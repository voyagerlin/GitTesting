/************************************************
 *   IAD103* : �H�Υd���Y���D���H���� *
 *   PROGRAM : ia103q01s.ec             	*
 *                                              *
 *   DATE    : 			                *
 *                                              *
 ************************************************/
#include <stdio.h>
#include <string.h>
#include "safeclib.h"
#include <time.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
$include sqltypes;
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"
#include <decimal.h>
#include "notmsgs.h"
#include "commsgs.h"

/*------------------------------------*/
extern char RPTDIR[];
time_t tstart, tstop;
float tused=0;

$char char_drcv1[9], char_drcv2[9];
$char company[3];
$char drcv1[11], drcv2[11];

$char iserno[13],    fstatus[2],      ADdinput[11],  ADdbegin[11],  ADdplyend[11], identity[2],
      ADdacc[11],    ncredit[21],     pay_type[2],   itmp_no[13],   ADdpay[11],
	  insure_type[2],  ipolicy1[21],  ipolicy2[21],  iendorse[21],  ftype[2],
	  nassured[121],     iquota[7],     isub[3],       ninsure_type[7],niquota[41];

/*$long dbegin;
 $long dplyend=0; */
$char Cdbegin[16],Cdplyend[16],Cdinput[16],Cdacc[16],Cdpay[16];
$char igroup[13];
$char iofficer[11], ileader[11], nname[11], nleader[11];
$double mprem, mcredit;
$char DBName[6];

$char FormTp[3];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1];
char  outputf[ N_FILE+1];
char  userid[11];

$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;
int   max_count, errCode;
int   fstar;
long  tot_count;
$char sErrmsg[200],sfilename[200], stitle[1024];
int   rc;
long iad103_build();

/************************************************/

main(argc, argv)
int argc;
char **argv;
{
    int rc;

    time(&tstart);
    batchinit();
    
    strcpy(DBName,        isNULLstr(argv[1]));
    strcpy(userid,        isNULLstr(argv[2]));
    strcpy(company,       isNULLstr(argv[3]));
    strcpy(char_drcv1,    isNULLstr(argv[4]));
    strcpy(char_drcv2,    isNULLstr(argv[5]));
    strcpy(identity,      isNULLstr(argv[6]));
    strcpy(outputf,       isNULLstr(argv[7]));

	printf("103buid\n");

   if((rc=iad103_build()) != SUCCESS){
   		
	  	/*	EWRITE(userid, rc, "build function error !");
	 */
	 exit(0);
   }
  
}

/************************************************/
long iad103_build()
{
    $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];
    char   buffer[256];
    int    i, flag_seq,j, strlen, k;
    $char  stmt[2048];
     $char sFullDBName[17];

 	printf("buid_beg\n");
 	
 	if (db_select(company) == False){
         EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
         return 0;
    }
    
 	
 	$WHENEVER SQLERROR GOTO errexit;
 	$SET LOCK MODE TO WAIT;

    printf("*** char_drcv1[%s]  char_drcv2[%s]\n",char_drcv1,char_drcv2);
    strcpy(drcv1,cm_to_infdate(char_drcv1));
    strcpy(drcv2,cm_to_infdate(char_drcv2));
    
    printf("***drcv1[%s] drcv2[%s]\n",drcv1,drcv2);
    
  	$CREATE TEMP TABLE iad103_tbl
    ( 
      iserno        char(12),
      fstatus       char(1),
      dinput        char(9),
      dacc          char(9), 
      ncredit       char(20),
      insure_type   char(1),
      pay_type      char(1),
      ipolicy1      char(20),
      ipolicy2      char(20),
      iendorse      char(20),
      itmp_no       char(12),
      dpay          char(9),
      mprem         decimal(17,4),
      mcredit       decimal(17,4),
      nassured      char(120),      
      dplyend       char(9),
      dbegin        char(9),
      iofficer      char(10),
      ileader       char(10),
      niofficer     char(10),
      iquota        char(6),      
      nleader       char(10),
      ninsure_type  char(6),
      niquota       char(40),
      identity      char(1)
      

    )WITH NO LOG;
    
printf("company%s\n",company);
printf("identity[%s]\n",identity);

	strcpy(sFullDBName,get_full_dbname(company));

	sprintf_s(stmt, sizeof stmt,
	 " select a.iserno,      a.fstatus,   a.dinput,    a.dacc,     a.ncredit,  a.mcredit, a.identity,"
	  		" b.insure_type, b.pay_type,  b.ipolicy1,  b.ipolicy2, b.iendorse," 
	  		" b.itmp_no,     b.dpay,      b.mprem,"
	  		" c.nassured,    c.dplyend,   c.dbegin,    d.ileader,  c.ftype, c.iofficer,"
	  		" d.nname,       d.iquota"
	  " from %s:ao_prem_credit a, %s:ao_prem_crd_detail b, %s:ao_plyedr_prem c, officer d"
	 " where a.dacc between '%s' and '%s'"
	   " and a.identity matches '%s'"
	   " and a.iserno=b.iserno"
	   " and a.fcommit='1'"
	   " and b.ipolicy1=c.ipolicy1"
	   " and b.iendorse= c.iendorse"
	   " and b.ipolicy2=c.ipolicy2"
	   " and d.iofficer=c.iofficer"  		  
  " ORDER BY a.iserno, b.ipolicy1, b.ipolicy2;"
  			,sFullDBName,sFullDBName,sFullDBName, drcv1,drcv2, identity);
      
      printf("stmt == [%s]\n",stmt);
            
       $PREPARE PC FROM $stmt;
       $DECLARE Acursor1a CURSOR FOR PC;
       $OPEN  Acursor1a;

       max_count=0;

	for(i=0;;i++) 
	{
		printf("fetch\n");
	   $FETCH Acursor1a
	   	 INTO $iserno,      $fstatus,   $ADdinput,  $ADdacc,   $ncredit, $mcredit, $identity,
	  		  $insure_type, $pay_type,  $ipolicy1,  $ipolicy2, $iendorse, 
	  		  $itmp_no,     $ADdpay,    $mprem,
	  		  $nassured,    $ADdplyend, $ADdbegin,  $ileader,  $ftype,   $iofficer, 
	  		  $nname,       $iquota;
                       
	   printf("sqlcode=%ld\n",SQLCODE);

	   if ( SQLCODE == SQLNOTFOUND) {           
	   	     $CLOSE Acursor1a;	
	         $FREE Acursor1a;
	         
            printf("max_count=%ld\n",max_count);  
                          
             if (max_count == 0){
             	 printf("M_CM_NOT_FOUND\N");
             	 sprintf_s(sErrmsg, sizeof sErrmsg, "�H�Υd�ɧ䤣����");
            	 EWRITE(userid, rc, sErrmsg);
                 /*
	             EWRITE(userid, M_CM_NOT_FOUND, buffer);
	             */
	             return 0;
	        	}  
	        break;	
	   }
	   
	   max_count++;	     
       printf("max_count=%ld\n",max_count);
		
	   if (ftype[0] != 'E' && ftype[0] != 'P' && ftype[0] != '4')
           mprem = mprem * (-1);
           
        printf("mprem=%ld\n",mprem);   
               
	   $SELECT nname
		  INTO $nleader
		  FROM	officer
		 WHERE iofficer=$ileader;	
	   if ( SQLCODE == SQLNOTFOUND)          
	   	     nleader[0]='\0';

printf("nleader=[%s]\n",nleader);	
	   
	    $SELECT nbranch
		  INTO $niquota
		  FROM	sa_branch_type
		 WHERE ibranch=$iquota;	
	   if ( SQLCODE == SQLNOTFOUND)          
	   	     niquota[0]='\0';
	   	     	   
	   strcpy(Cdinput,cm_from_infdate_100(ADdinput));
	   strcpy(Cdacc,cm_from_infdate_100(ADdacc));
	   strcpy(Cdpay,cm_from_infdate_100(ADdpay));
	   strcpy(Cdbegin,cm_from_infdate_100(ADdbegin));
	   strcpy(Cdplyend,cm_from_infdate_100(ADdplyend));
	   

printf("Cdinput=[%s]\n",Cdinput);	
printf("Cdacc=[%s]\n",Cdacc);	
printf("Cdpay=[%s]\n",Cdpay);	
printf("Cdbegin[%s]\n",Cdbegin);
printf("Cdplyend=[%s]\n",Cdplyend);

printf("insure_type=[%s]\n",insure_type);
 strncpy(insure_type,trim(insure_type), 1);
printf("insure_type0=[%s]\n",insure_type[0]);

	   switch (insure_type[0]){
	    case 'C':
	    	strcpy(ninsure_type,"���I");
	    	break;
	    case 'M':
	    	strcpy(ninsure_type,"���I");
	    	break;
	    case 'F':
	    	strcpy(ninsure_type,"���I");
	    	break;
	    case 'O':
	    	strcpy(ninsure_type,"��L�I");
	    	break;
	    default: break;				
		}
printf("ninsure_type=[%s]\n",ninsure_type);	
		
		 sprintf_s(stmt, sizeof stmt, 
            "INSERT INTO iad103_tbl "
            "VALUES (?, ?, ?, ?, ?, ?,"
                    "?, ?, ?, ?, ?, ?,"
                    "?, ?, ?, ?, ?, ?,"
                    "?, ?, ?, ?, ?, ?, ? );");

         $PREPARE q4_pre FROM $stmt;
         $EXECUTE q4_pre
             USING  $iserno,      $fstatus,   $Cdinput,      $Cdacc,        $ncredit,
	  		  	    $insure_type, $pay_type,  $ipolicy1,     $ipolicy2,     $iendorse, 
	  		  		$itmp_no,     $Cdpay,     $mprem,        $mcredit, 
	  		  		$nassured,    $Cdplyend,  $Cdbegin,      $iofficer,     $ileader,  
	  		  		$nname,       $iquota,    $nleader,      $ninsure_type, $niquota,    $identity;

         if(sqlca.sqlerrd[2]==0)
         {
            sprintf_s(sErrmsg, sizeof sErrmsg,"�g�J�Ȧs�� iad103_tbl");
            EWRITE(userid, rc, sErrmsg);
            printf("error in iad103_tbl\n");
            return 0;
         }
      
    }/* end for */

    printf("put database \n");
        
    sprintf_s(sfilename, sizeof sfilename,"�@���H�Υd���Y�H����");
     
       strcpy(stitle,"����s��\t�I �O\tú�O�O\t�O�渹1\t�O�渹2\t��渹\t�Ȧ��s��\t");
       strcat(stitle,"���O���A\t��J���\t�H�Υd�J�b��\t�X���\t�ͮĤ�\t�R�P��\t");
       strcat(stitle,"���d�H\t���H/�D���H\t�O�O���B\t'ñ�b���B\t�O��W��\t�g��H�N��\t�g��H�W��\t�޲z�H�N��\t�޲z�H�W��\t�~�Z�k�ݥN��\t�~�Z�k�ݦW��\t");
       
       sprintf_s(stmt, sizeof stmt,
          "SELECT iserno,     ninsure_type, pay_type,  ipolicy1,  ipolicy2,   iendorse,"
                " itmp_no,    fstatus,      dinput,    dacc,      dplyend,    dbegin,    dpay,"    
                " ncredit,    identity,     mprem,     mcredit,   nassured,   "
                " iofficer,   niofficer,    ileader,   nleader,   iquota,     niquota"
          "  FROM iad103_tbl "
          " ORDER BY identity, iserno, ipolicy1");

        printf("stmt[%s]\n",stmt); 

       rc = unload_file(outputf,"",sfilename, stitle, stmt);

       if(rc != SUCCESS)
       { 
          sprintf_s(sErrmsg, sizeof sErrmsg, "%s �ɮ׵L�k����", sfilename);
          EWRITE(userid, rc, sErrmsg);
          return 0;
       } 

    time(&tstop);
    tused=difftime(tstop, tstart);
    printf("������� = %f ��\n", tused);

    return SUCCESS;
	
errexit:
	printf("[build] : SQLCODE=%ld sqlca.sqlerrm=%s\n",SQLCODE,sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return 0;
}
/*----------------------------------------------------------------------------*/
