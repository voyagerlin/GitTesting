/**********************************************************************/
/*   program id   : ca301p08s.ec                                      */
/*   program name : �Ϳ��n�O�Ѹ������                                */
/*   date written : 2016/12/12                                        */
/*   exec time    : 02:30                                             */
/**********************************************************************/

#include <stdio.h>
#include <time.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include "print.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "othmsgs.h"
#include "commsgs.h"
#include "sqlfatal.h"
$include "var_length.h";
$include sqltypes;
#include "globdata.h"
#include "safeclib.h"



$char	DBName[5], userid[11], sdate1[11],sdate2[11];
DBinfo  *list;
char  	outputf[ N_FILE+1],sApHome[30],msgbuf[100],pathname[31],
        filename[50],filename1[50];
int     i,count_db;
FILE     *fp,*fp1;


/*----------------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
    int rc;
    $char date1[11];
      
    batchinit();
    strcpy(DBName,  isNULLstr(argv[1]));
    strcpy(userid,  isNULLstr(argv[2]));
    strcpy(sdate1,  isNULLstr(argv[3]));
    strcpy(sdate2,  isNULLstr(argv[4]));
    strcpy(outputf, isNULLstr(argv[5]));
    
    
    rc = car3019_get_db();
    if (rc != M_CM_OK) {
        printf("error on car3019_get_db\n");
        return rc;
    }
    
    $select first 1 to_char(date($sdate2),'%Y%m%d') into $date1 from systables;
    strcpy(date1, trim(date1));
    printf("sdate1=[%s]sdate2=[%s]date1=[%s]\n",sdate1,sdate2,date1);
    
    rc = getApHome(sApHome);
    sprintf_s(pathname, sizeof pathname,"%s/rptftp/ks/",sApHome);
    sprintf_s(filename, sizeof filename,"%sri_17_%s.txt",pathname,date1);
    sprintf_s(filename1, sizeof filename1,"%srid_17_%s.txt",pathname,date1);
    printf("filename[%s][%s]\n",filename,filename1);

    if ((fp=fopen(filename,"w")) == NULL) {
        printf("fopen error[%s]\n",filename);
        return M_CM_FAILED;
    }

    if ((fp1=fopen(filename1,"w")) == NULL) {
        printf("fopen error[%s]\n",filename1);
        return M_CM_FAILED;
    }
    /*----------------*/
    rc = car3019_ply_data();
    if (rc != M_CM_OK) {
        printf("error on car3019_ply_data\n");
        EWRITE(userid, rc, "�^���Ϳ��O���Ʀ��~!");
        return rc;
    }

    fclose(fp);
    fclose(fp1);
    printf("[car3019]:process ok!\n"); 
}
/*----------------------------------------------------------------------------*/
long car3019_get_db()
{
    int	rc;

    
    if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "��Ʈw�L�k�}��!");
       return M_CM_DB_NOTOPEN;
    }
    
    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }
    
    if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
       if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
          return M_CM_NOT_DBLIST;
    }

    return M_CM_OK;
}
/*----------------------------------------------------------------------------*/
long car3019_ply_data()
{
    int	rc, n, m;
    $char   stmt[3000],stmt2[1000],tmp[200],str_mnt[1000],str_mntb[1000];
    $char   ipolicy[21],icard[21],iengine[CA_ENGINE_NUM],dpolicy[11],ibig_sales[11];
    $char   ibig_office[10],nassured[31],itel[21],aassured[91];
    $char   ibenef[11],dply_begin[11],dply_end[11],icar_flag[2];
    $char   icar_type[3],iissue_ym[7],nuser[11],itag[CA_TAG_NUM],nbrand_abbr[13];
    $char   ibrand[9],iins_type[7],fcard_class[2],nbenef[43],iass4[5];
    $long   mprem = 0,mdmg_cover = 0,minj_cover = 0,mdth_cover = 0,mdeduct = 0,mins_prem;
    $char   dply_fmt[11],dbgn_fmt[11],dend_fmt[11],dissue[11],itype_prem[2];
    $char   ioff1[2],nass_all[121],iofficer[11],ilast_ply[21],dissue_ym[7];
    $long   mnt,mnt_b;
    $char   ply1[13],ply2[4],fbenef[2];
    long    rtncode;
    char    itype[10];
    
    $whenever sqlerror goto errexit;
    for(i=0;i<count_db;i++) 
    {  	 
        sprintf_s(stmt, sizeof stmt,
            "select a.ipolicy,a.icard,a.fcard_class, \
                    case when iengine = ' ' then ibody else iengine end, \
                    ibig_sales, ibig_office,nassured[1,30],itel,aassured,ibenef, \
                    dply_begin, dply_end,icar_flag,icar_type, \
                    to_char(dissue,'%%Y')||to_char(dissue,'%%m'), nuser[1,10], \
                    nvl(itag,' '), nbrand_abbr,ibrand,mdmg_prem+mlia_prem,nbenef, \
                    iofficer[1], nassured,nvl(ilast_ply,' '),iofficer,nvl(dpolicy,'XX'), \
                    iassured[7,10], \
                    to_char(dissue,'%%Y')||'/'||to_char(dissue,'%%m')||'/'||to_char(dissue,'%%d') \
               from %s:ply_relation a, %s:policy b  \
              where dentry between '%s' and '%s'  \
                and a.ipolicy = b.ipolicy and a.iofficer[1,1] = 'A'",
        list[i].dbname,list[i].dbname,sdate1, sdate2);

	    $PREPARE pre_ply from $stmt;
        $DECLARE cur_ply CURSOR FOR pre_ply;
        $OPEN cur_ply;
		for(;;)
		{
	        $fetch cur_ply into 
	                $ipolicy,$icard,$fcard_class,$iengine,$ibig_sales,
                    $ibig_office,$nassured,$itel,$aassured,$ibenef,$dply_begin,
                    $dply_end,$icar_flag,$icar_type,$dissue_ym,$nuser,$itag,
                    $nbrand_abbr,$ibrand,$mprem,$nbenef,$ioff1,$nass_all,
                    $ilast_ply,$iofficer,$dpolicy,$iass4, $dissue;
            if (SQLCODE==SQLNOTFOUND) break;
            
            strcpy(ipolicy,trim(ipolicy));
            strcpy(icard,trim(icard));
            strcpy(iengine,trim(iengine));
            strcpy(ibig_sales,trim(ibig_sales));
            strcpy(ibig_office,trim(ibig_office));
            strcpy(nassured,trim(nassured));
            strcpy(itel,trim(itel));
            strcpy(aassured,trim(aassured));
            strcpy(nuser,trim(nuser));
            strcpy(itag,trim(itag));
            strcpy(nbrand_abbr,trim(nbrand_abbr));

            dbgn_fmt[0]='\0';
            dend_fmt[0]='\0';
            dply_fmt[0]='\0';
            trans_date(dply_begin,dbgn_fmt);
            trans_date(dply_end,dend_fmt);
            strcpy(dpolicy, trim(dpolicy));
            if (strcmp(dpolicy,"XX") == 0)
                strcpy(dply_fmt," ");
            else
                trans_date(dpolicy,dply_fmt);

            if (strncmp(ibenef,"1231247",7)==0)
                strcpy(fbenef,"T");
            else if (strlen(trim(nbenef))==0)
                strcpy(fbenef,"N");
            else strcpy(fbenef,"O");
            	
            strcpy(tmp,"");

            rtncode = split_policy(ipolicy, ply1, ply2);

            n = 0;            
            sprintf_s(stmt2, sizeof stmt2,
                "select  b.itype_prem,sum(b.mnt) \
                   from cm_pre_receive a,ao_prercv_detail b \
                  where a.ipolicy1= '%s' \
                    and a.ipolicy2= '%s' \
                    and a.ipre_rcv=b.ipre_rcv \
                    and a.iins_kind =b.iins_kind  \
                    and a.ipre_end = b.ipre_end \
                  group by itype_prem \
                  order by sum(b.mnt) DESC ;",ply1, ply2);
            $PREPARE pre_mnt from $stmt2;
            $DECLARE cur_mnt CURSOR FOR pre_mnt;
            $open    cur_mnt;

            while(1)
            { 
	            mnt=0;
	
                $fetch cur_mnt into $itype_prem,$mnt;
                printf("***itype_prem[%s] mnt[%d]\n",itype_prem,mnt);
       
                strcpy(str_mnt,ltoa(mnt));
                printf("itype[%s]str_mnt[%s]\n",itype,str_mnt);
                if(SQLCODE == SQLNOTFOUND)
	            {
	                strcpy(itype_prem,"");
	                strcpy(itype,"");
	                strcpy(str_mnt,"");
                }/*ú�ڤ覡*/
                else if (strcmp(itype_prem,"A")==0)
                {
                    strcpy(itype,"�l��");
                }
                else if (strcmp(itype_prem,"B")==0)
                {
                    strcpy(itype,"�q�s");
                }
                else if (strcmp(itype_prem,"C")==0)
                {
                    strcpy(itype,"ATM");
                }
                else if (strcmp(itype_prem,"D")==0)
                {
                    strcpy(itype,"�K�Q�ө�");
                }
                else if (strcmp(itype_prem,"E")==0)
                {
                    strcpy(itype,"�Ȧ�O�N");
                }
                else if (strcmp(itype_prem,"1")==0)
                {
                    strcpy(itype,"�{��");
                }
                else if (strcmp(itype_prem,"2")==0)
                {
                    strcpy(itype,"�Ȧs");
                }
                else if (strcmp(itype_prem,"3")==0)
                {
                    strcpy(itype,"����");
                }
                else if (strcmp(itype_prem,"4")==0)
                {
                    strcpy(itype,"��ú");
                }
                else if (strcmp(itype_prem,"6")==0)
                {
                    strcpy(itype,"�Ȧ���");
                }
                else if (strcmp(itype_prem,"7")==0)
                {
                    strcpy(itype,"�H�Υd");
                }
                else if (strcmp(itype_prem,"8")==0)
                {
                    strcpy(itype,"�׶O");
                }
                else if (strcmp(itype_prem,"9")==0)
                {
                    strcpy(itype,"����");
                }
                
                if(n==2)
                {  
                    mnt_b=0;
                    strcat(tmp,itype);
	                strcat(tmp,",");
                    mnt_b=mnt;
                    printf("mnt_b[%d]\n",mnt_b); 
                }
                else if(n==3)
                {
                    mnt=mnt+mnt_b;
                    strcpy(str_mnt,ltoa(mnt));
                    if(mnt==0) strcpy(str_mnt,"");
                    strcat(tmp,str_mnt);
	                strcat(tmp,",");
        	    }
                else
                {
                    strcat(tmp,itype);
	                strcat(tmp,",");
	                strcat(tmp,str_mnt);
	                strcat(tmp,",");
                }
                n++;
                if (n == 4) break;
            }
            
            if (strncmp(fcard_class,"2",1)==0) 
            {
                fprintf(fp,"%s,,17,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,,,,,%d,,,,,,,,,%s\n", 
                    ipolicy,icard,iengine,dply_fmt,ibig_sales,ibig_office,
                    nassured,itel,aassured,fbenef,dbgn_fmt,dend_fmt,
                    icar_flag,icar_type,dissue,nuser,itag,nbrand_abbr,
                    ibrand,mprem,tmp);
            }
            else 
            {
                fprintf(fp,"%s,,17,,%s,%s,%s,%s,%s,%s,%s,%s,,,%s,%s,%s,%s,%s,%s,%s,,,,,,,,,%s,17,%s,%s,%d,%s\n", 
                    ipolicy,iengine,dply_fmt,ibig_sales,ibig_office,
                    nassured,itel,aassured,fbenef,
                    icar_flag,icar_type,dissue,nuser,itag,nbrand_abbr,
                    ibrand,icard,dbgn_fmt,dend_fmt,mprem,tmp);
            }
            
            sprintf_s(stmt2, sizeof stmt2,
                "select (select iins_type_ks from insurance_type where iins_type = a.iins_type), \
                        sum(mdamage_cover),sum(minjured_cover),sum(mdeath_cover), \
                        max(mdeduct),sum(mins_premium) \
                   from %s:ply_ins_type a \
                  where ipolicy = '%s' group by 1; ",list[i].dbname,ipolicy);
            $PREPARE pre_ins from $stmt2;
            $DECLARE cur_ins CURSOR FOR pre_ins;
            $open    cur_ins;
            while(1) 
            {
                $fetch cur_ins into $iins_type,$mdmg_cover,$minj_cover,$mdth_cover,
                                    $mdeduct,$mprem;
                if (SQLCODE==SQLNOTFOUND) break;
                
                strcpy(iins_type,trim(iins_type));

                fprintf(fp1,",%s,%s,%s,%d,%d,%d,%d,%d,\n",
                        ipolicy,icard,iins_type,minj_cover,mdth_cover,
                        mdmg_cover,mdeduct,mprem);
            }
            $close cur_ins;
        }
        $CLOSE cur_ply;
        $FREE cur_ply;
	}  

	return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*----------------------------------------------------------------------------*/
trans_date(dfrom,dtrans)
char *dfrom,*dtrans;
{
   char dtrans2[11];
   sprintf_s(dtrans2, sizeof dtrans2,"%s/",substring(dfrom,7,4));
   strncat(dtrans2,dfrom,5);
   strcpy(dtrans,dtrans2);
}
/*--------------------------------------------------------------------*/
trans_date1(dfrom,dtrans)
char *dfrom,*dtrans;
{
   strcpy(dtrans,substring(dfrom,7,4));
   strcat(dtrans,substring(dfrom,1,2));
   strcat(dtrans,substring(dfrom,4,2));
}
/*--------------------------------------------------------------------*/
long split_policy(sIpolicy, sIpolicy1, sIpolicy2)
char *sIpolicy, *sIpolicy1, *sIpolicy2;
{
     strcpy(sIpolicy, trim(sIpolicy));
     if (strlen(sIpolicy) == CAR_PLY_TAG_LEN)
     {
        strncpy(sIpolicy1, sIpolicy, CAR_POLICY_LEN);
        sIpolicy1[CAR_POLICY_LEN] = '\0';
        strncpy(sIpolicy2, sIpolicy+CAR_POLICY_LEN, CAR_TARGET_LEN);
        sIpolicy2[CAR_TARGET_LEN] = '\0';
     }
     else
     {
        strcpy(sIpolicy1,sIpolicy);
        strcpy(sIpolicy2," ");
     }
     return M_CM_OK;
}

/* runbatch 00 930268 car3019 P 2 '11/30/2016' '12/01/2016'  */