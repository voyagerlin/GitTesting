/***********************************************************************
*	program id   : ca214m01s.ec                                    *
*	program name : �j��d���O�I��O�ҩ�                            *
*	date written : 2014/05/22                                      *
*	                                                               *
***********************************************************************/

#include <stdio.h>
#include <time.h>
#include <string.h>
#include <decimal.h>
#include "sqlfatal.h"
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "commsgs.h"
#include "carmsgs.h"
#include "safeclib.h"
$include sqlca;
$include carest.h;

$char DBName[5];
$char userid[7];
$char option[2];
$char arg1[21];
$char arg2[21];
$char dapplicant[21];
char sApHome[30];
char filename[201];
char fname[101];
FILE *fp;
$define COMPANY "17";

long car214(reply,command,com_len)
serverReply reply;
voidP command;

int com_len;
{
 long rtncode;
 long car214_print();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 /*option1 = option;*/

 switch(option)
 {
  case 'P':
           rtncode=car214_print(reply);
           printf("--- rtncode=[%d]-- \n",rtncode);
           break;
  default :
           if(exitsub(reply,M_CM_WRONG_OPTION) == True)
             return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}


long car214_print(reply)
serverReply reply;
{
    $char date[11],dToday[11],nyy[4],nmm[3],ndd[3];
    $char begin[11],begin_y[4],begin_m[3],begin_d[3];
    $char end[11],end_y[4],end_m[3],end_d[3];
    $char sWhere0[256];
    $char option2[2];
    $char stmt[2048];
    char msgbuf[2048];
    $int res;
    int return_code;
    int	tmp_len;
    long t;
    $char ireceipt[21];
    $char sNassured[121],sFassured[2],sIassured[13],sItag[CA_TAG_NUM],sIengine[CA_ENGINE_NUM],ibranch[7];
    $char sIbody[CA_BODY_NUM],sIcard[21],sDply_begin[11],sDply_end[11],sIpolicy[21],sIpolicy3[21],sIcar_type[3],date1[11];
    $char sIcard1[23];
    time_t now;

    cm_buf_get("%s %s %s %s %s %s",DBName,userid,option2,arg1,arg2,dapplicant);

    /*printf("******************dapplicant = %s*****************\n",dapplicant);           �n�O�ѽT�ߤ��*/

    $WHENEVER SQLERROR GOTO errexit;


    if (db_select(DBName) == False)
  {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
  }



   return_code = getApHome(sApHome);
	if (return_code < 0) {
	 strcpy(msgbuf,"read Config file error!!-->getApHome\n");
	return return_code;
  }


   t = cm_today();
   strcpy(date,cm_edate_str(t));
   strcpy(date1,date);
   strcpy(dToday,cm_from_infdate_100(date));
   cm_split_ymd_100(dToday,nyy,nmm,ndd);


    printf("option2 = %s\n",option2);

    if(strncmp(option2,"1",1) == 0)
     sprintf_s(sWhere0, sizeof sWhere0," AND a.ipolicy BETWEEN '%s' AND '%s'",arg1,arg2);
    else
     sprintf_s(sWhere0, sizeof sWhere0," AND a.icard BETWEEN '%s' AND '%s'",arg1,arg2);



     sprintf_s(stmt, sizeof stmt,"select b.nassured,b.fassured,b.iassured,b.itag,b.iengine,"
                         "b.ibody, a.icard ,a.dply_begin,a.dply_end,a.ipolicy[1,3],a.icar_type,a.ipolicy "
                  "from ply_relation a,policy b "
                  "where a.ipolicy = b.ipolicy "
                  "and a.fcard_class = '1' %s ",sWhere0);



   printf("129-stmt=%s\n",stmt);

   $PREPARE ca_policy FROM $stmt;
   $DECLARE policy_cur CURSOR FOR ca_policy;
   $OPEN policy_cur;
   /*qcnt = 0;*/

   time(&now);
   strcpy(filename," ");
   sprintf_s(fname, sizeof fname,"Proof%s%s%s%ld.txt",nyy,nmm,ndd,now);
   sprintf_s(filename, sizeof filename,"%s/rptftp/%s",sApHome,fname);
   printf("�j���I��O�ҩ�[%s]\n",filename);
   fp=fopen(filename,"w");



   $BEGIN WORK;


   for(;;)
   {
     $FETCH policy_cur INTO $sNassured,$sFassured,$sIassured,$sItag,$sIengine,
                            $sIbody,$sIcard,$sDply_begin,$sDply_end,$sIpolicy3,
                            $sIcar_type,$sIpolicy;

     printf("154-sNassured=[%s]\n",sNassured);
     printf("***************************************sIcard=%s\n",sIcard);
     /*printf("dapplicant = %s\nsDply_begin=%s***********\n",dapplicant,sDply_begin);*/

     if (SQLCODE != 0) break;

          res = cm_get_serial_num_dwritten("C1","I","0","00","",dToday,ireceipt);
          printf("res=%d\n",res);
          printf("ireceipt=%s\n",ireceipt);
          if (res != 0) return res;

     strcpy(sNassured,rtrim(sNassured));
     strcpy(sIpolicy3,trim(sIpolicy3));
     strcat(sIpolicy3,trim(ireceipt));

     printf("169-sNassured=[%s]\nireceipt=[%s]\n",sNassured,ireceipt);
     printf("------------------------------sIpolicy3=%s\n",sIpolicy3);


     strcpy(begin,cm_from_infdate_100(sDply_begin));
     cm_split_ymd_100(begin,begin_y,begin_m,begin_d);

     strcpy(end,cm_from_infdate_100(sDply_end));
     cm_split_ymd_100(end,end_y,end_m,end_d);



     $select b.ibranch into $ibranch
      from officer a,sa_branch_type b
      where a.iquota = b.ibranch
      and a.iofficer = $userid;

     /*�j���Ҹ��[�W���q�N�X"17"*/
     strcpy(sIcard1,trim(COMPANY));
     strcat(sIcard1,trim(sIcard));

     $INSERT INTO ca_card_proof
	 	 VALUES ($sIpolicy3,$sIpolicy,$sIcard,$dapplicant,$ibranch,$sNassured,$userid,current);     /*���Ӫ���(ca_card_proof)���ǥ�*/


     fprintf(fp,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n"
                ,sNassured,sFassured,sIassured,sItag,sIengine
                ,sIbody,sIcard1,begin_y,begin_m,begin_d,end_y,end_m,end_d
                ,sIpolicy3,sIcar_type,nyy,nmm,ndd,date1);
   }

     $CLOSE policy_cur;
     $FREE  policy_cur;
     fclose(fp);
     $COMMIT WORK;

      cm_buf_init(ReplyBuf);
      cm_buf_put("%l",M_CM_OK);
      cm_buf_put("%s",fname);

      tmp_len = cm_buf_len(ReplyBuf);

      if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
            return apiRC;
      else
            return api_OKComplete;


errexit:

     $ROLLBACK WORK;
     fclose(fp);
     sqlfatal();
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}