/*******************************************/
/*                                         */
/*   �T���I�z�߹w���έp��                  */
/*                                         */
/*   PROGRAM : ca817q01s.ec                */
/*                                         */
/*   DATE    : 88.04.19                    */
/*                                         */
/*******************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"

$char fulldb[40];
$char stmt[1024] ;
$char module[3];
$char dtype[2];
$char dbgn1[11], dend1[11];
$char sWhere0[500];

static $char option[2];
$long sub_qcount_01;
$long sub_app_01;
$long sub_fee_01;
$long sub_qcount_05;
$long sub_app_05;
$long sub_fee_05;
$long sub_qcount_08;
$long sub_app_08;
$long sub_fee_08;
$long sub_qcount_09;
$long sub_app_09;
$long sub_fee_09;
$long sub_qcount_11;
$long sub_app_11;
$long sub_fee_11;
$long sub_qcount_32;
$long sub_app_32;
$long sub_fee_32;
$long sub_qcount_93;
$long sub_app_93;
$long sub_fee_93;
$long sub_qcount_94;
$long sub_app_94;
$long sub_fee_94;
$long sub_qcount_95;
$long sub_app_95;
$long sub_fee_95;
$long sub_qcount_51;
$long sub_app_51;
$long sub_fee_51;
$long sub_qcount_33;
$long sub_app_33;
$long sub_fee_33;
$long sub_qcount_16;
$long sub_app_16;
$long sub_fee_16;
$long sub_qcount_oth;
$long sub_app_oth;
$long sub_fee_oth;
$long sub_qcount_tot;
$long sub_app_tot;
$long sub_fee_tot;
$long sub_qcount_21;
$long sub_app_21;
$long sub_fee_21;
$long page=1;
$long Sum =0, Sum_qcount = 0;
$char DBName[05], FormTp[03];
char  outputf[N_FILE+1], userid[06];

int fHasData=0, fFindData=0, fFirstData=1;
static int max_cnt=0;

long ca817_build();
long ca817_detail();
void ca817_accumulate();
void ca817_title();
void ca817_init_table();

/*----------------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
   long rc;
   sub_qcount_01 = sub_app_01 = sub_fee_01 = 0;
   sub_qcount_05 = sub_app_05 = sub_fee_05 = 0;
   sub_qcount_09 = sub_app_09 = sub_fee_09 = 0;
   sub_qcount_11 = sub_app_11 = sub_fee_09 = 0;
   sub_qcount_93 = sub_app_93 = sub_fee_93 = 0;
   sub_qcount_94 = sub_app_94 = sub_fee_94 = 0;
   sub_qcount_32 = sub_app_32 = sub_fee_32 = 0;
   sub_qcount_95 = sub_app_95 = sub_fee_95 = 0;
   sub_qcount_51 = sub_app_51 = sub_fee_51 = 0;
   sub_qcount_oth = sub_app_oth = sub_fee_oth = 0;
   sub_qcount_21 = sub_app_21 = sub_fee_21 = 0;
   sub_qcount_33 = sub_app_33 = sub_fee_33 = 0;
   sub_qcount_16 = sub_app_16 = sub_fee_16 = 0;
   sub_qcount_08 = sub_app_08 = sub_fee_08 = 0;
   batchinit();
   strcpy(DBName, isNULLstr(argv[1]));
   strcpy(userid, isNULLstr(argv[2]));
   printf("DBName==>[%s]\n",DBName);

   strcpy(module, isNULLstr(argv[3]));
   strcpy(dbgn1, isNULLstr(argv[4]));
   strcpy(dend1, isNULLstr(argv[5]));
   printf("module===>[%s]\n",module);
   strcpy(option,isNULLstr(argv[6]));
   strcpy(outputf, isNULLstr(argv[7]));
   printf("outputf[%s]\n",outputf);

   strcpy(dbgn1, cm_to_infdate(dbgn1));
   strcpy(dend1, cm_to_infdate(dend1));

   rc = ca817_build();
   printf("rc----[%d]\n",rc);
   printf("delete ca817 begin\n");

   if (rc == api_OKComplete)
   {
     if ((rc=save_form_info(F_FREE, "CA", 817, userid, FormTp, 80,outputf))<0)
             EWRITE(userid, rc, "save_form_info failed");
     else
         printf("FormTp[%s],outputf[%s]\n",FormTp,outputf);
   }
}

/*----------------------------------------------------------------------------*/
long ca817_build()
{
   $char  FormFmt[N_FILE+1];
   $int   StartRow, TitleRow, TotColumn, PgLine, Width;

   char   FormFile[N_FILE+1];
   int    i, rcd;
   $char  dbname[8],server[20],t_iclaim[13],t_igroup[7];
   $char  sTemp[500];

   $WHENEVER SQLERROR GOTO errexit;
   
   if(db_select("S1") == False){
        return M_CM_DB_NOTOPEN;
  }

   $SELECT nForm_File, kStart_Row, kTitle_Row,
                kTot_Col, kPgNum_Line, kWidth, iForm_Tp
           INTO $FormFmt, $StartRow, $TitleRow,
                $TotColumn, $PgLine, $Width, $FormTp
           FROM Form
          WHERE ksys_grp = "CA" AND kPgmID = 817;

printf("nForm_File--->[%s]\n",FormFmt);
           
   strcpy(FormFmt, rtrim(FormFmt));
   sprintf(FormFile, "%s.tx", outputf);
   printf("outputf--->[%s]\n",FormFile);
 
  /***** ���ؤ@�� table �u�� ngroup , ��L���Ҭ� 0 *****/
  ca817_init_table(); 
printf(" ********************************************* \n");
  /***** prepare  SQL  stmt************/
  sprintf(stmt,"SELECT dbname,server FROM servertbl WHERE branch <> 'S1'");
  $PREPARE STMT1 FROM $stmt;
  $DECLARE sertbl_cur CURSOR FOR STMT1;
  $OPEN   sertbl_cur;
    while(1)
      {
        $FETCH  sertbl_cur into $dbname,$server ;
        if (SQLCODE == SQLNOTFOUND)
                 break;
        strcpy(dbname,trim(dbname));
        sprintf(fulldb,"%s@%s",dbname,server);
        printf("fulldb--[%s]\n",fulldb);
        strcpy(fulldb,trim(fulldb));
     
 /**�X�I��[option==>1] �Ψ��z��[option==>2] ***/
printf("  option [%s] , module[%s] \n", option , module );

        if (option[0] == '1')
        {
           strcpy(sTemp," AND date(daccident) >= ? AND date(daccident) <= ?  ");
           strcpy(sWhere0," ");
        }
        else if (option[0] == '2')
        {
           strcpy(sTemp," AND date(dclaim) >= ? AND date(dclaim) <= ?  ");
           strcpy(sWhere0," ");
        }
        else
        {
           sprintf(sTemp," AND (a.iclaim in (select z.iclaim from %s:app_ins_type z where z.iclaim = a.iclaim  \
                                                and z.dappraisal >= ? and z.dappraisal <= ?) or    \
                                a.iclaim in (select y.iclaim from %s:ca_app_victim y where y.iclaim = a.iclaim \
                                                and y.dappraisal >= ? and y.dappraisal <= ?) )  ",fulldb,fulldb);

           sprintf(sWhere0," AND dappraisal >= '%s' AND dappraisal <= '%s' ",dbgn1, dend1);
        }

        if (strncmp(module,"01",2) ==0) 
        {
           sprintf(stmt,"SELECT a.iclaim,c.igroup \
                  FROM %s:appraisal a, %s:ply_relation b,\
                       %s:sa_branch_type c \
                  WHERE a.ipolicy = b.ipolicy \
                  AND   b.iquota = c.ibranch \
                  AND a.dapp_entry is not null \
                  %s "
                 ,fulldb,fulldb,fulldb,sTemp);
        }
        else if(strncmp(module,"02",2) ==0) 
        {
                sprintf(stmt,"SELECT a.iclaim,c.ibig_comp[1,3] \
                  FROM %s:appraisal a, %s:ply_relation b,\
                       %s:ca_big_office c \
                  WHERE a.ipolicy = b.ipolicy \
                  AND  b.ibig_comp matches '[A-M]' \
                  AND  b.ibig_comp = c.ibig_comp[1,1] \
                  AND a.dapp_entry is not null \
                  %s "
                  ,fulldb,fulldb,fulldb,sTemp);
        }
        else
        {
        	  sprintf(stmt,"SELECT a.iclaim, a.iclaim[1,3] \
                FROM %s:appraisal a \
                WHERE a.dapp_entry is not null \
                  %s "
                  ,fulldb,sTemp);                
        }

        printf("stmt[%s]\n",stmt);

        $PREPARE ap_stmt01 FROM $stmt;  
        $DECLARE ap_01   CURSOR  FOR  ap_stmt01; 

        if (option[0] == '3')
        {
           $OPEN    ap_01   USING   $dbgn1,$dend1,$dbgn1,$dend1;
        }
        else
        {
           $OPEN    ap_01   USING   $dbgn1,$dend1;
        }

        while(1)
        {
            $FETCH   ap_01   INTO    $t_iclaim,$t_igroup; 
            if(SQLCODE == SQLNOTFOUND)
                break;
            printf("iclaim[%s],igroup[%s]\n",t_iclaim,t_igroup);
            ca817_accumulate(module,option,t_iclaim,t_igroup);
        }
        $CLOSE   ap_01;
        $FREE    ap_01;
        printf("ca817_accumulate end\n");

      }
   $CLOSE sertbl_cur;
   $FREE  sertbl_cur;

   /* build report  **/
   rgu_init_report(FormFmt, FormFile);
   ca817_title();
   ca817_detail();
   printf("ca817_detail sucess\n");
   rgu_finish_report();
   return api_OKComplete;

errexit:
   /*printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);**/
   return FAIL;
}


/*----------------------------------------------------------------------------*/

void ca817_accumulate(ac_bse1,ac_bse2,tmp_iclaim,igroup)
char  *ac_bse1,*ac_bse2;
$char *tmp_iclaim,*igroup;
{
  $char iins_type[INSURANCE_TYPE];
  $char ipolicy1[21], ipolicy2[21], iendorse[21];
  $int  id;
  $long qcount, M_qcount,mins_app,mproc_fee,mapp_fee;

  $long tmp_qcount, tmp_prem, rc;
  $char num1[6],num2[6],num3[6];

  $WHENEVER SQLERROR GOTO errexit;

  /* ���N�I�`��ƥH�C�@�߮׭p�� */
  if(tmp_iclaim[5]!='C')
    {
     printf("claim type v[%s]--igroup[%s]\n",tmp_iclaim,igroup);
     
     $UPDATE ca817
      SET    qcount_tot = qcount_tot + 1
      WHERE      igroup = $igroup;

      sprintf(stmt,"SELECT iins_type,mins_app,mproc_app \
                      FROM   %s:app_ins_type \
                      WHERE  iclaim = ? %s ",fulldb, sWhere0);
      printf("stmt[%s]\n",stmt);
      $PREPARE ap_ins_stmt FROM $stmt;
      $DECLARE ap_ins  CURSOR  FOR  ap_ins_stmt;
      $OPEN  ap_ins USING $tmp_iclaim;
      while(1)
        {
          $FETCH ap_ins INTO $iins_type,$mins_app,$mproc_fee;

          if (SQLCODE == SQLNOTFOUND)
                  break;
          /**** 01���Ҧ� *****/
          if (strcmp(trim(iins_type), "01")==0 )
             {
                  $UPDATE ca817
                      SET app_01 = app_01 + $mins_app,
                          fee_01 = fee_01 + $mproc_fee,
                       qcount_01 = qcount_01 + 1
                    WHERE igroup = $igroup;
               }
          /**** 05+105���A��(05+105�s�w�����I) *****/
            else if (strcmp(trim(iins_type), "05")==0 || strcmp(trim(iins_type), "105A")==0 || strcmp(trim(iins_type), "105B")==0)
               {
                    $UPDATE ca817
                        SET app_05 = app_05 + $mins_app,
                            fee_05 = fee_05 + $mproc_fee,
                         qcount_05 = qcount_05 + 1
                      WHERE igroup = $igroup;
                }
          /**** 08���B�� *****/
            else if (strcmp(trim(iins_type), "08")==0 )
                {
                      $UPDATE ca817
                          SET app_08 = app_08 + $mins_app,
                              fee_08 = fee_08 + $mproc_fee,
                           qcount_08 = qcount_08 +1
                        WHERE igroup = $igroup;
                } 
          /**** 09������ *****/
            else if (strcmp(trim(iins_type), "09")==0 )
                {
                      $UPDATE ca817
                          SET app_09 = app_09 + $mins_app,
                              fee_09 = fee_09 + $mproc_fee,
                           qcount_09 = qcount_09 + 1
                        WHERE igroup = $igroup;
                 }
         /**** 11���ѵs�I *****/
            else if (strcmp(trim(iins_type), "11")==0 )
                {
                        $UPDATE ca817
                            SET app_11 = app_11 + $mins_app,
                                fee_11 = fee_11 + $mproc_fee,
                             qcount_11 = qcount_11 + 1
                         WHERE igroup = $igroup;
                  }
        /**** 32���d���I *****/
             else if  (strcmp(trim(iins_type), "32")==0)
                  {
                         $UPDATE ca817
                             SET app_32 = app_32 + $mins_app,
                                 fee_32 = fee_32 + $mproc_fee,
                              qcount_32 = qcount_32 + 1
                           WHERE igroup = $igroup;
                  }
       /**** 93���d���I *****/
              else if  (strcmp(trim(iins_type), "93")==0)
                   {
                          $UPDATE ca817
                              SET app_93 = app_93 + $mins_app,
                                  fee_93 = fee_93 + $mproc_fee,
                               qcount_93 = qcount_93 + 1
                            WHERE igroup = $igroup;    
                   }
       /**** 94���d���I *****/
              else if  (strcmp(trim(iins_type), "94")==0)
                   {
                           $UPDATE ca817
                               SET app_94 = app_94 + $mins_app,
                                   fee_94 = fee_94 + $mproc_fee,
                                qcount_94 = qcount_94 + 1
                             WHERE igroup = $igroup;
                    }
       /**** 95���d���I *****/
              else if  (strcmp(trim(iins_type), "95")==0)
                   {
                           $UPDATE ca817
                               SET app_95 = app_95 + $mins_app,
                                   fee_95 = fee_95 + $mproc_fee,
                                qcount_95 = qcount_95 + 1
                             WHERE igroup = $igroup;
                    }
       /**** 51�������I *****/
               else if (strcmp(trim(iins_type), "51")== 0)
                    {
                             $UPDATE ca817
                                 SET app_51 = app_51 + $mins_app,
                                     fee_51 = fee_51 + $mproc_fee,
                                  qcount_51 = qcount_51 + 1
                               WHERE igroup = $igroup;
                     }
       /**** 33���ˮ`�I *****/
               else if (strcmp(trim(iins_type), "33")== 0)
                    {
                            printf("  mproc_fee[%d] \n",mproc_fee);

                             $UPDATE ca817
                                 SET app_33 = app_33 + $mins_app,
                                     fee_33 = fee_33 + $mproc_fee,
                                  qcount_33 = qcount_33 + 1
                               WHERE igroup = $igroup;
                     } 
       /**** 16���ѥN�� *****/
               else if (strcmp(trim(iins_type), "16")== 0)
                    {
                             $UPDATE ca817
                                 SET app_16 = app_16 + $mins_app,
                                     fee_16 = fee_16 + $mproc_fee,
                                  qcount_16 = qcount_16 + 1
                               WHERE igroup = $igroup;
                     }                           
       /**** oth�����[�I *****/
                else
                     {
                               $UPDATE ca817
                                 SET app_oth = app_oth + $mins_app,
                                     fee_oth = fee_oth + $mproc_fee,
                                  qcount_oth = qcount_oth + 1
                                WHERE igroup = $igroup;
                      }
          }
          $CLOSE ap_ins;
          }
        else
          {
            mins_app = mapp_fee = 0;
            sprintf(stmt,"SELECT sum(mapp_cover),sum(mapp_fee) \
                            FROM   %s:ca_app_victim \
                           WHERE  iclaim = ? %s ",fulldb,sWhere0);
            printf("stmt[%s]\n",stmt);
            $PREPARE ap_vtm_stmt FROM $stmt;
            $DECLARE ap_vtm   CURSOR   FOR  ap_vtm_stmt;
            $OPEN   ap_vtm USING $tmp_iclaim;         
            $FETCH  ap_vtm INTO $mins_app,$mapp_fee;

            /* if (SQLCODE != SQLNOTFOUND) */
            if (mins_app + mapp_fee > 0)
               {
                $UPDATE ca817
                    SET app_21  = app_21    +  $mins_app,
                        fee_21 = fee_21 + $mapp_fee,
                     qcount_21  = qcount_21 +  1
                  WHERE  igroup = $igroup;
                }
            $CLOSE  ap_vtm;
          }
 return;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(1);
}

/*----------------------------------------------------------------------------*/
void ca817_init_table()
{
   $char ini_igroup[6];
   $long ini_qorder;
   $char ini_ngroup[21];

   printf("begin create temp table\n");
   $CREATE TEMP TABLE ca817
   (
    qorder integer,
    igroup char(5),
    ngroup char(20), 
    qcount_01 integer,
    app_01 integer,
    fee_01 integer,
    qcount_05 integer,
    app_05 integer,
    fee_05 integer,
    qcount_08 integer,
    app_08 integer,
    fee_08 integer,
    qcount_09 integer,
    app_09 integer,
    fee_09 integer,
    qcount_11 integer,
    app_11 integer,
    fee_11 integer,
    qcount_32 integer,
    app_32 integer,
    fee_32 integer,
    qcount_93 integer,
    app_93 integer,
    fee_93 integer,
    qcount_94 integer,
    app_94 integer,
    fee_94 integer,
    qcount_95 integer,
    app_95 integer,
    fee_95 integer,
    qcount_51 integer,
    app_51 integer,
    fee_51 integer,
    qcount_33 integer,
    app_33 integer,
    fee_33 integer,
    qcount_16 integer,
    app_16 integer,
    fee_16 integer,
    qcount_oth integer,
    app_oth integer,
    fee_oth integer,
    qcount_tot integer,
    app_tot integer,
    fee_tot integer,
    qcount_21 integer, 
    app_21 integer,
    fee_21 integer
  ) with no log; 
  

    $DECLARE tmp_cur1 CURSOR FOR
          SELECT qorder, igroup, ngroup
            INTO $ini_qorder, $ini_igroup, $ini_ngroup
            FROM sa_frm_module
           WHERE ifrm_module = $module
           ORDER BY qorder;
    $OPEN tmp_cur1;
     while(1)
        {
        $FETCH tmp_cur1;
        if(SQLCODE == SQLNOTFOUND) break;

        $INSERT INTO ca817
                     ( qorder, igroup, ngroup, qcount_01,app_01, fee_01,
                       qcount_05, app_05,fee_05,qcount_08,app_08,fee_08,
                       qcount_09, app_09,fee_09,qcount_11,app_11,fee_11,
                       qcount_32, app_32,fee_32,qcount_93,app_93,fee_93,
                       qcount_94, app_94,fee_94,qcount_95,app_95,fee_95,
                       qcount_51, app_51,fee_51,qcount_33,app_33,fee_33,
                       qcount_16, app_16,fee_16,qcount_oth,app_oth,fee_oth,
                       qcount_tot,app_tot,fee_tot,qcount_21,app_21,fee_21)
        VALUES ( $ini_qorder, $ini_igroup, $ini_ngroup, 0, 0, 0,
                       0, 0, 0, 0, 0, 0,
                       0, 0, 0, 0, 0, 0,
                       0, 0, 0, 0, 0, 0,
                       0, 0, 0, 0, 0, 0,
                       0, 0, 0, 0, 0, 0,
                       0, 0, 0, 0, 0, 0,
                       0, 0, 0, 0, 0, 0 );

        }
        printf("-------cur1 success-----\n");
        $CLOSE tmp_cur1;
        $FREE  tmp_cur1;
        return;
errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(1);
}

void ca817_title()
{
         if (option[0] == '1')
             rgu_put_body_string(1,"�X�I��",1);
         else
             rgu_put_body_string(1,"���z��",1);

         rgu_put_body_string(1, dbgn1 ,1);
         rgu_put_body_string(1, dend1 ,1);


         if (strncmp(module,"01",2) ==0)
             rgu_put_body_string(1,"�X����",1);
         else if (strncmp(module,"02",2) ==0)
             rgu_put_body_string(1,"�g�P��",1);
         else if (strncmp(module,"03",2) ==0)
             rgu_put_body_string(1,"���z���",1);

         rgu_put_body(1);
}

/*----------------------------------------------------------------------------*/
long ca817_detail() 
{
 $long Total,Total_fee,Sum1 ,Sum_fee;
 $long qcount_01, app_01, fee_01;
 $long qcount_05, app_05, fee_05;
 $long qcount_08, app_08, fee_08;
 $long qcount_09, app_09, fee_09;
 $long qcount_11, app_11, fee_11;
 $long qcount_32, app_32, fee_32;
 $long qcount_93, app_93, fee_93;
 $long qcount_94, app_94, fee_94;
 $long qcount_51, app_51, fee_51;
 $long qcount_oth,app_oth,fee_oth;
 $long qcount_95, app_95, fee_95;
 $long qcount_33, app_33, fee_33;
 $long qcount_16, app_16, fee_16;
 $long qcount_tot, app_tot,fee_tot;
 $long qcount_21, app_21, fee_21;
 $long tot_cnt_01, tot_app_01, tot_fee_01;
 $long tot_cnt_05, tot_app_05, tot_fee_05;
 $long tot_cnt_08, tot_app_08, tot_fee_08;
 $long tot_cnt_09, tot_app_09, tot_fee_09;
 $long tot_cnt_11, tot_app_11, tot_fee_11;
 $long tot_cnt_32, tot_app_32, tot_fee_32;
 $long tot_cnt_93, tot_app_93, tot_fee_93;
 $long tot_cnt_94, tot_app_94, tot_fee_94;
 $long tot_cnt_95, tot_app_95, tot_fee_95;
 $long tot_cnt_51, tot_app_51, tot_fee_51;
 $long tot_cnt_33, tot_app_33, tot_fee_33;
 $long tot_cnt_tot;
 $long tot_cnt_16, tot_app_16, tot_fee_16;
 $long tot_cnt_oth,tot_app_oth,tot_fee_oth;
 $long tot_cnt_21, tot_app_21, tot_fee_21;
 $long qorder, qcount;
 $char igroup[6];
 $char ngroup[21];
  char tmp_buf[16];

   $WHENEVER SQLERROR GOTO errexit;
   $DECLARE cursor CURSOR FOR
     SELECT  qorder, igroup, ngroup, qcount_01, app_01, fee_01,
             qcount_05, app_05, fee_05, qcount_08, app_08, fee_08,
             qcount_09, app_09, fee_09, qcount_11, app_11, fee_11,
             qcount_32, app_32, fee_32, qcount_93, app_93, fee_93,
             qcount_94, app_94, fee_94, qcount_95, app_95, fee_95,
             qcount_51, app_51, fee_51, qcount_33, app_33, fee_33,
             qcount_16, app_16, fee_16, qcount_oth,app_oth,fee_oth,
             qcount_21, app_21, fee_21, qcount_tot, app_tot,fee_tot
       INTO  $qorder,    $igroup, $ngroup, $qcount_01, $app_01, $fee_01,
             $qcount_05, $app_05, $fee_05, $qcount_08, $app_08, $fee_08,
             $qcount_09, $app_09, $fee_09, $qcount_11, $app_11, $fee_11,
             $qcount_32, $app_32, $fee_32, $qcount_93, $app_93, $fee_93,
             $qcount_94, $app_94, $fee_94, $qcount_95, $app_95, $fee_95,
             $qcount_51, $app_51, $fee_51, $qcount_33, $app_33, $fee_33,
             $qcount_16, $app_16, $fee_16, $qcount_oth,$app_oth,$fee_oth,
             $qcount_21, $app_21, $fee_21, $qcount_tot,$app_tot,$fee_tot

       FROM ca817
       ORDER BY qorder;

   $OPEN cursor;

   while(1)
   {
       $FETCH cursor;

       if(SQLCODE == SQLNOTFOUND) break;
       if(strncmp(igroup,"ZZZ",3) == 0 || strncmp(igroup,"YYY",3)==0) 
                   continue;

       printf(" 1111111111111111111111111111111111111 fee_33[%d]\n",fee_33);



       
    
       if (strcmp(trim(igroup),"ZZZ") != 0)
          {
               /**** ��X�C�@�檺�X�p�w���z�ߪ��B ****/
              Total = app_01 + app_05 + app_08 + app_09 + app_32
                      + app_93 + app_94 + app_95 + app_51 + app_33 + app_16 
                      + app_oth +app_11;


          Total_fee =  fee_01 + fee_05 + fee_08 + fee_09 + fee_32
                       + fee_93 + fee_94 + fee_95 + fee_51 + fee_33 + fee_16
                       + fee_oth + fee_11;



               rgu_put_body_string(2, ngroup, 1);
               rfmtlong(qcount_01, "----&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);
               rfmtlong(app_01, "--,---,---,--&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);
               rfmtlong(fee_01, "---,---,--&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);

               rfmtlong(qcount_05, "----&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);
               rfmtlong(app_05, "--,---,---,--&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);
               rfmtlong(fee_05, "---,---,--&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);

               rfmtlong(qcount_08, "----&", tmp_buf);
               rgu_put_body_string(2, tmp_buf, 2);
               rfmtlong(app_08, "--,---,---,--&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);
               rfmtlong(fee_08, "---,---,--&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);

               rfmtlong(qcount_09, "----&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);
               rfmtlong(app_09, "--,---,---,--&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);
               rfmtlong(fee_09, "---,---,--&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);

               rfmtlong(qcount_11, "----&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);
               rfmtlong(app_11, "--,---,---,--&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);
               rfmtlong(fee_11, "---,---,--&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);

               rfmtlong(qcount_93, "----&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);
               rfmtlong(app_93, "--,---,---,--&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);
               rfmtlong(fee_93, "---,---,--&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);

               rfmtlong(qcount_94, "----&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);
               rfmtlong(app_94, "--,---,---,--&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);
               rfmtlong(fee_94, "---,---,--&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);

               rfmtlong(qcount_95, "----&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);
               rfmtlong(app_95, "--,---,---,--&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);
               rfmtlong(fee_95, "---,---,--&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);

               rfmtlong(qcount_32, "----&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);
               rfmtlong(app_32, "--,---,---,--&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);
               rfmtlong(fee_32, "---,---,--&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);

               rfmtlong(qcount_51, "----&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);
               rfmtlong(app_51, "--,---,---,--&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);
               rfmtlong(fee_51, "---,---,--&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);

               rfmtlong(qcount_33, "----&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);
               rfmtlong(app_33, "--,---,---,--&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);
               rfmtlong(fee_33, "---,---,--&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);

               rfmtlong(qcount_16, "----&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);
               rfmtlong(app_16, "--,---,---,--&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);
               rfmtlong(fee_16, "---,---,--&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);

               rfmtlong(qcount_oth, "-----&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);
               rfmtlong(app_oth, "--,---,---,--&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);
               rfmtlong(fee_oth, "---,---,--&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);

               rfmtlong(qcount_tot, "-----&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);
               rfmtlong(Total, "--,---,---,--&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);
               rfmtlong(Total_fee, "---,---,--&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);
               printf(" ********************************tmp_buf[%s]\n",tmp_buf);

               rfmtlong(qcount_21, "-----&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);
               rfmtlong(app_21, "--,---,---,--&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);
               rfmtlong(fee_21, "---,---,--&", tmp_buf);
               rgu_put_body_string(2, trim(tmp_buf), 2);

               rgu_put_body(2);
             }

      }
     $CLOSE cursor;
     $FREE  cursor;


       /********************************************************/
       /***********      �L�X�̫�@�C�X�p���   ****************/
       /********************************************************/
        $SELECT  SUM(qcount_01), SUM(app_01), SUM(fee_01),
                 SUM(qcount_05), SUM(app_05), SUM(fee_05),
                 SUM(qcount_08), SUM(app_08), SUM(fee_08),
                 SUM(qcount_09), SUM(app_09), SUM(fee_09),
                 SUM(qcount_11), SUM(app_11), SUM(fee_11),
                 SUM(qcount_32), SUM(app_32), SUM(fee_32),
                 SUM(qcount_21), SUM(app_21), SUM(fee_21),
                 SUM(qcount_93), SUM(app_93), SUM(fee_93),
                 SUM(qcount_94), SUM(app_94), SUM(fee_94),
                 SUM(qcount_95), SUM(app_95), SUM(fee_95),
                 SUM(qcount_51), SUM(app_51), SUM(fee_51),
                 SUM(qcount_33), SUM(app_33), SUM(fee_33),
                 SUM(qcount_16), SUM(app_16), SUM(fee_16),
                 SUM(qcount_oth),SUM(app_oth),SUM(fee_oth),
                 SUM(qcount_tot)
           INTO  $tot_cnt_01, $tot_app_01, $tot_fee_01,
                 $tot_cnt_05, $tot_app_05, $tot_fee_05,
                 $tot_cnt_08, $tot_app_08, $tot_fee_08,
                 $tot_cnt_09, $tot_app_09, $tot_fee_09,
                 $tot_cnt_11, $tot_app_11, $tot_fee_11,
                 $tot_cnt_32, $tot_app_32, $tot_fee_32,
                 $tot_cnt_21, $tot_app_21, $tot_fee_21,
                 $tot_cnt_93, $tot_app_93, $tot_fee_93,
                 $tot_cnt_94, $tot_app_94, $tot_fee_94,
                 $tot_cnt_95, $tot_app_95, $tot_fee_95,
                 $tot_cnt_51, $tot_app_51, $tot_fee_51,
                 $tot_cnt_33, $tot_app_33, $tot_fee_33,
                 $tot_cnt_16, $tot_app_16, $tot_fee_16,
                 $tot_cnt_oth,$tot_app_oth,$tot_fee_oth,
                 $tot_cnt_tot
           FROM  ca817
          WHERE  igroup != "YYY" 
            AND  igroup != "ZZZ";  

      if (SQLCODE == SQLNOTFOUND)
      {
         printf("[ca817_detail] ca817 not found !!\n") ;
         EWRITE(userid, M_CM_NOT_FOUND, "ca817");
         exit(1);
      }
       
     /* �`�p�w���z�ߪ��B */ 
             Sum1 = tot_app_01 + tot_app_05 + tot_app_08 + tot_app_09 
                   + tot_app_11 + tot_app_32 + tot_app_93 + tot_app_94 + tot_app_95  
                   + tot_app_51 + tot_app_33 + tot_app_16 + tot_app_oth;


             Sum_fee = tot_fee_01 + tot_fee_05 + tot_fee_08 + tot_fee_09
                       + tot_fee_11 + tot_fee_32 + tot_fee_93 + tot_fee_94 + tot_fee_95
                       + tot_fee_51 + tot_fee_33 + tot_fee_16 + tot_fee_oth;



             strcpy(ngroup, "�X �p");
             rgu_put_body_string(2, ngroup, 1);
             rfmtlong(tot_cnt_01, "----&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);
             rfmtlong(tot_app_01, "--,---,---,--&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);
             rfmtlong(tot_fee_01, "---,---,--&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);

             rfmtlong(tot_cnt_05, "----&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);
             rfmtlong(tot_app_05, "--,---,---,--&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);
             rfmtlong(tot_fee_05, "---,---,--&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);

             rfmtlong(tot_cnt_08, "----&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);
             rfmtlong(tot_app_08, "--,---,---,--&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);
             rfmtlong(tot_fee_08, "---,---,--&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);

             rfmtlong(tot_cnt_09, "----&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);
             rfmtlong(tot_app_09, "--,---,---,--&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);
             rfmtlong(tot_fee_09, "---,---,--&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);

             rfmtlong(tot_cnt_11, "----&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);
             rfmtlong(tot_app_11, "--,---,---,--&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);
             rfmtlong(tot_fee_11, "---,---,--&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);

             rfmtlong(tot_cnt_93, "----&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);
             rfmtlong(tot_app_93, "--,---,---,--&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);
             rfmtlong(tot_fee_93, "---,---,--&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);

             rfmtlong(tot_cnt_94, "----&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);
             rfmtlong(tot_app_94, "--,---,---,--&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);
             rfmtlong(tot_fee_94, "---,---,--&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);

             rfmtlong(tot_cnt_95, "----&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);
             rfmtlong(tot_app_95, "--,---,---,--&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);
             rfmtlong(tot_fee_95, "---,---,--&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);

             rfmtlong(tot_cnt_32, "----&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);
             rfmtlong(tot_app_32, "--,---,---,--&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);
             rfmtlong(tot_fee_32, "---,---,--&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);

             rfmtlong(tot_cnt_51, "----&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);
             rfmtlong(tot_app_51, "--,---,---,--&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);
             rfmtlong(tot_fee_51, "---,---,--&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);

             rfmtlong(tot_cnt_33, "----&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);
             rfmtlong(tot_app_33, "--,---,---,--&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);
             rfmtlong(tot_fee_33, "---,---,--&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);

             rfmtlong(tot_cnt_16, "----&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);
             rfmtlong(tot_app_16, "--,---,---,--&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);
             rfmtlong(tot_fee_16, "---,---,--&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);

             rfmtlong(tot_cnt_oth, "-----&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);
             rfmtlong(tot_app_oth, "--,---,---,--&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);
             rfmtlong(tot_fee_oth, "---,---,--&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);

             rfmtlong(tot_cnt_tot, "-----&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);
             rfmtlong(Sum1, "--,---,---,--&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);
             rfmtlong(Sum_fee, "---,---,--&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);

             rfmtlong(tot_cnt_21, "-----&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);
             rfmtlong(tot_app_21, "--,---,---,--&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);
             rfmtlong(tot_fee_21, "---,---,--&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 2);

             rgu_put_body(2);  
            
             rgu_put_body_string(3, cm_sysd_cdatetime_100(cm_get_sysd()), 1);
             rgu_put_body(3);  

 
             return SUCCESS;

errexit:
printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   $DELETE from ca817;
   exit(1);
}

/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
