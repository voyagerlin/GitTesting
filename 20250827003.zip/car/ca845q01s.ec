#include <stdio.h>
#include <stdlib.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"

#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"

$include decimal;
char delimiter;
int count_db,k;

$char itag_in[CA_TAG_NUM];

char  outputf[21];
$char userid[11];
$char DBName[05];
$char flag[1];
$char user_choose_branch[5];
$char dclaim_begin[11],dclaim_end[11],ddecide_begin[11],ddecide_end[11],dundecide[11];
$char msgbuf[128];
$char falldb[2];

int offset;
char   sApHome[50];
FILE   *fp;
static char  *bp;
long   rtncode;

/* icnt_fkind �I�O ;iclaim �߮׸��X;nchi_full ���;iofficer �z�ߤH�����s;nname �z�ߤH���m�W;nbranch �z�ߤH�����;dappraisal �Ĥ@���w�����;facoption ���׼t�����O*/
$char icnt_fkind[21],iclaim2[3],iclaim[21],nchi_full[40],iofficer[11],temp_iofficer[11],nname[11],nbranch[41],dappraisal[12],ibranch_in[15],nassured[20],dclaim[12],daccident[20],ddecide[20],iins_type[20],facoption[20];
/* iquota �~�Z���N�� ;nquota �~�Z���W�� ;iroute �q���O�N�� ;nroute �q���O�W��*/
$char iquota[7],iquota_0[10],nquota[41],iroute[21],nroute[41];
/*money �w���z�ߪ��B*/
$char money[20];
$char stmt[4096];
$int  mprem;

int rc;
int Build_Count;
int Build_Start;
$char stmt_tmp1[1024],stmt_tmp2[1024],stmt_tmp3[1024];
DBinfo *list;

char opt[2];
int  undec_type;

main(argc, argv)
int argc;
char **argv;
{

    batchinit();
    strcpy(DBName,    isNULLstr(argv[1]));
    strcpy(userid,    isNULLstr(argv[2]));
    strcpy(flag,	isNULLstr(argv[3]));
    strcpy(user_choose_branch,	isNULLstr(argv[4]));
    strcpy(dclaim_begin,  isNULLstr(argv[5]));
    strcpy(dclaim_end,    isNULLstr(argv[6]));
    strcpy(ddecide_begin,  isNULLstr(argv[7]));
    strcpy(ddecide_end,    isNULLstr(argv[8]));
    strcpy(dundecide,    isNULLstr(argv[9]));
    strcpy(opt,    isNULLstr(argv[10]));
    strcpy(outputf,   isNULLstr(argv[11])); /*�T�w���̫�@�ӰѼ�*/
    printf("flag = %s \n",flag);
    printf("user_choose_branch = %s \n",user_choose_branch);
    printf("dclaim_begin = %s\n",dclaim_begin);
    printf("dclaim_end = %s\n",dclaim_end);
    printf("ddecide_begin = %s\n",ddecide_begin);
    printf("ddecide_end = %s\n",ddecide_end);
    printf("dundecide = %s\n",dundecide);

    undec_type = atoi(opt);		/* ���M������O: 0:�D���M 1:�J�p�� 2:�鵲�� */

    Build_Count=0;
    Build_Start=0;
    rc = car845_get_db();
    if (rc != M_CM_OK)
       return rc;

    rtncode = getApHome(sApHome);
    if (rtncode < 0)
    {
        EWRITE(userid, M_CM_READ_CONFIG_ERR, "read Config file error!!");
        return FAIL;
    }


    /* Create table car845_tmp1 */
    rc = ca845_create_temp();
    if (rc != M_CM_OK)
       return rc;


    if ((strcmp(dclaim_begin," ")!=0) && (strcmp(dclaim_end ," ")!=0))
    {
    	printf("prepare_date1-----------------------------------------------------------------------------\n");

    	rc = car845_prepare_data1();
    	if (rc != M_CM_OK)
       	   return rc;

       	Build_Count=Build_Count+1;
       	Build_Start=1;
    }

    if((strcmp(ddecide_begin," ")!=0) && (strcmp(ddecide_end," ")!=0))
    {
    	printf("prepare_date2-----------------------------------------------------------------------------\n");

    	rc = car845_prepare_data2();
    	if (rc != M_CM_OK)
       	   return rc;

       	Build_Count=Build_Count+1;

       	if(Build_Start==0)
       	{
       		Build_Start=2;
       	}
    }

    if(strcmp(dundecide," ")!=0 )
    {
    	printf("prepare_date3-----------------------------------------------------------------------------\n");

        if (undec_type == 1)
 	        rc = car845_prepare_data3();
 	    else if (undec_type == 2)
 	        rc = car845_prepare_data4();
 	    else
 	    {
 	        EWRITE(userid, M_CM_WRONG_OPTION, "read Config file error!!");
            rc = M_CM_WRONG_OPTION;
 	    }

    	if (rc != M_CM_OK)
    	   return rc;

    	Build_Count=Build_Count+1;

    	if(Build_Start==0)
    	{
       		Build_Start=3;
    	}
    }

    /*build report - ����*/
    rc = car845_build();
    if (rc != M_CM_OK)
       return rc;

}


/*--------------------------------------------------------------------*/
long car845_get_db()
{
   $whenever sqlerror goto errexit;

   if(db_select(DBName) == FALSE)
   {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }

   if((list = get_db_list(&count_db,DBName)) == (char*)0)
   {
      	EWRITE(userid, M_CM_NOT_DBLIST);
        return M_CM_NOT_DBLIST;
   }

   return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

/*------------------------���z���------------------------*/
long car845_prepare_data1()
{
	$char stmt_bedata[1024],stmt1[1024],stmt2[1024],stmt3[1024],stmt_icnt_fkind[512],stmt_iins[256],stmt_nchi_full[256],stmt_dappraisal[256],stmt_money[256],stmt_user_choose[256],stmt_facoption[512];
	$int temp_icnt_fkind;
	$char full_dbname[20];
	$char temp_iins[5];
	printf("flag = %s \n",flag);
	printf("chose flag \n");

	$WHENEVER SQLERROR goto errexit;

	printf("-------------------------------------���z���----------------------------------------------------\n");
	printf("flag = %s \n",flag);
    	printf("user_choose_branch = %s \n",user_choose_branch);


	if (db_select(DBName) == FALSE)
   	{
     		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      		return FAIL;
   	}

	if(strcmp(flag,"1")==0)
	{
		if(strcmp(user_choose_branch,"*")==0)
		{
			sprintf_s(stmt_user_choose,256," ");
		}
		else
		{
			sprintf_s(stmt_user_choose,256,
				"AND d.ibranch=replace(a.iclaim[1,2],'A',decode(a.iclaim[1],'0','0','4','0','7','0',a.iclaim[1])) "
				"AND d.iupcomp='%s' "
	   		        ,user_choose_branch);
		}
	}

	else
	{
		sprintf_s(stmt_user_choose,256,
			"AND replace(a.iclaim[1,2],'A',decode(a.iclaim[1],'0','0','4','0','7','0',a.iclaim[1]))='%s' "
			,user_choose_branch);
	}

	printf("stmt_user =%s\n",stmt_user_choose);


	  sprintf_s(stmt1,1024,
	  	"SELECT UNIQUE b.iofficer ,b.nname , c.nbranch "
	  	"FROM ca_clm_process a, officer b,sa_branch_type c,branch d "
	  	"WHERE a.dclaim >= '%s' and a.dclaim <= '%s' "
	  	"AND a.adjustment=b.iofficer "
	  	"AND b.iquota=c.ibranch "
	  	"AND d.ibranch=replace(a.iclaim[1,2],'A',decode(a.iclaim[1],'0','0','4','0','7','0',a.iclaim[1])) "
	  	"%s "
	  	,dclaim_begin,dclaim_end,stmt_user_choose);

    	$PREPARE pre1_1_1 FROM $stmt1;
        $DECLARE cur_pre1_1_1 CURSOR for pre1_1_1;
       	$OPEN cur_pre1_1_1;


	while(1)
    {
		$FETCH cur_pre1_1_1 INTO $iofficer,$nname,$nbranch;
		if(SQLCODE == SQLNOTFOUND) break;

		printf("S1 iofficer = %s \n ",iofficer);
		printf("S1 nname = %s \n ",nname);
		printf("S1 nbranch = %s \n ",nbranch);

		sprintf_s(stmt_bedata,1024,
		"SELECT a.iclaim,a.ibranch_in,a.nassured,a.dclaim,a.daccident,b.nchi_full "
		"FROM ca_clm_process a , branch b "
		"WHERE dclaim >= '%s' and dclaim <= '%s' "
		"AND b.ibranch=replace(a.iclaim[1,2],'A',decode(a.iclaim[1],'0','0','4','0','7','0',a.iclaim[1])) "
		"AND adjustment='%s' " , dclaim_begin,dclaim_end,iofficer);

		$PREPARE Data_1 FROM $stmt_bedata;
		$DECLARE cur_BData_1 CURSOR for Data_1;
		$OPEN  cur_BData_1;

		while(1)
		{
			$FETCH 	cur_BData_1 INTO $iclaim,$ibranch_in,$nassured,$dclaim,$daccident,$nchi_full;
			if(SQLCODE == SQLNOTFOUND) break;

			printf("S1 iclaim = %s \n ",iclaim);
			printf("S1 ibranch_in = %s \n",ibranch_in);
			printf("S1 nassured = %s \n",nassured);

			sprintf_s(stmt_iins,256,"select iins_type from %s:app_ins_type where iclaim = '%s'",get_full_dbname(ibranch_in),iclaim);
			printf("S1 stmt_iins = %s \n",stmt_iins);
			$PREPARE pre1_1_iins FROM $stmt_iins;
			$DECLARE cur1_1_iins CURSOR for pre1_1_iins;
			$OPEN cur1_1_iins;
			strcpy(iins_type," ");
			while(1)
			{
				$FETCH cur1_1_iins INTO $temp_iins;
				if(SQLCODE==SQLNOTFOUND) break;
				strcat(iins_type , temp_iins);
				strcat(iins_type," ");
			}


         	/********************************** �I�O&�Ĥ@���w�����&�w�p�ߴڪ��B**********************************/
         	if (iclaim[5]!='C')
			{
				sprintf_s(stmt_dappraisal,256,"select min(dappraisal) from %s:app_ins_type_hist where iclaim='%s'",get_full_dbname(ibranch_in),iclaim);
				printf("S1 stmt_dappraisal = %s \n",stmt_dappraisal);
				$PREPARE pre1_1_dappraisal2 FROM $stmt_dappraisal;
				$EXECUTE pre1_1_dappraisal2 INTO $dappraisal;

				sprintf_s(stmt_money,256,"select sum(mins_app) from %s:app_ins_type_hist where iclaim='%s' and dappraisal = '%s'",get_full_dbname(ibranch_in),iclaim,dappraisal);
				printf("S1 stmt_money = %s \n",stmt_money);
				$PREPARE pre1_1_money2 from $stmt_money;
				$EXECUTE pre1_1_money2 into $money;

				temp_icnt_fkind = 0;
				sprintf_s(stmt_icnt_fkind,512,"select max(case when "
							        "(select count(*) "
	                        	                        "from insurance_type "
	                	                                "where iins_type =  x.iins_type "
	            	                                 	"and fins_grp  =  '2' "
	             	                                	"and fkind <> '3') > 0 then 4 "
	               	                        	"when "
	               	                        	"(select count(*) "
	              	                          	"from insurance_type "
	               	                          	"where iins_type =  x.iins_type "
	                	                        	  "and fkind = '3')  > 0 then 3 "
	                 	                     	 "when "
	                  	                        	  "(select count(*) "
	                  	                           	"from insurance_type "
	                  	                            	"where iins_type =  x.iins_type "
	                  	                            	"and fkind = '2')  > 0 then 2  "
	                    	                   	"else 1 END) "
	                 	       	"from %s:app_ins_type x "
	                    	  		"where x.iclaim = '%s'",get_full_dbname(ibranch_in),iclaim);
				printf("S1 stmt_icnt_fkind = %s \n",stmt_icnt_fkind);
	            		$PREPARE pre1_1_icnt_fkind FROM $stmt_icnt_fkind;
	            		$EXECUTE pre1_1_icnt_fkind INTO $temp_icnt_fkind;


				if (temp_icnt_fkind == 4)
				{
					strcpy(icnt_fkind,"���N(�t���)");
				}
				else if (temp_icnt_fkind == 3)
				{
					strcpy(icnt_fkind,"���N(���t���)");
				}
				else if (temp_icnt_fkind == 2)
				{
					strcpy(icnt_fkind,"���N(���t���)");
				}
				else
				{
					if((strncmp(trim(iins_type),"38",2)==0) ||
					   (strncmp(trim(iins_type),"39",2)==0) ||
					   (strncmp(trim(iins_type),"238",3)==0))
					{
						strcpy(icnt_fkind,"��L");
					}
					else
					{
						strcpy(icnt_fkind,"��W����");
					}
 				}
      		}
			else
			{

				sprintf_s(stmt_dappraisal,256,"select min(dappraisal) from %s:ca_app_victim_hist where iclaim='%s'",get_full_dbname(ibranch_in),iclaim);
				printf("S1 stmt_dappraisal = %s \n",stmt_dappraisal);
				$PREPARE pre1_1_dappraisal1 FROM $stmt_dappraisal;
				$EXECUTE pre1_1_dappraisal1 INTO $dappraisal;

				sprintf_s(stmt_money,256,"select sum(mapp_cover) from %s:ca_app_victim_hist where iclaim='%s' and dappraisal = '%s'",get_full_dbname(ibranch_in),iclaim,dappraisal);
				printf("S1 stmt_money = %s \n",stmt_money);
				$PREPARE pre_1_1_money1 from $stmt_money;
				$EXECUTE pre_1_1_money1 into $money;
      		    		strcpy(icnt_fkind,"�j��");
			}

			sprintf_s(stmt_facoption,512,"select CASE a.facoption WHEN '1' THEN '��t' WHEN '2' THEN '�D��t' WHEN '3' THEN '���i�t' ELSE '' END facoption, "
										 "       nvl(b.iquota,'') AS iquota, nvl(c.iroute,'') AS iroute, nvl(d.nroute,'') AS nroute "
										 "  from %s:appraisal a, %s:ori_ply_relation b, %s:policy c, cm_route d "
										 " where a.iclaim = '%s' "
										 "   and a.ipolicy = b.ipolicy "
										 "   and a.ipolicy = c.ipolicy "
										 "   and c.iroute = d.iroute ", get_full_dbname(ibranch_in), get_full_dbname(ibranch_in), get_full_dbname(ibranch_in), iclaim);
			printf("S1 stmt_facoption = %s \n",stmt_facoption);
			$PREPARE pre1_1_facoption1 FROM $stmt_facoption;
			$EXECUTE pre1_1_facoption1 INTO $facoption, $iquota, $iroute, $nroute;

			strcpy(iquota_0,substring(iquota,1,4));
			strcat(iquota_0,"00");

			$SELECT nbranch
			   INTO $nquota
			   FROM sa_branch_type
			  WHERE ibranch = $iquota_0; 
			if(SQLCODE == SQLNOTFOUND){
				strcpy(nquota," ");
			}

			printf("icnt_fkind=%s - iclaim=%s - nchi_full=%s\n",icnt_fkind,iclaim,nchi_full);
			printf("iofficer=%s - nname=%s - nbranch=%s\n",iofficer,nname,nbranch);
			printf("dappraisal=%s - nassured=%s - dclaim=%s\n",dappraisal,nassured,dclaim);
			printf("daccident=%s - iins_type=%s - money=%s\n",daccident,iins_type,money);
			printf("\n");

		  	$char ttempiclaim[15];
			$SELECT iclaim INTO $ttempiclaim FROM temp1 WHERE iclaim = $iclaim;
			printf("ttempiclaim = %s \n",ttempiclaim);

			if(SQLCODE == SQLNOTFOUND)
			{
				$INSERT INTO temp1(icnt_fkind,iclaim,iquota,nquota,iroute,nroute,nchi_full,iofficer,nname,nbranch,dappraisal,nassured,dclaim,daccident,iins_type,money,facoption)
		       			VALUES($icnt_fkind,$iclaim,$iquota,$nquota,$iroute,$nroute,$nchi_full,$iofficer,$nname,$nbranch,$dappraisal,$nassured,$dclaim,$daccident,$iins_type,$money,$facoption);
			}
		}
	}

	$CLOSE cur_pre1_1_1;
        $FREE cur_pre1_1_1;

        return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

/*------------------------���ץ��------------------------*/
long car845_prepare_data2()
{
	$char stmt_bedata[1024],stmt1[1024],stmt2[1024],stmt3[1024],stmt_icnt_fkind[512],stmt_iins[256],stmt_nchi_full[256],stmt_dappraisal[256],stmt_money[256],stmt_user_choose[256],stmt_facoption[512];
	$int temp_icnt_fkind;
	$char full_dbname[20];
	$char temp_iins[5];

	printf("-------------------------------------���ץ��----------------------------------------------------\n");
	$WHENEVER SQLERROR goto errexit;

	if (db_select(DBName) == FALSE)
   	{
      		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
     		return FAIL;
   	}


	if(strcmp(flag,"1")==0)
	{
		if(strcmp(user_choose_branch,"*")==0)
		{
			sprintf_s(stmt_user_choose,256," ");
		}
		else
		{
			sprintf_s(stmt_user_choose,256,
				"AND e.iupcomp='%s' "
				,user_choose_branch);
		}
	}

	else
	{
		sprintf_s(stmt_user_choose,256,
			"AND replace(a.iclaim1[1,2],'A',decode(a.iclaim1[1],'0','0','4','0','7','0',a.iclaim1[1])) = '%s' "
			,user_choose_branch);
	}


	sprintf_s(stmt1,1024,
		"SELECT UNIQUE c.iofficer,c.nname,d.nbranch "
		"FROM claim_app_main a ,officer c,sa_branch_type d ,branch e , ca_clm_process f "
		"WHERE a.ddecide >= '%s' and a.ddecide <= '%s' "
		"AND a.iclaim1 = f.iclaim "
		"AND f.adjustment = c.iofficer "
		"AND c.iquota=d.ibranch "
		"AND e.ibranch=replace(a.iclaim1[1,2],'A',decode(a.iclaim1[1],'0','0','4','0','7','0',a.iclaim1[1])) "
		"%s "
		,ddecide_begin,ddecide_end,stmt_user_choose);

	$PREPARE pre2_1_1 FROM $stmt1;
        $DECLARE cur_pre2_1_1 CURSOR for pre2_1_1;
       	$OPEN cur_pre2_1_1;


	while(1)
    {
		$FETCH cur_pre2_1_1 INTO $iofficer,$nname,$nbranch;
		if(SQLCODE == SQLNOTFOUND) break;

		printf("S2 iofficer = %s \n ",iofficer);


		sprintf_s(stmt_bedata,1024,
		"SELECT a.iclaim1,b.ibranch_in,b.nassured,b.dclaim,b.daccident,a.ddecide,c.nchi_full "
		"FROM claim_app_main a ,ca_clm_process b ,branch c "
		"WHERE a.ddecide >= '%s' and a.ddecide <= '%s' "
		"AND a.iclaim1=b.iclaim "
		"AND b.adjustment = '%s' "
		"AND c.ibranch=replace(a.iclaim1[1,2],'A',decode(a.iclaim1[1],'0','0','4','0','7','0',a.iclaim1[1])) "
		,ddecide_begin,ddecide_end,iofficer);

		printf("S2 stmt_bedata = %s \n ",stmt_bedata);


		$PREPARE Data_2 FROM $stmt_bedata;
		$DECLARE cur_BData_2 CURSOR for Data_2;
		$OPEN  cur_BData_2;

		while(1)
   		{

   			$FETCH cur_BData_2 INTO $iclaim,$ibranch_in,$nassured,$dclaim,$daccident,$ddecide,$nchi_full;
   			if(SQLCODE==SQLNOTFOUND) break;


   			printf("S2 iclaim = %s \n ",iclaim);
			printf("S2 ibranch_in = %s \n",ibranch_in);
			printf("S2 nassured = %s \n",nassured);
   			printf("S2 nchi_full = %s \n",nchi_full);

   			sprintf_s(stmt_iins,256,"select iins_type from %s:app_ins_type where iclaim = '%s'",get_full_dbname(ibranch_in),iclaim);
			$PREPARE pre2_1_iins FROM $stmt_iins;
			$DECLARE cur2_1_iins CURSOR for pre2_1_iins;
			$OPEN cur2_1_iins;
			strcpy(iins_type," ");

			while(1)
			{
				$FETCH cur2_1_iins INTO $temp_iins;
				if(SQLCODE==SQLNOTFOUND) break;
				strcat(iins_type , temp_iins);
				strcat(iins_type," ");
			}

			/********************************** �I�O&�Ĥ@���w�����&�w�p�ߴڪ��B **********************************/
			if (iclaim[5]!='C')
			{

				sprintf_s(stmt_dappraisal,256,"select min(dappraisal) from %s:app_ins_type_hist where iclaim='%s'",get_full_dbname(ibranch_in),iclaim);
				$PREPARE pre2_1_dappraisal2 FROM $stmt_dappraisal;
				$EXECUTE pre2_1_dappraisal2 INTO $dappraisal;

				sprintf_s(stmt_money,256,"select sum(mins_app) from %s:app_ins_type_hist where iclaim='%s' and dappraisal = '%s'",get_full_dbname(ibranch_in),iclaim,dappraisal);
				$PREPARE pre2_1_money2 from $stmt_money;
				$EXECUTE pre2_1_money2 into $money;

				temp_icnt_fkind = 0;
				sprintf_s(stmt_icnt_fkind,512,"select max(case when "
						     "(select count(*) "
	                                             "from insurance_type "
	                                             "where iins_type =  x.iins_type "
	                                             "and fins_grp  =  '2' "
	                                             "and fkind <> '3') > 0 then 4 "
	                                       "when "
	                                       "(select count(*) "
	                                        "from insurance_type "
	                                         "where iins_type =  x.iins_type "
	                                          "and fkind = '3')  > 0 then 3 "
	                                       "when "
	                                            "(select count(*) "
	                                             "from insurance_type "
	                                              "where iins_type =  x.iins_type "
	                                              "and fkind = '2')  > 0 then 2  "
	                                       "else 1 END) "
	                        "from %s:app_ins_type x "
	                      	"where x.iclaim = '%s'",get_full_dbname(ibranch_in),iclaim);


				$PREPARE pre2_1_icnt_fkind FROM $stmt_icnt_fkind;
				$EXECUTE pre2_1_icnt_fkind INTO $temp_icnt_fkind;


				if (temp_icnt_fkind == 4)
				{
					strcpy(icnt_fkind,"���N(�t���)");
				}
				else if (temp_icnt_fkind == 3)
				{
					strcpy(icnt_fkind,"���N(���t���)");
				}
				else if (temp_icnt_fkind == 2)
				{
					strcpy(icnt_fkind,"���N(���t���)");
				}
				else
				{
					if((strncmp(trim(iins_type),"38",2)==0) ||
					   (strncmp(trim(iins_type),"39",2)==0) ||
					   (strncmp(trim(iins_type),"238",3)==0) )
					{
						strcpy(icnt_fkind,"��L");
					}
					else
					{
						strcpy(icnt_fkind,"��W����");
					}
 				}
      		}
			else
			{
				sprintf_s(stmt_dappraisal,256,"select min(dappraisal) from %s:ca_app_victim_hist where iclaim='%s'",get_full_dbname(ibranch_in),iclaim);
				$PREPARE pre2_1_dappraisal1 FROM $stmt_dappraisal;
				$EXECUTE pre2_1_dappraisal1 INTO $dappraisal;

				sprintf_s(stmt_money,256,"select sum(mapp_cover) from %s:ca_app_victim_hist where iclaim='%s' and dappraisal = '%s'",get_full_dbname(ibranch_in),iclaim,dappraisal);
				$PREPARE pre2_1_money1 from $stmt_money;
				$EXECUTE pre2_1_money1 into $money;

				strcpy(icnt_fkind,"�j��");
			}

			sprintf_s(stmt_facoption,512,"select CASE a.facoption WHEN '1' THEN '��t' WHEN '2' THEN '�D��t' WHEN '3' THEN '���i�t' ELSE '' END facoption, "
										 "       nvl(b.iquota,'') AS iquota, nvl(c.iroute,'') AS iroute, nvl(d.nroute,'') AS nroute "
										 "  from %s:appraisal a, %s:ori_ply_relation b, %s:policy c, cm_route d "
										 " where a.iclaim = '%s' "
										 "   and a.ipolicy = b.ipolicy "
										 "   and a.ipolicy = c.ipolicy "
										 "   and c.iroute = d.iroute ", get_full_dbname(ibranch_in), get_full_dbname(ibranch_in), get_full_dbname(ibranch_in), iclaim);
			$PREPARE pre2_1_facoption1 FROM $stmt_facoption;
			$EXECUTE pre2_1_facoption1 INTO $facoption, $iquota, $iroute, $nroute;

			strcpy(iquota_0,substring(iquota,1,4));
			strcat(iquota_0,"00");

			$SELECT nbranch
			   INTO $nquota
			   FROM sa_branch_type
			  WHERE ibranch = $iquota_0; 
			if(SQLCODE == SQLNOTFOUND){
				strcpy(nquota," ");
			}

			printf("icnt_fkind=%s - iclaim=%s - nchi_full=%s\n",icnt_fkind,iclaim,nchi_full);
			printf("iofficer=%s - nname=%s - nbranch=%s\n",iofficer,nname,nbranch);
			printf("dappraisal=%s - nassured=%s - dclaim=%s\n",dappraisal,nassured,dclaim);
			printf("daccident=%s - iins_type=%s - money=%s\n",daccident,iins_type,money);
			printf("\n");

			$char ttempiclaim[15];
			$SELECT iclaim INTO $ttempiclaim FROM temp2 WHERE iclaim = $iclaim;
			printf("ttempiclaim = %s \n",ttempiclaim);

			if(SQLCODE == SQLNOTFOUND)
			{
				$INSERT INTO temp2(icnt_fkind,iclaim,iquota,nquota,iroute,nroute,nchi_full,iofficer,nname,nbranch,dappraisal,nassured,dclaim,daccident,ddecide,iins_type,money,facoption)
			      		VALUES($icnt_fkind,$iclaim,$iquota,$nquota,$iroute,$nroute,$nchi_full,$iofficer,$nname,$nbranch,$dappraisal,$nassured,$dclaim,$daccident,$ddecide,$iins_type,$money,$facoption);
			}
   		}
	}

	$CLOSE cur_pre2_1_1;
	$FREE cur_pre2_1_1;

	return M_CM_OK;


errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}


/*------------------------���M���------------------------*/
long car845_prepare_data3()
{
	printf("-------------------------------------���M���----------------------------------------------------\n");
	$char stmt_bedata[1024],stmt1[2056],stmt2[1024],stmt3[1024],stmt_icnt_fkind[512],stmt_iins[256],stmt_nchi_full[256],stmt_dappraisal[256],stmt_money[256],stmt_user_choose[256],stmt_facoption[512];
	$int temp_icnt_fkind;
	$char full_dbname[20];
	$char temp_iins[5];

	int count=0;

	$WHENEVER SQLERROR goto errexit;


	if (db_select(DBName) == FALSE)
   	{
      		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
     		return FAIL;
   	}


	if(strcmp(flag,"1")==0)
	{
		if(strcmp(user_choose_branch,"*")==0)
		{
			sprintf_s(stmt_user_choose,256," ");
		}
		else
		{
			sprintf_s(stmt_user_choose,256,
				"AND e.iupcomp='%s' "
				,user_choose_branch);
		}
	}

	else
	{
		sprintf_s(stmt_user_choose,256,
			"AND replace(a.iclaim1[1,2],'A',decode(a.iclaim1[1],'0','0','4','0','7','0',a.iclaim1[1])) = '%s' "
			,user_choose_branch);
	}

	printf("stmt_user_choose=%s\n",stmt_user_choose);


	sprintf_s(stmt1,2056,
		"SELECT UNIQUE c.iofficer,c.nname,d.nbranch "
		"FROM claim_app_main a ,officer c,sa_branch_type d ,branch e , ca_clm_process f "
		"WHERE a.dclaim <='%s' "
		"AND a.iclaim1 = f.iclaim "
		"AND (a.ddecide is null OR a.ddecide>'%s') "
		"AND f.adjustment = c.iofficer "
		"AND c.iquota=d.ibranch "
		"AND e.ibranch=replace(a.iclaim1[1,2],'A',decode(a.iclaim1[1],'0','0','4','0','7','0',a.iclaim1[1])) "
		"%s "
		,dundecide,dundecide,stmt_user_choose);

	printf("S3 stmt1 = %s \n ",stmt1);

	$PREPARE pre3_1_1 FROM $stmt1;
        $DECLARE cur_pre3_1_1 CURSOR for pre3_1_1;
       	$OPEN cur_pre3_1_1;


	while(1)
	{

		$FETCH cur_pre3_1_1 INTO $iofficer,$nname,$nbranch;
		if(SQLCODE == SQLNOTFOUND) break;

		printf("S3 iofficer = %s \n",iofficer);

		sprintf_s(stmt_bedata,1024,
		"SELECT a.iclaim1, "
		"b.ibranch_in,b.nassured,b.dclaim,b.daccident,c.nchi_full "
		"FROM claim_app_main a ,ca_clm_process b ,branch c "
		"WHERE a.dclaim <='%s' "
		"AND(a.ddecide is null OR a.ddecide>'%s') "
		"AND a.iclaim1=b.iclaim "
		"AND c.ibranch=replace(a.iclaim1[1,2],'A',decode(a.iclaim1[1],'0','0','4','0','7','0',a.iclaim1[1])) "
		"AND b.adjustment = '%s' ",dundecide,dundecide,iofficer);

	printf("S3 stmt_bedata = %s \n ",stmt_bedata);

		$PREPARE Data_3 FROM $stmt_bedata;
		$DECLARE cur_BData_3 CURSOR for Data_3;
		$OPEN  cur_BData_3;

		while(1)
		{
			$FETCH cur_BData_3 INTO $iclaim,$ibranch_in,$nassured,$dclaim,$daccident,$nchi_full;
			if(SQLCODE == SQLNOTFOUND) break;

			printf("S1 iclaim = %s \n ",iclaim);
			printf("S1 ibranch_in = %s \n",ibranch_in);
			printf("S1 nassured = %s \n",nassured);


			sprintf_s(stmt_iins,256,"select iins_type from %s:app_ins_type where iclaim = '%s'",get_full_dbname(ibranch_in),iclaim);
			$PREPARE pre3_1_iins FROM $stmt_iins;
			$DECLARE cur3_1_iins CURSOR for pre3_1_iins;
			$OPEN cur3_1_iins;
			strcpy(iins_type," ");

			while(1)
			{
				$FETCH cur3_1_iins INTO $temp_iins;
				if(SQLCODE==SQLNOTFOUND) break;
				strcat(iins_type , temp_iins);
				strcat(iins_type," ");
			}

			/********************************** �I�O&�Ĥ@���w�����&�w�p�ߴڪ��B **********************************/
			if (iclaim[5]!='C')
			{

				sprintf_s(stmt_dappraisal,256,"select min(dappraisal) from %s:app_ins_type_hist where iclaim='%s'",get_full_dbname(ibranch_in),iclaim);
				$PREPARE pre3_1_dappraisal2 FROM $stmt_dappraisal;
				$EXECUTE pre3_1_dappraisal2 INTO $dappraisal;

				sprintf_s(stmt_money,256,"select sum(mins_app) from %s:app_ins_type_hist where iclaim='%s' and dappraisal = '%s'",get_full_dbname(ibranch_in),iclaim,dappraisal);
				$PREPARE pre3_1_money2 from $stmt_money;
				$EXECUTE pre3_1_money2 into $money;

				temp_icnt_fkind = 0;
				sprintf_s(stmt_icnt_fkind,512,"select max(case when "
							 "(select count(*) "
												 "from insurance_type "
												 "where iins_type =  x.iins_type "
												 "and fins_grp  =  '2' "
												 "and fkind <> '3') > 0 then 4 "
										   "when "
										   "(select count(*) "
											"from insurance_type "
											 "where iins_type =  x.iins_type "
											  "and fkind = '3')  > 0 then 3 "
										   "when "
												"(select count(*) "
												 "from insurance_type "
												  "where iins_type =  x.iins_type "
												  "and fkind = '2')  > 0 then 2  "
										   "else 1 END) "
							"from %s:app_ins_type x "
							"where x.iclaim = '%s'",get_full_dbname(ibranch_in),iclaim);


				$PREPARE pre3_1_icnt_fkind FROM $stmt_icnt_fkind;
				$EXECUTE pre3_1_icnt_fkind INTO $temp_icnt_fkind;


				if (temp_icnt_fkind == 4)
				{
					strcpy(icnt_fkind,"���N(�t���)");
				}
				else if (temp_icnt_fkind == 3)
				{
					strcpy(icnt_fkind,"���N(���t���)");
				}
				else if (temp_icnt_fkind == 2)
				{
					strcpy(icnt_fkind,"���N(���t���)");
				}
				else
				{
					if((strncmp(trim(iins_type),"38",2)==0) ||
					   (strncmp(trim(iins_type),"39",2)==0) ||
					   (strncmp(trim(iins_type),"238",3)==0))
					{
						strcpy(icnt_fkind,"��L");
					}
					else
					{
					strcpy(icnt_fkind,"��W����");
					}
				}
			}
			else
			{
				sprintf_s(stmt_dappraisal,256,"select min(dappraisal) from %s:ca_app_victim_hist where iclaim='%s'",get_full_dbname(ibranch_in),iclaim);
				$PREPARE pre3_1_dappraisal1 FROM $stmt_dappraisal;
				$EXECUTE pre3_1_dappraisal1 INTO $dappraisal;

				sprintf_s(stmt_money,256,"select sum(mapp_cover) from %s:ca_app_victim_hist where iclaim='%s' and dappraisal = '%s'",get_full_dbname(ibranch_in),iclaim,dappraisal);
				$PREPARE pre3_1_money1 from $stmt_money;
				$EXECUTE pre3_1_money1 into $money;

				strcpy(icnt_fkind,"�j��");
			}

			sprintf_s(stmt_facoption,512,"select CASE a.facoption WHEN '1' THEN '��t' WHEN '2' THEN '�D��t' WHEN '3' THEN '���i�t' ELSE '' END facoption, "
										 "       nvl(b.iquota,'') AS iquota, nvl(c.iroute,'') AS iroute, nvl(d.nroute,'') AS nroute "
										 "  from %s:appraisal a, %s:ori_ply_relation b, %s:policy c, cm_route d "
										 " where a.iclaim = '%s' "
										 "   and a.ipolicy = b.ipolicy "
										 "   and a.ipolicy = c.ipolicy "
										 "   and c.iroute = d.iroute ", get_full_dbname(ibranch_in), get_full_dbname(ibranch_in), get_full_dbname(ibranch_in), iclaim);
			$PREPARE pre3_1_facoption1 FROM $stmt_facoption;
			$EXECUTE pre3_1_facoption1 INTO $facoption, $iquota, $iroute, $nroute;

			strcpy(iquota_0,substring(iquota,1,4));
			strcat(iquota_0,"00");

			$SELECT nbranch
			   INTO $nquota
			   FROM sa_branch_type
			  WHERE ibranch = $iquota_0; 
			if(SQLCODE == SQLNOTFOUND){
				strcpy(nquota," ");
			}

			printf("icnt_fkind=%s - iclaim=%s - nchi_full=%s\n",icnt_fkind,iclaim,nchi_full);
			printf("iofficer=%s - nname=%s - nbranch=%s\n",iofficer,nname,nbranch);
			printf("dappraisal=%s - nassured=%s - dclaim=%s\n",dappraisal,nassured,dclaim);
			printf("daccident=%s - iins_type=%s - money=%s\n",daccident,iins_type,money);
			printf("\n");

			$char ttempiclaim[15];
			$SELECT iclaim INTO $ttempiclaim FROM temp3 WHERE iclaim = $iclaim;
			printf("ttempiclaim = %s \n",ttempiclaim);

			if(SQLCODE == SQLNOTFOUND)
			{
				$INSERT INTO temp3(icnt_fkind,iclaim,iquota,nquota,iroute,nroute,nchi_full,iofficer,nname,nbranch,dappraisal,nassured,dclaim,daccident,iins_type,money,facoption)
					VALUES($icnt_fkind,$iclaim,$iquota,$nquota,$iroute,$nroute,$nchi_full,$iofficer,$nname,$nbranch,$dappraisal,$nassured,$dclaim,$daccident,$iins_type,$money,$facoption);
			}

		}

	}

	$CLOSE cur_pre3_1_1;
	$FREE cur_pre3_1_1;

	return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}



long car845_build()
{
   /*printf("build \n");
   $char t1[20],t2[20],t3[40],t4[20],t5[20],t6[40],t7[20];

   $declare cur_t cursor for select * from temp1;
   $open cur_t;

   while(1)
   {
   	$fetch cur_t into $t1,$t2,$t3,$t4,$t5,$t6,$t7;

   	printf("%s %s %s\n",t2,t5,t7);

   	if(SQLCODE == SQLNOTFOUND) break;
   }

   $close cur_t;
   $free cur_t;*/

   int rc;
   $char    sfilename[81],stitle[2048],stmt[2048];

    $WHENEVER SQLERROR GOTO errexit;


    if ((strcmp(dclaim_begin," ")!=0) && (strcmp(dclaim_end ," ")!=0))
    {
    	printf("---------------------------------------------------build 1 ---------------------------------\n");
    	strcpy(sfilename,"���z��Ʃ��Ӫ�[CAR845]");

    	strcpy(stitle,"\t�{���N��:CAR845\t���z��Ʃ��Ӫ�\t�L����:");
    	strcat(stitle,cm_get_sysd());
    	strcat(stitle,"\n");

    	strcat(stitle,"\t�I�O\t�߮׸��X\t�~�Z���N��\t�~�Z���W��\t�q���O�N��\t�q���O�W��\t�߮ר��z���\t�z�ߤH���m�W\t�z�ߤH�����\t�Ĥ@���w���ɶ�\t�Q�O�I�H\t���z���\t�X�I���\t�I��\t�w���ߴ�\t���׼t\t");


    	strcpy(stmt,"select icnt_fkind,iclaim,iquota,nquota,iroute,nroute,nchi_full,nname,nbranch,dappraisal,nassured,dclaim,daccident,iins_type,money,facoption from temp1;");
    	if(Build_Count == 1)
    	{
    		printf("test 1_1 \n");
    		rc = unload_file(outputf,"",sfilename,stitle,stmt);
    	}
    	else
    	{
    		printf("test 1_2 \n");
    		rc = unload_file(outputf,"A",sfilename,stitle,stmt);
    	}

  	  printf("rc = %d \n",rc);

    	if (rc != SUCCESS)
    	{
        	sprintf_s(msgbuf,128," %s �ɮ׵L�k���� ",sfilename);
        	EWRITE(userid, rc , msgbuf);
        	return rc;
    	}


    }


    if((strcmp(ddecide_begin," ")!=0) && (strcmp(ddecide_end," ")!=0))
    {

    	printf("---------------------------------------------------build 2 ---------------------------------\n");
    	strcpy(sfilename,"���ץ�Ʃ��Ӫ�[CAR845]");

    	strcpy(stitle,"\t�{���N��:CAR845\t���ץ�Ʃ��Ӫ�\t�L����:");
    	strcat(stitle,cm_get_sysd());
    	strcat(stitle,"\n");

     	strcat(stitle,"\t�I�O\t�߮׸��X\t�~�Z���N��\t�~�Z���W��\t�q���O�N��\t�q���O�W��\t�߮ר��z���\t�z�ߤH���m�W\t�z�ߤH�����\t�Ĥ@���w���ɶ�\t�Q�O�I�H\t���z���\t�X�I���\t�w�M���\t�I��\t�w���ߴ�\t���׼t\t");


    	strcpy(stmt,"select icnt_fkind,iclaim,iquota,nquota,iroute,nroute,nchi_full,nname,nbranch,dappraisal,nassured,dclaim,daccident,ddecide,iins_type,money,facoption from temp2");

	if(Build_Count==1)
	{
		printf("test 2_1 \n");
		rc = unload_file(outputf,"",sfilename,stitle,stmt);
	}
	else if(Build_Count==2 && Build_Start==2)
	{
		printf("test 2_2 \n");
		rc = unload_file(outputf,"A",sfilename,stitle,stmt);
	}
	else
	{
		printf("test 2_3 \n");
		rc = unload_file(outputf,"B",sfilename,stitle,stmt);
	}


    	printf("rc = %d \n",rc);

    	if (rc != SUCCESS)
    	{
    	    sprintf_s(msgbuf,128," %s �ɮ׵L�k���� ",sfilename);
    	    EWRITE(userid, rc , msgbuf);
     	   return rc;
   	 }
    }


    if(strcmp(dundecide," ")!=0)
    {

    	printf("---------------------------------------------------build 3 ---------------------------------\n");
    	 strcpy(sfilename,"���M��Ʃ��Ӫ�[CAR845]");

   	 strcpy(stitle,"\t�{���N��:CAR845\t���M��Ʃ��Ӫ�\t�L����:");
    	strcat(stitle,cm_get_sysd());
    	strcat(stitle,"\n");

    	strcat(stitle,"\t�I�O\t�߮׸��X\t�~�Z���N��\t�~�Z���W��\t�q���O�N��\t�q���O�W��\t�߮ר��z���\t�z�ߤH���m�W\t�z�ߤH�����\t�Ĥ@���w���ɶ�\t�Q�O�I�H\t���z���\t�X�I���\t�I��\t�w���ߴ�\t���׼t\t");


    	strcpy(stmt,"select icnt_fkind,iclaim,iquota,nquota,iroute,nroute,nchi_full,nname,nbranch,dappraisal,nassured,dclaim,daccident,iins_type,money,facoption from temp3");
    	printf("stmt=%s \n ",stmt);

    	if(Build_Count == 1)
    	{
    		printf("test 3_1 \n");
    		rc = unload_file(outputf,"",sfilename,stitle,stmt);
    	}
    	else if(Build_Count==2)
    	{
    		printf("test 3_2 \n");
    		rc = unload_file(outputf,"B",sfilename,stitle,stmt);
    	}
    	else
    	{
    		printf("test 3_3 \n");
    		rc = unload_file(outputf,"C",sfilename,stitle,stmt);
    	}


    	printf("rc = %d \n",rc);

    	if (rc != SUCCESS)
    	{
        	sprintf_s(msgbuf,128," %s �ɮ׵L�k���� ",sfilename);
        	EWRITE(userid, rc , msgbuf);
        	return rc;
    	}
    }





    return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;

}


long ca845_create_temp()
{
   $WHENEVER SQLERROR GOTO errexit;
   /* Create table tmp1 ���z�ץ� */
   $create temp table temp1 (
   	 icnt_fkind		char(20),
      	 iclaim 		char(20),
		 iquota			char(6),
		 nquota			char(40),
		 iroute			char(20),
		 nroute			char(40),
      	 nchi_full		char(40),
      	 iofficer 		char(13),
      	 nname 			char(10),
      	 nbranch		char(40),
      	 dappraisal		char(12),
      	 nassured 		char(20),
      	 dclaim			char(12),
      	 daccident		char(20),
      	 iins_type		char(20),
      	 money			int,
		 facoption		char(20)
   )with no log;
   /* Create table tmp2 ���׮ץ� */
    $create temp table temp2 (
   	  icnt_fkind		char(20),
      	 iclaim 		char(20),
		 iquota			char(6),
		 nquota			char(40),
		 iroute			char(20),
		 nroute			char(40),
      	 nchi_full		char(40),
      	 iofficer 		char(13),
      	 nname 			char(10),
      	 nbranch		char(40),
      	 dappraisal		char(12),
      	 nassured 		char(20),
      	 dclaim			char(12),
      	 daccident		char(20),
      	 ddecide		char(20),
      	 iins_type		char(20),
      	 money			int,
		 facoption		char(20)
   )with no log;
     /* Create table tmp3 ���M�ץ� */
    $create temp table temp3 (
   	 icnt_fkind		char(20),
      	 iclaim 		char(20),
		 iquota			char(6),
		 nquota			char(40),
		 iroute			char(20),
		 nroute			char(40),
      	 nchi_full		char(40),
      	 iofficer 		char(13),
      	 nname 			char(10),
      	 nbranch		char(40),
      	 dappraisal		char(12),
      	 nassured 		char(20),
      	 dclaim			char(12),
      	 daccident		char(20),
      	 iins_type		char(20),
      	 money			int,
		 facoption		char(20)
   )with no log;

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* ------------------------------------------------------------------------- */
/*------------------------���M���------------------------*/
long car845_prepare_data4()
{
    printf("------------- ���M���_�鵲�� ---------------------------------\n");
    $char stmt_bedata[1024],stmt1[2056],stmt2[1024],stmt3[1024],stmt_icnt_fkind[512],
          stmt_iins[256],stmt_nchi_full[256],stmt_dappraisal[256],stmt_money[256],
          stmt_user_choose[256],stmt_facoption[512];
    $int temp_icnt_fkind;
    $char full_dbname[20];
    $char temp_iins[5];

	int count=0;

	$WHENEVER SQLERROR goto errexit;


	if (db_select(DBName) == FALSE)
   	{
        EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
        return FAIL;
   	}

	if(strcmp(flag,"1")==0)
	{
		if(strcmp(user_choose_branch,"*")==0)
		{
			sprintf_s(stmt_user_choose,256," ");
		}
		else
		{
			sprintf_s(stmt_user_choose,256, "AND e.iupcomp='%s' " ,user_choose_branch);
		}
	}
	else
	{
		sprintf_s(stmt_user_choose,256,
			"AND replace(f.iclaim[1,2],'A',decode(f.iclaim[1],'0','0','4','0','7','0',f.iclaim[1])) = '%s' "
			,user_choose_branch);
	}

	printf("stmt_user_choose=%s\n",stmt_user_choose);

	sprintf_s(stmt1,2056,
		"SELECT UNIQUE c.iofficer,c.nname,d.nbranch "
		"FROM officer c,sa_branch_type d ,branch e , ca_clm_process f "
		"WHERE f.dclaim <='%s' "
		"AND f.fclaim_status < 501 "
		"AND f.fsystem = 'N' "
		"AND f.adjustment = c.iofficer "
		"AND c.iquota=d.ibranch "
		"AND e.ibranch=replace(f.iclaim[1,2],'A',decode(f.iclaim[1],'0','0','4','0','7','0',f.iclaim[1])) "
		"%s "
		,dundecide,stmt_user_choose);

	printf("S4 stmt1 = %s \n ",stmt1);

	$PREPARE pre4_1_1 FROM $stmt1;
        $DECLARE cur_pre4_1_1 CURSOR for pre4_1_1;
       	$OPEN cur_pre4_1_1;


	while(1)
    {

		$FETCH cur_pre4_1_1 INTO $iofficer,$nname,$nbranch;
		if(SQLCODE == SQLNOTFOUND) break;

		printf("S4 iofficer = %s \n",iofficer);

		sprintf_s(stmt_bedata,1024,
		"SELECT b.iclaim, "
		"b.ibranch_in,b.nassured,b.dclaim,b.daccident,c.nchi_full "
		"FROM ca_clm_process b ,branch c "
		"WHERE b.dclaim <='%s' "
		"AND b.fclaim_status < 501 "
		"AND b.fsystem = 'N' "
		"AND c.ibranch=replace(b.iclaim[1,2],'A',decode(b.iclaim[1],'0','0','4','0','7','0',b.iclaim[1])) "
		"AND b.adjustment = '%s' ",dundecide,iofficer);

		printf("S4 stmt_bedata = %s \n ",stmt_bedata);

        $PREPARE Data_4 FROM $stmt_bedata;
		$DECLARE cur_BData_4 CURSOR for Data_4;
		$OPEN  cur_BData_4;

		while(1)
		{
			$FETCH cur_BData_4 INTO $iclaim,$ibranch_in,$nassured,$dclaim,$daccident,$nchi_full;
			if(SQLCODE == SQLNOTFOUND) break;

      		printf("S4 iclaim = %s \n ",iclaim);
			printf("S4 ibranch_in = %s \n",ibranch_in);
			printf("S4 nassured = %s \n",nassured);


      		sprintf_s(stmt_iins,256,"select iins_type from %s:app_ins_type where iclaim = '%s'",get_full_dbname(ibranch_in),iclaim);
			$PREPARE pre4_1_iins FROM $stmt_iins;
			$DECLARE cur4_1_iins CURSOR for pre4_1_iins;
			$OPEN cur4_1_iins;
			strcpy(iins_type," ");

			while(1)
			{
				$FETCH cur4_1_iins INTO $temp_iins;
				if(SQLCODE==SQLNOTFOUND) break;
				strcat(iins_type , temp_iins);
				strcat(iins_type," ");
			}

			/********************************** �I�O&�Ĥ@���w�����&�w�p�ߴڪ��B **********************************/
			if (iclaim[5]!='C')
			{

				sprintf_s(stmt_dappraisal,256,"select min(dappraisal) from %s:app_ins_type_hist where iclaim='%s'",get_full_dbname(ibranch_in),iclaim);
				$PREPARE pre4_1_dappraisal2 FROM $stmt_dappraisal;
				$EXECUTE pre4_1_dappraisal2 INTO $dappraisal;

				sprintf_s(stmt_money,256,"select sum(mins_app) from %s:app_ins_type_hist where iclaim='%s' and dappraisal = '%s'",get_full_dbname(ibranch_in),iclaim,dappraisal);
				$PREPARE pre4_1_money2 from $stmt_money;
				$EXECUTE pre4_1_money2 into $money;

				temp_icnt_fkind = 0;
				sprintf_s(stmt_icnt_fkind,512,"select max(case when "
						     "(select count(*) "
	                                             "from insurance_type "
	                                             "where iins_type =  x.iins_type "
	                                             "and fins_grp  =  '2' "
	                                             "and fkind <> '3') > 0 then 4 "
	                                       "when "
	                                       "(select count(*) "
	                                        "from insurance_type "
	                                         "where iins_type =  x.iins_type "
	                                          "and fkind = '3')  > 0 then 3 "
	                                       "when "
	                                            "(select count(*) "
	                                             "from insurance_type "
	                                              "where iins_type =  x.iins_type "
	                                              "and fkind = '2')  > 0 then 2  "
	                                       "else 1 END) "
	                        "from %s:app_ins_type x "
	                      	"where x.iclaim = '%s'",get_full_dbname(ibranch_in),iclaim);


		            	$PREPARE pre4_1_icnt_fkind FROM $stmt_icnt_fkind;
		            	$EXECUTE pre4_1_icnt_fkind INTO $temp_icnt_fkind;


				if (temp_icnt_fkind == 4)
				{
					strcpy(icnt_fkind,"���N(�t���)");
				}
				else if (temp_icnt_fkind == 3)
				{
					strcpy(icnt_fkind,"���N(���t���)");
				}
				else if (temp_icnt_fkind == 2)
				{
					strcpy(icnt_fkind,"���N(���t���)");
				}
				else
				{

					if((strncmp(trim(iins_type),"38",2)==0) ||
					   (strncmp(trim(iins_type),"39",2)==0) ||
					   (strncmp(trim(iins_type),"238",3)==0))
					{
						strcpy(icnt_fkind,"��L");
					}
					else
					{
						strcpy(icnt_fkind,"��W����");
					}
 				}
      		}
			else
			{
				sprintf_s(stmt_dappraisal,256,"select min(dappraisal) from %s:ca_app_victim_hist where iclaim='%s'",get_full_dbname(ibranch_in),iclaim);
				$PREPARE pre4_1_dappraisal1 FROM $stmt_dappraisal;
				$EXECUTE pre4_1_dappraisal1 INTO $dappraisal;

				sprintf_s(stmt_money,256,"select sum(mapp_cover) from %s:ca_app_victim_hist where iclaim='%s' and dappraisal = '%s'",get_full_dbname(ibranch_in),iclaim,dappraisal);
				$PREPARE pre4_1_money1 from $stmt_money;
				$EXECUTE pre4_1_money1 into $money;

				strcpy(icnt_fkind,"�j��");
			}

			sprintf_s(stmt_facoption,512,"select CASE a.facoption WHEN '1' THEN '��t' WHEN '2' THEN '�D��t' WHEN '3' THEN '���i�t' ELSE '' END facoption, "
										 "       nvl(b.iquota,'') AS iquota, nvl(c.iroute,'') AS iroute, nvl(d.nroute,'') AS nroute "
										 "  from %s:appraisal a, %s:ori_ply_relation b, %s:policy c, cm_route d "
										 " where a.iclaim = '%s' "
										 "   and a.ipolicy = b.ipolicy "
										 "   and a.ipolicy = c.ipolicy "
										 "   and c.iroute = d.iroute ", get_full_dbname(ibranch_in), get_full_dbname(ibranch_in), get_full_dbname(ibranch_in), iclaim);
			$PREPARE pre3_1_facoption1 FROM $stmt_facoption;
			$EXECUTE pre3_1_facoption1 INTO $facoption, $iquota, $iroute, $nroute;

			strcpy(iquota_0,substring(iquota,1,4));
			strcat(iquota_0,"00");

			$SELECT nbranch
			   INTO $nquota
			   FROM sa_branch_type
			  WHERE ibranch = $iquota_0; 
			if(SQLCODE == SQLNOTFOUND){
				strcpy(nquota," ");
			}

			printf("icnt_fkind=%s - iclaim=%s - nchi_full=%s\n",icnt_fkind,iclaim,nchi_full);
			printf("iofficer=%s - nname=%s - nbranch=%s\n",iofficer,nname,nbranch);
			printf("dappraisal=%s - nassured=%s - dclaim=%s\n",dappraisal,nassured,dclaim);
			printf("daccident=%s - iins_type=%s - money=%s\n",daccident,iins_type,money);
			printf("\n");

			$char ttempiclaim[15];
			$SELECT iclaim INTO $ttempiclaim FROM temp3 WHERE iclaim = $iclaim;
			printf("ttempiclaim = %s \n",ttempiclaim);

			if(SQLCODE == SQLNOTFOUND)
			{
				$INSERT INTO temp3(icnt_fkind,iclaim,iquota,nquota,iroute,nroute,nchi_full,iofficer,nname,nbranch,dappraisal,nassured,dclaim,daccident,iins_type,money,facoption)
			      	VALUES($icnt_fkind,$iclaim,$iquota,$nquota,$iroute,$nroute,$nchi_full,$iofficer,$nname,$nbranch,$dappraisal,$nassured,$dclaim,$daccident,$iins_type,$money,$facoption);
			}
      	}
	}

	$CLOSE cur_pre4_1_1;
	$FREE cur_pre4_1_1;

	return M_CM_OK;


errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}