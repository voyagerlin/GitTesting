/*-------------------------------------------------------------------
 * Program: ca302aq01s.ec
 * Date   : 12/13/1994
 *-------------------------------------------------------------------*/

/* 100.06 ���T����
  �� �ШD�W��
  (1)��[4.�d�߫���]�קאּ[����Ÿ��]�w]�A�i0�j����X�i1�j��X[\r\n] �i2�j��X[\n]
  (2)��ƥ����[3.�O�I���O]�A�]���T/�����n���}�J�`�d�ߡA�G�����קאּ[�J�`���O]�A�䤤2=�T���A3=����
  (3)������Y�O���θ�ƥ���U�W�[1��[����Ÿ�]
  (4)������Y�O���θ�ƥ���U���վ��`���׬�65
  (5)[�k�H]��ƥ����[2.�P�Ӹ��X]�t�X�P�Ӵ��o�A�ѭ����(8)�קאּ(12)
  (6)[�k�H]��ƥ����[6.�ť�]�A�t�X�t�X�P�Ӹ��X�ק�A�ťժ��ץ�42��֬�38

  �� �^�гW��
  (1)������Y��[4.�d�߫���]�קאּ[����Ÿ��]�w]�A�i0�j����X�i1�j��X[\r\n] �i2�j��X[\n]
  (2)��[��������]��W�[[�J�`���O]�B[�s�v�I�[�O���O]
  (3)��ƥ���R��[�j��I�O�渹�X(X17)]�M[���N���I�O�渹�X(17)]
  (4)�󱱨���Y�θ�ƥ���ҼW�[[����Ÿ�]���
  (5)��ƥ���O�I�J�`��ƭ쥻�p�p����11�A����5���A�]���T�w�u�|�������I�M�d���I�A�ҥH�קאּ2���A�R���O�I�J�`��ƭ���3����33�ӪťաA��֤����n����ƶǿ�
  (6)������Y�O���θ�ƥ���U���վ��`���׬�103
  (7)[�k�H]��ƥ����[4.�P�Ӹ��X]�t�X�P�Ӵ��o�A�ѭ����(8)�קאּ(12)�C
*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "is_def.h"
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"
$include sqlca;
$include sqltypes;
#define FOUND                   sqlca.sqlcode!=SQLNOTFOUND
#define NOT_FOUND               sqlca.sqlcode==SQLNOTFOUND
#define DATENULL                0x80000000L


/*****************************************************************/

$int  iplyyear=0,iplymonth=0;
char plyyear[4];
char plymonth[3];
char flag[3];
char sfile[51];
int  iperflag=0;
int  rc;


int   rec_count, max_count,rec_count_1=0,label1=0;
$char DBName[5];
$char FormTp[3];
char  outputf0[50];
char  outputf[50];
char  outputf1[50];
char  outputf2[50];
$char  userid[11];
$char  BodyFile[21],TitleFile[21],BodyFmt[21],FormTp[3];
$char  TitleFmt[21],prtstr[10000];
$char  FormFile[N_FILE+1], OutFile[20];
$int   PgLine, Width;
char  getfile[50],txtfile[20];
FILE  *sfp,*fp;
static char  *bp;
static int   recLen=1024;
$char sData[31][121];
$char ipolicy[21], iassured[13], nassured[121], itag[CA_TAG_NUM],icar_kind[2],idrink_note[3];
$char fins_grp[2], fclass[3], fbef_class[3], sIpolicy[21], sp[2], lia_dmg_class[6];
$int  non_year,acc_count3,tmp_pacc;
$char sParam0[31],sParam1[31],sParam2[31];
$char sDply_begin[11],sDply_end[11];
$long lngDply_begin,lngDply_end,lngDexecute;
char  fGenMan,fGenCar;
$char sFilePath1[51],sFilePath2[51];
$char strApHome[31];
long  lngCount1=0,lngCount2=0;
char  tmpY[4],tmpM[3];
char  dmg_flag_p,lia_flag_p; /*�L��,�u�]�� ca_acc_next.o ���ѦҦ��~���ܼ� */


$date   dply_bgn;
$date   dExec;
$int    qdmg_acc;
$int    lia_class;
$char   fcar_class[2];

/*****************************************************************/
long car302a_build1();
long car302a_build2();
/*long car302a_readfile();*/
char *sformat_trade();
long ply_302_key();

main(argc,argv)
int argc;
char **argv;
{
    long src;
    $char tmp_FilePath1[51],tmp_FilePath2[51],subFile[16];
    FILE   *fpSrc,*fpDst;
    char  tmp_iassured[13],tmp_itag[CA_TAG_NUM],tmp_readstr[34],tmp_icar_kind[2];
    char  sTmp[200],sTmp1[20];

    strcpy(DBName,  isNULLstr(argv[1]));
    strcpy(userid,  isNULLstr(argv[2]));
    strcpy(flag,    isNULLstr(argv[3]));
    strcpy(sParam0, isNULLstr(argv[4]));
    strcpy(sParam1, isNULLstr(argv[5]));
    strcpy(sParam2, isNULLstr(argv[6]));
    strcpy(sfile   ,isNULLstr(argv[7]));
    strcpy(outputf, isNULLstr(argv[8]));

    printf("Trace -- flag    = [%s] \n",  flag);
    printf("Trace -- sParam0 = [%s] \n",  sParam0);

    printf("Trace -- sParam1 = [%s] \n",  sParam1);
    printf("Trace -- sParam2 = [%s] \n",  sParam2);
    printf("Trace -- sfile   = [%s] \n",  sfile);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
        return FAIL;
    }
    strcpy(sFilePath1," ");
    strcpy(sFilePath2," ");


    /*
    rc = IsNOTrade302Case("19","1701-WW","2","00098V9075543",tmpY);
    printf("Trace -- rc = [%ld] \n",  rc);
    printf("Trace -- tmpY = [%s] \n",  tmpY);
    */
    /*
    rc = IsNOTrade302Case("02"," ","2","52698V9025795");
    printf("Trace -- rc = [%ld] \n",  rc);
    rc = IsNOTrade302Case("10"," ","1","52698V9025795");
    rc = IsNOTrade302Case("10","1234","2","52698V9025795");
    printf("Trace -- rc = [%ld] \n",  rc);

    rc = IsNOTrade302Case("10","1234","2","00099V9004601");
    printf("Trace -- rc = [%ld] \n",  rc);
    */

    /*
    if (strncmp(sfile,"isqa17_1.txt",12) == 0)
        iperflag = 1;
    else if (strncmp(sfile,"isqa17_2.txt",12) == 0)
        iperflag = 2;
    else if (strncmp(sfile,"ca_trade_renew.txt",18) == 0);
    else if (strncmp(sfile,"ca_trade_diff.txt",17) == 0);
    else 
    {
        iperflag = 0;
        if( flag[0] == '2' )
        {
            EWRITE(userid, 100, "�ɮ׿�����~�A�q�H->isqa17_1.txt�A�q��->isqa17_2.txt");
            exit(1);
        }
    }
    */
    /*
    if (flag[0] == '1'){				    * �e���T�d���ɮפU�� *
        src = car302a_build1();
        if (src != M_CM_OK) goto errexit;
    }else if (flag[0] == '2'){			* ���T�^���ɮפW�� *
        src = car302a_readfile();
        if (src != M_CM_OK) goto errexit;
    }else if (flag[0] == '3'){			* ��O�j��Y�Ƹ�ƤU�� *
        src = car302a_build2();
        if (src != M_CM_OK) goto errexit;
    }else if (flag[0] == '4'){			* ��O�j��Y�Ʀ^���ɮ� *
        src = car302a_transfile();
        if (src != M_CM_OK) goto errexit;

    }else*/
    if (flag[0] == '5'){			/* �j���I��O�̷s�ż���J�G�O�O�d�ߤ�����O�j��Y�Ʀ^���ɮ� */
        src = car302a_renew();
        if (src != M_CM_OK) goto errexit;

    }else if (flag[0] == '6'){			/* ���T�P�ʲz���j����O�������J */
        src = car302a_diff();
        if (src != M_CM_OK) goto errexit;

    }else if (flag[0] == '7'){			/* ���N�I��O�d�����T�Y�� ( ���d�I�̷s�żơB�����I�[��O�I�� ) ��J */

  	/*---------------    ��  Init report  ��   ------------------------*/
	  batchinit();
	  max_count = 0;
	  $SELECT kPgNum_Line,nForm_File
	      INTO $PgLine,$FormFile
	      FROM Form
	     WHERE ksys_grp="CA" AND kpgmid = 3021;
	  strcpy(FormFile,rtrim(FormFile));
	  sprintf_s(OutFile,sizeof OutFile,"%s.tx",outputf);
	  rgu_init_report(FormFile,OutFile);
        /*---------------    ��   Init report ��    ------------------------*/

        /* �M�׸g�쪺�Ȧs�� add by sylvia 103.09.23 ----------------------------------*/
         $select unique iofficer_ori from ca_promote_officer into temp ca_promote_officer_A with no log;
        /* -------------------------------------------------------------------------- */


        /*******************           Step 1           *******************************/
        if (flag[1] == '1')
        {

	      fGenMan = sParam0[0]; /* �O�_���s�q�H���T�ШD��:  0:�_ ,1:�O */
	      fGenCar = sParam0[1]; /* �O�_���s�q�����T�ШD��:  0:�_ ,1:�O */

	      strcpy(sParam1,trim(sParam1));
	      strcpy(sParam2,trim(sParam2));


	      /* ---------------    �̫O�������^����ƨ��ഫ ---------------    */

	      if (sParam0[2] =='1')
	      {
		      lngDply_begin = cm_ymd_cdate(sParam1); /*  �^�����O�����_�l�� */
		      lngDply_end   = cm_ymd_cdate(sParam2); /*  �^�����O���������� */

		      printf("Trace -- lngDply_begin = [%ld] \n",  lngDply_begin);
		      printf("Trace -- lngDply_end   = [%ld] \n",  lngDply_end);

		      /* Step1_0:�^�����d���T�󪺸�ơA�é��ca_no_trade_302 */
		      src = GetNoTradeData(" ",lngDply_begin,lngDply_end," ",userid);
		      if (src != M_CM_OK) goto errexit;

		      /* Step1_1:���s����O��M����(�۵M�H��(��)�k�H)�A�i�ѤU�� */
		      /* �P��output sFilePath1,sFilePath2,sFile1,sFile2*/
		      src = car302a_Trade_302_Step1_1(tmp_FilePath1,tmp_FilePath2);
		      if (src != M_CM_OK) goto errexit;

                      /** 100.10.20 ���T�d���ɧ��client��"���T�妸�d�ߵ{��"�B�z **/


		      /* ---------------    �ϥβ{���M���r���ഫ ---------------    */

	      }
	      else if (sParam0[2] =='2')
	      {
	      	      /* ���o �M���r�� ���|*/
		      rc = getApHome(strApHome);
		      if (rc < 0) 
		      {
		          printf("read Config file error!!\n");
			  return M_CM_READ_CONFIG_ERR;
		      }
		      
		      if (fGenMan=='1')
		      {
                          sprintf_s(sFilePath1,sizeof sFilePath1,"%s/dat/car/%s",strApHome,sParam1);
                      }
                      
                      if (fGenCar=='1')
                      {
                          sprintf_s(sFilePath2,sizeof sFilePath2,"%s/dat/car/%s",strApHome,sParam2);
                      }
	      }

              /** 100.10.20 ���T�d���ɧ��client��"���T�妸�d�ߵ{��"�B�z **/
	      sprintf_s(sTmp,sizeof sTmp,"\n     ---------------------------------------------------------------------\n");
	      rgu_put_body_string(1, sTmp, 1);
	      rgu_put_body(1); max_count++;

	      sprintf_s(sTmp,sizeof sTmp," �� �H�W�ɮ׬ҥi�� cmn202 �U��");
	      rgu_put_body_string(1, sTmp, 1);
	      rgu_put_body(1); max_count++;
	  
	  }
	  /*******************        Step 2 �B Step 3       *******************************/
	  else if (flag[1] == '2' || flag[1] == '3')
	  {
      	      /* ���o���ŭp�⵲�G�ɸ��|*/
	      rc = getApHome(strApHome);
	      if (rc < 0) 
	      {
	          printf("read Config file error!!\n");
		  return M_CM_READ_CONFIG_ERR;
	      }
	      strcpy(sfile,trim(sfile));
	      sprintf_s(sFilePath1,sizeof sFilePath1,"%s/dat/car/%s",strApHome,sfile);

	      /* �N���ŭp�⵲�G����Jca_trade_302*/
	      lngCount1 = 0;
	      lngCount2 = 0;
	      src = car302a_Trade_302_Step2(sFilePath1,&lngCount1,&lngCount2);
	      if (src != M_CM_OK) goto errexit;


	      if (flag[1] == '2' )
	      {
	      	  strcpy(sParam0,trim(sParam0));
	      	  strcpy(sParam1,trim(sParam1));
	      	  if (sParam1[0]=='1'){
	      	  	  strcpy(sParam2,"�����I(�J�`)-�۵M�H");
	      	  }else if (sParam1[0]=='2'){
	      	  	  strcpy(sParam2,"�����I(�J�`)-�k  �H");
	      	  }else if (sParam1[0]=='3'){
	      	  	  strcpy(sParam2,"���d�I(�@��)-�۵M�H");
	      	  }else if (sParam1[0]=='4'){
	      	  	  strcpy(sParam2,"���d�I(�@��)-�k  �H");
	      	  }else if (sParam1[0]=='5'){
	      	  	  strcpy(sParam2,"���d�I(�p�{��)-�۵M�H");
	      	  }else if (sParam1[0]=='6'){
	      	  	  strcpy(sParam2,"���d�I(�p�{��)-�k  �H");
	      	  }

	      	  printf("Trace -- sParam0 = [%s] \n",  sParam0);
	      	  printf("Trace -- sParam1 = [%s] \n",  sParam1);
	      	  printf("Trace -- sParam2 = [%s] \n",  sParam2);
                  printf("403------------ \n");
		  sprintf_s(sTmp,sizeof sTmp,"\n �� %s�u���ŭp�⵲�G�ɡv( %s ) ��J�t�ΡA�w�����I\n", sParam2, sParam0);
                  printf("406--sTmp=[%s]max_count=[%d]---------- \n",sTmp,max_count);
                  
		  rgu_put_body_string(1, sTmp, 1);
		  rgu_put_body(1); max_count++;

		  sprintf_s(sTmp,sizeof sTmp,"�ס� �ɮ� %ld �� �A ��J�t�� %ld �� ",lngCount1, lngCount2);
		  printf("411--sTmp=[%s]---------- \n",sTmp);
		  rgu_put_body_string(1, sTmp, 1);
		  rgu_put_body(1); max_count++;

		  sprintf_s(sTmp,sizeof sTmp,"\n     ---------------------------------------------------------------------\n");
		  printf("416--sTmp=[%s]---------- \n",sTmp);
		  rgu_put_body_string(1, sTmp, 1);
		  rgu_put_body(1); max_count++;

                  sprintf_s(sTmp,sizeof sTmp,"�� �����z�I�нT�{��L�Ҧ��u���ŭp�⵲�G�ɡv�Ҥw��J�t�ΡI" );
                  printf("427--sTmp=[%s]---------- \n",sTmp);
		  rgu_put_body_string(1, sTmp, 1);
		  rgu_put_body(1); max_count++;


		  if ((lngCount1==lngCount2)&&(lngCount2 >0)) 
		  {
		      printf("433--sTmp=[%s]---------- \n",sTmp);
		      rc = ply_302_key(1, "car302a", "B", "1",userid);  /* ���ˮ����d "�wOK" */
		      printf("435--sTmp=[%s]---------- \n",sTmp);

		  }
		  else
		  {
		      printf("438--sTmp=[%s]---------- \n",sTmp);
 		      rc = ply_302_key(1, "car302a", "B", "0", userid);  /* ���ˮ����d "��OK" */
 		      printf("440--sTmp=[%s]---------- \n",sTmp);
		  }

	      }
	      else if (flag[1] == '3')
	      {
		  sprintf_s(sTmp,sizeof sTmp,"\n�� �����T�����J�t�ΡG\n");
		  rgu_put_body_string(1, sTmp, 1);
		  rgu_put_body(1); max_count++;

		  sprintf_s(sTmp,sizeof sTmp," �w�����A�@ %ld �� ", lngCount1);
		  rgu_put_body_string(1, sTmp, 1);
		  rgu_put_body(1); max_count++;
	      }


	  } 

          /*---------------     ��  finish_report   ��  ------------------------*/
	  rgu_finish_report();
	  FormTp[0] = '\0';
	  if(rc=(save_form_info(F_FREE,"CA",3021,userid,FormTp,max_count,outputf))<0)
	  {
	      printf("*** save_form_info() fail\n");
	      EWRITE(userid,rc,"save_form_info failed");
	      return rc;
	  }
	  /*---------------     ��  finish_report   ��  ------------------------*/

    }
    else if (flag[0] == '8')   /* �p��u���d�����T��v����O�椧�ߴګY��  */
    {
    	
        

  	/*---------------    ��  Init report  ��   ------------------------*/
	batchinit();
	max_count = 0;
	$SELECT kPgNum_Line,nForm_File
	    INTO $PgLine,$FormFile
	    FROM Form
	   WHERE ksys_grp="CA" AND kpgmid = 3021;
	strcpy(FormFile,rtrim(FormFile));
	sprintf_s(OutFile,sizeof OutFile,"%s.tx",outputf);
	rgu_init_report(FormFile,OutFile);
        /*---------------    ��   Init report ��    ------------------------*/

        strcpy(sParam1,trim(sParam1));
        strcpy(sParam2,trim(sParam2));

        lngDply_begin = cm_ymd_cdate(sParam1); /*  �^�����O�����_�l�� */
        lngDply_end   = cm_ymd_cdate(sParam2); /*  �^�����O���������� */
        rtoday(&lngDexecute);                  /*  ��O�J�p��           */


	sprintf_s(sTmp,sizeof sTmp,"\n�p��u���d�����T��v����O�椧�ߴګY�ơG\n");
	rgu_put_body_string(1, sTmp, 1);
	rgu_put_body(1); max_count++;

	strncpy(tmpY,sParam0,3);
	strncpy(tmpM,&sParam0[3],2);

	sprintf_s(sTmp,sizeof sTmp,"\n  �O�����G %s�~ %s��\n", tmpY,tmpM);
	rgu_put_body_string(1, sTmp, 1);
	rgu_put_body(1); max_count++;

        rc = cacu_no_trade_factor(" ",lngDply_begin,lngDply_end,lngDexecute,userid,&lngCount1);
	if (rc != M_CM_OK) goto errexit;

	if (lngCount1 > 0)
	{
	    sprintf_s(sTmp,sizeof sTmp," �w�����A�@  %ld  �� ", lngCount1);
	    rgu_put_body_string(1, sTmp, 1);
	    rgu_put_body(1); max_count++;
	    rc = ply_302_key(1, "car302a", "C", "1", userid);  /* ���ˮ����d "�wOK" */

        }
        else
        {
	    sprintf_s(sTmp,sizeof sTmp," �������A�@  %ld  �� ", lngCount1);
	    rgu_put_body_string(1, sTmp, 1);
	    rgu_put_body(1); max_count++;

	    sprintf_s(sTmp,sizeof sTmp,"\n    1. �нT�{�u�O�����~��v�O�_��J���T \n" );
	    rgu_put_body_string(1, sTmp, 1);
	    rgu_put_body(1); max_count++;

	    sprintf_s(sTmp,sizeof sTmp,"  2. �нT�{�O�_�w�����u���N�I��O�d�����T�Y�� ( ���d�I�̷s�żơB�����I�[��O�I�� ) ��J�v��Step1\n " );
	    rgu_put_body_string(1, sTmp, 1);
	    rgu_put_body(1); max_count++;

        }
        /* �]��Ƥ��R���H���������ǡA�B�P�t�Τ���L���A�G��b�J�p���Ѷi��R��
           �R��ca_trade_302, ca_no_trade_302 �����
           ca_trade_302     �Hdquery ���������ǡA��ƫO�d�@�~
           ca_no_trade_302  �Hdcreate���������ǡA��ƫO�d�@�~
        */
        /* �ץ�SQL��i���`�M�� modify by 061476 (1091112010_SC1) */
        
        printf("Deleting ... ca_trade_302 By dquery(��ƫO�d�@�~)\n");
        $DELETE FROM ca_trade_302
          WHERE dquery < date_add(to_char(today ,'%m/01/%Y' ) ,interval(-11) month TO month) ;

        printf("Deleting ... ca_no_trade_302 By dcreate(��ƫO�d�@�~)\n");
        $DELETE FROM ca_no_trade_302
          WHERE dcreate < date_add(to_char(today ,'%m/01/%Y' ) ,interval(-11) month TO month) ;

        /*---------------     ��  finish_report   ��  ------------------------*/
	rgu_finish_report();
	FormTp[0] = '\0';
	if(rc=(save_form_info(F_FREE,"CA",3021,userid,FormTp,max_count,outputf))<0)
	{
	    printf("*** save_form_info() fail\n");
	    EWRITE(userid,rc,"save_form_info failed");
	    return rc;
	}
	/*---------------     ��  finish_report   ��  ------------------------*/

    }else if (flag[0] == '9'){		  /* �j���I�~�ȱ����ˮ�(car159�]�w) */
        src = car302a_chk_car159();
        if (src != M_CM_OK)
            return src;
    }else if (strcmp(flag,"10") == 0){    /* ����~(car64�]�w) */
        src = car302a_chk_car644();
        if (src != M_CM_OK)
            return src;
    }else if (strcmp(flag,"11") == 0){    /* RBA�����I�ˮ� add by sylvia 106.08.11 (1060606002_C5) �W�[�F�d�����ˮ� modify by sylvia 106.09.11 (1060726001_C1) */
        src = car302a_chk_RBA();
        if (src != M_CM_OK)
            return src;
    }

    return M_CM_OK;

errexit:
    printf("------car302a_err: SQLCODE[%d]\n",SQLCODE);
    EWRITE(userid, SQLCODE,sqlca.sqlerrm);
    exit(1);
}

long car302a_build1()
{
$char sFull[30];
$char ibranch[3];
$char stmt[3000];
$char fassured[2];
FILE   *fp0,*fp1,*fp2;
$char  sApHome[31];
char  file0[51],file1[51],file2[51];
int rt;
char   sTmp[101];
$char  sTmp0[51],sTmp1[51],sTmp2[51];
$char  iengine[CA_ENGINE_NUM],icar_flag[2];
int    s,t,u;


   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT;

    batchinit();
    max_count = 0;
    s = t = u = 0;

    $SELECT kPgNum_Line,nForm_File
       INTO $PgLine,$FormFile
       FROM Form
      WHERE ksys_grp="CA" AND kpgmid = 3021;

    strcpy(FormFile,rtrim(FormFile));
    sprintf_s(OutFile,sizeof OutFile,"%s.tx",outputf);

    rgu_init_report(FormFile,OutFile);

   rt = getApHome(sApHome);
   if (rt < 0) {
        printf("read Config file error!!\n");
        return M_CM_READ_CONFIG_ERR;
   }

   sprintf_s(sTmp0,sizeof sTmp0,"ilicense_%d_%d.txt",atoi(plyyear),iplymonth);
   sprintf_s(file0,sizeof file0,"%s/rptftp/%s",sApHome,sTmp0);
   printf("file0[%s]\n",file0);
   fp0=fopen(file0,"w");

   sprintf_s(sTmp1,sizeof sTmp1,"itag_%d_%d.txt",atoi(plyyear),iplymonth);
   sprintf_s(file1,sizeof file1,"%s/rptftp/%s",sApHome,sTmp1);
   printf("file1[%s]\n",file1);
   fp1=fopen(file1,"w");

   sprintf_s(sTmp2,sizeof sTmp2,"notag_%d_%d.txt",atoi(plyyear),iplymonth);
   sprintf_s(file2,sizeof file2,"%s/rptftp/%s",sApHome,sTmp2);
   printf("file2[%s]\n",file2);
   fp2=fopen(file2,"w");

      $DECLARE sdb_cur CURSOR FOR
        SELECT branch
          FROM servertbl
         WHERE branch != 'S1'
         ORDER BY branch;

     $OPEN sdb_cur ;
     for(;;){
     $FETCH sdb_cur INTO $ibranch;
     if (SQLCODE == SQLNOTFOUND) break;

     strcpy(sFull,get_full_dbname(ibranch));

       sprintf_s(stmt,sizeof stmt,
        " SELECT UNIQUE b.itag,b.fassured,b.iassured,b.iengine,a.icar_flag,a.ipolicy  "
        "   FROM %s:ply_relation a,%s:policy b,%s:ply_ins_type c     "
        "  WHERE YEAR(a.dply_end) = %d                               "
        "    AND MONTH(a.dply_end) = %d                              "
        "    AND a.fcard_class = '2'                                 "
        "    AND NVL(a.inext_ply,' ') = ' '                          "
        "    AND c.fedr_status NOT IN ('1','2','3')                  "
        "    AND nvl(a.fedr_class,' ') != '1'                        "
        "    AND a.ipolicy = b.ipolicy                               "
        "    AND a.ipolicy = c.ipolicy ",sFull,sFull,sFull,iplyyear,iplymonth);

            printf("stmt[%s]\n",stmt);
        $PREPARE m1 FROM $stmt;
        $DECLARE m1_cur CURSOR FOR m1;
        $OPEN m1_cur;
        for(;;){
        $FETCH m1_cur INTO $itag,$fassured,$iassured,$iengine,$icar_flag,$ipolicy;
        if (SQLCODE == SQLNOTFOUND) break;

        printf("INTO ipolicy[%s],itag[%s],iassured[%s]\n",ipolicy,itag,iassured);
            if ((fassured[0] == '1') || (fassured[0] == '3') || (fassured[0] == '5'))
               {
                 if (strlen(trim(iassured)) != 0){
                     fprintf(fp0,"%s\n",rtrim(iassured));
                     s++;
                 }
               }
            else
               {
                 if (strlen(trim(itag)) != 0){
                     fprintf(fp1,"%s\n",rtrim(itag));
                     t++;
                 }
                 else{
                     /*
                     if (icar_flag[0] == '2'){
                     */
                     fprintf(fp2,"%s\n",rtrim(iengine));
                     u++;
                     /*
                     }
                     */
                 }
               }

        }
        $CLOSE m1_cur;
        $FREE  m1_cur;
     }
     $CLOSE sdb_cur;
     $FREE  sdb_cur;

     fclose(fp0);
     fclose(fp1);
     fclose(fp2);


   sprintf_s(sTmp,sizeof sTmp,"%d����q�H�ɮ� -> %s �U�� OK �@ %d �� ",atoi(plyyear),sTmp0,s);
   rgu_put_body_string(1, sTmp, 1);
   rgu_put_body(1); max_count++;

   rt = rptftpinsert(userid,"car302a",sTmp0);
   if (rt != 0){
        printf("rptftp error\n");
        goto errexit;
   }

   sprintf_s(sTmp,sizeof sTmp,"%d����q���ɮ� -> %s �U�� OK �@ %d �� ",atoi(plyyear),sTmp1,t);
   rgu_put_body_string(1, sTmp, 1);
   rgu_put_body(1); max_count++;

   rt = rptftpinsert(userid,"car302a",sTmp1);
   if (rt != 0){
        printf("rptftp error\n");
        goto errexit;
   }

   sprintf_s(sTmp,sizeof sTmp,"%d����L�P���ɮ� -> %s �U�� OK �@ %d �� ",atoi(plyyear),sTmp2,u);
   rgu_put_body_string(1, sTmp, 1);
   rgu_put_body(1); max_count++;

   rt = rptftpinsert(userid,"car302a",sTmp2);
   if (rt != 0){
        printf("rptftp error\n");
        goto errexit;
   }

   rgu_finish_report();

   FormTp[0] = '\0';

   if(rc=(save_form_info(F_FREE,"CA",3021,userid,FormTp,max_count,outputf))<0)
   {
      printf("*** save_form_info() fail\n");
      EWRITE(userid,rc,"save_form_info failed");
      return rc;
   }


  return M_CM_OK;
errexit:
    printf("------car302a_build1: SQLCODE[%d]\n",SQLCODE);
    EWRITE(userid, SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}


/*long car302a_readfile()
{
   long lamt, ltmp;
   char itmp[10], stmp[7];
   char syy[3], smm[3], sdd[3];
   $int count=0;
    int rtncode;
   $char b_dpaied_sql[11];
   char b_dpaied_fix[11];
   char sApHome[20];
   $char sTmp[1001];
    int  k,m;
   $char stmt[1024];
   int i;

   $WHENEVER SQLERROR GOTO errexit;

   if ( db_select(DBName) == False)
   return M_CM_DB_NOTOPEN;


   batchinit();
   max_count = 0;

   $SELECT kPgNum_Line,nForm_File
      INTO $PgLine,$FormFile
      FROM Form
     WHERE ksys_grp="CA" AND kpgmid = 3021;

   strcpy(FormFile,rtrim(FormFile));
   sprintf_s(OutFile,sizeof OutFile,"%s.tx",outputf);

   rgu_init_report(FormFile,OutFile);

   rtncode = getApHome(sApHome);
   if (rtncode < 0) {
        printf("read Config file error!!\n");
        return M_CM_READ_CONFIG_ERR;
   }
   sprintf_s(getfile,sizeof getfile, "%s/dat/car/%s", sApHome, sfile);

   printf("getfile[%s]\n",getfile);
   if ((fp=fopen(getfile,"rt"))==NULL) return FALSE;
   if ((bp=malloc(recLen))==NULL) {
        printf("System malloc failed  !\n");
        free(bp);
        return FAIL;
   }


   sprintf_s(stmt, sizeof stmt,
     " INSERT INTO trans_claim (ipolicy,fins_grp,iassured,nassured,   "
     "                          itag,fbef_class,fclass,non_year,acc_count3) "  
     "   VALUES (?,?,?,?,?,?,?,?,?) ");

       $PREPARE insid1 FROM $stmt;

   sprintf_s(stmt,sizeof stmt,
     " UPDATE trans_claim  "
     "    SET (ipolicy,fins_grp,iassured,nassured,    "
     "         itag,fbef_class,fclass,non_year,acc_count3) "
     "      = (?,?,?,?,?,?,?,?,?)  "
     "  WHERE fins_grp = ?  "
     "    AND iassured = ?  ");
     $PREPARE upiass FROM $stmt;

     sprintf_s(stmt,sizeof stmt,
     " UPDATE trans_claim  "
     "    SET (ipolicy,fins_grp,iassured,nassured,    "
     "         itag,fbef_class,fclass,non_year,acc_count3) "
     "      = (?,?,?,?,?,?,?,?,?)  "
     "  WHERE fins_grp = ?       "
     "    AND itag = ?  ");
     $PREPARE upitag FROM $stmt;

   while(fgets(bp,recLen,fp))
   {
      if (feof(fp)) break;

      printf("Bef Get Data\n");
      GetData(sTmp   , bp    , 1000);
      printf("Aft Get Data1000[%s]\n",sTmp);

          k = 0;
          m = 0;

      for(i=0;i<=30;i++)
          sData[i][0] = '\0';

      for(i=0;i<1000;i++)
      {
          if (sTmp[i] == '\0') break;
          if ((int)sTmp[i]>128)
          {
               i++;
               continue;
          }
          if (sTmp[i] == '|')
          {

             if (k == 0)
             {
                 memcpy(sData[m],sTmp,i-k);
             }
             else
             {
                 strncpy(sData[m],sTmp+k+1,i-k-1);
                 sData[m][i-k-1] = '\0';
             }

              printf("i[%d], k[%d]\n",i,k);
              printf("sData[%d]=[%s]\n",m,sData[m]);
              m++;
              k = i;
              if (m > 30) break;
          }
      }

         printf("iperflag = [%d]\n",iperflag);
         printf("sData[10] = [%s]\n",sData[10]);


     if (iperflag == 1){

         if (strncmp(sData[10],"01",2) == 0)
         {
             non_year = atoi(sData[11]);
             acc_count3 = atoi(sData[12]);
             strcpy(fins_grp,"1");
             strcpy(fbef_class," ");
             strcpy(fclass," ");
         }
         else if (strncmp(sData[10],"31",2) ==0)
         {
             non_year = atoi(sData[11]);
             acc_count3 = atoi(sData[12]);
             strcpy(fins_grp,"2");
             strcpy(fbef_class," ");
             strcpy(fclass," ");
         }
         else if (strncmp(sData[10],"21",2) == 0)
         {

             if (sData[11][0] == 'Y')
             {
                 non_year = 1;
             }
             else
             {
                 non_year = 0;
             }
             acc_count3 = atoi(sData[12]);
             strcpy(fins_grp,"3");
             strcpy(fbef_class,trim(sData[7]));
             strcpy(fclass,trim(sData[8]));
             strcpy(sData[6],trim(sData[5]));
         }
         else
         {
              continue;
         }

         strcpy(sp," ");
         $EXECUTE upiass
            USING $sData[6],$fins_grp,$sData[0],$sData[1],
                  $sp,$fbef_class,$fclass,$non_year,$acc_count3,$fins_grp,$sData[0];
          if (sqlca.sqlerrd[2] == 0)
          {
         $EXECUTE insid1
            USING $sData[6],$fins_grp,$sData[0],$sData[1],
                  $sp,$fbef_class,$fclass,$non_year,$acc_count3;
          }

     }else if (iperflag == 2){

         if (strncmp(sData[8],"01",2) == 0)
         {
             non_year = atoi(sData[9]);
             acc_count3 = atoi(sData[10]);
             strcpy(fins_grp,"1");
             strcpy(fbef_class," ");
             strcpy(fclass," ");
         }
         else if (strncmp(sData[8],"31",2) ==0)
         {
             non_year = atoi(sData[9]);
             acc_count3 = atoi(sData[10]);
             strcpy(fins_grp,"2");
             strcpy(fbef_class," ");
             strcpy(fclass," ");
         }
         else if (strncmp(sData[8],"21",2) == 0)
         {
             if (sData[9][0] == 'Y')
             {
                 non_year = 1;
             }
             else
             {
                 non_year = 0;
             }
             acc_count3 = atoi(sData[10]);
             strcpy(fins_grp,"3");
             strcpy(fbef_class,trim(sData[5]));
             strcpy(fclass,trim(sData[6]));
             strcpy(sData[4],trim(sData[3]));
         }
         else
         {
              continue;
         }

         $EXECUTE upitag
            USING $sData[4],$fins_grp,$sData[0],
                  $sData[1],$sData[2],$fbef_class,$fclass,$non_year,$acc_count3,
                  $fins_grp,$sData[2];
          if (sqlca.sqlerrd[2] == 0)
          {
         $EXECUTE insid1 USING $sData[4],$fins_grp,$sData[0],
                               $sData[1],$sData[2],$fbef_class,$fclass,$non_year,$acc_count3;
          }
     }else{
         printf("iperflag error [%d]\n",iperflag);
         goto errexit ;
     }

   }

   rgu_put_body_string(1,"�ɮפW�� OK",1);
   rgu_put_body(1); max_count++;

   rgu_finish_report();

   FormTp[0] = '\0';

   if(rc=(save_form_info(F_FREE,"CA",3021,userid,FormTp,max_count,outputf))<0)
   {
      printf("*** save_form_info() fail\n");
      EWRITE(userid,rc,"save_form_info failed");
      return rc;
   }

   fclose(fp);
   return M_CM_OK;

errexit:
   printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
   fclose(fp);
   return SQLCODE;
}*/


int GetData(data,offset,length)
char *data;
int offset,length;
{
    data[0]='\0';
    memcpy(data,offset,length);
    data[length] = 0x00;
printf("data[%s]\n",data);
}

long car302a_build2()
{
   $char  ibranch[3], fassured[2];
   $char  iengine[CA_ENGINE_NUM],icar_flag[2], ipolicy_a1[21];
   $char  sFull[30], stmt[3000], sApHome[31];
   $char  sTmp0[51],sTmp1[51],sTmp2[51];
   $long  dply_end;

   FILE   *fp0,*fp1,*fp2;
   char   file0[51],file1[51],file2[51];
   int    rt, tlen,iTmpbuf;
   char   sTmp[101], prtstr[80];
   int    s,t,u,i;


   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT;

    batchinit();
    max_count = 0;
    s = t = u = 0;

    $SELECT kPgNum_Line,nForm_File
       INTO $PgLine,$FormFile
       FROM Form
      WHERE ksys_grp="CA" AND kpgmid = 3021;

    strcpy(FormFile,rtrim(FormFile));
    sprintf_s(OutFile,sizeof OutFile,"%s.tx",outputf);

    rgu_init_report(FormFile,OutFile);

   rt = getApHome(sApHome);
   if (rt < 0) {
        printf("read Config file error!!\n");
        return M_CM_READ_CONFIG_ERR;
   }

   /* �q�H */
   strcpy(sTmp0,"isqr17_12");
   sprintf_s(file0,sizeof file0,"%s/rptftp/%s",sApHome,sTmp0);
   printf("file0[%s]\n",file0);
   fp0=fopen(file0,"w");

   /* �q�� */
   strcpy(sTmp1,"isqr17_22");
   sprintf_s(file1,sizeof file1,"%s/rptftp/%s",sApHome,sTmp1);
   printf("file1[%s]\n",file1);
   fp1=fopen(file1,"w");

   strcpy(prtstr,"HIS21I10");
   strcat(prtstr,"                    ");
   strcat(prtstr,"20");
   strcat(prtstr,"                                 ");
   prtstr[63]='\0';
   fprintf(fp0,"%s",prtstr);

   strcpy(prtstr,"HIS22I10");
   strcat(prtstr,"                    ");
   strcat(prtstr,"20");
   strcat(prtstr,"                                 ");
   prtstr[63]='\0';
   fprintf(fp1,"%s",prtstr);

   iTmpbuf = 0;
   $DECLARE sdb1_cur CURSOR FOR
     SELECT branch
       FROM servertbl
      WHERE branch != 'S1'
      ORDER BY branch;

   $OPEN sdb1_cur ;
   for(;;){
     $FETCH sdb1_cur INTO $ibranch;
     if (SQLCODE == SQLNOTFOUND) break;

     strcpy(sFull,get_full_dbname(ibranch));

     sprintf_s(stmt,sizeof stmt,
        " SELECT UNIQUE b.itag,b.fassured,b.iassured,b.iengine,a.icar_flag,a.ipolicy  "
        "   FROM %s:ply_relation a,%s:policy b,%s:ply_ins_type c     "
        "  WHERE YEAR(a.dply_end) = %d                               "
        "    AND MONTH(a.dply_end) = %d                              "
        "    AND a.fcard_class = '1'                                 "
        "    AND NVL(a.inext_ply,' ') = ' '                          "
        "    AND nvl(c.fedr_status,' ') NOT IN ('1','2','3')         "
        "    AND nvl(a.fedr_class,' ') != '1'                        "
        "    AND a.ipolicy = b.ipolicy                               "
        "    AND a.ipolicy = c.ipolicy ",sFull,sFull,sFull,iplyyear,iplymonth);

            printf("stmt[%s]\n",stmt);
        $PREPARE m2 FROM $stmt;
        $DECLARE m2_cur CURSOR FOR m2;
        $OPEN m2_cur;
        for(;;){
        $FETCH m2_cur INTO $itag,$fassured,$iassured,$iengine,$icar_flag,$ipolicy;
        if (SQLCODE == SQLNOTFOUND) break;

        printf("INTO ipolicy[%s],itag[%s],iassured[%s]\n",ipolicy,itag,iassured);
            if ((fassured[0] == '1') || (fassured[0] == '3') || (fassured[0] == '5'))
            {
               if (isdigit(iassured[1]) == 0 )
                  continue;

               if (strlen(trim(iassured)) < 10 )
                  continue;

               if (strlen(trim(iassured)) != 0){

                  strcpy(prtstr,"Q");
                  strcat(prtstr,rtrim(iassured));
                  strcat(prtstr,"21");
                  strcat(prtstr,"                                                  ");
                  prtstr[63] = '\0';
                  fprintf(fp0,"%s",prtstr);
                  s++;
              }
            }
            else
            {
               if (strlen(trim(itag)) != 0){
                   tlen = strlen(rtrim(itag));
                   strcpy(prtstr,"Q");
                   strcat(prtstr,rtrim(itag));
                   tlen = 8 - tlen;
                   for(i=0;i<tlen;i++)
                     strcat(prtstr," ");
                   strcat(prtstr,"21");
                   strcat(prtstr,"                                                    ");
                   prtstr[63] = '\0';
                   fprintf(fp1,"%s",prtstr);
                   t++;
               }

            }

        }
        $CLOSE m2_cur;
        $FREE  m2_cur;


        /** �L�۶O�󪺱M�ץ�A����W�����T�d�߫Y�� **/

        /** step1 ����X�O������������M�ץ��� || AZPG ��O�� */
        sprintf_s(stmt,sizeof stmt,
        " SELECT UNIQUE b.itag,b.fassured,b.iassured,b.iengine,a.ipolicy,a.dply_end  "
        "   FROM %s:ply_relation a,%s:policy b,%s:ply_ins_type c    "
        "  WHERE YEAR(a.dply_end) = %d       "
        "    AND MONTH(a.dply_end) = %d      "
        "    AND a.fcard_class = '2'         "
        "    AND NVL(a.inext_ply,' ') = ' '  "
        "    AND nvl(c.fedr_status,' ') NOT IN ('1','2','3') "
        "    AND nvl(a.fedr_class,' ') != '1'    "
        "    AND a.ipolicy = b.ipolicy  "
        "    AND a.ipolicy = c.ipolicy  "
        "    AND ((a.iresource = 'E'    "
        "          AND a.iofficer[1] = 'W' "
        "          AND a.icar_flag   = '1') "
        "          OR (a.ipolicy[8] between 'F' and 'Z'))", sFull,sFull,sFull,iplyyear,iplymonth);

            printf("stmt[%s]\n",stmt);
        $PREPARE wioff_pre FROM $stmt;
        $DECLARE wioff_cur CURSOR for wioff_pre;
        $OPEN wioff_cur;
        while(1)
        {
            $FETCH wioff_cur INTO $itag,$fassured,$iassured,$iengine,$ipolicy,$dply_end;
            if(SQLCODE == SQLNOTFOUND)
               break;

            continue;
            if( ipolicy[7] < 'F' || ipolicy[7] > 'Z') /* newa��O�� */
            {   /** step2 ��۶O�󪺸�� */
                sprintf_s(stmt,sizeof stmt,
                "SELECT a.ipolicy "
                "  FROM %s:ply_relation a , %s:policy b "
                " WHERE a.ipolicy = b.ipolicy "
                "   AND b.iengine = '%s'      "
                "   AND a.dply_end >= %d AND  a.dply_end <= %d "
                "   AND a.iofficer[1] = 'A'   "
                "   AND a.fcard_class = '2'   "
                "   AND nvl(a.fedr_class,' ') != '1'", sFull,sFull, iengine,
                    dply_end -30, dply_end+30 );
                $PREPARE get_a1 FROM $stmt;
                $DECLARE get_a2 CURSOR for get_a1;
                $OPEN get_a2;
                $FETCH get_a2 INTO $ipolicy_a1;
                if(SQLCODE == 0 )
                   continue;
                $CLOSE get_a2;
            }

            if ((fassured[0] == '1') || (fassured[0] == '3') || (fassured[0] == '5'))
            {
               if (isdigit(iassured[1]) == 0 )
                  continue;

               if (strlen(trim(iassured)) < 10 )
                  continue;

               if (strlen(trim(iassured)) != 0){

                  strcpy(prtstr,"Q");
                  strcat(prtstr,rtrim(iassured));
                  strcat(prtstr,"11");
                  strcat(prtstr,"                                                  ");
                  prtstr[63] = '\0';
                  fprintf(fp0,"%s",prtstr);
                  s++;
              }
            }
            else
            {
               if (strlen(trim(itag)) != 0){
                   tlen = strlen(rtrim(itag));
                   strcpy(prtstr,"Q");
                   strcat(prtstr,rtrim(itag));
                   tlen = 8 - tlen;
                   for(i=0;i<tlen;i++)
                     strcat(prtstr," ");
                   strcat(prtstr,"11");
                   strcat(prtstr,"                                                    ");
                   prtstr[63] = '\0';
                   fprintf(fp1,"%s",prtstr);
                   t++;
               }
            }
        }
        $CLOSE wioff_cur;
        $FREE  wioff_cur;

     }
     $CLOSE sdb1_cur;
     $FREE  sdb1_cur;

     fclose(fp0);
     fclose(fp1);


   sprintf_s(sTmp,sizeof sTmp,"%d����q�H�ɮ� -> %s �U�� OK �@ %d �� ",atoi(plyyear),sTmp0,s);
   rgu_put_body_string(1, sTmp, 1);
   rgu_put_body(1); max_count++;

   rt = rptftpinsert(userid,"car302a",sTmp0);
   if (rt != 0){
        printf("rptftp error\n");
        goto errexit;
   }

   sprintf_s(sTmp,sizeof sTmp,"%d����q���ɮ� -> %s �U�� OK �@ %d �� ",atoi(plyyear),sTmp1,t);
   rgu_put_body_string(1, sTmp, 1);
   rgu_put_body(1); max_count++;

   rt = rptftpinsert(userid,"car302a",sTmp1);
   if (rt != 0){
        printf("rptftp error\n");
        goto errexit;
   }

   rgu_finish_report();

   FormTp[0] = '\0';

   if(rc=(save_form_info(F_FREE,"CA",3021,userid,FormTp,max_count,outputf))<0)
   {
      printf("*** save_form_info() fail\n");
      EWRITE(userid,rc,"save_form_info failed");
      return rc;
   }


  return M_CM_OK;
errexit:
    printf("------car302a_build2: SQLCODE[%d]\n",SQLCODE);
    EWRITE(userid, SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}


/*long car302a_transfile()
{
   long lamt, ltmp;
   char itmp[10], stmp[7], syy[3], smm[3], sdd[3];
   $int count=0;
    int rtncode;
   $char b_dpaied_sql[11];
   char b_dpaied_fix[11];
   char sApHome[20];
   $char sTmp[1001];
    int  k,m;
   $char stmt[1024];

   char  record[2], transno[6], iins[3];
   int i, flen,n;

   $WHENEVER SQLERROR GOTO errexit;

   if ( db_select(DBName) == False)
   return M_CM_DB_NOTOPEN;


   batchinit();
   max_count = 0;
   flen   = 166;

   $SELECT kPgNum_Line,nForm_File
      INTO $PgLine,$FormFile
      FROM Form
     WHERE ksys_grp="CA" AND kpgmid = 3021;

   strcpy(FormFile,rtrim(FormFile));
   sprintf_s(OutFile,sizeof OutFile,"%s.tx",outputf);

   rgu_init_report(FormFile,OutFile);

   rtncode = getApHome(sApHome);
   if (rtncode < 0) {
        printf("read Config file error!!\n");
        return M_CM_READ_CONFIG_ERR;
   }
   sprintf_s(getfile,sizeof getfile, "%s/dat/car/%s", sApHome, sfile);

   printf("getfile[%s]\n",getfile);
   if ((fp=fopen(getfile,"rt"))==NULL)
   {
        printf(" fopen file error \n");
        return FALSE;
   }
   if ((bp=malloc(recLen))==NULL) {
        printf("System malloc failed  !\n");
        free(bp);
        return FAIL;
   }

    printf("before fgets file \n");

   for (i=0;(feof(fp)==0);i++) {
        memset(bp,0x00,flen);
        fgets(bp,flen,fp);
        if (bp[0]==0x00)
        break;

        for(i=0;i<=30;i++)
          sData[i][0] = '\0';
        printf("bp[%s]\b", bp);

        if (isdigit(bp[0])==0) {
            // ���Y�Ĥ@�X�� H 
            memcpy(record,bp+0,1);
            record[1]='\0';
            memcpy(transno,bp+1,5);
            transno[5]='\0';

            printf("record[%s] transno[%s]\n", record, transno );

            if(strcmp(transno,"IS21I")==0)
            {
            	iperflag = 1;
            }
            else if(strcmp(transno,"IS22I")==0)
            {
            	iperflag = 2;
            }
            continue;
        }
        else
        {
            memcpy(sData[0],bp+0,1);		//�O���O
            memcpy(sData[1],bp+1,9);		//�d�ߧǸ�
            memcpy(sData[2],bp+10,12);		//�d�ߤ��

            if(iperflag == 1)  // �q�H 
            {
               memcpy(sData[3],bp+22,10);	//�Q�O�Hid
               memcpy(sData[4],bp+32,20);	//����m�W
               memcpy(sData[5],bp+52,1);	//�m�O
               memcpy(sData[6],bp+53,1);	//�B��
               memcpy(sData[7],bp+54,8);	//�ͤ�
               memcpy(sData[8],bp+62,2);	//����
               memcpy(sData[9],bp+64,8);	//���ų̷s��s��
               memcpy(sData[10],bp+72,2);	//�s����
               memcpy(sData[11],bp+74,17);	//�j��O�渹�X
               memcpy(sData[12],bp+91,17);	//���N�O�渹�X

               for(n=0;n<5;n++)
               {
                  memcpy(iins,bp+108+n*11,2);	//�I��
                  iins[2] = '\0'; printf("iins[%s]\n", iins);

                  if( strcmp(iins, "21")== 0)  // �j�� 
                  {
                     strcpy(fins_grp,"3");
                     strcpy(sData[13],iins);
                     memcpy(sData[14],bp+110+n*11,1);
                     memcpy(sData[15],bp+111+n*11,2);
                     memcpy(sData[16],bp+113+n*11,2);
                     memcpy(sData[17],bp+115+n*11,4);

                     printf("sData[14]=[%s]\n", sData[14]);
                     if (sData[14][0] == 'Y')
                         non_year = 1;
                     else
                         non_year = 0;

                     acc_count3 = atoi(sData[15]);
                     strcpy(fbef_class,trim(sData[8]));
                     strcpy(fclass,trim(sData[10]));
                  //strncpy(ipolicy, sData[11], 13);
                  // ipolicy[13]='\0';  

                     strncpy(ipolicy, sData[11], 15);  // 950529,���15�Ӧr�� 
                     ipolicy[15]='\0';

                     rc= ins_upd_302( iperflag );
                     if(rc!=M_CM_OK)
                     {
                     	fclose(fp);
                        return rc;
                     }
                  }
                  else if( strcmp(iins, "01")== 0)  // ���l 
                  {
                     strcpy(fins_grp,"1");
                     strcpy(sData[18],iins);
                     memcpy(sData[19],bp+110+n*11,1);
                     memcpy(sData[20],bp+111+n*11,2);
                     memcpy(sData[21],bp+113+n*11,2);
                     memcpy(sData[22],bp+115+n*11,4);

                     non_year   = atoi(sData[19]);
            	     acc_count3 = atoi(sData[20]);
            	  // strncpy(ipolicy, sData[12], 13);
                  //   ipolicy[13]='\0';  

                     strncpy(ipolicy, sData[12], 15);  // 950529,���15�Ӧr��
                     ipolicy[15]='\0';

                     strcpy(fbef_class," ");
                     strcpy(lia_dmg_class,trim(sData[22]));
                     tmp_pacc = atoi(lia_dmg_class) + 4;
                     rfmtlong(tmp_pacc, "&&", fclass);
                     rc= ins_upd_302( iperflag );
                     if(rc!=M_CM_OK)
                     {
                     	fclose(fp);
                        return rc;
                     }
                  }
                  else if( strcmp(iins, "31")== 0)   // ���d 
                  {
                     strcpy(fins_grp,"2");
                     strcpy(sData[23],iins);
                     memcpy(sData[24],bp+110+n*11,1);
                     memcpy(sData[25],bp+111+n*11,2);
                     memcpy(sData[26],bp+113+n*11,2);
                     memcpy(sData[27],bp+115+n*11,4);
                     non_year   = atoi(sData[24]);
            	     acc_count3 = atoi(sData[25]);
             	  // strncpy(ipolicy, sData[12], 13);
                  // ipolicy[13]='\0';  

                     strncpy(ipolicy, sData[12], 15);  //950529,���15�Ӧr�� 
                     ipolicy[15]='\0';

                     strcpy(fbef_class," ");
                     strcpy(lia_dmg_class,trim(sData[27]));
                     tmp_pacc = atoi(lia_dmg_class) + 4;
                     rfmtlong(tmp_pacc, "&&", fclass);
                     rc= ins_upd_302( iperflag );
                     if(rc!=M_CM_OK)
                     {
                     	fclose(fp);
                        return rc;
                     }
                  }
                  else
                  {
                     break;
                  }
               }
            }
            else    // �q�� 
            {
               memcpy(sData[3],bp+22,8);	// �P�Ӹ��X
               memcpy(sData[4],bp+30,8);	// �Q�O�H�νs
               memcpy(sData[5],bp+38,20);	// ����m�W
               memcpy(sData[6],bp+58,2);	// ����
               memcpy(sData[7],bp+60,8);	// ��s��
               memcpy(sData[8],bp+68,2);	// �s����
               memcpy(sData[9],bp+70,17);	// �j��O�渹
               memcpy(sData[10],bp+87,17);	// ���N�O�渹
               for(n=0;n<5;n++)
               {
                  memcpy(iins,bp+104+n*11,2);
                  iins[2]='\0'; printf("iins=[%s]\n", iins);
                  if( strcmp(iins, "21")== 0)
                  {
                     strcpy(fins_grp,"3");
                     strcpy(sData[11],iins);
                     memcpy(sData[12],bp+106+n*11,1);
                     memcpy(sData[13],bp+107+n*11,2);
                     memcpy(sData[14],bp+109+n*11,2);
                     memcpy(sData[15],bp+111+n*11,4);
                     if (sData[12][0] == 'Y')
                         non_year = 1;
                     else
                         non_year = 0;

                     printf("sData[6]=[%s] sData[8]=[%s]\n", sData[8], sData[10]);

                     acc_count3 = atoi(sData[13]);
                     strcpy(fbef_class,trim(sData[6]));
                     strcpy(fclass,trim(sData[8]));
                  // strncpy(ipolicy, sData[9], 13);
                  // ipolicy[13]='\0'; 

                     strncpy(ipolicy, sData[9], 15);  // 950529,���15�Ӧr�� 
                     ipolicy[15]='\0';

                     strcpy(lia_dmg_class," ");
                     rc= ins_upd_302( iperflag );
                     if(rc!=M_CM_OK)
                     {
                     	fclose(fp);
                        return rc;
                     }
                  }
                  else if( strcmp(iins, "01")== 0)  // ���l 
                  {
                     strcpy(fins_grp,"1");
                     strcpy(sData[16],iins);
                     memcpy(sData[17],bp+106+n*11,1);
                     memcpy(sData[18],bp+107+n*11,2);
                     memcpy(sData[19],bp+109+n*11,2);
                     memcpy(sData[20],bp+111+n*11,4);

                     non_year   = atoi(sData[17]);
            	     acc_count3 = atoi(sData[18]);
                  // strncpy(ipolicy, sData[10], 13);
                  //   ipolicy[13]='\0'; 

                     strncpy(ipolicy, sData[10], 15);  // 950529,���15�Ӧr�� 
                     ipolicy[15]='\0';

                     strcpy(fbef_class," ");
                     strcpy(lia_dmg_class,trim(sData[20]));
                     tmp_pacc = atoi(lia_dmg_class) + 4;
                     rfmtlong(tmp_pacc, "&&", fclass);
                     rc= ins_upd_302( iperflag );
                     if(rc!=M_CM_OK)
                     {
                     	fclose(fp);
                        return rc;
                     }
                  }
                  else if( strcmp(iins, "31")== 0)   // ���d 
                  {
                     strcpy(fins_grp,"2");
                     strcpy(sData[21],iins);
                     memcpy(sData[22],bp+106+n*11,1);
                     memcpy(sData[23],bp+107+n*11,2);
                     memcpy(sData[24],bp+109+n*11,2);
                     memcpy(sData[25],bp+111+n*11,4);

                     non_year   = atoi(sData[22]);
            	     acc_count3 = atoi(sData[23]);
                  // strncpy(ipolicy, sData[10], 13);
                  //  ipolicy[13]='\0'; 

                     strncpy(ipolicy, sData[10], 15);  // 950529,���15�Ӧr�� 
                     ipolicy[15]='\0';

                     strcpy(fbef_class," ");
                     strcpy(lia_dmg_class,trim(sData[25]));
                     tmp_pacc = atoi(lia_dmg_class) + 4;
                     rfmtlong(tmp_pacc, "&&", fclass);
                     rc= ins_upd_302( iperflag );
                     if(rc!=M_CM_OK)
                     {
                     	fclose(fp);
                        return rc;
                     }
                  }
                  else
                  {
                     break;
                  }
               }
            }
        }

   }

   rgu_put_body_string(1,"�ɮפW�� OK",1);
   rgu_put_body(1); max_count++;

   rgu_finish_report();

   FormTp[0] = '\0';

   if(rc=(save_form_info(F_FREE,"CA",3021,userid,FormTp,max_count,outputf))<0)
   {
      printf("*** save_form_info() fail\n");
      EWRITE(userid,rc,"save_form_info failed");
      return rc;
   }

   fclose(fp);
   return M_CM_OK;

errexit:
   printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
   fclose(fp);
   return SQLCODE;
}*/

char *sformat_trade(pUnformat, iDatatype, iLength)
void *pUnformat;
int  iDatatype, iLength;
{
     char sFormat[200], sTmpbuf[200];
     int i, *iTmp;

     *sFormat = '\0';

     switch (iDatatype)
     {
          case 1:
                  iTmp = pUnformat;
                  strcpy(sTmpbuf, itoa(*iTmp));
                  for (i = 0 ; i < (iLength - strlen(sTmpbuf)) ; i++)
                        strcat(sFormat, "0");
                  strcat(sFormat, sTmpbuf);
                  break;
          case 2:
                  strcpy(sTmpbuf, trim(pUnformat));
                  strcpy(sFormat, sTmpbuf);
                  for (i = 0 ; i < (iLength - strlen(sTmpbuf)) ; i++)
                  strcat(sFormat, " ");
                  break;
          case 3:
                  strcpy(sTmpbuf, trim(pUnformat));
                  for (i = 0 ; i < (iLength - strlen(sTmpbuf)) ; i++)
                        strcat(sFormat, " ");
                  strcat(sFormat, sTmpbuf);
                  break;
           default:
                  break;
     }
     return sFormat;
     printf(" sFormat[%s]\n",sFormat);
}

long  ins_upd_302( flag )
int flag;
{
   $char  stmt[1024];

   $whenever sqlerror goto errexit;

   sprintf_s(stmt,sizeof stmt,
     " INSERT INTO sysdb:trans_fclass_302 (ipolicy,fins_grp,iassured,nassured,   "
     "                             itag,fbef_class,fclass,non_year,acc_count3)   "
     "   VALUES (?,?,?,?,?,?,?,?,?) ");
   printf("stmt[%s]\n", stmt );
   $PREPARE insid2 FROM $stmt;

   sprintf_s(stmt,sizeof stmt,
     " UPDATE sysdb:trans_fclass_302                  "
     "    SET (ipolicy,fins_grp,iassured,nassured,    "
     "         itag,fbef_class,fclass,non_year,acc_count3)  "
     "      = (?,?,?,?,?,?,?,?,?)  "
     "  WHERE fins_grp = ?  "
     "    AND iassured = ?  ");
   $PREPARE upiass1 FROM $stmt;

   sprintf_s(stmt,sizeof stmt,
   " UPDATE sysdb:trans_fclass_302                  "
   "    SET (ipolicy,fins_grp,iassured,nassured,    "
   "         itag,fbef_class,fclass,non_year,acc_count3)   "
   "      = (?,?,?,?,?,?,?,?,?)  "
   "  WHERE fins_grp = ?         "
   "    AND itag = ?  ");
   $PREPARE upitag1 FROM $stmt;

   strcpy(sp," ");

   if ( flag == 1 )
   {
        $EXECUTE upiass1
           USING $ipolicy,$fins_grp,$sData[3],$sData[4],$sp,$fbef_class,
                 $fclass,$non_year,$acc_count3,$fins_grp,$sData[3];
        if (sqlca.sqlerrd[2] == 0)
        {
         printf("insert into insid2\n");
         $EXECUTE insid2
            USING $ipolicy,$fins_grp,$sData[3],$sData[4],$sp,$fbef_class,$fclass,
                  $non_year,$acc_count3;
        }
    }
    else
    {
        $EXECUTE upitag1
           USING $ipolicy,$fins_grp,$sData[4],$sData[5],$sData[3],
                 $fbef_class,$fclass,$non_year,$acc_count3,
                 $fins_grp,$sData[3];
         if (sqlca.sqlerrd[2] == 0)
         {
             $EXECUTE insid2
                USING $ipolicy,$fins_grp,$sData[4],$sData[5],
                      $sData[3],$fbef_class,$fclass,$non_year,$acc_count3;
         }
    }

     return M_CM_OK;

errexit:
   printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

long car302a_renew()
{

    double calc_ipoint();

    FILE  *fptr;
    char  readstr[390];

    $char sFlag[2],        sIquery_serial[15], sIcard[18];
    $char sDply_begin[11], sDply_end[11],      sItag[CA_TAG_NUM];
    $char sIcar_type[3],   sQpt[6],            sFpt[2];
    $char sIassured[11],   sNassured[201],      sDbirthday[11];
    $char sFsex[2],        sFassured[2],       sIlevel[3];
    $char sIlevel_new[3],  sIins_type[3],      sPrem_21_std[7];
    $char sDeffect[11],    sDrate[11],         sError_msg[41];
    $char sFlagOld[2],sKind[9],sDrunk_driving[3],sDrunk_prem[7],sViolate[3],sViolate_prem[7];
    $char sTmpMsg[11],sOccurs[3];
    $long iTmpCount=0;
    $int  qdrunk_driving,mdrunk_prem;
    $int  qviolate,mviolate_prem;
    $double rIpoint, rTmp;
    $int  chk_day =0;
    $char sResult[2]=" ",sIquery_serialOld[15],sIassuredOld[11];
    int   rc,fErr;

    char  SendDB[5], sTmp[128];
    char  aphome[40];
    int   res, isqlcode, icnt,i,qOccurs ;
    $long  iCount, itest,itest2,itest3,iDelCnt,iDelCntAll,iTmpCnt,icnt_d;
    $int  iTmp;
    char  getfile[50];
    $char stmt[1024];



    iCount = 0;
    icnt   = 0;
    batchinit();
    max_count = 0;
    itest  = 0;
    itest2 = 0;
    itest3 = 0;
    iDelCnt = 0;
    iDelCntAll = 0;
    fErr = 0;
    iTmpCnt = 0;
    icnt_d = 0;

    /*$WHENEVER SQLERROR GOTO errexit;*/
    $WHENEVER SQLERROR CONTINUE;

    $SELECT kPgNum_Line,nForm_File
       INTO $PgLine,$FormFile
       FROM Form
      WHERE ksys_grp="CA" AND kpgmid = 3021;

    strcpy(FormFile,rtrim(FormFile));
    sprintf_s(OutFile,sizeof OutFile,"%s.tx",outputf);

    rgu_init_report(FormFile,OutFile);

    res = getApHome(aphome);
    if (res<0) {
        EWRITE( userid, -1, "In sigalrmcatcher func==>read config file error!!");
        return FAIL;
    }

    sprintf_s( getfile,sizeof getfile, "%s/dat/car/%s", aphome,sfile);

    printf("getfile[%s]\n", getfile);
    if ((fptr = fopen( getfile,"r")) == NULL)
    {
        sprintf_s( sTmp, "Cannot open print file: %s\n", getfile);
        EWRITE( userid, M_CM_OPEN_FILE_FAIL, sTmp);
        return M_CM_OPEN_FILE_FAIL;
    }

    $CREATE TEMP TABLE tmpCountTbl
    (
        dply_end     date

    ) WITH NO LOG;


    sprintf_s(stmt,sizeof stmt,
    " DELETE FROM ca_trade_renew "
    "  WHERE icard = ? ");
    $PREPARE pre_del_1 FROM $stmt;

   /* 103.02.05  4/1 �J�p��,��J����Ƥ~�|���s�r���(���)*/
   iTmp = 0;
   $SELECT FIRST 1 (today - '03/20/2014'::date) Into $iTmp FROM systables where 1=1;

   rgu_put_body_string(1, "  ",1);
   rgu_put_body(1); max_count++;
   sprintf_s( sTmp,sizeof sTmp,"%s","                �u�d�����ơv���S�O���p�B�z");
   rgu_put_body_string(1, sTmp,1);
   rgu_put_body(1); max_count++;
   sprintf_s( sTmp,sizeof sTmp,"%s","=====================================================================");
   rgu_put_body_string(1, sTmp,1);
   rgu_put_body(1); max_count++;
   sprintf_s( sTmp,sizeof sTmp,"%s","�B�z�覡\t�d    ��\t�d�ߧǸ� (��)\t�d�ߧǸ� (�s)\t��  ��");
   rgu_put_body_string(1, sTmp,1);
   rgu_put_body(1); max_count++;
   sprintf_s( sTmp,sizeof sTmp,"%s","---------------------------------------------------------------------");
   rgu_put_body_string(1, sTmp,1);
   rgu_put_body(1); max_count++;


   $BEGIN WORK;

   while(1)
   {
	     fscanf(fptr,"%[^\n]%*c",readstr);
	     printf("Trace -- strlen( readstr) = [%d] \n",  strlen( readstr));

	     /* �N�k��r��'\r'���N���r�굲���r��'\0' */
	     if (readstr[strlen(readstr)-1]=='\r'){
	     	  readstr[strlen(readstr)-1]= '\0';
	          printf("Trace -- TEST ok\n"  );
	     }
	     if(feof(fptr)) break;
	     iCount++;
	     printf("---READSTR[%s]\n", readstr);


	     /* �X�᪺֫�ɮ׳̥��r��"CrLf"���e���ɷ|�h�@�Ӧr��"Cr" ,���׷|�ܦ�168 �����v�TŪ�ɼg�J*/
	     /*
	     if( (strlen( readstr) != 172) || (strlen( readstr) != 173) )
	     {
	        $ROllBACK WORK;
	        EWRITE( userid, -1, readstr);
	        return FAIL;
	     }
	     */
	     strncpy( sFlag, &readstr[0], 1);
	     sFlag[1]='\0';
	     printf("sFlag [%s]\n", sFlag);

	     /*951204,���T�d�ߧǸ��קאּ14�X */
	     strncpy( sIquery_serial, &readstr[1], 14);
	     sIquery_serial[14]='\0';
	     strcpy(sIquery_serial,trim(sIquery_serial));
	     printf("Trace1 -- sIquery_serial = [%s] \n",  sIquery_serial);

	     /* ���L���q�N�X "17" �A���d�� */
	     strncpy( sIcard, &readstr[17], 15);
	     sIcard[15]='\0';
	     strcpy(sIcard,trim(sIcard));
	     printf("Trace1 -- sIcard = [%s] \n",  sIcard);

	     /* ��ʧR����� */
	     if (sFlag[0] == 'D')
	     {
	     	 iTmpCnt = 0;
	     	 iDelCntAll ++;
	         $SELECT count(*) Into $iTmpCnt FROM ca_trade_renew
	           WHERE icard = $sIcard;

        	 if (iTmpCnt > 0)
        	 {
       		     $EXECUTE pre_del_1 USING $sIcard;

	             sprintf_s( sTmp,sizeof sTmp, "%s\t%s\t%s\t%s\t%s",
	                      " [�w�R��]",sIcard,"              ",sIquery_serial," ");
		  	     rgu_put_body_string(1, sTmp,1);
		  	     rgu_put_body(1); max_count++;

	     	     iDelCnt++;

		     icnt_d++;
		     if (icnt_d==500)
		     {
		         icnt_d = 0;
		         $COMMIT WORK;
		         $BEGIN WORK;
		     }
        	 }
        	 else
        	 {
     	 	     /* �L������ƥi�R�� */
	             sprintf_s( sTmp,sizeof sTmp, "%s\t%s\t%s\t%s\t%s",
	                      " [���R��]",sIcard,"              ",sIquery_serial,"(�L�������)");
		     rgu_put_body_string(1, sTmp,1);
		     rgu_put_body(1); max_count++;
	       	 }

	     	 continue;
	     }
	     
	     
             if (sFlag[0] != 'A' && sFlag[0] != 'U')
             {
  	         rgu_put_body_string(1, "  ",1);
  	         rgu_put_body(1); max_count++;

	         sprintf_s( sTmp,sizeof sTmp, "%s\t%s\t%s\t%s\t%s",
	                        " [���~]",sIcard,"              ",sIquery_serial,"(�Ĥ@�X�����OA��U)");
		 rgu_put_body_string(1, sTmp,1);
		 rgu_put_body(1); max_count++;

                 sprintf_s( sTmp,sizeof sTmp,"%s","( ��J�ɮצܦ�����Ʈɵo�Ϳ��~�A���ˬd�íץ��ӵ���ƫ�A�q�����αq�Y�A����J )");
                 rgu_put_body_string(1, sTmp,1);
                 rgu_put_body(1); max_count++;
		 fErr = 1;
		 break;
	     }

	     strncpy( sTmp, &readstr[32], 8);
	     sTmp[8] = '\0';
	     printf("dply_begin [%s]\n", sTmp);
	     formatDate( sTmp, sDply_begin);
	     printf("dply_begin [%s]\n", sDply_begin);

	     strncpy( sTmp, &readstr[40], 8);
	     sTmp[8] = '\0';
	     printf("dply_end [%s]\n", sTmp);

	     formatDate( sTmp, sDply_end);
	     printf("dply_end [%s]\n", sDply_end);

	     strncpy( sItag, &readstr[48], 12);
	     sItag[12] = '\0';
	     printf("itag [%s]\n", sItag);

	     strncpy( sIcar_type, &readstr[60], 2);
	     sIcar_type[2] = '\0';
	     printf("icar_type [%s]\n", sIcar_type);

	     strncpy( sTmp, &readstr[62], 4);
	     sTmp[4] = '\0';
	     sprintf_s( sQpt,sizeof sQpt, "%c%c%c.%c", sTmp[0], sTmp[1], sTmp[2], sTmp[3]);
	     printf("sQpt [%s]\n", sQpt);

	     strncpy( sFpt, &readstr[66], 1);
	     sFpt[1] = '\0';
	     printf("Fpt [%s]\n", sFpt);

	     strncpy( sIassured, &readstr[67], 10);
	     sIassured[10] = '\0';
	     printf("iassured [%s]\n", sIassured);

	     strncpy( sNassured, &readstr[77], 200);
	     sNassured[200] = '\0';
	     printf("nassured [%s]\n", sNassured);

	     strncpy( sTmp, &readstr[277], 8);
	     sTmp[8] = '\0';
	     printf("dbirthday [%s]\n", sTmp);
	     formatDate( sTmp, sDbirthday);
	     printf("dbirthday [%s]\n", sDbirthday);

	     strncpy( sFsex, &readstr[285], 1);
	     sFsex[1] = '\0';
	     printf("fsex [%s]\n", sFsex);

	     strncpy( sFassured, &readstr[286], 1);
	     sFassured[1]='\0';
	     printf("fassured [%s]\n", sFassured);

	     strncpy( sIlevel, &readstr[287], 2);
	     sIlevel[2]='\0';
	     printf("ilevel [%s]\n", sIlevel);

	     strncpy( sIlevel_new, &readstr[289], 2);
	     sIlevel_new[2]='\0';
	     printf("ilevel_new [%s]\n", sIlevel_new);

	     /* 100.10.05�A���L�żƬ�0���A�ϥ�ca_acc_next.ec���p�⪺�ż� */
	     if (atoi(sIlevel_new)==0) 
	     {

                 sprintf_s( sTmp,sizeof sTmp, "%s\t%s\t%s\t%s\t%s",
                                " [���L]",sIcard,sIquery_serial,sIquery_serial,"(�żƬ�0)");
  	         rgu_put_body_string(1, sTmp,1);
  	         rgu_put_body(1); max_count++;
                 printf("--------------itest2[%d]\n", itest2);

	     	 itest2 ++;
	     	 continue;
	     }

	     strncpy( sIins_type, &readstr[291], 2);
	     sIins_type[2]='\0';
	     printf("iins_type [%s]\n", sIins_type);

	     rIpoint=calc_ipoint( sIins_type, " ", sIlevel_new);

	     strncpy( sPrem_21_std, &readstr[293], 6);
	     sPrem_21_std[6]='\0';
	     printf("prem_21_std [%s]\n", sPrem_21_std);

	     strncpy( sTmp, &readstr[299], 8);
	     sTmp[8] = '\0';
	     printf("deffect [%s]\n", sTmp);
	     formatDate( sTmp, sDeffect);
	     printf("deffect [%s]\n", sDeffect);

	     strncpy( sTmp, &readstr[307], 8);
	     sTmp[8] = '\0';
	     printf("drate [%s]\n", sTmp);
	     formatDate( sTmp, sDrate);
	     printf("drate [%s]\n", sDrate);

	     strncpy( sError_msg, &readstr[315], 40);
	     sError_msg[40]='\0';
	     printf("error_msg [%s]\n", sError_msg);

             /* 103.02.05 �s�r������� */
             qdrunk_driving = 0; mdrunk_prem = 0;
             /* ���j�H�W�[�O�[�O(1110608012_SC3)*/
             qviolate = 0; mviolate_prem = 0;
             
             if (iTmp>=0)
             {
		     strncpy( sOccurs, &readstr[355], 2);     /* �J�`��ưj���	9(02) */
		     sOccurs[2]='\0';
		     qOccurs = atoi(sOccurs);
		     printf("-- trace qOccurs[%d]\n ",qOccurs);
		     for(i=1;i<=qOccurs;i++)
		     {
		         strncpy( sKind, &readstr[357+((i-1)*16)], 8);   /* �J�`���O X(08 (21:�j��I�z�߷J�`��T ; 35:�s��r���J�`��T ; 43:���j�H�W�J�`��T)  */
			 sKind[8]='\0';
			 printf("-- trace sKind[%s]\n ",sKind);
			 if (strncmp(sKind, "35", 2)==0)
			 {
			     /* �s��r�� */
			     strncpy( sDrunk_driving, &readstr[365+((i-1)*16)], 2);  /* ����  9(02) */
			     sDrunk_driving[3]='\0';
			     qdrunk_driving = atoi(sDrunk_driving);
	                     printf("-- trace qdrunk_driving[%d]\n ",qdrunk_driving);
			     strncpy( sDrunk_prem, &readstr[367+((i-1)*16)], 6);     /* �[�O  9(06) */
			     sDrunk_prem[6]='\0';
			     mdrunk_prem = atoi(sDrunk_prem);
			     printf("-- trace mdrunk_prem[%d]\n ",mdrunk_prem);
			     
			 }
			 
			 if (strncmp(sKind, "43", 2)==0)
			 {
			     /* ���j�H�W */
			     strncpy( sViolate, &readstr[365+((i-1)*16)], 2);  /* ����  9(02) */
			     sViolate[2]='\0';
			     qviolate = atoi(sViolate);
	                     printf("-- trace qviolate[%d]\n ",qviolate);
			     strncpy( sViolate_prem, &readstr[367+((i-1)*16)], 6);     /* �[�O  9(06) */
			     sViolate_prem[6]='\0';
			     mviolate_prem = atoi(sViolate_prem);
			     printf("-- trace mviolate_prem[%d]\n ",mviolate_prem);
			     
			 }
			 
			 
		     }
	     }
	     printf("icard [%s]\n", sIcard);

	     $SELECT flag,iquery_serial,iassured
	        INTO $sFlagOld,$sIquery_serialOld,$sIassuredOld
	        FROM ca_trade_renew
	       WHERE icard = $sIcard;

	     if (SQLCODE != SQLNOTFOUND)
	     {
	         if( sFlagOld[0] == 'A' || ( sFlagOld[0] == 'U' && sFlag[0] == 'U'))
	         {
	             $EXECUTE pre_del_1 USING $sIcard;

	             sprintf_s( sTmp, sizeof sTmp, "%s\t%s\t%s\t%s\t%s",
	                            " [���N]",sIcard,sIquery_serialOld,sIquery_serial," ");

		     rgu_put_body_string(1, sTmp,1);
		     rgu_put_body(1); max_count++;
	             itest++;
	             printf("--------------itest[%d]\n", itest);

	         }
	         else if( sFlagOld[0] == 'U' && sFlag[0] == 'A')
	         {
	             strcpy(sIassuredOld,trim(sIassuredOld));
	             strcpy(sIassured,trim(sIassured));
	             if (strcmp(sIassured,sIassuredOld)==0)
	             {
		         sprintf_s( sTmp, sizeof sTmp, "%s\t%s\t%s\t%s\t%s",
		                        " [���L]",sIcard,sIquery_serialOld,sIquery_serial,"(�нT�{��])");
			 rgu_put_body_string(1, sTmp,1);
			 rgu_put_body(1); max_count++;
		         printf("--------------itest2[%d]\n", itest2);
		         itest2++;
		         continue;
	             }
	             else
	             {
	        	 $EXECUTE pre_del_1 USING $sIcard;

		         sprintf_s( sTmp,sizeof sTmp , "%s\t%s\t%s\t%s\t%s",
		                        " [���N*]",sIcard,sIquery_serialOld,sIquery_serial,"�O��ID���P");
			 rgu_put_body_string(1, sTmp,1);
			 rgu_put_body(1); max_count++;
		         printf("--------------itest2[%d]\n", itest2);
		         itest++;
	             }
	         }
	     }
	     else
	     {
	     	 itest3++;
	     }

	     $INSERT INTO ca_trade_renew
	              ( flag,        iquery_serial, icard,
	                dply_begin,  dply_end,      itag,
	                icar_type,   qpt,           fpt,
	                iassured,    nassured,      dbirthday,
	                fsex,        fassured,      ilevel,
	                ilevel_new,  iins_type,     ipoint,
	                prem_21_std, deffect,       drate,
	                error_msg,   icreate,       dcreate,
	                iupdate,     dupdate,       qdrunk_driving, mdrunk_prem,
	                qviolate,    mviolate_prem)

	      VALUES (  $sFlag,       $sIquery_serial, $sIcard,
	                $sDply_begin, $sDply_end,      $sItag,
	                $sIcar_type,  $sQpt,           $sFpt,
	                $sIassured,   $sNassured,      $sDbirthday,
	                $sFsex,       $sFassured,      $sIlevel,
	                $sIlevel_new, $sIins_type,     $rIpoint,
	                $sPrem_21_std,$sDeffect,       $sDrate,
	                $sError_msg,  $userid,         today,
	                ' ',          '' ,             $qdrunk_driving, $mdrunk_prem,
	                $qviolate,    $mviolate_prem);
	     
	     
	     if (SQLCODE != 0)
	     {
	         printf("Trace -- INSERT INTO ca_trade_renew SQLCODE = [%d] \n",  SQLCODE);
	  	 rgu_put_body_string(1, "  ",1);
	  	 rgu_put_body(1); max_count++;

		 sprintf_s( sTmp,sizeof sTmp, "%s\t%s\t%s\t%s\t%s",
		                " [���~]",sIcard,"              ",sIquery_serial,"(���ˬd�U����)");
		 rgu_put_body_string(1, sTmp,1);
		 rgu_put_body(1); max_count++;

	         sprintf_s( sTmp,sizeof sTmp,"%s","( ��J�ɮצܦ�����Ʈɵo�Ϳ��~�A���ˬd�íץ��ӵ���ƫ�A�q�����αq�Y�A����J )");
	         rgu_put_body_string(1, sTmp,1);
	         rgu_put_body(1); max_count++;
		 fErr = 1;
		 break;
	     }

	     $INSERT INTO tmpCountTbl VALUES ($sDply_end);
	     if (SQLCODE != 0)
	     {
	         rgu_put_body_string(1, "  ",1);
	  	 rgu_put_body(1); max_count++;

		 sprintf_s( sTmp,sizeof sTmp, "%s\t%s\t%s\t%s\t%s",
		                " [���~]",sIcard,"              ",sIquery_serial,"(���ˬd�O������)");
		 rgu_put_body_string(1, sTmp,1);
		 rgu_put_body(1); max_count++;

	         sprintf_s( sTmp,sizeof sTmp,"%s","( ��J�ɮצܦ�����Ʈɵo�Ϳ��~�A���ˬd�íץ��ӵ���ƫ�A�q�����αq�Y�A����J )");
	         rgu_put_body_string(1, sTmp,1);
	         rgu_put_body(1); max_count++;
		 fErr = 1;
		 break;
	     }
	     else
	     {

	         icnt++;
	         if (icnt==500)
	         {
	             icnt = 0;
	             $COMMIT WORK;
	             $BEGIN WORK;
	         }
	     }

   }/* end while */

   fclose( fptr);

   $COMMIT WORK;


/* �u�O�d2�~���?
   $BEGIN WORK;
   $DELETE FROM ca_trade_renew
     WHERE dply_end < (today - 2 UNITS YEAR)
   $COMMIT WORK;
*/

   if (fErr==0)
   {
       if ((itest+itest2+iDelCntAll)==0)
       {
           rgu_put_body_string(1, "( �L )",1);
	   rgu_put_body(1); max_count++;
       }
       rgu_put_body_string(1, " ",1);
       rgu_put_body(1); max_count++;
       rgu_put_body_string(1, "==>  ���槹���I",1);
   }
   else
   {
       rgu_put_body_string(1, " ",1);
       rgu_put_body(1); max_count++;
       rgu_put_body_string(1, "==>  ���椤�_�I",1);
   }
   rgu_put_body(1); max_count++;

   rgu_put_body_string(1, " ",1);
   rgu_put_body(1); max_count++;
   sprintf_s( sTmp,sizeof sTmp, "   �@��J       [%5d] ��", iCount);
   rgu_put_body_string(1, sTmp,1);
   rgu_put_body(1); max_count++;
   sprintf_s( sTmp,sizeof sTmp, "     �䤤  ���N [%5d] ��", itest);
   rgu_put_body_string(1, sTmp,1);
   rgu_put_body(1); max_count++;
   sprintf_s( sTmp,sizeof sTmp, "           ���L [%5d] ��", itest2);
   rgu_put_body_string(1, sTmp,1);
   rgu_put_body(1); max_count++;
   sprintf_s( sTmp,sizeof sTmp, "           �s�W [%5d] ��", itest3);
   rgu_put_body_string(1, sTmp,1);
   rgu_put_body(1); max_count++;

   if (iDelCntAll> 0 )
   {
       sprintf_s( sTmp,sizeof sTmp,"%s","---------------------------------------------------------------------");
       rgu_put_body_string(1, sTmp,1);
       rgu_put_body(1); max_count++;
       sprintf_s( sTmp,sizeof sTmp, "       ���w�R�� [%5d] ��", iDelCntAll);
       rgu_put_body_string(1, sTmp,1);
       rgu_put_body(1); max_count++;
       sprintf_s( sTmp,sizeof sTmp, "       ��ڧR�� [%5d] ��", iDelCnt);
       rgu_put_body_string(1, sTmp,1);
       rgu_put_body(1); max_count++;
   }



   /* 980903 */
   if (itest >0 || itest3>0 )
   {

       rgu_put_body_string(1, "  ",1);
       rgu_put_body(1); max_count++;

       sprintf_s( sTmp,sizeof sTmp,"%s","  �U�������J���Ʋέp");
       rgu_put_body_string(1, sTmp,1);
       rgu_put_body(1); max_count++;

       sprintf_s( sTmp,sizeof sTmp,"%s","=========================");
       rgu_put_body_string(1, sTmp,1);
       rgu_put_body(1); max_count++;
       rgu_put_body_string(1," �O����       �� ��  ",1);
       rgu_put_body(1); max_count++;

       sprintf_s( sTmp,sizeof sTmp,"%s","-------------------------");
       rgu_put_body_string(1, sTmp,1);
       rgu_put_body(1); max_count++;

       /* print �C�骺���*/
       $DECLARE cnt_cur CURSOR FOR
         SELECT  distinct to_char(dply_end,'%Y/%m/%d') ,count(*)
	   FROM tmpCountTbl
	  GROUP BY 1 ORDER BY 1;
       $OPEN cnt_cur ;
       for(;;)
       {
           $FETCH cnt_cur INTO $sTmpMsg,$iTmpCount ;
	   if (SQLCODE == SQLNOTFOUND) break;
	   printf("Trace -- sTmpMsg = [%s]iTmpCount=[%ld] \n",  sTmpMsg,iTmpCount);

	   sprintf_s(sTmp,sizeof sTmp,"%s     %5ld ",sTmpMsg,iTmpCount);
	   rgu_put_body_string(1, sTmp,1);
	   rgu_put_body(1); max_count++;
       }
       $CLOSE cnt_cur ;
       $FREE  cnt_cur ;

       if (fErr==1)
       {
           strcpy(sResult, "0" );
       }
       else
       {
           strcpy(sResult, "1" );
       }
   }
   else
   {
       strcpy(sResult, "0" );
   }

   rgu_finish_report();


   /* �g�Jcar302a�ˮֵ��G */
   /*$SELECT DAY(today) INTO $chk_day FROM systables WHERE tabid=1;*/

   rc = ply_302_key(1, "car302a", "A", sResult,userid);

   FormTp[0] = '\0';

   if(rc=(save_form_info(F_FREE,"CA",3021,userid,FormTp,max_count,outputf))<0)
   {
      printf("*** save_form_info() fail\n");
      EWRITE(userid,rc,"save_form_info failed");
      return rc;
   }

   return M_CM_OK;
/*
 errexit:

   printf("SQLCODE[%d], ERRM[%s]\n", SQLCODE, sqlca.sqlerrm);
   sprintf(sTmp, "SQLCODE[%d], ERRM[%s], Icard[%s], Itag[%s]\n",
         SQLCODE, sqlca.sqlerrm, sIcard, sItag);
   isqlcode=SQLCODE;
   $WHENEVER SQLERROR CONTINUE;
   $ROllBACK WORK;
   EWRITE( userid, isqlcode, sTmp);

   return isqlcode;
*/
}

/* -------------------------------------------------------------------------------*/
double calc_ipoint( sIins_type, sIpoint, sIlevel_new)
char sIins_type[03];
char sIpoint[5];
char sIlevel_new[03];
{
double rIpoint;
int    iIlevel_new;

        iIlevel_new = atoi( sIlevel_new);

        if( strcmp( trim(sIins_type), "01") == 0)
                rIpoint = 0.2 * atoi( sIpoint);
        else if( strcmp( trim(sIins_type), "31") == 0)
                rIpoint = 0.1 * atoi( sIpoint);
        else if( strcmp( trim(sIins_type), "21") == 0)
        {
                if( iIlevel_new < 4)
                {
                        if( iIlevel_new == 3)
                                rIpoint = -0.18;
                        else if( iIlevel_new == 2)
                                rIpoint = -0.26;
                        else if( iIlevel_new == 1)
                                rIpoint = -0.30;
                        else
                        	    rIpoint = -9.00;  /* �żƬ�0�A�L�k���o�Y�� => ���D���*/
                }
                else
                        rIpoint = 0.1 * (atoi( sIlevel_new) - 4);
        }

        return rIpoint;
}
/* -------------------------------------------------------------------------------*/
int formatDate( sTmp, sDate)
char sTmp[64];
char sDate[11];
{
        if( sTmp[0]==' ' || sTmp[0] == '0' || sTmp[0] == '\0')
        {   strcpy( sDate, " ");
            return;
        }
        sDate[0] = sTmp[4];
        sDate[1] = sTmp[5];
        sDate[2] = '/';
        sDate[3] = sTmp[6];
        sDate[4] = sTmp[7];
        sDate[5] = '/';
        sDate[6] = sTmp[0];
        sDate[7] = sTmp[1];
        sDate[8] = sTmp[2];
        sDate[9] = sTmp[3];
        sDate[10] = '\0';
}
/* -------------------------------------------------------------------------------*/

long car302a_diff()
{

double calc_ipoint();

FILE  *fptr;
char  readstr[256];

$char sIcard[18],sItag[CA_TAG_NUM],sIassured[11],sDbirthday[11],sFsex[2];
$char sIcar_type[3], sQpt[5],sFpt[2];
$char sIcard_1[18],sItag_1[CA_TAG_NUM],sIassured_1[11],sDbirthday_1[11];
$char sIcar_type_1[3], sQpt_1[5],sFpt_1[2];
$char sDitag_change[11],sNassured[21],sIdata_src[2],sIerr_code[19];
$char sFused[2],sDused[11],sIupdate[11],sDupdate[11];
char  aphome[40],sTmp[128];
int   isqlcode, iCount, res,fStat;
$int  iTmp;
char  getfile[50];
$char stmt[2048];


    $WHENEVER SQLERROR GOTO errexit;

    res = getApHome(aphome);
    if (res<0) {
        EWRITE( userid, -1, "In sigalrmcatcher func==>read config file error!!");
        return FAIL;
    }
    sprintf_s( getfile,sizeof getfile, "%s/dat/car/%s", aphome,sfile);

    printf("getfile[%s]\n", getfile);

/* -------------------------------------------------------*/
/*  �j���Ҹ�	����	�����Ҹ�	�ͤ� 	�ʧO	����	����	���
    �^���Ҹ�	�^�Ш���	�^�Ш����Ҹ�	�^�Хͤ� 	�^�Ш���	�^�Э���	�^�г��	���P��	�^�Щm	�ӷ�	���~�N�X */


    $DATABASE sysdb;
    $CREATE TEMP TABLE tmp_ca_trade_diff (
        icard                char(17) not null,
        itag                 char(12) ,
        iassured             char(10),
        ibirthday            char(8),
        fsex                 char(1),
        icar_type            char(2),
        qpt                  decimal(4,1),
        fpt                  char(1),
        icard_1              char(17) not null,
        itag_1               char(12) ,
        iassured_1           char(10),
        ibirthday_1          char(8),
        icar_type_1          char(2),
        qpt_1                decimal(4,1),
        fpt_1                char(1),
        itag_change          char(8),
        nassured             char(20),
        idata_src            char(1),
        ierr_code            char(18)
    ) WITH NO LOG;

    /*�W�Ǫ���Ƥ��]�\������ */
    /*$CREATE UNIQUE INDEX idx_ca_trade_tmp_u ON  tmp_ca_trade_diff(icard);*/

/* -------------------------------------------------------*/
	if ((fStat=load_command1(getfile,outputf,"tmp_ca_trade_diff","\t")) != SUCCESS)
	{
		  printf("Loading File fStat[%d]\n",fStat);
	   	  EWRITE(userid,fStat,"M_CM_LOAD_FAIL");
	   	  /*isEndReport(userid);
	   	  unlink(path_DataFile);*/
	   	  exit(FAIL);
	}

	printf("Loading ca_trade_diff.txt to tmp_ca_trade_diff Complete!!\n");

/* -------------------------------------------------------*/

    /* select tmp_ca_trade_diff
       �t�s�W��L�O�����Gfused(�O�_�w�I��),dused(�I�ɤ�),iupdate(�W�Ǫ�),dupdate(�W�Ǥ�)*/
	sprintf_s(stmt,sizeof stmt,
	   "  SELECT *,'N',' ','%s',today "
	   "    FROM tmp_ca_trade_diff",userid);
	    printf("stmt[%s]\n", stmt);
	$PREPARE pre_ca_diff FROM $stmt;
	$DECLARE cur_ca_diff CURSOR FOR pre_ca_diff;


    /* for check ��ƬO�_�w�s�b */
    sprintf_s(stmt,sizeof stmt,
    "SELECT count(*) FROM ca_trade_diff "
    " WHERE icard = ? ");
    $PREPARE pre_dupicate_chk FROM $stmt;

    /* for delete �w�s�b����� */
    sprintf_s(stmt,sizeof stmt,
    "DELETE FROM ca_trade_diff "
    " WHERE icard = ? ");
    $PREPARE pre_del_dupicate FROM $stmt;

    /* Insert into ca_trade_diff */
    sprintf_s(stmt,sizeof stmt,
    "INSERT INTO ca_trade_diff VALUES ( "
    " ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
    $PREPARE pre_insert_data FROM $stmt;

/* -------------------------------------------------------*/

    iCount = 0;
    batchinit();
    max_count = 0;


    if ((fptr = fopen( getfile,"r")) == NULL)
    {
        sprintf_s( sTmp,sizeof sTmp, "Cannot open print file: %s\n", getfile);
        EWRITE( userid, M_CM_OPEN_FILE_FAIL, sTmp);
        return M_CM_OPEN_FILE_FAIL;
    }

/* -------------------------------------------------------*/

    printf("�ǳ���J ca_trade_diff ...\n");

    /* ����J�Ȧs��,�T�{��J���O�_���T */
    $BEGIN WORK;

    $OPEN cur_ca_diff ;
    for(;;)
    {

        $FETCH cur_ca_diff
          INTO $sIcard, $sItag, $sIassured, $sDbirthday, $sFsex, $sIcar_type, $sQpt, $sFpt,
               $sIcard_1, $sItag_1, $sIassured_1, $sDbirthday_1, $sIcar_type_1, $sQpt_1,
               $sFpt_1, $sDitag_change, $sNassured, $sIdata_src, $sIerr_code, $sFused,$sDused,
               $sIupdate, $sDupdate;

         if (SQLCODE == SQLNOTFOUND) break;

         iTmp = 0;
         printf( "sIcard=[%s]\n", sIcard);

         strcpy(sTmp,trim(sDbirthday));
         formatDate( sTmp, sDbirthday);
         printf( "sDbirthday=[%s]\n", sDbirthday);

         strcpy(sTmp,trim(sDbirthday_1));
         formatDate( sTmp, sDbirthday_1);

         strcpy(sTmp,trim(sDitag_change));
         formatDate( sTmp, sDitag_change);

         /* duplicate check*/
         $EXECUTE pre_dupicate_chk INTO $iTmp USING $sIcard;
         if (iTmp!=0){
         	 printf( "dupicate icard=[%s]\n", sIcard);
         	 $EXECUTE pre_del_dupicate USING $sIcard;
         }

         /* Insert into ca_trade_diff */
         $EXECUTE pre_insert_data
            USING $sIcard, $sItag, $sIassured, $sDbirthday, $sFsex, $sIcar_type, $sQpt, $sFpt,
                  $sIcard_1, $sItag_1, $sIassured_1, $sDbirthday_1, $sIcar_type_1, $sQpt_1,
                  $sFpt_1, $sDitag_change, $sNassured, $sIdata_src, $sIerr_code, $sFused,$sDused,
                  $sIupdate,$sDupdate;

	     iCount++;

    } /* End for(;;) */

    printf( "iCount=[%d]\n", iCount);
    $CLOSE cur_ca_diff;
    $Free cur_ca_diff;

    $COMMIT WORK;
    sprintf_s( sTmp,sizeof sTmp, "���槹��,�@[%d]��", iCount);

    $SELECT kPgNum_Line,nForm_File
      INTO $PgLine,$FormFile
      FROM Form
     WHERE ksys_grp="CA" AND kpgmid = 3021;

    strcpy(FormFile,rtrim(FormFile));
    sprintf_s(OutFile,sizeof OutFile,"%s.tx",outputf);
    rgu_init_report(FormFile,OutFile);
    rgu_put_body_string(1, rtrim(sTmp), 1);
    rgu_put_body(1); max_count++;
    rgu_finish_report();

    if(rc=(save_form_info(F_FREE,"CA",3021,userid,FormTp,max_count,outputf))<0)
    {
       #ifdef PRINTF_FLAG
  	   printf("*** save_form_info() fail\n");
       #endif
    }
   printf( "���槹��,�@[%d]��\n", iCount);

   return M_CM_OK;


 errexit:

    printf("SQLCODE[%d], ERRM[%s]\n", SQLCODE, sqlca.sqlerrm);
    sprintf_s(sTmp,sizeof sTmp, "SQLCODE[%d], ERRM[%s], Icard[%s], Itag[%s]\n",
          SQLCODE, sqlca.sqlerrm, sIcard, sItag);
    isqlcode=SQLCODE;
    $WHENEVER SQLERROR CONTINUE;
    $ROllBACK WORK;
    EWRITE( userid, isqlcode, sTmp);
    return isqlcode;
}



/* 101.08.09 �s�Wfcar_class(�ۥ���~�O) ���B���s�u��~���M���r�ɡv */
/* 100.06���T����,�ɮײM��s�W"�J�`���O"���G2(�T��) ; 3(����) */
/* -------------------------------------------------------------------------------*/

/* �̫��w�����϶��A���O�^���۵M�H(�q�H)�Ϊk�H(�q��)�d�����T�һݤ�"�����Ҹ��X"��"�Τ@�s��+����"
�\��G
  1.�۵M�H(�q�H)�G����"�����Ҹ��X"�� �Ϊk�H(�q��):����"�Τ@�s��+����" ��rptftp �ѤU��
  2.�۵M�H(�q�H)�Ϊk�H(�q��):�U�������T�d�ߪ��ШD�� ��rptftp �ѤU��
���G�e���G

���s�����I

   �۵M�H(�q�H)�G�@    ��
   �k  �H(�q��)�G�@    ��

   => �Ц�cmn202�U���u���T�d�ߪ��ШD�ɡv
     (���s�L�{��"�����Ҹ��X"��"�Τ@�s��+����" �M���ɥi�ۦ�U���Ѧ� )*/

long car302a_Trade_302_Step1_1(sFilePathOut1,sFilePathOut2)
char *sFilePathOut1,*sFilePathOut2;
{
$char sFull[30];
$char ibranch[3];
$char stmt[3000],sTmpX[512],sTmpY[101];
$char fassured[2];
FILE  *fp0,*fp1,*fp2;
/*FILE  *fp2;*/
$char  sApHome[31];
char  file0[51],file1[51],file2[51];
int   rt, ifp2;
char   sTmp[101];
$char  sTmp0[100],sTmp1[100],sTmp2[100];
$char  str[51],icar_flag[2];
long    i,s,t,u,v;
char   nfile1[60],nfile2[60];
$int   ftrade3021; /* �O�_�}�l�ǰe�۵M�H���P:1:�}�l�ǰe 0:���ǰe */
$int   ftrade3022; /* �۵M�H���P:1:�u�ꨮ�P 0:�ť� */


   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT;

    ifp2 = 0;
   rt = getApHome(sApHome);
   if (rt < 0) {
        printf("read Config file error!!\n");
        return M_CM_READ_CONFIG_ERR;
   }

   strcpy(nfile1,rtrim(sParam1));
   strcpy(nfile2,rtrim(sParam2));
   strFileNameReplace(nfile1,"/"," ");  /* Ex. 099/12/01 => 0991201*/
   strFileNameReplace(nfile2,"/"," ");

   sprintf_s(sTmp0,sizeof sTmp0,"man_%s_%s.txt",nfile1,nfile2);
   sprintf_s(file0,sizeof file0,"%s/rptftp/%s",sApHome,sTmp0);
   sprintf_s(sTmp1,sizeof sTmp1,"car_%s_%s.txt",nfile1,nfile2);
   sprintf_s(file1,sizeof file1,"%s/rptftp/%s",sApHome,sTmp1);

   sprintf_s(sTmp2,sizeof sTmp2,"��~��_%s_%s.txt",nfile1,nfile2);
   sprintf_s(file2,sizeof file2,"%s/rptftp/%s",sApHome,sTmp2);

   printf("file0[%s]\n",file0);
   printf("file1[%s]\n",file1);
   printf("file1[%s]\n",file2);
   /** 100.10.20 ���T�d���ɧ��client��"���T�妸�d�ߵ{��"�B�z

   sprintf(sTmp,"\n�� ���s�u���N�I-�妸�d�����T�ШD��(�J�`)�v \n");
   **/
   sprintf_s(sTmp,sizeof sTmp,"\n�� ���s�u���N�I-�妸�d�����T-�M���ɡv \n");
   rgu_put_body_string(1, sTmp, 1);
   rgu_put_body(1); max_count++;

   sprintf_s(sTmp,sizeof sTmp,"\n�i��ư϶��j�O������G %s �� %s  \n", sParam1, sParam2);
   rgu_put_body_string(1, sTmp, 1);
   rgu_put_body(1); max_count++;

   /* ���PDB�i��X�{���ƪ�iassured+icar_kind+fcar_class��iassured+itag+icar_kind+fcar_class���
      �G���g�J temp table */


   /* Ūcar140�]�w,�P�_�O�_�n�ǰe�۵M�H���P add by sylvia 103.09.29 */
   $select case when today >= detail2 then 1 else 0 end
      into $ftrade3021
      from car_code
     where kind = 'RN' and detail = 'TRADE3021';

   /* Ūcar140�]�w,�۵M�H���P��ť��٬O�u�ꨮ�P add by sylvia 103.09.29 */
   $select case when today >= detail2 then 1 else 0 end
      into $ftrade3022
      from car_code
     where kind = 'RN' and detail = 'TRADE3022';


   for(i=1;i<=2;i++)
   {
       printf("Trace -- i = [%ld] \n",  i);
       if (i == 1)
       {
           if (fGenMan =='1')
           {
	       $CREATE TEMP TABLE tmp_ca_trade_302_1 (
		   iassured           char(12),       /* �����Ҹ� */
		   itag               char(12),      /* ����  */
		   icar_kind          char(1),        /* �J�`���O */
		   fcar_class         char(1)         /* �ۥ���~�O */
	       ) WITH NO LOG;

	       sprintf_s(stmt,sizeof stmt,"INSERT INTO tmp_ca_trade_302_1 Values (?,?,?,?) ");
               $PREPARE preInsertData1 FROM $stmt;

               if (ftrade3022 == 0)
               {
                   strcpy(sTmpX," DISTINCT b.iassured,' ', \n\
                                  CASE WHEN a.icar_type IN ('01','02','32','34','35') THEN '3' \n\
                                  ELSE '2' \n\
                                  END AS  icar_kind ,c.fcar_class ");
               }
               else
               {
   		   strcpy(sTmpX," DISTINCT b.iassured,b.itag, \n\
                                  CASE WHEN a.icar_type IN ('01','02','32','34','35') THEN '3' \n\
                                  ELSE '2' \n\
                                  END AS  icar_kind ,c.fcar_class ");
               }
               
	       strcpy(sTmpY," AND b.fassured in ('1','3','5') " );
	   }
	   else
	   {
	       continue;
	   }

       }
       else if (i == 2)
       {
           if (fGenCar =='1')
           {

	       $CREATE TEMP TABLE tmp_ca_trade_302_2 (
		    iassured           char(12),      /* �νs */
		    itag               char(12),      /* ����  */
		    icar_kind          char(1),       /* �J�`���O */
		    fcar_class         char(1)        /* �ۥ���~�O */
	        ) WITH NO LOG;

		sprintf_s(stmt,sizeof stmt,"INSERT INTO tmp_ca_trade_302_2 Values (?,?,?,?) ");
		$PREPARE preInsertData2 FROM $stmt;

		strcpy(sTmpX," DISTINCT b.iassured,b.itag , \n\
                               CASE WHEN a.icar_type IN ('01','02','32','34','35') THEN '3' \n\
                               ELSE '2' \n\
                               END AS  icar_kind ,c.fcar_class ");
		strcpy(sTmpY," AND b.fassured in ('2','4','6') " );
	   }
	   else
	   {
	       continue;
	   }
       }
       
       $DECLARE sdb_cur_trade CURSOR FOR
	 SELECT branch
	   FROM servertbl
	  WHERE branch != 'S1'
	  ORDER BY branch;

       $OPEN sdb_cur_trade ;
       for(;;)
       {
           $FETCH sdb_cur_trade INTO $ibranch;
	   if (SQLCODE == SQLNOTFOUND) break;

	   strcpy(sFull,get_full_dbname(ibranch));

	   /* 102.12.25 �ק�M�ץ����*/
	   /* 102.08,�q�ʦۦ樮(51����) ���d���T�A�]���ݨT���ξ���, �bca_no_trade_302���w�[�J"51����"�� */
	   /*        ���B���[�W AND a.icar_type <> '51'   ���� */
	   /* �ק��o���M�ץ�g�� modify by sylvia 103.09.23 (1030630002_C1) */
	   /*  AND ( iofficer[1] <> 'W' and not (iofficer[1] = 'H' and iofficer[2] not in ('0','1','2')) ) \n\ */

	   sprintf_s(stmt,sizeof stmt,
		   " SELECT %s \n"
		   "   FROM %s:ply_relation a,%s:policy b, car_type c  \n"
		   "  WHERE a.ipolicy = b.ipolicy AND a.icar_type = c.icode \n"
		   "    AND a.dply_end between %ld and %ld  \n"
		   "    AND a.fcard_class in ('1','2')             \n"
		   "    AND nvl(a.fedr_class,' ') <> '1'             \n"
		   "    AND a.iofficer not in (select iofficer_ori from ca_promote_officer_A) "
		   "    AND c.fclass = '1'                  \n"
		   "    AND a.icar_type <> '51'             \n"
		   "    AND a.ipolicy not in (SELECT ipolicy FROM ca_no_trade_302 WHERE dply_end between %ld and %ld) \n"
		   "     %s ",
		    sTmpX,sFull,sFull,lngDply_begin,lngDply_end,lngDply_begin,lngDply_end,sTmpY);

	   printf("stmt[%s]\n",stmt);
	   $PREPARE m1 FROM $stmt;
	   $DECLARE m1_cur_trade0 CURSOR FOR m1;
	   $OPEN m1_cur_trade0;
	   for(;;)
	   {

	       if (i ==1)  /* --�۵M�H-*/
	       {	   
	           $FETCH m1_cur_trade0 INTO $iassured,$itag, $icar_kind,$fcar_class;
		   if (SQLCODE == SQLNOTFOUND) break;
		   $EXECUTE preInsertData1 USING $iassured,$itag,$icar_kind,$fcar_class;

 	       }
 	       else if (i ==2) /* --�k  �H-*/
 	       { 
		   $FETCH m1_cur_trade0 INTO $iassured,$itag,$icar_kind,$fcar_class;
		   if (SQLCODE == SQLNOTFOUND) break;
		   $EXECUTE preInsertData2 USING $iassured,$itag,$icar_kind,$fcar_class;
	       }

	   } /* End of CURSOR m1_cur_trade */
	   $CLOSE m1_cur_trade0;
	   $FREE  m1_cur_trade0;

       } /* End of CURSOR sdb_cur_trade */
       $CLOSE sdb_cur_trade;
       $FREE  sdb_cur_trade;

   }

   s = t = u = v = 0;

   /** �A�q temp table �g�J�ɮ� */

   for(i=1;i<=2;i++)
   {
       printf("Trace -- i = [%ld] \n",  i);
       if (i == 1)
       {
           if (fGenMan =='1')
           {

               fp0=fopen(file0,"w");
	       strcpy(sTmpX," DISTINCT iassured,itag,icar_kind,fcar_class");
	       strcpy(sTmpY," tmp_ca_trade_302_1 " );
	   
	       if (ifp2 == 0)
	       {
	           ifp2 = 1;
		   fp2=fopen(file2,"w");
	       }
	       
	   }
	   else
	   {
	       continue;
	   }
       }
       else if (i == 2)
       {
           if (fGenCar =='1')
           {

               fp1=fopen(file1,"w");
	       strcpy(sTmpX," DISTINCT iassured,itag,icar_kind,fcar_class");
	       strcpy(sTmpY," tmp_ca_trade_302_2 " );

	       if (ifp2 == 0)
	       {
	           ifp2 = 2;
		   fp2=fopen(file2,"w");
	       }
	   }
	   else
	   {
	       continue;
	   }
       }

       sprintf_s(stmt,sizeof stmt, " SELECT %s FROM %s Order By 1" , sTmpX, sTmpY);

       printf("stmt[%s]\n",stmt);
       $PREPARE m1 FROM $stmt;
       $DECLARE m1_cur_trade CURSOR FOR m1;
       $OPEN m1_cur_trade;
       for(;;)
       {
           if (i ==1)
           {
               $FETCH m1_cur_trade INTO $iassured,$itag,$icar_kind,$fcar_class;
	   }
	   else if (i ==2)
	   {
	       $FETCH m1_cur_trade INTO $iassured,$itag,$icar_kind,$fcar_class;
	   }
	   
	   if (SQLCODE == SQLNOTFOUND) break;

	   if (i ==1)  /* --�۵M�H-*/
	   {                        
	       if (ftrade3021 > 0) /* �w�p103/10/03��~�|�s�W�۵M�H���P��� */
	       { 
	           strcpy(str,rtrim(itag));	     /*���P���X  add by sylvia 103.09.23 (�۵M�H�[���P,�d�������O���) */
	    	   strcat(str,"\t");
	       }
	       strcat(str,rtrim(iassured));    /*�����Ҹ� */
	       strcat(str,"\t");
	       strcat(str,rtrim(icar_kind));	 /*�������O*/
	       fprintf(fp0,"%s\n",str);
	       s++;

	   }
	   else if (i ==2)
	   {                  /* --�k  �H-*/
	       strcpy(str,rtrim(itag));	     /*���P���X*/
	       strcat(str,"\t");
	       strcat(str,rtrim(iassured));	 /*�Τ@�s��*/
	       strcat(str,"\t");
	       strcat(str,rtrim(icar_kind));	 /*�������O*/
	       fprintf(fp1,"%s\n",str);
	       t++;
	   }
	   
    	   if (fcar_class[0]=='2')
    	   {
    	       fprintf(fp2,"%s\n",str);
    	       v++;
    	       printf("Trace -- v = [%ld] ",  v);
    	       printf("str = [%s] \n",  str);
    	   }

       } /* End of CURSOR m1_cur_trade */
       $CLOSE m1_cur_trade;
       $FREE  m1_cur_trade;

       u++;

       if (u==1)
       {
           sprintf_s(sTmp,sizeof sTmp,"\n�i�M���r�ɡj \n");
	   rgu_put_body_string(1, sTmp, 1);
	   rgu_put_body(1); max_count++;
       }

       if (i == 1)
       {
	   $Drop Table tmp_ca_trade_302_1;
           strcpy(sFilePathOut1,rtrim(file0));

	   fclose(fp0);
	   sprintf_s(sTmp,sizeof sTmp,"�u�۵M�H�����Ҹ��M���r�ɡv -> %s�A�@ %ld �� ",sTmp0,s);
	   rgu_put_body_string(1, sTmp, 1);
	   rgu_put_body(1); max_count++;

	   rt = rptftpinsert(userid,"car302a",sTmp0);

	   if (rt != 0)
	   {
	       printf("rptftp error\n");
	       goto errexit;
	   }

       }
       else if(i == 2)
       {
	   $Drop Table tmp_ca_trade_302_2;
	   strcpy(sFilePathOut2,rtrim(file1));

	   fclose(fp1);
	   sprintf_s(sTmp,sizeof sTmp,"�u�k�H�νs +���P�M���r�ɡv -> %s�A�@ %ld �� ",sTmp1,t);
	   rgu_put_body_string(1, sTmp, 1);
	   rgu_put_body(1); max_count++;

	   rt = rptftpinsert(userid,"car302a",sTmp1);
	   if (rt != 0)
	   {
	       printf("rptftp error\n");
	       goto errexit;
	   }
       }
   } /* End of for(i=1;i<=2;i++) */
   
   fclose(fp2);
   sprintf_s(sTmp,sizeof sTmp,"�u��~���M���r�ɡv -> %s�A�@ %ld �� ",sTmp2,v);
   rgu_put_body_string(1, sTmp, 1);
   rgu_put_body(1); max_count++;

   rt = rptftpinsert(userid,"car302a",sTmp2);
   if (rt != 0)
   {
       printf("rptftp error\n");
       goto errexit;
   }

  return M_CM_OK;
errexit:
    printf("------car302a_build1: SQLCODE[%d]\n",SQLCODE);
    EWRITE(userid, SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}


long car302a_Trade_302_Step1_2(sInFilePath1,sInFilePath2)
char sInFilePath1[51],sInFilePath2[51];
{
$char sFull[30];
$char ibranch[3];
$char stmt[3000],sTmpX[101],sTmpY[101];
$char fassured[2];
FILE  *fp1,*fp2;
$char sApHome[31];
char  file1[51],file2[51];
int    rt;
char  sTmp[101];
$char sTmp0[51],sTmp1[51],sTmp2[51];
$char str[31],icar_flag[2];
long   i,s,t,u;
char  nfile1[31],nfile2[31];
$char subFile[13];
char  fManFile='0',fCarFile='0';
char  prtstr[101],tmpString[80];


   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT;
   s = t = u = 0;

   rt = getApHome(sApHome);
   if (rt < 0) {
        printf("read Config file error!!\n");
        return M_CM_READ_CONFIG_ERR;
   }

   /* Ex. subFile = 201011101748 */
   $SELECT first  1 to_char(current,'%Y%m%d%H%M')
      Into $subFile
      FROM systables WHERE 1=1;
   strcpy(subFile,rtrim(subFile));

printf("Trace -- sInFilePath1 = [%s] \n",  sInFilePath1);
printf("Trace -- sInFilePath2 = [%s] \n",  sInFilePath2);
   /* �۵M�H */
   strcpy(sInFilePath1,rtrim(sInFilePath1));
   if (strlen(sInFilePath1) > 0){

       fManFile = '1';  /* �O�_��q�H���T�ШD��:  0:�_ ,1:�O */

       $CREATE TEMP TABLE tmp_ca_trade_302_1 (
           iassured             char(12),      /* �����Ҹ� */
           icar_kind            char(1)        /* �������O */
       ) WITH NO LOG;

       /* �N�ӷ��ɮ���J temp table */
	   if ((rt=load_command1(sInFilePath1,outputf,"tmp_ca_trade_302_1","\t")) != SUCCESS){
		    printf("Loading File rt[%d]\n",rt);
		    EWRITE(userid,rt,"M_CM_LOAD_FAIL");
		    exit(FAIL);
	   }
	   printf("Loading %s to tmp_ca_trade_302 Complete!!\n",sInFilePath1);

   	   /* �]�w��X�����T�ШD�ɪ��ɦW�P���| */
       sprintf_s(nfile1,sizeof nfile1,"ISQN17_vol_man_%s",subFile);
       sprintf_s(file1,sizeof file1,"%s/rptftp/%s",sApHome,nfile1);
       printf("file1[%s]\n",file1);
	   fp1=fopen(file1,"w");

       /* 100.06 ���T���� (�Ԩ��ɮ׳̫e��������) */
       /* ���T�q�H�ШD�ɡG������Y���� */
       strcpy(prtstr,"H");
       strcat(prtstr,"IS25I");		            /* ����N�X�G�妸�d��-�۵M�H�q�H�J�`�ШD�W�� */
       strcat(prtstr,"1");                      /* �T���N�X�G1 (����"�ШD"���)              */
       strcat(prtstr,"0");                      /* �d�߫��СG0 => �אּ[����Ÿ��]�w],�A�i0�j����X�i1�j��X[\r\n] �i2�j��X[\n] */
       sprintf_s(tmpString,sizeof tmpString,"%-20s"," ");
	   strcat(prtstr,tmpString);                /* �ϥΪ̥N�X(10�X) +  �ϥΪ̱K�X(10�X)      */
       strcat(prtstr,"2");                      /* �ǿ餤��X�G2 (BIG5)                      */
       strcat(prtstr,"0");                      /* ����T�����СG0(��ƥ���L����X)         */
       sprintf_s(tmpString,sizeof tmpString,"%-33s"," ");
	   strcat(prtstr,tmpString);
	   sprintf_s(tmpString,sizeof tmpString,"%-2s"," ");           /* ����Ÿ�X(02)�G�̱�����Y��[����Ÿ��]�w]�]�w�M�w���檺��       */
	   strcat(prtstr,tmpString);                /*               �i0�j2�Ӫťաi1�j��X[\r\n] �i2�j��X1�Ӫť�+[\n] */
	   prtstr[65]='\0';                         /* �`��63 => 65                              */
	   fprintf(fp1,"%s",prtstr);
   }

   /* �k  �H */
   strcpy(sInFilePath2,rtrim(sInFilePath2));
   if (strlen(trim(sInFilePath2)) > 0){

   	   fCarFile = '1';  /* �O�_��q�����T�ШD��:  0:�_ ,1:�O */

       $CREATE TEMP TABLE tmp_ca_trade_302_2 (
           itag                 char(12),       /* ���� */
           iassured             char(12),       /* �νs */
           icar_kind            char(1)         /* �J�`���O */
       ) WITH NO LOG;

       /* �N�ӷ��ɮ���J temp table */
	   if ((rt=load_command1(sInFilePath2,outputf,"tmp_ca_trade_302_2","\t")) != SUCCESS){
		    printf("Loading File rt[%d]\n",rt);
		    EWRITE(userid,rt,"M_CM_LOAD_FAIL");
		    exit(FAIL);
	   }
	   printf("Loading %s to tmp_ca_trade_302 Complete!!\n",sInFilePath2);

   	   /* �]�w��X�����T�ШD�ɪ��ɦW�P���| */
   	   sprintf_s(nfile2,sizeof nfile2,"ISQN17_vol_car_%s",subFile);
   	   sprintf_s(file2,sizeof file2,"%s/rptftp/%s",sApHome,nfile2);
   	   printf("file2[%s]\n",file2);
       fp2=fopen(file2,"w");

       /* 100.06 ���T���� (�Ԩ��ɮ׳̫e��������) */
       /* ���T�q���ШD�ɡG������Y���� */
       strcpy(prtstr,"H");
       strcat(prtstr,"IS26I");	                /* ����N�X�G�妸�d��-�k�H�q���J�`�ШD�W�� */
       strcat(prtstr,"1");                      /* �T���N�X�G1 (����"�ШD"���)            */
       strcat(prtstr,"0");                      /* �d�߫��СG0 => �אּ[����Ÿ��]�w],�A�i0�j����X�i1�j��X[\r\n] �i2�j��X[\n] */
       sprintf_s(tmpString,sizeof tmpString,"%-20s"," ");
	   strcat(prtstr,tmpString);                /* �ϥΪ̥N�X(10�X) +  �ϥΪ̱K�X(10�X)    */
       strcat(prtstr,"2");                      /* �ǿ餤��X�G2 (BIG5)                    */
       strcat(prtstr,"0");                      /* ����T�����СG0(��ƥ���L����X)       */
       sprintf_s(tmpString,sizeof tmpString,"%-33s"," ");
	   strcat(prtstr,tmpString);
       sprintf_s(tmpString,sizeof tmpString,"%-2s"," ");           /* ����Ÿ�X(02)�G�̱�����Y��[����Ÿ��]�w]�]�w�M�w���檺��       */
	   strcat(prtstr,tmpString);                /*               �i0�j2�Ӫťաi1�j��X[\r\n] �i2�j��X1�Ӫť�+[\n] */
	   prtstr[65]='\0';                         /* �`��63 => 65                              */
	   fprintf(fp2,"%s",prtstr);
   }

   sprintf_s(sTmp,sizeof sTmp,"\n�i���T�d���ɡj\n");
   rgu_put_body_string(1, sTmp, 1);
   rgu_put_body(1); max_count++;

   /*****  ��u��ƥ�������v�A�������X���ɵ��G��T  ***/
   for(i=1;i<=2;i++){

   	   printf("Trace -- i = [%ld] \n",  i);
   	   if (i == 1){
	       if (fManFile !='1'){
	   	        continue;
	       }

		   /* ���T�q�H�ШD�ɡG��ƥ������ */
		   $DECLARE man_cur_trade CURSOR FOR
		     SELECT iassured,icar_kind
		       FROM tmp_ca_trade_302_1;
		   $OPEN man_cur_trade ;
		   for(;;){
			    $FETCH man_cur_trade INTO $iassured,$icar_kind;
			    if (SQLCODE == SQLNOTFOUND) break;

	            strcpy(prtstr,"Q");
	            sprintf_s(tmpString,sizeof tmpString,"%-10s",rtrim(iassured)); /* �ץ��������Q�X(��~�۵M�H�i��p��Q�X)*/
	            strcat(prtstr,tmpString);        /* �����Ҹ��X                 */
	            /*strcat(prtstr,"1");               �O�I���O: 1 ���ܥ��N�I���I */
	            strcat(prtstr,rtrim(icar_kind)); /* �J�`���O: 2(�T��) 3(����)  */
	            strcat(prtstr,"1");              /* �^�����O: 1 ���ܷJ�`       */
	            sprintf_s(tmpString,sizeof tmpString,"%-50s"," ");
		        strcat(prtstr,tmpString);
                sprintf_s(tmpString,sizeof tmpString,"%-2s"," ");   /* ����Ÿ�X(02)�G�̱�����Y��[����Ÿ��]�w]�]�w�M�w���檺��       */
	            strcat(prtstr,tmpString);        /*               �i0�j2�Ӫťաi1�j��X[\r\n] �i2�j��X1�Ӫť�+[\n] */
	            prtstr[65] = '\0';               /* �`��63 => 65                              */
	            fprintf(fp1,"%s",prtstr);
	            s++;
		   }
	       $CLOSE man_cur_trade;
	       $FREE  man_cur_trade;
	       fclose(fp1);
	       $Drop Table tmp_ca_trade_302_1;

           /* ��X���ɵ��G��T */
	       sprintf_s(sTmp,sizeof sTmp,"�u�۵M�H���T�d���ɮסv-> %s�A�@ %ld �� ",nfile1,s);
	       rgu_put_body_string(1, sTmp, 1);
	       rgu_put_body(1); max_count++;

	       rt = rptftpinsert(userid,"car302a",nfile1);

	       if (rt != 0){
	            printf("rptftp error\n");
	            goto errexit;
	       }
   	   }else if (i == 2){
           if (fCarFile !='1'){
	   	       continue;
	       }

		   /* ���T�q���ШD�ɡG��ƥ������ */
		   $DECLARE car_cur_trade CURSOR FOR
		     SELECT itag,iassured,icar_kind
		       FROM tmp_ca_trade_302_2;
		   $OPEN car_cur_trade ;
		   for(;;){
			   $FETCH car_cur_trade INTO $itag,$iassured,$icar_kind;
			   if (SQLCODE == SQLNOTFOUND) break;

	           strcpy(prtstr,"Q");
	           sprintf_s(tmpString,sizeof tmpString,"%-12s",rtrim(itag));
		       strcat(prtstr,tmpString);        /* ���P  */
	           /*strcat(prtstr,"1");               �O�I���O: 1 ���ܥ��N�I���I */
	           strcat(prtstr,rtrim(icar_kind)); /* �J�`���O: 2(�T��) 3(����)  */
	           strcat(prtstr,"1");              /* �^�����O: 1 ���ܷJ�`       */
	           sprintf_s(tmpString,sizeof tmpString,"%-10s",rtrim(iassured));
		       strcat(prtstr,tmpString);        /* �νs  */
	           sprintf_s(tmpString,sizeof tmpString,"%-38s"," ");
		       strcat(prtstr,tmpString);
               sprintf_s(tmpString,sizeof tmpString,"%-2s"," ");   /* ����Ÿ�X(02)�G�̱�����Y��[����Ÿ��]�w]�]�w�M�w���檺��       */
	           strcat(prtstr,tmpString);        /*               �i0�j2�Ӫťաi1�j��X[\r\n] �i2�j��X1�Ӫť�+[\n] */
	           prtstr[65] = '\0';               /* �`��63 => 65                              */

	           fprintf(fp2,"%s",prtstr);
	           t++;
		   }
	       $CLOSE car_cur_trade;
	       $FREE  car_cur_trade;
	       fclose(fp2);
	       $Drop Table tmp_ca_trade_302_2;

	       /* ��X���ɵ��G��T */
	       sprintf_s(sTmp,sizeof sTmp,"�u�k  �H���T�d���ɮסv-> %s�A�@ %ld �� ",nfile2,t);
	       rgu_put_body_string(1, sTmp, 1);
	       rgu_put_body(1); max_count++;

	       rt = rptftpinsert(userid,"car302a",nfile2);
	       if (rt != 0){
	            printf("rptftp error\n");
	            goto errexit;
	       }
   	   }

   } /* End of for(i=1;i<=2;i++) */


  return M_CM_OK;
errexit:
    printf("------car302a_build1: SQLCODE[%d]\n",SQLCODE);
    EWRITE(userid, SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* 100.06���T���� */
long car302a_Trade_302_Step2(sInFilePath1,iSrcCount,iDstCount)
char sInFilePath1[51];
long *iSrcCount,*iDstCount;
{
$char stmt[1024],sTmp[101];
$long src_count;
long  i,t,rt,tot_count;
$char iassured[13],itag[CA_TAG_NUM],iquery_num[21],sQueryDate[24],nassured[121],lia_class[3],qdmg[5],qdmg_acc[3],imsg_no[5],iacc_kind[2];
$char qdmg_lia[5],qacc_sum[3],qacc_sum_5y[3],qduty_sum_5y[3],dfirst_ply[11],qdmg_acc_sum_5y[3],fhave_newa_c_2y[2];



   $WHENEVER SQLERROR GOTO errexit;

   /* tot_count = src_count = t = 0;*/
    tot_count = 0;
    src_count = 0;
    t = 0;
    
   $CREATE TEMP TABLE tmp_ca_trade_302_2 (
       iassured        char (12)     NOT NULL,
       itag            char (12)     default ' ' ,
       icar_kind       char (1)      default ' ' ,
       iacc_kind       char (1)      default ' ' ,
       iquery_num      char (20)     default ' ' ,
       sQueryDate      char (12)     NOT NULL,
       nassured        char (120)    default ' ' ,
       qdmg            char (4)      default ' ' , /* 100.10.20 �I�Ʃίż� *//*�p�{�������d�Y�� modify by sylvia 103.10.13 */
       qdmg_acc        char (2)      default ' ' , /* 100.10.20 �T�~���ߴڦ����`�M */
       qacc_sum_5y     char (2)      default ' ' , /* �e���~�߮צ��� add by 061476 (1090803002_SC2) */
       qduty_sum_5y    char (2)      default ' ' , /* �e���~���F�d�p������ add by 061476 (1090803002_SC2) */
       dfirst_ply      char (8)      default ' ' , /* �̦���O�� add by 061476 (1090803002_SC2) */
       qdmg_acc_sum_5y char (2)      default ' ' , /* ����L�h���~�߮צ��� add by 061476 (1120220002_SC3) */
       fhave_newa_c_2y char (1)      default ' ' , /* �L�h2�~�O�_�b�s�w��O�L�T���I add by 061476 (1120220002_SC3) */    
       imsg_no         char (4)      default ' ' 
   ) WITH NO LOG;
   /*$CREATE UNIQUE INDEX idx_tmp_trade_302_u ON tmp_ca_trade_302_2(iassured,itag,icar_kind,sQueryDate);   */

   printf("Trace -- sInFilePath1 = [%s] \n",  sInFilePath1);

   /* ���N���T�^������J temp table */
   if ((rt=load_command1(sInFilePath1,outputf,"tmp_ca_trade_302_2","|")) != SUCCESS){
	    printf("Loading File rt[%d]\n",rt);
	    EWRITE(userid,rt,"M_CM_LOAD_FAIL");
	    exit(FAIL);
   }
   printf("Loading %s to tmp_ca_trade_302_2 Complete!!\n",sInFilePath1);

   $SELECT count(*) INTO $src_count FROM tmp_ca_trade_302_2;
   printf("3186 ==> src_count=[%ld]\n",src_count);

   sprintf_s(stmt,sizeof stmt,"INSERT INTO ca_trade_302 Values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,current) ");
   $PREPARE preInsertData FROM $stmt;

   sprintf_s(stmt,sizeof stmt,"DELETE FROM ca_trade_302 WHERE iassured = ? AND itag = ? And icar_kind = ? And iacc_kind = ? AND dquery = ?");
   $PREPARE preDelData FROM $stmt;

   $WHENEVER SQLERROR Continue;
   $BEGIN WORK;
   /* �A�� temp table ��J ca_trade_302 */
   $DECLARE car_cur_trade_2 CURSOR WITH HOLD FOR
     SELECT iassured,nvl(itag,' '),nvl(icar_kind,' '),nvl(iacc_kind,' '),nvl(iquery_num,' '),
            to_date(substr(sQueryDate,5,2) || '/' ||
                    substr(sQueryDate,7,2) || '/' ||
                    substr(sQueryDate,1,4) || ' ' ||
                    substr(sQueryDate,9,2) || ':' ||
                    substr(sQueryDate,11,2) ,'%m/%d/%Y %H:%M')::datetime year to minute,
            nvl(nassured,' '),nvl(qdmg,' '),nvl(qdmg_acc,' '),'00',
            nvl(qacc_sum_5y,' '),nvl(qduty_sum_5y,' '),nvl(qdmg_acc_sum_5y,' '),nvl(fhave_newa_c_2y,' '),
            to_date(substr(dfirst_ply,5,2) || '/' ||
                    substr(dfirst_ply,7,2) || '/' ||
                    substr(dfirst_ply,1,4) ,'%m/%d/%Y')::date,
            nvl(imsg_no,' ')
       FROM tmp_ca_trade_302_2;
   $OPEN car_cur_trade_2 ;
   for(;;){
   	$FETCH car_cur_trade_2 
   	  INTO $iassured,$itag,$icar_kind,$iacc_kind,$iquery_num,$sQueryDate,$nassured,
   	       $qdmg,$qdmg_acc,$idrink_note,$qacc_sum_5y,$qduty_sum_5y,$qdmg_acc_sum_5y,$fhave_newa_c_2y,
   	       $dfirst_ply,$imsg_no;
   	  if (SQLCODE == SQLNOTFOUND) break;
   	  
   	  strcpy(iassured   ,rtrim(iassured));
   	  /* strcpy(iquery_num ,rtrim(iquery_num));*/
   	  strcpy(sQueryDate ,rtrim(sQueryDate));
       
        printf("3215:iassured=[%s]itag=[%s]icar_kind=[%s]iacc_kind=[%s]\n",iassured,itag,icar_kind,iacc_kind);
        printf("3215:iquery_num=[%s]sQueryDate=[%s]nassured=[%s]qdmg=[%s]\n",iquery_num,sQueryDate,nassured,qdmg);
        printf("3215:qdmg_acc=[%s]idrink_note=[%s]imsg_no=[%s]\n",qdmg_acc,idrink_note,imsg_no);
        printf("3215:qacc_sum_5y=[%s]qduty_sum_5y=[%s]dfirst_ply=[%s]\n",qacc_sum_5y,qduty_sum_5y,dfirst_ply);
        /* �s�W6:�¤������l, 7:�¤������l�榸 add by sylvia 105.12.31 */
       if (iacc_kind[0]=='1'||iacc_kind[0]=='3'||iacc_kind[0]=='4'||iacc_kind[0]=='6'||iacc_kind[0]=='7'){       /* ����; 102.11.12 �s�W�������l�Y�����O */
	       if (atoi(qdmg) >= 0 ){
	           sprintf_s(qdmg_lia,sizeof qdmg_lia,"+%03d",atoi(qdmg)); /* +000,+001 ...*/
	       }else{
	           sprintf_s(qdmg_lia,sizeof qdmg_lia,"%04d",atoi(qdmg));  /* -001,-002 ...*/
	       }

       }else if (iacc_kind[0]=='2'){ /* ���d(�@��) */
	       if (atoi(qdmg) >= 0 ){
	           sprintf_s(qdmg_lia,sizeof qdmg_lia,"%02d",atoi(qdmg)); /* 00,01 ...*/
	       }else{
	           sprintf_s(qdmg_lia,sizeof qdmg_lia,"%d",atoi(qdmg));   /* -1,-2 ...*/
	       }
       }else if (iacc_kind[0]=='5'){ /* ���d(�p�{��) */
         strcpy(qdmg_lia, trim(qdmg)); /* �p�{���s���O�Y�� (0.2�B0.0�B-0.2�B.....) */
       }

       sprintf_s(qacc_sum,sizeof qacc_sum,"%02d",atoi(qdmg_acc));   /* -1,-2 ...*/
ReINS:
       $EXECUTE preInsertData USING $iassured,$itag,$icar_kind,$iacc_kind,$iquery_num,$sQueryDate,$nassured,
                                    $qdmg_lia,$qacc_sum,$idrink_note,$qacc_sum_5y,$qduty_sum_5y,$qdmg_acc_sum_5y,$fhave_newa_c_2y,
                                    $dfirst_ply,$imsg_no,$userid;

       printf("Trace -- iassured[%s] itag[%s] sQueryDate[%s] \n", iassured,itag,sQueryDate);
       printf("Trace -- SQLCODE = [%d] \n",  SQLCODE);

       /* ��ƭ��ƮɡA�����л\*/
       /* UNIQUE INDEX iassured + itag + icar_kind+, iacc_kind + sQueryDate */
       if (SQLCODE == -239){
       	   $EXECUTE preDelData USING $iassured,$itag,$icar_kind,$iacc_kind,$sQueryDate;
       	   goto ReINS;
       }else if (SQLCODE != 0){
       	   goto errexit;
       }

       t++;
       tot_count ++;
       printf("---3254 t=[%d]tot_count=[%d]\n",t,tot_count);
       if (t == 500)
       {
           $COMMIT WORK;
           $BEGIN WORK;
           t = 0;
       }
   }
   $CLOSE car_cur_trade_2;
   $FREE  car_cur_trade_2;
   $COMMIT WORK;
   $Drop table tmp_ca_trade_302_2;
printf("---3254 t=[%d]tot_count=[%d]src_count=[%d]\n",t,tot_count,src_count);
   *iSrcCount = src_count;
   *iDstCount = tot_count;
printf("Trace -- iSrcCount = [%ld] \n",  iSrcCount);
printf("Trace -- iDstCount = [%ld] \n",  iDstCount);
   return M_CM_OK;
errexit:
    printf("------car302a_build1: SQLCODE[%d]\n",SQLCODE);
    $WHENEVER SQLERROR Continue;
    $ROLLBACK WORK;
    EWRITE(userid, SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/*----------------------------------------------------------------------------*/
char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  char sTmp_db_name[21];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, sTmpcomp);
  }
  return sTmp_db_name;
}


/* 1.���ǤJ�� sIpolicy �����Ŧr��ɡA�h�u�p��� sIpolicy ���ߴګY�ơA�h���� lPly_Bgn�BlPly_End �Τ���F
   2.���ǤJ�� sIpolicy ���Ŧr��ɡA�h�p��Ҧ�dply_end����lPly_Bgn and lPly_End �������T��(ca_no_trade_302)�ߴګY��
   (==> �Y�����w sIpolicy�A�q�`lDExec�]�����H�����w�A�_�hlDExec�ϥΨt�Τ�N�|�y���ߴګY�ƭp��W���~�t(lDExec�P�O���p�⦳��) )
 */
long cacu_no_trade_factor(sIpolicy,lPly_Bgn,lPly_End, lDExec,sUserid,iTotCount)
$long lPly_Bgn, lPly_End, lDExec,*iTotCount;
$char sIpolicy[21],sUserid[11];
{

	$char sFull[30], ibranch[3];
    $char stmt[2049];

	$char   s_ipolicy[21]=" ";
	$date   lngDply_bgn;
	$char   s_icar_type[3]=" ";
	$double pre_pdmg_acc = 0.00 ;
	$double pre_unknown_acc = 0.00 ;
	$char   pre_lia_class[3] = "4";
	$char   fedr_class[2]=" ";
	$date   dExec;
	$int    qdmg_point, qunknown_dmg;
	$int    lia_class;
	$char   s_dupdate[21]=" ";

	$char   s_qdmg_point[5],s_qunknown_dmg[5];
	$char   s_lia_class[3];

	int     t,tot_count;
	long    rc;

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;
    printf("Trace -- cacu_no_trade_factor() Start ... \n");

	tot_count = 0;
    if (strlen(trim(sIpolicy))==0){

  	    $BEGIN WORK;
	    $DECLARE sdb_cur_no_trade CURSOR WITH HOLD FOR
          SELECT branch
            FROM servertbl
           WHERE branch != 'S1'
           ORDER BY branch;

	    $OPEN sdb_cur_no_trade ;
	    for(;;){
		    $FETCH sdb_cur_no_trade INTO $ibranch;
		    if (SQLCODE == SQLNOTFOUND) break;

		    strcpy(s_ipolicy," ");
		    strcpy(s_icar_type," ");
		    lngDply_bgn = DATENULL;
		    pre_pdmg_acc = 0.00;
		    strcpy(pre_lia_class," ");
		    strcpy(fedr_class," ");

		    strcpy(sFull,get_full_dbname(ibranch));

	        sprintf_s(stmt,sizeof stmt,
	        "SELECT x.ipolicy,a.dply_begin,a.icar_type,nvl(b.pdmg_acc,0.00),nvl(b.lia_class,'4'),nvl(a.fedr_class,' '),nvl(x.dupdate,'x'),nvl(b.punknown_acc,0.00) \n"
	        "  FROM ca_no_trade_302 x,%s:ply_relation a,%s:policy b  \n"
	        " WHERE x.ipolicy = a.ipolicy AND x.ipolicy = b.ipolicy \n"
	        "   AND x.dply_end Between %ld AND %ld ",
	          sFull,sFull, lPly_Bgn, lPly_End);
	        /*printf("Trace -- stmt = [%s] \n",  stmt);  */
			$PREPARE pre_no_trade FROM $stmt;
			$DECLARE cur_no_trade CURSOR WITH HOLD For pre_no_trade;
			$OPEN cur_no_trade;
			for(;;){
			    $FETCH cur_no_trade
			      INTO $s_ipolicy,$lngDply_bgn,$s_icar_type,$pre_pdmg_acc,$pre_lia_class,$fedr_class,$s_dupdate,$pre_unknown_acc;

			    if (SQLCODE == SQLNOTFOUND) break;
		        printf("Trace -- s_ipolicy    = [%s] \n" ,  s_ipolicy);

		        if (s_dupdate[0] != 'x') continue;  /*�H dupdate �P�_�ӵ��O�_�w�p��L�ߴګY�� */

                rc = ca_accident_record_next(s_ipolicy,lngDply_bgn,s_icar_type,pre_pdmg_acc,pre_lia_class,pre_unknown_acc,
                                             fedr_class,lDExec,&qdmg_point,&lia_class,&qunknown_dmg) ;
                if (rc != M_CM_OK){
                	printf("Trace -- sIpolicy = [%s] \n",  sIpolicy);
                	return rc;
                }
			    if (qdmg_point >= 0 ){
			        sprintf_s(s_qdmg_point,sizeof s_qdmg_point,"+%03d",qdmg_point); /* +000,+001 ...*/
			    }else{
			        sprintf_s(s_qdmg_point,sizeof s_qdmg_point,"%04d",qdmg_point);  /* -001,-002 ...*/
			    }
			    
			    if (qunknown_dmg >= 0 ){
			        sprintf_s(s_qunknown_dmg,sizeof s_qunknown_dmg,"+%03d",qunknown_dmg); /* +000,+001 ...*/
			    }else{
			        sprintf_s(s_qunknown_dmg,sizeof s_qunknown_dmg,"%04d",qunknown_dmg);  /* -001,-002 ...*/
			    }
			    
			    sprintf_s(s_lia_class,sizeof s_lia_class,"%02d",lia_class);        /* 00,01 ...*/

			    printf("s_qdmg_point=[%s]\n",s_qdmg_point);
			    printf("s_lia_class=[%s]\n",s_lia_class);

                /* �^�gca_no_trade_302 */
		        $UPDATE ca_no_trade_302
		            SET qdmg= $s_qdmg_point ,lia_class= $s_lia_class,
		                dexecute = $lDExec, iupdate = $sUserid ,dupdate = current,
		                qunknown_dmg = $s_qunknown_dmg
		        WHERE ipolicy = $s_ipolicy ;
                if (sqlca.sqlerrd[2] == 0){ /* ��s����=0 ?*/
                	 printf("Trace ���O��b update ca_no_trade_302 �ɦ^�ǵ���=0 \n");
               	 printf("Trace -- s_ipolicy = [%s] \n",  s_ipolicy);
               	 printf("Trace -- SQLCODE  = [%d] \n",  SQLCODE);
               	 return SQLCODE;
                }
                t++;
		        tot_count ++;
		        if (t == 500){
		            $COMMIT WORK;
		            $BEGIN WORK;
		            t = 0;
		        }
	        }
		    $CLOSE cur_no_trade;
		    $FREE  cur_no_trade;
	    }
	    $CLOSE sdb_cur_no_trade;
	    $FREE  sdb_cur_no_trade;
	    $COMMIT WORK;

    }else{

    	/* �p��浧�O��ߴګY�� */
        strcpy(ibranch,get_car_full_db(sIpolicy));
        strcpy(sFull , trim(get_full_dbname(ibranch)));
        printf("sFull[%s]\n" , sFull);

        sprintf_s(stmt,sizeof stmt,
        "SELECT x.ipolicy,a.dply_begin,a.icar_type,nvl(b.pdmg_acc,0.00),nvl(b.lia_class,'4'),nvl(a.fedr_class,' '),nvl(b.punknown_acc,0.00) \n"
        "  FROM ca_no_trade_302 x,%s:ply_relation a,%s:policy b  \n"
        " WHERE x.ipolicy = a.ipolicy AND x.ipolicy = b.ipolicy \n"
        "   AND x.ipolicy ='%s' ",
          sFull,sFull, sIpolicy);

		$PREPARE pre_no_trade FROM $stmt;
		$DECLARE cur_no_trade0 CURSOR WITH HOLD For pre_no_trade;
		$OPEN cur_no_trade0;
		for(;;){
		    $FETCH cur_no_trade0
		      INTO $s_ipolicy,$lngDply_bgn,$s_icar_type,$pre_pdmg_acc,$pre_lia_class,$fedr_class,$pre_unknown_acc;
		    if (SQLCODE == SQLNOTFOUND) break;

            rc = ca_accident_record_next(s_ipolicy,lngDply_bgn,s_icar_type,pre_pdmg_acc,pre_lia_class,pre_unknown_acc,
                                         fedr_class,lDExec,&qdmg_point,&lia_class,&qunknown_dmg) ;
            if (rc != M_CM_OK){
            	printf("Trace -- sIpolicy = [%s] \n",  sIpolicy);
            	return rc;
            }
            printf("Trace -- qdmg_acc  = [%d] \n", qdmg_point);
            printf("Trace -- lia_class = [%d] \n", lia_class);

		    if (qdmg_point >= 0 ){
		        sprintf_s(s_qdmg_point,sizeof s_qdmg_point,"+%03d",qdmg_point); /* +000,+001 ...*/
		    }else{
		        sprintf_s(s_qdmg_point,sizeof s_qdmg_point,"%04d",qdmg_point);  /* -001,-002 ...*/
		    }
		    
		    if (qunknown_dmg >= 0 ){
		        sprintf_s(s_qunknown_dmg,sizeof s_qunknown_dmg,"+%03d",qunknown_dmg); /* +000,+001 ...*/
		    }else{
		        sprintf_s(s_qunknown_dmg,sizeof s_qunknown_dmg,"%04d",qunknown_dmg);  /* -001,-002 ...*/
		    }
		    
		    
		    sprintf_s(s_lia_class,sizeof s_lia_class,"%02d",lia_class); /* 00,01 ...*/

		    printf("s_qdmg_point=[%s]\n",s_qdmg_point);
		    printf("s_lia_class=[%s]\n",s_lia_class);

            /* �^�gca_no_trade_302 */
	        $UPDATE ca_no_trade_302
	            SET qdmg= $s_qdmg_point ,lia_class= $s_lia_class,
	                dexecute = $lDExec, iupdate = $sUserid ,dupdate = current,
	                qunknown_dmg = $s_qunknown_dmg
	        WHERE ipolicy = $s_ipolicy ;
            if (sqlca.sqlerrd[2] == 0){ /* ��s����=0 ?*/
             	printf("Trace ���O��b update ca_no_trade_302 �ɦ^�ǵ���=0 \n");
            	printf("Trace -- s_ipolicy = [%s] \n",  s_ipolicy);
            	printf("Trace -- SQLCODE  = [%d] \n",  SQLCODE);
            	return SQLCODE;
            }
        }
	    $CLOSE cur_no_trade0;
	    $FREE  cur_no_trade0;
    }

    *iTotCount = tot_count;
    printf("Trace -- cacu_no_trade_factor() End ... \n");
    return M_CM_OK;

errexit:
    printf("------car302a_build1: SQLCODE[%d]\n",SQLCODE);
    $WHENEVER SQLERROR Continue;
    $ROLLBACK WORK;
    EWRITE(userid, SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/* ------------------------------------------------------------------------- */

long car302a_chk_car159()
{
    $char   sIcode[4], drate[11], err_buf[200], sDate1[11], sDate2[11];
    $char   stmt[1000], icar_type[3];
    $char   iroute_main[21], iofficer[11] , iins_cat[2], iyear[3];
    $double mservice, mbusiness;
    $int    mother_busi, qperiod, icount, icnt_ka01;
    $char   stitle[1000], sfilename[51];
    $long   rc;
    DBinfo *list;
    int   count_db, k;

    $WHENEVER SQLERROR GOTO errexit;
    
    /* �s�W[���s+A �B �q���N��=KA01] ���ˮ� add by sylvia 106.08.16(1060727008_C1) */
    if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
      if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
         return M_CM_NOT_DBLIST;
    }
    
    $create temp table chk_KA01
    (
        ipolicy     char(20), 
        iofficer    char(10), 
        iroute      char(20), 
        dexpire     char(10)
    ) with no log;

    $create temp table chk_renew_comp
    (
        iroute_main	char(20),
        iofficer	char(10),
        iins_cat	char(1),
        iyear		char(2),
        mservice	decimal(10,4),
        mother_busi	int,
        icar_type       char(2),
        mbusiness       decimal(10,4)
    ) with no log;

    strcpy(sParam1,trim(sParam1));
    strcpy(sDate1,cm_to_infdate(sParam1));
    strcpy(sDate2,cm_to_infdate(sParam2));
    strcpy(sIcode, " ");

    /* ���ˮ�car140�O�_�w�����..�p�S�����,�n���J�@�����q�L�ˮ֪���� */
    icount = 0;
    $select count(*) into $icount
       from car_code
      where kind = 'RN' and detail = 'car302a' and detail2 = 'D';
    if (icount == 0)
    {
        sprintf_s(stmt,sizeof stmt,
             " insert into car_code (kind, detail, detail2, chiname, engname, "
             "  icreate, dcreate, iupdate, dupdate)   "
             "   VALUES ('RN','car302a','D','0','%s', "
             "   '%s',current,'%s',current) ",userid,userid,userid);
        printf("stmt[%s]\n", stmt );
        $PREPARE ins_car302a_D FROM $stmt;
        $EXECUTE ins_car302a_D;
    }
    
    /* ---------------------------------------------------------------------- */
    /* �ˮ֡e���s�ϢϥB�q���N����KA01�f  add by sylvia 106.08.16 (1060727008_C1) */
    for(k=0;k<count_db;k++)
    {
        sprintf_s(stmt,sizeof stmt,
            "insert into chk_KA01 "
            "select a.ipolicy, a.iofficer, b.iroute, c.dexpire "
            "  from %s:ply_relation a, %s:policy b, officer c "
            " where a.ipolicy = b.ipolicy and a.iofficer = c.iofficer "
            "   and a.dply_end between '%s' and '%s' "
            "   and a.iofficer[7,7] = 'A' "
            "   and length(a.iofficer) = 7 "
            "   and c.dexpire is not null "
            "   and b.iroute = 'KA01' "
            "   and a.iofficer not in (select unique iofficer from car_renew_comp) ",
                list[k].dbname, list[k].dbname, sDate1, sDate2);
                
        printf("stmt[%s]\n", stmt );
        $PREPARE ck_ka01_1 FROM $stmt;
        $EXECUTE ck_ka01_1;
    }
    icnt_ka01 = 0;
    $select count(*) into $icnt_ka01
       from chk_KA01
      where 1=1;
    
    /* �g�@����Ƨi�DUSER */  
    if (icnt_ka01 == 0)
    {
        $insert into chk_KA01
        values ('�L�s�WKA01���',' ',' ',' ');
    }
    strcpy(stitle,"�O�渹\t �g��N��\t �q���N��\t �g�찱�Τ�\t ");
    sprintf_s(sfilename,sizeof sfilename,"KA01�g��N���ˮ�");

    sprintf_s(stmt,sizeof stmt, "select * from chk_KA01 where 1=1");

    rc = unload_file(outputf,"B",sfilename,stitle,stmt);
    if (rc != SUCCESS)
 	    return rc;
    
    /* ---------------------------------------------------------------------- */

    /* �j���I��O�O�v�N�� */
    $SELECT icode
       INTO $sIcode
       FROM ca_rate_renew
      WHERE deffect_bgn <= $sDate2
        AND deffect_end >= $sDate2
        AND fcard_class = '1';

    if (SQLCODE == SQLNOTFOUND)
    {
       sprintf_s( err_buf,sizeof err_buf, "�j���I�ͮİ϶�[%s ~ %s] �O�v�ͮĥN����Ƥ��s�b", sParam1,sParam2);
       EWRITE(userid,M_CA_NRATE_DATE, err_buf);
       return M_CA_NRATE_DATE;
    }

    /* �j���I�O�v�ͮĤ� */
	$select drate into $drate
	   from ca_rate_date
      where icode = $sIcode
        and itable = 'compulsory_premium';

    sprintf_s(stmt,sizeof stmt, "select iroute_main, iofficer , iins_cat, iyear,  "
                          "decode(iins_cat,'Z',round(iyear*12,0),12), "
                          "mservice,  mother_busi  from car_renew_comp where 1=1 ");

    printf("stmt[%s]\n",stmt);
    icount = 0;
    $PREPARE pre_9_1 FROM $stmt;
    $DECLARE cur_9_1 CURSOR FOR pre_9_1;
    $OPEN cur_9_1;
    for(;;)
    {
        $FETCH cur_9_1 INTO $iroute_main, $iofficer , $iins_cat, $iyear,
                            $qperiod, $mservice, $mother_busi;
        if (SQLCODE == SQLNOTFOUND) break;

        $select first 1 icode into $icar_type
          from cu_code_data
         where itype = '97'
           and ncode = $iins_cat;

        $select sum(mbusiness) into $mbusiness
           from compulsory_premium
          where drate = $drate
            and icar_type = $icar_type
            and qperiod <= $qperiod;
        if (SQLCODE == SQLNOTFOUND) mbusiness = 0.0;

        if ((mservice + mother_busi*1.0) > mbusiness)
        {
            $insert into chk_renew_comp
                (iroute_main, iofficer, iins_cat, iyear, mservice,
                 mother_busi, icar_type, mbusiness)
             values
                ($iroute_main, $iofficer , $iins_cat, $iyear, $mservice,
                 $mother_busi, $icar_type, $mbusiness);

            icount++;
        }
    }
    $CLOSE cur_9_1;
    $FREE  cur_9_1;
    
    /* �S���W�Ъ�, �g�@�y�ܸӨϥΪ̪��D */
    if (icount == 0)
    {
        $insert into chk_renew_comp
            (iroute_main, iofficer, iins_cat, iyear, mservice,
             mother_busi, icar_type, mbusiness)
         values
            ('�ˮֵL�~!', ' ' , ' ', ' ', 0,
              0, ' ', 0);
    }
    printf("icnt_ka01=[%d]icount=[%d]\n",icnt_ka01,icount);

    /* if (icount > 0) */
    /* �W�Щ�KA01�����,�������O modify by sylvia 106.08.16 (1060727008_C1) */
    if ((icount+icnt_ka01) > 0)
    {
        sprintf_s(stmt,sizeof stmt,
             " update  car_code set chiname = '0', engname = '%s' "
             "  where kind = 'RN' and detail = 'car302a' and detail2 = 'D' ",userid);
        printf("stmt[%s]\n", stmt );
        $PREPARE upd_car302a_D0 FROM $stmt;
        $EXECUTE upd_car302a_D0;
    }
    else
    {
        sprintf_s(stmt,sizeof stmt,
             " update  car_code set chiname = '1', engname = '%s' "
             "  where kind = 'RN' and detail = 'car302a' and detail2 = 'D' ",userid);
        printf("stmt[%s]\n", stmt );
        $PREPARE upd_car302a_D1 FROM $stmt;
        $EXECUTE upd_car302a_D1;
    }

    strcpy(stitle,"�D�q���N��\t �g��N��\t �����I�O\t �~��\t ����O\t ");
    strcat(stitle,"��L�~�ȶO��\t ���إN��(car101)\t �W���~�ȶO��(car101)\t ");

    sprintf_s(sfilename,sizeof sfilename,"��O�j���I�~�ȱ����ˮ�");

    sprintf_s(stmt,sizeof stmt, "select * from chk_renew_comp where 1=1");

    rc = unload_file(outputf,"A",sfilename,stitle,stmt);
    if (rc != SUCCESS)
 	    return rc;


    return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(1);
}

/* ����~�����ഫ�ˮ� (car644) */
long car302a_chk_car644()
{
    $char   err_buf[200], sDate1[11], sDate2[11];
    $char   stmt[1000], ipolicy[21], iengine[CA_ENGINE_NUM], icar_type_ori[3],
            icar_type_new[3], iroute[21];
    $char   stitle[1000], sfilename[51];
    DBinfo *list;
    int   count_db, k, rc, icount;

    $WHENEVER SQLERROR GOTO errexit;

    if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
      if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
         return M_CM_NOT_DBLIST;
    }

    $create temp table tp_ca6441
    (
        ipolicy         char(20) default ' ',       /* ���N�I�O�渹 */
        iengine         char(25) default ' ',       /* ������ */
        icar_type_ori   char(2) default ' ',        /* ��O�樮�� */
        icar_type_new   char(2) default ' ',    /* �ഫ�ᨮ�� */
        iroute          char(20) default ' '       /* �q���N�� */
    )with no log;

    strcpy(sParam1,trim(sParam1));
    strcpy(sParam2,trim(sParam2));
    strcpy(sDate1,cm_to_infdate(sParam1));
    strcpy(sDate2,cm_to_infdate(sParam2));
    icount = 0;
    for(k=0;k<count_db;k++)
    {
        /* ���N�I�O�� */
	    sprintf_s(stmt,sizeof stmt,"select a.ipolicy, a.iengine, a.icar_type_ori, a.icar_type_new, a.iroute "
	                  " from ca_exception a, %s:ply_relation b "
	                  "where a.ipolicy = b.ipolicy "
	                  "  and b.fcard_class = '2' "
	                  "  and b.dply_end >= '%s' "
	                  "  and b.dply_end <= '%s' ",
	                     list[k].dbname, sDate1, sDate2 );
	    printf("stmt[%s]\n", stmt);

        $PREPARE pre_A1 FROM $stmt;
        $DECLARE cur_A1 CURSOR for pre_A1;
      	$OPEN cur_A1;
      	while(1)
      	{
         	$FETCH cur_A1 INTO $ipolicy, $iengine, $icar_type_ori, $icar_type_new, $iroute;
         	if(SQLCODE == SQLNOTFOUND) break;

         	icount++;
         	$insert into tp_ca6441
         	 values ($ipolicy, $iengine, $icar_type_ori, $icar_type_new, $iroute);
        }
        $close cur_A1;
        $free cur_A1;
    }



    if (icount == 0)
    {
        /* �S���W�Ъ�, �g�@�y�ܸӨϥΪ̪��D */
        $insert into tp_ca6441 (ipolicy) values ('�L���');
    }

    strcpy(stitle,"�O�渹\t ������\t �ഫ�e����\t �ഫ�ᨮ��\t �q���N��\t ");

    sprintf_s(sfilename,sizeof sfilename,"����~�����ഫ����");

    sprintf_s(stmt,sizeof stmt, "select * from tp_ca6441 where 1=1");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);
    if (rc != SUCCESS)
 	    return rc;


    return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(1);
}

/* -------------------------------------------------------------------------- */
/* RBA�����I�ˮ�  add by sylvia 106.08.11 (1060606002_C5) */
/* �W�[�F�d�����ˮ� add by sylvia 106.09.11 (1060726001_C1) */
/* ISID�PRBA�G��O�u��RBA�A���ݷs�W�����I�W��L�o����(ca_risk) 
   add by 061476 (1061012002_SC5)*/
long car302a_chk_RBA()
{
    $char   err_buf[200], sDate1[11], sDate2[11],sDate3[11], sDate4[11];
    $char   stmt[1000] ;
    $char   stitle[1000], sfilename[51];
    DBinfo *list;
    int   count_db, k, rc;
    $int    mprem, icount;
    $char   ipolicy[21], bzfrom[3], iroute[21], iassured[13], nassured[121], 
            fassured[2], dbirth[11], iassured_cntry[2], iassured_rba[2],
            foccup[2], noccup[6], noccup_rba[6], iapplicant[12], napplicant[121], 
            fapplicant[2], dbirth_appl[11], iapplicant_cntry[2], iapplicant_rba[2],
            applicant_foccup[2], applicant_noccup[6],applicant_noccup_rba[6], 
            fsame_one[2], fHiRBA[2], errmsg[51], fresult[2], nresult[121];
    long  rtncode;

    $WHENEVER SQLERROR GOTO errexit;

    if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
      if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
         return M_CM_NOT_DBLIST;
    }
    
    $create temp table tp_rba
    (
        ipolicy      char(20),       -- �O�渹
        iassured     char(12),       -- �Q�O�HID
        nassured     varchar(120),   -- �Q�O�H�W��
        dbirth       char(10),       -- �Q�O�H�ͤ�
        iassured_cntry   char(1),    -- �����I��a(�Q�O�H)
        iassured_rba char(1),        -- �����I��a(�Q�O�H)(�ରY/N)
        iapplicant   char(12),       -- �n�O�HID
        napplicant   varchar(120),   -- �n�O�H�W��
        dbirth_appl  char(10),       -- �n�O�H�ͤ�
        iapplicant_cntry char(1),    -- �����I��a(�n�O�H)
        iapplicant_rba   char(1),    -- �����I��a(�n�O�H)(�ରY/N)
        fsame_one    char(1)         -- �n�B�Q�O�H�O�_�P�@�H   
    )with no log;
    
    /* �F�d���ʰO�� add by sylvia 106.09.11(1060726001_C1) */
    /* �s�W������ add by 061476 108.09.11(1080814009_SC1) */
    $create temp table tp_chg_dudy
    (
        ipolicy         char(20),   -- �O�渹
        dply_begin      date,       -- �_�O��
        dply_end        date,       -- ���O��
        itag            char(12),   -- ���P
        iengine         char(25),   -- ������
        iclaim          char(20),   -- �߮׸�
        ifield          char(10),   -- �F�d�������O
        ndata_before    char(1),    -- �ק�e���
        ndata_after     char(1),    -- �ק����
        dcreate         char(25),   -- ���ʤ��  
        iofficer        char(10),   -- �g��N��
        nleader         char(10),   -- �޲z�H�W��
        iassured        char(12),   -- �Q�O�HID
        daccident       char(25)    -- �X�I���
    )with no log;

    strcpy(sParam1,trim(sParam1));
    strcpy(sParam2,trim(sParam2));
    strcpy(sDate1,cm_to_infdate(sParam1));
    strcpy(sDate2,cm_to_infdate(sParam2));
    icount = 0;    
    
    /* ���ˮ�car140�O�_�w�����..�p�S�����,�n���J�@�����q�L�ˮ֪���� */
    icount = 0;
    $select count(*) into $icount
       from car_code
      where kind = 'RN' and detail = 'car302a' and detail2 = 'E';
    if (icount == 0)
    {
        sprintf_s(stmt,sizeof stmt,
             " insert into car_code (kind, detail, detail2, chiname, engname, "
             "   icreate, dcreate, iupdate, dupdate)   "
             "   VALUES ('RN','car302a','E','0','RBA�����I�ˮ�', "
             "   '%s',current,'%s',current) ",userid,userid);
        printf("stmt[%s]\n", stmt );
        $PREPARE ins_car302a_E FROM $stmt;
        $EXECUTE ins_car302a_E;
    }

    /* �z�߲��ʰ϶� add by sylvia 106.09.11 (1060726001_C1) */
    $select first 1 add_months(date($sDate1),-3),add_months(date($sDate2),-3)
       into $sDate3, $sDate4
       from car_code  where 1=1;


    for(k=0;k<count_db;k++)
    {
        /* ���X�Ҧ��O��-RBA */    
        sprintf_s(stmt,sizeof stmt,
	        "insert into tp_rba "
	        "select a.ipolicy, b.iassured, b.nassured, b.dbirth, b.iassured_cntry,  "
                "       decode(b.iassured_cntry,'1','Y','N'), b.iapplicant, b.napplicant,  "
                "       b.dbirth_appl, b.iapplicant_cntry, decode(b.iapplicant_cntry,'1','Y','N'),  "
                "       case when b.iassured = b.iapplicant then 'Y' else 'N' end "
                " from %s:ply_relation a, %s:policy b "
                " where a.ipolicy = b.ipolicy and a.dply_end between '%s' and '%s' ",
            list[k].dbname, list[k].dbname, sDate1, sDate2 );
	    printf("stmt[%s]\n", stmt);

        $PREPARE get_ply1 FROM $stmt;
        $EXECUTE get_ply1;
        
        /* �F�d���ʽ߮� add by sylvia 106.09.11 (1060726001_C1) */
        sprintf_s(stmt,sizeof stmt,
	        "insert into tp_chg_dudy "
	        "select b.ipolicy, c.dply_begin, c.dply_end, d.itag, d.iengine, "
	        "       a.iclaim,  decode(a.ifield,1,'����',2,'���d',' '), "
	        "       a.ndata_before, a.ndata_after, a.dcreate, c.iofficer, "
	        "       (select nname from officer where iofficer = c.ileader), "
	        "       d.iassured, b.daccident "
                "from ca_clm_upd_log a, ca_clm_process b, %s:ply_relation c, %s:policy d "
                "where a.iclaim = b.iclaim  "
                " and b.ipolicy = c.ipolicy and c.ipolicy = d.ipolicy "
                " and c.fcard_class = '2'   and a.ifield in ('1','2') "
                " and date(a.dcreate) between '%s' and '%s' "
                " and c.dply_end between '%s' and '%s' ",
                list[k].dbname, list[k].dbname, sDate3, sDate4, sDate1, sDate2);
	    printf("stmt[%s]\n", stmt);
	    
 
        $PREPARE get_clm1 FROM $stmt;
        $EXECUTE get_clm1;
    }

    /* �ŦXRBA�����I�Ӽ� */
    icount = 0;
    $select count(*) into $icount from tp_rba where 1=1;
    if (icount == 0)
    {
        /* �����I���, �g�@�y�ܸӨϥΪ̪��D */
        $insert into tp_rba2 (ipolicy) values ('�L�����I���');
    }
    else
    {
        icount = 0;
        
        $DECLARE chk_rba1 CURSOR for
            select * from tp_rba;
        $OPEN chk_rba1 ;
        for(;;)
        {
            $FETCH chk_rba1 
              INTO $ipolicy, $iassured, $nassured, $dbirth, $iassured_cntry, 
                   $iassured_rba, $iapplicant, $napplicant, 
                   $dbirth_appl, $iapplicant_cntry, $iapplicant_rba, 
                   $fsame_one;
            if (SQLCODE == SQLNOTFOUND) break;
            
            strcpy(errmsg, " ");
            
            if(strcmp(fsame_one,"Y") == 0)
            {
            	rtncode = cm_check_simple_RBA(iassured, nassured, dbirth, iassured_rba, fresult, nresult);
	
            	$insert into sysdb:ca_risk values
            	($ipolicy, $iassured, $nassured, $dbirth, $iassured_cntry, $iassured_rba, 
            	 "3", $fresult, $nresult, $userid, current, $userid, current);
            }
            else  /* �n�B�Q�O���P�H */
            {
            	rtncode = cm_check_simple_RBA(iassured, nassured, dbirth, iassured_rba, fresult, nresult);
            	
            	$insert into sysdb:ca_risk values
            	($ipolicy, $iassured, $nassured, $dbirth, $iassured_cntry, $iassured_rba, 
            	 "2", $fresult, $nresult, $userid, current, $userid, current);
            	
            	rtncode = cm_check_simple_RBA(iapplicant, napplicant, dbirth_appl, iapplicant_rba, fresult, nresult);
            	
            	$insert into sysdb:ca_risk values
            	($ipolicy, $iapplicant, $napplicant, $dbirth_appl, $iapplicant_cntry, $iapplicant_rba, 
            	 "1", $fresult, $nresult, $userid, current, $userid, current);
            }

        }/* end for */
                
        $select ipolicy, imember, nmember, imember_cntry, nresult from sysdb:ca_risk 
          where fresult = 'S' and dcreate::date = today into temp tp_rba2 with no log;
          
        $select count(*) into $icount from tp_rba2 where 1=1;
        if (icount == 0)
        {
            /* �����I���, �g�@�y�ܸӨϥΪ̪��D */
            $insert into tp_rba2 (ipolicy) values ('�L�����I���');
        }
    }
    
    sprintf_s(stmt,sizeof stmt,
             " update  car_code set chiname = '1', engname = '%s' "
             "  where kind = 'RN' and detail = 'car302a' and detail2 = 'E' ",userid);
        printf("stmt[%s]\n", stmt );
        $PREPARE upd_car302a_E1 FROM $stmt;
        $EXECUTE upd_car302a_E1;

    strcpy(stitle,"�O�渹\t�n�B�Q�O�HID\t�n�B�Q�O�H�m�W\t�n�B�Q�O�H��O\t�n�B�Q�O�H�T��\t");
    sprintf_s(sfilename,sizeof sfilename,"RBA�����I�ˮ�");

    sprintf_s(stmt,sizeof stmt, "select * from tp_rba2 where 1=1 order by ipolicy ");

    rc = unload_file(outputf,"A",sfilename,stitle,stmt);
    if (rc != SUCCESS)
 	    return rc;

    /* ---------------------------------------------------------------- */
    /* �ŦX�ŦX�F�d���ʽ߮� add by sylvia 106.09.11 (1060726001_C1) */
    icount = 0;
    $select count(*) into $icount from tp_chg_dudy where 1=1;
    if (icount == 0)
    {
        /* �g�@�y�ܸӨϥΪ̪��D */
        $insert into tp_rba2 (ipolicy) values ('�d�L�F�d���ʸ��');
    }
    
    strcpy(stitle,"�O�渹\t�_�O��\t���O��\t���P\t������\t�߮׸�\t�F�d�������O\t");
    strcat(stitle,"�ק�e���\t�ק����\t�F�d���ʤ��\t�g��N��\t�޲z�H�W��\t");
    strcat(stitle,"�Q�O�I�HID\t�X�I���\t");
    sprintf_s(sfilename,sizeof sfilename,"�F�d�����ˮ�");

    sprintf_s(stmt,sizeof stmt, "select * from tp_chg_dudy where 1=1 order by nleader,ipolicy, iclaim, dcreate ");

    rc = unload_file(outputf,"B",sfilename,stitle,stmt);
    if (rc != SUCCESS)
 	    return rc;
    

    return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(1);
}

int strFileNameReplace(char *string,char *searchString,char *replaceString)
 {
 char *currP, *baseStr;
 int  count = 0;
 $char tmp_currP[60001];
 currP = baseStr = NULL;

 while (*string)
      {
      currP = strstr (!currP ? string : baseStr, searchString);

      if (currP)
           {
           count++;
           baseStr = (currP + strlen (replaceString));

            /* strcpy (currP, (currP + strlen (searchString))); */

	   strcpy (tmp_currP, (currP + strlen (searchString)));
	   strcpy (currP, tmp_currP);

           memmove (currP + strlen (replaceString),
                      currP, strlen (currP) + 1);
           memcpy (currP, replaceString, strlen (replaceString));
           
           strcpy (currP, ltrim(currP));	/* �t�X���XBug�ק�����ɩ��󴫰��D */
           }
      else
           break;
      }

 return count;
 }





