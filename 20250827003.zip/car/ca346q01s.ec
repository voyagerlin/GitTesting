/**********************************************************************/
/*   program id   : ca346q01s.ec                                      */
/*   program name : �֫O���v�ޱ�                                      */
/*   date written : 2015/01/10 by 030344                              */
/*   files        : ply_relation                                      */
/*                                                                    */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
$include sqlca; 
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"

#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"

$include decimal;


int   count_db,k;
$char dentry[11],dentry_s[11];
$char ibranch[7];

$char itag_in[CA_TAG_NUM];
$char iengine[CA_ENGINE_NUM];
$char iassured[13];
$char payment[2];

$char chkComp[2]; /* 1020307002 C2 */

char  outputf[21];
$char userid[11];
$char DBName[05];
$char msgbuf[128];
$char iquota[7];
$char option[2];
$char fins_grp[2];
$char falldb[2];

$char stmt_tmp[1024];

DBinfo *list;
/*--------------------------------------------------------------------*/

main(argc, argv)
int argc;
char **argv;
{
    int rc;

    batchinit();
    strcpy(DBName,    isNULLstr(argv[1]));
    strcpy(userid,    isNULLstr(argv[2]));
    strcpy(option,    isNULLstr(argv[3]));
    strcpy(ibranch,   isNULLstr(argv[4]));
    strcpy(dentry_s,  isNULLstr(argv[5]));
    strcpy(dentry,    isNULLstr(argv[6]));
    strcpy(fins_grp,  isNULLstr(argv[7]));
    strcpy(outputf,   isNULLstr(argv[8]));

printf("dentry_s[%s]dentry[%s];ibranch[%s];itag_in[%s];iengine[%s];iassured[%s];\n",dentry_s,dentry,ibranch,itag_in,iengine,iassured);

    rc = car346_get_db();
    if (rc != M_CM_OK)
       return rc;
    
    rc = car346_privilege();
    if (rc != M_CM_OK)
       return rc;

    /* Create table car346_tmp1 */
    rc = ca346_create_temp();
    if (rc != M_CM_OK)
       return rc;       

printf("falldb=[%s]\n",falldb);
    
    if(strcmp(trim(falldb),"Y")==0)
    {
    	/*prepare data for report*/
    	rc = car346_prepare_data_ALL();
    	if (rc != M_CM_OK)
        return rc;
    }
    else
    {
    	/*prepare data for report*/
    	rc = car346_prepare_data();
    	if (rc != M_CM_OK)
       	return rc;
    }

    /*build report - ����*/
    rc = car346_build();
    if (rc != M_CM_OK) {
       return rc;
    }
}

/*--------------------------------------------------------------------*/
long car346_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }

   if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
      if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
         return M_CM_NOT_DBLIST;
   }
 
   return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/
long car346_prepare_data_ALL()
{

   $char ipolicy[21],iquota[7],nassured[121],icard[21],itag[CA_TAG_NUM],iengine[CA_ENGINE_NUM],iassured[13];
   $char icar_type[3],iins_type[7],iofficer[11],nofficer[121],nleader[120],qnext[11],nquota[121];
   $char iassured1[14],icar_type1[4],iins_type1[8],iofficer1[12];
   $char sWhere[256];
   $long dpolicy = 0,dply_begin = 0,dply_end = 0,minjured_cover = 0,mdeath_cover = 0,mdamage_cover = 0,mins_premium = 0;
   $char  dentry_cond[11],dentry_s_cond[11];
   $char  stmt[4096];
   
   strcpy(dentry_cond,cm_to_infdate(dentry));
   strcpy(dentry_s_cond,cm_to_infdate(dentry_s));
  
   
   $WHENEVER SQLERROR GOTO errexit;
   
   if (db_select(DBName) == FALSE)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return FAIL;
   } 

printf("prepared data, dentry_cond[%s]dentry_s_cond[%s]\n",dentry_cond,dentry_s_cond);

	if( strcmp(trim(option),"1") == 0)
            sprintf_s(sWhere, sizeof sWhere, " and b.iquota matches '%s' ",ibranch);
        else
            sprintf_s(sWhere, sizeof sWhere, " and a.ipolicy[1,3] matches '%s' ",ibranch);

printf("sWhere=[%s]\n",sWhere);
	
    for(k=0;k<count_db;k++)
    {
    	/*******************�����I***********************/
	if(strcmp(trim(fins_grp),"1") == 0)
	{
	/*******************�̷s�O����***********************/
	 sprintf_s(stmt, sizeof stmt,
		"SELECT b.dpolicy,b.iquota,a.ipolicy, a.icard,a.nassured,a.itag,a.iengine,a.iassured,    "
		"       b.dply_begin,b.dply_end,b.icar_type,c.iins_type,c.minjured_cover,c.mdeath_cover, "
		"       c.mdamage_cover ,c.mins_premium,b.iofficer, "
		"       (SELECT nname FROM officer WHERE iofficer = b.iofficer), "
		"       (SELECT nname FROM officer WHERE iofficer = b.ileader),  "
		"       CASE qnext_year WHEN '0' THEN '�s�O' ELSE '��O' END     "
		"  FROM %s:policy a,%s:ply_relation b ,%s:ply_ins_type c "
		" WHERE a.ipolicy = b.ipolicy      "
		"   AND a.ipolicy = c.ipolicy      "
		"   AND b.dply_close is not null   "
		"   AND c.mdamage_cover >= 3000000 "
		"   AND c.iins_type IN (select detail from car_code where kind IN ('40'))"
		"   AND b.dpolicy BETWEEN '%s' and '%s' "
		"   %s                                  "
		,list[k].dbname,list[k].dbname,list[k].dbname,dentry_s_cond,dentry_cond,sWhere);

printf("stmt[%s]\n", stmt);
	 
          $PREPARE pre1 FROM $stmt;
          $DECLARE cur_pre1 CURSOR for pre1;        	 
      	  $OPEN cur_pre1;

      		while(1)
      		{
         		$FETCH cur_pre1 INTO $dpolicy,$iquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured,$dply_begin,
         				     $dply_end,$icar_type,$iins_type,$minjured_cover,$mdeath_cover,$mdamage_cover,
         				     $mins_premium,$iofficer,$nofficer,$nleader,$qnext;
         			       			
         		if(SQLCODE == SQLNOTFOUND) break;
         		
         		$SELECT nbranch
         		   INTO $nquota
         		   FROM sa_branch_type 
         		  WHERE ibranch = $iquota;
         		  
         		 if(SQLCODE == SQLNOTFOUND) strcpy(nquota," ");

			strcpy(nassured,trim(nassured));
			strcpy(nofficer,trim(nofficer));
			strcpy(nleader,trim(nleader));
              		
              		/**���X�Ĥ@�X��0�A�����bexcel show �X*/
              		strcpy(iassured1, "�");
              		strcat(iassured1,trim(iassured));
              		
              		strcpy(icar_type1, "�");
              		strcat(icar_type1,trim(icar_type));
              		
              		strcpy(iins_type1, "�");
              		strcat(iins_type1,trim(iins_type));
              		
              		strcpy(iofficer1, "�");
              		strcat(iofficer1,trim(iofficer));
              		

			$INSERT INTO car346_tmp1
	          		     (dpolicy,nquota,ipolicy,icard,nassured,itag,iengine,iassured,dply_begin,
         			      dply_end,icar_type,iins_type,minjured_cover,mdeath_cover,mdamage_cover,
         		              mins_premium,iofficer,nofficer,nleader,qnext,ply)
			      VALUES
	          		     ($dpolicy,$nquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured1,$dply_begin,
         			      $dply_end,$icar_type1,$iins_type1,$minjured_cover,$mdeath_cover,$mdamage_cover,
         			      $mins_premium,$iofficer1,$nofficer,$nleader,$qnext,'�̷s�O��');
		}
          	$CLOSE cur_pre1;
          	$FREE cur_pre1;
          	
         /*******************�h�O���Ƨ��***********************/
         sprintf_s(stmt, sizeof stmt,
		"SELECT UNIQUE a.ipolicy , c.iins_type   "
		"  FROM %s:policy a,%s:ply_relation b ,%s:ply_ins_type c "
		" WHERE a.ipolicy = b.ipolicy      "
		"   AND a.ipolicy = c.ipolicy      "
		"   AND b.dply_close is not null   "
		"   AND (c.minjured_cover + c.mdeath_cover + c.mdamage_cover) = 0 "
		"   AND c.iins_type IN (select detail from car_code where kind IN ('40'))"
		"   AND b.dpolicy BETWEEN '%s' and '%s' "
		"   %s                                  "
		,list[k].dbname,list[k].dbname,list[k].dbname,dentry_s_cond,dentry_cond,sWhere);

printf("stmt[%s]\n", stmt);
	 
          $PREPARE pre1_1 FROM $stmt;
          $DECLARE cur_pre1_1 CURSOR for pre1_1;        	 
      	  $OPEN cur_pre1_1;

      		while(1)
      		{
         		$FETCH cur_pre1_1 INTO $ipolicy,$iins_type;
         			       			
         		if(SQLCODE == SQLNOTFOUND) break;
         		
         		sprintf_s(stmt, sizeof stmt,
				"SELECT b.dpolicy,b.iquota,a.ipolicy, a.icard,a.nassured,a.itag,a.iengine,a.iassured,    "
				"       b.dply_begin,b.dply_end,b.icar_type,c.iins_type,c.minjured_cover,c.mdeath_cover, "
				"       c.mdamage_cover ,c.mins_premium,b.iofficer, "
				"       (SELECT nname FROM officer WHERE iofficer = b.iofficer), "
				"       (SELECT nname FROM officer WHERE iofficer = b.ileader),  "
				"       CASE qnext_year WHEN '0' THEN '�s�O' ELSE '��O' END     "
				"  FROM %s:original_ply a,%s:ori_ply_relation b ,%s:ori_ins_type c "
				" WHERE a.ipolicy = b.ipolicy      "
				"   AND a.ipolicy = c.ipolicy      "
				"   AND b.dply_close is not null   "
				"   AND c.mdamage_cover >= 3000000 "
				"   AND c.iins_type IN (select detail from car_code where kind IN ('40'))"
				"   AND a.ipolicy = '%s'                "
				"   AND c.iins_type = '%s'              "
				,list[k].dbname,list[k].dbname,list[k].dbname,ipolicy,iins_type);
				
				$PREPARE pre1_2 FROM $stmt;
          			$DECLARE cur_pre1_2 CURSOR for pre1_2;        	 
      	  			$OPEN cur_pre1_2;
      	  			
      	  			while(1)
      	  			{
      	  			 $FETCH cur_pre1_2 INTO $dpolicy,$iquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured,$dply_begin,
         				                $dply_end,$icar_type,$iins_type,$minjured_cover,$mdeath_cover,$mdamage_cover,
         				                $mins_premium,$iofficer,$nofficer,$nleader,$qnext;
         				              
         			 if(SQLCODE == SQLNOTFOUND) break;
         			 
         			 $SELECT nbranch
         		   	    INTO $nquota
         		            FROM sa_branch_type 
         		           WHERE ibranch = $iquota;
         		           
         		           if(SQLCODE == SQLNOTFOUND) strcpy(nquota," ");
         		           
         		           /**���X�Ĥ@�X��0�A�����bexcel show �X*/
              			   strcpy(iassured1, "�");
              			   strcat(iassured1,trim(iassured));
              		
              			   strcpy(icar_type1, "�");
              			   strcat(icar_type1,trim(icar_type));
              		
              			   strcpy(iins_type1, "�");
              			   strcat(iins_type1,trim(iins_type));
              		
              			   strcpy(iofficer1, "�");
              			   strcat(iofficer1,trim(iofficer));

			$INSERT INTO car346_tmp1
	          		     (dpolicy,nquota,ipolicy,icard,nassured,itag,iengine,iassured,dply_begin,
         			      dply_end,icar_type,iins_type,minjured_cover,mdeath_cover,mdamage_cover,
         		              mins_premium,iofficer,nofficer,nleader,qnext,ply)
			      VALUES
	          		     ($dpolicy,$nquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured1,$dply_begin,
         			      $dply_end,$icar_type1,$iins_type1,$minjured_cover,$mdeath_cover,$mdamage_cover,
         			      $mins_premium,$iofficer1,$nofficer,$nleader,$qnext,'��l�O��');	    
      	  			}
      	  			$CLOSE cur_pre1_2;
          			$FREE cur_pre1_2;
       	
		}
          	$CLOSE cur_pre1_1;
          	$FREE cur_pre1_1;         
        }
        else if(strcmp(trim(fins_grp),"2") == 0)
        {
         /*******************�ѵs�I*****************************/
         /*******************�̷s�O����***********************/
	 sprintf_s(stmt, sizeof stmt,
		"SELECT b.dpolicy,b.iquota,a.ipolicy, a.icard,a.nassured,a.itag,a.iengine,a.iassured,    "
		"       b.dply_begin,b.dply_end,b.icar_type,c.iins_type,c.minjured_cover,c.mdeath_cover, "
		"       c.mdamage_cover ,c.mins_premium,b.iofficer, "
		"       (SELECT nname FROM officer WHERE iofficer = b.iofficer), "
		"       (SELECT nname FROM officer WHERE iofficer = b.ileader),  "
		"       CASE qnext_year WHEN '0' THEN '�s�O' ELSE '��O' END     "
		"  FROM %s:policy a,%s:ply_relation b ,%s:ply_ins_type c "
		" WHERE a.ipolicy = b.ipolicy      "
		"   AND a.ipolicy = c.ipolicy      "
		"   AND b.dply_close is not null   "
		"   AND c.mdamage_cover >= 3000000 "
		"   AND c.iins_type IN (select detail from car_code where kind IN ('41'))"
		"   AND b.dpolicy BETWEEN '%s' and '%s' "
		"   %s                                  "
		,list[k].dbname,list[k].dbname,list[k].dbname,dentry_s_cond,dentry_cond,sWhere);

printf("stmt[%s]\n", stmt);
	 
          $PREPARE pre2 FROM $stmt;
          $DECLARE cur_pre2 CURSOR for pre2;        	 
      	  $OPEN cur_pre2;

      		while(1)
      		{
         		$FETCH cur_pre2 INTO $dpolicy,$iquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured,$dply_begin,
         				     $dply_end,$icar_type,$iins_type,$minjured_cover,$mdeath_cover,$mdamage_cover,
         				     $mins_premium,$iofficer,$nofficer,$nleader,$qnext;
         			       			
         		if(SQLCODE == SQLNOTFOUND) break;
         		
         		$SELECT nbranch
         		   INTO $nquota
         		   FROM sa_branch_type 
         		  WHERE ibranch = $iquota;
         		  
         		if(SQLCODE == SQLNOTFOUND) strcpy(nquota," ");
         		
         		/**���X�Ĥ@�X��0�A�����bexcel show �X*/
              		strcpy(iassured1, "�");
              		strcat(iassured1,trim(iassured));
              		
              		strcpy(icar_type1, "�");
              		strcat(icar_type1,trim(icar_type));
              		
              		strcpy(iins_type1, "�");
              		strcat(iins_type1,trim(iins_type));
              		
              		strcpy(iofficer1, "�");
              		strcat(iofficer1,trim(iofficer));

			$INSERT INTO car346_tmp1
	          		     (dpolicy,nquota,ipolicy,icard,nassured,itag,iengine,iassured,dply_begin,
         			      dply_end,icar_type,iins_type,minjured_cover,mdeath_cover,mdamage_cover,
         		              mins_premium,iofficer,nofficer,nleader,qnext,ply)
			      VALUES
	          		     ($dpolicy,$nquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured1,$dply_begin,
         			      $dply_end,$icar_type1,$iins_type1,$minjured_cover,$mdeath_cover,$mdamage_cover,
         			      $mins_premium,$iofficer1,$nofficer,$nleader,$qnext,'�̷s�O��');
		}
          	$CLOSE cur_pre2;
          	$FREE cur_pre2;
          	
         /*******************�h�O���Ƨ��***********************/
         sprintf_s(stmt, sizeof stmt,
		"SELECT UNIQUE a.ipolicy , c.iins_type    "
		"  FROM %s:policy a,%s:ply_relation b ,%s:ply_ins_type c "
		" WHERE a.ipolicy = b.ipolicy      "
		"   AND a.ipolicy = c.ipolicy      "
		"   AND b.dply_close is not null   "
		"   AND (c.minjured_cover + c.mdeath_cover + c.mdamage_cover) = 0 "
		"   AND c.iins_type IN (select detail from car_code where kind IN ('41'))"
		"   AND b.dpolicy BETWEEN '%s' and '%s' "
		"   %s                                  "
		,list[k].dbname,list[k].dbname,list[k].dbname,dentry_s_cond,dentry_cond,sWhere);

printf("stmt[%s]\n", stmt);
	 
          $PREPARE pre2_1 FROM $stmt;
          $DECLARE cur_pre2_1 CURSOR for pre2_1;        	 
      	  $OPEN cur_pre2_1;

      		while(1)
      		{
         		$FETCH cur_pre2_1 INTO $ipolicy,$iins_type;
         			       			
         		if(SQLCODE == SQLNOTFOUND) break;
         		
         		sprintf_s(stmt, sizeof stmt,
				"SELECT b.dpolicy,b.iquota,a.ipolicy, a.icard,a.nassured,a.itag,a.iengine,a.iassured,    "
				"       b.dply_begin,b.dply_end,b.icar_type,c.iins_type,c.minjured_cover,c.mdeath_cover, "
				"       c.mdamage_cover ,c.mins_premium,b.iofficer, "
				"       (SELECT nname FROM officer WHERE iofficer = b.iofficer), "
				"       (SELECT nname FROM officer WHERE iofficer = b.ileader),  "
				"       CASE qnext_year WHEN '0' THEN '�s�O' ELSE '��O' END     "
				"  FROM %s:original_ply a,%s:ori_ply_relation b ,%s:ori_ins_type c "
				" WHERE a.ipolicy = b.ipolicy      "
				"   AND a.ipolicy = c.ipolicy      "
				"   AND b.dply_close is not null   "
				"   AND c.mdamage_cover >= 3000000 "
				"   AND c.iins_type IN (select detail from car_code where kind IN ('41'))"
				"   AND a.ipolicy = '%s'                "
				"   AND c.iins_type = '%s'              "
				,list[k].dbname,list[k].dbname,list[k].dbname,ipolicy,iins_type);
				
				$PREPARE pre2_2 FROM $stmt;
          			$DECLARE cur_pre2_2 CURSOR for pre2_2;        	 
      	  			$OPEN cur_pre2_2;
      	  			
      	  			while(1)
      	  			{
      	  			 $FETCH cur_pre2_2 INTO $dpolicy,$iquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured,$dply_begin,
         				                $dply_end,$icar_type,$iins_type,$minjured_cover,$mdeath_cover,$mdamage_cover,
         				                $mins_premium,$iofficer,$nofficer,$nleader,$qnext;
         				              
         			 if(SQLCODE == SQLNOTFOUND) break;
         			 
         			 $SELECT nbranch
         		   	    INTO $nquota
         		            FROM sa_branch_type 
         		           WHERE ibranch = $iquota;
         		           
         		           if(SQLCODE == SQLNOTFOUND) strcpy(nquota," ");
         		           
         		           /**���X�Ĥ@�X��0�A�����bexcel show �X*/
              			   strcpy(iassured1, "�");
              			   strcat(iassured1,trim(iassured));
              		
              			   strcpy(icar_type1, "�");
              			   strcat(icar_type1,trim(icar_type));
              		
              			   strcpy(iins_type1, "�");
              			   strcat(iins_type1,trim(iins_type));
              		
              			   strcpy(iofficer1, "�");
              			   strcat(iofficer1,trim(iofficer));

			$INSERT INTO car346_tmp1
	          		     (dpolicy,nquota,ipolicy,icard,nassured,itag,iengine,iassured,dply_begin,
         			      dply_end,icar_type,iins_type,minjured_cover,mdeath_cover,mdamage_cover,
         		              mins_premium,iofficer,nofficer,nleader,qnext,ply)
			      VALUES
	          		     ($dpolicy,$nquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured1,$dply_begin,
         			      $dply_end,$icar_type1,$iins_type1,$minjured_cover,$mdeath_cover,$mdamage_cover,
         			      $mins_premium,$iofficer1,$nofficer,$nleader,$qnext,'��l�O��');	    
      	  			}
      	  			$CLOSE cur_pre2_2;
          			$FREE cur_pre2_2;
       	
		}
          	$CLOSE cur_pre2_1;
          	$FREE cur_pre2_1;        	
        }
        else if(strcmp(trim(fins_grp),"3") == 0)
        {
         /*******************���d�I*****************************/
         /*******************�̷s�O����***********************/
	 sprintf_s(stmt, sizeof stmt,
		"SELECT b.dpolicy,b.iquota,a.ipolicy, a.icard,a.nassured,a.itag,a.iengine,a.iassured,    "
		"       b.dply_begin,b.dply_end,b.icar_type,c.iins_type,c.minjured_cover,c.mdeath_cover, "
		"       c.mdamage_cover ,c.mins_premium,b.iofficer, "
		"       (SELECT nname FROM officer WHERE iofficer = b.iofficer), "
		"       (SELECT nname FROM officer WHERE iofficer = b.ileader),  "
		"       CASE qnext_year WHEN '0' THEN '�s�O' ELSE '��O' END     "
		"  FROM %s:policy a,%s:ply_relation b ,%s:ply_ins_type c "
		" WHERE a.ipolicy = b.ipolicy      "
		"   AND a.ipolicy = c.ipolicy      "
		"   AND b.dply_close is not null   "
		"   AND c.iins_type IN (select detail from car_code where kind IN ('42'))"
		"   AND ((((SELECT minjured_cover FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '31') * 2) + (SELECT mdamage_cover FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '32')) > 20000000  "
   		"      OR(((SELECT minjured_cover FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '73') * 2) + (SELECT mdamage_cover FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '74')) > 20000000  "
   		"      OR(((SELECT minjured_cover FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '77') * 2) + (SELECT mdamage_cover FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '78')) > 20000000) "
		"   AND b.dpolicy BETWEEN '%s' and '%s' "
		"   %s                                  "
		,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,dentry_s_cond,dentry_cond,sWhere);

printf("stmt[%s]\n", stmt);
	 
          $PREPARE pre3 FROM $stmt;
          $DECLARE cur_pre3 CURSOR for pre3;        	 
      	  $OPEN cur_pre3;

      		while(1)
      		{
         		$FETCH cur_pre3 INTO $dpolicy,$iquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured,$dply_begin,
         				     $dply_end,$icar_type,$iins_type,$minjured_cover,$mdeath_cover,$mdamage_cover,
         				     $mins_premium,$iofficer,$nofficer,$nleader,$qnext;
         			       			
         		if(SQLCODE == SQLNOTFOUND) break;
         		
         		$SELECT nbranch
         		   INTO $nquota
         		   FROM sa_branch_type 
         		  WHERE ibranch = $iquota;
         		  
         		if(SQLCODE == SQLNOTFOUND) strcpy(nquota," ");
         		
         		/**���X�Ĥ@�X��0�A�����bexcel show �X*/
              		strcpy(iassured1, "�");
              		strcat(iassured1,trim(iassured));
              		
              		strcpy(icar_type1, "�");
              		strcat(icar_type1,trim(icar_type));
              		
              		strcpy(iins_type1, "�");
              		strcat(iins_type1,trim(iins_type));
              		
              		strcpy(iofficer1, "�");
              		strcat(iofficer1,trim(iofficer));

			$INSERT INTO car346_tmp1
	          		     (dpolicy,nquota,ipolicy,icard,nassured,itag,iengine,iassured,dply_begin,
         			      dply_end,icar_type,iins_type,minjured_cover,mdeath_cover,mdamage_cover,
         		              mins_premium,iofficer,nofficer,nleader,qnext,ply)
			      VALUES
	          		     ($dpolicy,$nquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured1,$dply_begin,
         			      $dply_end,$icar_type1,$iins_type1,$minjured_cover,$mdeath_cover,$mdamage_cover,
         			      $mins_premium,$iofficer1,$nofficer,$nleader,$qnext,'�̷s�O��');
		}
          	$CLOSE cur_pre3;
          	$FREE cur_pre3;
          	
         /*******************�h�O���Ƨ��***********************/
         sprintf_s(stmt, sizeof stmt,
		"SELECT UNIQUE a.ipolicy , c.iins_type   "
		"  FROM %s:policy a,%s:ply_relation b ,%s:ply_ins_type c "
		" WHERE a.ipolicy = b.ipolicy      "
		"   AND a.ipolicy = c.ipolicy      "
		"   AND b.dply_close is not null   "
		"   AND (c.minjured_cover + c.mdeath_cover + c.mdamage_cover) = 0 "
		"   AND c.iins_type IN (select detail from car_code where kind IN ('42'))"
		"   AND b.dpolicy BETWEEN '%s' and '%s' "
		"   %s                                  "
		,list[k].dbname,list[k].dbname,list[k].dbname,dentry_s_cond,dentry_cond,sWhere);

printf("stmt[%s]\n", stmt);

          $PREPARE pre3_1 FROM $stmt;
          $DECLARE cur_pre3_1 CURSOR for pre3_1;
      	  $OPEN cur_pre3_1;

      		while(1)
      		{
         		$FETCH cur_pre3_1 INTO $ipolicy,$iins_type;

         		if(SQLCODE == SQLNOTFOUND) break;

         		sprintf_s(stmt, sizeof stmt,
				"SELECT b.dpolicy,b.iquota,a.ipolicy, a.icard,a.nassured,a.itag,a.iengine,a.iassured,    "
				"       b.dply_begin,b.dply_end,b.icar_type,c.iins_type,c.minjured_cover,c.mdeath_cover, "
				"       c.mdamage_cover ,c.mins_premium,b.iofficer, "
				"       (SELECT nname FROM officer WHERE iofficer = b.iofficer), "
				"       (SELECT nname FROM officer WHERE iofficer = b.ileader),  "
				"       CASE qnext_year WHEN '0' THEN '�s�O' ELSE '��O' END     "
				"  FROM %s:original_ply a,%s:ori_ply_relation b ,%s:ori_ins_type c "
				" WHERE a.ipolicy = b.ipolicy      "
				"   AND a.ipolicy = c.ipolicy      "
				"   AND b.dply_close is not null   "
				"   AND c.iins_type IN (select detail from car_code where kind IN ('42'))"
				"   AND ((((SELECT minjured_cover FROM %s:ori_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '31') * 2) + (SELECT mdamage_cover FROM %s:ori_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '32')) > 20000000  "
   				"      OR(((SELECT minjured_cover FROM %s:ori_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '73') * 2) + (SELECT mdamage_cover FROM %s:ori_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '74')) > 20000000  "
   				"      OR(((SELECT minjured_cover FROM %s:ori_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '77') * 2) + (SELECT mdamage_cover FROM %s:ori_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '78')) > 20000000) "
				"   AND a.ipolicy = '%s'                "
				"   AND c.iins_type = '%s'              "
				,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,ipolicy,iins_type);

				$PREPARE pre3_2 FROM $stmt;
          			$DECLARE cur_pre3_2 CURSOR for pre3_2;
      	  			$OPEN cur_pre3_2;

      	  			while(1)
      	  			{
      	  			 $FETCH cur_pre3_2 INTO $dpolicy,$iquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured,$dply_begin,
         				                $dply_end,$icar_type,$iins_type,$minjured_cover,$mdeath_cover,$mdamage_cover,
         				                $mins_premium,$iofficer,$nofficer,$nleader,$qnext;

         			 if(SQLCODE == SQLNOTFOUND) break;

         			 $SELECT nbranch
         		   	    INTO $nquota
         		            FROM sa_branch_type 
         		           WHERE ibranch = $iquota;

         		           if(SQLCODE == SQLNOTFOUND) strcpy(nquota," ");
 
         		           /**���X�Ĥ@�X��0�A�����bexcel show �X*/
              			   strcpy(iassured1, "�");
              			   strcat(iassured1,trim(iassured));

              			   strcpy(icar_type1, "�");
              			   strcat(icar_type1,trim(icar_type));

              			   strcpy(iins_type1, "�");
              			   strcat(iins_type1,trim(iins_type));

              			   strcpy(iofficer1, "�");
              			   strcat(iofficer1,trim(iofficer));

			$INSERT INTO car346_tmp1
	          		     (dpolicy,nquota,ipolicy,icard,nassured,itag,iengine,iassured,dply_begin,
         			      dply_end,icar_type,iins_type,minjured_cover,mdeath_cover,mdamage_cover,
         		              mins_premium,iofficer,nofficer,nleader,qnext,ply)
			      VALUES
	          		     ($dpolicy,$nquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured1,$dply_begin,
         			      $dply_end,$icar_type1,$iins_type1,$minjured_cover,$mdeath_cover,$mdamage_cover,
         			      $mins_premium,$iofficer1,$nofficer,$nleader,$qnext,'��l�O��');	    
      	  			}
      	  			$CLOSE cur_pre3_2;
          			$FREE cur_pre3_2;

		}
          	$CLOSE cur_pre3_1;
          	$FREE cur_pre3_1;
        }
        else
        {
         /*******************�����I+���d�I***********************/
         /*******************�̷s�O����***********************/
	 sprintf_s(stmt, sizeof stmt,
		"SELECT b.dpolicy,b.iquota,a.ipolicy, a.icard,a.nassured,a.itag,a.iengine,a.iassured,    "
		"       b.dply_begin,b.dply_end,b.icar_type,c.iins_type,c.minjured_cover,c.mdeath_cover, "
		"       c.mdamage_cover ,c.mins_premium,b.iofficer, "
		"       (SELECT nname FROM officer WHERE iofficer = b.iofficer), "
		"       (SELECT nname FROM officer WHERE iofficer = b.ileader),  "
		"       CASE qnext_year WHEN '0' THEN '�s�O' ELSE '��O' END     "
		"  FROM %s:policy a,%s:ply_relation b ,%s:ply_ins_type c "
		" WHERE a.ipolicy = b.ipolicy      "
		"   AND a.ipolicy = c.ipolicy      "
		"   AND b.dply_close is not null   "
		"   AND c.mdamage_cover >= 3000000 "
		"   AND c.iins_type IN (select detail from car_code where kind IN ('40','41'))"
		"   AND b.dpolicy BETWEEN '%s' and '%s' "
		"   %s                                  "
		" UNION                                 "
		"SELECT b.dpolicy,b.iquota,a.ipolicy, a.icard,a.nassured,a.itag,a.iengine,a.iassured,    "
		"       b.dply_begin,b.dply_end,b.icar_type,c.iins_type,c.minjured_cover,c.mdeath_cover, "
		"       c.mdamage_cover ,c.mins_premium,b.iofficer, "
		"       (SELECT nname FROM officer WHERE iofficer = b.iofficer), "
		"       (SELECT nname FROM officer WHERE iofficer = b.ileader),  "
		"       CASE qnext_year WHEN '0' THEN '�s�O' ELSE '��O' END     "
		"  FROM %s:policy a,%s:ply_relation b ,%s:ply_ins_type c "
		" WHERE a.ipolicy = b.ipolicy      "
		"   AND a.ipolicy = c.ipolicy      "
		"   AND b.dply_close is not null   "
		"   AND c.iins_type IN (select detail from car_code where kind IN ('42'))"
		"   AND ((((SELECT minjured_cover FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '31') * 2) + (SELECT mdamage_cover FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '32')) > 20000000  "
   		"      OR(((SELECT minjured_cover FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '73') * 2) + (SELECT mdamage_cover FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '74')) > 20000000  "
   		"      OR(((SELECT minjured_cover FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '77') * 2) + (SELECT mdamage_cover FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '78')) > 20000000) "
		"   AND b.dpolicy BETWEEN '%s' and '%s' "
		"   %s                                  "
		,list[k].dbname,list[k].dbname,list[k].dbname,dentry_s_cond,dentry_cond,sWhere,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,dentry_s_cond,dentry_cond,sWhere);

printf("stmt[%s]\n", stmt);

          $PREPARE pre4 FROM $stmt;
          $DECLARE cur_pre4 CURSOR for pre4;        	 
      	  $OPEN cur_pre4;

      		while(1)
      		{
         		$FETCH cur_pre4 INTO $dpolicy,$iquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured,$dply_begin,
         				     $dply_end,$icar_type,$iins_type,$minjured_cover,$mdeath_cover,$mdamage_cover,
         				     $mins_premium,$iofficer,$nofficer,$nleader,$qnext;
         			       			
         		if(SQLCODE == SQLNOTFOUND) break;
         		
         		$SELECT nbranch
         		   INTO $nquota
         		   FROM sa_branch_type 
         		  WHERE ibranch = $iquota;
         		  
         		if(SQLCODE == SQLNOTFOUND) strcpy(nquota," ");
         		
         		/**���X�Ĥ@�X��0�A�����bexcel show �X*/
              		strcpy(iassured1, "�");
              		strcat(iassured1,trim(iassured));
              		
              		strcpy(icar_type1, "�");
              		strcat(icar_type1,trim(icar_type));
              		
              		strcpy(iins_type1, "�");
              		strcat(iins_type1,trim(iins_type));
              		
              		strcpy(iofficer1, "�");
              		strcat(iofficer1,trim(iofficer));

			$INSERT INTO car346_tmp1
	          		     (dpolicy,nquota,ipolicy,icard,nassured,itag,iengine,iassured,dply_begin,
         			      dply_end,icar_type,iins_type,minjured_cover,mdeath_cover,mdamage_cover,
         		              mins_premium,iofficer,nofficer,nleader,qnext,ply)
			      VALUES
	          		     ($dpolicy,$nquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured1,$dply_begin,
         			      $dply_end,$icar_type1,$iins_type1,$minjured_cover,$mdeath_cover,$mdamage_cover,
         			      $mins_premium,$iofficer1,$nofficer,$nleader,$qnext,'�̷s�O��');
		}
          	$CLOSE cur_pre4;
          	$FREE cur_pre4;

         /*******************�h�O���Ƨ��***********************/
         sprintf_s(stmt, sizeof stmt,
         	"SELECT UNIQUE a.ipolicy , c.iins_type    "
		"  FROM %s:policy a,%s:ply_relation b ,%s:ply_ins_type c "
		" WHERE a.ipolicy = b.ipolicy      "
		"   AND a.ipolicy = c.ipolicy      "
		"   AND b.dply_close is not null   "
		"   AND (c.minjured_cover + c.mdeath_cover + c.mdamage_cover) = 0 "
		"   AND c.iins_type IN (select detail from car_code where kind IN ('40','41','42'))"
		"   AND b.dpolicy BETWEEN '%s' and '%s' "
		"   %s                                  "
		,list[k].dbname,list[k].dbname,list[k].dbname,dentry_s_cond,dentry_cond,sWhere);

printf("stmt[%s]\n", stmt);

          $PREPARE pre4_1 FROM $stmt;
          $DECLARE cur_pre4_1 CURSOR for pre4_1;        	 
      	  $OPEN cur_pre4_1;

      		while(1)
      		{
         		$FETCH cur_pre4_1 INTO $ipolicy,$iins_type;

         		if(SQLCODE == SQLNOTFOUND) break;

         		sprintf_s(stmt, sizeof stmt,
         			"SELECT b.dpolicy,b.iquota,a.ipolicy, a.icard,a.nassured,a.itag,a.iengine,a.iassured,    "
				"       b.dply_begin,b.dply_end,b.icar_type,c.iins_type,c.minjured_cover,c.mdeath_cover, "
				"       c.mdamage_cover ,c.mins_premium,b.iofficer, "
				"       (SELECT nname FROM officer WHERE iofficer = b.iofficer), "
				"       (SELECT nname FROM officer WHERE iofficer = b.ileader),  "
				"       CASE qnext_year WHEN '0' THEN '�s�O' ELSE '��O' END     "
				"  FROM %s:original_ply a,%s:ori_ply_relation b ,%s:ori_ins_type c "
				" WHERE a.ipolicy = b.ipolicy      "
				"   AND a.ipolicy = c.ipolicy      "
				"   AND b.dply_close is not null   "
				"   AND c.mdamage_cover >= 3000000 "
				"   AND c.iins_type IN (select detail from car_code where kind IN ('40','41'))"
				"   AND a.ipolicy = '%s'                "
				"   AND c.iins_type = '%s'              "
         			" UNION                                 "
				"SELECT b.dpolicy,b.iquota,a.ipolicy, a.icard,a.nassured,a.itag,a.iengine,a.iassured,    "
				"       b.dply_begin,b.dply_end,b.icar_type,c.iins_type,c.minjured_cover,c.mdeath_cover, "
				"       c.mdamage_cover ,c.mins_premium,b.iofficer, "
				"       (SELECT nname FROM officer WHERE iofficer = b.iofficer), "
				"       (SELECT nname FROM officer WHERE iofficer = b.ileader),  "
				"       CASE qnext_year WHEN '0' THEN '�s�O' ELSE '��O' END     "
				"  FROM %s:original_ply a,%s:ori_ply_relation b ,%s:ori_ins_type c "
				" WHERE a.ipolicy = b.ipolicy      "
				"   AND a.ipolicy = c.ipolicy      "
				"   AND b.dply_close is not null   "
				"   AND c.iins_type IN (select detail from car_code where kind IN ('42'))"
				"   AND ((((SELECT minjured_cover FROM %s:ori_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '31') * 2) + (SELECT mdamage_cover FROM %s:ori_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '32')) > 20000000  "
   				"      OR(((SELECT minjured_cover FROM %s:ori_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '73') * 2) + (SELECT mdamage_cover FROM %s:ori_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '74')) > 20000000  "
   				"      OR(((SELECT minjured_cover FROM %s:ori_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '77') * 2) + (SELECT mdamage_cover FROM %s:ori_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '78')) > 20000000) "
				"   AND a.ipolicy = '%s'                "
				"   AND c.iins_type = '%s'              "
				,list[k].dbname,list[k].dbname,list[k].dbname,ipolicy,iins_type,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,ipolicy,iins_type);

				$PREPARE pre4_2 FROM $stmt;
          			$DECLARE cur_pre4_2 CURSOR for pre4_2;
      	  			$OPEN cur_pre4_2;

      	  			while(1)
      	  			{
      	  			 $FETCH cur_pre4_2 INTO $dpolicy,$iquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured,$dply_begin,
         				                $dply_end,$icar_type,$iins_type,$minjured_cover,$mdeath_cover,$mdamage_cover,
         				                $mins_premium,$iofficer,$nofficer,$nleader,$qnext;

         			 if(SQLCODE == SQLNOTFOUND) break;

         			 $SELECT nbranch
         		   	    INTO $nquota
         		            FROM sa_branch_type 
         		           WHERE ibranch = $iquota;

         		           if(SQLCODE == SQLNOTFOUND) strcpy(nquota," ");

         		           /**���X�Ĥ@�X��0�A�����bexcel show �X*/
              			   strcpy(iassured1, "�");
              			   strcat(iassured1,trim(iassured));

              			   strcpy(icar_type1, "�");
              			   strcat(icar_type1,trim(icar_type));

              			   strcpy(iins_type1, "�");
              			   strcat(iins_type1,trim(iins_type));

              			   strcpy(iofficer1, "�");
              			   strcat(iofficer1,trim(iofficer));

			$INSERT INTO car346_tmp1
	          		     (dpolicy,nquota,ipolicy,icard,nassured,itag,iengine,iassured,dply_begin,
         			      dply_end,icar_type,iins_type,minjured_cover,mdeath_cover,mdamage_cover,
         		              mins_premium,iofficer,nofficer,nleader,qnext,ply)
			      VALUES
	          		     ($dpolicy,$nquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured1,$dply_begin,
         			      $dply_end,$icar_type1,$iins_type1,$minjured_cover,$mdeath_cover,$mdamage_cover,
         			      $mins_premium,$iofficer1,$nofficer,$nleader,$qnext,'��l�O��');	    
      	  			}
      	  			$CLOSE cur_pre4_2;
          			$FREE cur_pre4_2;

		}
          	$CLOSE cur_pre4_1;
          	$FREE cur_pre4_1;
        }
     }
     return M_CM_OK;
     
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

long car346_prepare_data()
{
   
   $char ipolicy[21],iquota[7],nassured[121],icard[21],itag[CA_TAG_NUM],iengine[CA_ENGINE_NUM],iassured[13];
   $char icar_type[3],iins_type[7],iofficer[11],nofficer[121],nleader[120],qnext[11],nquota[121];
   $char iassured1[14],icar_type1[4],iins_type1[8],iofficer1[12];
   $char sWhere[256];
   $long dpolicy,dply_begin,dply_end,minjured_cover,mdeath_cover,mdamage_cover,mins_premium;
   $char  dentry_cond[11],dentry_s_cond[11];
   $char  stmt[4096];
   
   strcpy(dentry_cond,cm_to_infdate(dentry));
   strcpy(dentry_s_cond,cm_to_infdate(dentry_s));
  
   
   $WHENEVER SQLERROR GOTO errexit;
   
   if (db_select(DBName) == FALSE)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return FAIL;
   } 

printf("prepared data, dentry_cond[%s]dentry_s_cond[%s]\n",dentry_cond,dentry_s_cond);

	if( strcmp(trim(option),"1") == 0)
            sprintf_s(sWhere, sizeof sWhere, " and b.iquota matches '%s' ",ibranch);
        else
            sprintf_s(sWhere, sizeof sWhere, " and a.ipolicy[1,3] matches '%s' ",ibranch);

    	/*******************�����I***********************/
	if(strcmp(trim(fins_grp),"1") == 0)
	{
	/*******************�̷s�O����***********************/
	 sprintf_s(stmt, sizeof stmt,
		"SELECT b.dpolicy,b.iquota,a.ipolicy, a.icard,a.nassured,a.itag,a.iengine,a.iassured,    "
		"       b.dply_begin,b.dply_end,b.icar_type,c.iins_type,c.minjured_cover,c.mdeath_cover, "
		"       c.mdamage_cover ,c.mins_premium,b.iofficer, "
		"       (SELECT nname FROM officer WHERE iofficer = b.iofficer), "
		"       (SELECT nname FROM officer WHERE iofficer = b.ileader),  "
		"       CASE qnext_year WHEN '0' THEN '�s�O' ELSE '��O' END     "
		"  FROM policy a ,ply_relation b ,ply_ins_type c "
		" WHERE a.ipolicy = b.ipolicy      "
		"   AND a.ipolicy = c.ipolicy      "
		"   AND b.dply_close is not null   "
		"   AND c.mdamage_cover >= 3000000 "
		"   AND c.iins_type IN (select detail from car_code where kind IN ('40'))"
		"   AND b.dpolicy BETWEEN '%s' and '%s' "
		"   %s                                  "
		,dentry_s_cond,dentry_cond,sWhere);

printf("stmt[%s]\n", stmt);

          $PREPARE pre5 FROM $stmt;
          $DECLARE cur_pre5 CURSOR for pre5;
      	  $OPEN cur_pre5;

      		while(1)
      		{
         		$FETCH cur_pre5 INTO $dpolicy,$iquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured,$dply_begin,
         				     $dply_end,$icar_type,$iins_type,$minjured_cover,$mdeath_cover,$mdamage_cover,
         				     $mins_premium,$iofficer,$nofficer,$nleader,$qnext;

         		if(SQLCODE == SQLNOTFOUND) break;
         		
         		$SELECT nbranch
         		   INTO $nquota
         		   FROM sa_branch_type 
         		  WHERE ibranch = $iquota;
         		  
         		if(SQLCODE == SQLNOTFOUND) strcpy(nquota," ");
         		
         		/**���X�Ĥ@�X��0�A�����bexcel show �X*/
              		strcpy(iassured1, "�");
              		strcat(iassured1,trim(iassured));
              		
              		strcpy(icar_type1, "�");
              		strcat(icar_type1,trim(icar_type));
              		
              		strcpy(iins_type1, "�");
              		strcat(iins_type1,trim(iins_type));
              		
              		strcpy(iofficer1, "�");
              		strcat(iofficer1,trim(iofficer));
			
			$INSERT INTO car346_tmp1
	          		     (dpolicy,nquota,ipolicy,icard,nassured,itag,iengine,iassured,dply_begin,
         			      dply_end,icar_type,iins_type,minjured_cover,mdeath_cover,mdamage_cover,
         		              mins_premium,iofficer,nofficer,nleader,qnext,ply)
			      VALUES
	          		     ($dpolicy,$nquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured1,$dply_begin,
         			      $dply_end,$icar_type1,$iins_type1,$minjured_cover,$mdeath_cover,$mdamage_cover,
         			      $mins_premium,$iofficer1,$nofficer,$nleader,$qnext,'�̷s�O��');
		}
          	$CLOSE cur_pre5;
          	$FREE cur_pre5;

         /*******************�h�O���Ƨ��***********************/
         sprintf_s(stmt, sizeof stmt,
		"SELECT UNIQUE a.ipolicy , c.iins_type   "
		"  FROM policy a, ply_relation b ,ply_ins_type c "
		" WHERE a.ipolicy = b.ipolicy      "
		"   AND a.ipolicy = c.ipolicy      "
		"   AND b.dply_close is not null   "
		"   AND (c.minjured_cover + c.mdeath_cover + c.mdamage_cover) = 0 "
		"   AND c.iins_type IN (select detail from car_code where kind IN ('40'))"
		"   AND b.dpolicy BETWEEN '%s' and '%s' "
		"   %s                                  "
		,dentry_s_cond,dentry_cond,sWhere);

printf("stmt[%s]\n", stmt);

          $PREPARE pre5_1 FROM $stmt;
          $DECLARE cur_pre5_1 CURSOR for pre5_1;
      	  $OPEN cur_pre5_1;

      		while(1)
      		{
         		$FETCH cur_pre5_1 INTO $ipolicy,$iins_type;
         			       			
         		if(SQLCODE == SQLNOTFOUND) break;
         		
         		sprintf_s(stmt, sizeof stmt,
				"SELECT b.dpolicy,b.iquota,a.ipolicy, a.icard,a.nassured,a.itag,a.iengine,a.iassured,    "
				"       b.dply_begin,b.dply_end,b.icar_type,c.iins_type,c.minjured_cover,c.mdeath_cover, "
				"       c.mdamage_cover ,c.mins_premium,b.iofficer, "
				"       (SELECT nname FROM officer WHERE iofficer = b.iofficer), "
				"       (SELECT nname FROM officer WHERE iofficer = b.ileader),  "
				"       CASE qnext_year WHEN '0' THEN '�s�O' ELSE '��O' END     "
				"  FROM original_ply a,ori_ply_relation b ,ori_ins_type c "
				" WHERE a.ipolicy = b.ipolicy      "
				"   AND a.ipolicy = c.ipolicy      "
				"   AND b.dply_close is not null   "
				"   AND c.mdamage_cover >= 3000000 "
				"   AND c.iins_type IN (select detail from car_code where kind IN ('40'))"
				"   AND a.ipolicy = '%s'                "
				"   AND c.iins_type = '%s'              "
				,ipolicy,iins_type);

				$PREPARE pre5_2 FROM $stmt;
          			$DECLARE cur_pre5_2 CURSOR for pre5_2;
      	  			$OPEN cur_pre5_2;

      	  			while(1)
      	  			{
      	  			 $FETCH cur_pre5_2 INTO $dpolicy,$iquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured,$dply_begin,
         				                $dply_end,$icar_type,$iins_type,$minjured_cover,$mdeath_cover,$mdamage_cover,
         				                $mins_premium,$iofficer,$nofficer,$nleader,$qnext;
         				              
         			 if(SQLCODE == SQLNOTFOUND) break;
         			 
         			 $SELECT nbranch
         		   	    INTO $nquota
         		            FROM sa_branch_type 
         		           WHERE ibranch = $iquota;
         		           
         		           if(SQLCODE == SQLNOTFOUND) strcpy(nquota," ");
         		           
         		           /**���X�Ĥ@�X��0�A�����bexcel show �X*/
              			   strcpy(iassured1, "�");
              			   strcat(iassured1,trim(iassured));
              		
              			   strcpy(icar_type1, "�");
              			   strcat(icar_type1,trim(icar_type));
              		
              			   strcpy(iins_type1, "�");
              			   strcat(iins_type1,trim(iins_type));
              		
              			   strcpy(iofficer1, "�");
              			   strcat(iofficer1,trim(iofficer));
			
			$INSERT INTO car346_tmp1
	          		     (dpolicy,nquota,ipolicy,icard,nassured,itag,iengine,iassured,dply_begin,
         			      dply_end,icar_type,iins_type,minjured_cover,mdeath_cover,mdamage_cover,
         		              mins_premium,iofficer,nofficer,nleader,qnext,ply)
			      VALUES
	          		     ($dpolicy,$nquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured1,$dply_begin,
         			      $dply_end,$icar_type1,$iins_type1,$minjured_cover,$mdeath_cover,$mdamage_cover,
         			      $mins_premium,$iofficer1,$nofficer,$nleader,$qnext,'��l�O��');	    
      	  			}
      	  			$CLOSE cur_pre5_2;
          			$FREE cur_pre5_2;
       	
		}
          	$CLOSE cur_pre5_1;
          	$FREE cur_pre5_1;
        }
        else if(strcmp(trim(fins_grp),"2") == 0)
        {
         /*******************�ѵs�I*****************************/
         /*******************�̷s�O����***********************/
	 sprintf_s(stmt, sizeof stmt,
		"SELECT b.dpolicy,b.iquota,a.ipolicy, a.icard,a.nassured,a.itag,a.iengine,a.iassured,    "
		"       b.dply_begin,b.dply_end,b.icar_type,c.iins_type,c.minjured_cover,c.mdeath_cover, "
		"       c.mdamage_cover ,c.mins_premium,b.iofficer, "
		"       (SELECT nname FROM officer WHERE iofficer = b.iofficer), "
		"       (SELECT nname FROM officer WHERE iofficer = b.ileader),  "
		"       CASE qnext_year WHEN '0' THEN '�s�O' ELSE '��O' END     "
		"  FROM policy a,ply_relation b ,ply_ins_type c "
		" WHERE a.ipolicy = b.ipolicy      "
		"   AND a.ipolicy = c.ipolicy      "
		"   AND b.dply_close is not null   "
		"   AND c.mdamage_cover >= 3000000 "
		"   AND c.iins_type IN (select detail from car_code where kind IN ('41'))"
		"   AND b.dpolicy BETWEEN '%s' and '%s' "
		"   %s                                  "
		,dentry_s_cond,dentry_cond,sWhere);

printf("stmt[%s]\n", stmt);

          $PREPARE pre6 FROM $stmt;
          $DECLARE cur_pre6 CURSOR for pre6;
      	  $OPEN cur_pre6;

      		while(1)
      		{
         		$FETCH cur_pre6 INTO $dpolicy,$iquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured,$dply_begin,
         				     $dply_end,$icar_type,$iins_type,$minjured_cover,$mdeath_cover,$mdamage_cover,
         				     $mins_premium,$iofficer,$nofficer,$nleader,$qnext;

         		if(SQLCODE == SQLNOTFOUND) break;

         		$SELECT nbranch
         		   INTO $nquota
         		   FROM sa_branch_type 
         		  WHERE ibranch = $iquota;
 
         		if(SQLCODE == SQLNOTFOUND) strcpy(nquota," ");
         		
         		/**���X�Ĥ@�X��0�A�����bexcel show �X*/
              		strcpy(iassured1, "�");
              		strcat(iassured1,trim(iassured));
              		
              		strcpy(icar_type1, "�");
              		strcat(icar_type1,trim(icar_type));
              		
              		strcpy(iins_type1, "�");
              		strcat(iins_type1,trim(iins_type));
              		
              		strcpy(iofficer1, "�");
              		strcat(iofficer1,trim(iofficer));

			$INSERT INTO car346_tmp1
	          		     (dpolicy,nquota,ipolicy,icard,nassured,itag,iengine,iassured,dply_begin,
         			      dply_end,icar_type,iins_type,minjured_cover,mdeath_cover,mdamage_cover,
         		              mins_premium,iofficer,nofficer,nleader,qnext,ply)
			      VALUES
	          		     ($dpolicy,$nquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured1,$dply_begin,
         			      $dply_end,$icar_type1,$iins_type1,$minjured_cover,$mdeath_cover,$mdamage_cover,
         			      $mins_premium,$iofficer1,$nofficer,$nleader,$qnext,'�̷s�O��');
		}
          	$CLOSE cur_pre6;
          	$FREE cur_pre6;

         /*******************�h�O���Ƨ��***********************/
         sprintf_s(stmt, sizeof stmt,
		"SELECT UNIQUE a.ipolicy , c.iins_type    "
		"  FROM policy a,ply_relation b ,ply_ins_type c "
		" WHERE a.ipolicy = b.ipolicy      "
		"   AND a.ipolicy = c.ipolicy      "
		"   AND b.dply_close is not null   "
		"   AND (c.minjured_cover + c.mdeath_cover + c.mdamage_cover) = 0 "
		"   AND c.iins_type IN (select detail from car_code where kind IN ('41'))"
		"   AND b.dpolicy BETWEEN '%s' and '%s' "
		"   %s                                  "
		,dentry_s_cond,dentry_cond,sWhere);

printf("stmt[%s]\n", stmt);

          $PREPARE pre6_1 FROM $stmt;
          $DECLARE cur_pre6_1 CURSOR for pre6_1;
      	  $OPEN cur_pre6_1;

      		while(1)
      		{
         		$FETCH cur_pre6_1 INTO $ipolicy,$iins_type;

         		if(SQLCODE == SQLNOTFOUND) break;

         		sprintf_s(stmt, sizeof stmt,
				"SELECT b.dpolicy,b.iquota,a.ipolicy, a.icard,a.nassured,a.itag,a.iengine,a.iassured,    "
				"       b.dply_begin,b.dply_end,b.icar_type,c.iins_type,c.minjured_cover,c.mdeath_cover, "
				"       c.mdamage_cover ,c.mins_premium,b.iofficer, "
				"       (SELECT nname FROM officer WHERE iofficer = b.iofficer), "
				"       (SELECT nname FROM officer WHERE iofficer = b.ileader),  "
				"       CASE qnext_year WHEN '0' THEN '�s�O' ELSE '��O' END     "
				"  FROM original_ply a,ori_ply_relation b ,ori_ins_type c "
				" WHERE a.ipolicy = b.ipolicy      "
				"   AND a.ipolicy = c.ipolicy      "
				"   AND b.dply_close is not null   "
				"   AND c.mdamage_cover >= 3000000 "
				"   AND c.iins_type IN (select detail from car_code where kind IN ('41'))"
				"   AND a.ipolicy = '%s'                "
				"   AND c.iins_type = '%s'              "
				,ipolicy,iins_type);
				
				$PREPARE pre6_2 FROM $stmt;
          			$DECLARE cur_pre6_2 CURSOR for pre6_2;        	 
      	  			$OPEN cur_pre6_2;

      	  			while(1)
      	  			{
      	  			 $FETCH cur_pre6_2 INTO $dpolicy,$iquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured,$dply_begin,
         				                $dply_end,$icar_type,$iins_type,$minjured_cover,$mdeath_cover,$mdamage_cover,
         				                $mins_premium,$iofficer,$nofficer,$nleader,$qnext;
         				              
         			 if(SQLCODE == SQLNOTFOUND) break;

         			 $SELECT nbranch
         		   	    INTO $nquota
         		            FROM sa_branch_type 
         		           WHERE ibranch = $iquota;

         		           if(SQLCODE == SQLNOTFOUND) strcpy(nquota," ");
         		           
         		           /**���X�Ĥ@�X��0�A�����bexcel show �X*/
              			   strcpy(iassured1, "�");
              			   strcat(iassured1,trim(iassured));
              		
              			   strcpy(icar_type1, "�");
              			   strcat(icar_type1,trim(icar_type));
              		
              			   strcpy(iins_type1, "�");
              			   strcat(iins_type1,trim(iins_type));
              		
              			   strcpy(iofficer1, "�");
              			   strcat(iofficer1,trim(iofficer));

			$INSERT INTO car346_tmp1
	          		     (dpolicy,nquota,ipolicy,icard,nassured,itag,iengine,iassured,dply_begin,
         			      dply_end,icar_type,iins_type,minjured_cover,mdeath_cover,mdamage_cover,
         		              mins_premium,iofficer,nofficer,nleader,qnext,ply)
			      VALUES
	          		     ($dpolicy,$nquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured1,$dply_begin,
         			      $dply_end,$icar_type1,$iins_type1,$minjured_cover,$mdeath_cover,$mdamage_cover,
         			      $mins_premium,$iofficer1,$nofficer,$nleader,$qnext,'��l�O��');	    
      	  			}
      	  			$CLOSE cur_pre6_2;
          			$FREE cur_pre6_2;

		}
          	$CLOSE cur_pre6_1;
          	$FREE cur_pre6_1;
        }
        else if(strcmp(trim(fins_grp),"3") == 0)
        {
         /*******************���d�I*****************************/
         /*******************�̷s�O����***********************/
	 sprintf_s(stmt, sizeof stmt,
		"SELECT b.dpolicy,b.iquota,a.ipolicy, a.icard,a.nassured,a.itag,a.iengine,a.iassured,    "
		"       b.dply_begin,b.dply_end,b.icar_type,c.iins_type,c.minjured_cover,c.mdeath_cover, "
		"       c.mdamage_cover ,c.mins_premium,b.iofficer, "
		"       (SELECT nname FROM officer WHERE iofficer = b.iofficer), "
		"       (SELECT nname FROM officer WHERE iofficer = b.ileader),  "
		"       CASE qnext_year WHEN '0' THEN '�s�O' ELSE '��O' END     "
		"  FROM policy a,ply_relation b ,ply_ins_type c "
		" WHERE a.ipolicy = b.ipolicy      "
		"   AND a.ipolicy = c.ipolicy      "
		"   AND b.dply_close is not null   "
		"   AND c.iins_type IN (select detail from car_code where kind IN ('42'))"
		"   AND ((((SELECT minjured_cover FROM ply_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '31') * 2) + (SELECT mdamage_cover FROM ply_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '32')) > 20000000  "
   		"      OR(((SELECT minjured_cover FROM ply_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '73') * 2) + (SELECT mdamage_cover FROM ply_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '74')) > 20000000  "
   		"      OR(((SELECT minjured_cover FROM ply_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '77') * 2) + (SELECT mdamage_cover FROM ply_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '78')) > 20000000) "
		"   AND b.dpolicy BETWEEN '%s' and '%s' "
		"   %s                                  "
		,dentry_s_cond,dentry_cond,sWhere);

printf("stmt[%s]\n", stmt);

          $PREPARE pre7 FROM $stmt;
          $DECLARE cur_pre7 CURSOR for pre7;
      	  $OPEN cur_pre7;

      		while(1)
      		{
         		$FETCH cur_pre7 INTO $dpolicy,$iquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured,$dply_begin,
         				     $dply_end,$icar_type,$iins_type,$minjured_cover,$mdeath_cover,$mdamage_cover,
         				     $mins_premium,$iofficer,$nofficer,$nleader,$qnext;

         		if(SQLCODE == SQLNOTFOUND) break;

         		$SELECT nbranch
         		   INTO $nquota
         		   FROM sa_branch_type 
         		  WHERE ibranch = $iquota;
 
         		if(SQLCODE == SQLNOTFOUND) strcpy(nquota," ");
         		
         		/**���X�Ĥ@�X��0�A�����bexcel show �X*/
              		strcpy(iassured1, "�");
              		strcat(iassured1,trim(iassured));
              		
              		strcpy(icar_type1, "�");
              		strcat(icar_type1,trim(icar_type));
              		
              		strcpy(iins_type1, "�");
              		strcat(iins_type1,trim(iins_type));
              		
              		strcpy(iofficer1, "�");
              		strcat(iofficer1,trim(iofficer));

			$INSERT INTO car346_tmp1
	          		     (dpolicy,nquota,ipolicy,icard,nassured,itag,iengine,iassured,dply_begin,
         			      dply_end,icar_type,iins_type,minjured_cover,mdeath_cover,mdamage_cover,
         		              mins_premium,iofficer,nofficer,nleader,qnext,ply)
			      VALUES
	          		     ($dpolicy,$nquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured1,$dply_begin,
         			      $dply_end,$icar_type1,$iins_type1,$minjured_cover,$mdeath_cover,$mdamage_cover,
         			      $mins_premium,$iofficer1,$nofficer,$nleader,$qnext,'�̷s�O��');
		}
          	$CLOSE cur_pre7;
          	$FREE cur_pre7;

         /*******************�h�O���Ƨ��***********************/
         sprintf_s(stmt, sizeof stmt,
		"SELECT UNIQUE a.ipolicy , c.iins_type  "
		"  FROM policy a,ply_relation b ,ply_ins_type c "
		" WHERE a.ipolicy = b.ipolicy      "
		"   AND a.ipolicy = c.ipolicy      "
		"   AND b.dply_close is not null   "
		"   AND (c.minjured_cover + c.mdeath_cover + c.mdamage_cover) = 0 "
		"   AND c.iins_type IN (select detail from car_code where kind IN ('42'))"
		"   AND b.dpolicy BETWEEN '%s' and '%s' "
		"   %s                                  "
		,dentry_s_cond,dentry_cond,sWhere);

printf("stmt[%s]\n", stmt);

          $PREPARE pre7_1 FROM $stmt;
          $DECLARE cur_pre7_1 CURSOR for pre7_1;
      	  $OPEN cur_pre7_1;

      		while(1)
      		{
         		$FETCH cur_pre7_1 INTO $ipolicy,$iins_type;

         		if(SQLCODE == SQLNOTFOUND) break;

         		sprintf_s(stmt, sizeof stmt,
				"SELECT b.dpolicy,b.iquota,a.ipolicy, a.icard,a.nassured,a.itag,a.iengine,a.iassured,    "
				"       b.dply_begin,b.dply_end,b.icar_type,c.iins_type,c.minjured_cover,c.mdeath_cover, "
				"       c.mdamage_cover ,c.mins_premium,b.iofficer, "
				"       (SELECT nname FROM officer WHERE iofficer = b.iofficer), "
				"       (SELECT nname FROM officer WHERE iofficer = b.ileader),  "
				"       CASE qnext_year WHEN '0' THEN '�s�O' ELSE '��O' END     "
				"  FROM original_ply a,ori_ply_relation b ,ori_ins_type c "
				" WHERE a.ipolicy = b.ipolicy      "
				"   AND a.ipolicy = c.ipolicy      "
				"   AND b.dply_close is not null   "
				"   AND c.iins_type IN (select detail from car_code where kind IN ('42'))"
				"   AND ((((SELECT minjured_cover FROM ori_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '31') * 2) + (SELECT mdamage_cover FROM ori_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '32')) > 20000000  "
   				"      OR(((SELECT minjured_cover FROM ori_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '73') * 2) + (SELECT mdamage_cover FROM ori_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '74')) > 20000000  "
   				"      OR(((SELECT minjured_cover FROM ori_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '77') * 2) + (SELECT mdamage_cover FROM ori_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '78')) > 20000000) "
				"   AND a.ipolicy = '%s'                "
				"   AND c.iins_type = '%s'              "
				,ipolicy,iins_type);
				
				$PREPARE pre7_2 FROM $stmt;
          			$DECLARE cur_pre7_2 CURSOR for pre7_2;        	 
      	  			$OPEN cur_pre7_2;

      	  			while(1)
      	  			{
      	  			 $FETCH cur_pre7_2 INTO $dpolicy,$iquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured,$dply_begin,
         				                $dply_end,$icar_type,$iins_type,$minjured_cover,$mdeath_cover,$mdamage_cover,
         				                $mins_premium,$iofficer,$nofficer,$nleader,$qnext;
         				              
         			 if(SQLCODE == SQLNOTFOUND) break;

         			 $SELECT nbranch
         		   	    INTO $nquota
         		            FROM sa_branch_type 
         		           WHERE ibranch = $iquota;

         		           if(SQLCODE == SQLNOTFOUND) strcpy(nquota," ");
         		           
         		           /**���X�Ĥ@�X��0�A�����bexcel show �X*/
              			   strcpy(iassured1, "�");
              			   strcat(iassured1,trim(iassured));
              		
              			   strcpy(icar_type1, "�");
              			   strcat(icar_type1,trim(icar_type));
              		
              			   strcpy(iins_type1, "�");
              			   strcat(iins_type1,trim(iins_type));
              		
              			   strcpy(iofficer1, "�");
              			   strcat(iofficer1,trim(iofficer));

			$INSERT INTO car346_tmp1
	          		     (dpolicy,nquota,ipolicy,icard,nassured,itag,iengine,iassured,dply_begin,
         			      dply_end,icar_type,iins_type,minjured_cover,mdeath_cover,mdamage_cover,
         		              mins_premium,iofficer,nofficer,nleader,qnext,ply)
			      VALUES
	          		     ($dpolicy,$nquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured1,$dply_begin,
         			      $dply_end,$icar_type1,$iins_type1,$minjured_cover,$mdeath_cover,$mdamage_cover,
         			      $mins_premium,$iofficer1,$nofficer,$nleader,$qnext,'��l�O��');	    
      	  			}
      	  			$CLOSE cur_pre7_2;
          			$FREE cur_pre7_2;

		}
          	$CLOSE cur_pre7_1;
          	$FREE cur_pre7_1;        	
        }
        else
        {
         /*******************�����I+���d�I***********************/
         /*******************�̷s�O����***********************/
	 sprintf_s(stmt, sizeof stmt,
		"SELECT b.dpolicy,b.iquota,a.ipolicy, a.icard,a.nassured,a.itag,a.iengine,a.iassured,    "
		"       b.dply_begin,b.dply_end,b.icar_type,c.iins_type,c.minjured_cover,c.mdeath_cover, "
		"       c.mdamage_cover ,c.mins_premium,b.iofficer, "
		"       (SELECT nname FROM officer WHERE iofficer = b.iofficer), "
		"       (SELECT nname FROM officer WHERE iofficer = b.ileader),  "
		"       CASE qnext_year WHEN '0' THEN '�s�O' ELSE '��O' END     "
		"  FROM policy a,ply_relation b ,ply_ins_type c "
		" WHERE a.ipolicy = b.ipolicy      "
		"   AND a.ipolicy = c.ipolicy      "
		"   AND b.dply_close is not null   "
		"   AND c.mdamage_cover >= 3000000 "
		"   AND c.iins_type IN (select detail from car_code where kind IN ('40','41'))"
		"   AND b.dpolicy BETWEEN '%s' and '%s' "
		"   %s                                  "
		" UNION                                 "
		"SELECT b.dpolicy,b.iquota,a.ipolicy, a.icard,a.nassured,a.itag,a.iengine,a.iassured,    "
		"       b.dply_begin,b.dply_end,b.icar_type,c.iins_type,c.minjured_cover,c.mdeath_cover, "
		"       c.mdamage_cover ,c.mins_premium,b.iofficer, "
		"       (SELECT nname FROM officer WHERE iofficer = b.iofficer), "
		"       (SELECT nname FROM officer WHERE iofficer = b.ileader),  "
		"       CASE qnext_year WHEN '0' THEN '�s�O' ELSE '��O' END     "
		"  FROM policy a,ply_relation b ,ply_ins_type c "
		" WHERE a.ipolicy = b.ipolicy      "
		"   AND a.ipolicy = c.ipolicy      "
		"   AND b.dply_close is not null   "
		"   AND c.iins_type IN (select detail from car_code where kind IN ('42'))"
		"   AND ((((SELECT minjured_cover FROM ply_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '31') * 2) + (SELECT mdamage_cover FROM ply_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '32')) > 20000000  "
   		"     OR (((SELECT minjured_cover FROM ply_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '73') * 2) + (SELECT mdamage_cover FROM ply_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '74')) > 20000000  "
   		"     OR (((SELECT minjured_cover FROM ply_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '77') * 2) + (SELECT mdamage_cover FROM ply_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '78')) > 20000000) "
		"   AND b.dpolicy BETWEEN '%s' and '%s' "
		"   %s                                  "
		,dentry_s_cond,dentry_cond,sWhere,dentry_s_cond,dentry_cond,sWhere);

printf("stmt[%s]\n", stmt);

          $PREPARE pre8 FROM $stmt;
          $DECLARE cur_pre8 CURSOR for pre8;        	 
      	  $OPEN cur_pre8;

      		while(1)
      		{
         		$FETCH cur_pre8 INTO $dpolicy,$iquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured,$dply_begin,
         				     $dply_end,$icar_type,$iins_type,$minjured_cover,$mdeath_cover,$mdamage_cover,
         				     $mins_premium,$iofficer,$nofficer,$nleader,$qnext;
         			       			
         		if(SQLCODE == SQLNOTFOUND) break;
         		
         		$SELECT nbranch
         		   INTO $nquota
         		   FROM sa_branch_type 
         		  WHERE ibranch = $iquota;
         		  
         		if(SQLCODE == SQLNOTFOUND) strcpy(nquota," ");
         		
         		/**���X�Ĥ@�X��0�A�����bexcel show �X*/
              		strcpy(iassured1, "�");
              		strcat(iassured1,trim(iassured));
              		
              		strcpy(icar_type1, "�");
              		strcat(icar_type1,trim(icar_type));
              		
              		strcpy(iins_type1, "�");
              		strcat(iins_type1,trim(iins_type));
              		
              		strcpy(iofficer1, "�");
              		strcat(iofficer1,trim(iofficer));
			
			$INSERT INTO car346_tmp1
	          		     (dpolicy,nquota,ipolicy,icard,nassured,itag,iengine,iassured,dply_begin,
         			      dply_end,icar_type,iins_type,minjured_cover,mdeath_cover,mdamage_cover,
         		              mins_premium,iofficer,nofficer,nleader,qnext,ply)
			      VALUES
	          		     ($dpolicy,$nquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured1,$dply_begin,
         			      $dply_end,$icar_type1,$iins_type1,$minjured_cover,$mdeath_cover,$mdamage_cover,
         			      $mins_premium,$iofficer1,$nofficer,$nleader,$qnext,'�̷s�O��');
		}
          	$CLOSE cur_pre8;
          	$FREE cur_pre8;

         /*******************�h�O���Ƨ��***********************/
         sprintf_s(stmt, sizeof stmt,
         	"SELECT UNIQUE a.ipolicy , c.iins_type    "
		"  FROM policy a,ply_relation b ,ply_ins_type c "
		" WHERE a.ipolicy = b.ipolicy      "
		"   AND a.ipolicy = c.ipolicy      "
		"   AND b.dply_close is not null   "
		"   AND (c.minjured_cover + c.mdeath_cover + c.mdamage_cover) = 0 "
		"   AND c.iins_type IN (select detail from car_code where kind IN ('40','41','42'))"
		"   AND b.dpolicy BETWEEN '%s' and '%s' "
		"   %s                                  "
		,dentry_s_cond,dentry_cond,sWhere);

printf("stmt[%s]\n", stmt);

          $PREPARE pre8_1 FROM $stmt;
          $DECLARE cur_pre8_1 CURSOR for pre8_1;
      	  $OPEN cur_pre8_1;

      		while(1)
      		{
         		$FETCH cur_pre8_1 INTO $ipolicy,$iins_type;
         			       			
         		if(SQLCODE == SQLNOTFOUND) break;
         		
         		sprintf_s(stmt, sizeof stmt,
         			"SELECT b.dpolicy,b.iquota,a.ipolicy, a.icard,a.nassured,a.itag,a.iengine,a.iassured,    "
				"       b.dply_begin,b.dply_end,b.icar_type,c.iins_type,c.minjured_cover,c.mdeath_cover, "
				"       c.mdamage_cover ,c.mins_premium,b.iofficer, "
				"       (SELECT nname FROM officer WHERE iofficer = b.iofficer), "
				"       (SELECT nname FROM officer WHERE iofficer = b.ileader),  "
				"       CASE qnext_year WHEN '0' THEN '�s�O' ELSE '��O' END     "
				"  FROM original_ply a,ori_ply_relation b ,ori_ins_type c "
				" WHERE a.ipolicy = b.ipolicy      "
				"   AND a.ipolicy = c.ipolicy      "
				"   AND b.dply_close is not null   "
				"   AND c.mdamage_cover >= 3000000 "
				"   AND c.iins_type IN (select detail from car_code where kind IN ('40','41'))"
				"   AND a.ipolicy = '%s'                "
				"   AND c.iins_type = '%s'              "
         			" UNION                                 "
				"SELECT b.dpolicy,b.iquota,a.ipolicy, a.icard,a.nassured,a.itag,a.iengine,a.iassured,    "
				"       b.dply_begin,b.dply_end,b.icar_type,c.iins_type,c.minjured_cover,c.mdeath_cover, "
				"       c.mdamage_cover ,c.mins_premium,b.iofficer, "
				"       (SELECT nname FROM officer WHERE iofficer = b.iofficer), "
				"       (SELECT nname FROM officer WHERE iofficer = b.ileader),  "
				"       CASE qnext_year WHEN '0' THEN '�s�O' ELSE '��O' END     "
				"  FROM original_ply a,ori_ply_relation b ,ori_ins_type c "
				" WHERE a.ipolicy = b.ipolicy      "
				"   AND a.ipolicy = c.ipolicy      "
				"   AND b.dply_close is not null   "
				"   AND c.iins_type IN (select detail from car_code where kind IN ('42'))"
				"   AND ((((SELECT minjured_cover FROM ori_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '31') * 2) + (SELECT mdamage_cover FROM ori_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '32')) > 20000000  "
   				"     OR (((SELECT minjured_cover FROM ori_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '73') * 2) + (SELECT mdamage_cover FROM ori_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '74')) > 20000000  "
   				"     OR (((SELECT minjured_cover FROM ori_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '77') * 2) + (SELECT mdamage_cover FROM ori_ins_type WHERE ipolicy = a.ipolicy AND iins_type = '78')) > 20000000) "
				"   AND a.ipolicy = '%s'                "
				"   AND c.iins_type = '%s'              "
				,ipolicy,iins_type,ipolicy,iins_type);

				$PREPARE pre8_2 FROM $stmt;
          			$DECLARE cur_pre8_2 CURSOR for pre8_2;        	 
      	  			$OPEN cur_pre8_2;

      	  			while(1)
      	  			{

      	  			 $FETCH cur_pre8_2 INTO $dpolicy,$iquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured,$dply_begin,
         				                $dply_end,$icar_type,$iins_type,$minjured_cover,$mdeath_cover,$mdamage_cover,
         				                $mins_premium,$iofficer,$nofficer,$nleader,$qnext;
         				              
         			 if(SQLCODE == SQLNOTFOUND) break;
         			 
         			 $SELECT nbranch
         		   	    INTO $nquota
         		            FROM sa_branch_type 
         		           WHERE ibranch = $iquota;

         		           if(SQLCODE == SQLNOTFOUND) strcpy(nquota," ");
         		           
         		           /**���X�Ĥ@�X��0�A�����bexcel show �X*/
              			   strcpy(iassured1, "�");
              			   strcat(iassured1,trim(iassured));

              			   strcpy(icar_type1, "�");
              			   strcat(icar_type1,trim(icar_type));

              			   strcpy(iins_type1, "�");
              			   strcat(iins_type1,trim(iins_type));

              			   strcpy(iofficer1, "�");
              			   strcat(iofficer1,trim(iofficer));

			$INSERT INTO car346_tmp1
	          		     (dpolicy,nquota,ipolicy,icard,nassured,itag,iengine,iassured,dply_begin,
         			      dply_end,icar_type,iins_type,minjured_cover,mdeath_cover,mdamage_cover,
         		              mins_premium,iofficer,nofficer,nleader,qnext,ply)
			      VALUES
	          		     ($dpolicy,$nquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured1,$dply_begin,
         			      $dply_end,$icar_type1,$iins_type1,$minjured_cover,$mdeath_cover,$mdamage_cover,
         			      $mins_premium,$iofficer1,$nofficer,$nleader,$qnext,'��l�O��');	    
      	  			}
      	  			$CLOSE cur_pre8_2;
          			$FREE cur_pre8_2;

		}
          	$CLOSE cur_pre8_1;
          	$FREE cur_pre8_1;
        }

     return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/

long car346_build()

{
   int rc;
    char    sfilename[81],stitle[2048],stmt[2048];
    
    $WHENEVER SQLERROR GOTO errexit;

    strcpy(sfilename,"�֫O���v�ޱ�[CAR346]");
    
    strcpy(stitle,"\t�{���N��:CAR346\�֫O���v�ޱ�\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");
    
    strcat(stitle,"\tñ����\t���W��\t�O�渹�X\t�O�I�Ҹ�\t�Q�O�I�H\t�P�Ӹ��X\t�������X\t�Q�O�I�H�N��\t");
    strcat(stitle,"�ӫO�_��\t�ӫO�״�\t���إN�X\t�I��\t�O�B�@\t�O�B�G\t�O�B�T\t�O��O�O\t�g��N��\t�g��W��\t");
    strcat(stitle,"�޲z�H�W��\t�s��O\t�̷s/��l�O��\t");
    							          	

    strcpy(stmt,"select dpolicy,nquota,ipolicy,icard,nassured,itag,iengine,iassured,dply_begin, "
         	"       dply_end,icar_type,iins_type,minjured_cover,mdeath_cover,mdamage_cover, "
         	"       mins_premium,iofficer,nofficer,nleader,qnext,ply                        "
    		"  from car346_tmp1");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);
    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;

}

long car346_privilege()
{

    $whenever sqlerror goto errexit;

    $select falldb
       into $falldb
       from privilege
      where iemp = $userid
        and ipgid = 'car346';
    
    return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

long ca346_create_temp()
{
   /* Create table car346_tmp1 */
   sprintf_s(stmt_tmp, sizeof stmt_tmp,"create temp table car346_tmp1 "
	"( "
	" dpolicy    		date, "
    "    nquota     		varchar(120), "
    "    ipolicy    		char(20), "
	" icard      		char(20), "
	" nassured   		varchar(120), "
	" itag       		char(%d), "
	" iengine    		char(%d), "
	" iassured   		char(13), "
	" dply_begin 		date, "
	" dply_end   		date, "
	" icar_type  		char(3) , "
	" iins_type  		char(6), "
	" minjured_cover    	int, "
	" mdeath_cover      	int, "
	" mdamage_cover     	int, "
    "    mins_premium      	int, "
    "    iofficer          	char(11), "
    "    nofficer          	varchar(120), "
    "    nleader           	varchar(120), "
    "    qnext       		varchar(10), "
    "    ply		   	varchar(10) "
	" )with no log;",CA_TAG_NUM-1,CA_ENGINE_NUM-1);
     $PREPARE stmp FROM $stmt_tmp;
     $EXECUTE stmp;

    return M_CM_OK;
    
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;  
}

