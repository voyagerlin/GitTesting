/**********************************************************************/
/*                                                                    */
/*   program id   : ca606q01s.ec                                      */
/*   program name : �q����O��Ʃ��Ӫ�(�t���O�覡,��Local��Ʈw)      */
/*   date written : 2011/05/16                                        */
/*   author       : Jessie                                            */
/**********************************************************************/
/*                             MODIFICATION LOG                        *
 *                                                                     *
 *   DATE         SE                         DESCRIPTION               *
 * --------  -------------  ----------------------------------------   *
 * 20110711  Jessie         �W�[�ɨ����O�γQ�O�I�H�W��		       *
 **********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
#include "safeclib.h"
/*--------------------------------------------------------------------*/
$char dbgn1[11], dend1[11], conditions1[21], conditions2[11];
$char fcard1[2], fcard2[2], option[2], type[2];

$char stmt_card[81],stmt_route[121],stmt_type[121],stmt_type1[121];

char  msgbuf[100];

int     count_db,i;
DBinfo  *list;
char    sApHome[30];

$char DBName[05];
char  outputf[N_FILE+1];
$char userid[11];
$char isub[3];
$char stmt_tmp[5000];
/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
long  rc;

    batchinit();
    strcpy(DBName, isNULLstr(argv[1]));
    strcpy(userid, isNULLstr(argv[2]));
    strcpy(fcard2, isNULLstr(argv[3]));	/* ���N */
    strcpy(fcard1, isNULLstr(argv[4]));	/* �j�� */
    strcpy(type,   isNULLstr(argv[5])); /* 1:���� 2:�e�~�� */
    strcpy(option, isNULLstr(argv[6])); /* 1:�q���N�� 2:�޲z�H�N�� 3:�g��N�� */
    strcpy(conditions1, isNULLstr(argv[7]));
    strcpy(conditions2, isNULLstr(argv[8]));
    strcpy(dbgn1,  isNULLstr(argv[9]));
    strcpy(dend1,  isNULLstr(argv[10]));
    strcpy(outputf,isNULLstr(argv[11]));

    strcpy(dbgn1,  cm_to_infdate(dbgn1));
    strcpy(dend1,  cm_to_infdate(dend1));
    
		strncpy(isub, DBName, 2);
		isub[2] = '\0';

    rc = car606_get_db();
    if (rc != M_CM_OK)
      return rc;

    strcpy(msgbuf," ");
    if (strncmp(option,"1",1) == 0)
    {
      rc = car606_privilege();
      if (rc != M_CM_OK)
        return rc;
    }

    rc = car606_initial();
    if (rc != M_CM_OK)
       	return rc;

    rc = car606_process();
    if (rc != M_CM_OK)
        return rc;

    rc = car606_print();
    if (rc != M_CM_OK)
        return rc;

}
/*--------------------------------------------------------------------*/
long car606_get_db()
{
    printf("--- car606_get_db start --\n");
	int rc;

    if (db_select(DBName) == FALSE) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
    }

    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }

    if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
       if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
          return M_CM_NOT_DBLIST;
    }
printf("--- car606_get_db end --\n");
   return M_CM_OK;
}
/*--------------------------------------------------------------------*/
long car606_initial()
{
    $whenever sqlerror goto errexit;
    sprintf_s(stmt_tmp, sizeof stmt_tmp,"create temp table car606 ( "
       "fcm            char(4),  "
       "itmp_policy    char(20),  "
       "ipolicy        char(20),  "
       "ipolicy_c      char(20),  "
       "ilast_ply_c    char(20),  "
       "irelative_ply  char(20),  "
       "ipolicy_v      char(20),  "
       "ilast_ply_v    char(20),  "
       "inext_ply_v    char(20),  "
       "dply_bgn_v     date,      "
       "dply_end_v     date,      "
       "dply_bgn_c     date,      "
       "dply_end_c     date,      "
       "iendorse       char(20),  "
       "icard          char(20),  "
       "iassured       char(10),  "
       "nassured       varchar(120),  "
       "fassured       char(6),   "
       "itag           char(%d),  "
       "dissue         date,      "
       "dpolicy        date,      "
       "nrenew         char(1),   "
       "ipro_year      char(4),   "
       "ipro_month     char(2),   "
       "icar_type      char(2),   "
       "ncar_type      char(10),  "
       "ibrand         char(8),   "
       "nbrand_abbr    char(12),  "
       "series_name    char(4),   "
       "fsex           char(2),   "
       "dbirth         date,      "
       "iqyear         int,       "
       "iins_list      varchar(254),  "
       "ilast_iins_list  varchar(254),  "
       "ilast_iofficer char(10),      "
       "iofficer       char(10),      "
       "plia_acc       decimal(5,2),  "
       "pdmg_acc       decimal(5,2),  "
       "psex_age_damage   decimal(5,2),   "
       "psex_age       decimal(5,2),      "
       "pdmg_factor    decimal(5,2),      "
       "pbrg_factor    decimal(5,2),      "
       "mprem_v        int,          "
       "mprem_01       int,          "
       "mprem_05       int,          "
       "mprem_09       int,          "
       "mprem_11       int,          "
       "mprem_98       int,          "
       "mprem_31       int,          "
       "mprem_32       int,          "
       "mprem_29       int,          "
       "mprem_30       int,          "
       "mprem_301      int,          "
       "mprem_38       int,          "
       "mprem_39       int,          "
       "mprem_105      int,          "
       "mprem_55       int,          "
       "mprem_56       int,          "
       "mdamage_01        int,       "
       "mdamage_05        int,       "
       "mdamage_09        int,       "
       "mdamage_11        int,       "
       "mdamage_98        int,       "
       "minjured_31       int,       "
       "mdamage_31        int,       "
       "mdamage_32        int,       "
       "mdamage_29       int,        "
       "mdamage_30       int,        "
       "mdamage_301      int,        "
       "mdeath_55        int,        "
       "mdamage_55       int,        "
       "mdamage_56       int,        "
       "daily_pay_2        int,      "
       "daily_pay_3      int,        "
       "mdeduct_01       int,        "
       "mdeduct_05       int,        "
       "mdeduct_09       int,        "
       "nleader          char(10),   "
       "fout_print       char(1),    "
       "nequipment_01    char(1),    "
       "qply_period      char(6)     "
       ")with no log;",CA_TAG_NUM-1);
       
     printf("stmt_tmp=[%d][%s]\n",strlen(stmt_tmp),stmt_tmp);  
     $PREPARE stmp FROM $stmt_tmp;
     $EXECUTE stmp;

    $create index car606_ix on car606(ipolicy,iendorse);

    if (fcard2[0]=='1' && fcard1[0]=='1')  	/* ���� */
       strcpy(stmt_card," ");
    else if (fcard2[0]=='1') /* ���N */
       strcpy(stmt_card,"and a.fcard_class = '2'");
    else /* �j�� */
       strcpy(stmt_card,"and a.fcard_class = '1'");

    if (strncmp(type,"2",1) == 0){ /* �e�~�� */
    	 strcpy(stmt_type,"and a.fout_print = '1' and a.fmail_type != '0' ");
    	 strcpy(stmt_type1,"and e.fout_print = '1' and e.fmail_type != '0' ");
    }
    else{/* ���� */
    	 strcpy(stmt_type," ");
    	 strcpy(stmt_type1," ");
    }

    if (strncmp(option,"1",1) == 0)
       sprintf_s(stmt_route, sizeof stmt_route,"and b.iroute matches '%s*'",conditions1);
    else if (strncmp(option,"2",1) == 0)
       sprintf_s(stmt_route, sizeof stmt_route,"and a.ileader matches '%s'",conditions1);
    else
    	 sprintf_s(stmt_route, sizeof stmt_route,"and a.iofficer matches '%s'  "
    	                    "and a.ileader matches '%s'  ",conditions1,conditions2);

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car606_process()
{
int     k,rc;
$int	cnt;
$char   stmt[10000],stmt1[256],stmt2[256];
$char	stmt_fcard[256];
$char	ipolicy[21],iendorse[21],npay_type[9];
$char	iply1[21],iply2[21],nequipment[31],nequip_01[2];
$long	mstl;
$char   icar_series[3],icar_series_name[9],ibrand[9],ipro_year[5],ibrand_e[9],ipro_year_e[5],drate_ym[5];
$char  drate[11];
/*void choose_icar_series(char drate_f,char ibrand_f,char ipro_year_f,char icar_series_f);*/
/*void choose_icar_series($char,$char,$char,$char);*/

    $whenever sqlerror goto errexit;

    for(i=0;i<count_db;i++)
    {
        /*--- Ū����l�O�� ---*/
        sprintf_s(stmt, sizeof stmt,"insert into car606  "
	        "select case when a.icar_type in ('01','02','32','34','35') then '����' else '�T��' end as fcm,  "
            "       a.itmp_policy, a.ipolicy, decode(a.fcard_class,'1',a.ipolicy,' ') as ipolicy_c,  "
            "       decode(a.fcard_class,'1',a.ilast_ply,' ') as ilast_ply_c,  "
            "       a.irelative_ply, decode(a.fcard_class,'2',a.ipolicy,' ') as ipolicy_v,  "
            "       decode(a.fcard_class,'2',a.ilast_ply,' ') as ilast_ply_v,  "
            "       decode(a.fcard_class,'2',a.inext_ply,' ') as inext_ply_v,  "
            "       decode(a.fcard_class,'2',a.dply_begin,null) as dply_bgn_v,  "
            "       decode(a.fcard_class,'2',a.dply_end,null) as dply_end_v,  "
            "       decode(a.fcard_class,'1',a.dply_begin,null) as dply_bgn_c,  "
            "       decode(a.fcard_class,'1',a.dply_end,null) as dply_end_c,  "
            "       ' ' as iendorse, a.icard, b.iassured, b.nassured,  "
            "       case when fassured in ('1','3','5') then '�۵M�H' else '�k�H' end as fassured,  "
            "       b.itag, b.dissue, a.dpolicy,  "
            "       case when nvl(a.ilast_ply,' ') = ' ' then 'N' else 'Y' end as nrenew,  "
            "       a.ipro_year, b.qpro_month, a.icar_type,  "
            "       (select ncode from car_type where fclass = '1' and icode = a.icar_type) as ncar_type,  "
            "       a.ibrand, b.nbrand_abbr, ' ' as series_name,  "
            "       decode(b.fsex,'1','�k','2','�k',' ') as fsex, b.dbirth, a.qnext_year+1 as iqyer , "
            "       replace(replace(replace(replace(replace( multiset (select trim(iins_type)  "
            "          from %s:ori_ins_type where ipolicy = a.ipolicy)::lvarchar, 'MULTISET{',''), 'ROW(''',''),''')',''),'}',''),',','�B') as iins_list,  "
            "       replace(replace(replace(replace(replace( multiset (select unique trim(insure_instype)  "
            "          from policy_main_dtl where ipolicy1 = a.ilast_ply and ipolicy2 = ' ')::lvarchar, 'MULTISET{',''), 'ROW(''',''),''')',''),'}',''),',','�B') as ilast_iins_list,  "
            "       nvl((select iofficer from policy_new where insure_type = 'C'  "
            "          and isys_source = 'CAR' and ipolicy1 = a.ilast_ply and ipolicy2 = ' '),' ') as ilast_iofficer,  "
            "       a.iofficer, b.plia_acc, b.pdmg_acc, b.psex_age_damage,  "
            "       b.psex_age, b.pdmg_factor, b.pbrg_factor,  "
            "       decode(a.fcard_class, '1',0, a.mdmg_prem + a.mlia_prem) as mprem_v ,  "
            "       nvl((select d.mins_premium from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '01'),0) as mprem_01,  "
            "       nvl((select d.mins_premium from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '05'),0) as mprem_05,  "
            "       nvl((select d.mins_premium from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '09'),0) as mprem_09,  "
            "       nvl((select d.mins_premium from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '11'),0) as mprem_11,  "
            "       nvl((select d.mins_premium from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '98'),0) as mprem_98,  "
            "       nvl((select d.mins_premium from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '31'),0) as mprem_31,  "
            "       nvl((select d.mins_premium from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '32'),0) as mprem_32,  "
            "       nvl((select d.mins_premium from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '29'),0) as mprem_29,  "
            "       nvl((select d.mins_premium from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '30'),0) as mprem_30,  "
            "       nvl((select d.mins_premium from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '301'),0) as mprem_301,  "
            "       nvl((select d.mins_premium from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '38'),0) as mprem_38,  "
            "       nvl((select d.mins_premium from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '39'),0) as mprem_39,  "
            "       nvl((select d.mins_premium from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '105'),0) as mprem_105,  "
            "       nvl((select d.mins_premium from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '55'),0) as mprem_55,  "
            "       nvl((select d.mins_premium from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '56'),0) as mprem_56,  "
            "       nvl((select d.mdamage_cover from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '01'),0) as mdamage_01,  "
            "       nvl((select d.mdamage_cover from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '05'),0) as mdamage_05,  "
            "       nvl((select d.mdamage_cover from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '09'),0) as mdamage_09,  "
            "       nvl((select d.mdamage_cover from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '11'),0) as mdamage_11,  "
            "       nvl((select d.mdamage_cover from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '98'),0) as mdamage_98,  "
            "       nvl((select d.minjured_cover from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '31'),0) as minjured_31,  "
            "       nvl((select d.mdamage_cover from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '31'),0) as mdamage_31,  "
            "       nvl((select d.mdamage_cover from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '32'),0) as mdamage_32,  "
            "       nvl((select d.mdamage_cover from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '29'),0) as mdamage_29,  "
            "       nvl((select d.mdamage_cover from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '30'),0) as mdamage_30,  "
            "       nvl((select d.mdamage_cover from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '301'),0) as mdamage_301,  "
            "       nvl((select d.mdeath_cover from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '55'),0) as mdeath_55,  "
            "       nvl((select d.mdamage_cover from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '55'),0) as mdamage_55,  "
            "       nvl((select d.mdamage_cover from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '56'),0) as mdamage_56,  "
            "       nvl((select unique e.daily_pay from %s:ca_pa_ori e where e.ipolicy = a.ipolicy and e.iins_type = '56' and e.iins_scope = '2'),0) as daily_pay_2,  "
            "       nvl((select unique e.daily_pay from %s:ca_pa_ori e where e.ipolicy = a.ipolicy and e.iins_type = '56' and e.iins_scope = '3'),0) as daily_pay_3,  "
            "       nvl((select d.mdeduct from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '01'),0) as mdeduct_01,  "
            "       nvl((select d.mdeduct from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '05'),0) as mdeduct_05,  "
            "       nvl((select d.mdeduct from %s:ori_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '09'),0) as mdeduct_09,  "
            "       (select nname from officer where iofficer = a.ileader) as nleader,  "
            "       case when a.fout_print = '1' and fmail_type != 0 then 'Y' else 'N' end as fout_print,  "
            "       case when b.nequipment[1] in ('1','3','5','7','9','B','D','F','H','J') then 'Y' else ' ' end as nequipment_01,  "
            "       case when fcard_class = '1' then  case when a.qply_period <=12 then '�@�~��' else '�G�~��' end else ' ' end as qply_period  "
            "  from %s:ori_ply_relation a, %s:original_ply b  "
	        " where a.dpolicy between ? and ? %s and a.ipolicy = b.ipolicy %s %s;",
	        list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,
	        list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,
	        list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,
	        list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,
	        list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,
	        list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,
	        list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,
	        list[i].dbname,list[i].dbname, stmt_card,stmt_route,stmt_type);
     
     printf("stmt[%d][%s]\n",strlen(stmt),stmt);
     
      $prepare pre_ply from $stmt;
      $execute pre_ply using $dbgn1, $dend1;
     

     /*--- ��� ---*/
     memset(stmt,0x00,sizeof(stmt));
     sprintf_s(stmt, sizeof stmt,"insert into car606  "
        "select case when a.icar_type in ('01','02','32','34','35') then '����' else '�T��' end as fcm,  "
        "       e.itmp_policy, a.ipolicy, decode(a.fcard_class,'1',a.ipolicy,' ') as ipolicy_c,  "
        "       decode(a.fcard_class,'1',e.ilast_ply,' ') as ilast_ply_c, a.irelative_ply,  "
        "       decode(a.fcard_class,'2',a.ipolicy,' ') as ipolicy_v,  "
        "       decode(a.fcard_class,'2',e.ilast_ply,' ') as ilast_ply_v,  "
        "       decode(a.fcard_class,'2',e.inext_ply,' ') as inext_ply_v,  "
        "       decode(a.fcard_class,'2',a.dedr_begin,null) as dply_bgn_v,  "
        "       decode(a.fcard_class,'2',a.dedr_end,null) as dply_end_v,  "
        "       decode(a.fcard_class,'1',a.dedr_begin,null) as dply_bgn_c,  "
        "       decode(a.fcard_class,'1',a.dedr_end,null) as dply_end_c,  "
        "       a.iendorse, a.icard, b.iassured, b.nassured,  "
        "       case when b.fassured in ('1','3','5') then '�۵M�H' else '�k�H' end as fassured,  "
        "       b.itag, b.dissue, a.dendorse,  "
        "       case when nvl(e.ilast_ply,' ') = ' ' then 'N' else 'Y' end as nrenew,  "
        "       a.ipro_year, b.qpro_month, a.icar_type,  "
        "       (select ncode from car_type where fclass = '1' and icode = a.icar_type) as ncar_type,  "
        "       a.ibrand, b.nbrand_abbr, ' ' as series_name, decode(b.fsex,'1','�k','2','�k',' ') as fsex,  "
        "       b.dbirth, e.qnext_year+1 as iqyer,  "
        "       replace(replace(replace(replace(replace( multiset (select trim(iins_type) from %s:edr_ins_type  "
        "          where iendorse = a.iendorse)::lvarchar, 'MULTISET{',''), 'ROW(''',''),''')',''),'}',''),',','�B') as iins_list,  "
        "       replace(replace(replace(replace(replace( multiset (select unique trim(insure_instype) from policy_main_dtl  "
        "          where ipolicy1 = e.ilast_ply and ipolicy2 = ' ')::lvarchar, 'MULTISET{',''), 'ROW(''',''),''')',''),'}',''),',','�B') as ilast_iins_list,  "
        "       nvl((select iofficer from policy_new where insure_type = 'C'  "
        "          and isys_source = 'CAR' and ipolicy1 = e.ilast_ply and ipolicy2 = ' '),' ') as ilast_iofficer,  "
        "       a.iofficer, b.plia_acc, b.pdmg_acc, b.psex_age_damage,  "
        "       b.psex_age, b.pdmg_factor, b.pbrg_factor,  "
        "       decode(a.fcard_class, '1',0, a.medrdmg_prem + a.medrlia_prem) as mprem_v ,  "
        "       nvl((select d.medrins_prem from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '01'),0) as mprem_01,  "
        "       nvl((select d.medrins_prem from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '05'),0) as mprem_05,  "
        "       nvl((select d.medrins_prem from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '09'),0) as mprem_09,  "
        "       nvl((select d.medrins_prem from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '11'),0) as mprem_11,  "
        "       nvl((select d.medrins_prem from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '98'),0) as mprem_98,  "
        "       nvl((select d.medrins_prem from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '31'),0) as mprem_31,  "
        "       nvl((select d.medrins_prem from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '32'),0) as mprem_32,  "
        "       nvl((select d.medrins_prem from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '29'),0) as mprem_29,  "
        "       nvl((select d.medrins_prem from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '30'),0) as mprem_30,  "
        "       nvl((select d.medrins_prem from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '301'),0) as mprem_301,  "
        "       nvl((select d.medrins_prem from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '38'),0) as mprem_38,  "
        "       nvl((select d.medrins_prem from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '39'),0) as mprem_39,  "
        "       nvl((select d.medrins_prem from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '105'),0) as mprem_105,  "
        "       nvl((select d.medrins_prem from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '55'),0) as mprem_55,  "
        "       nvl((select d.medrins_prem from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '56'),0) as mprem_56,  "
        "       nvl((select d.medrdmg_cover from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '01'),0) as mdamage_01,  "
        "       nvl((select d.medrdmg_cover from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '05'),0) as mdamage_05,  "
        "       nvl((select d.medrdmg_cover from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '09'),0) as mdamage_09,  "
        "       nvl((select d.medrdmg_cover from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '11'),0) as mdamage_11,  "
        "       nvl((select d.medrdmg_cover from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '98'),0) as mdamage_98,  "
        "       nvl((select d.medrinj_cover from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '31'),0) as minjured_31,  "
        "       nvl((select d.medrdmg_cover from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '31'),0) as mdamage_31,  "
        "       nvl((select d.medrdmg_cover from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '32'),0) as mdamage_32,  "
        "       nvl((select d.medrdmg_cover from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '29'),0) as mdamage_29,  "
        "       nvl((select d.medrdmg_cover from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '30'),0) as mdamage_30,  "
        "       nvl((select d.medrdmg_cover from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '301'),0) as mdamage_301,  "
        "       nvl((select d.medrdea_cover from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '55'),0) as mdeath_55,  "
        "       nvl((select d.medrdmg_cover from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '55'),0) as mdamage_55,  "
        "       nvl((select d.medrdmg_cover from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '56'),0) as mdamage_56,  "
        "       nvl((select max(e.medr_daily_pay) from %s:ca_pa_edr e where e.iendorse = a.iendorse and e.iins_type = '56' and e.iins_scope = '2' and medrins_prem <> 0),0) as daily_pay_2,  "
        "       nvl((select max(e.medr_daily_pay) from %s:ca_pa_edr e where e.iendorse = a.iendorse and e.iins_type = '56' and e.iins_scope = '3' and medrins_prem <> 0),0) as daily_pay_3,  "
        "       nvl((select d.mdeduct from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '01'),0) as mdeduct_01,  "
        "       nvl((select d.mdeduct from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '05'),0) as mdeduct_05,  "
        "       nvl((select d.mdeduct from %s:edr_ins_type d where d.iendorse = a.iendorse and d.iins_type = '09'),0) as mdeduct_09,  "
        "       (select nname from officer where iofficer = a.ileader) as nleader,  "
        "       case when e.fout_print = '1' and fmail_type != 0 then 'Y' else 'N' end as fout_print,  "
        "       case when b.nequipment[1] in ('1','3','5','7','9','B','D','F','H','J') then 'Y' else ' ' end as nequipment_01,  "
        "       case when a.fcard_class = '1' then  case when b.qply_period <=12 then '�@�~��' else '�G�~��' end else ' ' end as qply_period  "
	    "  from %s:edr_relation a, %s:endorsement b, %s:ply_relation e "
	    " where a.iendorse= b.iendorse and a.ipolicy = e.ipolicy  "
	    "   and a.dendorse between ? and ? and dedr_close is not null %s %s %s",
	    list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,
	    list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,
	    list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,
	    list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,
	    list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,
	    list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,
	    list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,
	    list[i].dbname,list[i].dbname,list[i].dbname, stmt_card,stmt_route,stmt_type1);
	    
	  printf("stmt[%d][%s]\n",strlen(stmt),stmt);  
      $prepare pre_edr from $stmt;
      $execute pre_edr using $dbgn1, $dend1;

      sprintf_s(stmt, sizeof stmt,"select a.ipolicy, a.iendorse, a.ibrand, a.ipro_year  "
                      "from car606 a, %s:policy b where a.ipolicy = b.ipolicy",
                      list[i].dbname);
    
      /* printf("stmt[%d][%s]\n",strlen(stmt),stmt); */
      $PREPARE pre_1 FROM $stmt;
      $DECLARE cur_1 CURSOR FOR pre_1;
      $OPEN cur_1;
      for(;;)
      {
        $FETCH cur_1 INTO $ipolicy, $iendorse, $ibrand, $ipro_year;
        if (SQLCODE == SQLNOTFOUND) break;
        
        printf("ipolicy[%s]iendorse=[%s]ibrand=[%s]ipro_year=[%s]\n",ipolicy,iendorse,ibrand,ipro_year);
            /* �O�� */
        if (strlen(trim(iendorse)) == 0)
        {
            sprintf_s(stmt1, sizeof stmt1,"select first 1 drate_ym  from %s:ori_ins_type   "
		                  " where ipolicy = '%s'  ",list[i].dbname,ipolicy);
        }
        else
        {   /* ��� */
            sprintf_s(stmt1, sizeof stmt1,"select first 1 drate_ym  from %s:edr_ins_type   "
		                  " where iendorse = '%s'  ",list[i].dbname,iendorse);
        }
/* printf("stmt1[%d][%s]\n",strlen(stmt1),stmt1); */
        $PREPARE pre_1a FROM $stmt1;
        $EXECUTE pre_1a INTO $drate_ym;

        $select drate  into $drate
		   from ca_rate_date
		  where itable = 'ca_car_model' and icode = $drate_ym;

        strcpy(icar_series, " ");
        rc=choose_icar_series(drate,ibrand,ipro_year,icar_series);

        if (strcmp(icar_series," ")==0)
            strcpy(icar_series_name," ");
        else if (strcmp(icar_series,"10")==0)
            strcpy(icar_series_name,"�겣��");
        else
            strcpy(icar_series_name,"�i�f��");

        $update car606
		    set series_name = $icar_series_name
	      where ipolicy = $ipolicy
		    and iendorse = $iendorse;

        strcpy(icar_series_name," ");

      }
    }

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car606_print()
{
 int	rc;
 char	sfilename[81],stitle[3000],stmt[1024];
 $char	nname[41];

    $whenever sqlerror goto errexit;

    if (strncmp(option,"1",1) == 0){
       $select nroute into $nname
          from cm_route
         where iroute = $conditions1;
       if (SQLCODE==SQLNOTFOUND) strcpy(nname,conditions1);
    }
    else {
    	 strcpy(nname," ");
    }

    strcpy(sfilename,rtrim(nname));
    strcat(sfilename,"��O���Ӫ�");
    strcpy(stitle,"�{���N��:CAR606\t");
    strcat(stitle,sfilename);
    strcat(stitle,"\t\tñ����:");
    strcat(stitle,dbgn1);
    strcat(stitle,"��");
    strcat(stitle,dend1);
    strcat(stitle,"\t\t\t\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");
    strcat(sfilename,"[CAR606]");

    strcat(stitle,"\t �T�����O(�T���B����)\t �����渹\t �j��O�渹\t �e���j��O��\t ");
    strcat(stitle,"���p�O��\t ���N�I�O�渹\t �e�����N�I�O�渹�X\t ���N��O�渹\t ���N�I�O��ͮĤ�\t ");
    strcat(stitle,"���N�I�O������\t �j���I�O��ͮĤ�\t �j���I�O������\t ��渹�X\t �ҥd��\t ");
    strcat(stitle,"�Q�O�I�HID\t �Q�O�I�H�W��\t �Ȥᨭ��(�۵M�H/�k�H)\t ���P\t �o�Ӥ��\t");
    strcat(stitle,"ñ���\t �s��O(Y:��O N:�s��)\t �s�y�~��\t �s�y���\t ���إN��\t ");
    strcat(stitle,"���ئW��\t �t�P�N��\t �t�P�W��\t �겣/�i�f\t �Q�O�I�H�ʧO\t ");
    strcat(stitle,"�Q�O�I�H�ͤ�\t �w��O�~��\t �O�I�����C��\t �e���O��O�I�����C��\t �e���O��g��N��\t");
    strcat(stitle,"�̷s�O��g��N��\t ���d�I�ߴڬ����Y��\t �����I�ߴڬ����Y��\t �~�֩ʧO�Y�ơ]����^\t ");
    strcat(stitle,"�~�֩ʧO�Y�ơ]���d�^\t �t�N�O�v�N���Y��(����)\t �t�N�O�v�N���Y��(�ѵs)\t");
    strcat(stitle,"�`���N�I�O�O\t 01�O�O\t 05�O�O\t 09�I�O�O\t 11�O�O\t 98�I�O�O\t");
    strcat(stitle,"31�I�O�O\t 32�I�O�O\t 29�O�O\t 30�O�O\t 301�O�O\t 38�I�O�O\t 39�I�O�O\t");
    strcat(stitle,"105�O�O\t 55�O�O\t 56�O�O\t 01�O�B\t 05�O�B\t 09�O�B\t 11�O�B\t ");
    strcat(stitle,"98�O�B\t 31��˫O�B\t 31�ƬG�O�B\t 32�]�l�O�B\t 29�I�ƬG�O�B\t");
    strcat(stitle,"30�I�ƬG�O�B\t 301�ƬG�O�B\t 55���`�O�B\t 55�ƬG�O�B\t 56���ݫO�I��\t");
    strcat(stitle,"56���|�������B\t 56����I\t 01�ۭt�B\t 05�ۭt�B\t 09�ۭt�B\t");
    strcat(stitle,"�޲z�H\t �e�~�C�L\t �ɨ����O\t �j���I�@�~��/�G�~��\t");

    strcpy(stmt,"select fcm, itmp_policy, ipolicy_c, ilast_ply_c, irelative_ply,  "
                "       ipolicy_v, ilast_ply_v, inext_ply_v, dply_bgn_v, dply_end_v,  "
                "       dply_bgn_c, dply_end_c, iendorse, icard, iassured, nassured,  "
                "       fassured, itag, dissue, dpolicy, nrenew, ipro_year, ipro_month,  "
                "       icar_type, ncar_type, ibrand, nbrand_abbr, series_name, fsex,  "
                "       dbirth, iqyear, iins_list, ilast_iins_list, ilast_iofficer,  "
                "       iofficer, plia_acc, pdmg_acc, psex_age_damage, psex_age,  "
                "       pdmg_factor, pbrg_factor, mprem_v, mprem_01, mprem_05,  "
                "       mprem_09, mprem_11, mprem_98, mprem_31, mprem_32, mprem_29,  "
                "       mprem_30, mprem_301, mprem_38, mprem_39, mprem_105, mprem_55,  "
                "       mprem_56, mdamage_01, mdamage_05, mdamage_09, mdamage_11,  "
                "       mdamage_98, minjured_31, mdamage_31, mdamage_32, mdamage_29,  "
                "       mdamage_30, mdamage_301, mdeath_55, mdamage_55, mdamage_56,  "
                "       daily_pay_2, daily_pay_3, mdeduct_01, mdeduct_05, mdeduct_09,  "
                "       nleader, fout_print, nequipment_01, qply_period  "
                "   from car606 order by fcm, ipolicy ");
printf("stitle [%d] stmt=[%d]\n", strlen(stitle),strlen(stmt));
    rc = unload_file(outputf," ",sfilename,stitle,stmt);

    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car606_privilege()
{
$int    flevel = 0,cnt = 0;
$char   iquota[7],falldb[2];

    $whenever sqlerror goto errexit;

printf("--- car606_privilege start userid=[%s] --\n",userid);

    $select falldb
       into $falldb
       from privilege
      where iemp = $userid
        and ipgid = 'car606';
printf("--- 579--conditions1=[%s]userid=[%s]falldb[%s]\n",conditions1,userid,falldb);
    /* �����ٸ�Ʈw�v����,�L���ˮֳq���޲z�H */
    if (falldb[0]=='Y')
        return M_CM_OK;

    $select count(*)
       into $cnt
       from cm_route
      where iroute = $conditions1
        and ileader = $userid;
        printf("--- 589--\n");
    if (cnt==0) {
        printf("--- 591--\n");
      strcpy(msgbuf,"�z�D�q���޲z�H�A���i���榹�q�����");
      EWRITE(userid,10,msgbuf);
      return 10;
    }
    
printf("--- car606_privilege end --");
    
    return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*---------------------------------------------------------end program*/

/* 104.09.09 fix ca_car_model �^���޿� */
long choose_icar_series(drate_f,ibrand_f,ipro_year_f,icar_series_f)
$char *drate_f,*ibrand_f,*ipro_year_f,*icar_series_f;
{
  $whenever sqlerror goto errexit;
  /*printf("drate_f[%s],ibrand_f[%s],ipro_year_f[%s],icar_series_f[%s]\n",drate_f,ibrand_f,ipro_year_f,icar_series_f);*/
		$SELECT first 1 icar_series
		into $icar_series_f
		FROM ca_car_model
		WHERE ibrand= $ibrand_f
		and ipro_year = $ipro_year_f
		and (dexpire is null or dexpire > today)
		and drate = $drate_f;

		/*printf("�嵥��\n");*/
		if (SQLCODE==SQLNOTFOUND)
		{
			$SELECT first 1 icar_series
			into $icar_series_f
			FROM ca_car_model
			WHERE ibrand= $ibrand_f
			and ipro_year < $ipro_year_f
			and (dexpire is null or dexpire > today)
			and drate = $drate_f
			ORDER BY ipro_year DESC;
			/*printf("��j��\n");*/
			if (SQLCODE==SQLNOTFOUND)
			{
				$SELECT first 1 icar_series
				into $icar_series_f
				FROM ca_car_model
				WHERE ibrand= $ibrand_f
				and ipro_year > $ipro_year_f
				and (dexpire is null or dexpire > today)
				and drate = $drate_f
				ORDER BY ipro_year ;
				/*printf("��p��\n");*/
				if (SQLCODE==SQLNOTFOUND)
				{

					$SELECT first 1 icar_series
					into $icar_series_f
					FROM ca_car_model
					WHERE ibrand= $ibrand_f
					and ipro_year = $ipro_year_f
					and (dexpire is null or dexpire > today);
					/*printf("�䤣��\n");*/
					if (SQLCODE==SQLNOTFOUND)
				         strcpy(icar_series_f,'');
			        }
			}
	           }
return M_CM_OK;
errexit:
sqlfatal();
EWRITE(userid,SQLCODE,sqlca.sqlerrm);
return SQLCODE;

}

/* ------------------------------------------------------------------------- */
long car606_process_bak()
{
int     k,rc;
$int	cnt;
$char   stmt[4096],stmt1[256],stmt2[256];
$char	stmt_fcard[256];
$char	ipolicy[21],iendorse[21],npay_type[9];
$char	iply1[21],iply2[21],nequipment[31],nequip_01[2];
$long	mstl;
$char   icar_series[3],icar_series_name[9],ibrand[9],ipro_year[5],ibrand_e[9],ipro_year_e[5],drate_ym[5];
$char  drate[11];
/*void choose_icar_series(char drate_f,char ibrand_f,char ipro_year_f,char icar_series_f);*/
/*void choose_icar_series($char,$char,$char,$char);*/

   $whenever sqlerror goto errexit;

   for(i=0;i<count_db;i++)
   {
      /*--- Ū����l�O��A�O��~Ū���ߥI���B ---*/
      sprintf_s(stmt, sizeof stmt,"insert into car606  "
	    "select case when icar_type in ('01','02','32','34','35') then '����' "
	    "	else '�T��' end,a.ipolicy,a.irelative_ply,' ',a.itmp_policy,a.icard, "
	    "	iassured[1,3]||'****'||iassured[8,10],nassured,itag, "
	    "	nbrand_abbr,aassured,dissue,dpolicy,dply_begin,dply_end, "
	    "	mlia_prem+mdmg_prem,case when nvl(ilast_ply,'') = '' then "
	    "	'�s�O' else '��O' end,iofficer,(select iofficer from "
	    "	%s:ply_relation where ipolicy = a.ilast_ply),'', "
	    "	(select sum(decode(fstl,'2',msettle*-1,msettle)) "
	    "	from %s:settlement where ipolicy = a.ipolicy  "
	    "	and dgroup is not null), "
	    "	(select mins_premium from %s:ori_ins_type "
	    "	where ipolicy = a.ipolicy and iins_type = '05'), "
	    "	(select mins_premium from %s:ori_ins_type "
	    "	where ipolicy = a.ipolicy and iins_type = '11'), "
	    "	(select mins_premium from %s:ori_ins_type "
	    "	where ipolicy = a.ipolicy and iins_type = '09'), "
	    "	(select mins_premium from %s:ori_ins_type "
	    "	where ipolicy = a.ipolicy and iins_type = '98'), "
	    "	(select mins_premium from %s:ori_ins_type "
	    "	where ipolicy = a.ipolicy and iins_type = '105'), "
	    " (select sum(mins_premium) from %s:ori_ins_type "
	    " where ipolicy = a.ipolicy and iins_type in ('118','119')), "
	    " (select sum(mins_premium) from %s:ori_ins_type "
	    " where ipolicy = a.ipolicy and iins_type in ('120','121')), "
	    " (select sum(mins_premium) from %s:ori_ins_type "
	    " where ipolicy = a.ipolicy and iins_type in ('122','123')), "
	    "	(select mins_premium from %s:ori_ins_type "
	    "	where ipolicy = a.ipolicy and iins_type = '125'), "
	    "	(select mins_premium from %s:ori_ins_type "
	    "	where ipolicy = a.ipolicy and iins_type = '126'), "
	    "	(select mins_premium from %s:ori_ins_type "
	    "	where ipolicy = a.ipolicy and iins_type = '129'), "
	    "	(select mins_premium from %s:ori_ins_type "
	    "	where ipolicy = a.ipolicy and iins_type = '137'), "
	    " (select sum(mins_premium) from %s:ori_ins_type "
	    " where ipolicy = a.ipolicy and iins_type in ('138','139')), "
	    "	'',nequipment,'','',a.ibrand,a.ipro_year,'','', "
	    " a.fout_print,a.fmail_type,  "
	    " (select nname from officer where iofficer = a.ileader)  "
	    "  from %s:ori_ply_relation a,%s:original_ply b "
	    " where a.dpolicy between ? and ? %s  "
	    "   and a.ipolicy = b.ipolicy %s %s;",list[i].dbname,list[i].dbname,
	    list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,
	    list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,
	    list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,
	    stmt_card,stmt_route,stmt_type);
      $prepare pre_ply_bak from $stmt;
      $execute pre_ply_bak using $dbgn1, $dend1;
     /* printf("stmt[%s]\n",stmt);*/

     /*--- ��� ---*/
     memset(stmt,0x00,sizeof(stmt));
     sprintf_s(stmt, sizeof stmt,"insert into car606  "
	   "select case when a.icar_type in ('01','02','32','34','35') then '����' "
	   "	else '�T��' end,a.ipolicy,a.irelative_ply,a.iendorse,e.itmp_policy,a.icard, "
	   "	iassured[1,3]||'****'||iassured[8,10],nassured,itag, "
	   "	nbrand_abbr,aassured,dissue,a.dendorse,dedr_begin,dedr_end, "
	   "	medrlia_prem+medrdmg_prem, "
	   "	case when nvl(e.ilast_ply,'') = '' then '�s�O' "
	   "	else '��O' end,a.iofficer,(select iofficer from "
	   "	%s:ply_relation c where c.ipolicy = e.ilast_ply),'','', "
	   "	(select medrins_prem from %s:edr_ins_type "
	   "	where iendorse = a.iendorse and iins_type = '05'), "
	   "	(select medrins_prem from %s:edr_ins_type "
	   "	where iendorse = a.iendorse and iins_type = '11'), "
	   "	(select medrins_prem from %s:edr_ins_type "
	   "	where iendorse = a.iendorse and iins_type = '09'), "
	   "	(select medrins_prem from %s:edr_ins_type "
	   "	where iendorse = a.iendorse and iins_type = '98'), "
	   "	(select medrins_prem from %s:edr_ins_type "
	   "	where iendorse = a.iendorse and iins_type = '105'), "
	   "  (select sum(medrins_prem) from %s:edr_ins_type "
	   "  where iendorse = a.iendorse and iins_type in ('118','119')), "
	   "  (select sum(medrins_prem) from %s:edr_ins_type "
	   "  where iendorse = a.iendorse and iins_type in ('120','121')), "
	   "  (select sum(medrins_prem) from %s:edr_ins_type "
	   "  where iendorse = a.iendorse and iins_type in ('122','123')), "
	   "	(select medrins_prem from %s:edr_ins_type "
	   "	where iendorse = a.iendorse and iins_type = '125'), "
	   "	(select medrins_prem from %s:edr_ins_type "
	   "	where iendorse = a.iendorse and iins_type = '126'), "
	   "	(select medrins_prem from %s:edr_ins_type "
	   "	where iendorse = a.iendorse and iins_type = '129'), "
	   "	(select medrins_prem from %s:edr_ins_type "
	   "	where iendorse = a.iendorse and iins_type = '137'), "
	   "  (select sum(medrins_prem) from %s:edr_ins_type "
	   "  where iendorse = a.iendorse and iins_type in ('138','139')), "
	   "	'',nequipment,'','','','',a.ibrand,a.ipro_year, "
	   "  e.fout_print,e.fmail_type,  "
	   "  (select nname from officer where iofficer = a.ileader)  "
	   "  from %s:edr_relation a, %s:endorsement b, %s:ply_relation e "
	   " where a.dendorse between ? and ? %s  "
	   "   and a.iendorse= b.iendorse %s %s "
	   "   and a.ipolicy = e.ipolicy;",list[i].dbname,list[i].dbname,
	    list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,
	    list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,
	    list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,
	    stmt_card,stmt_route,stmt_type1);
      $prepare pre_edr_bak from $stmt;
      $execute pre_edr_bak using $dbgn1, $dend1;

      /* printf("stmt[%s]\n",stmt);*/
      $declare cur_tmp_bak cursor for
        select ipolicy,ipolicy[1,13],ipolicy[14,20],iendorse,nequipment,ibrand,ipro_year,ibrand_e,ipro_year_e
          from car606;
      $open    cur_tmp_bak;

      while(1) {
         $fetch cur_tmp_bak
         into $ipolicy,$iply1,$iply2,$iendorse,$nequipment,$ibrand,$ipro_year,$ibrand_e,$ipro_year_e;
	    /* printf("ipolicy[%s]iendorse[%s]nequipment[%s]ipro_year[%s]$ibrand\n",ipolicy,iendorse,nequipment,ipro_year,ibrand);*/
	       if (SQLCODE==SQLNOTFOUND) break;
	    /*** ���O�覡npay_type ***/
	    /* �t�X�]�|���پ�X�@�~, ao_prem_rcv_detail �s�W isub ��� modify by sylvia 101.07.23 (1001228004_C1) */
         $declare cur_pay cursor for
           select case when (select media_code from ao_prem_temp x
          	where x.itmp_no = d.irelative)='19' then '�K�Q�ө�'
           	when (select media_code from ao_prem_temp x
          	where x.itmp_no = d.irelative)='06'  then '�����b��'
          	when nvl((select itype from ao_prem_temp s
          	where s.itmp_no = d.irelative ),'') = '2' then '������'
          	when nvl((select itmp_no from ao_prem_crd_detail y
          	where y.itmp_no = d.irelative ),'') <> '' then '�H�Υd'
          	when d.itype = '2' then 'ATM'
          	when d.itype = '1' then '�{��'
          	when d.itype = '3' then '����'
          	else '' end
            from ao_prem_rcv c,ao_prem_rcv_detail d
           where c.ipolicy1 = $iply1
      	     and c.ipolicy2 = $iply2
             and c.iendorse = $iendorse
       	     and c.ircv = d.ircv
	           and c.iseq = d.iseq
             and d.itype != '7'
             and d.isub = $isub
             and d.iseq2 = (select min(iseq2) from ao_prem_rcv_detail
		                         where ircv = c.ircv and iseq = c.iseq and isub = $isub);

	      $open cur_pay;
	      $fetch cur_pay into $npay_type;
	      /*  printf("npay_type[%s]\n",npay_type);*/
	      if (SQLCODE==SQLNOTFOUND)
	      strcpy(npay_type," ");
	      $close cur_pay;
	      /* �ɨ����O nequip_01*/
	      strcpy(nequip_01," ");
	      if (equip_cmp(nequipment,"01")==TRUE) strcpy(nequip_01,"Y");
	      if (npay_type[0]!='' || nequip_01 == 'Y') {

	        $update car606
		          set npay_type = $npay_type,
		              nequip_01 = $nequip_01
	          where ipolicy = $ipolicy
		          and iendorse = $iendorse;
	      }
	      strcpy(icar_series,'');

	      /*printf("�ɨ����O����\n");*/
	      /*���t*****/
	      /*printf("iendorse[%s]\n",iendorse);*/

	      if (strcmp(trim(iendorse),'')!=0)/*���*/
	      {
		      sprintf_s(stmt1, sizeof stmt1,"select first 1 drate_ym  "
                        "  from %s:edr_ins_type   "
		                    " where iendorse = '%s'  ",list[i].dbname,iendorse);
				  $PREPARE prep1_bak FROM $stmt1;
          $EXECUTE prep1_bak INTO $drate_ym;

		      $select drate
		         into $drate
		         from ca_rate_date
		        where itable = 'ca_car_model' and icode = $drate_ym;

		        rc=choose_icar_series(drate,ibrand_e,ipro_year_e,icar_series);
		      /* if (rc != M_CM_OK)
			         return rc;*/
		      /*printf("choose����\n");	*/
	      }
	      else/*�O��*/
	      {
	      	sprintf_s(stmt2, sizeof stmt2,"select first 1 drate_ym  "
                        "  from %s:ori_ins_type   "
		                    " where ipolicy = '%s'  ",list[i].dbname,ipolicy);
				  $PREPARE prep2_bak FROM $stmt2;
          $EXECUTE prep2_bak INTO $drate_ym;

		      $select drate
		         into $drate
		         from ca_rate_date
		        where itable = 'ca_car_model' and icode =$drate_ym;

		       rc=choose_icar_series(drate,ibrand,ipro_year,icar_series);
		      /*if (rc != M_CM_OK)
			       return rc;	*/
		      /*printf("choose����\n");	*/
	      }

       if (strcmp(icar_series,"10")==0)
       strcpy(icar_series_name,"�겣��");
       else if (strcmp(icar_series,"20")==0)
       strcpy(icar_series_name,"���ꨮ");
       else if (strcmp(icar_series,"21")==0)
       strcpy(icar_series_name,"�֯S");
       else if (strcmp(icar_series,"22")==0)
       strcpy(icar_series_name,"�q��");
       else if (strcmp(icar_series,"23")==0)
       strcpy(icar_series_name,"�J�ܴ���");
       else if (strcmp(icar_series,"24")==0)
       strcpy(icar_series_name,"���W�騮");
       else if (strcmp(icar_series,"30")==0)
       strcpy(icar_series_name,"�ڬw��");
       else if (strcmp(icar_series,"40")==0)
       strcpy(icar_series_name,"�饻��");
       else if (strcmp(icar_series,"50")==0)
       strcpy(icar_series_name,"���ꨮ");
       else if (strcmp(icar_series,"90")==0)
       strcpy(icar_series_name,"�䥦");
       else
       strcpy(icar_series_name,'');

       $update car606
		       set icar_series = $icar_series,
		           icar_series_name = $icar_series_name
	       where ipolicy = $ipolicy
		       and iendorse = $iendorse;
      }
    $free  cur_pay;
    $close cur_tmp_bak;
    $free  cur_tmp_bak;
   }
    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}