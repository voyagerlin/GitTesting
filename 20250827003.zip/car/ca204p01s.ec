/************************************************/
/*                                              */
/*   PROGRAM : ca204p01s.ec                     */
/*   Reviser : Johnny 6/39/1997                 */
/*   Checked for ����100�~�M��                  */
/*                                              */
/************************************************/
     
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;

int insert_into_deduct();
int upd_into_deduct();

long car204(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
     long rtncode;
     long car204_update_exec();
     long car204_single_query();
     long car204_icard_count();
     long car204_receive_count();
     char option;

     cm_buf_init(command);
     cm_buf_get("%c",&option);
     switch(option)
     {
          case 'P':
                   rtncode=car204_update_exec(reply);
                   break;
          case '1':
                   rtncode=car204_single_query(reply);
                   break;
          case '2':
                   rtncode=car204_icard_count(reply);
                   break;
          case '3':
                   rtncode=car204_get_comp_officer(reply);
                   break;
          case '4':
                   rtncode=car204_receive_count(reply);
                   break;
          default :
                return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
     }
     return(rtncode);
}

/***************************************************************************/
long car204_update_exec(reply)
serverReply reply;
{
     /* standard defined host variables */
     $char DBName[5];
     int rc;
     /* end of standard host var */

     /* table card and compulsory-card */
     $char cardbegin[CARD_NUM], cardend[CARD_NUM];
     $char officer1[EMPLOYEE_ID], officer2[EMPLOYEE_ID];
     $char alterer[EMPLOYEE_ID];
     $long dalter;
     $char icard[CARD_NUM],icard1[CARD_NUM],icard2[CARD_NUM];
     $char icard_repeat[21]; /* ���T�O�d���έ��Ƨ�O�d�� */
     $char sFstatus[2];
     
     $char date[11],dToday[11],nyy[4],nmm[3],ndd[3];
     $char sIcard[21], sIcard_road[21], sFtype[2];
     $char sStmt[512];
     $char iupdate[10],dupdate[11],dupdate1[11];    /*USER�ۦ��J�����ʤH�����s�P���ʤ��*/
     char  sApHome[30], filename[128], filepath[256];
     FILE  *fp;
     int cnt_road, cnt=0;
     $char ideliver[11];
     /* end of card and compulsory-card */

     /* standard defined data */
     int tmp_len;
     long MsgCode;
     /* end of standard data */

     /* self defined data */
     char status;
     char cardclass;
     char s_dalter[20];
     int i,count=0;
     /* end of self data */

     cm_buf_get("%s",DBName);
     cm_buf_get("%c %c %s %s %s %s %s %s %s %s",
                &cardclass,&status,cardbegin,cardend,ideliver,alterer,icard_repeat,sFstatus,iupdate,dupdate);
     dalter=cm_today();
     strcpy(dupdate1,cm_to_infdate(dupdate));
     
     printf(" value:%c,%c,%s,%s,%s,%s,%s,%s,%s.\n",
               cardclass,status,cardbegin,cardend,alterer,icard_repeat,sFstatus,iupdate,dupdate);
     
     printf("dupdate1=%s\n",dupdate1);
               
     strcpy(date,cm_edate_str(dalter));  
     strcpy(dToday,cm_from_infdate_100(date));
     cm_split_ymd_100(dToday,nyy,nmm,ndd);         

     /****************************************************
     if (cardbegin[0]=='*') strcpy(cardbegin, "        ");
     if (cardend[0]=='*')
           strcpy(cardend, "~~~~~~~~");
     else if (cardend[0]==' ')
           strcpy(cardend, cardbegin);
     ****************************************************/         

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
        	
     rc = getApHome(sApHome);
	   if (rc < 0) {
		   return rc;
     }
     
     printf ("cardclass:%c\n",cardclass);
     
     EXEC SQL BEGIN WORK;
     if (cardclass=='1')
     {
     	  /*�ݩ󤽸��ʲz�����Ѫ��j���Ҹ�(���ʧO:�s�W)�A���o����@�o 
     	    add by 103.06.18 (1030529009_C1)*/
     	  sprintf(filename,"car204_�j���Ҥ��i�@�o����[%s%s%s].txt",nyy,nmm,ndd);
        sprintf(filepath,"%s/rptftp/%s",sApHome,filename);
        printf("�j���Ҥ��i�@�o����[%s]\n",filepath);
        fp=fopen(filepath,"w");
        
     	  sprintf(sStmt,"SELECT icard FROM compulsory_card"
     	                " WHERE icard >= '%s' "
     	                "   AND icard <= '%s' ", cardbegin, cardend);
     	                
     	  $PREPARE comp_card FROM $sStmt;                
        $DECLARE card_cur CURSOR FOR comp_card;    
        $OPEN    card_cur;
        
        cnt_road = 0;
        cnt = 0;
        for(;;)
        {
     	    $FETCH card_cur INTO $sIcard;
     	    if (SQLCODE != 0) break;

     	    $SELECT first 1 icard, ftype
     	       INTO $sIcard_road, $sFtype
     	       FROM ca_card_road
     	      WHERE icard = $sIcard
     	      ORDER BY dcreate desc;
     	    if (SQLCODE == SQLNOTFOUND)
     	    {
     	    	strcpy(sIcard_road," ");
     	    	strcpy(sFtype," ");
     	    }
     	    
     	    strcpy(sIcard_road, trim(sIcard_road));
     	    strcpy(sFtype,trim(sFtype));
     	    printf("-----166 sIcard_road[%s],sFtype[%s]\n",sIcard_road,sFtype);
     	    if (strlen(sIcard_road) != 0 && strcmp(sFtype, "9") == 0)
     	    {
     	    	 cnt_road++;
					   fprintf(fp,"�j���Ҹ��G%s\t���j���Ҹ��ݩ󤽸��ʲz�H����J�t�Τ��j���ҡA���o�@�o�C\n",sIcard_road);  
						 continue;
     	    } 

          if (status=='1')   /*** �@�o ***/
          {
             /* printf("Begin Update !!!!!\n");
             EXEC SQL UPDATE compulsory_card
                         SET (fstatus , ialter   , dalter)
                           = ('3'     , $alterer , $dalter)
                       WHERE icard >= :cardbegin
                         AND icard <= :cardend
                         AND (fstatus = '0' OR fstatus = '2' );
             printf("End Update !!!!!\n"); */
          }
          else if (status=='2')   /*** �� ***/
          {
          	 cnt++;
             EXEC SQL UPDATE compulsory_card
                         SET (fstatus, ialter   , dalter)
                           = ('4'    , :alterer , :dalter)
                       WHERE icard = $sIcard
                         AND (fstatus = '0' OR fstatus = '2')
                         AND (trim(ipolicy) = '' OR ipolicy is null);
          }
          else if (status=='3')   /*** �@�o�ܥ��X ***/
          {
          	 cnt++;
             /* fcancel���O���ݶǰe���T�����@�o */
             EXEC SQL UPDATE compulsory_card
                         SET (fstatus , ialter   , dalter,  fcancel, icard_repeat)
                           = ('5'     , :alterer , :dalter, 'Y', ' ')
                       WHERE icard = $sIcard
                         AND fstatus in ('3','A','B','C','D','E')
                         AND (trim(ipolicy) = '' OR ipolicy is null);
          }
          else if (status=='4')  /*** ���ܥ��X ***/
          {
            cnt++;
            EXEC SQL UPDATE compulsory_card
                        SET (fstatus  , ialter   , dalter,  fmiss)
                          = ('6' , :alterer , :dalter , 'Y' )
                      WHERE icard = $sIcard
                        AND (fstatus = '4' OR fstatus = '8')
                        AND (trim(ipolicy) = '' OR ipolicy is null);

          }
          else if (status=='9')  /*** �G���@�o ***/
          {
            cnt++;
            EXEC SQL UPDATE compulsory_card
                        SET (fstatus  , ialter   , dalter,  fcancel, icard_repeat)
                          = (:sFstatus , :iupdate , :dupdate1 , ' ' , :icard_repeat)
                      WHERE icard = $sIcard
                        AND (fstatus = '5' OR fstatus = '6')
                        AND (trim(ipolicy) = '' OR ipolicy is null);

          }
          else if (status=='6')  /*** �G���� ***/
          {
          	cnt++;
            EXEC SQL UPDATE compulsory_card
                        SET (fstatus  , ialter   , dalter,  fmiss)
                          = ('4' , :iupdate , :dupdate1 , ' ' )
                      WHERE icard = $sIcard
                        AND (fstatus = '5' OR fstatus = '6')
                        AND (trim(ipolicy) = '' OR ipolicy is null);
          }
          else if (status=='7')  /*** �G�������� ***/
          {
          	cnt++;
            EXEC SQL UPDATE compulsory_card
                        SET (fstatus  , ialter   , dalter,  fmiss, ideliver)
                          = ('8' , :iupdate , :dupdate1 , ' ', :ideliver )
                      WHERE icard = $sIcard
                        AND (fstatus = '5' OR fstatus = '6')
                        AND (trim(ipolicy) = '' OR ipolicy is null);

             /********************************************************************  
             rc = insert_into_deduct(cardbegin,cardend); 
             if (rc != 1)
             {
                if (exitsub (reply, SQLCODE) == True)
                   return SQLCODE;
                else
                   return apiRC;
             }
             **********************************************************************/
          }
          else if (status=='8') /*** ������ ***/
          {
          	 cnt++;
             printf("INTO status == '8' [%s]\n",status);
             EXEC SQL UPDATE compulsory_card
                         SET (fstatus, ialter   , dalter, ideliver)
                           = ('8'    , :alterer , :dalter, :ideliver)
                       WHERE icard = $sIcard
                         AND (fstatus = '0' OR fstatus = '2'
                          OR (fstatus = '7' AND dreceive is not null))
                         AND (trim(ipolicy) = '' OR ipolicy is null);
             
             printf("sqlca.sqlerrd[2] == [%d]\n",sqlca.sqlerrd[2]);
             /************************************************************
             rc = insert_into_deduct(cardbegin,cardend); 
             if (rc != 1)
             {
                if (exitsub (reply, SQLCODE) == True)
                   return SQLCODE;
                else
                   return apiRC;
             }
             **************************************************************/
          }
          else if (status == 'A') /*** A.µ�����~�Φ��l ***/
          {
          	 cnt++;
        	   printf("INTO status == 'A' [%s]\n",status);
             EXEC SQL UPDATE compulsory_card
                         SET (fstatus, ialter   , dalter  ,icard_repeat)
                           = ('A'    , :alterer , :dalter ,:icard_repeat)
                       WHERE icard = $sIcard
                         AND (fstatus = '0'
                          OR (fstatus = '7' AND dreceive is not null))
                         AND (trim(ipolicy) = '' OR ipolicy is null);
          }
          else if (status == 'B') /*** B.���Ƨ�O ***/
          {
          	 cnt++;
        	   printf("INTO status == 'B' [%s]\n",status);
             EXEC SQL UPDATE compulsory_card
                         SET (fstatus, ialter   , dalter  ,icard_repeat)
                           = ('B'    , :alterer , :dalter ,:icard_repeat)
                       WHERE icard = $sIcard
                         AND (fstatus = '0'
                          OR (fstatus = '7' AND dreceive is not null))
                         AND (trim(ipolicy) = '' OR ipolicy is null);
          }
          else if (status == 'C') /*** C.�ܺʲz����ӥ��L ***/
          {
          	 cnt++;
        	   printf("INTO status == 'C' [%s]\n",status);
             EXEC SQL UPDATE compulsory_card
                         SET (fstatus, ialter   , dalter)
                           = ('C'    , :alterer , :dalter)
                       WHERE icard = $sIcard
                         AND (fstatus = '0'
                          OR (fstatus = '7' AND dreceive is not null))
                         AND (trim(ipolicy) = '' OR ipolicy is null);
          }
          else if (status == 'D') /*** D.���ϥΤ��@�o ***/
          {
          	 cnt++;
        	   printf("INTO status == 'D' [%s]\n",status);
             EXEC SQL UPDATE compulsory_card
                         SET (fstatus, ialter   , dalter)
                           = ('D'    , :alterer , :dalter)
                       WHERE icard = $sIcard
                         AND (fstatus = '0'
                          OR (fstatus = '7' AND dreceive is not null))
                         AND (trim(ipolicy) = '' OR ipolicy is null);
          }
          else if (status == 'E') /*** E.���l ***/
          {
          	 cnt++;
        	   printf("INTO status == 'E' [%s]\n",status);
             EXEC SQL UPDATE compulsory_card
                         SET (fstatus, ialter   , dalter  ,icard_repeat)
                           = ('E'    , :alterer , :dalter ,:icard_repeat)
                       WHERE icard = $sIcard
                         AND (fstatus = '0'
                          OR (fstatus = '7' AND dreceive is not null))
                         AND (trim(ipolicy) = '' OR ipolicy is null);
          }
        }          
     }
     else if (cardclass=='2')
     {
     	
        if (status=='1')
        {

             EXEC SQL UPDATE card
                         SET (fstatus , ialter   , dalter)
                           = ('3'     , :alterer , :dalter)
                       WHERE icard >= :cardbegin
                         AND icard <= :cardend
                         AND (fstatus = '0' OR fstatus = '2')
                         AND (trim(ipolicy) = '' OR ipolicy is null);
        }
        else if (status=='2')
        {

             EXEC SQL UPDATE card
                         SET (fstatus , ialter   , dalter)
                           = ('4'     , :alterer , :dalter)
                       WHERE icard >= :cardbegin
                         AND icard <= :cardend
                         AND (fstatus = '0' OR fstatus = '2')
                         AND (trim(ipolicy) = '' OR ipolicy is null);
        }
        else if (status=='3')
        {

             EXEC SQL UPDATE card
                         SET (fstatus , ialter   , dalter )
                           = ('5'     , :alterer , :dalter )
                       WHERE icard >= :cardbegin
                         AND icard <= :cardend
                         AND fstatus in ('3','A','B','C','D','E')
                         AND (trim(ipolicy) = '' OR ipolicy is null);
        }
        else if (status=='4')
        {

             EXEC SQL UPDATE card
                         SET (fstatus  , ialter   , dalter  ,fmiss)
                           = ('6' , :alterer , :dalter , 'Y')
                       WHERE icard >= :cardbegin
                         AND icard <= :cardend
                         AND fstatus='4'
                         AND (trim(ipolicy) = '' OR ipolicy is null);

        }
        else if (status=='5')
        {

             EXEC SQL UPDATE card
                         SET (fstatus , ialter   , dalter )
                           = ('3'     , :iupdate , :dupdate1 )
                       WHERE icard >= :cardbegin
                         AND icard <= :cardend
                         AND (fstatus = '5' OR fstatus = '6')
                         AND (trim(ipolicy) = '' OR ipolicy is null);
        }
        else if (status=='6')
        {

             EXEC SQL UPDATE card
                         SET (fstatus  , ialter   , dalter  ,fmiss)
                           = ('4' , :iupdate , :dupdate1 , ' ')
                       WHERE icard >= :cardbegin
                         AND icard <= :cardend
                         AND (fstatus = '5' OR fstatus = '6')
                         AND (trim(ipolicy) = '' OR ipolicy is null);
        }
        else if (status=='9')
        {

             EXEC SQL UPDATE card
                         SET (fstatus , ialter   , dalter )
                           = (:sFstatus , :iupdate , :dupdate1 )
                       WHERE icard >= :cardbegin
                         AND icard <= :cardend
                         AND (fstatus = '5' OR fstatus = '6')
                         AND (trim(ipolicy) = '' OR ipolicy is null);
        }
         else if (status == 'A') /*** A.µ�����~�Φ��l ***/
        {
        	   printf("INTO status == 'A' [%s]\n",status);
             EXEC SQL UPDATE card
                         SET (fstatus, ialter   , dalter)
                           = ('A'    , :alterer , :dalter)
                       WHERE icard >= :cardbegin
                         AND icard <= :cardend
                         AND (fstatus = '0'
                          OR (fstatus = '7' AND dreceive is not null))
                         AND (trim(ipolicy) = '' OR ipolicy is null);
        }
        else if (status == 'B') /*** B.���Ƨ�O ***/
        {
        	   printf("INTO status == 'B' [%s]\n",status);
             EXEC SQL UPDATE card
                         SET (fstatus, ialter   , dalter)
                           = ('B'    , :alterer , :dalter)
                       WHERE icard >= :cardbegin
                         AND icard <= :cardend
                         AND (fstatus = '0'
                          OR (fstatus = '7' AND dreceive is not null))
                         AND (trim(ipolicy) = '' OR ipolicy is null);
        }
        else if (status == 'C') /*** C.�ܺʲz����ӥ��L ***/
        {
        	   printf("INTO status == 'C' [%s]\n",status);
             EXEC SQL UPDATE card
                         SET (fstatus, ialter   , dalter)
                           = ('C'    , :alterer , :dalter)
                       WHERE icard >= :cardbegin
                         AND icard <= :cardend
                         AND (fstatus = '0'
                          OR (fstatus = '7' AND dreceive is not null))
                         AND (trim(ipolicy) = '' OR ipolicy is null);
        }
        else if (status == 'D') /*** D.���ϥΤ��@�o ***/
        {
        	   printf("INTO status == 'D' [%s]\n",status);
             EXEC SQL UPDATE card
                         SET (fstatus, ialter   , dalter)
                           = ('D'    , :alterer , :dalter)
                       WHERE icard >= :cardbegin
                         AND icard <= :cardend
                         AND (fstatus = '0'
                          OR (fstatus = '7' AND dreceive is not null))
                         AND (trim(ipolicy) = '' OR ipolicy is null);
        }
        else if (status == 'E') /*** E.���l ***/
        {
        	   printf("INTO status == 'E' [%s]\n",status);
             EXEC SQL UPDATE card
                         SET (fstatus, ialter   , dalter)
                           = ('E'    , :alterer , :dalter)
                       WHERE icard >= :cardbegin
                         AND icard <= :cardend
                         AND (fstatus = '0'
                          OR (fstatus = '7' AND dreceive is not null))
                         AND (trim(ipolicy) = '' OR ipolicy is null);
        }
     }
                  
     if ( sqlca.sqlerrd[2] == 0)
     {
          EXEC SQL WHENEVER SQLERROR CONTINUE;
          EXEC SQL ROLLBACK WORK;
          return exitsub(reply,M_CA_UPD_NRECORD) ? M_CA_UPD_NRECORD : apiRC;
     }
     /*
     if (cardclass=='1') 
     {
        if ((status == '7') || (status == '8'))
        {
           rc = insert_into_deduct(cardbegin,cardend);
           if (rc != 1)
           {
              goto errexit;
           }
        }

        if (status == '4')
        {
           rc = upd_into_deduct(cardbegin,cardend);
           if (rc != 1)
           {
              goto errexit;
           }
        }
     }
     */
     if (cardclass == '1')
     {
     	  $CLOSE card_cur;
        $FREE  card_cur;
        fclose(fp);
        
        rc=rptftpinsert(alterer,"car204",filename);
        if (rc != 0) return rc;      
     }
          
     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);
     cm_buf_put("%d %d", cnt_road, cnt);
     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
     {
        EXEC SQL WHENEVER SQLERROR CONTINUE;
        EXEC SQL ROLLBACK WORK;
        return apiRC;
     }
     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     EXEC SQL COMMIT WORK;

     return api_OKComplete;

errexit:
     MsgCode = SQLCODE;
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     if (SQLCODE != 0) MsgCode = SQLCODE;
     return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

/***************************************************************************/
long car204_single_query(reply)
serverReply reply;
{
     EXEC SQL char DBName[5];
     EXEC SQL char icard[CARD_NUM];
     EXEC SQL char fcard_class[2];

     int  tmp_len;

     cm_buf_get("%s", DBName);
     cm_buf_get("%s", fcard_class);
     cm_buf_get("%s", icard);

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     if (db_select (DBName) == False)
     {
         if (exitsub (reply, M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
         else
            return apiRC;
     }

     strcpy(fcard_class , trim(fcard_class));
     strcpy(icard       , trim(icard));

     if (strcmp(fcard_class , "1") == 0)
     {
          EXEC SQL SELECT *
                     FROM compulsory_card
                    WHERE icard = :icard;

          if (SQLCODE == SQLNOTFOUND)
          {
              if(exitsub(reply,M_CM_NOT_FOUND) == True)
                  return M_CM_NOT_FOUND;
              else
                  return apiRC;
          }

     }
     else
     {
          EXEC SQL SELECT *
                     FROM card
                    WHERE icard = :icard;

          if (SQLCODE == SQLNOTFOUND)
          {
              if(exitsub(reply,M_CM_NOT_FOUND) == True)
                  return M_CM_NOT_FOUND;
              else
                  return apiRC;
          }

          if (SQLCODE == SQLNOTFOUND)
          {
              if(exitsub(reply,M_CM_NOT_FOUND) == True)
                  return M_CM_NOT_FOUND;
              else
                  return apiRC;
          }

     }

     cm_buf_init (ReplyBuf);
     cm_buf_put ("%l", M_CM_OK);

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply (reply, ReplyBuf, tmp_len, api_OKComplete) == False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
     printf ("SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
     if (exitsub (reply, SQLCODE) == True)
        return SQLCODE;
     else
        return apiRC;
} /* car204_single_query */


/***************************************************************************/
long car204_icard_count(reply)
serverReply reply;
{
     EXEC SQL char DBName[5];
     EXEC SQL char icard_begin[CARD_NUM];
     EXEC SQL char icard_end[CARD_NUM];
     EXEC SQL char fcard_class[2];
     EXEC SQL long count_card;

     int  tmp_len;

     cm_buf_get("%s", DBName);
     cm_buf_get("%s", fcard_class);
     cm_buf_get("%s", icard_begin);
     cm_buf_get("%s", icard_end);

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     if (db_select (DBName) == False)
     {
         if (exitsub (reply, M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
         else
            return apiRC;
     }

     strcpy(fcard_class , trim(fcard_class));
     strcpy(icard_begin , trim(icard_begin));
     strcpy(icard_end   , trim(icard_end));

     count_card = 0;

     if (strcmp(fcard_class , "1") == 0)
     {
          EXEC SQL SELECT count(*)
                     INTO :count_card
                     FROM compulsory_card
                    WHERE icard >= :icard_begin
                      AND icard <= :icard_end;
     }
     else
     {
          EXEC SQL SELECT count(*)
                     INTO :count_card
                     FROM card
                    WHERE icard >= :icard_begin
                      AND icard <= :icard_end;
     }

     printf("###### Total card [%ld]\n",count_card);

     cm_buf_init (ReplyBuf);
     cm_buf_put ("%l %l", M_CM_OK , count_card);

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply (reply, ReplyBuf, tmp_len, api_OKComplete) == False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
     printf ("SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
     if (exitsub (reply, SQLCODE) == True)
        return SQLCODE;
     else
        return apiRC;
} /* car204_icard_count */

long car204_get_comp_officer(reply)
serverReply reply;
{
     EXEC SQL char DBName[5];
     EXEC SQL char icard[CARD_NUM];
     EXEC SQL char fcard_class[2];
     
     $char cardbegin[21];
     $char cardend[21];
     $int  idel_cnt;
     $char ideliver[11];

     int  tmp_len;

     cm_buf_get("%s", DBName);
     cm_buf_get("%s %s", cardbegin,cardend);

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     if (db_select (DBName) == False)
     {
         if (exitsub (reply, M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
         else
            return apiRC;
     }
     
     $SELECT count(UNIQUE ideliver)
        INTO $idel_cnt
        FROM compulsory_card
       WHERE icard BETWEEN $cardbegin AND $cardend;
 
     if (idel_cnt > 1)
     {
        if(exitsub(reply,M_CA_MORE_ONE) == True)
            return M_CA_MORE_ONE;
        else
            return apiRC;
     }

     $SELECT UNIQUE ideliver
        INTO $ideliver
        FROM compulsory_card
       WHERE icard BETWEEN $cardbegin AND $cardend;

     cm_buf_init (ReplyBuf);
     cm_buf_put ("%l %s", M_CM_OK,ideliver);

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply (reply, ReplyBuf, tmp_len, api_OKComplete) == False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
     printf ("SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
     if (exitsub (reply, SQLCODE) == True)
        return SQLCODE;
     else
        return apiRC;
} /* car204_single_query */

int upd_into_deduct(cbgn,cend)
$char cbgn[21];
$char cend[21];
{
$char ficard[21];
$int  icnt;
$char iofficer[11];
$char ileader[11];
$long lPrem;

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     $DECLARE comp_cur1 CURSOR FOR
       SELECT icard
         FROM compulsory_card
        WHERE icard BETWEEN $cbgn AND $cend;

     $OPEN comp_cur1;
     for(;;)
     {
     $FETCH comp_cur1 INTO $ficard;
     if (SQLCODE == SQLNOTFOUND) break;

     $SELECT count(*)
        INTO $icnt
        FROM bn_deduct
       WHERE icard = $ficard
         AND ftype = '1'
         AND itype = '5';

     if (icnt == 0) continue;

        $DELETE FROM bn_deduct
          WHERE icard = $ficard
            AND ftype = '1'
            AND itype = '5'
            AND NVL(deduct_date,' ') = ' ';
        if (sqlca.sqlerrd[2] == 0)
        {
         $SELECT UNIQUE iofficer,ileader,deduct_mnt
            INTO $iofficer,$ileader,$lPrem
            FROM bn_deduct
           WHERE icard = $ficard 
             AND ftype = '1'
             AND itype = '5';
  
         $INSERT INTO bn_deduct
                 (ipolicy1 , ipolicy2 , iendorse , icard , dbrgin ,
                  dendorse , mprem , iofficer , ileader , deduct_mnt ,
                  insure_type, login_date, ftype, itype )
          VALUES (' ',' ',' ',$ficard,
                  today,today, $lPrem, $iofficer,
                  $ileader, $lPrem, 'C' ,today,'2','5');
        }
     }
     $CLOSE comp_cur1;
     $FREE  comp_cur1;

     return 1;
errexit:
     printf ("SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
     return SQLCODE;
}


int insert_into_deduct(cbgn,cend)
$char cbgn[21];
$char cend[21];
{
$char ficard[21];
$char ficar_type[3];
$char fideliver[11];
$char prem[20];
$char ikind[2];
$long lPrem;
$long ddeliver;
$char ileader[11];

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     $DECLARE comp_cur CURSOR FOR
       SELECT icard,icar_type,ideliver,ddeliver
         FROM compulsory_card
        WHERE icard BETWEEN $cbgn AND $cend;
 
     $OPEN comp_cur;
     for(;;)
     {
     $FETCH comp_cur
       INTO $ficard,$ficar_type,$fideliver,$ddeliver;
         if (SQLCODE == SQLNOTFOUND) break;

         if ((strncmp(ficar_type,"01",2) == 0) ||
             (strncmp(ficar_type,"02",2) == 0) ||
             (strncmp(ficar_type,"32",2) == 0) ||
             (strncmp(ficar_type,"34",2) == 0) ||
             (strncmp(ficar_type,"35",2) == 0))
         {
            strcpy(ikind,"1");           
         } 
         else
         {
            strcpy(ikind,"2");
         }

         $SELECT ncode
            INTO $prem
            FROM cu_code_data
           WHERE itype = '45'
             AND icode = $ikind;

         lPrem = atoi(prem);

         $SELECT ileader
            INTO $ileader
            FROM officer
           WHERE iofficer = $fideliver;

         lPrem = lPrem * (-1);

         $INSERT INTO bn_deduct
                 (ipolicy1 , ipolicy2 , iendorse , icard , dbrgin ,
                  dendorse , mprem , iofficer , ileader , deduct_mnt ,
                  insure_type, login_date, ftype, itype )
          VALUES (' ',' ',' ',$ficard,
                  $ddeliver,today, $lPrem, $fideliver,
                  $ileader, $lPrem, 'C' ,today,'1','5');
     }
     $CLOSE comp_cur;
     $FREE  comp_cur;
  
     return 1;
errexit:
     printf ("SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
     return SQLCODE;
}

long car204_receive_count(reply)
serverReply reply;
{
     EXEC SQL char DBName[5];
     EXEC SQL char icard_begin[CARD_NUM];
     EXEC SQL char icard_end[CARD_NUM];
     EXEC SQL long cnt_card;

     int  tmp_len;

     cm_buf_get("%s", DBName);
     cm_buf_get("%s", icard_begin);
     cm_buf_get("%s", icard_end);

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     if (db_select (DBName) == False)
     {
         if (exitsub (reply, M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
         else
            return apiRC;
     }

     strcpy(icard_begin , trim(icard_begin));
     strcpy(icard_end   , trim(icard_end));

     cnt_card = 0;
     
     EXEC SQL SELECT count(*)
                INTO :cnt_card
                FROM compulsory_card
               WHERE icard >= :icard_begin
                 AND icard <= :icard_end
                 AND ireceive = 'system';

     printf("###### Total card [%ld]\n",cnt_card);

     cm_buf_init (ReplyBuf);
     cm_buf_put ("%l %l", M_CM_OK , cnt_card);

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply (reply, ReplyBuf, tmp_len, api_OKComplete) == False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
     printf ("SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
     if (exitsub (reply, SQLCODE) == True)
        return SQLCODE;
     else
        return apiRC;
}