/************************************************/
/*                                              */
/*   PROGRAM : ca153m01s.ec                     */
/*                                              */
/*   PURPOSE : ���O�X��ĳq�]�w��               */
/*                                              */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
#include <decimal.h>
#include "cmnmsgs.h"
#include "safeclib.h"
$include sqlca;
$include datetime.h;

char errbuf[512];

long car153(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car153_insert(),car153_single_query(),car153_multiple_query();
 long car153_update_exec(),car153_insert_batch();
 char option;
 int tmp_len;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'A':
           rtncode=car153_insert(reply);
           break;
  case 'Q':
           rtncode=car153_single_query(reply);
           break;
  case 'M':
           rtncode=car153_multiple_query(reply);
           break;
  case 'D':
  case 'U':
           rtncode=car153_update_exec(reply,command,com_len);
           break;
  case 'E':   /* ��ƾ��W�� */
           rtncode=car153_insert_batch(reply);

           cm_buf_init(ReplyBuf);
           cm_buf_put("%l %s" , rtncode, errbuf);

           tmp_len = cm_buf_len(ReplyBuf);
           if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
               return apiRC;
           else
               return api_OKComplete;
           break;
  default :
           if(exitsub(reply,M_CM_WRONG_OPTION) == True)
             return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}

long car153_insert(reply)
serverReply reply;
{
  $char DBName[5];
  $char iclass[3],icode[21],ftype_sp[3],nremark[61],cday_c[3],cday_v[3],iupdate[11],dexpire[11];
  $int  qday_permit_c,qday_permit_v;
  
  int tmp_len;
  int i, j, is_add_fail=0, api_f;
  $char stmt_buf[300];
  long MsgCode;

  cm_buf_get("%s %s %s %s %s %s %s %s %s ",DBName, iclass, icode, ftype_sp ,nremark, cday_c ,cday_v, dexpire, iupdate);
  		
  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
  }

  MsgCode = chk_iroute( iclass, icode);
  if( MsgCode != M_CM_OK)
  {
   if(exitsub(reply,MsgCode) == True)
     return MsgCode;
   else
     return apiRC;
  }

  $BEGIN WORK;
  
  qday_permit_c = atoi(cday_c);
  qday_permit_v = atoi(cday_v);
  
  
   sprintf_s(stmt_buf, sizeof stmt_buf, "INSERT INTO ca_permit "
                    " (iclass,icode,ftype_sp,nremark,qday_permit_c,qday_permit_v,dexpire,iupdate,dupdate) "
	            " VALUES (?,?,?,?,?,?,?,?,current year to second)");

   $PREPARE a_id FROM $stmt_buf;
   $EXECUTE a_id USING $iclass,$icode,$ftype_sp,$nremark,$qday_permit_c,$qday_permit_v,$dexpire,$iupdate;
   
   if(SQLCODE != 0) goto errexit;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);

   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
   {
       $WHENEVER SQLERROR CONTINUE;
       $ROLLBACK WORK;
       return apiRC;
   }  

  $WHENEVER SQLERROR GOTO errexit;

  $COMMIT WORK;
  return api_OKComplete;

errexit:
   MsgCode = SQLCODE;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if (SQLCODE != 0) MsgCode = SQLCODE;		/* rollback fail */
   if(exitsub(reply,MsgCode) ==	True)
     return MsgCode;
   else
     return apiRC;
}
long chk_iroute( iclass, icode)
$char *iclass;
$char *icode;
{
$int iCount = 0;
  if( strcmp( iclass, "04") == 0) 
  {
      $select count(*)
         into $iCount
         from cm_route_setup
        where iroute_dim1 = $icode;
      if( iCount == 0) return M_CA_ROUTE_CLASS_ERR;
  }
  else if( strcmp( iclass, "05") == 0)
  {
      $select count(*)
         into $iCount
         from cm_route
        where iroute = $icode
          and fmain = 'Y'; /* Y:�D�q���N��,N:�D�D�q���N�� */
      if( iCount == 0) return M_CMN_ROUTE_NOEXIST;
  }
  return M_CM_OK;
}

long car153_single_query(reply)
serverReply reply;
{
  $char DBName[5];
  $char iclass[3],icode[21],ftype_sp[3],nremark[61],iupdate[11],qday_permit_c[3],qday_permit_v[3],dexpire[11],dupdate[20],strdexpire[11];
  	
  int tmp_len;

  cm_buf_get("%s %s %s %s",DBName, iclass, icode, ftype_sp);
  		
  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
     if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
       return M_CM_DB_NOTOPEN;
     else
       return apiRC;
  }
  
  $SELECT iclass, icode, ftype_sp , nremark, qday_permit_c,qday_permit_v,dexpire, iupdate, dupdate
     INTO $iclass, $icode, $ftype_sp , $nremark, $qday_permit_c ,$qday_permit_v , $dexpire, $iupdate, $dupdate
     FROM ca_permit
    WHERE iclass = $iclass
      AND icode = $icode
      AND ftype_sp = $ftype_sp;

  if(SQLCODE==SQLNOTFOUND)
  {
    if(exitsub(reply,M_CM_NOT_FOUND) == True)       
      return M_CM_NOT_FOUND;                        
    else
      return apiRC;
  }
  strcpy(strdexpire, cm_from_infdate_100(dexpire));
  
  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s %s %s %s %s %s %s %s %s ",M_CM_OK, iclass, icode, ftype_sp , nremark, qday_permit_c, qday_permit_v, strdexpire, iupdate, dupdate);
  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}

long car153_multiple_query(reply)
serverReply reply;
{
  $char DBName[5];
  $char iclass[3],icode[21],ftype_sp[3],nremark[61],nupdate[11],dexpire[11],dupdate[20],strdexpire[11];
  $char stmt[1024], ilog[2], update_mode[2], table[31], column[21];

  char tmpbuf[4000];
  int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
  int i,total_count=0;
  
  cm_buf_get("%s %s %s %s %s",DBName, iclass, icode, ftype_sp, ilog);
  
  
  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
    if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }
  if( ilog[0] == '1')
  {
      strcpy( table, "ca_permit a");
      strcpy( column, ",''");
  }
  else
  {
      strcpy( table, "ca_permit_log a");
      strcpy( column, ",update_mode");
  }

  sprintf_s(stmt, sizeof stmt, "select iclass, icode, ftype_sp, nremark, dexpire, (select nname from officer where iofficer = a.iupdate), dupdate %s" 
                "  from %s "
                " where iclass matches ? "
                "   and icode matches ? "
                "   and ftype_sp matches ?", column, table);
                    
   $PREPARE CUR_CAID FROM $stmt;
   $DECLARE IDcur CURSOR FOR CUR_CAID;
   $OPEN IDcur USING $iclass,$icode,$ftype_sp;

   for(;;)
   {
     $FETCH IDcur INTO $iclass,$icode,$ftype_sp,$nremark,$dexpire,$nupdate,$dupdate,$update_mode;
     if (SQLCODE == SQLNOTFOUND) break;

     cm_buf_init(tmpbuf);
     if ( count == 0 )
     {
       cm_buf_res_msg();             /* reserve for MsgCode and count */
       cm_buf_res_count();
     }
     
     /* Convert Era Date to Chinese Date */
     strcpy(strdexpire, cm_from_infdate_100(dexpire));
     
     cm_buf_put("%s %s %s %s %s %s %s %s", iclass, icode, ftype_sp , strdexpire, nupdate, dupdate, update_mode, nremark);
     tmp_len = cm_buf_len(tmpbuf);
     if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
       memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
       repbuf_len += tmp_len;
       count++;
     }
     else                               /* more than 4K, send to client side */
     {
       cm_buf_init(ReplyBuf);
       cm_buf_put_msg(M_CM_OK);
       cm_buf_put_count(count);
       if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
         $CLOSE IDcur;
         return apiRC;
       }
       else               /* clear ReplyBuf and count to start all over again */
       {
         replycnt++;
         if (replycnt == 10)   /* more than 30K, client cannot display,error */
         {
           cm_buf_init(ReplyBuf);
           cm_buf_put("%l",M_CM_OUT_SPACE);
           tmp_len = cm_buf_len(ReplyBuf);
           if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
               return apiRC;
           return M_CM_OUT_SPACE;
         }
         ReplyBuf[0] = '\0';
         count = 0;
         cm_buf_init(ReplyBuf);
         cm_buf_res_msg();           /* reserve for MsgCode and count */
         cm_buf_res_count();
         cm_buf_put("%s %s %s %s %s %s %s %s", iclass, icode, ftype_sp , strdexpire, nupdate, dupdate, update_mode, nremark);
         repbuf_len = cm_buf_len(ReplyBuf);
         count++;
       }
     }
  } /* for loop */

  $CLOSE IDcur;
  if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
  else            /* break out, not any row is found */
  {
    if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
      return M_CM_NOT_FOUND;                               /*?*/
    else
      return apiRC;
  }

errexit:
   if(exitsub(reply,SQLCODE) == True)
     return SQLCODE;
   else
     return apiRC;
}

long car153_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
  $char DBName[5];
  $char iclass[3],icode[21],ftype_sp[3],nremark[61],cday_c[3],cday_v[3],dexpire[11],iupdate[11],dupdate[20];
  $char old_iclass[3],old_icode[21],old_ftype_sp[3],old_nremark[61],old_cday_c[3],old_cday_v[3],old_dexpire[11],old_iupdate[11],old_dupdate[20];
  $char dbdupdate[20];
  $char stmt_buf[300];
  $int  qday_permit_c,qday_permit_v;
  
  char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
  int tmp_len,raw_len;
  long dummy;
  long MsgCode;
   int i, j, is_upd_fail=0,is_del_fail=0;

	comm = (char *) command;
	cm_buf_init(command);
	cm_buf_get("%c %s",&option,DBName);

	$WHENEVER SQLERROR GOTO errexit;

 	if (db_select(DBName) == False)
    	{
    		if (exitsub(reply,M_CM_DB_NOTOPEN) == True) return M_CM_DB_NOTOPEN;
    		else	return apiRC;
    	}

	/* get old record info from command buffer */

	memcpy(&raw_len,&comm[com_len],sizeof(int));
	pos = &comm[com_len+sizeof(int)];
	raw_ptr = malloc(raw_len);

 	if (raw_ptr != (char*)0) {
    		memcpy(raw_ptr,pos,raw_len);
	}
 	else
    	{
    		if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */
    			return M_CM_NOT_MALLOC;
    		else	return apiRC;
    	}
   
 	cm_buf_init(raw_ptr);          /* get index key from old record */
 	
        cm_buf_get("%l %s %s %s %s %s %s %s %s %s ",&dummy, old_iclass, old_icode, old_ftype_sp , old_nremark, old_cday_c,old_cday_v,old_dexpire, old_iupdate, old_dupdate);
  							
 	$SELECT dupdate
           INTO $dbdupdate
           FROM ca_permit
          WHERE iclass = $old_iclass
            AND icode = $old_icode
            AND ftype_sp = $old_ftype_sp;

 	if (SQLCODE == SQLNOTFOUND)
        {
            if (exitsub(reply,M_CM_NOT_FOUND) == True)
        	return M_CM_NOT_FOUND;
    	    else
        	return apiRC;
    	}

 	if (strcmp(old_dupdate,dbdupdate) != 0)
        {
    	    if(exitsub(reply,M_CM_NOT_EQUAL) == True)
        	return M_CM_NOT_EQUAL;
    	    else
        	return apiRC;
    	}
    	
 	$BEGIN WORK;
 	$WHENEVER SQLERROR GOTO errexit;
 	/* table lock is necessary to avoid concurrent update problems */
 	$LOCK TABLE ca_permit IN SHARE MODE;

 	$WHENEVER SQLERROR GOTO errexit;

 	/* equal, then exec DB operation */

 	 if ( option == 'D' )
  	 {
    		sprintf_s(stmt_buf, sizeof stmt_buf, "DELETE FROM ca_permit WHERE iclass=? AND icode=? AND ftype_sp =?" ); 
    		$PREPARE d_id FROM $stmt_buf;
    		if(SQLCODE != 0)
     		{
      		is_del_fail = 1; 
     		}
    		$EXECUTE d_id USING $old_iclass,$old_icode,$old_ftype_sp;
    		if(SQLCODE != 0)
     		{
      		is_del_fail = 1; 
     		}

   	 if( is_del_fail ) goto errexit;
   
   	 cm_buf_init(ReplyBuf);
   	 cm_buf_put("%l",M_CM_OK);
   	 tmp_len = cm_buf_len(ReplyBuf);
   	 
   	 if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    	 {
     		$WHENEVER SQLERROR CONTINUE;
     		$ROLLBACK WORK;
     		return apiRC;
    	 }  
	
   	  $WHENEVER SQLERROR GOTO errexit;
   	  $COMMIT WORK;
   	  return api_OKComplete;
  	}
 	else if (option == 'U')
   {	
   	cm_buf_init(command);
   	cm_buf_get("%c %s",&option,DBName);
        cm_buf_get("%s %s %s %s %s %s %s %s %s ",iclass, icode, ftype_sp , nremark, cday_c, cday_v, dexpire, iupdate, dupdate);
  	
  	qday_permit_c = atoi(cday_c);
  	qday_permit_v = atoi(cday_v);
  							
   	$WHENEVER SQLERROR CONTINUE;
    	sprintf_s(stmt_buf, sizeof stmt_buf, "UPDATE ca_permit SET "
	     		 " (iclass,icode,ftype_sp,nremark,qday_permit_c,qday_permit_v,dexpire,iupdate,dupdate) "
	     		 "  = (?,?,?,?,?,?,?,?,current year to second) "
	     		 "  WHERE iclass=? AND icode=? AND ftype_sp=?");

    	$PREPARE u_id FROM $stmt_buf;
    		
    	if(SQLCODE != 0)
     	{
      	is_upd_fail = 1;
     	}
    	$EXECUTE u_id USING $iclass,$icode,$ftype_sp,$nremark,$qday_permit_c,$qday_permit_v,$dexpire,$iupdate,$old_iclass,$old_icode,$old_ftype_sp;
    	if(SQLCODE != 0)
     	{
      	is_upd_fail = 1;
     	}
    	if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
     	{
  		sprintf_s(stmt_buf, sizeof stmt_buf, "INSERT INTO ca_permit "
         	                 " (iclass,icode,ftype_sp,nremark,qday_permit_c,qday_permit_v,dexpire,iupdate,dupdate)"
	 			 " VALUES (?,?,?,?,?,?,?,?,current year to second)");	 

      		$PREPARE ua_id FROM $stmt_buf;
      		if(SQLCODE != 0)
       		{
        		is_upd_fail = 1; 
       		}
      		$EXECUTE ua_id USING $iclass,$icode,$ftype_sp,$nremark,$qday_permit_c,$qday_permit_v,$dexpire,$iupdate;
      		if(SQLCODE != 0)
       		{
        			is_upd_fail = 1; 
       		}
     	}

   	if( is_upd_fail ) goto errexit;


   	cm_buf_init(ReplyBuf);
   	cm_buf_put("%l",M_CM_OK);
   	tmp_len = cm_buf_len(ReplyBuf);
   	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    	{
     		$WHENEVER SQLERROR CONTINUE;
     		$ROLLBACK WORK;
     		return apiRC;
    	}  

   	$WHENEVER SQLERROR GOTO errexit;
   	$COMMIT WORK;
   	return api_OKComplete;
  } else {
   	if(exitsub(reply,M_CM_WRONG_OPTION) == True) 
    		return M_CM_WRONG_OPTION;
   	else  
    		return apiRC;
  } 
  
  free(raw_ptr);

 errexit:
  $WHENEVER SQLERROR CONTINUE;
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True) 
   return MsgCode;
  else
    return apiRC;
}

/* ��ƾ��W�� */
long car153_insert_batch(reply)
serverReply reply;
{
  $char DBName[5], stmt[2048], stmt_buf[300];
  char  sApHome[30], filename[101],logname[101], cmd_str[2048], userid[11],m_type[2];
  $int  rc, cnt, rc1;
  int   stmt_len;
  int i, j, is_add_fail=0, api_f;
  long MsgCode;

   rc = getApHome(sApHome);
   if (rc<0) {
      strcpy( errbuf,"read Config file error!!-->getApHome\n");
      return rc;
   }

   sprintf_s(filename, sizeof filename, "%s/dat/car/car153.txt", sApHome);
   sprintf_s(logname, sizeof logname, "%s/rptftp/car153_log.txt",sApHome);

  cm_buf_get("%s %s %s",DBName, userid, m_type);
  		
  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
     sprintf_s(errbuf, sizeof errbuf, "��Ʈw�L�k�}��[%s]\n", DBName);
     return M_CM_DB_NOTOPEN;
  }

   /* ����J�Ȧs��,�T�{��J���O�_���T */
   stmt_len = 0;
   stmt_len += sprintf_s(stmt+stmt_len, sizeof stmt,
              "select iclass ,icode ,ftype_sp ,nremark,qday_permit_c,qday_permit_v,dexpire,iupdate,dupdate from ca_permit where 1=0 into temp temp1 with no log;\r\n");
   stmt_len += sprintf_s(stmt+stmt_len, sizeof stmt,
                      "load from %s delimiter '\t' insert into temp1; \r\n",
                       filename);
   sprintf_s(cmd_str, sizeof cmd_str, "dbaccess sysdb > %s 2>&1 << !\r\n"
                   "%s\r\n!", logname, stmt);
   printf("cmd_str[%s]\n",cmd_str);
   rc = system(cmd_str);
   if (rc != 0) {
       sprintf_s(errbuf, sizeof errbuf, "load file error[%s]\n���I���ɮפU���@�~�d��[Q],�T�{���~��]", logname);
       rc1=rptftpinsert(userid,"car153","car153_log.txt");
       return rc;
   }
   /* ��J�����ɮ� */
   stmt_len = 0;

   stmt_len += sprintf_s(stmt+stmt_len, sizeof stmt,
              "select iclass ,icode ,ftype_sp ,nremark,qday_permit_c,qday_permit_v,dexpire,iupdate,dupdate from ca_permit where 1=0 into temp temp1 with no log;\r\n");

   stmt_len += sprintf_s(stmt+stmt_len, sizeof stmt,
                      "load from %s delimiter '\t' insert into temp1; \r\n",
                       filename);
                       
   	stmt_len += sprintf_s(stmt+stmt_len, sizeof stmt,
                      "update temp1 set iupdate = '%s', dupdate = current year to second where 1=1;\r\n", userid);
                      
   if(strcmp(trim(m_type),"0") == 0)
   {                   
   	stmt_len += sprintf_s(stmt+stmt_len, sizeof stmt,
                      "insert into ca_permit(iclass ,icode ,ftype_sp ,nremark,qday_permit_c,qday_permit_v,dexpire,iupdate,dupdate) select * from temp1;\r\n");
   }
   else
   {
   	stmt_len += sprintf_s(stmt+stmt_len, sizeof stmt,
                      "update ca_permit SET dexpire = (SELECT dexpire FROM temp1 WHERE iclass = ca_permit.iclass AND icode = ca_permit.icode AND ftype_sp = ca_permit.ftype_sp), "
                      "                     iupdate = (SELECT iupdate FROM temp1 WHERE iclass = ca_permit.iclass AND icode = ca_permit.icode AND ftype_sp = ca_permit.ftype_sp), "
                      "                     dupdate = (SELECT dupdate FROM temp1 WHERE iclass = ca_permit.iclass AND icode = ca_permit.icode AND ftype_sp = ca_permit.ftype_sp)  "
                      "               WHERE icode IN (SELECT icode FROM temp1) AND iclass IN (SELECT iclass FROM temp1) AND ftype_sp IN (SELECT ftype_sp FROM temp1);\r\n");
   }

   sprintf_s(cmd_str, sizeof cmd_str, "dbaccess sysdb > %s 2>&1 << !\r\n"
                   "%s\r\n!", logname,stmt);
   printf("cmd_str[%s]\n",cmd_str);
   rc = system(cmd_str);
   if (rc != 0) {
       sprintf_s(errbuf, sizeof errbuf, "load file error[%s]\n���I���ɮפU���@�~�d��[Q],�T�{���~��]", logname);
       rc1=rptftpinsert(userid,"car153","car153_log.txt");
       return rc;
   }
   sprintf_s(errbuf, sizeof errbuf, "���槹��");
   return M_CM_OK;

errexit:
     sprintf_s(errbuf, sizeof errbuf, "SQLCODE[%d], sqlca.sqlerrm[%s]\n", SQLCODE, sqlca.sqlerrm);
     return SQLCODE;
}

