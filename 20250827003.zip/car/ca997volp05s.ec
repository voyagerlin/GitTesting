/*********************************************
 * Program : ca997volp05s.ec
 * �N�j���I���P����൹���N�I���x�A���ͺʲz�����T�������Ӹ�T��
 *********************************************/
 
#include <stdio.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"
#include "sqlfatal.h"
#include <time.h>

#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"

time_t tstart,tend;   
float tused=0;

/*--------------------------------------------------------------------*/
int     i=0,rc=0;

char  userid[11],option[2],outputf[21];
$char DBName[05];
$char dbgn1[11],dend1[11],datebgn[11],dateend[11];
$char sApHome[31];
char  errmsg[200];
FILE  *errfpt;
FILE  *fptr;

$char  strlog[500],errlog[300];

long car9975_get_db();
long car9975_build_vol();
extern int rptftpinsert();
long check_if_exist();

/*--------------------------------------------------------------------*/
main(argc,argv)
int   argc;
char  **argv;
{
   int   rc,rt;

   batchinit();

   strcpy(DBName,isNULLstr(argv[1]));
   strcpy(userid,isNULLstr(argv[2]));
   strcpy(option,isNULLstr(argv[3]));
   strcpy(datebgn,isNULLstr(argv[4]));
   strcpy(dateend,isNULLstr(argv[5]));
   strcpy(outputf,isNULLstr(argv[6]));
   
   if (datebgn[0]=='*' || datebgn[0] == '\0') 
      strcpy(datebgn,  "80/01/01");
   if (dateend[0]=='*' || dateend[0] == '\0') 
      strcpy(dateend,  "199/12/31");
     
   strcpy(dbgn1,cm_to_infdate(datebgn));
   strcpy(dend1,cm_to_infdate(dateend));

   printf("dbgn1[%s] dend1[%s]\n",dbgn1,dend1);
   
   $WHENEVER SQLERROR GOTO errexit;
   
   errfpt = (FILE *) STARTLOG();   time(&tstart);

   rc=car9975_get_db();
   if (rc!=M_CM_OK)
      return rc;
    
   rt = getApHome(sApHome);
   if (rt < 0) {
        printf("read Config file error!!\n");
        return M_CM_READ_CONFIG_ERR;
   }   
   
   rc=car9975_build_vol();  
   if (rc!=M_CM_OK)
   {
      rgetmsg(rc, errlog, sizeof(errlog));
        
      sprintf_s(strlog, sizeof strlog,"%s\n\n\t\t     ",errlog);
        
      printf("option [%s]\n",option);
        
      if ( strcmp(option,"1") == 0 )
      {
   	
   	   strcat(strlog," CNFM17_���N�I���Ӹ�T�ɻs�@���� ");
   	
      }
      else if (strcmp(option,"4") == 0)
      {
         strcat(strlog," ���N�I���Ӹ�T�ɭ��e���� ");
      }
      else
      {
         strcat(strlog,"���N�I���Ӹ�T�ɽ𰣭��e���� ");
      }
        
      printf("strlog[%s]\n",strlog); 
   	
   	EWRITE(userid,rc,strlog);
   	
   	exit(1);
   }
   
   time(&tend); 
   tused = difftime( tend, tstart);
   printf(" used time is [%f]\n",tused);
   
   exit(0);
   
errexit:
    printf("car9975vol-main:sqlcode=%d, sqlmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;   
   
}
/*--------------------------------------------------------------------*/

long car9975_get_db()
{
   $whenever sqlerror goto errexit;

   printf("userid[%s] DBName[%s]\n",userid,DBName);

   if (db_select(DBName) == FALSE) {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);

   return SQLCODE;
}

/*--------------------------------------------------------------------------*/

long car9975_build_vol()
{
	
   char  companyid[3];
   int   rtn=0;
   int   iFetch=0;
   char  day_yy[4],day_mm[3],day_dd[3];
   $char prtstr[500], cntrlrec_c[7];
   $char tstmt[1024], stmt_db[21], stmt_statement[256];
   $char Tmp1[20],file0[51],iply_type[3],fcard_class[2];
   int  rtncode=0,b=0;
   long rc=0;
   int  i=0;

   $char strbgn[71], strend[71];
   $char itype[2],itag_last[CA_TAG_NUM],itag_next[CA_TAG_NUM],dchange[11];
   $long dcreate=0, sDcreate=0, cntrlrec=0;
   $char dcreate_c[11];
  
   rtn = getCompanyId(companyid);
         
   printf(" ************************** companyid[%s]\n",companyid);
   
      /* if option = 5, it has to join with table [ca_tmp_no] */
      strcpy(stmt_statement,"");
      strcpy(stmt_db,"");
      if( strcmp(option,"5") == 0 )
      {
         strcpy(stmt_db,", ca_tmp_no b");
         strcpy(stmt_statement," WHERE a.itag_last = b.ipolicy and a.fcard_class = '1'");
      }
      else
      {
         sprintf_s(strbgn, sizeof strbgn, "to_char(date('%s'),'%%Y-%%m-%%d 00:00:00')", dbgn1);
         sprintf_s(strend, sizeof strend, "to_char(date('%s'),'%%Y-%%m-%%d 23:59:59')", dend1);
         sprintf_s(stmt_statement, sizeof stmt_statement, " WHERE a.dcreate BETWEEN %s AND %s AND a.fcard_class = '1' ORDER BY dcreate", strbgn, strend);
      }

      cntrlrec = 0;
      strcpy( fcard_class, "2"); /* �N�j���I���P����൹���N�I���x */
      strcpy( iply_type, "FM");
      sprintf_s(tstmt, sizeof tstmt,"SELECT a.itype,a.itag_last,a.itag_next,to_char(a.dchange,'%%Y%%m%%d'),date(a.dcreate) "
                    "  FROM ca_change_tag_ori a %s %s", stmt_db, stmt_statement);
   
      printf("tstmt[%s]\n",tstmt);
   
      $PREPARE CUR_TSTMT FROM $tstmt;
      $DECLARE scur_car9975 CURSOR FOR CUR_TSTMT;
                    
      $OPEN scur_car9975;
      
      iFetch = TRUE;
      while(1)
      {
         $FETCH scur_car9975 
           INTO $itype,$itag_last,$itag_next,$dchange,$dcreate;
            
         if (SQLCODE == SQLNOTFOUND) break;
     
         if (iFetch)                 /*�Ĥ@�����W�@���O�ۤv*/
         {   
            sDcreate = dcreate;
            iFetch = FALSE;
            
            strcpy( dcreate_c , cm_cdate_str_100( dcreate ));         
            cm_split_ymd_100(dcreate_c,day_yy,day_mm,day_dd);
          
            sprintf_s(Tmp1, sizeof Tmp1,"CNFM%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
        
            sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);
            
            printf("[NOERROR] file0[%s] Tmp1[%s]\n",file0,Tmp1);
            fptr=fopen(file0,"w");
          
            if (strcmp(option,"4") != 0 || strcmp(option,"5") != 0)
            {
               rc = check_if_exist(iply_type,dcreate,fcard_class,0);
               if ( rc != M_CM_OK )
               return rc;
            }
         }
     
         if ( sDcreate != dcreate ) /* �����ثefile , open a new file*/
         {    	
            if (cntrlrec > 0)
            {
               strcpy(prtstr,"CNTRLREC|");
               rfmtlong(cntrlrec,"<<<<<<<",cntrlrec_c);
               strcat(prtstr,cntrlrec_c);
               fprintf(fptr, "%s\n", prtstr);
            }

            printf("### cntrlrec=[%s]\n",cntrlrec_c);
    	
            fclose(fptr);         
            rtncode = rptftpinsert( userid , "car9975" , Tmp1 );
         
            if (strcmp(option,"4") != 0 && strcmp(option,"5") != 0)
            {
               $insert into ca_trade_exam
                  (iply_type,dpolicy,fcard_class,itrans_type,
                   qcount,mamount,minjure,mcripple,mdeath)
                values
                  ($iply_type,$sDcreate,$fcard_class,0,
                   $cntrlrec,0,0,0,0);
            }
         
            sprintf_s(strlog, sizeof strlog,"���ɧ���:%s ���:%d",file0,cntrlrec);
            WRITELOG(errfpt , strlog);
            
            printf("errfpt[%s]\n",strlog);
            
            strcpy( dcreate_c , cm_cdate_str_100( dcreate ));
            
            cm_split_ymd_100(dcreate_c,day_yy,day_mm,day_dd);
          
            sprintf_s(Tmp1, sizeof Tmp1,"CNFM%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);

            sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);

            printf("[002]file0[%s] Tmp1[%s]\n",file0,Tmp1);
            fptr=fopen(file0,"w");
         
            if (strcmp(option,"4") != 0 && strcmp(option,"5") != 0)
            {
               rc = check_if_exist(iply_type,dcreate,fcard_class,0);
               if ( rc != M_CM_OK )
                  return rc;
            }
            cntrlrec = 0;
         }
          
         sDcreate = dcreate;
         
         strcpy(prtstr, itype);        /* ���ʧO */
         strcat(prtstr, "|");
         strcat(prtstr, itag_last);    /* ��P�Ӹ��X */
         strcat(prtstr, "|");
         strcat(prtstr, itag_next);    /* �s�P�Ӹ��X */
         strcat(prtstr, "|");
         strcat(prtstr, dchange);      /* ���s���P��� */
            
         fprintf(fptr, "%s\n", prtstr);
         cntrlrec++;
      }  /* end of while that FETCH scur_car9975 */
   
   
      $CLOSE scur_car9975;
      $FREE  scur_car9975;
   
      if (cntrlrec > 0)
      {
         strcpy(prtstr,"CNTRLREC|");
         rfmtlong(cntrlrec,"<<<<<<<",cntrlrec_c);
         strcat(prtstr,cntrlrec_c);
         fprintf(fptr, "%s\n", prtstr);
      }
      else if ( cntrlrec == 0 )
      {
         rstrdate( dbgn1 , &dcreate);
         
         strcpy( dcreate_c , cm_cdate_str_100( dcreate ));
         
         cm_split_ymd_100(dcreate_c,day_yy,day_mm,day_dd);
         sprintf_s(Tmp1, sizeof Tmp1,"CNFM%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
          
         sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);
         
         printf("[NODATA] file0[%s] Tmp1[%s]\n",file0,Tmp1);
         fptr=fopen(file0,"w");
         
         strcpy(prtstr,"CNTRLREC|");
         rfmtlong(0,"<<<<<<<",cntrlrec_c);
         strcat(prtstr,cntrlrec_c);
         fprintf(fptr, "%s\n", prtstr);
         
         cntrlrec = 0;
   	 	
      }

      printf("### cntrlrec=[%s]\n",cntrlrec_c);  	
      
      fclose(fptr);
      
      rtncode = rptftpinsert( userid , "car9975" , Tmp1 );
      
      printf("dcreate[%d]\n",dcreate);
     
      if (strcmp(option,"4") != 0 && strcmp(option,"5") != 0)
      {
         $insert into ca_trade_exam
            (iply_type,dpolicy,fcard_class,itrans_type,
             qcount,mamount,minjure,mcripple,mdeath)
          values
            ($iply_type,$dcreate,$fcard_class,0,
             $cntrlrec,0,0,0,0);
      }
     
      sprintf_s(strlog, sizeof strlog,"���ɧ���:%s ���:%d",file0,cntrlrec);
      WRITELOG(errfpt , strlog);
      
      printf("errfpt[%s]\n",strlog);

   if (errfpt!=NULL) ENDLOG(errfpt); 
   
   return M_CM_OK;	
	
errexit:
    printf("car9975_vol:sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    rc = SQLCODE;
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return rc;	
	
}

long check_if_exist( iply_type, dcreate, fcard_class, trans_type )
$char *iply_type;
$int dcreate;
$char *fcard_class;
$int trans_type;
{
   
   $long trade_count, err_count, out_count;
   
   printf("iply_type[%s] dcreate[%d]\n",iply_type,dcreate);
   printf("fcard_class[%s] trans_type[%d]\n",fcard_class,trans_type);
   
   
   $SELECT qtradevan, qerr, qout
      INTO $trade_count, $err_count, $out_count
      FROM ca_trade_exam 
     WHERE iply_type = $iply_type
       AND dpolicy = $dcreate
       AND fcard_class = $fcard_class 
       AND itrans_type = $trans_type;
  
   if ( SQLCODE == SQLNOTFOUND )  return M_CM_OK;	
   
   printf("trade_count[%d] [%d] [%d]\n",trade_count,err_count,out_count);
   
   if ( trade_count==0 && err_count==0 && out_count==0 )
   {
       
       $DELETE FROM ca_trade_exam 
         WHERE iply_type = $iply_type
           AND dpolicy = $dcreate
           AND fcard_class = $fcard_class 
           AND itrans_type = $trans_type;
           
        return M_CM_OK;	
   
   }
   
   strcpy(sqlca.sqlerrm ,"�L�k���J�s�C - �b UNIQUE INDEX ��즳���Э�");
   
   return 239;
   
errexit:
    printf("check_if_exist:sqlcode=%d, sqlmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    rc = SQLCODE;
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return rc;	
   
}
