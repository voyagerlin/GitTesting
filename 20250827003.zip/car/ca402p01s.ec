/************************************************/
/*                                              */
/*   PROGRAM : ca402p01s.ec                     */
/*                                              */
/************************************************/
     
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
$include sqlca;
$include decimal;
$include "safeclib.h";

long car402(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car402_single_query(),car402_update_exec();
 long car402_multiple_query();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'M':
           rtncode=car402_multiple_query(reply);
           break;
  case 'Q':
	   rtncode=car402_single_query(reply);
	   break;
  case 'P':
	   rtncode=car402_update_exec(reply,command,com_len);
	   break;
  default :
	   if(exitsub(reply,M_CM_WRONG_OPTION) == True)
	    return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}

/*******************************************************************/
long car402_multiple_query(reply)
serverReply reply;
{
 $char DBName[DBNAME];

 $char iabnormal[CA_ESTIMATE_NUM],fpass[2],iabn_type[2];
 $char fpass_C[2],iabn_type_C[2];

 char  tmpbuf[4000];
 int   count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int   i,total_count=0;

 int   flag=0;
 char  taipei_db[40], dbname_tp[45];
 $char stmt[1000];
 int   rc;


 cm_buf_get("%s",DBName);
 cm_buf_get("%s %s",iabn_type_C,fpass_C);
printf("-----DB[%s] abn_tp[%s] fpass[%s]\n",DBName,iabn_type_C,fpass_C);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False) {
     if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
        return M_CM_DB_NOTOPEN;
     else
        return apiRC;
 }

 rc = getHeadBranch(taipei_db);
 if (rc < 0) {
     printf("read Config file error!!\n");
     return M_CM_READ_CONFIG_ERR;
 }
 strcpy(dbname_tp,get_full_dbname(taipei_db)); /* get TP's full DB name */


 if (fpass_C[0] == ' ')
 {
  sprintf_s(stmt, sizeof stmt,"SELECT %s FROM %s:%s %s %s %s",
               "fpass, iabn_type, iabnormal ",
               dbname_tp,"abn_edr_relation",
               "WHERE iabn_type MATCHES ? ", 
               "  AND (fpass IS NULL OR fpass = ' ') "
               "ORDER BY iabnormal ");
  $PREPARE CUR_STMT2 FROM $stmt;
  $DECLARE q1_cur CURSOR FOR CUR_STMT2;
 }
 else if (fpass_C[0] == '*')
 {
printf("-----fpass='*'\n");
  sprintf_s(stmt, sizeof stmt,"SELECT %s FROM %s:%s %s %s",
               "fpass, iabn_type, iabnormal ",
               dbname_tp,"abn_edr_relation ",
               "WHERE iabn_type MATCHES ? ",
               "ORDER BY iabnormal");
printf("A----stmt[%s]\n",stmt);
  $PREPARE CUR_STMT3 FROM $stmt;
printf("B\n");
  $DECLARE q2_cur CURSOR FOR CUR_STMT3;
printf("C\n");
printf("D\n");
printf("E\n");
 }
 else
 {
  sprintf_s(stmt, sizeof stmt,"SELECT %s FROM %s:%s %s %s %s",
               "fpass, iabn_type, iabnormal",
               dbname_tp,"abn_edr_relation ",
               "WHERE iabn_type MATCHES ? ",
               "  AND fpass MATCHES ? ",
               "ORDER BY iabnormal");
  $PREPARE CUR_STMT4 FROM $stmt;
  $DECLARE q3_cur CURSOR FOR CUR_STMT4;
 }

printf("F\n");
 if (fpass_C[0] == ' ')
  $OPEN q1_cur USING $iabn_type_C;
 else if (fpass_C[0] == '*')
  $OPEN q2_cur USING $iabn_type_C;
 else
  $OPEN q3_cur USING $iabn_type_C, $fpass_C;

printf("G\n");
  for (;;)
  {
    if (fpass_C[0] == ' ')
      $FETCH q1_cur INTO  $fpass, $iabn_type, $iabnormal;
    else if (fpass_C[0] == '*')
      $FETCH q2_cur INTO  $fpass, $iabn_type, $iabnormal;
    else
      $FETCH q3_cur INTO  $fpass, $iabn_type, $iabnormal;
     if(SQLCODE != 0) break;
printf("1\n");

     cm_buf_init(tmpbuf);
     if(count == 0)
     {
       cm_buf_res_msg();
       cm_buf_res_count();
     }
printf("2----- iabnormal[%s] iabn_type[%s] fpass[%s]\n",iabnormal,iabn_type,fpass);
     cm_buf_put("%s %s %s",iabnormal,iabn_type,fpass);
     tmp_len = cm_buf_len(tmpbuf);
     if ( tmp_len + repbuf_len < 3000 )
     {
       memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
       repbuf_len += tmp_len;
       count++;
     }
     else
     {
       cm_buf_init(ReplyBuf);
       cm_buf_put_msg(M_CM_OK);
       cm_buf_put_count(count);
       if(SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
          if (fpass_C[0] == ' ')
              $CLOSE q1_cur;
          else if (fpass_C[0] == '*')
              $CLOSE q2_cur;
          else
              $CLOSE q3_cur;
          return apiRC;
       }
       else
       {
           replycnt++;
           if(replycnt == 10)
           {
             cm_buf_init(ReplyBuf);
             cm_buf_put("%l",M_CM_OUT_SPACE);
             tmp_len = cm_buf_len(ReplyBuf);

             if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
                 return apiRC;
             return M_CM_OUT_SPACE;
           }
           ReplyBuf[0] = '\0';
           count = 0;
           cm_buf_init(ReplyBuf);
           cm_buf_res_msg();
           cm_buf_res_count();
           cm_buf_put("%s %s %s",iabnormal,iabn_type,fpass);
           repbuf_len = cm_buf_len(ReplyBuf);
           count++;
       }
     }
   } /* for loop */

 if (fpass_C[0] == ' ')
     $CLOSE q1_cur;
 else if (fpass_C[0] == '*')
     $CLOSE q2_cur;
 else
     $CLOSE q3_cur;

printf("3----- count[%d]\n",count);

 if(count > 0)
 {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if(SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
        return apiRC;
    return api_OKComplete;
 }
 else
 {
    if(exitsub(reply,M_CM_NOT_FOUND) == True)
       return M_CM_NOT_FOUND;
    else
       return apiRC;
 }

errexit:
  if(exitsub(reply,SQLCODE) == True)
     return SQLCODE;
  else
     return apiRC;
}
 

/***********************************************************************/
long car402_single_query(reply)
serverReply reply;
{
 $char DBName[DBNAME];

 $char iabnormal[CA_ESTIMATE_NUM],iabn_type[2],fpass[2];
 $char icard[CARD_NUM],ipolicy[POLICY_NUM_1],irelative_ply[POLICY_NUM_1];
 $char fedr_class[2];
 $char fpay[2],ipay[POLICY_NUM_1];
 $char s_dedr_begin[YYYMMDD],s_dedr_end[YYYMMDD];
 $char dedr_begin[11],dedr_end[11];
 $char dedr_examine[11],s_dedr_examine[YYYMMDD];
 $char iedr_area[4],ibroker[BROKER];
 $char iofficer[EMPLOYEE_ID],itreaty[2];

 $char iassured[CUSTOMER_ID],fassured[2],nassured[ASSURED_NAME];
 $char nuser[19],ibenef[11],nbenef[43];
 $char aassured[91],itel[21];
 $long qply_period = 0;
 $char dply_begin[11],s_dply_begin[YYYMMDD],dply_end[11],s_dply_end[YYYMMDD];
 $long ldply_begin_a = 0, ldply_begin_b = 0;
 $char dissue[11],ipro_year[5],ibrand[9];
 $char nbrand_abbr[13];
 $char icar_type[CA_CAR_TYPE_NUM];
 $char ncode[11]; /* car_type */
 /*$long qcylinder;*/
 $char iengine[CA_ENGINE_NUM],ibody[CA_BODY_NUM],itag[CA_TAG_NUM],ilicense[CUSTOMER_ID];
 $char dbirth[11],fsex[2],fmarriage[2],iacc_align[3],flimit[2];
 $long pdmg_align,plia_align;
 $dec_t mcar_price,pdmg_acc,plia_acc,qcylinder; /* it is decimal */
 $char s_mcar_price[10],s_pdmg_acc[10],s_plia_acc[10],s_qcylinder[10];
 $char nequipment[11];

 $char iedr_type[3],iins_type[INSURANCE_TYPE];
 $long medrinj_cover=0,medrdea_cover=0,medrdmg_cover=0,medrdeduct=0,medrins_prem=0;
 long  mtotprem;
 $char fcal_way[2];
 $long pcal =0,qday =0;
 char  s_pcal[4],fcal_pcal[5];
 long  qcount;
 
 char policy_1[POLICY_NUM_1],policy_2[POLICY_NUM_1];
 char result[50];
 char desc[50],paydate[YYYMMDD],duedate[YYYMMDD];

 $char fclose[2];
 $long msettle = 0,mprocess,msalvage;
 long  mlosspay;
 $long mapp_loss = 0,app_count;
 long  munfinpay,mtot1;

 $long mlia_prem = 0,mdmg_prem = 0, mcancel = 0;
 long  mpremium1,mpremium2,mtot2;
 $char fcard_class[2], fcard_class_abn[2]; 

 $char dacc[25],s_dacc[25],iclaim[CLAIM_NUM],daccident[25],iacc_reason[3];
 long  qacctimes;

 $int  ibatch_no = 0,iProvX,iCompDplyChange;
 $char batch_no[3];
  
 char  tmpbuf[4000];
 int   count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int   i,total_count=0; 

 int   flag=0;
 char  taipei_db[40], dbname_tp[25];
 $char stmt[1000];
 char  dbsite1[3], FullDBName1[20];
 char  dbsite2[3], FullDBName2[20];
 int   rc;
 
 char sMedrinj_cover[15], sMedrdea_cover[15], sMedrdmg_cover[15];
 $char iedr_return[2], terminate_rsn[2], ded_business[2], fmservice[2], fmaintain[2];
 $char ipass[EMPLOYEE_ID];
 $char napprove[150], iendorse[21];
 $char sDinstall_ym[7],sIsequence[31]; /*1120927002_C02 �R�q�ΰӫ~�}�o*/
 


 cm_buf_get("%s",DBName);
 cm_buf_get("%s",iabnormal);
printf("----DBName[%s] iabnormal[%s]\n",DBName,iabnormal);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False) 
 {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
 }

 rc = getHeadBranch(taipei_db);
 if (rc < 0) {
     printf("read Config file error!!\n");
     return M_CM_READ_CONFIG_ERR;
 }
 strcpy(dbname_tp,get_full_dbname(taipei_db));
printf("dbname_tp[%s]\n",dbname_tp);

 sprintf_s(stmt, sizeof stmt,"SELECT %s %s %s FROM %s:%s %s",
              "iabn_type,fpass,icard,ipolicy,irelative_ply,",
              "fedr_class,fpay,ipay,dedr_begin,dedr_end,",
              "dedr_examine,iedr_area,ibroker,iofficer,itreaty ",
              dbname_tp,"abn_edr_relation ",
              "WHERE iabnormal=?");
 printf("1[%s]\n",stmt);
 $PREPARE CUR_STMT5 FROM $stmt;
 $DECLARE x3 CURSOR FOR CUR_STMT5;
 $OPEN x3 USING $iabnormal;
 $FETCH x3
   INTO $iabn_type,$fpass,$icard,$ipolicy,$irelative_ply,$fedr_class,
        $fpay,$ipay,$dedr_begin,$dedr_end,$dedr_examine,$iedr_area,
        $ibroker,$iofficer,$itreaty;
 $CLOSE x3;
    
 sprintf_s(stmt, sizeof stmt,"SELECT %s %s %s %s %s %s %s %s %s %s FROM %s:%s %s:%s %s",
     "a.iassured,a.fassured,a.nassured,a.nuser,",
     "a.ibenef,a.nbenef,a.aassured,a.itel,a.qply_period,",
     "a.dply_begin,a.dply_end,a.dissue,b.ipro_year,",
     "b.ibrand,b.icar_type,a.ncar_abbr,",
     "a.qcylinder,a.iengine,a.ibody,a.itag,a.ilicense,",
     "a.dbirth,a.fsex,a.fmarriage,",
     "a.flimit,a.pdmg_align,a.plia_align,",
     "a.mcar_price,a.nequipment,a.nbrand_abbr,a.pdmg_acc,a.plia_acc, abs(b.mcancel), iedr_return, terminate_rsn, ded_business, fmservice, fmaintain, ",
     "a.dply_begin, b.iendorse, ",
     "nvl(to_char(a.dinstall,'%Y')::integer - 1911 ||'/'||to_char(a.dinstall,'%m'),' ') ,a.isequence ",
     dbname_tp,"abnormal_edr a," ,dbname_tp,"abn_edr_relation b",
     " WHERE a.iabnormal=? AND a.iabnormal=b.iabnormal");
 printf("2[%s]\n",stmt);
 $PREPARE CUR_STMT6 FROM $stmt;
 $DECLARE x4 CURSOR FOR CUR_STMT6;
 $OPEN x4 USING $iabnormal;
 $FETCH x4
   INTO $iassured,$fassured,$nassured,$nuser,$ibenef,$nbenef,
 	$aassured,$itel,$qply_period,$dply_begin,$dply_end,
 	$dissue,$ipro_year,$ibrand,$icar_type,$ncode,
 	$qcylinder,$iengine,$ibody,$itag,$ilicense,$dbirth,
 	$fsex,$fmarriage,$flimit,$pdmg_align,$plia_align,
 	$mcar_price,$nequipment,$nbrand_abbr,$pdmg_acc,$plia_acc,$mcancel,$iedr_return, $terminate_rsn, $ded_business, $fmservice, $fmaintain,
  $ldply_begin_a, $iendorse,$sDinstall_ym,$sIsequence;
 if(SQLCODE==SQLNOTFOUND) 
 {
   printf("abnormal_edr\n");
   if (exitsub(reply,M_CA_NOREC_ERR) == True) 
       return M_CA_NOREC_ERR; 
   else  
       return apiRC;
 }


 printf("3[%s]\n",stmt);
 cm_buf_init(ReplyBuf); 
 cm_buf_res_msg();
 cm_buf_res_count();
 cm_buf_put_msg(M_CM_OK);
 cm_buf_put("%s %c %s %s %s %s %s",
            iabnormal,iabn_type[0],fpass,icard,ipolicy,
            irelative_ply,fedr_class);

 switch (fedr_class[0]) {
 case '1':
 		cm_buf_put("%s","���P");
 		break;
 case '2':
 		cm_buf_put("%s","�L��(�����ʫO�O)");
 		break;
 case '3':
 		cm_buf_put("%s","��g��H");
 		break;
 case '4':
 		cm_buf_put("%s","�h���h�O");
 		break;
 case '5':
 		cm_buf_put("%s","�@����");
 		break;
 case '6':
 		cm_buf_put("%s","���B���");
 		break;
 case '7':
 		cm_buf_put("%s","�L�����");
 		break;
 case '8':
 		cm_buf_put("%s","�L��(���ʫO�O)");
 		break;
 case '9':
 		cm_buf_put("%s","����");
 		break;
 default:
 		cm_buf_put("%s","not defined");
 		break;
 }
 cm_buf_put("%s %s",fpay,ipay);
 strcpy(s_dedr_begin,cm_from_infdate_100(dedr_begin));
 strcpy(s_dedr_end,cm_from_infdate_100(dedr_end));
 strcpy(s_dedr_examine,cm_from_infdate_100(dedr_examine));
 cm_buf_put("%s %s %s %s %s %s %c",
             s_dedr_begin,s_dedr_end,s_dedr_examine,iedr_area,
             ibroker,iofficer,itreaty[0]);
 cm_buf_put("%s",iassured);

 switch (fassured[0]) {
 case '1':
 		cm_buf_put("%s","�۵M�H");
 		break;
 case '2':
 		cm_buf_put("%s","�k�H");
 		break;
 case '3':
 		cm_buf_put("%s","���U���q");
 		break;
 default:
 		cm_buf_put("%s","not defined");
 		break;
 }
 cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %l",
	     nassured,nuser,ibenef,nbenef,aassured,itel,iedr_return, terminate_rsn, ded_business, fmservice, fmaintain,qply_period);
 strcpy(s_dply_begin,cm_from_infdate_100(dply_begin));
 strcpy(s_dply_end,cm_from_infdate_100(dply_end));
 cm_buf_put("%s %s %s %s %s %s %s %s",
             s_dply_begin,s_dply_end,dissue,ipro_year,ibrand,
             nbrand_abbr,icar_type,ncode);

memset(s_qcylinder,0,sizeof(s_qcylinder));
 dectoasc(&qcylinder,s_qcylinder,9,2);
              
 cm_buf_put("%s %s %s %s %s %s",
 	     s_qcylinder,iengine,ibody,itag,ilicense,dbirth);

 switch (fsex[0]) {
 case '1':
 		cm_buf_put("%s","�k");
 		break;
 case '2':
 		cm_buf_put("%s","�k");
 		break;
 default:	/* �k�H fsex is null */
 		cm_buf_put("%s","");
 		break;
 }

 switch (fmarriage[0]) {
 case '1':
 		cm_buf_put("%s","�w�B");
 		break;
 case '2':
 		cm_buf_put("%s","���B");
 		break;
 default:	/* �k�H fmarriage is null */
 		cm_buf_put("%s"," ");
 		break;
 }
 memset(s_mcar_price,0,sizeof(s_mcar_price));
 memset(s_plia_acc,0,sizeof(s_plia_acc));
 memset(s_plia_acc,0,sizeof(s_plia_acc));
 
 dectoasc(&mcar_price,s_mcar_price,8,1);
 dectoasc(&pdmg_acc,s_pdmg_acc,8,1);
 dectoasc(&plia_acc,s_plia_acc,8,1);
 

 cm_buf_put("%s"," "); /*** ca402p02.iacc_aligen.Caption ???? ***/
 /****************************************************************
 cm_buf_put("%s %s %c %l %l %s %s",
            s_pdmg_acc,s_plia_acc,flimit[0],pdmg_align,plia_align,
            s_mcar_price,nequipment);
 ****************************************************************/

 /* car9610052 ���P���O�i�ۦ��J���B */

 cm_buf_put("%s %s %s %s %s %l",
            flimit,s_pdmg_acc,s_plia_acc,
            s_mcar_price,nequipment, mcancel);

 desc[0]=paydate[0]=duedate[0]=result[0]=0;
 if( fcard_class[0] == '1')
 {
 	strncpy(policy_1,ipolicy,CAR_POLICY_LEN);
 	policy_1[CAR_POLICY_LEN]=0;
	strcpy(policy_2,&ipolicy[CAR_POLICY_LEN]);
 }
 else
 {
        strncpy(policy_1,ipolicy,CAR_POLICY_LEN); 
	policy_1[CAR_POLICY_LEN]=0;
        strcpy(policy_2," ");
 }

 $DECLARE cur_batch1 CURSOR FOR
   SELECT ibatch_no
     INTO $ibatch_no
     FROM ply_relation
    WHERE ipolicy=$ipolicy;

    $OPEN cur_batch1;
   $FETCH cur_batch1;
   $CLOSE cur_batch1;

 memset (batch_no, 0, sizeof(batch_no));
 sprintf_s(batch_no, sizeof batch_no,"%d",ibatch_no);


 rc=ao_chk_charge(DBName,'A',policy_1,policy_2,batch_no,result,desc,paydate,duedate);
 cm_buf_put("%s %s %s",desc,paydate,duedate);

 strncpy(dbsite2,ipolicy,2); dbsite2[2]='\0';
 strcpy(FullDBName2,get_full_dbname(dbsite2));

 sprintf_s(stmt, sizeof stmt,"SELECT %s FROM %s:%s %s",
       "iclaim,daccident,msettle,mapp_loss,iacc_reason",
       FullDBName2,"appraisal", "WHERE ipolicy=? ORDER BY iclaim");
 $PREPARE CUR_STMT7 FROM $stmt;
 $DECLARE q_cur CURSOR FOR CUR_STMT7;
 $OPEN q_cur USING $ipolicy;
 count=0;
 mlosspay=munfinpay=0; 
 for(;;) {
    $FETCH q_cur INTO $iclaim,$daccident,$msettle,$mapp_loss,$iacc_reason;
    if (SQLCODE != 0) break;
    count++;

    mlosspay+=msettle;
    munfinpay+=mapp_loss;
 }
 $CLOSE q_cur;
 if (count > 0)
     cm_buf_put("%l %l %l",mlosspay,munfinpay,mlosspay+munfinpay);
 else
     cm_buf_put("%l %l %l",0,0,0);

 mpremium1=mpremium2=0; iProvX = 0;
 /*
 sprintf_s(stmt, sizeof stmt,
         "SELECT a.fcard_class,a.mlia_prem,a.mdmg_prem, a.dply_begin, \
                 (SELECT count(*)::integer FROM %s:ply_ins_type \
                   WHERE ipolicy = a.ipolicy and provision LIKE '%%X%%') \
            FROM %s:ply_relation a \
           WHERE a.ipolicy = ?", FullDBName2, FullDBName2);
 */
 /* 1081225006_SC3 �X�R���[���ڥN�X */
 sprintf_s(stmt, sizeof stmt,
         "SELECT a.fcard_class,a.mlia_prem,a.mdmg_prem, a.dply_begin, "
         "        (SELECT count(*)::integer FROM %s:ply_ins_type "
         "          WHERE ipolicy = a.ipolicy and regex_match(provision,'(;| +|^)X(;| +|$)')) "
         "   FROM %s:ply_relation a "
         "  WHERE a.ipolicy = ?", FullDBName2, FullDBName2);
 printf("stmt=[%s]\n",stmt);
 $PREPARE CUR_STMT8 FROM $stmt;
 $DECLARE x5 CURSOR FOR CUR_STMT8;
 $OPEN x5 USING $ipolicy;
 $FETCH x5 INTO $fcard_class,$mlia_prem,$mdmg_prem, $ldply_begin_b, $iProvX;
 if (SQLCODE==SQLNOTFOUND) 
 {
     printf("ply_relation\n");
     $CLOSE x5;
     if(exitsub(reply,M_CA_NOREC_ERR) == True) 
        return M_CA_NOREC_ERR; 
     else  
        return apiRC;
 }
 $CLOSE x5;

 if (iProvX == 0)
 { 
   /* 
	sprintf_s(stmt, sizeof stmt,
	         "SELECT count(*) FROM %s:abn_edr_ins_type \
	           WHERE iabnormal = '%s' and provision LIKE '%%X%%'",
             dbname_tp, iabnormal);
   */
   /* 1081225006_SC3 �X�R���[���ڥN�X */   
	sprintf_s(stmt, sizeof stmt,
	         "SELECT count(*) FROM %s:abn_edr_ins_type "
	         "  WHERE iabnormal = '%s' and regex_match(provision ,'(;| +|^)X(;| +|$)')",
             dbname_tp, iabnormal);           
    $PREPARE pre_cntX FROM $stmt; 
    $EXECUTE pre_cntX Into $iProvX; 
 }

 if (iProvX > 0)
 { 
    iProvX = 1;
 }
 printf("-- trace iProvX[%d]\n ",iProvX);
 strcpy( fcard_class_abn, fcard_class);
 if (fcard_class[0]=='1') mpremium2=mlia_prem; 
 else mpremium1=mdmg_prem+mlia_prem;

 sprintf_s(stmt, sizeof stmt,"SELECT irelative_ply FROM %s:%s %s %s",
              FullDBName2,"ply_relation ",
              "WHERE ipolicy=? ",
              "  AND irelative_ply IS NOT NULL AND irelative_ply != ' ' ");
 $PREPARE CUR_STMT9 FROM $stmt;
 $DECLARE x6 CURSOR FOR CUR_STMT9;
 $OPEN x6 USING $ipolicy;
 $FETCH x6 INTO $irelative_ply;
 if(SQLCODE!=SQLNOTFOUND) 
 {
    strncpy(dbsite1,irelative_ply,2); dbsite1[2]='\0';
    strcpy(FullDBName1,get_full_dbname(dbsite1));
    if (FullDBName1[0]=='\0') return M_CM_DB_NOTOPEN;

    sprintf_s(stmt, sizeof stmt,"SELECT %s FROM %s:%s %s",
                 "fcard_class,mlia_prem,mdmg_prem",
                 FullDBName1,"ply_relation", "WHERE ipolicy=?");
    $PREPARE CUR_STMT1 FROM $stmt;
    $DECLARE x1 CURSOR FOR CUR_STMT1;
    $OPEN x1 USING $irelative_ply;
    $FETCH x1 INTO $fcard_class,$mlia_prem,$mdmg_prem;
    if(SQLCODE!=SQLNOTFOUND) {
       if (fcard_class[0]=='1') mpremium2=mlia_prem;
       else mpremium1=mdmg_prem+mlia_prem;
    }
 }
 cm_buf_put("%l %l %l",mpremium1,mpremium2,mpremium1+mpremium2);

    
 sprintf_s(stmt, sizeof stmt,"SELECT %s FROM %s:%s %s %s ",
              "daccident,iclaim ",
              FullDBName2,"appraisal",
              "WHERE ipolicy=? ",
              "ORDER BY daccident");
 $PREPARE CUR_STMT10 FROM $stmt;
 $DECLARE q_cur2 CURSOR FOR CUR_STMT10;

 $OPEN q_cur2 USING $ipolicy;
 app_count=0;
 for(;;) 
 {
     $FETCH q_cur2 INTO $dacc,$iclaim;
     if (SQLCODE != 0) break;
     app_count++;
 } 
 $CLOSE q_cur2;

 if (app_count== 0)
     cm_buf_put("%l %s %s",0," "," ");
 else
 {
    strcpy(s_dacc,cm_sysd_cdate_100(dacc));
    cm_buf_put("%l %s %s",app_count,s_dacc,iclaim);
 }


 printf("=======a dbname_tp[%s]\n",dbname_tp);

 sprintf_s(stmt, sizeof stmt,"SELECT %s %s FROM %s:%s %s",
              "iedr_type,iins_type,medrinj_cover,medrdea_cover,",
              "medrdmg_cover,mdeduct,medrins_prem,fcal_way,pcal,qday ",
              dbname_tp,"abn_edr_ins_type ",
              "WHERE iabnormal=? ");
 printf("=======b stmt[%s]\n",stmt);
 $PREPARE CUR_STMT11 FROM $stmt;
 $DECLARE q_cur3 CURSOR FOR CUR_STMT11;
 $OPEN q_cur3 USING $iabnormal;
 count=mtotprem=0;
 for(;;)
 {
    $FETCH q_cur3
      INTO $iedr_type,$iins_type,$medrinj_cover,$medrdea_cover,$medrdmg_cover,
           $medrdeduct,$medrins_prem,$fcal_way,$pcal,$qday;
    if (SQLCODE != 0) break;
    sprintf_s(s_pcal, sizeof s_pcal,"%03d",pcal);
    fcal_pcal[0]=fcal_way[0];
    fcal_pcal[1]=s_pcal[0];
    fcal_pcal[2]=s_pcal[1];
    fcal_pcal[3]=s_pcal[2];
    fcal_pcal[4]='\0';    
    sprintf_s(sMedrinj_cover, sizeof sMedrinj_cover, "%.1f", (double) medrinj_cover/10000);
    sprintf_s(sMedrdea_cover, sizeof sMedrdea_cover, "%.1f", (double) medrdea_cover/10000);
    sprintf_s(sMedrdmg_cover, sizeof sMedrdmg_cover, "%.1f", (double) medrdmg_cover/10000);
    cm_buf_put("%s %s %s %s %s %l %l %s %l",
                iedr_type,iins_type,sMedrinj_cover,
                sMedrdea_cover,sMedrdmg_cover,
                medrdeduct,medrins_prem,fcal_pcal,qday);
    mtotprem+=medrins_prem;
    count++;
 }
 $CLOSE q_cur3;

 $long  irba_HG; 
 $int   isid_rba;     /* ISID+RBA���� */
 $char  isid_type[2]; /* ISID+RBA���� < 5         �^�� N:�D�����I
                         ISID+RBA���� >= 5 and <8 �^�� Y:�����I�ݼf�֭֮�
                         ISID+RBA����>=8          �^�� S:�����I�ݰ������óq���k������
                         ��ISID�|���f�֧���       �^�� W:�f�ָ�Ʃ|���^�� */
 $char isid_msg[201];
 $char iact[2];

 irba_HG  = 0; isid_rba = 0;
 strcpy( isid_msg, " "); strcpy( isid_type, " ");
 strcpy( napprove, " "); 
 strcpy( iact, "P");

 rc = cm_get_done_isid( iact, iabnormal, policy_1, policy_2, iendorse, &isid_rba, isid_type, isid_msg);
 printf("-- trace cm_get_done_isid rc[%d]\n ",rc);
 printf("iabnormal[%s], policy_1[%s], policy_2[%s], iendorse[%s], isid_rba[%d], isid_type[%s], isid_msg[%s]\n", 
         iabnormal, policy_1, policy_2, iendorse, isid_rba, isid_type, isid_msg);

 /* char *iact, *iref, *iply1, *iply2, *iedr, *isid_type, *isid_msg;
 int *isid_rba; */

 

 $select first 1 napprove 
    into $napprove
    from  cm_risk_preview 
   WHERE iref_num = $iabnormal;
 
 printf("[%s],[%d],[%d]\n", fcard_class_abn, ldply_begin_a, ldply_begin_b);
 iCompDplyChange = 0;
 if (fcard_class_abn[0]=='1' && (ldply_begin_a < ldply_begin_b))
 { 
     iCompDplyChange = 1;
 } 

 /* �H�U���@����A�ݰӫ~��D�޼f��
   1.�j���I���ͮĤ� < ��e�ͮĤ�
   2.ISID+RBA�������I 
   3.��X���� (�O�I�����ܧ�Τ��~�פ���[����)
 */
 strcpy( ipass, ""); 
 if( ( iCompDplyChange == 1 ) ||
     ( isid_type[0] == 'Y' || isid_type[0] == 'S' || isid_type[0] == 'W') ||
     ( iProvX == 1)
   )
 { 
     $select resp_name 
        into $ipass
        from personal:unitid2ef WHERE code_no = '320101';
 }
 cm_buf_put("%s %l %s %s %l %l", ipass, isid_rba, napprove, isid_type,iProvX,iCompDplyChange);

 printf(">>>>>>>>>>>> count[%d]\n",count); 

 cm_buf_put_count(count);
 cm_buf_put("%l",mtotprem);

 cm_buf_put("%s %s",sDinstall_ym, sIsequence); /*1120927002_C02 �R�q�ΰӫ~�}�o*/



 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
    return apiRC;
 else
    return api_OKComplete;

 

errexit:
  printf("SQLCODE:%d errmsg:%s\n",SQLCODE,sqlca.sqlerrm);
  if(exitsub(reply,SQLCODE) == True) 
     return SQLCODE;
  else  
     return apiRC;
}


/******************************************************************/
long car402_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 $char DBName[DBNAME];

 $char old_iabnormal[CA_ESTIMATE_NUM],iabnormal[CA_ESTIMATE_NUM];
 $char iabn_type[2],icard[CARD_NUM],ipolicy[POLICY_NUM_1];
 $char irelative_ply[POLICY_NUM_1],fedr_class[2];
 $char fpay[2],ipay[POLICY_NUM_1],dedr_begin[11];
 $char s_dedr_begin[YYYMMDD],dedr_end[11],s_dedr_end[YYYMMDD];
 $char dedr_examine[11],s_dedr_examine[YYYMMDD];
 $char iedr_cashier[EMPLOYEE_ID],ibroker[BROKER],iofficer[EMPLOYEE_ID];
 $char itreaty[2];

 $char iassured[CUSTOMER_ID],fassured[2];
 $char nassured[ASSURED_NAME],nuser[19],ibenef[11],nbenef[43];
 $char aassured[92],itel[21];
 $long qply_period = 0;
 $char dply_begin[11],s_dply_begin[YYYMMDD],dply_end[11],s_dply_end[YYYMMDD];
 $char dissue[11],ipro_year[5],ibrand[9];
 $char nbrand_abbr[13];
 $char icar_type[CA_CAR_TYPE_NUM];
 $char ncode[11]; /* car_type */
 $long qcylinder;
 $char iengine[CA_ENGINE_NUM],ibody[CA_BODY_NUM],itag[CA_TAG_NUM],ilicense[CUSTOMER_ID];
 $char dbirth[11],fsex[2],fmarriage[2],iacc_align[3],flimit[2];
 $long pdmg_align,plia_align;
 $dec_t mcar_price; /* it is decimal */
 $char s_mcar_price[10];
 $char nequipment[11];

 $char iedr_type[3],iins_type[INSURANCE_TYPE];
 $long medrinj_cover=0,medrdea_cover=0,medrdmg_cover=0,medrdeduct=0,medrins_prem=0;
 long  mtotprem;
 $char fcal_way[2];
 $long pcal = 0;
 char  s_pcal[4],fcal_pcal[5];
 long  qcount;

 char result[50];
 char desc[50],paydate[YYYMMDD],duedate[YYYMMDD];

 $char fclose[2];
 $long msettle = 0,mprocess,msalvage;
 long mlosspay;
 $long mapp_loss = 0;
 long munfinpay,mtot1;

 $long mlia_prem = 0,mdmg_prem = 0;
 long mpremium1,mpremium2,mtot2;
 $char fcard_class[2];

 $char fpass[2],ipass[EMPLOYEE_ID];
 $long dpass;

 $char dacc[25],s_dacc[25],iclaim[CLAIM_NUM];
 long qacctimes;

 $int  ibatch_no = 0;
 $char batch_no[3];

  
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0; 
 char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
 int raw_len;
 long dummy=0;
 long MsgCode;

 $char stmt[1000];
 char  dbsite1[3], FullDBName1[40];
 char  dbsite3[3], FullDBName3[40];
 char  taipei_db[40], dbname_tp[45];
 int   rc;
 $char napprove[151],npass[101];

 comm = (char *) command;
 cm_buf_init(command);
 cm_buf_get("%c %s",&option,DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

  /*strcpy(taipei_db,"00");*/
  rc = getHeadBranch(taipei_db);
  if (rc < 0) {
      printf("read Config file error!!\n");
      return M_CM_READ_CONFIG_ERR;
  }
  strcpy(dbname_tp,get_full_dbname(taipei_db)); /* get TP's full DB name */

 /* compare old record and current record, if the record has not been changed  
    since last request, update or delete the record, otherwise return errmsg
    to client side */

 /* get old record info from command buffer */ 

/******************* marked for no previous data
 memcpy(&raw_len,&comm[com_len],sizeof(int));   
 pos = &comm[com_len+sizeof(int)];
 raw_ptr = malloc(raw_len);
 if (raw_ptr != (char*)0)  
  memcpy(raw_ptr,pos,raw_len);
 else
  {
   if(exitsub(reply,M_CM_NOT_MALLOC) == True)   
    return M_CM_NOT_MALLOC;
   else  
    return apiRC;
  }
    
 cm_buf_init(raw_ptr);          
 cm_buf_get("%l",&dummy);
 cm_buf_get("%l",&count);
 cm_buf_get("%s",old_iabnormal);

 $BEGIN WORK;   

 sprintf_s(stmt, sizeof stmt,"SELECT %s %s %s FROM %s:%s %s",
              "iabn_type,icard,ipolicy,irelative_ply,fedr_class,",
 	      "fpay,ipay,dedr_begin,dedr_end,dedr_examine,",
              "iedr_cashier,ibroker,iofficer,itreaty, dissue ",
              dbname_tp,"abn_edr_relation ",
              "WHERE iabnormal=? ");
 $PREPARE CUR_STMT12 FROM $stmt;
 $DECLARE x7 CURSOR FOR CUR_STMT12;
 $OPEN x7 USING $old_iabnormal;
 $FETCH x7
   INTO $iabn_type,$icard,$ipolicy,$irelative_ply,$fedr_class,
        $fpay,$ipay,$dedr_begin,$dedr_end,$dedr_examine,
        $iedr_cashier,$ibroker,$iofficer,$itreaty,$dissue;
 $CLOSE x7;
    
 sprintf_s(stmt, sizeof stmt,"SELECT %s %s %s %s %s %s %s %s FROM %s:%s %s %s",
              "a.iassured, a.fassured, a.nassured, a.nuser, ",
              "a.ibenef, a.nbenef, a.aassured, a.itel, a.qply_period, ",
 	      "a.dply_begin, a.dply_end, a.ipro_year, ",
              "a.ibrand, a.icar_type, c.ncode, ",
 	      "a.qcylinder, a.iengine, a.ibody, a.itag, a.ilicense, ",
              "a.dbirth, a.fsex, a.fmarriage, ",
 	      "a.flimit, a.pdmg_align, a.plia_align, ",
 	      "a.mcar_price, a.nequipment ",
              dbname_tp,"abnormal_edr a ,car_type c ",
              "WHERE a.iabnormal=? ",
  	      "  AND a.icar_type=c.icode AND c.fclass='1' ");
 $PREPARE CUR_STMT13 FROM $stmt;
 $DECLARE x8 CURSOR FOR CUR_STMT13;
 $OPEN x8 USING $old_iabnormal;
 $FETCH x8
   INTO $iassured,$fassured,$nassured,$nuser,$ibenef,$nbenef,
 	$aassured,$itel,$qply_period,$dply_begin,$dply_end,
 	$ipro_year,$ibrand,$icar_type,$ncode,
 	$qcylinder,$iengine,$ibody,$itag,$ilicense,$dbirth,
 	$fsex,$fmarriage,$flimit,$pdmg_align,$plia_align,
 	$s_mcar_price,$nequipment ;
 if(SQLCODE==SQLNOTFOUND) 
 {
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   $CLOSE x8;
   if(exitsub(reply,M_CA_NOREC_ERR) == True) 
    return M_CA_NOREC_ERR; 
   else  
    return apiRC;
 }
 $CLOSE x8;
 $WHENEVER SQLERROR GOTO errexit;

 $DECLARE cur1 CURSOR FOR
   SELECT nbrand_abbr
     INTO $nbrand_abbr
     FROM ca_car_model
    WHERE ibrand=$ibrand;
 $OPEN cur1;
 $FETCH cur1;
 $CLOSE cur1;


 cm_buf_init(cur_buf);
 cm_buf_res_msg();	 
 cm_buf_res_count();
 cm_buf_put_msg(dummy);

 cm_buf_put("%s %c %s %s %s %s",
  	old_iabnormal,iabn_type[0],icard,ipolicy,irelative_ply,fedr_class);
 switch (fedr_class[0]) {
 case '1':
 		cm_buf_put("%s","���P");
 		break;
 case '2':
 		cm_buf_put("%s","�L��");
 		break;
 case '3':
 		cm_buf_put("%s","��g��H");
 		break;
 case '4':
 		cm_buf_put("%s","�h���h�O");
 		break;
 case '5':
 		cm_buf_put("%s","�@����");
 		break;
 case '6':
 		cm_buf_put("%s","���B���");
 		break;
 case '7':
 		cm_buf_put("%s","�L�����");
 		break;
 case '9':
 		cm_buf_put("%s","����");
 		break;
 default:
 		cm_buf_put("%s","not defined");
 		break;
 }
 cm_buf_put("%s %s",fpay,ipay);
 strcpy(s_dedr_begin,cm_from_infdate_100(dedr_begin));
 strcpy(s_dedr_end,cm_from_infdate_100(dedr_end));
 strcpy(s_dedr_examine,cm_from_infdate_100(dedr_examine));
 cm_buf_put("%s %s %s %s %s %s %c",
 	     s_dedr_begin,s_dedr_end,s_dedr_examine,
             iedr_cashier,ibroker,iofficer,itreaty[0]);
 cm_buf_put("%s",iassured);
 switch (fassured[0]) {
 case '1':
 		cm_buf_put("%s","�۵M�H");
 		break;
 case '2':
 		cm_buf_put("%s","�k�H");
 		break;
 case '3':
 		cm_buf_put("%s","���U���q");
 		break;
 default:
 		cm_buf_put("%s","not defined");
 		break;
 }
 cm_buf_put("%s %s %s %s %s %s %l",
		nassured,nuser,ibenef,nbenef,aassured,itel,qply_period);
 strcpy(s_dply_begin,cm_from_infdate_100(dply_begin));
 strcpy(s_dply_end,cm_from_infdate_100(dply_end));
 cm_buf_put("%s %s %s %s %s %s %s %S",
             s_dply_begin,s_dply_end,dissue,ipro_year,
             ibrand,nbrand_abbr,icar_type,ncode);
 cm_buf_put("%l %s %s %s %s %s",
 		qcylinder,iengine,ibody,itag,ilicense,dbirth);
switch (fsex[0]) {
 case '1':
 		cm_buf_put("%s","�k");
 		break;
 case '2':
 		cm_buf_put("%s","�k");
 		break;
 default:
 		cm_buf_put("%s","not defined");
 		break;
 }
switch (fmarriage[0]) {
 case '1':
 		cm_buf_put("%s","�w�B");
 		break;
 case '2':
 		cm_buf_put("%s","���B");
 		break;
 default:
 		cm_buf_put("%s","not defined");
 		break;
 }
 cm_buf_put("%s"," ");
 cm_buf_put("%c %l %l %s %s",
 	flimit[0],pdmg_align,plia_align,s_mcar_price,nequipment);


 desc[0]=paydate[0]=duedate[0]=result[0]=0;

 if( fcard_class[0] == '1')
 {
 	strncpy(policy_1,ipolicy,CAR_POLICY_LEN);
 	policy_1[CAR_POLICY_LEN]=0;
	strcpy(policy_2,&ipolicy[CAR_POLICY_LEN]);
 }
 else
 {
        strncpy(policy_1,ipolicy,CAR_POLICY_LEN); 
	policy_1[CAR_POLICY_LEN]=0;
        strcpy(policy_2," ");
 }

 $DECLARE cur_batch2 CURSOR FOR
   SELECT ibatch_no
     INTO $ibatch_no
     FROM ply_relation
    WHERE ipolicy=$ipolicy;

    $OPEN cur_batch2;
   $FETCH cur_batch2;
   $CLOSE cur_batch2;

 memset (batch_no, 0, sizeof (batch_no));
 sprintf_s(batch_no, sizeof batch_no,"%d",ibatch_no);

 rc=ao_chk_charge(DBName,'A',policy_1,policy_2,batch_no,result,desc,paydate,duedate);
 cm_buf_put("%s %s %s",desc,paydate,duedate);
 
 strncpy(dbsite3,ipolicy,2); dbsite3[2]='\0';
 strcpy(FullDBName3,get_full_dbname(dbsite3));

 $DECLARE q_cur10 CURSOR FOR
 sprintf_s(stmt, sizeof stmt,"SELECT %s FROM %s:%s %s",
              "fclose,msettle,mprocess,msalvage,mapp_loss",
              FullDBName3,"appraisal",
              "WHERE ipolicy=? ");
 $PREPARE CUR_STMT14 FROM $stmt;
 $DECLARE q_cur10 CURSOR FOR CUR_STMT14;
 $OPEN q_cur10 USING $ipolicy;
 count=0;
 mlosspay=munfinpay=0;
 for(;;)
  {
    $FETCH q_cur10
      INTO $fclose,$msettle,$mprocess,$msalvage,$mapp_loss;
    if (SQLCODE != 0) break;
    count++;
    if (fclose[0]=='1') 
        mlosspay+=msettle+mprocess-msalvage;
    else 
        munfinpay+=mapp_loss;
  } 

 $CLOSE q_cur10;
 if (count > 0)
    cm_buf_put("%l %l %l",mlosspay,munfinpay,mlosspay+munfinpay);
 else         
  {
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(exitsub(reply,M_CA_NOREC_ERR) == True) 
    return M_CA_NOREC_ERR;
   else  
    return apiRC;
  } 
 $WHENEVER SQLERROR GOTO errexit;

 mpremium1=mpremium2=0;
 sprintf_s(stmt, sizeof stmt,"SELECT %s FROM %s:%s %s",
              "fcard_class,mlia_prem,mdmg_prem ",
              FullDBName3,"ply_relation",
              "WHERE ipolicy=? ");
 $PREPARE CUR_STMT15 FROM $stmt;
 $DECLARE x9 CURSOR FOR CUR_STMT15;
 $OPEN x9 USING $ipolicy;
 $FETCH x9 INTO $fcard_class,$mlia_prem,$mdmg_prem;
 if(SQLCODE==SQLNOTFOUND) 
 {
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   $CLOSE x9;
   if(exitsub(reply,M_CA_NOREC_ERR) == True) 
    return M_CA_NOREC_ERR; 
   else  
    return apiRC;
 }
 $CLOSE x9;
 $WHENEVER SQLERROR GOTO errexit;

 if (fcard_class[0]=='1') mpremium2=mlia_prem;
 else mpremium1=mdmg_prem+mlia_prem;

 sprintf_s(stmt, sizeof stmt,"SELECT irelative_ply FROM %s:%s %s %s",
              FullDBName3,"ply_relation",
              "WHERE ipolicy=? ",
              "  AND irelative_ply IS NOT NULL AND irelative_ply !=' ' ");
 $PREPARE CUR_STMT16 FROM $stmt;
 $DECLARE x10 CURSOR FOR CUR_STMT16;
 $OPEN x10 USING $ipolicy;
 $FETCH x10 INTO $irelative_ply;
 if(SQLCODE!=SQLNOTFOUND) 
 {
    strncpy(dbsite1,irelative_ply,2); dbsite1[2]='\0';
    strcpy(FullDBName1,get_full_dbname(dbsite1));
    if (FullDBName1[0]=='\0') return M_CM_DB_NOTOPEN;

    sprintf_s(stmt, sizeof stmt,"SELECT %s FROM %s:%s %s",
                 "fcard_class,mlia_prem,mdmg_prem",
                 FullDBName1,"ply_relation", "WHERE ipolicy=?");
    $PREPARE CUR_STMT2 FROM $stmt;
    $DECLARE x2 CURSOR FOR CUR_STMT2;
    $OPEN x2 USING $irelative_ply;
    $FETCH x2 INTO $fcard_class,$mlia_prem,$mdmg_prem;
    if(SQLCODE!=SQLNOTFOUND) {
       if (fcard_class[0]=='1') mpremium2=mlia_prem;
       else mpremium1=mdmg_prem+mlia_prem;
    }
 }
 cm_buf_put("%l %l %l",mpremium1,mpremium2,mpremium1+mpremium2);

 sprintf_s(stmt, sizeof stmt,"SELECT %s FROM %s:%s %s",
              "daccident,iclaim",
              FullDBName,"appraisal",
              "WHERE ipolicy=? ORDER BY daccident");
 $PREPARE CUR_STMT17 FROM $stmt;
 $DECLARE q_cur12 CURSOR FOR CUR_STMT17;

 $OPEN q_cur12 USING $ipolicy;
 count=0;
 for(;;)
 {
    $FETCH q_cur12 INTO $dacc,$iclaim;
    if (SQLCODE != 0) break;
    count++;
 } 
 $CLOSE q_cur12;
 
 if (count > 0) { 
    strcpy(s_dacc,cm_sysd_cdate_100(dacc));
    cm_buf_put("%l %s %s",count,s_dacc,iclaim);
 }
 else            
  {
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(exitsub(reply,M_CA_NOREC_ERR) == True) 
    return M_CA_NOREC_ERR;
   else  
    return apiRC;
  } 
 $WHENEVER SQLERROR GOTO errexit;

 sprintf_s(stmt, sizeof stmt,"SELECT %s %s FROM %s:%s %s",
              "iedr_type,iins_type,medrinj_cover,medrdea_cover,",
              "medrdmg_cover,medrdeduct,medrins_prem,fcal_way,pcal ",
              dbname_tp,"abn_edr_ins_type",
              "WHERE iabnormal=$old_iabnormal");
 $PREPARE CUR_STMT18 FROM $stmt;
 $DECLARE q_cur13 CURSOR FOR CUR_STMT18;
 $OPEN q_cur13 USING $old_iabnormal;
 count=mtotprem=0;
 for(;;)
 {
    $FETCH q_cur13
      INTO $iedr_type,$iins_type,$medrinj_cover,$medrdea_cover,$medrdmg_cover,
           $medrdeduct,$medrins_prem,$fcal_way,$pcal ;
    if (SQLCODE != 0) break;
    sprintf_s(s_pcal, sizeof s_pcal,"%03d",pcal);
    fcal_pcal[0]=fcal_way[0];
    fcal_pcal[1]=s_pcal[0];
    fcal_pcal[2]=s_pcal[1];
    fcal_pcal[3]=s_pcal[2];
    fcal_pcal[4]='\0';    
    cm_buf_put("%s %s %l %l %l %l %l %s",
                iedr_type,iins_type,
                medrinj_cover/1000,medrdea_cover/1000,medrdmg_cover/1000,
                medrdeduct,medrins_prem,fcal_pcal);
    mtotprem+=medrins_prem;
    count++;
  } 
 $CLOSE q_cur13;
 
 if (count > 0) { 
    cm_buf_put_count(count);
    cm_buf_put("%l",mtotprem);
 }
 else            
  {
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(exitsub(reply,M_CA_NOREC_ERR) == True) 
    return M_CA_NOREC_ERR;
   else  
    return apiRC;
  } 
 $WHENEVER SQLERROR GOTO errexit;
 
 if (memcmp(cur_buf,raw_ptr,raw_len) != 0)
  {
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(exitsub(reply,M_CM_NOT_EQUAL) == True)
    return M_CM_NOT_EQUAL;
   else 
    return apiRC;
  }
********************************/

 $WHENEVER SQLERROR GOTO errexit;
   
 /* equal, then exec DB operation */

 if (option == 'P')
  {
   /* should be marked if previous compare included */ 
    $BEGIN WORK;             
   cm_buf_init(command);
   cm_buf_get("%c %s",&option,DBName);
   cm_buf_get("%s %c %s %s %s",iabnormal,&fpass[0],ipass,napprove,npass);
printf(">>>>>>>> iabnormal[%s] fpass[%c] ipass[%s]\n",iabnormal,fpass[0],ipass);

   fpass[1]='\0';
   dpass=cm_today();

   sprintf_s(stmt, sizeof stmt,"UPDATE %s:%s %s %s",
                dbname_tp,"abn_edr_relation", 
                "SET (fpass,ipass,dpass,dverify,npass) = (?,?,?,current year to fraction(3),?) ", 
                "WHERE iabnormal = ?");
   $PREPARE CUR_STMT19 FROM $stmt;
   $EXECUTE CUR_STMT19 USING $fpass,$ipass,$dpass,$npass,$iabnormal;

   if( fpass[0] == 'Y') 
       $update cm_risk_preview
           set napprove = $napprove,
               dapprove = current
         where iref_num = $iabnormal;
   else
       $update cm_risk_preview
           set napprove = '',
               dapprove = null
         where iref_num = $iabnormal;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }  

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else
  {
   if(exitsub(reply,M_CM_WRONG_OPTION) == True) 
    return M_CM_WRONG_OPTION;
   else  
    return apiRC;
  } 

 errexit:
  printf("SQLCODE:%d errmsg:%s\n",SQLCODE,sqlca.sqlerrm);
  $WHENEVER SQLERROR CONTINUE;
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True) 
   return MsgCode;
  else  
   return apiRC;
}

