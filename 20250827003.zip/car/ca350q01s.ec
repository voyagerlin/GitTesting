/**********************************************************************/
/*   program id   : ca350q01s.ec                                      */
/*   program name : ���M�L�O��ӫO���Ӫ�                   	      */
/*   date written : 2018/12/05 by 071004                              */
/*   files        :                                                   */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <decimal.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "globdata.h"
#include "safeclib.h"

$char ddate[6];
char dyear[4];
char dmonth[3];


int   count_db,k; 
char  outputf[21];
$char userid[11];
$char DBName[05];
$char FormTp[03];
$char msgbuf[128];
int   max_count;


DBinfo *list;

/*********************************************************************/
main(argc, argv)
int argc;
char **argv;
{
 	int rc;

	batchinit();
	strcpy(DBName,         isNULLstr(argv[1]));
	strcpy(userid,         isNULLstr(argv[2]));
	strcpy(ddate,          isNULLstr(argv[3]));
	strcpy(outputf,        isNULLstr(argv[4]));
	
	strncpy(dyear,ddate,3);
	strcpy(dmonth,"");
        for(int i=3;i<=sizeof(ddate);i++)  
        {
             dmonth[i-3]=ddate[i];
              	
        }
        
        
	rc = car350_get_db();
	if (rc != M_CM_OK)
		return rc;

 
	rc = car350_build();
	if (rc != M_CM_OK) 
		return rc;
}
/*----------------------------------------------------------------------------*/
long car350_get_db()
{
	$whenever sqlerror goto errexit;

	if (db_select(DBName) == FALSE) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car350_build()
{
 
 
 int rc;
 char sfilename[256],stitle[2048],stmt1[6000];

 	
	$WHENEVER SQLERROR GOTO errexit;

	strcpy(dyear,itoa(atoi(dyear)+1911));
	strcpy(sfilename,"���M�L�O�渹�ӫO���Ӫ�[car350]");	
	sprintf_s(stitle,sizeof stitle,"%s�~%s��\t",dyear,dmonth);
	strcat(stitle,"\n");
	strcat(stitle,"\t�޲z�H�W��\t�g��H�N��\t�g�P��\t���I\t�n�O�ѽs��\t�Q�O�I�H\t�P�Ӹ��X\t�j���I�Ҹ�\t���N�I�d��\t�j���I�O�渹�X\t�j���I�O�I�_��\t�j���I�O�I����\t�j���I�O�O\t���N�I�O�渹�X\t���N�I�O�I�_��\t���N�I�O�I����\t���N�I�O�O\t�L�k�X���]\t");
	sprintf_s(stmt1,sizeof stmt1,"SELECT  (select nname from officer where iofficer=b.ileader),chr(127)||b.iofficer,chr(127)||a.ivend_no,chr(127)||a.ibranch_no,a.iauto_no,a.ninsu_name,a.ilicense_no,a.iforce_card_no,a.irand_card_no,a.iforce_insu_no,a.dforce_dates,a.dforce_datee,a.mforce_amt,a.irand_insu_no,a.drand_dates,a.drand_datee,a.mrand_amt,a.nreturn_remark  \n"
		     "  FROM  sysdb:ca_rioho_pol_m_req a ,OUTER officer b   \n"
		     " WHERE  a.freturn_status = '2'  AND  b.ibus_location = a.ivend_no||a.ibranch_no AND a.dsend_date[1,4]='%s' AND a.dsend_date[5,6]='%s' AND b.dexpire is null \n",dyear,dmonth);

	rc = unload_file(outputf," ",sfilename,stitle,stmt1);
	
	if (rc != SUCCESS) 
	{
	    sprintf_s(msgbuf,sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
	    EWRITE(userid, rc , msgbuf);
	    return rc;
	}
	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	return SQLCODE;   
   
}


/*--------------------------------------------------------------------*/



