/*-------------------------------------------------------------------
 *  Program: ca832q01s.ec
 *-------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#include "is_def.h"
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "carmsgs.h"
#include "sql.h"
$include sqlca;
#include "safeclib.h"

char DBName[BRANCH_ID], userid[USER_ID];
$char FormTp[3], TitleFmt[21], BodyFmt[21];
$int Width = 0; 
$int ItemRow, TotColumn, StartRow, TitleRow, PgLine;
char outputf[21], BodyFile[21], TitleFile[21];
int max_count=0;

char dpay1[YYYMMDD], edpay1[YYYYMMDD];
char dpay2[YYYMMDD], edpay2[YYYYMMDD];
char istl_obj[11];

char FullClmDBName[21];
$char pay_unit[5];
$char iclaim[21], fstl[2], istl_obj_ext[3];
$int iclose_type = 0;
$long mexchange;
$long mamount = 0;
$long mprocess = 0;
$char dpay[YYYMMDD], edpay[YYYYMMDD];
$char clmdb[6], nassured[41], itag[CA_TAG_NUM], nadjuster[11];
$char isign[21], nins_type[41];

long msub, mtot;

$char stmt[1024];
char buf[16];

extern char RPTDIR[];
#define fmt1 "---,---,---,--&"

long ca832_Q();
void Put_Head_File(), Put_Body_File();
/***************************************************************************/
main(argc,argv)
int argc;
char *argv[];
{
    long rtncode;

    batchinit();

    strcpy(DBName, isNULLstr(argv[1]));
    strcpy(userid, isNULLstr(argv[2]));

    strcpy(dpay1, isNULLstr(argv[3]));
    strcpy(dpay2, isNULLstr(argv[4]));
    strcpy(istl_obj, isNULLstr(argv[5]));
    strcpy(outputf, isNULLstr(argv[6]));

    strcpy(edpay1, cm_to_infdate(dpay1));
    strcpy(edpay2, cm_to_infdate(dpay2));

    printf("edpay1[%s],edpay2[%s]\n",edpay1,edpay2);

    if ((rtncode=ca832_Q()) != api_OKComplete) {
        EWRITE(userid, rtncode, "build function fail!") ;
        exit(1);
    }

    create_sign_form("car832",BodyFile,Width) ;

    if ((rtncode = save_form_info(F_BLK0,"CA",832,userid,FormTp,max_count,outputf)) < 0)
        EWRITE(userid,rtncode,"save_form_info failed") ;
}

/***************************************************************************/
long ca832_Q()
{
$int DbCnt;
int dbi;
DBinfo *list=NULL;

    dbi = 0;

    if (db_select(DBName) == False)
    {
        EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
        exit(1);
    }

    if ((list=get_db_list(&DbCnt, DBName)) == (char*)0)
    {
        EWRITE(userid, M_CM_NOT_DBLIST, "get_db_list fail");
        exit(1);
    }

    $WHENEVER SQLERROR GOTO errexit;

    /* TEMP TABLE */
    $CREATE TEMP TABLE car832_tbl
    (
        iclaim CHAR(20),
        fstl CHAR(1),
        iclose_type SMALLINT,
        istl_obj_ext CHAR(2),
        nassured CHAR(40),
        itag CHAR(12),
        pay_unit CHAR(4),
        nadjuster CHAR(10),
        dpay DATE,
        mamount DECIMAL(10,0),
        nins_type CHAR(40)
    ) WITH NO LOG;


/************************************
    for(dbi=0; dbi<DbCnt; dbi++)
    {
*************************************/

     printf("dbi[%d]\n",dbi);

        /* ��I���q */
        strncpy(pay_unit, list[dbi].dbchi, 4); pay_unit[4]='\0';
        printf("pay_unit[%s]\n", pay_unit);

        sprintf_s(stmt,1024,
          "SELECT a.iclose, a.fstl, a.iclose_type, a.mexchange, a.dpay, a.istl_obj_ext "
            "FROM ao_stl_obj_close a, ao_stl_close b "
           "WHERE a.iclose = b.iclose AND a.fstl = b.fstl AND a.iclose_type = b.iclose_type "
             "AND b.insure_type = 'C' "
             "AND a.dpay BETWEEN '%s' AND '%s' "
             "AND a.istl_obj = '%s' ", edpay1, edpay2, istl_obj);
        printf("stmt[%s]\n", stmt);

        $PREPARE pr_1 FROM $stmt;
        $DECLARE ca832_q1 CURSOR FOR pr_1;
        $OPEN ca832_q1;
        while(1)
        {
            $FETCH ca832_q1
              INTO $iclaim, $fstl, $iclose_type, $mexchange, $edpay, $istl_obj_ext;
            if (SQLCODE == SQLNOTFOUND) break;
            printf("iclaim[%s]fstl[%s]iclose_type[%d]edpay[%s]istl_obj_ext[%s]\n", iclaim, fstl, iclose_type, edpay, istl_obj_ext);
            max_count++;

            /* �߮׸�Ʈw�B�O��W�١B�P�Ӹ��X�B�z�߸g�� */
            $SELECT ibranch_in, nassured[1,40], itag, (SELECT nname FROM officer WHERE iofficer = a.adjustment)
               INTO $clmdb, $nassured, $itag, $nadjuster
               FROM ca_clm_process a
              WHERE iclaim = $iclaim;
            printf("clmdb[%s]\n", clmdb);
            if (SQLCODE == SQLNOTFOUND)
            {
                sprintf_s(stmt,1024, "[%s]�߮׸�Ƨ䤣��!!", iclaim);
                EWRITE(userid, M_CM_NOT_FOUND, stmt);
                exit(1);
            }
            strcpy(FullClmDBName, get_full_dbname(clmdb));

            msub = 0;
            sprintf_s(stmt,1024,
              "SELECT DISTINCT b.isign, b.mprocess "
                "FROM %s:payment a, %s:ca_sign_receipt b "
               "WHERE a.iclaim = b.iclaim "
                 "AND a.ipayment = b.ifpce_id "
                 "AND a.ifpce_id_ext = b.ifpce_id_ext "
                 "AND a.qserial = b.qserial "
                 "AND a.iclaim = '%s' AND a.fstl = '%s' AND a.iclose_type = %d "
                 "AND a.ipayment = '%s' AND a.ifpce_id_ext = '%s'",
            FullClmDBName, FullClmDBName, iclaim, fstl, iclose_type, istl_obj, istl_obj_ext);
            printf("stmt[%s]\n", stmt);

            $PREPARE pr_2 FROM $stmt;
            $DECLARE ca832_q2 CURSOR FOR pr_2;
            $OPEN ca832_q2;
            while(1)
            {
                $FETCH ca832_q2
                  INTO $isign, $mprocess;
                if (SQLCODE == SQLNOTFOUND) break;
                printf("isign[%s]\n", isign);

                if (strlen(trim(isign))>0)
                {
                    /* ��ñ���渹 */
                    $DECLARE ca832_q3 CURSOR FOR
                      SELECT TRIM(iins_type)||(SELECT TRIM(nins_type) FROM insurance_type
                             WHERE iins_type=a.iins_type), mamount
                        FROM ca_pro_ins a
                       WHERE iclaim = $iclaim
                         AND isign = $isign
                       UNION ALL
                      SELECT TRIM(iins_type)||(SELECT TRIM(nins_type) FROM insurance_type
                             WHERE iins_type=b.iins_type), mamount
                        FROM ca_human_ins b
                       WHERE isign = $isign;
                    $OPEN ca832_q3;
                    while(1)
                    {
                        $FETCH ca832_q3
                          INTO $nins_type, $mamount;
                        if (SQLCODE == SQLNOTFOUND) break;

                        $INSERT INTO car832_tbl
                                (iclaim, fstl, iclose_type, istl_obj_ext, nassured, itag,
                                 pay_unit, nadjuster, dpay, mamount, nins_type)
                         VALUES ($iclaim, $fstl, $iclose_type, $istl_obj_ext, $nassured, $itag,
                                 $pay_unit, $nadjuster, $edpay, $mamount, $nins_type);
                        msub += mamount;
                    }
                    $CLOSE ca832_q3;
                    $FREE ca832_q3;

                    if (mprocess!=0)
                    {
                        $INSERT INTO car832_tbl
                                (iclaim, fstl, iclose_type, istl_obj_ext, nassured, itag,
                                 pay_unit, nadjuster, dpay, mamount, nins_type)
                         VALUES ($iclaim, $fstl, $iclose_type, $istl_obj_ext, $nassured, $itag,
                                 $pay_unit, $nadjuster, $edpay, $mprocess, '�O��');
                        msub += mprocess;
                    }
                }
                else
                {
                    /* �Lñ���渹 */
                    if (iclaim[5]=='C')
                    {
                        /* �j���I */
                        sprintf_s(stmt,1024,
                          "SELECT TRIM(iins_item)||(SELECT TRIM(nins_type) FROM insurance_type "
                                 "WHERE iins_type=a.iins_item), mins_stl, mins_proc "
                            "FROM %s:ca_stl_victim a "
                           "WHERE iclaim = '%s' AND fstl = '%s' AND iclose_type = %d ",
                        FullClmDBName, iclaim, fstl, iclose_type);
                        printf("stmt[%s]\n", stmt);

                        $PREPARE pr_4 FROM $stmt;
                        $DECLARE ca832_q4 CURSOR FOR pr_4;
                        $OPEN ca832_q4;
                        while(1)
                        {
                            $FETCH ca832_q4
                              INTO $nins_type, $mamount, $mprocess;
                            if (SQLCODE == SQLNOTFOUND) break;

                            $INSERT INTO car832_tbl
                                    (iclaim, fstl, iclose_type, istl_obj_ext, nassured, itag,
                                     pay_unit, nadjuster, dpay, mamount, nins_type)
                             VALUES ($iclaim, $fstl, $iclose_type, $istl_obj_ext, $nassured, $itag,
                                     $pay_unit, $nadjuster, $edpay, $mamount, $nins_type);
                            msub += mamount;

                            if (mprocess!=0)
                            {
                                $INSERT INTO car832_tbl
                                        (iclaim, fstl, iclose_type, istl_obj_ext, nassured, itag,
                                         pay_unit, nadjuster, dpay, mamount, nins_type)
                                 VALUES ($iclaim, $fstl, $iclose_type, $istl_obj_ext, $nassured, $itag,
                                         $pay_unit, $nadjuster, $edpay, $mprocess, '�O��');
                                msub += mprocess;
                            }
                        }
                        $CLOSE ca832_q4;
                        $FREE ca832_q4;
                    }
                    else
                    {
                        /* ���N�I */
                        sprintf_s(stmt,1024,
                          "SELECT TRIM(iins_type)||(SELECT TRIM(nins_type) FROM insurance_type "
                                 "WHERE iins_type=a.iins_type), mins_stl, mins_proc "
                            "FROM %s:stl_ins_type a "
                           "WHERE iclaim = '%s' AND fstl = '%s' AND iclose_type = %d ",
                        FullClmDBName, iclaim, fstl, iclose_type);
                        printf("stmt[%s]\n", stmt);

                        $PREPARE pr_5 FROM $stmt;
                        $DECLARE ca832_q5 CURSOR FOR pr_5;
                        $OPEN ca832_q5;
                        while(1)
                        {
                            $FETCH ca832_q5
                              INTO $nins_type, $mamount, $mprocess;
                            if (SQLCODE == SQLNOTFOUND) break;

                            $INSERT INTO car832_tbl
                                    (iclaim, fstl, iclose_type, istl_obj_ext, nassured, itag,
                                     pay_unit, nadjuster, dpay, mamount, nins_type)
                             VALUES ($iclaim, $fstl, $iclose_type, $istl_obj_ext, $nassured, $itag,
                                     $pay_unit, $nadjuster, $edpay, $mamount, $nins_type);
                            msub += mamount;

                            if (mprocess!=0)
                            {
                                $INSERT INTO car832_tbl
                                        (iclaim, fstl, iclose_type, istl_obj_ext, nassured, itag,
                                         pay_unit, nadjuster, dpay, mamount, nins_type)
                                 VALUES ($iclaim, $fstl, $iclose_type, $istl_obj_ext, $nassured, $itag,
                                         $pay_unit, $nadjuster, $edpay, $mprocess, '�O��');
                                msub += mprocess;
                            }
                        }
                        $CLOSE ca832_q5;
                        $FREE ca832_q5;

                    } /* if �j����N */

                } /* if isign */
            }
            $CLOSE ca832_q2;
            $FREE ca832_q2;

            /* �p�ߥI���B�P�I�ت��B�[�`���šA�H�ߥI���B���D */
            if (mexchange!=msub)
            {
                $DELETE FROM car832_tbl
                  WHERE iclaim = $iclaim
                    AND fstl = $fstl
                    AND iclose_type = $iclose_type
                    AND istl_obj_ext = $istl_obj_ext;

                $INSERT INTO car832_tbl
                        (iclaim, fstl, iclose_type, istl_obj_ext, nassured, itag,
                         pay_unit, nadjuster, dpay, mamount, nins_type)
                 VALUES ($iclaim, $fstl, $iclose_type, $istl_obj_ext, $nassured, $itag,
                         $pay_unit, $nadjuster, $edpay, $mexchange, '�L�k�P�_�A�Цۦ�d��');
            }
        }
        $CLOSE ca832_q1;
        $FREE ca832_q1;

/**************
    }
 DbCnt LOOP
***************/

    if (max_count == 0)
    {
        EWRITE(userid, M_CM_NOT_FOUND, "��Ƨ䤣��!!");
        exit(1);
    }

    /* �s�@���� */
    $SELECT nTitle_Fmt,nBody_Fmt,kStart_Row,kTitle_Row,kTot_Col,
            kPgNum_Line,kWidth,iForm_Tp
       INTO $TitleFmt,$BodyFmt,$StartRow,$TitleRow,$TotColumn,
            $PgLine,$Width,$FormTp
       FROM form
      WHERE ksys_grp = 'CA' AND kPgmID = 832;

    Put_Head_File();

    strcpy(BodyFmt,rtrim(BodyFmt)) ;
    sprintf_s(BodyFile,21,"%s.bd",outputf);

    rgu_init_report(BodyFmt,BodyFile);

    max_count = 0;
    mtot = 0;

    $DECLARE ca832_q CURSOR FOR
      SELECT iclaim, nassured, itag, pay_unit, nadjuster,
             dpay, mamount, nins_type
        FROM car832_tbl
       ORDER BY iclaim, dpay, nins_type;
    $OPEN ca832_q;
    while(1)
    {
        $FETCH ca832_q
          INTO $iclaim, $nassured, $itag, $pay_unit, $nadjuster,
               $edpay, $mexchange, $nins_type;
        if (SQLCODE == SQLNOTFOUND) break;

        strcpy(dpay, cm_from_infdate_100(edpay));

        Put_Body_File();
        mtot += mexchange;
    }
    $CLOSE ca832_q;
    $FREE ca832_q;

    rgu_put_body(2); max_count++;
    rfmtlong(mtot, fmt1, buf);
    rgu_put_body_string(3, trim(buf), RIGHT);
    rgu_put_body(3); max_count++;

    rgu_finish_report();

    return api_OKComplete;

errexit:
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    cm_show_sql_err("ca832_Q", "");
    exit(1);
}

/***************************************************************************/
void Put_Head_File()
{
    strcpy(TitleFmt,rtrim(TitleFmt));
    sprintf_s(TitleFile,21,"%s.ti",outputf);

    rgu_init_report(TitleFmt,TitleFile);

    rgu_put_head_string(LEFT, cm_sysd_cdatetime_100(cm_get_sysd()));
    rgu_put_head_string(LEFT, istl_obj);
    rgu_put_head_string(LEFT, dpay1);
    rgu_put_head_string(LEFT, dpay2);

    rgu_put_head();
    rgu_finish_report();
}

/***************************************************************************/
void Put_Body_File()
{
    rgu_put_body_string(1, iclaim, LEFT);
    rgu_put_body_string(1, nassured, LEFT);
    rgu_put_body_string(1, itag, LEFT);
    rgu_put_body_string(1, pay_unit, LEFT);
    rgu_put_body_string(1, nadjuster, LEFT);
    rgu_put_body_string(1, dpay, LEFT);
    rfmtlong(mexchange, fmt1, buf);
    rgu_put_body_string(1, trim(buf), RIGHT);
    rgu_put_body_string(1, nins_type, LEFT);

    rgu_put_body(1); max_count++;
}
