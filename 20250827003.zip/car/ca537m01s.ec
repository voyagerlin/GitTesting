/**********************************************************************/
/*   program id   : ca537m01s.ec                                      */
/*   program name : ���O�l�v��J���鵲��Ƭd��                        */
/*   date written : 2017/05/03                                        */
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include "cmnmsgs.h"
#include <math.h>
#include "safeclib.h"

long car537(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
  long rtncode;
  long car537_multiple_query();
  char option;
  
  cm_buf_init(command);
  cm_buf_get("%c",&option);
  switch(option)
  {     
    case 'M':
           rtncode=car537_multiple_query(reply);
           break;
    
    default :
           if(exitsub(reply,M_CM_WRONG_OPTION) == True)
            return M_CM_WRONG_OPTION;
           return apiRC;
  }
    return(rtncode);                   
}
/******************************************************************************/

long car537_multiple_query(reply)
serverReply reply;
{
    $char DBName[DBNAME];
    $char sUserid[10], sStmt[500], sIpayno[21], sItransno[21], sDcreate[11],
          ncreate[11];
    
    char tmpbuf[4000];
    int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
    
    cm_buf_get("%s %s ", DBName, sUserid);
    
    $WHENEVER SQLERROR GOTO errexit;
    if (db_select(DBName) == False)
    {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True) return M_CM_DB_NOTOPEN;
        else return apiRC;
    }
   
    
    sprintf_s(sStmt,500,"SELECT DISTINCT date(dcreate), idatano, itransno, \
                          (select nname from officer where iofficer = a.icreate) \
                     FROM sysdb:ca_health_recovery a \
                    WHERE icreate = '%s' \
                      AND dclose is null ",sUserid);
                                       
    $PREPARE ca_pre1 FROM $sStmt;                
    $DECLARE ca_cur1 CURSOR FOR ca_pre1;
    $OPEN ca_cur1;
    
    for(;;) { 
     	
    	$FETCH ca_cur1 INTO $sDcreate, $sIpayno, $sItransno, $ncreate;
    	if (SQLCODE != 0) break;
    		
    	cm_buf_init(tmpbuf); 
    	if ( count == 0 )
     	{
      	  cm_buf_res_msg();             /* reserve for MsgCode and count */
      	  cm_buf_res_count();          
     	}
    	  cm_buf_put("%s %s %s %s", sDcreate, sIpayno, ncreate, sItransno);
        tmp_len = cm_buf_len(tmpbuf);
    	if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
        {
      	  memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      	  repbuf_len += tmp_len;
      	  count++;
     	}
   	else                               /* more than 4K, send to client side */ 
     	{ 
      	  cm_buf_init(ReplyBuf);
      	  cm_buf_put_msg(M_CM_OK);
      	  cm_buf_put_count(count);
      	if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
        {
	        $CLOSE ca_cur1;
          return apiRC;
        }
      	else               /* clear ReplyBuf and count to start all over again */
        {
          replycnt++;
          if (replycnt == 10)   /* more than 30K, client cannot display,error */
          {
	  	      cm_buf_init(ReplyBuf);
          	cm_buf_put("%l",M_CM_OUT_SPACE);
          	tmp_len = cm_buf_len(ReplyBuf);
          	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
            	return apiRC;
            	return M_CM_OUT_SPACE; 
          }
	        ReplyBuf[0] = '\0';
	        count = 0;
	        cm_buf_init(ReplyBuf);
          cm_buf_res_msg();           /* reserve for MsgCode and count */
          cm_buf_res_count();    
          cm_buf_put("%s %s %s %s", sDcreate, sIpayno, ncreate, sItransno);
	      repbuf_len = cm_buf_len(ReplyBuf);
	      count++;
       }
     } 
  } /* for loop */

  $CLOSE ca_cur1;
  $FREE  ca_cur1;              
    	
  if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
   if(exitsub(reply,M_CM_NOT_FOUND) == True) 
    return M_CM_NOT_FOUND;
   else  
    return apiRC;
  } 

errexit:
printf("--car537_multiple_query-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
  if(exitsub(reply,SQLCODE) == True)  return SQLCODE;
  else return apiRC;
}
/**********************************THE END*************************************/