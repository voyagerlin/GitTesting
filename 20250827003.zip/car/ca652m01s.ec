/************************************************/
/*                                              */
/*   PROGRAM : ca652m01s.ec by sylvia           */
/*                                              */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"
$include sqlca;
$include "var_length.h";


long car652(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
    long rc;
    long car652_single_query(),car652_multiple_query();
    char option;
    
    cm_buf_init(command);
    cm_buf_get("%c",&option);
    
    switch(option)
    {
        case '1':rc=car652_get_date(reply);
            break;
    
        default :
            if(exitsub(reply,M_CM_WRONG_OPTION) == True)
            return M_CM_WRONG_OPTION;
    
        return apiRC;
    }
    return(rc);
}


/*-----------------------------------------------------------------*/
long car652_get_date(reply)
serverReply reply;
{
    $char DBName[5];
    int tmp_len;
    $char userid[11];
    $char date1[11], date2[11], date3[11],date4[11];
    
    cm_buf_get("%s %s",DBName,userid);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
      if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
        return M_CM_DB_NOTOPEN;
      else
        return apiRC;
    }
    
	

    $select mdy(substr(max(detail2),4,2),'01',substr(max(detail2),1,3)+1911),
            last_day(mdy(substr(max(detail2),4,2),'01',substr(max(detail2),1,3)+1911))
       into $date1, $date2
       from car_code
      where kind = 'RN' and detail = 'car302' and chiname = 'Y';


    if( SQLCODE == SQLNOTFOUND)
        return exitsub(reply, M_CA_NOT_CARD) ? M_CA_NOT_CARD : apiRC;

    $select min(dply_begin),last_day(min(dply_begin)) into $date3,$date4
       from policy_302
      where dply_begin >= add_months(today,-12);


    strcpy(date1,cm_from_infdate_100(date1)); 
	strcpy(date2,cm_from_infdate_100(date2));
	strcpy(date3,cm_from_infdate_100(date3));
	strcpy(date4,cm_from_infdate_100(date4));
	

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %s %s %s", M_CM_OK, date1, date2, date3, date4);

    tmp_len = cm_buf_len(ReplyBuf);

    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
      return apiRC;
    else
      return api_OKComplete;

errexit:
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}


/*----------------------------------------------------------------------------*/

