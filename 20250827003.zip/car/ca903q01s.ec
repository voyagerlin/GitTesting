/*******************************************/
/*                                         */
/*   ���׭��}���Ӫ�                        */
/*                                         */
/*   PROGRAM : car903q01s.ec               */
/*                                         */
/*   DATE    : 91.11.04                    */
/*******************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
$include sqltypes.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include "safeclib.h"

#define  head_line         1
#define  data_line         2

extern char RPTDIR[];

$char option[2];
$static char dbgn1[11], dend1[11];
$static char dbgn_inf[11], dend_inf[11];
char  MsgCode[50];

$char DBName[5], iForm_Tp[3];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1];
char  outputf[N_FILE+1], userid[11];

$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width = 0;
char  day_kind[5];
$char bufA[100],adjustment[11],iclose_type[3];
$char iclaim[21],iins_type[7],dclose[11],branch_type[3],branch[11];
$long mins_app,s_mins_stl,mins_stl = 0;
$char ibranch_in[3],sFullDBName[20],nname[10];

int  max_cnt=0;

long car903_build1();
long car903_body1();
void car903_title();
void car903_print_body();

main(argc, argv)
int argc;
char **argv;
{
   int rc;
   batchinit();
   strcpy(DBName,  isNULLstr(argv[1]));
   strcpy(userid,  isNULLstr(argv[2]));
   strcpy(option,  isNULLstr(argv[3]));
   strcpy(dbgn1,   isNULLstr(argv[4]));
   strcpy(dend1,   isNULLstr(argv[5]));
   strcpy(outputf, isNULLstr(argv[6]));

   strcpy(dbgn_inf,   cm_to_infdate(dbgn1));
   strcpy(dend_inf,   cm_to_infdate(dend1));

   if(strncmp(option,"1",1)==0 )
    {sprintf_s(bufA,100,"WHERE dentry >= ? AND dentry <= ?");
     strcpy(day_kind,"��J"); }
   else if(strncmp(option,"2",1)==0 )
    {sprintf_s(bufA,100,"WHERE dclose >= ? AND dclose <= ?");
     strcpy(day_kind,"�鵲"); }

   strcpy(MsgCode," ");
   rc = car903_build1();
   if (rc != M_CM_OK)
   {
       if (MsgCode[0]==' ')
           EWRITE(userid, rc, " ");
       else
           EWRITE(userid, rc, MsgCode);
       return rc;
   }


}

long car903_build1()
{
   $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];

   int    rc;

   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return FAIL;
   }

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt,  $StartRow,  $TitleRow,  $ItemRow,
           $TotColumn, $PgLine, $Width, $iForm_Tp
      FROM Form
     WHERE ksys_grp = "CA" AND kPgmID = 903;

   strcpy(TitleFmt,rtrim(TitleFmt));
   sprintf_s(TitleFile,21,"%s.ti",outputf);
   strcpy(BodyFmt, rtrim(BodyFmt));
   sprintf_s(BodyFile,21, "%s.bd",outputf);

   rgu_init_report(TitleFmt,TitleFile);
   car903_title();                        
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);

   rc = car903_body1();

   if (rc != M_CM_OK)
       return rc;
   rgu_finish_report();

   create_sign_form("car903", BodyFile, Width);
   if ((rc=save_form_info(F_BLK1, "CA", 903, userid, iForm_Tp, max_cnt, outputf))<0) {
        strcpy(MsgCode,"save_form_info failed");
        return rc;
   }

   return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/
void car903_title()
{
     rgu_put_head_string( 1, cm_sysd_cdatetime_100(cm_get_sysd()));
     rgu_put_head_string( 1, day_kind);
     rgu_put_head_string( 1, dbgn_inf);
     rgu_put_head_string( 1, dend_inf);
     rgu_put_head();
}
/*---------------------------------------------------------------------*/
long car903_body1()
{
 char  tmp_buf[16];
 $char stmt[1200];
 int   rc,flag_first;
 DBinfo *list;
 int i,j,count_db;


   $WHENEVER SQLERROR GOTO errexit;

   /* get db_list without sysdb */
   if ((list = get_db_list (&count_db, DBName)) == (char *) 0)
   {
     if (EWRITE(userid, M_CM_NOT_DBLIST) == True)
       return M_CM_NOT_DBLIST;
     return M_CM_OK;
   }

   rgu_put_body(1); /* �C�Ltitle�� */

   for(j=0;j<count_db;j++)
   {
     sprintf_s(stmt,1200,"SELECT iclaim,iclose_type \
                     FROM %s:ca_local_stl \
                     %s AND fclose = '1' \
                     AND fstl = '1' Order by 1",list[j].dbname,bufA);

     $PREPARE a_id0 FROM $stmt;
     $DECLARE cur1 CURSOR for a_id0;
     $OPEN cur1 USING $dbgn_inf,$dend_inf;
     for(;;)
     {
         $FETCH cur1 INTO $iclaim,$iclose_type;
         if(SQLCODE == SQLNOTFOUND ) break;

         printf(" iclaim=[%s] iclose_type=[%s] \n",iclaim,iclose_type);

         /* �z�ߤH�� */
         $SELECT adjustment , ibranch_in
            INTO $adjustment, $ibranch_in
            FROM ca_clm_process
           WHERE iclaim = $iclaim;
         if(SQLCODE == SQLNOTFOUND ) strcpy(adjustment," ");

         $SELECT nname
            INTO $nname
            FROM officer
           WHERE iofficer = $adjustment;
         if( SQLCODE == SQLNOTFOUND ) strcpy( nname , " ");

         strcpy(sFullDBName, get_full_dbname(ibranch_in));

         /* ���z��� */
         branch_type[0] = iclaim[0];
         branch_type[1] = iclaim[1];
         branch_type[2] = '\0';

         $SELECT nchi_full[1,4] INTO $branch
            FROM branch
           WHERE ibranch = $branch_type;
         if(SQLCODE == SQLNOTFOUND) strcpy(branch," ");


         /* �A�ߪ��B�P���פ�� */
         sprintf_s(stmt,1200,"SELECT iins_type, mins_stl, dclose \
                         FROM %s:stl_ins_type \
                        WHERE iclaim = ? AND fstl = '1' \
                          AND iclose_type = ? ",sFullDBName );

         $PREPARE a_id1 FROM $stmt;
         $DECLARE cur_2 CURSOR for a_id1;
         $OPEN cur_2 USING $iclaim, $iclose_type;
         while(1)
         {
            $FETCH cur_2 INTO $iins_type, $mins_stl, $dclose;
            if( SQLCODE == SQLNOTFOUND ) break;

            /* �w�����B�P��ߥI���B */
            sprintf_s(stmt,1200,"SELECT NVL(mins_app,0) FROM %s:app_ins_type \
                           WHERE iclaim = '%s' AND iins_type = '%s'",
                         sFullDBName, iclaim, iins_type );
            $PREPARE app_id1 FROM $stmt;
            $EXECUTE app_id1 INTO $mins_app;
            if( SQLCODE == SQLNOTFOUND )
            {
            	mins_app = 0;
            }
            
            sprintf_s(stmt,1200,"SELECT NVL(SUM(mins_stl),0) \
                            FROM %s:stl_ins_type  \
                           WHERE iclaim = ? AND iins_type = ? \
                             AND fstl = '1' AND iclose_type < ? ", sFullDBName);

            $PREPARE a_id2 FROM $stmt;
            $EXECUTE a_id2 INTO $s_mins_stl
                          USING $iclaim, $iins_type, $iclose_type;
            if( SQLCODE == SQLNOTFOUND )
            {
                s_mins_stl = 0;
            }

         }
         $CLOSE cur_2;
         $FREE  cur_2;

         car903_print_body();

     }
     $CLOSE cur1;
      $FREE  cur1;

   } /*end of 3'database*/

   return M_CM_OK;
   
errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
 }
/*-------------------------------------------------------------------*/
void car903_print_body()
{ char str[13];

 rgu_put_body_string(2,branch,LEFT);
 rgu_put_body_string(2,iclaim,LEFT);
 rgu_put_body_string(2,nname,LEFT);
 rgu_put_body_string(2,iins_type,LEFT);
 rfmtlong(mins_app,"---,---,---&",str);
 rgu_put_body_string(2,str,LEFT);
 rfmtlong(s_mins_stl,"---,---,---&",str);
 rgu_put_body_string(2,str,LEFT);
 rgu_put_body_string(2,iclose_type,LEFT);
 rfmtlong(mins_stl,"---,---,---&",str);
 rgu_put_body_string(2,str,LEFT);
 rgu_put_body_string(2,dclose,LEFT);
 rgu_put_body(2);
 max_cnt++;
}
/*------------------------------------------------------end of program*/
