/************************************************/
/*                                              */
/*   PROGRAM : ca1007q01s.ec                    */
/*                                              */
/************************************************/

#include <stdio.h>

#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "carmsgs.h"
#include "rinmsgs.h"
#include "car_equip.h"
#include "safeclib.h"

$include "ply_ins_assured.h";
$include sqlca;
$include decimal.h;
#define MAXDB 15
#define EQUAL(s1,s2)            !strcmp(s1,s2)
#define TRUE  1
#define FALSE 0
#define SUCCESS 1

#define _TONY860619

extern struct sEquip *IfirstEquip, *IcurrEquip, *IlastEquip, *IEquip_ptr;
$char   userid[11],sMsg[512];
char     sColumn[21], sTable[21], sDbname[21], v_sMsg[1512];
char   sTmpcode[6];
int	   iTmpcode;
long    rtncode=0;
$int    iUnDeny;
$char   sStmt[4096];
struct PLY_INS_ASSURED *get_ply_ins_assured();
$int iCountDeny,iCountFunsale;

/*********************************************************************/
long car1007(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
$char DBName[5];
    long rtncode;
    long car1007_multiple_query1();

    char option;

    printf("##### car1007 begin\n");

    cm_buf_init(command);
    cm_buf_get("%c",&option);
    printf("option[%c]\n",option);

    switch(option)
    {
         case '1': 
                  rtncode=car1007_multiple_query1(reply);
                  break;
         default :
               return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
    }
    return(rtncode);
}

/*********************************************************************/
long car1007_multiple_query1(reply)
serverReply reply;
{
   /* standard defined host variables */
   $char DBName[5];
   /* end of standard host var */

   $char isign[31],ipolicy[21],iendorse[21],inum1[21],iofficer[11],nofficer[11],icreate[11],ncreate[11];
   $char iupcomp[2],dcreate[11],dclose[11],ddate[11],nremark[256],nassured[121],itag[13],nleader[11],dply_begin[11],nquote[41];
   $char iclass[2],date_bgn[10],date_end[10],iquota_2[3],dbgn[11],dend[11];
   $char nclass[51];
   $char stmt[4096],stmt_date[64],stmt_quota[32];
   $char fall[2];
   $char swhere[101];

   /* standard defined data */
   char tmpbuf[10000];
   int  count=0,repbuf_len=0,tmp_len=0,replycnt=0;
   int  i,total_count=0,fFound;
   long lTmp;
   /* end of standard data */
   
   cm_buf_get("%s %s",DBName, userid);
   cm_buf_get("%s %s %s %s %s",isign, iclass, date_bgn, date_end, iquota_2);
   
   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False)
       return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

   printf("car1007-->flag1\n");

   $select case when iquota[1,4] in ('2206','3201','4302') then 'Y' else 'N' end case, iupcomp
      into $fall, $iupcomp
      from officer
     where iofficer = $userid;

   strcpy( swhere, " ");
   if( fall[0] == 'N')
       sprintf_s(swhere, sizeof swhere, " AND iupcomp = '%s'", iupcomp);
   
   if (strcmp(iclass,"7") == 0)
   {
   	if (strcmp(date_bgn,"*") == 0 || strcmp(date_end,"*") == 0)
       		sprintf_s(stmt_date, sizeof stmt_date, " ");
   	else
   	{
       		strcpy( dbgn,cm_to_infdate(date_bgn) );
       		strcpy( dend,cm_to_infdate(date_end) );
       		sprintf_s(stmt_date, sizeof stmt_date, " AND dcreate between '%s' and '%s' ",dbgn,dend );
   	}   
   }
   else
   {
   	
   	if (strcmp(date_bgn,"*") == 0 || strcmp(date_end,"*") == 0)
       		sprintf_s(stmt_date, sizeof stmt_date, " ");
   	else
   	{
       		strcpy( dbgn,cm_to_infdate(date_bgn) );
       		strcpy( dend,cm_to_infdate(date_end) );
       		sprintf_s(stmt_date, sizeof stmt_date, " AND dclose between '%s' and '%s' ",dbgn,dend );
   	}   	
   }
   
   if (strcmp(iquota_2,"*") == 0 )
       sprintf_s(stmt_quota, sizeof stmt_quota, " ");
   else
       sprintf_s(stmt_quota, sizeof stmt_quota, " AND ipolicy[1,2] = '%s' ",iquota_2);

   sprintf_s(stmt, sizeof stmt, "SELECT trim(isign)||':'||(select nname from officer where iofficer = a.isign),"
                 " iclass||case when iclass = 1 then ':�C�L���' "
                 " when iclass = 2 then ':�ɦL�O��' "
                 " when iclass = 3 then ':�h�O��楼�n���h�O��I���(cmn101)' "
                 " when iclass = 4 then ':��楼�鵲' "
                 " when iclass = 5 then ':�ݦC�L�j���I�M��' "
                 " when iclass = 6 then ':�j��P���N���ؤ���' "
                 " when iclass = 7 then ':�����O���' "    
                 " end case,"
                 " ipolicy,iendorse,inum1,iofficer,nofficer,icreate,ncreate,iupcomp, "
                 " dcreate,dclose,ddate,nremark,nassured,itag,nleader,dply_begin, " 
                 " nvl((select nbranch from sa_branch_type where ibranch = a.iquota),'') "
                 "  FROM ca_isign_note a"
                 " WHERE isign matches '%s' "
                 "   AND iclass::CHAR(1) matches '%s' "
                 "   %s %s %s", isign, iclass, swhere, stmt_date, stmt_quota);

   printf("stmt[%s]\n", stmt);  
   $PREPARE q_cur1_cursor FROM :stmt;
   $DECLARE q_cur1 CURSOR FOR q_cur1_cursor;
   $OPEN q_cur1;

   printf("car1007-->flag2\n");

   for(;;)
   {
       EXEC SQL FETCH q_cur1 INTO $isign,$nclass,$ipolicy,$iendorse,$inum1,$iofficer,$nofficer,$icreate,$ncreate,$iupcomp,$dcreate,$dclose,$ddate,$nremark,$nassured,$itag,$nleader,$dply_begin,$nquote ;
       if (SQLCODE == SQLNOTFOUND) break;

       cm_buf_init(tmpbuf);
       if (count == 0)
       {
           cm_buf_res_msg();          /* reserve for MsgCode and count */
           cm_buf_res_count();
       }
       printf("car1007-->flag3\n");

       cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",isign,nclass,ipolicy,iendorse,inum1,iofficer,nofficer,icreate,ncreate,iupcomp,dcreate,dclose,ddate,nremark,nassured,itag,nleader,dply_begin,nquote);
       tmp_len = cm_buf_len(tmpbuf);
       if (tmp_len + repbuf_len < 8000 )   /* buffer size less than 4K */
       {
           memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
           repbuf_len += tmp_len;
           count++;
       }
       else                               /* more than 4K, send to client side */
       {
           memcpy(&ReplyBuf[repbuf_len], tmpbuf, tmp_len);
           repbuf_len += tmp_len;

           for( lTmp=0;lTmp<=4000000;lTmp++){};  /* �n�y�L���𣸨Ǯɶ�,���Mclient�|�|��� */

           cm_buf_init(ReplyBuf);
           cm_buf_put_msg(M_CM_OK);
           cm_buf_put_count(count);
           if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
           {
                EXEC SQL CLOSE q_cur1;
                EXEC SQL FREE  q_cur1;
                return apiRC;
           }
           else               /* clear ReplyBuf and count to start all over again */
           {
                replycnt++;
                if (replycnt == 50)   /* more than 30K, client cannot display,error */
                {
                    sleep(1);
                    cm_buf_init(ReplyBuf);
                    cm_buf_put("%l",M_CM_OUT_SPACE);
                    tmp_len = cm_buf_len(ReplyBuf);
                    if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)== False)
                            return apiRC;
                    return M_CM_OUT_SPACE;
                }
                ReplyBuf[0] = '\0';
                count = 0;
                cm_buf_init(ReplyBuf);
                cm_buf_res_msg();           /* reserve for MsgCode and count */
                cm_buf_res_count();
                repbuf_len = cm_buf_len(ReplyBuf);
                count++;
           }
       }
   } /* for loop */

   EXEC SQL CLOSE q_cur1;
   EXEC SQL FREE  q_cur1;

   printf("replycnt[%d]\n", replycnt);

   if (count > 0)   /* break out, at least one record is selected */
   {
       sleep(1);
       cm_buf_init(ReplyBuf);
       cm_buf_put_msg(M_CM_OK);
       cm_buf_put_count(count);
       if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
          return apiRC;

       printf("car1007-->flag4\n");

       return api_OKComplete;
   }
   else            /* break out, not any row is found */
   {
       return exitsub(reply,M_CA_NOREC_ERR) ? M_CA_NOREC_ERR : apiRC;  
   }

errexit:
   printf("SOLERR:%s\n",sqlca.sqlerrm);
   return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/******************************************************************************/
