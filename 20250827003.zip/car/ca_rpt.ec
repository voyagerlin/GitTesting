#include <stdio.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include <malloc.h>

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "print.h"
#include "is_def.h"

#include "carmsgs.h"
#include "commsgs.h"
#define MAX_ROW 60
#define MAX_ROW_OLD 21
struct lin
{
  int no;
  int pos[MAX_ROW];
  char *pp[MAX_ROW];
};

struct lin_old
{
	int no;
	int pos[MAX_ROW_OLD];
	char *pp[MAX_ROW_OLD];
};

void clr_row(ll)
struct lin *ll;
{
  ll->no=0;
}

void add_row(ll,cc,pos)
struct lin *ll;
char *cc;
int pos;
{	
  ll->pp[ll->no]=cc;
  ll->pos[ll->no]=pos;
  (ll->no)++;
  if (ll->no >=MAX_ROW )
  {
    printf("add too many row\n");
    exit(1);
  }
}

void show_row(ll)
struct lin *ll;
{
  int i;
  for(i=0;i<ll->no;i++)
    printf("NEW[%d:%s]",i,ll->pp[i]);
  printf("\n");
}

void put_row(bas,ll)
int bas;
struct lin *ll;
{
  int i,j;
  show_row(ll);
  for(i=0;i<ll->no;i++)
  { 
    printf("new bas[%d]no[%d]:",bas,i);
    rgu_put_body_string(bas,ll->pp[i],ll->pos[i]);
    printf("new bas[%d]no[%d]\n",bas,i);
  }
  rgu_put_body(bas);
}

void put_free_data(bas,high,page,nline,first_flag)
int bas;
int high;
struct lin page[];
int nline;
int first_flag;
{
  int i;
  
  
  for(i=0;i<high;i++)
  {
  	 printf(" NEW----------------- i[%d]   , first_flag[%d]\n", i, first_flag);
    if((i==2) && (first_flag == 1 ))
    {  printf("********************  do nothing ************************************\n");   }
    else
    {
     if(page[i].no==0)
     {  rgu_put_body(nline);  }
     else
     {  put_row(bas+i,&page[i]);     }
    }
  }
}

/***********************************/
/* �t�X�«O�� */
void clr_row_old(ll)
struct lin_old *ll;
{
  ll->no=0;
}

void add_row_old(ll,cc,pos)
struct lin_old *ll;
char *cc;
int pos;
{	
  ll->pp[ll->no]=cc;
  ll->pos[ll->no]=pos;
  (ll->no)++;
  if (ll->no >=MAX_ROW_OLD )
  {
    printf("add too many row\n");
    exit(1);
  }
}

void show_row_old(ll)
struct lin_old *ll;
{
  int i;
  for(i=0;i<ll->no;i++)
    printf("OLD[%d:%s]",i,ll->pp[i]);
  printf("\n");
}

void put_row_old(bas,ll)
int bas;
struct lin_old *ll;
{
  int i,j;
  show_row_old(ll);
  for(i=0;i<ll->no;i++)
  { 
    printf("old_bas[%d]no[%d]:",bas,i);
    rgu_put_body_string(bas,ll->pp[i],ll->pos[i]);
    printf("_oldbas[%d]no[%d]\n",bas,i);
  }
  rgu_put_body(bas);
}

void put_free_data_old(bas,high,page,nline,first_flag)
int bas;
int high;
struct lin_old page[];
int nline;
int first_flag;
{
  int i;
  
  
  for(i=0;i<high;i++)
  {
  	 printf(" old----------------- i[%d]   , first_flag[%d]\n", i, first_flag);
    if((i==2) && (first_flag == 1 ))
    {  printf("********************  old do nothing ************************************\n");   }
    else
    {
     if(page[i].no==0)
     {  rgu_put_body(nline);  }
     else
     {  put_row_old(bas+i,&page[i]);     }
    }
  }
}
/* end of �B�z�«O�� */
