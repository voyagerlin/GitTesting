/**********************************************************************/
/*   program id   : ca310q01s.ec                                      */
/*   program name : ���C�L�O/�����Ӫ�                               */
/*   date written : 2007/01/10 by 950682                              */
/*   files        : ply_relation                                      */
/*                  officer                                           */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"

#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"
$include decimal;


int   count_db;
$char dentry[11],dentry_s[11];
$char ibranch[4];

$char itag_in[CA_TAG_NUM];
$char iengine_in[CA_ENGINE_NUM];
$char iassured_in[13];
$char payment[2];

$char chkComp[2]; /* 1020307002 C2 */
$char fcard_class1[2],fcard_class2[2],fcard_class3[2];

char  outputf[21];
$char userid[11];
$char DBName[05];
$char msgbuf[128];

DBinfo *list;
/*--------------------------------------------------------------------*/

main(argc, argv)
int argc;
char **argv;
{
    int rc;

    batchinit();
    strcpy(DBName,    	isNULLstr(argv[1]));
    strcpy(userid,    	isNULLstr(argv[2]));
    strcpy(dentry_s,  	isNULLstr(argv[3]));
    strcpy(dentry,    	isNULLstr(argv[4]));
    strcpy(ibranch,   	isNULLstr(argv[5]));
    strcpy(chkComp,   	isNULLstr(argv[6]));  /* 1020307002 C2 */
    strcpy(itag_in,   	isNULLstr(argv[7]));
    strcpy(iengine_in,	isNULLstr(argv[8]));
    strcpy(iassured_in,	isNULLstr(argv[9]));
    strcpy(payment,   	isNULLstr(argv[10]));
    strcpy(fcard_class1,isNULLstr(argv[11]));
    strcpy(fcard_class2,isNULLstr(argv[12]));
    strcpy(fcard_class3,isNULLstr(argv[13]));
    strcpy(outputf,   	isNULLstr(argv[14]));

printf("dentry_s[%s]dentry[%s];;ibranch[%s];itag_in[%s];iengine_in[%s];iassured_in[%s];\n",dentry_s,dentry,ibranch,itag_in,iengine_in,iassured_in);
printf("fcard_class1[%s]fcard_class2[%s]fcard_class3[%s]\n",fcard_class1,fcard_class2,fcard_class3);
    /*rc = car630_get_db();
    if (rc != M_CM_OK)
       return rc;*/

    /*prepare data for report*/
    rc = car310_prepare_data();
    if (rc != M_CM_OK)
       return rc;

    /*build report - ����*/
    rc = car310_build();
    if (rc != M_CM_OK) {
       return rc;
    }
}

/*--------------------------------------------------------------------*/
long car310_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }

   if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
      if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
         return M_CM_NOT_DBLIST;
   }

   return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/
long car310_prepare_data()
{
   /* Variables for db data */
   $char ipolicy[21],nassured[21],itag[CA_TAG_NUM],icard[21],iengine[CA_ENGINE_NUM],iassured[13];
   $long dply_begin = 0,dply_end = 0,dentry_db,dentry_s_db,dedr_begin = 0;
   $int receive = 0,detail = 0,ciphers = 0,dwork = 0;
   $long mprem = 0;
   $char iofficer[10],iofficer_name[11],icorps_name[11], iendorse[21], ientry[11], nentry[11],sWhere[256],sWhere1[256],sWhere2[256];
   $char iquota[41],ileader[11],pay[10],ipolicy1[21],ipolicy2[6],ipre_end[21];
   /* End of declare for db data */
   $char  dentry_cond[11],dentry_s_cond[11];
   $char  stmt[2048];
   $char  stmt_tmp[1024];


   strcpy(dentry_cond,cm_to_infdate(dentry));
   strcpy(dentry_s_cond,cm_to_infdate(dentry_s));


   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == FALSE)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return FAIL;
   }

printf("prepared data, dentry_cond[%s]dentry_s_cond[%s]\n",dentry_cond,dentry_s_cond);

   /* Create table car310_tmp1 */
   sprintf_s(stmt_tmp, sizeof stmt_tmp,"create temp table car310_tmp1  "
	"( "
	 "ipolicy    char(20), "
         "iendorse   char(20), "
         "ipre_end   char(20), "
	 "nassured   char(20), "
	 "iassured   char(12), "
	 "itag       char(%d), "
	 "iengine    char(%d), "
	 "dply_begin date, "
	 "dply_end   date, "
	 "dedr_begin date, "
	 "dwork	    integer  default 0, "
	 "mprem      integer  default 0, "
	 "iofficer  char(10), "
	 "iofficer_name   char(10), "
	 "icorps_name      char(10), "
	 "dentry     date, "
         "ientry     char(10), "
         "nentry     char(10), "
         "icard      char(20), "
         "iquota     char(40), "
         "ileader    char(10), "
         "payment  varchar(13) "
	")with no log;",CA_TAG_NUM-1,CA_ENGINE_NUM-1);
     $PREPARE stmp FROM $stmt_tmp;
     $EXECUTE stmp;

printf("\nitag�G%s\n",itag_in);
	/* select matching data */
	/*for(k=0;k<count_db;k++){*/
	 /* 1020307002 C2 */
        if( chkComp[0] == '1')
        {
            strcpy( sWhere, " and ((a.dpolicy IS NULL and fprint = '0') or (a.fcard_class = '1' and fprint = '0' and a.dentry > '04/15/2013'))");
            strcpy( sWhere1, " and (a.dendorse IS NULL and fprint = '0')");
        }
        else
        {
            strcpy( sWhere, " and a.dpolicy IS NULL and a.fcard_class = '2' and fprint = '0' ");
            strcpy( sWhere1, " and a.dendorse IS NULL and a.fcard_class = '2' and fprint = '0' ");
        }
        
        if(strcmp(fcard_class1,"1") == 0 && strcmp(fcard_class2,"1") == 0)
            strcpy( sWhere2, " ");
        else if(strcmp(fcard_class1,"1") == 0)
            strcpy( sWhere2, "and a.fcard_class = '1' ");
        else
            strcpy( sWhere2, "and a.fcard_class = '2' ");

printf("sWhere2[%s]\n",sWhere2);

	/******************************�O��******************************/
	if(strcmp(fcard_class1,"1") == 0 || strcmp(fcard_class2,"1") == 0)
	{
		sprintf_s(stmt, sizeof stmt,
			"select a.ipolicy,' ',c.ipre_end,b.nassured[1,20],b.iassured,b.itag,b.iengine,a.dply_begin,a.dply_end, "
			"(a.mdmg_prem+a.mlia_prem),"
			"a.iofficer, "
			"(select nname from officer where iofficer=a.iofficer), "
			"(select nname from officer where iofficer=a.icorps), "
			"a.dentry, a.ientry, (select nname from officer where iofficer = a.ientry), a.icard,"
			"(select nbranch from sa_branch_type where ibranch=a.iquota), "
			"(select nname from officer where iofficer=a.ileader) "
			"from ply_relation a, policy b, cm_pre_receive c "
			"where a.dentry between '%s'and '%s' "
			" %s %s"
			"and a.ipolicy[1,13] = c.ipolicy1 "
			"and a.ipolicy[14,20] = c.ipolicy2 "
			"and a.ipolicy = b.ipolicy "
			"and b.itag matches '%s' "
			"and b.iengine matches '%s' "
			"and b.iassured matches '%s' "
			"and b.ipolicy[1,3] matches '%s' "
	                "order by 1",dentry_s_cond,dentry_cond,sWhere,sWhere2,itag_in,iengine_in,iassured_in,ibranch);
		printf("stmt[%s]\n", stmt);
	        $PREPARE pre1 FROM $stmt;
	        $DECLARE cur_pre1 CURSOR for pre1;
	
	
	      	$OPEN cur_pre1;
	      	while(1)
	      	{
	         	$FETCH cur_pre1 INTO $ipolicy,$iendorse,$ipre_end,$nassured,$iassured,$itag,$iengine,$dply_begin,$dply_end,
	         			$mprem,$iofficer,$iofficer_name,$icorps_name,$dentry_db,$ientry,$nentry,$icard,$iquota,$ileader;
	
	         	if(SQLCODE == SQLNOTFOUND) break;
	

	printf("dply_begin[%ld],dply_end[%ld]\n",dply_begin,dply_end);
	printf("ipolicy[%s],ibranch[%s]\n",ipolicy,ibranch);
	printf("ipre_end[%s]\n",ipre_end);
	         	/**�P�_���O�X�浲�G  ***********/
		     strcpy(ipre_end,trim(ipre_end));
		     strncpy(ipolicy1,trim(ipolicy),CAR_POLICY_LEN);
	  	     ipolicy1[CAR_POLICY_LEN]=0;
	  	     strcpy(ipolicy2,&ipolicy[CAR_POLICY_LEN]);
	  	     strcpy(ipolicy1,trim(ipolicy1));
	  	     strcpy(ipolicy2,trim(ipolicy2));
	
	printf("ipolicy1[%s]ipolicy2[%s]\n",ipolicy1,ipolicy2);
	
	  sprintf_s(stmt, sizeof stmt,"SELECT count(*), "
	               "       NVL((select count(*) from ao_prercv_detail x where x.ipre_rcv = a.ipre_rcv and x.iins_kind = a.iins_kind and x.ipre_end = a.ipre_end),0),"
		       "       NVL((select count(*) from ao_prercv_pass x where x.ipre_rcv = a.ipre_rcv and x.iins_kind = a.iins_kind and x.ipre_end = a.ipre_end),0)   "
	               "  from cm_pre_receive a "
		       " where a.fstatus<>90    "
		       "   and a.iendorse=' '   "
		       "   and a.ipolicy1 = '%s'    "
		       "   and a.ipolicy2 = '%s'    "
		       "   and a.ipre_end = '%s'    "
		       "   group by 2,3",ipolicy1,ipolicy2,ipre_end);
	
	printf("stmt[%s]\n", stmt);
	
		$PREPARE pre2 FROM $stmt;
	        $DECLARE cur_pre2 CURSOR for pre2;
	        $OPEN cur_pre2;
	        $FETCH cur_pre2 INTO $receive,$detail,$ciphers;
	        $CLOSE cur_pre2;
	        $FREE cur_pre2;
	
	printf("receive[%d]detail[%d]ciphers[%d]\n",receive,detail,ciphers);
	printf("ipre_end[%s]\n",ipre_end);
	
		/*�ͮī�u�@�Ѽ�*/
		$SELECT count(*)
		   INTO $dwork
		   FROM cm_wrktbl 
		  WHERE dwork > $dply_begin
		    AND dwork <= today 
		    AND fwork = '0' 
		 ORDER BY 1;

		        if(strcmp(payment,"A")==0||strcmp(payment,"T")==0)
		        {
		   	    if (receive==1&&detail>0&&ciphers>0)
			    {
			        printf("print ibranch => ipolicy[%s];ibranch[%s]\n",ipolicy,ibranch);
			        strcpy(pay,"�w���O");
			        printf("�w���O\n");
			      strcpy(iofficer,trim(iofficer));
			      printf("iofficer[%s]\n",iofficer);
		         	          	$INSERT INTO car310_tmp1
		          		      		(ipolicy,iendorse,ipre_end,nassured,iassured,itag,iengine,dply_begin,dply_end,dedr_begin,dwork,mprem,iofficer,
					       		iofficer_name,icorps_name,dentry,ientry,nentry,icard,iquota,ileader,payment)
					   	VALUES
		          		      		($ipolicy,$iendorse,$ipre_end,$nassured,$iassured,$itag,$iengine,$dply_begin,$dply_end,$dedr_begin,$dwork,$mprem,$iofficer,
					       		$iofficer_name,$icorps_name,$dentry_db,$ientry,$nentry,$icard,$iquota,$ileader,$pay);
			    }
		        }
			if (strcmp(payment,"A")==0||strcmp(payment,"F")==0)
			{
			    if (receive==1&&detail>0&&ciphers==0)
			    {
			        printf("print ibranch => ipolicy[%s];ibranch[%s]\n",ipolicy,ibranch);
			        strcpy(pay,"���O������");
			        printf("���O������\n");
		         	           	$INSERT INTO car310_tmp1
		          		      		(ipolicy,iendorse,ipre_end,nassured,iassured,itag,iengine,dply_begin,dply_end,dedr_begin,dwork,mprem,iofficer,
					       		iofficer_name,icorps_name,dentry,ientry,nentry,icard,iquota,ileader,payment)
					   	VALUES
		          		      		($ipolicy,$iendorse,$ipre_end,$nassured,$iassured,$itag,$iengine,$dply_begin,$dply_end,$dedr_begin,$dwork,$mprem,$iofficer,
					       		$iofficer_name,$icorps_name,$dentry_db,$ientry,$nentry,$icard,$iquota,$ileader,$pay);
			    }
			    else if ((receive==1&&detail==0&&ciphers==0) || receive==0)
			    {
			         	strcpy(pay,"�����O");
			         	printf("�����O\n");
			         	        $INSERT INTO car310_tmp1
		          		      		(ipolicy,iendorse,ipre_end,nassured,iassured,itag,iengine,dply_begin,dply_end,dedr_begin,dwork,mprem,iofficer,
					       		iofficer_name,icorps_name,dentry,ientry,nentry,icard,iquota,ileader,payment)
					   	VALUES
		          		      		($ipolicy,$iendorse,$ipre_end,$nassured,$iassured,$itag,$iengine,$dply_begin,$dply_end,$dedr_begin,$dwork,$mprem,$iofficer,
					       		$iofficer_name,$icorps_name,$dentry_db,$ientry,$nentry,$icard,$iquota,$ileader,$pay);
	                    }
			 }
	
	          }
	          $CLOSE cur_pre1;
	          $FREE cur_pre1;
	}


     	/******************************���******************************/
	if(strcmp(fcard_class3,"1") == 0)
	{
		sprintf_s(stmt, sizeof stmt,
			"select a.ipolicy,a.iendorse,' ',b.nassured[1,20],b.iassured,b.itag,b.iengine,b.dply_begin,b.dply_end, "
			"(a.medrdmg_prem+a.medrlia_prem), "
			"a.iofficer, "
			"(select nname from officer where iofficer=a.iofficer), "
			"(select nname from officer where iofficer=a.icorps), "
			"a.dentry, a.iedr_examiner, (select nname from officer where iofficer = a.iedr_examiner), a.icard,"
			"(select nbranch from sa_branch_type where ibranch=a.iquota), "
			"(select nname from officer where iofficer=a.ileader) "
			"from edr_relation a, endorsement b "
			"where a.dentry between '%s'and '%s' "
			" %s "
			"and b.itag matches '%s' "
			"and b.iengine matches '%s' "
			"and b.iassured matches '%s' "
			"and a.ipolicy[1,3] matches '%s' "
			"and a.iendorse = b.iendorse "
	                "and a.iendorse not like '%%CVP%%' "
			"order by 1",dentry_s_cond,dentry_cond,sWhere1,itag_in,iengine_in,iassured_in,ibranch);
		printf("stmt[%s]\n", stmt);
	        $PREPARE pre3 FROM $stmt;
	        $DECLARE cur_pre3 CURSOR for pre3;
	
	
	      	$OPEN cur_pre3;
	      	while(1)
	      	{
	         	$FETCH cur_pre3 INTO $ipolicy,$iendorse,$ipre_end,$nassured,$iassured,$itag,$iengine,$dply_begin,$dply_end,
	         			$mprem,$iofficer,$iofficer_name,$icorps_name,$dentry_db,$ientry,$nentry,$icard,$iquota,$ileader;
	
	         	if(SQLCODE == SQLNOTFOUND) break;
	
	                strcpy(iendorse,trim(iendorse));

	         	 $select dedr_begin
	         	    into $dedr_begin
	         	    from edr_relation
	         	   where iendorse = $iendorse;
	
	printf("dply_begin[%ld],dply_end[%ld]\n",dply_begin,dply_end);
	printf("ipolicy[%s],ibranch[%s]\n",ipolicy,ibranch);
	printf("ipre_end[%s]\n",ipre_end);
	         	/**�P�_���O�X�浲�G  ***********/

	printf("iendorse[%s]\n",iendorse);
	
		sprintf_s(stmt, sizeof stmt,"SELECT count(*), "
	               "       NVL((select count(*) from ao_prercv_detail x where x.ipre_rcv = a.ipre_rcv and x.iins_kind = a.iins_kind and x.ipre_end = a.ipre_end),0),"
		       "       NVL((select count(*) from ao_prercv_pass x where x.ipre_rcv = a.ipre_rcv and x.iins_kind = a.iins_kind and x.ipre_end = a.ipre_end),0)   "
	               "  from cm_pre_receive a  "
		       " where a.fstatus<>90     "
		       "   and a.iendorse = '%s' "
		       "   group by 2,3",iendorse);
	
		$PREPARE pre4 FROM $stmt;
	        $DECLARE cur_pre4 CURSOR for pre4;
	        $OPEN cur_pre4;
	        $FETCH cur_pre4 INTO $receive,$detail,$ciphers;
	        $CLOSE cur_pre4;
	        $FREE cur_pre4;
	
	printf("receive[%d]detail[%d]ciphers[%d]\n",receive,detail,ciphers);

		/*�ͮī�u�@�Ѽ�*/
		$SELECT count(*)
		   INTO $dwork
		   FROM cm_wrktbl 
		  WHERE dwork > $dply_begin
		    AND dwork <= today 
		    AND fwork = '0' 
		 ORDER BY 1;
	
		        if(strcmp(payment,"A")==0||strcmp(payment,"T")==0)
		        {
		   	    if (receive==1&&detail>0&&ciphers>0)
			    {
			        printf("print ibranch => ipolicy[%s];ibranch[%s]\n",ipolicy,ibranch);
			        strcpy(pay,"�w���O");
			        printf("�w���O\n");
			      strcpy(iofficer,trim(iofficer));
			      printf("iofficer[%s]\n",iofficer);
		         	          	$INSERT INTO car310_tmp1
		          		      		(ipolicy,iendorse,ipre_end,nassured,iassured,itag,iengine,dply_begin,dply_end,dedr_begin,dwork,mprem,iofficer,
					       		iofficer_name,icorps_name,dentry,ientry,nentry,icard,iquota,ileader,payment)
					   	VALUES
		          		      		($ipolicy,$iendorse,$ipre_end,$nassured,$iassured,$itag,$iengine,$dply_begin,$dply_end,$dedr_begin,$dwork,$mprem,$iofficer,
					       		$iofficer_name,$icorps_name,$dentry_db,$ientry,$nentry,$icard,$iquota,$ileader,$pay);
			    }
		        }
			if (strcmp(payment,"A")==0||strcmp(payment,"F")==0)
			{
			    if (receive==1&&detail>0&&ciphers==0)
			    {
			        printf("print ibranch => ipolicy[%s];ibranch[%s]\n",ipolicy,ibranch);
			        strcpy(pay,"���O������");
			        printf("���O������\n");
		         	           	$INSERT INTO car310_tmp1
		          		      		(ipolicy,iendorse,ipre_end,nassured,iassured,itag,iengine,dply_begin,dply_end,dedr_begin,dwork,mprem,iofficer,
					       		iofficer_name,icorps_name,dentry,ientry,nentry,icard,iquota,ileader,payment)
					   	VALUES
		          		      		($ipolicy,$iendorse,$ipre_end,$nassured,$iassured,$itag,$iengine,$dply_begin,$dply_end,$dedr_begin,$dwork,$mprem,$iofficer,
					       		$iofficer_name,$icorps_name,$dentry_db,$ientry,$nentry,$icard,$iquota,$ileader,$pay);
			    }
			    else if ((receive==1&&detail==0&&ciphers==0) || receive==0)
			    {
			         	strcpy(pay,"�����O");
			         	printf("�����O\n");
			         	        $INSERT INTO car310_tmp1
		          		      		(ipolicy,iendorse,ipre_end,nassured,iassured,itag,iengine,dply_begin,dply_end,dedr_begin,dwork,mprem,iofficer,
					       		iofficer_name,icorps_name,dentry,ientry,nentry,icard,iquota,ileader,payment)
					   	VALUES
		          		      		($ipolicy,$iendorse,$ipre_end,$nassured,$iassured,$itag,$iengine,$dply_begin,$dply_end,$dedr_begin,$dwork,$mprem,$iofficer,
					       		$iofficer_name,$icorps_name,$dentry_db,$ientry,$nentry,$icard,$iquota,$ileader,$pay);
	                    }
			 }
	
	          }
	          $CLOSE cur_pre3;
	          $FREE cur_pre3;
	}

     return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/


long car310_build()

{
   int rc;
    char    sfilename[81],stitle[2048],stmt[2048];

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(sfilename,"���C�L�O/�����Ӫ�[CAR310]");

    strcpy(stitle,"\t�{���N��:CAR310\���C�L�O/�����Ӫ�\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");

    strcat(stitle,"\t�O�渹�X\t��(�d)��\t��渹�X\t�t�B���\t�Q�O�I�H\t�Q�O�I�HID\t�P�Ӹ��X\t�������X\t�O�I�_��\t");
    strcat(stitle,"�O�I�״�\t���ͮĤ�\t�ͮī�u�@�Ѽ�\tñ/���O�O\t�g��N��\t�g��H��\t��J�H��id\t��J�H��\t");
    strcat(stitle,"��J���\t�~�Z���\t�޲z�H\tú�ڪ��A\t");

    strcpy(stmt,"select ipolicy,icard,iendorse,ipre_end,nassured,iassured,itag,iengine,dply_begin,dply_end,dedr_begin,dwork,mprem,iofficer,iofficer_name,"
    		"ientry,nentry,dentry,iquota,ileader,payment "
    		" from car310_tmp1");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);
    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;

/*}*/}
