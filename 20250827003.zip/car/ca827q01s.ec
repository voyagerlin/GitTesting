/************************************************/
/*                                              */
/*   PROGRAM : ca827q01s.ec                     */
/*                                              */
/*                                              */
/************************************************/
#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"

#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"

/*------------------------------------*/

$char ibranch[3], nchi_abv[13];
$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width = 0;

char SysTm[ N_TM+1];
char BodyFile[ N_FILE+1];
char TitleFile[ N_FILE+1];
char outputf[ N_FILE+1];
char yy[4], mm[3], dd[3];
char yy1[4], mm1[3], dd1[3];
char yy2[4], mm2[3], dd2[3];

static int pagenum=1;
static int linecnt=0;

int  max_count, errCode;
int  tmp_len;
int  copies;
int miy;

long car827_build();
void car827_title();
void car827_body();

/*----------------------------------------------------------------------------*/
$char DBName[5];
$char c_yymmbgn[17],c_yymmend[17];
$char countA[3];
char userid[11];
char FormTp[N_FILE+1];
$int  iCnt, iTot;
$char stmt[2048];

main(argc,argv)
int argc;
char **argv;
{
   char dummy[20],option;
   char prnTitleFile[N_FILE+1], prnBodyFile[N_FILE+1], prnDev[N_NAME+1];
   char tmpcmd[255],hostname[N_NAME+1];
   long rtncode;

   int rc;
   batchinit();

   strcpy(DBName,isNULLstr(argv[1]));
   strcpy(userid,isNULLstr(argv[2]));

   strcpy(c_yymmbgn,isNULLstr(argv[3]));
   strcpy(c_yymmend,isNULLstr(argv[4]));
   strcpy(countA,isNULLstr(argv[5]));

   strcpy(outputf,isNULLstr(argv[6]));
   if(c_yymmbgn[0]=='*')strcpy(c_yymmbgn,"80/01/01");
   if(c_yymmend[0]=='*')strcpy(c_yymmend,"99/12/31");
   if(c_yymmend[0]==' ')strcpy(c_yymmend,c_yymmbgn);

printf("outputf[%s]\n",outputf);
printf("yymmbgn[%s]\n",c_yymmbgn);
printf("yymmend[%s]\n",c_yymmend);

   iTot = 0;
   car827_build();

      rtncode=create_sign_form("car827",BodyFile,Width);
      if (rtncode != 0)
        {
          EWRITE(userid,rtncode,"Error on creating sign form");
          printf("Error on creating sign form, rtncode=%d\n",rtncode);
          return;
        }

  if((rc=save_form_info(F_BLK1,"CA",827,userid,FormTp,max_count,outputf))<0)
    EWRITE(userid,rc,"save form info failure!");

}

/*----------------------------------------------------------------------------*/
long car827_build()
{
$char   TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];
$char   Ipolicy[21], nassured[121],dply_end[17],nname[21],itag[CA_TAG_NUM];
$int    tot_count = 0, cnt_mdmg, cnt_mlia;
$char   cc_yymmbgn[17],cc_yymmend[17];
$char   yymmbgn[17],yymmend[17], sTmpIbranch[3], tmp_policy[20];
char    tmpend[17],tmpbgn[17];
int     i_yy,i_mm;
int     i,j;
DBinfo  *list;



   if(db_select(DBName) == False)
   {
    EWRITE(userid,M_CM_DB_NOTOPEN,"M_CM_NOTOPEN");
    return 0;
   } 


   $WHENEVER SQLERROR GOTO errexit;
   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
           kTot_Col, kPgNum_Line, kWidth
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow, $ItemRow,
           $TotColumn, $PgLine, $Width
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 827;

   strcpy( TitleFmt,rtrim(TitleFmt));
   strcpy( BodyFmt,rtrim(BodyFmt));
   sprintf_s( TitleFile,21,"%s.ti",outputf);
   sprintf_s( BodyFile,21,"%s.bd",outputf);

   strcpy(yymmbgn, cm_to_infdate(c_yymmbgn));
   strcpy(yymmend, cm_to_infdate(c_yymmend));
printf("&&& yymmbgn:[%s] yymmend:[%s] &&&\n", yymmbgn, yymmend);

printf("&&& dpt:[%s], datebgn:[%s], dateend:[%s] &&&\n", countA, yymmbgn, yymmend);
   /* ***** title file ***** */
   rgu_init_report( TitleFmt,TitleFile);
   car827_title();
   rgu_finish_report();

   /* ***** body file ***** */
   rgu_init_report( BodyFmt,BodyFile);

  if((list=get_db_list(&i,DBName)) == (char*)0 )
     {
       EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
       return 0;
     }

  for(j=0;j<i;j++)
  {

        if(db_select(list[j].dbbranch) == False)
        {
        EWRITE(userid,M_CM_DB_NOTOPEN,"M_CM_NOTOPEN");
        return 0;
        }
        
        $DECLARE CUS1 CURSOR FOR 
          SELECT a.ipolicy,b.nassured,(SELECT nname FROM officer WHERE iofficer = c.iofficer),c.dply_end,count(unique a.iclaim),d.itag
            FROM settlement a inner join policy b
			on a.ipolicy = b.ipolicy
			inner join ply_relation c
			on b.ipolicy = c.ipolicy
			inner join adjustment_ply d
			on a.iclaim = d.iclaim
           WHERE a.ipolicy IN
               (
                 SELECT UNIQUE ipolicy
                   FROM settlement a, stl_ins_type b
                  WHERE a.fstl ='1'
                    AND a.dclose  BETWEEN $yymmbgn AND $yymmend
                    AND (msettle!=0 OR 
                         (SELECT NVL(SUM(e.mins_proc),0) 
                            FROM stl_ins_type e, insurance_type f 
                           WHERE e.iins_type=f.iins_type
                             AND e.iclaim=a.iclaim AND e.fstl=a.fstl AND e.iclose_type=a.iclose_type AND f.fins_grp IN ('1','2'))!=0 )
                    AND a.iclaim = b.iclaim
                    and a.fstl = b.fstl
                    and a.iclose_type = b.iclose_type
                    and b.iins_type in ('01','05','08','09','4A','4B','4C','4D','93','94','95','32','201','205','209','193','194','195','232')
               )
             AND fstl = '1'
             AND (msettle!=0 OR 
                  (SELECT NVL(SUM(e.mins_proc),0) 
                     FROM stl_ins_type e, insurance_type f 
                    WHERE e.iins_type=f.iins_type
                      AND e.iclaim=a.iclaim AND e.fstl=a.fstl AND e.iclose_type=a.iclose_type AND f.fins_grp IN ('1','2'))!=0 )
           GROUP  BY a.ipolicy,b.nassured,c.iofficer,c.dply_end,d.itag
           order by c.dply_end;
        $OPEN CUS1;
        while(1)
        {
            $FETCH CUS1 INTO $Ipolicy,$nassured,$nname,$dply_end,$tot_count,$itag;
            if( SQLCODE==SQLNOTFOUND) break;

            if (tot_count < atoi(trim(countA))) continue;

/*            $DECLARE CUS2 CURSOR FOR
              SELECT A.nassured,B.iofficer,B.dply_end
                FROM policy A,ply_relation B
               WHERE A.ipolicy=$Ipolicy
                 AND A.ipolicy=B.ipolicy
                ORDER BY 3 DESC;*/
			/*
			$DECLARE CUS2 CURSOR FOR
			select iclaim ,iadjuster,
			from settlement
			where ipolicy = $Ipolicy;


            $OPEN CUS2;
            while(1)
            {
                $FETCH CUS2 INTO $nassured,$iofficer,$dply_end;
                if(SQLCODE==SQLNOTFOUND) break;
                else
                {
                   $SELECT nname
                      INTO $nname
                      FROM officer
                     WHERE iofficer=$iofficer;
                   if(SQLCODE==SQLNOTFOUND) strcpy(nname," ");*/

                   nname[20]='\0';
                   nassured[16]='\0';
                   cnt_mdmg = 0;
                   cnt_mlia = 0;

                   sprintf_s(stmt,2048,"SELECT count(unique a.iclaim) \
                                   FROM settlement a, stl_ins_type b \
                                  WHERE a.ipolicy = '%s' \
                                    AND a.iclaim = b.iclaim \
                                    AND a.fstl = b.fstl \
                                    AND a.iclose_type = b.iclose_type \
                                    AND a.fstl = '1' \
                                    AND (msettle!=0 OR \
                                         (SELECT NVL(SUM(e.mins_proc),0) \
                                            FROM stl_ins_type e, insurance_type f \
                                           WHERE e.iins_type=f.iins_type \
                                             AND e.iclaim=a.iclaim AND e.fstl=a.fstl AND e.iclose_type=a.iclose_type AND f.fins_grp IN ('1','2'))!=0 ) \
                                    AND b.iins_type in ('01','05','08','09','201','205','209') \
                                               ",Ipolicy );

                   printf("stmt[%s]\n",stmt);

                   $PREPARE cnt_mdmg FROM $stmt;
                   $EXECUTE cnt_mdmg INTO $cnt_mdmg;

                   sprintf_s(stmt,2048,"SELECT count(unique a.iclaim) \
                                   FROM settlement a, stl_ins_type b \
                                  WHERE a.ipolicy = '%s' \
                                    AND a.iclaim = b.iclaim \
                                    AND a.fstl = b.fstl \
                                    AND a.iclose_type = b.iclose_type \
                                    AND a.fstl = '1' \
                                    AND (msettle!=0 OR \
                                         (SELECT NVL(SUM(e.mins_proc),0) \
                                            FROM stl_ins_type e, insurance_type f \
                                           WHERE e.iins_type=f.iins_type \
                                             AND e.iclaim=a.iclaim AND e.fstl=a.fstl AND e.iclose_type=a.iclose_type AND f.fins_grp IN ('1','2'))!=0 ) \
                                    AND b.iins_type in ('4A','4B','4C','4D','93','94','95','32','193','194','195','232') \
                                               ",Ipolicy );

                   printf("stmt[%s]\n",stmt);

                   $PREPARE cnt_mlia FROM $stmt;
                   $EXECUTE cnt_mlia INTO $cnt_mlia;

                   rgu_put_body_string(2, Ipolicy,1);
                   rgu_put_body_string(2, nassured,1);
                   rgu_put_body_string(2, nname,1);
                   rgu_put_body_string(2, itos(cnt_mdmg), 2);
                   rgu_put_body_string(2, itos(cnt_mlia), 2);
                   rgu_put_body_string(2, itos(tot_count), 2);
                   rgu_put_body_string(2, dply_end,1);
				   rgu_put_body_string(2, itag, 1);
                   rgu_put_body(2); max_count++;

/*                }

            }
            $CLOSE CUS2;
            $FREE CUS2;*/
        }
        $CLOSE CUS1;
        $FREE CUS1;
  }/**get_db_list***/
        rgu_put_body(3);  max_count++;
        rgu_finish_report();
         return 0;

errexit:
printf("SQLCODE[%d],ERR[%s]\n",SQLCODE,sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,"Error on SQL");
    return 0;
}

/*----------------------------------------------------------------------------*/
void car827_title()
{
   char yy[3], mm[3],dd[3];
   rgu_put_head_string(1, cm_get_sysd());   /* get_currdt */
   rgu_put_head_string(1, c_yymmbgn);
   rgu_put_head_string(1, c_yymmend);
   rgu_put_head();
}

