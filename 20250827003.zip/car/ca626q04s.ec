/*******************************************/
/*   �M�׽дک���--�����O�����ŦX�M�ש���  */
/*   PROGRAM : ca626q04s.ec                */
/*   DATE    : 2004/05/17                  */
/*   MODIFY  : yyyy/mm/dd                  */
/*   Checked for ����100�~�M��             */
/*******************************************/
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "carmsgs.h"
#include "is_def.h"
$include sqlca;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include "safeclib.h"

int     date_i;
$char   dbgn1[11], dend1[11],iprmt[11];
$char   dbgn_inf[11], dend_inf[11];
char    MsgCode[50],fply_close[2];
$char   Igroup[7],Ngroup[21];

$char   iquota[7],icard[21],ipolicy[21];
$char   nassured[25],dpolicy[11],dply_begin[11],ibrand[9];
$char   iengine[21],iissue_ym[7],ibig_office[10],ibig_office_c[11];
$char   itag[CA_TAG_NUM],nbrand[31],ipro_year[5];
$char   ibig_sales[11],nsales[11],iins_type[7],ioff_sales[4];
$char   ncomp[11],nbig[21],d_today[11];
$long   dply_bgn_long;
$char   nprmt[31],iofficer_1[2],ioff_chk[11],iagent[11];
$char   dprmt_bgn[11],dprmt_end[11],iprmt[11],iins_type_prmt[11];
$int    lofficer = 0,iremark = 0,ioff_chk_bgn = 0,ioff_chk_len = 0;
$int    qfield_all,qfield_chk,qyear,prmt_cnt = 0;
$char   fanother[2],iofficera_1[2],ioff_chka[11];
$int    lofficera = 0,iremarka,ioff_chk_bgna = 0,ioff_chk_lena = 0;
$char   iofficer[11],iofficer_c[11],ientry[11],ileader[11];
$char   ientry_c[11],ileader_c[11],cremark[2];
$char   napplicant[25],iapplicant[13];

DBinfo *list;
int   count_db;
$char DBName[05], iForm_Tp[03];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1];
char  outputf[N_FILE+1], userid[11];

char  msgbuf[100];
$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;

int  max_cnt;

long car6264_build1();
long car6264_body1();
void car6264_title();
void print_car6264_body1();

/*--------------------------------------------------------------------*/
car6264(DBName_h,userid_h,iprmt_h,dbgn1_h,dend1_h,date_h,outputf_h)
char *DBName_h,*userid_h,*iprmt_h,*dbgn1_h,*dend1_h,*date_h;
char *outputf_h;
{
   int rc;
   batchinit();

printf("begin car6264\n");
   strcpy(DBName,  DBName_h);
   strcpy(userid,  userid_h);
   strcpy(iprmt,   iprmt_h);
   strcpy(dbgn1,   dbgn1_h);
   strcpy(dend1,   dend1_h);
   date_i = atoi(date_h);
   strcpy(outputf, outputf_h);

   strcpy(dbgn_inf, cm_to_infdate(dbgn1));
   strcpy(dend_inf, cm_to_infdate(dend1));

   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False) {
       return M_CM_DB_NOTOPEN;
   }

   if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
      if (EWRITE(userid, M_CM_NOT_DBLIST) == True)
        return M_CM_NOT_DBLIST;
      return M_CM_OK;
   }

   rc = car6264_read_prmt();
   if (rc != M_CM_OK) {
      EWRITE(userid, rc,msgbuf);
      return rc;
   }

   max_cnt=0;
   rc = car6264_build1();
   if ( rc != M_CM_OK)  {
       EWRITE(userid, rc, " ");
       return rc;
   }

   return M_CM_OK;

errexit:
  sqlfatal();
  EWRITE(userid,SQLCODE,sqlca.sqlerrm);
  return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car6264_read_prmt()
{
$char  stmt[1024];
   $select nprmt,iofficer_1,lofficer,iremark,ioff_chk_bgn,
           ioff_chk_len,ioff_chk,iagent,qfield_all,qfield_chk,
           dprmt_bgn,dprmt_end,qyear,iins_type,fanother,
           iofficera_1,lofficera,iremarka,ioff_chk_bgna,
           ioff_chk_lena,ioff_chka
      into $nprmt,$iofficer_1,$lofficer,$iremark,$ioff_chk_bgn,
           $ioff_chk_len,$ioff_chk,$iagent,$qfield_all,$qfield_chk,
           $dprmt_bgn,$dprmt_end,$qyear,$iins_type_prmt,$fanother,
           $iofficera_1,$lofficera,$iremarka,$ioff_chk_bgna,
           $ioff_chk_lena,$ioff_chka
      from ca_promote
     where iprmt = $iprmt;
`
   if (SQLCODE==SQLNOTFOUND) {
      strcpy(msgbuf,"�d�L�M�׸��");
      return SQLCODE;
   }

   sprintf_s(stmt, sizeof stmt,"SELECT nbrand,ipro_year "
                "FROM ca_car_model  "
                "WHERE ibrand = ? "
                "ORDER BY ipro_year ");
   $PREPARE B_id FROM $stmt;
   $DECLARE curBX CURSOR FOR B_id;

   sprintf_s(stmt, sizeof stmt,"SELECT nname FROM officer WHERE iofficer = ? ");
   $PREPARE pre_name FROM $stmt;

   sprintf_s(stmt, sizeof stmt,"SELECT nname[1,10] FROM ca_big_office  "
           "WHERE fclass = '2' AND ibig_comp = ? ");
   $PREPARE pre_nsales FROM $stmt;

   sprintf_s(stmt, sizeof stmt,"SELECT nbranch FROM sa_branch_type  "
           "WHERE ibranch = ? ");
   $PREPARE pre_nbranch FROM $stmt;

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car6264_build1()
{
   $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];
   int    rc;
   $WHENEVER SQLERROR GOTO errexit;

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width, $iForm_Tp
      FROM Form
    WHERE ksys_grp = 'CA' AND kPgmID = 626 AND Iform_tp ='5';

   strcpy( TitleFmt,rtrim(TitleFmt));
   strcpy( BodyFmt,rtrim(BodyFmt));

   sprintf_s(TitleFile, sizeof TitleFile,"%s.ti",outputf);
   sprintf_s(BodyFile, sizeof BodyFile,"%s.bd",outputf);

   rgu_init_report(TitleFmt,TitleFile);
   car6264_title();
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);
   rc = car6264_body1();
   if (rc != M_CM_OK)
       return rc;
   rgu_finish_report();

   if ((rc=save_form_info(F_BLK1, "CA", 626, userid, iForm_Tp, max_cnt,
        outputf))<0) {
        strcpy(MsgCode,"save_form_info failed");
        return rc;
   }

   return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car6264_body1()
{
  int   j, rc, i;
  $char stmt[1024],stmt1[1024],stmt2[1024],stmt3[512];
  char  tit[41],h_tit[14];
  char  iequip_tmp[3];
  $char  nequipment[31];

  $WHENEVER SQLERROR GOTO errexit;

  sprintf_s(tit, sizeof tit,"%s�M��--�����O�����ŦX�M��",rtrim(nprmt));
  rgu_put_body_string(1,tit          ,1);
  rgu_put_body_string(1,cm_get_sysd(),1);
  rgu_put_body_string(1,dbgn1,1);
  rgu_put_body_string(1,dend1,1);
  rgu_put_body(1);
  max_cnt =4;

  if (date_i)
     sprintf_s(stmt3, sizeof stmt3,"dply_end >= '%s' and dply_end <= '%s' ",dbgn_inf,dend_inf);
  else
     sprintf_s(stmt3, sizeof stmt3,"dpolicy >= '%s' and dpolicy <= '%s' ",dbgn_inf,dend_inf); 

  for(j=0;j<count_db;j++) {
      sprintf_s(stmt, sizeof stmt,
             "SELECT a.ipolicy,a.icard,a.dply_begin,a.ibrand, "
             "to_char(b.dissue,'%%Y')::integer - 1911 || '/' || to_char(b.dissue,'%%m'), "
             "a.ibig_office,a.iquota[1,4]||'00',a.dpolicy, "
             "b.nassured[1,24],b.iengine,b.itag,ibig_sales, "
             "a.iofficer,nequipment,a.dply_begin,ientry,ileader,  "
             "b.iapplicant,b.napplicant[1,24]  "
             "FROM %s:ply_relation a, %s:policy b  "
             "WHERE %s AND a.fedr_class != '1'  "
             "AND a.ipolicy = b.ipolicy  "
             "AND a.dply_close is not null ",
              list[j].dbname,list[j].dbname,stmt3);

      strcpy(iequip_tmp,itoa(iremark));

      $PREPARE a_id1 FROM $stmt;
      $DECLARE cur_A CURSOR FOR a_id1;
      /* �H�������XŪ���M�׸g��N�����,�_�O��e��T�Ӥ뤺 */
      sprintf_s(stmt1, sizeof stmt1,
             "select count(*) from %s:policy a,%s:ply_relation b  "
              "where iengine = ? and a.ipolicy = b.ipolicy  "
              "  and dply_begin <= ? + 90  "
              "  and dply_begin >= ? - 90  "
              "  and iofficer[1] = '%s' and length(iofficer) = %d  "
              "  and iofficer[%d,%d] = '%s' ",
              list[j].dbname,list[j].dbname,iofficer_1,lofficer,
              ioff_chk_bgn,ioff_chk_bgn+ioff_chk_len-1,ioff_chk); 
      $PREPARE pre_f1 FROM $stmt1;
      /* �M�ײĤG�g��N�� */
      if (fanother[0]=='Y') {
         sprintf_s(stmt2, sizeof stmt2,
             "select count(*) from %s:policy a,%s:ply_relation b  "
              "where iengine = ? and a.ipolicy = b.ipolicy  "
              "  and dply_begin <= ? + 90  "
              "  and dply_begin >= ? - 90  "
              "  and iofficer[1] = '%s' and length(iofficer) = %d  "
              "  and iofficer[%d,%d] = '%s' ",
              list[j].dbname,list[j].dbname,iofficera_1,lofficera,
              ioff_chk_bgna,ioff_chk_bgna+ioff_chk_lena-1,ioff_chka); 
         $PREPARE pre_f2 FROM $stmt2;
      }
      $OPEN cur_A;
      for(;;) 
      {
         $FETCH cur_A
           INTO $ipolicy,   $icard,       $dply_begin, $ibrand,
                $iissue_ym, $ibig_office, $iquota,     $dpolicy,
                $nassured,  $iengine,     $itag,       $ibig_sales,
                $iofficer,  $nequipment,  $dply_bgn_long,
                $ientry,    $ileader      $iapplicant, $napplicant;

         if (SQLCODE == SQLNOTFOUND) break;

         if (equip_cmp(nequipment,iequip_tmp) == TRUE)
	 {
	    strcpy(cremark,"1"); 
	 }
	 else
	 {
            strcpy(cremark,"0");
	 }

         if (cremark[0]=='0') continue;

         if (strncmp(iofficer,iofficer_1,1)==0 &&
             strncmp(iofficer+ioff_chk_bgn,ioff_chk,ioff_chk_len)==0)
             continue;

         if (fanother[0]=='Y') {
            if (strncmp(iofficer,iofficera_1,1)==0 &&
                strncmp(iofficer+ioff_chk_bgna,ioff_chka,ioff_chk_lena)==0)
                continue;
         }
            
         $execute pre_f1 into $prmt_cnt using $iengine,$dply_bgn_long,
                              $dply_bgn_long;
         if (prmt_cnt > 0) continue;

         if (fanother[0]=='Y') {
            $execute pre_f2 into $prmt_cnt using $iengine,$dply_bgn_long,
                                 $dply_bgn_long;
            if (prmt_cnt > 0) continue;
         }

         $EXECUTE pre_name INTO $iofficer_c    using $iofficer;
         if(SQLCODE == SQLNOTFOUND)
            strcpy(iofficer_c, " ");
         
         $EXECUTE pre_name INTO $ientry_c      using $ientry;
         if(SQLCODE == SQLNOTFOUND)
            strcpy(ientry_c, " ");
         
         $EXECUTE pre_name INTO $ileader_c     using $ileader;
         if(SQLCODE == SQLNOTFOUND)
            strcpy(ileader_c, " ");
         
         $EXECUTE pre_nsales INTO $nsales USING $ibig_sales;
         if (SQLCODE==SQLNOTFOUND)
            strcpy(nsales," ");

         $OPEN curBX USING $ibrand;
         $FETCH curBX INTO $nbrand,$ipro_year;
         if(SQLCODE == SQLNOTFOUND) {
            nbrand[0]='\0';
         }
         $CLOSE curBX;

         $EXECUTE pre_nbranch INTO $Ngroup USING $iquota;
         if(SQLCODE ==SQLNOTFOUND) Ngroup[0]='\0';

         print_car6264_body1();

      }
      $CLOSE cur_A;
  } 
  $FREE  cur_A;

  return M_CM_OK;
   
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE; 
}
/*--------------------------------------------------------------------*/
void print_car6264_body1()
{ 
  rgu_put_body_string(2,iquota,LEFT);
  rgu_put_body_string(2,trim(Ngroup),LEFT);
  rgu_put_body_string(2,ipolicy,LEFT);
  rgu_put_body_string(2,icard,LEFT);
  rgu_put_body_string(2,nassured,LEFT);
  rgu_put_body_string(2,iapplicant,LEFT);
  rgu_put_body_string(2,napplicant,LEFT);
  rgu_put_body_string(2,dpolicy,LEFT);
  rgu_put_body_string(2,dply_begin,LEFT);
  rgu_put_body_string(2,ibrand,LEFT);
  rgu_put_body_string(2,nbrand,LEFT);
  rgu_put_body_string(2,iengine,LEFT);
  rgu_put_body_string(2,itag,LEFT);
  rgu_put_body_string(2,iissue_ym,LEFT);
  rgu_put_body_string(2,iofficer,LEFT);
  rgu_put_body_string(2,iofficer_c,LEFT);
  rgu_put_body_string(2,ileader ,LEFT);
  rgu_put_body_string(2,ileader_c ,LEFT);
  rgu_put_body_string(2,ientry_c  ,LEFT);
  rgu_put_body_string(2,ibig_office,LEFT);
  rgu_put_body_string(2,ibig_sales,LEFT);
  rgu_put_body_string(2,nsales,LEFT);
  
  rgu_put_body(2);
  max_cnt++;

}
/*--------------------------------------------------------------------*/
void car6264_title()
{
   rgu_put_head();
}
/*--------------------------------------------------------------------*/
