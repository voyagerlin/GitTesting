/************************************************/
/*                                              */
/*   PROGRAM : ca708q01s.ec by Pei Chow Chen    */
/*                                              */
/*   DATE    : 1993/09/24                       */
/*                                              */
/************************************************/
#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"

#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"
/*------------------------------------*/

$char iadjuster[11],nname[11];
$char ibranch[3], nchi_abv[13];
$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width = 0;

char tmp_iadjuster[11];
int  cnt_iadjuster;
int  tot_iadjuster;

char SysTm[ N_TM+1];
char BodyFile[ N_FILE+1];
char TitleFile[ N_FILE+1];
char outputf[ N_FILE+1];
char yy[3], mm[3], dd[3];
char yy1[3], mm1[3], dd1[3];
char yy2[3], mm2[3], dd2[3];

static int pagenum=1;
static int linecnt=0;

int  max_count = 0, errCode;
int  tmp_len;
int  copies;
int miy;

long car708_build();
void car708_title();
void car708_body();
void car708_grp();
void car708_tot();

#define LINEOFPAGE 5

/*----------------------------------------------------------------------------*/
$char DBName[5];
$char c_yymmbgn[17],c_yymmend[17];
$char dptbgn[5], dptend[2], opt[2];
char userid[11];
$char FormTp[N_FILE+1];
$int  iCnt, iCnt1, iCnt2, iTot;
$char sIadjuster[11],siofficer[11];
$char iofficer[11],itmp_policy[21],ipolicy[21],nassured[121],ibrand[9];
$char icar_type[3],iissue_ym[7],itag[CA_TAG_NUM],iengine[CA_ENGINE_NUM],dply_begin[11],dply_end[11];
$char dentry[11],dpolicy[11],icard[21],iassured[13],ibirth[11],fsex[2],fmarriage[2];
$char smadjcom_prem[11], siTot1[11], siTot2[11];
$char ibig_office[10],sibig_office[10],nname[11],fcomp_class[3];
$long madjcom_prem, iTot1, iTot2;
main(argc,argv)
int argc;
char **argv;
{
   char dummy[20],option;
   char prnTitleFile[N_FILE+1], prnBodyFile[N_FILE+1], prnDev[N_NAME+1];
   char tmpcmd[255],hostname[N_NAME+1];
   long rtncode;
   int  loc;
   int  i;

   int rc;
   batchinit();

   strcpy(DBName,isNULLstr(argv[1]));
   strcpy(userid,isNULLstr(argv[2]));
   strcpy(c_yymmbgn,isNULLstr(argv[3]));
   strcpy(c_yymmend,isNULLstr(argv[4]));
   strcpy(dptbgn,isNULLstr(argv[5]));
   strcpy(dptend,isNULLstr(argv[6]));
   strcpy(opt,isNULLstr(argv[7]));
   strcpy(outputf,isNULLstr(argv[8]));
   if(c_yymmbgn[0]=='*')strcpy(c_yymmbgn,"080/01/01");
   if(c_yymmend[0]=='*')strcpy(c_yymmend,"199/12/31");
   if(c_yymmend[0]==' ')strcpy(c_yymmend,c_yymmbgn);
printf("outputf[%s]\n",outputf);
printf("yymmbgn[%s]\n",c_yymmbgn);
printf("yymmend[%s]\n",c_yymmend);
   iTot = 0;
   car708_build();

      rtncode=create_sign_form("car708",BodyFile,Width);
      if (rtncode != 0)
        {
          EWRITE(userid,rtncode,"Error on creating sign form");
          printf("Error on creating sign form, rtncode=%d\n",rtncode);
          return;
        }

  if((rc=save_form_info(F_BLK1,"CA",708,userid,FormTp,max_count,outputf))<0)
    EWRITE(userid,rc,"save form info failure!");

}

/*----------------------------------------------------------------------------*/
long car708_build()
{
   $char TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];

   $char cc_yymmbgn[17],cc_yymmend[17];
   $char yymmbgn[17],yymmend[17], sTmpIbranch[3];
   char tmpend[17],tmpbgn[17];
   int   first=1;
   int   x,y;
   int   i_yy,i_mm;
printf("111\n");
printf("DBName[%s]\n",DBName);
   if(db_select(DBName) == False)
   {
    EWRITE(userid,M_CM_DB_NOTOPEN,"M_CM_NOTOPEN");
    return;
   } 
printf("112,opt[%s]\n",opt);

   $WHENEVER SQLERROR GOTO errexit;
   
   if (strcmp(opt,"1") == 0)
   {
        $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
                kTot_Col, kPgNum_Line, kWidth, iform_tp
           INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow, $ItemRow,
                $TotColumn, $PgLine, $Width, $FormTp
           FROM Form
          WHERE ksys_grp="CA" AND kPgmID = 708 AND iform_tp = "1";
    } else
    {
        $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
                kTot_Col, kPgNum_Line, kWidth, iform_tp
           INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow, $ItemRow,
                $TotColumn, $PgLine, $Width, $FormTp
           FROM Form
          WHERE ksys_grp="CA" AND kPgmID = 708 AND iform_tp = "2";
    }   	
printf("113,Titlefmt[%s],bodyfmt[%s]\n",TitleFmt,BodyFmt);

   strcpy( TitleFmt,rtrim(TitleFmt));
   strcpy( BodyFmt,rtrim(BodyFmt));
   sprintf_s(TitleFile, sizeof TitleFile,"%s.ti",outputf);
   sprintf_s(BodyFile, sizeof BodyFile,"%s.bd",outputf);

   strcpy(yymmbgn, cm_to_infdate(c_yymmbgn));
   strcpy(yymmend, cm_to_infdate(c_yymmend));
printf("&&& yymmbgn:[%s] yymmend:[%s] &&&\n", yymmbgn, yymmend);

printf("&&& dpt:[%s], datebgn:[%s], dateend:[%s] &&&\n", dptbgn, yymmbgn, yymmend);
   /* ***** title file ***** */
printf("104\n");
   rgu_init_report( TitleFmt,TitleFile);
printf("115\n");
   car708_title();
printf("116\n");
   rgu_finish_report();
printf("117\n");
   /* ***** body file ***** */
   rgu_init_report( BodyFmt,BodyFile);
   $DECLARE Tcursor CURSOR FOR
     SELECT a.iofficer,a.itmp_policy,a.ipolicy,b.nassured[1,8],a.ibrand,
            a.icar_type,to_char(b.dissue,'%Y')::integer - 1911 || '/' || to_char(b.dissue,'%m'),
            b.itag,b.iengine,a.dply_begin,a.dply_end,
            a.dentry,a.dpolicy,a.icard,b.iassured,
            to_char(b.dbirth,'%Y')::integer - 1911 || '/' || to_char(b.dbirth,'%m/%d'),
            b.fsex,b.fmarriage,a.madjcom_prem,
            a.ibig_office,a.fcomp_class
       FROM ply_relation a,policy b
      WHERE a.ipolicy = b.ipolicy
        AND (a.iquota[1,4] = $dptbgn or $dptbgn = '*')
        AND a.dpolicy BETWEEN $yymmbgn AND $yymmend
        AND (a.itmp_policy[1] = $dptend or $dptend = '*') 
        AND a.icashier = 'B2B'
      ORDER BY 1,2;
printf("118\n");
   $OPEN Tcursor;
printf("119\n");
   while(1) {
      $FETCH Tcursor INTO $iofficer,$itmp_policy,$ipolicy,$nassured,$ibrand,
            $icar_type,$iissue_ym,$itag,$iengine,$dply_begin,$dply_end,
            $dentry,$dpolicy,$icard,$iassured,$ibirth,$fsex,$fmarriage,$madjcom_prem,
            $ibig_office,$fcomp_class;
      if(SQLCODE == SQLNOTFOUND) break;
printf("&&& fetch ca_local_clm &&&\n");
      if(first){
        strcpy(siofficer, iofficer);
        strcpy(sibig_office, ibig_office);
        car708_grp(); 
        first = 0;
      }
printf("body1\n");
      if(strcmp(siofficer, iofficer) != 0){
printf("body2\n");
        car708_tot();
        rgu_put_body(6);
        max_count++;
        car708_grp(); 
        strcpy(sibig_office, ibig_office);
        strcpy(siofficer, iofficer);
      }
printf("body\n");
      car708_body();
   } /* while */
printf("120\n");
   $CLOSE Tcursor;
   if(max_count != 0)
     car708_tot();
   rgu_finish_report();
   return 0;
errexit:
    EWRITE(userid,SQLCODE,"Error on SQL");
    return 0;
}

/*----------------------------------------------------------------------------*/
void car708_title()
{
   char yy[3], mm[3];
   rgu_put_head_string(1, cm_get_sysd());   /* get_currdt */
   rgu_put_head_string(1, c_yymmbgn);
   rgu_put_head_string(1, c_yymmend);
   rgu_put_head();
}

/*----------------------------------------------------------------------------*/
void car708_grp()
{
printf("siofficer[%s]\n",siofficer);
   rgu_put_body_string(1, siofficer,1);
   $SELECT nname
      INTO $nname
      FROM officer
     WHERE iofficer = $siofficer;
   rgu_put_body_string(1, nname,1);    
   rgu_put_body_string(1, sibig_office,1);
   rgu_put_body(1);
   max_count++;
   return;
errexit:
printf("&&& car708_grp: SQLCODE:[%ld], ERRSTR:[%s] &&&\n", SQLCODE, sqlca.sqlerrm);
  EWRITE(userid,SQLCODE, sqlca.sqlerrm);
  exit(1);
} 

void car708_body()
{
   char buf1[20], buf2[20];
   char buf3[20];

   iTot1 += madjcom_prem;
   iTot2 += 1;

   strcpy( dply_begin, cm_from_infdate_100( dply_begin));
   strcpy( dply_end, cm_from_infdate_100(dply_end));
   strcpy( dentry, cm_from_infdate_100(dentry));
   strcpy( dpolicy, cm_from_infdate_100( dpolicy));
/*   strcpy( ibirth, cm_from_infdate_100(ibirth)); */
printf("itmp_policy[%s]\n",itmp_policy);
   rfmtlong(madjcom_prem,"---,--&",smadjcom_prem);
   rgu_put_body_string(2,itmp_policy ,1);
   rgu_put_body_string(2, ipolicy, 1);
   rgu_put_body_string(2, nassured, 1);
   rgu_put_body_string(2, ibrand, 1);
   rgu_put_body_string(2, icar_type, 1);
   rgu_put_body_string(2, iissue_ym, 1);
   rgu_put_body_string(2, itag, 1);
   rgu_put_body_string(2,iengine, 1);
   rgu_put_body_string(2, dply_begin, 1);
   rgu_put_body_string(2, dply_end, 1);
   rgu_put_body_string(2, dentry, 1);
   rgu_put_body_string(2, dpolicy, 1);
   rgu_put_body_string(2,icard, 1);
   rgu_put_body_string(2, smadjcom_prem, 2);
   rgu_put_body_string(2, iassured, 1);
   rgu_put_body_string(2, ibirth, 1);
   rgu_put_body_string(2, fsex, 1);
   rgu_put_body_string(2, fmarriage, 1);
   rgu_put_body_string(2, fcomp_class, 1);
   rgu_put_body(2);
   max_count++;
   return;
errexit:
printf("&&& car708_body: SQLCODE:[%ld], ERRSTR:[%s] &&&\n", SQLCODE, sqlca.sqlerrm);
  EWRITE(userid,SQLCODE, sqlca.sqlerrm);
  exit(1);
}

void car708_tot()
{
   char buf1[20];
   rgu_put_body( 3);
   max_count++;
   rfmtlong(iTot1,"---,--&",siTot1);
   rfmtlong(iTot2,"---,--&",siTot2);
   sprintf_s(buf1, sizeof buf1,"%d",iTot);
   rgu_put_body_string(4, siTot2, 2);
   rgu_put_body_string(4, siTot1, 2);
   rgu_put_body(4);
   max_count++;
/*
   rgu_put_body(6);
   max_count++;
*/
   iTot1 = iTot2 = 0;
}
