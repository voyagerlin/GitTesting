/*************************************************/
/*                                               */
/*    PROGRAM : ca_develop.ec                    */
/*                                               */
/*************************************************/
#include <stdio.h>
#include <stdlib.h>

#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "car_common.h"
#include <math.h>

double MyPower();
int DiffMonth();
long get_ca_car_model();
long get_dmg_cover();
long get_mcoefficient();
long get_prov_coefficient();
long get_mprem_base();
int IsBlankNull();
double d45();

long get_ca_car_model(v_ibrand,v_ipro_year,v_drate_ym,v_mcar_price,v_qpassenger,v_icar_series)
$char *v_ibrand,*v_ipro_year,*v_drate_ym,*v_icar_series;
$double *v_mcar_price,*v_qpassenger;
{
	$char ibrand_fun[11];
	$char ipro_year_fun[5];
	$char drate_ym_fun[6];
	$double mcar_price_tmp,qpassenger_tmp;
	$char icar_series_tmp[3];
	strcpy(ibrand_fun,v_ibrand);
	strcpy(ipro_year_fun,v_ipro_year);
	strcpy(drate_ym_fun,v_drate_ym);
	mcar_price_tmp = 0.0;
	qpassenger_tmp = 0.0;
	icar_series_tmp[0] = '0';
	printf("ibrand_fun[%s]\n",ibrand_fun);
	printf("ipro_year_fun[%s]\n",ipro_year_fun);
	printf("drate_ym_fun[%s]\n",drate_ym_fun);

	$WHENEVER SQLERROR GOTO car_err;
	$SELECT mcar_price,qpassenger,icar_series
	   INTO $mcar_price_tmp,$qpassenger_tmp,$icar_series_tmp
	   FROM ca_car_model
      WHERE ibrand = $ibrand_fun
        AND ipro_year = $ipro_year_fun
        AND (dexpire is null or dexpire > today)
        AND drate = (SELECT drate 
                       FROM ca_rate_date 
                      WHERE icode = $drate_ym_fun
                        AND itable = 'ca_car_model');
     printf("[=ipro_year] SQLCODE[%d] mcar_price[%f],qpassenger[%f] icar_series[%s]\n",SQLCODE,mcar_price_tmp,qpassenger_tmp,icar_series_tmp);
	if (SQLCODE==SQLNOTFOUND)
	{
		$SELECT mcar_price,qpassenger,icar_series
		   INTO $mcar_price_tmp,$qpassenger_tmp,$icar_series_tmp
		   FROM ca_car_model a
          WHERE ibrand = $ibrand_fun
            AND ipro_year = (SELECT MAX(ipro_year)
                               FROM ca_car_model
                              WHERE ibrand = $ibrand_fun
                                AND ipro_year < $ipro_year_fun 
                                AND drate = a.drate
                                AND (dexpire is null or dexpire > today))
            AND (dexpire is null or dexpire > today)
            AND drate = (SELECT drate 
                           FROM ca_rate_date 
                          WHERE icode = $drate_ym_fun
                            AND itable = 'ca_car_model');
         printf("[<ipro_year] SQLCODE[%d] mcar_price[%f],qpassenger[%f] icar_series[%s]\n",SQLCODE,mcar_price_tmp,qpassenger_tmp,icar_series_tmp);
                            
    	if (SQLCODE==SQLNOTFOUND)
		{
			$SELECT mcar_price,qpassenger,icar_series
			   INTO $mcar_price_tmp,$qpassenger_tmp,$icar_series_tmp
			   FROM ca_car_model  a
              WHERE ibrand = $ibrand_fun
                AND ipro_year = (SELECT MAX(ipro_year)
                                   FROM ca_car_model
                                  WHERE ibrand = $ibrand_fun
                                    AND ipro_year > $ipro_year_fun 
                                    AND drate = a.drate
                                    AND (dexpire is null or dexpire > today))
                AND (dexpire is null or dexpire > today)
                AND drate = (SELECT drate 
                               FROM ca_rate_date 
                              WHERE icode = $drate_ym_fun
                                AND itable = 'ca_car_model');
        	printf("[>ipro_year] SQLCODE[%d] mcar_price[%f],qpassenger[%f] icar_series[%s]\n",SQLCODE,mcar_price_tmp,qpassenger_tmp,icar_series_tmp);
        	if (SQLCODE==SQLNOTFOUND)
			{
				mcar_price_tmp = 0.0;
				qpassenger_tmp = 0.0;
				strcpy(icar_series_tmp," ");
				printf("mcar_price[%f],qpassenger[%f] icar_series[%s]\n",mcar_price_tmp,qpassenger_tmp,icar_series_tmp);
				printf("--�t�ΨS���]�w���t�P�����N��?? ibrand[%s]\n",ibrand_fun);
			}
		}
	}
	
	*v_mcar_price = mcar_price_tmp;
	*v_qpassenger = qpassenger_tmp;
	strcpy(v_icar_series,icar_series_tmp);
		
	return M_CM_OK;

	car_err:
	    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
	    return SQLCODE;			
	
}

long get_dmg_cover(v_iins_type,v_fProvision,v_dissue_pro,v_drate_ym,v_icar_type,v_mcar_price,v_dply_begin,v_mcover_ori)
$char *v_iins_type,*v_fProvision,*v_dissue_pro,*v_drate_ym,*v_icar_type;
$long v_dply_begin,*v_mcover_ori;
$double v_mcar_price;
{
	char  issue_ymd[12];
    char  datestring[16], yy[4], mm[3], dd[3], yy2[4], mm2[3];
    int   yy1,mm1,yy3,mm3, car_age20, car_age102;
    long  issue_date;
    $int  count_x=0;
    $long ply_begin_next_year,iSecondYear=0,ply_period=0,ply_period2=0;
    double year_dep,year_dep20, year_dep102;
    double year_dep_old, year_dep20_old;
    $long car_age=0,car_age_mth = 0;
	$long ply_begin;
    
    $double dep_rate = 0.0;
    
    year_dep = 0;
	year_dep102 = 0;
	car_age102 = 0;  
	$double short_prate = 0.0,pdepreciate=0.0;
	
	$double car_price;
    $long cover_01_tmp;
    $long thousand_cover_01,thousand_cover_20,thousand_cover_102;
	$long cover_01=0,cover_01_11=0;
	$long cover_20_tmp,cover_20;
	$long cover_102_tmp,cover_102;
	
	$char fcal_way[2],iins_type[INSURANCE_TYPE],fProvision[2],dissue_pro[11],Frate[5],icar_type[3];
	
	strcpy(iins_type,trim(v_iins_type));
	strcpy(fProvision,trim(v_fProvision));
	strcpy(dissue_pro,trim(v_dissue_pro));
	strcpy(Frate,trim(v_drate_ym));
	strcpy(icar_type,trim(v_icar_type));
	ply_begin = v_dply_begin;
	
	car_price = v_mcar_price;
	/**/
	printf("*******INTO get_dmg_cover******** \n");
	/*printf("fcal_way[%s]\n",fcal_way);*/
	printf("iins_type[%s]\n",iins_type);
	printf("fProvision[%s]\n",fProvision);
	printf("dissue_pro[%s]\n",dissue_pro);
	printf("Frate[%s]\n",Frate);
	printf("icar_type[%s]\n",icar_type);
	printf("ply_begin[%d]\n",ply_begin);
	
	$WHENEVER SQLERROR GOTO car_err2;

	char dissue_pro_100[11];
	strcpy(dissue_pro_100,cm_from_infdate_100(dissue_pro));
	printf("dissue_pro_100[%s]\n",dissue_pro_100);
	cm_long_split_3ymd(cm_ymd_cdate(dissue_pro_100),yy,mm,dd); /* Date(long)�ন����~�B��B��(yyy,mm,dd) */
    sprintf(issue_ymd,"%s/%s/01",yy,mm);
    issue_date=cm_ymd_cdate(issue_ymd);  /* ����~���((y)yy/mm/dd)�নDate(long) */

	printf("issue_ymd[%s] issue_date[%d] \n",issue_ymd,issue_date);

    yy3=atoi(yy);
    mm3=atoi(mm);
	
	if(strcpy(trim(iins_type),"20") == 0 || strcpy(trim(iins_type),"86") == 0 || strcpy(trim(iins_type),"23") == 0 ||
	   strcpy(trim(iins_type),"110") == 0|| strcpy(trim(iins_type),"111") == 0)
    /*if( adj_year == 1) /* 20�I�ئh��@�~ */
    {
        $SELECT first 1 (date_add( $ply_begin, interval(1) year to year))
           INTO $ply_begin_next_year
           FROM systables;

        car_age20=DiffMonth( ply_begin_next_year, issue_date);
        car_age102=DiffMonth( ply_begin_next_year, issue_date);
    }

	if (strcmp(icar_type,"CS") ==0)
	{
		car_age = 0;
		car_age_mth = 0;
	}
	else 
	{
		car_age=DiffMonth(ply_begin,issue_date);
	    car_age_mth=car_age % 12;
	    printf("car_age_mth[%d]\n",car_age_mth);
	}

    strcpy(datestring,cm_cdate_str_100(ply_begin));  /* Date(long)�ন����~���(yyy/mm/dd) */
    cm_split_ymd_100(datestring,yy,mm,dd);           /* ����~���((y)yy/mm/dd)��X�~�B��B�� */
    yy1=atoi(yy);
    /*int_ply_yr=yy1+1911;*/
    mm1=atoi(mm);

    /*if (yy3-yy1>0 || (yy3-yy1==0 && mm3-mm1>=0))
         flag_new=TRUE;
    else flag_new=FALSE;/*??????????????????????????????????????????????????????????*/

	if (fProvision[0]=='Z')
    {
		$SELECT 1-(pdepreciate/100) 
		   INTO $dep_rate
		   FROM depreciation_rate a
		  WHERE drate = (SELECT drate FROM ca_rate_date WHERE icode = $Frate
                            AND itable = 'depreciation_rate')
		    AND fcar_class   = '4'
		    AND qperiod_end  = '12';           	 
    }
    else if (fProvision[0]=='P')
    {
        $SELECT 1-(pdepreciate/100) 
		   INTO $dep_rate
		   FROM depreciation_rate a
		  WHERE drate = (SELECT drate FROM ca_rate_date WHERE icode = $Frate
                            AND itable = 'depreciation_rate')
            AND fcar_class   = '6'
            AND qperiod_end  = '12';           	 
    }
    else if (fProvision[0]=='Q') 
    {
		$SELECT 1-(pdepreciate/100) 
		   INTO $dep_rate
		   FROM depreciation_rate a
		  WHERE drate = (SELECT drate FROM ca_rate_date WHERE icode = $Frate
                            AND itable = 'depreciation_rate')
            AND fcar_class   = '7'
            AND qperiod_end  = '12';           	 
    }
    else if (fProvision[0]=='M')
    {                               
		$SELECT 1-(pdepreciate/100) 
		   INTO $dep_rate
		   FROM depreciation_rate a
		  WHERE drate = (SELECT drate FROM ca_rate_date WHERE icode = $Frate
                            AND itable = 'depreciation_rate')
            AND fcar_class   = '8'
            AND qperiod_end  = '12';           	 
    }
    else
    {
		printf("Frate = [%s]\n",Frate);
		$SELECT 1-(pdepreciate/100) 
		   INTO $dep_rate
		   FROM depreciation_rate a
		  WHERE drate = (SELECT drate FROM ca_rate_date WHERE icode = $Frate
		                    AND itable = 'depreciation_rate')
		    AND fcar_class = (SELECT case WHEN icar_grp = '1' THEN '3' else fcar_class END
		                        FROM car_type WHERE fclass = '1' AND icode = $icar_type)
		    AND qperiod_end  = '12';
	}
	printf("dep_rate[%f]\n",dep_rate);
	
	if(strcmp(icar_type,"CS") == 0) dep_rate=1;
	
	year_dep=MyPower(dep_rate, car_age/12);
    if(strcpy(trim(iins_type),"20") == 0 || strcpy(trim(iins_type),"86") == 0 || strcpy(trim(iins_type),"23") == 0 ||
	   strcpy(trim(iins_type),"110") == 0|| strcpy(trim(iins_type),"111") == 0)
    {
		year_dep20  = MyPower(dep_rate, car_age20/12);
		year_dep102 = MyPower(dep_rate, car_age102/12);
	}
	
	printf("year_dep[%f] \n",year_dep);

	if (car_age_mth==0)
    {
        pdepreciate=0;
    }
	else
    {
        if (fProvision[0]=='Z')
        {
         	$SELECT max(pdepreciate), count(*)
               INTO $pdepreciate, $count_x
               FROM depreciation_rate
              WHERE drate = (SELECT drate FROM ca_rate_date
                              WHERE icode = $Frate AND itable = 'depreciation_rate')
                AND fcar_class = '4'
                AND qperiod_end >= $car_age_mth
                AND qperiod_bgn < $car_age_mth;         	 
        }
        else if (fProvision[0]=='P')
        {
            $SELECT max(pdepreciate), count(*)
               INTO $pdepreciate, $count_x
               FROM depreciation_rate
              WHERE drate = (SELECT drate FROM ca_rate_date
                              WHERE icode = $Frate AND itable = 'depreciation_rate')
               AND fcar_class = '6'
               AND qperiod_end >= $car_age_mth
               AND qperiod_bgn < $car_age_mth;        	 
        }
        else if (fProvision[0]=='Q') 
        {
            $SELECT max(pdepreciate), count(*)
               INTO $pdepreciate, $count_x
               FROM depreciation_rate
              WHERE drate = (SELECT drate FROM ca_rate_date
                              WHERE icode = $Frate AND itable = 'depreciation_rate')
                AND fcar_class = '7'
                AND qperiod_end >= $car_age_mth
                AND qperiod_bgn < $car_age_mth;         	 
        }
        else if (fProvision[0]=='M')
        {                               
            $SELECT max(pdepreciate), count(*)
               INTO $pdepreciate, $count_x
               FROM depreciation_rate
              WHERE drate = (SELECT drate FROM ca_rate_date
                              WHERE icode = $Frate AND itable = 'depreciation_rate')
                AND fcar_class = '8'
                AND qperiod_end >= $car_age_mth
                AND qperiod_bgn < $car_age_mth;         	 
        }
        else
		{
        	$SELECT max(pdepreciate), count(*)
               INTO $pdepreciate, $count_x
               FROM depreciation_rate
              WHERE drate = (SELECT drate FROM ca_rate_date
                              WHERE icode = $Frate AND itable = 'depreciation_rate')
                AND fcar_class = (SELECT case WHEN icar_grp = '1' THEN '3' else fcar_class END
                                    FROM car_type WHERE fclass = '1' AND icode = $icar_type)
                AND qperiod_end >= $car_age_mth
                AND qperiod_bgn < $car_age_mth;
            
        }
        if (count_x == 0)  return 0;

        pdepreciate=pdepreciate/100.0;
    }
    printf("pdepreciate[%f]\n",pdepreciate);

	char tmp_outbuf[20];
   	rfmtdouble(car_price*10000.0*year_dep*(1.0-pdepreciate), "########.##########", tmp_outbuf);    
    printf("########## tmp_outbuf[%s]\n ",tmp_outbuf);
    
	if (car_price==0) return M_CA_CARPRICE; /* 1080718003-SC1-���m���椣�o��0 �_�h�p��O�B�|�ܦ�0*/
    cover_01_tmp = (long)floor(car_price*10000.0*year_dep*(1.0-pdepreciate)+ 0.000000001);
    thousand_cover_01 = cover_01_tmp % 1000;
    printf("########## car_price[%f]\n",car_price);
    printf("########## cover_01_tmp[%ld]\n",cover_01_tmp);
    printf("########## thousand_cover_01[%ld]\n",thousand_cover_01);
	
	if (thousand_cover_01 != 0)
    {
        cover_01 = (cover_01_tmp)-(thousand_cover_01);
        cover_01_11 = cover_01_tmp - thousand_cover_01;
    }
    else
    {
        cover_01 = cover_01_tmp;
        cover_01_11 = cover_01_tmp;
    }
    printf("########## cover_01[%d]\n",cover_01);

	if(strcpy(trim(iins_type),"20") == 0 || strcpy(trim(iins_type),"86") == 0 || strcpy(trim(iins_type),"23") == 0 ||
	   strcpy(trim(iins_type),"110") == 0|| strcpy(trim(iins_type),"111") == 0)
    {
        cover_20_tmp = (long)floor(car_price*10000.0*year_dep20*(1.0-pdepreciate)+ 0.000000001);
        thousand_cover_20 = cover_20_tmp % 1000;
        if (thousand_cover_20 != 0)
        {
            cover_20 = (cover_20_tmp)-(thousand_cover_20);
        }
        else
        {
            cover_20 = cover_20_tmp;
        }
        printf("########## cover_20[%ld]\n",cover_20);
        *v_mcover_ori = 	cover_20;
	}
	else if(strcpy(trim(iins_type),"102") == 0)
    {
        cover_102_tmp = (long)floor(car_price*10000.0*year_dep102*(1.0-pdepreciate)+ 0.000000001);
        thousand_cover_102 = cover_102_tmp % 1000;
        if (thousand_cover_102 != 0)
        {
            cover_102 = (cover_102_tmp)-(thousand_cover_102);
        }
        else
        {
            cover_102 = cover_102_tmp;
        }
        printf("########## cover_102[%ld]\n",cover_102);
        *v_mcover_ori = 	cover_102;
        
    }
    else if(strcpy(trim(iins_type),"11") == 0 || strcpy(trim(iins_type),"211") == 0)
    	*v_mcover_ori = cover_01_11;
    else 
    	*v_mcover_ori = cover_01;
    printf("OK \n");
    return M_CM_OK;
    car_err2:
	    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
	    return SQLCODE;			
}

double MyPower(f1, i1)
double f1;
int i1;
{
    int i;
    double ff=1.0;

    for (i=0; i<i1; i++)
    {
        ff=ff*f1;
    }
    return ff;
}
int DiffMonth(d1,d2)    /* input data should be date format */
long d1, d2;
{
    short mdy1[3], mdy2[3];
    int datediff=0;

    rjulmdy(d1,mdy1);
    rjulmdy(d2,mdy2);
    datediff=(mdy1[2]*12+mdy1[0])-(mdy2[2]*12+mdy2[0]);
    printf("DiffMonth-mdy1[2][%d]mdy1[1][%d]mdy1[0][%d]\n",mdy1[2],mdy1[1],mdy1[0]);
    printf("DiffMonth-mdy2[2][%d]mdy2[1][%d]mdy2[0][%d]\n",mdy2[2],mdy2[1],mdy2[0]);
    printf("datediff[%d]\n",datediff);
    if (datediff<0) datediff=0;
    return datediff;
}

long get_mcoefficient(v_coefficient,v_ifleet,v_mprem_cal,v_mperm_pure_cal,v_mprem_prov,v_mprem_pure_prov)
$double v_coefficient;
$int *v_ifleet;
$long *v_mprem_cal,*v_mprem_prov;
$long *v_mperm_pure_cal,*v_mprem_pure_prov;
{
	$double coefficient_fun = 0.0;
	$int ifleet_fun = 0;
	$long mprem_cal_fun,mprem_prov_fun;
	$long mprem_pure_cal_fun,mprem_pure_prov_fun;
	
	coefficient_fun = v_coefficient;
	ifleet_fun = *v_ifleet;
	
	mprem_cal_fun= *v_mprem_cal;
	mprem_pure_cal_fun = *v_mperm_pure_cal;
	mprem_prov_fun = *v_mprem_prov;
	mprem_pure_prov_fun = *v_mprem_pure_prov;
	
	printf("mprem_cal_fun[%d],mprem_pure_cal_fun[%d],mprem_prov_fun[%d],mprem_pure_prov_fun[%d]\n",mprem_cal_fun,mprem_pure_cal_fun,mprem_prov_fun,mprem_pure_prov_fun);
	
	$WHENEVER SQLERROR GOTO car_err_coe;
	if(coefficient_fun < 0 )  /*��O*/
	{
		$SELECT FIRST 1
		        ROUND($mprem_cal_fun * $coefficient_fun),
		        ROUND($mprem_pure_cal_fun * $coefficient_fun)
		   INTO $mprem_prov_fun,$mprem_pure_prov_fun
		   FROM systables;
		/*���h�ӡA�U�@�ӭp���*/
		$SELECT FIRST 1
		        ROUND($mprem_cal_fun * (1+$coefficient_fun)) * (-1),
		        ROUND($mprem_pure_cal_fun * (1+$coefficient_fun)) * (-1)
		   INTO $mprem_cal_fun,$mprem_pure_cal_fun
		   FROM systables;
	}
	else if((coefficient_fun < 1 && coefficient_fun > 0))  /*��O*/
	{
		if (ifleet_fun == 1)
		{
			$SELECT FIRST 1
			        ROUND($mprem_cal_fun * ($coefficient_fun-1)),
			        ROUND($mprem_pure_cal_fun * ($coefficient_fun-1))
			   INTO $mprem_prov_fun,$mprem_pure_prov_fun
			   FROM systables;
			/*���h�ӡA�U�@�ӭp���*/
			$SELECT FIRST 1
			        ROUND($mprem_cal_fun * $coefficient_fun),
			        ROUND($mprem_pure_cal_fun * $coefficient_fun)
			   INTO $mprem_cal_fun,$mprem_pure_cal_fun
			   FROM systables;
			ifleet_fun = 0;
		}
		else
		{
			$SELECT FIRST 1
			        ROUND($mprem_cal_fun * $coefficient_fun) * (-1),
			        ROUND($mprem_pure_cal_fun * $coefficient_fun) * (-1)
			   INTO $mprem_prov_fun,$mprem_pure_prov_fun
			   FROM systables;
			/*���h�ӡA�U�@�ӭp���*/
			$SELECT FIRST 1
			        ROUND($mprem_cal_fun * (1 - $coefficient_fun)),
			        ROUND($mprem_pure_cal_fun * (1 - $coefficient_fun))
			   INTO $mprem_cal_fun,$mprem_pure_cal_fun
			   FROM systables;
		}
	}						
	else /*�[�O*/
	{
		$SELECT FIRST 1
		        ROUND($mprem_cal_fun * ($coefficient_fun-1)),
		        ROUND($mprem_pure_cal_fun * ($coefficient_fun-1))
		   INTO $mprem_prov_fun,$mprem_pure_prov_fun
		   FROM systables;
		/*���h�ӡA�U�@�ӭp���*/
		$SELECT FIRST 1
		        ROUND($mprem_cal_fun * $coefficient_fun),
		        ROUND($mprem_pure_cal_fun * $coefficient_fun)
		   INTO $mprem_cal_fun,$mprem_pure_cal_fun
		   FROM systables;
	}
	
	*v_mprem_cal = mprem_cal_fun;
	*v_mperm_pure_cal = mprem_pure_cal_fun;
	*v_mprem_prov = mprem_prov_fun;
	*v_mprem_pure_prov = mprem_pure_prov_fun;

	return M_CM_OK;
	
	car_err_coe:
	    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
	    return SQLCODE;		
	
}

long get_prov_coefficient( char   *v_provision,
                           char   *v_drate_ym,
                           char   *v_fcar_class,
                           char   *v_iins_type,
                           char   *v_icar_type,
                           int     v_qprovision,
                           double  v_qpt,
                           long    v_mdeduct,
                           long    v_minjured_cover,
                           long    v_mdamage_cover,
                           double  v_adjust_rate,
                           double  v_pcar_price,
                           double  v_pubi_acc,
                           double  v_mcar_price,
                           double  v_mequipment,
                           int    *v_ifleet,
                           double *v_coefficient,
                           char   *v_chk_prov,
                           char   *v_sMsg)
{
	$char   provision[21],irate[5],fcar_class[2],iins_type[INSURANCE_TYPE],icar_type[3];
	$long   qprovision=0,mdeduct=0,minjured_cover=0,mdamage_cover=0;
	$double adjust_rate=0.0,pcar_price=0.0,pubi_acc=0.0,coefficient=0.0,mcar_price=0.0,mequipment=0.0;
	$double qpt=0.0,wk_qpt = 0.0;
	$double pmequipment_rate = 0.0;
	
	$WHENEVER SQLERROR GOTO errexit;
	
	puts("");
	puts("******************************");
	puts("begin get_prov_coefficient function");
	printf(" v_provision[%s]     \n ", v_provision);
	printf(" v_drate_ym[%s]      \n ", v_drate_ym);
	printf(" v_fcar_class[%s]    \n ", v_fcar_class);
	printf(" v_iins_type[%s]     \n ", v_iins_type);
	printf(" v_icar_type[%s]     \n ", v_icar_type);
	printf(" v_qprovision[%d]    \n ", v_qprovision);
	printf(" v_qpt[%f]           \n ", v_qpt);
	printf(" v_mdeduct[%d]       \n ", v_mdeduct);
	printf(" v_minjured_cover[%d]\n ", v_minjured_cover);
	printf(" v_mdamage_cover[%d] \n ", v_mdamage_cover);
	printf(" v_adjust_rate[%f]   \n ", v_adjust_rate);
	printf(" v_pcar_price[%f]    \n ", v_pcar_price);
	printf(" v_pubi_acc[%f]      \n ", v_pubi_acc);
	printf(" v_mcar_price[%f]    \n ", v_mcar_price);
	printf(" v_mequipment[%f]    \n ", v_mequipment);

	strcpy(provision,trim(v_provision));
	strcpy(irate,v_drate_ym);
	strcpy(fcar_class,v_fcar_class);
	strcpy(iins_type,v_iins_type);
	strcpy(icar_type,v_icar_type);
	qprovision = v_qprovision;
	qpt = v_qpt;
	mdeduct = v_mdeduct;
	minjured_cover = v_minjured_cover;
    mdamage_cover = v_mdamage_cover;
	adjust_rate = v_adjust_rate;
	pcar_price = v_pcar_price;
	pubi_acc = v_pubi_acc;
	mcar_price = v_mcar_price;
	mequipment = v_mequipment;

	printf(" provision[%s]     \n ", provision);
	printf(" adjust_rate[%f]   \n ", adjust_rate);
	
	v_ifleet = 0;
	if (strcmp(provision,"A") == 0)
	{
		/*ori_ins_type.adjust_rate*/
		v_ifleet = 1;
		coefficient = adjust_rate;
	}
	if (strcmp(provision,"B") == 0)
	{
		/*ori_ins_type.adjust_rate*/
		v_ifleet = 1;
		coefficient = adjust_rate;
	}
	if (strcmp(provision,"C") == 0)
	{
		$SELECT coefficient
		   INTO $coefficient
		   FROM ca_add_provision
		  WHERE provision = 'C'
		    AND iins_type = $iins_type
		    AND icar_type = $icar_type
		    AND drate     = (SELECT drate
		                       FROM ca_rate_date
		                      WHERE icode  = $irate
		                        AND itable = 'ca_add_provision');
	}
	if (strcmp(provision,"D") == 0)
	{
		/*���w�r�p�H��qprovision*/
		$SELECT coefficient
		   INTO $coefficient
		   FROM ca_add_provision
		  WHERE provision = 'D'
		    AND icar_type = $qprovision
		    AND drate     = (SELECT drate
		                       FROM ca_rate_date
		                      WHERE icode  = $irate
		                        AND itable = 'ca_add_provision');
	}
	if (strcmp(provision,"F") == 0)
	{
		printf("[FFFFFFFFF]\n");
		/*ori_ins_type.adjust_rate*/
		v_ifleet = 1;
		coefficient = adjust_rate;
	}
	if (strcmp(provision,"G") == 0)
	{
		/*ori_ins_type.adjust_rate*/
		v_ifleet = 1;
		coefficient = adjust_rate;
	}
	if (strcmp(provision,"H") == 0)
	{
		$SELECT coefficient
		   INTO $coefficient
		   FROM ca_add_provision
		  WHERE icar_type = $icar_type
		    AND iins_type = $iins_type
		    AND provision = 'H'
		    AND drate     = (SELECT drate
		                       FROM ca_rate_date
	                          WHERE icode  = $irate
	                            AND itable = 'ca_add_provision');	
	}
	if (strcmp(provision,"J") == 0)
	{
		$SELECT coefficient
		   INTO $coefficient
		   FROM ca_add_provision
		  WHERE icar_type = $icar_type
		    AND iins_type = $iins_type
		    AND provision = 'J'
		    AND drate     = (SELECT drate
		                       FROM ca_rate_date
	                          WHERE icode  = $irate
	                            AND itable = 'ca_add_provision');
	
	}
	if (strcmp(provision,"I") == 0)
	{
		/*ori_ins_type.adjust_rate*/
		v_ifleet = 1;
		coefficient = adjust_rate;
	}
	if (strcmp(provision,"K") == 0)
	{
		$SELECT coefficient 
		   INTO $coefficient
		   FROM ca_add_provision 
		  WHERE drate = (SELECT drate 
		                   FROM ca_rate_date 
		                  WHERE icode = $irate
		                    AND itable = 'ca_add_provision')
		    AND icar_type = $icar_type
		    AND iins_type = $iins_type 
		    AND provision = 'K'
		    AND mexpense = $mdamage_cover;
	}
	if (strcmp(provision,"P") == 0)
	{
		$SELECT coefficient
		   INTO $coefficient
		   FROM ca_add_provision 
		  WHERE drate = (SELECT drate 
		                   FROM ca_rate_date 
		                  WHERE icode = $irate
		                    AND itable = 'ca_add_provision')
		    AND icar_type = $fcar_class
		    AND iins_type = $iins_type
		    AND provision = 'P';
		if (SQLCODE == SQLNOTFOUND)  coefficient = 1;
	}
	if (strcmp(provision,"Q") == 0)
	{		
		$SELECT coefficient
		   INTO $coefficient
		   FROM ca_add_provision 
		  WHERE drate = (SELECT drate 
		                   FROM ca_rate_date 
		                  WHERE icode = $irate
		                    AND itable = 'ca_add_provision')
		    AND icar_type = $fcar_class
		    AND iins_type = $iins_type
		    AND provision = 'Q';
		if (SQLCODE == SQLNOTFOUND)  coefficient = 1;
	}
	
	if (strcmp(provision,"S") == 0)
	{
		/*ori_ins_type.pcar_price*/
		coefficient = pcar_price;
	}
	if (strcmp(provision,"T") == 0)
	{
		/*ori_ins_type.adjust_rate*/
		v_ifleet = 1;
		coefficient = adjust_rate;	
	}
	if (strcmp(provision,"U") == 0)
	{
		/*original_ply.pubi_acc*/
		v_ifleet = 1;
		coefficient = pubi_acc;
	}
	/*if (strcmp(provision,"V") == 0)
	{
		wk_qpt = 0.0;
		
		if (strcmp(fcar_class,"1")==0)
		{
			if(strcmp(iins_type,"09")==0)
			{
				if (strcmp(icar_type,"05")==0 || strcmp(icar_type,"06")==0 ||
				    strcmp(icar_type,"09")==0 || strcmp(icar_type,"10")==0 ||
				    strcmp(icar_type,"20")==0)
					wk_qpt = qpt;
	      		else
					wk_qpt = 0.0;
	
				$SELECT p_vprovision 
				   INTO $coefficient
				   FROM cover_vs_premium
	              WHERE icar_type = $icar_type
	                AND iins_type = $iins_type
	                AND mdeduct = $mdeduct
	                AND qpt_bgn >= $wk_qpt
	                AND qpt_end <= $wk_qpt
	                AND drate = (SELECT drate 
		                           FROM ca_rate_date 
		                          WHERE icode = $irate
		                            AND itable = 'ca_add_provision');
			}
			else 
			{
				$SELECT p_vprovision 
				   INTO $coefficient
				   FROM cover_vs_premium
	              WHERE icar_type = $icar_type
	                AND iins_type = $iins_type
	                AND mdeduct = $mdeduct
	                AND mcoverage1 = $minjured_cover
	                AND mcoverage2 = $mdamage_cover
	                AND drate = (SELECT drate 
		                           FROM ca_rate_date 
		                          WHERE icode = $irate
		                            AND itable = 'ca_add_provision');
			}
		}
	}*/
	if (strcmp(provision,"L") == 0)
	{
		$SELECT coefficient 
		   INTO $coefficient
		   FROM ca_add_provision 
		  WHERE drate = (SELECT drate 
		                   FROM ca_rate_date 
		                  WHERE icode = $irate
		                    AND itable = 'ca_add_provision')
		    AND icar_type = $icar_type
		    AND iins_type = $iins_type 
		    AND provision = 'L' 
		    AND mexpense = $mdamage_cover;
	}
	if (strcmp(provision,"Y") == 0)
	{
		pmequipment_rate = 0.0;
		printf("mcar_price[%f],mequipment[%f] \n",mcar_price,mequipment);
		pmequipment_rate = mequipment/(mcar_price - mequipment);
		printf("mequipment/(mcar_price - mequipment => pmequipment_rate[%f] \n",pmequipment_rate);
		pmequipment_rate = d45((mequipment/(mcar_price - mequipment)),4);
		printf("d45((mequipment/(mcar_price - mequipment)),4) => pmequipment_rate[%f] \n",pmequipment_rate);
		$SELECT coefficient
		   INTO $coefficient
		   FROM ca_add_provision
		  WHERE icar_type = $icar_type
		    AND iins_type = '*'
		    AND mexpense  = (SELECT max(mexpense) FROM ca_add_provision
		                      WHERE provision = 'Y'
		                        AND icar_type = $icar_type
		                        AND iins_type = '*' 
		                        AND mexpense <= $pmequipment_rate
		                        AND drate     = (SELECT drate
		                                           FROM ca_rate_date
		                                          WHERE icode  = $irate
		                                            AND itable = 'ca_add_provision')) 
		                                            AND provision = 'Y'
		                                            AND drate     = (SELECT drate
		                                                               FROM ca_rate_date
		                                                              WHERE icode  = $irate
		                                                               AND itable = 'ca_add_provision');
	}
  
	if (coefficient == 0.0) strcpy(v_chk_prov,"N");
	else strcpy(v_chk_prov,"Y");
	
	*v_coefficient = coefficient;
	
  sprintf( v_sMsg, "Found iins_type[%s] provision[%s] ==> coefficient[%f] v_chk_prov[%s] v_ifleet[%d]\n", v_iins_type, v_provision, *v_coefficient,v_chk_prov,v_ifleet);

  return M_CM_OK;

errexit:

  sprintf( v_sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  return SQLCODE;

}
long get_mprem_base( char    *v_fcal_way,
                     char    *v_icar_type,
                     char    *v_iins_type,
                     double   v_qpt,
                     char    *v_fpt,
                     char    *v_drate_ym,
                     int      v_qply_period,
                     long     v_dply_begin,
                     char    *v_dissue,
                     char    *v_ipro_year,
                     int      v_qpro_month,
                     int      v_qday,
                     long     v_mdeduct,
                     long     v_minjured_cover,
                     long     v_mdeath_cover,
                     long     v_mdamage_cover,
                     double   v_qpassenger,
                     double   v_mcar_price,
                     char     *v_ibrand,
                     char    *v_provision,
                     double  *mprem_base,
                     char    *v_sMsg)
{
	$char fcal_way[2],irate[5],fcar_class[2],iins_type[INSURANCE_TYPE],icar_type[3],dissue[11],ipro_year[5];
	$char isame_ins[INSURANCE_TYPE];
	$long dply_begin,mdeduct=0,minjured_cover=0,mdeath_cover=0,mdamage_cover=0;
	$double qpt=0.0,wk_qpt=0.0;
	$char fpt[2];
	$double ca_rate_qpt=0.0,mbase=0.0,mcar_price=0.0,qpassenger=0.0,mbase1=0.0,mbase2=0.0,mbase2_1=0.0,mbase2_2=0.0;
	$int qply_period=0,qday=0,car_age_year=0,car_age150151=0;
	$char ibrand[11];
	$char stmt[1024];
	$char provision[21];
	$int qpro_month = 0;
	
	$WHENEVER SQLERROR GOTO errexit;
	
	puts("");
	puts("******************************");
	puts("begin get_mprem_base function");
	printf(" v_fcal_way[%s]      \n ", v_fcal_way);
	printf(" v_icar_type[%s]     \n ", v_icar_type);
	printf(" v_iins_type[%s]     \n ", v_iins_type);
	printf(" v_qpt[%f]           \n ", v_qpt);
	printf(" v_fpt[%f]           \n ", v_fpt);
	printf(" v_drate_ym[%s]      \n ", v_drate_ym);
	printf(" v_qply_period[%d]   \n ", v_qply_period);
	printf(" v_dply_begin[%d]    \n ", v_dply_begin);
	printf(" v_dissue[%s]        \n ", v_dissue);
	printf(" v_ipro_year[%s]     \n ", v_ipro_year);
	printf(" v_qday[%d]          \n ", v_qday);
	printf(" v_mdeduct[%d]       \n ", v_mdeduct);
	printf(" v_minjured_cover[%d]\n ", v_minjured_cover);
	printf(" v_mdeath_cover[%d]  \n ", v_mdeath_cover);
	printf(" v_mdamage_cover[%d] \n ", v_mdamage_cover);
	printf(" v_qpassenger[%f]    \n ", v_qpassenger);
	printf(" v_mcar_price[%f]    \n ", v_mcar_price);
	printf(" v_ibrand[%s]        \n ", v_ibrand);
	printf(" v_provision[%s]     \n ", v_provision);

	strcpy(fcal_way,trim(v_fcal_way));
	strcpy(icar_type,trim(v_icar_type));
	strcpy(iins_type,v_iins_type);
	strcpy(fpt,v_fpt);
	strcpy(irate,v_drate_ym);
	strcpy(dissue,v_dissue);
	strcpy(ipro_year,v_ipro_year);
	strcpy(ibrand,v_ibrand);
	strcpy(provision,v_provision);
	
	qday = v_qday;
	qpt = v_qpt;
	qply_period = v_qply_period;
	dply_begin = v_dply_begin;
	mdeduct = v_mdeduct;
	minjured_cover = v_minjured_cover;
	mdeath_cover = v_mdeath_cover;
	mdamage_cover = v_mdamage_cover;
	mcar_price = v_mcar_price;
	qpassenger = v_qpassenger;
	qpro_month = v_qpro_month;
	
	sprintf(stmt,"SELECT fcar_class FROM car_type \
				   WHERE fclass = '1' AND icode = ? ");
	$PREPARE CUR_CARCLASS FROM $stmt;
	$EXECUTE CUR_CARCLASS INTO $fcar_class USING $icar_type;

	sprintf(stmt,"SELECT isame_ins FROM insurance_type\
				   WHERE iins_type = ? ");
	$PREPARE CUR_INS FROM $stmt;
	
	if (fcal_way[0] == '1')  /*�O�v��ca_rate*/
	{
		if (strcmp(trim(iins_type),"01") == 0  || strcmp(trim(iins_type),"05") == 0  || strcmp(trim(iins_type),"09") == 0  ||
			strcmp(trim(iins_type),"08") == 0  || strcmp(trim(iins_type),"85") == 0  || strcmp(trim(iins_type),"105") == 0 ||
			strcmp(trim(iins_type),"118") == 0 || strcmp(trim(iins_type),"120") == 0 || strcmp(trim(iins_type),"122") == 0 ||
			strcmp(trim(iins_type),"125") == 0 || strcmp(trim(iins_type),"126") == 0 || strcmp(trim(iins_type),"152") == 0 ||
			strcmp(trim(iins_type),"153") == 0 ||
			strcmp(trim(iins_type),"201") == 0 || strcmp(trim(iins_type),"205") == 0 || strcmp(trim(iins_type),"209") == 0)
		{
			if (strcmp(icar_type,"05")==0 || strcmp(icar_type,"06")==0 || strcmp(icar_type,"09")==0 ||
			    strcmp(icar_type,"10")==0 || strcmp(icar_type,"20")==0)
			    ca_rate_qpt = qpt;
			else 
				ca_rate_qpt = 0;
		}
		
		if (fpt[0] == 'P')
		{
			if(strcmp(trim(iins_type),"24") == 0 || strcmp(trim(iins_type),"26") == 0)
			{
				$SELECT case WHEN mprem > 0 THEN round(mprem,4) else round(prate,4) END
				   INTO $mbase
				   FROM ca_rate
				  WHERE icar_type = $icar_type
				    AND iins_type = $iins_type
				    AND qpt_bgn <= $ca_rate_qpt
				    AND qpt_end >= $ca_rate_qpt
				    AND drate = (SELECT drate 
				                   FROM ca_rate_date
				                  WHERE icode = $irate 
				                    AND itable = 'ca_rate');
				if (SQLCODE==SQLNOTFOUND) mbase = 0.0;
			}
			else if(strcmp(trim(iins_type),"111") == 0)
			{
				$SELECT case WHEN mprem > 0 THEN round(mprem,4) else round(prate,4) END
				   INTO $mbase
				   FROM ca_rate
				  WHERE icar_type = $icar_type
				    AND iins_type = $iins_type
				    AND qpt_bgn <= $ca_rate_qpt
				    AND qpt_end >= $ca_rate_qpt
				    AND mdeduct = case WHEN $qply_period <= 12 THEN 1 else 2 END
				    AND drate = (SELECT drate 
				                   FROM ca_rate_date
				                  WHERE icode = $irate 
				                    AND itable = 'ca_rate');
				if (SQLCODE==SQLNOTFOUND) mbase = 0.0;
			}
			else if(strcmp(trim(iins_type),"150") == 0 || strcmp(trim(iins_type),"151") == 0)
			{
				car_age150151=DiffMonth(dply_begin,dissue);
				
				if (atoi(irate) >=104)
				{
					if (car_age150151 >= 0 && car_age150151 < 12)
						car_age_year = 1;
					else if (car_age150151 >= 12 && car_age150151 < 24)
						car_age_year = 2;
					else
						car_age_year = 3;
				}
				else
				{  
					if (car_age150151 >= 0 && car_age150151 <= 12)
						car_age_year = 1;
					else if (car_age150151 > 12 && car_age150151 <= 24)
						car_age_year = 2;
					else
						car_age_year = 0;
				}
				
				$SELECT case WHEN mprem > 0 THEN round(mprem,4) else round(prate,4) END
				   INTO $mbase
				   FROM ca_rate
				  WHERE icar_type = $icar_type
				    AND iins_type = $iins_type
				    AND mdeduct = $car_age_year
				    AND qpt_bgn <= $ca_rate_qpt
				    AND qpt_end >= $ca_rate_qpt
				    AND drate = (SELECT drate 
				                   FROM ca_rate_date
				                  WHERE icode = $irate 
				                    AND itable = 'ca_rate');
				if (SQLCODE==SQLNOTFOUND) mbase = 0.0;
			}
			else
			{
				$SELECT case WHEN mprem > 0 THEN round(mprem,4) else round(prate,4) END
				   INTO $mbase
				   FROM ca_rate
				  WHERE icar_type = $icar_type
				    AND iins_type = $iins_type
				    AND mdeduct = $mdeduct
				    AND qpt_bgn = $ca_rate_qpt
				    AND qpt_end = $ca_rate_qpt
				    AND drate = (SELECT drate 
				                   FROM ca_rate_date
				                  WHERE icode = $irate 
				                    AND itable = 'ca_rate');
				if (SQLCODE==SQLNOTFOUND) mbase = 0.0;
			}
		}	
		else
		{
			
			if ((strcmp(icar_type,"06")==0 || strcmp(icar_type,"10")==0 || strcmp(icar_type,"20")==0) &&
				(strcmp(trim(iins_type),"01") == 0  || strcmp(trim(iins_type),"05") == 0  || strcmp(trim(iins_type),"09") == 0  ||
				 strcmp(trim(iins_type),"85") == 0  || strcmp(trim(iins_type),"105") == 0 || strcmp(trim(iins_type),"118") == 0 ||
				 strcmp(trim(iins_type),"120") == 0 || strcmp(trim(iins_type),"122") == 0 || strcmp(trim(iins_type),"125") == 0 ||
				 strcmp(trim(iins_type),"126") == 0 || strcmp(trim(iins_type),"201") == 0 || strcmp(trim(iins_type),"205") == 0 || 
				 strcmp(trim(iins_type),"209") == 0))
			{
				$SELECT case WHEN mprem > 0 THEN round(mprem,4) else round(prate,4) END
				   INTO $mbase
				   FROM ca_rate
				  WHERE icar_type = $icar_type
				    AND iins_type = $iins_type
				    AND qpt_bgn < $ca_rate_qpt
				    AND qpt_end >= $ca_rate_qpt
				    AND mdeduct = $mdeduct
				    AND drate = (SELECT drate 
				                   FROM ca_rate_date
				                  WHERE icode = $irate 
				                    AND itable = 'ca_rate');
			}
			else 
			{
				if(strcmp(trim(iins_type),"24") == 0 || strcmp(trim(iins_type),"26") == 0)
				{
					$SELECT case WHEN mprem > 0 THEN round(mprem,4) else round(prate,4) END
					   INTO $mbase
					   FROM ca_rate
					  WHERE icar_type = $icar_type
					    AND iins_type = $iins_type
					    AND qpt_bgn <= $ca_rate_qpt
					    AND qpt_end >= $ca_rate_qpt
					    AND drate = (SELECT drate 
					                   FROM ca_rate_date
					                  WHERE icode = $irate 
					                    AND itable = 'ca_rate');
					if (SQLCODE==SQLNOTFOUND) mbase = 0.0;
				}
				else if(strcmp(trim(iins_type),"150") == 0 || strcmp(trim(iins_type),"151") == 0)
				{
					car_age150151=DiffMonth(dply_begin,dissue);
					
					if (atoi(irate) >=104)
					{
						if (car_age150151 >= 0 && car_age150151 < 12)
							car_age_year = 1;
						else if (car_age150151 >= 12 && car_age150151 < 24)
							car_age_year = 2;
						else
							car_age_year = 3;
					}
					else
					{  
						if (car_age150151 >= 0 && car_age150151 <= 12)
							car_age_year = 1;
						else if (car_age150151 > 12 && car_age150151 <= 24)
							car_age_year = 2;
						else
							car_age_year = 0;
					}
					
					$SELECT case WHEN mprem > 0 THEN round(mprem,4) else round(prate,4) END
					   INTO $mbase
					   FROM ca_rate
					  WHERE icar_type = $icar_type
					    AND iins_type = $iins_type
					    AND mdeduct = $car_age_year
					    AND qpt_bgn <= $ca_rate_qpt
					    AND qpt_end >= $ca_rate_qpt
					    AND drate = (SELECT drate 
					                   FROM ca_rate_date
					                  WHERE icode = $irate 
					                    AND itable = 'ca_rate');
					if (SQLCODE==SQLNOTFOUND) mbase = 0.0;
				}
				else
				{
					$SELECT case WHEN mprem > 0 THEN round(mprem,4) else round(prate,4) END
					   INTO $mbase
					   FROM ca_rate
					  WHERE icar_type = $icar_type
					    AND iins_type = $iins_type
					    AND mdeduct = $mdeduct
					    AND qpt_bgn <= $ca_rate_qpt
					    AND qpt_end >= $ca_rate_qpt
					    AND drate = (SELECT drate 
					                   FROM ca_rate_date
					                  WHERE icode = $irate 
					                    AND itable = 'ca_rate');
					if (SQLCODE==SQLNOTFOUND) mbase = 0.0;
				}
			}
		}
	}
	else if (fcal_way[0] == '2')
	{
		$EXECUTE CUR_INS INTO $isame_ins USING $iins_type;
		
		if(strcmp(trim(iins_type),"34") == 0 || strcmp(trim(iins_type),"87") == 0 || strcmp(trim(iins_type),"115") == 0)
		{
			/* �@�~����~�� */
			$SELECT round(mpremium,4)
		       INTO $mbase
		       FROM cover_vs_premium
		      WHERE icar_type  = $icar_type
		        AND iins_type  = $iins_type
		        AND mcoverage1 = $minjured_cover
		        AND mcoverage2 = $mdeath_cover
		        AND mdeduct    = case WHEN $qply_period <= 12 THEN 1 else 21 END
			    AND drate = (SELECT drate 
			                   FROM ca_rate_date
			                  WHERE icode = $irate 
			                    AND itable = 'cover_vs_premium');
			if (SQLCODE==SQLNOTFOUND) mbase = 0.0;
		}
		else
		{
			if (!IsBlankNull(isame_ins))
			{
				if(strcmp(trim(iins_type),"71") == 0 || strcmp(trim(iins_type),"72") == 0)
				{
					$SELECT round(mpremium,4)
				       INTO $mbase
				       FROM cover_vs_premium
				      WHERE icar_type  = $icar_type
				        AND iins_type  = $iins_type
				        AND mcoverage2 = $mdamage_cover
				        AND mdeduct    = $mdeduct
					    AND drate = (SELECT drate 
					                   FROM ca_rate_date
					                  WHERE icode = $irate 
					                    AND itable = 'cover_vs_premium');
					if (SQLCODE==SQLNOTFOUND) mbase = 0.0;
				}
				else if(strcmp(trim(iins_type),"30") == 0 || strcmp(trim(iins_type),"301") == 0 || strcmp(trim(iins_type),"302") == 0 || strcmp(trim(iins_type),"530") == 0)
				{
					$SELECT round(mpremium,4)
				       INTO $mbase
				       FROM cover_vs_premium
				      WHERE icar_type  = $icar_type
				        AND iins_type  = $iins_type
				        AND mcoverage1 = $minjured_cover
				        AND mcoverage2 = $mdamage_cover
				        AND mdeduct    = $mdeduct
					    AND drate = (SELECT drate 
					                   FROM ca_rate_date
					                  WHERE icode = $irate 
					                    AND itable = 'cover_vs_premium');
					if (SQLCODE==SQLNOTFOUND) mbase = 0.0;			
				}
				else if(strcmp(trim(iins_type),"29") == 0 || strcmp(trim(iins_type),"124") == 0)
				{
					/*��minjured_cover��32�I�بƬG�O�B*/
					if ((minjured_cover >= 200000) && (minjured_cover < 500000))
						minjured_cover = 200000;
					else if ((minjured_cover >= 500000) && (minjured_cover <= 1000000))
						minjured_cover = 500000;
					else minjured_cover = 0;
					
					$SELECT round(mpremium,4)
				       INTO $mbase
				       FROM cover_vs_premium
				      WHERE icar_type  = $icar_type
				        AND iins_type  = $iins_type
				        AND mcoverage1 = $minjured_cover
				        AND mcoverage2 = $mdamage_cover
				        AND mdeduct    = $mdeduct
					    AND drate = (SELECT drate 
					                   FROM ca_rate_date
					                  WHERE icode = $irate 
					                    AND itable = 'cover_vs_premium');
					if (SQLCODE==SQLNOTFOUND) mbase = 0.0;
					
				}
				else if(strcmp(trim(iins_type),"38") == 0 || strcmp(trim(iins_type),"39") == 0)
				{
					$int icar_age = 0;
					icar_age = atoi(cm_eyear_str(dply_begin)) - atoi(ipro_year); /* �D���ϴ��I�ب��� */
					if ( icar_age <= 0)   icar_age = 1 ;      /* ���~��1�~ */
					else if ( icar_age >= 9)   icar_age = 9 ; /* �j��9�~��9�~ */
					icar_age = qday * 10 + icar_age;
					printf("--3839--qday[%d] icar_age[%d]\n",qday,icar_age);
					$SELECT round(mpremium,4)
				       INTO $mbase
				       FROM cover_vs_premium a
				      WHERE a.icar_type = $icar_type
				        AND a.iins_type = $iins_type
				        AND a.mcoverage1 = $minjured_cover
				        AND a.mcoverage2 = $mdamage_cover
				        AND drate = (SELECT drate
				                       FROM ca_rate_date
				                      WHERE icode = $irate
				                        AND itable='cover_vs_premium')
				        AND mdeduct = (SELECT max(mdeduct) from cover_vs_premium
				                        WHERE icar_type = a.icar_type
				                          AND iins_type = a.iins_type
				                          AND mcoverage1 = a.mcoverage1
				                          AND mcoverage2 = a.mcoverage2
				                          AND drate = a.drate
				                          AND mdeduct < $icar_age
				                          AND ((mdeduct- mod(mdeduct,$qday))/10 = $qday));
					if (SQLCODE==SQLNOTFOUND) mbase = 0.0;
				}
				else 
				{
					if(strcmp(trim(iins_type),"32") == 0  || strcmp(trim(iins_type),"132") == 0 || strcmp(trim(iins_type),"134") == 0 ||
					   strcmp(trim(iins_type),"78") == 0  || strcmp(trim(iins_type),"149") == 0 || strcmp(trim(iins_type),"31") == 0  ||
					   strcmp(trim(iins_type),"131") == 0 || strcmp(trim(iins_type),"133") == 0 || strcmp(trim(iins_type),"77") == 0  ||
					   strcmp(trim(iins_type),"164") == 0 || strcmp(trim(iins_type),"165") == 0 ||
					   strcmp(trim(iins_type),"231") == 0 || strcmp(trim(iins_type),"232") == 0 ||
					   strcmp(trim(iins_type),"331") == 0 || strcmp(trim(iins_type),"332") == 0 || strcmp(trim(iins_type),"249") == 0 ||
					   strcmp(trim(iins_type),"531") == 0 || strcmp(trim(iins_type),"532") == 0 )
					{
						$SELECT round(mpremium,4)
						   INTO $mbase
						   FROM cover_vs_premium
						  WHERE icar_type  = $icar_type
						    AND iins_type  = $iins_type
						    AND mcoverage1 = $minjured_cover
						    AND mcoverage2 = $mdamage_cover
						    AND mdeduct    = $mdeduct
						    AND drate = (SELECT drate 
						                   FROM ca_rate_date
						                  WHERE icode = $irate 
						                    AND itable = 'cover_vs_premium');
						if (SQLCODE==SQLNOTFOUND) mbase = 0.0;
					}
					else if(strcmp(trim(iins_type),"109") == 0)
					{
						/*109�I��minjured_cover��31�I�بƬG�O�B*/
						$SELECT round(mpremium,4)
					       INTO $mbase
					       FROM cover_vs_premium
					      WHERE icar_type  = $icar_type
					        AND iins_type  = $iins_type
					        AND mcoverage1 = $minjured_cover
					        AND mcoverage2 = $mdeath_cover
					        AND drate = (SELECT drate
					                       FROM ca_rate_date
					                      WHERE icode  = $irate
					                        AND itable = 'cover_vs_premium');
						if (SQLCODE==SQLNOTFOUND) mbase = 0.0;
					}
					else if(strcmp(trim(iins_type),"113") == 0 || strcmp(trim(iins_type),"114") == 0)
					{
						$SELECT round(mpremium,4)
					       INTO $mbase
					       FROM cover_vs_premium
					      WHERE icar_type  = $icar_type
					        AND iins_type  = $iins_type
					        AND mcoverage1 = $minjured_cover
					        AND mcoverage2 = $mdamage_cover
					        AND mdeduct = case WHEN $qply_period <= 12 THEN 1+10*$mdeduct else 2+10*$mdeduct END
					        AND drate = (SELECT drate
					                       FROM ca_rate_date
					                      WHERE icode  = $irate
					                        AND itable = 'cover_vs_premium');
						if (SQLCODE==SQLNOTFOUND) mbase = 0.0;
					}
					else
					{
						$SELECT round(mpremium,4)
					       INTO $mbase
					       FROM cover_vs_premium
					      WHERE icar_type  = $icar_type
					        AND iins_type  = $iins_type
					        AND mcoverage1 = $minjured_cover
					        AND mcoverage2 = $mdamage_cover
					        AND drate = (SELECT drate
					                       FROM ca_rate_date
					                      WHERE icode  = $irate
					                        AND itable = 'cover_vs_premium');
						if (SQLCODE==SQLNOTFOUND) /*mbase = 0.0;*/ 
						{
							mbase = 0.0;
							sprintf( v_sMsg,"SQLCODE=%d:irate=%s,icar_type=%s,iins_type=%s,minjured_cover=%ld,mdamage_cover=%ld,mdeduct=%ld\n",
								    SQLCODE, irate,icar_type,iins_type,minjured_cover,mdamage_cover,mdeduct);	
						} 

					}
	
					if(strcmp(trim(iins_type),"31") == 0  || strcmp(trim(iins_type),"32") == 0  || strcmp(trim(iins_type),"36") == 0  ||
					   strcmp(trim(iins_type),"37") == 0  || strcmp(trim(iins_type),"77") == 0  || strcmp(trim(iins_type),"78") == 0  ||
					   strcmp(trim(iins_type),"113") == 0 || strcmp(trim(iins_type),"114") == 0 || strcmp(trim(iins_type),"131") == 0 ||
					   strcmp(trim(iins_type),"132") == 0 || strcmp(trim(iins_type),"133") == 0 || strcmp(trim(iins_type),"134") == 0 ||
					   strcmp(trim(iins_type),"149") == 0 ||
					   strcmp(trim(iins_type),"231") == 0 || strcmp(trim(iins_type),"232") == 0 ||
					   strcmp(trim(iins_type),"331") == 0 || strcmp(trim(iins_type),"332") == 0 || 
					   strcmp(trim(iins_type),"249") == 0 || strcmp(trim(iins_type),"531") == 0 || strcmp(trim(iins_type),"532") == 0 )
					{
						if (fcar_class[0]=='1') 
						{
								
						}
						else /* fcar_class[0]=='2' */
						{
							if (strstr(provision,"J") != NULL)
			                {
				              	$SELECT round(mpremium,4)
				                   INTO $mbase
				                   FROM cover_vs_premium
				                  WHERE icar_type  = '03'
				                    AND iins_type  = $iins_type
				                    AND mcoverage1 = $minjured_cover
				                    AND mcoverage2 = $mdamage_cover
				                    AND mdeduct    = $mdeduct
				                    AND drate=(SELECT drate
				                                 FROM ca_rate_date
				                                WHERE icode  = $irate
				                                  AND itable = 'cover_vs_premium');
								if (SQLCODE==SQLNOTFOUND) mbase = 0.0;
			            	} 
						}
					}
				}
			}
			else 
			{
				if(strcmp(trim(iins_type),"25") == 0)
				{
					$SELECT round(mpremium,4)
				       INTO $mbase
				       FROM cover_vs_premium
				      WHERE icar_type  = $icar_type
				        AND iins_type  = $iins_type
				        AND mcoverage1 = $minjured_cover
				        AND drate = (SELECT drate
				                       FROM ca_rate_date
				                      WHERE icode  = $irate
				                        AND itable = 'cover_vs_premium');
					if (SQLCODE==SQLNOTFOUND) mbase = 0.0;
				}
				else if(strcmp(trim(iins_type),"14") == 0  || strcmp(trim(iins_type),"61") == 0 || strcmp(trim(iins_type),"65") == 0  ||
				        strcmp(trim(iins_type),"68") == 0  || strcmp(trim(iins_type),"69") == 0 || strcmp(trim(iins_type),"19") == 0  ||
				        strcmp(trim(iins_type),"97") == 0  || strcmp(trim(iins_type),"27") == 0 || strcmp(trim(iins_type),"108") == 0 ||
				        strcmp(trim(iins_type),"142") == 0 || strcmp(trim(iins_type),"157") == 0 )
				{
					$SELECT round(mpremium,4)
	                   INTO $mbase
	                   FROM cover_vs_premium
	                  WHERE icar_type  = $icar_type
	                    AND iins_type  = $iins_type
	                    AND mcoverage2 = $mdamage_cover
	                    AND drate=(SELECT drate
	                                 FROM ca_rate_date
	                                WHERE icode  = $irate
	                                  AND itable = 'cover_vs_premium');
					if (SQLCODE==SQLNOTFOUND) mbase = 0.0;
				}
				else if(strcmp(trim(iins_type),"15") == 0  || strcmp(trim(iins_type),"16") == 0  || strcmp(trim(iins_type),"66") == 0  ||
				        strcmp(trim(iins_type),"67") == 0  || strcmp(trim(iins_type),"106") == 0 || strcmp(trim(iins_type),"119") == 0 ||
				        strcmp(trim(iins_type),"121") == 0 || strcmp(trim(iins_type),"123") == 0 || 
				        strcmp(trim(iins_type),"154") == 0 || strcmp(trim(iins_type),"155") == 0 ||strcmp(trim(iins_type),"156") == 0  ||
				        strcmp(trim(iins_type),"163") == 0 )
				{
					$SELECT round(mpremium,4)
	                   INTO $mbase
	                   FROM cover_vs_premium
	                  WHERE icar_type  = $icar_type
	                    AND iins_type  = $iins_type
	                    AND mcoverage1 = $minjured_cover
	                    AND mcoverage2 = $mdamage_cover
	                    AND drate=(SELECT drate
	                                 FROM ca_rate_date
	                                WHERE icode  = $irate
	                                  AND itable = 'cover_vs_premium');
					if (SQLCODE==SQLNOTFOUND) mbase = 0.0;
				}
				else if(strcmp(trim(iins_type),"62") == 0  || strcmp(trim(iins_type),"63") == 0  || strcmp(trim(iins_type),"64") == 0  ||
				        strcmp(trim(iins_type),"86") == 0  || strcmp(trim(iins_type),"98") == 0  || strcmp(trim(iins_type),"101") == 0 ||
				        strcmp(trim(iins_type),"102") == 0 || strcmp(trim(iins_type),"103") == 0 || strcmp(trim(iins_type),"104") == 0 ||
				        strcmp(trim(iins_type),"107") == 0 || 
				        strcmp(trim(iins_type),"145") == 0 || strcmp(trim(iins_type),"146") == 0 || strcmp(trim(iins_type),"148") == 0 ||
				        strcmp(trim(iins_type),"161") == 0 || strcmp(trim(iins_type),"162") == 0 )
				{
					$char f86[2];
					if(strcmp(trim(iins_type),"86") == 0)
					{
						$SELECT case when drate >= date('06/08/2015') then '1' else '0' end
						   Into $f86
						   FROM ca_rate_date
						  WHERE icode  = $irate          
							AND itable = 'cover_vs_premium';
						if (f86[0] == '0')
						{
							if (strcmp(icar_type,"32")==0)
							{
								$SELECT min(mdeduct)
								   INTO $mdeduct
								   FROM cover_vs_premium
								  WHERE iins_type = $iins_type
									AND icar_type = $icar_type
									AND drate = (SELECT drate
				                                   FROM ca_rate_date
				                                  WHERE icode  = $irate
				                                    AND itable = 'cover_vs_premium')
			                						AND mdeduct >= $mcar_price;
								if(SQLCODE==SQLNOTFOUND) mdeduct = 0;
							}
							else
							{
								mdeduct = 0;
		                  	}
		                  	
		                  	$SELECT round(mpremium,4)
			                   INTO $mbase
			                   FROM cover_vs_premium
			                  WHERE icar_type  = $icar_type
			                    AND iins_type  = $iins_type
			                    AND mcoverage2 = $mdamage_cover
			                    AND mdeduct    = $mdeduct
			                    AND drate=(SELECT drate
			                                 FROM ca_rate_date
			                                WHERE icode  = $irate
			                                  AND itable = 'cover_vs_premium');
							if (SQLCODE==SQLNOTFOUND) mbase = 0.0;
						}
						else 
						{
		                    minjured_cover = 0;
							if (strcmp(icar_type,"32")==0)
							{
								$SELECT min(mcoverage1)
								   INTO $minjured_cover
								   FROM cover_vs_premium
								  WHERE iins_type = $iins_type
									AND icar_type = $icar_type
									AND drate = (SELECT drate
				                                   FROM ca_rate_date
				                                  WHERE icode  = $irate
				                                    AND itable = 'cover_vs_premium')
			                						AND mcoverage1 >= $mcar_price;
								if(SQLCODE==SQLNOTFOUND) minjured_cover = 0;
							}
							
							$SELECT round(mpremium,4)
			                   INTO $mbase
			                   FROM cover_vs_premium
			                  WHERE icar_type  = $icar_type
			                    AND iins_type  = $iins_type
			                    AND mcoverage1 = $minjured_cover
			                    AND mcoverage2 = $mdamage_cover
			                    AND mdeduct    = $mdeduct
			                    AND drate=(SELECT drate
			                                 FROM ca_rate_date
			                                WHERE icode  = $irate
			                                  AND itable = 'cover_vs_premium');
							if (SQLCODE==SQLNOTFOUND) mbase = 0.0;
						}
					}
					else if(strcmp(trim(iins_type),"101") == 0  || strcmp(trim(iins_type),"102") == 0)
					{
						/* �q�ʦۦ樮-�s���I�ǰe�I*/
					}
					/*103�B104�q�ʦۦ樮-�s���I�ǰe*/
					else if(strcmp(trim(iins_type),"107") == 0 || strcmp(trim(iins_type),"145") == 0 ||
					        strcmp(trim(iins_type),"146") == 0 || strcmp(trim(iins_type),"148") == 0 )
					{
						$SELECT round(mpremium,4)
		                   INTO $mbase
		                   FROM cover_vs_premium
		                  WHERE icar_type  = $icar_type
		                    AND iins_type  = $iins_type
		                    AND mcoverage1 = $minjured_cover
		                    AND mcoverage2 = $mdamage_cover
		                    AND mdeduct    = $mdeduct
		                    AND drate=(SELECT drate
		                                 FROM ca_rate_date
		                                WHERE icode  = $irate
		                                  AND itable = 'cover_vs_premium');
						if (SQLCODE==SQLNOTFOUND) mbase = 0.0;
					}
					else if(strcmp(trim(iins_type),"98") == 0 || strcmp(trim(iins_type),"161") == 0 || strcmp(trim(iins_type),"162") == 0)
					{
						$char sNcode[41];
						$SELECT b.ncode 
						   INTO $sNcode
						   FROM ca_car_model a, cu_code_data b
					 	  WHERE a.icar_series = b.icode
						    AND b.itype = 'CJ'
						    AND a.ibrand = $ibrand
						    AND (dexpire is null or dexpire > today)
						    AND a.ipro_year = (SELECT max(ipro_year)
						                         FROM ca_car_model
						                        WHERE ibrand = a.ibrand
						                          AND ipro_year <= $ipro_year
						                          AND drate = a.drate 
						                          AND (dexpire is null or dexpire > today))
						    AND a.drate = (SELECT drate 
						                     FROM ca_rate_date
						                    WHERE icode = $irate
						                      AND itable = 'ca_car_model');
						   if (SQLCODE==SQLNOTFOUND)
						   {
								$SELECT b.ncode 
								   INTO $sNcode
								   FROM ca_car_model a, cu_code_data b
								  WHERE a.icar_series = b.icode
								    AND b.itype = 'CJ'
								    AND a.ibrand = $ibrand
								    AND (dexpire is null or dexpire > today)
								    AND a.ipro_year = (SELECT min(ipro_year)
								                         FROM ca_car_model
								                        WHERE ibrand = a.ibrand
								                          AND ipro_year > $ipro_year
								                          AND drate = a.drate 
								                          AND (dexpire is null or dexpire > today))
								    AND a.drate = (SELECT drate 
								                     FROM ca_rate_date
								                    WHERE icode = $irate
								                      AND itable = 'ca_car_model');	
								if (SQLCODE==SQLNOTFOUND)  mbase = 0.0;
							}
						   
						strcpy(sNcode,trim(sNcode));
						mdeduct = atol(sNcode);
						$SELECT mpremium
						   INTO $mbase
						   FROM cover_vs_premium
						  WHERE icar_type  = $icar_type
						    AND iins_type  = $iins_type
						    AND mcoverage2 = $mdamage_cover
						    AND mdeduct    = $mdeduct
						    AND drate=(SELECT drate
						                 FROM ca_rate_date
						                WHERE icode  = $irate
						                  AND itable = 'cover_vs_premium');
						if (SQLCODE==SQLNOTFOUND)  mbase = 0.0;
					}
	                else if(strcmp(trim(iins_type),"62") == 0 || strcmp(trim(iins_type),"63") == 0 || strcmp(trim(iins_type),"64") == 0)
	                {
	                    $char fcheck626364_1[2];
	                    $long mcover1_626364=0;
	                    
	                    $SELECT case when drate >= date('12/01/2012') then '1' else '0' end
	                       INTO $fcheck626364_1
	                       FROM ca_rate_date
	                      WHERE icode  = $irate
	                        AND itable = 'cover_vs_premium';
	
	                    if (fcheck626364_1[0] == '0')
	                        mcover1_626364 = 0;
	                    else
	                        mcover1_626364 = minjured_cover;
	                
	                    $SELECT mpremium
						   INTO $mbase
						   FROM cover_vs_premium
						  WHERE icar_type  = $icar_type
						    AND iins_type  = $iins_type
	                        AND mcoverage1 = $mcover1_626364
						    AND mcoverage2 = $mdamage_cover
						    AND mdeduct    = $mdeduct
						    AND drate=(SELECT drate
						                 FROM ca_rate_date
						                WHERE icode  = $irate
						                  AND itable = 'cover_vs_premium');
	                    if (SQLCODE==SQLNOTFOUND)  mbase = 0.0;
	                }
	                else 
	                    mbase = 0.0;
				}
				else if (strcmp(trim(iins_type),"237") == 0)
				{
					$SELECT round(mpremium,4)
					   INTO $mbase
					   FROM cover_vs_premium
					  WHERE icar_type  = $icar_type AND iins_type  = $iins_type
					    AND mcoverage1 = $minjured_cover AND mcoverage2 = $mdamage_cover
					    AND mdeduct    = 0
					    AND drate= (SELECT drate
					                  FROM ca_rate_date 
					                 WHERE icode  = $irate
					                   AND itable = 'cover_vs_premium');
					if (SQLCODE==SQLNOTFOUND) mbase = 0.0;
				}
				else if (strcmp(trim(iins_type),"238") == 0)
				{
					$int iCar_age = 0;
					$char sProYM[11];
					$long lProYM = 0;
					if (qpro_month < 10)
						sprintf(sProYM,"0%d/01/%s",qpro_month,ipro_year);
					else
						sprintf(sProYM,"%d/01/%s",qpro_month,ipro_year);
						
					strcpy(sProYM,cm_from_infdate_100(sProYM));
					lProYM = cm_ymd_cdate(sProYM);  /* ����~���((y)yy/mm/dd)�নDate(long) */
					iCar_age=DiffMonth(dply_begin,lProYM);
					
					if ( (strncmp(icar_type,"01",2) == 0) ||
                         (strncmp(icar_type,"02",2) == 0) ||
                         (strncmp(icar_type,"32",2) == 0) ||
                         (strncmp(icar_type,"34",2) == 0) )
                    {
						if (iCar_age <  3*12)
                            iCar_age = 3;
						printf("����");
                    }
                    else
                    {
                        if (iCar_age <  3*12)
                            iCar_age = 3;
                        else if (iCar_age <  10*12)
                            iCar_age = 10;
                        else if (iCar_age <  15*12)
                            iCar_age = 15;
                        else 
                            iCar_age = 99;
						printf("�T��");
                    }
                    iCar_age = qday * 100 + iCar_age;
                    
                    printf("iCar_age[%d] \n",iCar_age);

					$SELECT round(mpremium,4)
					   INTO $mbase
					   FROM cover_vs_premium a
					  WHERE a.icar_type = $icar_type
					    AND a.iins_type = $iins_type
					    AND a.mcoverage1 = $minjured_cover
					    AND a.mcoverage2 = $mdamage_cover
					    AND drate = (SELECT drate
					                   FROM ca_rate_date
					                  WHERE icode = $irate
					                    AND itable = 'cover_vs_premium')
					    AND mdeduct = (select max(mdeduct) from cover_vs_premium
					                   where icar_type = a.icar_type
					                     and iins_type = a.iins_type
					                     and mcoverage1 = a.mcoverage1
					                     and mcoverage2 = a.mcoverage2
					                     and drate = a.drate
					                     and mdeduct = $iCar_age
					                     and ((mdeduct- mod(mdeduct,$qday))/100 = $qday));
					if (SQLCODE==SQLNOTFOUND) mbase = 0.0;
				}
				else 
				{
					if(strcmp(trim(iins_type),"47") == 0  || strcmp(trim(iins_type),"110") == 0 || strcmp(trim(iins_type),"112") == 0 ||
					   strcmp(trim(iins_type),"117") == 0 || strcmp(trim(iins_type),"147") == 0 || strcmp(trim(iins_type),"22") == 0)
					{
						$long tmp_mcoverage2;
						if(strcmp(trim(iins_type),"47") == 0  || strcmp(trim(iins_type),"117") == 0 || strcmp(trim(iins_type),"147") == 0)
						{
							tmp_mcoverage2 = mdeath_cover ;
						}
	                    else
						{
							tmp_mcoverage2 = mdamage_cover ;
						}
	
						$SELECT round(mpremium,4)
		                   INTO $mbase
		                   FROM cover_vs_premium
		                  WHERE icar_type  = $icar_type
		                    AND iins_type  = $iins_type
		                    AND mcoverage1 = $minjured_cover
		                    AND mcoverage2 = $tmp_mcoverage2
		                    AND mdeduct    = 1
		                    AND drate=(SELECT drate
		                                 FROM ca_rate_date
		                                WHERE icode  = $irate
		                                  AND itable = 'cover_vs_premium');
						if (SQLCODE==SQLNOTFOUND) mbase = 0.0;
						
						if (strncmp(icar_type,"01",2) ==0 || strncmp(icar_type,"02",2) ==0 || strncmp(icar_type,"32",2) ==0 || strncmp(icar_type,"34",2) ==0)
						{
							$SELECT round(mpremium,4)
			                   INTO $mbase
			                   FROM cover_vs_premium
			                  WHERE icar_type  = $icar_type
			                    AND iins_type  = $iins_type
			                    AND mcoverage1 = $minjured_cover
			                    AND mcoverage2 = $tmp_mcoverage2
			                    AND mdeduct    = 2
			                    AND drate=(SELECT drate
			                                 FROM ca_rate_date
			                                WHERE icode  = $irate
			                                  AND itable = 'cover_vs_premium');
							if (SQLCODE==SQLNOTFOUND) mbase = 0.0;
						}
					}
					else if (strcmp(trim(iins_type),"57") == 0  || strcmp(trim(iins_type),"59") == 0 || strcmp(trim(iins_type),"60") == 0)
					{
	                    if (minjured_cover == 0)
	                        mbase1 = 0.0;
	                    else 
	                    {
	                        $SELECT round(mpremium,4)
	                           INTO $mbase1
	                           FROM cover_vs_premium
	                          WHERE icar_type  = $icar_type
	                            AND iins_type  = $iins_type
	                            AND mcoverage1 = $minjured_cover
	                            AND mcoverage2 = 0
	                            AND mdeduct    = 0
	                            AND drate=(SELECT drate
	                                         FROM ca_rate_date
	                                        WHERE icode  = $irate
	                                          AND itable = 'cover_vs_premium');
	                        if (SQLCODE==SQLNOTFOUND) mbase1 = 0.0;
						}
						
						$SELECT round(mpremium,4)
		                   INTO $mbase2
		                   FROM cover_vs_premium
		                  WHERE icar_type  = $icar_type
		                    AND iins_type  = $iins_type
		                    AND mcoverage1 = 0
		                    AND mcoverage2 = $mdeath_cover
		                    AND mdeduct    = 0
		                    AND drate=(SELECT drate
		                                 FROM ca_rate_date
		                                WHERE icode  = $irate
		                                  AND itable = 'cover_vs_premium');
						if (SQLCODE==SQLNOTFOUND) mbase2 = 0.0;
						
						mbase = mbase1 + mbase2;
					}
					else if (strcmp(trim(iins_type),"79") == 0 || strcmp(trim(iins_type),"89") == 0 || strcmp(trim(iins_type),"90") == 0)
					{
						$SELECT round(mpremium,4)
		                   INTO $mbase
		                   FROM cover_vs_premium
		                  WHERE icar_type  = $icar_type
		                    AND iins_type  = $iins_type
		                    AND mcoverage2 = $mdamage_cover
		                    AND drate=(SELECT drate
		                                 FROM ca_rate_date
		                                WHERE icode  = $irate
		                                  AND itable = 'cover_vs_premium');
						if (SQLCODE==SQLNOTFOUND) mbase = 0.0;
							
					}
					else if (strcmp(trim(iins_type),"80") == 0)
					{
						$SELECT round(mpremium,4)
		                   INTO $mbase
		                   FROM cover_vs_premium
		                  WHERE icar_type  = $icar_type
		                    AND iins_type  = $iins_type
		                    AND mcoverage1 = $minjured_cover
		                    AND mcoverage2 = $mdamage_cover
		                    AND drate=(SELECT drate
		                                 FROM ca_rate_date
		                                WHERE icode  = $irate
		                                  AND itable = 'cover_vs_premium');
						if (SQLCODE==SQLNOTFOUND) mbase = 0.0;
					}
					else 
					{
						$SELECT round(mpremium,4)
		                   INTO $mbase
		                   FROM cover_vs_premium
		                  WHERE icar_type  = $icar_type
		                    AND iins_type  = $iins_type
		                    AND mcoverage1 = $minjured_cover
		                    AND mcoverage2 = $mdeath_cover
		                    AND drate=(SELECT drate
		                                 FROM ca_rate_date
		                                WHERE icode  = $irate
		                                  AND itable = 'cover_vs_premium');
						if (SQLCODE==SQLNOTFOUND) mbase = 0.0;	
					}	
				}
			}
		}
	}
	else if (fcal_way[0] == '4')
	{
		if(strcmp(trim(iins_type),"105") == 0 || strcmp(trim(iins_type),"118") == 0 ||
		   strcmp(trim(iins_type),"120") == 0 || strcmp(trim(iins_type),"85") == 0)
		{
			/*ca_rate & cover_premium*/
			if (strcmp(icar_type,"05")==0 || strcmp(icar_type,"06")==0 || strcmp(icar_type,"09")==0 ||
			    strcmp(icar_type,"10")==0 || strcmp(icar_type,"20")==0)
			    ca_rate_qpt = qpt;
			else 
				ca_rate_qpt = 0;
			
			if (fpt[0] == 'P')
			{
				$SELECT case WHEN mprem > 0 THEN round(mprem,4) else round(prate,4) END
				   INTO $mbase1
				   FROM ca_rate
				  WHERE icar_type = $icar_type
				    AND iins_type = $iins_type
				    AND mdeduct = $mdeduct
				    AND qpt_bgn <= $ca_rate_qpt
				    AND qpt_end >= $ca_rate_qpt
				    AND drate = (SELECT drate 
				                   FROM ca_rate_date
				                  WHERE icode = $irate 
				                    AND itable = 'ca_rate');
				if (SQLCODE==SQLNOTFOUND) mbase = 0.0;
			}
			else
			{
				if (strcmp(icar_type,"06")==0 || strcmp(icar_type,"10")==0 || strcmp(icar_type,"20")==0)
				{
					$SELECT case WHEN mprem > 0 THEN round(mprem,4) else round(prate,4) END
					   INTO $mbase1
					   FROM ca_rate
					  WHERE icar_type = $icar_type
					    AND iins_type = $iins_type
					    AND qpt_bgn < $ca_rate_qpt
					    AND qpt_end >= $ca_rate_qpt
					    AND mdeduct = $mdeduct
					    AND drate = (SELECT drate 
					                   FROM ca_rate_date
					                  WHERE icode = $irate 
					                    AND itable = 'ca_rate');
					if (SQLCODE==SQLNOTFOUND) mbase1 = 0.0;
				}
				else
				{
					$SELECT case WHEN mprem > 0 THEN round(mprem,4) else round(prate,4) END
					   INTO $mbase1
					   FROM ca_rate
					  WHERE icar_type = $icar_type
					    AND iins_type = $iins_type
					    AND mdeduct = $mdeduct
					    AND qpt_bgn <= $ca_rate_qpt
					    AND qpt_end >= $ca_rate_qpt
					    AND drate = (SELECT drate 
					                   FROM ca_rate_date
					                  WHERE icode = $irate 
					                    AND itable = 'ca_rate');
					if (SQLCODE==SQLNOTFOUND) mbase1 = 0.0;	
				}
			}
			
			if(strcmp(trim(iins_type),"105") == 0 || strcmp(trim(iins_type),"118") == 0 || 
			   strcmp(trim(iins_type),"152") == 0 || strcmp(trim(iins_type),"153") == 0)
			{
                if ((strcmp(icar_type,"03")==0 || strcmp(icar_type,"04")==0 || strcmp(icar_type,"21")==0 ||
			         strcmp(icar_type,"22")==0 || strcmp(icar_type,"19")==0 || strcmp(icar_type,"07")==0 ||
                     strcmp(icar_type,"08")==0 || strcmp(icar_type,"14")==0 || strcmp(icar_type,"15")==0) ||
                    ((ISNEW_CAR1(icar_type))  || (ISNEW_CAR2(icar_type))))
                {
                	mbase1 = 0;
                	if (strcmp(trim(iins_type),"152") == 0 || strcmp(trim(iins_type),"153") == 0)
                	{
	                    $SELECT round(mpremium,4)
	                       INTO $mbase2
	                       FROM cover_vs_premium
	                      WHERE icar_type  = $icar_type
	                        AND iins_type  = $iins_type
	                        AND mcoverage1 = $mdamage_cover
	                        AND drate      = (SELECT drate
	                                            FROM ca_rate_date
	                                           WHERE icode = $irate
	                                             AND itable = 'cover_vs_premium');
	                    if (SQLCODE==SQLNOTFOUND)  mbase2 = 0.0;
                	}
                	else
                	{
	                    $SELECT round(mpremium,4)
	                       INTO $mbase2
	                       FROM cover_vs_premium
	                      WHERE icar_type  = $icar_type
	                        AND iins_type  = $iins_type
	                        AND mcoverage1 = $minjured_cover
	                        AND drate      = (SELECT drate
	                                            FROM ca_rate_date
	                                           WHERE icode = $irate
	                                             AND itable = 'cover_vs_premium');
	                    if (SQLCODE==SQLNOTFOUND)  mbase2 = 0.0;
                	}
                }
                else
                    mbase2 = 0.0;
            }
            else if (strcmp(trim(iins_type),"85") == 0) 
            {
					$char f1010515[2];
					$SELECT case WHEN drate >= (SELECT date(detail2) 
					                              FROM car_code
					                             WHERE kind = '22'
					                               AND detail='01')
					             THEN '1' ELSE '0' END
					   INTO $f1010515
					   FROM ca_rate_date
					  WHERE icode  = $irate
					    AND itable = 'cover_vs_premium';
					
					$SELECT mpremium, mpremium
					   INTO $mbase2_1, $mbase2_2
					   FROM cover_vs_premium
					  WHERE icar_type  = $icar_type
					    AND iins_type  = $iins_type
					    AND mcoverage1 = $minjured_cover
					    AND drate      = (SELECT drate
					                        FROM ca_rate_date
					                       WHERE icode = $irate
	                                         AND itable ='cover_vs_premium');
                                         
	                if (f1010515[0] == '1')
	                {
	                    mbase2_1 = 0.0;
	                }
	                else
	                {
	                    mbase2_2 = 0.0;
	                }
	                mbase2 = mbase2_1 + mbase2_2;
	                
	            if ((strcmp(icar_type,"03")==0 || strcmp(icar_type,"04")==0 || strcmp(icar_type,"21")==0 ||
			         strcmp(icar_type,"22")==0 || strcmp(icar_type,"19")==0 || strcmp(icar_type,"07")==0 ||
                     strcmp(icar_type,"08")==0 || strcmp(icar_type,"14")==0 || strcmp(icar_type,"15")==0) ||
                    ((ISNEW_CAR1(icar_type))  || (ISNEW_CAR2(icar_type))))
                {
                	/* Do nothing */
                }
	            else
	            {
	            	mbase1 = 0.0;
	            }
            }
            else 
            	mbase2 = 0.0;
            	
			mbase = mbase1 + mbase2;
		}
		else 
			mbase = 0.0;
	}
	else 
		mbase = 0.0;
	
	*mprem_base = mbase;
	printf("mprem_base[%f]\n",*mprem_base);

	return M_CM_OK;

errexit:

  /*sprintf( v_sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);*/
  sprintf( v_sMsg,"SQLCODE=%d:irate=%s,icar_type=%s,iins_type=%s,minjured_cover=%ld,mdamage_cover=%ld,mdeduct=%ld\n",
    	   SQLCODE, irate,icar_type,iins_type,minjured_cover,mdamage_cover,mdeduct);	

  return SQLCODE;

}

int IsBlankNull(str)
char *str;
{
    while (*str)
    {
        if (*str!=' ') return FALSE;
        str++;
    }
    return TRUE;
}

double d45(num,num1)
double num;
int num1;
{
    long tmplong;
    double var1;
    double ten;
    int i;

    ten = 1;
    for(i = 1 ;i<=num1;i++)
    ten *= 10;

    num *= ten;
    if (num >= 0) var1 = 0.500000000001;
    else var1 = (-0.500000000001);

    num = num + var1;
    tmplong = num;

    num = tmplong/ten;
    return(num);
}