/**********************************************************************/
/*   program id   : ca625q01s.ec                                      */
/*   program name : ���رM�׸�Ƥ��@�~                              */
/*   date written : 2002/06/12                                        */
/*   date modify  : 2003/03/10 ��!�n�I�M��                            */
/*   date modify  : 2004/05/28 CAR�O�I�M��                            */
/*   files        : ply_relation        i                             */
/*                  ply_ins_type        i                             */
/*                  policy              i                             */
/*   temp table   : car625              io                            */
/*   Checked for ����100�~�M��                                        */
/**********************************************************************/
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>

/*--------------------------------------------------------------------*/
char    option[1],iprmt[11],checkD[1];
$char   icd[2][21], iply[2][21],icard[21],ipolicy[21],iendorse[21];
$char   iply_comp[21],icd_comp[21];
$char   ibig_sales[11],itag[CA_TAG_NUM],ibrand[9],iengine[21],ibig_office[10];
$char   nassured[121],iassured[13],dpolicy[11],iissue_ym[7];
$char   iofficer[11],iresource[2],iins_type[7],nofficer[11],fedr_class[2];
$char   ioff[2][11],noff[2][11],dendorse[11],ioff1[2],ibigo[2][10];
$char   nbrand[31],iquota[7],nquota[21],fcard_class[2];
$char   nsales[11],ipro_year[5],icar_type[3],ncar_abbr[13];
$char   dbgn1[11],dend1[11],remark[2];
$char   dbgn2[11],dend2[11],dply_begin[11];
$char   napplicant[121],iapplicant[13];
$long   mprem_dmg,mprem_02,mprem_11,mprem_31,mprem_51,mprem_oth;
$long   mprem_dmgd,mprem_02d,mprem_11d,mprem_31d,mprem_51d,mprem_othd;
$long   mprem_09,mprem_09_edr,mprem_edr,mprem_edr1,mprem_21d;
$long   mprem_21,mprem,mexp_edr,mexp_edr1,mprem_ori,mlia_prem;
$int    x,flag_01,x_cnt,comp_cnt;
int     iins,iclass,fcomp_only;
$double rSafe_dmg, rSafe_02, rSafe_11, rSafe_31, rSafe_51, rSafe_oth, rSafe_09;
$double rMgmt_dmg, rMgmt_02, rMgmt_11, rMgmt_31, rMgmt_51, rMgmt_oth, rMgmt_09;

$char   sdata[24][41];

int     flen,cnt;
int     cnt_s,cnt_f;
FILE    *fp;
char    sApHome[30];
char    filename[50],fulldb[31];

$char   DBName[05];
char    outputf[N_FILE+1], userid[11];

char    msgbuf[100];
/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{  
int   rc;
   batchinit();
   strcpy(DBName, isNULLstr(argv[1]));
   strcpy(userid, isNULLstr(argv[2]));
   strcpy(option, isNULLstr(argv[3]));
   strcpy(iprmt,  isNULLstr(argv[4]));
   strcpy(dbgn2,  isNULLstr(argv[5]));
   strcpy(dend2,  isNULLstr(argv[6]));
   strcpy(checkD, isNULLstr(argv[7]));
   strcpy(outputf,isNULLstr(argv[8]));

   if (dbgn2[0]=='*') {
      strcpy(dbgn1,dbgn2);
      strcpy(dend1,dend2);
   }
   else {
      strcpy(dbgn1, cm_to_infdate(dbgn2));
      strcpy(dend1, cm_to_infdate(dend2));  
   }

   if (option[0]=='1') {   /* TOBE�M�� ca625q02s.ec */
      rc = car6251(DBName,userid,dbgn1,dend1,checkD,outputf);
      if (rc != SUCCESS) {
         EWRITE(userid,rc,msgbuf);
      }
      return rc;
   }
   
/***********
   if (option[0]=='2') {
      rc = car6252(DBName,userid,outputf);
      if (rc != SUCCESS) {
         EWRITE(userid,rc,msgbuf);
      }
      return rc;
   }
************/
   
   if (option[0]=='3') { 
      if (iprmt[0]=='C') { /* ���ثP�P�M�� ca625q05s.ec */
         rc = car6255(DBName,userid,iprmt,dbgn1,dend1,checkD,outputf);
         if (rc != SUCCESS) {
            EWRITE(userid,rc,msgbuf);
         }
      }
      else { /* �P�P�M�� ca625q03s.ec */
         rc = car6253(DBName,userid,iprmt,dbgn1,dend1,checkD,outputf);
         if (rc != SUCCESS) {
            EWRITE(userid,rc,msgbuf);
         }
      }
      return rc;
   }
   
   if (option[0]=='7') { 
      rc = car6257(DBName,userid,iprmt,dbgn1,dend1,checkD,outputf);
      return rc;
   }
   
   if (option[0]=='4') {   /* ������Ƥ�� ca625q04s.ec */
      rc = car6254(DBName,userid,dbgn1,dend1,outputf);
      return rc;
   }

   if (option[0]=='6') {   /* �Ȥ�ID��� ca625q06s.ec */
      rc = car6256(DBName,userid,dbgn1,dend1,outputf);
      return rc;
   }
   
   /* ���رM�� */
   rc = car625_get_db();
   if (rc != SUCCESS) {
      EWRITE(userid,rc,msgbuf);
      return rc;
   }

   rc = car625_build();
   if (rc != SUCCESS) {
      EWRITE(userid,rc,msgbuf);
      return rc;
   }

   rc = car625_build1();
   if (rc != SUCCESS) {
      EWRITE(userid,rc,msgbuf);
      return rc;
   }

   rc = car625_build2();
   if (rc != SUCCESS) {
      EWRITE(userid,rc,msgbuf);
      return rc;
   }

   if (checkD[0]=='1') {
      rc = car625_build3();
      if (rc != SUCCESS) {
         EWRITE(userid,rc,msgbuf);
         return rc;
      }
   }
   return rc;
}
/*--------------------------------------------------------------------*/
long car625_get_db()
{
   int  rc;

   if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }

   rc = getApHome(sApHome);
   if (rc < 0) {
       strcpy(msgbuf,"read Config file error!!-->getApHome\n");
       EWRITE(userid,rc,msgbuf);
       return rc;
    }
    
   return SUCCESS;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car625_build()
{
int    rc;
char   sfilename[51],stitle[1024],stmt[1024];
   
   $whenever sqlerror goto errexit;

   rc = car625_read_file(); /* Ū��text file */
   if (rc != SUCCESS)
      return rc;

   sprintf(sfilename,"���رM�פ��@�~--��異��  %s",cm_get_sysd());
   strcpy(stitle,
   "����~��\t�q��s��\t�w���渹�X\t�q���s��\t�q�����O\t���q�O\t�ϰ쳡�N�X\t�ϰ쳡�W��\t�~�Z���N�X\t�~�Z���W��\t�~�Z�~�N�N�X\t�~�Z�~�N�W��\t���ئW��\t�����W��\t�Ө����N�X\t�g�P�Ө���\t����\t�������X\t�q����\t�樮���\t��P���\t�P�Ӹ��X \t��ĳ���\t");
   strcpy(stmt,"select * from car625_0");
   unload_file(outputf,"A",sfilename,stitle,stmt);
   if (rc != SUCCESS) {
      sprintf(msgbuf," %s �ɮ׵L�k���� ",sfilename);
      return rc;
   }
 
   return SUCCESS;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car625_build1()
{
int    rc=1;
char   sfilename[51],stitle[2048],stmt[3072];
   
   $whenever sqlerror goto errexit;

   sprintf(sfilename,"���رM�פ��@�~--���ݢ�  %s",cm_get_sysd());
   strcpy(stitle,
   "���N�X\t�~�Z���\t�O�d���X�@\t�O�渹�X�@\t�O�d���X�G\t�O�渹�X�G\t�Q�O�I�H�N��\t�Q�O�I�H�W��\t�n�O�HID\t�n�O�H�W��\tñ����\t�_�O���\t����\t\���ئW��\t�t���N��\t�t�P�����W��\t�������X\t�o�Ӧ~��\t�g�P�Ӥ@\t�g��N���@\t���I�N���@\t���I�W�٤@\t�g��N���G\t���I�N���G\t���I�W�٤G\t�~�N�N��\t�~�N�W��\t�P�Ӹ��X\t�����I�O�O\t�䭷�x���I�O�O\t�ѵs�I�O�O\t�d���I�O�O\t�����I�O�O\t��L���N�I�O�O\t�j���I�O�O\t���N����\t��渹�X\t���O�O\t�j��O�渹\t�j���Ҹ�\t�j����\t�����I�޲z���I�[��T��\t�䭷�x���I�޲z���I�[��T��\t�ѵs�I�޲z���I�[��T��\t�d���I�޲z���I�[��T��\t�����I�޲z���I�[��T��\t��L���N�I�޲z���I�[��T��\t�����I�w�����I�[��T��\t�䭷�x���I�w�����I�[��T��\t�ѵs�I�w�����I�[��T��\t�d���I�w�����I�[��T��\t�����I�w�����I�[��T��\t��L���N�I�w�����I�[��T��\t");
   strcpy(stmt,
   "select iquota, (select nvl(nbranch,' ') from sa_branch_type where ibranch=iquota),\
           icard1,ipolicy1,icard2,ipolicy2,iassured,nassured,iapplicant,napplicant,\
           dpolicy,dply_begin,icar_type,ncar_abbr,ibrand,\
           (select nvl(ncode,' ') from cm_group \
           where igroup = '04' and icode = ibrand),iengine,iissue_ym, \
           decode(a.iofficer1[7,8],'IF','����','IS','���q',' '), \
           iofficer1,ibig_office1,\
           decode(a.iofficer1[7,8],'IF',(select nvl(nname,'���I���~') \
           from officer where iofficer[1]='B' and ibus_location=ibig_office1),\
           'IS',(select nvl(nname,'���I���~') from officer where \
           iofficer[1]='J' and ibus_location=ibig_office1),' '),\
           iofficer2,ibig_office2,\
           (select nvl(nname,' ') from officer where iofficer=iofficer2),\
           ibig_sales, (select nvl(nname,' ') from ca_big_office \
           where fclass = '2' and ibig_comp=a.ibig_sales), \
           itag,mprem_dmg,mprem_02,mprem_11,\
           mprem_31,mprem_51,mprem_oth,mprem_21,ply_cnt,iendorse,mprem_edr,\
           iply_comp,icd_comp,comp_cnt, \
           rSafe_dmg,rSafe_02,rSafe_11,rSafe_31,rSafe_51,rSafe_oth, \
           rMgmt_dmg,rMgmt_02,rMgmt_11,rMgmt_31,rMgmt_51,rMgmt_oth \
           from car625 a order by 1,2");
   unload_file(outputf,"B",sfilename,stitle,stmt); 
   if (rc != SUCCESS) {
       sprintf(msgbuf," %s �ɮ׵L�k���� ",sfilename);
       return rc;
   }

   return SUCCESS;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car625_build2()
{
int    rc=1;
char   sfilename[51],stitle[1024],stmt[2048];
   
   $whenever sqlerror goto errexit;

   sprintf(sfilename,"���رM�׽дک��Ӹ�ƪ�  %s",cm_get_sysd());
   strcpy(stitle,
   "���N�X\t�~�Z���\t�j����N�O\t�O�d���X\t�O�渹�X\t�Q�O�I�H�N��\t�Q�O�I�H�W��\t�n�O�HID\t�n�O�H�W��\tñ����\t�_�O���\t����\t���ئW��\t�t���N��\t�t�P�����W��\t�������X\t�o�Ӧ~��\t�g��N��\t���I�N��\t���I�W��\t�~�N�N��\t�~�N�W��\t�P�Ӹ��X\t���郞�O�O\t�ɯūO�O\t�ѵs�I�O�O\t�d���I�O�O\t�����I�O�O\t�j���I�O�O\t���O\t�O�浧��\t��渹�X\t���郞�޲z���I�[��T��\t�ѵs�I�޲z���I�[��T��\t�d���I�޲z���I�[��T��\t�����I�޲z���I�[��T��\t���郞�w�����I�[��T��\t�ѵs�I�w�����I�[��T��\t�d���I�w�����I�[��T��\t�����I�w�����I�[��T��\t");
   strcpy(stmt,
   "select iquota, (select nbranch from sa_branch_type where ibranch=iquota),\
           fcard_class,icard,ipolicy,iassured,nassured,iapplicant,napplicant,\
           dpolicy,dply_begin,icar_type,ncar_abbr,ibrand,\
           (select ncode from cm_group where igroup = '04' \
           and icode = ibrand),\
           iengine,iissue_ym,iofficer,ibig_office,\
           decode(iofficer[7,8],'IF',(select nname from officer \
           where iofficer[1]='B' and ibus_location=ibig_office),\
           'IS',(select nname from officer where iofficer[1]='J' and \
           ibus_location=ibig_office),(select nname from officer \
           where iofficer=a.iofficer)), \
           ibig_sales,(select nname from ca_big_office \
           where fclass ='2' and ibig_comp = a.ibig_sales),\
           itag,mprem_09,mprem_09_edr,mprem_11,mprem_31,mprem_51,mprem_21,remark,\
           ply_cnt,iendorse,rSafe_09,rSafe_11,rSafe_31,rSafe_51, \
           rMgmt_09,rMgmt_11,rMgmt_31,rMgmt_51 \
           from car625_1 a order by 1,11,2 ");
   unload_file(outputf,"C",sfilename,stitle,stmt); 
   if (rc != SUCCESS) {
      sprintf(msgbuf," %s �ɮ׵L�k���� ",sfilename);
      return rc;
   }

   return SUCCESS;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car625_build3()
{
int    rc=1;
char   sfilename[51],stitle[1024],stmt[2048];
   
   $whenever sqlerror goto errexit;

   rc = car625_body3();
   if (rc != SUCCESS)
      return rc;

   sprintf(sfilename,"���رM�פ��@�~--���صL���  %s",cm_get_sysd());
   strcpy(stitle,
   "�~�Z���\t�O�d���X\t�O�渹�X\t�Q�O�I�H�N��\t�Q�O�I�H�W��\t�n�O�HID\t�n�O�H�W��\tñ����\t�_�O���\t����\t���ئW��\t�t���N��\t�t�P�����W��\t�������X\t�o�Ӧ~��\t�g��N��\t���I�N��\t���I�W��\t�~�N�N��\t�~�N�W��\t�P�Ӹ��X\t�����I�O�O\t���d�I�O�O\t���O�O\t");
   strcpy(stmt,"select * from car625_2 order by 1,2");
   unload_file(outputf,"D",sfilename,stitle,stmt); 
   if (rc != SUCCESS) {
      sprintf(msgbuf," %s �ɮ׵L�k���� ",sfilename);
      return rc;
   }

   return SUCCESS;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car625_read_ply()
{
int    first,rc,y,iins;
$char  stmt[1224],stmt1[1224],stmtdt[81],stmt2[1024];
$char  nequipment[31];
$double tmp_safe=0, tmp_manage=0;

   $whenever sqlerror goto errexit;

   if (dbgn1[0]=='*')
      strcpy(stmtdt," ");
   else
      sprintf(stmtdt," and dpolicy between '%s' and '%s' ",dbgn1,dend1);

   $declare cur_vs cursor for
     select ipolicy,icard,iassured,itag,fcard_class
       into $ipolicy,$icard,$iassured,$itag,$fcard_class
       from assured_vs_ply
      where iengine = $iengine
      order by fcard_class,ipolicy;
   $open cur_vs;
   x=0;
   first=1;
   comp_cnt=0;
   fcomp_only=1;
   for (y=0;y<2;y++) {
       strcpy(icd[y]," ");
       strcpy(iply[y]," ");
       strcpy(ioff[y]," ");
       strcpy(ibigo[y]," ");
   }
   strcpy(iply_comp," " );
   strcpy(icd_comp," ");
   while(1) {
      $fetch cur_vs;
      if (SQLCODE==SQLNOTFOUND) {
         if (first) {
            rc=car625_write_data_0();
            if (rc!=SUCCESS)
               return rc;
            break;
         }
         else { 
            if (fcomp_only) {
               rc=car625_write_comp();
               if (rc!=SUCCESS)
                  return rc;
               break;
            }  
            else {
               rc=car625_write_data();
               if (rc!=SUCCESS)
                  return rc;
               break;
            }
         } 
      }
      printf("ipolicy[%s]\n",ipolicy);
      if (first) {
         mprem_dmg=mprem_02=mprem_11=mprem_oth=0;
         mprem_21=mprem_edr=mprem_51=mprem_31=0;
         x_cnt=0;
      }  
      strcpy(fulldb,get_car_full_db(ipolicy));
      iclass=atoi(fcard_class);
      mprem_09=mprem_09_edr=flag_01=0;
      mprem_dmgd=mprem_02d=mprem_11d=mprem_31d=mprem_51d=0;
      mprem_othd=mprem_21d=0;
      strcpy(iendorse," ");
      sprintf(stmt,
             "select iquota[1,4] || '00',dpolicy,dply_begin,ibrand, \
                     to_char(b.dissue,'%%Y')::integer - 1911 || '/' || to_char(b.dissue,'%%m'), \
                     iofficer,a.iresource,ibig_sales,fedr_class, \
                     nequipment,nvl(dendorse,' '),ibig_office, \
                     mlia_prem,icar_type,(select ncode from car_type \
                     where fclass = '1' and icode = icar_type), \
                     nassured[1,40],iapplicant,napplicant[1,40] \
                from %s:ply_relation a,%s:policy b \
               where a.ipolicy = ? %s \
                 and a.ipolicy = b.ipolicy \
                 and fedr_class != '1' ",fulldb,fulldb,stmtdt); 
      printf("stmt[%s]\n",stmt);
      $prepare pre_2 from $stmt;
      $execute pre_2 into $iquota,$dpolicy,$dply_begin,$ibrand,
                     $iissue_ym,$iofficer,$iresource,$ibig_sales,$fedr_class,
                     $nequipment,$dendorse,$ibig_office,$mlia_prem,
                     $icar_type,$ncar_abbr,$nassured,$iapplicant,$napplicant
               using $ipolicy;
      if (SQLCODE == SQLNOTFOUND) continue;

      if (equip_cmp(nequipment,"27") == TRUE)
      {
          strcpy(remark,"1");
      }
      else
      {
          strcpy(remark,"0");
      }

      if (first) first=0;
      if (strncmp(fedr_class,"1",1)==0) continue;
      if (iclass==1) {
         mprem_21 += mlia_prem;
         mprem_21d = mlia_prem;
         strcpy(iply_comp,ipolicy);
         strcpy(icd_comp,icard);
         comp_cnt++;
         rc=car625_write_data_1();
         if (rc!=SUCCESS)
            return rc;
         continue;
      }
      fcomp_only=0;
      /* �M�ץ�P�_�s�WH�g����ư�H0-H2  modify by sylvia 103.01.17 (1021122001_C1)
                   �s�WN�g��A�~�Ȩӷ���E (1030630002_C4) */
      /* if (strncmp(iofficer,"W",1) == 0) */
      if ((strncmp(iofficer,"W",1) == 0) ||
      	  ((strncmp(iofficer,"H",1) == 0) && (strncmp(iofficer,"H0",2) != 0) &&
      	   (strncmp(iofficer,"H1",2) != 0) && (strncmp(iofficer,"H2",2) != 0)) ||
      	  ((strncmp(iofficer,"N",1) == 0) && (strncmp(iresource,"E",1) == 0)))
      { 
      	 printf("iofficer=[%s]\t iresource=[%s]\n",iofficer,iresource);
         strcpy(iply[0],ipolicy);
         strcpy(icd[0],icard);
         strcpy(ioff[0],iofficer);
         strcpy(ibigo[0],ibig_office);
      }
      else {
         if (x<2) {
            strcpy(iply[1],ipolicy);
            strcpy(icd[1],icard);
            strcpy(ioff[1],iofficer);
            strcpy(ibigo[1],ibig_office);
         }
      }
      x++;
      sprintf(stmt1,
      "select nvl(sum(decode(iins_type,\
              '01',mins_premium,'05',mins_premium,'08',mins_premium,\
              '09',mins_premium,0)),0),\
              nvl(sum(decode(iins_type,'02',mins_premium,0)),0),\
              nvl(sum(decode(iins_type,'11',mins_premium,0)),0),\
              nvl(sum(decode(iins_type,'31',mins_premium,\
              '32',mins_premium,0)),0),\
              nvl(sum(decode(iins_type,'51',mins_premium,0)),0),\
              nvl(sum(decode(iins_type,'01',0,'02',0,'05',0,'08',0,\
              '09',0,'11',0,'31',0,'32',0,'51',0,mins_premium)),0) \
          from %s:ply_ins_type \
         where ipolicy = ? ",fulldb);
      printf("stmt1[%s]\n",stmt1);
      $prepare pre_2d from $stmt1;
      $execute pre_2d into $mprem_dmgd,$mprem_02d,$mprem_11d,
                           $mprem_31d,$mprem_51d,$mprem_othd
                     using $ipolicy;
                      
      /* ����w��/�޲z���I�[��T�� */
         sprintf(stmt2,"select iins_type,safe_rate,manage_rate from %s:ply_ins_type \
                  where ipolicy = ? order by iins_type desc",fulldb);
         printf("stmt2[%s]\n",stmt2);
         $prepare pre_3d from $stmt2;
         $declare cur_3d cursor for pre_3d;
         $open    cur_3d using $ipolicy;
         while(1) {
            $fetch cur_3d into $iins_type,$tmp_safe,$tmp_manage;
            if (SQLCODE==SQLNOTFOUND) break;
            iins=atoi(iins_type);
            switch(iins) {
               case 1: case 5: case 8: case 9:
                  rSafe_dmg = tmp_safe;
                  rMgmt_dmg = tmp_manage;
                  if (iins==9)
                  {
                  	rSafe_09 = tmp_safe;
                  	rMgmt_09 = tmp_manage;
                  }
                  break;
               case 2:
                  rSafe_02 = tmp_safe;
                  rMgmt_02 = tmp_manage;
                  break;
               case 11:
                  rSafe_11 = tmp_safe;
                  rMgmt_11 = tmp_manage;
                  break;
               case 31: case 32:
                  rSafe_31 = tmp_safe;
                  rMgmt_31 = tmp_manage;
                  break;
               case 51: case 55: 
                  rSafe_51 = tmp_safe;
                  rMgmt_51 = tmp_manage;
                  break;
               default:
                  rSafe_oth = tmp_safe;
                  rMgmt_oth = tmp_manage;
                  break;
            }
         }
         $close cur_3d;
         $free cur_3d;
      /* end of ����w��/�޲z���I�[��T�� */
                                 
      printf("iofficer[%s]\n",iofficer);
      
      /* �M�ץ�P�_�s�WH�g����ư�H0-H2  modify by sylvia 103.01.17 (1021122001_C1)
                   �s�WN�g��A�~�Ȩӷ���E (1030630002_C4) */
      /* if (strncmp(iofficer,"W",1) == 0) */
      	if ((strncmp(iofficer,"W",1) == 0) ||
      		  ((strncmp(iofficer,"H",1) == 0) && (strncmp(iofficer,"H0",2) != 0) &&
      		   (strncmp(iofficer,"H1",2) != 0) && (strncmp(iofficer,"H2",2) != 0)) ||
      	  ((strncmp(iofficer,"N",1) == 0) && (strncmp(iresource,"E",1) == 0)))
      	{
         if (strncmp(dendorse[0]," ",1) != 0) {
             rc=car625_read_edr();
             if (rc!=SUCCESS)
                return rc;
         }
         /*---�O�O�� mprem_dmgd,mprem_51d---*/
         x_cnt++;
         rc=car625_write_data_1();
         if (rc!=SUCCESS)
            return rc;
      }
      mprem_dmg += mprem_dmgd;
      mprem_02  += mprem_02d;
      mprem_11  += mprem_11d;
      mprem_31  += mprem_31d;
      mprem_51  += mprem_51d;
      mprem_oth += mprem_othd;
   }
   $close cur_vs;
   $free  cur_vs;

   return SUCCESS;

errexit:
   sqlfatal();
   strcpy(msgbuf,sqlca.sqlerrm);
   return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car625_read_edr()
{
$char  stmt[1024],stmt1[512],iedr_type[3];
$int   first_edr;

   $whenever sqlerror goto errexit;

   mexp_edr=mexp_edr1=mprem_ori=0;
   sprintf(stmt,
           "select a.iendorse,iedr_type,medrins_prem,medr_expense \
              from %s:edr_relation a,%s:edr_ins_type b \
             where ipolicy = ? \
               and dedr_close is not null \
               and a.iendorse = b.iendorse \
               and iins_type = '09' ",fulldb,fulldb);
   $prepare pre_edr from $stmt;
   $declare cur_edr cursor for pre_edr;
   $open    cur_edr using $ipolicy;
   first_edr = 1;
   mprem_edr = 0;
   while(1) {
      $fetch cur_edr 
        into $iendorse,$iedr_type,$mprem_edr1,$mexp_edr1;
      if (SQLCODE == SQLNOTFOUND) break;
      first_edr = 0;
      if (strncmp(iedr_type,"02",2)!=0) {  /* ���~�h�O */
          mprem_edr += mprem_edr1;
          mexp_edr  += mexp_edr1;
      }
   }
   $close cur_edr;
   sprintf(stmt,
           "select mins_premium from %s:ori_ins_type \
             where ipolicy = ? and iins_type = '09' ",fulldb);
   $prepare pre_ori from $stmt;
   $execute pre_ori into $mprem_ori
                   using $ipolicy;
   if (first_edr) {
      mprem_09 = mprem_ori;
      mprem_09_edr = 0;
   }
   else {
      mprem_09 = mprem_ori + mprem_edr - mexp_edr;
      mprem_09_edr = mprem_dmgd - mprem_09;
   }
   return SUCCESS;

errexit:
   sqlfatal();
   strcpy(msgbuf,sqlca.sqlerrm);
   return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car625_body3()
{
DBinfo *list;
int    i,j,count_db,rc;
$int   cnt;
$char  stmt[2048],stmt1[1024];

  $whenever sqlerror goto errexit;

  if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
     if (EWRITE(userid, M_CM_NOT_DBLIST) == True)
        return M_CM_NOT_DBLIST;
     return M_CM_OK;
  }

  for(j=0;j<count_db;j++) {
     sprintf(stmt,
     "insert into car625_2 \
      select (select nbranch from sa_branch_type where ibranch=iquota),\
           a.icard,a.ipolicy,iassured,nassured[1,40],dpolicy,\
           dply_begin,icar_type,(select ncode from car_type \
           where fclass = '1' and icode = icar_type),ibrand, \
           (select ncode from cm_group where igroup = '04' \
           and icode = ibrand),iengine, \
           to_char(b.dissue,'%%Y')::integer - 1911 || '/' || to_char(b.dissue,'%%m'), \
           iofficer,ibig_office,\
           decode(iofficer[7,8],'IF',(select nname from officer \
           where iofficer[1]='B' and ibus_location=ibig_office),\
           'IS',(select nname from officer where iofficer[1]='J' \
           and ibus_location=ibig_office),' '),\
           ibig_sales,(select nname from ca_big_office where fclass='2'\
           and ibig_comp=ibig_sales),itag,mdmg_prem,mlia_prem,\
           (select sum(medrdmg_prem+medrlia_prem) from %s:edr_relation \
             where ipolicy = a.ipolicy and dedr_close is not null) \
        from %s:ply_relation a,%s:policy b \
       where dpolicy >= '06/01/2004' and dpolicy <= '09/30/2004' \
         and fedr_class != '1' and iofficer[1] = 'W' \
         and iofficer[7,8] in ('IF','IS') and a.ipolicy = b.ipolicy \
         and a.ipolicy not in (select ipolicy from car625_1)",
    list[j].dbname,list[j].dbname,list[j].dbname);
    $prepare pre_w from $stmt;
    $execute pre_w;
  }
   
  return SUCCESS;

errexit:
   sqlfatal();
   strcpy(msgbuf,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car625_write_data_0()
{
   $whenever sqlerror goto errexit;

   $insert into car625_0 values
   ($sdata[0],$sdata[1],$sdata[2],$sdata[3],$sdata[4],$sdata[5],
    $sdata[6],$sdata[7],$sdata[8],$sdata[9],$sdata[10],$sdata[11],
    $sdata[12],$sdata[13],$sdata[14],$sdata[15],$sdata[16],$sdata[17],
    $sdata[18],$sdata[19],$sdata[20],$sdata[21],$sdata[22],$sdata[23]);

   return SUCCESS;
errexit:
   sqlfatal();
   strcpy(msgbuf,sqlca.sqlerrm);
   return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car625_write_comp()
{
$char  stmt[1024];

   $whenever sqlerror goto errexit;

printf("begin insert car625 only comp\n");
   $insert into car625 values
    ($iquota,$icd[0],$iply[0],$icd[1],$iply[1],$iassured,$nassured,
     $iapplicant,$napplicant,
     $dpolicy,$dply_begin,$ibrand,$iengine,$iissue_ym,$iofficer,
     $ibig_office,' ',' ',$ibig_sales,$itag,0,0,0,0,
     0,0,$mprem_21,0,' ',0,$iply_comp,$icd_comp,$comp_cnt,
     $icar_type,$ncar_abbr,0,0,0,0,0,0);
          
   return SUCCESS;
errexit:
    sqlfatal();
    strcpy(msgbuf,sqlca.sqlerrm);
    return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car625_write_data()
{
   $whenever sqlerror goto errexit;

printf("begin insert car625\n");
   $insert into car625 values
    ($iquota,$icd[0],$iply[0],$icd[1],$iply[1],$iassured,$nassured,
     $iapplicant,$napplicant,
     $dpolicy,$dply_begin,$ibrand,$iengine,$iissue_ym,$ioff[0],
     $ibigo[0],$ioff[1],$ibigo[1],
     $ibig_sales,$itag,$mprem_dmg,$mprem_02,$mprem_11,$mprem_31,
     $mprem_51,$mprem_oth,$mprem_21,$x,$iendorse,$mprem_edr,
     $iply_comp,$icd_comp,$comp_cnt,$icar_type,$ncar_abbr,
     $rSafe_dmg,$rSafe_02,$rSafe_11,$rSafe_31,$rSafe_51,$rSafe_oth,
     $rMgmt_dmg,$rMgmt_02,$rMgmt_11,$rMgmt_31,$rMgmt_51,$rMgmt_oth);         

   if (x_cnt > 1)               /* �P�@�������X���G���H�W�M�ץ� */
      $update car625_1
          set ply_cnt = $x_cnt
        where iengine = $iengine
          and fcard_class = '2';

   if (comp_cnt > 1)            /* �P�@�������X���G���H�W�j���I */
      $update car625_1
          set ply_cnt = $comp_cnt
        where iengine = $iengine
          and fcard_class = '1';

printf("end write car625\n");
   return SUCCESS;
errexit:
    sqlfatal();
    strcpy(msgbuf,sqlca.sqlerrm);
    return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car625_write_data_1()
{
   $long w_mprem_11, w_mprem_31, w_mprem_51;
   
   $whenever sqlerror goto errexit;
   
   w_mprem_11 = mprem_11d;
   w_mprem_51 = mprem_51d;
   w_mprem_31 = mprem_31d;

   printf("before insert car625_1\n");
   $insert into car625_1 values
    ($iquota,$fcard_class,$icard,$ipolicy,$iassured,$nassured,
     $iapplicant,$napplicant,
     $dpolicy,$dply_begin,$ibrand,$iengine,$iissue_ym,$iofficer,
     $ibig_sales,$itag,$mprem_09,$mprem_09_edr,$mprem_11d,$mprem_31d,
     $mprem_51d,$mprem_21d,1,$remark,$iendorse,$ibig_office,
     $icar_type,$ncar_abbr,$rSafe_09,$rSafe_11,$rSafe_31,$rSafe_51,
     $rMgmt_09,$rMgmt_11,$rMgmt_31,$rMgmt_51);

   return SUCCESS;
errexit:
    sqlfatal();
    strcpy(msgbuf,sqlca.sqlerrm);
    return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car625_read_file()
{
char   *bp;
int    rc,i,j,k,m,n;

    $whenever sqlerror goto errexit;

    rc=car625_create_temp();
    if (rc != SUCCESS)
        return rc;

    sprintf(filename,"%s/dat/car/car625.txt",sApHome);
    if ((fp=fopen(filename,"r"))==NULL) {
       sprintf(msgbuf,"%s file open fail ",filename);
       return FALSE;
    }
    flen=1024;
    if ((bp=malloc(flen))==NULL) {
       sprintf(msgbuf,"System malloc failed !");
       return FALSE;
    }

    for (i=0;(feof(fp)==0);i++) {
printf("feof[%d]\n",feof(fp));
        memset(bp,0x00,flen);
        fgets(bp,flen,fp);
        if (bp[0]==0x00)
           break;
        for(j=0;j<23;j++)
           memset(sdata[j],0x00,41);
        k=m=n=0;
        for (j=0;j<flen;j++) {
            if (bp[j]=='\t' || bp[j]=='\0' || bp[j]=='\n') {
                strncpy(sdata[k],bp+m,j-m);
                sdata[k][j-m]='\0';
                m=j+1;
                k++;
            }
            if (bp[j]=='\n')
                break;
            if (k > 22) break;
        }      
        if (sdata[0][0]=='\0') continue;
        rtrim_alldata();
        
        printf("iengine[%s]\n",iengine);
        rc=car625_read_ply();
printf("end read ply\n");
        if (rc!=SUCCESS)
           return rc;

    }

    return SUCCESS;
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car625_create_temp()
{
    $whenever sqlerror goto errexit;

    $create temp table car625_0
     (data1          char(40),
      data2          char(40),
      data3          char(40),
      data4          char(40),
      data5          char(40),
      data6          char(40),
      data7          char(40),
      data8          char(40),
      data9          char(40),
      data10         char(40),
      data11         char(40),
      data12         char(40),
      data13         char(40),
      data14         char(40),
      data15         char(40),
      data16         char(40),
      data17         char(40),
      data18         char(40),
      data19         char(40),
      data20         char(40),
      data21         char(40),
      data22         char(40),
      data23         char(40),
      data24         char(40))
     with no log;

    $create temp table car625
     (iquota         char(6),
      icard1         char(20),
      ipolicy1       char(20),
      icard2         char(20),
      ipolicy2       char(20),
      iassured       char(12),
      nassured       char(40),
      iapplicant     char(12),
      napplicant     char(40),
      dpolicy        date,
      dply_begin     date,
      ibrand         char(8),
      iengine        char(20),
      iissue_ym      char(6),
      iofficer1      char(10),
      ibig_office1   char(9),
      iofficer2      char(10),
      ibig_office2   char(9),
      ibig_sales     char(10),
      itag           char(12),
      mprem_dmg      integer,
      mprem_02       integer,
      mprem_11       integer, 
      mprem_31       integer,
      mprem_51       integer,
      mprem_oth      integer,
      mprem_21       integer,
      ply_cnt        integer,
      iendorse       char(20),
      mprem_edr      integer,
      iply_comp      char(20),
      icd_comp       char(20),
      comp_cnt       integer,
      icar_type      char(2),
      ncar_abbr      char(12),
      rSafe_dmg      decimal(9,7),
      rSafe_02       decimal(9,7),
      rSafe_11       decimal(9,7),
      rSafe_31       decimal(9,7),
      rSafe_51       decimal(9,7),
      rSafe_oth      decimal(9,7),
      rMgmt_dmg      decimal(9,7),
      rMgmt_02       decimal(9,7),
      rMgmt_11       decimal(9,7),
      rMgmt_31       decimal(9,7),
      rMgmt_51       decimal(9,7),
      rMgmt_oth      decimal(9,7))      
     with no log;     

    $create temp table car625_1
     (iquota         char(6),
      fcard_class    char(1),
      icard          char(20),
      ipolicy        char(20),
      iassured       char(12),
      nassured       char(40),
      iapplicant     char(12),
      napplicant     char(40),
      dpolicy        date,
      dply_begin     date,
      ibrand         char(8),
      iengine        char(20),
      iissue_ym      char(6),
      iofficer       char(10),
      ibig_sales     char(10),
      itag           char(12),
      mprem_09       integer,
      mprem_09_edr   integer, 
      mprem_11       integer,
      mprem_31       integer,
      mprem_51       integer,
      mprem_21       integer,
      ply_cnt        integer,
      remark         char(1),
      iendorse       char(20),
      ibig_office    char(9),
      icar_type      char(2),
      ncar_abbr      char(12),
      rSafe_09       decimal(9,7),
      rSafe_11       decimal(9,7),
      rSafe_31       decimal(9,7),
      rSafe_51       decimal(9,7),
      rMgmt_09       decimal(9,7),
      rMgmt_11       decimal(9,7),
      rMgmt_31       decimal(9,7),
      rMgmt_51       decimal(9,7))      
     with no log;

    $create temp table car625_2
     (nquota         char(20),
      icard          char(20),
      ipolicy        char(20),
      iassured       char(10),
      nassured       char(40),
      iapplicant     char(12),
      napplicant     char(40),
      dpolicy        date,
      dply_begin     date,
      icar_type      char(2),
      ncar_abbr      char(12),
      ibrand         char(8),
      nbrand         char(40),
      iengine        char(20),
      iissue_ym      char(6),
      iofficer       char(10),
      ibig_office    char(9),
      nofficer       char(10),
      ibig_sales     char(10),
      nsales         char(10),
      itag           char(12),
      mprem_dmg      integer,
      mprem_51       integer,
      mprem_edr      integer)
     with no log;

    return SUCCESS;
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;  
}
/*--------------------------------------------------------------------*/
rtrim_alldata()
{
    int  x;
    for(x=0;x<23;x++) {
       strcpy(sdata[x],rtrim(sdata[x]));
       if (strlen(sdata[x])>20) printf("[%d][%s]\n",strlen(sdata[x]),sdata[x]);
    }
    strcpy(iengine,sdata[17]);
}
/*--------------------------------------------------------------------*/
