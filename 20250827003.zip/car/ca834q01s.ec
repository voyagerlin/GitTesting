/*******************************************/
/*                                         */
/*   �ˤ`�l���޲z���Ӫ�                    */
/*                                         */
/*   PROGRAM : ca834q01s.ec                */
/*                                         */
/*******************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include "safeclib.h"
extern char RPTDIR[];

$char   iOption[7];
$char   iPreDays_c[5];
$char   dPolicyBgn[11],dPolicyEnd[11];
$char   dPlyBgn[11],dPlyEnd[11];
$int    iPreDays;
$char   iOpt_c[2];
$int    iOpt;

$char DBName[05];
$char userid[11];
DBinfo *list;
int   count_db;
long    rc;
char  outputf[N_FILE+1];

$char  opt1[2],opt2[2],opt3[2],opt4[2];
$char  server[3];
$char  ibranch[3];

$char  dclaim_bgn[11];
$char  dclaim_end[11];

$char  dclaim_bgn_inf[11];
$char  dclaim_end_inf[11];

$char  datone_bgn[11];
$char  datone_end[11];

$char  datone_bgn_inf[11];
$char  datone_end_inf[11];

long car834_accumulate();
/* int  unload1(); */

/*----------------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
   int rc;

   batchinit();
   strcpy(DBName,      isNULLstr(argv[1]));
   strcpy(userid,      isNULLstr(argv[2]));

   strcpy(opt1,        isNULLstr(argv[3]));
   strcpy(server,      isNULLstr(argv[4]));

   strcpy(opt2,        isNULLstr(argv[5]));
   strcpy(ibranch,     isNULLstr(argv[6]));

   strcpy(opt3,        isNULLstr(argv[7]));
   strcpy(dclaim_bgn,  isNULLstr(argv[8]));
   strcpy(dclaim_end,  isNULLstr(argv[9]));

   strcpy(opt4,        isNULLstr(argv[10]));
   strcpy(datone_bgn,  isNULLstr(argv[11]));
   strcpy(datone_end,  isNULLstr(argv[12]));

   strcpy(outputf,     isNULLstr(argv[13]));


   strcpy(dclaim_bgn_inf, cm_to_infdate(dclaim_bgn));
   strcpy(dclaim_end_inf, cm_to_infdate(dclaim_end));

   strcpy(datone_bgn_inf, cm_to_infdate(datone_bgn));
   strcpy(datone_end_inf, cm_to_infdate(datone_end));

    rc = car834_get_db();
    if (rc != SUCCESS)
       return rc;

    rc = car834_prepare_data();
    if (rc != SUCCESS)
       return rc;

    rc = car834_create_rpt();
    if (rc != SUCCESS)
       return rc;
}

/*--------------------------------------------------------------------*/
long car834_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == False)
   {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }

   /******************************************************************
   if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
      if (EWRITE(userid, M_CM_NOT_DBLIST) == True)
         return M_CM_NOT_DBLIST;
   }
   *******************************************************************/

   return SUCCESS;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/

long car834_prepare_data()
{
   int k;
   $char stmt[16384];
   $char sbuf[50];
   $char sWhere0[1024];
   $char sWhere1[1024];
   $char sWhere2[1024];
   $char sNot[100];
   $char sWhere5[1024];
   $char iquota[11];
   $char ibranch1[3];
   $int  icnt;
   $int  icnt1;
   $char sWhere8[1024];

   $whenever sqlerror goto errexit;

   icnt  = 0;
   icnt1 = 0;

   if (opt1[0] == '1')
   {
      if (server[0] == '*')
      {
         sprintf_s(sWhere0,1024," ");
      }
      else
      {
         sprintf_s(sWhere0,1024," and a.iclaim1[1,2] in (select ibranch from branch where iupcomp = '%s') ", server);
      }
   }
   else
   {
      sprintf_s(sWhere0,1024," and a.iclaim1[1,2] = '%s' ",ibranch);
   }

   if (opt3[0] == '1')
   {
      sprintf_s(sWhere1,1024," and a.dclaim between '%s' and '%s' ",dclaim_bgn_inf,dclaim_end_inf);
      sprintf_s(sWhere2,1024," ");
      sprintf_s(sNot,100," not ");
   }
   else
   {
      sprintf_s(sWhere1,1024," ");
      sprintf_s(sWhere2,1024," and datone between '%s' and '%s' ",datone_bgn_inf,datone_end_inf);
      sprintf_s(sNot,100," ");
   }

   $select iquota
      into $iquota
      from officer
     where iofficer = $userid;
   if (SQLCODE == SQLNOTFOUND)
   {
     strcpy(iquota,"");
   }

   $declare c_cur1 cursor for
     select ibranch
       from claim_mail_notify
      where person = $userid
        and ibranch in ('00','22','33','40','66','70')
      order by ibranch;
   $open c_cur1;
   for(;;)
   {
     $fetch c_cur1 into $ibranch1;
     if (SQLCODE == SQLNOTFOUND) break;

     if (icnt1 == 0)
     {
        sprintf_s(sWhere8,1024,"and (c.iupcomp = '%s' ",ibranch1);
     }
     else
     {
        strcat(sWhere8," OR c.iupcomp = '");
        strcat(sWhere8,rtrim(ibranch1));
        strcat(sWhere8,"'");
     }
     icnt1++;
   }
   $close c_cur1;
   $free c_cur1;

   if (icnt1 > 0)
   {
      strcat(sWhere8,")");
   }

   /*  �s�D�ޤβz�߳��D�� */
   /*  �վ㳡���N�� modify by sylvia 111.03.25 (1110317003_SC1) */
   $select count(*)
      into $icnt
      from personal:unitid2ef
     where code_no in ('360000','360100','L10000','L20000','L10100')
       and resp_name = $userid;

   if ((icnt > 0) || (strncmp(iquota,"4302",4) == 0) || (strncmp(iquota,"3601",4) == 0) || (strncmp(iquota,"L101",4) == 0))
   {
      sprintf_s(sWhere5,1024," ");
   }
   else if (icnt1 > 0)
   {
      printf("INTO icnt1 > 0 \n");
      strcpy(sWhere5, sWhere8);
   }
   else
   {
      /* sprintf_s(sWhere5,1024," and b.affiliated in (select iquota from officer where iofficer = '%s' and iquota = b.affiliated"
                         " union select code_no from personal:unitid2ef where resp_name = '%s' union select code_no from personal:unitid2ef"
                         " where code_no[1,4] in (select code_no[1,4] from personal:unitid2ef where resp_name = '%s'"
                         " and code_no[5] = '0'))",userid,userid,userid);    */

      sprintf_s(sWhere5,1024," and b.adjustment in (select iofficer from officer where iofficer = '%s' "
                      " union select empl_no from personal:asempl where administrator = '%s' "
                      " union select empl_no from personal:asempl where unit_id[1,4] in "
                      " (select code_no[1,4] from personal:unitid2ef where resp_name = '%s' and code_no[5,6] = '00')) ",userid,userid,userid);
   }

   printf("INTO sWhere5 [%s]\n", sWhere5);

   sprintf_s(stmt,16384,
    "select a.iclaim1, b.ipolicy, b.nassured, b.affiliated, \
            c.nbranch, d.nname, f.nname as nname_led, \
            date(b.daccident) as daccident, b.dclaim, \
            (select min(b.dappraisal) \
               from claim_app_dtl_h b \
              where a.iclaim1     = b.iclaim1 \
                and a.insure_type = b.insure_type \
                and b.insure_instype in ('93','94','95')) as dappraisal, \
            (select min(date(dentry))  \
               from ca_human_est x  \
              where a.iclaim1 = x.iclaim) as dentry,  \
            (select min(date(destimate))  \
               from ca_human_est x  \
              where a.iclaim1 = x.iclaim) as destimate,  \
            ((select min(date(destimate))  \
                from ca_human_est x  \
               where a.iclaim1 = x.iclaim) - a.dclaim) as qest_claim,  \
            (select min(date(dapprove))  \
               from ca_human_est x  \
              where a.iclaim1 = x.iclaim) as dapprove,  \
            (select min(datone)  \
               from ca_human_est x  \
              where a.iclaim1 = x.iclaim  \
                 %s ) as datone,  \
            nvl((select sum(x.mclaim_app)  \
                   from claim_app_dtl x    \
                  where a.iclaim1        = x.iclaim1    \
                    and a.insure_type    = x.insure_type   \
                    and x.insure_instype in ('93','94','95')),0) as mapp9345,  \
            nvl((select sum(y.mestimate_ori)  \
                   from ca_human_est x,ca_human_arb y  \
                  where x.ihuman_est = y.ihuman_est  \
                    and y.iitem not in ('I060')  \
                    and a.iclaim1 = x.iclaim),0) as mest_ori,  \
            nvl((select sum(x.mupper_limit)  \
                   from ca_human_est x  \
                  where a.iclaim1 = x.iclaim),0) as mupper_limit,  \
            nvl((select sum(y.mamount)  \
                   from ca_human_est x,ca_human_arb y  \
                  where x.ihuman_est = y.ihuman_est  \
                    and y.iitem not in ('I060')  \
                    and a.iclaim1 = x.iclaim),0) as mamount,  \
            nvl((select sum(z.mamount_com)  \
                   from ca_human_est z  \
                  where z.iclaim = a.iclaim1),0) as mamount_com,  \
            nvl((select sum(y.mamount)  \
                   from ca_human_est x,ca_human_arb y  \
                  where x.ihuman_est = y.ihuman_est  \
                    and y.iitem not in ('I060')  \
                    and a.iclaim1 = x.iclaim),0) + nvl((select sum(z.mamount_com)  \
                                                          from ca_human_est z  \
                                                         where z.iclaim = a.iclaim1),0) as mamount_sum,  \
                (select sum(x.mclaim_app)  \
                   from claim_app_dtl_h x  \
                  where a.iclaim1        = x.iclaim1  \
                    and a.insure_type    = x.insure_type  \
                    and x.insure_instype in ('93','94','95')  \
                    and x.dappraisal     = (select max(y.dappraisal)  \
                                              from claim_app_dtl_h y  \
                                             where x.iclaim1        = y.iclaim1  \
                                               and x.insure_type    = y.insure_type  \
                                               and x.insure_instype = y.insure_instype  \
                                               and y.dappraisal    <= (select min(z.datone) - 30  \
                                                                         from ca_human_est z  \
                                                                        where a.iclaim1 = z.iclaim))) as datone30,  \
            nvl((select max(100 - nvl(y.qduty_adjuster,0))   \
                   from ca_human_est x,ca_clm_victim_data y  \
                  where x.iverify = y.iclaim   \
                    and x.ivictim = y.ivictim  \
                    and a.iclaim1 = x.iclaim),0) as qadj  \
       from claim_app_main a,ca_clm_process b,sa_branch_type c,  \
            officer d, personal:asempl e, officer f  \
      where a.insure_type  = 'C'    \
        and a.isys_source  = 'CAR'  \
        and a.iclaim1 = b.iclaim    \
        and b.affiliated = c.ibranch   \
        and b.adjustment = d.iofficer  \
        and b.adjustment = e.empl_no   \
        and e.administrator = f.iofficer   \
        %s  \
        and a.iclaim1 %s in (select m.iclaim  \
                               from ca_human_est m   \
                              where m.iclaim = a.iclaim1    \
                                 %s )  \
         %s %s \
       into temp main_tbl_a with no log ",sWhere2, sWhere5, sNot, sWhere2, sWhere1, sWhere0);

    printf("stmt[%s]\n",stmt);

    $EXECUTE IMMEDIATE $stmt ;


  strcpy(stmt," select a.* from main_tbl_a a where a.mapp9345 >= 15000            \
                   and a.iclaim1    not in (select sd.iclaim1                   \
                                              from claim_stl_dtl sd             \
                                             where a.iclaim1     = sd.iclaim1   \
                                               and sd.insure_instype in ('93','94','95')   \
                                               and sd.fstl        = '1'   \
                                             group by sd.iclaim1          \
                                            having sum(sd.msettle - sd.mfee) = 0)   \
                  into temp main_b8 with no log ");

    printf("stmt[%s]\n",stmt);
    $EXECUTE IMMEDIATE $stmt ;
    printf("main_b8 ok \n");

    sprintf_s(stmt,16384,
    " select a.iclaim, '�M�Ѥ�x' ftype, a.ivictim, a.iserial, a.drecord, a.nplace, a.njournal,  \
             c.nname, date(a.dentry) dentry, \
             replace(replace(a.nremark, chr(10),''),chr(13),'') as nremark    \
        from ca_clm_victim_jour a, main_tbl_a b,outer officer c \
       where a.ftype = '1'                                 \
         and a.iclaim = b.iclaim1                          \
         and a.ientry = c.iofficer                         \
         and b.mapp9345 >= 15000                           \
        into temp dtl_tbl_a ");

    printf("stmt[%s]\n",stmt);

    $EXECUTE IMMEDIATE $stmt ;

    sprintf_s(stmt,16384,
    " insert into dtl_tbl_a                  \
      select b.iclaim, cast('�߮פ�x' as char(10)) ftype, ' ' ivictim, a.iserial, a.drecord, a.nplace, a.njournal, \
             d.nname, cast(date(a.dentry) as date) dentry, \
             replace(replace(a.nremark, chr(10),''),chr(13),'') as nremark \
        from ca_clm_journal a, ca_ver_relation b, main_tbl_a c,outer officer d  \
       where a.iverify = b.iverify           \
         and b.iclaim  = c.iclaim1           \
         and c.mapp9345 >= 15000             \
         and a.ientry  = d.iofficer ");

    printf("stmt[%s]\n",stmt);

    $EXECUTE IMMEDIATE $stmt ;

    sprintf_s(stmt,16384,
    " select a.iclaim, a.iserial, date(a.drecheck) drecheck, b.nname nname1,    \
             decode(a.fadm,'1','�z�ߥD��','2','���ɭ�',' ') fadm, \
             date(a.dproc) dproc, c.nname nname2, \
             replace(replace(a.nremark,chr(10),''),chr(13),'') as nremark  \
        from ca_clm_recheck a, outer officer b,outer officer c,main_tbl_a d  \
       where a.irecheck = b.iofficer   \
         and a.iproc    = c.iofficer   \
         and a.iclaim   = d.iclaim1    \
         and d.mapp9345 >= 15000       \
        into temp dtl_tbl_b ");

    printf("stmt[%s]\n",stmt);

    $EXECUTE IMMEDIATE $stmt ;

  return SUCCESS;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/

long car834_create_rpt()
{
  $char sfilename[41];
  $char stitle[512];
  $char sErrmsg[200];
  $char stmt[512];

  $WHENEVER SQLERROR GOTO errexit;

  strcpy(sfilename,"�ˤ`�l���޲z���Ӫ�");

  strcpy(stitle,"�߮׸��X\t�O�渹�X\t�Q�O�I�H\t�z�߳��N��\t�z�߳��W��\t�z�ߤH���m�W\t�z�ߥD�ީm�W\t�X�I���\t���z���\t");

  strcat(stitle,"�w�����\t�l����J���\t�l��������\t�l��������-���z����Ѽ�\t�D�ޮ֭��\t�M�ѧ�����\t�w�����B\t��l�l�����B\t");

  strcat(stitle,"�D�ޮ֭�̰��M�Ѫ��B\t�M�ѫ���N�I�ߥI���B\t�j���I�ߥI���B\t�M�Ѫ��B(�t�j���I)\t�M�Ѥ�e1�Ӥ�w�����B\t");

  strcat(stitle,"�����F�d\t");

  strcpy(stmt," select * from main_b8 where mapp9345 >= 15000 order by iclaim1 ");

  rc = unload_file(outputf,"A",sfilename,stitle,stmt);

  if (rc != SUCCESS)
  {
     if (rc == 3501)
     {
        sprintf_s(sErrmsg,200," ��J���d�߱���䤣���� ",sfilename);
     }
     else
     {
        sprintf_s(sErrmsg,200," %s �ɮ׵L�k���� ",sfilename);
     }

      EWRITE(userid, rc , sErrmsg);
      exit(1);
  }

  strcpy(sfilename,"�߮שM�Ѥ�x");

  strcpy(stitle,"�߮׸��X\t��x���O\t���`�H�����Ҹ�\t�Ǹ�\t��x���\t�a�I\t��x��H�W��\t��J�H��\t��J���\t��x���e\t");

  strcpy(stmt," select * from dtl_tbl_a order by 1,2,3,4 ");

  printf("stmt[%s]\n",stmt);

  rc = unload_file(outputf,"B",sfilename,stitle,stmt);

  if (rc != SUCCESS)
  {
     if (rc == 3501)
     {
        sprintf_s(sErrmsg,200," ��J���d�߱���䤣���� ",sfilename);
     }
     else
     {
        sprintf_s(sErrmsg,200," %s �ɮ׵L�k���� ",sfilename);
     }

      EWRITE(userid, rc , sErrmsg);
      exit(1);
  }

  strcpy(sfilename,"�D�ޡB���ɭ��N��");

  strcpy(stitle,"�߮׸��X\t�Ǹ�\t�[�����\t�[���H��\t�D�ާO\t�z�߳B�z���\t�z�߳B�z�H��\t�[���N��\t");

  strcpy(stmt," select * from dtl_tbl_b order by 1,2 ");

  printf("stmt[%s]\n",stmt);

  rc = unload_file(outputf,"C",sfilename,stitle,stmt);

  if (rc != SUCCESS)
  {
     if (rc == 3501)
     {
        sprintf_s(sErrmsg,200," ��J���d�߱���䤣���� ",sfilename);
     }
     else
     {
        sprintf_s(sErrmsg,200," %s �ɮ׵L�k���� ",sfilename);
     }

      EWRITE(userid, rc , sErrmsg);
      exit(1);
  }

 return SUCCESS;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(1);
}
