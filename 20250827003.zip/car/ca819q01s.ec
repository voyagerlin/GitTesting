/*************************************************/
/*   PROGRAM : ca819q01s.ec                      */
/*   MODIFY  : neo                               */
/*   DATE    : 91.01.28                          */
/*   NOTE    : �H�߮ר��z����_������¦          */
/*************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
$include datetime.h;
#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"


$char DBName[05], iForm_Tp[03], outputf[N_FILE+1];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1];
char  userid[11];

char  msgbuf[100];
$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;
$int  PERIOD = 0;

static int  max_count;

DBinfo  *list;
int     count_db;

$char sIbranch[BRANCH_ID], sIofficer[EMPLOYEE_ID];
$char sNname[EMPLOYEE_NAME];
$char sIclaim[CLAIM_NUM], sFcard_class[2], sDclaim[YYYYMMDD];
$char sYearMonth[7];
$char sIadjuster[EMPLOYEE_ID], sFclose[2], sIins_type[INSURANCE_TYPE];
$char sDclose[13], victim[11], flast[2];
$char sDgroup[11];
$char sNgroup[5],sNadjuster[11];
$char sIupbranch[3], sNupgroup[11];
$char sFins_grp[2];
$char sBgnDate_e[11], sEndDate_e[11], sBgnDate[11], sEndDate[11];
$long lBgnDate, lEndDate;
$char sDrpDate[11], sDrpDate_e[11];
$long iQorder, qmonth, lMins_stl = 0;
$long qdmg_claim, qdmg_close, qdmg_nopay;       /** ���l **/
$long qlia_claim, qlia_close, qlia_nopay;       /** �d�� **/
$long qburg_claim, qburg_close, qburg_nopay;    /** �W�[�ѵs�����Ѩ��l�������X **/
$long qcomp_claim, qcomp_close, qcomp_nopay;    /** �j�� **/
$long qwea_claim, qwea_close, qwea_nopay;       /** �]�� **/
$date lDclaim;
$int  iclose_type;
$char stmt[2000];

$char iins_item[INSURANCE_TYPE];

int qlia, qburg, qdmg, qwea;
$int iTmp;
$int iMaxCnt = 0;
$int id1 = 0;
$int iMonthDiff;

long car819_build();
void car819_title();
long car819_body();
long car819_print();
void car819_print2();
int DiffMonth();

/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
   int rc;
   
   batchinit();
   strcpy(DBName  , isNULLstr(argv[1]));
   strcpy(userid  , isNULLstr(argv[2]));
   strcpy(sBgnDate, isNULLstr(argv[3]));
   strcpy(sEndDate, isNULLstr(argv[4]));
   strcpy(sDrpDate, isNULLstr(argv[5]));
   strcpy(outputf , isNULLstr(argv[6]));

   strcpy(sBgnDate_e, cm_to_infdate(sBgnDate));
   strcpy(sEndDate_e, cm_to_infdate(sEndDate));
   strcpy(sDrpDate_e, cm_to_infdate(sDrpDate));

   rstrdate(sBgnDate_e, &lBgnDate);
   rstrdate(sEndDate_e, &lEndDate);

   iMonthDiff = DiffMonth(lBgnDate, lEndDate);

   printf("iMonthDiff[%d]\n",iMonthDiff);
   printf("sBgnDate_e[%s] sEndDate_e[%s]\n",sBgnDate_e , sEndDate_e);
 
   rc=car819_get_db();
   if (rc!=M_CM_OK)
      return rc;
   
   rc = car819_build();

/**
   if ( rc != FAIL)
   {
    if ((rc=save_form_info(F_BLK0, "CA", 819, userid, iForm_Tp, max_count, outputf))<0)
    {
        strcpy(msgbuf,"save_form_info failed");
        return rc;
    }
   }
**/

   return M_CM_OK;
   
errexit:
   printf("main :SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/

long car819_build()
{
   $char  TitleFmt[N_FILE+1],BodyFmt[N_FILE+1];
   int    rc;
   
   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT;
   
   if (db_select(DBName) == False)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

/**
   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
          kTot_Col, kPgNum_Line, kWidth, iForm_Tp
     INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
          $TotColumn, $PgLine, $Width, $iForm_Tp
     FROM Form
    WHERE ksys_grp = "CA" AND kPgmID = 819;

   strcpy( TitleFmt,rtrim(TitleFmt));
   strcpy( BodyFmt,rtrim(BodyFmt));
   sprintf_s( TitleFile,21,"%s.ti",outputf);
   sprintf_s( BodyFile,21,"%s.bd",outputf);

   rgu_init_report(TitleFmt,TitleFile);
   car819_title();
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);
**/

   rc = car819_body();
   if (rc != M_CM_OK)
       return rc;
           
   rc = car819_print();
   if (rc != M_CM_OK)
       return rc;
 
/**     
   rgu_finish_report();
**/

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;  
}

long car819_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

void car819_title()
{
  char iyy[4], imm[3], idd[3];
  char sTmpBuf[20];
  int  i;

  rgu_put_head_string(1, cm_sysd_cdatetime_100(cm_get_sysd()));   /* get_currdt */

  cm_char_split_3ymd(sBgnDate, iyy, imm, idd);
  rgu_put_head_string(1, iyy);
  rgu_put_head_string(1, imm);
  rgu_put_head_string(1, idd);

  cm_char_split_3ymd(sEndDate, iyy, imm, idd);
  rgu_put_head_string(1, iyy);
  rgu_put_head_string(1, imm);
  rgu_put_head_string(1, idd);

  for (i = 0; i < PERIOD; i++)
  {
      sprintf_s(sTmpBuf,20, "%d", lGetNextMonth(sBgnDate_e, i));
      rgu_put_head_string(4, sTmpBuf, RIGHT);
  }
  rgu_put_head();
}

long car819_body()
{
    int i;
    long rc;
    $char sStmt[1024],sStmt1[1024],sStmt2[1024],sStmt3[1024],sStmt4[1024];
    $char  stmt[1024];

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;


    $CREATE TEMP TABLE CAR819
    (
        iadjuster   char(10),
        dyearmonth  char(6),
        qdmg_claim  int default 0,
        qdmg_close  int default 0,
        qdmg_nopay  int default 0,
        qburg_claim int default 0,
        qburg_close int default 0,
        qburg_nopay int default 0,
        qlia_claim  int default 0,
        qlia_close  int default 0,
        qlia_nopay  int default 0,
        qwea_claim  int default 0,
        qwea_close  int default 0,
        qwea_nopay  int default 0,
        qcomp_claim int default 0,
        qcomp_close int default 0,
        qcomp_nopay int default 0
    )
    WITH NO LOG;

    $CREATE UNIQUE INDEX CAR819_tmp_idx ON CAR819(iadjuster, dyearmonth);


    for (i=0;i<count_db;i++)
    {
        /*** �w����:�H�߮ר��z�������¦ ***/
        sprintf_s(sStmt,1024,"SELECT a.iclaim, a.fcard_class, DATE(a.dclaim), a.iadjuster "
                      "  FROM %s:appraisal a inner join %s:adjustment_ply b "
                         " ON a.iclaim = b.iclaim "
                      " WHERE DATE(a.dclaim) BETWEEN ? AND ? "
                        " AND not b.nassured like '%%�ڤO�h%%' "
                        " AND ipolicy not in (select ipolicy from %s:policy where ipolicy = a.ipolicy "
                        "                        and iroute = 'PA') "
                      " ORDER BY 1 ", list[i].dbname, list[i].dbname, list[i].dbname);
                  
        printf("sStmt[%s]\n",sStmt);
        
        $PREPARE CUR2_tmp FROM $sStmt;
        $DECLARE CUR2 CURSOR for CUR2_tmp;
        $OPEN CUR2 USING $sBgnDate_e , $sEndDate_e;
        while(1)
        {
           $FETCH CUR2 INTO $sIclaim, $sFcard_class, $sDclaim, $sIadjuster;

           if (SQLCODE == SQLNOTFOUND) break;

           strcpy(sYearMonth, sDclaim+6);
           strncat(sYearMonth, sDclaim, 2);
           sYearMonth[6] = '\0';

           printf("sDclaim[%s], sYearMonth[%s]\n", sDclaim, sYearMonth);

           /**** ����default�� ****/
           qcomp_claim = qdmg_claim = qlia_claim = qburg_claim = qwea_claim = 0;  /** ���z��� **/
           qcomp_close = qdmg_close = qlia_close = qburg_close = qwea_close = 0;  /** ���ץ�� **/
           qcomp_nopay = qdmg_nopay = qlia_nopay = qburg_nopay = qwea_nopay = 0;  /** �K�ߥ�� **/
    
           /*** �j��߮� ***/
           if (strcmp(trim(sFcard_class), "1") == 0 ||strcmp(trim(sFcard_class), "3") == 0)
           {
               qcomp_claim = 1;  /** �j���I���ץ�� **/
               qcomp_close = 0;  /** �j���I���ץ�� **/
               qcomp_nopay = 0;  /** �j���I�K�ߥ�� **/

               /*** �j���I�w���I�ة����� ***/

               sprintf_s(sStmt1,1024,
               " select a.iins_item, a.ivictim, b.dgroup, b.flast "
               "   from %s:ca_app_victim a, outer %s:ca_stl_victim b  "
               "  where a.iclaim    = b.iclaim      "
               "    and a.iins_item = b.iins_item   "
               "    and a.ivictim   = b.ivictim     "
               "    and b.flast    in ('1','2')     "
               "    and b.dgroup   <= ?             "
               "    and a.iclaim    = ?             ", list[i].dbname, list[i].dbname);

               $PREPARE CUR3_tmp FROM $sStmt1;
               $DECLARE CUR3 CURSOR for CUR3_tmp;
               $OPEN CUR3 USING $sDrpDate_e, $sIclaim;
               while(1)
               {
                  $FETCH CUR3 INTO $iins_item, $victim, $sDgroup, $flast;
                  if (SQLCODE == SQLNOTFOUND) break;

                  printf("ca_app_victim cur  iclaim[%s], iins_item[%s], ivictim[%s], dgroup[%s], flast[%s]\n",
                          sIclaim, iins_item, victim, sDgroup, flast);

                  /****  �ϥ� outer join �Y join ����(flast = 0 or dgroup is null), �h dgroup�|�O null  ****/
                  if (sDgroup[0] == '\0' || sDgroup[0] == ' ')
                  {
                     /*** �u�n���@���w�����I���إ��M,�h�������ץ�Ƭ� 0 �� ***/
                     qcomp_close = 0;
                     qcomp_nopay = 0;
                     break;
                  }
                  qcomp_close = 1;
               }
               $CLOSE CUR3;
               $FREE  CUR3;

               /** �w���פ���Ƥ~���ˮ֬O�_���K�ߵ��� **/
               if (qcomp_close == 1)
               {
                  sprintf_s(sStmt1,1024,
                  " select nvl(sum(mins_stl),0)   "
                  "   from %s:ca_stl_victim       "
                  "  where iclaim  = ?            "
                  "    and dgroup <= ?            "
                  "    and fstl    = '1'          ",list[i].dbname);
                   $PREPARE EXESTL3 from $sStmt1;
                   $EXECUTE EXESTL3
                       INTO $lMins_stl
                      USING $sIclaim, $sDrpDate_e;
                   /** �K�ߵ��ת̡A�p1�� **/
                   if (lMins_stl == 0) qcomp_nopay = 1;
               }
               printf("qcomp_close[%d]\n",qcomp_close);
           }
           else   /*** ���N�߮� ***/
           {
               qdmg_claim  = 0;      /** ���l�I���ץ�� **/
               qlia_claim  = 0;      /** �N�~�I���ץ�� **/
               qburg_claim = 0;      /** �ѵs�I���ץ�� **/
               qwea_claim  = 0;      /** �]�l�I���ץ�� **/

               qdmg_close  = 0;      /** ���l�I���ץ�� **/
               qlia_close  = 0;      /** �N�~�I���ץ�� **/
               qburg_close = 0;      /** �ѵs�I���ץ�� **/
               qwea_close  = 0;      /** �]�l�I���ץ�� **/

               qdmg_nopay  = 0;      /** ���l�I�K�ߥ�� **/
               qlia_nopay  = 0;      /** �N�~�I�K�ߥ�� **/
               qburg_nopay = 0;      /** �ѵs�I�K�ߥ�� **/
               qwea_nopay  = 0;      /** �]�l�I�K�ߥ�� **/
                              
               qlia = qburg = qdmg = qwea = True;
               
               printf("iclaim[%s]\n", sIclaim);

               /****  iMaxCnt 4.��� 3.�]�l 2.�ѵs 1.���� ****/
               sprintf_s(sStmt3,1024,
                "  select iins_type, ( case when         "
                                 "  (select count(*) "
                                 "     from insurance_type "
                                 "    where iins_type =  a.iins_type "
                                 "      and fins_grp  =  '2' "
                                 "      and fkind     <> '3') > 0 then 4 "
                                 "  when "
                                 "  (select count(*) "
                                 "     from insurance_type "
                                 "    where iins_type =  a.iins_type "
                                 "      and fkind     = '3')  > 0 then 3 "
                                 "  when "
                                 " (select count(*) "
                                 "    from insurance_type "
                                 "   where iins_type =  a.iins_type "
                                 "     and fkind     = '2')  > 0 then 2 "
                             " else 1 "
                        " end) as maxadj "
                 "   from %s:app_ins_type a  "
                 "  where iclaim = ? ", list[i].dbname);
               printf("sStmt3[%s]\n",sStmt3);
               $prepare exe_maxadj from $sStmt3;
               $declare exe_maxcur cursor for exe_maxadj;
               $open exe_maxcur using $sIclaim;
        
               for(;;)
               {
                   $fetch exe_maxcur into $sIins_type, $iMaxCnt;
                   if (SQLCODE == SQLNOTFOUND) break;

	               /*****
	               $execute exe_maxadj
	                   into $iMaxCnt:id1
	                  using $sIclaim;
	               if (id1 < 0)
	               {
	                  continue;
	               }
	               *****/
	
	               if (iMaxCnt == 4)
	               {
	                  qlia_claim  = 1;
	               }
	               else if (iMaxCnt == 3)
	               {
	                  qwea_claim  = 1;
	               }
	               else if (iMaxCnt == 2)
	               {
	                  qburg_claim = 1;
	               }
	               else if (iMaxCnt == 1)
	               {
	                  qdmg_claim  = 1;
	               }
	
	               iTmp = 0;
	               sprintf_s(sStmt3,1024,
	               " select b.dgroup, b.flast      "
	               "   from %s:app_ins_type a, outer %s:stl_ins_type b "
	               "  where a.iclaim     =  b.iclaim            "
	               "    and a.iins_type  =  b.iins_type         "
	               "    and b.flast      =  '1'                 "
	               "    and b.dgroup    <=  ?                   "
                       "    and a.iins_type  =  ?                   "
	               "    and a.iclaim     =  ? order by b.dgroup ", list[i].dbname, list[i].dbname);
 
                       printf("sStmt3[%s]\n",sStmt3);
	               $PREPARE CUR5_tmp FROM $sStmt3;
	               $DECLARE CUR5 CURSOR for CUR5_tmp;
	               $OPEN CUR5 USING $sDrpDate_e, $sIins_type, $sIclaim;
	               for(;;)
	               {
	                  $FETCH CUR5 INTO $sDgroup, $flast;
	                  if (SQLCODE == SQLNOTFOUND) break;
	
	                  /****  �ϥ� outer join �Y join ����(flast = 0 or dgroup is null), �h dgroup�|�O null  ****/
	                  if (sDgroup[0] == '\0' || sDgroup[0] == ' ')
	                  {
	                     /*** �u�n���@���w�����I���إ��M,�h�������ץ�Ƭ� 0 �� ***/
	                     break;
	                  }
	
	                  iTmp = 1;
	               }
	               $CLOSE CUR5;
	               $FREE  CUR5;
	
	               /** �w���פ���Ƥ~���ˮ֬O�_���K�ߵ��� **/
	               if (iTmp == 1)
	               {
	                   /*** �����Ƥ]������ ***/
	                   if (iMaxCnt == 4)
	                   {
	                      qlia_close  = 1;
	                   }
	                   else if (iMaxCnt == 3)
	                   {
	                      qwea_close  = 1;
	                   }
	                   else if (iMaxCnt == 2)
	                   {
	                      qburg_close = 1;
	                   }
	                   else if (iMaxCnt == 1)
	                   {
	                      qdmg_close  = 1;
	                   }
	
	                   sprintf_s(sStmt1,1024,
	                   " select nvl(sum(mins_stl),0)   "
	                   "   from %s:stl_ins_type        "
	                   "  where iclaim  = ?            "
	                   "    and dgroup <= ?            "
                           "    and iins_type = ?          "
	                   "    and fstl    = '1'          ",list[i].dbname);
	                    $PREPARE EXESTL5 from $sStmt1;
	                    $EXECUTE EXESTL5
	                        INTO $lMins_stl
	                       USING $sIclaim, $sDrpDate_e, $sIins_type;
	                    /** �K�ߵ��ת̡A�p1�� **/
	                    if (lMins_stl == 0)
	                    {
	                       if (iMaxCnt == 4)
	                       {
	                          qlia_nopay  = 1;
	                       }
	                       else if (iMaxCnt == 3)
	                       {
	                          qwea_nopay  = 1;
	                       }
	                       else if (iMaxCnt == 2)
	                       {
	                          qburg_nopay = 1;
	                       }
	                       else if (iMaxCnt == 1)
	                       {
	                          qdmg_nopay  = 1;
	                       }
	                    }
	                 }
             }
           } /* end ���N�߮�*/
           
           $UPDATE CAR819
               SET qdmg_claim  = qdmg_claim   + $qdmg_claim,
                   qdmg_close  = qdmg_close   + $qdmg_close,
                   qdmg_nopay  = qdmg_nopay   + $qdmg_nopay,
                   qburg_claim = qburg_claim  + $qburg_claim,
                   qburg_close = qburg_close  + $qburg_close,
                   qburg_nopay = qburg_nopay  + $qburg_nopay,
                   qlia_claim  = qlia_claim   + $qlia_claim,
                   qlia_close  = qlia_close   + $qlia_close,
                   qlia_nopay  = qlia_nopay   + $qlia_nopay,
                   qwea_claim  = qwea_claim   + $qwea_claim,
                   qwea_close  = qwea_close   + $qwea_close,
                   qwea_nopay  = qwea_nopay   + $qwea_nopay,
                   qcomp_claim = qcomp_claim  + $qcomp_claim,
                   qcomp_close = qcomp_close  + $qcomp_close,
                   qcomp_nopay = qcomp_nopay  + $qcomp_nopay
             WHERE iadjuster   = $sIadjuster
               AND dyearmonth  = $sYearMonth;
           if (sqlca.sqlerrd[2] == 0)
           {
              $INSERT INTO CAR819
               VALUES ($sIadjuster , $sYearMonth ,
                       $qdmg_claim , $qdmg_close , $qdmg_nopay,
                       $qburg_claim, $qburg_close, $qburg_nopay,
                       $qlia_claim , $qlia_close , $qlia_nopay,
                       $qwea_claim , $qwea_close , $qwea_nopay,
                       $qcomp_claim, $qcomp_close, $qcomp_nopay);
           }
        } /* END for one database */
        $CLOSE CUR2;
        $FREE  CUR2;
        /*  insert to ca_wk819 for iadjuster's backup */
    } /* end for three database */
    
    return M_CM_OK;
        
errexit:
   printf("car819_body ==> SQLCODE:[%ld] \n", SQLCODE);
   rc = EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   printf("car819 body ==> before drop CAR819\n");
   $DROP TABLE CAR819;
   printf("car819 body ==> after  drop CAR819\n");
   return SQLCODE;
}

long car819_print()
{
   $char stmt[4096], stmt1[1024], stmt2[1024];
   $long qorder;
   int i,x,j,k;
   $int COUNT;
   $char sfilename[31];
   $char stitle[10000];
   $char ssql[20000];
   $char dyearmonth_tmp[7];
   $char title_tmp[101];
   $char title_tmp0[101];
   $char title_tmp1[101];
   $char title_tmp2[101];
   $char filed[20][15];
   $char sqltmp[1024];
   $char filed_tmp[200];
   $char sErrmsg[100];
   $int  rc;

   $WHENEVER ERROR goto errexit;
   $SET LOCK MODE TO WAIT;

   strcpy(filed[0], "qdmg_claim");
   strcpy(filed[1], "qdmg_close");
   strcpy(filed[2], "qdmg_nopay");
   strcpy(filed[3], "qburg_claim");
   strcpy(filed[4], "qburg_close");
   strcpy(filed[5], "qburg_nopay");
   strcpy(filed[6], "qlia_claim");
   strcpy(filed[7], "qlia_close");
   strcpy(filed[8], "qlia_nopay");
   strcpy(filed[9], "qwea_claim");
   strcpy(filed[10], "qwea_close");
   strcpy(filed[11], "qwea_nopay");
   strcpy(filed[12], "qcomp_claim");
   strcpy(filed[13], "qcomp_close");
   strcpy(filed[14], "qcomp_nopay");


   /*  CREATE OUTPUT'S COWS FROM DATABASE */

   /******

    $CREATE TEMP TABLE CAR819
    (
        iadjuster   char(10),
        dyearmonth  char(6),
        qdmg_claim  int default 0,
        qdmg_close  int default 0,
        qdmg_nopay  int default 0,
        qburg_claim int default 0,
        qburg_close int default 0,
        qburg_nopay int default 0,
        qlia_claim  int default 0,
        qlia_close  int default 0,
        qlia_nopay  int default 0,
        qwea_claim  int default 0,
        qwea_close  int default 0,
        qwea_nopay  int default 0,
        qcomp_claim int default 0,
        qcomp_close int default 0,
        qcomp_nopay int default 0
    )
    WITH NO LOG;

    ******/

   strcpy(sfilename,"���ײv�έp��");

   strcpy(stitle,"�`�����q�O\t���\t�Ҧb�a\t�z�߭�\t");

   strcpy(ssql, " select decode(b.iupcomp,'0','00','1','40','2','70','5','22','6','33','7','66') as iupcomp, ");
   strcat(ssql, "        (select xx.nbranch from sa_branch_type xx where xx.ibranch = b.iquota) as nquota,   ");
   strcat(ssql, "        (select yy.nchi_full from branch yy, cm_clm_adjuster zz where zz.iapp_unit = yy.ibranch and zz.empl_no = a.iadjuster) as nlocal, ");
   strcat(ssql, " b.nname   "); 

   $declare pr_cur cursor for
     select unique TO_CHAR(dwork,'%Y%m')
       from cm_wrktbl
      where dwork between $sBgnDate_e and $sEndDate_e
      order by 1;
   $open pr_cur;
   for(;;)
   {
      $fetch pr_cur into $dyearmonth_tmp;
      if (SQLCODE == SQLNOTFOUND) break;

      strcpy(title_tmp0,rtrim(dyearmonth_tmp));

      for(j=1;j<=5;j++)
      {
          switch(j)
          {
              case 1:   strcpy(title_tmp1,"���l");   break;
              case 2:   strcpy(title_tmp1,"�ѵs");   break;
              case 3:   strcpy(title_tmp1,"�ˮ`");   break;
              case 4:   strcpy(title_tmp1,"�]�l");   break;
              case 5:   strcpy(title_tmp1,"�j��");   break;
              default:  break;
          }

          for(k=1;k<=3;k++)
          {
              switch(k)
              {
                  case 1:   strcpy(title_tmp2,"���ץ��");   break;
                  case 2:   strcpy(title_tmp2,"���ץ��");   break;
                  case 3:   strcpy(title_tmp2,"�K�ߥ��");   break;
                  default:  break;
              }

              strcpy(title_tmp, rtrim(title_tmp0));
              strcat(title_tmp, rtrim(title_tmp1));
              strcat(title_tmp, rtrim(title_tmp2));

              strcat(stitle, title_tmp);
              strcat(stitle, "\t");

              strcpy(filed_tmp, filed[(j-1)*3+(k-1)]); 
              strcat(filed_tmp, "_");
              strcat(filed_tmp, title_tmp0);

              sprintf_s(sqltmp,1024," ,sum(case when dyearmonth = '%s' then %s else 0 end) as %s ", title_tmp0, filed[(j-1)*3+(k-1)], filed_tmp);

              strcat(ssql, sqltmp);

          }
      }
   }
   $close pr_cur;
   $free pr_cur;

   strcat(ssql," from CAR819 a, officer b where a.iadjuster  =  b.iofficer group by 1,2,3,4 into temp CAR819_temp with no log ");

   printf(" ssql [%s]\n",ssql);
 
   $prepare exe1 from $ssql;
   $execute exe1;

   strcpy(ssql," select * from CAR819_temp order by 1,2,3,4 ");

   rc = unload_file(outputf," ",sfilename,stitle,ssql);

   if (rc != SUCCESS)
   {
       if (rc == 3501)
       {
          sprintf_s(sErrmsg,100," ��J���^������䤣���� ",sfilename);
       }
       else
       {
          sprintf_s(sErrmsg,100," %s �ɮ׵L�k���� ",sfilename);
       }

       EWRITE(userid, rc , sErrmsg);
       exit(1);
   }

   return M_CM_OK;

errexit:
  printf("SQL=[%d], sqlca.sqlerrm[%s]\n", SQLCODE, sqlca.sqlerrm);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  exit(1);
    
}

int DiffMonth(d1,d2)    /* input data should be date format */
long d1, d2;
{
short mdy1[3], mdy2[3];
int datediff=0;

    rjulmdy(d1,mdy1);
    rjulmdy(d2,mdy2);
    datediff=(mdy1[2]*12+mdy1[0])-(mdy2[2]*12+mdy2[0]);
    if (datediff<0) datediff=0;
    return datediff;
}
