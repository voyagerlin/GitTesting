/************************************************/
/*                                              */
/*   PROGRAM : ca13101qs.ec                     */
/*   �S�w�O�����ˮֳ]�w�@�~                   */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "commsgs.h"
#include "carmsgs.h"
$include sqlca;
#include "safeclib.h"

long car131(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
     long rtncode;
     long car131_insert(),car131_single_query(),car131_multiple_query(), car131_update_exec();
     char option;

     cm_buf_init(command);
     cm_buf_get("%c",&option);
     switch(option)
     {
           case 'A':
                    rtncode=car131_insert(reply);
                    break;
           case 'Q':
                    rtncode=car131_single_query(reply);
                    break;
           case 'M':
                    rtncode=car131_multiple_query(reply);
                    break;
           case 'D':
           case 'U':
                    rtncode=car131_update_exec(reply,command,com_len);
                    break;
           default :
                    return exitsub(reply,M_CM_WRONG_OPTION)?M_CM_WRONG_OPTION:apiRC;
     }
     return(rtncode);
}

/**********************************************************************/
long car131_insert(reply)
serverReply reply;
{
     $char  sOption[2];
     $char  sIpolicy[21],sCheck_fedr[11],sNote[101],sIclaim[21];
     $char  sIcard[21];
     $char  sFullName[20];
     $char  DBName[5], userid[11], stmt[300];

     int    tmp_len, fFound;
     long   MsgCode;

     cm_buf_get("%s %s %s %s %s %s %s ", DBName, sOption, sIpolicy, sCheck_fedr, sNote, sIclaim ,userid);

     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
         return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     printf("sOption[%s],sIpolicy[%s],sCheck_fedr[%s],sNote[%s]\n", sOption, sIpolicy, sCheck_fedr, sNote);

     $BEGIN WORK;
     if (strncmp(sOption,"2",1)==0)  /* ��J���O�d���X�ɡA���ഫ���O�渹�X */
     {
         strcpy(sIcard,trim(sIpolicy));

         $SELECT ipolicy
            INTO $sIpolicy
            FROM compulsory_card
           WHERE icard = $sIcard;
         if (SQLCODE == SQLNOTFOUND)
         {
              $SELECT ipolicy
                 INTO $sIpolicy
                 FROM card
                WHERE icard = $sIcard;
              if (SQLCODE == SQLNOTFOUND)
              {
                  $ROLLBACK WORK;
                  return exitsub(reply,M_CM_NOT_FOUND) ? M_CM_NOT_FOUND : apiRC;
              }
              if ((sIpolicy[0] == ' ') || (sIpolicy[0] == '\0'))  /* �O�I�d�|���X�� */
              {
                  $ROLLBACK WORK;
                  return exitsub(reply,M_CA_NCARD_IN_PLY) ? M_CA_NCARD_IN_PLY : apiRC;  /* �O�I�Ҥ��O���Ƥ��s�b */
              }
         }
         if ((sIpolicy[0] == ' ') || (sIpolicy[0] == '\0'))   /* �O�I�ҩ|���X�� */
         {
              $ROLLBACK WORK;
              return exitsub(reply,M_CA_NCARD_IN_PLY) ? M_CA_NCARD_IN_PLY : apiRC;      /* �O�I�Ҥ��O���Ƥ��s�b */
         }
         strcpy(sOption,"1");
     }

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     /* �ﶵ��1��2�ɶ��T�{�O���ƬO�_�s�b */
     if ((strncmp(sOption,"1",1)==0) || (strncmp(sOption,"2",1)==0))
     {
          strcpy(sFullName, get_car_full_db(sIpolicy));
          sprintf_s(stmt, sizeof stmt, "SELECT ipolicy FROM %s:ply_relation WHERE ipolicy = '%s' ", sFullName, sIpolicy);
          printf("stmt[%s]\n",stmt);
          $PREPARE sq1_1 FROM $stmt;
          $DECLARE sq1_1_cursor CURSOR FOR sq1_1;
          $OPEN    sq1_1_cursor;
          $FETCH   sq1_1_cursor INTO :sIpolicy;
          fFound = (SQLCODE == SQLNOTFOUND) ? 0 : 1;
          $CLOSE   sq1_1_cursor;
          $FREE    sq1_1_cursor;
          if(!fFound)
          {
              $ROLLBACK WORK;
              return exitsub(reply,M_CA_NPOLICY) ? M_CA_NPOLICY : apiRC;
          }
     }
     printf("Begin INSRRT car_spec_policy\n");
     
     if(strlen(trim(sIclaim)) == 0)
     	strcpy(sIclaim," ");
     	
     if(strlen(trim(sNote)) == 0)
     	strcpy(sNote," ");

     $INSERT INTO car_spec_policy (type, inumber, check_fedr, note, iclaim, iupdate, dupdate)
                           VALUES ($sOption, $sIpolicy, $sCheck_fedr, $sNote, $sIclaim, $userid, current);
                           
     $INSERT INTO car_spec_policy_log (ikind, type, inumber, check_fedr, note, iclaim, iupdate, dupdate)
                           VALUES ('A', $sOption, $sIpolicy, $sCheck_fedr, $sNote, $sIclaim, $userid, current);

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l ",M_CM_OK);
     tmp_len = cm_buf_len(ReplyBuf);

     if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
     {
        $WHENEVER SQLERROR CONTINUE;
        $COMMIT WORK;
        return apiRC;
     }

     $WHENEVER SQLERROR GOTO errexit;

     $COMMIT WORK;
     return api_OKComplete;

errexit:
     MsgCode = SQLCODE;
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     if (SQLCODE != 0) MsgCode = SQLCODE;         /* rollback fail */
     return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

/**********************************************************************/
long car131_single_query(reply)
serverReply reply;
{
     $char  DBName[5];
     $char  sInumber[21];
     $char  sOption[2];
     $char  sIpolicy[21],sCheck_fedr[11],sNote[101];
     $char  sIclaim[21],userid[11],dupdate[20];
     int tmp_len;

     cm_buf_get("%s %s %s",DBName,sInumber,userid);

     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     $SELECT type,inumber,check_fedr,note,iclaim,iupdate,dupdate
        INTO $sOption,$sIpolicy,$sCheck_fedr,$sNote,$sIclaim,$userid,$dupdate
        FROM car_spec_policy
       WHERE inumber = $sInumber;

     if(SQLCODE==SQLNOTFOUND)
         return exitsub(reply,M_CM_NOT_FOUND) ? M_CM_NOT_FOUND : apiRC;

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l ",M_CM_OK);
     cm_buf_put("%s %s %s %s %s %s %s",sOption,sIpolicy,sCheck_fedr,sNote,sIclaim,userid,dupdate);

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
       return apiRC;
     else
       return api_OKComplete;

errexit:
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/**********************************************************************/
long car131_multiple_query(reply)
serverReply reply;
{
     $char  DBName[5], userid[11], sInumber[21];
     $char  sOption[2];
     $char  sIpolicy[21],sCheck_fedr[11],sNote[101];

     $char  stmt[1024];

     $char  sOption_Name[20];
     $char  sOption_PutName[20];

     $char  sCheck_fedr_PutName[51];
     $char  sIclaim[21];

     char tmpbuf[4000];
     int  count=0,repbuf_len=0,tmp_len=0,replycnt=0;
     int  i,total_count=0;

     cm_buf_get("%s %s",DBName,sInumber);

     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     $DECLARE q_cur CURSOR FOR
       SELECT type,inumber,check_fedr,note,iclaim,iupdate
         INTO $sOption,$sIpolicy,$sCheck_fedr,$sNote,$sIclaim,$userid
         FROM car_spec_policy
        WHERE inumber matches $sInumber
        ORDER BY inumber;
     $OPEN q_cur;

     for(;;)
     {
         $FETCH q_cur;
         if (SQLCODE != 0) break;

         cm_buf_init(tmpbuf);
         if (count == 0)
         {
              cm_buf_res_msg();       /* reserve for MsgCode and count */
              cm_buf_res_count();
         }

         /* �ഫoption����r�ԭz */
         sOption_PutName[0] = '\0';
         $SELECT ncode
            INTO $sOption_Name
            FROM cu_code_data
           WHERE itype = '33'
             AND icode = $sOption;
         if (SQLCODE == SQLNOTFOUND)
             strcpy(sOption_Name,"");
         strcpy(sOption_Name,trim(sOption_Name));

         strcpy(sOption_PutName,trim(sOption));
         strcat(sOption_PutName,":");
         strcat(sOption_PutName,sOption_Name);

         /* �ഫ�ˮֶ��� */
         sCheck_fedr_PutName[0]='\0';
         if (strncmp(sCheck_fedr+(1-1),"1",1)==0)
             strcat(sCheck_fedr_PutName, "1.���P ");

         if (strncmp(sCheck_fedr+(2-1),"1",1)==0)
             strcat(sCheck_fedr_PutName, "2.�L�� ");

         if (strncmp(sCheck_fedr+(3-1),"1",1)==0)
             strcat(sCheck_fedr_PutName, "3.�h���h�O ");

         if (strncmp(sCheck_fedr+(4-1),"1",1)==0)
             strcat(sCheck_fedr_PutName, "4.�@���� ");

         if (strncmp(sCheck_fedr+(5-1),"1",1)==0)
             strcat(sCheck_fedr_PutName, "5.���B��� ");

         if (strncmp(sCheck_fedr+(6-1),"1",1)==0)
             strcat(sCheck_fedr_PutName, "6.���� ");

         cm_buf_put("%s %s %s %s",sOption_PutName, sIpolicy, sCheck_fedr_PutName, sNote);
         tmp_len = cm_buf_len(tmpbuf);
         if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
         {
              memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
              repbuf_len += tmp_len;
              count++;
         }
         else                               /* more than 4K, send to client side */
         {
              cm_buf_init(ReplyBuf);
              cm_buf_put_msg(M_CM_OK);
              cm_buf_put_count(count);
              if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
              {
                  $CLOSE q_cur;
                  return apiRC;
              }
              else               /* clear ReplyBuf and count to start all over again */
              {
                  replycnt++;
                  if (replycnt == 10)   /* more than 30K, client cannot display,error */
                  {
                      cm_buf_init(ReplyBuf);
                      cm_buf_put("%l",M_CM_OUT_SPACE);
                      tmp_len = cm_buf_len(ReplyBuf);
                      if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
                          return apiRC;
                      return M_CM_OUT_SPACE;
                  }
                  ReplyBuf[0] = '\0';
                  count = 0;
                  cm_buf_init(ReplyBuf);
                  cm_buf_res_msg();           /* reserve for MsgCode and count */
                  cm_buf_res_count();

                  cm_buf_put("%s %s %s %s",sOption_PutName, sIpolicy, sCheck_fedr_PutName, sNote);

                  repbuf_len = cm_buf_len(ReplyBuf);
                  count++;
              }
         }
     } /* for loop */

     $CLOSE q_cur;
     if (count > 0)   /* break out, at least one record is selected */
     {
          cm_buf_init(ReplyBuf);
          cm_buf_put_msg(M_CM_OK);
          cm_buf_put_count(count);
          if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
              return apiRC;
          return api_OKComplete;
     }
     else            /* break out, not any row is found */
     {
          return exitsub(reply,M_CM_NOT_FOUND) ? M_CM_NOT_FOUND : apiRC;
     }

errexit:
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/**********************************************************************/
long car131_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
     $char   DBName[5],userid[11];
     $char   sInumber[21];
     $char   sOption[2];
     $char   sIpolicy[21],sCheck_fedr[11],sNote[101],sIclaim[21];

     $char   old_option[2],old_inumber[21],old_check_fedr[11],old_note[101];
     $char   old_iclaim[21],old_iupdate[11],old_dupdate[20];
     
     char    option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
     int     tmp_len,raw_len;
     long    dummy;
     long    MsgCode;
     DBinfo *list;
     int i, j=0, is_del_fail=0, is_upd_fail=0;
     $char stmt_buf[300];

     comm = (char *) command;
     cm_buf_init(command);
     cm_buf_get("%c %s %s ",&option,DBName,userid);

     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
       return exitsub(reply,M_CM_NOT_DBLIST) ? M_CM_NOT_DBLIST : apiRC;

     /* compare old record and current record, if the record has not been changed
        since last request, update or delete the record, otherwise return errmsg
        to client side */

     /* get old record info from command buffer */

     /*
        raw_len = *(int *) &comm[com_len];
        memcpy(&raw_len,(void *)&command[com_len],sizeof(int));
     */

     memcpy(&raw_len,&comm[com_len],sizeof(int));
     pos = &comm[com_len+sizeof(int)];
     raw_ptr = malloc(raw_len);
     if (raw_ptr != (char*)0)
         memcpy(raw_ptr,pos,raw_len);
     else
     {
         if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */
             return M_CM_NOT_MALLOC;
         else
             return apiRC;
     }

     cm_buf_init(raw_ptr);          /* get index key from old record */
     cm_buf_get("%l %s %s ",&dummy,old_option,old_inumber);

     $BEGIN WORK;

     printf("1.old_inumber[%s]\n",old_inumber);
     $SELECT type,inumber,check_fedr,note,iclaim,iupdate,dupdate
        INTO $old_option,$old_inumber,$old_check_fedr,$old_note,$old_iclaim,$old_iupdate,$old_dupdate
        FROM car_spec_policy
       WHERE inumber = $old_inumber;

     /* if key value has been changed then SQLNOTFOUND,else put current value
        into cur_buf for comparison */

     if (SQLCODE==SQLNOTFOUND)
     {
         MsgCode = M_CM_NOT_FOUND;
         $WHENEVER SQLERROR CONTINUE;
         $ROLLBACK WORK;
         if (SQLCODE != 0) MsgCode = SQLCODE;         /* rollback fail */
         return exitsub(reply,MsgCode) ? MsgCode : apiRC;
     }

     cm_buf_init(cur_buf);
     cm_buf_put("%l ",dummy);
     cm_buf_put("%s %s %s %s %s %s %s",old_option,old_inumber,old_check_fedr,old_note,old_iclaim,old_iupdate,old_dupdate);
     
     write(1, cur_buf,raw_len);
     write(1,"\n",1);
     write(1, raw_ptr,raw_len);
     write(1,"\n",1);


     if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
     {
          MsgCode = M_CM_NOT_EQUAL;
          $WHENEVER SQLERROR CONTINUE;
          $ROLLBACK WORK;
          if (SQLCODE != 0) MsgCode = SQLCODE;         /* rollback fail */
          return exitsub(reply,MsgCode) ? MsgCode : apiRC;
     }

     /* equal, then exec DB operation */
     
     if(strlen(trim(old_iclaim)) == 0)
     	strcpy(old_iclaim," ");
     	
     if(strlen(trim(old_note)) == 0)
     	strcpy(old_note," ");

     if (option == 'D')
     {
          $DELETE FROM car_spec_policy WHERE inumber = $old_inumber;
          if(SQLCODE != 0)
          {
               is_del_fail = 1;
          }
          #ifdef DEBUG
          printf("Delete %d\n", j+1);
          #endif

          if( is_del_fail ) goto errexit;
          
          $INSERT INTO car_spec_policy_log (ikind, type, inumber, check_fedr, note, iclaim, iupdate, dupdate)
                  VALUES ('D', $old_option, $old_inumber, $old_check_fedr, $old_note, $old_iclaim, $userid, current);
          
          if(SQLCODE != 0)
          {
               is_upd_fail = 1;
          }
          
          if( is_upd_fail ) goto errexit;
                  
          cm_buf_init(ReplyBuf);
          cm_buf_put("%l",M_CM_OK);
          tmp_len = cm_buf_len(ReplyBuf);
          if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          {
               $WHENEVER SQLERROR CONTINUE;
               $ROLLBACK WORK;
               return apiRC;
          }

          $WHENEVER SQLERROR GOTO errexit;
          $COMMIT WORK;
          return api_OKComplete;
     }
     else if (option == 'U')
     {
          cm_buf_init(command);
          cm_buf_get("%c %s %s %s %s %s %s %s",&option, DBName , sOption, sInumber, sCheck_fedr, sNote, sIclaim, userid);

          /* grasp old key */
          cm_buf_init(raw_ptr);
          cm_buf_get("%l %s %s ",&dummy,old_option,old_inumber);
		  

          $WHENEVER SQLERROR CONTINUE;

          printf("old_inumber[%s]\n",old_inumber);
		  free(raw_ptr);
          
          if(strlen(trim(sIclaim)) == 0)
     		strcpy(sIclaim," ");
     	
     	  if(strlen(trim(sNote)) == 0)
     		strcpy(sNote," ");

          $UPDATE car_spec_policy
              SET (check_fedr, note, iclaim, iupdate, dupdate)
                = ($sCheck_fedr, $sNote, $sIclaim, $userid, current)
            WHERE inumber = $old_inumber;

          if(SQLCODE != 0) { is_upd_fail = 1; }

          if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
          {
               $INSERT INTO car_spec_policy (type, inumber, check_fedr, note, iclaim, iupdate, dupdate)
                                     VALUES ($sOption, $sInumber, $sCheck_fedr, $sNote, $sIclaim, $userid, current);
               if(SQLCODE != 0) { is_upd_fail = 1; }
               
               /* �g�Jlog�� */
               $INSERT INTO car_spec_policy_log (ikind, type, inumber, check_fedr, note, iclaim, iupdate, dupdate)
                           VALUES ('A', $sOption, $sInumber, $sCheck_fedr, $sNote, $sIclaim, $userid, current);
	       if(SQLCODE != 0) { is_upd_fail = 1; }

          }
          else
          {
          	/* �g�Jlog�� */
          	$INSERT INTO car_spec_policy_log (ikind, type, inumber, check_fedr, note, iclaim, iupdate, dupdate)
                           VALUES ('D', $old_option, $old_inumber, $old_check_fedr, $old_note, $old_iclaim, $userid, current);
 		if(SQLCODE != 0) { is_upd_fail = 1; }

          	$INSERT INTO car_spec_policy_log (ikind, type, inumber, check_fedr, note, iclaim, iupdate, dupdate)
                           VALUES ('A', $sOption, $sInumber, $sCheck_fedr, $sNote, $sIclaim, $userid, current);
		if(SQLCODE != 0) { is_upd_fail = 1; }
          }

          printf("Update\n");

          if( is_upd_fail ) goto errexit;

          cm_buf_init(ReplyBuf);
          cm_buf_put("%l",M_CM_OK);
          tmp_len = cm_buf_len(ReplyBuf);
          if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          {
               $WHENEVER SQLERROR CONTINUE;
               $ROLLBACK WORK;
               return apiRC;
          }
          $WHENEVER SQLERROR GOTO errexit;
          $COMMIT WORK;
          return api_OKComplete;
     }
     else
     {
          MsgCode = M_CM_WRONG_OPTION;
          $WHENEVER SQLERROR CONTINUE;
          $ROLLBACK WORK;
		  
		  free(raw_ptr);
		  
          if (SQLCODE != 0) MsgCode = SQLCODE;         /* rollback fail */
          return exitsub(reply,MsgCode) ? MsgCode : apiRC;
     }

errexit:
      MsgCode = SQLCODE;
      $WHENEVER SQLERROR CONTINUE;
      $ROLLBACK WORK;
      if (SQLCODE != 0) MsgCode = SQLCODE;         /* rollback fail */
      return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
