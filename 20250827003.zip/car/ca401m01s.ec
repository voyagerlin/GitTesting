/************************************************/
/*                                              */
/*   PROGRAM : ca401m01s.ec   (query function)  */
/*             ca416m01s.ec   (query function)  */
/************************************************/

#include <stdio.h>
#include "api_xsrv.h"
#include "sql.h"
#include "datetime.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "print.h"
#include "is_def.h"
#include "carmsgs.h"
#include "commsgs.h"
#include <time.h>
#include <math.h>
#include "safeclib.h"

$include sqlca;
$include "ply_ins_cover.h";
$include "ply_ins_assured.h";
$include "var_length.h";
$include "ca401lib.h";
$include "car_common.h";

#define TRUE 1
#define FALSE 0
#define NOT_FOUND sqlca.sqlcode == SQLNOTFOUND
#define FOUND sqlca.sqlcode != SQLNOTFOUND

struct PLY_INS_COVER *get_ply_ins_cover();
$char prep_stmt[5120];
$char equipdecode[201];
double d45();
char v_sMsg[1512];
long rtncode;
char sColumn[21], sTable[21], sDbname[21], sTable1[21], sTable2[21];
int tmp_buflen; /* ����ˮֵ{�������~�X Modified by Julia Han in 2007/08/20 */

static int DiffMonth();
static double MyPower();

/*******************************************************************/
long car401(reply, command, com_len)
serverReply reply;
voidP command;
int com_len;
{
  long rtncode;
  long car401_insert(), car401_single_query(), car401_single_query_1_2();
  long car416_insert();
  long car401_single_query_note();
  long car401_multiple_query1(), car401_delete_exec();
  long car401_multiple_query2();
  long car401_local_prn();
  long ca401q01s(), ca_rpt_ply_rcp(), ca409q02s();
  char option;

  memset(warning_code, 0, sizeof(warning_code));

  cm_buf_init(command);
  cm_buf_get("%c", &option);

  switch (option)
  {
  case 'A':
    rtncode = car401_insert(reply); /*** ca401m02s.ec ***/

    if (rtncode != M_CM_OK)
    {
      strcpy(warning_code, trim(warning_code));

      cm_buf_init(ReplyBuf);
      cm_buf_put("%l %s", rtncode, warning_code);

      tmp_buflen = cm_buf_len(ReplyBuf);
      if (SendSyncReply(reply, ReplyBuf, tmp_buflen, api_OKComplete) == False)
      {
        return apiRC;
      }
      return rtncode;
    }

    break;

#if 0
        case 'W':
          rtncode = car416_insert(reply);                 /*** ca416m01s.ec ������O�I�M�ק��@�~ ***/
          break;
#endif

  case '1':
    rtncode = car401_single_query_1_2(1, reply); /*** ca401m01s.ec ** (�H�ҥd�� �d�߫O��)*/
    break;

  case '2':
    rtncode = car401_single_query_1_2(2, reply); /*** ca401m01s.ec ** (�H�O�渹 �d�߫O��)*/
    break;

  case '3':
    rtncode = car401_single_query_note(reply); /*** ca401m01s.ec �d�߳Ƶ��ɸ�� ***/
    break;

  case 'Q':
    rtncode = car401_single_query(reply); /*** ca401m01s.ec **  (�d�ߧ��)*/
    break;

  case 'M':
    rtncode = car401_multiple_query1(reply); /*** ca401m01s.ec normal ***/
    break;

  case 'B':
    rtncode = car401_multiple_query2(reply); /*** ca401m01s.ec abnormal ***/
    break;

  case 'D':
    rtncode = car401_delete_exec(reply, command, com_len, option); /*** ca401m03s.ec ***/
    break;

  case 'L':
    rtncode = car401_local_prn(reply); /*** ca401m04s.ec ���C�L ***/
    break;

  case 'R':
    rtncode = ca401q01s(reply); /*** ca401q01s.ec ��榬�ڦC�L ***/
    break;

  case 'U':
    rtncode = ca409q02s(reply); /*** ca409q02s.ec �ˮ`�I���C�L����   ***/
    break;

  case 'T':
    rtncode = ca411_contact_transfer(reply); /*** ca401m04s.ec �j��L���v�q�ಾ ***/
    break;

  case 'P':
    rtncode = ca401_P(reply); /*** �C�Lú�O��� */
    break;

  case 'F':
    rtncode = car401_old_rule(reply); /* �s�w�����I����Y�ƾA���¨���� */
    break;

  case 'G':
    rtncode = ca401_G(reply); /* �ګO�Ȥᴣ�� */
    break;

  case 'V':
    rtncode = ca401_chk_reverse_num(reply);
    break;

  case 'H':
    rtncode = ca401_get_rel_data(reply); /* �����p�渹��� */
    break;

  case 'J':
    rtncode = ca401_GetDmgCoverEdr(reply); /* 1060919003_C1_�ק郞����ѵs�O�B���­p��
                                              ���o���l�I�O�B(���G�U��) (�̭��m���ȧ��­p��)
                                              ���­p���¦�GfOpt:0(�̵o�Ӥ��); 1(�̻s�y�~��) */
    break;

  case 'K':
    rtncode = ca401_get_policy(reply); /* ���̷s�O���� */
    break;

  case 'N':
    rtncode = ca401_get_dep_rate_prov(reply); /* �̫e��ӫO���p�A�^����O�w�]���²v���[���� */
    break;

  case 'E':
    rtncode = ca401_query_esign(reply); /*1080730005_SC2 �q�lñ�p���ظm�@�~*/
    break;

  case 'e':
    rtncode = ca401_update_esign(reply); /*1080730005_SC2 �q�lñ�p���ظm�@�~*/
    break;

  case 'I':
    rtncode = ca401_chk_cm_esign_data(reply); /*1080730005_SC2 �q�lñ�p���ظm�@�~*/
    break;

  case 'C':
    rtncode = get_compulsory_premium_icar_type(reply); /*1090601002_SC1 �}��CAR401���H�U�ҦC���إ~�A�i�H�H�����Ӹ��H��*/
    break;

  case 't':
    rtncode = Get_QdaySetup_ByRate(reply); /*1090828001_SC1_�ˮ�38.39�I�D���ϴ��I�����Ƥ��o�O�W��*/ /*1100119001_SC2 �s�W-�s�ӫ~(238�I-�D���ϴ��O�Ϊ��[����)�������ˮ֤Ϊ���*/
    break;

  case 'b':
    rtncode = get_user_branch_type(reply); /*1091021005_SC2�s�W�A�Ȥ��ߩ�����*/
    break;
  
  case 'c':
    rtncode = get_relative_ext_data(reply); /* ���O�T���p�����D��� (1140108008_C01) */
    break;
    
  case 'd':
    rtncode = chk_noccup_exception(reply); /* �ˮ֬O�_��"¾��~"���ҥ~�q��  (1140108008_C01) */
    break;

  case 'f':
    rtncode = chk_rel_itag(reply); /* �ˮ����p����(�j/��)�O�_�@�P (1140108008_C01) */
    break;
  
  case 'g':
    rtncode = get_bak_CusName(reply); /* ���o��O��Q�O�I�H�W�� (1140108008_C01) */
    break;
    
  case 'h':
    rtncode = ca401_transfer(reply); /* ���N�I�v�q����q���ѡG���o�I�حӼ� (1140108008_C01) */
    break;
    
  case 'i':
    rtncode = ca401_transfer_print1(reply); /* ���N�I�v�q����q���ѡG���o[�O���]�C�L��� (1140108008_C01) */
    break;
  
  case 'j':
    rtncode = ca401_transfer_print2(reply); /* ���N�I�v�q����q���ѡG���o[���p��]�C�L��� (1140108008_C01) */
    break;
  
  case 'k':
    rtncode = get_KYC_print_data1(reply); /* KYC���G���o�O���� (1140108008_C01) */
    break;
    
  case 'm':
    rtncode = get_KYC_print_data2(reply); /* KYC���G���o�I�ظ�� (1140108008_C01) */
    break;
    
  case 'n':
    rtncode = KYC_print(reply); /* KYC���G�C�L (1140108008_C01) */
    break;
    /*
            case 'p':
              rtncode = get_provision_new(reply);     1081225006_SC3 �X�R���[���ڥN�X
              break;
    */
  default:

#ifdef CA_CONS
    while (IfirstPlyInsCover != NULL)
    { /* free all allocated memory */
      IcurrPlyInsCover = IfirstPlyInsCover;
      IfirstPlyInsCover = IcurrPlyInsCover->next;
      free(IcurrPlyInsCover);
    }
#endif

#ifdef CA_ONE
    while (IfirstPlyInsAssured != NULL)
    { /* free all allocated memory */
      IcurrPlyInsAssured = IfirstPlyInsAssured;
      IfirstPlyInsAssured = IcurrPlyInsAssured->next;
      free(IcurrPlyInsAssured);
    }
#endif

    if (exitsub(reply, M_CM_WRONG_OPTION) == True)
      return M_CM_WRONG_OPTION;
    return apiRC;
  }

#ifdef CA_CONS
  while (IfirstPlyInsCover != NULL)
  { /* free all allocated memory */
    IcurrPlyInsCover = IfirstPlyInsCover;
    IfirstPlyInsCover = IcurrPlyInsCover->next;
    free(IcurrPlyInsCover);
  }
#endif

#ifdef CA_ONE
  while (IfirstPlyInsAssured != NULL)
  { /* free all allocated memory */
    IcurrPlyInsAssured = IfirstPlyInsAssured;
    IfirstPlyInsAssured = IcurrPlyInsAssured->next;
    free(IcurrPlyInsAssured);
  }
#endif

  return rtncode;
}

/****************************************************************************/
/*** �d�߫O���� ***********************************************************/
/****************************************************************************/
long car401_single_query_1_2(com, reply)
int com;
serverReply reply;
{
  /* standard defined host variables */
  $char DBName[5];
  int rc;
  long code;
  $char where_stmt[1024];
  $char stmt[4096];

  /* end of standard host var */

  /* table ply_realtion */
  $char ipolicy[POLICY_NUM_1], icard[CARD_NUM], irelative_ply[POLICY_NUM_1];
  $char ilast_ply[POLICY_NUM_1];
  $char iofficer[12], ibroker[BROKER], icashier[20], iresource[13];
  $char ibig_branch[8], fcard_class[2], ibranch[BRANCH_ID];
  $char ibig_office[11], ibig_sales[11];
  $long mdmg_prem_t, mlia_prem_t, mdmg_prem_t1, mlia_prem_t1;
  long premium1, premium2, premium;
  $long dpolicy;
  $int qdrunk_driving, qviolate; /*1110608012_SC2 �s�W�j��I�O�v�ǤJ���j�H�W�[�O���*/
  $char feply[2], feedr[2], feterms[2], aemail_eply[51], dcreate_eedr[31], dcreate_max[31];
  $char isign[11];
  $char fedr_class[2];
  $char fcomp_class_last[3], fcomp_class[3];
  $double mbusiness;
  char tmp_mbusiness[20];

  $char icar_flag[2]; /*** �s�¨����O ***/

  /* end of ply_realtion */

  /* table dailing_closing_ctl */
  $long dclosing, dwritten;
  /* end of dailing_closing_ctl */

  /* table policy */
  $char iassured[13], fassured[2], nuser[19], ibenef[11];
  $char iassured_ext[2];
  $char nbenef[43], aassured[100], itel[21], aassured_zip[CA_ZIP];
  $char iemail[51], itel_night[21], mobil_phone[21];
  $char itel_night_cus[21], mobil_phone_cus[21];
  $char apayment_zip[CA_ZIP], apayment[100];
  $long qply_period, dply_begin, dply_end;
  char s_dply_begin[11], s_dply_end[11];
  $char ipro_year[5], ibrand[9];
  $char icar_type[3], ncode[20];

  $char nassured[122];
  $char nbrand_abbr[16];
  $char fcar_note[6], ncar_abbr[16];
  $char iarea[11], iply_area[11];
  $char ibig_resource[8];
  $char fcomp_24[4];

  /*$long   qcylinder;*/
  $char iengine[CA_ENGINE_NUM], ibody[CA_BODY_NUM], itag[CA_TAG_NUM], ilicense[11], fsex[2];
  $char fmarriage[2], iacc_align[3], flimit[2];
  $long pdmg_align, plia_align, pbrg_align;
  $double mcar_price, qcylinder;
  char s_mcar_price[20];
  $char iabn_type[2], nequipment[31], itreaty[2], tmp_brand[7], ibig_comp[2];
  $char nequipment_tmp[31];
  $double pdmg_factor_1st, pbrg_factor_1st, pdmg_factor_2nd, pbrg_factor_2nd;
  $double temp_pdmg_factor, temp_pbrg_factor;
  $short dmg_2nd;

  $double qpt, psex_age, plia_acc, pdmg_acc, psex_age_damage;
  $char fpt[2];
  $char drate_ym[5];
  $int ibatch_no;
  $char batch_no[21];

  $int dmg_acc_1st, dmg_acc_2nd, dmg_acc_3rd;
  $char lia_class[3];

  /* bis9901141 �q����� */
  $char iroute[21];

  $char irate_type[2], bzfrom[3], iroute_comm[4], icomm_obj[11];

  /* car9903041 ���s�t�λP���O�B�ɨ�����s�� */
  $char ibound[421];

  /* �����O�T */
  $char iext_policy[21], irisk[2], irelative_ext[21];
  $long mkilo_ply, mkilo_edr, qpro_month, qprovision;

  $char napplicant[121]; /* car9705152 - �n�O�H */
  $long dbirth, dissue;  /* cmn9708011 - ����100�~ */
  char date1[11], date2[11];
  $char iextra_charge[11];                       /* for���[�O�βv�ϥ� */
  $int gextra_charge;                            /* for���[�O�βv�ϥ� */
  $char iquery_num_damage[121], iquery_num[121]; /* car9706251 - ���T�d�ߧǸ�*/
  /*$char     introducer[21];                                     car9705211 - �श�~�ȭ� */
  $double mequipment;                                       /* ���m���t�t�ƻ� */
  $char survey_num[121], bound_num[121], abnormal_num[121]; /* ����easy flow�渹 */
  $char iapplicant[13];                                     /* �n�O�HID */

  /* end of policy */

  $char sCompFrate[6], sIqueryNum[15], sNote[3], fcomp_class_err[3];

  $long coverage1_31, coverage2_31, coverage3_32; /* �W�B�d���I����h�ĤT�H�d���I�O�I���B */
  /* table ply_ins_type */
  $char iins_type[INSURANCE_TYPE];
  $long minjured_cover, mdeath_cover, mdamage_cover, mdeduct;
  $long mins_premium;  /* �I��ñ��O�O */
  $double lMpure_prem; /* �I�د«O�O   */
  $char fedr_status[2];
  $long qserial;
  $long lInsMprem; /* �I�سW���O�O */
  $long lMpremium; /* �W���`�O�O */

  $char tmp_pure_prem[14], tmp_mr_pure_prem[12];

  $long lMexpense;
  $long lMexp_disc;
  $long lQday;

  /* end of ply_ins_type */

  /* table appraisal */
  $char iacc_reason[3], iacc_21[3];
  $long msettle, mapp_loss;
  long losspay, outstanding, totalpay;
  long acctimes;
  $char daccident[25], s_daccident[25];
  $char iclaim[CLAIM_NUM], iclose[CLAIM_NUM], iclose_ctype[3], fclose[2];
  $char fdiscount[2], fhuman[4];
  /* end of appraisal */

  /* table ca_pa_ply */
  $int count_33, count_48, count_35, count_56;
  $char cIinsurant[11];
  $char cNinsurant[31];
  $char cDbirth[11];
  $long lDbirth;
  $char cAinsurant[91];
  $char cIins_scope[2];
  $char cIcareer[2];
  $long lMins_amt;
  $long lMins_premium;    /* ñ��O�O */
  $double lMpure_prem_33; /* �«O�O   */
  $double lMpure_prem_48; /* �«O�O   */
  $double lMpure_prem_35; /* �«O�O   */
  $double lMpure_prem_56; /* �«O�O   */
  $double dPcommission;
  $long lMcommission;
  $double dPagent;
  $long lMagent;
  $double dPdiscount;
  $long lMdiscount;
  $char cNapplicant[31];
  $char cRelation_appl[2];
  $char cNbeneficiary[31];
  $char cRelation_bene[2];
  $long ldaily_pay;
  $long lmr_ins_prem;
  $double dmr_pure_prem;
  $long ca_pa_ply_rowid;
  $char s_tenef[21], s_abenef_zip[CA_ZIP], s_abenef[91]; /*1090221006_SC2 ��_56�r�p�H�W�U_���*/
  /* end of ca_pa_ply */

  /* standard defined data */
  int tmp_len;
  /* end of standard data */

  /* self defined data */
  int count;
  char tmp_pdmg_factor_1st[20], tmp_pbrg_factor_1st[20];
  char tmp_pdmg_factor_2nd[20], tmp_pbrg_factor_2nd[20];
  /** dale **/
  char tmp_discount[6], tmp_commission[6], tmp_agent[6];
  $double pdiscount, pcommission, pagent;
  $long mdiscount, mcommission, magent;
  $date Today;
  $char sTmp_iendorse[ENDORSE_NUM], sIins_type[INSURANCE_TYPE];

  /* ���O���A�d�� */
  char payresult[5], paystatus[100], paydate[100], notedate[100];

  char tmp_qpt[11], tmp_psex_age[15], tmp_plia_acc[7], tmp_pdmg_acc[7], tmp_psex_age_damage[15], tmp_qcylinder[9];
  char policy_1[POLICY_NUM_1], policy_2[POLICY_NUM_2];
  /* end of self data */

  $char fNo_mdeduct[2], fRescue[2];

  $char sType_131[3];
  $char sInumber_131[21];
  $char sCheck_fedr_131[11];
  $char sNote_131[101];

  $char sTypeRtn_131[3];
  $char sInumberRtn_131[21];
  $char sCheck_fedrRtn_131[11];
  $char sNoteRtn_131[101];

  $char provision[21], fedr_m[2];
  $char iinstall[11], fedr_flag1[2], fedr_flag2[2], fedr_flag3[2], fedr_flag4[2];
  $char dexpire[13], dexpire_m[2], off_iquota[11], imgr[2];

  /* 'car9610231��~�βĤT�H�f�B�~���[���� */
  $double safe_rate;
  $double manage_rate;
  $double educated_rate;

  /* �«O�O�����v */
  $double deviation_rate;

  /* �O�v�ۥѤ� */
  $double pextra_charge;
  $double pbusiness;

  $long iCount=0;

  /* 1000728003_C2 �ĤT�H�d���I���ŧאּ5��(���) */
  $long qlia_acc_sum, qdmg_acc_sum;

  $long mservice, mcover_limit;
  $char fapplicant[2], fsex_appl[2], dbirth_appl[11], itel_appl[21], ndeputy_appl[51], nrelation_appl[41], ndeputy_assured[51];
  $char transno[21], userid[11], dcreate_ply[11];
  $char iins_kit[4];
  $char iassured_cntry[2], iapplicant_cntry[2];
  $char fequipment1[2], fequipment2[2], fequipment3[2], fequipment4[2], fequipment5[2], fequipment6[2], fequipment9[2], nequipment9[101];
  $char dentry[11];
  $char nassured_cntry[51], napplicant_cntry[51];

  $char iquery_num_unknown[121];
  $double punknown_acc;
  $long qunknown_acc_sum;

  $char foccup[2], noccup[6];
  $char applicant_foccup[2], applicant_noccup[6];
  $char iowner[13], nowner[121], dbirth_owner[11];
  $char tmobile_appl[21], aemail_appl[51];
  $char dtply_begin[17], dtply_end[17]; /* 1061108001_SC6_�t�X�s�еo�i���ߨt�λݨD���Ѭ����t�Υ\�� yyyy-mm-dd HH:MM */
  $char iroute_accept[21];              /* 1071225004_SC1_ ����_���I�W��ѽվ�*/
  $char tmobile_eply[21];               /* 1080417001_SC2 �s�W�q�l�O��H²�T�覡�o�e */
  $char ireg_no[21];                    /* 1080408005_SC2 �j��{�ҷs�W�q����Ƥεn���Ҹ� */
  $char fpart[2] = "", fclose_56[2] = "", s_dtransfer[11] = "";

  $long dinstall;
  $char isequence[31], ainstall_zip[7], ainstall[91]; /*1120927002_C02 �R�q�ΰӫ~�}�o*/

  time_t a_tt, b_tt;
  double diff;

  mdmg_prem_t = 0;
  mlia_prem_t = 0;
  mdmg_prem_t1 = 0;
  mlia_prem_t1 = 0;
  coverage1_31 = coverage2_31 = coverage3_32 = 0;
  count_33 = count_48 = count_35 = count_56 = 0;

  cm_buf_get("%s", DBName);

  if (com == 1) /*** �O�I�d/�Ҹ� ***/
  {
    cm_buf_get("%s", icard);
    if (icard[0] == ' ' || icard[0] == '\0')
    {
      if (exitsub(reply, M_CA_NOT_CARD) == True)
        return M_CA_NOT_CARD;
      else
        return apiRC;
    }
    sprintf_s(where_stmt, sizeof where_stmt, "a.icard = '%s' ", icard);
  }
  else if (com == 2) /*** �O�渹�X ***/
  {
    cm_buf_get("%s", ipolicy);
    if (ipolicy[0] == ' ' || ipolicy[0] == '\0')
    {
      if (exitsub(reply, M_CA_NPOLICY) == True)
        return M_CA_NPOLICY;
      else
        return apiRC;
    }
    sprintf_s(where_stmt, sizeof where_stmt, "a.ipolicy = '%s' ", ipolicy);
  }
  else
  {
    if (exitsub(reply, M_CM_WRONG_OPTION) == True)
      return M_CM_WRONG_OPTION;
    else
      return apiRC;
  }
  cm_buf_get("%s", userid);

  EXEC SQL WHENEVER SQLERROR GOTO errexit;
  if (db_select(DBName) == False)
  {
    if (exitsub(reply, M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }

  cm_buf_init(ReplyBuf);
  cm_buf_res_msg();
  cm_buf_res_count();
  cm_buf_put_msg(M_CM_OK);
  sprintf_s(stmt, sizeof stmt, "SELECT a.icard, a.ipolicy, a.fcard_class, a.irelative_ply, a.ilast_ply,"
                "       a.itreaty, a.qply_period, a.dply_begin, a.dply_end,"
                "       a.ipro_year, a.ibrand, a.icar_type,"
                "       a.mdmg_prem, a.mlia_prem, a.ibig_comp, a.ibig_branch,"
                "       a.ibig_office, a.ibig_sales,"
                "       a.iresource, a.ibroker, a.iofficer, a.icashier,"
                "       a.iarea, a.dpolicy, a.fedr_class, a.ibranch, a.mbusiness,"
                "       a.fcomp_class, a.fcomp_class_last, a.fdiscount, a.ibatch_no, a.icar_flag,"
                "       b.fassured, b.iassured, b.iassured_ext, b.nassured, b.ilicense, b.fsex,"
                "       b.fmarriage, b.nuser, b.ibenef, b.nbenef, b.aassured, b.aassured_zip,"
                "       b.apayment, b.apayment_zip,"
                "       b.itel, b.iply_area, b.nbrand_abbr, b.ncar_abbr, b.fcar_note, b.qcylinder,"
                "       b.iengine, b.ibody, b.itag, b.mcar_price, b.nequipment, b.flimit,"
                "       b.pdmg_align, b.pbrg_align, b.plia_align, b.iabn_type,"
                "       b.lia_class, b.dmg_acc_1st, b.dmg_acc_2nd, b.dmg_acc_3rd,"
                "       b.pdmg_factor, b.pbrg_factor,"
                "       b.qpt, b.fpt, b.psex_age, b.psex_age_damage, b.plia_acc, b.pdmg_acc, b.fhuman, "
                "       b.fcomp_24, a.iinstall,"
                "       b.iext_policy, b.qpro_month, b.mkilo_ply, b.mkilo_edr, b.irisk, b.irelative_ext,"
                "       b.napplicant, b.dbirth, b.dissue, "
                "       b.iextra_charge, nvl(b.gextra_charge,0), b.pextra_charge, "
                "       b.iquery_num_damage, b.iquery_num, b.mequipment, "
                "       b.survey_num, b.bound_num, b.abnormal_num, b.iapplicant, b.iemail, b.iroute, "
                "       a.irate_type,a.bzfrom,a.iroute_comm,a.icomm_obj, b.qlia_acc_sum, b.qdmg_acc_sum,  "
                "       case when fcard_class = '1' then mlia_commi else 0 end, a.qprovision, b.itel_night, b.mobil_phone, "
                "       b.fapplicant,b.fsex_appl,b.dbirth_appl,b.itel_appl,b.ndeputy_appl,b.nrelation_appl,b.ndeputy_assured,a.transno,"
                "       a.qdrunk_driving, a.isign, date(a.dcreate), b.iins_kit, b.mcover_limit, b.iassured_cntry, b.iapplicant_cntry, "
                "       b.fequipment1,b.fequipment2,b.fequipment3,b.fequipment4,b.fequipment5,b.fequipment6,b.fequipment9,b.nequipment9, "
                "       a.dentry, b.punknown_acc, b.iquery_num_unknown, b.qunknown_acc_sum, a.feply, a.aemail_eply, b.nassured_cntry, b.napplicant_cntry, "
                "       b.foccup, b.noccup, b.applicant_foccup, b.applicant_noccup, b.iowner, b.nowner, b.dbirth_owner, b.tmobile_appl, b.aemail_appl , a.dtply_begin, a.dtply_end, "
                "       b.iroute_accept,a.tmobile_eply,a.ireg_no,a.dtransfer,a.feterms,a.qviolate, "
                "       b.dinstall, b.isequence, b.ainstall_zip, b.ainstall "
                "  FROM ply_relation a, policy b"
                " WHERE %s"
                "AND a.ipolicy = b.ipolicy "
                "AND a.dply_close IS NOT NULL",
          where_stmt);
  printf("stmt[%s]\n", stmt);
  EXEC SQL PREPARE sel_ply_rel FROM $stmt;
  EXEC SQL EXECUTE sel_ply_rel INTO $icard, $ipolicy, $fcard_class, $irelative_ply, $ilast_ply,
      $itreaty, $qply_period, $dply_begin, $dply_end,
      $ipro_year, $ibrand, $icar_type,
      $mdmg_prem_t, $mlia_prem_t, $ibig_comp, $ibig_branch,
      $ibig_office, $ibig_sales,
      $iresource, $ibroker, $iofficer, $icashier,
      $iarea, $dpolicy, $fedr_class, $ibranch, $mbusiness,
      $fcomp_class, $fcomp_class_last, $fdiscount, $ibatch_no, $icar_flag,
      $fassured, $iassured, $iassured_ext, $nassured, $ilicense, $fsex,
      $fmarriage, $nuser, $ibenef, $nbenef, $aassured, $aassured_zip,
      $apayment, $apayment_zip,
      $itel, $iply_area, $nbrand_abbr, $ncar_abbr, $fcar_note, $qcylinder,
      $iengine, $ibody, $itag, $mcar_price, $nequipment, $flimit,
      $pdmg_align, $pbrg_align, $plia_align, $iabn_type,
      $lia_class, $dmg_acc_1st, $dmg_acc_2nd, $dmg_acc_3rd,
      $pdmg_factor_1st, $pbrg_factor_1st,
      $qpt, $fpt, $psex_age, $psex_age_damage, $plia_acc, $pdmg_acc, $fhuman, $fcomp_24,
      $iinstall, $iext_policy, $qpro_month, $mkilo_ply, $mkilo_edr,
      $irisk, $irelative_ext,
      $napplicant, $dbirth, $dissue,
      $iextra_charge, $gextra_charge, $pextra_charge,
      $iquery_num_damage, $iquery_num, $mequipment,
      $survey_num, $bound_num, $abnormal_num, $iapplicant, $iemail, $iroute,
      $irate_type, $bzfrom, $iroute_comm, $icomm_obj, $qlia_acc_sum, $qdmg_acc_sum, $mservice, $qprovision,
      $itel_night, $mobil_phone, $fapplicant, $fsex_appl, $dbirth_appl, $itel_appl, $ndeputy_appl,
      $nrelation_appl, $ndeputy_assured, $transno, $qdrunk_driving, $isign, $dcreate_ply, $iins_kit, $mcover_limit,
      $iassured_cntry, $iapplicant_cntry, $fequipment1, $fequipment2, $fequipment3, $fequipment4,
      $fequipment5, $fequipment6, $fequipment9, $nequipment9, $dentry,
      $punknown_acc, $iquery_num_unknown, $qunknown_acc_sum, $feply, $aemail_eply,
      $nassured_cntry, $napplicant_cntry, $foccup, $noccup, $applicant_foccup, $applicant_noccup,
      $iowner, $nowner, $dbirth_owner, $tmobile_appl, $aemail_appl, $dtply_begin, $dtply_end,
      $iroute_accept, $tmobile_eply, $ireg_no, $s_dtransfer, $feterms, $qviolate,
      $dinstall, $isequence, $ainstall_zip, $ainstall;

  if (SQLCODE == SQLNOTFOUND)
  {
    if (com == 1) /*** �O�I�d/�� ***/
    {
      {
        if (exitsub(reply, M_CA_NOT_CARD) == True)
          return M_CA_NOT_CARD;
        else
          return apiRC;
      }
    }

    if (com == 2) /*** �O�I�渹 ***/
    {
      if (SQLCODE == SQLNOTFOUND)
      {
        if (exitsub(reply, M_CA_NPOLICY) == True)
          return M_CA_NPOLICY;
        else
          return apiRC;
      }
    }
  }

  $select count(*)
      into $iCount
          from cu_code_data
              where itype = 'CK'
                  and icode = $userid;
  if (iCount == 0)
  {
    rc = chk_personal_deny(iassured, v_sMsg);
    if (rc != M_CM_OK)
    {
      if (exitsub(reply, rc) == True)
        return rc;
      else
        return apiRC;
    }
    if (strlen(trim(v_sMsg)) != 0)
    {
      strcpy(warning_code, v_sMsg);
      strcat(warning_code, ";");
    }
  }

  if (fcard_class[0] == '1') /* �j���I */
  {
    premium1 = mdmg_prem_t + mlia_prem_t;
    premium2 = 0;
  }
  else
  {
    premium1 = 0;
    premium2 = mdmg_prem_t + mlia_prem_t;
  }
  premium = premium1 + premium2;

  strcpy(nequipment_tmp, equip_delete(nequipment, "101"));
  strcpy(nequipment, nequipment_tmp);

  if (equip_cmp(nequipment, "17") == TRUE ||
      equip_cmp(nequipment, "67") == TRUE)
  {
    $SELECT fcomp_class, iquery_num, note, fcomp_class_err 
       INTO : sCompFrate, : sIqueryNum, : sNote, : fcomp_class_err 
       FROM ca_comp_return WHERE ipolicy = : ipolicy;
    if (SQLCODE == SQLNOTFOUND)
    {
      sCompFrate[0] = '\0';
      sIqueryNum[0] = '\0';
      sNote[0] = '\0';
      fcomp_class_err[0] = '\0';
    }
  }
  else
  {
    sCompFrate[0] = '\0';
    sIqueryNum[0] = '\0';
    sNote[0] = '\0';
    fcomp_class_err[0] = '\0';
  }

  /* ����ȪA����ɮפ��q��[�]],��ʹq�� */
  /* 1060607007_C1 ���t�Ψ����a�ȪA�� */
  /*
  EXEC SQL SELECT tphone_con , imovephone
             INTO :itel_night_cus , :mobil_phone_cus
             FROM cu_customer
            WHERE ifpce_id     = $iassured
              AND ifpce_id_ext = $iassured_ext;

  if (SQLCODE == SQLNOTFOUND)
  {
      strcpy( itel_night_cus, " ");
      strcpy( mobil_phone_cus, " ");
  }

  if( strlen( trim(itel_night)) == 0)
      strcpy( itel_night, itel_night_cus);

  if( strlen( trim(mobil_phone)) == 0)
      strcpy( mobil_phone, mobil_phone_cus);
  */

  /******************************************/
  /* com == 1 USE card_num to SELECT        */
  /* com == 2 USE policy_num to SELECT      */
  /******************************************/

  strncpy(tmp_brand, ibrand, 6);
  tmp_brand[6] = '\0';

  pdmg_factor_2nd = 0;
  pbrg_factor_2nd = 0;

  /**** �d�ݷ���O�_�w�����L��諸�ʧ@ ****/
  rtoday(&Today);
  $DECLARE EDR_CUR CURSOR FOR
      SELECT iendorse
        FROM edr_relation
       WHERE ipolicy = $ipolicy
         AND dentry = $Today
    ORDER BY dcreate DESC;
  $OPEN EDR_CUR;
  $FETCH EDR_CUR INTO $sTmp_iendorse;
  if (SQLCODE == SQLNOTFOUND)
    sTmp_iendorse[0] = '\0';

  strcpy(s_dply_begin, cm_cdate_str_100(dply_begin));
  strcpy(s_dply_end, cm_cdate_str_100(dply_end));

  cm_buf_put("%s %s %s %s %s",
             fcard_class, ipolicy, icard, ilast_ply, irelative_ply);

  cm_buf_put("%s %c %s %s %s %s %s %s %s",
             iassured, fassured[0], nassured, nuser, ibenef, nbenef, aassured, aassured_zip, itel);

  cm_buf_put("%s %s %s ", itel_night, mobil_phone, iemail);

  cm_buf_put("%s %s", apayment, apayment_zip);

  cm_buf_put("%s ", iply_area);

  cm_buf_put("%l %s %s", qply_period, s_dply_begin, s_dply_end);

  cm_buf_put("%s %s %s %s %s %s",
             ipro_year, ibrand, nbrand_abbr, icar_type, fcar_note, ncar_abbr);

  sprintf_s(tmp_qcylinder, sizeof tmp_qcylinder, "%7.2f", qcylinder); /* 1080902001_SC2 �Ʈ�q�X�ܤp���I2�� */
  cm_buf_put("%s", tmp_qcylinder);

  printf("1tmp_qpt[%s]\n", tmp_qpt);
  printf("qpt[%f]\n", qpt);
  printf("sizeof tmp_qpt[%d]\n", sizeof tmp_qpt);
  sprintf_s(tmp_qpt, sizeof tmp_qpt, "%4.1f", qpt);
  printf("2tmp_qpt[%s]\n", tmp_qpt);
  cm_buf_put("%s %s", tmp_qpt, fpt);

  sprintf_s(tmp_pdmg_factor_1st, sizeof tmp_pdmg_factor_1st, "%6.4f", pdmg_factor_1st);
  sprintf_s(tmp_pbrg_factor_1st, sizeof tmp_pbrg_factor_1st, "%6.4f", pbrg_factor_1st);
  if (dmg_2nd == -1)
  {
    memset(tmp_pdmg_factor_2nd, 0, sizeof(tmp_pdmg_factor_2nd));
    memset(tmp_pbrg_factor_2nd, 0, sizeof(tmp_pbrg_factor_2nd));
  }
  else
  {
    sprintf_s(tmp_pdmg_factor_2nd, sizeof tmp_pdmg_factor_2nd, "%6.4f", pdmg_factor_2nd);
    sprintf_s(tmp_pbrg_factor_2nd, sizeof tmp_pbrg_factor_2nd, "%6.4f", pbrg_factor_2nd);
  }
  cm_buf_put("%s %s %s %s",
             tmp_pdmg_factor_1st, tmp_pbrg_factor_1st,
             tmp_pdmg_factor_2nd, tmp_pbrg_factor_2nd);

  cm_buf_put("%s %s %s %s %c %c",
             iengine, ibody, itag, ilicense, fsex[0], fmarriage[0]);

  cm_buf_put("%s", icar_flag); /*** �s�¨��O ***/

  sprintf_s(tmp_psex_age, sizeof tmp_psex_age, "%3.12f", psex_age);
  sprintf_s(tmp_plia_acc, sizeof tmp_plia_acc, "%6.2f", plia_acc);
  sprintf_s(tmp_pdmg_acc, sizeof tmp_pdmg_acc, "%6.2f", pdmg_acc);

  cm_buf_put("%s %e %s %s", tmp_psex_age, psex_age_damage, tmp_plia_acc, tmp_pdmg_acc);

  cm_buf_put("%s %d %d %d", lia_class, dmg_acc_1st, dmg_acc_2nd, dmg_acc_3rd);

  cm_buf_put("%f %s %s", mbusiness, fcomp_class_last, fcomp_class);

  cm_buf_put("%l %l %l", pdmg_align, pbrg_align, plia_align);

  cm_buf_put("%s %s %s %s %s %s    %s %s %s %s %s %s",
             iabn_type, fdiscount, iofficer, ibroker, iarea, ibig_comp,
             iresource, ibig_branch, iroute, ibig_office, ibig_sales, iinstall);

  sprintf_s(s_mcar_price, sizeof s_mcar_price, "%6.1f", mcar_price);

  strcpy(equipdecode, equip_get(nequipment));
  cm_buf_put("%s %s %s %s %s",
             s_mcar_price, equipdecode, itreaty, fcomp_24, fhuman);

  cm_buf_put("%s %s %s %s", sCompFrate, sIqueryNum, sNote, fcomp_class_err);
  cm_buf_put("%s %s %s %s %l", irate_type, bzfrom, iroute_comm, icomm_obj, qprovision);

  /*** ���I��O���Ӹ�� ***/
  lMpremium = 0;
  $DECLARE query1 CURSOR FOR
    SELECT iins_type,
        minjured_cover, mdeath_cover, mdamage_cover, mdeduct,
        mins_premium, mpure_prem, mprem,
        fedr_status, qserial, pcommission, pagent, pdiscount, drate_ym,
        qday, mexpense, mexp_disc, provision, safe_rate, manage_rate, educated_rate,
        deviation_rate, pextra_charge, pbusiness, psex_age 
    INTO $iins_type, $minjured_cover, $mdeath_cover, $mdamage_cover, $mdeduct,
        $mins_premium, $lMpure_prem, $lInsMprem,
        $fedr_status, $qserial, $pcommission, $pagent, $pdiscount, $drate_ym,
        $lQday, $lMexpense, $lMexp_disc, $provision, $safe_rate, $manage_rate, $educated_rate,
        $deviation_rate, $pextra_charge, $pbusiness, $psex_age 
    FROM ply_ins_type 
   WHERE ipolicy = $ipolicy 
   ORDER BY iins_type;
  $OPEN query1;
  count = 0;
  for (;;)
  {
    $FETCH query1;
    if (SQLCODE != 0)
      break;

    count++;

    lMpremium += lInsMprem;
    /* �N���[�O�O��ñ��O�O�γW���O�O���ư� */
    if (((strcmp(trim(iins_type), "01") == 0) ||
         (strcmp(trim(iins_type), "05") == 0) ||         
         (strcmp(trim(iins_type), "09") == 0) ||
         (strcmp(trim(iins_type), "198") == 0)||
         (strcmp(trim(iins_type), "11") == 0) ||
         (strcmp(trim(iins_type), "201") == 0) ||
         (strcmp(trim(iins_type), "205") == 0) ||
         (strcmp(trim(iins_type), "209") == 0) ||
         (strcmp(trim(iins_type), "211") == 0) ) &&
        (lMexpense != 0))
    {
      mins_premium = mins_premium - lMexpense;
      lInsMprem = lInsMprem - (lMexpense + lMexp_disc);
    }

    minjured_cover = minjured_cover / 100;
    mdeath_cover = mdeath_cover / 100;
    mdamage_cover = mdamage_cover / 100;

    sprintf_s(tmp_commission, sizeof tmp_commission, "%4.2f", pcommission);
    sprintf_s(tmp_agent, sizeof tmp_agent, "%4.2f", pagent);
    sprintf_s(tmp_discount, sizeof tmp_discount, "%4.2f", pdiscount);

    sprintf_s(tmp_pure_prem, sizeof tmp_pure_prem, "%13.4f", lMpure_prem);
    strcpy(tmp_pure_prem, trim(tmp_pure_prem));

    /* �ഫ�W�B�d���I��h�O�B�N��qday���ĤT�H�d���I�O�I���B�@,�G,�T */
    if (strcmp(trim(iins_type), "29") == 0)
    {
      code = lReturnIns29BaseCover(lQday, &coverage1_31, &coverage2_31, &coverage3_32);
      lQday = 0;
    }

    if (strcmp(trim(iins_type), "31") == 0 || strcmp(trim(iins_type), "231") == 0 || strcmp(trim(iins_type), "531") == 0)
    {
      lQday = 0;
    }

    printf("provision[%s], psex_age[%f]\n", provision, psex_age);
    cm_buf_put("%s %l %l %l %l %s  %l %l %s   %s %s   %s %s %s   %l %l %e %e %e %e %e  %e %e",
               iins_type, minjured_cover, mdeath_cover, mdamage_cover, mdeduct, provision,
               lInsMprem, mins_premium, tmp_pure_prem,
               " ", drate_ym,
               tmp_commission, tmp_agent, tmp_discount,
               lQday, lMexpense, safe_rate, manage_rate, educated_rate, deviation_rate, pextra_charge,
               pbusiness, psex_age);
  }
  $CLOSE query1;
  $FREE query1;

  if (count == 0)
  {
    if (exitsub(reply, M_CA_NPLY_INS_TYPE) == True)
      return M_CA_NPLY_INS_TYPE;
    else
      return apiRC;
  }

  cm_buf_put_count(count);

  cm_buf_put("%l %l %l", coverage1_31, coverage2_31, coverage3_32);

  EXEC SQL SELECT count(*)
      INTO : count_33
                 FROM ca_pa_ply
                     WHERE ipolicy = $ipolicy
                         AND iins_type = '33';

  cm_buf_put("%d ", count_33);

  /*** �ˮ`�I���� ***/
  $DECLARE query1_33 CURSOR FOR
      SELECT iinsurant,
          ninsurant, dbirth, ainsurant,
          iins_scope, icareer,
          mins_amt, mins_premium, mpure_prem,
          napplicant, relation_appl,
          nbeneficiary, relation_bene,
          pcommission, pagent, pdiscount,
          daily_pay, mr_ins_prem, mr_pure_prem 
       INTO : cIinsurant, : cNinsurant, : lDbirth, : cAinsurant, : cIins_scope, : cIcareer, : lMins_amt, 
            : lMins_premium, : lMpure_prem_33, : cNapplicant, : cRelation_appl, : cNbeneficiary, : cRelation_bene, 
            : dPcommission, : dPagent, : dPdiscount, : ldaily_pay, : lmr_ins_prem, : dmr_pure_prem 
       FROM ca_pa_ply 
      WHERE ipolicy = $ipolicy AND iins_type = '33' 
      ORDER BY iinsurant, iins_scope, icareer;
  $OPEN query1_33;
  for (;;)
  {
    $FETCH query1_33;
    if (SQLCODE != 0)
      break;

    lMins_amt = lMins_amt / 10000;

    strcpy(cDbirth, cm_cdate_str_100(lDbirth));

    sprintf_s(tmp_commission, sizeof tmp_commission, "%4.2f", dPcommission);
    sprintf_s(tmp_agent, sizeof tmp_agent, "%4.2f", dPagent);
    sprintf_s(tmp_discount, sizeof tmp_discount, "%4.2f", dPdiscount);

    sprintf_s(tmp_pure_prem, sizeof tmp_pure_prem, "%10.0f", lMpure_prem_33);
    strcpy(tmp_pure_prem, trim(tmp_pure_prem));

    sprintf_s(tmp_mr_pure_prem, sizeof tmp_mr_pure_prem, "%10.0f", dmr_pure_prem);
    strcpy(tmp_mr_pure_prem, trim(tmp_mr_pure_prem));

    cm_buf_put("%s %s %s %s   %s %s   %l %l %s   %s %s   %s %s  %s %s %s  %l %l %s ",
               cIinsurant, cNinsurant, cDbirth, cAinsurant,
               cIins_scope, cIcareer,
               lMins_amt, lMins_premium, tmp_pure_prem,
               cNapplicant, cRelation_appl,
               cNbeneficiary, cRelation_bene,
               tmp_commission, tmp_agent, tmp_discount,
               ldaily_pay, lmr_ins_prem, tmp_mr_pure_prem);
  }
  $CLOSE query1_33;
  $FREE query1_33;

  EXEC SQL SELECT count(*) INTO : count_48 FROM ca_pa_ply WHERE ipolicy = $ipolicy AND iins_type = '48';

  cm_buf_put("%d ", count_48);

  /*** �ˮ`�I���� ***/
  $DECLARE query1_48 CURSOR FOR
      SELECT iinsurant,
          ninsurant, dbirth, iins_scope,
          mins_amt, mins_premium, mpure_prem,
          relation_appl,
          pcommission, pagent, pdiscount,
          daily_pay, mr_ins_prem, mr_pure_prem 
      INTO : cIinsurant, : cNinsurant, : lDbirth, : cIins_scope, : lMins_amt, : lMins_premium, : lMpure_prem_48, 
           : cRelation_appl, : dPcommission, : dPagent, : dPdiscount, : ldaily_pay, : lmr_ins_prem, : dmr_pure_prem 
      FROM ca_pa_ply 
      WHERE ipolicy = $ipolicy AND iins_type = '48' 
   ORDER BY iinsurant, iins_scope;
  $OPEN query1_48;
  for (;;)
  {
    $FETCH query1_48;
    if (SQLCODE != 0)
      break;

    lMins_amt = lMins_amt / 10000;
    ldaily_pay /= 10000;

    strcpy(cDbirth, cm_cdate_str_100(lDbirth));

    sprintf_s(tmp_commission, sizeof tmp_commission, "%4.2f", dPcommission);
    sprintf_s(tmp_agent, sizeof tmp_agent, "%4.2f", dPagent);
    sprintf_s(tmp_discount, sizeof tmp_discount, "%4.2f", dPdiscount);

    sprintf_s(tmp_pure_prem, sizeof tmp_pure_prem, "%10.0f", lMpure_prem_48);
    strcpy(tmp_pure_prem, trim(tmp_pure_prem));

    sprintf_s(tmp_mr_pure_prem, sizeof tmp_mr_pure_prem, "%10.0f", dmr_pure_prem);
    strcpy(tmp_mr_pure_prem, trim(tmp_mr_pure_prem));

    cm_buf_put("%s %s %s %s  %l %l %s  %s  %s %s %s  %l %l %s ",
               cIinsurant, cNinsurant, cDbirth, cIins_scope,
               lMins_amt, lMins_premium, tmp_pure_prem,
               cRelation_appl,
               tmp_commission, tmp_agent, tmp_discount,
               ldaily_pay, lmr_ins_prem, tmp_mr_pure_prem);
  }
  $CLOSE query1_48;
  $FREE query1_48;

  EXEC SQL SELECT count(*) INTO : count_35 FROM ca_pa_ply WHERE ipolicy = $ipolicy AND iins_type = '35';

  cm_buf_put("%d ", count_35);

  /*** �ˮ`�I���� ***/
  $DECLARE query1_35 CURSOR FOR
      SELECT iinsurant,
          ninsurant, iins_scope,
          mins_amt, mins_premium, mpure_prem,
          pcommission, pagent, pdiscount 
        INTO : cIinsurant, : cNinsurant, : cIins_scope, : lMins_amt, : lMins_premium, : lMpure_prem_35, 
             : dPcommission, : dPagent, : dPdiscount 
        FROM ca_pa_ply 
       WHERE ipolicy = $ipolicy AND iins_type = '35' 
       ORDER BY iinsurant, iins_scope;
  $OPEN query1_35;
  for (;;)
  {
    $FETCH query1_35;
    if (SQLCODE != 0)
      break;

    lMins_amt = lMins_amt / 10000;

    sprintf_s(tmp_commission, sizeof tmp_commission, "%4.2f", dPcommission);
    sprintf_s(tmp_agent, sizeof tmp_agent, "%4.2f", dPagent);
    sprintf_s(tmp_discount, sizeof tmp_discount, "%4.2f", dPdiscount);

    sprintf_s(tmp_pure_prem, sizeof tmp_pure_prem, "%10.0f", lMpure_prem_35);
    strcpy(tmp_pure_prem, trim(tmp_pure_prem));

    sprintf_s(tmp_mr_pure_prem, sizeof tmp_mr_pure_prem, "%10.0f", dmr_pure_prem);
    strcpy(tmp_mr_pure_prem, trim(tmp_mr_pure_prem));

    cm_buf_put("%s %s %s  %l %l %s %s %s %s ",
               cIinsurant, cNinsurant, cIins_scope,
               lMins_amt, lMins_premium, tmp_pure_prem,
               tmp_commission, tmp_agent, tmp_discount);
  }
  $CLOSE query1_35;
  $FREE query1_35;

  strcpy(sIins_type, " ");
  EXEC SQL SELECT first 1 iins_type, count(*) INTO $sIins_type, : count_56 
             FROM ca_pa_ply WHERE ipolicy = $ipolicy AND iins_type in('56', '136', '166', '266') group by 1;

  cm_buf_put("%d %s ", count_56, sIins_type);

  /*1090221006_SC2 ��_56�r�p�H�W�U_���*/
  /*** �ˮ`�I���� ***/
  $DECLARE query1_56 CURSOR FOR
      SELECT iinsurant,
          ninsurant, dbirth, iins_scope,
          mins_amt, mins_premium, mpure_prem,
          nbeneficiary, relation_bene,
          pcommission, pagent, pdiscount,
          daily_pay, mr_ins_prem, mr_pure_prem, rowid, tbenef, abenef_zip, abenef 
      INTO : cIinsurant, : cNinsurant, : lDbirth, : cIins_scope, : lMins_amt, : lMins_premium, : lMpure_prem_56, 
           : cNbeneficiary, : cRelation_bene, : dPcommission, : dPagent, : dPdiscount, : ldaily_pay, : lmr_ins_prem, 
           : dmr_pure_prem, : ca_pa_ply_rowid, : s_tenef, : s_abenef_zip, : s_abenef 
      FROM ca_pa_ply 
     WHERE ipolicy = $ipolicy AND iins_type = $sIins_type 
     ORDER BY iinsurant, iins_scope;
  $OPEN query1_56;
  for (;;)
  {
    $FETCH query1_56;
    if (SQLCODE != 0)
      break;

    lMins_amt = lMins_amt / 10000;

    strcpy(cDbirth, cm_cdate_str_100(lDbirth));

    sprintf_s(tmp_commission, sizeof tmp_commission, "%4.2f", dPcommission);
    sprintf_s(tmp_agent, sizeof tmp_agent, "%4.2f", dPagent);
    sprintf_s(tmp_discount, sizeof tmp_discount, "%4.2f", dPdiscount);

    sprintf_s(tmp_pure_prem, sizeof tmp_pure_prem, "%10.0f", lMpure_prem_56);
    strcpy(tmp_pure_prem, trim(tmp_pure_prem));

    sprintf_s(tmp_mr_pure_prem, sizeof tmp_mr_pure_prem, "%10.0f", dmr_pure_prem);
    strcpy(tmp_mr_pure_prem, trim(tmp_mr_pure_prem));

    cm_buf_put("%s %s %s %s   %l %l %s   %s %s  %s %s %s  %l %l %s %l %s %s %s",
               cIinsurant, cNinsurant, cDbirth, cIins_scope,
               lMins_amt, lMins_premium, tmp_pure_prem,
               cNbeneficiary, cRelation_bene,
               tmp_commission, tmp_agent, tmp_discount,
               ldaily_pay, lmr_ins_prem, tmp_mr_pure_prem, ca_pa_ply_rowid,
               s_tenef, s_abenef_zip, s_abenef);
  }
  $CLOSE query1_56;
  $FREE query1_56;

  /* premium1 �j���Iñ��O�O */
  /* premium2 ���N�Iñ��O�O */
  /* premium  ñ��O�O       */

  cm_buf_put("%l %l %l", premium1, premium2, premium);

  /*-----���O���p-----*/
  /***************************************************/
  /***************************************************/
  if (fcard_class[0] == '1')
  {
    strncpy(policy_1, ipolicy, CAR_POLICY_LEN);
    policy_1[CAR_POLICY_LEN] = 0;
    strcpy(policy_2, &ipolicy[CAR_POLICY_LEN]);
  }
  else
  {
    strncpy(policy_1, ipolicy, CAR_POLICY_LEN);
    policy_1[CAR_POLICY_LEN] = 0;
    strcpy(policy_2, &ipolicy[CAR_POLICY_LEN]);
  }

  memset(batch_no, 0, sizeof(batch_no));

  if (ibatch_no == 0)
    strcpy(batch_no, " ");
  else
    sprintf_s(batch_no, sizeof batch_no, "%d", ibatch_no);

  rc = ao_chk_charge(DBName, 'A', policy_1, policy_2, batch_no,
                     payresult, paystatus, paydate, notedate);

  /*** ���P�� ***/
  /* car9506142 ���P�ΰh���h�O�i�_��
  if (payresult[0] == 'C')
  {

      if (exitsub(reply, M_CA_PLY_CANCEL) == True)
          return M_CA_PLY_CANCEL;
      else
          return apiRC;

  }  */

  /*** �h���h�O ***/
  /* car9506142 ���P�ΰh���h�O�i�_��
  if (payresult[0] == 'X')
  {
      if(exitsub (reply, M_CA_CHK_CHARGE_ERROR) == True)
          return M_CA_CHK_CHARGE_ERROR;
      else
          return apiRC;
  } */

  cm_buf_put("%s %s %s", paystatus, paydate, notedate);

  /*--------------------*/
  acctimes = 0;
  fpart[0] = '\0'; /*1090515016_SC1 �s�W�����l���ˮ�*/
  losspay = outstanding = totalpay = 0;
  count_56 = 0;
  $DECLARE query2 CURSOR FOR
      SELECT iclaim,daccident, msettle, mapp_loss, iacc_reason, fpart       
        INTO $iclaim, $daccident, $msettle, $mapp_loss, $iacc_reason, $fpart 
        FROM appraisal 
       WHERE ipolicy = $ipolicy 
       ORDER BY iclaim;
  $OPEN query2;

  for (;;)
  {
    $FETCH query2;
    if (SQLCODE != 0)
      break;

    printf("iclaim[%s] iacc_reason[%s]\n", iclaim, iacc_reason);

    if (memcmp(iacc_reason, "00", 2) == 0)
      continue;

    if (strcmp(trim(iacc_reason), "21") == 0)
    {
      printf("=== iacc_21 \n");
      strcpy(iacc_21, "Y");
    }

    acctimes++;

    printf("iacc_21[%s]\n", iacc_21);

    losspay += msettle;
    outstanding += mapp_loss;

    $SELECT count(*) INTO $count_56
       FROM app_ins_type
      WHERE iclaim = $iclaim
        AND iins_type in(SELECT iins_type FROM insurance_type WHERE iins_ply in('56','136','166','266','561')) 
        AND fclose = '0'; /* ���M */
                    
}
  $CLOSE query2;
  $FREE query2;

  if (outstanding < 0)
    outstanding = 0;
  printf("=================\n");

  if (acctimes == 0)
  {
    cm_buf_put("%l %l %l %l %s %s %s %s %s", 0, 0, 0, 0, " ", " ", " ", "-", "-");
  }
  else
  {
    if (count_56 > 0) /* 56/136/166/561 �|�����M */
    {
      strcpy(fclose_56, "0");
    }
    else
    {
      strcpy(fclose_56, "1");
    }

    strcpy(daccident, rtrim(daccident));
    strcat(daccident, ":00");
    strcpy(s_daccident, cm_sysd_cdatetime(daccident));
    s_daccident[9] = '\0';
    totalpay = losspay + outstanding;
    cm_buf_put("%l %l %l %l %s %s %s %s %s",
               losspay, outstanding, totalpay, acctimes, s_daccident, iclaim, iacc_21, fpart, fclose_56);
  }

  cm_buf_put("%s %c", payresult, fcard_class[0]);

  /* �u�ݫe�O�I�O */
  cm_buf_put("%l", lMpremium);
  cm_buf_put("%s", sTmp_iendorse);

  /* �ˮ֬O�_��S�w�O�����ˮֳ]�w�ɤ����]�w */
  sType_131[0] = '\0';
  sInumber_131[0] = '\0';
  sCheck_fedr_131[0] = '\0';
  sNote_131[0] = '\0';

  sTypeRtn_131[0] = '\0';
  sInumberRtn_131[0] = '\0';
  sCheck_fedrRtn_131[0] = '\0';
  sNoteRtn_131[0] = '\0';

  strcpy(ipolicy, trim(ipolicy));
  strcpy(icard, trim(icard));
  strcpy(itag, trim(itag));
  strcpy(iengine, trim(iengine));
  strcpy(iassured, trim(iassured));
  strcpy(iapplicant, trim(iapplicant));

  time(&b_tt);
  printf("before[%ld], [%s]\n", b_tt, ctime(&b_tt));

  $SELECT type, inumber, check_fedr, note INTO $sTypeRtn_131, $sInumberRtn_131, $sCheck_fedrRtn_131, $sNoteRtn_131 FROM car_spec_policy WHERE type = '1' AND inumber = $ipolicy AND iclaim = '';
  if (SQLCODE == SQLNOTFOUND)
  {
    $SELECT type, inumber, check_fedr, note INTO $sTypeRtn_131, $sInumberRtn_131, $sCheck_fedrRtn_131, $sNoteRtn_131 FROM car_spec_policy WHERE type = '2' AND inumber = $icard AND iclaim = '';
    if (SQLCODE == SQLNOTFOUND)
    {
      $SELECT type, inumber, check_fedr, note INTO $sTypeRtn_131, $sInumberRtn_131, $sCheck_fedrRtn_131, $sNoteRtn_131 FROM car_spec_policy WHERE type = '3' AND inumber = $iassured AND iclaim = '';
      if (SQLCODE == SQLNOTFOUND)
      {
        $SELECT type, inumber, check_fedr, note INTO $sTypeRtn_131, $sInumberRtn_131, $sCheck_fedrRtn_131, $sNoteRtn_131 FROM car_spec_policy WHERE type = '4' AND inumber = $itag AND iclaim = '';
        if (SQLCODE == SQLNOTFOUND)
        {
          $SELECT type, inumber, check_fedr, note INTO $sTypeRtn_131, $sInumberRtn_131, $sCheck_fedrRtn_131, $sNoteRtn_131 FROM car_spec_policy WHERE type = '5' AND inumber = $iengine AND iclaim = '';
          if (SQLCODE == SQLNOTFOUND)
          {
            if (strlen(iapplicant) != 0)
            {
              $SELECT type, inumber, check_fedr, note INTO $sTypeRtn_131, $sInumberRtn_131, $sCheck_fedrRtn_131, $sNoteRtn_131 FROM car_spec_policy WHERE type = '6' AND inumber = $iapplicant AND iclaim = '';
            }
          }
        }
      }
    }
  }

#if 0 /* �찵�k�ݯӮ�4���A�s���k�ﵽ�u��1���� */
    $DECLARE query_131 CURSOR FOR
      SELECT type, inumber, check_fedr, note
        INTO $sType_131, $sInumber_131, $sCheck_fedr_131, $sNote_131
        FROM car_spec_policy
       ORDER BY 1,2;
    $OPEN query_131;
    for(;;)
    {
        $FETCH query_131;
        if (SQLCODE != 0)
             break;

        strcpy(sInumber_131,   trim(sInumber_131));

        /* sType == 1:�O�渹�X */
        if (strncmp(sType_131,"1",1)==0)
        {
             if (strcmp(sInumber_131,ipolicy)==0)
             {
                  strcpy(sTypeRtn_131       , sType_131);
                  strcpy(sInumberRtn_131    , sInumber_131);
                  strcpy(sCheck_fedrRtn_131 , sCheck_fedr_131);
                  strcpy(sNoteRtn_131       , sNote_131);

                  break;
             }
        }

        /* sType == 2:�ҥd���X */
        if (strncmp(sType_131,"2",1)==0)
        {
             if (strcmp(sInumber_131,icard)==0)
             {
                  strcpy(sTypeRtn_131       , sType_131);
                  strcpy(sInumberRtn_131    , sInumber_131);
                  strcpy(sCheck_fedrRtn_131 , sCheck_fedr_131);
                  strcpy(sNoteRtn_131       , sNote_131);

                  break;
             }
        }

        /* sType == 3:������/�Τ@�s�� */
        if (strncmp(sType_131,"3",1)==0)
        {
             if (strcmp(sInumber_131,iassured)==0)
             {
                  strcpy(sTypeRtn_131       , sType_131);
                  strcpy(sInumberRtn_131    , sInumber_131);
                  strcpy(sCheck_fedrRtn_131 , sCheck_fedr_131);
                  strcpy(sNoteRtn_131       , sNote_131);

                  break;
             }
        }

        /* sType == 4:�P�Ӹ��X */
        if (strncmp(sType_131,"4",1)==0)
        {
             if (strcmp(sInumber_131,itag)==0)
             {
                  strcpy(sTypeRtn_131       , sType_131);
                  strcpy(sInumberRtn_131    , sInumber_131);
                  strcpy(sCheck_fedrRtn_131 , sCheck_fedr_131);
                  strcpy(sNoteRtn_131       , sNote_131);

                  break;
             }
        }

        /* sType == 5:�������X */
        if (strncmp(sType_131,"5",1)==0)
        {
             if (strcmp(sInumber_131,iengine)==0)
             {
                  strcpy(sTypeRtn_131       , sType_131);
                  strcpy(sInumberRtn_131    , sInumber_131);
                  strcpy(sCheck_fedrRtn_131 , sCheck_fedr_131);
                  strcpy(sNoteRtn_131       , sNote_131);

                  break;
             }
        }

        /* sType == 6:�n�O�HID */
        if (strncmp(sType_131,"6",1)==0)
        {
             if (strcmp(sInumber_131,iapplicant)==0)
             {
                  strcpy(sTypeRtn_131       , sType_131);
                  strcpy(sInumberRtn_131    , sInumber_131);
                  strcpy(sCheck_fedrRtn_131 , sCheck_fedr_131);
                  strcpy(sNoteRtn_131       , sNote_131);

                  break;
             }
        }
    }
    $CLOSE query_131;
    $FREE  query_131;
#endif

  time(&a_tt);
  printf("after[%ld],[%s]\n", a_tt, ctime(&a_tt));
  diff = difftime(a_tt, b_tt);

  cm_buf_put("%s %s %s %s ", sTypeRtn_131, sInumberRtn_131, sCheck_fedrRtn_131, sNoteRtn_131);

  /** ���就�έ��� car-9303312 **/
  $SELECT fedr_m, iquota, imgr INTO $fedr_m, $off_iquota, $imgr FROM officer WHERE iofficer = $iofficer;
  if (SQLCODE == SQLNOTFOUND)
  {
    strcpy(fedr_m, "Y");
    strcpy(imgr, "");
  }
  /*** car-9407193 ***/
  if (strncmp(icard + 2, "AYK", 3) == 0)
  {
    strcpy(fedr_m, "N");
  }

  cm_buf_put("%s ", fedr_m);

  /** �s���P�_�G���M����ˮ� car-9502103    dexpire_m = N ���ܤw���M**/
  $SELECT case when today >= dexpire then 'N' else 'Y' end case INTO $dexpire_m
                                 FROM sa_branch_type
                                     WHERE ibranch = $off_iquota;

  /** �ª��P�_�G��������ܸg��H�~�Z���w���M
  if( strlen(trim(dexpire)) > 0 )
  {
    strcpy(dexpire_m,"N");
  }
  else
      strcpy(dexpire_m,"Y");
  */

  cm_buf_put("%s ", dexpire_m);
  cm_buf_put("%s ", imgr);
  cm_buf_put("%s %d %d %d %s %s", iext_policy, qpro_month, mkilo_ply, mkilo_edr, irisk, irelative_ext);

#ifdef CA_CONS

  strcpy(sDbname, "");
  strcpy(sColumn, "ipolicy");
  strcpy(sTable, "ply_ins_cover");

  IfirstPlyInsCover = get_ply_ins_cover(sDbname, sTable, sColumn, ipolicy, &rtncode, v_sMsg);

  if (rtncode != M_CM_OK)
  {
    if (exitsub(reply, rtncode) == True)
      return rtncode;
    else
      return apiRC;
  }

  puts("put ply_ins_cover���");

  IcurrPlyInsCover = IfirstPlyInsCover;
  while (IcurrPlyInsCover)
  {
    cm_buf_put("%s ", IcurrPlyInsCover->iins_type);
    cm_buf_put("%s ", IcurrPlyInsCover->cover_name);
    cm_buf_put("%l ", IcurrPlyInsCover->mcover);
    cm_buf_put("%l ", IcurrPlyInsCover->mcover_prem);
    cm_buf_put("%l ", IcurrPlyInsCover->mprem);
    cm_buf_put("%e ", IcurrPlyInsCover->mpure_prem);
    cm_buf_put("%s ", IcurrPlyInsCover->icover_type);
    cm_buf_put("%s ", IcurrPlyInsCover->iprem_cover_type);

    printf("IcurrPlyInsCover->iins_type    [%s]\n"
           "IcurrPlyInsCover->cover_name   [%s]\n"
           "IcurrPlyInsCover->icover_type  [%s]\n"
           "IcurrPlyInsCover->iprem_cover_type  [%s]\n"
           "IcurrPlyInsCover->mcover       [%d]\n"
           "IcurrPlyInsCover->mcover_prem  [%d]\n"
           "IcurrPlyInsCover->mprem        [%d]\n"
           "IcurrPlyInsCover->mpure_prem   [%f]\n"
           "IcurrPlyInsCover->pextra_charge[%f]\n",
           IcurrPlyInsCover->iins_type,
           IcurrPlyInsCover->cover_name,
           IcurrPlyInsCover->icover_type,
           IcurrPlyInsCover->iprem_cover_type,
           IcurrPlyInsCover->mcover,
           IcurrPlyInsCover->mcover_prem,
           IcurrPlyInsCover->mprem,
           IcurrPlyInsCover->mpure_prem,
           IcurrPlyInsCover->pextra_charge);
    puts("");
    IcurrPlyInsCover = IcurrPlyInsCover->next;
  }
  cm_buf_put("%s", "IcurrPlyInsCoverEnd");

#endif

#ifdef CA_ONE

  strcpy(sDbname, "");
  strcpy(sColumn, "ipolicy");
  strcpy(sTable, "ply_ins_assured");

  IfirstPlyInsAssured = get_ply_ins_assured(sDbname, sTable, sColumn, ipolicy, &rtncode, v_sMsg);

  if (rtncode != M_CM_OK)
  {
    if (exitsub(reply, rtncode) == True)
      return rtncode;
    else
      return apiRC;
  }

  puts("put ply_ins_assured���");

  IcurrPlyInsAssured = IfirstPlyInsAssured;
  while (IcurrPlyInsAssured)
  {
    cm_buf_put("%s ", IcurrPlyInsAssured->iins_type);
    cm_buf_put("%s ", IcurrPlyInsAssured->provision);
    cm_buf_put("%s ", IcurrPlyInsAssured->iassured);
    cm_buf_put("%s ", IcurrPlyInsAssured->nassured);
    cm_buf_put("%s ", IcurrPlyInsAssured->dbirth);
    cm_buf_put("%s ", IcurrPlyInsAssured->nbenef);
    cm_buf_put("%s ", IcurrPlyInsAssured->rel_benef);
    cm_buf_put("%s ", IcurrPlyInsAssured->tbenef); /*1110310005_SC2 �s�W147�Q�O�H�W�U*/
    cm_buf_put("%s ", IcurrPlyInsAssured->abenef_zip);
    cm_buf_put("%s ", IcurrPlyInsAssured->abenef);
    cm_buf_put("%l ", IcurrPlyInsAssured->iserial);

    printf("IcurrPlyInsAssured->iins_type    [%s]\n"
           "IcurrPlyInsAssured->provision    [%s]\n"
           "IcurrPlyInsAssured->iassured     [%s]\n"
           "IcurrPlyInsAssured->nassured     [%s]\n"
           "IcurrPlyInsAssured->dbirth       [%s]\n"
           "IcurrPlyInsAssured->nbenef       [%s]\n"
           "IcurrPlyInsAssured->rel_benef    [%s]\n"
           "IcurrPlyInsAssured->tbenef       [%s]\n"
           "IcurrPlyInsAssured->abenef_zip   [%s]\n"
           "IcurrPlyInsAssured->abenef       [%s]\n"
           "IcurrPlyInsAssured->iserial      [%d]\n",
           IcurrPlyInsAssured->iins_type,
           IcurrPlyInsAssured->provision,
           IcurrPlyInsAssured->iassured,
           IcurrPlyInsAssured->nassured,
           IcurrPlyInsAssured->dbirth,
           IcurrPlyInsAssured->nbenef,
           IcurrPlyInsAssured->rel_benef,
           IcurrPlyInsAssured->tbenef,
           IcurrPlyInsAssured->abenef_zip,
           IcurrPlyInsAssured->abenef,
           IcurrPlyInsAssured->iserial);

    puts("");

    IcurrPlyInsAssured = IcurrPlyInsAssured->next;
  }
  cm_buf_put("%s", "IcurrPlyInsAssuredEnd");
#endif

  /* car9903041 ���s�t�λP���O�B�ɨ�����s�� */
  strcpy(sTable, "ca_ply_bound");
  rtncode = get_ca_ply_bound(sDbname, sTable, sColumn, ipolicy, ibound, v_sMsg);
  if (rtncode != M_CM_OK)
  {
    if (exitsub(reply, rtncode) == True)
      return rtncode;
    else
      return apiRC;
  }

  /* fedr_flag1='N':���g�L��B�γ̷s�O�檬�A���h�O�B���P�A���i���j���I�t�B����O�B���šB���T�d�ߧǸ�
               ='W':���g���L��L���A���ʹ��ܰT���G�i���O��w���g���,�нT�w�ɤJ
                   �y�j���I�t�B����O�z�O�_���T�H�j�A�bclient��user��ܡi�O�j�h������
               ='Y':�������� */

  $SELECT first 1 
             case when(b.fedr_class = '2' or b.fedr_class = '8' or a.fedr_class = '1' or c.mdamage_cover = 0) then 'N'
                  when a.dendorse is not null then 'W' 
             else 'Y' end case INTO $fedr_flag1
     FROM ply_relation a,edr_relation b, ply_ins_type c 
    WHERE a.ipolicy = b.ipolicy AND a.ipolicy = c.ipolicy AND a.ipolicy = $ipolicy AND a.fcard_class = '1' 
    ORDER BY 1;

  cm_buf_put("%s", fedr_flag1);

  /* fedr_flag2='N':���O17�i�j���I�t�B��(�X�欰���~�ż�)�j�w����L�j���I�t�B��J�p���i���(�u��J�p�@��)
               ='W':���O17��67�j���I�t�B�󪺫O�������L���A�b���O17���J�p�e�ε��O67���h�O�e���ʹ��ܰT���G
                   �i���O��w�]�w�y�j���I�t�B��z���O,�нT�w��鷺�e���v�T�h�O�v�q�j�A
                    �bclient��user��ܡi�O�j�h������,
               ='Y':�������� */

  $SELECT case when iendorse<> '' then 'N' when((note = 'A' AND fcomp_class != '' ) or
                                                (note not in('F', 'G')AND fcomp_class_err != '' )) then 'W' else 'Y' end case INTO $fedr_flag2
     FROM ca_comp_return
    WHERE ipolicy = $ipolicy;

  cm_buf_put("%s", fedr_flag2);

  /* car9705152 - �n�O�H */
  cm_buf_put("%s", napplicant);
  /* cmn9708011 - ����100�~  */
  strcpy(date1, cm_cdate_str_100(dbirth));
  strcpy(date2, cm_cdate_str_100(dissue));
  cm_buf_put("%s %s", date1, date2);
  /* for���[�O�βv�ϥ� */
  cm_buf_put("%s %d %e", iextra_charge, gextra_charge, pextra_charge);
  /* car9706251 - ���T�d�ߧǸ� & car9705211 - �श�~�ȭ� & ���m���t�t�ƻ� */
  cm_buf_put("%s %s %e", iquery_num_damage, iquery_num, mequipment);
  /* ����easy flow�渹 */
  cm_buf_put("%s %s %s %s", survey_num, bound_num, abnormal_num, iapplicant);

  /* car9707103 �ѩ�n�P�_�j���I�O�_�O����J,�G�ݭn�ǤJ�O��ñ���H�T�{ */
  cm_buf_put("%s", cm_cdate_str_100(dpolicy));

  /* car9903041 ���s�t�λP���O�B�ɨ�����s�� */
  cm_buf_put("%s", ibound);

  /* 1000728003_C2 �ĤT�H�d���I���ŧאּ5��(���) */
  cm_buf_put("%l %l", qlia_acc_sum, qdmg_acc_sum);

  cm_buf_put("%l ", mservice);

  cm_buf_put("%s %s %s %s %s %s %s %s %d", fapplicant, fsex_appl, dbirth_appl, itel_appl, ndeputy_appl, nrelation_appl, ndeputy_assured, transno, qdrunk_driving);
  cm_buf_put("%s %s", isign, dcreate_ply);
  cm_buf_put("%s %d", iins_kit, mcover_limit);
  cm_buf_put("%s %s", iassured_cntry, iapplicant_cntry);
  cm_buf_put("%s ", warning_code);
  cm_buf_put("%s %s %s %s %s %s %s %s", fequipment1, fequipment2, fequipment3, fequipment4, fequipment5, fequipment6, fequipment9, nequipment9);
  cm_buf_put("%s ", dentry);
  cm_buf_put("%e %s %l", punknown_acc, iquery_num_unknown, qunknown_acc_sum);
  cm_buf_put("%s %s ", feply, aemail_eply);
  cm_buf_put("%s %s", nassured_cntry, napplicant_cntry);

  $select max(dcreate)
     into $dcreate_max
     from edr_relation
    where ipolicy = $ipolicy and iendorse not like '%CVP%';

  cm_buf_put("%s ", dcreate_max);

  cm_buf_put("%s %s %s %s ", foccup, noccup, applicant_foccup, applicant_noccup);

  cm_buf_put("%s %s %s ", iowner, nowner, dbirth_owner);

  cm_buf_put("%s %s ", tmobile_appl, aemail_appl);

  cm_buf_put("%s %s ", dtply_begin, dtply_end);

  cm_buf_put("%s ", iroute_accept); /* 1071225004_SC1_ ����_���I�W��ѽվ�*/
  cm_buf_put("%s ", tmobile_eply);  /* 1080417001_SC2 �s�W�q�l�O��H²�T�覡�o�e */
  cm_buf_put("%s ", ireg_no);       /* 1080408005_SC2 �j��{�ҷs�W�q����Ƥεn���Ҹ� */
  cm_buf_put("%s ", s_dtransfer);   /* �̪�L���A1091225007_SC1 �w��L�����зs�W�ݼu�����ܰT���β����ˮ� */
  cm_buf_put("%s ", feterms);       /* 1100419003_SC2 ���I�O�����QR Code�q�l�� */
  cm_buf_put("%d ", qviolate);      /*1110608012_SC2 �s�W�j��I�O�v�ǤJ���j�H�W�[�O���*/

  /* 1120927002_C02 �R�q�ΰӫ~�}�o */
  strcpy(date2, cm_cdate_str_100(dinstall));
  cm_buf_put("%s ", date2);  
  cm_buf_put("%s ", isequence);
  cm_buf_put("%s ", ainstall_zip);
  cm_buf_put("%s ", ainstall);

  tmp_len = cm_buf_len(ReplyBuf);

  if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  printf("{car401_single_query_1_2.0010}: SQLCODE:[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
}

/***************************************************************************/
/**** ���d��(�t���`��d��) ***********************************************/
/***************************************************************************/
long car401_single_query(reply)
serverReply reply;
{
  /* standard defined host variables */
  $char DBName[5];
  $char stmt[4096];
  long code;
  /* end of standard host var */

  /* table edr_relation */
  $char ipolicy[POLICY_NUM_1], icard[CARD_NUM], irelative_ply[POLICY_NUM_1];
  $char iendorse[ENDORSE_NUM], fcard_class[2],tmp_iendorse[ENDORSE_NUM];
  $char iabn_type[2], fpass[2], fedr_class[2], fpay[2];
  $char ipay[20], ffac[2], ibig_comp[2], ibranch[3];
  $long dedr_begin, dedr_end, dendorse;
  char s_dedr_begin[11], s_dedr_end[11], s_dendorse[11];
  $char iedr_cashier[12];
  $char iofficer[EMPLOYEE_ID], ibroker[BROKER];
  $char icashier[EMPLOYEE_ID];
  $char iresource[13], ibig_branch[6], ibig_office[10], ibig_sales[20];
  $char itreaty[2];
  $long medrdmg_prem, medrlia_prem, mcancel;
  $int qdrunk_driving, qviolate; /*1110608012_SC2 �s�W�j��I�O�v�ǤJ���j�H�W�[�O���*/
  $char feply[2], feedr[2], feterms[2], aemail_eply[51], dcreate_eedr[31], dcreate_max[31];
  $char isign[11];
  $double medrdmg_pure_prem, medrlia_pure_prem;
  $char fcomp_class_last[3], fcomp_class[3];
  $double mbusiness, medr_business;
  char tmp_mbusiness[20];
  $char icar_flag[2],iquote[21]; /* 1110607001_SC1 �ظmE�O�����t�� */
  /* end of edr_relation */

  $char nassured[122];
  $char nbrand_abbr[30];
  $char fcar_note[6], ncar_abbr[20];
  $char ibig_resource[8];
  $char fcomp_24[4], fhuman[4];

  /* table endorsement */
  $char iassured[14], iassured_ext[3], fassured[6];
  $char nuser[19], ibenef[11], nbenef[100];
  $char aassured[100], aassured_zip[CA_ZIP], apayment[100], apayment_zip[CA_ZIP];
  $char itel[21], iedr_return[2];
  $char iemail[51], itel_night[21], mobil_phone[21];
  $char terminate_rsn[2];
  $char iedr_area[11], iply_area[11], iarea[11];
  $long qply_period, dply_begin, dply_end;
  char s_dply_begin[11], s_dply_end[11];
  $char ipro_year[5], ibrand[9];
  $char icar_type[3], ncode[14];
  /*$long   qcylinder;*/
  $char iengine[CA_ENGINE_NUM], ibody[CA_BODY_NUM], itag[CA_TAG_NUM], ilicense[11], fsex[2];
  $char fmarriage[2], iacc_align[3], flimit[2];
  $long pdmg_align, plia_align, pbrg_align;
  $double mcar_price, qcylinder;
  char s_mcar_price[20];
  $char nequipment[31];
  $double pdmg_factor_1st, pbrg_factor_1st;
  $char drate_ym[5];
  $double qpt, psex_age, plia_acc, pdmg_acc, psex_age_damage;
  $char fpt[2];
  $char lia_class[3];
  $int dmg_acc_1st, dmg_acc_2nd, dmg_acc_3rd;
  $char irecover_num[21], ireverse_num[21];

  $char fNo_mdeduct[2], fRescue[2];
  /* bis9901141 �q���N�� */
  $char iroute[21];

  $char irate_type[2], bzfrom[3], iroute_comm[4], icomm_obj[11];
  /* car9903041 ���s�t�λP���O�B�ɨ�����s�� */
  $char ibound[421];

  /* �����O�T */
  $char iext_policy[21], irisk[2], irelative_ext[21];
  $long mkilo_ply, mkilo_edr, qpro_month, qprovision;

  $char napplicant[121]; /* car9705152 - �n�O�H */
  $long dbirth, dissue;  /* cmn9708011 - ����100�~ */
  char date1[11], date2[11];
  $char iextra_charge[11];                       /* for���[�O�βv�ϥ� */
  $int gextra_charge;                            /* for���[�O�βv�ϥ� */
  $char iquery_num_damage[121], iquery_num[121]; /* car9706251 - ���T�d�ߧǸ�*/
  /* $char     introducer[21];                                    car9705211 - �श�~�ȭ� */
  $double mequipment;                                       /* ���m���t�t�ƻ� */
  $char survey_num[121], bound_num[121], abnormal_num[121]; /* ����easy flow�渹 */
  $long dpolicy;                                            /* �����O��ñ��� */
  $char iapplicant[13];                                     /* �n�O�HID */

  $char ded_business[2], fmservice[2], fmaintain[2], fedr_print[2], fply_print[2];
  /* end of endorsement */
  $long coverage1_31, coverage2_31, coverage3_32; /* �W�B�d���I����h�ĤT�H�d���I�O�I���B */

  /* table edr_ins_type */
  $char iedr_type[3], iins_type[INSURANCE_TYPE];
  $long medrinj_cover, medrdea_cover, medrdmg_cover, mdeduct;
  $long medrins_prem, medr_prem;
  $double medrpure_prem; /*** �«O�O ***/
  $char fdiscount[2], fcal_way[2];
  $long qserial;
  $int pcal = 0;
  char temp[5];
  $double dPextra_charge;
  long lLoading;

  $long qday;
  $long medr_expense;
  $long medr_exp_disc;

  /* end of edr_ins_type */

  /* table ca_pa_ply */
  $int count_33, count_48, count_35, count_56;
  $char cIinsurant[11], sIins_type[INSURANCE_TYPE];
  $char cNinsurant[31];
  $char cDbirth[11];
  $long lDbirth;
  $char cAinsurant[91];
  $char cIins_scope[2];
  $char cIcareer[2];
  $long lMins_amt;
  $long lMins_premium;
  $double lMpure_prem_33; /* �«O�O   */
  $double lMpure_prem_35; /* �«O�O   */
  $double lMpure_prem_48; /* �«O�O   */
  $double lMpure_prem_56; /* �«O�O   */
  $double dPcommission;
  $long lMcommission;
  $double dPagent;
  $long lMagent;
  $double dPdiscount;
  $long lMdiscount;
  $char cNapplicant[31];
  $char cRelation_appl[2];
  $char cNbeneficiary[31];
  $char cRelation_bene[2];
  $long lMedr_daily_pay;
  $long lMedr_mr_insprem;
  $double lMedr_mr_pureprem;
  $char s_tenef[21], s_abenef_zip[CA_ZIP], s_abenef[91]; /*1090221006_SC2 ��_56�r�p�H�W�U_���*/
  /* end of ca_pa_ply */

  /* standard defined data */
  int tmp_len;
  char tmp_pure_prem[21];
  char tmp_edr_pure_prem[21];
  /* end of standard data */

  /* self defined data */
  $char ilast_ply[POLICY_NUM_1];
  char tmp_pdmg_factor_1st[20], tmp_pbrg_factor_1st[20];
  char tmp_pdmg_factor_2nd[20], tmp_pbrg_factor_2nd[20];
  char tmp_qpt[11], tmp_psex_age[21], tmp_plia_acc[11], tmp_pdmg_acc[11], tmp_qcylinder[9];
  long count;
  int ERR29, ERR30, ERR31;
  char dbname_tp[21];

  char tmp_discount[11], tmp_commission[11], tmp_agent[11];
  $double pdiscount, pcommission, pagent;
  $long mdiscount, mcommission, magent;

  /** endorsement_note **/
  $char note1[81], note2[81], note3[81];

  $char sType_131[3];
  $char sInumber_131[21];
  $char sCheck_fedr_131[11];
  $char sNote_131[101];

  $char sTypeRtn_131[3];
  $char sInumberRtn_131[21];
  $char sCheck_fedrRtn_131[11];
  $char sNoteRtn_131[101];
  $char provision[21], fedr_m[2];
  $char iinstall[11];
  char policy_1[POLICY_NUM_1], policy_2[POLICY_NUM_2];
  $int ibatch_no;
  $char batch_no[21];
  $char payresult[5], paystatus[100], paydate[100], notedate[100];
  int rc;

  $char dexpire_m[2], off_iquota[11], imgr[2];

  /* 'car9610231��~�βĤT�H�f�B�~���[���� */
  $double safe_rate;
  $double manage_rate;
  $double educated_rate;

  /* �«O�O�����v */
  $double deviation_rate;

  /* �O�v�ۥѤ� */
  $double pextra_charge;
  $double pbusiness;

  $long iCount, medrlia_commi;

  /* 1000728003_C2 �ĤT�H�d���I���ŧאּ5��(���) */
  $long qlia_acc_sum, qdmg_acc_sum;

  $long mservice, mcover_limit;

  $char fapplicant[2], fsex_appl[2], dbirth_appl[11], itel_appl[21], ndeputy_appl[51], nrelation_appl[41], ndeputy_assured[51];
  $char dcreate[31], dcreate_ply[11];
  $char iins_kit[4];
  $char iassured_cntry[2], iapplicant_cntry[2];
  $char fcharge_type[11];
  $char fequipment1[2], fequipment2[2], fequipment3[2], fequipment4[2], fequipment5[2], fequipment6[2], fequipment9[2], nequipment9[101];
  $char dentry[11];
  $double punknown_acc;
  $char iquery_num_unknown[121];
  $long qunknown_acc_sum;
  $char nassured_cntry[51], napplicant_cntry[51];

  $char foccup[2], noccup[6];
  $char applicant_foccup[2], applicant_noccup[6];
  $char iowner[13], nowner[121], dbirth_owner[11];
  $char tmobile_appl[21], aemail_appl[51];
  $char iref_num1[21];
  $char dtply_begin[17], dtply_end[17], dtedr_begin[17], dtedr_end[17]; /* 1061108001_SC6_�t�X�s�еo�i���ߨt�λݨD���Ѭ����t�Υ\�� yyyy-mm-dd HH:MM */
  $char iroute_accept[21], iroute_accept_edr[21];                       /* 1071225004_SC1_ ����_���I�W��ѽվ�*/
  $char tmobile_eply[21];                                               /* 1080417001_SC2 �s�W�q�l�O��H²�T�覡�o�e */
  $char ireg_no[21];                                                    /* 1080408005_SC2 �j��{�ҷs�W�q����Ƥεn���Ҹ� */
  $char iscan_no_edr[26]; /*1080730005_SC2 �q�lñ�p���ظm�@�~*/       /* 1101018008_SC2 �q�lñ�ݱ��y�s������X�W��25�X */

  $int fsign_status_edr = 0; /* 1091021005_SC2�s�W�A�Ȥ��ߩ����� */
  $char funder_chk_edr[2] = "", isign_edr[11] = "", dsign_edr[11] = "";
  int   estimate_type = 0;  /* 1110607001_SC1 �ظmE�O�����t��  0:��渹 , 1�GCVP , 2:CVR , 3:CY */

  $long dinstall;
  $char isequence[31]= "", ainstall_zip[7]= "", ainstall[91]= ""; /*1120927002_C02 �R�q�ΰӫ~�}�o*/

  time_t a_tt, b_tt;
  double diff;
  char   sTmp[50]=" ";

  /* end of self data */

  medrdmg_prem = 0;
  medrlia_prem = 0;
  medr_prem = 0;
  mdiscount = mcommission = magent = mcancel = 0;
  fpass[0] = 0;
  ilast_ply[0] = 0;
  coverage1_31 = coverage2_31 = coverage3_32 = 0;

  strcpy(iquote," ");
  estimate_type = 0;

  cm_buf_get("%s", DBName);
  cm_buf_get("%s", iendorse);

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
    if (exitsub(reply, M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }

  /* estimate_type = 0:��渹 , 1�GCVP , 2:CVR , 3:CY */
  /***** CAR_EDR_ABN_POS  7  ���`���պ⸹�r�y��m *****/  
  if ((iendorse[CAR_EDR_ABN_POS - 1] != 'Y') ||
      (isalpha(iendorse[CAR_EDR_ABN_POS])))
  {
    if((strncmp(iendorse + 4,"CVR",3)==0)) /* 1110607001_SC1 �ظmE�O�����t�� */
    {
      estimate_type = 2;

      ERR29 = M_CM_NOT_FOUND;
      ERR30 = M_CM_NOT_FOUND;
      ERR31 = M_CM_NOT_FOUND;
    }  
    else
    {
      if (strstr(iendorse, "CVP") != NULL)
      {
        estimate_type = 1;   
      }
      ERR29 = M_CA_NREL_EDR;
      ERR30 = M_CA_NENDORSE;
      ERR31 = M_CA_NEDR_INS_TYPE;
    }
  }
  else
  {
    estimate_type = 3; 

    ERR29 = M_CA_NABN_EDR_REL;
    ERR30 = M_CA_NABN_EDR;
    ERR31 = M_CA_NABN_EDR_INS;

  }
  strcpy(dbname_tp, get_full_dbname("00")); /* get TP's full DB name */

  cm_buf_init(ReplyBuf);
  cm_buf_res_msg();
  cm_buf_res_count();
  cm_buf_put_msg(M_CM_OK);

  if ((iendorse[CAR_EDR_ABN_POS - 1] != 'Y') ||
      (isalpha(iendorse[CAR_EDR_ABN_POS])))
  {
    /* 1110607001_SC1 �ظmE�O�����t�� */
    if(estimate_type==2)
    {
      printf("{car401_single_query} SELECT FROM newa00:endorse_master(���@�γ�����)�Bca_ed_quotation(���I������)�Aiquote =[%s]\n", iendorse);

      stmt[0] = '\0';
      sprintf_s(stmt, sizeof stmt, "SELECT (case when a.iins_kind_ply = 'C1' then '1' else '2' end) , b.ipolicy, a.icard, a.irelative_ply, a.fedr_class,"
                    "       ' ',' ', b.dedr_begin, b.dedr_end, "
                    "       a.ipro_year, a.ibrand, a.icar_type,"
                    "       a.medrdmg_prem, a.medrlia_prem, a.ibig_comp, ' ',"
                    "       a.ibig_office, a.ibig_sales, a.iresource, a.ibroker, b.iofficer,"
                    "       a.iarea, c.icashier, b.dprint::date,' ',' ' ,"
                    "       c.itreaty, a.ibranch, a.medr_business, a.fcomp_class, a.fcomp_class_last,"
                    "       c.fdiscount, a.iedr_return, a.terminate_rsn, a.icar_flag,"
                    "       a.qply_period, b.dply_begin, b.dply_end, b.iassured, b.iassured_ext, b.fassured, b.nassured,"
                    "       a.ilicense, (case when b.fassured_sex = 'M' then '1' when b.fassured_sex = 'F' then '2' else ' ' end),"
                    "       b.fassured_marriage, a.nuser, a.ibenef, a.nbenef,"
                    "       b.aassured, b.tassured_day, b.tassured_night, b.tassured_mobile, b.aassured_email, a.iply_area, "
                    "       a.nbrand_abbr, a.ncar_abbr, ' ',"
                    "       b.aassured_zip, b.aapplicant, b.aapplicant_zip,"
                    "       a.qcylinder, a.iengine, a.ibody, a.itag, a.mcar_price, a.nequipment,"
                    "       ' ', 0, 0, 0, a.pdmg_factor,"
                    "       a.pbrg_factor, a.qpt, a.fpt, a.psex_age_lia, a.psex_age_dmg, (case when a.iins_kind_ply = 'C1' then a.pcomp_acc else a.plia_acc end) , a.pdmg_acc,"
                    "       a.lia_class, 0, 0, 0,"
                    "       ' ', ' ', ' ', ' ',"
                    "       ' ', a.qpro_month, 0, 0, ' ', ' ',"
                    "       (case when a.ded_business = '' then '0' else a.ded_business end), "
                    "       (case when a.fmservice    = '' then '0' else a.fmservice end), "
                    "       (case when a.fmaintain    = '' then '0' else a.fmaintain end), "
                    "       b.napplicant, b.dassured_birth, a.dissue, "
                    "       ' ', 0, 0.0, "
                    "       a.iquery_num_damage, (case when a.iins_kind_ply = 'C1' then a.iquery_num_comp else a.iquery_num_lia end) , nvl(a.mequipment,0), "
                    "       a.isurvey_num, a.ibound_num, ' ', b.iapplicant, 0, b.iroute, "
                    "       b.irate_type, a.bzfrom, b.iroute_comm, b.icomm_obj, a.qlia_acc_sum, a.qdmg_acc_sum, a.medrlia_commi, a.qprovision, "
                    "       b.fapplicant,(case when b.fapplicant_sex = 'M' then '1' when b.fapplicant_sex = 'F' then '2' else ' ' end), "
                    "       b.dapplicant_birth,b.tapplicant_day,b.napplicant_deputy,"
                    "       CASE b.fapplicant_rel WHEN '1' THEN '���H' WHEN '2' THEN '����' WHEN '3' THEN '�t��' WHEN '4' THEN '�l�k' WHEN '5' THEN '�S�̩j�f' WHEN '6' THEN '���q�t�d�H' WHEN '7' THEN '���q���u' WHEN '8' THEN '�������Y' WHEN 'A' THEN '���Y���~' ELSE b.napplicant_relation END, "
                    "       b.nassured_deputy, a.dcreate, a.qdrunk_driving, c.isign, ' ', 0, b.iassured_cntry, b.iapplicant_cntry, ' ', "
                    "       a.fequipment1,a.fequipment2,a.fequipment3,a.fequipment4,a.fequipment5,a.fequipment6,a.fequipment9,a.nequipment9, "
                    "       '0','0', a.punknown_acc, a.iquery_num_unknown, a.qunknown_acc_sum, a.feply, a.feedr, a.aemail_eply, "
                    "       b.nassured_cntry, b.napplicant_cntry, ' ', b.assured_foccup, b.assured_noccup, b.applicant_foccup, b.applicant_noccup, "
                    "       ' ',' ',' ',' ', b.tapplicant_mobile, b.aapplicant_email,' ', ' ', c.dtply_begin, c.dtply_end,"
                    "       b.iroute_accept, a.tmobile_eply, b.ireg_no,' ',0,' ',' ',' ',a.feterms,a.qviolate,a.iquote "
                    "  FROM %s:ca_ed_quotation a, %s:endorse_master b, ply_relation c, policy d "
                    " WHERE a.iquote  = b.iquote "
                    "   AND b.ipolicy = c.ipolicy AND c.ipolicy = d.ipolicy "
                    "   AND a.iquote  = ? AND b.iendorse = '' "
                    "   AND b.iapproval_status >= 500", dbname_tp, dbname_tp);
    }
    else
    {

      /*1120927002_C02 �R�q�ΰӫ~�}�o�G�s�W4���*/
      printf("{car401_single_query} SELECT FROM edr_relation & endorsement iendorse=[%s]\n", iendorse);

      stmt[0] = '\0';
      sprintf_s(stmt, sizeof stmt, "SELECT a.fcard_class, a.ipolicy, a.icard, a.irelative_ply, a.fedr_class,"
                    "       a.fpay, a.ipay, a.dedr_begin, a.dedr_end, "
                    "       a.ipro_year, a.ibrand, a.icar_type,"
                    "       a.medrdmg_prem, a.medrlia_prem, a.ibig_comp, a.ibig_branch,"
                    "       a.ibig_office, a.ibig_sales, a.iresource, a.ibroker, a.iofficer,"
                    "       a.iedr_area, a.iedr_cashier, a.dendorse, a.iabn_type, a.ffac,"
                    "       a.itreaty, a.ibranch, a.medr_business, a.fcomp_class, a.fcomp_class_last,"
                    "       a.fdiscount, a.iedr_return, a.terminate_rsn, a.icar_flag,"
                    "       b.qply_period, b.dply_begin, b.dply_end, b.iassured, b.iassured_ext, b.fassured, b.nassured,"
                    "       b.ilicense, b.fsex, b.fmarriage, b.nuser, b.ibenef, b.nbenef,"
                    "       b.aassured, b.itel, b.itel_night, b.mobil_phone, b.iemail, b.iply_area, "
                    "       b.nbrand_abbr, b.ncar_abbr, b.fcar_note,"
                    "       b.aassured_zip, b.apayment, b.apayment_zip,"
                    "       b.qcylinder, b.iengine, b.ibody, b.itag, b.mcar_price, b.nequipment,"
                    "       b.flimit, b.pdmg_align, b.pbrg_align, b.plia_align, b.pdmg_factor,"
                    "       b.pbrg_factor, b.qpt, b.fpt, b.psex_age, b.psex_age_damage, b.plia_acc, b.pdmg_acc,"
                    "       b.lia_class, b.dmg_acc_1st, b.dmg_acc_2nd, b.dmg_acc_3rd,"
                    "       b.fhuman, b.fcomp_24, b.payresult, a.irecover_num,"
                    "       b.iext_policy, b.qpro_month, b.mkilo_ply, b.mkilo_edr, b.irisk, b.irelative_ext,"
                    "       b.ded_business, b.fmservice, b.fmaintain, "
                    "       b.napplicant, b.dbirth, b.dissue, "
                    "       b.iextra_charge, b.gextra_charge, b.pextra_charge, "
                    "       b.iquery_num_damage, b.iquery_num, nvl(b.mequipment,0), "
                    "       b.survey_num, b.bound_num, b.abnormal_num, b.iapplicant, a.mcancel*(-1), b.iroute, "
                    "       a.irate_type, a.bzfrom, a.iroute_comm, a.icomm_obj, b.qlia_acc_sum, b.qdmg_acc_sum, a.medrlia_commi, a.qprovision, "
                    "       b.fapplicant,b.fsex_appl,b.dbirth_appl,b.itel_appl,b.ndeputy_appl,b.nrelation_appl,b.ndeputy_assured, a.dcreate, "
                    "       a.qdrunk_driving, a.isign, b.iins_kit, b.mcover_limit, b.iassured_cntry, b.iapplicant_cntry, b.fcharge_type, "
                    "       b.fequipment1,b.fequipment2,b.fequipment3,b.fequipment4,b.fequipment5,b.fequipment6,b.fequipment9,b.nequipment9, "
                    "       a.fedr_print, a.fply_print, b.punknown_acc, b.iquery_num_unknown, b.qunknown_acc_sum, a.feply, a.feedr, a.aemail_eply, "
                    "       b.nassured_cntry, b.napplicant_cntry, a.ireverse_num, b.foccup, b.noccup, b.applicant_foccup, b.applicant_noccup, "
                    "       b.iowner, b.nowner, b.dbirth_owner, a.iref_num1, b.tmobile_appl, b.aemail_appl, a.dtedr_begin, a.dtedr_end , b.dtply_begin, b.dtply_end,"
                    "       b.iroute_accept, a.tmobile_eply,a.ireg_no,a.iscan_no,a.fsign_status_edr,a.funder_chk_edr,a.isign_edr,a.dsign_edr,a.feterms,a.qviolate,a.iquote, "
                    "       b.dinstall, b.isequence, b.ainstall_zip, b.ainstall"
                    "  FROM edr_relation a, endorsement b "
                    " WHERE a.iendorse = ? "
                    "   AND a.iendorse = b.iendorse "
                    "   AND a.dedr_close IS NULL"
                    "   AND a.fedr_class <> 'A' AND a.fedr_class <> 'B'");
    }
    printf("stmt[%s]\n", stmt);
    EXEC SQL PREPARE sel_edr FROM : stmt;
    EXEC SQL EXECUTE sel_edr INTO $fcard_class, $ipolicy, $icard, $irelative_ply, $fedr_class,
          $fpay, $ipay, $dedr_begin, $dedr_end,
          $ipro_year, $ibrand, $icar_type,
          $medrdmg_prem, $medrlia_prem, $ibig_comp, $ibig_branch,
          $ibig_office, $ibig_sales, $iresource, $ibroker, $iofficer,
          $iedr_area, $iedr_cashier, $dendorse, $iabn_type, $ffac,
          $itreaty, $ibranch, $medr_business, $fcomp_class, $fcomp_class_last,
          $fdiscount, $iedr_return, $terminate_rsn, $icar_flag,
          $qply_period, $dply_begin, $dply_end, $iassured, $iassured_ext, $fassured, $nassured,
          $ilicense, $fsex, $fmarriage, $nuser, $ibenef, $nbenef,
          $aassured, $itel, $itel_night, $mobil_phone, $iemail, $iply_area,
          $nbrand_abbr, $ncar_abbr, $fcar_note,
          $aassured_zip, $apayment, $apayment_zip,
          $qcylinder, $iengine, $ibody, $itag, $mcar_price, $nequipment,
          $flimit, $pdmg_align, $pbrg_align, $plia_align, $pdmg_factor_1st,
          $pbrg_factor_1st, $qpt, $fpt, $psex_age, $psex_age_damage, $plia_acc, $pdmg_acc,
          $lia_class, $dmg_acc_1st, $dmg_acc_2nd, $dmg_acc_3rd,
          $fhuman, $fcomp_24, $payresult, $irecover_num,
          $iext_policy, $qpro_month, $mkilo_ply, $mkilo_edr, $irisk, $irelative_ext,
          $ded_business, $fmservice, $fmaintain,
          $napplicant, $dbirth, $dissue,
          $iextra_charge, $gextra_charge, $pextra_charge,
          $iquery_num_damage, $iquery_num, $mequipment,
          $survey_num, $bound_num, $abnormal_num, $iapplicant, $mcancel, $iroute,
          $irate_type, $bzfrom, $iroute_comm, $icomm_obj, $qlia_acc_sum, $qdmg_acc_sum, $medrlia_commi, $qprovision,
          $fapplicant, $fsex_appl, $dbirth_appl, $itel_appl, $ndeputy_appl, $nrelation_appl, $ndeputy_assured, $dcreate,
          $qdrunk_driving, $isign, $iins_kit, $mcover_limit, $iassured_cntry, $iapplicant_cntry, $fcharge_type,
          $fequipment1, $fequipment2, $fequipment3, $fequipment4, $fequipment5, $fequipment6, $fequipment9, $nequipment9,
          $fedr_print, $fply_print, $punknown_acc, $iquery_num_unknown, $qunknown_acc_sum,
          $feply, $feedr, $aemail_eply, $nassured_cntry, $napplicant_cntry, $ireverse_num,
          $foccup, $noccup, $applicant_foccup, $applicant_noccup, $iowner, $nowner, $dbirth_owner,
          $iref_num1, $tmobile_appl, $aemail_appl, $dtedr_begin, $dtedr_end, $dtply_begin, $dtply_end, $iroute_accept_edr,
          $tmobile_eply, $ireg_no, $iscan_no_edr, $fsign_status_edr, $funder_chk_edr, $isign_edr, $dsign_edr, $feterms, $qviolate, $iquote,
          $dinstall, $isequence, $ainstall_zip, $ainstall 
    USING $iendorse;
    

    if (SQLCODE == SQLNOTFOUND)
    {
      if (exitsub(reply, ERR29) == True)
        return ERR29;
      else
        return apiRC;
    }

    iedr_return[1] = '\0';
    icar_flag[1] = '\0';
    terminate_rsn[1] = '\0';

  } /* end of if endorse[7]!= 'Y' */
  else
  {
    printf("--- SELECT FROM abn_edr_relation iendorse=[%s]\n", iendorse);

    sprintf_s(prep_stmt, sizeof prep_stmt, "SELECT a.fcard_class, a.ipolicy, a.icard, a.irelative_ply, a.ilast_ply, a.ffac,"
                       "       a.fedr_class, a.fpay, a.ipay, a.dedr_begin, a.dedr_end,"
                       "       a.ipro_year, a.ibrand, a.icar_type, a.medrdmg_prem, a.medrlia_prem,"
                       "       a.ibig_comp, a.ibig_branch, a.ibig_office, a.ibig_sales, a.iresource,"
                       "       a.ibroker, a.iofficer, a.iedr_area, a.iedr_cashier, a.iabn_type,"
                       "       a.fpass, a.itreaty, a.ibranch, a.medr_business, a.fcomp_class,"
                       "       a.fcomp_class_last, a.fdiscount, a.iedr_return, a.terminate_rsn, a.icar_flag,"
                       "       b.qply_period, b.dply_begin, b.dply_end, b.iassured, b.iassured_ext, b.fassured,"
                       "       b.nassured, b.ilicense, b.fsex, b.fmarriage, b.nuser, b.ibenef,"
                       "       b.nbenef, b.aassured, b.aassured_zip, b.apayment, b.apayment_zip,"
                       "       b.itel, b.itel_night, b.mobil_phone, b.iemail, b.iply_area, b.nbrand_abbr,"
                       "       b.ncar_abbr, b.fcar_note,"
                       "       b.qcylinder, b.iengine, b.ibody, b.itag, b.mcar_price, b.nequipment, b.flimit,"
                       "       b.pdmg_align, b.pbrg_align, b.plia_align, b.pdmg_factor, b.pbrg_factor,"
                       "       b.lia_class, b.dmg_acc_1st, b.dmg_acc_2nd, b.dmg_acc_3rd,"
                       "       b.qpt, b.fpt, b.psex_age, b.psex_age_damage, b.plia_acc, b.pdmg_acc, "
                       "       b.fhuman, b.fcomp_24, "
                       "       b.payresult, a.irecover_num,"
                       "       b.iext_policy, b.qpro_month, b.mkilo_ply, b.mkilo_edr, b.irisk, b.irelative_ext,"
                       "       b.ded_business, b.fmservice, b.fmaintain, "
                       "       b.napplicant, b.dbirth, b.dissue, "
                       "       b.iextra_charge, b.gextra_charge, b.pextra_charge, "
                       "       b.iquery_num_damage, b.iquery_num, nvl(b.mequipment,0), "
                       "       b.survey_num, b.bound_num, b.abnormal_num, b.iapplicant, a.mcancel*(-1), b.iroute, "
                       "       a.irate_type,a.bzfrom,a.iroute_comm,a.icomm_obj, b.qlia_acc_sum, b.qdmg_acc_sum, a.medrlia_commi,a.qprovision, "
                       "       b.fapplicant,b.fsex_appl,b.dbirth_appl,b.itel_appl,b.ndeputy_appl,b.nrelation_appl,b.ndeputy_assured,a.dcreate, "
                       "       a.qdrunk_driving, a.isign, b.iins_kit, b.mcover_limit, b.iassured_cntry, b.iapplicant_cntry, b.fcharge_type, "
                       "       b.fequipment1,b.fequipment2,b.fequipment3,b.fequipment4,b.fequipment5,b.fequipment6,b.fequipment9,b.nequipment9, "
                       "       a.fedr_print,  a.fply_print, b.punknown_acc, b.iquery_num_unknown, b.qunknown_acc_sum, "
                       "       a.feply, a.feedr, a.aemail_eply, b.nassured_cntry, b.napplicant_cntry, a.ireverse_num, "
                       "       b.foccup, b.noccup, b.applicant_foccup, b.applicant_noccup, b.iowner, b.nowner, b.dbirth_owner, a.iref_num1, "
                       "       b.tmobile_appl, b.aemail_appl, a.dtedr_begin, a.dtedr_end , b.dtply_begin, b.dtply_end, b.iroute_accept, a.tmobile_eply, "
                       "       a.ireg_no ,a.iscan_no,a.fsign_status_edr,a.funder_chk_edr,a.isign_edr,a.dsign_edr,a.feterms,a.qviolate, "
                       "       b.dinstall, b.isequence, b.ainstall_zip, b.ainstall"
                       "  FROM %s:abn_edr_relation a, %s:abnormal_edr b"
                       " WHERE a.iabnormal = ? "
                       "   AND a.iabnormal = b.iabnormal",
            dbname_tp, dbname_tp);

    $PREPARE STMT_CUR1 FROM $prep_stmt;
    $DECLARE cur1 CURSOR FOR STMT_CUR1;
    $OPEN cur1 USING $iendorse;
    $FETCH cur1
        INTO $fcard_class,
        $ipolicy, $icard, $irelative_ply, $ilast_ply, $ffac,
        $fedr_class, $fpay, $ipay, $dedr_begin, $dedr_end,
        $ipro_year, $ibrand, $icar_type, $medrdmg_prem, $medrlia_prem,
        $ibig_comp, $ibig_branch, $ibig_office, $ibig_sales, $iresource,
        $ibroker, $iofficer, $iedr_area, $iedr_cashier, $iabn_type,
        $fpass, $itreaty, $ibranch, $medr_business, $fcomp_class,
        $fcomp_class_last, $fdiscount, $iedr_return, $terminate_rsn, $icar_flag,
        $qply_period, $dply_begin, $dply_end, $iassured, $iassured_ext, $fassured, $nassured,
        $ilicense, $fsex, $fmarriage, $nuser, $ibenef, $nbenef, $aassured,
        $aassured_zip, $apayment, $apayment_zip,
        $itel, $itel_night, $mobil_phone, $iemail, $iply_area, $nbrand_abbr, $ncar_abbr, $fcar_note,
        $qcylinder, $iengine, $ibody, $itag, $mcar_price, $nequipment, $flimit,
        $pdmg_align, $pbrg_align, $plia_align, $pdmg_factor_1st, $pbrg_factor_1st,
        $lia_class, $dmg_acc_1st, $dmg_acc_2nd, $dmg_acc_3rd,
        $qpt, $fpt, $psex_age, $psex_age_damage, $plia_acc, $pdmg_acc, $fhuman,
        $fcomp_24, $payresult, $irecover_num,
        $iext_policy, $qpro_month, $mkilo_ply, $mkilo_edr, $irisk, $irelative_ext,
        $ded_business, $fmservice, $fmaintain,
        $napplicant, $dbirth, $dissue,
        $iextra_charge, $gextra_charge, $pextra_charge,
        $iquery_num_damage, $iquery_num, $mequipment,
        $survey_num, $bound_num, $abnormal_num, $iapplicant, $mcancel, $iroute,
        $irate_type, $bzfrom, $iroute_comm, $icomm_obj, $qlia_acc_sum, $qdmg_acc_sum, $medrlia_commi, $qprovision,
        $fapplicant, $fsex_appl, $dbirth_appl, $itel_appl, $ndeputy_appl, $nrelation_appl, $ndeputy_assured, $dcreate, $qdrunk_driving, $isign,
        $iins_kit, $mcover_limit, $iassured_cntry, $iapplicant_cntry, $fcharge_type,
        $fequipment1, $fequipment2, $fequipment3, $fequipment4, $fequipment5, $fequipment6, $fequipment9, $nequipment9,
        $fedr_print, $fply_print, $punknown_acc, $iquery_num_unknown, $qunknown_acc_sum,
        $feply, $feedr, $aemail_eply, $nassured_cntry, $napplicant_cntry, $ireverse_num,
        $foccup, $noccup, $applicant_foccup, $applicant_noccup, $iowner, $nowner, $dbirth_owner, $iref_num1, $tmobile_appl, $aemail_appl,
        $dtedr_begin, $dtedr_end, $dtply_begin, $dtply_end, $iroute_accept_edr, $tmobile_eply, $ireg_no, $iscan_no_edr,
        $fsign_status_edr, $funder_chk_edr, $isign_edr, $dsign_edr, $feterms, $qviolate,
        $dinstall, $isequence, $ainstall_zip, $ainstall;

    if (SQLCODE == SQLNOTFOUND)
    {
      $CLOSE cur1;
      $FREE cur1;
      if (exitsub(reply, ERR29) == True)
        return ERR29;
      else
        return apiRC;
    }
    $CLOSE cur1;
    $FREE cur1;

  } /* end of else */
 

  /* 1071225004_SC1_ ����_���I�W��ѽվ�*/
  $SELECT iroute_accept
     INTO $iroute_accept
     FROM policy
    WHERE ipolicy = $ipolicy;

  $SELECT iinstall, ibatch_no, dpolicy, mbusiness,
          case when fcard_class = '1' then mlia_commi else 0 end, date(dcreate), dentry 
     INTO $iinstall, $ibatch_no, $dpolicy, $mbusiness,$mservice, $dcreate_ply, $dentry          
     FROM ply_relation WHERE ipolicy = $ipolicy;

  if (SQLCODE == SQLNOTFOUND)
  {
    strcpy(iinstall, " ");
  }

  iCount = 0;
  /*s_dendorse[0] = 0;
  if (strstr(iendorse, "CVP") == NULL)*  *1110718002_SC2 �s�W�L���q�ʤG���� ,�ץ�bug 
  if(estimate_type == 0)
  {*/
    /* 
    $SELECT COUNT(*)
       INTO $iCount
       FROM ply_relation_bak
      WHERE iendorse = $iendorse;

    if (iCount == 0) * ���ܩ|���X��� *
    {
      mbusiness += medr_business; * �̷s�~�ȶO�� *
      mservice += medrlia_commi;  * �̷s����O *
    }
    */ 
    EXEC SQL SELECT note1, note2, note3 INTO : note1, : note2, : note3 
               FROM endorsement_note 
              WHERE iendorse = : iendorse;
    if (SQLCODE == SQLNOTFOUND)
    {
         strcpy(note1,"");
         strcpy(note2,"");
         strcpy(note3,"");
    }
    /**
    if ((iendorse[CAR_EDR_ABN_POS-1] != 'Y') ||
        (isalpha(iendorse[CAR_EDR_ABN_POS])))
    if((estimate_type == 0)||(estimate_type == 1))**/
    if(estimate_type == 0)
    {
          strcpy (s_dendorse, cm_cdate_str_100 (dendorse));
    }      
    else
    {
          s_dendorse[0] = 0;
    }
    
  /*}  */
  printf("--trace mbusiness[%f] ",mbusiness);
  printf("--trace mservice[%f] ",mservice);
  
  $SELECT iarea
     INTO $iarea
     FROM ply_relation
    WHERE ipolicy = $ipolicy;
  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CA_NREL_PLY) == True)
      return M_CA_NREL_PLY;
    else
      return apiRC;
  }

  strcpy(s_dedr_begin, cm_cdate_str_100(dedr_begin));
  strcpy(s_dedr_end, cm_cdate_str_100(dedr_end));


  /*-----���O���p-----*/
  /***************************************************/
  /***************************************************/
  if (fcard_class[0] == '1')
  {
    strncpy(policy_1, ipolicy, CAR_POLICY_LEN);
    policy_1[CAR_POLICY_LEN] = 0;
    strcpy(policy_2, &ipolicy[CAR_POLICY_LEN]);
  }
  else
  {
    strncpy(policy_1, ipolicy, CAR_POLICY_LEN);
    policy_1[CAR_POLICY_LEN] = 0;
    strcpy(policy_2, &ipolicy[CAR_POLICY_LEN]);
  }

  memset(batch_no, 0, sizeof(batch_no));

  if (ibatch_no == 0)
    strcpy(batch_no, " ");
  else
    sprintf_s(batch_no, sizeof batch_no, "%d", ibatch_no);

  rc = ao_chk_charge(DBName, 'A', policy_1, policy_2, batch_no,
                     payresult, paystatus, paydate, notedate);

  /*** ���P�� ***/
  /* car9506142 ���P�ΰh���h�O�i�_�� */
  /*
  if (payresult[0] == 'C')
  {
      if (exitsub(reply, M_CA_PLY_CANCEL) == True)
          return M_CA_PLY_CANCEL;
      else
          return apiRC;
  }
  */

  /*** �h���h�O ***/
  /* car9506142 ���P�ΰh���h�O�i�_�� */
  /*
  if (payresult[0] == 'X')
  {
      if(exitsub (reply, M_CA_CHK_CHARGE_ERROR) == True)
          return M_CA_CHK_CHARGE_ERROR;
      else
          return apiRC;
  }
  */

  strcpy(s_dply_begin, cm_cdate_str_100(dply_begin));
  strcpy(s_dply_end, cm_cdate_str_100(dply_end));

  /* 1110607001_SC1 �ظmE�O�����t�� */
  strcpy(tmp_iendorse," ");
  if(estimate_type!=2){
    strcpy(tmp_iendorse, iendorse);
  }  

  cm_buf_put("%s %s %s %s %s %s   %c %c %c %c %s   %s %s %s",
             fcard_class, ipolicy, icard, ilast_ply, irelative_ply, tmp_iendorse,
             iabn_type[0], fpass[0], fedr_class[0], fpay[0], ipay,
             s_dedr_begin, s_dedr_end, s_dendorse);

  cm_buf_put("%s %c %s %s %s %s %s %s %s %s %s %s %s",
             iassured, fassured[0], iedr_area, nassured, nuser,
             ibenef, nbenef, aassured,
             itel, itel_night, mobil_phone, iemail,
             iply_area);

  cm_buf_put("%s %s %s",
             aassured_zip, apayment, apayment_zip);

  cm_buf_put("%l %s %s", qply_period, s_dply_begin, s_dply_end);
  cm_buf_put("%s %s %s %s %s %s",
             ipro_year, ibrand, nbrand_abbr, icar_type, fcar_note, ncar_abbr);

  sprintf_s(tmp_qcylinder, sizeof tmp_qcylinder, "%7.2f", qcylinder); /* 1080902001_SC2 �Ʈ�q�X�ܤp���I2�� */
  cm_buf_put("%s", tmp_qcylinder);

  sprintf_s(tmp_qpt, sizeof tmp_qpt, "%4.1f", qpt);
  cm_buf_put("%s %s", tmp_qpt, fpt);

  sprintf_s(tmp_pdmg_factor_1st, sizeof tmp_pdmg_factor_1st, "%6.4f", pdmg_factor_1st);
  sprintf_s(tmp_pbrg_factor_1st, sizeof tmp_pbrg_factor_1st, "%6.4f", pbrg_factor_1st);
  strcpy(tmp_pdmg_factor_2nd, "");
  strcpy(tmp_pbrg_factor_2nd, "");
  cm_buf_put("%s %s %s %s",
             tmp_pdmg_factor_1st, tmp_pbrg_factor_1st,
             tmp_pdmg_factor_2nd, tmp_pbrg_factor_2nd);

  cm_buf_put("%s %s %s %s %c %c",
             iengine, ibody, itag, ilicense, fsex[0], fmarriage[0]);

  cm_buf_put("%s", icar_flag);

  sprintf_s(tmp_psex_age, sizeof tmp_psex_age, "%3.12f", psex_age);
  sprintf_s(tmp_plia_acc, sizeof tmp_plia_acc, "%6.2f", plia_acc);
  sprintf_s(tmp_pdmg_acc, sizeof tmp_pdmg_acc, "%6.2f", pdmg_acc);
  cm_buf_put("%s %e %s %s",
             tmp_psex_age, psex_age_damage, tmp_plia_acc, tmp_pdmg_acc);

  cm_buf_put("%s %d %d %d",
             lia_class, dmg_acc_1st, dmg_acc_2nd, dmg_acc_3rd);

  cm_buf_put("%f %s %s",
             medr_business, fcomp_class_last, fcomp_class);

  cm_buf_put("%l %l %l",
             pdmg_align, pbrg_align, plia_align);

  cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s",
             fdiscount, iofficer, ibroker, iarea, ibig_comp, iresource, ibig_branch, iroute,
             ibig_office, ibig_sales, iinstall);

  sprintf_s(s_mcar_price, sizeof s_mcar_price, "%6.1f", mcar_price);

  printf("AA nequipment[%s]\n", nequipment);
  strcpy(equipdecode, equip_get(nequipment));
  printf("equipdecode[%s]\n", equipdecode);
  cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s",
             s_mcar_price, equipdecode, note1, note2, note3,
             itreaty, fcomp_24, iedr_return, terminate_rsn, fhuman, payresult);

  cm_buf_put("%s", irecover_num);
  cm_buf_put("%s %s %s %s %l", irate_type, bzfrom, iroute_comm, icomm_obj, qprovision);

  /* estimate_type = 0:��渹 , 1�GCVP , 2:CVR , 3:CY 
  if ((iendorse[CAR_EDR_ABN_POS - 1] != 'Y') ||
      (isalpha(iendorse[CAR_EDR_ABN_POS])))*/
  count = 0;    
  prep_stmt[0]='\0';
  if (estimate_type != 3)
  {
    if (estimate_type == 2)
    {
      
      sprintf_s(prep_stmt, sizeof prep_stmt, "SELECT %s %s %s %s %s %s %s %s FROM %s:%s WHERE %s %s ",
              "iedr_type, iins_type, medrinj_cover, medrdea_cover,",
              "medrdmg_cover, mdeduct, ",
              "medrins_prem,",
              "medr_prem,",
              "medrpure_prem,",
              "fcal_way, qserial, pcal, pcommission, pagent, pdiscount, drate_ym,",
              "qday, medr_expense, medr_exp_disc, provision, safe_rate, manage_rate, educated_rate,",
              "deviation_rate, pextra_charge, pbusiness, psex_age ",
              dbname_tp,
              "ca_ed_quotation_ins",
              " iquote = ? AND iedr_type <>''",
              "ORDER BY rowid");    
    }
    else /* ��渹 or CVP */
    {
      sprintf_s(prep_stmt, sizeof prep_stmt, "SELECT %s %s %s %s %s %s %s %s FROM %s WHERE %s %s ",
              "iedr_type, iins_type, medrinj_cover, medrdea_cover,",
              "medrdmg_cover, mdeduct, ",
              "medrins_prem,",
              "medr_prem,",
              "medrpure_prem,",
              "fcal_way, qserial, pcal, pcommission, pagent, pdiscount, drate_ym,",
              "qday, medr_expense, medr_exp_disc, provision, safe_rate, manage_rate, educated_rate,",
              "deviation_rate, pextra_charge, pbusiness, psex_age ",
              "edr_ins_type",
              " iendorse = ? ",
              "ORDER BY rowid");
    }
  }
  else
  {
    sprintf_s(prep_stmt, sizeof prep_stmt, "SELECT %s %s %s %s %s %s %s %s FROM %s:%s WHERE %s %s ",
            "iedr_type, iins_type, medrinj_cover, medrdea_cover,",
            "medrdmg_cover, mdeduct, ",
            "medrins_prem,",
            "medr_prem,",
            "medrpure_prem,",
            "fcal_way, qserial, pcal, pcommission, pagent, pdiscount, drate_ym,",
            "qday, medr_expense, medr_exp_disc, provision, safe_rate, manage_rate, educated_rate,",
            "deviation_rate, pextra_charge, pbusiness, psex_age ",
            dbname_tp,
            "abn_edr_ins_type",
            " iabnormal = ? ",
            "ORDER BY rowid");
  }

  printf("prep_stmt[%s]\n", prep_stmt);
  $PREPARE STMT_CUR3 FROM $prep_stmt;
  $DECLARE query33 CURSOR FOR STMT_CUR3;
  $OPEN query33 USING $iendorse;
  for (;;)
  {
    $FETCH query33
        INTO $iedr_type,
        $iins_type, $medrinj_cover, $medrdea_cover,
        $medrdmg_cover, $mdeduct,
        $medrins_prem,
        $medr_prem,
        $medrpure_prem,
        $fcal_way, $qserial, $pcal, $pcommission, $pagent, $pdiscount, $drate_ym,
        $qday, $medr_expense, $medr_exp_disc, $provision, $safe_rate, $manage_rate, $educated_rate,
        $deviation_rate, $pextra_charge, $pbusiness, $psex_age;
    if (SQLCODE != 0) break;
      
    count++;

    /* �N���[�O�O�ۧ��O�O�γW���O�O���ư� */
    if (((strcmp(trim(iins_type), "01") == 0) ||
         (strcmp(trim(iins_type), "05") == 0) ||         
         (strcmp(trim(iins_type), "09") == 0) ||
         (strcmp(trim(iins_type), "198") == 0)||
         (strcmp(trim(iins_type), "11") == 0) ||
         (strcmp(trim(iins_type), "201") == 0) ||
         (strcmp(trim(iins_type), "205") == 0) ||
         (strcmp(trim(iins_type), "209") == 0) ||
         (strcmp(trim(iins_type), "211") == 0) ) &&
        (medr_expense != 0))
    {
      medrins_prem = medrins_prem - medr_expense;
      medr_prem = medr_prem - (medr_expense + medr_exp_disc);
    }

    medrinj_cover = medrinj_cover / 100;
    medrdea_cover = medrdea_cover / 100;
    medrdmg_cover = medrdmg_cover / 100;
    sprintf_s(temp, sizeof temp, "%c%03d", fcal_way[0], pcal);

    sprintf_s(tmp_commission, sizeof tmp_commission, "%4.2f", pcommission);
    sprintf_s(tmp_agent, sizeof tmp_agent, "%4.2f", pagent);
    sprintf_s(tmp_discount, sizeof tmp_discount, "%4.2f", pdiscount);

    sprintf_s(tmp_pure_prem, sizeof tmp_pure_prem, "%13.4f", medrpure_prem);
    strcpy(tmp_pure_prem, trim(tmp_pure_prem));

    lLoading += (long)medrins_prem - (long)medrpure_prem + (long)medr_expense;

    /* �ഫ�W�B�d���I��h�O�B�N��qday���ĤT�H�d���I�O�I���B�@,�G,�T */
    if (strcmp(trim(iins_type), "29") == 0)
    {
      if (qday < 0)
        qday = (-1) * qday;

      code = lReturnIns29BaseCover(qday, &coverage1_31, &coverage2_31, &coverage3_32);
      qday = 0;
    }

    if (strcmp(trim(iins_type), "31") == 0 || strcmp(trim(iins_type), "231") == 0 || strcmp(trim(iins_type), "531") == 0)
    {
      qday = 0;
    }

    /* add medr_prem */
    cm_buf_put("%s %s   %l %l %l %l  %s %l %l %s   %s %s   %s %s %s  %l %l %e %e %e %e %e %e %e",
                iedr_type, iins_type,
                medrinj_cover, medrdea_cover, medrdmg_cover, mdeduct, provision,
                medr_prem, medrins_prem, tmp_pure_prem,
                temp, drate_ym,
                tmp_commission, tmp_agent, tmp_discount,
                qday, medr_expense, safe_rate, manage_rate, educated_rate, deviation_rate,
                pextra_charge, pbusiness, psex_age);
  }
  $CLOSE query33;
  $FREE query33;

  cm_buf_put_count(count);
  medr_prem = medrdmg_prem + medrlia_prem;

  cm_buf_put("%l", medr_prem);
  cm_buf_put("%s", ffac);

  cm_buf_put("%l %l %l", coverage1_31, coverage2_31, coverage3_32);

  /*** �ˮ`�I���Ӹ�ƥ�� ***/
  /*if ((iendorse[CAR_EDR_ABN_POS - 1] != 'Y') ||
      (isalpha(iendorse[CAR_EDR_ABN_POS])))
  */    
  count_33 = count_48 = count_35 = count_56 = 0;
  strcpy(sIins_type, " ");

  prep_stmt[0] = '\0';
  strcpy(sTmp,"");
  /* estimate_type = 0:��渹 , 1�GCVP , 2:CVR , 3:CY */
  if (estimate_type != 3)  
  { 
    if (estimate_type == 2)
    {
      sprintf_s(prep_stmt, sizeof prep_stmt, "SELECT count(*) FROM %s:%s WHERE %s AND %s ",
              dbname_tp,
              "ca_ed_quotation_assured_dtl",
              "iquote = ? AND iedr_type <> ''",
              "iins_type = ?" );
     
      $PREPARE prepCnt48 FROM $prep_stmt;
      $EXECUTE prepCnt48 INTO $count_48 USING $iendorse, "48";
      $FREE prepCnt48;

      $PREPARE prepCnt35 FROM $prep_stmt;
      $EXECUTE prepCnt35 INTO $count_35 USING $iendorse, "35";
      $FREE prepCnt35;        

      prep_stmt[0] = '\0';
      sprintf_s(prep_stmt, sizeof prep_stmt, 
              "SELECT iins_type,count(*) FROM %s:%s WHERE %s AND iins_type in ('56','136','166','266') GROUP BY 1",
              dbname_tp,
              "ca_ed_quotation_assured_dtl",
              "iquote = ? AND iedr_type <>''");
              
      $PREPARE prepCnt56 FROM $prep_stmt;
      $EXECUTE prepCnt56 INTO $sIins_type,$count_56 USING $iendorse;
      $FREE prepCnt56;
    }
    else
    {
      /* �D���`��� */
      /*
      EXEC SQL SELECT count(*)
                 INTO : count_33
                 FROM ca_pa_edr
                WHERE iendorse = $iendorse
                  AND iins_type = '33';
      
      cm_buf_put("%d ", count_33);
      */
      EXEC SQL SELECT count(*)
                 INTO : count_48
                 FROM ca_pa_edr
                WHERE iendorse = $iendorse
                  AND iins_type = '48';

      EXEC SQL SELECT count(*)
                 INTO : count_35
                 FROM ca_pa_edr
                WHERE iendorse = $iendorse
                  AND iins_type = '35';

      EXEC SQL SELECT first 1 iins_type, count(*) 
                 INTO $sIins_type, : count_56 
                 FROM ca_pa_edr 
                WHERE iendorse = $iendorse 
                  AND iins_type in('56', '136', '166', '266')
                group by 1;
    }            
  }
  else /* ���`���� */
  {
    /*
    sprintf_s(prep_stmt, sizeof prep_stmt, "SELECT count(*) FROM %s:%s WHERE %s ",
            dbname_tp,
            "abn_ca_pa_edr",
            "iabnormal = ? AND iins_type = '33' ");

    $PREPARE STMT_COUNT33_TMP FROM $prep_stmt;
    $DECLARE cur_count_33 CURSOR FOR STMT_COUNT33_TMP;
    $OPEN cur_count_33 USING $iendorse;
    $FETCH cur_count_33 INTO $count_33;
    $CLOSE cur_count_33;
    $FREE cur_count_33;
    
    cm_buf_put("%d ", count_33);
    */

    sprintf_s(prep_stmt, sizeof prep_stmt, "SELECT count(*) FROM %s:%s WHERE %s ",
            dbname_tp,
            "abn_ca_pa_edr",
            "iabnormal = ? AND iins_type = '48' ");

    $PREPARE STMT_COUNT48_TMP FROM $prep_stmt;
    $DECLARE cur_count_48 CURSOR FOR STMT_COUNT48_TMP;
    $OPEN cur_count_48 USING $iendorse;
    $FETCH cur_count_48 INTO $count_48;
    $CLOSE cur_count_48;
    $FREE cur_count_48;

    sprintf_s(prep_stmt, sizeof prep_stmt, "SELECT count(*) FROM %s:%s WHERE %s ",
            dbname_tp,
            "abn_ca_pa_edr",
            "iabnormal = ? AND iins_type = '35' ");

    $PREPARE STMT_COUNT35_TMP FROM $prep_stmt;
    $DECLARE cur_count_35 CURSOR FOR STMT_COUNT35_TMP;
    $OPEN cur_count_35 USING $iendorse;
    $FETCH cur_count_35 INTO $count_35;
    $CLOSE cur_count_35;
    $FREE cur_count_35;

    sprintf_s(prep_stmt, sizeof prep_stmt, "SELECT first 1 iins_type,count(*) FROM %s:%s WHERE %s ",
            dbname_tp,
            "abn_ca_pa_edr",
            "iabnormal = ? AND iins_type in ('56','136','166','266') group by 1");

    $PREPARE STMT_COUNT56_TMP FROM $prep_stmt;
    $DECLARE cur_count_56 CURSOR FOR STMT_COUNT56_TMP;
    $OPEN cur_count_56 USING $iendorse;
    $FETCH cur_count_56 INTO $sIins_type, $count_56;
    $CLOSE cur_count_56;
    $FREE cur_count_56;
  }

  cm_buf_put("%d ", count_33);
 
  /* 1110607001_SC1 �ظmE�O�����t�� */
  /* estimate_type = 0:��渹 , 1�GCVP , 2:CVR , 3:CY */
  /*** �ˮ`�I���Ӹ�� **
  if ((iendorse[CAR_EDR_ABN_POS - 1] != 'Y') ||
      (isalpha(iendorse[CAR_EDR_ABN_POS])))*/
  if (estimate_type != 3)      
  {
    if (estimate_type == 2)
    {
      cm_buf_put("%d ", count_48);

      $DECLARE qry_cur_48_edr CURSOR FOR
          SELECT iedr_type, a.iassured[1,10], a.nassured[1,30],a.dbirth, b.iins_scope,                  
                 b.medrins_amt,b.medrins_premium, b.medrpure_prem, a.frel_assured,b.pcommission, 
                 b.pagent, b.pdiscount, b.medr_daily_pay, b.medr_mr_ins_prem, b.medr_mr_pure_prem
            INTO $iedr_type, $cIinsurant, $cNinsurant, $lDbirth, $cIins_scope,
                 $lMins_amt, $lMins_premium, $lMpure_prem_48, $cRelation_appl, $dPcommission, 
                 $dPagent, $dPdiscount, $lMedr_daily_pay, $lMedr_mr_insprem, $lMedr_mr_pureprem         
            FROM newa00:ca_ed_quotation_assured a, newa00:ca_ed_quotation_assured_dtl b 
            WHERE a.iquote   = b.iquote 
              AND a.iassured = b.iassured 
              AND a.iquote   = $iendorse
              AND b.iedr_type <> ''
              AND b.iins_type in ('48') ORDER BY a.iassured;
      $OPEN qry_cur_48_edr;
      for (;;)
      {
        $FETCH qry_cur_48_edr;

        if (SQLCODE != 0) break;

        lMins_amt = lMins_amt / 10000;
        lMedr_daily_pay /= 10000;

        strcpy(cDbirth, cm_cdate_str_100(lDbirth));

        sprintf_s(tmp_commission, sizeof tmp_commission, "%4.2f", dPcommission);
        sprintf_s(tmp_agent, sizeof tmp_agent, "%4.2f", dPagent);
        sprintf_s(tmp_discount, sizeof tmp_discount, "%4.2f", dPdiscount);

        sprintf_s(tmp_pure_prem, sizeof tmp_pure_prem, "%10.0f", lMpure_prem_48);
        strcpy(tmp_pure_prem, trim(tmp_pure_prem));

        sprintf_s(tmp_edr_pure_prem, sizeof tmp_edr_pure_prem, "%10.0f", lMedr_mr_pureprem);
        strcpy(tmp_edr_pure_prem, trim(tmp_edr_pure_prem));

        /* fix:1120619 */
        if (strcmp(iedr_type,"40")!=0 && strcmp(iedr_type,"02")!=0 && strcmp(iedr_type,"50")!=0) /* ��J�W�U�ɡA��40�B02�B50�~�A��l*/
        {
           strcpy(tmp_pure_prem,"0.0");
           strcpy(tmp_edr_pure_prem,"0.0");
           lMins_premium = 0;
           lMedr_mr_insprem= 0;
        } 

        cm_buf_put("%s ", iedr_type);
        cm_buf_put("%s %s %s %s   %l %l %s  %s  %s %s %s  %l %l %s",
                  cIinsurant, cNinsurant, cDbirth, cIins_scope,
                  lMins_amt, lMins_premium, tmp_pure_prem,
                  cRelation_appl,
                  tmp_commission, tmp_agent, tmp_discount,
                  lMedr_daily_pay, lMedr_mr_insprem, tmp_edr_pure_prem);        
      }
      $CLOSE qry_cur_48_edr;
      $FREE qry_cur_48_edr;


      cm_buf_put("%d ", count_35);

      $DECLARE qry_cur_35_edr CURSOR FOR
          SELECT iedr_type, a.iassured[1,10], a.nassured[1,30],b.iins_scope,                  
                 b.medrins_amt,b.medrins_premium, b.medrpure_prem,
                 b.pcommission, b.pagent, b.pdiscount
            INTO $iedr_type, $cIinsurant, $cNinsurant, $cIins_scope,
                 $lMins_amt, $lMins_premium, $lMpure_prem_35, 
                 $dPcommission, $dPagent, $dPdiscount        
            FROM newa00:ca_ed_quotation_assured a, newa00:ca_ed_quotation_assured_dtl b 
            WHERE a.iquote   = b.iquote 
              AND a.iassured = b.iassured 
              AND a.iquote   = $iendorse
              AND b.iedr_type <> ''
              AND b.iins_type in ('35') ORDER BY a.iassured;
      $OPEN qry_cur_35_edr;
      for (;;)
      {
        $FETCH qry_cur_35_edr;

        if (SQLCODE != 0) break;

        lMins_amt = lMins_amt / 10000;

        sprintf_s(tmp_commission, sizeof tmp_commission, "%4.2f", dPcommission);
        sprintf_s(tmp_agent, sizeof tmp_agent, "%4.2f", dPagent);
        sprintf_s(tmp_discount, sizeof tmp_discount, "%4.2f", dPdiscount);

        sprintf_s(tmp_pure_prem, sizeof tmp_pure_prem, "%10.0f", lMpure_prem_35);
        strcpy(tmp_pure_prem, trim(tmp_pure_prem));

        strcpy(iedr_type,trim(iedr_type));

        /* fix:1120619 */
        if (strcmp(iedr_type,"40")!=0 && strcmp(iedr_type,"02")!=0 && strcmp(iedr_type,"50")!=0) /* ��J�W�U�ɡA��40�B02�B50�~�A��l*/
        {
           strcpy(tmp_pure_prem,"0.0");
           lMins_premium = 0;
        }  


        cm_buf_put("%s ", iedr_type);
        cm_buf_put("%s %s %s   %l %l %s  %s %s %s ",
                  cIinsurant, cNinsurant, cIins_scope,
                  lMins_amt, lMins_premium, tmp_pure_prem,
                  tmp_commission, tmp_agent, tmp_discount);       
      }
      $CLOSE qry_cur_35_edr;
      $FREE qry_cur_35_edr;

      cm_buf_put("%d %s", count_56, sIins_type);

      $DECLARE qry_cur_56_edr CURSOR FOR
          SELECT iedr_type, a.iassured[1,10], a.nassured[1,30],a.dbirth, b.iins_scope,
                 b.medrins_amt,b.medrins_premium, b.medrpure_prem, a.nbenef, a.rel_benef ,
                 b.pcommission,b.pagent, b.pdiscount, b.medr_daily_pay, b.medr_mr_ins_prem, b.medr_mr_pure_prem,
                 a.tbenef, a.abenef_zip, a.abenef,' '
            INTO $iedr_type, $cIinsurant, $cNinsurant, $lDbirth, $cIins_scope,
                 $lMins_amt, $lMins_premium, $lMpure_prem_56, $cNbeneficiary, $cRelation_bene, 
                 $dPcommission, $dPagent, $dPdiscount, $lMedr_daily_pay, $lMedr_mr_insprem, $lMedr_mr_pureprem,
                 $s_tenef,  $s_abenef_zip, $s_abenef, $cAinsurant                 
            FROM newa00:ca_ed_quotation_assured a, newa00:ca_ed_quotation_assured_dtl b 
            WHERE a.iquote   = b.iquote 
              AND a.iassured = b.iassured 
              AND a.iquote   = $iendorse
              AND b.iedr_type <> ''
              AND b.iins_type in ('56','136','166','266') ORDER BY a.iassured;
      $OPEN qry_cur_56_edr;
      for (;;)
      {
        $FETCH qry_cur_56_edr;

        if (SQLCODE != 0) break;
        lMins_amt = lMins_amt / 10000;

        strcpy(cDbirth, cm_cdate_str_100(lDbirth));

        sprintf_s(tmp_commission, sizeof tmp_commission, "%4.2f", dPcommission);
        sprintf_s(tmp_agent, sizeof tmp_agent, "%4.2f", dPagent);
        sprintf_s(tmp_discount, sizeof tmp_discount, "%4.2f", dPdiscount);

        sprintf_s(tmp_pure_prem, sizeof tmp_pure_prem, "%10.0f", lMpure_prem_56);
        strcpy(tmp_pure_prem, trim(tmp_pure_prem));

        sprintf_s(tmp_edr_pure_prem, sizeof tmp_edr_pure_prem, "%10.0f", lMedr_mr_pureprem);
        strcpy(tmp_edr_pure_prem, trim(tmp_edr_pure_prem));

        strcpy(iedr_type,trim(iedr_type));

        /* fix:1120619�G ex. �G��05�W�U�ɡA�O�O�|double */
        if (strcmp(iedr_type,"40")!=0 && strcmp(iedr_type,"02")!=0 && strcmp(iedr_type,"50")!=0) /* ��J�W�U�ɡA��40�B02�B50�~�A��l*/
        {
           strcpy(tmp_pure_prem    ,"0.0");
           strcpy(tmp_edr_pure_prem,"0.0");
           lMins_premium = 0;
           lMedr_mr_insprem = 0;
        }        

        /* 1110607001_SC2 �ظmE�O�����t��_�[�O�ιL�� */
        /* �L����պ�/���`���ɡA�|���N iedr_type = 10 (�W�U���O�O����0��) ���@���� rowid�Ȧs�b cAinsurant, 
           �H�Ѥ������渹�ɷ��@ update ca_pa_ply��where����C
           CVR ������s�ɮɨS���s�� rowid (�S��cAinsurant�o�����)�A�ҥH�q�O�檺ca_pa_ply �� */ 
        /* ������S���s�� */
        if (strcmp(iedr_type,"10")==0) 
        {
             $Select first 1 rowid||'' Into $cAinsurant 
                From ca_pa_ply 
               Where ipolicy = $ipolicy  
                 And mins_premium > 0;
        }

        cm_buf_put("%s ", iedr_type);
        cm_buf_put("%s %s %s %s   %l %l %s  %s %s  %s %s %s  %l %l %s %s %s %s %s",
                  cIinsurant, cNinsurant, cDbirth, cIins_scope,
                  lMins_amt, lMins_premium, tmp_pure_prem,
                  cNbeneficiary, cRelation_bene,
                  tmp_commission, tmp_agent, tmp_discount,
                  lMedr_daily_pay, lMedr_mr_insprem, tmp_edr_pure_prem, cAinsurant, s_tenef, s_abenef_zip, s_abenef);
        /* 1100104007_SC1 56�I�L��ɦW�U��ƽЦ۰ʦ^���s���D*/
        /* �Y���պ�/���`���AcAinsurant �s�� rowid */
      }
      $CLOSE qry_cur_56_edr;
      $FREE qry_cur_56_edr;

      /*     
      strcpy(sDbname, "");
      strcpy(sColumn, "iendorse");
      strcpy(sTable, "edr_ins_cover");
      strcpy(sTable1, "edr_ins_assured");
      strcpy(sTable2, "ca_edr_bound");
      */      
      strcpy(sDbname, "");
      strcpy(sColumn, "");
      strcpy(sTable , "");
      strcpy(sTable1, "");
      strcpy(sTable2, "");
    }
    else
    {
      /*
      $DECLARE query_cur_33 CURSOR FOR
          SELECT  iedr_type,
                  iinsurant, ninsurant, dbirth, ainsurant,
                  iins_scope, icareer,
                  medrins_amt, medrins_prem, medrpure_prem,
                  napplicant, relation_appl,
                  nbeneficiary, relation_bene,
                  pcommission, pagent, pdiscount,
                  medr_daily_pay, medr_mr_ins_prem, medr_mr_pure_prem INTO : iedr_type,
                  : cIinsurant,
                  : cNinsurant,
                  : lDbirth,
                  : cAinsurant,
                  : cIins_scope,
                  : cIcareer,
                  : lMins_amt,
                  : lMins_premium,
                  : lMpure_prem_33,
                  : cNapplicant,
                  : cRelation_appl,
                  : cNbeneficiary,
                  : cRelation_bene,
                  : dPcommission,
                  : dPagent,
                  : dPdiscount,
                  : lMedr_daily_pay,
                  : lMedr_mr_insprem,
                  : lMedr_mr_pureprem
            FROM ca_pa_edr
           WHERE iendorse = $iendorse
             AND iins_type = '33' ORDER BY iinsurant;
      $OPEN query_cur_33;
      for (;;)
      {
        $FETCH query_cur_33;

        if (SQLCODE != 0)
          break;

        lMins_amt = lMins_amt / 10000;

        strcpy(cDbirth, cm_cdate_str_100(lDbirth));

        sprintf_s(tmp_commission, sizeof tmp_commission, "%4.2f", dPcommission);
        sprintf_s(tmp_agent, sizeof tmp_agent, "%4.2f", dPagent);
        sprintf_s(tmp_discount, sizeof tmp_discount, "%4.2f", dPdiscount);

        sprintf_s(tmp_pure_prem, sizeof tmp_pure_prem, "%10.0f", lMpure_prem_33);
        strcpy(tmp_pure_prem, trim(tmp_pure_prem));

        sprintf_s(tmp_edr_pure_prem, sizeof tmp_edr_pure_prem, "%10.0f", lMedr_mr_pureprem);
        strcpy(tmp_edr_pure_prem, trim(tmp_edr_pure_prem));

        cm_buf_put("%s ", iedr_type);
        cm_buf_put("%s %s %s %s   %s %s   %l %l %s  %s %s   %s %s  %s %s %s  %l %l %s",
                  cIinsurant, cNinsurant, cDbirth, cAinsurant,
                  cIins_scope, cIcareer,
                  lMins_amt, lMins_premium, tmp_pure_prem,
                  cNapplicant, cRelation_appl,
                  cNbeneficiary, cRelation_bene,
                  tmp_commission, tmp_agent, tmp_discount,
                  lMedr_daily_pay, lMedr_mr_insprem, tmp_edr_pure_prem);
      }
      $CLOSE query_cur_33;
      $FREE query_cur_33;
      */

      cm_buf_put("%d ", count_48);

      $DECLARE query_cur_48 CURSOR FOR
          SELECT iedr_type,
                 iinsurant, ninsurant, dbirth, iins_scope,
                 medrins_amt, medrins_prem, medrpure_prem,
                 relation_appl,
                 pcommission, pagent, pdiscount,
                 medr_daily_pay, medr_mr_ins_prem, medr_mr_pure_prem 
            INTO : iedr_type,
                 : cIinsurant,
                 : cNinsurant,
                 : lDbirth,
                 : cIins_scope,
                 : lMins_amt,
                 : lMins_premium,
                 : lMpure_prem_48,
                 : cRelation_appl,
                 : dPcommission,
                 : dPagent,
                 : dPdiscount,
                 : lMedr_daily_pay,
                 : lMedr_mr_insprem,
                 : lMedr_mr_pureprem
          FROM ca_pa_edr
         WHERE iendorse = $iendorse
           AND iins_type = '48' ORDER BY iinsurant;
      $OPEN query_cur_48;
      for (;;)
      {
        $FETCH query_cur_48;

        if (SQLCODE != 0)
          break;

        lMins_amt = lMins_amt / 10000;
        lMedr_daily_pay /= 10000;

        strcpy(cDbirth, cm_cdate_str_100(lDbirth));

        sprintf_s(tmp_commission, sizeof tmp_commission, "%4.2f", dPcommission);
        sprintf_s(tmp_agent, sizeof tmp_agent, "%4.2f", dPagent);
        sprintf_s(tmp_discount, sizeof tmp_discount, "%4.2f", dPdiscount);

        sprintf_s(tmp_pure_prem, sizeof tmp_pure_prem, "%10.0f", lMpure_prem_48);
        strcpy(tmp_pure_prem, trim(tmp_pure_prem));

        sprintf_s(tmp_edr_pure_prem, sizeof tmp_edr_pure_prem, "%10.0f", lMedr_mr_pureprem);
        strcpy(tmp_edr_pure_prem, trim(tmp_edr_pure_prem));

        cm_buf_put("%s ", iedr_type);
        cm_buf_put("%s %s %s %s   %l %l %s  %s  %s %s %s  %l %l %s",
                  cIinsurant, cNinsurant, cDbirth, cIins_scope,
                  lMins_amt, lMins_premium, tmp_pure_prem,
                  cRelation_appl,
                  tmp_commission, tmp_agent, tmp_discount,
                  lMedr_daily_pay, lMedr_mr_insprem, tmp_edr_pure_prem);
      }
      $CLOSE query_cur_48;
      $FREE query_cur_48;

      cm_buf_put("%d ", count_35);

      $DECLARE query_cur_35 CURSOR FOR
          SELECT iedr_type,
                 iinsurant, ninsurant, iins_scope,
                 medrins_amt, medrins_prem, medrpure_prem,
                 pcommission, pagent, pdiscount 
            INTO : iedr_type,
                 : cIinsurant,
                 : cNinsurant,
                 : cIins_scope,
                 : lMins_amt,
                 : lMins_premium,
                 : lMpure_prem_35,
                 : dPcommission,
                 : dPagent,
                 : dPdiscount
            FROM ca_pa_edr
           WHERE iendorse = $iendorse
             AND iins_type = '35' ORDER BY iinsurant;
      $OPEN query_cur_35;
      for (;;)
      {
        $FETCH query_cur_35;

        if (SQLCODE != 0)
          break;

        lMins_amt = lMins_amt / 10000;

        sprintf_s(tmp_commission, sizeof tmp_commission, "%4.2f", dPcommission);
        sprintf_s(tmp_agent, sizeof tmp_agent, "%4.2f", dPagent);
        sprintf_s(tmp_discount, sizeof tmp_discount, "%4.2f", dPdiscount);

        sprintf_s(tmp_pure_prem, sizeof tmp_pure_prem, "%10.0f", lMpure_prem_35);
        strcpy(tmp_pure_prem, trim(tmp_pure_prem));

        cm_buf_put("%s ", iedr_type);
        cm_buf_put("%s %s %s   %l %l %s  %s %s %s ",
                  cIinsurant, cNinsurant, cIins_scope,
                  lMins_amt, lMins_premium, tmp_pure_prem,
                  tmp_commission, tmp_agent, tmp_discount);
      }
      $CLOSE query_cur_35;
      $FREE query_cur_35;

      cm_buf_put("%d %s", count_56, sIins_type);

      $DECLARE query_cur_56 CURSOR FOR
          SELECT  iedr_type,
                  iinsurant, ninsurant, dbirth, iins_scope,
                  medrins_amt, medrins_prem, medrpure_prem,
                  nbeneficiary, relation_bene,
                  pcommission, pagent, pdiscount,
                  medr_daily_pay, medr_mr_ins_prem, medr_mr_pure_prem, tbenef, abenef_zip, abenef, ainsurant INTO : iedr_type,
                  : cIinsurant,
                  : cNinsurant,
                  : lDbirth,
                  : cIins_scope,
                  : lMins_amt,
                  : lMins_premium,
                  : lMpure_prem_56,
                  : cNbeneficiary,
                  : cRelation_bene,
                  : dPcommission,
                  : dPagent,
                  : dPdiscount,
                  : lMedr_daily_pay,
                  : lMedr_mr_insprem,
                  : lMedr_mr_pureprem,
                  : s_tenef,
                  : s_abenef_zip,
                  : s_abenef,
                  : cAinsurant
            FROM ca_pa_edr
           WHERE iendorse = $iendorse
             AND iins_type = $sIins_type
           ORDER BY iinsurant;
      $OPEN query_cur_56;
      for (;;)
      {
        $FETCH query_cur_56;

        if (SQLCODE != 0)
          break;

        lMins_amt = lMins_amt / 10000;

        strcpy(cDbirth, cm_cdate_str_100(lDbirth));

        sprintf_s(tmp_commission, sizeof tmp_commission, "%4.2f", dPcommission);
        sprintf_s(tmp_agent, sizeof tmp_agent, "%4.2f", dPagent);
        sprintf_s(tmp_discount, sizeof tmp_discount, "%4.2f", dPdiscount);

        sprintf_s(tmp_pure_prem, sizeof tmp_pure_prem, "%10.0f", lMpure_prem_56);
        strcpy(tmp_pure_prem, trim(tmp_pure_prem));

        sprintf_s(tmp_edr_pure_prem, sizeof tmp_edr_pure_prem, "%10.0f", lMedr_mr_pureprem);
        strcpy(tmp_edr_pure_prem, trim(tmp_edr_pure_prem));

        cm_buf_put("%s ", iedr_type);
        cm_buf_put("%s %s %s %s   %l %l %s  %s %s  %s %s %s  %l %l %s %s %s %s %s",
                  cIinsurant, cNinsurant, cDbirth, cIins_scope,
                  lMins_amt, lMins_premium, tmp_pure_prem,
                  cNbeneficiary, cRelation_bene,
                  tmp_commission, tmp_agent, tmp_discount,
                  lMedr_daily_pay, lMedr_mr_insprem, tmp_edr_pure_prem, cAinsurant, s_tenef, s_abenef_zip, s_abenef);
        /* 1100104007_SC1 56�I�L��ɦW�U��ƽЦ۰ʦ^���s���D*/
        /* �Y���պ�/���`���AcAinsurant �s�� rowid */
      }
      $CLOSE query_cur_56;
      $FREE query_cur_56;

      strcpy(sDbname, "");
      strcpy(sColumn, "iendorse");
      strcpy(sTable, "edr_ins_cover");
      strcpy(sTable1, "edr_ins_assured");
      strcpy(sTable2, "ca_edr_bound");
    }
  }
  else
  {
    /*
    sprintf_s(prep_stmt, sizeof prep_stmt, "SELECT %s %s %s %s %s %s %s %s FROM %s:%s WHERE %s %s",
            "iedr_type,",
            "iinsurant , ninsurant , dbirth , ainsurant ,",
            "iins_scope , icareer ,",
            "medrins_amt , medrins_prem , medrpure_prem ,",
            "napplicant , relation_appl ,",
            "nbeneficiary , relation_bene, ",
            "pcommission , pagent, pdiscount, ",
            "medr_daily_pay, mr_ins_prem, mr_pure_prem ",
            dbname_tp,
            "abn_ca_pa_edr",
            " iabnormal = ? AND iins_type = '33' ",
            "ORDER BY iinsurant");

    $PREPARE ABN_QRY_SMT_CUR33 FROM $prep_stmt;
    $DECLARE abn_query_cur_33 CURSOR FOR ABN_QRY_SMT_CUR33;
    $OPEN abn_query_cur_33 USING $iendorse;
    for (;;)
    {
      $FETCH abn_query_cur_33 INTO : iedr_type,
          : cIinsurant,
          : cNinsurant,
          : lDbirth,
          : cAinsurant,
          : cIins_scope,
          : cIcareer,
          : lMins_amt,
          : lMins_premium,
          : lMpure_prem_33,
          : cNapplicant,
          : cRelation_appl,
          : cNbeneficiary,
          : cRelation_bene,
          : dPcommission,
          : dPagent,
          : dPdiscount,
          : lMedr_daily_pay,
          : lMedr_mr_insprem,
          : lMedr_mr_pureprem;

      if (SQLCODE != 0)
        break;

      lMins_amt = lMins_amt / 10000;
      strcpy(cDbirth, cm_cdate_str_100(lDbirth));

      sprintf_s(tmp_commission, sizeof tmp_commission, "%4.2f", dPcommission);
      sprintf_s(tmp_agent, sizeof tmp_agent, "%4.2f", dPagent);
      sprintf_s(tmp_discount, sizeof tmp_discount, "%4.2f", dPdiscount);

      sprintf_s(tmp_pure_prem, sizeof tmp_pure_prem, "%10.0f", lMpure_prem_33);
      strcpy(tmp_pure_prem, trim(tmp_pure_prem));

      sprintf_s(tmp_edr_pure_prem, sizeof tmp_edr_pure_prem, "%10.0f", lMedr_mr_pureprem);
      strcpy(tmp_edr_pure_prem, trim(tmp_edr_pure_prem));

      cm_buf_put("%s ", iedr_type);
      cm_buf_put("%s %s %s %s   %s %s   %l %l %s  %s %s   %s %s   %s %s %s  %l %l %s",
                 cIinsurant, cNinsurant, cDbirth, cAinsurant,
                 cIins_scope, cIcareer,
                 lMins_amt, lMins_premium, tmp_pure_prem,
                 cNapplicant, cRelation_appl,
                 cNbeneficiary, cRelation_bene,
                 tmp_commission, tmp_agent, tmp_discount,
                 lMedr_daily_pay, lMedr_mr_insprem, tmp_edr_pure_prem);
    }
    $CLOSE abn_query_cur_33;
    $FREE abn_query_cur_33;
    */

    cm_buf_put("%d ", count_48);

    sprintf_s(prep_stmt, sizeof prep_stmt, "SELECT %s %s %s %s %s %s %s FROM %s:%s WHERE %s %s",
            "iedr_type,",
            "iinsurant , ninsurant , dbirth , ",
            "iins_scope , ",
            "medrins_amt , medrins_prem , medrpure_prem ,",
            "relation_appl ,",
            "pcommission , pagent, pdiscount, ",
            "medr_daily_pay, mr_ins_prem, mr_pure_prem ",
            dbname_tp,
            "abn_ca_pa_edr",
            " iabnormal = ? AND iins_type = '48'",
            "ORDER BY iinsurant");

    $PREPARE ABN_QRY_SMT_CUR48 FROM $prep_stmt;
    $DECLARE abn_query_cur_48 CURSOR FOR ABN_QRY_SMT_CUR48;
    $OPEN abn_query_cur_48 USING $iendorse;
    for (;;)
    {
      $FETCH abn_query_cur_48 INTO : iedr_type,
          : cIinsurant,
          : cNinsurant,
          : lDbirth,
          : cIins_scope,
          : lMins_amt,
          : lMins_premium,
          : lMpure_prem_48,
          : cRelation_appl,
          : dPcommission,
          : dPagent,
          : dPdiscount,
          : lMedr_daily_pay,
          : lMedr_mr_insprem,
          : lMedr_mr_pureprem;

      if (SQLCODE != 0)
        break;

      lMins_amt = lMins_amt / 10000;
      lMedr_daily_pay /= 10000;
      strcpy(cDbirth, cm_cdate_str_100(lDbirth));

      sprintf_s(tmp_commission, sizeof tmp_commission, "%4.2f", dPcommission);
      sprintf_s(tmp_agent, sizeof tmp_agent, "%4.2f", dPagent);
      sprintf_s(tmp_discount, sizeof tmp_discount, "%4.2f", dPdiscount);

      sprintf_s(tmp_pure_prem, sizeof tmp_pure_prem, "%10.0f", lMpure_prem_48);
      strcpy(tmp_pure_prem, trim(tmp_pure_prem));

      sprintf_s(tmp_edr_pure_prem, sizeof tmp_edr_pure_prem, "%10.0f", lMedr_mr_pureprem);
      strcpy(tmp_edr_pure_prem, trim(tmp_edr_pure_prem));

      cm_buf_put("%s ", iedr_type);
      cm_buf_put("%s %s %s %s   %l %l %s  %s   %s %s %s  %l %l %s",
                 cIinsurant, cNinsurant, cDbirth, cIins_scope,
                 lMins_amt, lMins_premium, tmp_pure_prem,
                 cRelation_appl,
                 tmp_commission, tmp_agent, tmp_discount,
                 lMedr_daily_pay, lMedr_mr_insprem, tmp_edr_pure_prem);
    }
    $CLOSE abn_query_cur_48;
    $FREE abn_query_cur_48;

    cm_buf_put("%d ", count_35);

    sprintf_s(prep_stmt, sizeof prep_stmt, "SELECT %s %s %s %s FROM %s:%s WHERE %s %s",
            "iedr_type,",
            "iinsurant , ninsurant , iins_scope ,",
            "medrins_amt , medrins_prem , medrpure_prem ,",
            "pcommission , pagent, pdiscount ",
            dbname_tp,
            "abn_ca_pa_edr",
            " iabnormal = ? AND iins_type = '35'",
            "ORDER BY iinsurant");

    $PREPARE ABN_QRY_SMT_CUR35 FROM $prep_stmt;
    $DECLARE abn_query_cur_35 CURSOR FOR ABN_QRY_SMT_CUR35;
    $OPEN abn_query_cur_35 USING $iendorse;
    for (;;)
    {
      $FETCH abn_query_cur_35 INTO : iedr_type,
          : cIinsurant,
          : cNinsurant,
          : cIins_scope,
          : lMins_amt,
          : lMins_premium,
          : lMpure_prem_35,
          : dPcommission,
          : dPagent,
          : dPdiscount;

      if (SQLCODE != 0)
        break;

      lMins_amt = lMins_amt / 10000;
      strcpy(cDbirth, cm_cdate_str_100(lDbirth));

      sprintf_s(tmp_commission, sizeof tmp_commission, "%4.2f", dPcommission);
      sprintf_s(tmp_agent, sizeof tmp_agent, "%4.2f", dPagent);
      sprintf_s(tmp_discount, sizeof tmp_discount, "%4.2f", dPdiscount);

      sprintf_s(tmp_pure_prem, sizeof tmp_pure_prem, "%10.0f", lMpure_prem_35);
      strcpy(tmp_pure_prem, trim(tmp_pure_prem));

      cm_buf_put("%s ", iedr_type);
      cm_buf_put("%s %s %s  %l %l %s  %s %s %s ",
                 cIinsurant, cNinsurant, cIins_scope,
                 lMins_amt, lMins_premium, tmp_pure_prem,
                 tmp_commission, tmp_agent, tmp_discount);
    }
    $CLOSE abn_query_cur_35;
    $FREE abn_query_cur_35;

    cm_buf_put("%d %s", count_56, sIins_type);
    sprintf_s(prep_stmt, sizeof prep_stmt, "SELECT %s %s %s %s %s %s FROM %s:%s WHERE %s %s",
            "iedr_type,",
            "iinsurant , ninsurant , dbirth , iins_scope ,",
            "medrins_amt , medrins_prem , medrpure_prem ,",
            "nbeneficiary , relation_bene, ",
            "pcommission , pagent, pdiscount, ",
            "medr_daily_pay, mr_ins_prem, mr_pure_prem ,tbenef, abenef_zip, abenef,ainsurant  ",
            dbname_tp,
            "abn_ca_pa_edr",
            " iabnormal = ? AND iins_type = ? ",
            "ORDER BY iinsurant");

    $PREPARE ABN_QRY_SMT_CUR56 FROM $prep_stmt;
    $DECLARE abn_query_cur_56 CURSOR FOR ABN_QRY_SMT_CUR56;
    $OPEN abn_query_cur_56 USING $iendorse, $sIins_type;
    for (;;)
    {
      $FETCH abn_query_cur_56 INTO : iedr_type,
          : cIinsurant,
          : cNinsurant,
          : lDbirth,
          : cIins_scope,
          : lMins_amt,
          : lMins_premium,
          : lMpure_prem_56,
          : cNbeneficiary,
          : cRelation_bene,
          : dPcommission,
          : dPagent,
          : dPdiscount,
          : lMedr_daily_pay,
          : lMedr_mr_insprem,
          : lMedr_mr_pureprem,
          : s_tenef,
          : s_abenef_zip,
          : s_abenef,
          : cAinsurant;

      if (SQLCODE != 0)
        break;

      lMins_amt = lMins_amt / 10000;
      strcpy(cDbirth, cm_cdate_str_100(lDbirth));

      sprintf_s(tmp_commission, sizeof tmp_commission, "%4.2f", dPcommission);
      sprintf_s(tmp_agent, sizeof tmp_agent, "%4.2f", dPagent);
      sprintf_s(tmp_discount, sizeof tmp_discount, "%4.2f", dPdiscount);

      sprintf_s(tmp_pure_prem, sizeof tmp_pure_prem, "%10.0f", lMpure_prem_56);
      strcpy(tmp_pure_prem, trim(tmp_pure_prem));

      sprintf_s(tmp_edr_pure_prem, sizeof tmp_edr_pure_prem, "%10.0f", lMedr_mr_pureprem);
      strcpy(tmp_edr_pure_prem, trim(tmp_edr_pure_prem));

      cm_buf_put("%s ", iedr_type);
      cm_buf_put("%s %s %s %s   %l %l %s  %s %s   %s %s %s  %l %l %s %s %s %s %s",
                 cIinsurant, cNinsurant, cDbirth, cIins_scope,
                 lMins_amt, lMins_premium, tmp_pure_prem,
                 cNbeneficiary, cRelation_bene,
                 tmp_commission, tmp_agent, tmp_discount,
                 lMedr_daily_pay, lMedr_mr_insprem, tmp_edr_pure_prem, cAinsurant, s_tenef, s_abenef_zip, s_abenef);
      /* 1100104007_SC1 56�I�L��ɦW�U��ƽЦ۰ʦ^���s���D ������ */
      /* �Y���պ�/���`���AcAinsurant�|�s�� ca_pa_ply��rowid,�H�Ѩ���渹�� update ca_pa_ply */
    }
    $CLOSE abn_query_cur_56;
    $FREE abn_query_cur_56;

    strcpy(sDbname, dbname_tp);
    strcpy(sColumn, "iabnormal");
    strcpy(sTable, "abn_edr_ins_cover");
    strcpy(sTable1, "abn_edr_ins_assured");
    strcpy(sTable2, "abn_ca_edr_bound");
     
  } /* end of else */

  /* �ˮ֬O�_��S�w�O�����ˮֳ]�w�ɤ����]�w */
  sType_131[0] = '\0';
  sInumber_131[0] = '\0';
  sCheck_fedr_131[0] = '\0';
  sNote_131[0] = '\0';

  sTypeRtn_131[0] = '\0';
  sInumberRtn_131[0] = '\0';
  sCheck_fedrRtn_131[0] = '\0';
  sNoteRtn_131[0] = '\0';

  strcpy(ipolicy, trim(ipolicy));
  strcpy(icard, trim(icard));
  strcpy(itag, trim(itag));
  strcpy(iengine, rtrim(iengine));
  strcpy(iassured, trim(iassured));
  strcpy(iapplicant, trim(iapplicant));

  time(&b_tt);
  printf("before[%ld], [%s]\n", b_tt, ctime(&b_tt));

  $SELECT type, inumber, check_fedr, note INTO $sTypeRtn_131, $sInumberRtn_131, $sCheck_fedrRtn_131, $sNoteRtn_131 FROM car_spec_policy WHERE type = '1' AND inumber = $ipolicy AND iclaim = '';
  if (SQLCODE == SQLNOTFOUND)
  {
    $SELECT type, inumber, check_fedr, note INTO $sTypeRtn_131, $sInumberRtn_131, $sCheck_fedrRtn_131, $sNoteRtn_131 FROM car_spec_policy WHERE type = '2' AND inumber = $icard AND iclaim = '';
    if (SQLCODE == SQLNOTFOUND)
    {
      $SELECT type, inumber, check_fedr, note INTO $sTypeRtn_131, $sInumberRtn_131, $sCheck_fedrRtn_131, $sNoteRtn_131 FROM car_spec_policy WHERE type = '3' AND inumber = $iassured AND iclaim = '';
      if (SQLCODE == SQLNOTFOUND)
      {
        $SELECT type, inumber, check_fedr, note INTO $sTypeRtn_131, $sInumberRtn_131, $sCheck_fedrRtn_131, $sNoteRtn_131 FROM car_spec_policy WHERE type = '4' AND inumber = $itag AND iclaim = '';
        if (SQLCODE == SQLNOTFOUND)
        {
          $SELECT type, inumber, check_fedr, note INTO $sTypeRtn_131, $sInumberRtn_131, $sCheck_fedrRtn_131, $sNoteRtn_131 FROM car_spec_policy WHERE type = '5' AND inumber = $iengine AND iclaim = '';
          if (SQLCODE == SQLNOTFOUND)
          {
            if (strlen(iapplicant) != 0)
            {
              $SELECT type, inumber, check_fedr, note INTO $sTypeRtn_131, $sInumberRtn_131, $sCheck_fedrRtn_131, $sNoteRtn_131 FROM car_spec_policy WHERE type = '6' AND inumber = $iapplicant AND iclaim = '';
            }
          }
        }
      }
    }
  }

#if 0 /* �찵�k�ݯӮ�4���A�s���k�ﵽ�u��1���� */
    $DECLARE query_131_2 CURSOR FOR
      SELECT type, inumber, check_fedr, note
        INTO $sType_131, $sInumber_131, $sCheck_fedr_131, $sNote_131
        FROM car_spec_policy
       ORDER BY 1,2;
    $OPEN query_131_2;
    for(;;)
    {
        $FETCH query_131_2;
        if (SQLCODE != 0)
             break;

        strcpy(sInumber_131,   trim(sInumber_131));

        /* sType == 1:�O�渹�X */
        if (strncmp(sType_131,"1",1)==0)
        {
             if (strcmp(sInumber_131,ipolicy)==0)
             {
                  strcpy(sTypeRtn_131       , sType_131);
                  strcpy(sInumberRtn_131    , sInumber_131);
                  strcpy(sCheck_fedrRtn_131 , sCheck_fedr_131);
                  strcpy(sNoteRtn_131       , sNote_131);

                  break;
             }
        }

        /* sType == 2:�ҥd���X */
        if (strncmp(sType_131,"2",1)==0)
        {
             if (strcmp(sInumber_131,icard)==0)
             {
                  strcpy(sTypeRtn_131       , sType_131);
                  strcpy(sInumberRtn_131    , sInumber_131);
                  strcpy(sCheck_fedrRtn_131 , sCheck_fedr_131);
                  strcpy(sNoteRtn_131       , sNote_131);

                  break;
             }
        }

        /* sType == 3:������/�Τ@�s�� */
        if (strncmp(sType_131,"3",1)==0)
        {
             if (strcmp(sInumber_131,iassured)==0)
             {
                  strcpy(sTypeRtn_131       , sType_131);
                  strcpy(sInumberRtn_131    , sInumber_131);
                  strcpy(sCheck_fedrRtn_131 , sCheck_fedr_131);
                  strcpy(sNoteRtn_131       , sNote_131);

                  break;
             }
        }

        /* sType == 4:�P�Ӹ��X */
        if (strncmp(sType_131,"4",1)==0)
        {
             if (strcmp(sInumber_131,itag)==0)
             {
                  strcpy(sTypeRtn_131       , sType_131);
                  strcpy(sInumberRtn_131    , sInumber_131);
                  strcpy(sCheck_fedrRtn_131 , sCheck_fedr_131);
                  strcpy(sNoteRtn_131       , sNote_131);

                  break;
             }
        }

        /* sType == 5:�������X */
        if (strncmp(sType_131,"5",1)==0)
        {
             if (strcmp(sInumber_131,iengine)==0)
             {
                  strcpy(sTypeRtn_131       , sType_131);
                  strcpy(sInumberRtn_131    , sInumber_131);
                  strcpy(sCheck_fedrRtn_131 , sCheck_fedr_131);
                  strcpy(sNoteRtn_131       , sNote_131);

                  break;
             }
        }

        /* sType == 6:�n�O�HID */
        if (strncmp(sType_131,"6",1)==0)
        {
             if (strcmp(sInumber_131,iapplicant)==0)
             {
                  strcpy(sTypeRtn_131       , sType_131);
                  strcpy(sInumberRtn_131    , sInumber_131);
                  strcpy(sCheck_fedrRtn_131 , sCheck_fedr_131);
                  strcpy(sNoteRtn_131       , sNote_131);

                  break;
             }
        }
    }
    $CLOSE query_131_2;
    $FREE  query_131_2;

#endif

  time(&a_tt);
  printf("after[%ld],[%s]\n", a_tt, ctime(&a_tt));
  diff = difftime(a_tt, b_tt);
  printf(" diff[%f]\n", diff);

  cm_buf_put("%s %s %s %s ", sTypeRtn_131, sInumberRtn_131, sCheck_fedrRtn_131, sNoteRtn_131);

  /** ���就�έ��� car-9303312 **/
  $SELECT fedr_m, iquota, imgr INTO $fedr_m, $off_iquota, $imgr FROM officer WHERE iofficer = $iofficer;
  if (SQLCODE == SQLNOTFOUND)
  {
    strcpy(fedr_m, "Y");
    strcpy(imgr, "");
  }
  /*** car-9407193 ***/
  if (strncmp(icard + 2, "AYK", 3) == 0)
  {
    strcpy(fedr_m, "N");
  }

  cm_buf_put("%s ", fedr_m);

  /** �s���P�_�G���M����ˮ� car-9502103    dexpire_m = N ���ܤw���M**/
  $SELECT case when today >= dexpire then 'N' else 'Y' end case INTO $dexpire_m
     FROM sa_branch_type
    WHERE ibranch = $off_iquota;

  cm_buf_put("%s ", dexpire_m);
  cm_buf_put("%s ", imgr);
  cm_buf_put("%s %d %d %d %s %s %s %s %s", iext_policy, qpro_month, mkilo_ply, mkilo_edr, irisk, irelative_ext,
             ded_business, fmservice, fmaintain);

#ifdef CA_CONS

  if (estimate_type == 2)
  {
    $char	 sIcover_type[4], sIprem_cover_type[4], sCover_name[51];
    $int 	 mCover, iorder;

    sprintf_s(prep_stmt, sizeof prep_stmt, 
            "SELECT iins_type, medrinj_cover, medrdea_cover,medrdmg_cover FROM %s:%s WHERE %s AND %s ",
            dbname_tp,
            "ca_ed_quotation_ins",
            " iquote = ?  AND iedr_type <>''",
            " iins_type in ('34','87','115')");  

    $PREPARE prep34 FROM $prep_stmt;
    $EXECUTE prep34 INTO $sIins_type, $medrinj_cover, $medrdea_cover, $medrdmg_cover
       USING $iendorse;
    if (SQLCODE != SQLNOTFOUND)   
    {
      $DECLARE cur_ins_cover CURSOR FOR
        SELECT icover_type, iprem_cover_type, cover_name, iorder
          FROM insurance_cover
          WHERE iins_type = $sIins_type ORDER BY iorder;
      $OPEN cur_ins_cover;
      for(;;)
      {
        $FETCH cur_ins_cover
          INTO $sIcover_type, $sIprem_cover_type, $sCover_name, $iorder;
        if (SQLCODE == SQLNOTFOUND)
        {
          break;
          /*$CLOSE cur_ins_cover;
          $FREE cur_ins_cover;  
          $FREE prep34;
          return M_CA_PREM_COVER_TYPE_ERR;
          */
        }

        if (iorder == 1)
          mCover = medrinj_cover;
        else if (iorder == 2)
          mCover = medrinj_cover*2;
        else if (iorder == 3)
          mCover = medrdea_cover;
        else
          mCover = medrdmg_cover;

        strcpy(sCover_name, trim(sCover_name));
        printf("icover_type[%s],mCover[%d]\n", sIcover_type, mCover);

        cm_buf_put("%s ", sIins_type);
        cm_buf_put("%s ", sCover_name);
        cm_buf_put("%l ", mCover);
        cm_buf_put("%l ", 0);
        cm_buf_put("%l ", 0);
        cm_buf_put("%e ", 0.0);
        cm_buf_put("%s ", sIcover_type);
        cm_buf_put("%s ", sIprem_cover_type);
      }
      $CLOSE cur_ins_cover;
      $FREE cur_ins_cover;  
    }
    $FREE prep34; 
  }
  else
  {

    IfirstPlyInsCover = get_ply_ins_cover(sDbname, sTable, sColumn, iendorse, &rtncode, v_sMsg);

    if (rtncode != M_CM_OK)
    {
      if (exitsub(reply, rtncode) == True)
        return rtncode;
      else
        return apiRC;
    }

    puts("put edr_ins_cover���");

    IcurrPlyInsCover = IfirstPlyInsCover;
    while (IcurrPlyInsCover)
    {
      cm_buf_put("%s ", IcurrPlyInsCover->iins_type);
      cm_buf_put("%s ", IcurrPlyInsCover->cover_name);
      cm_buf_put("%l ", IcurrPlyInsCover->mcover);
      cm_buf_put("%l ", IcurrPlyInsCover->mcover_prem);
      cm_buf_put("%l ", IcurrPlyInsCover->mprem);
      cm_buf_put("%e ", IcurrPlyInsCover->mpure_prem);
      cm_buf_put("%s ", IcurrPlyInsCover->icover_type);
      cm_buf_put("%s ", IcurrPlyInsCover->iprem_cover_type);

      printf("IcurrPlyInsCover->iins_type    [%s]\n"
            "IcurrPlyInsCover->cover_name   [%s]\n"
            "IcurrPlyInsCover->icover_type  [%s]\n"
            "IcurrPlyInsCover->iprem_cover_type  [%s]\n"
            "IcurrPlyInsCover->mcover       [%d]\n"
            "IcurrPlyInsCover->mcover_prem  [%d]\n"
            "IcurrPlyInsCover->mprem        [%d]\n"
            "IcurrPlyInsCover->mpure_prem   [%f]\n"
            "IcurrPlyInsCover->pextra_charge[%f]\n",
            IcurrPlyInsCover->iins_type,
            IcurrPlyInsCover->cover_name,
            IcurrPlyInsCover->icover_type,
            IcurrPlyInsCover->iprem_cover_type,
            IcurrPlyInsCover->mcover,
            IcurrPlyInsCover->mcover_prem,
            IcurrPlyInsCover->mprem,
            IcurrPlyInsCover->mpure_prem,
            IcurrPlyInsCover->pextra_charge);
      puts("");
      IcurrPlyInsCover = IcurrPlyInsCover->next;
    }
  }

  cm_buf_put("%s", "IcurrPlyInsCoverEnd");

#endif

#ifdef CA_ONE

  if (estimate_type == 2)
  {
    $char	 sProvision[7], sIassured[IASSURED], sNassured[NASSURED], sDdbirth[DATE], sNbenef[NBENEF], 
           sRel_benef[REL_BENEF], sTbenef[21], sAbenef_zip[CA_ZIP], sAbenef[91];
    $long 	lIserial;    
    $DECLARE cur_ins_assured CURSOR FOR
     SELECT 
            CASE WHEN b.iins_type = 'D' OR b.iins_type = 'J' THEN ' ' ELSE b.iins_type END,             
            CASE WHEN b.iins_type = 'D' THEN 'D' WHEN b.iins_type = 'J' THEN 'J' ELSE ' ' END, 
            a.iassured, a.nassured[1,30], a.dbirth, 
            a.nbenef[1,30], a.rel_benef, a.tbenef, a.abenef_zip, a.abenef, 0 
       FROM newa00:ca_ed_quotation_assured a, newa00:ca_ed_quotation_assured_dtl b 
      WHERE a.iquote   = b.iquote 
        AND a.iassured = b.iassured 
        AND b.iins_type in ('50','80','D','J','147','561')
      /*  AND b.iedr_type <> ''*/
        AND a.iquote   = $iendorse;
    $OPEN cur_ins_assured;
    for(;;)
    {
      $FETCH cur_ins_assured
        INTO $sIins_type, $sProvision, $sIassured, $sNassured, $sDdbirth, $sNbenef, 
             $sRel_benef, $sTbenef, $sAbenef_zip, $sAbenef, $lIserial;
      if (SQLCODE == SQLNOTFOUND) break;

      printf(" sIins_type[%s]\n", sIins_type);
      printf(" sIassured [%s]\n", sIassured);
      printf(" sTbenef   [%s]\n", sTbenef);
      cm_buf_put("%s ", sIins_type);
      cm_buf_put("%s ", sProvision);
      cm_buf_put("%s ", sIassured);
      cm_buf_put("%s ", sNassured);
      cm_buf_put("%s ", sDdbirth);
      cm_buf_put("%s ", sNbenef);
      cm_buf_put("%s ", sRel_benef);
      cm_buf_put("%s ", sTbenef);
      cm_buf_put("%s ", sAbenef_zip);
      cm_buf_put("%s ", sAbenef);
      cm_buf_put("%l ", lIserial);
    }
    $CLOSE cur_ins_assured;
    $FREE cur_ins_assured;          
  }
  else
  {
    IfirstPlyInsAssured = get_ply_ins_assured(sDbname, sTable1, sColumn, iendorse, &rtncode, v_sMsg);

    if (rtncode != M_CM_OK)
    {
      if (exitsub(reply, rtncode) == True)
        return rtncode;
      else
        return apiRC;
    }

    puts("put edr_ins_assured���");

    IcurrPlyInsAssured = IfirstPlyInsAssured;
    while (IcurrPlyInsAssured)
    {
      cm_buf_put("%s ", IcurrPlyInsAssured->iins_type);
      cm_buf_put("%s ", IcurrPlyInsAssured->provision);
      cm_buf_put("%s ", IcurrPlyInsAssured->iassured);
      cm_buf_put("%s ", IcurrPlyInsAssured->nassured);
      cm_buf_put("%s ", IcurrPlyInsAssured->dbirth);
      cm_buf_put("%s ", IcurrPlyInsAssured->nbenef);
      cm_buf_put("%s ", IcurrPlyInsAssured->rel_benef);
      cm_buf_put("%s ", IcurrPlyInsAssured->tbenef); /*1110310005_SC2 �s�W147�Q�O�H�W�U*/
      cm_buf_put("%s ", IcurrPlyInsAssured->abenef_zip);
      cm_buf_put("%s ", IcurrPlyInsAssured->abenef);
      cm_buf_put("%l ", IcurrPlyInsAssured->iserial);

      printf("IcurrPlyInsAssured->iins_type    [%s]\n"
            "IcurrPlyInsAssured->provision    [%s]\n"
            "IcurrPlyInsAssured->iassured     [%s]\n"
            "IcurrPlyInsAssured->nassured     [%s]\n"
            "IcurrPlyInsAssured->dbirth       [%s]\n"
            "IcurrPlyInsAssured->nbenef       [%s]\n"
            "IcurrPlyInsAssured->rel_benef    [%s]\n"
            "IcurrPlyInsAssured->tbenef       [%s]\n"
            "IcurrPlyInsAssured->abenef_zip   [%s]\n"
            "IcurrPlyInsAssured->abenef       [%s]\n"
            "IcurrPlyInsAssured->iserial      [%d]\n",
            IcurrPlyInsAssured->iins_type,
            IcurrPlyInsAssured->provision,
            IcurrPlyInsAssured->iassured,
            IcurrPlyInsAssured->nassured,
            IcurrPlyInsAssured->dbirth,
            IcurrPlyInsAssured->nbenef,
            IcurrPlyInsAssured->rel_benef,
            IcurrPlyInsAssured->tbenef,
            IcurrPlyInsAssured->abenef_zip,
            IcurrPlyInsAssured->abenef,
            IcurrPlyInsAssured->iserial);
      puts("");
      IcurrPlyInsAssured = IcurrPlyInsAssured->next;
    }
  } 

  cm_buf_put("%s", "IcurrPlyInsAssuredEnd");

#endif

  if (estimate_type == 2)
  {
    $char	 sIbound[4];
    strcpy(sIbound, " "); strcpy(ibound, "");
    $DECLARE cur_bound CURSOR FOR
     SELECT ibound 
       FROM newa00:ca_bound_dtl
      WHERE ibound_num = $bound_num;
    $OPEN cur_bound;
    for(;;)
    {
      $FETCH cur_bound INTO $sIbound;
      if (SQLCODE == SQLNOTFOUND) break;

      if (strlen(trim(sIbound))>0 )
      {
        strcat(ibound, sIbound);
        strcat(ibound, ",");
      }
    }
    $CLOSE cur_bound;
    $FREE cur_bound;

    if (strlen(trim(ibound))>0 )
    {
       strcpy(ibound, trim(ibound));
       ibound[strlen(ibound)-1] = '\0';
    }
  }
  else{
    /* car9903041 ���s�t�λP���O�B�ɨ�����s�� */
    rtncode = get_ca_ply_bound(sDbname, sTable2, sColumn, iendorse, ibound, v_sMsg);
    if (rtncode != M_CM_OK)
    {
      if (exitsub(reply, rtncode) == True)
        return rtncode;
      else
        return apiRC;
    }
  }

  cm_buf_put("%s", napplicant);
  strcpy(date1, cm_cdate_str_100(dbirth));
  strcpy(date2, cm_cdate_str_100(dissue));
  cm_buf_put("%s %s", date1, date2);
  cm_buf_put("%s %d %e", iextra_charge, gextra_charge, pextra_charge);
  cm_buf_put("%s %s %e", iquery_num_damage, iquery_num, mequipment);
  cm_buf_put("%s %s %s %s %d", survey_num, bound_num, abnormal_num, iapplicant, mcancel);

  /* car9707103 �ѩ�n�P�_�j���I�O�_�O����J,�G�ݭn�ǤJ�O��ñ���H�T�{ */
  cm_buf_put("%s", cm_cdate_str_100(dpolicy));

  /* car9903041 ���s�t�λP���O�B�ɨ�����s�� */
  cm_buf_put("%s", ibound);

  /* 1000728003_C2 �ĤT�H�d���I���ŧאּ5��(���) */
  cm_buf_put("%l %l", qlia_acc_sum, qdmg_acc_sum);

  cm_buf_put("%e %l", mbusiness, mservice);

  cm_buf_put("%s %s %s %s %s %s %s %s %d", fapplicant, fsex_appl, dbirth_appl, itel_appl, ndeputy_appl, nrelation_appl, ndeputy_assured, dcreate, qdrunk_driving);

  cm_buf_put("%s %s", isign, dcreate_ply);
  cm_buf_put("%s %d", iins_kit, mcover_limit);
  cm_buf_put("%s %s", iassured_cntry, iapplicant_cntry);
  cm_buf_put("%s ", fcharge_type);
  cm_buf_put("%s %s %s %s %s %s %s %s", fequipment1, fequipment2, fequipment3, fequipment4, fequipment5, fequipment6, fequipment9, nequipment9);
  cm_buf_put("%s %s", fedr_print, fply_print);
  cm_buf_put("%s ", dentry);
  cm_buf_put("%e %s %l", punknown_acc, iquery_num_unknown, qunknown_acc_sum);
  cm_buf_put("%s %s %s", feply, feedr, aemail_eply);
  cm_buf_put("%s %s", nassured_cntry, napplicant_cntry);
  cm_buf_put("%s", ireverse_num);

  $select max(dcreate)
     into $dcreate_max
     from edr_relation
    where ipolicy = $ipolicy and iendorse not like '%CVP%';

  cm_buf_put("%s ", dcreate_max);

  cm_buf_put("%s %s %s %s", foccup, noccup, applicant_foccup, applicant_noccup);
  cm_buf_put("%s %s %s ", iowner, nowner, dbirth_owner);
  cm_buf_put("%s ", iref_num1);
  cm_buf_put("%s %s ", tmobile_appl, aemail_appl);
  cm_buf_put("%s %s ", dtedr_begin, dtedr_end);
  cm_buf_put("%s %s ", dtply_begin, dtply_end);
  cm_buf_put("%s ", iroute_accept);
  cm_buf_put("%s ", iroute_accept_edr);
  cm_buf_put("%s ", tmobile_eply); /* 1080417001_SC2 �s�W�q�l�O��H²�T�覡�o�e */
  cm_buf_put("%s ", ireg_no);      /* 1080408005_SC2 �j��{�ҷs�W�q����Ƥεn���Ҹ� */
  cm_buf_put("%s ", iscan_no_edr); /* 1080730005_SC2 �q�lñ�p���ظm�@�~*/

  /*1091021005_SC2�s�W�A�Ȥ��ߩ�����*/
  cm_buf_put("%d %s %s %s ", fsign_status_edr, funder_chk_edr, isign_edr, dsign_edr);

  cm_buf_put("%s ", feterms);  /* 1100419003_SC2 ���I�O�����QR Code�q�l��*/
  cm_buf_put("%d ", qviolate); /*1110608012_SC2 �s�W�j��I�O�v�ǤJ���j�H�W�[�O���*/
  cm_buf_put("%s ", iquote);   /* 1110607001_SC1 �ظmE�O�����t�� */


  /* 1120927002_C02 �R�q�ΰӫ~�}�o */
  strcpy(date2, cm_cdate_str_100(dinstall));
  cm_buf_put("%s ", date2);  
  cm_buf_put("%s ", isequence);
  cm_buf_put("%s ", ainstall_zip);
  cm_buf_put("%s ", ainstall);

  { /* SELECT CREDIT CARD & WITHDRAW DATA */
    long iRtnCode;
    $char sTmpPolicy1[POLICY_NUM_1], sTmpPolicy2[POLICY_NUM_2];

    iRtnCode = split_policy(ipolicy, sTmpPolicy1, sTmpPolicy2);
    if (iRtnCode != M_CM_OK)
    {
      if (exitsub(reply, M_CA_NLENGTH) == True)
        return M_CA_NLENGTH;
      else
        return apiRC;
    }

    iRtnCode = cm_credit_pay_select_car(sTmpPolicy1, sTmpPolicy2, iendorse);
    if (iRtnCode != M_CM_OK)
    {
      if (exitsub(reply, iRtnCode) == True)
        return iRtnCode;
      else
        return apiRC;
    }
  }

  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  printf("SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
} /* car401_single_query */

/****************************************************************************/
/****************************************************************************/
long car401_multiple_query1(reply)
serverReply reply;
{
  /* standard defined host variables */
  $char DBName[5];
  /* end of standard host var */

  /* table edr_relation */
  $char ipolicy[POLICY_NUM_1], iendorse[ENDORSE_NUM];
  $char tmpiendorse[ENDORSE_NUM];
  /* end of edr_relation */

  /* standard defined data */
  char tmpbuf[4000];
  int count = 0, repbuf_len = 0, tmp_len = 0, replycnt = 0;
  int i, total_count = 0;
  /* end of standard data */

  cm_buf_get("%s", DBName);
  cm_buf_get("%s", tmpiendorse);

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
    if (exitsub(reply, M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }

  $DECLARE mutiple_query CURSOR FOR
      SELECT iendorse,
      ipolicy
          FROM edr_relation
              WHERE iendorse MATCHES $tmpiendorse
                  AND dedr_close IS NULL
                      AND fedr_class<> 'A' AND fedr_class<> 'B' ORDER BY ipolicy,
      iendorse;

  $OPEN mutiple_query;
  count = 0;
  for (;;)
  {
    $FETCH mutiple_query
        INTO $iendorse,
        $ipolicy;

    if (SQLCODE != 0)
      break;

    cm_buf_init(tmpbuf);
    if (count == 0)
    {
      cm_buf_res_msg(); /* reserve for MsgCode and count */
      cm_buf_res_count();
    }
    cm_buf_put("%s %s", iendorse, ipolicy);

    tmp_len = cm_buf_len(tmpbuf);

    if (tmp_len + repbuf_len < 3000)
    { /* buffer size less than 4K */
      memcpy(&ReplyBuf[repbuf_len], tmpbuf, tmp_len);
      repbuf_len += tmp_len;
      count++;
    }
    else /* more than 4K, send to client side */
    {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply, ReplyBuf, repbuf_len, api_OK) == False)
      {
        $CLOSE mutiple_query;
        $FREE mutiple_query;
        return apiRC;
      }
      else /* clear ReplyBuf and count to start all over again */
      {
        replycnt++;
        if (replycnt == 10) /* more than 30K, client cannot display,error */
        {
          cm_buf_init(ReplyBuf);
          cm_buf_put("%l", M_CM_OUT_SPACE);
          tmp_len = cm_buf_len(ReplyBuf);
          if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
            return apiRC;
          return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg(); /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s", iendorse, ipolicy);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
      }
    }
  } /* for loop */

  $CLOSE mutiple_query;
  $FREE mutiple_query;
  if (count > 0)
  { /* break out, at least one record is selected */
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply, ReplyBuf, repbuf_len, api_OKComplete) == False)
      return apiRC;
    return api_OKComplete;
  }
  else
  { /* break out, not any row is found */
    if (exitsub(reply, M_CA_NENDORSE) == True)
      return M_CA_NENDORSE;
    else
      return apiRC;
  }

errexit:
  printf("{car401_multiple_query1}:SQLCODE:[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
} /* car401_multiple_query1 */

/****************************************************************************/
/****************************************************************************/
long car401_multiple_query2(reply)
serverReply reply;
{
  $char DBName[5];

  /* table abn_edr_relation */
  $char ipolicy[POLICY_NUM_1], iabnormal[21];
  $char tmpiabnormal[21];
  /* end of abn_edr_relation */

  /* standard defined data */
  char tmpbuf[4000];
  int count = 0, repbuf_len = 0, tmp_len = 0, replycnt = 0;
  int i, total_count = 0;
  /* end of standard data */

  char dbname_tp[21];

  cm_buf_get("%s", DBName);
  cm_buf_get("%s", tmpiabnormal);

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
    if (exitsub(reply, M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }

  strcpy(dbname_tp, get_full_dbname("00")); /* get TP's full DB name */

  sprintf_s(prep_stmt, sizeof prep_stmt, "SELECT iabnormal,ipolicy FROM %s:%s %s %s %s",
          dbname_tp,
          "abn_edr_relation",
          "WHERE iabnormal MATCHES ? ",
          "  AND (iendorse IS NULL ",
          "   OR  iendorse =' ')");
  $PREPARE STMT_CUR4 FROM $prep_stmt;
  $DECLARE mutiple_query2 CURSOR FOR STMT_CUR4;
  $OPEN mutiple_query2 USING $tmpiabnormal;
  count = 0;
  for (;;)
  {
    $FETCH mutiple_query2 INTO $iabnormal, $ipolicy;
    if (SQLCODE != 0)
      break;

    cm_buf_init(tmpbuf);
    if (count == 0)
    {
      cm_buf_res_msg(); /* reserve for MsgCode and count */
      cm_buf_res_count();
    }
    cm_buf_put("%s %s", iabnormal, ipolicy);
    tmp_len = cm_buf_len(tmpbuf);
    if (tmp_len + repbuf_len < 3000)
    { /* buffer size less than 4K */
      memcpy(&ReplyBuf[repbuf_len], tmpbuf, tmp_len);
      repbuf_len += tmp_len;
      count++;
    }
    else
    /* more than 4K, send to client side */
    {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply, ReplyBuf, repbuf_len, api_OK) == False)
      {
        $CLOSE mutiple_query2;
        $FREE mutiple_query2;
        return apiRC;
      }
      else
      /* clear ReplyBuf and count to start all over again */
      {
        replycnt++;
        if (replycnt == 10) /* more than 30K, client cannot display,error */
        {
          cm_buf_init(ReplyBuf);
          cm_buf_put("%l", M_CM_OUT_SPACE);
          tmp_len = cm_buf_len(ReplyBuf);
          if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
            return apiRC;
          return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg(); /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s", iabnormal, ipolicy);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
      }
    }
  } /* for loop */

  $CLOSE mutiple_query2;
  $FREE mutiple_query2;
  if (count > 0)
  { /* break out, at least one record is selected */
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply, ReplyBuf, repbuf_len, api_OKComplete) == False)
      return apiRC;
    return api_OKComplete;
  }
  else
  { /* break out, not any row is found */
    if (exitsub(reply, M_CA_NENDORSE) == True)
      return M_CA_NENDORSE;
    else
      return apiRC;
  }

errexit:
  printf("{car401_multiple_query2}: SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
} /* car401_multiple_query2 */

/****************************************************************************/
/***************************************************************************/
/***************************************************************************/
long car401_single_query_note(reply)
serverReply reply;
{
  EXEC SQL char DBName[5];
  EXEC SQL char iendorse[4];

  int tmp_len;

  /** endorsement_note **/
  EXEC SQL char note1[81], note2[81], note3[81];

  cm_buf_get("%s", DBName);
  cm_buf_get("%s", iendorse);

  EXEC SQL WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
    if (exitsub(reply, M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }

  EXEC SQL SELECT note1, note2, note3 INTO : note1, : note2, : note3 FROM endorsement_note WHERE iendorse = : iendorse;
  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CM_NOT_FOUND) == True)
      return M_CM_NOT_FOUND;
    else
      return apiRC;
  }

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s %s %s",
             M_CM_OK, note1, note2, note3);

  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  printf("SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
} /* car401_single_query_note */

/***************************************************************************/
long car401_old_rule(reply)
serverReply reply;
{
  $char DBName[5];
  $char ipolicy[21], ilast_ply[21], dply_begin[21], iengine[CA_ENGINE_NUM];
  char sIupcompShort[2], policyDB[21], policyDBname[41];
  char last_policyDB[21], last_policyDBname[41];
  $char stmt[4096];
  $int iCount;
  $char fOldRule[2];

  int tmp_len;

  cm_buf_get("%s", DBName);
  cm_buf_get("%s", ilast_ply);
  cm_buf_get("%s", ipolicy);
  cm_buf_get("%s", iengine);
  cm_buf_get("%s", dply_begin);

  EXEC SQL WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
    if (exitsub(reply, M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }

  sIupcompShort[0] = ilast_ply[2]; /* �O�渹�ĤT�X */
  sIupcompShort[1] = '\0';
  strcpy(last_policyDB, get_upcomp(sIupcompShort, USE_SHORT_BRANCH_ID, USE_BRANCH_ID));
  strcpy(last_policyDBname, get_full_dbname(last_policyDB));

  sprintf_s(stmt, sizeof stmt, "SELECT count(*) "
                "  FROM %s:ply_relation a, %s:ply_ins_type b, %s:policy c "
                "  WHERE a.ipolicy = b.ipolicy AND a.ipolicy = c.ipolicy  "
                "  AND a.ipolicy = ?  "
                "  AND b.iins_type IN ('85','105','118') "
                "  AND EXISTS (SELECT 1 from ca_rate_date WHERE itable = 'ca_rate'  AND icode = b.drate_ym AND drate < date('04/15/2016'))"
                "  AND c.iengine = ?  "
                "  AND date('%s')-a.dply_end <= 92 ",
          last_policyDBname, last_policyDBname, last_policyDBname, dply_begin);
  printf("stmt[%s]\n", stmt);
  printf("ilast_ply[%s], ipolicy[%s], iengine[%s], dply_begin[%s]\n", ilast_ply, ipolicy, iengine, dply_begin);
  $PREPARE prep1 FROM $stmt;
  $EXECUTE prep1 INTO $iCount USING $ilast_ply, $iengine;
  $FREE prep1;

  if (iCount != 0)
    strcpy(fOldRule, "Y");
  else
    strcpy(fOldRule, "N");

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s ", M_CM_OK, fOldRule);

  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  printf("SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
} /* car401_old_rule */

/***************************************************************************/
long ca401_P(reply)
serverReply reply;
{
  $char DBName[5];
  $char iendorse[21], dcreate[31], fcard_class[2], iassured[IASSURED], iroute[21], ipolicy[21];
  $char spaydate[11], ftype_pol[3], itag[CA_TAG_NUM], iengine[CA_ENGINE_NUM], ftype_sp[3];
  $int iCount;
  $long medr_prem;
  $char paydate[11];

  int tmp_len;

  cm_buf_get("%s", DBName);
  cm_buf_get("%s", iendorse);
  cm_buf_get("%s", dcreate);

  EXEC SQL WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
    if (exitsub(reply, M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }

  $SELECT fcard_class, iassured, iroute, ipolicy, medrlia_prem + medrdmg_prem, itag, iengine INTO $fcard_class, $iassured, $iroute, $ipolicy, $medr_prem, $itag, $iengine FROM edr_relation a, endorsement b WHERE a.iendorse = b.iendorse AND a.iendorse = $iendorse AND dcreate = $dcreate;

  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CA_NENDORSE) == True)
      return M_CA_NENDORSE;
    else
      return apiRC;
  }

  $select count(*)
      into $iCount
          from edr_relation a,
      edr_ins_type b
          where a.iendorse = b.iendorse
                                 and a.iendorse = $iendorse and iins_type in('85', '105', '106', '107', '108', '118', '120', '122', '119', '121', '123', '125', '126', '127', '96', '97', '112')
                                                                    and iedr_type = '05' and dedr_begin >= '02/01/2017';
  if (iCount != 0)
    strcpy(paydate, "01/31/2017");
  else
    strcpy(paydate, "");

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s %s %d %s", M_CM_OK, iendorse, fcard_class, medr_prem, paydate);

  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  printf("SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
} /* ca401_P */
/***************************************************************************/

double d45(num, num1)
double num;
int num1;
{
  long tmplong;
  double var1;
  double ten;
  int i;

  ten = 1;
  for (i = 1; i <= num1; i++)
    ten *= 10;

  num *= ten;
  if (num >= 0)
    var1 = 0.5;
  else
    var1 = (-0.5);

  num = num + var1;
  tmplong = num;

  num = tmplong / ten;
  return (num);
}
long ca401_G(reply)
serverReply reply;
{
  $char DBName[5];
  int freason;
  char message[101], nassured[121], ilicense[11], iengine[CA_ENGINE_NUM], ibody[CA_BODY_NUM], itag[CA_TAG_NUM];

  int tmp_len;

  cm_buf_get("%s", DBName);
  cm_buf_get("%s", nassured);
  cm_buf_get("%s", ilicense);
  cm_buf_get("%s", iengine);
  cm_buf_get("%s", ibody);
  cm_buf_get("%s", itag);

  EXEC SQL WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
    if (exitsub(reply, M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }

  strcpy(message, "");

  freason = Check_reject_client(nassured, ilicense, iengine, ibody, itag);

  if (freason == 1)
  {
    strcpy(message, "�Ȥᱱ��(car102)�]�w:�r�p�ߺD�ά������}�Ȥ�");
  }
  if (freason == 2)
  {
    strcpy(message, "�Ȥᱱ��(car102)�]�w:���Ѩ�");
  }
  if (freason == 3)
  {
    strcpy(message, "�Ȥᱱ��(car102)�]�w:���l��");
  }
  if (freason == 4)
  {
    strcpy(message, "�Ȥᱱ��(car102)�]�w:�w����");
  }
  if (freason == 5)
  {
    strcpy(message, "�Ȥᱱ��(car102)�]�w:�z�ߴ���");
  }
  if (freason == 6)
  {
    strcpy(message, "�Ȥᱱ��(car102)�]�w:�ƬG���O");
  }
  if (freason == 7)
  {
    strcpy(message, "�Ȥᱱ��(car102)�]�w:�æ��D�w���I�Ȥ�");
  }

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s ", M_CM_OK, message);

  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  printf("ca401_G,SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
} /* ca401_G */
/***************************************************************************/
long ca401_chk_reverse_num(reply)
serverReply reply;
{
  $char DBName[5];
  $long iCount;
  $char message[101], ireverse_num[21], ipolicy[21];
  $char fedr_class[2], dcreate[31];

  int tmp_len;

  cm_buf_get("%s", DBName);
  cm_buf_get("%s %s", ireverse_num, ipolicy);

  EXEC SQL WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
    if (exitsub(reply, M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }
  /* �ˮ֥u�i�ɥ��̫�@�i���A
     �̫�@�i���Y�����P�B�h���h�O�B�L��(�����ʫO�O)�B
     �@����B�g����B�������B��z�覡�ܧ���A�h���i�ɥ�  */

  strcpy(message, "");

  $select fedr_class, dcreate into $fedr_class, $dcreate from edr_relation where ipolicy = $ipolicy and iendorse = $ireverse_num and iendorse not like '%CVP%';

  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CM_NOT_FOUND) == True)
      return M_CM_NOT_FOUND;
    else
      return apiRC;
  }

  if (fedr_class[0] != '6' && fedr_class[0] != '8' && fedr_class[0] != '9')
  {
    strcat(message, "���B���B�L��(���ʫO�O)�B������A�~�i�ɥ�;");
  }

  $select count(*)
      into $iCount
          from edr_relation
              where ipolicy = $ipolicy and iendorse not like '%CVP%' and (medrlia_prem != 0 or medrdmg_prem != 0) and dcreate > $dcreate;

  if (iCount != 0)
  {
    strcat(message, "\n");
    strcat(message, "�̫�@�i�O�O���ʧ��~�i�H�ɥ�");
  }

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s %s", M_CM_OK, message, fedr_class);

  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  printf("ca401_chk_reverse_num,SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
} /* ca401_chk_reverse_num */
/***************************************************************************/
long ca401_get_rel_data(reply)
serverReply reply;
{
  $char DBName[5];
  $long iCount;
  $char message[101], irelative_ply[21], icar_type[3];
  char sIupcompShort[2], policyDB[21], policyDBname[41];
  $char stmt[512];

  int tmp_len;

  cm_buf_get("%s", DBName);
  cm_buf_get("%s ", irelative_ply);

  EXEC SQL WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
    if (exitsub(reply, M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }

  strcpy(message, "");

  sIupcompShort[0] = irelative_ply[2]; /* �O�渹�ĤT�X */
  sIupcompShort[1] = '\0';
  strcpy(policyDB, get_upcomp(sIupcompShort, USE_SHORT_BRANCH_ID, USE_BRANCH_ID));
  strcpy(policyDBname, get_full_dbname(policyDB));

  sprintf_s(stmt, sizeof stmt, " select icar_type "
                "   from %s:ply_relation"
                "  where ipolicy = '%s' ",
          policyDBname, irelative_ply);

  $prepare prep2 from $stmt;
  $execute prep2 into $icar_type;

  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CM_NOT_FOUND) == True)
      return M_CM_NOT_FOUND;
    else
      return apiRC;
  }

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s ", M_CM_OK, icar_type);

  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  printf("ca401_get_rel_data,SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
} /* ca401_get_rel_data */
/***************************************************************************/
long ca401_GetDmgCoverEdr(reply)
serverReply reply;
{
  $char DBName[5];
  $long iCount;
  $char message[101], issue_ymd[12], ply_begin[11], iins_type[7];
  $char stmt[512];
  long issue_date;
  $long plybgn_date, plybgn_date_next_year, count_x = 0;
  $int age, month, year;
  double year_dept;
  $double mcar_price, year_rate;
  $char icar_type[3], irate_class[2];
  $char tmpfcar_class[2], provision[21], ym_icode[5];
  $double tmp_pdepreciate;
  $double car_pricep;
  long cover_01, cover_01_tmp, thousand_cover_01;

  int tmp_len;

  cm_buf_get("%s", DBName);
  cm_buf_get("%s ", issue_ymd); /* cyy/mm/01��client�M�w�ǤJ�o�Ӧ~�� �� �s�y�~�� */
  cm_buf_get("%s ", ply_begin); /* cyy/mm/01 */
  cm_buf_get("%s ", iins_type);
  cm_buf_get("%s ", icar_type);
  cm_buf_get("%s ", provision);
  cm_buf_get("%s ", ym_icode);
  cm_buf_get("%e ", &car_pricep);

  EXEC SQL WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
    if (exitsub(reply, M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }

  strcpy(message, "");

  issue_date = cm_ymd_cdate(issue_ymd);
  plybgn_date = cm_ymd_cdate(ply_begin);

  if (strcmp(trim(iins_type), "20") == 0 || strcmp(trim(iins_type), "86") == 0 ||
      strcmp(trim(iins_type), "23") == 0 || strcmp(trim(iins_type), "28") == 0 ||
      strcmp(trim(iins_type), "111") == 0 || strcmp(trim(iins_type), "128") == 0) /* 20,23,86�I�ئh��@�~ */
  {
    $select first 1(date_add($plybgn_date, interval(1) year to year))
        into $plybgn_date_next_year
            from systables;

    age = DiffMonth(plybgn_date_next_year, issue_date);
  }
  else
    age = DiffMonth(plybgn_date, issue_date);

  $SELECT fcar_class, case when icar_grp = '1' then '3' else fcar_class end INTO $tmpfcar_class, $irate_class FROM car_type WHERE fclass = '1' AND icode = $icar_type;
  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CA_NCARTYPE) == True)
      return M_CA_NCARTYPE;
    else
      return apiRC;
  }

  /* 1081225006_SC3 �X�R���[���ڥN�X */
  /*
  if ( strstr( provision, "Z") )
      strcpy( irate_class, "4");
  else if(strstr( provision, "P"))
      strcpy( irate_class, "6");
  else if(strstr( provision, "Q"))
      strcpy( irate_class, "7");
  else if(strstr( provision, "M"))
      strcpy( irate_class, "8");
 */
  if (IsProvExist("Z", provision) == TRUE)
    strcpy(irate_class, "4");
  else if (IsProvExist("P", provision) == TRUE)
    strcpy(irate_class, "6");
  else if (IsProvExist("Q", provision) == TRUE)
    strcpy(irate_class, "7");
  else if (IsProvExist("M", provision) == TRUE)
    strcpy(irate_class, "8");

  year = age / 12;
  month = age - (age / 12) * 12;
  year_dept = 1;

  /* �~���� year_rate*/
  $SELECT(100 - MAX(pdepreciate)) / 100, COUNT(*) INTO $year_rate, $count_x FROM depreciation_rate WHERE fcar_class = $irate_class AND qperiod_end = 12 AND drate = (SELECT drate FROM ca_rate_date WHERE icode = $ym_icode AND itable = 'depreciation_rate');
  if (count_x == 0)
  {
    if (exitsub(reply, M_CA_NDEPRE_RATE) == True)
      return M_CA_NDEPRE_RATE;
    else
      return apiRC;
  }

  year_dept = MyPower(year_rate, year);

  printf("{step8.0030}: year[%d],month[%d],year_dept[%f],fcar_class[%s],irate_class[%s]\n",
         year, month, year_dept, tmpfcar_class, irate_class);

  /* ����� */
  if (month == 0)
  {
    tmp_pdepreciate = 0;
  }
  else
  {
    $SELECT MAX(pdepreciate), COUNT(*) INTO $tmp_pdepreciate, $count_x FROM depreciation_rate WHERE fcar_class = $irate_class AND qperiod_bgn < $month AND qperiod_end >= $month AND drate = (SELECT drate FROM ca_rate_date WHERE icode = $ym_icode AND itable = 'depreciation_rate');
    if (count_x == 0)
    {
      if (exitsub(reply, M_CA_NDEPRE_RATE) == True)
        return M_CA_NDEPRE_RATE;
      else
        return apiRC;
    }
  }
  printf("car_pricep[%f],year_dept[%f],tmp_pdepreciate[%f]\n", car_pricep, year_dept, tmp_pdepreciate);
  cover_01_tmp = (long)floor(car_pricep * 10000.0 * year_dept * (1.0 - tmp_pdepreciate / 100.0) + 0.000000001);
  printf("-- trace cover_01_tmp[%ld]\n ", cover_01_tmp);
  thousand_cover_01 = cover_01_tmp % 1000;
  if (thousand_cover_01 != 0)
  {
    cover_01 = (cover_01_tmp) - (thousand_cover_01);
  }
  else
  {
    cover_01 = cover_01_tmp;
  }

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %l ", M_CM_OK, cover_01);

  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  printf("ca401_GetDmgCoverEdr,SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
} /* ca401_GetDmgCoverEdr */
/***************************************************************************/
long ca401_get_policy(reply)
serverReply reply;
{
  $char DBName[5];
  $long iCount;
  $char message[101], iPlyEdr[21], icar_type[3];
  char sIupcompShort[2], policyDB[21], policyDBname[41],fType[2]=" ";
  $char stmt[1024];
  /*$char nassured[121],napplicant[121],iassured[IASSURED],iapplicant[IASSURED],s_dbirth[11],s_dbirth_appl[11];*/
  $char nassured[121], itel[21], itel_night[21], mobil_phone[21], aassured_zip[CA_ZIP], aassured[100], iemail[51], dbirth[11];
  $char iassured[IASSURED], fassured[2], ndeputy_assured[51], ilicense[11], fsex[2], fmarriage[2], iassured_cntry[2], nassured_cntry[51], foccup[2], noccup[6];
  $char iapplicant[IASSURED], napplicant[121], fapplicant[2], apayment_zip[CA_ZIP], apayment[100], aemail_appl[51], dbirth_appl[11];
  $char fsex_appl[2], itel_appl[21], tmobile_appl[21], nrelation_appl[41], ndeputy_appl[51], iapplicant_cntry[2], napplicant_cntry[51], applicant_foccup[2], applicant_noccup[6];

  int tmp_len;

  cm_buf_get("%s", DBName);
  cm_buf_get("%s ", iPlyEdr);
  cm_buf_get("%s ", fType);  /*1130918005_C01 �u��car401�L�����ɥ������D*/
                             /*�GfType = "0" �O�渹�FfType = "1" ���(�ɥ�)�� */

  EXEC SQL WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
    if (exitsub(reply, M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }

  strcpy(message, "");

  sIupcompShort[0] = iPlyEdr[2]; /* �O�渹�ĤT�X */
  sIupcompShort[1] = '\0';
  strcpy(policyDB, get_upcomp(sIupcompShort, USE_SHORT_BRANCH_ID, USE_BRANCH_ID));
  strcpy(policyDBname, get_full_dbname(policyDB));
  /*
       sprintf_s(stmt, sizeof stmt, " select nassured, napplicant, iassured, iapplicant, nvl(dbirth,' '), nvl(dbirth_appl,' ') "
                      "   from %s:policy"
                      "  where iPlyEdr = '%s' ", policyDBname, iPlyEdr);
  */
   if (fType[0]=='0')
   {
      /* 1100324005_SC1 �w��j���L��@����J�@�~,�s�W�K�Q�ʱa��ƥ\�� */
      sprintf_s(stmt, sizeof stmt, " select nassured, itel, itel_night, mobil_phone, aassured_zip, aassured, iemail, "
                    "        nvl(dbirth,' ') AS dbirth, iassured, fassured, ndeputy_assured, ilicense, "
                    "        fsex, fmarriage, iassured_cntry, nassured_cntry, foccup, noccup, "
                    "        iapplicant, napplicant, fapplicant, apayment_zip, apayment, aemail_appl, "
                    "        nvl(dbirth_appl,' ') AS dbirth_appl, fsex_appl, itel_appl, tmobile_appl, "
                    "        nrelation_appl, ndeputy_appl, iapplicant_cntry, napplicant_cntry, "
                    "        applicant_foccup, applicant_noccup "
                    "   from %s:policy "
                    "  where ipolicy = '%s' ",
              policyDBname, iPlyEdr);
   }
   else if (fType[0]=='1')
   {
      /* 1130918005_C01 �u��car401�L�����ɥ������D */
      sprintf_s(stmt, sizeof stmt, " select nassured, itel, itel_night, mobil_phone, aassured_zip, aassured, iemail, "
                    "        nvl(dbirth,' ') AS dbirth, iassured, fassured, ndeputy_assured, ilicense, "
                    "        fsex, fmarriage, iassured_cntry, nassured_cntry, foccup, noccup, "
                    "        iapplicant, napplicant, fapplicant, apayment_zip, apayment, aemail_appl, "
                    "        nvl(dbirth_appl,' ') AS dbirth_appl, fsex_appl, itel_appl, tmobile_appl, "
                    "        nrelation_appl, ndeputy_appl, iapplicant_cntry, napplicant_cntry, "
                    "        applicant_foccup, applicant_noccup "
                    "   from %s:policy_bak "
                    "  where iendorse = '%s' ",
              policyDBname, iPlyEdr);
   }
     
  $prepare prep3 from $stmt;
  $execute prep3 into /*$nassured, $napplicant, $iassured, $iapplicant, $s_dbirth, $s_dbirth_appl;*/
      $nassured,
      $itel, $itel_night, $mobil_phone, $aassured_zip, $aassured, $iemail,
      $dbirth, $iassured, $fassured, $ndeputy_assured, $ilicense,
      $fsex, $fmarriage, $iassured_cntry, $nassured_cntry, $foccup, $noccup,
      $iapplicant, $napplicant, $fapplicant, $apayment_zip, $apayment, $aemail_appl,
      $dbirth_appl, $fsex_appl, $itel_appl, $tmobile_appl,
      $nrelation_appl, $ndeputy_appl, $iapplicant_cntry, $napplicant_cntry,
      $applicant_foccup, $applicant_noccup;

  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CM_NOT_FOUND) == True)
      return M_CM_NOT_FOUND;
    else
      return apiRC;
  }

  cm_buf_init(ReplyBuf);
  /*cm_buf_put ("%l %s %s %s %s %s %s ", M_CM_OK, nassured, napplicant, iassured, iapplicant, s_dbirth, s_dbirth_appl);*/

  cm_buf_put("%l %s %s %s %s %s %s %s ", M_CM_OK, nassured, itel, itel_night, mobil_phone, aassured_zip, aassured, iemail);
  cm_buf_put("%s %s %s %s %s ", dbirth, iassured, fassured, ndeputy_assured, ilicense);
  cm_buf_put("%s %s %s %s %s %s ", fsex, fmarriage, iassured_cntry, nassured_cntry, foccup, noccup);
  cm_buf_put("%s %s %s %s %s %s ", iapplicant, napplicant, fapplicant, apayment_zip, apayment, aemail_appl);
  cm_buf_put("%s %s %s %s ", dbirth_appl, fsex_appl, itel_appl, tmobile_appl);
  cm_buf_put("%s %s %s %s %s %s ", nrelation_appl, ndeputy_appl, iapplicant_cntry, napplicant_cntry, applicant_foccup, applicant_noccup);

  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  printf("ca401_get_policy,SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
} /* ca401_get_policy */
/***************************************************************************/

/***************************************************************************/
/*1100909003_SC2 �_�@�Ϯ��S�h���p�{��(����07.15)�}���O181�I�ݨD*/
/*1081105005_SC2 �ק���~���w���ƫ������²v�Φۭt�B*/
/*1071226006_SC2_ �w���ƫ����վ�(���²v+�ĤT�H�d��)*/
long ca401_get_dep_rate_prov(reply)
serverReply reply;
{
  $char DBName[5];
  $char message[101], ipolicy[21];
  char sIupcompShort[2], policyDB[21], policyDBname[41];
  $char stmt[2048], dep_rate_prov[2], sfcar_class_last[2], sfcar_class[2];
  $int i_drate_ym_15911, i_P_15911, i_Q_15911, i_drate_ym_other, i_P_other, i_Q_other, i_K_09, i_M_15911, i_Z_15911;

  int tmp_len;

  cm_buf_get("%s", DBName);
  cm_buf_get("%s", ipolicy);
  cm_buf_get("%s", sfcar_class);

  EXEC SQL WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
    if (exitsub(reply, M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }

  strcpy(message, "");
  strcpy(dep_rate_prov, " ");

  i_drate_ym_15911 = i_P_15911 = i_Q_15911 = i_M_15911 = i_Z_15911 = i_drate_ym_other = i_P_other = i_Q_other = i_K_09 = 0;

  sIupcompShort[0] = ipolicy[2]; /* �O�渹�ĤT�X */
  sIupcompShort[1] = '\0';
  strcpy(policyDB, get_upcomp(sIupcompShort, USE_SHORT_BRANCH_ID, USE_BRANCH_ID));
  strcpy(policyDBname, get_full_dbname(policyDB));

  strcpy(sfcar_class_last, " ");
  if (strlen(trim(sfcar_class)) > 0)
  {
    sprintf_s(stmt, sizeof stmt, " select (select fcar_class From car_type WHERE fclass='1' AND icode = p.icar_type) "
                  "   from %s:ply_relation p "
                  "  where ipolicy = '%s'",
            policyDBname, ipolicy);
    $prepare prep0 from $stmt;
    $execute prep0 into $sfcar_class_last;
    printf("-- trace sfcar_class_last[%s]\n ", sfcar_class_last);
    if (SQLCODE == SQLNOTFOUND)
    {
      if (exitsub(reply, M_CM_NOT_FOUND) == True)
        return M_CM_NOT_FOUND;
      else
        return apiRC;
    }
  }

  if ((sfcar_class[0] != ' ') && (sfcar_class_last[0] != ' ') && (sfcar_class[0] == sfcar_class_last[0]))
  {
    /*1080408008_SC2 98�����ഫ�I�ج�09+K����
  sprintf_s(stmt, sizeof stmt, " select max(case when iins_type in ('01','05','09','11') THEN drate_ym else '0' END) ::integer, "
                   "        sum(case when iins_type in ('01','05','09','11') then CHARINDEX('P',provision) else 0 end)::integer , "
                   "        sum(case when iins_type in ('01','05','09','11') then CHARINDEX('Q',provision) else 0 end)::integer , "
                   "        sum(case when iins_type in ('01','05','09','11','181') then CHARINDEX('M',provision) else 0 end)::integer , "
                   "        sum(case when iins_type in ('01','05','09','11') then CHARINDEX('Z',provision) else 0 end)::integer , "
                   "        sum(case when iins_type in ('09') then CHARINDEX('K',provision) else 0 end)::integer , "
                   "        max(case when iins_type in ('101','102','110','111','129','20','23','75','76','86','98') THEN drate_ym else '0' END)::integer , "
                   "        sum(case when iins_type in ('101','102','110','111','129','20','23','75','76','86','98') then CHARINDEX('P',provision) else 0 end)::integer , "
                   "        sum(case when iins_type in ('101','102','110','111','129','20','23','75','76','86','98') then CHARINDEX('Q',provision) else 0 end)::integer  "
             "   from %s:ply_ins_type "
             "  where ipolicy = '%s' and mdamage_cover > 0", policyDBname, ipolicy);*/

    /* 1081225006_SC3 �X�R���[���ڥN�X */
    sprintf_s(stmt, sizeof stmt, " select max(case when iins_type in ('01','05','09','181','11','201','205','209','211') THEN drate_ym else '0' END) ::integer, "
                  "        sum(case when iins_type in ('01','05','09','11','201','205','209','211') then CHARINDEX('P;',trim(provision)||';') else 0 end)::integer , "
                  "        sum(case when iins_type in ('01','05','09','181','11','201','205','209','211') then CHARINDEX('Q;',trim(provision)||';') else 0 end)::integer , "
                  "        sum(case when iins_type in ('01','05','09','181','11','201','205','209','211') then CHARINDEX('M;',trim(provision)||';') else 0 end)::integer , "
                  "        sum(case when iins_type in ('01','05','09','11','201','205','209','211') then CHARINDEX('Z;',trim(provision)||';') else 0 end)::integer , "
                  "        sum(case when iins_type in ('09','209') then CHARINDEX('K;',trim(provision)||';') else 0 end)::integer , "
                  "        max(case when iins_type in ('101','102','110','111','129','20','23','86') THEN drate_ym else '0' END)::integer , "
                  "        sum(case when iins_type in ('101','102','110','111','129','20','23','86') then CHARINDEX('P;',trim(provision)||';') else 0 end)::integer , "
                  "        sum(case when iins_type in ('101','102','110','111','129','20','23','86') then CHARINDEX('Q;',trim(provision)||';') else 0 end)::integer  "
                  "   from %s:ply_ins_type "
                  "  where ipolicy = '%s' and mdamage_cover > 0",
            policyDBname, ipolicy);
    printf("-- trace stmt[%s]\n ", stmt);
    $prepare prep1 from $stmt;
    $execute prep1 into $i_drate_ym_15911, $i_P_15911, $i_Q_15911, $i_M_15911, $i_Z_15911, $i_K_09, $i_drate_ym_other, $i_P_other, $i_Q_other;
    printf("-- trace SQLCODE[%d]\n ", SQLCODE);
    if (SQLCODE == SQLNOTFOUND)
    {
      if (exitsub(reply, M_CM_NOT_FOUND) == True)
        return M_CM_NOT_FOUND;
      else
        return apiRC;
    }

    if (sfcar_class[0] == '1')
    {
      strcpy(dep_rate_prov, "P"); /* �w�]�^��P����*/
      if (i_drate_ym_other > 0 || i_K_09 > 0)
      { /* �h�~���ӫO 101,102....86,98... �� [09 + K] */
        strcpy(dep_rate_prov, "P");
      }
      else
      {
        if (i_drate_ym_15911 == 0)
        { /* �h�~�S���ӫO 01,05,09,11   */
          /*strcpy( dep_rate_prov, "P");*/
          strcpy(dep_rate_prov, "-"); /* ��client�ݧ�ηs�O��W�h */
        }
        else
        {
          if (i_P_15911 > 0)
          { /* �h�~���ӫO 01,05,09,11 �B�����[ P  */
            strcpy(dep_rate_prov, "P");
          }
          else if (i_Q_15911 > 0)
          { /* �h�~���ӫO 01,05,09,11 �B�����[ Q  */
            strcpy(dep_rate_prov, "Q");
          }
          else
          { /* �h�~���ӫO 01,05,09,11 �B�S��P��Q  */
            if (i_drate_ym_15911 < 104)
            {
              strcpy(dep_rate_prov, "P"); /*�]���h�~���²v 15% */
            }
            else
            {
              strcpy(dep_rate_prov, " "); /*�]���h�~���²v 25% */
            }
          }
        }
      }
    }
    else if (sfcar_class[0] == '2') /* (�ƹ�W�{����~��������[ K����) */
    {
      strcpy(dep_rate_prov, "Q"); /* �w�]�^��Q����*/
      if (i_drate_ym_other > 0 || i_K_09 > 0)
      { /* (�ƹ�W��~������ӫO 101,102....86,98�Ϊ��[ K����*/
        strcpy(dep_rate_prov, "Q");
      }
      else
      {
        if (i_drate_ym_15911 == 0)
        { /* �h�~�S���ӫO 01,05,09,11   */
          /*strcpy( dep_rate_prov, "Q");*/
          strcpy(dep_rate_prov, "-"); /* ��client�ݧ�ηs�O��W�h */
        }
        else
        {
          if (i_P_15911 > 0)
          { /* �h�~���ӫO 01,05,09,11 �B�����[ P (�h�~���²v 15%) */
            strcpy(dep_rate_prov, "P");
          }
          else if (i_Q_15911 > 0)
          { /* �h�~���ӫO 01,05,09,11,181 �B�����[ Q (�h�~���²v 20%) */
            strcpy(dep_rate_prov, "Q");
          }
          else if (i_M_15911 > 0)
          { /* �h�~���ӫO 01,05,09,11,181 �B�����[ M (�h�~���²v 25%) */
            strcpy(dep_rate_prov, "M");
          }
          else if (i_Z_15911 > 0)
          { /* �h�~���ӫO 01,05,09,11 �B�����[ Z (�h�~���²v 15%),��Z����  */
            strcpy(dep_rate_prov, "P");
          }
          else
          { /* �h�~���ӫO 01,05,09,11 �B�S��������²v���� */
            if (i_drate_ym_15911 < 111)
            {
              strcpy(dep_rate_prov, "Q"); /*�]���h�~���²v 20% */
            }
            else
            {
              strcpy(dep_rate_prov, " "); /*�]���h�~���²v 30% */
            }
          }
        }
      }
    }
  }
  else
  {
    strcpy(dep_rate_prov, "-"); /* �O��P�e�檺�ۥ���~�O���@�� => ��client�ݧ�ηs�O��W�h */
  }
  printf("-- trace xxxxx[%s]\n ", dep_rate_prov);
  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s", M_CM_OK, dep_rate_prov);

  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  printf("ca401_get_policy,SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
}
/***************************************************************************/
static int
DiffMonth(d1, d2) /* input data should be date format */
long d1, d2;
{
  short mdy1[3], mdy2[3];
  int datediff = 0;

  rjulmdy(d1, mdy1);
  rjulmdy(d2, mdy2);
  datediff = (mdy1[2] * 12 + mdy1[0]) - (mdy2[2] * 12 + mdy2[0]);
  if (datediff < 0)
    datediff = 0;
  return datediff;
}
/*****************************************************************/
static double
MyPower(f1, i1)
double f1;
int i1;
{
  int i;
  double ff = 1.0;

  for (i = 0; i < i1; i++)
  {
    ff = ff * f1;
  }
  return ff;
}
/*****************************************************************/

/*1091021005_SC2�s�W�A�Ȥ��ߩ�����*/
/*1080730005_SC2 �q�lñ�p���ظm�@�~*/
static long ca401_query_esign(reply)
{
  int rc, ttlen;
  int count_all = 0;
  $char DBName[5], ibranch[3], s_itag[CA_TAG_NUM], s_iofficer[11], s_ileader[11], s_iroute[21];
  $char signType[2], stmt[7000], stmt_signType[2000], stmt_dunder[1000];
  $char dunder_bgn[11], dunder_end[11], caIentry[11], cmIunder[11], s_iassured[11];
  /* �d�ߵ��G */
  $char sIpolicy[21], sItag[CA_TAG_NUM], sDply_begin[11], sIroute[21], sIleader[11];
  $char sIofficer[11], sNleader[11], sNentry[11], sDunder[11], sNofficer[11], sIunder[11];
  $char sNassured[11];
  $char iscan_no[26]; /* 1101018008_SC2 �q�lñ�ݱ��y�s������X�W��25�X */
  char tmpbuf[4000];
  int count = 0, repbuf_len = 0, tmp_len = 0, replycnt = 0;

  cm_buf_get("%s", DBName);
  cm_buf_get("%s", ibranch);
  cm_buf_get("%s %s %s %s %s ", dunder_bgn, dunder_end, signType, caIentry, cmIunder);
  cm_buf_get("%s %s %s %s %s ", s_iofficer, s_ileader, s_itag, s_iassured, s_iroute);

  strcpy(dunder_bgn, trim(dunder_bgn));
  strcpy(dunder_end, trim(dunder_end));
  strcpy(signType, trim(signType));
  strcpy(caIentry, trim(caIentry));
  strcpy(cmIunder, trim(cmIunder));
  strcpy(s_iofficer, trim(s_iofficer));
  strcpy(s_ileader, trim(s_ileader));
  strcpy(s_itag, trim(s_itag));
  strcpy(s_iassured, trim(s_iassured));
  strcpy(s_iroute, trim(s_iroute));

  $WHENEVER SQLERROR GOTO errexit;
  $SET LOCK MODE TO WAIT 3;

  if (db_select(DBName) == False)
  {
    if (exitsub(reply, M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }

  if (signType[0] == '1')
  {
    sprintf_s(stmt_signType, sizeof stmt_signType, " AND a.fcase='3' AND a.ipolicy[1,2] = '%s'  \n", ibranch);
    sprintf_s(stmt_dunder, sizeof stmt_dunder, " AND a.iunder matches '%s' and a.dunder between '%s' and '%s'\n", cmIunder, dunder_bgn, dunder_end);
  }
  /*else if (signType[0] == '2')
  {    DM �� �u�|�����y�Ǹ� ��g��N�� �� �֫O�H���Bñ�p���
      sprintf_s(stmt_signType, sizeof stmt_signType," AND fcase='2' AND a.iquote='' ");
      sprintf_s(stmt_dunder, sizeof stmt_dunder,  " AND a.iunder <> '' AND a.iunder matches '%s' and a.dunder between '%s' and '%s'\n"
                            ,cmIunder,dunder_bgn, dunder_end);
  }*
  else if (signType[0] == '3') *�L�ȥ�ñ�p�G������ƥ�O�A�L�֫O�H���Bñ�p�������ơC*
  {
      sprintf_s(stmt_signType, sizeof stmt_signType," ");
      sprintf_s(stmt_dunder, sizeof stmt_dunder," AND trim(a.iunder) = '' and a.dunder is null\n");
  }*/

  cm_buf_init(ReplyBuf);
  ttlen = count = count_all = 0;
  cm_buf_res_msg(); /* reserve for msg_code and count */
  cm_buf_res_count();

  sprintf_s(stmt, sizeof stmt, "SELECT nvl(a.ipolicy,''), a.iscan_no, nvl(a.itag,''), \n"
                "       nvl(a.iofficer ,''),      nvl(a.iroute   ,''), nvl(a.ileader  ,''), \n"
                "       nvl(a.nassured[1,10],''), nvl(a.dunder,''),    nvl(a.dins_bgn,''), a.iunder \n"
                "  FROM cm_esign_data a ,ca_esign_data b\n"
                " WHERE a.iscan_no = b.iscan_no \n"
                "   AND a.iins_newtype = 'C'    \n"
                "   AND a.fstatus = '0'         \n"
                "   AND b.ientry   matches '%s' \n"
                "   AND a.iofficer matches '%s' \n"
                "   AND a.ileader  matches '%s' \n"
                "   AND a.iroute   matches '%s' \n"
                "   AND a.itag     matches '%s' \n"
                "   AND a.iassured matches '%s' \n"
                "   %s %s "
                " ORDER BY 3,4\n",
          caIentry, s_iofficer, s_ileader, s_iroute, s_itag, s_iassured,
          stmt_dunder, stmt_signType);

  printf("stmt[%s]\n", stmt);
  $PREPARE prepK FROM $stmt;
  $DECLARE cursK CURSOR FOR prepK;
  $OPEN cursK;
  for (;;)
  {
    $FETCH cursK INTO $sIpolicy, $iscan_no, $sItag, $sIofficer, $sIroute,
        $sIleader, $sNassured, $sDunder, $sDply_begin, $sIunder;
    printf("SQLCODE[%d]\n", SQLCODE);

    if (SQLCODE != 0)
      break;
    count++;
    count_all++;

    strcpy(sNleader, " ");
    $SELECT nname INTO $sNleader FROM officer WHERE iofficer = $sIleader;

    strcpy(sNofficer, " ");
    $SELECT nname INTO $sNofficer FROM officer WHERE iofficer = $sIofficer;

    printf("sIpolicy[%s]\n", sIpolicy);

    cm_buf_put("%s %s %s", sIpolicy, iscan_no, sItag);
    cm_buf_put("%s %s %s %s", sIofficer, sNofficer, sIroute, sNleader);
    cm_buf_put("%s %s %s %s", sNassured, sDply_begin, sDunder, sIunder);
    tmp_len = cm_buf_len(ReplyBuf);
    printf("tmp_len[%ld]\n", tmp_len);
    if (tmp_len > 39000)
    { /* if data length >= 3K/4K, then multiple send */
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OK) == False)
      {
        $CLOSE cursK;
        $FREE cursK;
        return apiRC;
      }
      ttlen = ttlen + tmp_len;
      count = 0;
      cm_buf_init(ReplyBuf);
      cm_buf_res_msg(); /* reserve for msg_code and count */
      cm_buf_res_count();
    }
    if (ttlen + tmp_len >= 300000)
    { /* if data length > 30K */
      $CLOSE cursK;
      $FREE cursK;
      cm_buf_init(ReplyBuf);
      cm_buf_put("%l", M_CM_OUT_SPACE);
      tmp_len = cm_buf_len(ReplyBuf);
      if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
        return apiRC;
      return M_CM_OUT_SPACE;
    }
  }

  $CLOSE cursK;
  $FREE cursK;
  printf("count_all[%d]\n", count_all);

  if (count_all > 0)
  {
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
      return apiRC;
    return api_OKComplete;
  }
  else
  {
    if (exitsub(reply, M_CM_NOT_FOUND) == True)
      return M_CM_NOT_FOUND;
    else
      return apiRC;
  }

errexit:
  printf("ca401_query_esign,SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
}

/*1080730005_SC2 �q�lñ�p���ظm�@�~*/
static long ca401_update_esign(reply)
serverReply reply;
{
  $int i, count;
  $char DBName[5], userid[11], iscan_no[26]; /* 1101018008_SC2 �q�lñ�ݱ��y�s������X�W��25�X */
  char option;
  int tmp_len;
  long MsgCode;

  $WHENEVER SQLERROR GOTO optes_err;
  $BEGIN WORK;

  cm_buf_get("%s", DBName);
  cm_buf_get("%s", userid);
  cm_buf_get("%d", &count);
  printf("=========ca401_update_esign() count[%d]=========\n", count);

  if (count > 0)
  {
    for (i = 0; i < count; i++)
    {
      cm_buf_get("%s ", iscan_no);

      $UPDATE cm_esign_data
          set fstatus = '2', /*�n�אּ 2:�w�鵲 �~�|�^�g�q�lñ�p�t�� */
          iupdate = $userid,
              dupdate = current,
              fpolicy = '3',
              dply_edr = today
                  WHERE iscan_no = $iscan_no
                      AND fstatus = '0';
      if (sqlca.sqlerrd[2] == 0)
      {
        SQLCODE = M_CA_ESIGN_UPD_ERR;
        goto optes_err;
      }
    }
  }
  $COMMIT WORK;

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l", M_CM_OK);

  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

optes_err:
  $ROLLBACK WORK;
  printf("ca401_update_esign,SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
}

/*1091021005_SC2�s�W�A�Ȥ��ߩ�����*/
long ca401_chk_cm_esign_data(reply)
serverReply reply;
{
  $char DBName[5], iscan_no[26] = "", ipolicy[21] = "", iunder[11] = "", dunder[11] = ""; /* 1101018008_SC2 �q�lñ�ݱ��y�s������X�W��25�X */
  $int iCount = 0;
  int tmp_len = 0;

  cm_buf_get("%s", DBName);
  cm_buf_get("%s", ipolicy);
  cm_buf_get("%s", iscan_no);

  EXEC SQL WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
    if (exitsub(reply, M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }

  iCount = 0;
  $select iunder, dunder Into $iunder, $dunder from cm_esign_data where iscan_no = $iscan_no and ipolicy = $ipolicy and fcase = '3';
  if (SQLCODE != SQLNOTFOUND)
    iCount = 1;
  printf("--trace iunder[%s],dunder[%s]", iunder, dunder);
  printf("-- trace ca401_chk_cm_esign_data() iCount[%d]\n ", iCount);

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %d %s %s", M_CM_OK, iCount, iunder, dunder);

  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  printf("ca401_chk_cm_esign_data,SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
}

/* 1090601002_SC1 �}��CAR401���H�U�ҦC���إ~�A�i�H�H�����Ӹ��H�� */
/* =>���o �j���I "�����H/�y��"���P�O�O���������� */
long get_compulsory_premium_icar_type(reply)
serverReply reply;
{
  int rc, tmp_len, slen;
  $char DBName[5];
  $char icode[4], car_type_list[200], s_car_type[3];
  cm_buf_get("%s ", DBName);
  cm_buf_get("%s ", icode);

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
    if (exitsub(reply, M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }

  strcpy(car_type_list, "");
  strcpy(s_car_type, "");

  $DECLARE GetCarType CURSOR FOR
      Select distinct icar_type From compulsory_premium
          Where(qcar_personbgn > 0 or qcar_personend > 0)
              And drate = (Select drate From ca_rate_date
                               Where icode = $icode and itable = 'compulsory_premium');
  $open GetCarType;
  for (;;)
  {
    $FETCH GetCarType INTO $s_car_type;
    if (SQLCODE == SQLNOTFOUND)
      break;

    strcpy(s_car_type, trim(s_car_type));
    printf("s_car_type=[%s]\n", s_car_type);

    if (strlen(s_car_type) > 0)
    {
      strcat(car_type_list, s_car_type);
      strcat(car_type_list, ";");
    }
  }
  $close GetCarType;
  $free GetCarType;

  cm_buf_init(ReplyBuf);

  slen = strlen(car_type_list);
  if (slen == 0)
  {
    strcpy(car_type_list, " ");
  }
  else
  {

    if (car_type_list[slen - 1] == ';')
    {
      car_type_list[slen - 1] = '\0';
    }
  }

  printf("car_type_list=[%s]\n", car_type_list);
  cm_buf_put("%l %s ", M_CM_OK, car_type_list);

  tmp_len = cm_buf_len(ReplyBuf);

  if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  printf("car401 get_compulsory_premium_icar_type(),SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
}

/*1100119001_SC2 �s�W-�s�ӫ~(238�I-�D���ϴ��O�Ϊ��[����)�������ˮ֤Ϊ���*/
/* 1090828001_SC1_�ˮ�38.39�I�D���ϴ��I�����Ƥ��o�O�W�� */
/* =>�ѶO�v�ɨ��o 38�B39�B238 �i�ϥΤ������� */
long Get_QdaySetup_ByRate(reply)
serverReply reply;
{
  int rc, tmp_len, slen;
  $char DBName[5];
  $char icode[4], iins_type[INSURANCE_TYPE], qday_list[200], icar_type[3], s_qday[4];
  $long mcoverage1, mcoverage3;
  cm_buf_get("%s ", DBName);
  cm_buf_get("%s ", icode);
  cm_buf_get("%s ", iins_type);
  cm_buf_get("%s ", icar_type);
  cm_buf_get("%l ", &mcoverage1);
  cm_buf_get("%l ", &mcoverage3);

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
    if (exitsub(reply, M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }

  printf("--trace icode=[%s]\n", icode);
  printf("--trace iins_type=[%s]\n", iins_type);
  printf("--trace icar_type=[%s]\n", icar_type);
  printf("--trace mcoverage1=[%ld]\n", mcoverage1);
  printf("--trace mcoverage3=[%ld]\n", mcoverage3);

  strcpy(qday_list, "");
  strcpy(s_qday, "");

  /*1100119001_SC2 �s�W-�s�ӫ~(238�I-�D���ϴ��O�Ϊ��[����)�������ˮ֤Ϊ��� */
  /* �վ�Ϥ��A�� 38/39/238�I */
  /* ex. 38/39: mdeduct = 300/305/800/805
          238 : mdeduct = 10003/10010/10015/10099  (�T��)
                           3003  (����)
  */
  $DECLARE GetQday CURSOR FOR
          SELECT DISTINCT CASE WHEN mdeduct > 1000 THEN TRIM(TRUNC(mdeduct / 100) ||'')
                                                  ELSE TRIM(TRUNC(mdeduct / 10) ||'') END
                                                      FROM cover_vs_premium
                                                          WHERE drate
                                                          IN(
                                                              SELECT drate FROM ca_rate_date
                                                                  WHERE itable = 'cover_vs_premium' AND icode = $icode)
                                                              AND iins_type = $iins_type
      AND icar_type = $icar_type
          AND mcoverage1 = $mcoverage1
              AND mcoverage2 = $mcoverage3;

  $open GetQday;
  for (;;)
  {
    $FETCH GetQday INTO $s_qday;
    printf("--trace SQLCODE=[%d]", SQLCODE);
    printf("--trace SQLNOTFOUND=[%d]", SQLNOTFOUND);
    if (SQLCODE == SQLNOTFOUND)
      break;

    strcpy(s_qday, trim(s_qday));
    printf("s_qday=[%s]\n", s_qday);

    if (strlen(s_qday) > 0)
    {
      strcat(qday_list, s_qday);
      strcat(qday_list, ";");
    }
  }
  $close GetQday;
  $free GetQday;

  cm_buf_init(ReplyBuf);

  slen = strlen(qday_list);
  if (slen == 0)
  {
    strcpy(qday_list, " ");
  }
  else
  {

    if (qday_list[slen - 1] == ';')
    {
      qday_list[slen - 1] = '\0';
    }
  }

  printf("qday_list=[%s]\n", qday_list);
  cm_buf_put("%l %s ", M_CM_OK, qday_list);

  tmp_len = cm_buf_len(ReplyBuf);

  if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  printf("car401 Get_QdaySetup_ByRate(),SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
}

/* 1:�`�����q�H�� ; 0:�A�Ȥ��ߤH��*/
long get_user_branch_type(reply)
serverReply reply;
{
  $char DBName[5] = "", userid[10] = "";
  $int iCount = 0;
  int tmp_len = 0;

  cm_buf_get("%s", DBName);
  cm_buf_get("%s", userid);

  EXEC SQL WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
    if (exitsub(reply, M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }

  iCount = 0;
  $SELECT count(*) into $iCount
      FROM officer a,
      branch b
          WHERE a.ibranch = b.ibranch
                                AND b.ibranch = b.iaccount_branch
                                                    AND a.iofficer = $userid;

  if (iCount > 0)
  {
    iCount = 1; /* 1:�`�����q�H�� 0:�A�Ȥ��ߤH��*/
  }

  printf("-- trace get_user_branch_type() iCount[%d]\n ", iCount);

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %d", M_CM_OK, iCount);

  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  printf("ca401 get_user_branch_type,SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
}

/* ���O�T���p�����D��� (1140108008_C01) */
long get_relative_ext_data(reply)
serverReply reply;
{
  $char DBName[5] = "", ipolicy[21] = "", iassured[13] = "", nassured[121] = "", dbirth[11] = "";
  int   tmp_len = 0;
  char  sIupcompShort[2], policyDB[21], policyDBname[41];
  $char stmt[2048];

  cm_buf_get("%s", DBName);
  cm_buf_get("%s", ipolicy);

  EXEC SQL WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
    if (exitsub(reply, M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }
  
  sIupcompShort[0] = ipolicy[2]; /* �O�渹�ĤT�X */
  sIupcompShort[1] = '\0';
  strcpy(policyDB, get_upcomp(sIupcompShort, USE_SHORT_BRANCH_ID, USE_BRANCH_ID));
  strcpy(policyDBname, get_full_dbname(policyDB));
  
  sprintf_s(stmt, sizeof stmt, 
            " SELECT iassured, nassured, dbirth "
            "   FROM %s:policy WHERE ipolicy = '%s'  ",policyDBname, ipolicy);

  $PREPARE pre_extdata FROM $stmt;
  $EXECUTE pre_extdata INTO $iassured, $nassured, $dbirth;
  $FREE pre_extdata;

  printf("-- trace get_relative_ext_data() iassured[%s] nassured[%s] dbirth[%s]\n ",iassured, nassured, dbirth);

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s %s %s", M_CM_OK, iassured, nassured, dbirth);

  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  printf("ca401 get_relative_ext_data,SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
}

/* �ˮ֬O�_��"¾��~"���ҥ~�q�� (1140108008_C01) */
long chk_noccup_exception(reply)
serverReply reply;
{
  $char DBName[5] = "", iroute[21] = "";
  $int  iCount = 0;
  int   tmp_len = 0;

  cm_buf_get("%s", DBName);
  cm_buf_get("%s", iroute);

  EXEC SQL WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
    if (exitsub(reply, M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }

  $SELECT count(*) INTO $iCount
     FROM car_code a, cm_route b
    WHERE a.kind = 'RB' 
      AND a.detail2 = b.iroute_main 
      AND b.iroute = $iroute
      AND (nvl(engname,'') = '' OR date(engname)>today);

  printf("-- trace chk_noccup_exception() iCount[%d]\n ",iCount);

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %d", M_CM_OK, iCount);

  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  printf("ca401 chk_noccup_exception,SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
}


/* �ˮ����p����(�j/��)�O�_�@�P (1140108008_C01) */
long chk_rel_itag(reply)
serverReply reply;
{
  $char DBName[5] = "", ipolicy[21] = "", irelative_ply[21] = "";
  $int  iCount = 0;
  int   tmp_len = 0;
  char  sIupcompShort[2], policyDB[21], policyDBname[41];
  $char stmt[2048];

  cm_buf_get("%s", DBName);
  cm_buf_get("%s", ipolicy);
  cm_buf_get("%s", irelative_ply);

  EXEC SQL WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
    if (exitsub(reply, M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }
  
  sIupcompShort[0] = ipolicy[2]; /* �O�渹�ĤT�X */
  sIupcompShort[1] = '\0';
  strcpy(policyDB, get_upcomp(sIupcompShort, USE_SHORT_BRANCH_ID, USE_BRANCH_ID));
  strcpy(policyDBname, get_full_dbname(policyDB));
  
  sprintf_s(stmt, sizeof stmt, 
            " SELECT count(*) FROM %s:policy a, %s:policy b "
            "  WHERE a.ipolicy = '%s'  "
            "    AND b.ipolicy = '%s'  "
            "    AND a.itag <> b.itag  ",
            policyDBname, policyDBname, ipolicy, irelative_ply);

  $PREPARE pre_relitag FROM $stmt;
  $EXECUTE pre_relitag INTO $iCount;
  $FREE pre_relitag;

  printf("-- trace chk_rel_itag() iCount[%d]\n ",iCount);

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %d", M_CM_OK, iCount);

  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  printf("ca401 chk_rel_itag,SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
}

/* ���o��O��Q�O�I�H�W�� (1140108008_C01) */
long get_bak_CusName(reply)
serverReply reply;
{
  $char DBName[5] = "", iendorse[21] = "", nassured[121] = "";
  int   tmp_len = 0;
  char  sIupcompShort[2], endorseDB[21], endorseDBname[41];
  $char stmt[2048];

  cm_buf_get("%s", DBName);
  cm_buf_get("%s", iendorse);

  EXEC SQL WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
    if (exitsub(reply, M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }
  
  sIupcompShort[0] = iendorse[2]; /* ��渹�ĤT�X */
  sIupcompShort[1] = '\0';
  strcpy(endorseDB, get_upcomp(sIupcompShort, USE_SHORT_BRANCH_ID, USE_BRANCH_ID));
  strcpy(endorseDBname, get_full_dbname(endorseDB));
  
  sprintf_s(stmt, sizeof stmt, 
            " SELECT nassured from %s:policy_bak "
            "  WHERE iendorse = '%s'  ",endorseDBname, iendorse);

  $PREPARE pre_CusName FROM $stmt;
  $EXECUTE pre_CusName INTO $nassured;
  $FREE pre_CusName;

  printf("-- trace get_bak_CusName() nassured[%s]\n ",nassured);

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s", M_CM_OK, nassured);

  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  printf("ca401 get_bak_CusName,SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
}

/* ���N�I�v�q����q���ѡG���o�I�حӼ� (1140108008_C01) */
long ca401_transfer(reply)
serverReply reply;
{
  $char DBName[5] = "", irelative_ply[21] = "";
  $int  iCount = 0;
  int   tmp_len = 0;
  char  sIupcompShort[2], policyDB[21], policyDBname[41];
  $char stmt[2048];

  cm_buf_get("%s", DBName);
  cm_buf_get("%s", irelative_ply);

  EXEC SQL WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
    if (exitsub(reply, M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }
  
  sIupcompShort[0] = irelative_ply[2]; /* �O�渹�ĤT�X */
  sIupcompShort[1] = '\0';
  strcpy(policyDB, get_upcomp(sIupcompShort, USE_SHORT_BRANCH_ID, USE_BRANCH_ID));
  strcpy(policyDBname, get_full_dbname(policyDB));
  
  sprintf_s(stmt, sizeof stmt, 
            " select count(*) from %s:ply_ins_type  "
            "  where ipolicy = '%s' and mdamage_cover <> 0  ",policyDBname, irelative_ply);

  $PREPARE pre_transfer FROM $stmt;
  $EXECUTE pre_transfer INTO $iCount;
  $FREE pre_transfer;

  printf("-- trace ca401_transfer() iCount[%d]\n ",iCount);

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %d", M_CM_OK, iCount);

  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  printf("ca401 ca401_transfer,SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
}

/* ���N�I�v�q����q���ѡG���o[�O���]�C�L��� (1140108008_C01) */
long ca401_transfer_print1(reply)
serverReply reply;
{
  $char DBName[5] = "", icard[21] = "", icard_print[23] = "", irelative_ply[23] = "", itag[CA_TAG_NUM] = "";
  int   tmp_len = 0;
  char  sIupcompShort[2], endorseDB[21], endorseDBname[41];
  $char stmt[2048];

  cm_buf_get("%s", DBName);
  cm_buf_get("%s", icard);

  EXEC SQL WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
    if (exitsub(reply, M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }

  
  sprintf_s(stmt, sizeof stmt, 
            " select '17'||a.icard, '17'||a.irelative_ply, b.itag   "
            "   from ply_relation a, policy b   "
            "   where a.icard = '%s' and a.ipolicy = b.ipolicy ", icard);

  $PREPARE pre_transfer1 FROM $stmt;
  $EXECUTE pre_transfer1 INTO $icard_print, $irelative_ply, $itag;
  $FREE pre_transfer1;

  printf("-- trace ca401_transfer_print1() icard_print[%s] irelative_ply[%s] itag[%s]\n ",icard_print,irelative_ply,itag);

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s %s %s", M_CM_OK, icard_print, irelative_ply, itag);

  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  printf("ca401 ca401_transfer_print1,SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
}

/* ���N�I�v�q����q���ѡG���o[���p��]�C�L��� (1140108008_C01) */
long ca401_transfer_print2(reply)
serverReply reply;
{
  $char DBName[5] = "", irelative_ply[21] = "", nassured[121] = "", aassured_zip[CA_ZIP] = "", aassured[91] = "", fsex[2] = "";
  int   tmp_len = 0;
  char  sIupcompShort[2], policyDB[21], policyDBname[41];
  $char stmt[2048];

  cm_buf_get("%s", DBName);
  cm_buf_get("%s", irelative_ply);

  EXEC SQL WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
    if (exitsub(reply, M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }
  
  sIupcompShort[0] = irelative_ply[2]; /* �O�渹�ĤT�X */
  sIupcompShort[1] = '\0';
  strcpy(policyDB, get_upcomp(sIupcompShort, USE_SHORT_BRANCH_ID, USE_BRANCH_ID));
  strcpy(policyDBname, get_full_dbname(policyDB));
  
  sprintf_s(stmt, sizeof stmt, 
            " select nassured, aassured_zip, aassured, fsex  "
            "   from %s:policy where ipolicy = '%s'  ",policyDBname, irelative_ply);

  $PREPARE pre_transfer2 FROM $stmt;
  $EXECUTE pre_transfer2 INTO $nassured, $aassured_zip, $aassured, $fsex;
  $FREE pre_transfer2;

  printf("-- trace ca401_transfer_print2() nassured[%s] aassured_zip[%s] aassured[%s] fsex[%s]\n ",nassured, aassured_zip, aassured, fsex);

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s %s %s %s", M_CM_OK, nassured, aassured_zip, aassured, fsex);

  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  printf("ca401 ca401_transfer_print2,SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
}

/* KYC���G��KYC����� (1140108008_C01) */
long get_KYC_print_data1(reply)
serverReply reply;
{
  $char DBName[5] = "", ipolicy[21] = "";
  $char nassured[121] = "", napplicant[121] = "", iengine[CA_ENGINE_NUM] = "", itag[CA_TAG_NUM] = "", 
        ndeputy_appl[51] = "", nrelation_appl[41] = "", ndeputy_assured[51] = "", 
        iassured_cntry[2] = "", nassured_cntry[51] = "", iapplicant_cntry[2] = "", napplicant_cntry[51] = "", 
        foccup[2] = "", noccup[6] = "", applicant_foccup[2] = "", applicant_noccup[6] = "", 
        fassured[2] = "", fapplicant[2] = "", dbirth[11] = "", dbirth_appl[11] = "", dply_begin[11] = "";
  int   tmp_len = 0;
  char  sIupcompShort[2], policyDB[21], policyDBname[41];
  $char stmt[2048];

  cm_buf_get("%s", DBName);
  cm_buf_get("%s", ipolicy);

  EXEC SQL WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
    if (exitsub(reply, M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }
  
  sIupcompShort[0] = ipolicy[2]; /* �O�渹�ĤT�X */
  sIupcompShort[1] = '\0';
  strcpy(policyDB, get_upcomp(sIupcompShort, USE_SHORT_BRANCH_ID, USE_BRANCH_ID));
  strcpy(policyDBname, get_full_dbname(policyDB));
  
  sprintf_s(stmt, sizeof stmt, 
            " select nassured, napplicant, iengine, itag,  "
            "        ndeputy_appl, nrelation_appl, ndeputy_assured,  "
            "        iassured_cntry, nassured_cntry, iapplicant_cntry, napplicant_cntry,  "
            "        foccup, noccup, applicant_foccup, applicant_noccup, "
            "        fassured, fapplicant, dbirth, dbirth_appl, b.dply_begin "
            "   from %s:policy a, %s:ply_relation b "
            "  where a.ipolicy = b.ipolicy AND a.ipolicy ='%s' ", policyDBname, policyDBname, ipolicy);

  $PREPARE pre_KYC1 FROM $stmt;
  $EXECUTE pre_KYC1 
      INTO $nassured, $napplicant, $iengine, $itag, 
           $ndeputy_appl, $nrelation_appl, $ndeputy_assured, 
           $iassured_cntry, $nassured_cntry, $iapplicant_cntry, $napplicant_cntry, 
           $foccup, $noccup, $applicant_foccup, $applicant_noccup, 
           $fassured, $fapplicant, 
           $dbirth, $dbirth_appl, $dply_begin;
  $FREE pre_KYC1;

  printf("-- trace get_KYC_print_data1() \n ");

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l", M_CM_OK);
  cm_buf_put("%s %s %s %s", nassured, napplicant, iengine, itag);
  cm_buf_put("%s %s %s", ndeputy_appl, nrelation_appl, ndeputy_assured);
  cm_buf_put("%s %s %s %s", iassured_cntry, nassured_cntry, iapplicant_cntry, napplicant_cntry);
  cm_buf_put("%s %s %s %s", foccup, noccup, applicant_foccup, applicant_noccup);
  cm_buf_put("%s %s %s %s %s", fassured, fapplicant, dbirth, dbirth_appl, dply_begin);

  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  printf("ca401 get_KYC_print_data1,SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
}

/* KYC���G��KYC����� (1140108008_C01) */
long get_KYC_print_data2(reply)
serverReply reply;
{
  $char DBName[5] = "", ipolicy[21] = "", iins_type[7] = "";
  $int  iCount  = 0;
  int   tmp_len = 0;
  char  sIupcompShort[2], policyDB[21], policyDBname[41];
  $char stmt[2048];

  cm_buf_get("%s", DBName);
  cm_buf_get("%s", ipolicy);

  EXEC SQL WHENEVER SQLERROR GOTO errexit;
   
  if (db_select(DBName) == False)
  {
    if (exitsub(reply, M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }
   
  sIupcompShort[0] = ipolicy[2]; /* �O�渹�ĤT�X */
  sIupcompShort[1] = '\0';
  strcpy(policyDB, get_upcomp(sIupcompShort, USE_SHORT_BRANCH_ID, USE_BRANCH_ID));
  strcpy(policyDBname, get_full_dbname(policyDB));
    
  sprintf_s(stmt, sizeof stmt, 
            " select iins_type from %s:ply_ins_type where ipolicy = ? ",policyDBname);

  cm_buf_init(ReplyBuf);
  cm_buf_res_msg();
  cm_buf_res_count();
  iCount=0;
  
  $PREPARE pre_KYC2 FROM $stmt;
  $DECLARE cur_KYC CURSOR FOR pre_KYC2;
  $OPEN cur_KYC USING $ipolicy;
  for (;;)
  {
  	$FETCH cur_KYC INTO $iins_type;
  	if (SQLCODE == SQLNOTFOUND) break;
  	
  	cm_buf_put("%s", iins_type);
  	iCount++;
  	
  	printf("-- trace KYC_print() iins_type[%s]\n ",iins_type);
  }
  $CLOSE cur_KYC;
  $FREE cur_KYC;
  
  cm_buf_put_msg(M_CM_OK);
  cm_buf_put_count(iCount);

  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  printf("ca401 get_KYC_print_data2,SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
}

/* KYC���G�C�L (1140108008_C01) */
long KYC_print(reply)
serverReply reply;
{
  $char DBName[5] = "", tmp[5] = "", data[21] = "";
  $int  iCount  = 0;
  int   tmp_len = 0;
  $char stmt[2048];

  cm_buf_get("%s", DBName);
  cm_buf_get("%s", tmp);

  EXEC SQL WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
    if (exitsub(reply, M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }
  
  sprintf_s(stmt, sizeof stmt, 
            " SELECT trim(detail2) FROM car_code WHERE kind = 'KY' AND detail = ? ");

  cm_buf_init(ReplyBuf);
  cm_buf_res_msg();
  cm_buf_res_count();
  iCount=0;
  
  $PREPARE pre_KYCprint FROM $stmt;
  $DECLARE cur_KYCprint CURSOR FOR pre_KYCprint;
  $OPEN cur_KYCprint USING $tmp;
  for (;;)
  {
  	$FETCH cur_KYCprint INTO $data;
  	if (SQLCODE == SQLNOTFOUND) break;
  	
  	cm_buf_put("%s", data);
  	iCount++;
  	
  	printf("-- trace KYC_print() data[%s]\n ",data);
  }
  $CLOSE cur_KYCprint;
  $FREE cur_KYCprint;
  
  cm_buf_put_msg(M_CM_OK);
  cm_buf_put_count(iCount);
  
  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
  	return apiRC;
  else
        return api_OKComplete;

errexit:
  printf("ca401 KYC_print,SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
}

/* 1081225006_SC3 �X�R���[���ڥN�X
long get_provision_new(reply)
serverReply reply;
{
     $char DBName[5] = "", userid[10] = "";
     $int  iCount  = 0;
     int   tmp_len = 0;
     $char iprovision[7]=" ",nprint[41]=" ";

     cm_buf_get ("%s", DBName);
     cm_buf_get ("%s", userid);


     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     if (db_select (DBName) == False)
     {
         if (exitsub (reply, M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
         else
            return apiRC;
     }
    $DECLARE cursP CURSOR FOR
      SELECT iprovision,nprint
        FROM ca_provision_main
       WHERE (dactive_sys <= today Or dactive_sys IS NULL)
         AND (dexpire_sys >  today Or dexpire_sys IS NULL)
       ORDER BY 1;

    cm_buf_init(ReplyBuf);
    cm_buf_res_msg();
    cm_buf_res_count();
    iCount=0;
    $OPEN cursP;
    for(;;)
    {
        $FETCH cursP INTO $iprovision, $nprint;
        if( SQLCODE == SQLNOTFOUND) break;

        cm_buf_put("%s %s", iprovision, nprint);
        iCount++;
    }
    $CLOSE cursP;
    $FREE cursP;
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(iCount);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
     printf ("ca401 get_provision_new,SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
*/