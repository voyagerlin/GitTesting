#include <stdio.h>
#include <string.h>
#include <memory.h>
#include "api_xsrv.h"
#include <sys/stat.h>
$include sqlca;
$include datetime.h;
#include "sql.h"
#include "is_def.h"
#include "aoimsgs.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"
#include <math.h>
#include "carmsgs.h"
#include "commsgs.h"

char  DBName[3];
int   rc;
$int  id1;
$char sBranch[3];
$char stmt[3072];

int   sTransApp();
char  *substring();
$char Errmsg[60];
$int  icnt;

$char ibranch[3];
char  outputf[20];

main(argc, argv)
int argc;
char **argv;
{
    char  buf[120];
    $char ipolicy[21];

    $int  iyear,imonth;
    $char cyear[5],cmonth[3];
    $char ndate[21];
    $char nyear[5],nmonth[3];
    $long minday,midday,maxday;
    long  ccnt;
    $long new_cnt,main_cnt,tmp_cnt;

    $char sDplyEndBgn[11],sDplyEndEnd[11];
    $long lDplyEndBgn    ,lDplyEndEnd;
    $int  iYY,iMM;
    $char sYY[4],sMM[3];

    minday = midday = maxday = 0;

    printf("1.�}�l�ɶ�[%s]\n",cm_get_sysd());

    strcpy(cyear    , isNULLstr(argv[1]));
    strcpy(cmonth   , isNULLstr(argv[2]));

    printf("cyear[%s],cmonth[%s]\n",cyear,cmonth);
    if  ( (strlen(trim(cyear)) == 0) || (strlen(trim(cmonth))==0) )
    {
        printf("2.�п�J�R����Ʀ~�פΤ�� Ex. --> trans302 91 01 \n");
        exit(1);
    }

    iyear = atoi(cyear) ;
    imonth = atoi(cmonth) ;

    strcpy(ndate,cm_sysd_cdate_100(cm_get_sysd()));
    printf("3.ndate[%s]\n",ndate);

    strcpy(nyear,substring(ndate,1,3));
    strcpy(nmonth,substring(ndate,5,2));

    printf("4.nyear[%s],nmonth[%s]\n",nyear,nmonth);
    
    /* 960705���ѡG���{�����J�p�e(�Y�q�`����멳���k)���� 
                   ex. 96.06.29(��)�A96.07.02�J�p9�����O��ơA
                   ��O��ƫO�s�b�~(�t9���)�A�G�R���~������9603
                   ���קK�ŧR�A�G�[���ˮ֡C
                   ex. [96.06] - [96.03] = 3 > 2 => OK */
     
    if (((atoi(nyear)*12+atoi(nmonth)) - (iyear*12+imonth) ) <= 2)
    {    	 
    	  if ((iyear==98)&&(imonth==5)){
    	  	  /* 98.05 ��ƧR��,�ηs�O�v���s�J�p */
    	  }else{
	          printf("5.�u�i�R��3�Ӥ�H�W����ơA\n");
	          printf("  �ЦA���T�{���R�����~��I\n");
	          exit(1);
          }
    }
 
    iyear = iyear + 1911;
    /***********************************************/
    /***********************************************/
    /* begin */
    sprintf(sDplyEndBgn,"%s/%s/01",cyear,cmonth);
    lDplyEndBgn = cm_ymd_cdate(sDplyEndBgn);

    /* end   */
    if (strcmp(trim(cmonth),"12")==0)
    {
        iYY = atoi(cyear) + 1;
        strcpy(sYY, itoa(iYY));
        strcpy(sYY, trim(sYY));
        sprintf(sDplyEndEnd,"%s/01/01",sYY);
    }
    else
    {
        iMM = atoi(cmonth) + 1;
        strcpy(sMM, itoa(iMM));
        sprintf(sDplyEndEnd,"%s/%s/01",cyear,sMM);
    }

    lDplyEndEnd = cm_ymd_cdate(sDplyEndEnd)-1;

    printf("6.lDplyEndBgn[%ld]\n",lDplyEndBgn);
    printf("7.lDplyEndEnd[%ld]\n",lDplyEndEnd);

    /***********************************************/

    printf("8.Check OK Begin Work\n");
    printf("9.Year[%d],Month[%d]\n",iyear,imonth);

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT ;
    $DATABASE sysdb;

/** goto do_next; **/

    $CREATE TEMP TABLE get_ipolicy
    (
        ipolicy char(20)
    )
    WITH NO LOG;

    /* 960705���ѡG�N�����ҭn�R������O�渹�Ȧs�� TEMP table: get_ipolicy **/
    printf("10.Begin Insert INTO temp table get_ipolicy\n");
    $BEGIN WORK;
    ccnt = 0;
    $DECLARE cur_1 CURSOR WITH HOLD FOR
      SELECT ipolicy
        FROM policy_302
       WHERE dply_begin between $lDplyEndBgn and $lDplyEndEnd;
    $OPEN cur_1;
    for(;;)
    {
           $FETCH cur_1 INTO $ipolicy;
           if (SQLCODE == SQLNOTFOUND) break;

           ccnt ++;

           $INSERT INTO get_ipolicy (ipolicy) VALUES ($ipolicy);

           if (ccnt == 1000)
           {
              ccnt = 0;
              $COMMIT WORK;
              $BEGIN  WORK;
           }
    }
    $CLOSE cur_1;
    $FREE  cur_1;
    $COMMIT WORK;
    printf("12.End Insert INTO temp table get_ipolicy\n");

    $CREATE INDEX get_ipolicy_ix_1 on get_ipolicy (ipolicy);


    /********************* 960705���ѡG �H�U�϶� delete �Ҧ� "_302" �� **********************/
 
    /* 960705,�s�W���ݪ��I => �s�Wtable ply_ins_cover_302*/
    printf("12.5 Begin delete from ply_ins_cover_302 \n");
    $BEGIN  WORK;
    ccnt = 0; 
    $DECLARE cur_X CURSOR WITH HOLD FOR
      SELECT ipolicy
        FROM get_ipolicy;
    $OPEN cur_X;
    for(;;)
    {
           $FETCH cur_X INTO :ipolicy;
           if (SQLCODE == SQLNOTFOUND) break;
           	
           tmp_cnt  = 0;             

		   $SELECT count(*)
		      INTO $tmp_cnt
		      FROM ply_ins_cover_302
		     WHERE ipolicy= $ipolicy;
		     
		   if (tmp_cnt>0){
	           ccnt ++;
	           $DELETE FROM ply_ins_cover_302 WHERE ipolicy = $ipolicy;		   	
		   	}

           if (ccnt == 1000)
           {
              ccnt = 0;
              EXEC SQL COMMIT WORK;
              EXEC SQL BEGIN WORK;
           }
    }
    $CLOSE cur_X;
    $FREE  cur_X;
    $COMMIT WORK;

    /* 960705, �� delete => ca_pa_ply_302*/
    printf("12.8 Begin delete from ca_pa_ply_302 \n");
    $BEGIN  WORK;
    ccnt = 0; 
    $DECLARE cur_Y CURSOR WITH HOLD FOR
      SELECT ipolicy
        FROM get_ipolicy;
    $OPEN cur_Y;
    for(;;)
    {
           $FETCH cur_Y INTO :ipolicy;
           if (SQLCODE == SQLNOTFOUND) break;
           	
           tmp_cnt  = 0;             

		   $SELECT count(*)
		      INTO $tmp_cnt
		      FROM ca_pa_ply_302
		     WHERE ipolicy= $ipolicy;
		     
		   if (tmp_cnt>0){
	           ccnt ++;
	           $DELETE FROM ca_pa_ply_302 WHERE ipolicy = $ipolicy;		   	
		   	}

           if (ccnt == 1000)
           {
              ccnt = 0;
              EXEC SQL COMMIT WORK;
              EXEC SQL BEGIN WORK;
           }
    }
    $CLOSE cur_Y;
    $FREE  cur_Y;
    $COMMIT WORK;

    
    printf("13.Begin delete from ca_pa_ply_302\n");
    $BEGIN  WORK;
    ccnt = 0;
    $DECLARE cur_A CURSOR WITH HOLD FOR
      SELECT ipolicy
        FROM get_ipolicy;
    $OPEN cur_A;
    for(;;)
    {
           $FETCH cur_A INTO :ipolicy;
           if (SQLCODE == SQLNOTFOUND) break;

           ccnt ++;

           $DELETE FROM ply_ins_type_302 WHERE ipolicy = $ipolicy;

           if (ccnt == 1000)
           {
              ccnt = 0;
              EXEC SQL COMMIT WORK;
              EXEC SQL BEGIN WORK;
           }
    }
    $CLOSE cur_A;
    $FREE  cur_A;
    $COMMIT WORK;
    printf("14.End delete from ply_ins_type_302\n");

    printf("15.Start Delete policy_302 Year[%d],Month[%d]\n",iyear,imonth);
    $BEGIN WORK;
    ccnt = 0;
    EXEC SQL DECLARE cur_B CURSOR WITH HOLD FOR
              SELECT ipolicy
                INTO :ipolicy
                FROM get_ipolicy;
    EXEC SQL OPEN cur_B;
    for(;;)
    {
           $FETCH cur_B;
           if (SQLCODE == SQLNOTFOUND) break;

           ccnt ++;

           $DELETE FROM policy_302 WHERE ipolicy = :ipolicy;

           if (ccnt == 1000)
           {
              ccnt = 0;
              $COMMIT WORK;
              $BEGIN WORK;
           }
    }
    $CLOSE cur_B;
    $FREE  cur_B;
    $COMMIT WORK;
    printf("16.End Delete policy_302\n");
    

    /*******************  960705���ѡG �H�U�϶� delete �Ҧ� "_last" �� �H�� policy_302f�Bply_ins_type_302f **********************/    
    /*******************   ( delete �覡 => ��drop table �� , �A create )  *****************/
    
    printf("17.BEGIN DROP all_last TABLE\n");
    $BEGIN WORK;
    $drop table ply_relation_last;
    $drop table policy_last;
    $drop table ply_ins_type_last;
    $drop table ca_pa_ply_last;
    $drop table ply_ins_cover_last;  /* 960705,�s�W���ݪ��I => �s�Wtable ply_ins_cover_last*/
    printf("18.END   DROP all_last TABLE\n");

    printf("19.BEGIN CREATE ply_relation_last \n");
    $create table "informix".ply_relation_last
    (
      ipolicy char(20)
          default ' ',
      icard char(20)
          default ' ',
      fcard_class char(1)
          default ' ',
      irelative_ply char(20)
          default ' ',
      ilast_card char(20)
          default ' ',
      ilast_ply char(20)
          default ' ',
      inext_ply char(20)
          default ' ',
      itmp_policy char(20)
          default ' ',
      itreaty char(1)
          default ' ',
      qply_period smallint
          default 0,
      dply_begin date,
      dply_end date,
      iissue_ym char(5)
          default ' ',
      ipro_year char(4)
          default ' ',
      ibrand char(8)
          default ' ',
      icar_type char(2)
          default ' ',
      mdmg_agent integer
          default 0,
      mdmg_commi integer
          default 0,
      mdmg_discount integer
          default 0,
      mdmg_prem integer
          default 0,
      mdmg_pure_prem decimal(10,3)
          default 0.000,
      mlia_agent integer
          default 0,
      mlia_commi integer
          default 0,
      mlia_discount integer
          default 0,
      mlia_prem integer
          default 0,
      mlia_pure_prem decimal(10,3)
          default 0.000,
      ibig_comp char(1)
          default ' ',
      ibig_branch char(4)
          default ' ',
      ibig_office char(9)
          default ' ',
      ibig_sales char(10)
          default ' ',
      iresource char(1)
          default ' ',
      ibroker char(10)
          default ' ',
      iofficer char(10)
          default ' ',
      ileader char(10)
          default ' ',
      icorps char(10)
          default ' ',
      iarea char(10)
          default ' ',
      icashier char(10)
          default ' ',
      iexaminer char(10)
          default ' ',
      dexamine date,
      ientry char(10)
          default ' ',
      dentry date,
      dpolicy date,
      dply_close date,
      dapply date,
      fprint char(1)
          default '0',
      drenew_print date,
      dtransfer date,
      fedr_class char(1)
          default ' ',
      dendorse date,
      ibranch char(2)
          default ' ',
      iquota char(6)
          default ' ',
      icomp_in char(2)
          default ' ',
      ibranch_in char(2)
          default ' ',
      icomp_at char(2)
          default ' ',
      ibranch_at char(2)
          default ' ',
      mready decimal(9,4)
          default 0.0000,
      mstable decimal(9,4)
          default 0.0000,
      mcompensation decimal(9,4)
          default 0.0000,
      madjcom_prem decimal(9,4)
          default 0.0000,
      mresearch decimal(9,4)
          default 0.0000,
      minvest decimal(9,4)
          default 0.0000,
      mbus_rule decimal(9,4)
          default 0,
      mbusiness decimal(9,4)
          default 0.0000,
      mcapital decimal(9,4)
          default 0.0000,
      maintain decimal(9,4)
          default 0.0000,
      fcomp_class char(2)
          default ' ',
      fcomp_class_last char(2)
          default ' ',
      fdiscount char(1)
          default ' ',
      ipay_way char(1)
          default ' ',
      ibatch_no smallint
          default 0,
      icar_flag char(1) not null ,
      transno char(20)
          default ' ',
      seqno smallint
          default 0,
      qnext_year smallint
          default 0,
      iinstall   char(10) 
          default ' '
    )in dbsp_carloss extent size 52892 next size 7556;
    $revoke all on "informix".ply_relation_last from "public";
    $create index "informix".ca_plyrelast_ix_1 on "informix".ply_relation_last
        (dpolicy);
    $create unique index "informix".ca_plyrelast_ix_2 on "informix"
        .ply_relation_last (ipolicy);
    $create unique index "informix".ca_plyrelast_ix_3 on "informix"
        .ply_relation_last (icard);
    $create index "informix".ca_plyrelast_ix_4 on "informix".ply_relation_last
        (dply_end);
    $grant all on ply_relation_last to ipisnew;
    $revoke alter on ply_relation_last from ipisnew;
    $grant select on ply_relation_last to ipismis;
    printf("20.END CREATE ply_relation_last\n");

    printf("21.BEGIN CREATE policy_last\n");
    $create table "informix".policy_last
    (
      ipolicy char(20)
          default ' ',
      icard char(20)
          default ' ',
      ixxcard char(20)
          default ' ',
      fassured char(1)
          default ' ',
      iassured char(12)
          default ' ',
      iassured_ext char(2)
          default ' ',
      nassured char(120)
          default ' ',
      ilicense char(10)
          default ' ',
      ibirth char(8)
          default ' ',
      fsex char(1)
          default ' ',
      fmarriage char(1)
          default ' ',
      nuser char(18)
          default ' ',
      ibenef char(10)
          default ' ',
      nbenef char(42)
          default ' ',
      aassured char(90)
          default ' ',
      aassured_zip char(5)
          default ' ',
      itel char(20)
          default ' ',
      iemail char(50)
          default ' ',
      apayment char(90)
          default ' ',
      apayment_zip char(5)
          default ' ',
      iply_area char(10)
          default ' ',
      nbrand_abbr char(12)
          default ' ',
      ncar_abbr char(12)
          default ' ',
      fcar_note char(2)
          default ' ',
      qcylinder integer
          default 0,
      iengine char(20)
          default ' ',
      ibody char(20)
          default ' ',
      itag char(8)
          default ' ',
      mcar_price decimal(5,1)
          default 0.0,
      nequipment char(30)
          default ' ',
      flimit char(1)
          default ' ',
      pdmg_align smallint
          default 0,
      pbrg_align smallint
          default 0,
      plia_align smallint
          default 0,
      iabn_type char(1)
          default ' ',
      fpass char(1)
          default ' ',
      ipass char(10)
          default ' ',
      dpass date,
      ffac char(1)
          default ' ',
      dfac date,
      fcut char(1)
          default '0',
      fcal_way char(1)
          default ' ',
      idmg_rate char(2)
          default ' ',
      pdmg_factor decimal(6,4)
          default 0.0000,
      ibrg_rate char(2)
          default ' ',
      pbrg_factor decimal(6,4)
          default 0.0000,
      qpt decimal(4,1)
          default 0.0,
      fpt char(1)
          default ' ',
      psex_age decimal(15,12)
          default 0.00,
      psex_age_damage decimal(15,12)
          default 0.00,          
      lia_class char(2)
          default '4',
      plia_acc decimal(5,2)
          default 0.00,
      dmg_acc_1st integer
          default 99,
      dmg_acc_2nd integer
          default 99,
      dmg_acc_3rd integer
          default 99,
      pdmg_acc decimal(5,2)
          default 0.00,
      fhuman char(1)
          default '1',
      fcomp_24 char(1)
          default ' ',
      iext_policy char(20)     
          default ' ',
      qpro_month integer      
          default 0,
      mkilo_ply decimal(9,2) 
          default 0.00,
      mkilo_edr decimal(9,2) 
          default 0.00,
      irisk char(1)      
          default ' ',
      irelative_ext char(20)     
          default ' ',
	  iapplicant char(12) 
	      default ' ',          
	  napplicant char(120) 
	      default ' ',
	  dbirth date 
	      default null,
	  dissue date 
	      default null,
	  iextra_charge char(10) 
	      default ' ',
	  gextra_charge integer 
	      default 0,
	  pextra_charge decimal(6,4) 
	      default 0,
	  iquery_num_damage char(14) 
	      default ' ',
	  iquery_num char(14) 
	      default ' ',
	  introducer char(20) 
	      default ' ',
	  mequipment decimal(5,1) 
	      default 0,
	  survey_num char(10) 
	      default ' ',
	  bound_num char(10) 
	      default ' ',
	  abnormal_num char(10) 
	      default ' '
    )in dbsp_carloss extent size 85720 next size 12244;
    $revoke all on "informix".policy_last from "public";
    $create unique index "informix".ca_ply_last_ix_1 on "informix".policy_last
        (icard);
    $create unique index "informix".ca_ply_last_ix_2 on "informix".policy_last
        (ipolicy);
    $create index "informix".ca_ply_last_ix_3 on "informix".policy_last
        (iengine);
    $create index "informix".ca_ply_last_ix_4 on "informix".policy_last
        (itag);
    $create index "informix".ca_ply_last_ix_5 on "informix".policy_last
        (nequipment);
    $grant all on policy_last to ipisnew;
    $revoke alter on policy_last from ipisnew;
    $grant select on policy_last to ipismis;
    printf("22.END CREATE policy_last\n");

    printf("23.BEGIN CREATE ply_ins_type_last\n");
    $create table "informix".ply_ins_type_last
    (
      ipolicy char(20)
          default ' ',
      iins_type char(6)
          default ' ',
      minjured_cover integer
          default 0,
      mdeath_cover integer
          default 0,
      mdamage_cover integer
          default 0,
      mdeduct integer
          default 0,
      mins_premium integer
          default 0,
      mpure_prem decimal(10,3)
          default 0,
      qserial smallint
          default 0,
      fedr_status char(1)
          default ' ',
      dendorse date,
      dedr_begin date,
      dedr_end date,
      iendorse char(20)
          default ' ',
      pcommission decimal(4,2)
          default 0,
      mcommission integer
          default 0,
      pagent decimal(4,2)
          default 0,
      magent integer
          default 0,
      pdiscount decimal(4,2)
          default 0,
      mdiscount integer
          default 0,
      drate_ym char(4)
          default ' ',
      mprem integer
          default 0,
      iproduct char(12)
          default ' ',
      ipaid_base char(1)
          default 'A',
      qday  integer
          default 0,
      mexpense  integer
          default 0,
      mexp_disc integer
          default 0,
      provision char(2)
          default '',
      pextra_charge decimal(7,6)
          default 0,
      pbusiness decimal(7,6)
          default 0          
    )in dbsp_carloss extent size 47508 next size 6788;
    $revoke all on "informix".ply_ins_type_last from "public";
    $create unique index "informix".ca_plyinslast_ix_1 on "informix"
        .ply_ins_type_last (ipolicy,iins_type);
    $create index "informix".ca_plyinslast_ix_2 on "informix".ply_ins_type_last
        (ipolicy);
    $grant all on ply_ins_type_last to ipisnew;
    $revoke alter on ply_ins_type_last from ipisnew;
    $grant select on ply_ins_type_last to ipismis;
    printf("24.END CREATE ply_ins_type_last\n");

    printf("25.BEGIN CREATE ca_pa_ply_last\n");
    $create table "informix".ca_pa_ply_last
    (
      ipolicy char(20)
          default ' ',
      iins_type char(6)
          default ' ',
      iinsurant char(10)
          default ' ',
      ninsurant char(30)
          default ' ',
      dbirth date,
      ainsurant char(90)
          default ' ',
      iins_scope char(1)
          default ' ',
      icareer char(1)
          default ' ',
      mins_amt integer
          default 0,
      mins_premium integer
          default 0,
      mpure_prem decimal(10,3)
          default 0,
      pcommission decimal(4,2)
          default 0.00,
      mcommission integer
          default 0,
      pagent decimal(4,2)
          default 0.00,
      magent integer
          default 0,
      pdiscount decimal(4,2)
          default 0.00,
      mdiscount integer
          default 0,
      dpolicy date,
      iendorse char(20)
          default ' ',
      dendorse date,
      dedr_begin date,
      dedr_end date,
      fedr_status char(1)
          default ' ',
      napplicant char(30)
          default ' ',
      relation_appl char(1)
          default ' ',
      nbeneficiary char(30)
          default ' ',
      relation_bene char(1)
          default ' ',
      daily_pay integer
          default 0,
      mr_ins_prem integer
          default 0,
      mr_pure_prem decimal(10,3)
          default 0          
    )in dbsp_carloss extent size 480 next size 68 lock mode page;
    $revoke all on ca_pa_ply_last from "public";
    $create index pa_last_ix_1 on ca_pa_ply_last
        (ipolicy,iinsurant);
    $create unique index pa_last_ix_2 on ca_pa_ply_last
        (ipolicy,iins_type,iinsurant,iins_scope,icareer);
    $create index pa_last_ix_3 on ca_pa_ply_last
        (dpolicy);
    $grant all on ca_pa_ply_last to ipisnew;
    $revoke alter on ca_pa_ply_last from ipisnew;
    $grant select on ca_pa_ply_last to ipismis;
    printf("26.END   CREATE ca_pa_ply_last\n");
    
    printf("26.5 BEGIN CREATE ply_ins_cover_last\n");
    $create table "informix".ply_ins_cover_last
    (
	  ipolicy     char(20) 
	            default ' ',  
	  iins_type   char(6)  
	            default ' ', 
	  icover_type char(3)  
	            default ' ', 
	  mcover      integer  
	            default 0,
	  mcover_prem integer  
	            default 0,
	  mdiscount   integer  
	            default 0,
	  mprem       integer  
	            default 0,
	  mpure_prem  decimal(10,3) 
	            default 0.00
    )in dbsp_carloss extent size 23428 next size 3348 lock mode page;
         
    $revoke all on ply_ins_cover_last from "public";
    $create unique index idx_ply_ins_cover_last_u on ply_ins_cover_last
        (ipolicy,iins_type,icover_type);        
    $grant all on ply_ins_cover_last to ipisnew;
    $revoke alter on ply_ins_cover_last from ipisnew;
    $grant select on ply_ins_cover_last to ipismis;
    printf("26.6 END   CREATE ply_ins_cover_last\n");    
    
    printf("27.COMMIT WORK all last table process\n");
    $COMMIT WORK;
    
    printf("28.BEGIN WORK policy_302f\n");
    $BEGIN WORK;
    printf("29.BEGIN DROP policy_302f\n");
    $DROP TABLE policy_302f;
    printf("30.END DROP policy_302f\n");
    printf("31.BEGIN CREATE policy_302f\n");
    $create table "informix".policy_302f
    (
      ipolicy char(20)
          default ' ',
      ipolicy_1 char(20)
          default ' ',
      icard char(20)
          default ' ',
      fcard_class char(1)
          default ' ',
      irelative_ply char(20)
          default ' ',
      dply_bgn_comp date
          default  '10/11/2012',
      dply_end_comp date
          default  '10/11/2012',
      comp_prem integer
          default 0,
      last_policy_2 char(20)
          default ' ',
      last_policy_3 char(20)
          default ' ',
      qply_period smallint
          default 0,
      dply_begin date,
      dply_end date,
      nassured char(120)
          default ' ',
      ilicense char(10)
          default ' ',
      ibirth char(9)
          default ' ',
      fsex char(1)
          default ' ',
      fmarriage char(1)
          default ' ',
      nuser char(18)
          default ' ',
      nbenef char(42)
          default ' ',
      aassured char(90)
          default ' ',
      itel char(20)
          default ' ',
      iply_area char(10)
          default ' ',
      iissue_ym char(6)
          default ' ',
      ipro_year char(4)
          default ' ',
      ibrand char(8)
          default ' ',
      nbrand_abbr char(16)
          default ' ',
      icar_type char(2)
          default ' ',
      ncar_type char(16)
          default ' ',
      qcylinder integer
          default 0,
      iengine char(20)
          default ' ',
      ibody char(20)
          default ' ',
      itag char(8)
          default ' ',
      mcar_price char(10)
          default ' ',
      pdmg_align smallint
          default 0,
      pbrg_align smallint
          default 0,
      plia_align smallint
          default 0,
      qpt decimal(4,1)
          default 0.0,
      fpt char(1)
          default ' ',
      idmg_rate char(2)
          default ' ',
      ibrg_rate char(2)
          default ' ',
      psex_age decimal(15,12)
          default 0.00,
      lia_ac_cnt1 char(2)
          default ' ',
      lia_ac_cnt2 char(2)
          default ' ',
      lia_ac_cnt3 char(2)
          default ' ',
      lia_ac_cntc char(2)
          default ' ',
      dmg_ac_cnt1 char(2)
          default ' ',
      dmg_ac_cnt2 char(2)
          default ' ',
      dmg_ac_cnt3 char(2)
          default ' ',
      plia_acc char(4)
          default ' ',
      pdmg_acc char(4)
          default ' ',
      plia_acc_c char(5)
          default ' ',
      fcar_class char(1)
          default ' ',
      dedr_begin date,
      iofficer char(10)
          default ' ',
      nname char(10)
          default ' ',
      ibig_office char(9)
          default ' ',
      ibig_sales char(10)
          default ' ',
      ibig_policy char(20)
          default ' ',
      ibig_comp char(1)
          default ' ',
      ibig_branch char(4)
          default ' ',
      mbusiness decimal(8,3)
          default 0.000,
      fcomp_class char(2)
          default ' ',
      fcomp_class_last char(2)
          default ' ',
      ileader char(10)
          default ' ',
      aassured_zip char(5)
          default ' ',
      irel_card char(17)
          default ' ',
      irel_card_2 char(17)
          default ' ',
      irel_card_3 char(17)
          default ' ',
      iquota char(6)
          default ' ',
      nchi_full char(30),
      fnation char(1)
          default ' ',
      v_prem integer
          default 0,
      tot_prem integer
          default 0,
      ch_ins_grp1 char(55)
          default ' ',
      ch_ins_grp2 char(55)
          default ' ',
      ch_ins_grp3 char(55)
          default ' ',
      pre_dply1_bgn date,
      pre_dply1_end date,
      pre_prem1 char(6),
      pre_prem2 char(6),
      pre_dply2_bgn date,
      pre_dply2_end date,
      pre_sex_age char(5)
          default ' ',
      pre_lia_acc char(5)
          default ' ',
      pre_dmg_acc char(5)
          default ' ',
      note1 char(20)
          default ' ',
      linnum integer
          default 0,
      nbrand char(20),
      remark1 char(100)
          default ' ',
      remark2 char(100)
          default ' ',
      remark6 char(100)
          default ' ',
      remark7 char(100)
          default ' ',
      ibig_nname char(10)
          default ' ',
      mdiscount integer
          default 0,
      tot_mpay integer
          default 0,
      pre_ch_ins_grp1 varchar(55),
      pre_ch_ins_grp2 varchar(55),
      pre_ch_ins_grp3 varchar(55),
      icorps          char(10),
      ncorps          char(30),
      pdiscount       decimal(4,2) default 0,
      fcomp_24        char(1) default 'N',
      remark3         char(736),
      fassured        char(1) default ' ',
      tphone_con char(20),
      imovephone char(20),
      iemail char(50),
      psex_age_c decimal(5,2)  default 0,
      psex_age_v decimal(5,2)  default 0,
      dmg_factor decimal(7,4)  default 0,
      brg_factor decimal(7,4)  default 0,
      v_ori_prem integer       default 0,
      c_tot_prem integer       default 0,
      remark4    char(100)     default ' ',
      remark5    char(140)     default ' ',
      nequipment char(30)      default ' ',
      iquota_tel char(20)      default ' ',
      iquota_fax char(20)      default ' ',
      ichange_note varchar(128)   default ' ',
      nofficer   char(10)      default ' ',
      nbroker    char(12)      default ' ' 
    ) in dbsp_carloss extent size 222560 next size 31796 lock mode page;
    $revoke all on "informix".policy_302f from "public";
    $create index "informix".p32f_idx_4 on "informix".policy_302f (dply_begin,
        ibig_comp,ibig_office);
    $create unique index "informix".p32f_idx_1 on "informix".policy_302f
        (ipolicy);
    $create index "informix".p32f_idx_2 on "informix".policy_302f (dply_begin);
    $create index "informix".p32f_idx_3 on "informix".policy_302f (iquota);
    $create index "informix".p32f_idx_5 on "informix".policy_302f (dply_begin,
        ibig_comp,ibig_sales);
    $grant all on policy_302f to ipisnew;
    $revoke alter on policy_302f from ipisnew;
    $grant select on policy_302f to ipismis;
    printf("32.END   CREATE policy_302f\n");
    $COMMIT WORK;

    printf("34.BEGIN WORK ply_ins_type_302f\n");
    $BEGIN WORK;
    printf("35.BEGIN DROP ply_ins_type_302f\n");
    $drop table ply_ins_type_302f;
    printf("36.END DROP ply_ins_type_302f\n");

    printf("37.BEGIN CREATE ply_ins_type_302f\n");
    $create table "informix".ply_ins_type_302f
    (
      ipolicy char(20)
          default ' ',
      iins_type char(6)
          default ' ',
      minjured_cover integer
          default 0,
      mdeath_cover integer
          default 0,
      mdamage_cover integer
          default 0,
      mdeduct integer
          default 0,
      mprem integer
          default 0,
      mins_premium integer
          default 0,
      qcoverage smallint
          default 0,
      pre_inj_cover integer,
      pre_dea_cover integer,
      pre_dam_cover integer,
      pre_deduct integer,
      pre_minsprem integer,
      qserial smallint
          default 0,
      ch_deduct char(12)
          default ' ',
      linnum integer
          default 0,
      mdiscount integer
          default 0,
      pre_mdiscount integer
          default 0,
      qday integer
          default 0,
      mexpense integer
          default 0,
      mexp_disc integer
          default 0,
      ori_inj_cover integer
        default 0,
      ori_dea_cover integer
        default 0,
      ori_dam_cover integer
        default 0,
      ori_premium integer
        default 0,
      iins_cnt integer
        default 0,
      daily_pay integer
        default 0,
      ninsurant_pa char(8)  
        default ' ',
      iinsurant_pa char(10) 
        default ' ',
      ibirth_pa char(7)  
        default ' ',
      nbenif_pa char(10)  
        default ' ',
      irel_pa char(10)  
        default ' ',
      ori_daily_pay integer
        default 0,
      pre_daily_pay integer
        default 0         
    ) in dbsp_carloss extent size 55024 next size 7860 lock mode page;
    $revoke all on "informix".ply_ins_type_302f from "public";
    $create unique index "informix".pins32f_idx_1 on "informix".ply_ins_type_302f
        (ipolicy,iins_type);
    $create index "informix".pins32f_idx_2 on "informix".ply_ins_type_302f
        (ipolicy);
    $grant all on ply_ins_type_302f to ipisnew;
    $revoke alter on ply_ins_type_302f from ipisnew;
    $grant select on ply_ins_type_302f to ipismis;

    $COMMIT WORK;
    printf("38.END   CREATE ply_ins_type_302f\n");


    /********************* 960705���ѡG �H�U�϶�"�M�~"�Ҧ� "_302" ��  **********************/  
    /***                   ( "�M�~"�覡 => 1. �ؤ@�� "_302t" table                     ***/
    /***                   (            => 2. �N "_302" INSERT �� "_302t"              ***/
    /***                   (            => 3. "_302" Rename��"_bak"�Adrop "_bak"       ***/
    /***                   (            => 4. "_302t" Rename��"_302"     )             ***/    
    /*************************************************************************************/
    $BEGIN WORK;
    printf("39.BEGIN WORK policy_302t\n");
 
    printf("40.BEGIN CREATE policy_302t\n");
    $create table "informix".policy_302t
    (
      ipolicy char(20)
          default ' ',
      ipolicy_1 char(20)
          default ' ',
      icard char(20)
          default ' ',
      fcard_class char(1)
          default ' ',
      irelative_ply char(20)
          default ' ',
      dply_bgn_comp date
          default  '10/11/2012',
      dply_end_comp date
          default  '10/11/2012',
      comp_prem integer
          default 0,
      last_policy_2 char(20)
          default ' ',
      last_policy_3 char(20)
          default ' ',
      qply_period smallint
          default 0,
      dply_begin date,
      dply_end date,
      nassured char(120)
          default ' ',
      ilicense char(10)
          default ' ',
      ibirth char(8)
          default ' ',
      fsex char(1)
          default ' ',
      fmarriage char(1)
          default ' ',
      nuser char(18)
          default ' ',
      nbenef char(42)
          default ' ',
      aassured char(90)
          default ' ',
      itel char(20)
          default ' ',
      iply_area char(10)
          default ' ',
      iissue_ym char(5)
          default ' ',
      ipro_year char(4)
          default ' ',
      ibrand char(8)
          default ' ',
      nbrand_abbr char(16)
          default ' ',
      icar_type char(2)
          default ' ',
      ichange_note varchar(128) 
          default ' ',
      ncar_type char(16)
          default ' ',
      qcylinder integer
          default 0,
      iengine char(20)
          default ' ',
      ibody char(20)
          default ' ',
      itag char(8)
          default ' ',
      mcar_price char(10)
          default ' ',
      pdmg_align smallint
          default 0,
      pbrg_align smallint
          default 0,
      plia_align smallint
          default 0,
      qpt decimal(4,1)
          default 0.0,
      fpt char(1)
          default ' ',
      idmg_rate char(2)
          default ' ',
      dmg_factor decimal(7,4)
          default 0,
      ibrg_rate char(2)
          default ' ',
      brg_factor decimal(7,4)
          default 0,
      psex_age decimal(15,12)
          default 0.00,
      psex_age_damage decimal(15,12)
          default 0.00,          
      lia_ac_cnt1 char(2)
          default ' ',
      lia_ac_cnt2 char(2)
          default ' ',
      lia_ac_cnt3 char(2)
          default ' ',
      lia_ac_cntc char(2)
          default ' ',
      dmg_ac_cnt1 char(2)
          default ' ',
      dmg_ac_cnt2 char(2)
          default ' ',
      dmg_ac_cnt3 char(2)
          default ' ',
      plia_acc char(4)
          default ' ',
      pdmg_acc char(4)
          default ' ',
      plia_acc_c char(5)
          default ' ',
      fcar_class char(1)
          default ' ',
      dedr_begin date,
      iofficer char(10)
          default ' ',
      nname char(10)
          default ' ',
      ibig_office char(9)
          default ' ',
      ibig_sales char(10)
          default ' ',
      ibig_policy char(20)
          default ' ',
      ibig_comp char(1)
          default ' ',
      ibig_branch char(4)
          default ' ',
      mbusiness decimal(8,3)
          default 0.000,
      fcomp_class char(2)
          default ' ',
      fcomp_class_last char(2)
          default ' ',
      ileader char(10)
          default ' ',
      aassured_zip char(5)
          default ' ',
      irel_card char(17)
          default ' ',
      irel_card_2 char(17)
          default ' ',
      irel_card_3 char(17)
          default ' ',
      iquota char(6)
          default ' ',
      nchi_full char(30),
      fnation char(1)
          default ' ',
      v_prem integer
          default 0,
      v_ori_prem integer
          default 0,
      tot_prem integer
          default 0,
      ch_ins_grp1 char(55)
          default ' ',
      ch_ins_grp2 char(55)
          default ' ',
      ch_ins_grp3 char(55)
          default ' ',
      pre_dply1_bgn date,
      pre_dply1_end date,
      pre_prem1 char(6),
      pre_prem2 char(6),
      pre_dply2_bgn date,
      pre_dply2_end date,
      pre_sex_age char(5)
          default ' ',
      pre_sex_age_damage char(5)
          default ' ',             
      pre_lia_acc char(5)
          default ' ',
      pre_dmg_acc char(5)
          default ' ',
      note1 char(20)
          default ' ',
      linnum integer
          default 0,
      nbrand char(20),
      remark1 char(100)
          default ' ',
      remark2 char(100)
          default ' ',
      remark6 char(100)
          default ' ',
      remark7 char(100)
          default ' ',
      ibig_nname char(10)
          default ' ',
      mdiscount integer
          default 0,
      tot_mpay integer
          default 0,
      pre_ch_ins_grp1 varchar(55),
      pre_ch_ins_grp2 varchar(55),
      pre_ch_ins_grp3 varchar(55),
      icorps          char(10),
      ncorps          char(30),
      pdiscount       decimal(4,2) default 0,
      fcomp_24        char(1) default 'N',
      remark3         char(736),
      fassured        char(1)  default ' ',
      tphone_con char(20),
      imovephone char(20),
      iemail char(50),
      remark4 varchar(100) default ' ',
      remark5 varchar(100) default ' ',
      nproject char(20)    default ' ',
      lia_class char(2)    default ' ',
      nequipment   char(30) default ' ',
      option       int      default 9 ,
      dbirth           	DATE DEFAULT NULL,
      dissue           	DATE DEFAULT NULL 
    ) in dbsp_carloss extent size 2102536 next size 300364 lock mode page;

    printf("41.END   CREATE policy_302t\n");
    printf("42.COMMIT WORK CREATE policy_302t\n");
    $COMMIT WORK;

    printf("43.BEGIN TRANSFERING policy_302 -> policy_302t\n");

    main_cnt = 0;
    new_cnt  = 0;
    $SELECT count(*)
       INTO $main_cnt
       FROM policy_302;

    printf("44.BEGIN INSERT INTO policy_302t\n");
    $BEGIN WORK;
    ccnt = 0;
    EXEC SQL DECLARE cur_C CURSOR WITH HOLD FOR
              SELECT ipolicy
                FROM policy_302;
    EXEC SQL OPEN cur_C;
    for(;;)
    {
           EXEC SQL FETCH cur_C INTO :ipolicy;
           if (SQLCODE == SQLNOTFOUND) break;

           ccnt ++;

           $INSERT INTO policy_302t
            SELECT *
              FROM policy_302
             WHERE ipolicy = :ipolicy;

           if (ccnt == 1000)
           {
              ccnt = 0;
              EXEC SQL COMMIT WORK;
              EXEC SQL BEGIN WORK;
           }
    }
    EXEC SQL CLOSE cur_C;
    EXEC SQL FREE  cur_C;
    $COMMIT WORK;
    printf("45.END INSERT INTO policy_302t\n");

    $SELECT count(*)
       INTO $new_cnt
       FROM policy_302t;

    if (main_cnt != new_cnt)
    {
         printf("46.�s��policy_302t[%ld]�P����policy_302[%ld]�����Ƥ��P\n",new_cnt, main_cnt);
    }

    printf("47.END TRANSFERING policy_302 -> policy_302t\n");

    $BEGIN WORK;

    printf("48.BEGIN RENAME TABLE policy_302 -> policy_302_bak\n");
    $RENAME TABLE policy_302 TO policy_302_bak;
    printf("49.END   RENAME TABLE policy_302 -> policy_302_bak\n");

    printf("50.BEGIN DROP TABLE policy_302_bak\n");
    $DROP   TABLE policy_302_bak;
    printf("51.END   DROP TABLE policy_302_bak\n");

    printf("52.BEGIN RENAME TABLE policy_302t -> policy_302\n");
    $RENAME TABLE policy_302t TO policy_302;
    printf("53.END   RENAME TABLE policy_302t -> policy_302\n");

    printf("54.BEGIN CREATE policy_302 INDEX \n");
    $revoke all on "informix".policy_302 from "public";
    $create index "informix".p32_idx_4 on "informix".policy_302 (dply_begin, ibig_comp,ibig_office);
    $create unique index "informix".p32_idx_1 on "informix".policy_302 (ipolicy);
    $create index "informix".p32_idx_2 on "informix".policy_302 (dply_begin);
    $create index "informix".p32_idx_3 on "informix".policy_302 (iquota);
    $create index "informix".p32_idx_5 on "informix".policy_302 (dply_begin, ibig_comp,ibig_sales);
    $create index "informix".p32_idx_6 on "informix".policy_302 (itag);
    $create index "informix".p32_idx_7 on "informix".policy_302 (iengine);
    $create index "informix".p32_idx_8 on "informix".policy_302 (ilicense);

    $grant all on policy_302 to ipisnew;
    $revoke alter on policy_302 from ipisnew;
    $grant select on policy_302 to ipismis;
    printf("55.END   CREATE policy_302 INDEX \n");

    $COMMIT WORK;
    printf("56.COMMIT WORK policy_302\n");

    printf("57.BEGIN CREATE ply_ins_type_302t\n");
    $BEGIN WORK;
    $create table "informix".ply_ins_type_302t
    (
        ipolicy char(20)
            default ' ',
        iins_type char(6)
            default ' ',
        minjured_cover integer
            default 0,
        mdeath_cover integer
            default 0,
        mdamage_cover integer
            default 0,
        mdeduct integer
            default 0,
        mprem integer
            default 0,
        mins_premium integer
            default 0,
        qcoverage smallint
            default 0,
        pre_inj_cover integer,
        pre_dea_cover integer,
        pre_dam_cover integer,
        pre_deduct integer,
        pre_minsprem integer,
        qserial smallint
            default 0,
        ch_deduct char(12)
            default ' ',
        linnum integer
            default 0,
        mdiscount integer
            default 0,
        pre_mdiscount integer
            default 0,
        qday  integer
            default 0,
        mexpense integer
            default 0,
        mexp_disc integer
            default 0,
        drate_ym  char(4)
            default ' ',
        ori_inj_cover integer
            default 0,
        ori_dea_cover integer
            default 0,
        ori_dam_cover integer
            default 0,
        ori_deduct integer
            default 0,
        ori_premium integer
            default 0,
        provision char(2)
            default ''
    ) in dbsp_carloss extent size 374664 next size 53524 lock mode page;
    printf("58.END   CREATE ply_ins_type_302t\n");
    $COMMIT WORK;

    printf("59.BEGIN TRANSFERING ply_ins_type_302 -> ply_ins_type_302t\n");
    main_cnt = 0;
    new_cnt = 0;

    $SELECT count(*)
       INTO $main_cnt
       FROM ply_ins_type_302;

    printf("60.BEGIN INSERT ply_ins_type_302t \n");
    $BEGIN WORK;
    ccnt = 0;
    EXEC SQL DECLARE cur_E CURSOR WITH HOLD FOR
              SELECT ipolicy
                INTO :ipolicy
                FROM policy_302;
    EXEC SQL OPEN cur_E;
    for(;;)
    {
        EXEC SQL FETCH cur_E;
        if (SQLCODE == SQLNOTFOUND) break;

        ccnt ++;

        $INSERT INTO ply_ins_type_302t
         SELECT *
           FROM ply_ins_type_302
          WHERE ipolicy = :ipolicy;

        if (ccnt == 1000)
        {
           ccnt = 0;
           EXEC SQL COMMIT WORK;
           EXEC SQL BEGIN WORK;
        }
    }
    EXEC SQL CLOSE cur_E;
    EXEC SQL FREE  cur_E;
    printf("61.BEGIN INSERT ply_ins_type_302t \n");

    $COMMIT WORK;

    $SELECT count(*)
       INTO $new_cnt
       FROM ply_ins_type_302t;

    if (main_cnt != new_cnt)
    {
          printf("62.�s��ply_ins_type_302t[%ld]�P����ply_ins_type_302[%ld]�����Ƥ��P\n",new_cnt,main_cnt);
    }

    $BEGIN WORK;

    printf("63.BEGIN RENAME TABLE ply_ins_type_302 -> plyinstp302bak \n");
    $RENAME TABLE ply_ins_type_302 TO plyinstp302bak;
    printf("64.END   RENAME TABLE ply_ins_type_302 -> plyinstp302bak \n");

    printf("65.BEGIN DROP TABLE plyinstp302bak\n");
    $DROP TABLE plyinstp302bak;
    printf("66.END   DROP TABLE plyinstp302bak\n");

    printf("67.BEGIN RENAME TABLE ply_ins_type_302t -> ply_ins_type_302 \n");
    $RENAME TABLE ply_ins_type_302t TO ply_ins_type_302;
    printf("68.END   RENAME TABLE ply_ins_type_302t -> ply_ins_type_302 \n");

    printf("69.BEGIN CREATE ply_ins_type_302 INDEX\n");
    $revoke all on "informix".ply_ins_type_302 from "public";
    $create unique index "informix".pins32_idx_1 on "informix".ply_ins_type_302 (ipolicy,iins_type);
    $create index "informix".pins32_idx_2 on "informix".ply_ins_type_302 (ipolicy);
    $grant all on ply_ins_type_302 to ipisnew;
    $revoke alter on ply_ins_type_302 from ipisnew;
    $grant select on ply_ins_type_302 to ipismis;
    printf("70.END   CREATE ply_ins_type_302 INDEX\n");
    $COMMIT WORK;
    printf("71.COMMIT WORK ply_ins_type_302\n");

    $BEGIN WORK;
    printf("72.BEGIN WORK ca_pa_ply_302t\n");
    printf("73.BEGIN CREATE ca_pa_ply_302t\n");
    $create table "informix".ca_pa_ply_302t
    (
        ipolicy char(20)
            default ' ',
        iins_type char(6)
            default ' ',
        iinsurant char(10)
            default ' ',
        ninsurant char(30)
            default ' ',
        dbirth date,
        ainsurant char(90)
            default ' ',
        iins_scope char(1)
            default ' ',
        icareer char(1)
            default ' ',
        mins_amt integer
            default 0,
        mins_premium integer
            default 0,
        mdiscount    integer
            default 0,
        napplicant char(30)
            default ' ',
        relation_appl char(1)
            default ' ',
        nbeneficiary char(30)
            default ' ',
        relation_bene char(1)
            default ' ',
        daily_pay integer
            default 0,
        mr_ins_prem integer
            default 0,
        mr_pure_prem decimal(10,3)
            default 0,
        ori_daily_pay integer
            default 0,
        pre_daily_pay integer
            default 0                    
    )in dbsp_carloss extent size 2312 next size 332 lock mode page;
    printf("74.END   CREATE ca_pa_ply_302t\n");
    $COMMIT WORK;

    main_cnt = 0;
    new_cnt = 0;

    $SELECT count(*)
       INTO $main_cnt
       FROM ca_pa_ply_302;

    $BEGIN WORK;
    printf("75.BEGIN INSERT ca_pa_ply_302t \n");
    $INSERT INTO ca_pa_ply_302t
     SELECT *
       FROM ca_pa_ply_302 ;

    $SELECT count(*)
       INTO $new_cnt
       FROM ca_pa_ply_302t;

    if (main_cnt != new_cnt)
    {
          printf("76.�s��ca_pa_ply_302t[%ld]�P����ca_pa_ply_302[%ld]�����Ƥ��P\n",new_cnt,main_cnt);
    }

    $COMMIT WORK;

    /* Working  */

    $BEGIN WORK;
    printf("77.BEGIN DROP TABLE ca_pa_ply_302\n");
    $DROP TABLE ca_pa_ply_302;
    printf("78.END   DROP TABLE ca_pa_ply_302\n");

    printf("79.BEGIN RENAME TABLE ca_pa_ply_302t -> ca_pa_ply_302 \n");
    $RENAME TABLE ca_pa_ply_302t TO ca_pa_ply_302;
    printf("80.END   RENAME TABLE ca_pa_ply_302t -> ca_pa_ply_302 \n");

    printf("81.BEGIN CREATE ca_pa_ply_302 INDEX\n");

    $create index pa_302_ix_1 on ca_pa_ply_302 (ipolicy,iinsurant);
    $create unique index pa_302_ix_2 on ca_pa_ply_302 (ipolicy,iins_type,iinsurant,iins_scope,icareer);

    $revoke all on "informix".ca_pa_ply_302 from "public";
    $grant all on ca_pa_ply_302 to ipisnew;
    $revoke alter on ca_pa_ply_302 from ipisnew;
    $grant select on ca_pa_ply_302 to ipismis;

    printf("82.END   CREATE ca_pa_ply_302 INDEX\n");

    printf("83.COMMIT WORK ca_pa_ply_302\n");
    $COMMIT WORK;

    /* End Working */
    
    
    printf("83.1 BEGIN CREATE ply_ins_cover_302t\n");
    $BEGIN WORK;
    $create table "informix".ply_ins_cover_302t
    (
        ipolicy      char(20)
            default ' ',
        iins_type    char(6)
            default ' ',
        icover_type  char(3)
            default ' ',
        mcover            integer 
            default 0,        
        mcover_prem       integer 
            default 0,        
        mdiscount         integer 
            default 0,        
        mprem             integer 
            default 0,        
        pre_mcover        integer 
            default 0,        
        pre_mcover_prem   integer 
            default 0,        
        pre_mdiscount     integer 
            default 0,        
        pre_mprem         integer 
            default 0,        
        ori_mcover        integer 
            default 0,        
        ori_mcover_prem   integer 
            default 0,        
        ori_mdiscount     integer 
            default 0,        
        ori_mprem         integer 
            default 0
    ) in dbsp_carloss  extent size 58112 next size 8300 lock mode page;    
                   
    printf("83.2 END   CREATE ply_ins_cover_302t\n");
    $COMMIT WORK;

    printf("83.3 BEGIN TRANSFERING ply_ins_cover_302 -> ply_ins_cover_302t\n");
    main_cnt = 0;
    new_cnt = 0;

    $SELECT count(*)
       INTO $main_cnt
       FROM ply_ins_cover_302;

    printf("83.4 BEGIN INSERT ply_ins_cover_302t \n");
    $BEGIN WORK;
    ccnt = 0;
    EXEC SQL DECLARE cur_F CURSOR WITH HOLD FOR
              SELECT ipolicy
                INTO :ipolicy
                FROM policy_302;
    EXEC SQL OPEN cur_F;
    for(;;)
    {
        EXEC SQL FETCH cur_F;
        if (SQLCODE == SQLNOTFOUND) break;

        tmp_cnt  = 0;             

		$SELECT count(*)
		   INTO $tmp_cnt
		   FROM ply_ins_cover_302
		  WHERE ipolicy= :ipolicy;
		       
	      if (tmp_cnt>0){
               
		      $INSERT INTO ply_ins_cover_302t
		       SELECT *
		         FROM ply_ins_cover_302
		        WHERE ipolicy = :ipolicy;
		        
              ccnt++;
          }
          if (ccnt == 1000)
          {
              ccnt = 0;
              EXEC SQL COMMIT WORK;
              EXEC SQL BEGIN WORK;
          }
    }
    EXEC SQL CLOSE cur_F;
    EXEC SQL FREE  cur_F;
    printf("83.5 BEGIN INSERT ply_ins_cover_302t \n");

    $COMMIT WORK;

    $SELECT count(*)
       INTO $new_cnt
       FROM ply_ins_cover_302t;

    if (main_cnt != new_cnt)
    {
          printf("83.6 �s��ply_ins_cover_302t[%ld]�P����ply_ins_cover_302[%ld]�����Ƥ��P\n",new_cnt,main_cnt);
    }

    $BEGIN WORK;

    printf("83.7 BEGIN RENAME TABLE ply_ins_cover_302 -> ply_ins_cover_bak \n");
    $RENAME TABLE ply_ins_cover_302 TO ply_ins_cover_bak;
    printf("83.8 END   RENAME TABLE ply_ins_cover_302 -> ply_ins_cover_bak \n");

    printf("83.9 BEGIN DROP TABLE ply_ins_cover_bak\n");
    $DROP TABLE ply_ins_cover_bak;
    printf("83.91 END   DROP TABLE ply_ins_cover_bak\n");

    printf("83.92 BEGIN RENAME TABLE ply_ins_cover_302t -> ply_ins_cover_302 \n");
    $RENAME TABLE ply_ins_cover_302t TO ply_ins_cover_302;
    printf("83.93 END   RENAME TABLE ply_ins_cover_302t -> ply_ins_cover_302 \n");

    printf("83.94 BEGIN CREATE ply_ins_cover_302 INDEX\n");
    $revoke all on "informix".ply_ins_cover_302 from "public";
    $create unique index "informix".idx_ply_ins_cover_302_u on  "informix".ply_ins_cover_302(ipolicy,iins_type,icover_type);    
    $grant all on ply_ins_cover_302 to ipisnew;
    $revoke alter on ply_ins_cover_302 from ipisnew;
    $grant select on ply_ins_cover_302 to ipismis;
    printf("83.95 END   CREATE ply_ins_cover_302 INDEX\n");
    
    $COMMIT WORK;
    printf("83.96 COMMIT WORK ply_ins_cover_302\n");

   /********************* 960705���ѡG �H�U�϶� UPDATE STATISTICS �Ҧ� "_302" ��  **********************/ 

    printf("83.97 BEGIN UPDATE STATISTICS HIGH ply_ins_cover_302\n");
    $UPDATE STATISTICS FOR TABLE ply_ins_cover_302;
    printf("83.98 END   UPDATE STATISTICS HIGH ply_ins_cover_302\n");    
    
    printf("84.BEGIN UPDATE STATISTICS HIGH ply_ins_type_302\n");
    $UPDATE STATISTICS FOR TABLE ply_ins_type_302;
    printf("85.END   UPDATE STATISTICS HIGH ply_ins_type_302\n");

    printf("86.BEGIN UPDATE STATISTICS HIGH policy_302\n");
    $UPDATE STATISTICS FOR TABLE policy_302;
    printf("87.END   UPDATE STATISTICS HIGH policy_302\n");

    printf("88.BEGIN UPDATE STATISTICS HIGH ca_pa_ply_302\n");
    $UPDATE STATISTICS FOR TABLE ca_pa_ply_302;
    printf("89.END   UPDATE STATISTICS HIGH ca_pa_ply_302\n");
    
    printf("90.BEGIN DELETE trans_fclass_302 TABLE\n");
    $BEGIN WORK;
    $DELETE FROM trans_fclass_302
      WHERE 1=1;
    $COMMIT WORK;
    printf("91.END   DELETE trans_fclass_302 TABLE\n");    

    printf("�����ɶ�[%s]\n",cm_get_sysd());

    printf("�@�~���� OK\n");

    exit(1);

errexit:
    printf("MAIN FUNCTION FALSE\n");
    printf("�@�~���� ���� \n");
    printf("SQLCODE=%d,errmsg=%s\n,Errmsg = [%s]",SQLCODE,sqlca.sqlerrm,Errmsg);
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
exit(1);
}

char *substring(s, off, len)
char *s;
short off, len;
{
    static char rtnStr[256];

    memcpy(rtnStr, s+off-1, len);
    rtnStr[len] = '\0';

    return rtnStr;
}    

