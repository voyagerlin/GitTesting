/************************************************
 * Copyright (C) 1995 Intellisys Corporation    *
 *                                              *
 * Program : car9990.ec                         *
 *      ��o�i���߸�ƳB�z:�j����`�H��������   *
 ************************************************/
#include <stdio.h>
#include "api_xsrv.h"
#include "sqlfatal.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "car_common.h"
#include "safeclib.h"

/* standard data declaration */
  FILE *fptr, *fptr_err;
  $char userid[11], iquota[7];
  char prtfile[80],outputf[80],outputf1[80];
  char errmsg[200];
  $char errFile[120];
/* end of standard data */
/* private data */
/* end of private data */

$char localdb[5],Taipei_FullName[20];
int  i, flag_check=0;
/* end of standard defined data */

char expdate[6];
char bgndate[10],enddate[10];
char option[2];
$static char remotedb[DBNAME];

int   count_db,k; 

$char DBName[05];
$char msgbuf[128];
DBinfo *list;
char  sApHome[30];
int   rtncode,rc;
char  filename[30];
FILE  *fp;
char  file_catalog[200];
$char filename1[200];
$char data_yyyymm[7];

$char iproduct_tmp[3];
$long mprem_14 = 0,mprem_15 = 0,mprem_16 = 0;
$long mhealth_14 = 0,mhealth_15 = 0,mhealth_16 = 0;

long car9990_get_db();
long car9990_build();
long car9990_final();
/*************************************************************/

main(argc,argv)
int argc;
char **argv;
{
	int rtncode,rc;

	strcpy(DBName,       isNULLstr(argv[1]));
	strcpy(userid,       isNULLstr(argv[2]));
	strcpy(expdate,      isNULLstr(argv[3]));
	strcpy(outputf,      isNULLstr(argv[4]));
	
	printf("DBName[%s],userid[%s],expdate[%s],outputf[%s] \n",DBName,userid,expdate,outputf);
	
	rc = car9990_get_db();
	if (rc != M_CM_OK)
	{
		return rc;
	}
	
	rc = car9990_build();
	if ( rc != SUCCESS ) {
	 	printf("error on car9991_build \n");
	 	EWRITE(userid, rc, errmsg);
		return rc;	
	}
	
	rc = car9990_final();
	if ( rc != SUCCESS ) {
	 	printf("error on car9991_show \n");
	 	EWRITE(userid, rc, errmsg);
		return rc;	
	}
}

long car9990_get_db()
{
	$whenever sqlerror goto errexit1;

	if (db_select(DBName) == DBName) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}
	
	rc = getApHome(sApHome);
	if (rc < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		EWRITE(userid,rc,msgbuf);
	 	return rc;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}	
	return M_CM_OK;

errexit1:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
long car9990_build()
{
	$long  dwritten_l;
	$char  drate_c[11];
	int    endyy,endmm;
	char   drate_yy[5],drate_mm[3],drate_dd[3];
	$char  iissue_yy[5];
	char   bgn_yy[5],bgn_mm[3],end_mm[3],prtstr[460];
	int    res;
	$static date   Today;
	$char aphome[40];
	$char stmt[4096];
	$char fstl[2],dclaim[17],iacc_license[11];
	$char iclaim[21];
	$char daccident[14],ipolicy[21];
	$long long_daccident = 0;
	$long dply_begin,dply_end,bgndate_l,enddate_l,count1;
	$int iclose_type = 0;
	$date dgroup,sta_dgroup;
	char prtstr_1to14[102],prtstr_1to25[102],dclaim_yyyy[5],dclaim_mm[3],dclaim_dd[3];
	char ipolicy_5to19[13],dgroup_c[11],dgroup_yy[5],dgroup_mm[3],dgroup_dd[3];
	$char buf1[21],iins_item[5],ivictim[11],ivictim2[11];
	$char daccident_yyyy[5],daccident_mm[3],daccident_dd[3];
	$char dhosp_start_c[11],dhosp_start_yyyy[5],dhosp_start_yy[5],dhosp_start_mm[3],dhosp_start_dd[3];
	$char iclose_type_c[3],mhealth_c[13],iserial_c[10];
	$char dgroup_e[11];
	$char istl_flag[2];
	$long iself_duty = 0,ioth_duty,ianoth_duty;
	$char sTmp[51];
	$char iproduct[13],drate_ym[5];
	 char ttday[21],ttday_yy[5],ttday_mm[3],ttday_dd[3];
	$char  icode[11];
	$char  iclaim_a[21];
	char   companyid[3];
	int    rtn,idx;
	$char  company_flag,iclaim_flag;
	char   COMPANY_P[3];
	char   COMPANY_F[3];
	$int   cnt;
	
	$char sIverify[21],sFsubrogation[2];
	$char chk_dpolicy[2];
	$char fvictim_nation[2];
	$int cnt_flast,iserial = 0,total_flast;
	$char dhosp_start[11],fhealth[2];
	$int mhealth,sum_mhealth; 
	$char flast[2];

	/* ca_dev_clm_health_comp */
	$char t_data_yyyymm[7],t_iclm_company[3],t_iclm_br[3],t_iclaim[15],t_daccident[9],t_dclaim[9],t_istl_flag[2],t_dgroup[9];
	$char t_fsubrogation[2],t_fvictim_nation[2],t_ivictim[11],t_fhealth[2],t_flast[2],t_dhosp_start[9],t_dsend[9];
	$long t_iclose_type,t_iself_duty,t_mhealth,t_iserial;

	filename[0] = '\0';
	file_catalog[0] = '\0';
	sprintf_s(filename,30,"%s/rptftp/", sApHome);
	sprintf_s(filename1,200,"AUTOM17_%d.txt",atoi(expdate)+191100);
	strcpy(file_catalog, trim(filename));
	strcat(file_catalog, trim(filename1));
	printf("file_catalog[%s] \n",file_catalog);
	
	if ((fptr=fopen(file_catalog,"w")) == NULL)
	{
		sprintf_s(errmsg,200,"Cannot open print file:%s",outputf);
		return M_CM_OPEN_FILE_FAIL;
	}

	/* *** open error log file *** */
	res = getApHome(aphome);
	sprintf_s(errFile,120,"%s.%s.error",outputf,DBName);
	printf("ERRFILE[%s]\n",errFile);
	if ((fptr_err=fopen(errFile,"w")) == NULL)
	{
		sprintf_s(errmsg,200,"Cannot open print file: %s",errFile);
		return M_CM_OPEN_FILE_FAIL;
	}
	
	printf(">>>expdate=%s\n",expdate);
	strncpy(bgn_yy,&expdate[0],3); bgn_yy[3]='\0';
	strncpy(bgn_mm,&expdate[3],2); bgn_mm[2]='\0';
	if (strncmp(bgn_mm, "12",2) == 0)
	{
		endyy=atoi(bgn_yy)+1;
		endmm=1;
	}
	else
	{
		endyy=atoi(bgn_yy);
		endmm=atoi(bgn_mm)+1;
	}
	rfmtlong(endmm,"&&",end_mm);
	
	sprintf_s(bgndate,10,"%s/%s/%s",bgn_yy,bgn_mm,"01");
	sprintf_s(enddate,10,"%d/%s/%s",endyy,end_mm,"01");
	sprintf_s(data_yyyymm,7,"%s%s",itoa(atoi(bgn_yy)+1911),bgn_mm);
	printf("########[car9990] bgndate=[%s] enddate=[%s]\n",bgndate,enddate);

	$WHENEVER SQLERROR GOTO errexit;

	bgndate_l=cm_ymd_cdate(bgndate);
	enddate_l=cm_ymd_cdate(enddate);

	/*43 ��ƻs�e���*/
	strcpy(ttday , cm_get_sysd());
	strncpy(ttday_yy,&ttday[0],4); ttday_yy[4] = '\0';
	strncpy(ttday_mm,&ttday[5],2); ttday_mm[2] = '\0';
	strncpy(ttday_dd,&ttday[8],2); ttday_dd[2] = '\0';

	sum_mhealth = 0;
	count1 = 0;
	prtstr_1to25[0]='\0';
	prtstr_1to14[0]='\0';
	
	for(k=0;k<count_db;k++)
	{
		sprintf_s(stmt,4096,"DELETE FROM %s:ca_dev_clm_health_comp WHERE data_yyyymm = '%s' ",list[k].dbname,data_yyyymm);
		$PREPARE DE_ca_dev_clm_health_comp FROM $stmt;
		$EXECUTE DE_ca_dev_clm_health_comp;
		
		sprintf_s(stmt,4096,"SELECT fstl,istl_flag,iclaim,iclose_type,iself_duty,dgroup,dgroup \
		                FROM %s:settlement a \
		               WHERE fcard_class = '1' \
		                 AND dgroup >= %ld \
		                 AND dgroup < %ld \
		                 AND (msettle != 0 OR  \
		                      (SELECT NVL(SUM(mins_proc),0)  \
		                         FROM ca_stl_victim  \
		                        WHERE iclaim=a.iclaim \
		                          AND fstl=a.fstl  \
		                          AND iclose_type=a.iclose_type) != 0) \
		                 AND dgroup IS NOT NULL \
		            ORDER BY iclaim,fstl,iclose_type",list[k].dbname,bgndate_l,enddate_l);
		$PREPARE car9990_1_tmp FROM $stmt;
		$DECLARE car9990_1 CURSOR FOR car9990_1_tmp;
		$OPEN car9990_1;
		while (1)
		{
			$FETCH car9990_1 INTO $fstl,$istl_flag,$iclaim,$iclose_type,$iself_duty,$dgroup,$dgroup_e;
			if (SQLCODE == SQLNOTFOUND) break;
			
			if (istl_flag[0] == 'A' || istl_flag[0] == 'B') continue;
		
			sprintf_s(stmt,4096,"SELECT dclaim,ipolicy,daccident,DATE(daccident),iacc_license \
			                FROM %s:appraisal \
			               WHERE iclaim = '%s'",list[k].dbname,iclaim);
			$PREPARE car9990_appraisal FROM $stmt;
			$EXECUTE car9990_appraisal INTO $dclaim,$ipolicy,$daccident,$long_daccident,$iacc_license;

			company_flag=ipolicy[7];
			printf(" ipolicy[%s]\n",ipolicy);
			printf(" iclaim[%s]\n",iclaim);
			printf(" company_flag[%c]\n",company_flag);
			printf(" fstl[%s]\n",fstl);
	
			rtn = getCompanyId(companyid);
			printf(" ************************** companyid[%s]\n",companyid);
		
			if(strcmp( companyid,"17")==0)
			{
				if(company_flag > 65 )
				{  
			      	$select ipolicy_a
			           into $ipolicy
			           from conv_ipolicy
			          where ipolicy_n = $ipolicy;
		         
					strcpy(COMPANY_P,"16");
					strcpy(COMPANY_F,"17");
				}
				else
				{
					strcpy(COMPANY_P,"17");
					strcpy(COMPANY_F,"17");
				}
		      
				iclaim_flag=iclaim[6];
		      
				printf(" iclaim[%s]\n",iclaim);
				printf(" iclaim_flag[%c]\n",iclaim_flag);
		      
				if(iclaim_flag > 65 )
				{  
					printf(" *************************************\n");           	
				     	$select distinct iclaim_a
				            into $iclaim_a
				            from conv_iclaim
				           where iclaim_n = $iclaim;
		           
					printf(" ****************** iclaim[%s]\n",iclaim_a);                 
					strcpy(COMPANY_F,"16");
				}
				else
				{
					strcpy(COMPANY_F,"17");
					strcpy(iclaim_a, iclaim);
					printf(" ****************** COMPANY_E[%s]\n",COMPANY_F);             
				}
			}
			else
			{
				strcpy(COMPANY_P,"32");
				strcpy(COMPANY_F,"32"); 	
				strcpy(iclaim_a, iclaim); 
			}   
		
			/* 1  1-16   �߮׸��X*/
			strcat(prtstr_1to25,COMPANY_F); prtstr_1to25[2]='\0';
			strcpy(t_iclm_company,COMPANY_F);
			strncat(prtstr_1to25, (iclaim_a[0]=='\0') ? "              " : iclaim_a,14);
			strncpy(t_iclm_br, (iclaim_a[0]=='\0') ? "              " : iclaim_a,2);
			strncpy(t_iclaim, (iclaim_a[0]=='\0') ? "              " : iclaim_a,14);
			prtstr_1to25[16]='\0';
			
			/* 2  17-24  �X�I���*/
			strncpy(daccident_yyyy,&daccident[0],4); daccident_yyyy[4]='\0';
			strncpy(daccident_mm,&daccident[5],2); daccident_mm[2]='\0';
			strncpy(daccident_dd,&daccident[8],2); daccident_dd[2]='\0';
			strncat(prtstr_1to25,(daccident_yyyy[0]=='\0') ? "0000" : daccident_yyyy,4);
			strncat(prtstr_1to25,(daccident_mm[0]=='\0') ? "00" : daccident_mm,2);
			strncat(prtstr_1to25,(daccident_dd[0]=='\0') ? "00" : daccident_dd,2);
			strcpy(t_daccident,(daccident_yyyy[0]=='\0') ? "0000" : daccident_yyyy); t_daccident[4] = '\0';
			strcat(t_daccident,(daccident_mm[0]=='\0') ? "00" : daccident_mm); t_daccident[6] = '\0';
			strcat(t_daccident,(daccident_dd[0]=='\0') ? "00" : daccident_dd); t_daccident[8] = '\0';
			prtstr_1to25[24]='\0';
			
			/* 3  25-32  �߮ר��z���*/
			strncpy(dclaim_yyyy,&dclaim[0],4); dclaim_yyyy[4] = '\0';
			strncpy(dclaim_mm,&dclaim[5],2); dclaim_mm[2] = '\0';
			strncpy(dclaim_dd,&dclaim[8],2); dclaim_dd[2] = '\0';
			strcat(prtstr_1to25, (dclaim_yyyy[0]=='\0') ? "0000" : dclaim_yyyy);
			strcat(prtstr_1to25, (dclaim_mm[0]=='\0') ? "00" : dclaim_mm);
			strcat(prtstr_1to25, (dclaim_dd[0]=='\0') ? "00" : dclaim_dd);
			strcpy(t_dclaim, (dclaim_yyyy[0]=='\0') ? "0000" : dclaim_yyyy);
			strcat(t_dclaim, (dclaim_mm[0]=='\0') ? "00" : dclaim_mm);
			strcat(t_dclaim, (dclaim_dd[0]=='\0') ? "00" : dclaim_dd);
			prtstr_1to25[32]='\0';
			
			/* 4  33-34  �ߥI/�l�v���� */
			t_iclose_type = iclose_type;
			rfmtlong(iclose_type,"&&",iclose_type_c);
			strncat(prtstr_1to25, (iclose_type_c[0]=='\0') ? "00" : iclose_type_c,2);
			prtstr_1to25[34]='\0';
			
			/* 5  35-35  �ߥI�N��*/
			strncat(prtstr_1to25, (istl_flag[0]=='\0' || istl_flag[0]==' ' ) ? "1" : istl_flag,1); 
			strncpy(t_istl_flag, (istl_flag[0]=='\0' || istl_flag[0]==' ' ) ? "1" : istl_flag,1); 
			prtstr_1to25[35]='\0';
			
			/* 6  36-43  ���פ��*/
			sta_dgroup = dgroup;
			memcpy(dgroup_yy,&dgroup_e[6],4);
			memcpy(dgroup_mm,&dgroup_e[0],2);
			memcpy(dgroup_dd,&dgroup_e[3],2);
			strncat(prtstr_1to25,(dgroup_yy[0]=='\0') ? "0000" : dgroup_yy,4);
			strncat(prtstr_1to25,(dgroup_mm[0]=='\0') ? "00" : dgroup_mm,2);
			strncat(prtstr_1to25,(dgroup_dd[0]=='\0') ? "00" : dgroup_dd,2);
			
			strcpy(t_dgroup,(dgroup_yy[0]=='\0') ? "0000" : dgroup_yy); t_dgroup[4] = '\0';
			strcat(t_dgroup,(dgroup_mm[0]=='\0') ? "00" : dgroup_mm);   t_dgroup[6] = '\0';
			strcat(t_dgroup,(dgroup_dd[0]=='\0') ? "00" : dgroup_dd);   t_dgroup[8] = '\0';
			prtstr_1to25[43]='\0';
			
			/* 7  44-51  �ߥI/�l�v���*/
			strcpy(dgroup_c,cm_cdate_str_100(sta_dgroup));
			cm_split_ymd_100(dgroup_c,dgroup_yy,dgroup_mm,dgroup_dd);
			rfmtlong(atoi(dgroup_yy)+1911,"&&&&",dgroup_yy);
			strncat(prtstr_1to25,(dgroup_yy[0]=='\0') ? "0000" : dgroup_yy,4);
			strncat(prtstr_1to25,(dgroup_mm[0]=='\0') ? "00" : dgroup_mm,2);
			strncat(prtstr_1to25,(dgroup_dd[0]=='\0') ? "00" : dgroup_dd,2);
			prtstr_1to25[51]='\0';
			
			/* 8  52-52  �A�β�29���l���ƶ�*/
			$SELECT iverify
			   INTO $sIverify
			   FROM ca_ver_relation
			  WHERE iclaim = $iclaim;
			if (SQLCODE == SQLNOTFOUND) strcpy(sIverify, iclaim);
				
			$SELECT fsubrogation 
			   INTO $sFsubrogation
			   FROM ca_clm_victim_data
			  WHERE ivictim = $iacc_license
			    AND iclaim = $sIverify;
			if (SQLCODE == SQLNOTFOUND) strcpy(sFsubrogation,"N");
			
			strncat(prtstr_1to25,(sFsubrogation[0]=='\0') ? "N" : sFsubrogation,1);
			strncpy(t_fsubrogation,(sFsubrogation[0]=='\0') ? "N" : sFsubrogation,1);
			prtstr_1to25[52]='\0';	
			
			/* 9  53-55  �����F�Ƴd���ʤ���*/
			buf1[0]='\0';
			rfmtlong(iself_duty,"&&&",buf1);
			strncat(prtstr_1to25,(buf1[0]=='\0') ? "000" : buf1,3);
			if (buf1[0]=='\0')
			{
				t_iself_duty = 0;
			}
			else 
			{
				t_iself_duty = iself_duty;
			}
			prtstr_1to25[55]='\0';
			
			/**** ���`�H��� ****/
			sprintf_s(stmt,4096,"SELECT b.fvictim_nation,a.ivictim \
			                FROM %s:ca_stl_victim a,ca_clm_victim_data b \
	                       WHERE a.iclaim = '%s' \
	                         AND b.iclaim = '%s' \
	                         AND b.ivictim = a.ivictim \
	                         AND a.fstl = '%s' \
	                         AND a.iclose_type = %d \
	                         AND a.iins_item[1,1] = 'A' \
	                        GROUP BY 1,2 \
	                        ORDER BY 2",list[k].dbname,iclaim,sIverify,fstl,iclose_type);
	        $PREPARE car9990_2_tmp FROM $stmt;
			$DECLARE car9990_2 CURSOR FOR car9990_2_tmp;
			$OPEN car9990_2;
			while (1)
			{
				$FETCH car9990_2 INTO $fvictim_nation,$ivictim;
				if (SQLCODE == SQLNOTFOUND) break;
				
				strcpy(prtstr_1to14,prtstr_1to25);
				
				mhealth = 0;
				if(fstl[0] == '1')/*�ߥI*/
				{
					sprintf_s(stmt,4096,"SELECT ivictim,iserial,fhealth, \
					                     (SELECT sum(mhealth)  \
					                        FROM %s:ca_stl_health  \
					                       WHERE iclaim = '%s'  \
					                         AND ivictim = '%s'  \
					                         AND fstl = '%s'  \
					                         AND iclose_type = %d),dhosp_start\
				    	            FROM %s:ca_stl_health  \
					               WHERE iclaim = '%s' \
					                 AND ivictim = '%s' \
					                 AND fstl = '%s' \
					                 AND iclose_type = %d ",list[k].dbname,iclaim,ivictim,fstl,iclose_type,list[k].dbname,iclaim,ivictim,fstl,iclose_type);
					$PREPARE car9990_3_tmp FROM $stmt;
					$DECLARE car9990_3 CURSOR FOR car9990_3_tmp;
					$OPEN car9990_3;
					while (1)
					{
						$FETCH car9990_3 INTO $ivictim2,$iserial,$fhealth,$mhealth,$dhosp_start;
						if (SQLCODE == SQLNOTFOUND) break;
						
						/* 10 56-68  ���t���O�������z�ߪ��B*/
						t_mhealth = mhealth;
						strcat(prtstr_1to14,(mhealth<0) ? "-" : "+");
						prtstr_1to14[56]='\0';
						rfmtlong(mhealth,"&&&&&&&&&&&&",mhealth_c);
						strncat(prtstr_1to14, (mhealth_c[0]=='\0') ? "00000000000" : mhealth_c,12);
						prtstr_1to14[68]='\0';
						
						/* 11 69-81  ���`�H�����*/		
						/* 11.1 69-69  ���`�H����*/ /* ID���~,�Y�H���O�����N��,�O�o���|�ˮ�: �D�ꤺ�۵M�H,���i�H���O�����N�� */
						if(strncmp(ivictim, "ID", 2)==0 && strlen(trim(ivictim))==5)
						{
							strcat(prtstr_1to14,"8");
							strcpy(t_fvictim_nation,"8");
						}
						else
						{
							if(strcmp(fvictim_nation,"1") == 0)
							{
								strcat(prtstr_1to14,"1");
								strcpy(t_fvictim_nation,"1");
							}
							else if(strcmp(fvictim_nation,"2") == 0)
							{
								strcat(prtstr_1to14,"2");
								strcpy(t_fvictim_nation,"2");
							}
							else
							{
								strcat(prtstr_1to14,"8");
								strcpy(t_fvictim_nation,"8");
							}
						}
						prtstr_1to14[69]='\0'; 
						
						/* 11.2 70-79  �ҷӸ��X*/
						strcat(prtstr_1to14,ivictim);
						strcpy(t_ivictim,ivictim);
						prtstr_1to14[79]='\0';
						
						/* 11.3 80-80  ���`�H���O�����N��N��*/
						strcat(prtstr_1to14,fhealth);
						strcpy(t_fhealth,fhealth);
						prtstr_1to14[80]='\0';
						
						/* 11.3 81-81  �ӧO���`�H�������I�O�_���ץB�ݰ��O�l�v*/	
						total_flast = 1;
						sprintf_s(stmt,4096,"SELECT UNIQUE iins_item \
						                FROM %s:ca_app_victim_hist \
						               WHERE iclaim = '%s' \
						                 AND ivictim = '%s' \
						                 AND iins_item[1,1] = 'A' \
						                 AND dappraisal < %ld",list[k].dbname,iclaim,ivictim,enddate_l);
						printf("stmt[%s] \n",stmt);
						$PREPARE car9990_4_tmp FROM $stmt;
						$DECLARE car9990_4 CURSOR FOR car9990_4_tmp;
						$OPEN car9990_4;
						while (1)
						{
							$FETCH car9990_4 INTO $iins_item;
							if (SQLCODE == SQLNOTFOUND) break;
							cnt_flast = 0;
							sprintf_s(stmt,4096,"SELECT count(*) \
							                FROM %s:ca_stl_victim a \
							               WHERE a.iclaim    = '%s' \
							                 AND a.ivictim   = '%s' \
							                 AND a.iins_item = '%s' \
							                 AND a.flast = '2' ",list[k].dbname,iclaim,ivictim,iins_item);
							printf("stmt[%s] \n",stmt);
							$PREPARE car9990_4_victim FROM $stmt;
							$EXECUTE car9990_4_victim INTO $cnt_flast;
							
							if(cnt_flast == 0) total_flast = 0;/*�Y���@�������׫h��N*/
							    
						}
						$CLOSE car9990_4;
						$FREE  car9990_4;
		
						if (total_flast > 0)
						{
							strcpy(flast,"Y");
						}
						else
						{
							strcpy(flast,"N");
						}
						
						strcat(prtstr_1to14,flast);
						strcpy(t_flast,flast);
						prtstr_1to14[81]='\0';
						
						/* 12 82-85  ���O�������ڽs��*/
						t_iserial = iserial;
						rfmtlong(iserial,"&&&&",iserial_c);
						strncat(prtstr_1to14, (iserial_c[0]=='\0') ? "0000" : iserial_c,4);
						prtstr_1to14[85]='\0';
						
						/* 13 86-93  �N�E����(�_�l)*/
						strcpy(dhosp_start_c,cm_from_infdate_100(dhosp_start));
						cm_split_ymd_100(dhosp_start_c,dhosp_start_yy,dhosp_start_mm,dhosp_start_dd);
						rfmtlong(atoi(dhosp_start_yy)+1911,"&&&&",dhosp_start_yyyy);
						strncat(prtstr_1to14,(dhosp_start_yy[0]=='\0') ? "0000" : dhosp_start_yyyy,4);
						strncat(prtstr_1to14,(dhosp_start_mm[0]=='\0') ? "00" : dhosp_start_mm,2);
						strncat(prtstr_1to14,(dhosp_start_dd[0]=='\0') ? "00" : dhosp_start_dd,2);
						strncpy(t_dhosp_start,(dhosp_start_yy[0]=='\0') ? "0000" : dhosp_start_yyyy,4); t_dhosp_start[4] = '\0';
						strncat(t_dhosp_start,(dhosp_start_mm[0]=='\0') ? "00" : dhosp_start_mm,2); t_dhosp_start[6] = '\0';
						strncat(t_dhosp_start,(dhosp_start_dd[0]=='\0') ? "00" : dhosp_start_dd,2); t_dhosp_start[8] = '\0';
						prtstr_1to14[93]='\0';
						
						/* 14 94-101 ��ƻs�e���*/
						strcat(prtstr_1to14,ttday_yy);
						strcat(prtstr_1to14,ttday_mm);
						strcat(prtstr_1to14,ttday_dd);
						strcpy(t_dsend,ttday_yy);
						strcat(t_dsend,ttday_mm);
						strcat(t_dsend,ttday_dd);
						prtstr_1to14[101]='\0';
						
						count1++;
						fprintf(fptr,"%s\n",prtstr_1to14);
						
						printf("t_daccident[%s] t_dgroup[%s]\n",t_daccident,t_dgroup);
						sprintf_s(stmt,4096,"INSERT INTO %s:ca_dev_clm_health_comp \
			                                 (data_yyyymm,iclm_company,iclm_br,iclaim,daccident,dclaim,iclose_type, \
                                              istl_flag,dgroup,fsubrogation,iself_duty,mhealth,fvictim_nation,ivictim, \
                                              fhealth,flast,iserial,dhosp_start,dsend) \
			                          VALUES(?,?,?,?,?,?,?, \
			                                 ?,?,?,?,?,?,?, \
			                                 ?,?,?,?,?)",list[k].dbname);
						$PREPARE insert_clm_health FROM $stmt;
						$EXECUTE insert_clm_health using $data_yyyymm,$t_iclm_company,$t_iclm_br,$t_iclaim,$t_daccident,$t_dclaim,$t_iclose_type,
						                                 $t_istl_flag,$t_dgroup,$t_fsubrogation,$t_iself_duty,$t_mhealth,$t_fvictim_nation,$t_ivictim,
						                                 $t_fhealth,$t_flast,$t_iserial,$t_dhosp_start,$t_dsend;
					}
					$CLOSE car9990_3;
					$FREE  car9990_3;
				}
				else/*�l�v*/
				{
					sprintf_s(stmt,4096,"SELECT SUM(DECODE(a.fstl,'2',a.mins_stl*(-1),a.mins_stl)) \
					                FROM %s:ca_stl_victim a  \
		                           WHERE a.iclaim = '%s' \
		                             AND a.ivictim = '%s' \
		                             AND a.fstl = '%s' \
					                 AND a.iclose_type = %d \
					                 AND a.iins_item[1,1] = 'A'",list[k].dbname,iclaim,ivictim,fstl,iclose_type);
					printf("stmt[%s] \n",stmt);
					$PREPARE car9990_vic2 FROM $stmt;
					$EXECUTE car9990_vic2 INTO $mhealth;
					if (SQLCODE == SQLNOTFOUND) mhealth = 0;
					
					/* 10 56-68  ���t���O�������z�ߪ��B*/
					t_mhealth = mhealth;
					strcat(prtstr_1to14,(mhealth<0) ? "-" : "+");
					prtstr_1to14[56]='\0';
					rfmtlong(mhealth,"&&&&&&&&&&&&",mhealth_c);
					strncat(prtstr_1to14, (mhealth_c[0]=='\0') ? "00000000000" : mhealth_c,12);
					prtstr_1to14[68]='\0';
					
					/* 11 69-81  ���`�H�����*/		
					/* 11.1 69-69  ���`�H����*/ /* ID���~,�Y�H���O�����N��,�O�o���|�ˮ�: �D�ꤺ�۵M�H,���i�H���O�����N�� */
					if(strncmp(ivictim, "ID", 2)==0 && strlen(trim(ivictim))==5)
					{
						strcat(prtstr_1to14,"8");
						strcpy(t_fvictim_nation,"8");
					}
					else
					{
						if(strcmp(fvictim_nation,"1") == 0)
						{
							strcat(prtstr_1to14,"1");
							strcpy(t_fvictim_nation,"1");
						}
						else if(strcmp(fvictim_nation,"2") == 0)
						{
							strcat(prtstr_1to14,"2");
							strcpy(t_fvictim_nation,"2");
						}
						else
						{
							strcat(prtstr_1to14,"8");
							strcpy(t_fvictim_nation,"8");
						}
					}
					prtstr_1to14[69]='\0'; 
					
					/* 11.2 70-79  �ҷӸ��X*/
					strcat(prtstr_1to14,ivictim);
					strcpy(t_ivictim,ivictim);
					prtstr_1to14[79]='\0';
						
					/* 11.3 80-80  ���`�H���O�����N��N��*//*�l�v�eN*/
					strcpy(fhealth,"N");
					strcat(prtstr_1to14,fhealth);
					strcpy(t_fhealth,fhealth);
					prtstr_1to14[80]='\0';
		                            
		                        /* 11.3 81-81  �ӧO���`�H�������I�O�_���ץB�ݰ��O�l�v*/	
					total_flast = 1;
					sprintf_s(stmt,4096,"SELECT UNIQUE iins_item \
					                FROM %s:ca_app_victim_hist \
					               WHERE iclaim = '%s' \
					                 AND ivictim = '%s' \
					                 AND iins_item[1,1] = 'A' \
					                 AND dappraisal < %ld",list[k].dbname,iclaim,ivictim,enddate_l);
					printf("stmt[%s] \n",stmt);
					$PREPARE car9990_5_tmp FROM $stmt;
					$DECLARE car9990_5 CURSOR FOR car9990_5_tmp;
					$OPEN car9990_5;
					while (1)
					{
						$FETCH car9990_5 INTO $iins_item;
						if (SQLCODE == SQLNOTFOUND) break;
						cnt_flast = 0;
						sprintf_s(stmt,4096,"SELECT count(*) \
						                FROM %s:ca_stl_victim a \
						               WHERE a.iclaim    = '%s' \
						                 AND a.ivictim   = '%s' \
						                 AND a.iins_item = '%s' \
						                 AND a.flast = '2'",list[k].dbname,iclaim,ivictim,iins_item);
						printf("stmt[%s] \n",stmt);
						$PREPARE car9990_5_vic FROM $stmt;
						$EXECUTE car9990_5_vic INTO $cnt_flast; 
						 
						if(cnt_flast == 0) total_flast = 0;/*�Y���@�������׫h��N*/
						    
					}
					$CLOSE car9990_5;
					$FREE  car9990_5;
	
					if (total_flast > 0) strcpy(flast,"Y");
					else strcpy(flast,"N");
					
					strcat(prtstr_1to14,flast);
					strcpy(t_flast,flast);
					prtstr_1to14[81]='\0';
					
					/* 12 82-85  ���O�������ڽs��*//*�l�v�e0*/
					t_iserial = 0;
					strcat(prtstr_1to14, "0000");
					prtstr_1to14[85]='\0';
					
					/* 13 86-93  �N�E����(�_�l)*//*�l�v�e0*/
					strcat(prtstr_1to14,"00000000");
					strcpy(t_dhosp_start,"00000000");
					prtstr_1to14[93]='\0';
					
					/* 14 94-101 ��ƻs�e���*/
					strcat(prtstr_1to14,ttday_yy);
					strcat(prtstr_1to14,ttday_mm);
					strcat(prtstr_1to14,ttday_dd);
					strcpy(t_dsend,ttday_yy);
					strcat(t_dsend,ttday_mm);
					strcat(t_dsend,ttday_dd);
					prtstr_1to14[101]='\0';
	
					count1++;
		         	fprintf(fptr,"%s\n",prtstr_1to14);
		         	
		         	sprintf_s(stmt,4096,"INSERT INTO %s:ca_dev_clm_health_comp \
			                                 (data_yyyymm,iclm_company,iclm_br,iclaim,daccident,dclaim,iclose_type, \
                                              istl_flag,dgroup,fsubrogation,iself_duty,mhealth,fvictim_nation,ivictim, \
                                              fhealth,flast,iserial,dhosp_start,dsend) \
			                          VALUES(?,?,?,?,?,?,?, \
			                                 ?,?,?,?,?,?,?, \
			                                 ?,?,?,?,?)",list[k].dbname);
						$PREPARE insert_clm_vic FROM $stmt;
						$EXECUTE insert_clm_vic  using $data_yyyymm,$t_iclm_company,$t_iclm_br,$t_iclaim,$t_daccident,$t_dclaim,$t_iclose_type,
						                                $t_istl_flag,$t_dgroup,$t_fsubrogation,$t_iself_duty,$t_mhealth,$t_fvictim_nation,$t_ivictim,
						                                $t_fhealth,$t_flast,$t_iserial,$t_dhosp_start,$t_dsend;
				}
				sum_mhealth = sum_mhealth + mhealth;
			}
			$CLOSE car9990_2;
			$FREE  car9990_2;
		}
		$CLOSE car9990_1;
		$FREE car9990_1;
	}
	fclose(fptr);
	
	printf("sum_mhealth[%d] \n",sum_mhealth);
	
	res = getApHome(aphome);
	if (res<0) {
	    printf("In sigalrmcatcher func==>read config file error!!\n");
	    exit(1);
	}

	if(count1==0) fprintf(fptr_err,"%s\n","�L���!!");
	else
	{
		$SELECT iquota INTO $iquota FROM officer WHERE iofficer=$userid;
		rtoday(&Today);     /* get today's datetime */
		printf("### Today[%d],localdb[%s],count1[%d]\n",Today,DBName,count1);

		strcpy(Taipei_FullName,get_full_dbname("00"));

		$WHENEVER SQLERROR CONTINUE;

		sprintf_s(stmt,4096,"DELETE FROM %s:ca_develop \
		               WHERE iclass='9990' AND ibranch=? AND data_yyyymm = ? ",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus1 FROM $stmt;
		$EXECUTE insert_cus1 USING $DBName,$data_yyyymm;
		
		$WHENEVER SQLERROR GOTO errexit;
		
		sprintf_s(stmt,4096,"INSERT INTO %s:ca_develop \
		                     (iquota,data_yyyymm,iclass,dsend,ibranch,product_kind,iins_class,mprem,mhealth,qcnt,mdrunk_pure_prem) \
		              VALUES (?,?,'9990',?,?,'99','C',?,0,?,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus2 FROM $stmt;
		$EXECUTE insert_cus2 USING $iquota,$data_yyyymm,$Today,$DBName,$sum_mhealth,$count1;
	}
	 
	return SUCCESS;

errexit:
	printf("usrid=%s SOLCODE=%d sqlca.sqlerrm=%s\n",userid,SQLCODE,sqlca.sqlerrm);
	sprintf_s(errmsg,200,"userid=%s SOLCODE=%d sqlca.sqlerrm=%s",userid,SQLCODE,sqlca.sqlerrm);
	fprintf(fptr_err,"%s\n",errmsg);
	return SQLCODE;
}

long car9990_final()
{
	char sTmpMsg[1024];
	$char sfilename[81],stitle[1024],stmt[1024];
	$char DBName1[5];
	$long mprem, qcnt;
	$char product_kind[3];
    
	$WHENEVER SQLERROR GOTO errexit;
	
	strcpy(DBName1,"00");
	if (db_select(DBName1) == False)  return M_CM_DB_NOTOPEN;
	
	printf("data_yyyymm[%s] \n",data_yyyymm);
	$SELECT sum(mprem), sum(qcnt)
	   INTO $mprem, $qcnt
	   FROM ca_develop
	  WHERE iclass = '9990' AND product_kind = '99'
	    AND data_yyyymm  = $data_yyyymm;

	sprintf_s(sTmpMsg,1024, "%s%s\n", "���ɧ���:", file_catalog);
	sprintf_s(sTmpMsg,1024, "%s�O�O=[%d] ����=[%d]\n",sTmpMsg, mprem, qcnt);

	EWRITE(userid, M_CM_OK, sTmpMsg);
	exit(SUCCESS);
	isfinish(rtncode);

errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}
