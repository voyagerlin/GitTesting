/*******************************************/
/*                                         */
/*   PROGRAM : ca706q01s.ec                */
/*                                         */
/*   MODIFY  : 2001.12.10                  */
/*                                         */
/*   Checked for ����100�~�M��             */
/*******************************************/
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "car_equip.h"


$char   dbgn1[YYYYMMDD], dend1[YYYYMMDD], dply_begin[YYYYMMDD], dply_end[YYYYMMDD];
$char   iins_type[INSURANCE_TYPE],iofficer[11],p_bgn[11],p_end[11];
int     d_bgn,d_end;
$char   dp_begin[11],dp_end[11],dendorse[11],dpolicy[11];
char    begin[11],end[11],insure_time[14],P_zone[4],N_zone[4],car[5];
$char   iendorse[21],ibig_office[11],ibig_sales[11],icard[21],nassured[41],nins_type[29],iengine[CA_ENGINE_NUM];
$char   iofficer[11],DBName[5],zone[4],ibig_branch[26],nname[17],N_iofficer[11],P_iofficer[11];
$char   P_iof[4],N_iof[4],P_iof_N[11],fedr_class[2],ipolicy[21];
$char   iquota[7],igroup[6],ioffice_unit[11];
$double medrins_prem,sumtot,subtot,sub00,sum00,subtot1,sum_all;
int     cont_tot =0 ,empty = 0,cont=0,num=0 ,num1=0;
$char   ileader[11],iresource[2],fassured[2];
$char   R_ncode[30],F_ncode[30],L_nname[11];
char    fymark[91][4];
$char   tcode[91][20];
$char   nequipment[31];
$char   iins_cnt[3];
int     cnt;

$char   FormTp[3];
char    outputf[N_FILE+1], userid[6],no_ipolicy[21];

/* AOI ao_chk_charge */
$int    ibatch_no;
char    tmp_ibatch_no[3];
char    ao_policy1[POLICY_NUM_1], ao_policy2[CA_TARGET_NUM];
char    a0result[3], a0comment[31], a0date1[9], a0date2[9];
$char   ao_note[2];
extern struct sEquip *IfirstEquip, *IcurrEquip, *IlastEquip, *IEquip_ptr;
char equipdecode[201];
$char iremark[4];


static  int max_cnt=0;
int     rtncode;

long    car706_build();
long    car706_detail();
long    car706_accumulate();
void    car706_body();
void    car706_subtot();
void    car706_tot();
void    car706_tot_all();
static  char *get_car_full_db();

#define fmt "---,---,---,---"

/*----------------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
   int   rc;
   int   i,m=0,k=0,n;

   cnt = 0;

   batchinit();
   strcpy(DBName,     isNULLstr(argv[1]));
   strcpy(userid,     isNULLstr(argv[2]));
   strcpy(iins_type,  isNULLstr(argv[3]));
   strcpy(dbgn1,      isNULLstr(argv[4]));
   strcpy(dend1,      isNULLstr(argv[5]));
   strcpy(iofficer,   isNULLstr(argv[6]));
   strcpy(iins_cnt,   isNULLstr(argv[7]));

   cnt = atoi(iins_cnt);

   for(i=1;i<91;i++)
   {
        fymark[i][0]='\0';
   }

   for(i = 1 ; i < cnt+1 ; i++)
   {
        k = 7+i;
        strcpy(fymark[i],isNULLstr(argv[k]));
        fymark[i][3]='\0';
   }

   if (cnt != 0)
        m = k + 1;
   else
        m = 8;

   strcpy(outputf,    isNULLstr(argv[m]));

   printf("outpuf[%s]\n",outputf);
   strcpy(p_bgn,dbgn1);
   strcpy(p_end,dend1); 
   strcpy(dbgn1, cm_to_infdate(dbgn1));
   strcpy(dend1, cm_to_infdate(dend1));
   
   printf("p_bgn[%s] ,pend [%s] \n",p_bgn,p_end);
   rc = car706_build();

   if (rc == api_OKComplete)
   {
       if ((rc=save_form_info(F_FREE, "CA", 706, userid, FormTp, max_cnt, outputf))<0)
       EWRITE(userid, rc, "save_form_info failed");
   }
}

/*----------------------------------------------------------------------------*/
long car706_build()
{
   $char  FormFmt[N_FILE+1];
   $int   StartRow, TitleRow, TotColumn, PgLine, Width;

   char   FormFile[N_FILE+1];

   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return FAIL;
   }
   $SELECT nForm_File, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $FormFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width, $FormTp
      FROM Form
     WHERE ksys_grp = "CA" AND kPgmID = 706 AND iform_tp = "1" ;

   strcpy(FormFmt, rtrim(FormFmt));
   sprintf(FormFile, "%s.tx", outputf);
   /* create & insert data with temp table */
   car706_accumulate(); 

   /* build report */
   rgu_init_report(FormFmt, FormFile);
   car706_detail();
   rgu_finish_report();

   $DROP TABLE CAR706;
   $DROP TABLE CAR706_EQUIP;

   if (max_cnt == 0)
   {
      EWRITE(userid, M_CM_NOT_FOUND, "no data found in CAR706 !!");
      return FAIL;
   }

   return api_OKComplete;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return FAIL;
}


/*----------------------------------------------------------------------------*/
long car706_accumulate()
{
   $char  tmp_fulldb[50], stmt[1024];
   $char  buf1[100];
   $long  mins_premium,mapp_loss,cmapp_loss;
   int    iquota_len;
   
   $char  stmt_buf[1500],stmt_buf1[300],stmt_bufA[300],stmt_bufB[300];
   int    i,j,count_db;
   $int   flag,x,y,yy,kk;
   $char  equipdecode[201];
   DBinfo *list;
   
   $WHENEVER SQLERROR GOTO errexit;

   $CREATE TEMP TABLE CAR706
    ( 
      ipolicy            char(20),
      ioffice_unit       char(11),
      iendorse           char(20),
      ibig_office        char(10),
      ibig_sales         char(11),
      icard              char(20),
      nassured           char(40),
      dply_begin         date,
      dply_end           date,
      medrins_prem       integer default 0, 
      iofficer           char(10),
      iengine            char(25),
      dendorse           date,
      dpolicy            date,
      L_nname            char(11),
      F_ncode            char(30),
      R_ncode            char(30),
      ao_note            char(2),
      ileader            char(10)
    ) WITH NO LOG;
    
   $CREATE TEMP TABLE CAR706_EQUIP
    (
      ipolicy   char(20),
      iendorse  char(20),
      note1     char(20),
      note2     char(20),
      note3     char(20),
      note4     char(20),
      note5     char(20),
      note6     char(20),
      note7     char(20),
      note8     char(20),
      note9     char(20),
      note10    char(20),
      note11    char(20),
      note12    char(20),
      note13    char(20),
      note14    char(20),
      note15    char(20),
      note16    char(20),
      note17    char(20),
      note18    char(20),
      note19    char(20),
      note20    char(20),
      note21    char(20),
      note22    char(20),
      note23    char(20),
      note24    char(20),
      note25    char(20),
      note26    char(20),
      note27    char(20),
      note28    char(20),
      note29    char(20),
      note30    char(20),
      note31    char(20),
      note32    char(20),
      note33    char(20),
      note34    char(20),
      note35    char(20),
      note36    char(20),
      note37    char(20),
      note38    char(20),
      note39    char(20),
      note40    char(20),
      note41    char(20),
      note42    char(20),
      note43    char(20),
      note44    char(20),
      note45    char(20),
      note46    char(20),
      note47    char(20),
      note48    char(20),
      note49    char(20),
      note50    char(20),
      note51    char(20),
      note52    char(20),
      note53    char(20),
      note54    char(20),
      note55    char(20),
      note56    char(20),
      note57    char(20),
      note58    char(20),
      note59    char(20),
      note60    char(20),
      note61    char(20),
      note62    char(20),
      note63    char(20),
      note64    char(20),
      note65    char(20),
      note66    char(20),
      note67    char(20),
      note68    char(20),
      note69    char(20),
      note70    char(20),
      note71    char(20),
      note72    char(20),
      note73    char(20),
      note74    char(20),
      note75    char(20),
      note76    char(20),
      note77    char(20),
      note78    char(20),
      note79    char(20),
      note80    char(20),
      note81    char(20),
      note82    char(20),
      note83    char(20),
      note84    char(20),
      note85    char(20),
      note86    char(20),
      note87    char(20),
      note88    char(20),
      note89    char(20),
      note90    char(20)
    ) WITH NO LOG;

   iquota_len = strlen( rtrim(iofficer));
    
   switch ( iquota_len )
   {
        case 1:
             strcpy(buf1," ");
             break;
        case 2:
             if( iofficer[1] == '*' )
                  sprintf(buf1,"AND a.iofficer[1] = '%s'",substring(iofficer,1,1));
             printf(" buf1_ case2 [%s] \n",buf1);
             break;
        case 3:
             if( iofficer[2] == '*')
                  sprintf(buf1, "AND a.iofficer[1,2] = '%s'",substring(iofficer,1,2));
             break;
        case 4:
             if(iofficer[3] == '*')
                  sprintf(buf1, "AND a.iofficer[1,3] = '%s'",substring(iofficer,1,3));
             break;
        case 5:
             if(iofficer[4] == '*')
                  sprintf(buf1, "AND a.iofficer[1,4] = '%s'",substring(iofficer,1,4));
             break;
        case 6:
             if( iofficer[5] == '*')
                  sprintf(buf1, "AND a.iofficer[1,5] = '%s'",substring(iofficer,1,5));
             else
                  sprintf(buf1,"AND a.iofficer = '%s'",iofficer);
             break;
        default:
             sprintf(buf1,"AND a.iofficer = '%s'", iofficer);
   }
   
   /* get db_list without sysdb */
   if ((list = get_db_list (&count_db, DBName)) == (char *) 0)
   {
        if (EWRITE(userid, M_CM_NOT_DBLIST) == True)
            return M_CM_NOT_DBLIST;
        return M_CM_OK;
   }
  
   for(j=0;j<count_db;j++)
   {
        sprintf(stmt_buf, "SELECT %s %s %s %s FROM %s:%s %s:%s %s:%s %s:%s WHERE %s %s %s %s %s %s %s ",
                          " a.ipolicy,a.iendorse,nvl(a.ibig_office,' '),a.ibig_sales, ",
                          " a.icard,a.iofficer,c.iengine,a.dedr_begin,a.dedr_end, ",
                          " a.fedr_class,a.iquota,b.medrins_prem,a.dendorse, ",
                          " c.nassured[1,40],d.dpolicy, a.ileader, a.iresource, c.fassured, c.nequipment ",
                          list[j].dbname, "edr_relation a, ",
                          list[j].dbname, "edr_ins_type b, ",
                          list[j].dbname, "endorsement c, ",
                          list[j].dbname, "ply_relation d ",
                          " (a.dendorse >= ? and a.dendorse <= ?) ",
                          buf1,
                          "AND a.iendorse = c.iendorse ",
                          "AND a.iendorse = b.iendorse ",
                          "AND b.iins_type = ? ",
                          "AND b.medrins_prem <> 0 ",
                          "AND a.ipolicy = d.ipolicy");

        printf("stmt_buf[%s]\n",stmt_buf);
        $PREPARE a_id FROM $stmt_buf;
        $DECLARE cur1 CURSOR for a_id;
        $OPEN    cur1 USING  $dbgn1, $dend1, $iins_type;

        for(;;)
        {
            $FETCH cur1 INTO $ipolicy,$iendorse,$ibig_office,$ibig_sales,
                             $icard,$iofficer,$iengine,$dply_begin,$dply_end,
                             $fedr_class,$iquota,$medrins_prem,$dendorse,
                             $nassured,$dpolicy,$ileader,$iresource,$fassured,
                             $nequipment;

            if(SQLCODE == SQLNOTFOUND) break;

            for(x=1;x<91;x++)
                strcpy(tcode[x]," ");

            flag=0;
            for(x=1;x<91;x++)
            {
                printf("iendorse=[%s]  x=[%d] fymark[x]=[%s]\n",iendorse,x,fymark[x]);
                if(fymark[x][1] != '\0')
                {
                     /*****************************
                     yy=atoi(fymark[x]);
                     if(nequipment[yy-1] == '1')
                     ******************************/
                     if (equip_cmp(nequipment,fymark[x]) == TRUE)
                     {
                          printf(" match nequipment \n");
                          flag=1;
                          break;
                     }
                }
                else
                {
                     break;
                }
            }   /* end of for */

            if (cnt==0)  flag = 1;   /*���O����=0,��ܩҦ����(���ܸ�Ƥ����Ҽ{�O�_�t�����O�ﶵ)*/
            if (flag==0) continue;

            strcpy(equipdecode,equip_get(nequipment));
            kk=1;
            y=1;

            IEquip_ptr=IfirstEquip;
            while(IEquip_ptr)
            {
               /*****
               kk = IEquip_ptr->iequip;
               ******/
               strcpy(iremark,IEquip_ptr->sequip);

               $SELECT ncode
                  INTO $tcode[y]
                  FROM cu_code_data
                 WHERE itype = '25'
                   AND icode = $iremark;
                    if (SQLCODE == SQLNOTFOUND) tcode[y][0]='\0';
                    strcpy(tcode[y],rtrim(tcode[y]));
                    printf("#######231 y=[%d] tcode[y]=[%s] \n",y,tcode[y]);
                    
               IEquip_ptr=IEquip_ptr->next;
               y++;
            }

/****************************************************************************************
            kk = 1;
            y  = 1;

            for(x=0 ; x<90 ; x++)
            {
                if(nequipment[x] == '1')
                {
                     $SELECT ncode[1,20]
                        INTO $tcode[y]
                        FROM cu_code_data
                       WHERE itype = '25'
                         AND icode = $kk;
                     if (SQLCODE == SQLNOTFOUND) tcode[j][0]='\0';
                     strcpy(tcode[y],trim(tcode[y]));
                     printf("####### y=[%d] tcode[y]=[%s] \n",y,tcode[y]);
                     y++;
                }
                kk++;
            }
*************************************************************************************/

            $SELECT b.ngroup[1,10]
               INTO $ioffice_unit
               FROM sa_branch_type a,sa_frm_module b
              WHERE a.ibranch = $iquota
                AND a.igroup = b.igroup
                AND b.ifrm_module = '01';

            if (SQLCODE == SQLNOTFOUND )
               strcpy(ioffice_unit," ");

            if (strncmp(ibig_office," ",1)==0)
            {
               $select nname
                  into $ibig_office
                  from officer
                 where iofficer = $iofficer;
               if (SQLCODE==SQLNOTFOUND) strcpy(ibig_office," ");
            }

            /* �޲z�H���� */
            $SELECT nname
               INTO $L_nname
               FROM officer
              WHERE iofficer = $ileader;
             

            /* �Ȥᨭ������ */
            $SELECT ncode
                INTO $F_ncode
                FROM cu_code_data
               WHERE itype='09'
                 AND icode=$fassured;
            printf("F_ncode[%s]\n",F_ncode);

            /* �~�Ȩӷ����� */
            $SELECT ncode
               INTO $R_ncode
               FROM cu_code_data
              WHERE itype='10'
                AND icode=$iresource;

            printf("ncode[%s]\n",R_ncode);

            /* ���O���O */
            rtncode = split_policy(ipolicy, ao_policy1, ao_policy2);
            if ( rtncode != M_CM_OK )
                return rtncode;

            printf("squery ao_policy1[%s],ao_policy2[%s],iendorse[%s]\n",
                    ao_policy1,ao_policy2,iendorse);

            ao_chk_charge( DBName, '2', ao_policy1, ao_policy2 , iendorse,
                           a0result, a0comment, a0date1, a0date2);

            printf("a0result[%s]\n",a0result);

            if( a0result[0] == 'R' )
                 strcpy( ao_note , "Y" );
            else
                 strcpy( ao_note , "N" );

            $INSERT INTO CAR706
                    (ipolicy,ioffice_unit,iendorse,ibig_office,ibig_sales,icard,
                     nassured,dply_begin,dply_end,medrins_prem,iofficer,iengine,dendorse,
                     dpolicy,L_nname,F_ncode,R_ncode,ao_note,ileader)
             VALUES ($ipolicy,$ioffice_unit,$iendorse,$ibig_office,
                     $ibig_sales,$icard,$nassured,$dply_begin,
                     $dply_end,$medrins_prem,$iofficer,$iengine,$dendorse,$dpolicy,
                     $L_nname,$F_ncode,$R_ncode,$ao_note,$ileader);

            $INSERT INTO CAR706_EQUIP
                    (ipolicy, iendorse,
                     note1, note2, note3, note4, note5, note6, note7, note8, note9, note10,
                     note11, note12, note13, note14, note15, note16, note17, note18, note19, note20,
                     note21, note22, note23, note24, note25, note26, note27, note28, note29, note30,
                     note31, note32, note33, note34, note35, note36, note37, note38, note39, note40,
                     note41, note42, note43, note44, note45, note46, note47, note48, note49, note50,
                     note51, note52, note53, note54, note55, note56, note57, note58, note59, note60,
                     note61, note62, note63, note64, note65, note66, note67, note68, note69, note70,
                     note71, note72, note73, note74, note75, note76, note77, note78, note79, note80,
                     note81, note82, note83, note84, note85, note86, note87, note88, note89, note90)
             VALUES ($ipolicy, $iendorse,
                     $tcode[1],$tcode[2],$tcode[3],$tcode[4],$tcode[5],$tcode[6],$tcode[7],$tcode[8],$tcode[9],$tcode[10],
                     $tcode[11],$tcode[12],$tcode[13],$tcode[14],$tcode[15],$tcode[16],$tcode[17],$tcode[18],$tcode[19],$tcode[20],
                     $tcode[21],$tcode[22],$tcode[23],$tcode[24],$tcode[25],$tcode[26],$tcode[27],$tcode[28],$tcode[29],$tcode[30],

                     $tcode[31],$tcode[32],$tcode[33],$tcode[34],$tcode[35],$tcode[36],$tcode[37],$tcode[38],$tcode[39],$tcode[40],
                     $tcode[41],$tcode[42],$tcode[43],$tcode[44],$tcode[45],$tcode[46],$tcode[47],$tcode[48],$tcode[49],$tcode[50],
                     $tcode[51],$tcode[52],$tcode[53],$tcode[54],$tcode[55],$tcode[56],$tcode[57],$tcode[58],$tcode[59],$tcode[60],

                     $tcode[61],$tcode[62],$tcode[63],$tcode[64],$tcode[65],$tcode[66],$tcode[67],$tcode[68],$tcode[69],$tcode[70],
                     $tcode[71],$tcode[72],$tcode[73],$tcode[74],$tcode[75],$tcode[76],$tcode[77],$tcode[78],$tcode[79],$tcode[80],
                     $tcode[81],$tcode[82],$tcode[83],$tcode[84],$tcode[85],$tcode[86],$tcode[87],$tcode[88],$tcode[89],$tcode[90]

                     );
        }
        $CLOSE cur1;
        $FREE  cur1;
   }
   return SUCCESS;
   
errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(1);
}

/*----------------------------------------------------------------------------*/
long car706_detail()
{
   $int x;

   $WHENEVER SQLERROR GOTO errexit;

   $select nins_type
      into $nins_type
      from insurance_type
     where iins_type = $iins_type;

   rgu_put_body_string( 5,iins_type,LEFT); 
   rgu_put_body_string( 5,nins_type,LEFT);
   strcpy(p_bgn,cm_to_infdate(p_bgn));
   strcpy(p_end,cm_to_infdate(p_end));
   rgu_put_body_string( 4, p_bgn);
   rgu_put_body_string( 4, p_end);
   rgu_put_body_string( 4, cm_get_sysd());   /* get_currdt */
   rgu_put_body(1);
   rgu_put_body(2);
   rgu_put_body(3);
   rgu_put_body(4);
   rgu_put_body(5);
   rgu_put_body(7);
   
   $DECLARE cursor CURSOR FOR
     SELECT ipolicy,iendorse,ioffice_unit,ibig_office,ibig_sales,icard,nassured,
            dply_begin,dply_end,medrins_prem,iofficer,iengine,dendorse,dpolicy,
            L_nname,F_ncode,R_ncode,ao_note,''''||ileader
       INTO $ipolicy,$iendorse,$ioffice_unit,$ibig_office,$ibig_sales,$icard,$nassured,
            $dp_begin,$dp_end,$medrins_prem,$iofficer,$iengine,$dendorse,$dpolicy,
            $L_nname,$F_ncode,$R_ncode,$ao_note,$ileader
       FROM CAR706
      ORDER BY iofficer;
   $OPEN  cursor;
   $FETCH cursor ;
   strcpy(P_iofficer, iofficer);
   strcpy(P_iof,substring(iofficer,1,3)); 
 
   subtot=sumtot=sum_all=0;
   for(;;)
   {
      printf("iofficer[%s]\n",iofficer);
      printf("dp_begin[%s]\n",dp_begin);
      printf("dp_end[%l]\n",dp_end);
 
      if (SQLCODE == SQLNOTFOUND)
      {
         $SELECT ibig_branch[1,8],nname[1,16]
            INTO $ibig_branch,$nname
            FROM ca_big_office
           WHERE ibig_comp = $P_iofficer
             AND fclass = '1';
                   
         if (SQLCODE ==SQLNOTFOUND)
         {
            strcpy(ibig_branch," ");
            strcpy(nname," ");
         }
         strcpy(ibig_branch,rtrim(ibig_branch));
         strcat(ibig_branch,nname);
         car706_subtot();
         $select ngroup
            into $ibig_branch
            from sa_frm_module
           where ifrm_module = '02'
             and igroup = $P_iof;
         if (SQLCODE ==SQLNOTFOUND) 
            strcpy(ibig_branch," ");
         car706_tot();
         car706_tot_all();
         break;  
      } 
      sprintf(N_iof,"%s",substring(iofficer,1,3)); 

      if (strcmp(P_iofficer,iofficer) !=0 )
      {
         $SELECT ibig_branch[1,8],nname[1,16]
            INTO $ibig_branch,$nname
            FROM ca_big_office
           WHERE ibig_comp = $P_iofficer
             AND fclass = '1';
                   
         if (SQLCODE ==SQLNOTFOUND) {
            strcpy(ibig_branch," ");
            strcpy(nname," ");
         }
         strcpy(ibig_branch,rtrim(ibig_branch));
         strcat(ibig_branch,nname);
 
         car706_subtot(); 
      }
                       
      if (strcmp(P_iof,N_iof) !=0)
      {
         $select ngroup
            into $ibig_branch
            from sa_frm_module
           where ifrm_module = '02'
             and igroup = $P_iof;
         if (SQLCODE ==SQLNOTFOUND) 
            strcpy(ibig_branch," ");

         car706_tot();
      }
                   
      for(x=1;x<91;x++)
         strcpy(tcode[x]," ");

      $SELECT note1, note2, note3, note4, note5, note6, note7, note8, note9, note10,
              note11, note12, note13, note14, note15, note16, note17, note18, note19, note20,
              note21, note22, note23, note24, note25, note26, note27, note28, note29, note30
         INTO $tcode[1],$tcode[2],$tcode[3],$tcode[4],$tcode[5],$tcode[6],$tcode[7],$tcode[8],$tcode[9],$tcode[10],
              $tcode[11],$tcode[12],$tcode[13],$tcode[14],$tcode[15],$tcode[16],$tcode[17],$tcode[18],$tcode[19],$tcode[20],
              $tcode[21],$tcode[22],$tcode[23],$tcode[24],$tcode[25],$tcode[26],$tcode[27],$tcode[28],$tcode[29],$tcode[30],

              $tcode[31],$tcode[32],$tcode[33],$tcode[34],$tcode[35],$tcode[36],$tcode[37],$tcode[38],$tcode[39],$tcode[40],
              $tcode[41],$tcode[42],$tcode[43],$tcode[44],$tcode[45],$tcode[46],$tcode[47],$tcode[48],$tcode[49],$tcode[50],
              $tcode[51],$tcode[52],$tcode[53],$tcode[54],$tcode[55],$tcode[56],$tcode[57],$tcode[58],$tcode[59],$tcode[60],

              $tcode[61],$tcode[62],$tcode[63],$tcode[64],$tcode[65],$tcode[66],$tcode[67],$tcode[68],$tcode[69],$tcode[70],
              $tcode[71],$tcode[72],$tcode[73],$tcode[74],$tcode[75],$tcode[76],$tcode[77],$tcode[78],$tcode[79],$tcode[80],
              $tcode[81],$tcode[82],$tcode[83],$tcode[84],$tcode[85],$tcode[86],$tcode[87],$tcode[88],$tcode[89],$tcode[90]
         FROM CAR706_EQUIP
        WHERE ipolicy = $ipolicy
          AND iendorse = $iendorse;

      car706_body();
       
      strcpy(P_iofficer, iofficer);
      strcpy(P_iof,substring(iofficer,1,3)); 
      $FETCH cursor ;
   
   }
   $CLOSE cursor;
   $FREE  cursor;
       
   if (strcmp(trim(iins_type),"17")==0)
   {
      if(strcmp(substring(iofficer,1,1),"A")==0)
         strcpy(car,"�ζ�");
      if(strcmp(substring(iofficer,1,1),"B")==0)
         strcpy(car,"����"); 
      rgu_put_body_string( 12, car);   
      rgu_put_body(11);
      rgu_put_body(12);
      rgu_put_body(13); 
   }
       
   return SUCCESS;
   
errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(1);
}


/*----------------------------------------------------------------------*/

void car706_body()
{
    char buf2[22];
    int  i;

    printf("IN car706_body\n");
    rgu_put_body_string(8,ipolicy,LEFT);
    rgu_put_body_string(8,iendorse,LEFT);
    rgu_put_body_string(8,ioffice_unit,LEFT);
    rgu_put_body_string(8,iofficer,LEFT);
    rgu_put_body_string(8,ibig_office,LEFT);
    rgu_put_body_string(8,ibig_sales,LEFT);
    rgu_put_body_string(8,iengine,LEFT);
    rgu_put_body_string(8,icard,LEFT);
    rgu_put_body_string(8,nassured,LEFT);
    rgu_put_body_string(8,dp_begin,LEFT);
    rgu_put_body_string(8,dp_end ,LEFT);
    rfmtdouble(medrins_prem,"---,---,---,--&",buf2);
    rgu_put_body_string(8,buf2,LEFT);
    rgu_put_body_string(8,dendorse,LEFT);
    rgu_put_body_string(8,dpolicy,LEFT);
    rgu_put_body_string(8,ileader,LEFT);
    rgu_put_body_string(8,L_nname,LEFT);
    rgu_put_body_string(8,R_ncode,LEFT);
    rgu_put_body_string(8,F_ncode,LEFT);
    rgu_put_body_string(8,ao_note,LEFT);

    for (i=1;i<=90;i++)
    rgu_put_body_string(8,tcode[i],LEFT);

/***********************************************
    rgu_put_body_string(8,tcode[2],LEFT);
    rgu_put_body_string(8,tcode[3],LEFT);
    rgu_put_body_string(8,tcode[4],LEFT);
    rgu_put_body_string(8,tcode[5],LEFT);
    rgu_put_body_string(8,tcode[6],LEFT);
    rgu_put_body_string(8,tcode[7],LEFT);
    rgu_put_body_string(8,tcode[8],LEFT);
    rgu_put_body_string(8,tcode[9],LEFT);
    rgu_put_body_string(8,tcode[10],LEFT);
    rgu_put_body_string(8,tcode[11],LEFT);
    rgu_put_body_string(8,tcode[12],LEFT);
    rgu_put_body_string(8,tcode[13],LEFT);
    rgu_put_body_string(8,tcode[14],LEFT);
    rgu_put_body_string(8,tcode[15],LEFT);
    rgu_put_body_string(8,tcode[16],LEFT);
    rgu_put_body_string(8,tcode[17],LEFT);
    rgu_put_body_string(8,tcode[18],LEFT);
    rgu_put_body_string(8,tcode[19],LEFT);
    rgu_put_body_string(8,tcode[20],LEFT);
    rgu_put_body_string(8,tcode[21],LEFT);
    rgu_put_body_string(8,tcode[22],LEFT);
    rgu_put_body_string(8,tcode[23],LEFT);
    rgu_put_body_string(8,tcode[24],LEFT);
    rgu_put_body_string(8,tcode[25],LEFT);
    rgu_put_body_string(8,tcode[26],LEFT);
    rgu_put_body_string(8,tcode[27],LEFT);
    rgu_put_body_string(8,tcode[28],LEFT);
    rgu_put_body_string(8,tcode[29],LEFT);
    rgu_put_body_string(8,tcode[30],LEFT);
****************************************************/

    rgu_put_body(8);
    subtot += medrins_prem;
    max_cnt++;
}
/*----------------------------------------------------------------------*/

void car706_subtot()
{
    char buf2[22];
    printf("IN car706_subtot\n");
    rgu_put_body_string(9,ibig_branch,LEFT);
    rfmtdouble(subtot,"---,---,---,--&",buf2);
    rgu_put_body_string(9,buf2,LEFT);
    rgu_put_body(9);
    sumtot += subtot;
    subtot = 0;
}
/*----------------------------------------------------------------------*/
void car706_tot()
{ 
    $char str[22];
    printf( "IN car706_tot\n");
    rgu_put_body_string(10,ibig_branch,LEFT);
    rfmtdouble(sumtot,"---,---,---,--&",str);
    rgu_put_body_string(10,str,LEFT);
    rgu_put_body(10);
    sum_all += sumtot;
    sumtot = 0;
}
/*-----------------------------------------------------------------------*/
void car706_tot_all()
{  
    $char str[22];
    printf(" IN car706_tot_all\n");
    rfmtdouble(sum_all,"---,---,---,--&",str);
    rgu_put_body_string(14,str,LEFT);
    printf(" sum_all [%f] \n",sum_all);
    rgu_put_body(14);
}

