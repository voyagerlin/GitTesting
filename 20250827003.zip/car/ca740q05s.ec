/**********************************************************************/
/*   program id   : ca740q05s.ec                                      */
/*   program name : �C��n�O��ƪ�                                    */
/*   date written : 2023/06/12 by 120957                              */
/*   files        : sysdb:ca_rioho_pol_req , officer,                 */
/*        	    sa_branch_type                                    */
/*                                                                    */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"
$include decimal;

DBinfo *list;
int   count_db;
char  outputf[21];
$char DBName[5];
$char userid[11], userid2[11];
$char msgbuf[128];
char aphome[40];

$char fclass[2],date1[11],date2[11],dbgn[11],dend[11];
char sp_yy[4], sp_mm[3], sp_dd[3], filedate[20];

$char stmt[4096],sMsg[4096];

int rc;
$int mail_count = 0;
$int data_count = 0;
FILE *fp;

main(argc, argv)
int argc;
char **argv;
{
    batchinit();
    strcpy(DBName,       isNULLstr(argv[1]));
    strcpy(userid2,       isNULLstr(argv[2]));
    strcpy(fclass, 	 isNULLstr(argv[3])); 
    strcpy(date1,        isNULLstr(argv[4]));
    strcpy(date2,        isNULLstr(argv[5]));
    strcpy(outputf,      isNULLstr(argv[6]));
    
    strcpy(dbgn, cm_to_infdate(date1));
    strcpy(dend, cm_to_infdate(date2));
	cm_split_ymd(dend, sp_mm, sp_dd, sp_yy);
	sprintf_s(filedate, sizeof filedate, "%s-%s-%s", sp_yy, sp_mm, sp_dd);
	
    strncpy(userid, userid2, 6);
	userid[6] = '\0';
    
    printf("DBName[%s]\n",DBName);
    printf("-- ����϶�(�褸):[%s] ~ [%s]\n",dbgn,dend); /*������褸�~*/
    printf("outputf[%s]\n",outputf);
	printf("userid = [%s], userid2 = [%s]\n", userid, userid2);
	printf("filedate = [%s]", filedate);
    
    rc = car740_get_db();
    if (rc != M_CM_OK)
       return rc;

    /* Create table car740_tmp1 */
    rc = ca740_create_temp();
    if (rc != M_CM_OK)
       return rc;
   
    /* Create table car740_tmp2 */
    rc = ca740_create_temp_ileader();
	if (rc != M_CM_OK)
       return rc;
    
    rc = car740_prepare_data();
    if (rc != M_CM_OK)
       return rc;    
       
    /*build report - ����*/
    rc = car740_build();
    if (rc != M_CM_OK)
       return rc;
    
	/* write email - �Ƶ{�H�H�\�� */
	if(strlen(userid2) == 7)
	{
		rc = car740_write_email();
		if (rc != M_CM_OK)
			return rc;
		
		rc = car740_email_final();
		if (rc != M_CM_OK)
			return rc;
	}
}

long car740_build()
{
   int rc;
    char    sfilename[81],stitle[2048],stmt[2048];

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(sfilename,"�n�O�����[CAR740]");
    strcat(sfilename,"\n");

    strcpy(stitle,"\t�{���N��:CAR740\t�n�O��ƪ�\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");
    strcat(stitle,"\n");

    strcat(stitle,"\t�O�I���q\t�ǰe����\t�n�O�ѽs��\t�s/��O(1.�s�O 2.��O)\t��J�I��(1.�j���I 2.���N�I 3.�j���I ���N�I)"
    "\t�g�P��\t���I\t�g��N��\t�޲z�H�W��\t�~�Z���W��\t�n���~�ȭ��m�W\t�Q�O�I�H"
    "\t�������X\t�������X\t�P�Ӹ��X\t�j���I�_�O���\t�j���I������\t�j���I�Ҹ�\t�j���I�O�O"
    "\t���N�I�_�O���\t���N�I������\t���N�I�d��\t���N�I�O�O\t�`�O�O\t���ɤ��");

    strcpy(stmt,"select *"
    		"  from car740_tmp1");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);
    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;

}

long car740_prepare_data()
{
   $char iinsur_comp[3],iauto_no[16],qsend_qty[5],fnew_yn[2],finsur_kind[2],ivend_no[4],ibranch_no[3],
   iofficer[11],nname[11],nbranch[41],ieng_no[21],icar_no[21],ilicense_no[11],iforce_card_no[21],irand_card_no[21],
   dforce_dates[11],dforce_datee[11],drand_dates[11],drand_datee[11],dcreate[11],	/*date*/
   mforce_amt[8],mrand_amt[8],minsu_amt[11],	/*decimal*/
   ileader[11],iquota[7];  
   
   $nvarchar nemp_name[10],ninsu_name[40];
   	

   $WHENEVER SQLERROR GOTO errexit;

   
	sprintf_s(stmt, sizeof stmt,
		"SELECT iinsur_comp,qsend_qty,iauto_no,fnew_yn,finsur_kind,ivend_no,ibranch_no,"
		"nemp_name,ninsu_name,ieng_no,icar_no,ilicense_no,dforce_dates,dforce_datee,iforce_card_no,"
		"mforce_amt,drand_dates,drand_datee,irand_card_no,mrand_amt,minsu_amt,DATE(dcreate)"
		"  FROM sysdb:ca_rioho_pol_req "
		"   WHERE dcreate BETWEEN to_date('%s','%%m/%%d/%%Y') "
		"   AND to_date('%s 23:59:59','%%m/%%d/%%Y %%H:%%M:%%S')" 
		,dbgn,dend);
		/*��ƫ��A��datetime�A�ݸɤW�ɶ�*/
		

	  printf("stmt[%s]\n", stmt);

          $PREPARE pre1 FROM $stmt;
          $DECLARE cur_pre1 CURSOR for pre1;
      	  $OPEN cur_pre1;

      	while(1)
      	{	
      		
		
         	$FETCH cur_pre1 INTO $iinsur_comp,$qsend_qty,$iauto_no,$fnew_yn,$finsur_kind,$ivend_no,$ibranch_no,$nemp_name,
         	$ninsu_name,$ieng_no,$icar_no,$ilicense_no,$dforce_dates,$dforce_datee,$iforce_card_no,$mforce_amt,$drand_dates,
         	$drand_datee,$irand_card_no,$mrand_amt,$minsu_amt,$dcreate;

         	if(SQLCODE == SQLNOTFOUND) break;
		strcpy(iofficer,"");
		strcpy(nname,"");
		strcpy(nbranch,"");
		/*�M���٥��Q���Ϊ��g��N��*/
		$SELECT FIRST 1 iofficer 
		   INTO $iofficer	
		   FROM officer
		  WHERE (dexpire IS NULL OR dexpire>today)
		    AND ibus_location = trim($ivend_no)||trim($ibranch_no);
			
		    
		/*�M��w���Ϊ�"�̪�"�@���g�N*/
		if(SQLCODE == SQLNOTFOUND) 
		{
			$SELECT FIRST  1 iofficer
			   INTO $iofficer
			   FROM officer
			  WHERE dexpire IS NOT NULL 
			    AND ibus_location = trim($ivend_no)||trim($ibranch_no)
			    AND dexpire >=(SELECT max(dexpire) FROM officer);
			    /*printf("iofficer[%S]\n",iofficer);*/
			    	  
		};
		
		strcpy(ileader,"");
		strcpy(iquota,"");
		
		if(strlen(iofficer)!=0  )
		{
			strcpy(ileader,"");
			strcpy(iquota,"");
			$SELECT ileader 
			   INTO $ileader
			   FROM officer
			  WHERE iofficer = $iofficer;	
			  
			$SELECT nname,iquota 
			   INTO $nname,$iquota
			   FROM officer
			  WHERE iofficer = $ileader;
			
			$SELECT nbranch
			   INTO $nbranch
			   FROM sa_branch_type
			  WHERE ibranch = $iquota;  
		};

			$INSERT INTO car740_tmp2 (ileader) VALUES (trim($ileader));
			printf("ileader = [%s]", ileader);
		
		
		/*		
         	printf(
         	"iinsur_comp[%s]\n"
         	"qsend_qty[%s]\n"
         	"iauto_no[%s]\n"
         	"fnew_yn[%s]\n"
         	"finsur_kind[%s]\n"
         	"ivend_no[%s]\n"
         	"ibranch_no[%s]\n"
         	"iofficer[%s]\n"
         	"nname[%s]\n"
         	"nbranch[%s]\n"
         	"nemp_name[%s]\n"
         	"ninsu_name[%s]\n"
         	"ieng_no[%s]\n"
         	"icar_no[%s]\n"
         	"ilicense_no[%s]\n"
         	"dforce_dates[%s]\n"
         	"dforce_datee[%s]\n"
         	"iforce_card_no[%s]\n"
         	"mforce_amt[%s]\n"
         	"drand_dates[%s]\n"
         	"drand_datee[%s]\n"
         	"irand_card_no[%s]\n"
         	"mrand_amt[%s]\n"
         	"minsu_amt[%s]\n"
         	"dcreate[%s]\n"
         	,iinsur_comp,qsend_qty,iauto_no,fnew_yn,finsur_kind,ivend_no,ibranch_no,iofficer,nname,nbranch,
         	nemp_name,ninsu_name,ieng_no,icar_no,ilicense_no,dforce_dates,dforce_datee,iforce_card_no,
         	mforce_amt,drand_dates,drand_datee,irand_card_no,mrand_amt,minsu_amt,dcreate);
		*/


		$INSERT INTO car740_tmp1
          		     (iinsur_comp,qsend_qty,iauto_no,fnew_yn,finsur_kind,ivend_no,ibranch_no,iofficer,nname,nbranch,
          		     nemp_name,ninsu_name,ieng_no,icar_no,ilicense_no,dforce_dates,dforce_datee,iforce_card_no,
          		     mforce_amt,drand_dates,drand_datee,irand_card_no,mrand_amt,minsu_amt,dcreate)
		      	VALUES
          		     ($iinsur_comp,$qsend_qty,$iauto_no,$fnew_yn,$finsur_kind,$ivend_no,$ibranch_no,$iofficer,$nname,$nbranch,
          		     $nemp_name,$ninsu_name,$ieng_no,$icar_no,$ilicense_no,$dforce_dates,$dforce_datee,$iforce_card_no,
          		     $mforce_amt,$drand_dates,$drand_datee,$irand_card_no,$mrand_amt,$minsu_amt,$dcreate);

	}
        $CLOSE cur_pre1;
        $FREE cur_pre1;



     return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

long car740_write_email()
{
	$char stmt2[128], stmt3[1024], mail_subject[128], mail_msg[512];
	char csvtitle[2048];
	$char nleader[31], ileader2[11], today_date[20], receiver_name[31], receiver_email[128];
	$char fname[150], filename[201], nattachment[201];
	$char stmt4[256];
	
	$char iinsur_comp[3],iauto_no[16],qsend_qty[5],fnew_yn[2],finsur_kind[2],ivend_no[4],ibranch_no[3],
    iofficer[11],nname[11],nbranch[41],ieng_no[21],icar_no[21],ilicense_no[11],iforce_card_no[21],irand_card_no[21],
    dforce_dates[11],dforce_datee[11],drand_dates[11],drand_datee[11],dcreate[11],	/*date*/
    mforce_amt[8],mrand_amt[8],minsu_amt[11];	/*decimal*/
   
	$char nemp_name[41],ninsu_name[41];
	int no_iofficer = 0;
	
	$loc_t ctxt;
	
	$WHENEVER SQLERROR GOTO errexit;
	
	$SELECT count(*) INTO $data_count FROM car740_tmp1;
	
	if(data_count == 0)
		return M_CM_OK;
	
	sprintf_s(stmt2, sizeof stmt2, 
				"SELECT UNIQUE ileader "
				"  FROM car740_tmp2 "
				" WHERE (ileader <> '' AND ileader IS NOT NULL);");
				
	printf("stmt2 = [%s]\n", stmt2);
	
	/********************* �H��ǳ� *********************/
	sprintf_s(mail_subject, sizeof mail_subject, "�i���M�O�N�j�C��n�O���(%s)", dend);
	sprintf_s(mail_msg, sizeof mail_msg, "�U��P����w�G<br><br>���󬰤��M�O�N�t����J���n�O��ơA�Яd�N�X��i�ת��p�A���¡C");
	
	ctxt.loc_loctype = LOCMEMORY;
    ctxt.loc_buffer = mail_msg;
    ctxt.loc_bufsize = 9000;
    ctxt.loc_size =  strlen(mail_msg) + 1;
	/****************************************************/
	
	/**********���ɷǳ�**********/
	memset(csvtitle, 0x00, sizeof(csvtitle));
	
	sprintf_s(csvtitle, sizeof csvtitle, "�O�I���q,�ǰe����,�n�O�ѽs��,�s/��O(1.�s�O 2.��O),��J�I��(1.�j���I 2.���N�I 3.�j���I ���N�I)"
    ",�g�P��,���I,�g��N��,�޲z�H�W��,�~�Z���W��,�n���~�ȭ��m�W,�Q�O�I�H"
    ",�������X,�������X,�P�Ӹ��X,�j���I�_�O���,�j���I������,�j���I�Ҹ�,�j���I�O�O"
    ",���N�I�_�O���,���N�I������,���N�I�d��,���N�I�O�O,�`�O�O,���ɤ��\n");
	
	memset(fname,0x00,sizeof(fname));
	memset(nattachment,0x00,sizeof(nattachment));
	memset(filename,0x00,sizeof(filename));
	/****************************/
	
	$PREPARE pre2 FROM $stmt2;
    $DECLARE cur_pre2 CURSOR for pre2;
    $OPEN cur_pre2;
	
	/**********���g��N��**********/
	while(1)
	{
		/**********�H�����**********/
		$FETCH cur_pre2 INTO $ileader2;
		
		if(SQLCODE == SQLNOTFOUND) break;
		
		$SELECT nname INTO $nleader FROM officer WHERE iofficer = $ileader2;
		
		sprintf_s(fname, sizeof fname, "�i���M�O�N�j�C��n�O���(%s)_%s", filedate, trim(nleader));
		sprintf_s(nattachment, sizeof nattachment, "%s.csv", fname);
		sprintf_s(filename, sizeof filename, "%s/rptftp/car_email/%s.csv",aphome,fname);
		
		sprintf_s(stmt3, sizeof stmt3, "SELECT iinsur_comp, qsend_qty, iauto_no, fnew_yn, finsur_kind, ivend_no, ibranch_no, iofficer, nname, nbranch,"
					  " nemp_name, ninsu_name, ieng_no, icar_no, ilicense_no, dforce_dates, dforce_datee, iforce_card_no, mforce_amt, drand_dates,"
					  " drand_datee, irand_card_no, mrand_amt, minsu_amt, dcreate"
					  "  FROM car740_tmp1 "
					  " WHERE (SELECT ileader FROM officer WHERE iofficer = car740_tmp1.iofficer) = '%s' ", trim(ileader2));
		
		printf("fname = [%s], nattachment = [%s], filename = [%s]\n", fname, nattachment, filename);
		
		printf("stmt3 = [%s]\n", stmt3);
		
		fp = fopen(filename, "w");
		fprintf(fp, csvtitle);
		
		$PREPARE pre3 FROM $stmt3;
		$DECLARE cur_pre3 CURSOR for pre3;
		$OPEN cur_pre3;
		
		while(1)
		{
			$FETCH cur_pre3 INTO $iinsur_comp,$qsend_qty,$iauto_no,$fnew_yn,$finsur_kind,$ivend_no,$ibranch_no,$iofficer,$nname,$nbranch,
          		     $nemp_name,$ninsu_name,$ieng_no,$icar_no,$ilicense_no,$dforce_dates,$dforce_datee,$iforce_card_no,
          		     $mforce_amt,$drand_dates,$drand_datee,$irand_card_no,$mrand_amt,$minsu_amt,$dcreate;
					 
			if(SQLCODE == SQLNOTFOUND) break;
			
			fprintf(fp, "%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,"
			        "%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,"
					"%s,%s,%s,%s,%s\n",
					iinsur_comp, qsend_qty, iauto_no, fnew_yn, finsur_kind, ivend_no, ibranch_no, iofficer, nname, nbranch,
					nemp_name, ninsu_name, ieng_no, icar_no, ilicense_no, dforce_dates, dforce_datee, iforce_card_no, mforce_amt, drand_dates,
					drand_datee, irand_card_no, mrand_amt, minsu_amt, dcreate);
		}
		
		$FREE  pre3;
		$CLOSE cur_pre3;
		fclose(fp);
		
		
		/**********batchemail**********/
		  
		$SELECT chinese_name, trim(email)||'@tmnewa.com.tw'
		   INTO $receiver_name, $receiver_email
		   FROM personal:asempl
		  WHERE empl_no = trim($ileader2);

		$INSERT INTO batchemail
		    (project_id, mail_date, receiver_email, receiver_name, cc,
    	     content, key, mail_count, nsubject ,nattachment)
		VALUES
		     ('CAR7405', today, $receiver_email, $receiver_name, "",
			  $ctxt, $fname, 1, $mail_subject, $nattachment);
			  
		mail_count++;
	}
	
	$FREE  pre2;
	$CLOSE cur_pre2;
	/********************/
	
	/**********�L�g��N��**********/
	
	$SELECT chinese_name
	   INTO $nleader
	   FROM personal:asempl
	 WHERE empl_no = $userid;
	
	sprintf_s(fname, sizeof fname, "�i���M�O�N�j�C��n�O���(%s)_%s", filedate, trim(nleader));
	sprintf_s(nattachment, sizeof nattachment, "%s.csv", fname);
	sprintf_s(filename, sizeof filename, "%s/rptftp/car_email/%s.csv",aphome,fname);
	
	sprintf_s(stmt3, sizeof stmt3, "SELECT iinsur_comp, qsend_qty, iauto_no, fnew_yn, finsur_kind, ivend_no, ibranch_no, iofficer, nname, nbranch, "
					  " nemp_name, ninsu_name, ieng_no, icar_no, ilicense_no, dforce_dates, dforce_datee, iforce_card_no, mforce_amt, drand_dates, "
					  " drand_datee, irand_card_no, mrand_amt, minsu_amt, dcreate"
					  "  FROM car740_tmp1 "
					  " WHERE (iofficer = '' OR iofficer IS NULL) ");
	
	fp = fopen(filename, "w");
	fprintf(fp, csvtitle);

	$PREPARE pre3_2 FROM $stmt3;
    $DECLARE cur_pre3_2 CURSOR for pre3_2;
    $OPEN cur_pre3_2;

	while(1)
	{
		$FETCH cur_pre3_2 INTO $iinsur_comp,$qsend_qty,$iauto_no,$fnew_yn,$finsur_kind,$ivend_no,$ibranch_no,$iofficer,$nname,$nbranch,
          		     $nemp_name,$ninsu_name,$ieng_no,$icar_no,$ilicense_no,$dforce_dates,$dforce_datee,$iforce_card_no,
          		     $mforce_amt,$drand_dates,$drand_datee,$irand_card_no,$mrand_amt,$minsu_amt,$dcreate;
		
		if(SQLCODE == SQLNOTFOUND) break;
		
		no_iofficer = 1;
		
		fprintf(fp, "%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,"
			        "%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,"
					"%s,%s,%s,%s,%s\n",
					iinsur_comp, qsend_qty, iauto_no, fnew_yn, finsur_kind, ivend_no, ibranch_no, iofficer, nname, nbranch,
					nemp_name, ninsu_name, ieng_no, icar_no, ilicense_no, dforce_dates, dforce_datee, iforce_card_no, mforce_amt, drand_dates,
					drand_datee, irand_card_no, mrand_amt, minsu_amt, dcreate);
	}
	
	$FREE  pre3_2;
	$CLOSE cur_pre3_2;
	fclose(fp);
	
	/**********batchemail**********/
	
	if(no_iofficer >= 1) /* �p�G�s�b�S���g��N������Ƥ~�g�Jbatchemail */
	{
		$SELECT chinese_name, trim(email)||'@tmnewa.com.tw'
		   INTO $receiver_name, $receiver_email
		   FROM personal:asempl
		  WHERE empl_no = $userid;

		$INSERT INTO batchemail
			(project_id, mail_date, receiver_email, receiver_name, cc,
			 content, key, mail_count, nsubject ,nattachment)
		VALUES
			 ('CAR7405', today, $receiver_email, $receiver_name, "",
			  $ctxt, $fname, 1, $mail_subject, $nattachment);
			  
		mail_count++;
	}
	
	return M_CM_OK;
	
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

long car740_email_final()
{
	$char stmt3[1024], mail_subject[128], mail_msg[512];
	char csvtitle[2048];
	$char receiver_name[31], receiver_email[128];
	$char fname[150], filename[201], nattachment[201];
	
	$char iinsur_comp[3],iauto_no[16],qsend_qty[5],fnew_yn[2],finsur_kind[2],ivend_no[4],ibranch_no[3],
    iofficer[11],nname[11],nbranch[41],ieng_no[21],icar_no[21],ilicense_no[11],iforce_card_no[21],irand_card_no[21],
    dforce_dates[11],dforce_datee[11],drand_dates[11],drand_datee[11],dcreate[11],	/*date*/
    mforce_amt[8],mrand_amt[8],minsu_amt[11];	/*decimal*/
   
	$char nemp_name[41],ninsu_name[41];
	
	$loc_t ctxt;
	
	if(data_count == 0)
		return M_CM_OK;
	
	$WHENEVER SQLERROR GOTO errexit;
	
	/********************* �H��ǳ� *********************/
	sprintf_s(mail_subject, sizeof mail_subject, "�i���M�O�N�j�C��n�O���_�`��(%s)", dend);
	sprintf_s(mail_msg, sizeof mail_msg, "���󬰤��M�O�N�t����J���n�O��ơA�`�@ %d ���C", data_count);
	
	ctxt.loc_loctype = LOCMEMORY;
    ctxt.loc_buffer = mail_msg;
    ctxt.loc_bufsize = 9000;
    ctxt.loc_size =  strlen(mail_msg) + 1;
	/****************************************************/
	
	/**********���ɷǳ�**********/
	memset(csvtitle, 0x00, sizeof(csvtitle));
	
	sprintf_s(csvtitle, sizeof csvtitle, "�O�I���q,�ǰe����,�n�O�ѽs��,�s/��O(1.�s�O 2.��O),��J�I��(1.�j���I 2.���N�I 3.�j���I ���N�I)"
    ",�g�P��,���I,�g��N��,�޲z�H�W��,�~�Z���W��,�n���~�ȭ��m�W,�Q�O�I�H"
    ",�������X,�������X,�P�Ӹ��X,�j���I�_�O���,�j���I������,�j���I�Ҹ�,�j���I�O�O"
    ",���N�I�_�O���,���N�I������,���N�I�d��,���N�I�O�O,�`�O�O,���ɤ��\n");

	sprintf_s(fname, sizeof fname, "�i���M�O�N�j�C��n�O���_�`��(%s)", filedate);
	sprintf_s(nattachment, sizeof nattachment, "%s.csv", fname);
	sprintf_s(filename, sizeof filename, "%s/rptftp/car_email/%s.csv",aphome,fname);
		
	/****************************/
	
	sprintf_s(stmt3, sizeof stmt3, "SELECT iinsur_comp, qsend_qty, iauto_no, fnew_yn, finsur_kind, ivend_no, ibranch_no, iofficer, nname, nbranch,"
					  " nemp_name, ninsu_name, ieng_no, icar_no, ilicense_no, dforce_dates, dforce_datee, iforce_card_no, mforce_amt, drand_dates,"
					  " drand_datee, irand_card_no, mrand_amt, minsu_amt, dcreate"
					  "  FROM car740_tmp1 ");
	
	fp = fopen(filename, "w");
	fprintf(fp, csvtitle);
	
	$PREPARE pre3_3 FROM $stmt3;
	$DECLARE cur_pre3_3 CURSOR for pre3_3;
	$OPEN cur_pre3_3;
	
	while(1)
	{
		$FETCH cur_pre3_3 INTO $iinsur_comp,$qsend_qty,$iauto_no,$fnew_yn,$finsur_kind,$ivend_no,$ibranch_no,$iofficer,$nname,$nbranch,
          		     $nemp_name,$ninsu_name,$ieng_no,$icar_no,$ilicense_no,$dforce_dates,$dforce_datee,$iforce_card_no,
          		     $mforce_amt,$drand_dates,$drand_datee,$irand_card_no,$mrand_amt,$minsu_amt,$dcreate;
		
		if(SQLCODE == SQLNOTFOUND) break;
		
		fprintf(fp, "%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,"
			        "%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,"
					"%s,%s,%s,%s,%s\n",
					iinsur_comp, qsend_qty, iauto_no, fnew_yn, finsur_kind, ivend_no, ibranch_no, iofficer, nname, nbranch,
					nemp_name, ninsu_name, ieng_no, icar_no, ilicense_no, dforce_dates, dforce_datee, iforce_card_no, mforce_amt, drand_dates,
					drand_datee, irand_card_no, mrand_amt, minsu_amt, dcreate);
	}
	
	$FREE  pre3_3;
	$CLOSE cur_pre3_3;
	fclose(fp);
	
	/**********batchemail**********/
		  
	$SELECT chinese_name, trim(email)||'@tmnewa.com.tw'
	   INTO $receiver_name, $receiver_email
	   FROM personal:asempl
	  WHERE empl_no = $userid;

	$INSERT INTO batchemail
	    (project_id, mail_date, receiver_email, receiver_name, cc,
         content, key, mail_count, nsubject ,nattachment)
	VALUES
	     ('CAR7405', today, $receiver_email, $receiver_name, "",
		  $ctxt, $fname, 1, $mail_subject, $nattachment);
		  
	return M_CM_OK;
	
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}


long ca740_create_temp()
{
   /* Create table car740_tmp1 */
   $create temp table car740_tmp1
	(
	 iinsur_comp		char(2),	/*�O�I���q�N��*/
	 qsend_qty		int,		/*�ǰe��Ƶ���*/
	 iauto_no		char(15),	/*�n�O�ѽs��*/
	 fnew_yn		char(1),	/*�s/��O*/	
	 finsur_kind		char(1),	/*��J�I��*/
	 ivend_no		char(3),	/*�g�P��*/
	 ibranch_no		char(2),	/*���I*/
	 iofficer		char(10),	/*�g��N��*/
	 nname			char(10),	/*�޲z�H�W��*/
	 nbranch		char(40),	/*�~�Z���W��*/
	 nemp_name		nvarchar(10),	/*�n���~�ȭ��m�W*/
	 ninsu_name		nvarchar(40),	/*�Q�O�I�H*/
	 ieng_no		char(20),	/*�������X*/
	 icar_no		char(20),	/*�������X*/
	 ilicense_no		char(10),	/*�P�Ӹ��X*/
	 dforce_dates		date,		/*�j���I�_�O���*/
	 dforce_datee		date,		/*�j���I������*/
	 iforce_card_no		char(20),	/*�j���I�Ҹ�*/
	 mforce_amt		decimal(7,0),	/*�j���I�O�O*/
	 drand_dates		date,		/*���N�I�_�O���*/
	 drand_datee		date,		/*���N�I������*/
	 irand_card_no		char(20),	/*���N�I�d��*/
	 mrand_amt		decimal(7,0),	/*���N�I�O�O*/
	 minsu_amt		decimal(10,0),	/*�`�O�O*/
	 dcreate		date		/*�إߤ��*/
	
	)with no log;
	
	printf("temp[%s]\n","temp_table_ok");
	
    return M_CM_OK;
    

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

long ca740_create_temp_ileader()
{
	$create temp table car740_tmp2
	(
	 ileader		char(10) /*�޲z�H�N��*/
	)with no log;
	
	printf("temp_ileader OK\n");
	
	return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;

}

long car740_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }

   if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
      if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
         return M_CM_NOT_DBLIST;
   }
   
   rc = getApHome(aphome);
   if (rc < 0)
	{
      EWRITE(userid, -1, "In sigalrmcatcher func==>read config file error!!");
      return rc;
	}

   return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}