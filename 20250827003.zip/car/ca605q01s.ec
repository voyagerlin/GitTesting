/**********************************************************************/
/*                                                                    */
/*   program id   : ca605q01s.ec                                      */
/*   program name : B2B�q���X����Ӫ�                                 */
/*   date written : 2011/01/31                                        */
/*   author       : Jessie                                            */
/**********************************************************************/
/*                             MODIFICATION LOG                        *
 *                                                                     *
 *   DATE         SE                         DESCRIPTION               *
 * --------  -------------  ----------------------------------------   *
 *                                                                     *
 **********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
#include "safeclib.h"
/*--------------------------------------------------------------------*/
$char dbgn1[11], dend1[11], iroute[21];
$char fcard1[2],fcard2[2],type[2];

char  msgbuf[100];

int     count_db;
DBinfo  *list;

$char DBName[05];
char  outputf[N_FILE+1];
$char userid[11];

$char stmt_tmp1[1024],stmt_tmp2[1024];
/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
   int  rc;

   batchinit();
   strcpy(DBName, isNULLstr(argv[1]));
   strcpy(userid, isNULLstr(argv[2]));
   strcpy(fcard2, isNULLstr(argv[3]));	/* ���N */
   strcpy(fcard1, isNULLstr(argv[4]));	/* �j�� */
   strcpy(iroute, isNULLstr(argv[5]));
   strcpy(type,   isNULLstr(argv[6]));
   strcpy(dbgn1,  isNULLstr(argv[7]));
   strcpy(dend1,  isNULLstr(argv[8]));
   strcpy(outputf,isNULLstr(argv[9]));
   strcpy(dbgn1,  cm_to_infdate(dbgn1));
   strcpy(dend1,  cm_to_infdate(dend1));

   rc = car605_get_db();
   if ( rc != M_CM_OK)
        return rc;

   strcpy(msgbuf," ");
   rc = car605_privilege();
   if ( rc != M_CM_OK)
        return rc;

   rc = car605_initial();
   if ( rc != M_CM_OK)
        return rc;
   
   if (fcard2[0]=='1') {
       rc = car605_process("2");
       if ( rc != M_CM_OK)
           return rc;
   }
   if (fcard1[0]=='1') {
       rc = car605_process("1");
       if ( rc != M_CM_OK)
           return rc;
   }

   rc = car605_print();
   if ( rc != M_CM_OK)
        return rc;

}
/*--------------------------------------------------------------------*/
long car605_get_db()
{
   if (db_select(DBName) == FALSE) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   return M_CM_OK;
}
/*--------------------------------------------------------------------*/
long car605_initial()
{
   $whenever sqlerror goto errexit;

   sprintf_s(stmt_tmp1, sizeof stmt_tmp1,"create temp table car605 ( "
	"iroute		char(20), "
	"iofficer	char(10), "
	"itmp		char(20), "
	"ipolicy	char(20), "
	"icard		char(20), "
	"iassured	char(10), "
	"nassured	char(20), "
	"itag		char(%d), "
	"dbegin		date, "
	"dpolicy	date, "
	"dentry		date, "
	"icar_type       char(2), "
	"ncode 		char(10),  "
	"iins_type       char(100), "
	"prem  		integer, "
	"iest		char(20) default ' ', "
	"dori		date, "
	"dacc_last	date "
    ")with no log;",CA_TAG_NUM-1);
     $PREPARE stmp1 FROM $stmt_tmp1;
     $EXECUTE stmp1;

   $create index car605_ix on car605(itmp);

   sprintf_s(stmt_tmp2, sizeof stmt_tmp2,"create temp table car605_1( "
	"iroute		char(20), "
	"iofficer	char(10), "
	"itmp		char(20), "
	"ipolicy	char(20), "
	"icard		char(20), "
	"iassured	char(10), "
	"nassured	char(20), "
	"itag		char(%d), "
	"dbegin		date, "
	"dpolicy	date, "
	"dentry		date, "
	"icar_type       char(2), "
	"ncode 		char(10),   "
	"iins_type       char(100), "
	"prem  		integer, "
	"dacc_last	date "
    ")with no log;",CA_TAG_NUM-1);
     $PREPARE stmp2 FROM $stmt_tmp2;
     $EXECUTE stmp2;

   $create index car6051_ix on car605_1(itmp);
   
   $create temp table car605_2(
	ipolicy		char(25),
	dacc_last	date
    )with no log;

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car605_process(fcard)
$char	*fcard;
{
int     k,rc;
$int	cnt = 0;
$char   stmt[2048],stmt1[1024],stmt2[1024],stmt3[1024],stmt4[1024];
$char	stmt_fcard[256],iins_type1[100],tmp1[7];


$char   iroute1[21],iofficer1[11],itmp1[21],ipolicy1[21],ipolicy2[6],icard1[21];
$char   iassured1[11],nassured1[21],itag1[CA_TAG_NUM],dbegin1[11],dpolicy1[11];
$char   dentry1[11],icar_type1[3],ncode1[11],iest1[21],dori1[11],dacc_last[11];
$char   temp_ipolicy[26];
$long prem1 = 0;
$int check = 0;

    $whenever sqlerror goto errexit;
    
    if(strcmp(trim(type),"2") == 0)
    {
    	sprintf_s(stmt, sizeof stmt,"insert into car605_2  "
    		"select trim(a.ipolicy1 || a.ipolicy2),date(dacc_last)  "
		"  from cm_pre_receive a, ao_prercv_pass b ,cm_route c "
		" where date(b.dacc_last) >= '%s' "
		"   and date(b.dacc_last) <= '%s' "
		"   and a.ipre_rcv = b.ipre_rcv     "
		"   and a.iins_kind = b.iins_kind   "
                "   and a.ipre_end = b.ipre_end     "
                "   and a.iendorse = ' '  "
                "   and a.iroute = c.iroute  "
                "   and a.iins_kind ='%s' "
                "   and c.iroute_main = '%s'",dbgn1,dend1,fcard,iroute);

        $prepare pre_cur2 from $stmt;
	$execute pre_cur2;        

    }
   
    for(k=0;k<count_db;k++) 
    {
	if(strcmp(trim(type),"1") == 0)
	{
	sprintf_s(stmt, sizeof stmt,"insert into car605_1  "
		"select b.iroute,a.iofficer,a.itmp_policy,a.ipolicy,a.icard,  "
		"	b.iassured,b.nassured[1,20],b.itag,a.dply_begin,a.dpolicy,a.dentry,  "
		"       a.icar_type,d.ncode ,  "
		"       '',(a.mdmg_prem+a.mlia_prem),  "
		"       nvl((select date(f.dacc_last)  "
		"              from cm_pre_receive e, ao_prercv_pass f " 
		"             where e.ipre_rcv = f.ipre_rcv "   
		"               and e.iins_kind = f.iins_kind "  
                "               and e.ipre_end = f.ipre_end  "
                "               and e.iendorse = ' '  "
                "               and e.ipolicy1 = a.ipolicy ),' ')  "
		"  from %s:ply_relation a,%s:policy b,cm_route c ,car_type d  "
		" where a.dpolicy >= ? "
		"   and a.dpolicy <= ? "
		"   and a.fcard_class =? "
		"   and a.ipolicy = b.ipolicy "
		"   and b.iroute = c.iroute "
		"   and c.iroute_main = ? "
		"   and d.icode= a.icar_type  "
		"   and d.fclass='1' ",list[k].dbname,list[k].dbname);

	$prepare pre_cur1 from $stmt;
	$execute pre_cur1 using $dbgn1, $dend1, $fcard, $iroute;
	
	}
	else
	{
        sprintf_s(stmt, sizeof stmt,"insert into car605_1  "
		"select b.iroute,a.iofficer,a.itmp_policy,a.ipolicy,a.icard,  "
		"	b.iassured,b.nassured[1,20],b.itag,a.dply_begin,a.dpolicy,a.dentry,  "
		"       a.icar_type,c.ncode ,  "
		"       '',(a.mdmg_prem+a.mlia_prem),d.dacc_last  "
		"  from %s:ply_relation a,%s:policy b ,car_type c ,car605_2 d  "
		" where a.ipolicy = b.ipolicy "
		"   and a.ipolicy = d.ipolicy "
		"   and c.icode= a.icar_type  "
		"   and c.fclass=1 ",list[k].dbname,list[k].dbname);

	$prepare pre_cur3 from $stmt;
	$execute pre_cur3;

	}

	$select count(*) 
	into
	$check
	from car605_1 ;
	printf("*****dbname[%d]****\ncheck[%d]\n",list[k],check);
		
        sprintf_s(stmt1, sizeof stmt1,
	"select a.*,' ',b.dentry "
	"  from car605_1 a,cm_pre_receive b "
	" where a.itmp = b.ipre_rcv "
	" and b.iins_kind=%s "
	" and b.ipre_end=''",fcard);
	printf("stmt1[%s]\n",stmt1);
	printf("fcard[%s]\n",fcard);
	$prepare pre_cur1 from $stmt1;
	$DECLARE x1 CURSOR for  pre_cur1;
	
	$OPEN x1;
	int e=0;
	while(1)
       {
       	        
   	      
		 /* printf("1while************%d\n",e++);*/
		  $FETCH x1 into    $iroute1,$iofficer1,$itmp1,$ipolicy1,$icard1, 
		                    $iassured1,$nassured1,$itag1,$dbegin1,$dpolicy1, 
		                    $dentry1,$icar_type1,$ncode1,$iins_type1,$prem1, 
		                    $dacc_last,$iest1,$dori1;
		   if (SQLCODE != 0) break;   
		  /*printf("ipolicy[%s]\n",ipolicy1);   */          
	        sprintf_s(stmt2, sizeof stmt2,"select    iins_type " 
		                 "from   %s:ply_ins_type   "
		                 "where  ipolicy= ? ",list[k].dbname);
	        /*printf("stmt2[%s]\n",stmt2);*/
                $PREPARE CUR_STMT1 FROM $stmt2;
	        $DECLARE cur_iins_1 CURSOR for  CUR_STMT1;

	        $OPEN cur_iins_1 using $ipolicy1;
		  
		strcpy(iins_type1,'');
		strcpy(tmp1,'');		
		
		int p=1;
		for(;;)
		{ 
			$fetch cur_iins_1 into   $tmp1;
			if(SQLCODE == SQLNOTFOUND)
			{
			 	break;
			}
			if(p==1)
			{
				strcat(iins_type1,trim(tmp1));
			}
			else
			{
				strcat(iins_type1,",");
				strcat(iins_type1,trim(tmp1));
		        }
		        p++;
		}
		$close cur_iins_1;
		$free cur_iins_1;
	
	
	    $INSERT INTO car605
	          		      		(iroute,iofficer,itmp,ipolicy,icard, 
	          		      		 iassured,nassured,itag,dbegin,dpolicy, 
	          		      		dentry,icar_type,ncode,iins_type,prem,iest,dori,dacc_last)
				   	VALUES
	          		      		($iroute1,$iofficer1,$itmp1,$ipolicy1,$icard1, 
	          		      		$iassured1,$nassured1,$itag1,$dbegin1,$dpolicy1, 
	          		      		$dentry1,$icar_type1,$ncode1,$iins_type1,$prem1,$iest1,$dori1,$dacc_last);
        }
	$close x1;
	$free x1;


/*-----------------�]��itmp_policy�ثe���|���ũҥH���q�{�����X����

      if (fcard[0]=='2') {
	    strcpy(stmt_fcard,
		"and abs(a.dbegin - b.dply2_begin) < 30  "
		"and b.ipolicy2 = ' ' and b.mpremium2 != 0 ");
	}
	else {
	    strcpy(stmt_fcard,
		"and abs(a.dbegin - b.dply1_begin) < 30  "
		"and b.ipolicy1 = ' ' and b.mpremium1 != 0 ");
	}

	sprintf_s(stmt3, sizeof stmt3,
	"select a.*,b.iestimate,b.dentry "
	"  from car605_1 a,%s:estimate b,cm_route c,cm_route d "
	" where itmp = ' ' "
	"   and a.itag = b.itag "
	"   and a.iassured = b.iassured %s "
	"   and b.icashier = 'B2B' "
	"   and a.iroute = c.iroute "
	"   and b.iroute = d.iroute "
	"   and c.iroute_main = d.iroute_main",
	list[k].dbname,stmt_fcard);
	
	$prepare pre_cur3 from $stmt3;
	$DECLARE x3 CURSOR for  pre_cur3;
	$OPEN x3;
	  int y=0;
	while(1)
       {     
       	      
  		  
		  $FETCH x3 into    $iroute1,$iofficer1,$itmp1,$ipolicy1,$icard1, 
		                    $iassured1,$nassured1,$itag1,$dbegin1,$dpolicy1, 
		                    $dentry1,$icar_type1,$ncode1,$iins_type1,$prem1, 
		                    $dacc_last,$iest1,$dori1;
		   if (SQLCODE != 0) break;  
		 
		          
	        sprintf_s(stmt4, sizeof stmt4,"select    iins_type " 
		                 "from   %s:ply_ins_type   "
		                 "where  ipolicy= ? ",list[k].dbname);
	        
                $PREPARE CUR_STMT1 FROM $stmt4;
	        $DECLARE cur_iins CURSOR for  CUR_STMT1;
	
	        $OPEN cur_iins using $ipolicy1;
		  
		strcpy(iins_type1,'');
		strcpy(tmp1,'');		
		
		int p=1;
		for(;;)
		{ 
			$fetch cur_iins into   $tmp1;
			if(SQLCODE == SQLNOTFOUND)
			{
			 	break;
			}
			if(p==1)
			{
				strcat(iins_type1,trim(tmp1));
			}
			else
			{
				strcat(iins_type1,",");
				strcat(iins_type1,trim(tmp1));
		        }
		        p++;
		}
		$close cur_iins;
		$free cur_iins;
		
	
	    $INSERT INTO car605
	          		      		(iroute,iofficer,itmp,ipolicy,icard, 
	          		      		 iassured,nassured,itag,dbegin,dpolicy, 
	          		      		dentry,icar_type,ncode,iins_type,prem,iest,dori,dacc_last)
				   	VALUES
	          		      		($iroute1,$iofficer1,$itmp1,$ipolicy1,$icard1, 
	          		      		$iassured1,$nassured1,$itag1,$dbegin1,$dpolicy1, 
	          		      		$dentry1,$icar_type1,$ncode1,$iins_type1,$prem1,$iest1,$dori1,$dacc_last);
        }
	$close x3;
	$free x3;
	
------------------------------------------*/	

	$delete from car605_1 where 0=0;
        $select count(*) into $cnt from car605;
        
  }	

	$delete from car605_2 where 1=1;

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car605_print()
{
int	rc;
char	sfilename[81],stitle[1024],stmt[1024];
$char	nroute[41];

    $whenever sqlerror goto errexit;

    $select nroute into $nroute
       from cm_route
      where iroute = $iroute;
    if (SQLCODE==SQLNOTFOUND)
	strcpy(nroute,iroute);

    strcpy(sfilename,rtrim(nroute));
    strcat(sfilename,"�X����Ӫ�");
    strcpy(stitle,"�{���N��:CAR605\t");
    strcat(stitle,sfilename);

    if(strcmp(trim(type),"1") == 0)
    	strcat(stitle,"\t\tñ����:");
    else
    	strcat(stitle,"\t\t���O���:");

    strcat(stitle,dbgn1);
    strcat(stitle,"��");
    strcat(stitle,dend1);
    strcat(stitle,"\t\t\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");
    strcat(sfilename,"[CAR605]");

    strcat(stitle,"\t���I�N��\t�g��N��\t�X��n�O��\t�O�渹�X\t�ҥd��\t");
    strcat(stitle,"�Q�O�I�HID\t�Q�O�I�H\t���P\t�_�O���\tñ����\t");
    strcat(stitle,"�O���J��\tB2B�n�O��\tB2B�n�O���\t���A\t");
    strcat(stitle,"���إN��\t���ئW��\t�I�إN�X\tñ��O�O\t���O���\t");


    strcpy(stmt,"select iroute,iofficer,itmp,ipolicy,icard,");
    strcat(stmt,"iassured[1,3]||'****'||iassured[8,10],");
    strcat(stmt,"nassured,itag,");
    strcat(stmt,"dbegin,dpolicy,dentry,iest,dori,");
    strcat(stmt,"(select decode(fstatus,'C','���P','D','���h',' ') ");
    strcat(stmt,"from policy_new where ipolicy1 = a.ipolicy) ,");
    strcat(stmt," icar_type,ncode,iins_type,prem,dacc_last ");
    strcat(stmt,"from car605 a order by dpolicy,ipolicy");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);

    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car605_privilege()
{
$int    flevel = 0,cnt = 0;
$char   iquota[7],falldb[2];

    $whenever sqlerror goto errexit;

    $select falldb
       into $falldb
       from privilege
      where iemp = $userid
        and ipgid = 'car605';

    /* �����ٸ�Ʈw�v����,�L���ˮֳq���޲z�H */
    if (falldb[0]=='Y')
        return M_CM_OK;

    $select count(*)
       into $cnt
       from cm_route
      where iroute = $iroute
        and ileader = $userid;
    if (cnt==0) {
	strcpy(msgbuf,"�z�D�q���޲z�H�A���i���榹�q�����");
   	EWRITE(userid,10,msgbuf);
	return 10;
    }

    return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*---------------------------------------------------------end program*/
