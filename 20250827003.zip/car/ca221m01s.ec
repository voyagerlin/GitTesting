/*--------------------------------------------------*/
/*   PROGRAM : ca221m01s.ec by 061476               */
/*   DATE    : 2020/07/24                           */
/*--------------------------------------------------*/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;
#include <decimal.h>
#include "safeclib.h"

typedef struct {
    char   ikits[4];
    char   iins_type[7];
    int    minjured_cover;
    int    mdeath_cover;
    int    mdamage_cover;
} car221_t;

/*--------------------------------------------------*/
long car221(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	long rtncode;
	long car221_insert(),car221_single_query(),car221_multiple_query(),car221_update_exec();
	long car221_file();
	char option;

	cm_buf_init(command);
 	cm_buf_get("%c",&option);

 	switch(option)
 	{
	  	case 'A':
    			rtncode=car221_insert(reply);
        		break;
  		case 'Q':
    			rtncode=car221_single_query(reply);
        		break;
  		case 'M':
        		rtncode=car221_multiple_query(reply);
        		break;
        	case '1':
        		rtncode=car221_check_iins_type(reply);
        		break;
  		default :
    		if(exitsub(reply,M_CM_WRONG_OPTION) == True)
        		return M_CM_WRONG_OPTION;
           	return apiRC;
 	}
 	return(rtncode);
}

/*--------------------------------------------------*/
long car221_insert(reply)
serverReply reply;
{
   	int      rows,tmp_len,i;
   	long     MsgCode;
   	DBinfo   *list;
   	int      k,j,is_add_fail=0, api_f;
   	$char    stmt_buf[500];
   	car221_t *alist;
   	
   	$char    str_rows[3];
   	$char    DBName[3],ikits[4],iins_type[7],cover1[11],cover2[11],cover3[11],icreate[7];
   	$int     minjured_cover=0, mdeath_cover=0, mdamage_cover=0;

   	cm_buf_get("%s %s %s",DBName,ikits,str_rows);
   	rows = atoi(str_rows);

   	if(db_select(DBName) == False)
   	{
   		if( exitsub(reply,M_CM_DB_NOTOPEN) == True )
   		    return M_CM_DB_NOTOPEN;
   		return apiRC;
   	}
  	
   	alist = (car221_t *) malloc(rows * sizeof (car221_t));

   	for (k=0; k<rows; k++)
   	{
   		cm_buf_get("%s %s %s %s",iins_type,cover1,cover2,cover3);
   		
   		minjured_cover = atoi(cover1)*10000;
   		mdeath_cover = atoi(cover2)*10000;
   		mdamage_cover = atoi(cover3)*10000;
   		
   		/*deccvasc( tmp_mpure, strlen(tmp_mpure), &dec_mpure);
   		dectodbl( &dec_mpure, &mpure);
   		deccvasc( tmp_pextra_charge, strlen(tmp_pextra_charge), &dec_pextra_charge);
   		dectodbl( &dec_pextra_charge, &pextra_charge);*/
   		
   		strcpy(alist[k].ikits,ikits);
   		strcpy(alist[k].iins_type,iins_type);
   		alist[k].minjured_cover=minjured_cover;
   		alist[k].mdeath_cover=mdeath_cover;
   		alist[k].mdamage_cover=mdamage_cover;
   	}
  	
   	cm_buf_get("%s",icreate);

 	if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
  	{
   		if(exitsub(reply,M_CM_NOT_DBLIST) == True)
   		return M_CM_NOT_DBLIST;
   		return apiRC;
  	}

	$BEGIN WORK;

 	for(j=0;j<i;j++)
 	{
 		sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO %s:ca_kits_ext "
 		       "(ikits,iins_type,minjured_cover,mdeath_cover,mdamage_cover,icreate,dcreate,iupdate,dupdate) "
 		       "VALUES (?,?,?,?,?,?,current,?,current)", list[j].dbname);
 		for (k=0; k<rows; k++)
 		{
 			$PREPARE b_id FROM $stmt_buf;
	 		strcpy(iins_type,alist[k].iins_type);
	 		minjured_cover=alist[k].minjured_cover;
        		mdeath_cover=alist[k].mdeath_cover;
        		mdamage_cover=alist[k].mdamage_cover;
   		  		        		
        		$EXECUTE b_id
        		USING $ikits,$iins_type,$minjured_cover,$mdeath_cover,$mdamage_cover,$icreate,$icreate;
        		
        		if(SQLCODE != 0)
        		{
        			is_add_fail = 3;
        			break;
        		}
        	}
        	
        	if (is_add_fail == 3)
        	{
        		is_add_fail = 1;
        		break;
        	}

		cm_buf_init(ReplyBuf);
  		cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);
  		tmp_len = cm_buf_len(ReplyBuf);
  		if( j == i-1 )
    		api_f = api_OKComplete;
  		else
    		api_f = api_OK;

  		if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
  		{
  			is_add_fail = 2;
  			break;
  		}
 	} /* for loop */

	for (i = 0; i < rows; i++)
  		free( alist[i]);
	free ( (char *) alist);
	if( is_add_fail == 1 ) goto errexit;
	if( is_add_fail == 2 )
	{
   		$ROLLBACK WORK;
   		return apiRC;
  	}
   	$WHENEVER SQLERROR GOTO errexit;
   	$COMMIT WORK;
   	return api_OKComplete;

 errexit:
   	MsgCode = SQLCODE;
   	$WHENEVER SQLERROR CONTINUE;
   	$ROLLBACK WORK;
   	if( SQLCODE != 0) MsgCode = SQLCODE;
   	if(exitsub(reply,MsgCode) == True)
    	return MsgCode;
   	else
    	return apiRC;
}
/*--------------------------------------------------*/
long car221_single_query(reply)
serverReply reply;
{
	int     rows=0,tmp_len;	
	$char   DBName[3],ikits[4],iins_type[7],icreate[11],dcreate[11],iupdate[11],dupdate[11];
	$int    minjured_cover=0, mdeath_cover=0, mdamage_cover=0;
	
	cm_buf_get("%s %s %s",DBName,ikits,iins_type);
    		    	
    	$WHENEVER SQLERROR GOTO errexit;
    	
    	if (db_select(DBName) == False)
    	    return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
    	
    	cm_buf_init(ReplyBuf);
    	cm_buf_res_msg();
    	cm_buf_res_count();
    	
    	$DECLARE q_cur CURSOR for
    	  SELECT ikits,iins_type,minjured_cover,mdeath_cover,mdamage_cover,icreate,dcreate,iupdate,dupdate
    	    INTO $ikits,$iins_type,$minjured_cover,$mdeath_cover,$mdamage_cover,$icreate,$dcreate,$iupdate,$dupdate
    	    FROM ca_kits_ext
    	   WHERE ikits = $ikits;
    	
    	$OPEN q_cur;
    	
    	for(;;)
    	{
    		$FETCH q_cur;
    		if (SQLCODE != 0) break;
    		
    		cm_buf_put("%s %s",ikits,iins_type);
    		cm_buf_put("%d %d %d",minjured_cover,mdeath_cover,mdamage_cover);
    		
    		rows++;
    		
    		cm_buf_put("%s %s %s %s",icreate,dcreate,iupdate,dupdate);
	}
	
	$CLOSE q_cur;
	$FREE q_cur;
	
	if(rows > 0 || SQLCODE==0)      /* at least one row is selected */
	{
		cm_buf_put_msg(M_CM_OK);
		cm_buf_put_count(rows);
		tmp_len = cm_buf_len(ReplyBuf);
		if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
		    return apiRC;
		else
        	    return api_OKComplete;
   	}
   	else
   	{
   		if( exitsub(reply,M_CA_NRATE) == True )
   		    return M_CA_NRATE;
   		return apiRC;
   	}

errexit:
	if ( exitsub(reply,SQLCODE) == True )
    	return SQLCODE;
   	return apiRC;
}
/*--------------------------------------------------*/
long car221_multiple_query(reply)
serverReply reply;
{

   	char    tmpbuf[4000];
   	int     count=0,repbuf_len=0,tmp_len=0,replycnt=0;
   	int     i,total_count=0,flag;
   	
   	$char   DBName[3],ikits[4],iins_type[7];
        
        cm_buf_get("%s %s %s",DBName,ikits,iins_type);

   	$WHENEVER SQLERROR GOTO errexit;

   	if (db_select(DBName) == False)
   	{
    	if( exitsub(reply,M_CM_DB_NOTOPEN) == True )
        	return M_CM_DB_NOTOPEN;
      	return apiRC;
   	}
   	
   	$DECLARE m1_cur CURSOR for
   	  SELECT ikits,iins_type
   	    INTO $ikits,$iins_type
   	    FROM ca_kits_ext
   	   WHERE ikits matches $ikits 
   	     AND iins_type matches $iins_type 
   	   ORDER BY ikits,iins_type;

	$OPEN m1_cur;

   	for(;;)
   	{
   		$FETCH m1_cur;
   		if (SQLCODE != 0) break;
   		
   		cm_buf_init(tmpbuf);
   		
   		if ( count == 0 )
   		{
   			cm_buf_res_msg();             /* reserve for MsgCode and count */
   			cm_buf_res_count();
   		}
   		
   		cm_buf_put("%s %s",ikits,iins_type);
   		
   		tmp_len = cm_buf_len(tmpbuf);
   		
   		if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
   		{
   			memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
   			repbuf_len += tmp_len;
   			count++;
   		}
   		else                               /* more than 4K, send to client side */
   		{
   			cm_buf_init(ReplyBuf);
   			cm_buf_put_msg(M_CM_OK);
   			cm_buf_put_count(count);
   			if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
   			{
   				$CLOSE m1_cur;
   				$FREE m1_cur;
   				return apiRC;
   			}
   			else               /* clear ReplyBuf and count to start all over again */
   			{
   				replycnt++;
   				if (replycnt == 10)   /* more than 30K, client cannot display,error */
   				{
   					cm_buf_init(ReplyBuf);
   					cm_buf_put("%l",M_CM_OUT_SPACE);
   					tmp_len = cm_buf_len(ReplyBuf);
   					if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
   					    return apiRC;
   					return M_CM_OUT_SPACE;
   				}
   				ReplyBuf[0] = '\0';
   				count = 0;
   				cm_buf_init(ReplyBuf);
   				cm_buf_res_msg();           /* reserve for MsgCode and count */
   				cm_buf_res_count();
   				
   				cm_buf_put("%s %s",ikits,iins_type);
   				repbuf_len = cm_buf_len(ReplyBuf);
   				count++;
   			}
   		}
   	} /* for loop */

   	$CLOSE m1_cur;
   	$FREE m1_cur;

   	if (count > 0)   /* break out, at least one record is selected */
   	{
   		cm_buf_init(ReplyBuf);
   		cm_buf_put_msg(M_CM_OK);
   		cm_buf_put_count(count);
   		if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
   		    return apiRC;
   		return api_OKComplete;
   	}
   	else            /* break out, not any raw is found */
   	{
   		if( exitsub(reply,M_CA_NRATE) == True )
   		    return M_CA_NRATE;
   		return apiRC;
   	}

errexit:
   	if ( exitsub(reply,SQLCODE) == True )
    	return SQLCODE;
   	return apiRC;
}
/*--------------------------------------------------*/
long car221_check_iins_type(reply)
serverReply reply;
{
	$char DBName[DBNAME],iins_type[21];
	$int count=0;
	int tmp_len;
	long MsgCode;
	
	cm_buf_get("%s %s", DBName, iins_type);
	
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
		    return M_CM_DB_NOTOPEN;
		else
		    return apiRC;
	}
	
	$SELECT count(*)
	   INTO $count
	   FROM insurance_type
	  WHERE iins_type = $iins_type
	    AND dexpire is null;
	
	if (SQLCODE == SQLNOTFOUND)
		MsgCode = M_CA_NINS_TYPE;
	else
	        MsgCode = M_CM_OK;
	        
	cm_buf_init(ReplyBuf);
	cm_buf_put("%l %d", MsgCode,count);
	tmp_len = cm_buf_len(ReplyBuf);
	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False) 
	    return apiRC;
	else 
	    return api_OKComplete;

errexit:
   if (exitsub(reply,SQLCODE) == True)
      return SQLCODE;
   else
      return apiRC;
}