/**********************************************************************/
/*   program id   : ca906q01s.ec                                      */
/*   program name : �l�v�O�����Ӫ�                                                 */
/*   date written : 2003/09/01                                        *
/**********************************************************************/
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
#include <time.h>
#include "safeclib.h"

/*--------------------------------------------------------------------*/
DBinfo  *list;
int  count_db, i;

 int count;
 char nequipment_0[2];
 float tused=0;
 time_t tstart,tstop;
 int fetch;

$char DBName[05], iForm_Tp[03];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1];
char  outputf[N_FILE+1], userid[11];

char  msgbuf[100];
$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;

$int k;
$char dbgn2[11],dbgn1[11],dend2[11],dend1[11];
$char iclaim[21],ipolicy[21];
$int msettle,mmrecov,mrec_done;
$char frecover[2],frecov[2],recov_man[2];
$char drecov[11],dclose[11];
$char fstl[2];
$int  iclose_type;
$char iadjuster[11],lawgiver[11],iadjuster_name[11],lawgiver_name[11];
$char tmp_frecover[2];
$char nassured[40];
$char ibranch[3],nchi_full[20];
$char itag[CA_TAG_NUM];
$char daccident[21];
$long drecov_date,dclose_date;
char  str_dclose[11];


static int  max_cnt,num;
long car906_get_db();
long car906_build();
void car906_title();
void car906_print();
long car906_body();
static char *get_car_full_db();  /*   �ǤJ�O�渹��X���O�檺�k�ݸ�Ʈw */

/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{  
   $WHENEVER SQLERROR GOTO errexit;
   int rc;
   batchinit();
   strcpy(DBName, isNULLstr(argv[1]));
   strcpy(userid, isNULLstr(argv[2]));
   strcpy(dbgn2, isNULLstr(argv[3]));
   strcpy(dend2, isNULLstr(argv[4]));
   strcpy(outputf,isNULLstr(argv[5]));
   printf(" 11111111111111111111111111111111111111111111 \n");

   strcpy(dbgn1, cm_to_infdate(dbgn2));
   strcpy(dend1, cm_to_infdate(dend2));  
   
   rc = car906_get_db();
    if (rc != SUCCESS)
       return rc;

   max_cnt=0;
   rc = car906_build();
   if ( rc != FAIL){
    if ((rc=save_form_info(F_BLK0, "CA", 906, userid, iForm_Tp, max_cnt, outputf))<0)
     {
        strcpy(msgbuf,"save_form_info failed");
        return rc;
   
     }
    }
}
/*--------------------------------------------------------------------*/

long car906_build()
{
   $char  TitleFmt[N_FILE+1],BodyFmt[N_FILE+1];
   int    rc;

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 906;

   strcpy( TitleFmt,rtrim(TitleFmt));
   strcpy( BodyFmt,rtrim(BodyFmt));

 printf("TitleFmt [%s]\n",TitleFmt);
 printf("BodyFmt [%s]\n",BodyFmt);

   sprintf_s( TitleFile, N_FILE+1,"%s.ti",outputf);
   sprintf_s( BodyFile, N_FILE+1,"%s.bd",outputf);

printf(" [%s]\n",TitleFile);

   rgu_init_report(TitleFmt,TitleFile);
   car906_title();
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);
   rc = car906_body();
   if (rc != M_CM_OK)
       return rc;



printf( " next is M_CM_OK \n");           
   return M_CM_OK;

errexit:
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;  
}

   
long car906_get_db()
{
 
   if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }
    
   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   return SUCCESS;

errexit:

   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

void car906_title()
{
  rgu_put_head_string(1," ");
  rgu_put_head_string(1," "); 
  rgu_put_head();

}


long car906_body()
{
  int ins;
  $char stmt_buf[1024],stmt[1024],stmp[300];

    rgu_put_body_string(1, dbgn1,1);
    rgu_put_body_string(1, dend1,1);
    rgu_put_body_string(1, cm_get_sysd(), 1);
    rgu_put_body(1);
    max_cnt+=4;

 /*   $set explain on;   */
    time(&tstart);
 for(k=0 ; k<count_db ; k++)
 {
    sprintf_s(stmt_buf,1024,"select iclaim,ipolicy,msettle,mmrecov,     \
                             frecover,frecov,recov_man,mrecov, \
                             drecov,lawgiver \
                        from %s:recovery                         \
                       where drecov >= '%s' and drecov <= '%s'   \
                         and frecov = '3' ",
                         list[k].dbname,dbgn1,dend1);
        printf("stmt[%s]\n",stmt_buf);
        EXEC SQL PREPARE Acursor  FROM :stmt_buf;
        EXEC SQL DECLARE Acursor1 CURSOR FOR Acursor;
        EXEC SQL OPEN Acursor1;
      while (1)
      {
        EXEC SQL FETCH Acursor1 INTO :iclaim,:ipolicy,:msettle,:mmrecov,
                                     :frecover,:frecov,:recov_man,:mrec_done,
                                     :drecov,:lawgiver;
                                    
        if (SQLCODE == SQLNOTFOUND)
        { break; }
        
         sprintf_s(stmt_buf,1024,"select a.fstl,a.iclose_type, \
                                  a.iadjuster,a.frecover,a.dclose     \
                             from %s:settlement a,%s:stl_ins_type b   \
                            where a.iclaim = '%s' \
                              and a.iclaim = b.iclaim  \
                              and a.fstl = b.fstl      \
                              and a.iclose_type = b.iclose_type \
                              and b.iins_type in ('01','05','08','09','11')  \
                              and a.frecover = '0' "
                        ,list[k].dbname,list[k].dbname,iclaim);
      printf("stmt[%s]\n",stmt_buf);                            
               EXEC SQL PREPARE Acursor  FROM :stmt_buf;
               EXEC SQL DECLARE Acursor2 CURSOR FOR Acursor;
               EXEC SQL OPEN Acursor2;
          while (1)
          {
               EXEC SQL FETCH Acursor2 INTO :fstl,:iclose_type,
                                       :iadjuster,:frecover,:dclose;

               if (SQLCODE == SQLNOTFOUND)
               { break; }
            
               
               
                rstrdate( dclose , &dclose_date );
                rstrdate( drecov , &drecov_date );
                
                if( dclose_date < drecov_date)
                {  strcpy(str_dclose,dclose);   }
                
                    
                sprintf_s(stmt_buf,1024,"select nassured[1,20],itag,daccident    \
                                    from %s:adjustment_ply      \
                                   where iclaim = '%s' ",list[k].dbname,iclaim);
                $prepare pre1 from $stmt_buf;
                $execute pre1 into $nassured,$itag,$daccident;
        
                strcpy(ibranch,substring(iclaim,1,2));
                
                $select nchi_full
                   into $nchi_full
                   from v_branch
                  where ibranch = $ibranch;      
                  
                $select nname
                   into $iadjuster_name
                   from officer
                  where iofficer = $iadjuster;
                  
                $select nname
                   into $lawgiver_name
                   from officer
                  where iofficer = $lawgiver;       
               	                  	    
               	    car906_print();
               	    lawgiver[0]='\0';
               	    lawgiver_name[0]='\0';
                    break;
         

          }/*End While*/
             
             EXEC SQL CLOSE Acursor2;
             EXEC SQL FREE Acursor2;
          
        }  /* end while */

             EXEC SQL CLOSE Acursor1;
             EXEC SQL FREE Acursor1;
 } /* end three database */

 /*  $set explain off;  */
      time(&tstop);
      tused=difftime(tstop,tstart);
      printf("�������=%f��\n",tused);
   
    return M_CM_OK;

   errexit:
   printf("build:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(FAIL);
}

void car906_print()
{
 char tmp_buf[10];
 int int_frecover,int_frecov,int_recov_man;
 char str_frecover[20],str_frecov[20],str_recov_man[20];     

      rgu_put_body_string(2,trim(nchi_full),1);
      rgu_put_body_string(2,iclaim,1);
      rgu_put_body_string(2,ipolicy,1);
      rgu_put_body_string(2,nassured,1);
      rgu_put_body_string(2,itag,1);
      rgu_put_body_string(2,iadjuster_name,1);
      rgu_put_body_string(2,lawgiver_name,1);
      rgu_put_body_string(2,daccident,1);
      rgu_put_body_string(2,str_dclose,1);
      rgu_put_body_string(2,drecov,1);
      rgu_put_body_string(2,itoa(msettle),1);
      rgu_put_body_string(2,itoa(mmrecov),1);
      rgu_put_body_string(2,itoa(mrec_done),1);
     
      int_frecover=atoi(frecover);
      switch(int_frecover){
                case 0:
                      strcpy (str_frecover,"�����l�v");
                      break;
                case 1:
                      strcpy (str_frecover,"�ۦ�l�v");
                      break;
                case 2:
                      strcpy (str_frecover,"�w�ۦ�l�v");
                      break;
                case 3:
                     strcpy (str_frecover,"�k�Ȱl�v");
                     break;
                case 4:
                     strcpy (str_frecover,"�ۦ�l�v��k�Ȱl�v");
                     break;
                case 5:
                     strcpy (str_frecover,"�j���I�u��");
                     break;
                         }                         
                     
    
      rgu_put_body_string(2,str_frecover,1);
      
      int_frecov=atoi(frecov);
      switch(int_frecov){
                case 0:
                      strcpy (str_frecov,"�����l�v");
                      break;
                case 1:
                      strcpy (str_frecov,"�l�v��");
                      break;
                case 2:
                      strcpy (str_frecov,"���l�v");
                      break;
                case 3:
                     strcpy (str_frecov,"�����l�v");
                     break;
                case 4:
                     strcpy (str_frecov,"�l�v�����l�v�z��");
                     break;
                       }        
         
      rgu_put_body_string(2,str_frecov,1);
      
      
      int_recov_man=atoi(recov_man);
      switch(int_recov_man){
                case 0:
                      strcpy (str_recov_man,"�����Q�O�I�H�ξr�p�H");
                      break;
                case 1:
                      strcpy (str_recov_man,"��y�Q�O�I�H�ξr�p�H");
                      break;
                case 2:
                      strcpy (str_recov_man,"��y�O�I���q");
                      break;
                case 3:
                     strcpy (str_recov_man,"��L");
                     break;
                       }                   
      
      rgu_put_body_string(2,str_recov_man,1);
      
      rgu_put_body(2);
      count ++;
      max_cnt++;
}

char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  char sTmp_db_name[21];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
  }
  return sTmp_db_name;
}
