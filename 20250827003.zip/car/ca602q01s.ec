/**********************************************************************/
/*   program id   : ca602q01s.ec                          	      */
/*   program name : �T���I���P�B�h�B��O���Ӫ�             	      */
/*   date written : 2000/11/09                             	      */
/*   files        : endorsement      i                     	      */
/*                  edr_relation     i                     	      */
/*                  officer          i                     	      */
/*                  ca_big_office    i                     	      */
/*   temp table   : car602           io                    	      */
/**********************************************************************/
/*                             MODIFICATION LOG                        *
 *                                                                     *
 *   DATE         SE                         DESCRIPTION               *
 * --------  -------------  ----------------------------------------   *
 * 20110222  Jessie	    �W�[���P���                               *
 **********************************************************************/

#include <stdio.h>
#include <string.h>
#include <math.h>
$include sqlca;
$include decimal.h;
#include "sql.h"
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"
#include "sqlfatal.h"
#include "safeclib.h"
/*-----------------------------------------------------------------------*/
$char Ddatebgn[11], Ddateend[11], Dendorse[11], Dedr_begin[11], Dply_end[11],
      datebgn[11], dateend[11], dpolicy[11];

$long Day = 0;

char yy[04], mm[03], dd[03];

$int  ptype, pcond;
$char icar_flag[2];
$char Nassured[121], Nname[11], Nname1[17], Nname2[17], Ibig_sales[11], tmp_Nassured[31],
      Edr_return[02], Icard[21], Iofficer[11], Iquota[07],
      Ipolicy[21], Iendorse[21], Fedr_class[02], Iedr_return[02],
      Ileader[11], Ibig_branch[05], iofficer[11], iquota[07],edr_return[02],
      iquota1[07],Nbranch[41], EName[21], iedr_examiner[11], Ibig_office[10],
      iroute[21],Iroute[21],Itag[CA_TAG_NUM];
$char terminate_rsn[2], ded_business[11], fcard_class[2], fpay[2];
$char nofficer[11],nroute[41],icomm_obj[11],ncomm_obj[101],ded_business[11], tmp_nroute[21], tmp_ncomm_obj[21];
$char policy_1[POLICY_NUM_1],policy_2[POLICY_NUM_2], batch_no[21];
$char payresult[5],paystatus[100],paydate[100],notedate[100];
$char ireplace[21], npay_cond[21],Ipre_rcv[21];
$int  mdmg_prem = 0,mlia_prem = 0,mins_premium = 0, ibatch_no = 0;
$double Medrdmg_prem = 0, Medrlia_prem = 0, Sum = 0;
$char imgr[2];

char  msgbuf[100];
$char dbname[21];
$char DBName[05], iForm_Tp[03];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1];
$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;
int   max_cnt;
$char TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];
char  outputf[N_FILE+1], userid[06];

long car602_build();
long car602_body();
long car602_accumulate();
void car602_title();
void car602_print();
/*-----------------------------------------------------------------------*/
main(argc,argv)
int  argc;
char **argv;
{
   int  rc;

   batchinit();
   strcpy(DBName,     isNULLstr(argv[1]));
   strcpy(userid,     isNULLstr(argv[2]));
   ptype = atoi(isNULLstr(argv[3]));        /* ������O 5:�j���I�����O�B�۩l�h�O�����~�ȶO�ΡB�ư����Ƨ�O���*/
   strcpy(edr_return, isNULLstr(argv[4]));  /* �h�O�覡 */
   pcond = atoi(isNULLstr(argv[5]));        /* 0:�@���, 1:�O�N��, 2:����    */
   strcpy(iofficer,   isNULLstr(argv[6]));  /* �g��N�� */
   strcpy(iquota,     isNULLstr(argv[7]));  /* �~�Z��� */
   strcpy(iroute,     isNULLstr(argv[8]));  /* �q���N�� */
   strcpy(datebgn,    isNULLstr(argv[9]));  /* ���_�� */
   strcpy(dateend,    isNULLstr(argv[10]));  /* ��勤�� */
   strcpy(outputf,    isNULLstr(argv[11]));

   strcpy(Ddatebgn,cm_to_infdate(datebgn));
   strcpy(Ddateend,cm_to_infdate(dateend));
 
        rc = car602_accumulate();
        if ( rc != M_CM_OK )
             return rc;
        
        rc = car602_build();
        if ( rc != M_CM_OK )
             return rc;     
}
/***----------------------------------------------------------------***/
long  car602_build()
{
    int rc;

    $WHENEVER SQLERROR GOTO errexit;

    $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
            kTot_Col, kPgNum_Line, kWidth, iForm_Tp
       INTO $TitleFmt, $BodyFmt,  $StartRow,  $TitleRow,  $ItemRow,
            $TotColumn, $PgLine, $Width, $iForm_Tp
       FROM Form
      WHERE ksys_grp = "CA" AND kPgmID = 602;

      strcpy(TitleFmt,rtrim(TitleFmt));
      strcpy(BodyFmt, rtrim(BodyFmt));
      sprintf_s(TitleFile, sizeof TitleFile, "%s.ti", outputf);
      sprintf_s(BodyFile, sizeof BodyFile, "%s.bd", outputf);

      rgu_init_report(TitleFmt,TitleFile);
      car602_title();
      rgu_finish_report();

     rgu_init_report(BodyFmt,BodyFile);
     rc = car602_body();
     if ( rc != M_CM_OK )
          return rc;
     rgu_finish_report();
   if ((rc=save_form_info(F_BLK0, "CA", 602, userid, iForm_Tp,
	max_cnt, outputf))<0) {
        strcpy(msgbuf,"save_form_info failed");
        return rc;
   }

        return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/***----------------------------------------------------------------------***/
long car602_accumulate()
{
    int     k, count_db;
    $char   stmt[4096], type[1024], cond[1024],buf1[500], cond1[500], cond2[500], cond3[500];
    $char   insTable[61];
    DBinfo  *list;
    $char stmt_tmp[1024];
    
    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == FALSE)
    {
        EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
        return M_CM_DB_NOTOPEN;
    }

   sprintf_s(stmt_tmp, sizeof stmt_tmp,"create temp table car602  "
    "( "
      "nassured         char(120),  "
      "icard            char(20),  "
      "ipolicy          char(20),  "
      "iendorse         char(20),  "
      "dendorse         date,  "
      "dedr_begin       date,  "
      "dply_end         date,  "
      "day              date,    "
      "medrdmg_prem     integer,  "
      "medrlia_prem     integer,  "
      "sum              integer,   "
      "fedr_class       char(02),  "
      "iedr_return      char(01),  "
      "iofficer         char(10),  "
      "nofficer         char(10),  "
      "ibig_office      char(9),  "
      "ibig_sales       char(10),  "
      "iroute           char(20),  "
      "nroute           char(40),  "
      "ileader          char(10),  "
      "iquota1          char(7),  "
      "dpolicy          date,  "
      "terminate_rsn    char(1),  "
      "mdmg_prem        integer,  "
      "mlia_prem        integer,  "
      "iedr_examiner    char(10),  "
      "itag		char(%d),  "
      "icomm_obj	char(10),  "
      "ncomm_obj	char(100),  "
      "mins_premium     integer,  "
      "ibatch_no        integer  "
    ")with no log;",CA_TAG_NUM-1);
   $PREPARE stmp FROM $stmt_tmp;
   $EXECUTE stmp;
   
   printf("stmt_tmp[%s]\n",stmt_tmp);
   
       /*--- ������O ---*/
        if (ptype == 0)
           strcpy(type,"and a.fedr_class = '1' ");  /* ���P */
        else if (ptype == 1)
           strcpy(type,"and a.fedr_class != '1'  "
                        "and a.medrdmg_prem + a.medrlia_prem < 0 "); /* �h��O */
        else if (ptype == 2)
           strcpy(type,"and a.fedr_class = 'A' ");
        else if (ptype == 3)
           strcpy(type,"and a.fedr_class = 'B' ");
        else if (ptype == 4)
           strcpy(type,"and a.medrdmg_prem + a.medrlia_prem < 0 "); /* ���� */
        else if (ptype == 6)
           strcpy(type,"and a.fedr_class = '4' ");  /* �h���h�O */ 
        else                            /* �j���I�����O�B�۩l�h�O�����~�ȶO�ΡB�ư����Ƨ�O��� */
        {
           sprintf_s(type, sizeof type," and a.iendorse = h.iendorse  "
                        " and a.fcard_class = '1' "
                        " and ded_business = '1' "
                        " and terminate_rsn != '4' "
                        " and iedr_type in ('02','03') "
                        " and a.dedr_begin = b.dply_begin"); 
        }

        if (pcond == 0)
           strcpy(cond,"and imgr = '2' "); /* �@��� */
        else if (pcond == 1)
           strcpy(cond,"and imgr = '1' "); /* �O�N�� */
        else
           strcpy(cond," ");       /* ���� */
           
           
      /*---- �s�¨� ----
        if (strcmp(icar_flag,"1") == 0)
           strcpy(buf1,"and a.icar_flag = '1' "); /* �s�� 
        else if (strcmp(icar_flag,"2") == 0)
           strcpy(buf1,"and a.icar_flag = '2' "); /* �¨� 
        else */
           strcpy(buf1," ");       /* ���� */
             
     
    if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
    {
        EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
        return M_CM_NOT_DBLIST;
    }
 
    for(k=0;k<count_db;k++)
    {
printf("Ddatebgn=[%s] Ddateend=[%s] iofficer=[%s] iquota=[%s] iroute=[%s] \n",Ddatebgn,Ddateend,iofficer,iquota,iroute);
printf("ptype=[%d] pcond=[%d]",ptype,pcond);
printf("****iedr_return[%s]\n",edr_return);

        if (ptype == 5)
            sprintf_s(insTable, sizeof insTable, ", %s:edr_ins_type h ", list[k].dbname);
        else strcpy( insTable, " ");

    /*--- Ū����� ---*/
     sprintf_s(stmt, sizeof stmt,
            "insert into car602  "
             "select b.nassured, a.icard, a.ipolicy, a.iendorse, "
		    "a.dendorse,a.dedr_begin, b.dply_end, "
		    "(a.dendorse - a.dedr_begin) day, "
                    "a.medrdmg_prem, a.medrlia_prem, "
                    "(a.medrdmg_prem + a.medrlia_prem) sum, a.fedr_class, "
                    "a.iedr_return, a.iofficer,  e.nname, a.ibig_office, a.ibig_sales, "
		    "b.iroute, f.nroute, a.ileader,a.iquota[1,4]||'00' iquota1,c.dpolicy, "
                    "a.terminate_rsn,d.mdmg_prem,d.mlia_prem, a.iedr_examiner, "
		    "b.itag, a.icomm_obj, g.nname,  "
                    "(select sum(mlia_prem + mdmg_prem) from %s:ply_relation where ipolicy = a.ipolicy), c.ibatch_no  "
               "from %s:edr_relation a,%s:endorsement b,%s:ply_relation c, "
		    "%s:ply_relation_bak d, officer e, outer cm_route f, v_commission_obj g %s  "
              "where a.dendorse >= ?  "
                "and a.dendorse <= ?  "
                "and dedr_close is not null  "
                "and a.iofficer matches ?  "
                "and a.iquota[1,4] matches ?  "
                "and a.iedr_return matches ?  "
                "and a.iendorse = b.iendorse  "
                "and a.iendorse = d.iendorse  "
                "and a.ipolicy = c.ipolicy  "
                "and a.iofficer = e.iofficer  "
                "and a.ipolicy = d.ipolicy  "
                "and b.iroute = f.iroute  "
                "and b.iroute matches ?  "
                "and a.icomm_obj = g.icomm_obj %s %s %s ",
                list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,
		list[k].dbname,insTable,type,cond,buf1);
         printf("%s \n",stmt);
        $PREPARE preA FROM $stmt;
        $EXECUTE preA USING $Ddatebgn,$Ddateend,$iofficer,$iquota,$edr_return,$iroute;
    }         
          return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*----------------------------------------------------------------------------*/
void car602_title()
{

   rgu_put_head_string(1, cm_get_sysd());

   cm_split_ymd_100(datebgn, yy, mm, dd);
   rgu_put_head_string(1, yy);
   rgu_put_head_string(1, mm);
   rgu_put_head_string(1, dd);
   cm_split_ymd_100(dateend, yy, mm, dd);
   rgu_put_head_string(1, yy);
   rgu_put_head_string(1, mm);
   rgu_put_head_string(1, dd);

   rgu_put_head();
   max_cnt= max_cnt+1;
}
/*----------------------------------------------------------------------------*/
long car602_body()
{
     int rc;
     char v_sMsg[512],tmpName[17];
     $whenever sqlerror goto errexit;

   rgu_put_body_string(1, cm_get_sysd());  /* get_currdt */

   cm_split_ymd_100(datebgn, yy, mm, dd);
   rgu_put_body_string(1, yy);
   rgu_put_body_string(1, mm);
   rgu_put_body_string(1, dd);
   cm_split_ymd_100(dateend, yy, mm, dd);
   rgu_put_body_string(1, yy);
   rgu_put_body_string(1, mm);
   rgu_put_body_string(1, dd);
   rgu_put_body(1);
   max_cnt ++;
   rgu_put_body(2);
   max_cnt ++; 

    $DECLARE curA CURSOR FOR
      SELECT nassured,icard,ipolicy,iendorse,dendorse,dedr_begin,
	     dply_end,day,
             medrdmg_prem,medrlia_prem,sum,fedr_class,iedr_return,iofficer, nofficer,
	     ibig_office, ibig_sales,iroute,nroute,ileader,iquota1,dpolicy,
	     terminate_rsn,mdmg_prem,mlia_prem,iedr_examiner,itag,icomm_obj, ncomm_obj, mins_premium,ibatch_no
        INTO $Nassured,$Icard,$Ipolicy,$Iendorse,$Dendorse,$Dedr_begin,
             $Dply_end,$Day,$Medrdmg_prem,$Medrlia_prem,$Sum,$Fedr_class,
             $Iedr_return,$Iofficer,$nofficer,$Ibig_office,$Ibig_sales,$Iroute,$nroute,
	     $Ileader,$iquota1,$dpolicy,
             $terminate_rsn,$mdmg_prem,$mlia_prem,$iedr_examiner,$Itag,$icomm_obj,$ncomm_obj,$mins_premium,$ibatch_no
        FROM car602
     ORDER BY iofficer;

    $OPEN curA;
    while(1)
    {
    $FETCH curA;
    if(SQLCODE == SQLNOTFOUND) break;

      strncpy(policy_1,Ipolicy,CAR_POLICY_LEN);
      policy_1[CAR_POLICY_LEN]=0;
      strcpy(policy_2,&Ipolicy[CAR_POLICY_LEN]);

      memset (batch_no, 0, sizeof (batch_no));
   
      if (ibatch_no == 0) strcpy(batch_no, " ");
      else sprintf_s(batch_no, sizeof batch_no,"%d",ibatch_no);

      rc = ao_chk_charge(DBName, '1', policy_1, policy_2, batch_no,
                       payresult, paystatus, paydate, notedate);
  
      if( ptype == 5 && strcmp( trim(payresult), "NR") != 0)
          continue;

      $select nname
         into $Nname
         from officer 
        where iofficer = $Ileader;
      if(SQLCODE == SQLNOTFOUND) strcpy(Nname,"");
        
      /* �g�P�ӦW�� */
      $select ibig_branch     
         into $Ibig_branch
         from ca_big_office 
        where fclass = '1'
          and ibig_comp = $Iofficer;
      if(SQLCODE == SQLNOTFOUND) strcpy(Ibig_branch,"");
      
      /* ���Ӥ@���O */
      $select nvl(imgr,' ')
         into $imgr
         from officer 
        where iofficer = $Iofficer;
      if(SQLCODE == SQLNOTFOUND) strcpy(imgr," ");
        
      /****Ū��������~��/�q����~������****/
      /* get_route_data input ������~��/�q���N��,���ӳq����~���N��
         �H�θg��N��,�^�Ǩ���/�q����~������W�� (2:����/�q����~��, 1:����/�q����~��) */
      /* imgr=1���ɭԬO���ӥ�,�Ǩ�����~��,��L���h�ǤJ�q���N�� */                    
         strcpy(tmpName,"");

      if (imgr[0] == '1')
      {
          rc = get_route_data(2, Iofficer, Ibig_office, Ibig_sales, tmpName, v_sMsg);
          if (rc != M_CM_OK) strcpy(tmpName," "); 
          cc_split_chinese(tmpName,Nname1,16);

          rc = get_route_data(1, Iofficer, Ibig_office, Ibig_sales, tmpName, v_sMsg);
          if (rc != M_CM_OK) strcpy(tmpName," "); 
          cc_split_chinese(tmpName,Nname2,16);
      }
      else
      {
          rc = get_route_data(2, Iofficer, Iroute, Ibig_sales, tmpName, v_sMsg);
          if (rc != M_CM_OK) strcpy(tmpName," "); 
          cc_split_chinese(tmpName,Nname1,16);

          rc = get_route_data(1, Iofficer, Iroute, Ibig_sales, tmpName, v_sMsg);
          if (rc != M_CM_OK) strcpy(tmpName," "); 
          cc_split_chinese(tmpName,Nname2,16);
      }


      $select nbranch
         into $Nbranch
         from sa_branch_type
        where ibranch = $iquota1; 
      if(SQLCODE == SQLNOTFOUND) strcpy(Nbranch,""); 
              
      $select nname 
         into $EName
         from officer
        where iofficer = $iedr_examiner;
      if(SQLCODE == SQLNOTFOUND) strcpy(EName,"");           
printf("ipolicy1=[%s]\tipolicy2=[%s]\n",policy_1,policy_2);

      /*�����渹*/
      $select ipre_rcv 
         into $Ipre_rcv
         from cm_pre_receive
        where ipolicy1 = $policy_1
          and ipolicy2 = $policy_2
          and iendorse = ' '
          and ipre_end = ' ';

      if(SQLCODE == SQLNOTFOUND) strcpy(Ipre_rcv," ");   

      $select first 1 ireplace, case when fpay_cond = '2' then '�}��'
                                     when fpay_cond = '3' then '�״�'
                                     when fpay_cond = '5' then '��ú'
                                     when fpay_cond = '7' then '�H�Υd'
                                     when fpay_cond = '9' then '����' end
         into $ireplace, $npay_cond
         from ao_prem_return
        where ipolicy1 = $policy_1
          and ipolicy2 = $policy_2
          and iendorse = $Iendorse;
      if(SQLCODE == SQLNOTFOUND) {strcpy(ireplace,"");strcpy(npay_cond,"");}           
 
       car602_print();
     } 
      $close curA;
      $free  curA;
          
        return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
void car602_print()
{
  char buf1[20], buf2[20], buf3[27], str[20];
  char str_sales[11];

   rgu_put_body_string(3, Ibig_branch , 1);
   rgu_put_body_string(3, Nname1      , 1);
   if (strlen(trim(Ibig_sales))==10) {
	strcpy(str_sales,substring(Ibig_sales,1,3));
	strcat(str_sales,"****");
	strcat(str_sales,substring(Ibig_sales,8,10));
   }
   else
	strcpy(str_sales,Ibig_sales);
   rgu_put_body_string(3, str_sales   , 1);
  
   rgu_put_body_string(3, Nname2      , 1);
   rgu_put_body_string(3, iquota1     , 1);
   rgu_put_body_string(3, Nbranch     , 1);   
   rgu_put_body_string(3, Nname       , 1);
   rgu_put_body_string(3, Iofficer    , 1);
   rgu_put_body_string(3, nofficer    , 1);
   cc_split_chinese(Nassured,tmp_Nassured,30);
   rgu_put_body_string(3, tmp_Nassured    , 1);
   rgu_put_body_string(3, Icard       , 1);
   rgu_put_body_string(3, Ipolicy     , 1);
   rgu_put_body_string(3, Iendorse    , 1);
   rgu_put_body_string(3, Ipre_rcv    , 1);
   rgu_put_body_string(3, dpolicy     , 1);   
   rgu_put_body_string(3, Dendorse    , 1);
   rgu_put_body_string(3, Dedr_begin  , 1);
   rgu_put_body_string(3, Dply_end    , 1);
   rfmtlong(Day,"###&",str);
   rgu_put_body_string(3, str         , 1);
   rfmtdouble(Medrdmg_prem,"---------&",str);
   rgu_put_body_string(3, str        , 1);
   rfmtdouble(Medrlia_prem,"---------&",str);
   rgu_put_body_string(3, str        , 1);
   rfmtdouble(Sum,"---------&",str);
   rgu_put_body_string(3, str        , 1);
   if (strcmp(Fedr_class,"1") == 0)
   {
       strcpy(buf1,"���P");
   }
   else if (strcmp(Fedr_class,"A") == 0)
   {
       strcpy(buf1,"�g��");
   }
   else if (strcmp(Fedr_class,"B") == 0)
   {
       strcpy(buf1,"����");
   }
   else if (strcmp(Fedr_class,"4") == 0)
   {
       strcpy(buf1,"�h���h�O");
   }
   else
   {
       strcpy(buf1,"�h�O");
   }

   rgu_put_body_string(3, rtrim(buf1), 1);
   if (strcmp(Iedr_return,"1") == 0)
       strcpy(buf2,"�Ȥ�˿�");
   else if (strcmp(Iedr_return,"2") == 0)
       strcpy(buf2,"�z�L�O�N");
   else 
       strcpy(buf2," ");
   rgu_put_body_string(3, rtrim(buf2), 1);
   
   
   if (strcmp(terminate_rsn,"1") == 0)
   {
       strcpy(buf3,"���Ѱh�O");
   }
   else if (strcmp(terminate_rsn,"2") == 0)
   {
       strcpy(buf3,"�����h��");
   }
   else if (strcmp(terminate_rsn,"3") == 0)
   {
       strcpy(buf3,"��������(�t�L��᭫�Ƨ�O)");
   }
   else if (strcmp(terminate_rsn,"4") == 0)
   {
       strcpy(buf3,"���Ƨ�O");
   }
   else if (strcmp(terminate_rsn,"5") == 0)
   {
       strcpy(buf3,"�z�ߪȯ�");
   }
   else if (strcmp(terminate_rsn,"6") == 0)
   {
       strcpy(buf3,"�A�ȺA�פ���");
   }
   else if (strcmp(terminate_rsn,"7") == 0)
   {
       strcpy(buf3,"�����I�ذh�O");
   }    
   else if (strcmp(terminate_rsn,"8") == 0)
   {
       strcpy(buf3,"�������p");
   }    
   else if (strcmp(terminate_rsn,"9") == 0)
   {
       strcpy(buf3,"�������o");
   }    
   else if (strcmp(terminate_rsn,"A") == 0)
   {
       strcpy(buf3,"���̬��w��I�O�I�O");
   }
   else if (strcmp(terminate_rsn,"B") == 0)
   {
       strcpy(buf3,"ú�P");
   }
   else if (strcmp(terminate_rsn,"C") == 0)
   {
       strcpy(buf3,"�Q�P");
   }
   else if (strcmp(terminate_rsn,"D") == 0)
   {
       strcpy(buf3,"���P");
   }
   else if (strcmp(terminate_rsn,"E") == 0)
   {
       strcpy(buf3,"���l�״_");
   }
   else if (strcmp(terminate_rsn,"F") == 0)
   {
       strcpy(buf3,"��P���L");
   }   
   else
   {
       strcpy(buf3," ");
   }   
   rgu_put_body_string(3, rtrim(buf3), 1);

   rfmtlong(mdmg_prem,"---------&",str); 
   rgu_put_body_string(3, str        , 1);
   rfmtlong(mlia_prem,"---------&",str);
   rgu_put_body_string(3, str        , 1);
   rgu_put_body_string(3, EName, 1);
   rgu_put_body_string(3, Itag,  1);
   
   rgu_put_body_string(3, Iroute      , 1);
   cc_split_chinese(nroute,tmp_nroute,20);
   rgu_put_body_string(3, tmp_nroute  , 1);
   rgu_put_body_string(3, icomm_obj   , 1);
   cc_split_chinese(ncomm_obj,tmp_ncomm_obj,20);
   rgu_put_body_string(3, tmp_ncomm_obj   , 1);
   rfmtlong(mins_premium,"---------&",str);
   rgu_put_body_string(3, str        , 1);
   rgu_put_body_string(3, paystatus  , 1);

   rgu_put_body_string(3, ireplace  , 1);
   rgu_put_body_string(3, npay_cond , 1);

   rgu_put_body(3);
   max_cnt++;
}
/*---------------------------------------------------------end program*/
