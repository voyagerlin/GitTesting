/************************************************/
/*                                              */
/*   PROGRAM : ca108m01s.ec                     */
/*   ����100�~�M��: Checked  (2008/08/08)       */
/*                                              */
/************************************************/
     
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;
#include "safeclib.h"


long car108(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car108_insert(),car108_single_query(),car108_multiple_query(),car108_update_exec();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'A':
           rtncode=car108_insert(reply);
           break;
  case 'Q':
           rtncode=car108_single_query(reply);
           break;
  case 'M':
           rtncode=car108_multiple_query(reply);
           break;
  case 'D':
  case 'U':
           rtncode=car108_update_exec(reply,command,com_len);
printf("step 8[%d]\n",rtncode);           
           break;
  default :
           if(exitsub(reply,M_CM_WRONG_OPTION) == True)
            return M_CM_WRONG_OPTION;
           return apiRC;
 }

 return(rtncode);
}

long car108_insert(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table insurance_type */
 $char instype[7],insname[29],sameins[7	],mainins[7],range1[25];
 $char range2[41],insabbr[13],tmpinstype[7],tmpinsname[7];
 $char deductf[2],insgrp[2],insprint[2],calway[2],frule[2],typerule[3],tradevan_iinstype[3];
 $char iri_ins[7],nins_type1[21],iins_ply[7], iins_type_ks[7], dexpire[11], pa_list[2], iupdate[11];
 $char cover_print[121],deduct_print[21];
 $long coverno,series;
 $char nins_eng[121],fkind[2],freco[2],fcolumn[2],fpa[2];
 $char ninjure_cover[51],ndeath_cover[51],ndamage_cover[51];
 $char fclaim_cover[2],fdeprec[2];
 $char ndeduct[101],ndeduct_note[201];
 $char cmp_provision[6],com_provision[6],iins_provision1[6],iins_provision2[6],iins_provision3[6];
 $int  iCount = 0;
 /* end of insurance_type */

  char   taipei_db[40];
  $char  dbname_tp[40], stmt[512];

 /* standard defined data */
 int tmp_len;
   DBinfo *list;
   int i, j, is_add_fail=0, api_f;
   $char stmt_buf[2048];
 /* end of standard data */

 /* self defined data */
 long MsgCode;
 /* end of self data */

 cm_buf_get("%s",DBName);
 cm_buf_get("%s %s %s %l %s %c %s %s %s %s %s %c %c %l %c %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s"
        ,instype,insname,nins_eng,&coverno,cover_print,&deductf[0],deduct_print,sameins,mainins
        ,range1,range2,&insgrp[0],&insprint[0],&series,&calway[0],insabbr
        ,frule,typerule,tradevan_iinstype,iri_ins,nins_type1,iins_ply, iins_type_ks, dexpire, pa_list, 
        fkind,freco,fcolumn,fpa,fdeprec,ninjure_cover,ndeath_cover,ndamage_cover,fclaim_cover,
        ndeduct,ndeduct_note,cmp_provision,com_provision,iins_provision1,iins_provision2,iins_provision3,iupdate);
        deductf[1]='\0';
        insgrp[1]='\0';
        insprint[1]='\0';
        calway[1]='\0';

 if (db_select(DBName) == False) 
  { 
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }
 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
  {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
  }

  MsgCode = getHeadBranch(taipei_db);
  if ( MsgCode < 0)
  {
   printf( "getHeadBranch Fail:read Config file error!!\n");
   if(exitsub(reply,M_CM_READ_CONFIG_ERR) == True)
    return M_CM_READ_CONFIG_ERR;
   else
    return apiRC;
  }

  /* get TAIPEI's full DB name */
  strcpy(dbname_tp,get_full_dbname(taipei_db));

  printf("instype[%s], iins_ply[%s], iins_type_ks[%s]\n", instype, iins_ply, iins_type_ks);
  if( strcmp( instype, iins_ply) == 0)
  {
      sprintf_s(stmt, sizeof stmt, "SELECT COUNT(*) "
                     "  FROM %s:v_group_instype "
                     " WHERE icode= '%s' ", dbname_tp, instype);
      printf("stmt[%s]\n", stmt);
      $PREPARE prepA FROM $stmt;
      $EXECUTE prepA INTO $iCount;
      $FREE prepA;
      if( iCount ==0 )
      {
       if(exitsub(reply,M_CA_NO_BIS) == True)
        return M_CA_NO_BIS;
       else
        return apiRC;
      }
  }

 $BEGIN WORK;
 for(j=0;j<i;j++)
 {
  sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO %s:insurance_type "
        " (iins_type,nins_type,qcoverage,cover_print,fdeduct,deduct_print,isame_ins, imain_ins, "
        " edomain1,edomain2,fins_grp,fprint,qserial,fcal_way,nins_abbr, "
        " frule,iins_type_rule,iins_type_tradevan,iri_ins,nins_type1,iins_ply, iins_type_ks, dexpire,pa_list, "
        " nins_eng,fkind,freco,fcolumn,fpa,fdeprec,ninjure_cover,ndeath_cover,ndamage_cover, "
        " fclaim_cover,ndeduct,ndeduct_note,cmp_provision,com_provision,iins_provision1,iins_provision2,iins_provision3,iupdate) "
        " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)" ,list[j].dbname);

  $PREPARE a_id FROM $stmt_buf;
  if(SQLCODE != 0)
   {
    is_add_fail = 1;
    break;
   }
  $EXECUTE a_id USING $instype,$insname,$coverno,$cover_print,$deductf,$deduct_print,$sameins,$mainins,
          $range1,$range2,$insgrp,$insprint,$series,$calway,$insabbr,
          $frule,$typerule,$tradevan_iinstype,$iri_ins,$nins_type1,$iins_ply, $iins_type_ks, $dexpire, $pa_list, 
          $nins_eng,$fkind,$freco,$fcolumn,$fpa,$fdeprec,$ninjure_cover,$ndeath_cover,$ndamage_cover,
          $fclaim_cover,$ndeduct,$ndeduct_note,$cmp_provision,$com_provision,$iins_provision1,$iins_provision2,$iins_provision3,$iupdate;
  if(SQLCODE != 0)
   {
    is_add_fail = 1;
    break;
   }
  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);
  tmp_len = cm_buf_len(ReplyBuf);
  if( j == i-1 )
     api_f = api_OKComplete;
  else
     api_f = api_OK;

  if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
    {
     is_add_fail = 2;
     break;
    }  
 } /* for loop */

 if( is_add_fail == 1 ) goto errexit;

 if( is_add_fail == 2 ) 
  {
   $ROLLBACK WORK;
   return apiRC;
  }


 $WHENEVER SQLERROR GOTO errexit;
 $COMMIT WORK;
 return api_OKComplete;

 errexit:
  $WHENEVER SQLERROR CONTINUE;    
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True) 
   return MsgCode;
  else  
   return apiRC;
}

long car108_single_query(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table insurance_type */
 $char instype[7],insname[29],sameins[7],mainins[7],range1[25];
 $char range2[41],insabbr[13],tmpinstype[7],tmpinsname[7];
 $char deductf[2],insgrp[2],insprint[2],calway[2],frule[2],typerule[3],tradevan_iinstype[3];
 $char iri_ins[7],nins_type1[21],iins_ply[7],iins_type_ks[7],dexpire[11], pa_list[2], iupdate[11], dupdate[31];
 $long coverno = 0,series = 0;
 $char cover_print[121],deduct_print[21];
 $char nins_eng[121],fkind[2],freco[2],fcolumn[2],fpa[2];
 $char ninjure_cover[51],ndeath_cover[51],ndamage_cover[51];
 $char fclaim_cover[2],fdeprec[2];
 $char ndeduct[101],ndeduct_note[201];
 $char cmp_provision[6],com_provision[6],iins_provision1[6],iins_provision2[6],iins_provision3[6];
 /* end of insurance_type */

 /* standard defined data */
 int tmp_len;
 /* end of standard data */

 /* self defined data */
 
 /* end of self data */
 cm_buf_get("%s",DBName);
 cm_buf_get("%s",instype); 

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False) 
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

 $SELECT nins_type,qcoverage,cover_print,fdeduct,deduct_print,isame_ins,imain_ins,
         edomain1,edomain2,fins_grp,fprint,qserial,fcal_way,nins_abbr,
         frule,iins_type_rule,iins_type_tradevan,iri_ins,nins_type1,
         iins_ply, iins_type_ks, dexpire, pa_list, nins_eng, fkind, freco, fcolumn, fpa, fdeprec,
         ninjure_cover, ndeath_cover, ndamage_cover, fclaim_cover, ndeduct, ndeduct_note, cmp_provision, com_provision, iins_provision1, iins_provision2, iins_provision3,
         iupdate, dupdate
  INTO $insname,$coverno,$cover_print,$deductf,$deduct_print,$sameins,$mainins,
       $range1,$range2,$insgrp,$insprint,$series,$calway,$insabbr,
       $frule,$typerule,$tradevan_iinstype,$iri_ins,$nins_type1,
       $iins_ply, $iins_type_ks, $dexpire, $pa_list, $nins_eng, $fkind, $freco, $fcolumn, $fpa, $fdeprec,
       $ninjure_cover, $ndeath_cover, $ndamage_cover, $fclaim_cover, $ndeduct, $ndeduct_note, $cmp_provision, $com_provision, $iins_provision1, $iins_provision2, $iins_provision3,
       $iupdate, $dupdate
  FROM insurance_type
  WHERE iins_type=$instype; 

 if(SQLCODE==SQLNOTFOUND) 
  {
   if(exitsub(reply,M_CA_NINS_TYPE) == True) 
    return M_CA_NINS_TYPE; 
   else  
    return apiRC;
  }
printf("nins_type1[%s];iins_ply[%s];iins_type_ks[%s]\n",nins_type1,iins_ply,iins_type_ks);
printf("domain2[%s];tradevan_iinstype[%s]\n",range2,tradevan_iinstype);

 cm_buf_init(ReplyBuf); 
 cm_buf_put("%l",M_CM_OK);
 cm_buf_put("%s %s %s %l %s %c %s %s %s %s %s %c %c %l %c %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s"
        ,instype,insname,nins_eng,coverno,cover_print,deductf[0],deduct_print,sameins,mainins
        ,range1,range2,insgrp[0],insprint[0],series,calway[0],insabbr,
        frule,typerule,tradevan_iinstype,iri_ins,nins_type1,iins_ply,iins_type_ks,dexpire, 
        pa_list,fkind,freco,fcolumn,fpa,fdeprec,ninjure_cover,ndeath_cover,ndamage_cover,
        fclaim_cover,ndeduct,ndeduct_note,cmp_provision,com_provision,iins_provision1,iins_provision2,iins_provision3,iupdate,dupdate);
 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
  return apiRC;
 else
  return api_OKComplete;

 errexit:
  if(exitsub(reply,SQLCODE) == True) 
   return SQLCODE;
  else  
   return apiRC;
}

long car108_multiple_query(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table insurance_type */
 $char instype[7],insname[29];
 $char tmpinstype[7],tmpinsname[7];
 $long coverno,series;
 /* end of insurance_type */

 /* standard defined data */
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0; 
 /* end of standard data */
 
 cm_buf_get("%s",DBName);
 cm_buf_get("%s",instype);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False) 
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

 $DECLARE q_cur CURSOR FOR
    SELECT iins_type,nins_abbr
    INTO $tmpinstype,$tmpinsname
    FROM insurance_type
    WHERE iins_type matches $instype
    ORDER BY iins_type; 

 $OPEN q_cur;

 for(;;)
  {
    $FETCH q_cur;
    if (SQLCODE != 0) break;

    cm_buf_init(tmpbuf); 
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();          
     }
    cm_buf_put("%s %s",tmpinstype,tmpinsname);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */ 
     { 
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
        $CLOSE q_cur;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE; 
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();    
    cm_buf_put("%s %s",tmpinstype,tmpinsname);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     } 
  } /* for loop */

 $CLOSE q_cur;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
   if(exitsub(reply,M_CA_NINS_TYPE) == True) 
    return M_CA_NINS_TYPE;
   else  
    return apiRC;
  } 

 errexit:
  if(exitsub(reply,SQLCODE) == True) 
   return SQLCODE;
  else  
   return apiRC;
}

/***************************************************************************/
long car108_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table insurance_type */
 $char instype[7],old_instype[7],insname[29],sameins[7],mainins[7],range1[25];
 $char range2[41],insabbr[13],tmpinstype[7],tmpinsname[7];
 $char deductf[2],insgrp[2],insprint[2],calway[2],frule[2],typerule[3],tradevan_iinstype[3];
 $char iri_ins[7],nins_type1[21],iins_ply[7], iins_type_ks[7], dexpire[11], pa_list[2], iupdate[11], dupdate[31];
 $long coverno = 0,series = 0;
 $char cover_print[121],deduct_print[21];
 $char nins_eng[121],fkind[2],freco[2],fcolumn[2],fpa[2];
 $char ninjure_cover[51],ndeath_cover[51],ndamage_cover[51];
 $char fclaim_cover[2],fdeprec[2];
 $char ndeduct[101],ndeduct_note[201];
 $char cmp_provision[6],com_provision[6],iins_provision1[6],iins_provision2[6],iins_provision3[6];
 /* end of insurance_type */

 /* standard defined data */
 char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
 int tmp_len,raw_len;
 $int iCount = 0;
 long dummy=0;
   DBinfo *list;
   int i, j, is_del_fail=0, is_upd_fail=0;
   $char stmt_buf[2048];
 /* end of standard data */

  char   taipei_db[40];
  $char  dbname_tp[40], stmt[512];

 /* self defined data */
 long MsgCode;
  /* end of self data */

 comm = (char *) command;
 cm_buf_init(command);
 cm_buf_get("%c %s",&option,DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }
 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
  {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
  }
 /* compare old record and current record, if the record has not been changed  
    since last request, update or delete the record, otherwise return errmsg
    to client side */

 /* get old record info from command buffer */ 

 memcpy(&raw_len,&comm[com_len],sizeof(int));   
 pos = &comm[com_len+sizeof(int)];
 raw_ptr = malloc(raw_len);
 if (raw_ptr != (char*)0)  
  memcpy(raw_ptr,pos,raw_len);
 else
  {
   if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */ 
    return M_CM_NOT_MALLOC;
   else  
    return apiRC;
  }
    
 cm_buf_init(raw_ptr);          /* get index key from old record */
 cm_buf_get("%l %s",&dummy,old_instype);

   $BEGIN WORK;                
 $SELECT nins_type,qcoverage,cover_print,fdeduct,deduct_print,isame_ins,imain_ins,
         edomain1,edomain2,fins_grp,fprint,qserial,fcal_way,nins_abbr,
         frule,iins_type_rule,iins_type_tradevan,iri_ins,nins_type1,
         iins_ply, iins_type_ks, dexpire, pa_list, nins_eng, fkind, freco, fcolumn, fpa, fdeprec,
         ninjure_cover, ndeath_cover, ndamage_cover, fclaim_cover, ndeduct, ndeduct_note, cmp_provision, com_provision, iins_provision1, iins_provision2, iins_provision3,
         iupdate, dupdate
  INTO   $insname,$coverno,$cover_print,$deductf,$deduct_print,$sameins,$mainins,
         $range1,$range2,$insgrp,$insprint,$series,$calway,$insabbr,
         $frule,$typerule,$tradevan_iinstype,$iri_ins,$nins_type1,
         $iins_ply , $iins_type_ks, $dexpire, $pa_list, $nins_eng, $fkind, $freco, $fcolumn, $fpa, $fdeprec,
         $ninjure_cover, $ndeath_cover, $ndamage_cover, $fclaim_cover, $ndeduct, $ndeduct_note, $cmp_provision, $com_provision, $iins_provision1, $iins_provision2, $iins_provision3,
         $iupdate, $dupdate
  FROM insurance_type
  WHERE iins_type=$old_instype;

  /* if key value has been changed then SQLNOTFOUND,else put current value
     into cur_buf for comparison */ 

 if (SQLCODE == SQLNOTFOUND)
  {
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(exitsub(reply,M_CM_NOT_FOUND) == True) 
    return M_CM_NOT_FOUND;
   else  
    return apiRC;
  }
 $WHENEVER SQLERROR GOTO errexit;

 cm_buf_init(cur_buf);
 cm_buf_put("%l %s %s %s %l %s %c %s %s %s %s %s %c %c %l %c %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
            dummy,old_instype,insname,nins_eng,coverno,cover_print,deductf[0],deduct_print,sameins,mainins,
            range1,range2,insgrp[0],insprint[0],series,calway[0],insabbr,
            frule,typerule,tradevan_iinstype,iri_ins,nins_type1,iins_ply,iins_type_ks,
            dexpire,pa_list,fkind,freco,fcolumn,fpa,fdeprec,ninjure_cover,ndeath_cover,ndamage_cover,
            fclaim_cover,ndeduct,ndeduct_note,cmp_provision,com_provision,iins_provision1,iins_provision2,iins_provision3,iupdate,dupdate);

 if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
  {
   printf(" cmp not equal \n");
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(exitsub(reply,M_CM_NOT_EQUAL) == True) 
    return M_CM_NOT_EQUAL;
   else  
    return apiRC;
  }
   $WHENEVER SQLERROR GOTO errexit;
   
   free(raw_ptr);
  
 /* equal, then exec DB operation */

 if ( option == 'D' )
  {
   for(j=0;j<i;j++)
   {
    sprintf_s(stmt_buf, sizeof stmt_buf,"DELETE FROM %s:insurance_type  WHERE iins_type = ?"
                ,list[j].dbname); 
    $PREPARE d_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      break;
     }
    $EXECUTE d_id USING $old_instype;
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      break;
     }
   }/* for loop */

   if( is_del_fail ) goto errexit;
   

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }  

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else if (option == 'U')
  {
  	
/* 
$char nins_eng[121],fkind[2],freco[2],fcolumn[2],fpa[2];
 $char ninjure_cover[51],ndeath_cover[51],ndamage_cover[51];
 $char fclaim_cover[2];
*/  	
   cm_buf_init(command);
   cm_buf_get("%c %s %s %s %s %l %s %c %s %s %s %s %s %c %c %l %c %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
   &option,DBName,instype,insname,nins_eng,&coverno,cover_print,&deductf[0],deduct_print,sameins,mainins
        ,range1,range2,&insgrp[0],&insprint[0],&series,&calway[0],insabbr,
        frule,typerule,tradevan_iinstype,iri_ins,nins_type1,iins_ply,iins_type_ks,
        dexpire,pa_list,fkind,freco,fcolumn,fpa,fdeprec,ninjure_cover,
        ndeath_cover,ndamage_cover,fclaim_cover,ndeduct,ndeduct_note,cmp_provision,com_provision,iins_provision1,iins_provision2,iins_provision3,iupdate);
        deductf[1]='\0';
        insgrp[1]='\0';
        insprint[1]='\0';
        calway[1]=='\0';

  MsgCode = getHeadBranch(taipei_db);
  if ( MsgCode < 0)
  {
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   printf( "getHeadBranch Fail:read Config file error!!\n");
   if(exitsub(reply,M_CM_READ_CONFIG_ERR) == True)
    return M_CM_READ_CONFIG_ERR;
   else
    return apiRC;
  }

  /* get TAIPEI's full DB name */
  strcpy(dbname_tp,get_full_dbname(taipei_db));

  if( strcmp( instype, iins_ply) == 0)
  {
      sprintf_s(stmt, sizeof stmt, "SELECT COUNT(*) "
                     "  FROM %s:v_group_instype "
                     " WHERE icode= '%s' ", dbname_tp, instype);
      printf("stmt[%s]\n", stmt);
      $PREPARE prepA FROM $stmt;
      $EXECUTE prepA INTO $iCount;
      $FREE prepA;
      if( iCount ==0 )
      {
       $WHENEVER SQLERROR CONTINUE;
       $ROLLBACK WORK;
       if(exitsub(reply,M_CA_NO_BIS) == True)
        return M_CA_NO_BIS;
       else
        return apiRC;
      }
  }

   $WHENEVER SQLERROR CONTINUE;
   for(j=0;j<i;j++)
   {
    sprintf_s(stmt_buf, sizeof stmt_buf,"UPDATE %s:insurance_type "
        " SET (iins_type,nins_type,qcoverage,cover_print,fdeduct,deduct_print,isame_ins, imain_ins, "
        " edomain1,edomain2,fins_grp,fprint,qserial,fcal_way,nins_abbr, "
        " iins_type_rule,iins_type_tradevan,frule,iri_ins,nins_type1,iins_ply,iins_type_ks, "
        " dexpire,pa_list,nins_eng,fkind,freco,fcolumn,fpa,fdeprec,ninjure_cover,ndeath_cover, "
        " ndamage_cover,fclaim_cover,ndeduct,ndeduct_note,cmp_provision,com_provision,iins_provision1,iins_provision2,iins_provision3,iupdate,dupdate) "
        " = (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, current year to second) "
        " WHERE iins_type = ?",list[j].dbname);
printf("stmt[%s]\n",stmt_buf);        

    $PREPARE u_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      break;
     }    
     
    $EXECUTE u_id USING $instype,$insname,$coverno,$cover_print,$deductf,$deduct_print,$sameins,$mainins,
        $range1,$range2,$insgrp,$insprint,$series,$calway,$insabbr,
        $typerule,$tradevan_iinstype,$frule,$iri_ins,$nins_type1,$iins_ply,$iins_type_ks,
        $dexpire,$pa_list,$nins_eng,$fkind,$freco,$fcolumn,$fpa,$fdeprec,$ninjure_cover,$ndeath_cover,
        $ndamage_cover,$fclaim_cover,$ndeduct,$ndeduct_note,$cmp_provision,$com_provision,$iins_provision1,$iins_provision2,$iins_provision3,$iupdate,$old_instype;

    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      break;
     }

    if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
     {
      sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO %s:insurance_type "
        " (iins_type,nins_type,qcoverage,cover_print,fdeduct,deduct_print,isame_ins, imain_ins,"
        " edomain1,edomain2,fins_grp,fprint,qserial,fcal_way,nins_abbr,frule, "
        " iins_type_rule,tradevan_iinstype,iri_ins,nins_type1,iins_ply,iins_type_ks, "
        " dexpire,pa_list,nins_eng,fkind,freco,fcolumn,fpa,fdeprec,ninjure_cover, "
        " ndeath_cover,ndamage_cover,fclaim_cover,ndeduct,ndeduct_note,cmp_provision,com_provision,iins_provision1,iins_provision2,iins_provision3,iupdate) "
        " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",list[j].dbname);

      $PREPARE ua_id FROM $stmt_buf;
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        break;
       }       

     $EXECUTE ua_id USING $instype,$insname,$coverno,$cover_print,$deductf,$deduct_print,$sameins,$mainins,
        $range1,$range2,$insgrp,$insprint,$series,$calway,$insabbr,$frule,
        $typerule,$tradevan_iinstype,$iri_ins,$nins_type1,$iins_ply,$iins_type_ks,
        $dexpire,$pa_list,$nins_eng,$fkind,$freco,$fcolumn,$fpa,$fdeprec,$ninjure_cover,$ndeath_cover,
        $ndamage_cover,$fclaim_cover,$ndeduct,$ndeduct_note,$cmp_provision,$com_provision,$iins_provision1,$iins_provision2,$iins_provision3,$iupdate;
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        break;
       }
     }
   } /* for loop */

   if( is_upd_fail ) goto errexit;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);

   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }  

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;

   return api_OKComplete;
   
  }
 else
  {
   if(exitsub(reply,M_CM_WRONG_OPTION) == True) 
    return M_CM_WRONG_OPTION;
   else  
    return apiRC;
  } 

 errexit:
  $WHENEVER SQLERROR CONTINUE;
printf("error[%l]\n",MsgCode);  
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True) 
   return MsgCode;
  else  
   return apiRC;
}
