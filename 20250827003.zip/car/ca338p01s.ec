/************************************************/
/*						*/
/*   PROGRAM : ca338q01s.ec                     */
/*   �j���I���Ƨ�O�H�oEmail�@�~		*/
/*   DATE    : 2009/08/21			*/
/*						*/
/************************************************/
#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "print.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"

#include "carmsgs.h"
#include "commsgs.h"
#include "ca_field.h"
#include "safeclib.h"
#include <locator.h>

#define  LOAD_FAIL               -1

char  outputf[ N_FILE+1];
char  userid[11], aphome[40];

long car338_email();

$char stmt[1024], DBName[5], sFullName[20];
char  sMsg[10240];
FILE  *sfp, *fp, *fp_note;
int rc, rc1;
DBinfo  *list;
int i, count_db;
$char  semail[51],chinese_name[15], pre_ileader[11];
$char fname[101], filename[101], ftitle[1024], noteDataFile[51],nattachment[100];
$int  mail_count;
$char  mbuf[9000];
$loc_t  ctxt;
$char   mmsg[2048];
char option[2];

char *get_car_full_db();
/***************************************************************************/
main(argc, argv)
int argc;
char **argv;
{


   batchinit(); 
   strcpy(DBName,    isNULLstr(argv[1]));
   strcpy(userid,    isNULLstr(argv[2]));
   strcpy(option,    isNULLstr(argv[3]));

   if( option[0] == 'E' || option[0] == 'F')   /* �H�o�j���I���Ƨ�Oemail, �j���I���Ƨ�O��Ƭd�� */ 
       strcpy(outputf,   isNULLstr(argv[4]));
   else if( option[0] == 'P')   /* ���ͱj���I���Ƨ�O�q������ */ 
   {
       strcpy(noteDataFile, isNULLstr(argv[4]));
       strcpy(outputf,   isNULLstr(argv[5]));
   }

   $WHENEVER SQLERROR GOTO errexit;

   sfp =  (FILE *)STARTLOG();

   if (db_select(DBName) == False)
   {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN"); 
       return M_CM_DB_NOTOPEN;
   }
            
   rc = getApHome(aphome);
   if (rc<0) {
       EWRITE( userid, -1, "In sigalrmcatcher func==>read config file error!!");
       return FAIL;
   }

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   rc = car338_get_data();   /* �B�zclient��data,���temp table */

   if (rc != M_CM_OK)
   {
       EWRITE(userid, rc, sMsg);
       return rc;
   }

   if( option[0] == 'E')   /* �H�o�j���I���Ƨ�Oemail */
   {
       rc=car338_email();
   }
   else if( option[0] == 'P')   /* ���ͱj���I���Ƨ�O�q������ */ 
   {
       rc=car338_note();
   }
   else if( option[0] == 'F')   /* �j���I���Ƨ�O��Ƭd�� */ 
   {
       rc=car338_file();
   }
   else
   {
       EWRITE(userid, -1, "ERROR OPTION");
       return FAIL;
   }

   if (rc != M_CM_OK)
   {
       EWRITE(userid, rc, sMsg);
       return rc;
   }

   WRITELOG( sfp, sMsg);
   ENDLOG(sfp);
   return M_CM_OK;

errexit:
    printf("------car338: SQLCODE[%d]\n",SQLCODE);
    EWRITE(userid, SQLCODE,sqlca.sqlerrm);
    exit(1);

}
/***************************************************************************/
/* �B�zclient��data,���temp table */
long car338_get_data()
{
char  local_dbname[41], FullGetName[101], stmt[1024], cmd_stmt[1024];
char  LogName[51], FullLogName[101], DBName1[5];
char  policy_1[POLICY_NUM_1],policy_2[POLICY_NUM_2], sdelimiter[2];
$char ipolicy[21], ibatch_no[3], icard[21], icard_oth[21];
$char payresult[5],paystatus[100],paydate[100],notedate[100], swhere[101];
int   fStat;
char  sIupcompShort[2], policyDB[21], policyDBname[41];
$char stmt_tmp[1024]; 

    strcpy(local_dbname, get_full_dbname(DBName)); 
    /* t338a�O�Nclient�ݤ�r��load�i�� */
     /* icard      char(20),            /* �O�I�Ҹ� *
        nassured   char(120),           /* �Q�O�I�H�m�W *
        iassured   char(20),            /* �����Ҹ�/�νs *
        itag       char(%d),            /* ���P���X 
        dply_begin char(10),            /* �O�I�_�l��]YYYYMMDD�^*
        dply_end   char(10),            /* �O�I������]YYYYMMDD�^*
        dpolicy    char(10),            /* ñ���]YYYYMMDD�^*
        dtrans     char(10),            /* �ǰe��]YYYYMMDD�^*
        doffer     char(20)             /* �O�o���Ѥ��(X��X��) */
    sprintf_s(stmt_tmp, sizeof stmt_tmp,"CREATE TEMP TABLE t338a "
   "(  "
       "icard      char(20),  "
       "nassured   char(120),  "
       "iassured   char(20),  "
       "itag       char(%d),  "
       "dply_begin char(10),  "
       "dply_end   char(10),  "
       "dpolicy    char(10),  "
       "dtrans     char(10),  "
       "doffer     char(20)  "
   ") with no log;",CA_TAG_NUM-1);
     $PREPARE stmp FROM $stmt_tmp;
     $EXECUTE stmp;

    /* t338b��ƨӷ��Ot338a�ھڥd���q��Ʈw�d�X�Ӫ� */
    /* 1060914002_C1 �s�W���G�n�O�H�B�n�O�H�a�}�B�~�Z���e�|�X */
    $CREATE TEMP TABLE t338b
    ( 
        icard      char(20),            /* �O�I�Ҹ� */
        ipolicy    char(20),            /* �����q�O�渹 */
        ileader    char(10),            /* �޲z�H */
        nleader    char(20),            /* �޲z�H�W�� */
        iofficer   char(10),            /* �g��N���A*/
        nofficer   char(20),            /* �g��H�W�� */
        nquota     char(20),            /* ���²�� */
        payresult  char(30),            /* ���O���A */
        paystatus  char(20),            /* ���O���A�y�z */
        dpay       char(20),            /* �O�榬�O�� */
        ibatch_no  int,                 /* �j�O��妸���X, �����O���A�� */
        note       int,                 /* �O�_�H�o�q����, 0:���H�o,1:�H�o,�w�]���H�o */ 
        mdamage_cover int,              /* �O�B */
        napplicant varchar(120),        /* �n�O�H */
        apayment varchar(90),           /* �n�O�H�a�} */
        iquota char(4)                  /* �~�Z���e�|�X */
    ) with no log;

    sprintf_s(FullGetName, sizeof FullGetName, "%s/dat/car/car338.txt", aphome);

    strcpy( sdelimiter,  "\t");
    if ((fStat=load_command1( FullGetName, outputf, "t338a", sdelimiter)) != SUCCESS)
    {
        sprintf_s(sMsg, sizeof sMsg, "Loading File[%s] Fail fStat[%d]\n", FullGetName, fStat);
        return LOAD_FAIL;
    }

    if( option[0] == 'E' || option[0] == 'P')   /* �H�o�j���I���Ƨ�Oemail, ���ͱj���I���Ƨ�O�q������ */ 
        strcpy( swhere, "   AND f.mdamage_cover <> 0 AND b.dply_end > today ");
    else /* �j���I���Ƨ�O��Ƭd�ߥ\�� */ 
        strcpy( swhere, " ");

    for (i=0;i<count_db;i++)
    {
        sprintf_s(stmt, sizeof stmt, "INSERT INTO t338b "
                       "SELECT a.icard, b.ipolicy, (SELECT ileader FROM officer WHERE iofficer = b.iofficer), "
                       "       (SELECT nname FROM officer WHERE iofficer = "
                       "       (SELECT ileader FROM officer WHERE iofficer = b.iofficer)), "
                       "       b.iofficer, d.nname, e.nbranch, ' ', ' ', ' ', b.ibatch_no, 1, f.mdamage_cover, "
                       "       g.napplicant, g.apayment, b.iquota[1,4] "
                       "  FROM t338a a, %s:ply_relation b, officer d, sa_branch_type e, %s:ply_ins_type f, %s:policy g "
                       " WHERE a.icard[1,2] = '17' "
                       "   AND a.icard[3,20] = b.icard "
                       "   AND b.iofficer = d.iofficer "
                       "   AND b.iquota = e.ibranch "
                       "   AND b.ipolicy = f.ipolicy "
                       "   AND b.ipolicy = g.ipolicy "
                       "   AND b.icard in (select icard[3,20] from t338a where icard[1,2] = '17') "
                       "   %s ", list[i].dbname, list[i].dbname, list[i].dbname, swhere);
        printf("stmt[%s]\n", stmt);
        $PREPARE prep1 FROM $stmt;
        $EXECUTE prep1;

        /* ���o���O���A */
        $DECLARE curs2 CURSOR FOR
          SELECT ipolicy, case when ibatch_no::char = '0' then ' ' else ibatch_no::char end case, icard
            FROM t338b
           WHERE paystatus = '';

        $OPEN curs2;
        for(;;)
        {
    	    $FETCH curs2 INTO $ipolicy, $ibatch_no, $icard;
    	    if( SQLCODE == SQLNOTFOUND ) break;
 
            strncpy(policy_1, ipolicy,CAR_POLICY_LEN);
            policy_1[CAR_POLICY_LEN]=0 ;
            strcpy(policy_2, &ipolicy[CAR_POLICY_LEN]);

            strncpy(DBName1, ipolicy, 2); DBName1[2]='\0';

            rc = ao_chk_charge( DBName1, 'A', policy_1, policy_2, ibatch_no,
                            payresult, paystatus, paydate, notedate);
            if( rc != TRUE)
            {
                strcpy( payresult, "");
                strcpy( paystatus, "");
            }
            printf("icard[%s],payresult[%s],paystatus[%s]\n", icard, payresult,paystatus);
            if( option[0] == 'P')   /* ���ͱj���I���Ƨ�O�q������,�w���O�w�q:���O���A��R�}�Y,NA���O������ */
            {
                if( payresult[0] == 'R' || strncmp( payresult, "NA", 2) == 0)
                {
                    sIupcompShort[0] = ipolicy[2]; /* �O�渹�ĤT�X */
                    sIupcompShort[1] = '\0';
                    strcpy( policyDB, get_upcomp(sIupcompShort, USE_SHORT_BRANCH_ID, USE_BRANCH_ID));
                    strcpy( policyDBname, get_full_dbname(policyDB));

                    sprintf_s(stmt, sizeof stmt, "SELECT dpay " 
                                   "  FROM %s:ao_plyedr_prem "
                                   " WHERE ipolicy1 = '%s'" 
                                   "   AND ipolicy2 = '%s'"
                                   "   AND iendorse = ''", policyDBname, policy_1, policy_2);
                    printf("stmt[%s]\n", stmt);
                    $PREPARE prep7 FROM $stmt;
                    $EXECUTE prep7 INTO $paydate;
    	            if( SQLCODE == SQLNOTFOUND )
                        strcpy( paydate, "");
                }
                else
                    strcpy( paydate, "");
            }

            printf("ipolicy[%s], payresult[%s], paystatus[%s], paydate[%s]\n", 
                    ipolicy, payresult, paystatus, paydate);
            $UPDATE t338b
                SET payresult = $payresult,
                    paystatus = $paystatus,
                    dpay = $paydate
              WHERE ipolicy = $ipolicy;
        }
    }
    
    return M_CM_OK;

errexit:
    sprintf_s(sMsg, sizeof sMsg, "car338_get_data:sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    printf("%s", sMsg);
    return SQLCODE;
}
/***************************************************************************/
long car338_email()
{
$char icard[21], nassured[121], iassured[21], itag[CA_TAG_NUM], dply_begin[11];
$char dply_end[11], dpolicy[11], dtrans[11], doffer[21];
$char ipolicy[21], ileader[11], nleader[21], iofficer[11];
$char nofficer[21], nquota[21], payresult[31], paystatus[21], dpay[11];
$char sileader[11], sdoffer[21], snleader[21];
$long iCount = 0, iWriteData;

/* �Ӹ�B�n (nassured,iassured) add by larry 103.02.19 (1030211003_C1) */
$char sFassured[2],sNassured[121], sIassured[21];
$char Full_DBName[20], stmt1[512];

int   tot_count;
    
$char nsend[20],isend[10],email_notify[100];

    /* ���Y */
    strcpy(ftitle, "�O�I�Ҹ�,�Q�O�I�H�m�W,�����Ҹ�/�νs,���P���X,"
                   "�O�I�_�l��,�O�I������,ñ���,�ǰe��,�O�o���Ѥ��,"
                   "�����q�O�渹,�޲z�H,�޲z�H�W��,�g��N��,�g��H�W��,���²��,���O���A,���O���A�y�z,�O�榬�O��\n");
 
    /* email��� */
    strcpy(mmsg,
        "<span style='font-family:�з���'>�U��D�ޡB�P�� �z�n�G<\P>\n"
        "&emsp;&emsp;����ֱj��I���Ƨ�O�����ơA�O�ٳQ�O�I�H�v�q�A�O�o���߰��歫�Ƨ�O�ˮ־���A<br>\n"
        "�é�C�g�T�J�`���~�ɭ��Ƨ�O��T��A���ѦW��ѦP����U�T�{�B�z�C<br>\n"
        "���ɬ����g���Ƨ�O�����ӡA�����O���Υ����O�����Ьҷ|�C�X�A���קK���@�~�ɮİ��D�A<br>\n"
        "�q�лP�O��T�{�O�_����z�O�I�����h�O�κM�P�B�z�C<\p>\n"
        "<span style='font-weight:bold;text-decoration: underline'>�̾ڱj�O�k��22���G</span><br>\n"
        "&emsp;&emsp;<span style='color:blue'>�y�n�O�H���ƭq�ߥ��O�I�����̡A�n�O�H�ΫO�I�����ͮĦb�ᤧ�O�I�H�o�M�P<span style='color:red'>�ͮĦb�ᤧ<br>\n"
        "�O�I�����C</span>�T����q�ƬG�o�ͫ�A��P�C�e���M�P�v����ϡA���󭫽ƭq�ߨƹ�o�ͤ��ɰ_�A<br>\n"
        "�ܥͮĦb�����O�I<span style='color:red'>�������������e</span>�����C�O�I�����g�M�P�̡A�O�I�H���N�O�I�O����<span style='color:red'>�������O<br>\n"
        "�I�O��</span>���l�B�A���٭n�O�H�C�z</span><\p>\n"
        "<table border='1'><tr><th style='background-color:lightgray'>�B�z�u������</th><th style='background-color:lightgray'>�O�����A</th><th style='background-color:lightgray'>�B�z�覡</th></tr>\n"
		"<tr><th rowspan='2'>���Ƨ�O<br><span style='color:red'>�P�@���q</th><td>��������</td><td>�о��t�P�Ȥ�T�{��z�䤤�@���h�O�C</td></tr>\n"
		"<tr><td>��������</td><td>�O���ͮĤ�b��޲z�H�A�H�o�q����γq���O���z�h�O�C</td></tr>\n"
		"<tr><th rowspan='2'>���Ƨ�O<br><span style='color:red'>�P�~����</th><td>��������</td><td>�о��t�P�Ȥ�T�{��z�䤤�@���h�O�C</td></tr>\n"
		"<tr><td>��������</td><td>�����q�O���ͮĦb��A�гq���Ȥ��e��O�I��������e�A���Ѱh�O<br>����U�Ȥ��z�h�O�ӽСC</td></tr>\n"
		"<tr><td colspan='3'><span style='color:red;font-weight:bold'>�`�N�G</span><br>\n"
		"&emsp;1.&emsp;���를�B�z�����Ƨ�O��ơA�j��멳�e�N�|�w��e�楼������O��妸�H�o���Ƨ�O��<br>\n"
        "&emsp;&emsp;&ensp;�H���C<br>&emsp;2.&emsp;�j���I�t���ƺ޲z�ˮ֤覡�p�U�G<br>&emsp;&emsp;��&emsp;�u�O�I�����������ƪ̡v�A�Y�����Pñ��󤧳Q�O�I�HID�εP�Ӹ��X���ۦP�A<br>\n"
		"&emsp;&emsp;&emsp;&emsp;<span style='color:red;text-decoration: underline'>�O�I�_�W�����@�P</span>�̡A�H<span style='color:blue;text-decoration: underline'>�ǰe��������</span>�~�ǤJ�p��C<br>\n"
		"&emsp;&emsp;��&emsp;�u�O�I�����������ƪ̡v�A�Y�����Pñ��󤧳Q�O�I�HID�εP�Ӹ��X���ۦP�A<br>\n"
		"&emsp;&emsp;&emsp;&emsp;<span style='color:red;text-decoration: underline'>�O�I�_�W��������</span>�̡A��<span style='color:blue;text-decoration: underline'>�O�I�ͮĤ鬰���</span>�~�ǤJ�p��C<br>\n"
		"&emsp;3.&emsp;��L�D�W�z�������ӮשΦh�����Ʊ��p�A�i�ӹq�Q�ק@�~�覡�C</td></tr></table></span>\n");

    strcpy(mbuf,rtrim(mmsg));
    ctxt.loc_loctype = LOCMEMORY;
    ctxt.loc_buffer = mbuf;
    ctxt.loc_bufsize = 9000;
    ctxt.loc_size =  strlen(mbuf) + 1;

    sprintf_s(stmt, sizeof stmt, "SELECT case when a.icard[1,2] = '17' then a.icard else \"'\"||a.icard end case,"
                   "       a.nassured, a.iassured, a.itag, a.dply_begin, "
                   "       a.dply_end, a.dpolicy, a.dtrans, a.doffer,"
                   "       b.ipolicy, b.ileader, b.nleader, b.iofficer, b.nofficer, "
                   "       b.nquota, b.payresult, b.paystatus, b.dpay"
                   "  FROM t338a a, outer t338b b"
                   " WHERE a.icard = b.icard"
                   "   AND a.itag = ? "
                   "   AND a.iassured = ?"
                   "   AND a.icard <> ?");

    $PREPARE prep3 FROM $stmt;
    $DECLARE curs3 CURSOR FOR prep3;

    sprintf_s(stmt, sizeof stmt, "SELECT a.icard, a.nassured, a.iassured, a.itag, a.dply_begin, "
                   "       a.dply_end, a.dpolicy, a.dtrans, a.doffer, "
                   "       b.ipolicy, b.ileader, b.nleader, b.iofficer, b.nofficer, "
                   "       b.nquota, b.payresult, b.paystatus, b.dpay"
                   "  FROM t338a a, t338b b"
                   " WHERE a.icard = b.icard"
                   "   AND ileader = ?");

    $PREPARE prep4 FROM $stmt;
    $DECLARE curs4 CURSOR FOR prep4;

    $DECLARE curs5 CURSOR FOR
      SELECT distinct a.ileader, b.doffer, a.nleader
        INTO $sileader, $sdoffer, $snleader
        FROM t338b a, t338a b
       WHERE a.icard = b.icard;
 
    $OPEN curs5;
    $FETCH curs5;
    printf("ileader[%s]\n",sileader);
    strcpy(pre_ileader,sileader);
    mail_count=0;
    tot_count=0;
    while(1)
    {
    	if( SQLCODE == SQLNOTFOUND ) break;
        
        
        iWriteData = 0;
        if (strcmp(sileader,pre_ileader)!=0 && mail_count!= 0) {
            rc = car338_write_email();
            if (rc!=M_CM_OK) {
                sprintf_s(sMsg, sizeof sMsg, "error on car338_write_email\n");
                return rc;
            }
            mail_count=0;
        }
        strcpy(pre_ileader,sileader);


        memset(fname,0x00,sizeof(fname));
        memset(filename,0x00,sizeof(filename));
        strcpy( sdoffer, trim(sdoffer));
        strcpy( snleader, trim(snleader));
        sprintf_s(fname, sizeof fname,"%s_�j���I���Ƨ�O����_%s.csv", sdoffer, snleader);
        sprintf_s(nattachment, sizeof nattachment,"%s",fname);
        sprintf_s(filename, sizeof filename,"%s/rptftp/car_comp_dup/%s", aphome, fname);
        printf("filename[%s]\n",filename);
        if (( fp=fopen( filename,"w"))==NULL)
        {
            sprintf_s(sMsg, sizeof sMsg, "Cannot open Ouput file: %s\n", filename);
            printf("%s", sMsg);
            return M_CM_OPEN_FILE_FAIL;
        }

        fprintf(fp,ftitle);

        $OPEN curs4 using $sileader;

        while(1) 
        {
            $FETCH curs4 INTO $icard, $nassured, $iassured, $itag, $dply_begin,
                              $dply_end, $dpolicy, $dtrans, $doffer,
                              $ipolicy, $ileader, $nleader, $iofficer,
                              $nofficer, $nquota, $payresult, $paystatus, $dpay;

            if (SQLCODE==SQLNOTFOUND) break;

            if( strncmp( icard, "17", 2) == 0)  /* �����q */
            {
                $SELECT COUNT(*)
                   INTO $iCount
                   FROM t338a
                  WHERE iassured = $iassured
                    AND itag = $itag
                    AND icard != $icard
                    AND icard[1,2] = '17';
                if( iCount != 0)  /* �P�����q���� */
                {
                    $SELECT COUNT(*)
                       INTO $iCount
                       FROM t338a
                      WHERE iassured = $iassured
                        AND itag = $itag
                        AND icard != $icard
                        AND icard[1,2] != '17';
                    if( iCount == 0)  /* �u�P�����q����, �p�Gt338b�䤣����ܵL�O�B,����Email�q�� */
                    {
                        $SELECT COUNT(*)
                           INTO $iCount
                           FROM t338a a, t338b b
                          WHERE a.iassured = $iassured
                            AND a.itag = $itag
                            AND a.icard != $icard
                            AND a.icard[1,2] = '17'
                            AND a.icard = b.icard;
                        if (iCount == 0) continue;
                    }
                }
            }

            printf("ipolicy[%s]\n",ipolicy);
            /* �Ӹ�B�n (nassured,iassured) add by larry 103.02.19 (1030211003_C1) */
            strcpy(ipolicy,trim(ipolicy));
            if (strlen(ipolicy) != 0){
                strcpy(Full_DBName,get_car_full_db(ipolicy));
		            sprintf_s(stmt1, sizeof stmt1,"SELECT fassured  "
                               " FROM %s:policy  "
                               "WHERE ipolicy = '%s'",Full_DBName,ipolicy);
                $PREPARE policy_cur FROM $stmt1;             
                $EXECUTE policy_cur INTO $sFassured;
            }
            
            strcpy(sFassured,trim(sFassured));
            printf("-----fassured[%s]\n-----",sFassured);
            if ((strncmp(sFassured,"1",1)==0)||(strncmp(sFassured,"3",1)==0)||(strncmp(sFassured,"5",1)==0))
            {
               strcpy(sNassured,substring(nassured,1,2));
	             strcat(sNassured,"�ݢ�");
	             strcpy(sIassured,substring(iassured,1,3));
	             strcat(sIassured,"****");
	             strcat(sIassured,substring(iassured,8,13));	        
            }
            else
            {
        	     strcpy(sNassured,nassured);
        	     strcpy(sIassured,iassured);
            }

            iWriteData++;
            fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",
                       icard, sNassured, sIassured, itag, dply_begin,
                       dply_end, dpolicy, dtrans, doffer,
                       ipolicy, ileader, nleader, iofficer,
                       nofficer, nquota, payresult, paystatus, dpay);

            $OPEN curs3 using $itag, $iassured, $icard;
            while(1) 
            {
                $FETCH curs3 INTO $icard, $nassured, $iassured, $itag, $dply_begin,
                                  $dply_end, $dpolicy, $dtrans, $doffer,
                                  $ipolicy, $ileader, $nleader, $iofficer,
                                  $nofficer, $nquota, $payresult, $paystatus, $dpay;
                if (SQLCODE==SQLNOTFOUND) break;

                if( strcmp( sileader, ileader) == 0) continue;
                
                /* �Ӹ�B�n (nassured,iassured) add by larry 103.02.19 (1030211003_C1) */
                strcpy(ipolicy,trim(ipolicy));
                if (strlen(ipolicy) != 0){		
                    strcpy(Full_DBName,get_car_full_db(ipolicy));
		                sprintf_s(stmt1, sizeof stmt1,"SELECT fassured  "
                                   " FROM %s:policy  "
                                   "WHERE ipolicy = '%s'",Full_DBName,ipolicy);
                    $PREPARE policy1_cur FROM $stmt1;             
                    $EXECUTE policy1_cur INTO $sFassured;
                }
            
                strcpy(sFassured,trim(sFassured));
                printf("-----fassured[%s]\n-----",sFassured);
                if ((strncmp(sFassured,"1",1)==0)||(strncmp(sFassured,"3",1)==0)||(strncmp(sFassured,"5",1)==0))
                {
                   strcpy(sNassured,substring(nassured,1,2));
	                 strcat(sNassured,"�ݢ�");
	                 strcpy(sIassured,substring(iassured,1,3));
	                 strcat(sIassured,"****");
	                 strcat(sIassured,substring(iassured,8,13));	        
                }
                else
                {
        	         strcpy(sNassured,nassured);
        	         strcpy(sIassured,iassured);
                }
                iWriteData++;
                fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",
                           icard, sNassured, sIassured, itag, dply_begin,
                           dply_end, dpolicy, dtrans, doffer,
                           ipolicy, ileader, nleader, iofficer,
                           nofficer, nquota, payresult, paystatus, dpay);
            }
        }
        fclose(fp);
        $FETCH curs5;
        if( iWriteData != 0) 
        {
            mail_count++;
            tot_count++;
        }
    }

    if (mail_count!=0) {
        rc = car338_write_email();
        if (rc!=M_CM_OK) {
            printf("error on car338_write_email\n");
            return rc;
        }
    }


    /*�W�[���|�~�Ȧ�F�쵡�f(1110812007_SC1_���CAR338�j���I���Ƨ�O�q���@�~�l��H�e�覡)*/
    
    sprintf_s(mbuf, sizeof mbuf,"car338�j���I���Ƨ�O�q���@�~�w�󤵤�H�o<\p> �� �H�e�޲z�Hemail��ơG%d\n", tot_count);
    ctxt.loc_loctype = LOCMEMORY;
    ctxt.loc_buffer = mbuf;
    ctxt.loc_bufsize = 9000;
    ctxt.loc_size =  strlen(mbuf) + 1;
    
    
    $declare cur_notify cursor for
      select DISTINCT detail2 INTO $isend 
        from car_code
       where kind = 'RC' and detail = '0002'
       order by detail2;
    $open  cur_notify;  
     
    while (1)
    {
    	strcpy(nsend,"");
    	strcpy(isend,"");
    	strcpy(email_notify,"");
    	
    	
        $fetch cur_notify;
     	
     	if (SQLCODE==SQLNOTFOUND) break;
     	
     	$SELECT nname[1,10] INTO $nsend
     	   FROM officer
     	  WHERE iofficer = $isend;
     	     
     	$SELECT trim(email)||'@tmnewa.com.tw' INTO $email_notify
           FROM asempl
          WHERE empl_no = $isend;


     	if (strlen(trim(isend))>0)
     	{
            $INSERT INTO batchemail
                       (project_id, mail_date, receiver_email,nsubject,
                        receiver_name, cc, content, key, mail_count,nattachment)
             VALUES
                       ("CAR338", today+1, $email_notify,"car338�j���I���Ƨ�O�q���@�~�w�󤵤�H�o" ,
                        $nsend," ", $ctxt, " ", 0, " ");
        }
    }
    $CLOSE cur_notify;
    $FREE  cur_notify;



    strcpy( sMsg, "�j���I���Ƨ�Oemail�@�~���槹��");

    return M_CM_OK;

errexit:
    sprintf_s(sMsg, sizeof sMsg, "car338_email:sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    printf("%s", sMsg);
    return SQLCODE;
}

/***************************************************************************/
long car338_write_email()
{
$long iCount;
    $SELECT email,chinese_name
       INTO $semail,$chinese_name
       FROM personal:asempl
      WHERE empl_no = $pre_ileader;

    strcpy(semail,trim(semail));
    strcat(semail,"@tmnewa.com.tw");
    printf("semail[%s]\n",semail);

    $SELECT count(*)
       INTO $iCount
       FROM batchemail
      WHERE project_id = 'CAR338'
        AND mail_date = today+1
        AND receiver_email = $semail
        AND receiver_name = $chinese_name
        AND key = $fname
        AND mail_count = $mail_count;

    if( iCount != 0)
    {
        $DELETE FROM batchemail
          WHERE project_id = 'CAR338'
            AND mail_date = today+1
            AND receiver_email = $semail
            AND receiver_name = $chinese_name
            AND key = $fname
            AND mail_count = $mail_count;
    }

    /*strcat(nattachment,";���Ƨ�O�B�z�覡.doc");*/
    
    $INSERT INTO batchemail
                (project_id, mail_date, receiver_email,nsubject,
                receiver_name, cc, content, key, mail_count,nattachment)
     VALUES
                ("CAR338", today+1, $semail, "�j���I���Ƨ�O�q��" ,
                 $chinese_name," ", $ctxt, $fname, $mail_count, $nattachment);

    return M_CM_OK;

errexit:
    sprintf_s(sMsg, sizeof sMsg, "car338_write_email:sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    printf("%s", sMsg);
    return SQLCODE;
}
/***************************************************************************/
long car338_note()
{
$char icard[21], iassured[21], itag[CA_TAG_NUM], dply_begin[11], dply_end[11], dtrans[11], dpay[11];
$long iCount, key, iCountDiffPeriod;
char  sIupcompShort[2], policyDB[21], policyDBname[41];
$char apayment_zip[11], apayment[101], fsex[2], nbranch[41], itel[21], nassured[121];
$char ipolicy[21], nrin_abbre[11], nleader[11];
$char sdply_begin[11], sdply_end[11], sdtrans[11], sitag[CA_TAG_NUM], icard3[21];

    $DECLARE curs6 CURSOR FOR
      SELECT a.icard, a.iassured, a.itag, a.dply_begin, a.dply_end, a.dtrans, b.dpay,
             a.dply_begin[5,6] || '/'||a.dply_begin[7,8]||'/'||a.dply_begin[1,4],
             a.dply_end[5,6] || '/'||a.dply_end[7,8]||'/'||a.dply_end[1,4],
             a.dtrans[5,6] || '/'||a.dtrans[7,8]||'/'||a.dtrans[1,4]
        FROM t338a a, t338b b
       WHERE a.icard = b.icard
         AND a.icard[1,2] = '17'
       ORDER BY a.iassured, a.itag;
    $OPEN curs6;
    for(;;)
    {
        $FETCH curs6 INTO $icard, $iassured, $itag, $dply_begin, $dply_end, $dtrans, $dpay, 
                          $sdply_begin, $sdply_end, $sdtrans;
        if (SQLCODE==SQLNOTFOUND) break;
        puts("============================================================");
        printf("icard[%s], iassured[%s], itag[%s], dply_begin[%s], \n"
               "dply_end[%s], dtrans[%s], dpay[%s], sdply_begin[%s], \n"
               "sdply_end[%s], sdtrans[%s]\n\n", icard, iassured, itag, 
                dply_begin, dply_end, dtrans, dpay, sdply_begin, sdply_end, sdtrans);
        $SELECT COUNT(*)
           INTO $iCount
           FROM t338a
          WHERE iassured = $iassured
            AND itag = $itag
            AND icard[1,2] != '17';
        if( iCount != 0)
        {
            puts("�P�P�~����");
            /* �H�Q�O�I�Hid�M�����A��M�P�ۤv�O�I�_�l��ۦP�B�O�I�����]�ۦP���L����� */
            $SELECT COUNT(*)
               INTO $iCount
               FROM t338a
              WHERE iassured = $iassured
                AND itag = $itag
                AND dply_begin = $dply_begin
                AND dply_end = $dply_end
                AND icard[1,2] != '17'
                AND icard != $icard
                AND date( dtrans[5,6] || '/'||dtrans[7,8]||'/'||dtrans[1,4]) > $sdtrans;
     
            /* �Y�����ܫO���������СA�����q�ǿ��b�e�̡A���H�o�q���� */
            if( iCount != 0) 
            {
                $UPDATE t338b
                    SET note = 0
                  WHERE icard = $icard;

                printf("sqlca.sqlerrd[2][%d],��0���ܨS��update���\n", sqlca.sqlerrd[2]);
            }
       
        }
        else
        {
            puts("���Ƨ�O�Ҭ������q");

            $SELECT COUNT(*)
               INTO $iCount
               FROM t338a
              WHERE iassured = $iassured
                AND itag = $itag
                AND icard != $icard
                AND icard[1,2] != '17';
            if( iCount == 0)  /* �u�P�����q����, �p�Gt338b�䤣����ܵL�O�B,���H�o�q���� */
            {
                $SELECT COUNT(*)
                   INTO $iCount
                   FROM t338a a, t338b b
                  WHERE a.iassured = $iassured
                    AND a.itag = $itag
                    AND a.icard != $icard
                    AND a.icard[1,2] = '17'
                    AND a.icard = b.icard;

                if (iCount == 0)
                {
                    $UPDATE t338b
                        SET note = 0
                      WHERE icard in (SELECT icard FROM t338a
                                       WHERE iassured = $iassured
                                         AND itag = $itag
                                         AND icard = $icard);
                }
            }

            /* �H�Q�O�I�Hid�M�����A��M�P�ۤv�O�I�_�l�餣�P�λP�ۤv�O�I����餣�P���L����� */

            $SELECT COUNT(*)
               INTO $iCountDiffPeriod
               FROM t338a
              WHERE iassured = $iassured
                AND itag = $itag
                AND (dply_begin != $dply_begin
                    OR dply_end != $dply_end)
                AND icard != $icard;
            printf("iCountDiffPeriod[%d]\n", iCountDiffPeriod);
            if( strlen( trim( dpay)) == 0)
            {
                puts("���������O");
                $SELECT COUNT(*)
                   INTO $iCount
                   FROM t338b
                  WHERE icard IN (SELECT icard FROM t338a
                                   WHERE iassured = $iassured
                                     AND itag = $itag
                                     AND icard != $icard)
                    AND dpay != ' ';
                if( iCount != 0)
                {
                    puts("�L���w���O");
                    $UPDATE t338b
                        SET note = 0
                      WHERE icard in (SELECT icard FROM t338a
                                       WHERE iassured = $iassured
                                         AND itag = $itag
                                         AND icard != $icard)
                        AND dpay != ' ';
                }
                else
                {
                    puts("�ҥ����O");
                    if( iCountDiffPeriod != 0) /* �Y�����ܫO���������ơA�O���ͮĦb�e�̡A���H�o�q���� */
                        $UPDATE t338b
                            SET note = 0
                          WHERE icard in (SELECT icard FROM t338a
                                           WHERE iassured = $iassured
                                             AND itag = $itag
                                             AND icard != $icard
                                             AND date(  dply_begin[5,6] || '/'|| dply_begin[7,8]||'/'|| dply_begin[1,4]) 
                                                 < $sdply_begin)
                            AND nvl(dpay,'') = '';
                    else           /* �Y�䤣����ܫO���������ơA�ǿ��b�e�̩ζǿ��ۦP�O�d���p���A���H�o�q���� */
                        $UPDATE t338b
                            SET note = 0
                          WHERE icard in (SELECT icard FROM t338a
                                           WHERE iassured = $iassured
                                             AND itag = $itag
                                             AND icard != $icard
                                             AND ( (date(  dtrans[5,6] || '/'|| dtrans[7,8]||'/'|| dtrans[1,4]) 
                                                    < date($sdtrans)
                                                   ) or
                                                   (date(  dtrans[5,6] || '/'|| dtrans[7,8]||'/'|| dtrans[1,4])
                                                    = date($sdtrans) and icard < $icard
                                                   )
                                                 )
                                         )
                            AND nvl(dpay,'') = '';
                }

            }
            else
            {
                puts("�����w���O");
                $SELECT COUNT(*)
                   INTO $iCount
                   FROM t338b
                  WHERE icard IN (SELECT icard FROM t338a
                                   WHERE iassured = $iassured
                                     AND itag = $itag
                                     AND icard != $icard)
                    AND dpay = '';
                if( iCount != 0)
                {
                    puts("�L�������O");
                    $UPDATE t338b
                        SET note = 0
                      WHERE icard = $icard;
                }
                else
                {
                    puts("�Ҥw���O");
                    if( iCountDiffPeriod != 0) /* �Y�����ܫO���������ơA�O���ͮĦb�e�̡A���H�o�q���� */
                        $UPDATE t338b
                            SET note = 0
                          WHERE icard in (SELECT icard FROM t338a
                                           WHERE iassured = $iassured
                                             AND itag = $itag
                                             AND icard != $icard
                                             AND date(  dply_begin[5,6] || '/'|| dply_begin[7,8]||'/'|| dply_begin[1,4]) 
                                                 < $sdply_begin)
                            AND nvl(dpay,'') != '';
                    else                /* �Y�䤣����ܫO���������ơA�ǿ��b�e�̩ζǿ��ۦP�O�d���p���A���H�o�q���� */
                        $UPDATE t338b
                            SET note = 0
                          WHERE icard in (SELECT icard FROM t338a
                                           WHERE iassured = $iassured
                                             AND itag = $itag
                                             AND icard != $icard
                                             AND ( ( date(  dtrans[5,6] || '/'|| dtrans[7,8]||'/'|| dtrans[1,4]) < $sdtrans
                                                   ) or
                                                   ( date(  dtrans[5,6] || '/'|| dtrans[7,8]||'/'|| dtrans[1,4]) = $sdtrans
                                                     and icard < $icard
                                                   )
                                                 )
                                         )
                            AND nvl(dpay,'') != '';
                }
            }
            printf("sqlca.sqlerrd[2][%d],��0���ܨS��update���\n", sqlca.sqlerrd[2]);
        }
        
    }

    sprintf_s(filename, sizeof filename, "%s/dat/car/%s", aphome, noteDataFile);
    printf("filename[%s]\n",filename);
    if (( fp_note=fopen( filename,"w"))==NULL)
    {
        sprintf_s(sMsg, sizeof sMsg, "Cannot open Ouput file: %s\n", filename);
        printf("%s", sMsg);
        return M_CM_OPEN_FILE_FAIL;
    }

    $DECLARE curs7 CURSOR FOR
      SELECT a.icard, a.dply_begin, a.dply_end, a.iassured, a.itag, b.ipolicy, c.nrin_abbre, 
             b.nleader, a.itag, a.icard[3,20]
        FROM t338a a, t338b b, outer ri_ricom_info c
       WHERE a.icard = b.icard
         AND a.icard[1,2] = c.irin_com
         AND a.icard[1,2] = '17'
         AND b.note = 1;
    
    key = 1;
    $OPEN curs7;
    for(;;)
    {
        $FETCH curs7 INTO $icard, $dply_begin, $dply_end, $iassured, $itag, $ipolicy, $nrin_abbre,
                          $nleader, $itag, $icard3 ;
        if (SQLCODE==SQLNOTFOUND) break;

        /* ��Ʀs�b��ca_no_notify,���H�o�q���� */
        $SELECT COUNT(*)
           INTO $iCount
           FROM ca_no_notify
          WHERE icard = $icard3;

        if( iCount != 0)
            continue;

        /* �P�H�o�q�����Ҹ��ۦP�Q�O�I�H,��������L�Ҹ��s�b��ca_no_notify,�]���H�o�q���� */
        $SELECT COUNT(*)
           INTO $iCount
           FROM t338a a, ca_no_notify b
          WHERE a.icard[3,20] = b.icard
            AND a.iassured = $iassured
            AND a.itag = $itag
            AND a.icard != $icard;

        if( iCount != 0)
            continue;

        sIupcompShort[0] = ipolicy[2]; /* �O�渹�ĤT�X */
        sIupcompShort[1] = '\0';
        strcpy( policyDB, get_upcomp(sIupcompShort, USE_SHORT_BRANCH_ID, USE_BRANCH_ID));
        strcpy( policyDBname, get_full_dbname(policyDB));

        sprintf_s(stmt, sizeof stmt, "SELECT a.apayment_zip, a.apayment, a.nassured, a.fsex, b.nbranch, c.itel"
                       "  FROM %s:policy a, outer sa_branch_type b, outer ca_big_office c, %s:ply_relation d"
                       " WHERE a.ipolicy = d.ipolicy"
                       "   AND d.iquota[1,4] = b.ibranch[1,4]"
                       "   AND b.ibranch[5,6] = '00'"
                       "   AND d.iquota[1,4] = c.ibig_comp[1,4]"
                       "   AND c.fclass = '3'"
                       "   AND c.ibig_comp[5,6] = '00'"
                       "   AND a.ipolicy = '%s' ", policyDBname, policyDBname, ipolicy);
        printf("stmt[%s]\n", stmt);
        $PREPARE prep5 FROM $stmt;
        $EXECUTE prep5 INTO $apayment_zip, $apayment, $nassured, $fsex, $nbranch, $itel;
        strcpy( nassured, trim( nassured));
        if( fsex[0] == '1')
            strcat( nassured, "  ���� ��");
        else if( fsex[0] == '2')
            strcat( nassured, "  �p�j ��");
        else
            strcat( nassured, "  ��");

        /* �g�ɮɨ�����1�X�H*�����N */
        strcpy( sitag, itag);
        sitag[0] = '*';
        fprintf(fp_note, "%d\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n", 
                key, apayment_zip, apayment, nassured, sitag, nrin_abbre, icard, 
                dply_begin, dply_end, nbranch, nleader, itel);

        printf("icard[%s], iassured[%s], itag[%s]\n", icard, iassured, itag);
        $DECLARE curs8 CURSOR FOR
          SELECT a.icard, a.dply_begin, a.dply_end, b.nrin_abbre
            FROM t338a a, outer ri_ricom_info b
           WHERE a.icard != $icard
             AND a.icard[1,2] = b.irin_com
             AND a.iassured = $iassured
             AND a.itag = $itag;
        $OPEN curs8;
        for(;;)
        {
            $FETCH curs8 INTO $icard, $dply_begin, $dply_end, $nrin_abbre ;
            if (SQLCODE==SQLNOTFOUND) break;

            /* �p�G�O17����ơA�p�G�O�B����0�A��Ʒ|�s�b��t338b�A�䤣����ܫO�B��0�A�h���C�L�b�q����W */
            if( strncmp( icard, "17", 2) == 0)
            {
                $SELECT COUNT(*)
                   INTO $iCount
                   FROM t338b
                  WHERE icard = $icard;
                if ( iCount == 0) continue;
            }
            fprintf(fp_note, "%d\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n", 
                    key, apayment_zip, apayment, nassured, sitag, nrin_abbre, icard, 
                    dply_begin, dply_end, nbranch, nleader, itel);
        }

        key++;
    }
    fclose(fp_note);

    strcpy( sMsg, "�j���I���Ƨ�O�q�����ƷJ�㧹��,���I��car338�C�L�q����");

    return M_CM_OK;

errexit:
    sprintf_s(sMsg, sizeof sMsg, "car338_note:sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    printf("%s", sMsg);
    return SQLCODE;
}

/* -------------------------------------------------------------------------------*/

char stitle[1024] =
"�O�I�Ҹ�\t�Q�O�I�H�m�W\t�����Ҹ�/�νs\t���P���X\t�O�I�_�l��\t�O�I������\tñ���\t�ǰe��\t"
"�O�o���Ѥ��\t�X����e�T�X\t�����q�O�渹\t�޲z�H\t�޲z�H�W��\t�g��N��\t�g��H�W��\t"
"���²��\t�O�B\t���O���A\t�O�榬�O��\t�n�O�H\t�n�O�H�a�}\t�~�Z���e�|�X\t";
long car338_file()
{
DBinfo  *list;
int     i, count_db, fStat;
$char   stmt[1024], cmd_stmt[20480];
char    ReportName[201], sdelimiter[2];

   WRITELOG( sfp, " ");
   sprintf_s(sMsg, sizeof sMsg, " ");
   WRITELOG( sfp, sMsg);

   sprintf_s(ReportName, sizeof ReportName ,"�j���I���Ƨ�O��Ƭd��_%s.txt", outputf);

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

    $SELECT distinct * FROM t338b
       INTO TEMP t338c;

    /* �p�G��X�[���, ���Y(stitle)�O�o�[ */
    sprintf_s(stmt, sizeof stmt, "SELECT a.*, b.ipolicy[1,3], b.ipolicy, b.ileader, b.nleader, "
                   "       b.iofficer, b.nofficer, b.nquota, b.mdamage_cover, b.payresult, b.dpay,"
                   "       b.napplicant, b.apayment, b.iquota " 
                   "  FROM t338a a, outer t338c b"
                   " WHERE a.icard = b.icard "
                   "   and a.itag NOT IN  "
                   "       (SELECT G.itag FROM (SELECT count(*) as icnt, a1.iassured , a1.itag, min(c1.mdamage_cover) as cover FROM t338a a1, outer t338c c1 where c1.icard = a1.icard  "
                   "   	     GROUP BY a1.iassured , a1.itag ) G WHERE G.icnt = 2 and G.cover = 0  )    " 
                   " ORDER BY a.rowid;\r\n");
    fStat = unload_file( outputf," ", ReportName, stitle, stmt);
    if (fStat != SUCCESS) {
        sprintf_s(sMsg, sizeof sMsg," %s �ɮ׵L�k���� ",ReportName);
        return fStat;
    }

    /* unload_file �ɮײ��ͦb aphome/batchfile, �n����aphome/rptftp, rptftpinsert�~��o���ɮ� */
    sprintf_s(cmd_stmt, sizeof cmd_stmt,
        "mv %s/batchfile/%s %s/rptftp/%s", aphome, outputf, aphome, ReportName);

    printf("cmd_stmt=[%s]\r\n", cmd_stmt);
    rc = system( cmd_stmt);
    if (rc != 0) {
        printf("mv file���~\r\n");
        sprintf_s(sMsg, sizeof sMsg, "mv file���~\r\n");
        return rc;
    }

    rc=rptftpinsert(userid,"car338", ReportName );
    printf("rptftpinsert rc[%d]\n", rc);
    if (rc!=0)
    {
       sprintf_s(sMsg, sizeof sMsg,"�g�Jrptftplist���~\r\n");
       return rc;
    }

    sprintf_s(sMsg, sizeof sMsg,"\n�d�ߧ���,���I���ɮפU���@�~�d��[Q],�U�� [%s] \r\n", ReportName);
    return M_CM_OK;

errexit:
    printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    sprintf_s(sMsg, sizeof sMsg, "sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/* -------------------------------------------------------------------------------*/
char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
        char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
        char sTmp_db_name[21];

        sTmp_db_name[0]='\0';
        if (*sIpolicy != '\0' && *sIpolicy !=' ')
        {
           sTmp_db_name[0]='\0';
           strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
           strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
                  USE_BRANCH_ID));
           strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
        }
  return sTmp_db_name;
}
/* -------------------------------------------------------------------------------*/

