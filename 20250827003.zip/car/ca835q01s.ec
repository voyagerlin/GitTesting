/************************************************/
/*   PROGRAM : ca835q01s.ec                     */
/*   MODIFY  : cyrus                            */
/*   DATE    : 103.06.16                        */
/*   NOTE    : ��ֽ߮ש��Ӫ�                   */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
$include datetime.h;
#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"

$char DBName[05], iForm_Tp[03], outputf[N_FILE+1];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1];
char  userid[11];

char  msgbuf[100];
$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;
$int  PERIOD;

static int  max_count;

DBinfo  *list;
int     count_db;

$char sIbranch[BRANCH_ID], sIofficer[EMPLOYEE_ID];
$char sNname[EMPLOYEE_NAME];
$char sIclaim[CLAIM_NUM], sFcard_class[2], sDclaim[YYYYMMDD];
$char sYearMonth[7];
$char sIadjuster[EMPLOYEE_ID], sFclose[2], sIins_type[INSURANCE_TYPE];
$char sDclose[13], victim[11], flast[2];
$char sDgroup[11];
$char sNgroup[5],sNadjuster[11];
$char sIupbranch[3], sNupgroup[11];
$char sFins_grp[2];
$char sBgnDate_e[11], sEndDate_e[11], sBgnDate[11], sEndDate[11];
$long lBgnDate, lEndDate;
$long iQorder, i, qmonth, lMins_stl;
$long qdmg_claim, qdmg_close, qdmg_nopay;       /** ���l **/
$long qlia_claim, qlia_close, qlia_nopay;       /** �d�� **/
$long qburg_claim, qburg_close, qburg_nopay;    /** �W�[�ѵs�����Ѩ��l�������X **/
$long qcomp_claim, qcomp_close, qcomp_nopay;    /** �j�� **/
$long qwea_claim, qwea_close, qwea_nopay;       /** �]�� **/
$date lDclaim;
$int  iclose_type;
$char stmt[2000];

$char iins_item[INSURANCE_TYPE];

int qlia, qburg, qdmg, qwea;
$int iTmp;
$int iMaxCnt;
$int id1;
$int iMonthDiff;

long car835_build();
void car835_title();
long car835_body();
long car835_print();
void car835_print2();
int DiffMonth();

/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
   int rc;
   
   batchinit();
   strcpy(DBName  , isNULLstr(argv[1]));
   strcpy(userid  , isNULLstr(argv[2]));
   strcpy(sBgnDate, isNULLstr(argv[3]));
   strcpy(sEndDate, isNULLstr(argv[4]));
   strcpy(outputf , isNULLstr(argv[5]));

   strcpy(sBgnDate_e, cm_to_infdate(sBgnDate));
   strcpy(sEndDate_e, cm_to_infdate(sEndDate));

   rstrdate(sBgnDate_e, &lBgnDate);
   rstrdate(sEndDate_e, &lEndDate);

   printf("sBgnDate_e[%s] sEndDate_e[%s]\n",sBgnDate_e , sEndDate_e);
 
   rc=car835_get_db();
   if (rc!=M_CM_OK)
      return rc;
   
   rc = car835_build();
   if (rc != M_CM_OK)
       return rc;

   return M_CM_OK;
   
errexit:
   printf("main :SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/

long car835_build()
{
   $char  TitleFmt[N_FILE+1],BodyFmt[N_FILE+1];
   int    rc;
   
   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT;
   
   if (db_select(DBName) == False)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   rc = car835_body();
   if (rc != M_CM_OK)
       return rc;
           
   rc = car835_print();
   if (rc != M_CM_OK)
       return rc;
 
   return M_CM_OK;

errexit:
   EWRITE(userid,rc,sqlca.sqlerrm);
   return SQLCODE;  
}

long car835_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

long car835_body()
{
    int i;
    long rc;
    $char sStmt[4096],sStmt1[1024],sStmt2[1024],sStmt3[1024],sStmt4[1024];
    $char  stmt[1024];

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;

    $CREATE TEMP TABLE car835
    (
        iclaim         char(20),
        iadjuster      char(10),
        dclaim         date,
        dapp_last      date,
        dfirst         date,
		daccident_last date
    )
    WITH NO LOG;

    $CREATE INDEX car835_tmp_id1 ON car835(iadjuster);
    $CREATE INDEX car835_tmp_id2 ON car835(iclaim);

    for (i=0;i<count_db;i++)
    {
        sprintf_s(sStmt,4096,
         " insert into car835  \
           select unique a.iclaim, x.adjustment, date(x.dclaim), a.dappraisal, x.dfirst, \
						(select max(date(h.dappraisal)) from %s:app_ins_type_hist h  WHERE a.iclaim = h.iclaim  AND h.dappraisal  <= ?  ) \
             from %s:app_ins_type_hist a, ca_clm_process x      \
            where a.iclaim  =  x.iclaim                        \
              and x.frule   = '1'                              \
              and ((a.dappraisal between ? and ?) or           \
                   (date(x.dfirst) between ? and ?))      \
              and a.dappraisal = ((select max(b.dappraisal)            \
                                     from %s:app_ins_type_hist b       \
                                    where b.dappraisal <= ?            \
                                      and a.iclaim = b.iclaim          \
                                      and a.iins_type = b.iins_type    \
                                      and b.dappraisal <= (select nvl(date(c.dfirst),'%s')   \
                                                             from ca_clm_process c     \
                                                            where b.iclaim = c.iclaim ))) ",
                                                           list[i].dbname, list[i].dbname, list[i].dbname, sEndDate_e);

        printf("sStmt[%s]\n",sStmt);
        $prepare main_id1 from $sStmt;
        $execute main_id1 using $sEndDate_e, $sBgnDate_e, $sEndDate_e, $sBgnDate_e, $sEndDate_e, $sEndDate_e;

        sprintf_s(sStmt,4096,
         " insert into car835  \
           select unique a.iclaim, x.adjustment, date(x.dclaim), a.dappraisal, x.dfirst, \
						(select max(date(h.dappraisal)) from %s:ca_app_victim_hist h  WHERE a.iclaim = h.iclaim  AND h.dappraisal  <= ?  ) 	\
             from %s:ca_app_victim_hist a, ca_clm_process x      \
            where a.iclaim  =  x.iclaim                          \
              and x.frule   = '1'                                \
              and ((a.dappraisal between ? and ?) or             \
                   (date(x.dfirst) between ? and ?))             \
              and a.dappraisal = ((select max(b.dappraisal)              \
                                     from %s:ca_app_victim_hist b        \
                                    where b.dappraisal <= ?              \
                                      and a.iclaim      = b.iclaim       \
                                      and a.iins_item   = b.iins_item    \
                                      and a.ivictim     = b.ivictim      \
                                      and b.dappraisal <= (select nvl(date(c.dfirst),'%s')   \
                                                             from ca_clm_process c     \
                                                            where b.iclaim = c.iclaim ))) ",
                                                           list[i].dbname, list[i].dbname, list[i].dbname, sEndDate_e);

        printf("sStmt[%s]\n",sStmt);
        $prepare main_id2 from $sStmt;
        $execute main_id2 using $sEndDate_e, $sBgnDate_e, $sEndDate_e, $sBgnDate_e, $sEndDate_e, $sEndDate_e;

    } /* end for three database */
    
    return M_CM_OK;
        
errexit:
   printf("car835_body ==> SQLCODE:[%ld][%s] \n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   printf("   end EWRITE \n");
   return SQLCODE;
}

long car835_print()
{
   $char stmt[4096], stmt1[1024], stmt2[1024];
   $long qorder;
   int i,x,j,k;
   $int COUNT;
   $char sfilename[31];
   $char stitle[10000];
   $char ssql[10000];
   $char dyearmonth_tmp[7];
   $char title_tmp[101];
   $char title_tmp0[101];
   $char title_tmp1[101];
   $char title_tmp2[101];
   $char filed[20][15];
   $char sqltmp[1024];
   $char filed_tmp[200];
   $char sErrmsg[100];
   $int  rc;

   $WHENEVER ERROR goto errexit;
   $SET LOCK MODE TO WAIT;


   strcpy(sfilename,"��ֽ߮ש��Ӫ�");

   strcpy(stitle,"�έp����G");
   strcat(stitle, sBgnDate_e);
   strcat(stitle, " ~ ");
   strcat(stitle, sEndDate_e);
   strcat(stitle,"\n\t�`�����q�O\t���\t�Ҧb�a\t�z�ߤH��\t�z�ߥD��\t�߮׸��X\t���z��\t��֫e�̫�w����\t�̫�w����\t�D�ު�֧�����\t��֤u�@�Ѽ�\t");

   strcpy(ssql, "  select decode(b.iupcomp,'0','00','1','40','2','70','5','22','6','33','7','66') as iupcomp, ");
   strcat(ssql, "         (select xx.nbranch from sa_branch_type xx where xx.ibranch = b.iquota) as nquota,   ");
   strcat(ssql, "         (select yy.nchi_full from branch yy, cm_clm_adjuster zz where zz.iapp_unit = yy.ibranch and zz.empl_no = a.iadjuster) as nlocal, ");
   strcat(ssql, "  b.nname,   ");
   strcat(ssql, "  (select v.chinese_name  from personal:asempl x,personal:asempl v where x.empl_no = a.iadjuster and x.administrator = v.empl_no) as adm,  ");
   strcat(ssql, "  a.iclaim, a.dclaim, a.dapp_last, a.daccident_last, a.dfirst, ");
   strcat(ssql, "  (select count(*) from cm_wrktbl where fwork = 0 and dwork >= a.dapp_last and dwork < a.dfirst) iday ");
   strcat(ssql, "  from car835 a, officer b where a.iadjuster  =  b.iofficer into temp car835_temp with no log ");

   printf(" ssql [%s]\n",ssql);
 
   $prepare exe1 from $ssql;
   $execute exe1;

   strcpy(ssql," select * from car835_temp order by 1,2,3,4,5,6 ");

   rc = unload_file(outputf," ",sfilename,stitle,ssql);

   if (rc != SUCCESS)
   {
       if (rc == 3501)
       {
          sprintf_s(sErrmsg,100," ��J���^������䤣���� ",sfilename);
       }
       else
       {
          sprintf_s(sErrmsg,100," %s �ɮ׵L�k���� ",sfilename);
       }

       EWRITE(userid, rc , sErrmsg);
       exit(1);
   }

   return M_CM_OK;

errexit:
  printf("SQL=[%d], sqlca.sqlerrm[%s]\n", SQLCODE, sqlca.sqlerrm);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  exit(1);
    
}

int DiffMonth(d1,d2)    /* input data should be date format */
long d1, d2;
{
short mdy1[3], mdy2[3];
int datediff=0;

    rjulmdy(d1,mdy1);
    rjulmdy(d2,mdy2);
    datediff=(mdy1[2]*12+mdy1[0])-(mdy2[2]*12+mdy2[0]);
    if (datediff<0) datediff=0;
    return datediff;
}

