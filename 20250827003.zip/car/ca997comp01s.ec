/*********************************************
 * Copyright (C) 1995 Intellisys Corporation
 * Program : ca997comp01.ec
 * �j����O�O�d�ߤ��߫O����
 *********************************************/
 
#include <stdio.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"
#include "sqlfatal.h"
#include <time.h>

#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"

#include "safeclib.h"

#define ONLINE_DATE "04/29/2007"	/* �e���T��Ʊj����N���ɤW�u�� */

 time_t tstart,tend;   
 float tused=0;

/*--------------------------------------------------------------------*/
DBinfo  *list;
int     i=0,count_db=0,rc=0;

char userid[11],option[2],outputf[21];
$char DBName[05];
$char dbgn1[11],dend1[11],datebgn[11],dateend[11];
$char sApHome[31];
char errmsg[200];
FILE *errfpt;
FILE *fptr;

$char  errFile[30],strlog[500],errlog[300];

/* data from ori_ply_relation */

$char ipolicy[21],fcard_class[2],sIpolicy1[15],ilast_ply[21],icard[21];
$char icar_type[3],iissue_ym[6],ibrand[10],ipro_year[5],fcomp_class[3];
$char fcomp_class_last[3],ibig_comp[2], icar_flag[2] ,chk_dpolicy[2];
$long dpolicy=0,dply_begin=0,dply_end=0,madjcom_prem=0,mbusiness=0;
$int qply_period=0, ibatch_no=0;

/* data from original_ply*/
$char ilicense[11],ibirth[9],fsex[2],fmarriage[2],fpt[2],iengine[CA_ENGINE_NUM];
$char ibody[CA_BODY_NUM],itag[CA_TAG_NUM],iassured[11],nassured[121],iply_area[3],fassured[2], apayment[91]; 
/*$char apayment_zip[5];*/
$int qcylinder=0;
$double qpt;
$int id1 = 0;
   
/* data from ori_ins_type */
$int ipdmg_align, iplia_align,ipbrg_align;
int iTmpbuf;
$char iins_type[3],iins_type_rule[3],drate_ym[6];
$long  mdamage_cover=0,minjured_cover=0,mdeath_cover=0;
$long  mdeduct=0,mins_premium=0,mprem=0;

/* others data */
int iFetch;
char  sPrePolicy[21],sPrePolicy1[21];
$long  sDpolicy;
$char prem_subtot_c[10],mins_premium_c[10];
$char objno[5],icode[2],drate[11];
$long prem_subtot=0,prem_subtot0=0,mdeduct01=0,cntrlrec=0,birth_yyyy=0;
$long prem_total=0,qcount=0;
$char prtstr[500];
char  drate_yy[4],drate_mm[3],drate_dd[3],tmp_yyy[4],tmp_yyyy[5];
$char  dply_yy[4],dply_mm[3],ibirth_yy[5],ibirth_mm[3],ibirth_dd[3],tmp_dd[3];
char  card_str[16],dply_begin_c[9],dply_end_c[9];
char  dply_begin_yy[4],dply_begin_mm[3],dply_begin_dd[3];
char  dply_end_yy[4],dply_end_mm[3],dply_end_dd[3];
$char  iissue_yy[5],iissue_mm[3],cntrlrec_c[7],ftrans_trade[2],bzfrom[3];
char  minjured_c[9],mdeath_c[9],mdamage_c[9],mdeduct_c[8],mprem_c[10];
char  drate_c[9],dpolicy_c[9],sTmpbuf[200];
char  day_yy[4],day_mm[3],day_dd[3];
long  yy_long=0,iRtnCode;
char  companyid[3];
int   rtn;
$char qpro_month_c[3];

$char nassured_tmp[201];


long car9971_get_db();
long car9971_build_comp();
long car9971_ori_relation();
extern char *sformat_trade();
extern long split_policy();
extern int rptftpinsert();
static char *get_car_full_db();  /*   �ǤJ�O�渹��X���O�檺�k�ݸ��*/
long check_if_exist();
long  today=0, online_date=0, online=0;

/*--------------------------------------------------------------------*/
main(argc,argv)
int   argc;
char  **argv;
{
int   rc,rt;

   batchinit();

   strcpy(DBName,isNULLstr(argv[1]));
   strcpy(userid,isNULLstr(argv[2]));
   strcpy(option,isNULLstr(argv[3])); /* 1:�j��T���O��, 3:�j������O��, 4:�O�歫�e, 5:�O��簣���e */
   strcpy(datebgn,isNULLstr(argv[4]));
   strcpy(dateend,isNULLstr(argv[5]));
   strcpy(outputf,isNULLstr(argv[6]));
   
   if (datebgn[0]=='*' || datebgn[0] == '\0') 
     strcpy(datebgn,  "80/01/01");
   if (dateend[0]=='*' || dateend[0] == '\0') 
     strcpy(dateend,  "99/12/31");
     
   strcpy(dbgn1,cm_to_infdate(datebgn));
   strcpy(dend1,cm_to_infdate(dateend));

   printf("dbgn1[%s] dend1[%s]\n",dbgn1,dend1);
   
   $WHENEVER SQLERROR GOTO errexit;
   
   rstrdate( ONLINE_DATE, &online_date);
   rtoday( &today);

   online = today >=online_date ? TRUE:FALSE;

   errfpt = (FILE *) STARTLOG();   time(&tstart);

   rc=car9971_get_db();
   if (rc!=M_CM_OK)
      return rc;
    
   rt = getApHome(sApHome);
   if (rt < 0) {
        printf("read Config file error!!\n");
        return M_CM_READ_CONFIG_ERR;
   }   
   
   $CREATE TEMP TABLE CAR9971
   (
      Tipolicy	   char(20),
      Tfcard_class char(2),
      Tipolicy1	   char(14),
      Tilast_ply   char(14),
      Ticard	   char(21),
      Tdpolicy	   int,
      Ticar_type    char(3),
      Tiissue_ym    char(8),
      Tibrand	    char(8),
      Tipro_year    char(5),
      Tdply_begin   int,
      Tdply_end	    int,
      Tqply_period  int,
      Tmadjcom_prem int,
      Tmbusiness    int,
      Tfcomp_class  char(3),
      Tfcomp_class_last char(3), 
      Tibatch_no    int,
      Tibig_comp    char(2),
      icar_flag     char(1),
      chk_dpolicy   char(1),
      ftrans_trade  char(1),
      bzfrom        char(2)
   ) WITH NO LOG;
   
   rc=car9971_ori_relation();
   if (rc!=M_CM_OK)
      return rc;

   rgetmsg(rc, errlog, sizeof(errlog));
   sprintf_s(strlog,sizeof strlog,"%s\n\n\t\t     ",errlog);
   printf("option [%s]\n",option);
        
   if( strcmp(option,"1") == 0 )
   {
       rc=car9971_build_comp();  
       if (rc!=M_CM_OK)
           strcat(strlog," isap17_�j��T���O��s�@���� ");
   }
   else if (strcmp(option,"3") == 0)
   {
       rc=car9971_build_comp();  
       if (rc!=M_CM_OK)
   	   strcat(strlog," ismp17_�j������O��s�@���� ");
   }
   else if (strcmp(option,"4") == 0)
   {
       rc=car9971_build_comp();  
       if (rc!=M_CM_OK)
           strcat(strlog,"�j��O�歫�e���� ");
   }
   else if (strcmp(option,"5") == 0)
   {
       rc=car9971_build_comp();  
       if (rc!=M_CM_OK)
           strcat(strlog,"�j��O��𰣭��e���� ");
   }
        
   printf("strlog[%s]\n",strlog); 
  	
   EWRITE(userid,rc,strlog);
   	
   exit(1);
   
   time(&tend); 
   tused = difftime( tend, tstart);
   printf(" used time is [%f]\n",tused);
   
   exit(0);
   
errexit:
    printf("car9971-main:sqlcode=%d, sqlmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;   
   
}
/*--------------------------------------------------------------------*/

long car9971_get_db()
{
   $whenever sqlerror goto errexit;

   printf("userid[%s] DBName[%s]\n",userid,DBName);

   if (db_select(DBName) == FALSE) {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);

   return SQLCODE;
}

/*------------------------------------------------------------------*/

long car9971_ori_relation()
{
	
   int i;
   $char stmt_buf1[5000],stmt_buf2[1024];
   $char stmt_db[512],stmt_statement[1024];
      
      /* data from ori_ply_relation */
   $char Oipolicy[21],Ofcard_class[2],OsIpolicy1[15],Oilast_ply[21],Oicard[21];
   $char Oicar_type[3],Oiissue_ym[6],Oibrand[10],Oipro_year[5],Ofcomp_class[3];
   $char Ofcomp_class_last[3],Oibig_comp[2],Ochk_dpolicy[2];
   $long Odpolicy,Odply_begin,Odply_end,Omadjcom_prem,Ombusiness;
   $int  Oqply_period, Oibatch_no;
   $char Oftrans_trade[2],Obzfrom[3];
   
   $long tmp_cnt=0;
   
   rtn = getCompanyId(companyid);
     
   for (i=0;i<count_db;i++)
   {
       	
       	/* if option = 5, it has to join with table [ca_tmp_no] */
       	strcpy(stmt_statement,"");
       	strcpy(stmt_db,"");
        if( strcmp(option,"5") == 0 )
   	   {
   		/*sprintf_s(stmt_db, sizeof stmt_db,", %s:ca_tmp_no b",list[i].dbname);*/
   		strcpy(stmt_db,", ca_tmp_no b");
   		strcpy(stmt_statement,"AND a.ipolicy = b.ipolicy");
 	      }
       /* End of statement */
       
       /* 1050803001 _C1 �ӽзs�W�ܺ��I�j���I�Y�ɶǿ�@�~ */
       /*�W�[�ǰe�q���O�N�X*/
       
       sprintf_s(stmt_buf1, sizeof stmt_buf1,"SELECT a.ipolicy,fcard_class,a.ipolicy[1,13],ilast_ply[1,13],icard, "
                         "       dpolicy,icar_type,iissue_ym,ibrand,ipro_year,dply_begin, "
                         "       dply_end,qply_period,madjcom_prem,mbusiness,fcomp_class, "
                         "       fcomp_class_last, ibatch_no,ibig_comp, icar_flag, "
                         "       CASE WHEN dpolicy < '08/01/2016' THEN 'Y' ELSE 'N' END , ftrans_trade, "
                         "       a.bzfrom "
                         "  FROM %s:ori_ply_relation a %s"
                         " WHERE dpolicy >= '%s' AND dpolicy <= '%s' %s AND fcard_class = '1' "
                         "   AND ( dtrans_trade is null OR "
                         "        (dtrans_trade::date = today AND ftrans_trade = '1' AND itrans_trade = 'car9971') ) " ,
                         list[i].dbname,stmt_db,  dbgn1, dend1,stmt_statement);
                         
        
        printf("stmt_buf1[%s]\n",stmt_buf1);
        
        $PREPARE CUR_STMT1 FROM $stmt_buf1;
        $DECLARE scur_ply1 CURSOR FOR CUR_STMT1;
   	
	   	$OPEN scur_ply1;
	   	
	   	while(1)
	   	{
	   		
	   	  $FETCH scur_ply1 
	   	    INTO $Oipolicy, $Ofcard_class, $OsIpolicy1, $Oilast_ply,$Oicard,
	                 $Odpolicy, $Oicar_type,   $Oiissue_ym, $Oibrand,   $Oipro_year,
	                 $Odply_begin,$Odply_end,  $Oqply_period,$Omadjcom_prem,$Ombusiness,
	                 $Ofcomp_class,$Ofcomp_class_last, $Oibatch_no,$Oibig_comp,$icar_flag,$Ochk_dpolicy, $Oftrans_trade,
	                 $Obzfrom;
	
	          if (SQLCODE == SQLNOTFOUND) break;
	   	
	   	  $INSERT INTO CAR9971
	   	  (
	   	   Tipolicy, Tfcard_class, Tipolicy1, Tilast_ply, Ticard, Tdpolicy ,
	   	   Ticar_type, Tiissue_ym, Tibrand, Tipro_year, Tdply_begin, Tdply_end ,
	   	   Tqply_period, Tmadjcom_prem, Tmbusiness, Tfcomp_class, Tfcomp_class_last,
	   	   Tibatch_no, Tibig_comp, icar_flag ,chk_dpolicy, ftrans_trade,
	   	   bzfrom
	   	  )
	   	  VALUES
	   	  (
	   	   $Oipolicy, $Ofcard_class, $OsIpolicy1, $Oilast_ply,$Oicard,
	           $Odpolicy, $Oicar_type,   $Oiissue_ym, $Oibrand,   $Oipro_year,
	           $Odply_begin,$Odply_end,  $Oqply_period,$Omadjcom_prem,$Ombusiness,
	           $Ofcomp_class,$Ofcomp_class_last, $Oibatch_no,$Oibig_comp,$icar_flag,$Ochk_dpolicy,$Oftrans_trade,
	           $Obzfrom
	          );
        } /* end of while */
    } /* end for loop */

    $CLOSE scur_ply1;
    $FREE  scur_ply1;                                	 

   return M_CM_OK;	
	
errexit:
    printf("car9971ori_relation:code=%d, msg=%s\n",SQLCODE,sqlca.sqlerrm);
    $DROP TABLE CAR9971;
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;	
} /* end of get ori_ply_relation */

/*--------------------------------------------------------------------------*/
/* �j���I */
long car9971_build_comp()
{
	
   $char tstmt[500],stmt1[500],stmt_buf2[1024],stmt_buf3[1024],stmt[300];
   char  tmp_dbname[20];
   $char Tmp1[20],file0[51],iply_type[3],fcard_class[2];
   $char sIbrand_new[10];
   $date Today;
   int  rtncode,aa=0,b=0;
   long rc;
   int  cond=0,i=0;

   rtoday(&Today);
  
   rtn = getCompanyId(companyid);
         
   printf(" ************************** companyid[%s]\n",companyid);
   
   /* If option = 1,3, loop is only running once; if option = 4, loop is running 2 times */
   if (strcmp(option,"1") == 0 || strcmp(option,"3") == 0) 
   {
   	cond = 2;
   } else {
   	cond = 1;
   }
   
   /*cntrlrec = 0;*/
 
for (i=cond;i<3;i++)
{ 
    cntrlrec = 0;
    sprintf_s(tstmt, sizeof tstmt,"SELECT * FROM CAR9971");
   
   if( strcmp(option,"1") == 0 || (i == 1))    /* �j��T���O�I�O�� */
   {
   	strcat(tstmt," WHERE Tfcard_class = '1' ");
   	strcat(tstmt,"   AND Ticar_type not in ('01' , '02' , '32', '34' ,'35') ");
   	strcat(tstmt," ORDER BY Tdpolicy, Tipolicy ");
   }
   else if ( strcmp(option,"3") == 0 || (i == 2))  /* �j������O�I�O�� */
   {
   	strcat(tstmt," WHERE Tfcard_class = '1' ");
   	strcat(tstmt,"   AND (Ticar_type='01' OR Ticar_type='02' OR Ticar_type='32' OR Ticar_type='34' OR Ticar_type='35') ");
        strcat(tstmt," ORDER BY Tdpolicy, Tipolicy ");
   } 
   else   /* �O�歫�e�H�έ簣���e */
   {
   	strcat(tstmt," ORDER BY Tdpolicy, Tipolicy");
   }
   
/*printf("tstmt[%s]\n",tstmt);*/
   
   $PREPARE CUR_TSTMT FROM $tstmt;
   $DECLARE scur_car9971 CURSOR FOR CUR_TSTMT;
   	              
   $OPEN scur_car9971;
   
   iFetch = TRUE;
   while(1)
   {  
     $FETCH scur_car9971 
       INTO $ipolicy, $fcard_class, $sIpolicy1, $ilast_ply,$icard,
            $dpolicy, $icar_type,   $iissue_ym, $ibrand,   $ipro_year,
            $dply_begin,$dply_end,  $qply_period,$madjcom_prem,$mbusiness,
            $fcomp_class,$fcomp_class_last, $ibatch_no,$ibig_comp,$icar_flag,$chk_dpolicy,$ftrans_trade,
            $bzfrom;
            
     if (SQLCODE == SQLNOTFOUND) break;
     
     strcpy(tmp_dbname,get_car_full_db(ipolicy));
     
     /***** prepare cursor for select original_ply *****/
     sprintf_s(stmt_buf2, sizeof stmt_buf2,"SELECT %s %s FROM %s:%s %s",
                       "ilicense,to_char(dbirth,'%Y'), to_char(dbirth,'%m'), to_char(dbirth,'%d'),fsex,fmarriage,qcylinder::int,qpt,fpt,iengine,ibody,",
                       "itag,iassured,nassured,iply_area,fassured, to_char(dissue, '%Y'), to_char(dissue, '%m'), apayment, (lpad(NVL(qpro_month,0),2,'0')) ",
                       tmp_dbname, "original_ply ",
                       "WHERE ipolicy=? ");

     $PREPARE CUR_STMT2 FROM $stmt_buf2;
     $DECLARE scur_policy1 CURSOR FOR CUR_STMT2;

     /***** prepare cursor for select ori_ins_type *****/
     sprintf_s(stmt_buf3, sizeof stmt_buf3,"SELECT %s %s FROM %s:%s %s ",
                       "iins_type,minjured_cover,mdeath_cover,",
                        "mdamage_cover,mdeduct,mins_premium,mprem,drate_ym",
                        tmp_dbname, "ori_ins_type", "WHERE ipolicy=? ");
                       
     $PREPARE CUR_STMT3 FROM $stmt_buf3;
     $DECLARE scur_ply_ins_a1 CURSOR FOR CUR_STMT3;
     
     $OPEN scur_policy1 USING $ipolicy;
     $FETCH scur_policy1
       INTO $ilicense,$ibirth_yy,$ibirth_mm,$ibirth_dd,$fsex,$fmarriage,$qcylinder,$qpt:id1,$fpt,
            $iengine,$ibody,$itag,$iassured,$nassured,$iply_area,$fassured,$iissue_yy,$iissue_mm,$apayment,$qpro_month_c;

     if (SQLCODE == SQLNOTFOUND)
     {
         $CLOSE scur_policy1;
            continue;
     }
     $CLOSE scur_policy1;
     if(id1 == -1)
        qpt = 0;

     if (strcmp(option,"4") == 0 || strcmp(option,"5") == 0)
     {
         sprintf_s(stmt_buf2, sizeof stmt_buf2,"SELECT itag FROM %s:policy WHERE ipolicy = '%s'", tmp_dbname, ipolicy);

         $PREPARE prep1 FROM $stmt_buf2;
         $EXECUTE prep1 INTO $itag;
         $FREE prep1;
     }

     if (iFetch)                 /*�Ĥ@�����W�@���O�ۤv*/
     {   
          strcpy(sPrePolicy,   ipolicy);
          strcpy(sPrePolicy1,  sIpolicy1);
          sDpolicy = dpolicy;
          iFetch = FALSE;
          prem_subtot = prem_subtot0 = mdeduct01 = prem_total = 0;          
          
          strcpy( dpolicy_c , cm_cdate_str_100( dpolicy ));         
          cm_split_ymd_100(dpolicy_c,day_yy,day_mm,day_dd);
          
			if( strcmp(option,"1") == 0 )
			{
				sprintf_s(Tmp1, sizeof Tmp1,"isap%s_%s%s%sc",companyid,day_yy,day_mm,day_dd);
				strcpy(iply_type,"ap");
				strcpy(fcard_class, "1");
			}
			else if ( strcmp(option,"3") == 0 )
			{
				sprintf_s(Tmp1, sizeof Tmp1,"ismp%s_%s%s%s",companyid,day_yy,day_mm,day_dd);
				strcpy(iply_type,"mp");
				strcpy(fcard_class, "1");
			} 
			else
			{
				if ( i == 1)
				{
					sprintf_s(Tmp1, sizeof Tmp1,"isap%s_%s%s%sc",companyid,day_yy,day_mm,day_dd);
				} 
				else 
				{
					sprintf_s(Tmp1, sizeof Tmp1,"ismp%s_%s%s%s",companyid,day_yy,day_mm,day_dd);
				}
			}
        
          sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);
   
          printf("[NOERROR] file0[%s] Tmp1[%s]\n",file0,Tmp1);
          fptr=fopen(file0,"w");
          
          if (strcmp(option,"4") != 0 || strcmp(option,"5") != 0)
          {
             rc = check_if_exist(iply_type,dpolicy,fcard_class,0);
             if ( rc != M_CM_OK )
            	return rc;
          }
     }
     
     if ( sDpolicy != dpolicy ) /* �����ثefile , open a new file*/
     {    	
     	if (cntrlrec > 0)
        {
     	    strcpy(prtstr,"CNTRLREC");
            rfmtlong(cntrlrec,"&&&&&&",cntrlrec_c);
            strcat(prtstr,cntrlrec_c);
            fprintf(fptr, "%s\n", prtstr);
         }

printf("### cntrlrec=[%s]\n",cntrlrec_c);
    	
         fclose(fptr);         
         rtncode = rptftpinsert( userid , "car9971" , Tmp1 );
         
         if (strcmp(option,"4") != 0 && strcmp(option,"5") != 0)
         {
         	$insert into ca_trade_exam
                 	(iply_type,dpolicy,fcard_class,itrans_type,
                  	qcount,mamount,minjure,mcripple,mdeath)
             	values
                 	($iply_type,$sDpolicy,$fcard_class,0,
                  	$cntrlrec,$prem_total,0,0,0);
          }
         
         sprintf_s(strlog, sizeof strlog,"���ɧ���:%s ���:%d",file0,cntrlrec);
         WRITELOG(errfpt , strlog);
     
         printf("errfpt[%s]\n",strlog);
          
         strcpy( dpolicy_c , cm_cdate_str_100( dpolicy ));
          
         cm_split_ymd_100(dpolicy_c,day_yy,day_mm,day_dd);
          
		if( strcmp(option,"1") == 0 )
		{
			sprintf_s(Tmp1, sizeof Tmp1,"isap%s_%s%s%sc",companyid,day_yy,day_mm,day_dd);
			strcpy(iply_type,"ap");
			strcpy(fcard_class, "1");
		}
		else if (strcmp(option,"3") == 0)
		{
			sprintf_s(Tmp1, sizeof Tmp1,"ismp%s_%s%s%s",companyid,day_yy,day_mm,day_dd);
			strcpy(iply_type,"mp");
			strcpy(fcard_class, "1");
		}
		else 
		{
			if ( i == 1)
			{
				sprintf_s(Tmp1, sizeof Tmp1,"isap%s_%s%s%sc",companyid,day_yy,day_mm,day_dd);
			} 
			else
			{
				sprintf_s(Tmp1, sizeof Tmp1,"ismp%s_%s%s%s",companyid,day_yy,day_mm,day_dd);
			}
		}
        
         sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);
   
         printf("[002]file0[%s] Tmp1[%s]\n",file0,Tmp1);
         fptr=fopen(file0,"w");
         
         if (strcmp(option,"4") != 0 && strcmp(option,"5") != 0)
         {
         	rc = check_if_exist(iply_type,dpolicy,fcard_class,0);
         	if ( rc != M_CM_OK )
            		return rc;
         }
         
         cntrlrec = 0;
         prem_total = 0;
     }
          
     if (strcmp(sPrePolicy1, sIpolicy1) != 0 &&
         strlen(trim(sPrePolicy)) == CAR_PLY_TAG_LEN) /*�W�@���O�j�O��*/
     {     	
         /*�`�O�O��ƿ�*/
         prtstr[70] = '\0';
         iTmpbuf = 0;
         strcat(prtstr, sformat_trade(&iTmpbuf, 1, 149));

         /*99�I�ظ�ƤΫO�O*/
         strcat(prtstr,"99");                 /*C220-221:�I��*/
         strcat(prtstr, sformat_trade(&iTmpbuf, 1, 39));
   
         rfmtlong(prem_subtot0,"&&&&&&&&&",prem_subtot_c);
         strcat(prtstr,prem_subtot_c);        /*C261-269:�u�ݫ��`�O�O*/
         strcat(prtstr, sformat_trade(&iTmpbuf, 1, 6));   /* C270-275:�O�v��I�~�� */

         strcat(prtstr, sformat_trade(tmp_yyyy, 2, 4));  
         strcat(prtstr, sformat_trade(dply_mm, 2, 2));  
         strcat(prtstr, sformat_trade(tmp_dd, 2, 2));  
                                                  /*C276-283:ñ��~���*/
                                                  
         if (bzfrom[0] == '\0') strcat(prtstr,"00");
         else strcat(prtstr,bzfrom);           /*C284-285:�O�o�q���N��*/
         /*                                       
         if( strncmp( icar_type, "01", 2) == 0 ||
             strncmp( icar_type, "02", 2) == 0 ||
             strncmp( icar_type, "32", 2) == 0 ||
             strncmp( icar_type, "34", 2) == 0 )
         {
         strcat(prtstr, sformat_trade(&iTmpbuf, 1, 63));  /* C284-343:�q�T�a,C344-346:�l���ϸ� *
         }*/

         cntrlrec++;
         fprintf(fptr, "%s\n", prtstr);
     }
     
     if (strcmp(sPrePolicy1, sIpolicy1) != 0) 
         prem_subtot = prem_subtot0 = mdeduct01 = 0; 

     strcpy(sPrePolicy,      ipolicy);
     strcpy(sPrePolicy1,     sIpolicy1);
     sDpolicy = dpolicy;
   	
     $OPEN scur_ply_ins_a1 USING $ipolicy;

     if ((iRtnCode =
          split_policy(ipolicy, sTmpbuf, objno)) != M_CM_OK) break;
printf("after split[%d]\n",iRtnCode);          

     while(1)
     {
     	$FETCH scur_ply_ins_a1
          INTO $iins_type,$minjured_cover,$mdeath_cover,$mdamage_cover,
               $mdeduct,$mins_premium,$mprem,$drate_ym;

        if (SQLCODE==SQLNOTFOUND) break;

        /*** field 1 ***/
        strcpy(prtstr,"9");                                     /*C1:���ʧO*/
        /*** field 2 ***/        

        strcat(prtstr, companyid);
        strcat(prtstr, sformat_trade(sTmpbuf, 2, 15));
                                                                /*C2-C18*/
        if (fcard_class[0] == '1')
        {
            strcpy(card_str,companyid);
            strcat(card_str,icard);
            strcat(prtstr, sformat_trade(card_str, 2, 17));
        } else {
            card_str[0] = '\0';
            strcat(prtstr, sformat_trade(card_str, 2, 17));
        }
                                                                /*C19-35:�O�I�����X*/

        if (strcmp(trim(ilast_ply),"" ) != 0)
        {
            strcat(prtstr, companyid);
            strcat(prtstr, sformat_trade(ilast_ply, 2, 15));   /* C36 - C52 ��O��*/
        }
        else
            strcat(prtstr, sformat_trade(" ", 2, 17));         /* C36 - C52 */

       /* �N�{��u�a�ϥN�����v���R���N��42�u�x�����v�B�N��63�u�x�n���v�B�N��65�u�������v�C*/
        if( strcmp( iply_area, "42") == 0)
            strcpy( iply_area, "41");
        else if( strcmp( iply_area, "63") == 0)
            strcpy( iply_area, "62");
        else if( strcmp( iply_area, "65") == 0)
            strcpy( iply_area, "64");

        strcat(prtstr, sformat_trade(iply_area, 2, 2));       /* C53 - C54 �ӫO�a�ϥN��*/

        strcpy(dply_begin_c, cm_cdate_str_100(dply_begin));
        cm_split_ymd_100(dply_begin_c,dply_begin_yy,dply_begin_mm,dply_begin_dd);
        strcpy(tmp_yyyy, itoa(1911+atoi(dply_begin_yy)));

        strcat(prtstr, sformat_trade(tmp_yyyy, 2, 4));
        strcat(prtstr, sformat_trade(dply_begin_mm, 2, 2));
        strcat(prtstr, sformat_trade(dply_begin_dd, 2, 2));
                                                             /*C55-62:�O��_��*/

        strcpy(dply_end_c,cm_cdate_str_100(dply_end));
        cm_split_ymd_100(dply_end_c,dply_end_yy,dply_end_mm,dply_end_dd);
        strcpy(tmp_yyyy,itoa(1911+atoi(dply_end_yy)));
        strcat(prtstr, sformat_trade(tmp_yyyy, 2, 4));
        strcat(prtstr, sformat_trade(dply_end_mm, 2, 2));
        strcat(prtstr, sformat_trade(dply_end_dd, 2, 2));
                                                             /*C63-70:�O�樴��*/

        if (strlen(trim(objno)) > 0) strcat(prtstr, sformat_trade(objno, 2, 4));
        else strcat(prtstr, "0001");
                                                             /*C71-74:�O��Ъ���*/

        /*�o�Ӧ~���Τ�����,��iissue_ym�o������,�諾����original_ply.dissure�����쪺�~��
		strncpy(iissue_yy, iissue_ym, 2);
        iissue_yy[2] = '\0';
        strncpy(iissue_mm, iissue_ym+3, 2);
        iissue_mm[2] = '\0';

        strcpy(tmp_yyyy,itoa(1911+atoi(iissue_yy)));*/
        strcat(prtstr, sformat_trade(iissue_yy, 2, 4));
        strcat(prtstr, sformat_trade(iissue_mm, 2, 2));       /*C75-80:�o�Ӧ~��*/

        strcat(prtstr, sformat_trade(ipro_year, 2, 4));                                                   
        strcat(prtstr, sformat_trade(qpro_month_c, 2, 2));   /*C81-86:�s�y�~��*/ /*1120131002_SC1_�j��I��T�@�~���߫O�I��ƶǿ�W�椧�s�y�~����첧�ʮ״���*/
        
        /* �t�P�����N���ഫ modify by sylvia 100.09.30 (car9812112_C1) ----- */
        sIbrand_new[0] = '\0';
        $select first 1 ibrand_new into $sIbrand_new
           from ca_car_model
          where ibrand = $ibrand
            and ibrand_new <> ' '
          order by drate desc;
        
        if (sIbrand_new[0] != '\0')
            strcpy(ibrand, sIbrand_new);
        /* ----------------------------------------------------------------- */
           
        strcat(prtstr, sformat_trade(ibrand, 2, 8));          /*C87-94   �t�P���� */
        strcat(prtstr, sformat_trade(iengine, 2, 25));        /*C95-119  �������X */
        strcat(prtstr, sformat_trade(ibody, 2, 25));          /*C120-144 �������X */

        /* 1061102009_C1 �ק�ǰe���T27���ؾ��񨮵P�W�h
        if (strcmp(icar_type,"27") == 0 && strcmp(chk_dpolicy,"Y") == 0)
            strcpy(itag, " "); */                              /* ����27,���P���X�M�� modify by sylvia 101.02.24 (1001005007_C1) */
            
        strcat(prtstr, sformat_trade(itag, 2, 12));          /*C145-156 �W���P�� */

        strcat(prtstr, sformat_trade(itag, 2, 12));          /*C157-168 �����P�� */

        strcat(prtstr, sformat_trade(icar_type, 2, 2));      /*C169-170:���إN��*/

        iTmpbuf = 10 * qcylinder;
        strcat(prtstr, sformat_trade(&iTmpbuf, 1, 6));       /*C171-176:�Ʈ�q*/
                                                             
        iTmpbuf =  10 * qpt;
        strcat(prtstr, sformat_trade(&iTmpbuf, 1, 4));       /*C177-180:�����ƶq*/
                                                            
        strcat(prtstr, sformat_trade(fpt, 2, 1));            /*C181-181:�������*/
                                                             
        strcat(prtstr, sformat_trade(iassured, 2, 10));      /*C182-191:������*/
                                                             
        /*nassured[120] = '\0';
        nassured_tmp[0] = '\0';
	    strcpy(nassured_tmp,nassured);
        sprintf_s(nassured_tmp, sizeof nassured_tmp,"                                                                                ");*/
        sprintf_s(nassured_tmp, sizeof nassured_tmp,"%-200.200s",rtrim(nassured));
        /*nassured_tmp[200] = '\0';
        strcat(prtstr, sformat_trade(nassured_tmp, 2, 200));*/
        strcat(prtstr, nassured_tmp);                        /*C192-391 �Q�O�I�H�m�W*/

        /*��Q�O�I�H�ͤ�b��Ʈw�̬Ocahr(6),�ӫO���X�W�Q�O�I�H�ͤ������,�諾�����褸�~���,���ݦA�ഫ
		cm_split_ymd_100(ibirth,ibirth_yy,ibirth_mm,tmp_dd);
        birth_yyyy=1911+atoi(ibirth_yy);

        if (birth_yyyy == 1911)
            strcat(prtstr, sformat_trade(" ", 2, 4));
        else strcat(prtstr, sformat_trade(&birth_yyyy, 1, 4));*/
		strcat(prtstr, sformat_trade(ibirth_yy, 2, 4));
        strcat(prtstr, sformat_trade(ibirth_mm, 2, 2));
        strcat(prtstr, sformat_trade(ibirth_dd, 2, 2));      /*C392-399 �Q�O�I�H�X�ͦ~���*/

        strcat(prtstr, sformat_trade(fsex, 2, 1));           /*C400-400 �Q�O�I�H�ʧO*/
        strcat(prtstr, sformat_trade(fmarriage, 2, 1));      /*C401-401 �Q�O�I�H�B�çO*/

        if (fassured[0]=='1'){
            strcat(prtstr,"1");
        }  else if(fassured[0]=='2'){
            strcat(prtstr,"3");
        }  else if(fassured[0]=='3'){
            strcat(prtstr,"2");
        }  else if(fassured[0]=='4'){
            strcat(prtstr,"9");
        }  else if(fassured[0]=='5'){
            strcat(prtstr,"8");
        }  else if(fassured[0]=='6'){
            strcat(prtstr,"9");
        } else strcat(prtstr, " ");
                                                             /*C402-402 �Q�O�I�H�����O*/

        iTmpbuf = atoi(fcomp_class);
        strcat(prtstr, sformat_trade(&iTmpbuf, 1, 2));       /*C403-404:�����ż�*/
                                                             
        strcat(prtstr,"    ");                               /*C405-408:blank*/

        if (strcmp(iins_type, "01")==0 ||
            strcmp(iins_type, "05")==0 ||
            strcmp(iins_type, "08")==0 ||
            strcmp(iins_type, "09")==0)
        {
            ipdmg_align=ipdmg_align*(-1);
            $SELECT icode INTO $icode FROM alignment
              WHERE fclass='4' AND palign=$ipdmg_align;
            if (SQLCODE==SQLNOTFOUND) strcat(prtstr, "0");   /*C409:����h�����u��*/
            else strcat(prtstr, trim(icode));
         } else strcat(prtstr,"0");

         if (strcmp(iins_type, "11")==0)
         {
             ipbrg_align=ipbrg_align*(-1);
             $SELECT icode INTO $icode FROM alignment
               WHERE fclass='4' AND palign=$ipbrg_align;
             if (SQLCODE==SQLNOTFOUND) strcat(prtstr, "0");  /*C410:�ѵs�h�����u��*/
             else strcat(prtstr,trim(icode));
         } else strcat(prtstr, "0");

         if (strcmp(iins_type, "31")==0 || strcmp(iins_type, "32")==0 )
         {
             iplia_align=iplia_align*(-1);
             $SELECT icode INTO $icode FROM alignment
               WHERE fclass='4' AND palign=$iplia_align;
             if (SQLCODE==SQLNOTFOUND) strcat(prtstr, "0");  /*C411:�d���h�����u��*/
             else strcat(prtstr,icode);
         } else strcat(prtstr, "0");

         /*�C���I�ظ�ƤΫO�O*/
         if (iins_type[0] == '\0')
         {  
             strcat(prtstr,"00"); 
         }
         else
         { 
             strcpy(iins_type_rule," ");
             if (strncmp(iins_type,"21",2) == 0)
             {
                 strcpy(iins_type_rule,"21");
             }
             else
             {
                $SELECT iins_type_rule 
                   INTO $iins_type_rule 
                   FROM insurance_type
                  WHERE iins_type = $iins_type;
                  
                  if (SQLCODE == SQLNOTFOUND)
                  { 
                      strcpy(iins_type_rule,iins_type);	
                  }
                  else
                  {
                      if (strlen(trim(iins_type_rule)) == 0)
                          strcpy(iins_type_rule,iins_type);
                  }
             }
             
             strcat(prtstr,iins_type_rule);                  /*C412-413:�I��*/
         }

         rfmtlong(minjured_cover,"&&&&&&&&",minjured_c);
         strcat(prtstr,minjured_c);                          /*C414-421:��˫O�B*/

         rfmtlong(mdeath_cover,"&&&&&&&&",mdeath_c);
         strcat(prtstr,mdeath_c);                            /*C422-429:�ݼo�O�B*/

         rfmtlong(mdeath_cover,"&&&&&&&&",mdeath_c);
         strcat(prtstr,mdeath_c);                            /*C430-437:���`�O�B*/

         rfmtlong(mdamage_cover,"&&&&&&&&",mdamage_c);
         strcat(prtstr,mdamage_c);                           /*C438-445:�O�B*/

         mdeduct = 0;

         rfmtlong(mdeduct,"&&&&&&&",mdeduct_c);
         strcat(prtstr,mdeduct_c);                           /*C446-452:�ۭt�B*/

         rfmtlong(mins_premium,"&&&&&&&&&",mins_premium_c);
         strcat(prtstr,mins_premium_c);                      /*C453-461:�u�ݫ�O�O*/
         
         prem_subtot0 += mins_premium;            /*�u�ݫ�O�O*/
         prem_total += mins_premium;              /*�`�O�O*/

         prem_subtot += mprem;                    /*�u�ݫe�O�O*/

         if (strncmp(iins_type,"21",2) == 0)
         {
             $SELECT drate INTO $drate
                FROM ca_rate_date
               WHERE icode=$drate_ym
                 AND itable='compulsory_premium';
         }

         if (SQLCODE == SQLNOTFOUND || drate[0] == '\0')
         {
                sprintf_s(errmsg, sizeof errmsg,"drate_ym[%s] not found in rate\n",drate_ym);
                fprintf(errfpt,"%s\n",errmsg);
                continue;
         }

         strcpy(drate_c,cm_from_infdate(drate));
         cm_split_ymd_100(drate_c,drate_yy,drate_mm,drate_dd);
         if (drate_yy[0] == '\0') strcat(prtstr,"0000");
         else {
             yy_long=1911+atoi(drate_yy);
             strcpy(tmp_yyyy,itoa(yy_long));
             strcat(prtstr,tmp_yyyy);  /*�褸�~*/
         }

         if (drate_mm[0] == '\0') strcat(prtstr,"00");
         else strcat(prtstr,drate_mm);                       /*C462-467:�O�v�~��*/

         strcpy(dpolicy_c,cm_cdate_str_100(dpolicy));
         cm_split_ymd_100(dpolicy_c,dply_yy,dply_mm,tmp_dd);
         if(dply_yy[0] == '\0') strcat(prtstr,"0000");
         else{
           yy_long=1911+atoi(dply_yy);
           strcpy(tmp_yyyy,itoa(yy_long));
           strcat(prtstr,tmp_yyyy);  /*�褸�~*/
         }
         if(dply_mm[0] == '\0') strcat(prtstr,"00");
         else strcat(prtstr,dply_mm);
         if(tmp_dd[0] == '\0') strcat(prtstr,"00");
         else strcat(prtstr,tmp_dd);                         /*C468-475:ñ��~���*/

	/*
         if( strncmp( icar_type, "01", 2) == 0 ||
             strncmp( icar_type, "02", 2) == 0 ||
             strncmp( icar_type, "32", 2) == 0 ||
             strncmp( icar_type, "34", 2) == 0 )
         {
             /* �O�o�q���ۧY��(6/10)�_�A����ǰe�����ӫO��Ƥ��q�T�a�}(�t�l���ϸ�) *
             strcpy( apayment, " ");
             strcpy( apayment_zip, " ");
             strcat(prtstr, sformat_trade(apayment, 2, 60));    /*C284-343:�q�T�a�} *
             strcat(prtstr, sformat_trade(apayment_zip, 2, 3)); /*C344-346:�l���ϸ� *
         }*/
         
         if (bzfrom[0] == '\0') strcat(prtstr,"00");
         else strcat(prtstr,bzfrom);                         /*C476-477:�O�o�q���N��*/
         
         fprintf(fptr, "%s\n", prtstr);
         cntrlrec++;

        }/* end of while that FETCH scur_ply_ins_a1 */	
    
        sprintf_s(stmt, sizeof stmt,"%s %s %s" ,
                      "UPDATE compulsory_card ",
                      "   SET dtrans = ? ",
                      " WHERE icard  = ?");
         printf("SQL stmt----->[%s]\n",stmt);
         $PREPARE stmt1 FROM  $stmt;
         $EXECUTE stmt1 USING $Today,$icard; 
         
         /* 106.05.12 fix: �s�W itrans_trade */
         /* 1050803001 _C1 �ӽзs�W�ܺ��I�j���I�Y�ɶǿ�@�~ */
         /* �Y�� "���T�Y�ɶǿ��"�A���^���ǿ��� */
         if (ftrans_trade[0]=='1')
         {
	         sprintf_s(stmt, sizeof stmt, "UPDATE %s:ori_ply_relation SET dtrans_trade = current,itrans_trade = 'car9971' WHERE ipolicy  = ?" , tmp_dbname);
	         $PREPARE stmt_trade  FROM  $stmt;
	         $EXECUTE stmt_trade  USING $ipolicy;    

	         sprintf_s(stmt, sizeof stmt, "UPDATE %s:ply_relation     SET dtrans_trade = current,itrans_trade = 'car9971' WHERE ipolicy  = ?" , tmp_dbname);
	         $PREPARE stmt_trade1 FROM  $stmt;
	         $EXECUTE stmt_trade1 USING $ipolicy;    	         
         }
   	
   }  /* end of while that FETCH scur_car9971 */
   
   
   if (cntrlrec > 0 && strlen(trim(sPrePolicy)) == CAR_PLY_TAG_LEN) 
                                                        /*DB���̫�@���O�j�O��*/
   {    
        /*�`�O�O��ƿ�*/
        prtstr[70] = '\0';
        iTmpbuf = 0;
        strcat(prtstr, sformat_trade(&iTmpbuf, 1, 165));

        /*99�I�ظ�ƤΫO�O*/
        strcat(prtstr,"99");                            /*C220-221:�I��*/
        strcat(prtstr, sformat_trade(&iTmpbuf, 1, 39));

        rfmtlong(prem_subtot0,"&&&&&&&&&",prem_subtot_c);
        strcat(prtstr,prem_subtot_c);                   /* C261-269:�u�ݫ��`�O�O */
        strcat(prtstr, sformat_trade(&iTmpbuf, 1, 6));  /* C270-275:�O�v��I�~�� */

        strcat(prtstr, sformat_trade(tmp_yyyy, 2, 4));  
        strcat(prtstr, sformat_trade(dply_mm, 2, 2));  
        strcat(prtstr, sformat_trade(tmp_dd, 2, 2));  
                                                         /* C276-283:ñ��~��� */
        /* if( strncmp( icar_type, "01", 2) == 0 ||
             strncmp( icar_type, "02", 2) == 0 ||
             strncmp( icar_type, "32", 2) == 0 ||
             strncmp( icar_type, "34", 2) == 0 )
         {
        strcat(prtstr, sformat_trade(&iTmpbuf, 1, 63));  /* C284-343:�q�T�a,C344-346:�l���ϸ� *
         }*/
         
        if (bzfrom[0] == '\0') strcat(prtstr,"00");
        else strcat(prtstr,bzfrom);           /*C284-285:�O�o�q���N��*/
        
        printf("-------->LEN [%d]\n", strlen(prtstr));

        cntrlrec++;
        fprintf(fptr, "%s\n", prtstr);

        prem_subtot = prem_subtot0 = mdeduct01 = 0; 
   
   }
 
   $CLOSE scur_car9971;
   $FREE  scur_car9971;
   
   if (cntrlrec > 0)
   {
     	strcpy(prtstr,"CNTRLREC");
        rfmtlong(cntrlrec,"&&&&&&",cntrlrec_c);
        strcat(prtstr,cntrlrec_c);
        fprintf(fptr, "%s\n", prtstr);
   }
   else if ( cntrlrec == 0 )
   {
   	rstrdate( dbgn1 , &dpolicy);
   	
   	strcpy( dpolicy_c , cm_cdate_str_100( dpolicy ));
          
        cm_split_ymd_100(dpolicy_c,day_yy,day_mm,day_dd);
          
        if( strcmp(option,"1") == 0 )
        {
   	   sprintf_s(Tmp1, sizeof Tmp1,"isap%s_%s%s%sc",companyid,day_yy,day_mm,day_dd);
   	   strcpy(iply_type,"ap");
   	   strcpy(fcard_class, "1");
        }
        else if (strcmp(option,"3") == 0)
        {
   	   sprintf_s(Tmp1, sizeof Tmp1,"ismp%s_%s%s%s",companyid,day_yy,day_mm,day_dd);
   	   strcpy(iply_type,"mp");
   	   strcpy(fcard_class, "1");
        } else
        {
           if ( i == 1)
            {
            	sprintf_s(Tmp1, sizeof Tmp1,"isap%s_%s%s%sc",companyid,day_yy,day_mm,day_dd);
            } else {
            	sprintf_s(Tmp1, sizeof Tmp1,"ismp%s_%s%s%s",companyid,day_yy,day_mm,day_dd);
            }
	      }
        

        sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);
   
        printf("[NODATA] file0[%s] Tmp1[%s]\n",file0,Tmp1);
        fptr=fopen(file0,"w");
   	
        strcpy(prtstr,"CNTRLREC");
        rfmtlong(0,"&&&&&&",cntrlrec_c);
        strcat(prtstr,cntrlrec_c);
        fprintf(fptr, "%s\n", prtstr);
     
        cntrlrec = prem_total = 0;
   	 	
   }

     printf("### cntrlrec=[%s]\n",cntrlrec_c);  	
    	
     fclose(fptr);
     
     rtncode = rptftpinsert( userid , "car9971" , Tmp1 );
     
     printf("qcount[%d] dpolicy[%d]\n",qcount,dpolicy);
     
     if (strcmp(option,"4") != 0 && strcmp(option,"5") != 0)
     {
     	    $insert into ca_trade_exam
                 (iply_type,dpolicy,fcard_class,itrans_type,
                  qcount,mamount,minjure,mcripple,mdeath)
             values
                 ($iply_type,$dpolicy,$fcard_class,0,
                  $cntrlrec,$prem_total,0,0,0);
     }
     
     sprintf_s(strlog, sizeof strlog,"���ɧ���:%s ���:%d",file0,cntrlrec);
     WRITELOG(errfpt , strlog);
     
     printf("errfpt[%s]\n",strlog);
}     
     if (errfpt!=NULL) ENDLOG(errfpt); 
    
     return M_CM_OK;	
	
	
errexit:
    printf("car9971_comp:sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    rc = SQLCODE;
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return rc;	
	
}

char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  char sTmp_db_name[21];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
  }
  return sTmp_db_name;
}

long check_if_exist( iply_type, dpolicy, fcard_class, trans_type )
$char *iply_type;
$int dpolicy;
$char *fcard_class;
$int trans_type;
{
   
   $long trade_count=0, err_count=0, out_count=0;
   
   printf("iply_type[%s] dpolicy[%d]\n",iply_type,dpolicy);
   printf("fcard_class[%s] trans_type[%d]\n",fcard_class,trans_type);
   
   
   $SELECT qtradevan, qerr, qout
      INTO $trade_count, $err_count, $out_count
      FROM ca_trade_exam 
     WHERE iply_type = $iply_type
       AND dpolicy = $dpolicy
       AND fcard_class = $fcard_class 
       AND itrans_type = $trans_type;
  
    if ( SQLCODE == SQLNOTFOUND )  return M_CM_OK;	
    
   printf("trade_count[%d] [%d] [%d]\n",trade_count,err_count,out_count);
   
        
   if ( trade_count==0 && err_count==0 && out_count==0 )
   {
       
       $DELETE FROM ca_trade_exam 
         WHERE iply_type = $iply_type
           AND dpolicy = $dpolicy
           AND fcard_class = $fcard_class 
           AND itrans_type = $trans_type;
           
        return M_CM_OK;	
   
   }
   
   strcpy(sqlca.sqlerrm ,"�L�k���J�s�C - �b UNIQUE INDEX ��즳���Э�");
   
   return 239;
   
errexit:
    printf("check_if_exist:sqlcode=%d, sqlmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    rc = SQLCODE;
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return rc;	
   
}
