/**********************************************************************/
/*   program id   : ca215p02s.ec                                      */
/*   program name : �����ʲz�j���Ҥ��i�@�o����E-Mail�q��(�޲z�H)      */
/*   date written : 2014/06/23                                        */
/*   date modify  : yyyy/mm/dd                                        */
/*   author       : Larry Liao                                        */
/*   shell        : car2152_email                                     */
/**********************************************************************/

#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include "print.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "othmsgs.h"
#include "commsgs.h"
#include "sqlfatal.h"
#include "safeclib.h"

/******************************************************************************/
$char  	DBName[5],outputf[ N_FILE+1];
$char  	userid[11],sDdate[11],smail[41];
char  	ddate[11],syy[4],smm[3],sdd[3],sdate[11];   
int     flen,i;
FILE    *fp;
char    sApHome[30],msgbuf[512];
$char   fname[128],filename[121],ftitle[1024],nsubject[512],nattachment[100];
$char	  mmsg[1024],tbuf[501],mbuf[9000];
$loc_t 	ctxt;

$char	pre_ileader[11],sNleader[11];
$char	pre_ilast_alter[11],sNlast_alter[11];
$int 	mail_count;
$long	dsys;

$char	icard[21],iofficer[11],nofficer[11];
$char ileader[11],nleader[11],dentry[11];
$char ilast_alter[11],dlast_alter[11],nlast_alter[11];

/* asempl */
$char	email[51],chinese_name[15];
/******************************************************************************/
main(argc, argv)
int argc;
char **argv;
{
    int rc;
      
    batchinit();
    strcpy(DBName,  isNULLstr(argv[1]));
    strcpy(userid,  isNULLstr(argv[2]));
    strcpy(ddate,   isNULLstr(argv[3])); /* cyy/mm/dd */
    strcpy(outputf, isNULLstr(argv[4]));
    
    strcpy(sDdate,cm_to_infdate(ddate));
    printf("-----��� : [%s]\n-----",sDdate);

    rc = car2152_get_db();
    if (rc != M_CM_OK) {
        printf("error on car3013_get_db\n");
        return rc;
    }
    
    /* �� temp table */        
    rc = car2152_init_data();
    if (rc != M_CM_OK) {
        printf("error on car2152_init_data\n");
        return rc;
    }
        
    /* �d�߱j���Ҹ����A���i�@�o���� */        
    rc = car2152_query_detail();
    if (rc != M_CM_OK) {
        printf("error on car2152_query_status\n");
        EWRITE(userid, rc, "�d�ߤ��i�@�o���Ӧ��~!");
        return rc;
    }

    /* �H�e�j���Ҹ����i�@�o����Mail�q�����޲z�H */
    rc = car2152_send_email_ileader(); 
    if (rc != M_CM_OK) {
        printf("error on car2152_send_email_ileader\n");
        EWRITE(userid, rc, "�H�oMail�q���޲z�H���~!");
        return rc;
    }
    
     /* �H�e�j���Ҹ����i�@�o����Mail�q�����e���ʤH�� */
    rc = car2152_send_email_ilast_alter(); 
    if (rc != M_CM_OK) {
        printf("error on car2152_send_email_ilast_alter\n");
        EWRITE(userid, rc, "�H�oMail�q�����ʤH�����~!");
        return rc;
    }
    
    /* ���s�j���Ҹ����i�@�o���ӳ��� */
    rc = car2152_print_detail();
    if (rc != M_CM_OK) {
        printf("error on car2152_print_detail\n");
        EWRITE(userid, rc, "�����M�沣�s���~!");
        return rc;
    }
    
    printf("[car2152]:process ok!\n"); 
}
/******************************************************************************/
long car2152_get_db()
{
    int	rc;
    
    $WHENEVER SQLERROR GOTO errexit;
    
    if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "��Ʈw�L�k�}��!");
       return M_CM_DB_NOTOPEN;
    }
    
    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }
           
    return M_CM_OK;
    
errexit:
   printf("--car2152_get_db-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/******************************************************************************/
long car2152_init_data()
{
    $WHENEVER SQLERROR GOTO errexit;

    $create temp table car2152_tmp(
		   icard           char(20),  /* �j���Ҹ� */
		   dentry          date,      /* �����ʲz����J��� */
       iofficer        char(10),  /* �g��N�� */
       nofficer        char(10),  /* �g��N������*/
       ileader         char(10),  /* �޲z�H�N�� */
       nleader         char(10),  /* �޲z�H�N������ */
       ilast_alter     char(10),  /* �e���ʤH���N�� */   
       nlast_alter     char(10),  /* �e���ʤH������ */
       dlast_alter     date       /* �e���ʤ�� */ 
     )with no log;

		printf("-----cdate = [%s]-----\n",ddate);
    dsys = cm_ymd_cdate(ddate);
    cm_char_split_3ymd(ddate,syy,smm,sdd);
    sprintf_s(sdate, sizeof sdate,"%s%s%s",syy,smm,sdd);

    /* ���Y */
    strcpy(ftitle,
           "�j���Ҹ�,�g��N��,�g��N������,�޲z�H����,�����ʲz����J���,�@�o���,�@�o�H��\n");
    
    /* �D�� */
    sprintf_s(nsubject, sizeof nsubject,"�j���Ҥ��o�@�o�����(%s/%s/%s)",syy,smm,sdd);
	
    return M_CM_OK;

errexit:
   printf("--car2152_init_data-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/******************************************************************************/
long car2152_query_detail()
{
   int	 rc;
   $char sStmt[4096];
   
   $WHENEVER SQLERROR GOTO errexit;
     	 
   sprintf_s(sStmt, sizeof sStmt,
           "INSERT INTO car2152_tmp     "
	         "SELECT b.icard, b.dentry, a.ideliver, "
	         " (SELECT nname FROM officer WHERE iofficer = a.ideliver),"
	         " (SELECT ileader FROM officer WHERE iofficer = a.ideliver),"
	         " (SELECT d.nname FROM officer c,officer d "
	         "   WHERE c.ileader = d.iofficer AND c.iofficer = a.ideliver),"
	         "  b.ilast_alter,(SELECT nname FROM officer WHERE iofficer = b.ilast_alter),"
	         "  b.dlast_alter "
           "  FROM compulsory_card a, ca_card_road b "
           " WHERE a.icard = b.icard "
           "   AND trim(b.flast_status) != '' "
           "   AND date(b.dcreate) = '%s' ", sDdate);
	  
	  printf("stmt[%s]\n",sStmt);
	  $prepare pre_card from $sStmt;
	  $execute pre_card;
	  	
	  return M_CM_OK;
  
errexit:
   printf("--car2152_query_detail-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/******************************************************************************/
long car2152_send_email_ileader()
{
	  int	rc;
	  $char sStmt[1024];
   
    $WHENEVER SQLERROR GOTO errexit;
	 
	  strcpy(sStmt,"SELECT icard, iofficer, nofficer, nleader, "
	               "       year(dentry)-1911||to_char(dentry,'/%m/%d'),"
	               "       year(dlast_alter)-1911||to_char(dlast_alter,'/%m/%d'),"
	               "       nlast_alter "
                 "   FROM car2152_tmp     "
				         "  WHERE ileader = ? "
                 "  ORDER BY icard ");
    printf("stmt[%s]\n",sStmt);
    $PREPARE pre_data from $sStmt;
    $DECLARE cur_data CURSOR FOR pre_data;
	
    $DECLARE cur_temp CURSOR FOR
      SELECT DISTINCT ileader
				INTO $ileader
				FROM car2152_tmp
       ORDER BY ileader;
    $OPEN  cur_temp;
    $FETCH cur_temp;
    strcpy(pre_ileader,ileader);
    
    mail_count=0;
    for(;;) 
    {
			if (SQLCODE==SQLNOTFOUND) break;

			if (strcmp(ileader,pre_ileader)!=0) 
			{
	    	rc = car2152_write_email_ileader();
	    	if (rc != M_CM_OK) {
					printf("error on car2152_write_email_ileader\n");
					return rc;
	    	}
	    	mail_count=0;
			}
			strcpy(pre_ileader,ileader);
	
			mail_count++;
			printf("---ileader:[%s]---\n",ileader);
			memset(fname,0x00,sizeof(fname));
			memset(filename,0x00,sizeof(filename));
			sprintf_s(fname, sizeof fname,"%s_�j���Ҥ��o�@�o����_%s",sdate,trim(ileader));
			sprintf_s(filename, sizeof filename,"%s/rptftp/car_email/%s.csv",sApHome,fname);
			sprintf_s(nattachment, sizeof nattachment,"%s.csv",fname);
			printf("----filename[%s]----\n",filename);
			fp=fopen(filename,"w");
		
			fprintf(fp,ftitle);
			
			$OPEN cur_data USING $ileader;
	
			for(;;)
		  {
		    $FETCH cur_data INTO $icard, $iofficer, $nofficer, $nleader, $dentry,
		                         $dlast_alter, $nlast_alter;
	                           
		    if (SQLCODE==SQLNOTFOUND) break;
		   	
		    fprintf(fp,"%s,%s,%s,%s,%s,%s,%s\n",
		            icard, iofficer, nofficer, nleader, dentry, dlast_alter, nlast_alter);
			}
			$CLOSE cur_data;
			fclose(fp);
			$FETCH cur_temp;
		}
    $FREE  cur_data;
    $CLOSE cur_temp;
    $FREE  cur_temp;
	    
    if (mail_count!=0) {
        rc = car2152_write_email_ileader();
        if (rc!=M_CM_OK) {
			    printf("error on car2152_write_email_ileader\n");
			    return rc;
				}
    }
           
    return M_CM_OK;
  
errexit:
    printf("--car2152_send_email_ileader-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car2152_write_email_ileader()
{
    $whenever sqlerror goto errexit;
    
    $SELECT nname
       INTO $sNleader
       FROM officer
      WHERE iofficer = $pre_ileader;
    if (SQLCODE==SQLNOTFOUND) strcpy(sNleader,"�P��");
    
    strcpy(sNleader,trim(sNleader));
    /* email��� */
    sprintf_s(mmsg, sizeof mmsg,
	  "�˷R�� %s,�z�n</P>\n\n"
	  "�q���z�A���󤤱z�ҧ@�o�j���ҬO�ݩ�g�����ʲz�H����J�t�Τ��j���ҡA���o�@�o�C</P>\n"
	  "����������ӧ@�o�j���Ҥw�۰��ন���X��,�гt���g��/�޲z�H������X��@�~�C</P>\n"
	  "�p��������D�Ь��ӤH�O�I���~�Ȧ�F��C</P>\n\n"
	  "����!</P>\n",sNleader);

    strcpy(mbuf,rtrim(mmsg));
    ctxt.loc_loctype = LOCMEMORY;
    ctxt.loc_buffer = mbuf;
    ctxt.loc_bufsize = 9000;
    ctxt.loc_size =  strlen(mbuf) + 1;

    strcpy(email," ");
    $select email,chinese_name
       into $email,$chinese_name
       from personal:asempl
      where empl_no = $pre_ileader;

    strcpy(email,trim(email));
    if (strlen(email) != 0){ 
    	
      strcpy(email,trim(email));
      strcat(email,"@tmnewa.com.tw");
      printf("-----email:[%s]-----\n",email);
		
      $INSERT INTO batchemail
		  (project_id, mail_date, receiver_email,
		   receiver_name, cc, content, key, mail_count,nsubject,nattachment)
       VALUES
		  ("CAR2152", today+1, $email, $chinese_name,
			 " ", $ctxt, $fname, $mail_count, $nsubject, $nattachment);
    }
    
    return M_CM_OK;
  
errexit:
   printf("--car2152_write_email_ileader-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/******************************************************************************/
long car2152_send_email_ilast_alter()
{
	  int	rc;
	  $char sStmt[1024];
   
    $WHENEVER SQLERROR GOTO errexit;
	 
	  strcpy(sStmt,"SELECT icard, iofficer, nofficer, nleader, "
	               "       year(dentry)-1911||to_char(dentry,'/%m/%d'),"
	               "       year(dlast_alter)-1911||to_char(dlast_alter,'/%m/%d'),"
	               "       nlast_alter "
                 "   FROM car2152_tmp     "
				         "  WHERE ilast_alter = ? "
                 "  ORDER BY icard ");
    printf("stmt[%s]\n",sStmt);
    $PREPARE pre_data1 from $sStmt;
    $DECLARE cur_data1 CURSOR FOR pre_data1;
	
    $DECLARE cur_temp1 CURSOR FOR
      SELECT DISTINCT ilast_alter
				INTO $ilast_alter
				FROM car2152_tmp
       ORDER BY ilast_alter;
    $OPEN  cur_temp1;
    $FETCH cur_temp1;
    strcpy(pre_ilast_alter,ilast_alter);
    
    mail_count=0;
    for(;;) 
    {
			if (SQLCODE==SQLNOTFOUND) break;

			if (strcmp(ilast_alter,pre_ilast_alter)!=0) 
			{
	    	rc = car2152_write_email_ilast_alter();
	    	if (rc != M_CM_OK) {
					printf("error on car2152_write_email_ilast_alter\n");
					return rc;
	    	}
	    	mail_count=0;
			}
			strcpy(pre_ilast_alter,ilast_alter);
	
			mail_count++;
			printf("---ilast_alter:[%s]---\n",ilast_alter);
			memset(fname,0x00,sizeof(fname));
			memset(filename,0x00,sizeof(filename));
			sprintf_s(fname, sizeof fname,"%s_�j���Ҥ��o�@�o����_%s",sdate,trim(ilast_alter));
			sprintf_s(filename, sizeof filename,"%s/rptftp/car_email/%s.csv",sApHome,fname);
			sprintf_s(nattachment, sizeof nattachment,"%s.csv",fname);
			printf("----filename[%s]----\n",filename);
			fp=fopen(filename,"w");
		
			fprintf(fp,ftitle);
			
			$OPEN cur_data1 USING $ilast_alter;
	
			for(;;)
		  {
		    $FETCH cur_data1 INTO $icard, $iofficer, $nofficer, $nleader, $dentry,
		                          $dlast_alter, $nlast_alter;
	                           
		    if (SQLCODE==SQLNOTFOUND) break;
		   	
		    fprintf(fp,"%s,%s,%s,%s,%s,%s,%s\n",
		            icard, iofficer, nofficer, nleader, dentry, dlast_alter, nlast_alter);
			}
			$CLOSE cur_data1;
			fclose(fp);
			$FETCH cur_temp1;
		}
    $FREE  cur_data1;
    $CLOSE cur_temp1;
    $FREE  cur_temp1;
	    
    if (mail_count!=0) {
        rc = car2152_write_email_ilast_alter();
        if (rc!=M_CM_OK) {
			    printf("error on car2152_write_email_ilast_alter\n");
			    return rc;
				}
    }
           
    return M_CM_OK;
  
errexit:
    printf("--car2152_send_email_ilast_alter-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car2152_write_email_ilast_alter()
{
    $whenever sqlerror goto errexit;
    
    $SELECT nname
       INTO $sNlast_alter
       FROM officer
      WHERE iofficer = $pre_ilast_alter;
    if (SQLCODE==SQLNOTFOUND) strcpy(sNlast_alter,"�P��");
    
    strcpy(sNlast_alter,trim(sNlast_alter));
    /* email��� */
    sprintf_s(mmsg, sizeof mmsg,
	  "�˷R�� %s,�z�n</P>\n\n"
	  "�q���z�A���󤤱z�ҧ@�o�j���ҬO�ݩ�g�����ʲz�H����J�t�Τ��j���ҡA���o�@�o�C</P>\n"
	  "����������ӧ@�o�j���Ҥw�۰��ন���X��,�гt���g��/�޲z�H������X��@�~�C</P>\n"
	  "�p��������D�Ь��ӤH�O�I���~�Ȧ�F��C</P>\n\n"
	  "����!</P>\n",sNlast_alter);

    strcpy(mbuf,rtrim(mmsg));
    ctxt.loc_loctype = LOCMEMORY;
    ctxt.loc_buffer = mbuf;
    ctxt.loc_bufsize = 9000;
    ctxt.loc_size =  strlen(mbuf) + 1;

    strcpy(email," ");
    $select email,chinese_name
       into $email,$chinese_name
       from personal:asempl
      where empl_no = $pre_ilast_alter;

    strcpy(email,trim(email));
    if (strlen(email) != 0){ 
    	
      strcpy(email,trim(email));
      strcat(email,"@tmnewa.com.tw");
      printf("-----email:[%s]-----\n",email);
		
      $INSERT INTO batchemail
		  (project_id, mail_date, receiver_email,
		   receiver_name, cc, content, key, mail_count,nsubject,nattachment)
       VALUES
		  ("CAR2152", today+1, $email, $chinese_name,
			 " ", $ctxt, $fname, $mail_count, $nsubject, $nattachment);
    }
    
    return M_CM_OK;
  
errexit:
   printf("--car2152_write_email_ilast_alter-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/******************************************************************************/
long car2152_print_detail()
{
    int     rc;
    char    sfilename[100],stitle[1024],stmt[1024];

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(sfilename,"�j���Ҹ����i�@�o����(E-Mail�q��)");
    strcpy(stitle,"�{���N��:CAR2152\t");
    strcat(stitle,sfilename);
    strcat(stitle,"\t\t\t\t\t\t\t\t\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");
    strcat(sfilename,"[CAR2152]");

    strcat(stitle,"\t�j���Ҹ�\t�g��N��\t�g��N������\t�޲z�H����\t");
    strcat(stitle,"�����ʲz����J���\t�@�o���\t�@�o�H��\t");

    strcpy(stmt,"SELECT icard, iofficer, nofficer, nleader,"
                "       year(dentry)-1911||to_char(dentry,'/%m/%d'), "
                "       year(dlast_alter)-1911||to_char(dlast_alter,'/%m/%d'),"
                "       nlast_alter "
                "   FROM car2152_tmp "
                "  ORDER BY icard ");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);

    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;
    
errexit:
   printf("--car2152_print_detail-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}
/******************************************************************************/