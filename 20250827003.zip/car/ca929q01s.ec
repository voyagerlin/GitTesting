/**********************************************************************/
/*   program id   : ca929q01s.ec                                      */
/*   program name : �j���I�F�d�վ���Ӫ�                              */
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <time.h>
#include <math.h>
#include "api_xsrv.h"
$include datetime.h;
#include "carmsgs.h"

/*--------------------------------------------------------------------*/
$char   userid[11];
char    msgbuf[1000],sApHome[30];
$char   DBName[5],stmt[7000];
char    outputf[N_FILE+1] ;
DBinfo  *list;
int     count_db;
char  sfilename[128],stitle[2048];

char  sWk1[2], sRpt1[2], sDate1[11], sDate2[11], sDbgn[11], sDend[11],
      txtfile[101];
$char rptdate1[8];

/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
    int rc;
    batchinit();
    strcpy(DBName,  isNULLstr(argv[1]));
    strcpy(userid,  isNULLstr(argv[2]));
    strcpy(sRpt1,   isNULLstr(argv[3]));         /* �������� 1:����� 2:����� 3:�w���ɥ��鵲 */
    strcpy(sDate1,  isNULLstr(argv[4]));         /* �d�߰_�� */
    strcpy(sDate2,  isNULLstr(argv[5]));         /* �d�ߨ��� */
    strcpy(outputf, isNULLstr(argv[6]));

    printf("sRpt1=[%s]sDate1=[%s]sDate2=[%s]\n",sRpt1, sDate1,sDate2);

		strcpy(sDbgn,cm_to_infdate(sDate1));
    strcpy(sDend,cm_to_infdate(sDate2));

    printf("1.car929_get_db() \n");
    rc = car929_get_db();
    if (rc != M_CM_OK) {
        printf("error on car929_get_db\n");
        EWRITE(userid, rc, "error on car929_get_db");
        return rc;
    }

    printf("2.ca929_build1() \n");
    if (strcmp(sRpt1, "1") == 0)
	{
	   	rc=ca929_build_D();	/* ��� */
	}
	else if (strcmp(sRpt1, "2") == 0)
	{
	   	rc=ca929_build_M();	/* ��� */
	}
	else if (strcmp(sRpt1, "3") == 0)
	{
	   	rc=ca929_build_A();	/* �w���ɥ��鵲 */
	}
	else
	{
	   	rc = M_CM_NOT_FOUND;
	}

	if (rc != M_CM_OK) {
	        printf("error on ca929_build1\n");
	        return rc;
	}

	printf("3.car929_report_init() \n");
	rc = car929_report_init();
	if (rc != M_CM_OK) {
	    EWRITE(userid, rc, "error on car929_report_init");
	    return rc;
    }

	rc=car929_print();
	if (rc != M_CM_OK) {
	    printf("error on car929_print\n");
	    return rc;
    }

	rc=car929_gen_files();
	if (rc != M_CM_OK) {
	    printf("error on car929_print\n");
	    return rc;
    }
   	return rc;
}

/*--------------------------------------------------------------------*/
long car929_get_db()
{
    int	rc;

    if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
    }

    if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
    {
        EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
        return M_CM_NOT_DBLIST;
    }

    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }

    $create temp table ca929d1
    (
	  icard						char(20), 			-- �d��
	  itag						char(12),  			-- ����
	  iverify					char(20),			-- �d�ҽs��
      iclaim					char(20), 			-- �߮׸�
      iclose_type			    int,				-- �ߥI����
      qduty_adjuster	        int,				-- �����F�d�ʤ���,
      car_cnt					int,				-- �ƬG������
      daccident				    datetime year TO minute   -- �X�I��
    )with no log;

	$create temp table ca929rptd
	(
	    icompany					char(2),		-- �O�I���q
	    icard						char(20), 		-- �O�I�Ҹ�
    	 itag						char(12), 		-- ���P���X
    	 nassured					varchar(20), 	-- ���`�H�m�W
    	 ivictim					char(10), 		-- ���`�H�����Ҹ�
         dvictim					date, 			-- �X�ͦ~���
         mins_stl					int, 			-- �z�ߪ��B
         daccident				    datetime year to minute,	-- �F�Ƥ��
         fvictim_car			    char(1),		-- ���`�H�O
         qduty_adjuster		        int,			-- �����F�d��
         qduty_adjuster2	        int, 			-- ��y�F�d��
         qduty_adjuster3	        int, 			-- ��L�F�d��
         itag2						char(12),  		-- ��y���P
         oth_company			    char(2), 		-- ��y���q
         oth_card 				    char(21),		-- ��y�O�I�Ҹ�
         rpt_bgn					date,			-- ��ư_��
         rpt_end					date,			-- ��ƨ���
         iclaim						char(20),	    -- �߮׸�
         iclose_type			    int,			-- �ߥI����
         icar_cnt					int				-- �ƬG������
	)with no log;

	$create temp table ca929m1
	(
		iclaim						char(20), 		    -- �߮׸�
		iclose_type				    int, 			    -- �ߥI����
		icard						char(20), 		    -- �d��
        fvictim_nation		        char(1), 			-- �Q�O�I�H�����N��
        icar_type					char(2), 			-- ���إN��
        qpt							decimal(4,1),	    -- �����ƶq
        fpt							char(1), 			-- �������
        itag						char(12), 		    -- ���P���X
        daccident					datetime year to minute, 	-- �X�I�ɶ�
        iacc_reason				    char(2),			-- �X�I��]�N�X
        iacc_area					char(2), 			-- �X�I�a�ϥN�X
        iverify						char(20), 		    -- �d�Ҹ�
        qduty_adjuster		        int,				-- �����F�d�ʤ���
        car_cnt 					int					-- �ƬG������
	)with no log;

	$create temp table ca929rptm
	(
		icompany					char(2),			-- 1 �O�I���q
		iclaim						char(20),			-- 2 �߮׸�
		icard						char(20),			-- 3 �O�I�Ҹ�
		fvictim_nation		        char(1),			-- 4 �Q�H�H�����N��
		icar_type					char(2),			-- 5 ���إN��
    	qpt							decimal(4,1),	    -- 6 �����ƶq
    	fpt							char(1),			-- 7 �������
    	itag						char(12),			-- 8 ���P���X
    	daccident					datetime year to minute,		-- 9 �X�I���
    	iacc_reason				    char(2),			-- 10 �X�I��]�N��
    	iacc_area					char(2),			-- 11 �X�I�a�ϥN��
    	nassured					char(20),			-- 12 ���`�H�m�W
    	ivictim						char(10),			-- 13 ���`�H�����Ҹ�
    	dvictim						date,				-- 14 ���`�H�ͤ�
    	iins_item					char(6),			-- 15 ���I���O�ζ���(A���� B���` C����)
    	mins_stl					int,				-- 16 �z�ߪ��B
    	fvictim_car				    char(1),			-- 17 ���`�H�O
        qduty_adjuster		        int,				-- 18 �����F�d�ʤ���
        qduty_adjuster2		        int,				-- 19 ��y���F�d�ʤ���
        qduty_adjuster3		        int,				-- 20 ��L�F�d�ʤ���
        itag2						char(12),			-- 21 ��y���P���X
        oth_company				    char(2),			-- 22 ��y���q�N�X
        oth_card					char(21),			-- 23 ��y�O�I�Ҹ�
        mprem						int,				-- 24 ���u���B
        rpt_bgn					    date,				-- 25 ��ư_��
        rpt_end					    date,				-- 26 ��ƨ���
        iclose_type				    int,				-- 27 �ߥI����
        icar_cnt					int					-- 28 �߮ר�����
	) with no log;

	$create temp table ca929a1
	(
		idate_ym	char(6), 		-- 1 ��Ʀ~��
		icompany	char(2), 		-- 2 �߮פ��q
		iclaim_p	char(20),		-- 3 �P�~�߮׸�,
		mins_stl	int,			-- 4 �P�~�ߥI���B
		itag		char(15),		-- 5 �s�w���P
		iclaim		char(20),		-- 6 �s�w�߮׸�
		fstl		char(1),		-- 7 �s�w�߰l�ʽ�
		iclose_type	int,			-- 8 �s�w�ߥI����
		istl_flag	char(1),		-- 9 �ߥI���p
		msettle		int,			-- 10 �s�w�ߥI���B
		iself_duty	int,			-- 11 �s�w�����F�d�H
		ioth_duty	int,			-- 12 �s�w��y�F�d�H
		nadjustment	char(10),	    -- 13 �z�߸g��
		dcreate		date,			-- 14 ���ɤ��
		ncreate		char(10)		-- 15 ���ɤH��
	)with no log;

    return M_CM_OK;
}
/*--------------------------------------------------------------------*/
long car929_report_init()
{

    $char	tp_now[21];


    $whenever sqlerror goto errexit;

    printf("-------- car929_report_init --------------\n");

    if (strcmp(sRpt1,"1") == 0)
    {
        /* ��� */
        $select first 1 to_char(rpt_end,'%Eg%Ey%Om%Od') into $rptdate1
           from ca929rptd;
				printf("226:rptdate1=[%s]\n",rptdate1);
        sprintf(sfilename,"17_ALL_�j���I�F�d�q����_%s", rptdate1);
        strcpy(stitle,"�O�I���q\t�O�I�Ҹ�\t����\t���`�H�m�W\t���`�H�����Ҹ�\t");
        strcat(stitle,"�X�ͦ~���\t�z�ߪ��B\t�F�Ƥ��\t���`�H�O\t�����F�d��\t");
        strcat(stitle,"��y���F�d��\t��L�F�d��\t��y���P��\t��y�O�I���q�N�X\t");
        strcat(stitle,"��y�O�I�Ҹ�\t");
    }
    else if (strcmp(sRpt1,"2") == 0)
    {
        /* ��� */
        $select first 1 to_char(rpt_end,'%Eg%Ey%Om') into $rptdate1
           from ca929rptm;
				printf("238:rptdate1=[%s]\n",rptdate1);
        sprintf(sfilename,"17_ALL_�j���I�F�d���u�վ���Ӫ�_%s",rptdate1);
        strcpy(stitle,"�Ǹ�\t�߮פ��q�N�X\t�߮׸��X\t�O�I�Ҹ�\t�Q�O�I�H�����N��\t");
        strcat(stitle,"���������N��\t�����ƶq\t�������\t���P���X\t�X�I�~(�褸)\t");
        strcat(stitle,"�X�I��\t�X�I��\t�X�I��\t�X�I��\t�X�I��]�N��\t�X�I�a�ϥN��\t���`�H�m�W\t");
        strcat(stitle,"���`�H�����Ҹ�\t���`�H�X�ͦ~���\t���I���O�ζ���\t");
        strcat(stitle,"�E���O�βӶ��N��\t�z�ߪ��B\t���`�H�O\t�����F�d���\t");
        strcat(stitle,"��y���F�d���\t��L�F�d���\t��y���P���X\t��y���q�N�X\t");
        strcat(stitle,"��y�O�I�Ҹ�\t���u���B\t");
    }
    else if (strcmp(sRpt1,"3") == 0)
    {
        /* �w���ɥ��鵲 */
				printf("259:�w���ɥ��鵲\n");
        sprintf(sfilename,"�w���ɥ��鵲���Ӫ�");
        strcpy(stitle,"��Ʀ~��\t�߮פ��q�N�X\t�P�~�߮׸��X\t�P�~�ߥI���B\t");
        strcat(stitle,"�s�w���P\t�s�w�߮׸�\t�s�w�߰l�ʽ�\t�s�w�ߥI����\t");
        strcat(stitle,"�ߥI���p\t�s�w�ߥI���B\t�s�w�����F�d�H\t�s�w��y�F�d�H\t");
        strcat(stitle,"�z�߸g��\t���ɤH��\t���ɤ��\t");
    }

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
/* ���o���_��� */
long ca929_build_D()
{
	int i;
	$char sTmp1[5000];

	$whenever sqlerror goto errexit;

    for (i=0; i<count_db; i++)
    {
		/* ��X�߮׸��νߥI���ơB������ */
        sprintf(sTmp1,
            "insert into ca929d1 "
    		"select unique c.icard, c.itag, "
    		"       (SELECT iverify FROM ca_ver_relation WHERE iclaim = a.iclaim) AS iverify, "
            "       a.iclaim, b.iclose_type, "
            "       (SELECT sum(qduty_adjuster) FROM ca_clm_victim_data y, ca_ver_relation z "
            "         WHERE y.iclaim = z.iverify AND z.iclaim = a.iclaim "
            "           AND y.fvictim_car IN ('A','F','G')) AS qduty_adjuster, "
            "       (SELECT count(UNIQUE itag) FROM ca_clm_victim_data y, ca_ver_relation z "
            "         WHERE y.iclaim = z.iverify AND z.iclaim = a.iclaim AND itag <> '') AS car_cnt, "
            "        a.daccident "
            "   from ca_clm_process a, %s:ca_stl_victim b, %s:policy c, %s:settlement d "
            "  where a.iclaim = b.iclaim 	  AND a.ipolicy = c.ipolicy "
            "    AND a.iclaim = d.iclaim 	  AND b.iclaim = d.iclaim "
            "    AND b.fstl = d.fstl 			  AND b.iclose_type = d.iclose_type "
            "    and b.fstl = '1'					  AND d.fsale = 0    "
            "    and a.iclaim[6] = 'C'      and b.mins_stl > 0 "
            "    and b.mstl_health = 0      and d.istl_flag not in ('8','B') "
            "    and b.dgroup between '%s' and '%s' "
            "    AND (SELECT sum(qduty_adjuster) FROM ca_clm_victim_data y, ca_ver_relation z "
            "          WHERE y.iclaim = z.iverify AND z.iclaim = a.iclaim "
            "            AND y.fvictim_car IN ('A','F','G')) < 100 ",
        list[i].dbname, list[i].dbname, list[i].dbname, sDbgn, sDend );

		$prepare pre_d1 from $sTmp1;
        $execute pre_d1;
    }

	/* ��X����O�������� */
    sprintf(sTmp1,
	    "select a.*, (select count(unique (c.ivictim||c.itag)) "
        "               from ca_clm_victim_data b, ca_property c "
        "              where b.iclaim = c.iverify   and b.itag = c.itag "
        "                and b.ivictim = c.ivictim  and b.fdrive = '1' "
        "                and decode(b.fvictim_car, 'G','17',ioth_card_company) not in (' ','XX') "
        "                and b.iclaim = a.iverify   and c.iverify = a.iverify) as com_cnt "
        "  from ca929d1 a 		where 1=1 "
        "  into temp ca929d2 with no log ");
	$prepare pre_d2 from $sTmp1;
    $execute pre_d2;

	/* ��X�����H�~�̤j���F�d���� */
	$SELECT UNIQUE c.iclaim, c.iclose_type, a.itag, a.qduty_adjuster ,
            (SELECT min(ioth_card_company) 	FROM ca_property
              WHERE iverify = a.iclaim 		AND itag = a.itag
                AND nvl(ioth_card_company,' ') NOT IN (' ','0','00')) as oth_company,
            (SELECT UNIQUE ioth_icard 			FROM ca_property
              WHERE iverify = a.iclaim 		AND itag = a.itag
                AND ioth_card_company =
              		(SELECT min(ioth_card_company)  FROM ca_property
                      WHERE iverify = a.iclaim 	AND itag = a.itag
                        AND nvl(ioth_card_company,' ') NOT IN (' ','0','00'))) AS oth_card,
            c.car_cnt, c.com_cnt
       FROM ca_clm_victim_data a, ca929d2 c
      WHERE a.iclaim = c.iverify
        AND a.fvictim_car NOT IN ('A','F','G')
        AND c.car_cnt > 1
        AND a.qduty_adjuster = (SELECT max(qduty_adjuster) FROM ca_clm_victim_data
                                 WHERE iclaim = a.iclaim
                                   AND fvictim_car NOT IN ('A','F','G','C'))
        AND CASE WHEN c.car_cnt > 2 then
    		   (SELECT count(*) FROM (
                       SELECT itag, sum(qduty_adjuster) AS icnt1
                         FROM ca_clm_victim_data f
                        WHERE f.iclaim = a.iclaim
                        GROUP BY 1) WHERE icnt1 > 0)
            ELSE  2  END  <= 2
      ORDER BY 1,2
       INTO temp ca929d3 WITH NO log;

	/* �����: �ư�36����1���߮� */
    for (i=0; i<count_db; i++)
    {
        sprintf(sTmp1,
            "insert into ca929rptd "
        	"SELECT '17', a.icard, a.itag, c.nassured, b.ivictim, "
        	"		c.dvictim, sum(b.mins_stl) as mins_stl, a.daccident, "
            "       decode(c.fvictim_car,'A','1','C','3','D','4','E','5',c.fvictim_car) AS fvictim_car, "
            "       a.qduty_adjuster, d.qduty_adjuster AS qduty_adjuster2, "
            "       (100-a.qduty_adjuster-d.qduty_adjuster) AS qduty_adjuster3, "
            "       d.itag AS itag2, d.oth_company, d.oth_card, '%s', '%s', a.iclaim, "
            "       a.iclose_type, a.car_cnt "
            "  FROM ca929d2 a, %s:ca_stl_victim b, ca_clm_victim_data c, ca929d3 d "
            " WHERE a.iclaim = b.iclaim  		AND a.iclose_type = b.iclose_type "
            "   AND a.iverify = c.iclaim    AND b.ivictim = c.ivictim "
            "   AND a.iclaim = d.iclaim 		AND a.iclose_type = d.iclose_type "
            "   AND b.fstl = '1'				   	AND a.car_cnt > 1 "
            "   AND a.car_cnt = a.com_cnt		AND b.mins_stl > 0 "
            "   AND (((a.car_cnt = 2) AND ((c.fvictim_car = 'E') "
            "              OR (c.fvictim_car IN ('A','C','D') AND b.mins_stl >0))) "
            "         OR "
            "         ((a.car_cnt > 2) AND ((c.fvictim_car IN ('A','C','D') AND b.mins_stl >0 )))) "
    	    " GROUP BY 1,2,3,4,5,6,8,9,10,11,12,13,14,15,16,17,18,19,20 ",
    	    sDbgn, sDend, list[i].dbname);

    	$prepare pre_d3 from $sTmp1;
        $execute pre_d3;
	}

	return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* ------------------------------------------------------------------------- */

/* ���o���_��� */
long ca929_build_M()
{
	int i;
	$char sTmp1[5000];

	$whenever sqlerror goto errexit;
	printf(" ------ ca929_build_M() start ------ \n");
    for (i=0; i<count_db; i++)
    {
	    /* ��X�߮׸��νߥI���ơB������ */
        sprintf(sTmp1,
            "insert into ca929m1 "
			"SELECT UNIQUE a.iclaim, b.iclose_type, c.icard, "
            "       (SELECT fvictim_nation FROM ca_clm_victim_data y, ca_ver_relation z "
            "         WHERE y.iclaim = z.iverify  AND z.iclaim = a.iclaim "
            "           AND y.fvictim_car IN ('A','F','G') AND y.fdrive = '1') AS fvictim_nation, "
            "       (SELECT icar_type FROM %s:adjustment_ply WHERE iclaim = a.iclaim) AS icar_type, "
            "        c.qpt, c.fpt, a.itag, a.daccident, e.iacc_reason, "
            "       DECODE(iacc_area,'42','41','63','62','65','64',iacc_area) AS iacc_area, "
            "       (SELECT iverify FROM ca_ver_relation WHERE iclaim = a.iclaim) AS iverify, "
            "       (SELECT sum(qduty_adjuster) FROM ca_clm_victim_data y, ca_ver_relation z "
            "         WHERE y.iclaim = z.iverify AND z.iclaim = a.iclaim  "
            "           AND y.fvictim_car IN ('A','F','G')) AS qduty_adjuster, "
            "       (SELECT count(UNIQUE itag) FROM ca_clm_victim_data y, ca_ver_relation z "
            "         WHERE y.iclaim = z.iverify AND z.iclaim = a.iclaim AND itag <> '') AS car_cnt "
            "  from ca_clm_process a, %s:ca_stl_victim b, %s:policy c, %s:settlement d, "
            "       %s:appraisal e "
            " WHERE a.iclaim = b.iclaim			  AND a.ipolicy = c.ipolicy "
            "   AND a.iclaim = d.iclaim	      AND b.iclaim = d.iclaim "
            "   AND b.fstl = d.fstl						AND b.iclose_type = d.iclose_type "
            "   AND a.iclaim = e.iclaim 			AND b.iclaim = e.iclaim "
            "   AND d.iclaim = e.iclaim				and b.fstl = '1'      AND d.fsale = 0 "
            "   and b.mins_stl > 0						and a.iclaim[6] = 'C' "
            "   and b.mstl_health = 0					and d.istl_flag not in ('8','B') "
            "   and b.dgroup between '%s' and '%s' "
            "   AND (SELECT sum(qduty_adjuster) FROM ca_clm_victim_data y, ca_ver_relation z "
            "         WHERE y.iclaim = z.iverify    AND z.iclaim = a.iclaim "
            "           AND y.fvictim_car IN ('A','F','G')) < 100",
        list[i].dbname, list[i].dbname, list[i].dbname, list[i].dbname,
        list[i].dbname, sDbgn, sDend );
        printf("405:sTmp1=[%s]\n",sTmp1);
		$prepare pre_m1 from $sTmp1;
        $execute pre_m1;
	}

	/* ��X����O�������� */
	sprintf(sTmp1,
            "SELECT a.* , (SELECT count(UNIQUE((c.ivictim)||(c.itag))) "
            "                FROM ca_clm_victim_data b, ca_property c "
            "               WHERE b.iclaim = c.iverify      AND b.itag = c.itag "
            "                 AND b.ivictim = c.ivictim     AND b.fdrive = '1' "
            "                 AND decode(b.fvictim_car,'G','17',ioth_card_company) NOT IN (' ','XX') "
            "                 AND b.iclaim = a.iverify and c.iverify = a.iverify) AS com_cnt "
            "  FROM ca929m1 a  where 1=1 "
            " INTO temp ca929m2 WITH no log");

	printf("421:sTmp1=[%s]\n",sTmp1);
	$prepare pre_m2 from $sTmp1;
    $execute pre_m2;

	/* ��X�����H�~�̤j���F�d���� */
	$SELECT UNIQUE c.iclaim, c.iclose_type, a.itag, a.qduty_adjuster ,
            (SELECT min(ioth_card_company) FROM ca_property
              WHERE iverify = a.iclaim   AND itag = a.itag
                AND nvl(ioth_card_company,' ') NOT IN (' ','0','00')) as oth_company,
            (SELECT UNIQUE CASE WHEN ioth_card_company = 'XX' THEN ' ' ELSE ioth_icard end
               FROM ca_property WHERE iverify = a.iclaim AND itag = a.itag
                AND ioth_card_company =
              		(SELECT min(ioth_card_company) FROM ca_property
                      WHERE iverify = a.iclaim AND itag = a.itag
                        AND nvl(ioth_card_company,' ') NOT IN (' ','0','00'))) AS oth_card,
            c.car_cnt, c.com_cnt
       FROM ca_clm_victim_data a, ca929m2 c
      WHERE a.iclaim = c.iverify        AND a.fvictim_car NOT IN ('A','F','G')
        AND c.car_cnt > 1  				AND a.qduty_adjuster > 0
  		AND a.qduty_adjuster =
  			(SELECT max(qduty_adjuster) FROM ca_clm_victim_data
  			  WHERE iclaim = a.iclaim  AND fvictim_car NOT IN ('A','F','G','C'))
  	    AND CASE WHEN c.car_cnt > 2 then
    		   (SELECT count(*) FROM (
                       SELECT itag, sum(qduty_adjuster) AS icnt1
                         FROM ca_clm_victim_data f
                        WHERE f.iclaim = a.iclaim
                        GROUP BY 1) WHERE icnt1 > 0)
             ELSE  2  END  <= 2
  	  ORDER BY 1,2
  	   INTO temp ca929m3 WITH NO log;

    printf("405:into temp ca929m3 OK \n");
	/* �����: �g�J�Ȧs��  */
	for (i=0; i<count_db; i++)
    {
        sprintf(sTmp1,
            "insert into ca929rptm "
            "SELECT '17' AS company, a.iclaim, a.icard, a.fvictim_nation, a.icar_type, "
            "       a.qpt, a.fpt, a.itag, a.daccident, a.iacc_reason, a.iacc_area, "
            "       c.nassured, c.ivictim, c.dvictim, b.iins_item, b.mins_stl, "
            "       decode(c.fvictim_car,'A', '1','C','3','D','4','E','5',c.fvictim_car) AS fvictim_car, "
            "       a.qduty_adjuster, d.qduty_adjuster AS qduty_adjuster2, "
            "       (100-a.qduty_adjuster-d.qduty_adjuster) AS qduty_adjuster3, "
            "       d.itag AS itag2, d.oth_company, d.oth_card, "
            "       FLOOR(b.mins_stl*d.qduty_adjuster/100) AS mprem, '%s', '%s',"
            "       a.iclose_type, a.car_cnt "
            "  FROM ca929m2 a, %s:ca_stl_victim b, ca_clm_victim_data c, ca929m3 d "
            " WHERE a.iclaim = b.iclaim  		AND a.iclose_type = b.iclose_type "
            "   AND a.iverify = c.iclaim		AND b.ivictim = c.ivictim "
            "		AND a.iclaim = d.iclaim 		AND a.iclose_type = d.iclose_type "
            "   AND b.fstl = '1'   					AND a.car_cnt > 1 "
            "   and c.itag = d.itag "
            "   AND a.car_cnt = a.com_cnt	  AND b.mins_stl > 0 "
            "   AND d.oth_company = (SELECT min(oth_company) FROM ca929m3 "
            "                        WHERE iclaim = a.iclaim AND iclose_type = a.iclose_type) "
            "   AND (((a.car_cnt = 2)  AND ((c.fvictim_car = 'E') "
            "            OR (c.fvictim_car IN ('A','C','D') AND b.mins_stl > 0 ))) "
            "        OR "
            "        ((a.car_cnt > 2) "
            "           AND ((c.fvictim_car IN ('A','C','D') AND b.mins_stl > 0 )))) ",
	    sDbgn, sDend,list[i].dbname);
        printf("474:into temp ca929m3 OK \n");
		$prepare pre_m3 from $sTmp1;
        $execute pre_m3;
	}

	return M_CM_OK;


errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* ------------------------------------------------------------------------- */
long car929_print()
{
    int     rc;
    $char stmt[2000];

    $WHENEVER SQLERROR GOTO errexit;

	if (strcmp(sRpt1,"1") == 0)
	{
	    /* �R���G�Ӥ�e����� */
		$DELETE FROM ca_clm_com_rpt
		  WHERE freport = 'D'
		    and DATE(dcreate) <= add_months(today,-2);

		/* ���g�J����table */
		sprintf(stmt,
                "insert into ca_clm_com_rpt "
                "select 'D', rpt_bgn, rpt_end, "
                "        row_number() over (partition by  oth_company ORDER BY iclaim,iclose_type, ivictim)::int, "
                "        icompany, icard, itag, nassured, ivictim, dvictim, "
                "        mins_stl, daccident, fvictim_car, qduty_adjuster, "
                "        qduty_adjuster2, qduty_adjuster3, itag2, nvl(oth_company,' '), oth_card[3,21],  "
                "        ' ', ' ', 0, ' ', ' ', "
                "        ' ', ' ', 0, icar_cnt, iclaim, "
                "        iclose_type, '%s', current "
                "   from ca929rptd "
                "  where 1=1 ORDER BY oth_company, iclaim, iclose_type,ivictim ",userid);
        $prepare pre_d4 from $stmt;
        $execute pre_d4;

        /* �L�� */
	    sprintf(stmt,
                "select icompany, icard, itag, nassured, ivictim, to_char(dvictim, '%%Y%%m%%d'), "
                "       mins_stl, to_char(daccident,'%%Y%%m%%d%%H%%M'), fvictim_car, qduty_adjuster, "
                "       qduty_adjuster2, qduty_adjuster3, itag2, oth_company, oth_card[3,21] "
                "   from ca929rptd "
                "  where 1=1 ORDER BY oth_company, iclaim, iclose_type,ivictim ");
		}
		else if (strcmp(sRpt1,"2") == 0)
		{
		    printf("----- 541 ----- \n");
			/* �R���G�Ӥ�e����� */
			$DELETE FROM ca_clm_com_rpt
			  WHERE freport = 'M'
			    and DATE(dcreate) <= add_months(today,-2);

			/* ���g�J����table */
			sprintf(stmt,
                    "insert into ca_clm_com_rpt "
                    "SELECT 'M', rpt_bgn, rpt_end, "
                    "       row_number() over (partition by  oth_company ORDER BY iclaim,iclose_type, ivictim, iins_item)::int, "
                    "       icompany, icard, itag, nassured, ivictim, "
                    "       dvictim, mins_stl, daccident, fvictim_car, qduty_adjuster, "
                    "       qduty_adjuster2, qduty_adjuster3, itag2, nvl(oth_company,' '), nvl(oth_card[3,21],' '), "
                    "       fvictim_nation, icar_type, qpt, fpt, iacc_reason, "
                    "       iacc_area, iins_item, mprem, icar_cnt, iclaim, "
                    "       iclose_type, '%s', current "
                    "  FROM ca929rptm "
                    " WHERE 1=1  "
                    " ORDER BY oth_company, iclaim, iclose_type, ivictim, iins_item;",userid);

            printf("563 stmt=[%s]\n",stmt);
			$prepare pre_m4 from $stmt;
            $execute pre_m4;

			/* �L�� */
			sprintf(stmt,
                    "SELECT row_number() over (partition by  oth_company ORDER BY iclaim,iclose_type, ivictim, iins_item)::int, "
                    "       icompany, iclaim, icard, fvictim_nation, icar_type, "
                    "       lpad(trim(replace(cast(qpt as char(4)),'.')),4,'0') as qpt, fpt,itag, "
                    "       year(daccident), to_char(daccident,'%%m'), to_char(daccident,'%%d'), "
                    "       to_char(daccident,'%%H'),to_char(daccident,'%%M'), "
                    "       iacc_reason, iacc_area, nassured, ivictim, to_char(dvictim,'%%Y%%m%%d'), "
                    "       iins_item[1,3], decode(iins_item[4],'0',' ',iins_item[4]), mins_stl, "
                    "       fvictim_car, qduty_adjuster, qduty_adjuster2, qduty_adjuster3, "
                    "       itag2, oth_company, oth_card[3,21], mprem "
                    "  FROM ca929rptm "
                    " WHERE 1=1  "
                    " ORDER BY oth_company, iclaim, iclose_type, ivictim, iins_item;");
		}
		else if (strcmp(sRpt1,"3") == 0)
		{
		    /* �L�� */
			/* �`�N:�U�CSQL����chr(127),�b�S�w�r���~�ݱo��,�������@�Ӧr��,
                ���i�H�b��Excel�ɮɥi�H��ܧ��㪺�Ʀr, ���|�y�������D,���V��.. */
			sprintf(stmt,
                    "SELECT idate_ym, chr(127)||icompany, chr(127)||trim(iclaim_p), "
                    "       mins_stl, chr(127)||trim(itag), iclaim, fstl, iclose_type, "
                    "       istl_flag, msettle, iself_duty, ioth_duty, nadjustment, "
                    "       dcreate, ncreate "
                    "  FROM ca929a1 "
                    " WHERE 1=1  "
                    " ORDER BY idate_ym, icompany, iclaim, fstl, iclose_type;");
		}
        rc = unload_file(outputf," ",sfilename,stitle,stmt);

        if (rc != SUCCESS) {
            sprintf(msgbuf," %s �ɮ׵L�k���� ",sfilename);
            EWRITE(userid, rc , msgbuf);
            return rc;
    }

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}

/* ------------------------------------------------------------------------- */
long car929_gen_files()
{
    int     rc, rt;
    char    ipgid[9], file1[65], outputf1[N_FILE+1];
    $char 	stmt[2000], stmt2[500];
    $char   ioth[3], prtstr[10000];
    $char   sIcompany[3], sIcard[21], sItag[13], sNassured[21], sIvictim[11],
            sDvictim[11], sDaccident[17], sFvictim_car[2], sItag2[13],
            sOth_company[3], sOth_card[21], sIclaim[21], sFvictim_nation[2],
            sIcar_typ[3], sQpt[10], sFpt[2], sYY[5], sMM[3], sDD[3],sHH[3], sMum[3],
            sIacc_reason[3], sIacc_area[3], sIins_item1[4], sIins_item2[2];
    $int    iMins_stl, iQduty_adjuster, iQduty_adjuster2, iQduty_adjuster3,
            iNumber, iMprem;

    FILE	   *fp1;

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(ipgid,"car929");
    strcpy(rptdate1,rtrim(rptdate1));
    printf("567:rptdate1=[%s]\n",rptdate1);
	/* ��� */
	if (strcmp(sRpt1,"1") == 0)
	{
	    sprintf(stmt2, "select unique oth_company from ca929rptd where 1=1 order by oth_company ");
	    $prepare pre_gd1 from $stmt2;
        $declare cur_gd1 cursor for pre_gd1;
        $open  cur_gd1;
        while(1)
      {
        $fetch cur_gd1 into $ioth;
      	if (SQLCODE==SQLNOTFOUND) break;
	    printf("576:rptdate1=[%s]\n",rptdate1);
		sprintf(outputf1,"17_%s_�j���I�F�d�q����_%s.txt", ioth, rptdate1);
		sprintf(file1,"%s/rptftp/%s",sApHome,rtrim(outputf1));

		printf("file1=[%s]\n",file1);
		rt = rptftpinsert(userid,ipgid,outputf1);

		fp1= fopen(file1,"w");
		fprintf(fp1,"%s\n",stitle);

		sprintf(stmt,
        		"select icompany, icard, itag, nassured, ivictim, "
        		"       to_char(dvictim, '%%Y%%m%%d'), mins_stl, "
        		"       to_char(daccident,'%%Y%%m%%d%%H%%M'), fvictim_car, qduty_adjuster, "
        		"       qduty_adjuster2, qduty_adjuster3, itag2, oth_company, oth_card[3,21] "
    	      	"  from ca929rptd "
    	      	" where oth_company = '%s' "
    	      	" ORDER BY oth_company, iclaim, iclose_type,ivictim ",ioth);

        $prepare pre_gd2 from $stmt;
      	$declare cur_gd2 cursor for pre_gd2;
      	$open  cur_gd2;
      	while(1)
      	{
      		$fetch cur_gd2 into $sIcompany, $sIcard, $sItag, $sNassured, $sIvictim,
      		                    $sDvictim, $iMins_stl, $sDaccident, $sFvictim_car,
      		                    $iQduty_adjuster, $iQduty_adjuster2,
      		                    $iQduty_adjuster3, $sItag2, $sOth_company,
      		                    $sOth_card;
      		if (SQLCODE==SQLNOTFOUND) break;

            strcpy(prtstr,rtrim(sIcompany));
            strcat(prtstr,"\t");
            strcat(prtstr,rtrim(sIcard));
            strcat(prtstr,"\t");
            strcat(prtstr,rtrim(sItag));
            strcat(prtstr,"\t");
            strcat(prtstr,rtrim(sNassured));
            strcat(prtstr,"\t");
            strcat(prtstr,rtrim(sIvictim));
            strcat(prtstr,"\t");
            strcat(prtstr,rtrim(sDvictim));
            strcat(prtstr,"\t");
            strcat(prtstr,rtrim(itoa(iMins_stl)));
            strcat(prtstr,"\t");
            strcat(prtstr,rtrim(sDaccident));
            strcat(prtstr,"\t");
            strcat(prtstr,rtrim(sFvictim_car));
            strcat(prtstr,"\t");
            strcat(prtstr,rtrim(itoa(iQduty_adjuster)));
            strcat(prtstr,"\t");
            strcat(prtstr,rtrim(itoa(iQduty_adjuster2)));
            strcat(prtstr,"\t");
            strcat(prtstr,rtrim(itoa(iQduty_adjuster3)));
            strcat(prtstr,"\t");
            strcat(prtstr,rtrim(sItag2));
            strcat(prtstr,"\t");
            strcat(prtstr,rtrim(sOth_company));
            strcat(prtstr,"\t");
            strcat(prtstr,rtrim(sOth_card));
            strcat(prtstr,"\t");

         	fprintf(fp1,"%s\n",prtstr);
        }
        $close  cur_gd2;
        $free  cur_gd2;
        fclose(fp1);
      }
      $close  cur_gd1;
      $free  cur_gd1;
    }
	else if (strcmp(sRpt1,"2") == 0)
	{
		/* ��� */
        sprintf(stmt2, "select unique oth_company from ca929rptm where 1=1 order by oth_company ");
	    $prepare pre_gm1 from $stmt2;
        $declare cur_gm1 cursor for pre_gm1;
        $open  cur_gm1;
        while(1)
        {
      	    $fetch cur_gm1 into $ioth;
      	    if (SQLCODE==SQLNOTFOUND) break;
            printf("657:rptdate1=[%s]\n",rptdate1);
			sprintf(outputf1,"17_%s_�j���I�P�~���u�վ���Ӫ�_%s.txt", ioth, rptdate1);
			sprintf(file1,"%s/rptftp/%s",sApHome,rtrim(outputf1));

			printf("file1=[%s]\n",file1);
			rt = rptftpinsert(userid,ipgid,outputf1);
			fp1= fopen(file1,"w");
			fprintf(fp1,"%s\n",stitle);

			sprintf(stmt,
        		    "SELECT row_number() over (partition by  oth_company ORDER BY iclaim,iclose_type, ivictim, iins_item)::int, "
        	        "       icompany, iclaim, icard, fvictim_nation, icar_type,"
        	        "       lpad(trim(replace(cast(qpt as char(4)),'.')),4,'0') as qpt, fpt,itag, "
        	        "       year(daccident), to_char(daccident,'%%m'), to_char(daccident,'%%d'), "
        	        "       to_char(daccident,'%%H'), to_char(daccident,'%%M'), "
        	        "       iacc_reason, iacc_area, nassured, ivictim, to_char(dvictim,'%%Y%%m%%d'), "
        	        "       iins_item[1,3], decode(iins_item[4],'0',' ',iins_item[4]), mins_stl, "
        	        "       fvictim_car, qduty_adjuster, qduty_adjuster2, qduty_adjuster3, "
        	        "       itag2, oth_company, oth_card[3,21], mprem "
        	        "  FROM ca929rptm "
        	        " WHERE oth_company = '%s'  "
        	        " ORDER BY oth_company, iclaim, iclose_type, ivictim, iins_item;",ioth);

            $prepare pre_gm2 from $stmt;
      	    $declare cur_gm2 cursor for pre_gm2;
      	    $open  cur_gm2;
      	    while(1)
      	    {
      		    $fetch cur_gm2 into $iNumber, $sIcompany, $sIclaim, $sIcard, $sFvictim_nation,
      		                    $sIcar_typ, $sQpt, $sFpt, $sItag, $sYY, $sMM, $sDD,
      		                    $sHH, $sMum,
      		                    $sIacc_reason, $sIacc_area, $sNassured, $sIvictim,
      		                    $sDvictim, $sIins_item1, $sIins_item2, $iMins_stl,
      		                    $sFvictim_car, $iQduty_adjuster, $iQduty_adjuster2,
      		                    $iQduty_adjuster3, $sItag2, $sOth_company,
      		                    $sOth_card, $iMprem;
      		    if (SQLCODE==SQLNOTFOUND) break;

                strcpy(prtstr,rtrim(itoa(iNumber)));
                strcat(prtstr,"\t");
                strcat(prtstr,rtrim(sIcompany));
                strcat(prtstr,"\t");
                strcat(prtstr,rtrim(sIclaim));
                strcat(prtstr,"\t");
                strcat(prtstr,rtrim(sIcard));
                strcat(prtstr,"\t");
                strcat(prtstr,rtrim(sFvictim_nation));
                strcat(prtstr,"\t");
                strcat(prtstr,rtrim(sIcar_typ));
                strcat(prtstr,"\t");
                strcat(prtstr,rtrim(sQpt));
                strcat(prtstr,"\t");
                strcat(prtstr,rtrim(sFpt));
                strcat(prtstr,"\t");
                strcat(prtstr,rtrim(sItag));
                strcat(prtstr,"\t");
                strcat(prtstr,rtrim(sYY));
                strcat(prtstr,"\t");
                strcat(prtstr,rtrim(sMM));
                strcat(prtstr,"\t");
                strcat(prtstr,rtrim(sDD));
                strcat(prtstr,"\t");
                strcat(prtstr,rtrim(sHH));
                strcat(prtstr,"\t");
                strcat(prtstr,rtrim(sMum));
                strcat(prtstr,"\t");
                strcat(prtstr,rtrim(sIacc_reason));
                strcat(prtstr,"\t");
                strcat(prtstr,rtrim(sIacc_area));
                strcat(prtstr,"\t");
                strcat(prtstr,rtrim(sNassured));
                strcat(prtstr,"\t");
                strcat(prtstr,rtrim(sIvictim));
                strcat(prtstr,"\t");
                strcat(prtstr,rtrim(sDvictim));
                strcat(prtstr,"\t");
                strcat(prtstr,rtrim(sIins_item1));
                strcat(prtstr,"\t");
                strcat(prtstr,rtrim(sIins_item2));
                strcat(prtstr,"\t");
                strcat(prtstr,rtrim(itoa(iMins_stl)));
                strcat(prtstr,"\t");
                strcat(prtstr,rtrim(sFvictim_car));
                strcat(prtstr,"\t");
                strcat(prtstr,rtrim(itoa(iQduty_adjuster)));
                strcat(prtstr,"\t");
                strcat(prtstr,rtrim(itoa(iQduty_adjuster2)));
                strcat(prtstr,"\t");
                strcat(prtstr,rtrim(itoa(iQduty_adjuster3)));
                strcat(prtstr,"\t");
                strcat(prtstr,rtrim(sItag2));
                strcat(prtstr,"\t");
                strcat(prtstr,rtrim(sOth_company));
                strcat(prtstr,"\t");
                strcat(prtstr,rtrim(sOth_card));
                strcat(prtstr,"\t");
                strcat(prtstr,rtrim(itoa(iMprem)));
                strcat(prtstr,"\t");

                fprintf(fp1,"%s\n",prtstr);
            }
      	    $close  cur_gm2;
      	    $free  cur_gm2;
      	    fclose(fp1);
		}
		$close  cur_gm1;
		$free  cur_gm1;
	}
    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}

/* ------------------------------------------------------------------------- */
/* ���o���_�w���ɥ��鵲���� */
long ca929_build_A()
{
	int i;
	$char sTmp1[5000];

	$whenever sqlerror goto errexit;
	printf(" ------ ca929_build_A() start ------ \n");
    for (i=0; i<count_db; i++)
    {
  	    sprintf(sTmp1,
  		        "insert into ca929a1 "
  			    "SELECT UNIQUE a.idate_ym, a.icompany, a.iclaim_p, sum(a.mins_stl), "
  			    "       c.itag, b.iclaim, b.fstl, b.iclose_type, b.istl_flag, "
  			    "       b.msettle, b.iself_duty, b.ioth_duty, "
                "       (SELECT nname FROM officer WHERE iofficer = c.adjustment), "
                "       DATE(a.dcreate), (SELECT nname FROM officer WHERE iofficer = a.icreate) "
                "  FROM ca_clm_com_trans a, %s:settlement b, ca_clm_process c "
                " WHERE a.iclaim = b.iclaim AND a.iclaim = c.iclaim "
                "   AND a.fstl = b.fstl "
                "   AND a.iclose_type = b.iclose_type "
                "   AND b.dclose IS NULL "
                "   AND date(a.dcreate) between '%s' and '%s' "
                "   AND a.istl_flag in ('7','8') "
                " GROUP BY 1,2,3,5,6,7,8,9,10,11,12,13,14,15 ",
                list[i].dbname,sDbgn,sDend);
		printf("sTmp1=[%s]\n",sTmp1);
		$prepare pre_A1 from $sTmp1;
    	$execute pre_A1;
    }

	return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}
