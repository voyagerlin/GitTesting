/**********************************************************************/
/*   program id   : ca1205q01s.ec                                     */
/*   program name : �߮׳B�z�i�פ���ˮֳ���                          */
/*   date written : 2019/06/03                                        */
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
#include "safeclib.h"

/****************************************************************************/
$char DBName[05],userid[11],iclaim[21],iroute[21],fedm[2],dedm_begin[11],dedm_end[11],dcreate_begin[11],dcreate_end[11];

char  msgbuf[2048], sApHome[30], rpt_type[2], getfile[101];
char  v_sMsg[1024], outputf[N_FILE+1];
int   count_db,i;
DBinfo  *list;
FILE    *fp;

/****************************************************************************/
main(argc, argv)
int argc;
char **argv;
{
	int rc;

	batchinit();
	strcpy(DBName, 		    isNULLstr(argv[1]));
	strcpy(userid, 		    isNULLstr(argv[2]));
	strcpy(iroute, 		    isNULLstr(argv[3]));    /* �q���N�� */
	strcpy(fedm, 		    isNULLstr(argv[4]));    /* �O�_�H�eEDM */
	strcpy(dedm_begin,      isNULLstr(argv[5]));    /* EDM�H�e��_��(CYYMMDD) */
	strcpy(dedm_end, 	    isNULLstr(argv[6]));    /* EDM�H�e�騴��(CYYMMDD) */
	strcpy(dcreate_begin,   isNULLstr(argv[7]));    /* ���ɰ_��(CYYMMDD) */
	strcpy(dcreate_end,     isNULLstr(argv[8]));    /* ���ɨ���(CYYMMDD) */
	strcpy(outputf,         isNULLstr(argv[9]));

	printf("outputf:s\n",outputf);
	printf("--1.car1205_get_db ------ \n");
	rc = car1205_get_db();
	if (rc != M_CM_OK) {
		EWRITE(userid,rc,msgbuf);
		return rc;
	}

    /* 1:�߮׳B�z�i�פ���ˮֳ���(CRJCM) */

        printf("--2.car1205_init_data ------ \n");
        rc = car1205_init_data();
        if (rc != M_CM_OK) {
            printf("error on car1205_init_data\n");
    		EWRITE(userid,rc,"�إ� temp table ���~!");
    		return rc;
        }

        printf("--3.car1205_query_detail ------ \n");
    	rc = car1205_query_detail();
        if (rc != M_CM_OK) {
        printf("error on car1205_query_detail\n");
    		EWRITE(userid, rc, "���̷s�߮׸��X���~");
    		return rc;
    	}

    	printf("--4.car1205_print_detail ------ \n");
        rc = car1205_print_detail();
        if (rc != M_CM_OK) {
         printf("error on car1205_print_detail\n");
         EWRITE(userid, rc, "���s�������Ӧ��~!");
         return rc;
        }



    return rc;
}
/******************************************************************************/
long car1205_get_db()
{
	int return_code;

	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == False) {
		strcpy(msgbuf,"��Ʈw�L�k�}��");
		return M_CM_DB_NOTOPEN;
	}

	return_code = getApHome(sApHome);
	if (return_code < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		return return_code;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
       if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
          return M_CM_NOT_DBLIST;
	}

	return M_CM_OK;

errexit:
   printf("--car1205_get_db-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/******************************************************************************/
long car1205_init_data()
{
    $WHENEVER SQLERROR GOTO errexit;

    $create temp table tb_ca12051
    (
        nassured 		varchar(120),   -- ���D�m�W
		iassured 		varchar(12),    -- ���DID
        itag            char(25),       -- ����
        iclaim          char(20),       -- �z�߮׸�
        nadjust         char(30),       -- �z�߱M��
        dclaim        	date    ,       -- ���z���
        dcontact        date	,       -- �pô���
        dverify 	    date	,       -- �d�ҧ@�~���
        dsurvey         date	,       -- �ɮ֤��
        fdmg_duty       char(15) ,      -- �����I���L�F�d
        dgroup          date    ,       -- ���פ��
		fedm            char(1) ,       -- EDM�O�_�H�e
		dedm			date	,		-- EDM�H�e���
		iemail			varchar(50),	-- �H�c
		aassured_zip	char(6),		-- �Q�O�I�H�l���ϸ�
		aassured		varchar(90),	-- �Q�O�I�H�a�}
		iroute          char(20),       -- �q���N��
		nroute          varchar(40),    -- �q���W��
		ipolicy			char(20),		-- �O�渹
		iadj_tel		char(20),		-- �z�߱M���q��
		msettle_dmg		int		,		-- �����I�ߴڪ��B
		icreate			char(10),		-- ���ɤH��(���s)
		ncreate			char(10),		-- ���ɤH��(�W��)
		dcreate			date			-- ���ɤ��
		/*iupdate			char(10),		-- ���ʤH��(���s)*/
		/*nupdate			char(10),		-- ���ʤH��(�W��)*/
		/*dupdate			date			-- ���ʤ��*/


    )with no log;

    return M_CM_OK;

errexit:
    printf("--car1205_init_data-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car1205_query_detail()
{
    int	    rc;
    $char   stmt1[2000],stmt2[100],stmt3[2000];
    $int    icnt;

    $WHENEVER SQLERROR GOTO errexit;

	printf("dedm_begin:[%s] , dedm_end:[%s] " ,dedm_begin , dedm_end );

	if( strcmp(trim(dedm_begin), "*") == 1 && strcmp(trim(dedm_end) , "*")==1 )
		sprintf_s(stmt3,2000 , "and e.dedm::date between '%s' and '%s'" , dedm_begin , dedm_end);


	printf("stmt2 : %s \n",stmt3);

        sprintf_s(stmt1,2000,
            "insert into tb_ca12051 \
             select e.nassured , e.iassured , e.itag , e.iclaim, (e.adjustment || e.nadjust) as nadjust , e.dclaim, \
                    date(e.dcontact) AS dcontact, date(e.dverify) AS dverify, date(e.dsurvey) AS dsurvey, \
					CASE e.fdmg_duty WHEN '1' THEN '1:���F�d,�p��' WHEN '2' THEN '2:�L�F�d,���p��' WHEN '3' THEN '3:���F�d,���p��' END fdmg_duty, \
					e.dgroup , e.fedm , e.dedm , e.iemail , e.aassured_zip , e.aassured , e.iroute , r.nroute , \
					e.ipolicy , e.iadj_tel , e.msettle_dmg , e.icreate , o1.nname as ncreate , e.dcreate \
               from ca_edm e , officer o1  ,cm_route r\
                where 1=1 \
				and e.iroute = r.iroute \
				and e.icreate = o1.iofficer \
                and e.iroute matches '%s' \
                and e.fedm matches '%s'  \
				%s  \
				and e.dcreate::date between '%s' and '%s'", iroute ,fedm , stmt3 , dcreate_begin , dcreate_end);

        printf("stmt1=[%s]\n",stmt1);
        $PREPARE pre_A1 FROM $stmt1;
        $EXECUTE pre_A1;


    return M_CM_OK;

errexit:
    printf("--car1205_query_detail-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* ------------------------------------------------------------------------- */
long car1205_print_detail()
{
    int     rc;
    char    sfilename[128],stitle[2048],stmt[2048];
    $int    icnt;

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(sfilename,"�߮׳B�z�i�פ���ˮֳ���");
    strcpy(stitle,"�{���N��:CAR12051\t");
    strcat(stitle,sfilename);
    strcat(stitle,"\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");


    icnt = 0;
    $select count(*) into $icnt
      from tb_ca12051;
	  printf("icnt:%d\n",icnt);
    if (icnt == 0)
    {
        sprintf_s(msgbuf,2048," %s �d�L���, �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return  M_CM_NOT_FOUND;
    }
    printf("11111111\n");
    strcat(stitle,"\t���D�m�W\t����\t�z�߮׸�\t�z�߱M��\t���z���");
    strcat(stitle,"\t�pô���\t�d�ҧ@�~���\t�ɮ֤��\t���פ��");
    strcat(stitle,"\t�����I���L�F�d\t�����I�ߴڪ��B\t�O�_�H�eEDM\tEDM�H�o���\tEmail\t�Q�O�I�H�l���ϸ�\t�Q�O�I�H�a�}");
	strcat(stitle,"\t�q���N��\t�q���W��\t���ɤH��\t���ɤ��");

    strcpy(stmt,"select nassured , itag , iclaim  , nadjust , dclaim ,\
                        dcontact , dverify , dsurvey , dgroup , \
                        fdmg_duty , msettle_dmg , fedm , dedm , iemail , aassured_zip , aassured , \
						iroute , nroute , ncreate , dcreate\
                   from tb_ca12051 where 1=1   order by iclaim ");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);
    printf("222222222\n");
    if (rc != SUCCESS) {

        sprintf_s(msgbuf,2048," %s �ɮ׵L�k���� ",sfilename);

        EWRITE(userid, rc , msgbuf);
        return rc;
    }
    return M_CM_OK;

errexit:
    printf("--car1205_print_detail-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}

/******************************************************************************/


