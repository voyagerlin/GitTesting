/*****************************************************************/
/*     ca351p01s.ec                                              */
/*     �C��17:00���沣�s�ɮ�(�e�@��17:00�����17:00�����ɪ��O��) */
/*     �C��17:30�N�ɮױq���I�t�Ωߦ�FTP Server                   */
/*     �C��18:00�N�ɮױqFTP Server�ߦܤ���                       */
/*****************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <decimal.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "globdata.h"
    

$char dbgn[11];
$char   Fname_1[128];
$char   FileName_1[128];
/*TEMP TABLE:  chailease_a*/
$char   itag_a[13],dply_begin_a[11],ibrand_a[11],iengine_a[26],mcar_price_a[10],cover_a[10],ixxcard_a[20];
$char   icard_1_a[21],ipolicy_2_a[21],prem_1_a[10],prem_2_a[10];
/*TEMP TABLE:  chailease*/
$char   icard_1[21],itag[13],dply_begin[11],ibrand[11],iengine[26],ipolicy_2[21];
$char   mcar_price[10],prem_1[10],prem_2[10],prem_sum[10];
$char   cover[10];
/*TEMP TABLE:  chailease_ins_type*/
$char   iins_type[6],nins_type[30];
$char   minjured_cover[11],mdeath_cover[11],mdamage_cover[11],mdeduct[11],daily_pay[11],qday[4];
$char   minjured_cover2[11],mdamage_cover2[11];/*���:�U*/
$char   dply_begin2[11];
$char   icard_delete[21];
/*for chailease_prepare_data2()*/
$char   sIpolicy_data2[21],sIendorse_data2[21],sFcard_class_data2[2],sIendorse_first[21];


FILE    *fp, *sfp, *sfp2;
char    sApHome[30];
$char   fname[60];
$char   filename[121];
$char	ReportName[500];
$char	dbegin[11],dend[11];
int   count_db,k; 
char  outputf[21];
$char userid[11];
$char DBName[05];
$char FormTp[03];
$char msgbuf[128];
$char	ftitle[1024];
int   max_count;
$char  sMsg[512];
$char  sMsg_mail[1024];
DBinfo *list;
char *get_car_full_db();
char *get_full_dbname();
$char Full_DBName1[20];
$char Full_DBName2[20];
char cmd_email1[1000];

$char stmt_ins[8192],stmp[256],stmp2[256];
$int itime_now = 0;

void car351_clear();

/*********************************************************************/
main(argc, argv)
int argc;
char **argv;
{
 	int rc;
        char yy_fn[4], mm_fn[3], dd_fn[3];
	batchinit();
	strcpy(DBName,         isNULLstr(argv[1]));
	strcpy(userid,         isNULLstr(argv[2]));
	strcpy(dbgn,           isNULLstr(argv[3]));
	strcpy(outputf,        isNULLstr(argv[4]));
	

	rc = chailease_get_db();
	if (rc != M_CM_OK)
		return rc;
		
        $CREATE TEMP TABLE car351_log 
        ( 
          field1       char(40),   
          field2       char(20),   
          field3       char(5),    
          field4       char(40)    
        ) WITH NO LOG;
	
	strcpy(FileName_1," ");
	strcpy(Fname_1," ");
	
	/*1101129001_SC1_�վ�car351�����q�l���n�O�Ѳ��s�@�~�Ƶ{*/
	/*�̨t�ΰ���ɶ��M�w���s��ư϶�*/
	itime_now = 0;
	$SELECT FIRST 1 to_char(CURRENT,'%H')::int INTO $itime_now FROM systables ; 
	
	$SELECT FIRST 1 today,today-1 INTO $dbegin,$dend FROM systables ;   
	cm_split_ymd(cm_from_infdate(dbegin),yy_fn,mm_fn,dd_fn);
	
	if (itime_now == 11)
		sprintf(Fname_1,"�����q�l���n�O�Ѳ��s����[%s%s%s_11].html",yy_fn,mm_fn,dd_fn);
	else 
		sprintf(Fname_1,"�����q�l���n�O�Ѳ��s����[%s%s%s_17].html",yy_fn,mm_fn,dd_fn);
	sprintf(FileName_1,"%s/rptftp/%s",sApHome,Fname_1);
	printf("--FileName_1--[%s]\n",FileName_1);
	sfp2=fopen(FileName_1,"w");
	
	stmp[0] = '\0';stmp2[0] = '\0';
	printf("itime_now[%d] \n",itime_now);
	if (itime_now == 11)
	{
		/*�C��11:00�A���s�e�@��17:00~����11:00�J��Χ�諸�ɮ�*/
		strcpy(stmp,"AND b.dcreate BETWEEN EXTEND( today-1 , year to second) + INTERVAL (17) hour TO hour AND EXTEND( today , year to second) + INTERVAL (11) hour TO hour ");
		strcpy(stmp2,"AND f.dcreate BETWEEN EXTEND( today-1 , year to second) + INTERVAL (17) hour TO hour AND EXTEND( today , year to second) + INTERVAL (11) hour TO hour ");
		/*TEST*/
		/*strcpy(stmp,"AND b.dcreate BETWEEN EXTEND( date('02/22/2022') , year to second) + INTERVAL (17) hour TO hour AND EXTEND( date('02/23/2022') , year to second) + INTERVAL (11) hour TO hour ");
		strcpy(stmp2,"AND f.dcreate BETWEEN EXTEND( date('02/22/2022') , year to second) + INTERVAL (17) hour TO hour AND EXTEND( date('02/23/2022') , year to second) + INTERVAL (11) hour TO hour ");
		*/
	}
	else if(itime_now == 17)
	{
		/*�C��17:00�A���s����11:00~����17:00�J��Χ�諸�ɮ�*/
		strcpy(stmp,"AND b.dcreate BETWEEN EXTEND( today , year to second) + INTERVAL (11) hour TO hour AND EXTEND( today , year to second) + INTERVAL (17) hour TO hour ");
		strcpy(stmp2,"AND f.dcreate BETWEEN EXTEND( today , year to second) + INTERVAL (11) hour TO hour AND EXTEND( today , year to second) + INTERVAL (17) hour TO hour ");
		/*TEST*/
		/*
		strcpy(stmp,"AND b.dcreate BETWEEN EXTEND( date('02/23/2022') , year to second) + INTERVAL (11) hour TO hour AND EXTEND( date('02/23/2022') , year to second) + INTERVAL (17) hour TO hour ");
		strcpy(stmp2,"AND f.dcreate BETWEEN EXTEND( date('02/23/2022') , year to second) + INTERVAL (11) hour TO hour AND EXTEND( date('02/23/2022') , year to second) + INTERVAL (17) hour TO hour ");
		*/
	}
	printf("stmp[%s] \n",stmp);
	
	rc = chailease_prepare_data();  /*���s�J�檺�ɮ�*/
	if (rc != M_CM_OK)
		return rc;
		
	$DROP TABLE chailease;
	$DROP TABLE chailease_a;
	$DROP TABLE chailease_ins_type;
	$DROP TABLE chailease_tmp;
	car351_clear();

	rc = chailease_prepare_data2();  /*���s���ɨ��P�ɮ�*/
	if (rc != M_CM_OK)
		return rc;	

	$DROP TABLE chailease;
	$DROP TABLE chailease_a;
	$DROP TABLE chailease_ins_type;
	$DROP TABLE chailease_tmp;
	car351_clear();

	rc = car351_writelog();
	if (rc != M_CM_OK)
		return rc;  
}
/*----------------------------------------------------------------------------*/
long chailease_get_db()
{
    int	rc;

    if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "��Ʈw�L�k�}��!");
       return M_CM_DB_NOTOPEN;
    }
    
    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }
    
    if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
       if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
          return M_CM_NOT_DBLIST;
    }

    return M_CM_OK;
}
/*----------------------------------------------------------------------------*/
long chailease_prepare_data()  /*���s�e�@��17:00�ܷ���17:00���J���ɮ�*/
{
	int rc;
	$char stmt[2048];
	$char stmt2[2048];
	$char stmt2_1[2048];
	$char stmt2_2[2048];
	$char stmt3[2048];
	$WHENEVER SQLERROR GOTO errexit;

	$CREATE TEMP TABLE chailease 
	( 
      icard_1       char(20),      /*�j��d��*/
      itag          char(12),      /*�P�Ӹ��X*/
      dply_begin    char(11),      /*�O�I�_��*/
      ibrand        char(10),      /*�t�P����*/
      iengine       char(25),      /*�������X*/
      ipolicy_2     char(20),      /*���N�O�渹*/
      mcar_price    DECIMAL(10,0), /*���m����*/
      cover         char(10),      /*�O�I���B*/     
      prem_1        DECIMAL(20,0), /*�j���I�O�O*/
      prem_2        DECIMAL(20,0), /*���N�I�O�O*/
      prem_sum      DECIMAL(20,0)  /*�`�O�O*/
	) WITH NO LOG;
    
	$CREATE TEMP TABLE chailease_a /*�L���p�渹 ������ �ˬd���p��*/
	( 
      icard_1       char(20),      /*�j��d��*/
      itag          char(12),      /*�P�Ӹ��X*/
      dply_begin    char(11),      /*�O�I�_��*/
      ibrand        char(10),      /*�t�P����*/
      iengine       char(25),      /*�������X*/
      ipolicy_2     char(20),      /*���N�O�渹*/
      mcar_price    DECIMAL(10,0), /*���m����*/
      cover         char(10),      /*�O�I���B*/     
      prem_1        DECIMAL(20,0), /*�j���I�O�O*/
      prem_2        DECIMAL(20,0), /*���N�I�O�O*/
      prem_sum      DECIMAL(20,0)  /*�`�O�O*/
	) WITH NO LOG;
    
	$CREATE TEMP TABLE chailease_ins_type
	( 
      iins_type       char(6),   /*�I�إN��*/
      minjured_cover  integer,   /*�O�B�@*/
      mdeath_cover    integer,   /*�O�B�G*/
      mdamage_cover   integer,   /*�O�B�T*/
      mdeduct         integer,   /*�ۭt�B*/
      nins_type       char(28),  /*�I�ئW��*/
      daily_pay       integer,   /*56�I���������B*/
      qday            integer,   /*38.39��Q���{*/
      serial_no       serial     /*�Ǹ�*/
	) WITH NO LOG; 
       
	$CREATE TEMP TABLE chailease_tmp
	( 
      icard_tmp       char(20)   /*�j���Ҹ�*/

	) WITH NO LOG;  
/****************************************************************************************************/        
    /*�����p�渹_���N�O��*/
    sprintf(stmt_ins," \
	INSERT INTO  chailease  \
	SELECT c.icard ,a.itag ,to_char(b.dply_begin) , \
           b.ibrand ,a.iengine ,a.ipolicy ,a.mcar_price*10000 , \
           (SELECT nvl(max(mdamage_cover),0) FROM newa22:ply_ins_type e WHERE iins_type in ('01','02','05','07','09','10','11','17') AND e.ipolicy=a.ipolicy ), \
           c.mdmg_prem+c.mlia_prem,b.mdmg_prem+b.mlia_prem , \
           b.mdmg_prem+b.mlia_prem+c.mdmg_prem+c.mlia_prem \
	  FROM newa22:policy a,newa22:ply_relation b,newa22:ply_relation c \
	 WHERE a.iroute[1,10] IN ('PA05072925','PA27998148') AND a.ipolicy=b.ipolicy %s \
	   AND b.irelative_ply IS NOT NULL AND b.irelative_ply!='' AND b.fcard_class='2' AND c.ipolicy=b.irelative_ply ",stmp);
	$PREPARE ply_relaY_V FROM $stmt_ins;
	$EXECUTE ply_relaY_V;

    /*�����p�渹_�j��O��*/
    sprintf(stmt_ins," \
	INSERT INTO  chailease  \
	SELECT b.icard ,a.itag ,to_char(c.dply_begin) , \
           b.ibrand ,a.iengine ,c.ipolicy ,a.mcar_price*10000 ,  \
           (SELECT nvl(max(mdamage_cover),0) FROM newa22:ply_ins_type e WHERE iins_type in ('01','02','05','07','09','10','11','17') AND e.ipolicy=c.ipolicy ), \
           b.mdmg_prem+b.mlia_prem,c.mdmg_prem+c.mlia_prem , \
           b.mdmg_prem+b.mlia_prem+c.mdmg_prem+c.mlia_prem \
	  FROM newa22:policy a,newa22:ply_relation b,newa22:ply_relation c \
	 WHERE a.iroute[1,10] IN ('PA05072925','PA27998148') AND a.ipolicy=b.ipolicy %s \
	   AND b.irelative_ply IS NOT NULL AND b.irelative_ply!='' AND b.fcard_class='1' AND c.ipolicy=b.irelative_ply ",stmp);
	$PREPARE ply_relaY_C FROM $stmt_ins;
	$EXECUTE ply_relaY_C;
/****************************************************************************************************/       
    /*�L���p�渹_�L�P�~�j���Ҹ�_�j��O��*/
    sprintf(stmt_ins," \
	INSERT INTO  chailease \
	SELECT b.icard ,a.itag ,to_char(b.dply_begin) , \
           b.ibrand ,a.iengine ,'',a.mcar_price*10000, \
           0, \
           b.mdmg_prem+b.mlia_prem ,0 , \
           b.mdmg_prem+b.mlia_prem  \
      FROM newa22:policy a,newa22:ply_relation b \
     WHERE a.iroute[1,10] IN ('PA05072925','PA27998148') AND a.ipolicy=b.ipolicy %s \
           AND (b.irelative_ply IS NULL OR b.irelative_ply='') AND b.fcard_class='1' ",stmp);
	$PREPARE ply_relaN_cardN_C FROM $stmt_ins;
	$EXECUTE ply_relaN_cardN_C;
	
	sprintf(stmt_ins," \
	INSERT INTO  chailease_tmp \
	SELECT b.icard  \
	  FROM newa22:policy a,newa22:ply_relation b  \
	 WHERE a.iroute[1,10] IN ('PA05072925','PA27998148') AND a.ipolicy=b.ipolicy %s \
	   AND (b.irelative_ply IS NULL OR b.irelative_ply='') AND b.fcard_class='1' ",stmp);
	$PREPARE ply_relaN_cardY_C FROM $stmt_ins;
	$EXECUTE ply_relaN_cardY_C;       
            
    /*�L���p�渹_�L�P�~�j���Ҹ�_�u���*/
    sprintf(stmt_ins," \
    INSERT INTO  chailease \
	SELECT '' ,a.itag ,to_char(b.dply_begin) , \
	       b.ibrand ,a.iengine ,a.ipolicy,a.mcar_price*10000, \
	       (SELECT nvl(max(mdamage_cover),0) FROM newa22:ply_ins_type e  WHERE iins_type in ('01','02','05','07','09','10','11','17')  AND e.ipolicy=a.ipolicy ), \
	       0,b.mdmg_prem+b.mlia_prem, \
	       b.mdmg_prem+b.mlia_prem  \
	  FROM newa22:policy a,newa22:ply_relation b  \
	 WHERE a.iroute[1,10] IN ('PA05072925','PA27998148') AND a.ipolicy=b.ipolicy %s \
	   AND (b.irelative_ply IS NULL OR b.irelative_ply='') AND b.fcard_class='2' AND len(a.ipolicy)=13 \
	   AND (a.ixxcard IS NULL or a.ixxcard='') ",stmp);
	$PREPARE ply_relaN_cardN_V FROM $stmt_ins;
	$EXECUTE ply_relaN_cardN_V;

    /*�L���p�渹_���P�~�j���Ҹ�_���N�O��*/
	sprintf(stmt_ins," \
	INSERT INTO  chailease \
	SELECT c.icard ,c.itag ,to_char(d.dply_begin) , \
	       d.ibrand ,c.iengine ,a.ipolicy,c.mcar_price*10000,  \
	       (SELECT nvl(max(mdamage_cover),0) FROM newa22:ply_ins_type e  WHERE iins_type in ('01','02','05','07','09','10','11','17')  AND e.ipolicy=a.ipolicy ), \
	       d.mdmg_prem+d.mlia_prem,b.mdmg_prem+b.mlia_prem, \
	       d.mdmg_prem+d.mlia_prem+b.mdmg_prem+b.mlia_prem \
	  FROM newa22:policy a,newa22:ply_relation b ,newa22:policy c,newa22:ply_relation d  \
	 WHERE a.iroute[1,10] IN ('PA05072925','PA27998148') AND a.ipolicy=b.ipolicy %s \
	   AND len(a.ipolicy)=13 \
	   AND (b.irelative_ply IS NULL OR b.irelative_ply='') AND b.fcard_class='2' \
	   AND a.ixxcard IS NOT NULL AND a.ixxcard<>'' AND (c.icard=a.ixxcard OR c.icard=a.ixxcard[3,12]) \
	   AND c.ipolicy=d.ipolicy ",stmp);
	$PREPARE ply_relaN_cardY_V FROM $stmt_ins;
	$EXECUTE ply_relaN_cardY_V; 
/****************************************************************************************************/            
	/*���p�ˬd*/ 
	/* rc = chailease_relative_ply_check();
	if (rc != M_CM_OK) 
	return rc; */    
    /*�R���L���������p�O�榳������A�קK���Ʋ���*/
	strcpy(stmt, "SELECT DISTINCT a.icard_1  "
                 "  FROM chailease a ,newa22:policy b,newa22:policy c"
                 " WHERE (a.itag IS NULL OR a.itag='') AND a.icard_1 IS NOT NULL AND a.icard_1 !='' " 
                 "       AND a.ipolicy_2 IS NOT NULL AND a.ipolicy_2 !='' AND b.icard=a.icard_1 AND c.ipolicy=a.ipolicy_2"
                 "       AND (( b.itag IS NOT NULL AND b.itag !='' ) OR ( c.itag IS NOT NULL AND c.itag !='' ));");
	printf("stmt[%s]\n",stmt);
	$PREPARE prep3 FROM $stmt;
	$DECLARE curs3 CURSOR FOR prep3;
	$OPEN curs3;
	for(;;)
	{
		$FETCH curs3 INTO $icard_delete;

		if( SQLCODE == SQLNOTFOUND) break;
		printf("icard_delete[%s]\n",icard_delete);
		sprintf(stmt2, "DELETE chailease WHERE icard_1='%s' AND (itag IS NULL OR itag='') ",icard_delete);
		$PREPARE pre_delete from $stmt2;
		$EXECUTE pre_delete ; 
    }
	$FREE prep3;
	$CLOSE curs3;
  
    /*�R������*/
	strcpy(stmt, "SELECT DISTINCT a.icard_1  "
                 "  FROM chailease a "
                 " WHERE a.icard_1 IN (SELECT icard_tmp FROM chailease_tmp) AND a.ipolicy_2 <> '' AND a.ipolicy_2 IS NOT NULL;");
	printf("stmt[%s]\n",stmt);
	$PREPARE prep4 FROM $stmt;
	$DECLARE curs4 CURSOR FOR prep4;
	$OPEN curs4;
	for(;;)
	{
		$FETCH curs4 INTO $icard_delete;
		
		if( SQLCODE == SQLNOTFOUND) break;
		printf("icard_delete[%s]\n",icard_delete);
		sprintf(stmt2, "DELETE chailease WHERE icard_1='%s' AND (ipolicy_2 IS NULL OR ipolicy_2='') ",icard_delete);
		$PREPARE pre_delete2 from $stmt2;
		$EXECUTE pre_delete2 ; 
	}
	$FREE prep4;
	$CLOSE curs4;
  
	/*�@���@���q chailease temp tableŪ���X*/
	strcpy(stmt, "SELECT  DISTINCT icard_1,itag,dply_begin,chr(127)||ibrand,iengine,ipolicy_2,mcar_price,cover,prem_1,prem_2,prem_sum FROM chailease  ");
	printf("stmt[%s]\n",stmt);
	$PREPARE prep1 FROM $stmt;
	$DECLARE curs1 CURSOR FOR prep1;
	$OPEN curs1;
	for(;;)
	{

		$FETCH curs1 INTO $icard_1,$itag,$dply_begin,$ibrand,$iengine,$ipolicy_2,$mcar_price,$cover,$prem_1,$prem_2,$prem_sum;
		
		if( SQLCODE == SQLNOTFOUND) break;
		
		printf("icard_1[%s]itag[%s]dply_begin[%s]ibrand[%s]iengine[%s]ipolicy_2[%s]mcar_price[%s]cover[%s]prem_1[%s]prem_2[%s]prem_sum[%s]\n",icard_1,itag,dply_begin,ibrand,iengine,ipolicy_2,mcar_price,cover,prem_1,prem_2,prem_sum);
		
		/*strcpy(Full_DBName1,get_car_full_db(trim(ipolicy_1)));
		strcpy(Full_DBName2,get_car_full_db(trim(ipolicy_2)));*/
		/*���o�ӫO��ҫO���j+���Ҧ��I��insert�Jtemp table�A�j���I��Ĥ@��*/
        
		/*�j��*/
		if(strcmp(trim(icard_1),"")!=0)
		{
            sprintf(stmt2, "INSERT INTO  chailease_ins_type (iins_type,minjured_cover,mdeath_cover,mdamage_cover,mdeduct,nins_type,daily_pay,qday) \n"
		           "     SELECT  a.iins_type,a.minjured_cover,a.mdeath_cover,a.mdamage_cover,a.mdeduct,b.nins_type,0,0 \n"
		           "       FROM  newa22:ply_ins_type a,insurance_type b,newa22:policy c   \n"
                           "      WHERE  c.icard='%s' AND a.iins_type=b.iins_type AND c.ipolicy=a.ipolicy; \n" ,trim(icard_1));
            $PREPARE pre_ins1 from $stmt2;
            $EXECUTE pre_ins1 ;   
		}             
        /*���N*/
		if(strcmp(trim(ipolicy_2),"")!=0)
		{
            sprintf(stmt2, "INSERT INTO  chailease_ins_type (iins_type,minjured_cover,mdeath_cover,mdamage_cover,mdeduct,nins_type,daily_pay,qday) \n"
		           "     SELECT  a.iins_type,a.minjured_cover,a.mdeath_cover,a.mdamage_cover,case when a.mdeduct <0 then 0 else a.mdeduct end,b.nins_type, \n"
		           "             CASE WHEN  a.iins_type='56' THEN (SELECT daily_pay FROM (SELECT FIRST 1 c.daily_pay FROM newa22:ca_pa_ply c WHERE c.ipolicy=a.ipolicy))  ELSE 0 END ,\n"
		           "             CASE WHEN  a.iins_type='38' OR a.iins_type='39' THEN  a.qday  ELSE 0 END \n"
		           "       FROM  newa22:ply_ins_type a,insurance_type b   \n"
                           "      WHERE  ipolicy='%s' AND a.iins_type=b.iins_type ORDER BY CAST(a.iins_type AS integer); \n",trim(ipolicy_2));
			$PREPARE pre_ins2 from $stmt2;
			$EXECUTE pre_ins2 ;         
		}
		rc = chailease_build_main();
		if (rc != M_CM_OK) 
		return rc;
	}
	$FREE prep1;
	$CLOSE curs1;
	$FREE curs1;
	
	return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(1);
}

/*----------------------------------------------------------------------------*/
long chailease_build_main()
{
	int	rc;
	char yy[4], mm[3], dd[3],yy2[5];
	$char stmt4[2048];
	$char stmt5[100];
	$char field1_chk[41];
	$char stmt15[100];
	cm_split_ymd(cm_from_infdate(dply_begin),yy,mm,dd);
	strcpy(yy2,itoa(atoi(yy)+1911));
	sprintf(dply_begin2,"%s%s%s",yy2,mm,dd);
	printf("%s\n",dply_begin2);
	
	if(strcmp(trim(icard_1),"")!=0)
	{
		sprintf(icard_1,"17%s",trim(icard_1));	
	}
        
	$whenever sqlerror goto errexit;
	memset(fname,0x00,sizeof(fname));
	memset(filename,0x00,sizeof(filename));

	if (strcmp(trim(icard_1),"")!=0 && strcmp(trim(ipolicy_2),"")!=0)
	{
		if (strcmp(trim(itag),"")==0)
		{
			if(strcmp(trim(icard_1),"")!=0)
			{
				sprintf(fname," �j���Ҹ� %s",trim(icard_1));
			}
			else
			{
				sprintf(fname," ���N�渹 %s",trim(ipolicy_2));
			}
			strcpy(stmt5,"�����s�ɮסA�L���P");	    		
		}
		else
		{
			sprintf(fname,"%s_%s",trim(itag),dply_begin2);
			strcpy(stmt5,"�w���s�ɮ�");    	    			
		}
	}
	else if (strcmp(trim(icard_1),"")!=0 && strcmp(trim(ipolicy_2),"")==0)
	{
		if (strcmp(trim(itag),"")==0)
		{
			sprintf(fname," �j���Ҹ� %s",trim(icard_1));
			strcpy(stmt5,"�����s�ɮסA�L���P");
		}
		else
		{
			sprintf(fname,"%s_%s",trim(itag),dply_begin2);
			strcpy(stmt5,"�����s�ɮ�");
		}
	}
	else if (strcmp(trim(icard_1),"")==0 && strcmp(trim(ipolicy_2),"")!=0)
	{
		if (strcmp(trim(itag),"")==0)
		{
			sprintf(fname," ���N�渹 %s",trim(ipolicy_2));
			strcpy(stmt5,"�����s�ɮסA�L���P");
		}
		else
		{
			sprintf(fname,"%s_%s",trim(itag),dply_begin2);
			strcpy(stmt5,"�����s�ɮ�");
		}	
	}
	else
	{
		strcpy(stmt5,"�����s�ɮ�");
	}

	/*�L���P�����s�ɮפ��߰e*/
	/*��j�γ�������s�ɮפ��߰e*/
	if (strcmp(trim(itag),"")!=0 && strcmp(trim(icard_1),"")!=0 && strcmp(trim(ipolicy_2),"")!=0 )
	{
		sprintf(filename,"%s/rptftp/car351/%s.xls",sApHome,fname);
		printf("filename[%s]\n",filename);
		fp=fopen(filename,"w");
		strcpy(ftitle,"�O�I���q�W��\t�O�I���q�Τ@�s��\t�j��O�I���X\t�P�Ӹ��X\t�O�I����(�_)\t�t�P����\t�������X\t���N�O�渹�X\t���m����\t�O�I���B\t�j���I�O�O\t���N�I�O�O\t�`�O�O\n");	
		fprintf(fp,ftitle);
		fprintf(fp,"�s�w�F�ʮ��W\t16099078\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n",trim(icard_1),itag,dply_begin2,ibrand,iengine,ipolicy_2,mcar_price,cover,prem_1,prem_2,prem_sum);
		fprintf(fp," \n");
		fprintf(fp,"�O�I�N�X\t�O�I���B�@\t�O�I���B�G\t�O�I���B���\t�Ƶ�\n");

		/*���P�I�ءA��m��즳�Ҥ��P*/
		rc = chailease_build_dtl();
		if (rc != M_CM_OK) 
			return rc; 
			      
		fclose(fp);		

		rc=rptftpinsert(userid,"car351", fname );
		if (rc!=0)
		{
			printf( "�g�Jrptftplist���~\n");
			return rc;
		}	
	}

	$DELETE  chailease_ins_type WHERE 1=1;
	
	sprintf(ReportName,"%-35.35s",fname);
	
	if (strcmp(trim(icard_1),"")!=0 && strcmp(trim(ipolicy_2),"")!=0)
	{
		strcpy(stmt4,"�j+��");	
	}
	else if (strcmp(trim(icard_1),"")!=0 && strcmp(trim(ipolicy_2),"")==0)
	{
		strcpy(stmt4,"��j");
	}
	else if (strcmp(trim(icard_1),"")==0 && strcmp(trim(ipolicy_2),"")!=0)
	{
		strcpy(stmt4,"���");	
	}
	else
	{
		strcpy(stmt4,"���~");
	}
    	
	/*�ɦW����*/
	if (strcmp(trim(itag),"")!=0)
	{
		sprintf(stmt15, "SELECT field1 FROM car351_log WHERE field1='%s';",trim(fname));
		printf("stmt15[%s]\n",stmt15);
		$PREPARE prep15 FROM $stmt15;
		$DECLARE curs15 CURSOR FOR prep15;
		$OPEN curs15;
		for(;;)
		{
			$FETCH curs15 INTO $field1_chk;
			if( SQLCODE == SQLNOTFOUND) break;
			printf("field1_chk[%s]\n",field1_chk);
		
			$UPDATE car351_log SET field4='�ɦW����' WHERE field1=$field1_chk;
		}
		$FREE prep15;
		$CLOSE curs15;
	}
        
	$INSERT INTO car351_log(field1,field2,field3,field4)
	 VALUES(trim($fname),trim($prem_sum),trim($stmt4),trim($stmt5));
    	 
	return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
} 
/*----------------------------------------------------------------------------*/
long chailease_build_dtl()
{
	int	rc;
	$char stmt[2048];
	
	$whenever sqlerror goto errexit;
	
	/*���P�I�ءA��m��즳�Ҥ��P*/
	/*�O�I�N�X�B�O�I���B�@�B�O�I���B�G�B�O�I���B���B�Ƶ�*/

	strcpy(stmt, "SELECT iins_type,minjured_cover,mdeath_cover,mdamage_cover,mdeduct,nins_type,daily_pay,qday FROM chailease_ins_type order by serial_no");
	printf("stmt[%s]\n",stmt);
	$PREPARE prep2 FROM $stmt;
	$DECLARE curs2 CURSOR FOR prep2;
	$OPEN curs2;
	for(;;)
    {
		$FETCH curs2 INTO $iins_type,$minjured_cover,$mdeath_cover,$mdamage_cover,$mdeduct,$nins_type,$daily_pay,$qday; 
		
		if( SQLCODE == SQLNOTFOUND) break;
		
		strcpy(iins_type,trim(iins_type));
		
		/*21�A�u���I�إN�X�A����O�B*/
		if(strcmp(iins_type,"21")==0)      
		{
			fprintf(fp,"%s\t%s\t%s\t%s\t%s\n",iins_type,"","","",nins_type);
		}
		/*01.05.09�A�u���I�إN�X�A����O�B*/
		else if(strcmp(iins_type,"01")==0 || strcmp(iins_type,"05")==0 || strcmp(iins_type,"09")==0) 
		{
			fprintf(fp,"%s\t%s\t%s\t%s\t%s\n",iins_type,"","","",nins_type);
		}
		/*02�A�u���I�إN�X�A����O�B*/
		else if(strcmp(iins_type,"02")==0) 
		{
			fprintf(fp,"%s\t%s\t%s\t%s\t%s\n",iins_type,"","","",nins_type);
		}            
		/*07�A�u���I�إN�X�A����O�B*/
		else if(strcmp(iins_type,"07")==0) 
		{
			fprintf(fp,"%s\t%s\t%s\t%s\t%s\n",iins_type,"","","",nins_type);
		}       
		/*10�A�u���I�إN�X�A����O�B*/
		else if(strcmp(iins_type,"10")==0) 
		{
			fprintf(fp,"%s\t%s\t%s\t%s\t%s\n",iins_type,"","","",nins_type);
		}               
		/*11�A�O�B�@��ۭt�B�A����%*/
		else if(strcmp(iins_type,"11")==0) 
		{
			fprintf(fp,"%s\t%s\t%s\t%s\t%s\n",iins_type,mdeduct,"","%",nins_type);
		} 
		/*12�A�u���I�إN�X�A����O�B*/
		else if(strcmp(iins_type,"12")==0) 
		{
			fprintf(fp,"%s\t%s\t%s\t%s\t%s\n",iins_type,"","","",nins_type);
		}             
		/*17�A�u���I�إN�X�A����O�B*/
		else if(strcmp(iins_type,"17")==0) 
		{
			fprintf(fp,"%s\t%s\t%s\t%s\t%s\n",iins_type,"","","",nins_type);
		}              
		/*19�A�O�B�@��mdamage_cover/30(���B)�A����"��"*/
		else if(strcmp(iins_type,"19")==0) 
		{
			/*sprintf(mdamage_cover2,"%.1f",atof(mdamage_cover)/10000);*/
			fprintf(fp,"%s\t%s\t%s\t%s\t%s\n",iins_type,itoa(atoi(mdamage_cover)/30),"","��",nins_type);
		}   
		/*24�A�u���I�إN�X�A����O�B*/
		else if(strcmp(iins_type,"24")==0) 
		{
			fprintf(fp,"%s\t%s\t%s\t%s\t%s\n",iins_type,"","","",nins_type);
		}             
		/*27�A�O�B�@��mdamage_cover�A����"�U"*/
		else if(strcmp(iins_type,"27")==0) 
		{
			fprintf(fp,"%s\t%s\t%s\t%s\t%s\n",iins_type,itoa(atoi(mdamage_cover)/10000),"","�U",nins_type);
		}              
		/*28�A�O�B�@��mdamage_cover�A����"�U"*/
		else if(strcmp(iins_type,"28")==0) 
		{
			fprintf(fp,"%s\t%s\t%s\t%s\t%s\n",iins_type,itoa(atoi(mdamage_cover)/10000),"","�U",nins_type);
		}             
		/*30�A�O�B�@��mdamage_cover�A����"�U"*/
		else if(strcmp(iins_type,"30")==0) 
		{
			fprintf(fp,"%s\t%s\t%s\t%s\t%s\n",iins_type,itoa(atoi(mdamage_cover)/10000),"","�U",nins_type);
		}             
		/*31�A�O�B�@��minjured_cover�A�O�B�G��mdamage_cover�A����"�U"*/
		else if(strcmp(iins_type,"31")==0) 
		{
			strcpy(minjured_cover2,itoa(atoi(minjured_cover)/10000));
			strcpy(mdamage_cover2,itoa(atoi(mdamage_cover)/10000));
			fprintf(fp,"%s\t%s\t%s\t%s\t%s\n",iins_type,minjured_cover2,mdamage_cover2,"�U",nins_type);
		}             
		/*32�A�O�B�@��mdamage_cover�A����"�U"*/
		else if(strcmp(iins_type,"32")==0) 
		{
			fprintf(fp,"%s\t%s\t%s\t%s\t%s\n",iins_type,itoa(atoi(mdamage_cover)/10000),"","�U",nins_type);
		}             
		/*34�A�O�B�@��mdamage_cover�A����"�U"*/
		else if(strcmp(iins_type,"34")==0) 
		{
			fprintf(fp,"%s\t%s\t%s\t%s\t%s\n",iins_type,itoa(atoi(mdamage_cover)/10000),"","�U",nins_type);
		} 
		/*38�A�O�B�@��mdamage_cover�A����"�U"*/
		else if(strcmp(iins_type,"38")==0) 
		{
			strcpy(mdamage_cover2,itoa(atoi(mdamage_cover)/10000));
			fprintf(fp,"%s\t%s\t%s\t%s\t��Q���{%s�����C%s\n",iins_type,mdamage_cover2,"","�U",trim(qday),nins_type);
		}
		/*39�A�O�B�@��mdamage_cover�A����"�U"*/
		else if(strcmp(iins_type,"39")==0) 
		{
			strcpy(mdamage_cover2,itoa(atoi(mdamage_cover)/10000));
			fprintf(fp,"%s\t%s\t%s\t%s\t��Q���{%s�����C%s\n",iins_type,mdamage_cover2,"","�U",trim(qday),nins_type);
		}                                    
		/*55�A�O�B�@��mdeath_cover�A����"�U"*/
		else if(strcmp(iins_type,"55")==0) 
		{
			fprintf(fp,"%s\t%s\t%s\t%s\t%s\n",iins_type,itoa(atoi(mdeath_cover)/10000),"","�U",nins_type);
		}             
		/*56�A�O�B�@��mdamage_cover�A�O�B�G��daily_pay�A����"�U/��"*/
		else if(strcmp(iins_type,"56")==0) 
		{
			fprintf(fp,"%s\t%s\t%s\t%s\t%s\n",iins_type,itoa(atoi(mdamage_cover)/10000),daily_pay,"�U/��",nins_type);
		}   
		/*62�A�O�B�@��minjured_cover�A�O�B�G��mdamage_cover�A����"��"*/
		else if(strcmp(iins_type,"62")==0) 
		{
			fprintf(fp,"%s\t%s\t%s\t%s\t%s\n",iins_type,minjured_cover,mdamage_cover,"��",nins_type);
		}              
		/*143�A�O�B�@��minjured_cover�A�O�B�G��mdamage_cover�A����"��"*/
		else if(strcmp(iins_type,"143")==0) 
		{
			fprintf(fp,"%s\t%s\t%s\t%s\t%s\n",iins_type,minjured_cover,mdamage_cover,"��",nins_type);
		}         
		else
		{
			fprintf(fp,"%s\t%s\t%s\t%s\t%s\n",iins_type,"","","",nins_type);
		}                           
	}
	$FREE prep2;
	$CLOSE curs2;
	$FREE curs2;
	
	return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
} 
/*----------------------------------------------------------------------------*/
long chailease_relative_ply_check()
{
   int	rc;
   $char stmt[2048];
   $char stmt2[2048];
   $char stmt2_0[2048];
   $char stmt2_1[2048];
   $char stmt2_2[2048];
   $char stmt2_3[2048];
   $char stmt3[2048];
   $int  cnt_xx;
   $whenever sqlerror goto errexit;
	
     /*���p�ˬd*//*�H�P�~�j���Ҹ��P�_��̬O�_���p*//*���s�b�P�@excel�ɤ�*/
    /*�@���@���q chailease_a temp tableŪ���X*/       
    strcpy(stmt, "SELECT DISTINCT icard_1 FROM chailease_a ");
    printf("stmt[%s]\n",stmt);
    $PREPARE prep0 FROM $stmt;
    $DECLARE curs0 CURSOR FOR prep0;
    $OPEN curs0;
    for(;;)
    {
		strcpy(icard_1_a,"");
        strcpy(prem_1_a,"0");
        strcpy(ipolicy_2_a,"");
        strcpy(prem_2_a,"0");
        cnt_xx=0;

        $FETCH curs0 INTO $icard_1_a;
        
      
        if( SQLCODE == SQLNOTFOUND) break;
        
        strcpy(icard_1_a,trim(icard_1_a));
        printf("icard_1_a[%s]\n",icard_1_a);

        sprintf(stmt2_0, "SELECT count(*) FROM newa22:policy WHERE ixxcard='%s' OR ixxcard='17'||'%s'  \n",icard_1_a,icard_1_a);
        printf("stmt2_0[%s]\n",stmt2_0);          
        $PREPARE pre2_0 from $stmt2_0;
        $EXECUTE pre2_0 INTO $cnt_xx; 

        if(cnt_xx==0)
        {
            /*�䤣��A�u��j*/
            sprintf(stmt3, " INSERT INTO chailease "
                           "  SELECT first 1 * FROM chailease_a WHERE icard_1='%s' \n",icard_1_a);
            $PREPARE pre3 from $stmt3;
            $EXECUTE pre3 ;  
        }
        else
        {
            /*���A��_��*/
           
            sprintf(stmt2_1, "SELECT first 1 c.icard ,case when (c.itag is null or c.itag='') then a.itag else c.itag end ,to_char(d.dply_begin) ,"
                             "       d.ibrand ,c.iengine ,a.ipolicy,c.mcar_price*10000, "
                             "       (SELECT nvl(max(mdamage_cover),0) FROM newa22:ply_ins_type e  WHERE iins_type in ('01','02','05','07','09','10','11','17')  AND e.ipolicy=a.ipolicy ),"
                             "       d.mdmg_prem+d.mlia_prem,b.mdmg_prem+b.mlia_prem"
                             " FROM  newa22:policy a,newa22:ply_relation b ,newa22:policy c,newa22:ply_relation d "
                             "WHERE  a.ipolicy=b.ipolicy AND len(a.ipolicy)=13"
                             "  AND  b.fcard_class='2' "
                             "  AND  a.ixxcard IS NOT NULL AND a.ixxcard<>'' AND (c.icard=a.ixxcard OR c.icard=a.ixxcard[3,12])"
                             "  AND  c.ipolicy=d.ipolicy AND c.icard='%s' " ,icard_1_a);
            printf("stmt2_1[%s]\n",stmt2_1);               
            $PREPARE pre2_1 from $stmt2_1;   
            $EXECUTE pre2_1 INTO $icard_1_a,$itag_a,$dply_begin_a,$ibrand_a,$iengine_a,$ipolicy_2_a,$mcar_price_a,$cover_a,$prem_1_a,$prem_2_a;
      
            printf("icard_1_a[%s]\n itag_a[%s]\n dply_begin_a[%s]\n ibrand_a[%s]\n iengine_a[%s]\n ipolicy_2_a[%s]\n",icard_1_a,itag_a,dply_begin_a,ibrand_a,iengine_a,ipolicy_2_a);
            printf("mcar_price_a[%d]\n cover_a[%s]\n prem_1_a[%d]\n prem_2_a[%d]\n ",atoi(mcar_price_a),cover_a,atoi(prem_1_a),atoi(prem_2_a));
            sprintf(stmt2_2, " INSERT INTO chailease "
                             " VALUES ('%s','%s','%s','%s','%s','%s',%d,'%s',%d,%d,%d) \n",icard_1_a,itag_a,dply_begin_a,ibrand_a,iengine_a,ipolicy_2_a,atoi(mcar_price_a),cover_a,atoi(prem_1_a),atoi(prem_2_a),atoi(prem_1_a)+atoi(prem_2_a));
            $PREPARE pre2_2 from $stmt2_2;
            $EXECUTE pre2_2 ;             
        }
    }
    $FREE prep0;
    $CLOSE curs0;
    $FREE curs0;
     
	return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
} 
/*********************************************************************************/
char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
	char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
	char sTmp_db_name[21];
	
	sTmp_db_name[0]='\0';
	if (*sIpolicy != '\0' && *sIpolicy !=' ')
	{
		sTmp_db_name[0]='\0';
		strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
		strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,	USE_BRANCH_ID));
		strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
	}
	return sTmp_db_name;
}
/*----------------------------------------------------------------------------*/
long chailease_prepare_data2()  /*���s�e�@��17:00�ܷ���17:00�����ɨ��P�ɮ�*/
{
	int rc;
	$char stmt[2048];
	$char stmt2[2048];
	$char stmt6[2048];
	$char stmt7[2048];
	$char stmt8_1[2048];
	$char stmt8_2[2048];
	$char stmt8_3[2048];
	$char stmt8_4[2048];  
	$char stmt8_5[2048]; 
	$char stmt8_6[2048]; 
	$char stmt8_7[2048]; 
	$char stmt9[2048];
	$char stmt10[2048];
	$int  cnt_check1;
	$WHENEVER SQLERROR GOTO errexit;

	$CREATE TEMP TABLE chailease 
	( 
	  icard_1       char(20),      /*�j��d��*/
	  itag          char(12),      /*�P�Ӹ��X*/
	  dply_begin    char(11),      /*�O�I�_��*/
	  ibrand        char(10),      /*�t�P����*/
	  iengine       char(25),      /*�������X*/
	  ipolicy_2     char(20),      /*���N�O�渹*/
	  mcar_price    DECIMAL(10,0), /*���m����*/
	  cover         char(10),      /*�O�I���B*/     
	  prem_1        DECIMAL(20,0), /*�j���I�O�O*/
	  prem_2        DECIMAL(20,0), /*���N�I�O�O*/
	  prem_sum      DECIMAL(20,0)  /*�`�O�O*/
	) WITH NO LOG;
	
	$CREATE TEMP TABLE chailease_a /*�L���p�渹 ������ �ˬd���p��*/
	( 
	  icard_1       char(20),      /*�j��d��*/
	  itag          char(12),      /*�P�Ӹ��X*/
	  dply_begin    char(11),      /*�O�I�_��*/
	  ibrand        char(10),      /*�t�P����*/
	  iengine       char(25),      /*�������X*/
	  ipolicy_2     char(20),      /*���N�O�渹*/
	  mcar_price    DECIMAL(10,0), /*���m����*/
	  cover         char(10),      /*�O�I���B*/     
	  prem_1        DECIMAL(20,0), /*�j���I�O�O*/
	  prem_2        DECIMAL(20,0), /*���N�I�O�O*/
	  prem_sum      DECIMAL(20,0)  /*�`�O�O*/
	) WITH NO LOG;
	
	$CREATE TEMP TABLE chailease_ins_type
	( 
	  iins_type       char(6),   /*�I�إN��*/
	  minjured_cover  integer,   /*�O�B�@*/
	  mdeath_cover    integer,   /*�O�B�G*/
	  mdamage_cover   integer,   /*�O�B�T*/
	  mdeduct         integer,   /*�ۭt�B*/
	  nins_type       char(28),  /*�I�ئW��*/
	  daily_pay       integer,   /*56�I���������B*/
	  qday            integer,   /*38.39��Q���{*/
	  serial_no       serial     /*�Ǹ�*/
	) WITH NO LOG;   
	 
	$CREATE TEMP TABLE chailease_tmp
	( 
	  icard_tmp       char(20)   /*�j���Ҹ�*/
	
	) WITH NO LOG; 

    /*�����}�M���*/ /*�ӧ�榳���P*/ /*��l�O��L���P���X*/
    sprintf(stmt6," SELECT  d.ipolicy,a.iendorse,d.fcard_class "
                  "   FROM  newa22:endorsement a, newa22:edr_relation b, newa22:original_ply c,"
                  "         newa22:ply_relation d "
                  "  WHERE  a.iroute[1,10] IN ('PA05072925','PA27998148') "
                  "    AND  a.iendorse=b.iendorse "
                  "    AND  a.iendorse NOT LIKE '%%CVP%%' "
                  "    AND  a.itag IS NOT NULL AND a.itag !='' "
                  "    AND  b.ipolicy=c.ipolicy "
                  "    AND  c.ipolicy=d.ipolicy "
                  "    AND  (c.itag IS NULL OR c.itag='') "
                  "    %s "
                  "    AND  (SELECT count(*) FROM newa22:policy e,newa22:ply_relation f WHERE e.ipolicy=f.ipolicy %s AND e.itag=a.itag)=0 ",stmp,stmp2);
                 /*"    AND  (SELECT count(*) FROM newa22:policy e,newa22:ply_relation f WHERE e.ipolicy=f.ipolicy AND  date(f.dcreate) BETWEEN '03/01/2021' AND '03/05/2021'  AND  e.itag=a.itag)=0 ");*/
    printf("stmt6[%s]\n",stmt6);
    $PREPARE prep6 FROM $stmt6;
    $DECLARE curs6 CURSOR FOR prep6;
    $OPEN curs6;
    for(;;)
    {

        $FETCH curs6 INTO $sIpolicy_data2,$sIendorse_data2,$sFcard_class_data2;
        cnt_check1=0;
      
        if( SQLCODE == SQLNOTFOUND) break;
        
        /*����ӫO��Ҧ������P��椤�̦���*/ /*���O�_�O�ӱi���*/
        /*�O�̦������ܬO�Ĥ@����郞�P*/  /*���O�̦������ܤ��e�w�����L���P�A�o���O����L���A�����Ʋ��s�ɮ�*/
        printf("sIpolicy_data2[%s]sIendorse_data2[%s]sFcard_class_data2[%s]\n",sIpolicy_data2,sIendorse_data2,sFcard_class_data2);
        
        sprintf(stmt7,   "SELECT  FIRST 1 a.iendorse \n"
		         "  FROM  newa22:edr_relation a ,newa22:endorsement b  \n"
                         " WHERE  a.iendorse=b.iendorse \n"
                         "   AND  b.itag IS NOT NULL AND b.itag !='' \n"
                         "   AND  a.ipolicy = '%s' "
                         " ORDER BY a.dcreate ",trim(sIpolicy_data2));
        printf("stmt7[%s]\n",stmt7);               
        $PREPARE pre7 from $stmt7;
        $EXECUTE pre7 INTO $sIendorse_first;  
        strcpy(sIendorse_first,trim(sIendorse_first));
        strcpy(sIendorse_data2,trim(sIendorse_data2));
        printf("sIendorse_first[%s]sIendorse_data2[%s]\n",sIendorse_first,sIendorse_data2); 
        if( SQLCODE == SQLNOTFOUND) break;
        	
        if ( strcmp(sIendorse_data2,sIendorse_first)==0  )
        {
            /*�O�̦���郞�P�����*/
            
            /*�ˮָӫO��O�_�����h�O*/ /*�P�_�ӫO�� �I�ة����� ���O���~�h�O�����ơA�j��0���ܦ��D���~�h�O���I�ئs�b*/
            $SELECT  count(*) 
               INTO  $cnt_check1
               FROM  newa22:ply_ins_type 
              WHERE  ipolicy= $sIpolicy_data2
                AND  fedr_status!='1';
               
             printf("cnt_check1[%d]\n",cnt_check1);  

             if(cnt_check1>0)   
             {
                 /* cnt_check1>0�A�����h�O�I�ءA���s�ɮ�*/
                 if( strcmp(sFcard_class_data2,"1")==0 )
                 {
            	     /*�j��O����ɨ��P*/ /*�����p�O�渹*/
            	     sprintf(stmt8_1,"INSERT INTO chailease "
		                     "SELECT b.icard ,a.itag,to_char(b.dply_begin),b.ibrand,a.iengine, "
                                     "       CASE WHEN b.irelative_ply IS NULL OR b.irelative_ply='' THEN '' ELSE b.irelative_ply END , "
                                     "       a.mcar_price *10000 , "
                                     "       CASE WHEN b.irelative_ply IS NULL OR b.irelative_ply='' THEN 0 ELSE "
                                     "       (SELECT nvl(max(mdamage_cover),0) FROM newa22:ply_ins_type e  WHERE iins_type in ('01','02','05','07','09','10','11','17')  AND e.ipolicy=b.irelative_ply ) END , "
                                     "       b.mdmg_prem+b.mlia_prem ,"
                                     "       CASE WHEN b.irelative_ply IS NULL OR b.irelative_ply='' THEN 0 ELSE "
                                     "       (SELECT mdmg_prem+mlia_prem FROM newa22:ply_relation WHERE ipolicy=b.irelative_ply) end ,"
                                     "       CASE WHEN b.irelative_ply IS NULL OR b.irelative_ply='' THEN b.mdmg_prem+b.mlia_prem ELSE "
                                     "       b.mdmg_prem+b.mlia_prem+(SELECT mdmg_prem+mlia_prem FROM newa22:ply_relation WHERE ipolicy=b.irelative_ply) END "
                                     "  FROM newa22:policy a ,newa22:ply_relation b "
                                     " WHERE a.ipolicy= '%s' AND a.ipolicy=b.ipolicy"
                                     "   AND b.irelative_ply IS NOT NULL AND b.irelative_ply!='' AND b.fcard_class='1' ",trim(sIpolicy_data2));
                     printf("stmt8_1[%s]\n",stmt8_1);               
                     $PREPARE pre8_1 from $stmt8_1;
                     $EXECUTE pre8_1 ;  
                     
                     /*�j��*/ /*�L���p�O�渹*//*����N�I�P�~�j���Ҹ�����ӱi�j���Ҹ����O��*/
            	     sprintf(stmt8_2,"INSERT INTO chailease "
		                     "SELECT b.icard ,a.itag,to_char(b.dply_begin),b.ibrand,a.iengine, "
                                     "       CASE WHEN c.ipolicy IS NULL THEN '' ELSE c.ipolicy END , "
                                     "       a.mcar_price *10000 , "
                                     "       CASE WHEN c.ipolicy IS NULL THEN 0 ELSE "
                                     "       (SELECT nvl(max(mdamage_cover),0) FROM newa22:ply_ins_type e  WHERE iins_type in ('01','02','05','07','09','10','11','17')  AND e.ipolicy=c.ipolicy ) END , "
                                     "       b.mdmg_prem+b.mlia_prem ,"
                                     "       CASE WHEN c.ipolicy IS NULL THEN 0 ELSE d.mdmg_prem+d.mlia_prem END,"
                                     "       CASE WHEN c.ipolicy IS NULL THEN b.mdmg_prem+b.mlia_prem ELSE "
                                     "       b.mdmg_prem+b.mlia_prem+d.mdmg_prem+d.mlia_prem END "
                                     "  FROM newa22:policy a ,newa22:ply_relation b,newa22:policy c , newa22:ply_relation d "
                                     " WHERE a.ipolicy= '%s' AND a.ipolicy=b.ipolicy"
                                     "   AND (b.irelative_ply IS NULL OR b.irelative_ply='') AND b.fcard_class='1' "
                                     "   AND (a.icard=c.ixxcard OR a.icard=c.ixxcard[3,12]) AND c.ipolicy=d.ipolicy"
                                     "   AND d.fcard_class='2' AND c.iroute[1,10] IN ('PA05072925','PA27998148') "
                                     "   AND a.iassured IN ('05072925','27998148') AND c.iassured IN ('05072925','27998148')",trim(sIpolicy_data2));
                     printf("stmt8_2[%s]\n",stmt8_2);               
                     $PREPARE pre8_2 from $stmt8_2;
                     $EXECUTE pre8_2 ;  
             
                     sprintf(stmt8_6,"INSERT INTO chailease "
                                     "SELECT b.icard ,a.itag,to_char(b.dply_begin),b.ibrand,a.iengine,"
                                     "       '' ,"
                                     "       a.mcar_price *10000 ,"
                                     "       0 ,"
                                     "       b.mdmg_prem+b.mlia_prem ,"
                                     "       0 ,"
                                     "       b.mdmg_prem+b.mlia_prem"
                                     "  FROM newa22:policy a ,newa22:ply_relation b"
                                     " WHERE a.ipolicy= '%s' AND a.ipolicy=b.ipolicy"
                                     "   AND (b.irelative_ply IS NULL OR b.irelative_ply='') AND b.fcard_class='1' ",trim(sIpolicy_data2));
                     printf("stmt8_6[%s]\n",stmt8_6);               
                     $PREPARE pre8_6 from $stmt8_6;
                     $EXECUTE pre8_6 ;
                                   
                     sprintf(stmt8_7,"INSERT INTO chailease_tmp "
                                     "SELECT b.icard "
                                     "  FROM newa22:policy a ,newa22:ply_relation b"
                                     " WHERE a.ipolicy= '%s' AND a.ipolicy=b.ipolicy"
                                     "   AND (b.irelative_ply IS NULL OR b.irelative_ply='') AND b.fcard_class='1' ",trim(sIpolicy_data2));
                     printf("stmt8_7[%s]\n",stmt8_7);               
                     $PREPARE pre8_7 from $stmt8_7;
                     $EXECUTE pre8_7 ;
                 }
                 else
                 {
            	     /*���N�O����ɨ��P*/  /*�����p�O�渹*/          	
            	     sprintf(stmt8_3,"INSERT INTO chailease "
		                     "SELECT CASE WHEN b.irelative_ply IS NULL OR b.irelative_ply='' THEN '' ELSE "
                                     "       (SELECT icard FROM newa22:ply_relation WHERE ipolicy =b.irelative_ply) END , "
                                     "       a.itag,to_char(b.dply_begin),b.ibrand,a.iengine, "
                                     "       b.ipolicy ,a.mcar_price *10000 , "
                                     "       (SELECT nvl(max(mdamage_cover),0) FROM newa22:ply_ins_type e  WHERE iins_type in ('01','02','05','07','09','10','11','17')  AND e.ipolicy=b.ipolicy ), "
                                     "       CASE WHEN b.irelative_ply IS NULL OR b.irelative_ply='' THEN 0 ELSE "
                                     "       (SELECT mdmg_prem+mlia_prem FROM newa22:ply_relation WHERE ipolicy =b.irelative_ply) END , "
                                     "       b.mdmg_prem+b.mlia_prem ,"
                                     "       CASE WHEN b.irelative_ply IS NULL OR b.irelative_ply='' THEN b.mdmg_prem+b.mlia_prem ELSE "
                                     "       b.mdmg_prem+b.mlia_prem+(SELECT mdmg_prem+mlia_prem FROM newa22:ply_relation WHERE ipolicy=b.irelative_ply) END "
                                     "  FROM newa22:policy a ,newa22:ply_relation b "
                                     " WHERE a.ipolicy= '%s' AND a.ipolicy=b.ipolicy"
                                     "   AND b.irelative_ply IS NOT NULL AND b.irelative_ply!='' AND b.fcard_class='2' ",trim(sIpolicy_data2));
                     printf("stmt8_3[%s]\n",stmt8_3);               
                     $PREPARE pre8_3 from $stmt8_3;
                     $EXECUTE pre8_3 ;    
                               	
                     /*���N*/ /*�L���p�O�渹*/ /*�L�P�~�j���Ҹ�*/ /*�u���*/
            	     sprintf(stmt8_4,"INSERT INTO chailease "
		                     "SELECT '',a.itag,to_char(b.dply_begin),b.ibrand,a.iengine, "
                                     "       b.ipolicy ,a.mcar_price *10000 , "
                                     "       (SELECT nvl(max(mdamage_cover),0) FROM newa22:ply_ins_type e  WHERE iins_type in ('01','02','05','07','09','10','11','17')  AND e.ipolicy=b.ipolicy ), "
                                     "       0, "
                                     "       b.mdmg_prem+b.mlia_prem ,"
                                     "       b.mdmg_prem+b.mlia_prem  "
                                     "  FROM newa22:policy a ,newa22:ply_relation b "
                                     " WHERE a.ipolicy= '%s' AND a.ipolicy=b.ipolicy AND (a.ixxcard IS NULL or a.ixxcard='') "
                                     "   AND (b.irelative_ply IS NULL OR b.irelative_ply='') AND b.fcard_class='2' ",trim(sIpolicy_data2));
                     printf("stmt8_4[%s]\n",stmt8_4);               
                     $PREPARE pre8_4 from $stmt8_4;
                     $EXECUTE pre8_4 ;  
                     
                     /*���N*/ /*�L���p�O�渹*/ /*���P�~�j���Ҹ�*/ 
            	     sprintf(stmt8_5,"INSERT INTO chailease "
		                     "SELECT c.icard, "
                                     "       c.itag,to_char(d.dply_begin),d.ibrand,c.iengine, "
                                     "       b.ipolicy ,c.mcar_price *10000 , "
                                     "       (SELECT nvl(max(mdamage_cover),0) FROM newa22:ply_ins_type e  WHERE iins_type in ('01','02','05','07','09','10','11','17')  AND e.ipolicy=b.ipolicy ), "
                                     "       d.mdmg_prem+d.mlia_prem, "
                                     "       b.mdmg_prem+b.mlia_prem,"
                                     "       b.mdmg_prem+b.mlia_prem+d.mdmg_prem+d.mlia_prem "
                                     "  FROM newa22:policy a ,newa22:ply_relation b ,newa22:policy c ,newa22:ply_relation d"
                                     " WHERE a.ipolicy= '%s' AND a.ipolicy=b.ipolicy AND a.ixxcard IS NOT NULL AND a.ixxcard<>'' "
                                     "   AND (b.irelative_ply IS NULL OR b.irelative_ply='') AND b.fcard_class='2' "
                                     "   AND (c.icard=a.ixxcard OR c.icard=a.ixxcard[3,12]) AND c.ipolicy=d.ipolicy ",trim(sIpolicy_data2));
                     printf("stmt8_5[%s]\n",stmt8_5);               
                     $PREPARE pre8_5 from $stmt8_5;
                     $EXECUTE pre8_5 ;    
                 }
             }
             else
             {
                 /* cnt_check1=0�A�ӫO������h�O�A�����s�ɮ�*/
             }	
        }
        else
        {
            /*���O�̦���郞�P�����A�����s�ɮ�*/   	
        }
    }
    $FREE prep6;
    $CLOSE curs6;
    $FREE curs6; 
    
    /*���p�ˬd*/ /*
    rc = chailease_relative_ply_check();
    if (rc != M_CM_OK) 
	 return rc;  */          
       
    /*�R������*/
	strcpy(stmt, "SELECT DISTINCT a.icard_1  "
                 "  FROM chailease a "
                 " WHERE a.icard_1 IN (SELECT icard_tmp FROM chailease_tmp) AND a.ipolicy_2 <> '' AND a.ipolicy_2 IS NOT NULL;");
	printf("stmt[%s]\n",stmt);
	$PREPARE prep7 FROM $stmt;
	$DECLARE curs7 CURSOR FOR prep7;
	$OPEN curs7;
	for(;;)
	{
        $FETCH curs7 INTO $icard_delete;
        if( SQLCODE == SQLNOTFOUND) break;
        printf("icard_delete[%s]\n",icard_delete);
        sprintf(stmt2, "DELETE chailease WHERE icard_1='%s' AND (ipolicy_2 IS NULL OR ipolicy_2='') ",icard_delete);
		$PREPARE pre_delete3 from $stmt2;
		$EXECUTE pre_delete3 ; 
	}
	$FREE prep7;
	$CLOSE curs7;
         
    /*�@���@���q chailease temp tableŪ���X*/
    strcpy(stmt9, "SELECT  DISTINCT icard_1,itag,dply_begin,chr(127)||ibrand,iengine,ipolicy_2,mcar_price,cover,prem_1,prem_2,prem_sum FROM chailease  ");
    printf("stmt9[%s]\n",stmt9);
    $PREPARE prep9 FROM $stmt9;
    $DECLARE curs9 CURSOR FOR prep9;
    $OPEN curs9;
    for(;;)
    {

        $FETCH curs9 INTO $icard_1,$itag,$dply_begin,$ibrand,$iengine,$ipolicy_2,$mcar_price,$cover,$prem_1,$prem_2,$prem_sum;

        if( SQLCODE == SQLNOTFOUND) break;
      
        printf("icard_1[%s]itag[%s]dply_begin[%s]ibrand[%s]iengine[%s]ipolicy_2[%s]mcar_price[%s]cover[%s]prem_1[%s]prem_2[%s]prem_sum[%s]\n",icard_1,itag,dply_begin,ibrand,iengine,ipolicy_2,mcar_price,cover,prem_1,prem_2,prem_sum);
        
        /*strcpy(Full_DBName1,get_car_full_db(trim(ipolicy_1)));
        strcpy(Full_DBName2,get_car_full_db(trim(ipolicy_2)));*/
        /*���o�ӫO��ҫO���j+���Ҧ��I��insert�Jtemp table�A�j���I��Ĥ@��*/
        
        /*�j��*/
        if(strcmp(trim(icard_1),"")!=0)
        {
            sprintf(stmt10,"INSERT INTO  chailease_ins_type (iins_type,minjured_cover,mdeath_cover,mdamage_cover,mdeduct,nins_type,daily_pay,qday) \n"
			               "SELECT a.iins_type,a.minjured_cover,a.mdeath_cover,a.mdamage_cover,a.mdeduct,b.nins_type,0,0 \n"
			               "  FROM newa22:ply_ins_type a,insurance_type b,newa22:policy c   \n"
			               " WHERE c.icard='%s' AND a.iins_type=b.iins_type AND c.ipolicy=a.ipolicy; \n" ,trim(icard_1));
            $PREPARE pre_ins3 from $stmt10;
            $EXECUTE pre_ins3 ;   
         }             
        /*���N*/
        if(strcmp(trim(ipolicy_2),"")!=0)
        {
            sprintf(stmt10,"INSERT INTO  chailease_ins_type (iins_type,minjured_cover,mdeath_cover,mdamage_cover,mdeduct,nins_type,daily_pay,qday) \n"
			               "SELECT a.iins_type,a.minjured_cover,a.mdeath_cover,a.mdamage_cover,case when a.mdeduct <0 then 0 else a.mdeduct end,b.nins_type, \n"
			               "       CASE WHEN  a.iins_type='56' THEN (SELECT daily_pay FROM (SELECT FIRST 1 c.daily_pay FROM newa22:ca_pa_ply c WHERE c.ipolicy=a.ipolicy))  ELSE 0 END ,\n"
			               "       CASE WHEN  a.iins_type='38' OR a.iins_type='39' THEN  a.qday  ELSE 0 END \n"
			               "  FROM newa22:ply_ins_type a,insurance_type b   \n"
			               " WHERE ipolicy='%s' AND a.iins_type=b.iins_type ORDER BY CAST(a.iins_type AS integer); \n",trim(ipolicy_2));
            $PREPARE pre_ins4 from $stmt10;
            $EXECUTE pre_ins4 ;         
         }

      	rc = chailease_build_main2();
		if (rc != M_CM_OK) 
		return rc;
    }
    $FREE prep9;
    $CLOSE curs9;
    $FREE curs9;

   return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(1);
}

/*----------------------------------------------------------------------------*/
void car351_clear()
{
    strcpy(itag_a," "); strcpy(dply_begin_a," "); strcpy(ibrand_a," "); 
    strcpy(iengine_a," ");  strcpy(mcar_price_a," "); strcpy(cover_a," ");
    strcpy(icard_1_a," "); strcpy(ipolicy_2_a," "); strcpy(prem_1_a," "); 
    strcpy(prem_2_a," ");  
    strcpy(icard_1," "); strcpy(itag," ");strcpy(dply_begin," "); 
    strcpy(ibrand," "); strcpy(iengine," "); 
    strcpy(ipolicy_2," ");  strcpy(mcar_price," "); strcpy(prem_1," ");
    strcpy(iins_type," "); strcpy(nins_type," "); strcpy(minjured_cover," "); 
    strcpy(mdeath_cover," ");  strcpy(mdamage_cover," "); strcpy(mdeduct," ");
    strcpy(daily_pay," "); strcpy(qday," "); strcpy(minjured_cover2," "); 
    strcpy(mdamage_cover2," ");  
    strcpy(dply_begin2," "); strcpy(icard_delete," ");  
    strcpy(fname," "); strcpy(filename," "); strcpy(ReportName," "); 
}
/*----------------------------------------------------------------------------*/
long chailease_build_main2()
{
	int	rc;
	char yy[4], mm[3], dd[3],yy2[5];
	$char stmt4[2048];
	$char stmt5[100];
	$char stmt16[100];
	$char field1_chk[41];
	
	cm_split_ymd(cm_from_infdate(dply_begin),yy,mm,dd);
	strcpy(yy2,itoa(atoi(yy)+1911));
	sprintf(dply_begin2,"%s%s%s",yy2,mm,dd);
	printf("%s\n",dply_begin2);
	
	if(strcmp(trim(icard_1),"")!=0)
	{
	  sprintf(icard_1,"17%s",trim(icard_1));	
	}
        
	$whenever sqlerror goto errexit;
	
	memset(fname,0x00,sizeof(fname));
	memset(filename,0x00,sizeof(filename));

	sprintf(fname,"%s_%s",trim(itag),dply_begin2);

	if (strcmp(trim(icard_1),"")!=0 && strcmp(trim(ipolicy_2),"")!=0 )
	{
		sprintf(filename,"%s/rptftp/car351/%s.xls",sApHome,fname);
		printf("filename[%s]\n",filename);
		fp=fopen(filename,"w");
		strcpy(ftitle,"�O�I���q�W��\t�O�I���q�Τ@�s��\t�j��O�I���X\t�P�Ӹ��X\t�O�I����(�_)\t�t�P����\t�������X\t���N�O�渹�X\t���m����\t�O�I���B\t�j���I�O�O\t���N�I�O�O\t�`�O�O\n");	
		fprintf(fp,ftitle);
		fprintf(fp,"�s�w�F�ʮ��W\t16099078\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n",trim(icard_1),itag,dply_begin2,ibrand,iengine,ipolicy_2,mcar_price,cover,prem_1,prem_2,prem_sum);
		fprintf(fp," \n");
		fprintf(fp,"�O�I�N�X\t�O�I���B�@\t�O�I���B�G\t�O�I���B���\t�Ƶ�\n");
		
		/*���P�I�ءA��m��즳�Ҥ��P*/
		rc = chailease_build_dtl();
		if (rc != M_CM_OK) 
			return rc;        
		
		fclose(fp);
	}
	
	$DELETE  chailease_ins_type WHERE 1=1;

	sprintf(ReportName,"%-35.35s",fname);

	rc=rptftpinsert(userid,"car351", fname );
	if (rc!=0)
	{
		printf( "�g�Jrptftplist���~\n");
		return rc;
	}
	
	if (strcmp(trim(icard_1),"")!=0 && strcmp(trim(ipolicy_2),"")!=0)
	{
		strcpy(stmt4,"�j+��");
		strcpy(stmt5,"�w���s�ɮסA���ɵP�ӥ�");	
	}
	else if (strcmp(trim(icard_1),"")!=0 && strcmp(trim(ipolicy_2),"")==0)
	{
		strcpy(stmt4,"��j");
		strcpy(stmt5,"�����s�ɮסA���ɵP�ӥ�");
	}
	else if (strcmp(trim(icard_1),"")==0 && strcmp(trim(ipolicy_2),"")!=0)
	{
		strcpy(stmt4,"���");
		strcpy(stmt5,"�����s�ɮסA���ɵP�ӥ�");	
	}
	else
	{
		strcpy(stmt4,"���~");
		strcpy(stmt5,"�����s�ɮסA���ɵP�ӥ�");
	}
    	
	/*�ɦW����*/
	if (strcmp(trim(itag),"")!=0)
	{
		sprintf(stmt16, "SELECT field1 FROM car351_log WHERE field1='%s';",trim(fname));
		printf("stmt16[%s]\n",stmt16);
		$PREPARE prep16 FROM $stmt16;
		$DECLARE curs16 CURSOR FOR prep16;
		$OPEN curs16;
		for(;;)
		{
			$FETCH curs16 INTO $field1_chk;
			if( SQLCODE == SQLNOTFOUND) break;
			printf("field1_chk[%s]\n",field1_chk);
			
			$UPDATE car351_log SET field4='�ɦW����' WHERE field1=$field1_chk;
		}
	    $FREE prep16;
	    $CLOSE curs16;
	}
	
	$INSERT INTO car351_log(field1,field2,field3,field4)
	 VALUES(trim($fname),trim($prem_sum),trim($stmt4),trim($stmt5));
  
	return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
} 
/*----------------------------------------------------------------------------*/
long car351_writelog()
{
	int	rc;
	$char stmt14[100];
	$char field1[41],field2[21],field3[6],field4[41];
	$char cnt_out[5];
	$char cnt[5];
	
	sfp = STARTLOG();
	
	$SELECT count(*) INTO $cnt_out FROM car351_log WHERE field4[1,10]='�w���s�ɮ�';
	printf("cnt_out[%s]\n",cnt_out);
	$SELECT count(*) INTO $cnt FROM car351_log WHERE field4[1,10]='�w���s�ɮ�' OR field4[1,10]='�����s�ɮ�';
	printf("cnt[%s]\n",cnt);
	if (itime_now == 11)
		sprintf( sMsg,"�H�U��Ƭ� %s 17:00�� %s 11:00���J�檺��ơA�N�� %s 12:00�߰e�ܤ����}�M",dend,dbegin,dbegin);
	else if (itime_now == 17)
		sprintf( sMsg,"�H�U��Ƭ� %s 11:00�� %s 17:00���J�檺��ơA�N�� %s 18:00�߰e�ܤ����}�M",dbegin,dbegin,dbegin);

	WRITELOG( sfp, sMsg);        
	strcpy(sMsg_mail,"<html><head><meta http-equiv=Content-Type content=\"text/html; charset=Big5\"></head><font face=\"�L�n������\">\n");
	fprintf(sfp2,sMsg_mail);
	strcpy(sMsg_mail,"��w<br>\n");
	fprintf(sfp2,sMsg_mail);
	sprintf(sMsg_mail,"%s<br>\n",sMsg);
	fprintf(sfp2,sMsg_mail);
	sprintf( sMsg,"�@%s���A�w���s%s���ɮ�",cnt,cnt_out);
	WRITELOG( sfp, sMsg);
	sprintf(sMsg_mail,"%s<br>\n",sMsg);
	fprintf(sfp2,sMsg_mail);
	strcpy(sMsg_mail,"<table style=\"border:1px #000000 solid;\" rules = \"all\"><font face=\"�L�n������\"><tr><td>�ɦW</td><td>�`�O�O</td><td>�ɮ����O</td><td>�Ƶ�</td></tr></font>");
	fprintf(sfp2,sMsg_mail);
	
	strcpy(stmt14, "SELECT DISTINCT field1,field2,field3,field4 FROM car351_log WHERE field4[1,10]='�w���s�ɮ�' OR field4[1,10]='�����s�ɮ�';");
	printf("stmt14[%s]\n",stmt14);
	$PREPARE prep14 FROM $stmt14;
	$DECLARE curs14 CURSOR FOR prep14;
	$OPEN curs14;
	for(;;)
	{
		$FETCH curs14 INTO $field1,$field2,$field3,$field4;
		if( SQLCODE == SQLNOTFOUND) break;
		printf("field1[%s]field2[%s]field3[%s]field4[%s]\n",field1,field2,field3,field4);
		
		strcpy(field1,trim(field1));
		strcpy(field2,trim(field2));
		strcpy(field3,trim(field3));
		strcpy(field4,trim(field4));
		sprintf( sMsg,"%-35.35s\t�`�O�O:%-7.7s\t%-7.7s\t%-26.26s",field1,field2,field3,field4);
		WRITELOG( sfp, sMsg);            
		sprintf(sMsg_mail,"<font face=\"�L�n������\"><tr><td>%s</td><td style=\"text-align:right;\">%s</td><td>%s</td><td>%s</td></tr></font>\n",field1,field2,field3,field4);
		fprintf(sfp2,sMsg_mail); 
	}
	$FREE prep14;
	$CLOSE curs14;

        strcpy(sMsg_mail,"</table></font></html>\n");
        fprintf(sfp2,sMsg_mail);        
        
        ENDLOG(sfp); 
        return M_CM_OK;
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
} 
