/*********************************************
 * Copyright (C) 1995 Intellisys Corporation
 * Program : ca997p04s.ec
 * �����T���߫O�I�ҧ@�o�ި�@�~
 *********************************************/
 
#include <stdio.h>
#include "api_xsrv.h"

#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"

#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"

$define  COMPANY    "17";
$include sqlca;
$include datetime.h;

/* -------- data in main program --------*/

char  userid[11],outputf[21],option[2];
$char DBName[05], sbgndate[10], senddate[10], dbgn1[11], dend1[11];
$char dbgn1_c[11], dend1_c[11];
$char sApHome[31],dgroup_c[11], iply_type[3], fcard_class[2], Tmp1[30];
$char file0[51], strlog[500];
char  day_yy[4], day_mm[3], day_dd[3];
FILE  *errfpt, *fptr;
$long date_check, dtoday;

/* -------- function definition -------*/
long  car209_get_db();
long  car209_build();
long  car209_test();

/*  ----------  data in build  ----------  */
$char  sTmt_buf[1024], sPrtstr[75];
$long  prem_total = 0, DateToTable, cntrlrec;

/*  -------- data find database name --------  */
DBinfo  *list;
int     i,count_db;

$char errmsg[72], errlog[300];
char errstr[20];


/*--------------------------------------------------------------------*/
main(argc,argv)
int   argc;
char  **argv;
{
   int   rc,rt;

   batchinit();

   strcpy(DBName,isNULLstr(argv[1]));
   strcpy(userid,isNULLstr(argv[2]));
   strcpy(sbgndate,isNULLstr(argv[3]));
   strcpy(senddate,isNULLstr(argv[4]));
   strcpy(outputf,isNULLstr(argv[5]));
   
   if (sbgndate[0]=='*' || sbgndate[0] == '\0') 
     strcpy(sbgndate,  "080/01/01");
   if (senddate[0]=='*' || senddate[0] == '\0') 
     strcpy(senddate,  "199/12/31");
     
   strcpy(dbgn1,cm_to_infdate(sbgndate));
   strcpy(dend1,cm_to_infdate(senddate));

   printf("dbgn1[%s] dend1[%s]\n",dbgn1,dend1);
   
   $WHENEVER SQLERROR GOTO errexit;
   
   if (db_select(DBName) == FALSE) {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   errfpt = (FILE *) STARTLOG();   

   rt = getApHome(sApHome);
   if (rt < 0) {
        printf("read Config file error!!\n");
        return M_CM_READ_CONFIG_ERR;
   }   
   
   cm_split_ymd_100(sbgndate,day_yy,day_mm,day_dd);
          
   sprintf_s(Tmp1, sizeof Tmp1,"isgu17_%s%s%s",day_yy,day_mm,day_dd);
   strcpy(iply_type,"gu");
   strcpy(fcard_class, "1");
   sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);
   
   printf("file0[%s] Tmp1[%s]\n",file0,Tmp1);
   fptr=fopen(file0,"w");
   
   rstrdate ( dbgn1 , &date_check );
   printf("sbgndate[%s] date_check [%d]\n",sbgndate,date_check);  
   
   dtoday = cm_today(); /* get today date MM/DD/YYYY */
   
   rc = check_if_exist(iply_type,dtoday,fcard_class,0);
   if ( rc != M_CM_OK )
        goto errhappen;  

   rc=car209_build();  
   if (rc!=M_CM_OK)
   {
      goto errhappen;
   }
   
   exit(0);
   
errexit:
    printf("209_main:code=%d, msg=%s\n",SQLCODE,sqlca.sqlerrm );
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    exit(1);   
    
errhappen:
    rgetmsg(rc, errlog , sizeof(errlog));
    sprintf_s(strlog, sizeof strlog,"%s\n",errlog);
    strcat(strlog,"     isgu17_�O�I�ҧ@�o��ƻs�@���� ");
    EWRITE(userid,rc,strlog);
    exit(1);
   
}
/*--------------------------------------------------------------------*/

long car209_build()
{
   
   $char  sIcard[CARD_NUM];
   $char  sDalter[11],sDalter_c[11];
   $char  sIcar_type[3],sIpolicy[21],fstatus[2];
   $char  str[17];
   $char  stmt[200],cntrlrec_c[7];
   $char  polsFullName[20];
    char  sDalter_yy[4],sDalter_mm[3],sDalter_dd[3],tmp_yyyy[5];
    int   rc;
    
   $whenever sqlerror goto errexit;
   $begin work;
   
   cntrlrec = 0;
        
   sprintf_s(sTmt_buf, sizeof sTmt_buf,"SELECT icard , dalter , icar_type , ipolicy  "
                      " FROM compulsory_card  "
                      "WHERE dalter between ? AND ?  "
                      "  AND fstatus in ('4','A','B','C','D') ");
                              
   printf ("[%s]\n", sTmt_buf);
     
   $PREPARE STMT1 FROM $sTmt_buf;
   $DECLARE CUR1 CURSOR FOR STMT1;
   $OPEN CUR1 USING  $dbgn1, $dend1;
        
   while(1)
   {
        
      $FETCH CUR1 INTO $sIcard, $sDalter, $sIcar_type, $sIpolicy;
            
      if( SQLCODE == SQLNOTFOUND ) break;  
      
      printf("sIcard[%s] sDalter[%s]\n",sIcard, sDalter );
        
      strcpy(sPrtstr,"D");              sPrtstr[1]='\0';     /*C1:�B�z�O�N�X*/
      strcat(sPrtstr,"        ");       sPrtstr[9]='\0';     /*C2:���P*/
      strcat(sPrtstr,"          ");     sPrtstr[19]='\0';    /*C3:���D*/
      strcat(sPrtstr,COMPANY);          sPrtstr[21]='\0';    /*C4:���q�O*/
      strncat(sPrtstr,sIcard,15);       sPrtstr[36]='\0';    /*C4:�O�I�d����*/
      strcat(sPrtstr,COMPANY);          sPrtstr[38]='\0';    /*C5:���q�O*/
      strcat(sPrtstr,"        ");       sPrtstr[46]='\0';    /*C6:�O�I�ͮĤ�*/
      strcat(sPrtstr,"        ");       sPrtstr[54]='\0';    /*C7:�O�I�����*/  
      
      str[0] = sDalter[6];
      str[1] = sDalter[7];
      str[2] = sDalter[8];
      str[3] = sDalter[9];
      str[4] = '\0';
      strcat(sPrtstr, str );            sPrtstr[58]='\0';
      
      str[0] = sDalter[0];
      str[1] = sDalter[1];
      str[2] = '\0';
      strcat(sPrtstr, str);             sPrtstr[60]='\0';
      
      str[0] = sDalter[3];
      str[1] = sDalter[4];
      str[2] = '\0';
      strcat(sPrtstr, str);             sPrtstr[62]='\0';    /*C8:���ʤ�*/
      strcat(sPrtstr, "      ");        sPrtstr[68]='\0';    /*C9:���ʮɶ�*/ 

      printf("sIpolicy[%s] sIcar_type[%s]\n",sIpolicy, sIcar_type);

      if( (sIpolicy[0] == '\0') || strlen(trim(sIpolicy)) <= 0 ) /* ���X�� */
      {
          if( (strcmp(sIcar_type,"01") == 0) || 
              (strcmp(sIcar_type,"02") == 0) ||
              (strcmp(sIcar_type,"32") == 0) ||
              (strcmp(sIcar_type,"34") == 0) ||
              (strcmp(sIcar_type,"35") == 0))
             strcpy(sIcar_type,"01");
      }
      strcat(sPrtstr,sIcar_type);       sPrtstr[70]='\0';    /*C10:����*/

      printf ("[%s]\n", sPrtstr);
      fprintf(fptr,"%s\n",sPrtstr);
      cntrlrec++;
      
      $UPDATE compulsory_card
          SET dtrans1 = $dtoday  
        WHERE icard = $sIcard;
        
    } /* end while loop */
    $CLOSE CUR1;
    $FREE  CUR1;

  /* ���q����@�o�ॼ�X */

   sprintf_s(sTmt_buf, sizeof sTmt_buf,"SELECT icard , dalter , icar_type , ipolicy  "
                       " FROM compulsory_card  "
                       "WHERE dalter between ? AND ?  "
                       "  AND dtrans1 is not null  "
                       "  AND fcancel = 'Y' ");

    printf ("[%s]\n", sTmt_buf);

    $PREPARE STMT2 FROM $sTmt_buf;
    $DECLARE CUR2 CURSOR FOR STMT2;
    $OPEN  CUR2  USING $dbgn1, $dend1;
    while(1)
    {

       $FETCH CUR2 INTO $sIcard, $sDalter, $sIcar_type, $sIpolicy;

       if( SQLCODE == SQLNOTFOUND ) break;

       printf("sIcard[%s] sDalter[%s]\n",sIcard, sDalter );

       strcpy(sPrtstr,"U");              sPrtstr[1]='\0';     /*C1:�B�z�O�N�X*/
       strcat(sPrtstr,"        ");       sPrtstr[9]='\0';     /*C2:���P*/
       strcat(sPrtstr,"          ");     sPrtstr[19]='\0';    /*C3:���D*/
       strcat(sPrtstr,COMPANY);          sPrtstr[21]='\0';    /*C4:���q�O*/
       strncat(sPrtstr,sIcard,15);       sPrtstr[36]='\0';    /*C4:�O�I�d����*/
       strcat(sPrtstr,COMPANY);          sPrtstr[38]='\0';    /*C5:���q�O*/
       strcat(sPrtstr,"        ");       sPrtstr[46]='\0';    /*C6:�O�I�ͮĤ�*/
       strcat(sPrtstr,"        ");       sPrtstr[54]='\0';    /*C7:�O�I�����*/

       str[0] = sDalter[6];
       str[1] = sDalter[7];
       str[2] = sDalter[8];
       str[3] = sDalter[9];
       str[4] = '\0';
       strcat(sPrtstr, str );            sPrtstr[58]='\0';

       str[0] = sDalter[0];
       str[1] = sDalter[1];
       str[2] = '\0';
       strcat(sPrtstr, str);             sPrtstr[60]='\0';

       str[0] = sDalter[3];
       str[1] = sDalter[4];
       str[2] = '\0';
       strcat(sPrtstr, str);             sPrtstr[62]='\0';    /*C8:���ʤ�*/
       strcat(sPrtstr, "      ");        sPrtstr[68]='\0';    /*C9:���ʮɶ�*/

       printf("sIpolicy[%s] sIcar_type[%s]\n",sIpolicy, sIcar_type);

       if( (sIpolicy[0] == '\0') || strlen(trim(sIpolicy)) <= 0 ) /* ���X�� */
       {
           if( (strcmp(sIcar_type,"01") == 0) || 
               (strcmp(sIcar_type,"02") == 0) ||
               (strcmp(sIcar_type,"32") == 0) ||
               (strcmp(sIcar_type,"34") == 0) ||
               (strcmp(sIcar_type,"35") == 0))
              strcpy(sIcar_type,"01");
       }
       strcat(sPrtstr,sIcar_type);       sPrtstr[70]='\0';    /*C10:����*/

       printf ("[%s]\n", sPrtstr);
       fprintf(fptr,"%s\n",sPrtstr);
       cntrlrec++;

       $UPDATE compulsory_card
           SET dtrans1 = $dtoday
         WHERE icard = $sIcard;

    }
    $CLOSE CUR2;
    $FREE  CUR2;


    /* ���q������ॼ�X  */
    sprintf_s(sTmt_buf, sizeof sTmt_buf,"SELECT icard , dalter , icar_type , ipolicy  "
                      " FROM compulsory_card  "
                      "WHERE dalter between ? AND ?  "
                      "  AND dtrans1 is not null  "
                      "  AND fmiss = 'Y' ");

    printf ("[%s]\n", sTmt_buf);

    $PREPARE STMT2 FROM $sTmt_buf;
    $DECLARE CUR22 CURSOR FOR STMT2;
    $OPEN  CUR22  USING $dbgn1, $dend1;
    while(1)
    {

       $FETCH CUR22 INTO $sIcard, $sDalter, $sIcar_type, $sIpolicy;

       if( SQLCODE == SQLNOTFOUND ) break;

       printf("sIcard[%s] sDalter[%s]\n",sIcard, sDalter );

       strcpy(sPrtstr,"U");              sPrtstr[1]='\0';     /*C1:�B�z�O�N�X*/
       strcat(sPrtstr,"        ");       sPrtstr[9]='\0';     /*C2:���P*/
       strcat(sPrtstr,"          ");     sPrtstr[19]='\0';    /*C3:���D*/
       strcat(sPrtstr,COMPANY);          sPrtstr[21]='\0';    /*C4:���q�O*/
       strncat(sPrtstr,sIcard,15);       sPrtstr[36]='\0';    /*C4:�O�I�d����*/
       strcat(sPrtstr,COMPANY);          sPrtstr[38]='\0';    /*C5:���q�O*/
       strcat(sPrtstr,"        ");       sPrtstr[46]='\0';    /*C6:�O�I�ͮĤ�*/
       strcat(sPrtstr,"        ");       sPrtstr[54]='\0';    /*C7:�O�I�����*/

       str[0] = sDalter[6];
       str[1] = sDalter[7];
       str[2] = sDalter[8];
       str[3] = sDalter[9];
       str[4] = '\0';
       strcat(sPrtstr, str );            sPrtstr[58]='\0';

       str[0] = sDalter[0];
       str[1] = sDalter[1];
       str[2] = '\0';
       strcat(sPrtstr, str);             sPrtstr[60]='\0';

       str[0] = sDalter[3];
       str[1] = sDalter[4];
       str[2] = '\0';
       strcat(sPrtstr, str);             sPrtstr[62]='\0';    /*C8:���ʤ�*/
       strcat(sPrtstr, "      ");        sPrtstr[68]='\0';    /*C9:���ʮɶ�*/

       printf("sIpolicy[%s] sIcar_type[%s]\n",sIpolicy, sIcar_type);

       if( (sIpolicy[0] == '\0') || strlen(trim(sIpolicy)) <= 0 ) /* ���X�� */
       {
           if( (strcmp(sIcar_type,"01") == 0) ||
               (strcmp(sIcar_type,"02") == 0) ||
               (strcmp(sIcar_type,"32") == 0) ||
               (strcmp(sIcar_type,"34") == 0) ||
               (strcmp(sIcar_type,"35") == 0))
              strcpy(sIcar_type,"01");
       }
       strcat(sPrtstr,sIcar_type);       sPrtstr[70]='\0';    /*C10:����*/

       printf ("[%s]\n", sPrtstr);
       fprintf(fptr,"%s\n",sPrtstr);
       cntrlrec++;

       $UPDATE compulsory_card
           SET dtrans1 = $dtoday
         WHERE icard = $sIcard;

    }
    $CLOSE CUR22;
    $FREE  CUR22;


    strcpy(sPrtstr,"CNTRLREC");
    rfmtlong(cntrlrec,"&&&&&&",cntrlrec_c);
    strcat(sPrtstr,cntrlrec_c);
    fprintf(fptr, "%s\n", sPrtstr);
   
   
   fclose(fptr);
     
   rc = rptftpinsert( userid , "car209" , Tmp1 );
   
   $insert into ca_trade_exam
               (iply_type,dpolicy,fcard_class,itrans_type,
                qcount,mamount,minjure,mcripple,mdeath)
         values
               ($iply_type,$dtoday,$fcard_class,0,
                $cntrlrec,0,0,0,0);

   sprintf_s(strlog, sizeof strlog,"���ɧ���:%s ���:%d\n\t\t ",file0,cntrlrec);

   day_yy[0] = sbgndate[0];
   day_yy[1] = sbgndate[1];
   day_yy[2] = sbgndate[2];
   day_yy[3] = '\0';
   day_mm[0] = sbgndate[4];
   day_mm[1] = sbgndate[5];
   day_mm[2] = '\0';
   day_dd[0] = sbgndate[7];
   day_dd[1] = sbgndate[8];
   day_dd[2] = '\0';
   
   sprintf_s(strlog, sizeof strlog,"%s�����X����� %s%s%s ~ ",strlog, day_yy,
           day_mm, day_dd );

   day_yy[0] = senddate[0];
   day_yy[1] = senddate[1];
   day_yy[2] = senddate[2];
   day_yy[3] = '\0';
   day_mm[0] = senddate[4];
   day_mm[1] = senddate[5];
   day_mm[2] = '\0';
   day_dd[0] = senddate[7];
   day_dd[1] = senddate[8];
   day_dd[2] = '\0';

   sprintf_s(strlog, sizeof strlog,"%s%s%s%s",strlog, day_yy , day_mm , day_dd );
   
   WRITELOG(errfpt , strlog);
     
   printf("errfpt[%s]\n",strlog);
     
   if (errfpt!=NULL) ENDLOG(errfpt); 
     
   $commit work;
       
   return M_CM_OK;
   
   errexit:
    $rollback work;
    return SQLCODE; 
}

/*---------------------------------------------------------*/
long check_if_exist( iply_type, dpolicy, fcard_class, trans_type )
$char *iply_type;
$int dpolicy;
$char *fcard_class;
$int trans_type;
{
   
   $long trade_count = 0, err_count = 0, out_count = 0;
   int rc;
   
   printf("iply_type[%s] dpolicy[%d]\n",iply_type,dpolicy);
   printf("fcard_class[%s] trans_type[%d]\n",fcard_class,trans_type);
   
   $SELECT qtradevan, qerr, qout
      INTO $trade_count, $err_count, $out_count
      FROM ca_trade_exam 
     WHERE iply_type = $iply_type
       AND dpolicy = $dpolicy
       AND fcard_class = $fcard_class 
       AND itrans_type = $trans_type;
  
    if ( SQLCODE == SQLNOTFOUND )  return M_CM_OK;      
    
   printf("trade_count[%d] [%d] [%d]\n",trade_count,err_count,out_count);
   
   if ( trade_count==0 && err_count==0 && out_count==0 )
   {
       
       $DELETE FROM ca_trade_exam 
         WHERE iply_type = $iply_type
           AND dpolicy = $dpolicy
           AND fcard_class = $fcard_class 
           AND itrans_type = $trans_type;
           
        printf("is updated [%d]\n",sqlca.sqlerrd[2]);
           
        return M_CM_OK; 
   
   }
   
   strcpy(sqlca.sqlerrm ,"�L�k���J�s�C - �b UNIQUE INDEX ��즳���Э�");
   
   return -239;
   
errexit:
    printf("check_if_exist:sqlcode=%d, sqlmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    rc = SQLCODE;
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return rc;  
   
}
