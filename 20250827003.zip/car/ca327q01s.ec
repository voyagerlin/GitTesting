/*-------------------------------------------------------------------
 * Program: ca312q01s.ec
 * Date   : 03/10/2003
 *-------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#include "is_def.h"
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "ISvar.h"
#include "safeclib.h"
$include "ca3xxlib.h";

$include sqlca;
$include sqltypes;

$char DBName[05], FormTp[03];
$char  outputf[N_FILE+1], userid[06];

$char  type[2], sfile[40], option[2], choice[2], opt[2], chk_eply[2];
$char  Tipolicy[21],Full_DBName[20],Full_DB_A[20],Full_DB_B[20];

$int mins_premium;
$int branch_mprem;
$int oth_mprem;
char str_mins_premium[10];


$char  sIpolicy[20], sDply_begin[11], sDply_end[11], sIbrand[10];
$char  sNassured[100], sItag[CA_TAG_NUM], sIengine[CA_ENGINE_NUM], sAassured[90], sAassured_zip[CA_ZIP];
$char  sFassured[2], sFsex[2], sIpro_year[10],sNbrand[21];
$char  iipolicy[21], iipolicy1[21], stmt_11[500];
$char  tmp_nassured[100], tmp_nassured1[51], tmp_nassured2[51];
$long  lmdamage_cover = 0;
$char sDpolicy[11];
$char iBig_office[11];
$char iBig_sales[11];
$char sNequipment5[2];
$char  nequipment[31];
$int count = 0;
$char ipro_year[5];
$char sErrMsg[2048];

/* file */
$char    report_file1[30],report_file2[30],sTmp[1001];
$char    sData[81];
 char    sApHome[30],outputf1[80],outputf2[80];
 char    prtstr[277],prtstr2[177];
 char    getfile[50],txtfile[20];
 char    itmp[10];
 FILE    *fptr,*fptr2;
 FILE    *sfp;
static int   recLen=1024;
static char  *bp;
 FILE    *fp;

int Len=0;
int i,d = 0,ben_len;
$int tot_count=0;

/* option1�Boption2 */
  int  rtn,pos;
 char  str_dply_begin[11],str_dply_end[11],str_date[50];
 char  yy2[4],mm2[3],dd2[3],yy3[4],mm3[3],dd3[3];
 char  buf[50], buf1[50], buf2[50];
$char  stmt_buf[500];
$char  sequip_str[201];

$char ProtectData[2];
int   max_count=0;
char  OutFile[20];
$char sdata[1024][121];
$char skpidFreeForm[12];/*1120918005_C01_CAR327�O��C�L�վ㬰FREEFORM�榡*/
$char iserl[11];
$char fhide[2];
static char *get_car_full_db();
long ca327_policyB_print();
long ca327_policyB_print_Freeform();
long ca_freeform_policy();

/**********************************************************************************/
main(argc,argv)
int argc;
char **argv;
{
   int rc,rtncode;

   batchinit();
   strcpy(DBName, isNULLstr(argv[1]));
   strcpy(userid, isNULLstr(argv[2]));
   strcpy(type,   isNULLstr(argv[3]));   /* 1.�ɮ� 2.ipolicy 3.�M�ץ�O��C�L */
   strcpy(opt,    isNULLstr(argv[4]));   /* 1.�M�ץ�O��פJ�� 2.�O�渹�϶�  */
   strcpy(sfile,  isNULLstr(argv[5]));
   strcpy(iipolicy,  isNULLstr(argv[6]));
   strcpy(iipolicy1, isNULLstr(argv[7]));
   strcpy(choice, isNULLstr(argv[8]));   /* 1.���s�ǩ_ 2.Yes I do 3.���~�ѵs�I */
   strcpy(option, isNULLstr(argv[9]));   /* 1.�M�׾��� 2.�M�׳q�� 3.���ڦC�L */
   strcpy(chk_eply, isNULLstr(argv[10]));/* 1.�Ŀ�ɵo�q�l�O�� 0.���Ŀ�ɵo�q�l�O��*/
   strcpy(outputf,isNULLstr(argv[11]));
   strcpy(skpidFreeForm, isNULLstr(argv[11]));/*1120918005_C01_CAR327�O��C�L�վ㬰FREEFORM�榡*/
   strcpy(outputf,isNULLstr(argv[12]));
   
   strcpy(skpidFreeForm,trim(skpidFreeForm));

   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN,"M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }

   if (strncmp(type,"3",1) != 0)
   {
       rc = ca327_detail();
       printf("main function rc = [%d]\n", rc);

       if (rc == api_OKComplete)
       {

           if ((rc=save_form_info(F_FREE, "CA", 327, userid, FormTp, 80,outputf))<0)
               EWRITE(userid, rc, "save_form_info failed");
           else
               printf("FormTp[%s],outputf[%s]\n",FormTp,outputf);
       }

       if( rc ==  M_CA_NBRAND)
       {
           EWRITE(userid,M_CA_NBRAND ,"�t�P�����N�����s�b");
           return rc;

       }

       exit(0);
   }
   else
   {
       $CREATE TEMP TABLE CAR327
       (
          ipolicy  char(20) default ' '
       )WITH NO LOG;

       $CREATE INDEX CAR327_ix1 ON CAR327 (ipolicy);

       strcpy(ProtectData,option);
       printf("---ProtectData[%s]\n---",ProtectData);

       if (strncmp(opt,"1",1) == 0) 
       {
           /* Ū���M�ץ�O�渹 �פJ�� */
           rtncode = ca327_read_data();
           if( rtncode != M_CM_OK )
           {
               printf("getfile error \n");
               return rtncode;
           }
       }
       else 
       {
     	   /* �϶��O�渹�s�W��temp table */
     	   rtncode = ca327_read_data1();
           if( rtncode != M_CM_OK )
           {
               printf("Insert temp table error \n");
               return rtncode;
           }
       }
       if(strcmp(skpidFreeForm,"") == 0)/*�@��C�L*/
       {
       	rtncode = ca327_policyB_print();
       }
       else/*Freeform�C�L*/
       {
       	rtncode = ca327_policyB_print_Freeform();
       }

       if (rtncode != M_CM_OK)
       {
           printf("ca327_policyB_print[%s] error\n", sErrMsg);
           EWRITE(userid, rtncode, sErrMsg);
           return rtncode;
       }
       if(strcmp(skpidFreeForm,"") == 0)/*�@��C�L*/
       {
	       if (rc=(save_form_info(F_FREE,"CA",306,userid,FormTp,max_count,outputf))<0)
	           EWRITE(userid,rc,"save_form_info failed");
	       else
	           printf("FormTp[%s],outputf[%s]\n",FormTp,outputf);
       }
       exit(0);
   }

errexit:
    printf("car327_err:sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    $WHENEVER SQLERROR CONTINUE;     /* reset error handling */
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/**************************************************************************************/
long ca327_detail()
{
   $char  sStmt[1024], sStmt1[200], stmtA[100];
     int  rc, rtncode;


   $WHENEVER sqlerror goto errexit;

   printf("===>  type[%s]\n", type );
   printf("   ??????????????????????????????????????????????????  \n");

   printf(" ???????????? choice[%s]\n",choice);
   printf(" ???????????? option[%s]\n",option);


   if( strcmp(type,"1") == 0 )
   {
      /* Load From File */

      if( strcmp( option, "1") == 0 )  /* �M�׾��ҡA�D Tobe �� */
      {
         rc = ca327_build1();
         if ( rc != api_OKComplete )
         {
            printf("ca327_build1 error \n");
            return rc;
         }
      }
      else if( strcmp( option, "2") == 0 )    /* �M�׳q�� */
      {
         rc = ca327_build2();
         if ( rc != api_OKComplete )
         {
            printf("ca327_build2 error \n");
            return rc;
         }
      }
      else
      {                                      /* ���� */
         rc = ca327_build3();
         if ( rc != api_OKComplete )
         {
            printf("ca327_build2 error \n");
            return rc;
         }
      }



      $CREATE TEMP TABLE CAR327
      (
          ipolicy  char(20) default ' '
      )
      WITH NO LOG;

      $CREATE INDEX CAR327_ix1 ON CAR327 (ipolicy);

      rc = ca327_getfile();
      if( rc != M_CM_OK )
      {
          printf("getfile error \n");
          return rc;
      }



      if( strcmp( choice, "1") == 0 )
      {
         sprintf_s(stmtA, sizeof stmtA , "AND (iofficer[7,8] = 'YF' or iofficer[7,9] in ('Y54','Y55','Y58'))");
      }
      else if( strcmp( choice, "2") == 0 )
      {
         sprintf_s(stmtA, sizeof stmtA , "AND (iofficer[7,8] = 'YI' or iofficer[7,9] in ('Y07','Y08','Y09','Y10'))");
      }


      if( strcmp(choice,"3") == 0 && ( strcmp( option, "3") == 0 ) )     /* ���O�檺���ڦC�L */
      {
      	printf(" ********************************************************** \n");
      	rc=car327_receipt();    /* �C�L�������t�~�W�ߥX�� */
        if( rc != api_OKComplete )
        {
          printf("option=3 choice=3 receipt error rc=[%d]\n",rc);
          return rc;
        }
        else
        {
          return rc;
        }
      }


      $DECLARE curx CURSOR  for
        SELECT ipolicy
          FROM CAR327;
      $OPEN curx;
      while(1)
      {
          $FETCH curx INTO $Tipolicy;
           printf("Tipolicy[%s]\n",Tipolicy);

          if ( SQLCODE == SQLNOTFOUND ) break;

          strcpy(Full_DBName,get_car_full_db(Tipolicy));

          /* �M�ץ�P�_�G�s�WH�g��B������H0-H2 modify by larry 103.01.20 (1021122001_C3)
                         OR (a.iofficer[1,1] = 'H' AND iofficer[2,2] not in ('0','1','2')) */

          /* �s�W�M��N*�g��P�_  add by sylvia 103.09.18 (1030630002_C1) */
          sprintf_s(sStmt, sizeof sStmt,
            "SELECT a.ipolicy, a.dply_begin, a.dply_end, a.ipro_year, a.ibrand,  "
                   "b.nassured, b.itag, b.iengine, b.aassured, b.aassured_zip,  "
                   "b.fassured, b.fsex  "
             " FROM %s:ply_relation a , %s:policy b  "
             "WHERE a.ipolicy = b.ipolicy AND a.ipolicy = '%s'  "
             "  AND (a.iofficer[1] = 'W' or a.iofficer in  "
             "      (select unique iofficer_ori from ca_promote_officer where iofficer_ori in ('H','N'))) %s ",
              Full_DBName, Full_DBName, Tipolicy, stmtA );

          strcpy(sequip_str,equip_instr("18"));
          if( strcmp( option, "1" ) == 0 )
          {
             sprintf_s(sStmt1, sizeof sStmt1," AND b.nequipment[18] in %s ",sequip_str);
             strcat( sStmt, sStmt1 );
          }
          printf("sStmt[%s]\n",sStmt );

          $PREPARE CUR3 FROM $sStmt;
          $DECLARE CUR4 CURSOR for CUR3;
          $OPEN CUR4;

          while(1)
          {
             $FETCH CUR4 INTO $sIpolicy, $sDply_begin, $sDply_end, $sIpro_year, $sIbrand,
                              $sNassured, $sItag, $sIengine, $sAassured, $sAassured_zip,
                              $sFassured, $sFsex;

             if( SQLCODE == SQLNOTFOUND ) break;

             if( strcmp( option, "1" ) == 0 )   /* �M�׾��ҡA�DTobe�� */
             {
                 sprintf_s(stmt_11, sizeof stmt_11,
                    "SELECT mdamage_cover  "
                     " FROM %s:ply_ins_type  "
                     "WHERE ipolicy = '%s' AND iins_type = '11'  "
                     "  AND mdamage_cover > 0 ",
                      Full_DBName, Tipolicy );
                 $PREPARE CURAA FROM $stmt_11;
                 $DECLARE CURBB CURSOR for CURAA;
                 $OPEN CURBB;
                 $FETCH CURBB INTO $lmdamage_cover;
                 $CLOSE CURBB;
                 $FREE CURBB;

                 rc = ca327_option1();
                 if( rc != M_CM_OK )
                 {
                    printf(" option1 error \n");
                    return rc;
                 }
             }
             else
             {
                 rc = ca327_option2();
                 if( rc != M_CM_OK )
                 {
                    printf(" option2 error \n");
                    return rc;
                 }

             }
          }
          $CLOSE CUR4;
          $FREE  CUR4;

      }
      $CLOSE curx;
      $FREE  curx;

      rgu_finish_report();

   }         /* end if file */
   else
   {

      printf("-->option[%s]\n", option );
      /* Data From ipolicy */
      if( strcmp( option, "1") == 0 )    /* �M�׾��� */
      {
         rc = ca327_build1();
         if ( rc != api_OKComplete )
         {
            printf("ca327_build1 error \n");
            return rc;
         }
      }
      else if( strcmp( option, "2") == 0 )    /* �M�׳q�� */
      {
         rc = ca327_build2();
         if ( rc != api_OKComplete )
         {
            printf("ca327_build2 error \n");
            return rc;
         }
      }
      else
       {                                      /* �C�L���� */
         rc = ca327_build3();
         if ( rc != api_OKComplete )
         {
            printf("ca327_build2 error \n");
            return rc;
         }
      }

      printf("-->choice[%s]\n", choice );

      if( strcmp( choice, "1") == 0 )
      {
         sprintf_s(stmtA, sizeof stmtA , "AND (iofficer[7,8] = 'YF' or iofficer[7,9] in ('Y54','Y55','Y58')) ");
      }
      else if( strcmp( choice, "2") == 0 )
      {
         sprintf_s(stmtA, sizeof stmtA , "AND (iofficer[7,8] = 'YI' or iofficer[7,9] in ('Y07','Y08','Y09','Y10')) ");
      }


      if( strcmp(choice,"3") == 0 && ( strcmp( option, "3") == 0 ) )     /* ���O�檺���ڦC�L */
      {
      	printf(" ********************************************************** \n");
      	rc=car327_receipt();    /* �C�L�������t�~�W�ߥX�� */
        if( rc == M_CM_OK )
        {
          printf("getfile error \n");
          return api_OKComplete;
        }
        else
        {
          return rc;
        }
      }


      printf("stmtA[%s]\n", stmtA);

      strcpy(Full_DBName,get_car_full_db(iipolicy));

      /* �M�ץ�P�_�G�s�WH�g��B������H0-H2 modify by larry 103.01.20 (1021122001_C3)
                     OR ( a.iofficer[1,1] = 'H' AND iofficer[2,2] not in ('0','1','2')) */
      /* �s�W�M��N*�g��P�_    add by sylvia 103.09.18 (1030630002_C1) */
      sprintf_s(sStmt, sizeof sStmt,
          "SELECT a.ipolicy, a.dply_begin, a.dply_end, a.ipro_year, a.ibrand,  "
                 "b.nassured, b.itag, b.iengine, b.aassured, b.aassured_zip,  "
                 "b.fassured, b.fsex  "
           " FROM %s:ply_relation a , %s:policy b  "
           "WHERE a.ipolicy = b.ipolicy  "
           "  AND a.ipolicy = '%s'  "
           "  AND ( a.iofficer[1] = 'W'  "
           "        OR ( a.iofficer in (select unique iofficer_ori from ca_promote_officer  "
           "               where iofficer_ori[1,1] in ('H','N'))) %s ",
            Full_DBName, Full_DBName, iipolicy, stmtA );

      strcpy(sequip_str,equip_instr("18"));
      if( strcmp( option, "1" ) == 0 )
      {
         sprintf_s(sStmt1, sizeof sStmt1," AND b.nequipment[18] in %s ",sequip_str);
         strcat( sStmt, sStmt1 );
      }

      printf("sStmt[%s]\n",sStmt );

      $PREPARE CUR1 FROM $sStmt;
      $DECLARE CUR2 CURSOR for CUR1;
      $OPEN CUR2;

      while(1)
      {
          $FETCH CUR2 INTO $sIpolicy, $sDply_begin, $sDply_end, $sIpro_year, $sIbrand,
                           $sNassured, $sItag, $sIengine, $sAassured, $sAassured_zip,
                           $sFassured, $sFsex;

          if( SQLCODE == SQLNOTFOUND ) break;

          if( strcmp( option, "1" ) == 0 )   /* �M�׾��ҡA�DTobe �� */
          {
              sprintf_s(stmt_11, sizeof stmt_11,
                 "SELECT mdamage_cover  "
                  " FROM %s:ply_ins_type  "
                  "WHERE ipolicy = '%s' AND iins_type = '11'  "
                  "  AND mdamage_cover > 0 ",
                   Full_DBName, sIpolicy );

              printf("stmt_11[%s]\n",stmt_11 );

              $PREPARE CURCC FROM $stmt_11;
              $DECLARE CURD CURSOR for CURCC;
              $OPEN CURD;
              $FETCH CURD INTO $lmdamage_cover;
              $CLOSE CURD;
              $FREE CURD;

              rc = ca327_option1();
              if( rc != M_CM_OK )
              {
                 printf(" option1 error \n");
                 return rc;
              }
          }
          else     /* �M�׳q�� */
          {
              rc = ca327_option2();
              if( rc != M_CM_OK )
              {
                 printf(" option2 error \n");
                 return rc;
              }

          }

      }
      $CLOSE CUR2;
      $FREE  CUR2;

       rgu_finish_report();
   }

   return api_OKComplete;


errexit:
   return SQLCODE;
}
/************************************************************************************/
long  ca327_getfile()
{
    int rtncode;

    $WHENEVER sqlerror goto errexit;

    printf("  into read file \n");
    rtncode = getApHome(sApHome);
    if (rtncode < 0)
    {
         printf("read Config file error!!\n");
         return M_CM_READ_CONFIG_ERR;
    }
    sprintf_s(getfile, sizeof getfile, "%s/dat/car/%s", sApHome, sfile);

    printf("getfile[%s]\n",getfile);
    if ((fp=fopen(getfile,"rt"))==NULL)
    {
        printf("fopen file error \n");
        return FALSE;
    }

    if ((bp=malloc(recLen))==NULL)
    {
         printf("System malloc failed  !\n");
         return FAIL;
    }

    while(fgets(bp,recLen,fp))
    {
         if (feof(fp)) break;
         sTmp[0]='\0';
         GetData(sTmp   , bp    , 1000);

         Len = strlen(trim(sTmp));

         if (Len > 1)
         {
            for(i=0;i<1000;i++)
            {
                if (sTmp[i] == '\0') break;
            }

            strncpy(sData,sTmp,i);
            sData[i-1] = '\0';
            d=strlen(sData);
            sData[d-1]='\0';
            strcpy(sData,rtrim(sData));

            $INSERT INTO CAR327 (ipolicy)
                        VALUES  ($sData);
            tot_count ++;
         }

    } /* end of while */

    printf("tot_count[%d]\n",  tot_count );

    return M_CM_OK;

errexit:
    printf("before SQLCODE \n");
    return SQLCODE;

}

long ca327_build1()
{
   $char  FormFmt[N_FILE+1];
   $int   StartRow, TitleRow, TotColumn, PgLine, Width;

   char   FormFile[N_FILE+1];
   int    i, rcd;
   $char  dbname[8],server[10],t_iclaim[13],t_igroup[7];

   $WHENEVER SQLERROR GOTO errexit;

   $SELECT nForm_File, kStart_Row, kTitle_Row,
                kTot_Col, kPgNum_Line, kWidth, iForm_Tp
           INTO $FormFmt, $StartRow, $TitleRow,
                $TotColumn, $PgLine, $Width, $FormTp
           FROM Form
          WHERE ksys_grp = "CA" AND kPgmID = 327 AND iform_tp = '1';
   strcpy(FormFmt, rtrim(FormFmt));
   sprintf_s(FormFile, sizeof FormFile, "%s.tx", outputf);
   printf("outputf--->[%s]\n",FormFile);

   /* build report  **/
   rgu_init_report(FormFmt, FormFile);

   return api_OKComplete;

errexit:
   /*printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);**/
   return FAIL;
}

long ca327_build2()
{
   $char  FormFmt[N_FILE+1];
   $int   StartRow, TitleRow, TotColumn, PgLine, Width;

   char   FormFile[N_FILE+1];
   int    i, rcd;
   $char  dbname[8],server[10],t_iclaim[13],t_igroup[7];

   $WHENEVER SQLERROR GOTO errexit;

   $SELECT nForm_File, kStart_Row, kTitle_Row,
                kTot_Col, kPgNum_Line, kWidth, iForm_Tp
           INTO $FormFmt, $StartRow, $TitleRow,
                $TotColumn, $PgLine, $Width, $FormTp
           FROM Form
          WHERE ksys_grp = "CA" AND kPgmID = 327 AND iform_tp = '2';
   strcpy(FormFmt, rtrim(FormFmt));
   sprintf_s(FormFile, sizeof FormFile, "%s.tx", outputf);
   printf("outputf--->[%s]\n",FormFile);
   printf("FormFmt[%s], FormFile[%s]\n",FormFmt, FormFile );

   /* build report  **/
   rgu_init_report(FormFmt, FormFile);

   return api_OKComplete;

errexit:
   /*printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);**/
   return FAIL;
}
long ca327_build3()
{
   $char  FormFmt[N_FILE+1];
   $int   StartRow, TitleRow, TotColumn, PgLine, Width;

   char   FormFile[N_FILE+1];
   int    i, rcd;
   $char  dbname[8],server[10],t_iclaim[13],t_igroup[7];

   $WHENEVER SQLERROR GOTO errexit;

   $SELECT nForm_File, kStart_Row, kTitle_Row,
                kTot_Col, kPgNum_Line, kWidth, iForm_Tp
           INTO $FormFmt, $StartRow, $TitleRow,
                $TotColumn, $PgLine, $Width, $FormTp
           FROM Form
          WHERE ksys_grp = "CA" AND kPgmID = 327 AND iform_tp = '3';
   strcpy(FormFmt, rtrim(FormFmt));
   sprintf_s(FormFile, sizeof FormFile, "%s.tx", outputf);
   printf("outputf--->[%s]\n",FormFile);
   printf("FormFmt[%s], FormFile[%s]\n",FormFmt, FormFile );

   /* build report  **/
   rgu_init_report(FormFmt, FormFile);

   return api_OKComplete;

errexit:
   /*printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);**/
   return FAIL;
}
/*ca327_option2(�w����)*/
long ca327_option2()
{


     $long  tIpro_year;

     /* 12 �� */
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);

     /*  �l�H�ϸ�  */
     rgu_put_body_string(13,trim(sAassured_zip),LEFT );
     rgu_put_body(13);

     /*  ���}�B�m�W  */

     rtn=cc_split_chinese(sAassured,buf,50);
     pos=rtn+1;
     rgu_put_body_string(14, buf,          LEFT);
     rgu_put_body(14);
     rtn=cc_split_chinese(substring(sAassured,pos,100),buf,50);
     pos=pos+rtn;
     rgu_put_body_string(15, buf,          LEFT);
     rgu_put_body(15);

     if (sFassured[0]=='1' || sFassured[0]=='3' || sFassured[0]=='5')
     {
         if (sFsex[0]=='1')
         {
             sprintf_s(tmp_nassured, sizeof tmp_nassured,"%s  ����  ��",rtrim(sNassured));
             sprintf_s(buf1, sizeof buf1,"%s  ����",rtrim(sNassured));
         }
         else
         {
             sprintf_s(tmp_nassured, sizeof tmp_nassured,"%s  �p�j  ��",rtrim(sNassured));
             sprintf_s(buf1, sizeof buf1,"%s  �p�j",rtrim(sNassured));
         }
     }
     else
     {
         sprintf_s(tmp_nassured, sizeof tmp_nassured,"%s  ��",rtrim(sNassured));
         sprintf_s(buf1, sizeof buf1,"%s",rtrim(sNassured));
     }

     ben_len=cc_split_chinese(tmp_nassured,tmp_nassured1,50);
     if(strlen(tmp_nassured)>50)
        ben_len=cc_split_chinese(&tmp_nassured[ben_len],tmp_nassured2,50);
     else
        strcpy(tmp_nassured2," ");

     rgu_put_body_string(16, tmp_nassured1,          LEFT);
     rgu_put_body(16);
     rgu_put_body_string(17, tmp_nassured2,          LEFT);
     rgu_put_body(17);

     /* 13 �� */
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);

     ben_len=cc_split_chinese(buf1,tmp_nassured1,50);
     if(strlen(buf1)>50)
        ben_len=cc_split_chinese(&buf1[ben_len],tmp_nassured2,50);
     else
        strcpy(tmp_nassured2," ");

     rgu_put_body_string(31,tmp_nassured1    ,LEFT);
     rgu_put_body(31);
     rgu_put_body_string(32,tmp_nassured2    ,LEFT);
     rgu_put_body(32);

     rgu_put_body(1);

     /* �����B�������X */

     rgu_put_body_string(33,trim(sItag),LEFT);
     rgu_put_body_string(33,trim(sIengine),LEFT);

     rgu_put_body(33);
     rgu_put_body(1);
     rgu_put_body(1);

     $SELECT nbrand
        INTO $sNbrand
        FROM ca_car_model
       WHERE ibrand = $sIbrand
         AND ipro_year = $sIpro_year
         AND drate = '07/01/2001';

     if( SQLCODE == SQLNOTFOUND )
     {

        sprintf_s(stmt_buf, sizeof stmt_buf,"SELECT nbrand, ipro_year  "
                          " FROM ca_car_model  "
                          "WHERE ibrand=?      "
                          "  AND drate = '07/01/2001'  "
                          "ORDER BY 2 DESC");

        $PREPARE Acursor  FROM $stmt_buf;
        $DECLARE Acursor4 CURSOR FOR Acursor;
        $OPEN  Acursor4 USING $sIbrand;
        $FETCH Acursor4 INTO $sNbrand, $tIpro_year;
        $CLOSE Acursor4;
        $FREE  Acursor4;
     }


       strcat(sIpro_year,"�~");

      rgu_put_body_string(35,trim(sIpro_year),LEFT);
      rgu_put_body_string(35,trim(sNbrand),LEFT);
      rgu_put_body(35);
      rgu_put_body(1);

      /*  �O�I����  */
      printf(" ******************************* \n");
      strcpy(str_dply_begin,cm_from_infdate_100(sDply_begin));
      cm_split_ymd_100(str_dply_begin,yy2,mm2,dd2);
      printf(" yy2[%s],mm2[%s],dd2[%s]\n",yy2,mm2,dd2);

      strcpy(str_dply_end,cm_from_infdate_100(sDply_end));
      cm_split_ymd_100(str_dply_end,yy3,mm3,dd3);
      printf(" yy3[%s],mm3[%s],dd3[%s]\n",yy3,mm3,dd3);

      strcpy(str_date,yy2);
      strcat(str_date,"�~");
      strcat(str_date,mm2);
      strcat(str_date,"��");
      strcat(str_date,dd2);
      strcat(str_date,"��");
      strcat(str_date,"  ~  ");
      strcat(str_date,yy3);
      strcat(str_date,"�~");
      strcat(str_date,mm3);
      strcat(str_date,"��");
      strcat(str_date,dd3);
      strcat(str_date,"��");
      printf("25--------------str_date[%s]\n",str_date);
      rgu_put_body_string(38,trim(str_date),LEFT);

      rgu_put_body(38);

      for ( i = 39 ; i <= 67 ; i ++ )
         rgu_put_body(1);

      return M_CM_OK;

errexit:
      return SQLCODE;

}
/******************************************************************************/
int GetData(data,offset,length)
char *data;
int offset,length;
{
    data[0]='\0';
    memcpy(data,offset,length);
    data[length] = 0x00;
    printf("data[%s]\n",data);
}
/*******************************************************************************/
char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
        char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
        char sTmp_db_name[21];

        sTmp_db_name[0]='\0';
        if (*sIpolicy != '\0' && *sIpolicy !=' ')
        {
           sTmp_db_name[0]='\0';
           strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
           strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
                  USE_BRANCH_ID));
           strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
        }
  return sTmp_db_name;
}
/********************************************************************************/
long ca327_option1()  /* �D Tobe */
{

     $long  tIpro_year;

     /* 12 �� */
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);

     /*  �l�H�ϸ�  */
     rgu_put_body_string(13,trim(sAassured_zip),LEFT );
     rgu_put_body(13);

     /*  ���}�B�m�W  */

     rtn=cc_split_chinese(sAassured,buf,50);
     pos=rtn+1;
     rgu_put_body_string(14, buf,          LEFT);
     rgu_put_body(14);
     rtn=cc_split_chinese(substring(sAassured,pos,100),buf,50);
     pos=pos+rtn;
     rgu_put_body_string(15, buf,          LEFT);
     rgu_put_body(15);

     if (sFassured[0]=='1' || sFassured[0]=='3' || sFassured[0]=='5')
     {
         if (sFsex[0]=='1')
         {
             sprintf_s(tmp_nassured, sizeof tmp_nassured,"%s  ���� ��", trim(sNassured));
             sprintf_s(buf2, sizeof buf2,"%s  ����", trim(sNassured));
         }
         else
         {
             printf("======> in lady copy \n");
             sprintf_s(tmp_nassured, sizeof tmp_nassured,"%s  �p�j ��", trim(sNassured) );
             sprintf_s(buf2, sizeof buf2,"%s  �p�j",trim(sNassured) );
             printf("tmp_nassured[%s]\n", tmp_nassured);
             printf("buf2        [%s]\n", buf2 );
         }
     }
     else
     {
         sprintf_s(tmp_nassured, sizeof tmp_nassured,"%s  ��",trim(sNassured)  );
         sprintf_s(buf2, sizeof buf2,"%s", trim(sNassured) );
     }

     ben_len=cc_split_chinese(tmp_nassured,tmp_nassured1,50);
     if(strlen(tmp_nassured)>50)
        ben_len=cc_split_chinese(&tmp_nassured[ben_len],tmp_nassured2,50);
     else
        strcpy(tmp_nassured2," ");

     printf("tmp_nassured1[%s] \n",tmp_nassured1 );
     printf("tmp_nassured2[%s] \n", tmp_nassured2 );

     rgu_put_body_string(16, tmp_nassured1,          LEFT);
     rgu_put_body(16);
     rgu_put_body_string(17, tmp_nassured2,          LEFT);
     rgu_put_body(17);

     /* 9 �� */
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);

     ben_len=cc_split_chinese(buf2,tmp_nassured1,50);
     if(strlen(buf2)>50)
        ben_len=cc_split_chinese(&buf2[ben_len],tmp_nassured2,50);
     else
        strcpy(tmp_nassured2," ");

     printf("tmp_nassured1[%s] \n",tmp_nassured1 );
     printf("tmp_nassured2[%s] \n", tmp_nassured2 );


     rgu_put_body_string(28,tmp_nassured1   ,LEFT);
     rgu_put_body(28);
     rgu_put_body_string(29,tmp_nassured2   ,LEFT);
     rgu_put_body(29);

     /* �����B�������X */

     rgu_put_body_string(30,trim(sItag),LEFT);
     rgu_put_body_string(30,trim(sIengine),LEFT);

     rgu_put_body(30);
     rgu_put_body(1);
     rgu_put_body(1);

     sprintf_s(stmt_buf, sizeof stmt_buf,"SELECT nbrand FROM ca_car_model  "
                       "WHERE ibrand = ? AND ipro_year = ?  "
                       "  AND drate = '07/01/2001' ");
     $SELECT nbrand
        INTO $sNbrand
        FROM ca_car_model
       WHERE ibrand = $sIbrand
         AND ipro_year = $sIpro_year
         AND drate = '07/01/2001';

     if( SQLCODE == SQLNOTFOUND )
     {

        sprintf_s(stmt_buf, sizeof stmt_buf,"SELECT nbrand, ipro_year  "
                          " FROM ca_car_model  "
                          "WHERE ibrand=?      "
                          "  AND drate = '07/01/2001'  "
                          "ORDER BY 2 DESC");

        $PREPARE Acursor5  FROM $stmt_buf;
        $DECLARE Acursor6 CURSOR FOR Acursor5;
        $OPEN  Acursor6 USING $sIbrand;
        $FETCH Acursor6 INTO $sNbrand, $tIpro_year;
        $CLOSE Acursor6;
        $FREE  Acursor6;
     }

     strcat(sIpro_year,"�~");

     rgu_put_body_string(32,trim(sIpro_year),LEFT);
     rgu_put_body_string(32,trim(sNbrand),LEFT);
     rgu_put_body(32);
     rgu_put_body(1);

     /*  �O�I���B  */
     printf(" ******************************* \n");

     rfmtdouble((double) lmdamage_cover/10000, "---&.&&", buf1);

     sprintf_s(buf, sizeof buf,"%s �U��", buf1 );
     printf("buf[%s]\n",buf);
     rgu_put_body_string(34,buf  ,LEFT);
     rgu_put_body(34);

     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);
     rgu_put_body(1);

     rgu_put_body_string(39,trim(sIpolicy),LEFT);
     rgu_put_body(39);
     rgu_put_body(1);

     /*  �O�I����  */
     printf(" ******************************* \n");
     strcpy(str_dply_begin,cm_from_infdate_100(sDply_begin));
     cm_split_ymd_100(str_dply_begin,yy2,mm2,dd2);
     printf(" yy2[%s],mm2[%s],dd2[%s]\n",yy2,mm2,dd2);

     strcpy(str_dply_end,cm_from_infdate_100(sDply_end));
     cm_split_ymd_100(str_dply_end,yy3,mm3,dd3);
     printf(" yy3[%s],mm3[%s],dd3[%s]\n",yy3,mm3,dd3);

     strcpy(str_date,yy2);
     strcat(str_date,"�~");
     strcat(str_date,mm2);
     strcat(str_date,"��");
     strcat(str_date,dd2);
     strcat(str_date,"��");
     strcat(str_date,"  ~  ");
     strcat(str_date,yy3);
     strcat(str_date,"�~");
     strcat(str_date,mm3);
     strcat(str_date,"��");
     strcat(str_date,dd3);
     strcat(str_date,"��");
     printf("25--------------str_date[%s]\n",str_date);
     rgu_put_body_string(41,trim(str_date),LEFT);
     rgu_put_body(41);

     for ( i = 42 ; i <= 68 ; i ++ )
        rgu_put_body(1);

     return M_CM_OK;

errexit:
      return SQLCODE;

}
/*********************************************************************************/
long car327_receipt()
{

   $char  sStmt[1024], sStmt1[200], stmtA[100];
   $char  branch_mprem_chr[10], detail2[3];
     int  rc, rtncode;
   $int  cn_327;
   $long ldpolicy, ldate20060410, ldate20060821,ldate20090401,ldply_begin;

   $WHENEVER sqlerror goto errexit;
   printf(" welcome to receipt \n");
   rstrdate("04/10/2006", &ldate20060410);
   rstrdate("08/21/2006", &ldate20060821);
   rstrdate("04/01/2009", &ldate20090401);

   /*980504, �u�O�O�渹�ӷ��覡���P�A�޿褣�μg�G�M  */
   if (strcmp(type,"2")==0)  /* type=2 => �����e��key�O�渹(�D����) */
   {
      $CREATE TEMP TABLE CAR327
      (
          ipolicy  char(20) default ' '
      )
      WITH NO LOG;

      $CREATE INDEX CAR327_ix1 ON CAR327 (ipolicy);
      $INSERT INTO CAR327 (ipolicy) VALUES  ($iipolicy);
   }

  $DECLARE cur_327_1 CURSOR  for
    SELECT ipolicy
      FROM CAR327;
  $OPEN cur_327_1;
  while(1)
  {
     $FETCH cur_327_1  INTO $Tipolicy;
     if ( SQLCODE == SQLNOTFOUND ) break;

     printf("Tipolicy=[%s]\n", Tipolicy );

     strcpy(Full_DBName,get_car_full_db(Tipolicy));

     /* �M�ץ�P�_�G�s�WH�g��B������H0-H2 modify by larry 103.01.20 (1021122001_C3) */
     /*             OR ( a.iofficer[1,1] = 'H' AND iofficer[2,2] not in ('0','1','2')) */
     /* �s�W�M��N*�g��  add by sylvia 103.09.18 (1030630002_C1) */
     sprintf_s(sStmt, sizeof sStmt,
        "SELECT a.ipolicy, a.dply_begin, a.dply_end, a.ipro_year, a.ibrand,  "
               "b.nassured, b.itag, b.iengine, b.aassured, b.aassured_zip,  "
               "b.fassured, b.fsex , a.dpolicy , a.ibig_office , a.ibig_sales,  "
               "b.nequipment , a.ibrand ,b.iengine ,a.ipro_year, a.dpolicy, a.dply_begin  "
         " FROM %s:ply_relation a , %s:policy b  "
         "WHERE a.ipolicy = b.ipolicy AND a.ipolicy = '%s'  "
         "  AND ( a.iofficer[1] = 'W'  "
                 "OR ( a.ioffice in (select unique iofficer_ori from ca_promote_office  "
                        "where iofficer_ori[1,1] in ('H','N'))) ",
          Full_DBName, Full_DBName, Tipolicy);

     printf("sStmt[%s]\n",sStmt );
     $PREPARE CUR3 FROM $sStmt;
     $DECLARE CUR40 CURSOR for CUR3;
     $OPEN CUR40;

     while(1)
     {
         $FETCH CUR40 INTO $sIpolicy, $sDply_begin, $sDply_end, $sIpro_year, $sIbrand,
                           $sNassured, $sItag, $sIengine, $sAassured, $sAassured_zip,
                           $sFassured, $sFsex, $sDpolicy, $iBig_office , $iBig_sales,
                           $nequipment, $sIbrand, $sIengine,$ipro_year, $ldpolicy,$ldply_begin;

         if( SQLCODE == SQLNOTFOUND ) break;

         if (equip_cmp(nequipment,"5") == TRUE)
         {
               strcpy(sNequipment5,"1");
         }
         else
         {
               strcpy(sNequipment5,"0");
         }
         printf("Trace -- ldate20090401 = [%ld] \n",  ldate20090401);
         printf("Trace -- ldply_begin   = [%ld] \n",  ldply_begin);
         printf("Trace -- ldpolicy      = [%ld] \n",  ldpolicy);
         printf("Trace -- sNequipment5  = [%s ] \n",  sNequipment5);

         if(strcmp(sNequipment5,"1")!=0)
         {
         	 /* 980504*/

         	 if (ldply_begin >= ldate20090401){
         	 	  strcpy(detail2, "7");
         	 }else{
                 if( ldpolicy >= ldate20060821 )
                     strcpy(detail2, "5");
                 else if( ldpolicy >= ldate20060410 )
                     strcpy(detail2, "3");
                 else
                     strcpy(detail2, "1");
             }
             printf("Trace -- detail2 = [%s] \n",  detail2);

             /* �p�G�L�U�L�@�����O �h�u�� 11 �I�ثO�O */
             sprintf_s(sStmt, sizeof sStmt,"select mins_premium from %s:ply_ins_type  "
                           "where ipolicy = '%s' and iins_type = '11'",
                            Full_DBName, Tipolicy);
             $prepare get_ins11_1 from $sStmt;
             $execute get_ins11_1 into $mins_premium;

             $select chiname
                into $branch_mprem_chr
                from car_code
               where kind = 'E1'
                 and detail = $sIbrand
                 and detail2 = $detail2;
             if(SQLCODE == SQLNOTFOUND)
                return M_CA_NBRAND;

             branch_mprem = atol(branch_mprem_chr);
             oth_mprem = branch_mprem - mins_premium;
             printf(" mins_premium[%d]\n",mins_premium);
             printf(" branch_mprem[%d]\n",branch_mprem);
             printf(" oth_mprem[%d]\n",oth_mprem);
         }
         else
         {
             /* �p�G���U�L�@�����O �h�� 11 14 17 �I�ثO�O */
             printf(" *****************************************\n");
         	 /* 980504*/
         	 if (ldply_begin >= ldate20090401){
         	 	  strcpy(detail2, "8");
         	 }else{
                 if( ldpolicy >= ldate20060821 )
                     strcpy(detail2, "6");
                 else if( ldpolicy >= ldate20060410 )
                     strcpy(detail2, "4");
                 else
                     strcpy(detail2, "2");
             }
             /* 980504,�s�O�v14����,��19 (14,19���|�P�ɦs�b)*/
             sprintf_s(sStmt, sizeof sStmt,"select sum(mins_premium) from %s:ply_ins_type  "
                            "where ipolicy = '%s'  "
                            "  and iins_type in ('11','14','17','19')",
                             Full_DBName, Tipolicy);
             printf("stmt=[%s]\n", sStmt );
             $prepare get_ins11_2 from $sStmt;
             $execute get_ins11_2 into $mins_premium;

             printf("detail=[%s]\n", detail2 );

             $select chiname
                into $branch_mprem_chr
                from car_code
               where kind = 'E1'
                 and detail = $sIbrand
                 and detail2 = $detail2;
             if(SQLCODE == SQLNOTFOUND)
                return M_CA_NBRAND;

             branch_mprem = atol(branch_mprem_chr);
             oth_mprem = branch_mprem - mins_premium;

             printf(" mins_premium[%d]\n",mins_premium);
             printf(" branch_mprem[%d]\n",branch_mprem);
             printf(" oth_mprem[%d]\n",oth_mprem);
         }

         rc=ca327_option3();
         if( rc != M_CM_OK )
         {
             printf(" option3 error \n");
             return rc;
         }
     }
     $CLOSE CUR40;
     $FREE  CUR40;

  }
  $CLOSE cur_327_1;
  $FREE  cur_327_1;


   rgu_finish_report();

   return api_OKComplete;

errexit:

   printf("SQLCODE == [%d]\n", SQLCODE );
   return SQLCODE;
}


long ca327_option3()  /* ���ڦC�L  */
{

 $long  tIpro_year;
 $char ipolicytmp[4];
 $char ipolicy2[1];
 char  nyy[4];/*��t�Τ��*/
 char  nmm[3];
 char  ndd[3];
 char  bch_date[12];
 char  ech_date[12];
 char  syy[4],smm[3],sdd[3],eyy[4],emm[3],edd[3];/*��O�I����*/
 $char empname[11];
 char  tempstr[81];
 char  cch_date[12];
 char  tyy[4];/*��ñ����*/
char  tmm[3];
char  tdd[3];
$char  sStmt[1024];
$char ibig_branch[21];
$char brandh_nname[11];
$char ibig_branch_sales[21];
$char nbrand_s[27];
 $char str_oth_mprem[4];
 $char str_oth_mprem_1[2];
 $char str_oth_mprem_2[2];
 $char str_oth_mprem_3[2];
 $char str_oth_mprem_4[2];
 $int  tmp_prem,mod_prem;
 char  ch_amt1[40],ch_amt2[40],ch_amt3[40],ch_amt4[40],ch_amt5[40];
 char str_money[40];
 char str_office_sales[25];
 $char drate[11], sToday[11];
 long  dToday;

/*********�P�_�O�渹�ĤT�X,�a�X�t�d�H 0:�Y�ͮ� 1:�\�y�� 2:�����****/

printf(" welcome to printf receipt \n");

if(strcmp(sNequipment5,"1")==0)
{
        rgu_put_body_string(2,"�ΫH�ѵs�I�[�U�L�@���M��",1);
}
else
{
        rgu_put_body_string(2,"�ΫH�ѵs�I�M��",1);

}

strncpy(ipolicytmp,sIpolicy,3);  /*���O��e�T�X*/
ipolicytmp[3] = '\0';
strcpy(ipolicy2,ipolicytmp+2);

   if (strcmp(ipolicy2,"0") == 0)
   {
     rgu_put_body_string(2,"�x",1);
     rgu_put_body_string(2,"�_",1);
     $SELECT npresident
        INTO $empname
        FROM branch
       WHERE ibranch = '00';

     printf("�x�_�t�d�H : %s \n", empname);

     rgu_put_body_string(3,empname,1);

     printf("chk2 ipolicy2 = [%s]-----[%s]\n",ipolicy2);
   }
   else if(strcmp(ipolicy2,"1") == 0)
   {
      rgu_put_body_string(2,"�x",1);
      rgu_put_body_string(2,"��",1);

      $SELECT npresident
         INTO $empname
         FROM branch
        WHERE ibranch = '40';

      printf("�x���t�d�H : %s \n", empname);

      rgu_put_body_string(3,empname,1);

      printf("chk2 ipolicy2 = [%s]\n",ipolicy2);

   }
   else if( strcmp(ipolicy2,"2") == 0)
   {
      rgu_put_body_string(2,"��",1);
      rgu_put_body_string(2,"��",1);

      $SELECT npresident
         INTO $empname
         FROM branch
        WHERE ibranch = '70';

      printf("�����t�d�H : %s \n", empname);

      rgu_put_body_string(3,empname,1);
      printf("chk2 ipolicy2 = [%s]\n",ipolicy2);
   }
   else if( strcmp(ipolicy2,"5") == 0)
   {
      rgu_put_body_string(2,"�O",1);
      rgu_put_body_string(2,"��",1);

      $SELECT npresident
         INTO $empname
         FROM branch
        WHERE ibranch = '22';

      printf("�O���t�d�H : %s \n", empname);

      rgu_put_body_string(3,empname,1);
      printf("chk2 ipolicy2 = [%s]\n",ipolicy2);
   }
   else if( strcmp(ipolicy2,"6") == 0)
   {
      rgu_put_body_string(2,"��",1);
      rgu_put_body_string(2,"��",1);

      $SELECT npresident
         INTO $empname
         FROM branch
        WHERE ibranch = '33';

      rgu_put_body_string(3,empname,1);
      printf("chk2 ipolicy2 = [%s]\n",ipolicy2);
   }
   else if( strcmp(ipolicy2,"7") == 0)
   {
      rgu_put_body_string(2,"�x",1);
      rgu_put_body_string(2,"�n",1);

      $SELECT npresident
         INTO $empname
         FROM branch
        WHERE ibranch = '66';

      rgu_put_body_string(3,empname,1);
      printf("chk2 ipolicy2 = [%s]\n",ipolicy2);
   }


/*****************�P�_���Y�O�_���šA�_�h�a�X�Ȥ�W��***************/


    rgu_put_body_string(4,sNassured,1); /*�Q�O�I�H*/


/*********************�H�U�q�X�t�Τ��***************/

  dToday = cm_today();
  strcpy(sToday , cm_cdate_str_100(dToday));
  cm_split_ymd_100(sToday, nyy, nmm, ndd);

  printf("nyy=%s\n",nyy);
  printf("nmm=%s\n",nmm);
  printf("ndd=%s\n",ndd);

  rgu_put_body_string(5,nyy,2);  /*�L�X�t�Φ~���*/
  rgu_put_body_string(5,nmm,2);
  rgu_put_body_string(5,ndd,2);

  /*�ͮİ_���������*/
  strcpy(bch_date,cm_from_infdate_100(sDply_begin));
  cm_split_ymd_100(bch_date,syy,smm,sdd);
  strcpy(ech_date,cm_from_infdate_100(sDply_end));
	cm_split_ymd_100(ech_date,eyy,emm,edd);

  /*ñ��������*/
  strcpy(cch_date,cm_from_infdate_100(sDpolicy));
  cm_split_ymd_100(cch_date,tyy,tmm,tdd);

/********** �O��O�O�B���O�O�Φ����r���ഫ *********************/





 rgu_put_body_string(9,sIpolicy,1); /*�O�渹�X*/
 rgu_put_body_string(9,syy,1);
 rgu_put_body_string(9,smm,1); /*�_��*/
 rgu_put_body_string(9,sdd,1); /*�_��*/
 rgu_put_body_string(9,eyy,1); /*�W�~*/
 rgu_put_body_string(9,emm,1); /*�W��*/
 rgu_put_body_string(9,edd,1); /*�W��*/

 strcpy(str_mins_premium,itoa(mins_premium));
 rgu_put_body_string(9,str_mins_premium,1); /* �O�I�O */
  printf(" str_mins_premium [%s] \n",str_mins_premium);


/********************* �C�L�O�I�O�b����p *******************/

 strcpy(str_oth_mprem,itoa(oth_mprem));
 printf(" str_oth_mprem [%s] \n",str_oth_mprem);

            tmp_prem=oth_mprem/10000;
            mod_prem=oth_mprem%10000;
            num_to_chinese(ch_amt1,tmp_prem);     /*�N���ԧB�Ʀr�ন����j�g�Ʀr*/
            if (tmp_prem==0) strcpy(ch_amt1,"�s");

            tmp_prem=mod_prem/1000;
            mod_prem=mod_prem%1000;
            num_to_chinese(ch_amt2,tmp_prem);
            if (tmp_prem==0) strcpy(ch_amt2,"�s");

            tmp_prem=mod_prem/100;
            mod_prem=mod_prem%100;
            num_to_chinese(ch_amt3,tmp_prem);
            if (tmp_prem==0) strcpy(ch_amt3,"�s");

            tmp_prem=mod_prem/10;
            mod_prem=mod_prem%10;
            num_to_chinese(ch_amt4,tmp_prem);
            if (tmp_prem==0) strcpy(ch_amt4,"�s");
            num_to_chinese(ch_amt5,mod_prem);
            if (mod_prem==0) strcpy(ch_amt5,"�s");

            strcpy(ch_amt1,trim(ch_amt1));
            strcpy(ch_amt2,trim(ch_amt2));
            strcpy(ch_amt3,trim(ch_amt3));
            strcpy(ch_amt4,trim(ch_amt4));
            strcpy(ch_amt5,trim(ch_amt5));


            strcpy(str_money,"");
            strcat(str_money,ch_amt1);
            strcat(str_money,"�U");
            strcat(str_money,ch_amt2);
            strcat(str_money,"�a");
            strcat(str_money,ch_amt3);
            strcat(str_money,"��");
            strcat(str_money,ch_amt4);
            strcat(str_money,"�B");
            strcat(str_money,ch_amt5);
            strcat(str_money,"��");

          printf(" str_money [%s] \n",str_money);


    rgu_put_body_string(19,str_money,1); /*�O�O*/
    rgu_put_body_string(20,sNassured,1); /*�Q�O�I�H*/

   printf(" iBig_office[%s]\n",iBig_office);
    $SELECT nname
       INTO $brandh_nname
       FROM officer
      WHERE iofficer = $iBig_office;


    if (SQLCODE==SQLNOTFOUND)
    {

      strcpy(brandh_nname, " ");
    }


    printf(" brandh_nname[%s]\n",brandh_nname);


    strcpy(brandh_nname,trim(brandh_nname));


    printf(" iBig_sales[%s] \n",iBig_sales);
    $SELECT nname
       INTO $ibig_branch_sales
       FROM ca_big_office
      WHERE ibig_comp = $iBig_sales
        AND fclass = '2';
    if (SQLCODE==SQLNOTFOUND)
    {
      strcpy(ibig_branch_sales, " ");
    }

   printf(" sIbrand[%s]\n",sIbrand);
   $DECLARE CA_OPT1 CURSOR FOR
      SELECT drate,nbrand[1,26]
        INTO $drate,$nbrand_s
        FROM ca_car_model
       WHERE ibrand    = $sIbrand
         AND ipro_year = $ipro_year
       ORDER BY drate DESC;
    $OPEN CA_OPT1;
    $FETCH CA_OPT1;

    if (SQLCODE==SQLNOTFOUND)
    {

        $DECLARE CA_OPT1A CURSOR FOR
          SELECT drate,nbrand[1,26]
            INTO $drate,$nbrand_s
            FROM ca_car_model
           WHERE ibrand   =$sIbrand
             AND ipro_year=(SELECT MAX(ipro_year)
                              FROM ca_car_model
                             WHERE ibrand=$sIbrand)
           ORDER BY drate DESC;
        $OPEN CA_OPT1A;
        $FETCH CA_OPT1A;

        printf(" nbrand_s[%s]\n",nbrand_s);
        printf(" drate[%s]\n",drate);

           if (SQLCODE==SQLNOTFOUND)
           {

                   strcpy(nbrand_s, " ");
           }


        $CLOSE CA_OPT1A;
        $FREE CA_OPT1A;
    }
    $CLOSE CA_OPT1;
    $FREE CA_OPT1;


   strcpy(str_office_sales,trim(brandh_nname));
   strcat(str_office_sales,"   ");
   strcat(str_office_sales,trim(ibig_branch_sales));

    printf(" nbrand_s[%s]\n",nbrand_s);
    rgu_put_body_string(24,trim(nbrand_s),1); /* �t�� */
    rgu_put_body_string(24,trim(sIengine),1); /* �������X  */
    rgu_put_body_string(24,trim(str_office_sales),1); /*�g�P��  �~�N*/




 /*   for ( i = 42 ; i <= 68 ; i ++ )
        rgu_put_body(1);                */

    for (i = 1;i <= 21;i++)rgu_put_body(i);
    rgu_put_body(27);
    for (i = 22;i <= 26;i++)rgu_put_body(i);


  return M_CM_OK;

errexit:
printf(" ************** \n");
     return SQLCODE;

}
/******************************************************************************/
long ca327_policyB_print()
{
	  $char FormFile[N_FILE+1], upd_str[500], upd_str_E[500], iestimate[21];
	  $char ipolicyB[21],iengine[21],comp_DB[3];
	  $char ipolicy_A[21],ipolicy_B[21],iofficer[11];
	  $char payresult[5], paystatus[100], paydate[100], notedate[100];
	  $char date[11],dToday[11],nyy[4],nmm[3],ndd[3];
	  $char stmt[2048],v_sMsg[1024],stmt2[500],stmt3[500],stmt4[50],stmt5[500];
	  $int  ibatch_no,sIpolicyB_type,rc,PgLine,dprint_yn,fstatus,rc2;
	  $long ldend,t, mcover_sum;
	  char  filename[201],fname[101],errmsg[201],Msg[201];
	  $char sftype_pol[3],sftype_sp[3],dpolicy_ori[11], ipolicy_main[21],icard_main[21];
	  $int  f1040301,f1040101,icount_10,icount_20,icount_RN;
	  int  cnt;
	  $char rba_HG[2],chk_rba_print[2];
	  $int rba_cnt,rba_max;
	  $char feedr[2],siserno[3],iendorse[21],sIroute[21];
	  $char yyyy[5];
	  $int  eply_cnt;
	  $int  iserno;
	  $int  chk_ftype;
	  $int  fsign_status;
	  
	  /* 1070809006_SC3_�ѵs�I�O����A���ƱĹq�l�O�洣�� */
	  $char feply[2],e_nfile[36],sIcomp_in[3],sIapplicant[13],sPasswd[13],sAemail_eply[51],dend_e[11],dbgn_e[11],sTmobile_eply[21];  

	  dprint_yn = 0; /* �O��C�L���A: 0:���C�L;1:�w�C�L */
	  mcover_sum =0;   /* A���`�O�B */
          t = cm_today();
          strcpy(date,cm_edate_str(t));
          strcpy(dToday,cm_from_infdate_100(date));
          cm_split_ymd_100(dToday,nyy,nmm,ndd);


	  $WHENEVER SQLERROR GOTO errexit;
	  $SET LOCK MODE TO WAIT;

	  $BEGIN WORK;

	  $SELECT kPgNum_Line, nForm_File
	     INTO $PgLine, $FormFile
             FROM Form
            WHERE ksys_grp="CA" AND kPgmID = 306;

          printf("filename[%s]\n",FormFile);
          strcpy(FormFile,rtrim(FormFile));
          sprintf_s(OutFile, sizeof OutFile,"%s.tx",outputf);

          rgu_init_report(FormFile, OutFile);

          strcpy(filename," ");
          strcpy(fname," ");
          sprintf_s(fname, sizeof fname,"car327_policyB_detial[%s].txt",outputf);
          sprintf_s(filename, sizeof filename,"%s/rptftp/%s",sApHome,fname);
          printf("car327_policyB[%s]\n",filename);
          fp=fopen(filename,"w");
          cnt = 0;
          $DECLARE policyB_cur CURSOR with hold for
            SELECT ipolicy
              INTO $ipolicyB
              FROM CAR327;
          $OPEN policyB_cur;

	  for(;;)
	  {
	      $FETCH policyB_cur;
	      printf("1------ipolicyB[%s]-------\n",ipolicyB);
	      if(SQLCODE == SQLNOTFOUND) break;

              strcpy(siserno,"");
              strcpy(sIroute,"");
              strcpy(yyyy,"");
              fsign_status=0;
              
              strcpy(ipolicyB,trim(ipolicyB));
              printf("2------ipolicyB[%s]-------\n",ipolicyB);
	      strcpy(Full_DBName,get_car_full_db(ipolicyB));
	      /* �M�ץ�P�_�G�s�WH�g��B������H0-H2 modify by larry 103.01.20 (1021122001_C3)
	                     OR (a.iofficer[1,1] = 'H' AND  a.iofficer[2,2] not in ('0','1','2'))*/
	      /* �s�W�M��N*�g��P�_  add by sylvia 103.09.18 (1030630002_C1) */
	      /* �t�X����Ʈw����(�p�򶩥�22��00), �s�W�Hicard_main(���pA��d��)�dA���� add by sylvia 106.02.08 */
	      strcpy(ipolicy_main," ");
	      sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy,a.ibatch_no,a.icomp_in,b.iengine,a.dply_end,  "
	                          "a.iofficer, case when a.dpolicy is null then 0 else 1 end,   "
	                          "a.itmp_policy, (select fstatus from cm_pre_receive  "
	                          "where iins_cat = 'C' and iins_kind = '2' and ipre_rcv = a.itmp_policy),  "
	                          "dpolicy,nvl((select ipolicy from card where icard = a.icard_main),' '),a.icard_main,  "
	                          "a.feply,b.iapplicant,b.iassured,a.aemail_eply,a.dply_end,a.tmobile_eply,b.iroute,year(nvl(a.dpolicy,today)),a.dply_begin,a.fsign_status   "
	                    " FROM %s:ply_relation a ,%s:policy b  "
	                    "WHERE a.ipolicy = b.ipolicy  "
	                    "  AND a.ipolicy = '%s'  "
	                    "  AND (a.iofficer[1,1] = 'W' or a.iofficer in  "
	                          "(select unique iofficer_ori from ca_promote_officer  "
	                          "  where iofficer_ori[1,1] in ('H','N')))",
                         Full_DBName,Full_DBName,ipolicyB);
              $PREPARE get_B FROM $stmt;
	      $DECLARE get_Bd CURSOR  FOR get_B;
	      $OPEN get_Bd;
	      strcpy(dpolicy_ori,"");
	      $FETCH get_Bd INTO $ipolicy_B,$ibatch_no,$comp_DB,$iengine,$ldend,$iofficer,
	                         $dprint_yn,$iestimate,$fstatus,$dpolicy_ori,$ipolicy_main,$icard_main,
	                         $feply,$sIapplicant,$sPasswd,$sAemail_eply,$dend_e,$sTmobile_eply,$sIroute,$yyyy,$dbgn_e,$fsign_status;
	      if(SQLCODE == SQLNOTFOUND)
	      {
	         printf("---- SQLNOTFOUND ---- \n");
	      	 fprintf(fp,"�O�渹�G%s\t�D�M�ץ�O��\n",ipolicyB);
	      	 $CLOSE get_Bd;
	         $FREE  get_Bd;
	         continue;
	      }
	      $CLOSE get_Bd;
	      $FREE  get_Bd;

	      strcpy(iengine,trim(iengine));
	      printf("-----iengine[%s],dply_end[%d]-----\n",iengine,ldend);
	      /** B�檺�������Ӭd��A��(�O�渹) **/
	      /* �s�W�M��N*�g��P�_ add by sylvia 103.09.18 (1030630002_C1) */
	      /* AND NOT (a.iofficer[1,1] = 'H' AND a.iofficer[2,2] not in ('0','1','2')) */
	      /* �W�[AB�����p�d�����P�_ (1070712005_SC1) */
	      
              sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy,  "
                            "nvl((select sum(mdamage_cover) from %s:ply_ins_type c  "
                                " where c.ipolicy = a.ipolicy),0)  "
	                    " FROM %s:ply_relation a , %s:policy b  "
	                    "WHERE a.ipolicy = b.ipolicy  "
	                    "  AND a.fcard_class = '2'  "
	                    "  AND a.iresource <> 'E'  "
	                    "  AND b.iengine = '%s'  "
	                    "  AND a.dply_end >= %d AND a.dply_end <= %d  "
	                    "  AND a.icard = '%s'  "
	                    "  AND a.fedr_class <> '1'  "
	                    "  AND nvl(a.ibig_comp,' ') <> ' '  "
	                    "  AND a.iofficer[1,1] <> 'W'  "
	                    "  AND a.iofficer not in  "
	                    "     (select unique iofficer_ori from ca_promote_officer  "
	                    "       where iofficer_ori[1,1] in ('H','N')) ",
	                       Full_DBName,Full_DBName, Full_DBName, iengine, ldend-30, ldend+30, icard_main);
	                       
	      $PREPARE get_A FROM $stmt;
	      $DECLARE get_Ad CURSOR FOR get_A;
	      $OPEN get_Ad;
	      $FETCH get_Ad INTO $ipolicy_A, $mcover_sum;
	      if(SQLCODE == SQLNOTFOUND)
	      {
	        /* ��Hipolicy_main(���pA�渹)�d add by sylvia 106.02.08 */
	        /* A�洫�d���i��ɭPipolicy_main���ťաA�P�_�ɼW�[trim (1100802014_SC1) */
	        if (strlen(trim(ipolicy_main)) > 10)
	        {
	            strcpy(ipolicy_A,ipolicy_main);
	            mcover_sum = 0;
	            strcpy(Full_DB_A,get_car_full_db(ipolicy_A));
            
	            sprintf_s(stmt2, sizeof stmt2,"select sum(mdamage_cover) from %s:ply_ins_type  "
	                           "where ipolicy = '%s'",Full_DB_A,ipolicy_main);
	            $PREPARE get_A1 FROM $stmt2;
	            $DECLARE get_Ad1 CURSOR FOR get_A1;
	            $OPEN get_Ad1;
	            $FETCH get_Ad1 INTO  $mcover_sum;
	            $CLOSE get_Ad1;
	            $FREE  get_Ad1;
	            
	            if (mcover_sum == 0)
	            {
	                fprintf(fp,"B��G%s\t�d�LA��(�O�渹)\n",ipolicy_B);
    	                $CLOSE get_Ad;
    	                $FREE  get_Ad;
    	                continue;
	            }
	        }
	        else
	        {
	            fprintf(fp,"B��G%s\t�d�LA��(�O�渹)\n",ipolicy_B);
	            $CLOSE get_Ad;
	            $FREE  get_Ad;
	            continue;
	        }
	      }
	      $CLOSE get_Ad;
	      $FREE  get_Ad;

	      printf("-----ipolicy_A[%s]-----\n",ipolicy_A);

	      /* �t�X���O�X��104/01/01�W�u, car330�u�t�d���O�渹,���^��ñ���,�]�����ެO�_�w���O... modify by sylvia 103.12.16 (1031111001_C3) */
              $select first 1 case when today >= '03/01/2015' then 1 else 0 end,
                              case when today >= '01/01/2015' then 1 else 0 end
                 into $f1040301,$f1040101
                 from policy_302;

	      /* �t�X���O�X��104/01/01�W�u,B�楼���O���i�C�L add by sylvia 103.12.10 (10311110001_C3) */
	      strcpy(sftype_pol," "); strcpy(sftype_sp," ");
	      $select ftype_pol,ftype_sp
	         into $sftype_pol, $sftype_sp
	         from cm_pre_receive
	        where iins_cat = 'C'
	          and ipre_rcv = $iestimate and iins_kind = '2';

	       /* �@�리�O�X���(sftype_sp=PA)�B�e�u���^��ftype_sp���O��(sftype_sp=PA)��
	          �W�L103/01/01�L�檺��O��(RN)�����ˮ֬O�_�w���O   */
	       /* ********************************************************************* */
	       /* �ˮ֬O�_��104/01-02�������O�� */

	       /* RN�w�q�קאּ--�L����O��,�䤺�e�t(103.12.25���e�{�ɷ|�Mĳ)(103.12.27 modify by sylvia):
	            (1)ñ��� < 104/01/01
                (2)�ͮĤ� < 104/01/01�A�B��104/02/28�e�����X��鵲�C
                (3)�ͮĤ鬰 104/01/01~104/02/28 ���¨��A�B��104/02/28�e�����X��鵲�C
                    �¨��w�q�G�]�ͮĦ~�� - �o�Ӥ�~��^ >   1 �Ӥ�   (�u�ݤ��)
           ************************************************************************* */

	       $select count(*) into $icount_RN
                  from policy_302
                 where dply_begin <= '02/28/2015'
                   and iofficer[1,1] in ('W','N','H')
                   and (iestimate_ori = $iestimate or iestimate_sug = $iestimate);

               if ((f1040301 == 0) && (icount_RN > 0))
               {
                   strcpy(sftype_pol,"NA");
	           strcpy(sftype_sp,"RN");
               }


               if ((strcmp(sftype_sp,"PA") == 0 )||(strlen(trim(sftype_sp)) == 0))
	       {
                   if (fstatus < 50)
                   {
      	               printf("----ipolicy_B[%s], fstatus[%d]----\n", ipolicy_B, fstatus);
      	               /** �����O�O�椣�i�C�L **/
   	               strcpy(ipolicy_B, trim(ipolicy_B));
   	      	       printf("�����O�O�椣�i�C�L!\n");
   	               fprintf(fp,"B��G%s �|�����O���i�C�L�O��!\n",ipolicy_B);
   	               continue;

      	           }
	       }


	       /* �t�X���O�X��104/01/01�W�u,A��h�O���i�C�L add by sylvia 103.12.10 (10311110001_C3) */
	       if (mcover_sum <=0)
	       {
	           printf("A��h�O���i�C�L!\n");
	           fprintf(fp,"B��G%s A��G%s\t�w�h�O���i�C�L\n",ipolicy_B,ipolicy_A);
	           continue;
	       }

	       /* ���F�O��϶��i�H���ˮ�A��O�_�w���O�~....��l���n�ŦXA��w���O�B���h�O... modify by sylvia 103.12.16 */
	       /*if ( (strncmp(iofficer+(7-1),"FW",2)==0) || (strncmp(opt,"2",1) == 0) ||
	            (strncmp(iofficer+(7-1),"C15",3)==0)|| (strncmp(iofficer+(7-1),"C17",3)==0)) */
	       if (strncmp(opt,"2",1) == 0)
	       {
	       }
	       else{
	           ao_chk_charge(comp_DB, '1', ipolicy_A, " ", " ",
	                         payresult, paystatus, paydate, notedate);
	           printf("----ipolicy_A[%s], payresult[%s]----\n", ipolicy_A, payresult);
	           /** �����O�O�椣�i�C�L **/
	           /* 103.12.22 �ɤ��q�����ˮ�A��O�_�w���O mark by sylvia 103.12.22 */
	           /*if (payresult[0] != 'R')
	           {
	      	       printf("�����O�O�椣�i�C�L!\n");
	               fprintf(fp,"B��G%s A��G%s\t�|�����O\n",ipolicy_B,ipolicy_A);
	               continue;
	           }*/
	       }
	      
	       /*�P�_�Y�������I�W��O�_�w�g�}��L
	       rc = cm_preview_done_noisid(" ",ipolicy_B," "," ",rba_HG,rba_cnt,rba_max);
	       if (rc != SUCCESS)
	       {
		   fprintf(fp, "�O�渹[%s],�����I�W��d�ߦ��~", ipolicy_B); 
		   goto errexit;
	       }
	       if(strncmp(rba_HG,"Y",1) ==0)
	       {
		   $SELECT first 1 case when ilog_number2 = 'D' then 'Y' else 'N' end 
		      INTO $chk_rba_print
		      FROM ca_log 
		     WHERE ipgid = 'car163' 
		       AND itype = 'O' 
		       AND ilog_number2 = 'D' 
		       AND ilog_number1 = $ipolicy_B;
			    
		   if (SQLCODE == SQLNOTFOUND) strcpy(chk_rba_print,"N");
			   
		   if(strcmp(chk_rba_print,"Y") !=0)
		   {
			fprintf(fp, "�O�渹[%s],�����I�W��ޱ��ݭ��O���O�A��ñ�֦ܭӫO��", ipolicy_B);
           		continue;
		   }
	        }*/
	        
                /*�ˮ֬O�_�f�ֳq�L�Afsign_status>=30 ---------------------------------*/
                /*1091021005_SC5_�s�W�A�Ȥ��ߩ�����*/
                if  (fsign_status < 30 && dprint_yn == 0)
                {
	                fprintf(fp,"�O�渹[%s]:���i�L��A�]���`�����q�|���f�֩��",ipolicy_B);
	                continue; 
                }
        
                /*--------------------------------------------------------------------*/
	        
	        /*1090521001_SC1_�}��M�ץ�i���q�l�O��EMAIL�b��*/
	        /*** �D�q�l�O��ݥ���אּ�q�l�O���A�ɱH�e�q�l�O�� ***/
                if (strcmp(feply,"1",1) != 0 && strcmp(chk_eply,"1",1) == 0)
            	{
	                fprintf(fp,"�O�渹[%s]:�Цܧ��{�����q�l�O����O�A�l�i�i��ɵo�@�~",ipolicy_B);
	                continue; 
            	}
            	
	        printf("---------�ɵo[%s]-------------\n",choice);
	        strcpy(feply,trim(feply));
		/* 1070809006_SC3_�ѵs�I�O����A���ƱĹq�l�O�洣�� */
		/* 1080417001_SC3_�s�W�q�l�O��H²�T�覡�o�e */
		if(strcmp(feply,"1",1) == 0 && dprint_yn == 0)
		{
			/* �q�l�O�椣�ݦL�X�ȥ���ơA�ݱN�O���Ƽg�J�q�l�O������ */
			strcpy(sIcomp_in,comp_DB);
			
			/*�O�o���ɦW*/
        	        strcpy(e_nfile,"");
        	        strcat(e_nfile,"P17CAR_");
        	        strcat(e_nfile,trim(ipolicy_B));
        	        strcat(e_nfile,"_");
        	        strcat(e_nfile,trim(yyyy));
        	        strcpy(e_nfile,trim(e_nfile));
			
			
			/*TWCA���ɦW*/
			/*
    		        strcpy(e_nfile,trim(ipolicy_B));
    		        strcat(e_nfile,"01");
                        */
                        
        	        /*�O�o�q�l�O��*/
            	        $INSERT INTO cm_e_policy(iins_cat,ipolicy,iendorse,iserno,ftype,fspeed,iins_kind_ply,iendorse_ti,
            	                             fprocess,fdata,ibranch_code,icustomer,npassword,nemai_send,tsms_mobile,
            	                             nfile,dbgn,dend,fstatus,iapplicant,iassured,ientry,dentry,iupdate,dupdate,
            	                             nplyidx1,nplyidx2,nplyidx3,nedridx1,nedridx2,nedridx3)
				     VALUES ('C',$ipolicy_B,' ','01','2',1,'C2',' ',
				             'A','P',$sIcomp_in,$sIapplicant,$sPasswd,$sAemail_eply,$sTmobile_eply,
				             $e_nfile,$dbgn_e,$dend_e,100,$sIapplicant,$sPasswd,$userid,CURRENT,$userid,CURRENT,
				             ' ',' ',' ',' ',' ',' ');
				             
			/*TWCA�q�l�O��*/
			/*
        	        $INSERT INTO cm_e_policy(iins_cat,ipolicy,iendorse,iserno,ibranch_code,icustomer,npassword,nemai_send,tsms_mobile,nfile,dend,fstatus,ientry,dentry,iupdate,dupdate)
				         VALUES ('C',$ipolicy_B,' ','01',$sIcomp_in,$sIapplicant,$sPasswd,$sAemail_eply,$sTmobile_eply,$e_nfile,$dend_e,100,$userid,CURRENT,$userid,CURRENT);
			*/	
			  
			sprintf_s(upd_str_E, sizeof upd_str_E,"update %s:ply_relation set dpolicy = today , fprint = '1' where ipolicy = '%s'",
	                           Full_DBName,ipolicy_B);
                        printf("upd_str_E=[%s]\n",upd_str_E);
                        $PREPARE per_upd_dpolicy_E FROM $upd_str_E;
                        $EXECUTE per_upd_dpolicy_E;

                        if ((fstatus == 10) || (fstatus == 40))
                            fstatus = 30;
                        else if (fstatus == 50)
                            fstatus = 60;

                        $update cm_pre_receive
                            set dprint = current,
                                fstatus = $fstatus,
                                iupdate = 'CAR327',
                                dupdate = current
                          where iins_cat = 'C'
                            and ipre_rcv = $iestimate
                            and iins_kind = '2'
                            and ipolicy1 = $ipolicy_B;
		}
		else if(strcmp(feply,"1",1) == 0 && dprint_yn == 1 && strcmp(chk_eply,"1",1) == 0)
		{
			strcpy( iendorse, "");
			strcpy( feedr, "");
			strcpy(sIcomp_in,comp_DB);
			strcpy(Full_DB_B,get_car_full_db(ipolicy_B));
			
                        sprintf_s(stmt3, sizeof stmt3, " SELECT first 1 iendorse,feedr "
                                        "   FROM %s:edr_relation "
                                        "  WHERE ipolicy = '%s'"
                                        "    AND iendorse not like '%%CVP%%'"
                                        "  ORDER BY dcreate DESC; ", Full_DB_B, ipolicy_B );
                        printf("[%s]\n", stmt3);
                        $PREPARE prep1 FROM $stmt3;
                        $EXECUTE prep1 INTO $iendorse,$feedr;
                        
                        /*** ��w���q�l�O��A�����z�Le�O���ɵo�q�l�O�� ***/
		        strcpy(iendorse,trim(iendorse));
	                if(strcmp(iendorse,"")==0)
			    sprintf_s(stmt4, sizeof stmt4," ");
		        else
			    sprintf_s(stmt4, sizeof stmt4,"AND iendorse = '%s'",iendorse);

		        sprintf_s(stmt5, sizeof stmt5, " select count(*)       "
                                        "   from cm_e_policy    "
                                        "  WHERE ipolicy = '%s' "
                                        "    %s ;" , ipolicy_B,stmt4 );
				
		        printf("stmt5[%s]\n",stmt5);
				
		        $PREPARE prep_cnt FROM $stmt5;
        	        $EXECUTE prep_cnt INTO $eply_cnt;
            	    
            	        printf("eply_cnt[%d]ipolicy_B[%s]iendorse[%s]\n",eply_cnt,ipolicy_B,iendorse);
            	 
            	        if (eply_cnt > 0)
            	        {
            	            fprintf(fp,"�O�渹[%s]:�w�ɵo�L�q�l�O��A�Цܩx��������e�O��CM0901�ɱH�Ȥ�Y�i�C",ipolicy_B);
	                    continue;
	                    
            	        }
            	        else if (strcmp(feedr,"2") != 0)
            	        {
            	            fprintf(fp,"�O�渹[%s]:�Цܧ��{�����q�l�O��-�̷s�O����O�A�l�i�i��ɵo�@�~�C",ipolicy_B);
	                    continue;
	                    
            	        }
            	        
            	        strcpy(sAemail_eply,trim(sAemail_eply));
            	        strcpy(sIroute, trim(sIroute));
            	        
            	        /* 1060328006_C1 �s�W�q�l�O�椽�ΫH�c(�q�ӳ��ϥ�) */
    	                if (strcmp(sIroute,"JB") == 0) strcpy(sIcomp_in , "88");
    	        	        	 	
        	        /* �q�l�O�椣�ݦL�X�ȥ���ơA�ݱN�O���Ƽg�J�q�l�O������ */
        	        $select nvl(max(iserno),0)+1
                           into $iserno
                           from cm_e_policy
                          where ipolicy = $ipolicy_B;

                        sprintf_s(siserno, sizeof siserno, "%02d", iserno);
                        
			/*�O�o���ɦW*/
        	        strcpy(e_nfile,"");
        	        strcat(e_nfile,"P17CAR_");
        	        strcat(e_nfile,trim(ipolicy_B));
        	        strcat(e_nfile,"_");
        	        strcat(e_nfile,trim(yyyy));
        	        strcpy(e_nfile,trim(e_nfile));
        	        
                        /*TWCA���ɦW*/
                        /*
                        sprintf_s(e_nfile, sizeof e_nfile, "%s%s", trim(ipolicy_B), siserno);
        	        */
        	        
        	        /*�P�_�O�_���ǰe�L�O�o����*/
                        $select count(*)
                           into $chk_ftype
                           from cm_e_policy
                          where ipolicy = $ipolicy_B and ftype='2' and iins_cat='C';
        	        
        	        
        	        /*�O�o�q�l�O��*/
        	        
        	        if(chk_ftype > 0 )  /*�j��0���ܦ��ǰe�L�O�o����-->�쬰�q�l(�O�o)�ɵo�q�l(�O�o)*/
                        {
            	            fprintf(fp,"�O�渹[%s]:�Ц�car409���s�q�l���C",ipolicy_B);
	                    continue;
            	        }
            	        else  /*����0���ܥ��ǰe�L�O�o����-->�쬰�ȥ��ɵo�q�l or �쬰�q�l(TWCA)�ɵo�q�l(�O�o)*/
            	        {
            	            $INSERT INTO cm_e_policy(iins_cat,ipolicy,iendorse,iserno,ftype,fspeed,iins_kind_ply,iendorse_ti,
            	                                     fprocess,fdata,ibranch_code,icustomer,npassword,nemai_send,tsms_mobile,
            	                                     nfile,dbgn,dend,fstatus,iapplicant,iassured,ientry,dentry,iupdate,dupdate,
            	                                     nplyidx1,nplyidx2,nplyidx3,nedridx1,nedridx2,nedridx3)
				         VALUES ('C',$ipolicy_B,$iendorse,$siserno,'2',1,'C2',' ',
				                 'A','P',$sIcomp_in,$sIapplicant,$sPasswd,$sAemail_eply,$sTmobile_eply,
				                 $e_nfile,$dbgn_e,$dend_e,100,$sIapplicant,$sPasswd,$userid,CURRENT,'car307',CURRENT,
				                 ' ',' ',' ',' ',' ',' ');	
            	        	
            	        }
            	        /*TWCA�q�l�O��*/
            	        /*
        	        $INSERT INTO cm_e_policy(iins_cat,ipolicy,iendorse,iserno,ibranch_code,icustomer,npassword,nemai_send,tsms_mobile,nfile,dend,fstatus,ientry,dentry,iupdate,dupdate)
				         VALUES ('C',$ipolicy_B,$iendorse,$siserno,$sIcomp_in,$sIapplicant,$sPasswd,$sAemail_eply,$sTmobile_eply,$e_nfile,$dend_e,100,$userid,CURRENT,'car307',CURRENT);
        	        */

		}
		else
	        {
		        /* �t�X���O�X��,�w�L�L�F�~��[�ɵo]���r��  modify by sylvia 103.12.10 (10311110001_C3) */
		        /* if (strncmp(choice,"1",1) == 0) */
			if ((strncmp(choice,"1",1) == 0) && (dprint_yn > 0))
				rc=ca_rpt_policy(ipolicy_B, "�ɵo", ibatch_no, "2", FALSE, 1, " ", "",userid,"0",ProtectData,DBName,"1","","","","0");
			else
				rc=ca_rpt_policy(ipolicy_B, "", ibatch_no, "2", FALSE, 1, " ", "",userid,"0",ProtectData,DBName,"1","","","","0");	
		
			if (rc != M_CM_OK)
			{
	                    printf("�O��C�L����!\n");
	                    strcpy(v_sMsg, cm_get_errmsg(rc));
	                    fprintf(fp, "�O�渹[%s], �O��C�L���� %s ", ipolicy_B, v_sMsg);
	                    continue;
	                }
	                else
	                {
	                    /* �Ĥ@���L�O��~�^�� */
	                    if (dprint_yn == 0)
	                    {
	                        /* �O��C�L��n�^��ñ��� */
	                        sprintf_s(upd_str, sizeof upd_str,"update %s:ply_relation set dpolicy = today , fprint = '1' where ipolicy = '%s'",
	                                 Full_DBName,ipolicy_B);
	                        printf("upd_str=[%s]\n",upd_str);
	                        $PREPARE per_upd_dpolicy FROM $upd_str;
	                        $EXECUTE per_upd_dpolicy;
	
	                        if ((fstatus == 10) || (fstatus == 40))
	                            fstatus = 30;
	                        else if (fstatus == 50)
	                            fstatus = 60;
	
	                        $update cm_pre_receive
	                            set dprint = current,
	                                fstatus = $fstatus,
	                                iupdate = 'CAR327',
	                                dupdate = current
	                          where iins_cat = 'C'
	                            and ipre_rcv = $iestimate
	                            and iins_kind = '2'
	                            and ipolicy1 = $ipolicy_B;
	                    }
	            
	                    if ((strncmp(choice,"1",1) == 0) && (dprint_yn > 0))
	                    {
		          	rc2 = insert_ca_log("car327","P",ipolicy_B," ","�O��ɵo",userid,Msg);
		          	printf("Msg[%s] rc[%d]",Msg,rc2);
				if( rc2 != M_CM_OK)
				{
				    SQLCODE = rc2;
				    goto errexit;
				}
		    	    }
	                }
	        }
	    
                cnt++;
                /* �C50�� commit�@�� add by sylvia 104.01.30 */
                if (cnt > 25)
                {
                    $commit work;
                    sleep(1);
                    $BEGIN WORK;
                    cnt = 0;
                }          
          }
          $CLOSE policyB_cur;
          $FREE  policyB_cur;

          fclose(fp);

          rc=rptftpinsert(userid,"car327",fname);
          if (rc!=0){
              sprintf_s(sErrMsg, sizeof sErrMsg,"%s�g�Jrptftplist���~",fname);
              EWRITE(userid,rc,sErrMsg);
              return rc;
          }

          $commit work;
          rgu_finish_report();

        return M_CM_OK;

errexit:
    printf("--ca327_policyB_print--SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
    $rollback work;
    return SQLCODE;
}
/********************************************************************************/
long ca327_policyB_print_Freeform()
{
	  $char FormFile[N_FILE+1], upd_str[500], upd_str_E[500], iestimate[21];
	  $char ipolicyB[21],iengine[21],comp_DB[3];
	  $char ipolicy_A[21],ipolicy_B[21],iofficer[11];
	  $char payresult[5], paystatus[100], paydate[100], notedate[100];
	  $char date[11],dToday[11],nyy[4],nmm[3],ndd[3];
	  $char stmt[2048],v_sMsg[1024],stmt2[500],stmt3[500],stmt4[50],stmt5[500],v_sMsg2[1024];
	  $char errmsg[512];
	  $int  ibatch_no,sIpolicyB_type,rc,PgLine,dprint_yn,fstatus,rc2;
	  $long ldend,t, mcover_sum;
	  char  filename[201],fname[101],Msg[201];
	  $char sftype_pol[3],sftype_sp[3],dpolicy_ori[11], ipolicy_main[21],icard_main[21];
	  $int  f1040301,f1040101,icount_10,icount_20,icount_RN;
	  int  cnt;
	  $char rba_HG[2],chk_rba_print[2];
	  $int rba_cnt,rba_max;
	  $char feedr[2],siserno[3],iendorse[21],sIroute[21];
	  $char yyyy[5];
	  $int  eply_cnt;
	  $int  iserno;
	  $int  chk_ftype;
	  $int  fsign_status;
	  
	  /* 1070809006_SC3_�ѵs�I�O����A���ƱĹq�l�O�洣�� */
	  $char feply[2],e_nfile[36],sIcomp_in[3],sIapplicant[13],sPasswd[13],sAemail_eply[51],dend_e[11],dbgn_e[11],sTmobile_eply[21];  
	  dprint_yn = 0; /* �O��C�L���A: 0:���C�L;1:�w�C�L */
	  mcover_sum =0;   /* A���`�O�B */
          t = cm_today();
          strcpy(date,cm_edate_str(t));
          strcpy(dToday,cm_from_infdate_100(date));
          cm_split_ymd_100(dToday,nyy,nmm,ndd);


	  $WHENEVER SQLERROR GOTO errexit;
	  $SET LOCK MODE TO WAIT;

	  $BEGIN WORK;
	  
	  strcpy(filename," ");
          strcpy(fname," ");
          sprintf_s(fname, sizeof fname,"car327_policyB_detial[%s].txt",outputf);
          sprintf_s(filename, sizeof filename,"%s/rptftp/%s",sApHome,fname);
          printf("car327_policyB[%s]\n",filename);
          fp=fopen(filename,"w");
          cnt = 0;
          $DECLARE policyB_cur_f CURSOR with hold for
            SELECT ipolicy
              INTO $ipolicyB
              FROM CAR327;
          $OPEN policyB_cur_f;
          
          
          
          if (ProtectData[0] == '1') 
	  strcpy(fhide,"Y");
	  else 
	  strcpy(fhide,"N");
	  
	  /* �g�Jcm_freeform */
	  /*                        ����Ǹ�       �I�O     �M�L�O      �C�L�O  �����O   �Ӹ����� ���C�L�Ƶ� �C�L����O ���ƥ� */
	  $INSERT INTO cm_freeform (kpid,          iins_cat,formid,     fprint, fformal, fhide,   fnote,     fbranch,    fpolicy, fcondition, iprinter , ipgid,    iupdate, tstime , tetime)
          		    VALUES ($skpidFreeForm,'C',     'CARPLY001','0'   , 'F'    , $fhide,     'N'  ,     ' '    ,     ' ',     ' ',        ' '   ,'car327',  $userid, current, current);

	  for(;;)
	  {
	      $FETCH policyB_cur_f;
	      printf("1------ipolicyB[%s]-------\n",ipolicyB);
	      if(SQLCODE == SQLNOTFOUND) break;

              strcpy(siserno,"");
              strcpy(sIroute,"");
              strcpy(yyyy,"");
              fsign_status=0;
              
              strcpy(ipolicyB,trim(ipolicyB));
              printf("2------ipolicyB[%s]-------\n",ipolicyB);
	      strcpy(Full_DBName,get_car_full_db(ipolicyB));
	      /* �M�ץ�P�_�G�s�WH�g��B������H0-H2 modify by larry 103.01.20 (1021122001_C3)
	                     OR (a.iofficer[1,1] = 'H' AND  a.iofficer[2,2] not in ('0','1','2'))*/
	      /* �s�W�M��N*�g��P�_  add by sylvia 103.09.18 (1030630002_C1) */
	      /* �t�X����Ʈw����(�p�򶩥�22��00), �s�W�Hicard_main(���pA��d��)�dA���� add by sylvia 106.02.08 */
	      strcpy(ipolicy_main," ");
	      sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy,a.ibatch_no,a.icomp_in,b.iengine,a.dply_end,  "
	                          "a.iofficer, case when a.dpolicy is null then 0 else 1 end,   "
	                          "a.itmp_policy, (select fstatus from cm_pre_receive  "
	                          "where iins_cat = 'C' and iins_kind = '2' and ipre_rcv = a.itmp_policy),  "
	                          "dpolicy,nvl((select ipolicy from card where icard = a.icard_main),' '),a.icard_main,  "
	                          "a.feply,b.iapplicant,b.iassured,a.aemail_eply,a.dply_end,a.tmobile_eply,b.iroute,year(nvl(a.dpolicy,today)),a.dply_begin,a.fsign_status   "
	                    " FROM %s:ply_relation a ,%s:policy b  "
	                    "WHERE a.ipolicy = b.ipolicy  "
	                    "  AND a.ipolicy = '%s'  "
	                    "  AND (a.iofficer[1,1] = 'W' or a.iofficer in  "
	                          "(select unique iofficer_ori from ca_promote_officer  "
	                          "  where iofficer_ori[1,1] in ('H','N')))",
                         Full_DBName,Full_DBName,ipolicyB);
              $PREPARE get_B FROM $stmt;
	      $DECLARE get_Bd_f CURSOR  FOR get_B;
	      $OPEN get_Bd_f;
	      strcpy(dpolicy_ori,"");
	      $FETCH get_Bd_f INTO $ipolicy_B,$ibatch_no,$comp_DB,$iengine,$ldend,$iofficer,
	                         $dprint_yn,$iestimate,$fstatus,$dpolicy_ori,$ipolicy_main,$icard_main,
	                         $feply,$sIapplicant,$sPasswd,$sAemail_eply,$dend_e,$sTmobile_eply,$sIroute,$yyyy,$dbgn_e,$fsign_status;
	      if(SQLCODE == SQLNOTFOUND)
	      {
	         printf("---- SQLNOTFOUND ---- \n");
	         fprintf(fp,"�O�渹�G%s\t�D�M�ץ�O��\n",ipolicyB);
	         sprintf_s(errmsg, sizeof errmsg,"�O�渹�G%s�D�M�ץ�O��",ipolicyB);
	         strcpy(errmsg, trim(errmsg));
	         /* �g�Jcm_freeform_dtl(�ˮ֦��~) */
	    	 $INSERT INTO cm_freeform_dtl (kpid,          iins_cat, ipolicy, iendorse, icard, feply, fversion, fstatus, iofficer,      ileader,   iserl, nnote,              iprint,  dprint)
	    	         	           VALUES ($skpidFreeForm,'C', $ipolicyB,' ',      ' ',   $feply,  ' ',  199,     ' ',           ' ',       ' ', $errmsg, $userid ,current);
	      	 $CLOSE get_Bd_f;
	         $FREE  get_Bd_f;
	         continue;
	      }
	      $CLOSE get_Bd_f;
	      $FREE  get_Bd_f;

	      strcpy(feply,trim(feply));
	      strcpy(iengine,trim(iengine));
	      printf("-----iengine[%s],dply_end[%d]-----\n",iengine,ldend);
	      /** B�檺�������Ӭd��A��(�O�渹) **/
	      /* �s�W�M��N*�g��P�_ add by sylvia 103.09.18 (1030630002_C1) */
	      /* AND NOT (a.iofficer[1,1] = 'H' AND a.iofficer[2,2] not in ('0','1','2')) */
	      /* �W�[AB�����p�d�����P�_ (1070712005_SC1) */
	      
              sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy,  "
                            "nvl((select sum(mdamage_cover) from %s:ply_ins_type c  "
                                " where c.ipolicy = a.ipolicy),0)  "
	                    " FROM %s:ply_relation a , %s:policy b  "
	                    "WHERE a.ipolicy = b.ipolicy  "
	                    "  AND a.fcard_class = '2'  "
	                    "  AND a.iresource <> 'E'  "
	                    "  AND b.iengine = '%s'  "
	                    "  AND a.dply_end >= %d AND a.dply_end <= %d  "
	                    "  AND a.icard = '%s'  "
	                    "  AND a.fedr_class <> '1'  "
	                    "  AND nvl(a.ibig_comp,' ') <> ' '  "
	                    "  AND a.iofficer[1,1] <> 'W'  "
	                    "  AND a.iofficer not in  "
	                         "(select unique iofficer_ori from ca_promote_officer  "
	                         "  where iofficer_ori[1,1] in ('H','N')) ",
	                       Full_DBName,Full_DBName, Full_DBName, iengine, ldend-30, ldend+30, icard_main);
	      $PREPARE get_A FROM $stmt;
	      $DECLARE get_Ad_f CURSOR FOR get_A;
	      $OPEN get_Ad_f;
	      $FETCH get_Ad_f INTO $ipolicy_A, $mcover_sum;
	      if(SQLCODE == SQLNOTFOUND)
	      {
	        /* ��Hipolicy_main(���pA�渹)�d add by sylvia 106.02.08 */
	        /* A�洫�d���i��ɭPipolicy_main���ťաA�P�_�ɼW�[trim (1100802014_SC1) */
	        if (strlen(trim(ipolicy_main)) > 10)
	        {
	            strcpy(ipolicy_A,ipolicy_main);
	            mcover_sum = 0;
	            strcpy(Full_DB_A,get_car_full_db(ipolicy_A));
            
	            sprintf_s(stmt2, sizeof stmt2,"select sum(mdamage_cover) from %s:ply_ins_type  "
	                           "where ipolicy = '%s'",Full_DB_A,ipolicy_main);
	            $PREPARE get_A1 FROM $stmt2;
	            $DECLARE get_Ad1_f CURSOR FOR get_A1;
	            $OPEN get_Ad1_f;
	            $FETCH get_Ad1_f INTO  $mcover_sum;
	            $CLOSE get_Ad1_f;
	            $FREE  get_Ad1_f;
	            
	            if (mcover_sum == 0)
	            {
	            	fprintf(fp,"B��G%s\t�d�LA��(�O�渹)\n",ipolicy_B);
	            	sprintf_s(errmsg, sizeof errmsg,"B��G%s �d�LA��(�O�渹)",ipolicy_B);
	         	strcpy(errmsg, trim(errmsg));
	            	/* �g�Jcm_freeform_dtl(�ˮ֦��~) */
	    	 	$INSERT INTO cm_freeform_dtl (kpid,          iins_cat, ipolicy, iendorse, icard, feply, fversion, fstatus, iofficer,      ileader,   iserl, nnote,              iprint,  dprint)
	    	        	 	          VALUES ($skpidFreeForm,'C', $ipolicy_B,' ',      ' ',   $feply,  ' ',  199,    ' ',            ' ',       ' ', $errmsg, $userid ,current);
    	                $CLOSE get_Ad_f;
    	                $FREE  get_Ad_f;
    	                continue;
	            }
	        }
	        else
	        {
	            fprintf(fp,"B��G%s\t�d�LA��(�O�渹)\n",ipolicy_B);
	            sprintf_s(errmsg, sizeof errmsg,"B��G%s �d�LA��(�O�渹)",ipolicy_B);
	            strcpy(errmsg, trim(errmsg));
	            /* �g�Jcm_freeform_dtl(�ˮ֦��~) */
		    $INSERT INTO cm_freeform_dtl (kpid,          iins_cat, ipolicy, iendorse, icard, feply, fversion, fstatus, iofficer,      ileader,   iserl, nnote,              iprint,  dprint)
	    	        	 	      VALUES ($skpidFreeForm,'C', $ipolicy_B,' ',      ' ',   $feply,  ' ',  199,    ' ',           ' ',       ' ', $errmsg, $userid ,current);
	            $CLOSE get_Ad_f;
	            $FREE  get_Ad_f;
	            continue;
	        }
	      }
	      $CLOSE get_Ad_f;
	      $FREE  get_Ad_f;

	      printf("-----ipolicy_A[%s]-----\n",ipolicy_A);

	      /* �t�X���O�X��104/01/01�W�u, car330�u�t�d���O�渹,���^��ñ���,�]�����ެO�_�w���O... modify by sylvia 103.12.16 (1031111001_C3) */
              $select first 1 case when today >= '03/01/2015' then 1 else 0 end,
                              case when today >= '01/01/2015' then 1 else 0 end
                 into $f1040301,$f1040101
                 from policy_302;

	      /* �t�X���O�X��104/01/01�W�u,B�楼���O���i�C�L add by sylvia 103.12.10 (10311110001_C3) */
	      strcpy(sftype_pol," "); strcpy(sftype_sp," ");
	      $select ftype_pol,ftype_sp
	         into $sftype_pol, $sftype_sp
	         from cm_pre_receive
	        where iins_cat = 'C'
	          and ipre_rcv = $iestimate and iins_kind = '2';

	       /* �@�리�O�X���(sftype_sp=PA)�B�e�u���^��ftype_sp���O��(sftype_sp=PA)��
	          �W�L103/01/01�L�檺��O��(RN)�����ˮ֬O�_�w���O   */
	       /* ********************************************************************* */
	       /* �ˮ֬O�_��104/01-02�������O�� */

	       /* RN�w�q�קאּ--�L����O��,�䤺�e�t(103.12.25���e�{�ɷ|�Mĳ)(103.12.27 modify by sylvia):
	            (1)ñ��� < 104/01/01
                (2)�ͮĤ� < 104/01/01�A�B��104/02/28�e�����X��鵲�C
                (3)�ͮĤ鬰 104/01/01~104/02/28 ���¨��A�B��104/02/28�e�����X��鵲�C
                    �¨��w�q�G�]�ͮĦ~�� - �o�Ӥ�~��^ >   1 �Ӥ�   (�u�ݤ��)
           ************************************************************************* */

	       $select count(*) into $icount_RN
                  from policy_302
                 where dply_begin <= '02/28/2015'
                   and iofficer[1,1] in ('W','N','H')
                   and (iestimate_ori = $iestimate or iestimate_sug = $iestimate);

               if ((f1040301 == 0) && (icount_RN > 0))
               {
                   strcpy(sftype_pol,"NA");
	           strcpy(sftype_sp,"RN");
               }


               if ((strcmp(sftype_sp,"PA") == 0 )||(strlen(trim(sftype_sp)) == 0))
	       {
                   if (fstatus < 50)
                   {
      	               printf("----ipolicy_B[%s], fstatus[%d]----\n", ipolicy_B, fstatus);
      	               /** �����O�O�椣�i�C�L **/
      	               strcpy(ipolicy_B, trim(ipolicy_B));
      	               fprintf(fp,"B��G%s �|�����O���i�C�L�O��!\n",ipolicy_B);
      	               sprintf_s(errmsg, sizeof errmsg,"B��G%s �|�����O���i�C�L�O��!",ipolicy_B);
	               strcpy(errmsg, trim(errmsg));
      	               /* �g�Jcm_freeform_dtl(�ˮ֦��~) */
      	               $INSERT INTO cm_freeform_dtl (kpid,          iins_cat, ipolicy, iendorse, icard, feply, fversion, fstatus, iofficer,      ileader,   iserl, nnote,              iprint,  dprint)
	    	        	 	         VALUES ($skpidFreeForm,'C', $ipolicy_B,' ',      ' ',   $feply, ' ',  199,    ' ',            ' ',       ' ',$errmsg, $userid ,current);
   	      	       printf("�����O�O�椣�i�C�L!\n");
   	               continue;

      	           }
	       }


	       /* �t�X���O�X��104/01/01�W�u,A��h�O���i�C�L add by sylvia 103.12.10 (10311110001_C3) */
	       if (mcover_sum <=0)
	       {
	       	   fprintf(fp,"B��G%s A��G%s\t�w�h�O���i�C�L\n",ipolicy_B,ipolicy_A);
	       	   sprintf_s(errmsg, sizeof errmsg,"B��G%s A��G%s �w�h�O���i�C�L",ipolicy_B,ipolicy_A);
	           strcpy(errmsg, trim(errmsg));
	       	   /* �g�Jcm_freeform_dtl(�ˮ֦��~) */
	       	   $INSERT INTO cm_freeform_dtl (kpid,          iins_cat, ipolicy, iendorse, icard, feply, fversion, fstatus, iofficer,      ileader,   iserl, nnote,              iprint,  dprint)
	    	        	 	     VALUES ($skpidFreeForm,'C', $ipolicy_B,' ',      ' ',   $feply,  ' ',  199,    ' ',           ' ',        ' ',$errmsg, $userid ,current);
	           printf("A��h�O���i�C�L!\n");
	           continue;
	       }

	       /* ���F�O��϶��i�H���ˮ�A��O�_�w���O�~....��l���n�ŦXA��w���O�B���h�O... modify by sylvia 103.12.16 */
	       /*if ( (strncmp(iofficer+(7-1),"FW",2)==0) || (strncmp(opt,"2",1) == 0) ||
	            (strncmp(iofficer+(7-1),"C15",3)==0)|| (strncmp(iofficer+(7-1),"C17",3)==0)) */
	       if (strncmp(opt,"2",1) == 0)
	       {
	       }
	       else{		
	           ao_chk_charge(comp_DB, '1', ipolicy_A, " ", " ",
	                         payresult, paystatus, paydate, notedate);
	           printf("----ipolicy_A[%s], payresult[%s]----\n", ipolicy_A, payresult);
	           /** �����O�O�椣�i�C�L **/
	           /* 103.12.22 �ɤ��q�����ˮ�A��O�_�w���O mark by sylvia 103.12.22 */
	           
	       }
	      
	       
	        
                /*�ˮ֬O�_�f�ֳq�L�Afsign_status>=30 ---------------------------------*/
                /*1091021005_SC5_�s�W�A�Ȥ��ߩ�����*/
                if  (fsign_status < 30 && dprint_yn == 0)
                {
                	fprintf(fp,"�O�渹[%s]:���i�L��A�]���`�����q�|���f�֩��",ipolicy_B);
                	sprintf_s(errmsg, sizeof errmsg,"�O�渹[%s]:���i�L��A�]���`�����q�|���f�֩��",ipolicy_B);
	                strcpy(errmsg, trim(errmsg));
                	/* �g�Jcm_freeform_dtl(�ˮ֦��~) */
	       	   	$INSERT INTO cm_freeform_dtl (kpid,          iins_cat, ipolicy, iendorse, icard, feply, fversion, fstatus, iofficer,      ileader,   iserl, nnote,              iprint,  dprint)
	    	        	 	   	  VALUES ($skpidFreeForm,'C', $ipolicy_B,' ',      ' ',   $feply,  ' ', 199,    ' ',            ' ',       ' ', $errmsg, $userid ,current);
	                continue; 
                }
        
                /*--------------------------------------------------------------------*/
	        
	        /*1090521001_SC1_�}��M�ץ�i���q�l�O��EMAIL�b��*/
	        /*** �D�q�l�O��ݥ���אּ�q�l�O���A�ɱH�e�q�l�O�� ***/
                if (strcmp(feply,"1",1) != 0 && strcmp(chk_eply,"1",1) == 0)
            	{
            		fprintf(fp,"�O�渹[%s]:�Цܧ��{�����q�l�O����O�A�l�i�i��ɵo�@�~",ipolicy_B);
            		sprintf_s(errmsg, sizeof errmsg,"�O�渹[%s]:�Цܧ��{�����q�l�O����O�A�l�i�i��ɵo�@�~",ipolicy_B);
	                strcpy(errmsg, trim(errmsg));
            		/* �g�Jcm_freeform_dtl(�ˮ֦��~) */
	       	   	$INSERT INTO cm_freeform_dtl (kpid,          iins_cat, ipolicy, iendorse, icard, feply, fversion, fstatus, iofficer,      ileader,   iserl, nnote,              iprint,  dprint)
	    	        	 	   	  VALUES ($skpidFreeForm,'C', $ipolicy_B,' ',      ' ',   $feply,   ' ', 199,    ' ',            ' ',       ' ', $errmsg, $userid ,current);
	                continue; 
            	}
            	
	        printf("---------�ɵo[%s]-------------\n",choice);
	        
		/* 1070809006_SC3_�ѵs�I�O����A���ƱĹq�l�O�洣�� */
		/* 1080417001_SC3_�s�W�q�l�O��H²�T�覡�o�e */
		if(strcmp(feply,"1",1) == 0 && dprint_yn == 0)
		{
			/* �q�l�O�椣�ݦL�X�ȥ���ơA�ݱN�O���Ƽg�J�q�l�O������ */
			strcpy(sIcomp_in,comp_DB);
			
			/*�O�o���ɦW*/
        	        strcpy(e_nfile,"");
        	        strcat(e_nfile,"P17CAR_");
        	        strcat(e_nfile,trim(ipolicy_B));
        	        strcat(e_nfile,"_");
        	        strcat(e_nfile,trim(yyyy));
        	        strcpy(e_nfile,trim(e_nfile));
			
			
                        
        	        /*�O�o�q�l�O��*/
            	        $INSERT INTO cm_e_policy(iins_cat,ipolicy,iendorse,iserno,ftype,fspeed,iins_kind_ply,iendorse_ti,
            	                             fprocess,fdata,ibranch_code,icustomer,npassword,nemai_send,tsms_mobile,
            	                             nfile,dbgn,dend,fstatus,iapplicant,iassured,ientry,dentry,iupdate,dupdate,
            	                             nplyidx1,nplyidx2,nplyidx3,nedridx1,nedridx2,nedridx3)
				     VALUES ('C',$ipolicy_B,' ','01','2',1,'C2',' ',
				             'A','P',$sIcomp_in,$sIapplicant,$sPasswd,$sAemail_eply,$sTmobile_eply,
				             $e_nfile,$dbgn_e,$dend_e,100,$sIapplicant,$sPasswd,$userid,CURRENT,$userid,CURRENT,
				             ' ',' ',' ',' ',' ',' ');
			
			  
			sprintf_s(upd_str_E, sizeof upd_str_E,"update %s:ply_relation set dpolicy = today , fprint = '1' where ipolicy = '%s'",
	                           Full_DBName,ipolicy_B);
                        printf("upd_str_E=[%s]\n",upd_str_E);
                        $PREPARE per_upd_dpolicy_E FROM $upd_str_E;
                        $EXECUTE per_upd_dpolicy_E;

                        if ((fstatus == 10) || (fstatus == 40))
                            fstatus = 30;
                        else if (fstatus == 50)
                            fstatus = 60;

                        $update cm_pre_receive
                            set dprint = current,
                                fstatus = $fstatus,
                                iupdate = 'CAR327',
                                dupdate = current
                          where iins_cat = 'C'
                            and ipre_rcv = $iestimate
                            and iins_kind = '2'
                            and ipolicy1 = $ipolicy_B;
                            
                        /* �g�Jcm_freeform_dtl */
	           
		    	$INSERT INTO cm_freeform_dtl (kpid,          iins_cat, ipolicy, iendorse, icard, feply, fversion, fstatus, iofficer,      ileader,   iserl, nnote,              iprint,  dprint)
		    	         	         VALUES ($skpidFreeForm,'C', $ipolicy_B,' ',      ' ',   '1',   ' ', 100,    $iofficer,          ' ',     ' ', '�wñ��A���ݦC�L', $userid ,current);
                        /*
			ca_freeform_policy(ipolicy�O�渹,
			                    �O�_�O�ɵo(�ť�:�D�ɵo),
			                    ibatch_no�j�O��妸���X,
			                    ikind�O�_�L�X�u�f���B(2:���L),
			                    �O�_�L�W�U(0:�n�C�L),
			                    urerid(���ڥ�),
			                    �O�_�C�L���r�W�U(1:�n�C�L),
			                    �Ӹ�B�n(ProtectData),
			                    DbName,
			                    sProjPlyType(1:�M��B��, 0:�M��A��Τ@��� E:�q�l�O��),
			                    skpidFreeForm,
			                    iserl�y����,
			                    �O�_�O�q�l�O��(0:�ȥ��A1:�q�l),
			                    �O�_�L����(N:���L)),
			                    ����,
			                    �ӷ��{��*/
			           
			/*rc=ca_freeform_policy(ipolicy_B, "", ibatch_no, "2", 0, userid, "1",ProtectData , DBName, "1" ,skpidFreeForm, &iserl, "1", "N","CARPLY001","car327","N"," ");*/
			            
		}
		else if(strcmp(feply,"1",1) == 0 && dprint_yn == 1 && strcmp(chk_eply,"1",1) == 0)
		{
			strcpy( iendorse, "");
			strcpy( feedr, "");
			strcpy(sIcomp_in,comp_DB);
			strcpy(Full_DB_B,get_car_full_db(ipolicy_B));
			
                        sprintf_s(stmt3, sizeof stmt3, " SELECT first 1 iendorse,feedr "
                                        "   FROM %s:edr_relation "
                                        "  WHERE ipolicy = '%s'"
                                        "    AND iendorse not like '%%CVP%%'"
                                        "  ORDER BY dcreate DESC; ", Full_DB_B, ipolicy_B );
                        printf("[%s]\n", stmt3);
                        $PREPARE prep1 FROM $stmt3;
                        $EXECUTE prep1 INTO $iendorse,$feedr;
                        
                        /*** ��w���q�l�O��A�����z�Le�O���ɵo�q�l�O�� ***/
		        strcpy(iendorse,trim(iendorse));
	                if(strcmp(iendorse,"")==0)
			    sprintf_s(stmt4, sizeof stmt4," ");
		        else
			    sprintf_s(stmt4, sizeof stmt4,"AND iendorse = '%s'",iendorse);

		        sprintf_s(stmt5, sizeof stmt5, " select count(*)       "
                                        "   from cm_e_policy    "
                                        "  WHERE ipolicy = '%s' "
                                        "    %s ;" , ipolicy_B,stmt4 );
				
		        printf("stmt5[%s]\n",stmt5);
				
		        $PREPARE prep_cnt FROM $stmt5;
        	        $EXECUTE prep_cnt INTO $eply_cnt;
            	    
            	        printf("eply_cnt[%d]ipolicy_B[%s]iendorse[%s]\n",eply_cnt,ipolicy_B,iendorse);
            	 
            	        if (eply_cnt > 0)
            	        {
            	            fprintf(fp,"�O�渹[%s]:�w�ɵo�L�q�l�O��A�Цܩx��������e�O��CM0901�ɱH�Ȥ�Y�i�C",ipolicy_B);
            	            sprintf_s(errmsg, sizeof errmsg,"�O�渹[%s]:�w�ɵo�L�q�l�O��A�Цܩx��������e�O��CM0901�ɱH�Ȥ�Y�i�C",ipolicy_B);
	                    strcpy(errmsg, trim(errmsg));
            	            /* �g�Jcm_freeform_dtl(�ˮ֦��~) */
	       	   	    $INSERT INTO cm_freeform_dtl (kpid,          iins_cat, ipolicy, iendorse, icard, feply, fversion, fstatus, iofficer,      ileader,   iserl, nnote,              iprint,  dprint)
	    	        	 	   	      VALUES ($skpidFreeForm,'C', $ipolicy_B,' ',      ' ',   $feply,   ' ', 199,    ' ',           ' ',       ' ',   $errmsg, $userid ,current);
	                    continue;
	                    
            	        }
            	        else if (strcmp(feedr,"2") != 0)
            	        {
            	            fprintf(fp,"�O�渹[%s]:�Цܧ��{�����q�l�O��-�̷s�O����O�A�l�i�i��ɵo�@�~�C",ipolicy_B);
            	            sprintf_s(errmsg, sizeof errmsg,"�O�渹[%s]:�Цܧ��{�����q�l�O��-�̷s�O����O�A�l�i�i��ɵo�@�~�C",ipolicy_B);
	                    strcpy(errmsg, trim(errmsg));
            	            /* �g�Jcm_freeform_dtl(�ˮ֦��~) */
	       	   	    $INSERT INTO cm_freeform_dtl (kpid,          iins_cat, ipolicy, iendorse, icard, feply, fversion, fstatus, iofficer,      ileader,   iserl, nnote,              iprint,  dprint)
	    	        	 	   	      VALUES ($skpidFreeForm,'C', $ipolicy_B,' ',      ' ',   $feply,   ' ', 199,    ' ',            ' ',       ' ', $errmsg, $userid ,current);
	                    continue;
	                    
            	        }
            	        
            	        strcpy(sAemail_eply,trim(sAemail_eply));
            	        strcpy(sIroute, trim(sIroute));
            	        
            	        /* 1060328006_C1 �s�W�q�l�O�椽�ΫH�c(�q�ӳ��ϥ�) */
    	                if (strcmp(sIroute,"JB") == 0) strcpy(sIcomp_in , "88");
    	        	        	 	
        	        /* �q�l�O�椣�ݦL�X�ȥ���ơA�ݱN�O���Ƽg�J�q�l�O������ */
        	        $select nvl(max(iserno),0)+1
                           into $iserno
                           from cm_e_policy
                          where ipolicy = $ipolicy_B;

                        sprintf_s(siserno, sizeof siserno, "%02d", iserno);
                        
			/*�O�o���ɦW*/
        	        strcpy(e_nfile,"");
        	        strcat(e_nfile,"P17CAR_");
        	        strcat(e_nfile,trim(ipolicy_B));
        	        strcat(e_nfile,"_");
        	        strcat(e_nfile,trim(yyyy));
        	        strcpy(e_nfile,trim(e_nfile));
        	        
                        
        	        
        	        /*�P�_�O�_���ǰe�L�O�o����*/
                        $select count(*)
                           into $chk_ftype
                           from cm_e_policy
                          where ipolicy = $ipolicy_B and ftype='2' and iins_cat='C';
        	        
        	        
        	        /*�O�o�q�l�O��*/
        	        
        	        if(chk_ftype > 0 )  /*�j��0���ܦ��ǰe�L�O�o����-->�쬰�q�l(�O�o)�ɵo�q�l(�O�o)*/
                        {
            	            fprintf(fp,"�O�渹[%s]:�Ц�car409���s�q�l���C",ipolicy_B);
            	            sprintf_s(errmsg, sizeof errmsg,"�O�渹[%s]:�Ц�car409���s�q�l���C",ipolicy_B);
	                    strcpy(errmsg, trim(errmsg));
            	            /* �g�Jcm_freeform_dtl(�ˮ֦��~) */
	       	   	    $INSERT INTO cm_freeform_dtl (kpid,          iins_cat, ipolicy, iendorse, icard, feply, fversion, fstatus, iofficer,      ileader,   iserl, nnote,              iprint,  dprint)
	    	        	 	   	      VALUES ($skpidFreeForm,'C', $ipolicy_B,' ',      ' ',   $feply,   ' ', 199,    ' ',           ' ',       ' ',$errmsg , $userid ,current);
	                    continue;
            	        }
            	        else  /*����0���ܥ��ǰe�L�O�o����-->�쬰�ȥ��ɵo�q�l or �쬰�q�l(TWCA)�ɵo�q�l(�O�o)*/
            	        {
            	            $INSERT INTO cm_e_policy(iins_cat,ipolicy,iendorse,iserno,ftype,fspeed,iins_kind_ply,iendorse_ti,
            	                                     fprocess,fdata,ibranch_code,icustomer,npassword,nemai_send,tsms_mobile,
            	                                     nfile,dbgn,dend,fstatus,iapplicant,iassured,ientry,dentry,iupdate,dupdate,
            	                                     nplyidx1,nplyidx2,nplyidx3,nedridx1,nedridx2,nedridx3)
				         VALUES ('C',$ipolicy_B,$iendorse,$siserno,'2',1,'C2',' ',
				                 'A','P',$sIcomp_in,$sIapplicant,$sPasswd,$sAemail_eply,$sTmobile_eply,
				                 $e_nfile,$dbgn_e,$dend_e,100,$sIapplicant,$sPasswd,$userid,CURRENT,'car307',CURRENT,
				                 ' ',' ',' ',' ',' ',' ');	
            	        	
            	        }
            	        
            	        /* �g�Jcm_freeform_dtl */
           
	    	    	$INSERT INTO cm_freeform_dtl (kpid,          iins_cat, ipolicy, iendorse, icard, feply, fversion, fstatus, iofficer,      ileader,   iserl, nnote,              iprint,  dprint)
	    	         	                 VALUES ($skpidFreeForm,'C', $ipolicy_B,' ',      ' ',   '1',  ' ',  100,    $iofficer,          ' ',     ' ', '�wñ��A���ݦC�L', $userid ,current);
                        /*
			ca_freeform_policy(ipolicy�O�渹,
			                    �O�_�O�ɵo(�ť�:�D�ɵo),
			                    ibatch_no�j�O��妸���X,
			                    ikind�O�_�L�X�u�f���B(2:���L),
			                    �O�_�L�W�U(0:�n�C�L),
			                    urerid(���ڥ�),
			                    �O�_�C�L���r�W�U(1:�n�C�L),
			                    �Ӹ�B�n(ProtectData),
			                    DbName,
			                    sProjPlyType(1:�M��B��, 0:�M��A��Τ@��� E:�q�l�O��),
			                    skpidFreeForm,
			                    iserl�y����,
			                    �O�_�O�q�l�O��(0:�ȥ��A1:�q�l),
			                    �O�_�L����(N:���L)),
			                    ����,
			                    �ӷ��{��*/
			           
		        /*rc=ca_freeform_policy(ipolicy_B, "", ibatch_no, "2", 0, userid, "1",ProtectData , DBName, "1" ,skpidFreeForm, &iserl, "1", "N","CARPLY001","car327","N"," ");*/
            	        

		}
		else
	        {
	        	/* �g�Jcm_freeform_dtl */
	           
	    	    	$INSERT INTO cm_freeform_dtl (kpid,          iins_cat, ipolicy, iendorse, icard, feply, fversion, fstatus, iofficer,      ileader,   iserl, nnote,              iprint,  dprint)
	    	         	                 VALUES ($skpidFreeForm,'C', $ipolicy_B,' ',      ' ',   '0',   ' ', 100,    $iofficer,          ' ',     ' ', '�wñ��A���ݦC�L', $userid ,current);
		        /* �t�X���O�X��,�w�L�L�F�~��[�ɵo]���r��  modify by sylvia 103.12.10 (10311110001_C3) */
		        /* if (strncmp(choice,"1",1) == 0) */
			if ((strncmp(choice,"1",1) == 0) && (dprint_yn > 0))
			{
				/*rc=ca_freeform_policy(ipolicy_B, "�ɵo", ibatch_no, "2", 0, userid, "1",ProtectData , DBName, "1" ,skpidFreeForm, &iserl, "0", "N","CARPLY001","car327","N"," ");*/
				rc=ca_freeform_policy(ipolicy_B, "�ɵo", "2", "0", userid, "1", ProtectData, "1" ,skpidFreeForm, &iserl, "0", "N", "CARPLY001", "car327", "N", " ", " ", " ", " ", v_sMsg2);
			}
			else
			{
				/*rc=ca_freeform_policy(ipolicy_B, "", ibatch_no, "2", 0, userid, "1",ProtectData , DBName, "1" ,skpidFreeForm, &iserl, "0", "N","CARPLY001","car327","N"," ");*/
				rc=ca_freeform_policy(ipolicy_B, "", "2", "0", userid, "1", ProtectData, "1" ,skpidFreeForm, &iserl, "0", "N", "CARPLY001", "car327", "N", " ", " ", " ", " ", v_sMsg2);
			}
			if (rc != M_CM_OK)
			{
	                    fprintf(fp, "�O�渹[%s], �O��C�L���� %s ", ipolicy_B, v_sMsg);
	                    printf("Freeform�O��C�L����!\n");
	                    strcpy(v_sMsg, cm_get_errmsg(rc));
	                    printf("v_Msg = [%s]",v_sMsg);
	                    
	                    /*�Y�L����~�^��ca_freeform_dtl(199)*/
	                    $UPDATE cm_freeform_dtl
	                        SET fstatus = 199,
	                            nnote = "Freeform�O��C�L����!"
	                      WHERE kpid = $skpidFreeForm
	                        AND ipolicy = $ipolicy_B;    	                       
	                    continue;
	                }
	                else
	                {
	                    /* �Ĥ@���L�O��~�^�� */
	                    if (dprint_yn == 0)
	                    {
	                        /* �O��C�L��n�^��ñ��� */
	                        sprintf_s(upd_str, sizeof upd_str,"update %s:ply_relation set dpolicy = today , fprint = '1' where ipolicy = '%s'",
	                                 Full_DBName,ipolicy_B);
	                        printf("upd_str=[%s]\n",upd_str);
	                        $PREPARE per_upd_dpolicy FROM $upd_str;
	                        $EXECUTE per_upd_dpolicy;
	
	                        if ((fstatus == 10) || (fstatus == 40))
	                            fstatus = 30;
	                        else if (fstatus == 50)
	                            fstatus = 60;
	
	                        $update cm_pre_receive
	                            set dprint = current,
	                                fstatus = $fstatus,
	                                iupdate = 'CAR327',
	                                dupdate = current
	                          where iins_cat = 'C'
	                            and ipre_rcv = $iestimate
	                            and iins_kind = '2'
	                            and ipolicy1 = $ipolicy_B;
	                    }
	            
	                    if ((strncmp(choice,"1",1) == 0) && (dprint_yn > 0))
	                    {
	                    	
		          	rc2 = insert_ca_log("car327","P",ipolicy_B," ","�O��ɵoFreeform",userid,Msg);
		          	printf("Msg[%s] rc[%d]",Msg,rc2);
				if( rc2 != M_CM_OK)
				{
				    SQLCODE = rc2;
				    goto errexit;
				}
		    	    }
	                }
	                $UPDATE cm_freeform
		            SET tetime = current
		          WHERE kpid = $skpidFreeForm AND iins_cat='C';
	        }
	    
                cnt++;
                /* �C50�� commit�@�� add by sylvia 104.01.30 */
                if (cnt > 25)
                {
                    $commit work;
                    sleep(1);
                    $BEGIN WORK;
                    cnt = 0;
                }          
          }
          $CLOSE policyB_cur_f;
          $FREE  policyB_cur_f;
          
          fclose(fp);
	  
          rc=rptftpinsert(userid,"car327",fname);
          if (rc!=0){
              sprintf_s(sErrMsg, sizeof sErrMsg,"%s�g�Jrptftplist���~",fname);
              EWRITE(userid,rc,sErrMsg);
              return rc;
          }
          
	  $DELETE FROM gb_schedulelog 
		  WHERE kpid = $outputf;
	  
          $commit work;
          

        return M_CM_OK;

errexit:
    printf("--ca327_policyB_print_Freeform--SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
    $rollback work;
    return SQLCODE;
}
/********************************************************************************/
long ca327_read_data1()
{
	$char stmt[512];
	char  msgbuf[2048];
        int return_code;

	printf("BEGIN TO READ DATA1\n");
	$WHENEVER SQLERROR GOTO errexit;
	
        return_code = getApHome(sApHome);
        if (return_code < 0) 
        {
	    strcpy(msgbuf,"read Config file error!!-->getApHome\n");
	    return return_code;
        }

	printf("---iipolicy[%s]---\n",iipolicy);
	strcpy(Full_DBName,get_car_full_db(iipolicy));
	sprintf_s(stmt, sizeof stmt,"INSERT INTO CAR327  "
	             "SELECT ipolicy FROM %s:ply_relation  "
	             " WHERE ipolicy between ? and ? ",Full_DBName);
	$PREPARE policy_cur FROM $stmt;
	$EXECUTE policy_cur USING $iipolicy,$iipolicy1;

	return M_CM_OK;

errexit:
    printf("--ca327_read_data1--SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/********************************************************************************/
long ca327_read_data()
{
    char   *bp,msgbuf[2048];
    int    rc,j,k,m,n,i,flen,return_code;
    $int   iChkDays,icount_row;
    $char  sBaseDate[11],filename[200];

    printf("BEGIN TO READ DATA\n");

    $WHENEVER SQLERROR GOTO errexit;

    return_code = getApHome(sApHome);
    if (return_code < 0) 
    {
	strcpy(msgbuf,"read Config file error!!-->getApHome\n");
	return return_code;
    }

    strcpy(sfile, trim(sfile));
    sprintf_s(filename, sizeof filename,"%s/dat/car/%s",sApHome,sfile);
    flen=1024;
    if ((fp=fopen(filename,"r"))==NULL) 
    {
       sprintf_s(msgbuf, sizeof msgbuf,"%s �ɮ׶}�ҥ���",filename);
       EWRITE(userid,FALSE,msgbuf);
       return FALSE;
    }
    if ((bp=malloc(flen))==NULL) 
    {
       sprintf_s(msgbuf, sizeof msgbuf,"System malloc failed !");
       EWRITE(userid,FALSE,msgbuf);
       return FALSE;
    }
    
    icount_row=0;
    for (i=0;(feof(fp)==0);i++)
    {
        memset(bp,0x00,flen);
	fgets(bp,flen,fp);

	if (bp[0]==0x00)	break;
	if (strlen(trim(bp))<10)	break;

	for(j=0;j<1024;j++)
	    sdata[j][0]='\0';

	k=m=n=0;

	for (j=0;j<flen;j++)
	{
	    if (bp[j]=='\0' || bp[j]=='\n' || bp[j]==' ')
	    {
                if (bp[j]=='\0' || bp[j]=='\n' )
                {
	            strncpy(sdata[k],bp+m,j-1);
	            sdata[k][j-1]='\0';
	        }
	        else
	        {
	            strncpy(sdata[k],bp+m,j-m);
	            sdata[k][j-m]='\0';
	        }
		m=j+1;
		k++;
	    }
	    if (bp[j]=='\n')	break;
	    if (k > 6) break;
	}
	printf("sdata[%s]\n",sdata[0]);
	if (sdata[0][0]=='\0') continue;

	$INSERT INTO CAR327 (ipolicy)
              VALUES  ($sdata[0]);
        tot_count ++;
    }
    fclose(fp);
    printf("tot_count[%d]\n",  tot_count );

    $select count(*) into $icount_row from CAR327 where 1=1;
    printf("icount_row[%d]\n",  icount_row );

    EWRITE(userid,M_CM_OK,msgbuf);
    return M_CM_OK;

errexit:
    printf("--ca327_read_data--SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}