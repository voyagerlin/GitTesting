/**********************************************************************/
/*   program id   : ca220p01s.ec                                      */
/*   program name : �h���p�{���S�����ظ�ƶפJ�@�~                    */
/*   date written : 2020/02/15                                        */
/*   date modify  : yyyy/mm/dd                                        */
/*   author       : 071004                                            */                                       
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
#include "safeclib.h"
/****************************************************************************/
$char DBName[05],userid[11],GetFile[128];
$char dcreate_bgn[11],dcreate_end[11];
$char sDcreate_bgn[11],sDcreate_end[11];
$char iissue_comp[3],iofficer[11];
$char date[11],dToday[11],nyy[4],nmm[3],ndd[3];
$char errmsg[10000],errmpt1[100],delmsg[10000],addmsg[10000];
int   errcnt;
int   delete_cnt;
int   add_cnt;
FILE  *fp, *fp1, *sfp;
$char sdata[6][121];
char msgbuf[2048],sApHome[30];
/* char  actiontype[2], v_sMsg[1024]; */
char  actiontype[2], v_sMsg[50000], v_sMsg2[11024], v_sMsg3[11024], v_sMsg4[11024];
char  file_name[128], filename[200],outputf[N_FILE+1];
int   qcount,cnt_status,cnt_err,count_db,i,flen;
long  t;
/****************************************************************************/
main(argc, argv)
int argc;
char **argv;
{  
	int rc;

	batchinit();
	strcpy(DBName, 		  isNULLstr(argv[1]));
	strcpy(userid, 		  isNULLstr(argv[2]));
	strcpy(actiontype,        isNULLstr(argv[3]));  /* 0�G�פJ�ɮ� */	                                          
	strcpy(file_name,         isNULLstr(argv[4]));
	strcpy(GetFile,           isNULLstr(argv[5]));
	strcpy(outputf,           isNULLstr(argv[6]));
	
	printf("-- actiontype[%s], GetFile[%s]\n",actiontype,GetFile);
	
	sfp =  (FILE *)STARTLOG();
		
	rc = car220_get_db();
	if (rc != M_CM_OK) {
		EWRITE(userid,rc,msgbuf);
		return rc;
	}
	
	rc = car220_init_data();
	if (rc != M_CM_OK) {
		EWRITE(userid,rc,"CREATE TEMP TABLE����!");
		return rc;
	}
  
        if (strncmp(actiontype,"0",1) == 0)
        {
            errcnt = 0; 
            delete_cnt = 0;
            add_cnt = 0;
	    strcpy(errmsg,"\t       \t                  \t    \t           \t �h����\t �S����\t     \n"
	                  "\t ���ʧO\t�O�I�Ҹ�          \t����\t   ���إN�X\t �p�{��\t �إN�X\t �Ƶ�\n");
	    strcpy(addmsg,"\t       \t                  \t    \t           \t �h����\t �S����\t     \n"
	                  "\t ���ʧO\t�O�I�Ҹ�          \t����\t   ���إN�X\t �p�{��\t �إN�X\t �Ƶ�\n");
	    strcpy(delmsg,"\t       \t                  \t    \t           \t �h����\t �S����\t     \n"
	                  "\t ���ʧO\t�O�I�Ҹ�          \t����\t   ���إN�X\t �p�{��\t �إN�X\t �Ƶ�\n");	
            rc = car220_read_data();
            if (rc != M_CM_OK) 
            {
    		    EWRITE(userid, rc, "�ɮ���J���~!");
    		    return rc;
    	    }
    	    else
            {
                 printf("=============================> RETURN SUCCESS\n");
                 sprintf_s(v_sMsg, sizeof v_sMsg, "\n    �`���ơG%d\n"
                                  "    �s�W���ơG%d\n"
                                  "    �R�����ơG%d\n"
                                  "    ���~���ơG%d\n"
                                  , qcount, add_cnt,delete_cnt, errcnt);
                                  
                 if (add_cnt==0) strcpy(addmsg,""); 
                 if (delete_cnt==0) strcpy(delmsg,"");  
                 if (errcnt==0) strcpy(errmsg,"");        
                 
                 sprintf_s(v_sMsg3, sizeof v_sMsg3,"\n�s�W����,�@ %d ��, �C�ܦp�U: \n %s",add_cnt,addmsg);
                 sprintf_s(v_sMsg4, sizeof v_sMsg4,"\n�R������,�@ %d ��, �C�ܦp�U: \n %s",delete_cnt,delmsg);             
                 sprintf_s(v_sMsg2, sizeof v_sMsg2,"\n���~����,�@ %d ��, �C�ܦp�U: \n %s",errcnt,errmsg);

                 strcat(v_sMsg,v_sMsg3);
                 strcat(v_sMsg,v_sMsg4);
                 strcat(v_sMsg,v_sMsg2);
                 WRITELOG( sfp, v_sMsg);

                 ENDLOG(sfp);       
            }
        }
	
			
  return rc;
}
/******************************************************************************/
long car220_read_data()
{
        char  *bp;    
        char  fname[128], filepath[256];
        int   rc, i, j, k, m, n;
    
        printf("BEGIN TO READ DATA\n");    

        $WHENEVER SQLERROR GOTO errexit;
    
            

        strcpy(GetFile, trim(GetFile));
        sprintf_s(filename, sizeof filename,"%s/dat/car/%s",sApHome,GetFile);
        flen=1024;
        if ((fp=fopen(filename,"r"))==NULL) {
            sprintf_s(msgbuf, sizeof msgbuf,"%s �ɮ׶}�ҥ���",filename);
            EWRITE(userid,FALSE,msgbuf);
            return FALSE;
        }
        if ((bp=malloc(flen))==NULL) {
            sprintf_s(msgbuf, sizeof msgbuf,"System malloc failed !");
            EWRITE(userid,FALSE,msgbuf);
            free(bp);
            return FALSE;
        }
     
	qcount=cnt_status=cnt_err=0;	
	for (i=0;(feof(fp)==0);i++) 
	{
	    memset(bp,0x00,flen);
	    fgets(bp,flen,fp);
		        
	    if (bp[0]==0x00)	break;
	    if (strlen(trim(bp))<10)	break;
		        	
	    for(j=0;j<6;j++)
	    sdata[j][0]='\0';
		            
	    strcpy(sdata[0],substring(bp,1,1));    /*���ʧO(����1) 9:�s�W�F1:�R��*/
	    strcpy(sdata[1],substring(bp,2,17));   /*�O�I�Ҹ�(����17)*/
	    strcpy(sdata[2],substring(bp,19,12));  /*����(����12)*/
	    strcpy(sdata[3],substring(bp,31,2));   /*���إN�X(����2)*/
	    strcpy(sdata[4],substring(bp,33,2));   /*�O�_���h���ƭp�{��(����2)*/
	    strcpy(sdata[5],substring(bp,35,2));   /*�S�����إN�X(����2)*/
		  
	    printf("sdata[%s][%s][%s][%s][%s][%s]\n",sdata[0],sdata[1],sdata[2],sdata[3],sdata[4],sdata[5]);
	    if (sdata[0][0]=='\0') continue;
	    
	    
            $INSERT INTO car220_tmp
             VALUES($sdata[0],$sdata[1],$sdata[2],$sdata[3],$sdata[4],$sdata[5]);
	    

	    qcount++;		  
	}
		   	 	      
        fclose(fp);
        
        
        
        rc = car220_delete_data();
	if (rc != M_CM_OK)
	{
		EWRITE(userid,rc,"�R������!");
		return rc;	     
	        
	}    
	    
	rc = car220_insert_data();
	if (rc != M_CM_OK)
	{
		EWRITE(userid,rc,"�s�W����!");
		return rc;	 

	}
	    
	    
    /*rc=rptftpinsert(userid,"car220",fname);
    if (rc != 0) return rc;*/
   
    return M_CM_OK;

errexit:
    printf("--car220_read_data-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car220_insert_data()
{
   $char ftype[2], icard[21], itag[13];
    $char icar_type[3], fkind[3];
    $char icar_type_taxi[3];
    $char load_icard[21];
    $char stmpB[100];
    
    $WHENEVER SQLERROR GOTO errexit; 
    
    $BEGIN WORK;
    
    sprintf_s(stmpB, sizeof stmpB,"SELECT * FROM car220_tmp WHERE ftype='9' ");
    printf("stmpB[%s]\n",stmpB);
    $prepare preB from $stmpB;
    $declare curBC cursor for preB;
    $open curBC;
                
    while(1)
    {
        $fetch curBC
         into $ftype,$load_icard,$itag,$icar_type,$fkind,$icar_type_taxi;
         
         if (SQLCODE==SQLNOTFOUND) break;
         
         
         strcpy(icard, substring(trim(load_icard), 3, 15)); /*�O�I�Ҹ�(�h���e2�X)*/

         printf("--> ftype[%s], load_icard[%s]\n", ftype, load_icard);
         printf("--> itag[%s], icar_type[%s]\n", itag, icar_type); 
         printf("--> fkind[%s], icar_type_taxi[%s]\n", fkind, icar_type_taxi); 
         printf("--> icard[%s]\n", icard);    

    	
        if (strncmp(load_icard,"17",2) != 0)   /*�D�����q*/
        {
        	
            strcpy(errmpt1,"");
            errcnt = errcnt+1;
            sprintf_s(errmpt1, sizeof errmpt1,"\t %s\t%s\t%s\t %s\t %s\t %s\t �D�����q��ơA�L�k�s�W\n",ftype,load_icard,itag,icar_type,fkind,icar_type_taxi);
            strcat(errmsg,errmpt1);

            
        }
        else   /*�����q*/
        {
            $SELECT icard
               FROM sysdb:compulsory_card
              WHERE icard = $icard;
            if (SQLCODE == SQLNOTFOUND)
            {
                strcpy(errmpt1,"");
                errcnt = errcnt+1;
                sprintf_s(errmpt1, sizeof errmpt1,"\t %s\t%s\t%s\t %s\t %s\t %s\t �j��d�ɧ䤣��ӥd���A�L�k�s�W\n",ftype,load_icard,itag,icar_type,fkind,icar_type_taxi);
                strcat(errmsg,errmpt1);
            }
            else
            {
                $SELECT icard
                   FROM sysdb:ca_taxi_type
                  WHERE icard=$icard AND itag=$itag AND icar_type_taxi=$icar_type_taxi;
            	if (SQLCODE == SQLNOTFOUND)
            	{
            	    $INSERT INTO sysdb:ca_taxi_type 
            	     VALUES($icard,$itag,$icar_type,$fkind,$icar_type_taxi,CURRENT,$userid,CURRENT,$userid,0);
            	    add_cnt = add_cnt+1; 
            	    
                    strcpy(errmpt1,"");
                    sprintf_s(errmpt1, sizeof errmpt1,"\t %s\t%s\t%s\t %s\t %s\t %s\t �w�s�W\n",ftype,load_icard,itag,icar_type,fkind,icar_type_taxi);
                    strcat(addmsg,errmpt1);
            	               		
            	}
            	else
            	{
                    strcpy(errmpt1,"");
                    errcnt = errcnt+1;
                    sprintf_s(errmpt1, sizeof errmpt1,"\t %s\t%s\t%s\t %s\t %s\t %s\t �w�s�b�h���p�{���S�����ظ���ɡA�L�k�s�W\n",ftype,load_icard,itag,icar_type,fkind,icar_type_taxi);
                    strcat(errmsg,errmpt1);
            	}
            	

            }         	            	            
            
        }
    }
    $close curBC;
    $free curBC;
    
    $COMMIT WORK;
    		
    return M_CM_OK;

errexit:
    printf("--car220_insert_data-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    $rollback work;
    return SQLCODE; 
}
/******************************************************************************/
long car220_delete_data()
{
    $char ftype[2], icard[21], itag[13];
    $char icar_type[3], fkind[3];
    $char icar_type_taxi[3];
    $char load_icard[21];
    $char stmpA[100];
    
    $WHENEVER SQLERROR GOTO errexit; 
    
    $BEGIN WORK;
    
    sprintf_s(stmpA, sizeof stmpA,"SELECT * FROM car220_tmp WHERE ftype='1' ");
    printf("stmpA[%s]\n",stmpA);
    $prepare preA from $stmpA;
    $declare curAC cursor for preA;
    $open curAC;
                
    while(1)
    {
        $fetch curAC
         into $ftype,$load_icard,$itag,$icar_type,$fkind,$icar_type_taxi;
         
         if (SQLCODE==SQLNOTFOUND) break;
         
         strcpy(icard, substring(trim(load_icard), 3, 15)); /*�O�I�Ҹ�(�h���e2�X)*/

         printf("--> ftype[%s], load_icard[%s]\n", ftype, load_icard);
         printf("--> itag[%s], icar_type[%s]\n", itag, icar_type); 
         printf("--> fkind[%s], icar_type_taxi[%s]\n", fkind, icar_type_taxi); 
         printf("--> icard[%s]\n", icard);    

    	
        if (strncmp(load_icard,"17",2) != 0)   /*�D�����q*/
        {
        	
            strcpy(errmpt1,"");
            errcnt = errcnt+1;
            sprintf_s(errmpt1, sizeof errmpt1,"\t %s\t%s\t%s\t %s\t %s\t %s\t �D�����q��ơA�L�k�R��\n",ftype,load_icard,itag,icar_type,fkind,icar_type_taxi);
            strcat(errmsg,errmpt1);

            
        }
        else   /*�����q*/
        {
            $SELECT icard
               FROM sysdb:ca_taxi_type
              WHERE icard=$icard AND itag=$itag AND icar_type=$icar_type AND fkind=$fkind AND icar_type_taxi=$icar_type_taxi;
            if (SQLCODE == SQLNOTFOUND)
            {
                strcpy(errmpt1,"");
                errcnt = errcnt+1;
                sprintf_s(errmpt1, sizeof errmpt1,"\t %s\t%s\t%s\t %s\t %s\t %s\t �h���p�{���S�����ظ���ɧ䤣���ơA�L�k�R��\n",ftype,load_icard,itag,icar_type,fkind,icar_type_taxi);
                strcat(errmsg,errmpt1);
            }
            else
            {
            	$DELETE FROM sysdb:ca_taxi_type WHERE icard=$icard AND itag=$itag AND icar_type=$icar_type AND fkind=$fkind AND icar_type_taxi=$icar_type_taxi;
            	delete_cnt = delete_cnt+1;
            	strcpy(errmpt1,"");
                sprintf_s(errmpt1, sizeof errmpt1,"\t %s\t%s\t%s\t %s\t %s\t %s\t �w�R��\n",ftype,load_icard,itag,icar_type,fkind,icar_type_taxi);
                strcat(delmsg,errmpt1);
            }         	            	            
            
        }
    }
    $close curAC;
    $free curAC;
    
    $COMMIT WORK;
    		
    return M_CM_OK;

errexit:
    printf("--car220_delete_data-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    $rollback work;
    return SQLCODE; 
}
/******************************************************************************/
long car220_get_db()
{
	int return_code;
	
	$WHENEVER SQLERROR GOTO errexit;
	
	t = cm_today();
        strcpy(date,cm_edate_str(t));  
        strcpy(dToday,cm_from_infdate_100(date));
        cm_split_ymd_100(dToday,nyy,nmm,ndd);

	if (db_select(DBName) == False) {
		strcpy(msgbuf,"��Ʈw�L�k�}��");
		return M_CM_DB_NOTOPEN;
	}
	return_code = getApHome(sApHome);
	if (return_code < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		return return_code;
  }  
  return M_CM_OK;

errexit:
   printf("--car220_get_db-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/******************************************************************************/
long car220_init_data()
{   
    $WHENEVER SQLERROR GOTO errexit;
         	  	   
	  $create temp table car220_tmp(
	  
	  	  ftype          char(1),  /*���ʧO 9:�s�W 1:�R��*/
	  	  icard          char(20),  /*�O�I�Ҹ�*/
	  	  itag           char(12),   /*����*/
	  	  icar_type      char(2),  /*���إN�X*/
	  	  fkind          char(1),   /*�O�_���h���ƭp�{�� Y�G���h���ƭp�{���AN�G�D�h���ƭp�{�� */
	  	  icar_type_taxi char(2)    /*�S�����إN�X*/
	  	 
	  )with no log;
	  
	    
	  return M_CM_OK;

errexit:
    printf("--car220_init_data-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/