/****************************************************
 * Copyright (C) 1993 Intellisys Corporation
 *
 * Program : ca203q01s.ec 
 *
 * revised : Johnny 1997/07/11
 *
 * Background Report   (Type : Free Style)
 ****************************************************/

#include <stdio.h>
#include <math.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"

#include "carmsgs.h" 
#include "commsgs.h" 
#include "cmnmsgs.h" 
#include "gls_array.h" 
#include "gls_const.h"
#include "sqlfatal.h"
#include "safeclib.h"

/*----------------------------------------------------------------------*/

int max_count;

$char DBName[5];
$char FormTp[3];
char  outputf[20];
char  userid[11];
char  v_sMsg[512];

$char iquota[7], icreate[11], icard[21], dcreateBgn[11], dcreateEnd[11];
$char iserialBgn[8], iserialEnd[8], fcar_type[2];
$char stmt[1024], sWhere[256];
long car203_build();
/*---------------------------------------------------------------------*/

main(argc, argv)
int argc;
char **argv;
{
    long rc;
    batchinit();
    strcpy(DBName,      isNULLstr(argv[1]));
    strcpy(userid,      isNULLstr(argv[2]));

    strcpy( iquota,     isNULLstr(argv[3])); 
    strcpy( icreate,    isNULLstr(argv[4])); 
    strcpy( icard,      isNULLstr(argv[5]));
    strcpy( dcreateBgn, isNULLstr(argv[6]));
    strcpy( dcreateEnd, isNULLstr(argv[7])); 
    strcpy( iserialBgn, isNULLstr(argv[8])); 
    strcpy( iserialEnd, isNULLstr(argv[9]));
    strcpy( fcar_type,   isNULLstr(argv[10]));
    strcpy( outputf,    isNULLstr(argv[11]));

    rc=car203_build();
    if (rc != M_CM_OK)
    {
        EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
        return rc;
    }
       
    if ((rc=save_form_info(F_FREE,"CA",203,userid,FormTp,max_count,outputf))<0)
    {
        EWRITE(userid,rc,"save_form_info failed");
        exit(FAIL);
    }
}

/*---------------------------------------------------------------------*/   
long car203_build()
{
  $char FormFile[N_FILE+1];
  char  OutFile[N_FILE];
  long  rtncode;

  $char dcreate[21], iserial[8], nbranch[41];
  $char nname[11], ipolicy[21], ireason[2], nreason[61], nassured[121];
  $char tmp_iserial[9];

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
      sprintf_s(v_sMsg, sizeof v_sMsg, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN; 
  }

  $SELECT nForm_File, iForm_Tp
     INTO $FormFile, $FormTp
     FROM Form
    WHERE ksys_grp="CA" AND kPgmID = 203
      AND iform_tp = '6';

  strcpy(FormFile,rtrim(FormFile));  /* FormFile=car2036.fmt */
  sprintf_s(OutFile, sizeof OutFile,"%s.tx",outputf);
  rgu_init_report(FormFile,OutFile);

  rgu_put_body(9);
  rgu_put_body_string(1,iquota,LEFT);
  rgu_put_body_string(1, cm_sysd_edatetime(cm_sysd_cdatetime_100(cm_get_sysd())));
  rgu_put_body(1);
  rgu_put_body_string(2,icreate,LEFT);
  rgu_put_body(2);
  rgu_put_body_string(3,icard,LEFT);
  rgu_put_body(3);
  rgu_put_body_string(4,dcreateBgn,LEFT);
  rgu_put_body_string(4,dcreateEnd,LEFT);
  rgu_put_body(4);
  rgu_put_body_string(5,iserialBgn,LEFT);
  rgu_put_body_string(5,iserialEnd,LEFT);
  rgu_put_body(5);
  if( fcar_type[0] == '1')
      rgu_put_body_string(6, "�T��",LEFT);
  else
      rgu_put_body_string(6, "����",LEFT);
  rgu_put_body(6);
  rgu_put_body(7);
  max_count+=11;

  sWhere[0] = 0;
  strcpy( iserialBgn, trim(iserialBgn));
  if( strcmp( iserialBgn, "*") != 0)
      sprintf_s(sWhere, sizeof sWhere, " AND a.iserial between '%s' AND '%s' ", iserialBgn, iserialEnd);
  if( fcar_type[0] == '1')
     strcat( sWhere, "   AND a.icar_type not in ('01','02','32','34','35') "); 
  else
     strcat( sWhere, "   AND a.icar_type in ('01','02','32','34','35') ");
  sprintf_s(stmt, sizeof stmt, "SELECT a.dcreate, a.iserial, a.iquota, b.nbranch, a.icreate, "
                 "       c.nname, a.icard, a.ipolicy, a.ireason, a.nreason, a.nassured "
                 "  FROM ca_card_log a, outer sa_branch_type b, outer officer c "
                 " WHERE a.iquota = b.ibranch "
                 "   AND a.icreate = c.iofficer "
                 "   AND a.iquota matches '%s'  "
                 "   AND a.icreate matches '%s'  "
                 "   AND a.icard matches '%s'  "
                 "   AND date(a.dcreate) between '%s' AND '%s' %s ",
                     iquota, icreate, icard, dcreateBgn, dcreateEnd, sWhere);
  printf("stmt[%s]\n", stmt);
  $PREPARE prep1 FROM $stmt;
  $DECLARE curs1 CURSOR FOR prep1;
  $OPEN curs1;
  for(;;)
  {
      $FETCH curs1 INTO $dcreate, $iserial, $iquota, $nbranch, $icreate,
                        $nname, $icard, $ipolicy, $ireason, $nreason, $nassured;
      if( SQLCODE == SQLNOTFOUND) break;

      rgu_put_body_string(8,dcreate,LEFT);
      sprintf_s(tmp_iserial, sizeof tmp_iserial, "'%s", iserial);
      rgu_put_body_string(8,tmp_iserial, LEFT);
      rgu_put_body_string(8,iquota,LEFT);
      rgu_put_body_string(8,nbranch,LEFT);
      rgu_put_body_string(8,icreate,LEFT);
      rgu_put_body_string(8,nname,LEFT);
      rgu_put_body_string(8,icard,LEFT);
      rgu_put_body_string(8,nassured,LEFT);
      if( ireason[0] == '1')
          rgu_put_body_string(8, "�L��B��蠟�ɴ��o",LEFT);
      else if( ireason[0] == '2')
          rgu_put_body_string(8, "�L�����o",LEFT);
      else if( ireason[0] == '3')
          rgu_put_body_string(8, "�򥢸ɵo",LEFT);
      else
          rgu_put_body_string(8,nreason,LEFT);
      rgu_put_body(8);
      max_count++;
  }
  $FREE prep1;
  $CLOSE curs1;
  $FREE curs1;

  rgu_finish_report();
  printf("finish_code------>%d\n",rtncode);
  return M_CM_OK;
  
errexit:
  sqlfatal();
  EWRITE(userid,SQLCODE,sqlca.sqlerrm);
  exit (FAIL);
} 

