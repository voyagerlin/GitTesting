/***************************************************/
/*                                                 */
/*   PROGRAM : ca201m01s.ec                        */
/*                                                 */
/***************************************************/
#include <stdio.h>
#include "comdata.h"
$include datetime.h;
#include "sql.h"
#include "print.h"
#include "gls_array.h" 
#include "gls_const.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
#include  "cmnmsgs.h"
#include "is_def.h"
$include sqlca;

#define WAKEUP_CNT 100
#define DATENULL               0x80000000L

struct card_struct {
       char begin[21];
       char end[21];
}list[MAXROWITEMS];

$date Today;
int   fcomp_p3;
char isExecute;
/************************************************************************/
long car201(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
     long rtncode;
     long car201_insert(),car201_single_query(),car201_multiple_query();
     long car201_update_exec(),car201_R1(),car201_R2(),car201_R3();
     int  IsBlankNull();
     char option,option1;

     rtoday(&Today);     /* get today's datetime */

     fcomp_p3=0;
     cm_buf_init(command);
     cm_buf_get("%c",&option);
     switch(option)
     {
        case 'A':
            rtncode=car201_insert(reply);
            break;
        case 'R':
            cm_buf_get("%c",&option1);
            switch (option1) 
            {
               case '1':
                  rtncode=car201_R1(reply); /* �ӻ��C�L */
                  break;
               case '2':
                  cm_buf_get("%c",&isExecute); /* �O�_�������� */
                  rtncode=car201_R2(reply); /* �j����,���N�d ���� */

                  break;
               case '3':
                  rtncode=car201_R3(reply); /* ñ����ҦC�L */
                  break;
               case '4':     /* �@��j����3P���� */
                  fcomp_p3=1;
                  cm_buf_get("%c",&isExecute); /* �O�_�������� */
                  rtncode=car201_R2(reply);
                  break;
               case '5':     /* �ۭq�����϶� */
                  cm_buf_get("%c",&isExecute); /* �O�_�������� */
                  rtncode=car201_R4(reply);
                  break;                  
               default :
                  return exitsub(reply,M_CM_WRONG_OPTION)?M_CM_WRONG_OPTION:apiRC;
            }
            break;
        case 'Q':
            rtncode=car201_single_query(reply);
            break;
        case 'M':
            rtncode=car201_multiple_query(reply);
            break;
        case 'D':
        case 'U':
            rtncode=car201_update_exec(reply,command,com_len);
            break;
        case 'B':
            rtncode=car201_get_billingsystem_setting(reply);  /*��billingsystem��Ū���s�X�W�h*/
            break;
        default :
            return exitsub(reply,M_CM_WRONG_OPTION)?M_CM_WRONG_OPTION:apiRC;
     }
     return(rtncode);
}

/*****************************************************************************/
long car201_insert(reply)
serverReply reply; 
{
     $char DBName[DBNAME];
     $char iofficer[EMPLOYEE_ID],ioffice[7],icardyear[4],dissue[11];
     $char s_dissue[10],iissuer[11];
     $char issuebranch[CA_POL_BRH_NUM];
     $char iupcomp[3],icar_type[3];
     $char sIcomp_in[3], sIbranch_in[3];
      char sTmpIbranch[3], sTmpIcomp[3];
      char sTmpTaipei[BRANCH_ID];

     $long qcard,qperiod;
     $long avaisum,usedsum,cancelsum,losssum,expiresum,sum;
     $char fstatus[2];
     $char ibigcomp[2];
     $char ibigoffice[7];
     $char sFcard_class[2], sIssue_branch[3];
     int   lqperiod[MAXROWITEMS],lqcard[MAXROWITEMS];
     char  lcartype[MAXROWITEMS][3];
     int   count,i; /* standard defined data */
     int   tmp_len;
     long  MsgCode;
     long  fRtnCode;
     /* end of standard data */

     /* self defined data */
     int   rows;
     $date max_drate=DATENULL;
     char  FullDBName[20];
     $char stmt_buf[500];
     /* end of self data */

     cm_buf_get("%s",DBName);
     cm_buf_get("%s %s ",sFcard_class, sIssue_branch );
     cm_buf_get("%s %s %s %s %s %s %l",
                iofficer,ioffice,icardyear,s_dissue,iissuer,issuebranch,&rows);

     strcpy(dissue,cm_to_infdate(s_dissue));

     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
         return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     fRtnCode = getHeadBranch(sTmpTaipei);

     if (fRtnCode < 0)
        return exitsub(reply, M_CM_READ_CONFIG_ERR ) ?
                       M_CM_READ_CONFIG_ERR : apiRC;

     if (strcmp(DBName, sTmpTaipei) !=0)
        return exitsub(reply,M_CA_BRANCH_NSAME) ? M_CA_BRANCH_NSAME :apiRC;

     strcpy(FullDBName, get_full_dbname(sTmpTaipei));
     if (FullDBName[0]=='\0')
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     printf("FullDBName ==> [%s]\n",FullDBName);
     printf("ioffice    ==> [%s]\n",ioffice);
     
     /*�k�ݳ��*/
     fRtnCode = cm_get_unit_in("", DBName, iissuer, issuebranch, "C1", sIcomp_in,
                               sIbranch_in);
     if (fRtnCode != M_CM_OK)
         return exitsub(reply, fRtnCode) ?  fRtnCode : apiRC;
     
     printf("sIbranch_in  ==>[%s] sIcomp_in  ==>[%s]\n",sIbranch_in, sIcomp_in );

     $BEGIN WORK;
     
     if( strcmp( sFcard_class, "1" ) == 0 )
     {
        /** �j���I **/
        sprintf(stmt_buf,"INSERT INTO issued_card \
                          (iofficer, ioffice, icardyear, dissue, \
                           iissue_branch, iissue_comp, fcard_class, \
                           icar_type, qperiod, qcard, iissuer, fapp_print, \
                           frec_print) \
                          VALUES (?,?,?,?,?,?,?,?,?,?,?,'0','0') ");
        $PREPARE c_issued_card FROM $stmt_buf;
     }
     else
     {
        /** ���N�I **/
        sprintf(stmt_buf,"INSERT INTO issued_card \
                          (iofficer, ioffice, icardyear, dissue, \
                           iissue_branch, iissue_comp, fcard_class, \
                           icar_type, qperiod, qcard, iissuer ) \
                          VALUES (?,?,?,?,?,?,?,?,?,?,?) ");
        $PREPARE v_issued_card FROM $stmt_buf;
     }

     /***** �Τ@�ѥx�_ñ�o�ӻ�AINSERT �� SYSDB ��Ʈw ****/
     for (i=0; i<rows; i++)
     {
          cm_buf_get("%s %l %l",icar_type,&qperiod,&qcard);
          strcpy(lcartype[i], icar_type,2);
          lqperiod[i]=qperiod;
          lqcard[i]  =qcard;
          
          if( strcmp( sFcard_class, "1") == 0 )
          {
            $EXECUTE c_issued_card
               USING $iofficer,$ioffice,$icardyear,$dissue,$sIbranch_in,$sIcomp_in,
                     $sFcard_class,$icar_type,$qperiod,$qcard,$iissuer;
          }
          else
          {
            $EXECUTE v_issued_card
               USING $iofficer,$ioffice,$icardyear,$dissue,$sIbranch_in,$sIcomp_in,
                     $sFcard_class,$icar_type,$qperiod,$qcard,$iissuer;
          }
     }
     /* end of for loop */

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);
     cm_buf_put("%l",rows);
     for (i=0;i<rows;i++)
          cm_buf_put("%s %d %d", lcartype[i],lqperiod[i],lqcard[i]);

     printf("---- 3\n");

     avaisum=usedsum=cancelsum=losssum=expiresum=0;

     /** modify no match by iofficer,ioffice,icardyear**/
     strcpy(icardyear,trim(icardyear));
     
     if( strcmp( sFcard_class,"1" ) == 0 )
     {
        $DECLARE comp_cur1 CURSOR FOR
          SELECT fstatus
            INTO $fstatus
            FROM compulsory_card
           WHERE icardyear = $icardyear
             AND iofficer  = $iofficer
             AND ioffice   = $ioffice;
        $OPEN comp_cur1;
        $FETCH comp_cur1;
        while (SQLCODE !=SQLNOTFOUND)
        {
            if (strcmp(fstatus,"0")==0)
                avaisum+=1;
            if (strcmp(fstatus,"1")==0)
                usedsum+=1;
            if (strcmp(fstatus,"3")==0)
                cancelsum+=1;
            if (strcmp(fstatus,"4")==0)
                losssum+=1;
            if (strcmp(fstatus,"2")==0)
                expiresum+=1;
            if (strcmp(fstatus,"5")==0)
                avaisum+=1;
            if (strcmp(fstatus,"6")==0)
                avaisum+=1;
            if (strcmp(fstatus,"7")==0)
                avaisum+=1;                                
            $FETCH comp_cur1;
        }
        $CLOSE comp_cur1;
     }
     else
     {
        $DECLARE card_cur1 CURSOR FOR
          SELECT fstatus INTO $fstatus
            FROM card
           WHERE icardyear=$icardyear
             AND iofficer=$iofficer
             AND ioffice=$ioffice;
        $OPEN card_cur1;
        $FETCH card_cur1;
        while (SQLCODE !=SQLNOTFOUND)
        {
            if (strcmp(fstatus,"0")==0) avaisum+=1;
            if (strcmp(fstatus,"1")==0) usedsum+=1;
            if (strcmp(fstatus,"2")==0) expiresum+=1;
            if (strcmp(fstatus,"3")==0) cancelsum+=1;
            if (strcmp(fstatus,"4")==0) losssum+=1;
            if (strcmp(fstatus,"5")==0) avaisum+=1;
            if (strcmp(fstatus,"6")==0) avaisum+=1;
            if (strcmp(fstatus,"7")==0) avaisum+=1;
           $FETCH card_cur1;
        }
        $CLOSE card_cur1;
     }

     printf("---- 4\n");

     sum=avaisum+usedsum+cancelsum+losssum+expiresum;

     cm_buf_put("%l %l %l %l %l %l",
                avaisum,usedsum,cancelsum,losssum,expiresum,sum);
     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
     {
         $WHENEVER SQLERROR CONTINUE;
         $ROLLBACK WORK;
         return apiRC;
     }
     $WHENEVER SQLERROR GOTO errexit;

     $COMMIT WORK;
     return api_OKComplete;

errexit:
     printf("SQL ERROR = %ld errm=%s\n",SQLCODE,sqlca.sqlerrm);
     MsgCode = SQLCODE;
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     if (SQLCODE != 0) MsgCode = SQLCODE;
     return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

/*****************************************************************************/
long car201_R1(reply)
serverReply reply;
{
     $char DBName[5];

     $char iofficer[EMPLOYEE_ID],ioffice[7],icardyear[4],dissue[11];
     $char s_dissue[10],iissuer[11],issuebranch[CA_POL_BRH_NUM];
     $char icar_type[3],fapp_print[2];
     $char sIbranch_in[3], sIcomp_in[3];
     $long qcard,qperiod;
      char sTmpIbranch[5], sTmpIcomp[5];
      char sTmpTaipei[BRANCH_ID];
      char CompanyName[COMPANY_CFULL];

     $long avaisum,usedsum,cancelsum,losssum,expiresum,sum,sum1,sum2;
     $char fstatus[2];
     $char sFcard_class[2], sIssue_branch[5];

     /* standard defined data */
     int   tmp_len;
     long  MsgCode;
     long  fRtnCode;
     char  FullDBName[41];
     /* end of standard data */

     /* self defined data */
     long count;
     $long app_count;
     /* end of self data */

     $WHENEVER SQLERROR GOTO errexit;

     cm_buf_get("%s",DBName);
     cm_buf_get("%s %s ",sFcard_class, sIssue_branch );
     cm_buf_get("%s %s %s %s",iofficer,ioffice,icardyear,s_dissue);
     cm_buf_get("%s",issuebranch);
     strcpy(dissue,cm_to_infdate(s_dissue));

     if (db_select(DBName) == False)
           return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     fRtnCode = getHeadBranch(sTmpTaipei);
     if (fRtnCode < 0)
           return exitsub(reply, M_CM_READ_CONFIG_ERR ) ?
                          M_CM_READ_CONFIG_ERR : apiRC;

     if (strcmp(DBName, sTmpTaipei) !=0)
           return exitsub(reply,M_CA_BRANCH_NSAME) ? M_CA_BRANCH_NSAME :apiRC;

     strcpy(FullDBName, get_full_dbname(sTmpTaipei));
     if (FullDBName[0]=='\0')
           return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     fRtnCode = getCompanyCFull(CompanyName);
     if (fRtnCode < 0)
        return exitsub(reply, fRtnCode) ?  fRtnCode : apiRC;

     /*�k�ݳ��*/
     fRtnCode = cm_get_unit_in("", DBName, iissuer, issuebranch, "C1", sIcomp_in,
                               sIbranch_in);
     if (fRtnCode != M_CM_OK)
        return exitsub(reply, fRtnCode) ?  fRtnCode : apiRC;

     $BEGIN WORK;

     avaisum=usedsum=cancelsum=losssum=expiresum=0;
     
     strcpy(icardyear,trim(icardyear));
     if( strcmp(sFcard_class,"1") == 0 )
     {
        $DECLARE comp_cur2 CURSOR FOR
          SELECT fstatus
            INTO $fstatus
            FROM compulsory_card
           WHERE icardyear= $icardyear
             AND iofficer = $iofficer;
        $OPEN comp_cur2;
        $FETCH comp_cur2;
        while (SQLCODE !=SQLNOTFOUND)
        { 
            if (strcmp(fstatus,"0")==0)  avaisum+=1;
            if (strcmp(fstatus,"1")==0)  usedsum+=1;
            if (strcmp(fstatus,"3")==0)  cancelsum+=1;
            if (strcmp(fstatus,"4")==0)  losssum+=1;
            if (strcmp(fstatus,"2")==0)  expiresum+=1;
            if (strcmp(fstatus,"5")==0)  avaisum+=1;
            if (strcmp(fstatus,"6")==0)  avaisum+=1;
            if (strcmp(fstatus,"7")==0)  avaisum+=1;                
            $FETCH comp_cur2;
        }
        $CLOSE comp_cur2;
     }
     else
     {
        $DECLARE valu_cur2 CURSOR FOR
          SELECT fstatus
            INTO $fstatus
            FROM card
           WHERE icardyear= $icardyear
             AND iofficer = $iofficer;
        $OPEN valu_cur2;
        $FETCH valu_cur2;
        while (SQLCODE !=SQLNOTFOUND)
        { 
            if (strcmp(fstatus,"0")==0)  avaisum+=1;
            if (strcmp(fstatus,"1")==0)  usedsum+=1;
            if (strcmp(fstatus,"3")==0)  cancelsum+=1;
            if (strcmp(fstatus,"4")==0)  losssum+=1;
            if (strcmp(fstatus,"2")==0)  expiresum+=1;
            if (strcmp(fstatus,"5")==0)  avaisum+=1;
            if (strcmp(fstatus,"6")==0)  avaisum+=1;
            if (strcmp(fstatus,"7")==0)  avaisum+=1;                
            $FETCH valu_cur2;
        }
        $CLOSE valu_cur2;
     }

     sum=avaisum+usedsum+cancelsum+losssum+expiresum;

     cm_buf_init(ReplyBuf);
     cm_buf_res_msg();
     cm_buf_res_count();
     cm_buf_put_msg(M_CM_OK);
     cm_buf_put("%s %s %s %l %l %l %l %l %l",
                iofficer,icardyear,CompanyName,avaisum,usedsum,cancelsum,losssum,expiresum,sum);
     cm_buf_put("%s %s", ioffice, issuebranch);

     $DECLARE curb CURSOR FOR
       SELECT icar_type,qperiod,qcard,fapp_print
         INTO $icar_type,$qperiod,$qcard,$fapp_print
         FROM issued_card
        WHERE iofficer     = $iofficer
          AND ioffice      = $ioffice
          AND icardyear    = $icardyear
          AND dissue       = $dissue
          AND fcard_class  = $sFcard_class
          AND iissue_branch= $sIbranch_in
          AND iissue_comp  = $sIcomp_in
          FOR UPDATE OF fapp_print;

     $OPEN curb;
     count=0;
     sum1=sum2=0;
     for (;;)
     {
         $FETCH curb;
         if (SQLCODE != 0)
            break;


         count++;

         $UPDATE issued_card
             SET (fapp_print) = ("1")
           WHERE CURRENT OF curb;

         sum1+=qcard;
         cm_buf_put("%s %l %l", icar_type,qperiod,qcard);
     }

     $CLOSE curb;

     if (count == 0)
     {
         $WHENEVER SQLERROR CONTINUE;
         $ROLLBACK WORK;
         return exitsub(reply,M_CA_NISSUED_CARD) ? M_CA_NISSUED_CARD : apiRC;
     }

     cm_buf_put_count(count);
     cm_buf_put("%l",sum1);

     $WHENEVER SQLERROR GOTO errexit;
     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
     {
         $WHENEVER SQLERROR CONTINUE;
         $ROLLBACK WORK;
         return apiRC;
     }

     $WHENEVER SQLERROR GOTO errexit;
     $COMMIT WORK;
     return api_OKComplete;

errexit:
     printf("SQL ERROR = %ld errm=%s\n",SQLCODE,sqlca.sqlerrm);
     MsgCode = SQLCODE;
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     if (SQLCODE != 0) MsgCode = SQLCODE;
     return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

/*****************************************************************************/
long car201_R2(reply)
serverReply reply;
{
     $char DBName[5];

     $char  iofficer[11],ioffice[7],icardyear[4],dissue[11];
     $char  sIquota[11];
     $char  s_dissue[10],iissuer[11],issuebranch[CA_POL_BRH_NUM],icar_type[3];
     $short icar_end_id;
     $long  qcard,qperiod;
     $char  icar_begin[21],icar_end[21],cardnum[21],tmp_cardnum[21];
     $char  first_icar_begin[21],last_icar_end[21],ichk_num[2];
     char   tmpbgn[7],tmpend[7],cmdbuf[4000];
     long   intbgn,intend;
     $char  iunit[3];
     $char  fcar_class[2];
     $char  sIbranch_in[3], sIcomp_in[3];
     $char  sFcard_class[2], sIssue_branch[3];
     char   sTmpIbranch[3], sTmpIcomp[3];
      char  sTmpTaipei[BRANCH_ID];

     $long avaisum,usedsum,cancelsum,losssum,expiresum,sum;
     $char ibigoffice[7];
     $char icard_abbr[2],icard[3],tempcard[9];
     int   card_len;
     int   count,i,j,count2;

     /*--------------------------- */
     char  chn_dollor[51];
     $char tmp_code_1[3],tmp_name_1[11];
     /*--------------------------- */

     /* standard defined data */
     int tmp_len,cmdlen;
     long MsgCode, fRtnCode, lFfirst;
     /* end of standard data */

     /* self defined data */
     long rows,rec_qperiod,rec_qcard;
     char qperiod1[2],sIbilling[7];
     char rec_icartype[3],tmpnum[6],tmpcard[9];

     struct rec_struct{
            char cartype[3];
            long qperiod;
            long qcard;
     } reclist[MAXROWITEMS];

     $char wk_icard_begin[21], wk_icard_end[21];
     int   num_count;
     $date max_drate=DATENULL;
     char  FullDBName[20], sIcardyear[YYYMMDD];
     $char stmt_buf[600];
     $char tmp_card[20];
     char  checkno_flag[3];
     /* end of self data */

     cm_buf_get("%s",DBName);
     cm_buf_get("%s %s %s ",   sFcard_class,checkno_flag,sIssue_branch );
     cm_buf_get("%s %s %s %s", iofficer,ioffice,icardyear,s_dissue);
     cm_buf_get("%s %s %l",    iissuer,issuebranch,&rows);

     strcpy(dissue, cm_to_infdate(s_dissue));
     strcpy(icardyear,trim(icardyear));     
     strcpy(sIcardyear, icardyear);
     strcat(sIcardyear, "/01/01");

     printf(" [%s] [%s] [%s] [%s] [%s] [%s] [%ld]\n", 
              iofficer,ioffice,icardyear,dissue,iissuer,issuebranch,&rows);

     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     fRtnCode = getHeadBranch(sTmpTaipei);
     if (fRtnCode < 0)
         return exitsub(reply, M_CM_READ_CONFIG_ERR ) ?
                M_CM_READ_CONFIG_ERR : apiRC;

     if (strcmp(DBName, sTmpTaipei) !=0)
         return exitsub(reply,M_CA_BRANCH_NSAME) ? M_CA_BRANCH_NSAME :apiRC;

     strcpy(FullDBName, get_full_dbname(sTmpTaipei));
     if (FullDBName[0]=='\0')
         return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;


     /*�k�ݳ��*/
     fRtnCode = cm_get_unit_in("", DBName, iissuer, issuebranch, "C1", sIcomp_in,
                               sIbranch_in);
     if (fRtnCode != M_CM_OK)
        return exitsub(reply, fRtnCode) ?  fRtnCode : apiRC;

     $SELECT iquota
        INTO :sIquota
        FROM officer
       WHERE iofficer = :iofficer;
     if (SQLCODE==SQLNOTFOUND)
     {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        return exitsub(reply,M_CMN_NOFFICER)? M_CMN_NOFFICER: apiRC;
     }

     printf("******** issuebranch[%s] dbname[%s]\n",issuebranch,FullDBName);

     for (i=0;i<rows;i++)
     {
         cm_buf_get("%s %l %l",rec_icartype,&rec_qperiod,&rec_qcard);
         strcpy(reclist[i].cartype,rec_icartype);
         reclist[i].qperiod = rec_qperiod;
         reclist[i].qcard   = rec_qcard;
     }
     num_count = 0;

     $BEGIN WORK;

     if( strcmp( sFcard_class , "1" ) == 0 ) /** �j���I**/
     {
          for (i=0; i<rows; i++)
          {
               strcpy(icar_type,reclist[i].cartype);
               qperiod=reclist[i].qperiod;
               qcard=reclist[i].qcard;

               printf("qcard[%d] \n",qcard);

               if (!IsBlankNull(ioffice))
               {  /* �O�N */
                    $SELECT icard_begin, icard_end
                       INTO $wk_icard_begin, $wk_icard_end
                       FROM issued_card
                      WHERE iofficer     = $iofficer
                        AND ioffice      = $ioffice
                        AND iissue_branch= $sIbranch_in
                        AND iissue_comp  = $sIcomp_in
                        AND icardyear    = $icardyear
                        AND dissue       = $dissue
                        AND fcard_class  = "1"
                        AND icar_type    = $icar_type
                        AND qperiod      = $qperiod
                        AND qcard        = $qcard;

                    if (SQLCODE==SQLNOTFOUND)
                    {
                         $WHENEVER SQLERROR CONTINUE;
                         $ROLLBACK WORK;
                         return exitsub(reply,M_CA_NISSUED_CARD1)? M_CA_NISSUED_CARD1: apiRC;
                    }
                    else if ( wk_icard_begin[0] !=' ' && wk_icard_begin[0] !='\0' )
                    {
                         num_count++;
                         continue;  /*�Y�w�������U�@��*/
                    }
               }
               else
               {      /*�@��*/
                    sprintf(stmt_buf,"SELECT %s FROM %s:issued_card %s %s %s %s",
                                     "icard_begin,icard_end",
                                     FullDBName,
                                     "WHERE iofficer=? AND ioffice=? AND iissue_branch=? ",
                                     "  AND iissue_comp=? ",
                                     "  AND icardyear=? AND dissue=? AND fcard_class='1' ",
                                     "  AND icar_type=? AND qperiod=? AND qcard=? ");
                    $PREPARE STMT_ISSUED FROM $stmt_buf;
                    $DECLARE issued_card_cur CURSOR FOR STMT_ISSUED;
                    $OPEN issued_card_cur USING $iofficer, $ioffice, $sIbranch_in, $sIcomp_in,
                                                $icardyear, $dissue,
                                                $icar_type, $qperiod, $qcard;
                    $FETCH issued_card_cur INTO $wk_icard_begin,$wk_icard_end;

                    if (SQLCODE==SQLNOTFOUND)
                    {
                         $WHENEVER SQLERROR CONTINUE;
                         $ROLLBACK WORK;
                         return exitsub(reply,M_CA_NISSUED_CARD1)?M_CA_NISSUED_CARD1:apiRC;
                    }
                    else
                    {
                         if ( wk_icard_begin[0] !=' ' && wk_icard_begin[0] !='\0' )
                         {
                              num_count++;
                              continue; /*�Y�w�������U�@��*/
                         }
                    }
               }

               if (!IsBlankNull(ioffice)) /* �O�N�� */
               {
                    strcpy(icar_begin, icardyear);
                    strcat(icar_begin, "C");
                    strcat(icar_begin, trim(ioffice));
                    strcpy(icar_end, " ");

                    printf("------>icar_begin[%s]\n",icar_begin);
                    printf("------>sIbranch_in[%s]\n",sIbranch_in);
                    printf("------>sIcomp_in[%s]\n",sIcomp_in);
                    printf("------>icardyear[%s]\n",icardyear);
                    printf("------>ioffice[%s]\n",ioffice);

                    $SELECT max(icard_end)
                       INTO $icar_end:icar_end_id
                       FROM issued_card
                      WHERE icardyear = $icardyear
                        AND ioffice = $ioffice
                        AND fcard_class='1';

                    printf("------>icar_end[%s]\n",icar_end);

                    if ((icar_end_id == -1) || IsBlankNull(icar_end))
                    {
                         strncpy(&(icar_begin[4]),"000000",6);
                         icar_begin[10]='\0';
                    }
                    else
                    {
                         intbgn=atol(&(icar_end[4]));
                         sprintf(tmpbgn,"%06d",intbgn);
                         strncpy(&(icar_begin[4]),tmpbgn,6);
                         icar_begin[10]='\0';
                    }
                    strcpy(cardnum, icar_begin);

                    printf("-------->cardnum[%s]\n", cardnum);
               }

               lFfirst=TRUE;
               for (j=0; j<qcard; j++)
               {
                   if (IsBlankNull(ioffice)) /*�@��*/
                   {
                        strcpy(cardnum, " ");
                        if ((strcmp(icar_type, "01") == 0) ||
                            (strcmp(icar_type, "02") == 0) ||
                            (strcmp(icar_type, "32") == 0) ||
                            (strcmp(icar_type, "34") == 0) ||
                            (strcmp(icar_type, "35") == 0))
                        {    
                           if (fcomp_p3)
                           fRtnCode = cm_get_serial_num_dwritten ("C1", "MQ3", " ",
                                                                  " " , s_dissue,
                                                                  sIcardyear, tmp_cardnum);
                           else
                           fRtnCode = cm_get_serial_num_dwritten ("C1", "MQ", " ",
                                                                  " " , s_dissue,
                                                                  sIcardyear, tmp_cardnum);                                       
                        }                                          
                        else if (fcomp_p3)
                           fRtnCode = cm_get_serial_num_dwritten ("C1", "CQ3", " ",
                                                                  " ", s_dissue,
                                                                  sIcardyear, tmp_cardnum);
                        else
                           fRtnCode = cm_get_serial_num_dwritten ("C1", "CQ", " ",
                                                                  " ", s_dissue,
                                                                  sIcardyear, tmp_cardnum);
                        if (fRtnCode !=0 )
                        {
                           $WHENEVER SQLERROR CONTINUE;
                           $ROLLBACK WORK;
                           return exitsub(reply,fRtnCode) ? fRtnCode : apiRC;
                        }
                        $WHENEVER SQLERROR GOTO errexit;

                        card_len = strlen(trim(tmp_cardnum));
                        strncpy(cardnum,tmp_cardnum,card_len - 1);
                        cardnum[card_len-1]= '\0';
                        strncpy(ichk_num,tmp_cardnum+card_len-1,1);
                        ichk_num[1] = '\0';

                        if (strncmp(checkno_flag,"N",1)==0)
                        {
                            strcpy(ichk_num," ");
                        }

                        printf("tmp_cardnum[%s]  cardnum[%s]  card_len[%d]  ichk_num[%s]\n",
                                tmp_cardnum,     cardnum,     card_len,     ichk_num);
                   }
                   else
                   {
                        /* car9808191 ���q�B���׾����j���ҵ��� */
                        if ((strcmp(icar_type, "01") == 0) ||
                            (strcmp(icar_type, "02") == 0) ||
                            (strcmp(icar_type, "32") == 0) ||
                            (strcmp(icar_type, "34") == 0) ||
                            (strcmp(icar_type, "35") == 0))
                            strcpy(sIbilling,"M");
                        else
                            strcpy(sIbilling,"Z");

                        strncat(sIbilling,ioffice,1);
                        sIbilling[2]='\0';
                        printf("#########sIbilling[%s]\n",sIbilling);

                        fRtnCode = cm_get_serial_num_dwritten ("C1",sIbilling ," " ,
                                                               " ", s_dissue,
                                                               sIcardyear, tmp_cardnum);
                        if (fRtnCode !=0 )
                        {
                           $WHENEVER SQLERROR CONTINUE;
                           $ROLLBACK WORK;
                           return exitsub(reply,fRtnCode) ? fRtnCode : apiRC;
                        }
                        $WHENEVER SQLERROR GOTO errexit;

                        /******�Ȯɬ馳�O�N������Ҹ����ˬd�X*********/
                        card_len = strlen(trim(tmp_cardnum));
                        strncpy(cardnum,tmp_cardnum,card_len - 1);
                        cardnum[card_len-1]= '\0';
                        strncpy(ichk_num,tmp_cardnum+card_len-1,1);
                        ichk_num[1] = '\0';

                        /*** �F�ثO�N�󤣥[�ˬd�X
                        if (strncmp(sIbilling,"ZH",2)==0)
                        ***/

                        if (strncmp(checkno_flag,"N",1)==0)
                            strcpy(ichk_num," ");

                        printf("tmp_cardnum[%s]  card_len[%d]\n",tmp_cardnum,card_len);
                   }

                   if (lFfirst == TRUE)
                   {
                      strcpy(icar_begin,cardnum);
                      lFfirst=FALSE;
                   }

                   printf("icard[%s],iofficer[%s],ioffice[%s],icardyear[%s],dissue[%s], \
                           iissue_branch[%s],icar_type[%s],qperiod[%s],fstatus[%s]\n",
                           cardnum,iofficer,ioffice,icardyear,dissue,issuebranch,
                           icar_type,qperiod,'0');

                   sprintf(stmt_buf,"UPDATE %s:compulsory_card \
                                        SET iofficer=?, ioffice=?, iquota=?, icardyear=?, \
                                            dissue=?, iissue_branch=?, \
                                            iissue_comp=?, icar_type=?, \
                                            qperiod=?, fstatus=? \
                                      WHERE icard=? ", FullDBName);
                   $PREPARE ins_comp_u FROM $stmt_buf;
                   $EXECUTE ins_comp_u
                      USING $iofficer, $ioffice, $sIquota, $icardyear, $dissue, $sIbranch_in,
                            $sIcomp_in, $icar_type, $qperiod, "7", $cardnum;

                   if (sqlca.sqlerrd[2] == 0)
                   {
                       sprintf(stmt_buf,"INSERT INTO %s:compulsory_card %s %s VALUES %s",
                                        FullDBName,
                                        "(icard,iofficer,ioffice,iquota,icardyear,dissue,",
                                        "iissue_branch,iissue_comp,icar_type,qperiod,fstatus,ichk_num)",
                                        "(?,?,?,?,?,?,?,?,?,?,'7',?)");
                       $PREPARE ins_comp_a FROM $stmt_buf;
                       $EXECUTE ins_comp_a
                          USING $cardnum,$iofficer,$ioffice,$sIquota,$icardyear,$dissue,
                                $sIbranch_in,$sIcomp_in,$icar_type,$qperiod,$ichk_num;

                       if (sqlca.sqlerrd[2] == 0)
                       {
                           $WHENEVER SQLERROR CONTINUE;
                           $ROLLBACK WORK;
                           return exitsub(reply,fRtnCode) ? fRtnCode : apiRC;
                       }
                       $WHENEVER SQLERROR GOTO errexit;
                   }
               }
               /* end of j loop */

               strcpy(icar_end, cardnum);
               strcpy(list[i].begin, icar_begin);
               strcpy(list[i].end,   icar_end);

               if (ioffice[0]!=' ' && ioffice[0]!='\0') /* �O�N�d */
               {
                  $UPDATE issued_card
                      SET (icard_begin,icard_end)=($icar_begin, $icar_end)
                    WHERE icardyear=$icardyear
                      AND dissue=$dissue
                      AND iofficer=$iofficer
                      AND ioffice=$ioffice
                      AND fcard_class="1"
                      AND icar_type=$icar_type
                      AND qperiod=$qperiod
                      AND qcard=$qcard
                      AND iissue_branch=$sIbranch_in
                      AND iissue_comp=$sIcomp_in;
               }
               else
               {      /* �@��d */
                  sprintf(stmt_buf,"UPDATE %s:issued_card %s %s %s %s %s %s",
                                   FullDBName,
                                   "  SET (icard_begin,icard_end) = (?,?)",
                                   "WHERE icardyear=? AND dissue=? AND iofficer=?",
                                   "  AND ioffice=? AND fcard_class='1' ",
                                   "  AND icar_type=? AND qperiod=? AND qcard=?",
                                   "  AND iissue_branch=?",
                                   "  AND iissue_comp=?");
                  $PREPARE upd_issued_card FROM $stmt_buf;
                  $EXECUTE upd_issued_card
                     USING $icar_begin,$icar_end,$icardyear,$dissue,$iofficer,
                           $ioffice,$icar_type,$qperiod,$qcard,$sIbranch_in,$sIcomp_in;
               }

               if (i==0)
               {
                  strcpy(first_icar_begin,icar_begin);
                  first_icar_begin[13]='\0';
               }

               if (i==(rows-1))
               {
                  strcpy(last_icar_end,icar_end);
                  last_icar_end[13]='\0';
               }
          } /* end of i loop */
     }
     else if( strcmp(sFcard_class,"2") == 0 )
     {
         /* �]�w�O�N�󵹸��Ѽ� */
         /*julia strncpy(sIbilling, ioffice, 3);*/
         strcpy(sIbilling, ioffice);
         strcpy(sIbilling, trim(sIbilling));
         /*sIbilling[3]='\0';*/

         /** ���N�I**/
         for (i=0; i<rows; i++)
         {
              printf("fcard_class [%d] \n", i );                           

              strcpy(icar_type,reclist[i].cartype);
              qperiod=reclist[i].qperiod;
              qcard=reclist[i].qcard;
              
printf("sIbilling[%s]\n",sIbilling);              
printf("car_type[%s],qperiod[%s],qcard[%s]\n",icar_type,qperiod,qcard);               

              $SELECT icard_begin, icard_end
                 INTO $wk_icard_begin, $wk_icard_end
                 FROM issued_card
                WHERE iofficer     = $iofficer
                  AND ioffice      = $ioffice
                  AND iissue_branch= $sIbranch_in
                  AND iissue_comp  = $sIcomp_in
                  AND icardyear    = $icardyear
                  AND dissue       = $dissue
                  AND fcard_class  = "2"
                  AND icar_type    = $icar_type
                  AND qperiod      = $qperiod
                  AND qcard        = $qcard;

              if (SQLCODE==SQLNOTFOUND)
              {
                   $WHENEVER SQLERROR CONTINUE;
                   $ROLLBACK WORK;
                   return exitsub(reply,M_CA_NISSUED_CARD)? M_CA_NISSUED_CARD: apiRC;
              }

              for (j=0; j<qcard; j++)
              {
                   fRtnCode = cm_get_serial_num_dwritten ("C1", sIbilling, " ",
                                                          " ",s_dissue ,
                                                          sIcardyear, tmp_cardnum);
                   if (fRtnCode !=0 )
                   {
                       $WHENEVER SQLERROR CONTINUE;
                       $ROLLBACK WORK;
                       return exitsub(reply,fRtnCode) ? fRtnCode : apiRC;
                   }
                   $WHENEVER SQLERROR GOTO errexit;



                   card_len = strlen(trim(tmp_cardnum));
                   
                   /* �M��N�g�쪺NA, NB�d�����[�ˬd�X  modify by sylvia 103.10.16 */
                   if ((strncmp(sIbilling,"NA",2)==0) || (strncmp(sIbilling,"NB",2)==0))
                   {
                     strcpy(cardnum,tmp_cardnum);
                     strcpy(ichk_num," ");
                   }
                   else
                   {  
                      strncpy(cardnum,tmp_cardnum,card_len - 1);
                      cardnum[card_len-1] = '\0';
                      strncpy(ichk_num,tmp_cardnum+card_len-1,1);
                      ichk_num[1]='\0';
                   }
            
                   printf("cardnum--->[%s] ichk_num--->[%s]\n",cardnum,ichk_num );

                   /*** ��a���[�ˬd�X
                   if (strncmp(sIbilling,"V",1)==0)
                     strcpy(ichk_num," ");

                        �F�ثO�N�󤣥[�ˬd�X
                   if (strncmp(sIbilling,"H",1)==0)
                      strcpy(ichk_num," ");

                        ���M�O�N�󤣥[�ˬd�X
                   if (strncmp(sIbilling,"L",1)==0)
                      strcpy(ichk_num," ");
                   ***/

                   if (strncmp(checkno_flag,"N",1)==0)
                      strcpy(ichk_num," ");

                   /******�e�^ñ�o�d���_��*****/
                   if (j == 0)
                      strcpy(icar_begin,cardnum);

                   printf("###### cardnum[%s]\n",cardnum);

                   sprintf(stmt_buf,"UPDATE card \
                                        SET iofficer=?, ioffice=?, iquota=?, icardyear=?, \
                                            dissue=?, iissue_branch=?, \
                                            iissue_comp=?, icar_type=?, \
                                            qperiod=?, fstatus=? \
                                      WHERE icard=? ");
                   printf("stmt_buf[%s]\n",stmt_buf);
                   $PREPARE ins_valu_u FROM $stmt_buf;
                   $EXECUTE ins_valu_u
                      USING $iofficer, $ioffice, $sIquota, $icardyear, $dissue, $sIbranch_in,
                            $sIcomp_in,$icar_type, $qperiod, "7", $cardnum;

                   if (sqlca.sqlerrd[2] == 0)
                   {
                       sprintf(stmt_buf,"INSERT INTO card \
                                         (icard,iofficer,ioffice,iquota,icardyear,dissue, \
                                          iissue_branch, iissue_comp, icar_type, \
                                          qperiod, fstatus,ichk_num) \
                                         VALUES (?,?,?,?,?,?,?,?,?,?,'7',?) ");
                       printf("stmt_buf[%s]\n",stmt_buf);
                       printf("[%s][%s][%s][%s][%s][%s][%s][%s][%s]\n",
                               cardnum,iofficer, ioffice, icardyear, dissue,
                               sIbranch_in, sIcomp_in, icar_type, ichk_num );
                       $PREPARE ins_valu_a FROM $stmt_buf;
                       $EXECUTE ins_valu_a
                          USING $cardnum,$iofficer,$ioffice,$sIquota,$icardyear,$dissue,
                                $sIbranch_in, $sIcomp_in,$icar_type,$qperiod,$ichk_num;

                       if (sqlca.sqlerrd[2] == 0)
                       {
                           $WHENEVER SQLERROR CONTINUE;
                           $ROLLBACK WORK;
                           return exitsub(reply,fRtnCode) ? fRtnCode : apiRC;
                       }
                       $WHENEVER SQLERROR GOTO errexit;
                   }
              }

              strcpy(icar_end, cardnum);
              strcpy(list[i].begin, icar_begin);
              strcpy(list[i].end,   icar_end);

              printf("list[%d].begin = [%s]\n",i, list[i].begin);
              printf("list[%d].end   = [%s]\n",i, list[i].end);

              $UPDATE issued_card
                  SET (icard_begin,icard_end)=($icar_begin, $icar_end)
                WHERE icardyear=$icardyear
                  AND dissue=$dissue
                  AND iofficer=$iofficer
                  AND ioffice=$ioffice
                  AND fcard_class="2"
                  AND qcard=$qcard
                  AND icar_type=$icar_type
                  AND qperiod=$qperiod
                  AND iissue_branch = $sIbranch_in
                  AND iissue_comp = $sIcomp_in;
         }/* end of i loop */
     }

     if ( num_count == rows )
     {
          $WHENEVER SQLERROR CONTINUE;
          $ROLLBACK WORK;
          return exitsub(reply,M_CA_NO_ASSIGNED) ? M_CA_NO_ASSIGNED : apiRC;
     }

     if( isExecute == 'Y')
     {
         $WHENEVER SQLERROR GOTO errexit;
         $COMMIT WORK;
         $WHENEVER SQLERROR CONTINUE;
     }
     else
     {
          $WHENEVER SQLERROR CONTINUE;
          $ROLLBACK WORK;
     }

     cm_buf_init(ReplyBuf);
     cm_buf_res_msg();
     cm_buf_res_count();
     cm_buf_put_msg(M_CM_OK);
     cm_buf_put_count(rows);

     for(i=0;i<rows;i++)
     {
        strcpy(tmp_code_1,reclist[i].cartype);

        printf("---->tmp_code_1[%s]\n",tmp_code_1);
        printf("===> card_begin[%s], card_end[%s]\n",list[i].begin,list[i].end);

        $SELECT ncode
           INTO $tmp_name_1
           FROM car_type
          WHERE fclass='1'
            AND icode=$tmp_code_1;

        cm_buf_put("%s %s",list[i].begin,list[i].end);
        cm_buf_put("%s",tmp_name_1);
     }

     tmp_len=cm_buf_len(ReplyBuf);
     if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==FALSE)
       return apiRC;
     else
       return api_OKComplete;

errexit:
      printf("sqlcode=%ld sqlerrm=%s\n",SQLCODE,sqlca.sqlerrm);
      MsgCode = SQLCODE;
      $WHENEVER SQLERROR CONTINUE;
      $ROLLBACK WORK;
      if (SQLCODE != 0) MsgCode = SQLCODE;
      return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

/*****************************************************************************/
long car201_R3(reply)
serverReply reply;
{
      $char DBName[5];

      $char iofficer[11],ioffice[7],icardyear[4],issuebranch[CA_POL_BRH_NUM];
      $char dissue[11], sIcomp_in[3], sIbranch_in[3];
      $char s_dissue[10],iissuer[11],icar_type[3],frec_print[2];
      $char icard_begin[21],icard_end[21];
      $long qcard,qperiod;

      $long avaisum,usedsum,cancelsum,losssum,expiresum,sum,sum1;
      $char fstatus[2];
      $char sFcard_class[2], sIssue_branch[5];
       char sTmpIbranch[3], sTmpIcomp[3];
       char sTmpTaipei[BRANCH_ID];
       char FullDBName[41];
       char CompanyName[COMPANY_CFULL];

      /* standard defined data */
      int tmp_len;
      long MsgCode, fRtnCode;
      /* end of standard data */

      /* self defined data */
      long count;
      $long rec_count;
       /* end of self data */

      cm_buf_get("%s",DBName);
      cm_buf_get("%s %s ",sFcard_class, sIssue_branch );      
      cm_buf_get("%s %s %s %s",iofficer,ioffice,icardyear,s_dissue);
      cm_buf_get("%s",issuebranch);
      strcpy(dissue,cm_to_infdate(s_dissue));

      $WHENEVER SQLERROR GOTO errexit;
      if (db_select(DBName) == False)
         return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

      fRtnCode = getHeadBranch(sTmpTaipei);
      if (fRtnCode < 0)
            return exitsub(reply, M_CM_READ_CONFIG_ERR ) ?
                   M_CM_READ_CONFIG_ERR : apiRC;

      if (strcmp(DBName, sTmpTaipei) !=0)
            return exitsub(reply,M_CA_BRANCH_NSAME) ? M_CA_BRANCH_NSAME :apiRC;

      strcpy(FullDBName, get_full_dbname(sTmpTaipei));
      if (FullDBName[0]=='\0')
            return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

      fRtnCode = getCompanyCFull(CompanyName);
      if (fRtnCode < 0)
         return exitsub(reply, fRtnCode) ?  fRtnCode : apiRC;

      /*�k�ݳ��*/
      fRtnCode = cm_get_unit_in("", DBName, iissuer, issuebranch, "C1", sIcomp_in,
                                sIbranch_in);
      if (fRtnCode != M_CM_OK)
         return exitsub(reply, fRtnCode) ?  fRtnCode : apiRC;
  
  
      printf("******** issuebranch[%s] dbname[%s]\n",issuebranch,FullDBName);

      $BEGIN WORK;

      avaisum=usedsum=cancelsum=losssum=expiresum=0;
      strcpy(icardyear,trim(icardyear));

      if( strcmp(sFcard_class,"1") == 0 )
      {
         $DECLARE comp_cur3 CURSOR FOR
           SELECT fstatus INTO $fstatus
             FROM compulsory_card
            WHERE icardyear=$icardyear
              AND iofficer=$iofficer
              AND ioffice=$ioffice;
         $OPEN comp_cur3;
         $FETCH comp_cur3;
         while (SQLCODE !=SQLNOTFOUND)
         {
             if (strcmp(fstatus,"0")==0) avaisum+=1;
             if (strcmp(fstatus,"1")==0) usedsum+=1;
             if (strcmp(fstatus,"3")==0) cancelsum+=1;
             if (strcmp(fstatus,"4")==0) losssum+=1;
             if (strcmp(fstatus,"2")==0) expiresum+=1;
             if (strcmp(fstatus,"5")==0) avaisum+=1;
             if (strcmp(fstatus,"6")==0) avaisum+=1;
             if (strcmp(fstatus,"7")==0) avaisum+=1;
             $FETCH comp_cur3;
         }
         $CLOSE comp_cur3;
      }
      else
      {
         $DECLARE valu_cur3 CURSOR FOR
           SELECT fstatus INTO $fstatus
             FROM card
            WHERE icardyear=$icardyear
              AND iofficer=$iofficer
              AND ioffice=$ioffice;
         $OPEN valu_cur3;
         $FETCH valu_cur3;
         while (SQLCODE !=SQLNOTFOUND)
         {
             if (strcmp(fstatus,"0")==0) avaisum+=1;
             if (strcmp(fstatus,"1")==0) usedsum+=1;
             if (strcmp(fstatus,"3")==0) cancelsum+=1;
             if (strcmp(fstatus,"4")==0) losssum+=1;
             if (strcmp(fstatus,"2")==0) expiresum+=1;
             if (strcmp(fstatus,"5")==0) avaisum+=1;
             if (strcmp(fstatus,"6")==0) avaisum+=1;
             if (strcmp(fstatus,"7")==0) avaisum+=1;
             $FETCH valu_cur3;
         }
         $CLOSE valu_cur3;
      }

      sum=avaisum+usedsum+cancelsum+losssum+expiresum;

      cm_buf_init(ReplyBuf);
      cm_buf_res_msg();
      cm_buf_res_count();
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put("%s %s %s %s %l %l %l %l %l %l",
                 iofficer,ioffice,icardyear,CompanyName,avaisum,usedsum,
                 cancelsum,losssum,expiresum,sum);
      cm_buf_put("%s",issuebranch);


      $DECLARE curc CURSOR FOR
        SELECT icard_begin,icard_end,icar_type,qperiod,qcard
          INTO  $icard_begin,$icard_end,$icar_type,$qperiod,$qcard
          FROM issued_card
         WHERE (icard_begin IS NOT NULL AND icard_begin!=" ")
           AND (icard_end IS NOT NULL AND icard_end!=" ")
           AND iofficer=$iofficer
           AND ioffice=$ioffice
           AND iissue_branch=$sIbranch_in
           AND iissue_comp=$sIcomp_in
           AND icardyear=$icardyear
           AND dissue=$dissue
           AND fcard_class=$sFcard_class

        FOR UPDATE OF frec_print;

      $OPEN curc;
      count=0;
      sum1=0;
      for (;;)
      {
         $FETCH curc;
         if (SQLCODE != 0) break;
         count++;

         $UPDATE issued_card
             SET (frec_print) = ("1")
           WHERE CURRENT OF curc;
         sum1+=qcard;
         cm_buf_put("%s %s %s %l %l",icard_begin,icard_end,icar_type,qperiod,qcard);
      }
      $CLOSE curc;

      if (count == 0)
      {
         $WHENEVER SQLERROR CONTINUE;
         $ROLLBACK WORK;
         return exitsub(reply,M_CA_NISSUED_CARD) ? M_CA_NISSUED_CARD : apiRC;
      }

      cm_buf_put_count(count);
      cm_buf_put("%l",sum1);

      printf("##### sum1[%ld]\n",sum1);

      $WHENEVER SQLERROR GOTO errexit;
      tmp_len = cm_buf_len(ReplyBuf);
      if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
      {
           $WHENEVER SQLERROR CONTINUE;
           $ROLLBACK WORK;
           return apiRC;
      }

      $WHENEVER SQLERROR GOTO errexit;
      $COMMIT WORK;
      return api_OKComplete;

errexit:
       MsgCode = SQLCODE;
       $WHENEVER SQLERROR CONTINUE;
       $ROLLBACK WORK;
       if (SQLCODE != 0) MsgCode = SQLCODE;
       return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
/*****************************************************************************/
long car201_R4(reply)   /*1070111014_SC4_car201�d��ñ������ܧ�  2019.03.11 by 071004   */
serverReply reply;  /*�ۭq�����϶�*/
{
     $char DBName[5];

     $char  iofficer[11],ioffice[7],icardyear[4],dissue[11];
     $char  sIquota[11];
     $char  s_dissue[10],iissuer[11],issuebranch[CA_POL_BRH_NUM],icar_type[3];
     $long  qcard,qperiod;
     $char  icar_begin[21],icar_end[21],cardnum[21],tmp_cardnum[21];
     $char  first_icar_begin[21],last_icar_end[21],ichk_num[2];
     $char  sIbranch_in[3], sIcomp_in[3];
     $char  sFcard_class[2], sIssue_branch[3],p3[2];
     char   sTmpTaipei[BRANCH_ID];
     $char  icard_title[10],icard_edit[21],icard_skip[21]; /*�d���~��+�r�y,�ۭq���d��,���L���d��*/
     $long  icardbgn_edit,icardend_edit,ksno_len; /*�ۭq���d���_�Ȭy��������,�ۭq���d�����Ȭy��������,�y�����r��*/
     $char  first_icard_edit[21],last_icard_edit[21],first_icard_skip[21],last_icard_skip[21];/*�ۭq���d���_�l,�ۭq���d���פ�,���L���d���_�l,���L���d���פ�*/
     $long  icard_ori_bgn;  /*��t�ΰt�o�d���_�l��*/

     
     int   card_len;
     int   count,i,j;

     /*--------------------------- */
     $char tmp_code_1[3],tmp_name_1[11];
     /*--------------------------- */

     /* standard defined data */
     int tmp_len;
     long MsgCode, fRtnCode, lFfirst;
     /* end of standard data */

     /* self defined data */
     long rows;
     char sIbilling[7];




     $char wk_icard_begin[21], wk_icard_end[21];
     int   num_count;
     $date max_drate=DATENULL;
     char  FullDBName[20], sIcardyear[YYYMMDD];
     $char stmt_buf[600];
     $char tmp_card[20];
     char  checkno_flag[3];
     /* end of self data */

     cm_buf_get("%s",DBName);
     cm_buf_get("%s %s %s ",   sFcard_class,checkno_flag,sIssue_branch );
     cm_buf_get("%s %s %s %s", iofficer,ioffice,icardyear,s_dissue);
     cm_buf_get("%s %s ",    iissuer,issuebranch);

     strcpy(dissue, cm_to_infdate(s_dissue));
     strcpy(icardyear,trim(icardyear));     
     strcpy(sIcardyear, icardyear);
     strcat(sIcardyear, "/01/01");

     printf(" [%s] [%s] [%s] [%s] [%s] [%s] \n", 
              iofficer,ioffice,icardyear,dissue,iissuer,issuebranch);

     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     fRtnCode = getHeadBranch(sTmpTaipei);
     if (fRtnCode < 0)
         return exitsub(reply, M_CM_READ_CONFIG_ERR ) ?
                M_CM_READ_CONFIG_ERR : apiRC;

     if (strcmp(DBName, sTmpTaipei) !=0)
         return exitsub(reply,M_CA_BRANCH_NSAME) ? M_CA_BRANCH_NSAME :apiRC;

     strcpy(FullDBName, get_full_dbname(sTmpTaipei));
     if (FullDBName[0]=='\0')
         return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;


     /*�k�ݳ��*/
     fRtnCode = cm_get_unit_in("", DBName, iissuer, issuebranch, "C1", sIcomp_in,
                               sIbranch_in);
     if (fRtnCode != M_CM_OK)
        return exitsub(reply, fRtnCode) ?  fRtnCode : apiRC;

     $SELECT iquota
        INTO :sIquota
        FROM officer
       WHERE iofficer = :iofficer;
     if (SQLCODE==SQLNOTFOUND)
     {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        return exitsub(reply,M_CMN_NOFFICER)? M_CMN_NOFFICER: apiRC;
     }

     printf("******** issuebranch[%s] dbname[%s]\n",issuebranch,FullDBName);


     
     cm_buf_get("%s %l %l",icar_type,&qperiod,&qcard);
     cm_buf_get("%s %l %l %l %l",icard_title,&icardbgn_edit,&icardend_edit,&ksno_len,&icard_ori_bgn);
     cm_buf_get("%s",p3);

     strcpy(icard_title,trim(icard_title));
     if(strcmp(p3,"4")==0) fcomp_p3=1;             
     num_count = 0;

     $BEGIN WORK;

     if( strcmp( sFcard_class , "1" ) == 0 ) /** �j���I**/
     {
          /*****************************************/
          /**           �ˮ֬O�_�wñ��            **/
          /*****************************************/
          if (!IsBlankNull(ioffice))
          {  
          	/* �O�N */
          	
                $SELECT icard_begin, icard_end
                   INTO $wk_icard_begin, $wk_icard_end
                   FROM issued_card
                  WHERE iofficer     = $iofficer
                    AND ioffice      = $ioffice
                    AND iissue_branch= $sIbranch_in
                    AND iissue_comp  = $sIcomp_in
                    AND icardyear    = $icardyear
                    AND dissue       = $dissue
                    AND fcard_class  = "1"
                    AND icar_type    = $icar_type
                    AND qperiod      = $qperiod
                    AND qcard        = $qcard;

                if (SQLCODE==SQLNOTFOUND)
                {
                      $WHENEVER SQLERROR CONTINUE;
                      $ROLLBACK WORK;
                      return exitsub(reply,M_CA_NISSUED_CARD1)? M_CA_NISSUED_CARD1: apiRC;
                }

          }
          else
          {
          	/*�@��*/
          
                sprintf(stmt_buf,"SELECT %s FROM %s:issued_card %s %s %s %s",
                                 "icard_begin,icard_end",
                                 FullDBName,
                                 "WHERE iofficer=? AND ioffice=? AND iissue_branch=? ",
                                 "  AND iissue_comp=? ",
                                 "  AND icardyear=? AND dissue=? AND fcard_class='1' ",
                                 "  AND icar_type=? AND qperiod=? AND qcard=? ");
                $PREPARE STMT_ISSUED FROM $stmt_buf;
                $DECLARE issued_card_cur1 CURSOR FOR STMT_ISSUED;
                $OPEN issued_card_cur1 USING $iofficer, $ioffice, $sIbranch_in, $sIcomp_in,
                                            $icardyear, $dissue,
                                            $icar_type, $qperiod, $qcard;
                $FETCH issued_card_cur1 INTO $wk_icard_begin,$wk_icard_end;

                if (SQLCODE==SQLNOTFOUND)
                {
                      $WHENEVER SQLERROR CONTINUE;
                      $ROLLBACK WORK;
                      return exitsub(reply,M_CA_NISSUED_CARD1)?M_CA_NISSUED_CARD1:apiRC;
                }

                
          }

          /*****************************************/
          /**        �ˮ֬O�_�w���ӥd���s�b       **/
          /*****************************************/
          
          printf("icard_title[%s] icardbgn_edit[%ld] icardend_edit[%ld] ksno_len[%ld]\n",icard_title,icardbgn_edit,icardend_edit,ksno_len);
          char tmp_zero[7];
          strcpy(tmp_zero,"");
          for(long x=icardbgn_edit;x<=icardend_edit;x++)  /*�̿�J�϶��@���@��Ū�X*/
          {
          	strcpy(icard_edit,ltoa(x));  
          	for(int y=0;y<ksno_len-strlen(icard_edit);y++)  /*��0*/
          	{
          	    	strcat(tmp_zero,"0");         		
          	}
          	
          	strcat(tmp_zero,icard_edit);
          	sprintf(icard_edit,"%s%s",icard_title,tmp_zero);
          	
          	printf("%s ",icard_edit);
          	
          	$SELECT icard
                   FROM compulsory_card
                  WHERE icard     = $icard_edit;
                if (SQLCODE!=SQLNOTFOUND)
                {
                    $WHENEVER SQLERROR CONTINUE;
                    $ROLLBACK WORK;
                    cm_buf_init(ReplyBuf);
                    cm_buf_put("%l %s ", M_CM_DUPDATA, icard_edit); 
                    tmp_len = cm_buf_len(ReplyBuf);
		    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
 						return M_CM_DUPDATA;
		    return M_CM_DUPDATA;
                                        
                }
          	strcpy(tmp_zero,"");
          	
          }
          

          /*****************************************/
          /**     insert�Jcompulsory_card         **/
          /*****************************************/
          
          /*���L���d��insert�Jcompulsory_card�ɡAfstatus�� "F" */
          /*���쪺�d��insert�Jcompulsory_card�ɡAfstatus�� "7" */
          
          printf("\n���L�i��:%ld�i\n",icardbgn_edit-icard_ori_bgn);
          
          printf("\n���L���d��:\n");
          for(long x=0;x<icardbgn_edit-icard_ori_bgn;x++)  /*���L�X�i�N���X����*/
          {
          	
                   if (IsBlankNull(ioffice)) /*�@��*/
                   {
                        strcpy(cardnum, " ");
                        if ((strcmp(icar_type, "01") == 0) ||
                            (strcmp(icar_type, "02") == 0) ||
                            (strcmp(icar_type, "32") == 0) ||
                            (strcmp(icar_type, "34") == 0) ||
                            (strcmp(icar_type, "35") == 0))
                        {    
                           if (fcomp_p3)
                           fRtnCode = cm_get_serial_num_dwritten ("C1", "MQ3", " ",
                                                                  " " , s_dissue,
                                                                  sIcardyear, tmp_cardnum);
                           else
                           fRtnCode = cm_get_serial_num_dwritten ("C1", "MQ", " ",
                                                                  " " , s_dissue,
                                                                  sIcardyear, tmp_cardnum);                                       
                        }                                          
                        else if (fcomp_p3)
                           fRtnCode = cm_get_serial_num_dwritten ("C1", "CQ3", " ",
                                                                  " ", s_dissue,
                                                                  sIcardyear, tmp_cardnum);
                        else
                           fRtnCode = cm_get_serial_num_dwritten ("C1", "CQ", " ",
                                                                  " ", s_dissue,
                                                                  sIcardyear, tmp_cardnum);
                        if (fRtnCode !=0 )
                        {
                           $WHENEVER SQLERROR CONTINUE;
                           $ROLLBACK WORK;
                           return exitsub(reply,fRtnCode) ? fRtnCode : apiRC;
                        }
                        $WHENEVER SQLERROR GOTO errexit;

                        card_len = strlen(trim(tmp_cardnum));
                        strncpy(cardnum,tmp_cardnum,card_len - 1);
                        cardnum[card_len-1]= '\0';
                        strncpy(ichk_num,tmp_cardnum+card_len-1,1);
                        ichk_num[1] = '\0';

                        if (strncmp(checkno_flag,"N",1)==0)
                        {
                            strcpy(ichk_num," ");
                        }

                        printf("tmp_cardnum[%s]  cardnum[%s]  card_len[%d]  ichk_num[%s]\n",
                                tmp_cardnum,     cardnum,     card_len,     ichk_num);
                   }
                   else
                   {
                        /* car9808191 ���q�B���׾����j���ҵ��� */
                        if ((strcmp(icar_type, "01") == 0) ||
                            (strcmp(icar_type, "02") == 0) ||
                            (strcmp(icar_type, "32") == 0) ||
                            (strcmp(icar_type, "34") == 0) ||
                            (strcmp(icar_type, "35") == 0))
                            strcpy(sIbilling,"M");
                        else
                            strcpy(sIbilling,"Z");

                        strncat(sIbilling,ioffice,1);
                        sIbilling[2]='\0';
                        printf("#########sIbilling[%s]\n",sIbilling);

                        fRtnCode = cm_get_serial_num_dwritten ("C1",sIbilling ," " ,
                                                               " ", s_dissue,
                                                               sIcardyear, tmp_cardnum);
                        if (fRtnCode !=0 )
                        {
                           $WHENEVER SQLERROR CONTINUE;
                           $ROLLBACK WORK;
                           return exitsub(reply,fRtnCode) ? fRtnCode : apiRC;
                        }
                        $WHENEVER SQLERROR GOTO errexit;

                        /******�Ȯɬ馳�O�N������Ҹ����ˬd�X*********/
                        card_len = strlen(trim(tmp_cardnum));
                        strncpy(cardnum,tmp_cardnum,card_len - 1);
                        cardnum[card_len-1]= '\0';
                        strncpy(ichk_num,tmp_cardnum+card_len-1,1);
                        ichk_num[1] = '\0';

                        /*** �F�ثO�N�󤣥[�ˬd�X
                        if (strncmp(sIbilling,"ZH",2)==0)
                        ***/

                        if (strncmp(checkno_flag,"N",1)==0)
                            strcpy(ichk_num," ");

                        printf("tmp_cardnum[%s]  card_len[%d]\n",tmp_cardnum,card_len);
                   }
          	
          	   printf("\n���L���d��[%s]  �ˬd�X[%s]\n",cardnum,ichk_num);
          	

          	   printf("icard[%s] iofficer[%s] ioffice[%s] iquota[%s] icardyear[%s] dissue[%s] iissue_branch[%s] iissue_comp[%s] icar_type[%s] qperiod[%ld] fstatus[%s] ichk_num[%s] \n"
          	           ,cardnum,iofficer,ioffice,sIquota,icardyear,dissue,sIbranch_in,sIcomp_in,icar_type,qperiod,"F",ichk_num);
          	
                   
                   sprintf(stmt_buf,"UPDATE %s:compulsory_card \
                                        SET iofficer=?, ioffice=?, iquota=?, icardyear=?, \
                                            dissue=?, iissue_branch=?, \
                                            iissue_comp=?, icar_type=?, \
                                            qperiod=?, fstatus=? \
                                      WHERE icard=? ", FullDBName);
                   $PREPARE ins_comp_u FROM $stmt_buf;
                   $EXECUTE ins_comp_u
                      USING $iofficer, $ioffice, $sIquota, $icardyear, $dissue, $sIbranch_in,
                            $sIcomp_in, $icar_type, $qperiod, "F", $cardnum;

                   if (sqlca.sqlerrd[2] == 0)
                   {
                      sprintf(stmt_buf,"INSERT INTO %s:compulsory_card %s %s VALUES %s",
                                       FullDBName,
                                       "(icard,iofficer,ioffice,iquota,icardyear,dissue,",
                                       "iissue_branch,iissue_comp,icar_type,qperiod,fstatus,ichk_num)",
                                       "(?,?,?,?,?,?,?,?,?,?,'F',?)");
                      $PREPARE ins_comp_a FROM $stmt_buf;
                      $EXECUTE ins_comp_a
                         USING $cardnum,$iofficer,$ioffice,$sIquota,$icardyear,$dissue,
                               $sIbranch_in,$sIcomp_in,$icar_type,$qperiod,$ichk_num;

                      if (sqlca.sqlerrd[2] == 0)
                      {
                            $WHENEVER SQLERROR CONTINUE;
                            $ROLLBACK WORK;
                            return exitsub(reply,fRtnCode) ? fRtnCode : apiRC;
                      }
                      $WHENEVER SQLERROR GOTO errexit;
                   }
                   
          	   if(x==0) /*���L���d���_�l*/
          	   {
          		strcpy(first_icard_skip,cardnum);          		
          	   }
           	   if(x==icardbgn_edit-icard_ori_bgn-1) /*���L���d���פ�*/
          	   {
          		strcpy(last_icard_skip,cardnum);        		
          	   }         	
          	   strcpy(tmp_zero,"");         	
          	
          	
          }  
          printf("\n");         
          printf("���쪺�d��:\n");
          for(long x=0;x<qcard;x++)  /*ñ��X�i�N���X����*/
          {

                   if (IsBlankNull(ioffice)) /*�@��*/
                   {
                        strcpy(cardnum, " ");
                        if ((strcmp(icar_type, "01") == 0) ||
                            (strcmp(icar_type, "02") == 0) ||
                            (strcmp(icar_type, "32") == 0) ||
                            (strcmp(icar_type, "34") == 0) ||
                            (strcmp(icar_type, "35") == 0))
                        {    
                           if (fcomp_p3)
                           fRtnCode = cm_get_serial_num_dwritten ("C1", "MQ3", " ",
                                                                  " " , s_dissue,
                                                                  sIcardyear, tmp_cardnum);
                           else
                           fRtnCode = cm_get_serial_num_dwritten ("C1", "MQ", " ",
                                                                  " " , s_dissue,
                                                                  sIcardyear, tmp_cardnum);                                       
                        }                                          
                        else if (fcomp_p3)
                           fRtnCode = cm_get_serial_num_dwritten ("C1", "CQ3", " ",
                                                                  " ", s_dissue,
                                                                  sIcardyear, tmp_cardnum);
                        else
                           fRtnCode = cm_get_serial_num_dwritten ("C1", "CQ", " ",
                                                                  " ", s_dissue,
                                                                  sIcardyear, tmp_cardnum);
                        if (fRtnCode !=0 )
                        {
                           $WHENEVER SQLERROR CONTINUE;
                           $ROLLBACK WORK;
                           return exitsub(reply,fRtnCode) ? fRtnCode : apiRC;
                        }
                        $WHENEVER SQLERROR GOTO errexit;

                        card_len = strlen(trim(tmp_cardnum));
                        strncpy(cardnum,tmp_cardnum,card_len - 1);
                        cardnum[card_len-1]= '\0';
                        strncpy(ichk_num,tmp_cardnum+card_len-1,1);
                        ichk_num[1] = '\0';

                        if (strncmp(checkno_flag,"N",1)==0)
                        {
                            strcpy(ichk_num," ");
                        }

                        printf("tmp_cardnum[%s]  cardnum[%s]  card_len[%d]  ichk_num[%s]\n",
                                tmp_cardnum,     cardnum,     card_len,     ichk_num);
                   }
                   else
                   {
                        /* car9808191 ���q�B���׾����j���ҵ��� */
                        if ((strcmp(icar_type, "01") == 0) ||
                            (strcmp(icar_type, "02") == 0) ||
                            (strcmp(icar_type, "32") == 0) ||
                            (strcmp(icar_type, "34") == 0) ||
                            (strcmp(icar_type, "35") == 0))
                            strcpy(sIbilling,"M");
                        else
                            strcpy(sIbilling,"Z");

                        strncat(sIbilling,ioffice,1);
                        sIbilling[2]='\0';
                        printf("#########sIbilling[%s]\n",sIbilling);

                        fRtnCode = cm_get_serial_num_dwritten ("C1",sIbilling ," " ,
                                                               " ", s_dissue,
                                                               sIcardyear, tmp_cardnum);
                        if (fRtnCode !=0 )
                        {
                           $WHENEVER SQLERROR CONTINUE;
                           $ROLLBACK WORK;
                           return exitsub(reply,fRtnCode) ? fRtnCode : apiRC;
                        }
                        $WHENEVER SQLERROR GOTO errexit;

                        /******�Ȯɬ馳�O�N������Ҹ����ˬd�X*********/
                        card_len = strlen(trim(tmp_cardnum));
                        strncpy(cardnum,tmp_cardnum,card_len - 1);
                        cardnum[card_len-1]= '\0';
                        strncpy(ichk_num,tmp_cardnum+card_len-1,1);
                        ichk_num[1] = '\0';

                        /*** �F�ثO�N�󤣥[�ˬd�X
                        if (strncmp(sIbilling,"ZH",2)==0)
                        ***/

                        if (strncmp(checkno_flag,"N",1)==0)
                            strcpy(ichk_num," ");

                        printf("tmp_cardnum[%s]  card_len[%d]\n",tmp_cardnum,card_len);
                   }
          	
          	   printf("\n���쪺�d��[%s]  �ˬd�X[%s]\n",cardnum,ichk_num);   
          	          	
          	   printf("icard[%s] iofficer[%s] ioffice[%s] iquota[%s] icardyear[%s] dissue[%s] iissue_branch[%s] iissue_comp[%s] icar_type[%s] qperiod[%ld] fstatus[%s] ichk_num[%s] \n"
          	          ,cardnum,iofficer,ioffice,sIquota,icardyear,dissue,sIbranch_in,sIcomp_in,icar_type,qperiod,"7",ichk_num);         	
                   
                   sprintf(stmt_buf,"UPDATE %s:compulsory_card \
                                        SET iofficer=?, ioffice=?, iquota=?, icardyear=?, \
                                            dissue=?, iissue_branch=?, \
                                            iissue_comp=?, icar_type=?, \
                                            qperiod=?, fstatus=? \
                                      WHERE icard=? ", FullDBName);
                   $PREPARE ins_comp_u FROM $stmt_buf;
                   $EXECUTE ins_comp_u
                      USING $iofficer, $ioffice, $sIquota, $icardyear, $dissue, $sIbranch_in,
                            $sIcomp_in, $icar_type, $qperiod, "7", $cardnum;

                   if (sqlca.sqlerrd[2] == 0)
                   {
                      sprintf(stmt_buf,"INSERT INTO %s:compulsory_card %s %s VALUES %s",
                                       FullDBName,
                                       "(icard,iofficer,ioffice,iquota,icardyear,dissue,",
                                       "iissue_branch,iissue_comp,icar_type,qperiod,fstatus,ichk_num)",
                                       "(?,?,?,?,?,?,?,?,?,?,'7',?)");
                      $PREPARE ins_comp_a FROM $stmt_buf;
                      $EXECUTE ins_comp_a
                         USING $cardnum,$iofficer,$ioffice,$sIquota,$icardyear,$dissue,
                               $sIbranch_in,$sIcomp_in,$icar_type,$qperiod,$ichk_num;

                      if (sqlca.sqlerrd[2] == 0)
                      {
                            $WHENEVER SQLERROR CONTINUE;
                            $ROLLBACK WORK;
                            return exitsub(reply,fRtnCode) ? fRtnCode : apiRC;
                      }
                      $WHENEVER SQLERROR GOTO errexit;
                   }
                   
          	   if(x==0) /*���쪺�d���_�l*/
          	   {
          		strcpy(first_icard_edit,cardnum);          		
          	   }
           	   if(x==qcard-1) /*���쪺�d���פ�*/
          	   {
          		strcpy(last_icard_edit,cardnum);          		          		
          	   }           	
          	
          	
           }           
           printf("\n"); 
          
          


          
          /*****************************************/
          /**      UPDATE issued_card��           **/
          /*****************************************/   
          /*���쪺UPDATE*/

          /*���L���d��*/
          printf("���L���d���_�l[%s]���L���d���פ�[%s]\n",first_icard_skip,last_icard_skip);
          /*if(first_icard_skip[0]!="\0" && first_icard_skip[0]!="\0")
          {
          	
              if (ioffice[0]!=' ' && ioffice[0]!='\0') 
              {
          	   �O�N�d
                  $INSERT INTO issued_card
                          (iofficer, ioffice, icardyear, dissue, iissue_branch, iissue_comp, fcard_class, icar_type, qperiod, icard_begin, icard_end, qcard, iissuer, fapp_print, frec_print) 
                   VALUES ($iofficer,$ioffice,$icardyear,$dissue,$sIbranch_in,$sIcomp_in,"1",$icar_type,$qperiod,$first_icard_skip,$last_icard_skip,$icardbgn_edit-$icard_ori_bgn,$iissuer,'0','0') ;
                  

              }
              else
              {    �@��d
                  $long z;
                  z=icardbgn_edit-icard_ori_bgn;
                  sprintf(stmt_buf,"INSERT INTO %s:issued_card %s %s ",
                                   FullDBName,
                                   "(iofficer, ioffice, icardyear, dissue, iissue_branch, iissue_comp, fcard_class, icar_type, qperiod, icard_begin, icard_end, qcard, iissuer, fapp_print, frec_print)",
                                   "VALUES (?,?,?,?,?,?,'1',?,?,?,?,?,?,'0','0')" );

                  $PREPARE insert_issued_card FROM $stmt_buf;
                  $EXECUTE insert_issued_card
                     USING $iofficer,$ioffice,$icardyear,$dissue,$sIbranch_in,$sIcomp_in,$icar_type,$qperiod,$first_icard_skip,$last_icard_skip,$z,$iissuer;  	
              }
             
          }*/
          /*���쪺�d��*/
          printf("���쪺�d���_�l[%s]���쪺�d���פ�[%s]\n",first_icard_edit,last_icard_edit);         
          if (ioffice[0]!=' ' && ioffice[0]!='\0') 
          {
          	  /*�O�N�d*/
                  $UPDATE issued_card
                      SET (icard_begin,icard_end)=($first_icard_edit, $last_icard_edit)
                    WHERE icardyear=$icardyear
                      AND dissue=$dissue
                      AND iofficer=$iofficer
                      AND ioffice=$ioffice
                      AND fcard_class="1"
                      AND icar_type=$icar_type
                      AND qperiod=$qperiod
                      AND qcard=$qcard
                      AND iissue_branch=$sIbranch_in
                      AND iissue_comp=$sIcomp_in;
          }
          else
          {       /*�@��d*/
                  sprintf(stmt_buf,"UPDATE %s:issued_card %s %s %s %s %s %s",
                                   FullDBName,
                                   "  SET (icard_begin,icard_end) = (?,?)",
                                   "WHERE icardyear=? AND dissue=? AND iofficer=?",
                                   "  AND ioffice=? AND fcard_class='1' ",
                                   "  AND icar_type=? AND qperiod=? AND qcard=?",
                                   "  AND iissue_branch=?",
                                   "  AND iissue_comp=?");
                  $PREPARE upd_issued_card FROM $stmt_buf;
                  $EXECUTE upd_issued_card
                     USING $first_icard_edit,$last_icard_edit,$icardyear,$dissue,$iofficer,
                           $ioffice,$icar_type,$qperiod,$qcard,$sIbranch_in,$sIcomp_in;
          }
          

          
     }
     else if( strcmp(sFcard_class,"2") == 0 )   /** ���N�I**/
     {

          strcpy(sIbilling, ioffice);
          strcpy(sIbilling, trim(sIbilling));

          /*****************************************/
          /**           �ˮ֬O�_�wñ��           **/
          /*****************************************/
          

          $SELECT icard_begin, icard_end
             INTO $wk_icard_begin, $wk_icard_end
             FROM issued_card
            WHERE iofficer     = $iofficer
              AND ioffice      = $ioffice
              AND iissue_branch= $sIbranch_in
              AND iissue_comp  = $sIcomp_in
              AND icardyear    = $icardyear
              AND dissue       = $dissue
              AND fcard_class  = "2"
              AND icar_type    = $icar_type
              AND qperiod      = $qperiod
              AND qcard        = $qcard;

          if (SQLCODE==SQLNOTFOUND)
          {
               $WHENEVER SQLERROR CONTINUE;
               $ROLLBACK WORK;
               return exitsub(reply,M_CA_NISSUED_CARD)? M_CA_NISSUED_CARD: apiRC;
          }
          

          /*****************************************/
          /**        �ˮ֬O�_�w���ӥd���s�b       **/
          /*****************************************/
          
          printf("icard_title[%s] icardbgn_edit[%ld] icardend_edit[%ld] ksno_len[%ld]\n",icard_title,icardbgn_edit,icardend_edit,ksno_len);
          char tmp_zero[7];
          strcpy(tmp_zero,"");
          for(long x=icardbgn_edit;x<=icardend_edit;x++)  /*�̿�J�϶��@���@��Ū�X*/
          {
          	strcpy(icard_edit,ltoa(x));  
          	for(int y=0;y<ksno_len-strlen(icard_edit);y++)  /*��0*/
          	{
          	    	strcat(tmp_zero,"0");
          		
          	}
          	
          	strcat(tmp_zero,icard_edit);
          	sprintf(icard_edit,"%s%s",icard_title,tmp_zero);
          	
          	printf("%s ",icard_edit);
          	
          	$SELECT icard
                   FROM card
                  WHERE icard     = $icard_edit;
                if (SQLCODE!=SQLNOTFOUND)
                {
                    $WHENEVER SQLERROR CONTINUE;
                    $ROLLBACK WORK;
                    cm_buf_init(ReplyBuf);
                    cm_buf_put("%l %s ", M_CM_DUPDATA, icard_edit); 
                    tmp_len = cm_buf_len(ReplyBuf);
		    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
 						return M_CM_DUPDATA;
		    return M_CM_DUPDATA;
                    
                    
                }
   	
          	strcpy(tmp_zero,"");
          	
           }  
           
          /*****************************************/
          /**           insert�Jcard              **/
          /*****************************************/          
          
          /*���L���d��insert�Jcard�ɡAfstatus�� "F" */
          /*���쪺�d��insert�Jcard�ɡAfstatus�� "7" */
          
          printf("\n���L�i��:%ld�i\n",icardbgn_edit-icard_ori_bgn);
          
          printf("\n���L���d��:\n");
          for(long x=0;x<icardbgn_edit-icard_ori_bgn;x++)  /*���L�X�i�N���X����*/
          {
          	
                   fRtnCode = cm_get_serial_num_dwritten ("C1", sIbilling, " ",
                                                          " ",s_dissue ,
                                                          sIcardyear, tmp_cardnum);
                   if (fRtnCode !=0 )
                   {
                       $WHENEVER SQLERROR CONTINUE;
                       $ROLLBACK WORK;
                       return exitsub(reply,fRtnCode) ? fRtnCode : apiRC;
                   }
                   $WHENEVER SQLERROR GOTO errexit;


                   card_len = strlen(trim(tmp_cardnum));
                   
                   /* �M��N�g�쪺NA, NB�d�����[�ˬd�X  modify by sylvia 103.10.16 */
                   if ((strncmp(sIbilling,"NA",2)==0) || (strncmp(sIbilling,"NB",2)==0))
                   {
                     strcpy(cardnum,tmp_cardnum);
                     strcpy(ichk_num," ");
                   }
                   else
                   {  
                      strncpy(cardnum,tmp_cardnum,card_len - 1);
                      cardnum[card_len-1] = '\0';
                      strncpy(ichk_num,tmp_cardnum+card_len-1,1);
                      ichk_num[1]='\0';
                   }
           

                   /*** ��a���[�ˬd�X
                   if (strncmp(sIbilling,"V",1)==0)
                     strcpy(ichk_num," ");

                        �F�ثO�N�󤣥[�ˬd�X
                   if (strncmp(sIbilling,"H",1)==0)
                      strcpy(ichk_num," ");

                        ���M�O�N�󤣥[�ˬd�X
                   if (strncmp(sIbilling,"L",1)==0)
                      strcpy(ichk_num," ");
                   ***/

                   if (strncmp(checkno_flag,"N",1)==0)
                      strcpy(ichk_num," ");

                   printf("\n���L���d��[%s]  �ˬd�X[%s]\n",cardnum,ichk_num);
                   
          	   printf("icard[%s] iofficer[%s] ioffice[%s] iquota[%s] icardyear[%s] dissue[%s] iissue_branch[%s] iissue_comp[%s] icar_type[%s] qperiod[%ld] fstatus[%s] ichk_num[%s] \n"
          	          ,cardnum,iofficer,ioffice,sIquota,icardyear,dissue,sIbranch_in,sIcomp_in,icar_type,qperiod,"F",ichk_num);           	
                   
                   sprintf(stmt_buf,"UPDATE card \
                                        SET iofficer=?, ioffice=?, iquota=?, icardyear=?, \
                                            dissue=?, iissue_branch=?, \
                                            iissue_comp=?, icar_type=?, \
                                            qperiod=?, fstatus=? \
                                      WHERE icard=? ");
                   printf("stmt_buf[%s]\n",stmt_buf);
                   $PREPARE ins_valu_u FROM $stmt_buf;
                   $EXECUTE ins_valu_u
                      USING $iofficer, $ioffice, $sIquota, $icardyear, $dissue, $sIbranch_in,
                            $sIcomp_in,$icar_type, $qperiod, "F", $cardnum;

                   if (sqlca.sqlerrd[2] == 0)
                   {
                       sprintf(stmt_buf,"INSERT INTO card \
                                         (icard,iofficer,ioffice,iquota,icardyear,dissue, \
                                          iissue_branch, iissue_comp, icar_type, \
                                          qperiod, fstatus,ichk_num) \
                                         VALUES (?,?,?,?,?,?,?,?,?,?,'F',?) ");
                       printf("stmt_buf[%s]\n",stmt_buf);
                       printf("[%s][%s][%s][%s][%s][%s][%s][%s][%s]\n",
                               cardnum,iofficer, ioffice, icardyear, dissue,
                               sIbranch_in, sIcomp_in, icar_type, ichk_num );
                       $PREPARE ins_valu_a FROM $stmt_buf;
                       $EXECUTE ins_valu_a
                          USING $cardnum,$iofficer,$ioffice,$sIquota,$icardyear,$dissue,
                                $sIbranch_in, $sIcomp_in,$icar_type,$qperiod,$ichk_num;

                       if (sqlca.sqlerrd[2] == 0)
                       {
                             $WHENEVER SQLERROR CONTINUE;
                             $ROLLBACK WORK;
                             return exitsub(reply,fRtnCode) ? fRtnCode : apiRC;
                       }
                       $WHENEVER SQLERROR GOTO errexit;
                   }
                    

          	   if(x==0) /*���L���d���_�l*/
          	   {
          		strcpy(first_icard_skip,cardnum);          		
          	   }
           	   if(x==icardbgn_edit-icard_ori_bgn-1) /*���L���d���פ�*/
          	   {
          		strcpy(last_icard_skip,cardnum);        		
          	   }        	
          	   strcpy(tmp_zero,"");
          	
          }  
          printf("\n");         
          printf("���쪺�d��:\n");
          for(long x=0;x<qcard;x++)  /*ñ��X�i�N���X����*/
          {
                   fRtnCode = cm_get_serial_num_dwritten ("C1", sIbilling, " ",
                                                          " ",s_dissue ,
                                                          sIcardyear, tmp_cardnum);
                   if (fRtnCode !=0 )
                   {
                       $WHENEVER SQLERROR CONTINUE;
                       $ROLLBACK WORK;
                       return exitsub(reply,fRtnCode) ? fRtnCode : apiRC;
                   }
                   $WHENEVER SQLERROR GOTO errexit;


                   card_len = strlen(trim(tmp_cardnum));
                   
                   /* �M��N�g�쪺NA, NB�d�����[�ˬd�X  modify by sylvia 103.10.16 */
                   if ((strncmp(sIbilling,"NA",2)==0) || (strncmp(sIbilling,"NB",2)==0))
                   {
                     strcpy(cardnum,tmp_cardnum);
                     strcpy(ichk_num," ");
                   }
                   else
                   {  
                      strncpy(cardnum,tmp_cardnum,card_len - 1);
                      cardnum[card_len-1] = '\0';
                      strncpy(ichk_num,tmp_cardnum+card_len-1,1);
                      ichk_num[1]='\0';
                   }
           

                   /*** ��a���[�ˬd�X
                   if (strncmp(sIbilling,"V",1)==0)
                     strcpy(ichk_num," ");

                        �F�ثO�N�󤣥[�ˬd�X
                   if (strncmp(sIbilling,"H",1)==0)
                      strcpy(ichk_num," ");

                        ���M�O�N�󤣥[�ˬd�X
                   if (strncmp(sIbilling,"L",1)==0)
                      strcpy(ichk_num," ");
                   ***/

                   if (strncmp(checkno_flag,"N",1)==0)
                      strcpy(ichk_num," ");

                   printf("\n���쪺�d��[%s]  �ˬd�X[%s]\n",cardnum,ichk_num);

          	   printf("icard[%s] iofficer[%s] ioffice[%s] iquota[%s] icardyear[%s] dissue[%s] iissue_branch[%s] iissue_comp[%s] icar_type[%s] qperiod[%ld] fstatus[%s] ichk_num[%s] \n"
          	          ,cardnum,iofficer,ioffice,sIquota,icardyear,dissue,sIbranch_in,sIcomp_in,icar_type,qperiod,"7",ichk_num);          	
                   
                   sprintf(stmt_buf,"UPDATE card \
                                        SET iofficer=?, ioffice=?, iquota=?, icardyear=?, \
                                            dissue=?, iissue_branch=?, \
                                            iissue_comp=?, icar_type=?, \
                                            qperiod=?, fstatus=? \
                                      WHERE icard=? ");
                   printf("stmt_buf[%s]\n",stmt_buf);
                   $PREPARE ins_valu_u FROM $stmt_buf;
                   $EXECUTE ins_valu_u
                      USING $iofficer, $ioffice, $sIquota, $icardyear, $dissue, $sIbranch_in,
                            $sIcomp_in,$icar_type, $qperiod, "7", $cardnum;

                   if (sqlca.sqlerrd[2] == 0)
                   {
                       sprintf(stmt_buf,"INSERT INTO card \
                                         (icard,iofficer,ioffice,iquota,icardyear,dissue, \
                                          iissue_branch, iissue_comp, icar_type, \
                                          qperiod, fstatus,ichk_num) \
                                         VALUES (?,?,?,?,?,?,?,?,?,?,'7',?) ");
                       printf("stmt_buf[%s]\n",stmt_buf);
                       printf("[%s][%s][%s][%s][%s][%s][%s][%s][%s]\n",
                               cardnum,iofficer, ioffice, icardyear, dissue,
                               sIbranch_in, sIcomp_in, icar_type, ichk_num );
                       $PREPARE ins_valu_a FROM $stmt_buf;
                       $EXECUTE ins_valu_a
                          USING $cardnum,$iofficer,$ioffice,$sIquota,$icardyear,$dissue,
                                $sIbranch_in, $sIcomp_in,$icar_type,$qperiod,$ichk_num;

                       if (sqlca.sqlerrd[2] == 0)
                       {
                             $WHENEVER SQLERROR CONTINUE;
                             $ROLLBACK WORK;
                             return exitsub(reply,fRtnCode) ? fRtnCode : apiRC;
                       }
                       $WHENEVER SQLERROR GOTO errexit;
                   }
                    
          	   if(x==0) /*���쪺�d���_�l*/
          	   {
          		strcpy(first_icard_edit,cardnum);
          		
          	   }
           	   if(x==qcard-1) /*���쪺�d���פ�*/
          	   {
          		strcpy(last_icard_edit,cardnum); 
          		
          	   }  
          	
          	
           }           
           printf("\n");      

          /*****************************************/
          /**       UPDATE issued_card��          **/
          /*****************************************/
          /*���쪺UPDATE*/
          /*���L���d��*/
          printf("���L���d���_�l[%s]���L���d���פ�[%s]\n",first_icard_skip,last_icard_skip);
          
          /*if(first_icard_skip[0]!="\0" && first_icard_skip[0]!="\0")
          {
                  $long z;
                  z=icardbgn_edit-icard_ori_bgn;          	                          
                   $INSERT INTO issued_card
                          (iofficer, ioffice, icardyear, dissue, iissue_branch, iissue_comp, fcard_class, icar_type, qperiod, icard_begin, icard_end, qcard, iissuer) 
                   VALUES ($iofficer,$ioffice,$icardyear,$dissue,$sIbranch_in,$sIcomp_in,"2",$icar_type,$qperiod,$first_icard_skip,$last_icard_skip,$z,$iissuer) ;
                   
          }*/
          /*���쪺�d��*/
          printf("���쪺�d���_�l[%s]���쪺�d���פ�[%s]\n",first_icard_edit,last_icard_edit);  
          
          $UPDATE issued_card
              SET (icard_begin,icard_end)=($first_icard_edit, $last_icard_edit)
            WHERE icardyear=$icardyear
              AND dissue=$dissue
              AND iofficer=$iofficer
              AND ioffice=$ioffice
              AND fcard_class="2"
              AND qcard=$qcard
              AND icar_type=$icar_type
              AND qperiod=$qperiod
              AND iissue_branch = $sIbranch_in
              AND iissue_comp = $sIcomp_in;
           
     }


     
     if( isExecute == 'Y')
     {
         $WHENEVER SQLERROR GOTO errexit;
         $COMMIT WORK;
         $WHENEVER SQLERROR CONTINUE;
     }
     else
     {
          $WHENEVER SQLERROR CONTINUE;
          $ROLLBACK WORK;
     }
     
     cm_buf_init(ReplyBuf);
     cm_buf_res_msg();
     cm_buf_res_count();
     cm_buf_put_msg(M_CM_OK);
     cm_buf_put_count(rows);

     /*
     for(i=0;i<rows;i++)
     {
        strcpy(tmp_code_1,reclist[i].cartype);

        printf("---->tmp_code_1[%s]\n",tmp_code_1);
        printf("===> card_begin[%s], card_end[%s]\n",list[i].begin,list[i].end);

        $SELECT ncode
           INTO $tmp_name_1
           FROM car_type
          WHERE fclass='1'
            AND icode=$tmp_code_1;

        cm_buf_put("%s %s",list[i].begin,list[i].end);
        cm_buf_put("%s",tmp_name_1);
     }
      */
     tmp_len=cm_buf_len(ReplyBuf);
     if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==FALSE)
       return apiRC;
     else
       return api_OKComplete;
     
errexit:
      printf("sqlcode=%ld sqlerrm=%s\n",SQLCODE,sqlca.sqlerrm);
      MsgCode = SQLCODE;
      $WHENEVER SQLERROR CONTINUE;
      $ROLLBACK WORK;
      if (SQLCODE != 0) MsgCode = SQLCODE;
      return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
/****************************************************************************/
long car201_single_query(reply)
serverReply reply;
{
      /* standard defined host variables */
      $char DBName[DBNAME];
      /* end of standard host var */

      /* table issued_card compulsory_premium */
      $char iofficer[11],ioffice[7],icardyear[4],dissue[11];
      $char s_dissue[10],iissuer[11],icar_type[3],issuebranch[CA_POL_BRH_NUM];
      $char sIcomp_in[BRANCH_ID], sIbranch_in[BRANCH_ID];
       char sTmpIbranch[BRANCH_ID], sTmpIcomp[BRANCH_ID];
       char sTmpTaipei[BRANCH_ID];
       char  FullDBName[20];
      $char icard_begin[21],icard_end[21];
      $char fapp_print[2],frec_print[2];
      $char sIcard_begin[20], sIcard_end[20];
      $char sFcard_class[2], sIissue_branch[4];
      $long qcard,qperiod;
      /* end of issued_card compulsory_premium */

      struct card_t {
             char icar_type[3];
             long qperiod;
             long qcard;
             char icard_begin[21];
             char icard_end[21];
             char fapp_print;
             char frec_print;
       } card[MAXROWITEMS];

      $long avaisum,usedsum,cancelsum,losssum,expiresum,sum;
      $char fstatus[2];
       long fRtnCode;

      /* standard defined data */
      char tmpbuf[4000];
      int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
      int i,total_count=0;

      cm_buf_get("%s",DBName);
      cm_buf_get("%s %s %s %s %s",iofficer,ioffice,icardyear,s_dissue,issuebranch);
      cm_buf_get("%s %s %s ",sIcard_begin, sIcard_end, sFcard_class );
      if (s_dissue[0]!='*')
          strcpy(dissue,cm_to_infdate(s_dissue));

      $WHENEVER SQLERROR GOTO errexit;

      if (db_select(DBName) == False)
         return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

      fRtnCode = getHeadBranch(sTmpTaipei);
      if (fRtnCode < 0)
            return exitsub(reply, M_CM_READ_CONFIG_ERR ) ?
                   M_CM_READ_CONFIG_ERR : apiRC;

      if (strcmp(DBName, sTmpTaipei) !=0)
            return exitsub(reply,M_CA_BRANCH_NSAME) ? M_CA_BRANCH_NSAME :apiRC;

      strcpy(FullDBName, get_full_dbname(sTmpTaipei));
      if (FullDBName[0]=='\0')
            return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

      /*�k�ݳ��*/
      fRtnCode = cm_get_unit_in("", DBName, iissuer, issuebranch, "C1", sIcomp_in,
                                sIbranch_in);
      if (fRtnCode != M_CM_OK)
         return exitsub(reply, fRtnCode) ?  fRtnCode : apiRC;


      printf("******** issuebranch[%s] dbname[%s]\n",issuebranch,FullDBName);
      printf("s_dissue[%s]\n",s_dissue);

      avaisum=usedsum=cancelsum=losssum=expiresum=sum=0;
      icar_type[0]=icard_begin[0]=icard_end[0]=fapp_print[0]=frec_print[0]=0;
      qperiod=qcard=0;
      strcpy(icardyear,trim(icardyear));

      if (s_dissue[0]=='*')
      {
        $DECLARE curd1 CURSOR FOR
          SELECT icar_type,qperiod,qcard,icard_begin,icard_end,
                 fapp_print,frec_print
            INTO $icar_type,$qperiod,$qcard,$icard_begin,$icard_end,
                 $fapp_print,$frec_print
            FROM issued_card
           WHERE iofficer MATCHES $iofficer
             AND ioffice MATCHES $ioffice
             AND iissue_branch MATCHES $sIbranch_in
             AND iissue_comp MATCHES $sIcomp_in
             AND icardyear MATCHES $icardyear
             AND icard_begin MATCHES $sIcard_begin
             AND icard_end MATCHES $sIcard_end
             AND fcard_class MATCHES $sFcard_class
           ORDER BY icar_type,qperiod,icard_begin;
      }
      else
      {
         /**johnny modify no match by iofficer,ioffice,iisue_branch,icardyear**/
        printf("[%s] , [%s] , [%s] , [%s] , [%s] , [%s] , [%s] , [%s]\n",
                iofficer , ioffice , sIbranch_in , sIcomp_in , icardyear , dissue ,
                sIcard_begin,  sIcard_end);

        $DECLARE curd2 CURSOR FOR
          SELECT icar_type,qperiod,qcard,icard_begin,icard_end,
                 fapp_print,frec_print
            INTO $icar_type,$qperiod,$qcard,$icard_begin,$icard_end,
                 $fapp_print,$frec_print
            FROM issued_card
           WHERE iofficer      = $iofficer
             AND ioffice       = $ioffice
             AND iissue_branch = $sIbranch_in
             AND iissue_comp   = $sIcomp_in
             AND icardyear     = $icardyear
             AND dissue = $dissue
             AND icard_begin MATCHES $sIcard_begin
             AND icard_end MATCHES $sIcard_end
             AND fcard_class MATCHES $sFcard_class
           ORDER BY icar_type,qperiod,icard_begin;
      }
      cm_buf_init(ReplyBuf);
      cm_buf_res_msg();
      cm_buf_res_count();
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put("%s %s %s %s %s %s",iofficer,ioffice,icardyear,s_dissue,issuebranch,sFcard_class);

      if (s_dissue[0]=='*')
          $OPEN curd1;
      else
          $OPEN curd2;
      count=0;
      for(i=0;;i++)
       {
         strcpy(icar_type,"");
         qperiod=0;
         qcard=0;
         strcpy(icard_begin,"");
         strcpy(icard_end,"");
         strcpy(fapp_print,"");
         strcpy(frec_print,"");

         if (s_dissue[0]=='*') $FETCH curd1;
         else $FETCH curd2;

         if (SQLCODE != 0) break;
         count++;

         strcpy(card[i].icar_type,icar_type);
         card[i].qperiod=qperiod;
         card[i].qcard=qcard;

         strcpy(card[i].icard_begin,icard_begin);
         strcpy(card[i].icard_end,icard_end);
         card[i].fapp_print=fapp_print[0];
         card[i].frec_print=frec_print[0];

       } /* for loop */

      if (s_dissue[0]=='*') $CLOSE curd1;
      else $CLOSE curd2;

      if (count > 0)   /* break out, at least one record is selected */
         cm_buf_put_count(count);
      else            /* break out, not any row is found */
       {
        return exitsub(reply,M_CA_NISSUED_CARD) ? M_CA_NISSUED_CARD : apiRC;
       }

      printf("===>  perpare put data <===\n");


      for (i=0;i<count;i++) {
             if (card[i].icard_begin[0] !=NULL && card[i].icard_begin[0]!=" ")
             cm_buf_put("%s %l %l %s %s ",
                     card[i].icar_type,card[i].qperiod,card[i].qcard,
                     card[i].icard_begin,card[i].icard_end );
      }
      for (i=0;i<count;i++) {
             if (card[i].icard_begin[0] ==NULL || card[i].icard_begin[0]==" ")
             cm_buf_put("%s %l %l %s %s ",
                     card[i].icar_type,card[i].qperiod,card[i].qcard,
                     card[i].icard_begin,card[i].icard_end );
      }

     printf("----icardyear[%s] iofficer[%s] ioffice[%s] issuebranch[%s]\n",
                 icardyear,iofficer,ioffice,issuebranch);

      /**johnny modify no match by iofficer,ioffice,iisue_branch,icardyear**/
      if( strcmp(sFcard_class,"1") == 0 )
      {
        $DECLARE comp_cur4 CURSOR FOR
          SELECT fstatus INTO $fstatus
            FROM compulsory_card
           WHERE icardyear     = $icardyear
             AND iofficer      = $iofficer
             AND ioffice       = $ioffice
             AND iissue_branch = $sIbranch_in
             AND iissue_comp   = $sIcomp_in;
        $OPEN comp_cur4;
        $FETCH comp_cur4;
        while (SQLCODE !=SQLNOTFOUND) {
             if (strcmp(fstatus,"0")==0) avaisum+=1;
             if (strcmp(fstatus,"1")==0) usedsum+=1;
             if (strcmp(fstatus,"3")==0) cancelsum+=1;
             if (strcmp(fstatus,"4")==0) losssum+=1;
             if (strcmp(fstatus,"2")==0) expiresum+=1;
             if (strcmp(fstatus,"5")==0) avaisum+=1;
             if (strcmp(fstatus,"6")==0) avaisum+=1;
             if (strcmp(fstatus,"7")==0) avaisum+=1;
         $FETCH comp_cur4;
        }
        $CLOSE comp_cur4;
      }
      else
      {
        $DECLARE valu_cur4 CURSOR for
          SELECT fstatus INTO $fstatus
            FROM card
           WHERE icardyear     = $icardyear
             AND iofficer      = $iofficer
             AND ioffice       = $ioffice
             AND iissue_branch = $sIbranch_in
             AND iissue_comp   = $sIcomp_in;
        $OPEN valu_cur4;
        $FETCH valu_cur4;
        while (SQLCODE !=SQLNOTFOUND) {
             if (strcmp(fstatus,"0")==0) avaisum+=1;
             if (strcmp(fstatus,"1")==0) usedsum+=1;
             if (strcmp(fstatus,"3")==0) cancelsum+=1;
             if (strcmp(fstatus,"4")==0) losssum+=1;
             if (strcmp(fstatus,"2")==0) expiresum+=1;
             if (strcmp(fstatus,"5")==0) avaisum+=1;
             if (strcmp(fstatus,"6")==0) avaisum+=1;
             if (strcmp(fstatus,"7")==0) avaisum+=1;             
         $FETCH valu_cur4;
        }
        $CLOSE valu_cur4;             
      }
        sum=avaisum+usedsum+cancelsum+losssum+expiresum;

      cm_buf_put("%l %l %l %l %l %l",
                 avaisum,usedsum,cancelsum,losssum,expiresum,sum);

      tmp_len = cm_buf_len(ReplyBuf);
      if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
                     return apiRC;
      else
                     return api_OKComplete;

      errexit:
       printf("SQLCODE=%d errm=%s\n",sqlca.sqlcode,sqlca.sqlerrm);
       return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/***********************************************************************/
/* �����D.. */
long car201_multiple_query_old(reply) 
serverReply reply;
{
 $char DBName[5];

 $char iofficer[11],ioffice[7],icardyear[4],issuebranch[CA_POL_BRH_NUM];
 $char sIbranch_in[BRANCH_ID], sIcomp_in[BRANCH_ID];
  char sTmpIbranch[BRANCH_ID], sTmpIcomp[BRANCH_ID];
  char sTmpTaipei[BRANCH_ID];
  char  FullDBName[20];
 $char dissue[11],s_dissue[10],iissuer[11],icar_type[3];
 $char key_iofficer[11],key_ioffice[7],key_icardyear[34];
 $long diss;
 $char key_dissure[11];
 $char icard_begin[21],icard_end[21];
 $char fapp_print[2],frec_print[2];
 $long qcard,qperiod;
 $char iissue_branch[3],sFcard_class[2];
 $char sIcard_begin[21], sIcard_end[21];

 struct card_t {
        char icar_type[3];
        long qperiod;
        long qcard;
        char icard_begin[21];
        char icard_end[21];
        char fapp_print;
        char frec_print;
  } card[MAXROWITEMS];
        
 $long avaisum,usedsum,cancelsum,losssum,expiresum,sum;
  long fRtnCode;

 /* standard defined data */
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0; 
 /* end of standard data */

 /* self defined data */
 /* end of self data */

 cm_buf_get("%s",DBName);
 cm_buf_get("%s %s %s %s %s",
            key_iofficer, key_ioffice, key_icardyear, s_dissue, issuebranch);
 if (s_dissue[0]!='*')
     strcpy(key_dissure,cm_to_infdate(s_dissue));

 $WHENEVER SQLERROR GOTO errexit;
 if (db_select(DBName) == False) 
    return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

printf("******** issuebranch[%s] dbname[%s]\n",issuebranch,FullDBName);

 strcpy(key_icardyear,trim(key_icardyear));

 if (key_ioffice[0] == '*') 
 {
  if (s_dissue[0]=='*') 
  {
   $DECLARE mcurd11 CURSOR FOR
     SELECT unique iofficer,ioffice,icardyear,dissue,iissue_branch,
            iissue_comp,icard_begin,icard_end,fcard_class
       INTO $iofficer,$ioffice,$icardyear,$diss,$sIbranch_in,
            $sIcomp_in,$sIcard_begin,$sIcard_end,$sFcard_class
       FROM issued_card
      WHERE iofficer MATCHES $key_iofficer
        AND icardyear MATCHES $key_icardyear
      ORDER BY iofficer;
   $OPEN mcurd11;
  }
 else 
  {
   $DECLARE mcurd21 CURSOR FOR
     SELECT unique iofficer,ioffice,icardyear,dissue,iissue_branch,
            iissue_comp,icard_begin,icard_end,fcard_class
       INTO $iofficer,$ioffice,$icardyear,$diss,$sIbranch_in,
            $sIcomp_in,$sIcard_begin,$sIcard_end,$sFcard_class
       FROM issued_card
      WHERE iofficer MATCHES $key_iofficer 
        AND icardyear MATCHES $key_icardyear 
        AND dissue = $key_dissure
      ORDER BY iofficer;
   $OPEN mcurd21;
  }
 }   
 else
 {
  if (s_dissue[0]=='*')
  {
   $DECLARE mcurd31 CURSOR FOR
     SELECT unique iofficer,ioffice,icardyear,dissue,iissue_branch,
            iissue_comp,icard_begin,icard_end,fcard_class
       INTO $iofficer,$ioffice,$icardyear,$diss,$sIbranch_in,$sIcomp_in,
            $sIcard_begin,$sIcard_end,$sFcard_class
       FROM issued_card
      WHERE iofficer matches $key_iofficer
        AND ioffice matches $key_ioffice
        AND icardyear matches $key_icardyear
      ORDER BY iofficer;
   $OPEN mcurd31;
  }
 else 
  {
   $DECLARE mcurd41 CURSOR FOR
     SELECT unique iofficer,ioffice,icardyear,dissue,iissue_branch,
            iissue_comp,icard_begin,icard_end,fcard_class
       INTO $iofficer,$ioffice,$icardyear,$diss,$sIbranch_in,$sIcomp_in,
            $sIcard_begin,$sIcard_end,$sFcard_class
       FROM issued_card
      WHERE iofficer MATCHES $key_iofficer
        AND ioffice MATCHES $key_ioffice 
        AND icardyear MATCHES $key_icardyear 
        AND dissue = $key_dissure 
      ORDER BY iofficer;
   $OPEN mcurd41;
  }   
 }

 cm_buf_init(ReplyBuf);
 cm_buf_res_msg();
 cm_buf_res_count();
 cm_buf_put_msg(M_CM_OK);

 count=0;
 for(;;)
  {
   if(key_ioffice[0] == '*')
   {
    if (s_dissue[0]=='*')
        $FETCH mcurd11;
    else
        $FETCH mcurd21;
   }
   else
   {
    if (s_dissue[0]=='*')
        $FETCH mcurd31;
    else
        $FETCH mcurd41;
   }
    if (SQLCODE != 0) break;
    strcpy(issuebranch, rtrim(sIbranch_in));
    strcat(issuebranch, rtrim(get_upcomp(sIcomp_in, USE_BRANCH_ID,
                                         USE_SHORT_BRANCH_ID)));
    cm_buf_put("%s %s %s %s %s %s %s %s",
               iofficer,ioffice,icardyear,cm_cdate_str_100(diss),issuebranch,
               sIcard_begin, sIcard_end, sFcard_class );
    count++;
  } /* for loop */


 if(key_ioffice[0] == '*')
 {
  if (s_dissue[0]=='*') 
     $CLOSE mcurd11;
  else
     $CLOSE mcurd21;
 }
 else
 {
  if (s_dissue[0]=='*') 
     $CLOSE mcurd31;
  else
     $CLOSE mcurd41;
 }


 if (count==0) {   
    return exitsub(reply,M_CA_NCARD1) ? M_CA_NCARD1 : apiRC;
 }

 cm_buf_put_count(count);
 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
     return apiRC;
 else     
     return api_OKComplete;

errexit:
  printf("SQLCODE=%d errm=%s\n",sqlca.sqlcode,sqlca.sqlerrm);
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*****************************************************************************/
long car201_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
    /* standard defined host variables */
    $char DBName[5];
    /* end of standard host var */

    /* table issued_card compulsory_premium */
    $char iofficer[11],ioffice[7],icardyear[4],dissue[11];
    $char issuebranch[CA_POL_BRH_NUM], old_issuebranch[BRANCH_ID];
    $char sIbranch_in[BRANCH_ID], sIcomp_in[BRANCH_ID];
    $char old_sIbranch_in[BRANCH_ID], old_sIcomp_in[BRANCH_ID];
     char sTmpIbranch[BRANCH_ID], sTmpIcomp[BRANCH_ID];
     char old_sTmpIbranch[BRANCH_ID], old_sTmpIcomp[BRANCH_ID];
     char sTmpTaipei[BRANCH_ID];
     char FullDBName[20];
    $char s_dissue[10],iissuer[11],icar_type[3],old_icar_type[3];
    $char old_iofficer[11],old_ioffice[7],old_icardyear[4];
    $char old_dissue[21],old_s_dissue[21];
    $char icard_begin[21],icard_end[21],tmpcard[4];
    $char fapp_print[2],frec_print[2];
    $long old_qcard,qcard,old_qperiod,qperiod;
    $char ialter[11];
    $char old_f_class[2], old_i_branch[4];
    $char old_c_begin[20],old_c_end[20];
    $char fcard_class[2],iissue_branch[4];
    /* end of issued_card compulsory_premium */

    $char tmpiofficer[11],icard[3],icard_abbr[2];
    $long dalter;
    struct card_t {
           char icar_type[3];
           long qperiod;
           long qcard;
           char icard_begin[21];
           char icard_end[21];
           char fapp_print;
           char frec_print;
     } card[MAXROWITEMS];
        
    $long avaisum,usedsum,cancelsum,losssum,expiresum,sum;
    $char fstatus[2];
 
    /* standard defined data */
    char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
     int tmp_len,raw_len,j;
    long dummy=0;
    long dummy_cnt=0;
    long MsgCode, fRtnCode;
    /* end of standard data */

    /* self defined data */
    char  flag;
    long  rows;
    long  count,i;
    char  tmpchar[4];
    $date max_drate=DATENULL;
    /* end of self data */

    comm = (char *) command;
    cm_buf_init(command);
    cm_buf_get("%c %s",&option,DBName);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    /* compare old record and current record, if the record has not been changed  
       since last request, update or delete the record, otherwise return errmsg
       to client side */

    /* get old record info from command buffer */ 

    memcpy(&raw_len,&comm[com_len],sizeof(int));   
    pos = &comm[com_len+sizeof(int)];

    raw_ptr = malloc(raw_len);
    if (raw_ptr != (char*)0)  
       memcpy(raw_ptr,pos,raw_len);
    else
    {
       if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */ 
          return M_CM_NOT_MALLOC;
       else  
          return apiRC;
    }
    
    cm_buf_init(raw_ptr);          /* get index key from old record */
    cm_buf_get("%l",&dummy);
    cm_buf_get("%l",&dummy_cnt);
    cm_buf_get("%s %s %s %s",old_iofficer,old_ioffice,old_icardyear,old_s_dissue);
    cm_buf_get("%s %s ",old_issuebranch,old_f_class);
    
    fRtnCode = getHeadBranch(sTmpTaipei);
    if (fRtnCode < 0) 
       return exitsub(reply, M_CM_READ_CONFIG_ERR ) ?  
              M_CM_READ_CONFIG_ERR : apiRC;

    if (strcmp(DBName, sTmpTaipei) !=0)
       return exitsub(reply,M_CA_BRANCH_NSAME) ? M_CA_BRANCH_NSAME :apiRC;
     
    strcpy(FullDBName, get_full_dbname(sTmpTaipei));
    if (FullDBName[0]=='\0') 
       return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    /*�k�ݳ��*/
    fRtnCode = cm_get_unit_in("", DBName, iissuer, old_issuebranch, "C1",
                              old_sIcomp_in, old_sIbranch_in);
    if (fRtnCode != M_CM_OK) return exitsub(reply, fRtnCode) ? fRtnCode : apiRC;
       strncpy(sTmpIbranch, old_issuebranch , 2);

    printf("******** issuebranch[%s] dbname[%s]\n",old_issuebranch,FullDBName);
    printf("******** sIbranch_in[%s] sIcomp[%s]\n",old_sIbranch_in,old_sIcomp_in);
    strcpy(old_dissue,cm_to_infdate(old_s_dissue));

    avaisum=usedsum=cancelsum=losssum=expiresum=sum=0;
    strcpy(old_icardyear,trim(old_icardyear));

    $BEGIN WORK;
    $DECLARE  cure CURSOR FOR
    SELECT  icar_type,qperiod,qcard,icard_begin,icard_end,
            fapp_print,frec_print
      FROM  issued_card
     WHERE  iofficer =$old_iofficer  AND ioffice=$old_ioffice
       AND  icardyear=$old_icardyear AND dissue =$old_dissue 
       AND  iissue_branch=$old_sIbranch_in
       AND  iissue_comp=$old_sIcomp_in
       AND  fcard_class=$old_f_class
     ORDER  BY icar_type,qperiod,icard_begin;
    
    cm_buf_init(cur_buf);
    cm_buf_res_msg();
    cm_buf_res_count();
    cm_buf_put_msg(dummy);   
    cm_buf_put("%s %s %s %s",old_iofficer,old_ioffice,old_icardyear,old_s_dissue);
    cm_buf_put("%s %s ",old_issuebranch,old_f_class);

    $OPEN cure;
    count=0;
    for(i=0;;i++)
    {
        strcpy(icar_type,"");
        qperiod=0;
        qcard=0;
        strcpy(icard_begin,"");
        strcpy(icard_end,"");
        strcpy(fapp_print,"");
        strcpy(frec_print,"");

        $FETCH cure
               INTO  $icar_type,$qperiod,$qcard,$icard_begin,$icard_end,
                     $fapp_print,$frec_print;
        if (SQLCODE != 0) break;

        count++;    printf("count++\n");
        strcpy(card[i].icar_type,icar_type);
        card[i].qperiod     =qperiod;
        card[i].qcard       =qcard;
        strcpy(card[i].icard_begin,icard_begin);
        strcpy(card[i].icard_end,icard_end);
        card[i].fapp_print=fapp_print[0];
        card[i].frec_print=frec_print[0];
    }
    $CLOSE cure;

    for (i=0;i<count;i++) 
    {
        if (card[i].icard_begin[0] !=NULL && card[i].icard_begin[0]!=" ")
        cm_buf_put("%s %l %l %s %s ",
                    card[i].icar_type,card[i].qperiod,card[i].qcard,
                    card[i].icard_begin,card[i].icard_end );
    }

    for (i=0;i<count;i++) 
    {
        if (card[i].icard_begin[0] ==NULL || card[i].icard_begin[0]==" ")
        cm_buf_put("%s %l %l %s %s ",
                    card[i].icar_type,card[i].qperiod,card[i].qcard,
                    card[i].icard_begin,card[i].icard_end );
    }
        
    if (count > 0)   /* break out, at least one record is selected */
        cm_buf_put_count(count);
    else            /* break out, not any row is found */
    {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        return exitsub(reply,M_CM_NOT_FOUND) ? M_CM_NOT_FOUND : apiRC;
    }

    $WHENEVER SQLERROR GOTO errexit;
 
    if( strcmp(old_f_class,"1") == 0 )
    {
       $DECLARE comp_cur5 CURSOR FOR
         SELECT fstatus INTO $fstatus
           FROM compulsory_card
          WHERE icardyear=$old_icardyear
            AND iofficer=$old_iofficer
            AND ioffice=$old_ioffice
            AND iissue_branch=$old_sIbranch_in
            AND iissue_comp=$old_sIcomp_in;
       $OPEN comp_cur5;
       $FETCH comp_cur5;
       while (SQLCODE !=SQLNOTFOUND) 
       {
           if (strcmp(fstatus,"0")==0)  avaisum+=1;
           if (strcmp(fstatus,"1")==0)  usedsum+=1;
           if (strcmp(fstatus,"3")==0)  cancelsum+=1;
           if (strcmp(fstatus,"4")==0)  losssum+=1;
           if (strcmp(fstatus,"2")==0)  expiresum+=1;    
           if (strcmp(fstatus,"5")==0)  avaisum+=1;
           if (strcmp(fstatus,"6")==0)  avaisum+=1;
           if (strcmp(fstatus,"7")==0)  avaisum+=1;
           $FETCH comp_cur5;
       }
       $CLOSE comp_cur5;
    }
    else
    {
       $DECLARE valu_cur5 CURSOR FOR
         SELECT fstatus INTO $fstatus
           FROM card
          WHERE icardyear=$old_icardyear
            AND iofficer=$old_iofficer
            AND ioffice=$old_ioffice
            AND iissue_branch=$old_sIbranch_in
            AND iissue_comp=$old_sIcomp_in;
       $OPEN valu_cur5;
       $FETCH valu_cur5;
       while (SQLCODE !=SQLNOTFOUND) 
       {
           if (strcmp(fstatus,"0")==0)  avaisum+=1;
           if (strcmp(fstatus,"1")==0)  usedsum+=1;
           if (strcmp(fstatus,"3")==0)  cancelsum+=1;
           if (strcmp(fstatus,"4")==0)  losssum+=1;
           if (strcmp(fstatus,"2")==0)  expiresum+=1;    
           if (strcmp(fstatus,"5")==0)  avaisum+=1;
           if (strcmp(fstatus,"6")==0)  avaisum+=1;
           if (strcmp(fstatus,"7")==0)  avaisum+=1;
           $FETCH valu_cur5;
       }
       $CLOSE valu_cur5;
    }

    sum=avaisum+usedsum+cancelsum+losssum+expiresum;
    
    cm_buf_put("%l %l %l %l %l %l",
                avaisum,usedsum,cancelsum,losssum,expiresum,sum);
                   
    write(1, cur_buf, raw_len);
    printf("\n");
    write(1, raw_ptr, raw_len);
    printf("\n");
    if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
    {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        return exitsub(reply,M_CM_NOT_EQUAL) ? M_CM_NOT_EQUAL : apiRC;
    }

    $WHENEVER SQLERROR GOTO errexit;

    /* equal, then exec DB operation */
    printf("iofficer[%s]\n",old_iofficer);
    printf("ioffice[%s]\n",old_ioffice);
    printf("icardyear[%s]\n",old_icardyear);
    printf("dissue[%s]\n",old_dissue);

    /***�w�������i���ΧR��***/
    $DECLARE dcurf CURSOR FOR 
      SELECT iofficer
        INTO $tmpiofficer
        FROM issued_card
       WHERE iofficer=$old_iofficer AND ioffice=$old_ioffice
         AND iissue_branch=$old_sIbranch_in
         AND iissue_comp=$old_sIcomp_in
         AND icardyear=$old_icardyear 
         AND dissue=$old_dissue AND fcard_class=$old_f_class
         AND icard_begin <> " " AND icard_end <> " ";
    $OPEN dcurf;
    count=0;
    for(;;) 
    {
        $FETCH dcurf;
            if (SQLCODE == SQLNOTFOUND) break;
            count++;
    }
    $CLOSE dcurf;
    if (count>0) 
    {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        return exitsub(reply,M_CA_CARD_NOT_NULL) ? M_CA_CARD_NOT_NULL : apiRC;
    }

    if ( option == 'D' )
    {
        printf("===> into delete\n");
        $WHENEVER SQLERROR GOTO errexit;

        $DELETE FROM issued_card
          WHERE iofficer=$old_iofficer 
            AND ioffice=$old_ioffice 
            AND iissue_branch=$old_sIbranch_in
            AND iissue_comp=$old_sIcomp_in
            AND icardyear=$old_icardyear 
            AND dissue=$old_dissue 
            AND fcard_class=$old_f_class;

        cm_buf_init(ReplyBuf);
        cm_buf_put("%l",M_CM_OK);
        tmp_len = cm_buf_len(ReplyBuf);
        if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
        {
             $WHENEVER SQLERROR CONTINUE;
             $ROLLBACK WORK;
             return apiRC;
        }  

        $WHENEVER SQLERROR GOTO errexit;
        $COMMIT WORK;
        return api_OKComplete;
    }
    else if (option == 'U')
    {
        printf("===> into update \n");
        cm_buf_init(command);
        cm_buf_get("%c %s",&option,DBName);
        cm_buf_get("%s %s",fcard_class, iissue_branch);
        cm_buf_get("%s %s %s %s %s %s %l",iofficer,ioffice,icardyear,
                    s_dissue,issuebranch,ialter,&rows);
   
        strcpy(dissue,cm_to_infdate(s_dissue));
        strcpy(icardyear,trim(icardyear));

        fRtnCode = getHeadBranch(sTmpTaipei);
        if (fRtnCode < 0) 
             return exitsub(reply, M_CM_READ_CONFIG_ERR ) ?  
                            M_CM_READ_CONFIG_ERR : apiRC;

        if (strcmp(DBName, sTmpTaipei) !=0)
             return exitsub(reply,M_CA_BRANCH_NSAME) ? M_CA_BRANCH_NSAME :apiRC;
     
        strcpy(FullDBName, get_full_dbname(sTmpTaipei));
        if (FullDBName[0]=='\0') 
            return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

        /*�k�ݳ��*/
        fRtnCode = cm_get_unit_in("", DBName, iissuer, issuebranch, "C1", sIcomp_in,
                                  sIbranch_in);
        if (fRtnCode != M_CM_OK)
             return exitsub(reply, fRtnCode) ?  fRtnCode : apiRC;

        printf("******** issuebranch[%s] dbname[%s]\n",issuebranch,FullDBName);

        printf("old_iofficer[%s]\n",old_iofficer);
        printf("old_ioffice[%s]\n",old_ioffice);
        printf("old_icardyear[%s]\n",old_icardyear);
        printf("old_dissue[%s]\n",old_dissue);

        $DELETE FROM issued_card
          WHERE iofficer=$old_iofficer 
            AND ioffice=$old_ioffice 
            AND iissue_branch=$old_sIbranch_in
            AND iissue_comp=$old_sIcomp_in
            AND icardyear=$old_icardyear 
            AND dissue=$old_dissue 
            AND fcard_class=$old_f_class;
       
        if (sqlca.sqlerrd[2]==0)
        {
            printf("1---------------delete-insert:no record\n");
            $WHENEVER SQLERROR CONTINUE;    
            $ROLLBACK WORK;
            return exitsub(reply,M_CA_NISSUED_CARD)?M_CA_NISSUED_CARD:apiRC;
        }

        for (i=0;i<rows;i++) 
        {
            cm_buf_get("%c %s %s %l %l %l %l %s %s", &flag, 
                       old_icar_type, icar_type, &old_qperiod, 
                       &qperiod, &old_qcard, &qcard, icard_begin, icard_end);
            $SELECT icard INTO $icard
               FROM officer
              WHERE iofficer=$iofficer;
            if (SQLCODE==SQLNOTFOUND) 
            {
                $WHENEVER SQLERROR CONTINUE;
                $ROLLBACK WORK;
                return exitsub(reply,M_CMN_NOFFICER) ? M_CMN_NOFFICER : apiRC;
            }

            $WHENEVER SQLERROR GOTO errexit;
            if(icar_type[0]!=' ' && icar_type[0]!='\0')
            {
                $SELECT icode 
                   FROM car_type
                  WHERE car_type.icode  =$icar_type ;
  
                if (SQLCODE==SQLNOTFOUND) 
                {
                    $WHENEVER SQLERROR CONTINUE;    
                    $ROLLBACK WORK;
                    return exitsub(reply,M_CA_NCARTYPE) ? M_CA_NCARTYPE : apiRC;
                }
            }

            $WHENEVER SQLERROR GOTO errexit;
            tmpcard[0]=icard[0];
            tmpcard[1]=icard[1];
            tmpcard[2]=icard_abbr[0];

            printf("issuebranch[%s]\n",issuebranch);
            printf("icardyear[%s]\n",icardyear);
            printf("dissue[%s]\n",dissue);
            printf("qperiod[%l]\n",qperiod);

            $INSERT INTO  issued_card
                         (iofficer,ioffice,icardyear,dissue,qcard,
                          iissuer,fcard_class,icar_type,qperiod,
                          fapp_print,frec_print,iissue_branch,iissue_comp)
                  VALUES ($iofficer,$ioffice,$icardyear,$dissue,$qcard,
                          $iissuer,$fcard_class,$icar_type,
                          $qperiod,"0","0",$sIbranch_in,$sIcomp_in);

        } /* end of for */
   
        cm_buf_init(ReplyBuf);
        cm_buf_put("%l",M_CM_OK);
        tmp_len = cm_buf_len(ReplyBuf);
        if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
        {
             $WHENEVER SQLERROR CONTINUE;
             $ROLLBACK WORK;
             return apiRC;
        }  

        $WHENEVER SQLERROR GOTO errexit;
        $COMMIT WORK;
        return api_OKComplete;
    }
    else
    {
        return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
    } 

errexit:
  $WHENEVER SQLERROR CONTINUE;
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

/*****************************************************************************/
/*****************************************************************************/
/* the followings are copied from ca203q.ec */

$int PgLine;
char OutFile[20];
int tmp_len;

static int max_count=0,errCode;
static int pagenum=1;

/*---------------------------------------------------------------------------*/
int car201_report(reply,rows,first_icar_begin,last_icar_end)
serverReply reply;
int rows;
char first_icar_begin[21],last_icar_end[21];
{
      char option,DBName[5];
      char tmpcmd[40],hostname[20];
      char prnDev[N_NAME+1];
      char prnFile[N_FILE+1];
      int  copies,res;
      char sBuf[40];
 
      res = build(reply,rows);
      if ( !res ) return 0;

      res = getApHome(sBuf);
      if (res<0) {
          printf("In sigalrmcatcher func==>read config file error!!\n");
          exit(1);
      }
        
      gethostname(hostname,sizeof hostname); 
      sprintf(tmpcmd,"%s/reportfile/%s", sBuf, OutFile);
      printf("tmpcmd=%s\n",tmpcmd);

      cm_buf_init(ReplyBuf);
      cm_buf_put("%l %s %s %d %s %s",errCode,hostname,tmpcmd,PgLine,
                  first_icar_begin,last_icar_end);
      tmp_len=cm_buf_len(ReplyBuf);
      printf("len of buf=%d\n",tmp_len);
      if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
          return 0;
          return 1;
}

/*---------------------------------------------------------------------------*/
int build(reply,rows)
serverReply reply;
int rows;
{
  $char RepFormat[N_FORMAT+1];
  $char PrnForm[N_PRNFRM+1];
  $char RepHeader1[N_HEADER+1];
  $char RepHeader2[N_HEADER+1];
  $char RepHeader3[N_HEADER+1];
  $char RepHeader4[N_HEADER+1];
  $char RepHeader5[N_HEADER+1];
  $char RepHeader6[N_HEADER+1];
  $char FormFile[N_FILE+1];
  $char RepTp[N_REPTP+1];
  $char RepDescription[N_NAME+1];
  char  Period1[N_DM+1];
  char  Period2[N_DM+1];
  char  Period3[N_DM+1];
  char  DeptNo[N_DEPT+1];
  char  fDept;
  char  outputf[20];

  $int PageSize;
  $int RepType;
  $int Unit;
  $int RepGrp;
  int i,res;

  errCode = M_CM_OK;

  $SELECT kPgNum_Line, nForm_File INTO $PgLine, $FormFile
     FROM Form
    WHERE ksys_grp="CA" AND kPgmID = 201;

  strcpy(FormFile,rtrim(FormFile));
  strcpy(outputf, getFileName());
  sprintf(OutFile,"%s.tx",outputf);

  rgu_init_report(FormFile,OutFile);
  res = body(reply,rows);
  rgu_finish_report();
  return res;
} 

/*-----------------------------------------------------------------------*/
int body(reply,rows)
serverReply reply;
int rows;
{
  int i, Code=1;
  
  $long dissue; 
  $char officer[11], office[7];
  $char icar_type[3];
  $char icard[10];
  $char begin_ptr[9], end_ptr[9];
  $char ncode[11];
  char  c_issuredt[9];
  
  $char cardbegin[9], cardend[9], c_dissue[20];
  char  checknum[2];
  int   j,k;
  int   even_cnt=0;
  int   cnt=0;
  $long qperiod;

  for (k=0; k<rows; k++)
  {
    strcpy(cardbegin,list[k].begin);
    strcpy(cardend,list[k].end);
  
    $WHENEVER SQLERROR GOTO errexit;   
  

    $DECLARE q_curp CURSOR FOR
      SELECT icard,icar_type,qperiod
        INTO $icard,$icar_type,$qperiod
        FROM compulsory_card
       WHERE icard  BETWEEN $cardbegin AND $cardend; 

    $OPEN q_curp;
    for(;;) 
    {
        $FETCH q_curp;
        if (SQLCODE != 0) break;

        $SELECT ncode
           INTO $ncode
           FROM car_type
          WHERE fclass="1" AND icode = $icar_type;

        icard[8]= ' ' ;
        icard[9]= '\0';
        sprintf(checknum,"%d",get_check_num(icard));

        rgu_put_body_string(1,checknum,RIGHT);  
        rgu_put_body_string(1,ncode,LEFT);  
        rgu_put_body_string(1,icar_type,LEFT);  
        rgu_put_body_long(1,qperiod,RIGHT);  
        rgu_put_body_string(1,checknum,RIGHT);  
        rgu_put_body(1);

        cnt++;
        if (cnt>0 && cnt%WAKEUP_CNT==0) {
            cm_buf_init(ReplyBuf);
            cm_buf_put("%l",M_CM_OK);
            tmp_len = cm_buf_len(ReplyBuf);
            if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OK)==False)
                return 0;
        }

    }
    $CLOSE q_curp;
  } /* for list struct loop */

  return 1;

errexit:
  printf("Hello!  SQL ERROR code=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
  return 0;
}


int IsBlankNull(str)
char *str;
{
    while (*str)
    {
        if (*str!=' ') return FALSE;
        str++;
    }
    return TRUE;
}

/* ------------------------------------------------------------------------ */
long car201_multiple_query(reply)
serverReply reply;
{
  $char DBName[5];

   $char iofficer[11],ioffice[7],icardyear[4],issuebranch[CA_POL_BRH_NUM];
   $char sIbranch_in[BRANCH_ID], sIcomp_in[BRANCH_ID];
   char sTmpIbranch[BRANCH_ID], sTmpIcomp[BRANCH_ID];
   char sTmpTaipei[BRANCH_ID];
   char  FullDBName[20];
   $char dissue[11],s_dissue[10],iissuer[11],icar_type[3];
   $char key_iofficer[11],key_ioffice[7],key_icardyear[34];
   $long diss;
   $char key_dissure[11];
   $char icard_begin[21],icard_end[21];
   $char fapp_print[2],frec_print[2];
   $long qcard,qperiod;
   $char iissue_branch[3],sFcard_class[2];
   $char sIcard_begin[21], sIcard_end[21];
   $char  stm_str1[4];

   struct card_t {
        char icar_type[3];
        long qperiod;
        long qcard;
        char icard_begin[21];
        char icard_end[21];
        char fapp_print;
        char frec_print;
   } card[MAXROWITEMS];
        
   $long avaisum,usedsum,cancelsum,losssum,expiresum,sum;
   long fRtnCode;

   /* standard defined data */
   char tmpbuf[4000];
   int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
   int i,total_count=0; 

   cm_buf_get("%s",DBName);
   cm_buf_get("%s %s %s %s %s",
   key_iofficer, key_ioffice, key_icardyear, s_dissue, issuebranch);
   if (s_dissue[0]!='*')
      strcpy(key_dissure,cm_to_infdate(s_dissue));

   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False)
   {
      if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
         return M_CM_DB_NOTOPEN;
      else
         return apiRC;
   }
   
   printf("******** issuebranch[%s] dbname[%s]\n",issuebranch,FullDBName);

   strcpy(key_icardyear,trim(key_icardyear));

   if (key_ioffice[0] == '*') 
   {
      if (s_dissue[0]=='*') 
      {
         $DECLARE mcurd1 CURSOR FOR
            SELECT unique iofficer,ioffice,icardyear,dissue,iissue_branch,
                   iissue_comp,icard_begin,icard_end,fcard_class
              INTO $iofficer,$ioffice,$icardyear,$diss,$sIbranch_in,
                   $sIcomp_in,$sIcard_begin,$sIcard_end,$sFcard_class
              FROM issued_card
             WHERE iofficer MATCHES $key_iofficer
               AND icardyear MATCHES $key_icardyear
             ORDER BY iofficer;
         $OPEN mcurd1;
      }
      else 
      {
         $DECLARE mcurd2 CURSOR FOR
           SELECT unique iofficer,ioffice,icardyear,dissue,iissue_branch,
                  iissue_comp,icard_begin,icard_end,fcard_class
             INTO $iofficer,$ioffice,$icardyear,$diss,$sIbranch_in,
                  $sIcomp_in,$sIcard_begin,$sIcard_end,$sFcard_class
             FROM issued_card
            WHERE iofficer MATCHES $key_iofficer 
              AND icardyear MATCHES $key_icardyear 
              AND dissue = $key_dissure
            ORDER BY iofficer;
         $OPEN mcurd2;
      }
   }   
   else
   {
      if (s_dissue[0]=='*')
      {
         $DECLARE mcurd3 CURSOR FOR
           SELECT unique iofficer,ioffice,icardyear,dissue,iissue_branch,
                  iissue_comp,icard_begin,icard_end,fcard_class
             INTO $iofficer,$ioffice,$icardyear,$diss,$sIbranch_in,$sIcomp_in,
                  $sIcard_begin,$sIcard_end,$sFcard_class
             FROM issued_card
            WHERE iofficer matches $key_iofficer
              AND ioffice matches $key_ioffice
              AND icardyear matches $key_icardyear
            ORDER BY iofficer;
         $OPEN mcurd3;
      }
      else 
      {
         $DECLARE mcurd4 CURSOR FOR
           SELECT unique iofficer,ioffice,icardyear,dissue,iissue_branch,
                  iissue_comp,icard_begin,icard_end,fcard_class
             INTO $iofficer,$ioffice,$icardyear,$diss,$sIbranch_in,$sIcomp_in,
                  $sIcard_begin,$sIcard_end,$sFcard_class
             FROM issued_card
            WHERE iofficer MATCHES $key_iofficer
              AND ioffice MATCHES $key_ioffice 
              AND icardyear MATCHES $key_icardyear 
              AND dissue = $key_dissure 
            ORDER BY iofficer;
         $OPEN mcurd4;
      }   
   }

   for(;;)
   {
      if(key_ioffice[0] == '*')
      {
         if (s_dissue[0]=='*')
            $FETCH mcurd1;
         else
            $FETCH mcurd2;
      }
      else
      {
         if (s_dissue[0]=='*')
            $FETCH mcurd3;
         else
            $FETCH mcurd4;
      }
    
      if (SQLCODE != 0) break;

      cm_buf_init(tmpbuf);
      if ( count == 0 )
      {
         cm_buf_res_msg();             /* reserve for MsgCode and count */
         cm_buf_res_count();
      }
      
        
      
      strcpy(issuebranch, rtrim(sIbranch_in));
      strcpy(stm_str1, get_upcomp(sIcomp_in, USE_BRANCH_ID,
                                         USE_SHORT_BRANCH_ID));
      printf("stm_str1=[%s]\n",stm_str1);
      strcpy(stm_str1, trim (stm_str1));
      
      /* strcat(issuebranch, rtrim(get_upcomp(sIcomp_in, USE_BRANCH_ID,
                                         USE_SHORT_BRANCH_ID))); */
      strcat(issuebranch, stm_str1);
      
      printf("issuebranch=[%s]\n",issuebranch);
      
      cm_buf_put("%s %s %s %s %s %s %s %s",
               iofficer,ioffice,icardyear,cm_cdate_str_100(diss),issuebranch,
               sIcard_begin, sIcard_end, sFcard_class );

      tmp_len = cm_buf_len(tmpbuf);
   
      if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
      {
         memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
         repbuf_len += tmp_len;
         count++;
      }
      else                               /* more than 4K, send to client side */
      {
         cm_buf_init(ReplyBuf);
         cm_buf_put_msg(M_CM_OK);
         cm_buf_put_count(count);
         if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
         {
            if(key_ioffice[0] == '*')
            {
               if (s_dissue[0]=='*') 
                  $CLOSE mcurd1;
               else
                  $CLOSE mcurd2;
            }
            else
            {
               if (s_dissue[0]=='*') 
                  $CLOSE mcurd3;
               else
                  $CLOSE mcurd4;
            }
            return apiRC;
         }
         else               /* clear ReplyBuf and count to start all over again */
         {
            replycnt++;
            if (replycnt == 10)   /* more than 30K, client cannot display,error */
            {
               cm_buf_init(ReplyBuf);
               cm_buf_put("%l",M_CM_OUT_SPACE);
               tmp_len = cm_buf_len(ReplyBuf);
               if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
                  return apiRC;
               return M_CM_OUT_SPACE;
            }
            ReplyBuf[0] = '\0';
            count = 0;
            
            cm_buf_init(ReplyBuf);
            cm_buf_res_msg();           /* reserve for MsgCode and count */
            cm_buf_res_count();
            cm_buf_put("%s %s %s %s %s %s %s %s",
                        iofficer,ioffice,icardyear,cm_cdate_str_100(diss),issuebranch,
                        sIcard_begin, sIcard_end, sFcard_class );
            repbuf_len = cm_buf_len(ReplyBuf);
            count++;
         }
      }
   } /* for loop */

   if(key_ioffice[0] == '*')
   {
      if (s_dissue[0]=='*') 
         $CLOSE mcurd1;
      else
         $CLOSE mcurd2;
   }
   else
   {
      if (s_dissue[0]=='*') 
         $CLOSE mcurd3;
      else
         $CLOSE mcurd4;
   }
 
 
   if (count > 0)   /* break out, at least one record is selected */
   {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
         return apiRC;
      return api_OKComplete;
   }
   else            /* break out, not any row is found */
   {
      if(exitsub(reply,M_CA_NCARD1) == True)
         return M_CA_NCARD1;
      else
         return apiRC;
   }

   errexit:
      if(exitsub(reply,SQLCODE) == True)
         return SQLCODE;
      else
         return apiRC;
}
/*****************************************************************************/
long car201_get_billingsystem_setting(reply)  /*1070111014_SC4_car201�d��ñ������ܧ�  2019.03.11 by 071004   */
serverReply reply; /*Ū��billingsystem�ɳ]�w���~��+�r�y�r�Ƥάy�����r��*/
{
     $char DBName[DBNAME];
     $char ioffice[7];
     $char sFcard_class[2],sIbilling[5],icar_type[4],fcomp_p3[2];
     $char kcode_yr_len[2], ksno_len[2];


     cm_buf_get("%s",DBName);
     cm_buf_get("%s %s %s %s",sFcard_class,ioffice,fcomp_p3,icar_type);

     if( strcmp( sFcard_class , "1" ) == 0 ) 
     {
        /** �j���I**/
         printf("fcard_class [%s] \n", sFcard_class );                                       

         if (IsBlankNull(ioffice)) /*�@��*/
         {
              $WHENEVER SQLERROR GOTO errexit;
              if ((strcmp(icar_type, "01") == 0) ||(strcmp(icar_type, "02") == 0) ||(strcmp(icar_type, "32") == 0) ||(strcmp(icar_type, "34") == 0) ||(strcmp(icar_type, "35") == 0))
              {    
                    if (strcmp(fcomp_p3,"4") == 0)
                           $SELECT kcode_len + kyr_len,ksno_len INTO $kcode_yr_len ,$ksno_len FROM billingsystem WHERE kbill_grp = 'C1' AND  kbill_tp = "MQ3";
                    else
                           $SELECT kcode_len + kyr_len,ksno_len INTO $kcode_yr_len ,$ksno_len FROM billingsystem WHERE kbill_grp = 'C1' AND  kbill_tp = "MQ";                                     
              }                                          
              else if (strcmp(fcomp_p3,"4") == 0)
                           $SELECT kcode_len + kyr_len,ksno_len INTO $kcode_yr_len ,$ksno_len FROM billingsystem WHERE kbill_grp = 'C1' AND  kbill_tp = "CQ3";
              else
                           $SELECT kcode_len + kyr_len,ksno_len INTO $kcode_yr_len ,$ksno_len FROM billingsystem WHERE kbill_grp = 'C1' AND  kbill_tp = "CQ";
                           
              printf("sIbilling[%s]\n",sIbilling);


         }
         else
         {
               /* car9808191 ���q�B���׾����j���ҵ��� */
              $WHENEVER SQLERROR GOTO errexit; 
              if ((strcmp(icar_type, "01") == 0) ||(strcmp(icar_type, "02") == 0) ||(strcmp(icar_type, "32") == 0) ||(strcmp(icar_type, "34") == 0) ||(strcmp(icar_type, "35") == 0))
                    strcpy(sIbilling,"M");
              else
                    strcpy(sIbilling,"Z");

              strncat(sIbilling,ioffice,1);
              sIbilling[2]='\0';
              printf("sIbilling[%s]\n",sIbilling);
              
              $SELECT kcode_len + kyr_len,ksno_len INTO $kcode_yr_len ,$ksno_len FROM billingsystem WHERE kbill_grp = 'C1' AND  kbill_tp = $sIbilling;
                        
         }
    
     }
     else if( strcmp(sFcard_class,"2") == 0 )
     { 
     	 /** ���N�I**/
     	 $WHENEVER SQLERROR GOTO errexit;
         /* �]�w�O�N�󵹸��Ѽ� */
         strcpy(sIbilling, ioffice);
         strcpy(sIbilling, trim(sIbilling));
         printf("fcard_class [%s] \n",sFcard_class );                                       
         printf("sIbilling[%s]\n",sIbilling);              
             
         $SELECT kcode_len + kyr_len,ksno_len INTO $kcode_yr_len ,$ksno_len FROM billingsystem WHERE kbill_grp = 'C1' AND  kbill_tp = $sIbilling;

     }
     
     
     cm_buf_init(ReplyBuf);

     cm_buf_put("%l %s %s", M_CM_OK, kcode_yr_len,ksno_len);

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}