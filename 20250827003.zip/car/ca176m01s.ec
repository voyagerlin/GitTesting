/************************************************/
/*                                              */
/*   PROGRAM : ca176m01s.ec                     */
/*                                              */
/*   PURPOSE : �O�o���N�I���@�{��               */
/*                                              */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "commsgs.h"
#include "safeclib.h"
$include sqlca;

DBinfo  *list;
int  count_db, i;

long car176(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	/*
		W/X ca_dev_ply_edr
		Y/Z ca_dev_clm
	*/
	
	long rtncode;
	long car176_single_query_WX(),car176_multiple_query_WX(),car176_update_exec_WX();
	long car176_single_query_YZ(),car176_multiple_query_YZ(),car176_update_exec_YZ();
	char option;
	
	cm_buf_init(command);
	cm_buf_get("%c",&option);
	switch(option)
	{
		case 'Q':
			rtncode=car176_single_query_WX(reply);
			break;
		case 'q':
			rtncode=car176_single_query_YZ(reply);
			break;
		case 'M':
			rtncode=car176_multiple_query_WX(reply);
			break;
		case 'm':
			rtncode=car176_multiple_query_YZ(reply);
			break;
		case 'U':
			rtncode=car176_update_exec_WX(reply,command,com_len);
			break;
		case 'u':
			rtncode=car176_update_exec_YZ(reply,command,com_len);
			break;
		default :
			if(exitsub(reply,M_CM_WRONG_OPTION) == True)
			 return M_CM_WRONG_OPTION;
		return apiRC;
	}
	return(rtncode);
}

long car176_single_query_WX(reply)
serverReply reply;
{
	$char DBName[5],data_yyyymm_in[7],idata_in[2],ipolicy_in[21],iendorse_in[21],iins_type_in[7],iins_main_in[7],iedr_type_in[3], sFullName[21], stmt[4096],stmp[2048];
	$char buff[250];
	int tmp_len;
	
	$char   data_yyyymm[7],idata[2],ipolicy[21],iendorse[21],icompany[3],iply_br[3],iply[13],iply_last_br[3],iply_last[13];
	$char   iedr_br[3],iedr[13],iarea[3],dedr_begin[9],dedr_end[9],dply_begin[9],dply_end[9],iobjno[5],iissue_ym[7],ipro_ym[7],ibrand[9];
	$char   icar_type_ori[3],icar_type[3],icar_type_no[3],iengine[26],itag[13],fpt[2],iassured[11],dbirth_y[5],fsex[2],fmarriage[2];
	$char   ipdmg_align[2],ipbrg_align[2],iplia_align[2],iins_type[7],iins_main[7],iins_type_main[2],iins_type_dtl[3];
	$char   iedr_type_ori[3],iedr_type[3],iins_type_dev[5],iins_type_rule[3],frule[2],ubi_data[9],fmdeduct[2];
	$char   iproduct[13],drate_ym[7],dendorse_ym[7],dpolicy_ym[7],bzfrom[3],dsend[9];
	$long   qcylinder = 0,qpt = 0,padjust_rate = 0,p_mcar_price = 0,qdmg_acc_year = 0,qdmg_acc_time = 0,pdepreciate_year = 0;
	$long   minjured_cover = 0,mdeath_cover = 0,mdamage_cover = 0,mdamage_cover_bak = 0,mdamage_cover_aft = 0,iins_mult = 0;
	$long   mdeduct = 0,mprem = 0,mprem_pure = 0,mprem_bak = 0,mprem_pure_bak = 0,mprem_aft = 0,mprem_pure_aft = 0;
	$double pins_acc = 0.0,psex_age = 0.0,mprem_pure_base = 0.0,mprem_pure_base_bak = 0.0,mprem_pure_base_aft = 0.0,coefficient = 0.0;
	$char   pins_acc_tmp[7],psex_age_tmp[7],mprem_pure_base_tmp[15],mprem_pure_base_bak_tmp[15],mprem_pure_base_aft_tmp[15],coefficient_tmp[15];

	cm_buf_get("%s %s %s %s %s %s %s %s ",DBName,data_yyyymm_in,idata_in,ipolicy_in,iendorse_in,iins_type_in,iins_main_in,iedr_type_in);
	strcpy(ipolicy_in,trim(ipolicy_in));

	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}

	if(idata_in[0] == 'W')
		strcpy(sFullName, get_car_full_db(ipolicy_in));
 	else 
 		strcpy(sFullName, get_car_full_db(iendorse_in));
 		
	sprintf_s(stmt, sizeof stmt,"SELECT data_yyyymm,idata,ipolicy,iendorse,icompany,iply_br,iply,iply_last_br,iply_last, "
	                    " iedr_br,iedr,iarea,dedr_begin,dedr_end,dply_begin,dply_end,iobjno,iissue_ym,ipro_ym,ibrand,icar_type_ori,icar_type,icar_type_no, "
	                    " qcylinder,iengine,itag,qpt,fpt,iassured,dbirth_y,fsex,fmarriage, "
	                    " ipdmg_align,ipbrg_align,iplia_align,iins_type,iins_main,iins_type_main,iins_type_dtl,iedr_type_ori,iedr_type,iins_type_dev,iins_type_rule,frule, "
	                    " padjust_rate,p_mcar_price,pins_acc,qdmg_acc_year,qdmg_acc_time,psex_age,pdepreciate_year,ubi_data, "
	                    " minjured_cover,mdeath_cover,mdamage_cover,mdamage_cover_bak,mdamage_cover_aft, "
	                    " iins_mult,fmdeduct,mdeduct,mprem,mprem_pure,mprem_pure_base, "
	                    " mprem_bak,mprem_pure_bak,mprem_pure_base_bak,mprem_aft,mprem_pure_aft,mprem_pure_base_aft, "
	                    " coefficient,iproduct,drate_ym,dendorse_ym,dpolicy_ym,bzfrom,dsend "
	               " FROM %s:ca_dev_ply_edr "
	              " WHERE data_yyyymm = '%s' "
	                " AND idata       = '%s' "
	                " AND ipolicy     = '%s' "
	                " AND iendorse    = '%s' "
	                " AND iins_type   = '%s' "
	                " AND iins_main   = '%s' "
	                " AND iedr_type   = '%s'",sFullName,data_yyyymm_in,idata_in,ipolicy_in,iendorse_in,iins_type_in,iins_main_in,iedr_type_in);
     
	printf("stmt[%s]\n\n",stmt);    
	$PREPARE ply_edr_q FROM $stmt;
	$EXECUTE ply_edr_q INTO $data_yyyymm,$idata,$ipolicy,$iendorse,$icompany,$iply_br,$iply,$iply_last_br,$iply_last,
	                        $iedr_br,$iedr,$iarea,$dedr_begin,$dedr_end,$dply_begin,$dply_end,$iobjno,$iissue_ym,$ipro_ym,$ibrand,$icar_type_ori,$icar_type,$icar_type_no,
	                        $qcylinder,$iengine,$itag,$qpt,$fpt,$iassured,$dbirth_y,$fsex,$fmarriage,
	                        $ipdmg_align,$ipbrg_align,$iplia_align,$iins_type,$iins_main,$iins_type_main,$iins_type_dtl,$iedr_type_ori,$iedr_type,$iins_type_dev,$iins_type_rule,$frule,
	                        $padjust_rate,$p_mcar_price,$pins_acc,$qdmg_acc_year,$qdmg_acc_time,$psex_age,$pdepreciate_year,$ubi_data,
	                        $minjured_cover,$mdeath_cover,$mdamage_cover,$mdamage_cover_bak,$mdamage_cover_aft,
	                        $iins_mult,$fmdeduct,$mdeduct,$mprem,$mprem_pure,$mprem_pure_base,
	                        $mprem_bak,$mprem_pure_bak,$mprem_pure_base_bak,$mprem_aft,$mprem_pure_aft,$mprem_pure_base_aft,
	                        $coefficient,$iproduct,$drate_ym,$dendorse_ym,$dpolicy_ym,$bzfrom,$dsend;
	if(SQLCODE==SQLNOTFOUND)
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True)     
			return M_CM_NOT_FOUND;                     
		else
			return apiRC;
	}
	
	sprintf_s(pins_acc_tmp, sizeof pins_acc_tmp,"%.2f",pins_acc);
	sprintf_s(psex_age_tmp, sizeof psex_age_tmp,"%.2f",psex_age);
	sprintf_s(mprem_pure_base_tmp, sizeof mprem_pure_base_tmp,"%.4f",mprem_pure_base);
	sprintf_s(mprem_pure_base_bak_tmp, sizeof mprem_pure_base_bak_tmp,"%.4f",mprem_pure_base_bak);
	sprintf_s(mprem_pure_base_aft_tmp, sizeof mprem_pure_base_aft_tmp,"%.4f",mprem_pure_base_aft);
	sprintf_s(coefficient_tmp, sizeof coefficient_tmp,"%.4f",coefficient);
	
	cm_buf_init(ReplyBuf);
	cm_buf_put("%l %s %s %s %s %s %s %s %s %s ",M_CM_OK,data_yyyymm,idata,ipolicy,iendorse,icompany,iply_br,iply,iply_last_br,iply_last);
	cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %s %s %s ",iedr_br,iedr,iarea,dedr_begin,dedr_end,dply_begin,dply_end,iobjno,iissue_ym,ipro_ym,ibrand,icar_type_ori,icar_type,icar_type_no);
	cm_buf_put("%d %s %s %d %s %s %s %s %s",qcylinder,iengine,itag,qpt,fpt,iassured,dbirth_y,fsex,fmarriage);
	cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %s",ipdmg_align,ipbrg_align,iplia_align,iins_type,iins_main,iins_type_main,iins_type_dtl,iedr_type_ori,iedr_type,iins_type_dev,iins_type_rule,frule);
	cm_buf_put("%d %d %s %d %d %s %d %s ",padjust_rate,p_mcar_price,pins_acc_tmp,qdmg_acc_year,qdmg_acc_time,psex_age_tmp,pdepreciate_year,ubi_data);
	cm_buf_put("%d %d %d %d %d ",minjured_cover,mdeath_cover,mdamage_cover,mdamage_cover_bak,mdamage_cover_aft);
	cm_buf_put("%d %s %d %d %d %s ",iins_mult,fmdeduct,mdeduct,mprem,mprem_pure,mprem_pure_base_tmp);
	cm_buf_put("%d %d %s %d %d %s ",mprem_bak,mprem_pure_bak,mprem_pure_base_bak_tmp,mprem_aft,mprem_pure_aft,mprem_pure_base_aft_tmp);
	cm_buf_put("%s %s %s %s %s %s %s ",coefficient_tmp,iproduct,drate_ym,dendorse_ym,dpolicy_ym,bzfrom,dsend);
	
	tmp_len = cm_buf_len(ReplyBuf);
	
	
	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
		return apiRC;
	else
		return api_OKComplete;
	
	errexit:
	if(exitsub(reply,SQLCODE) == True)
		return SQLCODE;
	else
		return apiRC;
}

long car176_single_query_YZ(reply)
serverReply reply;
{
	$char DBName[5],data_yyyymm_in[7],idata_in[2],iclaim_in[21],istl_in[21],iins_type_in[7],iins_main_in[7],iins_type_class_in[3], sFullName[21], stmt[4096],stmp[2048];
	$long iclose_type_in;
	$char sIbranch_in[3];
	$char buff[250];
	int tmp_len;
	
	$char data_yyyymm[7],idata[2],istl[2],ipolicy[21],iclaim[21],icompany[3],iclm_br[3],iclm[13],dclaim[9],dgroup[9];
	$char icompany_ply[3],iply_br[3],iply[13],dply_begin_ym[7],iobjno[5],iissue_ym[7],ipro_ym[7],ibrand[9],icar_type_ori[3],icar_type[3],icar_type_no[3];
	$char iengine[26],itag[13],fpt[2],iacc_license[11],iacc_birth_y[5],facc_sex[2],facc_marri[2],iacc_reason[3],fduty[2];
	$char iassured[11],dbirth_y[5],fsex[2],fmarriage[2],daccident[9],dvp_code1[3],dvp_code2[3],fpart[2];
	$char ipdmg_align[2],ipbrg_align[2],iplia_align[2],iins_type_ori[7],iins_type[7],iins_main[7],iins_type_main[2],iins_type_dtl[3],iins_type_dev[5],iins_type_rule[3],iins_type_class[3],frule[3];
	$char ubi_data[9],fmdeduct[2],fstl[2],iproduct[13],drate_ym[7],dentry[9],bzfrom[3],dpolicy_ym[7],dsend[9],fsingle_acc[5],adjustment[7],ifacnum[11];
	$long iclose_type = 0,qcylinder = 0,qpt = 0,qlia1 = 0,qlia2 = 0,qlia3 = 0,p_mcar_price = 0,pdepreciate_year = 0,mcover = 0,iins_mult = 0,mdeduct = 0,qpeople = 0;
	$long iself_duty = 0,ioth_duty = 0,ianoth_duty = 0,mins_app = 0,mdeduct_clm = 0,mins_stl = 0,mins_proc = 0;
	$double pins_acc = 0.0,psex_age = 0.0;
	$char   pins_acc_tmp[7],psex_age_tmp[7];
	
	cm_buf_get("%s %s %s %s %s %d %s %s %s ",DBName,data_yyyymm_in,idata_in,iclaim_in,istl_in,&iclose_type_in,iins_type_in,iins_main_in,iins_type_class_in);
	strcpy(iclaim_in,trim(iclaim_in));

	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}

	/* ���o�߮׸�Ʈw */
	$SELECT ibranch_in
	   INTO $sIbranch_in
	   FROM ca_clm_process
	  WHERE iclaim = $iclaim_in;
	  
	strcpy(sFullName, get_full_dbname(sIbranch_in));
 		
	sprintf_s(stmt, sizeof stmt,"SELECT data_yyyymm,idata,istl,ipolicy,iclaim,icompany,iclm_br,iclm,dclaim,iclose_type,dgroup, "
	                    " icompany_ply,iply_br,iply,dply_begin_ym,iobjno,iissue_ym,ipro_ym,ibrand,icar_type_ori,icar_type,icar_type_no, "
	                    " qcylinder,iengine,itag,qpt,fpt,iacc_license,iacc_birth_y,facc_sex,facc_marri,iacc_reason,fduty, "
	                    " iassured,dbirth_y,fsex,fmarriage,qlia1,qlia2,qlia3,daccident,dvp_code1,dvp_code2,fpart, "
	                    " ipdmg_align,ipbrg_align,iplia_align,iins_type_ori,iins_type,iins_main,iins_type_main,iins_type_dtl,iins_type_dev,iins_type_rule,iins_type_class,frule, "
	                    " p_mcar_price,pins_acc,psex_age,pdepreciate_year,ubi_data,mcover,iins_mult,fmdeduct,mdeduct,qpeople, "
	                    " iself_duty,ioth_duty,ianoth_duty,mins_app,mdeduct_clm,mins_stl,mins_proc,fstl, "
	                    " iproduct,drate_ym,dentry,bzfrom,dpolicy_ym,dsend,fsingle_acc,adjustment,ifacnum "
	               " FROM %s:ca_dev_clm "
	              " WHERE data_yyyymm = '%s' "
	                " AND idata       = '%s' "
	                " AND iclaim      = '%s' "
	                " AND istl        = '%s' "
	                " AND iclose_type =  %d  "
	                " AND iins_type   = '%s' "
	                " AND iins_main   = '%s' "
	                " AND iins_type_class = '%s'",sFullName,data_yyyymm_in,idata_in,iclaim_in,istl_in,iclose_type_in,iins_type_in,iins_main_in,iins_type_class_in);
     
	printf("stmt[%s]\n\n",stmt);    
	$PREPARE clm_q FROM $stmt;
	$EXECUTE clm_q INTO $data_yyyymm,$idata,$istl,$ipolicy,$iclaim,$icompany,$iclm_br,$iclm,$dclaim,$iclose_type,$dgroup,
	                    $icompany_ply,$iply_br,$iply,$dply_begin_ym,$iobjno,$iissue_ym,$ipro_ym,$ibrand,$icar_type_ori,$icar_type,$icar_type_no,
	                    $qcylinder,$iengine,$itag,$qpt,$fpt,$iacc_license,$iacc_birth_y,$facc_sex,$facc_marri,$iacc_reason,$fduty,
	                    $iassured,$dbirth_y,$fsex,$fmarriage,$qlia1,$qlia2,$qlia3,$daccident,$dvp_code1,$dvp_code2,$fpart,
	                    $ipdmg_align,$ipbrg_align,$iplia_align,$iins_type_ori,$iins_type,$iins_main,$iins_type_main,$iins_type_dtl,$iins_type_dev,$iins_type_rule,$iins_type_class,$frule,
	                    $p_mcar_price,$pins_acc,$psex_age,$pdepreciate_year,$ubi_data,$mcover,$iins_mult,$fmdeduct,$mdeduct,$qpeople,
	                    $iself_duty,$ioth_duty,$ianoth_duty,$mins_app,$mdeduct_clm,$mins_stl,$mins_proc,$fstl,
	                    $iproduct,$drate_ym,$dentry,$bzfrom,$dpolicy_ym,$dsend,$fsingle_acc,$adjustment,$ifacnum;
	
	if(SQLCODE==SQLNOTFOUND)
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True)     
			return M_CM_NOT_FOUND;                     
		else
			return apiRC;
	}
	
	sprintf_s(pins_acc_tmp, sizeof pins_acc_tmp,"%.2f",pins_acc);
	sprintf_s(psex_age_tmp, sizeof psex_age_tmp,"%.2f",psex_age);
	
	cm_buf_init(ReplyBuf);
	cm_buf_put("%l %s %s %s %s %s %s %s %s %s %d %s",M_CM_OK,data_yyyymm,idata,istl,ipolicy,iclaim,icompany,iclm_br,iclm,dclaim,iclose_type,dgroup);
	cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s ",icompany_ply,iply_br,iply,dply_begin_ym,iobjno,iissue_ym,ipro_ym,ibrand,icar_type_ori,icar_type,icar_type_no);
	cm_buf_put("%d %s %s %d %s %s %s %s %s %s %s ",qcylinder,iengine,itag,qpt,fpt,iacc_license,iacc_birth_y,facc_sex,facc_marri,iacc_reason,fduty);
	cm_buf_put("%s %s %s %s %d %d %d %s %s %s %s ",iassured,dbirth_y,fsex,fmarriage,qlia1,qlia2,qlia3,daccident,dvp_code1,dvp_code2,fpart);
	cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %s ",ipdmg_align,ipbrg_align,iplia_align,iins_type_ori,iins_type,iins_main,iins_type_main,iins_type_dtl,iins_type_dev,iins_type_rule,iins_type_class,frule);
	cm_buf_put("%d %s %s %d %s %d %d %s %d %d ",p_mcar_price,pins_acc_tmp,psex_age_tmp,pdepreciate_year,ubi_data,mcover,iins_mult,fmdeduct,mdeduct,qpeople);
	cm_buf_put("%d %d %d %d %d %d %d %s ",iself_duty,ioth_duty,ianoth_duty,mins_app,mdeduct_clm,mins_stl,mins_proc,fstl);
	cm_buf_put("%s %s %s %s %s %s %s %s %s ",iproduct,drate_ym,dentry,bzfrom,dpolicy_ym,dsend,fsingle_acc,adjustment,ifacnum);

	tmp_len = cm_buf_len(ReplyBuf);
	
	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
		return apiRC;
	else
		return api_OKComplete;
	
	errexit:
	if(exitsub(reply,SQLCODE) == True)
		return SQLCODE;
	else
		return apiRC;
}

long car176_multiple_query_WX(reply)
serverReply reply;
{
	$char DBName[5],data_yyyymm_in[7],idata_in[2],ipolicy_in[21],iendorse_in[21],iins_type_in[7],iins_main_in[7],iedr_type_in[3];
	$char userid[11],stmt[1024],v_sMsg[2040],stmp[128];
	$char data_yyyymm[7],idata[2],ipolicy[21],iendorse[21],iins_type[7],iins_main[7],iedr_type[3];
	$long sToday,ply2_begin,sLdeffect;
	char tmpbuf[4000];
	int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
	int i,total_count=0;
	int top_40 = 0,top_20 = 0 ,rc;
	
	cm_buf_get("%s %s %s %s %s %s %s %s ",DBName,data_yyyymm_in,idata_in,ipolicy_in,iendorse_in,iins_type_in,iins_main_in,iedr_type_in);
	
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
		return M_CM_DB_NOTOPEN;
		else
		return apiRC;
	}
	
	if ( (list=get_db_list(&count_db,DBName)) == (char*)0 ) {
		printf("get_db_list error accur \n");
		return SQLCODE;
	}
	for(int k=0 ; k<count_db ; k++)
	{
	
		sprintf_s(stmt, sizeof stmt,"SELECT data_yyyymm,idata,ipolicy,iendorse,iins_type,iins_main,iedr_type "
		               " FROM %s:ca_dev_ply_edr  "
		              " WHERE data_yyyymm matches '%s' "
		                " AND idata       matches '%s' "
		                " AND ipolicy     matches '%s' "
		                " AND iendorse    matches '%s' "
		                " AND iins_type   matches '%s' "
		                " AND iins_main   matches '%s' "
		                " AND iedr_type   matches '%s' ",list[k].dbname,data_yyyymm_in,idata_in,ipolicy_in,iendorse_in,iins_type_in,iins_main_in,iedr_type_in);	
		printf("stmt[%s]\n",stmt);
		$PREPARE mq_ply_edrs FROM $stmt;
		$DECLARE mq_ply_edr CURSOR FOR mq_ply_edrs;
		$OPEN mq_ply_edr;
		
		for(;;)
		{	
			$FETCH mq_ply_edr INTO $data_yyyymm,$idata,$ipolicy,$iendorse,$iins_type,$iins_main,$iedr_type;
			
			if (SQLCODE != 0) break;
			cm_buf_init(tmpbuf);
			if ( count == 0 )
			{
				cm_buf_res_msg();             /* reserve for MsgCode and count */
				cm_buf_res_count();
			}
			
			cm_buf_put("%s %s %s %s %s %s %s ",data_yyyymm,idata,ipolicy,iendorse,iins_type,iins_main,iedr_type);
			tmp_len = cm_buf_len(tmpbuf);
			if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
			{
				memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
				repbuf_len += tmp_len;
				count++;
			}
			else                               /* more than 4K, send to client side */
			{
				cm_buf_init(ReplyBuf);
				cm_buf_put_msg(M_CM_OK);
				cm_buf_put_count(count);
				if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
				{
					$CLOSE q_cur;
					return apiRC;
				}
				else               /* clear ReplyBuf and count to start all over again */
				{
					replycnt++;
					if (replycnt == 10)   /* more than 30K, client cannot display,error */
					{
						cm_buf_init(ReplyBuf);
						cm_buf_put("%l",M_CM_OUT_SPACE);
						tmp_len = cm_buf_len(ReplyBuf);
						if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
						return apiRC;
						return M_CM_OUT_SPACE;
					}
					ReplyBuf[0] = '\0';
					count = 0;
					cm_buf_init(ReplyBuf);
					cm_buf_res_msg();           /* reserve for MsgCode and count */
					cm_buf_res_count();
					cm_buf_put("%s %s %s %s %s %s %s ",data_yyyymm,idata,ipolicy,iendorse,iins_type,iins_main,iedr_type);
					repbuf_len = cm_buf_len(ReplyBuf);
					count++;
				}
			}
		} /* for loop */
	}
	$CLOSE mq_ply_edr;
	
	if (count > 0)   /* break out, at least one record is selected */
	{
		cm_buf_init(ReplyBuf);
		cm_buf_put_msg(M_CM_OK);
		cm_buf_put_count(count);
		if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
			return apiRC;
		return api_OKComplete;
	}
	else            /* break out, not any row is found */
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
			return M_CM_NOT_FOUND;                               /*?*/
		else
			return apiRC;
	}

errexit:
	if(exitsub(reply,SQLCODE) == True)
		return SQLCODE;
	else
		return apiRC;
}

long car176_multiple_query_YZ(reply)
serverReply reply;
{
	$char DBName[5],data_yyyymm_in[7],idata_in[2],iclaim_in[21],istl_in[21],iclose_type_in[5],iins_type_in[7],iins_main_in[7],iins_type_class_in[3];
	$char userid[11],stmt[1024],v_sMsg[2040],stmp[128];
	$char data_yyyymm[7],idata[2],iclaim[21],istl[21],iins_type[7],iins_main[7],iins_type_class[3];
	$long iclose_type = 0;
	$long sToday,ply2_begin,sLdeffect;
	char tmpbuf[4000];
	int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
	int i,total_count=0;
	int top_40 = 0,top_20 = 0 ,rc;
	
	cm_buf_get("%s %s %s %s %s %s %s %s %s ",DBName,data_yyyymm_in,idata_in,iclaim_in,istl_in,iclose_type_in,iins_type_in,iins_main_in,iins_type_class_in);
	strcpy(iclaim_in,trim(iclaim_in));
	strcpy(iclose_type_in,trim(iclose_type_in));
	
	if(strcmp(iclose_type_in,"*")==0)
		strcpy(stmp," ");
	else 
		sprintf_s(stmp, sizeof stmp,"iclose_type = %s",iclose_type);
	
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
		return M_CM_DB_NOTOPEN;
		else
		return apiRC;
	}
	
	if ( (list=get_db_list(&count_db,DBName)) == (char*)0 ) {
		printf("get_db_list error accur \n");
		return SQLCODE;
	}
	for(int k=0 ; k<count_db ; k++)
	{
	
		sprintf_s(stmt, sizeof stmt,"SELECT data_yyyymm,idata,iclaim,istl,iclose_type,iins_type,iins_main,iins_type_class "
		               " FROM %s:ca_dev_clm  "
		              " WHERE data_yyyymm matches '%s' "
		                " AND idata       matches '%s' "
		                " AND iclaim      matches '%s' "
		                " AND istl        matches '%s' "
		                " %s "
		                " AND iins_type   matches '%s' "
		                " AND iins_main   matches '%s' "
		                " AND iins_type_class matches '%s' ",list[k].dbname,data_yyyymm_in,idata_in,iclaim_in,istl_in,stmp,iins_type_in,iins_main_in,iins_type_class_in);	
		printf("stmt[%s]\n",stmt);
		$PREPARE mq_clms FROM $stmt;
		$DECLARE mq_clm CURSOR FOR mq_clms;
		$OPEN mq_clm;
		
		for(;;)
		{	
			$FETCH mq_clm INTO $data_yyyymm,$idata,$iclaim,$istl,$iclose_type,$iins_type,$iins_main,$iins_type_class;
			
			if (SQLCODE != 0) break;
			cm_buf_init(tmpbuf);
			if ( count == 0 )
			{
				cm_buf_res_msg();             /* reserve for MsgCode and count */
				cm_buf_res_count();
			}
			
			cm_buf_put("%s %s %s %s %d %s %s %s",data_yyyymm,idata,iclaim,istl,iclose_type,iins_type,iins_main,iins_type_class);
			tmp_len = cm_buf_len(tmpbuf);
			if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
			{
				memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
				repbuf_len += tmp_len;
				count++;
			}
			else                               /* more than 4K, send to client side */
			{
				cm_buf_init(ReplyBuf);
				cm_buf_put_msg(M_CM_OK);
				cm_buf_put_count(count);
				if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
				{
					$CLOSE q_cur;
					return apiRC;
				}
				else               /* clear ReplyBuf and count to start all over again */
				{
					replycnt++;
					if (replycnt == 10)   /* more than 30K, client cannot display,error */
					{
						cm_buf_init(ReplyBuf);
						cm_buf_put("%l",M_CM_OUT_SPACE);
						tmp_len = cm_buf_len(ReplyBuf);
						if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
						return apiRC;
						return M_CM_OUT_SPACE;
					}
					ReplyBuf[0] = '\0';
					count = 0;
					cm_buf_init(ReplyBuf);
					cm_buf_res_msg();           /* reserve for MsgCode and count */
					cm_buf_res_count();
					cm_buf_put("%s %s %s %s %d %s %s %s",data_yyyymm,idata,iclaim,istl,iclose_type,iins_type,iins_main,iins_type_class);
					repbuf_len = cm_buf_len(ReplyBuf);
					count++;
				}
			}
		} /* for loop */
	}
	$CLOSE mq_clm;
	
	if (count > 0)   /* break out, at least one record is selected */
	{
		cm_buf_init(ReplyBuf);
		cm_buf_put_msg(M_CM_OK);
		cm_buf_put_count(count);
		if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
			return apiRC;
		return api_OKComplete;
	}
	else            /* break out, not any row is found */
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
			return M_CM_NOT_FOUND;                               /*?*/
		else
			return apiRC;
	}

errexit:
	if(exitsub(reply,SQLCODE) == True)
		return SQLCODE;
	else
		return apiRC;
}

long car176_update_exec_WX(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	$char stmt[4096],DBName[5],sFullName[21];
	$char data_yyyymm[7],idata[2],ipolicy[21],iendorse[21],iins_type[7],iins_main[7],iedr_type_tmp[3];
	$char iarea[3],iissue_ym[7],ipro_ym[7],ibrand[9],icar_type_ori[3],icar_type[3],icar_type_no[3];
	$char iengine[26],itag[13],fpt[2],iassured[11],dbirth_y[5],fsex[2],fmarriage[2];
	$char iins_type_main[7],iins_type_dtl[7],iedr_type_ori[3],iedr_type[3];
	$char iins_type_dev[5],iins_type_rule[3],frule[2],ubi_data[9],fmdeduct[2];
	$long qcylinder,qpt,p_mcar_price,qdmg_acc_year,qdmg_acc_time,pdepreciate_year,padjust_rate;
	$long minjured_cover,mdeath_cover,mdamage_cover,mdamage_cover_bak,mdamage_cover_aft,iins_mult,mdeduct;
	
	$char pins_acc_tmp[7],psex_age_tmp[7];
	dec_t dec_pins_acc,dec_psex_age;
	$double pins_acc,psex_age;
	
	char  option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
	int   tmp_len,raw_len;
	long  dummy;
	long  MsgCode;
	DBinfo *list;
	int   i, j, is_del_fail=0, is_upd_fail=0;
	$char stmt_buf[300];

	comm = (char *) command;
	cm_buf_init(command);
	cm_buf_get("%c %s %s %s %s %s %s %s %s ",&option,DBName,data_yyyymm,idata,ipolicy,iendorse,iins_type,iins_main,iedr_type_tmp);
	
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}
	
	if(idata[0] == 'W')
		strcpy(sFullName, get_car_full_db(ipolicy));
 	else 
 		strcpy(sFullName, get_car_full_db(iendorse));
 		
	$BEGIN WORK;
		
	/*cm_buf_get("%c %s %s %s %s %s %s %s %s",&option,DBName,data_yyyymm,idata,ipolicy,iendorse,iins_type,iins_main,iedr_type_tmp);*/
	cm_buf_get("%s %s %s %s %s %s %s %d ",iarea,iissue_ym,ipro_ym,ibrand,icar_type_ori,icar_type,icar_type_no,&qcylinder);
	cm_buf_get("%s %s %d %s %s %s %s %s %s ",iengine,itag,&qpt,fpt,iassured,dbirth_y,fsex,fmarriage,iins_type_main);
	cm_buf_get("%s %s %s %s %s %s ",iins_type_dtl,iedr_type_ori,iedr_type,iins_type_dev,iins_type_rule,frule);
	cm_buf_get("%d %d %s %d %d %s ",&padjust_rate,&p_mcar_price,pins_acc_tmp,&qdmg_acc_year,&qdmg_acc_time,psex_age_tmp);
	cm_buf_get("%d %s %d %d %d ",&pdepreciate_year,&ubi_data,&minjured_cover,&mdeath_cover,&mdamage_cover);
	cm_buf_get("%d %d %d %s %d ",&mdamage_cover_bak,&mdamage_cover_aft,&iins_mult,fmdeduct,&mdeduct);
	
	printf("iarea[%s] iissue_ym[%s] ipro_ym[%s] ibrand[%s] icar_type_ori[%s] icar_type[%s] icar_type_no[%s] qcylinder[%d] \n",iarea,iissue_ym,ipro_ym,ibrand,icar_type_ori,icar_type,icar_type_no,qcylinder);
	printf("iengine[%s] itag[%s] qpt[%d] fpt[%s] iassured[%s] dbirth_y[%s] fsex[%s] fmarriage[%s] iins_type_main[%s] \n",iengine,itag,qpt,fpt,iassured,dbirth_y,fsex,fmarriage,iins_type_main);
	printf("iins_type_dtl[%s] iedr_type_ori[%s] iedr_type[%s] iins_type_dev[%s] iins_type_rule[%s] frule[%s] \n",iins_type_dtl,iedr_type_ori,iedr_type,iins_type_dev,iins_type_rule,frule);
	printf("padjust_rate[%d] p_mcar_price[%d] pins_acc_tmp%s] qdmg_acc_year[%d] qdmg_acc_time[%d] psex_age_tmp[%s] \n",padjust_rate,p_mcar_price,pins_acc_tmp,qdmg_acc_year,qdmg_acc_time,psex_age_tmp);
	printf("pdepreciate_year[%d] ubi_data[%s] minjured_cover[%d] mdeath_cover[%d] mdamage_cover[%d] \n",pdepreciate_year,ubi_data,minjured_cover,mdeath_cover,mdamage_cover);
	printf("mdamage_cover_bak[%d] mdamage_cover_aft[%d] iins_mult[%d] fmdeduct[%s] mdeduct[%d] \n",mdamage_cover_bak,mdamage_cover_aft,iins_mult,fmdeduct,mdeduct);
	
	/** convert from string to DECIMAL type **/
	deccvasc(pins_acc_tmp,strlen(pins_acc_tmp),&dec_pins_acc);
	dectodbl(&dec_pins_acc,&pins_acc);
	deccvasc(psex_age_tmp,strlen(psex_age_tmp),&dec_psex_age);
	dectodbl(&dec_psex_age,&psex_age);
	printf("%s %s \n",pins_acc_tmp,psex_age_tmp);
	printf("pins_acc[%f] psex_age[%f] \n",pins_acc,psex_age);
	
	/* �ݩ�򥻸�Ƴ����A�O���㵧�� */
	sprintf_s(stmt, sizeof stmt,"UPDATE %s:ca_dev_ply_edr "
	                " SET (iarea,iissue_ym,ipro_ym,ibrand,icar_type_ori,icar_type,icar_type_no,qcylinder, "
	                     " iengine,itag,qpt,fpt,iassured,dbirth_y,fsex,fmarriage,ubi_data) "
	                  " = ('%s','%s','%s','%s','%s','%s','%s', %d , "
	                     " '%s','%s', %d ,'%s','%s','%s','%s','%s','%s') "
	               " WHERE data_yyyymm = '%s' "
	                 " AND idata       = '%s' "
	                 " AND ipolicy     = '%s' "
	                 " AND iendorse    = '%s' "
	                 " AND iedr_type   = '%s' ",sFullName,
	                                           iarea,iissue_ym,ipro_ym,ibrand,icar_type_ori,icar_type,icar_type_no,qcylinder,
	                                           iengine,itag,qpt,fpt,iassured,dbirth_y,fsex,fmarriage,ubi_data,
	                                           data_yyyymm,idata,ipolicy,iendorse,iedr_type_tmp);
	printf("stmt[%s]\n",stmt);
	$PREPARE upd_ply_edr1 FROM $stmt;
	$EXECUTE upd_ply_edr1;
	if(sqlca.sqlerrd[2] == 0)
	{
		  printf("no rows has been updated then insert it\n");
	}
	
	sprintf_s(stmt, sizeof stmt,"UPDATE %s:ca_dev_ply_edr "
	                " SET (iins_type_main,iins_type_dtl,iedr_type_ori,iedr_type,iins_type_dev,iins_type_rule,frule, "
	                     " padjust_rate,p_mcar_price,pins_acc,qdmg_acc_year,qdmg_acc_time,psex_age, "
	                     " pdepreciate_year,minjured_cover,mdeath_cover,mdamage_cover, "
	                     " mdamage_cover_bak,mdamage_cover_aft,iins_mult,fmdeduct,mdeduct) "
	                  " = ('%s','%s','%s','%s','%s','%s','%s', "
	                      " %d , %d ,%.2f, %d , %d ,%.2f, "
	                      " %d , %d , %d , %d , "
	                      " %d , %d , %d ,'%s', %d ) "
	               " WHERE data_yyyymm = '%s' "
	                 " AND idata       = '%s' "
	                 " AND ipolicy     = '%s' "
	                 " AND iendorse    = '%s' "
	                 " AND iins_type   = '%s' "
	                 " AND iins_main   = '%s' "
	                 " AND iedr_type   = '%s' ",sFullName,
	                                           iins_type_main,iins_type_dtl,iedr_type_ori,iedr_type,iins_type_dev,iins_type_rule,frule,
	                                           padjust_rate,p_mcar_price,pins_acc,qdmg_acc_year,qdmg_acc_time,psex_age,
	                                           pdepreciate_year,minjured_cover,mdeath_cover,mdamage_cover,
	                                           mdamage_cover_bak,mdamage_cover_aft,iins_mult,fmdeduct,mdeduct,
	                                           data_yyyymm,idata,ipolicy,iendorse,iins_type,iins_main,iedr_type_tmp);
	printf("stmt[%s]\n",stmt);
	$PREPARE upd_ply_edr2 FROM $stmt;
	$EXECUTE upd_ply_edr2;

	if(sqlca.sqlerrd[2] == 0)
	{
		  printf("no rows has been updated then insert it\n");
	}
	
	cm_buf_init(ReplyBuf);
	cm_buf_put("%l",M_CM_OK);
	tmp_len = cm_buf_len(ReplyBuf);
	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
	{
		$WHENEVER SQLERROR CONTINUE;
		$ROLLBACK WORK;
		return apiRC;
	}
	$WHENEVER SQLERROR GOTO errexit;
	$COMMIT WORK;
	return api_OKComplete;
	
errexit:
	MsgCode = SQLCODE;
	$WHENEVER SQLERROR CONTINUE;
	$ROLLBACK WORK;              /* rollback fail */
	if(SQLCODE != 0) MsgCode = SQLCODE;
	if(exitsub(reply,MsgCode) == True)
	 return MsgCode;
	else
	 return apiRC;
}

long car176_update_exec_YZ(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	$char stmt[4096],DBName[5],sFullName[21];
	$char data_yyyymm[7],idata[2],iclaim[21],istl[3],iins_type[7],iins_main[7],iins_type_class[3];
	$long iclose_type_tmp;
	$char sIbranch_in[3];

	$char iissue_ym[7],ipro_ym[7],ibrand[9],icar_type_ori[3],icar_type[3],icar_type_no[3],iengine[26];
	$char itag[13],fpt[2],iacc_license[11],iacc_birth_y[5],facc_sex[2],facc_marri[2],iacc_reason[3],fduty[2];
	$char iassured[11],dbirth_y[5],fsex[2],fmarriage[2],daccident[9],dvp_code1[3],dvp_code2[3],fpart[2];
	$char ipdmg_align[2],ipbrg_align[2],iplia_align[2],iins_type_main[2],iins_type_dtl[3],iins_type_dev[5],iins_type_rule[3],frule[3];
	$char ubi_data[9],fmdeduct[2],fstl[2],bzfrom[3],fsingle_acc[5],adjustment[7],ifacnum[11];
	$long iclose_type,qcylinder,qpt,qlia1,qlia2,qlia3,p_mcar_price,pdepreciate_year,mcover,iins_mult,mdeduct,qpeople,iself_duty,ioth_duty,ianoth_duty,mdeduct_clm;
	
	$char pins_acc_tmp[7],psex_age_tmp[7];
	dec_t dec_pins_acc,dec_psex_age;
	$double pins_acc,psex_age;
	
	char  option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
	int   tmp_len,raw_len;
	long  dummy;
	long  MsgCode;
	DBinfo *list;
	int   i, j, is_del_fail=0, is_upd_fail=0;
	$char stmt_buf[300];

	comm = (char *) command;
	cm_buf_init(command);
	cm_buf_get("%c %s %s %s %s %s %d %s %s %s ",&option,DBName,data_yyyymm,idata,iclaim,istl,&iclose_type_tmp,iins_type,iins_main,iins_type_class);
	
	$WHENEVER SQLERROR GOTO errexit;
	$BEGIN WORK;
	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}
	
	/* ���o�߮׸�Ʈw */
	$SELECT ibranch_in
	   INTO $sIbranch_in
	   FROM ca_clm_process
	  WHERE iclaim = $iclaim;
	  
	strcpy(sFullName, get_full_dbname(sIbranch_in));
	
	cm_buf_get("%s %s %s %s %s %s %d %s ",iissue_ym,ipro_ym,ibrand,icar_type_ori,icar_type,icar_type_no,&qcylinder,iengine);
	cm_buf_get("%s %d %s %s %s %s %s %s %s ",itag,&qpt,fpt,iacc_license,iacc_birth_y,facc_sex,facc_marri,iacc_reason,fduty);
	cm_buf_get("%s %s %s %s %d %d %d %s %s %s ",iassured,dbirth_y,fsex,fmarriage,&qlia1,&qlia2,&qlia3,daccident,dvp_code1,dvp_code2);
	cm_buf_get("%s %s %s %s %s ",fpart,ipdmg_align,ipbrg_align,iplia_align,iins_type_main);
	cm_buf_get("%s %s %s %s %d %s ",iins_type_dtl,iins_type_dev,iins_type_rule,frule,&p_mcar_price,pins_acc_tmp);
	cm_buf_get("%s %d %s %d %d %s %d %d ",psex_age_tmp,&pdepreciate_year,ubi_data,&mcover,&iins_mult,fmdeduct,&mdeduct,&qpeople);
	cm_buf_get("%d %d %d %d %s %s %s %s %s ",&iself_duty,&ioth_duty,&ianoth_duty,&mdeduct_clm,fstl,bzfrom,fsingle_acc,adjustment,ifacnum);
	
	printf("iissue_ym[%s] ipro_ym[%s] ibrand[%s] icar_type_ori[%s] icar_type[%s] icar_type_no[%s] qcylinder[%d] iengine[%s] \n",iissue_ym,ipro_ym,ibrand,icar_type_ori,icar_type,icar_type_no,qcylinder,iengine);
	printf("itag[%s] qpt[%d] fpt[%s] iacc_license[%s] iacc_birth_y[%s] facc_sex[%s] facc_marri[%s] iacc_reason[%s] fduty[%s] \n",itag,qpt,fpt,iacc_license,iacc_birth_y,facc_sex,facc_marri,iacc_reason,fduty);
	printf("iassured[%s] dbirth_y[%s] fsex[%s] fmarriage[%s] qlia1[%d] qlia2[%d] qlia3[%d] daccident[%s] dvp_code1[%s] dvp_code2[%s] \n",iassured,dbirth_y,fsex,fmarriage,qlia1,qlia2,qlia3,daccident,dvp_code1,dvp_code2);
	printf("fpart[%s] ipdmg_align[%s] ipbrg_align[%s] iplia_align[%s] iins_type_main[%s] \n",fpart,ipdmg_align,ipbrg_align,iplia_align,iins_type_main);
	printf("iins_type_dtl[%s] iins_type_dev[%s] iins_type_rule[%s] frule[%s] p_mcar_price[%d] pins_acc_tmp[%s] \n",iins_type_dtl,iins_type_dev,iins_type_rule,frule,p_mcar_price,pins_acc_tmp);
	printf("psex_age_tmp[%s] pdepreciate_year[%d] ubi_data[%s] mcover[%d] iins_mult[%d] fmdeduct[%s] mdeduct[%d] qpeople[%d] \n",psex_age_tmp,pdepreciate_year,ubi_data,mcover,iins_mult,fmdeduct,mdeduct,qpeople);
	printf("iself_duty[%d] ioth_duty[%d] ianoth_duty[%d] mdeduct_clm[%d] fstl[%s] bzfrom[%s] fsingle_acc[%s] adjustment[%s] ifacnum[%s] \n",iself_duty,ioth_duty,ianoth_duty,mdeduct_clm,fstl,bzfrom,fsingle_acc,adjustment,ifacnum);
	
	/** convert from string to DECIMAL type **/
	deccvasc(pins_acc_tmp,strlen(pins_acc_tmp),&dec_pins_acc);
	dectodbl(&dec_pins_acc,&pins_acc);
	deccvasc(psex_age_tmp,strlen(psex_age_tmp),&dec_psex_age);
	dectodbl(&dec_psex_age,&psex_age);
	printf("%s %s \n",pins_acc_tmp,psex_age_tmp);
	printf("pins_acc[%f] psex_age[%f] \n",pins_acc,psex_age);
	
	/* �ݩ�򥻸�Ƴ����A�׸��㵧�� */
	sprintf_s(stmt, sizeof stmt,"UPDATE %s:ca_dev_clm "
	                " SET (iissue_ym,ipro_ym,ibrand,icar_type_ori,icar_type,icar_type_no,qcylinder,iengine, "
	                     " itag,qpt,fpt,iacc_license,iacc_birth_y,facc_sex,facc_marri,iacc_reason,fduty, "
	                     " iassured,dbirth_y,fsex,fmarriage,daccident,dvp_code1,dvp_code2, "
	                     " fpart,ubi_data, "
	                     " iself_duty,ioth_duty,ianoth_duty,fstl,bzfrom,fsingle_acc,adjustment,ifacnum) "
	                  " = ('%s','%s','%s','%s','%s','%s', %d ,'%s', "
	                     " '%s', %d ,'%s','%s','%s','%s','%s','%s','%s', "
	                     " '%s','%s','%s','%s','%s','%s','%s', "
	                     " '%s','%s', "
	                     "  %d , %d , %d ,'%s','%s','%s','%s','%s') "
	              " WHERE data_yyyymm = '%s' "
	                " AND idata       = '%s' "
	                " AND iclaim      = '%s' "
	                " AND istl        = '%s' "
	                " AND iclose_type =  %d ",sFullName,
                                            iissue_ym,ipro_ym,ibrand,icar_type_ori,icar_type,icar_type_no,qcylinder,iengine,
                                            itag,qpt,fpt,iacc_license,iacc_birth_y,facc_sex,facc_marri,iacc_reason,fduty, 
                                            iassured,dbirth_y,fsex,fmarriage,daccident,dvp_code1,dvp_code2, 
                                            fpart,ubi_data,
                                            iself_duty,ioth_duty,ianoth_duty,fstl,bzfrom,fsingle_acc,adjustment,ifacnum,
                                            data_yyyymm,idata,iclaim,istl,iclose_type_tmp);
	printf("stmt[%s]\n",stmt);
	$PREPARE upd_clm1 FROM $stmt;
	$EXECUTE upd_clm1;

	if(sqlca.sqlerrd[2] == 0)
	{
		  printf("no rows has been updated then insert it\n");
	}
	
	sprintf_s(stmt, sizeof stmt,"UPDATE %s:ca_dev_clm "
	                " SET (qlia1,qlia2,qlia3, "
	                     " ipdmg_align,ipbrg_align,iplia_align,iins_type_main, "
	                     " iins_type_dtl,iins_type_dev,iins_type_rule,frule,p_mcar_price,pins_acc, "
	                     " psex_age,pdepreciate_year,mcover,iins_mult,fmdeduct,mdeduct,qpeople,mdeduct_clm) "
	                  " = ( %d , %d ,%d ,  "
	                     " '%s','%s','%s','%s', "
	                     " '%s','%s','%s','%s', %d ,%.2f, "
	                     " %.2f, %d , %d , %d ,'%s', %d , %d , %d ) "
	              " WHERE data_yyyymm     = '%s' "
	                " AND idata           = '%s' "
	                " AND iclaim          = '%s' "
	                " AND istl            = '%s' "
	                " AND iclose_type     =  %d  "
	                " AND iins_type       = '%s' "
	                " AND iins_main       = '%s' "
	                " AND iins_type_class = '%s' ",sFullName,
                                                  qlia1,qlia2,qlia3,
                                                  ipdmg_align,ipbrg_align,iplia_align,iins_type_main, 
                                                  iins_type_dtl,iins_type_dev,iins_type_rule,frule,p_mcar_price,pins_acc, 
                                                  psex_age,pdepreciate_year,mcover,iins_mult,fmdeduct,mdeduct,qpeople,mdeduct_clm,
                                                  data_yyyymm,idata,iclaim,istl,iclose_type_tmp,iins_type,iins_main,iins_type_class);
	printf("stmt[%s]\n",stmt);
	$PREPARE upd_clm2 FROM $stmt;
	$EXECUTE upd_clm2;

	if(sqlca.sqlerrd[2] == 0)
	{
		  printf("no rows has been updated then insert it\n");
	}
	
	cm_buf_init(ReplyBuf);
	cm_buf_put("%l",M_CM_OK);
	tmp_len = cm_buf_len(ReplyBuf);
	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
	{
		$WHENEVER SQLERROR CONTINUE;
		$ROLLBACK WORK;
		return apiRC;
	}
	$WHENEVER SQLERROR GOTO errexit;
	$COMMIT WORK;
	return api_OKComplete;

errexit:
	MsgCode = SQLCODE;
	$WHENEVER SQLERROR CONTINUE;
	$ROLLBACK WORK;              /* rollback fail */
	if(SQLCODE != 0) MsgCode = SQLCODE;
	if(exitsub(reply,MsgCode) == True)
	 return MsgCode;
	else
	 return apiRC;
}
