/************************************************/
/*                                              */
/*   PROGRAM : ca1001q01s.ec                    */
/*   MODIFIER: Johnny Kuo 11/28/1997            */
/*             S.Y.HWANG FOR ISPS               */
/*                                              */
/*   REMEMBER TO MODIFY car1001.ec (rexec)      */
/*                                              */
/*   Modify  : 11/02/2006 �̫Ȥ����ëO����    */
/************************************************/

#include <stdio.h>

#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "carmsgs.h"
#include "rinmsgs.h"
#include "carday.h"
#include "car_equip.h"

$include "ply_ins_assured.h";
$include sqlca;
$include decimal.h;
#define MAXDB 15
#define EQUAL(s1,s2)            !strcmp(s1,s2)
#define TRUE  1
#define FALSE 0
#define SUCCESS 1

#define _TONY860619

extern struct sEquip *IfirstEquip, *IcurrEquip, *IlastEquip, *IEquip_ptr;
$char   equipdecode[201], sUserid[11],sMsg[512],o_sDeny_msg[512],o_sFply_chk[2];
char     sColumn[21], sTable[21], sDbname[21], v_sMsg[1512];
char   sTmpcode[6];
int	   iTmpcode;
long    rtncode;
$int    iUnDeny;
$char   sStmt[4096];
struct PLY_INS_ASSURED *get_ply_ins_assured();
$int iCountDeny,iCountFunsale;

$char funrenew[2],funquery[2],fundelete[2];
$char tmp_feply[2],tmpp_feply[2],feply1[2],feply2[2];
$char aemail_eply[51],dcreate_eply[20];

/*********************************************************************/
long car1001(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
$char DBName[5];
    long rtncode;
    long car1001_multiple_query1(), car1001_multiple_query2();
    long car1001_multiple_query3(), car1001_multiple_query4();
    long car1001_multiple_query5(), car1001_multiple_query6();
    long car1001_multiple_query7(), car1001_multiple_query8();
    long car1001_multiple_query9(), car1001_multiple_querya();
    long car1001_multiple_queryc(), car1001_multiple_queryd();
    long car1001_multiple_querye(), car1001_multiple_queryf();
    long car1001_multiple_queryg(), car1001_multiple_queryh();
    long car1001_multiple_queryi(), car1001_multiple_queryj();
    long car1001_multiple_queryk(), car1001_multiple_queryl();
    long car1001_multiple_querym(), car1001_multiple_queryn();
    long car1001_multiple_queryo(), car1001_multiple_queryu();
    long car1001_multiple_queryv(), car1001_multiple_queryw();
    long car1001_multiple_queryx(), car1001_multiple_queryb();
    long car1001_multiple_queryp(), car1001_multiple_queryb1();
    long Check_reject_client(),car1001_print(),car1001_endorse_print(),car1001_rpt_get();
    long car1001_query_no_dplyclose();

    int accchk_plyins();

    char option;

    printf("##### car1001 begin\n");

    cm_buf_init(command);
    cm_buf_get("%c",&option);
    printf("option[%c]\n",option);

    switch(option)
    {
         case '1': /* �d/���� */
                  rtncode=car1001_multiple_query1(reply);
                  break;
         case '2': /* ��� */
                  rtncode=car1001_multiple_query2(reply);
                  break;
         case '3': /* �߮� */
                  rtncode=car1001_multiple_query3(reply);
                  break;
         case '4': /* clos_num */
                  rtncode=car1001_multiple_query4(reply);
                  break;
         case '5': /* �Q�O�I�H*/
                  rtncode=car1001_multiple_query5(reply);
                  break;
         case '6': /* �O�渹�X */
                  rtncode=car1001_multiple_query6(reply);
                  break;
         case '7': /* �P�� */
                  rtncode=car1001_multiple_query7(reply);
                  break;
         case '8': /* ������ */
                  rtncode=car1001_multiple_query8(reply);
                  break;
         case '9': /* ������ */
                  rtncode=car1001_multiple_query9(reply);
                  break;
         case 'b': /* �����O�T�渹multiple search */
         	  		rtncode=car1001_multiple_queryb1(reply);
         	  		break;
         case 'i': /* ��A�U�z�B��A�� */
         	  rtncode=car1001_multiple_queryi1(reply);
         	  break;
         case 'l': /* �޲z�H�N�� */
         	  rtncode=car1001_multiple_queryl1(reply);
         	  break;
         case 'A': /* �̷s�O�� */
                  printf("querya begin\n");
                  rtncode=car1001_multiple_querya(reply);
                  break;
         /* Add car extended */
         case 'B': /* �����O�T */
         	  rtncode=car1001_multiple_queryb(reply);
         	  break;
         case 'C': /* ������� */
                  rtncode=car1001_multiple_queryc(reply);
                  break;
         case 'D': /* ���p��� */
                  rtncode=car1001_multiple_queryd(reply);
                  break;
         case 'E': /*�����X�I����*/
                  rtncode=car1001_multiple_querye(reply);
                  break;
         case 'F': /* ���p�߮� */
                  rtncode=car1001_multiple_queryf(reply);
                  break;
         case 'G': /* ���`�̸�� */
                  rtncode=car1001_multiple_queryg(reply);
                  break;
         case 'H': /* �X�I�J�` */
                  rtncode=car1001_multiple_queryh(reply);
                  break;
         case 'I': /* �O�榬�O���p�d�� */
                  rtncode=car1001_multiple_queryi(reply);
                  break;
         case 'J':
                  rtncode=car1001_multiple_queryj(reply);
                  break;
         case 'K': /* ��l�O�� */
                  rtncode=car1001_multiple_queryk(reply);
                  break;
         case 'L':  /* �ߴڰO�� */
                  rtncode=car1001_multiple_queryl(reply);
                  break;
         case 'M':  /* �j�O��O�� */
                  rtncode=car1001_multiple_querym(reply);
                  break;
         case 'N':  /* �j�O���l�O�� */
                  rtncode=car1001_multiple_queryn(reply);
                  break;
         case 'O':  /* �������r���d�� */
                  rtncode=car1001_multiple_queryo(reply);
                  break;
         case 'P':  /* ���ëO�� */
                  rtncode=car1001_multiple_queryp(reply);
                  break;
         case 'Q':
                  printf(" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL \n");
                  rtncode=car1001_print(reply);
                  break;
         case 'R': /*�C�L���ӽЮ�*/

                  cm_buf_get("%s",DBName);
                  if (db_select(DBName) == False)
                          return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

                  $CREATE TEMP TABLE ca1001_tmp
                  ( ipolicy    char(20)
                  ) with no log;
                  puts("create temp table ok");

                  rtncode = car1001_endorse_print(reply);

                  $DROP TABLE ca1001_tmp;

                  break;
         case 'S':
                  rtncode=query_ply_ins_assured(reply);
                  break;
         case 'U':  /* �ˮ`�I�d�� */
                  rtncode=car1001_multiple_queryu(reply);
                  break;
         case 'V':  /* �a�x�����d���I�d�� */
                  rtncode=car1001_multiple_queryv(reply);
                  break;
         case 'W':  /* �����r�p�ˮ`�I�d�� */
                  rtncode=car1001_multiple_queryw(reply);
                  break;
         case 'X':  /* �ĤT�H�d�����[�r�p�ˮ`�I�d�� */
                  rtncode=car1001_multiple_queryx(reply);
                  break;
         case 'Z':
                  rtncode=Check_reject_client(reply);
                  break;
         case '!': /* �ˬduser�O�_���v���d�߸�ơA�^�Ȣ������v�� */
                  rtncode= check_user_inspect(reply);
                  break;
         default :
               return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
    }
    return(rtncode);
}

/*********************************************************************/

long car1001_endorse_print(reply)
serverReply reply;
{
        int rc,i,j,rtncode,tmp_len;
        char extern rptstr1001[10000], rptstr_dtl[10000];
        char rpttitle[10000];
        char sApHome[31],sTmpBuf[254], option;
        $char DBName[5], sFullName[21];
        $char stmt[1024];
        $char ipolicy[21], ipolicyBgn[21], ipolicyEnd[21], icardBgn[21], icardEnd[21];
        char sTmp0[51],file0[51], sdelimiter[2];
        char sTmp1[71],file1[51], outputf[31];
        time_t now;
        FILE  *fp0;
        FILE  *fp1;
        char FullGetName[101], filename[31];

        $WHENEVER SQLERROR GOTO errexit;

        cm_buf_get("%c", &option);

        rc = getApHome(sApHome);
        if (rc < 0)
        {
            printf("read Config file error!!\n");
            return exitsub(reply,M_CM_READ_CONFIG_ERR) ? M_CM_READ_CONFIG_ERR : apiRC;
        }

        time(&now);
        sprintf(sTmp0,"policy_%ld.txt",now);
        sprintf(sTmp1,"policy_%ld_dtl.txt",now);

        sprintf(file0,"%s/rptftp/%s",sApHome,sTmp0);
        sprintf(file1,"%s/rptftp/%s",sApHome,sTmp1);

        fp0=fopen(file0,"w");
        fp1=fopen(file1,"w");

        if( option == '1')  			/* �浧�H�O�渹�C�L */
        {
            cm_buf_get("%s", ipolicy);
            strcpy(sFullName, get_car_full_db( ipolicy));
            sprintf( stmt, "INSERT INTO ca1001_tmp SELECT ipolicy FROM %s:ply_relation WHERE ipolicy = '%s'",
                            sFullName, ipolicy);
            $PREPARE prep1 FROM $stmt;
            $EXECUTE prep1;
            $FREE prep1;
        }
        else if( option == '2')  		/* ���H�O�渹�_�W�C�L */
        {
            cm_buf_get("%s %s", ipolicyBgn, ipolicyEnd);
            strcpy(sFullName, get_car_full_db( ipolicyBgn));
            sprintf( stmt, "INSERT INTO ca1001_tmp SELECT ipolicy FROM %s:ply_relation "
                           " WHERE ipolicy BETWEEN '%s' AND '%s' ",
                             sFullName, ipolicyBgn, ipolicyEnd);
            $PREPARE prep2 FROM $stmt;
            $EXECUTE prep2;
            $FREE prep2;
        }
        else if( option == '3')  		/* ���H�d���_�W�C�L */
        {
            cm_buf_get("%s %s", icardBgn, icardEnd);
            sprintf( stmt, "INSERT INTO ca1001_tmp SELECT ipolicy FROM ply_relation "
                           " WHERE ipolicy IN (SELECT ipolicy FROM ply_relation "
                           "                    WHERE icard BETWEEN '%s' AND '%s') ",
                             icardBgn, icardEnd);
            $PREPARE prep3 FROM $stmt;
            $EXECUTE prep3;
            $FREE prep3;
        }
        else if( option == '4')  		/* ���H��r�ɿ�J�h���O�渹�C�L */
        {
            cm_buf_get("%s ", filename);
            sprintf( FullGetName, "%s/dat/car/%s", sApHome, filename);
            strcpy( sdelimiter,  "\t");
            if ((rc=load_command1( FullGetName, outputf, "ca1001_tmp", sdelimiter)) != SUCCESS)
            {
                return exitsub(reply, -1) ?  -1 : apiRC;
            }
        }
        else
            return exitsub(reply, M_CM_WRONG_OPTION) ?  M_CM_WRONG_OPTION : apiRC;

        /* ca1001_tmp ��ipolicy�i�ର�d���ΫO�渹�Χ�渹 */
        $DECLARE curs1 CURSOR FOR
          SELECT distinct ipolicy FROM ca1001_tmp
           WHERE ipolicy <> ' '
           UNION
          SELECT distinct b.ipolicy FROM ca1001_tmp a, ply_relation b
           WHERE a.ipolicy = b.icard
             AND a.ipolicy <> ' '
           UNION
          SELECT distinct b.iendorse FROM ca1001_tmp a, edr_relation b
           WHERE a.ipolicy = b.iendorse
             AND a.ipolicy <> ' '
          ;

        $OPEN curs1;
        for(;;)
        {
            $FETCH curs1 INTO $ipolicy;
            if( SQLCODE == SQLNOTFOUND)
                break;
            rc = car1001_rpt_get(ipolicy);
            if(rc == 8888) /* �䤣���Ʈw�W��,�~��U�@�� */
                continue;
            else if(rc != M_CM_OK)
            {
                sprintf(sTmpBuf, "���ӽЮ�[%s] �C�L�����D", ipolicy);
                fclose(fp0);
                fclose(fp1);
                return exitsub(reply, rc) ?  rc : apiRC;
            }

            fprintf(fp0,"%s",rptstr1001);
            fprintf(fp1,"%s",rptstr_dtl);

            printf("%s\n",rptstr1001);
        }
        $CLOSE curs1;
        $FREE curs1;

        fclose(fp0);
        fclose(fp1);

        cm_buf_init(ReplyBuf);
        cm_buf_put("%l",M_CM_OK);
        cm_buf_put("%s %s",sTmp0, sTmp1);
        tmp_len = cm_buf_len(ReplyBuf);
        if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
                return apiRC;
        else
                return api_OKComplete;

errexit:
    printf("car1001_endorse_print:SOLERR:%s\n",sqlca.sqlerrm);
    fclose(fp0);
    fclose(fp1);
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/***** �d/����  *****/
long car1001_multiple_query1(reply)
serverReply reply;
{
     /* standard defined host variables */
     $char DBName[5];

     /* table assured_vs_ply */
     $char ipolicy[POLICY_NUM_1],itag[CA_TAG_NUM],nassured[41];
     $char ibody[21],iengine[21],icard[CARD_NUM];
     $char iassured[13];
     /* standard defined data */
     char tmpbuf[4000];
     int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
     int i,total_count=0;
     $char fcheckClose[2], stmt[4096];

     ipolicy[0]=itag[0]=nassured[0]=ibody[0]=iengine[0]=0;
     fcheckClose[0]=0;

     cm_buf_get("%s",DBName);
     cm_buf_get("%s %s %s",icard,sUserid,fcheckClose);

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
         return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
    
    /* fcheckClose 0:���鵲, 1:�w�鵲 */
    if (strcmp(trim(fcheckClose), "0") == 0)
    {
        printf("***** fcheckClose[%s] *****\n", fcheckClose);
   	    rtncode = car1001_query_no_dplyclose("1", icard);
   	    if (rtncode != M_CM_OK) return rtncode;
   	    strcpy(stmt, sStmt);
   	    printf("stmt[%s]\n", stmt);
    }
    else
    {
   	    sprintf(stmt, "SELECT DISTINCT ipolicy, iassured, nassured, itag \
                          FROM assured_vs_ply \
                         WHERE icard = '%s';", icard);
                         /* AND substr(ipolicy,6,2) <> 'VW';   Get rid of 'VW' data */
    }

     EXEC SQL PREPARE q_cur31_cur FROM :stmt;
     EXEC SQL DECLARE q_cur31 CURSOR FOR q_cur31_cur;
     EXEC SQL OPEN q_cur31;
     for(;;)
     {
        EXEC SQL FETCH q_cur31 INTO :ipolicy, :iassured, :nassured, :itag;
        if (SQLCODE != 0) break;

        /* �Y�Q�O�I�HQ201639145,��ܯS��ĵ�i�T��4450; Modified by Julia Han in 2007/06/04 */
        if (strcmp(trim(iassured),"Q201639145") == 0)
        {
        		return exitsub(reply,M_CA_IASSURED_WARNING) ? M_CA_IASSURED_WARNING :apiRC;
        }

        /* �Ӹ갱���ˮ� add by sylvia 103.02.17 (1020924002_C2) */
        iCountDeny=0;
         $select count(*),funrenew_ins[1,1],funquery_ins[1,1],fdelete_ins[1,1] 
            into $iCountDeny,$funrenew,$funquery,$fundelete
            from cm_personal_deny
           where iassured = $iassured
             and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
             and ddeny <= today
             and (dexpire is null or dexpire >= today)
             GROUP BY 2,3,4;
        if(iCountDeny > 0)
        {
            iUnDeny=0;
            /*�bcu_code_data.itype=CK ���]�w��,�i�H�d��*/ 
            $select count(*) into $iUnDeny
               from cu_code_data where itype = 'CK' and icode = $sUserid;
            if (iUnDeny == 0)
         	{
         		if (strcmp(trim(funrenew),"1") == 0)
            		return exitsub(reply,M_CA_PERSONAL_DENY_RENEW) ? M_CA_PERSONAL_DENY_RENEW :apiRC;
            	else if (strcmp(trim(funquery),"1") == 0)
            		return exitsub(reply,M_CA_PERSONAL_DENY_QUERY) ? M_CA_PERSONAL_DENY_QUERY :apiRC;
            	else if (strcmp(trim(fundelete),"1") == 0)
            		return exitsub(reply,M_CA_PERSONAL_DENY_DELETE) ? M_CA_PERSONAL_DENY_DELETE :apiRC;
            	else 
            		return exitsub(reply,M_CA_PERSONAL_DENY) ? M_CA_PERSONAL_DENY :apiRC;
         	}
        }

        cm_buf_init(tmpbuf);
        if (count == 0)
        {
             cm_buf_res_msg();             /* reserve for MsgCode and count */
             cm_buf_res_count();
        }
        cm_buf_put("%s %s %s ' ' ' ' ' ' ' '",ipolicy,itag,nassured);
        tmp_len = cm_buf_len(tmpbuf);
        if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
        {
            memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
            repbuf_len += tmp_len;
            count++;
        }
        else                               /* more than 4K, send to client side */
        {
            cm_buf_init(ReplyBuf);
            cm_buf_put_msg(M_CM_OK);
            cm_buf_put_count(count);
            if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
            {
                EXEC SQL CLOSE q_cur31;
                EXEC SQL FREE  q_cur31;
                return apiRC;
            }
            else               /* clear ReplyBuf and count to start all over again */
            {
                replycnt++;
                if (replycnt == 10)   /* more than 30K, client cannot display,error */
                {
                    cm_buf_init(ReplyBuf);
                    cm_buf_put("%l",M_CM_OUT_SPACE);
                    tmp_len = cm_buf_len(ReplyBuf);
                    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False) return apiRC;
                    return M_CM_OUT_SPACE;
                }
                ReplyBuf[0] = '\0';
                count = 0;
                cm_buf_init(ReplyBuf);
                cm_buf_res_msg();           /* reserve for MsgCode and count */
                cm_buf_res_count();
                cm_buf_put("%s %s %s ' ',' ',' '",ipolicy,itag,nassured);
                repbuf_len = cm_buf_len(ReplyBuf);
                count++;
            }
        }
     } /* for loop */


     printf("total_count[%d] \n",total_count);

     EXEC SQL CLOSE q_cur31;
     EXEC SQL FREE  q_cur31;
     if (count > 0)   /* break out, at least one record is selected */
     {
         cm_buf_init(ReplyBuf);
         cm_buf_put_msg(M_CM_OK);
         cm_buf_put_count(count);
         if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
             return apiRC;
         else
             return api_OKComplete;
     }
     else            /* break out, not any row is found */
     {
     	   if (strcmp(trim(fcheckClose), "0") == 0)
           return exitsub(reply,M_CA_NOREC_ERR) ? M_CA_NOREC_ERR :apiRC;
         else
           return exitsub(reply,M_CA_NASSURED_VS_PLY) ? M_CA_NASSURED_VS_PLY :apiRC;
     }

errexit:
    printf("SOLERR:%s\n",sqlca.sqlerrm);
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/***** �O�渹  *****/
long car1001_multiple_query6(reply)
serverReply reply;
{
    /* standard defined host variables */
    $char DBName[5];
    /* end of standard host var */

    /* table policy */
    $char ipolicy[POLICY_NUM_1],itag[CA_TAG_NUM],nassured[41];
    $char iassured[13];
    /* end of policy */

    /* standard defined data */
    char tmpbuf[4000];
    int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
    int i,total_count=0;
    /* end of standard data */
    $char fcheckClose[2], stmt[4096];

    /* self defined data */
    /* end of self data */

    ipolicy[0]=itag[0]=nassured[0]=fcheckClose[0]=0;

    cm_buf_get("%s",DBName);
    cm_buf_get("%s %s %s",ipolicy,sUserid,fcheckClose);

    EXEC SQL WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
       return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
       	
    /* fcheckClose 0:���鵲, 1:�w�鵲 */     	
    if (strcmp(trim(fcheckClose), "0") == 0)
    {
        printf("***** fcheckClose[%s] *****\n", fcheckClose);
   	    rtncode = car1001_query_no_dplyclose("6", ipolicy);
   	    if (rtncode != M_CM_OK) return rtncode;
   	    strcpy(stmt, sStmt);
   	    printf("stmt[%s]\n", stmt);
    }
    else
    {
   	    sprintf(stmt, "SELECT ipolicy, iassured, nassured, itag \
                         FROM assured_vs_ply \
                        WHERE ipolicy = '%s';", ipolicy);
                         /* AND substr(ipolicy,6,2) <> 'VW';   Get rid of 'VW' data */
    }

    EXEC SQL PREPARE ass_cur6_cursor FROM :stmt;
    EXEC SQL DECLARE ass_cur6 CURSOR FOR ass_cur6_cursor;
    EXEC SQL OPEN ass_cur6;
    for(;;)
    {
       EXEC SQL FETCH ass_cur6 INTO :ipolicy, :iassured, :nassured, :itag;
       if (SQLCODE != 0) break;

       /* �Y�Q�O�I�HQ201639145,��ܯS��ĵ�i�T��4450; Modified by Julia Han in 2007/06/04 */
        if (strcmp(trim(iassured),"Q201639145") == 0)
        {
        		return exitsub(reply,M_CA_IASSURED_WARNING) ? M_CA_IASSURED_WARNING :apiRC;
        	}

       /* �Ӹ갱���ˮ� add by sylvia 103.02.17 (1020924002_C2) */
        /*rtncode = chk_personal_deny( iassured, sMsg);
        if( rtncode == M_CA_PERSONAL_DENY)
        {
            iUnDeny=0;
            /* �bcu_code_data.itype=CK ���]�w��,�i�H�d�� 
            $select count(*) into $iUnDeny
               from cu_code_data where itype = 'CK' and icode = $sUserid;
            if (iUnDeny == 0)
               return exitsub(reply,M_CA_PERSONAL_DENY) ? M_CA_PERSONAL_DENY :apiRC;
        }*/
        iCountDeny=0;
        iCountFunsale=0;
         $select count(*),funrenew_ins[1,1],funquery_ins[1,1],fdelete_ins[1,1]
            into $iCountDeny,$funrenew,$funquery,$fundelete
            from cm_personal_deny
           where iassured = $iassured
             and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
             and ddeny <= today
             and (dexpire is null or dexpire >= today)
             GROUP BY 2,3,4;

         $select count(*) into $iCountFunsale
            from cm_personal_deny
           where iassured = $iassured
             and funsale_ins[1,1] = '1' 
             and ddeny <= today
             and (dexpire is null or dexpire >= today); 
             
        if(iCountDeny > 0)
        {
            iUnDeny=0;
            /*�bcu_code_data.itype=CK ���]�w��,�i�H�d��*/ 
            $select count(*) into $iUnDeny
               from cu_code_data where itype = 'CK' and icode = $sUserid;
            if (iUnDeny == 0)
         	{
         		if (strcmp(trim(funrenew),"1") == 0)
            		return exitsub(reply,M_CA_PERSONAL_DENY_RENEW) ? M_CA_PERSONAL_DENY_RENEW :apiRC;
            	else if (strcmp(trim(funquery),"1") == 0)
            		return exitsub(reply,M_CA_PERSONAL_DENY_QUERY) ? M_CA_PERSONAL_DENY_QUERY :apiRC;
            	else if (strcmp(trim(fundelete),"1") == 0)
            		return exitsub(reply,M_CA_PERSONAL_DENY_DELETE) ? M_CA_PERSONAL_DENY_DELETE :apiRC;
            	else 
            		return exitsub(reply,M_CA_PERSONAL_DENY) ? M_CA_PERSONAL_DENY :apiRC;
         	}
        }

       cm_buf_init(tmpbuf);
       if ( count == 0 )
       {
           cm_buf_res_msg();             /* reserve for MsgCode and count */
           cm_buf_res_count();
       }
       cm_buf_put("%s %s %s ' ' ' ' ' ' ' '",ipolicy,itag,nassured);
       tmp_len = cm_buf_len(tmpbuf);
       if (tmp_len + repbuf_len < 3000)   /* buffer size less than 4K */
       {
           memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
           repbuf_len += tmp_len;
           count++;
       }
       else                               /* more than 4K, send to client side */
       {
           cm_buf_init(ReplyBuf);
           cm_buf_put_msg(M_CM_OK);
           cm_buf_put_count(count);
           if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
           {
                EXEC SQL CLOSE ass_cur6;
                EXEC SQL FREE  ass_cur6;
                return apiRC;
           }
           else            /* clear ReplyBuf and count to start all over again */
           {
                replycnt++;
                if (replycnt == 10)   /* more than 30K, client cannot display,error */
                {
                     cm_buf_init(ReplyBuf);
                     cm_buf_put("%l",M_CM_OUT_SPACE);
                     tmp_len = cm_buf_len(ReplyBuf);
                     if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
                          return apiRC;
                     return M_CM_OUT_SPACE;
                }
                ReplyBuf[0] = '\0';
                count = 0;
                cm_buf_init(ReplyBuf);
                cm_buf_res_msg();           /* reserve for MsgCode and count */
                cm_buf_res_count();
                cm_buf_put("%s %s %s ' ' ' ' ' ' ' '",ipolicy,itag,nassured);
                repbuf_len = cm_buf_len(ReplyBuf);
                count++;
           }
       }
    } /* for loop */

    printf("count[%d]\n",count);

    EXEC SQL CLOSE ass_cur6;
    EXEC SQL FREE ass_cur6;

    if (count > 0)   /* break out, at least one record is selected */
    {
        cm_buf_init(ReplyBuf);
        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(count);
        if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
           return apiRC;
        else
           return api_OKComplete;
    }
    else            /* break out, not any row is found */
    {
       if (strcmp(trim(fcheckClose), "0") == 0)
           return exitsub(reply,M_CA_NOREC_ERR) ? M_CA_NOREC_ERR :apiRC;
       else
           return exitsub(reply,M_CA_NASSURED_VS_PLY) ? M_CA_NASSURED_VS_PLY :apiRC;
    }

errexit:
   printf("SOLERR:%s\n",sqlca.sqlerrm);
   return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/***** ��渹  *****/
long car1001_multiple_query2(reply)
serverReply reply;
{
     /* standard defined host variables */
     $char DBName[5], sFullName[20], stmt[1024];
     /* end of standard host var */

     /* table edr_relation,policy */
     $char iendorse[ENDORSE_NUM],ipolicy[POLICY_NUM_1],itag[CA_TAG_NUM],nassured[121];
     $char iassured[13],sdply_begin[11],sdply_end[11],iofficer[11],nofficer[11];
     $long dply_begin,dply_end;

     /* standard defined data */
     int tmp_len, fFound;

     iendorse[0]=ipolicy[0]=itag[0]=nassured[0]=0;

     cm_buf_get("%s",DBName);
     cm_buf_get("%s %s",iendorse, sUserid);

     if(db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     strncpy(DBName,iendorse,2);
     DBName[2]='\0';
     strcpy(sFullName, get_car_full_db(iendorse));

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     sprintf(stmt, "SELECT ipolicy \
                      FROM %s:edr_relation \
                     WHERE iendorse = '%s' ",sFullName, iendorse);
                       /* AND substr(ipolicy,6,2) <> 'VW'", sFullName, iendorse); */

     EXEC SQL PREPARE mq2_1 FROM :stmt;
     EXEC SQL DECLARE mq2_1_cursor CURSOR FOR mq2_1;
     EXEC SQL OPEN    mq2_1_cursor;
     EXEC SQL FETCH   mq2_1_cursor INTO :ipolicy;
     fFound = (SQLCODE == SQLNOTFOUND) ? 0 : 1;
     EXEC SQL CLOSE   mq2_1_cursor;
     EXEC SQL FREE    mq2_1_cursor;

     if(!fFound)
         return exitsub(reply,M_CA_NENDORSE) ? M_CA_NENDORSE : apiRC;

     sprintf(stmt, "SELECT itag, nassured, iassured, dply_begin, dply_end, iofficer, \
                           (select nname from officer where iofficer = b.iofficer) \
                      FROM %s:policy a, %s:ply_relation b \
                     WHERE a.ipolicy = '%s' \
                       AND a.ipolicy = b.ipolicy", sFullName, sFullName, ipolicy);

     EXEC SQL PREPARE mq2_2 FROM :stmt;
     EXEC SQL DECLARE mq2_2_cursor CURSOR FOR mq2_2;
     EXEC SQL OPEN    mq2_2_cursor;
     EXEC SQL FETCH   mq2_2_cursor INTO :itag, :nassured, :iassured, :dply_begin, :dply_end, :iofficer, :nofficer;
     fFound = (SQLCODE == SQLNOTFOUND) ? 0 : 1;

     /* ����B�z */
       strcpy(sdply_begin,cm_cdate_str_100(dply_begin));
       strcpy(sdply_end,cm_cdate_str_100(dply_end));

     /* �Y�Q�O�I�HQ201639145,��ܯS��ĵ�i�T��4450; Modified by Julia Han in 2007/06/04 */
       if (strcmp(trim(iassured),"Q201639145") == 0)
       {
       		return exitsub(reply,M_CA_IASSURED_WARNING) ? M_CA_IASSURED_WARNING :apiRC;
       }

     /* �Ӹ갱���ˮ� add by sylvia 103.02.17 (1020924002_C2) */
        iCountDeny=0;
         $select count(*),funrenew_ins[1,1],funquery_ins[1,1],fdelete_ins[1,1] 
            into $iCountDeny,$funrenew,$funquery,$fundelete
            from cm_personal_deny
           where iassured = $iassured
             and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
             and ddeny <= today
             and (dexpire is null or dexpire >= today)
             GROUP BY 2,3,4;
        if(iCountDeny > 0)
        {
            iUnDeny=0;
            /*�bcu_code_data.itype=CK ���]�w��,�i�H�d��*/ 
            $select count(*) into $iUnDeny
               from cu_code_data where itype = 'CK' and icode = $sUserid;
            if (iUnDeny == 0)
         	{
         		if (strcmp(trim(funrenew),"1") == 0)
            		return exitsub(reply,M_CA_PERSONAL_DENY_RENEW) ? M_CA_PERSONAL_DENY_RENEW :apiRC;
            	else if (strcmp(trim(funquery),"1") == 0)
            		return exitsub(reply,M_CA_PERSONAL_DENY_QUERY) ? M_CA_PERSONAL_DENY_QUERY :apiRC;
            	else if (strcmp(trim(fundelete),"1") == 0)
            		return exitsub(reply,M_CA_PERSONAL_DENY_DELETE) ? M_CA_PERSONAL_DENY_DELETE :apiRC;
            	else 
            		return exitsub(reply,M_CA_PERSONAL_DENY) ? M_CA_PERSONAL_DENY :apiRC;
         	}
        }

     EXEC SQL CLOSE   mq2_2_cursor;
     EXEC SQL FREE    mq2_2_cursor;

     if(!fFound)
       return exitsub(reply,M_CA_NENDORSE) ? M_CA_NENDORSE : apiRC;

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);
     cm_buf_put("%l",1);
     cm_buf_put("%s %s %s %s %s %s %s",ipolicy,itag,nassured,sdply_begin,sdply_end,iofficer,nofficer);
     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
    printf("SOLERR:%s\n",sqlca.sqlerrm);
    printf("stmt=[%s]\n",stmt);
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*********************************************************************/
/*�ѽ߮׸��u�i�b�X�p��ѳ��d��     870622 klyang                   */
/*                ���z���                                           */
/*********************************************************************/
long car1001_multiple_query3(reply)
serverReply reply;
{
     /* standard defined host variables */
     $char DBName[3], dbarray[MAXDB][3], branch[3];
     /* end of standard host var */
     int count, find, i, fFound;

     /* table branch,appraisal,policy */
     $char ibranch[3],iupcomp[3],iclaim[CLAIM_NUM],ipolicy[POLICY_NUM_1],itag[CA_TAG_NUM],nassured[41];
     $char stmt[1024], sFullName[20], sDBSite[3], sClmSite[3];
     $char iassured[13],sdply_begin[11],sdply_end[11],iofficer[11],nofficer[11];
     $long dply_begin,dply_end;
     /* end of branch,appraisal,policy */

     /* standard defined data */
     int tmp_len;
     /* end of standard data */

     /* self defined data */
     /* end of self data */

     ibranch[0]=iupcomp[0]=iclaim[0]=0;
     ipolicy[0]=itag[0]=nassured[0]=0;

     cm_buf_get("%s",DBName);
     cm_buf_get("%s %s",iclaim,sUserid);

     if(db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     strcpy(sFullName, get_full_dbname(DBName));

     sprintf(stmt, "SELECT ipolicy \
                      FROM ca_clm_process \
                     WHERE iclaim = '%s' ",iclaim);
                     /*  AND substr(ipolicy,6,2) <> 'VW'",iclaim);*/

     printf("stmt[%s]\n",stmt);
     EXEC SQL PREPARE clm_mq3 FROM :stmt;
     EXEC SQL DECLARE clm_mq3_cursor CURSOR FOR clm_mq3;
     EXEC SQL OPEN    clm_mq3_cursor;
     EXEC SQL FETCH   clm_mq3_cursor INTO :ipolicy;
     fFound = (SQLCODE == SQLNOTFOUND) ? 0 : 1;
     EXEC SQL CLOSE   clm_mq3_cursor;
     EXEC SQL FREE    clm_mq3_cursor;
     if (!fFound) return exitsub(reply,M_CA_NPOLICY_NCLAIM)?M_CA_NPOLICY_NCLAIM:apiRC;

     strncpy(iupcomp, ipolicy, 2); iupcomp[2] = '\0';
     strcpy(sFullName, get_car_full_db(ipolicy));

     sprintf(stmt, "SELECT a.itag, a.nassured, a.iassured, b.dply_begin, b.dply_end, b.iofficer, \
                     (select nname from officer where iofficer = b.iofficer) \
                      FROM %s:policy a, %s:ply_relation b \
                     WHERE a.ipolicy = '%s' \
                       AND a.ipolicy = b.ipolicy", sFullName, sFullName, ipolicy);
     printf("stmt[%s]\n",stmt);
     EXEC SQL PREPARE mq3_1 FROM :stmt;
     EXEC SQL DECLARE mq3_1_cursor CURSOR FOR mq3_1;
     EXEC SQL OPEN mq3_1_cursor;
     EXEC SQL FETCH mq3_1_cursor INTO :itag, :nassured, :iassured, :dply_begin, :dply_end, :iofficer, :nofficer;
     fFound = (SQLCODE == SQLNOTFOUND) ? 0 : 1;
      /* �Y�Q�O�I�HQ201639145,��ܯS��ĵ�i�T��4450; Modified by Julia Han in 2007/06/04 */
        if (strcmp(trim(iassured),"Q201639145") == 0)
        {
        		return exitsub(reply,M_CA_IASSURED_WARNING) ? M_CA_IASSURED_WARNING :apiRC;
        	}

     /* �Ӹ갱���ˮ� add by sylvia 103.02.17 (1020924002_C2) */
        iCountDeny=0;
         $select count(*),funrenew_ins[1,1],funquery_ins[1,1],fdelete_ins[1,1]
            into $iCountDeny,$funrenew,$funquery,$fundelete
            from cm_personal_deny
           where iassured = $iassured
             and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
             and ddeny <= today
             and (dexpire is null or dexpire >= today)
             GROUP BY 2,3,4;
        if(iCountDeny > 0)
        {
            iUnDeny=0;
            /*�bcu_code_data.itype=CK ���]�w��,�i�H�d��*/ 
            $select count(*) into $iUnDeny
               from cu_code_data where itype = 'CK' and icode = $sUserid;
            if (iUnDeny == 0)
         	{
         		if (strcmp(trim(funrenew),"1") == 0)
            		return exitsub(reply,M_CA_PERSONAL_DENY_RENEW) ? M_CA_PERSONAL_DENY_RENEW :apiRC;
            	else if (strcmp(trim(funquery),"1") == 0)
            		return exitsub(reply,M_CA_PERSONAL_DENY_QUERY) ? M_CA_PERSONAL_DENY_QUERY :apiRC;
            	else if (strcmp(trim(fundelete),"1") == 0)
            		return exitsub(reply,M_CA_PERSONAL_DENY_DELETE) ? M_CA_PERSONAL_DENY_DELETE :apiRC;
            	else 
            		return exitsub(reply,M_CA_PERSONAL_DENY) ? M_CA_PERSONAL_DENY :apiRC;
         	}
        }

     EXEC SQL CLOSE mq3_1_cursor;
     EXEC SQL FREE  mq3_1_cursor;
     if(!fFound)
        return exitsub(reply, M_CA_NPOLICY) ? M_CA_NPOLICY : apiRC;

     /* ����B�z */
     strcpy(sdply_begin,cm_cdate_str_100(dply_begin));
     strcpy(sdply_end,cm_cdate_str_100(dply_end));

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);
     cm_buf_put("%l",1);
     cm_buf_put("%s %s %s %s %s %s %s",ipolicy,itag,nassured,sdply_begin,sdply_end,iofficer,nofficer);
     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
     else
        return api_OKComplete;

errexit:
    printf("SQLERR:%s\n",sqlca.sqlerrm);
    printf("stmt=[%s]\n",stmt);
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*********************************************************************/
/**** ���׽s��????�w���ϥ�,�BTABLE:claim_branch�]���_�s�b ************/
long car1001_multiple_query4(reply)
serverReply reply;
{
     /* standard defined host variables */
     $char DBName[5], sFullName[20], stmt[1024], sTmpBuf[3];
     /* end of standard host var */

     /* table branch,settlement,policy */
     $char ibranch[3],iupcomp[3],iclose[15],ipolicy[19],itag[CA_TAG_NUM],nassured[41];
     $char sStlSite[3];
     $char iassured[13],sdply_begin[11],sdply_end[11],iofficer[11],nofficer[11];
     $long dply_begin,dply_end;
     /* end of branch,settlement,policy */

     /* standard defined data */
     int tmp_len, fFound;
     /* end of standard data */

     ibranch[0]=iupcomp[0]=iclose[0]=0;
     ipolicy[0]=itag[0]=nassured[0]=0;
     cm_buf_get("%s",DBName);
     cm_buf_get("%s %s",iclose,sUserid);
     if(db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     strncpy(ibranch, iclose,2);
     ibranch[2]='\0';

     EXEC SQL SELECT iup_branch
                INTO :sStlSite
                FROM claim_branch
               WHERE iclaim_branch = :ibranch;
     strcpy(sFullName, get_full_dbname(sStlSite));

     EXEC SQL WHENEVER SQLERROR GOTO errexit;
     sprintf(stmt,
       "SELECT ipolicy \
          FROM %s:ca_local_stl \
         WHERE iclose = '%s'",
             sFullName, iclose);
     EXEC SQL PREPARE mq4_0 FROM :stmt;
     EXEC SQL DECLARE mq4_0_cursor CURSOR FOR mq4_0;
     EXEC SQL OPEN    mq4_0_cursor;
     EXEC SQL FETCH   mq4_0_cursor INTO :ipolicy;
     fFound = (SQLCODE == SQLNOTFOUND) ? 0 : 1;
     EXEC SQL CLOSE   mq4_0_cursor;
     EXEC SQL FREE    mq4_0_cursor;
     if(!fFound)
         return exitsub(reply,M_CMN_NBRANCH) ? M_CMN_NBRANCH : apiRC;

     strncpy(sTmpBuf, ipolicy, 2);
     sTmpBuf[2] = '\0';
     strcpy(sFullName, get_car_full_db(ipolicy));

     sprintf(stmt,
       "SELECT itag, nassured, iassured, dply_begin, dply_end, iofficer, \
          (select nname from officer where iofficer = b.iofficer) \
          FROM %s:policy a, %s:ply_relation b \
         WHERE ipolicy = '%s' AND a.ipolicy = b.ipolicy", sFullName, sFullName, ipolicy);
     EXEC SQL PREPARE mq4_1 FROM :stmt;
     EXEC SQL DECLARE q_cur CURSOR FOR mq4_1;
     EXEC SQL OPEN    q_cur;
     EXEC SQL FETCH   q_cur INTO :itag, :nassured, :iassured, :dply_begin, :dply_end, :iofficer, :nofficer;
     if(SQLCODE == SQLNOTFOUND)
         return exitsub(reply,M_CA_NSETTLEMENT) ? M_CA_NSETTLEMENT : apiRC;

     /* ����B�z */
        strcpy(sdply_begin,cm_cdate_str_100(dply_begin));
        strcpy(sdply_end,cm_cdate_str_100(dply_end));

     /* �Y�Q�O�I�HQ201639145,��ܯS��ĵ�i�T��4450; Modified by Julia Han in 2007/06/04 */
        if (strcmp(trim(iassured),"Q201639145") == 0)
        {
        		return exitsub(reply,M_CA_IASSURED_WARNING) ? M_CA_IASSURED_WARNING :apiRC;
        }

        /* �Ӹ갱���ˮ� add by sylvia 103.02.17 (1020924002_C2) */
        iCountDeny=0;
         $select count(*),funrenew_ins[1,1],funquery_ins[1,1],fdelete_ins[1,1]
            into $iCountDeny,$funrenew,$funquery,$fundelete
            from cm_personal_deny
           where iassured = $iassured
             and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
             and ddeny <= today
             and (dexpire is null or dexpire >= today)
             GROUP BY 2,3,4;
        if(iCountDeny > 0)
        {
            iUnDeny=0;
            /*�bcu_code_data.itype=CK ���]�w��,�i�H�d��*/ 
            $select count(*) into $iUnDeny
               from cu_code_data where itype = 'CK' and icode = $sUserid;
            if (iUnDeny == 0)
         	{
         		if (strcmp(trim(funrenew),"1") == 0)
            		return exitsub(reply,M_CA_PERSONAL_DENY_RENEW) ? M_CA_PERSONAL_DENY_RENEW :apiRC;
            	else if (strcmp(trim(funquery),"1") == 0)
            		return exitsub(reply,M_CA_PERSONAL_DENY_QUERY) ? M_CA_PERSONAL_DENY_QUERY :apiRC;
            	else if (strcmp(trim(fundelete),"1") == 0)
            		return exitsub(reply,M_CA_PERSONAL_DENY_DELETE) ? M_CA_PERSONAL_DENY_DELETE :apiRC;
            	else 
            		return exitsub(reply,M_CA_PERSONAL_DENY) ? M_CA_PERSONAL_DENY :apiRC;
         	}
        }

     EXEC SQL CLOSE   q_cur;
     EXEC SQL FREE    q_cur;

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);
     cm_buf_put("%l",1);
     cm_buf_put("%s %s %s %s %s %s %s",ipolicy,itag,nassured,sdply_begin,sdply_end,iofficer,nofficer);
     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
     else
        return api_OKComplete;

errexit:
   printf("SOLERR:%s\n",sqlca.sqlerrm);
   printf("stmt=[%s]\n",stmt);
   return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*********************************************************************/
/******** �Q�O�I�H ***************************************************/
/*********************************************************************/
long car1001_multiple_query5(reply)
serverReply reply;
{
     /* standard defined host variables */
     $char DBName[5];
     /* end of standard host var */

     /* table assured_vs_ply */
     $char ipolicy[19],itag[CA_TAG_NUM],nassured[41],ibody[21],iengine[21];
     $char iassured[13],sdply_begin[11],sdply_end[11],iofficer[11],nofficer[11];
     $long dply_begin,dply_end;
     /* end of assured_vs_ply, */

     /* standard defined data */
     char tmpbuf[4000];
     int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
     int i,total_count=0;
     /* end of standard data */

     /* self defined data */
     $char yr[3], fcard_class[2];
     $char tmp_nassured[11];
     $char tmp_yr[6];
     $char sAassured[31], tmp_aassured[31];
     $long ltot_prem;
     $char sTmpBuf[51];
     $char stmt[400],stmt1[400],stmt2[400],stmt3[400];
     int iTmp;
     $char fcheckClose[2], stmt_1[4096];

     /* end of self data */
     ipolicy[0]=itag[0]=nassured[0]=ibody[0]=iengine[0]=0;
     yr[0]=fcard_class[0]=0;
     fcheckClose[0]=0;
     memset(tmp_yr,0,sizeof(tmp_yr));

     cm_buf_get("%s",DBName);
     cm_buf_get("%s",nassured);
     cm_buf_get("%s %s %s %s",yr,fcard_class,sUserid,fcheckClose);
     printf("  fcard_class[%s] \n",fcard_class);

     /**** client �ݦ��ˮֳQ�O�I�H���o��J���ťթάP�� ****/

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
         return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
     i=strlen(nassured)-1;
     if (nassured[i]=='*')
     {
        sprintf(stmt2,"WHERE nassured matches '%s' ", nassured);
        sprintf(stmt3,"AND a.nassured matches '%s' ", nassured);
     }
     else
     {
        sprintf(stmt2,"WHERE nassured = '%s' ", nassured);
        sprintf(stmt3,"AND a.nassured = '%s' ", nassured);
     }
     if (strncmp(fcard_class,"*",1)==0)
        strcpy(stmt1," ");
     else
        sprintf(stmt1,"AND fcard_class = '%s' ", fcard_class);

     /* fcheckClose 0:���鵲, 1:�w�鵲 */
     if (strcmp(trim(fcheckClose), "0") == 0)
     {
        sprintf(stmt_1, "SELECT UNIQUE a.ipolicy, a.itag, a.nassured, a.iassured \
                         FROM newa00:policy a, newa00:ply_relation b \
                        WHERE a.ipolicy = b.ipolicy \
                          AND b.dply_begin >= today - 60 \
                          AND b.dply_close IS NULL %s %s \
                        UNION \
                       SELECT UNIQUE a.ipolicy, a.itag, a.nassured, a.iassured \
                         FROM newa22:policy a, newa22:ply_relation b \
                        WHERE a.ipolicy = b.ipolicy \
                          AND b.dply_begin >= today - 60 \
                          AND b.dply_close IS NULL %s %s \
                        UNION \
                       SELECT UNIQUE a.ipolicy, a.itag, a.nassured, a.iassured \
                         FROM newa33:policy a, newa33:ply_relation b \
                        WHERE a.ipolicy = b.ipolicy \
                          AND b.dply_begin >= today - 60 \
                          AND b.dply_close IS NULL %s %s \
                        UNION \
                       SELECT UNIQUE a.ipolicy, a.itag, a.nassured, a.iassured \
                         FROM newa40:policy a, newa40:ply_relation b \
                        WHERE a.ipolicy = b.ipolicy \
                          AND b.dply_begin >= today - 60 \
                          AND b.dply_close IS NULL %s %s \
                        UNION \
                       SELECT UNIQUE a.ipolicy, a.itag, a.nassured, a.iassured \
                         FROM newa66:policy a, newa66:ply_relation b \
                        WHERE a.ipolicy = b.ipolicy \
                          AND b.dply_begin >= today - 60 \
                          AND b.dply_close IS NULL %s %s \
                        UNION \
                       SELECT UNIQUE a.ipolicy, a.itag, a.nassured, a.iassured \
                         FROM newa70:policy a, newa70:ply_relation b \
                        WHERE a.ipolicy = b.ipolicy \
                          AND b.dply_begin >= today - 60 \
                          AND b.dply_close IS NULL %s %s ;", stmt3, stmt1, stmt3, stmt1, stmt3, stmt1, 
                                                             stmt3, stmt1, stmt3, stmt1, stmt3, stmt1);
     }
     else
     {
        sprintf(stmt_1,"SELECT {+ index (assured_vs_ply ca_assply_ix_5)} \
                               ipolicy,itag,nassured,iassured \
                          FROM assured_vs_ply %s %s ",stmt2,stmt1);    /* �ư��Q�O�I�H Q201639145 */
     }

     printf("stmt[%s]\n",stmt_1);
     EXEC SQL PREPARE q_pre1 FROM :stmt_1;
     EXEC SQL DECLARE q_cur1 CURSOR FOR q_pre1;
     EXEC SQL OPEN q_cur1;
     for(;;)
     {
        EXEC SQL FETCH q_cur1 INTO :ipolicy, :itag, :tmp_nassured, :iassured;
        if (SQLCODE != 0) break;
        
        if (strncmp(&ipolicy[3],yr,2)!=0 && strcmp(yr,"*")!=0)
        {
            printf("===== ipolicy[%s] not in yr[%s]\n",ipolicy,yr);
            continue;
        }

		   /* �Y�Q�O�I�HQ201639145,��ܯS��ĵ�i�T��4450; Modified by Julia Han in 2007/06/04 */
        if (strcmp(trim(iassured),"Q201639145") == 0)
        {
        		return exitsub(reply,M_CA_IASSURED_WARNING) ? M_CA_IASSURED_WARNING :apiRC;
        }

        /* �Ӹ갱���ˮ� add by sylvia 103.02.17 (1020924002_C2) */
        iCountDeny=0;
         $select count(*),funrenew_ins[1,1],funquery_ins[1,1],fdelete_ins[1,1]
            into $iCountDeny,$funrenew,$funquery,$fundelete
            from cm_personal_deny
           where iassured = $iassured
             and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
             and ddeny <= today
             and (dexpire is null or dexpire >= today)
             GROUP BY 2,3,4;
        if(iCountDeny > 0)
        {
            iUnDeny=0;
            /*�bcu_code_data.itype=CK ���]�w��,�i�H�d��*/ 
            $select count(*) into $iUnDeny
               from cu_code_data where itype = 'CK' and icode = $sUserid;
            if (iUnDeny == 0)
         	{
         		if (strcmp(trim(funrenew),"1") == 0)
            		return exitsub(reply,M_CA_PERSONAL_DENY_RENEW) ? M_CA_PERSONAL_DENY_RENEW :apiRC;
            	else if (strcmp(trim(funquery),"1") == 0)
            		return exitsub(reply,M_CA_PERSONAL_DENY_QUERY) ? M_CA_PERSONAL_DENY_QUERY :apiRC;
            	else if (strcmp(trim(fundelete),"1") == 0)
            		return exitsub(reply,M_CA_PERSONAL_DENY_DELETE) ? M_CA_PERSONAL_DENY_DELETE :apiRC;
            	else 
            		return exitsub(reply,M_CA_PERSONAL_DENY) ? M_CA_PERSONAL_DENY :apiRC;
         	}
        }

        {
            char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
            char sTmp_db_name[21];

            strcpy(sTmp_db_name, get_car_full_db(ipolicy));

            if ((sTmp_db_name[0] != '\0') && (sTmp_db_name[0] != ' '))
            {
                 sprintf(stmt,"SELECT a.aassured, b.mdmg_prem+b.mlia_prem, \
                                 b.dply_begin,b.dply_end,b.iofficer, \
                                 (select nname from officer where iofficer = b.iofficer) \
                                 FROM %s:policy a ,%s:ply_relation b %s %s",
                               sTmp_db_name, sTmp_db_name,
                               "WHERE a.ipolicy = ? ",
                               "  AND a.ipolicy = b.ipolicy ");
                 EXEC SQL PREPARE STMT_PLY FROM :stmt;
                 EXEC SQL DECLARE CUR_PLY  CURSOR FOR STMT_PLY;
                 EXEC SQL OPEN CUR_PLY USING :ipolicy;
                 EXEC SQL FETCH CUR_PLY INTO :sAassured, :ltot_prem, :dply_begin, :dply_end, :iofficer, :nofficer;
                 if (SQLCODE==SQLNOTFOUND)
                 {
                     strcpy(sAassured, " ");
                     strcpy(sdply_begin," ");
                     strcpy(sdply_end," ");
                     strcpy(iofficer," ");
                     ltot_prem=0;
                 } else
                 {
                     /* ����B�z */
                     strcpy(sdply_begin,cm_cdate_str_100(dply_begin));
                     strcpy(sdply_end,cm_cdate_str_100(dply_end));
                 }

                 EXEC SQL CLOSE CUR_PLY;
                 EXEC SQL FREE  CUR_PLY;
            }
            else
            {
                 ltot_prem=0;
                 strcpy(sAassured, " ");
            }
        }
        printf("sAssured[%s]\n", sAassured);
        iTmp=cc_split_chinese(sAassured, tmp_aassured, 12);
        printf("tmp_aassured[%s]\n", tmp_aassured);
        strcat( tmp_aassured, "******");

        sprintf(sTmpBuf, "%s %s %8d", tmp_nassured, tmp_aassured, ltot_prem);

        cm_buf_init(tmpbuf);
        if ( count == 0 )
        {
            cm_buf_res_msg();             /* reserve for MsgCode and count */
            cm_buf_res_count();
        }
        cm_buf_put("%s %s %s %s %s %s %s",ipolicy,itag,sTmpBuf,sdply_begin,sdply_end,iofficer,nofficer);
        tmp_len = cm_buf_len(tmpbuf);
        if (tmp_len + repbuf_len < 12000)   /* buffer size less than 4K */
        {
            memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
            repbuf_len += tmp_len;
            count++;
        }
        else                               /* more than 4K, send to client side */
        {
            cm_buf_init(ReplyBuf);
            cm_buf_put_msg(M_CM_OK);
            cm_buf_put_count(count);
            if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
            {
                 EXEC SQL CLOSE q_cur1;
                 EXEC SQL FREE  q_cur1;
                 return apiRC;
            }
            else               /* clear ReplyBuf and count to start all over again */
            {
                 replycnt++;
                 if (replycnt == 10)   /* more than 30K, client cannot display,error */
                 {
                       cm_buf_init(ReplyBuf);
                       cm_buf_put("%l",M_CM_OUT_SPACE);
                       tmp_len = cm_buf_len(ReplyBuf);
                       if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
                               return apiRC;
                       return M_CM_OUT_SPACE;
                 }
                 ReplyBuf[0] = '\0';
                 count = 0;
                 cm_buf_init(ReplyBuf);
                 cm_buf_res_msg();           /* reserve for MsgCode and count */
                 cm_buf_res_count();
                 cm_buf_put("%s %s %s %s %s %s %s",ipolicy,itag,sTmpBuf,sdply_begin,sdply_end,iofficer,nofficer);
                 repbuf_len = cm_buf_len(ReplyBuf);
                 count++;
            }
         }
     } /* for loop */
     EXEC SQL CLOSE q_cur1;
     EXEC SQL FREE  q_cur1;
     if (count > 0)   /* break out, at least one record is selected */
     {
        cm_buf_init(ReplyBuf);
        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(count);
        if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
            return apiRC;
        return api_OKComplete;
     }
     else            /* break out, not any row is found */
     {
        return exitsub(reply,M_CA_NOREC_ERR) ? M_CA_NOREC_ERR : apiRC;
     }

errexit:
  printf("SOLERR:%s\n",sqlca.sqlerrm);
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/***** �P�� *****/
long car1001_multiple_query7(reply)
serverReply reply;
{
   /* standard defined host variables */
   $char DBName[5];
   /* end of standard host var */

   /* table assured_vs_ply */
   $char ipolicy[19],itag[CA_TAG_NUM],nassured[41],ibody[21],iengine[21];
   $char iassured[13],sdply_begin[11],sdply_end[11],iofficer[11],nofficer[11];
   $long dply_begin,dply_end;
   $char sFullName[20], stmt[1024], stmt_1[4096];
   /* end of assured_vs_ply, */

   /* standard defined data */
   char tmpbuf[4000];
   int  count=0,repbuf_len=0,tmp_len=0,replycnt=0;
   int  i,total_count=0,fFound;
   /* end of standard data */
   
   $char fcheckClose[2]; 

   /* self defined data */
   /* end of self data */
   ipolicy[0]=itag[0]=nassured[0]=ibody[0]=iengine[0]=0;

   cm_buf_get("%s",DBName);
   cm_buf_get("%s %s %s",itag,sUserid,fcheckClose);

   printf("itag = %s strlen(itag) = %d\n", itag, strlen(itag));

   EXEC SQL WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False)
       return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

   printf("car1001-->flag1\n");

   /* fcheckClose 0:���鵲, 1:�w�鵲 */
   if (strcmp(trim(fcheckClose), "0") == 0)
   {
      printf("***** fcheckClose[%s] *****\n", fcheckClose);
      
   	  rtncode = car1001_query_no_dplyclose("7", itag);
   	  if (rtncode != M_CM_OK) return rtncode;
   	  	
   	  strcpy(stmt_1, sStmt);
   }
   else
   {
      sprintf(stmt_1, "SELECT DISTINCT ipolicy, iassured, nassured, itag \
                         FROM assured_vs_ply \
                        WHERE itag = '%s' \
                       OR itag = (SELECT itag_next FROM ca_change_tag where itag_last = '%s') \
                       OR itag = (SELECT itag_last FROM ca_change_tag where itag_next = '%s');", itag, itag, itag );
   }
     
   EXEC SQL PREPARE q_cur2_cursor FROM :stmt_1;
   EXEC SQL DECLARE q_cur2 CURSOR FOR q_cur2_cursor;
   EXEC SQL OPEN q_cur2;
   printf("car1001-->flag2\n");

   for(;;)
   {
       EXEC SQL FETCH q_cur2 INTO :ipolicy, :iassured, :nassured, :itag;
       if (SQLCODE != 0) break;

       /* car9802052 �ھګO�渹��X��Ʈw,�ç�X�ӫO�渹���_����H�θg��N�� */
       strcpy(sFullName, get_car_full_db(ipolicy));

       sprintf(stmt, "SELECT a.dply_begin, a.dply_end, a.iofficer, \
                      (select nname from officer where iofficer = a.iofficer) \
                      FROM %s:ply_relation a WHERE ipolicy = '%s'", sFullName, ipolicy);
printf("stmt[%s]\n",stmt);
       EXEC SQL PREPARE q_cur2_1 FROM :stmt;
       EXEC SQL DECLARE q_cur2_1_cursor CURSOR FOR q_cur2_1;
       EXEC SQL OPEN q_cur2_1_cursor;
       EXEC SQL FETCH q_cur2_1_cursor INTO :dply_begin, :dply_end, :iofficer, :nofficer;
       fFound = (SQLCODE == SQLNOTFOUND) ? 0 : 1;
       EXEC SQL CLOSE q_cur2_1_cursor;
       EXEC SQL FREE  q_cur2_1_cursor;
       if(!fFound) return exitsub(reply, M_CA_NPOLICY) ? M_CA_NPOLICY : apiRC;
       /* end of car9802052 */

       /* ����B�z */
        strcpy(sdply_begin,cm_cdate_str_100(dply_begin));
        strcpy(sdply_end,cm_cdate_str_100(dply_end));

       /* �Y�Q�O�I�HQ201639145,��ܯS��ĵ�i�T��4450; Modified by Julia Han in 2007/06/04 */
        if (strcmp(trim(iassured),"Q201639145") == 0)
        {
        		return exitsub(reply,M_CA_IASSURED_WARNING) ? M_CA_IASSURED_WARNING :apiRC;
        	}

       /* �Ӹ갱���ˮ� add by sylvia 103.02.17 (1020924002_C2) */
        iCountDeny=0;
         $select count(*),funrenew_ins[1,1],funquery_ins[1,1],fdelete_ins[1,1]
            into $iCountDeny,$funrenew,$funquery,$fundelete
            from cm_personal_deny
           where iassured = $iassured
             and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
             and ddeny <= today
             and (dexpire is null or dexpire >= today)
             GROUP BY 2,3,4;
        if(iCountDeny > 0)
        {
            iUnDeny=0;
            /*�bcu_code_data.itype=CK ���]�w��,�i�H�d��*/ 
            $select count(*) into $iUnDeny
               from cu_code_data where itype = 'CK' and icode = $sUserid;
	         if (iUnDeny == 0)
	         {
	         	if (strcmp(trim(funrenew),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_RENEW) ? M_CA_PERSONAL_DENY_RENEW :apiRC;
	            else if (strcmp(trim(funquery),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_QUERY) ? M_CA_PERSONAL_DENY_QUERY :apiRC;
	            else if (strcmp(trim(fundelete),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_DELETE) ? M_CA_PERSONAL_DENY_DELETE :apiRC;
	            else 
	            	return exitsub(reply,M_CA_PERSONAL_DENY) ? M_CA_PERSONAL_DENY :apiRC;
	         }
        }

       cm_buf_init(tmpbuf);
       if (count == 0)
       {
           cm_buf_res_msg();          /* reserve for MsgCode and count */
           cm_buf_res_count();
       }
       printf("car1001-->flag3\n");

       cm_buf_put("%s %s %s %s %s %s %s",ipolicy,itag,nassured,sdply_begin,sdply_end,iofficer,nofficer);
       tmp_len = cm_buf_len(tmpbuf);
       if (tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
       {
           memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
           repbuf_len += tmp_len;
           count++;
       }
       else                               /* more than 4K, send to client side */
       {
           cm_buf_init(ReplyBuf);
           cm_buf_put_msg(M_CM_OK);
           cm_buf_put_count(count);
           if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
           {
                EXEC SQL CLOSE q_cur2;
                EXEC SQL FREE  q_cur2;
                return apiRC;
           }
           else               /* clear ReplyBuf and count to start all over again */
           {
                replycnt++;
                if (replycnt == 10)   /* more than 30K, client cannot display,error */
                {
                    cm_buf_init(ReplyBuf);
                    cm_buf_put("%l",M_CM_OUT_SPACE);
                    tmp_len = cm_buf_len(ReplyBuf);
                    if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)== False)
                            return apiRC;
                    return M_CM_OUT_SPACE;
                }
                ReplyBuf[0] = '\0';
                count = 0;
                cm_buf_init(ReplyBuf);
                cm_buf_res_msg();           /* reserve for MsgCode and count */
                cm_buf_res_count();
                cm_buf_put("%s %s %s %s %s %s %s",ipolicy,itag,nassured,sdply_begin,sdply_end,iofficer,nofficer);
                repbuf_len = cm_buf_len(ReplyBuf);
                count++;
           }
       }
   } /* for loop */

   EXEC SQL CLOSE q_cur2;
   EXEC SQL FREE  q_cur2;

   if (count > 0)   /* break out, at least one record is selected */
   {
       cm_buf_init(ReplyBuf);
       cm_buf_put_msg(M_CM_OK);
       cm_buf_put_count(count);
       if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
          return apiRC;

       printf("car1001-->flag4\n");

       return api_OKComplete;
   }
   else            /* break out, not any row is found */
   {
       return exitsub(reply,M_CA_NOREC_ERR) ? M_CA_NOREC_ERR : apiRC;  
   }

errexit:
   printf("SOLERR:%s\n",sqlca.sqlerrm);
   return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*********************************************************************/
/**************** �������X *******************************************/
/*********************************************************************/
/* Julia-2009 */
long car1001_multiple_query8(reply)
serverReply reply;
{
    /* standard defined host variables */
    $char DBName[5];
    /* end of standard host var */

    /* table assured_vs_ply */
    $char ipolicy[19],itag[CA_TAG_NUM],nassured[41],ibody[21],iengine[21];
    $char iassured[13],sdply_begin[11],sdply_end[11],iofficer[11],nofficer[11];
    $long dply_begin,dply_end;
    $char sFullName[20],stmt[1024];
    /* end of assured_vs_ply, */

    /* standard defined data */
    char tmpbuf[4000];
    int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
    int i,total_count=0,fFound;
    /* end of standard data */
    
    $char fcheckClose[2], stmt_1[4096];

    ipolicy[0]=itag[0]=nassured[0]=ibody[0]=iengine[0]=fcheckClose[0]=0;

    cm_buf_get("%s",DBName);
    cm_buf_get("%s %s %s",iengine,sUserid,fcheckClose);

    EXEC SQL WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    /* fcheckClose 0:���鵲, 1:�w�鵲 */
    if (strcmp(trim(fcheckClose), "0") == 0)
    {
      printf("***** fcheckClose[%s] *****\n", fcheckClose);
      
   	  rtncode = car1001_query_no_dplyclose("8", iengine);
   	  if (rtncode != M_CM_OK) return rtncode;
   	  	
   	  strcpy(stmt_1, sStmt);
    }
    else
    {
      sprintf(stmt_1, "SELECT DISTINCT ipolicy, iassured, nassured, itag \
                         FROM assured_vs_ply \
                        WHERE iengine = '%s';", iengine);
                       /* AND substr(ipolicy,6,2) <> 'VW'; *//* Get rid of 'VW' data */
    }
     
   
    EXEC SQL PREPARE q_cur3_cursor FROM :stmt_1;
    EXEC SQL DECLARE q_cur3 CURSOR FOR q_cur3_cursor;
    EXEC SQL OPEN q_cur3;

    for(;;)
    {
       EXEC SQL FETCH q_cur3 INTO :ipolicy, :iassured, :nassured, :itag;
       if (SQLCODE != 0) break;

       /* car9802052 �ھګO�渹��X��Ʈw,�ç�X�ӫO�渹���_����H�θg��N�� */
       strcpy(sFullName, get_car_full_db(ipolicy));

       sprintf(stmt, "SELECT a.dply_begin, a.dply_end, a.iofficer, \
                      (select nname from officer where iofficer = a.iofficer) \
                      FROM %s:ply_relation a WHERE ipolicy = '%s'", sFullName, ipolicy);
printf("stmt[%s]\n",stmt);
       EXEC SQL PREPARE q_cur31 FROM :stmt;
       EXEC SQL DECLARE q_cur31_cursor CURSOR FOR q_cur31;
       EXEC SQL OPEN q_cur31_cursor;
       EXEC SQL FETCH q_cur31_cursor INTO :dply_begin, :dply_end, :iofficer, :nofficer;
       fFound = (SQLCODE == SQLNOTFOUND) ? 0 : 1;
       EXEC SQL CLOSE q_cur31_cursor;
       EXEC SQL FREE  q_cur31_cursor;
       if(!fFound) return exitsub(reply, M_CA_NPOLICY) ? M_CA_NPOLICY : apiRC;
       /* end of car9802052 */

       /* ����B�z */
        strcpy(sdply_begin,cm_cdate_str_100(dply_begin));
        strcpy(sdply_end,cm_cdate_str_100(dply_end));

       /* �Y�Q�O�I�HQ201639145,��ܯS��ĵ�i�T��4450; Modified by Julia Han in 2007/06/04 */
        if (strcmp(trim(iassured),"Q201639145") == 0)
        {
        		return exitsub(reply,M_CA_IASSURED_WARNING) ? M_CA_IASSURED_WARNING :apiRC;
        	}

       /* �Ӹ갱���ˮ� add by sylvia 103.02.17 (1020924002_C2) */
        iCountDeny=0;
         $select count(*),funrenew_ins[1,1],funquery_ins[1,1],fdelete_ins[1,1]
            into $iCountDeny,$funrenew,$funquery,$fundelete
            from cm_personal_deny
           where iassured = $iassured
             and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
             and ddeny <= today
             and (dexpire is null or dexpire >= today)
             GROUP BY 2,3,4;
        if(iCountDeny > 0)
        {
            iUnDeny=0;
            /*�bcu_code_data.itype=CK ���]�w��,�i�H�d��*/ 
            $select count(*) into $iUnDeny
               from cu_code_data where itype = 'CK' and icode = $sUserid;
	         if (iUnDeny == 0)
	         {
	         	if (strcmp(trim(funrenew),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_RENEW) ? M_CA_PERSONAL_DENY_RENEW :apiRC;
	            else if (strcmp(trim(funquery),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_QUERY) ? M_CA_PERSONAL_DENY_QUERY :apiRC;
	            else if (strcmp(trim(fundelete),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_DELETE) ? M_CA_PERSONAL_DENY_DELETE :apiRC;
	            else 
	            	return exitsub(reply,M_CA_PERSONAL_DENY) ? M_CA_PERSONAL_DENY :apiRC;
	         }
        }

       cm_buf_init(tmpbuf);
       if ( count == 0 )
       {
           cm_buf_res_msg();             /* reserve for MsgCode and count */
           cm_buf_res_count();
       }
       cm_buf_put("%s %s %s %s %s %s %s",ipolicy,itag,nassured,sdply_begin,sdply_end,iofficer,nofficer);
       tmp_len = cm_buf_len(tmpbuf);
       if (tmp_len + repbuf_len < 3000)   /* buffer size less than 4K */
       {
           memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
           repbuf_len += tmp_len;
           count++;
       }
       else                             /* more than 4K, send to client side */
       {
           cm_buf_init(ReplyBuf);
           cm_buf_put_msg(M_CM_OK);
           cm_buf_put_count(count);
           if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
           {
               EXEC SQL CLOSE q_cur3;
               EXEC SQL FREE  q_cur3;
               return apiRC;
           }
           else            /* clear ReplyBuf and count to start all over again */
           {
               replycnt++;
               if (replycnt == 10)   /* more than 30K, client cannot display,error */
               {
                       cm_buf_init(ReplyBuf);
                       cm_buf_put("%l",M_CM_OUT_SPACE);
                       tmp_len = cm_buf_len(ReplyBuf);
                       if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
                                    return apiRC;
                       return M_CM_OUT_SPACE;
               }
               ReplyBuf[0] = '\0';
               count = 0;
               cm_buf_init(ReplyBuf);
               cm_buf_res_msg();           /* reserve for MsgCode and count */
               cm_buf_res_count();
               cm_buf_put("%s %s %s %s %s %s %s",ipolicy,itag,nassured,sdply_begin,sdply_end,iofficer,nofficer);
               repbuf_len = cm_buf_len(ReplyBuf);
               count++;
           }
       }
    } /* for loop */
    EXEC SQL CLOSE q_cur3;
    EXEC SQL FREE  q_cur3;
    if (count > 0)   /* break out, at least one record is selected */
    {
       cm_buf_init(ReplyBuf);
       cm_buf_put_msg(M_CM_OK);
       cm_buf_put_count(count);
       if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
         return apiRC;
       return api_OKComplete;
    }
    else            /* break out, not any row is found */
    {
       return exitsub(reply,M_CA_NOREC_ERR) ? M_CA_NOREC_ERR : apiRC;
    }

errexit:
   printf("SOLERR:%s\n",sqlca.sqlerrm);
   return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*********************************************************************/
/************** �������X:�ثe���b�ϥ� ********************************/
/*********************************************************************/
long car1001_multiple_query9(reply)
serverReply reply;
{
     /* standard defined host variables */
     $char DBName[5];
     /* end of standard host var */

     /* table assured_vs_ply */
     $char ipolicy[19],itag[CA_TAG_NUM],nassured[41],ibody[21],iengine[21];
     $char iassured[13],sdply_begin[11],sdply_end[11],iofficer[11],nofficer[11];
     $long dply_begin,dply_end;
     /* end of assured_vs_ply */

     /* standard defined data */
     char tmpbuf[4000];
     int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
     int i,total_count=0;
     /* end of standard data */

     ipolicy[0]=itag[0]=nassured[0]=ibody[0]=iengine[0]=0;

     cm_buf_get("%s",DBName);
     cm_buf_get("%s %s",ibody,sUserid);

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
         return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     EXEC SQL DECLARE q_cur4 CURSOR FOR
               SELECT DISTINCT ipolicy,itag,nassured,iassured
                 INTO :ipolicy, :itag, :nassured, :iassured
                 FROM assured_vs_ply
                WHERE ibody = :ibody;
                  /* AND substr(ipolicy,6,2) <> 'VW';   Get rid of 'VW' data */
     EXEC SQL OPEN q_cur4;
     for(;;)
     {
        EXEC SQL FETCH q_cur4;
        if (SQLCODE != 0) break;


        /* �Y�Q�O�I�HQ201639145,��ܯS��ĵ�i�T��4450; Modified by Julia Han in 2007/06/04 */
        if (strcmp(trim(iassured),"Q201639145") == 0)
        {
        		return exitsub(reply,M_CA_IASSURED_WARNING) ? M_CA_IASSURED_WARNING :apiRC;
        	}


        /* �Ӹ갱���ˮ� add by sylvia 103.02.17 (1020924002_C2) */
        iCountDeny=0;
         $select count(*),funrenew_ins[1,1],funquery_ins[1,1],fdelete_ins[1,1]
            into $iCountDeny,$funrenew,$funquery,$fundelete
            from cm_personal_deny
           where iassured = $iassured
             and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
             and ddeny <= today
             and (dexpire is null or dexpire >= today)
             GROUP BY 2,3,4;
        if(iCountDeny > 0)
        {
            iUnDeny=0;
            /*�bcu_code_data.itype=CK ���]�w��,�i�H�d��*/ 
            $select count(*) into $iUnDeny
               from cu_code_data where itype = 'CK' and icode = $sUserid;
	         if (iUnDeny == 0)
	         {
	         	if (strcmp(trim(funrenew),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_RENEW) ? M_CA_PERSONAL_DENY_RENEW :apiRC;
	            else if (strcmp(trim(funquery),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_QUERY) ? M_CA_PERSONAL_DENY_QUERY :apiRC;
	            else if (strcmp(trim(fundelete),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_DELETE) ? M_CA_PERSONAL_DENY_DELETE :apiRC;
	            else 
	            	return exitsub(reply,M_CA_PERSONAL_DENY) ? M_CA_PERSONAL_DENY :apiRC;
	         }
        }

        cm_buf_init(tmpbuf);
        if (count == 0)
        {
            cm_buf_res_msg();             /* reserve for MsgCode and count */
            cm_buf_res_count();
        }
        cm_buf_put("%s %s %s ' ' ' ' ' ' ' '",ipolicy,itag,nassured);
        tmp_len = cm_buf_len(tmpbuf);
        if (tmp_len + repbuf_len < 3000)   /* buffer size less than 4K */
        {
            memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
            repbuf_len += tmp_len;
            count++;
        }
        else                               /* more than 4K, send to client side */
        {
            cm_buf_init(ReplyBuf);
            cm_buf_put_msg(M_CM_OK);
            cm_buf_put_count(count);
            if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
            {
                EXEC SQL CLOSE q_cur4;
                EXEC SQL FREE  q_cur4;
                return apiRC;
            }
            else               /* clear ReplyBuf and count to start all over again */
            {
                replycnt++;
                if (replycnt == 10)   /* more than 30K, client cannot display,error */
                {
                        cm_buf_init(ReplyBuf);
                        cm_buf_put("%l",M_CM_OUT_SPACE);
                        tmp_len = cm_buf_len(ReplyBuf);
                        if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
                                return apiRC;
                        return M_CM_OUT_SPACE;
                }
                ReplyBuf[0] = '\0';
                count = 0;
                cm_buf_init(ReplyBuf);
                cm_buf_res_msg();           /* reserve for MsgCode and count */
                cm_buf_res_count();
                cm_buf_put("%s %s %s ' ' ' ' ' ' ' '",ipolicy,itag,nassured);
                repbuf_len = cm_buf_len(ReplyBuf);
                count++;
            }
         }
     } /* for loop */

     EXEC SQL CLOSE q_cur4;
     EXEC SQL FREE  q_cur4;
     if (count > 0)   /* break out, at least one record is selected */
     {
            cm_buf_init(ReplyBuf);
            cm_buf_put_msg(M_CM_OK);
            cm_buf_put_count(count);
            if(SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
                    return apiRC;
            return api_OKComplete;
     }
     else            /* break out, not any row is found */
     {
          return exitsub(reply,M_CA_NOREC_ERR) ? M_CA_NOREC_ERR : apiRC;
     }

errexit:
   printf("SOLERR:%s\n",sqlca.sqlerrm);
   return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*********************************************************************/
long car1001_multiple_queryb1(reply)
serverReply reply;
{
    /* standard defined host variables */
    $char DBName[5];
    /* end of standard host var */

    /* table policy */
    $char ipolicy[POLICY_NUM_1],itag[CA_TAG_NUM],nassured[41];
    $char ipolicy_ext[POLICY_NUM_1];
    $char iassured[13],sdply_begin[11],sdply_end[11],iofficer[11],nofficer[11];
    $long dply_begin,dply_end;
    /* end of policy */

    /* standard defined data */
    char tmpbuf[4000];
    int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
    int i,total_count=0;
    /* end of standard data */

    /* self defined data */
    /* end of self data */

    ipolicy[0]=itag[0]=nassured[0]=0;

    cm_buf_get("%s",DBName);
    cm_buf_get("%s %s",ipolicy,sUserid);

    EXEC SQL WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
       return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    EXEC SQL DECLARE ass_curb CURSOR FOR
              SELECT a.ipolicy, itag, nassured, iassured, b.dply_begin, b.dply_end, b.iofficer,
                     (select nname from officer where iofficer = b.iofficer)
                INTO :ipolicy_ext, :itag, :nassured, :iassured, :dply_begin, :dply_end, :iofficer, :nofficer
                FROM policy a, ply_relation b
               WHERE a.ipolicy = :ipolicy
                 AND a.ipolicy = b.ipolicy;

    EXEC SQL OPEN ass_curb;
    for(;;)
    {
       EXEC SQL FETCH ass_curb;
       if (SQLCODE != 0) break;

       /* ����B�z */
        strcpy(sdply_begin,cm_cdate_str_100(dply_begin));
        strcpy(sdply_end,cm_cdate_str_100(dply_end));

       /* �Y�Q�O�I�HQ201639145,��ܯS��ĵ�i�T��4450; Modified by Julia Han in 2007/06/04 */
        if (strcmp(trim(iassured),"Q201639145") == 0)
        {
        		return exitsub(reply,M_CA_IASSURED_WARNING) ? M_CA_IASSURED_WARNING :apiRC;
        	}

       /* �Ӹ갱���ˮ� add by sylvia 103.02.17 (1020924002_C2) */
        strcpy(o_sDeny_msg," ");
        iCountDeny=0;
        iCountFunsale=0;
        $select count(*),funrenew_ins[1,1],funquery_ins[1,1],fdelete_ins[1,1]
            into $iCountDeny,$funrenew,$funquery,$fundelete
            from cm_personal_deny
           where iassured = $iassured
             and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
             and ddeny <= today
             and (dexpire is null or dexpire >= today)
             GROUP BY 2,3,4;
             
             rtncode = cm_chk_personal(iassured, 'C' , '*' , o_sDeny_msg, o_sFply_chk);
             
        if(iCountDeny > 0)
        {
            iUnDeny=0;
            /*�bcu_code_data.itype=CK ���]�w��,�i�H�d��*/ 
            $select count(*) into $iUnDeny
               from cu_code_data where itype = 'CK' and icode = $sUserid;
            if (iUnDeny == 0)
         	{
         		if (strcmp(trim(funrenew),"1") == 0)
            		return exitsub(reply,M_CA_PERSONAL_DENY_RENEW) ? M_CA_PERSONAL_DENY_RENEW :apiRC;
            	else if (strcmp(trim(funquery),"1") == 0)
            		return exitsub(reply,M_CA_PERSONAL_DENY_QUERY) ? M_CA_PERSONAL_DENY_QUERY :apiRC;
            	else if (strcmp(trim(fundelete),"1") == 0)
            		return exitsub(reply,M_CA_PERSONAL_DENY_DELETE) ? M_CA_PERSONAL_DENY_DELETE :apiRC;
            	else 
            		return exitsub(reply,M_CA_PERSONAL_DENY) ? M_CA_PERSONAL_DENY :apiRC;
         	}
            else
	    		rtncode = cm_chk_personal(iassured, 'C' , '*' , o_sDeny_msg, o_sFply_chk);
        }

       cm_buf_init(tmpbuf);
       if ( count == 0 )
       {
           cm_buf_res_msg();             /* reserve for MsgCode and count */
           cm_buf_res_count();
       }
       cm_buf_put("%s %s %s %s %s %s %s",ipolicy_ext,itag,nassured,sdply_begin,sdply_end,iofficer,nofficer);
       tmp_len = cm_buf_len(tmpbuf);
       if (tmp_len + repbuf_len < 3000)   /* buffer size less than 4K */
       {
           memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
           repbuf_len += tmp_len;
           count++;
       }
       else                               /* more than 4K, send to client side */
       {
           cm_buf_init(ReplyBuf);
           cm_buf_put_msg(M_CM_OK);
           cm_buf_put_count(count);
           if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
           {
                EXEC SQL CLOSE ass_curb;
                EXEC SQL FREE  ass_curb;
                return apiRC;
           }
           else            /* clear ReplyBuf and count to start all over again */
           {
                replycnt++;
                if (replycnt == 10)   /* more than 30K, client cannot display,error */
                {
                     cm_buf_init(ReplyBuf);
                     cm_buf_put("%l",M_CM_OUT_SPACE);
                     tmp_len = cm_buf_len(ReplyBuf);
                     if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
                          return apiRC;
                     return M_CM_OUT_SPACE;
                }
                ReplyBuf[0] = '\0';
                count = 0;
                cm_buf_init(ReplyBuf);
                cm_buf_res_msg();           /* reserve for MsgCode and count */
                cm_buf_res_count();
                cm_buf_put("%s %s %s %s %s %s %s",ipolicy_ext,itag,nassured,sdply_begin,sdply_end,iofficer,nofficer);
                repbuf_len = cm_buf_len(ReplyBuf);
                count++;
           }
       }
    } /* for loop */

    printf("count[%d]\n",count);

    EXEC SQL CLOSE ass_curb;
    EXEC SQL FREE ass_curb;

    if (count > 0)   /* break out, at least one record is selected */
    {
        cm_buf_init(ReplyBuf);
        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(count);
        if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
           return apiRC;
        else
           return api_OKComplete;
    }
    else            /* break out, not any row is found */
    {
       return exitsub(reply,M_CA_NASSURED_VS_PLY) ? M_CA_NASSURED_VS_PLY :apiRC;
    }

errexit:
   printf("SOLERR:%s\n",sqlca.sqlerrm);
   return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*********************************************************************/
/*      FOR ca1001_get_dataa   �O����                              */
/* REMARK                                                            */
/* NEED ADD fcomp_class_last, fcomp_class, mbusiness, iply_area      */
/* select mbusiness into $mbussiness then change to tmp_business     */
/*********************************************************************/
long car1001_multiple_querya(reply)
serverReply reply;
{
     /* standard defined host variables */
     $char DBName[5];
     long  rc;
     /* table policy */
     $char   ipolicy[POLICY_NUM_1],icard[CARD_NUM];
     $char   itmp_policy[POLICY_NUM_1];
     $char   s_dply_begin[10],s_dply_end[10];
     $long   dply_begin   ,  dply_end;
     $char   nassured[41],nuser[19],nbenef[43];
     $char   aassured[65],itel[21],iissue_ym[7],apayment[65];
     $char   tphone_con[21],tphone_ext_con[21],imovephone[21],iemail[51];
     $char   ipro_year[5],qpro_month[4],ibrand[9],icar_type[CA_CAR_TYPE_NUM];
     $char   icorps[11],icorps_name[13];
     $char   iengine[21],ibody[21],itag[CA_TAG_NUM];
     $char   ilicense[11],ibirth[10],fsex[2],fmarriage[2],iassured[11],iassured_ext[3];
     $char   iacc_align[3],flimit[2],nequipment[31], Frescue[2], Fno_mdeduct[2], iapplicant[13];
     $char   s_nequipment[201] , icode_note[11] , ncode_note[41];
     $char   fcomp_class_last[3],fcomp_class[3],iply_area[11],tmp_business[11];
     $long   months, qcylinder,mcredit;
     $short  pdmg_align,plia_align,pbrg_align;
     $dec_t  mcar_price;
     $char   s_mcar_price[10], ixxcard[19];
     $char   fcut[2],fcal_way[2],fpt[2],cdxxend[9],dxxend[11];
     $double qpt,psex_age,plia_acc,pdmg_acc;
     $char   fcomp_24[2],ibig_resource[5],fdamaged[2],fspecial[2];
     $char   fdiscount[2], napplicant[121];
     $double preward,mbusiness;
     $long   coverage1_31, coverage2_31, coverage3_32;
     $char   iabn_type[2], survey_num[121], bound_num[121];
     $double mequipment;
     /* end of policy */

     $char   ibound[421];
     
     /* table ply_ins_type */
     $char nbrand_abbr[13], s_dedr_begin[10], s_dedr_end[10],icredit_no[17];
     $char ncode[11], nbrand_abbr2[13], ncar_abbr2[13];
     $char iins_type[INSURANCE_TYPE], sFullName[20], stmt[4096], sDBSite[3];
     $long minjured_cover,mdeath_cover,mdamage_cover,mdeduct,mins_premium;
     $char provision[21],ndeduct[19],prndeduct[19];
     $char ideduct_c[9];

     $double pdiscount, deviation_rate;
     $long mdiscount,mprem;
     $long sum_mdiscount, sum_mprem;
     $double avg_pdiscount;
     $char s_avg_pdiscount[8];
     $double safe_rate, manage_rate;
     $char drate_ym[5];

     long mtot;
     $long qday;

     /* table ply_relation */
     $char irelative_ply[POLICY_NUM_1],ilast_ply[POLICY_NUM_1];
     $char inext_ply[POLICY_NUM_1],s_dtransfer[10];
     $char s_dpolicy[10],iresource[2],ibig_branch[3],ibig_office[10],ibig_sales[11];
     $char iresource_name[21], ibig_office4[6];
     $char iresource_tmp[23];
     $char s_dentry[10];
     $char fcard_class[2],iofficer[11],nname[13],nleader[13],ibig_nname[41];
     $long dtransfer,dpolicy,dedr_begin,dedr_end,mlia_prem;
     $long dentry;
     $char iarea[10];
     $char nequip_azpg[31], s_ftrans_trade[3], s_dtrans_trade[21];
     /* �q��������� dws9807211 */
     $char introducer[21],iroute_accept[21],iroute_prop[3];
     $char nroute_prop[21],sIpolicy1[POLICY_NUM_1], sIpolicy2[POLICY_NUM_2];
     $char iroute[21],iroute_name[41],imgr[2],iroute_main[13];
     $char irate_type[2],iroute_comm[4],icomm_obj[11];
     /* �e�~�O���,�s�W(�e�~�C�L,�l�H�覡) add by larry 103.03.11 (1010523004_C2) */
     $char fout_print[3],fmail_type[5],dout_trans[11],s_dout_trans[10];
     $char sFtypeSp[21], nsign[11];
     /* table edr_ins_type */
     $char iedr_type[3],iendorse[19];
     $char fcheckClose[2], fDplyClose[2];
     /* �F�����(�e�~)) */
     $char sIrouteNote[3], sMailRemark[9];
     $int  cntIroute;
     /*�s�W�l���ϸ��B��O���O*/
     $char aassured_zip[6],apayment_zip[6];
     $char aassured1[97],apayment1[97];
     $char iassured_cntry[2],nassured_cntry[50];
     /* standard defined data */
     char tmpbuf[4000];
     int count=0,repbuf_len=0,tmp_len=0,replycnt=0, fFound;
     int i,total_count=0;
     int j;

     /* self defined data */
     char  s_yy1[4],s_yy2[4],s_mm1[3],s_mm2[3],s_dd1[3],s_dd2[3];
     long  yy1,yy2,mm1,mm2;
     char     v_sMsg[1512];
     /* end of self data */

     ipolicy[0]=icard[0]=s_dply_begin[0]=s_dply_end[0]=nassured[0]=cdxxend[0]=0;
     dxxend[0]=nuser[0]=nbenef[0];
     dply_begin=dply_end=qpt=psex_age=plia_acc=pdmg_acc=0;
     aassured[0]=itel[0]=iissue_ym[0]=apayment[0]=ipro_year[0]=qpro_month[0]=fcut[0]=0;
     tphone_con[0]=tphone_ext_con[0]=imovephone[0]=iemail[0]=0;
     fcal_way[0]=fpt[0]=ibrand[0]=icar_type[0]=0;
     icorps[0]=icorps_name[0]=0;
     iengine[0]=ibody[0]=itag[0]=ilicense[0]=ibirth[0]=fsex[0]=fmarriage[0]=0;
     iacc_align[0]=flimit[0]=nequipment[0]=ibound[0]=survey_num[0]=bound_num[0]=0;
     irate_type[0]=iroute_comm[0]=icomm_obj[0]=0;
     months=qcylinder=pdmg_align=plia_align=pbrg_align=0;
     s_mcar_price[0]=0;
     nbrand_abbr[0]=s_dedr_begin[0]=s_dedr_end[0]=0;
     ncode[0]=nbrand_abbr2[0]=ncar_abbr2[0]=0;
     iins_type[0]=0;
     minjured_cover=mdeath_cover=mdamage_cover=mdeduct=mins_premium=0;
     qday=0;
     mtot=0;
     irelative_ply[0]=ilast_ply[0]=inext_ply[0]=s_dtransfer[0]=0;
     s_dpolicy[0]=iresource[0]=ibig_branch[0]=ibig_office[0]=ibig_sales[0]=0;
     iroute[0]=iroute_name[0]=iroute_main[0]=0;
     iresource_name[0]=0;
     s_dentry[0]=0;
     fcard_class[0]=0;
     dtransfer=dentry=dpolicy=dedr_begin=dedr_end=mlia_prem=0;
     iedr_type[0]=0;
     s_yy1[0]=s_yy2[0]=s_mm1[0]=s_mm2[0]=s_dd1[0]=s_dd2[0]=0;
     yy1=yy2=mm1=mm2=0;
     coverage1_31= coverage2_31= coverage3_32= 0;
     provision[0]='\0';
     mequipment = safe_rate = manage_rate = 0;
     fout_print[0]=fmail_type[0]=dout_trans[0]=0;
     sFtypeSp[0]=nsign[0]=0;
     fcheckClose[0]=fDplyClose[0]=0;
     sIrouteNote[0]=0;

     pdiscount = 0.00;
     mdiscount = 0;
     mprem = 0;
     sum_mdiscount = 0;
     sum_mprem = 0;
     avg_pdiscount = 0.0;
     s_avg_pdiscount[0] = 0;
     itmp_policy[0] = '\0';
     
     aassured_zip[0] = aassured1[0] = 0;
     apayment_zip[0] = apayment1[0] = 0;
     iassured_cntry[0] = nassured_cntry[0] = 0;
     
     tmp_feply[0]=feply1[0]=feply2[0]=0;
     aemail_eply[0]=dcreate_eply[0]=0;
     
     cm_buf_get("%s",DBName);
     cm_buf_get("%s %s %s",ipolicy,sUserid,fcheckClose);

     printf("querya db_select\n");
     if(db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
     printf("querya db_select end\n");

     strncpy(DBName,ipolicy,2); DBName[2]='\0';
     strcpy(sFullName, get_car_full_db(ipolicy));

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     if (strcmp(trim(fcheckClose), "1") == 0)
     {
     /*** check �O�_�w�鵲 ***/
     printf("querya assured_vs_ply bigin\n");
     EXEC SQL SELECT icard
                FROM assured_vs_ply
               WHERE ipolicy = :ipolicy;

     if(SQLCODE==SQLNOTFOUND)
        return exitsub(reply,M_RIN_CLOSING) ? M_RIN_CLOSING : apiRC;
     }

     printf("querya assured_vs_ply end\n");

     sprintf(stmt,
       "SELECT A.irelative_ply, A.ilast_ply, A.inext_ply, A.dtransfer, \
               B.ixxcard, A.dply_begin, A.dply_end, B.icard,B.iassured,B.iassured_ext,B.nassured,\
               B.nuser, B.nbenef, B.aassured_zip, B.aassured, B.itel, B.itel_night, B.mobil_phone, B.iemail, B.iply_area, B.apayment_zip, B.apayment, \
               to_char(B.dissue,'%%Y')::integer - 1911 || '/' || to_char(B.dissue,'%%m'), \
               A.ipro_year, B.qpro_month, A.ibrand, A.icar_type, B.qcylinder, B.iengine, \
               B.ibody, B.itag, B.ilicense, \
               to_char(B.dbirth,'%%Y')::integer - 1911 || '/' || to_char(B.dbirth,'%%m/%%d'),\
               B.fsex, B.fmarriage, \
               B.flimit, B.pdmg_align,B.pbrg_align, B.plia_align, \
               B.mcar_price, B.nequipment, \
               A.dpolicy, A.iresource,A.iofficer, \
               (SELECT nname from officer WHERE iofficer = A.ileader) as nleader, A.icorps, \
               A.ibig_branch, A.ibig_office, A.ibig_sales, B.iroute, A.fcard_class, \
               A.mlia_prem, B.fcut, B.fcal_way, B.qpt, B.fpt, B.psex_age, \
               B.plia_acc, B.pdmg_acc, B.nbrand_abbr, B.ncar_abbr, \
               A.iarea, B.fcomp_24, \
               A.fdiscount, \
               A.fcomp_class_last, A.fcomp_class, A.mbusiness, A.dentry, A.itmp_policy, B.napplicant, \
               A.ibig_office[1,4], B.iabn_type, B.mequipment, B.iapplicant, B.survey_num, B.bound_num, \
               A.irate_type,A.iroute_comm,A.icomm_obj, \
               CASE WHEN A.fout_print = '1' AND A.fmail_type = '0' THEN '�_' \
               ELSE CASE WHEN A.fout_print = '1' THEN '�O' ELSE '�_' END END , \
               decode(A.fmail_type,'1','���H','2','����','3','����','4','����',' '), \
               date(A.dout_trans),\
               (SELECT nname FROM officer WHERE iofficer = A.isign) AS nsign, \
               CASE WHEN A.dply_close IS NULL THEN '0' ELSE '1' END AS fDplyClose, \
               B.iassured_cntry , CASE WHEN A.ftrans_trade = '1' THEN '�O' ELSE '�_' END ,nvl(A.dtrans_trade,' '), \
               A.feply, A.aemail_eply, A.dcreate_eply \
          FROM %s:ply_relation A, %s:policy B \
         WHERE A.ipolicy = '%s' AND B.ipolicy = '%s' AND A.ipolicy=B.ipolicy",
               sFullName, sFullName, ipolicy, ipolicy);

     EXEC SQL PREPARE mqa_1 FROM :stmt;
     EXEC SQL DECLARE mqa_1_cursor CURSOR FOR mqa_1;
     EXEC SQL OPEN    mqa_1_cursor;
     EXEC SQL FETCH   mqa_1_cursor INTO $irelative_ply,$ilast_ply,$inext_ply,$dtransfer,
                                        $ixxcard, $dply_begin, $dply_end, $icard, $iassured, $iassured_ext, $nassured,
                                        $nuser, $nbenef, $aassured_zip, $aassured, $itel, $tphone_con,$imovephone,$iemail, $iply_area, $apayment_zip, $apayment,
                                        $iissue_ym,
                                        $ipro_year, $qpro_month, $ibrand, $icar_type, $qcylinder, $iengine,
                                        $ibody, $itag, $ilicense,
                                        $ibirth,
                                        $fsex, $fmarriage,
                                        $flimit,$pdmg_align, $pbrg_align,$plia_align,
                                        $s_mcar_price, $nequipment,
                                        $dpolicy, $iresource,$iofficer,$nleader,$icorps,
                                        $ibig_branch, $ibig_office, $ibig_sales, $iroute, $fcard_class,
                                        $mlia_prem, $fcut, $fcal_way, $qpt, $fpt, $psex_age,
                                        $plia_acc, $pdmg_acc, $nbrand_abbr2, $ncar_abbr2,
                                        $iarea, $fcomp_24,
                                        $fdiscount,
                                        $fcomp_class_last, $fcomp_class, $mbusiness, $dentry, $itmp_policy,
                                        $napplicant, $ibig_office4, $iabn_type, $mequipment, $iapplicant,
                                        $survey_num, $bound_num, $irate_type,$iroute_comm,$icomm_obj,
                                        $fout_print,$fmail_type,$dout_trans,$nsign,$fDplyClose,$iassured_cntry,$s_ftrans_trade,$s_dtrans_trade,
                                        $tmp_feply,$aemail_eply,$dcreate_eply;

     fFound = (SQLCODE == SQLNOTFOUND) ? 0 : 1;
     EXEC SQL CLOSE mqa_1_cursor;
     EXEC SQL FREE  mqa_1_cursor;
     if(!fFound)
         return exitsub(reply,M_CA_NPOLICY) ? M_CA_NPOLICY : apiRC;
     printf("read iofficer begin\n");

     /* �Ӹ갱���ˮ� add by sylvia 103.02.17 (1020924002_C2) */
     strcpy(o_sDeny_msg," ");     
     /*rtncode = chk_personal_deny( iassured, sMsg);
     if( rtncode == M_CA_PERSONAL_DENY)
     {
         iUnDeny=0;
         /* �bcu_code_data.itype=CK ���]�w��,�i�H�d�� 
         $select count(*) into $iUnDeny
            from cu_code_data where itype = 'CK' and icode = $sUserid;
         if (iUnDeny == 0)
            return exitsub(reply,M_CA_PERSONAL_DENY) ? M_CA_PERSONAL_DENY :apiRC;
         else
	    rtncode = cm_chk_personal(iassured, 'C' , '*' , o_sDeny_msg, o_sFply_chk);
     }*/
        iCountDeny=0;
        iCountFunsale=0;
        $select count(*),funrenew_ins[1,1],funquery_ins[1,1],fdelete_ins[1,1]
            into $iCountDeny,$funrenew,$funquery,$fundelete
            from cm_personal_deny
           where iassured = $iassured
             and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
             and ddeny <= today
             and (dexpire is null or dexpire >= today)
             GROUP BY 2,3,4;
             
             rtncode = cm_chk_personal(iassured, 'C' , '*' , o_sDeny_msg, o_sFply_chk);
             
        if(iCountDeny > 0)
        {
            iUnDeny=0;
            /*�bcu_code_data.itype=CK ���]�w��,�i�H�d��*/ 
            $select count(*) into $iUnDeny
               from cu_code_data where itype = 'CK' and icode = $sUserid;
			if (iUnDeny == 0)
         	{
         		if (strcmp(trim(funrenew),"1") == 0)
            		return exitsub(reply,M_CA_PERSONAL_DENY_RENEW) ? M_CA_PERSONAL_DENY_RENEW :apiRC;
            	else if (strcmp(trim(funquery),"1") == 0)
            		return exitsub(reply,M_CA_PERSONAL_DENY_QUERY) ? M_CA_PERSONAL_DENY_QUERY :apiRC;
            	else if (strcmp(trim(fundelete),"1") == 0)
            		return exitsub(reply,M_CA_PERSONAL_DENY_DELETE) ? M_CA_PERSONAL_DENY_DELETE :apiRC;
            	else 
            		return exitsub(reply,M_CA_PERSONAL_DENY) ? M_CA_PERSONAL_DENY :apiRC;
         	}
            else
	    		rtncode = cm_chk_personal(iassured, 'C' , '*' , o_sDeny_msg, o_sFply_chk);
        }

     /*�s�y�~��*/
     strcat(ipro_year, "/");
     strcat(ipro_year, trim(qpro_month));
     printf("**********************ipro_year = %s\n",ipro_year);

     /**Ū���g��H����****/
     EXEC SQL SELECT  nname,nvl(imgr,' ')
                INTO  :nname,:imgr
                FROM  officer
               WHERE  iofficer = :iofficer;

     printf("read iofficer end\n");

     /**Ū��¾�ΥN������****/
     if (icorps[0] != '\0' && icorps[0] != ' ')
     {
          EXEC SQL SELECT  nname
                     INTO  :icorps_name
                     FROM  officer
                    WHERE  iofficer = :icorps;
     }

     EXEC SQL SELECT ncode[1,20]
                INTO :iresource_tmp
                FROM cu_code_data
               WHERE itype = '10'
                 AND icode = $iresource;

     if (SQLCODE == SQLNOTFOUND)
     {
          strcpy(iresource_name,iresource);
     }
     else
     {
          strcpy(iresource_name,trim(iresource));
          strcat(iresource_name,":");
          strcat(iresource_name,trim(iresource_tmp));
     }

     EXEC SQL SELECT nequipment
                INTO $nequip_azpg
                FROM conv_nequipment
               WHERE ipolicy = $ipolicy;
     if (SQLCODE == SQLNOTFOUND)
     {
        strcpy(nequip_azpg," ");
     }

     /* car9804172 get_route_data input ������~��/�q���N��,���ӳq����~���N��
        �H�θg��N��,�^�Ǩ���/�q����~������W�� (2:����/�q����~��, 1:����/�q����~��) */
     /* imgr=1���ɭԬO���ӥ�,�Ǩ�����~��,��L���h�ǤJ�q���N�� */
     if (imgr[0] == '1')
        rc = get_route_data(1, iofficer, ibig_office, ibig_sales, ibig_nname, v_sMsg);
     else
        rc = get_route_data(1, iofficer, iroute, ibig_sales, ibig_nname, v_sMsg);

     if (rc != M_CM_OK) strcpy(ibig_nname," ");
     /* end of Ū������/�q����~�� */

     /* Ū���q��������� dws9807211
        cm_route_data.column_1(���z�s��),cm_route_data.column_9(�q�����u),
        cm_route_data.column_10(�q��������O) */

        if ((rc = split_policy(ipolicy, sIpolicy1, sIpolicy2)) == M_CM_OK)
        {

           EXEC SQL SELECT nvl(column_1,' '),nvl(column_9,' '),nvl(column_10,' ')
                      INTO $iroute_accept,$introducer,$iroute_prop
                      FROM cm_route_data
                     WHERE ipolicy1 = $sIpolicy1
                       AND ipolicy2 = $sIpolicy2;

           if (SQLCODE == SQLNOTFOUND)
           {
              strcpy(iroute_accept,"");
              strcpy(introducer,"");
              strcpy(iroute_prop,"");
              strcpy(nroute_prop,"");
           } else
           {
        	      /* �Y�䪺��N�h����������q��������O */
        	         if (iroute_prop[0] != '\0' && iroute_prop[0] != ' ')
        	         {
        	   	      /*EXEC SQL SELECT ncode
                     INTO $nroute_prop
                     FROM cu_code_data
                    WHERE itype = 'BK'
                      AND icode = $iroute_prop;
                    if (SQLCODE == SQLNOTFOUND)  strcpy(nroute_prop,"");*/

                    $SELECT iroute_main INTO $iroute_main
                       FROM cm_route
                      WHERE iroute = $iroute;
                    if (SQLCODE == SQLNOTFOUND)  strcpy(iroute_main,"");

                    /*�u�q���ۭq�~�ȥN���v�令�d��cm_route_prop modify by larry 103.07.08 */
                    $SELECT nroute_prop INTO $nroute_prop
                       FROM cm_route_prop
                      WHERE iroute = $iroute_main
                        AND iroute_prop = $iroute_prop;
                      if (SQLCODE == SQLNOTFOUND)  strcpy(nroute_prop,"");
             	     }
                   else strcpy(nroute_prop,"");
        	   }
        }
        else
        {
        	   strcpy(iroute_accept,"");
        	   strcpy(introducer,"");
        	   strcpy(nroute_prop,"");
        }

     /* end of Ū���q��������� */

     /****Ū���H�Υd���****/

     /* 1041110002_C1 ���ӫO�N��X��H�Υd��J�{�ǽվ� 
        �H�Υd��ƥѭ�鵲����J�O�O�t��(ao_io_credit)�אּ�J���Y��J(�Y�j��P���N�X�ֽд�)
     */
     mcredit = 0;
     sprintf(stmt,"SELECT nvl(sum(nvl(mcredit,0)),0) FROM %s:ao_io_credit \
                    WHERE ipolicy1 = ? AND ipolicy2 = ? AND icard = ? \
                      AND nvl(icreditno,'') <> '' \
                      AND dentry = (SELECT max(dentry) FROM %s:ao_io_credit \
                                     WHERE ipolicy1 = ? AND ipolicy2 = ?  AND  icard = ? \
                                       AND nvl(icreditno,'') <> '' and dentry is not null) ",
            sFullName,sFullName);                   
     EXEC SQL PREPARE pre_credit  FROM :stmt;
     EXEC SQL EXECUTE pre_credit
                 INTO :mcredit
                USING :sIpolicy1, :sIpolicy2, :icard, :sIpolicy1, :sIpolicy2, :icard;
     printf("-- trace 1mcredit[%ld]\n ",mcredit);
     if (SQLCODE == SQLNOTFOUND)
     {                     	    	      
	     sprintf(stmt,"SELECT nvl(sum(nvl(mcredit,0)),0)  From %s:cm_credit_pay \
	                    WHERE ipolicy1 = ? AND ipolicy2 = ? \
	                      AND nvl(icreditno,'') <> '' ",sFullName);
	     EXEC SQL PREPARE credit_stmt  FROM :stmt;
	     EXEC SQL EXECUTE credit_stmt
	                 INTO :mcredit
	                USING :sIpolicy1, :sIpolicy2;
	     if (SQLCODE == 100)
	     {
	         mcredit = 0;
	     }
     }
     printf("read credit end\n");

     /**Ū���q�ܸ��****/
     EXEC SQL DECLARE tphone_cur1 CURSOR FOR
               SELECT tphone_ext_con
                 FROM cu_customer
                WHERE ifpce_id = :iassured
                  AND ifpce_id_ext = :iassured_ext;
     EXEC SQL OPEN  tphone_cur1;
     EXEC SQL FETCH tphone_cur1 INTO $tphone_ext_con;

     if (SQLCODE==SQLNOTFOUND)
         {
             strcpy(tphone_ext_con, " ");
             printf("read cu_customer notfound\n");
         }

     EXEC SQL CLOSE tphone_cur1;
     EXEC SQL FREE  tphone_cur1;
     printf("read cu_customer end\n");

     strcpy(s_dtransfer,cm_cdate_str_100(dtransfer));
     strcpy(s_dply_begin,cm_cdate_str_100(dply_begin));
     strcpy(s_dply_end,cm_cdate_str_100(dply_end));

     cm_split_ymd_100(s_dply_begin,s_yy1,s_mm1,s_dd1);
     cm_split_ymd_100(s_dply_end,s_yy2,s_mm2,s_dd2);
     yy1=atol(s_yy1);
     yy2=atol(s_yy2);
     mm1=atol(s_mm1);
     mm2=atol(s_mm2);

     months=(long)(yy2-yy1)*12+(mm2-mm1);

     strcpy(s_dpolicy,cm_cdate_str_100(dpolicy));
     strcpy(s_dentry,cm_cdate_str_100(dentry));
     strcpy(s_dout_trans,cm_from_infdate_100(dout_trans));

     /*** ��Ū���O���� ***/
     strcpy(equipdecode,equip_get(nequipment));
		 printf("1996:equipdecode=[%s]\n",equipdecode);
     s_nequipment[0] = '\0';
     IEquip_ptr=IfirstEquip;
     while (IEquip_ptr)
     {
         strcpy(icode_note , IEquip_ptr->sequip);
         printf("2002:icode_note[%s]\n",icode_note);
         iTmpcode = atoi(icode_note);
         sprintf(icode_note,"%02d",iTmpcode);
         printf("2009:icode_note[%s]\n",icode_note);
         EXEC SQL SELECT ncode
                    INTO :ncode_note
                    FROM cu_code_data
                   WHERE itype = '25'
                     AND icode = :icode_note;
         if (SQLCODE != SQLNOTFOUND)
         {
             strcat(s_nequipment,"�i");
             strcat(s_nequipment,rtrim(icode_note));
             strcat(s_nequipment,":");
             strcat(s_nequipment,rtrim(ncode_note));
             strcat(s_nequipment,"�j");
         }

         IEquip_ptr=IEquip_ptr->next;
     }

     strcpy( sDbname, sFullName);
     strcpy( sColumn, "ipolicy");
     strcpy( sTable,  "ca_ply_bound");
     rc = get_ca_ply_bound( sDbname, sTable, sColumn, ipolicy, ibound, v_sMsg);
     if( rc != M_CM_OK)
         return exitsub(reply,rc) ? rc : apiRC;

     /* �W�[�u�O�����O�ʽ�v��� add by larry 104.01.19 (1040107011_C1) */
     /* �ĳq�ʽ��� car_code.kind = '39' */
     sprintf(stmt,"SELECT a.ftype_sp||NVL((SELECT chiname FROM car_code \
                                            WHERE kind = '39' AND detail2 = '' \
                                              AND detail = a.ftype_sp),' ') \
                     From sysdb:cm_pre_receive a \
                    WHERE a.iins_cat = 'C' \
                      AND a.ipre_rcv = '%s' \
                      AND a.iins_kind = '%s' \
                      AND a.ipre_end = ' ' ", itmp_policy, fcard_class);
     $PREPARE ftypeSp_stmt FROM $stmt;
     $EXECUTE ftypeSp_stmt INTO $sFtypeSp;
     
     cntIroute = 0;
     /* �i�F����ġj(�e�~)�u�l�H�覡�v�W�[�Ƶ����� (1041102003_C1) */
     sprintf(stmt,"SELECT chiname, count(*) \
                     FROM car_code \
                    WHERE kind = 'SR' \
                      AND detail = '%s' \
                      AND detail2 = '%s' \
                    GROUP BY chiname;", iroute, iofficer);
     $PREPARE outIroute_cur FROM $stmt;
     $EXECUTE outIroute_cur INTO $sIrouteNote, $cntIroute;
     
     if (cntIroute > 0 && (equip_cmp(nequipment,"37") != TRUE))
         strcpy(sMailRemark, "�i��I�g��j");
     else
         strcpy(sMailRemark, " ");
/********************************************************
     j=strlen(nequipment);
     printf("j[%d]\n",j);
     for (i=0;i<j;i++)
     {
        printf("i[%d]\n",i);
        if (nequipment[i] == '1')
        {
            strcpy(icode_note , itoa(i+1));
            printf("icode_note[%s]\n",icode_note);
            EXEC SQL SELECT ncode
                       INTO :ncode_note
                       FROM cu_code_data
                      WHERE itype = '25'
                        AND icode = :icode_note;
            if (SQLCODE == SQLNOTFOUND)
                 strcpy(ncode_note, "");
            strcat(s_nequipment,"�i");
            strcat(s_nequipment,trim(icode_note));
            strcat(s_nequipment,":");
            strcat(s_nequipment,trim(ncode_note));
            strcat(s_nequipment,"�j");
        }
     }
***********************************************************/
     printf("nequipment[%s],s_nequipment[%s]\n",nequipment,s_nequipment);
     
     strcat(aassured1,aassured_zip);
     strcat(aassured1," ");
     strcat(aassured1,aassured);
     strcat(apayment1,apayment_zip);
     strcat(apayment1," ");
     strcat(apayment1,apayment);
     
     if(strcmp(iassured_cntry,"1",1) == 0)
     strcpy(nassured_cntry,"�����I��a");
     else if(strcmp(iassured_cntry,"2",1) == 0)
     strcpy(nassured_cntry,"�j���H(���t��D)");
     else if(strcmp(iassured_cntry,"8",1) == 0)
     strcpy(nassured_cntry,"��L");
     else
     strcpy(nassured_cntry,"����H");
     
     cm_buf_init(ReplyBuf);
     cm_buf_res_msg();
     cm_buf_res_count();
     cm_buf_put_msg(M_CM_OK);
     cm_buf_put("%s %s %s %s %l %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
                irelative_ply,ilast_ply,inext_ply,s_dtransfer,months,
                s_dply_begin,s_dply_end,icard,iassured,nassured,ibirth,nuser,nbenef,
                aassured1,itel,tphone_con,tphone_ext_con,imovephone,iemail,
                apayment1,iissue_ym,ipro_year,ibrand,icar_type);
     /* ADD FOR ISPS 870610 */
     sprintf(tmp_business,"%10.3f",mbusiness);
     cm_buf_put("%s %s %s %s ",iply_area,fcomp_class_last,fcomp_class,tmp_business);
     /* ADD END */

     cm_buf_put("%s %s %s",fout_print, fmail_type, s_dout_trans);
     cm_buf_put("%l %s %s %s ", qcylinder, iengine, ibody, itag);

     cm_buf_put("%c %l %l ", flimit[0], pdmg_align, pbrg_align);
     /* DELETE frescue, fno_mdeduct */
     cm_buf_put("%l %s %s ", plia_align, s_mcar_price, s_nequipment);
     cm_buf_put("%s %s %s ", s_dpolicy,iresource_name,ibig_branch);
     cm_buf_put("%s %s %s %s %s %s %s %s %s %l",iofficer,nname,nleader,icorps,icorps_name,ibig_office,ibig_sales,ibig_nname, "",mcredit);
     /* dws9807211 */
printf("intro[%s],accept[%s],prop[%s]\n",introducer,iroute_accept,nroute_prop);
     cm_buf_put("%s %s %s %s",introducer,iroute_accept,nroute_prop,iroute);

     cm_buf_put("%s %s %f %s %f %s %f %f",
                fcut,fcal_way,qpt,fpt,
                psex_age,fcard_class,plia_acc,pdmg_acc);

     printf("irelative_ply[%s]\n",irelative_ply);

     if (irelative_ply[0]=='\0' || irelative_ply[0]==' ' || irelative_ply[0]=='A')
          cm_buf_put("%s",irelative_ply);
     else
     {
          EXEC SQL SELECT icard INTO :icard
                     FROM assured_vs_ply
                    WHERE ipolicy = :irelative_ply;
          if(SQLCODE==SQLNOTFOUND) icard[0]='\0';
          cm_buf_put("%s",icard);
     }

     EXEC SQL DECLARE car_mode_cur1 CURSOR FOR
               SELECT nbrand_abbr
                 FROM ca_car_model
                WHERE ibrand = :ibrand AND ipro_year = :ipro_year;
     EXEC SQL OPEN  car_mode_cur1;
     EXEC SQL FETCH car_mode_cur1 INTO :nbrand_abbr;
     EXEC SQL CLOSE car_mode_cur1;
     EXEC SQL FREE  car_mode_cur1;

     if (SQLCODE==SQLNOTFOUND)
         memset(nbrand_abbr,' ',sizeof(nbrand_abbr));

     cm_buf_put("%s",nbrand_abbr);

     EXEC SQL DECLARE car_type_cur1 CURSOR FOR
               SELECT ncode
                 INTO :ncode
                 FROM car_type
                WHERE icode = :icar_type AND fclass="1";
     EXEC SQL OPEN car_type_cur1;
     EXEC SQL FETCH car_type_cur1 INTO :ncode;
     EXEC SQL CLOSE car_type_cur1;
     EXEC SQL FREE car_type_cur1;

     if(SQLCODE==SQLNOTFOUND)
         memset(ncode,' ',sizeof(ncode));
     cm_buf_put("%s",ncode);

     cm_buf_put("%s", iarea);
     cm_buf_put("%s", fcomp_24);
     cm_buf_put("%s %s %f %s", fdiscount,iabn_type,mequipment, iapplicant);
/**/ cm_buf_put("%s", nassured_cntry);    

     printf("$$$$$$$$$$sum_mdiscount[%ld],sum_mprem[%ld]\n",sum_mdiscount,sum_mprem);

     sprintf(stmt, "SELECT iins_type, dedr_begin, dedr_end, minjured_cover, mdeath_cover, \
                           mdamage_cover, mdeduct, mins_premium, iendorse, pdiscount, mdiscount, \
                           mprem, qday, provision, deviation_rate, drate_ym, safe_rate, manage_rate \
                      FROM %s:ply_ins_type \
                     WHERE ipolicy = '%s' ", sFullName, ipolicy);
     printf("q_cur5 ipolicy------->[%s]\n",ipolicy);
     EXEC SQL PREPARE mqa_2 FROM :stmt;
     EXEC SQL DECLARE q_cur5 CURSOR FOR mqa_2;
     EXEC SQL OPEN q_cur5;
     count = mtot = 0;
     for(;;)
     {
        EXEC SQL FETCH q_cur5 INTO $iins_type, $dedr_begin, $dedr_end, $minjured_cover,
                                   $mdeath_cover, $mdamage_cover, $mdeduct,
                                   $mins_premium, $iendorse, $pdiscount, $mdiscount,
                                   $mprem, $qday, $provision, $deviation_rate, $drate_ym, $safe_rate, $manage_rate;
        if (SQLCODE == SQLNOTFOUND) break;

        if(iendorse[0] != ' ' && iendorse[0] != '\0')
        {
            sprintf(stmt, "SELECT iedr_type \
                             FROM %s:edr_ins_type \
                            WHERE iendorse='%s' AND iins_type='%s' ",
                                sFullName, iendorse, iins_type);
            EXEC SQL PREPARE mqa_3 FROM $stmt;
            EXEC SQL DECLARE mqa_3_cursor CURSOR FOR mqa_3;
            EXEC SQL OPEN mqa_3_cursor;
            EXEC SQL FETCH mqa_3_cursor INTO $iedr_type;
            fFound = (SQLCODE == SQLNOTFOUND) ? 0 : 1;
            EXEC SQL CLOSE mqa_3_cursor;
            EXEC SQL FREE  mqa_3_cursor;
            if(!fFound) iedr_type[0]='\0';
        }
        else
            iedr_type[0]='\0';

        /* �ۭt�B���� */
        strcpy(ideduct_c,itoa(mdeduct));
        rc = get_deduct_info(icar_type,iins_type,ideduct_c,ndeduct,prndeduct);

        /* �W�B�d���I */
        if (strcmp(trim(iins_type),"29")==0)
        {
             printf("iins_type[%s],qday[%ld]\n",iins_type,qday);
             rc = lReturnIns29BaseCover(qday,&coverage1_31,&coverage2_31,&coverage3_32);
             qday = 0;
             printf("qday[%ld],coverage1[%ld],coverage2[%ld],coverage3[%ld]\n",qday,coverage1_31,coverage2_31,coverage3_32);
        }
        /* 31�d���I */
        if (strcmp(trim(iins_type),"31")==0 || strcmp(trim(iins_type),"36")==0)
        {
           qday = 0;
        }
	if (strcmp(trim(iins_type),"21")==0)
        {
           mdamage_cover = 2200000;
        }
	
        strcpy(s_dedr_begin,cm_cdate_str_100(dedr_begin));
        strcpy(s_dedr_end,cm_cdate_str_100(dedr_end));

        sum_mdiscount += mdiscount;
        sum_mprem     += mprem;
        printf("$$$$$$$$$$sum_mdiscount[%ld],sum_mprem[%ld]\n",sum_mdiscount,sum_mprem);

        cm_buf_put("%s %s %s %l %l %l %s %l %s %l %f %s %e %s %e %e",
                    iins_type,s_dedr_begin,s_dedr_end,minjured_cover,
                    mdeath_cover,mdamage_cover,prndeduct,mins_premium,
                    iedr_type,qday,pdiscount,provision, deviation_rate,
                    drate_ym, safe_rate, manage_rate);
        count++;
        mtot+=mins_premium;
     }  /* for loop */
     printf("q_cur5 loop end\n");
     EXEC SQL CLOSE q_cur5;
     EXEC SQL FREE  q_cur5;

     cm_buf_put_count(count);

     cm_buf_put("%l %l %l",coverage1_31,coverage2_31,coverage3_32);
     cm_buf_put("%l",mtot);
     cm_buf_put("%s",ixxcard);  /**** 84.05.17 ****/

     if( sum_mprem > 0 )
     {
        avg_pdiscount = (double)sum_mdiscount / (double)sum_mprem * 100.0;
     }
     else
        avg_pdiscount = 0;
     printf("$$$$$$$$$$sum_mdiscount[%ld],sum_mprem[%ld]\n",sum_mdiscount,sum_mprem);
     rfmtdouble(avg_pdiscount,"--&.&&",s_avg_pdiscount);
     cm_buf_put("%s",s_avg_pdiscount);

     cm_buf_put("%s",s_dentry);
     cm_buf_put("%s",itmp_policy);
     cm_buf_put("%s",nequip_azpg);
     cm_buf_put("%s",napplicant);
     cm_buf_put("%s %s %s", survey_num, bound_num, ibound);
     cm_buf_put("%s %s %s %s ", irate_type, iroute_comm, icomm_obj, sFtypeSp);
     cm_buf_put("%s",nsign);
     
     /* ���O 0:���鵲, 1:�w�鵲 */
     cm_buf_put("%s",fDplyClose);

     /*�Ӹ�P�_*/
     printf("iCountDeny[%d],iCountFunsale[%d]\n",iCountDeny,iCountFunsale);
     printf("o_sDeny_msg[%s]\n",o_sDeny_msg);     
     cm_buf_put("%s",o_sDeny_msg);
     
     /*�u�l�H�覡�v�Ƶ����� */
     cm_buf_put("%s",sMailRemark);
     printf("-- trace s_ftrans_trade[%s]\n ",s_ftrans_trade);     
     cm_buf_put("%s",s_ftrans_trade); /* �u���T�Y�ɶǿ��v���O */
     cm_buf_put("%s",s_dtrans_trade); /* �u���T�Y�ɶǿ��v�ǿ�ɶ� */
     
     /* �q�l�O���T */
     sprintf(stmt,"SELECT feply \
                     FROM %s:ply_relation \
                    WHERE ipolicy = '%s' ;",sFullName, irelative_ply);
     $PREPARE feply_cur FROM $stmt;
     $EXECUTE feply_cur INTO $tmpp_feply;
     
     if(fcard_class[0] == '1')
     {
     	strcpy(feply1,tmp_feply);
     	strcpy(feply2,tmpp_feply);
     }
     else
     {
     	strcpy(feply1,tmpp_feply);
     	strcpy(feply2,tmp_feply);
     }
     
     cm_buf_put("%s %s %s %s", feply1, feply2, aemail_eply, dcreate_eply);

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     return api_OKComplete;

errexit:
     printf("stmt=[%s]\n",stmt);
     printf("SOLERR:%s\n",sqlca.sqlerrm);
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*********************************************************************/
/*  �����O�T�d��  Modified by Julia Han in 2007/01/24                */
/*********************************************************************/
long car1001_multiple_queryb(reply)
serverReply reply;
{
    /* standard defined host variables */
    $char DBName[5],stmt[4096],sFullName[20];
    /* end of standard host var */

    /* data from db */
    $char ipolicy[POLICY_NUM_1],ipolicy_ext[POLICY_NUM_1];
    $char iassured[11],nassured[121];
    $char dpolicy[11],dply_begin[11],dply_end[11];
    $char aassured_zip[6],aassured[91],icar_flag[2],iparts[2];
    $int qperiod,qperiod_ori,qmiles,qmiles_ori;
    $long mcover1,mcover2,mdeduct;
    $char iassured_e[11],nassured_e[121];
    $char dpolicy_e[11],dply_begin_e[11],dply_end_e[11];
    $char itag_e[CA_TAG_NUM],iengine_e[21],ipro_year_e[5];
    $int qpro_month_e;
    $char nbrand_abbr_e[13],ibrand_e[9];
    $double mkilo_ply_e,pdiscount_e;
    $long mprem_e;
    $char irisk_e[2],iresource_e[2],ncode_e[41],iofficer_e[11],offnname_e[11];
    $char nleader[11];
    $char dentry_e[11],ientry_e[11],ientnname_e[11];
    $char irelative_ply[POLICY_NUM_1];  /* �d�ߩ����O�T���p�渹 */
    /* end of db */

    /* New definition of data from db */
    /* end of define */

    /* standard defined data */
    int count=0,tmp_len=0,fFound;
    char sdpolicy[12];
    char sdply_begin[12],sdply_end[12];
    char dyy[4],dmm[3],ddd[3]; /* ñ���� */
    char syy[4],smm[3],sdd[3]; /* �_�� */
    char eyy[4],emm[3],edd[3]; /* ���� */
    /* end of standard data */

     cm_buf_get("%s",DBName);
     cm_buf_get("%s %s",ipolicy,sUserid);

     if(db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     /*strncpy(DBName,ipolicy_rel,2); DBName[2]='\0';*/
     strcpy(sFullName, get_car_full_db(ipolicy));

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     sprintf(stmt,
       "SELECT a.ipolicy,a.dpolicy,a.iassured,a.nassured,a.dply_begin,a.dply_end, \
       	       a.aassured_zip,a.aassured,a.icar_flag,a.iparts,a.qperiod,a.qmiles, \
       	       a.qperiod_ori,a.qmiles_ori,a.mcover1,a.mcover2,a.mdeduct, \
       	       c.dpolicy,b.iassured,b.nassured,c.dply_begin,c.dply_end, \
       	       b.itag,b.iengine,c.ipro_year,b.qpro_month,b.nbrand_abbr,c.ibrand, \
       	       b.mkilo_ply,(c.mdmg_prem+c.mlia_prem), \
       	       (select pdiscount from %s:ply_ins_type where iins_type='58' and ipolicy=b.ipolicy), \
       	       b.irisk,c.iresource, \
       	       (select ncode from cu_code_data where itype='10' and icode=c.iresource), \
       	       c.iofficer,(select nname from officer where iofficer=c.iofficer), \
       	       (select nname from officer where iofficer = c.ileader), \
       	       c.dentry,c.ientry,(select nname from officer where iofficer=c.ientry), \
       	       b.irelative_ext \
          FROM %s:ca_ply_ext a, %s:policy b, %s:ply_relation c \
         WHERE b.ipolicy = '%s'  \
           AND c.ipolicy = b.ipolicy \
           AND a.ipolicy = b.iext_policy \
         ORDER by a.dpolicy desc",
               sFullName, sFullName, sFullName, sFullName, ipolicy);

     EXEC SQL PREPARE mqb FROM :stmt;
     EXEC SQL DECLARE mqb_cursor CURSOR FOR mqb;
     EXEC SQL OPEN    mqb_cursor;
     EXEC SQL FETCH   mqb_cursor INTO $ipolicy_ext,$dpolicy,$iassured,$nassured,$dply_begin,$dply_end,
     					$aassured_zip,$aassured,$icar_flag,$iparts,$qperiod,$qmiles,
     					$qperiod_ori,$qmiles_ori,$mcover1,$mcover2,$mdeduct,
     					$dpolicy_e,$iassured_e,$nassured_e,
     					$dply_begin_e,$dply_end_e,
     					$itag_e,$iengine_e,$ipro_year_e,$qpro_month_e,$nbrand_abbr_e,
     					$ibrand_e,$mkilo_ply_e,$mprem_e,$pdiscount_e,
     					$irisk_e,$iresource_e,$ncode_e,$iofficer_e,$offnname_e,
     					$nleader,
     					$dentry_e,$ientry_e,$ientnname_e,$irelative_ply;

     fFound = (SQLCODE == SQLNOTFOUND) ? 0 : 1;
     EXEC SQL CLOSE mqb_cursor;
     EXEC SQL FREE  mqb_cursor;
     if(!fFound)
         return exitsub(reply,M_CA_NPOLICY) ? M_CA_NPOLICY : apiRC;

     /* �Ӹ갱���ˮ� add by sylvia 103.02.17 (1020924002_C2) */
     strcpy(o_sDeny_msg," ");
     iCountDeny=0;
        iCountFunsale=0;
        $select count(*),funrenew_ins[1,1],funquery_ins[1,1],fdelete_ins[1,1]
            into $iCountDeny,$funrenew,$funquery,$fundelete
            from cm_personal_deny
           where iassured = $iassured
             and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
             and ddeny <= today
             and (dexpire is null or dexpire >= today)
             GROUP BY 2,3,4;
             
             rtncode = cm_chk_personal(iassured, 'C' , '*' , o_sDeny_msg, o_sFply_chk);
             
        if(iCountDeny > 0)
        {
            iUnDeny=0;
            /*�bcu_code_data.itype=CK ���]�w��,�i�H�d��*/ 
            $select count(*) into $iUnDeny
               from cu_code_data where itype = 'CK' and icode = $sUserid;
               
	         if (iUnDeny == 0)
	         {
	         	if (strcmp(trim(funrenew),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_RENEW) ? M_CA_PERSONAL_DENY_RENEW :apiRC;
	            else if (strcmp(trim(funquery),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_QUERY) ? M_CA_PERSONAL_DENY_QUERY :apiRC;
	            else if (strcmp(trim(fundelete),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_DELETE) ? M_CA_PERSONAL_DENY_DELETE :apiRC;
	            else 
	            	return exitsub(reply,M_CA_PERSONAL_DENY) ? M_CA_PERSONAL_DENY :apiRC;
	         }
	         else
		    	rtncode = cm_chk_personal(iassured, 'C' , '*' , o_sDeny_msg, o_sFply_chk);
        }


     /* Transfer date to Chinese format - �D�O��ñ���� and �D�O��_����� */
     strcpy(sdpolicy,cm_from_infdate_100(dpolicy));
     cm_split_ymd_100(sdpolicy,dyy,dmm,ddd);
     strcpy(sdply_begin,cm_from_infdate_100(dply_begin));
     cm_split_ymd_100(sdply_begin,syy,smm,sdd);
     strcpy(sdply_end,cm_from_infdate_100(dply_end));
     cm_split_ymd_100(sdply_end,eyy,emm,edd);
     /* End of transfer */

     /* init. putting data */
     cm_buf_init(ReplyBuf);
     cm_buf_res_msg();
     cm_buf_res_count();
     cm_buf_put_msg(M_CM_OK);
     /* end of init. */

     /* put �����O�T�D�O���� */
     cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %d %d %d %d %ld %ld %ld",
                ipolicy_ext,dyy,dmm,ddd,iassured,nassured,syy,smm,sdd,eyy,emm,edd,
                aassured_zip,aassured,icar_flag,iparts,qperiod,qmiles,qperiod_ori,
                qmiles_ori,mcover1,mcover2,mdeduct);
     strcpy(sdpolicy,"");
     strcpy(sdply_begin,"");
     strcpy(sdply_end,"");
     strcpy(dyy,"");
     strcpy(dmm,"");
     strcpy(ddd,"");
     strcpy(syy,"");
     strcpy(smm,"");
     strcpy(sdd,"");
     strcpy(eyy,"");
     strcpy(emm,"");
     strcpy(edd,"");
     /* end of putting */

     /* Transfer date to Chinese format - �l�O��ñ���� and �l�O��_����� */
     strcpy(sdpolicy,cm_from_infdate_100(dpolicy_e));
     cm_split_ymd_100(sdpolicy,dyy,dmm,ddd);
     strcpy(sdply_begin,cm_from_infdate_100(dply_begin_e));
     cm_split_ymd_100(sdply_begin,syy,smm,sdd);
     strcpy(sdply_end,cm_from_infdate_100(dply_end_e));
     cm_split_ymd_100(sdply_end,eyy,emm,edd);
     /* end of transfer */

printf("���p�渹[%s]\n",irelative_ply);
     /* put �l�O���� */
     cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %d %s %s %f %d %f %s %s %s %s %s %s %s %s %s %s",
     		ipolicy,dyy,dmm,ddd,syy,smm,sdd,eyy,emm,edd,iassured_e,nassured_e,
     		itag_e,iengine_e,ipro_year_e,qpro_month_e,nbrand_abbr_e,ibrand_e,
     		mkilo_ply_e,mprem_e,pdiscount_e,irisk_e,iresource_e,ncode_e,iofficer_e,
     		offnname_e,nleader,dentry_e,ientry_e,ientnname_e,irelative_ply);

     /*�Ӹ�P�_*/
     cm_buf_put("%s",o_sDeny_msg);
     /* End of putting */



     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     return api_OKComplete;

errexit:
     printf("stmt=[%s]\n",stmt);
     printf("SOLERR:%s\n",sqlca.sqlerrm);
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/************************************************************************/
/*         ca1001_get_datac                                             */
/*         ���������                                                 */
/************************************************************************/
long car1001_multiple_queryc(reply)
serverReply reply;
{
     /* standard defined host variables */
     $char DBName[5], sFullName[20], stmt[1024];
     long  rc;
     /* end of standard host var */

     /* table edr_relation endorsement */
     $char ipolicy[POLICY_NUM_1],iendorse[ENDORSE_NUM];
     $char icard[CARD_NUM],s_dendorse[10],s_dedr_begin[10],s_dedr_end[10];
     $long dendorse,dedr_begin,dedr_end,medrdmg_prem,medrlia_prem,dedr_close;
     $short dedr_close_id;
     $char icar_type[CA_CAR_TYPE_NUM],ibrand[9],itag[CA_TAG_NUM];
     $char fedr_class[2],fcal_way[2];
     $char nassured[41],aassured[65],itel[21],iedr_return[2];
     $char irelative_ply[POLICY_NUM_1];
     $char iedr_examiner[11];
     $char name_examiner[30];
     $long coverage1_31, coverage2_31, coverage3_32;
     $double mequipment;
     $char nsign[11];
     /* end of edr_relation endorsement */

     /* table edr_ins_type */
     $char iedr_type[3],iins_type[INSURANCE_TYPE];
     $long medrinj_cover,medrdea_cover,medrdmg_cover,medrins_prem,mdeduct;
     $long qday;
     $char provision[21];
     $char ideduct_c[9],ndeduct[19],prndeduct[19];
     $double deviation_rate;
     $double safe_rate, manage_rate;
     $char drate_ym[5], iassured[13];
     /* end of edr_int_type */

     /* standard defined data */
     char tmpbuf[4000];
     int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
     int i,total_count=0, fFound;
     /* end of standard data */

     /*** AOI ***/
     char ao_policy1[CAR_POLICY_LEN+1],ao_policy2[CAR_TARGET_LEN+1];

     /* self defined data */
     $long  qtot,qcount;
     char result[3];
     char desc[35],paydate[11],duedate[11];
     /* end of self data */

     ipolicy[0]=iendorse[0]=0;
     icard[0]=s_dendorse[0]=s_dedr_begin[0]=s_dedr_end[0]=0;
     dendorse=dedr_begin=dedr_end=medrdmg_prem=medrlia_prem=0;
     icar_type[0]=ibrand[0]=itag[0]=0;
     fedr_class[0]=0;
     nassured[0]=aassured[0]=itel[0]=0;
     irelative_ply[0]=0;
     iedr_type[0]=fcal_way[0]=iins_type[0]=0;
     medrinj_cover=medrdea_cover=medrdmg_cover=medrins_prem=mdeduct=0;
     qtot=qcount=0;
     result[0]=nsign[0]=0;
     desc[0]=paydate[0]=duedate[0]=0;
     coverage1_31= coverage2_31= coverage3_32= 0;
     provision[0]='\0';
     mequipment = safe_rate = manage_rate = 0;

     cm_buf_get("%s",DBName);
     cm_buf_get("%s %s",ipolicy,sUserid);

     printf("*********ipolicy[%s]**********\n",ipolicy);

     if(db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     strncpy(DBName,ipolicy,2); DBName[2]='\0';
     strcpy(sFullName, get_car_full_db(ipolicy));

     EXEC SQL WHENEVER SQLERROR GOTO errexit;
     sprintf(stmt, "SELECT icard, dendorse, dedr_begin, dedr_end, icar_type, \
                           ibrand, medrdmg_prem, medrlia_prem, fedr_class, \
                           irelative_ply, iendorse, iedr_return, iedr_examiner, dedr_close\
                      FROM %s:edr_relation a \
                     WHERE ipolicy='%s' AND iendorse[6,8] != 'CVP' \
                     ORDER BY dcreate", sFullName, ipolicy);
     EXEC SQL PREPARE mqc_1 FROM :stmt;
     EXEC SQL DECLARE cur1 CURSOR FOR mqc_1;
     EXEC SQL OPEN cur1;
     qtot = 0;
     for(;;)
     {
          EXEC SQL FETCH cur1 INTO $icard, $dendorse, $dedr_begin, $dedr_end, $icar_type,
                                   $ibrand, $medrdmg_prem, $medrlia_prem, $fedr_class,
                                   $irelative_ply, $iendorse, $iedr_return, $iedr_examiner,
                                   $dedr_close:dedr_close_id;

          if(SQLCODE==SQLNOTFOUND) break;
          sprintf(stmt, "SELECT a.itag, a.nassured, a.aassured, a.itel, a.mequipment, a.iassured, \
                                (SELECT nname FROM officer WHERE iofficer = b.isign) AS nsign \
                           FROM %s:endorsement a, %s:edr_relation b \
                          WHERE a.iendorse = b.iendorse \
                            AND a.iendorse='%s' ", sFullName, sFullName, iendorse);
          EXEC SQL PREPARE mqc_2 FROM :stmt;
          EXEC SQL DECLARE mqc_2_cursor CURSOR FOR mqc_2;
          EXEC SQL OPEN    mqc_2_cursor;
          EXEC SQL FETCH   mqc_2_cursor INTO :itag , :nassured , :aassured , :itel, :mequipment, :iassured,
          	                                 :nsign;
          fFound = (SQLCODE == SQLNOTFOUND) ? 0 : 1;
          EXEC SQL CLOSE   mqc_2_cursor;
          EXEC SQL FREE    mqc_2_cursor;
          if(!fFound) continue;

          /* �Ӹ갱���ˮ� add by sylvia 103.02.17 (1020924002_C2) */
           strcpy(o_sDeny_msg," ");
        iCountDeny=0;
        iCountFunsale=0;
         $select count(*),funrenew_ins[1,1],funquery_ins[1,1],fdelete_ins[1,1]
            into $iCountDeny,$funrenew,$funquery,$fundelete
            from cm_personal_deny
           where iassured = $iassured
             and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
             and ddeny <= today
             and (dexpire is null or dexpire >= today)
             GROUP BY 2,3,4;
             
             rtncode = cm_chk_personal(iassured, 'C' , '*' , o_sDeny_msg, o_sFply_chk);
             
        if(iCountDeny > 0)
        {
            iUnDeny=0;
            /*�bcu_code_data.itype=CK ���]�w��,�i�H�d��*/ 
            $select count(*) into $iUnDeny
               from cu_code_data where itype = 'CK' and icode = $sUserid;
            if (iUnDeny == 0)
         	{
	         	if (strcmp(trim(funrenew),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_RENEW) ? M_CA_PERSONAL_DENY_RENEW :apiRC;
	            else if (strcmp(trim(funquery),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_QUERY) ? M_CA_PERSONAL_DENY_QUERY :apiRC;
	            else if (strcmp(trim(fundelete),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_DELETE) ? M_CA_PERSONAL_DENY_DELETE :apiRC;
	            else 
	            	return exitsub(reply,M_CA_PERSONAL_DENY) ? M_CA_PERSONAL_DENY :apiRC;
         	}
            else
	    		rtncode = cm_chk_personal(iassured, 'C' , '*' , o_sDeny_msg, o_sFply_chk);
        }

          qtot++;
     }
     EXEC SQL CLOSE cur1;
     EXEC SQL FREE  cur1;

     if(qtot==0)
         return exitsub(reply,M_CA_NOREC_ERR) ? M_CA_NOREC_ERR : apiRC;

     strcpy(iedr_examiner, trim(iedr_examiner));

     $SELECT nname
        INTO :name_examiner
        FROM officer
       WHERE iofficer = :iedr_examiner;
     fFound = (SQLCODE == SQLNOTFOUND) ? 0 : 1;
     if(!fFound) strcpy(name_examiner, iedr_examiner);

     strcpy(s_dendorse,    cm_cdate_str_100(dendorse));
     strcpy(s_dedr_begin,  cm_cdate_str_100(dedr_begin));
     strcpy(s_dedr_end,    cm_cdate_str_100(dedr_end));

     cm_buf_init(ReplyBuf);
     cm_buf_res_msg();
     cm_buf_res_count();
     cm_buf_put_msg(M_CM_OK);
     cm_buf_put("%l %s %s %s %s %s %s %l %s %s %s %c %s %s %s %s %s %f",
                qtot,iendorse,icard,s_dendorse,name_examiner,
                s_dedr_begin,s_dedr_end,
                medrdmg_prem+medrlia_prem,icar_type,ibrand,itag,
                fedr_class[0],nassured,aassured,itel,irelative_ply,iedr_return,mequipment);

     sprintf(stmt, "SELECT iedr_type, iins_type, medrinj_cover, medrdea_cover, medrdmg_cover,\
                           medrins_prem, mdeduct, fcal_way, qday, provision, deviation_rate, \
                           drate_ym, safe_rate, manage_rate \
                      FROM %s:edr_ins_type \
                     WHERE iendorse='%s' ", sFullName, iendorse);

     EXEC SQL PREPARE mqc_3 FROM :stmt;
     EXEC SQL DECLARE q_cur6 CURSOR FOR mqc_3;
     EXEC SQL OPEN q_cur6;
     qcount=0;

     for(;;)
     {
        EXEC SQL FETCH q_cur6 INTO $iedr_type, $iins_type, $medrinj_cover, $medrdea_cover,
                                   $medrdmg_cover, $medrins_prem, $mdeduct, $fcal_way, $qday,
                                   $provision, $deviation_rate, $drate_ym, $safe_rate, $manage_rate;

        if (SQLCODE == SQLNOTFOUND) break;

        /* �W�B�d���I */
        if (strcmp(trim(iins_type),"29")==0)
        {
            if ((strcmp(trim(iedr_type),"01")==0) ||
                (strcmp(trim(iedr_type),"02")==0) ||
                (strcmp(trim(iedr_type),"03")==0) ||
                (strcmp(trim(iedr_type),"60")==0))
            {
                 coverage1_31=0;
                 coverage2_31=0;
                 coverage3_32=0;
            }
            else
            {
                 printf("iins_type[%s],qday[%ld]\n",iins_type,qday);
                 rc = lReturnIns29BaseCover(qday,&coverage1_31,&coverage2_31,&coverage3_32);
            }
            qday = 0;
            printf("qday[%ld],coverage1[%ld],coverage2[%ld],coverage3[%ld]\n",qday,coverage1_31,coverage2_31,coverage3_32);
        }

        /* 31�d���I */
        if (strcmp(trim(iins_type),"31")==0 || strcmp(trim(iins_type),"36")==0)
        {
           qday = 0;
        }

        cm_buf_put("%s %s %l %l %l %l %l %l %s %e",
                    iedr_type,iins_type,medrinj_cover/1000,
                    medrdea_cover/1000,medrdmg_cover/1000,mdeduct,medrins_prem,qday,provision, deviation_rate);
        cm_buf_put("%s %e %e",drate_ym,safe_rate,manage_rate);

        cm_buf_put("%s",fcal_way); /* �p��覡�]���H�I�ا@���,�G��ܤ]�H�I�ا@��� */
        qcount++;
     } /* for loop */
     EXEC SQL CLOSE q_cur6;
     EXEC SQL FREE  q_cur6;
     cm_buf_put_count(qcount);

     cm_buf_put ("%l %l %l",coverage1_31,coverage2_31,coverage3_32);

     if (dedr_close_id == -1)
     {
          cm_buf_put("%s"," ");
     }
     else
     {
          if ((medrdmg_prem+medrlia_prem==0) && fedr_class[0]!='3')
          {
              cm_buf_put("%s"," ");
          }
          else
          {
              split_ply(ipolicy,ao_policy1,ao_policy2);

              if (strlen(rtrim(ipolicy)) > CAR_POLICY_LEN) /*�j�O��*/
                 ao_chk_charge(DBName,'2',ao_policy1,ao_policy2,iendorse,result,
                                                         desc,paydate,duedate);
              else
                 ao_chk_charge(DBName,'2',ao_policy1," ",iendorse,result,
                                                         desc,paydate,duedate);
              cm_buf_put("%s",desc);
          }
     }

     cm_buf_put("%s",nsign);
     /*�Ӹ�P�_*/
     cm_buf_put("%s",o_sDeny_msg);
     cm_buf_put("%s",iassured);

     /*cm_buf_put("%s",fcal_way);*/

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
     return api_OKComplete;

errexit:
     printf("stmt=[%s]\n",stmt);
     printf("SOLERR:%s\n",sqlca.sqlerrm);
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long car1001_multiple_queryd(reply)
serverReply reply;
{
     /* �d�߫e���Φ�������� */
     /* standard defined host variables */
     $char DBName[5], sFullName[20], stmt[1024];
     long  rc;
     /* end of standard host var */

     /* table edr_relation endorsement */
     $char ipolicy[POLICY_NUM_1],iendorse[ENDORSE_NUM];
     $char icard[CARD_NUM],s_dendorse[10],s_dedr_begin[10],s_dedr_end[10];
     $long dendorse,dedr_begin,dedr_end,dedr_close,medrdmg_prem,medrlia_prem;
     $short dedr_close_id;
     $char icar_type[CA_CAR_TYPE_NUM],ibrand[9],itag[CA_TAG_NUM];
     $char fedr_class[2];
     $char nassured[41],aassured[65],itel[21];
     $char irelative_ply[POLICY_NUM_1];
     $char iedr_return[2];
     $char iedr_examiner[11];
     $char name_examiner[30];
     $long coverage1_31, coverage2_31, coverage3_32;
     $double mequipment;
     $char nsign[11];
     /* end of edr_relation endorsement */

     /* table edr_ins_type */
     $char iedr_type[3],iins_type[INSURANCE_TYPE];
     $long medrinj_cover,medrdea_cover,medrdmg_cover,medrins_prem,mdeduct;
     $long qday;
     $char provision[21];
     $char ideduct_c[9],ndeduct[19],prndeduct[19];
     $double deviation_rate;
     $double safe_rate, manage_rate;
     $char drate_ym[5],fcal_way[2], iassured[13];
     /* end of edr_int_type */

     /*** AOI ***/
     char ao_policy1[CAR_POLICY_LEN+1],ao_policy2[CAR_TARGET_LEN+1];

     /* standard defined data */
     char tmpbuf[4000];
     int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
     int i,total_count=0, fFound;
     /* end of standard data */

     /* self defined data */
     $long  qtot,qcount;
     int iindex;
     char result[3];
     char desc[35],paydate[11],duedate[11];
     /* end of self data */
     ipolicy[0]=iendorse[0]=0;
     icard[0]=s_dendorse[0]=s_dedr_begin[0]=s_dedr_end[0]=0;
     dendorse=dedr_begin=dedr_end=medrdmg_prem=medrlia_prem=0;
     icar_type[0]=ibrand[0]=itag[0]=0;
     fedr_class[0]=0;
     nassured[0]=aassured[0]=itel[0]=0;
     irelative_ply[0]=0;
     iedr_type[0]=iins_type[0]=nsign[0]=0;
     medrinj_cover=medrdea_cover=medrdmg_cover=medrins_prem=mdeduct=0;
     qtot=qcount=0;
     iindex=0;
     result[0]=0;
     desc[0]=paydate[0]=duedate[0]=0;
     coverage1_31= coverage2_31= coverage3_32= 0;
     dedr_close_id = 0;
     provision[0]='\0';
     mequipment = safe_rate = manage_rate = 0;

     cm_buf_get("%s",DBName);
     cm_buf_get("%s %s %l",ipolicy, sUserid, &iindex);
     if(db_select(DBName) == False)
       return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     printf("index=%d\n",iindex);
     strncpy(DBName,ipolicy,2);
     DBName[2]='\0';
     strcpy(sFullName, get_car_full_db(ipolicy));
     $WHENEVER SQLERROR GOTO errexit;
     sprintf(stmt,
       "SELECT icard, dendorse, dedr_begin, dedr_end, medrdmg_prem, \
               medrlia_prem, fedr_class, irelative_ply, iendorse, iedr_return, iedr_examiner, dedr_close, \
               (select nname from officer where iofficer = a.ileader) \
          FROM %s:edr_relation a \
         WHERE ipolicy='%s' AND iendorse[6,8] != 'CVP' \
      ORDER BY dcreate",
             sFullName, ipolicy);
     $PREPARE mqd_1 FROM $stmt;
     $DECLARE cur2 CURSOR FOR mqd_1;
     $OPEN cur2;
     qtot=0;
     for(;;){
       $FETCH cur2 INTO $icard,$dendorse,$dedr_begin,$dedr_end,$medrdmg_prem,
                        $medrlia_prem,$fedr_class, $irelative_ply,$iendorse,
                        $iedr_return,$iedr_examiner,$dedr_close:dedr_close_id;

       if(SQLCODE==SQLNOTFOUND) break;
       sprintf(stmt,
         "SELECT a.itag, a.nassured, a.aassured, a.itel, a.mequipment, a.iassured, \
                 (SELECT nname FROM officer WHERE iofficer = b.isign) AS nsign \
            FROM %s:endorsement a, %s:edr_relation b \
           WHERE a.iendorse = b.iendorse \
             AND a.iendorse='%s' ",
               sFullName, sFullName, iendorse);
       $PREPARE mqd_2 FROM $stmt;
       $DECLARE mqd_2_cursor CURSOR FOR mqd_2;
       $OPEN mqd_2_cursor;
       $FETCH mqd_2_cursor INTO $itag,$nassured,$aassured,$itel,$mequipment, $iassured,
                                $nsign;
       fFound = (SQLCODE == SQLNOTFOUND) ? 0 : 1;
       $CLOSE mqd_2_cursor;
       $FREE  mqd_2_cursor;
       if(!fFound) continue;

       /* �Ӹ갱���ˮ� add by sylvia 103.02.17 (1020924002_C2) */
        strcpy(o_sDeny_msg," ");
        iCountDeny=0;
        iCountFunsale=0;
        $select count(*),funrenew_ins[1,1],funquery_ins[1,1],fdelete_ins[1,1]
            into $iCountDeny,$funrenew,$funquery,$fundelete
            from cm_personal_deny
           where iassured = $iassured
             and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
             and ddeny <= today
             and (dexpire is null or dexpire >= today)
             GROUP BY 2,3,4;
             
             rtncode = cm_chk_personal(iassured, 'C' , '*' , o_sDeny_msg, o_sFply_chk);
             
        if(iCountDeny > 0)
        {
            iUnDeny=0;
            /*�bcu_code_data.itype=CK ���]�w��,�i�H�d��*/ 
            $select count(*) into $iUnDeny
               from cu_code_data where itype = 'CK' and icode = $sUserid;
            if (iUnDeny == 0)
         	{
	         	if (strcmp(trim(funrenew),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_RENEW) ? M_CA_PERSONAL_DENY_RENEW :apiRC;
	            else if (strcmp(trim(funquery),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_QUERY) ? M_CA_PERSONAL_DENY_QUERY :apiRC;
	            else if (strcmp(trim(fundelete),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_DELETE) ? M_CA_PERSONAL_DENY_DELETE :apiRC;
	            else 
	            	return exitsub(reply,M_CA_PERSONAL_DENY) ? M_CA_PERSONAL_DENY :apiRC;
         	}
            else
	    		rtncode = cm_chk_personal(iassured, 'C' , '*' , o_sDeny_msg, o_sFply_chk);
        }

       qtot++;
       if(qtot == iindex) break;
     }
     $CLOSE cur2;
     $FREE  cur2;

     if(qtot!=iindex)
       return exitsub(reply,M_CA_NOREC_ERR) ? M_CA_NOREC_ERR : apiRC;

     $SELECT nname
        INTO :name_examiner
        FROM officer
       WHERE iofficer = :iedr_examiner;
     fFound = (SQLCODE == SQLNOTFOUND) ? 0 : 1;
     if(!fFound) strcpy(name_examiner, iedr_examiner);

     strcpy(s_dendorse,cm_cdate_str_100(dendorse));
     strcpy(s_dedr_begin,cm_cdate_str_100(dedr_begin));
     strcpy(s_dedr_end,cm_cdate_str_100(dedr_end));

     cm_buf_init(ReplyBuf);
     cm_buf_res_msg();
     cm_buf_res_count();
     cm_buf_put_msg(M_CM_OK);
     cm_buf_put("%s %s %s %s %s %s %l %s %s %s %c %s %s %s %s %s %f",
                iendorse,icard,s_dendorse,name_examiner,s_dedr_begin,s_dedr_end,
                medrdmg_prem+medrlia_prem,icar_type,ibrand,itag,
                fedr_class[0],nassured,aassured,itel,irelative_ply,iedr_return,mequipment);
     sprintf(stmt,
       "SELECT iedr_type,iins_type,medrinj_cover,medrdea_cover, medrdmg_cover,\
               medrins_prem,mdeduct,qday,provision, deviation_rate, \
               drate_ym, safe_rate, manage_rate, fcal_way \
          FROM %s:edr_ins_type \
         WHERE iendorse='%s' ", sFullName, iendorse);

     $PREPARE mqd_3 FROM $stmt;
     $DECLARE q_cur7 CURSOR FOR mqd_3;
     $OPEN q_cur7;
     qcount=0;
     for(;;)
      {
        $FETCH q_cur7 INTO $iedr_type,$iins_type,$medrinj_cover,$medrdea_cover,
                           $medrdmg_cover,$medrins_prem,$mdeduct,$qday,$provision,$deviation_rate,
                           $drate_ym,$safe_rate,$manage_rate,$fcal_way;
        if (SQLCODE == SQLNOTFOUND) break;

        /* �W�B�d���I */
        if (strcmp(trim(iins_type),"29")==0)
        {
            if ((strcmp(trim(iedr_type),"01")==0) ||
                (strcmp(trim(iedr_type),"02")==0) ||
                (strcmp(trim(iedr_type),"03")==0) ||
                (strcmp(trim(iedr_type),"60")==0))
            {
                 coverage1_31=0;
                 coverage2_31=0;
                 coverage3_32=0;
            }
            else
            {
                 printf("iins_type[%s],qday[%ld]\n",iins_type,qday);
                 rc = lReturnIns29BaseCover(qday,&coverage1_31,&coverage2_31,&coverage3_32);
            }
            qday = 0;
            printf("qday[%ld],coverage1[%ld],coverage2[%ld],coverage3[%ld]\n",qday,coverage1_31,coverage2_31,coverage3_32);
        }

         /* 31�d���I */
        if (strcmp(trim(iins_type),"31")==0 || strcmp(trim(iins_type),"36")==0)
        {
           qday = 0;
        }

        cm_buf_put("%s %s %l %l %l %l %l %l %s %e",
                    iedr_type,iins_type,medrinj_cover/1000,
                    medrdea_cover/1000,medrdmg_cover/1000,mdeduct,
                    medrins_prem,qday,provision,deviation_rate);

        cm_buf_put("%s %e %e",drate_ym,safe_rate,manage_rate);
        cm_buf_put("%s",fcal_way); /* �p��覡�]���H�I�ا@���,�G��ܤ]�H�I�ا@��� */
        qcount++;
      } /* for loop */

     $CLOSE q_cur7;
     $FREE  q_cur7;
     cm_buf_put_count(qcount);

     cm_buf_put ("%l %l %l",coverage1_31,coverage2_31,coverage3_32);

     if (dedr_close_id == -1)
     {
          cm_buf_put("%s"," ");
     }
     else
     {
          if ((medrdmg_prem+medrlia_prem==0) && fedr_class[0]!='3')
          {
              cm_buf_put("%s"," ");
          }
          else
          {
              split_ply(ipolicy,ao_policy1,ao_policy2);
              if (strlen(rtrim(ipolicy)) > CAR_POLICY_LEN) /*�j�O��*/
                 ao_chk_charge(DBName,'2',ao_policy1,ao_policy2,iendorse,result,
                                                         desc,paydate,duedate);
              else
                 ao_chk_charge(DBName,'2',ao_policy1," ",iendorse,result,
                                                         desc,paydate,duedate);
              cm_buf_put("%s",desc);
          }
     }
     cm_buf_put("%s",nsign);
     /*�Ӹ�P�_*/
     cm_buf_put("%s",o_sDeny_msg);
     cm_buf_put("%s",iassured);

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
       return apiRC;
     return api_OKComplete;
errexit:
     printf("stmt=[%s]\n",stmt);
     printf("SOLERR:%s\n",sqlca.sqlerrm);
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/************************************************************************/
/* FOR ca1001q5, ca1001q6                                               */
/* NEED ADD �ݼo?�H �λF�d���                                          */
/* ��I��אּ���פ�                                                     */
/* �����X�I����                                                         */
/*                                                                      */
/* NEED MODIFY                                                          */
/* change iclose_type datatype from char to int                         */
/************************************************************************/
long car1001_multiple_querye(reply)
serverReply reply;
{
     /* standard defined host variables */
     $char DBName[5], sFullName[20],stmt[3000],stmt_1[3000];
     /* end of standard host var */

     char  sIpolicy1[POLICY_NUM_1], sIpolicy2[POLICY_NUM_2];

     /* table appraisal */
     $char  ipolicy[POLICY_NUM_1],iclaim[CLAIM_NUM],icard[CARD_NUM],s_dclaim[21],s_daccident[21];
     $char  iacc_reason[3],fpart[2],iadjuster[11],iadjuster_name[11],irelative_clm[15],frecover[2],frecover_1[2];
     $char  nacc_driver[19],iacc_license[11],dclaim[21],daccident[21],iacc_area[3];
     $char  iacc_birth[8],facc_sex[2],facc_marri[2],facc_duty[2],facc_rel[2];
     $char  facc_nation[2],facc_car[2];
     $short qainjure,qadeath,qacripple;
     $short qbinjure,qbdeath,qbcripple;
     $short qcinjure,qcdeath,qccripple;
     int    qtot, fFound;
     /* end of appraisal */

     $long test;

     /* table adjustment_ply */
     $char nassured[41],flimit[2],ibrand[9],itag[CA_TAG_NUM],iengine[21],ibody[21];
     $char Frescue[2], Fno_mdeduct[2],fcard_class[2];
     /* end of adjustment_ply */

     /* table settlement */
     $char istl_note[4],fstl[2];
     $int  iclose_type;
     $char stl_cdclose[11];
     $long stl_edclose;
     int   qtot2;
     /* end of settlement */

     /* table payment */
     $char ipayment[13],npayment[101];
     $long mpayment;
     int   qcount;
     /* end of payment */

     /* table stl_ins_type */
     $char iins_type[INSURANCE_TYPE],flast[2];
     $char flast_tmp[2];
     $long edclose;
     $long edgroup;
     $char cdclose[11];
     $char cdgroup[11];
     $long mins_audit,mins_stl,mins_dedu,mins_proc,mins_salv;
     int   qcount1,qcount2;
     /* end of stl_ins_type */

     /* table stl_victim_m */
     $char ivictim[11];
     $long mstl_health;

     /* table app_ins_type */
     $long mins_app;
     /* end of app_ins_type */

     /* standard defined data */
     char tmpbuf[4000];
     int  count=0,repbuf_len=0,tmp_len=0,replycnt=0;
     int  i,total_count=0;
     /* end of standard data */

     /* self defined data */
     char yy[3], unit[3];
     char flag[2];
     int  rtncode;
     /* end of self data */

     /*char ifpce_id_ext[3],nchi_full[100],xibank[8],xiaccount[15],pay_kind[2];
     char xfpay_cond[2],ipay_area[3],istl_obj[13],istl_obj_ext[3];*/
     /*char ifpce_id[11],tstl_remark[60],ibank[8],nchi_abv[13];
     char clm_pay_area[3],icur[3],iclose[15];*/

     int kind;
     $char ifpce_id_ext[3],nchi_full[41],xibank[8],xiaccount[15],pay_kind[11];
     $char xfpay_cond[2],ipay_area[3],istl_obj[13],istl_obj_ext[3];
     $long dpay;
     $int dpay_chk;
     $char dpay_c[11];
     $char ifpce_id[11],tstl_remark[61],ibank[8],nchi_abv[13];
     $char clm_pay_area[21],icur[3],iclose[15], iassured[13];
     char strIclose_type[6];

     ipolicy[0]=iclaim[0]=icard[0]=s_dclaim[0]=s_daccident[0]=0;
     iacc_reason[0]=fpart[0]=iadjuster[0]=irelative_clm[0]=0;
     frecover[0]=frecover_1[0]=iacc_license[0]=0;

     dclaim[0]=daccident[0]=0;
     iacc_birth[0]=facc_sex[0]=facc_marri[0]=facc_rel[0]=facc_duty[0]=0;
     nacc_driver[0]=facc_nation[0]=facc_car[0]=0;
     qainjure=qadeath=qacripple=0;
     qbinjure=qbdeath=qbcripple=0;
     qcinjure=qcdeath=qccripple=0;
     qtot=0;
     nassured[0]=flimit[0]=ibrand[0]=itag[0]=iengine[0]=ibody[0]=fstl[0]=0;
     istl_note[0]=0;
     qtot2=iclose_type=0;
     ipayment[0]=0;
     mpayment=0;
     qcount=0;
     iins_type[0]=0;
     mins_audit=mins_stl=mins_dedu=mins_proc=mins_salv=mins_app=0;
     qcount1=qcount2=0;
     yy[0]=0;

     cm_buf_get("%s",DBName);
     cm_buf_get("%s %s",ipolicy,sUserid );

     if(db_select(DBName) == False)
         return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     if ((rtncode = split_policy(ipolicy, sIpolicy1, sIpolicy2)) != M_CM_OK)
         return exitsub(reply, M_CA_NLENGTH) ? M_CA_NLENGTH : apiRC;

     printf("split ipolicy------>[%s]\n",sIpolicy1);

     rtncode = cm_get_unit_in(sIpolicy1, DBName, " "," " ,"C3",unit, " ");
     if(rtncode != M_CM_OK)
     {
        if (rtncode == 100 )
            return exitsub(reply,M_CA_NPOLICY) ? M_CA_NPOLICY : apiRC;
        else
            return exitsub(reply, rtncode) ? rtncode : apiRC;
     }

     /*strncpy(unit,ipolicy,2); */
     unit[2]='\0';
     strcpy(sFullName, get_full_dbname(unit));
     printf("sF[%s][%s]\n", sFullName, unit);

     /*ADD cripple FOR IPIS */
     EXEC SQL WHENEVER SQLERROR GOTO errexit;
     sprintf(stmt, "SELECT iclaim,icard,dclaim,daccident,iacc_area, \
                           iacc_reason,DECODE(fdmg_duty,'1',fdmg_duty,facc_duty),fpart, iadjuster, irelative_clm, \
                           frecover, nacc_driver,iacc_license, facc_sex, \
                           to_char(dacc_birth,'%%Y')::integer-1911 || to_char(dacc_birth,'%%m%%d'), \
                           facc_marri,facc_rel ,facc_nation, facc_car, \
                           qacar_injure,qbcar_injure,qccar_injure, \
                           qacar_death,qbcar_death,qccar_death , \
                           qacar_cripple,qbcar_cripple,qccar_cripple \
                      FROM %s:appraisal \
                     WHERE ipolicy='%s' \
                     ORDER BY dclaim", sFullName, ipolicy);
     EXEC SQL PREPARE mqe_1 FROM :stmt;
     EXEC SQL DECLARE cur3 CURSOR FOR mqe_1;
     EXEC SQL OPEN cur3;
     qtot=0;
     for(;;)
     {
         EXEC SQL FETCH cur3 INTO $iclaim,$icard,$dclaim,$daccident,$iacc_area,
                                  $iacc_reason,$facc_duty, $fpart, $iadjuster,$irelative_clm,
                                  $frecover_1,$nacc_driver,$iacc_license,$facc_sex,$iacc_birth,
                                  $facc_marri,$facc_rel ,$facc_nation ,$facc_car,
                                  $qainjure,$qbinjure,$qcinjure,
                                  $qadeath,$qbdeath,$qcdeath,
                                  $qacripple,$qbcripple,$qccripple;
         if(SQLCODE==SQLNOTFOUND) break;
         /*����l�v�O���*/
         sprintf(stmt_1, "SELECT NVL(MAX(frecover), '#') \
                            FROM %s:recovery \
                           WHERE iclaim='%s'", sFullName, iclaim);
         $PREPARE mqe_1_1 FROM $stmt_1;
         $DECLARE cur3_1 CURSOR FOR mqe_1_1;
         $OPEN cur3_1;
         $FETCH cur3_1 INTO $frecover;
             /* SQLNOTFOUND */
             if(frecover[0]=='#') strcpy(frecover,frecover_1);
         $CLOSE cur3_1;
         $FREE  cur3_1;
         qtot++;  /* �X�I���� */
     }
     EXEC SQL CLOSE cur3;
     EXEC SQL FREE  cur3;
     printf("�X�I����:qtot=[%d]\n",qtot);

     if(qtot==0)
         return exitsub(reply,M_CA_NAPPRAISAL_REC) ? M_CA_NAPPRAISAL_REC : apiRC;

     $SELECT nname
        INTO $iadjuster_name
        FROM officer
       WHERE iofficer = $iadjuster;

     strcpy(s_dclaim,cm_sysd_cdatetime_100(dclaim));
     strcpy(s_daccident,cm_sysd_cdatetime_100(daccident));
     cm_buf_init(ReplyBuf);
     cm_buf_res_msg();
     cm_buf_res_count();
     cm_buf_res_count();
     cm_buf_put_msg(M_CM_OK);
     /* ADD qcripple FOR IPIS */
     cm_buf_put("%l %s %s %s %s %s %s %c  %c %s %s %s %c %s %s %s  %c %c  %c %c %c",
                 qtot,iclaim,icard,s_dclaim,s_daccident,iacc_area,iacc_reason,facc_duty[0],
                 fpart[0],iadjuster,iadjuster_name,irelative_clm,frecover[0],nacc_driver,
                 iacc_license,iacc_birth ,
                 facc_sex[0],facc_marri[0], facc_rel[0],facc_nation[0], facc_car[0]);

     cm_buf_put ("%l %l %l %l %l %l %l %l %l ",
                 qainjure,qadeath,qacripple,
                 qbinjure,qbdeath,qbcripple,
                 qcinjure,qcdeath,qccripple );

     printf("iclaim1=[%s]\n",iclaim);
     sprintf(stmt, "SELECT nassured,flimit,ibrand,itag,iengine,ibody,iassured \
                      FROM %s:adjustment_ply \
                     WHERE iclaim='%s'", sFullName, iclaim);
     printf("stmt=[%s]\n",stmt);

     EXEC SQL PREPARE mqe_2 FROM :stmt;
     EXEC SQL DECLARE mqe_2_cursor CURSOR FOR mqe_2;
     EXEC SQL OPEN    mqe_2_cursor;
     EXEC SQL FETCH mqe_2_cursor INTO :nassured , :flimit , :ibrand , :itag , :iengine , :ibody, :iassured;
     fFound = (SQLCODE == SQLNOTFOUND) ? 0 : 1;
     EXEC SQL CLOSE mqe_2_cursor;
     EXEC SQL FREE  mqe_2_cursor;
     if(!fFound)
        return exitsub(reply,M_CA_NAPPRAISAL_REC) ? M_CA_NAPPRAISAL_REC : apiRC;

     /* �Ӹ갱���ˮ� add by sylvia 103.02.17 (1020924002_C2) */
        strcpy(o_sDeny_msg," ");
        iCountDeny=0;
        iCountFunsale=0;
         $select count(*),funrenew_ins[1,1],funquery_ins[1,1],fdelete_ins[1,1]
            into $iCountDeny,$funrenew,$funquery,$fundelete
            from cm_personal_deny
           where iassured = $iassured
             and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
             and ddeny <= today
             and (dexpire is null or dexpire >= today)
             GROUP BY 2,3,4;
             
             rtncode = cm_chk_personal(iassured, 'C' , '*' , o_sDeny_msg, o_sFply_chk);
             
        if(iCountDeny > 0)
        {
            iUnDeny=0;
            /*�bcu_code_data.itype=CK ���]�w��,�i�H�d��*/ 
            $select count(*) into $iUnDeny
               from cu_code_data where itype = 'CK' and icode = $sUserid;
            if (iUnDeny == 0)
         	{
	         	if (strcmp(trim(funrenew),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_RENEW) ? M_CA_PERSONAL_DENY_RENEW :apiRC;
	            else if (strcmp(trim(funquery),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_QUERY) ? M_CA_PERSONAL_DENY_QUERY :apiRC;
	            else if (strcmp(trim(fundelete),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_DELETE) ? M_CA_PERSONAL_DENY_DELETE :apiRC;
	            else 
	            	return exitsub(reply,M_CA_PERSONAL_DENY) ? M_CA_PERSONAL_DENY :apiRC;
         	}
            else
	    		rtncode = cm_chk_personal(iassured, 'C' , '*' , o_sDeny_msg, o_sFply_chk);
        }

     /* DELETE flimit, frescue, fno_mdeduct FOR ISPS */
     cm_buf_put("%s %s %s", nassured, ibrand, itag);
     cm_buf_put("%s %s ", iengine, ibody);

     sprintf(stmt, "SELECT iclaim, fstl ,iclose_type, fcard_class,dclose,istl_note \
                      FROM %s:settlement \
                     WHERE iclaim = '%s' \
                     ORDER BY fstl ,iclose_type", sFullName, iclaim);
     EXEC SQL PREPARE mqe_3 FROM :stmt;
     EXEC SQL DECLARE q_cur8 CURSOR FOR mqe_3;
     EXEC SQL OPEN q_cur8;
     qtot2=0;
     for(;;)
     {
        EXEC SQL FETCH q_cur8 INTO $iclaim,$fstl,$iclose_type,$fcard_class,
                                   $stl_edclose, $istl_note;
        if (SQLCODE==SQLNOTFOUND) break;
        qtot2++;
     }
     EXEC SQL CLOSE q_cur8;
     EXEC SQL FREE  q_cur8;
     printf("clm[%s] �p��ѵ���:qtot2=[%d]\n",iclaim,qtot2);

     if (qtot2 > 0)  /* break out, at least one record is selected */
     {
         strcpy (stl_cdclose, cm_cdate_str_100(stl_edclose));
         cm_buf_put("%l %s  %l %s %s",
                     qtot2,iclaim, iclose_type,stl_cdclose,istl_note);
     }
     else  /* break out, not any row is found */
     {
         strcpy (stl_cdclose, cm_cdate_str_100(stl_edclose));
         cm_buf_put("%l %s  %l %s %s",
                    qtot2,iclaim,  iclose_type,stl_cdclose,istl_note);
         cm_buf_put_count_seq(2,0);
     }

    sprintf(stmt, "SELECT ipayment,mpayment,ifpce_id_ext, \
                          nchi_full[1,40],xibank,xiaccount,pay_kind, \
                          xfpay_cond,ipay_area ,npayment \
                     FROM %s:payment \
                    WHERE iclaim ='%s' \
                      AND fstl ='%s' \
                      AND iclose_type= %d "
                      ,sFullName,iclaim,fstl,iclose_type);
    EXEC SQL PREPARE mqe_4 FROM :stmt;
    EXEC SQL DECLARE q_cur9 CURSOR FOR mqe_4;
    EXEC SQL OPEN q_cur9;
    qcount1=0;
    for(;;)
    {
       EXEC SQL FETCH q_cur9 INTO :ipayment,:mpayment, :ifpce_id_ext, :nchi_full,
                                  :xibank, :xiaccount, :pay_kind,
                                  :xfpay_cond, :ipay_area,:npayment;
        if (SQLCODE==SQLNOTFOUND) break;

        printf("ipayment[%s]\n",ipayment);
        printf("mpayment[%l]\n",mpayment);
        printf("ifpce_id_ext[%s]\n",ifpce_id_ext);
        printf("nchi_full[%s]\n",nchi_full);
        printf("xibank[%s]\n",xibank);
        printf("xiaccount[%s]\n",xiaccount);
        printf("pay_kind[%s]\n",pay_kind);
        printf("xfpay_cond[%s]\n",xfpay_cond);
        printf("ipay_area[%s]\n",ipay_area);

        kind=atoi(pay_kind);

        switch(kind)
        {
         case 1:
               strcpy(pay_kind,"���l");
               printf("pay_kind[%s]\n",pay_kind);
               break;
         case 2:
               strcpy(pay_kind,"�ѵs");
               printf("pay_kind[%s]\n",pay_kind);
               break;
         case 3:
               strcpy(pay_kind,"�N�~");
               printf("pay_kind[%s]\n",pay_kind);
               break;
         case 4:
               strcpy(pay_kind,"�O��");
               printf("pay_kind[%s]\n",pay_kind);
               break;
         case 5:
               strcpy(pay_kind,"�ˤ`");
               printf("pay_kind[%s]\n",pay_kind);
               break;
         case 6:
               strcpy(pay_kind,"�N�B���O��");
               printf("pay_kind[%s]\n",pay_kind);
               break;
         }

    if (strlen(trim(ipay_area))==0)
        strcpy(clm_pay_area, sFullName);
    else
        strcpy(clm_pay_area, get_full_dbname(ipay_area));
    printf("sF[%s][%s]\n", clm_pay_area, ipay_area);

     strcpy(strIclose_type, itoa(iclose_type));

     sprintf(stmt,
           " SELECT dpay \
               FROM %s:ao_stl_obj_close \
              WHERE iclose='%s' \
                AND fstl='%s' \
                AND iclose_type='%s' \
                AND istl_obj='%s' \
                AND istl_obj_ext ='%s'"
                   ,clm_pay_area,iclaim,fstl,strIclose_type,ipayment,ifpce_id_ext);

     EXEC SQL PREPARE mqe_6 FROM :stmt;
     EXEC SQL DECLARE q_cur10 CURSOR FOR mqe_6;
     EXEC SQL OPEN q_cur10;
     EXEC SQL FETCH q_cur10 INTO :dpay:dpay_chk ;
     printf("stmt[%s]\n",stmt);
     if (SQLCODE == SQLNOTFOUND)
        dpay_c[0] = '\0';
     else
     {
        if (dpay_chk == -1)
            dpay_c[0] = '\0';
        else
            strcpy(dpay_c,cm_cdate_str_100(dpay));
     }

     EXEC SQL CLOSE q_cur10;
     EXEC SQL FREE  q_cur10;

     printf("dpay_c[%s]\n",dpay_c);

/*        EXEC SQL SELECT tstl_remark
                   INTO :tstl_remark
                   FROM cu_stl_obj
                  WHERE ifpce_id = :ipayment
                    AND ifpce_id_ext = :ifpce_id_ext
                    AND NVL(tstl_remark,' ') != ' ' ;
        printf("tstl_remark[%s]\n",tstl_remark);
        if (SQLCODE==SQLNOTFOUND)
        {
            strcpy(tstl_remark,nchi_full);

        }                                            */


        if (strcmp( xfpay_cond , "3")==0)
        {
            EXEC SQL SELECT nchi_abv
                       INTO :nchi_abv
                       FROM bf_bank
                      WHERE ibank=:xibank ;
             printf("nchi_abv[%s]\n",nchi_abv);
        }
        else
        {
                nchi_abv[0] = '\0';
                xiaccount[0] = '\0';
        }

        cm_buf_put("%s %s %l %s %s %s %s %s",ipayment,nchi_full,mpayment,pay_kind,npayment,nchi_abv,xiaccount,dpay_c);
        qcount1++;
    }
    EXEC SQL CLOSE q_cur9;
    EXEC SQL FREE q_cur9;

     if (qcount1 > 0)   /* break out, at least one record is selected */
        cm_buf_put_count_seq(1,qcount1);

     if (fcard_class[0]=='2' )
     {
         sprintf(stmt,
           "SELECT iins_type, fstl , mins_dedu, mins_stl, mins_proc, \
                   flast ,dclose ,dgroup \
              FROM %s:stl_ins_type \
             WHERE iclaim ='%s'  AND fstl = '%s' AND iclose_type=%d ",
                 sFullName, iclaim, fstl ,iclose_type);
         EXEC SQL PREPARE mqe_5 FROM :stmt;
         EXEC SQL DECLARE q_cur0 CURSOR FOR mqe_5;
         EXEC SQL OPEN q_cur0;
         qcount2=0;
         for(;;)
         {
             mins_stl=mins_dedu=mins_proc=0;
             EXEC SQL FETCH q_cur0 INTO :iins_type, :fstl , :mins_dedu, :mins_stl,
                                        :mins_proc, :flast, :edclose  , :edgroup;
             if (SQLCODE==SQLNOTFOUND) break;

             strcpy (cdclose , cm_cdate_str_100(edclose));
             strcpy (cdgroup , cm_cdate_str_100(edgroup));

             flag[0]=='2';
             cm_buf_put ("%s %s %s  %l %l %l  %s %s %s %s ",
                         iins_type ,fstl ,"2" , mins_dedu,mins_stl,mins_proc,
                         " ",flast,cdclose,cdgroup);
             qcount2++;
         } /* for loop */
         EXEC SQL CLOSE q_cur0;
         EXEC SQL FREE  q_cur0;
         printf("stl_ins_type[%d]\n",qcount2);
     }

     if (fcard_class[0]=='1')
     {
         printf("fcard_class =1 a \n");
         sprintf (stmt, " SELECT iins_item, fstl ,ivictim ,mins_stl , \
                                 mins_proc,flast,mstl_health,dclose,dgroup \
                            FROM %s:ca_stl_victim \
                           WHERE iclaim ='%s'  AND fstl = '%s' \
                             AND iclose_type = %d", sFullName ,iclaim ,fstl ,iclose_type );
         EXEC SQL PREPARE mqe_51 FROM :stmt;
         EXEC SQL DECLARE q_cur01 CURSOR FOR mqe_51;
         EXEC SQL OPEN q_cur01;
         qcount2=0;
         for(;;)
         {
               printf ("fcard_class 2\n");
               mins_stl=mins_dedu=mins_proc=mstl_health=0;

               EXEC SQL FETCH q_cur01 INTO :iins_type, :fstl , :ivictim     , :mins_stl ,
                                           :mins_proc, :flast, :mstl_health , :edclose  , :edgroup;

               if (SQLCODE==SQLNOTFOUND) break;

               strcpy (cdclose , cm_cdate_str_100(edclose));
               strcpy (cdgroup , cm_cdate_str_100(edgroup));
               strcpy (flast_tmp,flast);
               if (flast_tmp[0] == '2')
                  strcpy(flast_tmp,"1");
               cm_buf_put ("%s %s %s %s %l %l %l %s %s %s ",
                           iins_type , fstl , "1" , ivictim , mins_stl , mins_proc ,
                           mstl_health , flast_tmp , cdclose , cdgroup);
               qcount2++;
         } /* for loop */
         EXEC SQL CLOSE q_cur01;
         EXEC SQL FREE  q_cur01;
     }
     /*�Ӹ�P�_*/
     cm_buf_put("%s",o_sDeny_msg);
     cm_buf_put("%s",iassured);

     if (qcount2 > 0)
     { /* break out, at least one record is selected */
        cm_buf_put_count_seq(2,qcount2);
        tmp_len = cm_buf_len(ReplyBuf);
        if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
          return apiRC;
        return api_OKComplete;
     }
     else
     {
        cm_buf_put_count_seq(2,qcount2);
        tmp_len = cm_buf_len(ReplyBuf);
        if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
          return apiRC;
        return api_OKComplete;
     }

errexit:
  printf("stmt=[%s]\n",stmt);
  printf("SOLERR:%s\n",sqlca.sqlerrm);
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*********************************************************************/
/* NEED MODIFY FOR facc_duty, qcripple, facc_rel, nacc_driver,       */
/* facc_nation, iacc_birth                                           */
/* change iclose_type's datatype from char to int                    */
/*********************************************************************/
/***** ���p�߮� *****/
long car1001_multiple_queryf(reply)
serverReply reply;
{
     /* standard defined host variables */
     $char DBName[5], sFullName[20], stmt[1024], stmt_1[1024];
     /* end of standard host var */

     /* table appraisal */
     $char ipolicy[POLICY_NUM_1],iclaim[CLAIM_NUM],icard[CARD_NUM],dclaim[21],daccident[21];
     $char iacc_reason[3],fpart[2],iadjuster[11],iadjuster_name[11],irelative_clm[CLAIM_NUM],frecover[2],frecover_1[2],iacc_license[11];
     char s_dclaim[21],s_daccident[21];
     $char iacc_birth[8],facc_sex[2],facc_marri[2],facc_duty[2],facc_rel[2];
     $char facc_nation[2],facc_car[2],iacc_area[3],nacc_driver[19];
     $short qainjure,qadeath,qacripple;
     $short qbinjure,qbdeath,qbcripple;
     $short qcinjure,qcdeath,qccripple;
     int qtot, fFound;
     /* end of appraisal */

     /* table adjustment_ply */
     $char nassured[41],flimit[2],ibrand[9],itag[CA_TAG_NUM],iengine[21],ibody[21];
     /* end of adjustment_ply */

     /* table settlement */
     $char iclose[15],s_dpay[9],istl_note[4],fstl[2];
     $char stl_cdclose[11],fcard_class[2];
     $long   stl_edclose;
     $int  iclose_type,iclose_type_inx2;
     int qtot2;
     /* end of settlement */

     /* table payment */
     $char ipayment[13],npayment[101];
     $long mpayment;
     int qcount;
     /* end of payment */

     /* table stl_victim_m */
     $char  ivictim[11],tag_fstl[2];
     $long mstl_health;

     /* table stl_ins_type */
     $char iins_type[INSURANCE_TYPE],flast[2];
     $char flast_tmp[2];
     $char cdclose[11];
     $char cdgroup[11];
     $long edclose,edgroup;
     $long mins_audit,mins_dedu,mins_stl,mins_proc,mins_salv;
     int qcount1,qcount2;
     /* end of stl_ins_type */

     /* table app_ins_type */
     $long mins_app;
     /* end of app_ins_type */

     /* standard defined data */
     char tmpbuf[4000];
     int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
     int i,total_count=0;
     /* end of standard data */

     /* self defined data */
     long iindex,iindex2;
     $int id1;
     /* end of self data */

     int kind;
     $char ifpce_id_ext[3],nchi_full[41],xibank[8],xiaccount[15],pay_kind[11];
     $char xfpay_cond[2],ipay_area[3],istl_obj[13],istl_obj_ext[3];
     $long dpay;
     $int dpay_chk;
     $char dpay_c[11];
     $char ifpce_id[11],tstl_remark[60],ibank[8],nchi_abv[13];
     $char clm_pay_area[21],icur[3], iassured[13];
     char strIclose_type[6];

     ipolicy[0]=iclaim[0]=icard[0]=dclaim[0]=daccident[0]=0;
     iacc_reason[0]=fpart[0]=iadjuster[0]=irelative_clm[0]=0;
     frecover[0]=frecover_1[0]=iacc_license[0]=0;
     s_dclaim[0]=s_daccident[0]=0;
     iacc_birth[0]=facc_sex[0]=facc_marri[0]=0;
     iclose_type=iclose_type_inx2=0;
     qtot=0;
     nassured[0]=flimit[0]=ibrand[0]=itag[0]=iengine[0]=ibody[0]=0;
     iclose[0]=s_dpay[0]=istl_note[0]=fstl[0]=0;
     qtot2=0;
     ipayment[0]=0;
     mpayment=0;
     qcount=0;
     iins_type[0]=0;
     mins_audit=mins_dedu=mins_stl=mins_proc=mins_salv=0;
     qcount1=qcount2=0;
     mins_app=0;
     iindex=0;



     cm_buf_get("%s",DBName);

     /* iindex:�ĴX���X�I����� */
     cm_buf_get("%s %s %l %s %l",ipolicy , sUserid, &iindex , iclaim , &iindex2);

     if(db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     strncpy(DBName,ipolicy,2);
     DBName[2]='\0';
     strcpy(sFullName, get_car_full_db(ipolicy));
     $WHENEVER SQLERROR GOTO errexit;
     sprintf(stmt, "SELECT iclaim,icard,dclaim,daccident,iacc_area, \
                           iacc_reason,DECODE(fdmg_duty,'1',fdmg_duty,facc_duty),fpart, iadjuster, irelative_clm, \
                           frecover,nacc_driver,iacc_license,facc_sex, \
                           to_char(dacc_birth,'%%Y')::integer-1911 || to_char(dacc_birth,'%%m%%d'), \
                           facc_marri,facc_rel ,facc_nation, facc_car, \
                           qacar_injure,qbcar_injure,qccar_injure, \
                           qacar_death,qbcar_death,qccar_death , \
                           qacar_cripple,qbcar_cripple,qccar_cripple \
                      FROM %s:appraisal \
                     WHERE ipolicy='%s' \
                     ORDER BY dclaim", sFullName, ipolicy);

     $PREPARE mqf_1 FROM $stmt;
     $DECLARE cur5 CURSOR FOR mqf_1;
     $OPEN cur5;
     qtot=0;
     for(;;)
     {
       $FETCH cur5 INTO $iclaim,$icard,$dclaim,$daccident,$iacc_area,
                        $iacc_reason,$facc_duty, $fpart, $iadjuster,$irelative_clm,
                        $frecover_1,$nacc_driver,$iacc_license,$facc_sex,$iacc_birth,
                        $facc_marri,$facc_rel ,$facc_nation ,$facc_car,
                        $qainjure,$qbinjure,$qcinjure,
                        $qadeath,$qbdeath,$qcdeath,
                        $qacripple,$qbcripple,$qccripple;
       if(SQLCODE==SQLNOTFOUND) break;
       /*����l�v�O���*/
       sprintf(stmt_1, "SELECT NVL(MAX(frecover), '#') \
                          FROM %s:recovery \
                         WHERE iclaim='%s'", sFullName, iclaim);
       $PREPARE mqf_1_1 FROM $stmt_1;
       $DECLARE cur5_1 CURSOR FOR mqf_1_1;
       $OPEN cur5_1;
       $FETCH cur5_1 INTO $frecover;
           /* SQLNOTFOUND */
           if(frecover[0]=='#') strcpy(frecover,frecover_1);
       $CLOSE cur5_1;
       $FREE  cur5_1;
       qtot++;
       if(qtot==iindex) break;
     }
     $CLOSE cur5;
     $FREE  cur5;

     if(qtot!=iindex)
       return exitsub(reply,M_CA_NAPPRAISAL_REC) ? M_CA_NAPPRAISAL_REC : apiRC;

     $SELECT nname
        INTO $iadjuster_name
        FROM officer
       WHERE iofficer = $iadjuster;

     strcpy(s_dclaim,cm_sysd_cdatetime_100(dclaim));
     strcpy(s_daccident,cm_sysd_cdatetime_100(daccident));
     cm_buf_init(ReplyBuf);
     cm_buf_res_msg();
     cm_buf_res_count();
     cm_buf_res_count();
     cm_buf_put_msg(M_CM_OK);

     cm_buf_put("%l %s %s %s %s %s %s %c   %c %s %s %s %c %s %s %s    %c %c  %c %c %c",
                 qtot,iclaim,icard,s_dclaim,s_daccident,
                 iacc_area,iacc_reason,facc_duty[0],
                 fpart[0],iadjuster,iadjuster_name,irelative_clm,frecover[0],
                 nacc_driver, iacc_license,iacc_birth ,
                 facc_sex[0],facc_marri[0],facc_rel[0],facc_nation[0],facc_car[0]);

     cm_buf_put ("%l %l %l %l %l %l %l %l %l ",
                 qainjure,qadeath,qacripple,
                 qbinjure,qbdeath,qbcripple,
                 qcinjure,qcdeath,qccripple );

     sprintf(stmt,
       "SELECT nassured,flimit,ibrand,itag,iengine,ibody, iassured \
          FROM %s:adjustment_ply \
         WHERE iclaim='%s' ",
             sFullName, iclaim);
     $PREPARE mqf_2 FROM $stmt;
     $DECLARE mqf_2_cursor CURSOR FOR mqf_2;
     $OPEN mqf_2_cursor;
     $FETCH mqf_2_cursor INTO $nassured,$flimit,$ibrand,$itag,$iengine,$ibody, $iassured;
     fFound = (SQLCODE == SQLNOTFOUND) ? 0 : 1;
     $CLOSE mqf_2_cursor;
     $FREE  mqf_2_cursor;
     if(!fFound)
        return exitsub(reply,M_CA_NAPPRAISAL_REC) ? M_CA_NAPPRAISAL_REC : apiRC;

     /* �Ӹ갱���ˮ� add by sylvia 103.02.17 (1020924002_C2) */
        iCountDeny=0;
        iCountFunsale=0;
        $select count(*),funrenew_ins[1,1],funquery_ins[1,1],fdelete_ins[1,1]
            into $iCountDeny,$funrenew,$funquery,$fundelete
            from cm_personal_deny
           where iassured = $iassured
             and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
             and ddeny <= today
             and (dexpire is null or dexpire >= today)
             GROUP BY 2,3,4;
             
             rtncode = cm_chk_personal(iassured, 'C' , '*' , o_sDeny_msg, o_sFply_chk);
             
        if(iCountDeny > 0)
        {
            iUnDeny=0;
            /*�bcu_code_data.itype=CK ���]�w��,�i�H�d��*/ 
            $select count(*) into $iUnDeny
               from cu_code_data where itype = 'CK' and icode = $sUserid;
            if (iUnDeny == 0)
         	{
	         	if (strcmp(trim(funrenew),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_RENEW) ? M_CA_PERSONAL_DENY_RENEW :apiRC;
	            else if (strcmp(trim(funquery),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_QUERY) ? M_CA_PERSONAL_DENY_QUERY :apiRC;
	            else if (strcmp(trim(fundelete),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_DELETE) ? M_CA_PERSONAL_DENY_DELETE :apiRC;
	            else 
	            	return exitsub(reply,M_CA_PERSONAL_DENY) ? M_CA_PERSONAL_DENY :apiRC;
         	}
            else
	    		rtncode = cm_chk_personal(iassured, 'C' , '*' , o_sDeny_msg, o_sFply_chk);
        }

     cm_buf_put("%s %s %s %s %s",
                 nassured,ibrand,itag,iengine,ibody);

     /*----settlement----*/
     sprintf(stmt,
       "SELECT iclaim,fstl,iclose_type,fcard_class,dclose,istl_note \
          FROM %s:settlement \
         WHERE iclaim='%s' \
      ORDER BY fstl, iclose_type",
             sFullName, iclaim);
     $PREPARE mqf_3 FROM $stmt;
     $DECLARE q_curA CURSOR FOR mqf_3;
     $OPEN q_curA;
     qtot2=0;
     for(;;)
     {
        $FETCH q_curA INTO $iclose,$fstl ,$iclose_type,$fcard_class,
                           $stl_edclose,$istl_note;
        if(SQLCODE==SQLNOTFOUND) break;
        printf("�ߥI����[%s]\n",iindex2);
        qtot2++;
        if(qtot2==iindex2)
        {
           strcpy(stl_cdclose,cm_cdate_str_100(stl_edclose));
           strcpy(tag_fstl,fstl);
           printf ("stl_cdclose[%s]\n",stl_cdclose);
           cm_buf_put("%l %s  %l %s %s",
                      iindex2,iclaim,iclose_type,stl_cdclose,istl_note);
           iclose_type_inx2=iclose_type;
           printf ("fcard_class[%s]\n",fcard_class);
        }
     }
     $CLOSE q_curA;
     $FREE  q_curA;

     if (qtot2 > 0)
       {
         cm_buf_put("%l",qtot2);
         cm_buf_put("%l",iindex2);
       }
     else {
         cm_buf_put("%l %s  %l %s %s",0," ",0," "," ");
         cm_buf_put("%l",0);
         cm_buf_put("%l",0);
     }
     printf ("payment iclaim[%s] fstl[%s] iclsoetype[%d]\n",
              iclaim, tag_fstl, iclose_type);
     if (qtot2 > 0)
     {
          sprintf(stmt, "SELECT ipayment,mpayment,ifpce_id_ext, \
                          nchi_full[1,40],xibank,xiaccount,pay_kind, \
                          xfpay_cond,ipay_area ,npayment \
                     FROM %s:payment \
                    WHERE iclaim ='%s' \
                      AND fstl ='%s' \
                      AND iclose_type= %d "
                    ,sFullName, iclaim, tag_fstl, iclose_type_inx2);
          $PREPARE mqf_4 FROM $stmt;
          $DECLARE q_cur11 CURSOR FOR mqf_4;
          $OPEN q_cur11;
          qcount1=0;
          for(;;)
          {
             $FETCH q_cur11 INTO $ipayment,$mpayment,$ifpce_id_ext,$nchi_full,
                                 $xibank,$xiaccount,$pay_kind,
                                 $xfpay_cond,$ipay_area,$npayment;
             if (SQLCODE==SQLNOTFOUND) break;
        printf("ipayment[%s]\n",ipayment);
        printf("mpayment[%l]\n",mpayment);
        printf("ifpce_id_ext[%s]\n",ifpce_id_ext);
        printf("nchi_full[%s]\n",nchi_full);
        printf("xibank[%s]\n",xibank);
        printf("xiaccount[%s]\n",xiaccount);
        printf("pay_kind[%s]\n",pay_kind);
        printf("xfpay_cond[%s]\n",xfpay_cond);
        printf("ipay_area[%s]\n",ipay_area);

        kind=atoi(pay_kind);

        switch(kind)
        {
         case 1:
               strcpy(pay_kind,"���l");
               printf("pay_kind[%s]\n",pay_kind);
               break;
         case 2:
               strcpy(pay_kind,"�ѵs");
               printf("pay_kind[%s]\n",pay_kind);
               break;
         case 3:
               strcpy(pay_kind,"�N�~");
               printf("pay_kind[%s]\n",pay_kind);
               break;
         case 4:
               strcpy(pay_kind,"�O��");
               printf("pay_kind[%s]\n",pay_kind);
               break;
         case 5:
               strcpy(pay_kind,"�ˤ`");
               printf("pay_kind[%s]\n",pay_kind);
               break;
         }

    if (strlen(trim(ipay_area))==0)
        strcpy(clm_pay_area, sFullName);
    else
        strcpy(clm_pay_area, get_full_dbname(ipay_area));
    printf("sF[%s][%s]\n", clm_pay_area, ipay_area);

     /*strcpy(strIclose_type, itoa(iclose_type));*/
     strcpy(strIclose_type, itoa(iclose_type_inx2));
     sprintf(stmt,
           " SELECT dpay \
               FROM %s:ao_stl_obj_close \
              WHERE iclose='%s' \
                AND fstl='%s' \
                AND iclose_type='%s' \
                AND istl_obj='%s' \
                AND istl_obj_ext ='%s'"
                   ,clm_pay_area,iclaim,tag_fstl,strIclose_type,ipayment,ifpce_id_ext);

     EXEC SQL PREPARE mqe_6 FROM :stmt;
     EXEC SQL DECLARE q_cur16 CURSOR FOR mqe_6;
     EXEC SQL OPEN q_cur16;
     EXEC SQL FETCH q_cur16 INTO :dpay:dpay_chk ;
     printf("stmt[%s]\n",stmt);
     if (SQLCODE == SQLNOTFOUND)
        dpay_c[0] = '\0';
     else
     {
        if (dpay_chk == -1)
            dpay_c[0] = '\0';
        else
            strcpy(dpay_c,cm_cdate_str_100(dpay));
     }

     EXEC SQL CLOSE q_cur16;
     EXEC SQL FREE  q_cur16;

     printf("dpay_c[%s]\n",dpay_c);

  /*      EXEC SQL SELECT tstl_remark
                   INTO :tstl_remark
                   FROM cu_stl_obj
                  WHERE ifpce_id = :ipayment
                    AND ifpce_id_ext = :ifpce_id_ext
                    AND NVL(tstl_remark,' ') != ' ';
        printf("tstl_remark[%s]\n",tstl_remark);

        if (SQLCODE==SQLNOTFOUND)
        {

            strcpy(tstl_remark,nchi_full);
            printf("tstl_remark[%s]\n",tstl_remark);

        }                           */


        if (strcmp( xfpay_cond , "3")==0)
        {
            EXEC SQL SELECT nchi_abv
                       INTO :nchi_abv
                       FROM bf_bank
                      WHERE ibank=:xibank ;
             printf("nchi_abv[%s]\n",nchi_abv);
        }
        else
        {
                nchi_abv[0] = '\0';
                xiaccount[0] = '\0';
        }

            cm_buf_put("%s %s %l %s %s %s %s %s",ipayment,nchi_full,mpayment,pay_kind,npayment,nchi_abv,xiaccount,dpay_c);
             qcount1++;
          }

          $CLOSE q_cur11;
          $FREE  q_cur11;
          if (qcount1 > 0)   /* break out, at least one record is selected */
             cm_buf_put_count_seq(1,qcount1);

          printf("iclose_type_inx2[%d]\n",iclose_type_inx2);
     }

     if (fcard_class[0]=='2')
     {
         printf("iclose_type_inx2_stlinstype[%d]\n",iclose_type_inx2);
         sprintf(stmt,
           "SELECT iins_type, fstl, mins_dedu, mins_stl, mins_proc, \
                   flast,dclose,dgroup \
              FROM %s:stl_ins_type \
             WHERE iclaim ='%s' AND fstl ='%s' AND iclose_type=%d ",
                 sFullName, iclaim, tag_fstl ,iclose_type_inx2);
         $PREPARE mqf_5 FROM $stmt;
         $DECLARE q_cur21 CURSOR FOR mqf_5;
         $OPEN q_cur21;
         qcount2=0;
         for(;;)
         {
            mins_stl=mins_dedu=mins_proc=0;
            $FETCH q_cur21 INTO $iins_type, $fstl ,$mins_dedu, $mins_stl,
                                $mins_proc, $flast, $edclose,$edgroup;
            if (SQLCODE==SQLNOTFOUND) break;
            strcpy (cdclose,cm_cdate_str_100(edclose));
            strcpy (cdgroup,cm_cdate_str_100(edgroup));
            cm_buf_put("%s %s %s %l %l %l %s %s  %s %s",
                        iins_type,fstl,"2",mins_dedu,
                        mins_stl,mins_proc," " ,flast,cdclose,cdgroup);
              qcount2++;
         } /* for loop */
         $CLOSE q_cur21;
         $FREE  q_cur21;
     }
     if (fcard_class[0]=='1')
     {
         printf ("iclaim[%s] fstl[%s] iclose_ty[e[%d]\n", iclaim, fstl, iclose_type);
         sprintf (stmt, " SELECT iins_item, fstl ,ivictim ,mins_stl, \
                                 mins_proc,flast,mstl_health,dclose,dgroup \
                            FROM %s:ca_stl_victim \
                           WHERE iclaim ='%s' \
                             AND fstl   ='%s' \
                             AND iclose_type = %d  ",
                       sFullName ,iclaim ,tag_fstl, iclose_type_inx2 );

         $PREPARE mqf_51 FROM $stmt;
         $DECLARE qf_cur01 CURSOR FOR mqf_51;
         $OPEN qf_cur01;
         qcount2=0;
         for(;;)
         {
            mins_stl=mins_dedu=mins_proc=mstl_health=0;
            $FETCH qf_cur01 INTO $iins_type, $fstl , $ivictim ,$mins_stl ,
                                 $mins_proc, $flast, $mstl_health ,$edclose ,$edgroup;
            if (SQLCODE==SQLNOTFOUND) break;

            strcpy (cdclose , cm_cdate_str_100(edclose));
            strcpy (cdgroup , cm_cdate_str_100(edgroup));
            strcpy (flast_tmp,flast);
            if (flast_tmp[0] == '2')
               strcpy(flast_tmp,"1");
            cm_buf_put("%s %s %s %s %l %l %l %s %s %s ",
                       iins_type ,fstl ,"1" ,ivictim ,mins_stl,mins_proc,
                       mstl_health,flast_tmp,cdclose,cdgroup);
            qcount2++;
         } /* for loop */
         $CLOSE qf_cur01;
         $FREE  qf_cur01;
     }
     /*�Ӹ�P�_*/
     cm_buf_put("%s",o_sDeny_msg);
     cm_buf_put("%s",iassured);

     if (qcount2 > 0)
     { /* break out, at least one record is selected */
        cm_buf_put_count_seq(2,qcount2);
        tmp_len = cm_buf_len(ReplyBuf);
        if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
          return apiRC;
        return api_OKComplete;
     }
     else
     {
        cm_buf_put_count_seq(2,qcount2);
        tmp_len = cm_buf_len(ReplyBuf);
        if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
          return apiRC;
        return api_OKComplete;
     }

errexit:
     printf("stmt=[%s]\n",stmt);
     printf("SOLERR:%s\n",sqlca.sqlerrm);
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/************************************************************************/
/* NEED ADD ���`�̸��                                                  */
/* FORM ca1001q6                                                        */
/* �ثe���b�ϥ�                                                         */
/************************************************************************/
long car1001_multiple_queryg(reply)
serverReply reply;
{
     /* standard defined host variables */
     $char DBName[5], sFullName[20], stmt[1024], sDBSite[3];
     $char sUpCom[3];
     /* end of standard host var */

     /* table settlement */
     $char iclaim[CLAIM_NUM],iclose[CLAIM_NUM],iclose_type[3],s_dpay[10],istl_note[4];
     $long dpay;
     int qtot2, fFound;
     /* end of settlement */

     /* table payment */
     $char ipayment[13];
     $long mpayment;
     int qcount;
     /* end of payment */

     /* table stl_ins_type */
     $char iins_type[INSURANCE_TYPE],itype;
     $long mins_audit,mins_dedu,mins_stl,mins_proc,mins_salv;
     int qcount1,qcount2;
     /* end of stl_ins_type */

     /* table app_ins_type */
     $long mins_app;
     /* end of app_ins_type */

     /* standard defined data */
     char tmpbuf[4000];
     int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
     int i,total_count=0;
     /* end of standard data */

     /* self defined data */
     long iindex;
     /* end of self data */

     iclaim[0]=iclose[0]=iclose_type[0]=s_dpay[0]=istl_note[0]=0;
     dpay=0;
     qtot2=0;
     ipayment[0]=0;
     mpayment=0;
     qcount=0;
     iins_type[0]=itype=0;
     mins_audit=mins_dedu=mins_stl=mins_proc=mins_salv=0;
     qcount1=qcount2=0;
     mins_app=0;
     iindex=0;

     cm_buf_get("%s",DBName);
     cm_buf_get("%s %s %l",iclaim, sUserid, &iindex);

     if(db_select(DBName) == False)
         return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     EXEC SQL WHENEVER SQLERROR GOTO errexit;
     strncpy(sDBSite, iclaim, 2);
     sDBSite[2] = '\0';

     $SELECT iup_branch
        INTO $sUpCom
        FROM claim_branch
       WHERE iclaim_branch = $sDBSite;

     if(SQLCODE == SQLNOTFOUND)
       return exitsub(reply,M_CMN_NBRANCH) ? M_CMN_NBRANCH : apiRC;

     strcpy(sFullName, get_full_dbname(sUpCom));
     sprintf(stmt,
       "SELECT iclose,iclose_type,dpay,istl_note \
          FROM %s:settlement \
         WHERE iclaim='%s' \
      ORDER BY dpay", sFullName, iclaim);

     $PREPARE mqg_1 FROM $stmt;
     $DECLARE q_curB CURSOR FOR mqg_1;
     $OPEN q_curB;
     qtot2=0;
     for(;;){
        $FETCH q_curB INTO $iclose,$iclose_type,$dpay,$istl_note;
        if (SQLCODE==SQLNOTFOUND) break;
        qtot2++;
        if (qtot2==iindex) break;
      } /* for loop */

     $CLOSE q_curB;
     $FREE  q_curB;
     if (qtot2 == iindex) {
        strcpy(s_dpay,cm_cdate_str_100(dpay));
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();
        cm_buf_res_count();
        cm_buf_res_count();
        cm_buf_put_msg(M_CM_OK);
        cm_buf_put("%s %s %s %s",iclose,iclose_type,s_dpay,istl_note);
      }
     else            /* break out, not any row is found */
       return exitsub(reply,M_CA_NSETTLEMENT) ? M_CA_NSETTLEMENT : apiRC;

     sprintf(stmt,
       "SELECT ipayment,mpayment \
          FROM %s:payment \
         WHERE iclaim='%s' AND iclose='%s' AND iclose_type='%s' ",
             sFullName, iclaim, iclose, iclose_type);

     $PREPARE mqg_2 FROM $stmt;
     $DECLARE q_cur12 CURSOR FOR mqg_2;
     $OPEN q_cur12;
     qcount1=0;
     for(;;)
     {
            $FETCH q_cur12 INTO $ipayment,$mpayment;
            if (SQLCODE==SQLNOTFOUND) break;
            cm_buf_put("%s %l",ipayment,mpayment);
            qcount1++;
     } /* for loop */
     $CLOSE q_cur12;
     $FREE  q_cur12;

     if (qcount1 > 0)   /* break out, at least one record is selected */
        cm_buf_put_count_seq(1,qcount1);
    /**
     else
       return exitsub(reply,M_CA_NPAYMENT) ? M_CA_NPAYMENT : apiRC;
    **/

     sprintf(stmt,
       "SELECT iins_type, mins_audit, mins_dedu, mins_stl, mins_proc, \
               mins_salv \
          FROM %s:stl_ins_type\
         WHERE iclaim ='%s' AND iclose='%s' AND iclose_type='%s' ",
               sFullName, iclaim, iclose, iclose_type);

     $PREPARE mqg_3 FROM $stmt;
     $DECLARE q_cur22 CURSOR FOR mqg_3;
     $OPEN q_cur22;
     if (iclose_type[0]=='R' || iclose_type[1]=='R' ||
         iclose_type[0]=='B' || iclose_type[1]=='B')
          itype='2';
     else itype='1';
     qcount2=0;
     for(;;)
      {
        $FETCH q_cur22 INTO $iins_type, $mins_audit, $mins_dedu, $mins_stl,
                            $mins_proc, $mins_salv;
        if (SQLCODE==SQLNOTFOUND) break;
        sprintf(stmt,
          "SELECT mins_app \
             FROM %s:app_ins_type \
            WHERE iclaim='%s' AND iins_type='%s' ",
                  sFullName, iclaim, iins_type);

        $PREPARE mqg_4 FROM $stmt;
        $DECLARE mqg_4_cursor CURSOR FOR mqg_4;
        $OPEN mqg_4_cursor;
        $FETCH mqg_4_curso INTO $iins_type, $mins_app, $mins_audit, $mins_dedu,
                                $mins_stl, $mins_proc, $mins_salv;
        fFound = (SQLCODE == SQLNOTFOUND) ? 0 : 1;
        $CLOSE mqg_4_cursor;
        $FREE  mqg_4_cursor;
        if(!fFound) continue;
        cm_buf_put("%s %c %l %l %l %l %l",
                    iins_type,itype,mins_app,mins_audit,mins_dedu,
                    mins_stl,mins_proc,mins_salv);
        qcount2++;
      } /* for loop */

     $CLOSE q_cur22;
     $FREE  q_cur22;
     if (qcount2 > 0)  { /* break out, at least one record is selected */
        cm_buf_put_count_seq(1,qcount2);
        tmp_len = cm_buf_len(ReplyBuf);
        if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
          return apiRC;
        return api_OKComplete;
     }

errexit:
  printf("stmt=[%s]\n",stmt);
  printf("SOLERR:%s\n",sqlca.sqlerrm);
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/****************<<<�X�I�J�`��Ƭd��>>>********************************/
/* NEED COMFIRM mlia_prem AND ���l�I�P���d�I���ߥI�`�B���p��          */
/* FORM ca1001q7                                                      */
/* change iclose_type's datatype from char to int                     */
/**********************************************************************/
long car1001_multiple_queryh(reply)
serverReply reply;
{    /** �X�I�J�` **/
     /* standard defined host variables */
     $char DBName[5], sFullName[20], stmt[2048];
     $char fcard_class[2];
     $char nname[11];
     /* end of standard host var */

     /* table ply_relation */
     $char irelative_ply[POLICY_NUM_1],irelative_card[CARD_NUM],icard[CARD_NUM],ipolicy[POLICY_NUM_1];
     $long mdmg_prem, mlia_prem;
     /* end of ply_relation */

     /* table policy */
     $char nassured[41],s_dply_begin[11],s_dply_end[11],ibrand[9],itag[CA_TAG_NUM],iassured[13],iacc_align[3],dclaim[30];
     $dec_t mcar_price;
     $char s_mcar_price[10];
     $char nequipment[31];
     $char s_nequipment[201] , icode_note[11] , ncode_note[41];
     $long dply_begin,dply_end;
     char s_yy1[4],s_yy2[4],s_mm1[3],s_mm2[3],s_dd1[3],s_dd2[3];
     long yy1,yy2,mm1,mm2,months;
     /* end of policy */

     /* table appraisal */
     $char iclose_ctype[3],iclose_rtype[3],iclose_last[3];
     $long dclose_ctype,dclose_rtype,dclose_last,Dpay;
     $long mdmg_stl, mapp_damage;
     char s_dclose_last[11], s_Dpay[11];
     int fFound;
     long mtot;
     int qtot,qcount;
     $char daccident[21];
     char s_daccident[21];
     $char iclaim[CLAIM_NUM],iclose[CLAIM_NUM],fclose[2];
     $long mapp_loss,msettle,mprocess,msalvage;
     $char iadjuster[11],istl_note[4];
     $long mliastl_hist,mdmgstl_hist,mstl1_hist,mstl2_hist,ii ;
     $char max_daccident[30],max_iclaim[16] ;
     $char iremark[11];
     $char facc_duty[2];    /** �P�_�O�_���F�d **/
     $char facc_duty_c[3];
     $char dapp_entry[11];
     /* end of appraisal */

     /* standard defined data */
     char tmpbuf[4000];
     int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
     int i,total_count=0;
     int j;
     /* end of standard data */

     /* table from : app_ins_type && stl_ins_type */
     $char iins_type[INSURANCE_TYPE];
     $long mins_app , mins_stl , mins_proc;
     $long dgroup;
     $char flast[2];
     $char flast_c[11], q_mins_stl[10], q_mins_proc[10];
     /* end of app_ins_type and stl_ins_type */

     /* table from : ca_app_victim && ca_stl_victim */
     $char iins_item[4] , iins_item_c[4] , ivictim[11] ;
     $long mapp_cover ;
     /* end of ca_app_victim && ca_stl_victim */

     /* adjustment_ply */
     $char q_day[3];
     $long qlia;
      int  qday2;
      char q_day2[6];
      int  rc;

     /* self defined data */
     $int id1,id2,id3,id4,id5;
     /* end of self data */

     memset(iclaim,0,CLAIM_NUM);
     memset(max_iclaim,0,16);
     irelative_ply[0] = irelative_card[0] = icard[0] = ipolicy[0] = 0;

     mdmg_prem=0;
     mlia_prem=0;

     nassured[0] = s_dply_begin[0] = s_dply_end[0] = ibrand[0] = itag[0] = 0;
     iassured[0] = iacc_align[0] = 0;
     s_mcar_price[0] = 0;
     nequipment[0] = 0;

     dply_begin = dply_end = 0;
     s_yy1[0] = s_yy2[0] = s_mm1[0] = s_mm2[0] = s_dd1[0] = s_dd2[0] = 0;
     yy1 = yy2 = mm1 = mm2 = months = 0;
     iclose_ctype[0] = iclose_rtype[0] = iclose_last[0] = s_Dpay[0] = 0;
     dclose_ctype = dclose_rtype = dclose_last = Dpay = 0;
     s_dclose_last[0] = 0;

     mdmg_stl = mapp_damage = 0;
     mtot = 0;
     qtot = qcount = 0;
     daccident[0] = 0;
     s_daccident[0] = 0;
     iclaim[0] = iclose[0] = 0;
     ii = 0 ;
     iadjuster[0] = istl_note[0] = 0;

     cm_buf_get("%s",DBName);
     cm_buf_get("%s",ipolicy);
     if(db_select(DBName) == False)
         return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     /*** ���O����ݸ�Ʈw peter ***/
     strncpy(DBName,ipolicy,2); DBName[2]='\0';
     strcpy(sFullName, get_full_dbname(DBName));

     EXEC SQL WHENEVER SQLERROR GOTO errexit;
     /*** ���l�B���d�I�O�O�ΫO�d���M���p�O�渹 peter ***/
     sprintf(stmt, "SELECT a.mdmg_prem , a.mlia_prem , a.icard , a.irelative_ply ,\
                           a.dply_begin , a.dply_end , a.ibrand , b.nassured , b.itag ,\
                           to_char(b.dissue,'%%Y')::integer - 1911 || '/' || to_char(b.dissue,'%%m'),\
                           b.nequipment , a.fcard_class, b.iassured \
                      FROM %s:ply_relation a , %s:policy b \
                     WHERE a.ipolicy = b.ipolicy \
                       AND a.ipolicy = '%s' ",
                    sFullName , sFullName , ipolicy);
     $PREPARE mqh_6 FROM $stmt;
     $DECLARE mqh_6_cursor CURSOR FOR mqh_6;
     $OPEN mqh_6_cursor;
     $FETCH mqh_6_cursor INTO $mdmg_prem , $mlia_prem , $icard , $irelative_ply ,
                              $dply_begin , $dply_end , $ibrand , $nassured , $itag ,
                              $iassured , $nequipment , $fcard_class, $iassured ;
     fFound = (SQLCODE==SQLNOTFOUND) ? 0 : 1;
     $CLOSE mqh_6_cursor;
     $FREE  mqh_6_cursor;

     if (!fFound)
        return exitsub(reply,M_CA_NREL_PLY) ? M_CA_NREL_PLY : apiRC;

     /* �Ӹ갱���ˮ� add by sylvia 103.02.17 (1020924002_C2) */
        strcpy(o_sDeny_msg," ");
        iCountDeny=0;
        iCountFunsale=0;
        $select count(*),funrenew_ins[1,1],funquery_ins[1,1],fdelete_ins[1,1]
            into $iCountDeny,$funrenew,$funquery,$fundelete
            from cm_personal_deny
           where iassured = $iassured
             and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
             and ddeny <= today
             and (dexpire is null or dexpire >= today)
             GROUP BY 2,3,4;
             
             rtncode = cm_chk_personal(iassured, 'C' , '*' , o_sDeny_msg, o_sFply_chk);
             
        if(iCountDeny > 0)
        {
            iUnDeny=0;
            /*�bcu_code_data.itype=CK ���]�w��,�i�H�d��*/ 
            $select count(*) into $iUnDeny
               from cu_code_data where itype = 'CK' and icode = $sUserid;
            if (iUnDeny == 0)
         	{
	         	if (strcmp(trim(funrenew),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_RENEW) ? M_CA_PERSONAL_DENY_RENEW :apiRC;
	            else if (strcmp(trim(funquery),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_QUERY) ? M_CA_PERSONAL_DENY_QUERY :apiRC;
	            else if (strcmp(trim(fundelete),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_DELETE) ? M_CA_PERSONAL_DENY_DELETE :apiRC;
	            else 
	            	return exitsub(reply,M_CA_PERSONAL_DENY) ? M_CA_PERSONAL_DENY :apiRC;
         	}
            else
	    		rtncode = cm_chk_personal(iassured, 'C' , '*' , o_sDeny_msg, o_sFply_chk);
        }

     cm_buf_init(ReplyBuf);
     cm_buf_res_msg();
     cm_buf_res_count();
     cm_buf_put_msg(M_CM_OK);

     /* add mlia_prem 870610 FOR ISPS */
     cm_buf_put("%s %s %l %l", icard, irelative_ply, mdmg_prem, mlia_prem);

     /*** ���p�d�� ***/
     EXEC SQL SELECT icard INTO :irelative_card
                FROM assured_vs_ply
               WHERE ipolicy = :irelative_ply;
     if (SQLCODE==SQLNOTFOUND) strcpy(irelative_card,"         ");  /* nine blank */

     cm_buf_put("%s",irelative_card);

     mtot = qtot = 0;
     mliastl_hist = mdmgstl_hist = mstl1_hist = mstl2_hist = 0;

     /*** �[�`�ӫO��Ҧ����߮ת��z����B�å[�H�Ϥ������l�Ψ��d ***/
     sprintf(stmt, "SELECT a.iclaim , \
                          (SELECT NVL(SUM(DECODE(b.fstl,'1',b.mins_stl,-b.mins_stl)),0) \
                             FROM %s:stl_ins_type b, insurance_type c \
                            WHERE b.iins_type=c.iins_type AND c.fkind IN ('1','2','4','6') \
                              AND b.iclaim=a.iclaim), DECODE(a.iclaim[6],'C', \
                          (SELECT NVL(SUM(DECODE(b.fstl,'1',(b.mins_stl+b.mstl_health),-(b.mins_stl+b.mstl_health))),0) \
                             FROM %s:ca_stl_victim b \
                            WHERE b.iclaim=a.iclaim), \
                          (SELECT NVL(SUM(DECODE(b.fstl,'1',b.mins_stl,-b.mins_stl)),0) \
                             FROM %s:stl_ins_type b, insurance_type c \
                            WHERE b.iins_type=c.iins_type AND c.fkind IN ('3','A','B','C','E','5') \
                              AND b.iclaim=a.iclaim)) \
                      FROM %s:appraisal a \
                     WHERE a.ipolicy = '%s' \
                     GROUP BY a.iclaim",
             sFullName, sFullName, sFullName, sFullName, ipolicy);
     EXEC SQL PREPARE mqh_3 FROM :stmt;
     EXEC SQL DECLARE q_curC CURSOR FOR mqh_3;
     EXEC SQL OPEN q_curC;
     for (;;)
     {
         EXEC SQL FETCH q_curC INTO :iclaim ,:mdmgstl_hist, :mliastl_hist;
         if (SQLCODE==SQLNOTFOUND) break;

         mstl1_hist += mdmgstl_hist;
         mstl2_hist += mliastl_hist;
     }
     EXEC SQL CLOSE q_curC;
     EXEC SQL FREE  q_curC;

     strcpy(s_dply_begin,cm_cdate_str_100(dply_begin));
     strcpy(s_dply_end,cm_cdate_str_100(dply_end));
     cm_split_ymd_100(s_dply_begin,s_yy1,s_mm1,s_dd1);
     cm_split_ymd_100(s_dply_end,s_yy2,s_mm2,s_dd2);
     yy1=atol(s_yy1);
     yy2=atol(s_yy2);
     mm1=atol(s_mm1);
     mm2=atol(s_mm2);
     months=(long)(yy2-yy1)*12+(mm2-mm1);

     /*** ��Ū���O���� ***/
     strcpy(equipdecode,equip_get(nequipment));
     printf("4231:equipdecode=[%s]\n",equipdecode);
     s_nequipment[0] = '\0';
     IEquip_ptr=IfirstEquip;
     while (IEquip_ptr)
     {
         strcpy(icode_note , IEquip_ptr->sequip);
         printf("4238:icode_note[%s]\n",icode_note);
         iTmpcode = atoi(icode_note);
         sprintf(icode_note,"%02d",iTmpcode);
         printf("4248:icode_note[%s]\n",icode_note);

         EXEC SQL SELECT ncode
                    INTO :ncode_note
                    FROM cu_code_data
                   WHERE itype = '25'
                     AND icode = :icode_note;
         if (SQLCODE != SQLNOTFOUND)
         {
             strcat(s_nequipment,"�i");
             strcat(s_nequipment,trim(icode_note));
             strcat(s_nequipment,":");
             strcat(s_nequipment,trim(ncode_note));
             strcat(s_nequipment,"�j");
         }
         IEquip_ptr=IEquip_ptr->next;
     }

/*********************************************************************
     j=strlen(nequipment);
     for (i=0;i<j;i++)
     {
        if (nequipment[i] == '1')
        {
            strcpy(icode_note , itoa(i+1));
            printf("icode_note[%s]\n",icode_note);
            EXEC SQL SELECT ncode
                       INTO :ncode_note
                       FROM cu_code_data
                      WHERE itype = '25'
                        AND icode = :icode_note;
            if (SQLCODE == SQLNOTFOUND)
                 strcpy(ncode_note, "");
            strcat(s_nequipment,"�i");
            strcat(s_nequipment,trim(icode_note));
            strcat(s_nequipment,":");
            strcat(s_nequipment,trim(ncode_note));
            strcat(s_nequipment,"�j");
        }
     }
**********************************************************************/
     printf("nequipment[%s],s_nequipment[%s]\n",nequipment,s_nequipment);

     /* delete 870610 FOR ISPS delete iacc_align */
     cm_buf_put("%s %l %s %s %s %s %s %s %s",
                nassured,months,s_dply_begin,s_dply_end,ibrand,
                itag,iassured,s_mcar_price,s_nequipment);

     cm_buf_put("%l %l", mstl1_hist, mstl2_hist);
     cm_buf_put("%s", fcard_class);

     /**** ca1001q8.frm �X�I�I�ة��Ӹ�� ****/
     printf("##### ca1001_queryh:Ipolicy[%s],Fcard_class[%s]\n",ipolicy,fcard_class);

     /**** �����ӫO��Ҧ��߮� from table:ca_clm_process ****/
     sprintf(stmt,"SELECT iclaim \
                     FROM ca_clm_process \
                    WHERE ipolicy = '%s' \
                    ORDER BY iclaim " , ipolicy);
     $PREPARE clm_sel FROM $stmt;
     $DECLARE clm_cur CURSOR FOR clm_sel;
     $OPEN    clm_cur;
     qcount=0;
     for(;;)
     {
          $FETCH clm_cur INTO $iclaim;
          if (SQLCODE == SQLNOTFOUND) break;
          printf("iclaim[%s]\n",iclaim );

          mapp_cover = 0;
          mins_app = 0;
          mins_stl = 0;
          mins_proc = 0;
          flast[0] = '\0';
          iins_item[0] = '\0';
          iins_type[0] = '\0';
          id1 = id2 = id3 = id4 = 0;
          flast_c[0] = '\0';

          if ((fcard_class[0] == '1') || (fcard_class[0] == '3'))  /*** �j���I ***/
          {

            sprintf(stmt, "SELECT daccident, iadjuster, DECODE(fdmg_duty,'1',fdmg_duty,facc_duty), dapp_entry \
                             FROM %s:appraisal \
                            WHERE iclaim = '%s'", sFullName , iclaim );
            $PREPARE mmn_4 FROM $stmt;
            $EXECUTE mmn_4 INTO $daccident, $iadjuster, $facc_duty, $dapp_entry;

            strcpy(s_daccident,cm_sysd_cdate_100(daccident));

            /*** �u�P�_���S�F�d ***/
            if ((facc_duty[0] == '1') || (facc_duty[0] == '3'))
                 strcpy(facc_duty_c,"��");
            else if (facc_duty[0] == '2')
                 strcpy(facc_duty_c,"�L");
            else
                 strcpy(facc_duty_c,"  ");

            $SELECT nname
               INTO $nname
               FROM officer
              WHERE iofficer = $iadjuster;

            sprintf(stmt,"SELECT ivictim , iins_item[1,1] , sum(b.mapp_cover) , max(b.dgroup1)  \
                            FROM %s:ca_app_victim b \
                           WHERE iclaim = '%s' \
                           GROUP BY 1,2 ", sFullName, iclaim);
            $PREPARE mqh_4 FROM $stmt;
            $DECLARE q_cur13 CURSOR FOR mqh_4;
            $OPEN q_cur13;
            for(;;)
            {
                 $FETCH q_cur13 INTO $ivictim , $iins_item , $mapp_cover , $dgroup;

                 if (SQLCODE==SQLNOTFOUND) break;

                 sprintf(stmt, "SELECT iclaim, sum(mins_stl), sum(mins_proc), max(flast) \
                                  FROM %s:ca_stl_victim \
                                 WHERE iclaim = '%s' AND ivictim = '%s' \
                                   AND iins_item[1,1] = '%s' AND fstl = '1' \
                                 GROUP BY 1 ",sFullName , iclaim , ivictim , iins_item);
                 $PREPARE stl_vic FROM $stmt;
                 $DECLARE stl_vic_cur CURSOR FOR stl_vic;
                 $OPEN stl_vic_cur;
                 $FETCH stl_vic_cur INTO $iclaim, $mins_stl, $mins_proc, $flast;
                 if( SQLCODE == SQLNOTFOUND )
                 {
                     strcpy( q_mins_stl, " ");
                     strcpy( q_mins_proc," ");
                 }
                 else
                 {
                     strcpy( q_mins_stl,  ltoa(mins_stl ));
                     strcpy( q_mins_proc, ltoa(mins_proc));
                 }
                 $CLOSE stl_vic_cur;
                 $FREE  stl_vic_cur;

                 if (iins_item[0] == 'A')
                     strcpy(iins_item_c,"A00");
                 else if (iins_item[0] == 'B')
                     strcpy(iins_item_c,"B00");
                 else if (iins_item[0] == 'C')
                     strcpy(iins_item_c,"C00");

                 if (flast[0] == '0')
                     strcpy(flast_c,"�D�̫�@��");
                 else if (flast[0] == '1')
                     strcpy(flast_c,"�̫�@��");
                 else if (flast[0] == '2')
                     strcpy(flast_c,"���O�l�v");
                 else
                     strcpy(flast_c," ");

                 cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s",
                             cm_sysd_cdate_100(daccident), iclaim , ivictim , iins_item_c ,
                             ltoa(mapp_cover) ,  q_mins_stl , q_mins_proc ,
                             cm_cdate_str_100(dgroup) , nname , flast_c , facc_duty_c);
                 qcount++;
              } /* for loop */
              $CLOSE q_cur13;
              $FREE  q_cur13;

              if( strcmp( trim(dapp_entry), "") == 0 )
              {

                 cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s",
                             cm_sysd_cdate_100(daccident), iclaim , " ", " ", " ",
                             " ", " ", " ", nname , " ", " ");
                 qcount++;
              }


          }
          else if (fcard_class[0] == '2')  /*** ���N�I ***/
          {
            sprintf(stmt, "SELECT daccident, iadjuster, DECODE(fdmg_duty,'1',fdmg_duty,facc_duty), dapp_entry \
                             FROM %s:appraisal \
                            WHERE iclaim = '%s'", sFullName , iclaim );
            $PREPARE mmn_5 FROM $stmt;
            $EXECUTE mmn_5 INTO $daccident, $iadjuster, $facc_duty, $dapp_entry;

            strcpy(s_daccident,cm_sysd_cdate_100(daccident));

            printf(">_< s_daccident[%s]\n",s_daccident );
            /*** �u�P�_���S�F�d ***/
            if ((facc_duty[0] == '1') || (facc_duty[0] == '3'))
                 strcpy(facc_duty_c,"��");
            else if (facc_duty[0] == '2')
                 strcpy(facc_duty_c,"�L");
            else
                 strcpy(facc_duty_c,"  ");

            $SELECT nname
               INTO $nname
               FROM officer
              WHERE iofficer = $iadjuster;

              sprintf(stmt, "SELECT iins_type , mins_app , dgroup1 \
                               FROM %s:app_ins_type  \
                              WHERE iclaim = '%s' ", sFullName, iclaim);
              $PREPARE mqh_5 FROM $stmt;
              $DECLARE q_cur14 CURSOR FOR mqh_5;
              $OPEN q_cur14;
              for(;;)
              {
                 $FETCH q_cur14 INTO $iins_type , $mins_app , $dgroup ;

                 if (SQLCODE==SQLNOTFOUND) break;

                 printf("iclaim[%s] mins_app[%d] \n",iclaim , mins_app );

                 sprintf(stmt, "SELECT iclaim, NVL(sum(mins_stl),0), NVL(sum(mins_proc),0), \
                                       NVL(max(flast),0), NVL(sum(qlia),0) \
                                  FROM %s:stl_ins_type \
                                 WHERE iclaim = '%s' AND iins_type = '%s' \
                                   AND fstl = '1' \
                                 GROUP BY 1",sFullName , iclaim , iins_type);
                 $PREPARE stl_ins FROM $stmt;
                 $DECLARE stl_ins_cur CURSOR FOR stl_ins;
                 $OPEN stl_ins_cur;
                 $FETCH stl_ins_cur INTO $iclaim, $mins_stl, $mins_proc, $flast, $qlia;
                 if( SQLCODE == SQLNOTFOUND )
                 {
                    strcpy( q_mins_stl , " ");
                    strcpy( q_mins_proc, " ");
                    strcpy( q_day, " ");
                    strcpy( q_day2," ");
                    strcpy(flast_c," ");
                 }
                 else
                 {
                    strcpy( q_mins_stl , ltoa(mins_stl));
                    strcpy( q_mins_proc, ltoa(mins_proc));
                    strcpy(iins_type, trim(iins_type));
                    switch(atoi(iins_type))
                    {
                        case  1:
                        case  5:
                        case  8:
                        case  9:
                        case 11:
                        case 14:
                        case 15:
                        case 16:
                             strcpy(q_day , itoa(qlia));
                             rc = qcount_qlia_day(ipolicy, iclaim, iins_type, &qday2 );
                             if( rc != SUCCESS )
                             {
                               SQLCODE = rc;
                               goto errexit;
                             }
                             printf("qcount_qlia [%d] \n",qday2 );
                             strcpy( q_day2, itoa(qday2));

                             break;
                        default:
                             strcpy(q_day , " ");
                             strcpy(q_day2, " ");
                             break;
                    }

                    if (flast[0] == '0')
                        strcpy(flast_c,"�D�̫�@��");
                    else if (flast[0] == '1')
                        strcpy(flast_c,"�̫�@��");
                    else
                        strcpy(flast_c," ");

                 }
                 $CLOSE stl_ins_cur;
                 $FREE  stl_ins_cur;

                 cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %s",
                             cm_sysd_cdate_100(daccident), iclaim, iins_type, ltoa(mins_app),
                             q_mins_stl, q_mins_proc, q_day, q_day2,
                             cm_cdate_str_100(dgroup) , nname , flast_c , facc_duty_c);
                 qcount++;


              } /* for loop */
              $CLOSE q_cur14;
              $FREE  q_cur14;

              if( strcmp( trim(dapp_entry), "") == 0 )
              {
                 cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %s",
                             cm_sysd_cdate_100(daccident), iclaim , " ", " ",
                             " ", " ", " "," ", " ", nname , " ", " " );
                 qcount++;
              }

          }
     }
     $CLOSE clm_cur;
     $FREE  clm_cur;
     /*�Ӹ�P�_*/
     cm_buf_put("%s",o_sDeny_msg);

     if (qcount > 0)
     {  /* break out, at least one record is selected */
        cm_buf_put_count(qcount);
        tmp_len = cm_buf_len(ReplyBuf);
        if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
          return apiRC;
        return api_OKComplete;
     }
     else            /* break out, not any row is found */
     {
        return exitsub(reply,M_CA_NAPPRAISAL_REC) ? M_CA_NAPPRAISAL_REC : apiRC;
     }
errexit:
 printf("stmt=[%s]\n",stmt);
 printf("SOLERR:%s\n",sqlca.sqlerrm);
 return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*********************************************************************/
/* NO NEED MODIFY CM_BUF_PUT JUST 'RENEW THE TABLE FILED CHANGED'    */
/*********************************************************************/
/***** �O�榬�O���p�d�� *****/
long car1001_multiple_queryi(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5], sFullName[20], stmt[1024];

 /* table policy */
 $char sDBSite[3];
 $char ipolicy[POLICY_NUM_1],s_dply_begin[10],s_dply_end[10];
 $char icard[CARD_NUM],nassured[41];
 $long dply_begin,dply_end;
 $long months;
 $int ibatch_no;
 $char batch_no[3],fcard_class[2];

 $long qtot;
 long mtot;
 /* table ply_relation */
 $char irelative_ply[POLICY_NUM_1],iofficer[EMPLOYEE_ID];
 $char ibroker[BROKER],iarea[AREA_NUM];
 $char s_dpolicy[10], iassured[13];
 $long dpolicy,mdmg_commi,mlia_commi,mdmg_prem,mlia_prem;
 $long chk_date, dpolicy_chk;
 $double pdiscount;
 $int mdiscount;
 $long total_prem;

 /*** AOI ***/
 char ao_policy1[CAR_POLICY_LEN+1],ao_policy2[CAR_TARGET_LEN+1];

 /* standard defined data */
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0, fFound,rc=0;

 /* self defined data */
 char s_yy1[4],s_yy2[4],s_mm1[3],s_mm2[3],s_dd1[3],s_dd2[3];
 long yy1,yy2,mm1,mm2;
 char result[3];
 char desc[35],paydate[11],duedate[11];
 /* end of self data */

 ipolicy[0]=s_dply_begin[0]=s_dply_end[0]=icard[0]=nassured[0]=0;
 dply_begin=dply_end=0;
 months=ibatch_no=0;
 qtot=mtot=0;
 irelative_ply[0]=iofficer[0]=ibroker[0]=iarea[0]=0;
 s_dpolicy[0]=0;
 dpolicy=mdmg_commi=mlia_commi=mdmg_prem=mlia_prem=0;
 s_yy1[0]=s_yy2[0]=s_mm1[0]=s_mm2[0]=s_dd1[0]=s_dd2[0]=0;
 yy1=yy2=mm1=mm2=pdiscount=mdiscount=0;
 result[0]=0;
 desc[0]=paydate[0]=duedate[0]=0;


 printf("------------------ INTO queryi()\n");

 cm_buf_get("%s",DBName);
 cm_buf_get("%s %s",ipolicy,sUserid);

 if(db_select(DBName) == False)
    return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

 strncpy(DBName,ipolicy,2); DBName[2]='\0';
 strcpy(sFullName, get_car_full_db(ipolicy));

 $WHENEVER SQLERROR GOTO errexit;

 /* get ���� */
 sprintf(stmt, "SELECT COUNT(*) \
                  FROM %s:edr_relation \
                 WHERE ipolicy='%s' \
                   AND iendorse[6,8]!='CVP'", sFullName, ipolicy);
 $PREPARE mqi_1 FROM $stmt;
 $DECLARE mqi_1_cursor CURSOR FOR mqi_1;
 $OPEN mqi_1_cursor;
 $FETCH mqi_1_cursor INTO $qtot;
 $CLOSE mqi_1_cursor;
 $FREE  mqi_1_cursor;

 cm_buf_init(ReplyBuf);
 cm_buf_put("%l",M_CM_OK);
 cm_buf_put("%l",qtot);

 sprintf(stmt,
   "SELECT B.icard, A.irelative_ply, A.iofficer, A.ibroker, A.dpolicy, \
           A.iarea, A.mdmg_commi, A.mlia_commi, A.mdmg_prem, \
           A.mlia_prem, B.nassured, A.dply_begin, A.dply_end,A.ibatch_no, \
           A.fcard_class, B.iassured \
      FROM %s:ori_ply_relation A,%s:original_ply B \
     WHERE A.ipolicy='%s' AND B.ipolicy = '%s' AND A.ipolicy=B.ipolicy",
         sFullName, sFullName, ipolicy, ipolicy);

/**A.pdiscount,A.mdiscount **/

 $PREPARE mqi_2 FROM $stmt;
 $DECLARE mqi_2_cursor CURSOR FOR mqi_2;
 $OPEN mqi_2_cursor;
 $FETCH mqi_2_cursor INTO $icard,$irelative_ply,$iofficer,$ibroker,$dpolicy,
                          $iarea,$mdmg_commi,$mlia_commi,$mdmg_prem,
                          $mlia_prem,$nassured,$dply_begin,$dply_end,
                          $ibatch_no,$fcard_class,$iassured;

 fFound = (SQLCODE == SQLNOTFOUND) ? 0 : 1;

 /* �Ӹ갱���ˮ� add by sylvia 103.02.17 (1020924002_C2) */
  strcpy(o_sDeny_msg," ");
        iCountDeny=0;
        iCountFunsale=0;
        $select count(*),funrenew_ins[1,1],funquery_ins[1,1],fdelete_ins[1,1]
            into $iCountDeny,$funrenew,$funquery,$fundelete
            from cm_personal_deny
           where iassured = $iassured
             and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
             and ddeny <= today
             and (dexpire is null or dexpire >= today)
             GROUP BY 2,3,4;
             
             rtncode = cm_chk_personal(iassured, 'C' , '*' , o_sDeny_msg, o_sFply_chk);
             
        if(iCountDeny > 0)
        {
            iUnDeny=0;
            /*�bcu_code_data.itype=CK ���]�w��,�i�H�d��*/ 
            $select count(*) into $iUnDeny
               from cu_code_data where itype = 'CK' and icode = $sUserid;
            if (iUnDeny == 0)
         	{
	         	if (strcmp(trim(funrenew),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_RENEW) ? M_CA_PERSONAL_DENY_RENEW :apiRC;
	            else if (strcmp(trim(funquery),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_QUERY) ? M_CA_PERSONAL_DENY_QUERY :apiRC;
	            else if (strcmp(trim(fundelete),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_DELETE) ? M_CA_PERSONAL_DENY_DELETE :apiRC;
	            else 
	            	return exitsub(reply,M_CA_PERSONAL_DENY) ? M_CA_PERSONAL_DENY :apiRC;
         	}
            else
	    		rtncode = cm_chk_personal(iassured, 'C' , '*' , o_sDeny_msg, o_sFply_chk);
        }

 $CLOSE mqi_2_cursor;
 $FREE  mqi_2_cursor;

 if(!fFound)
   return exitsub(reply,M_CA_NORI_INS_TYPE) ? M_CA_NORI_INS_TYPE : apiRC;

 mdiscount=0;

 sprintf(stmt, "SELECT SUM(mdiscount) \
                  FROM %s:ori_ins_type \
                 WHERE ipolicy='%s' ", sFullName, ipolicy);
 $PREPARE mqi_3 FROM $stmt;
 $DECLARE mqi_3_cursor CURSOR FOR mqi_3;
 $OPEN mqi_3_cursor;
 $FETCH mqi_3_cursor INTO $mdiscount;
 $CLOSE mqi_3_cursor;
 $FREE  mqi_3_cursor;

 printf("------------------4 mdiscount[%ld]\n",mdiscount);

 strcpy(s_dply_begin,cm_cdate_str_100(dply_begin));
 strcpy(s_dply_end,cm_cdate_str_100(dply_end));
 cm_split_ymd_100(s_dply_begin,s_yy1,s_mm1,s_dd1);
 cm_split_ymd_100(s_dply_end,s_yy2,s_mm2,s_dd2);
 yy1=atol(s_yy1);
 yy2=atol(s_yy2);
 mm1=atol(s_mm1);
 mm2=atol(s_mm2);
/**printf("### bgn y[%d] m[%d], end y[%d] m[%d]\n",yy1,mm1,yy2,mm2);**/
 months=(long)(yy2-yy1)*12+(mm2-mm1);
/**printf("### month=(yy2-yy1)*12+(mm2-mm1)=[%d]\n",months);**/
 strcpy(s_dpolicy,cm_cdate_str_100(dpolicy));


  /* �|��@��H�e
         ñ��O�O - ���� = �����O�O
     �|��@��H��
         ñ��O�O = �����O�O */

  chk_date = cm_build_date("91/04",1);

  printf("chk_date[%d] dpolicy[%d] \n",chk_date, dpolicy_chk );

  if( dpolicy >= chk_date )
  {
     total_prem = mdmg_prem + mlia_prem;
  }
  else
  {
     total_prem = mdmg_prem + mlia_prem - mdiscount;
  }

 cm_buf_put("%s %s %s %s %s %s %l %l %s %l %s %s %f %d %l",
            icard,irelative_ply,iofficer,ibroker,s_dpolicy,
            iarea,mdmg_commi+mlia_commi,mdmg_prem+mlia_prem,
            nassured,months,s_dply_begin,s_dply_end,pdiscount,
            mdiscount,total_prem );

 if(irelative_ply[0]!='\0' && irelative_ply[0]!=' ' && irelative_ply[0]!='A')
 {
    $SELECT icard
       INTO $icard
       FROM assured_vs_ply
      WHERE ipolicy=$irelative_ply;
/*    if(SQLCODE==SQLNOTFOUND)
      return exitsub(reply,M_CA_NASSURED_VS_PLY) ? M_CA_NASSURED_VS_PLY : apiRC;*/
 }
 else icard[0]='\0';

 cm_buf_put("%s",icard);
 split_ply(ipolicy,ao_policy1,ao_policy2);

 $SELECT ibatch_no INTO $ibatch_no FROM ply_relation
   WHERE ipolicy=$ipolicy;

 memset(batch_no,0,sizeof(batch_no));

 if (ibatch_no==0)
    strcpy(batch_no, " ");
 else
    sprintf(batch_no,"%d",ibatch_no);

 if (*fcard_class=='1')
 {

printf("------->fcard_class[%s]\n",fcard_class);

    if (strlen(rtrim(ipolicy)) > CAR_POLICY_LEN) /*�j�O��*/
       ao_chk_charge(DBName,'1',ao_policy1,ao_policy2,batch_no,result,
                     desc,paydate,duedate);
    else
       ao_chk_charge(DBName,'1',ao_policy1," ",batch_no,result,
                     desc,paydate,duedate);
 } else
    ao_chk_charge(DBName,'1',ao_policy1,ao_policy2,batch_no,result,
                                                desc,paydate,duedate);

   /*rc= ao_chk_charge (DBName, '1', ao_policy1,policy_2,batch_no,
                      result, desc, paydate, duedate);
printf("result[%s]\n",result);

   if (result[0]=='X')
   {
      rc = ao_chk_charge (DBName, '1', ao_policy1,"",batch_no,
                       result, desc, paydate, duedate);
   if (result[0]=='X')
      rc = ao_chk_charge (DBName, '1', ao_policy1,policy_2,"",
                       result, desc, paydate, duedate);
   }*/  /*M Thomas 870630*/

 cm_buf_put("%s %s %s",desc,paydate,duedate);
 /*�Ӹ�P�_*/
 cm_buf_put("%s",o_sDeny_msg);
 cm_buf_put("%s",iassured);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
     return apiRC;
 return api_OKComplete;

errexit:
  printf("stmt=[%s]\n",stmt);
  printf("SOLERR:%s\n",sqlca.sqlerrm);
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*********************************************************************/
/* NO NEED MODIFY CM_BUF_PUT JUST 'RENEW THE TABLE FILED CHANGED'    */
/*********************************************************************/
long car1001_multiple_queryj(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5], sFullName[20], stmt[1024];

 /* table edr_relation */
 $char iendorse[ENDORSE_NUM],ipolicy[POLICY_NUM_1],iofficer[EMPLOYEE_ID];
 char  s_dedr_begin[10],s_dedr_end[10],s_dendorse[10];
 $char nassured[41];
 $long dendorse,dedr_begin,dedr_end,dpolicy,chk_date,dedr_close;
 $long medrdmg_commi,medrlia_commi,medrdmg_prem,medrlia_prem;
 $long medrdmg_disc,medrlia_disc,total_prem;
 $char fedr_class[2], iassured[13];
 $short dedr_close_id;
 /* end of edr_relation */

 /*** AOI ***/
 char ao_policy1[CAR_POLICY_LEN+1],ao_policy2[CAR_TARGET_LEN+1];

 /* standard defined data */
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0;
 /* end of standard data */

 /* self defined data */
 long iindex;
 char s_yy1[4],s_yy2[4],s_mm1[3],s_mm2[3],s_dd1[3],s_dd2[3];
 long yy1,yy2,mm1,mm2,months,ibatch_no=0;
 char result[3];
 char desc[35],paydate[11],duedate[11];
 /* end of self data */
 iendorse[0]=ipolicy[0]=iofficer[0]=0;
 s_dedr_begin[0]=s_dedr_end[0]=s_dendorse[0]=0;
 dendorse=dedr_begin=dedr_end=0;
 dpolicy=chk_date=0;
 medrdmg_commi=medrlia_commi=medrdmg_prem=medrlia_prem=0;
 medrdmg_disc=medrlia_disc=0;
 iindex=0;
 s_yy1[0]=s_yy2[0]=s_mm1[0]=s_mm2[0]=s_dd1[0]=s_dd2[0]=0;
 yy1=yy2=mm1=mm2=months=0;
 result[0]=0;
 desc[0]=paydate[0]=duedate[0]=0;

 cm_buf_get("%s",DBName);
 cm_buf_get("%s %s %l",ipolicy, sUserid, &iindex);

 if(db_select(DBName) == False)
    return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

 strncpy(DBName,ipolicy,2); DBName[2]='\0';
 strcpy(sFullName, get_car_full_db(ipolicy));

 $WHENEVER SQLERROR GOTO errexit;

 sprintf(stmt,
   "SELECT a.iendorse,a.dendorse,dedr_begin,dedr_end,medrdmg_commi, \
           medrlia_commi,medrdmg_prem,medrlia_prem,medrdmg_disc,medrlia_disc, \
           a.iofficer,a.fedr_class,dpolicy,c.nassured[1,40],a.dedr_close, c.iassured \
      FROM %s:edr_relation a,%s:ply_relation b,%s:endorsement c \
     WHERE a.ipolicy='%s' \
       AND a.iendorse[6,8]!='CVP' \
       AND a.ipolicy = b.ipolicy \
       AND a.iendorse = c.iendorse \
  ORDER BY a.dcreate",
         sFullName, sFullName, sFullName, ipolicy);
 $PREPARE mqj_1 FROM $stmt;
 $DECLARE cur CURSOR FOR mqj_1;

 $OPEN cur;
 count=0;
 for(;;) {
   $FETCH cur INTO $iendorse,$dendorse,$dedr_begin,$dedr_end,
                   $medrdmg_commi,$medrlia_commi,
                   $medrdmg_prem,$medrlia_prem,$medrdmg_disc,$medrlia_disc,
                   $iofficer,$fedr_class,$dpolicy,$nassured,$dedr_close:dedr_close_id, $iassured;
        if(SQLCODE==SQLNOTFOUND) break;
        count++;
        if (count==iindex) break;
 }
 $CLOSE cur;
 $FREE  cur;
 if(count != iindex)
   return exitsub(reply,M_CA_NREL_EDR) ? M_CA_NREL_EDR : apiRC;

 /* �Ӹ갱���ˮ� add by sylvia 103.02.17 (1020924002_C2) */
     strcpy(o_sDeny_msg," ");
        iCountDeny=0;
        iCountFunsale=0;
        $select count(*),funrenew_ins[1,1],funquery_ins[1,1],fdelete_ins[1,1]
            into $iCountDeny,$funrenew,$funquery,$fundelete
            from cm_personal_deny
           where iassured = $iassured
             and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
             and ddeny <= today
             and (dexpire is null or dexpire >= today)
             GROUP BY 2,3,4;
             
             rtncode = cm_chk_personal(iassured, 'C' , '*' , o_sDeny_msg, o_sFply_chk);
             
        if(iCountDeny > 0)
        {
            iUnDeny=0;
            /*�bcu_code_data.itype=CK ���]�w��,�i�H�d��*/ 
            $select count(*) into $iUnDeny
               from cu_code_data where itype = 'CK' and icode = $sUserid;
            if (iUnDeny == 0)
         	{
	         	if (strcmp(trim(funrenew),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_RENEW) ? M_CA_PERSONAL_DENY_RENEW :apiRC;
	            else if (strcmp(trim(funquery),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_QUERY) ? M_CA_PERSONAL_DENY_QUERY :apiRC;
	            else if (strcmp(trim(fundelete),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_DELETE) ? M_CA_PERSONAL_DENY_DELETE :apiRC;
	            else 
	            	return exitsub(reply,M_CA_PERSONAL_DENY) ? M_CA_PERSONAL_DENY :apiRC;
         	}
            else
	    		rtncode = cm_chk_personal(iassured, 'C' , '*' , o_sDeny_msg, o_sFply_chk);
        }

 strcpy(s_dedr_begin,cm_cdate_str_100(dedr_begin));
 strcpy(s_dedr_end,cm_cdate_str_100(dedr_end));
 cm_split_ymd_100(s_dedr_begin,s_yy1,s_mm1,s_dd1);
 cm_split_ymd_100(s_dedr_end,s_yy2,s_mm2,s_dd2);
 yy1=atol(s_yy1);
 yy2=atol(s_yy2);
 mm1=atol(s_mm1);
 mm2=atol(s_mm2);
/**printf("### bgn y[%d] m[%d], end y[%d] m[%d]\n",yy1,mm1,yy2,mm2);**/
 months=(long)(yy2-yy1)*12+(mm2-mm1);
/**printf("### month=(yy2-yy1)*12+(mm2-mm1)=[%d]\n",months);**/
 strcpy(s_dendorse,cm_cdate_str_100(dendorse));
 /* �|��@��H�e
         ñ��O�O - ���� = �����O�O
     �|��@��H��
         ñ��O�O = �����O�O */

  chk_date = cm_build_date("91/04",1);


  if( dpolicy >= chk_date )
  {
     total_prem = medrdmg_prem + medrlia_prem;
  }
  else
  {
     total_prem = medrdmg_prem + medrlia_prem - medrlia_disc - medrdmg_disc;
  }

 cm_buf_init(ReplyBuf);
 cm_buf_put("l",M_CM_OK);
 cm_buf_put("%s %s %s %s %l %l %l %l %s %s",
            iendorse,s_dendorse,s_dedr_begin,s_dedr_end,
            medrdmg_commi+medrlia_commi,medrdmg_prem+medrlia_prem,
            medrdmg_disc+medrlia_disc,total_prem,
            iofficer,nassured);
 if (dedr_close_id == -1)
 {
      cm_buf_put("%s %s %s"," "," "," ");
 }
 else
 {
      if ((medrdmg_prem+medrlia_prem==0) && fedr_class[0]!='3')
      {
          cm_buf_put("%s %s %s"," "," "," ");
      } else {
          split_ply(ipolicy,ao_policy1,ao_policy2);
          if (strlen(rtrim(ipolicy)) > CAR_POLICY_LEN) /*�j�O��*/
             ao_chk_charge(DBName,'2',ao_policy1,ao_policy2,iendorse,result,
                                                     desc,paydate,duedate);
          else
             ao_chk_charge(DBName,'2',ao_policy1," ",iendorse,result,
                                                     desc,paydate,duedate);

          cm_buf_put("%s %s %s",desc,paydate,duedate);
      }
 }

 /*�Ӹ�P�_*/
 cm_buf_put("%s",o_sDeny_msg);
 cm_buf_put("%s",iassured);


 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 return api_OKComplete;

errexit:
 printf("stmt=[%s]\n",stmt);
 printf("SOLERR:%s\n",sqlca.sqlerrm);
 return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}


/*********************************************************************/
/*      FOR ca1001_get_dataa                                         */
/* REMARK                                                            */
/* NEED ADD fcomp_class_last, fcomp_class, mbusiness, iply_area      */
/* select mbusiness into $mbussiness then change to tmp_business     */
/*********************************************************************/
/***** ��l�O�� *****/
long car1001_multiple_queryk(reply)
serverReply reply;
{
     /* standard defined host variables */
     $char DBName[5];
     long  rc;
     /* end of standard host var */

     /* table policy */
     $char ipolicy[POLICY_NUM_1],s_dply_begin[10],s_dply_end[10],icard[19];
     $char itmp_policy[POLICY_NUM_1];
     $char iassured[11],iassured_ext[3],nassured[41],nuser[19],nbenef[43], iapplicant[13];
     $long dply_begin,dply_end;
     $char aassured[65],itel[21],iissue_ym[7],apayment[65];
     $char tphone_con[21],tphone_ext_con[21],imovephone[21],iemail[51];
     $char ipro_year[5],qpro_month[4],ibrand[9],icar_type[3];
     $char icorps[11],icorps_name[21];
     $char iengine[21],ibody[21],itag[CA_TAG_NUM],icredit_no[17],iofficer[11],nname[13];
     $char ilicense[11],ibirth[10],fsex[2],fmarriage[2];
     $char iacc_align[3],flimit[2],nequipment[31], Frescue[2], Fno_mdeduct[2];
     $char s_nequipment[201],icode_note[11],ncode_note[41];
     $long months, qcylinder;
     $short pdmg_align,plia_align,pbrg_align;
     $dec_t mcar_price;
     $char s_mcar_price[10], ixxcard[19];
     $char fcut[2],fcal_way[2],fpt[2],cdxxend[9],dxxend[11];
     $double qpt,psex_age,plia_acc,pdmg_acc;
     $char fcomp_24[2],ibig_resource[5],fdamaged[2],fspecial[2];
     $char fdiscount[2];
     $char fcomp_class_last[3],fcomp_class[3],iply_area[11],tmp_business[11], napplicant[121];
     $double preward, mbusiness;
     $char   iabn_type[2], survey_num[121], bound_num[121], ibound[421];
     $double mequipment;
     /* end of policy */

     $char nbrand_abbr[13], s_dedr_begin[10], s_dedr_end[10];
     $char ncode[11], nbrand_abbr2[13], ncar_abbr2[13];
     $char iins_type[INSURANCE_TYPE], sFullName[20], stmt[5182], sDBSite[3];
     $long minjured_cover,mdeath_cover,mdamage_cover,mdeduct,mins_premium,mcredit;
     $char provision[21];
     $double pdiscount, deviation_rate;
     $long mdiscount,mprem;
     $long sum_mdiscount, sum_mprem;
     $double avg_pdiscount;
     $char s_avg_pdiscount[8];
     long  mtot;
     $long qday;
     $char ideduct_c[9],ndeduct[19],prndeduct[19];
     $double safe_rate, manage_rate;
     $char drate_ym[5];

     /* table ply_relation */
     $char irelative_ply[POLICY_NUM_1],ilast_ply[POLICY_NUM_1];
     $char inext_ply[POLICY_NUM_1],s_dtransfer[10];
     $char s_dpolicy[10],iresource[7],ibig_branch[3],ibig_office[10],ibig_sales[11];
     $char iresource_tmp[23];
     $char iresource_name[21];
     $char s_dentry[10];
     $char fcard_class[2],ibig_nname[41];
     $long dtransfer,dentry,dpolicy,dedr_begin,dedr_end,mlia_prem;
     $char iarea[11];
     $long coverage1_31, coverage2_31, coverage3_32;
     $char nequip_azpg[31];
     $char nleader[11];
     $char irate_type[2],iroute_comm[4],icomm_obj[11];
     $char s_ftrans_trade[3], s_dtrans_trade[21];
     /* end of ply_relation */

     /* �q��������� dws9807211 */
     $char introducer[21],iroute_accept[21],iroute_prop[3];
     $char nroute_prop[21],sIpolicy1[POLICY_NUM_1], sIpolicy2[POLICY_NUM_2];
     $char iroute[21],iroute_name[41],imgr[2],iroute_main[13];
     /* �e�~�O��M��(�e�~�C�L,�l�H�覡) add by larry 103.03.11 (1010523004_C2) */
     $char fout_print[3],fmail_type[5],dout_trans[11],s_dout_trans[10];
     $char sFtypeSp[21], nsign[11];
     /* table edr_ins_type */
     $char iedr_type[3],iendorse[19];     
     /* �F�����(�e�~)) */
     $char sIrouteNote[3], sMailRemark[9];
     $int  cntIroute;
     /*�s�W�l���ϸ��B��O���O*/
     $char aassured_zip[6],apayment_zip[6];
     $char aassured1[97],apayment1[97];
     $char iassured_cntry[2],nassured_cntry[50];
     
     /* standard defined data */
     char tmpbuf[4000];
     int count=0,repbuf_len=0,tmp_len=0,replycnt=0, fFound;
     int i,total_count=0;
     int j=0;

     /* self defined data */
     char s_yy1[4],s_yy2[4],s_mm1[3],s_mm2[3],s_dd1[3],s_dd2[3];
     long yy1,yy2,mm1,mm2;
     char     v_sMsg[1512];

     ipolicy[0]=s_dply_begin[0]=s_dply_end[0]=icard[0]=nassured[0]=cdxxend[0]=dxxend[0]=0;
     nuser[0]=nbenef[0];
     dply_begin=dply_end=qpt=psex_age=plia_acc=pdmg_acc=0;
     aassured[0]=itel[0]=iissue_ym[0]=apayment[0]=ipro_year[0]=qpro_month[0]=0;
     tphone_con[0]=tphone_ext_con[0]=imovephone[0]=iemail[0]=0;
     icorps[0]=icorps_name[0]=0;
     fcut[0]=fcal_way[0]=fpt[0]=0;
     ibrand[0]=icar_type[0]=0;
     iengine[0]=ibody[0]=itag[0]=ilicense[0]=ibirth[0]=fsex[0]=fmarriage[0]=0;
     iacc_align[0]=flimit[0]=nequipment[0]=ibound[0]=survey_num[0]=bound_num[0]=0;
     irate_type[0]=iroute_comm[0]=icomm_obj[0]=0;
     months=qcylinder=pdmg_align=plia_align=pbrg_align=0;
     s_mcar_price[0]=0;
     nbrand_abbr[0]=s_dedr_begin[0]=s_dedr_end[0]=0;
     ncode[0]=nbrand_abbr2[0]=ncar_abbr2[0]=0;
     iins_type[0]=0;
     iroute[0]=iroute_name[0]=iroute_main[0]=0;
     minjured_cover=mdeath_cover=mdamage_cover=mdeduct=mins_premium=0;
     mtot=0;
     irelative_ply[0]=ilast_ply[0]=inext_ply[0]=s_dtransfer[0]=0;
     s_dpolicy[0]=iresource[0]=ibig_branch[0]=ibig_office[0]=ibig_sales[0]=0;
     iresource_name[0]=0;
     s_dentry[0]=0;
     fcard_class[0]=0;
     dtransfer=dentry=dpolicy=dedr_begin=dedr_end=mlia_prem=0;
     iedr_type[0]=0;
     qday=0;
     s_yy1[0]=s_yy2[0]=s_mm1[0]=s_mm2[0]=s_dd1[0]=s_dd2[0]=0;
     yy1=yy2=mm1=mm2=0;
     coverage1_31= coverage2_31= coverage3_32= 0;
     pdiscount = 0.00;
     mdiscount = mprem = sum_mdiscount = sum_mprem = 0;
     avg_pdiscount = 0.0;
     s_avg_pdiscount[0] = 0;
     provision[0]='\0';
     itmp_policy[0]='\0';
     mequipment = safe_rate = manage_rate = 0;
     fout_print[0]=fmail_type[0]=dout_trans[0]=0;
     sFtypeSp[0]=nsign[0]=0;
     
     aassured_zip[0] = aassured1[0] = 0;
     apayment_zip[0] = apayment1[0] = 0; 
     iassured_cntry[0] = nassured_cntry[0] = 0;
     tmp_feply[0]=feply1[0]=feply2[0]=aemail_eply[0]=dcreate_eply[0]=0;

     cm_buf_get("%s",DBName);
     cm_buf_get("%s %s",ipolicy,sUserid);

     if(db_select(DBName) == False)
       return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
     strncpy(DBName,ipolicy,2); DBName[2]='\0';
     strcpy(sFullName, get_car_full_db(ipolicy));

     printf("SFR==>This is new add parts !!\n");
     $WHENEVER SQLERROR GOTO errexit;
     sprintf(stmt,
       "SELECT A.irelative_ply, A.ilast_ply, A.inext_ply, A.dtransfer, \
               B.ixxcard, A.dply_begin, A.dply_end, B.icard,B.iassured,B.iassured_ext,B.nassured, \
               B.nuser, B.nbenef, B.aassured_zip, B.aassured, B.itel, B.itel_night, B.mobil_phone, B.iemail, B.iply_area, B.apayment_zip, B.apayment, \
               to_char(B.dissue,'%%Y')::integer - 1911 || '/' || to_char(B.dissue,'%%m'), \
               A.ipro_year, B.qpro_month, A.ibrand, A.icar_type, B.qcylinder, B.iengine, \
               B.ibody, B.itag, B.ilicense, \
               to_char(B.dbirth,'%%Y')::integer - 1911 || '/' || to_char(B.dbirth,'%%m/%%d'), \
               B.fsex, B.fmarriage, \
               B.flimit, B.pdmg_align,B.pbrg_align, B.plia_align, \
               B.mcar_price, B.nequipment, \
               A.dpolicy, A.iresource,iofficer, \
               (SELECT nname FROM officer WHERE iofficer = A.ileader), icorps, \
               A.ibig_branch, A.ibig_office, A.ibig_sales, B.iroute, A.fcard_class, \
               A.mlia_prem, B.fcut, B.fcal_way, B.qpt, B.fpt, B.psex_age, \
               B.plia_acc, B.pdmg_acc, B.nbrand_abbr, B.ncar_abbr, \
               A.iarea, B.fcomp_24, \
               A.fdiscount, \
               A.fcomp_class, A.fcomp_class_last, A.mbusiness, A.dentry, A.itmp_policy, B.napplicant, \
               B.iabn_type, nvl(B.mequipment,0) , B.iapplicant, B.survey_num, B.bound_num, \
               A.irate_type,A.iroute_comm,A.icomm_obj, \
               CASE WHEN A.fout_print = '1' AND A.fmail_type = '0' THEN '�_' \
               ELSE CASE WHEN A.fout_print = '1' THEN '�O' ELSE '�_' END END , \
               decode(A.fmail_type,'1','���H','2','����','3','����','4','����',' '), \
               date(A.dout_trans), \
               (SELECT nname FROM officer WHERE iofficer = A.isign) AS nsign, \
               B.iassured_cntry, CASE WHEN A.ftrans_trade = '1' THEN '�O' ELSE '�_' END ,nvl(A.dtrans_trade,' '), \
          	   A.feply, A.aemail_eply, A.dcreate_eply \
          FROM %s:ori_ply_relation A, %s:original_ply B \
         WHERE A.ipolicy = '%s' AND B.ipolicy = '%s' AND A.ipolicy=B.ipolicy",
             sFullName, sFullName, ipolicy, ipolicy);

     $PREPARE mqa_1x FROM $stmt;
     $DECLARE mqa_1_cursorx CURSOR FOR mqa_1x;
     $OPEN    mqa_1_cursorx;
     $FETCH   mqa_1_cursorx INTO $irelative_ply,$ilast_ply,$inext_ply,$dtransfer,
                     $ixxcard, $dply_begin, $dply_end, $icard, $iassured, $iassured_ext, $nassured,
                     $nuser,$nbenef,$aassured_zip,$aassured,$itel,$tphone_con,$imovephone,$iemail, $iply_area,$apayment_zip,$apayment,
                     $iissue_ym,
                     $ipro_year, $qpro_month, $ibrand, $icar_type, $qcylinder, $iengine,
                     $ibody, $itag, $ilicense,
                     $ibirth,
                     $fsex, $fmarriage,
                     $flimit,$pdmg_align, $pbrg_align,$plia_align,
                     $s_mcar_price, $nequipment,
                     $dpolicy, $iresource,$iofficer,$nleader,$icorps,
                     $ibig_branch, $ibig_office, $ibig_sales, $iroute, $fcard_class,
                     $mlia_prem, $fcut, $fcal_way, $qpt, $fpt, $psex_age,
                     $plia_acc, $pdmg_acc, $nbrand_abbr2, $ncar_abbr2,
                     $iarea, $fcomp_24,
                     $fdiscount,
                     $fcomp_class, $fcomp_class_last, $mbusiness, $dentry, $itmp_policy, $napplicant,
                     $iabn_type, $mequipment, $iapplicant, $survey_num, $bound_num,
                     $irate_type,$iroute_comm,$icomm_obj,$fout_print,$fmail_type,$dout_trans,$nsign,$iassured_cntry,$s_ftrans_trade,$s_dtrans_trade,
					 $tmp_feply,$aemail_eply,$dcreate_eply;
					 
printf("iabn_type[%s],mequipment[%f]\n",iabn_type,mequipment);

     fFound = (SQLCODE == SQLNOTFOUND) ? 0 : 1;
     $CLOSE mqa_1_cursorx;
     $FREE  mqa_1_cursorx;
     if(!fFound)
       return exitsub(reply,M_CA_NPOLICY) ? M_CA_NPOLICY : apiRC;

     /* �Ӹ갱���ˮ� add by sylvia 103.02.17 (1020924002_C2) */
        strcpy(o_sDeny_msg," ");
        iCountDeny=0;
        iCountFunsale=0;
        $select count(*),funrenew_ins[1,1],funquery_ins[1,1],fdelete_ins[1,1]
            into $iCountDeny,$funrenew,$funquery,$fundelete
            from cm_personal_deny
           where iassured = $iassured
             and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
             and ddeny <= today
             and (dexpire is null or dexpire >= today)
             GROUP BY 2,3,4;
             
             rtncode = cm_chk_personal(iassured, 'C' , '*' , o_sDeny_msg, o_sFply_chk);
             
        if(iCountDeny > 0)
        {
            iUnDeny=0;
            /*�bcu_code_data.itype=CK ���]�w��,�i�H�d��*/ 
            $select count(*) into $iUnDeny
               from cu_code_data where itype = 'CK' and icode = $sUserid;
            if (iUnDeny == 0)
         	{
	         	if (strcmp(trim(funrenew),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_RENEW) ? M_CA_PERSONAL_DENY_RENEW :apiRC;
	            else if (strcmp(trim(funquery),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_QUERY) ? M_CA_PERSONAL_DENY_QUERY :apiRC;
	            else if (strcmp(trim(fundelete),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_DELETE) ? M_CA_PERSONAL_DENY_DELETE :apiRC;
	            else 
	            	return exitsub(reply,M_CA_PERSONAL_DENY) ? M_CA_PERSONAL_DENY :apiRC;
         	}
            else
	    		rtncode = cm_chk_personal(iassured, 'C' , '*' , o_sDeny_msg, o_sFply_chk);
        }

     /*�s�y�~��*/
     strcat(ipro_year, "/");
     strcat(ipro_year, trim(qpro_month));
     printf("**********************ipro_year = %s\n",ipro_year);

     /**Ū���g��H����****/
     $SELECT  nname,nvl(imgr,' ')
        INTO   $nname, $imgr
        FROM   officer
       WHERE   iofficer = $iofficer;

     /**Ū��¾�ΥN������****/
     if (icorps[0] != '\0' && icorps[0] != ' ')
     {
          EXEC SQL SELECT  nname
                     INTO  :icorps_name
                     FROM  officer
                    WHERE  iofficer = :icorps;
     }

     EXEC SQL SELECT ncode[1,20]
                INTO :iresource_tmp
                FROM cu_code_data
               WHERE itype = '10'
                 AND icode = :iresource;
     if (SQLCODE==SQLNOTFOUND)
     {
          strcpy(iresource_name,iresource);
     }
     else
     {
          strcpy(iresource_name,trim(iresource));
          strcat(iresource_name,":");
          strcat(iresource_name,trim(iresource_tmp));
     }

     EXEC SQL SELECT nequipment
                INTO $nequip_azpg
                FROM conv_nequipment
               WHERE ipolicy = $ipolicy;
     if (SQLCODE == SQLNOTFOUND)
     {
        strcpy(nequip_azpg," ");
     }

     /****Ū��������~��/�q����~������****/
     /* get_route_data input ������~��/�q���N��,���ӳq����~���N��
        �H�θg��N��,�^�Ǩ���/�q����~������W�� (2:����/�q����~��, 1:����/�q����~��) */
     /* imgr=1���ɭԬO���ӥ�,�Ǩ�����~��,��L���h�ǤJ�q���N�� */
     if (imgr[0] == '1')
        rc = get_route_data(1, iofficer, ibig_office, ibig_sales, ibig_nname, v_sMsg);
     else
        rc = get_route_data(1, iofficer, iroute, ibig_sales, ibig_nname, v_sMsg);

     if (rc != M_CM_OK) strcpy(ibig_nname," ");
     /* end of Ū������/�q����~�� */

     /* Ū���q��������� dws9807211
        cm_route_data.column_1(���z�s��),cm_route_data.column_9(�q�����u),
        cm_route_data.column_10(�q��������O) */
        if ((rc = split_policy(ipolicy, sIpolicy1, sIpolicy2)) == M_CM_OK)
        {
           EXEC SQL SELECT nvl(column_1,' '),nvl(column_9,' '),nvl(column_10,' ')
                      INTO $iroute_accept,$introducer,$iroute_prop
                      FROM cm_route_data
                     WHERE ipolicy1 = $sIpolicy1
                       AND ipolicy2 = $sIpolicy2;
           if (SQLCODE == SQLNOTFOUND)
           {
              strcpy(iroute_accept,"");
              strcpy(introducer,"");
              strcpy(iroute_prop,"");
              strcpy(nroute_prop,"");
           } else
           {
        	      /* �Y�䪺��N�h����������q��������O */
        	         if (iroute_prop[0] != '\0' && iroute_prop[0] != ' ')
        	         {
        	   	      /*EXEC SQL SELECT ncode
                     INTO $nroute_prop
                     FROM cu_code_data
                    WHERE itype = 'BK'
                      AND icode = $iroute_prop;
                    if (SQLCODE == SQLNOTFOUND)  strcpy(nroute_prop,"");*/

                    $SELECT iroute_main INTO $iroute_main
                       FROM cm_route
                      WHERE iroute = $iroute;
                      if (SQLCODE == SQLNOTFOUND)  strcpy(iroute_main,"");

                    /*�u�q���ۭq�~�ȥN���v�令�d��cm_route_prop modify by larry 103.07.08 */
                    $SELECT nroute_prop INTO $nroute_prop
                       FROM cm_route_prop
                      WHERE iroute = $iroute_main
                        AND iroute_prop = $iroute_prop;
                    if (SQLCODE == SQLNOTFOUND)  strcpy(nroute_prop,"");
             	   }
                  else strcpy(nroute_prop,"");
        	   }
        }
        else
        {
        	   strcpy(iroute_accept,"");
        	   strcpy(introducer,"");
        	   strcpy(nroute_prop,"");
        }
     /* end of Ū���q��������� */

     /***Ū���H�Υd���***/
     /* 1041110002_C1 ���ӫO�N��X��H�Υd��J�{�ǽվ� 
        �H�Υd��ƥѭ�鵲����J�O�O�t��(ao_io_credit)�אּ�J���Y��J(�Y�j��P���N�X�ֽд�)
     */
     mcredit = 0;
     sprintf(stmt,"SELECT nvl(sum(nvl(mcredit,0)),0) FROM %s:ao_io_credit \
                    WHERE ipolicy1 = ? AND ipolicy2 = ? AND icard = ? AND nvl(iendorse,'') = '' \
                      AND nvl(icreditno,'') <> '' \
                      AND dentry = (SELECT max(dentry) FROM %s:ao_io_credit \
                                     WHERE ipolicy1 = ? AND ipolicy2 = ? AND icard = ? AND nvl(iendorse,'') = '' \
                                       AND nvl(icreditno,'') <> '' and dentry is not null) ",
            sFullName,sFullName);                   
     EXEC SQL PREPARE pre_credit  FROM :stmt;
     EXEC SQL EXECUTE pre_credit
                 INTO :mcredit
                USING :sIpolicy1, :sIpolicy2, :icard, :sIpolicy1, :sIpolicy2, :icard;
     printf("-- trace 2mcredit[%ld]\n ",mcredit);
     if (SQLCODE == SQLNOTFOUND)
     { 
     	     
	     sprintf(stmt,"SELECT  nvl(sum(nvl(mcredit,0)),0)  From %s:cm_credit_pay \
	                    WHERE ipolicy1 = ? AND ipolicy2 = ? \
	                      AND nvl(iendorse,'') = '' \
	                      AND nvl(icreditno,'') <> ''",sFullName);
	     $PREPARE    credit_stmt  FROM  $stmt;
	     $EXECUTE    credit_stmt
	                 INTO  $mcredit
	                 USING $sIpolicy1, $sIpolicy2;
	     if (SQLCODE == 100)
	     {
	         icredit_no[0] = '\0';
	         mcredit       =  0;
	     }
     }
     /**Ū���q�ܸ��****/
     EXEC SQL DECLARE tphone_ori_cur1 CURSOR FOR
               SELECT tphone_ext_con
                 FROM cu_customer
                WHERE ifpce_id = :iassured
                  AND ifpce_id_ext = :iassured_ext;
     EXEC SQL OPEN  tphone_ori_cur1;
     EXEC SQL FETCH tphone_ori_cur1 INTO $tphone_ext_con;

     if (SQLCODE==SQLNOTFOUND)
     {
         strcpy(tphone_ext_con, " ");
         printf("read cu_customer notfound\n");
     }
     EXEC SQL CLOSE tphone_ori_cur1;
     EXEC SQL FREE  tphone_ori_cur1;
     printf("read cu_customer end\n");

     /* �W�[�u�O�����O�ʽ�v��� add by larry 104.01.19 (1040107011_C1) */
     /* �ĳq�ʽ��� car_code.kind = '39' */
     sprintf(stmt,"SELECT a.ftype_sp||NVL((SELECT chiname FROM car_code \
                                            WHERE kind = '39' AND detail2 = '' \
                                              AND detail = a.ftype_sp),' ') \
                     From sysdb:cm_pre_receive a \
                    WHERE a.iins_cat = 'C' \
                      AND a.ipre_rcv = '%s' \
                      AND a.iins_kind = '%s' \
                      AND a.ipre_end = ' ' ", itmp_policy, fcard_class);
     $PREPARE ftypeSp_stmt FROM $stmt;
     $EXECUTE ftypeSp_stmt INTO $sFtypeSp;
     
     cntIroute = 0;
     /* �i�F����ġj(�e�~)�u�l�H�覡�v�W�[�Ƶ����� (1041102003_C1) */
     sprintf(stmt,"SELECT chiname, count(*) \
                     FROM car_code \
                    WHERE kind = 'SR' \
                      AND detail = '%s' \
                      AND detail2 = '%s' \
                    GROUP BY chiname;", iroute, iofficer);
     $PREPARE outIroute_cur FROM $stmt;
     $EXECUTE outIroute_cur INTO $sIrouteNote, $cntIroute;
     
     if (cntIroute > 0 && (equip_cmp(nequipment,"37") != TRUE))
         strcpy(sMailRemark, "�i��I�g��j");
     else
         strcpy(sMailRemark, " ");

     /*dectoasc(&mcar_price,s_mcar_price,5,1);*/
     strcpy(s_dtransfer,cm_cdate_str_100(dtransfer));
     strcpy(s_dply_begin,cm_cdate_str_100(dply_begin));
     strcpy(s_dply_end,cm_cdate_str_100(dply_end));
     strcpy(s_dout_trans,cm_from_infdate_100(dout_trans));

     cm_split_ymd_100(s_dply_begin,s_yy1,s_mm1,s_dd1);
     cm_split_ymd_100(s_dply_end,s_yy2,s_mm2,s_dd2);
     yy1=atol(s_yy1);
     yy2=atol(s_yy2);
     mm1=atol(s_mm1);
     mm2=atol(s_mm2);
     months=(long)(yy2-yy1)*12+(mm2-mm1);
     strcpy(s_dpolicy,cm_cdate_str_100(dpolicy));
     strcpy(s_dentry,cm_cdate_str_100(dentry));
     
     strcat(aassured1,aassured_zip);
     strcat(aassured1," ");
     strcat(aassured1,aassured);
     strcat(apayment1,apayment_zip);
     strcat(apayment1," ");
     strcat(apayment1,apayment);     
         
     if(strcmp(iassured_cntry,"1",1) == 0)
     strcpy(nassured_cntry,"�����I��a");
     else if(strcmp(iassured_cntry,"2",1) == 0)
     strcpy(nassured_cntry,"�j���H(���t��D)");
     else if(strcmp(iassured_cntry,"8",1) == 0)
     strcpy(nassured_cntry,"��L");
     else
     strcpy(nassured_cntry,"����H");

     cm_buf_init(ReplyBuf);
     cm_buf_res_msg();
     cm_buf_res_count();
     cm_buf_put_msg(M_CM_OK);
     cm_buf_put("%s %s %s %s %l %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
                irelative_ply,ilast_ply,inext_ply,s_dtransfer,months,
                s_dply_begin,s_dply_end,icard,iassured,nassured,ibirth,nuser,nbenef,
                aassured1,itel,tphone_con,tphone_ext_con,imovephone,iemail,
                apayment1,iissue_ym,ipro_year,ibrand,icar_type);

     sprintf(tmp_business,"%10.3f",mbusiness);
     /** ADD FOR ISPS 870610 **/
     cm_buf_put("%s %s %s %s ",iply_area,fcomp_class_last,fcomp_class,tmp_business);
     /** END ADD **/

     cm_buf_put("%s %s %s",fout_print,fmail_type,s_dout_trans);
     cm_buf_put("%l %s %s %s ", qcylinder, iengine, ibody, itag);


     cm_buf_put("%c %l %l ", flimit[0], pdmg_align, pbrg_align);

     /*** ��Ū���O���� ***/
     strcpy(equipdecode,equip_get(nequipment));
     printf("5303:equipdecode=[%s]\n",equipdecode);
     s_nequipment[0] = '\0';
     IEquip_ptr=IfirstEquip;
     while (IEquip_ptr)
     {
         strcpy(icode_note , IEquip_ptr->sequip);
         printf("5309:icode_note[%s]\n",icode_note);
         iTmpcode = atoi(icode_note);
         sprintf(icode_note,"%02d",iTmpcode);
         printf("5325:icode_note[%s]\n",icode_note);
         EXEC SQL SELECT ncode
                    INTO :ncode_note
                    FROM cu_code_data
                   WHERE itype = '25'
                     AND icode = :icode_note;
         if (SQLCODE != SQLNOTFOUND)
         {
             strcat(s_nequipment,"�i");
             strcat(s_nequipment,trim(icode_note));
             strcat(s_nequipment,":");
             strcat(s_nequipment,trim(ncode_note));
             strcat(s_nequipment,"�j");
         }
         IEquip_ptr=IEquip_ptr->next;
     }

     strcpy( sDbname, sFullName);
     strcpy( sColumn, "ipolicy");
     strcpy( sTable,  "ca_ori_bound");
     rc = get_ca_ply_bound( sDbname, sTable, sColumn, ipolicy, ibound, v_sMsg);
     if( rc != M_CM_OK)
         return exitsub(reply,rc) ? rc : apiRC;

/*************************************************************************
     s_nequipment[0] = '\0';
     j=strlen(nequipment);
     for (i=0;i<j;i++)
     {
            if (nequipment[i] == '1')
            {
                strcpy(icode_note , itoa(i+1));
                printf("icode_note[%s]\n",icode_note);
                EXEC SQL SELECT ncode
                           INTO :ncode_note
                           FROM cu_code_data
                          WHERE itype = '25'
                            AND icode = :icode_note;
                if (SQLCODE == SQLNOTFOUND)
                     strcpy(ncode_note, "");
                strcat(s_nequipment,"�i");
                strcat(s_nequipment,trim(icode_note));
                strcat(s_nequipment,":");
                strcat(s_nequipment,trim(ncode_note));
                strcat(s_nequipment,"�j");
            }
     }
*****************************************************************************/
         printf("nequipment[%s],s_nequipment[%s]\n",nequipment,s_nequipment);

     /* delete frescue and fno_mdeduct FOR ISPS 870610 */
     cm_buf_put("%l %s %s ", plia_align, s_mcar_price, s_nequipment);
     cm_buf_put("%s %s %s ", s_dpolicy, iresource_name, ibig_branch);
     cm_buf_put("%s %s %s %s %s %s %s %s %s %l",iofficer,nname,nleader,icorps,icorps_name,ibig_office,ibig_sales,ibig_nname, "",mcredit);

     /* dws9807211 */
printf("original=>intro[%s],accept[%s],prop[%s]\n",introducer,iroute_accept,nroute_prop);
     cm_buf_put("%s %s %s %s",introducer,iroute_accept,nroute_prop,iroute);

     cm_buf_put("%s %s %f %s %f %s %f %f",
                fcut,fcal_way,qpt,fpt,
                psex_age,fcard_class,plia_acc,pdmg_acc);

     if (irelative_ply[0]=='\0' || irelative_ply[0]==' ' || irelative_ply[0]=='A')
         cm_buf_put("%s",irelative_ply);
     else
     {
      $SELECT icard
         INTO $icard
         FROM assured_vs_ply
        WHERE ipolicy=$irelative_ply;
      if(SQLCODE==SQLNOTFOUND)
      return exitsub(reply,M_CA_NASSURED_VS_PLY) ? M_CA_NASSURED_VS_PLY : apiRC;
      cm_buf_put("%s",icard);
     }

     $DECLARE car_mod_cur2 CURSOR FOR
      SELECT nbrand_abbr
        FROM ca_car_model
       WHERE ibrand=$ibrand AND ipro_year=$ipro_year;
     $OPEN car_mod_cur2;
     $FETCH car_mod_cur2 INTO $nbrand_abbr;
     if(SQLCODE==SQLNOTFOUND) memset(nbrand_abbr,' ',sizeof(nbrand_abbr));
     cm_buf_put("%s",nbrand_abbr);

     $SELECT ncode
        INTO $ncode
        FROM car_type
       WHERE icode=$icar_type AND fclass="1";
     if(SQLCODE==SQLNOTFOUND) memset(ncode,' ',sizeof(ncode));
     cm_buf_put("%s",ncode);

     cm_buf_put("%s", iarea);
     cm_buf_put("%s", fcomp_24);
     cm_buf_put("%s %s %f %s", fdiscount,iabn_type,mequipment, iapplicant);
     cm_buf_put("%s", nassured_cntry);
     
     sprintf(stmt,
       "SELECT iins_type, dedr_begin, dedr_end, minjured_cover, mdeath_cover, \
               mdamage_cover, mdeduct, mins_premium, iendorse,pdiscount,mdiscount, \
               mprem, qday, provision, deviation_rate, \
               drate_ym, safe_rate, manage_rate \
          FROM %s:ori_ins_type \
         WHERE ipolicy = '%s' ",
             sFullName, ipolicy);
     $PREPARE mqa_2x FROM $stmt;
     $DECLARE q_cur5x CURSOR FOR mqa_2x;
     $OPEN q_cur5x;
     count = mtot = 0;
     for(;;){
        $FETCH q_cur5x INTO $iins_type, $dedr_begin, $dedr_end, $minjured_cover,
                           $mdeath_cover, $mdamage_cover, $mdeduct,
                           $mins_premium, $iendorse,$pdiscount,$mdiscount,
                           $mprem,$qday, $provision, $deviation_rate,
                           $drate_ym, $safe_rate, $manage_rate;

        if (SQLCODE == SQLNOTFOUND) break;
        if(iendorse[0] != ' ' && iendorse[0] != '\0'){
          sprintf(stmt,
            "SELECT iedr_type \
               FROM %s:edr_ins_type \
              WHERE iendorse='%s' AND iins_type='%s' ",
                  sFullName, iendorse, iins_type);
          $PREPARE mqa_3x FROM $stmt;
          $DECLARE mqa_3_cursorx CURSOR FOR mqa_3x;
          $OPEN mqa_3_cursorx;
          $FETCH mqa_3_cursorx INTO $iedr_type;
          fFound = (SQLCODE == SQLNOTFOUND) ? 0 : 1;
          $CLOSE mqa_3_cursorx;
          $FREE  mqa_3_cursorx;
          if(!fFound)
            iedr_type[0]=0;
        } else
           iedr_type[0]=0;

        /* �ۭt�B���� */
        strcpy(ideduct_c,itoa(mdeduct));
        rc = get_deduct_info(icar_type,iins_type,ideduct_c,ndeduct,prndeduct);

        /* �W�B�d���I */
        if (strcmp(trim(iins_type),"29")==0)
        {
             printf("iins_type[%s],qday[%ld]\n",iins_type,qday);
             rc = lReturnIns29BaseCover(qday,&coverage1_31,&coverage2_31,&coverage3_32);
             qday = 0;
             printf("qday[%ld],coverage1[%ld],coverage2[%ld],coverage3[%ld]\n",qday,coverage1_31,coverage2_31,coverage3_32);
        }
        /* 31�d���I */
        if (strcmp(trim(iins_type),"31")==0 || strcmp(trim(iins_type),"36")==0)
        {
           qday = 0;
        }
	if (strcmp(trim(iins_type),"21")==0)
        {
           mdamage_cover = 2200000;
        }
	
        strcpy(s_dedr_begin,cm_cdate_str_100(dedr_begin));
        strcpy(s_dedr_end,cm_cdate_str_100(dedr_end));

        sum_mdiscount += mdiscount;
        sum_mprem     += mprem;

        cm_buf_put("%s %s %s %l %l %l %s %l %s %l %f %s %e",
                    iins_type,s_dedr_begin,s_dedr_end,minjured_cover,
                    mdeath_cover,mdamage_cover,prndeduct,mins_premium,iedr_type,qday,pdiscount,provision,deviation_rate);

        cm_buf_put("%s %e %e",drate_ym,safe_rate,manage_rate);

        count++;
        mtot+=mins_premium;
     } /* for loop */
     $CLOSE q_cur5x;
     $FREE  q_cur5x;
     cm_buf_put_count(count);

     cm_buf_put("%l %l %l",coverage1_31,coverage2_31,coverage3_32);
     cm_buf_put("%l",mtot);
     cm_buf_put("%s",ixxcard);  /**** 84.05.17 ****/

     avg_pdiscount = (double)sum_mdiscount / (double)sum_mprem * 100.0;
     printf("sum_mdiscount[%ld],sum_mprem[%ld]\n",sum_mdiscount,sum_mprem);
     rfmtdouble(avg_pdiscount,"--&.&&",s_avg_pdiscount);
     cm_buf_put("%s",s_avg_pdiscount);

     cm_buf_put("%s",s_dentry);
     cm_buf_put("%s",itmp_policy);
     cm_buf_put("%s",nequip_azpg);
     cm_buf_put("%s",napplicant);
     cm_buf_put("%s %s %s ", survey_num, bound_num, ibound);
     cm_buf_put("%s %s %s %s ", irate_type, iroute_comm, icomm_obj, sFtypeSp);
     cm_buf_put("%s",nsign);

     
     /* ���O 1:�w�鵲 */
     cm_buf_put("%s","1");

     /*�Ӹ�P�_*/
     cm_buf_put("%s",o_sDeny_msg);
     
     /*�u�l�H�覡�v�Ƶ����� */
     cm_buf_put("%s",sMailRemark);
     cm_buf_put("%s",s_ftrans_trade); /* �u���T�Y�ɶǿ��v���O */
     cm_buf_put("%s",s_dtrans_trade); /* �u���T�Y�ɶǿ��v�ǿ�ɶ� */
     
     /* �q�l�O���T */
     sprintf(stmt,"SELECT feply \
                     FROM %s:ply_relation \
                    WHERE ipolicy = '%s' ;",sFullName, irelative_ply);
     $PREPARE feply_cur FROM $stmt;
     $EXECUTE feply_cur INTO $tmpp_feply;
     
     if(fcard_class[0] == '1')
     {
     	strcpy(feply1,tmp_feply);
     	strcpy(feply2,tmpp_feply);
     }
     else
     {
     	strcpy(feply1,tmpp_feply);
     	strcpy(feply2,tmp_feply);
     }
     
     cm_buf_put("%s %s %s %s", feply1, feply2, aemail_eply, dcreate_eply);
     
     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     return api_OKComplete;

errexit:
     printf("stmt=[%s]\n",stmt);
     printf("SOLERR:%s\n",sqlca.sqlerrm);
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*********************************************************************/
/* NEED CHECK FOR TABLE CHANGE AND CALCULATE NEED RENEW              */
/*********************************************************************/
/***** �ߴڰO�� *****/
long car1001_multiple_queryl(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5], sFullName[20], stmt[1024], sDBSite[3];
 /* end of standard host var */

 /* table policy,assured_vs_ply */
 $char ipolicy[POLICY_NUM_1];
 $date Dply_begin;
 $long dply_begin;
 $char Iengine[21],Itag[CA_TAG_NUM], Fcard_class[2];
 $char Inumber[21], iassured[13],nassured[41];

 /* self defined data */
 char fyear[3];
 char s_qdmg[3][10], s_qlia[3][10], s_mdmg[3][10], s_mlia[3][10];
 long   qdmg[3]    ,   qlia[3]    ,   mdmg[3]    ,   mlia[3];
 char s_qdmg_acc[10], s_qlia_acc[10];
 long   qdmg_acc    ,   qlia_acc;
 char tmp_pdmg_acc[20], tmp_plia_acc[20];
 double   pdmg_acc    ,     plia_acc;

 /* standard defined data */
 char tmpbuf[4000];
 int i, repbuf_len=0, tmp_len=0, replycnt=0, fFound;
 int lRtnCode1, lRtnCode2;

 cm_buf_get("%s",DBName);
 cm_buf_get("%s %s",ipolicy, sUserid);

 if(db_select(DBName) == False)
   return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
 strncpy(DBName,ipolicy,2); DBName[2]='\0';
 strcpy(sFullName, get_car_full_db(ipolicy));

 $WHENEVER SQLERROR GOTO errexit;
 $SELECT  itag,  iengine,  fcard_class, iassured, nassured
    INTO $Itag, $Iengine, $Fcard_class, $iassured, $nassured
    FROM assured_vs_ply
   WHERE ipolicy = $ipolicy;
 if (SQLCODE == SQLNOTFOUND)
    return exitsub(reply,M_CA_NASSURED_VS_PLY)?M_CA_NASSURED_VS_PLY:apiRC;

 /* �Ӹ갱���ˮ� add by sylvia 103.02.17 (1020924002_C2) */
     strcpy(o_sDeny_msg," ");
        iCountDeny=0;
        iCountFunsale=0;
        $select count(*),funrenew_ins[1,1],funquery_ins[1,1],fdelete_ins[1,1]
            into $iCountDeny,$funrenew,$funquery,$fundelete
            from cm_personal_deny
           where iassured = $iassured
             and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
             and ddeny <= today
             and (dexpire is null or dexpire >= today)
             GROUP BY 2,3,4;
             
             rtncode = cm_chk_personal(iassured, 'C' , '*' , o_sDeny_msg, o_sFply_chk);
             
        if(iCountDeny > 0)
        {
            iUnDeny=0;
            /*�bcu_code_data.itype=CK ���]�w��,�i�H�d��*/ 
            $select count(*) into $iUnDeny
               from cu_code_data where itype = 'CK' and icode = $sUserid;
            if (iUnDeny == 0)
         	{
	         	if (strcmp(trim(funrenew),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_RENEW) ? M_CA_PERSONAL_DENY_RENEW :apiRC;
	            else if (strcmp(trim(funquery),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_QUERY) ? M_CA_PERSONAL_DENY_QUERY :apiRC;
	            else if (strcmp(trim(fundelete),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_DELETE) ? M_CA_PERSONAL_DENY_DELETE :apiRC;
	            else 
	            	return exitsub(reply,M_CA_PERSONAL_DENY) ? M_CA_PERSONAL_DENY :apiRC;
         	}
            else
	    		rtncode = cm_chk_personal(iassured, 'C' , '*' , o_sDeny_msg, o_sFply_chk);
        }

 printf("==>query assured_vs_ply success!!\n");
 printf("tag[%s],eng[%s],fcrd_cls[%s]\n",Itag,Iengine,Fcard_class);

 if(Itag[0]==' ' || Itag[0]=='\0') strcpy(Inumber,Iengine);
    else strcpy(Inumber,Itag);

 sprintf(stmt, "SELECT dply_begin FROM %s:ply_relation \
                 WHERE ipolicy = '%s'", sFullName, ipolicy);
 $PREPARE ql_ply FROM $stmt;
 $DECLARE ql_ply_cur CURSOR FOR ql_ply;
 $OPEN    ql_ply_cur;
 $FETCH   ql_ply_cur INTO $Dply_begin;
 if (SQLCODE == SQLNOTFOUND)
     return exitsub(reply,M_CA_NPOLICY) ? M_CA_NPOLICY : apiRC;
 $CLOSE ql_ply_cur;
 $FREE  ql_ply_cur;
 printf("==>query policy success!!\n");

 /************************************************************/
 /* NEED CHECK ca_accident_record SELECT DATA IS NEED MODIFY */
 /************************************************************/
 fFound=ca_accident_record(DBName,Inumber,Dply_begin,Fcard_class,
        qdmg,qlia,mdmg,mlia,&qdmg_acc,&qlia_acc,&pdmg_acc,&plia_acc,fyear);
 if(fFound!=M_CM_OK) return fFound;

 printf("ca_accident:[%s]\n",fyear);
 /**�P�_�L�ӫO�~��**/
 for(i=0;i<3;i++){
   if (fyear[i]=='Y'){
     strcpy(s_qdmg[i],itoa(qdmg[i])); strcpy(s_mdmg[i],itoa(mdmg[i]));
     strcpy(s_qlia[i],itoa(qlia[i])); strcpy(s_mlia[i],itoa(mlia[i]));
   }else{
     strcpy(s_qdmg[i]," "); strcpy(s_mdmg[i]," ");
     strcpy(s_qlia[i]," "); strcpy(s_mlia[i]," ");
     continue;
   }
 }

 /**�P�_�O�_���O���n�I��**/
 if (Fcard_class[0]=='1'){      /*�j��*/
      lRtnCode1=accchk_plyins(ipolicy, "21");
      if (lRtnCode1==FALSE){
         for(i=0;i<3;i++){
            strcpy(s_qdmg[i]," "); strcpy(s_mdmg[i]," ");
            strcpy(s_qlia[i]," "); strcpy(s_mlia[i]," ");
         }
      }
 }else{ /*���N*/
      lRtnCode1=accchk_plyins(ipolicy, "01"); /*���^*/
      lRtnCode2=accchk_plyins(ipolicy, "05");
      if ((lRtnCode1==FALSE)&&(lRtnCode2==FALSE)){
         for(i=0;i<3;i++){
            strcpy(s_qdmg[i]," "); strcpy(s_mdmg[i]," ");
         }
      }
      lRtnCode1=accchk_plyins(ipolicy, "31"); /*���d*/
      lRtnCode2=accchk_plyins(ipolicy, "32");
      if ((lRtnCode1==FALSE)&&(lRtnCode2==FALSE)){
         for(i=0;i<3;i++){
            strcpy(s_qlia[i]," "); strcpy(s_mlia[i]," ");
         }
      }
 }

 strcpy(s_qdmg_acc,itoa(qdmg_acc));
 strcpy(s_qlia_acc,itoa(qlia_acc));
 rfmtdouble(pdmg_acc, "----&.&&", tmp_pdmg_acc);
 rfmtdouble(plia_acc, "----&.&&", tmp_plia_acc);

 /**�P�_�O�_�T�~�Ҫť�**/
 lRtnCode1=TRUE; lRtnCode2=TRUE;
 for(i=0;i<3;i++){
    if (s_qdmg[i][0]!=' ') {lRtnCode1=FALSE;}
    if (s_qlia[i][0]!=' ') {lRtnCode2=FALSE;}
 }
 if (lRtnCode1==TRUE)
    { strcpy(s_qdmg_acc," "); strcpy(tmp_pdmg_acc," "); }
 if (lRtnCode2==TRUE)
    { strcpy(s_qlia_acc," "); strcpy(tmp_plia_acc," "); }

 printf("inum=[%s]\n", Inumber);
 printf("qdmg=[%s][%s][%s]\n", s_qdmg[0], s_qdmg[1], s_qdmg[2]);
 printf("qlia=[%s][%s][%s]\n", s_qlia[0], s_qlia[1], s_qlia[2]);
 printf("mdmg=[%s][%s][%s]\n", s_mdmg[0], s_mdmg[1], s_mdmg[2]);
 printf("mlia=[%s][%s][%s]\n", s_mlia[0], s_mlia[1], s_mlia[2]);
 printf("[%s][%s][%s][%s]\n",s_qdmg_acc,s_qlia_acc,tmp_pdmg_acc,tmp_plia_acc);

 cm_buf_init(ReplyBuf);
 cm_buf_res_msg();
 cm_buf_put_msg(M_CM_OK);
 cm_buf_put("%s", Inumber);
 cm_buf_put("%s %s %s", s_qdmg[0], s_qdmg[1], s_qdmg[2]);
 cm_buf_put("%s %s %s", s_qlia[0], s_qlia[1], s_qlia[2]);
 cm_buf_put("%s %s %s", s_mdmg[0], s_mdmg[1], s_mdmg[2]);
 cm_buf_put("%s %s %s", s_mlia[0], s_mlia[1], s_mlia[2]);
 cm_buf_put("%s %s %s %s",s_qdmg_acc,s_qlia_acc,tmp_pdmg_acc,tmp_plia_acc);

 /*�Ӹ�P�_*/
 cm_buf_put("%s",o_sDeny_msg);
 cm_buf_put("%s",nassured);
 cm_buf_put("%s",iassured);
 

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
     return apiRC;
 return api_OKComplete;

errexit:
  printf("stmt=[%s], SQLERR=[%s]\n",stmt, sqlca.sqlerrm);
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/**********************************************/
long Check_reject_client(reply)
serverReply reply;
{
$ char nassured[41],iengine[21],itag[CA_TAG_NUM],ilicense[11],ibody[21];
$ char assuredn[41],engine[21],tagnum[CA_TAG_NUM],license[11],body[21];
$ char bpolicy[19];
$ char FullDBx[21],dbx[3];
$ char st_buf[300];
$ char DBName[5];

  int  rej_rtn=1,tmp_len=0;
/* 861201, ateng */
  cm_buf_get("%s",DBName);
  cm_buf_get("%s",bpolicy);

/* 861201, ateng */
 if(db_select(DBName) == False)
   return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

$ WHENEVER SQLERROR GOTO errexit;

    strncpy(dbx,bpolicy,2); dbx[2]='\0';
    strcpy(FullDBx, get_car_full_db(bpolicy));
{/***************
    if (FullDBx[0]!='\0'){
     sprintf(st_buf,"SELECT %s FROM %s:policy WHERE ipolicy='%s'",
                 "nassured,itag,ibody,ilicense,iengine",
                 FullDBx,bpolicy);
     $PREPARE rej_x1 FROM $st_buf;
     $DECLARE rej_1 CURSOR FOR rej_x1;
     $OPEN rej_1;
     $FETCH rej_1 INTO $assuredn,$tagnum,$body,$license,$engine;
     if (SQLCODE==SQLNOTFOUND) {printf("no found\n");rej_rtn=1;}
     $CLOSE rej_1;
     $FREE  rej_1;
    }
    sprintf(st_buf,"SELECT nassured,ilicense,itag,iengine,ibody FROM reject_client");
    $PREPARE rej_2x FROM $st_buf;
    $DECLARE rej_2 CURSOR FOR rej_2x;
    $OPEN rej_2;
    while (1)
    {
$    FETCH rej_2 INTO $nassured,$ilicense,$itag,$iengine,$ibody;
     if (SQLCODE==SQLNOTFOUND) break;
     trim_tail_white(nassured); trim_tail_white(ilicense);
     trim_tail_white(itag);     trim_tail_white(iengine);
     trim_tail_white(ibody);

     trim_tail_white(assuredn); trim_tail_white(license);
     trim_tail_white(tagnum);   trim_tail_white(engine);
     trim_tail_white(body);

     if ((EQUAL(nassured,assuredn) && nassured[0]!=' ' && assuredn[0]!=' ' &&
          nassured[0]!='\0' && assuredn[0]!='\0' &&
          EQUAL(ilicense,license) && ilicense[0]!=' ' && license[0]!=' ' &&
          ilicense[0]!='\0' && license[0]!='\0' &&
          strcmp(ilicense,"AAAAAAAAAA")!=0) ||
         (EQUAL(itag,tagnum) && itag[0]!=' ' && tagnum[0]!=' ' &&
          itag[0]!='\0' && tagnum[0]!='\0') ||
         (EQUAL(iengine,engine) && iengine[0]!=' ' && engine[0]!=' ' &&
          iengine[0]!='\0' && engine[0]!='\0') ||
         (EQUAL(ibody,body) && ibody[0]!=' ' && body[0]!=' ' &&
          body[0]!='\0' && body[0]!='\0')) {
            printf(">>>>>>>>> equal reject_client\n");
            rej_rtn=0;
            break;
       }
    }
$CLOSE rej_2; $FREE  rej_2;
******************/}
$WHENEVER SQLERROR CONTINUE;

 cm_buf_init(ReplyBuf);
 cm_buf_put("%l",M_CM_OK);
/**********
 if(rej_rtn==0)
   cm_buf_put("%s","R");    ** reject_client **
 else
***********/
   cm_buf_put("%s","N");

 tmp_len=cm_buf_len(ReplyBuf);
 if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/* �ˬduser�O�_���v���d�߸�ơA�^�Ȣ������v�� */
long check_user_inspect(reply)
serverReply reply;
{
$ char iofficer[11], userid[11];
$ char ipolicy[21], RouteCAJ[2], sIquota1[7], sIquota2[7], sGroup[7];
$ char FullDBx[21],dbx[3];
$ char st_buf[1000];
$ char DBName[5];
$ char ply1[POLICY_NUM_1], ply2[POLICY_NUM_2];
  $char   sIquotax1[7],sIquotax2[7];
$char IsPorject[2];	/* �O�_���M�ץ�:Y�M�ץ� N:�D�M�ץ� add by sylvia 102.12.11 (1021122001_C1) */

    int  tmp_len=0, rc;

    cm_buf_get("%s",DBName);
    cm_buf_get("%s %s",ipolicy, userid);

    if(db_select(DBName) == False)
       return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    $WHENEVER SQLERROR GOTO errexit;

    strncpy(dbx,ipolicy,2); dbx[2]='\0';
    strcpy(FullDBx, get_car_full_db(ipolicy));

    /* �M�ץ�P�_: W�g���H�g��(H�g�춷�ư�H0-H29) modify by sylvia 102.12.11 (1021122001_C1)
                   �s�WN�g��(�~�Ȩӷ���E)(1030630002_C4) */
    sprintf(st_buf,"SELECT a.iofficer, "
                   "       decode(decode(b.iroute[1,2],'CA','T','F'),'T','T', "
                   "               decode(b.iroute[1,1], 'J','T','F')), "
                   "       case when iofficer[1,1] = 'W' then 'Y' "
                   "            when iofficer[1,1] = 'H' and iofficer[2,2] not in ('0','1','2') then 'Y' "
                   "            when iofficer[1,1] = 'N' and a.iresource = 'E' then 'Y' else 'N' end "
                   "         FROM %s:ply_relation a, %s:policy b "
                   " WHERE a.ipolicy = b.ipolicy and a.ipolicy='%s'",
                   FullDBx,FullDBx, ipolicy);
    $PREPARE prep1 FROM $st_buf;
    $EXECUTE prep1 INTO $iofficer, $RouteCAJ, $IsPorject;
    $FREE prep1;

    printf("iofficer=[%s] RouteCAJ=[%s] IsPorject=[%s]\n",iofficer,RouteCAJ,IsPorject);

    /* if( iofficer[0] == 'W') */
    if (strcmp(IsPorject,"Y") == 0)
    {
        strncpy(ply1, ipolicy, CAR_POLICY_LEN);
        ply1[CAR_POLICY_LEN]='\0';

        strncpy(ply2, ipolicy+CAR_POLICY_LEN, CAR_TARGET_LEN);
        ply2[CAR_TARGET_LEN]='\0';

        if (ply2[0]=='\0' || ply2[0]==' ') strcpy(ply2," ");

        /* �M�ץ���A��g��N�� */
        sprintf( st_buf, "select b.iofficer"
                         "  from %s:ply_relation a, ca_promote_officer b, officer c, officer d"
                         " where a.iofficer = b.iofficer_ori"
                         "   and a.ibig_office = b.ibig_office"
                         "   and b.iofficer = c.iofficer"
                         "   and c.ileader = d.iofficer"
                         "   and a.ipolicy = '%s'", FullDBx, ipolicy);

        printf("st_buf[%s]\n", st_buf);
        $PREPARE prep2 FROM $st_buf;
        $EXECUTE prep2 INTO $iofficer;

        if( SQLCODE == SQLNOTFOUND)
        {
            /* return exitsub(reply,M_CA_W_A) ? SQLCODE : apiRC; �M�ץ��A��g��N���䤣�� */
        }
        $FREE prep2;
    }
    printf("iofficer[%s]\n", iofficer);
    rc = cm_get_user_inspect( userid, iofficer, "C");

    printf("------ rc=[%d]\n",rc);
    /* �]���c�q�T�@��(646300)�P���c�q�T�G��(646400)���ब�ݨ��ӫO�N����
						   �G�ק�P�_����,�Ϥ��c�@��P���c�G��i�H���ݸ��  modify by sylvia 102.01.07 */
    if ((rc == 0) && ((strcmp(RouteCAJ,"T") == 0) || (iofficer[0] == 'Z')))
    {
      $SELECT d.iquota, e.group3,
              case when d.iquota[1,4] in ('6462','6463','6464') then '646X00' else d.iquota end
       INTO $sIquota1, $sGroup, $sIquotax1
       FROM officer a, officer b,
            sa_branch_type c,
            officer d, sa_branch_type e
      WHERE a.iofficer=$iofficer
        AND a.ileader = b.iofficer
        AND b.iquota = c.ibranch
        AND b.ileader = d.iofficer
        AND d.iquota = e.ibranch;


      $select iquota, case when iquota[1,4] in ('6462','6463','6464') then '646X00' else iquota end
        into  $sIquota2, $sIquotax2
        from officer where iofficer = $userid;


     printf("sIquota2=[%s]\n",sIquota2);

       if(strncmp(sIquota2, sIquota1, 4) == 0)
         rc = 1;
       else if (strncmp(sIquotax2, sIquotax1, 4) == 0)
       {
       	 printf("----A. ���c�q�T�@��B���c�q�T�G�� ----- \n");
       	 rc = 1;		/* ���c�q�T�@��B���c�q�T�G�� */
			 }
       else
         rc = 0;
    }

    printf("******** rc = [%d]\n",rc);

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %d", M_CM_OK, rc);

    tmp_len=cm_buf_len(ReplyBuf);
    if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/*****************************************************************/
/*****************************************************************/

split_ply(ipolicy,ao_policy1,ao_policy2)
 char *ipolicy,*ao_policy1,*ao_policy2;
{
     if (strlen(rtrim(ipolicy)) <= CAR_POLICY_LEN)
     {
        strcpy(ao_policy1,ipolicy);
        strcpy(ao_policy2," ");
     } else {
        strncpy(ao_policy1,ipolicy,CAR_POLICY_LEN);
        ao_policy1[CAR_POLICY_LEN]='\0';
        strncpy(ao_policy2,ipolicy+CAR_POLICY_LEN,CAR_TARGET_LEN);
        ao_policy2[CAR_TARGET_LEN] ='\0';
        if (ao_policy2[0]=='\0') strcpy(ao_policy2," ");
     }
   return M_CM_OK;
}/*split_ply*/
/*****************************************************************/

int accchk_plyins(sIpolicy, sIins_type)
$char *sIpolicy;
{
  $char qIins_type[INSURANCE_TYPE];
  short int ffount;
  $char DBName[5], sFullName[20], stmt[1024], sDBSite[3];

$ WHENEVER SQLERROR GOTO errexit;

  strncpy(DBName,sIpolicy,2); DBName[2]='\0';
  strcpy(sFullName, get_car_full_db(sIpolicy));

  printf("===>[into accchk]:ply[%s],ins[%s],",sIpolicy, sIins_type);
  ffount=FALSE;
  sprintf(stmt, "SELECT iins_type \
                   FROM %s:ply_ins_type \
                   WHERE ipolicy = '%s' ", sFullName, sIpolicy);
  $PREPARE plyins FROM $stmt;
  $DECLARE plyins_cur CURSOR FOR plyins;
  $OPEN plyins_cur;
  for(;;){
     $FETCH plyins_cur INTO $qIins_type;
     if (SQLCODE==SQLNOTFOUND) break;

     printf("[%s]", qIins_type);
     strcpy(sIins_type, trim(sIins_type));
     strcpy(qIins_type, trim(qIins_type));
     /* if (strcmp(trim(sIins_type), trim(qIins_type))==0) */
     if (strcmp(sIins_type, qIins_type)==0)
     {
        ffount=TRUE;
        break;
     }
  }
  $CLOSE plyins_cur;
  $FREE  plyins_cur;
  printf(",ffount[%d]\n", ffount); /**TRUE(1):�����O�I��**/
  return ffount;

errexit:
  printf("stmt=[%s], SQLERR=[%s]\n",stmt, sqlca.sqlerrm);
  return SQLCODE;
}/*accchk_plyins*/


/*********************************************************************/
/* NO NEED MODIFY FOR CM_BUF_PUT JUST CHECK FOR TABLE FIELD CHANGE   */
/*********************************************************************/
long car1001_multiple_querym(reply)
serverReply reply;
{ /*�j�O��O�� */
 /* standard defined host variables */
 $char DBName[5], sFullName[20], stmt[1024], sTmpBuf[3],tmpbuf[4000];

 /* table branch,settlement,policy */
 $char DBsite[3],bIpolicy[POLICY_NUM_1],tmp_bIpolicy[POLICY_NUM_1];
 $char Ipolicy[POLICY_NUM_1];
 $char iassured[13];
 long Mtot_after,Mtot_before;
 long sum_Mtot_after,sum_Mtot_before;
 $long Mins_prem, Mprem;

 /* standard defined data */
 int fFound;
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;

 /* self defined data */
 $int icount;
 char target[CAR_TARGET_LEN];
 int spos;

 icount=0;count=0;

 cm_buf_get("%s",DBName);
 cm_buf_get("%s %s",bIpolicy, sUserid);

 if(db_select(DBName) == False)
    return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

/*********************
 cm_buf_init(ReplyBuf);
 cm_buf_res_msg();
 cm_buf_res_count();
**********************/

 strncpy(DBsite, bIpolicy, 2); DBsite[2]='\0';
 strcpy(sFullName, get_car_full_db(bIpolicy));
 strcpy(tmp_bIpolicy, bIpolicy); strcat(tmp_bIpolicy,"*");

 $WHENEVER SQLERROR GOTO errexit;

 sprintf(stmt, "SELECT count(*) FROM %s:policy WHERE ipolicy matches '%s'",
              sFullName, tmp_bIpolicy);
 $PREPARE mply1 FROM $stmt;
 $DECLARE mply1_cursor CURSOR FOR mply1;
 $OPEN  mply1_cursor;
 $FETCH mply1_cursor INTO $icount;
 $CLOSE mply1_cursor;
 $FREE  mply1_cursor;

 if (icount<=1)
    return exitsub(reply,M_CM_NOT_FOUND) ? M_CM_NOT_FOUND : apiRC;

 printf("icount[%ld],tmp_ply[%s]\n",icount, tmp_bIpolicy);
 /* cm_buf_put("%l",icount); */

 sum_Mtot_after=sum_Mtot_before=0;

 sprintf(stmt, "SELECT ipolicy,iassured FROM %s:policy WHERE ipolicy matches '%s'",
         sFullName, tmp_bIpolicy);
 $PREPARE mply FROM $stmt;
 $DECLARE mply_cursor CURSOR FOR mply;
 $OPEN mply_cursor;
 for(;;){
     $FETCH mply_cursor INTO $Ipolicy,$iassured;
     if (SQLCODE==SQLNOTFOUND) break;

     /* �Y�Q�O�I�HQ201639145,��ܯS��ĵ�i�T��4450; Modified by Julia Han in 2007/06/04 */
        if (strcmp(trim(iassured),"Q201639145") == 0)
        {
        		return exitsub(reply,M_CA_IASSURED_WARNING) ? M_CA_IASSURED_WARNING :apiRC;
        	}

     /* �Ӹ갱���ˮ� add by sylvia 103.02.17 (1020924002_C2) */
        strcpy(o_sDeny_msg," ");
        iCountDeny=0;
        iCountFunsale=0;
        $select count(*),funrenew_ins[1,1],funquery_ins[1,1],fdelete_ins[1,1]
            into $iCountDeny,$funrenew,$funquery,$fundelete
            from cm_personal_deny
           where iassured = $iassured
             and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
             and ddeny <= today
             and (dexpire is null or dexpire >= today)
             GROUP BY 2,3,4;
             
        if(iCountDeny > 0)
        {
            iUnDeny=0;
            /*�bcu_code_data.itype=CK ���]�w��,�i�H�d��*/ 
            $select count(*) into $iUnDeny
               from cu_code_data where itype = 'CK' and icode = $sUserid;
            if (iUnDeny == 0)
         	{
	         	if (strcmp(trim(funrenew),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_RENEW) ? M_CA_PERSONAL_DENY_RENEW :apiRC;
	            else if (strcmp(trim(funquery),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_QUERY) ? M_CA_PERSONAL_DENY_QUERY :apiRC;
	            else if (strcmp(trim(fundelete),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_DELETE) ? M_CA_PERSONAL_DENY_DELETE :apiRC;
	            else 
	            	return exitsub(reply,M_CA_PERSONAL_DENY) ? M_CA_PERSONAL_DENY :apiRC;
         	}
        }

     cm_buf_init(tmpbuf);
     if( count == 0 ) {
       cm_buf_res_msg();
       cm_buf_res_count();
     }
     spos=strlen(rtrim(Ipolicy));
     memcpy(target, &Ipolicy[spos-CAR_TARGET_LEN], CAR_TARGET_LEN);
     target[CAR_TARGET_LEN]='\0';
     printf("spos[%ld],Ipolicy[%s],target[%s]\n",spos,Ipolicy,target);

     Mtot_after=Mtot_before=0;

     sprintf(stmt, "SELECT sum(mins_premium), sum(mprem) \
                      FROM %s:ply_ins_type \
                     WHERE ipolicy matches '%s'",
             sFullName, Ipolicy);
     $PREPARE mplyins FROM $stmt;
     $DECLARE mplyins_cursor CURSOR FOR mplyins;
     $OPEN mplyins_cursor;
     $FETCH mplyins_cursor INTO $Mins_prem, $Mprem;
     $CLOSE mplyins_cursor;
     $FREE  mplyins_cursor;

     sum_Mtot_after +=Mins_prem;
     sum_Mtot_before +=Mprem;

 cm_buf_put("%s %l %l",target, Mprem, Mins_prem);
printf("sum_after[%ld],sum_before[%ld]\n",sum_Mtot_after,sum_Mtot_before);
 tmp_len = cm_buf_len(tmpbuf);
 if( tmp_len + repbuf_len < 3000 ) {   /* buffer size less than 4K */
     memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
     repbuf_len += tmp_len;
     count++;
 } else {                      /* more than 4K, send to client side */
     cm_buf_init(ReplyBuf);
     cm_buf_put_msg(M_CM_OK);
     cm_buf_put_count(count);
     if(SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False) {
       $CLOSE q_cur;
       return apiRC;
     } else {  /* clear ReplyBuf and count to start all over again */
       replycnt++;
       if(replycnt == 8) { /* more than 30K, client cannot display,error */
          cm_buf_init(ReplyBuf);
          cm_buf_put("%l",M_CM_OUT_SPACE);
          tmp_len = cm_buf_len(ReplyBuf);
          if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
            return apiRC;
            return M_CM_OUT_SPACE;
          }
          ReplyBuf[0] = '\0';
          count = 0;
          cm_buf_init(ReplyBuf);
          cm_buf_res_msg();           /* reserve for MsgCode and count */
          cm_buf_res_count();

          cm_buf_put("%s %l %l",target, Mprem, Mins_prem);
          repbuf_len = cm_buf_len(ReplyBuf);
          count++;
       }
    }
/***************************
     sum_Mtot_after +=Mtot_after;
     sum_Mtot_before+=Mtot_before;
****************************/
 } /* end of policy */
 $CLOSE mply_cursor;
 $FREE  mply_cursor;

printf("before put in total\n");
 cm_buf_put("%l %l",sum_Mtot_before, sum_Mtot_after);

 tmp_len = cm_buf_len(tmpbuf);
 count++;
/****************************
 cm_buf_put_msg(M_CM_OK);
 cm_buf_put_count(icount);
 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
    return apiRC;
 else
    return api_OKComplete;
****************************/
   if(count > 0) {  /* break out, at least one record is selected */
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if(SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
         return apiRC;
      return api_OKComplete;
   }
   else            /* break out, not any row is found */
   {
      return exitsub(reply,M_CA_NBIG_OFFICE) ? M_CA_NBIG_OFFICE : apiRC;
   }

errexit:
   printf("SQLERR:%s\n",sqlca.sqlerrm);
   printf("stmt=[%s]\n",stmt);
   return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*********************************************************************/
long car1001_multiple_queryn(reply)
serverReply reply;
{ /*�j�O���l�O�� */
 /* standard defined host variables */
 $char DBName[5], sFullName[20], stmt[1024], sTmpBuf[3];
 /* table branch,settlement,policy */
 $char DBsite[3],bIpolicy[POLICY_NUM_1],tmp_bIpolicy[POLICY_NUM_1];
 $char Ipolicy[POLICY_NUM_1];
 $char iassured[13];
 long Mtot_after,Mtot_before;
 long sum_Mtot_after,sum_Mtot_before;
 $long Mins_prem, Mprem;

 /* standard defined data */
 int tmp_len, fFound;

 /* self defined data */
 $int icount;
 char target[13];
 int spos;

 cm_buf_get("%s",DBName);
 cm_buf_get("%s %s",bIpolicy, sUserid);

 if(db_select(DBName) == False)
    return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

 cm_buf_init(ReplyBuf);
 cm_buf_res_msg();
 cm_buf_res_count();

 strncpy(DBsite, bIpolicy, 2); DBsite[2]='\0';
 strcpy(sFullName, get_car_full_db(bIpolicy));
 strcpy(tmp_bIpolicy, bIpolicy); strcat(tmp_bIpolicy,"*");

 $WHENEVER SQLERROR GOTO errexit;

 sprintf(stmt, "SELECT count(*) FROM %s:policy WHERE ipolicy matches '%s'",
              sFullName, tmp_bIpolicy);
 $PREPARE mply2 FROM $stmt;
 $DECLARE mply2_cursor CURSOR FOR mply2;
 $OPEN  mply2_cursor;
 $FETCH mply2_cursor INTO $icount;
 $CLOSE mply2_cursor;
 $FREE  mply2_cursor;

 if (icount<=1)
    return exitsub(reply,M_CM_NOT_FOUND) ? M_CM_NOT_FOUND : apiRC;

 printf("icount[%ld],tmp_ply[%s]\n",icount, tmp_bIpolicy);
 /* cm_buf_put("%l",icount); */

 sum_Mtot_after=sum_Mtot_before=0;

 sprintf(stmt, "SELECT ipolicy, iassured \
                  FROM %s:policy \
                 WHERE ipolicy matches '%s'", sFullName, tmp_bIpolicy);

 $PREPARE mply3 FROM $stmt;
 $DECLARE mply3_cursor CURSOR FOR mply3;
 $OPEN mply3_cursor;
 for(;;){
     $FETCH mply3_cursor INTO $Ipolicy,$iassured;
     if (SQLCODE==SQLNOTFOUND) break;

     /* �Y�Q�O�I�HQ201639145,��ܯS��ĵ�i�T��4450; Modified by Julia Han in 2007/06/04 */
        if (strcmp(trim(iassured),"Q201639145") == 0)
        {
        		return exitsub(reply,M_CA_IASSURED_WARNING) ? M_CA_IASSURED_WARNING :apiRC;
        	}

     /* �Ӹ갱���ˮ� add by sylvia 103.02.17 (1020924002_C2) */
        strcpy(o_sDeny_msg," ");
        iCountDeny=0;
        iCountFunsale=0;
        $select count(*),funrenew_ins[1,1],funquery_ins[1,1],fdelete_ins[1,1]
            into $iCountDeny,$funrenew,$funquery,$fundelete
            from cm_personal_deny
           where iassured = $iassured
             and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
             and ddeny <= today
             and (dexpire is null or dexpire >= today)
             GROUP BY 2,3,4;
             
             rtncode = cm_chk_personal(iassured, 'C' , '*' , o_sDeny_msg, o_sFply_chk);
             
        if(iCountDeny > 0)
        {
            iUnDeny=0;
            /*�bcu_code_data.itype=CK ���]�w��,�i�H�d��*/ 
            $select count(*) into $iUnDeny
               from cu_code_data where itype = 'CK' and icode = $sUserid;
            if (iUnDeny == 0)
         	{
	         	if (strcmp(trim(funrenew),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_RENEW) ? M_CA_PERSONAL_DENY_RENEW :apiRC;
	            else if (strcmp(trim(funquery),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_QUERY) ? M_CA_PERSONAL_DENY_QUERY :apiRC;
	            else if (strcmp(trim(fundelete),"1") == 0)
	            	return exitsub(reply,M_CA_PERSONAL_DENY_DELETE) ? M_CA_PERSONAL_DENY_DELETE :apiRC;
	            else 
	            	return exitsub(reply,M_CA_PERSONAL_DENY) ? M_CA_PERSONAL_DENY :apiRC;
         	}
            else
	    		rtncode = cm_chk_personal(iassured, 'C' , '*' , o_sDeny_msg, o_sFply_chk);
        }

     spos=strlen(rtrim(Ipolicy));
     memcpy(target, &Ipolicy[spos-4], 4); target[4]='\0';
     printf("spos[%ld],target[%s]\n",spos, target);

     Mtot_after=Mtot_before=0;

     sprintf(stmt, "SELECT mins_premium, mprem \
                      FROM %s:ori_ins_type \
                     WHERE ipolicy = '%s'",
             sFullName, Ipolicy);
     $PREPARE mplyins3 FROM $stmt;
     $DECLARE mplyins3_cursor CURSOR FOR mplyins3;
     $OPEN mplyins3_cursor;
     for(;;){
        $FETCH mplyins3_cursor INTO $Mins_prem, $Mprem;
        if (SQLCODE==SQLNOTFOUND) break;

        printf("Mins_prem[%ld],Mprem[%ld]\n",Mins_prem, Mprem);
        Mtot_after +=Mins_prem;
        Mtot_before+=Mprem;
     }
     $CLOSE mplyins3_cursor;
     $FREE  mplyins3_cursor;

     cm_buf_put("%s %l %l",target, Mtot_before, Mtot_after);
     sum_Mtot_after +=Mtot_after;
     sum_Mtot_before+=Mtot_before;
 }
 $CLOSE mply3_cursor;
 $FREE  mply3_cursor;

 cm_buf_put_msg(M_CM_OK);
 cm_buf_put_count(icount);

 /*�Ӹ�P�_*/
 cm_buf_put("%s",o_sDeny_msg);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
    return apiRC;
 else
    return api_OKComplete;

errexit:
   printf("SQLERR:%s\n",sqlca.sqlerrm);
   printf("stmt=[%s]\n",stmt);
   return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}


/***** �������r���d�� *****/
long car1001_multiple_queryo(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table policy */
 $char ipolicy[19],itag[CA_TAG_NUM],nassured[41],iassured[13];
 $char sdply_begin[11],sdply_end[11],iofficer[11],nofficer[11];
 $long dply_begin,dply_end;
 $char sFullName[20],stmt[1024];
 /* end of policy */

 /* standard defined data */
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0,fFound;
 /* end of standard data */
 
 $char fcheckClose[2], stmt_1[4096];

 /* self defined data */
 /* end of self data */

 ipolicy[0]=itag[0]=nassured[0]=iassured[0]=fcheckClose[0]=0;

 cm_buf_get("%s",DBName);
 cm_buf_get("%s %s %s",iassured, sUserid,fcheckClose);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
    return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
    	
   printf("***** fcheckClose[%s] *****\n", fcheckClose);
   /* fcheckClose 0:���鵲, 1:�w�鵲 */
   if (strcmp(trim(fcheckClose), "0") == 0)
   {
   	  rtncode = car1001_query_no_dplyclose("O", iassured);
   	  if (rtncode != M_CM_OK) return rtncode;
   	  	
   	  strcpy(stmt_1, sStmt);
   }
   else
   {
      sprintf(stmt_1, "SELECT ipolicy, iassured, nassured, itag \
                         FROM assured_vs_ply \
                        WHERE iassured = '%s'\
                        ORDER BY ipolicy;", iassured);
                       /* AND substr(ipolicy,6,2) <> 'VW'; *//* Get rid of 'VW' data */
   }
     
   $PREPARE ass_curn_cursor FROM :stmt_1;
   $DECLARE ass_curn CURSOR FOR ass_curn_cursor;
   $OPEN ass_curn;

 for(;;)
 {
    $FETCH ass_curn INTO $ipolicy, $iassured, $nassured, $itag;
    if (SQLCODE != 0) break;

    /* car9802052 �ھګO�渹��X��Ʈw,�ç�X�ӫO�渹���_����H�θg��N�� */
       strcpy(sFullName, get_car_full_db(ipolicy));

       sprintf(stmt, "SELECT a.dply_begin, a.dply_end, a.iofficer, \
                      (select nname from officer where iofficer = a.iofficer) \
                      FROM %s:ply_relation a WHERE ipolicy = '%s'", sFullName, ipolicy);
printf("stmt[%s]\n",stmt);
       EXEC SQL PREPARE q_curo_1 FROM :stmt;
       EXEC SQL DECLARE q_curo_1_cursor CURSOR FOR q_curo_1;
       EXEC SQL OPEN q_curo_1_cursor;
       EXEC SQL FETCH q_curo_1_cursor INTO :dply_begin, :dply_end, :iofficer, :nofficer;
       fFound = (SQLCODE == SQLNOTFOUND) ? 0 : 1;
       EXEC SQL CLOSE q_curo_1_cursor;
       EXEC SQL FREE  q_curo_1_cursor;
       if(!fFound) return exitsub(reply, M_CA_NPOLICY) ? M_CA_NPOLICY : apiRC;
    /* end of car9802052 */

    /* ����B�z */
        strcpy(sdply_begin,cm_cdate_str_100(dply_begin));
        strcpy(sdply_end,cm_cdate_str_100(dply_end));

    /* �Y�Q�O�I�HQ201639145,��ܯS��ĵ�i�T��4450; Modified by Julia Han in 2007/06/04 */
        if (strcmp(trim(iassured),"Q201639145") == 0)
        {
        		return exitsub(reply,M_CA_IASSURED_WARNING) ? M_CA_IASSURED_WARNING :apiRC;
        	}

    /* �Ӹ갱���ˮ� add by sylvia 103.02.17 (1020924002_C2) */
         iCountDeny=0;
         iCountFunsale=0;
         $select count(*),funrenew_ins[1,1],funquery_ins[1,1],fdelete_ins[1,1]
            into $iCountDeny,$funrenew,$funquery,$fundelete
            from cm_personal_deny
           where iassured = $iassured
             and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
             and ddeny <= today
             and (dexpire is null or dexpire >= today)
             GROUP BY 2,3,4;
        if(iCountDeny > 0)
        {
            iUnDeny=0;
         /* �bcu_code_data.itype=CK ���]�w��,�i�H�d�� */
         $select count(*) into $iUnDeny
            from cu_code_data where itype = 'CK' and icode = $sUserid;
         if (iUnDeny == 0)
         {
         	if (strcmp(trim(funrenew),"1") == 0)
            	return exitsub(reply,M_CA_PERSONAL_DENY_RENEW) ? M_CA_PERSONAL_DENY_RENEW :apiRC;
            else if (strcmp(trim(funquery),"1") == 0)
            	return exitsub(reply,M_CA_PERSONAL_DENY_QUERY) ? M_CA_PERSONAL_DENY_QUERY :apiRC;
            else if (strcmp(trim(fundelete),"1") == 0)
            	return exitsub(reply,M_CA_PERSONAL_DENY_DELETE) ? M_CA_PERSONAL_DENY_DELETE :apiRC;
            else 
            	return exitsub(reply,M_CA_PERSONAL_DENY) ? M_CA_PERSONAL_DENY :apiRC;
         }
         	
        }

    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
        cm_buf_res_msg();             /* reserve for MsgCode and count */
        cm_buf_res_count();
     }
    cm_buf_put("%s %s %s %s %s %s %s",ipolicy,itag,nassured,sdply_begin,sdply_end,iofficer,nofficer);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
        memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
        repbuf_len += tmp_len;
        count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
                $CLOSE ass_curn;
                $FREE  ass_curn;
                return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
                cm_buf_init(ReplyBuf);
                cm_buf_put("%l",M_CM_OUT_SPACE);
                tmp_len = cm_buf_len(ReplyBuf);
                if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)                           return apiRC;
                return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s %s %s %s %s %s",ipolicy,itag,nassured,sdply_begin,sdply_end,iofficer,nofficer);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
  } /* for loop */
 $CLOSE ass_curn;
 $FREE ass_curn;


 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    else
      return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
  	 if (strcmp(trim(fcheckClose), "0") == 0)
         return exitsub(reply,M_CA_NOREC_ERR) ? M_CA_NOREC_ERR :apiRC;
     else
         return exitsub(reply,M_CA_NASSURED_VS_PLY) ? M_CA_NASSURED_VS_PLY :apiRC;
  }

errexit:
   printf("SOLERR:%s\n",sqlca.sqlerrm);
   return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}


/***********************************************************/
/*                                                         */
/*               �ˮ`�I���                                */
/*                                                         */
/***********************************************************/
long car1001_multiple_queryu(reply)
serverReply reply;
{

     $char DBName[5], sFullName[20], stmt[1024];


     /* table ca_pa_ply */
    $char ninsurant[31],iinsurant[11],ainsurant[61],napplicant[31];
    $char relation_appl[2],nbeneficiary[31],relation_bene[2],iins_scope[2];
    $char icareer[2];

    $long mins_amt,mins_premium,daily_pay;
    $char ipolicy[19];
    $char dbirth[12];
    $char iendorse[21];
     /* end of ca_pa_ply */


     /* standard defined data */
     char tmpbuf[4000];
     int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
     int i,total_count=0, fFound;
     /* end of standard data */

     /*** AOI ***/
     char ao_policy1[CAR_POLICY_LEN+1],ao_policy2[CAR_TARGET_LEN+1];

     /* self defined data */
     $long  qtot,qcount;
     char result[3];
     char desc[35],paydate[11],duedate[11];
     char ap[2];
     $char buf1[100], buf2[21];
     /* end of self data */


     qtot=qcount=0;
     result[0]=0;
     desc[0]=paydate[0]=duedate[0]=0;

     ninsurant[0]=iinsurant[0]=ainsurant[0]=napplicant[0]=ipolicy[0]=0;
     relation_appl[0]=nbeneficiary[0]=relation_bene[0]=iins_scope[0]=0;
     icareer[0]=iendorse[0]=0;
     mins_amt=mins_premium=0;

     cm_buf_get("%s",DBName);
     cm_buf_get("%s",ipolicy);
     cm_buf_get("%s",sUserid);
     cm_buf_get("%s",ap);
     cm_buf_get("%s",iendorse);


     if(strcmp(trim(ap),"0")==0)
     {
        sprintf(buf1,"ca_pa_ply" );
        sprintf(buf2,"daily_pay" );
     }
     else if(strcmp(trim(ap),"1")==0)
     {
        sprintf(buf1,"ca_pa_edr");
        sprintf(buf2,"medr_daily_pay" );
     }
     else
     {
        sprintf(buf1,"ca_pa_ori");
        sprintf(buf2,"daily_pay" );
     }


     if(db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     strncpy(DBName,ipolicy,2); DBName[2]='\0';
     strcpy(sFullName, get_car_full_db(ipolicy));

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     if((strcmp(trim(ap),"0")==0) || (strcmp(trim(ap),"2")==0))
     {
         sprintf(stmt, "SELECT ninsurant,dbirth,iinsurant,ainsurant,napplicant, \
                               relation_appl,nbeneficiary,relation_bene,iins_scope, \
                               icareer,mins_amt,mins_premium, %s \
                          FROM %s:%s\
                         WHERE ipolicy='%s' and iins_type = '33' \
                         ORDER BY iinsurant", buf2, sFullName,buf1, ipolicy);
         EXEC SQL PREPARE mqc_1 FROM :stmt;
         EXEC SQL DECLARE ap_0 CURSOR FOR mqc_1;
         EXEC SQL OPEN ap_0;
         qtot = 0;

         cm_buf_init(ReplyBuf);
         cm_buf_res_msg();
         cm_buf_res_count();

         printf("stmt[%s]\n",stmt);
         for(;;)
         {
            EXEC SQL FETCH ap_0 INTO $ninsurant, $dbirth, $iinsurant, $ainsurant, $napplicant,
                                     $relation_appl, $nbeneficiary, $relation_bene, $iins_scope,
                                     $icareer, $mins_amt, $mins_premium, $daily_pay;

            if(SQLCODE==SQLNOTFOUND) break;

            mins_amt = mins_amt / 10000;
            printf("mins_amt[%l]\n",mins_amt);
            strcpy(dbirth,cm_from_infdate_100(dbirth));
            cm_buf_put("%s %s %s %s %s %s %s %s %s %s %l %l %l ",
                 ninsurant,dbirth,iinsurant,ainsurant,napplicant,
                 relation_appl,nbeneficiary,relation_bene,iins_scope,
                 icareer,mins_amt,mins_premium, daily_pay );

            qtot++;
         }
         EXEC SQL CLOSE ap_0;
         EXEC SQL FREE  ap_0;
     }
     if(strcmp(trim(ap),"1")==0)
     {

         sprintf(stmt, "SELECT ninsurant,dbirth,iinsurant,ainsurant,napplicant, \
                               relation_appl,nbeneficiary,relation_bene,iins_scope, \
                               icareer,medrins_amt,medrins_prem, %s \
                          FROM %s:%s\
                         WHERE iendorse='%s'  and iins_type = '33' \
                         ORDER BY iinsurant", buf2, sFullName,buf1, iendorse);
         EXEC SQL PREPARE mqc_1 FROM :stmt;
         EXEC SQL DECLARE ap_1 CURSOR FOR mqc_1;
         EXEC SQL OPEN ap_1;
         qtot = 0;

         cm_buf_init(ReplyBuf);
         cm_buf_res_msg();
         cm_buf_res_count();

         printf("stmt[%s]\n",stmt);
         for(;;)
         {
            EXEC SQL FETCH ap_1 INTO $ninsurant, $dbirth, $iinsurant, $ainsurant, $napplicant,
                                     $relation_appl, $nbeneficiary, $relation_bene, $iins_scope,
                                     $icareer, $mins_amt, $mins_premium, $daily_pay;

            if(SQLCODE==SQLNOTFOUND) break;

            mins_amt = mins_amt / 10000;
            printf("mins_amt[%l]\n",mins_amt);
            strcpy(dbirth,cm_from_infdate_100(dbirth));
            cm_buf_put("%s %s %s %s %s %s %s %s %s %s %l %l %l",
                  ninsurant,dbirth,iinsurant,ainsurant,napplicant,
                  relation_appl,nbeneficiary,relation_bene,iins_scope,
                  icareer,mins_amt,mins_premium,daily_pay );

            qtot++;
         }
         EXEC SQL CLOSE ap_1;
         EXEC SQL FREE  ap_1;

      }

     if(qtot==0)
         return exitsub(reply,M_CA_NOREC_ERR) ? M_CA_NOREC_ERR : apiRC;


     cm_buf_put_msg(M_CM_OK);
     cm_buf_put_count(qtot);

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
     return api_OKComplete;

errexit:
     printf("stmt=[%s]\n",stmt);
     printf("SOLERR:%s\n",sqlca.sqlerrm);
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long qcount_qlia_day(x_sIpolicy, x_sIclaim, x_sIins_type, x_qday2)
$char  x_sIpolicy[20], x_sIclaim[20], x_sIins_type[INSURANCE_TYPE];
  int  *x_qday2;
{
   $char stmt[1024], DBName[3], sFullName[20];
   $char xIofficer[10], xIcar_type[3], xNequipment15[2], xNequipment16[2];
   $char iins_type_x[INSURANCE_TYPE], dedr_begin_d[11],dendorse_d[11];
   $char fedr_status_d[2],dacc[11], iins_type_d[INSURANCE_TYPE];
   $int  rday1, rday2, qlia, qday_d;
   $char nequipment[31];

   $short int qday_x, qfree, qmore, free_day, more_day;

   $whenever sqlerror goto errexit;

    printf("in qcount_qlia_day \n");
    printf("x_sIpolicy[%s], x_sIclaim[%s] x_sIins_type[%s]\n",
            x_sIpolicy, x_sIclaim, x_sIins_type );

    strcpy( x_sIins_type, trim(x_sIins_type));
    strncpy(DBName,x_sIpolicy,2);
    DBName[2]='\0';
    strcpy(sFullName, get_full_dbname(DBName));

    sprintf(stmt,"SELECT a.iofficer, a.icar_type, b.nequipment \
                    FROM %s:ply_relation a, %s:policy b \
                   WHERE a.ipolicy = b.ipolicy \
                     AND a.ipolicy = '%s'", sFullName, sFullName,x_sIpolicy );
    $PREPARE cnt_qlia FROM $stmt;
    $EXECUTE cnt_qlia INTO $xIofficer, $xIcar_type, $nequipment;

    if (equip_cmp(nequipment,"15") == TRUE)
    {
       strcpy(xNequipment15,"1");
    }
    else
    {
       strcpy(xNequipment15,"0");
    }

    if (equip_cmp(nequipment,"16") == TRUE)
    {
       strcpy(xNequipment16,"1");
    }
    else
    {
       strcpy(xNequipment16,"0");
    }


    sprintf(stmt,"SELECT DATE(daccident) FROM %s:appraisal \
                   WHERE iclaim = '%s'",sFullName, x_sIclaim );

    $PREPARE kk FROM $stmt;
    $EXECUTE kk INTO $dacc;

    free_day = more_day = 0;
    rday1 = rday2 = 0;
    *x_qday2 = 0;

  if( (strcmp(trim(x_sIins_type),"01")==0) || (strcmp(trim(x_sIins_type),"05")==0) ||
      (strcmp(trim(x_sIins_type),"08")==0) || (strcmp(trim(x_sIins_type),"09")==0))
  {
     if((strcmp(xIofficer,"882237A")!= 0) && (strcmp(xIofficer,"Z03830A2")!=0) &&
        (strcmp(xIofficer,"Z03861A3")!=0))
     {
       if((strncmp(xIcar_type,"03",2) == 0)|| (strncmp(xIcar_type,"04",2) == 0) ||
          (strncmp(xIcar_type,"19",2) == 0))
       {

          sprintf(stmt,
          " SELECT iins_type,dedr_begin,dendorse,fedr_status,NVL(qday,0)  \
              FROM %s:ply_ins_type_hist                  \
             WHERE ipolicy = ?                           \
               AND dedr_begin <= ? AND dedr_end >= ?     \
               AND iins_type = ?                         \
             ORDER BY dedr_begin DESC, dendorse DESC, fedr_status DESC ",sFullName);
          $PREPARE cd01 FROM $stmt;
          $DECLARE cd01_cur CURSOR FOR cd01;
          $OPEN cd01_cur USING $x_sIpolicy,$dacc,$dacc,$x_sIins_type;
          $FETCH cd01_cur INTO $iins_type_d,$dedr_begin_d,$dendorse_d,$fedr_status_d,
                               $qday_d;
          if (SQLCODE != SQLNOTFOUND){

              /** �O�渹�i��X�I�h���A�[�`�X�I�餧�e���߮׸����Ѽ� **/
              sprintf(stmt,
              " SELECT NVL(SUM(NVL(qlia,0)),0) \
                  FROM %s:appraisal x,%s:settlement a,%s:stl_ins_type b \
                 WHERE x.ipolicy = ?         \
                   AND b.iins_type = ?       \
                   AND a.fstl = '1'          \
                   AND a.iclaim = b.iclaim   \
                   AND a.fstl = b.fstl       \
                   AND x.iclaim = a.iclaim   \
                   AND date(x.daccident) <= ?\
                   AND a.iclose_type = b.iclose_type ", sFullName, sFullName, sFullName );
              $PREPARE cd02 FROM $stmt;
              $EXECUTE cd02 INTO $qlia
                 USING $x_sIpolicy,$iins_type_d,$dacc;

              /*** �H�U�}�l�p��N�B���Ѿl�Ѽ� ***/
              /*** 1.�]�w�K�O�N�B���Ѽ� ***/
              strcpy(iins_type_d, trim(iins_type_d));
              switch(atoi(iins_type_d)){
                case  1:  free_day  = day01;
                          break;
                case  5:  free_day  = day05;
                          break;
                case  8:  free_day  = day08;
                          break;
                case  9:  free_day  = day09;
                          break;
                default : break;
               }

              /*** 2.�ˮ֬O�_�����[���N�B�� ***/
              if ( strcmp( xNequipment15,"1") == 0 )
              {
                  more_day = qday_d - free_day;
                  if( more_day < 0 )
                      more_day = 0;
              }
              else more_day = 0;

              printf("free_day[%ld],more_day[%ld] qlia[%ld]\n",free_day,more_day,qlia);

              /*** 3.�p��K�O�P���[�����Ѿl�Ѽ� ***/
              if( qlia <= free_day )
              {
                  rday1 = free_day - qlia;
                  rday2 = more_day;
              }
              else
              {
                  rday1 = 0;
                  rday2 = more_day - qlia + free_day;
              }

          }
          $CLOSE cd01_cur;
          $FREE  cd01_cur;

       }
     }
  }
  else if( strcmp(trim(x_sIins_type),"11")==0)
  {

     if((strcmp(xIofficer,"882237A")!= 0) && (strcmp(xIofficer,"Z03830A2")!=0) &&
        (strcmp(xIofficer,"Z03861A3")!=0))
     {
       if((strncmp(xIcar_type,"03",2) == 0)|| (strncmp(xIcar_type,"04",2) == 0) ||
          (strncmp(xIcar_type,"19",2) == 0))
       {
          sprintf(stmt,
          " SELECT iins_type,dedr_begin,dendorse,fedr_status,NVL(qday,0)  \
              FROM %s:ply_ins_type_hist                  \
             WHERE ipolicy = ?                           \
               AND dedr_begin <= ? AND dedr_end >= ? \
               AND iins_type = '11' \
             ORDER BY dedr_begin DESC, dendorse DESC, fedr_status DESC ",sFullName);
          $PREPARE sd01 FROM $stmt;
          $DECLARE sd01_cur CURSOR FOR sd01;
          $OPEN sd01_cur USING $x_sIpolicy,$dacc,$dacc;
          $FETCH sd01_cur INTO $iins_type_d,$dedr_begin_d,$dendorse_d,$fedr_status_d,
                               $qday_d;
          if (SQLCODE != SQLNOTFOUND){

               sprintf(stmt,
               " SELECT NVL(SUM(NVL(qlia,0)),0) \
                   FROM %s:appraisal x,%s:settlement a,%s:stl_ins_type b \
                  WHERE a.ipolicy = ?         \
                    AND b.iins_type = ?       \
                    AND a.fstl = '1'          \
                    AND a.iclaim = b.iclaim   \
                    AND a.fstl = b.fstl       \
                    AND x.iclaim = a.iclaim   \
                    AND date(x.daccident) <= ?\
                    AND a.iclose_type = b.iclose_type ",
                    sFullName, sFullName, sFullName );
               $PREPARE cd02 FROM $stmt;
               $EXECUTE cd02 INTO $qlia
                  USING $x_sIpolicy,$iins_type_d,$dacc;

               /*** �H�U�}�l�p��N�B���Ѿl�Ѽ� ***/
               /*** 1.�]�w�K�O�N�B���Ѽ� ***/

               /*** 2.�ˮ֬O�_�����[���N�B�� ***/
               if ( strcmp( xNequipment16,"1") == 0 )
               {
                   more_day = qday_d;
                   if( more_day < 0 )
                       more_day = 0;
               }
               else more_day = 0;

               /*** 3.�p��K�O�P���[�����Ѿl�Ѽ� ***/
               rday2 = more_day - qlia;

               printf("iins11 rday2[%d] more_day[%d] qlia[%d]\n",rday2, more_day,qlia );

          }
          $CLOSE sd01_cur;
          $FREE  sd01_cur;
       }
     }
  }
  else if((strcmp(trim(x_sIins_type),"14")==0) || (strcmp(trim(x_sIins_type),"15")==0) ||
          (strcmp(trim(x_sIins_type),"16")==0))
  {
      sprintf(stmt,
       " SELECT iins_type,dedr_begin,dendorse,fedr_status  \
           FROM %s:ply_ins_type_hist                  \
          WHERE ipolicy = ?                           \
            AND dedr_begin <= ? AND dedr_end >= ? \
            AND iins_type IN ('14','15','16')    \
          ORDER BY dedr_begin DESC, dendorse DESC, fedr_status DESC ",sFullName);
       $PREPARE cf01 FROM $stmt;
       $DECLARE cf01_cur CURSOR FOR cf01;
       $OPEN cf01_cur USING $x_sIpolicy,$dacc,$dacc;
       $FETCH cf01_cur INTO $iins_type_d,$dedr_begin_d,$dendorse_d,$fedr_status_d;
       if (SQLCODE != SQLNOTFOUND){

        sprintf(stmt,
         " SELECT NVL(SUM(NVL(qlia,0)),0)      \
             FROM %s:settlement a,%s:stl_ins_type b      \
            WHERE a.ipolicy = ?                          \
              AND b.iins_type = ?                        \
              AND a.fstl = '1'                           \
              AND a.iclaim = b.iclaim                    \
              AND a.fstl = b.fstl                        \
              AND a.iclose_type = b.iclose_type ", sFullName ,sFullName );
         $PREPARE cf02 FROM $stmt;
         $EXECUTE cf02
             INTO $qlia
            USING $x_sIpolicy,$iins_type_d;

           strcpy(iins_type_d, trim(iins_type_d));
           switch(atoi(iins_type_d)){

             case  14:  rday1  = day14 - qlia;
                       break;
             case  15:  rday1  = day15 - qlia;
                       break;
             case  16:  rday1  = day16 - qlia;
                       break;
             default : break;
           }
             printf("iins_type_d[%s],sIpolicy[%s]\n",iins_type_d,x_sIpolicy);
             printf("rday[%ld],qlia[%ld]\n",rday1,qlia);
       }else{
           rday1 = 0;
       }
       $CLOSE cf01_cur;
       $FREE  cf01_cur;
  }

  *x_qday2 = rday1 + rday2;

  printf("x_qday2[%d]\n",x_qday2);

  return SUCCESS;

errexit:
   return SQLCODE;
}
/***********************************************************/
/*                                                         */
/*               �a�x�����d���I���                        */
/*                                                         */
/***********************************************************/
long car1001_multiple_queryv(reply)
serverReply reply;
{

     $char DBName[5], sFullName[20], stmt[1024];


     /* table ca_pa_ply */
    $char ninsurant[31],iinsurant[11],ainsurant[61],napplicant[31];
    $char relation_appl[2],nbeneficiary[31],relation_bene[2],iins_scope[2];
    $char icareer[2];

    $long mins_amt,mins_premium,daily_pay;
    $char ipolicy[19];
    $char dbirth[12];
    $char iendorse[21];
     /* end of ca_pa_ply */


     /* standard defined data */
     char tmpbuf[4000];
     int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
     int i,total_count=0, fFound;
     /* end of standard data */

     /*** AOI ***/
     char ao_policy1[CAR_POLICY_LEN+1],ao_policy2[CAR_TARGET_LEN+1];

     /* self defined data */
     $long  qtot,qcount;
     char result[3];
     char desc[35],paydate[11],duedate[11];
     char ap[2];
     $char buf1[100], buf2[21];
     /* end of self data */


     qtot=qcount=0;
     result[0]=0;
     desc[0]=paydate[0]=duedate[0]=0;

     ninsurant[0]=iinsurant[0]=ainsurant[0]=napplicant[0]=ipolicy[0]=0;
     relation_appl[0]=nbeneficiary[0]=relation_bene[0]=iins_scope[0]=0;
     icareer[0]=iendorse[0]=0;
     mins_amt=mins_premium=0;

     cm_buf_get("%s",DBName);
     cm_buf_get("%s",ipolicy);
     cm_buf_get("%s",sUserid);
     cm_buf_get("%s",ap);
     cm_buf_get("%s",iendorse);


     if(strcmp(trim(ap),"0")==0)
     {
        sprintf(buf1,"ca_pa_ply" );
        sprintf(buf2,"daily_pay");
     }
     else if(strcmp(trim(ap),"1")==0)
     {
        sprintf(buf1,"ca_pa_edr");
        sprintf(buf2,"medr_daily_pay");
     }
     else
     {
        sprintf(buf1,"ca_pa_ori");
        sprintf(buf2,"daily_pay");
     }


     if(db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     strncpy(DBName,ipolicy,2); DBName[2]='\0';
     strcpy(sFullName, get_car_full_db(ipolicy));

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     if((strcmp(trim(ap),"0")==0) || (strcmp(trim(ap),"2")==0))
     {
         sprintf(stmt, "SELECT ninsurant,dbirth,iinsurant,ainsurant,napplicant, \
                               relation_appl,nbeneficiary,relation_bene,iins_scope, \
                               icareer,mins_amt,mins_premium, %s \
                          FROM %s:%s\
                         WHERE ipolicy='%s' and iins_type = '35' \
                         ORDER BY iinsurant", buf2, sFullName,buf1, ipolicy);

         printf("stmt[%s]\n",stmt);

         EXEC SQL PREPARE mqc_1 FROM :stmt;
         EXEC SQL DECLARE ap_2 CURSOR FOR mqc_1;
         EXEC SQL OPEN ap_2;
         qtot = 0;

         cm_buf_init(ReplyBuf);
         cm_buf_res_msg();
         cm_buf_res_count();


         for(;;)
         {
            EXEC SQL FETCH ap_2 INTO $ninsurant, $dbirth, $iinsurant, $ainsurant, $napplicant,
                                     $relation_appl, $nbeneficiary, $relation_bene, $iins_scope,
                                     $icareer, $mins_amt, $mins_premium, $daily_pay;

            if(SQLCODE==SQLNOTFOUND) break;

            mins_amt = mins_amt / 10000;
            printf("mins_amt[%l]\n",mins_amt);
            strcpy(dbirth,cm_from_infdate_100(dbirth));
            cm_buf_put("%s %s %s %s %s %s %s %s %s %s %l %l %l ",
                 ninsurant,dbirth,iinsurant,ainsurant,napplicant,
                 relation_appl,nbeneficiary,relation_bene,iins_scope,
                 icareer,mins_amt,mins_premium, daily_pay );

            qtot++;
         }
         EXEC SQL CLOSE ap_2;
         EXEC SQL FREE  ap_2;
     }
     if(strcmp(trim(ap),"1")==0)
     {

         sprintf(stmt, "SELECT ninsurant,dbirth,iinsurant,ainsurant,napplicant, \
                               relation_appl,nbeneficiary,relation_bene,iins_scope, \
                               icareer,medrins_amt,medrins_prem, %s \
                          FROM %s:%s\
                         WHERE iendorse='%s'  and iins_type = '35' \
                         ORDER BY iinsurant", buf2, sFullName,buf1, iendorse);
         EXEC SQL PREPARE mqc_1 FROM :stmt;
         EXEC SQL DECLARE ap_3 CURSOR FOR mqc_1;
         EXEC SQL OPEN ap_3;
         qtot = 0;

         cm_buf_init(ReplyBuf);
         cm_buf_res_msg();
         cm_buf_res_count();

         printf("stmt[%s]\n",stmt);
         for(;;)
         {
            EXEC SQL FETCH ap_3 INTO $ninsurant, $dbirth, $iinsurant, $ainsurant, $napplicant,
                                     $relation_appl, $nbeneficiary, $relation_bene, $iins_scope,
                                     $icareer, $mins_amt, $mins_premium, $daily_pay;

            if(SQLCODE==SQLNOTFOUND) break;

            mins_amt = mins_amt / 10000;
            printf("mins_amt[%l]\n",mins_amt);
            strcpy(dbirth,cm_from_infdate_100(dbirth));
            cm_buf_put("%s %s %s %s %s %s %s %s %s %s %l %l %l",
                  ninsurant,dbirth,iinsurant,ainsurant,napplicant,
                  relation_appl,nbeneficiary,relation_bene,iins_scope,
                  icareer,mins_amt,mins_premium,daily_pay );

            qtot++;
         }
         EXEC SQL CLOSE ap_3;
         EXEC SQL FREE  ap_3;

      }

     if(qtot==0)
         return exitsub(reply,M_CA_NOREC_ERR) ? M_CA_NOREC_ERR : apiRC;


     cm_buf_put_msg(M_CM_OK);
     cm_buf_put_count(qtot);

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
     return api_OKComplete;

errexit:
     printf("stmt=[%s]\n",stmt);
     printf("SOLERR:%s\n",sqlca.sqlerrm);
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/***********************************************************/
/*                                                         */
/*               �����r�p�ˮ`�I���                        */
/*                                                         */
/***********************************************************/
long car1001_multiple_queryw(reply)
serverReply reply;
{

     $char DBName[5], sFullName[20], stmt[1024];


     /* table ca_pa_ply */
    $char ninsurant[31],iinsurant[11],ainsurant[61],napplicant[31];
    $char relation_appl[2],nbeneficiary[31],relation_bene[2],iins_scope[2];
    $char icareer[2];

    $long mins_amt,mins_premium,daily_pay;
    $char ipolicy[19];
    $char dbirth[12];
    $char iendorse[21];
     /* end of ca_pa_ply */


     /* standard defined data */
     char tmpbuf[4000];
     int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
     int i,total_count=0, fFound;
     /* end of standard data */

     /*** AOI ***/
     char ao_policy1[CAR_POLICY_LEN+1],ao_policy2[CAR_TARGET_LEN+1];

     /* self defined data */
     $long  qtot,qcount;
     char result[3];
     char desc[35],paydate[11],duedate[11];
     char ap[2];
     $char buf1[100], buf2[21];
     /* end of self data */


     qtot=qcount=0;
     result[0]=0;
     desc[0]=paydate[0]=duedate[0]=0;

     ninsurant[0]=iinsurant[0]=ainsurant[0]=napplicant[0]=ipolicy[0]=0;
     relation_appl[0]=nbeneficiary[0]=relation_bene[0]=iins_scope[0]=0;
     icareer[0]=iendorse[0]=0;
     mins_amt=mins_premium=0;

     cm_buf_get("%s",DBName);
     cm_buf_get("%s",ipolicy);
     cm_buf_get("%s",sUserid);
     cm_buf_get("%s",ap);
     cm_buf_get("%s",iendorse);


     if(strcmp(trim(ap),"0")==0)
     {
        sprintf(buf1,"ca_pa_ply" );
        sprintf(buf2,"daily_pay" );
     }
     else if(strcmp(trim(ap),"1")==0)
     {
        sprintf(buf1,"ca_pa_edr");
        sprintf(buf2,"medr_daily_pay" );
     }
     else
     {
        sprintf(buf1,"ca_pa_ori");
        sprintf(buf2,"daily_pay" );
     }


     if(db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     strncpy(DBName,ipolicy,2); DBName[2]='\0';
     strcpy(sFullName, get_car_full_db(ipolicy));

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     if((strcmp(trim(ap),"0")==0) || (strcmp(trim(ap),"2")==0))
     {
         sprintf(stmt, "SELECT ninsurant,dbirth,iinsurant,ainsurant,napplicant, \
                               relation_appl,nbeneficiary,relation_bene,iins_scope, \
                               icareer,mins_amt,mins_premium, %s \
                          FROM %s:%s\
                         WHERE ipolicy='%s' and iins_type = '48' \
                         ORDER BY iinsurant", buf2, sFullName,buf1, ipolicy);
         EXEC SQL PREPARE mqc_1 FROM :stmt;
         EXEC SQL DECLARE ap_4 CURSOR FOR mqc_1;
         EXEC SQL OPEN ap_4;
         qtot = 0;

         cm_buf_init(ReplyBuf);
         cm_buf_res_msg();
         cm_buf_res_count();

         printf("stmt[%s]\n",stmt);
         for(;;)
         {
            EXEC SQL FETCH ap_4 INTO $ninsurant, $dbirth, $iinsurant, $ainsurant, $napplicant,
                                     $relation_appl, $nbeneficiary, $relation_bene, $iins_scope,
                                     $icareer, $mins_amt, $mins_premium, $daily_pay;

            if(SQLCODE==SQLNOTFOUND) break;

            mins_amt = mins_amt / 10000;
            printf("mins_amt[%l]\n",mins_amt);
            daily_pay = daily_pay / 10000;

            strcpy(dbirth,cm_from_infdate_100(dbirth));
            cm_buf_put("%s %s %s %s %s %s %s %s %s %s %l %l %l ",
                 ninsurant,dbirth,iinsurant,ainsurant,napplicant,
                 relation_appl,nbeneficiary,relation_bene,iins_scope,
                 icareer,mins_amt,mins_premium, daily_pay );

            qtot++;
         }
         EXEC SQL CLOSE ap_4;
         EXEC SQL FREE  ap_4;
     }
     if(strcmp(trim(ap),"1")==0)
     {

         sprintf(stmt, "SELECT ninsurant,dbirth,iinsurant,ainsurant,napplicant, \
                               relation_appl,nbeneficiary,relation_bene,iins_scope, \
                               icareer,medrins_amt,medrins_prem, %s \
                          FROM %s:%s\
                         WHERE iendorse='%s'  and iins_type = '48' \
                         ORDER BY iinsurant", buf2, sFullName,buf1, iendorse);
         EXEC SQL PREPARE mqc_1 FROM :stmt;
         EXEC SQL DECLARE ap_5 CURSOR FOR mqc_1;
         EXEC SQL OPEN ap_5;
         qtot = 0;

         cm_buf_init(ReplyBuf);
         cm_buf_res_msg();
         cm_buf_res_count();

         printf("stmt[%s]\n",stmt);
         for(;;)
         {
            EXEC SQL FETCH ap_5 INTO $ninsurant, $dbirth, $iinsurant, $ainsurant, $napplicant,
                                     $relation_appl, $nbeneficiary, $relation_bene, $iins_scope,
                                     $icareer, $mins_amt, $mins_premium, $daily_pay;

            if(SQLCODE==SQLNOTFOUND) break;

            mins_amt = mins_amt / 10000;
            printf("mins_amt[%l]\n",mins_amt);
            daily_pay = daily_pay / 10000;

            strcpy(dbirth,cm_from_infdate_100(dbirth));
            cm_buf_put("%s %s %s %s %s %s %s %s %s %s %l %l %l",
                  ninsurant,dbirth,iinsurant,ainsurant,napplicant,
                  relation_appl,nbeneficiary,relation_bene,iins_scope,
                  icareer,mins_amt,mins_premium,daily_pay );

            qtot++;
         }
         EXEC SQL CLOSE ap_5;
         EXEC SQL FREE  ap_5;

      }

     if(qtot==0)
         return exitsub(reply,M_CA_NOREC_ERR) ? M_CA_NOREC_ERR : apiRC;


     cm_buf_put_msg(M_CM_OK);
     cm_buf_put_count(qtot);

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
     return api_OKComplete;

errexit:
     printf("stmt=[%s]\n",stmt);
     printf("SOLERR:%s\n",sqlca.sqlerrm);
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/***********************************************************/
/*                                                         */
/*            �ĤT�H���[�r�p�ˮ`�I���                     */
/*                                                         */
/***********************************************************/
long car1001_multiple_queryx(reply)
serverReply reply;
{

     $char DBName[5], sFullName[20], stmt[1024];


     /* table ca_pa_ply */
    $char ninsurant[31],iinsurant[11],ainsurant[61],napplicant[31];
    $char relation_appl[2],nbeneficiary[31],relation_bene[2],iins_scope[2];
    $char icareer[2];

    $long mins_amt,mins_premium,daily_pay;
    $char ipolicy[19];
    $char dbirth[12];
    $char iendorse[21];
     /* end of ca_pa_ply */


     /* standard defined data */
     char tmpbuf[4000];
     int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
     int i,total_count=0, fFound;
     /* end of standard data */

     /*** AOI ***/
     char ao_policy1[CAR_POLICY_LEN+1],ao_policy2[CAR_TARGET_LEN+1];

     /* self defined data */
     $long  qtot,qcount;
     char result[3];
     char desc[35],paydate[11],duedate[11];
     char ap[2];
     $char buf1[100], buf2[21];
     /* end of self data */


     qtot=qcount=0;
     result[0]=0;
     desc[0]=paydate[0]=duedate[0]=0;

     ninsurant[0]=iinsurant[0]=ainsurant[0]=napplicant[0]=ipolicy[0]=0;
     relation_appl[0]=nbeneficiary[0]=relation_bene[0]=iins_scope[0]=0;
     icareer[0]=iendorse[0]=0;
     mins_amt=mins_premium=0;

     cm_buf_get("%s",DBName);
     cm_buf_get("%s",ipolicy);
     cm_buf_get("%s",sUserid);
     cm_buf_get("%s",ap);
     cm_buf_get("%s",iendorse);


     if(strcmp(trim(ap),"0")==0)
     {
        sprintf(buf1,"ca_pa_ply" );
        sprintf(buf2,"daily_pay" );
     }
     else if(strcmp(trim(ap),"1")==0)
     {
        sprintf(buf1,"ca_pa_edr");
        sprintf(buf2,"medr_daily_pay" );
     }
     else
     {
        sprintf(buf1,"ca_pa_ori");
        sprintf(buf2,"daily_pay" );
     }


     if(db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     strncpy(DBName,ipolicy,2); DBName[2]='\0';
     strcpy(sFullName, get_car_full_db(ipolicy));

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     if((strcmp(trim(ap),"0")==0) || (strcmp(trim(ap),"2")==0))
     {
         sprintf(stmt, "SELECT ninsurant,dbirth,iinsurant, \
                               nbeneficiary,relation_bene,iins_scope, \
                               mins_amt,mins_premium, %s \
                          FROM %s:%s\
                         WHERE ipolicy='%s' and iins_type in ('56','136') \
                         ORDER BY iinsurant", buf2, sFullName,buf1, ipolicy);
         EXEC SQL PREPARE mqc_a FROM :stmt;
         EXEC SQL DECLARE ap_56 CURSOR FOR mqc_a;
         EXEC SQL OPEN ap_56;
         qtot = 0;

         cm_buf_init(ReplyBuf);
         cm_buf_res_msg();
         cm_buf_res_count();

         printf("stmt[%s]\n",stmt);
         for(;;)
         {
            EXEC SQL FETCH ap_56 INTO $ninsurant, $dbirth, $iinsurant, $nbeneficiary,
                                      $relation_bene, $iins_scope,
                                      $mins_amt, $mins_premium, $daily_pay;

            if(SQLCODE==SQLNOTFOUND) break;

            mins_amt = mins_amt / 10000;
            printf("mins_amt[%l]\n",mins_amt);

            strcpy(dbirth,cm_from_infdate_100(dbirth));
            cm_buf_put("%s %s %s %s %s %s %l %l %l ",
                 ninsurant,dbirth,iinsurant,
                 nbeneficiary,relation_bene,iins_scope,
                 mins_amt,mins_premium, daily_pay );

            qtot++;
         }
         EXEC SQL CLOSE ap_56;
         EXEC SQL FREE  ap_56;
     }
     if(strcmp(trim(ap),"1")==0)
     {

         sprintf(stmt, "SELECT ninsurant,dbirth,iinsurant,ainsurant,napplicant, \
                               relation_appl,nbeneficiary,relation_bene,iins_scope, \
                               icareer,medrins_amt,medrins_prem, %s \
                          FROM %s:%s\
                         WHERE iendorse='%s'  and iins_type in ('56','136') \
                         ORDER BY iinsurant", buf2, sFullName,buf1, iendorse);
         EXEC SQL PREPARE mqc_b FROM :stmt;
         EXEC SQL DECLARE ap_562 CURSOR FOR mqc_b;
         EXEC SQL OPEN ap_562;
         qtot = 0;

         cm_buf_init(ReplyBuf);
         cm_buf_res_msg();
         cm_buf_res_count();

         printf("stmt[%s]\n",stmt);
         for(;;)
         {
            EXEC SQL FETCH ap_562 INTO $ninsurant, $dbirth, $iinsurant, $ainsurant, $napplicant,
                                       $relation_appl, $nbeneficiary, $relation_bene, $iins_scope,
                                       $icareer, $mins_amt, $mins_premium, $daily_pay;

            if(SQLCODE==SQLNOTFOUND) break;

            mins_amt = mins_amt / 10000;
            printf("mins_amt[%l]\n",mins_amt);

            strcpy(dbirth,cm_from_infdate_100(dbirth));
            cm_buf_put("%s %s %s %s %s %s %l %l %l",
                  ninsurant,dbirth,iinsurant,
                  nbeneficiary,relation_bene,iins_scope,
                  mins_amt,mins_premium,daily_pay );

            qtot++;
         }
         EXEC SQL CLOSE ap_562;
         EXEC SQL FREE  ap_562;

      }

     if(qtot==0)
         return exitsub(reply,M_CA_NOREC_ERR) ? M_CA_NOREC_ERR : apiRC;


     cm_buf_put_msg(M_CM_OK);
     cm_buf_put_count(qtot);

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
     return api_OKComplete;

errexit:
     printf("stmt=[%s]\n",stmt);
     printf("SOLERR:%s\n",sqlca.sqlerrm);
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/***** ���ëO�� *****/
long car1001_multiple_queryp(reply)
serverReply reply;
{
     $char DBName[5], sFullName[20], stmt[1024];

     $char iendorse[ENDORSE_NUM],ipolicy[POLICY_NUM_1],itag[CA_TAG_NUM],nassured[121];
     $char itype[2],iclaim[21];
     $int  check_fedr;

     int tmp_len, fFound;
     iendorse[0]=ipolicy[0]=itag[0]=nassured[0]=0;

     cm_buf_get("%s",DBName);
     cm_buf_get("%s",itype);
     cm_buf_get("%s",ipolicy);

     if(db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     sprintf(stmt,
     " SELECT count(*),max(iclaim) \
         FROM car_spec_policy    \
        WHERE check_fedr[10] = '1' \
          AND inumber = ?        \
          AND type    = ? ");
     $PREPARE get_fedr FROM $stmt;
     $EXECUTE get_fedr
         INTO $check_fedr,$iclaim
        USING $ipolicy,$itype;
     if (SQLCODE == SQLNOTFOUND)
     {
     	check_fedr = 0;
     	strcpy(iclaim," ");
     }

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);
     cm_buf_put("%d",check_fedr);
     cm_buf_put("%s",iclaim);
     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
    printf("SOLERR:%s\n",sqlca.sqlerrm);
    printf("stmt=[%s]\n",stmt);
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
long query_ply_ins_assured(reply)
serverReply reply;
{
     $char DBName[5], sFullName[20], stmt[1024];

     $char iendorse[ENDORSE_NUM],ipolicy[POLICY_NUM_1], sData[21];

     int tmp_len, fFound, rtncode;
     iendorse[0]=ipolicy[0]=0;

     cm_buf_get("%s",DBName);
     cm_buf_get("%s",ipolicy);
     cm_buf_get("%s",iendorse);

     if(db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     $WHENEVER SQLERROR GOTO errexit;

     strcpy(sFullName, get_car_full_db(ipolicy));

     strcpy( sDbname, sFullName);
     if( iendorse[0] == '\0' || iendorse[0] == '' || iendorse[0] == ' ')
     {
         strcpy( sTable,  "ply_ins_assured");
         strcpy( sColumn, "ipolicy");
         strcpy( sData, ipolicy);
     }
     else
     {
         strcpy( sTable,  "edr_ins_assured");
         strcpy( sColumn, "iendorse");
         strcpy( sData, iendorse);
     }

     IfirstPlyInsAssured = get_ply_ins_assured( sDbname, sTable, sColumn, sData, &rtncode, v_sMsg);

     if( rtncode != M_CM_OK)
         return exitsub(reply, rtncode) ?  rtncode : apiRC;


     cm_buf_init(ReplyBuf);

     #ifdef CA_ONE
     puts("put ply_ins_assured���");

     cm_buf_put("%l",M_CM_OK);

     IcurrPlyInsAssured = IfirstPlyInsAssured;
     while( IcurrPlyInsAssured)
     {
         cm_buf_put("%s ", IcurrPlyInsAssured->iins_type);
         cm_buf_put("%s ", IcurrPlyInsAssured->provision);
         cm_buf_put("%s ", IcurrPlyInsAssured->iassured);
         cm_buf_put("%s ", IcurrPlyInsAssured->nassured);
         cm_buf_put("%s ", IcurrPlyInsAssured->dbirth);
         cm_buf_put("%s ", IcurrPlyInsAssured->nbenef);
         cm_buf_put("%s ", IcurrPlyInsAssured->rel_benef);
         cm_buf_put("%l ", IcurrPlyInsAssured->iserial);

         printf("IcurrPlyInsAssured->iins_type    [%s]\n"
         			  "IcurrPlyInsAssured->provision    [%s]\n"
                "IcurrPlyInsAssured->iassured     [%s]\n"
                "IcurrPlyInsAssured->nassured     [%s]\n"
                "IcurrPlyInsAssured->dbirth       [%s]\n"
                "IcurrPlyInsAssured->nbenef       [%s]\n"
                "IcurrPlyInsAssured->rel_benef    [%s]\n"
                "IcurrPlyInsAssured->iserial      [%d]\n",
                 IcurrPlyInsAssured->iins_type,
                 IcurrPlyInsAssured->provision,
                 IcurrPlyInsAssured->iassured,
                 IcurrPlyInsAssured->nassured,
                 IcurrPlyInsAssured->dbirth,
                 IcurrPlyInsAssured->nbenef,
                 IcurrPlyInsAssured->rel_benef,
                 IcurrPlyInsAssured->iserial);

         puts("");
         IcurrPlyInsAssured = IcurrPlyInsAssured->next;
     }
     cm_buf_put("%s", "IcurrPlyInsAssuredEnd");

     #endif

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
    printf("SOLERR:%s\n",sqlca.sqlerrm);
    printf("stmt=[%s]\n",stmt);
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long car1001_multiple_queryi1(reply)
serverReply reply;
{
     $char DBName[5], sFullName[20];
     int tmp_len;
     $char job_pos[5],iquota[7],priLevel[2];

     cm_buf_get("%s",DBName);
     cm_buf_get("%s",sUserid);

     if(db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     $SELECT work_type
        INTO $job_pos
        FROM personal:asempl
       WHERE empl_no=$sUserid;
     if (SQLCODE == SQLNOTFOUND) {
            return M_CMN_NOFFICER;
        }
        
     $SELECT iquota
        INTO $iquota
        FROM officer
      WHERE iofficer=$sUserid;
     if (SQLCODE == SQLNOTFOUND) {
            return M_CMN_NOFFICER;
        }
        
     strcpy(priLevel, "N");

	if (iquota[0] >= '6')
	{
		if (iquota[2] == '0' && iquota[3] == '1')
		{
			strcpy(priLevel, "Y");
		}
		else
		{
			if (strncmp(job_pos,"GA",2) == 0)
			{
				strcpy(priLevel, "Y");
			}
		}
	}

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);
     cm_buf_put("%s",priLevel);
     tmp_len = cm_buf_len(ReplyBuf);

     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
    printf("SOLERR:%s\n",sqlca.sqlerrm);
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long car1001_multiple_queryl1(reply)
serverReply reply;
{
     $char DBName[5], sFullName[20], stmt[1024];
     $char ipolicy[POLICY_NUM_1];
     int tmp_len;
     $char iLeader[11];

     cm_buf_get("%s",DBName);
     cm_buf_get("%s",ipolicy);

     if(db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     strcpy(sFullName, get_car_full_db(ipolicy));

     sprintf(stmt,
     " SELECT ileader      \
         FROM %s:ply_relation    \
        WHERE ipolicy = ? ",sFullName);
          
     $PREPARE get_leader FROM $stmt;
     $EXECUTE get_leader
         INTO $iLeader
        USING $ipolicy;
printf("stmt[%s]\n",stmt);

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);
     cm_buf_put("%s",iLeader);
     tmp_len = cm_buf_len(ReplyBuf);

     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
    printf("SOLERR:%s\n",sqlca.sqlerrm);
    printf("stmt=[%s]\n",stmt);
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/******************************************************************************/
long car1001_query_no_dplyclose(v_ftype, v_ikind)
$char v_ftype[2], v_ikind[21];
{
	  $char sTemp[128];
	
	  printf("***** car1001_query_no_dplyclose() *****\n");
	  
	  strcpy(sStmt, "");
	  strcpy(sTemp, "");
	  
	  if (strcmp(trim(v_ftype), "1") == 0)
	      sprintf(sTemp, "AND a.icard = '%s'", v_ikind);
	  else if (strcmp(trim(v_ftype), "6") == 0)
	      sprintf(sTemp, "AND a.ipolicy = '%s'", v_ikind);
	  else if (strcmp(trim(v_ftype), "7") == 0)
	      sprintf(sTemp, "AND a.itag = '%s'", v_ikind);
    else if (strcmp(trim(v_ftype), "8") == 0)
    	  sprintf(sTemp, "AND a.iengine = '%s'", v_ikind);
    else
        sprintf(sTemp, "AND a.iassured = '%s'", v_ikind);
    
    printf("***** [%s] *****\n", sTemp);
   
    sprintf(sStmt, "SELECT UNIQUE a.ipolicy, a.iassured, a.nassured, a.itag \
                      FROM newa00:policy a, newa00:ply_relation b \
                     WHERE a.ipolicy = b.ipolicy \
                       AND b.dply_begin >= today - 60 \
                       %s \
                       AND b.dply_close IS NULL \
                     UNION \
                    SELECT UNIQUE a.ipolicy, a.iassured, a.nassured, a.itag \
                      FROM newa22:policy a, newa22:ply_relation b \
                     WHERE a.ipolicy = b.ipolicy \
                       AND b.dply_begin >= today - 60 \
                       %s \
                       AND b.dply_close IS NULL \
                     UNION \
                    SELECT UNIQUE a.ipolicy, a.iassured, a.nassured, a.itag \
                      FROM newa33:policy a, newa33:ply_relation b \
                     WHERE a.ipolicy = b.ipolicy \
                       AND b.dply_begin >= today - 60 \
                       %s \
                       AND b.dply_close IS NULL \
                     UNION \
                    SELECT UNIQUE a.ipolicy, a.iassured, a.nassured, a.itag \
                      FROM newa40:policy a, newa40:ply_relation b \
                     WHERE a.ipolicy = b.ipolicy \
                       AND b.dply_begin >= today - 60 \
                       %s \
                       AND b.dply_close IS NULL \
                     UNION \
                    SELECT UNIQUE a.ipolicy, a.iassured, a.nassured, a.itag \
                      FROM newa66:policy a, newa66:ply_relation b \
                     WHERE a.ipolicy = b.ipolicy \
                       AND b.dply_begin >= today - 60 \
                       %s \
                       AND b.dply_close IS NULL \
                     UNION \
                    SELECT UNIQUE a.ipolicy, a.iassured, a.nassured, a.itag \
                      FROM newa70:policy a, newa70:ply_relation b \
                     WHERE a.ipolicy = b.ipolicy \
                       AND b.dply_begin >= today - 60 \
                       %s \
                       AND b.dply_close IS NULL;", sTemp, sTemp, sTemp, sTemp, sTemp, sTemp );
    
    return M_CM_OK;
}
/******************************************************************************/
