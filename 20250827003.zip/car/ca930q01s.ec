/*************************************************/
/*						                         */
/*   PROGRAM : ca930q01s.ec                      */
/*             ���W�����D���ϴ�������ɧ@�~      */
/*						                         */
/*   DATE    : 2023/8/11	                     */
/*						                         */
/*	 output	 : CHyymmdd.txt					     */
/*						                         */
/*						                         */
/*************************************************/
#include <stdio.h>
#include <stdlib.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"

#include "api_xsrv.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"

#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"

#define SUCCESS                 1

/*-----------------------------------------------------------------------*/

DBinfo  *list;
static  int  count_db;

char    DBName[5];
char    outputf[80];

char    sApHome[30];
char    filename[30];

char    edbgn[11] , edend[11];
long    policy_cnt,endorse_cnt,cus_cnt,fir_cnt;

FILE    *fp;
int     flen;

EXEC SQL BEGIN DECLARE SECTION;
     char  eDbgn[11], eDend[11];
     long  lDbgn,     lDend;
     char  s[10],s1[10],s2[10],s3[10];
     char  userid[11];

     static char exec_time[20];     /*** �����s�@�ɶ� ***/

EXEC SQL END DECLARE SECTION;

long car930();

/*-----------------------------------------------------------------------*/
main(argc,argv)
int  argc;
char **argv;
{
     long  rtncode, rc;

     char  Message[1024];
     char  Message1[300];
     char  Message2[300];

     batchinit();
     strcpy(DBName,  isNULLstr(argv[1]));
     strcpy(userid,  isNULLstr(argv[2]));
     strcpy(edbgn,   isNULLstr(argv[3]));   /* ñ���� */
     strcpy(edend,   isNULLstr(argv[4]));
     strcpy(outputf, isNULLstr(argv[5]));

     strcpy(eDbgn, cm_to_infdate(edbgn));
     lDbgn = cm_ymd_cdate(edbgn);

     strcpy(eDend, cm_to_infdate(edend));
     lDend = cm_ymd_cdate(edend);

     if (db_select(DBName) == False)
     {
          EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
          return M_CM_DB_NOTOPEN;
     }

     if ((list=get_db_list(&count_db,DBName)) == (char*)0 )
     {
          EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
          return M_CM_NOT_DBLIST;
     }

     s[0]  = '\0';
     s1[0] = '\0';
     s2[0] = '\0';
     s3[0] = '\0';

     strcpy(s,cm_from_infdate_100(eDbgn));
     strcpy(s1,substring(s,1,3));
     strcpy(s2,substring(s,5,2));
     strcpy(s3,substring(s,8,2));

     rtncode = getApHome(sApHome);
     if (rtncode < 0)
     {
         return rtncode;
     }
     printf("sApHome:[%s]\n",sApHome);

     /**** ����ɶ� exec_time [YYYY-MM-DD HH:MM] ****/
     strcpy(exec_time, cm_get_sysd());
     printf("{CH%s%s%s}:EXECUTE TIME[%s]\n",s1,s2,s3,exec_time);
     /***********************************************/

     strncpy(filename," ",30);
     sprintf_s(filename, 30, "%s/rptftp/", sApHome);
     printf("{CH%s%s%s}:filename[%s]\n",s1,s2,s3,filename);

     rc = car930();
     if (rc != M_CM_OK)
         return rc;

     strcpy(Message,  "\n�Цܦ@�θ귽[N]/�d��[B]/�ɮפU���@�~[cmn202]�U���H�U�ɮ�!\n");

     sprintf_s(Message1,300,"�ɮפ@�GCH%s%s%s.txt\n",s1,s2,s3);
     sprintf_s(Message2,300,"�O���Ʀ@�G%ld��A����Ʀ@�G%ld��\n",policy_cnt,endorse_cnt);

     strcat(Message,Message1);
     strcat(Message,Message2);

     EWRITE(userid,M_CM_OK,Message);

     printf("END PROGRAM\n");
     return SUCCESS;

errexit:
     printf("SQLCODE=%d, sqlerrm=%s.\n",SQLCODE,sqlca.sqlerrm);
     flen=fprintf(fp,"SQLCODE=%d, sqlerrm=%s.\n",SQLCODE,sqlca.sqlerrm);
     fclose(fp);
}

long car930()
{
	EXEC SQL BEGIN DECLARE SECTION;
		char stmt[1024];
		char Iassured[11],Nassured[121],Itag[CA_TAG_NUM],Ipolicy[21],Dply_begin[11];
		char Dply_end[11],Status[2];
		char Iassured1[11],Nassured1[121],Itag1[CA_TAG_NUM],Iendorse[21];
		char Dply_begin1[10];
		char Dply_end1[10];
		long Dply_end_long = 0, Dply_begin_long = 0;
		long Dply_end_long1 = 0, Dply_begin_long1 = 0;
		long Dply_end_long2 = 0, Dply_begin_long2 = 0;
		long Dbirth_long = 0;
		char Dbirth[11], Icar_type[3];
		float Qcylinder = 0;
		int  id,ply_cnt = 0,edr_cnt = 0;
		char Iengine[CA_ENGINE_NUM],Iengine1[CA_ENGINE_NUM];
		char sIins_type[7];
		char sIins_type_Tmp[6];
		int  ccnt238;
		int  ccnt_edr = 0;

		char Fedr_class[3];    /*** ��������O ***/

		char filename1[200];

	EXEC SQL END DECLARE SECTION;

	int   k;
	char  file_catalog[200];
	char  syscmd[256];
	long  rc;

	EXEC SQL WHENEVER SQLERROR GOTO errexit;

	filename1[0]    = '\0';
	file_catalog[0] = '\0';
	syscmd[0] = '\0';

	policy_cnt  = 0;
	endorse_cnt = 0;

	sprintf_s(filename1,200,"CH%s%s%s.txt",s1,s2,s3);
	strcpy(file_catalog, trim(filename));
	strcat(file_catalog, trim(filename1));

	sprintf_s(syscmd,256,"cp %s %scar930/%s",file_catalog,filename,filename1);
	printf("---- syscmd = [%s] \n",syscmd);

	fp=fopen(file_catalog,"w");

	EXEC SQL SET LOCK MODE TO WAIT;

	printf("Start SQL\n\n");
	for(k=0 ; k<count_db ; k++)
	{
		/**** status:A-�s�W U-��� D-�R�� X-�L�� ****/
		
		/*********************** �O�� **************************/
		stmt[0]='\0';
		sprintf_s(stmt,1024,
				" select count(*) "
				" from %s:ply_ins_type "
				" where ipolicy = ? and iins_type = ? ", list[k].dbname);
		$prepare get_ins from $stmt;
		
		stmt[0]='\0';
		sprintf_s(stmt,1024,
				" select %s %s from %s:%s, %s:%s, %s:%s where %s %s %s %s %s %s",
				"a.ipolicy, b.nassured, b.itag, b.iengine, a.dply_begin, ",
				"a.dply_end, b.iassured, b.dbirth, a.icar_type, b.qcylinder ",
				 list[k].dbname,
				"ori_ply_relation a ",
				 list[k].dbname,
				"original_ply b ",
				list[k].dbname,
				"ply_ins_type c ",
				" a.dpolicy between ? AND ? ",
				" and a.ipolicy = b.ipolicy ",
				" and a.ipolicy = c.ipolicy ",
				" and a.fcard_class = '2' ",
				" and a.icar_type IN ('01','02','34') ",
				" and c.iins_type = '238' ");
				
				
				
		EXEC SQL PREPARE PLY_CUR1 FROM :stmt;
		EXEC SQL DECLARE curA CURSOR FOR PLY_CUR1;
		EXEC SQL OPEN    curA USING $lDbgn , $lDend;
		
		printf("stmt=[%s]\n\n", stmt);
		while(1)
		{
			$FETCH curA INTO $Ipolicy, $Nassured, $Itag, $Iengine, 
							 $Dply_begin_long, $Dply_end_long, $Iassured, 
							 $Dbirth_long, $Icar_type, $Qcylinder;
			
			if (SQLCODE==SQLNOTFOUND) break;
			
			if ((Itag[0]==' ') || (Itag[0]=='\0'))
			{
				strcpy(Itag,"        ");
			}
			
			strcpy(Dply_begin,cm_sysd_edate(cm_cdate_str_100(Dply_begin_long)));
            strcpy(Dply_end,cm_sysd_edate(cm_cdate_str_100(Dply_end_long)));
			strcpy(Dbirth,cm_sysd_edate(cm_cdate_str_100(Dbirth_long)));
			
			strcpy(Status,"A");
			
			ccnt238 = 0;
			
			strcpy(sIins_type_Tmp,"      ");
			
			strcpy(sIins_type,"238");
			$execute get_ins 
				into $ccnt238
			   using $Ipolicy,$sIins_type;
			
			if(ccnt238 > 0)
			{
				strcpy(sIins_type_Tmp,"238   ");
			}
			else
			{
			   strcpy(sIins_type_Tmp,"      ");
			}
			printf("%s, %s, %s, %s, %s, %s, %s, %s, %s, %7.2f, %s, %s\n", 
							Ipolicy,Nassured,Itag,Iengine,Dply_begin,Dply_end,Iassured,Dbirth,Icar_type,Qcylinder,sIins_type_Tmp,Status);
            flen=fprintf(fp,"%s|~%s|~%s|~%s|~%s|~%s|~%s|~%s|~%s|~%7.2f|~%s|~%s\n", 
							Ipolicy,Nassured,Itag,Iengine,Dply_begin,Dply_end,Iassured,Dbirth,Icar_type,Qcylinder,sIins_type_Tmp,Status);
			policy_cnt += 1;
        }
		$CLOSE curA;
		$FREE  curA;
		
		
		/*********************** ��� **************************/
		stmt[0]='\0';
		sprintf_s(stmt,1024,
			  " select count(*)                      "
			  " from %s:edr_ins_type                 "
			  " where iendorse = ? and iins_type = ? ", list[k].dbname);
		$prepare get_edr_ins from $stmt;
		
		stmt[0]='\0';
		sprintf_s(stmt,1024,
				" select %s %s from %s:%s, %s:%s, %s:%s where %s %s %s %s %s %s %s %s",
				" a.fedr_class, a.iendorse, a.ipolicy, b.nassured, b.itag, b.iengine, ",
				" a.dedr_begin, a.dedr_end, b.iassured, b.dbirth, a.icar_type, b.qcylinder ",
				 list[k].dbname,
				"edr_relation a ",
				 list[k].dbname,
				"endorsement b ",
				 list[k].dbname,
				"edr_ins_type c ",
				" a.dendorse between ? AND ? ",
				" and a.dedr_close is not null ",
				" and a.iendorse = b.iendorse ",
				" and a.iendorse = c.iendorse ",
				" and a.fedr_class not in ('A','B') ",
				" and a.fcard_class = '2' ",
				" and a.icar_type IN ('01','02','34') ",
				" and c.iins_type = '238' ");
		
		EXEC SQL PREPARE EDR_CUR1 FROM :stmt;
		EXEC SQL DECLARE curB CURSOR FOR EDR_CUR1;
		EXEC SQL OPEN    curB USING $lDbgn , $lDend;
		for(;;)
		{
			$FETCH curB INTO $Fedr_class, $Iendorse, $Ipolicy, $Nassured, $Itag, $Iengine, 
							 $Dply_begin_long, $Dply_end_long, $Iassured, 
							 $Dbirth_long, $Icar_type, $Qcylinder;
			
			if (SQLCODE==SQLNOTFOUND) break;
			
			if ((Itag[0]==' ') || (Itag[0]=='\0'))
			{
				strcpy(Itag,"        ");
			}
			
			strcpy(Dply_begin , cm_sysd_edate(cm_cdate_str_100(Dply_begin_long)));
            strcpy(Dply_end   , cm_sysd_edate(cm_cdate_str_100(Dply_end_long)));
			strcpy(Dbirth,cm_sysd_edate(cm_cdate_str_100(Dbirth_long)));
			
			strcpy(Fedr_class, trim(Fedr_class));
			
			/*** ���P ***/
			if (strcmp(Fedr_class,"1")==0)
			{
				strcpy(Status,"D");
			}
			
			/*** �h���h�O ***/
			if (strcmp(Fedr_class,"4")==0)
			{
				strcpy(Status,"X");
			}
			
			/*** �L�� : ���N�I�L�L�� ***/
			if (strcmp(Fedr_class,"2")==0 || strcmp(Fedr_class,"8")==0)
			{
				strcpy(Status,"U");
			}
			
			/*** �@���� ***/
			if (strcmp(Fedr_class,"5")==0)
			{
				Iassured1[0] = '\0';
				Nassured1[0] = '\0';
				Itag1[0]     = '\0';

				stmt[0]      = '\0';
				sprintf_s(stmt,1024, " SELECT %s FROM %s:%s WHERE %s ",
							  " iassured , nassured , itag, iengine ",
							    list[k].dbname,
							  " original_ply ",
							  " ipolicy = ? ");

				EXEC SQL PREPARE EDR_CUR_TMP_5 FROM :stmt;
				EXEC SQL DECLARE edr_cur_5 CURSOR FOR EDR_CUR_TMP_5;
				EXEC SQL OPEN    edr_cur_5 USING  $Ipolicy;
				EXEC SQL FETCH   edr_cur_5 INTO
					 $Iassured1, $Nassured1, $Itag1, $Iengine1;
				EXEC SQL CLOSE   edr_cur_5;

				if ((Itag1[0]==' ') || (Itag1[0]=='\0'))
				{
					strcpy(Itag1,"        ");
				}
					
				if ((strcmp(Iassured , Iassured1) != 0) ||
					(strcmp(Nassured , Nassured1) != 0) ||
					(strcmp(Itag     , Itag1)     != 0) ||
					(strcmp(Iengine  , Iengine1)  != 0))
				{
					/*strcpy(Iassured , Iassured1);
					strcpy(Nassured , Nassured1);
					strcpy(Itag     , Itag1);
					strcpy(Iengine  , Iengine1);*/

					strcpy(Status,"U");
				}
				else
				{
					continue;
				}
			}
			
			/*** ���h[�O] ***/
			if (strcmp(Fedr_class,"6")==0)
			{
				stmt[0]='\0';
				sprintf_s(stmt,1024, " SELECT %s FROM %s:%s WHERE %s %s ",
							  " count(*) ",
							    list[k].dbname,
							  " edr_ins_type ",
							  " iendorse = ? ",
							  " AND iedr_type in ('02','03') ");

				EXEC SQL PREPARE EDR_CUR_TMP6 FROM :stmt;
				EXEC SQL DECLARE edr_cur_cnt6 CURSOR FOR EDR_CUR_TMP6;
				EXEC SQL OPEN    edr_cur_cnt6 USING  $Iendorse;
				EXEC SQL FETCH   edr_cur_cnt6 INTO   $edr_cnt;
				EXEC SQL CLOSE   edr_cur_cnt6;

				stmt[0]='\0';
				sprintf_s(stmt,1024, " SELECT %s FROM %s:%s WHERE %s ",
							  " count(*) ",
							    list[k].dbname,
							  " ori_ins_type ",
							  " ipolicy = ? ");

				EXEC SQL PREPARE EDR_CUR_TMP2 FROM :stmt;
				EXEC SQL DECLARE edr_cur_cnt2 CURSOR FOR EDR_CUR_TMP2;
				EXEC SQL OPEN    edr_cur_cnt2 USING  $Ipolicy;
				EXEC SQL FETCH   edr_cur_cnt2 INTO   $ply_cnt;
				EXEC SQL CLOSE   edr_cur_cnt2;

				if (edr_cnt==ply_cnt)
				{
					strcpy(Status,"X");
				}
				else
				{
					sprintf_s(stmt,1024, " SELECT count(*)   "
								  " FROM %s:edr_ins_type     "
								  " WHERE iendorse = ?       "
								  " AND iins_type IN ('238') "  
								  " AND iedr_type = '05' ",list[k].dbname);
					
					$PREPARE get_edr_id FROM $stmt;
					$EXECUTE get_edr_id 
						INTO $ccnt_edr
					   USING $Iendorse;
					
					if (ccnt_edr == 0)
					{
						continue;
					}
					else
					{
						strcpy(Status,"U");
					}
				}
			}
			
			/*** ���� ***/
			if (strcmp(Fedr_class,"9")==0)
			{
				stmt[0] = '\0';
				sprintf_s(stmt,1024, " SELECT %s %s FROM %s:%s %s:%s WHERE %s %s ",
							  " b.iassured, b.itag, b.nassured, ",
							  " a.dply_begin, a.dply_end, b.iengine ",
							    list[k].dbname,
							  " ori_ply_relation a, ",
							    list[k].dbname,
							  " original_ply b ",
							  " a.ipolicy = ? ",
							  " AND a.ipolicy = b.ipolicy ");

				EXEC SQL PREPARE EDR_CUR_TMP_9 FROM :stmt;
				EXEC SQL DECLARE edr_cur_9 CURSOR FOR EDR_CUR_TMP_9;
				EXEC SQL OPEN    edr_cur_9 USING  $Ipolicy;
				EXEC SQL FETCH   edr_cur_9 INTO   $Iassured1,$Itag1,$Nassured1, 
												  $Dply_begin_long2,$Dply_end_long2,$Iengine1;
				EXEC SQL CLOSE   edr_cur_9;

				if ((Itag1[0]==' ') || (Itag1[0]=='\0'))
				{	
					strcpy(Itag1,"        ");
				}

				stmt[0] = '\0';
				sprintf_s(stmt,1024," SELECT %s FROM %s:%s %s:%s WHERE %s %s ",
							 " a.dply_begin, a.dply_end ",
							   list[k].dbname,
							 " ply_relation a, ",
							   list[k].dbname,
							 " policy b ",
							 " a.ipolicy = ? ",
							 " AND a.ipolicy = b.ipolicy ");

				EXEC SQL PREPARE EDR_CUR_TMP_9_1 FROM :stmt;
				EXEC SQL DECLARE edr_cur_9_1 CURSOR FOR EDR_CUR_TMP_9_1;
				EXEC SQL OPEN    edr_cur_9_1 USING  $Ipolicy;
				EXEC SQL FETCH   edr_cur_9_1 INTO   $Dply_begin_long1, $Dply_end_long1;
				EXEC SQL CLOSE   edr_cur_9_1;

				if ((strcmp(Iassured , Iassured1) != 0) ||
					(strcmp(Itag     , Itag1)     != 0) ||
					(strcmp(Nassured , Nassured1) != 0) ||
					(strcmp(Iengine  , Iengine1)  != 0))
				{
					strcpy(Status,"U");

					/* strcpy(Iassured , Iassured1);
					 strcpy(Nassured , Nassured1);
					 strcpy(Itag     , Itag1);
					 strcpy(Iengine  , Iengine1);*/
				}

				if ((Dply_begin_long1 != Dply_begin_long2) ||
					(Dply_end_long1   != Dply_end_long2))
				{
					strcpy(Status,"U");

					strcpy(Dply_begin , cm_sysd_edate(cm_cdate_str_100(Dply_begin_long1)));
					strcpy(Dply_end   , cm_sysd_edate(cm_cdate_str_100(Dply_end_long1)));
				}

				if ((strcmp(Iassured , Iassured1) == 0) &&
					(strcmp(Itag     , Itag1)     == 0) &&
					(strcmp(Iengine  , Iengine1)  == 0) &&
					(strcmp(Nassured , Nassured1) == 0) &&
					(Dply_begin_long1 == Dply_begin_long2) &&
					(Dply_end_long1   == Dply_end_long2))
				{
					stmt[0] = '\0';
					sprintf_s(stmt,1024,
							" SELECT count(*)          "
							" FROM %s:edr_ins_type     "
							" WHERE iendorse = ?       "
							" AND iins_type IN ('238') " 
							" AND iedr_type = '05' ",list[k].dbname);
					
					$PREPARE get_edr_ida FROM $stmt;
					$EXECUTE get_edr_ida 
					    INTO $ccnt_edr
					   USING $Iendorse;
					if (ccnt_edr == 0)
					{
						continue;
					}
					else
					{
						strcpy(Status,"U");
					}
				}
			}
			
			if ((Status[0]==' ') || (Status[0]=='\0')) 
			{
				if ((strcmp(Iassured , Iassured1) != 0) ||
					(strcmp(Nassured , Nassured1) != 0) ||
					(strcmp(Itag     , Itag1)     != 0) ||
					(strcmp(Iengine  , Iengine1)  != 0))
				{
				   /* strcpy(Iassured , Iassured1);
					strcpy(Nassured , Nassured1);
					strcpy(Itag     , Itag1);
					strcpy(Iengine  , Iengine1);*/

					strcpy(Status,"U");
				}
				else
				{
					stmt[0] = '\0';
					sprintf_s(stmt,1024,
							" SELECT count(*)          "
							" FROM %s:edr_ins_type     "
							" WHERE iendorse = ?       "
							" AND iins_type IN ('238') "
							" AND iedr_type = '05' ",list[k].dbname);
					
					$PREPARE get_edr_idb FROM $stmt;
					$EXECUTE get_edr_idb 
						INTO $ccnt_edr
					   USING $Iendorse;
					if (ccnt_edr == 0)
					{
						continue;
					}
					else
					{
						strcpy(Status,"U");
					}
				}
			}

			ccnt238 = 0;
			strcpy(sIins_type_Tmp,"      ");

			strcpy(sIins_type,"238");
			if (strcmp(Fedr_class,"2")==0 || strcmp(Fedr_class,"8")==0)
			{
				$execute get_ins 
					into $ccnt238
				   using $Ipolicy, $sIins_type;
			}
			else
			{
				$execute get_edr_ins
					into $ccnt238
				   using $Iendorse, $sIins_type;
			}

			if (ccnt238 > 0)
			{
				strcpy(sIins_type_Tmp,"238   ");
				
			}
			else
			{
				strcpy(sIins_type_Tmp,"      ");
			}
			printf("%s, %s, %s, %s, %s, %s, %s, %s, %s, %7.2f, %s, %s\n", 
							Ipolicy,Nassured,Itag,Iengine,Dply_begin,Dply_end,Iassured,Dbirth,Icar_type,Qcylinder,sIins_type_Tmp,Status);
			flen=fprintf(fp,"%s|~%s|~%s|~%s|~%s|~%s|~%s|~%s|~%s|~%7.2f|~%s|~%s\n", 
							Ipolicy,Nassured,Itag,Iengine,Dply_begin,Dply_end,Iassured,Dbirth,Icar_type,Qcylinder,sIins_type_Tmp,Status);
			endorse_cnt += 1;
			strcpy(Status," ");
		}
		$CLOSE curB;
        $FREE  curB;
	}
	printf("End SQL\n\n");
	fclose(fp);

    rc = system(syscmd);
    EXEC SQL SET LOCK MODE TO NOT WAIT;

    EXEC SQL INSERT INTO rptftplist (nuserid, ipgid,     noutfile,   dcreate)
                              VALUES ($userid, 'car930',  $filename1, $exec_time);

    return M_CM_OK;

errexit:
    printf("SQLCODE=%d, sqlerrm=%s.\n",SQLCODE,sqlca.sqlerrm);
    flen=fprintf(fp,"SQLCODE=%d, sqlerrm=%s.\n",SQLCODE,sqlca.sqlerrm);
    fclose(fp);
}


