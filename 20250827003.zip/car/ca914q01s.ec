/**********************************************************************/
/*   program id   : ca914q01s.ec                                      */
/*   program name : ��˽߮ש��Ӫ�                                    */
/*   date written : 2004/03/29                                        */
/*   date modify  : 2006/12/08                                        */
/**********************************************************************/
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
#include <time.h>
#include "safeclib.h"
/*--------------------------------------------------------------------*/
DBinfo *list;
int    count_db, i;
int    count;
 
char   tmp_buf[16];
float  tused=0;
time_t tstart,tstop;
int    fetch;

$char ibranch[3],ipolicy[21];
$char iclaim[21],iadjuster[11],fstl[2];
$int  iclose_type = 0;
$char dclaim[17],dclose[17],nassured[31];
$char itag[CA_TAG_NUM],iofficer[11],iacc_reason[3];
$char daccident[17],ibranch_in[3],fcard_class[2];
$char iins_type[7],ivictim[11];
$long mins_app,mins_stl,mpayment;
$char iflag[2],str_flag[2],ivictim_flag[2];
$char dply_begin[11],dpolicy[11],iresource[2];
$char iassured[11];
$char ipayment[11],nchi_full[31],xfpay_cond[2];
$char iacc_license[11];
$char irelative_clm[21];
$char flast[2],frecover[2];
$char sWhere1[101],sWhere2[64];

$char dbgn1[11],dend1[11];
$char dbgn2[11],dend2[11];
$char stmt_buf[5000];
$char poldbname[50],clmdbname[50];
$char DBName[05], iForm_Tp[03];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1];
char  outputf[N_FILE+1], userid[11];

char  msgbuf[100];
$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;

static int  max_cnt,num;
long car914_get_db();
long car914_build();
void car914_title();
long car914_body();
long car914_print();
/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{  
   int rc;
   batchinit();
   strcpy(DBName, isNULLstr(argv[1]));
   strcpy(userid, isNULLstr(argv[2]));
   strcpy(ibranch, isNULLstr(argv[3]));
   strcpy(dbgn2, isNULLstr(argv[4]));
   strcpy(dend2, isNULLstr(argv[5]));
   strcpy(iflag, isNULLstr(argv[6]));
   strcpy(outputf,isNULLstr(argv[7]));

   strcpy(dbgn1, cm_to_infdate(dbgn2));
   strcpy(dend1, cm_to_infdate(dend2));  
   
    if (ibranch[0] == '*')
       strcpy(sWhere1," ");
   else
       sprintf_s(sWhere1,101," AND a.iclaim[1,2] = '%s' ",ibranch);
   
   printf(" iflag[%s]\n",iflag);
   rc = car914_get_db();
    if (rc != SUCCESS)
       return rc;

   max_cnt=0;
   rc = car914_build();
   if ( rc != FAIL){
      if ((rc=save_form_info(F_BLK0, "CA", 914, userid, iForm_Tp,
                             max_cnt, outputf))<0)
      {
          strcpy(msgbuf,"save_form_info failed");
          return rc;
      }
  }
}
/*--------------------------------------------------------------------*/
long car914_build()
{
   $char  TitleFmt[N_FILE+1],BodyFmt[N_FILE+1];
   int    rc;

   $WHENEVER SQLERROR GOTO errexit;  

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 914;

   strcpy( TitleFmt,rtrim(TitleFmt));
   strcpy( BodyFmt,rtrim(BodyFmt));
   sprintf_s( TitleFile, N_FILE+1,"%s.ti",outputf);
   sprintf_s( BodyFile, N_FILE+1,"%s.bd",outputf);

printf("titlefmt = [%s]\n",TitleFile);

   rgu_init_report(TitleFmt,TitleFile);
   car914_title();
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);
   rc = car914_body();
   if (rc != M_CM_OK)
       return rc;

printf( " next is M_CM_OK \n");           
   return M_CM_OK;

errexit:
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;  
}
   
long car914_get_db()
{
   if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }
    
   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   return SUCCESS;

errexit:

   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

void car914_title()
{
  rgu_put_head();
}

long car914_body()
{
   int ins; 
   int rc;  
   char FullDBName[50];
   int vic_flag;
   
    $WHENEVER SQLERROR GOTO errexit;    

    rgu_put_body_string(1,dbgn1,1);
    rgu_put_body_string(1,dend1,1);
    rgu_put_body_string(1,cm_get_sysd(), 1);
    rgu_put_body(1);
    time(&tstart);
     
    for(i=0;i<count_db;i++) {
        sprintf_s(stmt_buf,5000,
          "select a.iclaim[1,2],a.ipolicy,      \
                  a.iclaim,a.adjustment,  \
                  a.dclaim,a.dclose,b.iassured,b.nassured, \
                  b.itag,b.iofficer,c.iacc_reason, \
                  date(c.daccident),a.ibranch_in,c.fcard_class, \
                  c.iacc_license ,c.irelative_clm, \
                  d.dply_begin, d.dpolicy, d.iresource \
             from ca_clm_process a,%s:adjustment_ply b,%s:appraisal c, \
                  %s:ply_relation d \
            where a.dclaim >= ? and a.dclaim <= ? %s \
              and a.iclaim = b.iclaim \
              and a.iclaim = c.iclaim \
              and c.ipolicy = d.ipolicy \
             order by 1,7 ",list[i].dbname,list[i].dbname,list[i].dbname,
                  sWhere1);
        printf("stmt[%s]\n",stmt_buf);
        EXEC SQL PREPARE Acursor  FROM :stmt_buf;
        EXEC SQL DECLARE Acursor1 CURSOR FOR Acursor;
        EXEC SQL OPEN Acursor1 USING $dbgn1, $dend1;
        mins_stl=mins_app=0; 
        while (1) {
          EXEC SQL FETCH Acursor1 INTO :ibranch,:ipolicy,
                                       :iclaim,:iadjuster,
                                       :dclaim,:dclose,:iassured,:nassured,
                                       :itag,:iofficer,:iacc_reason,
                                       :daccident,:ibranch_in,:fcard_class,
                                       :iacc_license,:irelative_clm,
                                       :dply_begin,:dpolicy,:iresource;

          if (SQLCODE == SQLNOTFOUND) break;
        
          printf("iclaim[%s]\n",iclaim);
          sprintf_s(stmt_buf,5000,
             "SELECT  b.mpayment,b.fstl,b.iclose_type, \
                      b.ipayment,b.nchi_full[1,30],b.xfpay_cond,frecover  \
                FROM  %s:payment b,%s:settlement c \
               WHERE  b.iclaim = ?        \
                 AND  b.fstl <> '2'       \
                 AND  b.iclaim = c.iclaim \
                 AND  b.fstl = c.fstl     \
                 AND  b.iclose_type = c.iclose_type \
                 AND  b.pay_kind = '5'    ",list[i].dbname,list[i].dbname);
           
          printf("stmt_buf[%s]\n",stmt_buf);
          $PREPARE Acursor  FROM $stmt_buf;
          $DECLARE Acursorapp CURSOR FOR Acursor;
          $OPEN Acursorapp USING $iclaim;
          while(1) {       
              $FETCH Acursorapp INTO $mpayment,$fstl,$iclose_type,
                     $ipayment,$nchi_full,$xfpay_cond,$frecover;
        
              if (SQLCODE == SQLNOTFOUND) break;
            
              printf(" ****** ipayment[%s]\n",ipayment);  

              strcpy(ivictim," ");
              if (strcmp(fcard_class,"1")==0) {  /* �j���I */
                  vic_flag = 0;
                  strcpy(sWhere2,"AND ivictim = '%s' ",ipayment);
                  victim_start:
                  sprintf_s(stmt_buf,5000,
                       "SELECT  iins_item,ivictim,max(flast),sum(mins_stl) \
                          FROM  %s:ca_stl_victim          \
                         WHERE  iclaim = ?   %s           \
                           AND  fstl = ? AND iclose_type = ? \
                         GROUP BY 2,1                     \
                         HAVING sum(mins_stl) != 0        \
                         ORDER BY 2,1  ",list[i].dbname,sWhere2);
           
                  $PREPARE Acursor  FROM $stmt_buf;
                  $DECLARE Acursorgroup CURSOR FOR Acursor;
                  $OPEN Acursorgroup USING $iclaim, $fstl, $iclose_type;
                  printf(" stmt_buf[%s]\n",stmt_buf);            
                  while(1) {       
                      $FETCH Acursorgroup INTO $iins_type,$ivictim,
                                               $flast,$mins_stl; 
            
                      if (SQLCODE == SQLNOTFOUND) break;
                      vic_flag = 1;
      
                      sprintf_s(stmt_buf,5000,"select sum(mapp_cover) \
                                          from %s:ca_app_victim  \
                                         where iclaim = ?  \
                                           and ivictim = ? \
                                           and iins_item = ? ",list[i].dbname);
                      $prepare pre_app from $stmt_buf;
                      $execute pre_app into $mins_app
                                      using $iclaim,$ivictim,$iins_type;

                      rc=car914_print();
                      if (rc != M_CM_OK)
                         return rc;
                  } /* end of ca_stl_victim  */
                  if (vic_flag==0) {
                      vic_flag=2;
                      strcpy(sWhere2," ");
                      goto victim_start;
                  }
                  $CLOSE Acursorgroup;
              }  /* end if fcard_class = '1' */ 
              else {        
                  sprintf_s(stmt_buf,5000,
                    "SELECT iins_type,sum(mins_stl),max(flast) \
                       FROM %s:stl_ins_type \
                      WHERE iclaim = ? \
                        AND fstl = ? AND iclose_type = ? \
                        AND iins_type in ('93','94','4A','4B','4C','193','194') \
                      GROUP BY 1 HAVING sum(mins_stl) != 0 ",list[i].dbname);
           
                  printf(" stmt_buf [%s]\n",stmt_buf);
                  $PREPARE Acursor  FROM $stmt_buf;
                  $DECLARE Acursorstl CURSOR FOR Acursor;
                  $OPEN Acursorstl USING $iclaim, $fstl, $iclose_type;
                  while(1) {
                      $FETCH Acursorstl INTO $iins_type,$mins_stl,$flast;
                                   
                      if (SQLCODE == SQLNOTFOUND) break;

                      sprintf_s(stmt_buf,5000,"select sum(mins_app) \
                                  from %s:app_ins_type  \
                                 where iclaim = ?  \
                                   and iins_type = ?  ",list[i].dbname);
                      $prepare pre_app_2 from $stmt_buf;
                      $execute pre_app_2 into $mins_app
                                        using $iclaim,$iins_type;

                      rc=car914_print();
                      if (rc != M_CM_OK)
                      return rc;
                  }
                  $CLOSE Acursorstl;
              }    /* end if fcard_class = '2' */
          } /* end of payment */
      }/*End While*/
      EXEC SQL CLOSE Acursor1;
   } /* end of dblist */
   EXEC SQL FREE Acursor1;

   time(&tstop);
   tused=difftime(tstop,tstart);
   printf("�������=%f��\n",tused);
   
   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

long car914_print()
{
   int ins; 
   char tmp_buf[16];  
   $char nname[13],nbranch[15];
   $char officer_nname[13];
   $char nabbr[20],ncode[20];
   $char str_ncond[20],str_frecover[20];
   $WHENEVER SQLERROR GOTO errexit;  
   
   $select nchi_full
      into $nbranch
      from v_branch
     where ibranch = $ibranch;
     
   $select nname
      into $nname
      from officer
     where iofficer = $iadjuster;
      
   $select nname
      into $officer_nname
      from officer
     where iofficer = $iofficer;     
     
   $select nabbr
      into $nabbr
      from adjustment_code
     where fclass="1" 
       and icode=$iacc_reason;
       
   $select ncode
      into $ncode
      from cu_code_data
     where itype="10" 
       and icode=$iresource;     
       
   if(strcmp(xfpay_cond,"1")==0)
   { strcpy(str_ncond,"�{ ��");  } 
   else if(strcmp(xfpay_cond,"2")==0)
   { strcpy(str_ncond,"�} ��");  }
   else
   { strcpy(str_ncond,"�� ��");  }
   
   if(strcmp(frecover,"0")==0)
   { strcpy(str_frecover,"���ݰl�v");  } 
   else if(strcmp(frecover,"1")==0)
   { strcpy(str_frecover,"�ۦ�l�v");  }
   else if(strcmp(frecover,"2")==0)
   { strcpy(str_frecover,"�w�ۦ�l�v");}
   else if(strcmp(frecover,"3")==0)
   { strcpy(str_frecover,"�k�Ȱl�v");}
   else if(strcmp(frecover,"4")==0)
   { strcpy(str_frecover,"�۰l��k�l");}
   else
   { strcpy(str_frecover,"�j���I�u��");}  

   rgu_put_body_string(2,trim(nbranch),1);           /* ���z��� */
   rgu_put_body_string(2,nassured,1);                /* �Q�O�I�H */
   rgu_put_body_string(2,trim(ipolicy),1);           /* �O�渹�X */
   rgu_put_body_string(2,trim(itag),1);              /* ���P���X */
   rgu_put_body_string(2,iclaim,1);                  /* �߮׸��X */
   rgu_put_body_string(2,trim(nname),1);             /* �z�߸g�� */
   rgu_put_body_string(2,trim(nabbr),1);             /* �X�I��] */
   rgu_put_body_string(2,dply_begin,1);              /* �ͮĤ�� */
   rgu_put_body_string(2,dpolicy,1);                 /* ñ���� */
   rgu_put_body_string(2,daccident,1);               /* �X�I��   */
   rgu_put_body_string(2,dclaim,1);                  /* ���z��   */
   rgu_put_body_string(2,dclose,1);                  /* �鵲��   */
   rgu_put_body_string(2,iins_type,1);               /* �I��     */
   rfmtlong(mins_app,"-##,###,##&",tmp_buf);         /* �w�����B */
   rgu_put_body_string(2,trim(tmp_buf),1);    
   rfmtlong(mins_stl,"-##,###,##&",tmp_buf);         /* �ߥI���B */
   rgu_put_body_string(2,trim(tmp_buf),1); 
   rgu_put_body_string(2,ncode,1);                   /* �~�Ȩӷ� */
   rgu_put_body_string(2,officer_nname,1);           /* �X��g�� */
   rgu_put_body_string(2,nchi_full,1);               /* �ߥI��H�W�� */
   rfmtlong(mpayment,"-##,###,##&",tmp_buf);         /* �ߥI���B */
   rgu_put_body_string(2,trim(tmp_buf),1);      
   rgu_put_body_string(2,ipayment,1);                /* �ߥI��Hid */ 
   rgu_put_body_string(2,iassured,1);                /* �Q�O�I�Hid */ 
   rgu_put_body_string(2,iacc_license,1);            /* �r �p �Hid */ 
   printf(" ivictim[%s]\n",ivictim);    
   rgu_put_body_string(2,ivictim,1);                 /* �� �` �Hid */ 
   if (strcmp(ipayment,iassured)==0)
      strcpy(str_flag,"1");
   else if (strcmp(ipayment,iacc_license)==0)
      strcpy(str_flag,"2");
   else if (strcmp(ipayment,ivictim)==0)
      strcpy(str_flag,"3");
   else
      strcpy(str_flag,"4");
   rgu_put_body_string(2,str_flag,1);                /* �ߥI��H���O */
   rgu_put_body_string(2,trim(str_ncond),1);         /* �I�ڤ覡     */
   rgu_put_body_string(2,trim(str_frecover),1);      /* �l�v�O       */
   rgu_put_body_string(2,flast,1);                   /* ���קO       */
   
   rgu_put_body(2);
   count ++;

   return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(FAIL);
}
 
