/**********************************************************************/
/*   program id   : ca742q02s.ec                                      */
/*   program name : �j��q�l���Ҳέp����-ñ��                         */
/*   date written : 2021/10/26 by 041090                              */
/*   files        :                                                   */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <decimal.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "globdata.h"

$char dpolicy_bgn_tmp[11],dpolicy_end_tmp[11];
$char dpolicy_bgn[11],dpolicy_end[11];

int   count_db,k; 
char  outputf[21];
$char userid[11];
$char DBName[05];
$char msgbuf[128];

DBinfo *list;

main(argc, argv)
int argc;
char **argv;
{
 int rc;

	batchinit();
	strcpy(DBName,            isNULLstr(argv[1]));
	strcpy(userid,            isNULLstr(argv[2]));
	strcpy(dpolicy_bgn_tmp,   isNULLstr(argv[3]));
	strcpy(dpolicy_end_tmp,   isNULLstr(argv[4]));
	strcpy(outputf,           isNULLstr(argv[5]));
	
	strcpy(dpolicy_bgn,cm_to_infdate(dpolicy_bgn_tmp));
	strcpy(dpolicy_end,cm_to_infdate(dpolicy_end_tmp));

	rc = car7422_get_db();
	if (rc != M_CM_OK)
		return rc;

	rc = car7422_prepare_data();
	if (rc != M_CM_OK)
		return rc;

	rc = car7422_build();
	if (rc != M_CM_OK) 
		return rc;
		
	$DROP TABLE ply_tmp;
	$DROP TABLE ply_tmp1;
	$DROP TABLE bzfrom_tmp;
	$DROP TABLE ply_renew_trade;
	$DROP TABLE ply_ecard;
	$DROP TABLE ply_phone_mail;
	$DROP TABLE ply_sendecard;
}

long car7422_get_db()
{
	$whenever sqlerror goto errexit;

	if (db_select(DBName) == FALSE) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}

long car7422_prepare_data()
{
	$char stmt[4096],stmp1[4096],stmp2[4096];
	$char stmp_cont[1024];
	
	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == FALSE)
	{
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return FAIL;
	}

	$CREATE TEMP TABLE ply_tmp
	(
		ipolicy      CHAR (20),
		icard        CHAR (20),
		bzfrom       CHAR (2),
		fassured     CHAR (1),
		ileader      CHAR (10),
		feply        CHAR (1),
		itmp_policy  CHAR (20),
		tmobile_eply VARCHAR (20),
		aemail_eply  VARCHAR (50),
		mobil_phone  char (20),
		iemail       VARCHAR (50),
		tmobile_appl VARCHAR (20),
		aemail_appl  VARCHAR (50),
		dpolicy      DATE,
		iexaminer    CHAR (10),
		ientry       CHAR (10),
		dnotifyornot DATETIME YEAR TO second,
		frenew       CHAR (1)
	)with no log;
	$CREATE INDEX ply_tmp_ind0 ON ply_tmp(ipolicy);
	$CREATE INDEX ply_tmp_ind1 ON ply_tmp(bzfrom);
	$CREATE INDEX ply_tmp_ind2 ON ply_tmp(fassured);
	$CREATE INDEX ply_tmp_ind3 ON ply_tmp(frenew);
	$CREATE INDEX ply_tmp_ind4 ON ply_tmp(dnotifyornot);

	$CREATE TEMP TABLE ply_tmp1
	(
		ipolicy      CHAR (20),
		icard        CHAR (20),
		bzfrom       CHAR (2),
		fassured     CHAR (1),
		ileader      CHAR (10),
		feply        CHAR (1),
		itmp_policy  CHAR (20),
		tmobile_eply VARCHAR (20),
		aemail_eply  VARCHAR (50),
		mobil_phone  CHAR (20),
		iemail       VARCHAR (50),
		tmobile_appl VARCHAR (20),
		aemail_appl  VARCHAR (50),
		dpolicy      DATE,
		iexaminer    CHAR (10),
		ientry       CHAR (10),
		frenew       CHAR (1),
		dnotifyornot DATETIME YEAR TO second
	)with no log;
	$CREATE INDEX ply_tmp10 ON ply_tmp1(ipolicy);
	$CREATE INDEX ply_tmp11 ON ply_tmp1(fassured);
	$CREATE INDEX ply_tmp12 ON ply_tmp1(tmobile_eply);
	$CREATE INDEX ply_tmp13 ON ply_tmp1(aemail_eply);
	$CREATE INDEX ply_tmp14 ON ply_tmp1(ientry);
	$CREATE INDEX ply_tmp15 ON ply_tmp1(iexaminer);
	$CREATE INDEX ply_tmp16 ON ply_tmp1(frenew);
	$CREATE INDEX ply_tmp17 ON ply_tmp1(dnotifyornot);

	/* f_NL-N:�۵M�H L:�k�H */
	/*$CREATE temp TABLE ply_show
	(
		iserial INT,
		f_NL    CHAR(1)
	);
	
	$INSERT INTO ply_show VALUES(1,'N');
	$INSERT INTO ply_show VALUES(2,'L');*/
	
	/* �O�o�q���O */
	$CREATE temp TABLE bzfrom_tmp
	(
		iserial INT,
		bzfrom  CHAR(2)
	);
	
	$INSERT INTO bzfrom_tmp VALUES(1,'10');
	$INSERT INTO bzfrom_tmp VALUES(2,'20');
	$INSERT INTO bzfrom_tmp VALUES(3,'21');
	$INSERT INTO bzfrom_tmp VALUES(4,'30');
	$INSERT INTO bzfrom_tmp VALUES(5,'31');
	$INSERT INTO bzfrom_tmp VALUES(6,'40');
	$INSERT INTO bzfrom_tmp VALUES(7,'41');
	
	/* ñ�� */
	$CREATE TEMP TABLE ply_renew_trade
	(
		f_NL       char(1),  /* �۵M�H�B�k�H */
		cnt_dply   INT,
		bzfrom     char(2),  /* �O�o�q���N�� */
		frenew     CHAR(1),  /* �s�¥� */
		ftrade_yn  CHAR(1)   /* ���U���x */
	);
	$CREATE INDEX ply_renew_trade_ind1 ON ply_renew_trade(f_NL);
	$CREATE INDEX ply_renew_trade_ind2 ON ply_renew_trade(bzfrom);
	$CREATE INDEX ply_renew_trade_ind3 ON ply_renew_trade(frenew);
	$CREATE INDEX ply_renew_trade_ind4 ON ply_renew_trade(ftrade_yn);

	/* �����s�q�l���O�I�� */
	$CREATE TEMP TABLE ply_ecard
	(
		f_NL            char(1),  /* �۵M�H�B�k�H */
		cnt_fecard      INT,
		bzfrom          char(2),  /* �O�o�q���N�� */
		frenew          CHAR(1),  /* �s�¥� */
		ftrade_yn       CHAR(1)   /* ���U���x */
		
	);
	$CREATE INDEX ply_ecard_ind1 ON ply_ecard(f_NL);
	$CREATE INDEX ply_ecard_ind2 ON ply_ecard(bzfrom);
	$CREATE INDEX ply_ecard_ind3 ON ply_ecard(frenew);
	$CREATE INDEX ply_ecard_ind4 ON ply_ecard(ftrade_yn);
	
	/* ������Ȥ�(�t�J���Ȥ�)����ʹq�ܤιq�l�l�� */
	$CREATE TEMP TABLE ply_phone_mail
	(
		f_NL            char(1),  /* �۵M�H�B�k�H */
		cnt_phone_mail      INT,
		bzfrom          char(2),  /* �O�o�q���N�� */
		frenew          CHAR(1),  /* �s�¥� */
		ftrade_yn       CHAR(1),  /* ���U���x */
		fnotifyornot    CHAR(1)   /* �O�_�Ŀ�L�k���� */
	);
	$CREATE INDEX ply_phone_mail_ind1 ON ply_phone_mail(f_NL);
	$CREATE INDEX ply_phone_mail_ind2 ON ply_phone_mail(bzfrom);
	$CREATE INDEX ply_phone_mail_ind3 ON ply_phone_mail(frenew);
	$CREATE INDEX ply_phone_mail_ind4 ON ply_phone_mail(ftrade_yn);
	$CREATE INDEX ply_phone_mail_ind5 ON ply_phone_mail(fnotifyornot);
	
	/* �T��H�e�q�l���O�I�� */
	$CREATE TEMP TABLE ply_sendecard
	(
		f_NL            char(1),  /* �۵M�H�B�k�H */
		cnt_sendecard       INT,
		bzfrom          char(2),  /* �O�o�q���N�� */
		frenew          CHAR(1),  /* �s�¥� */
		ftrade_yn       CHAR(1)   /* ���U���x */
	);
	$CREATE INDEX ply_sendecard_ind1 ON ply_sendecard(f_NL);
	$CREATE INDEX ply_sendecard_ind2 ON ply_sendecard(bzfrom);
	$CREATE INDEX ply_sendecard_ind3 ON ply_sendecard(frenew);
	$CREATE INDEX ply_sendecard_ind4 ON ply_sendecard(ftrade_yn);
	
	/* ñ���� */
	for(k=0;k<count_db;k++) 
	{
		sprintf(stmt,"INSERT INTO ply_tmp \
		               SELECT a.ipolicy,a.icard,bzfrom,b.fassured,a.ileader,a.feply, \
		                      a.itmp_policy,a.tmobile_eply,a.aemail_eply,mobil_phone,iemail,tmobile_appl,aemail_appl, \
		                      dpolicy,iexaminer,ientry,a.dnotifyornot, \
		                      case (SELECT count(*) FROM policy_new WHERE insure_type = 'C' AND insure_level = 'C1' AND itarget1 = b.itag AND b.itag <> '' AND b.itag IS NOT NULL) \
		                      WHEN 1 THEN 'N'  WHEN 0 THEN 'N'  ELSE 'R' END \
		                FROM %s:ply_relation a,%s:policy b \
		               WHERE a.ipolicy = b.ipolicy \
		                 AND a.dpolicy BETWEEN ? AND ? \
		                 AND a.fcard_class = '1' ", list[k].dbname,list[k].dbname);
		printf("stmt[%s] \n",stmt);

		$PREPARE ply_data FROM $stmt;
		$EXECUTE ply_data USING $dpolicy_bgn, $dpolicy_end;
	}

	/* �۵M�Hñ�� */
	$INSERT INTO ply_renew_trade
	 SELECT 'N',count(*),bzfrom,frenew,CASE WHEN (ientry = 'TRADE/SYS' OR iexaminer = 'TRADE/SYS') THEN 'Y' ELSE 'N' END
	   FROM ply_tmp 
	  WHERE fassured IN ('1','3','5')
	  GROUP BY 1,3,4,5;
	
	/* �k�Hñ�� */
	$INSERT INTO ply_renew_trade
	 SELECT 'L',count(*),bzfrom,frenew,CASE WHEN (ientry = 'TRADE/SYS' OR iexaminer = 'TRADE/SYS') THEN 'Y' ELSE 'N' END
	   FROM ply_tmp 
	  WHERE fassured IN ('2','4','6')
	  GROUP BY 1,3,4,5;	 
	
	/* �����s�q�l���O�I�� */
	$INSERT INTO ply_tmp1
	 SELECT ipolicy,icard,bzfrom,fassured,ileader,feply,itmp_policy,tmobile_eply,aemail_eply,mobil_phone,iemail,tmobile_appl,aemail_appl,dpolicy,iexaminer,ientry,frenew,dnotifyornot
	   FROM ply_tmp
	  WHERE (ipolicy IN (SELECT ipolicy
	                       FROM newa00:ca_ecard_log 
	                      WHERE (result_code IN ('S0000') OR result_code[1,2] = 'E1' OR result_code[1,2] = 'E2' OR result_code[1,2] = 'E3' OR result_code[1,2] = 'E8' OR result_code = 'E9000')) 
	     OR (ientry = 'TRADE/SYS' OR iexaminer = 'TRADE/SYS'));

	/* �����s�q�l���O�I��-�۵M�H */
	$INSERT INTO ply_ecard
	 SELECT 'N',count(*),bzfrom,frenew,CASE WHEN (ientry = 'TRADE/SYS' OR iexaminer = 'TRADE/SYS') THEN 'Y' ELSE 'N' END
	   FROM ply_tmp1 a
	  WHERE fassured IN ('1','3','5')
	  GROUP BY 1,3,4,5;
	  
	/* �����s�q�l���O�I��-�k�H */
	$INSERT INTO ply_ecard
	 SELECT 'L',count(*),bzfrom,frenew,CASE WHEN (ientry = 'TRADE/SYS' OR iexaminer = 'TRADE/SYS') THEN 'Y' ELSE 'N' END
	   FROM ply_tmp1 a
	  WHERE fassured IN ('2','4','6')
	  GROUP BY 1,3,4,5;
	
	/* ������Ȥ�(�t�J���Ȥ�)����ʹq�ܤΤl�l��-�۵M�H */
	$INSERT INTO ply_phone_mail
	 SELECT 'N',count(*),bzfrom,frenew,CASE WHEN (ientry = 'TRADE/SYS' OR iexaminer = 'TRADE/SYS') THEN 'Y' ELSE 'N' END,
	        CASE WHEN ((dnotifyornot IS NOT NULL OR dnotifyornot <> '') OR dnotifyornot <> '') THEN 'Y' ELSE 'N' END 
	  FROM ply_tmp1 
	 WHERE fassured IN ('1','3','5') 
	   AND (trim(nvl(tmobile_appl,'')) = '' AND trim(nvl(aemail_appl,'')) = '') 
	   AND (trim(nvl(tmobile_eply,'')) = '' AND trim(nvl(aemail_eply,'')) = '')
	 GROUP BY 1,3,4,5,6;
	  
	/* ������Ȥ�(�t�J���Ȥ�)����ʹq�ܤΤl�l��-�k�H */
	 $INSERT INTO ply_phone_mail
	 SELECT 'L',count(*),bzfrom,frenew,CASE WHEN (ientry = 'TRADE/SYS' OR iexaminer = 'TRADE/SYS') THEN 'Y' ELSE 'N' END,
	        CASE WHEN ((dnotifyornot IS NOT NULL OR dnotifyornot <> '') OR dnotifyornot <> '') THEN 'Y' ELSE 'N' END 
	  FROM ply_tmp1 
	 WHERE fassured IN ('2','4','6') 
	   AND (trim(nvl(tmobile_appl,'')) = '' AND trim(nvl(aemail_appl,'')) = '') 
	   AND (trim(nvl(tmobile_eply,'')) = '' AND trim(nvl(aemail_eply,'')) = '')
	 GROUP BY 1,3,4,5,6;
	
	/* �T��H�e�q�l���O�I��-�۵M�H */
	strcpy(stmp_cont,"\%\%\"sendOrNot\":\"Y\"\%\%");
	printf("stmp_cont[%s]\n",stmp_cont);
	
	sprintf(stmp1,"INSERT INTO ply_sendecard \
	               SELECT 'N',count(*),bzfrom,frenew,CASE WHEN (ientry = 'TRADE/SYS' OR iexaminer = 'TRADE/SYS') THEN 'Y' ELSE 'N' END \
	                 FROM ply_tmp1  \
	                WHERE ( \
	                        fassured IN ('1','3','5')  \
	                        AND (((ientry = 'TRADE/SYS' OR iexaminer = 'TRADE/SYS') AND (trim(nvl(tmobile_appl,'')) <> '' OR trim(nvl(aemail_appl,'')) <> ''))  \
	                         OR ((ientry <> 'TRADE/SYS' AND iexaminer <> 'TRADE/SYS') AND (trim(nvl(aemail_eply,'')) <> '' OR trim(nvl(tmobile_eply,'')) <> ''))) \
	                      ) \
	                   OR ( \
	                        ipolicy IN  \
	                        (SELECT DISTINCT a.ipolicy FROM ply_tmp1 a,newa00:ca_ecard_log b  \
	                          WHERE a.fassured IN ('1','3','5')   \
	                            AND (((trim(nvl(a.tmobile_appl,'')) = '' AND trim(nvl(a.aemail_appl,'')) = '') AND (a.ientry = 'TRADE/SYS' OR a.iexaminer = 'TRADE/SYS'))  \
	                             OR ((trim(nvl(a.aemail_eply,'')) = '' AND trim(nvl(a.tmobile_eply,'')) = '') AND (a.ientry <> 'TRADE/SYS' AND a.iexaminer <> 'TRADE/SYS'))) \
	                            AND a.ipolicy=b.ipolicy   \
	                            AND (b.trans_type='5' OR (b.trans_type = '8' AND b.trans_content LIKE '%s')) \
	                        ) \
	                      ) \
	                GROUP BY 1,3,4,5",stmp_cont);
	printf("stmp1[%s] \n",stmp1);
	$PREPARE sendecard1 FROM $stmp1;
	$EXECUTE sendecard1;
	
	/* �T��H�e�q�l���O�I��-�k�H */
	sprintf(stmp2,"INSERT INTO ply_sendecard \
	               SELECT 'N',count(*),bzfrom,frenew,CASE WHEN (ientry = 'TRADE/SYS' OR iexaminer = 'TRADE/SYS') THEN 'Y' ELSE 'N' END \
	                 FROM ply_tmp1  \
	                WHERE ( \
	                        fassured IN ('2','4','6')  \
	                        AND (((ientry = 'TRADE/SYS' OR iexaminer = 'TRADE/SYS') AND (trim(nvl(tmobile_appl,'')) <> '' OR trim(nvl(aemail_appl,'')) <> ''))  \
	                         OR ((ientry <> 'TRADE/SYS' AND iexaminer <> 'TRADE/SYS') AND (trim(nvl(aemail_eply,'')) <> '' OR trim(nvl(tmobile_eply,'')) <> ''))) \
	                      ) \
	                   OR ( \
	                        ipolicy IN  \
	                        (SELECT DISTINCT a.ipolicy FROM ply_tmp1 a,newa00:ca_ecard_log b  \
	                          WHERE a.fassured IN ('2','4','6')   \
	                            AND (((trim(nvl(a.tmobile_appl,'')) = '' AND trim(nvl(a.aemail_appl,'')) = '') AND (a.ientry = 'TRADE/SYS' OR a.iexaminer = 'TRADE/SYS'))  \
	                             OR ((trim(nvl(a.aemail_eply,'')) = '' AND trim(nvl(a.tmobile_eply,'')) = '') AND (a.ientry <> 'TRADE/SYS' AND a.iexaminer <> 'TRADE/SYS'))) \
	                            AND a.ipolicy=b.ipolicy   \
	                            AND (b.trans_type='5' OR (b.trans_type = '8' AND b.trans_content LIKE '%s')) \
	                        ) \
	                      ) \
	                GROUP BY 1,3,4,5",stmp_cont);
	printf("stmp2[%s] \n",stmp2);
	$PREPARE sendecard2 FROM $stmp2;
	$EXECUTE sendecard2;
	
	return M_CM_OK;
	
errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
/*--------------------------------------------------------------------*/


long car7422_build()
{
	$int rc;
	$char sfilename[256],stitle[4096],stmt2[20000];

	$WHENEVER SQLERROR GOTO errexit;
	
	
	strcpy(sfilename,"�j��q�l���Ҳέp����[car7422]\n");
	strcpy(stitle,"\tñ��\tñ��\tñ��\tñ��\tñ��\tñ��\tñ��\tñ��\tñ��\tñ��\t");
	strcat(stitle,"�����s�q�l\t�����s�q�l\t�����s�q�l\t�����s�q�l\t�����s�q�l\t�����s�q�l\t�����s�q�l\t�����s�q�l\t�����s�q�l\t�����s�q�l\t");
	strcat(stitle,"������Ȥ�\t������Ȥ�\t������Ȥ�\t������Ȥ�\t������Ȥ�\t������Ȥ�\t������Ȥ�\t������Ȥ�\t������Ȥ�\t������Ȥ�\t������Ȥ�\t������Ȥ�\t������Ȥ�\t������Ȥ�\t������Ȥ�\t������Ȥ�\t������Ȥ�\t������Ȥ�\t");
	strcat(stitle,"�T��H�e\t�T��H�e\t�T��H�e\t�T��H�e\t�T��H�e\t�T��H�e\t�T��H�e\t�T��H�e\t�T��H�e\t�T��H�e\t\n");
	strcat(stitle,"\t�O�o�q���N��\t�۵M�H\t�k�H\t�۵M�H\t�۵M�H\t�۵M�H\t�۵M�H\t�k�H\t�k�H\t�k�H\t�k�H\t");
	strcat(stitle,"�۵M�H\t�k�H\t�۵M�H\t�۵M�H\t�۵M�H\t�۵M�H\t�k�H\t�k�H\t�k�H\t�k�H\t");
	strcat(stitle,"�۵M�H\t�k�H\t�۵M�H\t�۵M�H\t�۵M�H\t�۵M�H\t�۵M�H\t�۵M�H\t�۵M�H\t�۵M�H\t�k�H\t�k�H\t�k�H\t�k�H\t�k�H\t�k�H\t�k�H\t�k�H\t");
	strcat(stitle,"�۵M�H\t�k�H\t�۵M�H\t�۵M�H\t�۵M�H\t�۵M�H\t�k�H\t�k�H\t�k�H\t�k�H\n");
	strcat(stitle,"\t\t\t\t�s��\t�s��\t��O\t��O\t�s��\t�s��\t��O\t��O\t");
	strcat(stitle,"\t\t�s��\t�s��\t��O\t��O\t�s��\t�s��\t��O\t��O\t");
	strcat(stitle,"\t\t�s��\t�s��\t�s��\t�s��\t��O\t��O\t��O\t��O\t�s��\t�s��\t�s��\t�s��\t��O\t��O\t��O\t��O\t");
	strcat(stitle,"\t\t�s��\t�s��\t��O\t��O\t�s��\t�s��\t��O\t��O\n");
	strcat(stitle,"\t\t\t\t���U���x\t�D���U���x\t���U���x\t�D���U���x\t���U���x\t�D���U���x\t���U���x\t�D���U���x\t");
	strcat(stitle,"\t\t���U���x\t�D���U���x\t���U���x\t�D���U���x\t���U���x\t�D���U���x\t���U���x\t�D���U���x\t");
	strcat(stitle,"\t\t���U���x\t���U���x\t�D���U���x\t�D���U���x\t���U���x\t���U���x\t�D���U���x\t�D���U���x\t���U���x\t���U���x\t�D���U���x\t�D���U���x\t���U���x\t���U���x\t�D���U���x\t�D���U���x\t");
	strcat(stitle,"\t\t���U���x\t�D���U���x\t���U���x\t�D���U���x\t���U���x\t�D���U���x\t���U���x\t�D���U���x\n");
	strcat(stitle,"\t\t\t\t\t\t\t\t\t\t\t\t");
	strcat(stitle,"\t\t\t\t\t\t\t\t\t\t");
	strcat(stitle,"\t\t�Ŀ�L�k����\t���Ŀ�L�k����\t�Ŀ�L�k����\t���Ŀ�L�k����\t�Ŀ�L�k����\t���Ŀ�L�k����\t�Ŀ�L�k����\t���Ŀ�L�k����\t�Ŀ�L�k����\t���Ŀ�L�k����\t�Ŀ�L�k����\t���Ŀ�L�k����\t�Ŀ�L�k����\t���Ŀ�L�k����\t�Ŀ�L�k����\t���Ŀ�L�k����\t");
	strcat(stitle,"\t\t\t\t\t\t\t\t\t\t");
	
	strcpy(stmt2," SELECT bzfrom,                                                                                                                                                       \
	                      NVL((SELECT sum(cnt_dply) FROM ply_renew_trade WHERE f_NL = 'N' AND bzfrom = a.bzfrom),0),                                                                    \
	                      NVL((SELECT sum(cnt_dply) FROM ply_renew_trade WHERE f_NL = 'L' AND bzfrom = a.bzfrom),0),                                                                    \
	                      NVL((SELECT sum(cnt_dply) FROM ply_renew_trade WHERE f_NL = 'N' AND bzfrom = a.bzfrom AND frenew = 'N' AND ftrade_yn = 'Y'),0),                               \
	                      NVL((SELECT sum(cnt_dply) FROM ply_renew_trade WHERE f_NL = 'N' AND bzfrom = a.bzfrom AND frenew = 'N' AND ftrade_yn = 'N'),0),                               \
	                      NVL((SELECT sum(cnt_dply) FROM ply_renew_trade WHERE f_NL = 'N' AND bzfrom = a.bzfrom AND frenew = 'R' AND ftrade_yn = 'Y'),0),                               \
	                      NVL((SELECT sum(cnt_dply) FROM ply_renew_trade WHERE f_NL = 'N' AND bzfrom = a.bzfrom AND frenew = 'R' AND ftrade_yn = 'N'),0),                               \
	                      NVL((SELECT sum(cnt_dply) FROM ply_renew_trade WHERE f_NL = 'L' AND bzfrom = a.bzfrom AND frenew = 'N' AND ftrade_yn = 'Y'),0),                               \
	                      NVL((SELECT sum(cnt_dply) FROM ply_renew_trade WHERE f_NL = 'L' AND bzfrom = a.bzfrom AND frenew = 'N' AND ftrade_yn = 'N'),0),                               \
	                      NVL((SELECT sum(cnt_dply) FROM ply_renew_trade WHERE f_NL = 'L' AND bzfrom = a.bzfrom AND frenew = 'R' AND ftrade_yn = 'Y'),0),                               \
	                      NVL((SELECT sum(cnt_dply) FROM ply_renew_trade WHERE f_NL = 'L' AND bzfrom = a.bzfrom AND frenew = 'R' AND ftrade_yn = 'N'),0),                               \
	                      NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = 'N' AND bzfrom = a.bzfrom),0),                                                                        \
	                      NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = 'L' AND bzfrom = a.bzfrom),0),                                                                        \
	                      NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = 'N' AND bzfrom = a.bzfrom AND frenew = 'N' AND ftrade_yn = 'Y'),0),                                   \
	                      NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = 'N' AND bzfrom = a.bzfrom AND frenew = 'N' AND ftrade_yn = 'N'),0),                                   \
	                      NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = 'N' AND bzfrom = a.bzfrom AND frenew = 'R' AND ftrade_yn = 'Y'),0),                                   \
	                      NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = 'N' AND bzfrom = a.bzfrom AND frenew = 'R' AND ftrade_yn = 'N'),0),                                   \
	                      NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = 'L' AND bzfrom = a.bzfrom AND frenew = 'N' AND ftrade_yn = 'Y'),0),                                   \
	                      NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = 'L' AND bzfrom = a.bzfrom AND frenew = 'N' AND ftrade_yn = 'N'),0),                                   \
	                      NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = 'L' AND bzfrom = a.bzfrom AND frenew = 'R' AND ftrade_yn = 'Y'),0),                                   \
	                      NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = 'L' AND bzfrom = a.bzfrom AND frenew = 'R' AND ftrade_yn = 'N'),0),                                   \
	                      NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = 'N' AND bzfrom = a.bzfrom),0),                                                               \
	                      NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = 'L' AND bzfrom = a.bzfrom),0),                                                               \
	                      NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = 'N' AND bzfrom = a.bzfrom AND frenew = 'N' AND ftrade_yn = 'Y' AND fnotifyornot = 'Y'),0),   \
	                      NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = 'N' AND bzfrom = a.bzfrom AND frenew = 'N' AND ftrade_yn = 'Y' AND fnotifyornot = 'N'),0),   \
	                      NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = 'N' AND bzfrom = a.bzfrom AND frenew = 'N' AND ftrade_yn = 'N' AND fnotifyornot = 'Y'),0),   \
	                      NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = 'N' AND bzfrom = a.bzfrom AND frenew = 'N' AND ftrade_yn = 'N' AND fnotifyornot = 'N'),0),   \
	                      NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = 'N' AND bzfrom = a.bzfrom AND frenew = 'R' AND ftrade_yn = 'Y' AND fnotifyornot = 'Y'),0),   \
	                      NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = 'N' AND bzfrom = a.bzfrom AND frenew = 'R' AND ftrade_yn = 'Y' AND fnotifyornot = 'N'),0),   \
	                      NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = 'N' AND bzfrom = a.bzfrom AND frenew = 'R' AND ftrade_yn = 'N' AND fnotifyornot = 'Y'),0),   \
	                      NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = 'N' AND bzfrom = a.bzfrom AND frenew = 'R' AND ftrade_yn = 'N' AND fnotifyornot = 'N'),0),   \
	                      NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = 'L' AND bzfrom = a.bzfrom AND frenew = 'N' AND ftrade_yn = 'Y' AND fnotifyornot = 'Y'),0),   \
	                      NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = 'L' AND bzfrom = a.bzfrom AND frenew = 'N' AND ftrade_yn = 'Y' AND fnotifyornot = 'N'),0),   \
	                      NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = 'L' AND bzfrom = a.bzfrom AND frenew = 'N' AND ftrade_yn = 'N' AND fnotifyornot = 'Y'),0),   \
	                      NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = 'L' AND bzfrom = a.bzfrom AND frenew = 'N' AND ftrade_yn = 'N' AND fnotifyornot = 'N'),0),   \
	                      NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = 'L' AND bzfrom = a.bzfrom AND frenew = 'R' AND ftrade_yn = 'Y' AND fnotifyornot = 'Y'),0),   \
	                      NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = 'L' AND bzfrom = a.bzfrom AND frenew = 'R' AND ftrade_yn = 'Y' AND fnotifyornot = 'N'),0),   \
	                      NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = 'L' AND bzfrom = a.bzfrom AND frenew = 'R' AND ftrade_yn = 'N' AND fnotifyornot = 'Y'),0),   \
	                      NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = 'L' AND bzfrom = a.bzfrom AND frenew = 'R' AND ftrade_yn = 'N' AND fnotifyornot = 'N'),0),   \
	                      NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = 'N' AND bzfrom = a.bzfrom),0),                                                                 \
	                      NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = 'L' AND bzfrom = a.bzfrom),0),                                                                 \
	                      NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = 'N' AND bzfrom = a.bzfrom AND frenew = 'N' AND ftrade_yn = 'Y'),0),                            \
	                      NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = 'N' AND bzfrom = a.bzfrom AND frenew = 'N' AND ftrade_yn = 'N'),0),                            \
	                      NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = 'N' AND bzfrom = a.bzfrom AND frenew = 'R' AND ftrade_yn = 'Y'),0),                            \
	                      NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = 'N' AND bzfrom = a.bzfrom AND frenew = 'R' AND ftrade_yn = 'N'),0),                            \
	                      NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = 'L' AND bzfrom = a.bzfrom AND frenew = 'N' AND ftrade_yn = 'Y'),0),                            \
	                      NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = 'L' AND bzfrom = a.bzfrom AND frenew = 'N' AND ftrade_yn = 'N'),0),                            \
	                      NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = 'L' AND bzfrom = a.bzfrom AND frenew = 'R' AND ftrade_yn = 'Y'),0),                            \
	                      NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = 'L' AND bzfrom = a.bzfrom AND frenew = 'R' AND ftrade_yn = 'N'),0)                             \
	                FROM bzfrom_tmp a                                                                                                                                                   \
	               ORDER BY iserial ");

    sprintf("stmt2[%s]",stmt2);
	rc = unload_file(outputf," ",sfilename,stitle,stmt2);

	if (rc != SUCCESS) 
	{
	    sprintf(msgbuf," %s �ɮ׵L�k���� ",sfilename);
	    EWRITE(userid, rc , msgbuf);
	    return rc;
	}
	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	return SQLCODE;
}
                                                                        