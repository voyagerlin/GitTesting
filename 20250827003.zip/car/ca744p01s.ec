/**********************************************************************/
/*   program id   : ca744p01s.ec                                     */
/*   program name : ���T�q�l�j��F���Ӫ�(�C��)                        */
/*   date written : 2022/10/26                                        */
/*   author       : 111863                                            */                                       
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include "safeclib.h"
#include <math.h>

/****************************************************************************/
$char DBName[05],userid[11];
$char iquote1[21],ipolicy1[21],iendorse1[21],icard1[21],iassured1[13],itag1[13],fclass[3];
$char sYYMM[7],dbgn[11];
$char icard[21],ipolicy[21],ipolicy_c[21]; 
$char  dend[11];
char  msgbuf[2048],sApHome[30];
char  outputf[N_FILE+1];
char sApHome[30],msgbuf[2048];
$char date[11],dToday[11],nyy[4],nmm[3],ndd[3];

$int isql2;
int	count_db;
int   count_db,k;

long  t;

DBinfo *list;
int rc; /* �P�_��Ʈw�s�u */
long car744_get_db();
/****************************************************************************/
main(argc, argv)
int argc;
char **argv;
{  

	batchinit();
	strcpy(DBName, isNULLstr(argv[1]));
	strcpy(userid, isNULLstr(argv[2]));
	strcpy(iquote1,  isNULLstr(argv[3]));
	strcpy(ipolicy1,  isNULLstr(argv[4]));
	strcpy(iendorse1,  isNULLstr(argv[5]));
	strcpy(icard1,  isNULLstr(argv[6]));
	strcpy(iassured1,  isNULLstr(argv[7]));
	strcpy(itag1,  isNULLstr(argv[8]));
	strcpy(outputf,isNULLstr(argv[9]));
	
	
			
	/* �P�_��Ʈw���L�s�W */
	rc = car744_get_db();
	if (rc != M_CM_OK)
	{
		EWRITE(userid,rc,msgbuf);
		return rc;
	}
	
	/* ���褸�~��(10807) */
	$select to_char(date($dbgn),'%Y%m') into $sYYMM 
	   from systables where tabid = 1;
	
	$BEGIN WORK;
	rc = car744_body();
	if (rc != M_CM_OK)
	    return rc;
	$COMMIT WORK;
	
	EWRITE(userid, M_CM_OK,  " ���槹��");
			
}
/****************************************************************************/
long car744_get_db()
{
	int return_code;
	
	$WHENEVER SQLERROR GOTO errexit;
	
	strcpy(dToday,cm_from_infdate_100(date));
	cm_split_ymd_100(dToday,nyy,nmm,ndd);

	if (db_select(DBName) == False)
	{
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}
	if ( (list = get_db_list(&count_db,DBName)) == (char*)0 )
	{
		EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
		return M_CM_NOT_DBLIST;
	}
	
	return_code = getApHome(sApHome);
	if (return_code < 0) 
	{
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		return return_code;	
	}  
  return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;  
}

long car744_body()
{
    char sfilename[256],stitle[2048];
    $char stmt1[6000],stmt11[6000];
    $char iquote1T[201],ipolicy1T[201],iendorseT[201],icardT[201],iassuredT[201],itag1T[201];
    strcpy( iquote1T, " ");
    strcpy( ipolicy1T, " ");
    strcpy( iendorseT, " ");
    strcpy( icardT, " ");
    strcpy( iassuredT, " ");
    strcpy( itag1T, " ");
    strcpy( stitle, " ");    

	$WHENEVER SQLERROR GOTO errexit;
	
	$create temp table ply_out_tmp2
			(
				nname          char(11),
			  	ipolicy        char(20),
				iendorse       char(20),
				icard          char(21),
				iquoteT        char(21),
				iassured       char(13),
				itagT          char(13),
				fkind	       char(11),	
				trans_typeT    char(10),
				dtransT        char(130),
				card_sel_dateT char(11),
				card_rev_dateT char(11),
				chinameT       char(46)
			) with no log;
			
	if ((iquote1[0] != '*') && (iquote1[strlen(trim(iquote1))-1] != '*') && (strlen(trim(iquote1)) > 0)){
		sprintf_s(iquote1T, sizeof iquote1T," AND cael.iquote='%s'", iquote1);
	}else {
        	if ((iquote1[0] != '*')  && (strlen(trim(iquote1)) > 0) && (iquote1[strlen(trim(iquote1))-1] == '*')){
			sprintf_s(iquote1T, sizeof iquote1T," AND cael.iquote matches '%s'", iquote1);
		}
    	}
    
        if ((ipolicy1[0] != '*') && (ipolicy1[strlen(trim(ipolicy1))-1] != '*') && (strlen(trim(ipolicy1)) > 0)){
		sprintf_s(ipolicy1T, sizeof ipolicy1T," AND cael.ipolicy='%s'", ipolicy1);
	}else {
        	if ((ipolicy1[0] != '*') && (strlen(trim(ipolicy1)) > 0) && (ipolicy1[strlen(trim(ipolicy1))-1] == '*')){
			sprintf_s(ipolicy1T, sizeof ipolicy1T," AND cael.ipolicy matches '%s'", ipolicy1);
        	}
    	}
    
   	 if ((iendorse1[0] != '*') && (iendorse1[strlen(trim(iendorse1))-1] != '*') && (strlen(trim(iendorse1)) > 0)){
		sprintf_s(iendorseT, sizeof iendorseT," AND cael.iendorse='%s'", iendorse1);
	}else {	
        	if ((iendorse1[0] != '*') && (strlen(trim(iendorse1)) > 0) && (iendorse1[strlen(trim(iendorse1))-1] == '*')){
			sprintf_s(iendorseT, sizeof iendorseT," AND cael.iendorse matches '17%s'", iendorse1);    		
        	}
    	}
    
    	if ((icard1[0] != '*') && (icard1[strlen(trim(icard1))-1] != '*') && (strlen(trim(icard1)) > 0)){
		sprintf_s(icardT, sizeof icardT," AND cael.icard='17%s'", icard1);
	}else {
        	if ((icard1[0] != '*') && (strlen(trim(icard1)) > 0) && (icard1[strlen(trim(icard1))-1] == '*')){
			sprintf_s(icardT, sizeof icardT," AND cael.icard matches '17%s'", icard1); 		
        	}
    	}
    
    	if ((iassured1[0] != '*') && (iassured1[strlen(trim(iassured1))-1] != '*') && (strlen(trim(iassured1)) > 0)){
		sprintf_s(iassuredT, sizeof iassuredT," AND cael.iassured='%s'", iassured1);
	}else {
        	if ((iassured1[0] != '*') && (strlen(trim(iassured1)) > 0) && (iassured1[strlen(trim(iassured1))-1] == '*')){
			sprintf_s(iassuredT, sizeof iassuredT," AND cael.iassured matches '%s'", iassured1);
        	}
    	}
    
    	if ((itag1[0] != '*') && (itag1[strlen(trim(itag1))-1] != '*') && (strlen(trim(itag1)) > 0)){
		sprintf_s(itag1T, sizeof itag1T," AND cael.itag='%s'", itag1);
	}else {
        	if ((itag1[0] != '*') && (strlen(trim(itag1)) > 0) && (itag1[strlen(trim(itag1))-1] == '*')){
			sprintf_s(itag1T, sizeof itag1T," AND cael.itag matches '%s'", itag1);
        	}
    	}

	for(k=0;k<count_db;k++){
		sprintf_s(stmt1, sizeof stmt1,"INSERT INTO ply_out_tmp2 \n"
		    "SELECT (SELECT nname FROM officer WHERE iofficer=%s:ply_relation.ileader) as nname, cael.ipolicy, cael.iendorse, cael.icard, cael.iquote, cael.iassured, cael.itag, \n"
		    "CASE \n" 
		    "WHEN cael.fkind=1 THEN CONCAT(TRIM(cael.fkind),':�����渹') \n"
		    "WHEN cael.fkind=2 THEN CONCAT(TRIM(cael.fkind),':�O�渹') \n"
		    "WHEN cael.fkind=3 THEN CONCAT(TRIM(cael.fkind),':�����') \n"
		    "WHEN cael.fkind=4 THEN CONCAT(TRIM(cael.fkind),':����Ǹ�') \n"
		    "END AS fkind,  \n"
		    "CASE  \n" 
		    "WHEN cael.trans_type=1 THEN CONCAT(TRIM(cael.trans_type),':�ӫO') \n"
		    "WHEN cael.trans_type=2 THEN CONCAT(TRIM(cael.trans_type),':���') \n"
		    "WHEN cael.trans_type=3 THEN CONCAT(TRIM(cael.trans_type),':�h�O') \n"
		    "WHEN cael.trans_type=4 THEN CONCAT(TRIM(cael.trans_type),':�ɵo') \n"
		    "WHEN cael.trans_type=5 THEN CONCAT(TRIM(cael.trans_type),':�U��') \n"
		    "WHEN cael.trans_type=6 THEN CONCAT(TRIM(cael.trans_type),':����') \n"
		    "WHEN cael.trans_type=7 THEN CONCAT(TRIM(cael.trans_type),':����') \n"
		    "WHEN cael.trans_type=8 THEN CONCAT(TRIM(cael.trans_type),':�H�e') \n"
		    "END AS trans_type, \n"
		    "to_char(extend (cael.dtrans, YEAR to second),'%%Y/%%m/%%d-%%H:%%M:%%S') AS dtrans, \n"
		    "cael.card_sel_date, cael.card_rev_date, CONCAT(CONCAT(TRIM(car_code.chiname),':'),TRIM(cael.result_code)) as chiname \n"
		    "FROM ca_ecard_log AS cael \n"
		    "LEFT JOIN car_code ON car_code.detail=cael.result_code \n"
		    "INNER JOIN %s:ply_relation ON %s:ply_relation.ipolicy=cael.ipolicy \n"
		    "WHERE 1=1 \n"
		    " %s%s%s%s%s%s \n", list[k].dbname, list[k].dbname, list[k].dbname,iquote1T,ipolicy1T,iendorseT,icardT,iassuredT,itag1T);

		$PREPARE ply_out_2 FROM $stmt1;
		$EXECUTE ply_out_2;
	}
	strcpy(sfilename,"���T�q�l�j���ҩ��Ӫ����Ӫ�[car744]");
	strcat(stitle,"�g��H\t�O�渹\t��渹\t�j���Ҹ�\t�����渹\t�Q�O�I�HID\t���P���X\t�d�����O\t����N��\t��������ɶ�\t�d�ߤ��\t�h�O�ͮĤ��\t�^�ХN�X\t");
	strcat(stmt11,"SELECT * FROM ply_out_tmp2;");
	
	rc = unload_file(outputf," ",sfilename,stitle,stmt11);
	
	if (rc != SUCCESS) 
	{
	    sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
	    EWRITE(userid, rc , msgbuf);
	    return rc;
	}
	 
    return M_CM_OK;

errexit:
    sqlfatal();
    isql2 = SQLCODE;
    $ROLLBACK WORK;
    EWRITE(userid,isql2,sqlca.sqlerrm);
    return isql2;
}
