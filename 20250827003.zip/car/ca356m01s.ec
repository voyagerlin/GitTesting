/************************************************/
/*                                              */
/*   PROGRAM : ca356m01s.ec by Stevechiang      */
/*                                              */
/*   PURPOSE : �妸���s�H�o�Ψ����H�e�q�l�O��   */
/*                                              */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "commsgs.h"
#include "carmsgs.h"
#include "safeclib.h"
$include datetime.h;
$include sqlca;

char errbuf[512];
$int count1;
$char getfile[300],sFile[41],sFile_log[41],sFile_log_tmp[41];
FILE   *fp,*fp2;
static int   recLen=1024;
static char  *bp;
char delimiter;
int offset;

long car356(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	long rtncode;
	long car356_batch_update();
	char option;
	int tmp_len;
	
	cm_buf_init(command);
	cm_buf_get("%c",&option);
	switch(option)
	{
		case 'E':
			rtncode=car356_batch_update(reply);
			
			cm_buf_init(ReplyBuf);
			cm_buf_put("%l %s" , rtncode, errbuf);
			tmp_len = cm_buf_len(ReplyBuf);
			if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
				return apiRC;
			else
				return api_OKComplete;
			break;

		default :
			if(exitsub(reply,M_CM_WRONG_OPTION) == True)
				return M_CM_WRONG_OPTION;
		return apiRC;
	}
	return(rtncode);
}

long car356_batch_update(reply)
serverReply reply;
{
	$char DBName[5], stmt[2048], stmt1[2048], stmt_buf[300], v_sMsg[255];
	$char sApHome[30], filename[101], logname[101], cmd_str[2048], userid[11];
	$char ipolicy[21], iendorse[21], tmobile[21], iemail[51], ipolicy_tmp[21], iendorse_tmp[21];
	$char icheck[2];
	$int  ichk_V = 0, ichk_C = 0, ichk_fail = 0, icnt = 0;
	$int  fstatus;
	$int  rc, cnt, rc1 ,irate, rc2;
	int   stmt_len;
	int i, j, is_add_fail=0, api_f;
	long MsgCode;
	
	rc = getApHome(sApHome);
	if (rc<0) {
		strcpy( errbuf,"read Config file error!!-->getApHome\n");
		return rc;
	}
	
	cm_buf_get("%s %d %s %s %s ",DBName, &fstatus, icheck, sFile, userid);
	
	$SELECT first 1 trim(replace($sFile,".txt",""))
	   INTO $sFile_log
	   FROM systables;
	   
	sprintf_s(getfile, sizeof getfile,"%s/dat/car/%s", sApHome,sFile);
	sprintf_s(logname, sizeof logname,"%s/rptftp/%s_log.txt",sApHome,trim(sFile_log));
	
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		sprintf_s(errbuf, sizeof errbuf,"��Ʈw�L�k�}��[%s]\n", DBName);
		return M_CM_DB_NOTOPEN;
	}

   /********************************************************************************************/
    
    if ((fp=fopen(getfile,"rt"))==NULL)
    {
        return SQLCODE;
    }

    if ((bp=malloc(recLen))==NULL)
    {
        printf("System malloc failed  !\n");
        return SQLCODE;
    }
    
    fp2=fopen(logname,"w");

    /* ���j�Ÿ� */
    delimiter = '\t';
	$CREATE TEMP TABLE car356_tmp
	(
		ipolicy    char(20) not null,
		iendorse   char(20) ,
		tmobile    varchar(20) ,
		iemail     varchar(50)    
	)with no log;

	while(fgets(bp,recLen,fp))
	{
		if (feof(fp)) break;
		offset = 0;
		/* ��ƨ��o���Ǥ��i�ܰ�*/
		GetData(ipolicy,    sizeof(ipolicy),    delimiter);
		GetData(iendorse,   sizeof(iendorse),   delimiter);
		GetData(tmobile,    sizeof(tmobile),    delimiter);
		GetData(iemail,     sizeof(iemail),     delimiter);
		
		printf("ipolicy[%s],iendorse[%s],tmobile[%s],iemail[%s]\n",ipolicy,iendorse,tmobile,iemail);
		
		$INSERT INTO car356_tmp(ipolicy,iendorse,tmobile,iemail)
		                VALUES ($ipolicy,$iendorse,$tmobile,$iemail);
		memset(bp, ' ', recLen);
	}
	fclose(fp);
	free(bp);
	
	ichk_fail = 0;
	
	sprintf_s(stmt1, sizeof stmt1,"SELECT ipolicy,iendorse,tmobile,iemail FROM car356_tmp");
	printf("stmt1=[%s]\n",stmt1);

	$PREPARE CUR_CHK FROM $stmt1;
	$DECLARE CUR_CHK1 CURSOR FOR CUR_CHK;
	$OPEN CUR_CHK1;

	for(;;)
	{
		$FETCH CUR_CHK1 INTO $ipolicy,$iendorse,$tmobile,$iemail;
		if (SQLCODE != 0) break;
		printf("ipolicy[%s],iendorse[%s],tmobile[%s],iemail[%s]\n",ipolicy,iendorse,tmobile,iemail);

		$SELECT count(*)
		   INTO $ichk_V
		   FROM cm_e_policy
		  WHERE ipolicy = $ipolicy
		    AND iendorse = $iendorse
		    AND fstatus = 930;
		
		if(ichk_V == 0)
		{
			$SELECT count(*)
			   INTO $ichk_C
			   FROM ca_ecard_email_log
			  WHERE ipolicy = $ipolicy
			    AND iendorse = $iendorse
			    AND fstatus = 930;
			    
			if(ichk_C == 0) 
			{ 
				ichk_fail++;
				strcpy(ipolicy_tmp,trim(ipolicy));
				strcpy(iendorse_tmp,trim(iendorse));
				fprintf(fp2,"�O�渹[%s],��渹[%s]�����A�D930���o�� \n",ipolicy_tmp,iendorse_tmp);
				continue;
			}
			else
			{
				/* �ȧ󥿪��A */
				$UPDATE ca_ecard_email_log
				    SET fstatus  = $fstatus,
				        iupdate  = $userid,
				        dupdate  = current
				  WHERE ipolicy  = $ipolicy
			        AND iendorse = $iendorse
				    AND fstatus  = 930;
				rc2 = insert_ca_log("car356","A",ipolicy,iendorse,itoa(fstatus),userid,v_sMsg);
			}
		}
		else 
		{
			if (icheck[0] == 'Y')
			{
				/* �ȧ󥿪��A */
				if ((strcmp(trim(iemail)) != 0) || (strcmp(trim(tmobile)) != 0))
				{
					ichk_fail++;
					strcpy(ipolicy_tmp,trim(ipolicy));
					strcpy(iendorse_tmp,trim(iendorse));
					fprintf(fp2,"�O�渹[%s],��渹[%s]���Ŀ�Ȳ��ʪ��A�A�����EMAIL�������� \n",ipolicy_tmp,iendorse_tmp);
					continue;
				}
				else 
				{
					$UPDATE cm_e_policy
					    SET fstatus  = $fstatus,
					        iupdate  = $userid,
					        dupdate  = current
					  WHERE ipolicy  = $ipolicy
				        AND iendorse = $iendorse
					    AND fstatus  = 930;
				}
			}
			else
			{
				/* �󥿪��A�BEMAIL�Τ���A����̨�@�����ݦ��� */
				if ((strcmp(trim(iemail)) == 0) && (strcmp(trim(tmobile)) == 0))
				{
					ichk_fail++;
					strcpy(ipolicy_tmp,trim(ipolicy));
					strcpy(iendorse_tmp,trim(iendorse));
					fprintf(fp2,"�O�渹[%s],��渹[%s]�����Ŀ�Ȳ��ʪ��A�A�����EMAIL���o���� \n",ipolicy_tmp,iendorse_tmp);
					continue;
				}
				else
				{
					
					if (strcmp(trim(iemail),"") != 0 && strstr(iemail,"@") == NULL)
					{
						ichk_fail++;
						strcpy(ipolicy_tmp,trim(ipolicy));
						strcpy(iendorse_tmp,trim(iendorse));
						fprintf(fp2,"�O�渹[%s],��渹[%s]��email�榡�����T[%s] \n",ipolicy_tmp,iendorse_tmp,iemail);
						continue;	
					}
					
					if (strcmp(trim(tmobile),"") != 0 && (strstr(tmobile,"@") != NULL || strncmp(trim(tmobile),"09",2) != 0))
					{
						ichk_fail++;
						strcpy(ipolicy_tmp,trim(ipolicy));
						strcpy(iendorse_tmp,trim(iendorse));
						fprintf(fp2,"�O�渹[%s],��渹[%s]������榡�����T[%s] \n",ipolicy_tmp,iendorse_tmp,tmobile);
						continue;	
					}

					$UPDATE cm_e_policy
					    SET fstatus     = $fstatus,
					        nemai_send  = $iemail, 
					        tsms_mobile = $tmobile,
					        iupdate     = $userid,
					        dupdate     = current
					  WHERE ipolicy     = $ipolicy
				        AND iendorse    = $iendorse
					    AND fstatus     = 930;
				}
			}
			rc2 = insert_ca_log("car356","A",ipolicy,iendorse,itoa(fstatus),userid,v_sMsg);
		}
	}
	
	$SELECT count(*) INTO $icnt FROM car356_tmp;
	
	sprintf_s(sFile_log_tmp, sizeof sFile_log_tmp,"%s_log.txt",trim(sFile_log));
	
	$INSERT INTO rptftplist (nuserid, ipgid,    noutfile,  dcreate) 
	                 VALUES ($userid, 'car356', $sFile_log_tmp,  CURRENT);
	fclose(fp2);
	$CLOSE CUR_CHK1;
	$FREE CUR_CHK1;
	$DROP TABLE car356_tmp;
	/********************************************************************************************/
	if (ichk_fail == icnt)
		sprintf_s(errbuf, sizeof errbuf,"�u���楢��\�A���I���ɮפU���@�~�d��[Q],�T�{���~��]�v");
	else if (ichk_fail > 0)
		sprintf_s(errbuf, sizeof errbuf,"�u�������榨�\\�A���I���ɮפU���@�~�d��[Q],�T�{���~��]�v");
	else 
		sprintf_s(errbuf, sizeof errbuf,"�u���榨�\\�v");
		
	return M_CM_OK;

errexit:
     sprintf_s(errbuf, sizeof errbuf,"SQLCODE[%d], sqlca.sqlerrm[%s]\n", SQLCODE, sqlca.sqlerrm);
     return SQLCODE;
}

long GetData(data, maxlen, delimiter)
char *data, delimiter;
int maxlen;
{
int fori, pre_offset, cnt=0;

    data[0]='\0';
    pre_offset = offset;
	printf("[%s] \n",bp);
    for (fori=pre_offset; bp[fori]!=0x00&&bp[fori]!=0x0d&&bp[fori]!=0x0a&&bp[fori]!=delimiter; fori++)
    {
        offset++;
        if (cnt < maxlen-1)
        {
            data[cnt]=bp[fori];
            cnt++;
        }
    }

    offset++; /* ���ܤU�@�� */
    if (cnt==0) data[cnt++]=0x20; /* �L��Ƶ��ť� */
    data[cnt]=0x00;
    printf("pre_offset[%d]offset[%d]len[%d]data[%s]\n", pre_offset, offset, cnt, data);
}
