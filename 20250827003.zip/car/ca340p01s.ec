/************************************************/
/*						*/
/*   PROGRAM : ca340p01s.ec                     */
/*   �ȫOEmail�@�~		                */
/*						*/
/************************************************/
#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "print.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"

#include "carmsgs.h"
#include "commsgs.h"
#include "ca_field.h"
#include "safeclib.h"
#include <locator.h>

#define  LOAD_FAIL               -1

char  outputf[ N_FILE+1];
char  userid[11], aphome[40];

long car340_email();

$char stmt[1024], DBName[5], sFullName[20];
char  sMsg[10240];
FILE  *sfp, *fp, *fp_note;
int rc, rc1;
DBinfo  *list;
int i, count_db;
$char  semail[51],chinese_name[15], pre_iexaminer[11];
$char fname[101], filename[201], ftitle[1024], noteDataFile[51];
$int  mail_count;
$char  mbuf[9000];
$loc_t  ctxt;
$char   mmsg[1024];
char option[2];

/***************************************************************************/
main(argc, argv)
int argc;
char **argv;
{


   batchinit(); 
   strcpy(DBName,    isNULLstr(argv[1]));
   strcpy(userid,    isNULLstr(argv[2]));
   strcpy(option,    isNULLstr(argv[3]));
   strcpy(outputf,   isNULLstr(argv[4]));

   $WHENEVER SQLERROR GOTO errexit;

   sfp =  (FILE *)STARTLOG();

   if (db_select(DBName) == False)
   {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN"); 
       return M_CM_DB_NOTOPEN;
   }
            
   rc = getApHome(aphome);
   if (rc<0) {
       EWRITE( userid, -1, "In sigalrmcatcher func==>read config file error!!");
       return FAIL;
   }

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   if( option[0] == 'E')   /* ��s�X�檬�A && �H�o�ȫOEmail���֫O�H�� */
   {
       rc=car340_update_fstatus();
       if (rc != M_CM_OK)
       {
           EWRITE(userid, rc, sMsg);
           return rc;
       }

       rc=car340_email();
   }
   else
   {
       EWRITE(userid, -1, "ERROR OPTION");
       return FAIL;
   }

   if (rc != M_CM_OK)
   {
       EWRITE(userid, rc, sMsg);
       return rc;
   }

   WRITELOG( sfp, sMsg);
   ENDLOG(sfp);
   return M_CM_OK;

errexit:
    printf("------car340: SQLCODE[%d]\n",SQLCODE);
    EWRITE(userid, SQLCODE,sqlca.sqlerrm);
    exit(1);

}
/***************************************************************************/
long car340_update_fstatus()
{
 $char iestimate[21], ilast_ply[21], itag[CA_TAG_NUM], iengine[CA_ENGINE_NUM], fstatus1[2], fstatus2[2];
 $char dply1_begin[11], dply2_begin[11], sFullDBName[41], ipolicy1[21], ipolicy2[21], inext_ply[21];
 $long iserial=0;
 $int  iTmp, jTmp, date10, iCount;

    /* ��X�e10�u�@�� */
    jTmp = date10 = 0;
    for(iTmp=1;jTmp<=10;iTmp++)
    {
        $select 1 
           from ca_holiday
          where (today+1 - $iTmp) between holiday_bgn and holiday_end;
        if( SQLCODE == SQLNOTFOUND) jTmp++;
        /* printf("iTmp[%d,jTmp[%d]\n", iTmp, jTmp); */
        if( jTmp == 10 && date10 == 0) date10 = iTmp;
    }
    printf("date10[%d]\n", date10);

    sprintf_s( stmt,sizeof stmt, "SELECT iserial, iestimate, ilast_ply, itag, iengine, dply1_begin, dply2_begin "
                   "  from ca_note "
                   " where ((dply1_begin is not null and fstatus1 = '0') or (dply2_begin is not null and fstatus2 = '0'))"
                   "   and date(dcreate) between (today+1-%d) and today and fstatus != 'D' " , date10);
    printf("stmt[%s]\n", stmt);
    $PREPARE prep1 FROM $stmt;
    $DECLARE curs1 CURSOR FOR prep1;

    $OPEN curs1;
    while(1)
    {
        $FETCH curs1 INTO $iserial, $iestimate, $ilast_ply, $itag, $iengine, $dply1_begin, $dply2_begin;
    	if( SQLCODE == SQLNOTFOUND ) break;
        strcpy( iestimate, trim( iestimate));
        strcpy( ilast_ply, trim( ilast_ply));
        strcpy( itag, trim( itag));
        strcpy( iengine, trim( iengine));
        strcpy( dply1_begin, trim( dply1_begin));
        strcpy( dply2_begin, trim( dply2_begin));
        strcpy( fstatus1, "");
        strcpy( fstatus2, "");
        strcpy( ipolicy1, "");
        strcpy( ipolicy2, "");
        iCount = 0;
        if( strlen( iestimate) != 0)
        {
            strcpy( sFullDBName, get_car_full_db( iestimate));
            strcpy( sFullDBName, trim( sFullDBName));
            if( strlen( sFullDBName) != 0)
            {
                sprintf_s( stmt,sizeof stmt, "select ipolicy1, ipolicy2"
                               "  from %s:estimate"
                               " where iestimate = '%s'", sFullDBName, iestimate);
                printf("         stmt[%s]\n", stmt);
                $PREPARE prep2 FROM $stmt;
                $EXECUTE prep2 into $ipolicy1, $ipolicy2;
                strcpy( ipolicy1, trim(ipolicy1));
                strcpy( ipolicy2, trim(ipolicy2));
                if( strlen( ipolicy1) != 0 && strlen( dply1_begin) != 0) strcpy( fstatus1, "1");
                if( strlen( ipolicy2) != 0 && strlen( dply2_begin) != 0) strcpy( fstatus2, "1");
            }
        }
        if( strlen( ilast_ply) != 0)
        {
            strcpy( sFullDBName, get_car_full_db( ilast_ply));
            sprintf_s( stmt,sizeof stmt, "select inext_ply "
                           "  from %s:ply_relation"
                           " where ipolicy = '%s'", sFullDBName, ilast_ply);
            printf("         stmt[%s]\n", stmt);
            $PREPARE prep9 FROM $stmt;
            $EXECUTE prep9 into $inext_ply;
            strcpy( inext_ply, trim(inext_ply));
            if( strlen( inext_ply) != 0)
            {
                if( strlen( dply1_begin) != 0 && fstatus1[0] != '1')
                {    strcpy( fstatus1, "1"); strcpy( ipolicy1, inext_ply);}
                if( strlen( dply2_begin) != 0 && fstatus2[0] != '1')
                {    strcpy( fstatus2, "1"); strcpy( ipolicy2, inext_ply);}
            }
        }
        if( strlen( iengine) != 0)
        {
            if( strlen( dply1_begin) != 0 && fstatus1[0] != '1')
            {
                for (i=0;i<count_db;i++)
                {
                    sprintf_s( stmt,sizeof stmt, "select a.ipolicy from %s:policy a, %s:ply_relation b where a.ipolicy = b.ipolicy "
                                   "       and iengine = '%s' and date(dcreate) >= today - 30 and iofficer not like 'W%%' and fcard_class = '1'",
                                     list[i].dbname, list[i].dbname, iengine);
                    $PREPARE prep5 FROM $stmt;
                    $EXECUTE prep5 into $ipolicy1;
                    if( SQLCODE == 0) {strcpy( fstatus1, "1");break;}

                }
                printf("         stmt[%s]\n", stmt);
            }
            if( strlen( dply2_begin) != 0 && fstatus2[0] != '1')
            {
                for (i=0;i<count_db;i++)
                {
                    sprintf_s( stmt,sizeof stmt, "select a.ipolicy from %s:policy a, %s:ply_relation b where a.ipolicy = b.ipolicy "
                                   "       and iengine = '%s' and date(dcreate) >= today - 30 and iofficer not like 'W%%' and fcard_class = '2'",
                                     list[i].dbname, list[i].dbname, iengine);
                    $PREPARE prep6 FROM $stmt;
                    $EXECUTE prep6 into $ipolicy2;
                    if( SQLCODE == 0) {strcpy( fstatus2, "1");break;}

                }
                printf("         stmt[%s]\n", stmt);
            }
        }
        if( strlen( itag) != 0)
        {
            if( strlen( dply1_begin) != 0 && fstatus1[0] != '1')
            {
                for (i=0;i<count_db;i++)
                {
                    sprintf_s( stmt,sizeof stmt, "select a.ipolicy from %s:policy a, %s:ply_relation b where a.ipolicy = b.ipolicy "
                                   "       and itag = '%s' and date(dcreate) >= today - 30 and iofficer not like 'W%%' and fcard_class = '1'",
                                     list[i].dbname, list[i].dbname, itag);
                    $PREPARE prep7 FROM $stmt;
                    $EXECUTE prep7 into $ipolicy1;
                    if( SQLCODE == 0) {strcpy( fstatus1, "1");break;}

                }
                printf("         stmt[%s]\n", stmt);
            }
            if( strlen( dply2_begin) != 0 && fstatus2[0] != '1')
            {
                for (i=0;i<count_db;i++)
                {
                    sprintf_s( stmt,sizeof stmt, "select a.ipolicy from %s:policy a, %s:ply_relation b where a.ipolicy = b.ipolicy "
                                   "       and itag = '%s' and date(dcreate) >= today - 30 and iofficer not like 'W%%' and fcard_class = '2'",
                                     list[i].dbname, list[i].dbname, itag);
                    $PREPARE prep8 FROM $stmt;
                    $EXECUTE prep8 into $ipolicy2;
                    if( SQLCODE == 0) {strcpy( fstatus2, "1");break;}
                }
                printf("         stmt[%s]\n", stmt);
            }
        }
        if( fstatus1[0] == '1') $update ca_note set fstatus1 = $fstatus1, ipolicy1 = $ipolicy1 where iserial = $iserial;
        if( fstatus2[0] == '1') $update ca_note set fstatus2 = $fstatus2, ipolicy2 = $ipolicy2 where iserial = $iserial;
    }

    return M_CM_OK;

errexit:
    sprintf_s( sMsg,sizeof sMsg, "car340_update_fstatus:sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    printf("%s", sMsg);
    return SQLCODE;
}
/***************************************************************************/
long car340_email()
{
 $char iestimate[21], ilast_ply[21], icard1[21], nassured[121], iassured[21], itag[CA_TAG_NUM], iengine[CA_ENGINE_NUM], iofficer[11];
 $char dply1_begin[11], dply1_end[11], dply2_begin[11], dply2_end[11], ncar_note[61], nass_note[61], nins_note[61];
 $char nseal_note[61], nremark[256], iexaminer[11], dcreateBgn[11], dcreateEnd[11], fstatus[11], fstatus1[11], fstatus2[11];
 $char icreate[11], iupdate[11], dcreate[31], dupdate[31], stoday[11];
 
 /* �Ӹ�B�n (nassured,iassured) add by larry 103.02.19 (1030211003_C1) */
 $char sIpolicy1[21],sIpolicy2[2],sFullDBName[41],stmt1[512];
 $char sFassured[2],sNassured[121],sIassured[21];

 $long iCount, iserial=0;
 $int  iTmp, jTmp, date4, date5;

    /* ���Y */
    strcpy(ftitle, "�Ǹ�,�պ⸹,��O��,�j���Ҹ�,�Q�O�I�H�m�W,�Q�O�I�HID,"
                   "����,������,�g��N��,�j���I�ͮĤ�,�j���I�����,"
                   "���N�I�ͮĤ�,���N�I�����,�j��X�檬�A,���N�X�檬�A,"
                   "���y��ư��D,�Q�O�I�H��ư��D,�ӫO���e���D,�ΦL���D,"
                   "�֫O�H��,���ɤH��,���ɤ��,��s�H��,��s���\n");
 
    /* email��� */
    strcpy(mmsg,
        "<p><span style='font-size:14.0pt;font-family:�з���'>"
        "�U��֫O�D�ޡB�P�� �z�n�G<BR><BR>"
        "�� �w<BR><BR>"
        "�����z�I<BR><BR>"
        "������ҦC��Ƭ��ȫO����J�w�O3�Ӥu�@�ѡA�B�����ɷ��ɤ��]�պ⸹�B��O���B�����Τ������^�|�L�X������A<BR><BR>"
        "�զ]���ɸ�ơ]�պ⸹�B��O���B�����Τ������^�P�X���Ƥ��ųy���t�εL�k���R���̡A�i�L�ݲz�|�C<BR><BR>"
        "���p�]��~�P���|���w��h���]�^�Ъ̡A�q�Ш�U�A�������P���������󳹤��ɮĩʨ������t�^�СA���¡C</span></p>");

    strcpy(mbuf,rtrim(mmsg));
    ctxt.loc_loctype = LOCMEMORY;
    ctxt.loc_buffer = mbuf;
    ctxt.loc_bufsize = 9000;
    ctxt.loc_size =  strlen(mbuf) + 1;
   
    /* ��X�e4,�e5�Ӥu�@�� */
    jTmp = date4 = date5 = 0;
    for(iTmp=1;jTmp<=5;iTmp++)
    {
        $select to_char(today+1,'%Y')::integer - 1911 || to_char(today+1,'%m%d') 
           into $stoday
           from ca_holiday
          where (today+1 - $iTmp) between holiday_bgn and holiday_end;
        if( SQLCODE == SQLNOTFOUND) jTmp++;
        /* printf("iTmp[%d,jTmp[%d]\n", iTmp, jTmp); */
        if( jTmp == 4 && date4 == 0) date4 = iTmp;
        if( jTmp == 5 && date5 == 0) date5 = iTmp;
    }
    strcpy( stoday, trim(stoday));
    /* printf("[%d], [%d]\n", date4, date5); */

    sprintf_s( stmt,sizeof stmt, "SELECT iserial, iestimate, ilast_ply, icard1, nassured, iassured, "
                   "       itag, iengine, iofficer, " 
                   "       to_char(dply1_begin,'%%Y')::integer - 1911 || to_char(dply1_begin,'%%m%%d'), "
                   "       to_char(dply1_end,'%%Y')::integer - 1911 || to_char(dply1_end,'%%m%%d'), "
                   "       to_char(dply2_begin,'%%Y')::integer - 1911 || to_char(dply2_begin,'%%m%%d'), "
                   "       to_char(dply2_end,'%%Y')::integer - 1911 || to_char(dply2_end,'%%m%%d'), "
                   "       case when dply1_begin is null then ' ' when fstatus1 = '1' then '�w�X��' else '���X��' end, "
                   "       case when dply2_begin is null then ' ' when fstatus2 = '1' then '�w�X��' else '���X��' end, "
                   "       ncar_note, nass_note, nins_note, nseal_note, "
                   "       iexaminer, icreate, dcreate, iupdate, dupdate, ipolicy1, ipolicy2 "
                   "  from ca_note "
                   " where ((dply1_begin is not null and fstatus1 = '0') or (dply2_begin is not null and fstatus2 = '0'))"
                   "   and date(dcreate) in (today+1-%d, today+1-%d) and fstatus != 'D' "
                   " order by iexaminer", date4, date5);
    printf("stmt[%s]\n", stmt);
    $PREPARE prep3 FROM $stmt;
    $DECLARE curs3 CURSOR FOR prep3;

    $OPEN curs3;
    strcpy(pre_iexaminer,"");
    mail_count=0;
    while(1)
    {
        $FETCH curs3 INTO $iserial, $iestimate, $ilast_ply, $icard1, $nassured, $iassured, 
                          $itag, $iengine, $iofficer, $dply1_begin, $dply1_end, $dply2_begin, 
                          $dply2_end, $fstatus1, $fstatus2, $ncar_note, $nass_note, $nins_note, 
                          $nseal_note, $iexaminer, $icreate, $dcreate, $iupdate, $dupdate,
                          $sIpolicy1, $sIpolicy2; 
    	  if( SQLCODE == SQLNOTFOUND ) break;
         
        printf("1:iexaminer[%s], iserial[%d]\n", iexaminer, iserial);
        if (strcmp(iexaminer,pre_iexaminer)!=0 )
        {   puts("NEW iexaminer");
            if(mail_count!= 0) 
            {
                rc = car340_write_email();
                if (rc!=M_CM_OK) {
                    sprintf_s( sMsg,sizeof sMsg, "error on car340_write_email\n");
                    return rc;
                }
                mail_count=0;
            }
            fclose(fp);
            memset(fname,0x00,sizeof(fname));
            memset(filename,0x00,sizeof(filename));
            sprintf_s(fname,sizeof fname,"%s�ȫO����_%s.csv", stoday, trim(iexaminer));
            sprintf_s(filename,sizeof filename,"%s/rptftp/car340/%s", aphome, fname);
            printf("filename[%s]\n",filename);
            if (( fp=fopen( filename,"w"))==NULL)
            {
                sprintf_s( sMsg,sizeof sMsg, "Cannot open Ouput file: %s\n", filename);
                printf("%s", sMsg);
                return M_CM_OPEN_FILE_FAIL;
            }

            fprintf(fp,ftitle);
            mail_count++;
        }
        
        /* �Ӹ�B�n (nassured,iassured) add by larry 103.02.19 (1030211003_C1) */
        strcpy(sIpolicy1,trim(sIpolicy1));
        strcpy(sIpolicy2,trim(sIpolicy2));
        strcpy(ilast_ply,trim(ilast_ply));
        if (strlen(sIpolicy1) != 0){
            strcpy(sFullDBName,get_car_full_db(sIpolicy1));
	    sprintf_s(stmt1,sizeof stmt1,"SELECT fassured "
                           "  FROM %s:policy "
                           " WHERE ipolicy = '%s'",sFullDBName,sIpolicy1);
            $PREPARE policy_cur FROM $stmt1;             
            $EXECUTE policy_cur INTO $sFassured;
        }
        else if (strlen(sIpolicy2) != 0){
            strcpy(sFullDBName,get_car_full_db(sIpolicy2));
	    sprintf_s(stmt1,sizeof stmt1,"SELECT fassured "
                          "  FROM %s:policy "
                          " WHERE ipolicy = '%s'",sFullDBName,sIpolicy2);
            $PREPARE policy2_cur FROM $stmt1;             
            $EXECUTE policy2_cur INTO $sFassured;	
        }
        else if (strlen(ilast_ply) != 0){
            strcpy(sFullDBName,get_car_full_db(ilast_ply));
	    sprintf_s(stmt1,sizeof stmt1,"SELECT fassured "
                            " FROM %s:policy "
                            " WHERE ipolicy = '%s'",sFullDBName,ilast_ply);
            $PREPARE policy2_cur FROM $stmt1;             
            $EXECUTE policy2_cur INTO $sFassured;           
        }
        else{
        	  strcpy(sFassured,"1");
        }
        
        strcpy(sFassured,trim(sFassured));
        printf("-----fassured[%s]\n-----",sFassured);
        if ((strncmp(sFassured,"1",1)==0)||(strncmp(sFassured,"3",1)==0)||(strncmp(sFassured,"5",1)==0))
        {
            strcpy(sNassured,substring(nassured,1,2));
	          strcat(sNassured,"�ݢ�");
	          strcpy(sIassured,substring(iassured,1,3));
	          strcat(sIassured,"****");
	          strcat(sIassured,substring(iassured,8,13));
	      }
	      else{
	          strcpy(sNassured,nassured);
	          strcpy(sIassured,iassured);
	      }
        
        strcpy(pre_iexaminer,iexaminer);
        fprintf(fp,"%d,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",
                    iserial, iestimate, ilast_ply, icard1, sNassured, sIassured, 
                    itag, iengine, iofficer, dply1_begin, dply1_end, dply2_begin, 
                    dply2_end, fstatus1, fstatus2, ncar_note, nass_note, nins_note, 
                    nseal_note, iexaminer, icreate, dcreate, iupdate, dupdate);
    }

    if (mail_count!=0) {
        rc = car340_write_email();
        if (rc!=M_CM_OK) {
            printf("error on car340_write_email\n");
            return rc;
        }
        fclose(fp);
    }
    fclose(fp);

    strcpy( sMsg, "�ȫO����email�@�~���槹��");

    return M_CM_OK;

errexit:
    sprintf_s( sMsg,sizeof sMsg, "car340_email:sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    printf("%s", sMsg);
    return SQLCODE;
}

/***************************************************************************/
long car340_write_email()
{
$long iCount;
    $SELECT email,chinese_name
       INTO $semail,$chinese_name
       FROM personal:asempl
      WHERE empl_no = $pre_iexaminer;

    strcpy(semail,trim(semail));
    strcat(semail,"@tmnewa.com.tw");
    printf("semail[%s]\n",semail);

    $SELECT count(*)
       INTO $iCount
       FROM batchemail
      WHERE project_id = 'CAR340'
        AND mail_date = today+1
        AND receiver_email = $semail
        AND receiver_name = $chinese_name
        AND key = $fname
        AND mail_count = $mail_count;

    if( iCount != 0)
    {
        $DELETE FROM batchemail
          WHERE project_id = 'CAR340'
            AND mail_date = today+1
            AND receiver_email = $semail
            AND receiver_name = $chinese_name
            AND key = $fname
            AND mail_count = $mail_count;
    }
    
    /* 1110322014_SC1_batchemail�ಾ�ܷs���x fname�w�]�t���ɦW */
    
    $INSERT INTO batchemail
                (project_id, mail_date, receiver_email,
                 receiver_name, cc, content, key, mail_count,
                 nattachment)
     VALUES
                ("CAR340", today+1, $semail, $chinese_name,
                 " ", $ctxt, $fname, $mail_count,
                 $fname);

    return M_CM_OK;

errexit:
    sprintf_s( sMsg,sizeof sMsg, "car340_write_email:sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    printf("%s", sMsg);
    return SQLCODE;
}
/***************************************************************************/


