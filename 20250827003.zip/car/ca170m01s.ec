/*--------------------------------------------------*/
/*   PROGRAM : cm170m01s.ec by stevechiang          */
/*   MODIFIER:                                      */
/*                                                  */
/*   DATE    : 2021/01/18                           */
/*--------------------------------------------------*/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;
#include <decimal.h>
#include "safeclib.h"

typedef struct {
	char   type;
	char   iins_type[6];
	double pextra_charge;
	double pbusiness;
	char   drate[12];
} car170_t;

char errbuf[512];
$int count1;
$char getfile[300];
FILE   *fp;
static int   recLen=1024;
static char  *bp;
char delimiter = '\t';
int  offset;
int  tmp_len;
/*--------------------------------------------------*/
long car170(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	long rtncode;
	long car170_insert(),car170_single_query(),car170_multiple_query(),car170_update_exec();
	char option;

	cm_buf_init(command);
 	cm_buf_get("%c",&option);
        
        
        
 	switch(option)
 	{
	  	case 'A':
    		rtncode=car170_insert(reply);
        	break;
  		case 'Q':
    		rtncode=car170_single_query(reply);
        	break;
  		case 'M':
        	rtncode=car170_multiple_query(reply);
        	break;
  		case 'D':
  		case 'U':
        	rtncode=car170_update_exec(reply,command,com_len);
        	break;
		case 'B':   /* ��ƾ��W�� */
			rtncode=car170_batch_insert(reply);

			cm_buf_init(ReplyBuf);
			cm_buf_put("%l %s" , rtncode, errbuf);

			tmp_len = cm_buf_len(ReplyBuf);
			if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
				return apiRC;
			else
				return api_OKComplete;
			break;
  		default :
    		if(exitsub(reply,M_CM_WRONG_OPTION) == True)
        		return M_CM_WRONG_OPTION;
           	return apiRC;
 	}
 	return(rtncode);
}

/*--------------------------------------------------*/
long car170_insert(reply)
serverReply reply;
{
	$char    DBName[3],iins_cat[2],iyear[2],iextra_charge[11],iroute[21];
   	$char    iins_type[INSURANCE_TYPE],drate[9],drate_e[12],str_rows[4];
   	$char    userid[11];
   	$double  pextra_charge,pbusiness;
    dec_t    dec_pextra_charge,dec_pbusiness;
    char     tmp_pextra_charge[7],tmp_pbusiness[7];
   	int      rows,tmp_len,i;
   	long     MsgCode;
   	DBinfo   *list;
   	int      k,j = 0,is_add_fail=0, api_f;
   	$char    stmt_buf[2048],stmt_buf2[2048];
   	car170_t *alist;

   	cm_buf_get("%s %s %s %s %s %s %s ",DBName,iins_cat,iyear,iextra_charge,iroute,str_rows,userid);
	
	strcpy(iins_cat,trim(iins_cat));
	strcpy(iyear,trim(iyear));
	strcpy(iextra_charge,trim(iextra_charge));
	strcpy(iroute,trim(iroute));
	strcpy(userid,trim(userid));
	
   	rows=atoi(str_rows);
   	
	$WHENEVER SQLERROR GOTO errexit;
	
   	if(db_select(DBName) == False)
   	{
    	if( exitsub(reply,M_CM_DB_NOTOPEN) == True )
        	return M_CM_DB_NOTOPEN;
      	return apiRC;
   	}
   	
	printf("rows[%d] \n",rows);
	
	alist = (car170_t *) malloc(rows * sizeof (car170_t));
	for (k=0; k<rows; k++)
	{
		cm_buf_get("%s %s %s %s ",iins_type,tmp_pextra_charge,tmp_pbusiness,drate);
		strcpy(iins_type,trim(iins_type));
		strcpy(tmp_pextra_charge,trim(tmp_pextra_charge));
		strcpy(tmp_pbusiness,trim(tmp_pbusiness));
		strcpy(tmp_pbusiness,trim(tmp_pbusiness));
		printf("iins_type[%s],tmp_pextra_charge[%s],tmp_pbusiness[%s],drate[%s] \n",iins_type,tmp_pextra_charge,tmp_pbusiness,drate);
		deccvasc( tmp_pextra_charge, strlen(tmp_pextra_charge), &dec_pextra_charge);
		dectodbl( &dec_pextra_charge, &pextra_charge);
		deccvasc( tmp_pbusiness, strlen(tmp_pbusiness), &dec_pbusiness);
		dectodbl( &dec_pbusiness, &pbusiness);
		printf("dec_pextra_charge[%f],dec_pbusiness[%f] \n",dec_pextra_charge,dec_pbusiness);
		strcpy(alist[k].iins_type,iins_type);
		alist[k].pextra_charge = pextra_charge;
		alist[k].pbusiness = pbusiness;
		strcpy(alist[k].drate,cm_to_infdate(drate));
	}

	if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
	{
		if(exitsub(reply,M_CM_NOT_DBLIST) == True)
			return M_CM_NOT_DBLIST;
		return apiRC;
	}
	
	$BEGIN WORK;
	sprintf_s(stmt_buf, sizeof stmt_buf, "INSERT INTO cm_extra_charge "
  		                    " (iins_cat, iyear, iextra_charge, iroute, iins_type, drate, pextra_charge, pbusiness, iupdate, dupdate) "
  	                 " VALUES (?,?,?,?,?,?,?,?,?,current)");
  	sprintf_s(stmt_buf2, sizeof stmt_buf2, "INSERT INTO cm_extra_charge_log "
  		                    " (itype, iins_cat, iyear, iextra_charge, iroute, iins_type, drate, pextra_charge, pbusiness, iupdate, dupdate) "
  	                 " VALUES ('A',?,?,?,?,?,?,?,?,?,current)");
	for (k=0; k<rows; k++)
	{
		$PREPARE b_id FROM $stmt_buf;
		$PREPARE b_id2 FROM $stmt_buf2;
		strcpy(iins_type,alist[k].iins_type);
		pextra_charge=alist[k].pextra_charge;
		pbusiness=alist[k].pbusiness;
		strcpy(drate_e,alist[k].drate);
		printf("iins_cat[%s],iyear[%s],iextra_charge[%s],iroute[%s] \n",iins_cat,iyear,iextra_charge,iroute);
		printf("iins_type[%s],pextra_charge[%f],pbusiness[%f],drate_e[%s] \n",iins_type,pextra_charge,pbusiness,drate_e);
		$EXECUTE b_id USING $iins_cat,$iyear,$iextra_charge,$iroute,$iins_type,$drate_e,$pextra_charge,$pbusiness,$userid;
		printf("SQLCODE[%d] \n",SQLCODE);
		if(SQLCODE != 0)
		{
			is_add_fail = 3;
			break;
		}
		$EXECUTE b_id2 USING $iins_cat,$iyear,$iextra_charge,$iroute,$iins_type,$drate_e,$pextra_charge,$pbusiness,$userid;
		printf("SQLCODE[%d] \n",SQLCODE);
		if(SQLCODE != 0)
		{
			is_add_fail = 3;
			break;
		}
	}
	
	if(is_add_fail == 3)
	{
		is_add_fail = 1;
	}
	
	cm_buf_init(ReplyBuf);
	cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);
	tmp_len = cm_buf_len(ReplyBuf);

	api_f = api_OKComplete;
	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
	{
		is_add_fail = 2;
	}

	for (i = 0; i < rows; i++)
  		free( alist[i]);
  		
	free ((char *) alist);

	if( is_add_fail == 1 ) goto errexit;
	if( is_add_fail == 2 )
	{
   		$ROLLBACK WORK;
   		return apiRC;
  	}
  	
   	$WHENEVER SQLERROR GOTO errexit;
   	$COMMIT WORK;
   	return api_OKComplete;

 errexit:
   	MsgCode = SQLCODE;
   	$WHENEVER SQLERROR CONTINUE;
   	$ROLLBACK WORK;
   	if( SQLCODE != 0) MsgCode = SQLCODE;
   	if(exitsub(reply,MsgCode) == True)
    	return MsgCode;
   	else
    	return apiRC;
}

/*--------------------------------------------------*/
long car170_single_query(reply)
serverReply reply;
{
	$char   DBName[3],iins_cat[2],iyear[3],iextra_charge[11],iroute[21],drate[10];
	$char   drate_e[11];
	$long   drate_l = 0;
	$char   iins_type[INSURANCE_TYPE];
	$char   str_pextra_charge[20],str_pbusiness[20];
	$double pextra_charge = 0.0, pbusiness = 0.0;
	$char   iupdate[11],dupdate[21];
	int     rows=0,tmp_len,first;

	cm_buf_get("%s %s %s %s %s %s",DBName,iins_cat,iyear,iextra_charge,iroute,drate);

	printf("drate[%s] \n",drate);
	strcpy(drate_e,cm_to_infdate(drate));
	printf("iins_cat[%s],iyear[%s],iextra_charge[%s],iroute[%s],drate_e[%s] \n",iins_cat,iyear,iextra_charge,iroute,drate_e);
	
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
		return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
	
	cm_buf_init(ReplyBuf);
	cm_buf_res_msg();
	cm_buf_res_count();
	
	$DECLARE q_cur CURSOR FOR
	  SELECT iins_cat, iyear, iextra_charge, iroute, iins_type, pextra_charge, pbusiness, drate, iupdate, dupdate 
	    INTO $iins_cat, $iyear, $iextra_charge, $iroute, $iins_type, $pextra_charge, $pbusiness, $drate_l, $iupdate, $dupdate 
	    FROM cm_extra_charge
	   WHERE iins_cat = $iins_cat 
	     AND iyear = $iyear
	     AND iextra_charge = $iextra_charge
	     AND iroute = $iroute
	     AND drate = $drate_e; 
	$OPEN q_cur;
	for(;;)
	{
		$FETCH q_cur;
		if (SQLCODE != 0) break;
		
		first=0;
		sprintf_s(str_pextra_charge, sizeof str_pextra_charge, "%.4f",pextra_charge);
		sprintf_s(str_pbusiness, sizeof str_pbusiness, "%.4f",pbusiness);
		strcpy(drate,cm_cdate_str_100(drate_l));
		printf("drate[%s] \n",drate);
		cm_buf_put("%s %s %s %s %s %s %s %s %s %s ",iins_cat,iyear,iextra_charge,iroute,iins_type,str_pextra_charge,str_pbusiness,drate,iupdate,dupdate);
		
		rows++;
	}
	$CLOSE q_cur;
	$FREE q_cur;
	
	if(rows > 0 || SQLCODE==0)      /* at least one row is selected */
	{
		cm_buf_put_msg(M_CM_OK);
		cm_buf_put_count(rows);
		tmp_len = cm_buf_len(ReplyBuf);
		if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
			return apiRC;
		else
			return api_OKComplete;
	}
	else
	{
		if( exitsub(reply,M_CA_NRATE) == True )
			return M_CA_NRATE;
		return apiRC;
	}
	
errexit:
	if ( exitsub(reply,SQLCODE) == True )
		return SQLCODE;
	return apiRC;
}

/*--------------------------------------------------*/
long car170_multiple_query(reply)
serverReply reply;
{
	$char   stmt[1024];
	$char   DBName[3],iins_cat[2],iyear[3],iextra_charge[11],iroute[21],drate[11];
    $char   drate_e[11];
    $long   drate_l = 0;
    $char   iins_type[INSURANCE_TYPE];
    $double pextra_charge = 0.0, pbusiness = 0.0;
    $char   str_pextra_charge[50],str_pbusiness[50];
    $char   stmp_iins_cat[128],stmp_iyear[128],stmp_iextra_charge[128],stmp_iroute[128],stmp_drate[128];

   	char    tmpbuf[4000];
   	int     count=0,repbuf_len=0,tmp_len=0,replycnt=0;
   	int     i,total_count=0,flag;

    cm_buf_get("%s %s %s %s %s %s",DBName,iins_cat,iyear,iextra_charge,iroute,drate);

   	$WHENEVER SQLERROR GOTO errexit;

   	if (db_select(DBName) == False)
   	{
    	if( exitsub(reply,M_CM_DB_NOTOPEN) == True )
        	return M_CM_DB_NOTOPEN;
      	return apiRC;
   	}
	
	if(iins_cat[0] == '*')
    {
    	strcpy(stmp_iins_cat," ");
	}
   	else
    {
    	sprintf_s(stmp_iins_cat, sizeof stmp_iins_cat, "AND iins_cat matches '%s' ",iins_cat);
	}
	
	if(iyear[0] == '*')
    {
    	strcpy(stmp_iyear," ");
	}
   	else
    {
    	sprintf_s(stmp_iyear, sizeof stmp_iyear, "AND iyear matches '%s' ",iyear);
	}
	
	if(iextra_charge[0] == '*')
    {
    	strcpy(stmp_iextra_charge," ");
	}
   	else
    {
    	sprintf_s(stmp_iextra_charge, sizeof stmp_iextra_charge, "AND iextra_charge matches '%s' ",iextra_charge);
	}
	
	if(iroute[0] == '*')
    {
    	strcpy(stmp_iroute," ");
	}
   	else
    {
    	sprintf_s(stmp_iroute, sizeof stmp_iroute, "AND iroute matches '%s' ",iroute);
	}

   	if(drate[0] == '*')
    {
    	strcpy(stmp_drate," ");
	}
   	else
    {
    	sprintf_s(stmp_drate, sizeof stmp_drate, "AND drate = '%s' ",cm_to_infdate(drate));
	}

	sprintf_s(stmt, sizeof stmt, " SELECT iins_cat,iyear,iextra_charge,iroute,iins_type,pextra_charge,pbusiness,drate "
                   "  FROM cm_extra_charge "
                   " WHERE 1 = 1 %s %s %s %s %s "
                  " ORDER BY iins_cat,iyear,iextra_charge,iroute,drate",stmp_iins_cat,stmp_iyear,stmp_iextra_charge,stmp_iroute,stmp_drate);

	$PREPARE m_cur1 FROM $stmt;
	$DECLARE m_cur CURSOR FOR m_cur1;
	printf("stmt[%s]\n",stmt);
	$OPEN m_cur;
   	for(;;)
   	{
    	$FETCH m_cur INTO $iins_cat,$iyear,$iextra_charge,$iroute,$iins_type,$pextra_charge,$pbusiness,$drate_l;
     	if (SQLCODE != 0) break;

      	cm_buf_init(tmpbuf);

      	if ( count == 0 )
      	{
        	cm_buf_res_msg();             /* reserve for MsgCode and count */
         	cm_buf_res_count();
      	}
		
		sprintf_s(str_pextra_charge, sizeof str_pextra_charge, "%.4f",pextra_charge);
      	sprintf_s(str_pbusiness, sizeof str_pbusiness, "%.4f",pbusiness);
      	strcpy(drate,cm_cdate_str_100(drate_l));
      	printf("drate[%s]",drate);
      	cm_buf_put("%s %s %s %s %s %s %s %s ",iins_cat,iyear,iextra_charge,iroute,iins_type,str_pextra_charge,str_pbusiness,drate);

      	tmp_len = cm_buf_len(tmpbuf);

      	if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
      	{
        	memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
         	repbuf_len += tmp_len;
         	count++;
     	}
      	else                               /* more than 4K, send to client side */
      	{
        	cm_buf_init(ReplyBuf);
         	cm_buf_put_msg(M_CM_OK);
         	cm_buf_put_count(count);
         	if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
         	{
            	$CLOSE m_cur;
	    		$FREE m_cur;
            	return apiRC;
			}
        	else               /* clear ReplyBuf and count to start all over again */
        	{
            	replycnt++;
	            if (replycnt == 10)   /* more than 30K, client cannot display,error */
    	        {
        	       	cm_buf_init(ReplyBuf);
            	   	cm_buf_put("%l",M_CM_OUT_SPACE);
	               	tmp_len = cm_buf_len(ReplyBuf);
               		if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
                  	return apiRC;
               		return M_CM_OUT_SPACE;
            	}
            	ReplyBuf[0] = '\0';
            	count = 0;
            	cm_buf_init(ReplyBuf);
            	cm_buf_res_msg();           /* reserve for MsgCode and count */
            	cm_buf_res_count();
            	sprintf_s(str_pextra_charge, sizeof str_pextra_charge, "%.4f",pextra_charge);
      			sprintf_s(str_pbusiness, sizeof str_pbusiness, "%.4f",pbusiness);
            	strcpy(drate,cm_cdate_str_100(drate_l));
            	printf("drate[%s]",drate);
      			cm_buf_put("%s %s %s %s %s %s %s %s",iins_cat,iyear,iextra_charge,iroute,iins_type,str_pextra_charge,str_pbusiness,drate);
            	repbuf_len = cm_buf_len(ReplyBuf);
            	count++;
			}
		}
	} /* for loop */

   	$CLOSE m_cur;
   	$FREE m_cur;

	if (count > 0)   /* break out, at least one record is selected */
   	{
      	cm_buf_init(ReplyBuf);
      	cm_buf_put_msg(M_CM_OK);
      	cm_buf_put_count(count);
      	if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
        	return apiRC;
      	return api_OKComplete;
   	}
   	else            /* break out, not any raw is found */
   	{
    	if( exitsub(reply,M_CA_NRATE) == True )
        	return M_CA_NRATE;
      	return apiRC;
   	}

errexit:
   	if ( exitsub(reply,SQLCODE) == True )
    	return SQLCODE;
   	return apiRC;
}

long car170_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	$char   DBName[3],iins_cat[2],iyear[3],iextra_charge[11],iroute[21];
	$char   iins_type[INSURANCE_TYPE],drate[21],drate_e[21];
	$char   userid[11],iupdate[11],dupdate[21];
	$double pextra_charge,pbusiness;
	$long   drate_l = 0;
	dec_t   dec_pextra_charge,dec_pbusiness;
	dec_t   dec_cur_pextra_charge,dec_cur_pbusiness;
	$char   tmp_pextra_charge[50],tmp_pbusiness[50];
	$char   str_pextra_charge[50],str_pbusiness[50];
	
	int    tmp_len,raw_len,count,rows=0,i,flag,count1,y;
	
	$char   cur_iins_cat[2],cur_iyear[3],cur_iextra_charge[11],cur_iroute[21];
	$char   cur_iins_type[INSURANCE_TYPE],cur_drate[21],cur_drate_e[21];
	$long   cur_drate_l;
	$double cur_pextra_charge = 0.0,cur_pbusiness = 0.0;
	$char   cur_str_pextra_charge[7],cur_str_pbusiness[7];
	$char   cur_iupdate[11],cur_dupdate[21];
	
	char  option,*pos,*raw_ptr,cur_buf[10000],*comm,type;
	long  dummy;
	long  MsgCode;
	int   first;
	int   k, j, is_del_fail=0, is_upd_fail=0;
	$char  stmt_buf[1024];
	
	car170_t *alist;
	
	comm = (char *) command;
	cm_buf_init(command);
	cm_buf_get("%c %s",&option,DBName);

	$WHENEVER SQLERROR GOTO errexit;

   	if (db_select(DBName) == False)
		return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

	memcpy(&raw_len,&comm[com_len],sizeof(int));
	pos = &comm[com_len+sizeof(int)];
	raw_ptr = malloc(raw_len);

	if (raw_ptr != (char*)0)
		memcpy(raw_ptr,pos,raw_len);
	else
	{
		return exitsub(reply,M_CM_NOT_MALLOC) ? M_CM_NOT_MALLOC : apiRC;
	}

   	cm_buf_init(raw_ptr);
   	cm_buf_get("%l %d",&dummy,&count);
   	count1 = count;
   	cm_buf_get("%s %s %s %s %s %s %s %s %s %s", 
   	           cur_iins_cat,cur_iyear,cur_iextra_charge,cur_iroute,cur_iins_type,cur_str_pextra_charge,cur_str_pbusiness,cur_drate,cur_iupdate,cur_dupdate);
	strcpy(cur_drate_e,cm_to_infdate(cur_drate));
	
	strcpy(cur_iins_cat,trim(cur_iins_cat));
	strcpy(cur_iyear,trim(cur_iyear));
	strcpy(cur_iextra_charge,trim(cur_iextra_charge));
	strcpy(cur_iroute,trim(cur_iroute));
	strcpy(cur_iins_type,trim(cur_iins_type));
	strcpy(cur_str_pextra_charge,trim(cur_str_pextra_charge));
	strcpy(cur_str_pbusiness,trim(cur_str_pbusiness));
	
	printf("cur_iins_cat[%s],cur_iyear[%s],cur_iextra_charge[%s],cur_iroute[%s] \n",cur_iins_cat,cur_iyear,cur_iextra_charge,cur_iroute);
	printf("cur_iins_type[%s],cur_str_pextra_charge[%s],cur_str_pbusiness[%s],drate_e[%s] \n",cur_iins_type,cur_str_pextra_charge,cur_str_pbusiness,cur_drate_e);
   	$BEGIN WORK;

   	cm_buf_init(cur_buf);
   	cm_buf_res_msg();
   	cm_buf_res_count();

   	$WHENEVER SQLERROR GOTO errexit;

   	cm_buf_put_msg(dummy);
   	cm_buf_put_count(count);

   	$DECLARE u_cur CURSOR FOR
      SELECT iins_cat, iyear, iextra_charge, iroute, 
             iins_type, pextra_charge, pbusiness, drate, 
             iupdate, dupdate 
        INTO $iins_cat, $iyear, $iextra_charge, $iroute,
             $iins_type, $pextra_charge, $pbusiness, $drate_l,
             $iupdate, $dupdate
        FROM cm_extra_charge
       WHERE iins_cat = $cur_iins_cat
         AND iyear = $cur_iyear
         AND iextra_charge = $cur_iextra_charge
         AND iroute = $cur_iroute
         AND drate = $cur_drate_e;
   	$OPEN u_cur;

   	rows=0;

   	for(;;)
	{
    	$FETCH u_cur;
      	if (SQLCODE == SQLNOTFOUND) break;
      	strcpy(iins_cat,trim(iins_cat));
		strcpy(iyear,trim(iyear));
		strcpy(iextra_charge,trim(iextra_charge));
		strcpy(iroute,trim(iroute));
		strcpy(iins_type,trim(iins_type));

	    cm_buf_put("%s %s %s %s", iins_cat,iyear,iextra_charge,iroute);
		sprintf_s(str_pextra_charge, sizeof str_pextra_charge, "%.4f",pextra_charge);
      	sprintf_s(str_pbusiness, sizeof str_pbusiness, "%.4f",pbusiness);
		strcpy(drate,cm_cdate_str_100(drate_l));
	    cm_buf_put("%s %s %s %s %s %s",iins_type,str_pextra_charge,str_pbusiness,drate,iupdate,dupdate);
	    
		rows++;
   	}
   	$CLOSE u_cur;
   	$FREE u_cur;
   
	printf("1 count=%d\n",count);
	printf("1 ROWS=%d\n",rows);

   	if(rows != count) 
   	{
      	MsgCode = M_CM_NOT_EQUAL;
      	$WHENEVER SQLERROR CONTINUE;
      	$ROLLBACK WORK;
      	if( SQLCODE != 0) MsgCode = SQLCODE;
      	return exitsub(reply,MsgCode) ? MsgCode : apiRC;

      	cm_buf_put("%s",cur_iins_type);
      	cm_buf_put("%s",cur_pextra_charge);
      	cm_buf_put("%s",cur_pbusiness);
      	cm_buf_put("%s",cur_drate);
	} 
	printf("2 count=%d\n",count);
	printf("2 ROWS=%d\n",rows);

   	if(rows != count) 
   	{
      	MsgCode = M_CM_NOT_EQUAL;
      	$WHENEVER SQLERROR CONTINUE;
      	$ROLLBACK WORK;
      	if( SQLCODE != 0) MsgCode = SQLCODE;
      	return exitsub(reply,MsgCode) ? MsgCode : apiRC;
   	}
   	$WHENEVER SQLERROR GOTO errexit;

	write(1, cur_buf, raw_len); 
	printf("\n");
	write(1, raw_ptr, raw_len);
	printf("\n");
	free(raw_ptr);
   	$WHENEVER SQLERROR GOTO errexit;

   	if( option == 'D' )
   	{
  		strcpy(stmt_buf, "DELETE FROM cm_extra_charge \
	                       WHERE iins_cat = ? \
	                         AND iyear = ? \
	                         AND iextra_charge = ? \
	                         AND iroute = ? \
	                         AND drate = ? ");

   		$PREPARE d_id FROM $stmt_buf;
   		$EXECUTE d_id USING $cur_iins_cat,$cur_iyear,$cur_iextra_charge,$cur_iroute,$cur_drate_e;

     	cm_buf_init(ReplyBuf);
     	cm_buf_put("%l", M_CM_OK);
     	tmp_len = cm_buf_len(ReplyBuf);
     	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
     	{
        	$WHENEVER SQLERROR CONTINUE;
         	$ROLLBACK WORK;
         	return apiRC;
     	}
     	$WHENEVER SQLERROR GOTO errexit;
     	$COMMIT WORK;
     	return api_OKComplete;
   	}
   	else if(option == 'U')
   	{
    	cm_buf_init(command);
      	cm_buf_get("%c %s",&option,DBName);
      	cm_buf_get("%s %s %s %s %s",iins_cat,iyear,iextra_charge,iroute,userid);
      	strcpy(iins_cat,trim(iins_cat));
		strcpy(iyear,trim(iyear));
		strcpy(iextra_charge,trim(iextra_charge));
		strcpy(iroute,trim(iroute));
      	
      	cm_buf_get("%d",&rows);
      	alist = (car170_t *) malloc(rows *sizeof (car170_t));

      	for (k = 0; k <rows; k++)
      	{
       		cm_buf_get("%c %s %s %s %s ",&type,iins_type,tmp_pextra_charge,tmp_pbusiness,drate);

	       	deccvasc( tmp_pextra_charge, strlen(tmp_pextra_charge), &dec_pextra_charge);
       		dectodbl( &dec_pextra_charge, &pextra_charge);
       		deccvasc( tmp_pbusiness, strlen(tmp_pbusiness), &dec_pbusiness);
       		dectodbl( &dec_pbusiness, &pbusiness);
       		printf("pextra_charge[%f],pbusiness[%f] \n",pextra_charge,pbusiness);
       		
       		alist[k].type = type;
       		strcpy(alist[k].iins_type,iins_type);
       		alist[k].pextra_charge=pextra_charge;
       		alist[k].pbusiness=pbusiness;
        	strcpy(alist[k].drate,cm_to_infdate(drate));
		}

    	$WHENEVER SQLERROR GOTO errexit;
    	for(k=0; k < rows; k++)
		{
			iins_type[0] = drate_e[0] = '\0';
			pextra_charge = pbusiness= 0.0;
			
			strcpy(iins_type,alist[k].iins_type);
			strcpy(iins_type,trim(iins_type));
       		pextra_charge=alist[k].pextra_charge;
       		pbusiness=alist[k].pbusiness;
       		strcpy(drate_e,alist[k].drate);
			
			printf("alist[k].type[%c] \n",alist[k].type);
            switch(alist[k].type)
            {
            	case 'A':
                	strcpy(stmt_buf, "INSERT INTO cm_extra_charge (iins_cat,iyear,iextra_charge,iroute,iins_type,pextra_charge,pbusiness,drate,iupdate,dupdate) \
                                      VALUES (?,?,?,?,?,?,?,?,?,current)");
					$PREPARE u1_id FROM $stmt_buf;
					$EXECUTE u1_id USING $iins_cat,$iyear,$iextra_charge,$iroute,$iins_type,$pextra_charge,$pbusiness,$drate_e,$userid;
					if(SQLCODE != 0)
                    	is_upd_fail = 3;
                    	
                   	strcpy(stmt_buf,
                	       "INSERT INTO cm_extra_charge_log (itype,iins_cat,iyear,iextra_charge,iroute,iins_type,pextra_charge,pbusiness,drate,iupdate,dupdate) \
                            VALUES ('A',?,?,?,?,?,?,?,?,?,current)");
					$PREPARE u1_id_log FROM $stmt_buf;
					$EXECUTE u1_id_log USING $iins_cat,$iyear,$iextra_charge,$iroute,$iins_type,$pextra_charge,$pbusiness,$drate_e,$userid;
					if(SQLCODE != 0)
                    	is_upd_fail = 3;
					break;
				case 'D':
                	sprintf_s(stmt_buf, sizeof stmt_buf, "INSERT INTO cm_extra_charge_log "
                                      " SELECT 'D',iins_cat,iyear,iextra_charge,iroute,iins_type,drate,pextra_charge,pbusiness,'%s',current "
                                      " FROM cm_extra_charge "
                   	                  " WHERE iins_cat=? AND iyear=? "
                   	                  "  AND iextra_charge=? AND iroute=? "
                   	                  "  AND iins_type=? AND drate=? ",userid);
					$PREPARE u2_id_log FROM $stmt_buf;
                	$EXECUTE u2_id_log USING $cur_iins_cat,$cur_iyear,$cur_iextra_charge,$cur_iroute,$iins_type,$cur_drate_e;
					if(SQLCODE != 0)
                    	is_upd_fail = 3;

                	strcpy(stmt_buf, "DELETE FROM cm_extra_charge \
                   	                   WHERE iins_cat=? AND iyear=? \
                   	                     AND iextra_charge=? AND iroute=? \
                   	                     AND iins_type=? AND drate=?");
					$PREPARE u2_id FROM $stmt_buf;
                    $EXECUTE u2_id USING $cur_iins_cat,$cur_iyear,$cur_iextra_charge,$cur_iroute,$iins_type,$cur_drate_e;
					if(SQLCODE != 0)
                    	is_upd_fail = 3;
					break;
                case 'U':
                	
                	printf("iins_cat[%s],iyear[%s],iextra_charge[%s],iroute[%s] \n",iins_cat,iyear,iextra_charge,iroute);
                	printf("iins_type[%s],pextra_charge[%f],pbusiness[%f],drate_e[%s] \n",iins_type,pextra_charge,pbusiness,drate_e);
                	printf("cur_iins_cat[%s],cur_iyear[%s],cur_iextra_charge[%s],cur_iroute[%s],iins_type[%s] \n",cur_iins_cat,cur_iyear,cur_iextra_charge,cur_iroute,iins_type);

					sprintf_s(stmt_buf, sizeof stmt_buf, "INSERT INTO cm_extra_charge_log "
				                       " SELECT 'U',iins_cat,iyear,iextra_charge,iroute,iins_type,drate,pextra_charge,pbusiness,'%s',current "
                           	           " FROM cm_extra_charge "
                           	           " WHERE iins_cat = ? AND iyear = ? AND iextra_charge = ? "
                           	           "  AND iroute = ? AND iins_type = ? AND drate = ?",userid);
					$PREPARE u3_id_log FROM $stmt_buf;
					$EXECUTE u3_id_log USING $cur_iins_cat,$cur_iyear,$cur_iextra_charge,$cur_iroute,$iins_type,$cur_drate_e;
					if(SQLCODE != 0)
                       	is_upd_fail = 3;
					
                   	strcpy(stmt_buf,
				            "UPDATE cm_extra_charge \
				                SET (iins_cat,iyear,iextra_charge,iroute,iins_type,pextra_charge,pbusiness,drate,iupdate,dupdate) \
               	   			      = (?,?,?,?,?,?,?,?,?,current ) \
                           	  WHERE iins_cat = ? AND iyear = ? AND iextra_charge = ? \
                           	    AND iroute = ? AND iins_type = ? AND drate = ?");
                    printf("stmt_buf[%s] \n",stmt_buf);
                   	$PREPARE u3_id FROM $stmt_buf;
                   	$EXECUTE u3_id USING $iins_cat,$iyear,$iextra_charge,$iroute,
                   	                     $iins_type,$pextra_charge,$pbusiness,$drate_e,$userid,
                                         $cur_iins_cat,$cur_iyear,$cur_iextra_charge,$cur_iroute,$iins_type,$cur_drate_e;
					if(SQLCODE != 0)
                       	is_upd_fail = 3;
					break;
				default:
                    $WHENEVER SQLERROR CONTINUE;
                    $ROLLBACK WORK;
                    if(exitsub(reply,M_CM_WRONG_OPTION) == True)
                    	return M_CM_WRONG_OPTION;
					else
                       	return apiRC;
			}
		}
		
		for (i = 0; i < rows; i++)
			free( alist[i]);
  		free ((char *) alist);
		
    	cm_buf_init(ReplyBuf);
    	cm_buf_put("%l",M_CM_OK);
    	tmp_len = cm_buf_len(ReplyBuf);
    	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    	{
    		$WHENEVER SQLERROR CONTINUE;
        	$ROLLBACK WORK;
        	return apiRC;
    	}
	    $WHENEVER SQLERROR GOTO errexit;
    	$COMMIT WORK;
    	return api_OKComplete;
   	}
   	else
   	{
    	return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
   	}

errexit:
	MsgCode = SQLCODE;
	$WHENEVER SQLERROR CONTINUE;
   	$ROLLBACK WORK;
   	if( SQLCODE != 0) MsgCode = SQLCODE;
   	return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
/*--------------------------------------------------*/

/* ��ƾ��W�� */
long car170_batch_insert(reply)
serverReply reply;
{
	$char   DBName[5], nfiledate[20], stmt[2048], stmt1[2048], stmt2[2048], stmt3[2048], stmt_buf[300];
	$char   sApHome[30], filename[101],logname[101], cmd_str[2048];
	$char   iins_cat[2],iins_cat_tmp[2],iyear[2],iyear_tmp[2],iextra_charge[11],iextra_charge_tmp[11],iroute[21],iroute_tmp[21];
   	$char   iins_type[INSURANCE_TYPE],iins_type_tmp[INSURANCE_TYPE],drate[11],drate_tmp[11],str_rows[4],nfile_log[101];
   	$char   userid[11];
   	$char   pextra_charge_c[8],pbusiness_c[8],pextra_charge_c_tmp[8],pbusiness_c_tmp[8];
   	$double pextra_charge = 0.0,pbusiness = 0.0;
	$int    rc, cnt, rc1 ,irate;
	$int     stmt_len;
	$int     i, j, is_add_fail=0, api_f;
	$long    MsgCode;
	$int    err;


	cm_buf_get("%s %s %s ",DBName, nfiledate, userid);
	
	rc = getApHome(sApHome);
	if (rc<0) {
		strcpy( errbuf,"read Config file error!!-->getApHome\n");
		return rc;
	}
	
	sprintf_s(nfile_log, sizeof nfile_log,"car170_%s_log.txt",nfiledate);
	sprintf_s(filename, sizeof filename, "%s/dat/car/car170_%s.txt", sApHome,nfiledate);
	sprintf_s(logname, sizeof logname, "%s/rptftp/car170_%s_log.txt",sApHome,nfiledate);
	printf("filename[%s]\n",filename);
	
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		sprintf_s(errbuf, sizeof errbuf, "��Ʈw�L�k�}��[%s]\n", DBName);
		return M_CM_DB_NOTOPEN;
	}

	/* ����J�Ȧs��,�T�{��J���O�_���T */
	stmt_len = 0;
	stmt_len += sprintf_s(stmt+stmt_len, sizeof stmt, "SELECT iins_cat, iyear, iextra_charge, iroute, iins_type, drate, pextra_charge, pbusiness "
	                                    " FROM cm_extra_charge WHERE 1=0 INTO TEMP ca_extra1 with no log; \r\n");
	stmt_len += sprintf_s(stmt+stmt_len, sizeof stmt, "LOAD FROM %s DELIMITER '\t' INSERT INTO ca_extra1; \r\n",filename);
	sprintf_s(cmd_str, sizeof cmd_str, "dbaccess sysdb > %s 2>&1 << !\r\n" "%s\r\n!", logname, stmt);
	printf("cmd_str[%s]\n",cmd_str);
	rc = system(cmd_str);
	printf("rc[%d]\n",rc);
	if (rc != 0)
	{
		sprintf_s(errbuf, sizeof errbuf, "load file error[%s]\n���I���ɮפU���@�~�d��[Q],�T�{���~��]", logname);
		rc1=rptftpinsert(userid,"car170",nfile_log);
		return rc;
	}
	
	/********************************************************************************************/
	/* */
	sprintf_s(getfile, sizeof getfile, "%s/dat/car/car170_%s.txt",sApHome,nfiledate);
	printf("getfile[%s]\n",getfile);
	
	if ((fp=fopen(getfile,"rt"))==NULL)
	{
		return SQLCODE;
	}
	
	if ((bp=malloc(recLen))==NULL)
	{
		printf("System malloc failed  !\n");
		free(bp);
		return SQLCODE;
	}
        
	$CREATE TEMP table cm_extra_charge_tmp
	(	
		iins_cat      char(1),
		iyear         char(1),
		iextra_charge char(10),
		iroute 		  char(20),
		iins_type     char(6),
		drate         date,
		pextra_charge decimal(6,4),
		pbusiness     decimal(6,4)
	)with no log;
	
	/* ���j�Ÿ� */
	delimiter = '\t';
	

	
	while(fgets(bp,recLen,fp))
	{
		printf("recLen[%d]\n",recLen);
		if (feof(fp)) break;
		
		

		offset = 0;
		/* ��ƨ��o���Ǥ��i�ܰ�*/
		GetData(iins_cat_tmp        ,sizeof(iins_cat)        ,delimiter);
		GetData(iyear_tmp           ,sizeof(iyear)           ,delimiter);
		GetData(iextra_charge_tmp   ,sizeof(iextra_charge)   ,delimiter);
		GetData(iroute_tmp          ,sizeof(iroute)          ,delimiter);
		GetData(iins_type_tmp       ,sizeof(iins_type)       ,delimiter);
		GetData(drate_tmp           ,sizeof(drate)           ,delimiter);
		GetData(pextra_charge_c_tmp ,sizeof(pextra_charge_c) ,delimiter);
		GetData(pbusiness_c_tmp     ,sizeof(pbusiness_c)     ,delimiter);
		
		printf("iins_cat[%s]  ,iyear[%s] ,iextra_charge[%s]   ,iroute[%s] \n",iins_cat,iyear,iextra_charge,iroute);
		printf("iins_type[%s] ,drate[%s] ,pextra_charge_c[%s] ,pbusiness_c[%s] \n",iins_type,drate,pextra_charge_c,pbusiness_c);
                
                strcpy(iins_cat,trim(iins_cat_tmp));
                strcpy(iyear,trim(iyear_tmp));
                strcpy(iextra_charge,trim(iextra_charge_tmp));
                strcpy(iroute,trim(iroute_tmp));
                strcpy(iins_type,trim(iins_type_tmp));
                strcpy(drate,trim(drate_tmp));
                strcpy(pextra_charge_c,trim(pextra_charge_c_tmp));
                strcpy(pbusiness_c,trim(pbusiness_c_tmp));
		                          
		$INSERT INTO cm_extra_charge_tmp(iins_cat,iyear,iextra_charge,iroute,iins_type,drate,pextra_charge,pbusiness) 
		                          VALUES($iins_cat,$iyear,$iextra_charge,$iroute,$iins_type,$drate,$pextra_charge_c,$pbusiness_c);                
	}
	fclose(fp);
	free(bp);
	sprintf_s(stmt1, sizeof stmt1, "SELECT iins_cat,iyear,iextra_charge,iroute,iins_type,drate,pextra_charge,pbusiness FROM cm_extra_charge_tmp " );
	printf("stmt1=[%s]\n",stmt1);

	$PREPARE PRE_EXTRA FROM $stmt1;
	$DECLARE DEC_EXTRA CURSOR FOR PRE_EXTRA;
	$OPEN DEC_EXTRA;
	err = 0;
	for(;;)
	{
     	$FETCH DEC_EXTRA INTO $iins_cat,$iyear,$iextra_charge,$iroute,$iins_type,$drate,$pextra_charge,$pbusiness;
		printf("iins_cat[%s]  iyear[%s] iextra_charge[%s] iroute[%s] \n",iins_cat,iyear,iextra_charge,iroute);
		printf("iins_type[%s] drate[%d] pextra_charge[%f] pbusiness[%f] \n",iins_type,drate,pextra_charge,pbusiness);
		
		if (SQLCODE != 0) break;
		
		strcpy(iextra_charge,trim(iextra_charge));
		strcpy(iroute,trim(iroute));
		strcpy(iins_type,trim(iins_type));
		
		if(strcmp(iextra_charge,"21") ==0 || strcmp(iextra_charge,"31") ==0)
		{
			if(strcmp(iroute,"*") ==0) err++;
			else if(strcmp(iins_type,"*") ==0) err++;
		}
    
	}
	$CLOSE DEC_EXTRA;
	$FREE DEC_EXTRA;
	
	if (err == 0)
	{
		/*INSERT cm_extra_charge*/
		sprintf_s(stmt2, sizeof stmt2, " INSERT INTO cm_extra_charge " 
		              " SELECT iins_cat,iyear,iextra_charge,iroute,iins_type,drate,pextra_charge,pbusiness,'%s',current,0 "
		              "   FROM cm_extra_charge_tmp;",userid);
		$PREPARE EXTRA_INSERT FROM $stmt2;
		$EXECUTE EXTRA_INSERT;
		
		/*INSERT cm_extra_charge_log*/
		sprintf_s(stmt3, sizeof stmt3, " INSERT INTO cm_extra_charge_log " 
		              " SELECT 'B',iins_cat,iyear,iextra_charge,iroute,iins_type,drate,pextra_charge,pbusiness,'%s',current "
		              "   FROM cm_extra_charge_tmp;",userid);
		$PREPARE EXTRA_INSERT_LOG FROM $stmt3;
		$EXECUTE EXTRA_INSERT_LOG;
	}
	else 
	{
		printf("�O�o�q���N��21/31�A�q��/�I�إN�����o��J�� \n");
		sprintf_s(errbuf, sizeof errbuf, "�O�o�q���N��21/31�A�q��/�I�إN�����o��J��");
		$DROP TABLE cm_extra_charge_tmp;
		return M_CM_ADD_FAIL;
	}
	$DROP TABLE cm_extra_charge_tmp;

	sprintf_s(errbuf, sizeof errbuf, "���槹��");
	return M_CM_OK;

errexit:
	sprintf_s(errbuf, sizeof errbuf, "SQLCODE[%d], sqlca.sqlerrm[%s]\n", SQLCODE, sqlca.sqlerrm);
	return SQLCODE;
}

long GetData(data, maxlen, delimiter)
char *data, delimiter;
int maxlen;
{
int fori, pre_offset, cnt=0;

    data[0]='\0';
    pre_offset = offset;

    for (fori=pre_offset; bp[fori]!=0x00&&bp[fori]!=0x0d&&bp[fori]!=0x0a&&bp[fori]!=delimiter; fori++)
    {
        offset++;
        if (cnt < maxlen-1)
        {
            data[cnt]=bp[fori];
            cnt++;
        }
    }

    offset++; /* ���ܤU�@�� */
    if (cnt==0) data[cnt++]=0x20; /* �L��Ƶ��ť� */
    data[cnt]=0x00;
    printf("pre_offset[%d]offset[%d]len[%d]data[%s]\n", pre_offset, offset, cnt, data);
}