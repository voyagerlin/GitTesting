/*----------------------------------------------------------------------------*/
/*   PROGRAM : ca_rpt_policy1.ec                                              */
/*   AUTHOR  : EALEX                                                          */
/*   DATE    : 2001/07/23                                                     */
/*   Modify  : 2010/11/22 �ѷs���I�������ק�{��                              */
/*----------------------------------------------------------------------------*/
#include <stdio.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include <malloc.h>
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "print.h"
#include "is_def.h"
#include "carmsgs.h"
#include "commsgs.h"
$include "ply_ins_cover.h";
$include "var_length.h";
#include "car_common.h"
#include "ISvar.h"

#define MAX_ROW 60
#define script      "�Ԩ��O����Ӫ�"
#define script1     "�Ԫ���"
#define str_ps      "����G���O�I��ҩӫO�����ȳd���I�A�ȭ��r�p�H���`�Ψ�����ˮɡA�����q�l�t���v�d���C"
#define str_add01   "���������o�ͩӫO�����I�ƬG�A�o�ɦ��̰�15��N�B�����C"
#define str_add11   "���������o�ͩӫO�ѵs�I�ƬG�A�o�ɦ��̰�30��N�B�����C"
#define str_add0111 "���������o�ͨ�����ѵs�I�ƬG�A�o���O�ɦ��̰�15���30��N�B�����C"
                
#define str_ins_30_1   "�W�B�d�����[���ڡЫO�٫��ӫO�d�򤣥]�t�G�ĤT�H�d�����s���v�T�έ�����˳d�����[���ڡC"
#define str_ins_30_2   "�W�B�d�����[���ڡЫO�٫��ӫO�d�򤣥]�t�G�ĤT�H�d�����s���v�T���[���ڡC"
#define str_ins_30_3   "�W�B�d�����[���ڡЫO�٫��ӫO�d�򤣥]�t�G������˳d�����[���ڡC"
#define str_ins_30_11  "�W�B�d�����[���ڡЫO�٫��ӫO�d��]�t�G������˳d�����[���ڡC"
#define str_ins_30_12  "�W�B�d�����[���ڡЫO�٫��ӫO�d��]�t�G�ĤT�H�d�����s���v�T���[���ڡC"
#define str_ins_30_13  "�W�B�d�����[���ڡЫO�٫��ӫO�d��]�t�G�ĤT�H�d�����s���v�T�έ�����˳d�����[���ڡC"
#define str_ins_30_21  "�W�B�d�����[���ڡЫO�٫��ӫO�d��]�t�G�ĤT�H�d�����s���v�T���[���ڦ����]�t������˳d�����[���ڡC"
#define str_ins_30_22  "�W�B�d�����[���ڡЫO�٫��ӫO�d��]�t�G������˳d�����[���ڦ����]�t�ĤT�H�d�����s���v�T���[���ڡC"
#define str_ins_30_4   "�W�B�d�����[���ڡЫO�٫��ӫO�d�򤣥]�t�G������˳d���I�C"

#define str_ins_301_1  "�W�B�d���I���[���ڡа�D���W���ӫO�d�򤣥]�t�G������˳d�����[���ڡC"
#define str_ins_301_11 "�W�B�d���I���[���ڡа�D���W���ӫO�d��]�t�G������˳d�����[���ڡC"
#define str_ins_301_2  "�W�B�d���I���[���ڡа�D���W���ӫO�d�򤣥]�t�G������˳d���I�C"

#define str_ins_302_1  "�ĤT�H�W�B�d���O�I�а�D���W���ӫO�d�򤣥]�t�G������˳d�����[���ڡC"
#define str_ins_302_11 "�ĤT�H�W�B�d���O�I�а�D���W���ӫO�d��]�t�G������˳d�����[���ڡC"
#define str_ins_302_2  "�ĤT�H�W�B�d���O�I�а�D���W���ӫO�d�򤣥]�t�G������˳d���I�C"
#define str_ins_302_21 "�ĤT�H�W�B�d���O�I�а�D���W���ӫO�d��]�t�G������˳d���I�C"

#define str_ins_530_1 "�r�V�Z�W�B�d���I�ӫO�d�򤣥]�t�G�r�V�Z������˳d���I�C"
#define str_ins_530_11 "�r�V�Z�W�B�d���I�ӫO�d��]�t�G�r�V�Z������˳d���I�C"

#define str_ins_55_car_11 "�����I�ӫO�d�򤣧t�˱w"

/* ��ϰϰ� */
#define area_restrict "��p�ϰ�:�O�W,���,����,�����άF���Ϊv�v�ҤΤ��a��"

/* �֭�帹 */
#define approval_1 "96�~6��8��s�w�F�ʮ��W96�r��0191����Ƭd"
#define approval_2 "96�~8��31��̦�F�|���ĺʷ��޲z�e���|95"
#define approval_3 "�~9��1����ޫO�G�r��09502522257���O�ץ�"
/* �t�X�O�v�ۥѤƦL�X�֭�帹 */
/*#define approval_980401_1 "98�~3��31��s�w�F�ʮ��W98�r��015120����Ƭd"*/
/*car9810133�X�֭ק� */
#define approval_980401_1 "99�~11��15��s�w�F�ʮ��W99�r��0655����Ƭd"
#define approval_980401_2 " "
#define approval_980401_3 " "
/* �����~�Ȥw�ɦ��u�f������ */
#define direct_disc_98    "(���O��w�ɦ�������O���O�O�u�f)"

/* �q�l���ڻ������*/
/*#define str_feterms1 "���ۦ����O�I��Υ����q���Ѥ�QR Code�ɡA�Y�����w�����O����ڡC"
#define str_feterms2 "���pQR Code���X�l���εL�k�ϥΩζ��ȥ��O����ڽЬ��~�ȪA�ȤH���ΫȪA�M�u�C"*/

/*** Report Variable ***/
 long           code;
 static  $char  icard[CARD_NUM];
 static  $char  r_icard[CARD_NUM];
 static  $char  nname[11];
 static  $char  ileader[10];
 static  $char  ipolicy[POLICY_NUM_1];
 static  $char  irelative_ply[POLICY_NUM_1];
 static  $char  fcard_class[2];
 static  $char  fprint[2];
 static  $char  ilast_ply[POLICY_NUM_1];
 static  $char  ibig_branch[5];
 static  $char  ibig_office[10];
 static  $char  ibig_sales[11];
 static  $char  ibroker[BROKER];
 static  char   new_ibroker[BROKER];
 static  char   dsc_ibroker[13];
 static  $char  iofficer[11];
 static  $char  iresource[2];
 static  $char  icashier[11];
 static  $long  mdmg_prem;
 static  $long  mlia_prem;
 static  $double  mpure_prem;
 static  $char  dpolicy[11];
 static  $long  dpolicy_long;
 static  $char  iexaminer[11];
 static  $char  ientry[11];
 static  $int   mdiscount;
 static  $char  iply_area[11];
 static  $char  ps_dtl[101];
 static  $char  ps_60[101];  /* 1120316006_SC5_�L��-���N�I���e�{�s�W���@�������������O�N��05�ή��s�X��t�ηs�W���@�����O */
 static  $char  transno[21];
 static  $char  dendorse[11];
 static  $int   seqno;
 static  $char  fassured[2];
 static  $char  nassured[122];
 static  $char  nuser[20];
 static  $char  nbenef[43];
 static  $char  aassured[92];
 static  $char  aassured_cmb[92];
 static  $char  aassured_zip[CA_ZIP];
 static  $char  itel[21];
 static  $char  apayment[92];
 static  $char  apayment_zip[CA_ZIP];
 static  $char  iextra_charge[11];
 static  $char  iroute[21];            /* bis9901141 �q���N�� */
 static  $int   qply_period;
 static  $long  dply_begin;
 static  $long  dply_end;
 static  $long  dentry;
 static  $char  ipro_year[5];
 static  $char  ibrand[9];
 static  $char  icar_type[3];
 static  $char  icar_flag[2];
 /*static  $int   qcylinder;*/ /* 5 */
 static  $double   qcylinder;
 static  $char  iengine[CA_ENGINE_NUM];
 static  $char  ibody[CA_BODY_NUM];
 static  $char  itag[CA_TAG_NUM];
 static  $double mcar_price;
 static  $double  qpt;
 static  $char  fpt[2];
 static  $double  psex_age;
 static  $double  psex_age_damage;
 static  $double  plia_acc;
 static  $double  pdmg_acc;
 static  $double  mcommission;
 static  $char  nbrand_abbr[14];
 static  $char  ncar_abbr[14];
 static  $char  fcar_class[2];
 static  $char  ilicense[11];
 static  $char  iassured[11];
 static  $char  fsex[2];
 static  $char  fmarriage[2];
 static  $double  pdmg_factor;
 static  $double  pbrg_factor;
 static  $char  flimit[2];
 static  $int   pdmg_align;
 static  $int   pbrg_align;
 static  $int   plia_align;
 static  $char  nequipment[31];
 static  $char  prn_deduct[20];
 static  $char  str_deduct[18];
 static  $char  tmp_deduct[20];
 static  $char  iins_type[7];
 static  $char  nins_type[50];
 static  $char  main_paid[81];
 static  $int   qcoverage;
 static  $char  cover_print[121];
 static  $char  edomain1[20];
 static  $char  fdeduct[2];
 static  $char  deduct_print[21];
 static  $char  fcomp_24;
 static  $int   injured_cover;
 static  $int   death_cover;
 static  $int   damage_cover;
 static  $int   deduct;
 static  $long  ins_premium;
 static  $int   qserial;
 static  $long  premium1;
 static  $long  prem21;
 static  $char  nequipment_7h_14[31], nequipment_7h_19[31];
 static  $char  iofficer_7h_14[11], iofficer_7h_19[11];
 static  $int   premium_7h_14, premium_7h_19;
 static  $int   old_premium_7h_14, old_premium_7h_19;
 static  $int   mdiscount_7h_14, mdiscount_7h_19;
 static  $char  nequipment_17[31];
 static  $int   premium_17;
 static  $int   old_premium_17;
 static  $int   mdiscount_17;
 static  $char  nequipment_7h[31];
 static  $char  iofficer_7h[11];
 static  $char  site2[3];
 static  $date r_dbegin,r_dend;
 $char   LHsNname[11];
 $char   npresident[11],tax_area[11];
 $char   ifirm_pid[13],sIlicense[11],sItel[21];
 static  $char   napplicant[121];
 static  char  code1[3],code2[11], code3[3];
 char    s_r_dbegin[14],s_r_dend[14],tmp_str3[10];
 static  $date Today;
 
 static  $char  fsex_appl[2];

 static  char  yy1[4],mm1[3],dd1[3];
 static  char  yy2[4],mm2[3],dd2[3];
 static  char  yy3[4],mm3[3],dd3[3];
 static  char  yy4[4],mm4[3],dd4[3];
 static  char  yy5[4],mm5[3],dd5[3];
 static  char  yy6[4],mm6[3],dd6[3];
 static  char  yy7[4],mm7[4],dd7[4];
 static  char  is_yy[4],is_mm[3],is_dd[3],s_fpt[10];
 static  char  fcar1[3],fcar2[3];
 static  char  s_qcylinder[9],s_qpt[10];
 static  char  by[4],bm[4],bd[4];
 static  char  sex1[4],marriage1[5];
 static  char  s_psex_age[16],s_psex_age_damage[16],s_dmg_align[10],s_brg_align[10],s_lia_align[10];
 static  char  s_premium1[20];
 static  char  ply1[6],ply[3],ply2[14],last_ply1[6],last_ply2[14];
 static  $double  pcommission,pagent;
 static  $char  drate_ym[6];
 static  $char  s_note1[70];  /****** �����O�T�T�� ******/
 static  $char  s_note2[70];
 static  $char  provision[22];
 static  char  CompanyId[3];
 char     sTmp[21];
 int   add_mplace_01_flag , add_mplace_11_flag;
$long  qday, dissue, dbirth;
$long  coverage1,coverage2,coverage3;
$char  sCoverage1[20],sCoverage2[20],sCoverage3[20];
 char  flag_29_exist[2],flag_31_exist[2],flag_32_exist[2];
 char  Str29_1[50];
 char  Str29_2[50];
 char  Str29_3[50];
 char  s_note[100];


$long  ins_mdiscount,old_premium,real_premium,real1_premium;
$long  tmp_prem,other_prem,trans_premium;
 char  ch_amt1[40],ch_amt2[40],ch_amt3[40],ch_amt4[40],ch_amt5[40];
 char  s_old_premium[40],s_real_premium[200],s1_real_premium[200],s_prem21[60];
 char  s0_real_premium[200],s2_real_premium[200];
 char  s_dpolicy[14];
$char  s_lia_acc[30],s_dmg_acc[30],s_unk_acc[30];
 char  bak1[60],bak2[60],bak3[60],bak31[60],bak4[60],bak_chiness[60];
 int   people,iins,ben_len=0,ben_len_t=0;
 int   ins_14, ins_17, ins_51, ins_19, ins_31, ins_32, ins_11, ins_56, ins_575960, ins_36, ins_37, ins_150151;
 char  reprint[30],buf[20],tmp_reprint[30];
 long  rate = 0;
$char  deduct_30[11];
$char  deduct_301[11];
$char  deduct_302[11];

long   ins_31_multiple;

 char  str_cover1[25],str_cover2[25],str_cover3[25],str_cover4[25];
 char  str_ins_premium[21];

/*56�I�سQ�O�I�H�W�U��� */
 $char  ninsurant56[31],ninsurant67[31];
 $long  dbirth56,dbirth67;
 $char  iins_type56[7],iinsurant56[11],iinsurant67[11],sIinsurant56[11],sIinsurant67[11];
 $char  nbeneficiary56[31],nbeneficiary67[31], tmp_nbeneficiary56[31], tmp_nbeneficiary67[31];
 $char  relation_bene56[21],relation_bene67[21];
 $char  tbenef56[21],abenef56[91];
 int     line66, line67, list_cnt = 0;   /* �P�_�W�U�L���_,0�����L��,1���L�� */
/*end of �W�U���(modified by Julia Han in 2008/03/26 */


/* �P�_�O�_�C�L�W�U */
int list_print=0; /* 0���C�L,1�����C�L */

/* �O�v�ۥѤ� */
$char     f980401[2]; /* 1:cm_extra_charge�O�v�ͮĤ�>=980401,�O�v�ۥѤƫ�
                         0:cm_extra_charge�O�v�ͮĤ�< 980401,�O�v�ۥѤƫe */
char flag980401[2];

/* �j�O�檺�פ,�Ψӭp��j�O����ܪ��O�O */
$char ply_end[POLICY_NUM_1];

/* �g��N����I�}�Y��,�ݭn�C�X�g��H������W��(officer.nname) */
$char nname_I[11],nname_N[21];

/*�帹�� ca_terms */
$char viins_type[7],ncontract[21],ncontent1[251],ncontent2[251],ncontent3[251],ca_dpolicy[11];
$char stmt1[1024],stmt2[512];
$char stmt1_2[1024],stmt2_2[512];
$varchar ncontent_a[302],ncontent_a_1[151],ncontent_a_2[151],ncontent_a_3[151];
$char ncontent_print[2048];
$int iTmp, iTmp2, iTmp3, iTmp4, iTmp5, iTmp6, iTmp7, iTmp8, iTmp9, iTmp10, count;

/* �I��52,53,55,24 �A�ηs�� -- ����J��˫O�B add by sylvia  */
$char     f52535524[2]; /* 1:�O�v�ͮĤ�>=100/4/15,�A�ηs�� */

/* �q���ĤG���q */
$char sIcomm_obj[11], sIroute_comm[4], sIroute_prop[3], sIcode[2];

char  tmpDrate[6];

int  idbstr;

/* ATM����O 101/06/01�_�խ���15��  modify by sylvia (101.05.24) */
$int	iATM_Fee;

/* D���ڤH�ƤΦW�U add by sylvia 101.06.21 */
$int iQprovision, iCounD, ninsD_cnt;
$char sProvD[100],sProvD_1[100],sProvD_2[100],sTmpIassured[13],sTmpIassured1[13],sTmpNiassured[31],sTmpDbirth[10],sTmpDbirth1[10],PrintDlist[2];
$char sTmpDbirth_yy[4],sTmpDbirth_mm[3],sTmpDbirth_dd[3];
$char ninsType[100];

/* �O��C�L�h�� add by sylvia 101.10.08 (1010928006_C1)*/
/* Tcount �I�ئ��, Pcount �`����, Pline �C�����, Total_Prem �O�O */  
$int  Tcount, Pcount, Pline, ipage;
$long Total_Prem;

/* �I��62,63,64 �A�ηs�� -- ����J��˫O�B add by sylvia (1011214002_C1)  */
$char     f626364[2]; /* �O�v�ͮĤ�>=101/12/01,�A�ηs�� */

/* �ӤH�O��Ӹ�(�B�n/����) add by larry 102.11.13 (1020924002_C1)*/
$char sProtectData[2];
$int ply_6075;		/* ����s����6075 */

/* �M�ץ�O��C�L add by larry 102.12.16 (1021122001_C3) */
$char DBName[05]; /* �D�M�ץ�O�椣�i���Ʈw */
$char sIpolicyB_type[2]; /* �D�M�ץ�O�� (sIpolicyB_type = 0) �M�ץ�O�� (sIpolicyB_type = 1) */
                         /* �e�~��O�� (sIpolicyB_type = 2) */
$char Full_DBName[20];

$char sNassured_56_136[15];

/* 86�I�اe�{�ۭt�B (1040525002_C1) */
$char f86[2]; /* �O�v�ͮĤ�>=104/06/08,�A�ηs�� */

/* �e�~�O��(�e�~�C�L,�l�H�覡) add by larry 103.03.11 (1010523004_C2) */
$char fout_print[2],fmail_type[2],outpolicy[16];
$char sRemark[15],dply_close[11],dcreate[24],sDate[8],sDateTime[22];
$int out_ply_50, out_ply_47, out_ply_147;
$char ntel_leader[51];
char stmp_space[2];

/* �C�L�t�ƪ��B (1031014003_C1) */
$double mequipment;
$char sMequipment[61];
$char bak1_ply[60];

/* �C�L��� (1040625002_C1) */
$char iquota[7];
$char nbranch[41];

/* �e�~�O��(������l���) (1041102003_C1)*/
$char tablePly[64], tableRelation[64], tableInsType[64], tablePaPly[64],tableAssured[64];
$char sIrouteNote[3],sIrouteNote2[2];
$int  cntIroute,cntIroute2,cnt_term;

/* �e�~��O�v�N���P�_ */
$int  irate_ym,out_ply_dmg;

/*150151�I�ح��m���Ȫ��B*/
$char tmp_150151[40];

/* 1050801002_C1_�s�W����~�S�w�γ~�ΩT�w�ϥΤH���[���� */
$int provision_J;

/**/
$double punknown_acc;
$char   iquery_num_unknown[121];

/*1051128002_C1_�վ㨮�I�e�~�O��L�s�@�~���ڸ��X�����覡*/
$char Ireceipt1_1[11],Ireceipt1_2[11],Ireceipt_2[11];
$int tmp_Ireceipt1_1;

/*1060426011_C1_CAR320,CAR322 �ק�30��301�I�ئC�L�n�O�ѳ������r*/
/*�ݨD�l�[�O���r*/
$char iins_type24[7],iins_type55[7];
int flag24,flag55,flag255;
int flag49117;
int flag555;
/*1060818001_C1_cmn134a-���I*/
int bufa_print = 0,bufa_print2;
$long i_begin=0,i_end=0;

/**/
$char nc1[100] = "",nc2[100] = "",nc3[100] = "",nc4[100] = "";
$char nc5[100] = "",nc6[100] = "",nc7[100] = "",nc8[100] = "";

$char icar_type_ori[3];

/*�U�L�@���M�ץ�ɵo*/
$int bufa_ins_17 = 0,bufa_ins_19 = 0;

/*���P�X�W��25�X*/
$char iengine_0[CA_ENGINE_NUM],iengine_1[21],iengine_2[6];

/*���[���ڻ�����r*/
$char nprovision[42];
$char nprov_note[210];
$char nprov_note_print[220];

struct lin
{
    int no;
    int pos[MAX_ROW];
    char *pp[MAX_ROW];
};

struct  lin  ppage[120];
struct  lin  iins_page[120];
struct  lin  bottom_page[120];

$int provision_X = 0;
$char nprov_X[50];

/* 1071107007_SC2_UBI�{���W�u */
$int provision_U = 0;

/* 1071226006_SC4_�w���ƫ����վ�(���²v+�ĤT�H�d��) */
$int provision_P = 0,provision_Q = 0,provision_V = 0;
$int provision_M = 0,provision_Y = 0;
$int cnt_V09 = 0,cnt_V3132 = 0;
$char nprov_pqv[105];

/* 1080225007_SC4_�s�W�r�˰ӫ~  */
$int provision_K = 0;

/* 1080708002_SC4_�s�W�����������(�N��L)  */
$int provision_L = 0;
$char nprov_L[50];

/* 1080311008_SC4_�ͮĤ��71�_����s�v�I */
$char fchk_24[2];

/* 1100419003_SC3_���I�O�����QR Code�q�l��*/
$char feterms[2];
$char str_sEterms[2];

/* 1120316006_SC5_�L��-���N�I���e�{�s�W���@�������������O�N��05�ή��s�X��t�ηs�W���@�����O */
$char fdbgn20230601[2],fdply20230601[2];

long car306_query();
long ca306_get_data();

long car306_query1();
long ca306_get_data1();
long insert_prt_table();
char *get_full_dbname();
char *get_car_full_db();
/*int get_18_6x_prt_deduct();*/
int IsFcomp24();
int IsFcomp55();

long ca_rpt();
long process_rpt();
int *iGetChinesePos();


/*--------------------------------------------------------------------------------*/
long ca_rpt_policy(sIpolicy, title, ibatch_no, sIkind, iFbig, iPrintList, type, sPly_end, iprint,PrintDlist,ProtectData,DbName,ipolicyB_type,Ireceipt1,Ireceipt2,Ireceipt_end,sEterms)
$char sIpolicy[],iprint[11];
char title[];
int iFbig;
int ibatch_no;
char sIkind[];
int iPrintList;
char type;
char sPly_end[];
char PrintDlist[2];
char ProtectData[2];
char DbName[5];
char ipolicyB_type[2];
char sEterms[2];
char Ireceipt1[11];
char Ireceipt2[11];
char *Ireceipt_end;
{
    int rc;
    $int sType;
    iPrintList=0;

    Pline = 21; /* �C�@���I�س����i�C�L�����  add by sylvia 101.10.08 (1010928006_C1)*/
		/*1090218008_SC1_�e�~�O���I�ة��Ӱ϶������C�󥿬�21��*/
    printf(">>>>INTO ca_rpt_policy(),ipolicy[%s],ibatch_no[%d],List[%d]\n",sIpolicy,ibatch_no,iPrintList);
    strcpy(reprint,title);
    strcpy(ply_end,sPly_end);
    strcpy(PrintDlist, trim(PrintDlist));
    strcpy(sProtectData,trim(ProtectData));
    strcpy(DBName,trim(DbName));
    strcpy(sIpolicyB_type,trim(ipolicyB_type));
    strcpy(Ireceipt1_1,trim(Ireceipt1));
    strcpy(Ireceipt1_2,trim(Ireceipt2));
    strcpy(str_sEterms,trim(sEterms));
    
    
    printf("---------------- PrintDlist = [%s] ------------\n",PrintDlist);
    printf("---------------- ProtectData = [%s] -----------\n",sProtectData);
    printf("---------------- DBName = [%s] ----------------\n",DBName);
    printf("---------------- sIpolicyB_type = [%s] --------\n",sIpolicyB_type);
    printf("---------------- Ireceipt1_1 = [%s] ------------\n",Ireceipt1_1);
    printf("---------------- Ireceipt1_2 = [%s] ------------\n",Ireceipt1_2);
    printf("---------------- str_sEterms = [%s] ------------\n",str_sEterms);

    /* �s�W�@��temp table��m�I�ئC�L�һݪ���� */
    /* line_no�C�L����� */
    /* field1�Ĥ@��,�I�ؽs�� */
    /* field2�ĤG��,�I�ئW�� */
    /* field3�ĤT��,�D�n���I���� */
    /* field4�ĥ|��,�O�I���B */
    /* field5�Ĥ���,�O���I���ɪ��O�B */
    /* field5�Ĥ���,�ۭt�B */
    /* field6�ĤC��,�O�I�O */
    /* ins_premium�O�I�O(���A��long),�ˮ֥� */


    $CREATE TEMP TABLE tbl_print
    (   ipolicy   char(20),
        line_no      serial,
        field1    varchar(6),
        field2    varchar(120),
        field3    varchar(250),
        field4    varchar(120),
        field5    varchar(120),
        field6    varchar(120),
        field7    varchar(120),
        ins_premium integer
    ) with no log;
    $CREATE TEMP TABLE print_layout
    (   ipolicy   char(20),
        line_no   decimal(10,2),
        field1    varchar(6),
        field2    varchar(120),
        field3    varchar(250),
        field4    varchar(120),
        field5    varchar(120),
        field6    varchar(120),
        field7    varchar(120),
        ins_premium integer,
        field_tmp varchar(120)
    ) with no log;
    /* ��h�ӫO�B */
    $CREATE TEMP TABLE tbl_coverage
    (   ipolicy   char(20),
        serial_no serial,
        contain1  char(20)
    ) with no log;
    
    /*�帹*/
	$CREATE TEMP TABLE tbl_ncontent
    (   ipolicy   char(20),
        ncont  varchar(151),
        serial_no serial
    ) with no log;
    	$CREATE TEMP TABLE tbl_ncontent2
    (   ipolicy   char(20),
        ncont  varchar(151),
        serial_no serial
    ) with no log;
    
    /*�r�p�H�ˮ`�I�W�U*/
    $CREATE TEMP TABLE tbl_56list
    (   ipolicy       char(20),
        iins_type     char(6),
        iinsurant     char(10),
        ninsurant     char(30),
        dbirth        date,
        nbeneficiary  char(30),
        relation_bene char(1),
        tbenef        char(20),
        abenef        char(90),
        serial_no serial
    ) with no log;
    
    rc = getCompanyId(CompanyId);
    if (rc < 0)
        return rc;

    /* car9803301 default �֭�帹flag */
    strcpy(flag980401,"0");
    /* end of default */

    strcpy(deduct_30,"");
    strcpy(deduct_301,"");
    strcpy(deduct_302,"");
    
        
    if (iFbig == FALSE)
    {
        printf("!!!!!!!!!!!!!!!!!!!!!1111111111111\n");
        rc=car306_query(sIpolicy);
        if (rc!=M_CM_OK) return rc;
        /* �ھڶǤJ���ѼƨM�w�O�_�C�L�W�U */
        list_print = iPrintList;
        rc=ca306_get_data(sIpolicy, sIkind);
        if (rc!=M_CM_OK) return rc;
    }
    else
    {
        printf("�C�L�j�O��\n");
        rc=car306_query1(sIpolicy, ibatch_no, type);
        if (rc!=M_CM_OK) return rc;
        /* �ھڶǤJ���ѼƨM�w�O�_�C�L�W�U */
        list_print = iPrintList;
        rc=ca306_get_data1(sIpolicy, ibatch_no, type);
        if (rc!=M_CM_OK) return rc;
    }

    if(strncmp(sIpolicyB_type,"4",1)!=0) /*sIpolicyB_type=4�A�Ӧ�car353���I�O��ֹ�q���H�o�@�~�A�ޥ�ca_rpt_policy�O���I�ئC�L�榡*/
    {
    	
    	rc=process_rpt();
        if( rc!= M_CM_OK)
            return rc;

        /* �O��C�L�h�� add by sylvia 101.10.08 (1010928006_C1)    */
	Tcount = Pcount = ipage = 0;
	$select count(*) into $Tcount from print_layout where ipolicy = $ipolicy;

	if ((Tcount <= Pline) && strlen(ncontent_print)/98 + 1 < 5 )
	{
	    Pcount = 1;		/* �Ȥ@�� */
	}
	else if ((Tcount <= Pline) && strlen(ncontent_print)/98 + 1 >= 5)
	{
	    Pcount = 2;
	}
	else
	{
	    /* �w�d�C�L(�ӤW��),(���U��)��� */
	    Pcount = Tcount / (Pline-1);
	    if ((Tcount % (Pline-1)) > 0 )
	        Pcount = Pcount + 1 ;
	}
	  
	Total_Prem = 0;
	for (ipage = 1; ipage <= Pcount; ipage ++)
	{
            printf("********* Total_Prem=[%ld]ipage=[%d]Pcount=[%d]\n",Total_Prem,ipage,Pcount);
	    printf("487+++++Ireceipt1_1[%s]\n",Ireceipt1_1);
            if(ipage>1)
	    {
	        if(strlen(Ireceipt1_1) == 0)
		    rc = ca_rpt(iFbig, ibatch_no, iprint, "");
		else
		{
		    tmp_Ireceipt1_1=atoi(Ireceipt1_1)+(ipage-1);
		    printf("500+++++tmp_Ireceipt1_1[%d]\n",tmp_Ireceipt1_1);
		    if(tmp_Ireceipt1_1 <= atoi(Ireceipt1_2))
			rc = ca_rpt(iFbig, ibatch_no, iprint, itoa(tmp_Ireceipt1_1));
		    else
			rc = ca_rpt(iFbig, ibatch_no, iprint, "");
		    strcpy(Ireceipt_end,itoa(tmp_Ireceipt1_1));
		    printf("506+++++Ireceipt_end[%s]\n",Ireceipt_end);
		}
            }
	    else
	    {
		if(strlen(Ireceipt1_1) == 0)
		    rc = ca_rpt(iFbig, ibatch_no, iprint, "");
		else
		{
		    if(atoi(Ireceipt1_1) > atoi(Ireceipt1_2))
		    	rc = ca_rpt(iFbig, ibatch_no, iprint, "");
		    else
		    	rc = ca_rpt(iFbig, ibatch_no, iprint, Ireceipt1_1);
	            strcpy(Ireceipt_end,Ireceipt1_1);
		    printf("520+++++Ireceipt_end[%s]\n",Ireceipt_end);
		}		    		
	    }
		    			      
	    if( rc!= M_CM_OK)
		return rc;
        }
    	
    	
    }

    return M_CM_OK;
}

/*--------------------------------------------------------------------*/
void car306_clear()
{
    int i;

    printf("in clear\n");
    sex1[0]=0;
    marriage1[0]=0;
    edomain1[0]=0;
    qcoverage=0;
    prem21=0;
    s_dpolicy[0]=0;
    s_r_dbegin[0]=0;
    s_r_dend[0]=0;
    r_dbegin=0;
    r_dend=0;
    fcar1[0]=0;
    fcar2[0]=0;
    s_premium1[0]=0;
    ply1[0]=0;
    ply[0]=0;
    ply2[0]=0;
    iply_area[0]=0;
    last_ply1[0]=0;
    last_ply2[0]=0;
    ps_dtl[0]=0;
    ps_60[0]=0;
    ins_11 = ins_14 = ins_17 = ins_19 = ins_31 = ins_32 = ins_51 = ins_56 = ins_575960 = ins_36 = ins_37 = ins_150151 = 0;
    qday=0;
    coverage1=coverage2=coverage3=0;
    ins_31_multiple = 0;
    line66 = line67 = 0;
    list_cnt = list_print = 0;

    strcpy(flag_29_exist," "); strcpy(flag_31_exist," "); strcpy(flag_32_exist," ");
    strcpy(sCoverage1,""); strcpy(sCoverage2,""); strcpy(sCoverage3,"");
    strcpy(icard,""); strcpy(ipolicy,""); strcpy(irelative_ply,"");
    strcpy(fcard_class,""); strcpy(fprint,"");
    strcpy(ilast_ply,""); strcpy(ibroker,""); strcpy(iofficer,"");
    strcpy(ibig_branch,""); strcpy(ibig_office,"");
    strcpy(ibig_sales,"");
    strcpy(icashier,""); strcpy(iexaminer,""); strcpy(ientry,"");
    strcpy(r_icard,""); strcpy(nbrand_abbr,""); strcpy(ncar_abbr,"");
    strcpy(fcar_class,"");
    strcpy(fassured,""); strcpy(nassured,""); strcpy(nuser,"");
    strcpy(nbenef,""); strcpy(aassured,""); strcpy(itel,"");
    strcpy(aassured_zip,"");strcpy(aassured_cmb,"");
    strcpy(ipro_year,""); strcpy(ibrand,"");
    strcpy(icar_type,""); strcpy(iengine,""); strcpy(ibody,"");
    strcpy(icar_flag,"");
    strcpy(itag,""); strcpy(ilicense,"");
    strcpy(fpt,"");
    strcpy(fsex,""); strcpy(fmarriage,"");strcpy(fsex_appl,"");
    strcpy(flimit,""); strcpy(apayment,""); strcpy(nequipment,"");
    strcpy(napplicant,""); strcpy(apayment_zip,""); strcpy(iextra_charge,"");
    strcpy(transno,""); strcpy(dendorse,"");
    strcpy(nequipment_17,""); premium_17=0; old_premium_17=0; mdiscount_17=0;
    strcpy(nequipment_7h_14,""); premium_7h_14=0; old_premium_7h_14=0; mdiscount_7h_14=0;
    strcpy(nequipment_7h_19,""); premium_7h_19=0; old_premium_7h_19=0; mdiscount_7h_19=0;
    strcpy(s_note1,""); strcpy(s_note2,"");
    seqno=0;
    mcar_price=0;qpt=0;psex_age=psex_age_damage=0;plia_acc=0;pdmg_acc=0;mdiscount=0;
    mdmg_prem=0; mlia_prem=0; qply_period=0; qcylinder=0;
    pdmg_align=0; pbrg_align=0; plia_align=0; pdmg_factor=0;
    pbrg_factor=0;
    ins_mdiscount=0,old_premium=0;
    s_old_premium[0]=0;
    mpure_prem=0;
    add_mplace_01_flag=0 , add_mplace_11_flag=0;
    /* �q���ĤG���q */
    strcpy(sIcomm_obj, "");
    strcpy(sIroute_comm,"");
    strcpy(sIroute_prop,"");
    strcpy(sIcode,"");
    iQprovision = 0;
    strcpy(sProvD, " ");
    strcpy(sProvD_1, " ");
    strcpy(sProvD_2, " ");

    strcpy(fout_print," ");
    strcpy(fmail_type," ");
    strcpy(dcreate,""); strcpy(sDateTime,""); strcpy(sDate,"");
    out_ply_50 = 0;
    out_ply_47 = 0;
    out_ply_147 = 0;
    strcpy(sNassured_56_136, " ");
    mequipment = 0;
    strcpy(sMequipment, " ");
    strcpy(iquota,""); strcpy(nbranch,"");
    strcpy(napplicant,"");
    cntIroute = 0;
    strcpy(sIrouteNote," ");
    cntIroute2 = 0;
    cnt_term = 0;
    strcpy(sIrouteNote2," ");
    strcpy(drate_ym," ");
    irate_ym = 0;
    out_ply_dmg = 0;
    provision_J = 0;
    punknown_acc = 0;
    strcpy(iquery_num_unknown," ");
    provision_X = 0;
    strcpy(nprov_X," ");
    provision_U = 0;
    provision_L = 0;
    /* 1071226006_SC4_�w���ƫ����վ�(���²v+�ĤT�H�d��) */
    provision_P = 0;
    provision_Q = 0;
    provision_V = 0;
    provision_K = 0;
    provision_M = 0;
    provision_Y = 0;
    cnt_V09 = 0;
    cnt_V3132 = 0;
    strcpy(nprov_pqv," ");
    strcpy(fchk_24," ");
    strcpy(feterms," ");
    strcpy(fdbgn20230601," "); 
    strcpy(fdply20230601," "); 
    
    strcpy(iinsurant56," ");
    strcpy(ninsurant56," ");
    dbirth56=0;
    strcpy(nbeneficiary56," ");
    strcpy(relation_bene56," ");
    strcpy(tbenef56," ");
    strcpy(abenef56," ");
    printf("out clear\n");
}

/*--------------------------------------------------------------------*/
long car306_query(sIpolicy)
char *sIpolicy;
{
    char  show_Tel[21];  /*---super ---*/
    char  show_tel_class[21]; /*--super  �q�����O--*/
    $char  tphone_con[21];   /*--super --*/
    $char  imovephone[21];   /*--super --*/
    int   i=0,k,rc=0;
    int   flag_exist;
    $char stmt[400],buf[20],sStmt[2048];
    char  dbsite[3], FullDBName[40];
    $char imgr[2],fsales[2],tmp_iroute[5];
    char  tmpName[11], v_sMsg[512];
    $char prov_terms[22],prov_terms1[22],prov_iins[7];
    char  tmp_prov_terms[60],swhere[60];
    $char f47[2];
    char *ncon,*ncon2;
    $char *ptr1;

    car306_clear();
    strcpy(ipolicy, sIpolicy);

    /* �P�_���M�ץ�O��or�D�M�ץ�O�� add by larry 102.12.16 (1021122001_C3) */
    /* �P�_�e�~��O��(sIpolicyB_type = 2) modify by larry 103.03.11 (1010523004_C2) */
    if ((strncmp(sIpolicyB_type,"1",1) == 0) || (strncmp(sIpolicyB_type,"2",1) == 0) || (strncmp(sIpolicyB_type,"3",1) == 0))
    {
        printf("-----1:�M�ץ�O�� 2:�e�~�O��(�w�鵲) 3:�e�~�O��(���鵲) sIpolicyB_type = [%s] -----\n",sIpolicyB_type);
        strcpy(Full_DBName,get_car_full_db(ipolicy));
    }
    else
    {
        printf("-----0:�D�M�ץ�O�� 4:car353 sIpolicyB_type = [%s]-----\n",sIpolicyB_type);
        strcpy(Full_DBName,get_full_dbname(DBName));
    }

    /* �e�~�O�����u��l�O��v��� (1041102003_C1) */
    /* �e�~�O��w�鵲������l�O���ɡA�e�~�O�楼�鵲�h�����̷s�O����*/
    if (strncmp(sIpolicyB_type,"2",1) == 0)
    {
        sprintf(tablePly,"%s:original_ply", Full_DBName);
        sprintf(tableRelation,"%s:ori_ply_relation", Full_DBName);
        sprintf(tableInsType,"%s:ori_ins_type", Full_DBName);
        sprintf(tablePaPly,"%s:ca_pa_ori", Full_DBName);
        sprintf(tableAssured,"%s:ori_ins_assured", Full_DBName);
    }
    else
    {
    	sprintf(tablePly,"%s:policy", Full_DBName);
        sprintf(tableRelation,"%s:ply_relation", Full_DBName);
    	sprintf(tableInsType,"%s:ply_ins_type", Full_DBName);
    	sprintf(tablePaPly,"%s:ca_pa_ply", Full_DBName);
    	sprintf(tableAssured,"%s:ply_ins_assured", Full_DBName);
    }

    strcpy(tablePly, trim(tablePly));
    strcpy(tableRelation, trim(tableRelation));
    strcpy(tableInsType, trim(tableInsType));
    printf("***** Query table[%s][%s][%s] *****\n", tablePly, tableRelation, tableInsType);

    $WHENEVER SQLERROR GOTO errexit;
    /*99.11.22 �]���U�����{�������Ψ� NULL �� dpolicy, �ȼv�T��{������h,�]���t�~�s�W�@ ca_dpolicy ���֭�帹��*/
    printf("GO HERE 1\n");
    sprintf(sStmt,"SELECT x.icard, x.ipolicy, x.irelative_ply, x.fcard_class, x.fprint,\
                   x.ilast_ply, x.ibroker, x.iofficer, x.iresource ,x.icashier,\
                   x.ibig_branch, x.ibig_office, x.ibig_sales,\
                   x.mdmg_prem, x.mlia_prem, NVL(x.dpolicy,' '),NVL(x.dpolicy,today),\
                   NVL(x.dpolicy,0),\
                   x.iexaminer, x.ientry, y.iply_area,\
                   y.fassured, y.nassured, y.nuser, y.nbenef, y.aassured, y.itel,\
                   trim(y.apayment), x.qply_period, x.dply_begin, \
                   x.dply_end, y.dissue, x.ipro_year, x.ibrand, \
                   x.icar_type, x.dentry, y.qcylinder, y.iengine, y.ibody, y.itag, y.mcar_price,\
                   y.qpt, y.fpt, y.psex_age, y.psex_age_damage, y.plia_acc, y.pdmg_acc, y.aassured_zip,\
                   y.ilicense, y.dbirth, y.fsex, y.fmarriage,\
                   y.pdmg_factor, y.pbrg_factor,\
                   y.flimit, y.pdmg_align, y.pbrg_align, y.plia_align,\
                   y.nequipment, y.nbrand_abbr, y.fcomp_24,\
                   x.transno, x.seqno, x.dendorse, x.icar_flag,\
                   x.mdmg_pure_prem + x.mlia_pure_prem, y.iassured, trim(y.napplicant), trim(y.apayment_zip),\
                   trim(y.iextra_charge), y.iroute,\
                   x.icomm_obj, x.iroute_comm, y.iroute_prop, x.qprovision,\
                   decode(x.transno[1,4],'6075',1,0), x.fout_print, x.fmail_type, x.dcreate, x.dply_close, \
                   y.mequipment, x.iquota , y.fsex_appl,\
                   y.punknown_acc, y.iquery_num_unknown ,\
                   case when x.dply_begin < '07/01/2019' then 'Y' else 'N' end,x.feterms, \
                   case when x.dply_begin >= '06/01/2023' then 'Y' else 'N' end, \
                   case when DATE(nvl(x.dpolicy,'01/01/1911')) >= '06/01/2023' then 'Y' else 'N' end \
                   FROM %s x, %s y \
                  WHERE y.ipolicy = x.ipolicy \
                    AND x.ipolicy = '%s' ",tableRelation,tablePly,ipolicy);
    $PREPARE policy_cur FROM $sStmt;
    $EXECUTE policy_cur INTO $icard, $ipolicy, $irelative_ply, $fcard_class, $fprint,
                           $ilast_ply,  $ibroker, $iofficer, $iresource ,$icashier,
                           $ibig_branch, $ibig_office, $ibig_sales,
                           $mdmg_prem, $mlia_prem, $dpolicy,$ca_dpolicy,$dpolicy_long,
                           $iexaminer, $ientry, $iply_area,
                           $fassured, $nassured, $nuser, $nbenef, $aassured, $itel,
                           $apayment, $qply_period, $dply_begin,
                           $dply_end, $dissue, $ipro_year, $ibrand,
                           $icar_type, $dentry, $qcylinder, $iengine, $ibody, $itag, $mcar_price,
                           $qpt, $fpt, $psex_age, $psex_age_damage, $plia_acc, $pdmg_acc, $aassured_zip,
                           $ilicense, $dbirth, $fsex, $fmarriage,
                           $pdmg_factor, $pbrg_factor,
                           $flimit, $pdmg_align, $pbrg_align, $plia_align,
                           $nequipment, $nbrand_abbr, $fcomp_24,
                           $transno, $seqno, $dendorse, $icar_flag,
                           $mpure_prem, $iassured, $napplicant, $apayment_zip,
                           $iextra_charge, $iroute,
                           $sIcomm_obj, $sIroute_comm, $sIroute_prop, $iQprovision,
                           $ply_6075,$fout_print,$fmail_type,$dcreate,$dply_close,
                           $mequipment, $iquota ,$fsex_appl,
                           $punknown_acc,$iquery_num_unknown,$fchk_24,$feterms,$fdbgn20230601,$fdply20230601;
    if (SQLCODE == SQLNOTFOUND) return M_CM_NOT_FOUND;

    /*1040202006_C1 �s�W���ؤ���~�����²v�վ�*/
    /*strcpy(icar_type,TRANS_CAR_TYPE(icar_type));
    printf("-- trace icar_type[%s]\n ",icar_type);*/
    
    strcpy(irelative_ply,trim(irelative_ply));

    /* �D�M�ץ�P�_:�g��N������W�g��BM�g��B������M0,M9 add by larry 102.12.26 (1021122001_C3) */
    /* �M�ץ�P�_:�g��N����W�g��BH�g��B������H0-H2 modify by sylvia 103.01.07 (1021122001_C3) */
    /* �M�ץ�P�_:�s�WN�g��A�~�Ȩӷ���E (1030630002_C4)*/
    if (strncmp(sIpolicyB_type,"0",1) == 0)
    {
        if ((strncmp(iofficer,"W",1) == 0) ||
           ((strncmp(iofficer,"H",1) == 0 ) && ((strncmp(iofficer,"H0",2)!=0)
             && (strncmp(iofficer,"H1",2)!=0) && (strncmp(iofficer,"H2",2)!=0))) ||
           ((strncmp(iofficer,"N",1) == 0) && (strncmp(iresource,"E",1) == 0)))
        {

            printf("�D�M�ץ�O��:���g��N�����M�ץ�g��(W, H (�ư�H0-H2) , N (�~�Ȩӷ���E)) \n");
            return M_CM_NOT_FOUND;
        }
    }

    /* �e�~�O�� (�T��)�u�O50�I��-�O��A�ȥd(0:�����[),����(2:�����H)
       add by larry 103.03.11 (1010523004_C2) */
    sprintf(stmt,"SELECT count(*) "
                 "  FROM %s "
                 " WHERE ipolicy = '%s'  "
                 "   AND iins_type != '50'",tableInsType,ipolicy);
    $PREPARE outply_50 FROM $stmt;
    $EXECUTE outply_50 INTO $out_ply_50;

    /* �e�~�O�� (����)�u�O47�I��-����(1:�����H) */
    sprintf(stmt,"SELECT count(*) "
                 "  FROM %s "
                 " WHERE ipolicy = '%s'  "
                 "   AND iins_type != '47' ",tableInsType,ipolicy);
    $PREPARE outply_47 FROM $stmt;
    $EXECUTE outply_47 INTO $out_ply_47;
	  
    /* �e�~�O�� (����)�u�O147�I��-����(5:�����H) */ 
    sprintf(stmt,"SELECT count(*) "
                 "  FROM %s "
                 " WHERE ipolicy = '%s'  "
                 "   AND iins_type != '147' ",tableInsType,ipolicy);
    $PREPARE outply_147 FROM $stmt;
    $EXECUTE outply_147 INTO $out_ply_147;
	  
    /* �e�~��O����B�ѵs�P�_ */
    sprintf(stmt,"SELECT count(*) "
                 "  FROM %s "
                 " WHERE ipolicy = '%s'  "
                 "   AND iins_type IN (SELECT iins_type FROM insurance_type WHERE fins_grp='1' AND iins_type = iins_ply)",tableInsType,ipolicy);
    $PREPARE outply_dmg FROM $stmt;
    $EXECUTE outply_dmg INTO $out_ply_dmg;

    /* �e�~�O��O�v�N���P�_ */
    sprintf(stmt,"SELECT Max(drate_ym) "
                 "  FROM %s "
                 " WHERE ipolicy = '%s'  ",tableInsType,ipolicy);
    $PREPARE outply_drate_ym FROM $stmt;
    $EXECUTE outply_drate_ym INTO $drate_ym;
	  
    irate_ym = atoi(drate_ym);

    /* �q���O���O(�e�~�O����) (1041102003_C1) */
    $SELECT chiname, count(*)
       INTO $sIrouteNote, $cntIroute
       FROM car_code
      WHERE kind = 'SR'
        AND detail = $iroute
        AND detail2 = $iofficer
      GROUP BY chiname;
      
    /*1060706009_C1_�ӽо����e�~�O��*/
    $SELECT trim(chiname), count(*)
       INTO $sIrouteNote2, $cntIroute2
       FROM car_code
      WHERE kind = 'O4'
        AND detail = $iroute
        AND detail2 = $iofficer
      GROUP BY chiname; 
    if (SQLCODE == SQLNOTFOUND) 
    {
        cntIroute2 = 0;
      	strcpy(sIrouteNote2," ");
    }
    
    /* �S�w�q�������[���� */
    $SELECT count(*)
       INTO $cnt_term
       FROM car_code
      WHERE kind = 'SX'
        AND detail = $iroute
        AND detail2 = $iofficer
      GROUP BY chiname; 
    if (SQLCODE == SQLNOTFOUND) 
    {
        cnt_term = 0;
    }
      
    /*1061128001_C1_����W�ǳW�h�ܰ�*/  
    strcpy(icar_type_ori,icar_type);
    strcpy(icar_type,TRANS_CAR_TYPE(icar_type,drate_ym));
    printf("--850 trace icar_type[%s] drate_ym[%s]\n ",icar_type,drate_ym); 

    /* bis9901141 if printing policy works, take it off */
    /*$SELECT nvl(b.fsales,'N') INTO $fsales
       FROM officer a, cm_route b
      WHERE a.iofficer = $iofficer
        AND a.iroute[1,4] = b.iroute;

    strcpy(LHsNname," ");

    if (strncmp(fsales,"Y",1) == 0)
    {
        strncpy(tmp_iroute,iroute,4);
    	EXEC SQL DECLARE sel_cm_route CURSOR FOR
        SELECT nsales[1,10]
          FROM cm_route_sales
         WHERE isales = :ibig_sales
           AND iroute = :tmp_iroute;

        EXEC SQL OPEN sel_cm_route;
        EXEC SQL FETCH sel_cm_route INTO :LHsNname;

        EXEC SQL CLOSE sel_cm_route;
        EXEC SQL FREE  sel_cm_route;

    } 
    else 
    {
        EXEC SQL DECLARE sel_ca_big CURSOR FOR
        SELECT nname[1,10]
          FROM ca_big_office
         WHERE fclass = '2'
           AND ibig_comp = :ibig_sales;
        EXEC SQL OPEN sel_ca_big;
        EXEC SQL FETCH sel_ca_big INTO :LHsNname;

        EXEC SQL CLOSE sel_ca_big;
        EXEC SQL FREE  sel_ca_big;
    }

    if(SQLCODE == SQLNOTFOUND)
        strcpy(LHsNname," ");*/

    /* �쬰����~�ȶ��L�g���N��������W��, �אּ�Ҧ��O�槡�L�g��N��������W��
    modify by sylvia 100.09.27 (1000926002_C1)  W�g�찣�~ */
    /* �j�M�g���N��������W�� */
    /* $SELECT nchi_full INTO $nname_I
          FROM broker_agent
         WHERE ibroker = $ibroker; */

    /* H�g�줣�C�L����W�� add by larry 102.12.16 (1021122001_C3) */
    $SELECT nname INTO $nname_I
       FROM officer
      WHERE iofficer = $iofficer
        AND iofficer[1,1] <> 'W'
        AND NOT (iofficer[1,1] = 'H' AND iofficer[2,2] not in ('0','1','2'))
        AND NOT (iofficer[1,1] = 'N' AND fprop = 'E');

    if(SQLCODE == SQLNOTFOUND)
    {
        /* strcpy(ibroker," "); */
        strcpy(nname_I, " ");
    }

    /* 99.11.19 �j�M�q���N��������W�� */
    $SELECT nroute[1,20] INTO $nname_N
       FROM cm_route
      WHERE iroute = $iroute;

    /* ���W�� add by larry 104.08.10 (1040625002_C1) */
    $SELECT nbranch INTO $nbranch
       FROM sa_branch_type
      WHERE ibranch = $iquota;
    if(SQLCODE == SQLNOTFOUND) 
        strcpy(nbranch," ");

    if(SQLCODE == SQLNOTFOUND)
        strcpy(nname_N," ");

    /* CompanyId */
    printf("companyid[%s]\n",CompanyId);
    if(strcmp( CompanyId, "32") == 0)
    {
       if( fassured[0] == '2' || fassured[0] == '4' || fassured[0] == '6' )
           strcpy( ilicense, iassured );
    }
    $SELECT imgr
       INTO $imgr
       FROM officer
      WHERE iofficer = $iofficer;
    if (SQLCODE == SQLNOTFOUND) strcpy(imgr,"2");

    /*--- �j�M�~�ȥN���m�W ---*/
    /* get_route_data input ������~��/�q���N��,���ӳq����~���N��
         �H�θg��N��,�^�Ǩ���/�q����~������W�� (2:����/�q����~��, 1:����/�q����~��) */
    /* imgr=1���ɭԬO���ӥ�,�Ǩ�����~��,��L���h�ǤJ�q���N�� */
    strcpy(tmpName,"");

    if (imgr[0] == '1')
    {
        rc = get_route_data(1, iofficer, ibig_office, ibig_sales, tmpName, v_sMsg);
        if (rc != M_CM_OK) strcpy(tmpName," ");
        strncpy(LHsNname,tmpName,10);
        LHsNname[11]='\0';
    }
    else
    {
        rc = get_route_data(1, iofficer, iroute, ibig_sales, tmpName, v_sMsg);
        if (rc != M_CM_OK) strcpy(tmpName," ");
        strncpy(LHsNname,tmpName,10);
        LHsNname[11]='\0';
    }
    /* end of Ū������/�q����~��(��) */

    if (imgr[0] == '1')
    {
       if (strlen(trim(LHsNname)) == 0)
       {
          if (strlen(trim(ibig_sales)) == 10)
          {
             ibig_sales[6] = '*';
             ibig_sales[7] = '*';
             ibig_sales[8] = '*';
             ibig_sales[9] = '*';
          }
       }
       else
       {
          strcpy(ibig_sales," ");
       }
    }

      /* ��]��ʹq�ܨ��@---start super 92.6.24 ---*/
    /*strcpy(show_Tel,itel);  /*--�᭱���e��--*
    /*strcpy(show_tel_class,"�q��(��)");
    if ((itel[0]==' ') || (itel[0]=='\0'))
    {
            sprintf(stmt,"SELECT A.tphone_con[1,11],A.imovephone[1,11] \
                            FROM cu_customer A,%s B \
                           WHERE B.ipolicy = '%s' \
                             AND A.ifpce_id=B.iassured \
                             AND A.ifpce_id_ext=B.iassured_ext",tablePly,ipolicy);
            $PREPARE policy_cur1 FROM $stmt;
	          $DECLARE tel_ply_cur CURSOR FOR policy_cur1;
	          $OPEN  tel_ply_cur;
	          $FETCH tel_ply_cur INTO $tphone_con,$imovephone;
            if (SQLCODE == SQLNOTFOUND)
            {
                tphone_con[0] = '\0';
                imovephone[0] = '\0';
                show_Tel[0]   = '\0';
                show_tel_class[0] = '\0';
            }
            else
            {
                strcpy(show_Tel,trim(tphone_con));
                strcpy(show_tel_class,"�q��(�])");
            }
            $CLOSE tel_ply_cur;
	          $FREE  tel_ply_cur;

            if ((show_Tel[0]==' ') || (show_Tel[0]=='\0'))
            {
                strcpy(show_Tel,trim(imovephone));
                strcpy(show_tel_class,"��ʹq��");
            }
    }
    strcpy(itel,trim(show_Tel));*/
    /*---end super 92.6.24 ---*/

    if (irelative_ply[0]!='\0' && irelative_ply[0]!=' ')
    {
        printf("0010:irelative_ply[%s],fcard_class[%s]\n",irelative_ply,fcard_class);
        sprintf(stmt,"SELECT icard,dply_begin,dply_end \
                        FROM %s \
                       WHERE ipolicy = '%s'",tableRelation,irelative_ply);
        $PREPARE policy_cur2 FROM $stmt;
	$DECLARE icard_ply_cur CURSOR FOR policy_cur2;
	$OPEN  icard_ply_cur;
	$FETCH icard_ply_cur INTO $r_icard,$r_dbegin,$r_dend;
        strcpy(r_icard,rtrim(r_icard));
        if (SQLCODE == SQLNOTFOUND)
        {
            strcpy(r_icard," ");
            r_dbegin=0;r_dend=0;
        }
        $CLOSE icard_ply_cur;
	$FREE  icard_ply_cur;

        if(fcard_class[0]=='2')
        {
            sprintf(stmt,"SELECT mlia_prem \
                            FROM %s \
                           WHERE ipolicy = '%s'",tableRelation,irelative_ply);
            $PREPARE policy_cur3 FROM $stmt;
	    $DECLARE prem_ply_cur CURSOR FOR policy_cur3;
	    $OPEN  prem_ply_cur;
	    $FETCH prem_ply_cur INTO $prem21;
            if (SQLCODE == SQLNOTFOUND) 
                prem21=0;
            $CLOSE prem_ply_cur;
	    $FREE  prem_ply_cur;
        }
    }

    /*����޲z�H�B�޲z�H�m�W�B�g��H�q�ܸ��X*/
    $SELECT  first 1 z.ileader as ileader,
                    y.nname as nleader,
             CASE WHEN LEFT(r.iroute,2) = 'JB' THEN  r.tphone
                 else x.itel END as ntel_leader
        INTO $ileader, $nname, $ntel_leader
        FROM ca_big_office x, officer y, officer z,cm_route r
       WHERE ((x.ibig_comp = y.iquota[1,4] || '00') or (x.ibig_comp = y.iquota))
         AND r.iroute= z.iroute
         AND x.fclass = '3'
         AND y.iofficer = z.ileader
         AND z.iofficer = $iofficer
    order by x.ibig_comp desc;


    if(SQLCODE==SQLNOTFOUND)
    {
        strcpy( ileader, "");
        strcpy( nname, "");
        strcpy( ntel_leader, "");
       
        $SELECT ileader
           INTO $ileader
           FROM officer
          WHERE iofficer=$iofficer;
        if (SQLCODE == SQLNOTFOUND)
            strcpy(ileader," ");

        $SELECT nname
           INTO $nname
           FROM officer
          WHERE iofficer=$ileader;
        if (SQLCODE == SQLNOTFOUND)
            strcpy(nname," ");      
       
    }
    printf("***858***\nileader=%s,\n nname=%s,\n ntel_leader=%s\n",ileader,nname,ntel_leader);

    printf("0020:prem21[%d]\n",prem21);

    if(prem21 > 0 )
    {
        strcpy(bak4,"(�t�j��)");
        strcpy(bak1,refmtamt(prem21,MILLIONTH));
        if(strcmp(irelative_ply,r_icard) != 0)
            sprintf(s_prem21,"�j��O�O %s  (�Ҹ�%s)",bak1,r_icard);
        else
            sprintf(s_prem21,"�j��O�O %s  ",bak1);        
    }
    else
    {
        strcpy(bak4," ");
        strcpy(s_prem21," ");
    }

    printf("0020:s_prem21[%s]\n",s_prem21);

    mdiscount=0;
    mcommission=0;
    sprintf(stmt,"SELECT SUM(mcommission) \
                    FROM %s \
                   WHERE ipolicy = '%s'",tableInsType,ipolicy);
    $PREPARE policy_cur4 FROM $stmt;
    $DECLARE commis_cur CURSOR FOR policy_cur4;
    $OPEN  commis_cur;
    $FETCH commis_cur INTO $mcommission;
    $CLOSE commis_cur;
    $FREE  commis_cur;

    sprintf(stmt,"SELECT SUM(case when mdiscount<0 then 0 else mdiscount end) \
                    FROM %s \
                   WHERE ipolicy = '%s'",tableInsType,ipolicy);
    $PREPARE policy_cur5 FROM $stmt;
    $DECLARE discoun_cur CURSOR FOR policy_cur5;
    $OPEN  discoun_cur;
    $FETCH discoun_cur INTO $mdiscount;
    $CLOSE discoun_cur;
    $FREE  discoun_cur;

    sprintf(stmt,"SELECT SUM(mins_premium) \
                     FROM %s \
                    WHERE ipolicy = '%s'",tableInsType,ipolicy);
    $PREPARE policy_cur6 FROM $stmt;
    $DECLARE prem1_cur CURSOR FOR policy_cur6;
    $OPEN  prem1_cur;
    $FETCH prem1_cur INTO $premium1;
    $CLOSE prem1_cur;
    $FREE  prem1_cur;

    strncpy(site2,ipolicy,2);
    site2[2]='\0';

    $SELECT npresident,ifirm_pid,nchi_abv
       INTO $npresident,$ifirm_pid,$tax_area
       FROM branch
      WHERE ibranch = $site2;
    if (SQLCODE == SQLNOTFOUND)
        return M_CM_NOT_FOUND;

    $SELECT fcar_class, ncode
       INTO $fcar_class, $ncar_abbr
       FROM car_type
      WHERE icode = $icar_type AND fclass = '1';
    if(SQLCODE == SQLNOTFOUND)
        strcpy( fcar_class, " ");

    printf("ipolicy[%s] dply_begin[%ld] ca_dpolicy[%s]\n",ipolicy,dply_begin,ca_dpolicy);
    
    strcpy(f47,"0");
    /* 47�I�ضO�v�N���P�_ */
    /* f47 = '0'�A���ܥ��ӫO47��47�O�v�N��>=111�A�����47�帹*/
    /* f47 = '1'�A����47�O�v�N��<111�A�n���47�帹*/
    /*1081205009_SC4_�t�X47�I�رq�D�I�אּ���[�I�A�ק���s/E�O��/B2B/B2C�ˮ�(�Цb12�멳����)*/
    sprintf(stmt,"SELECT CASE WHEN CAST (drate_ym AS INTEGER)>=111 THEN '0' ELSE '1'  END "
                 "  FROM %s "
                 " WHERE ipolicy = '%s' AND iins_type='47' ",tableInsType,ipolicy);
    $PREPARE drate_ym_47 FROM $stmt;
    $EXECUTE drate_ym_47 INTO $f47;
    
    /* �q�l���ڵ��O�P�_ */
    /* 1100419003_SC3_���I�O�����QR Code�q�l��*/
    /*printf("str_sEterms[%s]\n",str_sEterms);
    if (strcmp(str_sEterms,"0")==0 )
    {
    	/*�̷̳s�O����*
    	strcpy(feterms,trim(feterms));
    }
    else if(strcmp(str_sEterms,"1")==0)
    {
    	/*�q�l����*
    	strcpy(feterms,"1");
    }
    else 
    {
    	/*�ȥ�����*
    	strcpy(feterms,"0");
    }*/
    /* 1111005011_SC1_�����q�l����(�tE�O��B2B���s�q�lñ���u�W�n�O) */
    strcpy(feterms,"0");
    printf("feterms[%s]\n",feterms);
    
    /*******************************************/
    
    
    /*======== ��������������  �H�U�걵�I�ؤ帹  �������������� ========*/
    
    
    /* �C�@���帹���n�C�X�ӡA�ۥΧ�帹�@�B��~��帹�G */  
    /* 1090915004_SC1_�Эק�car307�B�e�~�B�q�l�O�檺�^���帹�W�h*/
    sprintf(ncontent_print,"");
    sprintf(ncontent1,"");
    sprintf(ncontent2,"");
    sprintf(stmt1,"SELECT max(ncontract),a.iins_type "
                  "  FROM ca_terms a, %s b"
                  " WHERE a.iins_type = b.iins_type"
                  "   AND b.ipolicy = ? "
                  "   AND deffect <= ? "
                  "   AND dcreate <= ? "
                  "   AND ((dendorse IS NULL) OR (dendorse IS NOT NULL AND b.minjured_cover + b.mdeath_cover + b.mdamage_cover = 0) )"
                  " GROUP BY a.iins_type "
                  " UNION "
                  "SELECT max(ncontract),a.iins_type "
                  "  FROM ca_terms a, %s b"
                  " WHERE a.iins_type = b.iins_type"
                  "   AND b.ipolicy = ? "
                  "   AND deffect <= b.dedr_begin "
                  "   AND dcreate <= b.dendorse "
                  "   AND dendorse IS NOT NULL AND b.minjured_cover + b.mdeath_cover + b.mdamage_cover <> 0 "
                  " GROUP BY a.iins_type "
                  " ORDER BY 1 DESC ",tableInsType,tableInsType);
    $PREPARE s_app4 FROM $stmt1;
    $DECLARE sel_app4 CURSOR FOR s_app4;
    $OPEN sel_app4 USING $ipolicy,$dply_begin,$ca_dpolicy,$ipolicy;
  
    while(1)
    {
        $FETCH sel_app4 INTO $ncontract,$viins_type;
         	
        if (SQLCODE == SQLNOTFOUND) break;
        printf("ncontract[%s],viins_type[%s]\n",ncontract, viins_type);

        sprintf(stmt2,
         	" SELECT ncontent1,ncontent2 "
                " FROM ca_terms"
                " WHERE ncontract = '%s'"
                " AND iins_type = '%s' " ,ncontract,viins_type);
            
        $PREPARE terms FROM $stmt2;
        $EXECUTE terms into $ncontent1,$ncontent2;
            
        /*�O�v�N��>=111�A����ܤ帹*/
        /*1081205009_SC4_�t�X47�I�رq�D�I�אּ���[�I�A�ק���s/E�O��/B2B/B2C�ˮ�(�Цb12�멳����)*/
        if(strcmp(f47,"0")==0 && strcmp(trim(viins_type),"47")==0)
        {
            strcpy(ncontent1,"");
            strcpy(ncontent2,"");
        }
            
            
            
	if (fcar_class[0] == '1')
	{
	    if (strcmp(trim(ncontent1),"") != 0)
	    {
	        sprintf(ncontent1, "%s;", trim(ncontent1));
		strcat(ncontent_print, ncontent1);
	    }
	}
	else
	{
	    if (strcmp(trim(ncontent2),"") != 0)
	    {
		sprintf(ncontent2, "%s;", trim(ncontent2));
		strcat(ncontent_print, ncontent2);
	    }
	}    	
    }
    $CLOSE sel_app4;
    $FREE  sel_app4;
     
    /*======== ��������������  �H�W�걵�I�ؤ帹  �������������� ========*/ 
         
    /*======== ��������������  �H�U�걵���[���ڻ�����r�B�帹  �������������� ========*/
    strcpy(prov_terms,"");
    strcpy(prov_terms1,"");
    strcpy(prov_iins,"");
    strcpy(nprov_note,"");
    strcpy(swhere,"");
    sprintf(stmt1_2,"SELECT trim(nvl(provision,' '))||';',iins_type "
                    " FROM  %s "
                    " WHERE ipolicy = '%s' ",tableInsType,ipolicy);
    $PREPARE s_app6 FROM $stmt1_2;
         
    $DECLARE sel_app6 CURSOR FOR s_app6;
    $OPEN sel_app6 ;
    printf("stmt1_2[%s]\n",stmt1_2);
         
    while(1)
    {
        $FETCH sel_app6 INTO $prov_terms1,$prov_iins;
        printf("prov_terms1[%s]prov_iins[%s]\n",prov_terms1,prov_iins);
        
        if (SQLCODE == SQLNOTFOUND) 
            break;
            
        if (strstr(trim(prov_terms1),"P;") != NULL)
        {
             if ((strcmp(trim(prov_iins),"01")!=0)  && (strcmp(trim(prov_iins),"05")!=0)  && (strcmp(trim(prov_iins),"09")!=0)  && (strcmp(trim(prov_iins),"11")!=0) &&
                 (strcmp(trim(prov_iins),"201")!=0) && (strcmp(trim(prov_iins),"205")!=0) && (strcmp(trim(prov_iins),"209")!=0) && (strcmp(trim(prov_iins),"211")!=0))

			$SELECT first 1 replace($prov_terms1,'P;','')
		       INTO $prov_terms1
		       FROM systables;
        }
        else if (strstr(trim(prov_terms1),"Q;") != NULL)
        {
             if ((strcmp(trim(prov_iins),"01")!=0)  && (strcmp(trim(prov_iins),"05")!=0)  && (strcmp(trim(prov_iins),"09")!=0)  && (strcmp(trim(prov_iins),"11")!=0) &&
                 (strcmp(trim(prov_iins),"201")!=0) && (strcmp(trim(prov_iins),"205")!=0) && (strcmp(trim(prov_iins),"209")!=0) && (strcmp(trim(prov_iins),"211")!=0))

			$SELECT first 1 replace($prov_terms1,'Q;','')
		       INTO $prov_terms1
		       FROM systables;	
        }
        else if (strstr(trim(prov_terms1),"M;") != NULL)
        {
             if ((strcmp(trim(prov_iins),"01")!=0)  && (strcmp(trim(prov_iins),"05")!=0)  && (strcmp(trim(prov_iins),"09")!=0)  && (strcmp(trim(prov_iins),"11")!=0) && (strcmp(trim(prov_iins),"181")!=0) &&
                 (strcmp(trim(prov_iins),"201")!=0) && (strcmp(trim(prov_iins),"205")!=0) && (strcmp(trim(prov_iins),"209")!=0) && (strcmp(trim(prov_iins),"211")!=0))

			$SELECT first 1 replace($prov_terms1,'M;','')
		       INTO $prov_terms1
		       FROM systables;		
        }
        else if (strstr(trim(prov_terms1),"Y;") != NULL)
        {
        	/* 1130827011_C04_�s�W�s�t��W�B���[����(Y)(�L��) */
             if ((strcmp(trim(prov_iins),"01")!=0)  && (strcmp(trim(prov_iins),"05")!=0)  && (strcmp(trim(prov_iins),"09")!=0)  && (strcmp(trim(prov_iins),"11")!=0) && (strcmp(trim(prov_iins),"198")!=0) &&
                 (strcmp(trim(prov_iins),"201")!=0) && (strcmp(trim(prov_iins),"205")!=0) && (strcmp(trim(prov_iins),"209")!=0) && (strcmp(trim(prov_iins),"211")!=0))

			$SELECT first 1 replace($prov_terms1,'Y;','')
		       INTO $prov_terms1
		       FROM systables;		
        }      
            
              
        strcat(prov_terms,trim(prov_terms1));
      	  
    }
    $CLOSE sel_app6;
    $FREE  sel_app6;
    
    strcpy(prov_terms,trim(prov_terms));
    printf("prov_terms[%s]\n",prov_terms);
    strcpy(nprov_note_print,"  ");
         
    if(strlen(prov_terms)>1)
    {
         
        strcpy(swhere,"");
        strcpy(tmp_prov_terms,"");
        
        ptr1 = strtok(prov_terms,";");
		while(ptr1 != NULL)
		{
	      	    sprintf(tmp_prov_terms,"'%s',",ptr1);  
	      	    strcat(swhere,tmp_prov_terms);	  				
		    ptr1 = strtok(NULL, ";");
		}
				

        strcat(swhere,"''");
      		
        printf("�����[����:swhere[%s]\n",trim(swhere));
        

             
        /*���[���ڤ帹*//*  
        sprintf(ncontent1,"");
        sprintf(ncontent2,"");
        sprintf(stmt1,"SELECT max(ncontract),iins_type "
                      "  FROM ca_terms "
                      " WHERE iins_type IN (%s) "
                      "   AND deffect <= ? "
                      "   AND dcreate <= ? "                       
                      " GROUP BY iins_type "
                      " ORDER BY 1 DESC ",swhere,tableInsType);
        $PREPARE s_app7 FROM $stmt1;
        $DECLARE sel_app7 CURSOR FOR s_app7;
        $OPEN sel_app7 USING $dply_begin,$ca_dpolicy;
  
        while(1)
        {
            $FETCH sel_app7 INTO $ncontract,$viins_type;
         	
            if (SQLCODE == SQLNOTFOUND) break;
            printf("ncontract[%s],viins_type[%s]\n",ncontract, viins_type);

            sprintf(stmt2,
         	          " SELECT ncontent1,ncontent2 "
                          " FROM ca_terms"
                          " WHERE ncontract = '%s'"
                          " AND iins_type = '%s' " ,ncontract,viins_type);
            
            $PREPARE terms FROM $stmt2;
            $EXECUTE terms into $ncontent1,$ncontent2;
            
	    if (fcar_class[0] == '1')
	    {
	        if (strcmp(trim(ncontent1),"") != 0)
		{
		    sprintf(ncontent1, "%s;", trim(ncontent1));
		    strcat(ncontent_print, ncontent1);
		}
	    }
	    else
            {
		if (strcmp(trim(ncontent2),"") != 0)
		{
		    sprintf(ncontent2, "%s;", trim(ncontent2));
		    strcat(ncontent_print, ncontent2);
		}
	    }    	
        }
        $CLOSE sel_app7;
        $FREE  sel_app7;         
         
        printf("ncontent_print[%s]\n",ncontent_print);*/
             
        /*���[���ڻ�����r*/
        strcpy(nprovision,"");
        strcpy(nprov_note,"���O����[");
        strcpy(nprov_note_print,"");
        sprintf(stmt1,"SELECT trim(nprint)||',' "
                      "  FROM ca_provision_main "
                      " WHERE iprovision IN (%s) "
                      "   AND iprovision NOT IN ('C','E','S') ",swhere);
        $PREPARE s_app8 FROM $stmt1;
        $DECLARE sel_app8 CURSOR FOR s_app8;
        $OPEN sel_app8 ;
  
        while(1)
        {
            $FETCH sel_app8 INTO $nprovision;
         	
            if (SQLCODE == SQLNOTFOUND) break;
         	    
            printf("chiname[%s]\n",nprovision);
         	    
            strcat(nprov_note,trim(nprovision));
	    
        }
        $CLOSE sel_app8;
        $FREE  sel_app8;         
             
        if(strcmp(trim(nprov_note),"���O����[")==0) strcpy(nprov_note,"   ");
             
        printf("nprov_note[%s]\n",nprov_note); 
             
        nprov_note[strlen(nprov_note)-1]='\0';
        /*strncpy(nprov_note_print,nprov_note,strlen(nprov_note)-1);  */         
        printf("nprov_note[%s]\n",nprov_note); 
             
    }
    /*======== ��������������  �H�W�걵���[���ڻ�����r�B�帹  �������������� ========*/          
         
    return M_CM_OK;

errexit:
    return SQLCODE;
}

/*--------------------------------------------------------------------*/
/* sIkind = 1 => �L�X�u�f���B, sIkind = 2 => ���L�u�f���B             */
/*--------------------------------------------------------------------*/
long ca306_get_data(sIpolicy,sIkind)
char *sIpolicy;
char *sIkind;
{
    $int  i,line_no;
    int   j;
    int   str_length;
    char  *ilocation;
    char  s_qcylinder_tail[4];
    $char stmt[600], sStmt[128];
    char  datestr[40];
    char  ikind[2];
    $char  tmp_iins_scope[3];
    $char iins_scope_56[2];
    $int   daily_pay;
    char   v_sMsg[512];
    long   rtncode, lPremSum;
    char   sColumn[21], sTable[21], sDbname[21];
    $char   contain_coverage[120],prt_coverage[120];
    $long    insurance_cover_count;
    char   *ptr;
    $char  tmp3132[13], sFcal_way[2];
    $char  tmpfield2[28];
    char   amt_print[11];
    long   tmp_cover1=0, tmp_cover2=0, tmp_cover3=0;
    long   deduct_prem=0;
    char   sNinstype2[31];
    $char   ins31_provision[11];
    $char  stmp_ntype1[17], stmp_ntype2[17],stmp_mpad1[15], stmp_mpad2[15];
    char   FullDBName[40];
    $char sIpolicy1[21]=" ",sIpolicy2[21]=" ";
    $double mdisc;
    $char nins_type2[50],provision2[22];
    $int nins_type_len = 0;
    $char nins_type_split[17];

    printf("start to get information...\n");

    ins31_provision[0]='\0';
    strcpy(ipolicy,sIpolicy);
    strcpy(ikind, sIkind);
    str_length = 0;
    tmpDrate[0] = '\0';
    daily_pay = 0;

    printf("111111111111111fcar1[%s] fcar_class[%s]\n",fcar1,fcar_class);
    
    /*1080720003_SC1_�ק�O��C�L2A�B2B���ئۥ�/��~����(�t�ȥ��B�q�l�B�e�~) 2019.08.07 by 071004*/
    if(strcmp(icar_type_ori,"4A")==0||strcmp(icar_type_ori,"2B")==0)
    {
    	strcpy(fcar2,"V");
    	
    }
    else
    {
        if (fcar_class[0]=='1')
            strcpy(fcar1,"V");
        else if (fcar_class[0]=='2')
            strcpy(fcar2,"V");    	
    }


    printf("22222222222222222fcar1[%s]\n",fcar1);
    strcpy(s_r_dbegin,cm_cdate_str_100(r_dbegin));
    strcpy(s_r_dend,cm_cdate_str_100(r_dend));

    /*** �����O�T�T�� 92.12.03 ***/
    if ((strncmp(fcard_class,"2",1)==0) &&
        (strncmp(icar_flag,"2",1)==0) &&
        (strncmp(icar_type,"03",2)==0) &&
        (((strncmp(iofficer,"8",1)==0) && (strncmp(iofficer+6,"T",1)!=0)) ||
         ((strncmp(iofficer,"9",1)==0) && (strncmp(iofficer+6,"T",1)!=0)) ||
         (strncmp(iofficer,"S",1)==0) ||
         (strncmp(iofficer,"Z",1)==0) ||
         (strncmp(iofficer,"A",1)==0) ||
         (strncmp(iofficer,"E",1)==0)) &&
        ((ilast_ply[0] != ' ') && (ilast_ply[0] != '\0')) &&
        (strncmp(ibrand,"01",2)==0) &&
        (premium1 >= 8000) &&
        (mdiscount == 0) &&
        (equip_cmp(nequipment,"6") == TRUE))
    {
        sprintf(stmt, "SELECT * FROM %s WHERE %s %s %s %s ",
                      " ext_policy ",
                      " ipolicy = ? ",
                      " AND irenew='1' ",
                      " AND dconfirm is not null ",
                      " AND dcancel is null");
        $PREPARE pre_ext FROM  $stmt;
        $EXECUTE pre_ext USING $ilast_ply;
        if (SQLCODE==SQLNOTFOUND)
        {
            strcpy(s_note1,"");
            strcpy(s_note2,"");
        }
        else
        {
            strcpy(s_note1,"���ζ����~�K�U�O�T�M��");
            strcpy(s_note2,"");
        }
    }
    else
    {
        strcpy(s_note1," ");
        strcpy(s_note2,"");
    }

    /* ���[�N�B���A�� */
    if (strcmp(trim(fcard_class),"2")==0)
    {
        if (equip_cmp(nequipment,"15") == TRUE)
        {
            add_mplace_01_flag = 1;
        }
        else
        {
            add_mplace_01_flag = 0;
        }

        if (equip_cmp(nequipment,"16") == TRUE)
        {
            add_mplace_11_flag = 1;
        }
        else
        {
            add_mplace_11_flag = 0;
        }
    }

    if (ipolicy[0]!=' ' && ipolicy[0]!='\0') 
        strcpy(ply1,CompanyId);
    else 
        strcpy(ply1,"  ");

    strncat(ply1,ipolicy,3);
    strncpy(ply2,&ipolicy[3],10); ply2[10]='\0';

    if(ilast_ply[0]!=' ' && ilast_ply[0]!='\0')
        strcpy(last_ply1,CompanyId);
    else
    {
        memset(ilast_ply,0,sizeof(ilast_ply));
        strcpy(last_ply1,"  ");
    }

    strncat(last_ply1,ilast_ply,3);
    strncpy(last_ply2,&ilast_ply[3],10);
    last_ply2[10] = '\0';

    if(apayment[0]=='\0' || apayment[0]==' ') 
        strcpy(apayment,aassured);

    rtoday(&Today);
    strcpy(s_dpolicy,cm_cdate_str_100(Today));
    cm_split_ymd_100(s_dpolicy,yy5,mm5,dd5);

    strcpy(datestr,cm_cdate_str_100(dentry));
    cm_split_ymd_100(datestr,yy6,mm6,dd6);

    /* �e�~��O��t�Τ� = ñ��� */
    if (strncmp(sIpolicyB_type,"2",1) == 0 || strncmp(sIpolicyB_type,"3",1) == 0)
    {
        strcpy(yy7,yy5);   /* �C�L�� = �t�Τ� */
    	strcpy(mm7,mm5);
    	strcpy(dd7,dd5);
    	 
        strcpy(datestr,cm_from_infdate_100(dpolicy));
        cm_split_ymd_100(datestr,yy6,mm6,dd6);
       
        strcpy(yy5,yy6);   /* �t�Τ� = ñ��� */
        strcpy(mm5,mm6);
        strcpy(dd5,dd6);
       
        printf("---1201---datestr[%s]yy6[%s]mm6[%s]dd6[%s]\n",datestr,yy6,mm6,dd6);
        printf("---1202---datestr[%s]yy5[%s]mm5[%s]dd5[%s]\n",datestr,yy5,mm5,dd5);
    }

    strcpy(datestr,cm_cdate_str_100(dply_begin));
    i_begin = cm_ymd_cdate(datestr);
    cm_split_ymd_100(datestr,yy1,mm1,dd1);

    strcpy(datestr,cm_cdate_str_100(dply_end));
    i_end = cm_ymd_cdate(datestr);
    cm_split_ymd_100(datestr,yy2,mm2,dd2);

    cm_long_split_3ymd(dissue,is_yy,is_mm,is_dd);   /* Date(long)�ন����~�B��B��(yyy,mm,dd) */

    sprintf(s_qcylinder, "%5.2f", qcylinder);   /*1080902001_SC4_�Ʈ�q�X�ܤp���I2��(�t�Ҧ������B�X��B�����B���p�d�ߡB���{��)*/
    strcpy(s_qcylinder,trim(s_qcylinder) );
    
    /*�Ʈ�q���ƧP�_�A�Y�O .00 �h�ٲ������*/
    /*
    strcpy(s_qcylinder_tail,"");
    ilocation = strstr(s_qcylinder, ".");
    printf("�Ʈ�q�p��[%d]\n",ilocation-s_qcylinder);
    printf("�Ʈ�q�p��[%c%c%c]\n",s_qcylinder[ilocation-s_qcylinder],s_qcylinder[ilocation-s_qcylinder+1],s_qcylinder[ilocation-s_qcylinder+2]);
    sprintf(s_qcylinder_tail,"%c%c%c",s_qcylinder[ilocation-s_qcylinder],s_qcylinder[ilocation-s_qcylinder+1],s_qcylinder[ilocation-s_qcylinder+2]);
    printf("�Ʈ�q�p��[%s]\n",s_qcylinder_tail);
    
    if(strcmp(s_qcylinder_tail,".00")==0)
    {
    	s_qcylinder[ilocation-s_qcylinder]='\0';
    }
    printf("�Ʈ�q�p��[%s]\n",s_qcylinder);*/
    
    if (qpt!=0) 
        sprintf( s_qpt, "%5.1f", qpt);
    else 
        strcpy(s_qpt," ");

    if (qpt!=0)
    {
        if (fpt[0] == 'P') 
            strcpy(s_fpt, "�H");
        else if(fpt[0] == 'T') 
            strcpy(s_fpt, "��");
        s_fpt[2]=0;
    }
    else strcpy(s_fpt," ");

    /* �Ӹ�B�n */
    if (strncmp(sProtectData,"0",1) == 0)
    {
        printf("----------ProtectData = 0 ----------\n");
    	if( fassured[0] == '1' || fassured[0] == '3' || fassured[0] == '5' )
    	{
            cm_long_split_3ymd( dbirth, by, bm, bd);   /* Date(long)�ন����~�B��B��(yyy,mm,dd) */
        }
        else
        {
            strcpy( by, " ");
            strcpy( bm, " ");
            strcpy( bd, " ");
        }
    }
    else
    {
    	printf("-----------ProtectData = 1 ----------\n");
    	if( fassured[0] == '1' || fassured[0] == '3' || fassured[0] == '5' )
    	{
    	    strcpy(sIlicense,substring(ilicense,1,4));
    	    strcat(sIlicense,"****");
    	    strcat(sIlicense,substring(ilicense,9,2));
			
	    if((itel[0]==' ') || (itel[0]=='\0'))
	    {
	        strcpy(sItel," ");
	    }
	    else
	    {
	    	strcpy(sItel,substring(itel,1,3));
	    	strcat(sItel,"XXXX");
	    	strcat(sItel,substring(itel,8,13));
    	    }
    	}
    	else
    	{
            strcpy(sIlicense,ilicense);
    	    strcpy(sItel,itel);
    	}
    	
    	if( fassured[0] == '1' || fassured[0] == '3' || fassured[0] == '5' )
    	{
            cm_long_split_3ymd( dbirth, by, bm, bd);   /* Date(long)�ন����~�B��B��(yyy,mm,dd) */
            strcpy( by, "***");
            strcpy( bd, "**");
     	}
     	else
     	{
    	    strcpy( by, " ");
            strcpy( bm, " ");
            strcpy( bd, " ");
        }
        
    }

    if (fsex[0]=='1') 
        strcpy(sex1,"�k");
    else if (fsex[0]=='2') 
        strcpy(sex1,"�k");
    
    if (fmarriage[0]=='1') 
        strcpy(marriage1,"�w�B");
    else if (fmarriage[0]=='2') 
        strcpy(marriage1,"���B");

    /*
    sprintf(s_psex_age, "���d:%-6.2f", psex_age);
    sprintf(s_psex_age_damage, "����:%-6.2f", psex_age_damage);
    */

    if (pdmg_align==0) 
        s_dmg_align[0]='\0';
    else 
        sprintf(s_dmg_align, "%d", pdmg_align);

    if (pbrg_align==0) 
        s_brg_align[0]='\0';
    else 
        sprintf(s_brg_align, "%d", pbrg_align);

    if (plia_align==0) 
        s_lia_align[0]='\0';
    else 
        sprintf(s_lia_align, "%d", plia_align);

    sprintf(s_lia_acc,"%6.2f",plia_acc);
    sprintf(s_dmg_acc,"%6.2f",pdmg_acc);
    sprintf(s_unk_acc,"%6.2f",punknown_acc);
    strcpy(s_unk_acc,trim(s_unk_acc));

    $WHENEVER SQLERROR GOTO errexit;

    strcpy( sDbname, Full_DBName);
    strcpy( sTable, "ply_ins_cover");
    strcpy( sColumn, "ipolicy");

    IcurrPlyInsCover=IfirstPlyInsCover=IlastPlyInsCover=NULL;    /* set init pointer to NULL */
    #ifdef CA_CONS
        IfirstPlyInsCover = get_ply_ins_cover( sDbname, sTable, sColumn, ipolicy, &rtncode, v_sMsg);
        if( rtncode != M_CM_OK)
            return rtncode;
    #endif

    strcpy(flag_29_exist,"N");
    strcpy(flag_31_exist,"N");
    strcpy(flag_32_exist,"N");

    strcpy(tableInsType, trim(tableInsType));
    strcpy(tablePaPly, trim(tablePaPly));
    strcpy(tableAssured, trim(tableAssured));
    printf("***** Get_data table[%s][%s] *****\n", tableInsType, tablePaPly);

    /********************/
    /*                  */
    /* �v�I�رN���Ū�X */
    /*                  */
    /********************/
    
    sprintf(stmt,"SELECT iins_type, minjured_cover, mdeath_cover,\
                         mdamage_cover, mdeduct, mins_premium, qserial,\
                         pcommission,pagent,mdiscount,drate_ym,mprem,qday,trim(nvl(provision,' '))||';' \
                    FROM %s \
                   WHERE (ipolicy = ?) ORDER BY qserial",tableInsType);
    $PREPARE CUR8 FROM $stmt;
    $DECLARE curh CURSOR FOR CUR8;
    $OPEN curh USING $ipolicy;

    for(;;)
    {
        $FETCH curh INTO $iins_type,$injured_cover,$death_cover, $damage_cover, $deduct, $ins_premium, $qserial,
                         $pcommission, $pagent, $ins_mdiscount, $drate_ym, $old_premium, $qday, $provision;
        if (SQLCODE == SQLNOTFOUND) break;

        lPremSum = 0;
        strcpy(cover_print,"");
        strcpy(amt_print,"");
        strcpy(str_cover1,"");
        strcpy(str_cover2,"");
        strcpy(str_cover3,"");
        strcpy(str_cover4,"");
        strcpy(f980401,"");
        strcpy(f52535524,"");
        strcpy(f626364,"");
        strcpy(f86,"");
        strcpy(iins_type, rtrim(iins_type));

        if (tmpDrate[0] == '\0')
            strcpy(tmpDrate, drate_ym);



        /*======================================================================*/
        /* car9803301 �P�_�ϥηs�¶O�v(�s�O�v2009/04/01�W�u),�L�X���P���֭�帹 */
        /* �u�n���@�I�بϥηs�O�v,�֭�帹�K�ϥηs�� */
        $SELECT case when drate >= date('04/01/2009') then '1' else '0' end
           INTO $f980401
           FROM ca_rate_date
          WHERE icode  = $drate_ym
            AND itable = 'cm_extra_charge';
        if (SQLCODE == SQLNOTFOUND)  
            return M_CA_EXTRA_CHARGE_DRATE;

        if( f980401[0] == '1')
        {
            strcpy(flag980401,f980401);
        }
        /* end of car9803301 */
        /*======================================================================*/
        
        

        /*======================================================================*/
        /* �Y�O�O�B���s,�����u���O�O,�O��W���C�L,�B�O�O�]�n���� */
        /* �Y�O�B=,�O�O!= 0, �������I�ذh�O, �����C�L,�H���O�O�P�b�W�ƬۦP
           ���O�B�C�L�i�h�O�j�r�ˡC add by sylvia 101.10.08 (1010928006_C1) */
        if (damage_cover == 0)
        {
            if ((equip_cmp(nequipment,"5") == TRUE) &&
        	((strcmp(trim(iins_type),"17") == 0) ||
        	(strcmp(trim(iins_type),"19") == 0)))
            {
                /* �U�L�@��, 17��19���C�L */
            }
            else
            {
	        deduct_prem = deduct_prem + ins_premium;

		if (ins_premium != 0)
		{
		    $SELECT nins_type into $nins_type from insurance_type
		      WHERE iins_type = $iins_type;
		      
		    strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
		    insert_prt_table(ipolicy,iins_type,nins_type," "," ","�i�h�O�j"," ",str_ins_premium,ins_premium);
		}
		continue;
	    }
        }
        /*======================================================================*/
        
        
        
        /*======================================================================*/
        /* �W�B�d���I,�L�b���I�ئC�L������(print_note) */
        /* �W�B�d���I(29),�p�G���O31,32,�|�ݭn�L�X�t���O���r�� 
        if ((strcmp(trim(iins_type),"29")==0) && (damage_cover > 0))
        {
            strcpy(flag_29_exist,"Y");
            code = lReturnIns29BaseCover(qday,&coverage1,&coverage2,&coverage3);
            tmp_cover1 = coverage1 / 10000;
            tmp_cover2 = coverage2 / 10000;
            tmp_cover3 = coverage3 / 10000;
            rfmtlong(tmp_cover1,"--,---,--&",sCoverage1);
            rfmtlong(tmp_cover2,"---,---,--&",sCoverage2);
            rfmtlong(tmp_cover3,"--,---,--&",sCoverage3);
            deduct = 0;
            qday = 0;
            strcpy(sCoverage1,trim(sCoverage1));
            strcpy(sCoverage2,trim(sCoverage2));
            strcpy(sCoverage3,trim(sCoverage3));
            printf("0100: iins_type[%s],cover1[%s],cover2[%s],cover3[%s]\n", iins_type, sCoverage1, sCoverage2, sCoverage3);
        } *//*else strcpy(flag_29_exist,"N");*/

        if ((strcmp(trim(iins_type),"31")==0 || strcmp(trim(iins_type),"77")==0 || strcmp(trim(iins_type),"231")==0) && (damage_cover > 0))
            strcpy(flag_31_exist,"Y");
        /*else strcpy(flag_31_exist,"N");*/

        if ((strcmp(trim(iins_type),"32")==0 || strcmp(trim(iins_type),"78")==0 || strcmp(trim(iins_type),"232")==0) && (damage_cover > 0))
            strcpy(flag_32_exist,"Y");
        /*else strcpy(flag_32_exist,"N");*/

        /* end of �P�_�O�_�L�X�t���O�r�� */
        /*======================================================================*/
        
        
        
        /*======================================================================*/
        /* SELECT�O�I����,�D�n���I����,�O�I���B,�ۭt�B�C�L���� */
        $SELECT nins_type,edomain2,nvl(qcoverage,0),nvl(cover_print,' '),
                fdeduct,nvl(deduct_print,' '), fcal_way
           INTO $nins_type,$main_paid,$qcoverage,$cover_print,
                $fdeduct,$deduct_print, $sFcal_way
           FROM insurance_type
          WHERE iins_type = $iins_type;

        strcpy(deduct_print, rtrim(deduct_print));
        printf("iins_type=[%s]sFcal_way=[%s]\n",iins_type,sFcal_way);
        /*======================================================================*/
        
        

        /*======================================================================*/
        /*�I��56 �������B���P����I�� 103.11.11*/
        /*�I��136 104.04.22 */
        /*166�I�حn�L�W�U (1090921003_SC1) */
        if (strcmp(trim(iins_type),"56") == 0 || strcmp(trim(iins_type),"136") == 0 || strcmp(trim(iins_type),"166") == 0 || strcmp(trim(iins_type),"266") == 0)
        {
            if (strcmp(trim(iins_type),"56") == 0)
     	        strcpy(sNassured_56_136,"56 �Q�O�I�H:");
     	    else if(strcmp(trim(iins_type),"136") == 0)
     	 	strcpy(sNassured_56_136,"136�Q�O�I�H:");
     	    else if(strcmp(trim(iins_type),"166") == 0)
     	 	strcpy(sNassured_56_136,"166�Q�O�I�H:");    
            else
     	 	strcpy(sNassured_56_136,"266�Q�O�I�H:"); 
     	 	
            strcpy(Full_DBName,get_car_full_db(ipolicy));
            sprintf(stmt,"SELECT distinct iins_scope \
                            FROM %s \
                           WHERE ipolicy = '%s' \
                             AND iins_type = '%s' \
                             AND (nvl(fedr_status,'') != '1' AND \
                             nvl(fedr_status,'') != '2' AND \
                             nvl(fedr_status,'') != '3');",tablePaPly,ipolicy,iins_type);

            $PREPARE pa_ply_56_scope FROM $stmt;
            $DECLARE pa_ply_56_scope_cur CURSOR FOR pa_ply_56_scope;
	    $OPEN  pa_ply_56_scope_cur;

            $FETCH pa_ply_56_scope_cur INTO $iins_scope_56;
            $CLOSE pa_ply_56_scope_cur;
	    $FREE  pa_ply_56_scope_cur;

            if((strcmp(trim(iins_scope_56),"2")==0))
            {
            	qcoverage = 2; /* 56�I�ؤ������B���P����I�� */
                strcpy(cover_print,"���|�������B;���G����");
            }
            else if((strcmp(trim(iins_scope_56),"3")==0))
            {
            	qcoverage = 2; /* 56�I�ؤ������B���P����I�� */
                strcpy(cover_print,"�ˮ`�����й���I��;���G����");
            }
        }
        /*======================================================================*/

        /*======================================================================*/
        if ((strcmp(trim(iins_type),"24") == 0)  || (strcmp(trim(iins_type),"52") == 0)  ||
            (strcmp(trim(iins_type),"53") == 0)  || (strcmp(trim(iins_type),"55") == 0)  ||
            (strcmp(trim(iins_type),"135") == 0) || (strcmp(trim(iins_type),"255") == 0) ||
            (strcmp(trim(iins_type),"252") == 0) || (strcmp(trim(iins_type),"253") == 0))
        {
            /* �I��52,53,55,24 �O�v�ͮĤ� >- '04/06/2011', �A�ηs�� add by sylvia 100.03.29 (1000323008)*/
            if(strcmp(sFcal_way,"1") == 0)
            {
               $SELECT case when drate >= date('04/06/2011') then '1' else '0' end
                  INTO $f52535524
                  FROM ca_rate_date
                 WHERE icode  = $drate_ym
                   AND itable = 'ca_rate';
            }
            else
            {
               $SELECT case when drate >= date('04/06/2011') then '1' else '0' end
                  INTO $f52535524
                  FROM ca_rate_date
                 WHERE icode  = $drate_ym
                   AND itable = 'cover_vs_premium';
            }
            if (SQLCODE == SQLNOTFOUND)  
                return M_CA_EXTRA_CHARGE_DRATE;
            printf("drate_ym=[%s] f52535524=[%s]\n",drate_ym,f52535524);


            /* �I��52,53,55,24 �s�¦��t add by sylvia 100.03.29 */
            if (strcmp(f52535524,"0") == 0)
            {   /* �A���¨� �O�v�ͮĤ� < 04/06/2011 */
                printf("-------------- �A���¨� �O�v�ͮĤ� < 04/06/2011 ---------\n");
                if (strcmp(trim(iins_type),"24")==0)
                    strcpy(nins_type,"���s���v�T���ר��`�H���v�I");
                else if (strcmp(trim(iins_type),"52")==0)
                {
                    strcpy(nins_type,"���D�d���I");
                    qcoverage = 3; /* �¨3�ӫO�B--���,���`,�ƬG */
                    strcpy(cover_print,"�C�@�H���;�C�@�H���`;�C�@�N�~�ƬG���`�B");
                }
                else if (strcmp(trim(iins_type),"53")==0)
                {
                    qcoverage = 3; /* �¨3�ӫO�B--���,���`,�ƬG */
                    strcpy(cover_print,"�C�@�H���;�C�@�H���`;�C�@�N�~�ƬG���`�B");
                }
                else if (strcmp(trim(iins_type),"55")==0 || strcmp(trim(iins_type),"135")==0 || strcmp(trim(iins_type),"255")==0)
                {
                    qcoverage = 3; /* �¨3�ӫO�B--���,���`,�ƬG */
                    strcpy(cover_print,"�C�@�H���;�C�@�H���`�Υ���;�C�@�N�~�ƬG���`�B");
                }
            }
            else
            {   
            	/* �A�ηs�� �O�v�ͮĤ� >= 04/06/2011 (�̳]�w�ɦC�L) */
                printf("-------------- �A�ηs�� �O�v�ͮĤ� > 04/06/2011 ---------\n");
                if (strcmp(trim(iins_type),"52")==0 || strcmp(trim(iins_type),"252")==0)
                {
                    if (fcar_class[0] == '1')
                    {
                        strcpy(nins_type,"���D�d�����[����");
                    }
                    else
                    {
                        strcpy(nins_type,"�T�����D�d���O�I");
                    }
                }
            }
        }/* end 52,53,55,24 �I�� */
        /*======================================================================*/
        
        
        
        /*======================================================================*/
        if ((strcmp(trim(iins_type),"62") == 0) || (strcmp(trim(iins_type),"63") == 0) ||
            (strcmp(trim(iins_type),"64") == 0) || (strcmp(trim(iins_type),"143") == 0))
        {
            /* �I��62,63,64 �O�v�ͮĤ� >= '12/01/2012', �A�ηs�� add by sylvia 101.12.25 (1011214002_C1)*/
            /* �s�W143�I�� add by �L�� 104.12.14 (1041203004_C2)*/   
            $SELECT case when drate >= date('12/01/2012') then '1' else '0' end
               INTO $f626364
               FROM ca_rate_date
              WHERE icode  = $drate_ym
                AND itable = 'cover_vs_premium';

            if (SQLCODE == SQLNOTFOUND)  
                return M_CA_EXTRA_CHARGE_DRATE;
            printf("drate_ym=[%s] f626364=[%s]\n",drate_ym,f626364);

            if (strcmp(f626364,"0") == 0)
            {   
            	/* �A���¨� �O�v�ͮĤ� < 12/01/2012 */
                printf("-------------- �A���¨� �O�v�ͮĤ� < 12/01/2012 ---------\n");
                if (strcmp(trim(iins_type),"62")==0)
                {
                    qcoverage = 1; /* �¨�u��1�ӫO�B--�ƬG */
                    strcpy(cover_print," ");
                }
                else if (strcmp(trim(iins_type),"63")==0)
                {
                    qcoverage = 1; /* �¨�u��1�ӫO�B--�ƬG */
                    strcpy(cover_print," ");
                }
                else if (strcmp(trim(iins_type),"64")==0)
                {
                    qcoverage = 1; /* �¨�u��1�ӫO�B--�ƬG */
                    strcpy(cover_print," ");
                }

            }
            else
            {   
            	/* �A�ηs�� �O�v�ͮĤ� >= 12/01/2012 (�̳]�w�ɦC�L) */
                printf("-------------- �A�ηs�� �O�v�ͮĤ� > 12/01/2012 ---------\n");
                /* ��car108�]�w: 62,63,64�O�B��2��--��ˡB�ƬG, �O�B��r�̳]�w�ɳ]�w */
            }
        }/* end 62,63,64 �I�� */
        /*======================================================================*/
        
        
        
        /*======================================================================*/
        /* �P�_�I��47 �O�v�ͮĤ� >= '03/01/2020', �I�ئW�٨̳]�w�ɦC�L*/
        /*            �O�v�ͮĤ� <  '03/01/2020', �I�ئW�٦C�L�u�����r�p�H�ˮ`�O�I�v*/
        /* 1081205009_SC4_�t�X47�I�رq�D�I�אּ���[�I�A�ק���s/E�O��/B2B/B2C�ˮ�(�Цb12�멳����)*/
        if (strcmp(trim(iins_type),"47") == 0 )
        {

            if (atoi(drate_ym) < 111)
            {   
               /*�����C�L�u�����r�p�H�ˮ`�O�I�v*/
               strcpy(nins_type,"�����r�p�H�ˮ`�O�I");
            }
            else
            {  
               /* ��car108�]�w*/
            }
        }/* end 47 �I�� */
        /*======================================================================*/
        
        

        /* end of select */
        /*======================================================================*/
        /* ��X�ۭt�B���C�L���e,fdeduct = 1�ɥN�����ۭt�B */
        printf("0110: �ۭt�B����[%s],deduct_print[%s]\n",fdeduct,deduct_print);
        if (strncmp(fdeduct,"1",1) == 0)
        {
            /* 86�I�اe�{�ۭt�B (1040525002_C1) */
            if (strcmp(trim(iins_type),"86") == 0)
            {
                $SELECT case when drate >= date('06/08/2015') then '1' else '0' end
                   INTO $f86
                   FROM ca_rate_date
                  WHERE icode  = $drate_ym
                    AND itable = 'cover_vs_premium';

                if (SQLCODE == SQLNOTFOUND)  
                    return M_CA_EXTRA_CHARGE_DRATE;

                strcpy(str_deduct,"");
                if (strcmp(trim(f86),"1") == 0)
                {
               	    if (deduct != 0)
               	    {
                        sprintf(deduct_print,"%d",deduct);
                        strcpy(str_deduct,deduct_print);
                        strcat(str_deduct,"%");
                    }
                    else
                    {
                        strcpy(str_deduct,"�L");
                    }
                }
                else
                {
                    strcpy(str_deduct,"�L");
                }
            }
            else
            {
                if ((strcmp(trim(deduct_print),"") == 0) ||(strcmp(trim(deduct_print),'\0') == 0))
        	{
        	    sprintf(str_deduct,"%d",deduct);
                    prn_deduct[0]=0;

                    $SELECT prn_deduct
                       INTO $prn_deduct
                       FROM ca_dmg_mdeduct
                      WHERE icar_type=$icar_type
                        AND ideduct=$str_deduct;

                    strcpy(str_deduct, trim(prn_deduct));
        	}
        	else
        	{
                    strcpy(str_deduct,deduct_print);
                }
            }
        }
        else
        {
            strcpy(str_deduct,deduct_print);
        }
        /* end of �ۭt�B�C�L */
        /*======================================================================*/
        
        
        
        /*======================================================================*/
        /* �B�z�h�ӫO�B,���N�I�ؤ����O�B����";"�����j�Ÿ���} */
        printf("0120: qcoverage[%d],iins_type[%s]\n",qcoverage,iins_type);
        if (qcoverage > 1)
        {
            ptr = strtok(cover_print,";");
            while (ptr != NULL)
            {
                strcpy(prt_coverage,trim(ptr));
                $INSERT INTO tbl_coverage (ipolicy, contain1) VALUES ($ipolicy,$prt_coverage);
            	ptr = strtok(NULL,";");
            }
        }
        /* End of �B�z�h�ӫO�B�C�L���e */
        /*======================================================================*/




        printf("0130: ipolicy[%s][%s][%d][%d][%d][%d][%s]\n",ipolicy,iins_type,injured_cover,death_cover,damage_cover,ins_premium,prn_deduct);
        iins=atoi(iins_type);

        switch (iins)
        {
            case 1: case 5: case 9: case 8: case 86: case 110: case 120: case 122: case 125: case 126: case 152: case 153: case 161: case 162: case 201: case 205: case 209:
                
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
        	if (iins == 120)
        	{
        	    sprintf(sStmt, "SELECT sum(mins_premium) \
                                      FROM %s \
                                     WHERE ipolicy = '%s' \
                                       AND iins_type in ('120','121');", tableInsType, ipolicy);
                    $PREPARE plyInsType120_cur FROM $sStmt;
                    $EXECUTE plyInsType120_cur INTO $ins_premium;
        	}
        	else if (iins == 122)
        	{
        	    sprintf(sStmt, "SELECT sum(mins_premium) \
                                      FROM %s \
                                     WHERE ipolicy = '%s' \
                                       AND iins_type in ('122','123');", tableInsType, ipolicy);
                    $PREPARE plyInsType122_cur FROM $sStmt;
                    $EXECUTE plyInsType122_cur INTO $ins_premium;
        	}
        	strcpy(str_ins_premium,rtrim(refmtamt(ins_premium,MILLIONTH)));
        	break;

            case 85:
            
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
        	strcpy(str_cover2,rtrim(refmtamt(injured_cover,MILLIONTH)));
        	strcpy(str_ins_premium,rtrim(refmtamt(ins_premium,MILLIONTH)));
        	break;

            /* �����¦����s�A�������I�����{���]�w(137�B138�B139�B141�B142�I��) (1100311005_SC6)*/
            case 105: case 118:
            
        	strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
        	strcpy(str_cover2,rtrim(refmtamt(injured_cover,MILLIONTH)));
        	if (iins == 118)
        	{
        	    sprintf(sStmt, "SELECT sum(mins_premium) \
                                      FROM %s \
                                     WHERE ipolicy = '%s' \
                                       AND iins_type in ('118','119');", tableInsType, ipolicy);
                    $PREPARE plyInsType118_cur FROM $sStmt;
                    $EXECUTE plyInsType118_cur INTO $ins_premium;
        	}
                strcpy(str_ins_premium,rtrim(refmtamt(ins_premium,MILLIONTH)));
        	break;

            case 2: case 3: case 7: case 150:
            
                strcpy(str_cover1," ");
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                if (iins == 150)
                {
                	strcpy(str_cover1,"�̱��ڬ��w");
                	sprintf(tmp_150151,"���m����:%.1f�U",mcar_price);
            		ins_150151 = 1;
                }
                break;

            case 10: case 127:
            
        	strcpy(str_ins_premium,rtrim(refmtamt(ins_premium,MILLIONTH)));
        	break;

            case 11: case 129: case 211:
            
                ins_11 = 1;
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
                strcat(str_deduct,refmtamt(deduct,MILLIONTH));
                strcat(str_deduct,"%");
                strcpy(str_ins_premium,rtrim(refmtamt(ins_premium,MILLIONTH)));
                break;

            case 12:
            
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
                strcat(str_cover1,"��");
                break;

            case 28: case 128:
            
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
                strcat(str_deduct,refmtamt(deduct,MILLIONTH));
                strcat(str_deduct,"%");
                strcpy(str_ins_premium,rtrim(refmtamt(ins_premium,MILLIONTH)));
                break;

            case 14:
            
                ins_14=1;
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                if (equip_cmp(nequipment,"5") == TRUE)
                {
                    strcpy(nequipment_7h_14,"1");
                }
                else
                {
                    strcpy(nequipment_7h_14,"0");
                }
                strcpy(iofficer_7h_14,substring(iofficer,1,3));
                printf("0140: nequipment_7h_14:[%s]\n,iofficer_7h_14:[%s]",nequipment_7h_14,iofficer_7h_14);

                if ( strncmp(nequipment_7h_14,"1",1)==0 && strcmp(trim(dpolicy),"")!=0 &&
                   ( iofficer[0] == 'A' || iofficer[0] == 'B') )
                {
                    ins_14=2;
                    premium_7h_14 = ins_premium;
                    old_premium_7h_14 = old_premium;
                    mdiscount_7h_14 = ins_mdiscount;
                }
                break;

            /* �����¦����s�A�������I�����{���]�w(137�B138�B139�B141�B142�I��) (1100311005_SC6)*/
            case 15: case 16: case 66: case 67: case 106: case 119: case 121: case 123:
            
                strcpy(str_cover1,ltoa(qday));
                strcat(str_cover1,"��");
                if (iins != 119 && iins != 121 && iins != 123 )
                {
                    strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                }
                else
                {
                    strcpy(str_cover2,rtrim(refmtamt(injured_cover,MILLIONTH)));
                }
                break;

            case 17: case 130: case 151:
            
                ins_17=1;
                strcpy(str_ins_premium,rtrim(refmtamt(ins_premium,MILLIONTH)));
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
                /*�U�L�@���M�׸ɵo���L17�I��*/
                if (equip_cmp(nequipment,"5") == TRUE)
                {
                    strcpy(nequipment_17,"1");
                }
                else
                {
                    strcpy(nequipment_17,"0");
                }
                
                printf("0150: nequipment_17:[%s]\n",nequipment_17);
                
                if ((strcmp(nequipment_17,"1")==0 && strcmp(trim(dpolicy),"")!=0 &&
                   ( iofficer[0] == 'A' || iofficer[0] == 'B' || iofficer[0] == 'J')) ||
                    strncmp(sIpolicyB_type,"1",1) == 0 )
                {
                    /* ins_17=2���ɭԥN���ɵo�B���O17�I��,17�I�ؤ��e���C�L,�O�O�]�n� */
                    /* �M�ץ�O�� 17�I�ؤ��e���C�L,�O�O�]�n� */
                    bufa_ins_17 = 1;
                    ins_17=2;
                    premium_17 = ins_premium;
                    old_premium_17 = old_premium;
                    mdiscount_17 = ins_mdiscount;
                }
                
                if (iins == 151)
                {
                	strcpy(str_cover1,"�̱��ڬ��w");
                	sprintf(tmp_150151,"���m����:%.1f�U",mcar_price);
            		ins_150151 = 1;
                }
                
                break;

            case 18:
            
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                strcpy(tmp_deduct,itoa(deduct));
                strncpy(deduct_30,&tmp_deduct[2],2);
                deduct_30[2] = '%';
                deduct_30[3] = '\0';
                strcpy(str_deduct,deduct_30);
                strcat(str_deduct,"(�_��");
                strncpy(deduct_30,tmp_deduct,2);
                deduct_30[2] = '%';
                deduct_30[3] = '\0';
                strcat(str_deduct,deduct_30);
                strcat(str_deduct,")");
                break;

            case 19:
            
                ins_19=1;
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                if (equip_cmp(nequipment,"5") == TRUE)
                {
                    strcpy(nequipment_7h_19,"1");
                }
                else
                {
                    strcpy(nequipment_7h_19,"0");
                }
                strcpy(iofficer_7h_19,substring(iofficer,1,3));
                printf("0190: nequipment_7h_19:[%s]\n,iofficer_7h_19:[%s]",nequipment_7h_19,iofficer_7h_19);

                if ( (strncmp(nequipment_7h_19,"1",1)==0 && strcmp(trim(dpolicy),"")!=0 &&
                   ( iofficer[0] == 'A' || iofficer[0] == 'B')) || strncmp(sIpolicyB_type,"1",1) == 0 )
                {
                    /* �M�ץ�O�� 19�I�ؤ��e���C�L,�O�O�]�n� */
                    bufa_ins_19 = 1;
                    ins_19=2;
                    premium_7h_19 = ins_premium;
                    old_premium_7h_19 = old_premium;
                    mdiscount_7h_19 = ins_mdiscount;
                }

                break;

            case 20: case 23: case 111:
            
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 22: case 112:
            
                strcpy(str_cover1,refmtamt(damage_cover,MILLIONTH));
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 24: case 88: case 26:
            
                if (fcomp_24 == 'Y' && strlen(str_ins_premium) != 0)
                {
                    strcpy(str_ins_premium,"�[�j ");
                    strcat(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                } 
                else 
                    strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 29: case 124:
            
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 30:
            
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
				strcpy(tmp_deduct,itoa(deduct));
				strcpy(deduct_30,tmp_deduct);
						
				/*�T�{���[�O24*/    
				$SELECT iins_type
				   INTO $iins_type24
				   FROM ply_ins_type
				  WHERE ipolicy = $ipolicy
				    AND iins_type = '24';
				if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��24�I��*/
				{
				    flag24=0;
				}
				else
				{
				    flag24=1;
				}
				
				 /* 1110308005_SC4_�w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h */
				/*�T�{���[�O55*/
				$SELECT iins_type
				   INTO $iins_type55
				   FROM ply_ins_type
				  WHERE ipolicy = $ipolicy
				    AND iins_type = '55';
				if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��55�I��*/
				{
				    flag55=0;
				}
				else
				{
				    flag55=1;
				}
				
				/*�T�{���[�O255*/
				$SELECT iins_type
				   INTO $iins_type55
				   FROM ply_ins_type
				  WHERE ipolicy = $ipolicy
				    AND iins_type = '255';
				if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��255�I��*/
				{
				    flag255=0;
				}
				else
				{
				    flag255=1;
				}
						
				/*�T�{���[�O49 or 117*/
				$SELECT iins_type
				   FROM ply_ins_type
				  WHERE ipolicy = $ipolicy
				    AND iins_type IN ('49','117');
				if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��49 or 117�I��*/
				{
				    flag49117=0;
				}
				else
				{
				    flag49117=1;
				}
				
				/* 1080311008_SC4_�ͮĤ��71�_����s�v�I */
				if((flag24 == 1) && (flag55 == 1) && (strncmp(fchk_24,"Y",1) == 0))
				{
				    if ((IsFcomp24(deduct_30)) && (IsFcomp55(deduct_30)))
				    {
				        strcpy(ps_dtl,str_ins_30_13);
				    }
				    else if (IsFcomp24(deduct_30))
				    {
						strcpy(ps_dtl,str_ins_30_21);
				    }
				    else if (IsFcomp55(deduct_30))
				    {
						strcpy(ps_dtl,str_ins_30_22);
				    }
				    else
				    {
				        strcpy(ps_dtl,str_ins_30_1 );
				    }
				}
				else if((flag24 == 1) && (strncmp(fchk_24,"Y",1) == 0))
				{
				    if (IsFcomp24(deduct_30))
				    {
				        strcpy(ps_dtl,str_ins_30_12);
				    }
				    else
				    {
						strcpy(ps_dtl,str_ins_30_2);
				    }		
				}
				else if((flag55 == 1) || (flag49117 == 1)) 
				{
				    if (IsFcomp55(deduct_30))
				    {
				        strcpy(ps_dtl,str_ins_30_11);
				    }
				    else
				    {
						strcpy(ps_dtl,str_ins_30_3);
				    }		
				}
				else if(flag255 == 1)
				{
					strcpy(ps_dtl,str_ins_30_4);
				}
						
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;
                
            case 301:
            /* 1110308005_SC4_�w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h */
				$SELECT iins_type
				   INTO $iins_type55
				   FROM ply_ins_type
				  WHERE ipolicy = $ipolicy
				    AND iins_type = '55';
				if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��55�I��*/
				{
				    flag55=0;
				}
				else
				{
				    flag55=1;
				}
				$SELECT iins_type
				   INTO $iins_type55
				   FROM ply_ins_type
				  WHERE ipolicy = $ipolicy
				    AND iins_type = '255';
				if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��255�I��*/
				{
				    flag255=0;
				}
				else
				{
				    flag255=1;
				}
                strcpy(str_cover1,rtrim(refmtamt(injured_cover,MILLIONTH)));
                strcpy(str_cover2,rtrim(refmtamt(damage_cover,MILLIONTH)));
                strcpy(tmp_deduct,itoa(deduct));
                strcpy(deduct_301,tmp_deduct);
                if(flag55 == 1)
                {
                    if (IsFcomp55(deduct_301))
                    {
                        strcpy(ps_dtl,str_ins_301_11);
                    }
                    else
                    {
                   		strcpy(ps_dtl,str_ins_301_1);
                    }
                }
                else if(flag255 == 1)
                {
                    strcpy(ps_dtl,str_ins_301_2);
                }
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

			case 302:
            /* 1110308005_SC4_�w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h */
				$SELECT iins_type
				   INTO $iins_type55
				   FROM ply_ins_type
				  WHERE ipolicy = $ipolicy
				    AND iins_type = '55';
				if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��55�I��*/
				{
				    flag55=0;
				}
				else
				{
				    flag55=1;
				}
				$SELECT iins_type
				   INTO $iins_type55
				   FROM ply_ins_type
				  WHERE ipolicy = $ipolicy
				    AND iins_type = '255';
				if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��255�I��*/
				{
				    flag255=0;
				}
				else
				{
				    flag255=1;
				}	
                strcpy(str_cover1,rtrim(refmtamt(injured_cover,MILLIONTH)));
                strcpy(str_cover2,rtrim(refmtamt(damage_cover,MILLIONTH)));
                strcpy(tmp_deduct,itoa(deduct));
                strcpy(deduct_302,tmp_deduct);
                if(flag55 == 1)        /*55���[�I*/
                {
                    if (IsFcomp55(deduct_302))
                    {
                        strcpy(ps_dtl,str_ins_302_11);
                    }
                    else
                    {
                   		strcpy(ps_dtl,str_ins_302_1);
                    }
                }
                else if(flag255 == 1)  /*255�D�I*/
                {
                    if (IsFcomp55(deduct_302))
                    {
                        strcpy(ps_dtl,str_ins_302_21);
                    }
                    else
                    {
                   		strcpy(ps_dtl,str_ins_302_2);
                    }
                }
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;
            /* 1140409004_C06_�s�W�r�V�Z��X�O�I */
			case 530:
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
                strcpy(tmp_deduct,itoa(deduct));
                strcpy(deduct_30,tmp_deduct);

                $SELECT iins_type
                INTO $iins_type55
                FROM ply_ins_type
                WHERE ipolicy = $ipolicy
                    AND iins_type = '555';
                if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��555�I��*/
                {
                    flag555=0;
                }
                else
                {
                    flag555=1;
                }
                if(flag555 == 1)        /*555���[�I*/
                {
                    if (IsFcomp55(deduct_30))
                    {
                        strcpy(ps_dtl,str_ins_530_11);
                    }
                    else
                    {
                        strcpy(ps_dtl,str_ins_530_1);
                    }
                }
                break;

            case 31: case 36: case 113: case 131: case 133: case 231: case 331: case 531:
            
                if(iins == 131 || iins== 331)
                {
                    strcpy(str_cover1,refmtamt(injured_cover,MILLIONTH));
                    /* �Y�O�B�G�W�L99,999,999��,��H�U����� */
                    if (damage_cover > 99999999)
                    {
                        strcpy(str_cover2,refmtamt((damage_cover/10000),MILLIONTH));
                        strcat(str_cover2,"�U");
                    }
                    else
                        strcpy(str_cover2,refmtamt(damage_cover,MILLIONTH));

                    strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                    /*strcpy(str_deduct,refmtamt(deduct,MILLIONTH));*/
                }
                else
                {
	            ins_31 = 1;
	            strcpy(str_cover1,refmtamt(injured_cover,MILLIONTH));
	            /* �Y�O�B�G�W�L99,999,999��,��H�U����� */
                    if (damage_cover > 99999999)
                    {
                        strcpy(str_cover2,refmtamt((damage_cover/10000),MILLIONTH));
                        strcat(str_cover2,"�U");
                    }
                    else
                        strcpy(str_cover2,refmtamt(damage_cover,MILLIONTH));

                    strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
					
		    printf("--113 str_deduct[%s] deduct[%d] \n",str_deduct,deduct);
		    
	            if (iins == 31 || iins == 133 || iins == 113 || iins == 231)
	                strcpy(str_deduct,refmtamt(deduct,MILLIONTH));
	                	
		    printf("--113 str_deduct[%s] deduct[%d] \n",str_deduct,deduct);
		    
	            ins_31_multiple = damage_cover / injured_cover;
	            
	            /* ���w�r�p�H */
	            if(strstr(trim(provision),"D;") != NULL)
		    {
		        strcpy(ins31_provision,"�i���w�r�p�H�j");
			printf("---- 1439---iins_type=[%s]provision=[%s]ins31_provision=[%s]\n",iins_type,provision,ins31_provision);
		    }
		    else if(strstr(trim(provision),"J;") != NULL)
		    {
			provision_J = 1;
			strcpy(ins31_provision,"�i�S�w�γ~�[�T�w�ϥΤH�j");
			printf("---- 1439---iins_type=[%s]provision=[%s]ins31_provision=[%s]\n",iins_type,provision,ins31_provision);
		    }
	            else
			ins31_provision[0]= '\0';
		}

                break;

            case 32: case 37: case 114: case 132: case 134: case 149: case 232: case 332: case 249: case 532:
            
                if(iins == 132 || iins == 332)
                {
                    strcpy(str_cover1,refmtamt(damage_cover,MILLIONTH));
                    strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                }
                else
                {
                    ins_32 = 1;
                    strcpy(str_cover1,refmtamt(damage_cover,MILLIONTH));
                    strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                }

                if (iins == 32 || iins == 134 || iins == 149 || iins == 114 || iins == 232 || iins == 249 || iins == 532)
                    strcpy(str_deduct,refmtamt(deduct,MILLIONTH));
                break;

            case 34: case 87: case 115:
            
                /* �Ψ�Ū�����ݪ��I�ت��O�B�O�O */
                insurance_cover_count = 0;
                $SELECT COUNT(*)
           	   INTO $insurance_cover_count
                   FROM insurance_cover
                  WHERE iins_type = $iins_type;
                /* �������ݪ����Ū�� */

                /* �ΨӳB�z�I��34 */
                if( insurance_cover_count != 0)
                {    /* CA_CONS */
                    IcurrPlyInsCover = move_ply_ins_cover_curr2( IfirstPlyInsCover, &iins, "001");
                    strcpy(str_cover1, refmtamt(IcurrPlyInsCover->mcover, MILLIONTH));
                    lPremSum += IcurrPlyInsCover->mcover_prem;

                    IcurrPlyInsCover = move_ply_ins_cover_curr2( IfirstPlyInsCover, &iins, "002");
                    /*sprintf( sTmp, "%g�U", (double)((IcurrPlyInsCover->mcover)/10000));*/
                    /*strcpy(str_cover2, sTmp);*/
                    strcpy(str_cover2, refmtamt(IcurrPlyInsCover->mcover, MILLIONTH));
                    lPremSum += IcurrPlyInsCover->mcover_prem;

                    IcurrPlyInsCover = move_ply_ins_cover_curr2( IfirstPlyInsCover, &iins, "003");
                    strcpy(str_cover3, refmtamt(IcurrPlyInsCover->mcover, MILLIONTH));
                    printf("3------IcurrPlyInsCover->mcover=[%d],  str_cover3=[%s]\n ",IcurrPlyInsCover->mcover, str_cover3);
                    lPremSum += IcurrPlyInsCover->mcover_prem;

                    IcurrPlyInsCover = move_ply_ins_cover_curr2( IfirstPlyInsCover, &iins, "004");
                    /*sprintf( sTmp, "%g�U", (double)IcurrPlyInsCover->mcover/10000);*/
                    /*strcpy(str_cover4, sTmp);*/
                    strcpy(str_cover4, refmtamt(IcurrPlyInsCover->mcover,MILLIONTH));

                    strcpy(str_ins_premium,refmtamt( lPremSum,MILLIONTH)); /* �L�X���I�ؤ��P�O�B�X�p���O�O */
                }
                break;

            case 38: case 39:
           
                strcpy(str_cover1,ltoa(qday));
                strcat(str_cover1,"����");
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 35: 
            
                strcpy(Full_DBName,get_car_full_db(ipolicy));
                sprintf(stmt,"SELECT distinct iins_scope \
                                FROM %s \
                               WHERE ipolicy = '%s' \
                                 AND iins_type = '35' \
                                 AND mins_amt > 0;",tablePaPly,ipolicy);
                $PREPARE pa_ply_35 FROM $stmt;
	        $DECLARE pa_ply35_cur CURSOR FOR pa_ply_35;
	        $OPEN  pa_ply35_cur;
                $FETCH pa_ply35_cur INTO $tmp_iins_scope;
                $CLOSE pa_ply35_cur;
	        $FREE  pa_ply35_cur;

                strcpy(nins_type,trim(nins_type));

                if( strcmp(trim(tmp_iins_scope),"1") == 0 )
                    strcat(nins_type,"  �O�W��");
                else if( strcmp(trim(tmp_iins_scope),"2") == 0 )
                    strcat(nins_type,"  �a�x��");

                if (strcmp(trim(tmp_iins_scope),"1") != 0)
                    strcpy(cover_print,"");

                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
                
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;
                
            case 48:
                
                if (damage_cover > 99999999)
                {
                    strcpy(str_cover1,refmtamt((damage_cover/10000),MILLIONTH));
                    strcat(str_cover1,"�U");	
                }
                else
                {
                    strcpy(str_cover1,refmtamt(damage_cover,MILLIONTH));
                }

                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 47: case 147:
            	
            	if(strcmp(iins_type,"147")==0) ins_56 = 1;
            	
                if (injured_cover > 99999999)
                {
                    strcpy(str_cover1,refmtamt((injured_cover/10000),MILLIONTH));
                    strcat(str_cover1,"�U");                		
                }
                else
                {
                    strcpy(str_cover1,refmtamt(injured_cover,MILLIONTH));
                }
                
                if (death_cover > 99999999)
                {
                    strcpy(str_cover2,refmtamt((death_cover/10000),MILLIONTH));
                    strcat(str_cover2,"�U");               		
                }
                else
                {
                    strcpy(str_cover2,refmtamt(death_cover,MILLIONTH));
                }

                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 49:
            
                strcpy(str_cover1,refmtamt(injured_cover,MILLIONTH));
                strcpy(str_cover2,refmtamt(death_cover,MILLIONTH));
                strcpy(str_cover3,refmtamt(damage_cover,MILLIONTH));
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 50:
                
                if (injured_cover > 99999999)
                {
                    strcpy(str_cover1,refmtamt((injured_cover/10000),MILLIONTH));
                    strcat(str_cover1,"�U");                		
                }
                else
                {
                    strcpy(str_cover1,refmtamt(injured_cover,MILLIONTH));                	
                }

                if (death_cover > 99999999)
                {
                    strcpy(str_cover2,refmtamt((death_cover/10000),MILLIONTH));
                    strcat(str_cover2,"�U");                	
                }
                else
                {
                    strcpy(str_cover2,refmtamt(death_cover,MILLIONTH));                	
                }

                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 52: case 252:
            
                if (qcoverage > 2)
                {
                    strcpy(str_cover1,refmtamt(injured_cover,MILLIONTH));
                    strcpy(str_cover2,refmtamt(death_cover,MILLIONTH));
                    strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                    people = (int) (damage_cover / death_cover);
                    /* �Y�O�B�T�W�L99,999,999��,��H�U����� */
                    if (damage_cover > 99999999)
                    {
                        strcpy(str_cover3,refmtamt((damage_cover/10000),MILLIONTH));
                        strcat(str_cover3,"�U");
                    }
                    else
                        strcpy(str_cover3,refmtamt(damage_cover,MILLIONTH));

                }
                else
                {
                    strcpy(str_cover1,refmtamt(death_cover,MILLIONTH));
                    strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                    people = (int) (damage_cover / death_cover);
                    /* �Y�O�B�T�W�L99,999,999��,��H�U����� */
                    if (damage_cover > 99999999)
                    {
                        strcpy(str_cover2,refmtamt((damage_cover/10000),MILLIONTH));
                        strcat(str_cover2,"�U");
                    }
                    else
                        strcpy(str_cover2,refmtamt(damage_cover,MILLIONTH));

                }
                break;

            case 51:
            
                ins_51 = 1;
                strcpy(str_cover1,refmtamt(injured_cover,MILLIONTH));
                strcpy(str_cover2,refmtamt(death_cover,MILLIONTH));
                /* �Y�O�B�T�W�L99,999,999��,��H�U����� */
                if (damage_cover > 99999999)
                {
                    strcpy(str_cover3,refmtamt((damage_cover/10000),MILLIONTH));
                    strcat(str_cover3,"�U");
                }
                else
                    strcpy(str_cover3,refmtamt(damage_cover,MILLIONTH));
                
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));

                if( (iins == 51) && (death_cover == damage_cover))
                    strcpy(ps_dtl,str_ps);
                break;

            case 53: case 55: case 117: case 135: case 255: case 253: case 555:
            
                if (qcoverage > 2)
                {
                    strcpy(str_cover1,refmtamt(injured_cover,MILLIONTH));
                    strcpy(str_cover2,refmtamt(death_cover,MILLIONTH));
                    /* �Y�O�B�T�W�L99,999,999��,��H�U����� */
                    if (damage_cover > 99999999)
                    {
                        strcpy(str_cover3,refmtamt((damage_cover/10000),MILLIONTH));
                        strcat(str_cover3,"�U");
                    }
                    else
                        strcpy(str_cover3,refmtamt(damage_cover,MILLIONTH));
                        
                    strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));

                }
                else
                {
                    strcpy(str_cover1,refmtamt(death_cover,MILLIONTH));
                    /* �Y�O�B�G�W�L99,999,999��,��H�U����� */
                    if (damage_cover > 99999999)
                    {
                        strcpy(str_cover2,refmtamt((damage_cover/10000),MILLIONTH));
                        strcat(str_cover2,"�U");
                    }
                    else
                        strcpy(str_cover2,refmtamt(damage_cover,MILLIONTH));
                        
                    strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                    
                }
                
                strcpy(ps_60,"");
                if(strcmp(iins_type,"55")==0 || strcmp(iins_type,"555")==0)
                {
                	if((strcmp(icar_type,"11") == 0) && (equip_cmp(nequipment,"115") == TRUE) && fdbgn20230601[0] == 'Y')
                	{
                		if (strcmp(trim(dpolicy),"")!=0 )
                		{
                			if(fdply20230601[0] == 'Y')
								strcpy(ps_60,str_ins_55_car_11);
							else 
								strcpy(ps_60," ");
						}
						else 
							strcpy(ps_60,str_ins_55_car_11);
					}
                }

                break;

            case 56: case 136: case 166: case 266:
            
                ins_56 = 1;
                strcpy(Full_DBName,get_car_full_db(ipolicy));
                sprintf(stmt,"SELECT max(daily_pay) \
                                FROM %s \
                               WHERE ipolicy = '%s' \
                                 AND iins_type in ('56','136','166','266');",tablePaPly,ipolicy);
                $PREPARE pa_ply_56 FROM $stmt;
		        $DECLARE pa_ply56_cur CURSOR FOR pa_ply_56;
		        $OPEN  pa_ply56_cur;
	            $FETCH pa_ply56_cur INTO $daily_pay;
	            $CLOSE pa_ply56_cur;
		        $FREE  pa_ply56_cur;
	              
                /*1080711006_SC1_�ק�O��/���C�L���e�A�ҥH�I�ثO�B�ҭn��"," 2019.08.07 by 071004*/
                strcpy(str_cover1,refmtamt(daily_pay,MILLIONTH));
                if (damage_cover > 99999999)
                {
                    strcpy(str_cover2, refmtamt((damage_cover /10000),MILLIONTH));
                    strcat(str_cover2,"�U");                 	
                }
                else
                {
                    strcpy(str_cover2, refmtamt(damage_cover,MILLIONTH));
                }

                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 57: case 59: case 60:
            
                /* car9801122 �T���ȹB�~�����I(57,59,60), add by Julia in 2009/01/19 */
                /* 0991209006_C3 �[�L��˫O�B add by sylvia 100.01.20 (0991209006_C1) */
                if (qcoverage > 2)
                { /* ���L��� */
                    strcpy(str_cover1,refmtamt(injured_cover,MILLIONTH));
                    strcpy(str_cover2,refmtamt(death_cover,MILLIONTH));
                    /* �Y�O�B�T�W�L99,999,999��,��H�U����� */
                    if (damage_cover > 99999999)
                    {
                        strcpy(str_cover3,refmtamt((damage_cover/10000),MILLIONTH));
                        strcat(str_cover3,"�U");
                    }
                    else
                        strcpy(str_cover3,refmtamt(damage_cover,MILLIONTH));
                }
                else
                {
                    /* ���L��� */
                    strcpy(str_cover1,refmtamt(death_cover,MILLIONTH));
                    /* �Y�O�B�G�W�L99,999,999��,��H�U����� */
                    if (damage_cover > 99999999)
                    {
                        strcpy(str_cover2,refmtamt((damage_cover/10000),MILLIONTH));
                        strcat(str_cover2,"�U");
                    }
                    else
                        strcpy(str_cover2,refmtamt(damage_cover,MILLIONTH));
                }
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));

                ins_575960 = 1;
                break;

            /* �����¦����s�A�������I�����{���]�w(137�B138�B139�B141�B142�I��) (1100311005_SC6)*/
            case 61: case 65: case 69: case 68: case 108:
            
                strcpy(str_cover1,refmtamt(damage_cover,MILLIONTH));
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 62: case 63: case 64: case 143:
            
                if (qcoverage > 1)
            	{	
            	    /* �A�ηs��(���G�ӫO�B) add by sylvia 101.12.25 (1011214002_C1) */
            	    strcpy(str_cover1,refmtamt(injured_cover,MILLIONTH));
	            strcpy(str_cover2,rtrim(refmtamt(damage_cover,MILLIONTH)));
	            strcat(str_deduct,refmtamt(deduct,MILLIONTH));
	            strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
	        }
	        else
	        {
	            /* �A���¨�(�u���@�ӫO�B) */
	            strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
	            strcat(str_deduct,refmtamt(deduct,MILLIONTH));
	            strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
	        }
                break;

            case 71: case 72: case 78: case 79: case 89: case 90:
            
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 77: case 80:
            
                strcpy(str_cover1,refmtamt(injured_cover,MILLIONTH));
                if (damage_cover > 99999999)
                {
                    strcpy(str_cover2,refmtamt((damage_cover/10000),MILLIONTH));
                    strcat(str_cover2,"�U");
                }
                else
                    strcpy(str_cover2,refmtamt(damage_cover,MILLIONTH));

                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 96:
            
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
                strcpy(str_deduct,refmtamt(deduct,MILLIONTH));
                strcat(str_deduct,"%");
                /* strcpy(str_ins_premium,rtrim(refmtamt(ins_premium,MILLIONTH))); */
                /* Ū��96+97�O�O */
                sprintf(sStmt, "SELECT sum(mins_premium) \
                                  FROM %s \
                                 WHERE ipolicy = '%s' \
                                   AND iins_type in ('96','97');", tableInsType, ipolicy);
                $PREPARE plyInsType96_cur FROM $sStmt;
                $EXECUTE plyInsType97_cur INTO $ins_premium;

                strcpy(str_ins_premium,rtrim(refmtamt(ins_premium,MILLIONTH)));
                break;

            case 97:
            
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
                /* strcat(str_deduct,refmtamt(deduct,MILLIONTH));
                strcat(str_deduct,"%"); */
                break;

		    /* �����¦����s�A�������I�����{���]�w(137�B138�B139�B141�B142�I��) (1100311005_SC6)*/
		    case 107:
		    
		        strcpy(str_cover1,refmtamt(injured_cover,MILLIONTH));
	                strcpy(str_cover2,rtrim(refmtamt(damage_cover,MILLIONTH)));
	                strcat(str_deduct,refmtamt(deduct,MILLIONTH));
	                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
	                break;
	            
	        case 154: case 155: case 156: case 163:
	            
            	strcpy(str_cover1,ltoa(qday));
                strcat(str_cover1,"��");
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                strcpy(str_cover2,rtrim(refmtamt(injured_cover,MILLIONTH)));
			break;
			
			case 173:
					
				strcpy(str_cover1,refmtamt(damage_cover,MILLIONTH));
				strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
				break;
				
			case 174:
			
				strcpy(str_cover1,refmtamt(injured_cover,MILLIONTH));
				strcpy(str_cover2,rtrim(refmtamt(damage_cover,MILLIONTH)));
				strcat(str_deduct,refmtamt(deduct,MILLIONTH));
	            strcat(str_deduct,"%");
	            strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;
			
			case 175:
			
				strcpy(str_cover1," ");
				strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;
			
			case 176: case 177:
	        	
	        	strcat(str_deduct,refmtamt(deduct,MILLIONTH));
	            strcat(str_deduct,"%");
	    		strcpy(str_ins_premium,rtrim(refmtamt(ins_premium,MILLIONTH)));
	    	break;
	    	
	    	case 178:
			
				strcpy(str_cover1,refmtamt(injured_cover,MILLIONTH));
				strcpy(str_cover2,rtrim(refmtamt(damage_cover,MILLIONTH)));
				strcat(str_deduct,refmtamt(deduct,MILLIONTH));
	            strcat(str_deduct,"%");
	            strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;
			
			case 237:
	            	
	        	/*1130229009_C09_�s�W�N�~�ƬG�୼�O�Ϊ��[����(�L��)*/
	            strcpy(str_cover1,rtrim(refmtamt(injured_cover,MILLIONTH)));
	            strcpy(str_cover2,rtrim(refmtamt(damage_cover,MILLIONTH)));
	            strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;
			
			case 238:
	            	
	            	/*1101229013_SC4_�s�W238�I�ؤ������{�O�v-�L��@�~*/
	            	if (qday == 999)
	            	{
	            		strcpy(str_cover4,"����");
	            	}
	            	else
	            	{
	                	strcpy(str_cover4,ltoa(qday));
	            	}
	                strcat(str_cover4,"����");
	                strcpy(str_cover1,rtrim(refmtamt(injured_cover,MILLIONTH)));
	                strcpy(str_cover2,rtrim(refmtamt(damage_cover,MILLIONTH)));
	                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;

            case 561:

				ins_56 = 1;
				strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
				strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;
			case 562:

				strcpy(str_cover1,rtrim(refmtamt(injured_cover,MILLIONTH)));
				strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;
			
	            default:
	            
	                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
	                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
	                break;

        }/* end of switch */



        /*======================================================================*/
        /* �ɵo�O��B�ӳ榳�O�U�L�@��,17�I�ؤ��C�L */
        /* �M�ץ�O��,17�I�ؤ��C�L */
        if (ins_17 == 2)
        {
        	  ins_17 = 0;
        	  continue;
        }
        /* end of �P�_�U�L�@�� */

        /* �ɵo�O��B�ӳ榳�O�U�L�@��,14�I�ؤ��C�L */
        if (ins_14 == 2)
        {
        	  ins_14 = 0;
        	  continue;
        }
        /* end of �P�_�U�L�@�� */

        /* �ɵo�O��B�ӳ榳�O�U�L�@��,19�I�ؤ��C�L */
        /* �M�ץ�O��,19�I�ؤ��C�L */
        if (ins_19 == 2)
        {
        	  ins_19 = 0;
        	  continue;
        }
        /* end of �P�_�U�L�@�� */
        /*======================================================================*/
        
        
        

        /* �N�C�L����Ʃ�J�Ȧstable */
        /* �Y�O�B���@�ӥH�W���ɭ�,�n�̷ӫO�B�Ӽƨ̧ǩ�J�Ȧs���C�Ltable */
        strcpy(iins_type,trim(iins_type));
        printf("iins_type=[%s]ins31_provision=[%s]\n",iins_type,ins31_provision);
        
        
        
        /*======================================================================*/
        /*======== ��������������  �H�U�B�z�I�ؤ���W�٫�A�������[����  �������������� ========*/ 
	nins_type2[0] = '\0';
	strcpy(nins_type2,rtrim(nins_type));
	strcpy(provision2,trim(provision));
	if (strlen(provision) > 1) 
	{
	    if(strstr(trim(provision),"P;") != NULL)
	    {
	        if ((strcmp(iins_type,"01") != 0)  && (strcmp(iins_type,"05") != 0)  && (strcmp(iins_type,"09") != 0)  && (strcmp(iins_type,"11") != 0) &&
	            (strcmp(iins_type,"201") != 0) && (strcmp(iins_type,"205") != 0) && (strcmp(iins_type,"209") != 0) && (strcmp(iins_type,"211") != 0))
		    $SELECT first 1 replace($provision2,'P;','')
		       INTO $provision2
		       FROM systables;
	    }
			
	    if(strstr(trim(provision),"Q;") != NULL)
	    {
			if ((strcmp(iins_type,"01") != 0)  && (strcmp(iins_type,"05") != 0)  && (strcmp(iins_type,"09") != 0)  && (strcmp(iins_type,"11") != 0) &&
	            (strcmp(iins_type,"201") != 0) && (strcmp(iins_type,"205") != 0) && (strcmp(iins_type,"209") != 0) && (strcmp(iins_type,"211") != 0))
		    $SELECT first 1 replace($provision2,'Q;','')
		       INTO $provision2
		       FROM systables;
	    }
			
	    if(strstr(trim(provision),"M;") != NULL)
	    {
		if ((strcmp(iins_type,"01") != 0)  && (strcmp(iins_type,"05") != 0)  && (strcmp(iins_type,"09") != 0)  && (strcmp(iins_type,"11") != 0) && (strcmp(iins_type,"181") != 0) &&
	        (strcmp(iins_type,"201") != 0) && (strcmp(iins_type,"205") != 0) && (strcmp(iins_type,"209") != 0) && (strcmp(iins_type,"211") != 0))
		    $SELECT first 1 replace($provision2,'M;','')
		       INTO $provision2
		       FROM systables;
	    }
	    
	    /* 1130827011_C04_�s�W�s�t��W�B���[����(Y)(�L��) */
	    if(strstr(trim(provision),"Y;") != NULL)
	    {
		if ((strcmp(iins_type,"01") != 0)  && (strcmp(iins_type,"05") != 0)  && (strcmp(iins_type,"09") != 0)  && (strcmp(iins_type,"11") != 0) && (strcmp(iins_type,"198") != 0) &&
	        (strcmp(iins_type,"201") != 0) && (strcmp(iins_type,"205") != 0) && (strcmp(iins_type,"209") != 0) && (strcmp(iins_type,"211") != 0))
		    $SELECT first 1 replace($provision2,'Y;','')
		       INTO $provision2
		       FROM systables;
	    }
						
	    if(strstr(trim(provision),"X;") != NULL)
	    {
			$SELECT first 1 replace($provision2,'X;','')
			   INTO $provision2
			   FROM systables;
	    }
			
	    if(strstr(trim(provision),"D;") != NULL)
	    {
	        if (strcmp(iins_type,"07") == 0) /*07�������(D)*/
			{
			    $SELECT first 1 replace($provision2,'D;','')
			       INTO $provision2
			       FROM systables;
			}
	    }
			
	    if(strstr(trim(provision),"H;") != NULL)
	    {
	        if (strcmp(iins_type,"07") == 0 || strcmp(iins_type,"10") == 0 || strcmp(iins_type,"109") == 0)
			{
			    $SELECT first 1 replace($provision2,'H;','')  /*07�B10�B109�������(H)*/
			       INTO $provision2
			       FROM systables;
			}
	    }
			
	    if(strstr(trim(provision),"L;") != NULL)   /*1080708002_SC4_�s�W�����������(�N��L)*//* 2019.09.10 by 071004 */
	    {
			$SELECT first 1 replace($provision2,'L;','')
			   INTO $provision2
			   FROM systables;
	    }

	    strcpy(provision2,trim(provision2));
	    if (strlen(provision2) > 1) 
	    {
	    	provision2[strlen(provision2)-1]='\0';
	        strcat(nins_type2,"(");
			strcat(nins_type2,provision2);
			strcat(nins_type2,")");
			strcpy(nins_type,nins_type2);
			printf("--nins_type2[%s]\n",nins_type2);
	    }
	}
	printf("--2999 iins_type[%s] nins_type[%s] provision[%s] \n",iins_type,nins_type,provision);
	
	/*======== ��������������  �H�W�B�z�I�ؤ���W�٫�A�������[����  �������������� ========*/
	/*======================================================================*/

        /*======================================================================*/ 
        /* �P�ɩӫO31,32�I��,�S�O�h�����O��,�B��D����,�n�b�g�J32�e�A�h�@��LD���ڸ�� */
        if (((strcmp(iins_type,"32") == 0) || (strcmp(iins_type,"134") == 0) || (strcmp(iins_type,"232") == 0)) && (ins_31_multiple > 2)&& (ins31_provision[0] != '\0'))
        {
            if(strstr(trim(provision),"D;") != NULL)
	    {
	        insert_prt_table(ipolicy,"","�i���w�r�p�H�j","","","","","", 0);            
	    }
	    else if(strstr(trim(provision),"J;") != NULL)
	    {
		insert_prt_table(ipolicy,"","�i�S�w�γ~�[�T�w�ϥΤH�j","","","","","", 0); 
	    }

            printf("---- 1771---iins_type=[%s]provision=[%s]\n",iins_type,provision);
        }
        /*======================================================================*/

        /*======================================================================*/
        /*======== ��������������  �H�U�B�z�O�B�C�L  �������������� ========*/
        if (qcoverage > 1)
        {
            /* ���I�ئW�٩�G��  modify by sylvia 102.10.23 ---------------------------------------------- */
            strcpy(nins_type, rtrim(nins_type));
            printf("----- 1892 iins_type=[%s] nins_type=[%s][%D]--- \n",iins_type,nins_type,strlen(nins_type));
            if (strlen(nins_type) > 16)
            {
                nins_type_len = cc_split_chinese(nins_type,nins_type_split,16);
         	strcpy(nins_type_split, rtrim(nins_type_split));
         	strncpy(stmp_ntype1, nins_type_split, 16);
         	strncpy(stmp_ntype2, &nins_type[16], strlen(nins_type)-16);
         	stmp_ntype1[16]='\0';
         	stmp_ntype2[strlen(nins_type)-16]='\0';
         	printf("stmp_ntype1=[%s],stmp_ntype2=[%s]\n",stmp_ntype1,stmp_ntype2);
            }
            else
            {
         	strcpy(stmp_ntype1, nins_type);
         	strcpy(stmp_ntype2,"");
            }
            /* ���I�ئW�٩�G��  modify by sylvia 102.10.23 ---------------------------------------------- */

            /* �D�n���I���ة�G��  modify by sylvia 102.10.23 ---------------------------------------------- */
            strcpy(main_paid, rtrim(main_paid));
            printf("----- 1892 iins_type=[%s] main_paid=[%s][%D]--- \n",iins_type,main_paid,strlen(main_paid));
            if (strlen(main_paid) > 14)
            {
                strncpy(stmp_mpad1, main_paid, 14);
         	strncpy(stmp_mpad2, &main_paid[14], strlen(main_paid)-14);
         	stmp_mpad1[14]='\0';
         	stmp_mpad2[strlen(main_paid)-14]='\0';
         	printf("stmp_mpad1=[%s],stmp_mpad2=[%s]\n",stmp_mpad1,stmp_mpad2);
            }
            else
            {
         	strcpy(stmp_mpad1, main_paid);
         	strcpy(stmp_mpad2,"");
            }
            /* �D�n���I���ة�G��  modify by sylvia 102.10.23 ---------------------------------------------- */

            /* �h�ӫO�B */
            $DECLARE cur_coverage1 CURSOR for
              SELECT contain1 FROM tbl_coverage WHERE ipolicy = $ipolicy ORDER BY serial_no;

            j = 0;
            $OPEN cur_coverage1;
            while (1)
            {
                $FETCH cur_coverage1 INTO $contain_coverage;

                if (SQLCODE == SQLNOTFOUND) break; 

                strcpy(cover_print,trim(contain_coverage));
               
                if(j==0)
                {
               	
                    strcpy(amt_print,str_cover1);
                    strcpy(nins_type, stmp_ntype1);
                    strcpy(main_paid, stmp_mpad1);
                    printf("j=0, nins_type=[%s] \n",nins_type );
                   
                }
                else if (j==1)
                {
               	
                    strcpy(amt_print,str_cover2);
                    strcpy(iins_type,"");
                    strcpy(nins_type, stmp_ntype2);	/* �I�ئW�ٲĤG�� */

                    /* �P�_�O�_�L�X���w�r�p�H add by sylvia 101.06.21 */
                    printf("provision=[%s]\n",provision);
		    if(strstr(trim(provision),"D;") != NULL)
		    {
		        /* strcpy(nins_type,"�i���w�r�p�H�j"); */
		        /*strcat(nins_type,"�i���w�r�p�H�j");*/
		        printf("---- 1781---iins_type=[%s]provision=[%s]\n",iins_type,provision);
		    }
		    else if(strstr(trim(provision),"J;") != NULL)
		    {
		        provision_J = 1;
		        /*strcat(nins_type,"�i�S�w�γ~�[�T�w�ϥΤH�j");*/
		        printf("---- 1781---iins_type=[%s]provision=[%s]\n",iins_type,provision);
		    }
		    else
		        strcat(nins_type,"");

		    printf("---- 1876---iins_type=[%s]provision=[%s]\n",iins_type,provision);
		    printf("j=0, stmp_ntype2=[%s] \n",stmp_ntype2 );
                    /* strcpy(main_paid,""); */
                    strcpy(main_paid, stmp_mpad2);
                    strcpy(str_deduct,"");
                   
                }
                else if (j==2)
                {
                    strcpy(amt_print,str_cover3);
                    strcpy(iins_type,"");
                    strcpy(nins_type,"");
                    strcpy(main_paid,"");
                    strcpy(str_deduct,"");
                }
                else
                {
                    strcpy(amt_print,str_cover4);
                    strcpy(iins_type,"");
                    strcpy(nins_type,"");
                    strcpy(main_paid,"");
                    strcpy(str_deduct,"");
                }

                printf("0160: cover_print[%s],amt_print[%s]\n",cover_print,amt_print);
               
                /* �h�O�B���ɭ�,�u���Ĥ@��~�|�L�X�O�O */
                if (j > 0)
                {   
                    strcpy(str_ins_premium,"");
                    ins_premium = 0;
                }
                /* end of �h�O�B�O�O�B�z */

                insert_prt_table(ipolicy,iins_type,nins_type,main_paid,cover_print,amt_print,str_deduct,str_ins_premium,
                                 ins_premium);
                j++;
            }
           
            $CLOSE cur_coverage1;
            $FREE cur_coverage1;
            $DELETE tbl_coverage WHERE ipolicy=$ipolicy;
                
        }
        else if (strcmp(iins_type, "96")==0)
        {
            /* �n�g�J�G��:�Ĥ@�欰�D�I��-�I�إN��96,�D�n�I�ئW��,�D�n���I����,96+97�`�O�O;
                          �ĤG�欰96�I��:�I�ئW��,�O�B,�ۭt�B */
            strcpy(cover_print,trim(cover_print));
            strcpy(amt_print,str_cover1);

            /* �Ĥ@�� */
            insert_prt_table(ipolicy,iins_type,"�T���ѵs�l���O�I(�ҫ�)","�ꨮ�ߥI�B�]���l���O�I���B�N���O��",
                             " "," "," ",str_ins_premium,ins_premium);

            /* �ĤG�� */
            sprintf(sNinstype2, "  %s",nins_type);
            insert_prt_table(ipolicy," ",sNinstype2," ",cover_print,amt_print,str_deduct," ", 0);
         
        }
        else if (strcmp(iins_type, "97")==0)
        {
            /* �g�J97�I��:�W��,�O�B,�ۭt�B */
            strcpy(cover_print,trim(cover_print));
            strcpy(amt_print,str_cover1);
            sprintf(sNinstype2, "  %s",nins_type);
            insert_prt_table(ipolicy," ",sNinstype2," ",cover_print,amt_print,str_deduct," ", 0);

            /* �P�_�O�_�L�X���w�r�p�H add by sylvia 101.06.21 */
            if(strstr(trim(provision),"D;") != NULL)
            {
                strcpy(nins_type,"�i���w�r�p�H�j");
                insert_prt_table(ipolicy,"",nins_type,"","","","","", 0);
                printf("---- 1849---iins_type=[%s]provision=[%s]\n",iins_type,provision);
            }
        }
        else if (strcmp(iins_type, "119") == 0 || strcmp(iins_type, "121") == 0)
        {
            /* 119��121�I�ءu�D�n���I���ءv�Ρu�O�I���B�v�e�{�覡��אּ��C (1040109009_C1)*/
            strcpy(iins_type,"");
            strcpy(cover_print,"");
            strcpy(amt_print,"");
            strcpy(str_ins_premium,"");
            ins_premium = 0;

            strncpy(stmp_ntype1, nins_type, 16);
            strncpy(stmp_ntype2, &nins_type[16], strlen(nins_type)-16);
            stmp_ntype1[16]='\0';
            stmp_ntype2[strlen(nins_type)-16]='\0';
            printf("stmp_ntype1=[%s],stmp_ntype2=[%s]\n",stmp_ntype1,stmp_ntype2);

            strncpy(stmp_mpad1, main_paid, 8);
            strncpy(stmp_mpad2, &main_paid[8], strlen(main_paid)-8);
            stmp_mpad1[8]='\0';
            stmp_mpad2[strlen(main_paid)-8]='\0';
            printf("stmp_mpad1=[%s],stmp_mpad2=[%s]\n",stmp_mpad1,stmp_mpad2);

            sprintf(cover_print,"�̰�%s",str_cover1);
            insert_prt_table(ipolicy,iins_type,stmp_ntype1,stmp_mpad1,cover_print,amt_print,str_deduct,str_ins_premium,
                             ins_premium);

            strcpy(cover_print,"");
            sprintf(cover_print,"�O�������Ѩ����ΨC��");
            insert_prt_table(ipolicy,iins_type,stmp_ntype1,stmp_mpad1,cover_print,amt_print,str_deduct,str_ins_premium,
                             ins_premium);
            
            strcpy(cover_print,"");
            sprintf(cover_print,"%s���G�̦X�p�̰�%s ",str_cover2,str_cover1);
            insert_prt_table(ipolicy,iins_type,stmp_ntype2,stmp_mpad2,cover_print,amt_print,"",str_ins_premium,
                              ins_premium);

        }
        else if (strcmp(iins_type, "154") == 0 || strcmp(iins_type, "155") == 0 || strcmp(iins_type, "156") == 0)
        {
            sprintf(cover_print,"�O�������Ѩ����ΨC��%s���G�̦X�p�̰�%s ",str_cover2,str_cover1);
            insert_prt_table(ipolicy,iins_type,nins_type,main_paid,cover_print,amt_print,str_deduct,str_ins_premium,
                             ins_premium);
        }
        else if (strcmp(iins_type, "237") == 0)
        {
        	 /* ���I�ئW�٩�G��  modify by sylvia 102.10.23 ---------------------------------------------- */
            strcpy(nins_type, rtrim(nins_type));
            printf("----- 1892 iins_type=[%s] nins_type=[%s][%D]--- \n",iins_type,nins_type,strlen(nins_type));
            if (strlen(nins_type) > 16)
            {
                nins_type_len = cc_split_chinese(nins_type,nins_type_split,16);
                strcpy(nins_type_split, rtrim(nins_type_split));
	         	strncpy(stmp_ntype1, nins_type_split, 16);
	         	strncpy(stmp_ntype2, &nins_type[16], strlen(nins_type)-16);
	         	stmp_ntype1[16]='\0';
	         	stmp_ntype2[strlen(nins_type)-16]='\0';
	         	printf("stmp_ntype1=[%s],stmp_ntype2=[%s]\n",stmp_ntype1,stmp_ntype2);
            }
            else
            {
                strcpy(stmp_ntype1, nins_type);
         		strcpy(stmp_ntype2,"");
            }
            /* ���I�ئW�٩�G��  modify by sylvia 102.10.23 ---------------------------------------------- */
   
            strcpy(cover_print,"�C�@�ƬG");
            insert_prt_table(ipolicy,iins_type,stmp_ntype1,main_paid,cover_print,str_cover1,str_deduct,str_ins_premium,ins_premium);	
            strcpy(cover_print,"�O�I����");
            insert_prt_table(ipolicy," ",stmp_ntype2," ",cover_print,str_cover2," "," ",0);	
            
        }
        else if (strcmp(iins_type, "238") == 0)
        {
            /* ���I�ئW�٩�G��  modify by sylvia 102.10.23 ---------------------------------------------- */
            strcpy(nins_type, rtrim(nins_type));
            printf("----- 1892 iins_type=[%s] nins_type=[%s][%D]--- \n",iins_type,nins_type,strlen(nins_type));
            if (strlen(nins_type) > 16)
            {
                nins_type_len = cc_split_chinese(nins_type,nins_type_split,16);
                strcpy(nins_type_split, rtrim(nins_type_split));
         	strncpy(stmp_ntype1, nins_type_split, 16);
         	strncpy(stmp_ntype2, &nins_type[16], strlen(nins_type)-16);
         	stmp_ntype1[16]='\0';
         	stmp_ntype2[strlen(nins_type)-16]='\0';
         	printf("stmp_ntype1=[%s],stmp_ntype2=[%s]\n",stmp_ntype1,stmp_ntype2);
            }
            else
            {
                strcpy(stmp_ntype1, nins_type);
         	strcpy(stmp_ntype2,"");
            }
            /* ���I�ئW�٩�G��  modify by sylvia 102.10.23 ---------------------------------------------- */

            /* �D�n���I���ة�G��  modify by sylvia 102.10.23 ---------------------------------------------- */
            strcpy(main_paid, rtrim(main_paid));
            printf("----- 1892 iins_type=[%s] main_paid=[%s][%D]--- \n",iins_type,main_paid,strlen(main_paid));
            if (strlen(main_paid) > 14)
            {
                strncpy(stmp_mpad1, main_paid, 14);
         	strncpy(stmp_mpad2, &main_paid[14], strlen(main_paid)-14);
                stmp_mpad1[14]='\0';
                stmp_mpad2[strlen(main_paid)-14]='\0';
         	printf("stmp_mpad1=[%s],stmp_mpad2=[%s]\n",stmp_mpad1,stmp_mpad2);
            }
            else
            {
                strcpy(stmp_mpad1, main_paid);
         	strcpy(stmp_mpad2,"");
            }
            /* �D�n���I���ة�G��  modify by sylvia 102.10.23 ---------------------------------------------- */
         			
         			
            strcpy(cover_print,"�C�@�ƬG");
            insert_prt_table(ipolicy,iins_type,stmp_ntype1,stmp_mpad1,cover_print,str_cover1,str_deduct,str_ins_premium,
                             ins_premium);	
            strcpy(cover_print,"�O�I����");
            insert_prt_table(ipolicy," ",stmp_ntype2,stmp_mpad2,cover_print,str_cover2," "," ",0);	
            sprintf(cover_print,"��Q���{%s",str_cover4);
            insert_prt_table(ipolicy," ",cover_print," "," "," "," "," ",0);
        }
        /* �B�z�I�ئW�ٲ�16�r�����ת���m���O�@�ӧ��㪺����r�A�q��15�Ӧr���}�l��2��(1140507003_C01) */
        else if(strcmp(iins_type, "15") == 0 || strcmp(iins_type, "16") == 0 || strcmp(iins_type, "66") == 0 || strcmp(iins_type, "67") == 0)
        {
            /* ���I�ئW�٩�G�� */
            strcpy(nins_type, rtrim(nins_type));
            printf("----- 1892 iins_type=[%s] nins_type=[%s][%D]--- \n",iins_type,nins_type,strlen(nins_type));
            if (strlen(nins_type) > 15)
            {
                nins_type_len = cc_split_chinese(nins_type,nins_type_split,15);
                strcpy(nins_type_split, rtrim(nins_type_split));
         	    strncpy(stmp_ntype1, nins_type_split, 15);
         	    strncpy(stmp_ntype2, &nins_type[15], strlen(nins_type)-15);
         	    stmp_ntype1[15]='\0';
         	    stmp_ntype2[strlen(nins_type)-15]='\0';
         	    printf("stmp_ntype1=[%s],stmp_ntype2=[%s]\n",stmp_ntype1,stmp_ntype2);
            }
            else
            {
                strcpy(stmp_ntype1, nins_type);
         	    strcpy(stmp_ntype2,"");
            }
            /* ���I�ئW�٩�G��  */

            /* �D�n���I���ة�G��*/
            if (strlen(main_paid) > 14)
            {
                strncpy(stmp_mpad1, main_paid, 14);
         	    strncpy(stmp_mpad2, &main_paid[14], strlen(main_paid)-14);
         	    stmp_mpad1[14]='\0';
         	    stmp_mpad2[strlen(main_paid)-14]='\0';
         	    printf("stmp_mpad1=[%s],stmp_mpad2=[%s]\n",stmp_mpad1,stmp_mpad2);
            }
            else
            {
         	    strcpy(stmp_mpad1, main_paid);
         	    strcpy(stmp_mpad2,"");
            }
            /* �D�n���I���ة�G�� */            
            strcpy(amt_print,str_cover1);
            insert_prt_table(ipolicy,iins_type,stmp_ntype1,stmp_mpad1,cover_print,amt_print,str_deduct,str_ins_premium,
                ins_premium);            
            insert_prt_table(ipolicy," ",stmp_ntype2,stmp_mpad2," "," "," "," ",0);           
        }
        else
        {
            strcpy(cover_print,trim(cover_print));
            strcpy(amt_print,str_cover1);

            /* 119��121�I�ت��O�O�w�[�`�b118��120�I�� add by larry 103.08.05 (1030725001_C5) */
            /* 123�I�ثO�O�w�[�`�b122�I�ثO�O add by larry 103.08.12 (1030806001_C2)*/
            /* 139�I�ت��O�O�w�[�`�b138�I�� add by larry 104.05.21 (1040515009_C2) */
            /* �����¦����s�A�������I�����{���]�w(137�B138�B139�B141�B142�I��) (1100311005_SC6)*/
            if (strcmp(iins_type, "123") == 0)
            {
                strcpy(iins_type,"");
                strcpy(cover_print,"");
                strcpy(amt_print,"");
                sprintf(cover_print,"�O�������Ѩ����ΨC��%s���G�̦X�p�̰�%s ",str_cover2,str_cover1);
                strcpy(str_ins_premium,"");
                ins_premium = 0;
            }

            insert_prt_table(ipolicy,iins_type,nins_type,main_paid,cover_print,amt_print,str_deduct,str_ins_premium,
                             ins_premium);

            /* �P�_�O�_�L�X�Ұ���O��(only iins_type = '05','09','32' */
            if (strcmp(iins_type,"05") == 0  || strcmp(iins_type,"09") == 0  ||
                strcmp(iins_type,"32") == 0  || strcmp(iins_type,"125") == 0 ||
                strcmp(iins_type,"126") == 0 || strcmp(iins_type,"134") == 0 || 
                strcmp(iins_type,"205") == 0 || strcmp(iins_type,"209") == 0)
            {
                /* if(strcmp(trim(provision),"H")==0) */
                if(strstr(trim(provision),"H;") != NULL)
                {
                    strcpy(nins_type,"�i�Ұ���O�١j");
                    insert_prt_table(ipolicy,"",nins_type,"","","","","", 0);
                }
            }

            /* �P�_�O�_�L�X���w�r�p�H add by sylvia 101.06.21 */
            if(strstr(trim(provision),"D;") != NULL)
            {
                if (strcmp(iins_type,"07") != 0)
                {
                    strcpy(nins_type,"�i���w�r�p�H�j");
                    insert_prt_table(ipolicy,"",nins_type,"","","","","", 0);
                    printf("---- 1876---iins_type=[%s]provision=[%s]\n",iins_type,provision);                     	
                }

            }
                 
            if(strstr(trim(provision),"J;") != NULL)
            {
                provision_J = 1;
                strcpy(nins_type,"�i�S�w�γ~�[�T�w�ϥΤH�j");
                insert_prt_table(ipolicy,"",nins_type,"","","","","", 0);
                printf("---- 1876---iins_type=[%s]provision=[%s]\n",iins_type,provision);
            }
        }
        /*======== ��������������  �H�W�B�z�O�B�C�L  �������������� ========*/
        /*======================================================================*/



        /*======================================================================*/
        /* �P�_�O�_�L�X���������[���� add by �L�� 104.11.25 */
        if(strstr(trim(provision),"S;") != NULL)
        {
            if(strcmp(iins_type, "07") != 0 && strcmp(iins_type, "10") != 0 && strcmp(iins_type, "127") != 0)
            {
                strcpy(nins_type,"���������[����");
         	insert_prt_table(ipolicy,"",nins_type,"","","","","", 0);
         	printf("----2526---iins_type=[%s]provision=[%s]\n",iins_type,provision);
            }
        }
        /*======================================================================*/
         
         
         
        /*======================================================================*/ 
        /*======== ��������������  �H�U�B�z���[���ڵ��O  �������������� ========*/
        
        if(strstr(trim(provision),"X;") != NULL)
	{
            provision_X = 1;
            strcpy(nprov_X,"���O���O�i�O�I�����ܧ�Τ��~�פ���[���ڡj(X)");
            printf("---- 1781---iins_type=[%s]provision=[%s]\n",iins_type,provision);
	}
	/* 1071226006_SC4_�w���ƫ����վ�(���²v+�ĤT�H�d��) */
	if(strstr(trim(provision),"P;") != NULL)
	{
	    /* �u�w��D�I01�B05�B09�B11�P�_����P�BQ���ڴ��� */
	    if (strcmp(iins_type, "01") == 0  || strcmp(iins_type, "05") == 0  || strcmp(iins_type, "09") == 0  || strcmp(iins_type, "11") == 0 ||
	        strcmp(iins_type, "201") == 0 || strcmp(iins_type, "205") == 0 || strcmp(iins_type, "209") == 0 || strcmp(iins_type, "211") == 0)
	    {
        	provision_P = 1;
            	printf("---- 2936---iins_type=[%s]provision=[%s]\n",iins_type,provision);
            }
            else 
             	printf("Do Nothing \n");
	}
	 
	if(strstr(trim(provision),"Q;") != NULL)
	{
	    /* �u�w��D�I01�B05�B09�B11�P�_����P�BQ���ڴ��� */
	    if (strcmp(iins_type, "01") == 0  || strcmp(iins_type, "05") == 0  || strcmp(iins_type, "09") == 0  || strcmp(iins_type, "11") == 0 ||
	        strcmp(iins_type, "201") == 0 || strcmp(iins_type, "205") == 0 || strcmp(iins_type, "209") == 0 || strcmp(iins_type, "211") == 0)
	    {
        	provision_Q = 1;
            	printf("---- 2947---iins_type=[%s]provision=[%s]\n",iins_type,provision);
            }
            else 
             	printf("Do Nothing \n");
	}
	 
	if(strstr(trim(provision),"M;") != NULL)
	{
	    /* �u�w��D�I01�B05�B09�B11�P�_���� M ���ڴ��� */
	    if (strcmp(iins_type, "01") == 0  || strcmp(iins_type, "05") == 0  || strcmp(iins_type, "09") == 0  || strcmp(iins_type, "11") == 0 || strcmp(iins_type, "181") == 0 ||
	        strcmp(iins_type, "201") == 0 || strcmp(iins_type, "205") == 0 || strcmp(iins_type, "209") == 0 || strcmp(iins_type, "211") == 0)
	    {
        	provision_M = 1;
            	printf("---- 2947---iins_type=[%s]provision=[%s]\n",iins_type,provision);
            }
            else 
             	printf("Do Nothing \n");
	}
	
	if(strstr(trim(provision),"Y;") != NULL)
	{
	    /* 1130827011_C04_�s�W�s�t��W�B���[����(Y)(�L��) */
	    if (strcmp(iins_type, "01") == 0  || strcmp(iins_type, "05") == 0  || strcmp(iins_type, "09") == 0  || strcmp(iins_type, "11") == 0 || strcmp(iins_type, "198") == 0 ||
	        strcmp(iins_type, "201") == 0 || strcmp(iins_type, "205") == 0 || strcmp(iins_type, "209") == 0 || strcmp(iins_type, "211") == 0)
	    {
        	provision_Y = 1;
            	printf("---- 2947---iins_type=[%s]provision=[%s]\n",iins_type,provision);
            }
            else 
             	printf("Do Nothing \n");
	}
	 
	if(strstr(trim(provision),"V;") != NULL)
	{
	    /* �w��09�B31�B32�P�_�ۭt�B���[���� */
            provision_V = 1;
            if(strcmp(iins_type, "09") == 0 || strcmp(iins_type, "209") == 0)  
                cnt_V09 = 1;
            if(strcmp(iins_type, "31") == 0 || strcmp(iins_type, "32") == 0 || strcmp(iins_type, "231") == 0 || strcmp(iins_type, "232") == 0) 
                cnt_V3132 = 1;
            printf("---- 2957---iins_type=[%s]provision=[%s]\n",iins_type,provision);
	}
	 
	if(strstr(trim(provision),"K;") != NULL)
	{
	    /* 1080225007_SC4_�s�W�r�˰ӫ~ */
            provision_K = 1;
            printf("---- 2957---iins_type=[%s]provision=[%s]\n",iins_type,provision);
	}
	 
        if(strstr(trim(provision),"U;") != NULL)
	{
	    provision_U = 1;
	    printf("---- 1781---iins_type=[%s]provision=[%s]\n",iins_type,provision);
	}
	 
	if(strstr(trim(provision),"L;") != NULL)
	{
	    /* 1080708002_SC4_�s�W�����������(�N��L)  */
	    provision_L = 1;
	    strcpy(nprov_L,"�i���O����[������~�γ~���[���ڡj");
	    printf("---- 3125---iins_type=[%s]provision=[%s]\n",iins_type,provision);
	}
	
	/*======== ��������������  �H�W�B�z���[���ڵ��O  �������������� ========*/
	/*======================================================================*/  
	 
		 	    
    } /* end of Ū���I�� */
    $CLOSE curh;



    /* �O�O�����O�B���s���I�ثO�O */
    /* �O�B=0,�O�O!=0,�����C�L mark by sylvia 101.10.08 (1010928006_C1) */
    /* premium1 = premium1 - deduct_prem; */



    /*======================================================================*/
    /* �Y��56.136�I��,�hŪ���X�Q�O�I�H�W�U������� */
    /* 166�I�حn�L�W�U (1090921003_SC1) */
    printf("list_print 0:�C�L 1:���L[%d]\n",list_print);
    if (ins_56 == 1 && list_print == 0)
    {
        sprintf(stmt,"SELECT iins_type,iinsurant,ninsurant,dbirth,nbeneficiary,relation_bene,tbenef,abenef \
                        FROM %s \
                       WHERE ipolicy = '%s' \
                         AND iins_type in ('56','136','166','266') \
                         AND mins_amt > 0 \
                       union \
                       SELECT iins_type,iassured,nassured,dbirth,nbenef,rel_benef,tbenef,abenef \
		                 FROM %s \
		                WHERE ipolicy = '%s' \
		                  AND iins_type in ('147','561') ;",tablePaPly,ipolicy,tableAssured,ipolicy);
                          

        $PREPARE pa_ply FROM $stmt;
        $DECLARE ca_cur CURSOR FOR pa_ply;
        j = 0;
        
        $OPEN ca_cur;
        while(1)
        {
            
            $FETCH ca_cur INTO $iins_type56,$iinsurant56,$ninsurant56,$dbirth56,$nbeneficiary56,$relation_bene56,$tbenef56,$abenef56;
            if (SQLCODE == SQLNOTFOUND) 
            {
                line66 = 1;  /* line66 and line67�O�ӽT�{�Q�O�I�H�W�U�O�_�ݭn�C�L */
                line67 = 1;
                list_cnt = 1;
                break;
            }

            $INSERT INTO tbl_56list (ipolicy,iins_type,iinsurant,ninsurant,dbirth,nbeneficiary,relation_bene,tbenef,abenef) 
                  VALUES ($ipolicy,$iins_type56,$iinsurant56,$ninsurant56,$dbirth56,$nbeneficiary56,$relation_bene56,$tbenef56,$abenef56);


        }
        $CLOSE ca_cur;
        $FREE ca_cur;
    }
    else
    {
        /* ���L��ơA�u�L���廡�� */
        line66 = 1;
        line67 = 1;
        list_cnt = 1;
    }
    /* end of Ū��56 */
    /*======================================================================*/
    
    
    
    /*======================================================================*/
    /* 31,32�P�ɩӫO��,�Y���T���h���O�ٮ�,�[�L"�T���h���O��"�b31�I�ؤ��� */
    if (ins_31 == 1 && ins_32 == 1)
    {
        if (ins_31_multiple > 2)
    	{
    	    strcpy(tmp3132,"�T���h���O��");

    	    $SELECT MIN(line_no) INTO $line_no FROM tbl_print WHERE ipolicy = $ipolicy AND field1 in ('31','36','231');
                
            if (line_no > 0)
            {
    	        $SELECT field2 INTO $tmpfield2 FROM tbl_print WHERE ipolicy = $ipolicy AND line_no = $line_no + 1;    
    	 	strcpy(tmpfield2,trim(tmpfield2));  
    	 	strcat(tmpfield2,tmp3132);      	
    	        $UPDATE tbl_print
    	            SET field2 = $tmpfield2
    	          WHERE ipolicy = $ipolicy AND line_no = $line_no + 1;
    	        strcpy(tmpfield2,""); 
    	    }
        }
    }
    /*======================================================================*/
    
    
    
    
    printf("0170: before select mprem\n");
    sprintf(stmt,"SELECT SUM(mprem) \
                    FROM %s \
                   WHERE ipolicy = '%s';", tableInsType, ipolicy);
    printf("stmt[%s]\n", stmt);
    $PREPARE plyins_cur1 FROM $stmt;
    $DECLARE prem_cur1 CURSOR FOR plyins_cur1;
    $OPEN prem_cur1;
    $FETCH prem_cur1 INTO $old_premium;
    $CLOSE prem_cur1;
    $FREE  prem_cur1;

    if ( ins_17 == 0 || ins_17 == 2)
    {
        printf("***********************17�I�ؤ��C�L���O���O ******************************\n");
        premium1 = premium1 - premium_17;
        old_premium = old_premium - old_premium_17;
        mdiscount = mdiscount - mdiscount_17;
    } 
    else
    {
    	/* ���ӫO11�I�إH��17�I��,17�I�ؤ��C�L */
    	/*if (ins_11 == 1)
    	$DELETE FROM tbl_print WHERE ipolicy = $ipolicy AND field1 = '17';*/
    }

    /* �M�ץ�O�椣�C�L19�I�� add by larry 102.12.16 (1021122001_C3) */
    if (strncmp(sIpolicyB_type,"1",1) == 0)
    {
        if ( ins_19 == 0 || ins_19 == 2)
        {
            premium1 = premium1 - premium_7h_19;
            old_premium = old_premium - old_premium_7h_19;
            mdiscount = mdiscount - mdiscount_7h_19;
        }
    }

    /*�C�M�ᨮ�ߨ����O*/
    if (equip_cmp(nequipment,"5") == TRUE)
    {
        strcpy(nequipment_7h,"1");
    }
    else
    {
        strcpy(nequipment_7h,"0");
    }

    strcpy(iofficer_7h,substring(iofficer,1,3));
    printf("0180: nequipment_7h:[%s],iofficer_7h:[%s], ins_14[%d]\n",nequipment_7h,iofficer_7h, ins_14);

    if ( strcmp(nequipment_7h,"1")==0 && strncmp(sIpolicyB_type,"0",1) == 0 )
    {
        if ( ins_14 == 0 || ins_14 == 2)
        {
            premium1 = premium1 - premium_7h_14;
            old_premium = old_premium - old_premium_7h_14;
            mdiscount = mdiscount - mdiscount_7h_14;
        }
        
        if ( ins_19 == 0 || ins_19 == 2)
        {
            premium1 = premium1 - premium_7h_19;
            old_premium = old_premium - old_premium_7h_19;
            mdiscount = mdiscount - mdiscount_7h_19;
        }
        
        /*1100624009_SC1_�w��30�I�ۭt�B(���t55)����r��������*/
        /*if ( ! ins_51)
        {
            strcpy(ps_dtl,"");
        }*/
    }

    /* �ӫO�W�B�d���I�����ӫO�I��31��32�ɡA����C�L�����T��
    printf("0190: flag_29[%s],flag_31[%s],flag_32[%s]\n",flag_29_exist,flag_31_exist,flag_32_exist);
    if (strcmp(flag_29_exist,"Y")==0 &&
        strcmp(flag_31_exist,"N")==0 &&
        strcmp(flag_32_exist,"N")==0)
    {
         strcpy (Str29_1,"�����w�t��O�ĤT�H�d���I�A�O�B");
         sprintf(Str29_2,"���C�@�H�ˮ`NT$%s�U;�C�@�ƬG�ˮ`",sCoverage1);
         sprintf(Str29_3,"NT$%s�U;�C�@�ƬG�]�lNT$%s�U�C",sCoverage2,sCoverage3);
         strcpy(s_note,trim(Str29_1));
         strcat(s_note,trim(Str29_2));
         strcat(s_note,trim(Str29_3));
    } else  */ 
    strcpy(s_note," ");

    strcpy(datestr,cm_cdate_str_100(dply_begin));
    cm_split_ymd_100(datestr,yy3,mm3,dd3);

    strcpy(datestr,cm_cdate_str_100(dply_end));
    cm_split_ymd_100(datestr,yy4,mm4,dd4);

    strcpy(s_premium1,refmtamt(premium1,MILLIONTH));

    /* 1040706002_C1_���O�X��1%���u�馩�� */
    mdisc=0.0;

    if (strlen(trim(ipolicy)) > 13)
    {
        strncpy(sIpolicy1, ipolicy, 13);
        sIpolicy1[13] = '\0';
        strncpy(sIpolicy2, ipolicy+13, 4);
        sIpolicy2[20] = '\0';
        if (sIpolicy2[0]=='\0' || sIpolicy2[0]==' ') 
            strcpy(sIpolicy2," ");
    }
    else
    {
        strcpy(sIpolicy1,ipolicy);
        strcpy(sIpolicy2," ");
    }

    $SELECT nvl(sum(pay_mnt),0.0)  Into $mdisc
       FROM ao_reward_policy
      WHERE ipolicy1 = $sIpolicy1
	AND ipolicy2 = $sIpolicy2;


    strcpy(bak1_ply,refmtamt(premium1,MILLIONTH));   /* for �`�O�I�O    */

    if ( mpure_prem != 0 )
    {
        real_premium=premium1 + prem21 - (long)mdisc;      /* �X�p�O�O*/
        real1_premium=premium1 + mdiscount - (long)mdisc;  /* ���N�O�O*/

        strcpy(bak1,refmtamt(premium1- (long)mdisc,MILLIONTH));       /*����*/
        strcpy(bak3,refmtamt(real1_premium,MILLIONTH));  /*�O�Ototal*/
        strcpy(bak31,refmtamt(real_premium,MILLIONTH));  /*�X�p*/
        strcpy(bak2,refmtamt(mdiscount,MILLIONTH));      /*�u�f*/

        rate = (float)mdiscount / (float)( premium1 + mdiscount ) * 100  + 0.5;
    }
    else
    {
        real_premium=premium1 + prem21 - mdiscount - (long)mdisc;
        real1_premium=premium1 - mdiscount - (long)mdisc;

        strcpy(bak3,refmtamt(premium1- (long)mdisc,MILLIONTH));       /*�O�Ototal*/
        strcpy(bak1,refmtamt(real1_premium,MILLIONTH));  /*�ꦬ*/
        strcpy(bak31,refmtamt(real_premium,MILLIONTH));  /*�X�p*/
        strcpy(bak2,refmtamt(mdiscount,MILLIONTH));      /*�u�f*/

        rate = (float) mdiscount / (float) premium1 * 100 + 0.5;
    }

    if (mdiscount<=0)
    {
        /*sprintf(s0_real_premium,"                               %s", bak1); */ /*�`�O�I�O    */
        sprintf(s0_real_premium,"                               %s", bak1_ply);  /*�`�O�I�O    */
        sprintf(s_real_premium,"���N�O�O %s  "                       , bak3);  /*�b��Ĥ@��  */
        sprintf(s1_real_premium,"�O�O %s "                           , bak3);  /*���ڲĤ@��  */
    }
    else
    {
        strcpy(iassured, trim(iassured));
        if( (strcmp(iassured,"23528130")==0) || (strcmp(iassured,"16091337")==0) ||
            (strcmp(iassured,"70462172")==0) || (strcmp(iassured,"80521360")==0) ||
            (strcmp(iassured,"16097233")==0) || (strcmp(ikind,"2")==0))
        {   /** car-9405172 �������̲νs�P�_���L�X�u�f�r�� **/
            sprintf(s0_real_premium,"                                 %s", bak1);           /*�`�O�I�O    */
            sprintf(s_real_premium,"���N�O�O %s"   , bak1); /*�b��Ĥ@��  */
            sprintf(s1_real_premium,"�O�O %s"      , bak1); /*���ڲĤ@��  */
        }
        else
        {
            /*sprintf(s0_real_premium,"�����O��w�ɦ��O�O�u�f�� %s", bak1);*/           /*�`�O�I�O    */
            sprintf(s0_real_premium,"�����O��w�ɦ��O�O�u�f�� %s", bak1_ply);           /*�`�O�I�O    */
            sprintf(s_real_premium,"���N�O�O %s �u�f %s ���N�ꦬ %s"   , bak3,bak2,bak1); /*�b��Ĥ@��  */
            sprintf(s1_real_premium,"�O�O %s  �u�f %s  �ꦬ %s"          , bak3,bak2,bak1); /*���ڲĤ@��  */
        }
    }

    sprintf(s2_real_premium,"%s  �X�p�O�O %s",
    s_prem21,bak31);                                     /*�b��ĤG��  */
    strcpy(s2_real_premium,ltrim(s2_real_premium));
    num_to_chinese(bak_chiness,real_premium);            /*�Ĥ@�p���B����j�g  */
    strcpy(bak_chiness,trim(bak_chiness));
    strcat(bak_chiness,"����");

    if(strncmp(ibroker,"ZZZZZ",5)==0)
    {
        strcpy(new_ibroker,ibroker);
        strcpy(dsc_ibroker,"������O����");
    }
    else
    {
        strcpy(new_ibroker,ibroker);
        strcpy(dsc_ibroker," ");
    }

    if (plia_align==0) 
        s_lia_align[0]='\0';
    else 
        sprintf(s_lia_align, "%d", plia_align);

    /* car9803242 */
    /* �Y�O�����~��(policy.iextra_charge = '40')�H�ο�ܦ��u�f,�C�ܥXdirect_disc_98�����e */
    if (strncmp(iextra_charge,"40",2) == 0 && strncmp(sIkind,"1",1) == 0)
    {
    	strcat(s_real_premium,direct_disc_98);
    	strcat(s1_real_premium,direct_disc_98);
    }

    /* �����w�r�p�H�W�U add by sylvia 101.06.22 */
    if (iQprovision > 0 || provision_J == 1)
    {
        printf("2808\n");
   	strcpy(sTmpIassured, " ");
   	strcpy(sTmpIassured1, " ");
   	strcpy(sTmpNiassured, " ");
   	strcpy(sTmpDbirth, " ");
   	strcpy(sTmpDbirth1, " ");
   	strcpy(sTmpDbirth_yy, " ");
   	strcpy(sTmpDbirth_mm, " ");
   	strcpy(sTmpDbirth_dd, " ");

   	if(provision_J == 1)
   		strcpy(sProvD,"�S�w�γ~�[�T�w�ϥΤH�ӫ~�ΦW�U:");
   	else
   		strcpy(sProvD,"���w�r�p�H�ӫ~�ΦW�U:");

   	strcpy(sProvD_1," ");
   	strcpy(sProvD_2," ");

   	iCounD = 0;
   	ninsD_cnt = 0;
   	$DECLARE cur_provd CURSOR for
   	SELECT trim(a.iins_type)||(SELECT nins_abbr FROM insurance_type WHERE iins_type = a.iins_type),
   	       (SELECT count(*) FROM ply_ins_type WHERE ipolicy = a.ipolicy AND (trim(nvl(provision,' '))||';' like '%D;%' OR trim(nvl(provision,' '))||';' like '%J;%'))
	  FROM ply_ins_type a
	 WHERE a.ipolicy = $ipolicy
	   AND (trim(nvl(a.provision,' '))||';' like '%D;%' or trim(nvl(a.provision,' '))||';' like '%J;%')
	 GROUP BY 1,2;
      	$OPEN cur_provd;
	while (1)
      	{

	    $FETCH cur_provd INTO $ninsType,$ninsD_cnt;
	    
	    if (SQLCODE == SQLNOTFOUND) break;
	    
	    iCounD ++;
	    
	    strcat(sProvD, rtrim(ninsType));
	    
	    if (iCounD < ninsD_cnt)
	        strcat(sProvD, "�B");
            else
		strcat(sProvD, "�C");
      	}

   	iCounD = 0;
   	ninsD_cnt = 0;
   	$DECLARE cur_provd1 CURSOR for
	SELECT iassured, nassured,year(dbirth)-1911||to_char(dbirth,'/%m/%d'),
	       (SELECT count(*) FROM ply_ins_assured WHERE ipolicy = a.ipolicy AND (trim(nvl(provision,' '))||';' like '%D;%' OR trim(nvl(provision,' '))||';' like '%J;%'))
	  FROM ply_ins_assured a
	 WHERE ipolicy = $ipolicy
	   AND (trim(nvl(provision,' '))||';' like '%D;%' or trim(nvl(provision,' '))||';' like '%J;%')
	 GROUP BY 1,2,3,4;
      	$OPEN cur_provd1;
	while (1)
      	{
	    $FETCH cur_provd1 INTO $sTmpIassured1,$sTmpNiassured,$sTmpDbirth1,$ninsD_cnt;
		
	    if (SQLCODE == SQLNOTFOUND) break;
	    
            printf("2854---iCounD[%d]\n",iCounD);		
	    iCounD ++;
	    /* �Q�O�I�H�Ӹ�B�n */
	    if (strncmp(sProtectData,"0",1) != 0)
	    {
			
	        strcpy(sTmpIassured,substring(sTmpIassured1,1,4));
    		strcat(sTmpIassured,"****");
    		strcat(sTmpIassured,substring(sTmpIassured1,9,2));
    		cm_char_split_3ymd(sTmpDbirth1, sTmpDbirth_yy, sTmpDbirth_mm, sTmpDbirth_dd);
    		strcpy(sTmpDbirth_yy,trim(sTmpDbirth_yy));
    		sprintf(sTmpDbirth,"***/%s/*%s",sTmpDbirth_mm,substring(sTmpDbirth_dd,2,2));

	    }
	    else
            {
		strcpy(sTmpIassured,trim(sTmpIassured1));
		strcpy(sTmpDbirth,trim(sTmpDbirth1));
	    }
		
	    if (iCounD <= 2)
            {
		strcat(sProvD_1, rtrim(sTmpIassured));
		strcat(sProvD_1, " ");
		strcat(sProvD_1, rtrim(sTmpNiassured));
		strcat(sProvD_1, " ");
		strcat(sProvD_1, rtrim(sTmpDbirth));
		if (iCounD == 1 && ninsD_cnt >= 2)
		    strcat(sProvD_1, "�B");
	    }
	    else
	    {
		strcat(sProvD_2, rtrim(sTmpIassured));
		strcat(sProvD_2, " ");
		strcat(sProvD_2, rtrim(sTmpNiassured));
		strcat(sProvD_2, " ");
		strcat(sProvD_2, rtrim(sTmpDbirth));
		if (iCounD == 3 && ninsD_cnt >= 4)
		    strcat(sProvD_2, "�B");
	    }
            printf("2876---iCounD[%d]ninsD_cnt[%d]\n",iCounD,ninsD_cnt);
      	}
    }
   
    /* 1071107007_SC2_UBI�{���W�u */
    if(provision_U == 1)
        strcpy(sProvD,"�i���O����[UBI���ڡj");

    /* �C�L�t�ƪ��B (1031014003_C1) */
    if (mequipment > 0)
    {
        sprintf(sMequipment,"�t�ƪ��B(�w�]�t�b����/�ѵs�O�I���B��)�G%4.1f�U",mequipment);
        strcpy(sProvD,trim(sProvD));
        if(strlen(sProvD) == 0)
            strcpy(sProvD,trim(sMequipment));
        else
      	    strcat(sProvD,trim(sMequipment));
    }


    printf("end of getdata\n\n");

    return M_CM_OK;
    
errexit:
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    return SQLCODE;
}

/*--------------------------------------------------------------------*/
long ca_rpt(bigply_flag, ibatch_no, iprint, Ireceipt2)
int bigply_flag;
$int ibatch_no;
$char iprint[11];
$char Ireceipt2[11];
{
    $double p_no = 0;
    $char p_iins_type[7],p_nins_type[17],p_main_paid[17],p_qcoverage[21],p_qcoverage_amt[11];
    $char p_deduct[13],p_mpremium[14], sIpolicyTmp[21],p_field_tmp[38];
    int i,j,ben_len=0,len=0,ben_len_t=0,x;
    char tmp_address[100];
    char tmp_nassured[200],tmp_nassured_t[200];
    char tmp_nassured1[63],tmp_nassured1_t[63];
    char tmp_nassured2[63],tmp_nassured2_t[63];
    char tmp_nassured3[19], tmp_nassured4[63], tmp_nassured4_t[63],tmp_nassurC[29];
    char tmp_napplicant[200],tmp_napplicant_t[200],tmp_napplicant1[63];
    char nbenef_f[2];
    char sTmpbuf1[11],sTmpbuf2[11],sTmpbuf3[11],sTmpbuf4[12];
    char tax_area1[3];
    char tax_area2[3];
    char print_premium[200];
    char s_mcar_price[8];
    char str_dbirth[10], sTmp[250], sTmp1[250], sTmpPsexAge[34];
    int iins_cnt=0;     /* �ΨӧP�_�I�جO�_���L��,�L����iins_cnt = 1, �L�����h��0 */
    long sum_ins_premium;
    char tmp_575960[40];
    char tmpNameDrate[16];
    char tmpstr_print[38];
    char str_print[38];
    char s_Nassured[101], s_Napplicant[101], sNapp1[122], sNass1[122];
    int  iTmp1;
    $int  chk_finvalid;
    $char sTmpsql[1200];
    $char tmp_acc[40];/* 1051214006_C2_�]���D�޾������ܤ����X�W���l�I�U�[�ΰӫ~�s�W�����ܧ�O�v�ץ� */
    
    int tok=4;
    /* ���ڽs�� */
    $char sToday1[11],sToday2[11],ireceipt[11],idb[3], iversion[2], stmpx[2000];
    $int res;
    $varchar ntarget2[121];

    $int cnt_ncont,cnt_ncont2;
    $char ncont1_1[81],ncont1_2[81],ncont2_1[81],ncont2_2[81],stmt_ncont[512];
	
    $int cnt_receipt,prem_receipt,receipt_print;
    $char tmp_receipt[11],receipt_dbegin[11],receipt_dend[11],receipt_nassured[101],receipt_napplicant[101];
    $char receipt_dbegin_100[11],receipt_dend_100[11];
    $long i_rebegin=0,i_reend=0;

    $WHENEVER SQLERROR GOTO errexit;

    tmpNameDrate[0] = '\0';
    strcpy(stmp_space, " ");



    /*======== ��������������  �H�U�P�_�O�_�����ڽs���άO�_�C�L����  �������������� ========*/
    /*=====       bufa_print (0:�n�����ڽs�� 1:�������ڽs��)             =====*/
    /*=====       receipt_print (0:���C�L���ڽs�� 1:�C�L���ڽs��)        =====*/
    /*=====       bufa_print2 (0:���C�L�ɵo�r�� 1:�C�L�ɵo�r��)          =====*/

    /* 1060818001_C1_cmn134a-���I */
    bufa_print = 0;
    receipt_print = 0;
    bufa_print2 = 1;
    
    printf("reprint[%s]\n",reprint);
    if(strcmp(reprint,"0") == 0) 
        bufa_print2 = 0;
    printf("bufa_print2[%d]\n",bufa_print2);
    
    if(strcmp(reprint,"�ɵo") == 0 || strcmp(reprint,"0") == 0)
    {
        printf("X1\n");
	bufa_print = 1;
	cnt_receipt = 0;
	chk_finvalid = 0;

	/*$SELECT count(*)
             INTO $cnt_receipt
	     FROM cm_receipt_log_dtl a ,cm_receipt_log b
            WHERE a.ireceipt = b.ireceipt
	      AND a.ipolicy = $ipolicy
              AND b.finvalid = 0;*/
		
	/* ���o���@�o���ڵ��� : cnt_receipt*/	
	$SELECT count(*)
	   INTO $cnt_receipt
           FROM cm_receipt_log
          WHERE ireceipt IN (SELECT ireceipt FROM cm_receipt_log_dtl WHERE ipolicy = $ipolicy)
            AND finvalid = 0;
            
	if(bufa_ins_17 == 1 || bufa_ins_19 == 1)
	{
	    bufa_print = 0;
	    bufa_ins_17 = 0;
	    bufa_ins_19 = 0;
	}
	else if ( iofficer[0] == 'A' || iofficer[0] == 'B' || iofficer[0] == 'J' || strncmp(sIpolicyB_type,"1",1) == 0 )
	{
	    /*�M�ץ�*/
	    /*�P�_��l�O�榬�ڬO�_�Ҥw�@�o*/
	    $SELECT count(*)
	       INTO $chk_finvalid
               FROM cm_receipt_log
              WHERE ireceipt IN (SELECT ireceipt FROM cm_receipt_log_dtl WHERE ipolicy = $ipolicy AND iendorse='' AND ireceipt[4]!='9')
                AND finvalid = 0;
			
	    if(chk_finvalid==0)
	    {
	        bufa_print = 0;
	    }
	    else
	    {
		receipt_print = 0;
	    }
					
	}
	else
	{
	    if(cnt_receipt == 0 )  /*�N�����ڳ��w�g���o  �ݭn�����@�Ӧ��ڨæL�X*/
	    {
	        bufa_print = 0;
	    }
	    else if(cnt_receipt == 1 )  /*�Y���ڥu���@��  �����B�B�O���B�n�Q�O�H����W�١A�Y�ҬۦP�h�L�X�����ڽs��*/
	    {
		prem_receipt = 0;
		$SELECT mprem_cur,ireceipt,dbegin,dend,nassured,napplicant
		   INTO $prem_receipt,$tmp_receipt,$receipt_dbegin,$receipt_dend,$receipt_nassured,$receipt_napplicant
		   FROM cm_receipt_log
	          WHERE ipolicy =  $ipolicy
		    AND finvalid = 0;
			
		if(SQLCODE == SQLNOTFOUND) 
		    receipt_print = 0;		
		else
		{
		    printf("prem_receipt[%d] premium1[%d] \n",prem_receipt,premium1);
					
		    strcpy(receipt_dbegin_100,cm_from_infdate_100(receipt_dbegin));
		    i_rebegin = cm_ymd_cdate(receipt_dbegin_100);
		    strcpy(receipt_dend_100,cm_from_infdate_100(receipt_dend));
		    i_reend = cm_ymd_cdate(receipt_dend_100);
		    printf("3331\n");
					
		    printf("i_rebegin[%d] i_reend[%d] \n",i_rebegin,i_reend);
		    printf("i_begin[%d] i_end[%d] \n",i_begin,i_end);
		    strcpy(nassured,rtrim(nassured));
		    strcpy(napplicant,rtrim(napplicant));
		    strcpy(receipt_nassured,rtrim(receipt_nassured));
		    strcpy(receipt_napplicant,rtrim(receipt_napplicant));
		    printf("nassured[%s] napplicant[%s] \n",nassured,napplicant);
		    printf("receipt_nassured[%s] receipt_napplicant[%s] \n",receipt_nassured,receipt_napplicant);
					
		    if(ireceipt[3] == "9")  /*��}����(�ĥ|�X��9) �]�n��ܦ��ڤw�}��*/
		    {
			receipt_print = 0; 
		    }
		    else if((premium1 == prem_receipt) && (i_rebegin == i_begin) && (i_reend == i_end) && (strcmp(receipt_nassured,nassured)==0) && (strcmp(receipt_napplicant,napplicant)==0) ) 
		    {
		    	/*���B�B�O���B�n�Q�O�H����W�٬ҬۦP�h�C�L�L�L�����ڽs��*/
			receipt_print = 1;
			strcpy(ireceipt,tmp_receipt);
		    }
		    else 
		        receipt_print = 0; 
		}
	    }
	    else 
	    {
		/*�Y���ŦX�W�z����h�k�䦬�ڤ��C�L ��ܦ��ڤw�}��*/
		receipt_print = 0;
	    }
	}
	
        if(receipt_print == 0) 
            strcpy(ireceipt," ");
        
    }
	
    if(bufa_print == 0)
    {
        /* �����ڽs�� add by sylvia 100.05.19 */
	strcpy(sToday1,cm_edate_str(cm_today()));
	strcpy(sToday2, cm_cdate_str_100(cm_today()));
	int iTryCnt;
	iTryCnt =0;
	    
	strcpy(Ireceipt_2,Ireceipt2);
	printf("2+++++Ireceipt_2[%s]\n",Ireceipt_2);
	    
	strcpy(Ireceipt_2,trim(Ireceipt_2));
	
	RETRY:
	    if(strlen(Ireceipt_2)==0)
	    {
	        res = cm_get_serial_num_dwritten("CM","R1","0","00",sToday1,sToday2,ireceipt);
	
	        if (res != 0) {
	            iTryCnt++;
	            if (iTryCnt > 3)  return res;
	            sleep(1);
	            goto  RETRY;
	        }
	
	        printf("res=[%d]sToday1=[%s]sToday2=[%s]ireceipt=[%s]\n",res,sToday1,sToday2,ireceipt);
	    }
	    else 
	        strcpy(ireceipt,Ireceipt_2);
	        
	    strcpy(ireceipt,trim(ireceipt));
    }

    /*======== ��������������  �H�W�P�_�O�_�����ڽs���άO�_�C�L����  �������������� ========*/

    printf("in ca_rpt\n");
    
    
    
    /********************************/
    /**                            **/
    /**  �O��e�q�D�n��T�C�L�϶�  **/
    /**                            **/
    /********************************/ 
    
    
    for(i=0;i< 99;i ++)
    clr_row(&ppage[i]);
    
    
    /*==========���������������������H�U�B�z�e�~�O��Ĥ@��P�_�X��������������������==========*/
    
    /* �W�[�e�~�O���Ĥ@�椺�e (Ex:~~1100000000000) add by larry 103.03.11 (1010523004_C2) */
    /* �F����ġu�l�H�覡�v�� A:�e�^�s�w, �q���O���O = 2 (1041102003_C1) */
    if (strncmp(sIpolicyB_type,"2",1) == 0 || strncmp(sIpolicyB_type,"3",1) == 0 )
    {
    	/*************************/
    	/*  ��1�B2�X:�T�w�r��~~  */
    	/*************************/
        strcpy(outpolicy,"~~"); /* �e��X�T�w�r�� */
        
        /*********************************************************/
        /*  ��3�X:�l�H�覡 1�G���H2�G����3�G����4�G���� A: �e�^  */
        /*********************************************************/
        if ( cntIroute > 0 && (equip_cmp(nequipment,"37") != TRUE)) 
            strcat(outpolicy,"A");
        else if ( cntIroute2 > 0 ) 
            strcat(outpolicy,"A");
        else 
            strcat(outpolicy,fmail_type); /* �l�H�覡 */
        
        /*************************************/    
        /* ��4�X:�T���� 1�G����2�G�T��       */        
        /*************************************/ 
        if ((strncmp(icar_type,"01",2) == 0) || (strncmp(icar_type,"02",2) == 0) ||
          	(strncmp(icar_type,"32",2) == 0) || (strncmp(icar_type,"34",2) == 0) || (strncmp(icar_type,"35",2) == 0))
        {
            strcat(outpolicy,"1"); /* ���� */
            /*strcat(outpolicy,"0");  �����@�ߤ����[�O��A�ȥd */
        }
        else 
        {
            strcat(outpolicy,"2"); /* �T�� */
          /*  if (out_ply_50 > 0) strcat(outpolicy,"1");
            else strcat(outpolicy,"0");  �u�O50�I��,�����[�O��A�ȥd */
        }

        /*************************************************/
        /* ��5�X:�R�q�K�� 0�G(��O)�����[ 1�G(�s��)���[    */
        /*************************************************/
        if(ilast_ply[0]!=' ' && ilast_ply[0]!='\0')
        {
             strcat(outpolicy,"0"); /* ��O */
        }
        else
        {
            strcat(outpolicy,"1"); /* �s�� */
        }
        
        /***********************************************************/
        /* ��6�X:�q�����O 0�G�D����B1�G����B2�G�F����ġB3�G���Q */
        /***********************************************************/
        if (strncmp(iroute,"JB",2) == 0)
        {
            strcat(outpolicy,"1"); /* ���� */
        }
        else if(cntIroute2 > 0) 
            strcat(outpolicy,sIrouteNote2);
        else 
        {
            /* �S�w�q������]�w��kind = 'SR' (�ư���Oú�ڥ�)*/
            if (cntIroute > 0 && (equip_cmp(nequipment,"37") != TRUE) ) 
            {
                strcat(outpolicy, trim(sIrouteNote));
            }
            else 
            {
                strcat(outpolicy,"0");
            }
        }
        
        /************************************************/
        /* ��7�X:�O�_�[���ڧP�_ 0�G���L���� 1�G�n�L���� */
        /************************************************/
        /* 1111005011_SC1_�����q�l����(�tE�O��B2B���s�q�lñ���u�W�n�O) */
        /*if (strcmp(feterms,"1")==0)
     	    strcat(outpolicy,"0");
        else*/

        if (cnt_term > 0 )
        {
        	strcat(outpolicy,"0");
        }
        else 
        {
            strcat(outpolicy,"1");
        }
 
        /*if ((strncmp(icar_type,"01",2) == 0) || (strncmp(icar_type,"02",2) == 0) ||
          	(strncmp(icar_type,"32",2) == 0) || (strncmp(icar_type,"34",2) == 0))
        {
            if (cntIroute > 0 && (equip_cmp(nequipment,"37") != TRUE) )
            {
      	        strcat(outpolicy,"1"); /*�i�F����ġj�����H���� 
            }
            else 
            {
                if (out_ply_47 == 0) strcat(outpolicy,"1"); /*�u�O47�I��,���������H���� 
                else if (out_ply_147 == 0) strcat(outpolicy,"5"); /*�u�O147�I��,���������H���� 
                else strcat(outpolicy,"0"); 
            }
        }
        else 
        {
            if (out_ply_50 > 0) 
            {
                if (fcar_class[0]=='2')
                    strcat(outpolicy,"3");
                else
                    strcat(outpolicy,"0");
            }
            else 
                strcat(outpolicy,"2");  /*�u�O50�I��,�T�������H���� 
        }*/
        
        
        /***************************************************/
        /* ��8�X:�s�±��ڵ��O ���~2021.06.10�^�Фw�S�b�ϥ� */
        /***************************************************/
        /* �s�±��ڵ��O 
              ���O	�s����(�O�v�N����79)		�±���(�O�v�N����78)
          �ۥΨT��	1�t������ѵs�I			4�t������ѵs�I
	    	        2�L������ѵs����L���N�I	5�L������ѵs����L���N�I
	      ����	3���I��				6���I��
    	    ��~��	7���I��
        */
        if ((strncmp(icar_type,"01",2) == 0) || (strncmp(icar_type,"02",2) == 0) ||
          	(strncmp(icar_type,"32",2) == 0) || (strncmp(icar_type,"34",2) == 0) || (strncmp(icar_type,"35",2) == 0))
        {
            if(irate_ym >= 80)
      	        strcat(outpolicy,"C");     	
      	    else if(irate_ym == 79)
      	        strcat(outpolicy,"3");
      	    else
      	        strcat(outpolicy,"7");
        }
        else
        {
            if (fcar_class[0]=='2')
      	    {
      	        strcat(outpolicy,"4");
      	    }
      	    else
      	    {
      	        if(irate_ym >= 80)
      	        {
      	            if(out_ply_dmg > 0)
      		        strcat(outpolicy,"A");
      		    else
      		        strcat(outpolicy,"B");
                }
      	        else if(irate_ym == 79)
      	        {
      		    if(out_ply_dmg > 0)
      		        strcat(outpolicy,"1");
      		    else
      		        strcat(outpolicy,"2");
      	        }
      	        else
      	        {
      		    if(out_ply_dmg > 0)
      		        strcat(outpolicy,"5");
      		    else
      		        strcat(outpolicy,"6");
      	        }
      	    }
        }
        
        /*********************/
        /* ��9~15�X: 0000000 */
        /*********************/
        strcat(outpolicy,"0000000");
        
        add_row(&ppage[0], outpolicy ,1);
    }
    else
    {
    	  add_row(&ppage[0], " " ,1);
    }

    /*==========���������������������H�W�϶��B�z�e�~�O��Ĥ@��P�_�X��������������������==========*/

    if (add_mplace_01_flag == 1 && add_mplace_11_flag == 0)
    {
         add_row(&ppage[0], str_add01 ,1);
    }
    else if (add_mplace_01_flag == 0 && add_mplace_11_flag == 1)
    {
         add_row(&ppage[0], str_add11 ,1);
    }
    else if (add_mplace_01_flag == 1 && add_mplace_11_flag == 1)
    {
         add_row(&ppage[0], str_add0111 ,1);
    }
    else
    {
         add_row(&ppage[0], " " ,1);
    }

    strcpy(tmp_str3,"");
    sprintf(tmp_str3,"%s",reprint);
    /*add_row(&ppage[1],tmp_str3); */                /*1*car306.fmt����1��*/
    
    if(bufa_print == 1 && bufa_print2 == 1)
    	sprintf(tmp_reprint,"�ɵo���%s�~%s��%s��",yy5,mm5,dd5); 
    else
    	strcpy(tmp_reprint," ");
    	
    add_row(&ppage[1],tmp_reprint);
    
    printf("0200: tmpstr[%s]\n",tmp_str3);

    printf("!!!!!!!!!!!!!fcar1[%s] fcar2[%s]\n",fcar1,fcar2);
    

    tax_area[4]='\0';
    strncpy(tax_area1,tax_area,2);
    tax_area1[2] = '\0';
    strcpy(tax_area2,tax_area+2);
    tax_area2[2] ='\0';

    printf("************ tax_area1=[%s]tax_area2=[%s]\n",tax_area1,tax_area2);
    /*  add_row(&ppage[6],approval_980401_1,1);*/

    cnt_ncont = 0;
    cnt_ncont2 = 0;
    $SELECT count(*) INTO $cnt_ncont FROM tbl_ncontent WHERE ipolicy = $ipolicy;
    printf("--348cnt_ncont[%d]\n\n",cnt_ncont);
    $SELECT count(*) INTO $cnt_ncont2 FROM tbl_ncontent2 WHERE ipolicy = $ipolicy;
    printf("--cnt_ncont2[%d]\n\n",cnt_ncont2);

                    
    /*add_row(&ppage[6]," ",1);*/                /*7*�֭�帹1*/
    add_row(&ppage[6],fcar1,1);                  /*7*�ۥε��O*/
    add_row(&ppage[6],fcar2,1);                  /*7*��~���O*/
    
    if(bufa_print == 1 && receipt_print == 0)
    {
        add_row(&ppage[6]," ",1);                /*7*�x*/
	add_row(&ppage[6]," ",1);                /*7*�_*/
    }
    else
    {
	add_row(&ppage[6],tax_area1,1);          /*7*�x*/
	add_row(&ppage[6],tax_area2,1);          /*7*�_*/	
    }
	
    add_row(&ppage[7]," ",1);                    /*8*�֭�帹2*/
	
    if(bufa_print == 1 && receipt_print == 0)
        add_row(&ppage[7]," ",1);                /*8*�t�d�H*/
    else
	add_row(&ppage[7],npresident,1);         /*8*�t�d�H*/

    if (irelative_ply[0] != '\0' && irelative_ply[0]!=' ')
    {
        if(strcmp(irelative_ply,r_icard) != 0)
    	{
    	    add_row(&ppage[8],"�j���Ҹ�",1);     /*9*/     
            add_row(&ppage[8],r_icard,1);	 /*9*�j���Ҹ�*/
    	}
    	else
    	{
    	    add_row(&ppage[8]," ",1);         	 
            add_row(&ppage[8]," ",1);            	 
    	}        
        add_row(&ppage[8],"����",1);
        add_row(&ppage[8],s_r_dbegin,1);         /*9*�j��_��*/
        if(s_r_dbegin[0]==' ' || s_r_dbegin[0]=='\0')
            add_row(&ppage[8]," ",1);            /*9*/
        else
            add_row(&ppage[8],"-",1);            /*9*/
        add_row(&ppage[8],s_r_dend,1);           /*9*/
    }
    else
    {
        add_row(&ppage[8]," ",1);                /*9*�Y�L�j���I���p���h�L�X�ť� */
        add_row(&ppage[8]," ",1);                /*9*/
        add_row(&ppage[8]," ",1);                /*9*/
        add_row(&ppage[8]," ",1);                /*9*/
        add_row(&ppage[8]," ",1);                /*9*/
        add_row(&ppage[8]," ",1);                /*9*/
    }

    if (flag980401[0] == '0')                    /*9*�֭�帹3*/
        add_row(&ppage[8],approval_3,1);
    else
        add_row(&ppage[8],approval_980401_3,1);

    if(bufa_print == 1 && receipt_print == 0)
    {
	add_row(&ppage[8]," ",2);                    /*9ñ�����~*/
	add_row(&ppage[8]," ",2);                    /*9ñ������*/
	add_row(&ppage[8]," ",2);                    /*9ñ������*/
    }
    else
    {
	add_row(&ppage[8],yy5,2);                    /*9ñ�����~*/
	add_row(&ppage[8],mm5,2);                    /*9ñ������*/
	add_row(&ppage[8],dd5,2);                    /*9ñ������*/	
    }


    if(bufa_print == 1 && receipt_print == 0)
    {
	add_row(&ppage[9]," ",1);                 /*10�k�䦬�ڪ����O�I�_��*/
	add_row(&ppage[9]," ",1);                 /*10*/
	add_row(&ppage[9]," ",1);                 /*10*/
    }
    else 
    {
	add_row(&ppage[9],yy1,1);                 /*10�k�䦬�ڪ����O�I�_��*/
	add_row(&ppage[9],mm1,1);                 /*10*/
	add_row(&ppage[9],dd1,1);                 /*10*/
    }

    add_row(&ppage[10],ply1,1);                   /*11����O�檺�O�渹*/
    add_row(&ppage[10],ply2,1);                   /*11*/
    add_row(&ppage[10],last_ply1,1);              /*11����O�檺��O�渹*/
    add_row(&ppage[10],last_ply2,1);              /*11*/
    iply_area[2] = '\0';
    add_row(&ppage[10],iply_area,1);              /*11�ӫO�a��*/

    if(bufa_print == 1 && receipt_print == 0)
    {
        add_row(&ppage[10]," ",1);                /*11�k�䦬�ڪ��O�渹*/
	add_row(&ppage[10]," ",1);                /*11*/    
	add_row(&ppage[10]," ",1);                /*11�k�䦬�ڪ��O�I����*/
	add_row(&ppage[10]," ",1);                /*11*/
	add_row(&ppage[10]," ",1);                /*11*/
    }
    else
    {
        add_row(&ppage[10],ply1,1);               /*11�k�䦬�ڪ��O�渹*/
	add_row(&ppage[10],ply2,1);               /*11*/    
	add_row(&ppage[10],yy2,1);                /*11�k�䦬�ڪ��O�I����*/
	add_row(&ppage[10],mm2,1);                /*11*/
	add_row(&ppage[10],dd2,1);                /*11*/
    }
	
    strcpy(tmp_nassured,rtrim(nassured));
    
    /*1090703007_SC1_�s�W�n/�Q�O�I�H(�O�_��ܴL��)�Ŀ����*/
    if(strncmp(icar_type,"15",2) != 0)
    {
        /*if (fsex[0] == '1')
            strcat(tmp_nassured," �g");
        else if (fsex[0] == '2')
            strcat(tmp_nassured," �g");*/ 	
    }


    strcpy(tmp_nassured_t,tmp_nassured);         /*����s���γQ�O�I�H*/

    if (nuser[0]!=' ' && nuser[0]!='\0')
    {
        strcat(tmp_nassured," �ϥΤH: ");
        strcat(tmp_nassured,rtrim(nuser));
    }
    strcpy( tmp_nassured4_t, tmp_nassured);
    ben_len=cc_split_chinese(tmp_nassured4_t,tmp_nassured4,62);
    /*
    if (napplicant[0]!=' ' && napplicant[0]!='\0')
    {
        strcat(tmp_nassured," �n�O�H: ");
        strcat(tmp_nassured,rtrim(napplicant));
    }
    */
    ben_len=cc_split_chinese(tmp_nassured,tmp_nassured1,62);
    if(strlen(tmp_nassured)>62)
        ben_len=cc_split_chinese(&tmp_nassured[ben_len],tmp_nassured2,62);
    else
        strcpy(tmp_nassured2," ");

    ben_len_t=cc_split_chinese(tmp_nassured_t,tmp_nassured1_t,62);
    if(strlen(tmp_nassured_t)>62)
        ben_len_t=cc_split_chinese(&tmp_nassured_t[ben_len_t],tmp_nassured2_t,62);
    else
        strcpy(tmp_nassured2_t," ");

    ben_len_t=cc_split_chinese(tmp_nassured,tmp_nassured3,18);


    add_row(&ppage[12],tmp_nassured4,1);          /*13 ����Q�O�I�H */

    /* �Ӹ�B�n */
    if (strncmp(sProtectData,"0",1) == 0)
        add_row(&ppage[12],itel,1);               /*13 ����q�ܸ��X */
    else
        add_row(&ppage[12],sItel,1);              /*13 ����q�ܸ��X */

    strcpy(tmp_napplicant,rtrim(napplicant));
    
    /*1090703007_SC1_�s�W�n/�Q�O�I�H(�O�_��ܴL��)�Ŀ����*/
    if(strncmp(icar_type,"15",2) != 0)
    {
        /*if (fsex_appl[0] == '1')
            strcat(tmp_napplicant," �g");
        else if (fsex_appl[0] == '2')
            strcat(tmp_napplicant," �g");*/
    }

        
    strcpy( tmp_napplicant_t, tmp_napplicant);
    ben_len=cc_split_chinese(tmp_napplicant_t,tmp_napplicant1,62);

    if(bufa_print == 1 && receipt_print == 0)
        add_row(&ppage[12],"���ڤw�}��",1);       /*13 �k��n�O�H */
    else
	add_row(&ppage[12],tmp_napplicant1,1);    /*13 �k��n�O�H */

    aassured[76]=0;
    if (aassured_zip[0]!=' ' && aassured_zip[0]!='\0')
        sprintf(aassured_cmb,"%s ",trim(aassured_zip));
    else
        strcpy(aassured_cmb,"");
        
    strcat(aassured_cmb,aassured);
    add_row(&ppage[14],aassured_cmb,1);           /*15 ����a�}*/
	
    if(bufa_print == 1 && receipt_print == 0)
        add_row(&ppage[14],"���ڤw�}��",1);       /*15 �k��Q�O�I�H */
    else 
	add_row(&ppage[14],tmp_nassured1,1);      /*15 �k��Q�O�I�H */

    /* �t�X�q���ĤG���q,�P�_����ק� (����~�ȭ��|�C�L�W�r) */
    $select icode into $sIcode
       from v_commission_obj
      where icomm_obj = $sIcomm_obj;

    /* �쬰����~�ȶ��L�g���N��������W��, �אּ�Ҧ��O�槡�L�g��N��������W��
      modify by sylvia 100.09.27 (1000926002_C1)
    */

    /* if (strncmp(ibroker,"I",1) == 0) */           /*17 �g��N����"I"�}�Y,�L�X�~�ȭ��m�W*/
    /* if (strcmp(sIcode,"2") == 0)
       add_row(&ppage[16],nname_I,1);
    else
       add_row(&ppage[16],"",1); */

    add_row(&ppage[16]," ",1);     /*17 �g��W�� W�g�찣�~ (�Ĥ@�p���L�W��) */


    if (nbenef[0]!=' ' && nbenef[0]!='\0')
        strcpy(nbenef_f,"V");
    else
        strcpy(nbenef_f, " ");

    add_row(&ppage[17],nbenef_f,1);               /*18 ����v�H */
    add_row(&ppage[17],nbenef,1);                 /*18*���q�H*/
    add_row(&ppage[17],yy1,1);                    /*18 ����O�I�_��*/
    add_row(&ppage[17],mm1,1);                    /*18*/
    add_row(&ppage[17],dd1,1);                    /*18*/

    /* �]���O��C�L�h��,�P�_�ӭ����̫�@��,���C�L���T�����B,
       �_�h�C�L �i*** ��U�� ***�j modify by sylvia 101.10.08 (1010928006_C1) */
    if(bufa_print == 1 && receipt_print == 0)
    {
        add_row(&ppage[17]," ",1);                /*18 �k��O�I�O */
    }
    else
    {
	if ( ipage < Pcount )
	    add_row(&ppage[17],"******(��U��)",1);   /*18 �k��O�I�O */
	else
	    add_row(&ppage[17],s1_real_premium,1);    /*18 �k��O�I�O */
    }
	
    nbenef[38]=0;
    add_row(&ppage[18],yy2,1);                /*19*����O�I����*/
    add_row(&ppage[18],mm2,1);                /*19*/
    add_row(&ppage[18],dd2,1);                /*19*/
	
    if(bufa_print == 1 && receipt_print == 0)
    {
        add_row(&ppage[18]," ",1);               /*19 �k�䦬�ڹq�ܸ��X*/
	add_row(&ppage[19]," ",1);               /*20 �k�䦬�ڪ��g��N�� */
	add_row(&ppage[19]," ",1);	             /*20 �k�䦬�ڪ��޲z�H */
	add_row(&ppage[19]," ",1);               /*20 �k�䦬�ڪ��P�Ӹ��X*/
    }
    else
    {
	add_row(&ppage[18],ntel_leader,1);       /*19 �k�䦬�ڹq�ܸ��X*/
	strcpy(iofficer,rtrim(iofficer));
	add_row(&ppage[19],iofficer,1);          /*20 �k�䦬�ڪ��g��N�� */
	strcpy(ntel_leader,trim(ntel_leader));
		
	if(strncmp(iroute,"JB",2)==0)            /*20 �k�䦬�ڪ��޲z�H */
	    add_row(&ppage[19],"����A�Ȥp��",1);
	else
	    add_row(&ppage[19],nname,1);
			
	add_row(&ppage[19],trim(itag),1);        /*20 �k�䦬�ڪ��P�Ӹ��X*/
    }

    add_row(&ppage[20]," ",1);                   /*21 */

    nbrand_abbr[10]=0;
    add_row(&ppage[22],nbrand_abbr,1);           /*23*�t�P����*/
    ncar_abbr[10]=0;
    add_row(&ppage[22],ncar_abbr,1);             /*23*��������*/

    add_row(&ppage[23],is_yy,2);                 /*24*��l�o�Ӧ~*/
    add_row(&ppage[23],ipro_year,1);             /*24*�s�y�~��*/
    add_row(&ppage[23],s_qcylinder,1);           /*24*�Ʈ�q*/

    /* car9711072 �Y���������ŭ�,�h�L�X������ */
    if(strlen(trim(iengine)) == 0) 
        strcpy(iengine,ibody);
    strcpy(iengine_0,"");
    strcat(iengine_0,iengine);
    strncpy(iengine_1,iengine_0,20);
    iengine_1[20] = '\0';
    strncpy(iengine_2,iengine_0+20,5);
    iengine_2[5] = '\0';
    printf("--3784 iengine[%s] iengine_0[%s] iengine_1[%s] iengine_2[%s]\n",iengine,iengine_0,iengine_1,iengine_2);
    /*add_row(&ppage[23],iengine,1);*/           /*24*�������X1*/
    add_row(&ppage[23],iengine_1,1);
    
    /* end of car9711072 */
    add_row(&ppage[23], trim(itag),1);           /*24*�P�Ӹ��X*/
    add_row(&ppage[23],ltrim(s_qpt),1);          /*24*�Ӹ�����*/

    if(bufa_print == 1 && receipt_print == 0)
	add_row(&ppage[23]," ",1);               /*24 ���ڽs�� add by sylvia 100.05.18 */
    else
	add_row(&ppage[23],ireceipt,1);          /*24 ���ڽs�� add by sylvia 100.05.18 */

    add_row(&ppage[24],is_mm,1);                 /*25*��l�o�Ӥ�*/
    add_row(&ppage[24],ibrand,1);                /*25*�t�P����*/
    add_row(&ppage[24],icar_type,1);             /*25*��������*/

    
    add_row(&ppage[24],iengine_2,1);             /*25 �������X2*/
    
    add_row(&ppage[24],s_fpt,1);                 /*25*�Ӹ�������*/
    
    if (strncmp(ibrand+6,"01",2)==0)
         add_row(&ppage[25],"HP",1);             /*26* �Ʈ�q���*/
    else
         add_row(&ppage[25]," ",1);    

    if(bufa_print == 1 && bufa_print2 == 1)
    {
    	add_row(&ppage[24],"��",1);
    	add_row(&ppage[26],"�o",1);
    }
    else
    {
    	add_row(&ppage[24]," ",1);
    	add_row(&ppage[26]," ",1);
    }

    if (strncmp(sProtectData,"0",1) == 0)
	add_row(&ppage[27],ilicense,1);          /*28*�����Ҹ��X*/
    else
	add_row(&ppage[27],sIlicense,1);         /*28*�����Ҹ��X*/

    add_row(&ppage[27],by,1);                    /*28*�X�ͤ���~*/
    add_row(&ppage[27],bm,1);                    /*28*�X�ͤ����*/
    add_row(&ppage[27],bd,1);                    /*28*�X�ͤ����*/
    add_row(&ppage[27],sex1,1);                  /*28*�ʧO*/

    if(bufa_print == 1 && bufa_print2 == 1)
    	add_row(&ppage[28],"��",1);
    else
   	add_row(&ppage[28]," ",1);

    /* sprintf( sTmpPsexAge, "%s %s", s_psex_age, s_psex_age_damage); */
    strcpy( sTmpPsexAge, ""); /* �O�v�ۥѤƦ~�֩ʧO���L */

    add_row(&ppage[29],sTmpPsexAge,1);           /*30*���d�~�֩ʧO�Y��*/
    add_row(&ppage[29],s_lia_acc,1);             /*30*�ߴڬ����Y�Ƴd��*/
    add_row(&ppage[29],s_dmg_acc,1);             /*30*�ߴڬ����Y�ƨ���*/
    /* �ӫO57,59,60�I��,���ݦL�X[���������y��Υߦ�Ӹ��H�Ƭ�XX�H] */
    if (ins_575960 == 1)
    {
    	sprintf(tmp_575960,"���������y��Υߦ쭼���H�Ƭ�%s�H",ltrim(s_qpt));
    	add_row(&ppage[29],tmp_575960,1);
    }
    else if(ins_150151 == 1)
    {
    	add_row(&ppage[29],tmp_150151,1);
    }
    else 
    {
    	sprintf(tmp_acc,"�䥦���l�ߴګY��:%s",s_unk_acc);
    	add_row(&ppage[29],tmp_acc,1);
    }
    
    if(bufa_print == 1 && bufa_print2 == 1)
	add_row(&ppage[30],"��",1);
    else
    	add_row(&ppage[30]," ",1);

    add_row(&ppage[31],"�O�I�����ΦW��",1);      /*32*�I�ت��Y */
    add_row(&ppage[31]," �D�n���I����",1);
    add_row(&ppage[31],"        �O  �I  ��  �B  ",1);
    add_row(&ppage[31]," �� �t �B",1);
    add_row(&ppage[31]," �O �I �O",1);

    add_row(&ppage[32],"    (�s�x����)  ",1);/*33*�s�x��*/
    add_row(&ppage[32],"(�s�x����)",1);
    add_row(&ppage[32],"(�s�x����)",1);
    /*add_row(&ppage[32],s_real_premium,1);         34*���N�O�O*/

    if(bufa_print == 1 && bufa_print2 == 1)
    	add_row(&ppage[32],yy5,1);   
    else
    	add_row(&ppage[32]," ",1);

    /*add_row(&ppage[34],s2_real_premium,1);       35*�j��O�O�B�X�p�O�O*/

    put_free_data(1,33,ppage,3,1);



    /****************************/
    /**                        **/
    /**  �O�椤�q�I�ئC�L�϶�  **/
    /**                        **/
    /****************************/



    for(i=0;i< 99;i ++)
        clr_row(&iins_page[i]);

    /* �N��btemp tbl_print�����I�ظ��Ū�X */
    $WHENEVER SQLERROR GOTO errexit;

    /* �]���O��C�L�h��,�P�_�ӫO�歶��,�Ȥ@���h���ƦL�X,�h��,���� N*P ����,
       ���e N �����  modify by sylvia 101.10.08 (1010928006_C1) */
       
    if (Pcount > 2)  /* �W�L3���C���u���19���I�ؤ��e */
    {		
        sprintf(sTmpsql,"SELECT skip %d first %d * FROM print_layout WHERE ipolicy = '%s' ORDER BY line_no;",
	                (ipage-1)*(Pline-2), (Pline-2), ipolicy);
    }
    else if (Pcount == 2) /* ��n2���C���u���20���I�ؤ��e */
    {
        sprintf(sTmpsql,"SELECT skip %d first %d * FROM print_layout WHERE ipolicy = '%s' ORDER BY line_no;",
                      	(ipage-1)*(Pline-1), (Pline-1), ipolicy);
    }
    else  /* ��n1���C�����21���I�ؤ��e */
    {
     	sprintf(sTmpsql,"SELECT skip %d first %d * FROM print_layout WHERE ipolicy = '%s' ORDER BY line_no;",
                      	(ipage-1)*Pline, Pline, ipolicy);
    }
    printf("sTmpsql=[%s]\n",sTmpsql);

    $PREPARE CURM FROM $sTmpsql;
    $DECLARE cur_print CURSOR FOR CURM;
    /* $DECLARE cur_print CURSOR for
       SELECT * FROM print_layout WHERE ipolicy = $ipolicy ORDER BY line_no; */


    
    /*========            �H�U�϶��B�z�I�ئC�L                 ========*/
    /*======== ��������������  �I�ئC�L���d��qline34~line54  �������������� ========*/
    
    j = 0;
    sum_ins_premium = 0;
    $OPEN cur_print;
    while (1)
    {
        p_no = 0;
	strcpy(p_iins_type,"");
	strcpy(p_nins_type,"");
	strcpy(p_main_paid,"");
	strcpy(p_qcoverage,"");
	strcpy(p_qcoverage_amt,"");
	strcpy(p_deduct,"");
	strcpy(p_mpremium,"");
	strcpy(p_field_tmp,"");
	ins_premium = 0;
		
	$FETCH cur_print INTO $sIpolicyTmp,$p_no,$p_iins_type,$p_nins_type,$p_main_paid,$p_qcoverage,
		              $p_qcoverage_amt, $p_deduct,$p_mpremium, $ins_premium,$p_field_tmp;
		              
	if (SQLCODE == SQLNOTFOUND) iins_cnt = 1;
		

	/*if (strlen(p_iins_type) > 1)
	      Total_Prem = Total_Prem+ins_premium;
	printf("-2535--- p_iins_type=[%s]sum_ins_premium=[%ld]ins_premium=[%d]Total_Prem=[%d]\n",p_iins_type,sum_ins_premium,ins_premium,Total_Prem); */
		
	if (ipage == Pcount)
	{
	    if (j==Pline)	break;
	}
	else
	{
	    if (j==(Pline-1))	break;
	}	
			
		
	Total_Prem = Total_Prem+ins_premium;
	printf("-2535--- sum_ins_premium=[%ld]ins_premium=[%d]Total_Prem=[%d]\n",sum_ins_premium,ins_premium,Total_Prem);
		
	strcpy(p_main_paid,trim(p_main_paid));
	strcpy(p_qcoverage,trim(p_qcoverage));
	strcpy(p_qcoverage_amt,trim(p_qcoverage_amt));
	strcpy(p_deduct,trim(p_deduct));
	strcpy(p_mpremium,trim(p_mpremium));
	if (strncmp(trim(p_iins_type),"�i",2)==0) 
	    sprintf(p_iins_type," %s",trim(p_iins_type));/*�t�X�i�r�p�H�ˮ`�I�W�U�j�����վ�*/
	else 
	    strcpy(p_iins_type, trim(p_iins_type));
		

	printf("-- 2546 ---- ipage=[%d] j=[%d] Pcount=[%d]\n",ipage,j,Pcount);
	if ((ipage>1) && (j==0))
	{
	    printf(" 2549 ----  �ĤG���H�᪺�Ĥ@��, �n���C�L *** �ӤW�� **** \n ");
	    /* �ĤG���H�᪺�Ĥ@��, �n���C�L *** �ӤW�� **** */
	    add_row(&iins_page[j],"  ",1);
	    add_row(&iins_page[j],"  ",1);
	    add_row(&iins_page[j],"  ",1);
	    add_row(&iins_page[j],"**** �ӤW�� ****",1);
	    add_row(&iins_page[j],"  ",2);
	    add_row(&iins_page[j],"  ",2);
	    add_row(&iins_page[j],"  ",2);
			
	    if (ipage == Pcount)
	        add_row(&iins_page[j],s_real_premium,1);        /*34*���N�O�O*/
	    else
		add_row(&iins_page[j],"**** ��U�� ****",1);    /*34*���N�O�O*/
			
	    put_row(34+j,&iins_page[j]);
	    j++;
	}
	printf(" --2565--ipage=[%d]------ j=[%d] ------------- \n",ipage,j);
		
	if (ipage == 1 && Pcount >2 && j == 19)  /*�O��W�L3��(�t)�A�C���ȦL19��A�Y�Ĥ@���̫�@��(��21��)��"��U��"�A�|���ťդ@��A���F���������ťդ@��A�]�����20������"��U��"��r*/
	{
	    add_row(&iins_page[j],"  ",1);
	    add_row(&iins_page[j],"  ",1);
	    add_row(&iins_page[j],"  ",1);
            add_row(&iins_page[j],"**** ��U�� ****",1);
	    add_row(&iins_page[j],"  ",2);
	    /*add_row(&iins_page[j],"  ",2);
	      add_row(&iins_page[j],"  ",2);*/
	}
	else 
	{
	    add_row(&iins_page[j],p_iins_type,1);
	    add_row(&iins_page[j],p_nins_type,1);
	    add_row(&iins_page[j],p_main_paid,1);
	    add_row(&iins_page[j],p_qcoverage,1);
			
	    /*�P�_�r�˦W�U*/
	    if (strcmp(trim(p_field_tmp),"")!=0)
	    {
	        if (strncmp(trim(p_field_tmp),"�a�}:",5)!=0 && strncmp(trim(p_field_tmp),"���q�H:",7)!=0)
		    add_row(&iins_page[j],p_field_tmp,1);
	        else
	            add_row(&iins_page[j],p_field_tmp,1);

	    }
	    else
	    {
			    
		printf("p_qcoverage_amt[%s]����[%d]\n",p_qcoverage_amt,strlen(p_qcoverage_amt));/*10*/
		printf("p_deduct[%s]����[%d]\n",p_deduct,strlen(p_deduct));/*12*/
		printf("p_mpremium[%s]����[%d]\n",p_mpremium,strlen(p_mpremium));/*13*/	
		/*�ɪť�*/
		strcpy(str_print,"");
		strcpy(tmpstr_print,"");
		for (int i=0;i<10-strlen(p_qcoverage_amt);i++)
		{
		    strcat(tmpstr_print," ");
			
		}		    				
		strcat(tmpstr_print,p_qcoverage_amt);	
		strcpy(p_qcoverage_amt,tmpstr_print);
			
		strcpy(tmpstr_print,"");
		for (int i=0;i<12-strlen(p_deduct);i++)
		{
		    strcat(tmpstr_print," ");
			
		}		    				
		strcat(tmpstr_print,p_deduct);	
		strcpy(p_deduct,tmpstr_print);
			
		strcpy(tmpstr_print,"");
		for (int i=0;i<13-strlen(p_mpremium);i++)
		{
		    strcat(tmpstr_print," ");
			
		}		    				
		strcat(tmpstr_print,p_mpremium);
		strcpy(p_mpremium,tmpstr_print);
		printf("�ɪť�p_qcoverage_amt[%s]����[%d]\n",p_qcoverage_amt,strlen(p_qcoverage_amt));/*10*/
		printf("�ɪť�p_deduct[%s]����[%d]\n",p_deduct,strlen(p_deduct));/*12*/
		printf("�ɪť�p_mpremium[%s]����[%d]\n",p_mpremium,strlen(p_mpremium));/*13*/
		strcat(str_print,p_qcoverage_amt);
		strcat(str_print," ");
		strcat(str_print,p_deduct);
		strcat(str_print," ");
		strcat(str_print,p_mpremium);	
		printf("����str_print[%s]����[%d]\n",str_print,strlen(str_print));
		add_row(&iins_page[j],str_print,1);	
	    }

	}

	if (j==0)
	{

	}
	
	if (j==1)
	{
	    if(bufa_print == 1 && bufa_print2 == 1)
	        add_row(&iins_page[j],"�~",1);
	    else
		add_row(&iins_page[j]," ",1);
	}
	else if (j==3)
	{
	    if(bufa_print == 1 && bufa_print2 == 1)
	        add_row(&iins_page[j],mm5,1);
	    else
		add_row(&iins_page[j]," ",1);
		
	    if(bufa_print == 1 && receipt_print == 0)
	    {
	        add_row(&iins_page[j]," ",2);                   /*37*�b��~*/
		add_row(&iins_page[j]," ",2);                   /*37*�b���*/
		add_row(&iins_page[j]," ",2);                   /*37*�b���*/ 
	    }
	    else
	    {
		add_row(&iins_page[j],yy5,2);                   /*37*�b��~*/
		add_row(&iins_page[j],mm5,2);                   /*37*�b���*/
		add_row(&iins_page[j],dd5,2);                   /*37*�b���*/ 
	    }

	}
	else if (j==4)
	{
	    if(bufa_print == 1 && receipt_print == 0)
	    {
		add_row(&iins_page[j]," ",1);                   /*38*�O�I�_���~*/
		add_row(&iins_page[j]," ",1);                   /*38*�O�I�_����*/
		add_row(&iins_page[j]," ",1);                   /*38*�O�I�_����*/
	    }
	    else
	    {
		add_row(&iins_page[j],yy1,1);                   /*38*�O�I�_���~*/
		add_row(&iins_page[j],mm1,1);                   /*38*�O�I�_����*/
		add_row(&iins_page[j],dd1,1);                   /*38*�O�I�_����*/
	    }       
	}
	else if (j==5)
	{
	    if(bufa_print == 1 && bufa_print2 == 1)
		add_row(&iins_page[j],"��",1);
	    else 
		add_row(&iins_page[j]," ",1);	
	
	    if(bufa_print == 1 && receipt_print == 0)
	    {
		add_row(&iins_page[j]," ",1);                   /*39*�O�渹�@*/
		add_row(&iins_page[j]," ",1);                   /*39*�O�渹�G*/         	
		add_row(&iins_page[j]," ",1);                   /*39*�O�I�����~*/
		add_row(&iins_page[j]," ",1);                   /*39*�O�I������*/
		add_row(&iins_page[j]," ",1);                   /*39*�O�I������*/  
	    } 
	    else
	    {
		add_row(&iins_page[j],ply1,1);                  /*39*�O�渹�@*/
		add_row(&iins_page[j],ply2,1);                  /*39*�O�渹�G*/         	
		add_row(&iins_page[j],yy2,1);                   /*39*�O�I�����~*/
		add_row(&iins_page[j],mm2,1);                   /*39*�O�I������*/
		add_row(&iins_page[j],dd2,1);                   /*39*�O�I������*/  
	    } 
	}
	else if (j==7)
	{
	    if(bufa_print == 1 && bufa_print2 == 1)
		add_row(&iins_page[j],dd5,1);
	    else
		add_row(&iins_page[j]," ",1);
	}
	else if (j==8)
	{    
	    if(bufa_print == 1 && receipt_print == 0)
		add_row(&iins_page[j],"���ڤw�}��",1);          /*42 �k��n�O�H */
	    else
		add_row(&iins_page[j],tmp_napplicant1,1);       /*42 �k��n�O�H */
	}
	else if (j==9)
	{
	    if(bufa_print == 1 && bufa_print2 == 1)
		add_row(&iins_page[j],"��",1);
	    else
		add_row(&iins_page[j]," ",1);
	}
        else if (j==10)
	{   
	    if(bufa_print == 1 && receipt_print == 0)
		add_row(&iins_page[j],"���ڤw�}��",1);              /*44*�Q�O�I�H*/
	    else
		add_row(&iins_page[j],tmp_nassured1,1);             /*44*�Q�O�I�H*/
	}        
	else if (j==11)
	{    
	    if(bufa_print == 1 && receipt_print == 0)
	    {              

	        add_row(&iins_page[j]," ",1);                   /*45*���N�O�O*/
		add_row(&iins_page[j]," ",1);                   /*45 �O�v�N��*/
	    }
	    else
	    {
		if (ipage == Pcount)
		{
		    add_row(&iins_page[j],s_real_premium,1);        /*45*���N�O�O*/
		    add_row(&iins_page[j],drate_ym,1);              /*45 �O�v�N��*/
		}
		else
		{
		    add_row(&iins_page[j],"**** ��U�� ****",1);    /*45*���N�O�O*/
		    add_row(&iins_page[j],drate_ym,1);              /*45 �O�v�N��*/
		}
	    }	      
	}           
	else if (j==12)
	{
	    if(bufa_print == 1 && receipt_print == 0)      
	    {
	        add_row(&iins_page[j]," ",1);                   /*46*�j��O�O�B�X�p�O�O*/
	    }
	    else
	    {
		if (ipage == Pcount)
		    add_row(&iins_page[j],s2_real_premium,1);       /*46*�j��O�O�B�X�p�O�O*/
		else
		    add_row(&iins_page[j],"  ",1);                  /*46*�j��O�O�B�X�p�O�O*/
	    }
	}           
	else if (j==13)
	{
	    if(bufa_print == 1 && receipt_print == 0)   
		add_row(&iins_page[j]," ",1);                       /*47* �k�䦬�ڹq�ܸ��X*/
	    else
		add_row(&iins_page[j],ntel_leader,1);               /*47* �k�䦬�ڹq�ܸ��X*/
	}          
	else if (j==14) 
	{  
	    if(bufa_print == 1 && receipt_print == 0)
	    {
	        /*1090908009_SC1_�Эק�ɵo�O��-�k�b�䦬�ڤ������p�ЦC�L���*/
		add_row(&iins_page[j],iofficer,1);                 /*48* �k�䦬�ڸg��N��*/
		add_row(&iins_page[j],ileader,1);                  /*48* �k�䦬�ں޲z�H*/
		add_row(&iins_page[j]," ",1);                      /*48* �k�䦬�ڵP�Ӹ��X*/ 
	    }
	    else
	    {
		add_row(&iins_page[j],iofficer,1);                /*48* �k�䦬�ڸg��N��*/
		strcpy(ntel_leader,trim(ntel_leader));
				
		if(strncmp(iroute,"JB",2)==0)                     /*48* �k�䦬�ں޲z�H*/
		    add_row(&iins_page[j],"����A�Ȥp��",1);
		else
		    add_row(&iins_page[j],ileader,1);
					
		add_row(&iins_page[j],trim(itag),1);              /*48* �k�䦬�ڵP�Ӹ��X*/ 
	    }        
	}         
	else if (j==15)         
	{  
	    if(bufa_print == 1 && receipt_print == 0)
	        add_row(&iins_page[j],nname_I,1);                     /*49 �g��W�� W�g�찣�~ */
	    else
		add_row(&iins_page[j],nname_I,1);                 /*49 �g��W�� W�g�찣�~ */
	}        
	else if (j==16)         
	{  
	    if(bufa_print == 1 && receipt_print == 0)
	    {
	        add_row(&iins_page[j]," ",1);                     /*50*���p�j��渹*/
		add_row(&iins_page[j]," ",1);                     /*50*���p�j��渹*/
		add_row(&iins_page[j]," ",1);
		add_row(&iins_page[j]," ",1);                     /*50*������~���m�W*/
	    }
	    else
	    {
		if (irelative_ply[0] != '\0' && irelative_ply[0] !=' ')
		{
		    add_row(&iins_page[j],"�j��渹�G",1);        /*50*���p�j��渹*/
		    add_row(&iins_page[j],irelative_ply,1);       /*50*���p�j��渹*/
		}
		else
		{
		    add_row(&iins_page[j]," ",1);                 /*50*���p�j��渹*/
		    add_row(&iins_page[j]," ",1);                 /*50*���p�j��渹*/
		}
			
		add_row(&iins_page[j], nbranch ,1);
			
		if ((ibig_sales[0] != '\0' && ibig_sales[0] !=' ') || (LHsNname[0] != '\0' && LHsNname[0] != ' '))
		{
		    /*add_row(&iins_page[j],"",1);*/              /*50*������~���N��*/
		    /*add_row(&iins_page[j],"",1);*/              /*50*������~���N��*/
		    add_row(&iins_page[j],LHsNname,1);            /*50*������~���m�W*/
		}
		else
		{
		    /*add_row(&iins_page[j]," ",1);*/             /*50*������~���N��*/
		    /*add_row(&iins_page[j]," ",1);*/             /*50*������~���N��*/
		    add_row(&iins_page[j]," ",1);                 /*50*������~���m�W*/
		}
	    }      
	}         
	else if (j==17)         
	{
	    if(bufa_print == 1 && receipt_print == 0)
	    {
	        add_row(&iins_page[j]," ",1);                     /*51*�q���N��*/
		add_row(&iins_page[j]," ",1);                     /*51*�q���W��*/
		add_row(&iins_page[j]," ",1);                     /*51*�~�ȱ��� (�q���ĤG���q) */
		add_row(&iins_page[j]," ",1);                     /*51*�q���ۭq�~�ȥN�� (�q���ĤG���q) */
	    }
	    else
	    {
		add_row(&iins_page[j],iroute,1);                  /*51*�q���N��*/
		add_row(&iins_page[j],nname_N,1);                 /*51*�q���W��*/
		add_row(&iins_page[j],sIroute_comm,1);            /*51*�~�ȱ��� (�q���ĤG���q) */
		add_row(&iins_page[j],sIroute_prop,1);            /*51*�q���ۭq�~�ȥN�� (�q���ĤG���q) */
	    }
	    printf("0210: ibig_sales1:[%s] \n",ibig_sales);	      
	}                            	
	else if (j==20)
	{
	    /* add_row(&iins_page[j],bak_chiness,1); */       /* 54 ���B���j�g  modify by sylvia 100.05.18 */
	    /*���p�O�O�b10�U���H�W�h�C�L�ť�*/
	    tmp_prem=real_premium/100000;
	    if ((tmp_prem!=0) ||  (ipage != Pcount))
	    {
	        strcpy(ch_amt1,"**");
		strcpy(ch_amt2,"**");
		strcpy(ch_amt3,"**");
		strcpy(ch_amt4,"**");
		strcpy(ch_amt5,"**");
		add_row(&iins_page[j],ch_amt1,2);                     /*55��*�U*/
		add_row(&iins_page[j],ch_amt2,2);                     /*55��*�a*/
		add_row(&iins_page[j],ch_amt3,2);                     /*55��*��*/
		add_row(&iins_page[j],ch_amt4,2);                     /*55��*�B*/
		add_row(&iins_page[j],ch_amt5,2);                     /*55��*��*/
	    }
	    else
	    {
		tmp_prem=real_premium/10000;
		other_prem=real_premium%10000;
		num_to_chinese(ch_amt1,tmp_prem);     /*�N���ԧB�Ʀr�ন����j�g�Ʀr*/
		if (tmp_prem==0) 
		    strcpy(ch_amt1,"�s");
				
		tmp_prem=other_prem/1000;
		other_prem=other_prem%1000;
		num_to_chinese(ch_amt2,tmp_prem);
		if (tmp_prem==0) 
		    strcpy(ch_amt2,"�s");
				
		tmp_prem=other_prem/100;
		other_prem=other_prem%100;
		num_to_chinese(ch_amt3,tmp_prem);
		if (tmp_prem==0) 
		    strcpy(ch_amt3,"�s");
				
		tmp_prem=other_prem/10;
		other_prem=other_prem%10;
		num_to_chinese(ch_amt4,tmp_prem);
		if (tmp_prem==0) 
		    strcpy(ch_amt4,"�s");
		num_to_chinese(ch_amt5,other_prem);
		if (other_prem==0) 
		    strcpy(ch_amt5,"�s");
				
		if ((strcmp(trim(dendorse),"") == 0) ||(strcmp(trim(dendorse),'\0') == 0))
		    printf("the dendorse is not exist ----> ch_amt !!!\n");
		else
		{
		    printf("the dendorse is exist ----> ch_amt !!!\n");
		    strcpy(ch_amt1,"");
		    strcpy(ch_amt2,"");
		    strcpy(ch_amt3,"");
		    strcpy(ch_amt4,"");
		    strcpy(ch_amt5,"");
		}
		/* 8/1�W�u�٬O�n�L��� */
		/* strcpy(ch_amt1,"**");
		strcpy(ch_amt2,"**");
		strcpy(ch_amt3,"**");
		strcpy(ch_amt4,"**");
		strcpy(ch_amt5,"**"); */
		add_row(&iins_page[j],ch_amt1,2);                     /*55��*�U*/
		add_row(&iins_page[j],ch_amt2,2);                     /*55��*�a*/
		add_row(&iins_page[j],ch_amt3,2);                     /*55��*��*/
		add_row(&iins_page[j],ch_amt4,2);                     /*55��*�B*/
		add_row(&iins_page[j],ch_amt5,2);                     /*55��*��*/
	    }
	}
			
	printf("0220: j[%d]\n",j);
	put_row(34+j,&iins_page[j]);
	j++;
		
	if( iins_cnt == 0)
            sum_ins_premium += ins_premium;
		
    } /* end of while */
    $CLOSE cur_print;
    $FREE cur_print;
    
		
    if (ipage == 1 && Pcount > 2)   /*�O��W�L3��(�t)�A�C���ȦL19��A�Y�Ĥ@���̫�@��(��21��)��"��U��"�A�|���ťդ@��A���F���������ťդ@��A�]�����20������"��U��"��r*/
    {                               /* �]�e���w�g��"��U��"�A��21���ť� */
        add_row(&iins_page[j],"  ",1);
	add_row(&iins_page[j],"  ",1);
	add_row(&iins_page[j],"  ",1);
	add_row(&iins_page[j],"  ",1);
	add_row(&iins_page[j],"  ",2);
	add_row(&iins_page[j],"  ",2);
	add_row(&iins_page[j],"  ",2);
	put_row(34+j,&iins_page[j]);
    }
    else if (ipage < Pcount)
    {
        add_row(&iins_page[j],"  ",1);
	add_row(&iins_page[j],"  ",1);
	add_row(&iins_page[j],"  ",1);
	add_row(&iins_page[j],"**** ��U�� ****",1);
	add_row(&iins_page[j],"  ",2);
	add_row(&iins_page[j],"  ",2);
	add_row(&iins_page[j],"  ",2);
	put_row(34+j,&iins_page[j]);
    }
		
    puts("aaaaaaaaaaaaaaaaaaaaaaaaaa");
    printf("sum_ins_premium[%d], premium1[%d] Total_Prem=[%ld]\n", sum_ins_premium, premium1,Total_Prem);
		
    /* �j�O�椣�ˮ��I�� */
    if (bigply_flag == FALSE)
    {
        printf("iins_cnt=[%d] ipage=[%d] Pcount=[%d]\n",iins_cnt,ipage,Pcount);
	/* if( sum_ins_premium != premium1) */
	if (ipage == Pcount)
	{
	    if( Total_Prem != premium1)
	    {
	        /* ���B���۵�����ر��p,�@�جO�]��bug�y�����B����,�t�@�جO�I�إ��L���y����,���~�T���n���j�}�� */
		if (iins_cnt == 1)
		{
		    printf("M_CA_PREMIUM_ERR!\n");
		    return M_CA_PREMIUM_ERR;
		}
		else
		{
		    printf("M_CA_IINS_NONFINISH\n");
		    /* return M_CA_IINS_NONFINISH; */
		}
	    }
	}
    }
		
    /* �I�ئC�L���� */
    
    /*========            �H�W�϶��B�z�I�ئC�L                 ========*/
    /*======== ��������������  �I�ئC�L���d��qline34~line54  �������������� ========*/
    
    
    
    
    
    /********************************/
    /**                            **/
    /**  �O���q��L��T�C�L�϶�  **/
    /**                            **/
    /********************************/   
    
    
    

    /* �}�l�C�L���ݫO�O�H�Ψ�L��� */
    for(i=0;i< 99;i ++)
        clr_row(&bottom_page[i]);

    /*1061026002_C4_1��1��s�O�v�վ����l    b2be�O�����s    b2c�Хt���q��*/
    if (flag980401[0] == '0')
    {
        sprintf(nc1,"%s%s",approval_1,approval_2);
	strcpy(nc2," ");
	strcpy(nc3," ");  
    }
    else
    {
    	
    	
        /*======== ��������������  �H�U�B�z�帹�_��  �������������� ========*/
        
	ncontent_a[0] = '\0';
	ncontent_a_2[0] = '\0';
	ncontent_a_3[0] = '\0';
		
	printf("--4431\n");
	/*1061226007_C4_�������ˮ֨��� */
	/*if(ISLEASED_CAR(icar_type_ori) && atoi(drate_ym) >= 90)
	{
	    strcpy(ncontent1," ");
	    strcpy(ncontent2," ");
	    strcpy(ncontent1,ncontent3);
	}*/

	iTmp = iTmp2 = iTmp3 = iTmp4 = iTmp5 = iTmp6 = iTmp7 = iTmp8 = iTmp9 = iTmp10 = 0;
	count = 0;

        printf("--4443--ncontent[%s]\n",ncontent_print);
        
        /*strcpy(nc1,"");
        strcpy(nc2,"");
        strcpy(nc3,"");
        strcpy(nc4,"");
        strcpy(nc5,"");
        strcpy(nc6,"");
        strcpy(nc7,"");
        strcpy(nc8,"");*/
        printf("--4443--nc3[%s]\n",nc3);      		
		
	iTmp = iGetChinesePos(ncontent_print,98);
	strcpy(nc1,"");
	strncpy(nc1,ncontent_print,iTmp+1);
	nc1[iTmp+1] = '\0';
	count = count + iTmp + 1;
	 	
	if (count <= strlen(ncontent_print))
	{
	    iTmp2 = iGetChinesePos(ncontent_print+count,98);
	    strncpy(nc2,ncontent_print+count,iTmp2+1);
	    nc2[iTmp2+1] = '\0';
	 	    count = count + iTmp2 + 1;
	}
	else 
	    strcpy(nc2,"");
	 	
	if (count <= strlen(ncontent_print))
	{
	    iTmp3 = iGetChinesePos(ncontent_print+count,98);
	    strncpy(nc3,ncontent_print+count,iTmp3+1);
	    /*strcpy(nc3,substring(ncontent_print,count+1,iTmp3));*/
	    nc3[iTmp3+1] = '\0';
	    count = count + iTmp3 + 1;
	}
	else 
	    strcpy(nc3,"");	

	if (count <= strlen(ncontent_print))
	{
	    iTmp4 = iGetChinesePos(ncontent_print+count,98);
	    strncpy(nc4,ncontent_print+count,iTmp4+1);
	    nc4[iTmp4+1] = '\0';
	    count = count + iTmp4 + 1;
	}
	else 
	    strcpy(nc4,"");
	 	
	if (count <= strlen(ncontent_print))
	{
	    iTmp5 = iGetChinesePos(ncontent_print+count,98);
	    strncpy(nc5,ncontent_print+count,iTmp5+1);
	    nc5[iTmp5+1] = '\0';
	    count = count + iTmp5 + 1;
	}
	else 
	    strcpy(nc5,"");
	 	
	if (count <= strlen(ncontent_print))
	{
	    iTmp6 = iGetChinesePos(ncontent_print+count,98);
	    strncpy(nc6,ncontent_print+count,iTmp6+1);
	    nc6[iTmp6+1] = '\0';
	    count = count + iTmp6 + 1;
	}
	else 
	    strcpy(nc6,"");
	 	
	if (count <= strlen(ncontent_print))
	{
	    iTmp7 = iGetChinesePos(ncontent_print+count,98);
	    strncpy(nc7,ncontent_print+count,iTmp7+1);
	    nc7[iTmp7+1] = '\0';
	    count = count + iTmp7 + 1;
	}
	else 
	    strcpy(nc7,"");
	 	
	if (count <= strlen(ncontent_print))
	{
	    iTmp8 = iGetChinesePos(ncontent_print+count,98);
	    strncpy(nc8,ncontent_print+count,iTmp8+1);
	    nc8[iTmp8+1] = '\0';
	}
	else 
	    strcpy(nc8,"");
	 	
	printf("--4443--nc1[%s]nc2[%s]nc3[%s]nc4[%s]\n",nc1,nc2,nc3,nc4);
	
	/*======== ��������������  �H�W�B�z�帹�_��  �������������� ========*/
	
	
    }

    /* ���ݸ�ư_�l�欰55��,����C�@����put_row,�@�����ɮק��ݪ�85�� */
    for(i=55;i < 85; i++)
    {
        switch (i)
     	{
     	    case 55:
	        printf("0230: �I�ئL���_1-�L��0-���L��[%d]\n",iins_cnt);
     	 	if (iins_cnt == 0)  /* ���L�� */
     	 	{
     	 	    add_row(&bottom_page[i],"�I�إ��L��",1);
     	 	} 
     	 	else
     	 	{
     	 	    add_row(&bottom_page[i]," ",1);
     	 	}
     	 	break;
     	 	
     	    case 56:
		printf("�C�L���w�r�p�H�ӫ~�ΦW�U�I��  PrintDlist=[%s]\n",PrintDlist);
		if (strcmp(PrintDlist,"0") != 0)
		{
     	 	    add_row(&bottom_page[i],sProvD,1);
     	 	}
     	 	else
     	 	{
     	 	    if (mequipment > 0) add_row(&bottom_page[i],sMequipment,1);
     	 	    else add_row(&bottom_page[i]," ",1);
     	 	}	 	    	

     	 	break;
     	 	
     	    case 57:
     	        printf("�C�L���w�r�p�H�ӫ~�ΦW�U1  PrintDlist=[%s]sProvD_1[%s]\n",PrintDlist,sProvD_1);
     	 	if (strcmp(PrintDlist,"0") != 0)
		{
     	 	    add_row(&bottom_page[i],sProvD_1,1);
     	 	}
     	 	else
     	 	{
     	 	    add_row(&bottom_page[i]," ",1);
     	 	}
	 	   	
     	 	break;
     	 	
     	    case 58:
     	 	printf("�C�L���w�r�p�H�ӫ~�ΦW�U2  PrintDlist=[%s]sProvD_2[%s]\n",PrintDlist,sProvD_2);
     	 	if (strcmp(PrintDlist,"0") != 0)
		{
     	 	    add_row(&bottom_page[i],sProvD_2,1);
     	 	}
     	 	else
     	 	    add_row(&bottom_page[i]," ",1);
 	 	   	
     	 	break;
     	 	
     	    case 59:
         	/*�s�W��SQL�ASQLNOTFOUND�O�ק�e����r*/
	 	/*�ק��]1060426011_C1_CAR320,CAR322 �ק�30��301�I�ئC�L�n�O�ѳ������r*/
                /*�W�[�P�_���L�O�B �קK�ɵo�ɦ�30�B301�P�ɦs�b*/
		$SELECT iins_type,mdeduct
		   FROM ply_ins_type
		  WHERE ipolicy = $ipolicy
	            AND iins_type in ( '30', '301' ,'302', '530')
		    AND mdamage_cover <> 0;
		if(SQLCODE == SQLNOTFOUND)
		{		
		    /* ��65��:29�I�ص��O������ */
		    if (s_note[0] == '\0' || s_note[0] == " ") 
		    {
		        add_row(&bottom_page[i]," ",1); 
		    }
		    else
		    {
			strcpy(s_note,trim(s_note));
			add_row(&bottom_page[i],s_note,1);
		    } 
		    break;	
		}
		else
		{
		    add_row(&bottom_page[i],ps_dtl,1);                        /*81�����I����B�C�M�ᨮ�ߨ����O*/
		    break;	
		}
		
     	    case 60:
                    /*60 �q�l���ڻ������1*/
                    /*if (strcmp(feterms,"1")==0)
     	 	        add_row(&bottom_page[i],str_feterms1,1);
                    else*/
                    /* 1111005011_SC1_�����q�l����(�tE�O��B2B���s�q�lñ���u�W�n�O) */
                    if (ps_60[0] == '\0' || ps_60[0] == " ") 
                    	add_row(&bottom_page[i]," ",1);
                    else 
                    	add_row(&bottom_page[i],ps_60,1);

                    break;

            case 61:
                    /*61 �q�l���ڻ������2*/
                    /*if (strcmp(feterms,"1")==0)
     	 	        add_row(&bottom_page[i],str_feterms2,1);
                    else*/
                    /* 1111005011_SC1_�����q�l����(�tE�O��B2B���s�q�lñ���u�W�n�O) */
                        add_row(&bottom_page[i]," ",1);
                    break;

            case 62:
	        printf("0260: �W�U�L���_1-�L��0-���L��[%d]\n",list_cnt);
     	 	if (list_cnt == 0 && list_print == 0)  /* list_print=0��,�N���ݭn�L�W�U */
     	 	{
     	 	    add_row(&bottom_page[i]," ",1);
     	 	    /*add_row(&bottom_page[i],"56�Q�O�I�H�W�U���L��",1);*/
     	 	} 
     	 	else
     	 	{
     	 	    add_row(&bottom_page[i]," ",1);
     	        }
     	 	/* �k��ñ����  add by sylvia 100.05.18 */
		/*add_row(&bottom_page[i],yy5,2);                   /*65ñ�����~*
		add_row(&bottom_page[i],mm5,2);                    /*65ñ������*
		add_row(&bottom_page[i],dd5,2);                    /*65ñ������*/
     	 	add_row(&bottom_page[i]," ",1);
     	 	add_row(&bottom_page[i]," ",1);				                

       	        break;
        
	    case 63:
	        /*63�帹�Ĥ@��*/
	        if (ipage == 1 && strlen(trim(nc1))>0)
 	 	{
 	 	    add_row(&bottom_page[i],trim(nc1),1);
 	 	}
 	 	else if (ipage == 2 && strlen(trim(nc5))>0)
 	 	{
 	 	    add_row(&bottom_page[i],trim(nc5),1);
 	 	}
 	 	else
 	 	{
 	 	    add_row(&bottom_page[i]," ",1);
 	 	}
       	        add_row(&bottom_page[i]," ",2); 	 	    
 
     	 	break;
 	 	
 	    case 64:
 	        /*64�帹�ĤG��*/
 	        if (ipage == 1 && strlen(trim(nc2))>0)
 	 	{
 	 	    add_row(&bottom_page[i],trim(nc2),1);
 	 	}
 	 	else if (ipage == 2 && strlen(trim(nc6))>0)
 	 	{
 	 	    add_row(&bottom_page[i],trim(nc6),1);
 	        }
 	 	else
 	 	{
 	 	    add_row(&bottom_page[i]," ",1);
 	 	}

     	 	break;

 	    case 65:
 	        /*65�帹�ĤT��*/
 	        if (ipage == 1 && strlen(trim(nc3))>0)
 	 	{ 	 	    
 	 	    add_row(&bottom_page[i],trim(nc3),1);
 	 	}
 	 	else if (ipage == 2 && strlen(trim(nc7))>0)
 	 	{
 	 	    add_row(&bottom_page[i],trim(nc7),1);
 	 	}
 	 	else
 	 	{
 	 	    add_row(&bottom_page[i]," ",1);
 	 	}
		add_row(&bottom_page[i]," ",1); 
		add_row(&bottom_page[i]," ",1);
		add_row(&bottom_page[i]," ",1); 
				 	    

     	 	break;
     	 	
     	    case 66:
     	        /*66�帹�ĥ|��*/
     	        if (ipage == 1 && strlen(trim(nc4))>0)
     	        {
     	    	    add_row(&bottom_page[i],trim(nc4),1);
     	        }
     	        else if(ipage == 2 && strlen(trim(nc8))>0)
     	        {
     	    	    add_row(&bottom_page[i],trim(nc8),1);	
     	 	}
     	 	else
     	 	{
     	 	    add_row(&bottom_page[i]," ",1);
     	 	}
		add_row(&bottom_page[i]," ",1); 
		add_row(&bottom_page[i]," ",1);
		add_row(&bottom_page[i]," ",1);   
			  	 	

     	 	break;
     	 	
     	    case 67: 
     		printf("--nprov_X[%s] \n",nprov_X);
     		/*1080920003_SC1_�ק�q�l�O��w��S�w�q����ܯS�w�T�� by 071004 2019.10.08*/
     		if (strcmp(iofficer,"Z17015Y01")==0 ||strcmp(iofficer,"Z17015Y")==0)
     		{

     	    	    add_row(&bottom_page[i],"���w�ɦ��D���ϴ�100�����A�ȡA��کνվ�A�Ȥ��e�̡A�H�����q���������i�γq������",1);      		    	
     		    	
     		}
     		else
     		{

     	    	    add_row(&bottom_page[i]," ",1);    				
     		}
     	 	add_row(&bottom_page[i]," ",1);
     	 	add_row(&bottom_page[i]," ",1);
     	 	add_row(&bottom_page[i]," ",1);
     	 	add_row(&bottom_page[i]," ",1);
     	 	add_row(&bottom_page[i]," ",1);
     	 	add_row(&bottom_page[i]," ",1);
     	        break;
     	    
     	    case 68:  	
     	        /*68 ���[���ڻ�����r*/	
     		strcpy(nprov_pqv,"");

     	    	
     	    	add_row(&bottom_page[i],nprov_note,1); 
     	    	

  	        
     	        break;
        
            case 69: 
                strcpy( sTmp1, "�n�O�H:");
                strcat( sTmp1, trim(napplicant));
                strcat( sTmp1, " �n�O�H�a�}:");
                strcat( sTmp1, trim(apayment_zip));
                strcat( sTmp1, " ");
                strcat( sTmp1, trim(apayment));
                ben_len=cc_split_chinese( sTmp1, sTmp, 104);
  	        add_row(&bottom_page[i], sTmp, 1);
  	        add_row(&bottom_page[i]," ",1);  	               
                break;

     	    case 70:
     	 	add_row(&bottom_page[i],area_restrict);
     	 	strcpy(print_premium,"�`�O�I�O:");
     	 	strcat(print_premium,s0_real_premium);
     	 	if (ipage < Pcount)
     	 	    strcpy(print_premium,"  ");

                if(mdiscount > 0 )
                {
                    if ( strncmp(fassured,"1",1)==0 || strncmp(fassured,"3",1)==0 ||
                         strncmp(fassured,"5",1)==0 )
                        add_row(&bottom_page[i],print_premium,1);    /*70*�`�O�I�O�B�������B�B�ꦬ�O�O*/
                    else
                       add_row(&bottom_page[i],print_premium,1);    /*70*�`�O�I�O*/
                }
                else
                    add_row(&bottom_page[i],print_premium,1);          /*70*�`�O�I�O*/

		
                break;

            case 72:
		/*add_row(&bottom_page[i],tmp_nassured1,1);*/          /*72 �k��Q�O�I�H */
		add_row(&bottom_page[i]," ",1);
                break;           
            
            case 74:
		/*�k��O�I�O add by sylvia 100.05.18 *
		if (ipage == Pcount)
		{
		add_row(&bottom_page[i],s1_real_premium,1);          *74 �k��O�I�O *
		add_row(&bottom_page[i],drate_ym,1);                 *74 �O�v�N�� *
		}
		else
		{
		add_row(&bottom_page[i]," **** ��U�� ****** ",1);    *74 �k��O�I�O *
		add_row(&bottom_page[i],drate_ym,1);                *74 �O�v�N�� *
		}*/
		add_row(&bottom_page[i]," ",1);
		add_row(&bottom_page[i]," ",1);
                break;
            
            case 75:
		/*add_row(&bottom_page[i],ntel_leader,1);          *75 �k�䦬�ڪ��q�ܸ��X */
		add_row(&bottom_page[i]," ",1);
                break; 
                       
            case 76:
	        /*strcpy(nname, trim(nname));
                strcpy(tmpDrate, trim(tmpDrate));
                sprintf(tmpNameDrate, "%s(%s)", nname, tmpDrate);
                add_row(&bottom_page[i],iofficer,1);                   *76 �k�䦬�ڪ��g��N�� *
                add_row(&bottom_page[i],nname,1);                *76 �k�䦬�ڪ��޲z�H *
                strcpy(ntel_leader,trim(ntel_leader));
                if(strncmp(iroute,"JB",2)==0)
                {
                    add_row(&bottom_page[i],"����A�Ȥp��",1);
                }
                else
                {
                    add_row(&bottom_page[i],tmpNameDrate,1);
                }
	        add_row(&bottom_page[i],trim(itag),1);            *76 �k�䦬�ڪ��P�Ӹ��X*/
	        add_row(&bottom_page[i]," ",1);
	        add_row(&bottom_page[i]," ",1);
	        add_row(&bottom_page[i]," ",1);
	     
                break;   

            case 77:
                /*add_row(&bottom_page[i],nname_I,1);         * 77 �g��W�� W�g�찣�~ */
                add_row(&bottom_page[i]," ",1);
                break;

            case 78:
	        /*add_row(&bottom_page[i],ireceipt,1);                    *78*���ڽs�� */     
	        add_row(&bottom_page[i]," ",1);      
                break;
	  
            case 79:
                /* �쬰����~�ȶ��L�g���N��������W��, �אּ�Ҧ��O�槡�L�g��N��������W��
                modify by sylvia 100.09.27 (1000926002_C1) W�g�찣�~ */
                /* �t�X�q���ĤG���q,�ק�P�_���� */
                /* if (strncmp(ibroker,"I",1) == 0)  */                 /*79 �g��N����"I"�}�Y,�L�X�~�ȭ��m�W*/
                /* if (strcmp(sIcode,"2") == 0)
                   add_row(&bottom_page[i],nname_I,1);
                else
                   add_row(&bottom_page[i],"",1); */
                break;

            case 80:
                if (strncmp(sIpolicyB_type,"2",1) == 0 || strncmp(sIpolicyB_type,"3",1) == 0 )
                {
         	    add_row(&bottom_page[i],yy7,2);                         /*80*ñ����*/
                    add_row(&bottom_page[i],mm7,2);                         /*80*ñ����*/
                    add_row(&bottom_page[i],dd7,2);                         /*80*ñ����*/
         	}
         	else
         	{
                    add_row(&bottom_page[i],yy5,2);                         /*80*ñ����*/
                    add_row(&bottom_page[i],mm5,2);                         /*80*ñ����*/
                    add_row(&bottom_page[i],dd5,2);                         /*80*ñ����*/
                }
                /*if(equip_cmp(nequipment,"102") == True)
                add_row(&bottom_page[i],"102:�۰ʥX��",1); 
                else */
	        add_row(&bottom_page[i]," ",1); 
	
                break;

            case 81:
                /*�]1060426011_C1_CAR320,CAR322 �ק�30��301�I�ئC�L�n�O�ѳ������r*/
	        /*  �ݨD�l�[�O���r�����Y�A�P����29�I�ص��O����*/
                /*add_row(&bottom_page[i],ps_dtl);*/                        /*81�����I����B�C�M�ᨮ�ߨ����O*/
                /*break;*/
		add_row(&bottom_page[i]," ");
            case 82:
                add_row(&bottom_page[i],yy6,2);                         /*82*��J���*/
                add_row(&bottom_page[i],mm6,2);                         /*82*��J���*/
                add_row(&bottom_page[i],dd6,2);                         /*82*��J���*/
                add_row(&bottom_page[i],tax_area,1);                    /*82*�ߩ��a*/
                break;
        } /* end of switch */

        put_row(i,&bottom_page[i]);
    } /* end of for */


    
    /** �]�w��car140 ���O=SR ����W��=2 ���q���g��N���A **/

    /* �i�F����ġj����L��N�O��^�����u�e�~�v, �l�H�覡���u���H�v(1041102003_C1) */
    if (strncmp(sIpolicyB_type,"0",1) == 0)
    {
        if (cntIroute > 0 && (strncmp(sIrouteNote,"2",1) == 0)) 
        {
       	    printf("�q���O���O(�e�~�O����)[%s]\n", sIrouteNote);
            $UPDATE ply_relation
                SET fout_print = '1',
                    fmail_type = '1'
              WHERE fcard_class = '2'
                AND ipolicy = $ipolicy
                AND dpolicy IS NULL
                AND dply_close IS NULL;
        }
    }

    /* �M���I�ت�table */
    /* �]���O��C�L�h��,�P�_�ӭ����̫�@��,�~�M��temp table �B�g�J���ڰO����
       modify by sylvia 101.10.08 (1010928006_C1) */
    if (ipage == Pcount)
    {
        $DELETE FROM print_layout where ipolicy = $ipolicy;
	$DELETE FROM tbl_print WHERE ipolicy = $ipolicy;
	$DELETE FROM tbl_coverage WHERE ipolicy = $ipolicy;
	$DELETE FROM tbl_56list WHERE ipolicy = $ipolicy;

	/* �g�J���ڰO���� ------------------------------------------------------- */
	   
	if(strlen(ireceipt) > 0) 
	{
	    if (strncmp(sIpolicyB_type,"2",1) != 0 && strncmp(sIpolicyB_type,"3",1) != 0 )
	    {
	    	/* �D�e�~��*/
	        strcpy(sDate,"today");
            strcpy(sDateTime,"current");
            strcpy(sRemark," ");
            strcpy(sDateTime,trim(sDateTime));
            if (strcmp(trim(dpolicy),"") == 0)
            {
                strcpy(iversion,"A");     /* ���� */
            }
            else
            {
                if (strncmp(sIpolicyB_type,"0",1) == 0)
                {
                    /* �z�Lcar344�C�L�e�~��(�鵲�e),���������� add by larry 103.03.28 (1010523004_C2) */
                    if (strncmp(fout_print,"1",1) == 0 && strncmp(fmail_type,"0",1) != 0 &&
                        strcmp(trim(dply_close),"") == 0 )
                    {
                        strcpy(iversion,"A");  /* ���� */
                    }
                    else
                    {
                        strcpy(iversion,"S");  /* �ɦL */
                    }
                }
                else
                {
                        /* �M�ץ�G�Ƶ��g�J�i�O��e�~�L�s�jmodify by larry 103.05.22 (1030325001_C1) */
                        strcpy(sRemark,"�O��e�~�L�s");
                        strcpy(iversion,"A");  /* ���� */
                }
		    }
	    }
	    else
	    {
	        /* �e�~��G�Ƶ��g�J�e�~�L�s add by larry 103.03.28 (1010523004_C2) */
            strcpy(sDate,"today");
            strcpy(sDateTime,"'");
            strcat(sDateTime,substring(dcreate,1,19));
            strcat(sDateTime,"'");
            strcpy(sRemark,"�e�~�L�s");
            strcpy(iversion,"A");      /* ���� */
	    }
	
	    idbstr = atoi(&ply1[4]);
	
	    printf("idbstr=[%d], ply1=[%s] \n",idbstr, ply1);
	    switch (idbstr)
	    {
	        case 0:
                strcpy(idb,"00");
                break;
	
            case 1:
                strcpy(idb,"40");
                break;
        
            case 2:
                strcpy(idb,"70");
                break;
        
            case 5:
                strcpy(idb,"22");
                break;
        
            case 6:
                strcpy(idb,"33");
                break;
        
            case 7:
                strcpy(idb,"66");
                break;
	    }
	
	    /* cm_receipt_log.nassured �u��  varchar(100,0) �ҥH�n�^�X add by sylvia 101.03.07 */
	    strcpy(sNass1, trim(nassured));
	
	    if (strlen(sNass1) > 100)
	    {
	        iTmp1 = iGetChinesePos(sNass1,100);
            strncpy(s_Nassured,&sNass1[0],iTmp1+1);
            s_Nassured[iTmp1+1] = '\0';
	    }
	    else
	    {
		    strcpy(s_Nassured, trim(sNass1));
	    }
	
            /* cm_receipt_log.napplicant �u��  varchar(100,0) �ҥH�n�^�X add by sylvia 101.03.07 */
	    strcpy(sNapp1, trim(napplicant));
	    if (strlen(sNapp1) > 100)
            {
		iTmp1 = iGetChinesePos(sNapp1,100);
		strncpy(s_Napplicant,&sNapp1[0],iTmp1+1);
		s_Napplicant[iTmp1+1] = '\0';
	    }
	    else
	    {
		strcpy(s_Napplicant, trim(sNapp1));
	    }
	
	    /* �P�_(�e�~��)�O��ӫO���e�󭶼g�Jcm_receipt_log.ntarget2
	       add by larry 103.06.05 (1030415003_C1) */
	    if (strncmp(sIpolicyB_type,"2",1) == 0 || strncmp(sIpolicyB_type,"3",1) == 0 )
	    {
		if(Pcount > 1)
		    sprintf(ntarget2,"%d",Pcount);
		else
		    strcpy(ntarget2," ");
	    }
	    else
            {
		strcpy(ntarget2," ");
	    }
	      
	    strcpy(stmpx," ");
	    if(bufa_print == 0)
	    {
		strcpy(stmpx," ");
	        sprintf(stmpx, "insert into cm_receipt_log \
			               (ireceipt, iins_cat, ipolicy, iendorse, itype, \
			                iversion, idb, iprint, dprint, remark,  \
			                dreceipt, nassured, napplicant, dbegin, dend, \
			                curr, mpremium, ileader, pexchg_rate, mprem_cur, \
			                iofficer, ntarget2,azip,aaddress) \
			        values \
			               ( '%s', 'C', '%s', ' ', 'N', \
			                 '%s', '%s', '%s', %s, '%s', \
			                 %s, '%s', '%s', %ld, %ld, \
			                 'NT', %ld, '%s', 1.0000, %ld, '%s', '%s',' ',' ')",
			                 ireceipt, ipolicy, iversion, idb, iprint, sDateTime,sRemark,sDate,
			                 nassured,napplicant, dply_begin, dply_end, real1_premium,
			                 ileader, real1_premium,iofficer, ntarget2);
		printf("stmpx=[%s]\n",stmpx);
		$PREPARE ins_pre1 FROM $stmpx;
		$EXECUTE ins_pre1;
		strcpy(stmpx," ");
		/*1060818001_C1_cmn134a-���I */
		/*�W�[�g�J���ک��ӤΦC�L�O��*/
		sprintf(stmpx, "insert into cm_receipt_log_dtl \
			              (ireceipt,ipolicy,iendorse,ftype,curr,pexchg_rate,mprem_cur) \
			        values('%s','%s',' ','N','NT',1.0000,'%ld') ",ireceipt,ipolicy,real1_premium);
		printf("stmpx=[%s]\n",stmpx);
		$PREPARE ins_pre2 FROM $stmpx;
		$EXECUTE ins_pre2;
		strcpy(stmpx," ");
			   
		sprintf(stmpx, "insert into cm_receipt_log_prt \
			              (ireceipt,fformal,fversion,fnote,iprint,dprint,isource) \
			        values('%s','F','%s',' ','%s',current,'car306') ",ireceipt,iversion,iprint);
		printf("stmpx=[%s]\n",stmpx);
		$PREPARE ins_pre3 FROM $stmpx;
		$EXECUTE ins_pre3;
		strcpy(stmpx," ");
	    }
	}
   }
   return M_CM_OK;

errexit:
    printf("SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/*--------------------------------------------------------------------------------*/
long car306_query1(sIpolicy,ibatch_no,type)
char sIpolicy[];
$int ibatch_no;
char type[];
{
    int   i=0,k;
    int   flag_exist;
    $char stmt[2000],buf[20],stmt_type[512];
    char  dbsite[3], FullDBName[40], str_type[2];
    $char ipolicy1[POLICY_NUM_1];
    $char f47[2];

    car306_clear();
    strncpy(ipolicy1,sIpolicy,13);
    ipolicy1[13]=0;

    strcpy(str_type,type);

    $WHENEVER SQLERROR GOTO errexit;

    /* type = 'a'�O�Ъ���, 'b'�O�帹 */
    if (strncmp(str_type,"a",1) == 0)
         strcpy(stmt_type,"");
    else
         strcpy(stmt_type,"AND x.ibatch_no = ?");

    sprintf(stmt,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s             ",
           "SELECT x.icard, x.ipolicy, x.irelative_ply, x.fcard_class, x.fprint,    ",
           "       x.ilast_ply, x.ibroker, x.iofficer, x.icashier,                  ",
           "       x.mdmg_prem, x.mlia_prem, x.dpolicy, NVL(x.dpolicy,today),       ",
           "       x.iexaminer, x.ientry, y.iply_area,                              ",
           "       y.fassured, y.nassured, y.nuser, y.nbenef, y.aassured, y.itel,   ",
           "       y.apayment, x.qply_period, x.dply_begin,                         ",
           "       x.dply_end, y.dissue, x.ipro_year, x.ibrand,                  ",
           "       x.icar_type, x.dentry, y.qcylinder, y.iengine, y.ibody,          ",
           "       y.qpt, y.fpt, y.psex_age, y.psex_age_damage, y.plia_acc, y.pdmg_acc, y.aassured_zip,",
           "       y.ilicense, y.dbirth, y.fsex, y.fmarriage,                       ",
           "       y.pdmg_factor, y.pbrg_factor,                                    ",
           "       y.flimit, y.pdmg_align, y.pbrg_align, y.plia_align,              ",
           "       y.nequipment, y.nbrand_abbr, y.ncar_abbr,                        ",
           "       x.transno, x.seqno, x.dendorse ,y.iroute,                        ",
           "       x.icomm_obj, x.iroute_comm, y.iroute_prop, x.iquota              ",
           "  FROM ply_relation x, policy y                                         ",
           " WHERE y.ipolicy = x.ipolicy                                            ",
           "   AND x.ipolicy = ? ",stmt_type);
printf("%s\n",stmt);
    $PREPARE car306_ply FROM $stmt;
    $DECLARE cur_ply CURSOR FOR car306_ply;

    if (strncmp(str_type,"b",1) == 0)
         $OPEN cur_ply USING $sIpolicy,$ibatch_no;
    else
         $OPEN cur_ply USING $sIpolicy;

    $FETCH cur_ply
      INTO $icard, $ipolicy, $irelative_ply, $fcard_class, $fprint,
           $ilast_ply, $ibroker, $iofficer, $icashier,
           $mdmg_prem, $mlia_prem, $dpolicy,$ca_dpolicy,
           $iexaminer, $ientry, $iply_area,
           $fassured, $nassured, $nuser, $nbenef, $aassured, $itel,
           $apayment, $qply_period, $dply_begin,
           $dply_end, $dissue, $ipro_year, $ibrand,
           $icar_type, $dentry, $qcylinder, $iengine, $ibody,
           $qpt, $fpt, $psex_age, $psex_age_damage, $plia_acc, $pdmg_acc, $aassured_zip,
           $ilicense, $dbirth, $fsex, $fmarriage,
           $pdmg_factor, $pbrg_factor,
           $flimit, $pdmg_align, $pbrg_align, $plia_align,
           $nequipment, $nbrand_abbr, $ncar_abbr,
           $transno, $seqno, $dendorse, $iroute,
           $sIcomm_obj, $sIroute_comm, $sIroute_prop, $iquota;

    if (SQLCODE == SQLNOTFOUND)
        return M_CM_NOT_FOUND;

    /*1040202006_C1 �s�W���ؤ���~�����²v�վ�*/
    strcpy(icar_type,TRANS_CAR_TYPE(icar_type));
    printf("-- trace icar_type[%s]\n ",icar_type);
    
    /*�j�O��j���Ҥ��C�L*/
    irelative_ply[0] = '\0';
    r_icard[0]='\0';
    icard[0]='\0';

    mdiscount = 0;
    mcommission = 0;
    premium1 = 0;
    mpure_prem = 0;

    /* �Y�ϥμЪ����h�ھڶǨӪ��O��פ�p��Ҧ����檺�O�O */
    if (strncmp(str_type,"b",1) == 0)
    {
        $SELECT SUM(mcommission),SUM(mdiscount),SUM(mins_premium),SUM(mpure_prem)
           INTO $mcommission, $mdiscount, $premium1, $mpure_prem
           FROM ply_ins_type
          WHERE ipolicy IN(SELECT ipolicy FROM ply_relation
                            WHERE ipolicy[1,13]=$ipolicy1
                              AND ibatch_no=$ibatch_no);
     } else {
     	  $SELECT SUM(mcommission),SUM(mdiscount),SUM(mins_premium),SUM(mpure_prem)
           INTO $mcommission, $mdiscount, $premium1, $mpure_prem
           FROM ply_ins_type
          WHERE ipolicy IN(SELECT ipolicy FROM ply_relation
                            WHERE ipolicy BETWEEN $sIpolicy AND $ply_end);
     }

printf("ipolicy1[%s],ipolicy[%s],ibatch_no[%s]\n",
            ipolicy1,ipolicy,ibatch_no);


    strncpy(site2,ipolicy,2);
    site2[2]='\0';

    $SELECT npresident,ifirm_pid,nchi_abv
       INTO $npresident,$ifirm_pid,$tax_area
       FROM branch
      WHERE ibranch = $site2;
    if (SQLCODE == SQLNOTFOUND)
    {
        return M_CM_NOT_FOUND;
    }

    $SELECT fcar_class
       INTO $fcar_class
       FROM car_type
      WHERE icode = $icar_type
        AND fclass = '1';
    if(SQLCODE == SQLNOTFOUND)
        strcpy( fcar_class, " ");

    $SELECT ileader
       INTO $ileader
       FROM officer
      WHERE iofficer=$iofficer;
    if (SQLCODE == SQLNOTFOUND)
        strcpy(ileader," ");

    $SELECT nname
       INTO $nname
       FROM officer
      WHERE iofficer=$ileader;
    if (SQLCODE == SQLNOTFOUND)
        strcpy(nname," ");

    /* 99.11.19 �j�M�q���N��������W�� */
    $SELECT nroute[1,20] INTO $nname_N
       FROM cm_route
      WHERE iroute = $iroute;

    /* ���W�� add by larry 104.08.10 (1040625002_C1) */
    $SELECT nbranch INTO $nbranch
       FROM sa_branch_type
      WHERE ibranch = $iquota;
    if(SQLCODE == SQLNOTFOUND) strcpy(nbranch," ");

    strcpy(f47,"0");
    /* 47�I�ضO�v�N���P�_ */
    /* f47 = '0'�A���ܥ��ӫO47��47�O�v�N��>=111�A�����47�帹*/
    /* f47 = '1'�A����47�O�v�N��<111�A�n���47�帹*/
    /*1081205009_SC4_�t�X47�I�رq�D�I�אּ���[�I�A�ק���s/E�O��/B2B/B2C�ˮ�(�Цb12�멳����)*/
    sprintf(stmt,"SELECT CASE WHEN CAST (drate_ym AS INTEGER)>=111 THEN '0' ELSE '1'  END "
                 "  FROM %s "
                 " WHERE ipolicy = '%s' AND iins_type='47' ",tableInsType,ipolicy);
    $PREPARE drate_ym_47 FROM $stmt;
    $EXECUTE drate_ym_47 INTO $f47;

    sprintf(ncontent_print,"");
    strcpy(stmt1,"SELECT max(ncontract ),a.iins_type "
                 " FROM  ca_terms a, ply_ins_type b"
                 " WHERE a.iins_type = b.iins_type"
                 "  AND  b.ipolicy = ? "
                 "  AND  deffect <= ? "
                 "  AND  dcreate <= ? "
                 "  AND ((dendorse IS NULL) OR (dendorse IS NOT NULL AND b.minjured_cover + b.mdeath_cover + b.mdamage_cover = 0) )"
                 " GROUP BY a.iins_type "
                 " UNION "
                 "SELECT max(ncontract ),a.iins_type "
                 " FROM  ca_terms a, ply_ins_type b"
                 " WHERE a.iins_type = b.iins_type"
                 "  AND  b.ipolicy = ? "
                 "  AND  deffect <= b.dedr_begin "
                 "  AND  dcreate <= b.dendorse "
                 "  AND  dendorse IS NOT NULL "
                 "  AND  b.minjured_cover + b.mdeath_cover + b.mdamage_cover <> 0 "
                 " GROUP BY a.iins_type "
                 " ORDER BY 1 DESC ");
                 
                 
                 
         $PREPARE s_app5 FROM $stmt1;
         printf("1stmt1[%s]\n",stmt1);
         $DECLARE sel_app5 CURSOR FOR s_app5;
         $OPEN sel_app5 USING $ipolicy,$dply_begin,$ca_dpolicy,$ipolicy;
         /*---------------------------------------*/
         while(1)
         {
         	$FETCH sel_app5 INTO $ncontract,$viins_type;
         	
         	if (SQLCODE == SQLNOTFOUND) continue;
         	printf("ncontract[%s],viins_type[%s]\n",ncontract, viins_type);
         	
         	sprintf(stmt2,
         	      " SELECT ncontent1,ncontent2 "
                  " FROM ca_terms"
                  " WHERE ncontract = '%s'"
                  " AND iins_type = '%s' " ,ncontract,viins_type);
            
            $PREPARE terms FROM $stmt2;
            $EXECUTE terms into $ncontent1,$ncontent2;
            
            /*�O�v�N��>=111�A����ܤ帹*/
            /*1081205009_SC4_�t�X47�I�رq�D�I�אּ���[�I�A�ק���s/E�O��/B2B/B2C�ˮ�(�Цb12�멳����)*/
            if(strcmp(f47,"0")==0 && strcmp(trim(viins_type),"47")==0)
            {
                strcpy(ncontent1,"");
                strcpy(ncontent2,"");
            }
            
            
            if (fcar_class[0] == '1')
	    {
		    if (strcmp(trim(ncontent1),"") != 0)
		    {
		    		sprintf(ncontent1, "%s;", trim(ncontent1));
		    		strcat(ncontent_print, ncontent1);
		    }
	    }
	    else
	    {
		    if (strcmp(trim(ncontent2),"") != 0)
		    {
		    		sprintf(ncontent2, "%s;", trim(ncontent2));
		    		strcat(ncontent_print, ncontent2);
		    }
	    }    	
         }
         $CLOSE sel_app5;
         $FREE  sel_app5;
         
         

         
    ipolicy1[13]=0;

    return M_CM_OK;

errexit:
    printf("SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

long ca306_get_data1(sIpolicy,ibatch_no,type)
char *sIpolicy;
$int ibatch_no;
char type[];
{
    $int i;
    int j;
    long prem0105;
    $char ipolicy1[POLICY_NUM_1];
    $char stmt[1000], stmt_type[512];
    char datestr[40],amt_print[11];
    $double damage_cover;
    $double injured_cover;
    $double death_cover;
    $long   ins_premium;
    $char   ssTmp[25];
    $long    insurance_cover_count = 0;
    $char   contain_coverage[120],prt_coverage[51];
    char   *ptr;
    long   lPremSum;
    $char  tmp_iins_scope[3],str_type[2],sFcal_way[2];
    char   sNinstype2[31];
    $char  iins_scope_56[2];
    $char sIpolicy1[21]=" ",sIpolicy2[21]=" ";
    $double mdisc;
    

printf("in get_data1\n");
    damage_cover = 0;
    death_cover = 0;
    injured_cover = 0;
    strcpy(ipolicy1,sIpolicy);
    ipolicy1[13]=0;
    strcpy(fcar1,"");
    strcpy(fcar2,"");

    strcpy(s_note1,"");
    strcpy(s_note2,"");

    strcpy(str_type,type);

    tmpDrate[0] = '\0';

    s_r_dbegin[0]='\0';
    s_r_dend[0]='\0';
    if(ipolicy[0]!=' ' && ipolicy[0]!='\0')
        strcpy(ply1,CompanyId);
    else
        strcpy(ply1,"  ");
    strncat(ply1,ipolicy,3);
    strncpy(ply2,&ipolicy[3],10);
    if(ipolicy[0]!=' ' && ipolicy[0]!='\0')
    {
        strcat(ply2,"-");
        sprintf(ply2,"%s%d",ply2,ibatch_no);
        ply2[13]='\0';
    }
    printf("-----------------PLY1%s\n",ply1);
    printf("-----------------PLY2%s\n",ply2);
    if(ilast_ply[0]!=' ' && ilast_ply[0]!='\0')
        strcpy(last_ply1,CompanyId);
    else
        strcpy(last_ply1,"  ");
    strncat(last_ply1,ilast_ply,3);
    strncpy(last_ply2,&ilast_ply[3],12);
    last_ply2[12]='\0';

    if(apayment[0]==0 || apayment[0]==' ')
      strcpy(apayment,aassured);

    rtoday(&Today);
    strcpy(s_dpolicy,cm_cdate_str_100(Today));
    cm_split_ymd_100(s_dpolicy,yy5,mm5,dd5);

    strcpy(datestr,cm_cdate_str_100(dentry));
    cm_split_ymd_100(datestr,yy6,mm6,dd6);

    strcpy(datestr,cm_cdate_str_100(dply_begin));
    cm_split_ymd_100(datestr,yy1,mm1,dd1);

    strcpy(datestr,cm_cdate_str_100(dply_end));
    cm_split_ymd_100(datestr,yy2,mm2,dd2);

    is_yy[0]=0;
    is_mm[0]=0;
    s_qcylinder[0]=0;
    nbrand_abbr[0]=0;
    ibody[0]=0;
    s_qpt[0]=0;
    s_fpt[0]=0;
    icar_type[0]=0;
    ibrand[0]=0;
    ncar_abbr[0]=0;
    ipro_year[0]=0;
    cm_long_split_3ymd( dbirth, by, bm, bd);   /* Date(long)�ন����~�B��B��(yyy,mm,dd) */
    strcpy(sIlicense,ilicense);
    strcpy(sItel,itel);
    prem0105=0;
    strcpy(iengine,script);

    if (fsex[0]=='1')
        strcpy(sex1,"�k");
    else if (fsex[0]=='2')
        strcpy(sex1,"�k");

    if (fmarriage[0]=='1')
        strcpy(marriage1,"�w�B");
    else if (fmarriage[0]=='2')
        strcpy(marriage1,"���B");
    sprintf( s_psex_age, "���d:%-6.2f", psex_age);
    sprintf( s_psex_age_damage, "����:%-6.2f", psex_age_damage);

    if(pdmg_align==0)
        s_dmg_align[0]='\0';
    else
        sprintf( s_dmg_align, "%d", pdmg_align);

    if(pbrg_align==0)
        s_brg_align[0]='\0';
    else
        sprintf( s_brg_align, "%d", pbrg_align);

    if(plia_align==0)
        s_lia_align[0]='\0';
    else
        sprintf( s_lia_align, "%d", plia_align);

    sprintf(s_lia_acc,"%6.2f",plia_acc);
    sprintf(s_dmg_acc,"%6.2f",pdmg_acc);

    $WHENEVER SQLERROR GOTO errexit;

    printf("ipolicy1[%s],ibatch_no[%d]\n",ipolicy1,ibatch_no);

    /*$SELECT SUM(mprem) INTO $old_premium
       FROM ply_ins_type
      WHERE ipolicy IN (SELECT ipolicy FROM ply_relation
                         WHERE ipolicy[1,13]=$ipolicy1 AND ibatch_no=$ibatch_no);
    if (SQLCODE == SQLNOTFOUND) old_premium=0; */
    if (strncmp(str_type,"b",1) == 0)
       strcpy(stmt_type,"WHERE ipolicy[1,13]=? AND ibatch_no=?)");
    else
       strcpy(stmt_type,"WHERE ipolicy BETWEEN ? AND ?)");

    sprintf(stmt,"%s %s %s %s %s %s",
           "SELECT iins_type, drate_ym, sum(minjured_cover), sum(mdeath_cover),",
                  "sum(mdamage_cover), sum(mdeduct), sum(mins_premium),trim(nvl(provision,' '))||';' ",
             "FROM ply_ins_type ",
            "WHERE ipolicy IN(SELECT ipolicy FROM ply_relation ",
                              stmt_type,
                              "GROUP BY iins_type, drate_ym");
    printf("%s\n",stmt);
    $PREPARE CUR8_1 FROM $stmt;
    $DECLARE curh_1 CURSOR FOR CUR8_1;

    if (strncmp(str_type,"b",1) == 0)
    	$OPEN curh_1 USING $ipolicy1,$ibatch_no;
    else
      $OPEN curh_1 USING $sIpolicy,$ply_end;
    for(;;)
    {
        $FETCH curh_1
          INTO $iins_type,$drate_ym,$injured_cover,$death_cover,
               $damage_cover,$deduct,$provision,
               $ins_premium;
        if (SQLCODE == SQLNOTFOUND)
            break;

        strcpy(f980401," ");
        /* car9803301 �P�_�ϥηs�¶O�v(�s�O�v2009/04/01�W�u),�L�X���P���֭�帹 */
        /* �u�n���@�I�بϥηs�O�v,�֭�帹�K�ϥηs�� */
          $SELECT case when drate >= date('04/01/2009') then '1' else '0' end
             INTO $f980401
             FROM ca_rate_date
            WHERE icode  = $drate_ym
              AND itable = 'cm_extra_charge';
          if (SQLCODE == SQLNOTFOUND)  return M_CA_EXTRA_CHARGE_DRATE;

          if( f980401[0] == '1')
          {
          	strcpy(flag980401,f980401);
          }
        /* end of car9803301 */

        strcpy(f980401," ");



        /* SELECT�O�I����,�D�n���I����,�O�I���B,�ۭt�B�C�L���� */
           $SELECT nins_type,edomain2,qcoverage,cover_print,fdeduct,deduct_print,fcal_way
              INTO $nins_type,$main_paid,$qcoverage,$cover_print,$fdeduct,$deduct_print,$sFcal_way
              FROM insurance_type
             WHERE iins_type = $iins_type;

        /*�I��56 �������B���P����I�� 103.11.11*/
        /*�I��136 104.04.24 (1040407003_C2)*/
        /* 166�I�حn�L�W�U (1090921003_SC1) */
        if (strcmp(trim(iins_type),"56") == 0 || strcmp(trim(iins_type),"136") == 0 || strcmp(trim(iins_type),"166") == 0 || strcmp(trim(iins_type),"266") == 0)
        {
            if (strcmp(trim(iins_type),"56") == 0)
                strcpy(sNassured_56_136,"56 �Q�O�I�H:");
            else if(strcmp(trim(iins_type),"136") == 0)
                strcpy(sNassured_56_136,"136�Q�O�I�H:");
            else if(strcmp(trim(iins_type),"166") == 0)
                strcpy(sNassured_56_136,"166�Q�O�I�H:");
            else
                strcpy(sNassured_56_136,"266�Q�O�I�H:");

            $SELECT distinct iins_scope
               INTO $iins_scope_56
               FROM ca_pa_ply
              WHERE ipolicy = $ipolicy
                AND iins_type in ('56','136','166','266')
                AND (nvl(fedr_status,'') != '1' AND 
                     nvl(fedr_status,'') != '2' AND
                     nvl(fedr_status,'') != '3');

            if((strcmp(trim(iins_scope_56),"2")==0))
            {
            	qcoverage = 2; /* 56�I�ؤ������B���P����I�� */
                strcpy(cover_print,"�ˮ`�����Ф��B��;���G����");
            }
            else if((strcmp(trim(iins_scope_56),"3")==0))
            {
            	qcoverage = 2; /* 56�I�ؤ������B���P����I�� */
                strcpy(cover_print,"�ˮ`�����й���I��;���G����");
            }
        }


        /* �I��52,53,55,24 �O�v�ͮĤ� >- '04/06/2011', �A�ηs�� add by sylvia 100.03.29 (1000323008)*/
        if ((strcmp(trim(iins_type),"24") == 0) || (strcmp(trim(iins_type),"52") == 0) ||
            (strcmp(trim(iins_type),"53") == 0) || (strcmp(trim(iins_type),"55") == 0) ||
            (strcmp(trim(iins_type),"135") == 0))
        {
          if(strcmp(sFcal_way,"1") == 0)
            {
               $SELECT case when drate >= date('04/06/2011') then '1' else '0' end
                  INTO $f52535524
                  FROM ca_rate_date
                 WHERE icode  = $drate_ym
                   AND itable = 'ca_rate';
            }
            else
            {
               $SELECT case when drate >= date('04/06/2011') then '1' else '0' end
                  INTO $f52535524
                  FROM ca_rate_date
                 WHERE icode  = $drate_ym
                   AND itable = 'cover_vs_premium';
            }
          if (SQLCODE == SQLNOTFOUND)  return M_CA_EXTRA_CHARGE_DRATE;


           /* �I��52,53,55,24 �s�¦��t add by sylvia 100.03.29 */
           if (strcmp(f52535524,"0") == 0)
           {   /* �A���¨� �O�v�ͮĤ� < 04/06/2011 */
               if (strcmp(trim(iins_type),"24")==0)
                  strcpy(nins_type,"���s���v�T���ר��`�H���v�I");
               else if (strcmp(trim(iins_type),"52")==0)
               {
                  strcpy(nins_type,"���D�d���I");
                  qcoverage = 3; /* �¨3�ӫO�B--���,���`,�ƬG */
                  strcpy(cover_print,"�C�@�H���;�C�@�H���`;�C�@�N�~�ƬG���`�B");
               }
               else if (strcmp(trim(iins_type),"53")==0)
               {
                  qcoverage = 3; /* �¨3�ӫO�B--���,���`,�ƬG */
                  strcpy(cover_print,"�C�@�H���;�C�@�H���`;�C�@�N�~�ƬG���`�B");
               }
               else if (strcmp(trim(iins_type),"55")==0 || strcmp(trim(iins_type),"135")==0)
               {
                  qcoverage = 3; /* �¨3�ӫO�B--���,���`,�ƬG */
                  strcpy(cover_print,"�C�@�H���;�C�@�H���`�Υ���;�C�@�N�~�ƬG���`�B");
               }

           }
           else
           {   /* �A�ηs�� �O�v�ͮĤ� >= 04/06/2011 (�̳]�w�ɦC�L) */
               printf("-------------- �A�ηs�� �O�v�ͮĤ� > 04/06/2011 ---------\n");
               if (strcmp(trim(iins_type),"52")==0)
               {
                  if (fcar_class[0] == '1')
                  {
                     strcpy(nins_type,"���D�d�����[����");
                  }
                  else
                  {
                     strcpy(nins_type,"�T�����D�d���O�I");
                  }
               }
           }
         }

         /* �I��62,63,64 �O�v�ͮĤ� >= '12/01/2012', �A�ηs�� add by sylvia 101.12.25 (1011214002_C1)*/
         /* �s�W143�I�� add by �L�� 104.12.14 (1041203004_C2)*/
        if ((strcmp(trim(iins_type),"62") == 0) || (strcmp(trim(iins_type),"63") == 0) ||
            (strcmp(trim(iins_type),"64") == 0) || (strcmp(trim(iins_type),"143") == 0))
        {
               $SELECT case when drate >= date('12/01/2012') then '1' else '0' end
                  INTO $f626364
                  FROM ca_rate_date
                 WHERE icode  = $drate_ym
                   AND itable = 'cover_vs_premium';

          	if (SQLCODE == SQLNOTFOUND)  return M_CA_EXTRA_CHARGE_DRATE;

           	/* �I��62,63,64 �s�¦��t add by sylvia 101.12.25 (1011214002_C1) */
           	if (strcmp(f626364,"0") == 0)
           	{   /* �A���¨� �O�v�ͮĤ� < 12/01/2012 */
               if (strcmp(trim(iins_type),"62")==0)
               {
                  qcoverage = 1; /* �¨�u��1�ӫO�B--�ƬG */
                  strcpy(cover_print," ");
               }
               else if (strcmp(trim(iins_type),"63")==0)
               {
                  qcoverage = 1; /* �¨�u��1�ӫO�B--�ƬG */
                  strcpy(cover_print," ");
               }
               else if (strcmp(trim(iins_type),"64")==0)
               {
                  qcoverage = 1; /* �¨�u��1�ӫO�B--�ƬG */
                  strcpy(cover_print," ");
               }

           }
           else
           {   /* �A�ηs�� �O�v�ͮĤ� >= 12/01/2012 (�̳]�w�ɦC�L) */
               printf("-------------- �A�ηs�� �O�v�ͮĤ� > 12/01/2012 ---------\n");
               /* ��car108�]�w: 62,63,64�O�B��2��--��ˡB�ƬG, �O�B��r�̳]�w�ɳ]�w */
            }
         }

         /* �P�_�I��47 �O�v�ͮĤ� >= '03/01/2020', �I�ئW�٨̳]�w�ɦC�L*/
         /*            �O�v�ͮĤ� <  '03/01/2020', �I�ئW�٦C�L�u�����r�p�H�ˮ`�O�I�v*/
         /* 1081205009_SC4_�t�X47�I�رq�D�I�אּ���[�I�A�ק���s/E�O��/B2B/B2C�ˮ�(�Цb12�멳����)*/
         if (strcmp(trim(iins_type),"47") == 0 )
         {

            if (atoi(drate_ym) < 111)
            {   
               /*�����C�L�u�����r�p�H�ˮ`�O�I�v*/
               strcpy(nins_type,"�����r�p�H�ˮ`�O�I");
            }
            else
            {  
               /* ��car108�]�w*/
            }
         }/* end 47 �I�� */

        /* end of select */

        /* �B�z�h�ӫO�B,���N�I�ؤ����O�B����";"�����j�Ÿ���} */
           ptr = strtok(cover_print,";");
           while (ptr != NULL)
           {
                 strcpy(prt_coverage,ptr);
                 strcpy(prt_coverage,trim(prt_coverage));
                 $INSERT INTO tbl_coverage (ipolicy,contain1) VALUES ($ipolicy,$prt_coverage);
            	  ptr = strtok(NULL,";");
            }
        /* End of �B�z�h�ӫO�B�C�L���e */
		
        /* �����¦����s�A�������I�����{���]�w(137�B138�B139�B141�B142�I��) (1100311005_SC6)*/
        iins=atoi(iins_type);
        switch (iins)
        {
            case 1: case 5: case 9: case 8: case 85: case 86: case 105: case 110: case 118: case 120: case 122: case 125: case 126: case 152: case 153: case 161: case 162:
                strcpy(prn_deduct," ");
                if (iins == 118)
                {
                	 $SELECT sum(mins_premium) into $ins_premium
                      FROM ply_ins_type
                     WHERE ipolicy = $ipolicy
                       AND iins_type in ('118','119');
                }
                else if (iins == 120)
                {
                	  $SELECT sum(mins_premium) into $ins_premium
                       FROM ply_ins_type
                      WHERE ipolicy = $ipolicy
                        AND iins_type in ('120','121');
                }
                else if (iins == 122)
                {
                	  $SELECT sum(mins_premium) into $ins_premium
                       FROM ply_ins_type
                      WHERE ipolicy = $ipolicy
                        AND iins_type in ('122','123');
                }
                prem0105=prem0105 + ins_premium;


printf("[01/05]:,prem0105[%d],ins_premium[%ld]\n",prem0105,ins_premium);
                if(prem0105 > 0)
                       strcpy(str_cover1,script1);
                strcpy(str_ins_premium,refmtamt(prem0105,MILLIONTH));
                break;

            case 2: case 3: case 7: case 150:
                /*strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));*/
                strcpy(str_cover1," ");
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                
                if (iins == 150)
                {
                	strcpy(str_cover1,"�̱��ڬ��w");
                	sprintf(tmp_150151,"���m����:%.1f�U",mcar_price);
            		ins_150151 = 1;
                }
                
                break;

            case 10: case 127:
                /*�I��10����ܥX�O�B,only����I���ɩҳ]�w���O�B�C�L��� */
        	       /*strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));*/
        	       strcpy(str_ins_premium,rtrim(refmtamt(ins_premium,MILLIONTH)));
        	       break;

            case 11: case 129:
                strcpy(prn_deduct," ");
                if(ins_premium > 0)
                     strcpy(str_cover1,script1);
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 12:
                /*�I��12����ܥX�O�B,only����I���ɩҳ]�w���O�B�C�L��� */
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 14:
                ins_14 = 1;
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            /* �����¦����s�A�������I�����{���]�w(137�B138�B139�B141�B142�I��) (1100311005_SC6)*/
            case 15: case 16: case 66: case 67: case 106: case 119: case 121: case 123:
                strcpy(str_cover1,ltoa(qday));
                strcat(str_cover1,"��");
                if (iins != 119 && iins != 121 && iins != 123 )
                {
                  strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                }
                else
                {
                	strcpy(str_cover2,rtrim(refmtamt(injured_cover,MILLIONTH)));
                }
                break;

            case 17: case 130: case 151:
                ins_17=1;
                strcpy(str_ins_premium,rtrim(refmtamt(ins_premium,MILLIONTH)));
                
                if (iins == 151)
                {
                	strcpy(str_cover1,"�̱��ڬ��w");
                	sprintf(tmp_150151,"���m����:%.1f�U",mcar_price);
            		ins_150151 = 1;
                }
                
                break;

            case 18:
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 19:
                ins_19=1;
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 20: case 23: case 111:
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 22: case 112:
                strcpy(str_cover1,refmtamt(damage_cover,MILLIONTH));
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 24: case 88:
                /*�I��24����ܥX�O�B,only����I���ɩҳ]�w���O�B�C�L��� */
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 25:
                if(atoi(ins_premium)>0)
                {
                       strcpy(str_cover1,script1);
                       strcpy(str_cover2,script1);
                }
                break;

            case 29: case 124:
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 30:
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
		strcpy(tmp_deduct,itoa(deduct));
		/*�T�{���[�O24*/    
		$SELECT iins_type
		   INTO $iins_type24
		   FROM ply_ins_type
		  WHERE ipolicy = $ipolicy
		    AND iins_type = '24';
		if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��24�I��*/
		{
			flag24=0;
		}
		else
		{
			flag24=1;
		}	
		/*�T�{���[�O55*/
		$SELECT iins_type
		   INTO $iins_type55
		   FROM ply_ins_type
		  WHERE ipolicy = $ipolicy
		    AND iins_type = '55';
		if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��55�I��*/
		{
			flag55=0;
		}
		else
		{
			flag55=1;
		}
                strcpy(deduct_30,tmp_deduct);
		/*�T�{���[�O49 or 177*/
		$SELECT iins_type
		   FROM ply_ins_type
		  WHERE ipolicy = $ipolicy
		    AND iins_type IN ('49','117');
		if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��49 or 117�I��*/
		{
		    flag49117=0;
		}
		else
		{
		    flag49117=1;
		}
                /*if ((!IsFcomp24(deduct_30)) && (!IsFcomp51(deduct_30)))
                {
                     strcpy(ps_dtl,str_ins_30_1);
                }
                else if (!IsFcomp24(deduct_30))
                {
                     strcpy(ps_dtl,str_ins_30_2);
                }
                else if (!IsFcomp51(deduct_30))
                {
                     strcpy(ps_dtl,str_ins_30_3);
                }*/
                
		if((flag24 == 1) && (flag55 == 1) )
		{
			if ((IsFcomp24(deduct_30)) && (IsFcomp55(deduct_30)))
	                {
	                	strcpy(ps_dtl,"");
	                }
			else if (IsFcomp24(deduct_30))
	                {
	                	strcpy(ps_dtl,str_ins_30_3);
	                }
			else if (IsFcomp55(deduct_30))
	                {
	                	strcpy(ps_dtl,str_ins_30_2);
	                }
			else
	                {
	                	strcpy(ps_dtl,str_ins_30_1 );
	                }
		}
		else if(flag24 == 1)
		{
			if (IsFcomp24(deduct_30))
	                {
	                	strcpy(ps_dtl,"");
	                }
			else
	                {
	                	strcpy(ps_dtl,str_ins_30_2);
	                }		
		}
		else if( (flag55 == 1) ||(flag49117 == 1))
		{
			if (IsFcomp55(deduct_30))
	                {
	                	strcpy(ps_dtl,"");
	                }
			else
	                {
	                	strcpy(ps_dtl,str_ins_30_3);
	                }		
		}
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;
                
            case 301:
		/*�T�{���[�O55*/
		$SELECT iins_type
		   INTO $iins_type55
		   FROM ply_ins_type
		  WHERE ipolicy = $ipolicy
		    AND iins_type = '55';
		if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��55�I��*/
		{
			flag55=0;
		}
		else
		{
			flag55=1;
		}		
                strcpy(str_cover1,rtrim(refmtamt(injured_cover,MILLIONTH)));
                strcpy(str_cover2,rtrim(refmtamt(damage_cover,MILLIONTH)));
                strcpy(tmp_deduct,itoa(deduct));
                strcpy(deduct_301,tmp_deduct);
                if(flag55 == 1)
                {
                	if (IsFcomp55(deduct_301))
                	{
                   		strcpy(ps_dtl,"");
                   	}
                   	else
                   	{
                   		strcpy(ps_dtl,str_ins_301_1);
                   	}
                }
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 31: case 36: case 113: case 131: case 331:
                if(ins_premium > 0)
                {
                      strcpy(str_cover1,script1);
                      strcpy(str_cover2,script1);
                }
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                ins_31_multiple = damage_cover / injured_cover;                
                break;

            case 32: case 37: case 78: case 89: case 90: case 114: case 132: case 149:
                if(ins_premium > 0)
                      strcpy(str_cover1,script1);
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 34: case 87: case 115:
                /* �Ψ�Ū�����ݪ��I�ت��O�B�O�O */
                   insurance_cover_count = 0;
                   $SELECT COUNT(*)
           				 INTO $insurance_cover_count
                      FROM insurance_cover
                     WHERE iins_type = $iins_type;
                /* �������ݪ����Ū�� */

                /* �ΨӳB�z�I��34 */
                if( insurance_cover_count != 0)
                {    /* CA_CONS */
                         IcurrPlyInsCover = move_ply_ins_cover_curr2( IfirstPlyInsCover, &iins, "001");
                         strcpy(str_cover1, refmtamt(IcurrPlyInsCover->mcover));
                         lPremSum += IcurrPlyInsCover->mcover_prem;

                         IcurrPlyInsCover = move_ply_ins_cover_curr2( IfirstPlyInsCover, &iins, "002");
                         /*sprintf( sTmp, "%.2f�U", (double)IcurrPlyInsCover->mcover/10000);*/
                         /*strcpy(str_cover2, sTmp);*/
                         strcpy(str_cover2, refmtamt(IcurrPlyInsCover->mcover));
                         lPremSum += IcurrPlyInsCover->mcover_prem;

                         IcurrPlyInsCover = move_ply_ins_cover_curr2( IfirstPlyInsCover, &iins, "003");
                         strcpy(str_cover3, refmtamt(IcurrPlyInsCover->mcover));
                         lPremSum += IcurrPlyInsCover->mcover_prem;

                         IcurrPlyInsCover = move_ply_ins_cover_curr2( IfirstPlyInsCover, &iins, "004");
                         /*sprintf( sTmp, "%.2f�U", (double)IcurrPlyInsCover->mcover/10000);*/
                         /*strcpy(str_cover4, sTmp);*/
                         strcpy(str_cover4, refmtamt(IcurrPlyInsCover->mcover));

                         strcpy(str_ins_premium,refmtamt( lPremSum,MILLIONTH)); /* �L�X���I�ؤ��P�O�B�X�p���O�O */
                }
                break;

            case 35: 
                $SELECT distinct iins_scope
                   INTO $tmp_iins_scope
                   FROM ca_pa_ply
                  WHERE ipolicy = $ipolicy AND iins_type = '35'
                    AND mins_amt > 0;

                strcpy(nins_type,trim(nins_type));

                if( strcmp(trim(tmp_iins_scope),"1") == 0 )
                     strcat(nins_type,"  �O�W��");
                else if( strcmp(trim(tmp_iins_scope),"2") == 0 )
                     strcat(nins_type,"  �a�x��");


                if (strcmp(trim(tmp_iins_scope),"1") != 0)
                     strcpy(cover_print,"");
                


                break;

            case 48:


                strcpy(str_cover1,refmtamt((damage_cover/10000),MILLIONTH));
                strcat(str_cover1,"�U");
                
                break;

            case 38: case 39:
                strcpy(str_cover1,ltoa(qday));
                strcat(str_cover1,"����");
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;


            case 47: case 147:
                strcpy(str_cover1,refmtamt((injured_cover/10000),MILLIONTH));
                strcat(str_cover1,"�U");
                strcpy(str_cover2,refmtamt((death_cover/10000),MILLIONTH));
                strcat(str_cover2,"�U");
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 49:
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 50:
                strcpy(str_cover1,refmtamt((injured_cover/10000),MILLIONTH));
                strcat(str_cover1,"�U");
                strcpy(str_cover2,refmtamt((death_cover/10000),MILLIONTH));
                strcat(str_cover2,"�U");
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 51: case 55: case 57: case 59: case 60: case 79: case 117: case 135:
                /*�I��51����ܥX�O�B,only����I���ɩҳ]�w���O�B�C�L��� */
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 52:
                if(ins_premium > 0)
                {
                      strcpy(str_cover1,script1);
                      strcpy(str_cover2,script1);
                      strcpy(str_cover3,script1);
                }
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 53:
                if(ins_premium > 0)
                {
                    strcpy(str_cover1,script1);
                    strcpy(str_cover2,script1);
                    strcpy(str_cover3,script1);
                }
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 56: case 80: case 136: case 166: case 266:
                if(ins_premium > 0)
                {
                    strcpy(str_cover1,script1);
                    strcpy(str_cover2,script1);
                }
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            /* �����¦����s�A�������I�����{���]�w(137�B138�B139�B141�B142�I��) (1100311005_SC6)*/
            case 61: case 65: case 69: case 68: case 108:
                strcpy(str_cover1,refmtamt(damage_cover,MILLIONTH));
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 62: case 63: case 64: case 143:
                if(ins_premium > 0)
                {
                			if (qcoverage > 1)
                			{
		                			strcpy(str_cover1,script1);
		                			strcpy(str_cover2,script1);
		                      strcat(str_deduct,refmtamt(deduct,MILLIONTH));
			                  	strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
		                   }
                      else
                      {
			                  strcpy(str_cover1,script1);
			                  strcat(str_deduct,refmtamt(deduct,MILLIONTH));
			                  strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			                }
                }
                break;

            case 71: case 72:
                if (ins_premium > 0)
                {
                  strcpy(str_cover1,script1);
                  strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                }
                break;

            case 77:
                if(ins_premium > 0)
                {
                      strcpy(str_cover1,script1);
                      strcpy(str_cover2,script1);
                }
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 96:
                strcpy(prn_deduct," ");
                if(ins_premium > 0)
                     strcpy(str_cover1,script1);

                /* Ū��96+97�O�O */
                $SELECT sum(mins_premium) into $ins_premium
                   FROM ply_ins_type
                  WHERE ipolicy = $ipolicy
                    and iins_type in ('96','97');
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                break;

            case 97:
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
                break;

            /* �����¦����s�A�������I�����{���]�w(137�B138�B139�B141�B142�I��) (1100311005_SC6)*/
            case 107:
		strcpy(str_cover1,script1);
          	strcpy(str_cover2,script1);
                strcat(str_deduct,refmtamt(deduct,MILLIONTH));
              	strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
              	break;
			
	    case 154: case 155: case 156:
		strcpy(str_cover1,ltoa(qday));
                strcat(str_cover1,"��");
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                strcpy(str_cover2,rtrim(refmtamt(injured_cover,MILLIONTH)));
                break;

		
            default:
                if (ins_premium > 0)
                {
                  strcpy(str_cover1,script1);
                  strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                }
                break;

        }  /* end of switch */
        

        /* �N�C�L����Ʃ�J�Ȧstable */
         /* �Y�O�B���@�ӥH�W���ɭ�,�n�̷ӫO�B�Ӽƨ̧ǩ�J�Ȧs���C�Ltable */
         if (qcoverage > 1)
         {
         	 /* �h�ӫO�B */
              $DECLARE cur_coverage2 CURSOR for
               SELECT serial_no,contain1 FROM tbl_coverage WHERE ipolicy = $ipolicy ORDER BY 1;

               j = 0;

               $OPEN cur_coverage2;
               while (1)
               {
                 	$FETCH cur_coverage2 INTO $contain_coverage;

                 	if (SQLCODE == SQLNOTFOUND) break;

                 	strcpy(cover_print,trim(contain_coverage));
                 	strcat(cover_print," ");
                 	if(j==0)
                 		/*strcat(cover_print,str_cover1);*/
                 		strcpy(amt_print,str_cover2);
                  else if (j==1)
                  {
                 		strcpy(amt_print,str_cover2);
                 		strcpy(iins_type,"");
                 		strcpy(nins_type,"");
                 		strcpy(main_paid,"");
                 		strcpy(str_deduct,"");
                 	}
                  else if (j==2)
                  {
                 		strcpy(amt_print,str_cover3);
                 		strcpy(iins_type,"");
                 		strcpy(nins_type,"");
                 		strcpy(main_paid,"");
                 		strcpy(str_deduct,"");
                 	}
                 	else
                 	{
                 	   strcpy(amt_print,str_cover4);
                 	   strcpy(iins_type,"");
                 		strcpy(nins_type,"");
                 		strcpy(main_paid,"");
                 		strcpy(str_deduct,"");
                 	}

                  /* �h�O�B���ɭ�,�̫�@��~�|�L�X�O�O */
                     if (j > 0)
                     {    strcpy(str_ins_premium,"");
                          ins_premium = 0;
                     }
                  /* end of �h�O�B�O�O�B�z */

                  insert_prt_table(ipolicy,iins_type,nins_type,main_paid,cover_print,amt_print,str_deduct,str_ins_premium,
                                   ins_premium);
                  j++;
                 }
                 $CLOSE cur_coverage2;
                 $FREE cur_coverage2;
         }
         else if (strcmp(iins_type, "96")==0)
         {
            /* �n�g�J�G��:�Ĥ@�欰�D�I��-�I�إN��96,�D�n�I�ئW��,�D�n���I����,96+97�`�O�O;
                          �ĤG�欰96�I��:�I�ئW��,�O�B,�ۭt�B */
            strcpy(cover_print,trim(cover_print));
         	strcpy(amt_print,str_cover1);

            /* �Ĥ@�� */
            insert_prt_table(ipolicy,iins_type,"�T���ѵs�l���O�I(�ҫ�)","�ꨮ�ߥI�B�]���l���O�I���B�N���O��",
                               " "," "," ",str_ins_premium,ins_premium);

            /* �ĤG�� */
            sprintf(sNinstype2, "  %s",nins_type);
            insert_prt_table(ipolicy," ",sNinstype2," ",cover_print,amt_print,str_deduct," ", 0);
         }
         else if (strcmp(iins_type, "97")==0)
         {
            /* �g�J97�I��:�W��,�O�B,�ۭt�B */
            strcpy(cover_print,trim(cover_print));
         	strcpy(amt_print,str_cover1);
         	sprintf(sNinstype2, "  %s",nins_type);
            insert_prt_table(ipolicy," ",sNinstype2," ",cover_print,amt_print,str_deduct," ", 0);
         }
         else
         {
         	 if (strlen(cover_print) > 0)
         	 	printf("�O�B���L�X�I���ɩҳ]�w�����e\n");
         	 else
         	  strcpy(cover_print,refmtamt(damage_cover));

         	 /* 119��121�I�ت��O�O�w�[�`�b118��120�I�� add by larry 103.08.05 (1030725001_C5) */
         	 /* 123�I�ثO�O�w�[�`�b122�I�ثO�O add by larry 103.08.12 (1030806001_C2)*/
         	 /* 139�I�ت��O�O�w�[�`�b138�I�� add by larry 104.05.21 (1040515009_C2) */
           if (strcmp(iins_type, "119") == 0 || strcmp(iins_type, "121") == 0 || strcmp(iins_type, "123") == 0)
           {
                strcpy(iins_type,"");
                strcpy(cover_print,"");
                strcpy(amt_print,"");
                sprintf(cover_print,"�O�������Ѩ����ΨC��%s���G�̦X�p�̰�%s ",str_cover2,str_cover1);
                strcpy(str_ins_premium,"");
                ins_premium = 0;
           }
           else if (strcmp(iins_type, "119") == 0 || strcmp(iins_type, "154") == 0 || strcmp(iins_type, "155") == 0 || strcmp(iins_type, "156") == 0 || strcmp(iins_type, "163") == 0)
           {
           		sprintf(cover_print,"�O�������Ѩ����ΨC��%s���G�̦X�p�̰�%s ",str_cover2,str_cover1);
           }

            insert_prt_table(ipolicy,iins_type,nins_type,main_paid,cover_print,amt_print,str_deduct,str_ins_premium,
                             ins_premium);
         }

    } /* end of Ū���I�� */
    $CLOSE curh_1;

printf("end of Ū���I�� \n");
    strcpy(datestr,cm_cdate_str_100(dply_begin));
    cm_split_ymd_100(datestr,yy3,mm3,dd3);

    strcpy(datestr,cm_cdate_str_100(dply_end));
    cm_split_ymd_100(datestr,yy4,mm4,dd4);

    strcpy(s_premium1,refmtamt(premium1,MILLIONTH));

    if ( mpure_prem != 0 )
    {
        real_premium=premium1 + prem21;      /* �X�p�O�O*/
        real1_premium=premium1 + mdiscount;  /* ���N�O�O*/

        strcpy(bak1,refmtamt(premium1,MILLIONTH));       /*����*/
        strcpy(bak3,refmtamt(real1_premium,MILLIONTH));  /*�O�Ototal*/
        strcpy(bak31,refmtamt(real_premium,MILLIONTH));  /*�X�p*/
        strcpy(bak2,refmtamt(mdiscount,MILLIONTH));      /*�u�f*/

        rate = (float)mdiscount / (float)( premium1 + mdiscount ) * 100  + 0.5;
    }
    else
    {
        real_premium=premium1 + prem21 - mdiscount;
        real1_premium=premium1 - mdiscount;

        strcpy(bak3,refmtamt(premium1,MILLIONTH));       /*�O�Ototal*/
        strcpy(bak1,refmtamt(real1_premium,MILLIONTH));  /*�ꦬ*/
        strcpy(bak31,refmtamt(real_premium,MILLIONTH));  /*�X�p*/
        strcpy(bak2,refmtamt(mdiscount,MILLIONTH));      /*�u�f*/

        rate = (float) mdiscount / (float) premium1 * 100 + 0.5;
    }

    if (mdiscount<=0)
    {
        sprintf(s0_real_premium,"                                 %s", bak1);  /*�`�O�I�O    */
        sprintf(s_real_premium,"���N�O�O %s  "                       , bak3);  /*�b��Ĥ@��  */
        sprintf(s1_real_premium,"�O�O %s "                           , bak3);  /*���ڲĤ@��  */
    }
    else
    {
        sprintf(s0_real_premium,"�������O��w�ɦ��O�O�u�f���� %s", bak1);           /*�`�O�I�O    */
        sprintf(s_real_premium,"���N�O�O%s �u�f%s ���N�ꦬ%s"   , bak3,bak2,bak1); /*�b��Ĥ@��  */
        sprintf(s1_real_premium,"�O�O %s  �u�f %s  �ꦬ %s"          , bak3,bak2,bak1); /*���ڲĤ@��  */
    }

    sprintf(s2_real_premium,"%s  �X�p�O�O %s",
    s_prem21,bak31);                                     /*�b��ĤG��  */
    strcpy(s2_real_premium,ltrim(s2_real_premium));
    num_to_chinese(bak_chiness,real_premium);            /*�Ĥ@�p���B����j�g  */
    strcpy(bak_chiness,trim(bak_chiness));
    strcat(bak_chiness,"����");
    printf("bak_chiness :[%s] \n",bak_chiness);

    if(strncmp(ibroker,"ZZZZZ",5)==0)
    {
        strcpy(new_ibroker,ibroker);
        strcpy(dsc_ibroker,"������O����");
    }
    else
    {
        strcpy(new_ibroker,ibroker);
        strcpy(dsc_ibroker," ");
    }

    ipolicy[13]=0;
    if(ipolicy[0]!=' ' && ipolicy[0]!='\0')
    {
        strcat(ipolicy,"-");
        sprintf(ipolicy,"%s%d",ipolicy,ibatch_no);
    }

    ipolicy1[13]=0;


    /* �Y��56.136�I��,�hŪ���X�Q�O�I�H�W�U������� */
    /*166�I�حn�L�W�U (1090921003_SC1) */
    if (ins_56 == 1 && list_print == 0)
    {
      $DECLARE ca_cur1 CURSOR for
     	 SELECT iins_type,iinsurant,ninsurant,dbirth,nbeneficiary,relation_bene,tbenef,abenef
         FROM ca_pa_ply
        WHERE ipolicy = $sIpolicy
          AND iins_type in ('56','136','166','266')
          AND mins_amt > 0;

       $OPEN ca_cur1;
        while(1)
        {
        
            $FETCH ca_cur1 INTO $iins_type56,$iinsurant56,$ninsurant56,$dbirth56,$nbeneficiary56,$relation_bene56,$tbenef56,$abenef56;
          	

            /* line66 and line67�O�ӽT�{}�Q�O�I�H�W�U�O�_�ݭn�C�L */
            if (SQLCODE == SQLNOTFOUND)
            {
            	
                 line66 = 1;
                 line67 = 1;
                 list_cnt = 1;
                 break;
             }
             $INSERT INTO tbl_56list (ipolicy,iins_type,iinsurant,ninsurant,dbirth,nbeneficiary,relation_bene,tbenef,abenef) 
                   VALUES ($sIpolicy,$iins_type56,$iinsurant56,$ninsurant56,$dbirth56,$nbeneficiary56,$relation_bene56,$tbenef56,$abenef56);
             
         }
         $CLOSE ca_cur1;
         $FREE ca_cur1;
    }
    else
    {
    	 line66 = 1;
         line67 = 1;
         list_cnt = 1;
    	
    }
    /* end of Ū��56 */

    return M_CM_OK;
errexit:
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    return SQLCODE;
}

/*int get_18_6x_prt_deduct(gins_type,gprn_deduct)
char *gins_type;
char *gprn_deduct;
{
int  rtn;
char sTmpBuf[20];
char start_18[3];

     rtn = 0;
     if (strncmp(gins_type,"18",2) == 0)
     {
 strncpy(sTmpBuf,gprn_deduct+2,2);
 sTmpBuf[2] = '\0';
 strcat(sTmpBuf,"%");
 strcat(sTmpBuf,"(�_���B");
 strncpy(start_18,gprn_deduct,2);
 start_18[2] = '\0';
        strcat(sTmpBuf,start_18);
        strcat(sTmpBuf,"%)");
        strcpy(gprn_deduct,sTmpBuf);
        rtn = 1;
     }
     else if ((strncmp(gins_type,"62",2) == 0) ||
              (strncmp(gins_type,"63",2) == 0) ||
              (strncmp(gins_type,"64",2) == 0))
     {
        strcpy(sTmpBuf,"���ݮɶ�");
        strcat(sTmpBuf,trim(gprn_deduct));
        strcat(sTmpBuf,"�p��");
        strcpy(gprn_deduct,sTmpBuf);
        rtn = 1;
     }

     return rtn;
} */
/*--------------------------------------------------------------------------------*/

int IsFcomp24(str)
char *str;
{
    while (*str)
    {
        if (*str == '2')
        {
           str++;
           if (*str == '4')
           {
              return TRUE;
           }
           else
           {
              str--;
           }
        }
        str++;
    }
    return FALSE;
}

int IsFcomp55(str)
char *str;
{
    while (*str)
    {
        if (*str == '5')
        {
           str++;
           if (*str == '5') /* original version is if (*str == '1') */
           {
              return TRUE;
           }
           else
           {
              str--;
           }
        }
        str++;
    }
    return FALSE;
}

/*--------------------------------------------------------------------------------*/
long insert_prt_table(ipolicy,iins_type,nins_type,main_paid,cover_print,amt_print,prn_deduct,str_ins_premium,
                                   ins_premium)
$char ipolicy[21];
$char iins_type[7];
$char nins_type[121];
$char main_paid[251];
$char cover_print[121];
$char amt_print[121];
$char prn_deduct[121];
$char str_ins_premium[121];
$long ins_premium;
{
      $WHENEVER SQLERROR GOTO errexit;


      printf("ipolicy=[%s],iins_type=[%s],nins_type=[%s],main_paid=[%s]\n",
              ipolicy,iins_type,nins_type,main_paid);
      printf("cover_print=[%s],amt_print=[%s],prn_deduct=[%s],str_ins_premium=[%s]\n",
              cover_print,amt_print,prn_deduct,str_ins_premium);
      printf("ins_premium=[%ld]\n",ins_premium);

printf("insert table tbl_print...................................\n");
		$INSERT INTO tbl_print
		  (ipolicy,field1,field2,field3,field4,field5,field6,field7, ins_premium)
		 VALUES
		  ($ipolicy,$iins_type,$nins_type,$main_paid,$cover_print,$amt_print,$prn_deduct,$str_ins_premium,
                   $ins_premium);
printf("end of insert......................\n");

errexit:
    return SQLCODE;
}

/*--------------------------------------------------------------------*/
long process_rpt()
{
	$double i;
	$int ser_no;
	$double max_line_no;
	$int cnt_56list;
	$char field1[7],field2[121],field3[251],field4[121],field5[121],field6[121],field7[121];
	$int  len1,len2,len3,len4,len5,len6,len7;
	$char    tmp_ipolicy[21],tmp_field1[7],tmp_field2[121],tmp_field3[251],tmp_field4[121],tmp_field5[121],tmp_field6[121],tmp_field7[121];
	$char    tmp_relation_bene[16],tmp_tbenef[21],tmp_abenef[91],tmp_nbeneficiary[38];
	$char    stmp_abenef1[38],stmp_abenef2[38],stmp_abenef3[38];
	$char    tmp_address[91];
	$char    address1[10],address2[11],address3[13],address4[14],address5[10],address6[11],address7[13],address8[14];
        $int     tmp_ins_premium;
        $int     itmp_abenef1,itmp_abenef2,itmp_abenef3,count_abenef;


        $WHENEVER SQLERROR GOTO errexit;

        printf("get into process_rpt\n");
        $DECLARE tmp_cur CURSOR for
          SELECT line_no,nvl(field1,' '),nvl(field2,' '),nvl(field3,' '),nvl(field4,' '),
                 nvl(field5,' '),nvl(field6,' '),nvl(field7,' '),
                 length(field1),length(field2),length(field3),length(field4),
                 length(field5),length(field6),length(field7), ins_premium
            FROM tbl_print
           WHERE ipolicy = $ipolicy;

        $OPEN tmp_cur;
        while (1)
        {
            $FETCH tmp_cur INTO $ser_no,
                 		$field1,$field2,$field3,$field4,$field5,$field6,$field7,
                 		$len1,$len2,$len3,$len4,$len5,$len6,$len7,$ins_premium;

            if (SQLCODE == SQLNOTFOUND) break;
            /*printf("********************************************************\n");
              printf("serino[%d]:[%d][%s][%d][%s][%d][%s][%d][%s][%d][%s][%d][%s][%d][%s],ins_premium[%d],[%s]\n",
                      ser_no,
                 	len1,field1,
                 	len2,field2,
                 	len3,field3,
                 	len4,field4,
                 	len5,field5,
                 	len6,field6,
                 	len7,field7, ins_premium, ipolicy);*/
        }
        $CLOSE tmp_cur;
        $FREE tmp_cur;
        printf("finish print...................................\n");


        $Update tbl_print set
   	        field1 = Nvl(field1,''),
   	        field2 = Nvl(field2,''),
   	        field3 = Nvl(field3,''),
   	        field4 = Nvl(field4,''),
   	        field5 = Nvl(field5,''),
   	        field6 = Nvl(field6,''),
   	        field7 = Nvl(field7,'')
          WHERE ipolicy = $ipolicy;

        i = 0.0;
	printf("get into while\n");
        while(1)
        {
            puts("in while 1");
	    i += 0.01;

	    $INSERT INTO print_layout
	     SELECT ipolicy, line_no + $i,
		    field1[1,3],
		    field2[1,16],
		    field3[1,14],
		    field4[1,20],
		    field5[1,10],
		    field6[1,12],
		    field7[1,8],
                    ins_premium,
                    ''
	       FROM tbl_print
              WHERE ipolicy = $ipolicy;

	    printf("i=[%f]\n,tcount=[%d]\n",i,sqlca.sqlerrd[2]);
	    if(sqlca.sqlerrd[2] == 0) break;

	    $UPDATE tbl_print SET
		    field1 = field1[4,6],
		    field2 = field2[17,120],
		    field3 = field3[15,250],
		    field4 = field4[21,120],
		    field5 = field5[11,120],
		    field6 = field6[13,120],
		    field7 = field7[9,120],
                    ins_premium = 0
              WHERE ipolicy = $ipolicy;

	    $DELETE tbl_print
	      WHERE field1 || field2 || field3 || field4 || field5 || field6 || field7 = ''
                AND ipolicy = $ipolicy;
        }

        printf("finish process_rpt\n");
        
        
        /*tbl_56list �g�J print_layout*/
        $SELECT count(*) INTO $cnt_56list FROM tbl_56list WHERE ipolicy = $ipolicy AND ninsurant!='' AND iinsurant!='1';
        printf("cnt_56list[%d]\n",cnt_56list);
        if(cnt_56list==0 )
        {
           /*do Nothing  */               
        }
        else
        {
            $SELECT max(line_no) INTO $max_line_no FROM print_layout WHERE ipolicy = $ipolicy;                       
            $INSERT INTO print_layout (ipolicy,line_no,field1,field2,field3,field4,field5,field6,field7,ins_premium,field_tmp) 
                               VALUES ($ipolicy,$max_line_no+1,'','','','','','','',0,''); 
            $INSERT INTO print_layout (ipolicy,line_no,field1,field2,field3,field4,field5,field6,field7,ins_premium,field_tmp) 
                               VALUES ($ipolicy,$max_line_no+2,'�i','�r�p�H�ˮ`�I�W�U','�j','','','','',0,'');               
        
        if (strncmp(sProtectData,"0",1) != 0)/*�B�n*/
        {
            $DECLARE cur_56list1 CURSOR for
                  SELECT ipolicy,
                        iins_type,
                        '�Q�O�H:'||trim(ninsurant),
                        case when dbirth='' then '�ͤ�:' when dbirth='01/01/1912' then '�ͤ�:' when dbirth is null then '�ͤ�:' else '�ͤ�:**/'||to_char(dbirth,'%m')||'/**' end ,
                        case when trim(iinsurant)='' then '�����Ҹ�:' else'�����Ҹ�:'||trim(iinsurant[1,4])||'****'||trim(iinsurant[9,10]) end,
                        '���q�H:'||trim(nbeneficiary),
                        0,
                        relation_bene,
                        case when trim(tbenef)='' then '�q��:' else '�q��:'||tbenef[1,3]||'XXXX'||tbenef[8,12] end,
                        abenef
                   FROM tbl_56list 
                  WHERE ipolicy = $ipolicy AND trim(ninsurant)!='' AND trim(iinsurant)!='1';        	
	    $OPEN cur_56list1;
        }
        else  /*���B�n*/
        {
            $DECLARE cur_56list2 CURSOR for
                  SELECT ipolicy,
                        iins_type,
                        '�Q�O�H:'||trim(ninsurant),
                        case when dbirth='' then '�ͤ�:' when dbirth='01/01/1912' then '�ͤ�:' when dbirth is null then '�ͤ�:' else '�ͤ�:'|| to_char(year(dbirth)-1911)||to_char(dbirth,'/%m/%d') end ,
                        case when trim(iinsurant)='' then '�����Ҹ�:' else'�����Ҹ�:'||trim(iinsurant) end,
                        '���q�H:'||trim(nbeneficiary),
                        0,
                        relation_bene,
                        '�q��:'||tbenef[1,12],
                        abenef
                   FROM tbl_56list 
                  WHERE ipolicy = $ipolicy AND trim(ninsurant)!='' AND trim(iinsurant)!='1'; 
        	
            $OPEN cur_56list2;
        }
  

        
            $int p;
            for(p=0;p<cnt_56list;p++)
            {
            	 if (strncmp(sProtectData,"0",1) != 0)/*�B�n*/
                 {
            	    $FETCH cur_56list1 INTO $tmp_ipolicy,$tmp_field1,$tmp_field2,$tmp_field3,$tmp_field4,$tmp_nbeneficiary,$tmp_ins_premium,
            	                            $tmp_relation_bene,$tmp_tbenef,$tmp_abenef;
                 }
                 else
                 {
            	    $FETCH cur_56list2 INTO $tmp_ipolicy,$tmp_field1,$tmp_field2,$tmp_field3,$tmp_field4,$tmp_nbeneficiary,$tmp_ins_premium,
            	                            $tmp_relation_bene,$tmp_tbenef,$tmp_abenef;        	
                 }

          	                       
          	
          	/*�W�U�Ĥ@��:�Q�O�H�B�ͤ�B�����Ҹ��B���q�H*/  

       	
            	$INSERT INTO print_layout (ipolicy,line_no,field1,field2,field3,field4,field5,field6,field7,ins_premium,field_tmp)
            	       VALUES ($tmp_ipolicy,$max_line_no+3+$p,$tmp_field1,$tmp_field2,$tmp_field3,$tmp_field4,'','','',$tmp_ins_premium,$tmp_nbeneficiary);
            	       
            	  		
            	/*�W�U�ĤG��:���Y�B�q�ܡB�a�}�Ĥ@�q*/       		
            	if (strncmp(tmp_relation_bene,"1",1)==0) strcpy(tmp_relation_bene,"���Y:���H");
            	else if (strncmp(tmp_relation_bene,"2",1)==0) strcpy(tmp_relation_bene,"���Y:�a��");
            	else if (strncmp(tmp_relation_bene,"3",1)==0) strcpy(tmp_relation_bene,"���Y:�O�Υ����H");
            	else if (strncmp(tmp_relation_bene,"4",1)==0) strcpy(tmp_relation_bene,"���Y:�ŰȤH");
            	else if (strncmp(tmp_relation_bene,"5",1)==0) strcpy(tmp_relation_bene,"���Y:�]���޲z�H");
            	else if (strncmp(tmp_relation_bene,"6",1)==0) strcpy(tmp_relation_bene,"���Y:�k�w�~�ӤH");
            	else if (strncmp(tmp_relation_bene,"7",1)==0) strcpy(tmp_relation_bene,"���Y:�t��");
            	else if (strncmp(tmp_relation_bene,"8",1)==0) strcpy(tmp_relation_bene,"���Y:���t����");
            	else strcpy(tmp_relation_bene,"");
            	
            	
            	/*�a�}�_��B�z*/
		itmp_abenef1 = itmp_abenef2 = itmp_abenef3  = 0;
		count_abenef = 0;
		
		itmp_abenef1 = iGetChinesePos(tmp_abenef,30);
		strcpy(stmp_abenef1,"");
		strncpy(stmp_abenef1,tmp_abenef,itmp_abenef1+1);
		stmp_abenef1[itmp_abenef1+1] = '\0';
		count_abenef = count_abenef + itmp_abenef1 + 1;
	 	
	 	if (count_abenef <= strlen(tmp_abenef))
	 	{
	 	    itmp_abenef2 = iGetChinesePos(tmp_abenef+count_abenef,30);
	 	    strcpy(stmp_abenef2,"");
	 	    strncpy(stmp_abenef2,tmp_abenef+count_abenef,itmp_abenef2+1);
	 	    stmp_abenef2[itmp_abenef2+1] = '\0';
	 	    count_abenef = count_abenef + itmp_abenef2 + 1;
	 	}
	 	else strcpy(stmp_abenef2,"");
	 	
	 	if (count_abenef <= strlen(tmp_abenef))
	 	{
	 	    itmp_abenef3 = iGetChinesePos(tmp_abenef+count_abenef,30);
	 	    strcpy(stmp_abenef3,"");
	 	    strncpy(stmp_abenef3,tmp_abenef+count_abenef,itmp_abenef3+1);
	 	    stmp_abenef3[itmp_abenef3+1] = '\0';
	 	    count_abenef = count_abenef + itmp_abenef3 + 1;
	 	}
	 	else strcpy(stmp_abenef3,"");
	 	
	 	printf("���q�H�a�}[%s][%s][%s]\n",stmp_abenef1,stmp_abenef2,stmp_abenef3);
            	
            	       
            	strcpy(tmp_tbenef,trim(tmp_tbenef));
            	
            	$INSERT INTO print_layout (ipolicy,line_no,field1,field2,field3,field4,field5,field6,field7,ins_premium,field_tmp)
            	       VALUES ($tmp_ipolicy,$max_line_no+3.1+$p,'',$tmp_relation_bene,$tmp_tbenef,'','','','',$tmp_ins_premium,'�a�}:'||$stmp_abenef1);
            	       
            	/*�W�U�ĤT��:�a�}�ĤG�q*/ 
            	if  (strcmp(trim(stmp_abenef2),"")!=0)
            	{
            	    $INSERT INTO print_layout (ipolicy,line_no,field1,field2,field3,field4,field5,field6,field7,ins_premium,field_tmp)
            	           VALUES ($tmp_ipolicy,$max_line_no+3.2+$p,'','','','','','','',$tmp_ins_premium,'     '||$stmp_abenef2);            		
            	}
            	/*�W�U�ĥ|��:�a�}�ĤT�q*/ 
            	if  (strcmp(trim(stmp_abenef3),"")!=0)
            	{
            	    $INSERT INTO print_layout (ipolicy,line_no,field1,field2,field3,field4,field5,field6,field7,ins_premium,field_tmp)
            	           VALUES ($tmp_ipolicy,$max_line_no+3.3+$p,'','','','','','','',$tmp_ins_premium,'     '||$stmp_abenef3);
            	}
            }   
            if (strncmp(sProtectData,"0",1) != 0)/*�B�n*/
            {
                $CLOSE cur_56list1;
                $FREE cur_56list1; 
            }
            else
            {
                $CLOSE cur_56list2;
                $FREE cur_56list2;        	
            }

	
        }
        
        
        return M_CM_OK;


    



errexit:
    printf("process_rpt SQLCODE[%d]\n", SQLCODE);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
/** ���o���^���q�������T���嵲����m **/
int *iGetChinesePos(sStrTmp,iPos)
char *sStrTmp;
int  iPos;
{
   int  iTrueLen;
   int  i,x;

   for(i = 0; i<= iPos; i++){
         if ((int)(sStrTmp[i]) >= 128){
                i++;
         }
   }
   return (i-1);
}
/*--------------------------------------------------------------------*/
/* ���o�r�꥿�T���_��m 
int *iGetPartStr(sInString,iGetlen)
char *sInString;
int  iGetlen;
{
   int i, j;
   i = 0; j = 0 ;
   
   if (strlen(sInString) <= iGetlen)
      i = strlen(sInString);
   else
   {
      for (i = 0 ; i < iGetlen ; i++)
      {
         if ((sInString[i] >= 0x81) && (sInString[i] <= 0xFE))
         {   ����Ĥ@�X 
            j++;
         }
         else if (((sInString[i] >= 0x40) && (sInString[i] <= 0x7E)) ||
                  ((sInString[i] >= 0xA1 ) && (sInString[i] <= 0xFE)))
         {   ����ĤG�X 
            j++;
         }
         else
         {
             �D���� 
            j = 0;
         }         
      }
   }
   
   if ((j == 0) || ((j % 2) == 0))
   {
      return i;
   }
   else
      return (i-1) ;
}*/
/*********************************************************************************/
char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
        char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
        char sTmp_db_name[31];

        sTmp_db_name[0]='\0';
        if (*sIpolicy != '\0' && *sIpolicy !=' ')
        {
           sTmp_db_name[0]='\0';
           strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
           strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
                  USE_BRANCH_ID));
           strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
        }
  return sTmp_db_name;
}
/*********************************************************************************/
