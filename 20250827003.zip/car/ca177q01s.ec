/**********************************************************************/
/*   program id   : ca177q01s.ec                                      */
/*   program name : �t�P�s�պ��@                                */
/*   date written : 2021/09/09 by 101314                              */
/*   files        :                                                   */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <decimal.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "globdata.h"
#include "safeclib.h"

$char ilevel[3];  /*�h��*/
$char icode[11]; /*�N�X*/
$char ncode[41]; /*�W��*/
$char qorder[20]; /*����*/
$char level1[11]; /*�h�Ť@*/
$char level2[11]; /*�h�ŤG*/

$char stmpx[128];

int   count_db,k; 
char  outputf[21];
$char userid[11];
$char DBName[05];
$char msgbuf[128];

DBinfo *list;

main(argc, argv)
int argc;
char **argv;
{
	int rc;
         printf("46:init\n");
	batchinit();
	strcpy(DBName,         isNULLstr(argv[1]));
	strcpy(userid,         isNULLstr(argv[2]));
	strcpy(ilevel,         isNULLstr(argv[3]));  /*�h��*/
	strcpy(icode,           isNULLstr(argv[4]));  /*�N�X*/
	strcpy(level1,           isNULLstr(argv[5])); /*�h�Ť@*/
	/*outputf*/
	strcpy(outputf,        isNULLstr(argv[6]));
	
	rc = car177_get_db();
	if (rc != M_CM_OK)
		return rc;

	rc = car177_prepare_data();
	if (rc != M_CM_OK)
		return rc;

	rc = car177_build();
	if (rc != M_CM_OK) 
		return rc;
}

long car177_get_db()
{
	$whenever sqlerror goto errexit;

	if (db_select(DBName) == FALSE) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}

long car177_prepare_data()
{
	$int qorder = 0,cnt = 0;
	$char stmt[8192],stmt_icode[128],stmt_level1[128];
	$char stmp1[128],stmp2[128],stmp3[128];
	$char sFullName[21];
	$char db_tmp[3];
	
	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == FALSE)
	{
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return FAIL;
	}
         
	$create temp table ply_out_tmp
	(			
	        igroup CHAR (2)
                , ilevel CHAR(3)
                , icode CHAR (10)
                , ncode CHAR (40)
                , qorder CHAR (15)
                , level1 CHAR (10)
                , level2 CHAR (10)
                , level3 CHAR (10)
                , level4 CHAR (10)
                , level5 CHAR (10)
                , level6 CHAR (10)
                , level7 CHAR (10)
                , level8 CHAR (10)
                , level9 CHAR (10)
                , row_guid CHAR (20)
	) with no log;
			
         if(icode[0] == '*')
         {
                strcpy(stmt_icode,"");
        }
        else
        {
                sprintf_s(stmt_icode, sizeof stmt_icode, "AND icode= '%s'",icode);            
        }			
			
         if(level1[0] == '*')
         {
                strcpy(stmt_level1,"");
        }
        else
        {
                sprintf_s(stmt_level1, sizeof stmt_level1, "AND level1= '%s'",level1);            
        }
	
	sprintf_s(stmt, sizeof stmt, "INSERT INTO ply_out_tmp "
		"SELECT * "
		"FROM cm_group "
		"WHERE igroup = '23' "
		"AND ilevel = '%s' "
		"%s %s "
        "          ",ilevel,stmt_icode,stmt_level1);
				
	printf("stmt[%s]\n",stmt);

	$PREPARE ply_out_1 FROM $stmt;
	$EXECUTE ply_out_1;
	
	return M_CM_OK;
	
errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
/*--------------------------------------------------------------------*/


long car177_build()
{
	int rc;
	$char sfilename[256],stitle[2048],stmt1[4096],stmt11[8192];

	$WHENEVER SQLERROR GOTO errexit;
	
	sprintf_s(sfilename, sizeof sfilename, "�n�O�H�ΫO���󥿧@�~[%s]\n",stmpx);
	
	/*stitle�ɶq�@��d�w�A�קK���D����*/
	sprintf_s(stitle, sizeof stitle, "�h�ŧO\t�N�X\t�W��\t����\t�h�Ť@\t�h�ŤG\t");

	strcpy(stmt1,"SELECT ilevel,icode,ncode,qorder,level1,level2 \
		FROM ply_out_tmp");
	
	rc = unload_file(outputf," ",sfilename,stitle,stmt1);
	$DROP TABLE ply_out_tmp;	
	
	if (rc != SUCCESS) 
	{
	    sprintf_s(msgbuf, sizeof msgbuf, " %s �ɮ׵L�k���� ",sfilename);
	    EWRITE(userid, rc , msgbuf);
	    return rc;
	}
	
	printf("done. return M_CM_OK\n");	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	return SQLCODE;
}
