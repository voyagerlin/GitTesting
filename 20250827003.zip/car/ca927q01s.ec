/**********************************************************************/
/*   program id   : ca927q01s.ec                                      */
/*   program name : �F�d���u�Ƴ���                                */
/*   date written : 2021/09/13 by 101314                              */
/*   files        :                                                   */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <decimal.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "globdata.h"
#include "safeclib.h"

$char dbgn[11],dbgn_q[21];
$char dend[11],dend_q[21];
$char stmpx[128];

int   count_db,k,j;
char  outputf[21];
$char userid[11];
$char DBName[05];
$char msgbuf[128];

DBinfo *list;

main(argc, argv)
int argc;
char **argv;
{
	int rc;

	batchinit();
	strcpy(DBName,         isNULLstr(argv[1]));
	strcpy(userid,         isNULLstr(argv[2]));
	strcpy(dbgn,           isNULLstr(argv[3]));  /*�e�~����϶�*/
	strcpy(dend,           isNULLstr(argv[4]));
	/*outputf*/
	strcpy(outputf,        isNULLstr(argv[5]));

	rc = car927_get_db();
	if (rc != M_CM_OK)
		return rc;

	rc = car927_prepare_data();
	if (rc != M_CM_OK)
		return rc;

	rc = car927_build();
	if (rc != M_CM_OK)
		return rc;
}

long car927_get_db()
{
	$whenever sqlerror goto errexit;

	if (db_select(DBName) == FALSE) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}

long car927_prepare_data()
{
	$char igroup[11],ngroup[21],fcard_class[2],imgr[2],iroute[21],iclass[2];
	$int qorder = 0,cnt = 0;
	$char stmt[8192];
	$char stmp1[128],stmp2[128],stmp3[128];
	$char sFullName[21];
	$char db_tmp[3];

	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == FALSE)
	{
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return FAIL;
	}

	strcpy(dbgn_q,cm_to_infdate(dbgn));
	strcpy(dend_q,cm_to_infdate(dend));

	printf("dbgn=[%s]\n",dbgn);
	printf("dend=[%s]\n",dend);
	printf("dbgn_q=[%s]\n",dbgn_q);
	printf("dend_q=[%s]\n",dend_q);

	$create temp table ply_out_tmp
	(
		iclaim CHAR (20)
                , fstl CHAR (1)
                , iclose_type SMALLINT
                , iins_item char(6)
                , msettle INTEGER
                , istl_flag CHAR (1)
                , daccident DATE
                , dclaim DATE
                , dclose DATE
                , dgroup DATE
                , ipolicy CHAR (20)
                , dwritten DATE
                , kreserve CHAR (5)
                , dply_begin DATE
                , dply_end DATE
                , kreserve_new CHAR (5)
                , kreserve_m   CHAR (5)
                , qduty_adjuster smallint
                
	) with no log;

	$create temp table ply_out_tmp2
         (
    	         nyear CHAR (5)
                , season CHAR (2)
                , msettle1 INTEGER
                , msettle2 INTEGER
                , msettle3 INTEGER
                , msettle4 INTEGER
                , msettle5 INTEGER
                , msettle6 INTEGER
                , msettle7 INTEGER
         )with no log;

	for(k=0;k<count_db;k++)
	{
		printf("for loop k=[%s]\n",itoa(k));
		sprintf_s(stmt,8192,"INSERT INTO ply_out_tmp \
			SELECT a.iclaim, a.fstl, a.iclose_type, d.iins_item, sum(decode(a.fstl,'1',d.mins_stl, -d.mins_stl)) AS msettle,  \
                           a.istl_flag, DATE(b.daccident) AS daccident, DATE(b.dclaim) AS dclaim, a.dclose, a.dgroup, b.ipolicy, \
                          (SELECT dwritten FROM policy_main_dtl WHERE ipolicy1 = b.ipolicy AND ipolicy2 = ' ' AND iendorsement = ' ' AND insure_type ='C' AND insure_instype='21') AS dwritten, \
                          (SELECT kreserve FROM policy_main_dtl WHERE ipolicy1 = b.ipolicy AND ipolicy2 = ' ' AND iendorsement = ' ' AND insure_type ='C' AND insure_instype='21') AS kreserve, \
                           c.dply_begin, c.dply_end, \
                          (SELECT kreserve \
                             FROM (SELECT kreserve, row_number() over (ORDER BY ipolicy1, ipolicy2, dwritten desc ) AS sno \
                             FROM policy_main_dtl WHERE ipolicy1 = a.ipolicy) AS tp2 WHERE sno = 1) AS kreserve_new, \
                          (SELECT unique kreserve                    \
                             from claim_stl_dtl                      \
                            where iclaim1        =  a.iclaim         \
                              and fstl           =  a.fstl           \
                              and iclose_type    =  a.iclose_type    \
                              and insure_type    =  'C'              \
                              and insure_instype =  d.iins_item      \
                              and ivictim        =  d.ivictim) as kreserve_m,    \
                           (select unique qduty_adjuster                    \
                              from ca_clm_victim_data x, ca_ver_relation y       \
                             where x.iclaim      =  y.iverify        \
                               and x.fvictim_car =  'F'              \
                               and y.iclaim      =  a.iclaim) as qduty_adjuster  \
                        FROM %s:settlement a, ca_clm_process b, %s:adjustment_ply c, %s:ca_stl_victim d  \
                        WHERE a.iclaim = b.iclaim AND a.iclaim = c.iclaim \
                          AND a.dgroup BETWEEN '%s' AND '%s' \
                          AND a.iclaim[6] = 'C' \
                          AND a.istl_flag IN ('A','B') \
                          AND a.iclaim = d.iclaim \
                          AND a.fstl = d.fstl \
                          AND a.iclose_type = d.iclose_type \
                          GROUP BY 1,2,3,4,6,7,8,9,10,11,12,13,14,15,16,17 \
                          ORDER BY 1,2,3,4 \
                          ",list[k].dbname,list[k].dbname,list[k].dbname,dbgn_q,dend_q);

		printf("stmt[%s]\n",stmt);
		printf("dbaccess[%s]\n",list[k].dbname);
		$PREPARE ply_out_1 FROM $stmt;
		$EXECUTE ply_out_1;
	}

	printf("165:\n");

	$char dbgn_yy[5],dbgn_mm[5],dbgn_dd[5];
         $char dend_yy[5],dend_mm[5],dend_dd[5];

	cm_char_split_3ymd(dbgn,dbgn_yy,dbgn_mm,dbgn_dd);
	cm_char_split_3ymd(dend,dend_yy,dend_mm,dend_dd);

	printf("167:dbgn year=[%s]\n",dbgn_yy);

       	for(k=atoi(dbgn_yy);k<=atoi(dend_yy);k++) /*�~��*/
	{
	    for(j=1;j<=4;j++)                                             /*�u��*/
	    {
	        $char dbgn_temp[21];
	        $char dend_temp[21];

	        if(j == 1){
	             sprintf_s(dbgn_temp,21,"01/01/%s",itoa(k+1911));
	             sprintf_s(dend_temp,21,"03/31/%s",itoa(k+1911));
	        }
	        else if(j == 2)
	        {
	             sprintf_s(dbgn_temp,21,"04/01/%s",itoa(k+1911));
	             sprintf_s(dend_temp,21,"06/30/%s",itoa(k+1911));
	        }
	        else if(j == 3)
	        {
	             sprintf_s(dbgn_temp,21,"07/01/%s",itoa(k+1911));
	             sprintf_s(dend_temp,21,"09/30/%s",itoa(k+1911));
	        }
	        else
	        {
	             sprintf_s(dbgn_temp,21,"10/01/%s",itoa(k+1911));
	             sprintf_s(dend_temp,21,"12/31/%s",itoa(k+1911));
	        }

	    	sprintf_s(stmt,8192,"INSERT INTO ply_out_tmp2 \
		SELECT DISTINCT '%d' AS nyear, '%d' AS season, \
                    (SELECT SUM(msettle) FROM ply_out_tmp WHERE kreserve_m = '1400' AND dgroup BETWEEN '%s' AND '%s') AS msettle1, \
                    (SELECT SUM(msettle) FROM ply_out_tmp WHERE kreserve_m = '1500' AND dgroup BETWEEN '%s' AND '%s') AS msettle2, \
                    (SELECT SUM(msettle) FROM ply_out_tmp WHERE kreserve_m = '1610' AND dgroup BETWEEN '%s' AND '%s') AS msettle3, \
                    (SELECT SUM(msettle) FROM ply_out_tmp WHERE kreserve_m = '1620' AND dgroup BETWEEN '%s' AND '%s') AS msettle4, \
                    (SELECT SUM(msettle) FROM ply_out_tmp WHERE kreserve_m = '3210' AND dgroup BETWEEN '%s' AND '%s') AS msettle5, \
                    (SELECT SUM(msettle) FROM ply_out_tmp WHERE kreserve_m = '3220' AND dgroup BETWEEN '%s' AND '%s') AS msettle6, \
                    (SELECT SUM(msettle) FROM ply_out_tmp WHERE kreserve_m = '3230' AND dgroup BETWEEN '%s' AND '%s') AS msettle7  \
                    FROM ply_out_tmp \
                    WHERE dgroup BETWEEN '%s' AND '%s'",k,j,dbgn_temp,dend_temp,dbgn_temp,dend_temp,dbgn_temp,dend_temp,dbgn_temp,dend_temp,dbgn_temp,dend_temp,dbgn_temp,dend_temp,dbgn_temp,dend_temp,dbgn_temp,dend_temp);

                	printf("212:stmt[%s]\n",stmt);
                	$PREPARE ply_out_1 FROM $stmt;
                	$EXECUTE ply_out_1;
	    }
	}

	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
/*--------------------------------------------------------------------*/

long car927_build()
{
	int rc;
	$char sfilename[256],stitle[2048],stmt1[4096],stmt11[8192];

	$WHENEVER SQLERROR GOTO errexit;

	strcpy(sfilename,"�F�d���u�Ʃ��Ӫ�\n");
	/*stitle�ɶq�@��d�w�A�קK���D����*/
	sprintf_s(stitle,2048,"�߮׸�\t��/�l�ʽ�\t�ߥI����\t���I����\t�߰l���B\t�ߥI���p\t�X�I��\t���z��\t�߮פ鵲��\t�߮׷J�p��\t�O�渹\tñ���\t�ǳƪ��N�X\t�ǳƪ��N�X�W��\t�O�I�_��\t�O�I����\t�̷s�O��ǳƪ��N�X\t�z�ߨ��z�ǳƪ��N�X\t�����r�p�F�d���\t");

	strcpy(stmt1,"SELECT iclaim, fstl, iclose_type, iins_item, msettle, istl_flag, daccident, dclaim, dclose, dgroup, ipolicy, dwritten, kreserve, \
	                 case \
                          	WHEN kreserve='1400' THEN '�j��ۥΨT���d���I' \
                          	WHEN kreserve='1500' THEN '�j��ӷ~�T���d���I' \
                          	WHEN kreserve='1610' THEN '�j������O�I1�~��' \
                          	WHEN kreserve='1620' THEN '�j������O�I2�~��' \
                          	WHEN kreserve='3210' THEN '�j��L�q���O�I1�~��' \
                          	WHEN kreserve='3220' THEN '�j��L�q���O�I2�~��' \
                          	WHEN kreserve='3230' THEN '�j��L�q���O�I3�~��' \
                          END AS nkreserve, \
	         dply_begin, dply_end, kreserve_new, kreserve_m, qduty_adjuster \
		FROM ply_out_tmp");

	rc = unload_file(outputf,"B",sfilename,stitle,stmt1);

	strcpy(sfilename,"�F�d���u�ƷJ�`��\n");
	sprintf_s(stitle,2048,"�~��\t�u��\t�j��ۥΨT���d���I\t�j��ӷ~�T���d���I\t�j������O�I1�~��\t�j������O�I2�~��\t�j��L�q���O�I1�~��\t�j��L�q���O�I2�~��\t�j��L�q���O�I3�~��\t");

	strcpy(stmt1,"SELECT * \
		FROM ply_out_tmp2");

	rc = unload_file(outputf,"A",sfilename,stitle,stmt1);

	$DROP TABLE ply_out_tmp;
	$DROP TABLE ply_out_tmp2;


	if (rc != SUCCESS)
	{
	    sprintf_s(msgbuf,128," %s �ɮ׵L�k���� ",sfilename);
	    EWRITE(userid, rc , msgbuf);
	    return rc;
	}

	printf("done. return M_CM_OK\n");
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	return SQLCODE;
}
