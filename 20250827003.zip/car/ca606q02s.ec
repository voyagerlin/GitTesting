/*******************************************/
/*   �g�P�Ө����I�ΰ������N�~�Z�έp���Ӫ�  */
/*   �������P�O��                        */
/*   PROGRAM : ca606q02s.ec                */
/*   DATE    : 94.02.16  by Jessie         */
/*   Checked for ����100�~�M��             */
/*******************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include "safeclib.h"
extern char RPTDIR[];

$char   office[2];
$char   icar_flag[2];
$char   dPolicyBgn[11],dPolicyEnd[11];
$char   dEndorseEnd[11];
$char   iEdrtype[2];
char    iPay[2];
char    dPayBgn[11],dPayEnd[11];
long    lDpaybgn,lDpayend;

$char   DBName[05];
$char   userid[11];
DBinfo  *list;
int     count_db;
long    rc;
char    outputf[N_FILE+1], userid[11];

/*----------------------------------------------------------------------------*/
/****
main(argc, argv)
int argc;
char **argv;
****/
long car6062(DBName1,userid1,office1,icar_flag1,dPolicyBgn1,dPolicyEnd1,
             iPay1,dPayBgn1,dPayEnd1,outputf1)
char *DBName1,*userid1,*office1,*icar_flag1,*dPolicyBgn1,*dPolicyEnd1;
char *iPay1,*dPayBgn1,*dPayEnd1;
char *outputf1;
{
   	int rc;

   	batchinit();
   	strcpy(DBName,        isNULLstr(DBName1));
   	strcpy(userid,        isNULLstr(userid1));
   	strcpy(office,        isNULLstr(office1));
	strcpy(icar_flag,     isNULLstr(icar_flag1));
   	strcpy(dPolicyBgn,    isNULLstr(dPolicyBgn1));
   	strcpy(dPolicyEnd,    isNULLstr(dPolicyEnd1));
        strcpy(iPay,          isNULLstr(iPay1));
        strcpy(dPayBgn,       isNULLstr(dPayBgn1));
        strcpy(dPayEnd,       isNULLstr(dPayEnd1));
   	strcpy(outputf,       isNULLstr(outputf1));
                     
	printf("office[%s],icar_flag[%s],dpolicy_bgn[%s],dpolicy_end[%s],dendorse_end[%s]\n",
	        office,    icar_flag,    dPolicyBgn,     dPolicyEnd,     dEndorseEnd);

        lDpaybgn = cm_ymd_cdate(dPayBgn);
        lDpayend = cm_ymd_cdate(dPayEnd);

    rc = car6062_get_db();
    if (rc != SUCCESS)
       	return rc;
       
    rc = car6062_prepare_data();     
    if (rc != SUCCESS)
       	return rc;
    
    rc = car6062_create_rpt();
    if (rc != SUCCESS)
       	return rc;

    return SUCCESS;
}  

/*--------------------------------------------------------------------*/

long car6062_get_db()
{
   	$whenever sqlerror goto errexit;

   	if (db_select(DBName) == False) {
       	EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       	return M_CM_DB_NOTOPEN;
   	}

   	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
      	if (EWRITE(userid, M_CM_NOT_DBLIST) == True)
         	return M_CM_NOT_DBLIST;
   	}
 
   	return SUCCESS;
errexit:
   	sqlfatal();
   	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   	return SQLCODE;
}

/*--------------------------------------------------------------------*/

long car6062_prepare_data()
{  
   	int k;
   	$char stmt[5000],stmt1[256];
   	$char sbuf[50]; 
	$char stmt_buf[50];
	$char nbig_area[21];
	$char nbig_office[21];
	$char ibig_sales[21];
	$char nbig_sales[21];
	$char ipolicy[21];
	$char icard[21];
	$char iendorse[21];
    $char nassured[41];
    $char dply_begin[21];
    $char dpolicy[21];
    $char iengine[21];
    $char itag[11];
    $long lDpay = 0;
    $int  id = 0;
    $long qpt = 0;
    $char iquota[7];

    int   FlagHPHA_31;
    int   FlagHPHA_32;
    int   FlagHPHA_51;
    int   Flag01;

    $char icar_type[3];	
	$char iins_type[7];	
	$long minjured_cover = 0,mdeath_cover = 0,mdamage_cover = 0;
        $long mpreinj_cover,mpredea_cover,mpredmg_cover;
	$long mins_premium = 0;
	$int  qcount = 0;
    $int  IntPlyCount;     /*'���N�I���*/
    $long LngPlyPrem;      /*'���N�I�O�O*/
    $int  IntDmgCount;     /*'�����I���*/
    $long LngDmgPrem;      /*'�����I�O�O*/
    $int  Int31Count;      /*'31�I�إ��*/
    $long Lng31Prem;       /*'31�I�ثO�O*/
    $int  Int32Count;      /*'32�I�إ��*/
    $long Lng32Prem;       /*'32�I�ثO�O*/
    $int  Int51Count;      /*'51�I�إ��*/
    $long Lng51Prem;       /*'51�I�ثO�O*/
    $int  IntHPHACount;    /*'�������N���*/
    $long LngHPHAPrem;     /*'�������N�O�O*/
    
    $long Coverage31_1;     /*'�I��31�X�p�O�B*/
    $long Coverage31_2;
    $long Coverage31_3;
    $long Coverage31_1_pre; /*'�I�ا��e31�O�B*/
    $long Coverage31_2_pre;
    $long Coverage31_3_pre;
    $long Coverage31_Top;   /*'�I��31�̰��O�B����̨��ؤ��P*/
    
    $long Coverage32_1;     /*'�I��32�X�p�O�B*/
    $long Coverage32_2;
    $long Coverage32_3;
    $long Coverage32_1_pre; /*'�I��32���e�O�B*/
    $long Coverage32_2_pre;
    $long Coverage32_3_pre;
        
    $long Coverage51_1;     /*'�I��51�X�p�O�B*/
    $long Coverage51_2;
    $long Coverage51_3;
    $long Coverage51_1_pre; /*'�I��51���e�O�B*/
    $long Coverage51_2_pre;
    $long Coverage51_3_pre;

	/* �P�_���L�ӫO�O�� */
    $int  FlagCovered31;
    $int  FlagCovered32;
    $int  FlagCovered51;
    $int  FlagCovered01;

   	$whenever sqlerror goto errexit;
   
   	$CREATE TEMP TABLE car6062_tmp_tbl
    ( 
      	nbig_area      char(20) default ' ',
      	nbig_office    char(20) default ' ',
      	ibig_sales     char(20) default ' ',
      	nbig_sales     char(20) default ' ',
      	ipolicy        char(20) default ' ',
      	icard          char(20) default ' ',
      	iendorse       char(20) default ' ',
      	nassured       char(40) default ' ',
      	dply_begin     char(20) default ' ',
      	dpolicy        char(20) default ' ',
      	iengine        char(20) default ' ',
      	itag           char(10) default ' ',
      	ply_count      integer  default 0,
      	ply_prem       integer  default 0,
      	dmg_count      integer  default 0,
      	dmg_prem       integer  default 0,
      	HPHA_count     integer  default 0,
      	HPHA_prem      integer  default 0,
        dpay           date,
        iquota         char(06) default ' ',
        icar_type      char(02) default ' '
    )WITH NO LOG;
 	
 	
 	
 	if (strncmp(icar_flag,"1",1)==0)
 	{
 		strcpy(stmt_buf," AND   a.icar_flag = '1' ");
 	}
 	else if (strncmp(icar_flag,"2",1)==0)
 	{
 		strcpy(stmt_buf," AND   a.icar_flag = '2' ");
 	}
 	else
 	{
 		strcpy(stmt_buf," ");
 	}	
 	
   	for(k=0;k<count_db;k++)
   	{
         if (iPay[0]=='1') {
             sprintf_s(stmt1, sizeof stmt1,"(select dpay from %s:ao_plyedr_prem where  "
               "ipolicy1=a.ipolicy[1,13] and ipolicy2=a.ipolicy[14,17]  "
               "and iendorse = ' ' and frcvpay = 'P')",list[k].dbname);
         }
         else
             strcpy(stmt1,"''");

        /* Ū���O���� */
       	sprintf_s(stmt, sizeof stmt,"SELECT %s %s %s FROM %s:%s %s:%s %s %s %s WHERE %s %s %s %s %s %s %s %s %s %s ",
		             "NVL(d.ngroup,a.iofficer[1,3]), c.nname, a.ibig_sales, NVL(e.nname,a.ibig_sales),a.icar_type,",
       	             "a.ipolicy, a.icard, b.nassured[1,40], a.dply_begin, a.dpolicy, b.iengine, b.itag, qpt, (a.mdmg_prem + a.mlia_prem),a.iquota, ",
                             stmt1,
		             list[k].dbname,"ori_ply_relation a,",
		             list[k].dbname,"original_ply b,",
		             " officer c,",
		             " outer sa_frm_module d,",
		             " outer ca_big_office e ",
		             "       a.ipolicy = b.ipolicy ",
       		         " AND   a.fcard_class = '2' ",
		             " AND   a.dpolicy between ? and ? ",
/*******�������� AND   a.icar_type in ('03','04','19') ",****/
		             stmt_buf,
		             " AND   a.iofficer[1] = ? ",
		             " AND   a.iofficer = c.iofficer ",
		             " AND   c.idealer = d.igroup ",
		             " AND   d.ifrm_module = '02' ",
		             " AND   a.ibig_sales = e.ibig_comp ",
		             " AND   e.fclass = '2' ");
      	
      	printf("stmt[%s]\n",stmt);
      	
       	$PREPARE Acursor1_tmp FROM $stmt;
       	
       	$DECLARE Acursor1 CURSOR for Acursor1_tmp;
       	$OPEN    Acursor1 using $dPolicyBgn,$dPolicyEnd,$office;
       	for(;;)
       	{
       		$FETCH Acursor1 INTO $nbig_area,$nbig_office,$ibig_sales,$nbig_sales,$icar_type,
       		                     $ipolicy,$icard,$nassured,$dply_begin,$dpolicy,$iengine,$itag,$qpt,$mins_premium,$iquota,$lDpay:id;
       		
       		if (SQLCODE == SQLNOTFOUND) break;

                if (iPay[0]=='1') {
                   if (id < 0) continue;
                   if (lDpay < lDpaybgn || lDpay > lDpayend) continue;
                }

                /* 31�I�س̰��O�B�̨��ؤ��P */
                if (strncmp(icar_type,"04",2)==0 ||
                    strncmp(icar_type,"19",2)==0)
                    Coverage31_Top = 10000000;
                else
                    Coverage31_Top = 24000000;

       		
       		/* initial data */
    		iendorse[0] = '\0';
    		IntPlyCount=0;     /*'���N�I���*/
    		LngPlyPrem=0;      /*'���N�I�O�O*/
    		IntDmgCount=0;     /*'�����I���*/
    		LngDmgPrem=0;      /*'�����I�O�O*/
    		Int31Count=0;      /*'31�I�إ��*/
    		Lng31Prem=0;       /*'31�I�ثO�O*/
    		Int32Count=0;      /*'32�I�إ��*/
    		Lng32Prem=0;       /*'32�I�ثO�O*/
    		Int51Count=0;      /*'51�I�إ��*/
    		Lng51Prem=0;       /*'51�I�ثO�O*/
    		IntHPHACount=0;    /*'�������N���*/
    		LngHPHAPrem=0;     /*'�������N�O�O*/
    
    		Coverage31_1=0;    /*'�I��31�X�p�O�B*/
    		Coverage31_2=0;
    		Coverage31_3=0;
    
    		Coverage32_1=0;    /*'�I��32�X�p�O�B*/
    		Coverage32_2=0;
    		Coverage32_3=0;
    
    		Coverage51_1=0;    /*'�I��51�X�p�O�B*/
    		Coverage51_2=0;
    		Coverage51_3=0;

    		FlagCovered31=0;
    		FlagCovered32=0;
    		FlagCovered51=0;
    		FlagCovered01=0;
       		
       		/* �O���ƤΫO��O�O */
       		IntPlyCount = 1;
       		LngPlyPrem  = mins_premium; 
       		
       		/* ���o�I�ءG����l���I(01,05,09,08)�βĤT�H�d���I(31,32)�έ����I(51)��� */
        	sprintf_s(stmt, sizeof stmt,"SELECT %s FROM %s:%s WHERE %s ",
       		             " iins_type, minjured_cover, mdeath_cover, mdamage_cover, mins_premium ",
       		             list[k].dbname,"ori_ins_type ",
       		             "    ipolicy = ? AND iins_type in ('01','05','08','09','31','32','51')");
       		
       		$PREPARE Acursor3_tmp FROM $stmt;
       		$DECLARE Acursor3 CURSOR for Acursor3_tmp;
       		$OPEN    Acursor3 using $ipolicy;
       		for(;;)
       		{
       			$FETCH Acursor3 INTO $iins_type,$minjured_cover,$mdeath_cover,$mdamage_cover,$mins_premium;
       			              
				if (SQLCODE == SQLNOTFOUND) break;
				
				if ((strncmp(iins_type,"01",2)==0) ||
				    (strncmp(iins_type,"05",2)==0) ||
				    (strncmp(iins_type,"08",2)==0) ||
				    (strncmp(iins_type,"09",2)==0))
				{
					Flag01 = 1;
                    FlagCovered01 = 1;
                        
                    IntDmgCount = 1;
                    LngDmgPrem = mins_premium;
                    
				}
			
				if ((strncmp(iins_type,"31",2)==0) ||
				    (strncmp(iins_type,"32",2)==0) ||
				    (strncmp(iins_type,"51",2)==0))
				{
					if (strncmp(iins_type,"31",2)==0)
					{
						FlagCovered31 = 1;
					
						Int31Count = 1;
						Lng31Prem = mins_premium;
					
                    	Coverage31_1 = minjured_cover;
                    	Coverage31_2 = mdeath_cover;
                    	Coverage31_3 = mdamage_cover;
                        
	                if ((Coverage31_1 >= 2000000) && (Coverage31_3 >= Coverage31_Top)) 
                        {
	                     	FlagHPHA_31 = 1;
                        }
					}

					if (strncmp(iins_type,"32",2)==0)
					{
						FlagCovered32 = 1;
					
						Int32Count = 1;
						Lng32Prem = mins_premium;
					
                    	Coverage32_1 = minjured_cover;
                    	Coverage32_2 = mdeath_cover;
                    	Coverage32_3 = mdamage_cover;
                        
                    	if (Coverage32_3 >= 500000) 
                    	{
                        	FlagHPHA_32 = 1;
                    	}
					}

					if (strncmp(iins_type,"51",2)==0)
					{
						FlagCovered51 = 1;
					
						Int51Count = 1;
						Lng51Prem = mins_premium;
					
                    	Coverage51_1 = minjured_cover;
                    	Coverage51_2 = mdeath_cover;
                    	Coverage51_3 = mdamage_cover;
                        
                    	if ((Coverage51_1 >= 150000) && (Coverage51_2 >= 1500000) && (Coverage51_3 >= (1500000*qpt))) 
                    	{
                        	FlagHPHA_51 = 1;
                    	}
					}
					
				}
			}
			$CLOSE Acursor3;
			$FREE  Acursor3;
       		
       		if (((FlagHPHA_51 == 0) || (FlagHPHA_31 == 0) || (FlagHPHA_32 == 0)) && (Flag01 == 0))
       		{
       			/* ������X */
       		}
       		else
       		{
	                if ((Coverage31_1 >= 2000000) && (Coverage31_3 >= Coverage31_Top) && (Coverage32_3 >= 500000) &&
	                    (Coverage51_1 >= 150000) && (Coverage51_2 >= 1500000) && (Coverage51_3 >= (1500000 * qpt)))
	                {    
	                    IntHPHACount = 1;
	                    LngHPHAPrem = Lng31Prem + Lng32Prem + Lng51Prem;
	       		}

       		}
       			$INSERT INTO car6062_tmp_tbl VALUES
       			 ($nbig_area, $nbig_office, $ibig_sales, $nbig_sales,
       			  $ipolicy, $icard, $iendorse, $nassured, $dply_begin,
                          $dpolicy, $iengine, $itag,
       			  $IntPlyCount, $LngPlyPrem, $IntDmgCount, $LngDmgPrem,
                          $IntHPHACount, $LngHPHAPrem, $lDpay,
                          $iquota,$icar_type);
       	}
       	$CLOSE  Acursor1;
       	$FREE   Acursor1;

         if (iPay[0]=='1') {
             sprintf_s(stmt1, sizeof stmt1,"(select dpay from %s:ao_plyedr_prem where  "
               "ipolicy1=a.ipolicy[1,13] and ipolicy2=a.ipolicy[14,17]  "
               "and iendorse = a.iendorse and frcvpay = 'P')",list[k].dbname);
         }
         else
             strcpy(stmt1,"''");

        /* Ū������� */
       	sprintf_s(stmt, sizeof stmt,"SELECT %s %s %s FROM %s:%s %s:%s %s %s %s WHERE %s %s %s %s %s %s %s %s %s %s %s ",
		             "NVL(d.ngroup,a.iofficer[1,3]), c.nname, a.ibig_sales, NVL(e.nname,a.ibig_sales),a.icar_type,",
       	             "a.ipolicy, a.iendorse, a.icard, b.nassured[1,40], a.dedr_begin, a.dendorse, b.iengine, b.itag, qpt, (a.medrdmg_prem + a.medrlia_prem), a.qcount,a.iquota, ",
 			     stmt1,
		             list[k].dbname,"edr_relation a,",
		             list[k].dbname,"endorsement b,",
		             " officer c,",
		             " outer sa_frm_module d,",
		             " outer ca_big_office e ",
		             "       a.iendorse = b.iendorse ",
       		             " AND   a.fcard_class = '2' ",
		             " AND   a.dendorse between ? and ? ",
                             " AND   a.dedr_close is not null ",
/***��������     " AND   a.icar_type in ('03','04','19') ", ***/
		             stmt_buf,
		             " AND   a.iofficer[1] = ? ",
		             " AND   a.iofficer = c.iofficer ",
		             " AND   c.idealer = d.igroup ",
		             " AND   d.ifrm_module = '02' ",
		             " AND   a.ibig_sales = e.ibig_comp ",
		             " AND   e.fclass = '2' ");
      	
       	printf("stmt[%s]\n",stmt);
       	
       	$PREPARE AcursorE1_tmp FROM $stmt;
       	$DECLARE AcursorE1 CURSOR for AcursorE1_tmp;
       	$OPEN    AcursorE1 using $dPolicyBgn,$dPolicyEnd,$office;
       	for(;;)
       	{
       		$FETCH AcursorE1 INTO $nbig_area,$nbig_office,
                       $ibig_sales,$nbig_sales,$icar_type,$ipolicy,$iendorse,
                       $icard,$nassured,$dply_begin,$dpolicy,$iengine,
                       $itag,$qpt,$mins_premium,$qcount,$iquota,$lDpay:id;
       		
       		if (SQLCODE == SQLNOTFOUND) break;

                if (iPay[0]=='1') {
                   if (id < 0) continue;
                   if (lDpay < lDpaybgn || lDpay > lDpayend) continue;
                }
       		
                /* 31�I�س̰��O�B�̨��ؤ��P */
                if (strncmp(icar_type,"04",2)==0 ||
                    strncmp(icar_type,"19",2)==0)
                    Coverage31_Top = 10000000;
                else
                    Coverage31_Top = 24000000;

       		/* initial data */
    		IntPlyCount=0;     /*'���N�I���*/
    		LngPlyPrem=0;      /*'���N�I�O�O*/
    		IntDmgCount=0;     /*'�����I���*/
    		LngDmgPrem=0;      /*'�����I�O�O*/
    		Int31Count=0;      /*'31�I�إ��*/
    		Lng31Prem=0;       /*'31�I�ثO�O*/
    		Int32Count=0;      /*'32�I�إ��*/
    		Lng32Prem=0;       /*'32�I�ثO�O*/
    		Int51Count=0;      /*'51�I�إ��*/
    		Lng51Prem=0;       /*'51�I�ثO�O*/
    		IntHPHACount=0;    /*'�������N���*/
    		LngHPHAPrem=0;     /*'�������N�O�O*/
    
    		Coverage31_1=0;    /*'�I��31�X�p�O�B*/
    		Coverage31_2=0;
    		Coverage31_3=0;
    		Coverage31_1_pre=0;    /*'�I��31���e�O�B*/
    		Coverage31_2_pre=0;
    		Coverage31_3_pre=0;
    
    		Coverage32_1=0;    /*'�I��32�X�p�O�B*/
    		Coverage32_2=0;
    		Coverage32_3=0;
    		Coverage32_1_pre=0;    /*'�I��32���e�O�B*/
    		Coverage32_2_pre=0;
    		Coverage32_3_pre=0;
    
    		Coverage51_1=0;    /*'�I��51�X�p�O�B*/
    		Coverage51_2=0;
    		Coverage51_3=0;
    		Coverage51_1_pre=0;    /*'�I��51���e�O�B*/
    		Coverage51_2_pre=0;
    		Coverage51_3_pre=0;

    		FlagCovered31=0;
    		FlagCovered32=0;
    		FlagCovered51=0;
    		FlagCovered01=0;
       		
       		/* ����ƤΧ��O�O */
       		IntPlyCount = qcount;
       		LngPlyPrem  = mins_premium; 
       		
       		/* ���o�I�ءG����l���I(01,05,09,08)�βĤT�H�d���I(31,32)�έ����I(51)��� */
                stmt[0]='\0';
        	sprintf_s(stmt, sizeof stmt,"SELECT %s FROM %s:%s WHERE %s ",
       		             " iins_type, medrinj_cover, medrdea_cover, medrdmg_cover, medrins_prem, qcount ",
       		             list[k].dbname,"edr_ins_type ",
       		             "    iendorse = ? AND iins_type in ('01','05','08','09','31','32','51')");
       		
       		$PREPARE AcursorE3_tmp FROM $stmt;
       		$DECLARE AcursorE3 CURSOR for AcursorE3_tmp;
       		$OPEN    AcursorE3 using $iendorse;
       		for(;;)
       		{
       			$FETCH AcursorE3 INTO $iins_type,$minjured_cover,
                               $mdeath_cover,$mdamage_cover,$mins_premium,
                               $qcount;
       			              
				if (SQLCODE == SQLNOTFOUND) break;
				
				if ((strncmp(iins_type,"01",2)==0) ||
				    (strncmp(iins_type,"05",2)==0) ||
				    (strncmp(iins_type,"08",2)==0) ||
				    (strncmp(iins_type,"09",2)==0))
				{
					Flag01 = 1;
                    FlagCovered01 = 1;
                        
                    IntDmgCount += qcount;
                    LngDmgPrem += mins_premium;
                    
				}
			
				if ((strncmp(iins_type,"31",2)==0) ||
				    (strncmp(iins_type,"32",2)==0) ||
				    (strncmp(iins_type,"51",2)==0))
				{
                        /* ���o���e���O�B */
                        stmt[0]='\0';
                        sprintf_s(stmt, sizeof stmt,"SELECT %s FROM %s:%s WHERE %s %s ",
                               "minjured_cover, mdeath_cover, mdamage_cover",
                               list[k].dbname, "ply_ins_type_bak",
                               "iendorse = ? ","AND iins_type = ? "); 
			$PREPARE pre_bak from $stmt;
			$EXECUTE pre_bak INTO $mpreinj_cover,$mpredea_cover,
                                 $mpredmg_cover USING $iendorse, $iins_type;
                        if (SQLCODE==SQLNOTFOUND)
                           mpreinj_cover=mpredea_cover=mpredmg_cover=0;

					if (strncmp(iins_type,"31",2)==0)
					{
						FlagCovered31 = 1;
					
						Int31Count = qcount;
						Lng31Prem = mins_premium;
					
                    	Coverage31_1 = minjured_cover + mpreinj_cover;
                    	Coverage31_2 = mdeath_cover   + mpredea_cover;
                    	Coverage31_3 = mdamage_cover  + mpredmg_cover;
                    	Coverage31_1_pre = mpreinj_cover;
                    	Coverage31_2_pre = mpredea_cover;
                    	Coverage31_3_pre = mpredmg_cover;
                        
	                    	if ((Coverage31_1 >= 2000000) && (Coverage31_3 >= Coverage31_Top)) 
	                    	{
	                        	FlagHPHA_31 = 1;
	                    	}
					}

					if (strncmp(iins_type,"32",2)==0)
					{
						FlagCovered32 = 1;
					
						Int32Count = qcount;
						Lng32Prem = mins_premium;
					
                    	Coverage32_1 = minjured_cover + mpreinj_cover;
                    	Coverage32_2 = mdeath_cover   + mpredea_cover;
                    	Coverage32_3 = mdamage_cover  + mpredmg_cover;
                    	Coverage32_1_pre = mpreinj_cover;
                    	Coverage32_2_pre = mpredea_cover;
                    	Coverage32_3_pre = mpredmg_cover;
                        
                    	if (Coverage32_3 >= 500000) 
                    	{
                        	FlagHPHA_32 = 1;
                    	}
					}

					if (strncmp(iins_type,"51",2)==0)
					{
						FlagCovered51 = 1;
					
						Int51Count = qcount;
						Lng51Prem = mins_premium;
					
                    	Coverage51_1 = minjured_cover + mpreinj_cover;
                    	Coverage51_2 = mdeath_cover   + mpredea_cover;
                    	Coverage51_3 = mdamage_cover  + mpredmg_cover;
                    	Coverage51_1_pre = mpreinj_cover;
                    	Coverage51_2_pre = mpredea_cover;
                    	Coverage51_3_pre = mpredmg_cover;
                        
                    	if ((Coverage51_1 >= 150000) && (Coverage51_2 >= 1500000) && (Coverage51_3 >= (1500000*qpt))) 
                    	{
                        	FlagHPHA_51 = 1;
                    	}
					}
					
				}
			}
			$CLOSE AcursorE3;
			$FREE  AcursorE3;

			/* �����I�L�ӫO�O�� */
			if (FlagCovered01 == 0)
			{
            	/* ���o���e���I�ثO�B */
				sprintf_s(stmt, sizeof stmt, "SELECT %s FROM %s:%s WHERE %s %s ",
				              "minjured_cover,mdeath_cover,mdamage_cover ",
				              list[k].dbname, "ply_ins_type_bak ",
				              " iendorse = ? ",
				              " AND iins_type in ('01','05','08','09') ");
				$PREPARE AcursorE6_tmp FROM $stmt;
				$DECLARE AcursorE6 CURSOR for AcursorE6_tmp;
				$OPEN    AcursorE6 using $iendorse;
				for(;;)
				{
					$FETCH AcursorE6 INTO $mpreinj_cover,
                                           $mpredea_cover,$mpredmg_cover;
					              
					if (SQLCODE == SQLNOTFOUND) break;
						
                    Flag01      = 1;
				}
				$CLOSE   AcursorE6;
				$FREE    AcursorE6;
			}
			
			if (FlagCovered31 == 0)
			{
            	/* ���o���e���I�ثO�B */
				sprintf_s(stmt, sizeof stmt, "SELECT %s FROM %s:%s WHERE %s %s ",
				              "minjured_cover,mdeath_cover,mdamage_cover ",
				              list[k].dbname, "ply_ins_type_bak ",
				              " iendorse = ? ",
				              " AND iins_type = '31' ");
				$PREPARE AcursorE7_tmp FROM $stmt;
				$DECLARE AcursorE7 CURSOR for AcursorE7_tmp;
				$OPEN    AcursorE7 using $iendorse;
				for(;;)
				{
					$FETCH AcursorE7 INTO $mpreinj_cover,
                                           $mpredea_cover,$mpredmg_cover;
					              
					if (SQLCODE == SQLNOTFOUND) break;
					
                   	Coverage31_1 += mpreinj_cover;
                   	Coverage31_2 += mpredea_cover;
                   	Coverage31_3 += mpredmg_cover;
                   	Coverage31_1_pre = mpreinj_cover;
                   	Coverage31_2_pre = mpredea_cover;
                   	Coverage31_3_pre = mpredmg_cover;

	                    	if ((Coverage31_1 >= 2000000) && (Coverage31_3 >= Coverage31_Top)) 
	                    	{
	                        	FlagHPHA_31 = 1;
	                    	}
				}
				$CLOSE   AcursorE7;
				$FREE    AcursorE7;
			}
				
			if (FlagCovered32 == 0)
			{
            	/* ���o���e���I�ثO�B */
				sprintf_s(stmt, sizeof stmt, "SELECT %s FROM %s:%s WHERE %s %s ",
				              "minjured_cover,mdeath_cover,mdamage_cover ",
				              list[k].dbname, "ply_ins_type_bak ",
				              " iendorse = ? ",
				              " AND iins_type = '32' ");
				$PREPARE AcursorE8_tmp FROM $stmt;
				$DECLARE AcursorE8 CURSOR for AcursorE8_tmp;
				$OPEN    AcursorE8 using $iendorse;
				for(;;)
				{
					$FETCH AcursorE8 INTO $mpreinj_cover,
                                           $mpredea_cover,$mpredmg_cover;
					              
					if (SQLCODE == SQLNOTFOUND) break;
						
               		Coverage32_1 += mpreinj_cover;
               		Coverage32_2 += mpredea_cover;
               		Coverage32_3 += mpredmg_cover;
               		Coverage32_1_pre = mpreinj_cover;
               		Coverage32_2_pre = mpredea_cover;
               		Coverage32_3_pre = mpredmg_cover;

               		if (Coverage32_3 >= 500000) 
               		{
                   		FlagHPHA_32 = 1;
               		}

				}
				$CLOSE   AcursorE8;
				$FREE    AcursorE8;
			}				
				
			if (FlagCovered51 == 0)
			{
            	/* ���o���e���I�ثO�B */
				sprintf_s(stmt, sizeof stmt, "SELECT %s FROM %s:%s WHERE %s %s ",
				              "minjured_cover,mdeath_cover,mdamage_cover ",
				              list[k].dbname, "ply_ins_type_bak ",
				              " iendorse = ? ",
				              " AND iins_type = '51' ");
				$PREPARE AcursorE9_tmp FROM $stmt;
				$DECLARE AcursorE9 CURSOR for AcursorE9_tmp;
				$OPEN    AcursorE9 using $iendorse;
				for(;;)
				{
					$FETCH AcursorE9 INTO $mpreinj_cover,
                                           $mpredea_cover,$mpredmg_cover;
					              
					if (SQLCODE == SQLNOTFOUND) break;
						
               		Coverage51_1 += mpreinj_cover;
               		Coverage51_2 += mpredea_cover;
               		Coverage51_3 += mpredmg_cover;
               		Coverage51_1_pre = mpreinj_cover;
               		Coverage51_2_pre = mpredea_cover;
               		Coverage51_3_pre = mpredmg_cover;

               		if ((Coverage51_1 >= 150000) && (Coverage51_2 >= 1500000) && (Coverage51_3 >= (1500000*qpt))) 
               		{
                   		FlagHPHA_51 = 1;
               		}
				}
				$CLOSE   AcursorE9;
				$FREE    AcursorE9;
			}		      		
                if (IntPlyCount==0 && LngPlyPrem==0 && IntDmgCount==0 &&
                    LngDmgPrem==0  && Int31Count==0 && Lng31Prem==0   &&
                    Int32Count==0  && Lng32Prem==0  && Int51Count==0  &&
                    Lng51Prem==0) continue;
       		
       		if (((FlagHPHA_51 == 0) || (FlagHPHA_31 == 0) || (FlagHPHA_32 == 0)) && (Flag01 == 0))
       		{
	                if ((Coverage31_1_pre >= 2000000) && (Coverage31_3_pre >= Coverage31_Top) && (Coverage32_3_pre >= 500000) &&
	                    (Coverage51_1_pre >= 150000) && (Coverage51_2_pre >= 1500000) && (Coverage51_3_pre >= (1500000 * qpt)))
	                {
	                    IntHPHACount = -1;
	                    LngHPHAPrem = Lng31Prem + Lng32Prem + Lng51Prem;
	       		    }
            }
       		else
       		{
  	                if ((Coverage31_1 >= 2000000) && (Coverage31_3 >= Coverage31_Top) && (Coverage32_3 >= 500000) &&
	                    (Coverage51_1 >= 150000) && (Coverage51_2 >= 1500000) && (Coverage51_3 >= (1500000 * qpt)))
			    
	                {    
			                if ((Coverage31_1_pre >= 2000000) && (Coverage31_3_pre >= Coverage31_Top) && (Coverage32_3_pre >= 500000) &&
			                    (Coverage51_1_pre >= 150000) && (Coverage51_2_pre >= 1500000) && (Coverage51_3_pre >= (1500000 * qpt)))
			                 {
			                    IntHPHACount = 0;
			                    LngHPHAPrem = Lng31Prem + Lng32Prem + Lng51Prem;
			       		     }
			                 else
			                 {
			                    IntHPHACount = 1;
			                    LngHPHAPrem = Lng31Prem + Lng32Prem + Lng51Prem;
			                 }	
	       		    }	
       	    }
       			$INSERT INTO car6062_tmp_tbl VALUES
       			 ($nbig_area, $nbig_office, $ibig_sales, $nbig_sales,
       			  $ipolicy, $icard, $iendorse, $nassured, $dply_begin,
                          $dpolicy, $iengine, $itag, $IntPlyCount, $LngPlyPrem,
                          $IntDmgCount, $LngDmgPrem, $IntHPHACount,
                          $LngHPHAPrem, $lDpay, $iquota, $icar_type);
        }
       	$CLOSE  AcursorE1;
       	$FREE   AcursorE1;
  	}
  	return SUCCESS;
    
errexit:
   	sqlfatal();
   	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   	return SQLCODE;
}    
/*--------------------------------------------------------------------*/

long car6062_create_rpt()
{ 
  	$char sfilename[41];
  	$char stitle[512];
  	$char sErrmsg[200];  
  	$char stmt[5000];
    $long count_tbl;

  	$WHENEVER SQLERROR GOTO errexit;
  	$CREATE INDEX car6062_ix_1 ON car6062_tmp_tbl(nbig_area);
  	$CREATE INDEX car6062_ix_2 ON car6062_tmp_tbl(ipolicy);

    $select count(*)
       into $count_tbl
       from car6062_tmp_tbl;
    printf("car6062_tmp_tbl���[%ld]\n",count_tbl);

  	strcpy(sfilename,"�g�P�Ө����I�ΰ������N���Ӫ�");
  	strcpy(stitle,"�Ұ�\t���N��\t���W��\t����\t���I\t�~�N�N��\t�~�N�W��\t�O�渹�X\t�O�I�d��\t��渹�X\t�Ȥ�m�W\t�O��ͮĤ�\tñ���\t�������X\t���P���X\t���N�I���\t���N�I�O�O\t�����I���\t�����I�O�O\t�������N���\t�������N�O�O\t���O���\t����\t");

  	strcpy(stmt,"SELECT (select ncode from cu_code_data,sa_branch_type  "
    " where ibranch = iquota and group2 = icode and itype = '19'),iquota, "
    " (select nbranch from sa_branch_type where ibranch = iquota[1,4]||'00'), "
                    " nbig_area,nbig_office,ibig_sales,nbig_sales, "
		                "ipolicy,icard,iendorse,nassured,dply_begin,dpolicy,iengine,itag,  "
				        "ply_count,ply_prem,dmg_count,dmg_prem,HPHA_count,HPHA_prem,dpay,icar_type  "
  			     "FROM   car6062_tmp_tbl  "
  			     "ORDER BY nbig_area,ipolicy ");
  	
  	rc = unload_file(outputf," ",sfilename,stitle,stmt);
  
  	if (rc != SUCCESS)
  	{
  	  	if (rc == 3501){
  	     	sprintf_s(sErrmsg, sizeof sErrmsg," ��J���d�߱���䤣���� ",sfilename);
  	  	}
  	  	else
  	  	{
  	     	sprintf_s(sErrmsg, sizeof sErrmsg," %s �ɮ׵L�k���� ",sfilename);
  	  	}
      
      	EWRITE(userid, rc , sErrmsg);
      	exit(1);
  	}

 return SUCCESS;
   
errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(1);   
}
