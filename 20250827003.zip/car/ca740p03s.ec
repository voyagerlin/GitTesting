/**********************************************************************/
/*   program id   : ca740p03s.ec                                      */
/*   program name : ���M�O�N������ɧ@�~(�ӫO)                        */
/*   date written : 2018/11/09                                        */
/*   author       : 061476                                            */                                       
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include "safeclib.h"
#include <math.h>

/****************************************************************************/
$char DBName[05],userid[11];
$char fclass[2],date1[10],date2[10],dbgn[11],dend[11];
int   count_db, k;

$char date[11],dToday[11],nyy[4],nmm[3],ndd[3];
char  msgbuf[2048],sApHome[30];
char  outputf[N_FILE+1];
int   count_db,k;
long  t;
DBinfo *list;

$char icard_c[21],ipolicy_c[21],dply_begin_c[11],dply_end_c[11];
$char icard[21],ipolicy[21],dply_begin[11],dply_end[11];
$int  prem_c,prem;

long car740_get_db();
/****************************************************************************/
main(argc, argv)
int argc;
char **argv;
{  
	int rc;

	batchinit();
	strcpy(DBName, isNULLstr(argv[1]));
	strcpy(userid, isNULLstr(argv[2]));
	strcpy(fclass, isNULLstr(argv[3]));  /* 1�G��O 2�G�z�� 3�G�ӫO */
	strcpy(date1,  isNULLstr(argv[4]));
	strcpy(date2,  isNULLstr(argv[5]));
	strcpy(outputf,isNULLstr(argv[6]));
	
	strcpy(dbgn, cm_to_infdate(date1));
	strcpy(dend, cm_to_infdate(date2));
	printf("-- ����϶�(�褸):[%s] ~ [%s]\n",dbgn,dend);
			
	rc = car740_get_db();
	if (rc != M_CM_OK)
	{
		EWRITE(userid,rc,msgbuf);
		return rc;
	}

	$BEGIN WORK;
		
	rc = car740_get_data();
	if (rc != M_CM_OK)
	    return rc;
        	
	$COMMIT WORK;
			
  return rc;
}
/******************************************************************************/
long car740_get_data()
{
    $char  stmt_buf[1024],sFullName[32];
    $int   isql2;
            
    printf("BEGIN TO car740_get_data\n");    

    $WHENEVER SQLERROR GOTO errexit;
                                            
    $DECLARE acur CURSOR for 
    SELECT iforce_card_no, irand_card_no  
      FROM sysdb:ca_rioho_pol_m_req
     WHERE dcreate::date BETWEEN $dbgn AND $dend
       AND freturn_status = '';      

    $OPEN acur;    
    while(1)
    {
    	$FETCH acur INTO $icard_c, $icard;
    	
    	if (SQLCODE == SQLNOTFOUND) break;
    	printf("icard[%s],icard_c[%s]\n",icard,icard_c);
    	
    	prem_c = prem = 0;
    	init_data();
    	
    	/* �j�� */
    	if (strlen(trim(icard_c))!= 0)
    	{
    		$SELECT ipolicy1 INTO $ipolicy_c
    		   FROM policy_new
    		  WHERE isys_source = 'CAR'
    		    AND itarget2 = $icard_c;
    		
    		if (SQLCODE != SQLNOTFOUND)
    		{
    			strcpy(sFullName, get_car_full_db(ipolicy_c));
    			sprintf_s(stmt_buf, sizeof stmt_buf,
    			    " SELECT dply_begin,dply_end "
    			    "   FROM %s:ori_ply_relation "
    			    "  WHERE ipolicy = '%s'; " ,sFullName,ipolicy_c);
    			$PREPARE get_data_c FROM $stmt_buf;
    			$EXECUTE get_data_c INTO $dply_begin_c,$dply_end_c;
    			
    			sprintf_s(stmt_buf, sizeof stmt_buf,
    			    " SELECT sum(mins_premium) "
    			    "   FROM %s:ori_ins_type "
    			    "  WHERE ipolicy = '%s'; " ,sFullName,ipolicy_c);
    			$PREPARE get_prem_c FROM $stmt_buf;
    			$EXECUTE get_prem_c INTO $prem_c;    			
    		}
    	}
    	
    	/* ���N */ 
    	if (strlen(trim(icard))!= 0)
    	{
    		$SELECT ipolicy1 INTO $ipolicy
    		   FROM policy_new
    		  WHERE isys_source = 'CAR'
    		    AND itarget2 = $icard;
    		
    		if (SQLCODE != SQLNOTFOUND)
    		{
    			strcpy(sFullName, get_car_full_db(ipolicy));
    			sprintf_s(stmt_buf, sizeof stmt_buf,
    			    " SELECT dply_begin,dply_end "
    			    "   FROM %s:ori_ply_relation "
    			    "  WHERE ipolicy = '%s'; " ,sFullName,ipolicy);
    			$PREPARE get_data FROM $stmt_buf;
    			$EXECUTE get_data INTO $dply_begin,$dply_end;
    			
    			sprintf_s(stmt_buf, sizeof stmt_buf,
    			    " SELECT sum(mins_premium) "
    			    "   FROM %s:ori_ins_type "
    			    "  WHERE ipolicy = '%s'; " ,sFullName,ipolicy);
    			$PREPARE get_prem FROM $stmt_buf;
    			$EXECUTE get_prem INTO $prem;
    		}
    	}
    	
    	if (strlen(trim(ipolicy_c))== 0 && strlen(trim(ipolicy))== 0)
    	{
    		$UPDATE sysdb:ca_rioho_pol_m_req
    		    SET freturn_status = '2', dupdate = current
    	          WHERE iforce_card_no = $icard_c
    	            AND irand_card_no = $icard;
    	}
    	else
    	{
    		$UPDATE sysdb:ca_rioho_pol_m_req
    		    SET iforce_insu_no = $ipolicy_c, dforce_dates = $dply_begin_c,
    	                dforce_datee = $dply_end_c ,mforce_amt = $prem_c,
    	                irand_insu_no = $ipolicy, drand_dates = $dply_begin, 
    	                drand_datee = $dply_end, mrand_amt = $prem,
    	                freturn_status = '1', dupdate = current
    	          WHERE iforce_card_no = $icard_c
    	            AND irand_card_no = $icard;
    	}
    	
    	/* �Y�j+�����u���@�ӫO�渹�A�^�_���A���@���� */
    	if ((strlen(trim(icard))!= 0 && strlen(trim(ipolicy))== 0)||
    	    (strlen(trim(icard_c))!= 0 && strlen(trim(ipolicy_c))== 0))
    	{
    		$UPDATE sysdb:ca_rioho_pol_m_req
    		    SET freturn_status = '2'
    	          WHERE iforce_card_no = $icard_c
    	            AND irand_card_no = $icard;
    	}
    		
    }
    $CLOSE acur;
    $FREE acur;
     
    return M_CM_OK;

errexit:
    sqlfatal();
    isql2 = SQLCODE;
    $ROLLBACK WORK;
    EWRITE(userid,isql2,sqlca.sqlerrm);
    return isql2;
}
/******************************************************************************/
init_data()
{
	strcpy(ipolicy," ");   
	strcpy(dply_begin," ");
	strcpy(dply_end," ");
	
	strcpy(ipolicy_c," ");
	strcpy(dply_begin_c," ");
	strcpy(dply_end_c," ");
}
/******************************************************************************/
long car740_get_db()
{
	int return_code;
	
	$WHENEVER SQLERROR GOTO errexit;
	
	t = cm_today();
	strcpy(date,cm_edate_str(t));  
	strcpy(dToday,cm_from_infdate_100(date));
	cm_split_ymd_100(dToday,nyy,nmm,ndd);

	if (db_select(DBName) == False)
	{
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}
	if ( (list = get_db_list(&count_db,DBName)) == (char*)0 )
	{
		EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
		return M_CM_NOT_DBLIST;
	}
	
	return_code = getApHome(sApHome);
	if (return_code < 0) 
	{
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		return return_code;	
	}  
  return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;  
}
/******************************************************************************/
