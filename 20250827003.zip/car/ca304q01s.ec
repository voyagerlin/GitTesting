/**********************************************************************/
/*   program id   : ca304q01s.ec                                      */
/*   program name : �O��H�u�f�ֲέp����                              */
/*   date written : 2018/01/02 by 061476                              */
/**********************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <decimal.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "globdata.h"
#include "safeclib.h"

$char ipass[11],dpass_bgn[10],dpass_end[10],ipolicy[21],ibranch[3],fpass[2];


int   count_db,k; 
char  outputf[21];
$char userid[11];
$char DBName[05];
$char msgbuf[128];

DBinfo *list;
/*--------------------------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
 int rc;

	batchinit();
	strcpy(DBName,         isNULLstr(argv[1]));
	strcpy(userid,         isNULLstr(argv[2]));
	strcpy(ipass,          isNULLstr(argv[3]));  /*�f�֤H��*/
	strcpy(dpass_bgn,      isNULLstr(argv[4]));  /*�f�ְ϶�(�_:CYYMMDD)*/
	strcpy(dpass_end,      isNULLstr(argv[5]));  /*�f�ְ϶�(��)*/
	strcpy(ipolicy,        isNULLstr(argv[6]));  /*�O�渹*/
	strcpy(ibranch,        isNULLstr(argv[7]));  /*�X����(�O��e��X)*/
	strcpy(fpass,          isNULLstr(argv[8]));  /*�f�֪��A*/
	strcpy(outputf,        isNULLstr(argv[9]));
	
	printf("1.car304_get_db() \n");
	rc = car304_get_db();
	if (rc != M_CM_OK)
		return rc;
		
	printf("2.car304_build() \n");	
	rc = car304_build();
	if (rc != M_CM_OK) 
		return rc;
}
/*--------------------------------------------------------------------------------------*/
long car304_get_db()
{
	$whenever sqlerror goto errexit;

	if (db_select(DBName) == FALSE) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
/*--------------------------------------------------------------------------------------*/
long car304_build()
{
	int rc;
	char sfilename[256],stitle[2048],stmt[6000];
	$char stmt1[1024];
	$char stmp_ipass[64],stmp_dbgn[64],stmp_ipolicy[64];
	$char stmp_ibranch[64],stmp_fpass[64];
	$char dbgn[11],dend[11];

	$WHENEVER SQLERROR goto errexit;
	
	if (db_select(DBName) == FALSE)
	{
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return FAIL;
	}

	strcpy(ipass,trim(ipass));
	strcpy(ipolicy,trim(ipolicy));
	strcpy(ibranch,trim(ibranch));
	strcpy(fpass,trim(fpass));
	
	if(strncmp(fpass,"Y",1) == 0)
	    sprintf_s(stmp_fpass,sizeof stmp_fpass,"WHERE fpass in ('Y','P') ");
	else 
	    sprintf_s(stmp_fpass,sizeof stmp_fpass,"WHERE fpass = 'N' ");
	    	
	if(strncmp(ipass,"*",1) != 0)
	    sprintf_s(stmp_ipass,sizeof stmp_ipass,"AND ipass = '%s' ",ipass);
	else
	    sprintf_s(stmp_ipass,sizeof stmp_ipass,"  ");
	
	if(strncmp(dpass_bgn,"*",1) != 0)
	{
		strcpy(dbgn,cm_to_infdate(dpass_bgn));
		strcpy(dend,cm_to_infdate(dpass_end));
		sprintf_s(stmp_dbgn,sizeof stmp_dbgn,"AND dpass between '%s' and '%s' ",dbgn,dend);
	}  
	else
	    sprintf_s(stmp_dbgn,sizeof stmp_dbgn,"  ");
	
	if(strncmp(ipolicy,"*",1) != 0)
	    sprintf_s(stmp_ipolicy,sizeof stmp_ipolicy,"AND (ipolicy1 = '%s' or ipolicy2 = '%s') ",ipolicy,ipolicy);
	else
	    sprintf_s(stmp_ipolicy,sizeof stmp_ipolicy,"  ");
	
	if(strncmp(ibranch,"*",1) != 0)
	    sprintf_s(stmp_ibranch,sizeof stmp_ibranch,"AND (ipolicy1[1,2] = '%s' or ipolicy1[1,2] = '%s') ",ibranch,ibranch);
	else
	    sprintf_s(stmp_ibranch,sizeof stmp_ibranch,"  ");
    
	$create temp table car304_tmp1
	(
	    nassured      char(120),
	    iabnormal     char(20),
		ipolicy1      char(20),
		ipolicy2      char(20),
		itag          char(12),
		dcomp_begin   char(10),
		dcomp_end     char(10),
		dbegin        char(10),
		dend          char(10),
		ipass         char(21),
		dpass         char(10),
		npass         char(100)
	) with no log;
	
	/* SQL����''��ASCII��127�X,�i����EXCEL�ɮɥi������ܼƦr���e,���|���@�Ӧr��,
       �p�G�s�ɷ|�y������x�s�Τ����D,���V�� */
	
	sprintf_s(stmt1,sizeof stmt1,"INSERT INTO car304_tmp1 "
			             " SELECT nassured,iabnormal,ipolicy1,ipolicy2,itag, "
			             "        dcomp_begin,dcomp_end,dbegin,dend, "
			             "        trim(ipass)||':'||(SELECT nname FROM officer WHERE iofficer = ipass),dpass,npass"
			             " FROM abnormal_ply "  
	  		             " %s %s %s %s %s "
	  		             ,stmp_fpass,stmp_ipass,stmp_dbgn,stmp_ipolicy,stmp_ibranch);
	  		
	printf("--stmt1[%s]\n", stmt1);
	$PREPARE ply_tmp FROM $stmt1;
	$EXECUTE ply_tmp;

	strcpy(sfilename,"�O��H�u�f�ֲέp����[car304]");
    sprintf_s(stitle,sizeof stitle,"�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");
	
	strcat(stitle,"\t�Q�O�I�H\t���`��\t�j��O�渹\t���N�O�渹\t����\t�j��O�I�_��\t�j��O�I����");
	strcat(stitle,"\t���N�O�I�_��\t���N�O�I����\t�}��H��\t�}����\t�֭��]");
    
    strcpy(stmt,"select * from car304_tmp1 where 1=1 ");
	               
	rc = unload_file(outputf," ",sfilename,stitle,stmt);
	
	if (rc != SUCCESS) 
	{
	    sprintf_s(msgbuf,sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
	    EWRITE(userid, rc , msgbuf);
	    return rc;
	}
	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	return SQLCODE;
}
