/************************************************/
/*                                              */
/*   PROGRAM : ca304p01s.ec                     */
/*                                              */
/************************************************/
     
#include <stdio.h>

$include sqlca;
$include decimal;

#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "carmsgs.h"
#include "safeclib.h"



$char sqlstmt[1000] ;

long car304(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car304_single_query(),car304_update_exec();
 long car304_multiple_query();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'M':
           rtncode=car304_multiple_query(reply);
           break;
  case 'Q':
           rtncode=car304_single_query(reply);
           break;
  case 'P':
           rtncode=car304_update_exec(reply,command,com_len);
           break;
  default :
           if(exitsub(reply,M_CM_WRONG_OPTION) == True)
            return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}

/**********************************************************************/
long car304_multiple_query(reply)
serverReply reply;
{
 $char DBName[DBNAME];

 $char iabnormal[CA_ESTIMATE_NUM],fpass[2],iabn_type[2];
 $char fpass_C[2],iabn_type_C[2],ibranch_C[BRANCH_ID];
 char  tmpbuf[4000];
 int   count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int   i,total_count=0; 

 int   flag=0;
 char  taipei_db[40];
 int   rc;


 cm_buf_get("%s",DBName);
 cm_buf_get("%s %s %s",iabn_type_C,fpass_C,ibranch_C);

 $WHENEVER SQLERROR GOTO errexit;

 rc = getHeadBranch(taipei_db);
 if (rc < 0) {
     printf("read Config file error!!\n");
     return M_CM_READ_CONFIG_ERR;
 }

 if (db_select(taipei_db) == False) 
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

printf("[%s] [%s]\n",iabn_type_C,fpass_C);
 if (fpass_C[0]==' ' || fpass_C[0]=='\0')
  {
printf("[%s] [%s] [%s]\n",iabn_type_C,fpass_C,ibranch_C);
  sprintf_s(sqlstmt,sizeof sqlstmt,"SELECT fpass,iabn_type,iabnormal "
                                   " FROM abnormal_ply "
                                   "WHERE iabnormal[1,2] = '%s' AND "
                                   "      iabn_type MATCHES '%s*' AND "
                                   "      (fpass IS NULL OR fpass = ' ') "
                                   "ORDER BY iabnormal",ibranch_C,iabn_type_C) ;

 printf("[%s]\n",sqlstmt) ;

 $PREPARE pp FROM $sqlstmt ;
 $DECLARE q1_cur CURSOR FOR pp ;
  }
 else if (fpass_C[0] == '*')
  {
  $DECLARE q2_cur CURSOR FOR
    SELECT  fpass, iabn_type, iabnormal
      INTO  $fpass, $iabn_type, $iabnormal
      FROM  abnormal_ply
     WHERE  iabn_type matches $iabn_type_C
   ORDER BY iabnormal;
  }
 else 
  {
  $DECLARE q3_cur CURSOR FOR
    SELECT  fpass, iabn_type, iabnormal
      INTO  $fpass, $iabn_type, $iabnormal
      FROM  abnormal_ply
     WHERE  iabn_type matches $iabn_type_C 
       AND fpass matches $fpass_C 
   ORDER BY iabnormal;
  }
 if (fpass_C[0] == ' ')
  $OPEN q1_cur;
 else if (fpass_C[0] == '*')
  $OPEN q2_cur;
 else
  $OPEN q3_cur;

  cm_buf_init(ReplyBuf);

  for (;;)
  {
    if (fpass_C[0] == ' ')
      $FETCH q1_cur
        INTO  $fpass, $iabn_type, $iabnormal ;
    else if (fpass_C[0] == '*')
      $FETCH q2_cur;
    else
      $FETCH q3_cur;
     if(SQLCODE != 0) break;
   
     if(count == 0)
     {
       cm_buf_res_msg();
       cm_buf_res_count();
     }
     cm_buf_put("%s %s %s",iabnormal,iabn_type,fpass);
     repbuf_len = cm_buf_len();
     if ( repbuf_len < 3000 )
     {
       count++;
     }
     else
     {
       cm_buf_put_msg(M_CM_OK);
       cm_buf_put_count(count);
       if(SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
        if (fpass_C[0] == ' ')
        {
          $CLOSE q1_cur;
          $FREE q1_cur;
        }
        else if (fpass_C[0] == '*')
        {
          $CLOSE q2_cur;
          $FREE q2_cur;
        }
        else
        {
          $CLOSE q3_cur;
          $FREE q3_cur;
        }
        return apiRC;
       }
       else
       {
         replycnt++;
         if(replycnt == 10)
         {
           cm_buf_init(ReplyBuf);
           cm_buf_put("%l",M_CM_OUT_SPACE);
           repbuf_len = cm_buf_len();
           if(SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
             return apiRC;
           return M_CM_OUT_SPACE; 
         }
         ReplyBuf[0] = '\0';
         count = 0;
         cm_buf_init(ReplyBuf);
         cm_buf_res_msg();
         cm_buf_res_count();
         cm_buf_put("%s %s %s",iabnormal,iabn_type,fpass);
         repbuf_len = cm_buf_len();
         count++;
       }
     }
   } /* for loop */
 if (fpass_C[0] == ' ')
 {
     $CLOSE q1_cur;
     $FREE q1_cur;
 }
 else if (fpass_C[0] == '*')
 {
     $CLOSE q2_cur;
     $FREE q2_cur;
 }
 else
 {
     $CLOSE q3_cur;
     $FREE q3_cur;
 }
if(count > 0)
{
  cm_buf_put_msg(M_CM_OK);
  cm_buf_put_count(count);
  repbuf_len = cm_buf_len();
  if(SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
    return apiRC;
  return api_OKComplete; 
}
else
{
  if(exitsub(reply,M_CM_NOT_FOUND) == True) 
    return M_CM_NOT_FOUND; 
  else  
    return apiRC;
}

 errexit:
  if(exitsub(reply,SQLCODE) == True) 
   return SQLCODE;
  else  
   return apiRC;
}

/***************************************************************/
long car304_single_query(reply)
serverReply reply;
{
 $char DBName[DBNAME];

 $char iabnormal[CA_ESTIMATE_NUM],fpass[2],iabn_type[2];
 $char ilast_ply[POLICY_NUM_1];
 $char ilast_card[CARD_NUM],iins_card[CARD_NUM],icomp_card[CARD_NUM];
 $char ixxcard[CARD_NUM],iassured[CUSTOMER_ID],fassured[2],fcut[2];
 $char nassured[ASSURED_NAME],nuser[19],ibenef[11],nbenef[43];
 $char aassured[91],apayment[91],itel[21];
 $long qperiod=0,dbegin=0,dend=0,qcomp_period=0,dcomp_begin=0,dcomp_end=0;
 char  s_dbegin[YYYMMDD],s_dend[YYYMMDD];
 char  s_dcomp_begin[YYYMMDD],s_dcomp_end[YYYMMDD];
 $char dissue[11],ipro_year[5],ibrand[9];
 $char nbrand_abbr[13];
 $char icar_type1[CA_CAR_TYPE_NUM],icar_type2[CA_CAR_TYPE_NUM];
 $char ncode1[11],ncode2[11]; /* car_type */
 $double qcylinder=0;/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/
 $char iengine[CA_ENGINE_NUM],ibody[CA_BODY_NUM],itag[CA_TAG_NUM],ilicense[CUSTOMER_ID];
 $char dbirth[11],fsex[2],fmarriage[2],iacc_align[3],flimit[2];
 $long pdmg_align=0,plia_align=0;
 $char iofficer1[EMPLOYEE_ID],iofficer2[EMPLOYEE_ID];
 $char ibroker1[BROKER],ibroker2[BROKER];
 $char icashier[EMPLOYEE_ID],iexaminer[EMPLOYEE_ID],ientry[EMPLOYEE_ID];
 $char itreaty[2],iresource[7];
 $char ibig_branch[5],ibig_office[10],ibig_sales[11];

 $dec_t mcar_price,plia_acc1,plia_acc2,pdmg_acc,pdmg_acc2,pdmg_acc3; /* it is decimal */
 char   s_mcar_price[9],s_plia_acc1[9],s_plia_acc2[9],s_pdmg_acc[9];

 $char nequipment[31];
 $long mdali_prem=0,mcomp_prem=0; /* and sum of them */
 
 $char iins_type[INSURANCE_TYPE],sIins_type[7];
 $long minjured_cover=0,mdeath_cover=0,mdamage_cover=0,mins_premium=0;
 $long qserial;
 $long mdeduct=0;
 $char sTmpcylinder[9];/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/ 
 char  tmpbuf[4000];
 int   count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int   i,total_count=0; 

 $int   Xprovision=0;  /* 1070928002-SC1-�O�I�����ܧ�Τ��~�פ���[X����*/
 $char cal_pro_year[5];
 char  taipei_db[40];
 int   rc;

 $long iCa_log_RBA; /* 1061012002-SC3 -ISID+RBA*/
 
 $char isequence[31]; /*1120927002-C09-�R�q�ΰӫ~�}�o*/

 cm_buf_get("%s",DBName);
 cm_buf_get("%s",iabnormal);
 printf("*******iabnormal[%s]\n",iabnormal);

 $WHENEVER SQLERROR GOTO errexit;


 
 memset(&mcar_price,0,sizeof(mcar_price));
 memset(&plia_acc1,0,sizeof(plia_acc1));
 memset(&plia_acc2,0,sizeof(plia_acc2));
 memset(&pdmg_acc,0,sizeof(pdmg_acc));
 memset(&pdmg_acc2,0,sizeof(pdmg_acc2));
 memset(&pdmg_acc3,0,sizeof(pdmg_acc3));
 
 
 rc = getHeadBranch(taipei_db);
 if (rc < 0) {
     printf("read Config file error!!\n");
     return M_CM_READ_CONFIG_ERR;
 }

 if (db_select(taipei_db) == False) 
 {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
 }

 $SELECT abnormal_ply.fpass, abnormal_ply.iabn_type, abnormal_ply.ilast_ply, 
         abnormal_ply.ilast_card,
         abnormal_ply.iins_card, abnormal_ply.icomp_card,
         abnormal_ply.ixxcard, abnormal_ply.iassured,
         abnormal_ply.fassured, abnormal_ply.fcut, abnormal_ply.nassured,
         abnormal_ply.nuser, abnormal_ply.ibenef,
         abnormal_ply.nbenef, abnormal_ply.aassured, abnormal_ply.apayment,
         abnormal_ply.itel, abnormal_ply.qperiod,
         abnormal_ply.dbegin, abnormal_ply.dend, abnormal_ply.qcomp_period,
         abnormal_ply.dcomp_begin,
         abnormal_ply.dcomp_end, abnormal_ply.dissue,
         abnormal_ply.ipro_year, abnormal_ply.ibrand,
         abnormal_ply.icar_type1,abnormal_ply.icar_type2,
         abnormal_ply.qcylinder,
         abnormal_ply.iengine, abnormal_ply.ibody, abnormal_ply.itag, 
         abnormal_ply.ilicense,
         abnormal_ply.dbirth, abnormal_ply.fsex, abnormal_ply.fmarriage,
         abnormal_ply.flimit, abnormal_ply.pdmg_align, 
         abnormal_ply.plia_align, abnormal_ply.iofficer1,abnormal_ply.iofficer2,
         abnormal_ply.ibroker1,abnormal_ply.ibroker2, abnormal_ply.icashier,
         abnormal_ply.iexaminer,
         abnormal_ply.ientry,plia_acc1,plia_acc2,pdmg_acc,
         abnormal_ply.itreaty, abnormal_ply.iresource, 
         abnormal_ply.ibig_branch, abnormal_ply.ibig_office,
         abnormal_ply.ibig_sales, abnormal_ply.mcar_price, 
         abnormal_ply.nequipment,
         abnormal_ply.mdali_prem, abnormal_ply.mcomp_prem,
         abnormal_ply.pdmg_acc2,abnormal_ply.pdmg_acc3, abnormal_ply.isequence
    INTO $fpass, $iabn_type, $ilast_ply, $ilast_card, $iins_card, 
         $icomp_card, $ixxcard, $iassured,
         $fassured, $fcut, $nassured, $nuser, $ibenef, $nbenef, $aassured,
         $apayment, $itel, $qperiod,
         $dbegin, $dend, $qcomp_period, $dcomp_begin, $dcomp_end,
         $dissue, $ipro_year, $ibrand,
         $icar_type1,$icar_type2, $qcylinder, $iengine, $ibody,
         $itag, $ilicense, $dbirth,
         $fsex, $fmarriage, $flimit, $pdmg_align, $plia_align,
         $iofficer1,$iofficer2, $ibroker1,$ibroker2, $icashier,
         $iexaminer, $ientry,$plia_acc1,$plia_acc2,$pdmg_acc, 
         $itreaty, $iresource, $ibig_branch,
         $ibig_office, $ibig_sales, $mcar_price,
         $nequipment, $mdali_prem, $mcomp_prem,$pdmg_acc2,$pdmg_acc3, $isequence
    FROM abnormal_ply
   WHERE abnormal_ply.iabnormal=$iabnormal ;

 if(SQLCODE==SQLNOTFOUND) 
  {
   printf("no found here \n");
   if(exitsub(reply,M_CM_NOT_FOUND) == True) 
    return M_CM_NOT_FOUND; 
   else  
    return apiRC;
  }
  
printf("--------------brand[%s] \n",ibrand);
  memset(ncode1,0,sizeof(ncode1));
  memset(ncode2,0,sizeof(ncode2));
  memset(s_plia_acc1,0,sizeof(s_plia_acc1));
  memset(s_plia_acc2,0,sizeof(s_plia_acc2));
  memset(s_pdmg_acc,0,sizeof(s_pdmg_acc));
  $SELECT ncode INTO $ncode1 FROM car_type
   WHERE icode=$icar_type1 AND fclass='1';

  $SELECT ncode INTO $ncode2 FROM car_type
   WHERE icode=$icar_type2 AND fclass='1';
   
   /*1120927002-C09-�R�q�ΰӫ~�}�o �R�q�ΨS���t�P����*/
   printf("icar_type1 = [%s], icar_type2 = [%s]\n", icar_type1, icar_type2);
   if(strcmp(trim(icar_type2), "CS") != 0)
   {
	   printf("In brand detect\n");
       /* 104.09.09 fix ca_car_model �^���޿� */
        /* car9812112_C1 �t�P�����ɷs�W���Τ� modify by sylvia 100.09.21 */
        $DECLARE cur CURSOR FOR
          SELECT nbrand_abbr,drate
            INTO $nbrand_abbr
            FROM ca_car_model
           WHERE ibrand=$ibrand
             AND ipro_year=$ipro_year
             AND (dexpire is null or dexpire > today)
             ORDER BY drate DESC;
       $OPEN cur;
       $FETCH cur;
       if(SQLCODE==SQLNOTFOUND) 
       {
        $DECLARE curA CURSOR FOR
         SELECT nbrand_abbr,drate
            INTO $nbrand_abbr
            FROM ca_car_model
           WHERE ibrand=$ibrand
             AND (dexpire is null or dexpire > today)
             AND ipro_year=(SELECT MAX(ipro_year) FROM ca_car_model
                             WHERE ibrand=$ibrand AND ipro_year < $ipro_year
                               AND (dexpire is null or dexpire > today))
             ORDER BY drate DESC;
        $OPEN curA;
        $FETCH curA;
        if(SQLCODE==SQLNOTFOUND) 
        {
	        $DECLARE curA1 CURSOR FOR
	         SELECT nbrand_abbr,drate
	            INTO $nbrand_abbr
	            FROM ca_car_model
	           WHERE ibrand=$ibrand
	             AND (dexpire is null or dexpire > today)
	             AND ipro_year=(SELECT MIN(ipro_year) FROM ca_car_model
	                             WHERE ibrand=$ibrand AND ipro_year > $ipro_year
	                               AND (dexpire is null or dexpire > today))
	             ORDER BY drate DESC;
	        $OPEN curA1;
	        $FETCH curA1;
	        if(SQLCODE==SQLNOTFOUND) 
	        {        	        	
                printf("no found here \n");
                /* if(exitsub(reply,M_CM_NOT_FOUND) == True) 
                        return M_CM_NOT_FOUND; */
                if(exitsub(reply,M_CA_NBRAND) == True) 
                        return M_CA_NBRAND; 
                else  
                        return apiRC;
            }     
	        $CLOSE curA1;
	        $FREE curA1;                   
        }
        $CLOSE curA;
        $FREE curA;
       }
       $CLOSE cur;
       $FREE cur;
   }
/**
  $DECLARE cur CURSOR FOR 
    SELECT nbrand_abbr
      FROM ca_car_model
     WHERE ibrand=$ibrand
       AND ipro_year=$cal_pro_year;
  $OPEN cur;
  $FETCH cur INTO $nbrand_abbr;
  if(SQLCODE==SQLNOTFOUND) 
  {
     printf("no found here \n");
     if(exitsub(reply,M_CM_NOT_FOUND) == True) 
        return M_CM_NOT_FOUND; 
     else  
        return apiRC;
  }
****/

   /* �P�_����Y�� pdmg_acc(01,08)�Bpdmg_acc2(05,09)�Bpdmg_acc3(85,105) */
    $SELECT iins_type
       INTO $sIins_type
       FROM abn_ply_ins_type
      WHERE iabnormal = $iabnormal
        AND iins_type in ('01','08','05','09','85','105','201','205','209');
      if(SQLCODE==SQLNOTFOUND) strcpy(sIins_type," ");
      
    strcpy(sIins_type,trim(sIins_type));
    if ((strncmp(sIins_type,"01",2) == 0) || (strncmp(sIins_type,"08",2) == 0) || (strncmp(sIins_type,"201",3) == 0))    
        dectoasc(&pdmg_acc,s_pdmg_acc,8,1);   
    else if ((strncmp(sIins_type,"05",2) == 0) || (strncmp(sIins_type,"09",2) == 0) || (strncmp(sIins_type,"205",3) == 0) || (strncmp(sIins_type,"209",3) == 0))
    	  dectoasc(&pdmg_acc2,s_pdmg_acc,8,1);
    else if ((strncmp(sIins_type,"85",2) == 0) || (strncmp(sIins_type,"105",3) == 0))   
    	  dectoasc(&pdmg_acc3,s_pdmg_acc,8,1);    
    else
    	  strcpy(s_pdmg_acc,"0.0");

    /* 1061012002-SC3- ISID+RBA*/
    iCa_log_RBA = 0;
    $select count(*) INTO $iCa_log_RBA
       from ca_log 
      WHERE ipgid ='car301'
        AND itype = 'A'
        AND ilog_number1 = $iabnormal;
    if(SQLCODE==SQLNOTFOUND) iCa_log_RBA =0;
    
    /* 1070928002-SC1-�O�I�����ܧ�Τ��~�פ���[X����*/
     /* 1081225006-SC1-���ά�-�X�R���[���ڥN�X AND CHARINDEX('X',provision)>0; */
    $SELECT count(*) INTO $Xprovision
       FROM abn_ply_ins_type
      WHERE iabnormal = $iabnormal
        AND trim(provision)||';' matches 'X;';
    if(SQLCODE==SQLNOTFOUND) Xprovision =0;
    
    
    dectoasc(&mcar_price,s_mcar_price,8,1);
    dectoasc(&plia_acc1,s_plia_acc1,8,1);
    dectoasc(&plia_acc2,s_plia_acc2,8,1);
    s_mcar_price[8] = '\0';
    printf("s_mcar_price = %s\n", s_mcar_price);
 
    /*strcpy(s_dbegin, cm_cdate_str_100(dbegin));
    strcpy(s_dend, cm_cdate_str_100(dend));
    strcpy(s_dcomp_begin, cm_cdate_str_100(dcomp_begin));
    strcpy(s_dcomp_end, cm_cdate_str_100(dcomp_end));*/
    
    memcpy(s_dbegin,cm_cdate_str_100(dbegin),9); 
    s_dbegin[10]='\0';
    memcpy(s_dend,cm_cdate_str_100(dend),9); 
    s_dend[10]='\0';
    memcpy(s_dcomp_begin,cm_cdate_str_100(dcomp_begin),9);
    s_dcomp_begin[10]='\0';
    memcpy(s_dcomp_end,cm_cdate_str_100(dcomp_end),9);
    s_dcomp_end[10]='\0';
    
    printf("s_dbegin = %s\n", s_dbegin);
    printf("s_dend = %s\n", s_dend);
    printf("s_dcomp_begin = %s\n", s_dcomp_begin);
    printf("s_dcomp_end = %s\n", s_dcomp_end);

    /*strcpy(sTmpcylinder," ");*//* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/
    sTmpcylinder[0]='\0';
    sprintf_s(sTmpcylinder,sizeof sTmpcylinder,"%8.2f",qcylinder); 
    /*strcpy(sTmpcylinder, trim(sTmpcylinder));*/
    memcpy(sTmpcylinder,trim(sTmpcylinder),9);
    sTmpcylinder[10]='\0';
    printf("sTmpcylinder[%s]\n",sTmpcylinder);
	memcpy(isequence, trim(isequence), 30);
	isequence[30] = '\0';
    printf("isequence = [%s]\n", isequence);
    
    cm_buf_init(ReplyBuf); 
    cm_buf_res_msg();          
    cm_buf_res_count();          
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put("%s %c %c %s %s %s %s %s %s %c %c %s %s %s %s %s %s %s %l %l %l %s %s %l %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %c %c %s %s %s %c %l %l %s %s %s %s %s %s %s %c %s %s %s %s %s %s %l %l %l ",
        iabnormal, fpass[0], iabn_type[0], ilast_ply, ilast_card, 
        iins_card, icomp_card, ixxcard, iassured,
        fassured[0], fcut[0], nassured, nuser, ibenef, nbenef, 
        aassured, apayment, itel, iCa_log_RBA, Xprovision, qperiod,
        s_dbegin, s_dend, qcomp_period, s_dcomp_begin, s_dcomp_end,
        dissue, ipro_year, ibrand,
        nbrand_abbr, icar_type1,icar_type2, ncode1,ncode2, sTmpcylinder,
        iengine, ibody, 
        itag, isequence, ilicense, dbirth,
        fsex[0], fmarriage[0], s_plia_acc1,s_plia_acc2,s_pdmg_acc, flimit[0],
        pdmg_align, plia_align,
        ibroker1,ibroker2,iofficer1, iofficer2, icashier,
        iexaminer, ientry, itreaty[0], iresource,
        ibig_branch, ibig_office, ibig_sales, s_mcar_price,
        nequipment, mdali_prem, mcomp_prem, mdali_prem+mcomp_prem);

 $DECLARE q_cur CURSOR FOR
    SELECT iins_type,minjured_cover,mdeath_cover,mdamage_cover,mins_premium,qserial,mdeduct
    INTO $iins_type,$minjured_cover,$mdeath_cover,$mdamage_cover,$mins_premium, $qserial,$mdeduct
    FROM abn_ply_ins_type
    WHERE iabnormal=$iabnormal
    ORDER BY qserial; 

 $OPEN q_cur;
 count=0;
 
for(;;)
  {
    $FETCH q_cur;
    if (SQLCODE != 0) break;
    count++;
    cm_buf_put("%s %l %l %l %l %l",iins_type,minjured_cover,mdeath_cover,
               mdamage_cover,mdeduct, mins_premium);
  } /* for loop */
 $CLOSE q_cur;
 $FREE q_cur;
/********
 if (count==0)
  {
   if(exitsub(reply,M_CM_NOT_FOUND) == True) 
    return M_CM_NOT_FOUND;
   else  
    return apiRC;
  }
********/
  repbuf_len=cm_buf_len(ReplyBuf);
  cm_buf_put_count(count);
  if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
     return apiRC;
  return api_OKComplete;

 errexit:
  printf("soldata: %s\n",sqlca.sqlerrm);
  if(exitsub(reply,SQLCODE) == True) 
   return SQLCODE;
  else  
   return apiRC;
}


/*****************************************************************************/
long car304_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 $char DBName[DBNAME];

 $char iabnormal[CA_ESTIMATE_NUM], fpass_res[2], ipass[EMPLOYEE_ID], npass[101];
 $long dpass;
 char  taipei_db[40];
 int   rc;

 char option;
 int  tmp_len;
 long MsgCode;

 cm_buf_init(command);
 cm_buf_get("%c %s",&option,DBName);
 cm_buf_get("%s %s %s %s",iabnormal,fpass_res,ipass,npass);
 printf("iabnormal=%s fpass_res=%s ipass=%s\n", iabnormal, fpass_res, ipass);

 $WHENEVER SQLERROR GOTO errexit;

 rc = getHeadBranch(taipei_db);
 if (rc < 0) {
     printf("read Config file error!!\n");
     return M_CM_READ_CONFIG_ERR;
 }

 if (db_select(taipei_db) == False) 
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

 $BEGIN WORK;                
 $WHENEVER SQLERROR GOTO errexit;
 if (option == 'P')
  {
   dpass=cm_today();
   $UPDATE abnormal_ply SET (fpass,ipass,dpass,dverify,npass)
                  = ($fpass_res,$ipass,$dpass,current year to fraction(3),$npass) 
   WHERE iabnormal = $iabnormal;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }  

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else
  {
   if(exitsub(reply,M_CM_WRONG_OPTION) == True) 
    return M_CM_WRONG_OPTION;
   else  
    return apiRC;
  } 

 errexit:
  $WHENEVER SQLERROR CONTINUE;
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  printf("soldata: %s\n",sqlca.sqlerrm);
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True) 
   return MsgCode;
  else  
   return apiRC;
}

