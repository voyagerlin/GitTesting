/**********************************************************************/
/*   program id   : ca740p02s.ec                                      */
/*   program name : ���M�������(�߮�)                                */
/*   date written : 2018/10/18 by sylvia                              */
/*   files        :                                                   */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <decimal.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "globdata.h"
#include "safeclib.h"

char  outputf[21];
char dbgn[11],dend[11], opt[2];
$char userid[11], sdate1[11], sdate2[11], sYYMM[7];
$char DBName[05];
$char msgbuf[128], msg1[200], msg2[500], sbroker_top[6];
char   sApHome[50];

int rc;
    
main(argc, argv)
int argc;
char **argv;
{
    
	batchinit();
	strcpy(DBName,         isNULLstr(argv[1]));
	strcpy(userid,         isNULLstr(argv[2]));
	strcpy(opt,            isNULLstr(argv[3])); /* 1:��O 2:�z�� */
	strcpy(dbgn,           isNULLstr(argv[4]));
	strcpy(dend,           isNULLstr(argv[5]));
	strcpy(outputf,        isNULLstr(argv[6]));
	
	strcpy(sdate1,cm_to_infdate(dbgn));
	strcpy(sdate2,cm_to_infdate(dend));
	msg1[0]='\0';
	msg2[0]='\0';
	
	rc=car740_get_db();
    if ( rc != M_CM_OK) return rc;

	
	$select to_char(date($sdate1),'%Y%m') into $sYYMM 
	   from systables where tabid = 1;
	
    printf("sdate1=[%s]sdate2=[%s]sYYMM=[%s]\n",sdate1,sdate2,sYYMM);
    
	/* �w�� */
	$BEGIN WORK;
	rc = car740_claimB();
	if (rc != M_CM_OK)
		return rc;
    
	strcat(msg2, trim(msg1));
	
        /* ��� */
	rc = car740_claimA();
	if (rc != M_CM_OK)
		return rc;
		
    strcat(msg2, trim(msg1));
    
		
	$INSERT INTO sysdb:ca_rioho_log
	 (fsend_type,iyyyymm,dcreate) values ('2',$sYYMM,current);

    
    $COMMIT WORK;
    printf("---------msg2=[%s]\n  ",msg2);
    EWRITE(userid,M_CM_OK,msg2);
}


/*--------------------------------------------------------------------*/
long car740_get_db() 
{
    int rc;
    $whenever sqlerror goto errexit;

    if (db_select(DBName) == FALSE)
    {
        EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
        return M_CM_DB_NOTOPEN;
    }

    rc = getApHome(sApHome);
    if (rc < 0)
    {
        EWRITE(userid, M_CM_READ_CONFIG_ERR, "read Config file error!!");
        return FAIL;
    }

    return M_CM_OK;
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;  
}

/* -------------------------------------------------------------------------- */
long car740_claimB()
{
	
	$int  iqty, isql2;
	
	$WHENEVER SQLERROR GOTO errexit;

	/* ���R���w������� */
	$delete from sysdb:ca_rioho_lossMaster where iyyyymm = $sYYMM and ikindno = 'B';
	$delete from sysdb:ca_rioho_lossdetail where iyyyymm = $sYYMM and ikindno = 'B';
    
	
	/*  ��X���O�O�N���g���N��(�I����H) */
	strcpy(sbroker_top,"A0009");
	$select ibroker from broker_agent where ibroker_top = $sbroker_top into temp tp_broker with no log;


    /* �w��_�D�� */
    printf("insert into ca_rioho_lossmaster (B)......... \n");
    $insert into sysdb:ca_rioho_lossmaster
     select to_char(date($sdate1),'%Y%m') as iyyyymm, 'B' as ikindno, 
            case when insure_level = 'C1' then b.itarget2 else ' ' end as iforceno,
            case when insure_level = 'C2' then b.itarget2 else ' ' end as irandno,
            nvl(c.ibus_location[1,3],' ') as ivendno, 
            rtrim(replace(b.nassured, substr(b.nassured,3,2),'*')) as ninsuname,
            b.naddress[1,18]||'*****' as naddress, 
            rtrim(replace(b.itarget1, substr(b.itarget1,3,3),'***')) as ilicenseno,
            a.iclaim1 as ilossno, to_char(daccident,'%Y%m%d') as dlossdate,
            (select count(*) from claim_app_main 
              where ipolicy1=a.ipolicy1 and ipolicy2 = a.ipolicy2 ) as ilossqty,
            b.ntel1 as itelno, (a.mclaim_app-a.mfee_app) as mplanamt,
            (select sum(mclaim_app - mfee_app) from claim_app_main 
              where ipolicy1=a.ipolicy1 and ipolicy2 = a.ipolicy2) as mtotalplanamt,
            0 as mreadyamt, 0 as mtotalreadyamt,current
       from claim_app_main a, policy_new b, officer c, tp_broker d
      where a.isys_source = b.isys_source
        and a.ipolicy1 = b.ipolicy1
        and a.ipolicy2 = b.ipolicy2
        and b.iofficer = c.iofficer
        and a.iagent = d.ibroker
        and a.isys_source = 'CAR'
        and a.daccident between $sdate1 and $sdate2
        and b.insure_level = 'C2';
        
    
    iqty = 0;
    $select count(*) into $iqty
       from sysdb:ca_rioho_lossMaster
      where iyyyymm = $sYYMM
        and ikindno = 'B';

    /* �w��_������ */
    if (iqty > 0)
    {
        printf("insert into ca_rioho_lossdetail (B)......... \n");
        $insert into sysdb:ca_rioho_lossdetail
         select a.iyyyymm, a.ikindno, a.ilossno, ' ' as dlossdates, 
                (select iins_ply from insurance_type where iins_type = b.insure_instype) as iinsukind, 
                sum(b.mclaim_app-b.mfee_app) as mplanamts, 0 as mreadyamts, ' ' as npaynames
           from sysdb:ca_rioho_lossmaster a, claim_app_dtl b
          where a.ilossno = b.iclaim1
            and b.iclaim2  = ' '
            and a.iyyyymm = $sYYMM
            and a.ikindno = 'B'
            and b.isys_source = 'CAR'
          group by 1,2,3,4,5,7,8;
    }
	
    sprintf_s(msg1,200,"��Ʀ~��[ %s ] �w���߮צ@�� [%d] �� \n",sYYMM,iqty);
    
    printf("\n�w��: %s \n",msg1);
    
	return M_CM_OK;
	
errexit:
	sqlfatal();
	isql2 = SQLCODE;
	$ROLLBACK WORK;
	EWRITE(userid,isql2,sqlca.sqlerrm);
	return isql2;
}

/*--------------------------------------------------------------------*/

long car740_claimA()
{
	
	$int  iqty,isql2;
	
	
	$WHENEVER SQLERROR GOTO errexit;

	/* ���R���w������� */
	$delete from sysdb:ca_rioho_lossMaster where iyyyymm = $sYYMM and ikindno = 'A';
	$delete from sysdb:ca_rioho_lossdetail where iyyyymm = $sYYMM and ikindno = 'A';
    
	
	/*  ��X���e�����M�O�N���w���߮� */
	$select unique ilossno 
	   from sysdb:ca_rioho_lossMaster 
	  where ikindno = 'B'
	   into temp tp_iclaim with no log;


    /* ���_������ */
    printf("insert into ca_rioho_lossdetail (A)......... \n");
    $select to_char(date($sdate1),'%Y%m') as iyyyymm, 'A' as ikindno,  a.ilossno, 
            to_char(b.dgroup,'%Y%m%d') as dlossdates,
            (select iins_ply from insurance_type where iins_type = b.insure_instype) as iinsukind,
            0 as mplanamts, sum(b.msettle - b.mfee) as mreadyamts, 
            (select replace(replace(replace(replace(replace( multiset
                    (select unique trim(replace(nstl_obj,substr(trim(nstl_obj),3,2),'*')) 
                       from ao_stl_obj_close where iclose = b.iclaim1 
                         and iclose_type = b.iclose_type and fstl = b.fstl )::lvarchar, 
                     'MULTISET{',''), 'ROW(''',''),''')',''),'}',''),',','|') 
               from tp_iclaim where ilossno = a.ilossno) as npaynames
       from tp_iclaim a, claim_stl_dtl b
      where a.ilossno = b.iclaim1
        and b.iclaim2 = ' '
        and b.fstl = '1'
        and b.isys_source = 'CAR'
        and b.dgroup between $sdate1 and $sdate2
      group by 1,2,3,4,5,6,8
      into temp tp_lossdetail with no log;
      
    $insert into sysdb:ca_rioho_lossdetail
     select * from tp_lossdetail where 1=1;

    /*���_�D�� */
    $select ilossno, sum(mreadyamts) as mreadyamts
	   from tp_lossdetail 
	  where 1=1
	  group by 1
	   into temp tp_iclaim2 with no log;
	   
	
	/* ���_���Y */
    iqty = 0;
    $select count(*) into $iqty from tp_iclaim2;   
	
	if (iqty > 0)   
	{
        printf("insert into ca_rioho_lossMaster (A)......... \n");
        $insert into sysdb:ca_rioho_lossMaster
         select to_char(date($sdate1),'%Y%m') as iyyyymm, 'A' as ikindno, 
                case when insure_level = 'C1' then b.itarget2 else ' ' end as iforceno,
                case when insure_level = 'C2' then b.itarget2 else ' ' end as irandno,
                nvl(c.ibus_location[1,3],' ') as ivendno, 
                rtrim(replace(b.nassured, substr(b.nassured,3,2),'*')) as ninsuname,
                b.naddress[1,18]||'*****' as naddress, 
                rtrim(replace(b.itarget1, substr(b.itarget1,3,3),'***')) as ilicenseno,
                a.iclaim1 as ilossno, to_char(daccident,'%Y%m%d') as dlossdate,
                (select count(*) from claim_app_main 
                  where ipolicy1=a.ipolicy1 and ipolicy2 = a.ipolicy2 ) as ilossqty,
                b.ntel1 as itelno, 0 as mplanamt, 0 as mtotalplanamt, d.mreadyamts,
                (select sum(msettle - mfee) from claim_stl_dtl
                  where isys_source = 'CAR' and iclaim1 = a.iclaim1 and iclaim2 = a.iclaim2
                    and fstl = '1' and dgroup <= $sdate2) as mtotalreadyamt, current
           from claim_app_main a, policy_new b, officer c, tp_iclaim2 d
          where a.isys_source = b.isys_source
            and a.ipolicy1 = b.ipolicy1
            and a.ipolicy2 = b.ipolicy2
            and b.iofficer = c.iofficer
            and a.iclaim1 = d.ilossno 
            and a.iclaim2 = ' '
            and a.isys_source = 'CAR'
            and b.insure_level = 'C2';
	}
            
    sprintf_s(msg1,200,"��Ʀ~��[ %s ] ��߽߮צ� [%d] �� \n",sYYMM,iqty);
    
    printf("���: %s \n",msg1);
        
	return M_CM_OK;
	
	
errexit:
	sqlfatal();
	isql2 = SQLCODE;
	$ROLLBACK WORK;
	
	EWRITE(userid,isql2,sqlca.sqlerrm);
    return isql2;
}

/* -------------------------------------------------------------------------- */


