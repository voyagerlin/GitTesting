/**********************************************************/
/*   PROGRAM : ca121m01s.ec by Ealex                      */
/*   DATE    : 2000/12/20                                 */
/*             ������~��/�~�N��ƺ��@                    */
/*   MODIFY  : �s�Wireg_no(�n���Ҹ�) by sylvia 103.09.11  */
/**********************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;
#include <decimal.h>
#include "safeclib.h"

long car121(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	long rtncode;
	long car121_insert(),car121_single_query(),car121_multiple_query();
	long car121_update_exec();
	
	char option;
	
	cm_buf_init(command);
	cm_buf_get("%c",&option);
	switch(option)
	{
		case 'A': rtncode=car121_insert(reply);
	              break;
		case 'Q': rtncode=car121_single_query(reply);
		          break;
		case 'M': rtncode=car121_multiple_query(reply);
		          break;
		case 'D':
		case 'U': rtncode=car121_update_exec(reply,command,com_len);
		          break;
		default : 
		          return exitsub(reply,M_CM_WRONG_OPTION)?M_CM_WRONG_OPTION:apiRC;
	}
	return(rtncode);
}

/*-----------------------------------------------------------------*/
long car121_insert(reply)
serverReply reply;
{
	$char DBName[5],userid[11];
	$char Fclass[2],Ibigcomp[11],Ibigbranch[21],Ibigoffice[15],Nname[41],Itel[15];
	$char email[41],ireg_no[11],felder[2],ffair[2];
	$char dresign_c[12],dresign[12];
	int tmp_len;
	long MsgCode;
	
	cm_buf_get("%s %s %s %s %s %s %s %s %s %s %s %s %s", 
	            DBName,Fclass,Ibigcomp,Ibigbranch,Ibigoffice,Nname,Itel,email,ireg_no,dresign_c,felder,ffair,userid);
	strcpy(dresign,cm_to_infdate(dresign_c));
	$WHENEVER SQLERROR GOTO errexit;
	
	if(db_select(DBName) == False) 
		return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
	
	$BEGIN WORK;
	
	$INSERT INTO ca_big_office
	        (fclass,ibig_comp,ibig_branch,ibig_office,nname,itel,email,ireg_no,dresign,felder,ffair,icreate,dcreate,iupdate,dupdate)
	 VALUES ($Fclass,$Ibigcomp,$Ibigbranch,$Ibigoffice,$Nname,$Itel,$email,$ireg_no,$dresign,$felder,$ffair,$userid,current,$userid,current);
	
	cm_buf_init(ReplyBuf);
	cm_buf_put("%l",M_CM_OK);
	tmp_len = cm_buf_len(ReplyBuf);
	
	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
	{
		$WHENEVER SQLERROR CONTINUE;
		$ROLLBACK WORK;
		return apiRC;
	}  
	
	$WHENEVER SQLERROR GOTO errexit;
	$COMMIT WORK;
	return api_OKComplete;

errexit:
    MsgCode = SQLCODE;
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if( SQLCODE != 0) MsgCode = SQLCODE;
    return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

/*-----------------------------------------------------------------*/
long car121_single_query(reply)
serverReply reply;
{
    $char DBName[5];
    $char Fclass[2],Ibigcomp[11],Ibigbranch[21],Ibigoffice[15],Nname[41],Itel[15];
    $char email[41],ireg_no[11],felder[2],ffair[2];
    $char icreate[11],dcreate[21],iupdate[11],dupdate[21];
    $char dresign_c[12],dresign[12];
    int tmp_len;

    cm_buf_get("%s",DBName);
    cm_buf_get("%s %s",Fclass,Ibigcomp);

    $WHENEVER SQLERROR GOTO errexit;

    if(db_select(DBName) == False) 
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    printf( "SELECT ca_big_office\n");
    $SELECT fclass,ibig_comp,ibig_branch,ibig_office,nname,itel,email,ireg_no,dresign,felder,ffair,icreate,dcreate,iupdate,dupdate
       INTO $Fclass,$Ibigcomp,$Ibigbranch,$Ibigoffice,$Nname,$Itel,$email,$ireg_no,$dresign,$felder,$ffair,$icreate,$dcreate,$iupdate,$dupdate
       FROM ca_big_office 
      WHERE fclass = $Fclass
        AND ibig_comp = $Ibigcomp;
    
    strcpy(dresign_c,cm_from_infdate_100(dresign));
        
    if(SQLCODE==SQLNOTFOUND) 
        return exitsub(reply,M_CA_NBIG_OFFICE) ? M_CA_NBIG_OFFICE : apiRC;

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s", 
                M_CM_OK,Fclass,Ibigcomp,Ibigbranch,Ibigoffice,Nname,Itel,email,ireg_no,dresign_c,felder,ffair,icreate,dcreate,iupdate,dupdate);

    tmp_len = cm_buf_len(ReplyBuf);
    if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
   return exitsub(reply, SQLCODE) ? SQLCODE : apiRC;
}

/*-----------------------------------------------------------------*/
long car121_multiple_query(reply)
serverReply reply;
{
	$char DBName[5];
	$char Fclass[2],Ibigcomp[11],Ibigbranch[21],Ibigoffice[15],Nname[41],Iregno[11],Itel[15] ;
	$char Fclass2[2],Ibig_comp[11],Ibig_branch[21],Ibig_office[15],Nname2[41],Ireg_no[11],Felder[2],Ffair[2];
	$char Dresign_c[12],Dresign[12];
	$char stmt[512];
	char tmpbuf[4000];
	char stmp1[128];
	int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
	int i,total_count=0;
	
	cm_buf_get("%s",DBName);
	cm_buf_get("%s %s %s %s %s %s %s %s %s",Fclass,Ibigcomp,Ibigbranch,Ibigoffice,Nname,Iregno,Dresign_c,Felder,Ffair);
	strcpy(Dresign,cm_to_infdate(Dresign_c));
	
	if(Dresign_c[0]=='*')
	{
	    sprintf_s(stmp1,sizeof stmp1,"");
	}
	else
	{
	    sprintf_s(stmp1,sizeof stmp1,
	    "AND dresign = '%s' ",Dresign);
	}
	
    $WHENEVER SQLERROR GOTO errexit;
    if(db_select(DBName) == False) 
		return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
    
    printf("Declare q_cur FOR ca_big_office \n");
    sprintf_s(stmt,sizeof stmt,
    "SELECT fclass, ibig_comp, ibig_branch, ibig_office, nname, ireg_no, dresign, felder, ffair "
    "FROM ca_big_office "
    "WHERE fclass matches '%s' "
    "  AND ibig_comp matches '%s' "
    "  AND ibig_branch matches '%s' "
    "  AND ibig_office matches '%s' "
    "  AND nname matches '%s' "
    "  AND ireg_no matches '%s' "
    "  %s "
    "  AND felder matches '%s' "
    "  AND ffair matches '%s' "
    "ORDER BY ibig_comp ",
    Fclass,Ibigcomp,Ibigbranch,Ibigoffice,Nname,Iregno,stmp1,Felder,Ffair);
    printf("stmt = [%s]\n",stmt);
    $PREPARE q1 FROM $stmt;
    $DECLARE q_cur CURSOR for q1;
    $OPEN q_cur;

	for(;;)
	{
		$FETCH q_cur
		 INTO $Fclass2, $Ibig_comp, $Ibig_branch, $Ibig_office, $Nname2, $Ireg_no, $Dresign, $Felder, $Ffair;
		if(SQLCODE != 0) break;
		
		cm_buf_init(tmpbuf);
		if( count == 0 )
		{
		     cm_buf_res_msg();    /* reserve for MsgCode and count */
		     cm_buf_res_count();
		}
		strcpy(Dresign_c,cm_from_infdate_100(Dresign));
		cm_buf_put("%s %s %s %s %s %s %s %s %s",Fclass2, Ibig_comp, Ibig_branch, Ibig_office, Nname2, Ireg_no, Dresign_c, Felder, Ffair);
		tmp_len = cm_buf_len(tmpbuf);
		
		if( tmp_len + repbuf_len < 3000 )
		{    /* buffer size less than 4K */
		    memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
		    repbuf_len += tmp_len;
		    count++;
		}
		else
		{    /* more than 4K, send to client side */
		    cm_buf_init(ReplyBuf);
		    cm_buf_put_msg(M_CM_OK);
		    cm_buf_put_count(count);
		
		    if(SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
		    {
		        $CLOSE q_cur;
		        return apiRC;
		    }
		    else
		    {   /* clear ReplyBuf and count to start all over again */
		        replycnt++;
		
		        if(replycnt == 8)
		        {    /* more than 30K, client cannot display,error */
		            cm_buf_init(ReplyBuf);
		            cm_buf_put("%l",M_CM_OUT_SPACE);
		            tmp_len = cm_buf_len(ReplyBuf);
		            if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
		                return apiRC;
		            return M_CM_OUT_SPACE;
		        }
		
		        ReplyBuf[0] = '\0';
		        count = 0;
		        cm_buf_init(ReplyBuf);
		        cm_buf_res_msg();    /* reserve for MsgCode and count */
		        cm_buf_res_count();
		        
		        cm_buf_put("%s %s %s %s %s %s %s %s %s",Fclass2, Ibig_comp, Ibig_branch, Ibig_office, Nname2, Ireg_no, Dresign_c, Felder, Ffair);
		        repbuf_len = cm_buf_len(ReplyBuf);
		        count++;
		    }
		}
	} /* for loop */

    $CLOSE q_cur;
    $FREE q_cur;
	if(count > 0)
	{    /* break out, at least one record is selected */
		cm_buf_init(ReplyBuf);
		cm_buf_put_msg(M_CM_OK);
		cm_buf_put_count(count);
		if(SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
		    return apiRC;
		 return api_OKComplete;
	}
	else    /* break out, not any row is found */
	{
		return exitsub(reply,M_CA_NBIG_OFFICE) ? M_CA_NBIG_OFFICE : apiRC;
	}

errexit:
    return exitsub(reply, SQLCODE) ? SQLCODE : apiRC;
}

/*-----------------------------------------------------------------*/
long car121_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
    $char Fclass[2],Ibigcomp[11],Ibigbranch[21],Ibigoffice[15],Nname[41],Itel[15];
    $char email[41],ireg_no[11],felder[2],ffair[2];
    $char icreate[11],dcreate[21],iupdate[11],dupdate[21];
    $char cur_Fclass[2],cur_Ibigcomp[11],cur_Ibigbranch[21],cur_Ibigoffice[15],cur_Nname[41],cur_Itel[15];
    $char cur_email[41],cur_felder[2],cur_ffair[2],userid[11];
    $char dresign_c[12],dresign[12];
    char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
    int tmp_len,raw_len;
    long dummy;
    long MsgCode;

    $char DBName[5];

    comm = (char *) command;
    cm_buf_init(command);
    cm_buf_get("%c %s",&option,DBName);

    $WHENEVER SQLERROR GOTO errexit;

    if(db_select(DBName) == False) 
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    memcpy(&raw_len,&comm[com_len],sizeof(int));
    pos = &comm[com_len+sizeof(int)];
    raw_ptr = malloc(raw_len);
    if(raw_ptr != (char*)0)
        memcpy(raw_ptr,pos,raw_len);
    else
    {
        if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */
            return M_CM_NOT_MALLOC;
        else
            return apiRC;
    }

    cm_buf_init(raw_ptr);    /* get index key from old record */
    cm_buf_get("%l %s %s ",&dummy,cur_Fclass,cur_Ibigcomp);

    $BEGIN WORK;

    printf( "[UPDATE]:SELECT ca_big_office \n");
    $SELECT fclass,ibig_comp,ibig_branch,ibig_office,nname,itel,email,ireg_no,dresign,felder,ffair,icreate,dcreate,iupdate,dupdate
       INTO $Fclass,$Ibigcomp,$Ibigbranch,$Ibigoffice,$Nname,$Itel,$email,$ireg_no,$dresign,$felder,$ffair,$icreate,$dcreate,$iupdate,$dupdate
       FROM ca_big_office
      WHERE fclass = $cur_Fclass
        AND ibig_comp = $cur_Ibigcomp;

    if(SQLCODE == SQLNOTFOUND)
    {
        MsgCode = M_CM_NOT_FOUND;
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        if( SQLCODE != 0) MsgCode = SQLCODE;
        return exitsub(reply,MsgCode) ? MsgCode : apiRC;
    }

    cm_buf_init(cur_buf);
    strcpy(dresign_c,cm_from_infdate_100(dresign));
    cm_buf_put("%l %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s ",dummy,Fclass,Ibigcomp,Ibigbranch,Ibigoffice,Nname,Itel,email,ireg_no,dresign_c,felder,ffair,icreate,dcreate,iupdate,dupdate);

    if(memcmp(cur_buf,raw_ptr,raw_len) != 0)
    {    /* compare 2 records, not equal */
        MsgCode = M_CM_NOT_EQUAL;
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        if( SQLCODE != 0) MsgCode = SQLCODE;
        return exitsub(reply,MsgCode) ? MsgCode : apiRC;
    }
	
	free(raw_ptr);

    /* equal, then exec DB operation */

    if( option == 'D' )
    {
        $DELETE FROM ca_big_office
          WHERE fclass = $cur_Fclass
            AND ibig_comp = $cur_Ibigcomp; 
        cm_buf_init(ReplyBuf);
        cm_buf_put("%l",M_CM_OK);
        tmp_len = cm_buf_len(ReplyBuf);
        if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
        {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            return apiRC;
        }

        $WHENEVER SQLERROR GOTO errexit;
        $COMMIT WORK;
        return api_OKComplete;
    }
    else if(option == 'U')
    {
        cm_buf_init(command);
        
        cm_buf_get("%c %s %s %s %s %s %s %s %s %s %s %s %s %s",
	            &option,DBName,Fclass,Ibigcomp,Ibigbranch,Ibigoffice,Nname,Itel,email,ireg_no,dresign_c,felder,ffair,userid);
	strcpy(dresign,cm_to_infdate(dresign_c));
	
        $UPDATE ca_big_office
            SET (fclass,ibig_comp,ibig_branch,ibig_office,nname,itel,email,ireg_no,dresign,felder,ffair,iupdate,dupdate)
              = ($Fclass,$Ibigcomp,$Ibigbranch,$Ibigoffice,$Nname,$Itel,$email,$ireg_no,$dresign,$felder,$ffair,$userid,current)
          WHERE fclass = $cur_Fclass
            AND ibig_comp = $cur_Ibigcomp;
 
        if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
        {
            $INSERT INTO ca_big_office
                    (fclass,ibig_comp,ibig_branch,ibig_office,nname,itel,email,ireg_no,dresign,felder,ffair,icreate,dcreate,iupdate,dupdate)
             VALUES ($Fclass,$Ibigcomp,$Ibigbranch,$Ibigoffice,$Nname,$Itel,$email,$ireg_no,$dresign,$felder,$ffair,$userid,current,$userid,current);
        }

        cm_buf_init(ReplyBuf);
        cm_buf_put("%l",M_CM_OK);
        tmp_len = cm_buf_len(ReplyBuf);
        
        if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
        {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            return apiRC;
        }

        $WHENEVER SQLERROR GOTO errexit;
        $COMMIT WORK;
        return api_OKComplete;
    }
    else
    {
        return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
    }

errexit:
    MsgCode = SQLCODE;
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if( SQLCODE != 0) MsgCode = SQLCODE;
    return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
/*-----------------------------------------------------------------*/
