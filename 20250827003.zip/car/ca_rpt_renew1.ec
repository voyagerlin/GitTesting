/*-------------------------------------------------------------------
 * Program: ca_rpt_renew1.ec
 * Date   : 03/20/1997
 *-------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "is_def.h"
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
$include "ca3xxlib.h";
$include "car_common.h";
$include sqlca;
$include sqltypes;
void Put_Other_Ins_Cost();    /* �I�ة��Ӹ�� in ca3xxlib.ec */
void Put_Ins_Cost();          /* in ca3xxlib.ec */
void Put_Ins_Cost_1();        /* in ca3xxlib.ec */
void Put_Other_Ins_Cost_1();  /* in ca3xxlib.ec */

/*****************************************************************/
$char stm3[25] ,nname[41],nchi_full[41],iply_area[3],ibranch[3],scar_price[11];
$char last_policy[21], nproject[21], nchi_full_tmp[31];
$char aassured_zip[6],irel_card[18],note1[18],splia_acc[6],spdmg_acc[5];
$long LHdMdeduct, LHdMprem;
$char stmt[2048];
char LHsMprem[11], LHsdamage_cover[11],LHsMdeduct[11];
$char ch_deduct[13];
$char LHsNname[11];
$char tmp_ply[20];
char  remark[12],dmg_flag,lia_flag,frelative_comp;
char  dmg_flag_p,lia_flag_p;
$long bef_premium1,bef_premium2,bef_premium3;
$long deduct_t3,prem_t3;
$long deduct;
$char remark1[401], remark4[242], remark_comp[242], remark5_12[3];
$char remark1_ori[101], remark2[101], remark6[101], remark7[101];
$char sNequipment[31];   /* �Τ@�F�ʥ�~�� �~�ȥN�X , 990728=>�אּ nequipment	���O(�t�P�t��)	char(30)*/
$char ibig_sales[11],nbig_sales[16];
$char localdb1[30];
$char sdbname[3];
$int  iMdiscount,iTot_mpay;
$char icorps[11],ncorps[31];
$int  rela_cnt;
$char sFassured[2];
$char s_ilicense[13];
char  new_rate;
$double  pdiscount_d;
$char pdiscount_s[20];
$char ibig_comp_s[2];
$char lia_class[2];
$int  dmg_acc_1st,dmg_acc_2nd,dmg_acc_3rd;
$int  bqdmg[3];
$char last_ply_tmp[21];
$int  itp;
$char cdmg[5][3];
$int  iyymm;
$char syymm[6];
$char   tphone_con[21],imovephone[21],iemail[51], icar_type_comp[3];
$long qday_01,qday_11;
$long qday;

int   max_count=0,ben_len=0;
$int   rec_count_1;
$double plia_acc_1,plia_acc_2,pdmg_acc_2;
char *get_car_full_db();
char *split_yymm();
$char  ilicense_v[13];
int   fchg_id;
$char s_dbirth[11],s_dissue[11];  /* 980815, �]���s�Wdbirth ,dissue*/
$char tmp_yyyy[5],tmp_mm[3],tmp_dd[3];
$char slia_class_renew[3];
$char slia_ac_cnt3[3];
$char sAdds_new1[121];
$char tmp_napplicant[131];

/*****************************************************************/
int ca_rpt_renew1(db,fbigcomp,ply,fmulti,prt,rec_cnt)
$char *db, *fbigcomp, *ply, *fmulti, *prt;
$int  *rec_cnt;
{
    $char  stmt_buf[2000];
    $short fprem,fprem2,id,id2;
    $char  tmp_irelative[13],last_ply[18],inext_ply[20];
    char   ply1_date[11], ply2_date[11];
    char   ply1_yr[5], ply2_yr[5];
    char   ply1_mth[3], ply2_mth[3];
    $char  dply_begin_c[11];
    $char  xiofficer[11];

    $WHENEVER SQLERROR GOTO ca_rpt_renew_err;

    strcpy(sdbname,get_car_full_db(ply));
    strcpy(localdb1,get_full_dbname(sdbname));

    strcpy(last_policy, trim(ply));

    printf("----into ca_rpt_renew1() fbigcomp[%s] fmulti[%s]\n",fbigcomp,fmulti);
    printf("----into ca_rpt_renew1() db[%s] prt[%s]\n",db,prt);
    rec_count_1=*rec_cnt;

    printf("1.### *rec_cnt[%d]\n",*rec_cnt);

    Icurr=Ifirst=Ilast=Ifirst1=NULL;    /* set INS_TYPE pointer to NULL */

    printf("ply[%s]\n",ply);

    strncpy(tmp_ply,ply,CAR_POLICY_LEN);
    tmp_ply[CAR_POLICY_LEN]='\0';

    printf("-------into ca_rpt_renew1() tmp_ply[%s]\n",tmp_ply);
    
    $CREATE TEMP TABLE NO_NASS
    (
       iofficer  char(10)
    )
    WITH NO LOG;
    
    printf("-------CREATE NO_NASS\n");
   
    $INSERT INTO NO_NASS VALUES ("Y61024YS1");
    $INSERT INTO NO_NASS VALUES ("Y61024YS2");
    $INSERT INTO NO_NASS VALUES ("Y61024YS3");
    $INSERT INTO NO_NASS VALUES ("Y61024YS4");
    $INSERT INTO NO_NASS VALUES ("Y61024YS6");
    $INSERT INTO NO_NASS VALUES ("Y61024YC");
    $INSERT INTO NO_NASS VALUES ("Y61024YC2");
    $INSERT INTO NO_NASS VALUES ("711762Q3");
    $INSERT INTO NO_NASS VALUES ("Z61021");
    $INSERT INTO NO_NASS VALUES ("Z6102101");
    $INSERT INTO NO_NASS VALUES ("Z6102102");
    $INSERT INTO NO_NASS VALUES ("Z6102103");
    $INSERT INTO NO_NASS VALUES ("Z6102104");
    $INSERT INTO NO_NASS VALUES ("Z6102105");
    $INSERT INTO NO_NASS VALUES ("Z61021BC");
   
    printf("-------CREATE NO_NASS\n");
   
    $DECLARE xx110 CURSOR FOR
      SELECT iofficer
        INTO $xiofficer
        FROM NO_NASS;
    $OPEN xx110;

    while(1)
    {
        $FETCH xx110;
        if(SQLCODE == SQLNOTFOUND) break;
        printf("xiofficer = [%s] \n", xiofficer );
    }
    $CLOSE xx110;
     

    sprintf(stmt,"SELECT iofficer FROM NO_NASS where iofficer = ?");
    $PREPARE get_no_nass FROM $stmt;

    /*---�C�L��O��---*/
    /*******�N�q�H�Y�ƲM��*******/
    /**frelative_comp �ΨӧP�_�O�_�O���N�ɤS�O�j��***/
    plia_acc_1 = plia_acc_2 = pdmg_acc_2 = 0,frelative_comp='N';
    sprintf(stmt_buf,"SELECT %s %s %s %s %s %s %s %s %s %s %s %s %s FROM %s %s",
            "ipolicy,icard,fcard_class,irelative_ply,qply_period,dply_begin,dply_end,",
            "nassured,ilicense,fsex,fmarriage,nuser,nbenef,aassured,itel,",
            "ipro_year,ibrand,nbrand_abbr,icar_type,ncar_type,qcylinder,iengine,",
            "ibody,itag,mcar_price,pdmg_align,pbrg_align,plia_align,qpt,fpt,",
            "idmg_rate,ibrg_rate,psex_age,psex_age_damage,nvl(plia_acc,'0'),nvl(pdmg_acc,'0'),",
            "fcar_class,dedr_begin,iofficer,ileader,ibig_office,ibig_sales,iply_area,",
            "aassured_zip, irel_card,nchi_full,trim(remark1)||nvl(remark2,''),ibig_nname,nname,",
            "mdiscount,tot_mpay,icorps,ncorps,ibig_comp,pdiscount,fcomp_24,dmg_ac_cnt1,",
            "dmg_ac_cnt2,dmg_ac_cnt3,dply_begin,tphone_con,imovephone, ",
            "dmg_factor,brg_factor,nproject,trim(remark4)||nvl(remark5,''),remark5[1,2], nequipment, ichange_note,",
            "remark1, remark2, remark6, remark7,nvl(dbirth,' '),nvl(dissue,' '),",
            "iquery_num,iquery_num_damage,lia_class,lia_ac_cnt3,napplicant,ndeputy_assured,",
            "ndeputy_appl,apayment_zip,apayment,iapplicant,fsex_appl,dbirth_appl,itel_appl,nrelation_appl",
            "policy_302 ",
            "WHERE ipolicy = ? ");
    $PREPARE CUR_ply_302_1 FROM $stmt_buf;
    $DECLARE CA302_ply_302_1 CURSOR FOR CUR_ply_302_1;
    printf("stmt_buf[%s]\n",stmt_buf);
    $OPEN CA302_ply_302_1 USING $ply;
    while (1)
    {
        InitData1();
        note1[0] = '\0';

        $FETCH CA302_ply_302_1
          INTO $last_ply,$last_card,$fcard_class,$irelative_ply,
               $qply_period,$dply_begin,$dply_end,$assuredn,$license,
               $sex,$marriage,$user,$benefn,$assureda,$tel,
               $pro_year,$brandi,$brandn,$car_typei,$car_typen,
               $cylinder,$engine,$body,$tagnum,$scar_price,
               $dmg_align,$brg_align,$lia_align,$qpt,$fpt,
               $idmg_rate,$ibrg_rate,$psex_age_1,$psex_age_damage,$splia_acc,$spdmg_acc,
               $fcar_class,$dedr_begin,$iofficer,$ileader,$big_office,$big_sales,
               $iply_area,$aassured_zip,$irel_card,$nchi_full,$remark1,
               $LHsNname,$nname,$iMdiscount,$iTot_mpay,$icorps,$ncorps,$ibig_comp_s,
               $pdiscount_d,$fcomp_24,$cdmg[0],$cdmg[1],$cdmg[2],$dply_begin_c,
               $tphone_con,$imovephone,$dmg_factor,$brg_factor,$nproject,$remark4,$remark5_12, $sNequipment, $ichange_note,
               $remark1_ori, $remark2, $remark6, $remark7,$s_dbirth,$s_dissue,
               $iquery_num_lia,$iquery_num_damage,$slia_class_renew,$slia_ac_cnt3,$napplicant,$ndeputy_assured,
               $ndeputy_appl,$apayment_zip,$apayment,$iapplicant,$fsex_appl,$dbirth_appl,$itel_appl,$nrelation_appl;
        if (SQLCODE != 0) break;

        strcpy(last_ply_tmp,last_ply);
/*        
        printf("dply_begin[%s]\n",dply_begin_c);
        strcpy(syymm,split_yymm(dply_begin_c));
        printf("syymm[%s]\n",syymm);
        iyymm = atoi(syymm);

        $SELECT icode
           INTO $frate
           FROM ca_rate_renew   ��O�O�v�N�� 
          WHERE iym_bgn <= $iyymm
            AND iym_end >= $iyymm
            AND fcard_class = $fcard_class;
*/

        /* ���ca_rate_renew �s�X��������*/
        $SELECT icode
           INTO $frate
           FROM ca_rate_renew
          WHERE deffect_bgn <= $dply_begin_c
            AND deffect_end >= $dply_begin_c
            AND fcard_class = $fcard_class;
        tagnum[8]='\0';
        tel[21]='\0';
        dmg_flag = 'N';
        dmg_flag_p = 'N';
        lia_flag = 'N';
        lia_flag_p = 'N';
        rstod(splia_acc,&plia_acc);
        rstod(spdmg_acc,&pdmg_acc);
        
        strcpy(iofficer, trim(iofficer));
        $EXECUTE get_no_nass USING $iofficer;
        printf("get-No-nass iofficer=[%s] SQLCODE =[%d]\n", iofficer, SQLCODE );
             
        if(SQLCODE == SQLNOTFOUND){ /** nothing happen**/    }
        else
        {
       	    strcpy( engine, "********************");
       	    strcpy( license,"**********");       	         	    
        }                
        /* 980220 */
        strcpy(big_sales , trim(big_sales));
        if (strlen(big_sales)>=10){
        	  if ((iofficer[0]!='A')&&(iofficer[0]!='B')&&(iofficer[0]!='L')&&(iofficer[0]!='N')){
                   strncpy(big_sales+(3),"****",4); 
           }
        }         
        printf("nproject[%s]\n", nproject );
 
        if(strlen(trim(nproject))>0)
        {
           printf("nchi_full[%s], project[%s]\n", nchi_full, nproject);

           sprintf(nchi_full_tmp,"%s%s%s","(",trim(nproject),")");
           printf("nchi_full_tmp[%s]\n", nchi_full_tmp);
          
           strcpy(nchi_full, trim(nchi_full)); 
           strcat(nchi_full, trim(nchi_full_tmp));
           
           printf("nchi_full[%s]\n", nchi_full );
        }
        
        printf("----  assuredn[%s],fcard_class[%s]\n",assuredn,fcard_class);
        printf(">>>>>last_ply[%s]\n",last_ply);

        sprintf(stmt, " SELECT fassured,lia_class,dmg_acc_1st,dmg_acc_2nd,dmg_acc_3rd    \
                          FROM %s:policy   \
                         WHERE ipolicy = '%s' ",localdb1,last_ply);
        $PREPARE xs_id FROM $stmt;
        $EXECUTE xs_id INTO $sFassured,$lia_class,$dmg_acc_1st,$dmg_acc_2nd,$dmg_acc_3rd;
        if (SQLCODE == SQLNOTFOUND) strcpy(sFassured," ");

        bqdmg[0] = dmg_acc_1st;
        bqdmg[1] = dmg_acc_2nd;
        bqdmg[2] = dmg_acc_3rd;

        if ((sFassured[0] == '1') ||
            (sFassured[0] == '3') ||
            (sFassured[0] == '5'))
             strcpy(s_ilicense,license);
        else
             strcpy(s_ilicense," ");

        /*---���p�O�檺�B�z---*/
        fprem=0;fprem2=0;id=0;id2=0;
        strcpy(remark," ");

        printf("---### before line 113 ###\n");
        if (fcard_class[0]=='2')       /*---���N--*/
        {
             ply2_begin=dply_begin;
             ply2_end=dply_end;
             pdmg_acc_2 = pdmg_acc;
             plia_acc_2 = plia_acc;
             psex_age_1 = psex_age_1;
             psex_age_2 = 0;

             if (fmulti[0]=='0') /* �@��� */
             {
                  printf("### in �@��� ####\n");
                  $SELECT --+INDEX (a pins32_idx_2)
                          SUM(mins_premium), SUM(ori_premium)
                     INTO $premium2:id, $premium3:id2
                     FROM ply_ins_type_302 a
                    WHERE ipolicy=$last_ply;
                  printf("#### id=[%d],premium2[%d] ####\n",id,premium2);
                  if (id==-1) premium2=0;
                  if (id2==-1) premium3=0;
                  printf("-----1 premium=[%d] \n",premium2);
                  if(fbigcomp[0]=='1')
                  {
                      $SELECT pre_dply2_bgn,pre_dply2_end
                         INTO $bef_ply2_begin,$bef_ply2_end
                         FROM policy_302
                        WHERE ipolicy = $last_ply;

                      $SELECT SUM(decode(pre_minsprem,-999,0,pre_minsprem)),
                              SUM(ori_premium)
                         INTO $bef_premium2:id, $bef_premium3:id2
                         FROM ply_ins_type_302
                        WHERE ipolicy = $last_ply;

                      printf("#### id=[%d] ####\n",id);
                      if (id==-1) bef_premium2=0;
                      if (id2==-1) bef_premium3=0;
                      printf("-----2 premium=[%d] \n",bef_premium2);
                  }
                  else
                  {
                      $SELECT pre_dply2_bgn,pre_dply2_end
                         INTO $bef_ply2_begin,$bef_ply2_end
                         FROM policy_302
                        WHERE ipolicy = $last_ply;

                      $SELECT SUM(decode(pre_minsprem,-999,0,pre_minsprem)), 
                              SUM(ori_premium)
                         INTO $bef_premium2:id, $bef_premium3:id2
                         FROM ply_ins_type_302
                        WHERE ipolicy = $last_ply;

                      printf("#### id=[%d] ####\n",id);
                      if (id==-1) bef_premium2=0;
                      if (id2==-1) bef_premium3=0;
                      printf("-----3 premium=[%d] \n",bef_premium2);
                  }
             }

             printf("1-->premium2[%ld]\n",premium2);

             if (irelative_ply[0]!=' ' && irelative_ply[0]!='\0')
             {                                  /*--���N�I���j�����p�O��*/
                  $SELECT  plia_acc_c, psex_age, trim(remark1)||nvl(remark2,''),iquery_num
                     INTO  $splia_acc, $psex_age_2, $remark_comp,$iquery_num
                     FROM  policy_302
                    WHERE  ipolicy = $irelative_ply;

                  rstod(splia_acc,&plia_acc_1);
                  printf("plia_acc_1[%f]\n",plia_acc_1);
                  frelative_comp = 'Y';

                  if( strlen(trim(remark1)) == 0 ){
                     strcpy( remark1, remark_comp);
                  }else if( strlen(trim(remark4)) == 0 ){
                     strcpy( remark4, remark_comp);                     
                  }   
                  
                  if (fmulti[0]=='0') /* �@��� */
                  {
                       $SELECT --+INDEX (a pins32_idx_2)
                               SUM(mins_premium) INTO $premium1:fprem
                          FROM ply_ins_type_302 a,policy_302 b
                         WHERE a.ipolicy=$irelative_ply
                           AND a.ipolicy=b.ipolicy
                           AND YEAR(b.dply_begin)=YEAR($ply2_begin)
                           AND MONTH(b.dply_begin)=MONTH($ply2_begin);
                       printf("#### fprem=[%d] ####\n",fprem);
                       if (fprem==-1) premium1=0;
                       printf("-----6 premium=[%d] \n",premium1);

                       if(fbigcomp[0]=='1')
                       {
                            $SELECT pre_dply1_bgn,pre_dply1_end
                               INTO $bef_ply1_begin,$bef_ply1_end
                               FROM policy_302
                              WHERE ipolicy=$irelative_ply;

                            $SELECT SUM(decode(pre_minsprem,-999,0,pre_minsprem)) 
                               INTO $bef_premium1:id
                               FROM ply_ins_type_302
                              WHERE ipolicy = $irelative_ply;

                            printf("#### id=[%d] ####\n",id);
                            if (id==-1) bef_premium1=0;
                            printf("-----7 premium=[%d] \n",bef_premium1);
                       }
                       else
                       {
                            $SELECT pre_dply1_bgn,pre_dply1_end
                               INTO $bef_ply1_begin,$bef_ply1_end
                               FROM policy_302
                              WHERE ipolicy=$irelative_ply;

                            $SELECT SUM(decode(pre_minsprem,-999,0,pre_minsprem)) 
                               INTO $bef_premium1:id
                               FROM ply_ins_type_302
                              WHERE ipolicy = $irelative_ply;

                            printf("#### id=[%d] ####\n",id);
                            if (id==-1) bef_premium1=0;
                            printf("-----8 premium=[%d] \n",bef_premium1);
                       }
                  }

                  printf("#### fprem=[%d] ####\n",fprem);
                  if (fmulti[0]=='0') /* �@��� */
                  {
                      if (bef_premium1 == 0)
                      {
                          strcpy(remark,"3");
                          remark[1]='\0';
                      }
                      else
                      {
                          if (fprem==-1)
                          { /* �j����  or �w�L��*/
                               sprintf(stmt, " SELECT dply_end \
                                                 FROM %s:ply_relation    \
                                                WHERE ipolicy = '%s' ",localdb1,irelative_ply);
                               $PREPARE next3 FROM $stmt;
                               $EXECUTE next3 INTO $ply1_end;

                               printf("-9-irelative[%s]\n",irelative_ply);
                               printf("-9-@@@ply1_end[%d],bef_ply1_end[%d],ply2_begin[%d]\n",ply1_end,bef_ply1_end,ply2_begin);
                               if(bef_ply1_end > ply2_begin)
                               {
                                    /**********�j����****************/
                                    $SELECT note1,pre_dply1_bgn,pre_dply1_end, icar_type, ichange_note
                                       INTO $note1,$ply1_begin,$ply1_end, $icar_type_comp, $ichange_note
                                       FROM policy_302
                                      WHERE ipolicy = $irelative_ply;
                                    premium1=0;
                                    strcpy(remark,"0"); remark[1]='\0';

                                printf("-10-note1[%s] ply1_begin[%d] ply1_end[%d]\n", note1, ply1_begin, ply1_end );

                               }
                               else
                               {
                                    /**********�j��w�L��,�L�X��O�Ҹ��ΫO��****************/
                                    sprintf(stmt, " SELECT inext_ply,dply_begin,dply_end \
                                                      FROM %s:ply_relation               \
                                                     WHERE ipolicy = '%s' ",localdb1,irelative_ply);
                                    $PREPARE next1 FROM $stmt;
                                    $EXECUTE next1 INTO $inext_ply,$ply1_begin,$ply1_end;

                                    if(strlen(trim(inext_ply)) == 0)
                                    {
                                        strcpy(remark,"2"); remark[1]='\0';
                                    }
                                    else
                                    {
                                        strcpy(remark,"1");
                                    }
                               }
                          }
                          else
                          {    /* �j���� */
                               $SELECT icard,qply_period,dply_begin,dply_end, icar_type, ichange_note
                                  INTO $icard_1, $ply1_period, $ply1_begin, $ply1_end, $icar_type_comp, $ichange_note
                                  FROM policy_302
                                 WHERE ipolicy=$irelative_ply;

                               $SELECT --+INDEX (a pins32_idx_2)
                                       mins_premium
                                  INTO $premium1:id
                                  FROM ply_ins_type_302 a
                                 WHERE ipolicy=$irelative_ply
                                   and iins_type = '21';
                               printf("-12-#### id=[%d] ####\n",id);
                               if (id==-1)
                                   premium1=0;
                               else
                                  frelative_comp = 'Y';
                          }
                      }
                  }
             }
        }
        else if (fcard_class[0]=='1')  /*-- �j�� --*/
        {
             $SELECT  plia_acc_c
                INTO  $splia_acc
                FROM  policy_302
               WHERE  ipolicy = $last_ply;
             rstod(splia_acc,&plia_acc_1);
             if (fmulti[0]=='1')        /* �j�O�� */
                 continue;

             ply1_period=qply_period;
             ply1_begin=dply_begin;
             ply1_end=dply_end;
             psex_age_2 = psex_age_1;
             psex_age_1 = 0;

             printf("-13.1- last_ply[%s]\n", last_ply);

             if (fmulti[0]=='0') /* �@��� */
             {

                  $SELECT --+INDEX (pins32_idx_2)
                          SUM(mins_premium) INTO $premium1:id
                     FROM ply_ins_type_302
                    WHERE ipolicy=$last_ply
                      AND iins_type = '21' ;
                  printf("-----premium1=[%d] \n",premium1);    
                  printf("-13- #### id=[%d] ####\n",id);
                  if (id==-1) premium1=0;
                  if(fbigcomp[0]=='1')
                  {
                       $SELECT pre_dply1_bgn,pre_dply1_end
                          INTO $bef_ply1_begin,$bef_ply1_end
                          FROM policy_302
                         WHERE ipolicy=$last_ply;

                       $SELECT SUM(decode(pre_minsprem,-999,0,pre_minsprem))
                          INTO $bef_premium1:id
                          FROM ply_ins_type_302
                         WHERE ipolicy = $last_ply;

                       printf("-14- #### id=[%d] ####\n",id);
                       if (id==-1) bef_premium1=0;
                       printf("-----14 bef_premium1=[%d] \n",bef_premium1);
                  }
                  else
                  {
                       $SELECT pre_dply1_bgn,pre_dply1_end
                          INTO $bef_ply1_begin,$bef_ply1_end
                          FROM policy_302
                         WHERE ipolicy=$last_ply;

                       $SELECT SUM(decode(pre_minsprem,-999,0,pre_minsprem))
                          INTO $bef_premium1:id
                          FROM ply_ins_type_302
                         WHERE ipolicy = $last_ply
                           AND iins_type = '21';
                       printf("-15-#### id=[%d] ####\n",id);
                       if (id==-1) bef_premium1=0;
                       printf("-----15 bef_premium1=[%d] \n",bef_premium1);
                  }
                  /*
                  if ((strncmp(car_typei,"01",2) == 0) ||
                      (strncmp(car_typei,"02",2) == 0) ||
                      (strncmp(car_typei,"32",2) == 0) ||
                      (strncmp(car_typei,"34",2) == 0))
                  {                  
                      $SELECT count(*)
                         INTO $rela_cnt
                         FROM policy_302
                        WHERE ipolicy = $irelative_ply
                          AND YEAR(dply_begin) = YEAR($ply1_begin)
                          AND MONTH(dply_begin) = MONTH($ply1_end);
                      printf("rela_cnt[%d]\n",rela_cnt);
                      printf("irelative_ply[%s]\n",irelative_ply);
                      if (rela_cnt == 0)
                      {
                           $SELECT --+INDEX (pins32_idx_2)
                                   SUM(mins_premium)
                              INTO $premium2:id
                              FROM ply_ins_type_302
                             WHERE ipolicy=$last_ply
                               AND iins_type != '21' ;                               
                           if (id == -1) premium2 = 0;
                           printf("----- premium2=[%d] \n",premium2);                           	                                 	                     	
                      }
                  }*/
             }

             printf("-16-irelative_ply[%s]\n",irelative_ply);
             printf("-17-fprem[%ld]\n",fprem);

             /* 950828, �p�G�j��Υ��N��L��,�j��n�L   */
             fchg_id = 0;
                
             $SELECT ilicense   
                INTO $ilicense_v        
                FROM policy_302                 
               WHERE ipolicy = $irelative_ply;  
               
             if (SQLCODE == SQLNOTFOUND){ /* �䤣����N��O�� */
             	printf("�䤣�����p�����N��O��\n");  
             }else{	
                strcpy(ilicense_v,trim(ilicense_v));
                if(strncmp(license,ilicense_v,strlen(ilicense_v)) != 0 ){
                   fchg_id = 1;
                   printf("license[%s]\n",license);            
                   printf("ilicense_v[%s]\n",ilicense_v);   
                }
             }   
             printf("�j����NID ��/�P(1/0) fchg_id[%d]\n",fchg_id);             
       
             fprem=0;fprem2=0;

             if (irelative_ply[0]!=' ' && irelative_ply[0]!='\0' && fchg_id != 1)
             {      
                   	  
              	  $SELECT  psex_age
                     INTO  $psex_age_1
                     FROM  policy_302
                    WHERE  ipolicy = $irelative_ply;
                            
                  /* �����N���p�O�� */
                  if (fmulti[0]=='0') /* �@��� */
                  {
                       $SELECT --+INDEX (a pins32_idx_2)
                               SUM(mins_premium), SUM(ori_premium)
                          INTO $premium2:fprem, $premium3:fprem2
                          FROM ply_ins_type_302 a,policy_302 b
                         WHERE a.ipolicy=$irelative_ply
                           AND a.ipolicy=b.ipolicy
                           AND YEAR(b.dply_begin)=YEAR($ply1_begin)
                           AND MONTH(b.dply_begin)=MONTH($ply1_begin);
                       printf("-18-#### fprem=[%d] ####\n",fprem);
                       if (fprem==-1) premium2=0;
                       if (fprem2==-1) premium3=0;

                       if(fbigcomp[0]=='1')
                       {
                            $SELECT pre_dply2_bgn,pre_dply2_end
                               INTO $bef_ply2_begin,$bef_ply2_end
                               FROM policy_302
                              WHERE ipolicy = $irelative_ply;

                            $SELECT SUM(decode(pre_minsprem,-999,0,pre_minsprem)),
                                    SUM(ori_premium)
                               INTO $bef_premium2:id,$bef_premium3:id2
                               FROM ply_ins_type_302
                              WHERE ipolicy = $irelative_ply;

                            printf("-19-#### id=[%d] ####\n",id);
                            if (id==-1) bef_premium2=0;
                            if (id2==-1) bef_premium3=0;
                       }
                       else
                       {
                            $SELECT pre_dply2_bgn,pre_dply2_end
                               INTO $bef_ply2_begin,$bef_ply2_end
                               FROM policy_302
                              WHERE ipolicy = $irelative_ply;

                            $SELECT SUM(decode(pre_minsprem,-999,0,pre_minsprem)),
                                    SUM(ori_premium)
                               INTO $bef_premium2:id,$bef_premium3:id2
                               FROM ply_ins_type_302
                              WHERE ipolicy = $irelative_ply;

                            printf("-20-#### id=[%d] ####\n",id);
                            if (id==-1) bef_premium2=0;
                            if (id2==-1) bef_premium3=0;
                       }
                  }
                                                             
                  if (fprem==-1)
                  {    /* ���N�����  or �w�L��*/
                       premium2=0;
                       bef_premium2=0;

                       sprintf(stmt, " SELECT dply_end \
                                         FROM %s:ply_relation   \
                                        WHERE ipolicy = '%s' ",localdb1,irelative_ply);

                       $PREPARE next5 FROM $stmt;
                       $EXECUTE next5 INTO $ply2_end;

                       printf("-21-ply2_end[%l],ply2_begin[%l]\n",ply2_end,ply1_begin);

                       if(ply2_end > ply1_begin)
                       {
                            /**********���N�����****************/
                            sprintf(stmt, " SELECT dply_begin,dply_end,ipolicy   \
                                              FROM %s:ply_relation \
                                             WHERE ipolicy = '%s' ",localdb1,irelative_ply);

                            $PREPARE next7 FROM $stmt;
                            $EXECUTE next7 INTO $ply2_begin,$ply2_end,$last_ply;
                       }
                       else
                       {
                            /**********���N�w�L��****************/
                            sprintf(stmt, " SELECT dply_begin,dply_end,ipolicy \
                                              FROM %s:ply_relation \
                                             WHERE ipolicy=(SELECT inext_ply FROM %s:ply_relation \
                                                             WHERE ipolicy= '%s') " ,
                                          localdb1,localdb1,irelative_ply);
                            $PREPARE next9 FROM $stmt;
                            $EXECUTE next9 INTO $ply2_begin,$ply2_end,$last_ply;
                            if(NOT_FOUND)
                            {
                                strcpy(remark,"���N�w�L��"); remark[10]='\0';
                            }
                            else
                            {
                                strcpy(remark," "); remark[10]='\0';
                            }
                       }
                  }
                  else
                  {    /* ���N��� */
                       rec_count_1--;
                       *rec_cnt=rec_count_1;
                       printf("-22-.### *rec_cnt[%d]\n",*rec_cnt);
                       continue;
                  }
             }
             else /* ��O�j�� */
             {
                  /* 971226, �T����j�|��ĳ50�I, ������j���i��|��ĳ47�I */
                  $SELECT count(*)
                     INTO $rela_cnt
                     FROM policy_302
                    WHERE ipolicy = $irelative_ply
                      AND YEAR(dply_begin) = YEAR($ply1_begin)
                      AND MONTH(dply_begin) = MONTH($ply1_end);
                  printf("rela_cnt[%d]\n",rela_cnt);
                  printf("irelative_ply[%s]\n",irelative_ply);
                  if (rela_cnt == 0)
                  {
                       $SELECT --+INDEX (pins32_idx_2)
                               SUM(mins_premium)
                          INTO $premium2:id
                          FROM ply_ins_type_302
                         WHERE ipolicy=$last_ply
                           AND iins_type != '21' ;                               
                       if (id == -1) premium2 = 0;
                       printf("----- premium2=[%d] \n",premium2);                           	                                 	                     	
                  }             	
                  /*premium2=0;*/
                  premium3=0;
             }
        }
        /*--------------------*/
        printf("-23-->premium2[%ld]\n",premium2);
        
        /* 991215, �^�������s�a�}*/
        strcpy(sAdds_new1," ");
        $SELECT nadds_new1 Into $sAdds_new1 FROM conv_city_ply
          WHERE ipolicy1 = $ply 
            AND fchg1='S';
            
        strcpy(sAdds_new1,trim(sAdds_new1));
        strcpy(aassured_zip,trim(aassured_zip));
        

        /* b.nins_type1 �אּ�� b.nins_type*/ 
        sprintf(stmt_buf,"SELECT {+ INDEX (a pins32_idx_2)} %s %s %s %s FROM %s %s %s ",
                         "a.iins_type,minjured_cover,mdeath_cover,mdamage_cover,",
                         "mdeduct,mins_premium, a.qcoverage,a.qserial,ch_deduct,qday, ",
                         "ori_inj_cover, ori_dea_cover, ori_dam_cover, ori_deduct, ",
                         "ori_premium, b.nins_type, b.qcoverage, b.qserial",
                         "ply_ins_type_302 a , insurance_type b",
                         "WHERE ipolicy=? AND a.iins_type = b.iins_type ",
                         "ORDER BY b.qserial");

        printf("stmt_buf[%s]\n", stmt_buf );
             
        $PREPARE STM_ins FROM $stmt_buf;
        $DECLARE CUR_ins CURSOR FOR STM_ins;
        $OPEN CUR_ins USING $ply;
        while (1)
        {
            $FETCH CUR_ins
              INTO $ins_type,$injured_cover,$death_cover,$damage_cover,
                   $deduct,$ins_premium,$qcoverage,$qserial,$ch_deduct,$qday,
                   $ori_inj_cover,$ori_dea_cover,$ori_dam_cover,$ori_deduct,
                   $ori_premium,$nins_type1,$qcoverage,$qserial1;

           if (NOT_FOUND) break;
           	
           strcpy(ins_type, trim(ins_type));
           
           /* 100.04.01 */	
           if (strcmp(ins_type,"52") == 0){ 	
               if(fcar_class[0]=='1'){ /* �ۥΨ� */
               	   strcpy(nins_type1, "���D�d�����[����");
               }else{
              	   strcpy(nins_type1, "�T�����D�d���O�I");
               }
           }  	
           if ( strcmp(ins_type,"01") == 0 ||
                strcmp(ins_type,"05") == 0 ||
                strcmp(ins_type,"09") == 0 ||
                strcmp(ins_type,"08") == 0 ||
                strcmp(ins_type,"85") == 0 )
            {
                dmg_flag = 'Y';
                rfmtlong(damage_cover,"###,###,##&",LHsdamage_cover);
                rfmtlong(ins_premium,"###,###,##&",LHsMprem);
                strcpy(LHsMdeduct,ch_deduct);

                if (qday > 0)
                    qday_01 = 1;
                else
                    qday_01 = 0;
            }
            dmg_flag_p = dmg_flag;

            if (strcmp(ins_type,"11") == 0)
            {
                if (qday > 0)
                    qday_11 = 1;
                else
                    qday_11 = 0;
            }

            if (strcmp(ins_type,"31") == 0 ||
                strcmp(ins_type,"36") == 0 )
                lia_flag = 'Y';
                
            lia_flag_p = lia_flag ;

            printf("inser into INS_TYPE1 ins_type[%s] qserial1[%d]\n", 
                    ins_type, qserial1);
            strcpy(ins_type, trim(ins_type));
            if (! Insert_INS_TYPE1(ins_type, injured_cover, death_cover,
                                   damage_cover, ch_deduct, ins_premium, 
                                   ori_inj_cover,ori_dea_cover,ori_dam_cover,
                                   ori_deduct,ori_premium,nins_type1,qcoverage,
                                   qserial1,qday))
            {
                printf("malloc fail in struct INS_TYPE allocation!\n");
                $CLOSE CUR_ins;
                return M_CM_NOT_MALLOC;
            }
                 
        }
        $CLOSE CUR_ins;
             
        /*---�C�L��O��---*/
        CA301XForm1(db,fmulti, fbigcomp);              /* ����O�O */
        CA301XForm2(db,fbigcomp,fmulti);     /* ����q���� */
    }
    $CLOSE CA302_ply_302_1;
    
    $drop table NO_NASS;

    printf("befreturn\n");
    return SUCCESS;

ca_rpt_renew_err:
    printf("ca_rpt_renew_err1....\n");
    printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/*** ����O�O--�T���O�I�n�O�� PrintForm1 *************************/
CA301XForm1(db,fmulti, fbigcomp)
char *db,*fmulti, *fbigcomp;
{
    int   i, other_ins;
    char  ch1[10], ch2[10];
    $char edomain1[25],edomain2[81];
    $char tmp_edo11[13],tmp_edo12[12],tmp_edo21[13],tmp_edo22[12];
    $char nins_abbr[29];
    $char nins_abbr1[29];

    printf("=============into CA30XForm1()\n");

    $WHENEVER SQLERROR GOTO ca30xform1_err;

    CA301XF1_1();        /* �򥻸�� */
    CA301XF1_2(fmulti);  /* �I�� */
    CA301XF1_3(db, fbigcomp);

    return 1;

ca30xform1_err:
    printf("ca30xform1_err....\n");
    printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* *�T���O�I�n�O��-- �򥻸�� **************************************/
CA301XF1_1()
{
    char  datestr[16], ch1[10], ch2[10], ch3[3];
    char  yy1[4], mm1[3], dd1[3], yy2[4], mm2[3], dd2[3];
    char  benefn1[31],benefn2[31];
    $char tmp_area[3],area_code[3];
    char  iss1[4], iss2[3];
    char assureda1[80], assureda2[80], assureda_all[90];
    char yy[4],mm[3],dd[3],tmp_today[12];
    $char tmp_str[31];
    int  i;

    printf(">>>> into ca302F1_1()\n");

    $WHENEVER SQLERROR GOTO ca30xf1_err;

    printf("fcar_class[%s]\n",fcar_class);

    rgu_put_body(92); max_count++;
    rgu_put_body(93); max_count++;
    rgu_put_body(94); max_count++;
        
    rgu_put_body_string(2,nchi_full,RIGHT);
    rgu_put_body_string(2,itoa(rec_count_1),RIGHT);
    if(fcar_class[0]=='1')
    {
         rgu_put_body_string(2,"V",RIGHT);
         rgu_put_body_string(2," ",RIGHT);
    }
    else
    {
         rgu_put_body_string(2," ",RIGHT);
         rgu_put_body_string(2,"V",RIGHT);
    }
    rgu_put_body(2); /* �ۥ�/��~ */

    printf("last_card[%s]\n",last_card);
 
    if (strlen(trim(icorps)) != 0)
    {
         rgu_put_body_string(95,trim(icorps),1);
         rgu_put_body_string(95,trim(ncorps),1);
         rgu_put_body(95);
    }
    else
    {
         rgu_put_body(1);
    }
    rgu_put_body(1);
    rgu_put_body(1);

    max_count+=4;

    strncpy(ch1,last_ply,3);
    ch1[3]='\0';
    rgu_put_body_string(3,ch1,RIGHT);
    strncpy(ch1,last_ply+3,14);
    ch1[14]='\0';
    rgu_put_body_string(3,ch1,LEFT);
    rgu_put_body_string(3,iply_area,LEFT);
    rgu_put_body(3); /* �O�I�渹�X */
    rgu_put_body(1);
    max_count+= 2;

    rgu_put_body_string(4,assuredn,LEFT);
    
    /* 101.08.24 ,�Q�O�I�H���k�H�ɤ��N���H */
    if(strlen(trim(ndeputy_assured)) != 0)
        rgu_put_body_string(4,ndeputy_assured,LEFT);
    else 
        rgu_put_body_string(4," ",LEFT);
        
    if(strlen(trim(user)) != 0)
        rgu_put_body_string(4,user,LEFT);
    else 
        rgu_put_body_string(4," ",LEFT);
    rgu_put_body(4); /* �ϥΤH */

    /* 991215, �����s�a�}*/
    if (strlen(sAdds_new1)>6){
  	
  	   
        rgu_put_body_string(5,"(�s�a�}:",LEFT);
        
	    printf("sAdds_new1[%s]\n",sAdds_new1);
	    ben_len=cc_split_chinese(sAdds_new1,assureda1,60);    
	    strcpy(assureda1,rtrim(assureda1));
	    printf("assureda1[%s]\n",assureda1);    
	    sprintf(assureda2,"%s)",assureda1);	    
	    strcpy(assureda2,rtrim(assureda2));
	    printf("assureda2[%s]\n",assureda2);   
	    rgu_put_body_string(5,assureda2,LEFT); 
	 	 
	    strcpy(tmp_str,"(��):");
	    strcat(tmp_str,tel);
	    rgu_put_body_string(5,rtrim(tmp_str),LEFT); 	 
	    rgu_put_body(5);   	
	    strcpy(assureda1,"");
	    
    }else{
    	
	    strcpy(tmp_str,"(��):");
	    strcat(tmp_str,tel);
	    rgu_put_body_string(91,rtrim(tmp_str),1);
	    rgu_put_body(91);   	
    }
       

    printf("assureda[%s]\n",assureda);
    ben_len=cc_split_chinese(assureda,assureda1,60);
    ben_len=cc_split_chinese(&assureda[ben_len],assureda2,60);
    printf("assureda1[%s]\n",assureda1);
    printf("assureda2[%s]\n",assureda2);    
    strcpy(aassured_zip,rtrim(aassured_zip));
    rgu_put_body_string(5,aassured_zip,LEFT);
    strcpy(assureda1,rtrim(assureda1));
    rgu_put_body_string(5,assureda1,LEFT);
/*        
    sprintf(assureda_all,"%s %s",aassured_zip,assureda1);
    strcpy(assureda_all,rtrim(assureda_all));
    printf("assureda_all[%s]\n",assureda_all);    
    rgu_put_body_string(5,assureda_all,LEFT); */
  
    /*
    aassured_zip[5]='\0';
    rgu_put_body_string(5,trim(aassured_zip),LEFT); 
    rgu_put_body_string(5,assureda1,LEFT); 
    */
    
    strcpy(tmp_str,"(�]):");
    strcat(tmp_str,tphone_con);
    rgu_put_body_string(5,rtrim(tmp_str),1);

    rgu_put_body(5); /* ���� */

    strcpy(tmp_str,"(���):");
    strcat(tmp_str,imovephone);
    rgu_put_body_string(91,rtrim(tmp_str),1);
    rgu_put_body(91);

    max_count+=4;

    
    /* 970725 */
    /* 970829,���k�H�~,�@������ ID*/
    /*if (ibig_comp_s[0]!=' ' && ibig_comp_s[0]!='\0'){  �O�N�� 
	    if (ibig_comp_s[0]!='L' && ibig_comp_s[0]!='P'){*/
	        if (sFassured[0]=='1'||sFassured[0]=='3'||sFassured[0]=='5'){
	          strncpy(license+(3),"****",4);
	        }
	/*    }
	} */   
	
    /* 101.08.24 �������y */
    /* 980815, �]���s�Wdbirth ,dissue*/
    rgu_put_body_string(10,license,LEFT);
    if (strlen(trim(s_dbirth))==0)
    {
        /* rgu_put_body_string(10," ",LEFT);
        rgu_put_body_string(10," ",LEFT);*/
        rgu_put_body_string(10," ",LEFT);
        rgu_put_body_string(10," ",LEFT);
        rgu_put_body_string(10," ",LEFT);
        
        strcpy(birth," ");
    }
    else
    {
    	/*
        if(strlen(trim(license))==10 && license[0] >= 'A' && license[0] <= 'Z')
        {
           rgu_put_body_string(10,"V",LEFT);
           rgu_put_body_string(10," ",LEFT);
        }
        else
        {
           rgu_put_body_string(10,"V",LEFT);
           rgu_put_body_string(10," ",LEFT);
        }
        */
        /* 980815, �]���s�Wdbirth ,dissue*/
        cm_split_ymd(s_dbirth, tmp_mm, tmp_dd, tmp_yyyy);
        /*cm_split_ymd_100(birth,yy2,mm2,dd2);*/
        sprintf(yy2,"%d", atoi(tmp_yyyy)-1911);
        strcpy(yy2, trim(yy2));
        strcpy(mm2, tmp_mm);
        strcpy(dd2, tmp_dd);
        sprintf(birth,"%s/%s/%s",yy2,mm2,dd2 );
        strcpy(birth, trim(birth));
        
        rgu_put_body_string(10,yy2,LEFT);
        rgu_put_body_string(10,mm2,LEFT);
        rgu_put_body_string(10,dd2,LEFT);
    }   
    if (*sex=='1')
    {
        rgu_put_body_string(10,"V",RIGHT);
        rgu_put_body_string(10," ",RIGHT);
    }
    else
    {
        if (*sex=='2')
        {
                rgu_put_body_string(10," ",RIGHT);
                rgu_put_body_string(10,"V",RIGHT);
        }
        else
        {
                rgu_put_body_string(10," ",RIGHT);
                rgu_put_body_string(10," ",RIGHT);
        }
    }
  
    if (*marriage=='1')
    {
        rgu_put_body_string(10,"V",RIGHT);
        rgu_put_body_string(10," ",RIGHT);
    }
    else
    {
        if (*marriage=='2')
        {
                rgu_put_body_string(10," ",RIGHT);
                rgu_put_body_string(10,"V",RIGHT);
        }
        else
        {
                rgu_put_body_string(10," ",RIGHT);
                rgu_put_body_string(10," ",RIGHT);
        }
    }

    rgu_put_body(10); /* �Q�O�I�H�򥻸�� */
    max_count++;                    
    
    /* 101.08.24 ,�n�O�H�Ҧ���쳣�n�L */
    /* 101.01.20, ��J�n�O�H�W�١A�a�}���ť� */ 
    strcpy(napplicant,trim(napplicant));
    strcpy(ndeputy_appl,trim(ndeputy_appl));
    strcpy(apayment_zip,trim(apayment_zip));
    strcpy(apayment,trim(apayment));
    /*sprintf(tmp_napplicant,"       %s",napplicant);
    strcpy(tmp_napplicant,rtrim(tmp_napplicant));
    rgu_put_body_string(4,tmp_napplicant,LEFT);*/
    rgu_put_body_string(90,napplicant,LEFT);
    rgu_put_body_string(90,ndeputy_appl,LEFT);
    rgu_put_body_string(90,apayment_zip,LEFT);
    rgu_put_body_string(90,apayment,LEFT);        
    rgu_put_body(90); 
    
    rgu_put_body(1);     
    max_count+=2;

    if (fcard_class[0] == '2')
    {
        strcpy(datestr,cm_cdate_str_100(ply2_begin));
        cm_split_ymd_100(datestr,yy1,mm1,dd1);
        rgu_put_body_string(7,yy1,LEFT);
        rgu_put_body_string(7,mm1,LEFT);
        rgu_put_body_string(7,dd1,LEFT);
    }
    else
    {
        strcpy(datestr,cm_cdate_str_100(ply1_begin));
        cm_split_ymd_100(datestr,yy1,mm1,dd1);
        rgu_put_body_string(7,yy1,LEFT);
        rgu_put_body_string(7,mm1,LEFT);
        rgu_put_body_string(7,dd1,LEFT);
    }
    if (fcard_class[0] == '2') 
    {
        strcpy(datestr,cm_cdate_str_100(ply2_end));
        cm_split_ymd_100(datestr,yy2,mm2,dd2);
        rgu_put_body_string(7,yy2,LEFT);
        rgu_put_body_string(7,mm2,LEFT);
        rgu_put_body_string(7,dd2,LEFT);
    }
    else
    {
        strcpy(datestr,cm_cdate_str_100(ply1_end));
        cm_split_ymd_100(datestr,yy1,mm1,dd1);
        rgu_put_body_string(7,yy1,LEFT);
        rgu_put_body_string(7,mm1,LEFT);
        rgu_put_body_string(7,dd1,LEFT);
    }    
    /*rgu_put_body(7); 
    max_count++;*/
    /* ����v�H */
    ben_len=cc_split_chinese(benefn,benefn1,30);
    ben_len=cc_split_chinese(&benefn[ben_len],benefn2,30);
    if(strlen(trim(benefn1)) != 0)
        rgu_put_body_string(7,benefn1,LEFT);
    else
        rgu_put_body_string(7," ",LEFT);
            
    if(strlen(trim(benefn2)) != 0)
        rgu_put_body_string(7,benefn2,LEFT);
    else
        rgu_put_body_string(7," ",LEFT);
        
    rgu_put_body(7); /* ���q�H/�O�I���� */
    max_count++;
    rgu_put_body(1);
    rgu_put_body(1);
    max_count+=2;

    /* 980815, �]���s�Wdbirth ,dissue*/
    cm_split_ymd(s_dissue, tmp_mm, tmp_dd, tmp_yyyy);
    sprintf(iss1,"%d", atoi(tmp_yyyy)-1911 );
    strcpy(iss1, trim(iss1));
    strcpy(iss2, trim(tmp_mm));
    
    /*strncpy(iss1,issue_ym,2); iss1[2]='\0';*/
    rgu_put_body_string(8,iss1,LEFT);
    rgu_put_body_string(8,pro_year,LEFT); 
    rgu_put_body_string(8,brandi,LEFT);
    rgu_put_body_string(8,car_typei,LEFT);
    sprintf(ch1,"%2d",cylinder);
    rgu_put_body_string(8,ch1,LEFT);
    if (engine[0] !='\0' && engine[0] !=' ')
        rgu_put_body_string(8,engine,LEFT);
    else
        rgu_put_body_string(8,body,LEFT);

    rgu_put_body_string(8,tagnum,LEFT);
    sprintf(ch1,"%2.0f",qpt);
    printf("qpt[%s]\n",ch1);
    rgu_put_body_string(8,ch1,LEFT);
    rgu_put_body(8); /* ���y���-I */
    max_count+=1;
     /* 980815, �]���s�Wdbirth ,dissue*/
   /* strncpy(iss2,issue_ym+3,2); iss2[2]='\0';*/
    rgu_put_body_string(9,iss2,LEFT);

    rgu_put_body_string(9,brandn,LEFT);
    rgu_put_body_string(9,car_typen,LEFT);
    if(fpt[0]=='P')
        rgu_put_body_string(9,"�H",LEFT);
    else if(fpt[0]=='T')        
        rgu_put_body_string(9,"��",LEFT);
    else 
        rgu_put_body_string(9," ",LEFT);
    rgu_put_body(9); /* ���y���-II */
    max_count+=1;

    rgu_put_body_string(11,idmg_rate,RIGHT);
    sprintf(ch1,"%5.4f",dmg_factor);
    ch1[6]='\0';
    rgu_put_body_string(11,ch1,RIGHT);
    rgu_put_body_string(11,ibrg_rate,RIGHT);
    sprintf(ch1,"%5.4f",brg_factor);
    ch1[6]='\0';
    rgu_put_body_string(11,ch1,RIGHT);    
    sprintf(ch1,"%4.2f",psex_age_2);  /*�j*/
    strcpy(ch1,"     "); /* 980310, �~�֩ʧO�Y�����d�ť�*/
    rgu_put_body_string(11,ch1,RIGHT);
    sprintf(ch1,"%4.2f",psex_age_1);  /*��*/
    strcpy(ch1,"     "); /* 980310, �~�֩ʧO�Y�����d�ť�*/
    rgu_put_body_string(11,ch1,RIGHT);

    rgu_put_body(11); /* �O�v�N���ΫY�� */
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body_string(60,"",LEFT);
    rgu_put_body_string(60,"",LEFT);
    rgu_put_body_string(60,"",LEFT);
    rgu_put_body_string(60,"",LEFT);
    rgu_put_body_string(60,"",LEFT);
    rgu_put_body_string(60,"",LEFT);
    rgu_put_body_string(60,"",LEFT);
    rgu_put_body_string(60,big_office,LEFT);
    rgu_put_body(60);
    max_count+=4;

    return 1;

ca30xf1_err:
    printf("ca30xf1_err....\n");
    printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/** �T���O�I�n�O��--�I�� *******************************************/
CA301XF1_2(fmulti)
char *fmulti;
{
    char ch1[10], partion[2], partion_bak[2];
    char sstmp[31],sstmp1[513];
    struct INS_TYPE1 *ptr;
    int  i, first_line, tins;
    int  line25_prt, put_line, qserial_bak, qserial_ins;
    int  ins56_flag,ins50_flag;
   $int  count_no;
    char ncover_name1[2];
    char ncover_name2[11];
    char ch_deduct_tmp[6];

   /* 970822, �s�W�Ĥ@���Q�O�I�H�W�U */
   $char  iinsurant_pa[11]=" " , ninsurant_pa[31]=" ", ibirth_pa[11], nbenif_pa[31],irel_pa[14];
   $char  mm_pa[3], dd_pa[3], yyyy_pa[5];
   $int   cy_pa;
        
    printf(">>>> into ca302F1_2()\n");
    $WHENEVER SQLERROR GOTO ca30xf1_2_err;
    printf(">>>> fcard_class[%s] remark[%s]\n", fcard_class, remark);

    ptr = Ifirst1;
    first_line=1;
    line25_prt=0;
    put_line  =0;
    ins56_flag=0;
    ins50_flag=0;
    ncover_name1[0]='\0';
    ncover_name2[0]='\0';
    ch_deduct_tmp[0]='\0';

    /* 970822,�����ɼW�[�@���Q�O�I�H�W�U */               
    sprintf(stmt, "SELECT first 1 nvl(ninsurant,' '),nvl(iinsurant,' '),to_char(dbirth) ,nvl(nbeneficiary,' '), \
                          CASE \
                             WHEN nvl(relation_bene,' ') = '1' THEN '���H' \
                             WHEN nvl(relation_bene,' ') = '2' THEN '�a��' \
                             WHEN nvl(relation_bene,' ') = '3' THEN '�O�Υ������H' \
                             WHEN nvl(relation_bene,' ') = '4' THEN '�ŰȤH' \
                             WHEN nvl(relation_bene,' ') = '5' THEN '�]���޲z�H' \
                             WHEN nvl(relation_bene,' ') = '6' THEN '�k�w�~�ӤH' \
                          ELSE ' ' END AS relation_bene \
                     FROM ca_pa_ply_302 \
                    WHERE ipolicy =? AND iins_type='56' "); 
    $PREPARE prePa_list FROM $stmt;            
    printf(" ------- stmt = [%s]\n " , stmt);
      
    if (fcard_class[0]=='1' &&
        remark[0]!=' ' && remark[0]!='\0')
    {
        rgu_put_body_string(48,remark,LEFT);
        for (i=0; i<26; i++) /* peter */
             rgu_put_body(1);
    }
    else
    {
        /*�Ѽ�:�C�L���,�I��,�O�B,�L�O�O,�ۭt�B,�j�O��flag*/
        /* �I�� 01/05/09/08 */
        
        while(ptr)
        {
            strcpy(ins_type,   trim(ptr->ins_type));
            strcpy(nins_type1, ptr->nins_type1);
            strcpy(ch_deduct,  ptr->ch_deduct);
            injured_cover = ptr->injured_cover;
            death_cover   = ptr->death_cover; 
            damage_cover  = ptr->damage_cover;
            ins_premium   = ptr->ins_premium;
            ori_injured_cover = ptr->ori_inj_cover;
            ori_death_cover   = ptr->ori_dea_cover;
            ori_damage_cover  = ptr->ori_dam_cover;
            ori_deduct        = ptr->ori_deduct;
            ori_premium       = ptr->ori_premium;
            qcoverage         = ptr->qcoverage;
            qserial           = ptr->qserial;
            qday              = ptr->qday;
            
            printf("ins_type[%s] qserial[%d]\n", ins_type, qserial );
            printf(" ------- nins_type1 = [%s]\n " , nins_type1);                  
            printf("injured_cover[%ld]\n", injured_cover );   
            printf("death_cover[%ld]\n", death_cover );   
            printf("damage_cover[%ld]\n", damage_cover );   
            printf("qcoverage[%d]\n", qcoverage );   
            if(strcmp(trim(ins_type),"21")==0)
            {
               ptr=ptr->next;
               continue;
            } 
            
            /* 950908,��ĳ�έ��O�զX���O�O��0��,���C�L ,
                  ex. ��ĳ�I�إ�09=>05,�h�N�P�ɥX�{09��05 ,
                      ��09�ȫe���O�B�O�O����0, ��l����0 ; 05�h�ۤ�*/
                      
            if((ins_premium==0)&&(ori_premium==0)){
               ptr=ptr->next;
               continue;            	
            }

            qserial_ins = qserial / 10;
            
            /* 980605,�[������
               �Y�Ofirst_line=1,���ܬ��Ĥ@�ӦL�s���I��,���I�ت��Ĥ@��̫᭱�n�C�L"�~�N�N�X" 
               �Y�O���I�ئ��G��, �h�ĤG�檺�̫᭱�n�C�L"�~�N�W��",���ɳ]�w line25_prt=1 ���ܤw�g�L�L"�~�N�W��";
               �Y�Ofirst_line=0,���ܬ��ĤG�ӥH��L�s���I��,�Yline25_prt=0���ܤW�����Ĥ@���I�إu���@��, �����b��
               �G���I�ت��Ĥ@��᭱�C�L "�~�N�W��" */ 
            if( first_line == 1 )
            {
                printf("in first_line \n");
                
                first_line = 0;
                qserial_bak = qserial / 10;

                if( qcoverage == 1 )
                {
                	tins = atoi(ins_type);
                    if (tins== 56){ /* 950704 */
		                    rgu_put_body_string(60,ins_type,LEFT);
		                    rgu_put_body_string(60,nins_type1,LEFT);
		                    rgu_put_body_string(60," ",LEFT);
		                    rgu_put_body_string(60,trim(ch_deduct),RIGHT);
		                    strcpy(sstmp,refmtamt(ins_premium ,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		                    rgu_put_body_string(60," ",LEFT);
		                    strcpy(sstmp,refmtamt(ori_premium ,MILLIONTH));
	                        rgu_put_body_string(60,sstmp,2);	            	    
	                        rgu_put_body_string(60,trim(big_sales),LEFT); /* �~�N�N�X*/
		                    rgu_put_body(60);

		                    rgu_put_body_string(60," ",LEFT);
		                    rgu_put_body_string(60,"�ݼo�Φ��`�O�I��",LEFT);
		                    strcpy(sstmp,refmtamt(damage_cover,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		                    rgu_put_body_string(60," ",LEFT);
		                    rgu_put_body_string(60," ",LEFT);
		                    strcpy(sstmp,refmtamt(ori_damage_cover,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		                    rgu_put_body_string(60," ",LEFT);
		                    /*rgu_put_body_string(60," ",LEFT);*/		                    
		                    rgu_put_body_string(60,trim(LHsNname),LEFT); /* �~�N�W��*/
		                    rgu_put_body(60);
		                    line25_prt=1;
		                    
                            put_line = put_line+2;                            		  
                           /* ���[���� */                            
					        sprintf(stmt, " SELECT FIRST 1 nvl(daily_pay,0),nvl(ori_daily_pay,0)  \
					                          FROM ca_pa_ply_302 \
					                         WHERE ipolicy = ? \
					                           AND iins_type = ? \
					                           AND iins_scope ='2'");
					        printf("get_daily_pay=> stmt[%s]\n", stmt );
					        $PREPARE prep_pa FROM $stmt;
					
					        $EXECUTE prep_pa INTO $lDaily_pay,$ori_lDaily_pay USING $last_policy, $ins_type;
					        
                            if ((SQLCODE != SQLNOTFOUND) && (lDaily_pay != 0) ){                             
			                    rgu_put_body_string(60," ",LEFT);
			                    rgu_put_body_string(60,"���|�������B",LEFT);
			                    strcpy(sstmp,refmtamt(lDaily_pay,MILLIONTH));
			                    rgu_put_body_string(60,sstmp,2);
			                    rgu_put_body_string(60," ",LEFT);
			                    rgu_put_body_string(60," ",LEFT);
			                    
			                    /*
			                    if (ori_damage_cover==0){
			                    	rgu_put_body_string(60,"0",2);
			                    }else{	
			                        strcpy(sstmp,refmtamt(lDaily_pay,MILLIONTH));
			                        rgu_put_body_string(60,sstmp,2);
			                    } */
		                        strcpy(sstmp,refmtamt(ori_lDaily_pay,MILLIONTH));
		                        rgu_put_body_string(60,sstmp,2); 
			                        			                   			                    
			                    rgu_put_body_string(60," ",LEFT);
			                    rgu_put_body_string(60," ",LEFT);
			                    rgu_put_body(60);
			                    
			                    put_line = put_line+1;                             	
                             }        
		            }else if(tins==38 || tins==39) {
		            	
	                    rgu_put_body_string(60,ins_type,LEFT);
	                    if(tins==38)
	                       strcpy(nins_type1,"�D���ϴ����v�I�򥻫�");
	                    else   
	                       strcpy(nins_type1,"�D���ϴ����v�I�O�٫�");	 
	                    
	                    rgu_put_body_string(60,nins_type1,LEFT);
	                    
/*           	                
	                    strcpy(sstmp,refmtamt(damage_cover,MILLIONTH));
*/	                    
                      	strcpy(sstmp,"��Q���{");
                      	rgu_put_body_string(60,sstmp,RIGHT);	                    
	                    
/*	                    
	                    rgu_put_body_string(60,trim(ch_deduct),RIGHT);
*/	                    
                        if (damage_cover > 0){
                            sprintf(sstmp,"%ld���� �L",qday);
                            rgu_put_body_string(60,sstmp,LEFT); 
                        }else{
                            strcpy(sstmp," 0���� �L");
                            rgu_put_body_string(60,sstmp,LEFT);                         	
                        }    

	            	    strcpy(sstmp,refmtamt(ins_premium ,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    
	                    if (ori_damage_cover > 0){
                            sprintf(sstmp,"%ld����",qday);
                            rgu_put_body_string(60,sstmp,RIGHT); 	                    	
	                    }else{
                            strcpy(sstmp," 0���� �L");
                            rgu_put_body_string(60,sstmp,LEFT);                         	
                        } 
	                    
	            	    strcpy(sstmp,refmtamt(ori_premium ,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	            	    
	                    rgu_put_body_string(60,trim(big_sales),LEFT);  /* �~�N�N�X*/
	                    rgu_put_body(60);
	                    put_line++;
	                    	                    
                    }else if(tins==27) {
		                rgu_put_body_string(60,ins_type,LEFT);
		                rgu_put_body_string(60,nins_type1,LEFT);
		                rgu_put_body_string(60," ",LEFT);
		                rgu_put_body_string(60,trim(ch_deduct),RIGHT);
		                strcpy(sstmp,refmtamt(ins_premium ,MILLIONTH));
		                rgu_put_body_string(60,sstmp,2);
		                rgu_put_body_string(60," ",LEFT);
		                strcpy(sstmp,refmtamt(ori_premium ,MILLIONTH));
		                rgu_put_body_string(60,sstmp,2);
		                rgu_put_body_string(60," ",LEFT);
		                rgu_put_body(60);
		                
		                
		                rgu_put_body_string(60," ",LEFT);
		                rgu_put_body_string(60,"�̰����I���O�I���B",LEFT);
		                strcpy(sstmp,refmtamt(damage_cover,MILLIONTH));
		                rgu_put_body_string(60,sstmp,2);
		                rgu_put_body_string(60," ",LEFT);
		                rgu_put_body_string(60," ",LEFT);
		                strcpy(sstmp,refmtamt(ori_damage_cover,MILLIONTH));
		                rgu_put_body_string(60,sstmp,2);
		                rgu_put_body_string(60," ",LEFT);
		                rgu_put_body_string(60," ",LEFT);
		                rgu_put_body(60);
		                
                        put_line++;		            	                                    
                    }else{                   	
	                    rgu_put_body_string(60,ins_type,LEFT);
	                    rgu_put_body_string(60,nins_type1,LEFT);
	                
	                    strcpy(sstmp,refmtamt(damage_cover,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60,trim(ch_deduct),RIGHT);
	            	    strcpy(sstmp,refmtamt(ins_premium ,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    
	            	    strcpy(sstmp,refmtamt(ori_damage_cover,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	            	    strcpy(sstmp,refmtamt(ori_premium ,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	            	    
	                    rgu_put_body_string(60,trim(big_sales),LEFT);  /* �~�N�N�X*/
	                    rgu_put_body(60);
	                    put_line++;
	                    	                    
	                    if(((tins== 1 || tins== 5 || tins== 8 || tins== 9)&& (qday_01 == 1)) ||
	                       ((tins==11) && (qday_11 == 1)))
	                    { 
	                        rgu_put_body_string(60," ",LEFT);
	                        rgu_put_body_string(60," ",LEFT);
	                        rgu_put_body_string(60," ",LEFT);
	                        rgu_put_body_string(60,"(�[��)",LEFT);
	                        rgu_put_body_string(60," ",LEFT);
	                        rgu_put_body_string(60," ",LEFT);
	                        rgu_put_body_string(60," ",LEFT);
	                        rgu_put_body_string(60,trim(LHsNname),LEFT);  /* �~�N�W��*/
	                        rgu_put_body(60);
	                        put_line++;
	                        line25_prt=1;
	                    }
	               }    
                }
                else if( qcoverage == 2 )
                {
                	tins = atoi(ins_type);                     

                    if (tins== 56){ /* 950704 */
		                    rgu_put_body_string(60,ins_type,LEFT);
		                    rgu_put_body_string(60,nins_type1,LEFT);
		                    rgu_put_body_string(60," ",LEFT);
		                    rgu_put_body_string(60,trim(ch_deduct),RIGHT);
		                    strcpy(sstmp,refmtamt(ins_premium ,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		                    rgu_put_body_string(60," ",LEFT);
		                    strcpy(sstmp,refmtamt(ori_premium ,MILLIONTH));
	                        rgu_put_body_string(60,sstmp,2);	            	    
	                        rgu_put_body_string(60,trim(big_sales),LEFT);  /* �~�N�N�X*/
		                    rgu_put_body(60);

		                    rgu_put_body_string(60," ",LEFT);
		                    rgu_put_body_string(60,"�ݼo�Φ��`�O�I��",LEFT);
		                    strcpy(sstmp,refmtamt(damage_cover,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		                    rgu_put_body_string(60," ",LEFT);
		                    rgu_put_body_string(60," ",LEFT);
		                    strcpy(sstmp,refmtamt(ori_damage_cover,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		                    rgu_put_body_string(60," ",LEFT);
		                    rgu_put_body_string(60,trim(LHsNname),LEFT);  /* �~�N�W��*/
		                    rgu_put_body(60);
		                    line25_prt=1;
		                    
                            put_line = put_line+2;
                            
                           /* ���[���� */                            
					        sprintf(stmt, " SELECT FIRST 1 nvl(daily_pay,0),nvl(ori_daily_pay,0)  \
					                          FROM ca_pa_ply_302 \
					                         WHERE ipolicy = ? \
					                           AND iins_type = ? \
					                           AND iins_scope ='2'");
					        printf("get_daily_pay=> stmt[%s]\n", stmt );
					        $PREPARE prep_pa FROM $stmt;
					
					        $EXECUTE prep_pa INTO $lDaily_pay,$ori_lDaily_pay USING $last_policy, $ins_type;
					        
                            if ((SQLCODE != SQLNOTFOUND) && (lDaily_pay != 0) ){                             
			                    rgu_put_body_string(60," ",LEFT);
			                    rgu_put_body_string(60,"���|�������B",LEFT);
			                    strcpy(sstmp,refmtamt(lDaily_pay,MILLIONTH));
			                    rgu_put_body_string(60,sstmp,2);
			                    rgu_put_body_string(60," ",LEFT);
			                    rgu_put_body_string(60," ",LEFT);
			                    
			                    /*
			                    if (ori_damage_cover==0){
			                    	rgu_put_body_string(60,"0",2);
			                    }else{	
			                        strcpy(sstmp,refmtamt(lDaily_pay,MILLIONTH));
			                        rgu_put_body_string(60,sstmp,2);
			                    } */
		                        strcpy(sstmp,refmtamt(ori_lDaily_pay,MILLIONTH));
		                        rgu_put_body_string(60,sstmp,2); 
		                         			                   			                    
			                    rgu_put_body_string(60," ",LEFT);
			                    rgu_put_body_string(60," ",LEFT);
			                    rgu_put_body(60);
			                    
			                    put_line = put_line+1;                             	
                             }                                                     
		                                                
                    }else{ 
                    	 if (tins==57 || tins==59 || tins==60 ){
	                         rgu_put_body_string(60,ins_type,LEFT);
		                     rgu_put_body_string(60,nins_type1,LEFT);
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60,trim(ch_deduct),RIGHT);
		                     strcpy(sstmp,refmtamt(ins_premium ,MILLIONTH));
		                     rgu_put_body_string(60,sstmp,2);
		                     rgu_put_body_string(60," ",LEFT);
		                     strcpy(sstmp,refmtamt(ori_premium ,MILLIONTH));
		                     rgu_put_body_string(60,sstmp,2);	            	    
		                     rgu_put_body_string(60,trim(big_sales),LEFT);  /* �~�N�N�X*/
		                     rgu_put_body(60);	                    		                     
		                     
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60,"  �C�@�ӤH�ݼo�Φ��`",LEFT);
		                     strcpy(sstmp,refmtamt(death_cover,MILLIONTH));
		                     rgu_put_body_string(60,sstmp,2);
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60," ",LEFT);
		                     strcpy(sstmp,refmtamt(ori_death_cover,MILLIONTH));
		                     rgu_put_body_string(60,sstmp,2);
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60,trim(LHsNname),LEFT);  /* �~�N�W��*/
		                     rgu_put_body(60);
		                     line25_prt=1;
		                    		                     
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60,"  �C�@�ƬG�`�B",LEFT);
		                     strcpy(sstmp,refmtamt(damage_cover,MILLIONTH));
		                     rgu_put_body_string(60,sstmp,2);
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60," ",LEFT);
		                     strcpy(sstmp,refmtamt(ori_damage_cover,MILLIONTH));
		                     rgu_put_body_string(60,sstmp,2);
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body(60);      
		                     
		                     put_line = put_line+3;      
		                             	
		                }else if (tins==85) {
		                    rgu_put_body_string(60,ins_type,LEFT);
		                    rgu_put_body_string(60,nins_type1,LEFT);
		                
		                    strcpy(sstmp,refmtamt(damage_cover,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		                    rgu_put_body_string(60,trim(ch_deduct),RIGHT);
		            	    strcpy(sstmp,refmtamt(ins_premium ,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		                    
		            	    strcpy(sstmp,refmtamt(ori_damage_cover,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		            	    strcpy(sstmp,refmtamt(ori_premium ,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		            	    
		                    rgu_put_body_string(60,trim(big_sales),LEFT);  /* �~�N�N�X*/
		                    rgu_put_body(60);
		                    put_line++;
		                    
		                    /*�������l�֭p���v���B*/
		                    rgu_put_body_string(60," ",LEFT);
		                    rgu_put_body_string(60,"�������l�֭p���v���B",LEFT);
		                
		                    strcpy(sstmp,refmtamt(injured_cover,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		                    rgu_put_body_string(60," ",RIGHT);
		                    rgu_put_body_string(60," ",RIGHT);
		                    
		            	    strcpy(sstmp,refmtamt(ori_injured_cover,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		                    rgu_put_body_string(60," ",RIGHT);		            	    
		                    rgu_put_body_string(60,trim(LHsNname),LEFT);  /* �~�N�W��*/
		                    rgu_put_body(60);

	                        put_line++;
	                        line25_prt=1;
                    	}else if(tins==52 || tins==53 || tins==55 ){      /* 100.04.01 */
	                         rgu_put_body_string(60,ins_type,LEFT);
		                     rgu_put_body_string(60,nins_type1,LEFT);
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60,trim(ch_deduct),RIGHT);
		                     strcpy(sstmp,refmtamt(ins_premium ,MILLIONTH));
		                     rgu_put_body_string(60,sstmp,2);
		                     rgu_put_body_string(60," ",LEFT);
		                     strcpy(sstmp,refmtamt(ori_premium ,MILLIONTH));
		                     rgu_put_body_string(60,sstmp,2);	            	    
		                     rgu_put_body_string(60,trim(big_sales),LEFT);  /* �~�N�N�X*/
		                     rgu_put_body(60);	                    		                     
		                     
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60,"  �C�@�ӤH�ˮ`",LEFT);
		                     strcpy(sstmp,refmtamt(death_cover,MILLIONTH));
		                     rgu_put_body_string(60,sstmp,2);
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60," ",LEFT);
		                     strcpy(sstmp,refmtamt(ori_death_cover,MILLIONTH));
		                     rgu_put_body_string(60,sstmp,2);
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60,trim(LHsNname),LEFT);  /* �~�N�W��*/
		                     rgu_put_body(60);
		                     line25_prt=1;
		                    		                     
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60,"  �C�@�N�~�ƬG���ˮ`",LEFT);
		                     strcpy(sstmp,refmtamt(damage_cover,MILLIONTH));
		                     rgu_put_body_string(60,sstmp,2);
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60," ",LEFT);
		                     strcpy(sstmp,refmtamt(ori_damage_cover,MILLIONTH));
		                     rgu_put_body_string(60,sstmp,2);
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body(60);      
		                     
		                     put_line = put_line+3; 		                   		                    	                	     
                    	}else{
		                    rgu_put_body_string(60,ins_type,LEFT);
		                    if (tins== 34){ /* 960612, ���ݪ��I34 */   
		                        strcpy(ncover_name1,"(");
		                        strcpy(ncover_name2,"�ƬG�O�B��");
		                        strcpy(nins_type1,trim(nins_type1));
		                        strcat(nins_type1,ncover_name1);
		                        
		                        strcpy(ch_deduct_tmp,"�G��)");
		                        sprintf(ch_deduct,"%s�@%s",ch_deduct_tmp,trim(ch_deduct));
		                        
		                    }else{
		                    	strcpy(ncover_name2," ");
		                    }    
		                       
		                    rgu_put_body_string(60,nins_type1,LEFT);
		                    /*rgu_put_body_string(60," ",LEFT);*/
		                    rgu_put_body_string(60,ncover_name2,LEFT);                  
		                    if (tins== 34){
		                        rgu_put_body_string(60,trim(ch_deduct),LEFT);
		                    }else{    
		                        rgu_put_body_string(60,trim(ch_deduct),RIGHT);
		                    }  
		                    strcpy(sstmp,refmtamt(ins_premium ,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		                    rgu_put_body_string(60," ",LEFT);
		                    strcpy(sstmp,refmtamt(ori_premium ,MILLIONTH));
	                        rgu_put_body_string(60,sstmp,2);	            	    
	                        rgu_put_body_string(60,trim(big_sales),LEFT);  /* �~�N�N�X*/
		                    rgu_put_body(60);
		                    
		                    rgu_put_body_string(60," ",LEFT);
		                    if (tins== 34){ /* 960612, ���ݪ��I34 */
		                    	rgu_put_body_string(60,"  �C�@�ӤH���|",LEFT);
		                    }else{	
		                        rgu_put_body_string(60,"  �C�@�ӤH�ˮ`",LEFT);
		                    }   
		                    strcpy(sstmp,refmtamt(injured_cover,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		                    rgu_put_body_string(60," ",LEFT);
		                    rgu_put_body_string(60," ",LEFT);
		                    strcpy(sstmp,refmtamt(ori_injured_cover,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		                    rgu_put_body_string(60," ",LEFT);
		                    rgu_put_body_string(60,trim(LHsNname),LEFT);  /* �~�N�W��*/
		                    rgu_put_body(60);
		                    line25_prt=1;
		                    
		                    rgu_put_body_string(60," ",LEFT);
		                    if (tins== 34){ /* 960612, ���ݪ��I34 */
		                    	rgu_put_body_string(60,"  �C�@�ӤH���G",LEFT);
			                    strcpy(sstmp,refmtamt(death_cover,MILLIONTH));
			                    rgu_put_body_string(60,sstmp,2);
			                    rgu_put_body_string(60," ",LEFT);
			                    rgu_put_body_string(60," ",LEFT);
			                    strcpy(sstmp,refmtamt(ori_death_cover,MILLIONTH));                      	
		                    }else{	
		                        rgu_put_body_string(60,"  �C�@�ƬG�`�B",LEFT);
			                    strcpy(sstmp,refmtamt(damage_cover,MILLIONTH));
			                    rgu_put_body_string(60,sstmp,2);
			                    rgu_put_body_string(60," ",LEFT);
			                    rgu_put_body_string(60," ",LEFT);
			                    strcpy(sstmp,refmtamt(ori_damage_cover,MILLIONTH));                       
		                    }                                        
		
		                    rgu_put_body_string(60,sstmp,2);
		                    rgu_put_body_string(60," ",LEFT);
		                    rgu_put_body_string(60," ",LEFT);
		                    rgu_put_body(60);
		                    put_line = put_line+3;
		                }
                    }
                }
                else if( qcoverage == 3 )
                {
                	tins = atoi(ins_type); 
                    if (tins== 50){
                        ins50_flag = 1;
	                    rgu_put_body_string(60,ins_type,LEFT);
	                    rgu_put_body_string(60,nins_type1,LEFT);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60,trim(ch_deduct),RIGHT);
	                    strcpy(sstmp,refmtamt(ins_premium ,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60," ",LEFT);
	                    strcpy(sstmp,refmtamt(ori_premium ,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);	            	    
	                    rgu_put_body_string(60,trim(big_sales),LEFT);  /* �~�N�N�X*/
	                    rgu_put_body(60);
	                    line25_prt=1;
	                   
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60,"�ݼo�Φ��`�O�I��",LEFT);
	                    strcpy(sstmp,refmtamt(death_cover,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60," ",LEFT);
	                    strcpy(sstmp,refmtamt(ori_death_cover,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60,trim(LHsNname),LEFT);  /* �~�N�W��*/
	                    rgu_put_body(60);
	                    line25_prt=1;
	                    
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60,"  �ˮ`�����O�I��",LEFT);
	                    strcpy(sstmp,refmtamt(injured_cover,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60," ",LEFT);
	                    strcpy(sstmp,refmtamt(ori_injured_cover,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body(60);
	                    
                        put_line = put_line+3;
                    }else{	                    	
	                    rgu_put_body_string(60,ins_type,LEFT);
	                    rgu_put_body_string(60,nins_type1,LEFT);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60,trim(ch_deduct),RIGHT);
	                    strcpy(sstmp,refmtamt(ins_premium ,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60," ",LEFT);
	                    strcpy(sstmp,refmtamt(ori_premium ,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);	            	    
	                    rgu_put_body_string(60,trim(big_sales),LEFT);  /* �~�N�N�X*/
	                    rgu_put_body(60);	                    
	                    
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60,"  �C�@�ӤH���",LEFT);
	                    strcpy(sstmp,refmtamt(injured_cover,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60," ",LEFT);
	                    strcpy(sstmp,refmtamt(ori_injured_cover,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60,trim(LHsNname),LEFT);  /* �~�N�W��*/
	                    rgu_put_body(60);
	                    line25_prt=1;
	                   
	                    rgu_put_body_string(60," ",LEFT);
	                    if (tins== 57||tins== 59||tins== 60){ 
	                        rgu_put_body_string(60,"  �C�@�ӤH���`�δݼo",LEFT);
	                    }else{
	                    	rgu_put_body_string(60,"  �C�@�ӤH���`",LEFT); 
	                    }
	                    strcpy(sstmp,refmtamt(death_cover,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60," ",LEFT);
	                    strcpy(sstmp,refmtamt(ori_death_cover,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body(60);
	                 
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60,"  �C�@�ƬG�`�B",LEFT);
	                    strcpy(sstmp,refmtamt(damage_cover,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60," ",LEFT);
	                    strcpy(sstmp,refmtamt(ori_damage_cover,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body(60);
	                    put_line = put_line+4;
                    }
                }
	            /* insurance_type=34 �� qcoverage��2 ,���O ply_ins_type_302 34�I �� qcoverage��4 */
				/* �ҥH����34�G�䳣�� */	                
                else if( qcoverage == 4 )
                {
                	tins = atoi(ins_type);                     
                    	                	
                    rgu_put_body_string(60,ins_type,LEFT);
                    if (tins== 34){ /* 960612, ���ݪ��I34 */   
                        strcpy(ncover_name1,"(");
                        strcpy(ncover_name2,"�ƬG�O�B��");
                        strcpy(nins_type1,trim(nins_type1));
                        strcat(nins_type1,ncover_name1);
                        
                        strcpy(ch_deduct_tmp,"�G��)");
                        sprintf(ch_deduct,"%s�@%s",ch_deduct_tmp,trim(ch_deduct));
                        
                    }else{
                    	strcpy(ncover_name2," ");
                    }    
                       
                    rgu_put_body_string(60,nins_type1,LEFT);
                    /*rgu_put_body_string(60," ",LEFT);*/
                    rgu_put_body_string(60,ncover_name2,LEFT);                 
                    if (tins== 34){
                        rgu_put_body_string(60,trim(ch_deduct),LEFT);
                    }else{    
                        rgu_put_body_string(60,trim(ch_deduct),RIGHT);
                    }  
                    strcpy(sstmp,refmtamt(ins_premium ,MILLIONTH));
                    rgu_put_body_string(60,sstmp,2);
                    rgu_put_body_string(60," ",LEFT);
                    strcpy(sstmp,refmtamt(ori_premium ,MILLIONTH));
	                rgu_put_body_string(60,sstmp,2);	            	    
	                rgu_put_body_string(60,trim(big_sales),LEFT);  /* �~�N�N�X*/
                    rgu_put_body(60);
                    
                    rgu_put_body_string(60," ",LEFT);
                    if (tins== 34){ /* 960612, ���ݪ��I34 */
                    	rgu_put_body_string(60,"  �C�@�ӤH���|",LEFT);
                    }else{	
                        rgu_put_body_string(60,"  �C�@�ӤH�ˮ`",LEFT);
                    }   
                    strcpy(sstmp,refmtamt(injured_cover,MILLIONTH));
                    rgu_put_body_string(60,sstmp,2);
                    rgu_put_body_string(60," ",LEFT);
                    rgu_put_body_string(60," ",LEFT);
                    strcpy(sstmp,refmtamt(ori_injured_cover,MILLIONTH));
                    rgu_put_body_string(60,sstmp,2);
                    rgu_put_body_string(60," ",LEFT);
                    rgu_put_body_string(60,trim(LHsNname),LEFT);  /* �~�N�W��*/
                    rgu_put_body(60);
                    line25_prt=1;
                    
                    rgu_put_body_string(60," ",LEFT);
                    if (tins== 34){ /* 960612, ���ݪ��I34 */
                    	rgu_put_body_string(60,"  �C�@�ӤH���G",LEFT);
	                    strcpy(sstmp,refmtamt(death_cover,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60," ",LEFT);
	                    strcpy(sstmp,refmtamt(ori_death_cover,MILLIONTH));                      	
                    }else{	
                        rgu_put_body_string(60,"  �C�@�ƬG�`�B",LEFT);
	                    strcpy(sstmp,refmtamt(damage_cover,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60," ",LEFT);
	                    strcpy(sstmp,refmtamt(ori_damage_cover,MILLIONTH));                       
                    }                                        

                    rgu_put_body_string(60,sstmp,2);
                    rgu_put_body_string(60," ",LEFT);
                    rgu_put_body_string(60," ",LEFT);
                    rgu_put_body(60);
                    put_line = put_line+3;                	
                }                
            }
            else
            {
                /** ��25�C�~�N�W�٤w�C�L�L�A�H�U���ݦA����� **/
                if(line25_prt == 1)
                {
                   strcpy(LHsNname," ");
                   printf("==> line25 i= 1 LHsNname[%s]\n", LHsNname);
                }
                
                printf("qserial_bak[%d] qserial_ins[%d]\n", 
                        qserial_bak, qserial_ins );   
                if( qserial_bak != qserial_ins )
                {
            	    if( line25_prt == 0 )
            	    {
            	    	rgu_put_body_string(60," ",LEFT);
                        rgu_put_body_string(60," ",LEFT);
                        rgu_put_body_string(60," ",LEFT);
                        rgu_put_body_string(60," ",LEFT);
                        rgu_put_body_string(60," ",LEFT);
                        rgu_put_body_string(60," ",LEFT);
                        rgu_put_body_string(60," ",LEFT);
                        rgu_put_body_string(60,trim(LHsNname),LEFT);
                        rgu_put_body(60);
                        put_line++;
                        line25_prt=1;
                        strcpy(LHsNname," ");
            	    }
            	    else
            	    {
            	       rgu_put_body(1);
            	       put_line++;
            	    }
                }
                printf("2tins[%d]\n",tins);
                if( qcoverage == 1 )                
                {
                	tins = atoi(ins_type); 
                    if (tins== 56){ /* 950704 */
                    	    ins56_flag = 1;
		                    rgu_put_body_string(60,ins_type,LEFT);
		                    rgu_put_body_string(60,nins_type1,LEFT);
		                    rgu_put_body_string(60," ",LEFT);
		                    rgu_put_body_string(60,trim(ch_deduct),RIGHT);
		                    strcpy(sstmp,refmtamt(ins_premium ,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		                    rgu_put_body_string(60," ",LEFT);
		                    strcpy(sstmp,refmtamt(ori_premium ,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		                    rgu_put_body_string(60," ",LEFT);
		                    rgu_put_body(60);
		                   
		                    
		                    rgu_put_body_string(60," ",LEFT);
		                    rgu_put_body_string(60,"�ݼo�Φ��`�O�I��",LEFT);
		                    strcpy(sstmp,refmtamt(damage_cover,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		                    rgu_put_body_string(60," ",LEFT);
		                    rgu_put_body_string(60," ",LEFT);
		                    strcpy(sstmp,refmtamt(ori_damage_cover,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		                    rgu_put_body_string(60," ",LEFT);
		                    rgu_put_body_string(60," ",LEFT);
		                    rgu_put_body(60);
		                    
                            put_line = put_line+2;
                            
                            /* ���[���� */
					        sprintf(stmt, " SELECT FIRST 1 nvl(daily_pay,0),nvl(ori_daily_pay,0)  \
					                          FROM ca_pa_ply_302 \
					                         WHERE ipolicy = ? \
					                           AND iins_type = ? \
					                           AND iins_scope ='2'");
					        printf("pa_stmt[%s]\n", stmt );
					        $PREPARE prep_pa FROM $stmt;
					
					        $EXECUTE prep_pa INTO $lDaily_pay,$ori_lDaily_pay USING $last_policy, $ins_type;
					        
                            if ((SQLCODE != SQLNOTFOUND) && (lDaily_pay != 0) ){                             
			                    rgu_put_body_string(60," ",LEFT);
			                    rgu_put_body_string(60,"���|�������B",LEFT);
			                    strcpy(sstmp,refmtamt(lDaily_pay,MILLIONTH));
			                    rgu_put_body_string(60,sstmp,2);
			                    rgu_put_body_string(60," ",LEFT);
			                    rgu_put_body_string(60," ",LEFT);
			                    
			                    /*
			                    if (ori_damage_cover==0){
			                    	rgu_put_body_string(60,"0",2);
			                    }else{	
			                        strcpy(sstmp,refmtamt(lDaily_pay,MILLIONTH));
			                        rgu_put_body_string(60,sstmp,2);
			                    } */
		                        strcpy(sstmp,refmtamt(ori_lDaily_pay,MILLIONTH));
		                        rgu_put_body_string(60,sstmp,2); 
		                        
			                    rgu_put_body_string(60," ",LEFT);
			                    rgu_put_body_string(60," ",LEFT);
			                    rgu_put_body(60);			                    
			                    put_line = put_line+1;  			                      
			                }                                              	
		            }else if(tins==38 || tins==39) {
		            	
	                    rgu_put_body_string(60,ins_type,LEFT);
	                    if(tins==38)
	                       strcpy(nins_type1,"�D���ϴ����v�I�򥻫�");
	                    else   
	                       strcpy(nins_type1,"�D���ϴ����v�I�O�٫�");	 
	                    
	                    rgu_put_body_string(60,nins_type1,LEFT);
	                    
/*           	                
	                    strcpy(sstmp,refmtamt(damage_cover,MILLIONTH));
*/	                    
                      	strcpy(sstmp,"��Q���{");
                      	rgu_put_body_string(60,sstmp,RIGHT);	                    
	                    
/*	                    
	                    rgu_put_body_string(60,trim(ch_deduct),RIGHT);
*/	                    
                        if (damage_cover > 0){
                            sprintf(sstmp,"%ld���� �L",qday);
                            rgu_put_body_string(60,sstmp,LEFT); 
                        }else{
                            strcpy(sstmp," 0���� �L");
                            rgu_put_body_string(60,sstmp,LEFT);                         	
                        }    

	            	    strcpy(sstmp,refmtamt(ins_premium ,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    
	                    if (ori_damage_cover > 0){
                            sprintf(sstmp,"%ld����",qday);
                            rgu_put_body_string(60,sstmp,RIGHT); 	                    	
	                    }else{
                            strcpy(sstmp," 0���� �L");
                            rgu_put_body_string(60,sstmp,LEFT);                         	
                        } 
/*	                    
	            	    strcpy(sstmp,refmtamt(ori_damage_cover,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
*/	                    
	            	    strcpy(sstmp,refmtamt(ori_premium ,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	            	    
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body(60);
	                    put_line++;		
	                    
                    }else if(tins==27) {
		                rgu_put_body_string(60,ins_type,LEFT);
		                rgu_put_body_string(60,nins_type1,LEFT);
		                rgu_put_body_string(60," ",LEFT);
		                rgu_put_body_string(60,trim(ch_deduct),RIGHT);
		                strcpy(sstmp,refmtamt(ins_premium ,MILLIONTH));
		                rgu_put_body_string(60,sstmp,2);
		                rgu_put_body_string(60," ",LEFT);
		                strcpy(sstmp,refmtamt(ori_premium ,MILLIONTH));
		                rgu_put_body_string(60,sstmp,2);
		                rgu_put_body_string(60," ",LEFT);
		                rgu_put_body(60);
		                
		                
		                rgu_put_body_string(60," ",LEFT);
		                rgu_put_body_string(60,"�̰����I���O�I���B",LEFT);
		                strcpy(sstmp,refmtamt(damage_cover,MILLIONTH));
		                rgu_put_body_string(60,sstmp,2);
		                rgu_put_body_string(60," ",LEFT);
		                rgu_put_body_string(60," ",LEFT);
		                strcpy(sstmp,refmtamt(ori_damage_cover,MILLIONTH));
		                rgu_put_body_string(60,sstmp,2);
		                rgu_put_body_string(60," ",LEFT);
		                rgu_put_body_string(60," ",LEFT);
		                rgu_put_body(60);
		                
                        put_line++;		                 					                                                	
                    }else{                	
	                    rgu_put_body_string(60,ins_type,LEFT);
	                    rgu_put_body_string(60,nins_type1,LEFT);
	                
	                    strcpy(sstmp,refmtamt(damage_cover,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60,trim(ch_deduct),RIGHT);
	                    strcpy(sstmp,refmtamt(ins_premium ,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    
	                    strcpy(sstmp,refmtamt(ori_damage_cover,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	            	    strcpy(sstmp,refmtamt(ori_premium ,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	            	
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body(60);
	                    put_line++;
	                    	                   
	                    if(((tins== 1 || tins== 5 || tins== 8 || tins== 9)&& (qday_01 == 1)) ||
	                       ((tins==11) && (qday_11 == 1)))
	                    { 
	                        rgu_put_body_string(60," ",LEFT);
	                        rgu_put_body_string(60," ",LEFT);
	                        rgu_put_body_string(60," ",LEFT);
	                        rgu_put_body_string(60,"(�[��)",LEFT);
	                        rgu_put_body_string(60," ",LEFT);
	                        rgu_put_body_string(60," ",LEFT);
	                        rgu_put_body_string(60," ",LEFT);
	                        rgu_put_body_string(60," ",LEFT);
	                        rgu_put_body(60);
	                        put_line++;
	                    }
                    }
                }
                else if( qcoverage == 2 )
                {
                	tins = atoi(ins_type); 
                    if (tins== 56){ /* 950704 */
                    	    ins56_flag = 1;
		                    rgu_put_body_string(60,ins_type,LEFT);
		                    rgu_put_body_string(60,nins_type1,LEFT);
		                    rgu_put_body_string(60," ",LEFT);
		                    rgu_put_body_string(60,trim(ch_deduct),RIGHT);
		                    strcpy(sstmp,refmtamt(ins_premium ,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		                    rgu_put_body_string(60," ",LEFT);
		                    strcpy(sstmp,refmtamt(ori_premium ,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		                    rgu_put_body_string(60," ",LEFT);
		                    rgu_put_body(60);
		                    
		                    rgu_put_body_string(60," ",LEFT);
		                    rgu_put_body_string(60,"�ݼo�Φ��`�O�I��",LEFT);
		                    strcpy(sstmp,refmtamt(damage_cover,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		                    rgu_put_body_string(60," ",LEFT);
		                    rgu_put_body_string(60," ",LEFT);
		                    strcpy(sstmp,refmtamt(ori_damage_cover,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		                    rgu_put_body_string(60," ",LEFT);
		                    rgu_put_body_string(60," ",LEFT);
		                    rgu_put_body(60);
		                    
                            put_line = put_line+2;
                            
                            /* ���[���� */
					        sprintf(stmt, " SELECT FIRST 1 nvl(daily_pay,0),nvl(ori_daily_pay,0)  \
					                          FROM ca_pa_ply_302 \
					                         WHERE ipolicy = ? \
					                           AND iins_type = ? \
					                           AND iins_scope ='2'");
					        printf("pa_stmt[%s]\n", stmt );
					        $PREPARE prep_pa FROM $stmt;
					
					        $EXECUTE prep_pa INTO $lDaily_pay,$ori_lDaily_pay USING $last_policy, $ins_type;
					        
                            if ((SQLCODE != SQLNOTFOUND) && (lDaily_pay != 0) ){                             
			                    rgu_put_body_string(60," ",LEFT);
			                    rgu_put_body_string(60,"���|�������B",LEFT);
			                    strcpy(sstmp,refmtamt(lDaily_pay,MILLIONTH));
			                    rgu_put_body_string(60,sstmp,2);
			                    rgu_put_body_string(60," ",LEFT);
			                    rgu_put_body_string(60," ",LEFT);
			                    
			                    /*
			                    if (ori_damage_cover==0){
			                    	rgu_put_body_string(60,"0",2);
			                    }else{	
			                        strcpy(sstmp,refmtamt(lDaily_pay,MILLIONTH));
			                        rgu_put_body_string(60,sstmp,2);
			                    } */
		                        strcpy(sstmp,refmtamt(ori_lDaily_pay,MILLIONTH));
		                        rgu_put_body_string(60,sstmp,2); 
		                        
			                    rgu_put_body_string(60," ",LEFT);
			                    rgu_put_body_string(60," ",LEFT);
			                    rgu_put_body(60);			                    
			                    put_line = put_line+1;  			                      
			                }                                              	
							                                                	
                    }else{  
                    	 if (tins==57 || tins==59 || tins==60 ){
	                         rgu_put_body_string(60,ins_type,LEFT);
		                     rgu_put_body_string(60,nins_type1,LEFT);
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60,trim(ch_deduct),RIGHT);
		                     strcpy(sstmp,refmtamt(ins_premium ,MILLIONTH));
		                     rgu_put_body_string(60,sstmp,2);
		                     rgu_put_body_string(60," ",LEFT);
		                     strcpy(sstmp,refmtamt(ori_premium ,MILLIONTH));
		                     rgu_put_body_string(60,sstmp,2);	            	    
		                     rgu_put_body_string(60," ",LEFT); 
		                     rgu_put_body(60);	                    		                     
		                     
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60,"  �C�@�ӤH�ݼo�Φ��`",LEFT);
		                     strcpy(sstmp,refmtamt(death_cover,MILLIONTH));
		                     rgu_put_body_string(60,sstmp,2);
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60," ",LEFT);
		                     strcpy(sstmp,refmtamt(ori_death_cover,MILLIONTH));
		                     rgu_put_body_string(60,sstmp,2);
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60,trim(LHsNname),LEFT);  /* �~�N�W��*/
		                     rgu_put_body(60);
		                    		                    		                     
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60,"  �C�@�ƬG�`�B",LEFT);
		                     strcpy(sstmp,refmtamt(damage_cover,MILLIONTH));
		                     rgu_put_body_string(60,sstmp,2);
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60," ",LEFT);
		                     strcpy(sstmp,refmtamt(ori_damage_cover,MILLIONTH));
		                     rgu_put_body_string(60,sstmp,2);
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body(60);      
		                     
		                     put_line = put_line+3;   
		                }else if (tins==85) {
		                    rgu_put_body_string(60,ins_type,LEFT);
		                    rgu_put_body_string(60,nins_type1,LEFT);
		                
		                    strcpy(sstmp,refmtamt(damage_cover,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		                    rgu_put_body_string(60,trim(ch_deduct),RIGHT);
		            	    strcpy(sstmp,refmtamt(ins_premium ,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		                    
		            	    strcpy(sstmp,refmtamt(ori_damage_cover,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		            	    strcpy(sstmp,refmtamt(ori_premium ,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		            	    
		                    rgu_put_body_string(60," ",LEFT);  /* �~�N�N�X*/
		                    rgu_put_body(60);
		                    put_line++;
		                    
		                    /*�������l�֭p���v���B*/
		                    rgu_put_body_string(60," ",LEFT);
		                    rgu_put_body_string(60,"�������l�֭p���v���B",LEFT);
		                
		                    strcpy(sstmp,refmtamt(injured_cover,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		                    rgu_put_body_string(60," ",RIGHT);
		                    rgu_put_body_string(60," ",RIGHT);
		                    
		            	    strcpy(sstmp,refmtamt(ori_injured_cover,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		                    rgu_put_body_string(60," ",RIGHT);		            	    
		                    rgu_put_body_string(60,trim(LHsNname),LEFT);  /* �~�N�W��*/
		                    rgu_put_body(60);
	                        put_line++;
	                    }else if (tins==52 || tins==53 || tins==55 ){     /* 100.04.01 */
	                         rgu_put_body_string(60,ins_type,LEFT);
		                     rgu_put_body_string(60,nins_type1,LEFT);
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60,trim(ch_deduct),RIGHT);
		                     strcpy(sstmp,refmtamt(ins_premium ,MILLIONTH));
		                     rgu_put_body_string(60,sstmp,2);
		                     rgu_put_body_string(60," ",LEFT);
		                     strcpy(sstmp,refmtamt(ori_premium ,MILLIONTH));
		                     rgu_put_body_string(60,sstmp,2);	            	    
		                     rgu_put_body_string(60," ",LEFT); 
		                     rgu_put_body(60);	                    		                     
		                     
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60,"  �C�@�ӤH�ˮ`",LEFT);
		                     strcpy(sstmp,refmtamt(death_cover,MILLIONTH));
		                     rgu_put_body_string(60,sstmp,2);
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60," ",LEFT);
		                     strcpy(sstmp,refmtamt(ori_death_cover,MILLIONTH));
		                     rgu_put_body_string(60,sstmp,2);
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60,trim(LHsNname),LEFT);  /* �~�N�W��*/
		                     rgu_put_body(60);
		                    		                    		                     
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60,"  �C�@�N�~�ƬG���ˮ`",LEFT);
		                     strcpy(sstmp,refmtamt(damage_cover,MILLIONTH));
		                     rgu_put_body_string(60,sstmp,2);
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60," ",LEFT);
		                     strcpy(sstmp,refmtamt(ori_damage_cover,MILLIONTH));
		                     rgu_put_body_string(60,sstmp,2);
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body(60);      
		                     
		                     put_line = put_line+3;   	  
	                    }else if (tins==62 || tins==63 || tins==64 ){     /* 100.04.01 */
	                         rgu_put_body_string(60,ins_type,LEFT);
		                     rgu_put_body_string(60,nins_type1,LEFT);
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60,trim(ch_deduct),RIGHT);
		                     strcpy(sstmp,refmtamt(ins_premium ,MILLIONTH));
		                     rgu_put_body_string(60,sstmp,2);
		                     rgu_put_body_string(60," ",LEFT);
		                     strcpy(sstmp,refmtamt(ori_premium ,MILLIONTH));
		                     rgu_put_body_string(60,sstmp,2);	            	    
		                     rgu_put_body_string(60," ",LEFT); 
		                     rgu_put_body(60);	                    		                     
		                     
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60,"  �C�@���B",LEFT);
		                     strcpy(sstmp,refmtamt(injured_cover,MILLIONTH));
		                     rgu_put_body_string(60,sstmp,2);
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60," ",LEFT);
		                     strcpy(sstmp,refmtamt(ori_injured_cover,MILLIONTH));
		                     rgu_put_body_string(60,sstmp,2);
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60,trim(LHsNname),LEFT);  /* �~�N�W��*/
		                     rgu_put_body(60);
		                    		                    		                     
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60,"  �C�@�ƬG�`�B",LEFT);
		                     strcpy(sstmp,refmtamt(damage_cover,MILLIONTH));
		                     rgu_put_body_string(60,sstmp,2);
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60," ",LEFT);
		                     strcpy(sstmp,refmtamt(ori_damage_cover,MILLIONTH));
		                     rgu_put_body_string(60,sstmp,2);
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body_string(60," ",LEFT);
		                     rgu_put_body(60);      
		                     
		                     put_line = put_line+3;  		                                       	   	                                	
                    	}else{                	
		                    rgu_put_body_string(60,ins_type,LEFT);
		                    if (tins== 34){ /* 960612, ���ݪ��I34 */   
		                        strcpy(ncover_name1,"(");
		                        strcpy(ncover_name2,"�ƬG�O�B��");
		                        strcpy(nins_type1,trim(nins_type1));
		                        strcat(nins_type1,ncover_name1);
		                        
		                        strcpy(ch_deduct_tmp,"�G��)");
		                        sprintf(ch_deduct,"%s�@%s",ch_deduct_tmp,trim(ch_deduct));
		                    }else{
		                    	strcpy(ncover_name2," ");
		                    }    
		                       
		                    rgu_put_body_string(60,nins_type1,LEFT);
		                    /*rgu_put_body_string(60," ",LEFT);*/
		                    rgu_put_body_string(60,ncover_name2,LEFT);
		                    
		                    /*rgu_put_body_string(60,trim(ch_deduct),RIGHT);*/
		                    if (tins== 34){
		                        rgu_put_body_string(60,trim(ch_deduct),LEFT);
		                    }else{    
		                        rgu_put_body_string(60,trim(ch_deduct),RIGHT);
		                    }    
		                    strcpy(sstmp,refmtamt(ins_premium ,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		                    rgu_put_body_string(60," ",LEFT);
		                    strcpy(sstmp,refmtamt(ori_premium ,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		                    rgu_put_body_string(60," ",LEFT);
		                    rgu_put_body(60);
		                    
		                    rgu_put_body_string(60," ",LEFT);
		                    if (tins== 34){ /* 960612, ���ݪ��I34 */
		                    	rgu_put_body_string(60,"  �C�@�ӤH���|",LEFT);
		                    }else{	
		                        rgu_put_body_string(60,"  �C�@�ӤH�ˮ`",LEFT);
		                    }                      
		                    strcpy(sstmp,refmtamt(injured_cover,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		                    rgu_put_body_string(60," ",LEFT);
		                    rgu_put_body_string(60," ",LEFT);
		                    strcpy(sstmp,refmtamt(ori_injured_cover,MILLIONTH));
		                    rgu_put_body_string(60,sstmp,2);
		                    rgu_put_body_string(60," ",LEFT);
		                    rgu_put_body_string(60," ",LEFT);
		                    rgu_put_body(60);
		                    
		                    rgu_put_body_string(60," ",LEFT);
		                    if (tins== 34){ /* 960612, ���ݪ��I34 */
		                    	rgu_put_body_string(60,"  �C�@�ӤH���G",LEFT);
			                    strcpy(sstmp,refmtamt(death_cover,MILLIONTH));
			                    rgu_put_body_string(60,sstmp,2);
			                    rgu_put_body_string(60," ",LEFT);
			                    rgu_put_body_string(60," ",LEFT);
			                    strcpy(sstmp,refmtamt(ori_death_cover,MILLIONTH));                      	
		                    }else{	
		                        rgu_put_body_string(60,"  �C�@�ƬG�`�B",LEFT);
			                    strcpy(sstmp,refmtamt(damage_cover,MILLIONTH));
			                    rgu_put_body_string(60,sstmp,2);
			                    rgu_put_body_string(60," ",LEFT);
			                    rgu_put_body_string(60," ",LEFT);
			                    strcpy(sstmp,refmtamt(ori_damage_cover,MILLIONTH));                       
		                    } 
		                    rgu_put_body_string(60,sstmp,2);
		                    rgu_put_body_string(60," ",LEFT);
		                    rgu_put_body_string(60," ",LEFT);
		                    rgu_put_body(60);
		                    put_line = put_line+3;
		                }        
		            }      
                }
                else if( qcoverage == 3 )
                {
                	tins = atoi(ins_type); 
                    if (tins== 50){
                        ins50_flag = 1;
	                    rgu_put_body_string(60,ins_type,LEFT);
	                    rgu_put_body_string(60,nins_type1,LEFT);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60,trim(ch_deduct),RIGHT);
	                    strcpy(sstmp,refmtamt(ins_premium ,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60," ",LEFT);
	                    strcpy(sstmp,refmtamt(ori_premium ,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body(60);
	                   
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60,"�ݼo�Φ��`�O�I��",LEFT);
	                    strcpy(sstmp,refmtamt(death_cover,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60," ",LEFT);
	                    strcpy(sstmp,refmtamt(ori_death_cover,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body(60);
	                    
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60,"  �ˮ`�����O�I��",LEFT);
	                    strcpy(sstmp,refmtamt(injured_cover,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60," ",LEFT);
	                    strcpy(sstmp,refmtamt(ori_injured_cover,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body(60);
	                    
                        put_line = put_line+3;
                    }else{	                    	
	                    rgu_put_body_string(60,ins_type,LEFT);
	                    rgu_put_body_string(60,nins_type1,LEFT);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60,trim(ch_deduct),RIGHT);
	                    strcpy(sstmp,refmtamt(ins_premium ,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60," ",LEFT);
	                    strcpy(sstmp,refmtamt(ori_premium ,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body(60);
	                    
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60,"  �C�@�ӤH���",LEFT);
	                    strcpy(sstmp,refmtamt(injured_cover,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60," ",LEFT);
	                    strcpy(sstmp,refmtamt(ori_injured_cover,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body(60);
	                   
	                    rgu_put_body_string(60," ",LEFT);
                        if (tins== 57||tins== 59||tins== 60){ 
	                        rgu_put_body_string(60,"  �C�@�ӤH���`�δݼo",LEFT);
	                    }else{
	                    	rgu_put_body_string(60,"  �C�@�ӤH���`",LEFT); 
	                    }	                    	                    
	                    strcpy(sstmp,refmtamt(death_cover,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60," ",LEFT);
	                    strcpy(sstmp,refmtamt(ori_death_cover,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body(60);
	                 
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60,"  �C�@�ƬG�`�B",LEFT);
	                    strcpy(sstmp,refmtamt(damage_cover,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60," ",LEFT);
	                    strcpy(sstmp,refmtamt(ori_damage_cover,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body(60);
	                    put_line = put_line+4;
                    }
                }
	            /* insurance_type=34 �� qcoverage��2 ,���O ply_ins_type_302 34�I �� qcoverage��4 */
				/* �ҥH����34�G�䳣�� */	                
                else if( qcoverage == 4 )
                {
                	tins = atoi(ins_type);                     
                    	                	
                    rgu_put_body_string(60,ins_type,LEFT);
                    if (tins== 34){ /* 960612, ���ݪ��I34 */   
                        strcpy(ncover_name1,"(");
                        strcpy(ncover_name2,"�ƬG�O�B��");
                        strcpy(nins_type1,trim(nins_type1));
                        strcat(nins_type1,ncover_name1);
                        
                        strcpy(ch_deduct_tmp,"�G��)");
                        sprintf(ch_deduct,"%s�@%s",ch_deduct_tmp,trim(ch_deduct));
                        
                    }else{
                    	strcpy(ncover_name2," ");
                    }    
                       
                    rgu_put_body_string(60,nins_type1,LEFT);
                    /*rgu_put_body_string(60," ",LEFT);*/
                    rgu_put_body_string(60,ncover_name2,LEFT);                  
                    if (tins== 34){
                        rgu_put_body_string(60,trim(ch_deduct),LEFT);
                    }else{    
                        rgu_put_body_string(60,trim(ch_deduct),RIGHT);
                    }  
                    strcpy(sstmp,refmtamt(ins_premium ,MILLIONTH));
                    rgu_put_body_string(60,sstmp,2);
                    rgu_put_body_string(60," ",LEFT);
                    strcpy(sstmp,refmtamt(ori_premium ,MILLIONTH));
                    rgu_put_body_string(60,sstmp,2);
                    rgu_put_body_string(60," ",LEFT);
                    rgu_put_body(60);
                    
                    rgu_put_body_string(60," ",LEFT);
                    if (tins== 34){ /* 960612, ���ݪ��I34 */
                    	rgu_put_body_string(60,"  �C�@�ӤH���|",LEFT);
                    }else{	
                        rgu_put_body_string(60,"  �C�@�ӤH�ˮ`",LEFT);
                    }   
                    strcpy(sstmp,refmtamt(injured_cover,MILLIONTH));
                    rgu_put_body_string(60,sstmp,2);
                    rgu_put_body_string(60," ",LEFT);
                    rgu_put_body_string(60," ",LEFT);
                    strcpy(sstmp,refmtamt(ori_injured_cover,MILLIONTH));
                    rgu_put_body_string(60,sstmp,2);
                    rgu_put_body_string(60," ",LEFT);
                    rgu_put_body_string(60," ",LEFT);
                    rgu_put_body(60);
                    
                    rgu_put_body_string(60," ",LEFT);
                    if (tins== 34){ /* 960612, ���ݪ��I34 */
                    	rgu_put_body_string(60,"  �C�@�ӤH���G",LEFT);
	                    strcpy(sstmp,refmtamt(death_cover,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60," ",LEFT);
	                    strcpy(sstmp,refmtamt(ori_death_cover,MILLIONTH));                      	
                    }else{	
                        rgu_put_body_string(60,"  �C�@�ƬG�`�B",LEFT);
	                    strcpy(sstmp,refmtamt(damage_cover,MILLIONTH));
	                    rgu_put_body_string(60,sstmp,2);
	                    rgu_put_body_string(60," ",LEFT);
	                    rgu_put_body_string(60," ",LEFT);
	                    strcpy(sstmp,refmtamt(ori_damage_cover,MILLIONTH));                       
                    }                                        

                    rgu_put_body_string(60,sstmp,2);
                    rgu_put_body_string(60," ",LEFT);
                    rgu_put_body_string(60," ",LEFT);
                    rgu_put_body(60);
                    put_line = put_line+3;                	
                }             
                qserial_bak = qserial / 10;
            }    
            
            ptr=ptr->next;
        }/**end while **/
        
        /* 101.01.31 �����C�L�W�U */
        /* 950704 */
/*        
        if (ins56_flag==1 || ins50_flag==1){
        	if (put_line<=24){
	             * 970822,�����ɼW�[�@���Q�O�I�H�W�U *
	      	     strcpy(iinsurant_pa, " ");
	      	     strcpy(ninsurant_pa, " ");
	      	     strcpy(ibirth_pa, " ");
	      	     strcpy(nbenif_pa, " ");
	      	     strcpy(irel_pa, " ");                       
                  
                 * 50�I�ة|���s�W�Q�O�I�H�W�U,�ҥH�|�O�Ū��]SQLNOTFOUND�^ * 
	             $EXECUTE prePa_list INTO $ninsurant_pa, $iinsurant_pa, $ibirth_pa, $nbenif_pa, $irel_pa 
	                USING $last_policy;
		         if((SQLCODE == SQLNOTFOUND)||(iinsurant_pa[0]==' ')||(iinsurant_pa[0]=='\0')){
		        	   strcpy(ninsurant_pa, "        ");
		        	   strcpy(iinsurant_pa, "          ");
		        	   strcpy(ibirth_pa, "       ");
		        	   strcpy(nbenif_pa, "           ");
		        	   strcpy(irel_pa, "            ");
		         }else{ 
	                 cm_split_ymd(ibirth_pa, mm_pa, dd_pa, yyyy_pa);
	                 cy_pa = atoi(yyyy_pa)-1911;
	                 sprintf(ibirth_pa,"%d%s%s",cy_pa,mm_pa, dd_pa);
	                 strcpy(ninsurant_pa,rtrim(ninsurant_pa));
	                 strcpy(iinsurant_pa,rtrim(iinsurant_pa));
	                 strcpy(ibirth_pa,rtrim(ibirth_pa));
	                 strcpy(nbenif_pa,rtrim(nbenif_pa));
	                 strcpy(irel_pa,rtrim(irel_pa));
	                 strncpy(iinsurant_pa+(3),"****",4);
		         }	         
	               		
        		if (put_line!=24){ *���h�l�Ŷ��N�Ť@��*
		           rgu_put_body_string(67," ",LEFT);     
		           rgu_put_body(67);      
		           put_line = put_line+1;  
		        }   
		        sprintf(sstmp1,"*��O�T���r�p�H�ˮ`�I��,�ФĿ� ���O:�r�p�H�P�Q�O�I�H ���_:�ж�g:�m�W:%s",ninsurant_pa );
		        rgu_put_body_string(67,rtrim(sstmp1),LEFT);		        
		        rgu_put_body(67);
		        if (ins56_flag==1){
		            sprintf(sstmp1,"��������:%s �X�ͤ��:%s ���q�H:%s ���Y:%s �Q�O�I�H��ñ:",iinsurant_pa,ibirth_pa,nbenif_pa,irel_pa );
		            rgu_put_body_string(67,rtrim(sstmp1),LEFT);
		        }else{        
		            rgu_put_body_string(67,"��������:        �X�ͤ��:      ���q�H:        ���Y:    �Q�O�I�H��ñ:",LEFT);
		        }
		        rgu_put_body(67);        
		        put_line = put_line+2;
			    
	        }
        }     
*/
        /*980522,�j��s����T�� */
        if (remark5_12[0]=='a' && (remark5_12[1]=='2'||remark5_12[1]=='3')){
	        rgu_put_body_string(67,"�� �s�v�I�w���]�t�j���I�ӫO�d��",LEFT);  
	        rgu_put_body(67);
	        put_line = put_line+1;
        }
        			                         
        printf("put_line=[%d]\n", put_line); 
 
        for(i=put_line+1;i<=26;i++)
            rgu_put_body(1);
    }
    max_count+=26;
    
    return 1;

ca30xf1_2_err:
    printf("ca30xf1_2_err....\n");
    printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;    
}

/* �T���O�I�n�O��--�j��αq�H�]�� **********************************/
int CA301XF1_3(db, fbigcomp)
char *db, *fbigcomp;
{
    int     i,code, comm_line;
    char    datestr[16], ch1[10], ch2[10], ch3[10];
    char    yy1[4], mm1[3], dd1[3], yy2[4], mm2[3], dd2[3];
    char    str1[32],str2[6],tmp_rmk[91];
    $char   last_ply2[18];
    $long   qdmg_1[3],qlia_1[3];
    $long   mdmg_1[3],mlia_1[3];
    $long   qlia_acc_1,qdmg_acc_1;
    $double pdmg_acc_1,t_plia_acc_1;
    $long   qdmg_2[3],qlia_2[3];
    $long   id;
    $long   qlia_acc_2,qdmg_acc_2,com_prem;
    $double t_pdmg_acc_2,t_plia_acc_2;
    $int    pre_year;
    char    fyear1[3],fyear2[3];
    $char   pre_ply[3][20],inumber[21],pre_relative[20],xxcard[15];
    $char   tmp[11];
    long    tot_premium, ori_tot_premium;
    $date   dat_begin;
    double  acc_tmp;
    $char   c_acc_tmp[11];
    $int    iseq_tmp;
    $char   dclaim_tmp[11],dprocess_tmp[11],drescue_tmp[11];
    $char   qday_tmp[5];
    $char   tmp_buf[60], sTmp[51], sTmp1[21], tmp_ileader[11], iquota_tel[21], iquota_fax[21];
    $char   nofficer[11];
    $char  ioff_corps[11],ibroker[11],nbroker[13];
    $char  FullDBName[21],tmp_db[3];    
     
    $WHENEVER SQLERROR GOTO ca302F1_3_err;

    printf(">>>> into ca302F1_3()\n");

    rgu_put_body(1);
    max_count+=1;
    
    sprintf(stmt, " SELECT nname \
                       FROM officer \
                      WHERE iofficer = ?");

    $PREPARE get_nofficer FROM $stmt;

    /* 100.05,�q���N���ĤG���q */   
    /*    
    sprintf( stmt, "SELECT icar_broker \
                      FROM officer_broker \
                     WHERE iofficer = ? ");
    $PREPARE prep_ibroker FROM $stmt; 
                          
    sprintf( stmt, "SELECT nchi_abv \
                      FROM broker_agent \
                     WHERE ibroker = ?");
    $PREPARE prep_nbroker FROM $stmt;     
    */    
    strcpy(tmp,refmtamt(premium2 ,MILLIONTH));
    rgu_put_body_string(17,tmp,RIGHT);
    strcpy(tmp,refmtamt(premium3 ,MILLIONTH));
    rgu_put_body_string(17,tmp,RIGHT);
    rgu_put_body(17); /* �`�O�O */ 
    max_count+=1;
    
    tot_premium = premium1 + premium2;
    ori_tot_premium = premium1 + premium3;
    printf("----- tot_premium=[%d] \n",tot_premium);
    printf("----- ori_tot_premium=[%d] \n",ori_tot_premium);
    rgu_put_body(1);
    max_count+=1;

    printf("\n--------------------\n");

    /*----�j��ĤT�H�d���I----*/
    /**remark 0������� 1���w��O 2������O 3���j����N���P�~�Ȩӷ�******/
    if (fcard_class[0]=='2' &&
        remark[0]!=' ' && remark[0]!='\0')
    {
        printf("remark[%s]\n", remark);

        if ( remark[0] == '0')
        {
             printf("note1[%s] ply1_begin[%d]\n",note1, ply1_begin);

             $SELECT icar_type, ichange_note
                INTO $icar_type_comp, $ichange_note
                FROM policy_302
               WHERE ipolicy=$irelative_ply;
                            
             rgu_put_body_string(18,note1,LEFT);
             strcpy(datestr,cm_cdate_str_100(ply1_begin));
             cm_split_ymd_100(datestr,yy1,mm1,dd1);
             rgu_put_body_string(18,yy1,LEFT);
             rgu_put_body_string(18,mm1,LEFT);
             rgu_put_body_string(18,dd1,LEFT); /* �j��O�I����(�_) */
             rgu_put_body(18); 
             /* 970411
             if( strcmp( icar_type_comp, icar_type_ori) != 0 && (strlen(trim(icar_type_ori)) > 0 ))
                 sprintf( tmp, "(%s->%s)", icar_type_ori, icar_type_comp);
             else  
                 strcpy( tmp, " ");*/
             strcpy(ichange_note, trim(ichange_note));    
             printf("ichange_note=[%s]\n",ichange_note);             
             rgu_put_body_string(19,ichange_note,LEFT);
             printf("ply1_end[%d] ",ply1_end);
             strcpy(datestr,cm_cdate_str_100(ply1_end));
             cm_split_ymd_100(datestr,yy2,mm2,dd2);       printf("yy2[%s] mm2[%s] dd2[%s]\n", yy2, mm2, dd2 );
             rgu_put_body_string(19,yy2,LEFT);
             rgu_put_body_string(19,mm2,LEFT);
             rgu_put_body_string(19,dd2,LEFT);
             strcpy(tmp,refmtamt(premium1,MILLIONTH));
             rgu_put_body_string(19,tmp,RIGHT);
             rgu_put_body(19); /* �j��O�I����(��) */
             max_count   +=   2;
        }
        else if ( remark[0] == '2')
        {
             printf("in remark 2\n");
 
             $SELECT dply_bgn_comp,dply_end_comp, icar_type, ichange_note
                INTO  $ply1_begin,$ply1_end,$icar_type_comp,$ichange_note
                FROM policy_302
               WHERE ipolicy=$irelative_ply;
               
             rgu_put_body_string(18,note1,LEFT);
             strcpy(datestr,cm_cdate_str_100(ply1_begin));
             cm_split_ymd_100(datestr,yy1,mm1,dd1);
             rgu_put_body_string(18,yy1,LEFT);
             rgu_put_body_string(18,mm1,LEFT);
             rgu_put_body_string(18,dd1,LEFT);
             rgu_put_body(18); /* �j��O�I����(�_) */
             /* 970411
             if( strcmp( icar_type_comp, icar_type_ori) != 0 && (strlen(trim(icar_type_ori)) > 0 ))
                 sprintf( tmp, "(%s->%s)", icar_type_ori, icar_type_comp);
             else  
                 strcpy( tmp, " ");*/
             strcpy(ichange_note, trim(ichange_note));    
             printf("ichange_note=[%s]\n",ichange_note);               
             rgu_put_body_string(19,ichange_note,LEFT);

             strcpy(datestr,cm_cdate_str_100(ply1_end));
             cm_split_ymd_100(datestr,yy2,mm2,dd2);
             rgu_put_body_string(19,yy2,LEFT);
             rgu_put_body_string(19,mm2,LEFT);
             rgu_put_body_string(19,dd2,LEFT);
             rgu_put_body_string(19," ",LEFT);
             rgu_put_body(19); /* �j��O�I����(�_) */
             max_count   +=   2;
        }
        else
        {
             printf("in else\n");

             rgu_put_body(1);
             rgu_put_body(1);
             max_count   +=   2;
        }   
    }
    else
    {
       
        if (ply1_begin!=DATENULL) {
            rgu_put_body_string(18," ",LEFT);
            strcpy(datestr,cm_cdate_str_100(ply1_begin));
            cm_split_ymd_100(datestr,yy1,mm1,dd1);
            rgu_put_body_string(18,yy1,LEFT);
            rgu_put_body_string(18,mm1,LEFT);
            rgu_put_body_string(18,dd1,LEFT);
        } else if (bef_ply1_begin!=DATENULL) {
            strcpy(datestr,cm_cdate_str_100(bef_ply1_begin));
            cm_split_ymd_100(datestr,yy1,mm1,dd1);
            rgu_put_body_string(18," ",LEFT);
            rgu_put_body_string(18,yy1,LEFT);
            rgu_put_body_string(18,mm1,LEFT);
            rgu_put_body_string(18,dd1,LEFT);
        } else {
            rgu_put_body_string(18," ",LEFT);
            rgu_put_body_string(18," ",LEFT);
            rgu_put_body_string(18," ",LEFT);
            rgu_put_body_string(18," ",LEFT);
        }
        rgu_put_body(18); /* �j��O�I����(�_) */
        max_count++;
         
         
         if (fcard_class[0]=='1'){ 
         	
         	/* 970411
	        if( strcmp( car_typei, icar_type_ori) != 0 && (strlen(trim(icar_type_ori)) > 0 ))
	            sprintf( tmp, "(%s->%s)", icar_type_ori, car_typei);
	        else  
	            strcpy( tmp, " ");                 
	        */    
         }else{ 
         	 /* 951212�ץ�,Case : fcard_class[0]=='2' ,�B remark[0]=' ' */   		            
             $SELECT icar_type, ichange_note
                INTO $icar_type_comp, $ichange_note
                FROM policy_302
               WHERE ipolicy=$irelative_ply;
             /*  970411
             if( strcmp( icar_type_comp, icar_type_ori) != 0 && (strlen(trim(icar_type_ori)) > 0 ))
                 sprintf( tmp, "(%s->%s)", icar_type_ori, icar_type_comp);
             else  
                 strcpy( tmp, " "); 
             */    
         }
         strcpy(ichange_note, trim(ichange_note));
         printf("2_ichange_note=[%s]\n",ichange_note); 
             
        if (ply1_end!=DATENULL) {
            rgu_put_body_string(19,ichange_note,LEFT);
            strcpy(datestr,cm_cdate_str_100(ply1_end));
            cm_split_ymd_100(datestr,yy2,mm2,dd2);
            rgu_put_body_string(19,yy2,LEFT);
            rgu_put_body_string(19,mm2,LEFT);
            rgu_put_body_string(19,dd2,LEFT);
        } else if (bef_ply1_end!=DATENULL) {
            rgu_put_body_string(19,ichange_note,LEFT);
            strcpy(datestr,cm_cdate_str_100(bef_ply1_end));
            cm_split_ymd_100(datestr,yy2,mm2,dd2);
            rgu_put_body_string(19,yy2,LEFT);
            rgu_put_body_string(19,mm2,LEFT);
            rgu_put_body_string(19,dd2,LEFT);
        } else {
            rgu_put_body_string(19," ",LEFT);
            rgu_put_body_string(19," ",LEFT);
            rgu_put_body_string(19," ",LEFT);
            rgu_put_body_string(19," ",LEFT);
        }
        rfmtlong(premium1,"--,---,--&",ch2);
        rgu_put_body_string(19,ch2,LEFT);
        rgu_put_body(19); /* �j��O�I����(��) */
        max_count++;

    }
    rgu_put_body(1);
    max_count++;
   
    printf("\n---------------\n\n");
 
    /* �`�O�I�O*/
    strcpy(tmp,refmtamt(tot_premium ,MILLIONTH));
    rgu_put_body_string(16,tmp,RIGHT);
    strcpy(tmp,refmtamt(ori_tot_premium ,MILLIONTH));
    rgu_put_body_string(16,tmp,RIGHT);
    rgu_put_body(16); /* �`�O�O */ 
    max_count++;
    
    /*--- �O��q�T�M�� ---*/
    printf("full - remark1[%s]\n",remark1);
    
    /*
    1. ���׶W�L90�Ӧr�A�L�T��
    
    */
    /*
    if( (strlen(trim(remark1)) > 180 ) || ((strlen(trim(remark6)) > 0)||(strlen(trim(remark7)) > 0)) )
    */
    if(strlen(trim(remark1)) > 180 )
    {
        /*
    	memset(tmp_rmk, 0x00, sizeof(tmp_rmk));
        strcpy(tmp_rmk,substring(remark1,1,100));
        rgu_put_body_string(88,tmp_rmk,LEFT);
        printf("1_tmp_rmk[%s]\n",tmp_rmk);
        rgu_put_body(88);
        strcpy(tmp_rmk,substring(remark1,101,100));
        rgu_put_body_string(88,tmp_rmk,LEFT);
        printf("2_tmp_rmk[%s]\n",tmp_rmk);
        rgu_put_body(88);
        strcpy(tmp_rmk,substring(remark1,201,100));
        rgu_put_body_string(88,tmp_rmk,LEFT);
        printf("2_tmp_rmk[%s]\n",tmp_rmk);
        rgu_put_body(88);
    	rgu_put_body(1);
        */
        rgu_put_body_string(88,remark1_ori,LEFT);
        rgu_put_body(88);
        rgu_put_body_string(88,remark2,LEFT);
        rgu_put_body(88);
        rgu_put_body_string(88,remark6,LEFT);
        rgu_put_body(88);
        rgu_put_body_string(88,remark7,LEFT);
        rgu_put_body(88);
    }
    else 
    {
    	comm_line=0;
    	if (strlen(trim(remark1)) != 0)
        {
            memset(tmp_rmk, 0x00, sizeof(tmp_rmk));
            strcpy(tmp_rmk,substring(remark1,1,90));
            rgu_put_body_string(88,tmp_rmk,LEFT);
            printf("1_tmp_rmk[%s]\n",tmp_rmk);
            rgu_put_body(88);
            strcpy(tmp_rmk,substring(remark1,91,90));
            rgu_put_body_string(88,tmp_rmk,LEFT);
            printf("2_tmp_rmk[%s]\n",tmp_rmk);
            rgu_put_body(88);
            comm_line += 2;
        }
        /** 950621 **/
        if (strlen(trim(remark6)) > 0)
        {
	        rgu_put_body_string(88,remark6,LEFT);
	        printf("remark6[%s]\n",remark6);
	        rgu_put_body(88);
	        comm_line += 1;	        
	    }    
	    if (strlen(trim(remark7)) > 0)
	    {
	        rgu_put_body_string(88,remark7,LEFT);
	        printf("remark7[%s]\n",remark7);
	        rgu_put_body(88);  
	        comm_line += 1;          	
        }
    	if (strlen(trim(remark4)) != 0)
        {
            memset(tmp_rmk, 0x00, sizeof(tmp_rmk));
            strcpy(tmp_rmk,substring(remark4,1,90));
            rgu_put_body_string(88,tmp_rmk,LEFT);
            printf("1_tmp_rmk[%s]\n",tmp_rmk);
            rgu_put_body(88);
            strcpy(tmp_rmk,substring(remark4,91,90));
            rgu_put_body_string(88,tmp_rmk,LEFT);
            printf("2_tmp_rmk[%s]\n",tmp_rmk);
            rgu_put_body(88);
            comm_line += 2;
        }
        
          /* 101.08.24 */        	 	
          if (comm_line>=5) comm_line=4;
          for( i=0; i<4-comm_line; i++ )           
              rgu_put_body(1);
              
          rgu_put_body(89);
          rgu_put_body(1);
    }
    
    if(tagnum[0]==' ' || tagnum[0]=='\0') strcpy(inumber,engine);
    else strcpy(inumber,tagnum);

    /*************�j��***************/
    printf("ca_acc-->inumber[%s]\n",trim(inumber));
    strcpy(inumber,trim(inumber));
    printf("----> frate[%s] \n", frate );

/*  990820  
    code=ca_accident_record_next(db,inumber,ply1_begin,"1",
                                 qdmg_1,qlia_1,mdmg_1,mlia_1,&qdmg_acc_1,&qlia_acc_1,
                                 &pdmg_acc_1,&t_plia_acc_1,fyear1,"",lia_class,bqdmg,dply_begin,frate,last_ply);
    if(code!=M_CM_OK) return code;
    printf("�j��ca_rpt_renew1---qlia_acc_1-->[%ld]\n",qlia_acc_1);
*/
     /*990820*/
     strcpy(fedr_class," ") ;
     rtoday(&Today);
      
     strcpy(tmp_db,get_car_full_db(last_ply));                                  
     strcpy(FullDBName , trim(get_full_dbname(tmp_db)));
     printf("FullDBName[%s]\n" , FullDBName);  
	 sprintf(stmt,
	        "SELECT fedr_class FROM %s:ply_relation \
	          WHERE ipolicy = '%s'",
		    FullDBName,last_ply); 		    
	  $PREPARE get_edr FROM $stmt;             	    	 	  
	  $EXECUTE get_edr INTO $fedr_class;	  		   
	  
    printf("Trace -- fedr_class = [%s] \n",  fedr_class);	  
    printf("Trace -- Today = [%ld] \n",  Today);
      
    /***********���N*****************/
    /* 9912,�ߴګY�Ƨ�����T */
    /*
    code=ca_accident_record_next(db,inumber,ply2_begin,"2",qdmg_2,qlia_2,&qdmg_acc_2,&qlia_acc_2,                                 
                                 &t_pdmg_acc_2,&t_plia_acc_2,fyear2,"",lia_class,bqdmg,frate,last_ply,
                                 sFassured,fedr_class,Today);
    if(code!=M_CM_OK) return code;
    */   
    /*****Ū���e��~�O��ܰ}�C********/

    for (pre_year=0; pre_year < 2 ; pre_year++)
    {
        printf("read pre_policy--cnt[%d],inumber[%s]\n",pre_year,inumber);
        pre_ply[pre_year][0] = '\0';
        /*pre_comp[pre_year][0] = '\0';*/
        printf("pre_ply_ipolicy-----[%s]\n",pre_ply[pre_year]);
        $DECLARE ply_cur CURSOR FOR
          SELECT ipolicy
            FROM ca_ply_period
           WHERE inumber=$inumber
             AND YEAR(dply_bgn)=(YEAR($dply_begin)-($pre_year+1));
        $OPEN ply_cur;
       
        while(1)
        {
            printf("fetch-------cnt[%d]\n",pre_year);
            $FETCH ply_cur into $pre_ply[pre_year];
            if (SQLCODE == SQLNOTFOUND)
                 break;

            printf("inumber [%s]\n",inumber);
            printf("pre_ply[%d]=[%s]\n",pre_year,pre_ply[pre_year]);
/*
            $SELECT NVL(irel_card,' ')
               INTO $pre_comp[pre_year]
               FROM policy_302
              WHERE ipolicy = $pre_ply[pre_year];
            printf("Fetched AAAAAAAAAAAAAA   irel_card[%s]\n",pre_comp[pre_year]);
*/            
        }
        $CLOSE ply_cur;
        $FREE  ply_cur;
    }
    /************************************************/
    /* �q�H�]���ߴګY�� */

    rstrdate("09/01/2001",&dat_begin);
    printf("dat_begin[%ld]\n",dat_begin);
    printf("dply_begin[%ld]\n",dply_begin);

    if (dply_begin >= dat_begin){
        new_rate = 'Y';
    }else{
        new_rate = 'N';
    }
    /*  950621  */ 
    /*rgu_put_body(1);*/  /* line 1 */
    /*rgu_put_body(1);*/  /* line 1 */
    rgu_put_body(1);  /* line 1 */
    rgu_put_body(1);  /* line 1 */
    rgu_put_body(1);  /* line 1 */    
    /*max_count += 6;*/
    max_count += 4;

    printf("fyear2[%s]\n",fyear2);
    /* �e�@�~�O�渹 */
    if(strlen(trim(pre_ply[0])) > 13)
         strcpy(ch1,pre_ply[0]); /*** 89.06.19�]�j�O����פ���,�G17���L**/
    else if (strlen(trim(pre_ply[0])) > 0)
    {
         strcpy(ch1,"17");
         strcat(ch1,pre_ply[0]);
    }
    else
          ch1[0]='\0';
    rgu_put_body_string(46,ch1,LEFT);
    
    /*9912 */   
    /*
    sprintf(ch1,"%2d",qlia_2[0]);
    if(fyear2[0]=='Y' && lia_flag == 'Y' && new_rate == 'N') * ���N-�d�� *
        rgu_put_body_string(46,ch1,RIGHT);
    else
    {
        rgu_put_body_string(46," ",RIGHT);
    }

    strcpy(ch1,trim(cdmg[0]));
    if(fyear2[0]=='Y' && dmg_flag == 'Y') * ���N-���� *
        rgu_put_body_string(46,ch1,RIGHT);
    else
        rgu_put_body_string(46," ",RIGHT);
    */
    /*�j�� 
    if(fyear1[0]=='Y')
    {    
        printf("last_ply[%s],ch1[%s]\n",last_ply,ch1);
        sprintf(ch1,"%2d",qlia_1[0]);

        printf("ch1 == [%s]\n",ch1);*/
        /** 95.06.19 �j��e�@�~�ߴڦ��Ƥ����
          rgu_put_body_string(46,ch1,RIGHT);  **/
 /*       rgu_put_body_string(46," ",RIGHT);
    }
    else
    {*/
     /* 9912
        rgu_put_body_string(46," ",RIGHT);*/
/*    }*/
    if (fcard_class[0] == '1' ||
       (fcard_class[0] == '2' && frelative_comp == 'Y'))
    {    
	    /*9912,����m��L�j���I���T�d�ߧǸ� */
	    if(strlen(trim(iquery_num)) > 0)
	    { 	    	
	       rgu_put_body_string(46,trim(iquery_num),LEFT);  
	    }    	
    }else{
    
        rgu_put_body_string(46," ",LEFT);
    }
    
    rgu_put_body_string(46," ",RIGHT);
    rgu_put_body_string(46," ",RIGHT);
    rgu_put_body(46); /* �e�@�~ */

    /*990809,����m��L�j���I���T�d�ߧǸ� */
    /*
    if(strlen(trim(iquery_num)) > 0)
    { 
         rgu_put_body_string(46,trim(iquery_num),LEFT);  
    }
    else
    {
        rgu_put_body_string(46," ",LEFT);
    }
    
    rgu_put_body_string(46,"",LEFT);*/
    rgu_put_body_string(46,"",LEFT);
    rgu_put_body_string(46,"",LEFT);
    rgu_put_body_string(46,"",LEFT);
    rgu_put_body_string(46,"",LEFT);
    rgu_put_body(46);
    max_count+=2;


    /* �e�G�~�O�渹 */
    if(strlen(trim(pre_ply[1])) > 13)
        strcpy(ch1,pre_ply[1]);
    else if(strlen(trim(pre_ply[1])) > 0)
    {
        strcpy(ch1,"17");
        strcat(ch1,pre_ply[1]);
    }
    else
        ch1[0]='\0';
    rgu_put_body_string(46,ch1,LEFT);
    /* 9912
    sprintf(ch1,"%2d",qlia_2[1]);
    if(fyear2[1]=='Y' && lia_flag == 'Y' && new_rate == 'N') * ���N-�d�� *
         rgu_put_body_string(46,ch1,RIGHT);
    else
         rgu_put_body_string(46," ",RIGHT);

    strcpy(ch1,trim(cdmg[1]));
    if(fyear2[1]=='Y' && dmg_flag == 'Y') * ���N-���� *
        rgu_put_body_string(46,ch1,RIGHT);
    else
        rgu_put_body_string(46," ",RIGHT);

    rgu_put_body_string(46," ",RIGHT); */

    /*9912, �����I���T�d�ߧǸ� */
    if(strlen(trim(iquery_num_damage)) > 0)
    { 
         rgu_put_body_string(46,trim(iquery_num_damage),LEFT);  
    }
    else
    {
        rgu_put_body_string(46," ",LEFT);
    }    
    rgu_put_body_string(46," ",RIGHT);
    rgu_put_body_string(46," ",RIGHT);

    rgu_put_body(46); /* �e�G�~ */
    
    rgu_put_body_string(46,"",LEFT);
    /*100.10.20 ,���d�I���T�d�ߧǸ� */
    if(strlen(trim(iquery_num_lia)) > 0)
    { 
         rgu_put_body_string(46,trim(iquery_num_lia),LEFT);  
    }
    else
    {
        rgu_put_body_string(46," ",LEFT);
    } 
    rgu_put_body_string(46,"",LEFT);
    rgu_put_body_string(46,"",LEFT);
    rgu_put_body(46); 
    max_count  += 2;

    rgu_put_body_string(46," ",RIGHT);
/*    rgu_put_body_string(46," ",RIGHT);
    strcpy(ch1,trim(cdmg[2]));
    rgu_put_body_string(46,ch1,RIGHT);*/
    
    if (strncmp(slia_ac_cnt3,"31",2)==0){
    	rgu_put_body_string(46,"���N�I�d�L���T�Y��",LEFT);  
    }else{
    	rgu_put_body_string(46," ",RIGHT);
    }
    
    rgu_put_body_string(46," ",LEFT);
    rgu_put_body_string(46," ",LEFT);
    rgu_put_body(46); /* �e�T�~ */
/*
    rgu_put_body_string(46," ",RIGHT);
    rgu_put_body_string(46," ",RIGHT);*/
    rgu_put_body_string(46," ",RIGHT);
    if (strncmp(slia_ac_cnt3,"31",2)==0){
    	rgu_put_body_string(46,"�A�Э��s�T�{",LEFT);  
    }else{
    	rgu_put_body_string(46," ",RIGHT);
    }


    /* 970414 ,�s�W��X���:�g��H�W�� */ 
    $EXECUTE get_nofficer INTO $nofficer USING $iofficer;
    if(SQLCODE == SQLNOTFOUND){
    	   strcpy(nofficer, " ");
    }else{
    	   strcpy(nofficer, trim(nofficer));
    }        
    if(fbigcomp[0]=='1')   /* �@��� */
    {
/*  980815  	
       rgu_put_body_string(46,nofficer,RIGHT);
       rgu_put_body_string(46," ",LEFT);    	
*/              
       rgu_put_body_string(46,nofficer,RIGHT);    	
       rgu_put_body_string(46," ",RIGHT);
    }else{	       
       rgu_put_body_string(46," ",RIGHT);
       rgu_put_body_string(46,nofficer,LEFT);    	
	}
    rgu_put_body(46); /* �e�T�~ */
    max_count = max_count + 2;
   /* printf("qlia_acc_1[%ld]\n",qlia_acc_1);*/
   
   /* 9912
    printf("qlia_acc_2[%ld]\n",qlia_acc_2);
    printf("qdmg_acc_2[%ld]\n",qdmg_acc_2);
   */
    printf("plia_acc_1[%f]\n",plia_acc_1);
/*    rgu_put_body_string(46," ",LEFT);*/
    /* 9912
    $SELECT qclass INTO $qlia_acc_2
       FROM ca_comp_acc_factor
      WHERE pcomp_factor = $plia_acc_2
        AND fcard_class = '2'
        AND drate = (select drate from ca_rate_date
                      where icode = $frate
                        and itable = 'ca_comp_acc_factor');
    if (SQLCODE == SQLNOTFOUND) qlia_acc_2=4;
    */
    
    /*9912 */
    qlia_acc_2 = atoi(slia_class_renew);  /* ���d�ż� */       
    acc_tmp = pdmg_acc_2 / 0.2;   
    sprintf(c_acc_tmp,"%f",acc_tmp);
    qdmg_acc_2 = atoi(c_acc_tmp);  /* �����I�� */  
    printf("acc_tmp[%f]\n",acc_tmp);
    printf(" AA qdmg_acc_2 = pdmg_acc_2  / 0.2 \n ");
    printf("AA pdmg_acc_2[%f]\n",pdmg_acc_2);
    printf("AA qdmg_acc_2[%ld]\n",qdmg_acc_2);
    printf("Trace -- fcar_class = [%s] \n",  fcar_class);
    $SELECT qclass INTO $qlia_acc_1
       FROM ca_comp_acc_factor
      WHERE pcomp_factor = $plia_acc_1
        AND fcard_class = '1'
        AND fcar_class  =  $fcar_class
        AND drate = (select drate from ca_rate_date
                      where icode = $frate
                        and itable = 'ca_comp_acc_factor');
    if (SQLCODE == SQLNOTFOUND) qlia_acc_1=4;

    printf("�q�Hqlia_acc_2[%ld]\n",qlia_acc_2);
    printf("�q�Hqdmg_acc_2[%ld]\n",qdmg_acc_2);
    printf("�q�Hqlia_acc_1[%ld]\n",qlia_acc_1);
/*
    if (lia_flag == 'Y')
    {*/
        sprintf(ch1,"%3d",qlia_acc_2);
        rgu_put_body_string(81,ch1,RIGHT);
/*    }
    else
        rgu_put_body_string(81," ",RIGHT);*/
/*
    if  (dmg_flag == 'Y')
    {*/
        sprintf(ch1,"%3d",qdmg_acc_2);
        rgu_put_body_string(81,ch1,RIGHT);
/*    }
    else
         rgu_put_body_string(81," ",RIGHT);*/

    if (fcard_class[0] == '1' ||
       (fcard_class[0] == '2' && frelative_comp == 'Y'))
    {
        sprintf(ch1,"%3d",qlia_acc_1);
        rgu_put_body_string(81,ch1,RIGHT);
    }
    else
        rgu_put_body_string(81,"",RIGHT);

    if(fbigcomp[0]=='1')   /* �@��� */
    {    	
        /*rgu_put_body_string(46, iofficer,RIGHT);   980815�ק�*/
        rgu_put_body_string(81, iofficer,RIGHT);
        rgu_put_body_string(81," ",LEFT);
        
        sprintf(stmt, " SELECT iquota, ileader  \
                          FROM officer \
                         WHERE iofficer = ?");

        $PREPARE prep3 FROM $stmt;

        $EXECUTE prep3 INTO $sTmp, $tmp_ileader USING $ileader;
        sTmp[4] = '0';
        sTmp[5] = '0';

        if( ileader[0] == '6') /* �����޲z�H�����H��޲z�H����쬰��� */
        {
            $EXECUTE prep3 INTO $sTmp, $sTmp1 USING $tmp_ileader;
            sTmp[4] = '0';
            sTmp[5] = '0';
        }
        $FREE prep3;
/*  980815
        sprintf(stmt, " SELECT '�ǯu:'||ibig_office, '�q��:'||itel \
                          FROM ca_big_office \
                         WHERE fclass = '3' \
                           AND ibig_comp = ? ");
        $PREPARE prep2 FROM $stmt;

        $EXECUTE prep2 INTO $iquota_fax, $iquota_tel USING $sTmp;
        $FREE prep2;

        if(SQLCODE == SQLNOTFOUND)
        {
             strcpy( iquota_fax, " ");
             strcpy( iquota_tel, " ");
        }

        rgu_put_body_string(46, iquota_tel,LEFT);*/
    }
    else
    {
        rgu_put_body_string(81," ",LEFT);
        rgu_put_body_string(81," ",LEFT);
    }

    rgu_put_body(81); /* �֭p�I�� */
    max_count++;

    printf("plia_acc_1[%f]\n",plia_acc_1);
    printf("plia_acc_2[%f]\n",plia_acc_2);
    printf("pdmg_acc_2[%f]\n",pdmg_acc_2);

    /*rgu_put_body_string(46," ",RIGHT);*/
/*
    if (lia_flag == 'Y')
    {*/
        sprintf(ch1,"%2.2f",plia_acc_2);
        rgu_put_body_string(81,ch1,RIGHT);
/*    }
    else
        rgu_put_body_string(81,"",RIGHT);*/
/*
    if (dmg_flag == 'Y')
    {*/
        sprintf(ch1,"%2.1f",pdmg_acc_2);
        rgu_put_body_string(81,ch1,RIGHT);
/*    }
    else
        rgu_put_body_string(81,"",RIGHT);*/
     
    if (fcard_class[0] == '1' ||
       (fcard_class[0] == '2' && frelative_comp == 'Y'))
    {
       sprintf(ch1,"%2.2f",plia_acc_1);
       printf("\n\nline1949--->");
       printf("plia_acc_1=[%f] ch1=[%s]\n", plia_acc_1, ch1 );

       rgu_put_body_string(81,ch1,LEFT);
    }
    else
       rgu_put_body_string(81,"",RIGHT);

    if(fbigcomp[0]=='1')   /* �@��� */
    {
    	/* 980815�ק�*/    	
        rgu_put_body_string(81, nname,RIGHT);
        /*rgu_put_body_string(46, iquota_fax,LEFT);*/
        rgu_put_body_string(81," ",RIGHT);
    }
    else /* �O�N�� */
    {
        rgu_put_body_string(81," ",RIGHT);
        sprintf( sTmp, "%s %s", iofficer, nname);
        rgu_put_body_string(81, sTmp, LEFT);
    }

    rgu_put_body(81); /* �ߴګY�� */
    max_count++;


    /*971126, �s�W�g���W�� */        
    if (icorps[0] != ' ' && icorps[0] != '\0'){  /* ¾�Υ� */
         strcpy(ioff_corps,icorps);
    }else{
    	   strcpy(ioff_corps,iofficer);
    }        	
    ibroker[0]='\0';
    strcpy(nbroker , "            ");     
    
    /* 100.05,�q���N���ĤG���q */       
    /*          
    $EXECUTE prep_ibroker INTO $ibroker using $ioff_corps;       
    if ((ibroker[0]!='\0')&&(ibroker[0]!=' ')){
          $EXECUTE prep_nbroker INTO $nbroker using $ibroker;
    	     if ((nbroker[0]!='\0')&&(nbroker[0]!=' ')){
    	     	  strcpy(nbroker , trim(nbroker));
    	     }else{
    	     	  strcpy(nbroker , "            ");
    	     }
    }
    */    

    if (dedr_begin==DATENULL)
    {
        rgu_put_body_string(87," ",LEFT);
    }
    else
    {
        printf("dedr_begin[%ld]\n",dedr_begin);
        strcpy(dedrbegin,cm_cdate_str_100(dedr_begin));
        printf("dedrbegin[%s]\n",dedrbegin);
        strcpy(ch1,dedrbegin);
        strcat(ch1," �L��");

        strcpy(tmp_buf,"(");
        strcat(tmp_buf,ch1);
        strcat(tmp_buf,")");

        rgu_put_body_string(87,tmp_buf,LEFT);
    }
/*
    sNequipment[13] = '\0'; 
    rgu_put_body_string(87, sNequipment, RIGHT);
*/    
     /* 990728=>�אּ nequipment	���O(�t�P�t��)	char(30) */
    rgu_put_body_string(87, " ", RIGHT);
    
    if ((strlen(trim(ibig_comp_s)) == 0) && (dply_begin >= 37499) && (fcard_class[0] == '2'))
    {
        sprintf(pdiscount_s,"%.2f",pdiscount_d);
        strcat(pdiscount_s,"(�DPA)");

        rgu_put_body_string(87,rtrim(pdiscount_s),LEFT);
        printf("dply_begin[%ld]\n",dply_begin);
    }
    else
    {
        rgu_put_body_string(87," ",LEFT);
    }
    
    rgu_put_body_string(87,nbroker,LEFT);
    
    rgu_put_body(87);

   /* rgu_put_body(1);*/
    rgu_put_body(1);
    max_count  += 2;

    /* ��H�Υdñ�b��C�L�O�渹�X */
    strcpy(tmp_buf,"�O�渹�X:");
    strcat(tmp_buf,trim(last_policy));

    rgu_put_body_string(44,tmp_buf,LEFT);
    rgu_put_body(44);
    max_count++;

    /*  Start Work 911008   */

    rgu_put_body(1); max_count++;
    rgu_put_body(1); max_count++;
    itp = 0;
    $DECLARE clm_cur CURSOR FOR
      SELECT iseq,dclaim,dprocess,drescue,nvl(qday,' ')
        INTO $iseq_tmp,$dclaim_tmp,$dprocess_tmp,$drescue_tmp,$qday_tmp
        FROM ca_ply_service
       WHERE ipolicy = $last_ply_tmp
       ORDER BY 1;
    $OPEN clm_cur;
    for(;;)
    {
         $FETCH clm_cur;
         if (SQLCODE == SQLNOTFOUND) break;
         if (itp == 0)
         {
             rgu_put_body_string(59,"�߮פ��",1);
             rgu_put_body_string(59,"�{���B�z",1);
             rgu_put_body_string(59,"�D���ϴ�",1);
             rgu_put_body_string(59,"�N�B���Ѽ�",1);
             rgu_put_body(59); max_count++;  itp++;
         }
          strcpy(dclaim_tmp,cm_from_infdate_100(dclaim_tmp));
          rgu_put_body_string(59,trim(dclaim_tmp),1);

          strcpy(dprocess_tmp,cm_from_infdate_100(dprocess_tmp));
          rgu_put_body_string(59,trim(dprocess_tmp),1);

          strcpy(drescue_tmp,cm_from_infdate_100(drescue_tmp));
          rgu_put_body_string(59,trim(drescue_tmp),1);

          rgu_put_body_string(59,trim(qday_tmp),2);
          rgu_put_body(59); max_count++;  itp++;
    }
    $CLOSE clm_cur;
    $FREE  clm_cur;

    /*  End Work 911008     */

    return 1;

ca302F1_3_err:
    printf("ca302F1_3....\n");
    printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* * ����q���� **************************************************/
CA301XForm2(locdb,fbigcomp,fmulti)
$char *locdb, *fbigcomp, *fmulti;
{
    int   i, other_ins,oth_cnt=0;
    char  ch1[10], ch2[10], LocDB[20];
    $char buf3[200],edomain1[25],edomain2[81];
    $char tmp_edo11[13],tmp_edo12[12],tmp_edo21[13],tmp_edo22[12];
    $char nins_abbr[29];
    $char ins_type_t3[INSURANCE_TYPE];
    $long inj_cover_t3,dea_cover_t3,dam_cover_t3;
    $int  qser_t3,qday_t3;
    char  tmp_tab[20];

    printf("=============into CA30XForm2()\n");

    $WHENEVER SQLERROR GOTO ca30xform2_err;

    CA301XF2_1(locdb,fbigcomp);
    CA301XF2_2(locdb,fbigcomp,fmulti);

    other_ins=0;

    strcpy(LocDB,get_full_dbname(locdb));
    if (LocDB[0]=='\0') return M_CM_DB_NOTOPEN;
  
    strcpy(tmp_tab,"ply_ins_type_302");
   
    sprintf(buf3,"SELECT iins_type, pre_inj_cover, pre_dea_cover, pre_dam_cover, \
                         pre_deduct, decode(pre_minsprem,-999,0,pre_minsprem) ,qserial,qday  \
                    FROM ply_ins_type_302     \
                   WHERE ipolicy = ? ORDER BY qserial  " ) ;   

    $PREPARE STM_10 FROM $buf3;
    $DECLARE CUR_10 CURSOR FOR STM_10;
    $OPEN CUR_10 USING $last_ply;
    while (1) 
    {
        $FETCH CUR_10
          INTO $ins_type_t3, $inj_cover_t3, $dea_cover_t3,
               $dam_cover_t3, $deduct_t3, $prem_t3, $qser_t3,$qday_t3;

        if (sqlca.sqlcode !=0) break;
        
        /* 950704 ,add  55, 56 */
        /* 960612, ���ݪ��I34 */
        iins=atoi(ins_type_t3);
        if (iins==1  || iins==5 || iins==2 || iins==11 || iins==12 ||
            iins==31 || iins==32 || iins==24 || iins==25 || iins==51 || iins==55 || iins==56 || 
            iins==53 || iins==52 || iins==21 || iins==9 || iins==8 || iins==47||iins==49||iins==34||iins==50||
            iins==57||iins==59||iins==60)
            continue;

        $SELECT nins_abbr,edomain1,edomain2,fprint,qcoverage
           INTO $nins_abbr,$edomain1,$edomain2,$fprint,$qcoverage
           FROM insurance_type
          WHERE iins_type=$ins_type_t3;
        if (NOT_FOUND)  continue; 

        if (*fprint=='0') {             /* clear to blank */
            /*strcpy(nins_abbr,blank);*/
            strcpy(edomain1,blank);
        }

        oth_cnt++;
        printf("oth_cnt[%d]\n",oth_cnt);

printf("Trace -- ins_type_t3 = [%s] \n",  ins_type_t3);
printf("Trace -- nins_abbr = [%s] \n",  nins_abbr);
printf("Trace -- edomain1 = [%s] \n",  edomain1);
printf("Trace -- dam_cover_t3 = [%ld] \n",  dam_cover_t3);

       if (iins==38||iins==39) 
	      dam_cover_t3 = qday_t3;

        if(oth_cnt==1)
            Put_Other_Ins_Cost_1(57,ins_type_t3,nins_abbr,edomain1,
                               " ","", 
                               deduct_t3,prem_t3,dam_cover_t3,
                               fmulti);
        else if(oth_cnt==2)
            Put_Other_Ins_Cost_1(58,ins_type_t3,nins_abbr,edomain1,
                               " ","", 
                               deduct_t3,prem_t3,dam_cover_t3,
                               fmulti);

    }   /* end while */
    $CLOSE CUR_10;

    if(oth_cnt==0)
    {
           rgu_put_body_string(57," ",LEFT);
           rgu_put_body_string(57," ",LEFT);
           rgu_put_body_string(57," ",LEFT);
           rgu_put_body_string(57," ",LEFT);
           rgu_put_body_string(57," ",LEFT);
           rgu_put_body_string(58," ",LEFT);
           rgu_put_body_string(58," ",LEFT);
           rgu_put_body_string(58," ",LEFT);
           rgu_put_body_string(58," ",LEFT);
           rgu_put_body_string(58," ",LEFT);
    }
    else if(oth_cnt==1) {
           rgu_put_body_string(58," ",LEFT);
           rgu_put_body_string(58," ",LEFT);
           rgu_put_body_string(58," ",LEFT);
           rgu_put_body_string(58," ",LEFT);
           rgu_put_body_string(58," ",LEFT);
    }
    rgu_put_body(50);
    rgu_put_body(51);
    rgu_put_body(52);
    rgu_put_body(53);
    rgu_put_body(54);
    rgu_put_body(55);
    rgu_put_body(56);
    rgu_put_body(57);
    rgu_put_body(58);
    max_count+=9;

    CA301XF2_3();

    return 1;

ca30xform2_err:
    printf("ca30xform2_err....\n");
    printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/* * ����q����--�O�I�򥻸�� *************************************/
CA301XF2_1(locdb1,fbigcomp)
char  *locdb1;
char  *fbigcomp;
{
    int      i;
    char     datestr[16], ch1[10], ch2[10];
    char     yy1[4], mm1[3], dd1[3], yy2[4], mm2[3], dd2[3], yy3[4], mm3[3], dd3[3];
    char     assureda1[45], assureda2[45];
    char     LocDB[20];
    $char    buf3[1080];
    $double  t_psex_age,t_plia_acc,t_pdmg_acc;
    char  tmp_tab[20];

    printf(">>>> into ca302F2_1()\n");
      
    strcpy(LocDB,get_full_dbname(locdb1));
    if (LocDB[0]=='\0') return M_CM_DB_NOTOPEN;

    $WHENEVER SQLERROR GOTO ca30xf2_err;

    sprintf(buf3,"SELECT pre_sex_age,NVL(pre_lia_acc,0),NVL(pre_dmg_acc,0) \
                    FROM policy_302                                        \
                   WHERE ipolicy = ? ");

    printf("�q����--->[%s]\n",buf3);
    $PREPARE STM_XF2     FROM   $buf3;
    $DECLARE CUR_XF2  CURSOR FOR STM_XF2;
    $OPEN    CUR_XF2 USING       $last_ply;
    $FETCH   CUR_XF2  INTO   $t_psex_age,$t_plia_acc,$t_pdmg_acc;
    printf("sex_age[%3.2f],lia_acc[%2.1f],dmg_acc[%2.1f]\n",
            t_psex_age,t_plia_acc,t_pdmg_acc);
    $CLOSE   CUR_XF2;
    $FREE    CUR_XF2;
/*
    for (i=0; i<19-itp; i++)
         rgu_put_body(1);
         
    max_count+=21;
*/
    for (i=0; i<18-itp; i++)
         rgu_put_body(1);
         
    max_count+=20;
    if (fcard_class[0] == '2')
    {
        rgu_put_body_string(30,last_card,LEFT);
        rgu_put_body_string(30,last_ply,LEFT);
        strcpy(datestr,cm_cdate_str_100(bef_ply2_begin));
        cm_split_ymd_100(datestr,yy1,mm1,dd1);
        sprintf(ch1,"%s%s%s%s%s",yy1,"/",mm1,"/",dd1);
        rgu_put_body_string(30,ch1,LEFT);
        strcpy(datestr,cm_cdate_str_100(bef_ply2_end));
        cm_split_ymd_100(datestr,yy2,mm2,dd2);
        sprintf(ch1,"%s%s%s%s%s",yy2,"/",mm2,"/",dd2);
        rgu_put_body_string(30,ch1,LEFT);
        rfmtlong(bef_premium2,"---,---,--&",ch1);
        rgu_put_body_string(30,ch1,LEFT);
        rgu_put_body(30);
    }
    else
        rgu_put_body(1);
     
    rgu_put_body(1);
    max_count+=2;

    rgu_put_body_string(31,assuredn,LEFT);
    rgu_put_body(31);
    rgu_put_body(1);
    max_count+=2;

    ben_len=cc_split_chinese(assureda,assureda1,44);
    ben_len=cc_split_chinese(&assureda[ben_len],assureda2,44);

    printf("assureda1[%s]\n",assureda1);
    rgu_put_body_string(32,aassured_zip,LEFT);
    rgu_put_body_string(32,assureda1,LEFT);
    rgu_put_body(32);
    max_count++;

    printf("assureda2[%s]\n",assureda2);

    rgu_put_body_string(33,assureda2,LEFT);
    rgu_put_body(33);
    rgu_put_body(1);
    max_count+=2;

    rgu_put_body_string(34,pro_year,LEFT);
    rgu_put_body_string(34,brandn,LEFT);
    printf("@@@@car_typen[%s]\n",car_typen);
    rgu_put_body_string(34,car_typen,LEFT);
    sprintf(ch1,"%2d",cylinder);
    rgu_put_body_string(34,ch1,LEFT);
    if (engine[0] !='\0' && engine[0] !=' ')
        rgu_put_body_string(34,engine,LEFT);
    else
        rgu_put_body_string(34,body,LEFT);

    rgu_put_body_string(34,tagnum,LEFT);
    sprintf(ch1,"%2.0f",qpt);
    if(fpt[0]=='P')
        strcat(ch1,"�H");
    else if(fpt[0]=='T')
        strcat(ch1,"��");
    else
        strcat(ch1,"  ");
    rgu_put_body_string(34,ch1,RIGHT);
    rgu_put_body(34);
    max_count+=1;
    
/* license �e���[�L"*"�F
    if (ibig_comp_s[0]!='L' && ibig_comp_s[0]!='P'){
        if (sFassured[0]=='1'||sFassured[0]=='3'||sFassured[0]=='5'){
          strncpy(license+(3),"****",4);
        }
    }
*/    
    rgu_put_body_string(35,license,LEFT);
    if (strlen(trim(s_dbirth))==0){
        rgu_put_body_string(35," ",LEFT);
    } else {      	      
        rgu_put_body_string(35,birth,LEFT);
    }
    if (*sex=='1') {
        strcpy(ch1,"�k");
    } else {
        if (*sex=='2') 
        strcpy(ch1,"�k");
        else strcpy(ch1,"");
    }
    rgu_put_body_string(35,ch1,LEFT);

    sprintf(ch1,"%2.1f",t_psex_age);
    rgu_put_body_string(35,ch1,RIGHT);

    sprintf(ch1,"%3.1f",t_plia_acc);
    rgu_put_body_string(35,ch1,RIGHT);

    sprintf(ch1,"%3.1f",t_pdmg_acc);
    rgu_put_body_string(35,ch1,RIGHT);

    rgu_put_body(35);
    rgu_put_body(1);
    max_count+=2;

    return 1;

ca30xf2_err:
    printf("ca30xf2_err....\n");
    printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* * ����q����--�I�ة��Ӹ�� **********************************/
CA301XF2_2(locdb1,fbigcomp,fmulti)
$char *locdb1;
char  *fbigcomp, *fmulti;
{
    char LHsdam_cover_t2[11];
    $char LHsdeduct_t2[13];
    char LHsprem_t2[11], LHsdea_cover_t2[11];
    $char buf4[200],ins_type_t2[INSURANCE_TYPE];
    $long inj_cover_t2,dea_cover_t2,dam_cover_t2,deduct_t2,prem_t2,qday_t2;
    $int  qser_t2, j,cnt;
    $static char fixins[26][INSURANCE_TYPE]={"01","05","08","09","85","11","31","32","12","24","25","51","55","56","49","52","53","02","47","34","50","57","59","60","38","39"};
    char  LocDB1[20];
    char  tmp_tab[20];
    int   iIdrive;
    int  ins55_flag;
    int  ins51_flag;
    int  ins56_flag;
    int  ins49_flag;
    int  ins52_flag;
    int  ins47_flag;
    int  ins50_flag;
    int  ins57_59_60_flag;
    int  ins53_flag;
    $char tmp_1[20];

    $WHENEVER SQLERROR GOTO ca30xf2_2_err;
  
    printf(">>>> into ca302F2_2()\n");
    ins51_flag = 0;
    ins55_flag = 0;    
    ins56_flag = 0;
    ins49_flag = 0;
    ins52_flag = 0;
    ins53_flag = 0;
    ins47_flag = 0;
    ins50_flag = 0;
    ins57_59_60_flag = 0;
    qday_t2 = 0;
    iIdrive = FALSE;
    strcpy(LocDB1,get_full_dbname(locdb1));
    if (LocDB1[0]=='\0') return M_CM_DB_NOTOPEN;
    strcpy(tmp_tab,"ply_ins_type_302");
    sprintf(buf4,"SELECT {+ INDEX (%s pins32_idx_1)} %s %s FROM %s:%s %s",
                 tmp_tab,
                 "iins_type,pre_inj_cover,pre_dea_cover,pre_dam_cover,",
                 "pre_deduct,pre_minsprem,qserial,ch_deduct[1,7],qday",
                 LocDB1,tmp_tab,
                 "WHERE ipolicy=? AND iins_type=? AND pre_minsprem<>0"); 
                                              /* 950908,�e���O�O��0��,���C�L*/
    $PREPARE STM_11 FROM $buf4;
    $DECLARE CUR_11 CURSOR FOR STM_11;
    cnt = 0;

    for (j=0;j<26;j++) /* fixins �W�[��,j�W���� �]�n�W�[ */

    {
        $OPEN CUR_11 USING $last_ply,$fixins[j];
        $FETCH CUR_11
          INTO $ins_type_t2, $inj_cover_t2, $dea_cover_t2,
               $dam_cover_t2, $deduct_t2, $prem_t2, $qser_t2, $LHsdeduct_t2,$qday_t2;
         
        if (SQLCODE == SQLNOTFOUND)
        {
            iins=atoi(fixins[j]);
            switch (iins) {
            case 1: case 5: case 9: case 8: case 85:
                  cnt += 1;
                  if (cnt == 5)
                  {
                    rgu_put_body_string(50," ",0);
                    rgu_put_body_string(50," ",0);
                    rgu_put_body_string(50," ",0);
                    rgu_put_body_string(50," ",0);
                    rgu_put_body_string(50," ",0);
                  }
                  break;
            case 11:
                  rgu_put_body_string(51," ",0);
                  rgu_put_body_string(51," ",0);
                  rgu_put_body_string(51," ",0);
                    break;
            case 12:
                  rgu_put_body_string(55," ",0);
                    break;
            case 32:
                  rgu_put_body_string(54," ",0);
                  rgu_put_body_string(54," ",0);
                  rgu_put_body_string(54," ",0);
                    break;
            case 24:
                  rgu_put_body_string(56," ",0);
                    break;
            case 31:
                  rgu_put_body_string(52," ",0);
                  rgu_put_body_string(52," ",0);
                  rgu_put_body_string(52," ",0);
                  rgu_put_body_string(53," ",0);
                  rgu_put_body_string(53," ",0);
                  rgu_put_body_string(53," ",0);
                    break;
                    
            /* 960612, ���ݪ��I34 => �ϥ�25�I����m */         
            /*case 25:*/
            case 25:
            	 break;
            case 34:
                  rgu_put_body_string(57," ",0);
                  rgu_put_body_string(57," ",0);
                  rgu_put_body_string(57," ",0);
                  rgu_put_body_string(57," ",0);
                  rgu_put_body_string(57," ",0);
                  rgu_put_body_string(58," ",0);
                  rgu_put_body_string(58," ",0);
                  rgu_put_body_string(58," ",0);
                  rgu_put_body_string(58," ",0);
                  rgu_put_body_string(58," ",0);
                    break;
            case 51:
            	 ins51_flag = 0;     /* �S��51*/ 
            	 /* 
                  rgu_put_body_string(50," ",0);
                  rgu_put_body_string(50," ",0);
                  rgu_put_body_string(50," ",0);
                  rgu_put_body_string(51," ",0);
                  rgu_put_body_string(51," ",0);
                  rgu_put_body_string(51," ",0);
                  rgu_put_body_string(52," ",0);
                  rgu_put_body_string(52," ",0);
                  rgu_put_body_string(52," ",0);
                  */
                    break;  
            case 55:  /*  950704 51,55,56 �ثe�ȯ�C�L�䤤�@���I�� */
            	  ins55_flag = 0;     /* �S��55*/
            	  /* 
                  rgu_put_body_string(50," ",0);
                  rgu_put_body_string(50," ",0);
                  rgu_put_body_string(50," ",0);
                  rgu_put_body_string(51," ",0);
                  rgu_put_body_string(51," ",0);
                  rgu_put_body_string(51," ",0);
                  rgu_put_body_string(52," ",0);
                  rgu_put_body_string(52," ",0);
                  rgu_put_body_string(52," ",0);
                  */
                    break;                    
            case 56: 
            	  ins56_flag = 0;     /* �S��56*/
            	  /* 950704 �p�G�O51��O�r�p,�h�S��55�u��56 */
                    break;           
            case 50: 
            	  ins50_flag = 0;       
            	    break;
            case 49:
            	 ins49_flag = 0;     /* �S��49*/   
            	    break;                        
            case 52:
            	 ins52_flag = 0;
                   break; 	
            case 53:
            	 ins53_flag = 0;
            case 47:
                 ins47_flag = 0;  
                    break;           	

             case 2:
                  rgu_put_body_string(56," ",0);
                  rgu_put_body_string(56," ",0);
                  rgu_put_body_string(56," ",0);
                  break;
            case 57:
            case 59:
            case 60:
            	  ins57_59_60_flag = 0;	
                  break;
            case 38:
            case 39:
                  break;            	
             other:
                  rgu_put_body_string(57," ",0);
                  rgu_put_body_string(57," ",0);
                  rgu_put_body_string(57," ",0);
                  rgu_put_body_string(58," ",0);
                  rgu_put_body_string(58," ",0);
                  rgu_put_body_string(58," ",0);
                  break;
             
                  
            }
            continue;
        }
        
        iins=atoi(ins_type_t2);
        /* �I�� 01/05/88/11/12/31/32/24/25/51/55/56/52/09/08/47/34 */

        if(iins==1 || iins==5 || iins==8 || iins==9 || iins==85)
        {
            rfmtlong(dam_cover_t2,"###,###,##&",LHsdam_cover_t2);
            /***rfmtlong(deduct_t2,"###,##&",LHsdeduct_t2);***/
            if( prem_t2 == -999 )
                strcpy( LHsprem_t2, "�M�ץ�");
            else
                rfmtlong(prem_t2,"###,###,##&",LHsprem_t2);
            rfmtlong(dea_cover_t2,"###,###,##&",LHsdea_cover_t2);

            rgu_put_body_string(50,ins_type_t2,RIGHT);
            if(iins==1)
            {
                 rgu_put_body_string(50,"�Ҧ�",LEFT);
            }
            if(iins==5)
            {
                 rgu_put_body_string(50,"�A��",LEFT);
            }
            if(iins==8)
            {
                 rgu_put_body_string(50,"�B��",LEFT);
            }
            if(iins==9)
            {
                 rgu_put_body_string(50,"����",LEFT);
            }
            if(iins==85)
            {
            	 rgu_put_body_string(50,"�I�������I",LEFT);
            }
            rgu_put_body_string(50,trim(LHsdam_cover_t2),RIGHT);
            rgu_put_body_string(50,trim(LHsdeduct_t2),RIGHT);
            rgu_put_body_string(50,trim(LHsprem_t2),RIGHT);
        }

        if(iins==11)
        {
            Put_Ins_Cost_1(51,11,3,1,0,1,
                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
                           deduct_t2,prem_t2,fmulti);

        }
        if(iins==12)
        {
            printf("BEF 12 \n");
            Put_Ins_Cost_1(55,12,0,1,0,1,
                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
                           deduct_t2,prem_t2,fmulti);

        }
        if(iins==31)
        {
            if (inj_cover_t2==0 && dea_cover_t2==0 && dam_cover_t2==0 &&
                prem_t2==0) {
                  rgu_put_body_string(52," ",0);
                  rgu_put_body_string(52," ",0);
                  rgu_put_body_string(52," ",0);
                  rgu_put_body_string(53," ",0);
                  rgu_put_body_string(53," ",0);
                  rgu_put_body_string(53," ",0);
            } else {
            Put_Ins_Cost_1(52,31,1,0,0,2,
                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
                           deduct_t2,prem_t2,fmulti);
            Put_Ins_Cost_1(53,31,3,1,0,2,
                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
                           deduct_t2,prem_t2,fmulti);
            }
        }
        if(iins==32)
        {
            if (inj_cover_t2==0 && dea_cover_t2==0 && dam_cover_t2==0 &&
                prem_t2==0) {
                  rgu_put_body_string(54," ",0);
                  rgu_put_body_string(54," ",0);
                  rgu_put_body_string(54," ",0);
            } else {
            Put_Ins_Cost_1(54,32,3,1,deduct_t2,1,
                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
                           deduct_t2,prem_t2,fmulti);
            }
        }
        if(iins==24)
        {
            Put_Ins_Cost_1(56,24,0,1,0,1,
                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
                           deduct_t2,prem_t2,fmulti);

        }
        /* 960612, ���ݪ��I34 => �ϥ�25�I�ت���m */
        if(iins==25) continue;
        if(iins==34)
        {
            Put_Ins_Cost_1(57,34,1,0,0,2,
                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
                           deduct_t2,prem_t2,fmulti);         
            Put_Ins_Cost_1(58,34,2,1,0,2,
                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
                           deduct_t2,prem_t2,fmulti);

        }
        /* 950704 */
        if((iins==51)||(iins==53)||(iins==55)||(iins==56 && ins55_flag != 1)||(iins==49)){
           
        	switch (iins) {
        		case 51:
        	        ins55_flag = 1; 
        		case 55:
        	        ins55_flag = 1; 
        		case 53:
        	        ins53_flag = 1;         	        
        		case 56:
        	        ins56_flag = 1; 
        		case 49:
        	        ins49_flag = 1;       	        
            }
   printf(" ------- iins = [%d]\n " , iins);
   printf(" ------- inj_cover_t2 = [%d]\n " , inj_cover_t2);
   printf(" ------- dea_cover_t2 = [%d]\n " , dea_cover_t2);
   printf(" ------- dam_cover_t2 = [%d]\n " , dam_cover_t2);
   printf(" ------- prem_t2 = [%d]\n " , prem_t2);
   
   
            if (inj_cover_t2==0 && dea_cover_t2==0 && dam_cover_t2==0 &&
                prem_t2==0) {
	            rgu_put_body_string(50," ",LEFT);
	            rgu_put_body_string(50," ",LEFT);
	            rgu_put_body_string(50," ",LEFT);
	            rgu_put_body_string(51," ",LEFT);
	            rgu_put_body_string(51," ",LEFT);
	            rgu_put_body_string(51," ",LEFT);
	            rgu_put_body_string(52," ",LEFT);
	            rgu_put_body_string(52," ",LEFT);
	            rgu_put_body_string(52," ",LEFT);
            }
            else {
            	printf(" ------- test1 \n");
            	if (iins==55||iins==53){  /* 100.04.01 */
		            Put_Ins_Cost_1(51,iins,2,0,0,2,
		                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
		                           deduct_t2,prem_t2,fmulti);
		            Put_Ins_Cost_1(52,iins,3,1,0,2,
		                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
		                           deduct_t2,prem_t2,fmulti);            		
            	}else{
		            Put_Ins_Cost_1(50,iins,1,0,0,3,
		                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
		                           deduct_t2,prem_t2,fmulti);
		            Put_Ins_Cost_1(51,iins,2,0,0,3,
		                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
		                           deduct_t2,prem_t2,fmulti);
		            Put_Ins_Cost_1(52,iins,3,1,0,3,
		                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
		                           deduct_t2,prem_t2,fmulti);
	            }               
            }

        } 
        
        if(iins==57||iins==59||iins==60){
        	 
            ins57_59_60_flag = 1;
 
            if (inj_cover_t2==0 && dea_cover_t2==0 && dam_cover_t2==0 &&
                prem_t2==0) {
	            rgu_put_body_string(50," ",LEFT);
	            rgu_put_body_string(50," ",LEFT);
	            rgu_put_body_string(50," ",LEFT);
	            rgu_put_body_string(51," ",LEFT);
	            rgu_put_body_string(51," ",LEFT);
	            rgu_put_body_string(51," ",LEFT);
	            rgu_put_body_string(52," ",LEFT);
	            rgu_put_body_string(52," ",LEFT);
	            rgu_put_body_string(52," ",LEFT);
            }
            else {
            	printf(" ------- test1 \n");
	            Put_Ins_Cost_1(51,iins,2,0,0,3,
	                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
	                           deduct_t2,prem_t2,fmulti);
	            Put_Ins_Cost_1(52,iins,3,1,0,3,
	                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
	                           deduct_t2,prem_t2,fmulti);
            }
        } 
                
        /* 950704 
        if(iins==55)
        {
        	ins55_flag = 1;  
        	printf("\n iins[%d] ins55_flag\n[%d]",iins,ins55_flag);          	 
        	printf("\n---inj_cover_t2[%d]  dea_cover_t2[%d]  dam_cover_t2[%d]-\n",inj_cover_t2,dea_cover_t2,dam_cover_t2);
            if (inj_cover_t2==0 && dea_cover_t2==0 && dam_cover_t2==0 &&
                prem_t2==0) {
            rgu_put_body_string(50," ",LEFT);
            rgu_put_body_string(50," ",LEFT);
            rgu_put_body_string(50," ",LEFT);
            rgu_put_body_string(51," ",LEFT);
            rgu_put_body_string(51," ",LEFT);
            rgu_put_body_string(51," ",LEFT);
            rgu_put_body_string(52," ",LEFT);
            rgu_put_body_string(52," ",LEFT);
            rgu_put_body_string(52," ",LEFT);
            }
            else {
            Put_Ins_Cost_1(50,55,1,0,0,3,
                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
                           deduct_t2,prem_t2,fmulti);
            Put_Ins_Cost_1(51,55,2,0,0,3,
                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
                           deduct_t2,prem_t2,fmulti);
            Put_Ins_Cost_1(52,55,3,1,0,3,
                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
                           deduct_t2,prem_t2,fmulti);
            }

        }  */ 
         /* if(iins==56) 950704 �p�G�O51��O�r�p(�S��55),�h�L56���e���O�B�B�O�O 
        {
        	        	
        	printf("\n iins[%d] ins55_flag\n[%d",iins,ins55_flag); 
        	if (ins55_flag != 1){
	        	printf("\n---inj_cover_t2[%d]  dea_cover_t2[%d]  dam_cover_t2[%d]-\n",inj_cover_t2,dea_cover_t2,dam_cover_t2);
	            if (inj_cover_t2==0 && dea_cover_t2==0 && dam_cover_t2==0 &&
	                prem_t2==0) {
	            rgu_put_body_string(50," ",LEFT);
	            rgu_put_body_string(50," ",LEFT);
	            rgu_put_body_string(50," ",LEFT);
	            rgu_put_body_string(51," ",LEFT);
	            rgu_put_body_string(51," ",LEFT);
	            rgu_put_body_string(51," ",LEFT);
	            rgu_put_body_string(52," ",LEFT);
	            rgu_put_body_string(52," ",LEFT);
	            rgu_put_body_string(52," ",LEFT);
	            }
	            else {
	            Put_Ins_Cost_1(50,56,1,0,0,3,
	                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
	                           deduct_t2,prem_t2,fmulti);
	            Put_Ins_Cost_1(51,56,2,0,0,3,
	                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
	                           deduct_t2,prem_t2,fmulti);
	            Put_Ins_Cost_1(52,56,3,1,0,3,
	                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
	                           deduct_t2,prem_t2,fmulti);
	            }
            } 
        }    */       
             
        if((iins==52)||(iins==50)) /* 50 �Ȩϥ�52��m*/
        {

            if (iins==50){
	            Put_Ins_Cost_1(53,iins,1,0,0,2,
	                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
	                           deduct_t2,prem_t2,fmulti);            	
	            Put_Ins_Cost_1(54,iins,2,1,0,2,
	                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
	                           deduct_t2,prem_t2,fmulti);
	            Put_Ins_Cost_1(55,iins,3,0,0,2,
	                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
	                           deduct_t2,prem_t2,fmulti);	 	                           
            }else{
            	/* 100.4.01
	            Put_Ins_Cost_1(53,iins,1,0,0,3,
	                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
	                           deduct_t2,prem_t2,fmulti);            	
	            */               
	            Put_Ins_Cost_1(54,iins,2,0,0,2,
	                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
	                           deduct_t2,prem_t2,fmulti);
	            Put_Ins_Cost_1(55,iins,3,1,0,2,
	                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
	                           deduct_t2,prem_t2,fmulti);	                           
            }               

        }
        if(iins==47)
        {   

            Put_Ins_Cost_1(53,iins,1,0,0,3,
                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
                           deduct_t2,prem_t2,fmulti);
            Put_Ins_Cost_1(54,iins,2,0,0,3,
                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
                           deduct_t2,prem_t2,fmulti);
            Put_Ins_Cost_1(55,iins,3,1,0,3,
                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
                           deduct_t2,prem_t2,fmulti);
        }
        if(iins==2){
            rgu_put_body_string(56," ",1);
            rgu_put_body_string(56," ",1);
            rfmtlong(prem_t2,"-,---,--&",tmp_1);
            rgu_put_body_string(56,trim(tmp_1),2);
        }
        /* 
        if(iins==38||iins==39)
        {
        */
        	/*
            Put_Ins_Cost_1(55,iins,3,1,0,1,
                           0,0,20,
                           deduct_t2,prem_t2,fmulti);     	
            */                
        	/*
        	if (iins==38){
                rgu_put_body_string(40,"38",RIGHT);
                rgu_put_body_string(40,"�D���ϴ����v�򥻫�",RIGHT);                
            }else{
            	rgu_put_body_string(40,"39",RIGHT);
            	rgu_put_body_string(40,"�D���ϴ����v�O�٫�",RIGHT);
            }
                        
            sprintf(tmp_1,"��Q���{ %ld",qday_t2);
            rgu_put_body_string(40,rtrim(tmp_1),RIGHT);
            
            rgu_put_body_string(40,"����   �L",LEFT);
            
            rfmtlong(prem_t2,"---,--&",tmp_1);
            rgu_put_body_string(40,rtrim(tmp_1),RIGHT);
                                      
            rgu_put_body_string(40," ",0);
            rgu_put_body(40);
           */   
        /*}*/
        
        $CLOSE CUR_11;

    } /* end of for */
    
    if (((ins51_flag==0)&&(ins55_flag==0)&&(ins56_flag==0)&&(ins57_59_60_flag==0))||((ins51_flag==0)&&(ins49_flag==0))||((ins53_flag==0)&&(ins55_flag==0)&&(ins56_flag==0)&&(ins57_59_60_flag==0)) ){
          rgu_put_body_string(50," ",0);
          rgu_put_body_string(50," ",0);
          rgu_put_body_string(50," ",0);
          rgu_put_body_string(51," ",0);
          rgu_put_body_string(51," ",0);
          rgu_put_body_string(51," ",0);
          rgu_put_body_string(52," ",0);
          rgu_put_body_string(52," ",0);
          rgu_put_body_string(52," ",0);     	
    }
    if ((ins52_flag==0)&&(ins47_flag==0)&&(ins50_flag==0)){
          rgu_put_body_string(53," ",0);
          rgu_put_body_string(53," ",0);
          rgu_put_body_string(53," ",0);
          rgu_put_body_string(54," ",0);
          rgu_put_body_string(54," ",0);
          rgu_put_body_string(54," ",0);
          rgu_put_body_string(55," ",0);
          rgu_put_body_string(55," ",0);
          rgu_put_body_string(55," ",0);    
    }                  
    max_count += 9;

    return 1;
        

ca30xf2_2_err:
    printf("ca30xf2_2_err....\n");
    printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* * ����q����--�j���I�ظ�� ************************************/
CA301XF2_3()
{
    char  datestr[16], ch1[16], ch2[16];
    char  yy1[4], mm1[3], dd1[3], yy2[4], mm2[3], dd2[3];

    printf(">>>> into ca302F2_3()\n");

    if (bef_ply1_begin==DATENULL) {
        rgu_put_body_string(41," ",LEFT);
        rgu_put_body_string(41," ",LEFT);
        rgu_put_body_string(41," ",LEFT);
    } else {
        strcpy(datestr,cm_cdate_str_100(bef_ply1_begin));
        cm_split_ymd_100(datestr,yy1,mm1,dd1);
        rgu_put_body_string(41,yy1,LEFT);
        rgu_put_body_string(41,mm1,LEFT);
        rgu_put_body_string(41,dd1,LEFT);
    }
    rgu_put_body(41);
    if (fcard_class[0] == '1')
        rgu_put_body_string(42,last_card,LEFT);
    else
        rgu_put_body_string(42,irel_card,LEFT);
    if (bef_ply1_end==DATENULL) {
        rgu_put_body_string(42," ",LEFT);
        rgu_put_body_string(42," ",LEFT);
        rgu_put_body_string(42," ",LEFT);
    } else {
        strcpy(datestr,cm_cdate_str_100(bef_ply1_end));
        cm_split_ymd_100(datestr,yy2,mm2,dd2);
        rgu_put_body_string(42,yy2,LEFT);
        rgu_put_body_string(42,mm2,LEFT);
        rgu_put_body_string(42,dd2,LEFT);
    }
    printf("-----20 bef_premium1=[%d] \n",bef_premium1);
    rfmtlong(bef_premium1,"---,---,--&",ch1);
    rgu_put_body_string(42,trim(ch1),RIGHT);
    rgu_put_body(42);
    rgu_put_body(1);
    max_count+=3;
}

/* * ����*********************************************************/
int docket(bigcomp_ply,fcomp)
$char *bigcomp_ply,*fcomp;
{
    $char ch1[300],stmt_buf[1000];
    char assureda1[80], assureda2[80];

    $WHENEVER SQLERROR GOTO ca_rpt_renew_err1;

    InitData1();

    printf("1----->>>>bigcomp_ply[%s],fcomp[%s]\n",bigcomp_ply,fcomp);
    if(fcomp[0]=='1')
    { /* �@�� */
        $SELECT a.ipolicy,a.ibig_office,b.nassured,b.aassured
           INTO $last_ply,$big_office,$assuredn,$assureda
           FROM ply_relation a,policy b
          WHERE a.ipolicy=b.ipolicy AND a.ipolicy=$bigcomp_ply;
    }
    else
    {  /* �O�N */
        $SELECT a.ipolicy,ibig_office,nassured,aassured,a.ibig_comp
           INTO $last_ply,$big_office,$assuredn,$assureda,$ibig_comp
           FROM ply_relation_last a,policy_last b,broker_agent c
          WHERE a.ipolicy=b.ipolicy AND a.ipolicy=$bigcomp_ply
            AND a.ibroker=c.ibroker;
    }

    if (SQLCODE != 0)
    {
       strcpy(last_ply," ");
       strcpy(big_office," ");
       strcpy(assuredn," ");
       strcpy(assureda," ");
       strcpy(ibig_comp," ");
    }

    printf("2-------ply[%s] \n",last_ply);
    printf("ibig_comp[%s],big_office[%s]\n",ibig_comp,big_office);

    /*---�C�L����---*/
    rgu_put_body(1);      /* line 1 */
    rgu_put_body(1);      /* line 2 */
    if(fcomp[0]=='1')
    { /* �@�� */
         rgu_put_body(1);      /* line 4 */
    }
    else
    {  /* �O�N */
         strcpy(ch1,"�O�N���q:");
         strcat(ch1,ibig_comp);
         strcat(ch1,"  ������~�ҥN��:");
         strcat(ch1,big_office);
         rgu_put_body_string(44,ch1,LEFT);
         rgu_put_body(44);     /* line 3 */
    }
    rgu_put_body(1);      /* line 4 */

    printf("assuredn[%s]\n",assuredn);

    strcpy(ch1,"�m�W:");
    strcat(ch1,assuredn);
    rgu_put_body_string(44,ch1,LEFT);
    rgu_put_body(44);     /* line 5 */
    rgu_put_body(1);      /* line 6 */

    printf("assureda[%s]\n",assureda);
    ben_len=cc_split_chinese(assureda,assureda1,40);
    ben_len=cc_split_chinese(&assureda[ben_len],assureda2,40);
    printf("assureda1[%s]\n",assureda1);
    printf("assureda2[%s]\n",assureda2);
    strcpy(ch1,"���}:");
    strcat(ch1,assureda1);
    rgu_put_body_string(44,ch1,LEFT);
    rgu_put_body(44);     /* line 7 */

    strcpy(ch1,"     ");
    strcat(ch1,assureda2);
    rgu_put_body_string(44,ch1,LEFT);
    rgu_put_body(44);    /* line 8 */

    printf("------print label:ply[%s] \n",last_ply);

    max_count+=8;

    rgu_put_body(1); /* line 9 */
    max_count+=1;
  
return SUCCESS;

ca_rpt_renew_err1:
    printf("ca_rpt_renew1_err1....\n");
    printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  char sTmp_db_name[21];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, sTmpcomp);
  }
  return sTmp_db_name;
}

/************************************************************************/
static long GetNextYearDate(pdate)
long pdate;
{
long ndate;
short mdy[3];

    rjulmdy(pdate,mdy);
    mdy[2]++;   /* mdy[2] is the year data */

    if ((mdy[0] == 2) && (mdy[1] == 29))
       mdy[1] = 28;

    printf("�~[%d],��[%d],��[%d]\n",mdy[2],mdy[0],mdy[1]);

    rmdyjul(mdy,&ndate);
    return ndate;
}

char *split_yymm(edate)
char edate[11];
{
char syymm[5];
int  iyear;
char tmp[5];

     printf("edate[%s]\n",edate);
     strcpy(tmp,edate+6);
     iyear = atoi(tmp);
     strcpy(syymm,itoa(iyear-1911));
     strncpy(tmp,edate,2);
     tmp[2] = '\0';
     strcat(syymm,tmp);
     return syymm;
}

