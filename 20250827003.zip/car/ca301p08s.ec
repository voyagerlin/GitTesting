/**********************************************************************/
/*   program id   : ca301p08s.ec                                      */
/*   program name : ���I�e�~�O����Ӳ��s                              */
/*   date written : 2016/11/11                                        */
/*   date modify  : yyyy/mm/dd                                        */
/*   shell        : car3018                                           */
/*   exec time    : �C��U�ȤT�I�|�Q����                              */
/**********************************************************************/

#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include "print.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "othmsgs.h"
#include "commsgs.h"
#include "sqlfatal.h"
#include "safeclib.h"

char  	outputf[ N_FILE+1];
$char  	userid[11],sDdate[11];
char  	ddate[11];
char	sdate[11];

$char	DBName[5];
DBinfo  *list;
    
int     flen,count_db,i;
FILE    *fp;
char    sApHome[30];
$char   fname[60];
$char   filename[121];

$char	stmt[1024],stmt_1[4096],stmt_2[4096],stmt1[256],stmt2[256];
char	msgbuf[100];

$char	ipolicy[21],icard1[21],itag[CA_TAG_NUM],fassured[2],dpolicy[11],iroute[21];
$varchar nassured[121],sNassured[121];
$char	iofficer[11],nofficer[11],ileader[11],nleader[11],nmail_type[11];
$int mpremium;
$char   cdate1[11],cdate2[11];
$int c_holiday,c_3072=0;
$char ck_holiday_year[4],ck_now[21],ck_holiday[11];

$char stmt_tmp[1024];
/*----------------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
    int rc;
      
    batchinit();
    strcpy(DBName,  isNULLstr(argv[1]));
    strcpy(userid,  isNULLstr(argv[2]));
    strcpy(ddate,   isNULLstr(argv[3])); /* cyy/mm/dd */
    strcpy(outputf, isNULLstr(argv[4]));
    
    strcpy(sDdate,cm_to_infdate(ddate));
    printf("-----dpolicy : [%s]\n-----",sDdate);

    rc = car3018_get_db();
    if (rc != M_CM_OK) {
        printf("error on car3018_get_db\n");
        return rc;
    }
    /*
    strcpy(ck_holiday_year,"");
    strcpy(ck_holiday,"");
    strcpy(ck_holiday_year,cm_get_sysd());
    strcpy(ck_holiday_year,cm_sysd_cyear_100(ck_holiday_year));
    strcpy(ck_holiday,cm_get_sysd());
    strcpy(ck_holiday,cm_sysd_cdate_100(ck_holiday));
    strcpy(ck_holiday,cm_to_infdate(ck_holiday));
    strcpy(ck_holiday,"05/28/2016");
    printf("-----ck_holiday_year = [%s]-----\n",ck_holiday_year);
    printf("-----ck_holiday = [%s]-----\n",ck_holiday);
    $SELECT count(*)
       INTO $c_holiday 
       FROM ca_holiday  
      WHERE cyear = $ck_holiday_year
        AND $ck_holiday BETWEEN holiday_bgn AND holiday_end;  
    */ 
    /*   
    if(c_holiday == 0)
    {
    */
    
    $SELECT count(*)
       INTO $c_3072
       FROM cu_code_data
      WHERE itype = 'OT'
        AND icode = '3072'
        AND ncode = 'Y';
    
    if(c_3072 > 0)
    {
    	/* �ةe�~�O��M����� temp table (car3018) */        
	    rc = car3018_init_data();
	    if (rc != M_CM_OK) {
	        printf("error on car3018_init_data\n");
	        return rc;
	    }
	        
	    /* �d�ߩe�~�O�������� */        
	    rc = car3018_ply_data();
	    if (rc != M_CM_OK) {
	        printf("error on car3018_ply_data\n");
	        EWRITE(userid, rc, "�d�߫O���Ʀ��~!");
	        return rc;
	    }
	    
	    /* ���I�e�~�O��L�s�M�� */
	    rc = car3018_print();
	    if (rc != M_CM_OK) {
	        printf("error on car3018_print\n");
	        EWRITE(userid, rc, "�����M�沣�s���~!");
	        return rc;
	    }
    }

	/*
    }
	*/
    printf("[car3018]:process ok!\n"); 
}
/*----------------------------------------------------------------------------*/
long car3018_get_db()
{
    int	rc;

    if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "��Ʈw�L�k�}��!");
       return M_CM_DB_NOTOPEN;
    }
    
    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }
    
    if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
       if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
          return M_CM_NOT_DBLIST;
    }

    return M_CM_OK;
}
/*----------------------------------------------------------------------------*/
long car3018_init_data()
{
    $whenever sqlerror goto errexit;


    sprintf_s(stmt_tmp, sizeof stmt_tmp,"create temp table car3018 (\
	   ipolicy		     char(20),\
	   icard1          char(20),\
	   nassured        char(120),\
       itag            char(%d),\
       mpremium        integer,\
       dpolicy         date,\
       iofficer        char(10),\
       nofficer        char(10),\
       iroute          char(20),\
       nmail_type      char(10),\
       ileader         char(10),\
       nleader         char(10),\
       fassured        char(1)\
     )with no log;",CA_TAG_NUM-1);
      $PREPARE stmp FROM $stmt_tmp;
      $EXECUTE stmp;

    printf("-----ddate = [%s]-----\n",ddate);

    return M_CM_OK;

errexit:
        sqlfatal();
        EWRITE(userid,SQLCODE,sqlca.sqlerrm);
        return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car3018_ply_data()
{
   int	rc;
   
   $whenever sqlerror goto errexit;
   $SET LOCK MODE TO WAIT 5;

   for(i=0;i<count_db;i++) 
   {  	 
     sprintf_s(stmt_1, sizeof stmt_1,"INSERT INTO car3018 "
	   "SELECT a.ipolicy, CASE WHEN a.fcard_class = '1' Then a.icard ELSE ' ' END, "
	   "       b.nassured , b.itag , (a.mdmg_prem+a.mlia_prem) as mpremium , "
	   "       a.dpolicy, a.iofficer, "
	   "      (SELECT nname FROM officer WHERE iofficer = a.iofficer) as nofficer, "
	   "       b.iroute, decode(a.fmail_type,'0','���e�~�l�H','1','���H','2','����', "
	   "                        '3','����','4','����',' '), a.ileader, " 
	   "      (SELECT nname FROM officer WHERE iofficer = a.ileader) as nleader, b.fassured "
	   "  FROM %s:ply_relation a, %s:policy b"
	   " WHERE a.ipolicy = b.ipolicy  "
	   "   AND dpolicy >= '01/11/2016'   "
	   "   AND date(a.dout_trans) = '%s' "
	   "   AND a.dply_close is null",list[i].dbname,list[i].dbname,sDdate);	  
	   printf("stmt1[%s]\n",stmt_1);
	   $prepare pre_ply1 from $stmt_1;
	   $execute pre_ply1;
	   
     sprintf_s(stmt_2, sizeof stmt_2,"INSERT INTO car3018 "
	   "SELECT a.ipolicy, CASE WHEN a.fcard_class = '1' Then a.icard ELSE ' ' END, "
	   "       b.nassured , b.itag , (a.mdmg_prem+a.mlia_prem) as mpremium , "
	   "       a.dpolicy, a.iofficer, "
	   "      (SELECT nname FROM officer WHERE iofficer = a.iofficer) as nofficer, "
	   "       b.iroute, decode(a.fmail_type,'0','���e�~�l�H','1','���H','2','����', "
	   "                        '3','����','4','����',' '), a.ileader, " 
	   "      (SELECT nname FROM officer WHERE iofficer = a.ileader) as nleader, b.fassured "
	   "  FROM %s:ori_ply_relation a, %s:original_ply b"
	   " WHERE a.ipolicy = b.ipolicy  "
	   "   AND dpolicy >= '01/11/2016'   "
	   "   AND date(a.dout_trans) = '%s' "
	   "   AND a.dply_close is not null",list[i].dbname,list[i].dbname,sDdate);	  
	   printf("stmt2[%s]\n",stmt_2);
	   $prepare pre_ply2 from $stmt_2;
	   $execute pre_ply2;
	 }  
	
	   return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

long car3018_print()
{
    int     rc;
    char    sfilename[100],stitle[1024],stmt[1024];

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(sfilename,"���I�O��e�~�L�s�M��(E-mail�q��)");
    strcpy(stitle,"�{���N��:CAR3018\t");
    strcat(stitle,sfilename);
    strcat(stitle,"\t\t\t\t\t\t\t\t\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");
    strcat(sfilename,"[CAR3018]");

    strcat(stitle,"\t�O�渹�X\t�j���Ҹ�\t�Q�O�I�H�m�W\t���P���X\t�O�O\t");
    strcat(stitle,"�X����\t�g��N��\t�g��N������\t�q���N��\t");
    strcat(stitle,"�l�H�覡\t�޲z�H�N��\t�޲z�H����\t");

    strcpy(stmt,"SELECT ipolicy, icard1, nassured, itag, mpremium, dpolicy, "
				       "	      iofficer, nofficer, iroute, nmail_type, "
				       "        ileader, nleader "
               "   FROM car3018          "
               "  ORDER BY itag ");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);

    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;
    
errexit:
    sqlfatal();
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}
/*-------------------------------THE END--------------------------------------*/