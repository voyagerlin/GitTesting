/************************************************/
/*                                              */
/*   PROGRAM : car119p01s.ec                     */
/*                                              */
/************************************************/
     
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "is_def.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;
#include "safeclib.h"

$char DBName[5];
char  outputf[21];
char  userid[11];
/*  self data */


main(argc, argv)
int argc;
char **argv;
{
   int rc;
   char x;

   batchinit();

   /* must part */
   strcpy(DBName,isNULLstr(argv[1]));
   strcpy(userid,isNULLstr(argv[2]));

   /* must part, (index should be changed) */
   strcpy(outputf,isNULLstr(argv[3]));

   aoi110_update_exec();
}


int aoi110_update_exec()
{
   /* self defined data */
   $char db[20][3];
   $char tmp[512];
   int i,j;
   DBinfo *list; 

   $WHENEVER SQLERROR GOTO errexit;
   if (db_select(DBName) == False) 
   { 
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return 0;
   }

   $BEGIN WORK;

   /* program  logic */
   if((list=get_db_list(&i,DBName)) == (char*)0 )
     {
       EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
       return 0;
     }
/*
   $DECLARE cur CURSOR FOR
    SELECT distinct iupcomp FROM branch;
   $OPEN cur;
   for (i=0;;i++) {
	$FETCH cur INTO $db[i];
   	if (SQLCODE==SQLNOTFOUND) break;
   }
   $CLOSE cur;
*/
   for(j=0;j<i;j++) {
	sprintf_s(tmp, sizeof tmp, "UPDATE %s:car_model_align SET %s=%s",
	  list[j].dbname,
	  "(pdmg_factor_2nd,pbrg_factor_2nd,ddate_2nd)",
	  "(pdmg_factor_1st,pbrg_factor_1st,ddate_1st)");
	$PREPARE q_up from $tmp;
	$EXECUTE q_up;
   }
       $COMMIT WORK;
       EWRITE(userid, M_CM_OK,"All information has been successfully updated");
       return SUCCESS;

errexit:
   printf("SQLCODE=%ld sqlerrm=%s\n",SQLCODE,sqlca.sqlerrm);
   EWRITE(userid, SQLCODE,"Update not successfully");
   $WHENEVER SQLERROR CONTINUE;    
   $ROLLBACK WORK;
   return FAIL;
}
