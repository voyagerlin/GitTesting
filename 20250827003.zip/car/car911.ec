/*************************************************/
/*                                               */
/*   PROGRAM : car911.ec                         */
/*             �z�߰��C�����R��                  */
/*   DATE    : 87.07.07 Maggie                   */
/*   EDIT    : 89.10.30 Peter ���ٳ����אּbatch  */
/*************************************************/
#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include "api_xsrv.h"
#include "sql.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"

#define NEXTPAGE   7

EXEC SQL include sqlca;
EXEC SQL include datetime.h;

EXEC SQL define PETER;

extern char RPTDIR[];

EXEC SQL BEGIN DECLARE SECTION;
     /********* receive data car911_parm ***********/
     char  DBName[5];
     char  iins1[INSURANCE_TYPE], iins2[INSURANCE_TYPE], iins3[INSURANCE_TYPE], iins4[INSURANCE_TYPE];
     char  ibranch_flag[2], ibranch[4];
     char  Ibranch_flag[2];
     char  yymmbgn[7], yymmend[7];
     char  Flag31[2];
     char  outputf[21];

     long  cls_datebgn, cls_dateend;
     char  aBuf[17], aBuf1[17];
     char  dt_datebgn[17], dt_dateend[17];
     /**********************************************/

     /********** car911_build *********/
     char  FormTp[3];
     char  BodyFile[21], BodyFmt[21];
     char  TitleFile[21], TitleFmt[21];
     int   StartRow,TitleRow;
     int   ItemRow, TotColumn;
     int   PgLine, Width = 0;
     /*********************************/

     char  iupbranch[3];         /*** �߮ר��z�������`�����q ***/
     char  stl_unit[50];
     char  adjustment[EMPLOYEE_ID];

     long  qclose, mins_app, mpay, m_proc ,mproc_app;

     char  iapp_unit[BRANCH_ID];
     char  iapp_branch[BRANCH_ID];
     char ibranchy[BRANCH_ID];/**/
     char  iadjuster[EMPLOYEE_ID];
     char  iadjuster_name[11];
     char  nchi_abv_name[15];
     char  nchi_full_name[15];
     char  nchi_unit_name[50];

     long  app_total, stl_total;
     long  p_close, p_1, p_2;/***- EALEX -***/
     long  q_1, q_2, q_3, q_4, q_5, q_6, q_7, q_8;
     long  m_1, m_2, m_3, m_4, m_5, m_6, m_7, m_8;

     long  tot_qclose, tot_mins_app, tot_mpay;
     long  total_app, total_stl;
     long  tot_p_close, tot_p_1, tot_p_2;/***- EALEX -***/
     long  tot_q_1, tot_q_2, tot_q_3, tot_q_4, tot_q_5, tot_q_6, tot_q_7, tot_q_8;
     long  tot_m_1, tot_m_2, tot_m_3, tot_m_4, tot_m_5, tot_m_6, tot_m_7, tot_m_8;

     char  sAdjuster[11], sIclaim[20], sIpolicy[20], sIins_type[6],iapp_unit[3];
     char  sDappraisal[13], sDclose[13], note[31], snassured[121];
     long  lMins_app, lMins_stl;
     int   cnopay;
     char  iinsclass[7];
     char  sWhere0[1024];
     char  branch_tmp1[3];
     char  Full_tmp1[41];
     int   iCntTmp;
     /* char  mindgroup[11]; */
     int mindgroup, mindgroup2;
     int firstdgroup;
     double  est_rate1,accuracy,tot_accuracy;
     char  sIquota[11];

EXEC SQL END DECLARE SECTION;

char  userid[EMPLOYEE_ID];

char  outputf[21];
int   max_count = 0, errCode;
int   tmp_len;

/******* sub_function *******/
long  car911_build();
long  car911_title();
long  car911_grp();
void  car911_body();
void  car911_tot();
double d45();
/****************************/

/*************************************************************************/
main(argc, argv)
int  argc;
char **argv;
{
     int rc;

     /*** receive data ***/
     car911_parm(argc, argv);

EXEC SQL ifdef PETER;
     printf("BEGIN car911_process \n");
EXEC SQL endif;

     car911_process();
EXEC SQL ifdef PETER;
     printf("END   car911_process \n");
EXEC SQL endif;

     rc = car911_build();

     if(rc == M_CM_OK)
     {
         rc = create_sign_form("car911", BodyFile, Width);
         if (rc != 0)
         {
             EWRITE(userid,rc,"create_sign_form failed");
             isEndReport(userid);
             exit(FAIL);
         }
         printf("userid[%s],FormTp[%s],maxcount[%ld],outputf[%s] \n",userid,FormTp,max_count,outputf);
         rc = save_form_info(F_BLK1,"CA",911,userid,FormTp,max_count,outputf);
         if (rc < 0)
         {
             EWRITE(userid,rc,"save_form_info failed");
             isEndReport(userid);
             exit(FAIL);
         }

         EXEC SQL DELETE FROM car911_temp WHERE wkinx = :outputf;
     }
     else
     {
         EWRITE(userid,rc," ");
     }

     rc = car911_build1();
     if( rc != M_CM_OK )
     {
         EWRITE(userid,rc,"save_form_info failed");
         isEndReport(userid);
         exit(FAIL);
     }
}

/*************************************************************************/
car911_parm(argc, argv)
int argc;
char **argv;
{
     batchinit();

     strcpy(DBName,       isNULLstr(argv[1]));
     strcpy(userid,       isNULLstr(argv[2]));

     strcpy(ibranch_flag, isNULLstr(argv[3]));    /*** 1:server 2:ibranch ***/
     strcpy(ibranch,      isNULLstr(argv[4]));

     strcpy(iinsclass,    trim(isNULLstr(argv[5])));

     strcpy(yymmbgn,      isNULLstr(argv[6]));
     strcpy(yymmend,      isNULLstr(argv[7]));

     strcpy(Flag31,       isNULLstr(argv[8]));

     strcpy(outputf,      isNULLstr(argv[9]));

printf("ibranch[%s] Flag31[%s]\n",ibranch, Flag31);

     if(db_select(DBName) == False)
     {
         EWRITE(userid,M_CM_DB_NOTOPEN,"M_CM_DB_NOTOPEN");
         return FAIL;
     }

     strcpy(Ibranch_flag,trim(ibranch_flag));

     /*** ���װ_�l��� ***/
     cls_datebgn = cm_build_date_ym(yymmbgn, 1);
     strcpy(dt_datebgn, cm_edate_str(cls_datebgn));

     /*** ���ײפ��� ***/
     cls_dateend = cm_build_date_ym(yymmend, 2);
     strcpy(dt_dateend, cm_edate_str(cls_dateend));

     if(strcmp(trim(Ibranch_flag),"1") == 0)
     {
         printf("Flag===>1\n");
         strcpy(stl_unit," ");
     }
     else
     {
         printf("Flag===>2\n");
         sprintf_s(stl_unit,50," and c.iapp_unit = %s ",ibranch);
     }

     if (strcmp(trim(Ibranch_flag),"1") == 0)
     {
         strcpy(iupbranch, ibranch);
 EXEC SQL ifdef PETER;
         printf("stl_unit[%s]\n",stl_unit);
         printf("�H�`�����q�O�d��===>iupbranch[%s] \n",iupbranch);
 EXEC SQL endif;
     }
     else
     {
         EXEC SQL SELECT iupbranch
                    INTO :iupbranch
                    FROM branch
                   WHERE ibranch = :ibranch;
 EXEC SQL ifdef PETER;
          printf("�H�߮ר��z���d��===>iupbranch[%s]\n",iupbranch);
 EXEC SQL endif;
     }

EXEC SQL ifdef PETER;
     printf("##### [car9971_parm]:Ibranch_flag[%s], ibranch[%s]\n",Ibranch_flag, ibranch);
     printf("##### [car9971_parm]:iins1[%s], iins2[%s], iins3[%s], iins4[%s]\n",iins1, iins2, iins3, iins4);
     printf("##### [car9971_parm]:dt_datebgn=[%s], dt_dateend=[%s]\n",dt_datebgn,dt_dateend);
EXEC SQL endif;
}

/*******************************************************************************************/
long car911_build()
{
     char  iapp_unit_prev[BRANCH_ID];
     int   rc;
     int   flag_exist = 0;

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     FormTp[0] = '\0';

     EXEC SQL SELECT nTitle_Fmt , nBody_Fmt   , kStart_Row , kTitle_Row,
                     kTot_Col   , kPgNum_Line , kWidth     , iForm_Tp
                INTO :TitleFmt  , :BodyFmt    , :StartRow  , :TitleRow,
                     :TotColumn , :PgLine     , :Width     , :FormTp
                FROM Form
               WHERE ksys_grp = "CA" AND kPgmID = 911
                 AND iForm_Tp = '1';

     strcpy( TitleFmt , rtrim(TitleFmt));
     strcpy( BodyFmt  , rtrim(BodyFmt));
     sprintf_s(TitleFile,21, "%sA.ti", outputf);
     sprintf_s(BodyFile,21, "%sA.bd", outputf);

    printf(">_< build1 ==> TitleFile[%s] BodyFile[%s] \n", TitleFile, BodyFile );

     /* build title */
     rgu_init_report(TitleFmt, TitleFile);

     /*** �I�إN���ѨϥΪ̦ۦ��J ***/
     rc = car911_title();
     if (rc != M_CM_OK) return rc;
     rgu_finish_report();

     /* build body */
     rgu_init_report(BodyFmt, BodyFile);

     /*-------------*/
     max_count = 0;
     qclose = mins_app = mpay = mproc_app = 0;
     app_total = stl_total = accuracy = 0;
     p_close = p_1= p_2 = 0;
     q_1 = q_2 = q_3 = q_4 = q_5 = q_6 = q_7 = q_8 = 0;
     m_1 = m_2 = m_3 = m_4 = m_5 = m_6 = m_7 = m_8 = 0;

     strcpy(iapp_unit_prev, "##");

     EXEC SQL DECLARE Acursor2 CURSOR FOR
               SELECT iapp_unit, iadjuster, SUM(accuracy),SUM(qclose), SUM(app_total), SUM(stl_total),
                      SUM(mins_app), SUM(mpay),
                      SUM(p_close), SUM(p_1), SUM(p_2),
                      SUM(q_1), SUM(m_1), SUM(q_2), SUM(m_2), SUM(q_3), SUM(m_3), SUM(q_4), SUM(m_4),
                      SUM(q_5), SUM(m_5), SUM(q_6), SUM(m_6), SUM(q_7), SUM(m_7), SUM(q_8), SUM(m_8)
                 FROM car911_temp
                WHERE wkinx = :outputf
                GROUP BY iapp_unit, iadjuster
                ORDER BY iapp_unit, iadjuster;
     EXEC SQL OPEN Acursor2;
     while(1)
     {
          qclose=mins_app=mpay=0;
          app_total=stl_total= accuracy = 0;
          p_close=p_1=p_2=0;
          q_1=q_2=q_3=q_4=q_5=q_6=q_7=q_8=0;
          m_1=m_2=m_3=m_4=m_5=m_6=m_7=m_8=0;

          EXEC SQL FETCH Acursor2 INTO :iapp_unit, :iadjuster, :accuracy, :qclose,
                                       :app_total, :stl_total,
                                       :mins_app, :mpay,
                                       :p_close, :p_1, :p_2,
                                       :q_1, :m_1, :q_2, :m_2,
                                       :q_3, :m_3, :q_4, :m_4,
                                       :q_5, :m_5, :q_6, :m_6,
                                       :q_7, :m_7, :q_8, :m_8;

          printf("313accuracy=%f\n",accuracy);

          if(SQLCODE == SQLNOTFOUND) break;
          flag_exist=1;



EXEC SQL ifdef PETER;
          printf("iapp_unit[%s],iadjuster[%s]\n",iapp_unit,iadjuster);
EXEC SQL endif;

          if(strcmp(iapp_unit_prev, "##") == 0)
          {
             rc=car911_grp('1');
             if (rc != M_CM_OK) return rc;
             strcpy(iapp_unit_prev,iapp_unit);
          }
          else if(strcmp(iapp_unit_prev, iapp_unit) != 0)
          {
             car911_tot();
             tot_qclose=tot_mins_app=tot_mpay=0;
             total_app=total_stl=tot_accuracy=0;
             tot_p_close=tot_p_1=tot_p_2=0;
             tot_q_1=tot_q_2=tot_q_3=tot_q_4=tot_q_5=tot_q_6=tot_q_7=tot_q_8=0;
             tot_m_1=tot_m_2=tot_m_3=tot_m_4=tot_m_5=tot_m_6=tot_m_7=tot_m_8=0;
             rgu_put_body(NEXTPAGE);
             strcpy(iapp_unit_prev, iapp_unit);
             rc=car911_grp('1');
             if (rc != M_CM_OK) return rc;
          }

          EXEC SQL SELECT nname
                     INTO :iadjuster_name
                     FROM officer
                    WHERE iofficer = :iadjuster;

          EXEC SQL SELECT nbranch
                     INTO :nchi_unit_name
                     FROM officer a, sa_branch_type b
                    WHERE b.ibranch = a.iquota
                      AND iofficer = :iadjuster;

          EXEC SQL  SELECT nchi_abv,nchi_full
                      INTO :nchi_abv_name, :nchi_full_name
                      FROM branch
                     WHERE ibranch =:iapp_unit;

          car911_body();
          printf("end of car911_body\n");
          /* ��� */
          tot_qclose   += qclose;
          tot_mins_app += mins_app;
          tot_mpay     += mpay;
          total_app    += app_total;
          total_stl    += stl_total;
          tot_accuracy += accuracy;
          tot_p_close  += p_close;
          tot_p_1      += p_1;         tot_p_2      += p_2;
          tot_q_1      += q_1;         tot_m_1      += m_1;
          tot_q_2      += q_2;         tot_m_2      += m_2;
          tot_q_3      += q_3;         tot_m_3      += m_3;
          tot_q_4      += q_4;         tot_m_4      += m_4;
          tot_q_5      += q_5;         tot_m_5      += m_5;
          tot_q_6      += q_6;         tot_m_6      += m_6;
          tot_q_7      += q_7;         tot_m_7      += m_7;
          tot_q_8      += q_8;         tot_m_8      += m_8;

     }
     EXEC SQL CLOSE Acursor2;
     EXEC SQL FREE Acursor2;
EXEC SQL ifdef PETER;
     printf("####### End Acursor2 flag_exist[%ld] \n",flag_exist);
EXEC SQL endif;

     if (flag_exist == 1)
     {
          car911_tot();
          rgu_put_body(NEXTPAGE);

          tot_qclose=tot_mins_app=tot_mpay=0;
          total_app=total_stl=tot_accuracy=0;
          tot_p_close=tot_p_1=tot_p_2=0;
          tot_q_1=tot_q_2=tot_q_3=tot_q_4=tot_q_5=tot_q_6=tot_q_7=tot_q_8=0;
          tot_m_1=tot_m_2=tot_m_3=tot_m_4=tot_m_5=tot_m_6=tot_m_7=tot_m_8=0;

          /*-----all company-----*/
          flag_exist=0;
          rc=car911_grp('2');
          if (rc != M_CM_OK) return rc;

          EXEC SQL DECLARE Acursor3 CURSOR FOR
                    SELECT iapp_unit,iadjuster, SUM(accuracy), SUM(qclose), SUM(app_total), SUM(stl_total), SUM(mins_app), SUM(mpay),
                           SUM(p_close), SUM(p_1), SUM(p_2),
                           SUM(q_1), SUM(m_1), SUM(q_2), SUM(m_2), SUM(q_3), SUM(m_3),
                           SUM(q_4), SUM(m_4), SUM(q_5), SUM(m_5), SUM(q_6), SUM(m_6),
                           SUM(q_7), SUM(m_7), SUM(q_8), SUM(m_8)
                      FROM car911_temp
                     WHERE wkinx = :outputf
                     GROUP BY iapp_unit, iadjuster
                     ORDER BY iapp_unit, iadjuster;
          EXEC SQL OPEN Acursor3;
          while(1)
          {
               qclose=mins_app=mpay=0;
               app_total=stl_total=accuracy=0;
               p_close=p_1=p_2=0;
               q_1=q_2=q_3=q_4=q_5=q_6=q_7=q_8=0;
               m_1=m_2=m_3=m_4=m_5=m_6=m_7=m_8=0;

               EXEC SQL FETCH Acursor3 INTO :iapp_unit,:iadjuster,:accuracy,
                                            :qclose, :app_total, :stl_total,
                                            :mins_app, :mpay,
                                            :p_close, :p_1, :p_2,
                                            :q_1, :m_1, :q_2, :m_2,
                                            :q_3, :m_3, :q_4, :m_4,
                                            :q_5, :m_5, :q_6, :m_6,
                                            :q_7, :m_7, :q_8, :m_8;
               if(SQLCODE == SQLNOTFOUND) break;
               flag_exist=1;

               EXEC SQL   SELECT nname
                            INTO :iadjuster_name
                            FROM officer
                           WHERE iofficer = :iadjuster;

               EXEC SQL SELECT nbranch
                          INTO :nchi_unit_name
                          FROM officer a, sa_branch_type b
                         WHERE b.ibranch = a.iquota
                           AND iofficer = :iadjuster;

                EXEC SQL  SELECT nchi_abv,nchi_full
                            INTO :nchi_abv_name, :nchi_full_name
                            FROM branch
                           WHERE ibranch =:iapp_unit;

               car911_body();

               tot_qclose   += qclose;
               tot_mins_app += mins_app;
               tot_mpay     += mpay;
               total_app    += app_total;
               total_stl    += stl_total;
               tot_accuracy += accuracy;
               tot_p_close  += p_close;
               tot_p_1      += p_1;         tot_p_2      += p_2;
               tot_q_1      += q_1;         tot_m_1      += m_1;
               tot_q_2      += q_2;         tot_m_2      += m_2;
               tot_q_3      += q_3;         tot_m_3      += m_3;
               tot_q_4      += q_4;         tot_m_4      += m_4;
               tot_q_5      += q_5;         tot_m_5      += m_5;
               tot_q_6      += q_6;         tot_m_6      += m_6;
               tot_q_7      += q_7;         tot_m_7      += m_7;
               tot_q_8      += q_8;         tot_m_8      += m_8;
          }
          EXEC SQL CLOSE Acursor3;
          EXEC SQL FREE Acursor3;

          if (flag_exist == 1)
              car911_tot();
     }

     rgu_finish_report();

     return M_CM_OK;

errexit:
  printf("build:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  EXEC SQL DELETE FROM car911_temp WHERE wkinx = :outputf;
  isEndReport(userid);
}

/***************************************************************************/
long car911_title()
{
     EXEC SQL char nname[13];
     char  Buf[16];
     char  yy[4], mm[3], dd[3];

     EXEC SQL WHENEVER SQLERROR GOTO errexit;
EXEC SQL ifdef PETER;
     printf("[car9971_title]:begin of nname\n");
EXEC SQL endif;

     strcpy(Buf,"(");

     if (strcmp(iinsclass,"99",2)==0)
     {
          strcat(Buf,"�����I");
          strcat(Buf,") ");
     }
     else if (strcmp(iinsclass,"98",2)==0)
     {
          strcat(Buf,"���d-�]�l�I");
          strcat(Buf,") ");
     }
     else if (strcmp(iinsclass,"31",2)==0)
     {
          strcat(Buf,"���d-�ˤ`");
          strcat(Buf,") ");
     }
     else
     {
          EXEC SQL SELECT nins_abbr
                     INTO :nname
                     FROM insurance_type
                    WHERE iins_type = :iinsclass;
          if (SQLCODE == SQLNOTFOUND) strcpy(nname," ");
          strcat(Buf,iinsclass);
          strcat(Buf,") ");
          strcat(Buf,nname);
     }

EXEC SQL ifdef PETER;
     printf("[car9971_title]: end of nname\n");
EXEC SQL endif;

     /*-----------*/
EXEC SQL ifdef PETER;
     printf("[car9971_title]:begin of rgu_put_head_string\n");
EXEC SQL endif;

     rgu_put_head_string(1, cm_sysd_cdatetime_100(cm_get_sysd()));
     rgu_put_head_string(1, Buf);
     cm_long_split_3ymd(cls_datebgn, yy, mm, dd);
     rgu_put_head_string(1, yy);
     rgu_put_head_string(1, mm);
     rgu_put_head_string(1, dd);

     cm_long_split_3ymd(cls_dateend, yy, mm, dd);
     rgu_put_head_string(1, yy);
     rgu_put_head_string(1, mm);
     rgu_put_head_string(1, dd);

     rgu_put_head();

     return M_CM_OK;

errexit:
     return SQLCODE;
}

/*************************************************************************/
car911_process()
{
    EXEC SQL BEGIN DECLARE SECTION;
         char   iclaim[CLAIM_NUM];
         char   Iclaim[CLAIM_NUM];
         char   Iins_type[6];

         long   mstl_1, mstl_2;
         short  ind1, ind2;
         double est_rate;

         char   sFullName[20];   /*** �߮ר��z��Ʈw ***/
         char   stmt[3072];
         char   ibranch_in[3];   /*** �߮׫O����ݸ�Ʈw ***/
         char   sFullName1[20];  /*** �O����ݸ�Ʈw ***/
         char   sDappraisal[13], sDclose[13];
         char   ipolicy[20];
         char   istl_note[5], frecover[2];
         int    iclose_type;
         int     PAY_type5;             /***���׭��}***/
         char   nassured[121];          /***�Q�O�I�H***/
         int    PAY_type6;              /***�Τ@�F��***/
         int    PAY_type7;              /***�ڤO�h***/

    EXEC SQL END DECLARE SECTION;

    int     flag_exist, stl_flag;
    int     PAY_type1, PAY_type2, PAY_type3, PAY_type4;

    EXEC SQL WHENEVER SQLERROR GOTO errexit;

    /***- create temp table 20010115 Ealex -***/
    EXEC SQL CREATE TEMP TABLE car911_temp
    (
        wkinx        char(10)    default ' ',
        iapp_unit    char(2)     default ' ',
        iadjuster    char(10)    default ' ',
        accuracy     decimal(9,2),
        qclose       integer     default 0,
        app_total    integer     default 0,
        stl_total    integer     default 0,
        mins_app     integer     default 0,
        mpay         integer     default 0,
        p_close      integer     default 0,
        p_1          integer     default 0,
        p_2          integer     default 0,
        q_1          integer     default 0,
        m_1          integer     default 0,
        q_2          integer     default 0,
        m_2          integer     default 0,
        q_3          integer     default 0,
        m_3          integer     default 0,
        q_4          integer     default 0,
        m_4          integer     default 0,
        q_5          integer     default 0,
        m_5          integer     default 0,
        q_6          integer     default 0,
        m_6          integer     default 0,
        q_7          integer     default 0,
        m_7          integer     default 0,
        q_8          integer     default 0,
        m_8          integer     default 0
    )WITH NO LOG;

    /* �K�ߵ��׻P�w�����B�p��100�����߮ש��� */
    $CREATE TEMP TABLE NOPAY
    (
       adjustment  char(10),
       iclaim      char(20),
       ipolicy     char(20),
       iins_type   char(6),
       nassured    char(120),
       mins_app    integer,
       mins_stl    integer,
       est_rate1   char(30),
       accuracy    char(30),
       note        char(30),
       dappraisal  date,
       dclose      date,
       iapp_unit    char(2)     default ' ',
       iquota       char(10)
    )WITH NO LOG;

    $CREATE INDEX nopay_ix1 ON NOPAY(iclaim);

EXEC SQL ifdef PETER;
    printf("Ibranch_flag[%s],branch[%s]\n",Ibranch_flag,ibranch);
EXEC SQL endif;

    strcpy(sFullName, get_full_dbname(iupbranch));

EXEC SQL ifdef PETER;
    printf("�߮ש��ݸ�Ʈw[%s]\n",sFullName);
EXEC SQL endif;

   $create temp table car911_limit
   (
       iclaim      char(20)
   )with no log;

   $create index car911_limit_ix1 on car911_limit(iclaim);

   if (strncmp(iinsclass,"99",2) == 0)
   {
      /*****
      strcpy(sWhere0," and d.iins_type in (select icode from cu_code_data where itype = 'CT') ");
      *****/
      strcpy(sWhere0," and d.iins_type in (select iins_type                     \
                                             from sysdb:insurance_type          \
                                            where fkind in ('1','2','4','6')    \
                                              and iins_type not in ('238','58')) ");
   }
   else if (strncmp(iinsclass,"98",2) == 0)
   {
      /*****
      strcpy(sWhere0," and d.iins_type in ('93','94','95','32') ");
      *****/
      strcpy(sWhere0," and d.iins_type in (select iins_type                     \
                                             from sysdb:insurance_type          \
                                            where fkind in ('3')                \
                                              and iins_type not in ('238','58')) ");
   }
   else if (strncmp(iinsclass,"31",2) == 0)
   {
      /*****
      strcpy(sWhere0," and d.iins_type in ('93','94','95') ");
      *****/
      strcpy(sWhere0," and d.iins_type in (select iins_type                     \
                                             from sysdb:insurance_type          \
                                            where fkind in ('5','A','B','C','E','F')  \
                                              and iins_type not in ('238','58')) ");
   }
   else
   {
      sprintf_s(sWhere0,1024," and d.iins_type = '%s' ",iinsclass);
   }

   $declare s_cur1 cursor for
     select branch
       from servertbl
      where branch != 'S1'
      order by branch;

   $open s_cur1;
   for(;;)
   {
   $fetch s_cur1 into $branch_tmp1;
   if (SQLCODE == SQLNOTFOUND) break;

       strcpy(Full_tmp1, get_full_dbname(branch_tmp1));

       sprintf_s(stmt,3072,
         "insert into car911_limit   \
          select a.iclaim            \
            from ca_clm_process a, cm_clm_adjuster c, %s:stl_ins_type d    \
           where a.iclaim     = d.iclaim    \
             and a.adjustment = c.empl_no   \
             and d.fstl       = '1'         \
             and d.flast      = '1'         \
              %s %s \
             and d.dgroup >= ? AND d.dgroup <= ? ",Full_tmp1, stl_unit, sWhere0);
       $prepare s_curid from $stmt;
       $execute s_curid using $dt_datebgn, $dt_dateend;

   }
   $close s_cur1;
   $free s_cur1;


   $declare s_cur2 cursor for
     select branch
       from servertbl
      where branch != 'S1'
        and ((branch = $iupbranch) or ('*' = $iupbranch) or (branch = (select iupcomp from branch where ibranch = $iupbranch)))
      order by branch;

   $open s_cur2;
   for(;;)
   {
   $fetch s_cur2 into $branch_tmp1;
   if (SQLCODE == SQLNOTFOUND) break;

   strcpy(sFullName, get_full_dbname(branch_tmp1));

    /*** �� SELECT ���z��쪺:�߮׸��X(iclaim)�B�z�߭�(iadjuster)�B�O������`�����q(ibranch_in) ***/
    /* �z�߭����ca_clm_process�����(�̷s�z�߭�) modify by sylvia 110.03.04 (1100120012_SC1) */
	sprintf_s(stmt, 3072, "SELECT DISTINCT b.iclaim, b.adjustment, b.ibranch_in , c.iapp_unit , b.ipolicy , b.dappraisal , b.dclose , b.affiliated  \
						     FROM ca_clm_process b \
					   INNER JOIN cm_clm_adjuster c ON b.adjustment = c.empl_no \
					   INNER JOIN %s:ca_local_clm a ON a.iclaim = b.iclaim \
						    WHERE b.iclaim[6] != 'C' \
						      AND b.iclaim in (select iclaim from car911_limit) \
							   %s \
						 ORDER BY b.iclaim ", sFullName, stl_unit);
	
    EXEC SQL PREPARE  A_1 FROM :stmt;

EXEC SQL ifdef PETER;
    printf("### car911_process stmt[%s] \n",stmt);
EXEC SQL endif;

    EXEC SQL DECLARE Acursor1 CURSOR FOR A_1;
    EXEC SQL OPEN Acursor1;
    printf("dt_datebgn[%s]\n",dt_datebgn);
    printf("dt_dateend[%s]\n",dt_dateend);
    while(1)
    {
         EXEC SQL FETCH Acursor1 INTO :iclaim , :adjustment , :ibranch_in , :iapp_branch ,
                                      :ipolicy, :sDappraisal, :sDclose, :sIquota;
         if(SQLCODE == SQLNOTFOUND) break;

         strcpy(sFullName1, get_full_dbname(ibranch_in)); /*** �O����ݸ�Ʈw ***/


         sprintf_s(stmt,3072,"SELECT DISTINCT d.iclaim , d.iins_type  \
                         FROM %s:stl_ins_type d \
                        WHERE d.iclaim   = '%s' \
                          AND d.fstl     = '1'  \
                          AND d.flast    = '1'  \
                          AND not exists (select *    \
                                            from %s:stl_ins_type x             \
                                           where x.iclaim     = d.iclaim       \
                                             and x.fstl       = d.fstl         \
                                             and x.iins_type  = d.iins_type    \
                                             and x.fstl       = '1'            \
                                             and x.flast      = '1'            \
                                             and x.dgroup     < ? )            \
                          AND d.dgroup  >= ? AND d.dgroup <= ?  \
                          %s \
                        ORDER BY d.iclaim ",sFullName1, iclaim, sFullName1, sWhere0);

         printf("stmt[%s]\n",stmt);
         EXEC SQL PREPARE  A_11 FROM :stmt;
         EXEC SQL DECLARE  Acursor11 CURSOR FOR A_11;
         EXEC SQL OPEN     Acursor11 USING :dt_datebgn, :dt_datebgn, :dt_dateend;
         while(1)
         {
              EXEC SQL FETCH Acursor11 INTO :Iclaim , :Iins_type;
              if (SQLCODE == SQLNOTFOUND) break;

              mins_app = mstl_1 = mstl_2 = mpay = mproc_app = 0;
              qclose = 0;
              app_total = stl_total = 0;
              est_rate = 0;
              p_close = 0;
              p_1 = p_2 = 0;
              q_1 = q_2 = q_3 = q_4 = q_5 = q_6 = q_7 = q_8 = 0;
              m_1 = m_2 = m_3 = m_4 = m_5 = m_6 = m_7 = m_8 = 0;

              /*-----------------*/
              flag_exist = 0;

              stmt[0] = '\0';
              sprintf_s(stmt,3072,"SELECT SUM(mins_stl) , SUM(mins_proc)\
                              FROM %s:stl_ins_type  \
                             WHERE iclaim    = '%s' \
                               AND iins_type = '%s' \
                               AND fstl      = '1'  \
                               AND dgroup   <= ?  ",sFullName1,Iclaim,Iins_type);
              printf("stmt[%s]\n",stmt);
              EXEC SQL PREPARE  stl_type FROM :stmt;
              EXEC SQL DECLARE  stl_type_cur CURSOR FOR stl_type;
              EXEC SQL OPEN     stl_type_cur USING $dt_dateend;
              EXEC SQL FETCH    stl_type_cur INTO :mstl_1, :m_proc;
              EXEC SQL CLOSE    stl_type_cur;
              EXEC SQL FREE     stl_type_cur;

              mpay += mstl_1; qclose ++;

              /*��ڰl�ߪ��B�`�M = 0 ���C�J����*/
              if(mpay == 0)
              {
              	continue;
              }

              stmt[0] = '\0';
              /*
              sprintf_s(stmt,3072,"select count(*)          \
                              from cu_code_data      \
                             where itype = 'CT'      \
                               and icode = '%s' ", Iins_type);
             
              printf("stmt[%s]\n",stmt);
              $prepare cuid1 from $stmt;
              $execute cuid1 into $iCntTmp;
              */

      

              /****************************************************************************
              if ((iCntTmp > 0) || (strncmp(Iins_type,"32",2) == 0))     ����B�]�l�I ��l�w�����B   
              {
                 sprintf_s(stmt,3072,"SELECT first 1 mins_app, mproc_app \
                                 FROM %s:app_ins_type_hist        \
                                WHERE iclaim    = '%s'             \
                                  AND iins_type = '%s'            \
                                ORDER BY dappraisal ",sFullName1,Iclaim,Iins_type);
                 printf("stmt[%s]\n",stmt);
              }
              else if ((strncmp(Iins_type,"93",2) == 0) || (strncmp(Iins_type,"94",2) == 0) || (strncmp(Iins_type,"95",2) == 0))
              {
                 �Y���@�Ӥ뤺���ת��A�h������׫e�̫�@���ק蠟�w�����B modify by sylvia 107.02.07 (1060725007_SC1) 
                 sprintf_s(stmt,3072,"select min(dgroup) - 30,   \
                                      (select min(dappraisal) from %s:app_ins_type_hist \
                                        where iclaim = a.iclaim and iins_type = a.iins_type) \
                                 from %s:stl_ins_type a  \
                                where iclaim    = '%s'   \
                                  and iins_type = '%s'   \
                                  and fstl      = '1'    \
                                  and flast     = '1'    \
                                  and dgroup >= ? and dgroup <= ? \
                                  group by 2",sFullName1,sFullName1,Iclaim,Iins_type);
                 printf("stmt[%s]\n",stmt);
                 $prepare mindgroup from $stmt;
                 $execute mindgroup into $mindgroup, $mindgroup2 using $dt_datebgn, $dt_dateend;

                 printf("���� mindgroup=[%d]  mindgroup2=[%d]\n",mindgroup,mindgroup2);

                 if (mindgroup < mindgroup2)
                     mindgroup = mindgroup2;    ���פ�-30�� < �Ĥ@���w����, �����H�Ĥ@���w���鬰��Ǥ� 

                 sprintf_s(stmt,3072,"SELECT first 1 mins_app, mproc_app \
                                 FROM %s:app_ins_type_hist        \
                                WHERE iclaim      = '%s'          \
                                  AND iins_type   = '%s'          \
                                  AND dappraisal <= %d           \
                                ORDER BY dappraisal desc ",sFullName1,Iclaim,Iins_type,mindgroup);
                 printf("stmt[%s]\n",stmt);
              }
              else
              {
                 sprintf_s(stmt,3072,"SELECT mins_app,mproc_app \
                                 FROM %s:app_ins_type    \
                                WHERE iclaim    = '%s'   \
                                  AND iins_type = '%s' ",sFullName1,Iclaim,Iins_type);
                 printf("stmt[%s]\n",stmt);
              }
              ****************************************************************************/
			  
              printf("this Iins_type[%s], iinsclass[%s]\n",Iins_type, iinsclass);

              if (strncmp(iinsclass,"31",2) == 0 || Flag31[0] == '1')
              {
                 /* �Y���@�Ӥ뤺���ת��A�h������׫e�̫�@���ק蠟�w�����B modify by sylvia 107.02.07 (1060725007_SC1)  */
                 sprintf_s(stmt,3072,"select min(dgroup) - 30,   \
                                      (select min(dappraisal) from %s:app_ins_type_hist \
                                        where iclaim = a.iclaim and iins_type = a.iins_type), \
                                      min(dgroup)        \
                                 from %s:stl_ins_type a  \
                                where iclaim    = '%s'   \
                                  and iins_type = '%s'   \
                                  and fstl      = '1'    \
                                  and flast     = '1'    \
                                  and dgroup >= ? and dgroup <= ? \
                                  group by 2 ",sFullName1,sFullName1,Iclaim,Iins_type);
                 printf("stmt[%s]\n",stmt);
                 $prepare mindgroup from $stmt;
                 $execute mindgroup into $mindgroup, $mindgroup2, $firstdgroup using $dt_datebgn, $dt_dateend;

                 printf("���� mindgroup=[%d]  mindgroup2=[%d]\n",mindgroup,mindgroup2);

                 /******
                 if (mindgroup < mindgroup2)
                     mindgroup = mindgroup2; 
                 ******/

                 /*   ���פ�-30�� < �Ĥ@���w����, �����H�Ĥ@���w���鬰��Ǥ�
                      1121024 �t���P�a�F�g�z�Q�סA�Y���פ�-30�ѵL�w����ơA�h������0���p��
                 */                 

                 if (mindgroup < mindgroup2)
                 {
                    sprintf_s(stmt,3072,"SELECT first 1 nvl(mins_app,0), nvl(mproc_app,0) \
                                    FROM %s:app_ins_type_hist        \
                                   WHERE iclaim      = '%s'          \
                                     AND iins_type   = '%s'          \
                                     AND dappraisal <= %d           \
                                   ORDER BY dappraisal desc ",sFullName1,Iclaim,Iins_type,firstdgroup);
                 }
                 else
                 {
                    sprintf_s(stmt,3072,"SELECT first 1 nvl(mins_app,0), nvl(mproc_app,0) \
                                    FROM %s:app_ins_type_hist        \
                                   WHERE iclaim      = '%s'          \
                                     AND iins_type   = '%s'          \
                                     AND dappraisal <= %d           \
                                   ORDER BY dappraisal desc ",sFullName1,Iclaim,Iins_type,mindgroup);
                 }
                 printf("stmt[%s]\n",stmt);
                  

                 /*****
                 if (strncmp(iinsclass,"31",2) != 0)
                 {
                     if (mindgroup < mindgroup2)
                     {
                         sprintf_s(stmt,3072,"SELECT first 1 nvl(mins_app,0), nvl(mproc_app,0)      \
                                                FROM %s:app_ins_type_hist    \
                                               WHERE iclaim      = '%s'   \
                                                 AND iins_type   = '%s'   \
                                                 AND dappraisal <= (select dclaim+30 from sysdb:ca_clm_process where iclaim = '%s') \
                                               ORDER BY dappraisal desc ",sFullName1,Iclaim,Iins_type,Iclaim);
                         printf("stmt[%s]\n",stmt);
                     }
                 }
                 *****/
              }
              else
              {
                 sprintf_s(stmt,3072,"SELECT first 1 nvl(mins_app,0), nvl(mproc_app,0)      \
                                 FROM %s:app_ins_type_hist    \
                                WHERE iclaim      = '%s'   \
                                  AND iins_type   = '%s'   \
                                  AND dappraisal <= (select dclaim+30 from sysdb:ca_clm_process where iclaim = '%s') \
                                 ORDER BY dappraisal desc ",sFullName1,Iclaim,Iins_type,Iclaim);
                 printf("stmt[%s]\n",stmt);
              }
              

              /******
              if ((strncmp(Iins_type,"238",3) == 0) || (strncmp(Iins_type,"58",2) == 0))
              {
                 sprintf_s(stmt,3072,"SELECT nvl(mins_app,0), nvl(mproc_app,0) \
                                 FROM %s:app_ins_type    \
                                WHERE iclaim    = '%s'   \
                                  AND iins_type = '%s' ",sFullName1,Iclaim,Iins_type);
                 printf("stmt[%s]\n",stmt);
              }
              else
              {
                 sprintf_s(stmt,3072,"SELECT nvl(mins_app,0), nvl(mproc_app,0)      \
                                 FROM %s:app_ins_type_hist    \
                                WHERE iclaim      = '%s'   \
                                  AND iins_type   = '%s'   \
                                  AND dappraisal <= (select dclaim+30 from sysdb:ca_clm_process where iclaim = '%s') \
                                 ORDER BY dappraisal desc ",sFullName1,Iclaim,Iins_type,Iclaim);
                 printf("stmt[%s]\n",stmt);
              }
              ******/           
			  
              EXEC SQL PREPARE  app_type FROM :stmt;
              EXEC SQL DECLARE  app_type_cur CURSOR FOR app_type;
              EXEC SQL OPEN     app_type_cur;
              EXEC SQL FETCH    app_type_cur INTO :mins_app,:mproc_app;
              if (SQLCODE == SQLNOTFOUND)
              {
                  mins_app = 0;
                  mproc_app = 0;
              }
              EXEC SQL CLOSE    app_type_cur;
              EXEC SQL FREE     app_type_cur;

              sprintf_s(stmt,3072,"SELECT a.iclose_type, a.istl_note, a.frecover \
                              FROM %s:settlement a \
                             WHERE a.iclaim = '%s' AND a.fstl = '1' \
                               AND exists (select *  \
                                             from %s:stl_ins_type b  \
                                            where a.iclaim       =  b.iclaim  \
                                              and a.fstl         =  b.fstl    \
                                              and a.iclose_type  =  b.iclose_type    \
                                              and b.iins_type    =  '%s'             \
                                              and dgroup >= '%s' AND dgroup <= '%s') \
                             ORDER BY 1 ", sFullName1, Iclaim, sFullName1, Iins_type, dt_datebgn, dt_dateend);
              printf("stmt[%s]\n",stmt);

              $PREPARE cur_set1 FROM $stmt;
              $DECLARE cur_set2 CURSOR for cur_set1;
              $OPEN cur_set2;
              $FETCH cur_set2 INTO $iclose_type, $istl_note, $frecover;
              if( SQLCODE == SQLNOTFOUND )
              {
                 strcpy( istl_note ," ");
                 strcpy( frecover  ," ");
              }
              $CLOSE cur_set2;
              $FREE  cur_set2;

              /**** 1030625  dclose -> dgroup �אּ�ϥηJ�p��� ****/
              sprintf_s(stmt,3072," select min(dgroup)          \
                               from %s:stl_ins_type      \
                              where iclaim      = '%s'   \
                                and fstl        = '1'    \
                                and iclose_type =  ?     \
                                and iins_type   = '%s'   \
                                and dgroup >= '%s' AND dgroup <= '%s' ",sFullName1, Iclaim, Iins_type, dt_datebgn , dt_dateend);
              $prepare get_dgroup_1 from $stmt;
              $execute get_dgroup_1
                  into $sDclose
                 using $iclose_type;

              /** type1->�K�� type2->�w�۰l type3->100�� type4->�e�q type5->���׭��}**/

              mins_app = mins_app + mproc_app;
              PAY_type1 = PAY_type2 = PAY_type3 =  PAY_type4 = PAY_type5 = PAY_type6 = PAY_type7 = 0;
              stl_flag = 1;
              strcpy( note ," ");

              sprintf_s(stmt,3072,"SELECT count(*) from %s:ca_local_stl where iclaim = '%s' and fclose = '1' ",sFullName,Iclaim);
              $PREPARE cur_fclose from $stmt;
              $DECLARE cur_fclose1 CURSOR for cur_fclose;
              $OPEN cur_fclose1;
              $FETCH cur_fclose1 INTO $PAY_type5;

              sprintf_s(stmt,3072,"SELECT count(*) from %s:adjustment_ply where iclaim = '%s' and nassured like '%%�Τ@�F��%%' ",sFullName1,Iclaim);
              $PREPARE cur_tko1 from $stmt;
              $DECLARE cur_tko2 CURSOR for cur_tko1;
              $OPEN cur_tko2;
              $FETCH cur_tko2 INTO $PAY_type6;

              sprintf_s(stmt,3072,"SELECT count(*) from %s:adjustment_ply where iclaim = '%s' and nassured like '%%�ڤO�h%%' ",sFullName1,Iclaim);
              $PREPARE cur_olz1 from $stmt;
              $DECLARE cur_olz2 CURSOR for cur_olz1;
              $OPEN cur_olz2;
              $FETCH cur_olz2 INTO $PAY_type7;

              sprintf_s(stmt,3072,"SELECT nassured from %s:adjustment_ply where iclaim = '%s' ",sFullName1,Iclaim);
              $PREPARE cur_nassured from $stmt;
              $DECLARE cur_nassured1 CURSOR for cur_nassured;
              $OPEN cur_nassured1;
              $FETCH cur_nassured1 INTO $nassured;

              if( mins_app <= 100 )
              {
                 PAY_type3 = 1;
              }

              if (mpay == 0)
              {
                  est_rate = 0;
                  PAY_type1 = 1;
              }
              else
                  est_rate = (double)((double)abs(mins_app - mpay) / mpay * 100);

              if( strcmp( trim(istl_note) , "016") == 0 )
              {
                  PAY_type4 = 1;
                  stl_flag  = 0;
              }

              if( strcmp( frecover , "2") == 0 )
              {
                  PAY_type2 = 1;
                  stl_flag = 0;
              }

              if (PAY_type5 >= 1)
                      stl_flag = 0;

              if (PAY_type6 == 1)
                      stl_flag = 0;

              if (PAY_type7 == 1)
                      stl_flag = 0;

              /*�u�p���V�~�t�M���*/
              if(stl_flag == 0)
              {
              	continue;
              }

        /**** �w�����B app_ins_type.mins_app ****/
        /**** ��ߪ��B stl_ins_type.sum(mins_proc + mins_stl)=mpay ****/

              if( (stl_flag == 1 ) && (mpay > 0)) /***- ��V�~�t�M�����ҥ~ -***/
              {
                  p_close ++;/***- ��V�~�t�M��� -***/
                  if (mins_app >= mpay)/***- ��V�~�t�M -***/
                  {
                      p_1 = mins_app - mpay;
                  }
                  else
                  {
                      p_1 = mpay - mins_app;
                  }
                  p_2 += mpay;/***- ����`�B -***/
              }

              if (mins_app >= mpay)
              {
                  if (est_rate < 10)
                  {
                      q_1 ++;
                      m_1 += mpay;
                  }
                  else if (est_rate >= 10 && est_rate < 20)
                  {
                      q_2 ++;
                      m_2 += mpay;
                  }
                  else if (est_rate >= 20 && est_rate < 30)
                  {
                      q_3 ++;
                      m_3 += mpay;
                  }
                  else
                  {
                      q_4 ++;
                      m_4 += mpay;
                  }
              }
              else
              {
                  if (est_rate < 10)
                  {
                      q_5 ++;
                      m_5 += mpay;
                  }
                  else if (est_rate >= 10 && est_rate < 20)
                  {
                      q_6 ++;
                      m_6 += mpay;
                  }
                  else if (est_rate >= 20 && est_rate < 30)
                  {
                      q_7 ++;
                      m_7 += mpay;
                  }
                  else
                  {
                      q_8 ++;
                      m_8 += mpay;
                  }
              }

              if(mins_app == 0)
              {
              	est_rate1 = d45((double)((double)abs(10 - mpay) / mpay * 100),2);
              	printf("mpay = %d , est_rate1 = %f \n",mpay,est_rate1);
              }
              else
              {
              	est_rate1 = d45((double)((double)abs(mins_app - mpay) / mpay * 100),2);
                printf("mpay = %d , est_rate1 = %f \n",mpay,est_rate1);
              }

              if(est_rate1 >= 100)
              {
              	accuracy = 0 ;
              	printf("accuracy = %f \n",accuracy);
              }
              else
              {
              	accuracy = 100 - est_rate1 ;
              	printf("accuracy = %f \n",accuracy);
              }



              if( PAY_type1 == 1 )
                 strcat(note,"�K��,");

              if( PAY_type2 == 1 )
                 strcat(note,"�w�۰l,");

              if( PAY_type3 == 1 )
                 strcat(note,"100��,");

              if( PAY_type4 == 1 )
                 strcat(note,"�ĳq,");

              if( PAY_type5 == 1)
                      strcat(note,"���׭��},");

              if( PAY_type6 == 1)
                      strcat(note,"�Τ@�F��,");

              if( PAY_type7 == 1)
                      strcat(note,"�ڤO�h,");

              $INSERT INTO NOPAY
               ( adjustment, iclaim, ipolicy, nassured, iins_type,
                 mins_app, mins_stl, est_rate1, accuracy, note, dappraisal, dclose,iapp_unit, iquota)
               VALUES
               ( $adjustment, $iclaim, $ipolicy, $nassured, $Iins_type,
                 $mins_app, $mpay, $est_rate1, $accuracy, $note, $sDappraisal, $sDclose, $iapp_branch, $sIquota);

              app_total += mins_app;
              stl_total = stl_total + mpay + m_proc ;

              output_record();

         }
         EXEC SQL CLOSE  Acursor11;
    }
    EXEC SQL CLOSE Acursor1;
    EXEC SQL FREE  Acursor1;

   }
   $close s_cur2;
   $free s_cur2;

    return SUCCESS;

errexit:
  printf("car911_process:SQLCODE[%d], errstr[%s]",SQLCODE, sqlca.sqlerrm);
  isEWRITE(SQLCODE, sqlca.sqlerrm);
  isfinish(SQLCODE);
}

/*************************************************************************/
output_record()
{

    EXEC SQL INSERT INTO car911_temp
                        (wkinx, iapp_unit, iadjuster, accuracy ,qclose, app_total, stl_total, mins_app, mpay,
                         p_close, p_1, p_2,
                         q_1, m_1, q_2, m_2, q_3, m_3, q_4, m_4,
                         q_5, m_5, q_6, m_6, q_7, m_7, q_8, m_8 )
                 VALUES (:outputf, :iapp_branch, :adjustment, :accuracy, :qclose, :app_total, :stl_total, :mins_app, :mpay,
                         :p_close, :p_1, :p_2,
                         :q_1, :m_1, :q_2, :m_2, :q_3, :m_3, :q_4, :m_4,
                         :q_5, :m_5, :q_6, :m_6, :q_7, :m_7, :q_8, :m_8);

errexit:
  return SQLCODE;
}
/***************************************************************************/
long car911_grp(type)
char type;
{
     EXEC SQL char nchi_abv[13];
     char  Buf[16];

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     if (type == '1')
     {
         EXEC SQL SELECT nchi_abv INTO :nchi_abv
                    FROM branch
                   WHERE ibranch = :iapp_unit;
         if (SQLCODE == SQLNOTFOUND) strcpy(nchi_abv," ");
         strcpy(Buf,"(");
         strcat(Buf,iapp_unit);
         strcat(Buf,") ");
         strcat(Buf,nchi_abv);
EXEC SQL ifdef PETER;
         printf("*****>Iapp_unit[%s], Nchi_abv[%s]\n",iapp_unit,nchi_abv);
EXEC SQL endif;
     }
     else if (type == '2')
     {
         strcpy(Buf,"(�����q)");
     }
     rgu_put_body_string(1,Buf,LEFT);
     rgu_put_body(1);
     max_count++;

     return M_CM_OK;

errexit:
  return SQLCODE;
}


/***************************************************************************/
void car911_body()
{
     char  Buf[8];
     short j;
     long t1,t2,t3,t4,t5,t6,t7,t8,t9,t11,t12;
     double accuracy2,estimate2;

EXEC SQL ifdef PETER;
     printf("car911_body start\n");
EXEC SQL endif;

     t1=t2=t3=t4=0;
     t5=t6=t7=t8=t9=0;
     t11=t12=0;

     /*field1*/
     rgu_put_body_string(2, nchi_abv_name, LEFT);
     rgu_put_body_string(2, nchi_unit_name, LEFT);
     rgu_put_body_string(2, nchi_full_name, LEFT);
     rgu_put_body_string(2, iadjuster_name, LEFT);

     /*field2*/
     /*rfmtlong(qclose,   "###,##&", Buf);
     rgu_put_body_string(2, Buf, RIGHT);*/

     /********* �w���`�B ***************/
     /*t11 =( (app_total/1000)+0.5);

     rfmtlong(app_total, "##,###,##&", Buf);
     printf("-------- app_total[%s]\n",Buf);
     rgu_put_body_string(2, Buf, RIGHT);*/

     /********* �߰l�`�B ***************/
     /*t12 =( (stl_total/1000)+0.5);

     rfmtlong(stl_total, "##,###,##&", Buf);
     printf("-------- stl_total[%s]\n",Buf);
     rgu_put_body_string(2, Buf, RIGHT);*/

     /*field3*/
     /*rfmtdouble((double) (t11 - t12)/ t12*100, "---&.&&", Buf);
     printf("-------- estimate rate[%s]\n",Buf);
     rgu_put_body_string(2, Buf, RIGHT);

     /********** ��V�~�t�M��� **********/
     /*field4*/
     rfmtlong(p_close,   "###,##&", Buf);
     rgu_put_body_string(2, Buf, RIGHT);


     accuracy2 = accuracy/(double)p_close;
     estimate2 = 100 - accuracy2;

     printf("accuracy=%f p_close=%d iadjuster_name=%s\n",accuracy,p_close,iadjuster_name);
     printf("accuracy2=%f estimate2=%f \n",accuracy2,estimate2);

     rfmtdouble(estimate2, "---&.&&", Buf);
     rgu_put_body_string(2, Buf, RIGHT);

     rfmtdouble(accuracy2, "---&.&&", Buf);
     rgu_put_body_string(2, Buf, RIGHT);

     /********** ��V�~�t�M **************/
     /*field5*/
     /*rfmtlong(p_1, "##,###,##&", Buf);
     printf("-------- p_1[%s]\n",Buf);
     rgu_put_body_string(2, Buf, RIGHT);*/

     /********** ����`�B ****************/
     /*field6*/
     /*rfmtlong(p_2, "##,###,##&", Buf);
     printf("-------- p_2[%s]\n",Buf);
     rgu_put_body_string(2, Buf, RIGHT);*/

     /*field7*/
     /*rfmtlong(q_1,   "##,##&", Buf);
     rgu_put_body_string(2, Buf, RIGHT);*/

     /*field8*/
     /*t1 =( (m_1/1000)+0.5);
     rfmtlong(m_1, "##,###,##&", Buf);
     printf("-------- m_1[%s]\n",Buf);
     rgu_put_body_string(2, Buf, RIGHT);*/

     /*field9*/
     /*rfmtlong(q_2,   "##,##&", Buf);
     rgu_put_body_string(2, Buf, RIGHT);*/

     /*field10*/
     /*t2 =((m_2/1000)+0.5);
     rfmtlong(m_2, "##,###,##&", Buf);
     printf("-------- m_2[%s]\n",Buf);
     rgu_put_body_string(2, Buf, RIGHT);*/

     /*field11*/
     /*rfmtlong(q_3,   "##,##&", Buf);
     rgu_put_body_string(2, Buf, RIGHT);*/

     /*field12*/
     /*t3 =( (m_3/1000)+0.5);
     rfmtlong(m_3, "##,###,##&", Buf);
     printf("-------- m_3[%s]\n",Buf);
     rgu_put_body_string(2, Buf, RIGHT);*/

     /*field13*/
     /*rfmtlong(q_4,   "##,##&", Buf);
     rgu_put_body_string(2, Buf, RIGHT);*/

     /*field14*/
     /*t4 =( (m_4/1000)+0.5);
     rfmtlong(m_4, "##,###,##&", Buf);
     printf("-------- m_4[%s]\n",Buf);
     rgu_put_body_string(2, Buf, RIGHT);*/

     /*field15*/
     /*rfmtlong(q_5,   "##,##&", Buf);
     rgu_put_body_string(2, Buf, RIGHT);*/

     /*field16*/
     /*t5 =( (m_5/1000)+0.5);
     rfmtlong(m_5, "##,###,##&", Buf);
     printf("-------- m_5[%s]\n",Buf);
     rgu_put_body_string(2, Buf, RIGHT);*/

     /*field17*/
     /*rfmtlong(q_6,   "##,##&", Buf);
     rgu_put_body_string(2, Buf, RIGHT);*/

     /*field18*/
     /*t6 =( (m_6/1000)+0.5);
     rfmtlong(m_6, "##,###,##&", Buf);
     printf("-------- m_6[%s]\n",Buf);
     rgu_put_body_string(2, Buf, RIGHT);*/

     /*field19*/
     /*rfmtlong(q_7,   "##,##&", Buf);
     rgu_put_body_string(2, Buf, RIGHT);*/

     /*field20*/
     /*t7 =( (m_7/1000)+0.5);
     rfmtlong(m_7, "##,###,##&", Buf);
     printf("-------- m_7[%s]\n",Buf);
     rgu_put_body_string(2, Buf, RIGHT);*/

     /*field21*/
     /*rfmtlong(q_8,   "##,##&", Buf);
     rgu_put_body_string(2, Buf, RIGHT);*/

     /*field22*/
     /*t8 =( (m_8/1000)+0.5);
     rfmtlong(m_8, "##,###,##&", Buf);
     printf("-------- m_8[%s]\n",Buf);
     rgu_put_body_string(2, Buf, RIGHT);*/

     rgu_put_body(2);
     max_count++;

}

/***************************************************************************/
void car911_tot()
{
     char   Buf1[8];
     long a1,a2,a3,a4,a5,a6,a7,a8,a9,ta,tb;
     double accuracy3,estimate3;

     a1=a2=a3=a4=a5=0;
     a6=a7=a8=a9=ta=tb=0;

     rgu_put_body(3);  /*���j�u*/
     max_count++;

     /*rfmtlong(tot_qclose,   "###,##&", Buf1);
     rgu_put_body_string(4, Buf1, RIGHT);

     ta = (total_app/1000+0.5);
     rfmtlong(total_app,   "##,###,##&", Buf1);
     rgu_put_body_string(4, Buf1, RIGHT);

     tb = (total_stl/1000+0.5);
     rfmtlong(total_stl,   "##,###,##&", Buf1);
     rgu_put_body_string(4, Buf1, RIGHT);

     rfmtdouble((double) (tot_mins_app-tot_mpay)/tot_mpay*100, "---&.&&", Buf1);
     rgu_put_body_string(4, Buf1, RIGHT);*/

     rfmtlong(tot_p_close,   "###,##&", Buf1);
     rgu_put_body_string(4, Buf1, RIGHT);

     /*accuracy3 = tot_accuracy/tot_p_close;
     estimate3 = 100 - accuracy3;

     rfmtdouble(estimate3, "---&.&&", Buf1);
     rgu_put_body_string(4, Buf1, RIGHT);

     rfmtdouble(accuracy3, "---&.&&", Buf1);
     rgu_put_body_string(4, Buf1, RIGHT);*/


     /*rfmtlong(tot_p_1,   "##,###,##&", Buf1);
     rgu_put_body_string(4, Buf1, RIGHT);

     rfmtlong(tot_p_2,   "##,###,##&", Buf1);
     rgu_put_body_string(4, Buf1, RIGHT);

     rfmtlong(tot_q_1, "##,##&", Buf1);
     rgu_put_body_string(4, Buf1, RIGHT);
     a1 = (tot_m_1/1000+0.5);
     rfmtlong(tot_m_1,"##,###,##&", Buf1);
     rgu_put_body_string(4, Buf1, RIGHT);

     rfmtlong(tot_q_2, "##,##&", Buf1);
     rgu_put_body_string(4, Buf1, RIGHT);
     a2 = (tot_m_2/1000+0.5);
     rfmtlong(tot_m_2,"##,###,##&", Buf1);
     rgu_put_body_string(4, Buf1, RIGHT);

     rfmtlong(tot_q_3, "##,##&", Buf1);
     rgu_put_body_string(4, Buf1, RIGHT);
     a3 = (tot_m_3/1000+0.5);
     rfmtlong(tot_m_3,"##,###,##&", Buf1);
     rgu_put_body_string(4, Buf1, RIGHT);

     rfmtlong(tot_q_4, "##,##&", Buf1);
     rgu_put_body_string(4, Buf1, RIGHT);
     a4 = (tot_m_4/1000+0.5);
     rfmtlong(tot_m_4,"##,###,##&", Buf1);
     rgu_put_body_string(4, Buf1, RIGHT);

     rfmtlong(tot_q_5, "##,##&", Buf1);
     rgu_put_body_string(4, Buf1, RIGHT);
     a5 = (tot_m_5/1000+0.5);
     rfmtlong(tot_m_5,"##,###,##&", Buf1);
     rgu_put_body_string(4, Buf1, RIGHT);

     rfmtlong(tot_q_6, "##,##&", Buf1);
     rgu_put_body_string(4, Buf1, RIGHT);
     a6 = (tot_m_6/1000+0.5);
     rfmtlong(tot_m_6,"##,###,##&", Buf1);
     rgu_put_body_string(4, Buf1, RIGHT);

     rfmtlong(tot_q_7, "##,##&", Buf1);
     rgu_put_body_string(4, Buf1, RIGHT);
     a7 = (tot_m_7/1000+0.5);
     rfmtlong(tot_m_7,"##,###,##&", Buf1);
     rgu_put_body_string(4, Buf1, RIGHT);

     rfmtlong(tot_q_8, "##,##&", Buf1);
     rgu_put_body_string(4, Buf1, RIGHT);
     a8 = (tot_m_8/1000+0.5);
     rfmtlong(tot_m_8,"##,###,##&", Buf1);
     rgu_put_body_string(4, Buf1, RIGHT);*/

     rgu_put_body(4);
     rgu_put_body(5);  /* �ťզ� */
     rgu_put_body(6);
     max_count += 3;
}


/*************************************************************************/
long car911_build1()
{
   $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];
    char  Buf1[11];
   $char  sTmp[31];

   int    rc;

   max_count = 0;
   $WHENEVER SQLERROR GOTO errexit;

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt,  $StartRow,  $TitleRow,  $ItemRow,
           $TotColumn, $PgLine, $Width, $FormTp
      FROM Form
     WHERE ksys_grp = "CA" AND kPgmID = 911
       AND iForm_Tp = '2';

   strcpy(TitleFmt,rtrim(TitleFmt));
   sprintf_s(TitleFile,21,"%sB.ti",outputf);
   strcpy(BodyFmt, rtrim(BodyFmt));
   sprintf_s(BodyFile,21, "%sB.bd",outputf);

   printf(">_< build1 ==> TitleFile[%s] BodyFile[%s] \n", TitleFile, BodyFile );

   rgu_init_report(TitleFmt,TitleFile);
   car911_title1();
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);

   $DECLARE cur_nopay CURSOR FOR
    SELECT adjustment, iclaim, ipolicy, nassured, iins_type,
           mins_app, mins_stl, est_rate1, accuracy, note, dappraisal, dclose,iapp_unit, iquota
      INTO $sAdjuster, $sIclaim, $sIpolicy, $snassured, $sIins_type,
           $lMins_app, $lMins_stl, $est_rate1, $accuracy, $note, $sDappraisal, $sDclose,$iapp_branch, $sIquota
      FROM NOPAY;
   $OPEN cur_nopay;
   while(1)
   {

      $FETCH cur_nopay;
      if( SQLCODE == SQLNOTFOUND ) break;

      $select nbranch
         into $sTmp
         from sa_branch_type
        where ibranch = $sIquota;
      if (SQLCODE == SQLNOTFOUND) strcpy(sTmp," ");

      strcpy(sTmp, rtrim(sTmp));

      $SELECT nname
         INTO $iadjuster_name
         FROM officer
        WHERE iofficer = $sAdjuster;

      $SELECT nchi_full
         INTO  $nchi_full_name
         FROM  branch
        WHERE  ibranch = $iapp_branch;

      rgu_put_body_string(1, sTmp, LEFT);
      rgu_put_body_string(1, nchi_full_name, LEFT);
      rgu_put_body_string(1, iadjuster_name, LEFT);

      rgu_put_body_string(1, sIclaim , LEFT);
      rgu_put_body_string(1, sIpolicy , LEFT);
          rgu_put_body_string(1, snassured, LEFT);
      rgu_put_body_string(1, sIins_type , LEFT);

      rfmtlong(lMins_app, "##,###,##&", Buf1);
      rgu_put_body_string(1, Buf1, LEFT);

      rfmtlong(lMins_stl, "##,###,##&", Buf1);
      rgu_put_body_string(1, Buf1, LEFT);

      rfmtdouble(est_rate1, "----&.&&", Buf1);
      rgu_put_body_string(1, Buf1, LEFT);

      rfmtdouble(accuracy, "----&.&&", Buf1);
      rgu_put_body_string(1, Buf1, LEFT);

      rgu_put_body_string(1, note , LEFT );
      rgu_put_body_string(1, sDappraisal, LEFT);
      rgu_put_body_string(1, sDclose, LEFT);
      rgu_put_body(1);

      max_count += 1;
   }
   $CLOSE cur_nopay;
   $FREE  cur_nopay;

   rgu_finish_report();

   printf(">_< max_count[%d]\n",max_count);

   create_sign_form("car911", BodyFile, Width);

   if ((rc=save_form_info(F_BLK1, "CA", 911, userid, FormTp, max_count, outputf))<0) {
        return rc;
   }

   return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}
/***************************************************************************/
long car911_title1()
{
     EXEC SQL char nname[13];
     char  Buf[16];
     char  yy[4], mm[3], dd[3];

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     strcpy(Buf,"(");

     if (strcmp(iinsclass,"99",2)==0)
     {
          strcat(Buf,"�����I");
          strcat(Buf,") ");
     }
     else if (strcmp(iinsclass,"98",2)==0)
     {
          strcat(Buf,"�d���I31+32");
          strcat(Buf,") ");
     }
     else if (strcmp(iinsclass,"31",2)==0)
     {
          strcat(Buf,"�ˮ`�I");
          strcat(Buf,") ");
     }
     else
     {
          EXEC SQL SELECT nins_abbr
                     INTO :nname
                     FROM insurance_type
                    WHERE iins_type = :iinsclass;
          if (SQLCODE == SQLNOTFOUND) strcpy(nname," ");
          strcat(Buf,iinsclass);
          strcat(Buf,") ");
          strcat(Buf,nname);
     }

     rgu_put_head_string(1, cm_sysd_cdatetime_100(cm_get_sysd()));
     rgu_put_head_string(1, Buf);
     cm_long_split_3ymd(cls_datebgn, yy, mm, dd);
     rgu_put_head_string(1, yy);
     rgu_put_head_string(1, mm);
     rgu_put_head_string(1, dd);

     cm_long_split_3ymd(cls_dateend, yy, mm, dd);
     rgu_put_head_string(1, yy);
     rgu_put_head_string(1, mm);
     rgu_put_head_string(1, dd);

     rgu_put_head();

     return M_CM_OK;

errexit:
     return SQLCODE;
}

double d45(num,num1)
double num;
int num1;
{
    long tmplong;
    double var1;
    double ten;
    int i;

    ten = 1;
    for(i = 1 ;i<=num1;i++)
    ten *= 10;

    num *= ten;
    if (num >= 0) var1 = 0.5;
    else var1 = (-0.5);

    num = num + var1;
    tmplong = num;

    num = tmplong/ten;
    return(num);
}
