/************************************************/
/*   PROGRAM : ca928q01s.ec                     */
/*   DATE    : 110.11.05                        */
/*   NOTE    : �������M��]�޲z����             */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
$include datetime.h;
#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"

$char DBName[05], outputf[N_FILE+1];
$char  userid[11];
DBinfo  *list;
int     count_db;


$char sEndDate_e[11], sEndDate[11], sArea[6];
$long lBgnDate, lEndDate;

long car928_build();
void car928_title();
long car928_body();
long car928_print();

/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
    int rc;

    batchinit();
    strcpy(DBName   ,  isNULLstr(argv[1]));
    strcpy(userid   ,  isNULLstr(argv[2]));
    strcpy(sEndDate ,  isNULLstr(argv[3]));  /* �έp�I���� */
    strcpy(sArea    ,  isNULLstr(argv[4]));  /* �z�ߤ��� */
    strcpy(outputf  ,  isNULLstr(argv[5]));


    strcpy(sEndDate_e, cm_to_infdate(sEndDate));

    rstrdate(sEndDate_e, &lEndDate);

    strcpy(sArea, trim(sArea));
    strcat(sArea,"*");



    rc=car928_get_db();
    if (rc!=M_CM_OK)
        return rc;

    rc = car928_build();
    if (rc != M_CM_OK)
        return rc;

    return M_CM_OK;

errexit:
    printf("main :SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}

/*--------------------------------------------------------------------*/

long car928_build()
{
    int    rc;

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;

    rc = car928_body();
    if (rc != M_CM_OK)
        return rc;

   rc = car928_print();
   if (rc != M_CM_OK)
       return rc;


   return M_CM_OK;

errexit:
   EWRITE(userid,rc,sqlca.sqlerrm);
   return SQLCODE;
}

/* ------------------------------------------------------------------------- */
long car928_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/* ---------------------------------------------------------------- */

long car928_body()
{
    long rc;
    int k;
    $char stmt[30000],stmt2[3000];
    $char iclaim[CLAIM_NUM];
    $int fclaim_status,msettle,icount;

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;

    $create temp table car928tbl
    (
       iclaim      			char(20),    		--�߮׸��X
       fclaim_status    char(20),    		--�߮ת��A
       dclaim						date,        		--���z��(���)
       dunclose					int, 	 					--���M�`�Ѽ�
       dunclose_d				int, 	 					--���M�Ѽ�
       dunclose_m				int, 	 					--���M���
       ibranch     			char(30),     		--���ݲz�ߤ���
       nbranch     			char(50),    		--�z�߬�O
       nname       			char(10),    		--�z�ߤH��
       fins			        int,     		--�߮פ���
       vouch_state			char(3),		 		--�z��i��
       noutst1   				varchar(255),		-- �̷s���M��]
       dounts1					char(40) ,		-- �̷s���M��]�O���ɶ�
       noutst2   				varchar(255),		-- �e�����M��]
       dounts2					char(40) ,		-- �e�����M��]�O���ɶ�
       dunwrite					int							-- �����@�Ѽ�
    )with no log;

    $create index car928_x1 on car928tbl (fins);
	$CREATE INDEX car928_x2 ON car928tbl (iclaim);
    $CREATE INDEX car928_x3 ON car928tbl (iclaim,vouch_state);

		for(k=0;k<count_db;k++)
    {
		   sprintf_s(stmt,30000,
		   	 " insert into car928tbl "
			   "select a.iclaim, a.fclaim_status, a.dclaim, date('%s')-a.dclaim,  "
		     "       CASE WHEN date('%s')-a.dclaim <= 28 THEN "
			   "		        date('%s')-a.dclaim "
			   "       ELSE "
			   "		        CASE WHEN day(date('%s')) >= day(a.dclaim) THEN "
			   " 		             day(date('%s')) - day(a.dclaim) "
			   "		        ELSE "
			   "			           day(last_day(a.dclaim))- day(a.dclaim)+day(date('%s')) "
			   "		        END "
			   "       END AS day1, "
			   "       CASE WHEN day(date('%s')) >= day(a.dclaim) THEN "
			   " 		        ((year(date('%s'))-year(a.dclaim))*12) + month(date('%s')) - month(a.dclaim) "
			   "       ELSE "
			   "			      ((year(date('%s'))-year(a.dclaim))*12) + month(date('%s'))  - month(a.dclaim) -1  "
			   "       END  AS month1, "
			   "       (SELECT nbranch FROM sa_branch_type WHERE ibranch = a.affiliated[1,4]||'00')  as �z�ߤ���, "
		     "       (select nbranch from sa_branch_type where ibranch = a.affiliated) as �z�߬�O, "
		     "       (select nname from officer where iofficer = a.adjustment) as �z�ߤH��, "
		     "       a.fins,  c.vouch_state,  "
		     "       max(case when b.sno = 1 then b.noutstand_note else ' ' end) , "
		     "       max(case when b.sno = 1 then b.dcreate else NULL end) , "
		     "       max(case when b.sno = 2 then b.noutstand_note else ' ' end) , "
		     "       max(case when b.sno = 2 then b.dcreate else NULL end) , "
		     "       max(CASE WHEN a.doutstand IS NOT NULL then "
		     "          			today-DATE(a.doutstand) "
		     "  	       ELSE "
		     "  			        CASE a.fins when 30 THEN today-add_months(a.dclaim,2) "
		     "              	            WHEN 40 THEN today-add_months(a.dclaim,4) "
		     "                 	          WHEN 50 THEN today-add_months(a.dclaim,9) "
		     "                   	        WHEN 10 THEN today-add_months(DATE(a.daccident),36) END "
		     "  	       END )"
		     "  from ca_clm_process a, outer %s:settlement c, "
		     "       outer (SELECT iclaim, dclaim, noutstand_note , dcreate, "
		     "                     dense_rank() over(PARTITION BY iclaim ORDER BY row_guid desc) AS sno "
		     "                FROM sysdb:ca_clm_outs WHERE DATE(dcreate) <= '%s') AS b "
		     " WHERE a.iclaim = b.iclaim  AND a.dclaim = b.dclaim  "
		     "   and a.iclaim = c.iclaim  and c.fstl = '1' "
		     "   and c.iclose_type = (select max(iclose_type) from %s:settlement "
		     "                         where iclaim = a.iclaim and fstl = '1') "
		     "   and a.dclaim >= '01/01/2008' and a.dclaim <= '%s' "
		     "   and a.fclaim_status < 501 "
		     "   and b.sno <= 2    and a.fsystem = 'N' "
		     "   AND a.fins IN (10,30,40,50) "
		     "   AND ((a.fins IN (30,40,50) "
		     "         AND a.dclaim < CASE a.fins WHEN 30 THEN add_months(today,-2) "
		     "                                    WHEN 40 THEN add_months(today,-4) "
		     "                                     WHEN 50 THEN add_months(today,-9) END) "
		     "       or (a.fins = 10 AND a.daccident < add_months(today,-36))) "
		     " group by 1,2,3,7,8,9,10,11 "
		     " ORDER BY a.iclaim, a.dclaim ",
		     sEndDate_e, sEndDate_e, sEndDate_e, sEndDate_e, sEndDate_e,
		     sEndDate_e, sEndDate_e, sEndDate_e, sEndDate_e, sEndDate_e,
		     sEndDate_e,  list[k].dbname, sEndDate_e, list[k].dbname,sEndDate_e);

     		printf("stmt[%s]\n",stmt);

     $prepare pre1 from $stmt;
     $execute pre1;

   }

    return M_CM_OK;

errexit:
   printf("car928_body ==> SQLCODE:[%ld][%s] \n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   printf("   end EWRITE \n");
   return SQLCODE;
}

/* ------------------------------------------------------------------------- */
long car928_print()
{
   $char sfilename[200];
   $char stitle[2000];
   $char ssql[2000];
   $char sErrmsg[100];
   $int  rc;

   $WHENEVER ERROR goto errexit;
   $SET LOCK MODE TO WAIT;

   strcpy(sfilename,"���M��]��Ʃ��Ӫ�_���N�I");
   printf("sfilename[%s]\n",sfilename);

   strcpy(stitle, "�{���N��:CAR928\t");
   strcat(stitle, sfilename);
   strcat(stitle, "\t\t\t�έp�I�����G\t");
   strcat(stitle, sEndDate_e);

   strcat(stitle, "\n\t�׸�\t�߮ת��A\t���z��\t���M���\t�z�ߤ���\t�z�߬�O\t");
   strcat(stitle, "�z�ߤH��\t�߮פ���\t�z��ñ�ֶi��\t�̷s���M��]\t�̷s���M��]�O�����\t");
   strcat(stitle, "�W�����M��]\t�W�����M��]�O�����\t���M��]�����@�Ѽ�\t");

   printf("stitle[%s]\n",stitle);

   sprintf_s(ssql,2000,
    " select unique iclaim, decode(fclaim_status, 101,'�w���z', 201,'�w�w��', 301,'�w�f��', 401,'�d�ҧ���', 451,'�w�M��w��', 501,'���פw�M','���A���~'), "
    "        dclaim, dunclose_m||'��'||dunclose_d||'��', ibranch, nbranch, nname, "
    "        decode(fins, 10, 'B �j���I', 30, 'C ��W������ѵs', 40, 'D �]�l', 'E ���'), "
    "        decode(vouch_state, 80, '�h�^ñ��', 90, '�h��', 100, '��ñ��', 110, 'ñ�֤�', 130, 'ñ�֧���', '�L�z����'), "
    "        replace(replace(replace(noutst1,chr(13),''),chr(10),''),chr(9),'') as noutst1, dounts1, "
    "        replace(replace(replace(noutst2,chr(13),''),chr(10),''),chr(9),'') as noutst2, dounts2, dunwrite "
    "   from car928tbl a where fins > 10 "
    "    and nvl(a.vouch_state,'') = "
    "           (SELECT UNIQUE max(nvl(vouch_state,'')) FROM car928tbl WHERE iclaim = a.iclaim )");

   printf("1:ssql[%s]\n",ssql);

   rc = unload_file(outputf,"A",sfilename,stitle,ssql);
    printf("------ 278 ------- \n");
   if (rc != SUCCESS)
   {
       if (rc == 3501)
       {
          sprintf_s(sErrmsg,100," ��J���^������䤣���� ",sfilename);
       }
       else
       {
          sprintf_s(sErrmsg,100," %s �ɮ׵L�k���� ",sfilename);
       }

       EWRITE(userid, rc , sErrmsg);
       exit(1);
   }

   strcpy(sfilename,"�j���I�W�L�T�~���鵲���Ӫ�");
   printf("sfilename[%s]\n",sfilename);

   strcpy(stitle, "�{���N��:CAR928\t");
   strcat(stitle, sfilename);
   strcat(stitle, "\t\t\t�έp�I�����G\t");
   strcat(stitle, sEndDate_e);

   strcat(stitle, "\n\t�׸�\t�߮ת��A\t���z��\t���M���\t�z�ߤ���\t�z�߬�O\t");
   strcat(stitle, "�z�ߤH��\t�߮פ���\t�z��ñ�ֶi��\t�̷s���M��]\t�̷s���M��]�O�����\t");
   strcat(stitle, "�W�����M��]\t�W�����M��]�O�����\t���M��]�����@�Ѽ�\t");

   sprintf_s(ssql,2000,
    " select unique iclaim, decode(fclaim_status, 101,'�w���z', 201,'�w�w��', 301,'�w�f��', 401,'�d�ҧ���', 451,'�w�M��w��', 501,'���פw�M','���A���~'), "
    "        dclaim, dunclose_m||'��'||dunclose_d||'��', ibranch, nbranch, nname, "
    "        decode(fins, 10, 'B �j���I', 30, 'C ��W������ѵs', 40, 'D �]�l', 'E ���'), "
    "        decode(vouch_state, 80, '�h�^ñ��', 90, '�h��', 100, '��ñ��', 110, 'ñ�֤�', 130, 'ñ�֧���', '�L�z��ѩβz��ѬҤw�鵲'), "
    "        replace(replace(replace(noutst1,chr(13),''),chr(10),''),chr(9),'') as noutst1, dounts1, "
    "        replace(replace(replace(noutst2,chr(13),''),chr(10),''),chr(9),'') as noutst2, dounts2, dunwrite "
    "   from car928tbl a where a.fins = 10 "
    "    and nvl(a.vouch_state,'') = "
    "           (SELECT UNIQUE max(nvl(vouch_state,'')) FROM car928tbl WHERE iclaim = a.iclaim )");
printf("2:ssql[%s]\n",ssql);
    rc = unload_file(outputf,"B",sfilename,stitle,ssql);
    printf("------ 278 ------- \n");
    if (rc != SUCCESS)
   {
       if (rc == 3501)
       {
          sprintf_s(sErrmsg,100," ��J���^������䤣���� ",sfilename);
       }
       else
       {
          sprintf_s(sErrmsg,100," %s �ɮ׵L�k���� ",sfilename);
       }

       EWRITE(userid, rc , sErrmsg);
       exit(1);
   }

   return M_CM_OK;

errexit:
  printf("SQL=[%d], sqlca.sqlerrm[%s]\n", SQLCODE, sqlca.sqlerrm);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  exit(1);

}
