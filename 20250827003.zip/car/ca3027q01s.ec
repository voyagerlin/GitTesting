#include <stdio.h>
#include <string.h>
#include <memory.h>
#include "api_xsrv.h"
#include <sys/stat.h>
$include sqlca;
$include datetime.h;
#include "sql.h"
#include "is_def.h"
#include "aoimsgs.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"
#include <math.h>
#include "carmsgs.h"
#include "commsgs.h"
#include <time.h>
#include "car_common.h"
#define  SUGCNT   3
#define  SUGCNT5  5

char     DBName[3];
$char    FullDBName[21];
int      rc;
$int     id1;
$char    sBranch[3];
$char    stmt[4096];
time_t   tstart,tstop;
double   tused;

char     *get_db();
int      sTransApp();

$char    Errmsg[60];
$int     icnt;
$int     idx;
$char    sugmark1[101],sugmark2[101],sugmark3[101];
$char    sugmark4[101],sugmark5[101];

$char    ibranch[3];
char     outputf[20];
$char    iendorse[21];
$char    file[100],sfile[100];
$int     rt,i,j;
$char    sApHome[100],outputf1[80];
$char    sDB[3];
 FILE    *fp;

/*main(argc, argv)
int argc;
char **argv;*/
long gen_test_list(iplyyear,iplymonth,DBName,userid,ipgid,intopt,flg)
char  DBName[3];
char  userid[12],ipgid[9];
$int  iplyyear,iplymonth, intopt,flg;
{
    $char  syy[5];
    $char  smm[3];
    $int   iyy;
    $char  str_syy[3];
    $char  ipolicy[21],irelative_ply[21],ipolicy12[21];
    $char  fcard_class[2],ibig_comp[2];
    $char  dply_begin[11],icar_type[3];
    $long  comp_prem,v_prem,tot_prem,mdiscount,tot_mpay;
    $long  sum_insprem,sum_discount;
    $long  v_ins_prem;
    $long  c_ins_premium;
    $int   motor_cnt;
    $long  ire_mprem;
    $long  mzero;
    $int   ikindcnt;
    $char  A[100][200];
    $int   B[101],C[101];
    $char  branch[3];
    $char  fsex[2];
    $int   chkcnt;
    $int   ii,j;
    $char  all_ins[INSURANCE_TYPE],last_ins[INSURANCE_TYPE];
    $long  all_ins_premium;
    $char  iquota[11];
    $char  iofficer[11];
    $char  f_24,f_31,f_32;
    $char  f_11,f_14,f_51, f_12, f_19;
    $char  f_52,f_71,f_72, f_30, f_47;
    $char  f_1589_85;
    $char  pdmg_acc[5];
    $double f_pdmg_acc;
    $double n_pdmg_acc;
    $char  c_pdmg_acc[5];
    $char  ply_group[2];
    $char  iissue_ym[10];
    $char  icorps[11];
    $long  ins_mdiscount;
    $char  iins_type[INSURANCE_TYPE];
    $int   ac_count;
    $int   A02_count;
    $char  re_comp[2];
    $long  linnum;
    $char  comp[20];
    $int   m9cnt;
    $char  ldb[3];
    $char  license[11];
    $char  ibig_office[11];
    $char  nproject[21];
    $char  nofficer[20], iresource[2];
    $int   pro_cnt;
    $int   mdeduct, mdeduct_11;

    $char    sDplyEndBgn[11],sDplyEndEnd[11];
    $long    lDplyEndBgn    ,lDplyEndEnd;
    $int     iYY,iMM;
    $char    sYY[5],sMM[3], itag[CA_TAG_NUM];

    $char    s_dissue[11];
    $char    tmp_yyyy[5],tmp_mm[3],tmp_dd[3];
    $char    sIssue_y[4];
    $int     iIssue_y ,iPly_begin_cy;

    iyy = iplyyear - 1911;
    strcpy(syy,itoa(iplyyear));
    strcpy(str_syy,itoa(iyy));
    strcpy(str_syy,trim(str_syy));

    if (iplymonth<10){
    	sprintf(smm,"0%d",iplymonth);
    }else{
    	strcpy(smm,itoa(iplymonth));
    }


    /***********************************************/
    /***********************************************/
    /* begin */
    sprintf(sDplyEndBgn,"%s/%s/01",str_syy,smm);
    lDplyEndBgn = cm_ymd_cdate(sDplyEndBgn);

    /* end   */
    if (strcmp(trim(smm),"12")==0){
        iyy ++;
        strcpy(str_syy,itoa(iyy));
        sprintf(sDplyEndEnd,"%s/01/01",str_syy);

    }else{

        iMM = atoi(smm) + 1;
        if (iMM<10){
            sprintf(sMM,"0%d",iMM);
        }else{
        	strcpy(sMM, itoa(iMM));
        }

        sprintf(sDplyEndEnd,"%s/%s/01",str_syy,sMM);
    }
    lDplyEndEnd = cm_ymd_cdate(sDplyEndEnd)-1;

    printf("lDplyEndBgn[%ld]\n",lDplyEndBgn);
    printf("lDplyEndEnd[%ld]\n",lDplyEndEnd);

    /***********************************************/

    /* 100.03.01,�w���� �έ�W�b��(���|intopt ==10) */
    /* intopt = 0:���ͤU�b����ո��, 10:���ͤW�b��έ���ո�� */

    rt = test_data(iplymonth,intopt);

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT ;

    $DATABASE sysdb;

    $CREATE TEMP TABLE SUGDATA
     (
       idx         int ,
       sugmark1    char(100),
       sugmark2    char(100),
       sugmark3    char(100),
       sugmark4    char(100),
       sugmark5    char(100)
     )with no log;

    for(ii=0;ii<=100;ii++){
        B[ii] = 0;
        C[ii] = 0;
    }

    all_ins_premium = 0;
    comp_prem = v_prem = tot_prem = mdiscount = tot_mpay = 0;
    sum_insprem = 0;
    sum_discount = 0;
    v_ins_prem = 0;
    c_ins_premium = 0;
    ikindcnt = 0;
    mzero = 0;
    ire_mprem = 0;
    chkcnt = 0;
    ac_count = 0;

    sprintf(stmt,
     " SELECT SUM(mins_premium),SUM(mdiscount) \
         FROM ply_ins_type_302f                \
        WHERE ipolicy = ?   ");
    $PREPARE insid FROM $stmt;

    sprintf(stmt,
     " SELECT SUM(mins_premium+mdiscount)      \
         FROM ply_ins_type_302f                \
        WHERE ipolicy = ?                      \
          AND iins_type != '21'  ");
    $PREPARE v_id FROM $stmt;

    sprintf(stmt,
     " SELECT mins_premium                     \
         FROM ply_ins_type_302f                \
        WHERE ipolicy = ?                      \
          AND iins_type = '21' " );
    $PREPARE c_id FROM $stmt;

    sprintf(stmt,
     " SELECT count(*)                         \
         FROM ply_relation_last                \
        WHERE ipolicy = ?                      \
          AND YEAR(dply_end) = ?               \
          AND MONTH(dply_end) = ? ");
    $PREPARE r_id FROM $stmt;

    sprintf(stmt,
     " SELECT pdmg_acc                         \
         FROM policy_last                      \
        WHERE ipolicy = ? ");
    $PREPARE dmg_id FROM $stmt;

    sprintf(stmt,
     " SELECT mins_premium                     \
         FROM policy_302 a,ply_ins_type_302 b  \
        WHERE a.ipolicy = ?                    \
          AND a.ipolicy = b.ipolicy            \
          AND YEAR(a.dply_begin) = ?           \
          AND MONTH(a.dply_begin) = ?          \
          AND b.iins_type = '21' ");
    $PREPARE comp_id FROM $stmt;

    sprintf(stmt,
     " SELECT iins_type,mins_premium,mdiscount \
         FROM ply_ins_type_302f                \
        WHERE ipolicy = ? ");
    $PREPARE allins FROM $stmt;
    $DECLARE allins_cur CURSOR FOR allins;

    sprintf(stmt,
     " SELECT iins_type, mdeduct     \
         FROM ply_ins_type_last      \
        WHERE ipolicy = ?  ");
    $PREPARE lastins FROM $stmt;
    $DECLARE lastins_cur CURSOR FOR lastins;

    sprintf(stmt,
     " SELECT ply_group                \
         FROM ext_policy               \
        WHERE ipolicy = ?              \
          AND dconfirm IS NOT NULL     \
          AND dcancel IS NULL  ");
    $PREPARE ext_id FROM $stmt;



    sprintf(stmt,
     " SELECT count(*)             \
         FROM ply_ins_type_302f    \
        WHERE ipolicy = ?          \
          AND iins_type = ?  ");
    $PREPARE ikind FROM $stmt;

    sprintf(stmt,
     " SELECT count(*)             \
         FROM ca_accident          \
        WHERE ipolicy = ?          \
          AND fcard_class = '2'    \
          AND fdmg = 1 ");
    $PREPARE ac_id FROM $stmt  ;

    /* �ˮ�A02�ĤT�H�d���I(31/32)�O�I���B�O�_���C��200/400/50�U�� */
    sprintf(stmt,"SELECT count(*) FROM ply_ins_type_302f WHERE %s %s ",
                 "ipolicy = ? ",
                 "AND ((iins_type = '31' and minjured_cover < 2000000 and mdamage_cover < 4000000) or (iins_type = '32' and mdamage_cover< 500000)) ");
    $PREPARE b_A02 FROM $stmt;

    sprintf(stmt,
     " SELECT trim(nproject) \
         FROM policy_302 \
        WHERE ipolicy = ? ");
    $PREPARE prep_nproject FROM $stmt;

/*
    strcpy(A[0],"�`�O�O�P�I�ة��ӫO�O����");
    strcpy(A[1],"�`�������B�P�I�ة��ӧ������B����");
    strcpy(A[2],"���N�I�O�O�P�I�ة��ӫO�O����");
    strcpy(A[3],"��O�j��������B�����s");
    strcpy(A[4],"�j�����(���N�I��ĳ�O�B)���B����");
    strcpy(A[5],"�j�����(�D��ĳ�O�B)�����N�I�O�O�����s");
    strcpy(A[6],"�O�N�󤧧������B�����s");
    strcpy(A[7],"�j���I�O�O�P�I�ة��Ӥ���");
    strcpy(A[8],"��O�j��(�T��)�����N�I�O�O�����s");
    strcpy(A[9],"���N�I�ҰO�����j��O�I���B����");
    strcpy(A[11],"�ꦬ�[�����������`�O�O");
    strcpy(A[12],"�O�N��t��17�I��");
    strcpy(A[13],"���N�I�O�O�[�j���I�O�O�������`�O�O");
    strcpy(A[14],"��O���N���j���I�O�O�����s");
    strcpy(A[15],"A02�C�M�ĤT�H�d���I�O�I���B����200/400/50");
*/
    /*strcpy(A[10],"�O�O���s�έt��");*/
    /*strcpy(A[14],"�������B�����������v���H�O�O");*/

    /*     C[1]   �@����O�j��   */
    /*     C[2]   �O�N���O�j��   */
    /*     C[3]   ���j�f           */
    /*     C[4]   ��j�f           */
    /*     C[5]   �ۤp��_�k��      */
    /*     C[6]   �ۤp��_�k��      */
    /*     C[7]   �ۤp��_�k�H      */
    /*     C[8]   �ۤp�f_�k��      */
    /*     C[9]   �ۤp�f_�k��      */
    /*     C[10]  �ۤp�f_�k�H      */
    /*     C[11]  �������N�I       */
    /*     C[12]  �����j���I       */
    /*     C[13]  ��ӥ��ӫO31�I�� */
    /*     C[14]  ��Ӧ��ӫO31�I�� */
    /*     C[15]  ��ӥ��ӫO51�I��_�D�F�w�� */
    /*     C[16]  ��Ӧ��ӫO51�I��_�D�F�w�� */
    /*     C[17]  ��ӥ��ӫO51�I��_�F�w�� */
    /*     C[18]  ��Ӧ��ӫO51�I��_�F�w�� */
    /*     C[19]  ��Ӧ��ӫO24�I��_�j��w��� */
    /*     C[20]  ��Ӧ��ӫO24�I��_�j���� */
    /*     C[21]  ��ӵL�ӫO24�I��_�j��w��� */
    /*     C[22]  ��ӵL�ӫO24�I��_�j���� */
    /*     C[23]  ��Ӧ��ӫO11�I�إB��14�� */
    /*     C[24]  ���l��O�Y�ƻP�e���Y�ƬۦP  */
    /*     C[25]  ��~�@����_����ĳ�O�B */
    /*     C[26]  �����O�TA�s��  */
    /*     C[27]  �����O�TB�s��  */
    /*     C[28]  �����O�TC�s��  */
    /*     C[29]  ¾�Υ�         */
    /*     C[30]  ��O��w�t�ѵs�I�����ӫO�����I�A�B���֦b�T�~�����ۤp�ȳf��  */
    /*     C[31]  ��O��w�t�ѵs�I--�F�w��   */
    /*     C[32]  ��O��w�t�ѵs�I--�D�F�w�� */
    /*     C[33]  ��O��w�t�ѵs�I�B�w���N���O�� */
    /*     C[34]  �x�_��~���T�j�k�H��---���������s   */
    /*     C[35]  ��W����---���������s */

    /*     C[36]  ���ج�(18+31+13+30)��O�����I�B11�B31.32.24�B52�B71�B72 */
    /*     C[37]  ���ج�(06+20+09+10)��O�����I�B11�B31.32.24�B52�B71�B72 */
    /*     C[38]  ��Τ@�F�� */
    /*     C[39]  �W�B�O�I */
    /*     C[40]  ��O11+19��O��ĳ11+12+19 */
    /*     C[41]  ��O11�L�ۭt�B,��ĳ��O��10% */
    /*     C[42]  �����ɯ� */
    /*     C[43]  �ΫH���~�ѵs */
    /*     C[44]  ���M��ţ */
    /*     C[45]  50�ǩ_ */
    /*     C[46]  �֯S���AA */
    /*     C[47]  �W��50 */
    /*     C[48]  ��AZPG12�I�� */
    /*     C[49]  22���ؤ��i��ĳ�N�B��(15,16,�[�Ȩ�����ѵs,�i��ĳ�N���O��) */
    /*     C[50]  ����47�I�� */
    /*     C[51]  �k�H�Ĥ@�~�j���I */
    /*     C[52]  YesIdo */
    /*     C[53]  50�ǩ_2 */
    /*     C[54]  �ΫH50 */
    /*     C[55]  �����ɯũ���� */
    /*     C[56]  YesIdo3 */
    /*     C[57]  �üy50 */
    /*     C[58]  ���M�a�x */
    /*     C[59]  YesIdo2 */
    /*     C[60]  YesIdo4 */
    /*     C[61]  �W���U�� */
    /*     C[62]  ����SV 555�M�� */
    /*     C[63]  ���~�ѵs�I�M�� */
    /*     C[64]  �p�դ��~�ѵs�I */
    /*     C[65]  �ߦw�s�u�M�� */
    /*     C[66]  �Υ�1519�M�� */
    /*     C[67]  �ζ��OCAR�[�M�� */
    /*     C[68]  ���׸U�o�ֱM�� */
    /*     C[69]  �ζ�TWO�O�O�M�� */
    /*     C[70]  ����50 */
    /*     C[71]  �Υ�60 */
    /*     C[72]  �Υ�50 */
    /*     C[73]  �W�ߤA��" */
    /*     C[74]  �έ�A��" */

    /*     C[99]  �O�O���s�έt�� */

    j = 0;

    $DECLARE c_cur CURSOR FOR
      SELECT ipolicy,irelative_ply,fcard_class,ibig_comp,icar_type,
             dply_begin,comp_prem,v_prem,tot_prem,mdiscount,tot_mpay,fsex,iquota,
             pdmg_acc,icorps,linnum,ilicense,iofficer, itag,iissue_ym,Year(dply_begin)-1911
        FROM policy_302f
       WHERE dply_begin between $lDplyEndBgn and $lDplyEndEnd
       ORDER BY fcard_class;
    $OPEN c_cur;
    for(;;)
    {
        $FETCH c_cur
          INTO $ipolicy,$irelative_ply,$fcard_class,$ibig_comp,$icar_type,
               $dply_begin,$comp_prem,$v_prem,$tot_prem,$mdiscount,$tot_mpay,$fsex,$iquota,
               $pdmg_acc,$icorps,$linnum,$license,$iofficer, $itag,$iissue_ym,$iPly_begin_cy;
        if (SQLCODE == SQLNOTFOUND) break;

        if (strlen(trim(ibig_comp)) == 0 && iofficer[0] != 'W' ){
            strcpy(comp,"2p");
        }else{
            strcpy(comp,"5p");
        }

        strcpy(ipolicy12,ipolicy+2);
        printf("ipolicy[%s]\n",ipolicy);
        printf("ipolicy12[%s]\n",ipolicy12);
        $EXECUTE insid INTO $sum_insprem,$sum_discount USING $ipolicy;
        j++;

   	    strcpy(iissue_ym,trim(iissue_ym));
   	    if (iissue_ym[3]=='/'){ /*  "xxx/xx"  */
   	  	   strcpy(sIssue_y,substring(iissue_ym,1,3));
   	    }else{
   	  	   strcpy(sIssue_y,substring(iissue_ym,1,2));
   	    }
   	    iIssue_y = atoi(sIssue_y);       /* --> �o�Ӧ~     */


        printf("count[%d]\n",j);

        motor_cnt = 0;
        if (strlen(trim(irelative_ply)) != 0){
             $EXECUTE r_id INTO $motor_cnt USING $irelative_ply,$syy,$smm;
        }

        if (fcard_class[0] == '1')
        {
           if (ISMOT(icar_type)){
              if (strlen(trim(ibig_comp)) == 0){
                     C[1]++;
                 if (C[1] <= SUGCNT){
                     $INSERT INTO SUGDATA VALUES (1,'�@����O�j��',$ipolicy,'',$linnum,$comp);
                 }
              }else{
                     C[2]++;
                 if (C[2] <= SUGCNT){
                     $INSERT INTO SUGDATA VALUES (2,'�O�N���O�j��',$ipolicy,'',$linnum,$comp);
                 }
              }
           }else{
                     C[12]++;
                 if (C[12] <= SUGCNT){
                     $INSERT INTO SUGDATA VALUES (12,'�����j���I',$ipolicy,'',$linnum,$comp);
                 }
           }

           if ((strncmp(icar_type,"03",2) == 0) && (strlen(trim(fsex)) == 0) && ((iPly_begin_cy-iIssue_y)<=1) && itag[0] == ' ')
           {
                 C[51]++;
                 if (C[51] <= SUGCNT)
                 {
                     $INSERT INTO SUGDATA VALUES (51,'�k�H�Ĥ@�~�j���I',$ipolicy,'',$linnum,$comp);
                 }
           }
        }
        if (fcard_class[0] == '2')
        {
           if (((strncmp(license,"23528130",8) == 0) ||
                (strncmp(license,"12497194",8) == 0)) &&
               (strncmp(iquota,"6202",4) == 0) &&
               (mdiscount != 0))
           {
                 C[34]++;
                 if (C[34] <= SUGCNT)
                 {
                     $INSERT INTO SUGDATA VALUES (34,'�T�j�k�H--���������s',$ipolicy,'',$linnum,$comp);
                 }
           }
           else if (strncmp(icar_type,"20",2) == 0)
           {
                 C[3]++;
                 if (C[3] <= SUGCNT)
                 {
                     $INSERT INTO SUGDATA VALUES (3,'���j�f',$ipolicy,'',$linnum,$comp);
                 }
           }
           else if (strncmp(icar_type,"10",2) == 0)
           {
                 C[4]++;
                 if (C[4] <= SUGCNT)
                 {
                     $INSERT INTO SUGDATA VALUES (4,'��j�f',$ipolicy,'',$linnum,$comp);
                 }
           }
           else if ((strncmp(icar_type,"03",2) == 0) && (fsex[0] == '1'))
           {
                 C[5]++;
                 if (C[5] <= SUGCNT)
                 {
                     $INSERT INTO SUGDATA VALUES (5,'�ۤp��_�k��',$ipolicy,'',$linnum,$comp);
                 }
           }
           else if ((strncmp(icar_type,"03",2) == 0) && (fsex[0] == '2'))
           {
                 C[6]++;
                 if (C[6] <= SUGCNT)
                 {
                     $INSERT INTO SUGDATA VALUES (6,'�ۤp��_�k��',$ipolicy,'',$linnum,$comp);
                 }
           }
           else if ((strncmp(icar_type,"03",2) == 0) && (strlen(trim(fsex)) == 0))
           {
                 C[7]++;
                 if (C[7] <= SUGCNT)
                 {
                     $INSERT INTO SUGDATA VALUES (7,'�ۤp��_�k�H',$ipolicy,'',$linnum,$comp);
                 }
           }
           else if ((strncmp(icar_type,"04",2) == 0) && (fsex[0] == '1'))
           {
                 C[8]++;
                 if (C[8] <= SUGCNT)
                 {
                     $INSERT INTO SUGDATA VALUES (8,'�ۤp�f_�k��',$ipolicy,'',$linnum,$comp);
                 }
           }
           else if ((strncmp(icar_type,"04",2) == 0) && (fsex[0] == '2'))
           {
                 C[9]++;
                 if (C[9] <= SUGCNT)
                 {
                     $INSERT INTO SUGDATA VALUES (9,'�ۤp�f_�k��',$ipolicy,'',$linnum,$comp);
                 }
           }
           else if ((strncmp(icar_type,"04",2) == 0) && (strlen(trim(fsex)) == 0))
           {
                 C[10]++;
                 if (C[10] <= SUGCNT)
                 {
                     $INSERT INTO SUGDATA VALUES (10,'�ۤp�f_�k�H',$ipolicy,'',$linnum,$comp);
                 }
           }
           else if (ISMOT(icar_type))
           {
                 C[11]++;
                 if (C[11] <= SUGCNT)
                 {
                     $INSERT INTO SUGDATA VALUES (11,'�������N�I',$ipolicy,'',$linnum,$comp);
                 }
           }
           if ( strncmp( icorps, "H0670007", 8) == 0)
           {
                 C[38]++;
                 if (C[38] <= SUGCNT)
                 {
                     $INSERT INTO SUGDATA VALUES (38,'��Τ@�F��',$ipolicy,'',$linnum,$comp);
                 }
           }



        }  /* END fcard_class == '2' */

        strcpy(sDB,get_db(ipolicy));

        f_12 = 'N';
        f_19 = 'N';
        f_24 = 'N';
        f_30 = 'N';
        f_31 = 'N';
        f_51 = 'N';
        f_11 = 'N';
        f_14 = 'N';

        f_1589_85 = 'N';

        f_52 = 'N';
        f_71 = 'N';
        f_72 = 'N';
        f_47 = 'N';
        mdeduct_11 = 0;

        if (fcard_class[0] == '2')
        {
              $OPEN lastins_cur USING $ipolicy12;
              for(;;)
              {
                  $FETCH lastins_cur INTO $last_ins, $mdeduct;
                  if (SQLCODE == SQLNOTFOUND) break;

                  if ( (strcmp(trim(last_ins),"01") == 0)||(strcmp(trim(last_ins),"05") == 0)||(strcmp(trim(last_ins),"08") == 0)||
                  	   (strcmp(trim(last_ins),"09") == 0)||(strcmp(trim(last_ins),"85") == 0)
                  	 )
                     f_1589_85 = 'Y';

                  else if (strcmp(trim(last_ins),"32") == 0)
                      f_32 = 'Y';

                  else if (strcmp(trim(last_ins),"31") == 0)
                      f_31 = 'Y';

                  else if (strcmp(trim(last_ins),"51") == 0)
                      f_51 = 'Y';

                  else if (strcmp(trim(last_ins),"24") == 0)
                      f_24 = 'Y';

                  else if (strcmp(trim(last_ins),"11") == 0)
                  {
                      f_11 = 'Y';
                      mdeduct_11 = mdeduct;
                  }

                  else if (strcmp(trim(last_ins),"12") == 0)
                      f_12 = 'Y';

                  else if (strcmp(trim(last_ins),"52") == 0)
                      f_52 = 'Y';

                  else if (strcmp(trim(last_ins),"19") == 0)
                      f_19 = 'Y';

                  else if (strcmp(trim(last_ins),"30") == 0)
                      f_30 = 'Y';

                  else if (strcmp(trim(last_ins),"14") == 0)
                      f_14 = 'Y';

                  else if (strcmp(trim(last_ins),"71") == 0)
                      f_71 = 'Y';

                  else if (strcmp(trim(last_ins),"72") == 0)
                      f_72 = 'Y';
                  else if (strcmp(trim(last_ins),"47") == 0)
                      f_47 = 'Y';

              }
              $CLOSE lastins_cur;
              printf("f_31[%c]\n",f_31);
              printf("Trace -- after f_31 \n");
              
              if (strncmp(iquota,"6102",4) != 0)
              {
                 if (f_31 == 'N')
                 {
                      C[13]++;
                      if (C[13] <= SUGCNT){
                        $INSERT INTO SUGDATA VALUES (13,'��ӥ��ӫO31�I��',$ipolicy,'',$linnum,$comp);
                         continue;
                      }
                 }

                 if (f_31 == 'Y')
                 {
                      printf(" INTO f_31 == 'Y' f_31[%c],C[14][%d]\n",f_31,C[14]);
                      C[14]++;
                      if (C[14] <= SUGCNT){
                        $INSERT INTO SUGDATA VALUES (14,'��Ӧ��ӫO31�I��',$ipolicy,'',$linnum,$comp);
                         continue;
                      }
                 }

                 if ((f_51 == 'N') && (ibig_comp[0] != 'B'))
                 {
                      C[15]++;
                      if (C[15] <= SUGCNT){
                         $INSERT INTO SUGDATA VALUES (15,'��ӥ��ӫO51�I��_�D�F�w��',$ipolicy,'',$linnum,$comp);
                         continue;
                      }
                 }

                 if ((f_51 == 'Y') && (ibig_comp[0] != 'B'))
                 {
                      C[16]++;
                      if (C[16] <= SUGCNT){
                          $INSERT INTO SUGDATA VALUES (16,'��Ӧ��ӫO51�I��_�D�F�w��',$ipolicy,'',$linnum,$comp);
                         continue;
                      }
                 }

                 if ((f_51 == 'N') && (ibig_comp[0] == 'B'))
                 {
                      C[17]++;
                      if (C[17] <= SUGCNT){
                         $INSERT INTO SUGDATA VALUES (17,'��ӥ��ӫO51�I��_�F�w��',$ipolicy,'',$linnum,$comp);
                         continue;
                      }
                 }

                 if ((f_51 == 'Y') && (ibig_comp[0] == 'B'))
                 {
                      C[18]++;
                      if (C[18] <= SUGCNT){
                         $INSERT INTO SUGDATA VALUES (18,'��Ӧ��ӫO51�I��_�F�w��',$ipolicy,'',$linnum,$comp);
                         continue;
                      }
                 }

                 if ((f_24 == 'Y') && (motor_cnt > 0))
                 {
                      C[19]++;
                      if (C[19] <= SUGCNT){
                         $INSERT INTO SUGDATA VALUES (19,'��Ӧ��ӫO24�I��_�j��w���',$ipolicy,'',$linnum,$comp);
                         continue;
                      }
                 }

                 if ((f_24 == 'Y') && (motor_cnt == 0)){
                      C[20]++;
                      if (C[20] <=SUGCNT){
                         $INSERT INTO SUGDATA VALUES (20,'��Ӧ��ӫO24�I��_�j����',$ipolicy,'',$linnum,$comp);
                         continue;
                      }
                 }

                 if ((f_24 == 'N') && (motor_cnt > 0))
                 {
                      C[21]++;
                      if (C[21] <= SUGCNT){
                          $INSERT INTO SUGDATA VALUES (21,'��ӵL�ӫO24�I��_�j��w���',$ipolicy,'',$linnum,$comp);
                         continue;
                      }
                 }

                 if ((f_24 == 'N') && (motor_cnt == 0))
                 {
                      C[22]++;
                      if (C[22] <= SUGCNT){
                          $INSERT INTO SUGDATA VALUES (22,'��ӵL�ӫO24�I��_�j����',$ipolicy,'',$linnum,$comp);
                         continue;
                      }
                 }

                 if ((f_11 == 'Y') && (f_14 == 'Y'))
                 {
                      C[23]++;
                      if (C[23] <= SUGCNT){
                          $INSERT INTO SUGDATA VALUES (23,'��Ӧ��ӫO11�I�إB��14��',$ipolicy,'',$linnum,$comp);
                          continue;
                      }
                 }
              }
              else
              {
              	 /* ����B�D�x�s��(�x�s�󤣧���)*/
                 if ((strncmp(iofficer,"Y03613ZC",8) !=0)&&
				     (strncmp(iofficer,"Y03613ZC4",8)!=0)&&
				     (strncmp(iofficer,"Y03613ZC5",8)!=0)&&
				     (strncmp(iofficer,"Y03613ZC6",8)!=0)&&
				     (strncmp(iofficer,"Y03613ZCA",8)!=0)&&
				     (strncmp(iofficer,"Y03613ZCB",8)!=0)&&
				     (strncmp(iofficer,"Y03613ZCC",8)!=0)&&
				     (strncmp(iofficer,"Y03613ZCD",8)!=0)&&
				     (strncmp(iofficer,"Y03613ZCE",8)!=0)&&
				     (strncmp(iofficer,"Y03613ZCF",8)!=0)){

	                 C[25]++;
	                 if (C[25] <= SUGCNT){
	                     $INSERT INTO SUGDATA VALUES (25,'���~����~��_������O�O',$ipolicy,'',$linnum,$comp);
	                     continue;
	                 }
                 }
              }


printf("Trace -- before ply_group \n");
              strcpy(ply_group," ");
              if (ibig_comp[0] == 'A' || ibig_comp[0] == 'E')
              {
                  $EXECUTE ext_id INTO $ply_group USING $ipolicy12;
                  if (ply_group[0] == 'A')
                  {
                       C[26]++;
                       if (C[26] <= SUGCNT){
                           $INSERT INTO SUGDATA VALUES (26,'�����O�TA�s��',$ipolicy,'',$linnum,$comp);
                           continue;
                       }
                  }

                  if (ply_group[0] == 'B')
                  {
                       C[27]++;
                       if (C[27] <= SUGCNT){
                          $INSERT INTO SUGDATA VALUES (27,'�����O�TB�s��',$ipolicy,'',$linnum,$comp);
                           continue;
                       }
                  }

                  if (ply_group[0] == 'C')
                  {
                       C[28]++;
                       if (C[28] <= SUGCNT){
                          $INSERT INTO SUGDATA VALUES (28,'�����O�TC�s��',$ipolicy,'',$linnum,$comp);
                           continue;
                       }
                  }
              }

              if (strlen(trim(ibig_comp)) == 0)
              {
                  if (strlen(trim(icorps)) != 0)
                  {
                       strcpy(ldb,get_db(ipolicy12));
                       sprintf(stmt,
                         " SELECT iresource          \
                             FROM %s:ply_relation   \
                            WHERE ipolicy = ?       " ,get_full_dbname(ldb));

                       $PREPARE prep1 FROM $stmt;
                       $EXECUTE prep1 INTO $iresource USING $ipolicy12;
                       $FREE prep1;

                       if( iresource[0] == '4')
                       {
                           C[29]++;
                           if (C[29] <= SUGCNT){
                              $INSERT INTO SUGDATA VALUES (29,'¾�Υ�',$ipolicy,'',$linnum,$comp);
                               continue;
                           }
                       }
                  }
              }
              /* 980815, �]���s�Wdbirth ,dissue
              cm_split_ymd(s_dissue, tmp_mm, tmp_dd, tmp_yyyy);*/

              if ((f_11 == 'Y') &&
                  (f_1589_85 == 'N') &&
                  (atoi(syy)- atoi(tmp_yyyy) <= 3) &&
                  ((strncmp(icar_type,"03",2) == 0) || (strncmp(icar_type,"04",2) == 0)))
              {
                     C[30]++;
                     if (C[30] <= SUGCNT)
                     {
                         $INSERT INTO SUGDATA VALUES (30,'��O��w�t�ѵs�I�����ӫO�����I�A�B���֦b�T�~�����ۤp�ȳf��',$ipolicy,'',$linnum,$comp);
                           continue;
                     }
              }

              if ((f_11 == 'Y') && (ibig_comp[0] == 'B'))
              {
                     C[31]++;
                     if (C[31] <= SUGCNT)
                     {
                         $INSERT INTO SUGDATA VALUES (31,'��O��w�t�ѵs�I--�F�w��',$ipolicy,'',$linnum,$comp);
                           continue;
                     }
              }

              if ((f_11 == 'Y') && (ibig_comp[0] != 'B'))
              {
                     C[32]++;
                     if (C[32] <= SUGCNT)
                     {
                         $INSERT INTO SUGDATA VALUES (32,'��O��w�t�ѵs�I--�D�F�w��',$ipolicy,'',$linnum,$comp);
                           continue;
                     }
              }

              if ((f_11 == 'Y') && (f_14 == 'Y'))
              {
                     C[33]++;
                     if (C[33] <= SUGCNT)
                     {
                         $INSERT INTO SUGDATA VALUES (33,'��O��w�t�ѵs�I�B�w���N���O��',$ipolicy,'',$linnum,$comp);
                           continue;
                     }
              }

              if ((strncmp(icar_type,"18",2) == 0) || (strncmp(icar_type,"31",2) == 0) ||
                  (strncmp(icar_type,"13",2) == 0) || (strncmp(icar_type,"30",2) == 0) )
              {
                  if( (f_1589_85 == 'Y' ) &&
                      (f_11 == 'Y' && f_31 == 'Y' && f_32 == 'Y' && f_24 == 'Y' &&
                       f_51 == 'Y' && f_71 == 'Y' && f_72 == 'Y'))
                  {
                     C[36]++;
                     if (C[36] <= 30)
                     {
                         $INSERT INTO SUGDATA VALUES (36,'���ج�18+31+13+30��O�����I�B11�B31.32.24�B52�B71�B72',$ipolicy,'',$linnum,$comp);
                           continue;
                     }
                  }
              }
              else if ((strncmp(icar_type,"06",2) == 0) || (strncmp(icar_type,"20",2) == 0) ||
                       (strncmp(icar_type,"09",2) == 0) || (strncmp(icar_type,"10",2) == 0) )
              {
                  if( (f_1589_85 == 'Y' ) &&
                      (f_11 == 'Y' && f_31 == 'Y' && f_32 == 'Y' && f_24 == 'Y' &&
                       f_51 == 'Y' && f_71 == 'Y' && f_72 == 'Y'))
                  {
                     C[37]++;
                     if (C[37] <= 30)
                     {
                         $INSERT INTO SUGDATA VALUES (37,'���ج�06+20+09+10��O�����I�B11�B31.32.24�B52�B71�B72',$ipolicy,'',$linnum,$comp);
                           continue;
                     }
                  }
              }

              if (f_30 == 'Y')
              {
                   C[39]++;
                   if (C[39] <= SUGCNT){
                     $INSERT INTO SUGDATA VALUES (39,'�W�B�O�I',$ipolicy,'',$linnum,$comp);
                           continue;
                   }
              }

              if (f_11 == 'Y' && f_19 == 'Y')
              {
                   C[40]++;
                   if (C[40] <= SUGCNT){
                     $INSERT INTO SUGDATA VALUES (40,'��O11+19��O��ĳ11+12+19',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }

              if (f_11 == 'Y' && mdeduct_11 == 0)
              {
                   C[41]++;
                   if (C[41] <= SUGCNT){
                     $INSERT INTO SUGDATA VALUES (41,'��O11�L�ۭt�B,��ĳ��O��10%',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }

              $EXECUTE prep_nproject INTO $nproject using $ipolicy12;
              if( strncmp( nproject, "�����ɯ�", 8) == 0)
              {
                   C[42]++;
                   if (C[42] <= SUGCNT5){
                     $INSERT INTO SUGDATA VALUES (42,'�����ɯ�',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }
              else if( strncmp( nproject, "�ΫH���~�ѵs", 12) == 0)
              {
                   C[43]++;
                   if (C[43] <= SUGCNT5){
                     $INSERT INTO SUGDATA VALUES (43,'�ΫH���~�ѵs',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }
              else if( strncmp( nproject, "���M��ţ", 8) == 0)
              {
                   C[44]++;
                   if (C[44] <= SUGCNT5){
                     $INSERT INTO SUGDATA VALUES (44,'���M��ţ',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }
              else if( strncmp( nproject, "50�ǩ_", 6) == 0)
              {
                   C[45]++;
                   if (C[45] <= SUGCNT5){
                     $INSERT INTO SUGDATA VALUES (45,'50�ǩ_',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }
              else if( strncmp( nproject, "�֯S���AA", 9) == 0)
              {
                   C[46]++;
                   if (C[46] <= SUGCNT5){
                     $INSERT INTO SUGDATA VALUES (46,'�֯S���AA',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }
              else if( strncmp( nproject, "�W��50", 6) == 0)
              {
                   C[47]++;
                   if (C[47] <= SUGCNT5){
                     $INSERT INTO SUGDATA VALUES (47,'�W��50',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }
              else if( f_12 == 'Y' && ipolicy[7] >= 'F' && ipolicy[7] <= 'Z')
              {
                   C[48]++;
                   if (C[48] <= SUGCNT){
                     $INSERT INTO SUGDATA VALUES (48,'��AZPG12�I��',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }
              else if( f_47 == 'Y' )
              {
                   C[50]++;
                   if (C[50] <= SUGCNT){
                     $INSERT INTO SUGDATA VALUES (50,'����47�I��',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }
              else if( strncmp( nproject, "YesIdo", 6) == 0)
              {
                   C[52]++;
                   if (C[52] <= SUGCNT5){
                     $INSERT INTO SUGDATA VALUES (52,'YesIdo',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }
              else if( strncmp( nproject, "50�ǩ_ 2", 8) == 0)
              {
                   C[53]++;
                   if (C[53] <= SUGCNT5){
                     $INSERT INTO SUGDATA VALUES (53,'50�ǩ_ 2',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }
              else if( strncmp( nproject, "�ΫH50", 6) == 0)
              {
                   C[54]++;
                   if (C[54] <= SUGCNT5){
                     $INSERT INTO SUGDATA VALUES (54,'�ΫH50',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }
              else if( strncmp( nproject, "�����ɯũ����", 14) == 0)
              {
                   C[55]++;
                   if (C[55] <= SUGCNT5){
                     $INSERT INTO SUGDATA VALUES (55,'�����ɯũ����',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }
              else if( strncmp( nproject, "YesIdo3", 7) == 0)
              {
                   C[56]++;
                   if (C[56] <= SUGCNT5){
                     $INSERT INTO SUGDATA VALUES (56,'YesIdo3',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }
              else if( strncmp( nproject, "�üy50", 6) == 0)
              {
                   C[57]++;
                   if (C[57] <= SUGCNT5){
                     $INSERT INTO SUGDATA VALUES (57,'�üy50',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }
              else if( strncmp( nproject, "���M�a�x", 8) == 0)
              {
                   C[58]++;
                   if (C[58] <= SUGCNT5){
                     $INSERT INTO SUGDATA VALUES (58,'���M�a�x',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }
              else if( strncmp( nproject, "YesIdo2", 7) == 0)
              {
                   C[59]++;
                   if (C[59] <= SUGCNT5){
                     $INSERT INTO SUGDATA VALUES (59,'YesIdo2',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }
              else if( strncmp( nproject, " YesIdo4", 8) == 0)
              {
                   C[60]++;
                   if (C[60] <= SUGCNT5){
                     $INSERT INTO SUGDATA VALUES (60,'YesIdo4',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }
              else if( strncmp( nproject, "�W���U��", 8) == 0)
              {
                   C[61]++;
                   if (C[61] <= SUGCNT5){
                     $INSERT INTO SUGDATA VALUES (61,'�W���U��',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }
              else if( strncmp( nproject, "����SV 555�M��", 14) == 0)
              {
                   C[62]++;
                   if (C[62] <= SUGCNT5){
                     $INSERT INTO SUGDATA VALUES (62,'����SV 555�M��',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }
              else if( strncmp( nproject, "���~�ѵs�I�M��", 14) == 0)
              {
                   C[63]++;
                   if (C[63] <= SUGCNT5){
                     $INSERT INTO SUGDATA VALUES (63,'���~�ѵs�I�M��',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }
              else if( strncmp( nproject, "�p�դ��~�ѵs�I", 14) == 0)
              {
                   C[64]++;
                   if (C[64] <= SUGCNT5){
                     $INSERT INTO SUGDATA VALUES (64,'�p�դ��~�ѵs�I',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }
              else if( strncmp( nproject, "�ߦw�s�u�M��", 12) == 0)
              {
                   C[65]++;
                   if (C[65] <= SUGCNT5){
                     $INSERT INTO SUGDATA VALUES (65,'�ߦw�s�u�M��',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }
              else if((strncmp(nproject, "�Υ�1519�M��", 12) == 0)||(strncmp( nproject, "1519�M��", 8) == 0))
              {
                   C[66]++;
                   if (C[66] <= SUGCNT){
                     $INSERT INTO SUGDATA VALUES (66,'�Υ�1519�M��',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }
              else if(strncmp(nproject, "�ζ��OCAR�[�M��", 15) == 0)
              {
                   C[67]++;
                   if (C[67] <= SUGCNT5){
                     $INSERT INTO SUGDATA VALUES (67,'�ζ��OCAR�[�M��',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }
              else if(strncmp(nproject, "���׸U�o�ֱM��", 14) == 0)
              {
                   C[68]++;
                   if (C[68] <= SUGCNT5){
                     $INSERT INTO SUGDATA VALUES (68,'���׸U�o�ֱM��',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }
              else if(strncmp(nproject, "�ζ�TWO�O�O", 11) == 0)
              {
                   C[69]++;
                   if (C[69] <= SUGCNT5){
                     $INSERT INTO SUGDATA VALUES (69,'�ζ�TWO�O�O',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }
              else if(strncmp(nproject, "����50", 6) == 0)
              {
                   C[70]++;
                   if (C[70] <= SUGCNT){
                     $INSERT INTO SUGDATA VALUES (70,'����50',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }
              else if(strncmp(nproject, "�Υ�60", 6) == 0)
              {
                   C[71]++;
                   if (C[71] <= SUGCNT){
                     $INSERT INTO SUGDATA VALUES (71,'�Υ�60',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }
              else if(strncmp(nproject, "�Υ�50", 6) == 0)
              {
                   C[72]++;
                   if (C[72] <= SUGCNT){
                     $INSERT INTO SUGDATA VALUES (72,'�Υ�50',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }
              else if(strncmp(nproject, "�W�ߤA��", 8) == 0)
              {
                   C[73]++;
                   if (C[73] <= SUGCNT){
                     $INSERT INTO SUGDATA VALUES (73,'�W�ߤA��',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }
              else if(strncmp(nproject, "�έ�A��", 8) == 0)
              {
                   C[74]++;
                   if (C[74] <= SUGCNT){
                     $INSERT INTO SUGDATA VALUES (74,'�έ�A��',$ipolicy,'',$linnum,$comp);
                     continue;
                   }
              }

        }
    }
    $CLOSE c_cur;
    $FREE  c_cur;
    printf("Trace -- after c_cur \n");
    

    rt = getApHome(sApHome);
    if (rt < 0) {
    printf("read Config file error!!\n");
    }
    printf("Trace -- sApHome = [%s] \n",  sApHome);

    if (flg==1){  /* �n�P�ɲ��s���ե��ɮ� */
    	$Delete From newa00:ca_tmp_no Where 1=1;
    }

    sprintf(outputf1,"p32_check_%s_%s.xls",syy,smm);
    rt = rptftpinsert(userid,ipgid,outputf1);
    if (rt != 0){
        printf("rptftp error\n");
        goto errexit;
    }
    sprintf(sfile,"%s/rptftp/%s",sApHome,outputf1);
    sprintf(file,"%s",rtrim(sfile));

    fp=fopen(file,"w");

    printf("Trace -- before DECLARE da_cur \n");
    $DECLARE da_cur CURSOR FOR
      SELECT idx,sugmark1,sugmark2,sugmark3,sugmark4,sugmark5
        INTO $idx,$sugmark1,$sugmark2,$sugmark3,$sugmark4,$sugmark5
        FROM SUGDATA
      ORDER BY 1;
    $OPEN da_cur;
    for(;;)
    {
         $FETCH da_cur;
         if (SQLCODE == SQLNOTFOUND) break;
         printf("Trace -- in da_cur \n");
         printf("Trace -- flg = [%d] \n",  flg);
         if (flg==1){
         	 strcpy(ipolicy12,sugmark2+2);
         	 printf("Trace -- Insert Into ca_tmp_no  [%s] \n",  ipolicy12);
             $Insert Into newa00:ca_tmp_no Values($ipolicy12);
         }
         strcpy(sugmark1,trim(sugmark1));
         strcpy(sugmark2,trim(sugmark2));
         strcpy(sugmark3,trim(sugmark3));
         strcpy(sugmark4,trim(sugmark4));
         strcpy(sugmark5,trim(sugmark5));

         fprintf(fp,"%d\t%s\t%s\t%s\t%s\t%s\n",idx,sugmark1,sugmark2,sugmark3,sugmark4,sugmark5);
    }
    $CLOSE da_cur;
    $FREE da_cur;
    printf("Trace -- after FREE da_cur \n");

    fclose(fp);
    printf("Trace -- after fclose \n");

    return 1;

errexit:
   printf("-----gen_test_list : SQLCODE[%d]\n",SQLCODE);
   EWRITE(userid, SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}


char *get_db(sIpolicy1)
char *sIpolicy1;
{
   char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
   char sTmp_db_name[21];

   sTmp_db_name[0]='\0';
   if (*sIpolicy1 != '\0' && *sIpolicy1 !=' ')
   {
      sTmp_db_name[0]='\0';
      strncpy(sTmpScomp, sIpolicy1+2, 1); sTmpScomp[1]='\0';
      printf("sTmpScomp = %s\n", sTmpScomp);
      strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
             USE_BRANCH_ID));
      printf("sTmpcomp = %s\n", sTmpcomp);
      strcpy(sTmp_db_name, sTmpcomp);
   }
   return sTmp_db_name;
}

int get_fsize(fn)
char *fn;
{
    struct stat buf;
    if (stat(fn,&buf) == -1)
         buf.st_size = 0;

    return buf.st_size;
}

/*101.10,���s�U�I�ءB���ش��ղM�� */
long gen_test2_list(iplyyear,iplymonth,DBName,userid,ipgid,intopt,flg)
char  DBName[3];
char  userid[12],ipgid[9];
$int  iplyyear,iplymonth, intopt,flg;
{
     FILE    *fptr1, *fptr2, *fptr3;
     char    sApHome[30];
     int     rt;
     char    file1[50], file2[50], file3[50];
     char    outputf[80],outputf1[80],outputf2[80],outputf3[80];
     char    prtstr1[2048],errmsg[121];
     $char   sDplyEndBgn[11],sDplyEndEnd[11];
     $char   sTitle1[201],sTitle2[201],sTitle3[201],stmt[2048];
     $char   fcard_class[2],iins_type[INSURANCE_TYPE], ipolicy[21], itag[CA_TAG_NUM] ;
     $char   iengine[CA_ENGINE_NUM], icar_type[3],iofficer[11], iroute[21], c_prem[7],itype[2];
     $int    prem;
     $int    dissue_year[4];
     $static char ins_set1[6][INSURANCE_TYPE]={"01","05","09","85","11","98"};
     $static char ins_set2[4][INSURANCE_TYPE]={"01","05","09","31"};
     $char   rate_icode2[4],s_plia_acc[6],s_fsex[2],qdrunk[3];
     $double dbl_plia_acc;
     $double dbl_qage_bgn,dbl_qage_end;
     $int    count_A,count_B,count_C;

     $WHENEVER SQLERROR GOTO errexit;
     $SET LOCK MODE TO WAIT ;


     /* ���o ���B�멳��� */
     sprintf(stmt, "SELECT '%02d/01/%d'::date,LAST_DAY('%02d/01/%d'::date) FROM systables WHERE tabid=1",
	        iplymonth,iplyyear,iplymonth,iplyyear);
     $PREPARE preLastDay FROM $stmt;
     $EXECUTE preLastDay INTO $sDplyEndBgn,$sDplyEndEnd;
     printf("trace sDplyEndBgn[%s]\n ",sDplyEndBgn);
     printf("trace sDplyEndEnd[%s]\n ",sDplyEndEnd);

     sprintf(sTitle1,"%s","�I�إN�X\t�O�渹\t����\t������\t���إN�X\t�g��N��\t�q���N��\t���O�զX�O�O");
     sprintf(sTitle2,"%s","�j����N�O\t�O�渹\t����\t������\t���إN�X\t�g��N��\t�q���N��\t���O�զX�O�O");
     sprintf(sTitle3,"%s","���O\t�O�渹\t����\t������\t���إN�X\t�g��N��\t�q���N��\t���O�զX�O�O\t�s�r�έ��j�H�W����");

     rt = getApHome(sApHome);
     if (rt < 0) {
         printf("read Config file error!!\n");
         return M_CM_READ_CONFIG_ERR;
     }
     sprintf(outputf1,"p32_check_%d_%d_ins.xls",iplyyear,iplymonth);
     printf("output1=[%s]\n", outputf1 );
     sprintf(file1,"%s/rptftp/%s",sApHome,rtrim(outputf1));
     rt = rptftpinsert(userid,ipgid,outputf1);
     if (rt != 0){
         printf("rptftp error\n");
         goto errexit;
     }
     printf("file1=[%s]\n", file1 );
     if ((fptr1=fopen(file1,"w")) == NULL){
         sprintf(errmsg,"Cannot open print file: %s",file1);
         return M_CM_OPEN_FILE_FAIL;
     }

     sprintf(outputf2,"p32_check_%d_%d_car.xls",iplyyear,iplymonth);
     printf("outputf2=[%s]\n", outputf2 );
     sprintf(file2,"%s/rptftp/%s",sApHome,rtrim(outputf2));
     rt = rptftpinsert(userid,ipgid,outputf2);
     if (rt != 0){
         printf("rptftp error\n");
         goto errexit;
     }
     printf("file2=[%s]\n", file2 );
     if ((fptr2=fopen(file2,"w")) == NULL){
         sprintf(errmsg,"Cannot open print file: %s",file2);
         return M_CM_OPEN_FILE_FAIL;
     }

     sprintf(outputf3,"p32_check_%d_%d_other.xls",iplyyear,iplymonth);
     printf("outputf3=[%s]\n", outputf3 );
     sprintf(file3,"%s/rptftp/%s",sApHome,rtrim(outputf3));
     rt = rptftpinsert(userid,ipgid,outputf3);
     if (rt != 0){
         printf("rptftp error\n");
         goto errexit;
     }
     printf("file3=[%s]\n", file3 );
     if ((fptr3=fopen(file3,"w")) == NULL){
         sprintf(errmsg,"Cannot open print file: %s",file3);
         return M_CM_OPEN_FILE_FAIL;
     }

     printf("trace iplyyear[%d]\n ",iplyyear);
     printf("trace iplymonth[%d]\n ",iplymonth);

     /* ���N�I��O�O�v�N�� */
     $SELECT icode
       INTO $rate_icode2
       FROM ca_rate_renew
      WHERE deffect_bgn <= $sDplyEndBgn
        AND deffect_end >= $sDplyEndBgn
        AND fcard_class = '2';
     printf("trace rate_icode2[%s]\n ",rate_icode2);


     $WHENEVER ERROR CONTINUE;
     $DROP TABLE tmpIns;
     $DROP TABLE tmpCar;
     $DROP TABLE tmpOther;
     $DROP TABLE tmpAll;
     $WHENEVER SQLERROR GOTO errexit;

     $CREATE TEMP TABLE tmpIns(
       iins_type    char(6),
       ipolicy      char(20)
     ) with no log;
     $CREATE INDEX tmpIns_x1 ON tmpIns(ipolicy);

     $CREATE TEMP TABLE tmpCar(
       icar_type    char(2),
       iengine      char(25)
     ) with no log;
     $CREATE INDEX tmpCar_x1 ON tmpCar(iengine);

     $CREATE TEMP TABLE tmpOther(
       icar_type    char(2),
       ipolicy      char(20),
       iengine      char(25),
       itype        char(1),
       qdrunk       char(2)         -- �s�r���Ʃέ��j�H�W����  add by sylvia 103.05.30
     ) with no log;
     $CREATE INDEX tmpOther_x1 ON tmpOther(ipolicy);

     $CREATE TEMP TABLE tmpAll(
       ipolicy      char(20),
       iengine      char(25)
     ) with no log;
     $CREATE INDEX tmpAll_x1 ON tmpAll(ipolicy);
     $CREATE INDEX tmpAll_x2 ON tmpAll(iengine);

     /* �U�I�ب����ե� */
     printf("�U�I�ب����ե� ---------------------------\n ");

     sprintf(stmt,"SELECT iins_type FROM insurance_type WHERE iins_type = iins_ply \
                      and dexpire is null  Order By iins_type " );
     $PREPARE  preIns_stmt FROM $stmt;
     $DECLARE  cur_Ins CURSOR FOR preIns_stmt;
     $OPEN     cur_Ins;
     while(1)
     {
         $FETCH cur_Ins INTO $iins_type;
         if(SQLCODE == SQLNOTFOUND) break;
         strcpy(iins_type,trim(iins_type));
         printf("trace iins_type[%s]\n ",iins_type);

         /* ���ը���X�I���J�p,�G�L�������ե�  add by sylvia 105.03.03 */
         if ((strcmp(iins_type,"145") == 0) || (strcmp(iins_type,"146") == 0) ||
             (strcmp(iins_type,"148") == 0) || (strcmp(iins_type,"58") == 0) ||
             (strcmp(iins_type,"73") == 0) || (strcmp(iins_type,"74") == 0) ||
             (strcmp(iins_type,"75") == 0) || (strcmp(iins_type,"76") == 0))
         continue;

         /* �D����3��*/

         printf("----�D���ӥ�[iins_type= %s] ---------  \n ",iins_type);
	 $DECLARE cur_Ins1 CURSOR FOR
	   SELECT first 3 a.ipolicy  FROM policy_302 a , ply_ins_type_302 b
	    WHERE a.ipolicy=b.ipolicy
	      AND b.iins_type = $iins_type
	      AND (a.ibig_comp = ' ' or a.ibig_comp is null)
	      AND a.dply_begin between $sDplyEndBgn and $sDplyEndEnd
	      AND a.ipolicy not in (select ipolicy from tmpAll where ipolicy = a.ipolicy);
	 $OPEN cur_Ins1;
	 while(1)
	 {
	     $FETCH cur_Ins1 INTO $ipolicy;
	     if(SQLCODE == SQLNOTFOUND) break;
	     $Insert Into tmpIns values ($iins_type,$ipolicy );
	     $Insert Into tmpAll values ($ipolicy,' ' );
	 }
	 $CLOSE cur_Ins1;
	 $FREE  cur_Ins1;

         /* ����2��*/
         printf("----���ӥ�[iins_type= %s] ---------  \n ",iins_type);
         
         $DECLARE cur_Ins2 CURSOR FOR
           SELECT first 2 a.ipolicy  FROM policy_302 a , ply_ins_type_302 b
            WHERE a.ipolicy=b.ipolicy
              AND b.iins_type = $iins_type
              AND nvl(a.ibig_comp,' ' ) <> ' '
              AND a.ipolicy not in (select ipolicy from tmpAll where ipolicy = a.ipolicy)
              AND a.dply_begin between $sDplyEndBgn and $sDplyEndEnd ;
	 $OPEN cur_Ins2;
	 while(1)
	 {
	     $FETCH cur_Ins2 INTO $ipolicy;
	     if(SQLCODE == SQLNOTFOUND) break;
	     $Insert Into tmpIns values ($iins_type,$ipolicy );
	     $Insert Into tmpAll values ($ipolicy,' ' );
	 }
	 $CLOSE cur_Ins2;
	 $FREE  cur_Ins2;

	 /* �M��5��*/

	 if (strcmp(iins_type,"11")==0)
	 {
	     printf("----�M�ץ�[iins_type= %s] ---------  \n ",iins_type);
	     $DECLARE cur_Ins3 CURSOR FOR
	       SELECT first 5 a.ipolicy  FROM policy_302 a , ply_ins_type_302 b
	        WHERE a.ipolicy=b.ipolicy
	          AND b.iins_type = $iins_type
	          AND a.iofficer[1,1] in ('W','H','N')
	          AND a.iofficer[1,2] not in ('H0','H1','H2')
	          AND a.ipolicy not in (select ipolicy from tmpAll where ipolicy = a.ipolicy)
	          AND a.dply_begin between $sDplyEndBgn and $sDplyEndEnd ;
	     $OPEN cur_Ins3;
	     while(1)
	     {
	         $FETCH cur_Ins3 INTO $ipolicy;
		 if(SQLCODE == SQLNOTFOUND) break;
		 $Insert Into tmpIns values ($iins_type,$ipolicy );
		 $Insert Into tmpAll values ($ipolicy,' ' );
	     }
	     $CLOSE cur_Ins3;
	     $FREE  cur_Ins3;
	 }
     }
     $CLOSE cur_Ins;
     $FREE  cur_Ins;

     count_A = 0; count_B = 0; count_C = 0;
     printf("�U���ب����ե� ---------------------------\n ");
     
     /* �U���ب����ե� */
     sprintf(stmt,"SELECT icode FROM car_type Where fclass='1' and icode not in ('T1','T2') Order By icode " );
     $PREPARE  preCar_stmt FROM $stmt;
     $DECLARE  cur_Car CURSOR FOR preCar_stmt;
     $OPEN     cur_Car;
     while(1)
     {
         $FETCH cur_Car INTO $icar_type;
         if(SQLCODE == SQLNOTFOUND) break;
         printf("trace icar_type[%s]\n ",icar_type);


         /* �D����3��*/
         printf("----�D���ӥ�[icar_type= %s] ---------  \n ",icar_type);
	          
	 $DECLARE cur_Car1 CURSOR FOR
           SELECT first 3 iengine FROM policy_302
            WHERE icar_type = $icar_type
              AND fcard_class='2'
              AND nvl(irelative_ply,' ') <> ' '
              AND (ibig_comp = ' ' or ibig_comp is null)
              AND ipolicy not in (select ipolicy from tmpAll where ipolicy = policy_302.ipolicy)
              AND iengine not in (select iengine from tmpAll where iengine = policy_302.iengine)
	      AND dply_begin between $sDplyEndBgn and $sDplyEndEnd;
	 $OPEN cur_Car1;
	 while(1)
	 {
	     $FETCH cur_Car1 INTO $iengine;
	     if(SQLCODE == SQLNOTFOUND) break;
	     $Insert Into tmpCar values ($icar_type,$iengine );
	     $Insert Into tmpAll values (' ', $iengine );
	 }
	 $CLOSE cur_Car1;
	 $FREE  cur_Car1;

	 /* ����2��*/
	 printf("----���ӥ�[icar_type= %s] ---------  \n ",icar_type);
	 $DECLARE cur_Car2 CURSOR FOR
           SELECT first 2 iengine FROM policy_302
            WHERE icar_type = $icar_type
              AND fcard_class='2'
              AND nvl(irelative_ply,' ') <> ' '
              AND nvl(ibig_comp,' ' )    <> ' '
              AND ipolicy not in (select ipolicy from tmpAll where ipolicy = policy_302.ipolicy)
              AND iengine not in (select iengine from tmpAll where iengine = policy_302.iengine)
	      AND dply_begin between $sDplyEndBgn and $sDplyEndEnd;
	 $OPEN cur_Car2;
	 while(1)
	 {
	     $FETCH cur_Car2 INTO $iengine;
	     if(SQLCODE == SQLNOTFOUND) break;
	     $Insert Into tmpCar values ($icar_type,$iengine );
	     $Insert Into tmpAll values (' ', $iengine );
	 }
	 $CLOSE cur_Car2;
	 $FREE  cur_Car2;

	 /* �M��2��*/
	 printf("----�M�ץ�[icar_type= %s] ---------  \n ",icar_type);

	 $DECLARE cur_Car3 CURSOR FOR
           SELECT first 2 iengine FROM policy_302
            WHERE icar_type = $icar_type
              AND fcard_class='2'
              AND iofficer[1,1] in ('W','H','N')
              AND iofficer[1,2] not in ('H0','H1','H2')
              AND ipolicy not in (select ipolicy from tmpAll where ipolicy = policy_302.ipolicy)
              AND iengine not in (select iengine from tmpAll where iengine = policy_302.iengine)
	      AND dply_begin between $sDplyEndBgn and $sDplyEndEnd;
	 $OPEN cur_Car3;
	 while(1)
	 {
	     $FETCH cur_Car3 INTO $iengine;
	     if(SQLCODE == SQLNOTFOUND) break;
	     $Insert Into tmpCar values ($icar_type,$iengine );
	     $Insert Into tmpAll values (' ', $iengine );
	 }
	 $CLOSE cur_Car3;
	 $FREE  cur_Car3;
	 
	 /*1.����B�ѵs�I�O�O�˥��W�h:�񤭭Ӧ~��,�C�@����,01�B05�B09�B11�B85�B98�O�O */
	 printf("----����B�ѵs�I�O�O�˥��W�h:�񤭭Ӧ~��,�C�@����,01�B05�B09�B11�B85�B98�O�O[icar_type= %s] ---------  \n ",icar_type);
	 printf("1.����B�ѵs�I�O�O�˥��W�h: icar_type[%s]\n ",icar_type);
	 printf("trace iplyyear[%d]\n ",iplyyear);
	     
	     
	 if (strcmp(icar_type,"51") == 0)
	 {
	     printf("51���صL�ӫO01�B05�B09�B11�B85�B98�I��!!");
	 }
	 else
	 {
             for( i=iplyyear; i> (iplyyear-5); i--)
             {
                 printf("trace �~�� i[%d]\n ",i);
             	 for( j = 0; j <6; j++)
             	 {
             	     printf("trace ins_set1[%d]=[%s]\n ",j, ins_set1[j]);


    	             sprintf(stmt," SELECT skip %d first 1 a.ipolicy,a.iengine FROM policy_302 a,ply_ins_type_302 b \
    		                     WHERE a.ipolicy      = b.ipolicy \
    		                       AND a.icar_type    = '%s' \
    		                       AND Year(a.dissue) =  %d  \
    		                       AND b.iins_type <> '21' \
    		                       AND nvl(a.irelative_ply,' ') <> ' ' \
                                       AND b.iins_type    = '%s' \
                                       AND a.ipolicy not in (select ipolicy from tmpAll where ipolicy = a.ipolicy) \
                                       AND a.iengine not in (select iengine from tmpAll where iengine = a.iengine) \
    			               AND a.dply_begin between '%s' and '%s'",
    			             count_A ,icar_type, i, ins_set1[j],sDplyEndBgn,sDplyEndEnd);
    		     printf("trace stmt[%s]\n ",stmt);
    		     $PREPARE  preCar_stmt FROM $stmt;
    		     $DECLARE  cur_Car4 CURSOR FOR preCar_stmt;
    		     $OPEN cur_Car4;
    		     while(1)
    		     {
    		         $FETCH cur_Car4 INTO $ipolicy,$iengine;
    			 if(SQLCODE == SQLNOTFOUND) break;
    			 printf("trace iengine[%s]\n ",iengine);
    			 $Insert Into tmpOther values ($icar_type,$ipolicy,$iengine,'A',' ');
    			 $Insert Into tmpAll values (' ', $iengine );
    			 count_A ++;
    		     }
    		     $CLOSE cur_Car4;
    		     $FREE  cur_Car4;
    		 }
             }
         }
         
         /*2.���NTPL�O�O�G �˥��W�h:�C�@����,�C�@�Y�� */
	 /* �Ҧ����d�I�Y�� */
	 printf("2. ���NTPL�O�O�G �˥��W�h:�C�@����,�C�@�Y��[icar_type= %s]  \n ",icar_type);

	 if (strcmp(icar_type, "51") == 0)
	 {
	     printf("51���صL�ӫO31�I��!!");
	 }
	 else
	 {
    	     sprintf(stmt," SELECT DISTINCT pcomp_factor  FROM ca_comp_acc_factor WHERE fcard_class='2' \
                               AND drate= (SELECT drate FROM ca_rate_date \
    	                                    WHERE icode ='%s' AND itable = 'ca_comp_acc_factor')", rate_icode2);
    	     $PREPARE  preCar_stmt FROM $stmt;
    	     $DECLARE  cur_Car5 CURSOR FOR preCar_stmt;
    	     $OPEN     cur_Car5;
    	     while(1)
    	     {
    	         $FETCH cur_Car5 INTO $dbl_plia_acc;
    	         if(SQLCODE == SQLNOTFOUND) break;

             	 sprintf(s_plia_acc,"%4.2f",dbl_plia_acc);
             	 printf("trace s_plia_acc[%s]\n ",s_plia_acc);


    		 sprintf(stmt," SELECT skip %d first 1 a.ipolicy,a.iengine FROM policy_302 a,ply_ins_type_302 b \
    	                         WHERE a.ipolicy      = b.ipolicy \
    	                           AND a.icar_type    = '%s' \
    	                           AND a.plia_acc     = '%s' \
    	                           AND nvl(a.irelative_ply,' ') <> ' ' \
    	                           AND b.iins_type    = '31' \
                                   AND a.ipolicy not in (select ipolicy from tmpAll where ipolicy = a.ipolicy) \
                                   AND a.iengine not in (select iengine from tmpAll where iengine = a.iengine) \
    		                   AND a.dply_begin between '%s' and '%s'",
    		             count_B ,icar_type, s_plia_acc ,sDplyEndBgn,sDplyEndEnd);
                 printf("trace stmt[%s]\n ",stmt);
    	         $PREPARE  preCar_stmt FROM $stmt;
    	         $DECLARE  cur_Car5_1 CURSOR FOR preCar_stmt;
    		 $OPEN cur_Car5_1;
    		 while(1)
    		 {
    		     $FETCH cur_Car5_1 INTO $ipolicy,$iengine;
    		     if(SQLCODE == SQLNOTFOUND) break;
    		     printf("trace iengine[%s]\n ",iengine);
    		     $Insert Into tmpOther values ($icar_type,$ipolicy,$iengine,'B',' ');
    		     $Insert Into tmpAll values (' ', $iengine );
    		     count_B ++;
    		 }
    		 $CLOSE cur_Car5_1;
    		 $FREE  cur_Car5_1;
    	     }
    	     $CLOSE cur_Car5;
    	     $FREE  cur_Car5;
         }
         
         /*3.�k�k�ʧO�O�O�G�˥��W�h:03�B04�B22����,�C�@�~�֯ŶZ,01�B05�B09�B31�O�O */
         printf("3. �k�k�ʧO�O�O�G�˥��W�h:03�B04�B22����,�C�@�~�֯ŶZ,01�B05�B09�B31�O�O[icar_type= %s] ---------  \n ",icar_type);
         
         if ( (strcmp(icar_type,"03")==0)||(strcmp(icar_type,"04")==0)||(strcmp(icar_type,"22")==0) )
         {
             for( i=1; i<3; i++)
             {
             	 strcpy(s_fsex,itoa(i));
             	 printf("trace s_fsex[%s]\n ",s_fsex);
             	 for( j = 0; j <4; j++)
             	 {
	             printf("trace ins_set2[%d]=[%s]\n ",j,ins_set2[j]);
	             dbl_qage_bgn = 0.0 ; dbl_qage_end = 0.0 ;
	             if (strncmp(ins_set2[j],"31",2)!=0)
	             {
		         sprintf(stmt," SELECT DISTINCT qage_bgn,(qage_end-0.08) FROM ca_sex_age_factor \
				         WHERE fcard_class = '3' And fsex = '%s' \
				           And  drate=(SELECT drate FROM ca_rate_date \
					                WHERE icode  ='%s' AND itable = 'ca_sex_age_factor3') \
					 Order by 1 ",s_fsex, rate_icode2);
	             }
	             else
	             {
			 sprintf(stmt," SELECT DISTINCT qage_bgn,(qage_end-0.08) FROM ca_sex_age_factor \
				         WHERE fcard_class = '2' And fsex = '%s' \
				           And  drate=(SELECT drate FROM ca_rate_date \
					                WHERE icode  ='%s' AND itable = 'ca_sex_age_factor2') \
					 Order by 1 ",s_fsex, rate_icode2);
	             }
	             
		     $PREPARE  preCar_stmt FROM $stmt;
		     $DECLARE  cur_Car6 CURSOR FOR preCar_stmt;
		     $OPEN     cur_Car6;
		     while(1)
		     {
		         $FETCH cur_Car6 INTO $dbl_qage_bgn,$dbl_qage_end;
			 if(SQLCODE == SQLNOTFOUND) break;

			 printf("trace dbl_qage_bgn[%f] ,dbl_qage_end[%f]\n ",dbl_qage_bgn,dbl_qage_end);


			 sprintf(stmt," SELECT skip %d first 1 a.ipolicy,a.iengine FROM policy_302 a,ply_ins_type_302 b \
				         WHERE a.ipolicy      = b.ipolicy \
				           AND a.icar_type    = '%s' \
				           AND a.fassured IN ('1','3','5') \
				           AND nvl(a.irelative_ply,' ') <> ' ' \
		                           AND b.iins_type    = '%s' \
		                           AND a.ipolicy not in (select ipolicy from tmpAll where ipolicy = a.ipolicy) \
		                           AND a.iengine not in (select iengine from tmpAll where iengine = a.iengine) \
		                           AND a.dply_begin between date_add(a.dbirth,%f units year) and date_add(a.dbirth,%f units year) \
					   AND a.dply_begin between '%s' and '%s'",
				       count_C ,icar_type, ins_set2[j],dbl_qage_bgn,dbl_qage_end,sDplyEndBgn,sDplyEndEnd);
                         printf("trace stmt[%s]\n ",stmt);
			 $PREPARE  preCar_stmt FROM $stmt;
			 $DECLARE  cur_Car6_1 CURSOR FOR preCar_stmt;
			 $OPEN cur_Car6_1;
			 while(1)
			 {
			     $FETCH cur_Car6_1 INTO $ipolicy,$iengine;
			     if(SQLCODE == SQLNOTFOUND) break;
			     printf("trace iengine[%s]\n ",iengine);
			     $Insert Into tmpOther values ($icar_type,$ipolicy,$iengine,'C',' ');
			     $Insert Into tmpAll values (' ', $iengine );
			     count_C ++;
			 }
			 $CLOSE cur_Car6_1;
			 $FREE  cur_Car6_1;
		     }
		     $CLOSE cur_Car6;
		     $FREE  cur_Car6;
		 }
             }
         }
         
         /*�N��1��*/   
         printf("----�N��[icar_type= %s] ---------  \n ",icar_type);
	          
	 $DECLARE cur_Car7 CURSOR FOR
           SELECT first 1 iengine FROM policy_302
            WHERE icar_type = $icar_type
              AND fcard_class='2'
              AND nvl(irelative_ply,' ') <> ' '
              AND iroute[1,4] = 'I823'
              AND (ibig_comp = ' ' or ibig_comp is null)
              AND ipolicy not in (select ipolicy from tmpAll where ipolicy = policy_302.ipolicy)
              AND iengine not in (select iengine from tmpAll where iengine = policy_302.iengine)
	      AND dply_begin between $sDplyEndBgn and $sDplyEndEnd;
	 $OPEN cur_Car7;
	 while(1)
	 {
	     $FETCH cur_Car7 INTO $iengine;
	     if(SQLCODE == SQLNOTFOUND) break;
	     $Insert Into tmpCar values ($icar_type,$iengine );
	     $Insert Into tmpAll values (' ', $iengine );
	 }
	 $CLOSE cur_Car7;
	 $FREE  cur_Car7;     
         
               
         /*�I��1��*/
         printf("----�I��[icar_type= %s] ---------  \n ",icar_type);
	          
	 $DECLARE cur_Car8 CURSOR FOR
           SELECT first 1 iengine FROM policy_302
            WHERE icar_type = $icar_type
              AND fcard_class='2'
              AND nvl(irelative_ply,' ') <> ' '
              AND iroute[1,10] = 'BA27986706'
              AND (ibig_comp = ' ' or ibig_comp is null)
              AND ipolicy not in (select ipolicy from tmpAll where ipolicy = policy_302.ipolicy)
              AND iengine not in (select iengine from tmpAll where iengine = policy_302.iengine)
	      AND dply_begin between $sDplyEndBgn and $sDplyEndEnd;
	 $OPEN cur_Car8;
	 while(1)
	 {
	     $FETCH cur_Car8 INTO $iengine;
	     if(SQLCODE == SQLNOTFOUND) break;
	     $Insert Into tmpCar values ($icar_type,$iengine );
	     $Insert Into tmpAll values (' ', $iengine );
	 }
	 $CLOSE cur_Car8;
	 $FREE  cur_Car8;
         
         
         
         
     }
     $CLOSE cur_Car;
     $FREE  cur_Car;
     printf("trace 2 ---------------------------\n ");

     /* �s�W�s�r���ƪ����ո��--itype=D (20�����) */
     $insert into tmpOther
      select first 20 a.icar_type, a.ipolicy, a.iengine, 'D', a.qdrunk_driving
        from policy_302 a, ply_ins_type_302 b
       where a.ipolicy = b.ipolicy
         and a.dply_begin between $sDplyEndBgn and $sDplyEndEnd
         and b.iins_type = '21'
         and a.qdrunk_driving > 0 ;

     /*�s�W���j�H�W���ƪ����ո��--itype=E (20�����)*/
     $insert into tmpOther
      select first 20 a.icar_type, a.ipolicy, a.iengine, 'E', a.qviolate
        from policy_302 a, ply_ins_type_302 b
       where a.ipolicy = b.ipolicy
         and a.dply_begin between $sDplyEndBgn and $sDplyEndEnd
         and b.iins_type = '21'
         and a.qviolate > 0 ;
         
         
     if (flg==2){  /* �n�P�ɲ��s���ե��ɮ� */
     	 $Delete From newa00:ca_tmp_no Where 1=1;
     }

     /* �I�ش�����*/
     fprintf(fptr1,"%s\n",sTitle1);

     sprintf(stmt,"SELECT b.iins_type,a.ipolicy ,nvl(a.itag,'�@'),  \n\
                          a.iengine,a.icar_type,a.iofficer,a.iroute,\n\
                          CASE \n\
                              WHEN b.iins_type <> '21' then a.v_ori_prem \n\
                              ELSE a.comp_prem \n\
                          END \n\
                     FROM policy_302 a , tmpIns b \n\
                    WHERE a.ipolicy = b.ipolicy \n\
                    ORDER BY 1 " );

     printf("stmt[%s]\n", stmt);
     $PREPARE  pre_stmt FROM $stmt;
     $DECLARE  cur_test1 CURSOR FOR pre_stmt;
     $OPEN     cur_test1;
     while (1)
     {
          $FETCH cur_test1
            INTO $iins_type, $ipolicy, $itag, $iengine, $icar_type, $iofficer, $iroute, $prem;
          if(SQLCODE == SQLNOTFOUND) break;

          strcpy(prtstr1,rtrim(iins_type));
          strcat(prtstr1,"\t");
          strcat(prtstr1,rtrim(ipolicy));
          strcat(prtstr1,"\t");
          strcat(prtstr1,rtrim(itag));
          strcat(prtstr1,"\t");
          strcat(prtstr1,rtrim(iengine));
          strcat(prtstr1,"\t");
          strcat(prtstr1,rtrim(icar_type));
          strcat(prtstr1,"\t");
          strcat(prtstr1,rtrim(iofficer));
          strcat(prtstr1,"\t");
          strcat(prtstr1,rtrim(iroute));
          strcat(prtstr1,"\t");
          strcpy(c_prem,itoa(prem));
          strcat(prtstr1,rtrim(c_prem));

          fprintf(fptr1,"%s\n",prtstr1);

          if (flg==2){
               $Insert Into newa00:ca_tmp_no Values($ipolicy);
          }
     }
     $CLOSE cur_test1;
     $FREE  cur_test1;
     fclose(fptr1);

     /* ���ش�����*/
     fprintf(fptr2,"%s\n",sTitle2);

     sprintf(stmt,"SELECT a.fcard_class,a.ipolicy,nvl(a.itag,'�@'),\n\
                          a.iengine,a.icar_type,a.iofficer,a.iroute,\n\
                         CASE \n\
                            WHEN a.fcard_class = '1' then a.comp_prem \n\
                         ELSE a.v_ori_prem \n\
                         END  \n\
                     FROM policy_302 a , tmpCar b\n\
                    WHERE a.iengine  = b.iengine\n\
                    ORDER BY 3,1 " );

     printf("stmt[%s]\n", stmt);
     $PREPARE  pre_stmt FROM $stmt;
     $DECLARE  cur_test2 CURSOR FOR pre_stmt;
     $OPEN     cur_test2;
     while (1)
     {
          $FETCH cur_test2
            INTO $fcard_class, $ipolicy, $itag, $iengine, $icar_type, $iofficer, $iroute, $prem;
          if(SQLCODE == SQLNOTFOUND) break;

          strcpy(prtstr1,rtrim(fcard_class));
          strcat(prtstr1,"\t");
          strcat(prtstr1,rtrim(ipolicy));
          strcat(prtstr1,"\t");
          strcat(prtstr1,rtrim(itag));
          strcat(prtstr1,"\t");
          strcat(prtstr1,rtrim(iengine));
          strcat(prtstr1,"\t");
          strcat(prtstr1,rtrim(icar_type));
          strcat(prtstr1,"\t");
          strcat(prtstr1,rtrim(iofficer));
          strcat(prtstr1,"\t");
          strcat(prtstr1,rtrim(iroute));
          strcat(prtstr1,"\t");
          strcpy(c_prem,itoa(prem));
          strcat(prtstr1,rtrim(c_prem));

          fprintf(fptr2,"%s\n",prtstr1);

          if (flg==2){
               $Insert Into newa00:ca_tmp_no Values($ipolicy);
          }
     }
     $CLOSE cur_test2;
     $FREE  cur_test2;
     fclose(fptr2);

     /* ��L������*/
     fprintf(fptr3,"%s\n",sTitle3);


     sprintf(stmt,"SELECT b.itype, a.ipolicy,nvl(a.itag,'�@'), \n\
                          a.iengine,a.icar_type,a.iofficer,a.iroute,\n\
                          CASE \n\
                              WHEN a.fcard_class = '1' then a.comp_prem \n\
                              ELSE a.v_ori_prem \n\
                          END, b.qdrunk \n\
                     FROM policy_302 a , tmpOther b\n\
                    WHERE a.ipolicy  = b.ipolicy\n\
                    ORDER BY 1,4 " );

     printf("stmt[%s]\n", stmt);
     $PREPARE  pre_stmt FROM $stmt;
     $DECLARE  cur_test3 CURSOR FOR pre_stmt;
     $OPEN     cur_test3;
     while (1)
     {
          $FETCH cur_test3
            INTO $itype, $ipolicy, $itag, $iengine, $icar_type, $iofficer, $iroute, $prem, $qdrunk;
          if(SQLCODE == SQLNOTFOUND) break;

          strcpy(prtstr1,rtrim(itype));
          strcat(prtstr1,"\t");
          strcat(prtstr1,rtrim(ipolicy));
          strcat(prtstr1,"\t");
          strcat(prtstr1,rtrim(itag));
          strcat(prtstr1,"\t");
          strcat(prtstr1,rtrim(iengine));
          strcat(prtstr1,"\t");
          strcat(prtstr1,rtrim(icar_type));
          strcat(prtstr1,"\t");
          strcat(prtstr1,rtrim(iofficer));
          strcat(prtstr1,"\t");
          strcat(prtstr1,rtrim(iroute));
          strcat(prtstr1,"\t");
          strcpy(c_prem,itoa(prem));
          strcat(prtstr1,rtrim(c_prem));
          strcat(prtstr1,"\t");
          strcat(prtstr1,rtrim(qdrunk));  /* �s�r���ơB���j�H�W���� */

          fprintf(fptr3,"%s\n",prtstr1);

          if (flg==2){
               $Insert Into newa00:ca_tmp_no Values($ipolicy);
          }
     }
     $CLOSE cur_test3;
     $FREE  cur_test3;
     fclose(fptr3);
     return 1;

errexit:
   printf("-----gen_test2_list : SQLCODE[%d]\n",SQLCODE);
   EWRITE(userid, SQLCODE,sqlca.sqlerrm);
   return SQLCODE;

}
