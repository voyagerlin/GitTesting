/************************************************/
/*                                              */
/*   PROGRAM : caqbase1.ec by Han-Cheng Chen    */
/*                                              */
/*   PURPOSE : Get detailed descripyion of a    */
/*             named item                       */
/*                                              */
/************************************************/

#include <stdio.h>
#include <string.h>
#include <decimal.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "bfsmsgs.h"
#include "cmnmsgs.h"
#include "commsgs.h"
#include "car_common.h"
#include "safeclib.h"
$include sqlca;
$include "var_length.h";
$include cmnroute.h;


/* *** Code block *** */
#define _T860701

/* *** Message block *** */
/************************
#define _M860701
 ************************/

#define SUCCESS                 1
#define TURE                    1
#define FALSE                   0
#define FOUND                   sqlca.sqlcode!=SQLNOTFOUND
#define NOT_FOUND               sqlca.sqlcode==SQLNOTFOUND
#define EQUAL(s1,s2)            !strcmp(s1,s2)
#define NOT_EQUAL(s1,s2)        strcmp(s1,s2)
/*
*  Name: caqbase1
*
*  Description: The purpose of this function is to select corresponding
*               name from database according to the namecode and option.
*
*/

double d45();
char   v_sMsg[1512];

long caqbase1(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
    long rtncode;
    long select_car_name(),car401_mult_ply(), select_car_series(), select_ins_name(),
         select_brand_name(), select_material_name();
    long get_assured_name(), get_benef_name(), get_benef1_name(), get_brand_data(),
         get_ins_type_info(), check_card1(), check_card2();
    long get_brand_data1();
    long get_brand_data2();
    long car508_get_closing_date();
    long get_big_inst_info();
    long get_resource_info();
    long get_officer_info();
    long select_card_exist();
    long get_adjuster_info();
    long get_acc_reason_info();
    long get_pacc_reason_info();
    long get_adj_comment_info();
    long get_close_limit_info();
    long get_daily_closing_ctl_info();
    long get_dmg_brg_factor_info();
    long check_officer_change();
    long select_car_type();
    long get_psex_age();
    long get_daily_closing_ctl();
    long get_broker_info();
    long get_collect_area();
    long get_fagent();
    long get_officer();
    long car202_max_card();
    long get_branch_nchi_abv();
    long get_rate_code();
    long get_big_resource();
    long get_accident_record();
    long get_ca_big_office_info();
    long get_fins_grp();
    long get_max_rate_code();
    long get_comp_acc_factor();
    long get_ins_comm_agent();
    long get_ca_dvp_ply_area();
    long get_compulsory_mbusiness();
    long get_user_branch();
    long get_user_info();
    long get_list_ins_comm_agent();
    long get_ca_zipcode();
    long get_ca_trans_ply();
    long get_ca_big_office_name();
    long get_ca_rate_renew_code();
    long get_brand_engine();
    long get_add_mplace_day();
    long get_user_fadu();
    long check_iins_29_3132();
    long get_act_groupinfo();
    long get_b2b_motor_est();
    long get_iinstall();
    long W_office_chk();
    long get_ins_comm_agent_comp();
    long get_billingcode();
    long get_W_office();
    long get_iuser_branch();
    char option;

    cm_buf_init(command);
    cm_buf_get("%c",&option);

    switch(option)
    {
         case '1':
                  rtncode=car508_get_closing_date(reply);
                  break;
         case '2' :
                  rtncode=car401_mult_ply(reply);
                  break;
         case '3' :
                  rtncode=get_fagent(reply);
                  break;
         case '4' :
                  rtncode=get_officer(reply);
                  break;
         case '5' :
                  rtncode=get_branch_nchi_abv(reply);
                  break;
         case '6' :
                  rtncode=car202_max_card(reply);
                  break;
         case '7' :
                  rtncode=get_rate_code(reply);
                  break;
         case '8' :
                  rtncode=get_accident_record(reply);
                  break;
         case '9' :
                  rtncode=get_ca_big_office_info(reply);
                  break;
         case '0' :
                  rtncode=select_card_exist(reply);
                  break;
         case 'A':
                  rtncode=select_car_name(reply);
                  break;
         case 'B':
                  rtncode=select_car_series(reply);
                  break;
         case 'C':
                  rtncode=select_ins_name(reply);
                  break;
         case 'D':
                  rtncode=select_brand_name(reply);
                  break;
         case 'E':
                  rtncode=select_material_name(reply);
                  break;
         case 'F':
                  rtncode=get_assured_name(reply);
                  break;
         case 'G':
                  rtncode=get_benef_name(reply);
                  break;
         case 'H':
                  rtncode=get_brand_data(reply);
                  break;
         case 'I':
                  rtncode=get_ins_type_info(reply);
                  break;
         case 'J':
                  rtncode=get_resource_info(reply);
                  break;
         case 'K':
                  rtncode=get_big_inst_info(reply);
                  break;
         case 'L':
                  rtncode=get_officer_info(reply);
                  break;
         case 'M':
                  rtncode=get_adjuster_info(reply);
                  break;
         case 'N':
                  rtncode=get_acc_reason_info(reply);
                  break;
         case 'O':
                  rtncode=get_adj_comment_info(reply);
                  break;
         case 'P':
                  rtncode=get_close_limit_info(reply);
                  break;
         case 'Q':
                  rtncode=get_daily_closing_ctl_info(reply);
                  break;
         case 'R':
                  rtncode=get_dmg_brg_factor_info(reply);
                  break;
         case 'S':
                  rtncode=get_brand_data1(reply);
                  break;
         case 'T':
                  rtncode=check_officer_change(reply);
                  break;
         case 'U':
                  rtncode=select_car_type(reply);
                  break;
         case 'V':
                  rtncode=get_psex_age(reply);
                  break;
         case 'W':
                  rtncode=get_daily_closing_ctl(reply);
                  break;
         case 'X':
                  rtncode=get_broker_info(reply);
                  break;
         case 'Y':
                  rtncode=get_collect_area(reply);
                  break;
         case 'Z':
                  rtncode=get_big_resource(reply);
                  break;
         case 'a':
                  rtncode=get_fins_grp(reply);
                  break;
         case 'b':
                  rtncode=get_max_rate_code(reply);
                  break;
         case 'c':
                  rtncode=check_iins_29_3132(reply);
                  break;
         case 'd':
                  rtncode=get_comp_acc_factor(reply);
                  break;
         case 'e':
                  rtncode=get_act_groupinfo(reply);
                  break;
         case 'f':
                  rtncode=get_ca_dvp_ply_area(reply);
                  break;
         case 'g':
                  rtncode=get_ins_comm_agent(reply);
                  break;
         case 'h':
                  rtncode=get_compulsory_mbusiness(reply);
                  break;
         case 'i':
                  rtncode=get_user_branch(reply);
                  break;
         case 'j':
                  rtncode=get_corps_info(reply);
                  break;
         case 'k':
                  rtncode=get_benef1_name(reply);
                  break;
         case 'l':
                  rtncode=get_est_prem(reply);
                  break;
         case 'm':
                  rtncode=get_ply_prem(reply);
                  break;
         case 'n':
                  rtncode=get_user_info(reply);
                  break;
         case 'o':
                  rtncode=get_list_ins_comm_agent(reply);
                  break;
         case 'p':
                  rtncode=get_ca_zipcode(reply);
                  break;
         case 'q':
                  rtncode=get_ca_trans_ply(reply);
                  break;
         case 'r':
                  rtncode=get_ca_big_office_name(reply);
                  break;
         case 's':
                  rtncode=get_ca_rate_renew_code(reply);
                  break;
         case 't':
                  rtncode=select_brand_nameD(reply);
                  break;
         case 'u':
                  rtncode=get_brand_data2(reply);
                  break;
         case 'v':
                  rtncode=get_brand_engine_list(reply);
                  break;
         case 'w':
                  rtncode=get_add_mplace_day(reply);
                  break;
         case 'x':
                  rtncode=get_user_fadu(reply);
                  break;
         case 'y':
                  rtncode=get_pacc_reason_info(reply);
                  break;
         case 'z':
                  rtncode=get_b2b_motor_est(reply);
                  break;
         case '+':
                  rtncode=get_iinstall(reply);
                  break;
         case '-':
                  rtncode=get_mservice_info(reply);
                  break;
         case '~':
                  rtncode=get_ins_comm_agent_comp(reply);
                  break;
         case '!':
         	  rtncode=get_route_chk(reply);
                  break;
         case '@':
         	  rtncode=get_sales_chk(reply);
                  break;
         case '=':
         	  rtncode=get_sales_chk1(reply);
                  break;
         case '#':
                  rtncode=W_office_chk(reply);
                  break;
         case '^':
                  rtncode=get_ca_ply_ext(reply);
                  break;

         case '%':
                  rtncode=getInsuranceCover(reply);
                  break;

         case '$':
                  rtncode=get_pa_list(reply);
                  break;

         case '&':
                  rtncode=checkUsedRenewCompClass(reply);
                  break;

         case '*':
                  rtncode=checkIsDiffCompType(reply);
                  break;

         case '(':
                  rtncode=getIbrand(reply);
                  break;

         case ')':
                  rtncode=getIinsType(reply);
                  break;

         case '|':
                  rtncode=isSportsCar(reply);
                  break;

         case '_':
                  rtncode=chkIaccept(reply);
                  break;
         
         case '[':
                  rtncode=get_billingcode(reply);
                  break;
         		          
         case ']':
                  /* ���o�O�_�O�v�ۥѤƤ�flag */
         	      rtncode=get_cm_extra_charge_flag(reply); 
         	      break;
         	  
         case '{':
                  /* ���o�íp��O�B�O�O�ɪ��N�B���Ѽ� */
         	      rtncode=get_rental_days(reply); 
         	      break;
         	  
         case '}':
                  /* car9705071 �W�X�M�צ~�����i�W�M�׵��O
                     �̵��O��P�P�M��(ca_promote)���o�M�צ~��(qyear) */
         	      rtncode=get_ca_promote_qyear(reply); 
         	      break;
         case '`':
         	      /* ���oW�}�Y�g��N���^�k�᪺�g��N�� */
         	      rtncode=get_W_office(reply);
         	      break;
         case ':':
                  rtncode=getMultiCarCode(reply); /* ���O���O����from table:car_code.kind = '10' */ 
                  break;

         case ';':
                  rtncode=getPersonalData(reply); /* ���o���u���*/ 
                  break;

         case '\'':
                  rtncode=getOfficerInfo(reply); /* �d�߸g��N���޲z�H�����B�ǯu�B���}�B�q�ܡB�m�W */ 
                  break;
                  
         case '<':
                  /* ���o�íp��O�B�O�O�ɪ���Q���{�� */
         	      rtncode=get_rental_km(reply); 
         	      break;

         case '>':
                  rtncode=get_iuser_branch(reply);
                  break;
         case '.':
                  rtncode=get_salesman_iregNo(reply);
                  break;

         default :
                  if (exitsub(reply,M_CM_WRONG_OPTION) == True)
                     return M_CM_WRONG_OPTION;
                  return apiRC;
    }
    return(rtncode);
}

/*
*  Name: car508_get_closing_date
*
*  Description: Select last closing date from database
*               type='1' : get policy closing date
*               type='2' : get endorse closing date
*               type='3' : get settlement closing date
*/
long get_user_fadu(reply)
serverReply reply;
{
    $char DBName[5];
    int tmp_len;
    $long fadu;
    $char falldb[2];
    $char userid[11];
    $char ipgid[9];

    cm_buf_get("%s %s %s",DBName,userid,ipgid);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
      if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
        return M_CM_DB_NOTOPEN;
      else
        return apiRC;
    }
 
    $SELECT falldb,fadu
       INTO $falldb,$fadu
       FROM privilege
      WHERE iemp = $userid
        AND ipgid = $ipgid;
     if (SQLCODE == SQLNOTFOUND)
     {
         fadu = 0;
         strcpy(falldb,"N");
     }

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %l",M_CM_OK,falldb,fadu);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
      return apiRC;
    else
      return api_OKComplete;

errexit:
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long check_iins_29_3132(reply)
serverReply reply;
{
    $char DBName[5];
    int   tmp_len;

    $char sMdeduct29[10];
    $long lMcoverage1;
    $long lMcoverage2;
    $long lMcoverage3;
    $char sPrn_deduct[20];

    cm_buf_get("%s %s %l %l %l",DBName,sMdeduct29,&lMcoverage1,&lMcoverage2,&lMcoverage3);

    strcpy(sMdeduct29, trim(sMdeduct29));

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
        else
            return apiRC;
    }
 
    if ((lMcoverage1 == 0) && (lMcoverage2 == 0) && (lMcoverage3 == 0))
    {
         /* �H��h�O�B�N��select�������ĤT�H�d���I���O�I���B */
         $SELECT prn_deduct,    mcoverage1,  mcoverage2,   mcoverage3
            INTO :sPrn_deduct, :lMcoverage1, :lMcoverage2, :lMcoverage3
            FROM ca_dmg_mdeduct
           WHERE icar_type = "I29"
             AND ideduct   = :sMdeduct29;

         if(SQLCODE==SQLNOTFOUND)
         {
              /* �W�B�d���I�L��������h�O�B���,�Ц�car126�إ߬������ */
              if(exitsub(reply,M_CA_29_NODEDUCT) == True)
                   return M_CA_29_NODEDUCT;
              else
                   return apiRC;
         }
    }
    else
    {
         /* �H��h�O�B�N��select�������ĤT�H�d���I���O�I���B */
         $SELECT prn_deduct
            INTO :sPrn_deduct
            FROM ca_dmg_mdeduct
           WHERE icar_type  = "I29"
             AND ideduct    = :sMdeduct29
             AND mcoverage1 = :lMcoverage1
             AND mcoverage2 = :lMcoverage2
             AND mcoverage3 = :lMcoverage3;

         if(SQLCODE==SQLNOTFOUND)
         {
             if(exitsub(reply,M_CA_29_DEDUCT_ERROR) == True)
                  return M_CA_29_DEDUCT_ERROR;
             else
                  return apiRC;
         }
    }

    /* �^�ǡG�C�L�ۭt�B�A�W�B�d���I��h�O�B���O�I���B�@,�O�I���B�G,�O�I���B�T */
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %l %l %l",M_CM_OK , sPrn_deduct , lMcoverage1 , lMcoverage2 , lMcoverage3);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
    else
         return api_OKComplete;

errexit:
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long car508_get_closing_date(reply)
serverReply reply;
{
    $char DBName[5],op_type[3];
    $long lastday;
    char  s_lastday[10],type[2];
    int tmp_len;

    cm_buf_get("%s %s",DBName,type);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
      if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
        return M_CM_DB_NOTOPEN;
      else
        return apiRC;
    }

    sprintf_s(op_type,sizeof op_type,"C%c",type[0]);
    $SELECT dclosing
     INTO   $lastday
     FROM   daily_closing_ctl
     WHERE  iop_type=$op_type;

    if(SQLCODE==SQLNOTFOUND)
    {
     if(exitsub(reply,M_CMN_NDAILY_CLOSING_CTL) == True)
       return M_CMN_NDAILY_CLOSING_CTL;
     else
       return apiRC;
    }
    strcpy(s_lastday,cm_cdate_str_100(lastday));

    cm_buf_init(ReplyBuf);

    cm_buf_put("%l %s",M_CM_OK,s_lastday);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
      return apiRC;
    else
      return api_OKComplete;

errexit:
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long select_card_exist(reply)
serverReply reply;
{
 $char DBName[5];
 $char sIcard[20];
 int tmp_len;

 cm_buf_get("%s %s",DBName,sIcard);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }
 /** �O�_���j���� **/
 $SELECT *
    FROM compulsory_card
   WHERE icard = $sIcard;

 if (SQLCODE == SQLNOTFOUND)
 {
      /** �O�_�����N�d **/
      $SELECT *
         FROM card
        WHERE icard = $sIcard;

      if (SQLCODE == SQLNOTFOUND)
      {
         if(exitsub(reply,M_CM_NOT_FOUND) == True)
             return M_CM_NOT_FOUND;
         else
             return apiRC;
      }
 }

 cm_buf_init(ReplyBuf);

 cm_buf_put("%l ",M_CM_OK);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long car401_mult_ply(reply)
serverReply reply;
{
     $char  DBName[5];
     $char  ipolicy[20];
     $int   ply_count;
     $char  nassured[122];
     int    tmp_len;
   # ifdef _T860701
     $long  lDply_end, lToday;
     $char  sIpolicy[19], sFcard_class[2];
   # endif

     cm_buf_get("%s %s",DBName,ipolicy);

     $WHENEVER SQLERROR GOTO errexit;

     if(db_select(DBName) == False)
       return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     $SELECT nassured
        INTO $nassured
        FROM policy
       WHERE ipolicy = $ipolicy;

   # ifdef _T860701
     ply_count = 0;

     lToday = cm_today();
     $DECLARE a_cur CURSOR FOR
       SELECT a.dply_end, a.ipolicy
         INTO $lDply_end, $sIpolicy
         FROM ply_relation a, policy b
        WHERE b.nassured=$nassured
          AND a.ipolicy=b.ipolicy;
     $OPEN a_cur;
     while(1){
       $FETCH a_cur;
       if(SQLCODE == SQLNOTFOUND) break;
   # ifdef _M860701
     printf("{car401_mult_ply.0010}: dply_end[%d],today[%d]\n", lDply_end,lToday);
   # endif
       if(lDply_end <= lToday) continue;
       $SELECT fcard_class
          INTO $sFcard_class
          FROM ply_relation
         WHERE ipolicy = $sIpolicy;
       if(SQLCODE == SQLNOTFOUND) continue;
       if(*sFcard_class != '2') continue;
       ply_count++;
     }
     $CLOSE a_cur; $FREE a_cur;
   # else
     $SELECT count(*)
        into $ply_count
            FROM policy p,ply_relation r
             where p.nassured=$nassured
             and r.dply_end > today
             and p.ipolicy=r.ipolicy
             and r.fcard_class='2';
   # endif
    cm_buf_init(ReplyBuf);

    cm_buf_put("%l %d",M_CM_OK,ply_count);
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
      return apiRC;
    else
      return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/* 104.01.07 add fcar_class
*  Name: select_car_name
*
*  Description: Select car type name from database
*/
long select_car_name(reply)
serverReply reply;
{
 $char DBName[5];
 $char cartype[3];
 $char carseries[3];
 int tmp_len;
 $char carname[11]=" ",fcar_class[2]=" ";
 $char class[2];

 cm_buf_get("%s %s",DBName,cartype);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 strcpy(class, "1");
 $SELECT ncode,fcar_class
  INTO   $carname,$fcar_class
  FROM   car_type
  WHERE  fclass=$class AND icode=$cartype;

 if(SQLCODE==SQLNOTFOUND)
 {
  if(exitsub(reply,M_CA_NCARTYPE) == True)      
    return M_CA_NCARTYPE;                      
  else
    return apiRC;
 }

 cm_buf_init(ReplyBuf);

 cm_buf_put("%l %s %s",M_CM_OK,carname,fcar_class);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*
*  Name: select_car_series
*
*  Description: Select car series name from database
*/
long select_car_series(reply)
serverReply reply;
{
 $char DBName[5];
 $char carseries[3];
 $char sername[11];
 int tmp_len;
 $char class[2];

 cm_buf_get("%s %s",DBName, carseries);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }
 if(strcmp(carseries,"99")==0){
 strcpy(sername," ");}
 else{
 strcpy(class, "2");
 $SELECT ncode
  INTO   $sername
  FROM   car_type
  WHERE  fclass=$class AND icode=$carseries;

 if(SQLCODE==SQLNOTFOUND)
 {
  if(exitsub(reply,M_CA_NCAR_SERIES) == True)       
    return M_CA_NCAR_SERIES;                       
  else
    return apiRC;
 }
 }
 cm_buf_init(ReplyBuf);

 cm_buf_put("%l %s",M_CM_OK,sername);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*
*  Name: select_ins_name
*
*  Description: Select insurance type name from database
*/
long select_ins_name(reply)
serverReply reply;
{
 $char DBName[5];
 $char instype[INSURANCE_TYPE];
 $char insname[13];
 int tmp_len;

 cm_buf_get("%s %s",DBName,instype);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 $SELECT nins_abbr
  INTO   $insname
  FROM   insurance_type
  WHERE  iins_type=$instype;

 if(SQLCODE==SQLNOTFOUND)
 {
  if(exitsub(reply,M_CA_NINS_TYPE) == True)    
    return M_CA_NINS_TYPE;                    
  else
    return apiRC;
 }

 cm_buf_init(ReplyBuf);

 cm_buf_put("%l %s",M_CM_OK,insname);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*
*  Name: select_brand_name
*
*  Description: Select insurance type name from database
*/
long select_brand_nameD(reply)
serverReply reply;
{
 $char DBName[5];
 $char brandtype[9];
 $char brandname[13];
 $char branddetail[51];
 $char returnname[101];
 int tmp_len;

 cm_buf_get("%s %s",DBName,brandtype);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

printf("-------------------brand=[%s]\n",brandtype);
/* car9812112_C1 �t�P�����ɷs�W���Τ� modify by sylvia 100.09.21 */
 $SELECT UNIQUE nbrand_abbr,nbrand 
  INTO   $brandname,$branddetail
  FROM   ca_car_model   /* mag */
  WHERE  ibrand[1,6]=$brandtype
    AND  (dexpire is null or dexpire > today);

 if(SQLCODE==SQLNOTFOUND)
 {
  if(exitsub(reply,M_CA_NBRAND) == True)       /*?*/
    return M_CA_NBRAND;                        /*?*/
  else
    return apiRC;
 }

 strcpy(returnname,rtrim(brandname));
 strcat(returnname," ");
 strcat(returnname,branddetail);
 cm_buf_init(ReplyBuf);
 cm_buf_put("%l %s",M_CM_OK,returnname);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
long select_brand_name(reply)
serverReply reply;
{
 $char DBName[5];
 $char brandtype[9];
 $char brandname[13];
 int tmp_len;

 cm_buf_get("%s %s",DBName,brandtype);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

printf("-------------------brand=[%s]\n",brandtype);
/* car9812112_C1 �t�P�����ɷs�W���Τ� modify by sylvia 100.09.21 */
 $SELECT UNIQUE nbrand_abbr 
  INTO   $brandname
  FROM   ca_car_model   /* mag */
  WHERE  ibrand[1,6]=$brandtype
    AND  (dexpire is null or dexpire > today) ;

 if(SQLCODE==SQLNOTFOUND)
 {
  if(exitsub(reply,M_CA_NBRAND) == True)       /*?*/
    return M_CA_NBRAND;                        /*?*/
  else
    return apiRC;
 }

 cm_buf_init(ReplyBuf);

 cm_buf_put("%l %s",M_CM_OK,brandname);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*
*  Name: select_material_name
*
*  Description: Select material name from database
*/
long select_material_name(reply)
serverReply reply;
{
 $char DBName[5];
 $char materialtype[7];
 $char mtrname[21];
 int tmp_len;

 cm_buf_get("%s %s",DBName, materialtype);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 $SELECT nmaterial  
  INTO   $mtrname
  FROM   material 
  WHERE  imaterial=$materialtype;

 if(SQLCODE==SQLNOTFOUND)
 {
  if(exitsub(reply,M_CA_NMATERIAL) == True)       /*?*/
    return M_CA_NMATERIAL;                        /*?*/
  else
    return apiRC;
 }

 printf("mtrname[%s]\n",mtrname);
 cm_buf_init(ReplyBuf);

 cm_buf_put("%l %s",M_CM_OK,mtrname);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*
*  Name: get_assured_name 
*
*  Description: Get assured name according to assured card number.
*/
long get_assured_name(reply)
serverReply reply;
{
 $char DBName[5];
 $char ass_code[13];
 $char ass_name[31], addr[65], phone[16],type[2];
 int tmp_len;

 cm_buf_get("%s %s",DBName, ass_code);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 $SELECT nchi_full, aperm, tphone, itype 
  INTO   $ass_name, $addr, $phone, $type
  FROM   customer_basic_inf 
  WHERE  ifpce_id=$ass_code;

 if(SQLCODE==SQLNOTFOUND)
 {
  if(exitsub(reply,M_CM_NASSURED) == True)       /*?*/
    return M_CM_NASSURED;                        /*?*/
  else
    return apiRC;
 }

 cm_buf_init(ReplyBuf);

 type[1]='\0';
 cm_buf_put("%l %s %s %s %c",M_CM_OK, ass_name, addr, phone, type[0]);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*
*  Name: get_benef_name 
*
*  Description: Get beneficial name according to beneficial number.
*/
long get_benef_name(reply)
serverReply reply;
{
 $char DBName[5];
 $char ibroker[BROKER];
 $char nchi_full[43];
 $char nchi_abv[13];
 int tmp_len;

 cm_buf_get("%s %s",DBName, ibroker);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 $SELECT nchi_full,nchi_abv
    INTO $nchi_full,$nchi_abv
    FROM broker_agent 
   WHERE ibroker=$ibroker;

  nchi_full[42]='\0';   /*for car301*/

 if(SQLCODE==SQLNOTFOUND)
 {
  if(exitsub(reply,M_CMN_NBROKER_AGENT) == True)       /*?*/
    return M_CMN_NBROKER_AGENT;                          /*?*/
  else
    return apiRC;
 }

 cm_buf_init(ReplyBuf);

 cm_buf_put("%l %s %s",M_CM_OK,nchi_full,nchi_abv);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*
*  Name: get_brand_data 
*
*  Description: Get car info according to ibrand number.
*/
long get_brand_data(reply)
serverReply reply;
{
    $char   DBName[5], carname[11], fcar_class[2];
    $char   drate_ym[5];
    $char   assured_type[2];
    $char   ibrand[9], ipro_year[5], cal_pro_year[5], class[2];
    $char   brand[13], car_type[3], fuse_type[2], tmp_brand[7];
    $double cylinder;/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/
    $dec_t  price_dec;
    $char   tmp_pdmg_factor_1st[10],tmp_pbrg_factor_1st[10];
    $char   tmp_pdmg_factor_2nd[10],tmp_pbrg_factor_2nd[10], fpt[2] ;
    $double   qpassenger;
    $date   Today;
    int     int_cur_yr;
    char    cur_yr[5];
    $char   tmp_cylinder[9];/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/
    $double price,dmg_factor_1st,brg_factor_1st,dmg_factor_2nd,brg_factor_2nd;
    $short  dmg_2nd;
    int     tmp_len;

    cm_buf_get("%s %s %s %s %s", DBName, ibrand, ipro_year, assured_type, drate_ym);
    
    printf("--caqbase1: DBName[%s] brand[%s] yr[%s]\n",DBName,ibrand,ipro_year);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
        else
            return apiRC;
    }

    rtoday(&Today);     /* get today's datetime */
    strncpy(cur_yr,cm_get_sysd(),4); cur_yr[4]='\0';
    int_cur_yr=atoi(cur_yr);

    /* 104.09.09 fix ca_car_model �^���޿� */
    /* car9812112_C1 �t�P�����ɷs�W���Τ� modify by sylvia 100.09.21 */
    $DECLARE CA_OPT1 CURSOR FOR
      SELECT mcar_price , nbrand_abbr, icar_type , fuse_type  , qcylinder, qpassenger, fpt, drate
        INTO $price_dec , $brand     , $car_type , $fuse_type , $cylinder, $qpassenger, $fpt
        FROM ca_car_model
       WHERE ibrand=$ibrand
         AND ipro_year=$ipro_year
         AND (dexpire is null or dexpire > today)
       ORDER BY drate DESC;
    $OPEN CA_OPT1;
    $FETCH CA_OPT1;

    if (SQLCODE==SQLNOTFOUND)
    {
        $DECLARE CA_OPT1A CURSOR FOR
          SELECT mcar_price , nbrand_abbr , icar_type , fuse_type  , qcylinder , qpassenger, fpt, drate
            INTO $price_dec , $brand      , $car_type , $fuse_type , $cylinder, $qpassenger, $fpt
            FROM ca_car_model
           WHERE ibrand=$ibrand
             AND (dexpire is null or dexpire > today)
             AND ipro_year=(SELECT MAX(ipro_year) 
                              FROM ca_car_model
                             WHERE ibrand=$ibrand
                               AND ipro_year < $ipro_year
                               AND (dexpire is null or dexpire > today))
             ORDER BY drate DESC;
        $OPEN CA_OPT1A;
        $FETCH CA_OPT1A;
	    if (SQLCODE==SQLNOTFOUND)
	    {
	        $DECLARE CA_OPT1A1 CURSOR FOR
	          SELECT mcar_price , nbrand_abbr , icar_type , fuse_type  , qcylinder , qpassenger, fpt, drate
	            INTO $price_dec , $brand      , $car_type , $fuse_type , $cylinder, $qpassenger, $fpt
	            FROM ca_car_model
	           WHERE ibrand=$ibrand
	             AND (dexpire is null or dexpire > today)
	             AND ipro_year=(SELECT MIN(ipro_year) 
	                              FROM ca_car_model
	                             WHERE ibrand=$ibrand
	                               AND ipro_year > $ipro_year
	                               AND (dexpire is null or dexpire > today))
	             ORDER BY drate DESC;
	        $OPEN CA_OPT1A1;
	        $FETCH CA_OPT1A1;        
	        if (SQLCODE==SQLNOTFOUND)
	        {
	            if(exitsub(reply,M_CA_NBRAND) == True)      
	                return M_CA_NBRAND;                    
	            else
	                return apiRC;
	        }
	        $CLOSE CA_OPT1A1;
	        $FREE CA_OPT1A1;		        
	    }    
        $CLOSE CA_OPT1A;
        $FREE CA_OPT1A;		    
    }
    $CLOSE CA_OPT1;
    $FREE CA_OPT1;	
    	
    strcpy(class, "1");
    $SELECT ncode   , fcar_class
       INTO $carname, $fcar_class
       FROM car_type
      WHERE fclass = $class 
        AND icode  = $car_type;
    if (SQLCODE==SQLNOTFOUND) 
    {
       if(exitsub(reply,M_CA_NCARTYPE) == True)       
          return M_CA_NCARTYPE;
       else
          return apiRC;
    }
    printf("--------------fcar_class[%s] car_type[%s]\n",fcar_class,car_type);

    if (strcmp(assured_type,"2")==0 ||
        strcmp(assured_type,"4")==0 ||
        strcmp(assured_type,"6")==0)
    {
         if (strcmp(trim(car_type),"04")==0)
         {
             strcpy(car_type,"19");
         }
         
         if (strcmp(trim(car_type),"06")==0)
         {
             strcpy(car_type,"20");
         }
    }

    if (strcmp(assured_type,"1")==0 ||
        strcmp(assured_type,"3")==0 ||
        strcmp(assured_type,"5")==0)
    {
         if (strcmp(trim(car_type),"19")==0)
         {
             strcpy(car_type,"04");
         }
         
         if (strcmp(trim(car_type),"20")==0)
         {
             strcpy(car_type,"06");
         }
    }

    if (drate_ym[0] == '\0' || drate_ym[0] == ' ')
    {
         strcpy(tmp_pdmg_factor_1st,"0");
         strcpy(tmp_pbrg_factor_1st,"0");
         strcpy(tmp_pdmg_factor_2nd,"0");
         strcpy(tmp_pbrg_factor_2nd,"0");
    }
    else
    {
    	/*1040202006_C1 �s�W���ؤ���~�����²v�վ�*/ 
        if ((fcar_class[0]=='1' &&
             strcmp(car_type,"03")!=0 && strcmp(car_type,"04")!=0 &&
             strcmp(car_type,"19")!=0 && strcmp(car_type,"21")!=0 &&
             strcmp(car_type,"22")!=0 && (!(ISNEW_CAR1(car_type))) ) ||
            (fcar_class[0]=='2' &&
             strcmp(car_type,"07")!=0 && strcmp(car_type,"08")!=0 &&
             strcmp(car_type,"14")!=0 && strcmp(car_type,"15")!=0 && (!(ISNEW_CAR2(car_type))) )
           )
        {
             strncpy(tmp_brand,ibrand,6);
             tmp_brand[6]='\0';
             $SELECT pdmg_factor,pbrg_factor,pdmg_factor,pbrg_factor
                INTO $dmg_factor_1st,$brg_factor_1st,$dmg_factor_2nd,$brg_factor_2nd
                FROM car_model_align
               WHERE ibrand    = $tmp_brand 
                 AND icar_type = $car_type
                 AND drate = (select drate
                              from   ca_rate_date
                              where  icode = $drate_ym
                              and    itable = 'car_model_align');

             if (SQLCODE==SQLNOTFOUND)
             {
                 dmg_factor_1st=0;
                 brg_factor_1st=0;
                 dmg_factor_2nd=0;
                 brg_factor_2nd=0;
             }

             sprintf_s(tmp_pdmg_factor_1st,sizeof tmp_pdmg_factor_1st,"%6.5f",dmg_factor_1st);
             sprintf_s(tmp_pbrg_factor_1st,sizeof tmp_pbrg_factor_1st,"%6.5f",brg_factor_1st);
             sprintf_s(tmp_pdmg_factor_2nd,sizeof tmp_pdmg_factor_2nd,"%6.5f",dmg_factor_2nd);
             sprintf_s(tmp_pbrg_factor_2nd,sizeof tmp_pbrg_factor_2nd,"%6.5f",brg_factor_2nd);
        } 
        else 
        {
             strcpy(tmp_pdmg_factor_1st,"0");
             strcpy(tmp_pbrg_factor_1st,"0");
             strcpy(tmp_pdmg_factor_2nd,"0");
             strcpy(tmp_pbrg_factor_2nd,"0");
        }
    }
    dectodbl(&price_dec, &price);            

    printf("pdmg=[%s], pbrg=[%s]\n",tmp_pdmg_factor_2nd,tmp_pbrg_factor_2nd);

    cm_buf_init(ReplyBuf);
    sprintf_s(tmp_cylinder,sizeof tmp_cylinder,"%8.2f",cylinder);/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/
    strcpy(tmp_cylinder,trim(tmp_cylinder));
    cm_buf_put("%l %s %s %s %e %s %s %s %s %s %s %e %s ",
                M_CM_OK,brand,car_type,carname,price,tmp_cylinder,fuse_type,
                tmp_pdmg_factor_1st,tmp_pbrg_factor_1st,
                tmp_pdmg_factor_2nd,tmp_pbrg_factor_2nd, qpassenger, fpt);
 
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*********************************************************/
/*  Name: get_brand_data2                                */
/*                                                       */
/*  Description: Get car info according to ibrand number.*/
/*********************************************************/
long get_brand_data2(reply)
serverReply reply;
{
    $char   DBName[5], carname[11], fcar_class[2];
    $char   ibrand[9], ipro_year[5], cal_pro_year[5], class[2] ,icode[5];
    $char   brand[13], car_type[3], fuse_type[2], tmp_brand[7];
    $double cylinder;/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/
    $dec_t  price_dec,qpassenger_dec;
    $char   tmp_pdmg_factor[10],tmp_pbrg_factor[10];
    $char   tmp_cylinder[9];/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/
 
    $date   Today;
    int     int_cur_yr;
    char    cur_yr[5];

    $double price,dmg_factor,brg_factor;
    $double qpassenger;
    $short  dmg_2nd;
    int     tmp_len;

    $char   fpt[2];

    cm_buf_get("%s %s %s %s ", DBName, ibrand, ipro_year, icode);
    
    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
        else
            return apiRC;
    }

    rtoday(&Today);   
    strncpy(cur_yr,cm_get_sysd(),4); cur_yr[4]='\0';
    int_cur_yr=atoi(cur_yr);
    
    /* 104.09.09 fix ca_car_model �^���޿� */
    /* car9812112_C1 �t�P�����ɷs�W���Τ� modify by sylvia 100.09.21 */
    $DECLARE CA_BRAND CURSOR FOR
      SELECT mcar_price,nbrand_abbr,icar_type,fuse_type ,qcylinder,qpassenger,fpt,drate
        INTO $price_dec,$brand     ,$car_type,$fuse_type,$cylinder,$qpassenger_dec,$fpt
        FROM ca_car_model
       WHERE ibrand=$ibrand
         AND ipro_year=$ipro_year
         AND (dexpire is null or dexpire > today)
       ORDER BY drate DESC;
    $OPEN  CA_BRAND;
    $FETCH CA_BRAND;

    if (SQLCODE==SQLNOTFOUND)
    {
        $DECLARE CA_BRANDA CURSOR FOR
          SELECT mcar_price,nbrand_abbr,icar_type,fuse_type ,qcylinder,qpassenger,fpt,drate
            INTO $price_dec,$brand     ,$car_type,$fuse_type,$cylinder,$qpassenger_dec,$fpt
            FROM ca_car_model
           WHERE ibrand=$ibrand
             AND (dexpire is null or dexpire > today)
             AND ipro_year=(SELECT MAX(ipro_year) 
                              FROM ca_car_model
                             WHERE ibrand=$ibrand
                               AND ipro_year < $ipro_year
                               AND (dexpire is null or dexpire > today))
             ORDER BY drate DESC;
        $OPEN  CA_BRANDA;
        $FETCH CA_BRANDA;
	    if (SQLCODE==SQLNOTFOUND)
	    {
	        $DECLARE CA_BRANDA1 CURSOR FOR
	          SELECT mcar_price,nbrand_abbr,icar_type,fuse_type ,qcylinder,qpassenger,fpt,drate
	            INTO $price_dec,$brand     ,$car_type,$fuse_type,$cylinder,$qpassenger_dec,$fpt
	            FROM ca_car_model
	           WHERE ibrand=$ibrand
	             AND (dexpire is null or dexpire > today)
	             AND ipro_year=(SELECT MIN(ipro_year) 
	                              FROM ca_car_model
	                             WHERE ibrand=$ibrand
	                               AND ipro_year > $ipro_year
	                               AND (dexpire is null or dexpire > today))
	             ORDER BY drate DESC;
	        $OPEN  CA_BRANDA1;
	        $FETCH CA_BRANDA1;        
	        if (SQLCODE==SQLNOTFOUND)
	        {
	            if(exitsub(reply,M_CA_NBRAND) == True)      
	                return M_CA_NBRAND;                    
	            else
	                return apiRC;
	        }
	        $CLOSE CA_BRANDA1;
	        $FREE CA_BRANDA1;	 	        
	    } 
        $CLOSE CA_BRANDA;
        $FREE CA_BRANDA;		       
    }
    $CLOSE CA_BRAND;
    $FREE CA_BRAND;
    	
    strcpy(class, "1");
    $SELECT ncode   , fcar_class
       INTO $carname, $fcar_class
       FROM car_type
      WHERE fclass = $class 
        AND icode  = $car_type;
    if (SQLCODE==SQLNOTFOUND) 
    {
       if(exitsub(reply,M_CA_NCARTYPE) == True)       
          return M_CA_NCARTYPE;
       else
          return apiRC;
    }

    /*1040202006_C1 �s�W���ؤ���~�����²v�վ�*/
    if ((fcar_class[0]=='1' &&
         strcmp(car_type,"03")!=0 && strcmp(car_type,"04")!=0 &&
         strcmp(car_type,"19")!=0 && strcmp(car_type,"21")!=0 &&
         strcmp(car_type,"22")!=0 && (!(ISNEW_CAR1(car_type))) ) ||
        (fcar_class[0]=='2' &&
         strcmp(car_type,"07")!=0 && strcmp(car_type,"08")!=0 &&
         strcmp(car_type,"14")!=0 && strcmp(car_type,"15")!=0 && (!(ISNEW_CAR2(car_type))) ) 
      )
    {
         strncpy(tmp_brand,ibrand,6);
         tmp_brand[6]='\0';
         $SELECT pdmg_factor,pbrg_factor
            INTO $dmg_factor,$brg_factor
            FROM car_model_align
           WHERE ibrand    = $tmp_brand 
             AND icar_type = $car_type
             AND drate = (SELECT drate
                            FROM ca_rate_date
                           WHERE icode=$icode
                             AND itable='car_model_align');

         if (SQLCODE==SQLNOTFOUND)
         {
             dmg_factor=0;
             brg_factor=0;
         }

         sprintf_s(tmp_pdmg_factor,sizeof tmp_pdmg_factor,"%6.5f",dmg_factor);
         sprintf_s(tmp_pbrg_factor,sizeof tmp_pbrg_factor,"%6.5f",brg_factor);
    } 
    else 
    {
         strcpy(tmp_pdmg_factor,"0");
         strcpy(tmp_pbrg_factor,"0");
    }
    dectodbl(&price_dec, &price);            
    dectodbl(&qpassenger_dec, &qpassenger);            
    
    sprintf_s(tmp_cylinder,sizeof tmp_cylinder,"%8.2f",cylinder); /* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/
    strcpy(tmp_cylinder,trim(tmp_cylinder));
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %s %s %e %s %s %s %s",
                M_CM_OK,brand,car_type,carname,price,tmp_cylinder,fuse_type,
                tmp_pdmg_factor,tmp_pbrg_factor);
    cm_buf_put("%e %s",qpassenger,fpt);
 
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*
*  Name: check_card2 
*
*  Description: Get card status according to card number.
*/
long check_card2(reply)
serverReply reply;
{
 $char DBName[5];
 $char card[7];
 $char status[2];
 int tmp_len;

 cm_buf_get("%s %s", DBName,card);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 $SELECT fstatus 
  INTO   $status
  FROM   card 
  WHERE  icard=$card;

 if(SQLCODE==SQLNOTFOUND)
 {
  if(exitsub(reply,M_CM_NOT_FOUND) == True)       /*?*/
    return M_CM_NOT_FOUND;                        /*?*/
  else
    return apiRC;
 }

 cm_buf_init(ReplyBuf);

 cm_buf_put("%l %s", M_CM_OK, status);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*
*  Name: check_card1 
*
*  Description: Get compulsory card status according to card number.
*/
long check_card1(reply)
serverReply reply;
{
 $char DBName[5];
 $char com_card[9];
 $char status[2];
 int tmp_len;

 cm_buf_get("%s %s",DBName, com_card);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 $SELECT fstatus 
  INTO   $status
  FROM   compulsory_card 
  WHERE  icard=$com_card;

 if(SQLCODE==SQLNOTFOUND)
 {
  if(exitsub(reply,M_CM_NOT_FOUND) == True)    
    return M_CM_NOT_FOUND;                    
  else
    return apiRC;
 }

 cm_buf_init(ReplyBuf);

 cm_buf_put("%l %s",M_CM_OK, status);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*
*  Name: get_ins_type_info 
*
*  Description: Get insurance type information. 
*/
long get_ins_type_info(reply)
serverReply reply;
{
 $char DBName[5];
 $char ins_type_code[INSURANCE_TYPE], deduct[2], same_ins[INSURANCE_TYPE], 
       main_ins[INSURANCE_TYPE], cal_way[2];
 $short coverage;
 int tmp_len;

 cm_buf_get("%s %s", DBName, ins_type_code);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 
 $SELECT qcoverage, fdeduct, isame_ins, imain_ins, fcal_way  
  INTO   $coverage, $deduct, $same_ins, $main_ins, $cal_way
  FROM   insurance_type 
  WHERE  iins_type=$ins_type_code;

 if(SQLCODE==SQLNOTFOUND)
 {
  if(exitsub(reply,M_CA_NINS_TYPE) == True)    
    return M_CA_NINS_TYPE;                    
  else
    return apiRC;
 }

 cm_buf_init(ReplyBuf);

 cm_buf_put("%l %d %s %s %s %s",
             M_CM_OK, coverage, deduct, same_ins, main_ins, cal_way);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*
*  Name: get_resource_info 
*
*  Description: Get resource information. 
*/
long get_resource_info(reply)
serverReply reply;
{
 $char DBName[5];
 $char iresource[12];
 int tmp_len;

 cm_buf_get("%s %s", DBName, iresource);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 $SELECT iidno
     FROM off_fun_sour
    WHERE iidno=$iresource;    

 if(SQLCODE==SQLNOTFOUND)
 {
  if(exitsub(reply,M_CA_NRESOURCE) == True)    
    return M_CA_NRESOURCE;                    
  else
    return apiRC;
 }

 cm_buf_init(ReplyBuf);

 cm_buf_put("%l",M_CM_OK);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*
*  Name: get_big_inst_info 
*
*  Description: Get big_inst information. 
*/
long get_big_inst_info(reply)
serverReply reply;
{
 $char DBName[5];
 $char ibigbranch[3], ibigoffice[7], ibigcom[2];
 int tmp_len;

 cm_buf_get("%s %s %s", DBName, ibigbranch,ibigoffice);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False) {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
       return M_CM_DB_NOTOPEN;
   else
       return apiRC;
 }

 $DECLARE big_inst_cur CURSOR FOR
   SELECT ibigcom
     FROM big_inst 
    WHERE ibigbranch=$ibigbranch    
      AND ibigoffice=$ibigoffice;
 $OPEN big_inst_cur;
 $FETCH big_inst_cur INTO $ibigcom;

 if(SQLCODE==SQLNOTFOUND) {
  if(exitsub(reply,M_CMN_NBIG_INST) == True)    
    return M_CMN_NBIG_INST;                    
  else
    return apiRC;
 }

 cm_buf_init(ReplyBuf);

 cm_buf_put("%l",M_CM_OK);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}


long get_fagent(reply)
serverReply reply;
{
 $char DBName[5];
 $char fagent[2], ibroker[BROKER], nname[11], ibigcomp[2], ibranch[3];
 int tmp_len;

 cm_buf_get("%s %s", DBName, ibroker);

 $WHENEVER SQLERROR GOTO errexit;
 if (db_select(DBName) == False) {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }
 $SELECT fagent into $fagent
    FROM broker_agent
   WHERE ibroker=$ibroker;
 if(SQLCODE==SQLNOTFOUND) {
  if(exitsub(reply,M_CMN_NBROKER_AGENT) == True)    
    return M_CMN_NBROKER_AGENT;                    
  else
    return apiRC;
  }
 cm_buf_init(ReplyBuf);
 cm_buf_put("%l %s",M_CM_OK,fagent);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}


long get_officer(reply)
serverReply reply;
{
 $char DBName[5];
 $char iofficer[11], nname[11]=" ", ibranch[BRANCH_ID]=" ", ibig_comp[2]=" ";
 $char iupcomp[BRANCH_ID]=" ", sIbranchIcomp[CA_POL_BRH_NUM];
 $char fenterprise[2]="N";
 int tmp_len;

 cm_buf_get("%s %s", DBName, iofficer);

 $WHENEVER SQLERROR GOTO errexit;
 if (db_select(DBName) == False) {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }  
  $SELECT  nname,  ibranch,  ibigcomp, iupcomp, fenterprise
     INTO $nname, $ibranch, $ibig_comp, $iupcomp, $fenterprise
     FROM officer
    WHERE iofficer=$iofficer;    
 
 if(SQLCODE==SQLNOTFOUND) {
  if(exitsub(reply,M_CMN_NOFFICER) == True)    
    return M_CMN_NOFFICER;                    
  else
    return apiRC;
  }
 printf("--trace1 iofficer[%s],iupcomp[%s],fenterprise[%s]\n",iofficer,iupcomp, fenterprise);
 strcpy(ibranch,trim(ibranch)); 
 strcpy(iupcomp,trim(iupcomp));

 strcpy(sIbranchIcomp, ibranch);
 strcat(sIbranchIcomp, iupcomp);

 printf("--trace2 iofficer[%s],fenterprise[%s]\n",iofficer, fenterprise);
 cm_buf_init(ReplyBuf);
 cm_buf_put("%l %s %s %s %s %s", M_CM_OK,nname,ibranch,ibig_comp,sIbranchIcomp,fenterprise);
 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long W_office_chk(reply)
serverReply reply;
{
    $char   DBName[5];
    $char   iofficer[EMPLOYEE_ID],ibroker[BROKER];
    $char   ioffice[11];
    $char   nname[11],ibigcomp[2],ibranch[3],nchi_abv[13],fprop[2],imgr[2];
    $char   sIbus_location[BUSINESS_LOCATION],dexpire[11],fcredit[2];
    $char   stmt[1024];
    int     tmp_len;

    cm_buf_get("%s %s %s", DBName, ioffice, iofficer);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
             return M_CM_DB_NOTOPEN;
        else
             return apiRC;
    }

    $SELECT *
       FROM officer
      WHERE iofficer = $iofficer
        AND fprop    = 'E';
    printf("SQLCODE[%d]\n",SQLCODE);

    if (SQLCODE != SQLNOTFOUND)
    {  
       sprintf_s(stmt,sizeof stmt,
       " SELECT First 1 *                                \
           FROM sysdb:v_promote_off                      \
          WHERE iofficer_ori  =  '%s'                    \
            AND ibus_lct_ori  =  '%s' ",iofficer,ioffice);
       printf("stmt[%s]\n",stmt);
       $PREPARE get_v_pro FROM $stmt;
       $EXECUTE get_v_pro;

       if (SQLCODE == SQLNOTFOUND)
       {
           if (exitsub(reply,M_CM_NOT_FOUND) == True)
                return M_CM_NOT_FOUND;
           else
                return apiRC;
       }
    }

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l", M_CM_OK);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*
*  Name: get_officer_info 
*
*  Description: Get resource information. 
*  
*  Modified in 2009/12/17 for �q���M�׭ק�,fsales�אּ��cm_route���H�q���N����key�Ȩ��ofsales
*  �Y������h��JN
*/

long get_officer_info(reply)
serverReply reply;
{
    $char   DBName[5];
    $char   iofficer[EMPLOYEE_ID],ibroker[BROKER], ileader[EMPLOYEE_ID];
    $char   nname[11],ibigcomp[2],ibranch[3],nchi_abv[13],fprop[2],imgr[2];
    $char   sIbus_location[BUSINESS_LOCATION],dexpire[11],fcredit[2];
    $char   iroute[21],froute[2],fsales[2];
    int     tmp_len;
    
    /* �q���ĤG���q  */
    $char   sIroute[21], sFstart[2], sFauth[2], fPlyEdr[2];
    long   rc;
    
    cm_buf_get("%s %s %s %s", DBName, iofficer, sIroute, fPlyEdr);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
             return M_CM_DB_NOTOPEN;
        else
             return apiRC;
    }
    printf("get_officer_info:iofficer[%s]\n",iofficer);
    
    

    /* bis9901141�Ҧ����󳣵����q��,�ҥH�q�����O(froute)�אּ�@�ߧ�Y */
    $SELECT trim(nname), trim(ibigcomp), trim(ibranch), ibus_location, trim(fprop), 
            dexpire , imgr , fcredit, iroute, 'Y', ileader
       INTO $nname, $ibigcomp, $ibranch, $sIbus_location, $fprop, 
            $dexpire , $imgr, $fcredit, $iroute, $froute, $ileader
       FROM officer
      WHERE iofficer = $iofficer;
    if(SQLCODE==SQLNOTFOUND)
    {
        if(exitsub(reply,M_CMN_NOFFICER) == True)
            return M_CMN_NOFFICER;
        else
            return apiRC;
    }
    if (iroute[0] != '\0' && iroute[0] != ' ')
    {
        strcpy(iroute,trim(iroute));
        $SELECT fsales INTO $fsales FROM cm_route WHERE iroute = $iroute;
        if(SQLCODE==SQLNOTFOUND) strcpy(fsales,"N");
    } else strcpy(fsales,"N");


    /* ---- �t�X�q���ĤG���q�ק� �P�_�O�_�ҥγq���~�ȱ��� ---------------- */
    printf(" ---- �P�_�O�_�ҥγq���~�ȱ���  \n");
    /* ���קK����client�ݦ]�e���S���q���N��,���ǤJ�q���N���ӥX�{"�D�q���N���䤣��"�����D,
       ���P�_�O�_���ǤJ�q���N��,�Y���ǤJ,�h�H�W���Ҭd�쪺�q���N���a�J */
    if (strcmp(trim(sIroute),"") == 0)
         strcpy(sIroute, iroute);
    
    /* �Y���O��{���h��P�A�Y�����{���h��E�A���E�A�h���ˮֳq�����vcm_get_route_auth */
    if( fPlyEdr[0] != 'E')
    {
        rc = cm_get_route_auth("C", sIroute, iofficer, sFstart, sFauth);
        if (rc != M_CM_OK)  
        {
             printf("@ rc = errmsg[%s]\n",cm_get_errmsg(rc));
             if (exitsub(reply,rc) == True)
                    return rc;
             else return apiRC;
        }
    }
    else strcpy( sFstart, "Y");

    if (strcmp(sFstart, "Y") == 0)
    {
      strcpy(ibroker," ");
      strcpy(nchi_abv," ");
    } 
   else
    {
       ibroker[0] = '\0';
       $SELECT icar_broker
          INTO $ibroker
          FROM officer_broker
         WHERE iofficer=$iofficer;
       if ((SQLCODE == SQLNOTFOUND) || (ibroker[0] == '\0') || (ibroker[0] == ' '))
       {
           if (exitsub(reply,M_CMN_NOFFICER_BROKER) == True)
               return M_CMN_NOFFICER_BROKER;
           else return apiRC;
       }
   
       $SELECT nchi_abv
          INTO $nchi_abv
          FROM broker_agent
         WHERE ibroker = $ibroker;
       if (SQLCODE==SQLNOTFOUND)
       {
           if (exitsub(reply,M_CA_NBROKER) == True)
               return M_CA_NBROKER;
           else return apiRC;
       }
    }

    cm_buf_init(ReplyBuf);

    cm_buf_put("%l", M_CM_OK);

    cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %s %s %s ", ibroker,nname,ibigcomp,ibranch,
               nchi_abv,sIbus_location,fprop,dexpire,imgr,fcredit,iroute,froute,fsales, ileader);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}


long get_act_groupinfo(reply)
serverReply reply;
{
    $char   DBName[5];
    $char   GroupId[EMPLOYEE_ID];
    $char   Dexpire[11];
    int     tmp_len;

    cm_buf_get("%s %s", DBName, GroupId);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
             return M_CM_DB_NOTOPEN;
        else
             return apiRC;
    }
    printf("get_act_groupinfo:GroupId[%s]\n",GroupId);

    $SELECT grpdexpire
       INTO $Dexpire
       FROM act_groupinfo
      WHERE grpid=$GroupId;
    if (SQLCODE == SQLNOTFOUND)
    {
        if (exitsub(reply,M_CMN_NCUSTOMER) == True)
            return M_CMN_NCUSTOMER;
        else return apiRC;
    }

    cm_buf_init(ReplyBuf);

    cm_buf_put("%l", M_CM_OK);

    cm_buf_put("%s", Dexpire);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*
*  Name: get_adjuster_info 
*
*  Description: Get resource information. 
*/
long get_adjuster_info(reply)
serverReply reply;
{
 $char DBName[5];
 $char iofficer[11], nname[11], fprop[2], iapp_unit[3];
 int tmp_len;

 cm_buf_get("%s %s", DBName, iofficer);

 $WHENEVER SQLERROR GOTO errexit;
 if (db_select(DBName) == False) {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 $SELECT  nname, fprop, iapp_unit
     INTO $nname, $fprop, $iapp_unit
     FROM officer
    WHERE iofficer=$iofficer;    
 if(SQLCODE==SQLNOTFOUND) {
  if(exitsub(reply,M_CMN_NOFFICER) == True)    
    return M_CMN_NOFFICER;                    
  else
    return apiRC;
 }

 cm_buf_init(ReplyBuf);

 cm_buf_put("%l %s %s %s %s",M_CM_OK,iofficer,nname,fprop,iapp_unit);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*
*  Name:get_acc_reason_info  
*
*  Description: Get acc_reason information. 
*/
long get_acc_reason_info(reply)
serverReply reply;
{
 $char DBName[5];
 $char icode[3], nabbr[9], fclass[2];
 int tmp_len;

 cm_buf_get("%s %s %s", DBName, icode, fclass);

 $WHENEVER SQLERROR GOTO errexit;
 if (db_select(DBName) == False) {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 $SELECT  nabbr
     INTO $nabbr
     FROM adjustment_code
    WHERE fclass=$fclass AND icode=$icode;    
 if(SQLCODE==SQLNOTFOUND) {
  if(exitsub(reply,M_CA_NACCREASON) == True)    
    return M_CA_NACCREASON;                    
  else
    return apiRC;
 }

 cm_buf_init(ReplyBuf);

 cm_buf_put("%l %s",M_CM_OK,nabbr);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*  �ˮ`�I�X�I��] */
long get_pacc_reason_info(reply)
serverReply reply;
{
  $char icode[4],ncode[40];
   int rows, i;  
   
   $char DBName[5];
   int tmp_len,count,rtncode;
   long MsgCode;
   long long_mprem;
   cm_buf_get("%s", DBName);
        
   $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False) {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True) {
            return M_CM_DB_NOTOPEN;
        } else {
            return apiRC;
        }
    }
   cm_buf_init(ReplyBuf);
   cm_buf_res_msg();
   cm_buf_res_count();
printf(" *********************************************** \n");
   $DECLARE q_cura CURSOR for
     SELECT icode,ncode
       INTO $icode,$ncode
       FROM adjustment_code
      WHERE fclass='3'
   ORDER BY icode;
printf(" &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& \n");
   $OPEN q_cura;
  
    count=0;
    for(;;) 
    {
       $FETCH q_cura;
        if (SQLCODE != 0) 
        {
            break;
        }
        printf(" icode[%s]  ncode[%s] \n",icode,ncode);
        count++;
        cm_buf_put("%s %s ",icode,ncode);
    }
   $CLOSE q_cura; $FREE  q_cura;
    cm_buf_put_count_seq(1, count);
   
    cm_buf_put_msg(M_CM_OK);                                            
    tmp_len = cm_buf_len(ReplyBuf);                                     
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False) {  
        return apiRC;                                                   
    } else {                                                            
        return api_OKComplete;                                          
    }                                                                   
errexit:                                       
    if(exitsub(reply,SQLCODE) == True) {       
        return SQLCODE;                        
    } else {                                   
        return apiRC;                          
    }          
}

/* ****************************************** */
/*
*  Name: get_adj_comment_info 
*
*  Description: Get adj_comment information. 
*/
long get_adj_comment_info(reply)
serverReply reply;
{
 $char DBName[5];
 $char icode[2], nabbr[9];
 int tmp_len;

 cm_buf_get("%s %s", DBName, icode);

 $WHENEVER SQLERROR GOTO errexit;
 if (db_select(DBName) == False) {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 $SELECT  nabbr
     INTO $nabbr
     FROM adjustment_code
    WHERE fclass="2" AND icode=$icode;    
 if(SQLCODE==SQLNOTFOUND) {
  if(exitsub(reply,M_CA_NADJCOMMENT) == True)    
    return M_CA_NADJCOMMENT;                   
  else
    return apiRC;
 }

 cm_buf_init(ReplyBuf);

 cm_buf_put("%l %s",M_CM_OK,nabbr);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*
*  Name: get_close_limit_info 
*
*  Description: Get get_close_limit_info information. 
*/
long get_close_limit_info (reply)
serverReply reply;
{
 $char DBName[5];
 $char iofficer[11];
 $long mclose_limit;
 int tmp_len;

 cm_buf_get("%s %s", DBName, iofficer);

 $WHENEVER SQLERROR GOTO errexit;
 if (db_select(DBName) == False) {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }
mclose_limit=0;
 $SELECT  claim_branch.mclose_limit
     INTO $mclose_limit
     FROM officer, claim_branch
    WHERE officer.iofficer=$iofficer 
          AND officer.ibranch=claim_branch.iclaim_branch;
 if(SQLCODE==SQLNOTFOUND) {
  if(exitsub(reply,M_CA_NAUTHERITY) == True)    
    return M_CA_NAUTHERITY;                   
  else
    return apiRC;
 }
 cm_buf_init(ReplyBuf);

 cm_buf_put("%l %d",M_CM_OK,mclose_limit);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*********************************************************
*  Name: get_daily_closing_ctl_info
*  
*  Description: daily_closing_ctl Get information. 
**********************************************************/
long get_daily_closing_ctl_info(reply)
serverReply reply;
{
 $char DBName[5];
 $char iop_type[3],dwritten[10];
 $date inf_dwritten;
 $date Today;
 $char sToday[YYYMMDD];

 int tmp_len;

 cm_buf_get("%s %s", DBName, iop_type);

 $WHENEVER SQLERROR GOTO errexit;
 if (db_select(DBName) == False) {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 /* Mark by Thomas 871222*/
 /*$SELECT  dwritten******************************
     INTO $inf_dwritten
     FROM daily_closing_ctl
    WHERE iop_type = $iop_type; 
 if(SQLCODE==SQLNOTFOUND) {
  if(exitsub(reply,M_CMN_NDAILY_CLOSING_CTL))
    return M_CMN_NDAILY_CLOSING_CTL;                   
  else
    return apiRC;
 }
 strcpy(dwritten, cm_cdate_str_100(inf_dwritten));*******/

 rtoday(&Today); /*get today date time*/
 strcpy(sToday, cm_cdate_str_100(Today));

 cm_buf_init(ReplyBuf);

 /*cm_buf_put("%l %s",M_CM_OK,dwritten);*/

 cm_buf_put("%l %s", M_CM_OK, sToday);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*
*  Name: get_dmg_brg_factor_info
*
*  Description: Get dmg_brg_factor info according to ibrand,icar_type
*/
long get_dmg_brg_factor_info(reply)
serverReply reply;
{
    $char   DBName[5],class[2],fcar_class[2];
    $char   drate_ym[5];
    $char   ibrand[9],icar_type[3],carname[11],tmp_brand[7],icode[3];
    $double dmg_factor,brg_factor;
     char   tmp_pdmg_factor[10],tmp_pbrg_factor[10], isBigCar[2];
     int    tmp_len;
    $short  dmg_2nd;
    

    cm_buf_get("%s %s %s %s", DBName, ibrand, icar_type, drate_ym);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
        else
            return apiRC;
    }

    strcpy(class, "1");
    $SELECT ncode, fcar_class
       INTO $carname, $fcar_class
       FROM car_type
      WHERE fclass=$class AND icode=$icar_type;
    if (SQLCODE==SQLNOTFOUND) {
        if(exitsub(reply,M_CA_NCARTYPE) == True)
            return M_CA_NCARTYPE;
        else
            return apiRC;
    }
    printf("---fcar_class[%s] car_type[%s]\n",fcar_class,icar_type);
    
    /*1040202006_C1 �s�W���ؤ���~�����²v�վ�*/    
    if ((fcar_class[0]=='1' &&
         strcmp(icar_type,"03")!=0 && strcmp(icar_type,"04")!=0 &&
         strcmp(icar_type,"19")!=0 && strcmp(icar_type,"21")!=0 &&
         strcmp(icar_type,"22")!=0 && (!(ISNEW_CAR1(icar_type))) ) ||
        (fcar_class[0]=='2' &&
         strcmp(icar_type,"07")!=0 && strcmp(icar_type,"08")!=0 &&
         strcmp(icar_type,"14")!=0 && strcmp(icar_type,"15")!=0 && (!(ISNEW_CAR2(icar_type))) )
       )
    {
         strncpy(tmp_brand,ibrand,6);
         tmp_brand[6]='\0';

         $SELECT pdmg_factor,pbrg_factor
            INTO $dmg_factor,$brg_factor
            FROM car_model_align
           WHERE ibrand=$tmp_brand
             AND icar_type=$icar_type
             AND drate = (SELECT drate
                            FROM ca_rate_date
                           WHERE icode=$drate_ym
                             AND itable='car_model_align');

         if (SQLCODE==SQLNOTFOUND)
         {
             dmg_factor=0;
             brg_factor=0;
         }

         sprintf_s(tmp_pdmg_factor,sizeof tmp_pdmg_factor,"%6.5f",dmg_factor);
         sprintf_s(tmp_pbrg_factor,sizeof tmp_pbrg_factor,"%6.5f",brg_factor);
         sprintf_s( isBigCar,sizeof isBigCar, "Y");
    } 
    else 
    {
         strcpy(tmp_pdmg_factor,"0");
         strcpy(tmp_pbrg_factor,"0");
         sprintf_s( isBigCar,sizeof isBigCar, "N");
    }

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %s %s %s",
                M_CM_OK,isBigCar,carname,tmp_pdmg_factor,tmp_pbrg_factor);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*
*  Name: get_brand_data1
*
*  Description: Get brand name.
*/
long get_brand_data1(reply)
serverReply reply;
{
 $char DBName[5];
 $char ibrand[9], cartype[3], brand[13], carname[11], class[2];
 int tmp_len;

 cm_buf_get("%s %s", DBName, ibrand);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 /* car9812112_C1 �t�P�����ɷs�W���Τ� modify by sylvia 100.09.21 */
 $SELECT UNIQUE nbrand_abbr, icar_type
  INTO   $brand, $cartype
  FROM   ca_car_model  /* mag */
  WHERE  ibrand=$ibrand
    AND (dexpire is null or dexpire > today);

 if(SQLCODE==SQLNOTFOUND)
 {
  if(exitsub(reply,M_CA_NBRAND) == True)       /*?*/
    return M_CA_NBRAND;                        /*?*/
  else
    return apiRC;
 }
 
 strcpy(class, "1");
 $SELECT ncode
  INTO   $carname
  FROM   car_type
  WHERE  fclass=$class AND icode=$cartype;

 if(SQLCODE==SQLNOTFOUND)
 {
  if(exitsub(reply,M_CA_NCARTYPE) == True)       /*?*/
    return M_CA_NCARTYPE;                        /*?*/
  else
    return apiRC;
 }

 cm_buf_init(ReplyBuf);
 cm_buf_put("%l %s %s %s", M_CM_OK, brand, cartype, carname);
 
 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*
*  Name: check_officer_change
*
*  Description: Get resource information. 
*/
long check_officer_change(reply)
serverReply reply;
{
 $char DBName[5];
 $char iofficer_o[11], iofficer_n[11], ibroker[BROKER], nname[11];
 $char icard_o[3], icard_n[3];
 $char ibigcomp[2], ibranch[3];
 int tmp_len;

 cm_buf_get("%s %s %s", DBName, iofficer_o,iofficer_n);
printf(">>>>>>>>caqbase1:officer_o[%s] officer_n[%s]\n",iofficer_o,iofficer_n);

 $WHENEVER SQLERROR GOTO errexit;
 if (db_select(DBName) == False) {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 $SELECT  icard
     INTO $icard_o
     FROM officer
    WHERE iofficer=$iofficer_o;    
 if(SQLCODE==SQLNOTFOUND) {
  if(exitsub(reply,M_CMN_NOFFICER) == True)    
    return M_CMN_NOFFICER;                    
  else
    return apiRC;
 }

 $SELECT  nname, icard, ibigcomp, ibranch
     INTO $nname, $icard_n, $ibigcomp, $ibranch
     FROM officer
    WHERE iofficer=$iofficer_n;    
 if(SQLCODE==SQLNOTFOUND) {
  if(exitsub(reply,M_CMN_NOFFICER) == True)    
    return M_CMN_NOFFICER;                    
  else
    return apiRC;
 }

/* if (strcmp(icard_o,icard_n)!=0) return M_CA_CANNOT_CHANGE_OFFICER; */
 
 $SELECT  icar_broker
     INTO $ibroker
     FROM officer_broker
    WHERE iofficer=$iofficer_n;    
 if(SQLCODE==SQLNOTFOUND) {
  if(exitsub(reply,M_CMN_NOFFICER_BROKER) == True)    
     return M_CMN_NOFFICER_BROKER;                    
  else
     return apiRC;
 }

 cm_buf_init(ReplyBuf);
 cm_buf_put("%l %s %s %s %s",M_CM_OK,ibroker,nname,ibigcomp,ibranch);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
     return apiRC;
 else
     return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*
*  Name: select_car_type
*
*  Description: Select car type from database
*/
long select_car_type(reply)
serverReply reply;
{
 $char DBName[5];
 $char cartype[3];
 $char sername[11];
 int   tmp_len;
 $char class[2];

 cm_buf_get("%s %s",DBName, cartype);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 strcpy(class, "1");
 $SELECT ncode
  INTO   $sername
  FROM   car_type
  WHERE  fclass=$class AND icode=$cartype;

 if(SQLCODE==SQLNOTFOUND)
 {
  if(exitsub(reply,M_CA_NCAR_SERIES) == True)       
    return M_CA_NCAR_SERIES;                       
  else
    return apiRC;
 }

 cm_buf_init(ReplyBuf);

 cm_buf_put("%l %s",M_CM_OK,sername);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}


/*
*  Name: get_psex_age
*
*  Description: Get psex_age factor from database
*/
long get_psex_age(reply)
serverReply reply;
{
  $char   DBName[5];
  $char   fcard_class[7];
  $double age;
  $char   fsex[2];
  $char   icode[6];
  $int    dcode, rc;
  $double psex_age;
  int     tmp_len;

  cm_buf_get("%s %s %e %s %s",DBName, fcard_class, &age, fsex, icode);

  $WHENEVER SQLERROR GOTO errexit;
  if (db_select(DBName) == False)
  {
    if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
       return M_CM_DB_NOTOPEN;
    else
       return apiRC;
  }

  if (age!=0)
  {
     printf("fcard_class=[%s],age=[%f],fsex=[%s],icode=[%s]\n",fcard_class,age,fsex,icode);

     rc = get_sex_age_factor( fcard_class, &age, fsex, icode, &psex_age, v_sMsg);
     if( rc != M_CM_OK)
     {
        if(exitsub(reply, rc) == True)       
            return rc;                       
        else
            return apiRC;
     }
  } 
  else {
     psex_age=0;
  }
  printf("psex_age=[%f]\n",psex_age);

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %e",M_CM_OK, psex_age);

  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}


/*
*  Name: get_daily_closing_ctl
*
*  Description: daily_closing_ctl Get information. 
*/
long get_daily_closing_ctl(reply)
serverReply reply;
{
 $char  iop_type[3], fofficial[2];
 char   type[2], dclosing[10], dwritten[10], next_dwritten[10];
 $date  inf_dclosing, inf_dwritten, inf_next_dwritten;
 $char DBName[5];
 int tmp_len;

 cm_buf_get("%s", DBName);

 $WHENEVER SQLERROR GOTO errexit;
 if (db_select(DBName) == False) {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

    cm_buf_get("%s",type);
    strcpy(iop_type,"C");
    strcat(iop_type,type);   /* "C"+"[1|2|3]" ==> "C1" or "C2" or "C3" */
printf("type=%s\n",iop_type);

$   SELECT dclosing, dwritten, fofficial
      INTO $inf_dclosing, $inf_dwritten, $fofficial
      FROM daily_closing_ctl
     WHERE iop_type=$iop_type;
    if (NOT_FOUND) {
        return M_CMN_NDAILY_CLOSING_CTL;
    } else {
/*        if (strncmp(fofficial,"N",1)==0){
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CA_NPRINT_308_309);
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
      return apiRC;
    else
      return api_OKComplete;
      }
*/
        strcpy(dclosing,cm_cdate_str_100(inf_dclosing));
        strcpy(dwritten,cm_cdate_str_100(inf_dwritten));
        strcpy(next_dwritten,cm_cdate_str_100(inf_dwritten+1));
    }

    cm_buf_init(ReplyBuf);
    if (strncmp(fofficial,"N",1)==0)
          cm_buf_put("%l",M_CA_NPRINT_308_309);
    else
        cm_buf_put("%l",M_CM_OK);
    cm_buf_put("%s %s %s",dclosing,dwritten,next_dwritten);
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
    else
      return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}


/*
*  Name: get_broker_info 
*
*  Description: Get ibigcom information. 
*/
long get_broker_info(reply)
serverReply reply;
{
 $char DBName[5];
 $char ibroker[BROKER], ibigcomp[2];
 int tmp_len;

 cm_buf_get("%s %s", DBName, ibroker);

 $WHENEVER SQLERROR GOTO errexit;
 if (db_select(DBName) == False) {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }
printf("ibroker[%s]\n",ibroker);

  $SELECT ibig_comp
     INTO $ibigcomp
     FROM broker_agent
    WHERE ibroker=$ibroker;    

 if(SQLCODE==SQLNOTFOUND) {
  if(exitsub(reply,M_CMN_NBROKER_AGENT) == True)    
    return M_CMN_NBROKER_AGENT;                    
  else
    return apiRC;
 }

 cm_buf_init(ReplyBuf);

 cm_buf_put("%l %s",M_CM_OK,ibigcomp);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}



/*
*  Name: get_collect_area 
*
*  Description: Get cashier information. 
*/
long get_collect_area(reply)
serverReply reply;
{
 $char DBName[5];
 $char iarea[7];
 $char sIarea[13];
 int tmp_len;

 cm_buf_get("%s %s", DBName, iarea);

 sprintf_s(sIarea,sizeof sIarea, "%s%s", DBName, iarea);
 $WHENEVER SQLERROR GOTO errexit;
 if (db_select(DBName) == False) {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

  $SELECT icollector
     FROM collect_area
    WHERE iarea=$sIarea;    

 if(SQLCODE==SQLNOTFOUND) {
  if(exitsub(reply,M_CMN_NCOLLECTOR_AREA) == True)    
    return M_CMN_NCOLLECTOR_AREA;                    
  else
    return apiRC;
 }

 cm_buf_init(ReplyBuf);

 cm_buf_put("%l",M_CM_OK);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long car202_max_card(reply)
serverReply reply;
{
 $char DBName[DBNAME];
 $char office[3];
 $char icardyear[3];
 $char sIbranch_in[BRANCH_ID], sIcomp_in[BRANCH_ID];
  char sIbranchIcomp;
  char sTmpIbranch[BRANCH_ID], sTmpIcomp[BRANCH_ID];
 $char card_buf[200];
 $char card_head[CARD_NUM];
 $char iissuer[EMPLOYEE_ID];
 int tmp_len;
 char bak[30];
 long bakl;
 cm_buf_get("%s %s %s", DBName, office, icardyear);

 $WHENEVER SQLERROR GOTO errexit;
 if (db_select(DBName) == False) {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

sprintf_s(card_buf,sizeof card_buf,"select max(icard) from card where icard matches \
                  '%c%c%c*' ", icardyear[0], icardyear[1], office[0]);

printf("%s\n",card_buf);

  $PREPARE cq_tmp FROM $card_buf;
  $DECLARE cq_cur CURSOR FOR cq_tmp;
  $OPEN cq_cur;
  $FETCH cq_cur INTO $card_head;
 if(SQLCODE==SQLNOTFOUND) {
  if(exitsub(reply,M_CA_NISSUED_CARD) == True)    
    return M_CA_NISSUED_CARD;                    
  else
    return apiRC;
 }
 printf("card_head[%s]\n",card_head);
 if (card_head[0] == ' ' || card_head[0]== '\0') strcpy(bak, "0");
 else strcpy(bak, &card_head[3]);

printf("----->debug 1\n");
printf("----->card_head[%s]\n", card_head);

 bakl=atol(bak);

printf("----->debug 2\n");
 bakl++;
 sprintf_s(card_head,sizeof card_head,"%c%c%c%06d",icardyear[0], icardyear[1],
                                office[0], bakl);
 cm_buf_init(ReplyBuf);

 cm_buf_put("%l %s",M_CM_OK,card_head);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long get_branch_nchi_abv(reply)
serverReply reply;
{
  $char DBName[5];
  $char ibranch[3], nchi_abv[32];
  int tmp_len;
  cm_buf_get("%s %s", DBName, ibranch);
  $WHENEVER SQLERROR GOTO errexit;
  if (db_select(DBName) == False) {
    if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
    }
  $SELECT  nchi_abv
     INTO $nchi_abv
     FROM branch
     WHERE ibranch=$ibranch;
  if(SQLCODE==SQLNOTFOUND) {  
     if(exitsub(reply,M_CM_NOT_FOUND) == True)    
       return M_CM_NOT_FOUND;                    
     else
      return apiRC;
  }  
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s",M_CM_OK,nchi_abv);
  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}


long get_rate_code(reply)
serverReply reply;
{
  $char DBName[5];
  $char icode[5];
  int tmp_len;
  cm_buf_get("%s %s", DBName, icode);
  $WHENEVER SQLERROR GOTO errexit;
  if (db_select(DBName) == False) {
    if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
    }
  $SELECT DISTINCT icode
     INTO $icode
     FROM ca_rate_date
     WHERE icode = $icode;

printf("icode[%s] sqlcode[%d]\n",icode,SQLCODE);

  if(SQLCODE==SQLNOTFOUND) {  
     if(exitsub(reply,M_CM_NOT_FOUND) == True)    
       return M_CM_NOT_FOUND;                    
     else
      return apiRC;
  }  
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s",M_CM_OK,icode);
  tmp_len = cm_buf_len(ReplyBuf);

  if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}


/*
*  Name: get_big_resource 
*
*  Description: Get big_resource information. 
*/
long get_big_resource(reply)
serverReply reply;
{
 $char DBName[5];
 $char ibig_resource[5];
 int tmp_len;

 cm_buf_get("%s %s", DBName, ibig_resource);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 $SELECT nbig_name
     FROM big_resource
    WHERE ibig_resource=$ibig_resource;    

 if(SQLCODE==SQLNOTFOUND)
 {
  if(exitsub(reply,M_CA_NBIGRESOURCE) == True)    
    return M_CA_NBIGRESOURCE;                    
  else
    return apiRC;
 }

 cm_buf_init(ReplyBuf);

 cm_buf_put("%l",M_CM_OK);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long get_accident_record(reply)
serverReply reply;
{
  $char DBName[5];
  $char fcard_class[2],dply_begin[11],inumber[21];
  $date rate_date;
  char fyear[3];
  long qdmg[3],qlia[3];
  long mdmg[3],mlia[3];
  long qlia_acc,qdmg_acc;
  double pdmg_acc,plia_acc;
  long code;
  int tmp_len;

  cm_buf_get("%s %s %s %s", DBName, fcard_class,dply_begin,inumber);

   rate_date=cm_ymd_cdate(dply_begin);
   code=ca_accident_record(DBName,inumber,rate_date,fcard_class
            ,qdmg,qlia,mdmg,mlia,&qdmg_acc,&qlia_acc,
            &pdmg_acc,&plia_acc, fyear);

   cm_buf_init(ReplyBuf);

   if(strcmp(code,M_CM_OK)!=0)
     cm_buf_put("%l",code);
   else
     cm_buf_put("%l %f %f",M_CM_OK,pdmg_acc,plia_acc);

    tmp_len = cm_buf_len(ReplyBuf);

  if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
    return apiRC;
  else
    return api_OKComplete;
}

long get_ca_big_office_info(reply)
serverReply reply;
{
 $char DBName[5];
 $char ibig_comp[2],nname[41],ibig_branch[5],ibig_office[10];
 int tmp_len;

 cm_buf_get("%s %s %s %s", DBName,ibig_comp,ibig_branch,ibig_office);

 $WHENEVER SQLERROR GOTO errexit;
 if (db_select(DBName) == False) {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }
 $SELECT  nname
     INTO $nname
     FROM ca_big_office
    WHERE fclass='1' 
      AND ibig_comp=$ibig_comp
      AND ibig_branch=$ibig_branch
      AND ibig_office=$ibig_office;    

 if (SQLCODE==SQLNOTFOUND) {
    if (exitsub(reply,M_CA_NBIG_OFFICE) == True)    
       return M_CA_NBIG_OFFICE;                    
    else
       return apiRC;
  }

 cm_buf_init(ReplyBuf);
 cm_buf_put("%l %s",M_CM_OK,nname);
 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/**************************************************
 *  Name: get_fins_grp 
 *
 *  Description: Get insurance_type fins_grp field. 
 *  
 *  used program: ca502
 **************************************************/
long get_fins_grp(reply)
serverReply reply;
{
 $char DBName[5];
 $char fins_grp[2], iins_type[INSURANCE_TYPE];
 int tmp_len;

 cm_buf_get("%s %s", DBName, iins_type);

 $WHENEVER SQLERROR GOTO errexit;
 if (db_select(DBName)==False) 
    return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

 
 $SELECT  fins_grp
    INTO $fins_grp
    FROM insurance_type
   WHERE iins_type=$iins_type;
 if(SQLCODE==SQLNOTFOUND)
    return exitsub(reply,M_CA_NBIG_OFFICE) ? M_CA_NBIG_OFFICE : apiRC;

 printf("=====>�I��[%s],�I��[%s]\n",iins_type, fins_grp);

 cm_buf_init(ReplyBuf);
 cm_buf_put("%l %s",M_CM_OK, fins_grp);
 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long get_max_rate_code(reply)
serverReply reply;
{
  $char DBName[5];
  $char icode[5];
  int tmp_len;
  cm_buf_get("%s", DBName);
  $WHENEVER SQLERROR GOTO errexit;
  if (db_select(DBName) == False) {
    if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
    }
  $SELECT MAX(icode)
     INTO $icode
     FROM ca_rate_date;

printf("icode[%s] sqlcode[%d]\n",icode,SQLCODE);

  if(SQLCODE==SQLNOTFOUND) {  
     if(exitsub(reply,M_CM_NOT_FOUND) == True)    
       return M_CM_NOT_FOUND;                    
     else
      return apiRC;
  }  
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s",M_CM_OK,icode);
  tmp_len = cm_buf_len(ReplyBuf);

  if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/**************************************************
 *  Name: get_comp_acc_factor
 *
 *  Description: Get �j��ż�
 *
 *  used program: ca301
 **************************************************/
long get_comp_acc_factor(reply)
serverReply reply;
{
  $char   DBName[5];
  $char   fcard_class[2];
  $char   area_name[10];
  $int    qclass;
  $double pcomp_factor;
  char    tmp_pcomp_factor[10];
  $char   icode[6];
  $int    dcode;
  int     tmp_len;
  $char		sIcar_type[3], sFcar_class[2];

  cm_buf_get("%s %s %d %s %s", DBName, fcard_class, &qclass, icode, sIcar_type);

  $WHENEVER SQLERROR GOTO errexit;
  if (db_select(DBName)==False)
     return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

  printf("-------- qclass[%d],icode[%s]\n",qclass, icode);
  dcode=atoi(icode);

  /***************************************
  if (strlen(rtrim(icode)) > 2 ) 
  {
      $SELECT icode
         INTO $icode
         FROM ca_rate_renew
        WHERE iym_bgn<=$dcode
          AND iym_end>=$dcode;
      if(SQLCODE==SQLNOTFOUND) 
      {  
        if(exitsub(reply,M_CM_NOT_FOUND) == True)    
           return M_CM_NOT_FOUND;                    
        else
           return apiRC;
      }  
  }
  ****************************************/
  if (strcmp(fcard_class,"3") == 0)
  {  /* �����I�Y�� */ 
     $select pfactor into $pcomp_factor
        from ca_acc_factor
       where qrecord = $qclass
         and drate = (select drate from ca_rate_date where icode = $icode
                         and itable = 'ca_acc_factor');
      if(SQLCODE==SQLNOTFOUND)
         return exitsub(reply,M_CA_NACC_FACTOR) ? M_CA_NCOMP_ACC_FACTOR : apiRC;
  }
  else
  {
  	 strcpy(sIcar_type, trim(sIcar_type));
  	 if (strlen(sIcar_type) == 2)
  	 {
  	 		/* �ǤJ���O���إN�� */
  	 		$select fcar_class into $sFcar_class
  	 		   from car_type
  	 		  where fclass = '1'
  	 		    and icode = $sIcar_type;
  	 }		
  	 else
  	 {
  	 		/* �ǤJ���ۥ���~���O */
  	 		strcpy(sFcar_class, sIcar_type);
  	 }
  	 	
  	 printf("fcard_class=[%s]qclass=[%d]sFcar_class=[%s]icode=[%s]\n",fcard_class,qclass,sFcar_class,icode);
      /* �j��/���N �Y�� */
     $SELECT pcomp_factor
        INTO $pcomp_factor
        FROM ca_comp_acc_factor
       WHERE fcard_class=$fcard_class
         AND qclass=$qclass
         AND fcar_class = $sFcar_class
         AND drate=(SELECT drate
                      FROM ca_rate_date
                     WHERE icode=$icode
                       AND itable='ca_comp_acc_factor');
    if(SQLCODE==SQLNOTFOUND)
      return exitsub(reply,M_CA_NCOMP_ACC_FACTOR) ? M_CA_NCOMP_ACC_FACTOR : apiRC;
  }


  /*printf("------- qclass[%d],pcomp_factor[%.1f]\n",qclass,pcomp_factor);*/
  sprintf_s(tmp_pcomp_factor,sizeof tmp_pcomp_factor,"%.2f",pcomp_factor);

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s",M_CM_OK, tmp_pcomp_factor);
  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/***************************
*  Name: get_ca_dvp_ply_area 
****************************/
long get_ca_dvp_ply_area(reply)
serverReply reply;
{
     $char DBName[5];
     $char dvp_code[11], dvp_abbr[21];
     int tmp_len;

     cm_buf_get("%s %s", DBName,dvp_code);

     $WHENEVER SQLERROR GOTO errexit;
     if (db_select(DBName) == False)
     {
       if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
         return M_CM_DB_NOTOPEN;
       else
         return apiRC;
     }

     $SELECT dvp_abbr
        INTO $dvp_abbr
        FROM ca_dvp_ply_area
       WHERE dvp_code=$dvp_code;

     if(SQLCODE==SQLNOTFOUND)
     {
         if(exitsub(reply,M_CA_NDVP_PLY_AREA) == True)
              return M_CA_NDVP_PLY_AREA;
         else
              return apiRC;
     }

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l %s",M_CM_OK,dvp_abbr);

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long get_ins_comm_agent(reply)
serverReply reply;
{
    $char   DBName[5];
    $double pcommission, pagent, pdiscount;
    $char   ibroker[BROKER], ins_type[INSURANCE_TYPE], car_type[5];
    $char   tmp_comm[8], tmp_agent[8], tmp_discount[8];
    int     tmp_len, qperiod;
    $char   tmp_pfix_agent[10];
    $double pfix_agent;
    $char   icheck_commi[3];
    $char   icheck_agent[3];
    $char   icheck_disc[3];
    $char   iins_cat[3];
    $char   itype_disc[2];
    $char   iyear[2];
    $char   period[3], v_sMsg[1512], drate_ym[5], ipaid_base[2];
    long    rc;
    double mservice, mother_busi;
    char   icheck_busi[2], icheck_mservice[2], fstart[2];

    /* 1000311003 �q��2 */
    $char   irate_type[2],iroute_comm[4],iroute[21],iofficer[11];
    $char   insure_type[2], deffect[11], fPlyEdr[2];

    strcpy( fstart, "");
    cm_buf_get("%s %s %s %s %s %s", DBName, ins_type, ibroker, car_type, period, drate_ym);
    /* 1000311003 �q��2 */
    cm_buf_get("%s %s %s %s %s", iroute, iofficer, irate_type, iroute_comm, fPlyEdr);


   printf("DBName=[%s]\n",DBName);
   printf("ins_type=[%s]\n",ins_type);
   printf("ibroker=[%s]\n",ibroker);
   printf("car_type=[%s]\n",car_type);
   printf("period=[%s]\n",period);
   printf("drate_ym=[%s]\n",drate_ym);
   printf("iroute=[%s]\n",iroute);
   printf("iofficer=[%s]\n",iofficer);
   printf("irate_type=[%s]\n",irate_type);
   printf("iroute_comm=[%s]\n",iroute_comm);
   
   

    $WHENEVER SQLERROR GOTO errexit;
    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
        else
            return apiRC;
    }
    
    rc = chk_insurance_expire( ins_type, v_sMsg);
    printf("chk_insurance_expire ==>rc=[%d]ins_type=[%s]v_sMsg=[%s]\n",rc,ins_type,v_sMsg);
    
    if( rc != M_CM_OK)
    {
        if(exitsub(reply,rc) == True)
            return rc;
        else
            return apiRC;
    }
    
    strcpy( car_type , trim(car_type));
    qperiod = atoi( period);
    
    rc = get_iins_cat( car_type, 1, qperiod, iins_cat, iyear, v_sMsg );
   
    printf("get_iins_cat ==>rc=[%d]iins_cat=[%s]v_sMsg=[%s]\n",rc,iins_cat,v_sMsg);
    
    if( rc != M_CM_OK)
    {
        if(exitsub(reply, rc) == True)
            return  rc;
        else
            return apiRC;
    }
    
    rc = get_commission_agent( iins_cat, ibroker, ins_type, iyear, drate_ym,
             &pagent, &pdiscount, &pcommission, &mservice, &mother_busi,
             icheck_disc, icheck_commi, icheck_agent, icheck_busi, ipaid_base,
             &pfix_agent, icheck_mservice, itype_disc, fstart, iofficer, iroute, irate_type, iroute_comm, fPlyEdr, v_sMsg );

    printf("get_commission_agent ==>rc=[%d]v_sMsg=[%s]\n",rc,v_sMsg);
    
    if( rc != M_CM_OK)
    { if(exitsub(reply, rc) == True)
        return  rc;
      else
        return apiRC;
    }
    strcpy(icheck_commi, trim(icheck_commi));
    strcpy(icheck_agent, trim(icheck_agent));
    strcpy(icheck_disc,  trim(icheck_disc));
    sprintf_s(tmp_pfix_agent,sizeof tmp_pfix_agent,"%4.2f",pfix_agent);

   printf("icheck_commi=[%s]\n",icheck_commi);
   printf("icheck_agent=[%s]\n",icheck_agent);
   printf("icheck_disc=[%s]\n",icheck_disc);
   printf("tmp_pfix_agent=[%s]\n",tmp_pfix_agent);
   

    if (strcmp(trim(icheck_agent),"4")==0)  /* �N�z�v�B��--�̦����v�p�� */
    {
         printf("strcmp(trim(icheck_agent),4)==0 \n");
         /* �p���I�ĤT��L����i�� */
         pagent = (double)pcommission * (double)(pfix_agent/100.00);
         pagent = pagent + 0.009;
         pagent = (long)(pagent*100);
         pagent = (double)((double)pagent/100.00); 
    }

    printf("{get_ins_comm_agent}:icheck_agent[%s],pagent[%lf]\n",icheck_agent, pagent);

    sprintf_s(tmp_comm,sizeof tmp_comm,     "%4.2f" , pcommission);
    sprintf_s(tmp_agent,sizeof tmp_agent,    "%4.2f" , pagent);
    sprintf_s(tmp_discount,sizeof tmp_discount, "%4.2f" , pdiscount);

   printf("tmp_comm=[%s]\n",tmp_comm);
   printf("tmp_agent=[%s]\n",tmp_agent);
   printf("tmp_discount=[%s]\n",tmp_discount);
   

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    cm_buf_put("%s %s %s", tmp_comm, tmp_agent, tmp_discount);
    cm_buf_put("%s", tmp_pfix_agent);
    cm_buf_put("%s %s %s", icheck_commi, icheck_agent, icheck_disc);
    cm_buf_put("%s %s ",itype_disc, ipaid_base);

    tmp_len = cm_buf_len(ReplyBuf);

    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
    {
        printf("return apiRC;\n");
        return apiRC;
    }
    else
    {
         printf("return api_OKComplete;\n");
        return api_OKComplete;
    }

errexit:
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long get_compulsory_mbusiness(reply)
serverReply reply;
{
    $char   DBName[5];
    $double qpt, mbusiness, mbusiness2, mbusiness3, mbusiness4, mbusiness5, mbusiness36;
    $char   icar_type[3],comp_frate[5], insperiod[5];
    $char   dply_bgn[13], dply_end[13];
    $int    ply1_period;
    char    tmp_qpt[10],tmp_mbusiness[21];
    dec_t   dec_qpt;
    int     tmp_len;
    int     lsperiod;
    $int    iSecondYear, iSecondYearAdd;
    char    sTmpyy1[4], sTmpmm1[3], sTmpdd1[3];  /* dply_begin */
    char    sTmpyy2[4], sTmpmm2[3], sTmpdd2[3];  /* dply_end   */
    $long   dply_begin21, dply_end21;
    

    cm_buf_get("%s %s %s %s %s",DBName,icar_type,tmp_qpt,comp_frate, insperiod);
    cm_buf_get("%s %s ", dply_bgn, dply_end);
    
    dply_begin21 = cm_ymd_cdate(dply_bgn);
    dply_end21   = cm_ymd_cdate(dply_end);
    

   
    if (tmp_qpt[0]!=' ' && tmp_qpt[0]!='\0')
    {
       deccvasc(tmp_qpt,strlen(trim(tmp_qpt)),&dec_qpt);
       dectodbl(&dec_qpt,&qpt);
    } else qpt=0;

    $WHENEVER SQLERROR GOTO errexit;
    if (db_select(DBName) == False) {
      if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
        return M_CM_DB_NOTOPEN;
      else
        return apiRC;
    }

    if( strcmp(icar_type, "22") == 0 )
        strcpy(icar_type, "04");
    
    lsperiod = atoi(insperiod);
    /* iSecondYear = lsperiod - 12; */

    $select first 1 TRUNC((($dply_end21 - date_add( $dply_begin21, interval(1) year to year)) / 30))
       into $iSecondYear
       from systables;

    printf("iSecondYear[%d]\n", iSecondYear);

    do
    {
            $select first 1
            case
            when date_add($dply_begin21,interval(1) year to year) = $dply_end21 then 0
            when date_add($dply_begin21,(12+$iSecondYear) * interval(1) month to month) <= $dply_end21 then 1
            else 0
            end 
            into $iSecondYearAdd
            from systables;
            iSecondYear += iSecondYearAdd;
    }while(iSecondYearAdd > 0);

    printf("iSecondYear[%d]\n", iSecondYear);

    $SELECT mbusiness INTO $mbusiness
       FROM compulsory_premium
      WHERE icar_type=$icar_type
        AND qperiod=12
        AND ((qcar_personbgn <= $qpt
        AND   qcar_personend >= $qpt)
         OR  (qcar_personbgn=0))
        AND drate=(SELECT drate
                     FROM ca_rate_date
                    WHERE icode=$comp_frate
                      AND itable='compulsory_premium');
    if(SQLCODE==SQLNOTFOUND) mbusiness=(double)0;
    
    $SELECT mbusiness INTO $mbusiness2
       FROM compulsory_premium
      WHERE icar_type=$icar_type
        AND qperiod=24
        AND ((qcar_personbgn <= $qpt
        AND   qcar_personend >= $qpt)
         OR  (qcar_personbgn=0))
        AND drate=(SELECT drate
                     FROM ca_rate_date
                    WHERE icode=$comp_frate
                      AND itable='compulsory_premium');
    if(SQLCODE==SQLNOTFOUND) mbusiness2=(double)0;
    
    $SELECT mbusiness INTO $mbusiness3
       FROM compulsory_premium
      WHERE icar_type=$icar_type
        AND qperiod=36
        AND ((qcar_personbgn <= $qpt
        AND   qcar_personend >= $qpt)
         OR  (qcar_personbgn=0))
        AND drate=(SELECT drate
                     FROM ca_rate_date
                    WHERE icode=$comp_frate
                      AND itable='compulsory_premium');
    if(SQLCODE==SQLNOTFOUND) mbusiness3=(double)0;
    
    /*$SELECT mbusiness INTO $mbusiness4
       FROM compulsory_premium
      WHERE icar_type=$icar_type
        AND qperiod=48
        AND ((qcar_personbgn <= $qpt
        AND   qcar_personend >= $qpt)
         OR  (qcar_personbgn=0))
        AND drate=(SELECT drate
                     FROM ca_rate_date
                    WHERE icode=$comp_frate
                      AND itable='compulsory_premium');
    if(SQLCODE==SQLNOTFOUND) */
    mbusiness4=(double)0;
    
    /*$SELECT mbusiness INTO $mbusiness5
       FROM compulsory_premium
      WHERE icar_type=$icar_type
        AND qperiod=60
        AND ((qcar_personbgn <= $qpt
        AND   qcar_personend >= $qpt)
         OR  (qcar_personbgn=0))
        AND drate=(SELECT drate
                     FROM ca_rate_date
                    WHERE icode=$comp_frate
                      AND itable='compulsory_premium');
    if(SQLCODE==SQLNOTFOUND) */
    mbusiness5=(double)0;
    
    $SELECT mbusiness INTO $mbusiness36
       FROM compulsory_premium
      WHERE icar_type=$icar_type
        AND qperiod=1
        AND ((qcar_personbgn <= $qpt
        AND   qcar_personend >= $qpt)
         OR  (qcar_personbgn=0))
        AND drate=(SELECT drate
                     FROM ca_rate_date
                    WHERE icode=$comp_frate
                      AND itable='compulsory_premium');
    if(SQLCODE==SQLNOTFOUND) mbusiness36=(double)0;
    
    
    printf("First  Year mbusiness=[%f]\n", mbusiness  );
    printf("Second Year mbusiness=[%f]\n", mbusiness2 );
    printf("Third  Year mbusiness=[%f]\n", mbusiness3 );
    printf("Fourth Year mbusiness=[%f]\n", mbusiness4 );
    printf("Fifth  Year mbusiness=[%f]\n", mbusiness5 );
    printf("Cartype 36  mbusiness=[%f]\n", mbusiness36 );
    

    
    if ( iSecondYear > 0 ) 
    {
    	if ( iSecondYear <= 13 ) /* ���O���j��@�~�p�󵥩�G�~�� */
    	{
    		if (iSecondYear == 13)
    		{       /* �G�~�� */
    			/* �ӫO���G�~���A�~�ȶO�Τ𶷭p��u�� */
    		}
    		else
    		{       /* �@�~�H�W�����G�~ */
    			mbusiness2 = ( mbusiness2*((iSecondYear-0.5)/12) );
    		}
    		
    		mbusiness += mbusiness2;
    		printf("Total mbusiness = [%f]\n", mbusiness );
    	}
    	else if ( iSecondYear <= 25 ) /* ���O���j��G�~�p�󵥩�T�~�� */
    	{
    		if (iSecondYear == 25)
    		{       /* �T�~�� */
    			/* �ӫO���T�~���A�~�ȶO�Τ𶷭p��u�� */
    		}
    		else
    		{       /* �G�~�H�W�����T�~ */
    			mbusiness3 = ( mbusiness3*((iSecondYear-12-0.5)/12) );
    		}
    		
    		mbusiness = mbusiness + mbusiness2 + mbusiness3;
    		printf("Total mbusiness = [%f]\n", mbusiness );
    	}
    	else if ( iSecondYear <= 37 ) /* ���O���j��T�~�p�󵥩�|�~�� */
    	{
    		if (iSecondYear == 37)
    		{       /* �|�~�� */
    			/* �ӫO���|�~���A�~�ȶO�Τ𶷭p��u�� */
    		}
    		else
    		{       /* �T�~�H�W�����|�~ */
    			mbusiness4 = ( mbusiness4*((iSecondYear-24-0.5)/12) );
    		}
    		
    		mbusiness = mbusiness + mbusiness2 + mbusiness3 + mbusiness4;
    		printf("Total mbusiness = [%f]\n", mbusiness );
    	}
    	else if ( iSecondYear <= 49 ) /* ���O���j��|�~�p�󵥩󤭦~�� */
    	{
    		if (iSecondYear == 49)
    		{       /* ���~�� */
    			/* �ӫO�����~���A�~�ȶO�Τ𶷭p��u�� */
    		}
    		else
    		{       /* �|�~�H�W�������~ */
    			mbusiness5 = ( mbusiness5*((iSecondYear-36-0.5)/12) );
    		}
    		
    		mbusiness = mbusiness + mbusiness2 + mbusiness3 + mbusiness4 + mbusiness5;
    		printf("Total mbusiness = [%f]\n", mbusiness );
    	}
    }
    else if (strcmp(icar_type, "36") == 0)
    {
        mbusiness = mbusiness36;
        printf("Total mbusiness = [%f]\n", mbusiness );
    }
    
    mbusiness = d45( mbusiness, 2);
    printf("Total mbusiness = [%f]\n", mbusiness );
    
    sprintf_s(tmp_mbusiness,sizeof tmp_mbusiness,"%8.3f",mbusiness);

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s",M_CM_OK,tmp_mbusiness);
    tmp_len = cm_buf_len(ReplyBuf);

    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
      return apiRC;
    else
      return api_OKComplete;

errexit:
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

double d45(num,num1)
double num;
int num1;
{
    long tmplong;
    double var1;
    double ten;
    int i;

    ten = 1;
    for(i = 1 ;i<=num1;i++)
    ten *= 10;

    num *= ten;
    if (num >= 0) var1 = 0.500000000001;
    else var1 = (-0.500000000001);

    num = num + var1;
    tmplong = num;

    num = tmplong/ten;
    return(num);
}

long get_user_branch(reply)
serverReply reply;
{
    $char   DBName[DBNAME];
    $char   sIuserid[EMPLOYEE_ID];
    $char   sIbranch[BRANCH_ID], sIupcomp[BRANCH_ID];
    $char   sIupcompShort[BRANCH_ID];
    int     tmp_len;

    cm_buf_get("%s %s",DBName, sIuserid);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False) {
      if (exitsub(reply,M_CM_DB_NOTOPEN) == True) return M_CM_DB_NOTOPEN;
      else return apiRC;
    }

    $SELECT ibranch, iupcomp
       INTO $sIbranch, $sIupcompShort
       FROM officer
      WHERE iofficer=$sIuserid;
    if (SQLCODE==SQLNOTFOUND) {
       sIbranch[0]='\0'; sIupcomp[0]='\0';
    } else strcpy(sIupcomp, get_upcomp(sIupcompShort,
                                       USE_SHORT_BRANCH_ID, USE_BRANCH_ID));
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %s %s", M_CM_OK, sIbranch, sIupcomp, sIupcompShort);
    tmp_len = cm_buf_len(ReplyBuf);

    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
      return apiRC;
    else
      return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*********************************************
*  Description: Get icorps information. 
**********************************************/
long get_corps_info(reply)
serverReply reply;
{
    $char DBName[DBNAME];
    $char sIcorps[CORP_ID],sIbroker[BROKER];
    $char sNchi_abv[13];
    int tmp_len;

    cm_buf_get("%s %s", DBName, sIcorps);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
      if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
        return M_CM_DB_NOTOPEN;
      else
        return apiRC;
    }

    printf("sIcorps[%s]\n",sIcorps);
    strcpy(sIbroker," ");

    $SELECT icar_broker
       INTO $sIbroker
       FROM officer_broker
      WHERE iofficer=$sIcorps;

    if (SQLCODE==SQLNOTFOUND) {
        if (exitsub(reply,M_CA_NCORPS) == True)
           return M_CA_NCORPS;
        else return apiRC;
    }

    $SELECT nchi_abv
       INTO $sNchi_abv
       FROM broker_agent
      WHERE ibroker=$sIbroker;
    if (SQLCODE==SQLNOTFOUND) {
        if (exitsub(reply,M_CA_NBROKER) == True)
           return M_CA_NBROKER;
        else return apiRC;
    }

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %s", M_CM_OK, sIbroker, sNchi_abv);
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
      return apiRC;
    else
      return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*-------------------------------------------------------------------*
*  Name: get_benef1_name 
*
*  Description: Get beneficial name according to beneficial number.
*--------------------------------------------------------------------*/
long get_benef1_name(reply)
serverReply reply;
{
    $char DBName[5];
    $char ibroker[BROKER];
    $char nchi_full[43];
    $char nchi_abv[13];
    int tmp_len;

    cm_buf_get("%s %s",DBName, ibroker);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
      if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
        return M_CM_DB_NOTOPEN;
      else
        return apiRC;
    }

    $SELECT nchi_full, nchi_abv
       INTO $nchi_full, $nchi_abv
       FROM bf_bank
      WHERE ibank=$ibroker;

     nchi_full[42]='\0';   /*for car301*/

    if(SQLCODE==SQLNOTFOUND)
    {
     if(exitsub(reply,M_BF_BANK_ERR) == True)       /*?*/
       return M_BF_BANK_ERR;                          /*?*/
     else
       return apiRC;
    }

    cm_buf_init(ReplyBuf);

    cm_buf_put("%l %s %s",M_CM_OK,nchi_full,nchi_abv);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
      return apiRC;
    else
      return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*-------------------------------------------------------------------*
*  Name: get_prem                                                    *
*                                                                    *
*  Description: get the actually premium from estimate               *
*                                                                    *
*--------------------------------------------------------------------*/
long get_est_prem(reply)
serverReply reply;
{
    $char DBName[5];
    $char sIestimate[CA_ESTIMATE_NUM];
     char sHeadBranch[DBNAME];
    $char sTmpBuf[400];
     char sHeadBranchName[21], sDbName[21], sTblName[21];
    $long lPremium1, lPremium2;
     long iRtnCode;
      int tmp_len;
    $short no_null;

    cm_buf_get("%s %s",DBName, sIestimate);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
      if (exitsub(reply,M_CM_DB_NOTOPEN) == True) return M_CM_DB_NOTOPEN;
      else return apiRC;
    }

    strcpy(sIestimate, trim_space(sIestimate));

    /* Get Taipei's full DB name */
    iRtnCode = getHeadBranch(sHeadBranch);
    if (iRtnCode < 0)
       return exitsub(reply, M_CM_READ_CONFIG_ERR) ? M_CM_READ_CONFIG_ERR : apiRC;
    strcpy(sHeadBranchName, get_full_dbname(sHeadBranch));

    if (sIestimate[CAR_EST_ABN_POS-1] == 'X') {
        strcpy(sDbName, sHeadBranchName);
        strcat(sDbName, ":");
        strcpy(sTblName, "abn_ply_ins_type");
    } else {
        strcpy(sDbName, " ");
        strcpy(sTblName, "est_ins_type");
    }

    /* �j�� */
    if (sIestimate[CAR_EST_ABN_POS-1] == 'X')
    {
            sprintf_s(sTmpBuf,sizeof sTmpBuf, "SELECT SUM(mins_premium) \
                                FROM %s%s \
                               WHERE iabnormal = ? \
                                 AND iins_type = '21'", sDbName, sTblName);
    }
    else
    {
            sprintf_s(sTmpBuf,sizeof sTmpBuf, "SELECT SUM(mins_premium) \
                                FROM %s%s \
                               WHERE iestimate = ? \
                                 AND iins_type = '21'", sDbName, sTblName);
    }
    $PREPARE STMT1 FROM $sTmpBuf;
    $DECLARE CUR1 CURSOR FOR STMT1;
    $OPEN CUR1 USING $sIestimate;
    $FETCH CUR1 INTO $lPremium1:no_null;
    if (SQLCODE == SQLNOTFOUND || no_null==-1) lPremium1 = 0;

    /* ���N */
    if (sIestimate[CAR_EST_ABN_POS-1] == 'X')
    {
            sprintf_s(sTmpBuf,sizeof sTmpBuf, "SELECT SUM(mins_premium) \
                                FROM %s%s \
                               WHERE iabnormal = ? \
                                 AND iins_type <> '21'", sDbName, sTblName);
    }
    else
    {
            sprintf_s(sTmpBuf,sizeof sTmpBuf, "SELECT SUM(mins_premium) \
                                FROM %s%s \
                               WHERE iestimate = ? \
                                 AND iins_type <> '21'", sDbName, sTblName);
    }
    $PREPARE STMT2 FROM $sTmpBuf;
    $DECLARE CUR2 CURSOR FOR STMT2;
    $OPEN CUR2 USING $sIestimate;
    $FETCH CUR2 INTO $lPremium2:no_null;
    if (SQLCODE == SQLNOTFOUND || no_null==-1) lPremium2 = 0;

    cm_buf_init(ReplyBuf);

    cm_buf_put("%l %l %l", M_CM_OK, lPremium1, lPremium2);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
      return apiRC;
    else
      return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*-------------------------------------------------------------------*
*  Name: get_ply_prem                                                *
*                                                                    *
*  Description: get the actually premium from policy                 *
*                                                                    *
*--------------------------------------------------------------------*/
long get_ply_prem(reply)
serverReply reply;
{
    $char DBName[5];
    $char sIpolicy[POLICY_NUM_1];
    $long lPremium;
     long iRtnCode;
      int tmp_len;
    $short no_null;

    cm_buf_get("%s %s",DBName, sIpolicy);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
      if (exitsub(reply,M_CM_DB_NOTOPEN) == True) return M_CM_DB_NOTOPEN;
      else return apiRC;
    }

    strcpy(sIpolicy, trim_space(sIpolicy));

    $SELECT (mdmg_prem+mlia_prem)
       INTO $lPremium:no_null
       FROM ply_relation
      WHERE ipolicy = $sIpolicy;

    if (SQLCODE == SQLNOTFOUND || no_null==-1) lPremium = 0;

    cm_buf_init(ReplyBuf);

    cm_buf_put("%l %l", M_CM_OK, lPremium);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
      return apiRC;
    else
      return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long get_user_info(reply)
serverReply reply;
{
    $char   DBName[DBNAME];
    $char   sIuserid[EMPLOYEE_ID];
    $char   func1[3], func2[3];
    int     tmp_len;

    cm_buf_get("%s %s",DBName, sIuserid);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False) {
      if (exitsub(reply,M_CM_DB_NOTOPEN) == True) return M_CM_DB_NOTOPEN;
      else return apiRC;
    }

    $SELECT func1, func2
       INTO $func1, $func2
       FROM user
      WHERE iemp=$sIuserid;

    if( SQLCODE == SQLNOTFOUND)
    { 
        if (exitsub(reply, M_CA_NO_USERID) == True) 
            return M_CA_NO_USERID;
        else 
            return apiRC;
    }

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %s", M_CM_OK, func1, func2);
    tmp_len = cm_buf_len(ReplyBuf);

    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
      return apiRC;
    else
      return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long get_list_ins_comm_agent(reply)
serverReply reply;
{
    $char   DBName[5];
    $double pcommission, pagent, pdiscount;
    $char   ibroker[BROKER], ins_type[INSURANCE_TYPE];
    $char   ibroker_tmp[BROKER];
    $char   iofficer[11], icar_type[5], iins_cat[5];
    $char   tmp_ins_type[100][7];
    $char   drate_ym[1000][5];
    $char   tmp_comm[8], tmp_agent[8], tmp_discount[8];
    int     i, tmp_len, list_cnt, qperiod;

    $char   tmp_pfix_agent[10];
    $char   icheck_disc[3];
    $char   icheck_agent[3];
    $char   icheck_commi[3];
    $double pfix_agent;
    $char   itype_disc[2], iyear[2], f980401[2];
    long    rc;
    double mservice, mother_busi;
    char   icheck_busi[2], icheck_mservice[2], ipaid_base[2];

    /* 1000311003 �q��2 */
    $char   irate_type[2],iroute_comm[4],iroute[21];
    $char   insure_type[2], deffect[11], sFstart[2], sFauth[2], fPlyEdr[2];

    cm_buf_get("%s %s %s %d %d", DBName, ibroker, icar_type, &list_cnt, &qperiod);

    /* 1000311003 �q��2 */
    cm_buf_get("%s %s %s %s %s", iroute, iofficer, irate_type, iroute_comm, fPlyEdr);

    $WHENEVER SQLERROR GOTO errexit;
    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
        else
            return apiRC;
    }
    
    
    /* ---- �t�X�q���ĤG���q�ק� �P�_�O�_�ҥγq���~�ȱ��� ---------------- */
    printf(" ---- �P�_�O�_�ҥγq���~�ȱ���  \n");

    /* �Y���O��{���h��P�A�Y�����{���h��E�A���E�A�h���ˮֳq�����vcm_get_route_auth */
    if( fPlyEdr[0] != 'E') 
    {
        rc = cm_get_route_auth("C", iroute, iofficer, sFstart, sFauth);
        if (rc != M_CM_OK)  
        {
             printf("@ rc = errmsg[%s]\n",cm_get_errmsg(rc));
             if (exitsub(reply,rc) == True)
                    return rc;
             else return apiRC;
        }
    }
    else strcpy( sFstart, "Y");

   if (strcmp(sFstart, "N") == 0)
   {
       $SELECT *
          FROM officer
         WHERE iofficer = :ibroker;
       if(SQLCODE==SQLNOTFOUND) 
       {
           /*** ���ܿ�J�������g���H�N�� ***/
       }
       else
       {
           $SELECT icar_broker
              INTO $ibroker_tmp
              FROM officer_broker
             WHERE iofficer = $ibroker;
           if (SQLCODE==SQLNOTFOUND) 
           {
               if (exitsub(reply,M_CMN_NOFFICER_BROKER) == True)
                   return M_CMN_NOFFICER_BROKER;
               else return apiRC;
           }
           strcpy(ibroker,trim(ibroker_tmp));
       }
   }
    strcpy(icar_type, trim(icar_type));

    rc = get_iins_cat( icar_type, 1, qperiod, iins_cat, iyear, v_sMsg );

    if( rc != M_CM_OK)
    {
        if(exitsub(reply, rc) == True)
            return  rc;
        else
            return apiRC;
    }
    
    for (i=0;i<list_cnt;i++)
    {
        cm_buf_get("%s", tmp_ins_type[i]);
        cm_buf_get("%s", drate_ym[i]);
    }

    cm_buf_init(ReplyBuf);
    cm_buf_res_msg();

    for (i=0;i<list_cnt;i++)
    {
        rc = get_commission_agent( iins_cat, ibroker, tmp_ins_type[i], iyear, drate_ym[i],
                 &pagent, &pdiscount, &pcommission, &mservice, &mother_busi,
                 icheck_disc, icheck_commi, icheck_agent, icheck_busi, ipaid_base,
                 &pfix_agent, icheck_mservice, itype_disc, sFstart, iofficer, iroute, irate_type, iroute_comm, fPlyEdr, v_sMsg );

        if( rc != M_CM_OK)
        {
            if(exitsub(reply, rc) == True)
                return  rc;
            else
                return apiRC;
        }

        strcpy(icheck_commi, trim(icheck_commi));
        strcpy(icheck_agent, trim(icheck_agent));
        strcpy(icheck_disc,  trim(icheck_disc));

        sprintf_s(tmp_pfix_agent,sizeof tmp_pfix_agent,"%4.2f",pfix_agent);

        printf("icheck_agent[%s]\n",icheck_agent);
        if (strcmp(trim(icheck_agent),"4")==0)  /* �B��--�̦����v�p�� */
        {
             /* �p���I�ĤT��L����i�� */
             pagent = (double)pcommission*(double)(pfix_agent/100.00);
             pagent = pagent + 0.009;
             pagent = (long)(pagent*100);
             pagent = (double)((double)pagent/100.00);
        }

        sprintf_s(tmp_comm,sizeof tmp_comm,     "%4.2f", pcommission);
        sprintf_s(tmp_agent,sizeof tmp_agent,    "%4.2f", pagent);
        sprintf_s(tmp_discount,sizeof tmp_discount, "%4.2f", pdiscount);

        cm_buf_put("%s %s %s" ,tmp_comm,tmp_agent,tmp_discount);
        cm_buf_put("%s" , tmp_pfix_agent);
        cm_buf_put("%s %s %s", icheck_commi, icheck_agent, icheck_disc);
        cm_buf_put("%s",itype_disc);

        $SELECT case when drate >= date('04/01/2009') then '1' else '0' end
         INTO $f980401
         FROM ca_rate_date
        WHERE icode  = $drate_ym[i]
          AND itable = 'cm_extra_charge';

        if (SQLCODE == SQLNOTFOUND)
        {
          if (exitsub(reply,M_CA_EXTRA_CHARGE_DRATE) == True)
            return M_CA_EXTRA_CHARGE_DRATE;
          else
            return apiRC;
        }

        cm_buf_put("%s", f980401);
    }
    cm_buf_put_msg(M_CM_OK);
    tmp_len = cm_buf_len(ReplyBuf);

    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/***************************
*  Name: get_ca_zipcode
****************************/
long get_ca_zipcode(reply)
serverReply reply;
{
     EXEC SQL char DBName[5];
     EXEC SQL char izipcode[CA_ZIP], ncity[7], ncounty[9];/* 1090525004-SC1-�]�y��-�s���l���ϸ�3+3   ZIP_CODE 5+1->CA_ZIP 6+1*/
     char Total_name[15];
     int tmp_len;

     cm_buf_get("%s %s", DBName,izipcode);

     EXEC SQL WHENEVER SQLERROR GOTO errexit;
     if (db_select(DBName) == False)
     {
       if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
         return M_CM_DB_NOTOPEN;
       else
         return apiRC;
     }
     EXEC SQL SELECT ncity  , ncounty
                INTO :ncity , :ncounty
                FROM zipcode
               WHERE izipcode = :izipcode;

     if(SQLCODE==SQLNOTFOUND)
     {
         if(exitsub(reply,M_CMN_NZIPCODE) == True)
            return M_CMN_NZIPCODE;
         else
            return apiRC;
     }

     strcpy(Total_name , trim(ncity));
     strcat(Total_name , trim(ncounty));

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l %s",M_CM_OK,Total_name);

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
       return apiRC;
     else
       return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/***************************
*  Name  : get_ca_trans_ply
*  Table : ca_trans_ply
*          �O�I�Ҥ�����
****************************/
long get_ca_trans_ply(reply)
serverReply reply;
{
     EXEC SQL BEGIN DECLARE SECTION;
         char  DBName[5];
         char  icard[21];

         char  iassured[13];
         char  nassured[121];
         char  ibirth[8];
         char  fsex[2];
         char  fmarriage[2];
         char  aassured[91];
         long  dply_begin;
         long  dply_end;
         char  iissue_ym[6];
         char  nbrand_abbr[13];
         char  ncar_abbr[13];
         float qcylinder;/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/
         char  itag[CA_TAG_NUM];
         char  iengine[CA_ENGINE_NUM];
         char  ilast_card[21];
         char  fcomp_class[3];
         char  fcomp_class_last[3];
         int   mlia_prem;
         long  dcreate;
         char  ibig_office[32];
         char  ibig_sales[17];
         char  icard2[21];
         long  dply_begin2;
         long  dply_end2;
         char  ipro_year[5];
         float qpt;
         float mcar_price;
         int   mvol_prem;
         int   mtot_prem;

         char  ilast_policy[21];
         char  iestimate[21];
         char  icar_type1[3];
         char  icar_type2[3];
         char  iofficer1[11];
         char  iofficer2[11];

         char  iins_type[INSURANCE_TYPE];
         long  minjured_cover;
         long  mdeath_cover;
         long  mdamage_cover;
         long  mdeduct;
         long  mins_premium;
         long  pdiscount;
         long  mdiscount;
         long  mprem;

         char  drate_ym[5];
         char  fcard_class[2];
         int   ins_cnt;

     EXEC SQL END DECLARE SECTION;

     int   tmp_len;
     char  cdply_begin[10] , cdply_end[10] , cdply_begin2[10] , cdply_end2[10];
     char  cdcreate[10];
     char  C_qcylinder[9];/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/
     char  C_qpt[6] , C_mcar_price[7];
     int   Birth_len;

     cm_buf_get("%s %s %s",DBName,fcard_class,icard);

     /*** EXEC SQL SET EXPLAIN ON; ***/

     printf("########## icard[%s]\n",icard);

     EXEC SQL WHENEVER SQLERROR GOTO errexit;
     if (db_select(DBName) == False)
     {
       if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
         return M_CM_DB_NOTOPEN;
       else
         return apiRC;
     }

     if (fcard_class[0] == '1')
     {
     EXEC SQL SELECT  iassured    , nassured         , ibirth      , fsex      , fmarriage   ,
                      aassured    , dply_begin       , dply_end    , iissue_ym , nbrand_abbr ,
                      ncar_abbr   , qcylinder        , itag        , iengine   , ilast_card  ,
                      fcomp_class , fcomp_class_last , mlia_prem   , dcreate   , ibig_office ,
                      ibig_sales  , icard2           , dply_begin2 , dply_end2 , ipro_year   ,
                      qpt         , mcar_price       , mvol_prem   , mtot_prem ,
                      iestimate   , icar_type1       , icar_type2  , iofficer1 , iofficer2
                INTO :iassured    ,:nassured         ,:ibirth      ,:fsex      ,:fmarriage   ,
                     :aassured    ,:dply_begin       ,:dply_end    ,:iissue_ym ,:nbrand_abbr ,
                     :ncar_abbr   ,:qcylinder        ,:itag        ,:iengine   ,:ilast_card  ,
                     :fcomp_class ,:fcomp_class_last ,:mlia_prem   ,:dcreate   ,:ibig_office ,
                     :ibig_sales  ,:icard2           ,:dply_begin2 ,:dply_end2 ,:ipro_year   ,
                     :qpt         ,:mcar_price       ,:mvol_prem   ,:mtot_prem ,
                     :iestimate   ,:icar_type1       ,:icar_type2  ,:iofficer1 ,:iofficer2
                FROM ca_trans_ply
               WHERE icard = :icard;
     }
     else
     {
     EXEC SQL SELECT  iassured    , nassured         , ibirth      , fsex      , fmarriage   ,
                      aassured    , dply_begin       , dply_end    , iissue_ym , nbrand_abbr ,
                      ncar_abbr   , qcylinder        , itag        , iengine   , ilast_card  ,
                      fcomp_class , fcomp_class_last , mlia_prem   , dcreate   , ibig_office ,
                      ibig_sales  , icard2           , dply_begin2 , dply_end2 , ipro_year   ,
                      qpt         , mcar_price       , mvol_prem   , mtot_prem ,
                      iestimate   , icar_type1       , icar_type2  , iofficer1 , iofficer2
                INTO :iassured    ,:nassured         ,:ibirth      ,:fsex      ,:fmarriage   ,
                     :aassured    ,:dply_begin       ,:dply_end    ,:iissue_ym ,:nbrand_abbr ,
                     :ncar_abbr   ,:qcylinder        ,:itag        ,:iengine   ,:ilast_card  ,
                     :fcomp_class ,:fcomp_class_last ,:mlia_prem   ,:dcreate   ,:ibig_office ,
                     :ibig_sales  ,:icard2           ,:dply_begin2 ,:dply_end2 ,:ipro_year   ,
                     :qpt         ,:mcar_price       ,:mvol_prem   ,:mtot_prem ,
                     :iestimate   ,:icar_type1       ,:icar_type2  ,:iofficer1 ,:iofficer2
                FROM ca_trans_ply
               WHERE icard2 = :icard;
     }

     if(SQLCODE==SQLNOTFOUND)
     {
         if(exitsub(reply,M_CM_NOT_FOUND) == True)
            return M_CM_NOT_FOUND;
         else
            return apiRC;
     }


     EXEC SQL SELECT ipolicy
                INTO :ilast_policy
                FROM assured_vs_ply
               WHERE icard = :ilast_card;

     if(SQLCODE==SQLNOTFOUND)
     {
         strcpy(ilast_policy,"");
     }

     Birth_len = strlen(ibirth);
     if (Birth_len == 7)
     {
        if (strncmp(ibirth,"0",1)==0)
        {
            strncpy(ibirth,ibirth+1,6);
            ibirth[6] = '\0';
        }
     }

     strcpy(cdply_begin  , cm_cdate_str_100(dply_begin));    /*** �j��O�� ***/
     strcpy(cdply_end    , cm_cdate_str_100(dply_end));
     strcpy(cdply_begin2 , cm_cdate_str_100(dply_begin2));   /*** ���N�O�� ***/
     strcpy(cdply_end2   , cm_cdate_str_100(dply_end2));
     strcpy(cdcreate     , cm_cdate_str_100(dcreate));       /*** ���ɤ�� ***/

     printf("cdply_begin[%s] , cdply_end[%s] \n",cdply_begin , cdply_end);
     printf("cdply_begin2[%s] , cdply_end2[%s] \n",cdply_begin2 , cdply_end2);

     /*strcpy(C_qcylinder , itoa(qcylinder)); 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/
     sprintf_s(C_qcylinder ,sizeof C_qcylinder, "%8.2f" , qcylinder);
     sprintf_s(C_qpt ,sizeof C_qpt, "%6.2f" , qpt);
     sprintf_s(C_mcar_price ,sizeof C_mcar_price, "%7.2f" , mcar_price);

     printf("C_qpt[%s] , C_mcar_price[%s] \n",C_qpt , C_mcar_price);

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);

     cm_buf_put("%s %s %s %s %s" , iassured    , nassured         , ibirth       , fsex       , fmarriage);
     cm_buf_put("%s %s %s %s %s" , aassured    , cdply_begin      , cdply_end    , iissue_ym  , nbrand_abbr);
     cm_buf_put("%s %s %s %s "   , ncar_abbr   , C_qcylinder      , itag         , iengine);
     cm_buf_put("%s %s %s %s "   , fcomp_class , fcomp_class_last , cdcreate     , ibig_office);
     cm_buf_put("%s %s %s %s %s" , ibig_sales  , icard2           , cdply_begin2 , cdply_end2 , ipro_year);
     cm_buf_put("%s %s %d %d %d" , C_qpt       , C_mcar_price     , mvol_prem    , mlia_prem  , mtot_prem);
     cm_buf_put("%s"             , ilast_policy);
     cm_buf_put("%s %s %s %s %s" , iestimate, icar_type1, icar_type2, iofficer1, iofficer2);

     $SELECT count(*)
        INTO $ins_cnt
        FROM ca_trans_ins
       WHERE iestimate = $iestimate;

     cm_buf_put("%d",ins_cnt);

     $DECLARE ins_cur_1 CURSOR FOR
       SELECT iins_type, minjured_cover/10000, mdeath_cover/10000, mdamage_cover/10000,
              mdeduct, mins_premium, pdiscount, mdiscount, mprem, drate_ym
         INTO $iins_type, $minjured_cover, $mdeath_cover, $mdamage_cover,
              $mdeduct, $mins_premium, $pdiscount, $mdiscount, $mprem, $drate_ym
         FROM ca_trans_ins
        WHERE iestimate = $iestimate;
     $OPEN ins_cur_1;
     for(;;)
     {
     $FETCH ins_cur_1;
     if (SQLCODE == SQLNOTFOUND) break;
         cm_buf_put("%s %d %d %d %d %d %d %s",iins_type, minjured_cover, mdeath_cover, mdamage_cover,
                                                    mdeduct, mins_premium, pdiscount, drate_ym);
     }
     $CLOSE ins_cur_1;
     $FREE  ins_cur_1;
     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
       return apiRC;
     else
       return api_OKComplete;

     /*** EXEC SQL SET EXPLAIN OFF; ***/

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long get_ca_big_office_name(reply)
serverReply reply;
{
    EXEC SQL char DBName[5];
    EXEC SQL char ibig_comp[11],nname[41],ibig_branch[21],ireg_no[21];
    EXEC SQL char Iofficer[11],IofficerName[10];
    EXEC SQL char stmt[1024];
    int tmp_len;

    cm_buf_get("%s %s", DBName,ibig_comp);

    EXEC SQL WHENEVER SQLERROR GOTO errexit;
    if (db_select(DBName) == False)
    {
       if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
         return M_CM_DB_NOTOPEN;
       else
         return apiRC;
    }

    sprintf_s(stmt,sizeof stmt,"SELECT nname,ibig_branch,ireg_no \
                    FROM ca_big_office \
                   WHERE fclass = '2' \
                     AND ibig_comp = '%s'",ibig_comp);

    EXEC SQL PREPARE big_office FROM :stmt;
    EXEC SQL DECLARE office_cur CURSOR FOR big_office;
    EXEC SQL OPEN    office_cur;
    EXEC SQL FETCH   office_cur INTO :nname, :ibig_branch, :ireg_no ;
    if (SQLCODE==SQLNOTFOUND)
    {
        strcpy(nname,"");
        strcpy(ibig_branch,"");
		strcpy(ireg_no,"");  /*1080408005-SC1-��ã��-�j���һ{�ҷs�W�q����Ƥεn���Ҹ�*/
    }
    else
    {
        strcpy(nname,trim(nname));
        strcpy(ibig_branch,trim(ibig_branch));
		strcpy(ireg_no,trim(ireg_no));  /*1080408005-SC1-��ã��-�j���һ{�ҷs�W�q����Ƥεn���Ҹ�*/
    }
    printf("nname[%s]\n",nname);
    EXEC SQL CLOSE office_cur;
    EXEC SQL FREE  office_cur;

    if (ibig_branch[0] != '\0' && ibig_branch[0] != '')
    {
        sprintf_s(stmt,sizeof stmt,"SELECT iofficer,nname \
                        FROM officer \
                       WHERE ibus_location = '%s'",ibig_branch);

        EXEC SQL PREPARE big_office1 FROM :stmt;
        EXEC SQL DECLARE office_cur1 CURSOR FOR big_office1;
        EXEC SQL OPEN    office_cur1;
        EXEC SQL FETCH   office_cur1 INTO :Iofficer, :IofficerName;
        if (SQLCODE==SQLNOTFOUND)
        {
            strcpy(Iofficer,"");
            strcpy(IofficerName,"");
        }
        else
        {
            strcpy(Iofficer,trim(Iofficer));
            strcpy(IofficerName,trim(IofficerName));
        }
        printf("Iofficer[%s],IofficerName[%s]\n",Iofficer,IofficerName);
        EXEC SQL CLOSE office_cur1;
        EXEC SQL FREE  office_cur1;
    }

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s",M_CM_OK,nname);
    cm_buf_put("%s %s %s %s",Iofficer,IofficerName,ibig_branch,ireg_no);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
       return apiRC;
    else
       return api_OKComplete;

errexit:
   return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long get_ca_rate_renew_code(reply)
serverReply reply;
{
  EXEC SQL char icode[5], icode1[5], icode2[5], icode3[5];
  EXEC SQL char code_flag[2];
  EXEC SQL char DBName[5];
  EXEC SQL char dply_begin[11], fcard_class[2];
  EXEC SQL int  Idply_begin;
  int tmp_len;

  cm_buf_get("%s", DBName);
  cm_buf_get("%s %s", dply_begin, fcard_class );
  /* Idply_begin = atoi(dply_begin); */
  printf("dply_begin[%s]\n",dply_begin);
  EXEC SQL WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False) 
  {
    if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }

  EXEC SQL SELECT icode,  code_flag, icode1, icode2, icode3
             INTO $icode, $code_flag, $icode1, $icode2, $icode3
             FROM ca_rate_renew
            WHERE deffect_bgn <= :dply_begin
              AND deffect_end >= :dply_begin
              AND fcard_class = :fcard_class;

  printf("icode[%s] code_flag[%s]\n",icode, code_flag);

  if(SQLCODE==SQLNOTFOUND) 
  {  
     if(exitsub(reply,M_CM_NOT_FOUND) == True)    
         return M_CM_NOT_FOUND;                    
     else
         return apiRC;
  }  
  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s ",M_CM_OK,icode);
  cm_buf_put("%s %s %s %s", code_flag, icode1, icode2, icode3);
  tmp_len = cm_buf_len(ReplyBuf);

  if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long get_brand_engine_list(reply)
serverReply reply;
{
    $char   DBName[5];
    $char   ibrand[10], engine_title[11], check_type[3], Cdate[11];
    $int    engine_len, eng_pos_bgn, eng_pos_end, eng_length;
    $date   check_date;
    long    count_engine;

    int     tmp_len;

    cm_buf_get("%s", DBName);

    $WHENEVER SQLERROR GOTO errexit;
    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
        else
            return apiRC;
    }

    cm_buf_init(ReplyBuf);
    cm_buf_res_msg();
    cm_buf_res_count();

    $DECLARE cur_brand_engine CURSOR FOR
      SELECT ibrand, engine_len, engine_title, eng_position, eng_length, check_type, check_date
        FROM brand_engine
       ORDER BY ibrand, check_date;

    $OPEN cur_brand_engine;
    count_engine = 0;
    for (;;)
    {
        $FETCH cur_brand_engine INTO $ibrand, $engine_len, $engine_title,
                                     $eng_pos_bgn, $eng_length, $check_type,
                                     $check_date;

        if(SQLCODE==SQLNOTFOUND)
            break;

        /** convert from DATE type to CY/MM/DD string **/
        strcpy(Cdate, cm_cdate_str_100(check_date));

        cm_buf_put("%s %d %s" , ibrand, engine_len, engine_title);
        cm_buf_put("%s %d %d" , check_type, eng_pos_bgn, eng_length);
        cm_buf_put("%s", Cdate);

        count_engine ++;
    }

    if (count_engine > 0)
    {
        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(count_engine);

        tmp_len = cm_buf_len(ReplyBuf);

        if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
            return apiRC;
        else
            return api_OKComplete;
    }
    else
    {
        if (exitsub(reply,M_CM_NOT_FOUND) == True)
            return M_CM_NOT_FOUND;
        else
            return apiRC;
    }

errexit:
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}


long get_add_mplace_day(reply)
serverReply reply;
{
    $char   DBName[5];
    $long   damage_qday[20], thief_qday[20];
    $long   damage_count, thief_count;
    int     i;
    int     tmp_len;

    cm_buf_get("%s", DBName);

    $WHENEVER SQLERROR GOTO errexit;
    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
        else
            return apiRC;
    }

    damage_count = 0;
    /* ����l���I�N�B���Ѽ� */
    $DECLARE cur_damage_qday CURSOR FOR
      SELECT distinct qday
        FROM ca_add_mplace
       WHERE iins_type in ('01','05','08','09','201','205','209')
       ORDER BY qday;
    $OPEN cur_damage_qday;
    for (i=0;;i++)
    {
        $FETCH cur_damage_qday INTO $damage_qday[i];

        if(SQLCODE==SQLNOTFOUND)
            break;

        damage_count ++;
    }
    $CLOSE cur_damage_qday;
    $FREE  cur_damage_qday;

    thief_count  = 0;
    /* �ѵs�l���I�N�B���Ѽ� */
    $DECLARE cur_thief_qday CURSOR FOR
      SELECT distinct qday
        FROM ca_add_mplace
       WHERE iins_type in('11','211')
       ORDER BY qday;
    $OPEN cur_thief_qday;
    for (i=0;;i++)
    {
        $FETCH cur_thief_qday INTO $thief_qday[i];

        if(SQLCODE==SQLNOTFOUND)
            break;

        thief_count ++;
    }
    $CLOSE cur_thief_qday;
    $FREE  cur_thief_qday;

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);

    cm_buf_put("%l", damage_count);
    for (i=0;i<damage_count;i++)
    {
        cm_buf_put("%l", damage_qday[i]);
    }

    cm_buf_put("%l", thief_count);
    for (i=0;i<thief_count;i++)
    {
        cm_buf_put("%l", thief_qday[i]);
    }

    tmp_len = cm_buf_len(ReplyBuf);

    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long get_b2b_motor_est(reply)
serverReply reply;
{
    $char   DBName[5];
    int     i;
    int     tmp_len;
    $char   icomp_card[21];
    $char   icard[21];
    $char   iestimate[21];

    cm_buf_get("%s", DBName);

    $WHENEVER SQLERROR GOTO errexit;
    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
        else
            return apiRC;
    }

    cm_buf_get("%s %s",icomp_card,icard);   
    printf("icomp_card[%s],icard[%s]\n",icomp_card,icard);
 
    if (strlen(trim(icomp_card)) != 0)
    {
       $SELECT iestimate
          INTO $iestimate
          FROM ca_trans_ply
         WHERE icard = $icomp_card;
            if (SQLCODE == SQLNOTFOUND)
            {
                strcpy(iestimate," ");
            } 
    }
    else
    {
       if (strlen(trim(icard)) != 0)
       { 
          $SELECT iestimate
             INTO $iestimate
             FROM ca_trans_ply
            WHERE icard2 = $icard;
               if (SQLCODE == SQLNOTFOUND)
               {
                   strcpy(iestimate," ");
               } 
       }
       else
       {
           strcpy(iestimate," ");
       }
    }

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    cm_buf_put("%s",iestimate);

    tmp_len = cm_buf_len(ReplyBuf);

    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long get_iinstall(reply)
serverReply reply;
{
    $char   DBName[5];
    int     i;
    int     tmp_len;
    $char   iinstall[11];
    $char   ninstall[21];

    cm_buf_get("%s", DBName);

    $WHENEVER SQLERROR GOTO errexit;
    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
        else
            return apiRC;
    }

    cm_buf_get("%s",iinstall);
    printf("iinstall[%s]\n",iinstall);

    $SELECT ninstall
       INTO $ninstall
       FROM installment
      WHERE iinstall = $iinstall;
    if (SQLCODE == SQLNOTFOUND)
    {
        if (exitsub(reply,M_CM_NOT_FOUND) == True)
            return M_CM_NOT_FOUND;
        else
            return apiRC;
    }

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    cm_buf_put("%s",ninstall);

    tmp_len = cm_buf_len(ReplyBuf);

    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long get_mservice_info(reply)
serverReply reply;
{
    $char   DBName[DBNAME];
    $char   sIcorps[CORP_ID],sIbroker[BROKER];
    $char   sNchi_abv[13];
    int     tmp_len, qperiod;
    $char   soff[11];
    $char   speriod[3], speriod1[3];
    $char   scartype[3], iins_cat[2], icode[3];
    $char   sToday[6], sToday_tmp[11];
    $long   bef_mbusiness, lToday;
    $double mservice, mservice_1, mservice_2, mservice_3, mservice_4, mservice_5;
    $double mother_busi, mother_busi_1, mother_busi_2, mother_busi_3, mother_busi_4, mother_busi_5, min_mother_busi;
    $char   icheck_busi[2], icheck_busi_1[2], icheck_busi_2[2], icheck_busi_3[2], icheck_busi_4[2], icheck_busi_5[2];
    $int    iSecondYear,iSecondYearAdd;
    $long   dply_begin21, dply_end21;
    $char   dply_bgn[13], dply_end[13],sDeffect[11];
    long    rc;
    
    /* �q���ĤG���q���� */
    $char sRtn_route[2], sIroute[21], sIrate_type[2], sIroute_comm[4];
    $struct cm_route_comm o_stcomm;
    int   o_qrec = 0;

    cm_buf_get("%s %s", DBName, soff);
    cm_buf_get("%s %s", speriod, scartype);
    cm_buf_get("%s %s ", dply_bgn, dply_end);
    cm_buf_get("%s %s ", sRtn_route, sIroute);
    cm_buf_get("%s %s ", sIrate_type, sIroute_comm);
    cm_buf_get("%s ", sDeffect );
    
    printf("-- trace sDeffect[%s]\n ",sDeffect);
    dply_begin21 = cm_ymd_cdate(dply_bgn);
    dply_end21   = cm_ymd_cdate(dply_end);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
      if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
        return M_CM_DB_NOTOPEN;
      else
        return apiRC;
    }
    
    lToday = cm_today();
    
    strcpy(sIbroker, " ");
    if (strcmp(sRtn_route,"Y") != 0)
    {
       $SELECT icar_broker
          INTO $sIbroker
          FROM officer_broker
         WHERE iofficer=$soff;
   
       if (SQLCODE==SQLNOTFOUND) {
           if (exitsub(reply,M_CA_NCORPS) == True)
              return M_CA_NCORPS;
           else return apiRC;
       }
    }
    qperiod = atoi(speriod);

    rc = get_iins_cat( scartype, 1, qperiod, iins_cat, speriod1, v_sMsg );


   printf(" ======== iins_cat=[%s]   speriod1 =[%s]\n",iins_cat,speriod1);
    if( rc != M_CM_OK)
    {
        if(exitsub(reply, rc) == True)
            return  rc;
        else
            return apiRC;
    }

    $select first 1 TRUNC((($dply_end21 - date_add( $dply_begin21, interval(1) year to year)) / 30))
       into $iSecondYear
       from systables;

    printf("iSecondYear[%d]\n", iSecondYear);

    do
    {
            $select first 1
            case
                    when date_add($dply_begin21,interval(1) year to year) = $dply_end21 then 0
                    when date_add($dply_begin21,(12+$iSecondYear) * interval(1) month to month) <= $dply_end21 then 1
                    else 0
            end 
            into $iSecondYearAdd
            from systables;
            iSecondYear += iSecondYearAdd;
    }while(iSecondYearAdd > 0);

    printf("iSecondYear[%d]\n", iSecondYear);
    min_mother_busi = 0.0;

    if ( (strncmp(scartype,"01",2) == 0) ||
         (strncmp(scartype,"02",2) == 0) ||
         (strncmp(scartype,"32",2) == 0) ||
         (strncmp(scartype,"34",2) == 0)  )
    {
         if (strcmp(sRtn_route,"Y") == 0)
         { /* �A�γq���ĤG���q */
            memset(&o_stcomm, 0x00, sizeof(o_stcomm));
            o_qrec = 0;   
            rc = cm_get_insure_comm(sIroute, sIrate_type, sIroute_comm, "C", "Z", 
                                    "21", "1", &o_qrec, &o_stcomm, sDeffect);
            if( rc != M_CM_OK)
             {
                 if(exitsub(reply, rc) == True)
                     return  rc;
                 else
                     return apiRC;
             }
        
            mservice_1 = o_stcomm.mservice;
            mother_busi_1 = o_stcomm.mother_busi;
            strcpy(icheck_busi_1,o_stcomm.icheck_busi);
            
            printf("���� mservice_1=[%f]mother_busi_1=[%f]icheck_busi_1=[%s]\n",
                     mservice_1,mother_busi_1,icheck_busi_1);
        
            memset(&o_stcomm, 0x00, sizeof(o_stcomm));
            o_qrec = 0;
            rc = cm_get_insure_comm(sIroute, sIrate_type, sIroute_comm, "C", "Z", 
                                    "21", "2", &o_qrec, &o_stcomm, sDeffect);
        
            if( rc != M_CM_OK)
             {
                 if(exitsub(reply, rc) == True)
                     return  rc;
                 else
                     return apiRC;
             }
             
            mservice_2 = o_stcomm.mservice;
            mother_busi_2 = o_stcomm.mother_busi;
            strcpy(icheck_busi_2,o_stcomm.icheck_busi);
            
            printf("����  mservice_2=[%f]mother_busi_2=[%f]icheck_busi_2=[%s]\n",
                    mservice_2,mother_busi_2,icheck_busi_2);

         } 
         else
         { /* ���A�γq���ĤG���q */  
           $SELECT mservice, mother_busi, icheck_busi INTO $mservice_1, $mother_busi_1, $icheck_busi_1
              FROM commission_agent
             WHERE iins_cat = 'Z'
               AND ibroker  = $sIbroker
               AND iins_type = '21'
               AND iyear = '1'; 
           
           $SELECT mservice, mother_busi, icheck_busi 
              INTO $mservice_2, $mother_busi_2, $icheck_busi_2
              FROM commission_agent
             WHERE iins_cat = 'Z'
               AND ibroker  = $sIbroker
               AND iins_type = '21'
               AND iyear = '2'; 
         } 
        /* iSecondYear = atoi(speriod) - 12; */
        
        if( iSecondYear <= 0 )
        {
            mservice = (long)mservice_1;
            mother_busi = (long)mother_busi_1;
            strcpy( icheck_busi, icheck_busi_1);
        }
        else
        {
            if( iSecondYear == 13 )
            {
            	mservice = (long)mservice_2;
            	mother_busi = (long)mother_busi_2;
                strcpy( icheck_busi, icheck_busi_2);
            }
            else
            {
            	mservice = d45(mservice_1 + (mservice_2 - mservice_1) * ((iSecondYear-0.5)/12), 0);
            	mother_busi = d45(mother_busi_1 + (mother_busi_2 - mother_busi_1) * ((iSecondYear-0.5)/12), 0);
                strcpy( icheck_busi, icheck_busi_2);
            }
        }
        if (sIrate_type[0]=='D'){
        	if (qperiod == 24){
	            $SELECT nvl(detail2::float,0) Into $min_mother_busi 
	               FROM car_code 
	              WHERE kind = 'CD' and detail = 'M2' ;         		
        	}else{
	            $SELECT nvl(detail2::float,0) Into $min_mother_busi 
	               FROM car_code 
	              WHERE kind = 'CD' and detail = 'M1' ;         		
        	}
        }        
    }
    else if(strncmp(scartype,"35",2) == 0)
    {   /* �L�q��(1110718002_SC1) */
    	memset(&o_stcomm, 0x00, sizeof(o_stcomm));
    	o_qrec = 0;   
    	rc = cm_get_insure_comm(sIroute, sIrate_type, sIroute_comm, "C", "Y", 
    	                        "21", "1", &o_qrec, &o_stcomm, sDeffect);
    	
    	if( rc != M_CM_OK)
    	{
    		if(exitsub(reply, rc) == True)
    			return  rc;
    		else
    			return apiRC;
    	}
    	
    	mservice_1 = o_stcomm.mservice;
    	mother_busi_1 = o_stcomm.mother_busi;
    	strcpy(icheck_busi_1,o_stcomm.icheck_busi);
    	
    	printf("���� mservice_1=[%f]mother_busi_1=[%f]icheck_busi_1=[%s]\n",
    	           mservice_1,mother_busi_1,icheck_busi_1);
    	
    	memset(&o_stcomm, 0x00, sizeof(o_stcomm));
    	o_qrec = 0;
    	rc = cm_get_insure_comm(sIroute, sIrate_type, sIroute_comm, "C", "Y", 
    	                        "21", "2", &o_qrec, &o_stcomm, sDeffect);
    	
    	if( rc != M_CM_OK)
    	{
    		if(exitsub(reply, rc) == True)
    			return  rc;
    		else
    			return apiRC;
    	}
    	
    	mservice_2 = o_stcomm.mservice;
    	mother_busi_2 = o_stcomm.mother_busi;
    	strcpy(icheck_busi_2,o_stcomm.icheck_busi);
    	
    	printf("����  mservice_2=[%f]mother_busi_2=[%f]icheck_busi_2=[%s]\n",
                    mservice_2,mother_busi_2,icheck_busi_2);

        memset(&o_stcomm, 0x00, sizeof(o_stcomm));
    	o_qrec = 0;
    	rc = cm_get_insure_comm(sIroute, sIrate_type, sIroute_comm, "C", "Y", 
    	                        "21", "3", &o_qrec, &o_stcomm, sDeffect);
    	
    	if( rc != M_CM_OK)
    	{
    		if(exitsub(reply, rc) == True)
    			return  rc;
    		else
    			return apiRC;
    	}
    	
    	mservice_3 = o_stcomm.mservice;
    	mother_busi_3 = o_stcomm.mother_busi;
    	strcpy(icheck_busi_3,o_stcomm.icheck_busi);
    	
    	printf("����  mservice_3=[%f]mother_busi_3=[%f]icheck_busi_3=[%s]\n",
                    mservice_3,mother_busi_3,icheck_busi_3);
        
                    
        memset(&o_stcomm, 0x00, sizeof(o_stcomm));
    	o_qrec = 0;
    	rc = cm_get_insure_comm(sIroute, sIrate_type, sIroute_comm, "C", "Y", 
    	                        "21", "4", &o_qrec, &o_stcomm, sDeffect);
    	
    	if( rc != M_CM_OK)
    	{
    		if(exitsub(reply, rc) == True)
    			return  rc;
    		else
    			return apiRC;
    	}
    	
    	mservice_4 = o_stcomm.mservice;
    	mother_busi_4 = o_stcomm.mother_busi;
    	strcpy(icheck_busi_4,o_stcomm.icheck_busi);
    	
    	printf("����  mservice_4=[%f]mother_busi_4=[%f]icheck_busi_4=[%s]\n",
                    mservice_4,mother_busi_4,icheck_busi_4);
                    
        memset(&o_stcomm, 0x00, sizeof(o_stcomm));
    	o_qrec = 0;
    	rc = cm_get_insure_comm(sIroute, sIrate_type, sIroute_comm, "C", "Y", 
    	                        "21", "5", &o_qrec, &o_stcomm, sDeffect);
    	
    	if( rc != M_CM_OK)
    	{
    		if(exitsub(reply, rc) == True)
    			return  rc;
    		else
    			return apiRC;
    	}
    	
    	mservice_5 = o_stcomm.mservice;
    	mother_busi_5 = o_stcomm.mother_busi;
    	strcpy(icheck_busi_5,o_stcomm.icheck_busi);
    	
    	printf("����  mservice_5=[%f]mother_busi_5=[%f]icheck_busi_5=[%s]\n",
                    mservice_5,mother_busi_5,icheck_busi_5);
        
                    
        if( iSecondYear <= 0 )
        {
            mservice = (long)mservice_1;
            mother_busi = (long)mother_busi_1;
            strcpy( icheck_busi, icheck_busi_1);
        }
        else if( iSecondYear <= 13 )
        {
            if( iSecondYear == 13 )
            {
            	mservice = (long)mservice_2;
            	mother_busi = (long)mother_busi_2;
                strcpy( icheck_busi, icheck_busi_2);
            }
            else
            {
            	/*mservice = d45(mservice_1 + (mservice_2 - mservice_1) * ((iSecondYear-0.5)/12), 0);
            	mother_busi = d45(mother_busi_1 + (mother_busi_2 - mother_busi_1) * ((iSecondYear-0.5)/12), 0);*/
            	mservice = d45(mservice_2 * ((iSecondYear-0.5)/12), 0);
            	mother_busi = d45(mother_busi_2 * ((iSecondYear-0.5)/12), 0);
                strcpy( icheck_busi, icheck_busi_2);
            }
        }
        else if( iSecondYear <= 25 )
        {
            if( iSecondYear == 25 )
            {
            	mservice = (long)mservice_3;
            	mother_busi = (long)mother_busi_3;
                strcpy( icheck_busi, icheck_busi_3);
            }
            else
            {
            	mservice = d45(mservice_3 * ((iSecondYear-12-0.5)/12), 0);
            	mother_busi = d45(mother_busi_3 * ((iSecondYear-12-0.5)/12), 0);
                strcpy( icheck_busi, icheck_busi_3);
            }
        }
        else if( iSecondYear <= 37 )
        {
            if( iSecondYear == 37 )
            {
            	mservice = (long)mservice_4;
            	mother_busi = (long)mother_busi_4;
                strcpy( icheck_busi, icheck_busi_4);
            }
            else
            {
            	mservice = d45(mservice_4 * ((iSecondYear-24-0.5)/12), 0);
            	mother_busi = d45(mother_busi_4 * ((iSecondYear-24-0.5)/12), 0);
                strcpy( icheck_busi, icheck_busi_4);
            }
        }
        else if( iSecondYear <= 49 )
        {
            if( iSecondYear == 49 )
            {
            	mservice = (long)mservice_5;
            	mother_busi = (long)mother_busi_5;
                strcpy( icheck_busi, icheck_busi_5);
            }
            else
            {
            	mservice = d45(mservice_5 * ((iSecondYear-36-0.5)/12), 0);
            	mother_busi = d45(mother_busi_5 * ((iSecondYear-36-0.5)/12), 0);
                strcpy( icheck_busi, icheck_busi_5);
            }
        }
        
        if (sIrate_type[0]=='D'){
        	/*1111019003_SC1_�s�W�L�q�������I�O*/
        	/*if (qperiod == 60){
	            $SELECT nvl(detail2::float,0) Into $min_mother_busi 
	               FROM car_code 
	              WHERE kind = 'CD' and detail = 'M5' ;         		
        	}else if (qperiod >= 48){
	            $SELECT nvl(detail2::float,0) Into $min_mother_busi 
	               FROM car_code 
	              WHERE kind = 'CD' and detail = 'M4' ;         		
        	}else */
        	if (qperiod == 36){
	            $SELECT nvl(detail2::float,0) Into $min_mother_busi 
	               FROM car_code 
	              WHERE kind = 'CD' and detail = 'Y3' ;         		
        	}else if (qperiod >= 24){
	            $SELECT nvl(detail2::float,0) Into $min_mother_busi 
	               FROM car_code 
	              WHERE kind = 'CD' and detail = 'Y2' ;         		
        	}else{
	            $SELECT nvl(detail2::float,0) Into $min_mother_busi 
	               FROM car_code 
	              WHERE kind = 'CD' and detail = 'Y1' ;         		
        	}
        }        
    }
    else if(strncmp(scartype,"36",2) == 0)
    {
    	/* 1121115007_C01_�ĤG���ը��P��O�j��T���d���O�I */
    	
        printf("iins_cat[%s],ibroker[%s],iyear[%s]\n",iins_cat,sIbroker,speriod);
        printf(" ======== iins_cat=[%s]   speriod1 =[%s]\n",iins_cat,speriod1);
        if (strcmp(sRtn_route,"Y") == 0)
        { /* �A�γq���ĤG���q */
            memset(&o_stcomm, 0x00, sizeof(o_stcomm));
            o_qrec = 0;   
            rc = cm_get_insure_comm(sIroute, sIrate_type, sIroute_comm, "C", iins_cat, 
                                    "21", speriod1, &o_qrec, &o_stcomm, sDeffect);
            
            if( rc != M_CM_OK)
            {
                if(exitsub(reply, rc) == True)
                    return  rc;
                else
                    return apiRC;
            }
            else if( o_qrec == 0)
            {
                if(exitsub(reply,M_CA_NCOMMISSION_AGENT) == True)
                    return M_CA_NCOMMISSION_AGENT;
                else
                    return apiRC;
            }
        
            mservice = o_stcomm.mservice;
            mother_busi = o_stcomm.mother_busi;
            strcpy(icheck_busi,o_stcomm.icheck_busi);
            
            printf("���� mservice=[%f]mother_busi=[%f]icheck_busi=[%s]\n",
                     mservice,mother_busi,icheck_busi);            
          
        } 
        else
        { /* ���A�γq���ĤG���q */  
        
              $SELECT mservice, mother_busi, icheck_busi
                 INTO $mservice, $mother_busi, $icheck_busi
                 FROM commission_agent
                WHERE iins_cat  = $iins_cat
                  AND ibroker   = $sIbroker
                  AND iins_type = '21'
                  AND iyear     = $speriod1;
              if (SQLCODE == SQLNOTFOUND) 
              {
                  $SELECT mservice, mother_busi, icheck_busi
                     INTO $mservice, $mother_busi, $icheck_busi
                     FROM commission_agent
                    WHERE iins_cat  = 'C'
                      AND ibroker   = $sIbroker
                      AND iins_type = '21'
                      AND iyear     = $speriod1;
                  if (SQLCODE==SQLNOTFOUND) 
                  {
                      if (exitsub(reply,M_CA_NCOMMISSION_AGENT) == True)
                         return M_CA_NCOMMISSION_AGENT;
                      else return apiRC;
                  }
              }
        }
         
        if (sIrate_type[0]=='D')
        {
            $SELECT nvl(detail2::float,0) Into $min_mother_busi 
               FROM car_code 
              WHERE kind = 'CD' and detail = 'V0' ; 
        }         	
    }
    else
    {
        printf("iins_cat[%s],ibroker[%s],iyear[%s]\n",iins_cat,sIbroker,speriod);
        printf(" ======== iins_cat=[%s]   speriod1 =[%s]\n",iins_cat,speriod1);
        if (strcmp(sRtn_route,"Y") == 0)
         { /* �A�γq���ĤG���q */
            memset(&o_stcomm, 0x00, sizeof(o_stcomm));
            o_qrec = 0;   
            rc = cm_get_insure_comm(sIroute, sIrate_type, sIroute_comm, "C", iins_cat, 
                                    "21", speriod1, &o_qrec, &o_stcomm, sDeffect);
            
            if( rc != M_CM_OK)
            {
               if(exitsub(reply, rc) == True)
                  return  rc;
               else
                  return apiRC;
            }
            else if( o_qrec == 0)
            {
       	        /* 103.11.05: �Y���I�O��C �� X �ɡA�H C �I�O�A��@���A��l�I�O�h�_(1031022002_C1:�t�X�T���I��������������) */
       	         if ((iins_cat[0] == 'C') || (iins_cat[0] == 'X')){
	                 memset(&o_stcomm, 0x00, sizeof(o_stcomm));
	                 o_qrec = 0;   
	                 rc = cm_get_insure_comm(sIroute, sIrate_type, sIroute_comm, "C", "C", 
	                                         "21", speriod1, &o_qrec, &o_stcomm, sDeffect);
	                 if( rc != M_CM_OK)
	                 {
	                     if(exitsub(reply, rc) == True)
	                        return  rc;
	                     else
	                        return apiRC;
	                 }
	             }    
	             
                 if( o_qrec == 0)
                 {
                     if(exitsub(reply,M_CA_NCOMMISSION_AGENT) == True)
                        return M_CA_NCOMMISSION_AGENT;
                     else
                        return apiRC;
                 }
            }
        
            mservice = o_stcomm.mservice;
            mother_busi = o_stcomm.mother_busi;
            strcpy(icheck_busi,o_stcomm.icheck_busi);
            
            printf("���� mservice=[%f]mother_busi=[%f]icheck_busi=[%s]\n",
                     mservice,mother_busi,icheck_busi);            
          
         } 
         else
         { /* ���A�γq���ĤG���q */  
        
              $SELECT mservice, mother_busi, icheck_busi
                 INTO $mservice, $mother_busi, $icheck_busi
                 FROM commission_agent
                WHERE iins_cat  = $iins_cat
                  AND ibroker   = $sIbroker
                  AND iins_type = '21'
                  AND iyear     = $speriod1;
              if (SQLCODE == SQLNOTFOUND) 
              {
                  $SELECT mservice, mother_busi, icheck_busi
                     INTO $mservice, $mother_busi, $icheck_busi
                     FROM commission_agent
                    WHERE iins_cat  = 'C'
                      AND ibroker   = $sIbroker
                      AND iins_type = '21'
                      AND iyear     = $speriod1;
                  if (SQLCODE==SQLNOTFOUND) 
                  {
                      if (exitsub(reply,M_CA_NCOMMISSION_AGENT) == True)
                         return M_CA_NCOMMISSION_AGENT;
                      else return apiRC;
                  }
              }
         }
         
         if (sIrate_type[0]=='D'){
            $SELECT nvl(detail2::float,0) Into $min_mother_busi 
               FROM car_code 
              WHERE kind = 'CD' and detail = 'C0' ; 
         }         
    
    }
    
    	
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %e %e %s %e", M_CM_OK, mservice, mother_busi, icheck_busi, min_mother_busi );
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
      return apiRC;
    else
      return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long get_ins_comm_agent_comp(reply)
serverReply reply;
{
    $char   DBName[5];
    $double pcommission, pagent, pdiscount;
    $char   ibroker[BROKER], ins_type[INSURANCE_TYPE], car_type[5];
    $char   tmp_comm[8], tmp_agent[8], tmp_discount[8];
    int     tmp_len, qperiod;
    $char   tmp_pfix_agent[10];
    $double pfix_agent;
    $char   icheck_commi[3];
    $char   icheck_agent[3];
    $char   icheck_disc[3];
    $char   iins_cat[3];
    $char   itype_disc[2];
    $char   iyear[2];
    $char   period[3];
    long    rc;
    double mservice, mother_busi;
    char   icheck_busi[2], icheck_mservice[2], ipaid_base[2], drate_ym[5];

    /* 1000311003 �q��2 */
    $char   irate_type[2],iroute_comm[4],iroute[21],iofficer[11];
    $char   insure_type[2], deffect[11], fstart[2], fPlyEdr[2];

    cm_buf_get("%s %s %s %s %s %s", DBName, ins_type, ibroker, car_type, period, drate_ym);

    /* 1000311003 �q��2 */
    cm_buf_get("%s %s %s %s %s", iroute, iofficer, irate_type, iroute_comm, fPlyEdr);

    $WHENEVER SQLERROR GOTO errexit;
    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
        else
            return apiRC;
    }
    
    strcpy( car_type , trim(car_type));
    strcpy( fstart , "");
    qperiod = atoi( period);
    
    rc = get_iins_cat( car_type, 1, qperiod, iins_cat, iyear, v_sMsg );

    if( rc != M_CM_OK)
    {
        if(exitsub(reply, rc) == True)
            return  rc;
        else
            return apiRC;
    }

    rc = get_commission_agent( iins_cat, ibroker, ins_type, iyear, drate_ym,
             &pagent, &pdiscount, &pcommission, &mservice, &mother_busi,
             icheck_disc, icheck_commi, icheck_agent, icheck_busi, ipaid_base,
             &pfix_agent, icheck_mservice, itype_disc, fstart, iofficer, iroute, irate_type, iroute_comm, fPlyEdr, v_sMsg );

   if( rc != M_CM_OK)
   {
     if(exitsub(reply, rc) == True)
       return  rc;
     else
       return apiRC;
   }
    
   strcpy(icheck_commi, trim(icheck_commi));
   strcpy(icheck_agent, trim(icheck_agent));
   strcpy(icheck_disc,  trim(icheck_disc));
   sprintf_s(tmp_pfix_agent,sizeof tmp_pfix_agent,"%4.2f",pfix_agent);

    if (strcmp(trim(icheck_agent),"4")==0)  /* �N�z�v�B��--�̦����v�p�� */
    {
         /* �p���I�ĤT��L����i�� */
         pagent = (double)pcommission * (double)(pfix_agent/100.00);
         pagent = pagent + 0.009;
         pagent = (long)(pagent*100);
         pagent = (double)((double)pagent/100.00); 
    }

    printf("{get_ins_comm_agent}:icheck_agent[%s],pagent[%lf]\n",icheck_agent, pagent);

    sprintf_s(tmp_comm,sizeof tmp_comm,     "%4.2f" , pcommission);
    sprintf_s(tmp_agent,sizeof tmp_agent,    "%4.2f" , pagent);
    sprintf_s(tmp_discount,sizeof tmp_discount, "%4.2f" , pdiscount);

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    cm_buf_put("%s %s %s", tmp_comm, tmp_agent, tmp_discount);
    cm_buf_put("%s", tmp_pfix_agent);
    cm_buf_put("%s %s %s", icheck_commi, icheck_agent, icheck_disc);
    cm_buf_put("%s",itype_disc);

    cm_buf_put("%e %e %s %s ",mservice,mother_busi,icheck_busi, ipaid_base );

    printf("mservice[%f]\n",mservice);
    printf("mother_busi[%f]\n",mother_busi);
    printf("icheck_busi[%s]\n",icheck_busi);

    tmp_len = cm_buf_len(ReplyBuf);

    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long get_route_chk(reply)
serverReply reply;
{
    $char   DBName[5];
    $char   iroute[21], ffinance[2], iroute4[5];
    int     tmp_len;

    cm_buf_get("%s %s", DBName, iroute);
    strncpy( iroute4, iroute, 4);
    iroute4[4] = '\0';
    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
             return M_CM_DB_NOTOPEN;
        else
             return apiRC;
    }
    printf("get_route_chk:iroute[%s], iroute4[%s]\n",iroute, iroute4);

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l", M_CM_OK);

    $SELECT ffinance
       INTO $ffinance
       FROM cm_route
      WHERE iroute = $iroute4;
 
    cm_buf_put("%l", SQLCODE); /* �O�_���|�X�q���N�� */

    $SELECT m.iroute
       INTO $iroute
       FROM cm_route m
      WHERE m.iroute = $iroute
        AND ( m.dexpire is null OR m.dexpire >= Today );

    cm_buf_put("%l", SQLCODE);
    cm_buf_put("%s %s", iroute, ffinance);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long get_sales_chk(reply)
serverReply reply;
{
    $char   DBName[5];
    $char   iroute[21], route_sales[11], nsales[21], iroute_main[13];
	$char   ireg_no[21];/*1080408005-SC1-��ã��-�j���һ{�ҷs�W�q����Ƥεn���Ҹ�*/
    int     tmp_len;

    cm_buf_get("%s %s %s", DBName, iroute, route_sales);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
             return M_CM_DB_NOTOPEN;
        else
             return apiRC;
    }
    printf("get_sales_chk:route_sales[%s]\n",route_sales);
    
    /* ����cm_route����D�q���N�� */
    $SELECT iroute_main INTO $iroute_main
       FROM cm_route
      WHERE iroute = $iroute;
      
    if(SQLCODE==SQLNOTFOUND)
    {
        if(exitsub(reply,M_CMN_NROUTE) == True)
            return M_CMN_NROUTE;
        else
            return apiRC;
    }
	strcpy(ireg_no,"");
    $SELECT isales, nsales , ilicence INTO $route_sales, $nsales, $ireg_no
       FROM cm_route_sales
      WHERE iroute = $iroute_main
        AND isales = $route_sales
        AND ( dexpire is null OR dexpire >= Today );
    if(SQLCODE==SQLNOTFOUND)
    {
        if(exitsub(reply,M_CMN_NSALES) == True)
            return M_CMN_NSALES;
        else
            return apiRC;
    }

    cm_buf_init(ReplyBuf);

    cm_buf_put("%l", M_CM_OK);
    cm_buf_put("%s %s %s %s", route_sales, nsales, ireg_no ,iroute_main);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long get_sales_chk1(reply)
serverReply reply;
{
    $char   DBName[5];
    $char   iroute4[21], route_sales[11], nsales[21], ffinance[2];
    int     tmp_len;

    cm_buf_get("%s %s %s", DBName, iroute4, route_sales);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
             return M_CM_DB_NOTOPEN;
        else
             return apiRC;
    }
    printf("get_sales_chk:route_sales[%s]\n",route_sales);
    
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l", M_CM_OK);

    $SELECT ffinance 
       INTO $ffinance 
       FROM cm_route
      WHERE iroute = $iroute4;

    cm_buf_put("%l", SQLCODE); /* �O�_���|�X�q���N�� */

    $SELECT isales, nsales INTO $route_sales, $nsales
       FROM cm_route_sales
      WHERE iroute = $iroute4
        AND isales = $route_sales
        AND ( dexpire is null OR dexpire >= Today );

    cm_buf_put("%l", SQLCODE);

    cm_buf_put("%s %s %s", route_sales, nsales, ffinance );

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/**********************************************************************************/
/* �HClient�ݶǤJ�������O�T�D�O�渹iext_policy�O�T�D�O���� */
static long get_ca_ply_ext( reply )
serverReply reply;
{
$char iext_policy[21];
$char icar_flag_ext[2], iparts[2], irate[11],s_dply_bgn[11],s_dply_end[11];
$long qperiod, qmiles, mcover1, mdeduct;
$char iassured[11],nassured[121],aassured_zip[CA_ZIP],aassured[91],nrepresent[121];/* 1090525004-SC1-�]�y��-�s���l���ϸ�3+3   ZIP_CODE 5+1->CA_ZIP 6+1*/
int     tmp_len;
$char   DBName[5];
$char   itel[21],itel_night[21],mobil_phone[21];/*1090508001-SC1-��౻T-��T�M��[�ظm�T�������O�T�I�����κި�t��*/

    $WHENEVER SQLERROR GOTO errexit;

    cm_buf_get("%s %s", DBName, iext_policy );

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
             return M_CM_DB_NOTOPEN;
        else
             return apiRC;
    }

    cm_buf_init(ReplyBuf);
    cm_buf_res_msg();           /* reserve for msg_code */

    /* �s�¨��B�O�T���O�B�O�T��ơB�O�T���e�ơB�O�v�N���B�C�����C�@�ƬG�̰����v���B�B�ۭt�B */
    $SELECT icar_flag, iparts, qperiod,
            qmiles, irate, mcover1, mdeduct,dply_begin,dply_end,
            iassured,nvl(nassured,' '),aassured_zip,nvl(aassured,' '),nvl(nrepresent,' '),
            nvl(itel,' '),nvl(itel_night,' '),nvl(mobil_phone,' ')
       INTO $icar_flag_ext, $iparts, $qperiod,
            $qmiles, $irate, $mcover1, $mdeduct,$s_dply_bgn,$s_dply_end,
            $iassured,$nassured,$aassured_zip,$aassured,$nrepresent,
            $itel,$itel_night,$mobil_phone
       FROM ca_ply_ext
      WHERE ipolicy = $iext_policy
        AND dpolicy is not null;

    if( SQLCODE == SQLNOTFOUND)
    {
        if(exitsub(reply,M_CA_PLY_MAIN_NO_GET) == True)
            return M_CA_PLY_MAIN_NO_GET;
        else
            return apiRC;
    }

    cm_buf_put("%s %s %d %d %s %d %d %s %s", icar_flag_ext, iparts, qperiod, qmiles, irate, mcover1, mdeduct,s_dply_bgn,s_dply_end);
    cm_buf_put("%s %s %s %s %s", iassured, nassured, aassured_zip, aassured, nrepresent);
    cm_buf_put("%s %s %s ", itel, itel_night, mobil_phone);
    cm_buf_put_msg(M_CM_OK);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/**********************************************************************************/
/* �HClient�ݶǤJ�I�إN�����oinsurance_cover��� */

static long getInsuranceCover( reply )
serverReply reply;
{
int     tmp_len;
$char   DBName[5], v_sMsg[1512];
long    rc;

$char iins_type[INSURANCE_TYPE], icover_type[ICOVER_TYPE], cover_name[COVER_NAME];
$char iprem_cover_type[ICOVER_TYPE];
$long iorder, iCount;

/* INSURANCE_COVER_LIST insCover;	 define in insurance_cover.h */

/* $long qperiod, qmiles, mcover1, mdeduct; */

    $WHENEVER SQLERROR GOTO errexit;

    cm_buf_get("%s %s", DBName, iins_type );

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
             return M_CM_DB_NOTOPEN;
        else
             return apiRC;
    }

    cm_buf_init(ReplyBuf);
    cm_buf_res_msg();
    cm_buf_res_count();

    $DECLARE curs1 CURSOR FOR
      SELECT icover_type, cover_name, iprem_cover_type, iorder
        FROM insurance_cover
       WHERE iins_type = $iins_type
       ORDER BY iorder;
    iCount = 0;
    $OPEN curs1;
    for(;;)
    {
        $FETCH curs1 INTO $icover_type, $cover_name, $iprem_cover_type;
        if( SQLCODE == SQLNOTFOUND)
            break;
        cm_buf_put("%s %s %s", icover_type, cover_name, iprem_cover_type);
        iCount++;
    }

    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(iCount);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/**********************************************************************************/
/* �HClient�ݶǤJ�I�إN�����opa_list*/

static long get_pa_list( reply )
serverReply reply;
{
int     tmp_len;
$char   DBName[5], v_sMsg[1512], pa_list[PA_LIST];
long    rc;

$char iins_type[INSURANCE_TYPE];

    $WHENEVER SQLERROR GOTO errexit;

    cm_buf_get("%s %s", DBName, iins_type );

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
             return M_CM_DB_NOTOPEN;
        else
             return apiRC;
    }

    cm_buf_init(ReplyBuf);

    $SELECT pa_list
       INTO $pa_list
       FROM insurance_type
      WHERE iins_type = $iins_type;

    if( SQLCODE == SQLNOTFOUND)
        return exitsub(reply, M_CA_NINS_TYPE) ? SQLCODE : apiRC;

    cm_buf_put("%d %s ", M_CM_OK, pa_list);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/**********************************************************************************
�@�B	�j���I�պ�X��ɡA�H�����Ҹ��βνs�Ψ���������A�j�M�p��j���I�ͮĤ�3�Ӥ뤧��O��ơA
        �Y�s�b�h����i���s�d�����T��ơA�P�ɩ�n�O�Ѥγ�����W�j���I�d�ߧǸ����C�L�i��O��Y�ơj
�G�B	�Y���s�b��O�ɤ��h�i�H���s�d�����T���
**********************************************************************************/

static long checkUsedRenewCompClass( reply )
serverReply reply;
{
int     tmp_len;
$char   DBName[5], v_sMsg[1512], pa_list[PA_LIST];
long    rc;

$char sIassured[IASSURED];
$char sItag[CA_TAG_NUM];
$char sDcompPlyBegin[DATE];

    $WHENEVER SQLERROR GOTO errexit;

    cm_buf_get("%s %s %s %s", DBName, sIassured, sItag, sDcompPlyBegin );

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
             return M_CM_DB_NOTOPEN;
        else
             return apiRC;
    }

    cm_buf_init(ReplyBuf);

    /* �X��ɤ��O��ͮĤ餶����O�ɫO��ͮĤ�e�T�Ӥ뤺���j���I��O���,���i���s�d�����T�Y�� */
    $SELECT first 1 ipolicy, dply_bgn_comp
       FROM policy_302
      WHERE ilicense = $sIassured
        AND itag = $sItag
        AND $sDcompPlyBegin between date_add( dply_bgn_comp ,INTERVAL(-3) month to month)
        AND dply_bgn_comp
        AND fcard_class = '1'
      ORDER BY dply_bgn_comp DESC;

    printf("FOUND[%d], SQLCODE[%d]\n", FOUND, SQLCODE);

    if( FOUND)
    {
        puts("FOUND");
        cm_buf_put("%d %s ", M_CM_OK, "Y");
    }
    else
    {
        puts("NOt FOUND");
        cm_buf_put("%d %s ", M_CM_OK, "N");
    }

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/**********************************************************************************
�ˮֱj���I�X�樮�ػP��O�ɤ��@�P�A�h���ʹ��ܰT���i�j���I���ػP��O�ɤ��šA�нT�{�j
**********************************************************************************/

static long checkIsDiffCompType( reply )
serverReply reply;
{
int     tmp_len;
$char   DBName[5];
long    rc;

$char sIlast_ply[IPOLICY];
$char sIcar_type[ICAR_TYPE], sIcar_type_302[ICAR_TYPE];

    $WHENEVER SQLERROR GOTO errexit;

    cm_buf_get("%s %s %s", DBName, sIlast_ply, sIcar_type);

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
             return M_CM_DB_NOTOPEN;
        else
             return apiRC;
    }

    cm_buf_init(ReplyBuf);

    $SELECT icar_type
       INTO $sIcar_type_302
       FROM policy_302
      WHERE ipolicy = $sIlast_ply;

    if( FOUND)
    {
        if( strncmp( sIcar_type, sIcar_type_302, 2) != 0)
            cm_buf_put("%d %s ", M_CM_OK, "Y");
        else
            cm_buf_put("%d %s ", M_CM_OK, "N");
    }
    else
        cm_buf_put("%d %s ", M_CM_OK, "N");

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/**********************************************************************************
���o�t�P,�����N��
**********************************************************************************/

static long getIbrand( reply )
serverReply reply;
{
int     tmp_len;
$char   DBName[5], stmt[1024], sTmp[101];
long    rc, iCount;

$char ilevel[2];   /* 3:�t�P,4:���� */
$char icode[11], ncode[31], ibrand12[3], ibrand34[3], isMotorCycle[2];
$double mcar_price;

    $WHENEVER SQLERROR GOTO errexit;

    cm_buf_get("%s %s %s %s ", DBName, ilevel, ibrand12, ibrand34);

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
             return M_CM_DB_NOTOPEN;
        else
             return apiRC;
    }

    /* ���T�w�Ө����O�_������ */
    $SELECT first 1 case when level1 = 'MM' then 'Y' else 'N' end
       INTO $isMotorCycle
       FROM cm_group
      WHERE igroup = '04'
        AND ilevel = '4'
        AND icode[1,2] = $ibrand12;

    if( ilevel[0] == '3') /* �t�P(��1�h) */
    {
        sprintf_s( stmt,sizeof stmt, "SELECT icode, ncode, 0 "
                       "  FROM cm_group"
                       " WHERE igroup = '04'"
                       "   AND ilevel = '%s'", ilevel);
    }
    else if( ilevel[0] == '4') /* ����(��2�h) */
    {
        if( isMotorCycle[0] == 'N' )
            sprintf_s( stmt,sizeof stmt, "SELECT icode[3,4], ncode, 0 "
                           "  FROM cm_group"
                           " WHERE igroup = '04'"
                           "   AND ilevel = '4'"
                           "   AND icode like '%s%%' AND icode[3,4] != '00' ORDER BY 1 DESC", ibrand12);
        else /* �����t��3,4�X�T�w��00 */
            sprintf_s( stmt,sizeof stmt, "SELECT first 1 '00', ' ', 0 "
                           "  FROM cm_group"
                           " WHERE igroup = '04'"
                           "   AND ilevel = '4'");
    }
    else if( ilevel[0] == '5') /* ����(��3�h) */
    {
            /* car9812112_C1 �t�P�����ɷs�W���Τ� modify by sylvia 100.09.21 */
            sprintf_s( stmt,sizeof stmt, "SELECT distinct ibrand[5,8], nbrand, mcar_price"
                           "  FROM ca_car_model"
                           " WHERE ibrand like '%s%s%%'"
                           "   AND (dexpire is null or dexpire > today) "
                           " ORDER BY 1 DESC", ibrand12, ibrand34);
    }
    printf("stmt[%s]\n", stmt);
    $PREPARE prep2 FROM $stmt;
    $DECLARE curs2 CURSOR FOR prep2;

    cm_buf_init(ReplyBuf);
    cm_buf_res_msg();
    cm_buf_res_count();

    iCount = 0;
    $OPEN curs2;
    for(;;)
    {
        $FETCH curs2 INTO $icode, $ncode, $mcar_price;
        if( SQLCODE == SQLNOTFOUND)
            break;
        cm_buf_put("%s %s %e", icode, ncode, mcar_price);
        iCount++;
    }
    $FREE prep2;
    $CLOSE curs2;
    $FREE curs2;
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(iCount);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/**********************************************************************************
���o�˺ظ�
**********************************************************************************/

static long getIinsType( reply )
serverReply reply;
{
int     tmp_len;
$char   DBName[5], stmt[1024], sTmp[101];
long    rc, iCount;

$char iins_type[INSURANCE_TYPE], nins_type[51];

    $WHENEVER SQLERROR GOTO errexit;

    cm_buf_get("%s ", DBName);

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
             return M_CM_DB_NOTOPEN;
        else
             return apiRC;
    }

    sprintf_s( stmt,sizeof stmt, "SELECT iins_type, nins_type"
                   "  FROM insurance_type"
                   " WHERE iins_type = iins_ply"
                   "   AND iins_type != '21' "
                   "   AND (dexpire is null or dexpire > today)"
                   " ORDER BY qserial");

    printf("stmt[%s]\n", stmt);
    cm_buf_init(ReplyBuf);
    cm_buf_res_msg();
    cm_buf_res_count();

    $PREPARE prep3 FROM $stmt;
    $DECLARE curs3 CURSOR FOR prep3;
    iCount = 0;
    $OPEN curs3;
    for(;;)
    {
        $FETCH curs3 INTO $iins_type, $nins_type;
        if( SQLCODE == SQLNOTFOUND)
            break;
        cm_buf_put("%s %s ", iins_type, nins_type);
        iCount++;
    }
    $FREE prep3;
    $CLOSE curs3;
    $FREE curs3;
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(iCount);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long isSportsCar(reply)
serverReply reply;
{
 $char DBName[5];
 $char ibrand[10];
 $char sports_car[2];
 $int  iCount;
 int tmp_len;

 cm_buf_get("%s %s", DBName, ibrand);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

  /* car9812112_C1 �t�P�����ɷs�W���Τ� modify by sylvia 100.09.21 */
 $SELECT COUNT(*) 
    INTO $iCount
    FROM ca_car_model 
   WHERE ibrand=$ibrand
     AND sports_car = 'Y'
     AND (dexpire is null or dexpire > today);

 if( iCount != 0)
     strcpy( sports_car, "Y");
 else
     strcpy( sports_car, "N");

 cm_buf_init(ReplyBuf);

 cm_buf_put("%l %s", M_CM_OK, sports_car);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
long chkIaccept(reply)
serverReply reply;
{
 $char DBName[5];
 $char iaccept[21], iroute4[21], itag[CA_TAG_NUM], dply_begin_c[11], dply_begin_v[11];
 $char ipolicy_v[21], ipolicy_c[21], itag1[CA_TAG_NUM];
 $int  iCount;
 int tmp_len;

 cm_buf_get("%s %s %s %s %s %s", DBName, iroute4, iaccept, itag, dply_begin_c, dply_begin_v);

 strcpy( iroute4, trim( iroute4));
 strcpy( iaccept, trim( iaccept));
 strcpy( itag,    trim( itag));
 strcpy( dply_begin_c, trim( dply_begin_c));
 strcpy( dply_begin_v, trim( dply_begin_v));

 printf("iroute4[%s], iaccept[%s], itag[%s], dply_begin_c[%s], dply_begin_v[%s]\n",
         iroute4, iaccept, itag, dply_begin_c, dply_begin_v);
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }
 
 $SELECT ipolicy_v, ipolicy_c, itag
    INTO $ipolicy_v, $ipolicy_c, $itag1
    FROM ca_accept 
   WHERE iroute  = $iroute4  /* �ȷ|��4�X */
     AND iaccept = $iaccept;

 if( SQLCODE == SQLNOTFOUND)
     return exitsub(reply, M_CA_ERR_IACCEPT1) ? M_CA_ERR_IACCEPT1 : apiRC;

 strcpy( ipolicy_v, trim( ipolicy_v));
 strcpy( ipolicy_c, trim( ipolicy_c));
 strcpy( itag1,     trim( itag1));

 printf("ipolicy_v[%s], ipolicy_c[%s], itag1[%s]\n", ipolicy_v, ipolicy_c, itag1);
 
 printf("strlen( dply_begin_c)=[%d]\n", strlen( dply_begin_c));
 printf("strlen( ipolicy_c)   =[%d]\n", strlen( ipolicy_c));

 if( strlen( dply_begin_c) != 0 && strlen( ipolicy_c) != 0)
     return exitsub(reply, M_CA_ERR_IACCEPT2) ? M_CA_ERR_IACCEPT2 : apiRC;

 printf("strlen( dply_begin_v)=[%d]\n", strlen( dply_begin_v));
 printf("strlen( ipolicy_v)   =[%d]\n", strlen( ipolicy_v));

 if( strlen( dply_begin_v) != 0 && strlen( ipolicy_v) != 0)
     return exitsub(reply, M_CA_ERR_IACCEPT3) ? M_CA_ERR_IACCEPT3 : apiRC;

 if( strcmp( itag, itag1) != 0 )
     return exitsub(reply, M_CA_ERR_IACCEPT4) ? M_CA_ERR_IACCEPT4 : apiRC;

 cm_buf_init(ReplyBuf);

 cm_buf_put("%l", M_CM_OK);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long get_billingcode(reply)
serverReply reply;
{
 $char DBName[5];
 $char iofficer[11],billing_code[4];
 $int  str_pos=0, length=0;
 int tmp_len;

 cm_buf_get("%s %s", DBName, iofficer);

 strcpy( iofficer, trim( iofficer));
 
 printf("iofficer[%s]\n",iofficer);
     
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }
 
 $SELECT kbill_code
    INTO $billing_code
    FROM ca_card_iofficer 
   WHERE iofficer  = $iofficer;     

 if( SQLCODE == SQLNOTFOUND)
     strcpy(billing_code," "); /* �Y�䤣��N���L���X�S�w���O�d�� */

 if (billing_code[0] != '\0' && billing_code[0] != ' ')
 {
 	 /* ��X���ˮ֦r�y���_�l��m�H�Ϊ��� */
 	 $SELECT 
      (case WHEN fbranch = 'Y' and fbranch_order < fcode_order THEN kbranch_len else 0 end + 
      case WHEN fcomp = 'Y' and fcomp_order < fcode_order THEN kcomp_len else 0 end + 
      case WHEN fyr = 'Y' and fyr_order < fcode_order THEN kyr_len else 0 end + 
      case WHEN fmth = 'Y' and fmth_order < fcode_order THEN kmth_len else 0 end + 
      case WHEN fday = 'Y' and fday_order < fcode_order THEN kday_len else 0 end),
      kcode_len
    INTO $str_pos, $length
    FROM billingsystem
    WHERE kbill_grp = 'C1' AND kbill_code = $billing_code;
    
    if (SQLCODE == SQLNOTFOUND)
    	return M_CMN_NBILLING_SYSTEM;
 }
 
 /* vb��position�n��c�y������m�h�@ */
 str_pos += 1;
 
 printf("billing_code[%s]\n", billing_code);

 cm_buf_init(ReplyBuf);

 cm_buf_put("%l %s %d %d", M_CM_OK, billing_code, str_pos, length);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/* ���o�O�_�O�v�ۥѤƤ�flag */
long get_cm_extra_charge_flag(reply)
serverReply reply;
{
 $char DBName[5];
 $char ibrand[10];
 $char frate[5], f980401[2];
 $int  iCount;
 int tmp_len;

 cm_buf_get("%s %s", DBName, frate);  /* ���o�O�v�N�� */

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 $SELECT case when drate >= date('04/01/2009') then '1' else '0' end
    INTO $f980401
    FROM ca_rate_date
   WHERE icode  = $frate
     AND itable = 'cm_extra_charge';

 if (SQLCODE == SQLNOTFOUND)
 {
   if (exitsub(reply,M_CA_EXTRA_CHARGE_DRATE) == True)
     return M_CA_EXTRA_CHARGE_DRATE;
   else
     return apiRC;
 }

 cm_buf_init(ReplyBuf);

 cm_buf_put("%l %s", M_CM_OK, f980401);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/* �ھڨ���,�O�v�N��,�I�ب��o�íp��N�B���Ѽ� */
long get_rental_days(reply)
serverReply reply;
{
 $char DBName[5];
 $char icar_type[3],iins_type[INSURANCE_TYPE],drate_ym[5];
 $long   mcoverage1[20], rental_days[20];
 $int i;
 int tmp_len,cnt;

 cm_buf_get("%s %s %s %s", DBName, icar_type, iins_type, drate_ym);  

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }
 
 cnt = 0;
 $DECLARE cur_qday CURSOR FOR
   SELECT nvl(mcoverage1,0),nvl((mcoverage2/mcoverage1),0)     
     FROM cover_vs_premium  
    WHERE icar_type = $icar_type
      AND iins_type = $iins_type
      AND drate=(SELECT drate
                   FROM ca_rate_date
                  WHERE icode=$drate_ym
                    AND itable='cover_vs_premium')
      AND mcoverage1 >= 0
      AND mcoverage2 >= 0
   GROUP BY 1,2
   ORDER BY 1,2;
      
  $OPEN cur_qday;  
   for (i=0;;i++)
   {
        if (i > 20) return M_CM_FILE_OVERFLOW;
        $FETCH cur_qday INTO $mcoverage1[i],$rental_days[i];

        if(SQLCODE==SQLNOTFOUND)
            break;
            
        cnt++;
   }
   $CLOSE cur_qday;
   $FREE  cur_qday;
   
   
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);

    cm_buf_put("%l", cnt);
    for (i=0;i<cnt;i++)
    {
        cm_buf_put("%l %l", mcoverage1[i],rental_days[i]);
    }

    tmp_len = cm_buf_len(ReplyBuf);

    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/* car9705071 �W�X�M�צ~�����i�W�M�׵��O
   �̵��O��P�P�M��(ca_promote)���o�M�צ~��(qyear) */
long get_ca_promote_qyear(reply)
serverReply reply;
{
 $char DBName[5];
 $char iremark[10];
 $int  iCount;
 $long qyear; /* �M�צ~��*/
 int tmp_len;

 cm_buf_get("%s %s", DBName, iremark);  /* ���o���O */

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 $SELECT COUNT(distinct qyear) 
    INTO $iCount
    FROM ca_promote
   WHERE iremark  = $iremark;

 if( iCount > 1) /* �ۦP���O�A�M�צ~���]�w���@�P,�Ь��ӫO�� */
 {
   if (exitsub(reply,M_CA_QYEAR_ERR) == True)
     return M_CA_QYEAR_ERR;
   else
     return apiRC;
 }
    
 $SELECT nvl(min(qyear), -9999)
    INTO $qyear
    FROM ca_promote
   WHERE iremark  = $iremark;

 printf("get_ca_promote_qyear[%d]\n", qyear);

 cm_buf_init(ReplyBuf);

 cm_buf_put("%l %d", M_CM_OK, qyear);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/* �Y�Ooption = 1���ܸg��N���}�Y��W,�h���o�M�צ^�k����� */
/* option = 2 �h���^�g�쪺�~�Z���H�κ޲z�H */
long get_W_office(reply)
serverReply reply;
{
    $char   DBName[5];
    $char   iofficer_W[EMPLOYEE_ID];
    $char   ioffice[11], iofficer_prmt[EMPLOYEE_ID];
    $char   iquota_prmt[7], ileader_prmt[11], opt[2];    
    int     tmp_len;

    cm_buf_get("%s %s %s %s", DBName, opt, iofficer_W, ioffice);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
             return M_CM_DB_NOTOPEN;
        else
             return apiRC;
    }
    
    if (opt[0] == '1')
    {
       $SELECT * FROM officer
         WHERE iofficer = $iofficer_W
           AND fprop    = 'E';   

       if (SQLCODE != SQLNOTFOUND)
       {  
printf("iofficer_w[%s],ioffice[%s]\n",iofficer_W,ioffice);    	
            $SELECT iofficer_new
               INTO $iofficer_prmt
               FROM sysdb:v_promote_off
              WHERE iofficer_ori  =  $iofficer_W     
                AND ibus_lct_ori matches $ioffice; 
 
            if (SQLCODE == SQLNOTFOUND)
           {
               if (exitsub(reply,M_CA_W_A) == True)
                   return M_CA_W_A;
               else
                   return apiRC;
           }
        } else
        {
    	        if (exitsub(reply,M_CA_W_A) == True)
                   return M_CA_W_A;
              else
                   return apiRC;  
         }
     } else if (opt[0] == '2') strcpy(iofficer_prmt,iofficer_W);
     
    
    $SELECT iquota, ileader INTO $iquota_prmt, $ileader_prmt
       FROM officer
      WHERE iofficer = $iofficer_prmt;
    if (SQLCODE == SQLNOTFOUND)
    {
         if (exitsub(reply,M_CMN_NOFFICER) == True)
              return M_CMN_NOFFICER;
         else
              return apiRC;
    }

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %s %s", M_CM_OK, iofficer_prmt, iquota_prmt, ileader_prmt);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/**********************************************************************************
���O���O����from table:car_code.kind = '10'
**********************************************************************************/

static long getMultiCarCode( reply )
serverReply reply;
{
int     tmp_len;
$char   DBName[5], stmt[1024], sTmp[101];
$char   kind[3], detail[21], detail2[21], chiname[41], engname[41];
long    rc, iCount;

    $WHENEVER SQLERROR GOTO errexit;

    cm_buf_get("%s %s", DBName, kind);

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
             return M_CM_DB_NOTOPEN;
        else
             return apiRC;
    }

    $DECLARE curs4 CURSOR FOR
      SELECT detail, detail2, chiname, engname
        FROM car_code
       WHERE kind = $kind;

    cm_buf_init(ReplyBuf);
    cm_buf_res_msg();
    cm_buf_res_count();
    iCount=0;
    $OPEN curs4;
    for(;;)
    {
        $FETCH curs4 INTO $detail, $detail2, $chiname, $engname;
        if( SQLCODE == SQLNOTFOUND)
            break;
        cm_buf_put("%s %s %s %s", detail, detail2, chiname, engname);
        iCount++;
    }
    $CLOSE curs4;
    $FREE curs4;
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(iCount);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long getPersonalData(reply)
serverReply reply;
{
 $char DBName[5];
 $char empl_no[21];
 $char chinese_name[21], email[31];
 $int  iCount;
 int tmp_len;

 cm_buf_get("%s %s", DBName, empl_no);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

   $SELECT chinese_name, email
      INTO $chinese_name, $email
      FROM personal:asempl
     WHERE empl_no = $empl_no;

   if(SQLCODE==SQLNOTFOUND)
   {
       strcpy( chinese_name, "");
       strcpy( email ,"");
   }

 cm_buf_init(ReplyBuf);

 cm_buf_put("%l %s %s ", M_CM_OK, chinese_name, email);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long getOfficerInfo(reply)
serverReply reply;
{
 $char DBName[5];
 $char iofficer[11];
 $char nbranch_leader[51], nfax_leader[51], naddress_leader[51], ntel_leader[51], nleader[51]; 
 $int  iCount;
 int tmp_len;

 cm_buf_get("%s %s", DBName, iofficer);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

   $SELECT FIRST 1 x.ibig_branch as nbranch_leader,
                   x.ibig_office as nfax_leader,
                   x.nname as naddress_leader,
         CASE WHEN LEFT(r.iroute,2) = 'JB' THEN  r.tphone
              else x.itel END as ntel_leader,
                   y.nname as nleader
              INTO $nbranch_leader, $nfax_leader, $naddress_leader, $ntel_leader, $nleader
              FROM ca_big_office x , officer y, officer z,cm_route r
             WHERE ((x.ibig_comp = y.iquota[1,4] || '00') or (x.ibig_comp = y.iquota))
               AND r.iroute= z.iroute
               AND x.fclass = '3'
               AND y.iofficer = z.ileader
               AND z.iofficer = $iofficer
          order by x.ibig_comp desc;

   if(SQLCODE==SQLNOTFOUND)
   {
       strcpy( nbranch_leader , "");
       strcpy( nfax_leader, "");
       strcpy( naddress_leader, "");
       strcpy( ntel_leader, "");
       strcpy( nleader, "");
   }

 cm_buf_init(ReplyBuf);

 cm_buf_put("%l %s %s %s %s %s ", M_CM_OK, nbranch_leader, nfax_leader, naddress_leader, ntel_leader, nleader); 

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/* -------------------------------------------------------------------------- */
/* �ھڨ���,�O�v�N��,�I�ب��o�íp���Q���{�� */
long get_rental_km(reply)
serverReply reply;
{
 $char DBName[5],sCar_age[3];
 $char icar_type[3],iins_type[INSURANCE_TYPE],drate_ym[5];
 $long mcoverage1[20], mcoverage2[20], rental_km[20];
 $int i, iCar_age;
 
 int tmp_len,cnt;

 cm_buf_get("%s %s %s %s %s", DBName, icar_type, iins_type, drate_ym, sCar_age);  

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }
 printf("DBName[%s]\n",DBName);
 printf("icar_type[%s]\n",icar_type);
 printf("iins_type[%s]\n",iins_type);
 printf("drate_ym[%s]\n",drate_ym);
 printf("sCar_age[%s]\n",sCar_age);
 
 iCar_age = atoi(sCar_age);
 if (strncmp(iins_type,"238",3) == 0)
 {  
    /*
    238����               ����              �ŶZ
    �T��(�D01;02;32;34;35)0~3(���t)  �~     03
                          3~10(���t) �~     10
                          10~15(���t)�~     15
                          15         �~�H�W 99
    ����(01;02;32;34;35)  0~3(���t)  �~     03
                          3~10(���t) �~     10
    */
    if ( (strncmp(icar_type,"01",2) == 0) ||
         (strncmp(icar_type,"02",2) == 0) ||
         (strncmp(icar_type,"32",2) == 0) ||
         (strncmp(icar_type,"34",2) == 0) ||
         (strncmp(icar_type,"35",2) == 0) )
    {
        if (iCar_age <  3)
            strcpy(sCar_age,"03");
        else if (iCar_age <  10)
            strcpy(sCar_age,"10");
        else
            strcpy(sCar_age,"0"); /* ���줣��]�wERR*/
    }
    else
    {
        if (iCar_age <  3)
            strcpy(sCar_age,"03");
        else if (iCar_age <  10)
            strcpy(sCar_age,"10"); 
        else if (iCar_age <  15)
            strcpy(sCar_age,"15"); 
        else 
            strcpy(sCar_age,"99"); 
    }
    
     printf("iCar_age=[%d]\n",iCar_age);
     
    cnt = 0;
    $DECLARE cur_km_cover CURSOR FOR
      SELECT nvl(mcoverage1,0),nvl(mcoverage2,0),(mdeduct - mod (mdeduct,100))/100
        FROM cover_vs_premium  a
       WHERE icar_type = $icar_type
         AND iins_type = $iins_type
         AND drate=(SELECT drate
                      FROM ca_rate_date
                     WHERE icode = $drate_ym
                       AND itable='cover_vs_premium')
         AND mcoverage1 >= 0
         AND mcoverage2 >= 0
         AND mod(mdeduct,100 ) = (select mod(max(mdeduct),100 ) from cover_vs_premium
                                  where icar_type = a.icar_type
                                    and iins_type = a.iins_type
                                    and mcoverage1 = a.mcoverage1
                                    and mcoverage2 = a.mcoverage2
                                    and drate = a.drate
                                    and mod(mdeduct,100 ) = $sCar_age)
      GROUP BY 1,2,3
      ORDER BY 1,2,3;
     $OPEN cur_km_cover;  
      for (i=0;;i++)
      {
           if (i > 20) return M_CM_FILE_OVERFLOW;
           
           $FETCH cur_km_cover INTO $mcoverage1[i], $mcoverage2[i],$rental_km[i];
           
           printf("i=[%d]cur_km_cover[i]=[%ld]\n",i,rental_km[i]);
           if(SQLCODE==SQLNOTFOUND)
               break;
               
           cnt++;
      }
      
      $CLOSE cur_km_cover;
      $FREE  cur_km_cover;    
    
    
 }
 else
 {  /*  38/39*/
     if (iCar_age <= 0)
       iCar_age = 1;
     else if (iCar_age >= 9)
       iCar_age = 9;
     printf("iCar_age=[%d]\n",iCar_age);
     
     cnt = 0;
     $DECLARE cur_km CURSOR FOR
       SELECT nvl(mcoverage1,0),nvl(mcoverage2,0),(mdeduct - mod (mdeduct,10))/10
         FROM cover_vs_premium  a
        WHERE icar_type = $icar_type
          AND iins_type = $iins_type
          AND drate=(SELECT drate
                       FROM ca_rate_date
                      WHERE icode = $drate_ym
                        AND itable='cover_vs_premium')
          AND mcoverage1 >= 0
          AND mcoverage2 >= 0
          AND mod(mdeduct,10 ) = (select mod(max(mdeduct),10 ) from cover_vs_premium
                                   where icar_type = a.icar_type
                                     and iins_type = a.iins_type
                                     and mcoverage1 = a.mcoverage1
                                     and mcoverage2 = a.mcoverage2
                                     and drate = a.drate
                                     and mod(mdeduct,10 ) <= $iCar_age)
       GROUP BY 1,2,3
       ORDER BY 1,2,3;
      $OPEN cur_km;  
       for (i=0;;i++)
       {
            if (i > 20) return M_CM_FILE_OVERFLOW;
            
            $FETCH cur_km INTO $mcoverage1[i], $mcoverage2[i],$rental_km[i];
            
            printf("i=[%d]rental_km[i]=[%ld]\n",i,rental_km[i]);
            if(SQLCODE==SQLNOTFOUND)
                break;
                
            cnt++;
       }
       
       $CLOSE cur_km;
       $FREE  cur_km;       
 }

   
   
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);

    cm_buf_put("%l", cnt);
    for (i=0;i<cnt;i++)
    {
        cm_buf_put("%l %l %l",rental_km[i],mcoverage1[i],mcoverage2[i]);
    }

    tmp_len = cm_buf_len(ReplyBuf);

    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/* �ھڨ���,�O�v�N��,�I�ب��o�íp���Q���{�� */
long get_iuser_branch(reply)
serverReply reply;
{
 $char DBName[5];
 $int i, iCar_age;
 $char iuser[11];
 $char iquota[11];
 $char iupcomp[3];
 $char iapp_unit[3];
 int tmp_len,cnt;

 cm_buf_get("%s %s", DBName, iuser);  

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 $SELECT a.iquota, b.iupcomp, a.iapp_unit 
    INTO $iquota,  $iupcomp,  $iapp_unit
    FROM officer a,sa_branch_type b
   WHERE a.iquota   =   b.ibranch
     AND a.iofficer =   $iuser;
 if (SQLCODE == SQLNOTFOUND) 
 {
    strcpy(iquota," ");
    strcpy(iupcomp," ");
    strcpy(iapp_unit," ");
 } 

    strcpy(iquota,rtrim(iquota));
    strcpy(iupcomp,rtrim(iupcomp));
    strcpy(iapp_unit,rtrim(iapp_unit));

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    cm_buf_put("%s",iquota);
    cm_buf_put("%s",iupcomp);
    cm_buf_put("%s",iapp_unit); 

    tmp_len = cm_buf_len(ReplyBuf);

    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long get_salesman_iregNo(reply)/* 1080408005-SC1-��ã��-�j���һ{�ҷs�W�q����Ƥεn���Ҹ�*/ 
serverReply reply;
{
 $char DBName[5];
 $int i, iCar_age;
 $char iofficer[21],ileader[11],icomm_obj[11],qry_type[2];
 $char ilicence[11];
 	/*
    'A�O�o�q��10(KB��)         �θg��N���dofficer(�g��H�����)���I����H    �d�~�ȭ��n���M����cm_salesman_log.icomm_obj���oilicence
    'B�O�o�q��10(�DKB-���u��)  �θg��N���dofficer(�g��H�����)���޲z�H�N��  �d�~�ȭ��n���M����cm_salesman_log.icomm_obj���oilicence
    'B�O�o�q��40               �θg��N���dofficer(�g��H�����)���޲z�H�N��  �d�~�ȭ��n���M����cm_salesman_log.icomm_obj���oilicence
    'C:iofficer �ǤJ"�~�ȭ��n���Ҧr��" ; �^�ǭ� ilicence = Y/N (�O�_�s�bcm_salesman_log�B�n���b�s�w)
	'D:�ǤJilicence���o�����r�^��
	*/
int tmp_len,cnt;

	cm_buf_get("%s %s %s", DBName, qry_type , iofficer);  

	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == False)
	{
		if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}
	strcpy(iofficer,trim(iofficer));
	strcpy(ilicence," ");
	printf("qry_type[%s],iofficer[%s]",qry_type,iofficer);
	if (qry_type[0]=='D')  /* 1080910006-SC1-���ά�-�Эק�n���Ҹ�����ɪ��P�_ �Ҹ�����������W�r*/
	{
		$SELECT FIRST 1 b.nchi_full[1,10]
		   INTO $ilicence
		   FROM cm_salesman_log a, cu_customer b
		  WHERE a.id_no = b.ifpce_id AND b.ifpce_id_ext=''
		    AND a.ilicence = $iofficer
	   ORDER BY a.dupdate DESC;
		if (SQLCODE == SQLNOTFOUND) 
		{
			$SELECT FIRST 1 nsales[1,10]
			   INTO $ilicence	
			   FROM cm_route_sales
			  WHERE ilicence = $iofficer
		   ORDER BY dupdate DESC,dcreate DESC ;	  
			if (SQLCODE == SQLNOTFOUND) 
			{
				$SELECT FIRST 1 nname[1,10]
				   INTO $ilicence	
				   FROM ca_big_office
				  WHERE ireg_no = $iofficer;
				  if (SQLCODE == SQLNOTFOUND) strcpy(ilicence," ");
			}
		}
 
	}
	else if (qry_type[0]=='C')  /*1080806011_SC2 �s�W�n�����ˮ� */
	{
		strcpy(ilicence," ");	   
		$SELECT CASE WHEN Count(*) > 0 THEN 'Y' ELSE 'N' END 
	       INTO $ilicence
	 	   FROM cm_salesman_log
	 	  WHERE ilicence = $iofficer
	 	    AND ilicence <> ''
	 	    AND (dbusiness is null or dbusiness > today);
	}
	else
	{	
		strcpy(ileader," ");	strcpy(icomm_obj," ");					
		$SELECT ileader ,icomm_obj
	   	   INTO $ileader,$icomm_obj 
		   FROM officer 
		  WHERE iofficer =$iofficer;
		if (SQLCODE != SQLNOTFOUND) 
		{
	        printf("ileader[%s]icomm_obj[%s]",ileader,icomm_obj);
	        
	        strcpy(ilicence," ");	  
	        if (qry_type[0]=='A')
	        {
	            $SELECT FIRST 1 nvl(ilicence,' ')
	               INTO $ilicence
	               FROM cm_salesman_log
	              WHERE icomm_obj = $icomm_obj
	                AND (dbusiness is null or dbusiness > today)
	              ORDER by dcreate desc;
	        }
	        else
			{
	            $SELECT FIRST 1 nvl(ilicence,' ')
	               INTO $ilicence
	               FROM cm_salesman_log
	              WHERE icomm_obj = $ileader
	                AND (dbusiness is null or dbusiness > today)
	              ORDER by dcreate desc;
	        }	        
		}
	}
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    cm_buf_put("%s",ilicence); 

    tmp_len = cm_buf_len(ReplyBuf);

    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
