/**********************************************************************/
/*   program id   : ca999q01s.ec                                      */
/*   program name : �޿��ˮ�                                          */
/*   date written : 2025/03/27                                        */
/*   date modify  : yyyy/mm/dd                                        */
/*   author       : SteveChiang                                       */                                       
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
#include "safeclib.h"
/****************************************************************************/
$char DBName[05],userid[11],GetFile[128];
char  expdate[6];
$char bgndate[12],enddate[12];
char  bgn_yy[5],bgn_mm[3],end_mm[3];
int   endyy=0,endmm=0;
$int  bgndate_l=0,enddate_l=0;
int   errcnt = 0;
FILE  *fp, *fp1, *sfp;
$char sdata[4][121];
char  msgbuf[2048],sApHome[30];
char  filename[200],outputf[N_FILE+1];

int   cnt_err = 0,flen = 0;
long  t = 0;
int   i = 0,count_db = 0,rnt = 0;
int   x = 0;
DBinfo *list;
/****************************************************************************/
main(argc, argv)
int argc;
char **argv;
{  
	int rc;

	batchinit();
	strcpy(DBName,      isNULLstr(argv[1]));
	strcpy(userid,      isNULLstr(argv[2]));
	strcpy(expdate,     isNULLstr(argv[3])); 
	strcpy(GetFile,     isNULLstr(argv[4]));
	strcpy(outputf,     isNULLstr(argv[5]));
	
	printf("-- expdate[%s], GetFile[%s]\n",expdate,GetFile);
	
	strncpy(bgn_yy,&expdate[0],3);
	bgn_yy[3]='\0';
	strncpy(bgn_mm,&expdate[3],2);
	bgn_mm[2]='\0';
	if (strncmp(bgn_mm, "12",2) == 0)
	{
		endyy=atoi(bgn_yy)+1;
		endmm=1;
	}
	else
	{
		endyy=atoi(bgn_yy);
		endmm=atoi(bgn_mm)+1;
	}
	rfmtlong(endmm,"&&",end_mm);
	
	printf("bgn_mm[%s] bgn_yy[%s] end_mm[%s] endyy[%d] \n ",bgn_mm,bgn_yy,end_mm,endyy);

	sprintf_s(bgndate, sizeof bgndate,"%s/%s/%d",bgn_mm,"01",atoi(bgn_yy)+1911);
	sprintf_s(enddate, sizeof enddate,"%s/%s/%d",end_mm,"01",endyy+1911);
	printf(">>>bgndate=[%s] enddate=[%s]\n",bgndate,enddate);
	
	sfp =  (FILE *)STARTLOG();
		
	rc = car999_get_db();
	if (rc != M_CM_OK) {
		EWRITE(userid,rc,msgbuf);
		return rc;
	}

	rc = car999_init_data();
	if (rc != M_CM_OK) {
		printf("error on car999_init_data\n");
		EWRITE(userid,rc,"�إ� temp table ���~!");
		return rc;
	}
	
	rc = car999_read_data();
	if (rc != M_CM_OK) 
	{
		EWRITE(userid, rc, "�ɮ���J���~!");
		return rc;
	}
	
	rc = car999_check_data();
	if (rc != M_CM_OK) 
	{
		EWRITE(userid, rc, "��ƦX�֦��~!");
		return rc;
	}
	
	rc = car999_print_detail();
	if (rc != M_CM_OK) 
	{
		EWRITE(userid, rc, "���s�ɮצ��~!");
		return rc;
	}

	return rc;
}
/******************************************************************************/
long car999_get_db()
{
	int rc;
	
	if (db_select(DBName) == False) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "��Ʈw�L�k�}��!");
		return M_CM_DB_NOTOPEN;
	}
	
	rc = getApHome(sApHome);
	if (rc < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		EWRITE(userid,rc,msgbuf);
	 	return rc;
	}
	
	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}
	
	return M_CM_OK;

errexit:
   printf("--car999_get_db-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/******************************************************************************/
long car999_init_data()
{   
	$WHENEVER SQLERROR GOTO errexit;
	 	  	   
	$CREATE TEMP TABLE ply_logic (iply_tmp CHAR(20),iins_type_de CHAR(20)) with no log;
	
	$CREATE TEMP TABLE edr_tmp (
		ipolicy_t VARCHAR (12),
		ipolicy VARCHAR (13),
		iendorse_t CHAR (12),
		iendorse CHAR (20),
		dendorse DATE,
		fedr_class CHAR (1),
		iedr_type CHAR (2),
		iins_type_de CHAR (20),
		iins_type CHAR (6),
		chk_ins CHAR (1),
		medrinj_cover INTEGER,
		medrdmg_cover INTEGER,
		mdeduct INTEGER,
		iedr_examiner CHAR (10),
		nedr_examiner CHAR (10)
	)with no log;
	
	$CREATE TEMP TABLE edr_ins_dtl (
		iendorse CHAR (20),
		dendorse DATE,
		iedr_type CHAR (2),
		iins_type CHAR (6),
		iins_type_develop CHAR (2)
	)with no log;
	
	return M_CM_OK;
    
errexit:
    printf("--car999_init_data-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car999_read_data()
{
    char   *bp;
    int    rc;
    $char  ipolicy_tmp[21],iins_type_de_tmp[3];
    flen = 1024;
    int index = 0;
    char *part1 = NULL, *part2 = NULL, *part4 = NULL;
    
    $WHENEVER SQLERROR GOTO errexit;

    strcpy(GetFile, trim(GetFile));
    sprintf_s(filename, sizeof filename,"%s/dat/car/%s",sApHome,GetFile);
	
	if ((fp=fopen(filename,"r"))==NULL) {
		sprintf_s(msgbuf, sizeof msgbuf,"%s �ɮ׶}�ҥ���",filename);
		EWRITE(userid,FALSE,msgbuf);
		return FALSE;
	}
	if ((bp=malloc(flen))==NULL) {
		sprintf_s(msgbuf, sizeof msgbuf,"System malloc failed !");
		EWRITE(userid,FALSE,msgbuf);
		return FALSE;
	}

    while(fgets(bp,flen,fp))
	{
		if (feof(fp)) break;
		
		printf("bp[%s] \n",bp);
		
		char *found = strstr(bp, "��������i������O����");  /* ���L�~�֩ʧO���~ */
		if (found != NULL) {
			char *data_start = strrchr(bp, '�G');
	        if (data_start != NULL) {
	        	
	            data_start+=1; /* ���L "�G" �Ÿ�*/
	            
				index = 0;
		        /* ���μƾڳ��� */
		        char *token = strtok(data_start, "�B");
		        while (token != NULL) {
		            /* �h���h�l�ť� */
		            while (*token == ' ') token++;
		            /*printf("%s\n", token);*/ /* ��X���Ϋ᪺�C�ӳ��� */
		            
		            if (index == 0) part1 = token; /* �Ĥ@�����G1666 */
		            if (index == 1) part2 = token; /* �ĤG�����G1000000009 */
		            if (index == 3) part4 = token; /* �ĥ|�����G04 */
		            
		            token = strtok(NULL, "�B");
		            index++;
		        }
				
				sprintf_s(ipolicy_tmp,sizeof(ipolicy_tmp),"%s%s",part1 + 2, part2);
				sprintf_s(iins_type_de_tmp,sizeof(iins_type_de_tmp),"%s",part4);
	
				printf("ipolicy_tmp[%s] iins_type_de_tmp[%s] \n",ipolicy_tmp,iins_type_de_tmp);
				strcpy(ipolicy_tmp,trim(ipolicy_tmp));
				strcpy(iins_type_de_tmp,trim(iins_type_de_tmp));
				$INSERT INTO ply_logic VALUES($ipolicy_tmp,$iins_type_de_tmp);
			}
			else
			{
				printf("nothing\n"); 
			}
		}
	}
	free(bp);
	fclose(fp);	 
	return M_CM_OK;

errexit:
    printf("--car999_read_data-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car999_check_data()
{
	$char stmt[4096],stmp[100];
	
    $WHENEVER SQLERROR GOTO errexit; 
    $BEGIN WORK;
    
	$SELECT CASE WHEN iply_tmp[1] = '0' THEN iply_tmp[1,2]||'0'||iply_tmp[3,12] 
	             WHEN iply_tmp[1] = '1' THEN iply_tmp[1,2]||'0'||iply_tmp[3,12] 
	             WHEN iply_tmp[1] = '2' THEN iply_tmp[1,2]||'5'||iply_tmp[3,12] 
	             WHEN iply_tmp[1] = '3' THEN iply_tmp[1,2]||'6'||iply_tmp[3,12] 
	             WHEN iply_tmp[1] = '4' THEN iply_tmp[1,2]||'1'||iply_tmp[3,12] 
	             WHEN iply_tmp[1] = '5' THEN iply_tmp[1,2]||'6'||iply_tmp[3,12] 
	             WHEN iply_tmp[1] = '6' THEN iply_tmp[1,2]||'7'||iply_tmp[3,12] 
	             WHEN iply_tmp[1] = '7' THEN iply_tmp[1,2]||'2'||iply_tmp[3,12] 
	             WHEN iply_tmp[1] = '8' THEN iply_tmp[1,2]||'2'||iply_tmp[3,12]
	        ELSE '' END AS ipolicy,iins_type_de
	   FROM ply_logic
	   INTO temp ply_tmp;
    
    stmt[0] = '\0';
	for(x=0;x<count_db;x++)
	{
		sprintf_s(stmt,sizeof(stmt),"INSERT INTO edr_tmp \
		                             SELECT UNIQUE \
		                                    b.ipolicy[1,2]||b.ipolicy[4,13] AS ipolicy_t,b.ipolicy,a.iendorse[1,2]||a.iendorse[4,13] AS iendorse_t,a.iendorse,a.dendorse, \
		                                    a.fedr_class,c.iedr_type,b.iins_type_de,c.iins_type,  \
		                                    CASE WHEN (b.iins_type_de = (SELECT iins_type_develop FROM insurance_type_develop WHERE iins_type = c.iins_type) AND c.iedr_type = '05') THEN 'Y' \
		                                         WHEN (b.iins_type_de = '04' AND c.iins_type IN ('01','05','09') AND c.iedr_type = '05' AND (c.provision LIKE '%%P%%' OR c.provision LIKE '%%Q%%' OR c.provision LIKE '%%M%%')) THEN 'Y' \
		                                         WHEN (b.iins_type_de = '13' AND c.iins_type IN ('11') AND c.iedr_type = '05' AND (c.provision LIKE '%%P%%' OR c.provision LIKE '%%Q%%' OR c.provision LIKE '%%M%%')) THEN 'Y' \
		                                         WHEN (b.iins_type_de = '62' AND c.iins_type IN ('31','32') AND c.iedr_type = '05' AND c.provision LIKE '%%T%%') THEN 'Y' \
		                                         ELSE 'N' END AS chk_ins, \
		                                    c.medrinj_cover,c.medrdmg_cover,c.mdeduct,a.iedr_examiner,(SELECT nname FROM officer WHERE iofficer = a.iedr_examiner) AS nedr_examiner \
		                               FROM %s:edr_relation a,ply_tmp b,%s:edr_ins_type c \
		                              WHERE a.ipolicy = b.ipolicy \
		                                AND a.iendorse = c.iendorse \
		                                AND a.dendorse < ?;",list[x].dbname,list[x].dbname);
		printf("stmt[%s] \n",stmt);
		$PREPARE cur_edr FROM $stmt;
		$EXECUTE cur_edr using $enddate;
	}
	
	stmp[0] = '\0';
	sprintf_s(stmp,sizeof(stmp),"dendorse >= '%s' AND dendorse < '%s'",bgndate,enddate);
	
	stmt[0] = '\0';
    sprintf_s(stmt,sizeof(stmt),"SELECT UNIQUE \
	                                    ipolicy,ipolicy[1,2]||ipolicy[4,13] AS ipolicy_t, \
	                                    CASE WHEN ipolicy[3] = '0' THEN (SELECT max(iendorse) FROM newa00:edr_relation WHERE ipolicy = a.ipolicy AND %s) \
	                                         WHEN ipolicy[3] = '5' THEN (SELECT max(iendorse) FROM newa22:edr_relation WHERE ipolicy = a.ipolicy AND %s) \
	                                         WHEN ipolicy[3] = '6' THEN (SELECT max(iendorse) FROM newa33:edr_relation WHERE ipolicy = a.ipolicy AND %s) \
	                                         WHEN ipolicy[3] = '1' THEN (SELECT max(iendorse) FROM newa40:edr_relation WHERE ipolicy = a.ipolicy AND %s) \
	                                         WHEN ipolicy[3] = '7' THEN (SELECT max(iendorse) FROM newa66:edr_relation WHERE ipolicy = a.ipolicy AND %s) \
	                                         ELSE (SELECT max(iendorse) FROM newa70:edr_relation WHERE ipolicy = a.ipolicy AND %s) END AS iendorse_in_month, \
	                                    iins_type_de,  \
	                                    CASE WHEN ipolicy[3] = '0' THEN (SELECT dpolicy FROM newa00:ori_ply_relation WHERE ipolicy = a.ipolicy) \
	                                         WHEN ipolicy[3] = '5' THEN (SELECT dpolicy FROM newa22:ori_ply_relation WHERE ipolicy = a.ipolicy) \
	                                         WHEN ipolicy[3] = '6' THEN (SELECT dpolicy FROM newa33:ori_ply_relation WHERE ipolicy = a.ipolicy) \
	                                         WHEN ipolicy[3] = '1' THEN (SELECT dpolicy FROM newa40:ori_ply_relation WHERE ipolicy = a.ipolicy) \
	                                         WHEN ipolicy[3] = '7' THEN (SELECT dpolicy FROM newa66:ori_ply_relation WHERE ipolicy = a.ipolicy) \
	                                         ELSE (SELECT dpolicy FROM newa70:ori_ply_relation WHERE ipolicy = a.ipolicy) END AS dpolicy, \
	                                    CASE WHEN (SELECT count(*) FROM edr_tmp WHERE ipolicy = a.ipolicy AND iins_type_de = a.iins_type_de AND chk_ins = 'Y') > 0 THEN 'Y' ELSE 'N' END AS chk_yn, \
	                                    (SELECT max(iendorse) FROM edr_tmp WHERE ipolicy = a.ipolicy AND iins_type_de = a.iins_type_de AND chk_ins = 'Y') AS iendorse \
	                               FROM ply_tmp a \
	                               INTO temp ply_tmp1;",stmp,stmp,stmp,stmp,stmp,stmp);
	printf("stmt[%s] \n",stmt);
	$PREPARE cur_final FROM $stmt;
	$EXECUTE cur_final;
	
	stmt[0] = '\0';
	for(x=0;x<count_db;x++)
	{
		sprintf_s(stmt,sizeof(stmt),"INSERT INTO edr_ins_dtl \
		                             SELECT UNIQUE \
		                                    a.iendorse,a.dendorse,b.iedr_type,b.iins_type,(SELECT iins_type_develop FROM insurance_type_develop WHERE iins_type = b.iins_type) \
		                               FROM %s:edr_relation a,%s:edr_ins_type b \
		                              WHERE a.iendorse = b.iendorse AND a.iendorse IN (SELECT iendorse FROM ply_tmp1);",list[x].dbname,list[x].dbname);
		printf("stmt[%s] \n",stmt);
		$PREPARE cur_edr_ins FROM $stmt;
		$EXECUTE cur_edr_ins;
	}
	
	
	$COMMIT WORK;
    return M_CM_OK;
    
errexit:
    printf("--car999_insert_data-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    $ROLLBACK WORK;
    return SQLCODE; 
}   
/******************************************************************************/
long car999_print_detail()
{
    int     rc;
    char    sfilename[128],stitle[2048],stmt[2048];
    
    $WHENEVER SQLERROR GOTO errexit;

	sprintf_s(sfilename, sizeof sfilename,"�޿��ˮ֩��Ӫ�\n");
	sprintf_s(stitle, sizeof stitle,"�O�渹\t�O�渹_�O�o\t������~���\t�O�o�I�إN��\t�O��ñ���\t�O�_����[�L\t��[�I�ا��\t�Ƶ�\t");
	strcpy(stmt,"SELECT ipolicy, ipolicy_t, iendorse_in_month, chr(127)||iins_type_de, dpolicy, chk_yn, iendorse FROM ply_tmp1; ");
	rc = unload_file(outputf,"A",sfilename,stitle,stmt);

    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }
    
    sprintf_s(sfilename, sizeof sfilename,"�����Ӫ�\n");
	sprintf_s(stitle, sizeof stitle,"��渹\tñ���\t���ʽ�\t�I�إN��\t�O�o�I�إN��\t");
	strcpy(stmt,"SELECT iendorse,dendorse,chr(127)||iedr_type,chr(127)||iins_type,chr(127)||iins_type_develop FROM edr_ins_dtl; ");
    rc = unload_file(outputf,"B",sfilename,stitle,stmt);

    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;
    
errexit:
    printf("--car999_print_detail-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/