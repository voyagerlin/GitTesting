/****************************************************
 * Copyright (C) 1993 Intellisys Corporation
 * Program : car314q01s.ec 
 * Date    : 03/06/1997
 * UPDATE  : 07/04/2001
 ****************************************************/

#include <stdio.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "commsgs.h"
#include "glsmsgs.h" 
#include "gls_array.h" 
#include "gls_const.h"
#include "safeclib.h"

/* standard data declaration */
char  SysTm[21];
char  BodyFile[21];
char  TitleFile[21];
$char BodyFmt[21];
$char TitleFmt[21];
char  outputf[21];

$int  StartRow,TitleRow;
$int  ItemRow, TotColumn;
$int  PgLine, Width = 0;
int   max_count=0;

char  DBName[5];
char  userid[11];
char  FormTp[21];

$struct parm{
  char plyyr[5];
  char plymth[3];
  char ipolicy_bgn[19];
  char ipolicy_end[19];
} pa;

$struct var{
  char  ipolicy[19];
  char  ire_ply[19];
  char  iinssue_ym[11];
  char  ipro_year[5];
  char  ibrand[9];
  char  dply_begin[11];
  char  dply_end[11];
  char  dendorse[11];
  char  ibatch_no[4];
  char  nbrand_abbr[12];
  char  icar_type[3];
  char  ncar_abbr[12];
  char  itag[CA_TAG_NUM];
  char  iengine[CA_ENGINE_NUM];
  short pdmg_align;
  short plia_align;
  short pbrg_align;
  double plia_acc;
  double pdmg_acc;
  char  nassured[121];
  char  nuser[19];
  char  tmp_policy[13];
  char  ibig_office[10];
  char  ibig_branch[5];
  char  fcomp_24[2];
} v;

$struct var1{
  char  iins_type[INSURANCE_TYPE];
  long  mdamage_cover;
  long  mdeath_cover;
  long  minjured_cover;
  long  mdeduct;
  long  mins_premium;
  long  mprem;
} v1;

long iSubmins_premium;
long iSubmprem;
long iTotmins_premium=0;
long iTotmprem=0;
$long comp_premium;
long iTotcomp_premium=0;
long mins_premium_tot=0;
long mprem_tot=0;
long comp_premium_tot=0;

int car_count;
long premium0105;
long premium11;
long premium31;
long premium32;
long premium5153;
long premium52;
long premium_oth;

$char stmt[1024];
$char cDate_bgn[11];
$char cDate_end[11],str_deduct[9];

$char nbrand_abbr[13];
char prtfile[50];
char errmsg[200];
char prtstr[300];
char filename1[7],filename2[7],option[2],type[2];
$double comp_acc;
int cnt,cnt1;
FILE *fptr;

/***************************************************************/
main(argc,argv)
int argc;
char **argv;
{
     int rc;
     batchinit();

     strcpy(DBName        ,isNULLstr(argv[1]));
     strcpy(userid        ,isNULLstr(argv[2]));
     strcpy(option        ,isNULLstr(argv[3]));
     strcpy(pa.plyyr      ,isNULLstr(argv[4]));
     strcpy(pa.plymth     ,isNULLstr(argv[5]));
     strcpy(type          ,isNULLstr(argv[6]));
     strcpy(pa.ipolicy_bgn,isNULLstr(argv[7]));
     strcpy(pa.ipolicy_end,isNULLstr(argv[8]));
     strcpy(outputf       ,isNULLstr(argv[9]));

     strcpy(pa.plyyr,itoa(1911+atoi(pa.plyyr)));

     printf("plyyr[%s]\n",pa.plyyr);
     printf("plymth[%s]\n",pa.plymth);
     printf("ipolicy_bgn[%s]\n",pa.ipolicy_bgn);
     printf("ipolicy_end[%s]\n",pa.ipolicy_end);

     if((rc=ca314_build()) < 0) return;

     rc=create_sign_form("ca314",BodyFile,Width);
     if  (rc != 0)
     {
          EWRITE(userid,rc ,"ERROR on  creating sign form");
          printf("Error on creating sign form, rc=%d\n",rc);
          return;
     }

     if((rc=save_form_info(F_BLK1,"CA",314,userid,FormTp,max_count,outputf))<0)
          EWRITE(userid,rc,"save form  info failure!");
} 

/***************************************************************/
ca314_build()
{
     int   flag_exist1=0, flag_exist2=0,comp=1;

     $char ibig_branch[5],ire_ply[19],ire_card[15],ply_beg[11],ply_end[11];
     $char imain_ins[INSURANCE_TYPE],ire_card1[15],t_policy[15];
     char  icard_brk[10],str[21],apay1[5],apay2[17];
     char  brand_str[21],car_str[11], headstr[100];
     $int big_cnt=0;
     $char nname[41],mark[5],ply[20],prn_deduct[20];
     $char sTmpbgn1[21],sTmpbgn2[21],den_str[15];

     $WHENEVER SQLERROR goto errexit;

     if (db_select(DBName)==False)
     {
         EWRITE(userid,M_CM_DB_NOTOPEN,"M_CM_NOTOPEN");
         return;
     }

     $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
             kTot_col, kPgNum_Line, kWidth
        INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow, $ItemRow,
             $TotColumn, $PgLine, $Width
        FROM Form
       WHERE ksys_grp="CA" AND kPgmID = 314;

     strcpy(TitleFmt,rtrim(TitleFmt));
     strcpy(BodyFmt,rtrim(BodyFmt));
     sprintf_s(TitleFile, sizeof TitleFile,"%s.ti",outputf);
     sprintf_s(BodyFile, sizeof BodyFile,"%s.bd",outputf);

     /*--------title--------*/
     /* ESC(24)�]�w�r���j�p, ESC(1)�٭� */
     rgu_init_report(TitleFmt, TitleFile);
     rgu_put_head_string(1, cm_sysd_cdate_100(cm_get_sysd()));   /* get_currdt */
     rgu_put_head();
     rgu_finish_report();

     /*--------body---------*/
     rgu_init_report(BodyFmt, BodyFile);

     iTotmins_premium = 0;
     flag_exist1 = 0;

     v.pdmg_align= v.plia_align= v.pbrg_align= v.plia_acc= v.pdmg_acc=0;
     v.ibig_branch[0] = '\0';
     printf("{0010}:in body\n");

     if(option[0]=='1')    /*�O��*/
     {
         if (type[0]=='a')
         {
             /*�O��*/
             $DECLARE build_acursor1 CURSOR FOR
               SELECT ipolicy,ibig_branch
                 FROM ply_relation
                WHERE ipolicy BETWEEN $pa.ipolicy_bgn AND $pa.ipolicy_end
                  AND fcard_class = "2";
             $OPEN build_acursor1;
         }
         else if (type[0]=='b')
         {
             strcpy(sTmpbgn1, substring(pa.ipolicy_bgn,1,13));
             strcpy(sTmpbgn2, substring(pa.ipolicy_bgn,14,4));
             printf("sTmpbgn1:[%s] \n",sTmpbgn1);
             printf("sTmpbgn2:[%s] \n",sTmpbgn2);
             $DECLARE build_acursor1_1 CURSOR FOR
               SELECT ipolicy,ibig_branch
                 FROM ply_relation
                WHERE ipolicy[1,13]= $sTmpbgn1
                  AND fcard_class = "2"
                  AND ibatch_no = $sTmpbgn2;
             $OPEN build_acursor1_1;
         }
     }
     else
     {
         /*��O��*/
         $DECLARE build_acursor3 CURSOR FOR
           SELECT ipolicy,ibig_branch
             FROM policy_302
            WHERE ipolicy BETWEEN $pa.ipolicy_bgn AND $pa.ipolicy_end
              AND YEAR(dply_begin)=$pa.plyyr
              AND MONTH(dply_begin)=$pa.plymth
              AND fcard_class = "2";
         $OPEN build_acursor3;
     }

     while(1)
     {
         if(option[0]=='1')
         {
             if (type[0]=='a')
             {
                 $FETCH build_acursor1 INTO $v.ipolicy,$v.ibig_branch;
             }
             else if (type[0]=='b')
             {
                 $FETCH build_acursor1_1 INTO $v.ipolicy,$v.ibig_branch;
             }
         }
         else
         {
             $FETCH build_acursor3 INTO $v.ipolicy,$v.ibig_branch;
         }
         printf("{0020}:in fatch[%s]\n",v.ipolicy);
         if(SQLCODE == SQLNOTFOUND) break;

         if(option[0]=='1') /*�O��*/
         {
             if(strncmp(v.ibig_branch,"TSC",3)==0)
             {   /*�ثe�S����*/
                 $DECLARE build_acursor CURSOR FOR
                   SELECT a.ipolicy,a.irelative_ply,
                          to_char(b.dissue,'%Y')::integer - 1911 || '/' || to_char(b.dissue,'%m'),
                          a.ipro_year,a.ibrand,
                          a.dply_begin,a.dply_end,a.dendorse,a.ibatch_no,
                          b.nbrand_abbr,a.icar_type,b.ncar_abbr,b.iengine,b.itag,
                          b.pdmg_align,b.plia_align,b.pbrg_align,b.plia_acc,b.pdmg_acc,
                          b.nassured,b.nuser,a.ibig_office,a.ibig_branch,b.fcomp_24
                     FROM ply_relation a, policy b
                    WHERE b.ipolicy = $v.ipolicy
                      AND a.ipolicy = b.ipolicy
                      AND fcard_class = "2"
                    ORDER BY a.ibig_office,a.icar_type,3,a.ipolicy;
                 $OPEN build_acursor;
             }
             else
             {
                 $DECLARE build_acursor4 CURSOR FOR
                   SELECT a.ipolicy,a.irelative_ply,
                          to_char(b.dissue,'%Y')::integer - 1911 || '/' || to_char(b.dissue,'%m'),
                          a.ipro_year,a.ibrand,
                          a.dply_begin,a.dply_end,a.dendorse,a.ibatch_no,
                          b.nbrand_abbr,a.icar_type,b.ncar_abbr,b.iengine,b.itag,
                          b.pdmg_align,b.plia_align,b.pbrg_align,b.plia_acc,b.pdmg_acc,
                          b.nassured,b.nuser,a.ibig_office,a.ibig_branch,b.fcomp_24
                     FROM ply_relation a, policy b
                    WHERE b.ipolicy = $v.ipolicy
                      AND a.ipolicy=b.ipolicy
                      AND fcard_class = "2"
                    ORDER BY a.ipolicy;
                 $OPEN build_acursor4;
                        /*�O�渹�B���p�O�渹�B�o�Ӧ~��B�s�y����B�t�P�����N���A
                          �t�P�C�L�W�١B���������N���B���ئC�L�W�١B�������X�B�P�Ӹ��X�A
                          �h�������u�ݡB�h���d���u�ݡB�h���ѵs�u�ݡB���d�ߴګY�ơB����ߴګY�ơA
                          �Q�O�I�H�B�ϥΤH�B������~�ҡB���t�B�j��s�v�I */
             }
         }
         else
         {   /*��O��*/
             if(strncmp(v.ibig_branch,"TSC",3)==0)
             {   /*�ثe�S����*/
                 $DECLARE build_acursor2 CURSOR FOR
                   SELECT ipolicy, irelative_ply, 
                          to_char(dissue,'%Y')::integer - 1911 || '/' || to_char(dissue,'%m'), 
                          ipro_year, ibrand,
                          dply_begin,dply_end,' ',' ',
                          nbrand_abbr,icar_type, ncar_type, iengine, itag,
                          pdmg_align, plia_align, pbrg_align, plia_acc, pdmg_acc,
                          nassured,nuser,ibig_office,ibig_branch
                     FROM policy_302
                    WHERE ipolicy =$v.ipolicy
                      AND YEAR(dply_begin)=$pa.plyyr
                      AND MONTH(dply_begin)=$pa.plymth
                      AND fcard_class = "2"
                    ORDER BY ibig_office,icar_type,3,ipolicy;
                 $OPEN build_acursor2;
             }
             else
             {
                 $DECLARE build_acursor5 CURSOR FOR
                   SELECT ipolicy, irelative_ply, 
                          to_char(dissue,'%Y')::integer - 1911 || '/' || to_char(dissue,'%m'), 
                          ipro_year, ibrand,
                          dply_begin,dply_end,' ',' ',
                          nbrand_abbr,icar_type, ncar_type, iengine, itag,
                          pdmg_align, plia_align, pbrg_align, plia_acc, pdmg_acc,
                          nassured,nuser,ibig_office,ibig_branch
                     FROM policy_302
                    WHERE ipolicy =$v.ipolicy
                      AND YEAR(dply_begin)=$pa.plyyr
                      AND MONTH(dply_begin)=$pa.plymth
                      AND fcard_class = "2"
                    ORDER BY ipolicy;
                    $OPEN build_acursor5;
             }
         }

         while(1)
         {
             if(option[0]=='1')
             {
                 if(strncmp(v.ibig_branch,"TSC",3)==0)
                 {
                     $FETCH build_acursor INTO $v.ipolicy, $v.ire_ply, $v.iinssue_ym,
                                               $v.ipro_year, $v.ibrand,
                                               $v.dply_begin, $v.dply_end, $v.dendorse, $v.ibatch_no,
                                               $v.nbrand_abbr, $v.icar_type, $v.ncar_abbr,
                                               $v.iengine, $v.itag,
                                               $v.pdmg_align, $v.plia_align, $v.pbrg_align,
                                               $v.plia_acc, $v.pdmg_acc, $v.nassured, $v.nuser,
                                               $v.ibig_office, $v.ibig_branch, $v.fcomp_24;
                 }
                 else
                 {
                     $FETCH build_acursor4 INTO $v.ipolicy, $v.ire_ply, $v.iinssue_ym,
                                                $v.ipro_year, $v.ibrand,
                                                $v.dply_begin, $v.dply_end, $v.dendorse, $v.ibatch_no,
                                                $v.nbrand_abbr, $v.icar_type, $v.ncar_abbr,
                                                $v.iengine, $v.itag,
                                                $v.pdmg_align, $v.plia_align, $v.pbrg_align,
                                                $v.plia_acc, $v.pdmg_acc, $v.nassured, $v.nuser,
                                                $v.ibig_office, $v.ibig_branch, $v.fcomp_24;
                 }
             }
             else
             {
                 if(strncmp(v.ibig_branch,"TSC",3)==0)
                 {
                     $FETCH build_acursor2 INTO $v.ipolicy, $v.ire_ply, $v.iinssue_ym,
                                                $v.ipro_year, $v.ibrand,
                                                $v.dply_begin, $v.dply_end, $v.dendorse, $v.ibatch_no,
                                                $v.nbrand_abbr, $v.icar_type, $v.ncar_abbr,
                                                $v.iengine, $v.itag,
                                                $v.pdmg_align, $v.plia_align, $v.pbrg_align,
                                                $v.plia_acc, $v.pdmg_acc, $v.nassured, $v.nuser,
                                                $v.ibig_office, $v.ibig_branch;
                 }
                 else
                 {
                     $FETCH build_acursor5 INTO $v.ipolicy, $v.ire_ply, $v.iinssue_ym,
                                                $v.dply_begin, $v.dply_end, $v.dendorse, $v.ibatch_no,
                                                $v.ipro_year, $v.ibrand, $v.nbrand_abbr,
                                                $v.icar_type, $v.ncar_abbr,
                                                $v.iengine, $v.itag,
                                                $v.pdmg_align, $v.plia_align, $v.pbrg_align,
                                                $v.plia_acc, $v.pdmg_acc,$v.nassured,$v.nuser,
                                                $v.ibig_office,$v.ibig_branch;
                 }
             }

             printf("{0030}:in fatch[%d]\n",SQLCODE);
             if(SQLCODE == SQLNOTFOUND) break;

             /*copy�O�渹�e13�X*/
             strncpy(v.tmp_policy,v.ipolicy,13);
             /*copy�O�渹��4�X*/
             strncpy(mark,&v.ipolicy[13],4);
             v.tmp_policy[13]='\0';
             mark[4]='\0';
             printf("mark[%s]\n",mark);

             if(option[0]=='1')  /*�O��*/
                 $SELECT COUNT(*) INTO $big_cnt FROM policy
                   WHERE ipolicy[1,13]=$v.tmp_policy;
             else
                 $SELECT COUNT(*) INTO $big_cnt FROM policy_302
                   WHERE ipolicy[1,13]=$v.tmp_policy;

             printf("big_cnt[%d]\n",big_cnt);

             flag_exist1++;

             if(flag_exist1==1)
             {
                 ibig_branch[0]='\0';
                 ply[0]='\0';

                 if(v.ibig_branch[0]==' ' || v.ibig_branch[0]=='\0')
                 strcpy(v.ibig_branch,"####");
             }

             printf("ibig_branch[%s],v.ibig_branch[%s]\n",ibig_branch,v.ibig_branch);

             strcpy(ibig_branch, trim(ibig_branch));
             strcpy(v.ibig_branch, trim(v.ibig_branch));
             
             /* if(strcmp(trim(ibig_branch),trim(v.ibig_branch))!=0 || strcmp(ply,v.tmp_policy)!=0) */
             if(strcmp(ibig_branch,v.ibig_branch)!=0 || strcmp(ply,v.tmp_policy)!=0)
             {
                 if(flag_exist1!=1)
                 {
                     printf("flag_exist1[%d]\n",flag_exist1);
                     rgu_put_body_string(10, itoa(car_count), 1);

                     rfmtlong(premium0105,"#,###,##&",str);
                     rgu_put_body_string(10, ltrim(str), 1);

                     rfmtlong(premium11,"#,###,##&",str);
                     rgu_put_body_string(10, ltrim(str), 1);

                     rfmtlong(premium31,"#,###,##&",str);
                     rgu_put_body_string(10, ltrim(str), 1);

                     rfmtlong(premium32,"#,###,##&",str);
                     rgu_put_body_string(10, ltrim(str), 1);

                     rfmtlong(premium5153,"#,###,##&",str);
                     rgu_put_body_string(10, ltrim(str), 1);

                     rfmtlong(premium52,"#,###,##&",str);
                     rgu_put_body_string(10, ltrim(str), 1);

                     rfmtlong(premium_oth,"#,###,##&",str);
                     rgu_put_body_string(10, ltrim(str), 1);

                     rfmtlong(iTotmprem,"#,###,##&",str);
                     rgu_put_body_string(10, ltrim(str), 2);

                     rfmtlong(iTotmins_premium,"#,###,##&",str);
                     rgu_put_body_string(10, ltrim(str), 2);

                     rfmtlong(iTotcomp_premium,"#,###,##&",str);
                     rgu_put_body_string(10, ltrim(str), 2);
                     rgu_put_body(10);
                     max_count++;

                     mprem_tot += iTotmprem;
                     mins_premium_tot += iTotmins_premium;
                     comp_premium_tot += iTotcomp_premium;
                     if(strcmp(ply,v.tmp_policy)!=0)
                     {
                         rfmtlong(mprem_tot,"#,###,##&",str);
                         rgu_put_body_string(13, ltrim(str), 2);

                         rfmtlong(mins_premium_tot,"#,###,##&",str);
                         rgu_put_body_string(13, ltrim(str), 2);

                         rfmtlong(comp_premium_tot,"#,###,##&",str);
                         rgu_put_body_string(13, ltrim(str), 2);
                         rgu_put_body(13);

                         max_count++;
                         mprem_tot=0;
                         mins_premium_tot=0;
                         comp_premium_tot=0;
                     }
                     rgu_put_body(12);
                     max_count++;
                     rgu_put_body(11);
                     max_count++;
                     rgu_put_body(7);
                     car_count=0;
                     premium0105=0;
                     premium11=0;
                     premium31=0;
                     premium32=0;
                     premium5153=0;
                     premium52=0;
                     premium_oth=0;
                     iTotmprem=0;
                     iTotmins_premium=0;
                     iTotcomp_premium=0;
                     max_count++;
                 }
                 ibig_branch[0] = '\0';

                 if(option[0]=='1')
                 {
                     $SELECT ibig_branch INTO $ibig_branch
                        FROM ply_relation
                       WHERE ipolicy = $v.ipolicy;
                     if (SQLCODE == SQLNOTFOUND)
                     {
                         EWRITE(userid, SQLCODE, "read ibig_branch-1 no data found");
                         return -1;
                     }
                 }
                 else
                 {
                     $SELECT ibig_branch INTO $ibig_branch
                        FROM policy_302
                       WHERE ipolicy = $v.ipolicy;
                     if (SQLCODE == SQLNOTFOUND)
                     {
                         EWRITE(userid, SQLCODE, "read ibig_branch-2 no data found");
                         return -1;
                     }
                 }

                 strcpy(ply,v.tmp_policy);

                 /*�o�q�ثe�S����*/
                 $SELECT nname INTO $nname
                    FROM ca_big_office
                   WHERE ibig_comp=$ibig_branch
                     AND ibig_branch=$ibig_branch
                     AND ibig_office=$v.ibig_office;
                 if (SQLCODE == SQLNOTFOUND) nname[0]='\0';

                 printf("ibig_branch[%s],ibig_office[%s],nname[%s]\n",ibig_branch,v.ibig_office,nname);
                 strcpy(t_policy,"17");
                 strcat(t_policy,v.tmp_policy);
                 rgu_put_body_string(1, t_policy);      /*1*�O�渹�X*/
                 rgu_put_body_string(1, v.nassured);    /*1*�Q�O�I�H*/
                 rgu_put_body(1);
                 max_count++;
                 rgu_put_body_string(2, ibig_branch);
                 rgu_put_body_string(2, v.ibig_office);
                 rgu_put_body_string(2, nname);
                 rgu_put_body(2);
                 max_count++;
             }

             if(option[0]=='1')
             {
                 $DECLARE build_bcursor CURSOR FOR
                   SELECT iins_type, minjured_cover, mdeath_cover, mdamage_cover,
                          mdeduct, mins_premium, mprem
                     FROM ply_ins_type
                    WHERE ipolicy = $v.ipolicy;

                 iSubmins_premium=0;
                 iSubmprem=0;
                 flag_exist2=0;

                 $OPEN build_bcursor;
             }
             else
             {
                 $DECLARE build_bcursor1 CURSOR for
                   SELECT iins_type, minjured_cover, mdeath_cover, mdamage_cover,
                          mdeduct, mins_premium,mprem
                     FROM ply_ins_type_302
                    WHERE ipolicy = $v.ipolicy;

                 iSubmins_premium=0;
                 iSubmprem=0;
                 flag_exist2=0;

                 $OPEN build_bcursor1;
             }

             while(1)
             {
                 /*---initialize---*/
                 v1.iins_type[0]='\0';
                 v1.mdamage_cover = v1.mdeduct = v1.mins_premium = 0;
                 v1.minjured_cover = v1.mdeath_cover = 0;
                 if(option[0]=='1')
                 {
                     $FETCH build_bcursor INTO $v1.iins_type, $v1.minjured_cover,
                                               $v1.mdeath_cover, $v1.mdamage_cover,
                                               $v1.mdeduct, $v1.mins_premium,$v1.mprem;
                 }
                 else
                 {
                     $FETCH build_bcursor1 INTO $v1.iins_type, $v1.minjured_cover,
                                                $v1.mdeath_cover, $v1.mdamage_cover,
                                                $v1.mdeduct, $v1.mins_premium,$v1.mprem;
                 }
                 if (SQLCODE == SQLNOTFOUND) break;
                 else flag_exist2++;

                 printf("ipolicy[%s],ipro_year[%s],iinssue_ym[%s],ibrand[%s],nbrand_abbr[%s]\n",
                         v.ipolicy,v.ipro_year,v.iinssue_ym,v.ibrand,v.nbrand_abbr);

                 if (flag_exist2==1)
                 {
                     rgu_put_body_string(3, mark, 2);         /*3*�Ъ����X*/
                     rgu_put_body_string(3, v.ipro_year, 2);  /*3*�s�y�~��*/
                     rgu_put_body_string(3, v.iinssue_ym, 2); /*3*�o�Ӧ~��*/
                     strcpy(brand_str,v.ibrand);
                     strcat(brand_str,"  ");
                     strcat(brand_str,v.nbrand_abbr);
                     brand_str[20]='\0';
                     rgu_put_body_string(3, brand_str, 1);    /*3*�t�P����*/
                     strcpy(car_str,v.icar_type);

                     $SELECT ncode
                        INTO $v.ncar_abbr
                        FROM car_type
                       WHERE icode = $v.icar_type
                         AND  fclass = '1';
                     if(SQLCODE == SQLNOTFOUND)

                     strcpy(v.ncar_abbr," ");
                     strcat(car_str,"  ");
                     strcat(car_str,v.ncar_abbr);
                     car_str[20]='\0';
                     rgu_put_body_string(3, car_str, 1);      /*3*��������*/
                     rgu_put_body_string(3, v.iengine,1);     /*3*�������X*/
                     rgu_put_body_string(3, v.itag, 1);       /*3*�P�Ӹ��X*/
                     rgu_put_body_string(3, v.ibatch_no, 1);  /*3*�帹*/
                     strcpy(den_str,cm_from_infdate_100(v.dendorse));
                     rgu_put_body_string(3, den_str, 1);   /*3*�̫�@�������*/
                 }
                 else
                 {
                     rgu_put_body_string(3, "    ", 2);                 /*3*�Ъ����X*/
                     rgu_put_body_string(3, "     ", 2);                /*3*�s�y�~��*/
                     rgu_put_body_string(3, "     ", 2);                /*3*�o�Ӧ~��*/
                     rgu_put_body_string(3, "                    ", 2); /*3*�t�P����*/
                     rgu_put_body_string(3, "          ", 2);           /*3*��������*/
                     rgu_put_body_string(3, "                  ", 2);   /*3*�������X*/
                     rgu_put_body_string(3, "        ", 2);             /*3*�P�Ӹ��X*/
                     rgu_put_body_string(3, "   ", 2);                  /*3*�帹*/
                     rgu_put_body_string(3, "          ", 1);           /*3*�̫�@�������*/
                 }
                 
                 strcpy(v1.iins_type, trim(v1.iins_type));
                 printf("�������� v1.iins_type=[%s] ������������\n",v1.iins_type);
                 rgu_put_body_string(3, v1.iins_type, 2);               /*3*�I�O*/

                 rfmtlong(v1.minjured_cover,"###,###,##&",str);
                 rgu_put_body_string(3,ltrim(str), 2);                  /*3*���*/

                 rfmtlong(v1.mdeath_cover,"###,###,##&",str);
                 rgu_put_body_string(3,rtrim(str), 2);                  /*3*���`*/

                 rfmtlong(v1.mdamage_cover,"###,###,##&",str);
                 rgu_put_body_string(3,rtrim(str), 2);                  /*3*�`�B*/

                 if(strcmp(v1.iins_type,"01")== 0 || strcmp(v1.iins_type,"05")==0 || strcmp(v1.iins_type,"08")== 0 || strcmp(v1.iins_type,"09")==0)
                 {
                     printf("01v1.iins_type->[%s] v1.mdeduct->[%d]\n",v1.iins_type, v1.mdeduct);
                     prn_deduct[0]=0;
                     sprintf_s(str_deduct, sizeof str_deduct,"%d",v1.mdeduct);
                     $SELECT prn_deduct
                        INTO $prn_deduct
                        FROM ca_dmg_mdeduct
                       WHERE icar_type=$v.icar_type
                         AND ideduct=$str_deduct;
                     printf("prn_deduct-->[%s]\n",prn_deduct);
                     rgu_put_body_string(3, prn_deduct, 2);
                 }
                 else if(strcmp(v1.iins_type,"11")==0)
                 {
                     rfmtlong(v1.mdeduct,"##&",str);
                     strcat(str,"%");
                     rgu_put_body_string(3, str, 2);
                 }
                 else if(strcmp(v1.iins_type,"24")==0)
                 {
                     if (strcmp(trim(v.fcomp_24),"Y")==0)
                     {
                          rgu_put_body_string(3,"(�[�j)",2);
                     }
                     else
                     {
                          rgu_put_body_string(3," ",2);
                     }
                 }
                 else
                     rgu_put_body_string(3," ",2);

                 switch (atoi(v1.iins_type))
                 {
                     case 1: case 5: case 8: case 9:
                         premium0105 +=v1.mins_premium;
                         break;
                     case 11:
                         premium11 +=v1.mins_premium;
                         break;
                     case 31:
                         premium31 +=v1.mins_premium;
                         break;
                     case 32:
                         premium32 +=v1.mins_premium;
                         break;
                     case 51: case 53:
                         premium5153 +=v1.mins_premium;
                         break;
                     case 52:
                         premium52 +=v1.mins_premium;
                         break;
                     default:
                         premium_oth +=v1.mins_premium;
                         break;
                 }

                 rfmtlong(v1.mprem,"#,###,##&",str);
                 rgu_put_body_string(3,str, 2);                         /*�u�ݫe�O�O*/

                 rfmtlong(v1.mins_premium,"#,###,##&",str);
                 rgu_put_body_string(3,rtrim(str), 2);                  /*�u�ݫ�O�O*/
                 rgu_put_body(3);
                 max_count++;

                 iSubmins_premium += v1.mins_premium;
                 iSubmprem += v1.mprem;

             }/*End While*/

             if(option[0]=='1')
             {
                 $CLOSE build_bcursor;
                 $FREE build_bcursor;
             }
             else
             {
                 $CLOSE build_bcursor1;
                 $FREE build_bcursor1;
             }

             printf("relation_ply[%s]\n",v.ire_ply);

             comp=1;
             printf("comp---->%s\n",v.ire_ply);
             if(option[0]=='1')
             {
                 $SELECT a.icard,dply_begin,dply_end,b.plia_acc
                    INTO $ire_card,$ply_beg,$ply_end,$comp_acc
                    FROM ply_relation  a,policy b
                   WHERE a.ipolicy=b.ipolicy AND a.ipolicy=$v.ire_ply;
                 printf("ire_card:[%s],ply_beg:[%s],ply_end:[%s] \n",ire_card,ply_beg,ply_end);
                 printf("ire_ply:[%s] \n",v.ire_ply);
                 printf("comp_acc:[%f] \n",comp_acc);
             }
             else
             {
                 $SELECT icard,dply_begin,dply_end,plia_acc
                    INTO $ire_card,$ply_beg,$ply_end,$comp_acc
                    FROM policy_302
                   WHERE ipolicy=$v.ire_ply;
                 printf("32_ire_card:[%s],ply_beg:[%s],ply_end:[%s] \n",ire_card,ply_beg,ply_end);
                 printf("32_ire_ply:[%s] \n",v.ire_ply);
                 printf("32_comp_acc:[%f] \n",comp_acc);
             }
             printf("plia_acc----->%f\n",comp_acc);
             strcpy(ire_card1,"17");
             if(SQLCODE == SQLNOTFOUND)
             {
                 strcpy(ire_card,"          ");
                 strcpy(ply_beg,"          ");
                 strcpy(ply_end,"          ");
                 comp_acc=0;
                 comp=0;
                 ire_card1[0] = '\0';
             }
             strcat(ire_card1,ire_card);

             if(option[0]=='1')
             {
                 $SELECT mins_premium
                    INTO $comp_premium
                    FROM ply_ins_type
                   WHERE ipolicy=$v.ire_ply;
                 printf("v.ire_ply:[%s] \n",v.ire_ply);
             }
             else
             {
                 $SELECT mins_premium
                    INTO $comp_premium
                    FROM ply_ins_type_302
                   WHERE ipolicy=$v.ire_ply;
                 printf("v.ire_ply:[%s] \n",v.ire_ply);
             }
             if(SQLCODE == SQLNOTFOUND)
                 comp_premium=0;

             if (flag_exist2 != 0)
             {     /*���I�ة���*/
                 rgu_put_body(8);
                 max_count += 1;

                 /*--------sub total--------*/
                 rfmtlong(iSubmprem,"#,###,##&",str);
                 rgu_put_body_string(4, str, 2);                        /*4*�h���u�ݫe�O�O*/
                 rfmtlong(iSubmins_premium,"#,###,##&",str);
                 rgu_put_body_string(4, str, 2);                        /*4*�h���u�ݫ�O�O*/
                 printf("comp_premium[%d]\n",comp_premium);
                 rfmtlong(comp_premium,"#,###,##&",str);
                 rgu_put_body_string(4, str, 2);                        /*4*�j��O�O*/
                 rgu_put_body(4);
                 max_count += 1;

                 str[0]='\0';
                 if(comp==1)
                 {
                     strcpy(str,cm_from_infdate_100(ply_beg));
                     strcat(str," - ");
                     strcat(str,cm_from_infdate_100(ply_end));
                 }
                 printf("str[%s]\n",str);
                 rgu_put_body_string(9, str, 2);                        /*9*�j���I�_�W���*/

                 strcpy(str,cm_from_infdate_100(v.dply_begin));
                 strcat(str," - ");
                 strcat(str,cm_from_infdate_100(v.dply_end));
                 rgu_put_body_string(9, str, 2);                        /*9*���N�I�_�W���*/

                 if(v.nuser[0]=='\0' || v.nuser[0]==' ')
                     rgu_put_body_string(9, "               ", 1);      /*9*�ϥΤH*/
                 else
                 {
                     strcpy(str,"�ϥΤH:");
                     strcat(str,v.nuser);
                     rgu_put_body_string(9, str, 1);                    /*9*�ϥΤH*/
                 }
                 rgu_put_body(9);
                 max_count += 1;

                 rgu_put_body_string(5, ire_card1, 2);                  /*5*�j���Ҹ��X*/
                 printf("pdmg->[%d]pbrg->[%d]plia->[%d]\n",v.pdmg_align,v.pbrg_align,
                                                           v.plia_align);

                 if(v.pdmg_align==0)
                     rgu_put_body_string(5, "0", 2);                    /*5*�h�������u��*/
                 else
                 {
                     rfmtlong(v.pdmg_align,"##",str);
                     rgu_put_body_string(5, str, 2);                    /*5*�h�������u��*/
                 }
                 printf("pdmg->[%d]pbrg->[%d]plia->[%d]\n",v.pdmg_align,v.pbrg_align,
                                           v.plia_align);
                 if(v.pbrg_align==0)
                     rgu_put_body_string(5, "0", 2);                    /*5*�h���ѵs�u��*/
                 else
                 {
                     rfmtlong(v.pbrg_align,"##",str);
                     rgu_put_body_string(5, str, 2);                    /*5*�h���ѵs�u��*/
                 }
                 printf("pdmg->[%d]pbrg->[%d]plia->[%d]\n",v.pdmg_align,v.pbrg_align,
                                           v.plia_align);
                 if(v.plia_align==0)
                     rgu_put_body_string(5, "0", 2);                    /*5*�h���d���u��*/
                 else
                 {
                     rfmtlong(v.plia_align,"##",str);
                     rgu_put_body_string(5, str, 2);                    /*5*�h���d���u��*/
                 }

                 printf("pdmg-->[%f] plia--->[%f] comp-->[%f]\n",v.pdmg_acc,v.plia_acc
                                                  ,comp_acc);
                 if(v.pdmg_acc==0.0)
                     rgu_put_body_string(5, "0", 2);                    /*5*����ߴګY��*/
                 else
                 {
                     rfmtdouble(v.pdmg_acc,"-&&.&&",str);
                     rgu_put_body_string(5, str,2);                     /*5*����ߴګY��*/
                 }
                 printf("pdmg-->[%f] plia--->[%f] comp-->[%f]\n",v.pdmg_acc,v.plia_acc
                                                ,comp_acc);
                 if(v.plia_acc==0.0)
                     rgu_put_body_string(5, "0", 2);                    /*5*���d�ߴګY��*/
                 else
                 {
                     rfmtdouble(v.plia_acc,"-&&.&&",str);
                     rgu_put_body_string(5, str,2);                     /*5*���d�ߴګY��*/
                 }
                 printf("pdmg-->[%f] plia--->[%f] comp-->[%f]\n",v.pdmg_acc,v.plia_acc
                                                ,comp_acc);
                 if(comp_acc==0.0)
                     rgu_put_body_string(5, "0", 2);                    /*5*�j��ߴګY��*/
                 else
                 {
                     rfmtdouble(comp_acc,"-&&.&&",str);
                     rgu_put_body_string(5, str,2);                     /*5*�j��ߴګY��*/
                 }

                 rgu_put_body(5);
                 rgu_put_body(6);
                 car_count++;
                 max_count += 2;
                 iTotmins_premium += iSubmins_premium;
                 iTotmprem += iSubmprem;
                 iTotcomp_premium +=comp_premium;
             }/*END if (flag_exist2 != 0)*/
         }
     }

     if(option[0]=='1')
     {
         if (type[0]=='a')
         {
             $CLOSE build_acursor1;
             $FREE build_acursor1;
         }
         else if (type[0]=='b')
         {
             $CLOSE build_acursor1_1;
             $FREE build_acursor1_1;
         }

         if(flag_exist1==0)
         {
             EWRITE(userid, M_CM_NOT_FOUND, "");
             return -1;
         }

         if(strncmp(v.ibig_branch,"TSC",3)==0)
         {
             $CLOSE build_acursor;
             $FREE build_acursor;
         }
         else
         {
             $CLOSE build_acursor4;
             $FREE build_acursor4;
         }
     }
     else
     {
         $CLOSE build_acursor3;
         $FREE build_acursor3;

         if(flag_exist1==0)
         {
             EWRITE(userid, M_CM_NOT_FOUND, "");
             return -1;
         }

         if(strncmp(v.ibig_branch,"TSC",3)==0)
         {
             $CLOSE build_acursor2;
             $FREE build_acursor2;
         }
         else
         {
             $CLOSE build_acursor5;
             $FREE build_acursor5;
         }
     }

     if(flag_exist1==0)
     {
         EWRITE(userid, M_CM_NOT_FOUND, "data not found");
         return -1;
     }
     if(flag_exist1!=0)
     {
         printf("flag_exist1[%d]\n",flag_exist1);
         rgu_put_body_string(10, itoa(car_count), 1);                   /*10*�`�p ����*/
         rfmtlong(premium0105,"#,###,##&",str);
         rgu_put_body_string(10, ltrim(str), 1);                        /*10*�`�p �I�O01/05/08/09*/
         rfmtlong(premium11,"#,###,##&",str);
         rgu_put_body_string(10, ltrim(str), 1);                        /*10*�`�p �I�O11*/
         rfmtlong(premium31,"#,###,##&",str);
         rgu_put_body_string(10, ltrim(str), 1);                        /*10*�`�p �I�O31*/
         rfmtlong(premium32,"#,###,##&",str);
         rgu_put_body_string(10, ltrim(str), 1);                        /*10*�`�p �I�O32*/
         rfmtlong(premium5153,"#,###,##&",str);
         rgu_put_body_string(10, ltrim(str), 1);                        /*10*�`�p �I�O51/53*/
         rfmtlong(premium52,"#,###,##&",str);
         rgu_put_body_string(10, ltrim(str), 1);                        /*10*�`�p �I�O52*/
         rfmtlong(premium_oth,"#,###,##&",str);
         rgu_put_body_string(10, ltrim(str), 1);                        /*10*�`�p �䥦�I*/
         rfmtlong(iTotmprem,"#,###,##&",str);
         rgu_put_body_string(10, ltrim(str), 2);                        /*10*�`�p �h���u�ݫe�O�O*/
         rfmtlong(iTotmins_premium,"#,###,##&",str);
         rgu_put_body_string(10, ltrim(str), 2);                        /*10*�`�p �h���u�ݫ�O�O*/
         rfmtlong(iTotcomp_premium,"#,###,##&",str);
         rgu_put_body_string(10, ltrim(str), 2);                        /*10*�`�p �j��O�O*/
         rgu_put_body(10);
         max_count++;

         mprem_tot += iTotmprem;
         mins_premium_tot += iTotmins_premium;
         comp_premium_tot += iTotcomp_premium;
         rfmtlong(mprem_tot,"#,###,##&",str);
         mprem_tot=0;
         mins_premium_tot=0;
         comp_premium_tot=0;

         rgu_put_body(12);
         max_count++;
         rgu_put_body(11);
         max_count++;
         car_count=0;
         premium0105=0;
         premium11=0;
         premium31=0;
         premium32=0;
         premium5153=0;
         premium52=0;
         premium_oth=0;
         iTotmprem=0;
         iTotmins_premium=0;
         iTotcomp_premium=0;
     }
     rgu_finish_report();

     return 0;

errexit:
    printf( "SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return -1;
} 

/***************************************************************/
