/*-------------------------------------------------------------------
 * Program: ca_rpt_renew.ec
 * Date   : 03/20/1997
 *-------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#include "is_def.h"
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
$include "ca3xxlib.h";
$include sqlca;
$include sqltypes;
void Put_Other_Ins_Cost();    /* �I�ة��Ӹ�� in ca3xxlib.ec */
void Put_Ins_Cost();          /* in ca3xxlib.ec */
void Put_Ins_Cost_1();        /* in ca3xxlib.ec */
void Put_Other_Ins_Cost_1();  /* in ca3xxlib.ec */

/*****************************************************************/
$char stm3[25] ,nname[41],nchi_full[21],iply_area[3],ibranch[3],scar_price[11];
$char last_policy[21], nproject[21], nchi_full_tmp[31];
$char aassured_zip[6],irel_card[18],note1[18],splia_acc[5],spdmg_acc[5];
$long LHdMdeduct, LHdMprem;
$char stmt[2048];
char LHsMprem[11], LHsdamage_cover[11],LHsMdeduct[11];
$char ch_deduct[13];
$char LHsNname[11];
$char tmp_ply[20];
char  remark[12],dmg_flag,lia_flag,frelative_comp;
char  dmg_flag_p;
$long bef_premium1,bef_premium2;
$long deduct_t3,prem_t3;
$long deduct;
$char remark1[242], remark4[242];
$char ibig_sales[11],nbig_sales[16];
$char localdb1[30];
$char sdbname[3];
$int  iMdiscount,iTot_mpay;
$char icorps[11],ncorps[31], sNequipment[31];
$int  rela_cnt;
$char sFassured[2];
$char s_ilicense[13];
char  new_rate;
$double  pdiscount_d;
$char pdiscount_s[20];
$char ibig_comp_s[2];
$char lia_class[2];
$int  dmg_acc_1st,dmg_acc_2nd,dmg_acc_3rd;
$int  bqdmg[3];
$char last_ply_tmp[21];
$int  itp;
$char cdmg[5][3];
$int  iyymm;
$char syymm[5];
$char   tphone_con[21],imovephone[21],iemail[51];
$long qday_01,qday_11;
$long qday;

int   max_count=0,ben_len=0;
$int   rec_count_1;
$double plia_acc_1,plia_acc_2,pdmg_acc_2;
char *get_car_full_db();
char *split_yymm();

/*****************************************************************/
int ca_rpt_renew(db,fbigcomp,ply,fmulti,prt,rec_cnt)
$char *db, *fbigcomp, *ply, *fmulti, *prt;
$int  *rec_cnt;
{
    $char  stmt_buf[2000];
    $short fprem,id;
    $char  tmp_irelative[13],last_ply[18],inext_ply[20];
    char   ply1_date[11], ply2_date[11];
    char   ply1_yr[5], ply2_yr[5];
    char   ply1_mth[3], ply2_mth[3];
    $char  dply_begin_c[11];

    $WHENEVER SQLERROR GOTO ca_rpt_renew_err;

    strcpy(sdbname,get_car_full_db(ply));
    strcpy(localdb1,get_full_dbname(sdbname));

    strcpy(last_policy, trim(ply));

    printf("----into ca_rpt_renew() fbigcomp[%s] fmulti[%s]\n",fbigcomp,fmulti);
    printf("----into ca_rpt_renew() db[%s] prt[%s]\n",db,prt);
    rec_count_1=*rec_cnt;
 
    printf("1.### *rec_cnt[%d]\n",*rec_cnt);

    Icurr=Ifirst=Ilast=NULL;    /* set INS_TYPE pointer to NULL */

    printf("ply[%s]\n",ply);

    strncpy(tmp_ply,ply,CAR_POLICY_LEN);
    tmp_ply[CAR_POLICY_LEN]='\0';

    printf("-------into ca_rpt_renew() tmp_ply[%s]\n",tmp_ply);
    
    
    $CREATE TEMP TABLE NO_NASS
    (
       iofficer  char(10)
    )
    WITH NO LOG;
   
    $INSERT INTO NO_NASS VALUES ("Y61024YS1");
    $INSERT INTO NO_NASS VALUES ("Y61024YS2");
    $INSERT INTO NO_NASS VALUES ("Y61024YS3");
    $INSERT INTO NO_NASS VALUES ("Y61024YS4");
    $INSERT INTO NO_NASS VALUES ("Y61024YS6");
    $INSERT INTO NO_NASS VALUES ("Y61024YC");
    $INSERT INTO NO_NASS VALUES ("Y61024YS2");
    $INSERT INTO NO_NASS VALUES ("711762Q3");
    $INSERT INTO NO_NASS VALUES ("Z61021");
    $INSERT INTO NO_NASS VALUES ("Z6102101");
    $INSERT INTO NO_NASS VALUES ("Z6102102");
    $INSERT INTO NO_NASS VALUES ("Z6102103");
    $INSERT INTO NO_NASS VALUES ("Z6102104");
    $INSERT INTO NO_NASS VALUES ("Z6102105");
    $INSERT INTO NO_NASS VALUES ("Z61021BC");
   
    sprintf(stmt,"SELECT iofficer FROM NO_NASS where iofficer = ?");
    $PREPARE get_no_nass FROM $stmt;
    
    /*---�C�L��O��---*/
    /*  if (prt[0]=='2')  */
    {
        /*******�N�q�H�Y�ƲM��*******/
        /**frelative_comp �ΨӧP�_�O�_�O���N�ɤS�O�j��***/
        plia_acc_1 = plia_acc_2 = pdmg_acc_2 = 0,frelative_comp='N';
        sprintf(stmt_buf,"SELECT %s %s %s %s %s %s %s %s %s %s %s %s FROM %s %s",
                "ipolicy,icard,fcard_class,irelative_ply,qply_period,",
                "dply_begin,dply_end,nassured,ilicense,ibirth,fsex,",
                "fmarriage,nuser,nbenef,aassured,itel,iissue_ym,",
                "ipro_year,ibrand,nbrand_abbr,icar_type,ncar_type,",
                "qcylinder,iengine,ibody,itag,mcar_price,pdmg_align,",
                "pbrg_align,plia_align,qpt,fpt,idmg_rate,ibrg_rate,",
                "psex_age,nvl(plia_acc,'0'),nvl(pdmg_acc,'0'),",
                "fcar_class,dedr_begin,",
                "iofficer,ileader,ibig_office,ibig_sales,iply_area,aassured_zip,\
                 irel_card,nchi_full,",
                "trim(remark1)||remark2,ibig_nname,nname,mdiscount,tot_mpay,icorps,",
                "ncorps,ibig_comp,pdiscount,fcomp_24,dmg_ac_cnt1,dmg_ac_cnt2,dmg_ac_cnt3,",
                "dply_begin,tphone_con,imovephone,nproject,trim(remark4)||remark5, nequipment ",
                "policy_302 ",
                "WHERE ipolicy = ? ");
        $PREPARE CUR_ply_302_1 FROM $stmt_buf;
        $DECLARE CA302_ply_302_1 CURSOR FOR CUR_ply_302_1;
        printf("stmt_buf[%s]\n",stmt_buf);
        $OPEN CA302_ply_302_1 USING $ply;
        while (1)
        {
             InitData1();
             note1[0] = '\0';

             $FETCH CA302_ply_302_1
              INTO $last_ply,$last_card,$fcard_class,$irelative_ply,
                   $qply_period,$dply_begin,$dply_end,$assuredn,$license,
                   $birth,$sex,$marriage,$user,$benefn,$assureda,$tel,
                   $issue_ym,$pro_year,$brandi,$brandn,$car_typei,$car_typen,
                   $cylinder,$engine,$body,$tagnum,$scar_price,
                   $dmg_align,$brg_align,$lia_align,$qpt,$fpt,
                   $idmg_rate,$ibrg_rate,$psex_age_1,$splia_acc,$spdmg_acc,
                   $fcar_class,$dedr_begin,$iofficer,$ileader,$big_office,$big_sales,
                   $iply_area,$aassured_zip,$irel_card,$nchi_full,$remark1,
                   $LHsNname,$nname,$iMdiscount,$iTot_mpay,$icorps,$ncorps,$ibig_comp_s,
                   $pdiscount_d,$fcomp_24,$cdmg[0],$cdmg[1],$cdmg[2],$dply_begin_c,
                   $tphone_con,$imovephone,$nproject,$remark4, $sNequipment;
             if (SQLCODE != 0) break;

             strcpy(last_ply_tmp,last_ply);
             printf("dply_begin[%s]\n",dply_begin_c);
             strcpy(syymm,split_yymm(dply_begin_c));
             printf("syymm[%s]\n",syymm);
             iyymm = atoi(syymm);

             $SELECT icode
                INTO $frate
                FROM ca_rate_renew  /* ��O�O�v�N�� */
               WHERE iym_bgn <= $iyymm
                 AND iym_end >= $iyymm
                 AND fcard_class = $fcard_class;

             $EXECUTE get_no_nass USING $iofficer;
             printf("get-No-nass SQLCODE =[%d]\n", SQLCODE );
             
             if(SQLCODE == SQLNOTFOUND){ /** nothing happen**/    }
             else
             {
       	         strcpy( engine, "********************");
       	         strcpy( license,"**********");
             }
             
             /***************
             $SELECT nname[1,10]
                INTO $LHsNname
                FROM ca_big_office
               WHERE fclass = '2'
                 and ibig_comp = $big_sales;

             if(SQLCODE == SQLNOTFOUND)
             {
                  strcpy(LHsNname," ");
             }
             ***************/
             tagnum[8]='\0';
             tel[12]='\0';
             dmg_flag = 'N';
             dmg_flag_p = 'N';
             lia_flag = 'N';
             rstod(splia_acc,&plia_acc);
             rstod(spdmg_acc,&pdmg_acc);
             /**************
             $SELECT ibroker INTO $broker FROM  ply_relation WHERE ipolicy=$ply;
             $SELECT nname,ibranch   INTO $nname,$ibranch  FROM  officer
               WHERE  iofficer   =   $ileader ;
             **************/

             if(strlen(trim(nproject))>0)
             {
                sprintf(nchi_full_tmp,"%s%s%s","(",trim(nproject),")");
                strcpy(nchi_full, trim(nchi_full)); 
                strcat(nchi_full, trim(nchi_full_tmp));
             }
             
             printf("----  assuredn[%s],fcard_class[%s]\n",assuredn,fcard_class);
             printf(">>>>>last_ply[%s]\n",last_ply);

             sprintf(stmt, " SELECT fassured,lia_class,dmg_acc_1st,dmg_acc_2nd,dmg_acc_3rd    \
                               FROM %s:policy   \
                              WHERE ipolicy = '%s' ",localdb1,last_ply);
             $PREPARE xs_id FROM $stmt;
             $EXECUTE xs_id INTO $sFassured,$lia_class,$dmg_acc_1st,$dmg_acc_2nd,$dmg_acc_3rd;
             if (SQLCODE == SQLNOTFOUND) strcpy(sFassured," ");

             bqdmg[0] = dmg_acc_1st;
             bqdmg[1] = dmg_acc_2nd;
             bqdmg[2] = dmg_acc_3rd;

             if ((sFassured[0] == '1') ||
                 (sFassured[0] == '3') ||
                 (sFassured[0] == '5'))
                  strcpy(s_ilicense,license);
             else
                  strcpy(s_ilicense," ");

             /*---���p�O�檺�B�z---*/
             fprem=0;id=0;
             strcpy(remark," ");

             printf("---### before line 113 ###\n");
             if (fcard_class[0]=='2')       /*---���N--*/
             {
                   ply2_begin=dply_begin;
                   ply2_end=dply_end;
                   pdmg_acc_2 = pdmg_acc;
                   plia_acc_2 = plia_acc;

                   if (fmulti[0]=='0') /* �@��� */
                   {
                       printf("### in �@��� ####\n");
                       $SELECT --+INDEX (a pins32_idx_2)
                              SUM(mins_premium) INTO $premium2:id
                          FROM ply_ins_type_302 a
                         WHERE ipolicy=$last_ply;
                       printf("#### id=[%d],premium2[%d] ####\n",id,premium2);
                       if (id==-1) premium2=0;
                       printf("-----1 premium=[%d] \n",premium2);
                       if(fbigcomp[0]=='1')
                       {
                          $SELECT pre_dply2_bgn,pre_dply2_end
                             INTO $bef_ply2_begin,$bef_ply2_end
                             FROM policy_302
                            WHERE ipolicy = $last_ply;

                          $SELECT SUM(pre_minsprem) INTO $bef_premium2:id
                             FROM ply_ins_type_302
                            WHERE ipolicy = $last_ply;

                          printf("#### id=[%d] ####\n",id);
                          if (id==-1) bef_premium2=0;
                          printf("-----2 premium=[%d] \n",bef_premium2);
                       }
                       else
                       {
                          $SELECT pre_dply2_bgn,pre_dply2_end
                             INTO $bef_ply2_begin,$bef_ply2_end
                             FROM policy_302
                            WHERE ipolicy = $last_ply;

                          $SELECT SUM(pre_minsprem) INTO $bef_premium2:id
                             FROM ply_ins_type_302
                            WHERE ipolicy = $last_ply;

                          printf("#### id=[%d] ####\n",id);
                          if (id==-1) bef_premium2=0;
                          printf("-----3 premium=[%d] \n",bef_premium2);
                       }
                   }

                   printf("1-->premium2[%ld]\n",premium2);

                   if (irelative_ply[0]!=' ' && irelative_ply[0]!='\0')
                   {                                  /*--���N�I���j�����p�O��*/
                       $SELECT  plia_acc_c
                          INTO  $splia_acc
                          FROM  policy_302
                         WHERE  ipolicy = $irelative_ply;

                       rstod(splia_acc,&plia_acc_1);
                       printf("plia_acc_1[%f]\n",plia_acc_1);

                       if (fmulti[0]=='0') /* �@��� */
                       {
                            $SELECT --+INDEX (a pins32_idx_2)
                                    SUM(mins_premium) INTO $premium1:fprem
                               FROM ply_ins_type_302 a,policy_302 b
                              WHERE a.ipolicy=$irelative_ply
                                AND a.ipolicy=b.ipolicy
                                AND YEAR(b.dply_begin)=YEAR($ply2_begin)
                                AND MONTH(b.dply_begin)=MONTH($ply2_begin);
                            printf("#### fprem=[%d] ####\n",fprem);
                            if (fprem==-1) premium1=0;
                            printf("-----6 premium=[%d] \n",premium1);

                            if(fbigcomp[0]=='1')
                            {
                                $SELECT pre_dply1_bgn,pre_dply1_end
                                   INTO $bef_ply1_begin,$bef_ply1_end
                                   FROM policy_302
                                  WHERE ipolicy=$irelative_ply;

                                $SELECT SUM(pre_minsprem) INTO $bef_premium1:id
                                   FROM ply_ins_type_302
                                  WHERE ipolicy = $irelative_ply;

                                printf("#### id=[%d] ####\n",id);
                                if (id==-1) bef_premium1=0;
                                printf("-----7 premium=[%d] \n",bef_premium1);
                            }
                            else
                            {
                                $SELECT pre_dply1_bgn,pre_dply1_end
                                   INTO $bef_ply1_begin,$bef_ply1_end
                                   FROM policy_302
                                  WHERE ipolicy=$irelative_ply;

                                $SELECT SUM(pre_minsprem) INTO $bef_premium1:id
                                   FROM ply_ins_type_302
                                  WHERE ipolicy = $irelative_ply;

                                printf("#### id=[%d] ####\n",id);
                                if (id==-1) bef_premium1=0;
                                printf("-----8 premium=[%d] \n",bef_premium1);
                            }
                       }

                       printf("#### fprem=[%d] ####\n",fprem);
                       if (fmulti[0]=='0') /* �@��� */
                       {
                           if (bef_premium1 == 0)
                           {
                                 strcpy(remark,"3");
                                 remark[1]='\0';
                           }
                           else
                           {
                                if (fprem==-1)
                                { /* �j����  or �w�L��*/
                                     sprintf(stmt, " SELECT dply_end \
                                                       FROM %s:ply_relation    \
                                                     WHERE ipolicy = '%s' ",localdb1,irelative_ply);

                                     $PREPARE next3 FROM $stmt;
                                     $EXECUTE next3 INTO $ply1_end;

                                     printf("-9-irelative[%s]\n",irelative_ply);
                                     printf("-9-@@@bef_ply1_end[%d],ply2_begin[%d]\n",bef_ply1_end,ply2_begin);
                                     if(bef_ply1_end > ply2_begin)
                                     {
                                            /**********�j����****************/
                                            $SELECT note1,pre_dply1_bgn,pre_dply2_end
                                               INTO $note1,$ply1_begin,$ply1_end
                                               FROM policy_302
                                              WHERE ipolicy = $irelative_ply;
                                            premium1=0;
                                            strcpy(remark,"0"); remark[1]='\0';
                                     }
                                     else
                                     {
                                            /**********�j��w�L��,�L�X��O�Ҹ��ΫO��****************/
                                            sprintf(stmt, " SELECT inext_ply,dply_begin,dply_end \
                                                              FROM %s:ply_relation               \
                                                             WHERE ipolicy = '%s' ",localdb1,irelative_ply);
                                            $PREPARE next1 FROM $stmt;
                                            $EXECUTE next1 INTO $inext_ply,$ply1_begin,$ply1_end;

                                            if(strlen(trim(inext_ply)) == 0)
                                            {
                                                  strcpy(remark,"2"); remark[1]='\0';
                                            }
                                            else
                                            {
                                                  strcpy(remark,"1");
                                            }
                                     }
                                }
                                else
                                {       /* �j���� */
                                     $SELECT icard,qply_period,dply_begin,dply_end
                                        INTO $icard_1, $ply1_period, $ply1_begin, $ply1_end
                                        FROM policy_302
                                       WHERE ipolicy=$irelative_ply;

                                     $SELECT --+INDEX (a pins32_idx_2)
                                             mins_premium
                                        INTO $premium1:id
                                        FROM ply_ins_type_302 a
                                       WHERE ipolicy=$irelative_ply;
                                     printf("-12-#### id=[%d] ####\n",id);
                                     if (id==-1)
                                           premium1=0;
                                     else
                                           frelative_comp = 'Y';
                                }
                           }
                       }
                   }
             }
             else if (fcard_class[0]=='1')  /*-- �j�� --*/
             {
                   $SELECT  plia_acc_c
                      INTO  $splia_acc
                      FROM  policy_302
                     WHERE  ipolicy = $last_ply;
                   rstod(splia_acc,&plia_acc_1);
                   if (fmulti[0]=='1')        /* �j�O�� */
                         continue;

                   ply1_period=qply_period;
                   ply1_begin=dply_begin;
                   ply1_end=dply_end;

                   if (fmulti[0]=='0') /* �@��� */
                   {
                         $SELECT --+INDEX (pins32_idx_2)
                                 SUM(mins_premium) INTO $premium1:id
                            FROM ply_ins_type_302
                           WHERE ipolicy=$last_ply
                             AND iins_type = '21' ;
                         printf("-13- #### id=[%d] ####\n",id);
                         if (id==-1) premium1=0;
                         if(fbigcomp[0]=='1')
                         {
                             $SELECT pre_dply1_bgn,pre_dply1_end
                                INTO $bef_ply1_begin,$bef_ply1_end
                                FROM policy_302
                               WHERE ipolicy=$last_ply;

                             $SELECT SUM(pre_minsprem)
                                INTO $bef_premium1:id
                                FROM ply_ins_type_302
                               WHERE ipolicy = $last_ply;

                             printf("-14- #### id=[%d] ####\n",id);
                             if (id==-1) bef_premium1=0;
                             printf("-----14 bef_premium1=[%d] \n",bef_premium1);
                         }
                         else
                         {
                             $SELECT pre_dply1_bgn,pre_dply1_end
                                INTO $bef_ply1_begin,$bef_ply1_end
                                FROM policy_302
                               WHERE ipolicy=$last_ply;

                             $SELECT SUM(pre_minsprem)
                                INTO $bef_premium1:id
                                FROM ply_ins_type_302
                               WHERE ipolicy = $last_ply
                                 AND iins_type = '21';
                             printf("-15-#### id=[%d] ####\n",id);
                             if (id==-1) bef_premium1=0;
                             printf("-----15 bef_premium1=[%d] \n",bef_premium1);
                         }

                         if ((strncmp(car_typei,"01",2) == 0) ||
                             (strncmp(car_typei,"02",2) == 0) ||
                             (strncmp(car_typei,"32",2) == 0) ||
                             (strncmp(car_typei,"34",2) == 0))
                         {
                              $SELECT count(*)
                                 INTO $rela_cnt
                                 FROM policy_302
                                WHERE ipolicy = $irelative_ply
                                  AND YEAR(dply_begin) = YEAR($ply1_begin)
                                  AND MONTH(dply_begin) = MONTH($ply1_end);
                              printf("rela_cnt[%d]\n",rela_cnt);
                              printf("irelative_ply[%s]\n",irelative_ply);
                              if (rela_cnt == 0)
                              {
                                 $SELECT --+INDEX (pins32_idx_2)
                                         SUM(mins_premium)
                                    INTO $premium2:id
                                    FROM ply_ins_type_302
                                   WHERE ipolicy=$last_ply
                                     AND iins_type != '21' ;
                                 if (id == -1) premium2 = 0;
                              }
                         }
                   }

                   printf("-16-irelative_ply[%s]\n",irelative_ply);
                   printf("-17-fprem[%ld]\n",fprem);

                   fprem=0;

                   if (irelative_ply[0]!=' ' && irelative_ply[0]!='\0')
                   {      /* �����N���p�O�� */
                          if (fmulti[0]=='0') /* �@��� */
                          {
                              $SELECT --+INDEX (a pins32_idx_2)
                                         SUM(mins_premium) INTO $premium2:fprem
                                 FROM ply_ins_type_302 a,policy_302 b
                                WHERE a.ipolicy=$irelative_ply
                                  AND a.ipolicy=b.ipolicy
                                  AND YEAR(b.dply_begin)=YEAR($ply1_begin)
                                  AND MONTH(b.dply_begin)=MONTH($ply1_begin);
                              printf("-18-#### fprem=[%d] ####\n",fprem);
                              if (fprem==-1) premium2=0;

                              if(fbigcomp[0]=='1')
                              {
                                  $SELECT pre_dply2_bgn,pre_dply2_end
                                     INTO $bef_ply2_begin,$bef_ply2_end
                                     FROM policy_302
                                    WHERE ipolicy = $irelative_ply;

                                  $SELECT SUM(pre_minsprem)
                                     INTO $bef_premium2:id
                                     FROM ply_ins_type_302
                                    WHERE ipolicy = $irelative_ply;

                                  printf("-19-#### id=[%d] ####\n",id);
                                  if (id==-1) bef_premium2=0;
                              }
                              else
                              {
                                  $SELECT pre_dply2_bgn,pre_dply2_end
                                     INTO $bef_ply2_begin,$bef_ply2_end
                                     FROM policy_302
                                    WHERE ipolicy = $irelative_ply;

                                  $SELECT SUM(pre_minsprem)
                                     INTO $bef_premium2:id
                                     FROM ply_ins_type_302
                                    WHERE ipolicy = $irelative_ply;

                                  printf("-20-#### id=[%d] ####\n",id);
                                  if (id==-1) bef_premium2=0;
                              }
                         }
                         if (fprem==-1)
                         {       /* ���N�����  or �w�L��*/
                              premium2=0;
                              bef_premium2=0;

                              sprintf(stmt, " SELECT dply_end \
                                                FROM %s:ply_relation   \
                                               WHERE ipolicy = '%s' ",localdb1,irelative_ply);

                              $PREPARE next5 FROM $stmt;
                              $EXECUTE next5 INTO $ply2_end;

                              printf("-21-ply2_end[%l],ply2_begin[%l]\n",ply2_end,ply1_begin);

                              if(ply2_end > ply1_begin)
                              {
                                    /**********���N�����****************/
                                    sprintf(stmt, " SELECT dply_begin,dply_end,ipolicy   \
                                                      FROM %s:ply_relation \
                                                     WHERE ipolicy = '%s' ",localdb1,irelative_ply);

                                    $PREPARE next7 FROM $stmt;
                                    $EXECUTE next7 INTO $ply2_begin,$ply2_end,$last_ply;
                              }
                              else
                              {
                                    /**********���N�w�L��****************/
                                    sprintf(stmt, " SELECT dply_begin,dply_end,ipolicy \
                                                      FROM %s:ply_relation \
                                                     WHERE ipolicy=(SELECT inext_ply FROM %s:ply_relation \
                                                                     WHERE ipolicy= '%s') " ,
                                                    localdb1,localdb1,irelative_ply);
                                    $PREPARE next9 FROM $stmt;
                                    $EXECUTE next9 INTO $ply2_begin,$ply2_end,$last_ply;
                                    if(NOT_FOUND)
                                    {
                                        strcpy(remark,"���N�w�L��"); remark[10]='\0';
                                    }
                                    else
                                    {
                                        strcpy(remark," "); remark[10]='\0';
                                    }
                              }
                         }
                         else
                         {    /* ���N��� */
                              rec_count_1--;
                              *rec_cnt=rec_count_1;
                              printf("-22-.### *rec_cnt[%d]\n",*rec_cnt);
                              continue;
                         }
                   }
             }
             /*--------------------*/
             printf("-23-->premium2[%ld]\n",premium2);

             sprintf(stmt_buf,"SELECT {+ INDEX (a pins32_idx_2)} %s %s %s FROM %s %s %s ",
                              "iins_type,minjured_cover,mdeath_cover,",
                              "mdamage_cover,mdeduct,mins_premium,",
                              "qcoverage,qserial,ch_deduct,qday ",
                              "ply_ins_type_302 a ",
                              "WHERE ipolicy=? ",
                              "ORDER BY qserial");

             $PREPARE STM_ins FROM $stmt_buf;
             $DECLARE CUR_ins CURSOR FOR STM_ins;
             $OPEN CUR_ins USING $ply;
             while (1)
             {
                 $FETCH CUR_ins
                   INTO $ins_type,$injured_cover,$death_cover,$damage_cover,
                        $deduct,$ins_premium,$qcoverage,$qserial,
                        $ch_deduct,$qday;

                 if (NOT_FOUND) break;

                 if (strncmp(ins_type,"01",2) == 0 ||
                     strncmp(ins_type,"05",2) == 0 ||
                     strncmp(ins_type,"09",2) == 0 ||
                     strncmp(ins_type,"08",2) == 0)
                 {
                     dmg_flag = 'Y';
                     rfmtlong(damage_cover,"###,###,##&",LHsdamage_cover);
                     rfmtlong(ins_premium,"###,###,##&",LHsMprem);
                     strcpy(LHsMdeduct,ch_deduct);

                     if (qday > 0)
                         qday_01 = 1;
                     else
                         qday_01 = 0;
                 }
                 dmg_flag_p = dmg_flag;

                 if (strncmp(ins_type,"11",2) == 0)
                 {
                     if (qday > 0)
                         qday_11 = 1;
                     else
                         qday_11 = 0;
                 }

                 if (strncmp(ins_type,"31",2) == 0 ||
                     strncmp(ins_type,"32",2) == 0 )
                      lia_flag = 'Y';

                 if (! Insert_INS_TYPE(ins_type, injured_cover, death_cover,
                                       damage_cover, deduct, ins_premium,
                                       (double)0,(double)0," ",(double)0),
                                       0,0,0)
                 {
                     printf("malloc fail in struct INS_TYPE allocation!\n");
                     $CLOSE CUR_ins;
                     return M_CM_NOT_MALLOC;
                 }
                 Icurr->qcoverage=qcoverage;
                 Icurr->qserial=qserial;
             }
             $CLOSE CUR_ins;

             /*---�C�L��O��---*/
             CA30XForm1(db,fmulti);          /* ����O�O */
             CA30XForm2(db,fbigcomp,fmulti);     /* ����q���� */
        }
        $CLOSE CA302_ply_302_1;
    }

    printf("befreturn\n");
    return SUCCESS;

ca_rpt_renew_err:
    printf("ca_rpt_renew_err....\n");
    printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/*** ����O�O--�T���O�I�n�O�� PrintForm1 *************************/
CA30XForm1(db,fmulti)
char *db,*fmulti;
{
    int   i, other_ins;
    char  ch1[10], ch2[10];
    $char edomain1[25],edomain2[25];
    $char tmp_edo11[13],tmp_edo12[12],tmp_edo21[13],tmp_edo22[12];
    $char nins_abbr[29];
    $char nins_abbr1[29];

    printf("=============into CA30XForm1()\n");

    $WHENEVER SQLERROR GOTO ca30xform1_err;

    CA30XF1_1();        /* �򥻸�� */
    CA30XF1_2(fmulti);  /* �I�� */

    printf("==> end of CA30XF1_1 CA30XF1_2 \n");

    other_ins=0;
    INS_ptr=Ifirst;             /* process the other insurance type */
    while (INS_ptr) 
    {
        iins=atoi(INS_ptr->ins_type);

        if (iins==1 || iins==5 || iins==9 || iins==11 || iins==12 || iins==31 
            || iins==32 || iins==24 || iins==25 || iins==51 || iins==52 || 
            iins==53 || iins==0 || iins==2 || iins==21 || iins==8 || iins==17 ||
            iins==61 || iins==65 || iins==68 || iins==69 || iins==47)
            goto next_ins;

        strcpy(ins_type,INS_ptr->ins_type);

        $SELECT nins_type,edomain1,edomain2,fprint,qcoverage,nins_abbr
           INTO $nins_abbr,$edomain1,$edomain2,$fprint,$qcoverage,$nins_abbr1
           FROM insurance_type
          WHERE iins_type=$ins_type;
        if (NOT_FOUND)  goto next_ins;  /* It must be something wrong here! */
        if (*fprint=='0')
        {             /* clear to blank */
            strcpy(nins_abbr,blank);
            strcpy(edomain1,blank);
        }
        if (other_ins>6)
        {              /* not the first page */
            CA30XF1_3(db);

            CA30XF1_1();
            for (i=0; i<17; i++) rgu_put_body(1);   /* skip 17 lines */
        }

        printf("ins_type[%s],nins_abbr[%s],edomain1[%s]\n",ins_type,nins_abbr,edomain1);
        edomain1[21]='\0';

        if (qcoverage==0)
        {
            Put_Other_Ins_Cost(16,ins_type,nins_abbr,edomain1,
                               0,INS_ptr->fdeduct,
                               INS_ptr->deduct,(long)INS_ptr->ins_premium,
                               fmulti);
            other_ins+=1;
        }
        else if (qcoverage==1)
        {
            Put_Other_Ins_Cost(16,ins_type,nins_abbr,edomain1,
                               INS_ptr->damage_cover,INS_ptr->fdeduct,
                               INS_ptr->deduct,(long)INS_ptr->ins_premium,
                               fmulti);
            other_ins+=1;
        }
        else if (qcoverage==2)
        {
            Put_Other_Ins_Cost(16,ins_type,nins_abbr,edomain1,
                               INS_ptr->injured_cover,0,
                               0,0,
                               fmulti);
            Put_Other_Ins_Cost(16," "," "," ",
                               INS_ptr->damage_cover,INS_ptr->fdeduct,
                               INS_ptr->deduct,(long)INS_ptr->ins_premium,
                               fmulti);
            other_ins+=2;
        }
        else
        {
            Put_Other_Ins_Cost(16,ins_type,nins_abbr,edomain1,
                               INS_ptr->injured_cover,0,
                               0,0,
                               fmulti);
            Put_Other_Ins_Cost(16," "," "," ",
                               INS_ptr->death_cover,INS_ptr->fdeduct,
                               INS_ptr->deduct,0,
                               fmulti);
            Put_Other_Ins_Cost(16," "," "," ",
                               INS_ptr->damage_cover,0,
                               0,(long)INS_ptr->ins_premium,
                               fmulti);
            rgu_put_body(1);
            other_ins+=4;
        }
        next_ins:
        INS_ptr=INS_ptr->next;
    }   /* end while */

    for(i=0;i<6-other_ins;i++)
    {
        rgu_put_body(1);
    }

    CA30XF1_3(db);

    return 1;

ca30xform1_err:
    printf("ca30xform1_err....\n");
    printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* *�T���O�I�n�O��-- �򥻸�� **************************************/
CA30XF1_1()
{
    char  datestr[16], ch1[10], ch2[10], ch3[3];
    char  yy1[3], mm1[3], dd1[3], yy2[3], mm2[3], dd2[3];
    char  benefn1[31],benefn2[31];
    $char tmp_area[3],area_code[3];
    char  iss1[3], iss2[3];
    char assureda1[80], assureda2[80];
    char yy[3],mm[3],dd[3],tmp_today[12];
    $char tmp_str[31];
    int  i;

    printf(">>>> into ca302F1_1()\n");

    $WHENEVER SQLERROR GOTO ca30xf1_err;

    printf("fcar_class[%s]\n",fcar_class);

    rgu_put_body(92); max_count++;
    rgu_put_body(93); max_count++;
    rgu_put_body(94); max_count++;
        
    rgu_put_body_string(2,nchi_full,RIGHT);
    rgu_put_body_string(2,itoa(rec_count_1),RIGHT);
    if(fcar_class[0]=='1')
    {
         rgu_put_body_string(2,"V",RIGHT);
         rgu_put_body_string(2," ",RIGHT);
    }
    else
    {
         rgu_put_body_string(2," ",RIGHT);
         rgu_put_body_string(2,"V",RIGHT);
    }
    rgu_put_body(2); /* �ۥ�/��~ */

    printf("last_card[%s]\n",last_card);
 
    if (strlen(trim(icorps)) != 0)
    {
         rgu_put_body_string(95,trim(icorps),1);
         rgu_put_body_string(95,trim(ncorps),1);
         rgu_put_body(95);
    }
    else
    {
         rgu_put_body(1);
    }
    rgu_put_body(1);
    rgu_put_body(1);

    max_count+=4;

    strncpy(ch1,last_ply,3);
    ch1[3]='\0';
    rgu_put_body_string(3,ch1,RIGHT);
    strncpy(ch1,last_ply+3,14);
    ch1[14]='\0';
    rgu_put_body_string(3,ch1,LEFT);
    rgu_put_body_string(3,iply_area,LEFT);
    rgu_put_body(3); /* �O�I�渹�X */
    rgu_put_body(1);
    max_count+= 2;

    rgu_put_body_string(4,assuredn,LEFT);
    if(strlen(trim(user)) != 0)
        rgu_put_body_string(4,user,LEFT);
    else 
        rgu_put_body_string(4," ",LEFT);
    rgu_put_body(4); /* �Q�O�I�H */
 
    strcpy(tmp_str,"(��):");
    strcat(tmp_str,tel);
    rgu_put_body_string(91,rtrim(tmp_str),1);
    rgu_put_body(91);

    printf("assureda[%s]\n",assureda);
    ben_len=cc_split_chinese(assureda,assureda1,60);
    ben_len=cc_split_chinese(&assureda[ben_len],assureda2,60);
    printf("assureda1[%s]\n",assureda1);
    printf("assureda2[%s]\n",assureda2);
    aassured_zip[5]='\0';
    rgu_put_body_string(5,trim(aassured_zip),LEFT); 
    rgu_put_body_string(5,assureda1,LEFT); 

    strcpy(tmp_str,"(�]):");
    strcat(tmp_str,tphone_con);
    rgu_put_body_string(5,rtrim(tmp_str),1);

    rgu_put_body(5); /* ���� */

    strcpy(tmp_str,"(���):");
    strcat(tmp_str,imovephone);
    rgu_put_body_string(91,rtrim(tmp_str),1);
    rgu_put_body(91);

    max_count+=4;

    ben_len=cc_split_chinese(benefn,benefn1,30);
    ben_len=cc_split_chinese(&benefn[ben_len],benefn2,30);
    if(strlen(trim(benefn1)) != 0)
        rgu_put_body_string(7,benefn1,LEFT);
    else
        rgu_put_body_string(7," ",LEFT);
    if (fcard_class[0] == '2')
    {
        strcpy(datestr,cm_cdate_str(ply2_begin));
        cm_split_ymd(datestr,yy1,mm1,dd1);
        rgu_put_body_string(7,yy1,LEFT);
        rgu_put_body_string(7,mm1,LEFT);
        rgu_put_body_string(7,dd1,LEFT);
    }
    else
    {
        strcpy(datestr,cm_cdate_str(ply1_begin));
        cm_split_ymd(datestr,yy1,mm1,dd1);
        rgu_put_body_string(7,yy1,LEFT);
        rgu_put_body_string(7,mm1,LEFT);
        rgu_put_body_string(7,dd1,LEFT);
    }
    rgu_put_body(7); /* ����v�H */
    max_count++;
    if(strlen(trim(benefn2)) != 0)
        rgu_put_body_string(7,benefn2,LEFT);
    else
        rgu_put_body_string(7," ",LEFT);

    if (fcard_class[0] == '2') 
    {
        strcpy(datestr,cm_cdate_str(ply2_end));
        cm_split_ymd(datestr,yy2,mm2,dd2);
        rgu_put_body_string(7,yy2,LEFT);
        rgu_put_body_string(7,mm2,LEFT);
        rgu_put_body_string(7,dd2,LEFT);
    }
    else
    {
        strcpy(datestr,cm_cdate_str(ply1_end));
        cm_split_ymd(datestr,yy1,mm1,dd1);
        rgu_put_body_string(7,yy1,LEFT);
        rgu_put_body_string(7,mm1,LEFT);
        rgu_put_body_string(7,dd1,LEFT);
    }
    rgu_put_body(7); /* ���q�H/�O�I���� */
    max_count++;
    rgu_put_body(1);
    rgu_put_body(1);
    max_count+=2;

    strncpy(iss1,issue_ym,2); iss1[2]='\0';
    rgu_put_body_string(8,iss1,LEFT);

    rgu_put_body_string(8,brandi,LEFT);
    rgu_put_body_string(8,car_typei,LEFT);
    sprintf(ch1,"%2d",cylinder);
    rgu_put_body_string(8,ch1,LEFT);
    if (engine[0] !='\0' && engine[0] !=' ')
        rgu_put_body_string(8,engine,LEFT);
    else
        rgu_put_body_string(8,body,LEFT);

    rgu_put_body_string(8,tagnum,LEFT);
    sprintf(ch1,"%2.0f",qpt);
    printf("qpt[%s]\n",ch1);
    rgu_put_body_string(8,ch1,LEFT);
    rgu_put_body(8); /* ���y���-I */
    max_count+=1;

    strncpy(iss2,issue_ym+3,2); iss2[2]='\0';
    rgu_put_body_string(9,iss2,LEFT);

    rgu_put_body_string(9,pro_year,LEFT);
    rgu_put_body_string(9,brandn,LEFT);
    rgu_put_body_string(9,car_typen,LEFT);
    if(fpt[0]=='P')
        rgu_put_body_string(9,"�H",LEFT);
    else if(fpt[0]=='T')        
        rgu_put_body_string(9,"��",LEFT);
    else 
        rgu_put_body_string(9," ",LEFT);
    rgu_put_body(9); /* ���y���-II */
    max_count+=1;

    rgu_put_body_string(10,license,LEFT);
    if (birth[0] =='\0' || birth[0] ==' ')
    {
        rgu_put_body_string(10," ",LEFT);
        rgu_put_body_string(10," ",LEFT);
        rgu_put_body_string(10," ",LEFT);
        rgu_put_body_string(10," ",LEFT);
        rgu_put_body_string(10," ",LEFT);
    }
    else
    {
        if(strlen(trim(license))==10 && license[0] >= 'A' && license[0] <= 'Z')
        {
           rgu_put_body_string(10,"V",LEFT);
           rgu_put_body_string(10," ",LEFT);
        }
        else
        {
           rgu_put_body_string(10,"V",LEFT);
           rgu_put_body_string(10," ",LEFT);
        }
        cm_split_ymd(birth,yy2,mm2,dd2);
        rgu_put_body_string(10,yy2,LEFT);
        rgu_put_body_string(10,mm2,LEFT);
        rgu_put_body_string(10,dd2,LEFT);
    }   
    if (*sex=='1')
    {
        rgu_put_body_string(10,"V",RIGHT);
        rgu_put_body_string(10," ",RIGHT);
    }
    else
    {
        if (*sex=='2')
        {
                rgu_put_body_string(10," ",RIGHT);
                rgu_put_body_string(10,"V",RIGHT);
        }
        else
        {
                rgu_put_body_string(10," ",RIGHT);
                rgu_put_body_string(10," ",RIGHT);
        }
    }
  
    if (*marriage=='1')
    {
        rgu_put_body_string(10,"V",RIGHT);
        rgu_put_body_string(10," ",RIGHT);
    }
    else
    {
        if (*marriage=='2')
        {
                rgu_put_body_string(10," ",RIGHT);
                rgu_put_body_string(10,"V",RIGHT);
        }
        else
        {
                rgu_put_body_string(10," ",RIGHT);
                rgu_put_body_string(10," ",RIGHT);
        }
    }

    rgu_put_body(10); /* �Q�O�I�H�򥻸�� */
    max_count++;
    rgu_put_body_string(11,idmg_rate,RIGHT);
    rgu_put_body_string(11,ibrg_rate,RIGHT);
    sprintf(ch1,"%4.2f",psex_age_1);
    rgu_put_body_string(11,ch1,RIGHT);
    sprintf(ch1,"%2d",dmg_align);
    rgu_put_body_string(11,ch1,LEFT);
    sprintf(ch1,"%2d",brg_align);
    rgu_put_body_string(11,ch1,LEFT);
    sprintf(ch2,"%2d",lia_align);
    rgu_put_body_string(11,ch2,LEFT);
    rgu_put_body(11); /* �O�v�N���ΫY�� */
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body_string(60,"",LEFT);
    rgu_put_body_string(60,"",LEFT);
    rgu_put_body_string(60,"",LEFT);
    rgu_put_body_string(60,"",LEFT);
    rgu_put_body_string(60,"",LEFT);
    rgu_put_body_string(60,"",LEFT);
    rgu_put_body_string(60,big_office,LEFT);
    rgu_put_body(60);
    max_count+=4;

    return 1;

ca30xf1_err:
    printf("ca30xf1_err....\n");
    printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/** �T���O�I�n�O��--�I�� *******************************************/
CA30XF1_2(fmulti)
char *fmulti;
{
    char ch1[10];
    char sstmp[31];
    struct INS_TYPE *ptr;
    int  i;

    printf(">>>> into ca302F1_2()\n");

    ptr = Ifirst;

    if (fcard_class[0]=='1' &&
        remark[0]!=' ' && remark[0]!='\0')
    {
        rgu_put_body_string(48,remark,LEFT);
        for (i=0; i<20; i++) /* peter */
             rgu_put_body(1);
    }
    else
    {
        /*�Ѽ�:�C�L���,�I��,�O�B,�L�O�O,�ۭt�B,�j�O��flag*/
        /* �I�� 01/05/09/08 */
        if(Scan_INS_TYPE(1))
        {
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60,trim(big_sales),LEFT);
            rgu_put_body(60);  
            rgu_put_body_string(13,"01",LEFT);
            rgu_put_body_string(13,"�Ҧ�",LEFT); 
            rgu_put_body_string(13,trim(scar_price),RIGHT);
            rgu_put_body_string(13,trim(LHsdamage_cover),RIGHT);
            rgu_put_body_string(13,trim(LHsMdeduct),RIGHT);

            if (qday_01 > 0 )
               rgu_put_body_string(13,"(�[��)",LEFT);
            else
               rgu_put_body_string(13," ",LEFT);
            rgu_put_body_string(13,trim(LHsMprem),RIGHT);
            rgu_put_body_string(13,trim(LHsNname),1);
            rgu_put_body(13);  
        }
        else if(Scan_INS_TYPE(5))
        {
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60,big_sales,1);
            rgu_put_body(60); 
            rgu_put_body_string(13,"05",LEFT);
            rgu_put_body_string(13,"�A��",LEFT);
            rgu_put_body_string(13,trim(scar_price),RIGHT);
            rgu_put_body_string(13,trim(LHsdamage_cover),RIGHT);
            rgu_put_body_string(13,trim(LHsMdeduct),RIGHT);

            if (qday_01 > 0 )
               rgu_put_body_string(13,"(�[��)",LEFT);
            else
               rgu_put_body_string(13," ",LEFT);
            rgu_put_body_string(13,trim(LHsMprem),RIGHT);
            rgu_put_body_string(13,trim(LHsNname),1);
            rgu_put_body(13);  
        }
        else  if(Scan_INS_TYPE(9))
        {
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60,"���郞",LEFT);
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60,big_sales,LEFT);
            rgu_put_body(60);  
            rgu_put_body_string(13,"09",LEFT);
            rgu_put_body_string(13," �I��",LEFT);
            rgu_put_body_string(13,trim(scar_price),RIGHT);
            rgu_put_body_string(13,trim(LHsdamage_cover),RIGHT);
            rgu_put_body_string(13,trim(LHsMdeduct),RIGHT);

            if (qday_01 > 0 )
               rgu_put_body_string(13,"(�[��)",LEFT);
            else
               rgu_put_body_string(13," ",LEFT);
            rgu_put_body_string(13,trim(LHsMprem),RIGHT);
            rgu_put_body_string(13,trim(LHsNname),1);
            rgu_put_body(13);  
        }
        else if (Scan_INS_TYPE(8))
        {
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60,"�T����",LEFT);
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60,big_sales,LEFT);
            rgu_put_body(60);  
            rgu_put_body_string(13,"08",LEFT);
            rgu_put_body_string(13,"��I��",LEFT);
            rgu_put_body_string(13,trim(scar_price),RIGHT);
            rgu_put_body_string(13,trim(LHsdamage_cover),RIGHT);
            rgu_put_body_string(13,trim(LHsMdeduct),RIGHT);

            if (qday_01 > 0 )
               rgu_put_body_string(13,"(�[��)",LEFT);
            else
               rgu_put_body_string(13," ",LEFT);
            rgu_put_body_string(13,trim(LHsMprem),RIGHT);
            rgu_put_body_string(13,trim(LHsNname),1);
            rgu_put_body(13);  
        }
        else if(Scan_INS_TYPE(11))
        {
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60,big_sales,LEFT);
            rgu_put_body(60);
            rgu_put_body_string(13," ",LEFT);
            rgu_put_body_string(13," ",LEFT);
            rgu_put_body_string(13,trim(scar_price),RIGHT);
            rgu_put_body_string(13," ",LEFT);
            rgu_put_body_string(13," ",LEFT);
            printf("INTO 11\n");
            printf("qday_11[%ld]\n",qday_11);
            if (qday_11 > 0 )
               rgu_put_body_string(13,"(�[��)",LEFT);
            else
               rgu_put_body_string(13," ",LEFT);
            rgu_put_body_string(13," ",LEFT);
            rgu_put_body_string(13,trim(LHsNname),1);
            rgu_put_body(13);
        }
        else
        {
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60," ",LEFT);
            rgu_put_body_string(60,big_sales,LEFT);
            rgu_put_body(60);
            rgu_put_body_string(13," ",LEFT);
            rgu_put_body_string(13," ",LEFT);
            printf("carprice[%s]\n",ch1);
            rgu_put_body_string(13," ",LEFT);
            rgu_put_body_string(13," ",RIGHT);
            rgu_put_body_string(13," ",LEFT);
            rgu_put_body_string(13," ",LEFT);
            rgu_put_body_string(13," ",LEFT);
            rgu_put_body_string(13,trim(LHsNname),1);
            rgu_put_body(13);
        }
     
        /* �I�� 61 65 68 69 */
        if (Scan_INS_TYPE(61))
        {
           rgu_put_body_string(78,"61",1); 
           rgu_put_body_string(78,"�Ҧ��N���O",1);
           strcpy(sstmp,refmtamt(Icurr->damage_cover,MILLIONTH));
           rgu_put_body_string(78,sstmp,2);
           strcpy(sstmp,refmtamt(Icurr->ins_premium ,MILLIONTH));
           rgu_put_body_string(78,sstmp,2);
           rgu_put_body(78);
        }
        else if (Scan_INS_TYPE(65))
        {
           rgu_put_body_string(78,"65",1); 
           rgu_put_body_string(78,"�A���N���O",1);
           strcpy(sstmp,refmtamt(Icurr->damage_cover,MILLIONTH));
           rgu_put_body_string(78,sstmp,2);
           strcpy(sstmp,refmtamt(Icurr->ins_premium ,MILLIONTH));
           rgu_put_body_string(78,sstmp,2);
           rgu_put_body(78);
        }
        else if (Scan_INS_TYPE(68))
        {
           rgu_put_body_string(78,"68",1); 
           rgu_put_body_string(78,"����I���N���O",1);
           strcpy(sstmp,refmtamt(Icurr->damage_cover,MILLIONTH));
           rgu_put_body_string(78,sstmp,2);
           strcpy(sstmp,refmtamt(Icurr->ins_premium ,MILLIONTH));
           rgu_put_body_string(78,sstmp,2);
           rgu_put_body(78);
        }
        else if (Scan_INS_TYPE(69))
        {
           rgu_put_body_string(78,"69",1); 
           rgu_put_body_string(78,"���郞�N���O",1);
           strcpy(sstmp,refmtamt(Icurr->damage_cover,MILLIONTH));
           rgu_put_body_string(78,sstmp,2);
           strcpy(sstmp,refmtamt(Icurr->ins_premium ,MILLIONTH));
           rgu_put_body_string(78,sstmp,2);
           rgu_put_body(78);
        }
        else
        {
           rgu_put_body(1);
        }

        /* �I�� 11 */
        Put_Ins_Cost(75,11,3,1,1,fmulti,fcomp_24,qday_11);

        if (Scan_INS_TYPE(17))
        {
           rgu_put_body_string(78,"17",1);
           rgu_put_body_string(78,"�ѵs�I�K����",1);
           strcpy(sstmp,refmtamt(Icurr->damage_cover,MILLIONTH));
           rgu_put_body_string(78,trim(sstmp),2);
           printf("Icurr->ins_premium[%f]\n",Icurr->ins_premium);
           rfmtdouble(Icurr->ins_premium,"---,---,--&",sstmp);
           printf("sstmp[%s]\n",sstmp);
           rgu_put_body_string(78,trim(sstmp),2);
           rgu_put_body(78);
        }
        else
        {
           rgu_put_body(1);
        }

        /* �I�� 31/32 */
        Put_Ins_Cost(14,31,1,0,0,fmulti,fcomp_24,qday_11);
        Put_Ins_Cost(14,31,3,1,0,fmulti,fcomp_24,qday_11);
        Put_Ins_Cost(14,32,3,1,0,fmulti,fcomp_24,qday_11);
        /* �I�� 12/24 */
        rgu_put_body(1);
        Put_Ins_Cost(15,12,0,1,0,fmulti,fcomp_24,qday_11);
        rgu_put_body(1);
        Put_Ins_Cost(86,24,0,1,0,fmulti,fcomp_24,qday_11);
        /* �I�� 25 */
    
        /* �I�� 51/53/52 */
        if (Scan_INS_TYPE(51))
        {
            Put_Ins_Cost(61,51,1,0,0,fmulti,fcomp_24,qday_11);
            Put_Ins_Cost(63,51,2,0,0,fmulti,fcomp_24,qday_11);
            Put_Ins_Cost(63,51,3,1,0,fmulti,fcomp_24,qday_11);
        }
        else if (Scan_INS_TYPE(53))
        {
            Put_Ins_Cost(63,53,1,0,0,fmulti,fcomp_24,qday_11);
            Put_Ins_Cost(63,53,2,0,0,fmulti,fcomp_24,qday_11);
            Put_Ins_Cost(61,53,3,1,0,fmulti,fcomp_24,qday_11);
        }
        else
        {
            Put_Ins_Cost(14,51,1,0,0,fmulti,fcomp_24,qday_11);
            Put_Ins_Cost(14,51,2,0,0,fmulti,fcomp_24,qday_11);
            Put_Ins_Cost(14,51,3,1,0,fmulti,fcomp_24,qday_11);
        }

        if (Scan_INS_TYPE(52))
        {
            Put_Ins_Cost(62,52,1,0,0,fmulti,fcomp_24,qday_11);
            Put_Ins_Cost(62,52,2,0,0,fmulti,fcomp_24,qday_11);
            Put_Ins_Cost(62,52,3,1,0,fmulti,fcomp_24,qday_11);
        }
        else if (Scan_INS_TYPE(47))
        {
            rgu_put_body_string(78," ",1);
            rgu_put_body_string(78," ",1);
            strcpy(sstmp,refmtamt(Icurr->injured_cover,MILLIONTH));
            rgu_put_body_string(78,sstmp,2);
            rgu_put_body_string(78," ",1);
            rgu_put_body(78);
            rgu_put_body_string(78,"--",1);
            rgu_put_body_string(78,"�w�w�w�w�w�w",1);
            strcpy(sstmp,refmtamt(Icurr->death_cover,MILLIONTH));
            rgu_put_body_string(78,sstmp,2);
            strcpy(sstmp,refmtamt(Icurr->ins_premium ,MILLIONTH));
            rgu_put_body_string(78,sstmp,2);
            rgu_put_body(78);
            rgu_put_body_string(78,"47",1);
            rgu_put_body_string(78,"�r�p�H�ˮ`�I",1);
            strcpy(sstmp,refmtamt(Icurr->damage_cover,MILLIONTH));
            rgu_put_body_string(78,sstmp,2);
            rgu_put_body_string(78," ",1);

            rgu_put_body(78);
        }
        else
        {
            rgu_put_body(1);
            rgu_put_body(1);
            rgu_put_body(1);
        }
        /* �I�� 02 */
        rgu_put_body(1);
        Put_Ins_Cost(15,2,0,1,0,fmulti,fcomp_24,qday_11);  
    }
    max_count+=20;
}

/* �T���O�I�n�O��--�j��αq�H�]�� **********************************/
int CA30XF1_3(db)
char *db;
{
    int     i,code;
    char    datestr[16], ch1[10], ch2[10], ch3[10];
    char    yy1[3], mm1[3], dd1[3], yy2[3], mm2[3], dd2[3];
    char    str1[32],str2[6],tmp_rmk[91];
    $char   last_ply2[18];
    $long   qdmg_1[3],qlia_1[3];
    $long   mdmg_1[3],mlia_1[3];
    $long   qlia_acc_1,qdmg_acc_1;
    $double pdmg_acc_1,t_plia_acc_1;
    $long   qdmg_2[3],qlia_2[3];
    $long   mdmg_2[3],mlia_2[3],id;
    $long   qlia_acc_2,qdmg_acc_2,com_prem;
    $double t_pdmg_acc_2,t_plia_acc_2;
    $int    pre_year;
    char    fyear1[3],fyear2[3];
    $char   pre_ply[3][20],inumber[21],pre_comp[3][20],pre_relative[20],xxcard[15];
    $char   tmp[11];
    long    tot_premium;
    $date   dat_begin;
    double  acc_tmp;
    $char   c_acc_tmp[11];
    $int    iseq_tmp;
    $char   dclaim_tmp[11],dprocess_tmp[11],drescue_tmp[11];
    $char   qday_tmp[5];
    $char   tmp_buf[60];

    $WHENEVER SQLERROR GOTO ca302F1_3_err;

    printf(">>>> into ca302F1_3()\n");
    tot_premium = premium1 + premium2;
    strcpy(tmp,refmtamt(premium1,MILLIONTH));
    rgu_put_body_string(17,tmp,LEFT);
    if (dply_begin >= 37407)
        strcpy(tmp,refmtamt(premium2+iMdiscount,MILLIONTH));
    else
        strcpy(tmp,refmtamt(premium2,MILLIONTH));
        
    rgu_put_body_string(17,tmp,LEFT);

    if (iMdiscount != 0)
    {
        rgu_put_body_string(17,"�u�f:",LEFT);
        strcpy(tmp,refmtamt(iMdiscount,MILLIONTH));
        rgu_put_body_string(17,tmp,LEFT);
        rgu_put_body_string(17,"�ꦬ:",LEFT);
    }
    else
    {
        rgu_put_body_string(17," ",LEFT);
        rgu_put_body_string(17," ",LEFT);
        rgu_put_body_string(17," ",LEFT);
    }

    printf("iMdiscount[%ld]\n",iMdiscount);

    if (dply_begin >= 37407)
        strcpy(tmp,refmtamt((tot_premium),MILLIONTH));
    else
        strcpy(tmp,refmtamt((tot_premium-iMdiscount),MILLIONTH));

    rgu_put_body_string(17,tmp,RIGHT);
    rgu_put_body(17); /* �`�O�O */ 
    max_count+=1;

    rgu_put_body(1);
    max_count+=1;

    /*----�j��ĤT�H�d���I----*/
    /**remark 0������� 1���w��O 2������O 3���j����N���P�~�Ȩӷ�******/
    if (fcard_class[0]=='2' &&
        remark[0]!=' ' && remark[0]!='\0')
    {
        if ( remark[0] == '0')
        {
             rgu_put_body_string(12,note1,LEFT);
             rgu_put_body(12);
             rgu_put_body(1);
             strcpy(datestr,cm_cdate_str(ply1_begin));
             cm_split_ymd(datestr,yy1,mm1,dd1);
             rgu_put_body_string(18,yy1,LEFT);
             rgu_put_body_string(18,mm1,LEFT);
             rgu_put_body_string(18,dd1,LEFT);
             rgu_put_body(18); /* �j��O�I����(�_) */
             strcpy(datestr,cm_cdate_str(ply1_end));
             cm_split_ymd(datestr,yy2,mm2,dd2);
             rgu_put_body_string(19,yy2,LEFT);
             rgu_put_body_string(19,mm2,LEFT);
             rgu_put_body_string(19,dd2,LEFT);
             rgu_put_body_string(19,"",LEFT);
             rgu_put_body_string(19,"",LEFT);
             rgu_put_body(19); /* �j��O�I����(�_) */
             max_count   +=   4;
        }
        else if ( remark[0] == '2')
        {
             $SELECT dply_bgn_comp,dply_end_comp
                INTO  $ply1_begin,$ply1_end
                FROM policy_302
               WHERE ipolicy=$irelative_ply;

             rgu_put_body_string(12,note1,LEFT);
             rgu_put_body(12);
             rgu_put_body(1);
             strcpy(datestr,cm_cdate_str(ply1_begin));
             cm_split_ymd(datestr,yy1,mm1,dd1);
             rgu_put_body_string(18,yy1,LEFT);
             rgu_put_body_string(18,mm1,LEFT);
             rgu_put_body_string(18,dd1,LEFT);
             rgu_put_body(18); /* �j��O�I����(�_) */
             strcpy(datestr,cm_cdate_str(ply1_end));
             cm_split_ymd(datestr,yy2,mm2,dd2);
             rgu_put_body_string(19,yy2,LEFT);
             rgu_put_body_string(19,mm2,LEFT);
             rgu_put_body_string(19,dd2,LEFT);
             rgu_put_body_string(19,"",LEFT);
             rgu_put_body_string(19,"",LEFT);
             rgu_put_body(19); /* �j��O�I����(�_) */
             max_count   +=   4;
        }
        else
        {
             rgu_put_body(1);
             rgu_put_body(1);
             rgu_put_body(1);
             rgu_put_body(1);
             max_count   +=   4;
        }   
        rgu_put_body(1);
        max_count+=4;
    }
    else
    {
        rgu_put_body(1);
        rgu_put_body_string(12," ",LEFT);  
        rgu_put_body(12); /* �O�I�����X */
        max_count+=2;

        if (ply1_begin!=DATENULL) {
            strcpy(datestr,cm_cdate_str(ply1_begin));
            cm_split_ymd(datestr,yy1,mm1,dd1);
            rgu_put_body_string(18,yy1,LEFT);
            rgu_put_body_string(18,mm1,LEFT);
            rgu_put_body_string(18,dd1,LEFT);
        } else if (bef_ply1_begin!=DATENULL) {
            strcpy(datestr,cm_cdate_str(bef_ply1_begin));
            cm_split_ymd(datestr,yy1,mm1,dd1);
            rgu_put_body_string(18,yy1,LEFT);
            rgu_put_body_string(18,mm1,LEFT);
            rgu_put_body_string(18,dd1,LEFT);
        } else {
            rgu_put_body_string(18," ",LEFT);
            rgu_put_body_string(18," ",LEFT);
            rgu_put_body_string(18," ",LEFT);
        }
        rgu_put_body(18); /* �j��O�I����(�_) */
        max_count++;

        if (ply1_end!=DATENULL) {
            strcpy(datestr,cm_cdate_str(ply1_end));
            cm_split_ymd(datestr,yy2,mm2,dd2);
            rgu_put_body_string(19,yy2,LEFT);
            rgu_put_body_string(19,mm2,LEFT);
            rgu_put_body_string(19,dd2,LEFT);
        } else if (bef_ply1_end!=DATENULL) {
            strcpy(datestr,cm_cdate_str(bef_ply1_end));
            cm_split_ymd(datestr,yy2,mm2,dd2);
            rgu_put_body_string(19,yy2,LEFT);
            rgu_put_body_string(19,mm2,LEFT);
            rgu_put_body_string(19,dd2,LEFT);
        } else {
            rgu_put_body_string(19," ",LEFT);
            rgu_put_body_string(19," ",LEFT);
            rgu_put_body_string(19," ",LEFT);
        }
        rgu_put_body_string(19," ",LEFT);
        rfmtlong(premium1,"--,---,--&",ch2);
        rgu_put_body_string(19,ch2,LEFT);
        rgu_put_body(19); /* �j��O�I����(��) */
        max_count++;

        rgu_put_body(1);
        max_count+=4;
    }
    
    /*--- �O��q�T�M�� ---*/
    printf("full - remark1[%s]\n",remark1);
    
    if (strlen(trim(remark1)) != 0)
    {
        memset(tmp_rmk, 0x00, sizeof(tmp_rmk));
        strcpy(tmp_rmk,substring(remark1,1,90));
        rgu_put_body_string(88,tmp_rmk,LEFT);
        printf("1_tmp_rmk[%s]\n",tmp_rmk);
        rgu_put_body(88);
        strcpy(tmp_rmk,substring(remark1,91,90));
        rgu_put_body_string(88,tmp_rmk,LEFT);
        printf("2_tmp_rmk[%s]\n",tmp_rmk);
        rgu_put_body(88);
        memset(tmp_rmk, 0x00, sizeof(tmp_rmk));
        strcpy(tmp_rmk,substring(remark1,181,90));
        printf("3_tmp_rmk[%s]\n",tmp_rmk);
        rgu_put_body_string(88,tmp_rmk,LEFT);
        rgu_put_body(88);
    }
    else
    {
        rgu_put_body_string(88," ",LEFT);
        rgu_put_body(88);
        rgu_put_body_string(88," ",LEFT);
        rgu_put_body(88);
        rgu_put_body_string(88," ",LEFT);
        rgu_put_body(88);
    }

    if(tagnum[0]==' ' || tagnum[0]=='\0') strcpy(inumber,engine);
    else strcpy(inumber,tagnum);

    /*************�j��***************/
    printf("ca_acc-->inumber[%s]\n",trim(inumber));
    strcpy(inumber,trim(inumber));
    printf("----> qdmg_1[%d] qlia_1[%d]\n", qdmg_1[0], qlia_1[0]);
    printf("----> mdmg_1[%d] mlia_1[%d]\n", mdmg_1[0], mlia_1[0]);
    printf("----> fyear1[%d] lia_class[%s]\n", fyear1, lia_class);
    printf("----> frate[%s] \n", frate );
    code=ca_accident_record_next(db,inumber,ply1_begin,"1",
                                 qdmg_1,qlia_1,mdmg_1,mlia_1,&qdmg_acc_1,&qlia_acc_1,
                                 &pdmg_acc_1,&t_plia_acc_1,fyear1,"",lia_class,bqdmg,dply_begin,frate);
    if(code!=M_CM_OK) return code;
    printf("�j��ca_rpt_renew---qlia_acc_1-->[%ld]\n",qlia_acc_1);

    /***********���N*****************/
    code=ca_accident_record_next(db,inumber,ply2_begin,"2",
                                 qdmg_2,qlia_2,mdmg_2,mlia_2,&qdmg_acc_2,&qlia_acc_2,
                                 &t_pdmg_acc_2,&t_plia_acc_2,fyear2,"",lia_class,bqdmg,dply_begin,frate);
    if(code!=M_CM_OK) return code;
       
    /*****Ū���e��~�O��ܰ}�C********/

    for (pre_year=0; pre_year < 2 ; pre_year++)
    {
        printf("read pre_policy--cnt[%d],inumber[%s]\n",pre_year,inumber);
        pre_ply[pre_year][0] = '\0';
        pre_comp[pre_year][0] = '\0';
        printf("pre_ply_ipolicy-----[%s]\n",pre_ply[pre_year]);
        $DECLARE ply_cur CURSOR FOR
          SELECT ipolicy
            FROM ca_ply_period
           WHERE inumber=$inumber
             AND YEAR(dply_bgn)=(YEAR($dply_begin)-($pre_year+1));
        $OPEN ply_cur;
       
        while(1)
        {
            printf("fetch-------cnt[%d]\n",pre_year);
            $FETCH ply_cur into $pre_ply[pre_year];
            if (SQLCODE == SQLNOTFOUND)
                 break;

            printf("inumber [%s]\n",inumber);
            printf("pre_ply[%d]=[%s]\n",pre_year,pre_ply[pre_year]);

            $SELECT NVL(irel_card,' ')
               INTO $pre_comp[pre_year]
               FROM policy_302
              WHERE ipolicy = $pre_ply[pre_year];
            printf("Fetched AAAAAAAAAAAAAA   irel_card[%s]\n",pre_comp[pre_year]);
        }
        $CLOSE ply_cur;
        $FREE  ply_cur;
    }
    /************************************************/
    /* �q�H�]���ߴګY�� */

    rstrdate("09/01/2001",&dat_begin);
    printf("dat_begin[%ld]\n",dat_begin);
    printf("dply_begin[%ld]\n",dply_begin);

    if (dply_begin >= dat_begin){
        new_rate = 'Y';
    }else{
        new_rate = 'N';
    }

    rgu_put_body(1);  /* line 1 */
    rgu_put_body(1);  /* line 1 */
    rgu_put_body(1);  /* line 1 */
    rgu_put_body(1);  /* line 1 */
    rgu_put_body(1);  /* line 1 */
    max_count += 5;

    printf("fyear1[%s],fyear2[%s]\n",fyear1,fyear2);
    /* �e�@�~�O�渹 */
    if(strlen(trim(pre_ply[0])) > 13)
         strcpy(ch1,pre_ply[0]); /*** 89.06.19�]�j�O����פ���,�G17���L**/
    else if (strlen(trim(pre_ply[0])) > 0)
    {
         strcpy(ch1,"17");
         strcat(ch1,pre_ply[0]);
    }
    else
          ch1[0]='\0';
    rgu_put_body_string(46,ch1,LEFT);
       
    sprintf(ch1,"%2d",qlia_2[0]);
    if(fyear2[0]=='Y' && lia_flag == 'Y' && new_rate == 'N') /* ���N-�d�� */
        rgu_put_body_string(46,ch1,RIGHT);
    else
    {
        rgu_put_body_string(46," ",RIGHT);
    }

    strcpy(ch1,trim(cdmg[0]));
    if(fyear2[0]=='Y' && dmg_flag == 'Y') /* ���N-���� */
        rgu_put_body_string(46,ch1,RIGHT);
    else
        rgu_put_body_string(46," ",RIGHT);

    printf("====  fyear1 = [%c] ====\n\n",fyear1[0]);

    if(fyear1[0]=='Y')
    {   /* �j�� */
        printf("last_ply[%s],ch1[%s]\n",last_ply,ch1);
        sprintf(ch1,"%2d",qlia_1[0]);

        printf("ch1 == [%s]\n",ch1);
        rgu_put_body_string(46,ch1,RIGHT);
    }
    else
    {
        rgu_put_body_string(46," ",RIGHT);
    }
    rgu_put_body_string(46," ",RIGHT);
    rgu_put_body_string(46," ",RIGHT);
    rgu_put_body(46); /* �e�@�~ */

    /*****�e�@�~�j��************/

    printf("pre_comp[0] [%s]\n",pre_comp[0]);

    if(strlen(trim(pre_comp[0])) > 0)
    {
        rgu_put_body_string(46,trim(pre_comp[0]),LEFT);
    }
    else
    {
        rgu_put_body_string(46," ",LEFT);
    }
    rgu_put_body_string(46,"",LEFT);
    rgu_put_body_string(46,"",LEFT);
    rgu_put_body_string(46,"",LEFT);
    rgu_put_body_string(46,"",LEFT);
    rgu_put_body(46); /* �e�@�~ */
    max_count+=2;

    /* �e�G�~�O�渹 */
    if(strlen(trim(pre_ply[1])) > 13)
        strcpy(ch1,pre_ply[1]);
    else if(strlen(trim(pre_ply[1])) > 0)
    {
        strcpy(ch1,"17");
        strcat(ch1,pre_ply[1]);
    }
    else
        ch1[0]='\0';
    rgu_put_body_string(46,ch1,LEFT);

    sprintf(ch1,"%2d",qlia_2[1]);
    if(fyear2[1]=='Y' && lia_flag == 'Y' && new_rate == 'N') /* ���N-�d�� */
         rgu_put_body_string(46,ch1,RIGHT);
    else
         rgu_put_body_string(46," ",RIGHT);

    strcpy(ch1,trim(cdmg[1]));
    if(fyear2[1]=='Y' && dmg_flag == 'Y') /* ���N-���� */
        rgu_put_body_string(46,ch1,RIGHT);
    else
        rgu_put_body_string(46," ",RIGHT);

    rgu_put_body_string(46," ",RIGHT);
    rgu_put_body_string(46," ",RIGHT);

    rgu_put_body(46); /* �e�G�~ */
    rgu_put_body_string(46,trim(pre_comp[1]),LEFT);
    rgu_put_body_string(46,"",LEFT);
    rgu_put_body_string(46,"",LEFT);
    rgu_put_body_string(46,"",LEFT);
    rgu_put_body_string(46,"",LEFT);
    rgu_put_body(46); /* �e�@�~ */
    max_count  += 2;

    rgu_put_body_string(46," ",RIGHT);
    rgu_put_body_string(46," ",RIGHT);
    strcpy(ch1,trim(cdmg[2]));
    rgu_put_body_string(46,ch1,RIGHT);
    rgu_put_body_string(46," ",RIGHT);
    rgu_put_body_string(46," ",LEFT);
    rgu_put_body_string(46," ",LEFT);
    rgu_put_body(46); /* �e�T�~ */

    rgu_put_body_string(46," ",RIGHT);
    rgu_put_body_string(46," ",RIGHT);
    rgu_put_body_string(46," ",RIGHT);
    rgu_put_body_string(46," ",RIGHT);
    rgu_put_body_string(46," ",LEFT);
    rgu_put_body_string(46," ",LEFT);
    rgu_put_body(46); /* �e�T�~ */
    max_count = max_count + 2;
    printf("qlia_acc_1[%ld]\n",qlia_acc_1);
    printf("qlia_acc_2[%ld]\n",qlia_acc_2);
    printf("qdmg_acc_2[%ld]\n",qdmg_acc_2);

    printf("plia_acc_1[%f]\n",plia_acc_1);
    rgu_put_body_string(46," ",LEFT);

    $SELECT qclass INTO $qlia_acc_2
       FROM ca_comp_acc_factor
      WHERE pcomp_factor = $plia_acc_2
        AND fcard_class = '2'
        AND drate = (select drate from ca_rate_date
                      where icode = $frate
                        and itable = 'ca_comp_acc_factor');
    if (SQLCODE == SQLNOTFOUND) qlia_acc_2=4;

    acc_tmp = pdmg_acc_2 / 0.2;
    sprintf(c_acc_tmp,"%f",acc_tmp);
    qdmg_acc_2 = atoi(c_acc_tmp);
    printf("acc_tmp[%f]\n",acc_tmp);
    printf(" AA qdmg_acc_2 = pdmg_acc_2  / 0.2 \n ");
    printf("AA pdmg_acc_2[%f]\n",pdmg_acc_2);
    printf("AA qdmg_acc_2[%ld]\n",qdmg_acc_2);
 
    $SELECT qclass INTO $qlia_acc_1
       FROM ca_comp_acc_factor
      WHERE pcomp_factor = $plia_acc_1
        AND fcard_class = '1'
        AND drate = (select drate from ca_rate_date
                      where icode = $frate
                        and itable = 'ca_comp_acc_factor');
    if (SQLCODE == SQLNOTFOUND) qlia_acc_1=4;

    printf("�q�Hqlia_acc_2[%ld]\n",qlia_acc_2);
    printf("�q�Hqdmg_acc_2[%ld]\n",qdmg_acc_2);
    printf("�q�Hqlia_acc_1[%ld]\n",qlia_acc_1);

    if (lia_flag == 'Y')
    {
        sprintf(ch1,"%3d",qlia_acc_2);
        rgu_put_body_string(46,ch1,RIGHT);
    }
    else
        rgu_put_body_string(46," ",RIGHT);

    if  (dmg_flag == 'Y')
    {
        sprintf(ch1,"%3d",qdmg_acc_2);
        rgu_put_body_string(46,ch1,RIGHT);
    }
    else
         rgu_put_body_string(46," ",RIGHT);

    if (fcard_class[0] == '1' ||
       (fcard_class[0] == '2' && frelative_comp == 'Y'))
    {
        sprintf(ch1,"%3d",qlia_acc_1);
        rgu_put_body_string(46,ch1,RIGHT);
    }
    else
        rgu_put_body_string(46,"",RIGHT);
    rgu_put_body_string(46," ",LEFT);
    rgu_put_body_string(46," ",LEFT);
    rgu_put_body(46); /* �֭p�I�� */
    max_count++;

    printf("plia_acc_1[%f]\n",plia_acc_1);
    printf("plia_acc_2[%f]\n",plia_acc_2);
    printf("pdmg_acc_2[%f]\n",pdmg_acc_2);

    rgu_put_body_string(46," ",RIGHT);

    if (lia_flag == 'Y')
    {
        sprintf(ch1,"%2.1f",plia_acc_2);
        rgu_put_body_string(46,ch1,RIGHT);
    }
    else
        rgu_put_body_string(46,"",RIGHT);

    if (dmg_flag == 'Y')
    {
        sprintf(ch1,"%2.1f",pdmg_acc_2);
        rgu_put_body_string(46,ch1,RIGHT);
    }
    else
        rgu_put_body_string(46,"",RIGHT);
     
    if (fcard_class[0] == '1' ||
       (fcard_class[0] == '2' && frelative_comp == 'Y'))
    {
       sprintf(ch1,"%2.1f",plia_acc_1);
       rgu_put_body_string(46,ch1,RIGHT);
    }
    else
       rgu_put_body_string(46,"",RIGHT);

    rgu_put_body_string(46,iofficer,LEFT);
    rgu_put_body_string(46,nname,LEFT);
    rgu_put_body(46); /* �ߴګY�� */
    max_count++;

    if (dedr_begin==DATENULL)
    {
        rgu_put_body_string(87," ",LEFT);
    }
    else
    {
        printf("dedr_begin[%ld]\n",dedr_begin);
        strcpy(dedrbegin,cm_cdate_str(dedr_begin));
        printf("dedrbegin[%s]\n",dedrbegin);
        strcpy(ch1,dedrbegin);
        strcat(ch1," �L��");

        strcpy(tmp_buf,"(");
        strcat(tmp_buf,ch1);
        strcat(tmp_buf,")");

        rgu_put_body_string(87,tmp_buf,LEFT);
    }

    sNequipment[13] = '\0';
    rgu_put_body_string(87, sNequipment, RIGHT);

    if ((strlen(trim(ibig_comp_s)) == 0) && (dply_begin >= 37499) && (fcard_class[0] == '2'))
    {
        sprintf(pdiscount_s,"%.2f",pdiscount_d);
        strcat(pdiscount_s,"(�DPA)");

        rgu_put_body_string(87,rtrim(pdiscount_s),LEFT);
        printf("dply_begin[%ld]\n",dply_begin);
    }
    else
    {
        rgu_put_body_string(87," ",LEFT);
    }
    rgu_put_body(87);

    rgu_put_body(1);
    rgu_put_body(1);
    max_count  += 3;

    /* ��H�Υdñ�b��C�L�O�渹�X */
    strcpy(tmp_buf,"�O�渹�X:");
    strcat(tmp_buf,trim(last_policy));

    rgu_put_body_string(44,tmp_buf,LEFT);
    rgu_put_body(44);
    max_count++;

    /*  Start Work 911008   */

    rgu_put_body(1); max_count++;
    rgu_put_body(1); max_count++;
    itp = 0;
    $DECLARE clm_cur CURSOR FOR
      SELECT iseq,dclaim,dprocess,drescue,nvl(qday,' ')
        INTO $iseq_tmp,$dclaim_tmp,$dprocess_tmp,$drescue_tmp,$qday_tmp
        FROM ca_ply_service
       WHERE ipolicy = $last_ply_tmp
       ORDER BY 1;
    $OPEN clm_cur;
    for(;;)
    {
         $FETCH clm_cur;
         if (SQLCODE == SQLNOTFOUND) break;
         if (itp == 0)
         {
             rgu_put_body_string(59,"�߮פ��",1);
             rgu_put_body_string(59,"�{���B�z",1);
             rgu_put_body_string(59,"�D���ϴ�",1);
             rgu_put_body_string(59,"�N�B���Ѽ�",1);
             rgu_put_body(59); max_count++;  itp++;
         }
          strcpy(dclaim_tmp,cm_from_infdate(dclaim_tmp));
          rgu_put_body_string(59,trim(dclaim_tmp),1);

          strcpy(dprocess_tmp,cm_from_infdate(dprocess_tmp));
          rgu_put_body_string(59,trim(dprocess_tmp),1);

          strcpy(drescue_tmp,cm_from_infdate(drescue_tmp));
          rgu_put_body_string(59,trim(drescue_tmp),1);

          rgu_put_body_string(59,trim(qday_tmp),2);
          rgu_put_body(59); max_count++;  itp++;
    }
    $CLOSE clm_cur;
    $FREE  clm_cur;

    /*  End Work 911008     */

    return 1;

ca302F1_3_err:
    printf("ca302F1_3....\n");
    printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* * ����q���� **************************************************/
CA30XForm2(locdb,fbigcomp,fmulti)
$char *locdb, *fbigcomp, *fmulti;
{
    int   i, other_ins,oth_cnt=0;
    char  ch1[10], ch2[10], LocDB[20];
    $char buf3[200],edomain1[25],edomain2[25];
    $char tmp_edo11[13],tmp_edo12[12],tmp_edo21[13],tmp_edo22[12];
    $char nins_abbr[29];
    $char ins_type_t3[3];
    $long inj_cover_t3,dea_cover_t3,dam_cover_t3;
    $int  qser_t3;
    char  tmp_tab[20];

    printf("=============into CA30XForm2()\n");

    $WHENEVER SQLERROR GOTO ca30xform2_err;

    CA30XF2_1(locdb,fbigcomp);
    CA30XF2_2(locdb,fbigcomp,fmulti);

    other_ins=0;

    strcpy(LocDB,get_full_dbname(locdb));
    if (LocDB[0]=='\0') return M_CM_DB_NOTOPEN;
  
    strcpy(tmp_tab,"ply_ins_type_302");
   
    sprintf(buf3,"SELECT iins_type, pre_inj_cover, pre_dea_cover, pre_dam_cover, \
                         pre_deduct, pre_minsprem ,qserial                       \
                    FROM ply_ins_type_302     \
                   WHERE ipolicy = ? ORDER BY qserial  " ) ;   

    $PREPARE STM_10 FROM $buf3;
    $DECLARE CUR_10 CURSOR FOR STM_10;
    $OPEN CUR_10 USING $last_ply;
    while (1) 
    {
        $FETCH CUR_10
          INTO $ins_type_t3, $inj_cover_t3, $dea_cover_t3,
               $dam_cover_t3, $deduct_t3, $prem_t3, $qser_t3;

        if (sqlca.sqlcode !=0) break;

        iins=atoi(ins_type_t3);
        if (iins==1  || iins==5 || iins==2 || iins==11 || iins==12 ||
            iins==31 || iins==32 || iins==24 || iins==25 || iins==51 ||
            iins==53 || iins==52 || iins==21 || iins==9 || iins==8 || iins==47)
            continue;

        $SELECT nins_abbr,edomain1,edomain2,fprint,qcoverage
           INTO $nins_abbr,$edomain1,$edomain2,$fprint,$qcoverage
           FROM insurance_type
          WHERE iins_type=$ins_type_t3;
        if (NOT_FOUND)  continue; 

        if (*fprint=='0') {             /* clear to blank */
            strcpy(nins_abbr,blank);
            strcpy(edomain1,blank);
        }

        oth_cnt++;
        printf("oth_cnt[%d]\n",oth_cnt);

        if(oth_cnt==1)
            Put_Other_Ins_Cost_1(57,ins_type_t3,nins_abbr,edomain1,
                               " ","", 
                               deduct_t3,prem_t3,dam_cover_t3,
                               fmulti);
        else if(oth_cnt==2)
            Put_Other_Ins_Cost_1(58,ins_type_t3,nins_abbr,edomain1,
                               " ","", 
                               deduct_t3,prem_t3,dam_cover_t3,
                               fmulti);

    }   /* end while */
    $CLOSE CUR_10;

    if(oth_cnt==0)
    {
           rgu_put_body_string(57," ",LEFT);
           rgu_put_body_string(57," ",LEFT);
           rgu_put_body_string(57," ",LEFT);
           rgu_put_body_string(57," ",LEFT);
           rgu_put_body_string(57," ",LEFT);
           rgu_put_body_string(58," ",LEFT);
           rgu_put_body_string(58," ",LEFT);
           rgu_put_body_string(58," ",LEFT);
           rgu_put_body_string(58," ",LEFT);
           rgu_put_body_string(58," ",LEFT);
    }
    else if(oth_cnt==1) {
           rgu_put_body_string(58," ",LEFT);
           rgu_put_body_string(58," ",LEFT);
           rgu_put_body_string(58," ",LEFT);
           rgu_put_body_string(58," ",LEFT);
           rgu_put_body_string(58," ",LEFT);
    }
    rgu_put_body(50);
    rgu_put_body(51);
    rgu_put_body(52);
    rgu_put_body(53);
    rgu_put_body(54);
    rgu_put_body(55);
    rgu_put_body(56);
    rgu_put_body(57);
    rgu_put_body(58);
    max_count+=9;

    CA30XF2_3();

    return 1;

ca30xform2_err:
    printf("ca30xform2_err....\n");
    printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/* * ����q����--�O�I�򥻸�� *************************************/
CA30XF2_1(locdb1,fbigcomp)
char  *locdb1;
char  *fbigcomp;
{
    int      i;
    char     datestr[16], ch1[10], ch2[10];
    char     yy1[3], mm1[3], dd1[3], yy2[3], mm2[3], dd2[3], yy3[3], mm3[3], dd3[3];
    char     assureda1[45], assureda2[45];
    char     LocDB[20];
    $char    buf3[1080];
    $double  t_psex_age,t_plia_acc,t_pdmg_acc;
    char  tmp_tab[20];

    printf(">>>> into ca302F2_1()\n");
      
    strcpy(LocDB,get_full_dbname(locdb1));
    if (LocDB[0]=='\0') return M_CM_DB_NOTOPEN;

    $WHENEVER SQLERROR GOTO ca30xf2_err;

    sprintf(buf3,"SELECT pre_sex_age,NVL(pre_lia_acc,0),NVL(pre_dmg_acc,0) \
                    FROM policy_302                                        \
                   WHERE ipolicy = ? ");

    printf("�q����--->[%s]\n",buf3);
    $PREPARE STM_XF2     FROM   $buf3;
    $DECLARE CUR_XF2  CURSOR FOR STM_XF2;
    $OPEN    CUR_XF2 USING       $last_ply;
    $FETCH   CUR_XF2  INTO   $t_psex_age,$t_plia_acc,$t_pdmg_acc;
    printf("sex_age[%3.2f],lia_acc[%2.1f],dmg_acc[%2.1f]\n",
            t_psex_age,t_plia_acc,t_pdmg_acc);
    $CLOSE   CUR_XF2;
    $FREE    CUR_XF2;

    for (i=0; i<19-itp; i++)
         rgu_put_body(1);



    max_count+=21;

    if (fcard_class[0] == '2')
    {
        rgu_put_body_string(30,last_card,LEFT);
        rgu_put_body_string(30,last_ply,LEFT);
        strcpy(datestr,cm_cdate_str(bef_ply2_begin));
        cm_split_ymd(datestr,yy1,mm1,dd1);
        sprintf(ch1,"%s%s%s%s%s",yy1,"/",mm1,"/",dd1);
        rgu_put_body_string(30,ch1,LEFT);
        strcpy(datestr,cm_cdate_str(bef_ply2_end));
        cm_split_ymd(datestr,yy2,mm2,dd2);
        sprintf(ch1,"%s%s%s%s%s",yy2,"/",mm2,"/",dd2);
        rgu_put_body_string(30,ch1,LEFT);
        rfmtlong(bef_premium2,"---,---,--&",ch1);
        rgu_put_body_string(30,ch1,LEFT);
        rgu_put_body(30);
    }
    else
        rgu_put_body(1);
     
    rgu_put_body(1);
    max_count+=2;

    rgu_put_body_string(31,assuredn,LEFT);
    rgu_put_body(31);
    rgu_put_body(1);
    max_count+=2;

    ben_len=cc_split_chinese(assureda,assureda1,44);
    ben_len=cc_split_chinese(&assureda[ben_len],assureda2,44);

    printf("assureda1[%s]\n",assureda1);
    rgu_put_body_string(32,aassured_zip,LEFT);
    rgu_put_body_string(32,assureda1,LEFT);
    rgu_put_body(32);
    max_count++;

    printf("assureda2[%s]\n",assureda2);

    rgu_put_body_string(33,assureda2,LEFT);
    rgu_put_body(33);
    rgu_put_body(1);
    max_count+=2;

    rgu_put_body_string(34,pro_year,LEFT);
    rgu_put_body_string(34,brandn,LEFT);
    printf("@@@@car_typen[%s]\n",car_typen);
    rgu_put_body_string(34,car_typen,LEFT);
    sprintf(ch1,"%2d",cylinder);
    rgu_put_body_string(34,ch1,LEFT);
    if (engine[0] !='\0' && engine[0] !=' ')
        rgu_put_body_string(34,engine,LEFT);
    else
        rgu_put_body_string(34,body,LEFT);

    rgu_put_body_string(34,tagnum,LEFT);
    sprintf(ch1,"%2.0f",qpt);
    if(fpt[0]=='P')
        strcat(ch1,"�H");
    else if(fpt[0]=='T')
        strcat(ch1,"��");
    else
        strcat(ch1,"  ");
    rgu_put_body_string(34,ch1,RIGHT);
    rgu_put_body(34);
    max_count+=1;

    rgu_put_body_string(35,license,LEFT);
    if (birth[0]==' ' || birth[0]=='\0') {
        rgu_put_body_string(35," ",LEFT);
    } else {
        birth[5]='\0';
        rgu_put_body_string(35,birth,LEFT);
    }
    if (*sex=='1') {
        strcpy(ch1,"�k");
    } else {
        if (*sex=='2') 
        strcpy(ch1,"�k");
        else strcpy(ch1,"");
    }
    rgu_put_body_string(35,ch1,LEFT);

    sprintf(ch1,"%2.1f",t_psex_age);
    rgu_put_body_string(35,ch1,RIGHT);

    sprintf(ch1,"%3.1f",t_plia_acc);
    rgu_put_body_string(35,ch1,RIGHT);

    sprintf(ch1,"%3.1f",t_pdmg_acc);
    rgu_put_body_string(35,ch1,RIGHT);

    sprintf(ch1,"%2d",dmg_align);
    rgu_put_body_string(35,ch1,LEFT);
    sprintf(ch1,"%2d",brg_align);
    rgu_put_body_string(35,ch1,LEFT);
    sprintf(ch2,"%2d",lia_align);
    rgu_put_body_string(35,ch2,LEFT);
    rgu_put_body(35);
    rgu_put_body(1);
    max_count+=2;

    return 1;

ca30xf2_err:
    printf("ca30xf2_err....\n");
    printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* * ����q����--�I�ة��Ӹ�� **********************************/
CA30XF2_2(locdb1,fbigcomp,fmulti)
$char *locdb1;
char  *fbigcomp, *fmulti;
{
    char LHsdam_cover_t2[11];
    $char LHsdeduct_t2[13];
    char LHsprem_t2[11], LHsdea_cover_t2[11];
    $char buf4[200],ins_type_t2[3];
    $long inj_cover_t2,dea_cover_t2,dam_cover_t2,deduct_t2,prem_t2;
    $int  qser_t2, j,cnt;
    $static char fixins[14][3]={"01","05","08","09","11","31","32","12","24","25","51","52","02","47"};
    char  LocDB1[20];
    char  tmp_tab[20];
    int   iIdrive;
    $char tmp_1[20];

    $WHENEVER SQLERROR GOTO ca30xf2_2_err;

    printf(">>>> into ca302F2_2()\n");

    iIdrive = FALSE;
    strcpy(LocDB1,get_full_dbname(locdb1));
    if (LocDB1[0]=='\0') return M_CM_DB_NOTOPEN;
    strcpy(tmp_tab,"ply_ins_type_302");
    sprintf(buf4,"SELECT {+ INDEX (%s pins32_idx_1)} %s %s FROM %s:%s %s",
                 tmp_tab,
                 "iins_type,pre_inj_cover,pre_dea_cover,pre_dam_cover,",
                 "pre_deduct,pre_minsprem,qserial,ch_deduct[1,7]",
                 LocDB1,tmp_tab,
                 "WHERE ipolicy=? AND iins_type=?");
    $PREPARE STM_11 FROM $buf4;
    $DECLARE CUR_11 CURSOR FOR STM_11;
    cnt = 0;

    for (j=0;j<14;j++)
    {
        $OPEN CUR_11 USING $last_ply,$fixins[j];
        $FETCH CUR_11
          INTO $ins_type_t2, $inj_cover_t2, $dea_cover_t2,
               $dam_cover_t2, $deduct_t2, $prem_t2, $qser_t2, $LHsdeduct_t2;

        if (SQLCODE == SQLNOTFOUND)
        {
            iins=atoi(fixins[j]);
            switch (iins) {
            case 1: case 5: case 9: case 8:
                  cnt += 1;
                  if (cnt == 4)
                  {
                    rgu_put_body_string(50," ",0);
                    rgu_put_body_string(50," ",0);
                    rgu_put_body_string(50," ",0);
                    rgu_put_body_string(50," ",0);
                    rgu_put_body_string(50," ",0);
                  }
                  break;
            case 11:
                  rgu_put_body_string(51," ",0);
                  rgu_put_body_string(51," ",0);
                  rgu_put_body_string(51," ",0);
                    break;
            case 12:
                  rgu_put_body_string(55," ",0);
                    break;
            case 32:
                  rgu_put_body_string(54," ",0);
                  rgu_put_body_string(54," ",0);
                  rgu_put_body_string(54," ",0);
                    break;
            case 24:
                  rgu_put_body_string(56," ",0);
                    break;
            case 31:
                  rgu_put_body_string(52," ",0);
                  rgu_put_body_string(52," ",0);
                  rgu_put_body_string(52," ",0);
                  rgu_put_body_string(53," ",0);
                  rgu_put_body_string(53," ",0);
                  rgu_put_body_string(53," ",0);
                    break;
            case 25:
                  rgu_put_body_string(57," ",0);
                  rgu_put_body_string(57," ",0);
                  rgu_put_body_string(57," ",0);
                  rgu_put_body_string(58," ",0);
                  rgu_put_body_string(58," ",0);
                  rgu_put_body_string(58," ",0);
                    break;
            case 51:
                  rgu_put_body_string(50," ",0);
                  rgu_put_body_string(50," ",0);
                  rgu_put_body_string(50," ",0);
                  rgu_put_body_string(51," ",0);
                  rgu_put_body_string(51," ",0);
                  rgu_put_body_string(51," ",0);
                  rgu_put_body_string(52," ",0);
                  rgu_put_body_string(52," ",0);
                  rgu_put_body_string(52," ",0);
                    break;
            case 52:
            case 47:
                  if ((j == 13) && (iIdrive == FALSE)){
                  rgu_put_body_string(53," ",0);
                  rgu_put_body_string(53," ",0);
                  rgu_put_body_string(53," ",0);
                  rgu_put_body_string(54," ",0);
                  rgu_put_body_string(54," ",0);
                  rgu_put_body_string(54," ",0);
                  rgu_put_body_string(55," ",0);
                  rgu_put_body_string(55," ",0);
                  rgu_put_body_string(55," ",0);
                  }
                  iIdrive = TRUE ;
                  break;
             other:
                  rgu_put_body_string(57," ",0);
                  rgu_put_body_string(57," ",0);
                  rgu_put_body_string(57," ",0);
                  rgu_put_body_string(58," ",0);
                  rgu_put_body_string(58," ",0);
                  rgu_put_body_string(58," ",0);
                  break;
            }
            continue;
        }

        iins=atoi(ins_type_t2);
        /* �I�� 01/05/88/11/12/31/32/24/25/51/52/09/08/47 */

        if(iins==1 || iins==5 || iins==8 || iins==9)
        {
            rfmtlong(dam_cover_t2,"###,###,##&",LHsdam_cover_t2);
            /***rfmtlong(deduct_t2,"###,##&",LHsdeduct_t2);***/
            rfmtlong(prem_t2,"###,###,##&",LHsprem_t2);
            rfmtlong(dea_cover_t2,"###,###,##&",LHsdea_cover_t2);

            rgu_put_body_string(50,ins_type_t2,RIGHT);
            if(iins==1)
            {
                 rgu_put_body_string(50,"�Ҧ�",RIGHT);
            }
            if(iins==5)
            {
                 rgu_put_body_string(50,"�A��",RIGHT);
            }
            if(iins==8)
            {
                 rgu_put_body_string(50,"�B��",RIGHT);
            }
            if(iins==9)
            {
                 rgu_put_body_string(50,"����",RIGHT);
            }
            rgu_put_body_string(50,trim(LHsdam_cover_t2),RIGHT);
            rgu_put_body_string(50,trim(LHsdeduct_t2),RIGHT);
            rgu_put_body_string(50,trim(LHsprem_t2),RIGHT);
        }

        if(iins==11)
        {
            Put_Ins_Cost_1(51,11,3,1,0,1,
                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
                           deduct_t2,prem_t2,fmulti);

        }
        if(iins==12)
        {
            printf("BEF 12 \n");
            Put_Ins_Cost_1(55,12,0,1,0,1,
                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
                           deduct_t2,prem_t2,fmulti);

        }
        if(iins==31)
        {
            if (inj_cover_t2==0 && dea_cover_t2==0 && dam_cover_t2==0 &&
                prem_t2==0) {
                  rgu_put_body_string(52," ",0);
                  rgu_put_body_string(52," ",0);
                  rgu_put_body_string(52," ",0);
                  rgu_put_body_string(53," ",0);
                  rgu_put_body_string(53," ",0);
                  rgu_put_body_string(53," ",0);
            } else {
            Put_Ins_Cost_1(52,31,1,0,0,2,
                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
                           deduct_t2,prem_t2,fmulti);
            Put_Ins_Cost_1(53,31,3,1,0,2,
                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
                           deduct_t2,prem_t2,fmulti);
            }
        }
        if(iins==32)
        {
            if (inj_cover_t2==0 && dea_cover_t2==0 && dam_cover_t2==0 &&
                prem_t2==0) {
                  rgu_put_body_string(54," ",0);
                  rgu_put_body_string(54," ",0);
                  rgu_put_body_string(54," ",0);
            } else {
            Put_Ins_Cost_1(54,32,3,1,0,1,
                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
                           deduct_t2,prem_t2,fmulti);
            }
        }
        if(iins==24)
        {
            Put_Ins_Cost_1(56,24,0,1,0,1,
                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
                           deduct_t2,prem_t2,fmulti);

        }
        if(iins==25)
        {
            Put_Ins_Cost_1(57,25,1,0,0,2,
                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
                           deduct_t2,prem_t2,fmulti);
            Put_Ins_Cost_1(58,25,3,1,0,2,
                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
                           deduct_t2,prem_t2,fmulti);

        }
        if(iins==51)
        {
            if (inj_cover_t2==0 && dea_cover_t2==0 && dam_cover_t2==0 &&
                prem_t2==0) {
            rgu_put_body_string(50," ",LEFT);
            rgu_put_body_string(50," ",LEFT);
            rgu_put_body_string(50," ",LEFT);
            rgu_put_body_string(51," ",LEFT);
            rgu_put_body_string(51," ",LEFT);
            rgu_put_body_string(51," ",LEFT);
            rgu_put_body_string(52," ",LEFT);
            rgu_put_body_string(52," ",LEFT);
            rgu_put_body_string(52," ",LEFT);
            }
            else {
            Put_Ins_Cost_1(50,51,1,0,0,3,
                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
                           deduct_t2,prem_t2,fmulti);
            Put_Ins_Cost_1(51,51,2,0,0,3,
                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
                           deduct_t2,prem_t2,fmulti);
            Put_Ins_Cost_1(52,51,3,1,0,3,
                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
                           deduct_t2,prem_t2,fmulti);
            }

        }
        if(iins==52)
        {
            Put_Ins_Cost_1(53,52,1,0,0,3,
                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
                           deduct_t2,prem_t2,fmulti);
            Put_Ins_Cost_1(54,52,2,0,0,3,
                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
                           deduct_t2,prem_t2,fmulti);
            Put_Ins_Cost_1(55,52,3,1,0,3,
                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
                           deduct_t2,prem_t2,fmulti);
        }
        if(iins==47)
        {
            Put_Ins_Cost_1(53,47,1,0,0,3,
                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
                           deduct_t2,prem_t2,fmulti);
            Put_Ins_Cost_1(54,47,2,0,0,3,
                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
                           deduct_t2,prem_t2,fmulti);
            Put_Ins_Cost_1(55,47,3,1,0,3,
                           inj_cover_t2,dea_cover_t2,dam_cover_t2,
                           deduct_t2,prem_t2,fmulti);
        }
        if(iins==2){
            rgu_put_body_string(56," ",1);
            rgu_put_body_string(56," ",1);
            rfmtlong(prem_t2,"-,---,--&",tmp_1);
            rgu_put_body_string(56,trim(tmp_1),2);
        }

        $CLOSE CUR_11;

    } /* end of for */
    max_count += 9;

    return 1;
        

ca30xf2_2_err:
    printf("ca30xf2_2_err....\n");
    printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* * ����q����--�j���I�ظ�� ************************************/
CA30XF2_3()
{
    char  datestr[16], ch1[16], ch2[16];
    char  yy1[3], mm1[3], dd1[3], yy2[3], mm2[3], dd2[3];

    printf(">>>> into ca302F2_3()\n");

    if (bef_ply1_begin==DATENULL) {
        rgu_put_body_string(41," ",LEFT);
        rgu_put_body_string(41," ",LEFT);
        rgu_put_body_string(41," ",LEFT);
    } else {
        strcpy(datestr,cm_cdate_str(bef_ply1_begin));
        cm_split_ymd(datestr,yy1,mm1,dd1);
        rgu_put_body_string(41,yy1,LEFT);
        rgu_put_body_string(41,mm1,LEFT);
        rgu_put_body_string(41,dd1,LEFT);
    }
    rgu_put_body(41);
    if (fcard_class[0] == '1')
        rgu_put_body_string(42,last_card,LEFT);
    else
        rgu_put_body_string(42,irel_card,LEFT);
    if (bef_ply1_end==DATENULL) {
        rgu_put_body_string(42," ",LEFT);
        rgu_put_body_string(42," ",LEFT);
        rgu_put_body_string(42," ",LEFT);
    } else {
        strcpy(datestr,cm_cdate_str(bef_ply1_end));
        cm_split_ymd(datestr,yy2,mm2,dd2);
        rgu_put_body_string(42,yy2,LEFT);
        rgu_put_body_string(42,mm2,LEFT);
        rgu_put_body_string(42,dd2,LEFT);
    }
    printf("-----20 bef_premium1=[%d] \n",bef_premium1);
    rfmtlong(bef_premium1,"---,---,--&",ch1);
    rgu_put_body_string(42,trim(ch1),RIGHT);
    rgu_put_body(42);
    rgu_put_body(1);
    max_count+=3;
}

/* * ����*********************************************************/
int docket(bigcomp_ply,fcomp)
$char *bigcomp_ply,*fcomp;
{
    $char ch1[300],stmt_buf[1000];
    char assureda1[80], assureda2[80];

    $WHENEVER SQLERROR GOTO ca_rpt_renew_err1;

    InitData1();

    printf("1----->>>>bigcomp_ply[%s],fcomp[%s]\n",bigcomp_ply,fcomp);
    if(fcomp[0]=='1')
    { /* �@�� */
        $SELECT a.ipolicy,a.ibig_office,b.nassured,b.aassured
           INTO $last_ply,$big_office,$assuredn,$assureda
           FROM ply_relation a,policy b
          WHERE a.ipolicy=b.ipolicy AND a.ipolicy=$bigcomp_ply;
    }
    else
    {  /* �O�N */
        $SELECT a.ipolicy,ibig_office,nassured,aassured,a.ibig_comp
           INTO $last_ply,$big_office,$assuredn,$assureda,$ibig_comp
           FROM ply_relation_last a,policy_last b,broker_agent c
          WHERE a.ipolicy=b.ipolicy AND a.ipolicy=$bigcomp_ply
            AND a.ibroker=c.ibroker;
    }

    if (SQLCODE != 0)
    {
       strcpy(last_ply," ");
       strcpy(big_office," ");
       strcpy(assuredn," ");
       strcpy(assureda," ");
       strcpy(ibig_comp," ");
    }

    printf("2-------ply[%s] \n",last_ply);
    printf("ibig_comp[%s],big_office[%s]\n",ibig_comp,big_office);

    /*---�C�L����---*/
    rgu_put_body(1);      /* line 1 */
    rgu_put_body(1);      /* line 2 */
    if(fcomp[0]=='1')
    { /* �@�� */
         rgu_put_body(1);      /* line 4 */
    }
    else
    {  /* �O�N */
         strcpy(ch1,"�O�N���q:");
         strcat(ch1,ibig_comp);
         strcat(ch1,"  ������~�ҥN��:");
         strcat(ch1,big_office);
         rgu_put_body_string(44,ch1,LEFT);
         rgu_put_body(44);     /* line 3 */
    }
    rgu_put_body(1);      /* line 4 */

    printf("assuredn[%s]\n",assuredn);

    strcpy(ch1,"�m�W:");
    strcat(ch1,assuredn);
    rgu_put_body_string(44,ch1,LEFT);
    rgu_put_body(44);     /* line 5 */
    rgu_put_body(1);      /* line 6 */

    printf("assureda[%s]\n",assureda);
    ben_len=cc_split_chinese(assureda,assureda1,40);
    ben_len=cc_split_chinese(&assureda[ben_len],assureda2,40);
    printf("assureda1[%s]\n",assureda1);
    printf("assureda2[%s]\n",assureda2);
    strcpy(ch1,"���}:");
    strcat(ch1,assureda1);
    rgu_put_body_string(44,ch1,LEFT);
    rgu_put_body(44);     /* line 7 */

    strcpy(ch1,"     ");
    strcat(ch1,assureda2);
    rgu_put_body_string(44,ch1,LEFT);
    rgu_put_body(44);    /* line 8 */

    printf("------print label:ply[%s] \n",last_ply);

    max_count+=8;

    rgu_put_body(1); /* line 9 */
    max_count+=1;
  
return SUCCESS;

ca_rpt_renew_err1:
    printf("ca_rpt_renew_err1....\n");
    printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  char sTmp_db_name[21];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, sTmpcomp);
  }
  return sTmp_db_name;
}

/************************************************************************/
static long GetNextYearDate(pdate)
long pdate;
{
long ndate;
short mdy[3];

    rjulmdy(pdate,mdy);
    mdy[2]++;   /* mdy[2] is the year data */

    if ((mdy[0] == 2) && (mdy[1] == 29))
       mdy[1] = 28;

    printf("�~[%d],��[%d],��[%d]\n",mdy[2],mdy[0],mdy[1]);

    rmdyjul(mdy,&ndate);
    return ndate;
}

char *split_yymm(edate)
char edate[11];
{
char syymm[5];
int  iyear;
char tmp[5];

     printf("edate[%s]\n",edate);
     strcpy(tmp,edate+6);
     iyear = atoi(tmp);
     strcpy(syymm,itoa(iyear-1911));
     strncpy(tmp,edate,2);
     tmp[2] = '\0';
     strcat(syymm,tmp);
     return syymm;
}

