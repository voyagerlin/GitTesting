/**********************************************************************/
/*   program id   : ca153q01s.ec                                      */
/*   program name : �H�u�֭�]�w��                                        */
/*   date written : 2015/06/10 by 030344                              */
/*   files        : ca_permit                                         */
/*                                                                    */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"

#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"
$include decimal;

DBinfo *list;
int   count_db;
char  outputf[21];
$char DBName[5];
$char userid[11];
$char msgbuf[128];

$char txticlass[3],txticode[21],txtitype[3],dupdate_bgn[11],dupdate_end[11],ch_dexpire[2];
$char dupdate_bgn1[11],dupdate_end1[11];
$char sWhere[256],stmt[4096],sMsg[4096];


int rc;

main(argc, argv)
int argc;
char **argv;
{

    batchinit();
    strcpy(DBName,       isNULLstr(argv[1]));
    strcpy(userid,       isNULLstr(argv[2]));
    strcpy(txticlass,    isNULLstr(argv[3]));
    strcpy(txticode,     isNULLstr(argv[4]));
    strcpy(txtitype,     isNULLstr(argv[5]));
    strcpy(dupdate_bgn,  isNULLstr(argv[6]));
    strcpy(dupdate_end,  isNULLstr(argv[7]));
    strcpy(ch_dexpire,   isNULLstr(argv[8]));
    strcpy(outputf,      isNULLstr(argv[9]));

printf("DBName[%s]\n",DBName);

    rc = car153_get_db();
    if (rc != M_CM_OK)
       return rc;

    /* Create table car153_tmp1 */
    rc = ca153_create_temp();
    if (rc != M_CM_OK)
       return rc;

    rc = car153_prepare_data();
    if (rc != M_CM_OK)
       return rc;

    /*build report - ����*/
    rc = car153_build();
    if (rc != M_CM_OK)
       return rc;

}

long car153_prepare_data()
{
   $char iclass[3],icode[21],ftype_sp[3],nremark[120],dexpire[11],iupdate[7],dupdate[11],icreate[7],dcreate[11];
   $int  qday_permit_c = 0, qday_permit_v = 0;

   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == FALSE)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return FAIL;
   }

   strcpy(dupdate_bgn1,cm_to_infdate(dupdate_bgn));
   strcpy(dupdate_end1,cm_to_infdate(dupdate_end));

printf("dupdate_bgn1[%s]dupdate_end1[%s]\n",dupdate_bgn1,dupdate_end1);

	if( strcmp(trim(ch_dexpire),"0") == 0)
            strcpy(sWhere, "AND dexpire is null");
        else
            strcpy(sWhere, " ");

printf("sWhere=[%s]\n",sWhere);
printf("iclass[%s]icode[%s]ftype_sp[%s]\n",iclass,icode,ftype_sp);

	 sprintf_s(stmt, sizeof stmt,
		"SELECT iclass,icode,ftype_sp,nremark,qday_permit_c,qday_permit_v,dexpire,iupdate,date(dupdate) "
		"  FROM ca_permit   "
		" WHERE iclass matches '%s'           "
		"   AND icode matches '%s'            "
		"   AND ftype_sp matches '%s'         "
		"   AND date(dupdate) between '%s' and '%s' "
		"   %s                                "
		,txticlass,txticode,txtitype,dupdate_bgn1,dupdate_end1,sWhere);

printf("stmt[%s]\n", stmt);

          $PREPARE pre1 FROM $stmt;
          $DECLARE cur_pre1 CURSOR for pre1;
      	  $OPEN cur_pre1;

      	while(1)
      	{
         		$FETCH cur_pre1 INTO $iclass,$icode,$ftype_sp,$nremark,$qday_permit_c,$qday_permit_v,$dexpire,$iupdate,$dupdate;

         		if(SQLCODE == SQLNOTFOUND) break;

         		$SELECT iupdate,date(dupdate)
         		   INTO $icreate,$dcreate
         		   FROM ca_permit_log
         		  WHERE icode = $icode
         		    AND update_mode = 'I';

         		if(SQLCODE == SQLNOTFOUND) break;

printf("icreate[%s],dcreate[%s]\n",icreate,dcreate);

		$INSERT INTO car153_tmp1
          		     (iclass,icode,ftype_sp,nremark,qday_permit_c,qday_permit_v,dexpire,iupdate,dupdate,icreate,dcreate)
		      	VALUES
          		     ($iclass,$icode,$ftype_sp,$nremark,$qday_permit_c,$qday_permit_v,$dexpire,$iupdate,$dupdate,$icreate,$dcreate);

	}
        $CLOSE cur_pre1;
        $FREE cur_pre1;



     return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

long car153_build()
{
   int rc;
    char    sfilename[81],stitle[2048],stmt[2048];

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(sfilename,"�H�u�֭�]�w��[CAR153]");
    strcat(sfilename,"\n");

    strcpy(stitle,"\t�{���N��:CAR153\t�H�u�֭�]�w��\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");
    strcat(stitle,"\n");

    strcat(stitle,"\t�H�u�֭����O\t�H�u�֭�N��\t�H�u�֭�ʽ�\t�Ƶ�\t�j���I����鵲�ѼƱ���\t���N�I�L��ѼƱ���\t���Τ�\t��s�H��\t��s���\t���ɤH��\t���ɤ��\t");

    strcpy(stmt,"select *"
    		"  from car153_tmp1"
    		"  order by iclass");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);
    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf, " %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;

}

long ca153_create_temp()
{
   /* Create table car153_tmp1 */
   $create temp table car153_tmp1
	(
	 iclass			char(2),
	 icode			char(20),
	 ftype_sp		char(2),
	 nremark		varchar(120),
	 qday_permit_c		int,
	 qday_permit_v		int,
	 dexpire		char(10),
	 iupdate		char(6),
	 dupdate		char(10),
	 icreate		char(6),
	 dcreate		char(10)
	)with no log;

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

long car153_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }

   if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
      if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
         return M_CM_NOT_DBLIST;
   }

   return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
