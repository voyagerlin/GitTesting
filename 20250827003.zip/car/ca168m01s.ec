/**********************************************************************/
/*   program id   : car168m01s.ec                                      */
/*   program name : ���I�N�X�ɺ��@�@�~                                */
/*   date modified: 080284     2019/05/15                             */
/*   date modify  :                                                   */
/**********************************************************************/


#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "othmsgs.h"
#include "glscom.h"
$include decimal.h;
$include sqlca;
#include "safeclib.h"

$char itype[3],icode1[51],icode2[21],ncode1[256],ncode2[256],ncode3[2001],uorder[5];
$char icreate[31],dcreate[25],iupdate[31],dupdate[25];
$char sUserid[11], ncreate[31], nupdate[31];
$char itype_old[3], icode1_old[51], icode2_old[21];
$char uorder_sNO[5];

$char getfile[300];
$char errbuf[1024];
FILE *fp;
FILE *fplog;
static int recLen = 1024;
static char *bp;
char delimiter;
int offset;

long car168(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
    long rtncode;
    long car168_insert();
    long car168_multiple_query();
    long car168_update_exec();
    long car168_single_query();
	long car168_itype_single_query();
	long car168_batch_insert();
	long car168_batch_insert_init();
    char option;
    
    cm_buf_init(command);
    cm_buf_get("%c",&option);
    switch(option)
    {
		case 'I':
                 rtncode = car168_itype_single_query(reply);
                 break;
        case 'A':
                 rtncode = car168_insert(reply);
                 break;
        case 'Q':
                 rtncode = car168_single_query(reply);
                 break;
        case 'M':
                 rtncode = car168_multiple_query(reply);
                 break;
        case 'D':
        case 'U':
                 rtncode = car168_update_exec(reply,command,com_len);
                 break;
        case 'B':
                 rtncode = car168_batch_insert(reply);
                 break;
        default :
                 if(exitsub(reply,M_CM_WRONG_OPTION) == True)
                     return M_CM_WRONG_OPTION;
                 return apiRC;
    }
	
    return(rtncode);
}

long car168_insert(reply)
serverReply reply;
{
    
    $char DBName[5];
    
    int tmp_len;
    long MsgCode;
	int uorder_no=0;
    int i;

	cm_buf_get("%s %s %s %s %s %s %s %s", DBName, itype, icode1, icode2, ncode1, ncode2, ncode3, uorder);
    cm_buf_get("%s %s %s %s ", icreate, dcreate, iupdate, dupdate);           
      
    $WHENEVER SQLERROR GOTO errexit;
	
    if (db_select(DBName) == False) 
		return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
  
	$SELECT max(uorder) 
		INTO $uorder 
    FROM ca_code_data
	WHERE itype = $itype;
	
	strcpy(uorder , trim(uorder));
	printf("uorder:%s\n",uorder);
	
	uorder_no = atoi (uorder) +1;
	printf("uorder_no:%d\n",uorder_no);
	
	strcpy(uorder_sNO , trim(itoa(uorder_no))); 
	printf("uorder_sNO:%s\n",uorder_sNO);
  
    $BEGIN WORK;
	
    $WHENEVER SQLERROR GOTO errexit;
	
    $INSERT INTO ca_code_data (itype, icode1, icode2, ncode1, ncode2, 
                                 ncode3, uorder, icreate, dcreate, iupdate, 
                                 dupdate)
                         VALUES ($itype, $icode1, $icode2, $ncode1, $ncode2, 
                                 $ncode3, $uorder_sNO, $icreate, current, $iupdate, 
                                 current);
    
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    tmp_len = cm_buf_len(ReplyBuf);

	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
    {
        $WHENEVER SQLERROR CONTINUE;    
        $ROLLBACK WORK;
        return apiRC;
    }

    $WHENEVER SQLERROR GOTO errexit;
    $COMMIT WORK;
    return api_OKComplete;

errexit:
    MsgCode = SQLCODE;
    $WHENEVER SQLERROR CONTINUE;    
    $ROLLBACK WORK;
    if (SQLCODE != 0) MsgCode = SQLCODE;
		return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
 /*=====================================================*/
long car168_single_query(reply)
serverReply reply;
{
    $char  DBName[5], ncreate[31], nupdate[31];;
    
    int tmp_len;

    $char sDbirth[11];
    $varchar stmt[1024], stmt1[512];

    cm_buf_get(" %s %s %s %s" ,DBName ,itype ,icode1 ,icode2);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False) 
		return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

		
	$SELECT itype,icode1, icode2, ncode1, ncode2, ncode3, uorder, icreate, dcreate, iupdate, dupdate 
		INTO $itype, $icode1, $icode2, $ncode1, $ncode2, $ncode3, $uorder, $icreate, $dcreate, $iupdate, $dupdate
    FROM ca_code_data
	WHERE itype = $itype
	AND icode1  = $icode1
	AND icode2  = $icode2;
	

    if (SQLCODE == SQLNOTFOUND)
		return exitsub(reply,M_CM_NOT_FOUND) ? M_CM_NOT_FOUND : apiRC;

    $SELECT nname INTO $ncreate
      FROM  officer
      WHERE iofficer = $icreate;
      if(SQLCODE==SQLNOTFOUND) strcpy(ncreate," ");

    $SELECT nname INTO $nupdate
      FROM  officer
      WHERE iofficer = $iupdate;
      if(SQLCODE==SQLNOTFOUND) strcpy(nupdate," ");
     
    cm_buf_init(ReplyBuf); 
    cm_buf_put("%l",M_CM_OK);


    cm_buf_put("%s %s %s %s %s %s %s", itype, icode1, icode2,ncode1, ncode2, ncode3, uorder);
    cm_buf_put("%s %s %s %s %s %s", icreate, dcreate, iupdate, dupdate, ncreate, nupdate);
	strcpy(itype_old , trim(itype));
	strcpy(icode1_old , trim(icode1));
	strcpy(icode2_old , trim(icode2));

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;
    
errexit:
    return exitsub(reply, SQLCODE) ? SQLCODE : apiRC;
}
/*=======================================================*/
long car168_multiple_query(reply)
serverReply reply;
{

    $char stmt[1024],stmt1[1024];

    $char  DBName[5], stable[31], scolumn[101];

    char tmpbuf[4000];
    int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
    int i,total_count=0; 
    
	$char  Tmtbuf[1024];
    
    cm_buf_get("%s", DBName);
    cm_buf_get("%s %s %s", itype, icode1, icode2);
	
    $WHENEVER SQLERROR GOTO errexit;
	
    if (db_select(DBName) == False) 
		return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
     

  
    sprintf_s(stmt, sizeof stmt,
				  "SELECT c.itype, c.icode1, c.icode2, c.uorder, " 
				  " c.icreate, c.dcreate, c.iupdate ,c.dupdate ,o1.nname ,o2.nname "
				  " FROM ca_code_data c, officer o1, officer o2 "
                  " WHERE itype MATCHES '%s'"
				  "  AND icode1 MATCHES '%s'"
				  "  AND icode2 MATCHES '%s'"
				  "  AND c.icreate = o1.iofficer"
				  "  AND c.iupdate = o2.iofficer"
				"  AND c.iupdate = o2.iofficer"
				" ORDER BY itype ,uorder asc ", itype, icode1, icode2 );
				  
    $prepare p_stmt from $stmt;
    $declare q_cur  cursor for p_stmt;
    $OPEN q_cur;

    for ( ; ; )
    {
       $FETCH q_cur INTO $itype, $icode1, $icode2 ;
       
	   if (SQLCODE != 0) break;
       
       
       cm_buf_init(tmpbuf); 
       if ( count == 0 )
       {
           cm_buf_res_msg();             /* reserve for MsgCode and count */
           cm_buf_res_count();          
       }
       
	    /* strcpy(itype, cm_from_infdate_100(itype));*/
        cm_buf_put("%s", itype);
        cm_buf_put("%s", icode1);
        cm_buf_put("%s", icode2);


		
       tmp_len = cm_buf_len(tmpbuf);

       if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
       {
           memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
           repbuf_len += tmp_len;
           count++;
       }
       else                               /* more than 4K, send to client side */ 
       { 
           cm_buf_init(ReplyBuf);
           cm_buf_put_msg(M_CM_OK);
           cm_buf_put_count(count);
           
		   if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
           {
               $CLOSE q_cur;
               return apiRC;
           }
           else               /* clear ReplyBuf and count to start all over again */
           {
               replycnt++;
               if (replycnt == 10)   /* more than 30K, client cannot display,error */
               {
                   cm_buf_init(ReplyBuf);
                   cm_buf_put("%l",M_CM_OUT_SPACE);
                   tmp_len = cm_buf_len(ReplyBuf);
                   if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
                       return apiRC;
                   return M_CM_OUT_SPACE; 
               }
			   
               ReplyBuf[0] = '\0';
               count = 0;
               cm_buf_init(ReplyBuf);
               cm_buf_res_msg();           /* reserve for MsgCode and count */
               cm_buf_res_count();    
               
               repbuf_len = cm_buf_len(ReplyBuf);
               count++;
           }
       } 
    } 
	/* for loop */

    $CLOSE q_cur;
    $FREE q_cur;
    
    if (count > 0)   /* break out, at least one record is selected */
    {
        cm_buf_init(ReplyBuf);
        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(count);
        if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
            return apiRC;
        return api_OKComplete;
    }
    else            /* break out, not any row is found */
    {
        if(exitsub(reply,M_CM_NOT_FOUND) == True) 
            return M_CM_NOT_FOUND;
        else  
            return apiRC;
    } 
    
errexit:
    if(exitsub(reply,SQLCODE) == True) 
        return SQLCODE;
    else  
        return apiRC;
}

/*=======================================================*/

long car168_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
    
    $char  DBName[5];   
    $char old_itype[3], old_icode1[51], old_icode2[21], old_ncode1[256], old_ncode2[256], old_ncode3[2001], old_uorder[5];
	$char old_icreate[31], old_dcreate[25], old_iupdate[31], old_dupdate[25], old_ncreate[11], old_nupdate[11];
	$int  iRows;
    char option,*pos,*raw_ptr,*malloc(),cur_buf[MAX_REPLY_LEN],*comm;
    int tmp_len,raw_len;
	long  dummy;
    long MsgCode;
	$char stmt[20000];
	
    comm = (char *) command;
    cm_buf_init(command);
    cm_buf_get("%c %s %s %s %s ",&option, DBName, old_itype, old_icode1, old_icode2);
   
    if (db_select(DBName) == False)
		return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
	printf("6.\n");
	$BEGIN WORK;
    
    $WHENEVER SQLERROR GOTO errexit;
	  
    if ( option == 'D' )
    {
       $DELETE FROM ca_code_data
           WHERE itype  = $old_itype
			AND icode1 = $old_icode1
			AND icode2 = $old_icode2;

         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OK);
         tmp_len = cm_buf_len(ReplyBuf);
         if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
         {
             $WHENEVER SQLERROR CONTINUE;
             $ROLLBACK WORK;
             return apiRC;
         }

         $WHENEVER SQLERROR GOTO errexit;
         $COMMIT WORK;
         return api_OKComplete;
    }
    else if (option == 'U')
    {
         printf("OPTION U");

         cm_buf_init(command);
         cm_buf_get("%s %s %s %s %s %s %s %s %s ", &option, DBName, itype, icode1, icode2, ncode1, ncode2, ncode3, uorder);
		 cm_buf_get("%s %s  " , iupdate, dupdate);

		 strcpy(itype,  trim(itype));
         strcpy(icode1, trim(icode1));
         strcpy(icode2, trim(icode2));
         strcpy(ncode1, trim(ncode1));
         strcpy(ncode2, trim(ncode2));
         strcpy(ncode3, trim(ncode3));
         strcpy(uorder, trim(uorder));


		sprintf_s(stmt, sizeof stmt, "UPDATE ca_code_data    "
                     "   SET itype = '%s',     "
                     "       icode1 = '%s',   "
                     "       icode2 = '%s',   "
                     "       ncode1 = '%s',   "
                     "       ncode2 = '%s',   "
                     "       ncode3 = '%s',   "
                     "       uorder = '%s',   "
                     "       iupdate = '%s', "
					 "       dupdate = '%s' "
                     " WHERE itype = '%s'   "
                     "   AND icode1 = '%s'   "
                     "   AND icode2 = '%s'   ",
                     itype, icode1, icode2, ncode1, ncode2, ncode3,
                     uorder, iupdate, dupdate, itype_old, icode1_old, icode2_old);
					 
        printf("stmt=[%s]\n", stmt);
        $prepare p_sq from $stmt;
        $EXECUTE p_sq;

         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OK);
         tmp_len = cm_buf_len(ReplyBuf);

         if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
         {
             $WHENEVER SQLERROR CONTINUE;
             $ROLLBACK WORK;
             return apiRC;
         }

         $WHENEVER SQLERROR GOTO errexit;
         $COMMIT WORK;
         return api_OKComplete;
    }
    else
    {

         return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
    } 

errexit:
    $WHENEVER SQLERROR CONTINUE;
    MsgCode = SQLCODE;
    $ROLLBACK WORK;
    if (SQLCODE != 0) MsgCode = SQLCODE;
    return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
 /*=====================================================*/
long car168_itype_single_query(reply)
serverReply reply;
{
    $char  DBName[5] ;
	$char uorder[5];
	int uorder_no=0;
    int tmp_len;

    cm_buf_get(" %s %s " ,DBName ,itype );

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False) 
		return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

	
		
	$SELECT max(uorder) 
		INTO $uorder 
    FROM ca_code_data
	WHERE itype = $itype;

    if (SQLCODE == SQLNOTFOUND)
		return exitsub(reply,M_CM_NOT_FOUND) ? M_CM_NOT_FOUND : apiRC;
	
	strcpy(uorder , trim(uorder));
	
	uorder_no = atoi (uorder) +1;
	
	printf("uorder_no:[%d]\n",uorder_no);
	
    cm_buf_init(ReplyBuf); 
    cm_buf_put("%l",M_CM_OK);


    cm_buf_put("%d %s ", uorder_no ,itype);


    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;
    
errexit:
    return exitsub(reply, SQLCODE) ? SQLCODE : apiRC;
}
/*=====================================================*/
long car168_batch_insert(reply)
serverReply reply;
{
	$char DBName[5], stmt[2048], userid[11], errbuf2[256];
	char sApHome[40], filename[101], logname[101], logname1[101], cmd_str[2048];
	$int rc;
	int tmp_len, uorder_no = 0;
	$int totaldata = 0, datacount = 0, failflag = 0, failcnt = 0, successcnt = 0;
	
	printf("Now in car168_batch_insert\n");
	
	$WHENEVER SQLERROR GOTO errexit;
	
	cm_buf_get("%s %s", DBName, userid);
	
	rc = getApHome(sApHome);
	
	if(rc < 0)
	{
		strcpy(errbuf, "read Config file error!! --> getApHome\n");
		return rc;
	}
	
	printf("Now in after getApHome\n");
	
	sprintf_s(filename, sizeof filename, "%s/dat/car/car168_tmp.txt", sApHome);
	sprintf_s(logname1, sizeof logname1, "car168_log_%s.txt", userid);
	sprintf_s(logname, sizeof logname, "%s/rptftp/%s", sApHome, logname1);
	
	printf("Now in after arguments[%s]\n", filename);
	
	if(db_select(DBName) == False)
	{
		sprintf_s(errbuf, sizeof errbuf, "��Ʈw�L�k�}��[%s]\n", DBName);
		goto errexit;
	}
	
	printf("Now in after db_select\n");

	rc = car168_batch_insert_init();
	
	if(rc != M_CM_OK)
	{
		goto errexit;
	}
	
	sprintf_s(getfile, sizeof getfile, "%s/dat/car/car168_tmp.txt", sApHome);
	
	printf("Now in after create temp table\n");
	
	if((fp = fopen(getfile, "rt")) == NULL)
	{
		return SQLCODE;
	}
	
	printf("Now in after fopen\n");
	
	if((bp = malloc(recLen)) == NULL)
	{
		printf("System malloc failed !\n");
		return SQLCODE;
	}
	
	printf("Now in after malloc\n");
	
	delimiter = '\t';
	
	while(fgets(bp, recLen, fp))
	{
		if (feof(fp)) break;
		
		printf("[%s]\n", bp);
		
		int tabcnt = 0;
		datacount++;
		for(char *tabchk = bp; *tabchk != '\0'; tabchk++)
		{
			if(*tabchk == '\t')
			{
				tabcnt++;
			}
			/*printf("char = [%c], tabcount = [%d]\n", *tabchk, tabcnt);*/
		}
		
		if(tabcnt != 5)
		{
			sprintf_s(errbuf, sizeof errbuf, "��[%d]��: ��Ʈ榡������\n", datacount);
			$INSERT INTO car168_tmplog(inumber, fstatus, freason) VALUES($datacount, 'N', $errbuf);
			failflag = 1;
			failcnt++;
			continue;
		}
		
		
		offset = 0;
		GetData(itype,  sizeof(itype),  delimiter);
		GetData(icode1, sizeof(icode1), delimiter);
		GetData(icode2, sizeof(icode2), delimiter);
		GetData(ncode1, sizeof(ncode1), delimiter);
		GetData(ncode2, sizeof(ncode2), delimiter);
		GetData(ncode3, sizeof(ncode3), delimiter);
		
		/*strcpy(itype,   trim(itype));
		strcpy(icode1,  trim(icode1));
		strcpy(icode2,  trim(icode2));
		strcpy(ncode1,  trim(ncode1));
		strcpy(ncode2,  trim(ncode2));
		strcpy(ncode3,  trim(ncode3));*/
		
		printf("Now in after load file\n");
		
		/*printf("itype[%s], icode1[%s], icode2[%s], ncode1[%s], ncode2[%s], ncode3[%s]\n", itype, icode1, icode2, ncode1, ncode2, ncode3);*/
		
		$insert into car168_tmp(itype, icode1, icode2, ncode1, ncode2, ncode3, icreate, dcreate, iupdate, dupdate)
		        values ($itype, $icode1, $icode2, $ncode1, $ncode2, $ncode3, $userid, CURRENT, $userid, CURRENT);
	}
	
	totaldata = datacount;
	printf("totaldata = [%d]", totaldata);
	datacount = 1;
	printf("Now in before fclose\n");
	
	fclose(fp);
	free(bp);
	
	printf("Now in after fclose\n");
	
	sprintf_s(stmt, sizeof stmt, "SELECT itype, icode1, icode2, ncode1, ncode2, ncode3, icreate, dcreate, iupdate, dupdate "
								 " FROM car168_tmp");
	
	$PREPARE bi_cur1 FROM $stmt;
	$DECLARE bi_cur CURSOR FOR bi_cur1;
	$OPEN bi_cur;
	
	printf("Now in before fetch\n");
	
	$WHENEVER SQLERROR CONTINUE;
	
	printf("Now at fopen logname\n");
	
	while(1)
	{
		$FETCH bi_cur 
		INTO $itype, $icode1, $icode2, $ncode1, $ncode2, $ncode3, $icreate, $dcreate, $iupdate, $dupdate;
		
		if(SQLCODE == SQLNOTFOUND) break;
		
		printf("itype[%s], icode1[%s], icode2[%s], ncode1[%s], ncode2[%s], ncode3[%s], icreate[%s], dcreate[%s], iupdate[%s], dupdate[%s]\n", 
		        itype, icode1, icode2, ncode1, ncode2, ncode3, icreate, dcreate, iupdate, dupdate);
		
		/*strcpy(itype,   trim(itype));
		strcpy(icode1,  trim(icode1));
		strcpy(icode2,  trim(icode2));
		strcpy(ncode1,  trim(ncode1));
		strcpy(ncode2,  trim(ncode2));
		strcpy(ncode3,  trim(ncode3));
		strcpy(icreate, trim(icreate));
		strcpy(dcreate, trim(dcreate));
		strcpy(iupdate, trim(iupdate));
		strcpy(dupdate, trim(dupdate));*/
		
		$SELECT max(uorder) 
		INTO $uorder 
		FROM ca_code_data 
		WHERE itype = $itype;
		
		strcpy(uorder, trim(uorder));
		uorder_no = atoi(uorder) + 1;
		strcpy(uorder_sNO , trim(itoa(uorder_no))); 
		
		$INSERT INTO ca_code_data(itype, icode1, icode2, ncode1, ncode2, ncode3, uorder, icreate, dcreate, iupdate, dupdate) 
		 VALUES($itype, $icode1, $icode2, $ncode1, $ncode2, $ncode3, $uorder_sNO, $icreate, $dcreate, $iupdate, $dupdate);
		
		if(SQLCODE != 0)
		{
			switch(SQLCODE)
			{
				case -239:
					sprintf_s(errbuf2, sizeof errbuf2, "��ƭ���\n");
					break;
				
				default:
					sprintf_s(errbuf2, sizeof errbuf2, "%s\n", sqlca.sqlerrm);
					printf("%s", errbuf2);
					break;
			}

			while(1)
			{
				$SELECT * FROM car168_tmplog WHERE inumber = $datacount;
				
				if(SQLCODE == SQLNOTFOUND) break;
				
				else datacount++;
			}
			
			sprintf_s(errbuf, sizeof errbuf, "��[%d]��: %s", datacount, errbuf2);

			$INSERT INTO car168_tmplog(inumber, fstatus, freason) VALUES($datacount, 'N', $errbuf);
			failcnt++;
			failflag = 1;
		}
		else
		{
			while(1)
			{
				$SELECT * FROM car168_tmplog WHERE inumber = $datacount;
				
				if(SQLCODE == SQLNOTFOUND) break;
				
				else datacount++;
			}
			sprintf_s(errbuf, sizeof errbuf, "��[%d]��: ��J���\\\n", datacount);
			$INSERT INTO car168_tmplog(inumber, fstatus, freason) VALUES($datacount, 'Y', $errbuf);
			successcnt++;
		}
		
		printf("datacount = [%d], errbuf = [%s]\n", datacount, errbuf);
	}
	
	printf("Now in after fetch\n");
	
	fplog = fopen(logname, "w");
	
	sprintf_s(errbuf, sizeof errbuf, "�`�p��J���[%d]��	���\\[%d]��	����[%d]��\n", totaldata, successcnt, failcnt);
	fprintf(fplog, "%s", errbuf);
	
	sprintf_s(stmt, sizeof stmt, "SELECT freason FROM car168_tmplog WHERE fstatus = 'N' ORDER BY inumber");
	
	$PREPARE log_w1 FROM $stmt;
	$DECLARE log_w CURSOR FOR log_w1;
	$OPEN log_w;
	
	while(1)
	{
		$FETCH log_w INTO $errbuf;
		if(SQLCODE == SQLNOTFOUND) break;
		
		fprintf(fplog, "%s", trim(errbuf));
	}
	
	if(failflag == 0)
	{
		sprintf_s(errbuf, sizeof errbuf, "���槹��\n");
		fprintf(fplog, "%s", errbuf);
	}
	
	fclose(fplog);
	
	$CLOSE log_w;
	$FREE log_w;
	
	$CLOSE bi_cur;
	$FREE bi_cur;
	
	$DROP TABLE car168_tmp;
	$DROP TABLE car168_tmplog;
	
	rc = rptftpinsert(userid, "car168", logname1);
	
	if(rc != 0)
	{
		goto errexit;
	}
	
	cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    tmp_len = cm_buf_len(ReplyBuf);

    if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
         return apiRC;
    }
	
	return M_CM_OK;
	
errexit:
	cm_buf_init(ReplyBuf);
    cm_buf_put("%d",SQLCODE);
    tmp_len = cm_buf_len(ReplyBuf);
    return exitsub(reply, SQLCODE) ? SQLCODE : apiRC;
}
/*=====================================================*/
long car168_batch_insert_init()
{
	printf("Now in before create temp table\n");
	$whenever sqlerror goto errexit;
	
	$CREATE TEMP TABLE car168_tmp
	(
		itype     CHAR(2),
		icode1    VARCHAR(50),
		icode2    VARCHAR(20),
		ncode1    VARCHAR(255),
		ncode2    VARCHAR(255),
		ncode3    LVARCHAR(2000),
		icreate   VARCHAR(30),
		dcreate   DATETIME YEAR TO FRACTION(3),
		iupdate   VARCHAR(30),
		dupdate   DATETIME YEAR TO FRACTION(3)
	)with no log;
	
	$CREATE TEMP TABLE car168_tmplog
	(
		inumber   INTEGER,
		fstatus   CHAR(2),
		freason   VARCHAR(255)
	)with no log;
	
	$CREATE INDEX car168_tmplog_x1 on car168_tmplog (inumber);
	printf("Now in after create temp table\n");
	
	$TRUNCATE TABLE car168_tmp;
	$TRUNCATE TABLE car168_tmplog;
	return M_CM_OK;

errexit:
	printf("SQLERROR[%d]", SQLCODE);
	return SQLCODE;
}
/*=====================================================*/
long GetData(data, maxlen, delimiter)
char *data, delimiter;
int maxlen;
{
	int fori, pre_offset, cnt=0;

	data[0]='\0';
	pre_offset = offset;

	for (fori=pre_offset; bp[fori]!=0x00&&bp[fori]!=0x0d&&bp[fori]!=0x0a&&bp[fori]!=delimiter; fori++)
	{
		offset++;
		if (cnt < maxlen-1)
		{
			data[cnt]=bp[fori];
			cnt++;
		}
	}

	offset++; /* ���ܤU�@�� */
	if (cnt==0) data[cnt++]=0x20; /* �L��Ƶ��ť� */
	data[cnt]=0x00;
	printf("pre_offset[%d]offset[%d]len[%d]data[%s]\n", pre_offset, offset, cnt, data);
}