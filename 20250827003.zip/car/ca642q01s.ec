/**********************************************************************/
/*   program id   : ca642q01s.ec                                      */
/*   program name : �j���I�����ˮ֩��Ӫ�                              */
/*   date written : 2015/09/15 by 030344                              */
/*   files        : ply_relation                                      */
/*                                                                    */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"

#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"
$include decimal;
char delimiter;
int   count_db,k;
$char dentry[11],dentry_s[11];

$char itag_in[CA_TAG_NUM];

char  outputf[21];
$char userid[11];
$char DBName[05];
$char msgbuf[128];
$char falldb[2];

int offset;
char   sApHome[50];
FILE   *fp;
static char  *bp;
long   rtncode;

$char ipolicy3[5],ipolicy[21],nassured[121],itag[CA_TAG_NUM],iengine[CA_ENGINE_NUM];
$char icar_type[4],ncar_type[121],ibrand[10],nofficer[121];
$char ipolicy31[4],icar_type1[3],ibrand1[9],dpolicy[10];
$char dentry_cond[11],dentry_s_cond[11];
$char stmt[4096];
$int  mprem = 0;
int rc;
$char stmt_tmp1[1024],stmt_tmp2[1024];
DBinfo *list;

main(argc, argv)
int argc;
char **argv;
{

    batchinit();
    strcpy(DBName,    isNULLstr(argv[1]));
    strcpy(userid,    isNULLstr(argv[2]));
    strcpy(dentry_s,  isNULLstr(argv[3]));
    strcpy(dentry,    isNULLstr(argv[4]));
    strcpy(outputf,   isNULLstr(argv[5]));

printf("dentry_s[%s]dentry[%s];\n",dentry_s,dentry);

    rc = car642_get_db();
    if (rc != M_CM_OK)
       return rc;

    rtncode = getApHome(sApHome);
    if (rtncode < 0)
    {
        EWRITE(userid, M_CM_READ_CONFIG_ERR, "read Config file error!!");
        return FAIL;
    }


    /* Create table car642_tmp1 */
    rc = ca642_create_temp();
    if (rc != M_CM_OK)
       return rc;


printf("falldb=[%s]\n",falldb);


    rc = car642_prepare_data();
    if (rc != M_CM_OK)
       return rc;


    /*build report - ����*/
    rc = car642_build();
    if (rc != M_CM_OK)
       return rc;

}


/*--------------------------------------------------------------------*/
long car642_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }

   if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
      if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
         return M_CM_NOT_DBLIST;
   }

   return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

long car642_prepare_data()
{

   strcpy(dentry_cond,cm_to_infdate(dentry));
   strcpy(dentry_s_cond,cm_to_infdate(dentry_s));


   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == FALSE)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return FAIL;
   }

printf("prepared data, dentry_cond[%s]dentry_s_cond[%s]\n",dentry_cond,dentry_s_cond);



/*******************�s��/��O(���t����14��21)***********************/
	 sprintf_s(stmt, sizeof stmt,
		"SELECT to_char(b.dpolicy,'%%Y')::integer - 1911 || '/' || to_char(b.dpolicy,'%%m/%%d'), "
		"       a.ipolicy[1,3], a.ipolicy, a.nassured ,b.ibrand,  "
		"       a.iengine,b.icar_type,  "
		"       (SELECT ncode FROM car_type WHERE fclass = '1' AND icode = b.icar_type),  "
		"       a.itag, (SELECT nname FROM officer WHERE iofficer = b.iofficer),   "
		"       (b.mdmg_prem+b.mlia_prem)        "
		"  FROM policy a,ply_relation b          "
		" WHERE a.ipolicy = b.ipolicy            "
		"   AND b.fcard_class = '1'              "
		"   AND b.icar_flag = '1'                "
		"   AND b.icar_type NOT IN ('14','21')   "
		"   AND (trim(b.ilast_ply) = '' OR b.ilast_ply IS NULL) "
		"   AND b.dpolicy BETWEEN '%s' and '%s' ",dentry_s_cond,dentry_cond);

printf("stmt[%s]\n", stmt);

          $PREPARE pre1_1 FROM $stmt;
          $DECLARE cur_pre1_1 CURSOR for pre1_1;
      	  $OPEN cur_pre1_1;

      	while(1)
      	{
         	$FETCH cur_pre1_1 INTO $dpolicy,$ipolicy31,$ipolicy,$nassured,$ibrand1,
         			       $iengine,$icar_type1,$ncar_type,$itag,$nofficer,
         			       $mprem;

         	if(SQLCODE == SQLNOTFOUND) break;

         	/**���X�Ĥ@�X��0�A�����bexcel show �X*/
      		strcpy(ipolicy3, "�");
      		strcat(ipolicy3,trim(ipolicy31));

      		strcpy(icar_type, "�");
      		strcat(icar_type,trim(icar_type1));

      		strcpy(ibrand, "�");
      		strcat(ibrand,trim(ibrand1));

		$INSERT INTO car642_tmp1
          		     (dpolicy,ipolicy3,ipolicy,nassured,ibrand,iengine,icar_type,ncar_type,
 			      itag,nofficer,mprem)
		      	VALUES
          		     ($dpolicy,$ipolicy3,$ipolicy,$nassured,$ibrand,
         		      $iengine,$icar_type,$ncar_type,$itag,$nofficer,
         		      $mprem);

	}
        $CLOSE cur_pre1_1;
        $FREE cur_pre1_1;


/*******************���(����14 �u����/����21 ������)***********************/
	 sprintf_s(stmt, sizeof stmt,
		"SELECT to_char(b.dpolicy,'%%Y')::integer - 1911 || '/' || to_char(b.dpolicy,'%%m/%%d'),  "
		"       a.ipolicy[1,3], a.ipolicy, a.nassured ,b.ibrand,  "
		"       a.iengine,b.icar_type,  "
		"       (SELECT ncode FROM car_type WHERE fclass = '1' AND icode = b.icar_type),  "
		"       a.itag, (SELECT nname FROM officer WHERE iofficer = b.iofficer),   "
		"       (b.mdmg_prem+b.mlia_prem)        "
		"  FROM policy a,ply_relation b          "
		" WHERE a.ipolicy = b.ipolicy            "
		"   AND b.fcard_class = '1'              "
		"   AND b.icar_type IN ('14','21')       "
		"   AND b.dpolicy BETWEEN '%s' and '%s' ",dentry_s_cond,dentry_cond);

printf("stmt[%s]\n", stmt);

          $PREPARE pre1_2 FROM $stmt;
          $DECLARE cur_pre1_2 CURSOR for pre1_2;
      	  $OPEN cur_pre1_2;

      	while(1)
      	{
         	$FETCH cur_pre1_2 INTO $dpolicy,$ipolicy31,$ipolicy,$nassured,$ibrand1,
         			       $iengine,$icar_type1,$ncar_type,$itag,$nofficer,
         			       $mprem;

         	if(SQLCODE == SQLNOTFOUND) break;

         	/**���X�Ĥ@�X��0�A�����bexcel show �X*/
      		strcpy(ipolicy3, "�");
      		strcat(ipolicy3,trim(ipolicy31));

      		strcpy(icar_type, "�");
      		strcat(icar_type,trim(icar_type1));

      		strcpy(ibrand, "�");
      		strcat(ibrand,trim(ibrand1));

		$INSERT INTO car642_tmp2
          		     (dpolicy,ipolicy3,ipolicy,nassured,ibrand,iengine,icar_type,ncar_type,
 			      itag,nofficer,mprem)
		      	VALUES
          		     ($dpolicy,$ipolicy3,$ipolicy,$nassured,$ibrand,
         		      $iengine,$icar_type,$ncar_type,$itag,$nofficer,
         		      $mprem);

	}
        $CLOSE cur_pre1_2;
        $FREE cur_pre1_2;



     return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/

long car642_build()
{
   int rc;
    char    sfilename[81],stitle[2048],stmt[2048];

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(sfilename,"�s��/��O(���t����14/21)[CAR642]");

    strcpy(stitle,"\t�{���N��:CAR642\t�s��/��O(���t����14��21)\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");

    strcat(stitle,"\tñ����\t���\t�O�渹�X\t�Q�O�I�H\t�t�P�����N��\t�������X\t");
    strcat(stitle,"�X��N��\t�X��W��\t�P�Ӹ��X\t�g��H\t��X��O�O\t");


    strcpy(stmt,"select dpolicy,ipolicy3,ipolicy,nassured,ibrand,iengine,  "
         	"       icar_type,ncar_type,itag,nofficer,mprem  "
    		"  from car642_tmp1 "
    		"  order by dpolicy");

    rc = unload_file(outputf,"A",sfilename,stitle,stmt);
    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }


    strcpy(sfilename,"���(����14 �u����/����21 ������)[CAR642]");

    strcpy(stitle,"\t�{���N��:CAR642\t���(����14/����21)\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");

    strcat(stitle,"\tñ����\t���\t�O�渹�X\t�Q�O�I�H\t�t�P�����N��\t�������X\t");
    strcat(stitle,"�X��N��\t�X��W��\t�P�Ӹ��X\t�g��H\t��X��O�O\t");

    strcpy(stmt,"select dpolicy,ipolicy3,ipolicy,nassured,ibrand,iengine,  "
         	"       icar_type,ncar_type,itag,nofficer,mprem  "
    		"  from car642_tmp2 "
    		"  order by dpolicy");

    rc = unload_file(outputf,"B",sfilename,stitle,stmt);
    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }




    return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;

}

long ca642_create_temp()
{
   /* Create table car642_tmp1 �s��/��O(���t����14��21) */
   sprintf_s(stmt_tmp1, sizeof stmt_tmp1,"create temp table car642_tmp1 "
	 "( "
	 " dpolicy    		char(10), "
	 " ipolicy3               char(4), "
     "     ipolicy    		char(20), "
	 " nassured   		varchar(120), "
	 " ibrand			char(9), "
	 " iengine    		char(%d), "
	 " icar_type  		char(3), "
	 " ncar_type              varchar(120), "
	 " itag       		char(%d), "
	 " nofficer          	varchar(120), "
	 " mprem                  int "
	 ")with no log;",CA_ENGINE_NUM-1,CA_TAG_NUM-1);
     $PREPARE stmp1 FROM $stmt_tmp1;
     $EXECUTE stmp1;

   /* Create table car642_tmp1 ���(����14 �u����/����21 ������) */
   sprintf_s(stmt_tmp2, sizeof stmt_tmp2,"create temp table car642_tmp2 "
	 "( "
	 " dpolicy    		char(10), "
	 " ipolicy3               char(4), "
     "     ipolicy    		char(20), "
	 " nassured   		varchar(120), "
	 " ibrand			char(9), "
	 " iengine    		char(%d), "
	 " icar_type  		char(3), "
	 " ncar_type              varchar(120), "
	 " itag       		char(%d), "
	 " nofficer          	varchar(120), "
	 " mprem                  int "
	 ")with no log;",CA_ENGINE_NUM-1,CA_TAG_NUM-1);
     $PREPARE stmp2 FROM $stmt_tmp2;
     $EXECUTE stmp2;

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}