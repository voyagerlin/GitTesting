#include <stdio.h>
#include "api_xsrv.h"
#include "sql.h"
#include "datetime.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "print.h"
#include "is_def.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"

EXEC SQL include sqlca;
EXEC SQL BEGIN DECLARE SECTION;
     char LHsDBName[42];
     char LHsServer[21];
     char LHsDbName[42];
     char LHsConnectDB[42];
EXEC SQL END DECLARE SECTION;

char  LsApHome[30];

int Mutile_Process();

main()
{
    int LiRtnCode;

    LiRtnCode = 0;

    LiRtnCode = getApHome(LsApHome);
    if(LiRtnCode < 0)
    {
         printf("read Config file error!!-->getApHome\n");
    }
    printf("LsApHome:[%s]\n",LsApHome);

    LiRtnCode = getInitServerDB(LHsDBName);
    if(LiRtnCode < 0)
    {
         printf("read Config file error!!-->getInitServerDB\n");
    }
    printf("LHsDBName:[%s]\n",LHsDBName);

    EXEC SQL DATABASE :LHsDBName;

    printf("connect database:[%s]\n",LHsDBName);

    EXEC SQL DECLARE SERVERTBL_302 CURSOR FOR

    SELECT server, dbname
      FROM servertbl
     WHERE branch != 'S1';

    EXEC SQL OPEN SERVERTBL_302;

    while(1)
    {
        EXEC SQL FETCH SERVERTBL_302

        into :LHsServer, :LHsDbName;

        if(SQLCODE == SQLNOTFOUND)
	{
	    break;
	}

	sprintf_s(LHsConnectDB, sizeof LHsConnectDB, "%s@%s", rtrim(LHsDbName), LHsServer);	
	Mutile_Process();
    }

    EXEC SQL CLOSE SERVERTBL_302;
    EXEC SQL FREE SERVERTBL_302;
}

Mutile_Process()
{
EXEC SQL BEGIN DECLARE SECTION;
	char stmt_txt[1024];
	char LHsIpolicy[21];
	char LHsIcard[21];
	char LHsDply_Begin[11];
	int  LHiCnt;
EXEC SQL END DECLARE SECTION;

    LHiCnt = 0;

    memcpy(LHsDply_Begin, "10/03/2000", 10);

    sprintf_s(stmt_txt, sizeof stmt_txt,
     	    "%s %s%s",
	    "select ipolicy, icard, dply_begin, linnum from",
            LHsConnectDB,
            ":policy_302 where dply_begin = ? ");

    EXEC SQL prepare slct_id from :stmt_txt;
    EXEC SQL declare policy_302_cur cursor for slct_id;
    EXEC SQL open policy_302_cur using :LHsDply_Begin;

    while(1)
    {
    	EXEC SQL fetch policy_302_cur into :LHsIpolicy, :LHsIcard, :LHsDply_Begin, :LHiCnt;

    	if(SQLCODE==SQLNOTFOUND)
	    break;
    	else
        {
    	    printf("====  LHsConnectDB = [%s] \n\n", LHsConnectDB);
    	    printf("====  LHiCnt = [%s] \n\n", LHsIpolicy);
    	    printf("====  LHiCnt = [%s] \n\n", LHsIcard);
    	    printf("====  LHiCnt = [%s] \n\n", LHsDply_Begin);
    	    printf("====  LHiCnt = [%d] \n\n", LHiCnt);
        }
    }

    EXEC SQL close policy_302_cur;
    EXEC SQL close slct_id;
    EXEC SQL free policy_302_cur;
    EXEC SQL free slct_id;
}
