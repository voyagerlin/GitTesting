/************************************************/
/*                                              */
/*   PROGRAM : ca104m01s.ec by Pei-Chow Chen    */
/*                                              */
/*   PURPOSE : server side standard program     */
/*                                              */
/************************************************/

#include <stdio.h>
#include <string.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "commsgs.h"
#include "carmsgs.h"
$include sqlca;
#include "safeclib.h"


long car104(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car104_insert(),car104_single_query(),car104_multiple_query(),
      car104_update_exec();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'A':
           rtncode=car104_insert(reply);
           break;
  case 'Q':
           rtncode=car104_single_query(reply);
           break;
  case 'M':
           rtncode=car104_multiple_query(reply);
           break;
  case 'D':
  case 'U':
           rtncode=car104_update_exec(reply,command,com_len);
           break;
  default :
           if(exitsub(reply,M_CM_WRONG_OPTION) == True)
             return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}

long car104_insert(reply)
serverReply reply;
{
 $char DBName[5],i_fclass[2],i_icode[3],i_ncode[11];
 $char i_icar_grp[2],i_fcar_class[2];
 $char i_fpt[2],i_maxqpt[11],i_minqpt[11];   /* Modified by Julia Han in 2007/08/09 */
 $char i_maxcylinder[11],i_mincylinder[11];  /* Modified by Julia Han in 2007/08/09 */
 $double maxqpt,minqpt;
 $double maxcylinder,mincylinder;/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/ 
 dec_t dec_cylinder_max,dec_cylinder_min;/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��  */ 
 $char iupdate[11];
 int tmp_len;
   DBinfo *list;
   int i, j, is_add_fail=0, api_f;
   $char stmt_buf[300];
 long MsgCode;
 dec_t    dec_maxqpt,dec_minqpt;
 
 cm_buf_get("%s %s %s %s %s %s %s %s %s %s %s %s",DBName,i_fclass,i_icode,i_ncode,
                                i_fcar_class,i_icar_grp,i_fpt,i_maxqpt,i_minqpt,
                                i_maxcylinder,i_mincylinder,iupdate);
                                
 /* 1080902001-SC1-�Ʈ�q�X�W�p���I2�� 
 maxcylinder = atol(i_maxcylinder);
 mincylinder = atol(i_mincylinder);*/ 
 
 deccvasc(i_maxcylinder,10,&dec_cylinder_max);
 dectodbl(&dec_cylinder_max,&maxcylinder);               

 deccvasc(i_mincylinder,10,&dec_cylinder_min);
 dectodbl(&dec_cylinder_min,&mincylinder);    
 
 printf("\n1080902001-maxcylinder[%f]mincylinder[%f]\n",maxcylinder,mincylinder);
 deccvasc( i_maxqpt, 10, &dec_maxqpt);
 dectodbl( &dec_maxqpt, &maxqpt);
 deccvasc( i_minqpt, 10, &dec_minqpt);
 dectodbl( &dec_minqpt, &minqpt); 
       	
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
  }


 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
  {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
  }

 $BEGIN WORK;
 for(j=0;j<i;j++)
 {
  sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO %s:car_type "
         " (fclass,icode,ncode,fcar_class,icar_grp,fpt,max_qpt,min_qpt, "
         " max_cylinder,min_cylinder,iupdate,dupdate) "
	 " VALUES (?,?,?,?,?,?,?,?,?,?,?,current)",list[j].dbname);

  $PREPARE a_id FROM $stmt_buf;
  if(SQLCODE != 0)
   {
    is_add_fail = 1;
    break;
   }
  $EXECUTE a_id USING $i_fclass,$i_icode,$i_ncode,$i_fcar_class,$i_icar_grp,
  							  $i_fpt,$maxqpt,$minqpt,$maxcylinder,$mincylinder,$iupdate;
  if(SQLCODE != 0)
   {
    is_add_fail = 1;
    break;
   }
  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);
  tmp_len = cm_buf_len(ReplyBuf);
  if( j == i-1 )
     api_f = api_OKComplete;
  else
     api_f = api_OK;

  if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
    {
     is_add_fail = 2;
     break;
    }  
#ifdef DEBUG
printf("Insert %d\n", j+1);
#endif
 } /* for loop */

 if( is_add_fail == 1 ) goto errexit;

 if( is_add_fail == 2 ) 
  {
   $ROLLBACK WORK;
   return apiRC;
  }


 $WHENEVER SQLERROR GOTO errexit;

 $COMMIT WORK;
 return api_OKComplete;

errexit:
   MsgCode = SQLCODE;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if (SQLCODE != 0) MsgCode = SQLCODE;		/* rollback fail */
   if(exitsub(reply,MsgCode) ==	True)
     return MsgCode;
   else
     return apiRC;
}

long car104_single_query(reply)
serverReply reply;
{
 $char DBName[5],i_fclass[2],i_icode[3],i_ncode[11];
 $char i_icar_grp[2],i_fcar_class[2],i_fpt[2];
 $double i_maxqpt=0,i_minqpt=0;
 $double i_maxcylinder=0,i_mincylinder=0;/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��  long->double*/ 
 $char iupdate[11],dupdate[20];  /* Modified by Julia Han in 2007/08/09 */
 $char sMincylinder[9],sMaxcylinder[9];/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��  */ 
 int tmp_len;
 char strmax[20],strmin[20];

 cm_buf_get("%s %s %s",DBName,i_fclass,i_icode);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 } 
 
 $SELECT ncode, icar_grp, fcar_class, fpt, max_qpt, min_qpt, max_cylinder, min_cylinder, iupdate, dupdate
  INTO $i_ncode, $i_icar_grp, $i_fcar_class, $i_fpt, $i_maxqpt, $i_minqpt,
       $i_maxcylinder, $i_mincylinder, $iupdate, $dupdate
  FROM car_type
  WHERE fclass=$i_fclass AND icode=$i_icode;

 if(SQLCODE==SQLNOTFOUND)
 {
  if(exitsub(reply,M_CM_NOT_FOUND) == True)       /*?*/
    return M_CM_NOT_FOUND;                        /*?*/
  else
    return apiRC;
 }
 
 sprintf_s(strmax, sizeof strmax,"%.2f",i_maxqpt);
 sprintf_s(strmin, sizeof strmin,"%.2f",i_minqpt);
 /*strcpy(sMaxcylinder,"");*//* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/
 sMaxcylinder[0]='\0';
 sprintf_s(sMaxcylinder, sizeof sMaxcylinder,"%8.2f",i_maxcylinder);
 strncpy(sMaxcylinder,trim(sMaxcylinder),9);
 /*strcpy(sMincylinder,"");*//* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/
 sMincylinder[0]='\0';
 sprintf_s(sMincylinder, sizeof sMincylinder,"%8.2f",i_mincylinder);
 strncpy(sMincylinder,trim(sMincylinder),9);
 
 cm_buf_init(ReplyBuf);
 cm_buf_put("%l %s %s %s %s %s %s %s %s %s %s %s %s",M_CM_OK,i_fclass,i_icode,i_ncode,
                                        i_fcar_class,i_icar_grp,i_fpt,strmax,strmin,
                                        sMaxcylinder,sMincylinder,iupdate,dupdate);
 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

 errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}

long car104_multiple_query(reply)
serverReply reply;
{
 $char DBName[5],i_fclass[2],i_icode[3],i_ncode[11];
 $char i_icar_grp[2],i_fcar_class[2];

 $char key_fclass[2],key_icode[3];

 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0;

 cm_buf_get("%s %s %s",DBName,key_fclass,key_icode);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 $DECLARE q_cur CURSOR FOR
    SELECT ncode, fclass, icode
    INTO $i_ncode, $i_fclass, $i_icode
    FROM car_type
    WHERE fclass matches $key_fclass AND icode matches $key_icode
    ORDER BY fclass;

 $OPEN q_cur;

 for(;;)
  {
    $FETCH q_cur;
    if (SQLCODE != 0) break;

    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();
     }
    cm_buf_put("%s %s %s",i_fclass,i_icode,i_ncode);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
        $CLOSE q_cur;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s %s",i_fclass,i_icode,i_ncode);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
  } /* for loop */

 $CLOSE q_cur;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
    if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
      return M_CM_NOT_FOUND;                               /*?*/
    else
      return apiRC;
  }

 errexit:
   if(exitsub(reply,SQLCODE) == True)
     return SQLCODE;
   else
     return apiRC;
}

long car104_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 $char DBName[5],i_fclass[2],i_icode[3],i_ncode[11];
 $char i_icar_grp[2],i_fcar_class[2],i_fpt[2];
 $char str_maxqpt[11],str_minqpt[11],str_maxcylinder[11],str_mincylinder[11];
 $double i_maxqpt,i_minqpt;
 $double i_maxcylinder,i_mincylinder;  /* Modified by Julia Han in 2007/08/09 *//* 1080902001-SC1-�Ʈ�q�X�W�p���I2��  long->double*/ 

 $char cur_fclass[2],cur_icode[3],cur_ncode[11];
 $char cur_icar_grp[2],cur_fcar_class[2],cur_fpt[2];
 $char strcur_maxqpt[11],strcur_minqpt[11],strcur_maxcylinder[11],strcur_mincylinder[11];
 $double cur_maxqpt,cur_minqpt;
 $double cur_maxcylinder,cur_mincylinder;/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��  long->double*/ 
 $char iupdate[11],dupdate[20],cur_dupdate[20]; /* Modified by Julia Han in 2007/08/09 */
 dec_t dec_cylinder_max,dec_cylinder_min;/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��  */ 
 
 $char old_fclass[2],old_icode[3];
 
  char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
  int tmp_len,raw_len;
  long dummy;
  long MsgCode;
  DBinfo *list;
  int i, j, is_upd_fail=0,is_del_fail=0;
  int qlen=0;
  $char stmt_buf[300];
  dec_t    dec_maxqpt,dec_minqpt,dec_curmaxqpt,dec_curminqpt;

 	comm = (char *) command;
	cm_buf_init(command);
	cm_buf_get("%c %s",&option,DBName);

	$WHENEVER SQLERROR GOTO errexit;

 	if (db_select(DBName) == False)
    	{
    		if (exitsub(reply,M_CM_DB_NOTOPEN) == True) return M_CM_DB_NOTOPEN;
    		else	return apiRC;
    	}

 	if ( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
    	{
    		if (exitsub(reply,M_CM_NOT_DBLIST) == True)	return M_CM_NOT_DBLIST;
    		return apiRC;
    	}
	
	/* get old record info from command buffer */

	memcpy(&raw_len,&comm[com_len],sizeof(int));
	pos = &comm[com_len+sizeof(int)];
	raw_ptr = malloc(raw_len);

 	if (raw_ptr != (char*)0) {
    		memcpy(raw_ptr,pos,raw_len);
	}
 	else
    	{
    		if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */
    			return M_CM_NOT_MALLOC;
    		else	return apiRC;
    	}
   
 	cm_buf_init(raw_ptr);          /* get index key from old record */
 	
	cm_buf_get("%l %s %s %s %s %s %s %s %s %s %s %s %s",&dummy, i_fclass, i_icode, i_ncode, 
	             i_fcar_class, i_icar_grp, i_fpt, str_maxqpt, str_minqpt,
	             str_maxcylinder, str_mincylinder, iupdate, dupdate);
  							
 	$BEGIN WORK;
 	$WHENEVER SQLERROR GOTO errexit;
 	/* table lock is necessary to avoid concurrent update problems */
 	$LOCK TABLE ca_id_officer IN SHARE MODE;

 	$SELECT dupdate
      INTO $cur_dupdate
      FROM car_type
  		WHERE fclass=$i_fclass AND icode=$i_icode;
  
 	if (SQLCODE == SQLNOTFOUND)
        {
    		$WHENEVER SQLERROR CONTINUE;
    		$ROLLBACK WORK;
    		if (exitsub(reply,M_CM_NOT_FOUND) == True)
        		return M_CM_NOT_FOUND;
    		else
        		return apiRC;
    	}
		
	free(raw_ptr);

 
printf("org. dentry=[%s],db. dentry[%s]\n",dupdate,cur_dupdate);

 	if (strcmp(dupdate,cur_dupdate) != 0)
        {
    		$WHENEVER SQLERROR CONTINUE;
    		$ROLLBACK WORK;
    		if(exitsub(reply,M_CM_NOT_EQUAL) == True)
        		return M_CM_NOT_EQUAL;
    		else
        		return apiRC;
    	}
    	
 	$WHENEVER SQLERROR GOTO errexit;

 	/* equal, then exec DB operation */

 	 if ( option == 'D' )
  	 {
   	for(j=0;j<i;j++)
   	{
    		sprintf_s(stmt_buf, sizeof stmt_buf,"DELETE FROM %s:car_type WHERE fclass=? "
		     						" AND icode=? " ,list[j].dbname); 
    		$PREPARE d_id FROM $stmt_buf;
    		if(SQLCODE != 0)
     		{
      		is_del_fail = 1; 
      		break;
     		}
    		$EXECUTE d_id USING $i_fclass, $i_icode;
    		if(SQLCODE != 0)
     		{
      		is_del_fail = 1; 
      		break;
     		}
   	 }/* for loop */

   	 if( is_del_fail ) goto errexit;
   
   	 cm_buf_init(ReplyBuf);
   	 cm_buf_put("%l",M_CM_OK);
   	 tmp_len = cm_buf_len(ReplyBuf);
   	 
   	 if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    	 {
     		$WHENEVER SQLERROR CONTINUE;
     		$ROLLBACK WORK;
     		return apiRC;
    	 }  
	
   	$WHENEVER SQLERROR GOTO errexit;
   	$COMMIT WORK;
   	return api_OKComplete;
  	}
 	else if (option == 'U')
   {	
   	cm_buf_init(command);
   	cm_buf_get("%c %s",&option,DBName);
   	cm_buf_get("%s %s %s %s %s %s %s %s %s %s %s", cur_fclass, cur_icode, cur_ncode, 
  							cur_fcar_class, cur_icar_grp, cur_fpt, strcur_maxqpt,
  							strcur_minqpt,strcur_maxcylinder,strcur_mincylinder,iupdate);
  							
        /* 1080902001-SC1-�Ʈ�q�X�W�p���I2��
  		cur_maxcylinder = atof(strcur_maxcylinder);  
 		cur_mincylinder = atof(strcur_mincylinder);*/ 
        
        

        deccvasc(strcur_maxcylinder,10,&dec_cylinder_max);
        dectodbl(&dec_cylinder_max,&cur_maxcylinder);               
        

        deccvasc(strcur_mincylinder,10,&dec_cylinder_min);
        dectodbl(&dec_cylinder_min,&cur_mincylinder);    


 	deccvasc( strcur_maxqpt, 10, &dec_curmaxqpt);
 	dectodbl( &dec_curmaxqpt, &cur_maxqpt);
 		

 	deccvasc( strcur_minqpt, 10, &dec_curminqpt);
 	dectodbl( &dec_curminqpt, &cur_minqpt);
 		
printf("maxqpt[%f],minqpt[%f]\n",cur_maxqpt,cur_minqpt);	
  							  							  		                              
   	$WHENEVER SQLERROR CONTINUE;
   	for(j=0;j<i;j++)
   	{
    		sprintf_s(stmt_buf, sizeof stmt_buf,"UPDATE %s:car_type  "
   		" SET (fclass,icode,ncode,fcar_class,icar_grp,fpt,max_qpt,min_qpt, "
   		"    max_cylinder,min_cylinder,iupdate,dupdate) "
		" = (?,?,?,?,?,?,?,?,?,?,?,current) WHERE fclass= ? AND icode = ?",list[j].dbname);

    		$PREPARE u_id FROM $stmt_buf;
    		
    		if(SQLCODE != 0)
     		{
      		is_upd_fail = 1;
      		break;
     		}
    		$EXECUTE u_id USING $cur_fclass,$cur_icode,$cur_ncode,$cur_fcar_class,
		                       $cur_icar_grp,$cur_fpt,$cur_maxqpt,$cur_minqpt,
		                       $cur_maxcylinder,$cur_mincylinder,$iupdate,$i_fclass,$i_icode;
    		if(SQLCODE != 0)
     		{
      		is_upd_fail = 1;
      		break;
     		}
    		if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
     		{
  				sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO %s:car_type "
         			 " (fclass,icode,ncode,icar_grp,fcar_class,fpt, "
         			 " max_qpt,min_qpt,max_cylinder,min_cylinder,iupdate,dupdate) "
	 				 " VALUES (?,?,?,?,?,?,?,?,?,?,?,current)",list[j].dbname);	 

      		$PREPARE ua_id FROM $stmt_buf;
      		if(SQLCODE != 0)
       		{
        			is_upd_fail = 1; 
        			break;
       		}
      		$EXECUTE ua_id USING $cur_fclass,$cur_icode,$cur_ncode,$cur_fcar_class,
      									$cur_icar_grp,$cur_fpt,$cur_maxqpt,$cur_minqpt,
      									$cur_maxcylinder,$cur_mincylinder,$iupdate;
      		if(SQLCODE != 0)
       		{
        			is_upd_fail = 1; 
        			break;
       		}
     		}
   	} /* for loop */

   	if( is_upd_fail ) goto errexit;


   	cm_buf_init(ReplyBuf);
   	cm_buf_put("%l",M_CM_OK);
   	tmp_len = cm_buf_len(ReplyBuf);
   	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    	{
     		$WHENEVER SQLERROR CONTINUE;
     		$ROLLBACK WORK;
     		return apiRC;
    	}  

   	$WHENEVER SQLERROR GOTO errexit;
   	$COMMIT WORK;
   	return api_OKComplete;
  } else {
   	if(exitsub(reply,M_CM_WRONG_OPTION) == True) 
    		return M_CM_WRONG_OPTION;
   	else  
    		return apiRC;
  } 

errexit:
   MsgCode = SQLCODE;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if (SQLCODE != 0) MsgCode = SQLCODE;		/* rollback fail */
   if(exitsub(reply,MsgCode) ==	True)
     return MsgCode;
   else
     return apiRC;
}
