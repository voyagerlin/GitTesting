/************************************************/
/*                                              */
/*   PROGRAM : ca134m01s.ec by Thomas Lo        */
/*                                              */
/*   DATE    : 1998/04/15                       */
/*                                              */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;
#include <decimal.h>
#include "safeclib.h"


long car134(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car134_insert(),car134_single_query(),car134_update_exec();
 long car134_multiple_query();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'A':
           rtncode=car134_insert(reply);
           break;
  case 'Q':
           rtncode=car134_single_query(reply);
           break;
  case 'M':
           rtncode=car134_multiple_query(reply);
           break;
  case 'D':
  case 'U':
           rtncode=car134_update_exec(reply,command,com_len);
           break;
  default :
           if(exitsub(reply,M_CM_WRONG_OPTION) == True)
            return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}

/*-----------------------------------------------------------------*/
long car134_insert(reply)
serverReply reply;
{
 $char DBName[5],k_drate[10],drate[12];
 $int  qclass;  
 $double pcomp_factor;
 dec_t dec_pcomp_factor;
 char  tmp_pcomp_factor[21];
 $char fcard_class[2], fcar_class[3];
 int tmp_len;
 long MsgCode;
 DBinfo *list;
 int i, j, is_add_fail=0, api_f;
 $char stmt_buf[300];

 cm_buf_get("%s %s %d %s %s %s",DBName,fcard_class,&qclass,tmp_pcomp_factor,k_drate,fcar_class);
 deccvasc( tmp_pcomp_factor, strlen(tmp_pcomp_factor), &dec_pcomp_factor);
 dectodbl( &dec_pcomp_factor, &pcomp_factor);
 strcpy(drate,cm_to_infdate(k_drate));
 strcpy(fcar_class, trim(fcar_class));
 
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
    return M_CM_DB_NOTOPEN;
   else
    return apiRC;
 }

 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
 {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
 }

 $BEGIN WORK;
 for(j=0;j<i;j++)
 {
  sprintf_s(stmt_buf, sizeof stmt_buf, "INSERT INTO %s:ca_comp_acc_factor "
           "(fcard_class,qclass, pcomp_factor, drate, fcar_class) VALUES(?,?,?,?,?)" ,list[j].dbname);

  $PREPARE a_id FROM $stmt_buf;
  if(SQLCODE != 0)
   {
    is_add_fail = 1;
    break;
   }
  $EXECUTE a_id USING $fcard_class,$qclass,$pcomp_factor,$drate,$fcar_class;
  if(SQLCODE != 0)
   {
    is_add_fail = 1;
    break;
   }
  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);
  tmp_len = cm_buf_len(ReplyBuf);
  if( j == i-1 )
     api_f = api_OKComplete;
  else
     api_f = api_OK;

  if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
    {
     is_add_fail = 2;
     break;
    }  
#ifdef DEBUG 
printf("INSERT %d\n", j+1);
#endif
 } /* for loop */

 if( is_add_fail == 1 ) goto errexit;

 if( is_add_fail == 2 ) 
  {
   $ROLLBACK WORK;
   return apiRC;
  }

 $WHENEVER SQLERROR GOTO errexit;
 $COMMIT WORK;
 return api_OKComplete;

 errexit:
   MsgCode = SQLCODE;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if( SQLCODE != 0) MsgCode = SQLCODE;
   printf("MsgCoDE[%d]\n",MsgCode);

   if(exitsub(reply,MsgCode) == True)
    return MsgCode;
   else
    return apiRC;
   printf("MsgCoDE[%d]\n",MsgCode);
}

/*-----------------------------------------------------------------*/
long car134_single_query(reply)
serverReply reply;
{
 $char DBName[5],k_drate[10],drate[12],k_qclass[4];
 $int  qclass;
 $double pcomp_factor = 0.0;
 $char fcard_class[2],fcar_class[3];
 int tmp_len;

 cm_buf_get("%s %s %d %s %s",DBName,fcard_class,&qclass,k_drate,fcar_class);
 strcpy(drate,cm_to_infdate(k_drate));
 strcpy(fcar_class, trim(fcar_class));

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
    return M_CM_DB_NOTOPEN;
   else
    return apiRC;
  }

 $SELECT pcomp_factor
    INTO $pcomp_factor
    FROM ca_comp_acc_factor
   WHERE fcard_class = $fcard_class and qclass = $qclass and drate = $drate and fcar_class = $fcar_class;

 if(SQLCODE==SQLNOTFOUND)
  {
   if(exitsub(reply,M_CA_NACC_FACTOR) == True)
    return M_CA_NACC_FACTOR;
   else
    return apiRC;
  }

 cm_buf_init(ReplyBuf);
 cm_buf_put("%l %s %s %d %e %s",M_CM_OK,fcard_class,fcar_class,qclass,pcomp_factor,k_drate);
 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
  return apiRC;
 else
  return api_OKComplete;

 errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}

/*-----------------------------------------------------------------*/
long car134_multiple_query(reply)
serverReply reply;
{
 $char DBName[5],k_drate[10],drate[12];
 $int  key_qclass,qclass = 0;
 $long drate_l = 0;
 $double pcomp_factor = 0.0;
 $char fcard_class[2], fcar_class[3];
 char  key_char_qclass[4];
 char tmpbuf[4000],strtmp[5];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0;
 int flag,date_flag;

 cm_buf_get("%s %s %s %s %s",DBName,fcard_class,key_char_qclass,k_drate,fcar_class);
printf("-----DB[%s] qclass[%s] drate[%s]\n",DBName,key_char_qclass,k_drate);
 strcpy(fcar_class, trim(fcar_class));
 if(k_drate[0]=='*')
 {      
        date_flag=0;
 }else{
        strcpy(drate,cm_to_infdate(k_drate));
        date_flag=1;
 }
printf("-----date_flag[%d] drate[%s]\n",date_flag,drate);


 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
    return M_CM_DB_NOTOPEN;
   else
    return apiRC;
  }

 if( key_char_qclass[0] == '*') {
   if(date_flag){

    flag = 1;
    $DECLARE q_cur1 CURSOR FOR
       SELECT fcard_class,qclass,pcomp_factor,fcar_class,drate
       INTO $fcard_class,$qclass,$pcomp_factor,$fcar_class,$drate_l
       FROM ca_comp_acc_factor
       WHERE  fcard_class MATCHES $fcard_class AND drate=$drate and fcar_class matches $fcar_class
       ORDER BY fcard_class,qclass,pcomp_factor,fcar_class;
    }else{

printf("---- flag=1\n");
    flag = 2;
    $DECLARE q_cur2 CURSOR FOR
       SELECT fcard_class,qclass,pcomp_factor,drate,fcar_class
       INTO $fcard_class,$qclass,$pcomp_factor,$drate_l,$fcar_class
       FROM ca_comp_acc_factor
       WHERE fcard_class MATCHES $fcard_class and fcar_class matches $fcar_class
       ORDER BY fcard_class,qclass,pcomp_factor,drate,fcar_class;
      }
  } else {
printf("---- flag=2\n");
    if(date_flag)
    {

    key_qclass= atoi( key_char_qclass);  /* ????? */
    flag = 3;
    $DECLARE q_cur3 CURSOR FOR
       SELECT fcard_class,pcomp_factor,fcar_class,drate
       INTO $fcard_class,$pcomp_factor,$fcar_class,$drate_l
       FROM ca_comp_acc_factor
       WHERE fcard_class matches $fcard_class and qclass= $key_qclass and drate=$drate
         and fcar_class matches $fcar_class
       ORDER BY fcard_class,pcomp_factor,fcar_class;
    }else{

    key_qclass= atoi( key_char_qclass);  /* ????? */
    flag = 4;
    $DECLARE q_cur4 CURSOR FOR
       SELECT fcard_class,pcomp_factor,drate,fcar_class
       INTO $fcard_class,$pcomp_factor,$drate_l,$fcar_class
       FROM ca_comp_acc_factor
       WHERE fcard_class matches $fcard_class and qclass= $key_qclass and fcar_class matches $fcar_class
       ORDER BY pcomp_factor,drate;
    }
  }

printf("---- flag=6\n");
 if( flag == 1)
   $OPEN q_cur1;
 if(flag==2)
   $OPEN q_cur2;
 if(flag==3)
   $OPEN q_cur3;
 if(flag==4) 
   $OPEN q_cur4;

 for(;;)
  {
printf("---- flag=6.6\n");
    if(flag==1)
       $FETCH q_cur1;
    if(flag==2)
       $FETCH q_cur2;
    if(flag==3)
       $FETCH q_cur3;
    if(flag==4)
       $FETCH q_cur4;

    if (SQLCODE != 0) break;
		
printf("---- flag=7\n");
    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();
     }
    sprintf_s(strtmp, sizeof strtmp, "%.2f",pcomp_factor);
    if (flag==2 || flag==4) 
    strcpy(k_drate,cm_cdate_str_100(drate_l));
    else 
    strcpy(k_drate,cm_cdate_str_100(drate_l));
    
    strcpy(fcar_class, trim(fcar_class));
    if (flag==1 || flag==2)
    cm_buf_put("%s %d %s %s %s",fcard_class, qclass, strtmp,k_drate,fcar_class);
    else
    cm_buf_put("%s %s %s %s %s",fcard_class,key_char_qclass, strtmp,k_drate,fcar_class);

printf("---- flag=8\n");
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
printf("---- flag=9\n");
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
         if( flag == 1)
            $CLOSE q_cur1;
         else
            $CLOSE q_cur2;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
printf("---- flag=10\n");
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        sprintf_s(strtmp, sizeof strtmp, "%.2f",pcomp_factor);
        if (flag==2 || flag==4) 
        strcpy(k_drate,cm_cdate_str_100(drate_l));
        else 
        strcpy(k_drate,cm_cdate_str_100(drate));
        strcpy(fcar_class, trim(fcar_class));
    if (flag==1 || flag==2)
    cm_buf_put("%s %d %s %s %s",fcard_class, qclass, strtmp,k_drate,fcar_class);
    else
    cm_buf_put("%s %s %s %s %s",fcard_class,key_char_qclass, strtmp,k_drate,fcar_class);

        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
  } /* for loop */

 if( flag == 1)
    $CLOSE q_cur1;
 if (flag==2)
    $CLOSE q_cur2;
 if(flag==3)
    $CLOSE q_cur3;
 if(flag==4)
    $CLOSE q_cur4;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
printf("---- flag=11\n");
   if(exitsub(reply,M_CA_NACC_FACTOR) == True)
    return M_CA_NACC_FACTOR;
   else
    return apiRC;
  }

 errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}


/*-----------------------------------------------------------------*/
long car134_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 $char DBName[5],cur_drate[12],drate[12],k_drate[10],k_qclass[4],m_drate[10];
 $int  qclass,cur_qclass ,count;
 $double pcomp_factor, cur_pcomp_factor;
 $char fcard_class[2],tmp_fcard_class[2];
 $char fcar_class[3],tmp_fcar_class[3];
 dec_t dec_pcomp_factor, dec_cur_pcomp_factor;
 char tmp_pcomp_factor[21], tmp_cur_pcomp_factor[21],tmp_qclass[4];
 char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
 int tmp_len,raw_len;
 long dummy;
 long MsgCode;
 DBinfo *list;
 int i, j, is_del_fail=0, is_upd_fail=0;
 $char stmt_buf[300];

 comm = (char *) command;
 cm_buf_init(command);
 cm_buf_get("%c %s",&option,DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
    return M_CM_DB_NOTOPEN;
   else
    return apiRC;
  }

 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
  {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
}
 /* compare old record and current record, if the record has not been changed
    since last request, update or delete the record, otherwise return errmsg
    to client side */

 /* get old record info from command buffer */

/*
 raw_len = *(int *) &comm[com_len];
 memcpy(&raw_len,(void *)&command[com_len],sizeof(int));
*/
 memcpy(&raw_len,&comm[com_len],sizeof(int));
 pos = &comm[com_len+sizeof(int)];
 raw_ptr = malloc(raw_len);
 if (raw_ptr != (char*)0)
  memcpy(raw_ptr,pos,raw_len);
 else
  {
   if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */
    return M_CM_NOT_MALLOC;
   else
    return apiRC;
  }
printf("work form here\n");
 cm_buf_init(raw_ptr);          /* get index key from old record */
 cm_buf_get("%l %s %s %s %e %s",&dummy,fcard_class,fcar_class, &k_qclass,&cur_pcomp_factor,k_drate);
 strcpy(cur_drate,cm_to_infdate(k_drate));
 cur_qclass= atoi(k_qclass);
 strcpy(fcar_class, trim(fcar_class));
 printf("is %s\n",k_drate);
 $BEGIN WORK;

 $SELECT fcard_class,pcomp_factor,fcar_class
    INTO $fcard_class,$cur_pcomp_factor,$fcar_class
    FROM ca_comp_acc_factor
   WHERE fcard_class matches $fcard_class and qclass=$cur_qclass and drate=$cur_drate
     and fcar_class matches $fcar_class;
strcpy(fcar_class, trim(fcar_class));
  /* if key value has been changed then SQLNOTFOUND,else put current value
     into cur_buf for comparison */

 if (SQLCODE == SQLNOTFOUND)
  {
   MsgCode = M_CM_NOT_FOUND;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if( SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
    return MsgCode;
   else
    return apiRC;
  }
strcpy(fcar_class, trim(fcar_class));
 cm_buf_init(cur_buf);
 strcpy(m_drate,cm_cdate_str_100(cur_drate));
 cm_buf_put("%l %s %s %d %e %s",dummy,fcard_class,fcar_class,cur_qclass,cur_pcomp_factor,k_drate);

printf("kkkk\n");
 if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
  {
printf("kkkk2\n");
   MsgCode = M_CM_NOT_EQUAL;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if( SQLCODE != 0) MsgCode = SQLCODE;
   free(raw_ptr);
   if(exitsub(reply,MsgCode) == True)
    return MsgCode;
   else
    return apiRC;
  }

   $WHENEVER SQLERROR GOTO errexit;
 /* equal, then exec DB operation */

 if ( option == 'D' )
  {
     
   for(j=0;j<i;j++)
   {
    sprintf_s(stmt_buf, sizeof stmt_buf, "DELETE FROM %s:ca_comp_acc_factor WHERE fcard_class = ? and qclass = ? and drate=? and fcar_class = ?"
                ,list[j].dbname); 
    $PREPARE d_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      break;
     }
    $EXECUTE d_id USING $fcard_class,$cur_qclass,$cur_drate,$fcar_class;
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      break;
     }
#ifdef DEBUG 
printf("Delete %d\n", j+1);
#endif
   }/* for loop */

   if( is_del_fail ) goto errexit;
   
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else if (option == 'U')
  {
  printf("here1\n");
   cm_buf_init(command);
printf("here8\n");
   cm_buf_get("%c %s %s %s %s %s %s",&option,DBName,tmp_fcard_class,tmp_qclass,tmp_pcomp_factor,k_drate,tmp_fcar_class);
printf("here9\n");
   qclass=atoi(tmp_qclass);
   deccvasc( tmp_pcomp_factor, strlen( tmp_pcomp_factor), &dec_pcomp_factor);
   dectodbl( &dec_pcomp_factor, &pcomp_factor);
   strcpy(drate,cm_to_infdate(k_drate));
   strcpy(tmp_fcar_class, trim(tmp_fcar_class));
printf("qclass[%d]\n",qclass);        
printf("pcomp_factor[%f]\n",pcomp_factor);        
printf("drate[%s]\n",drate);        
printf("qclass[%d]\n",cur_qclass);        
printf("drate[%d]\n",cur_drate);        
   $WHENEVER SQLERROR GOTO errexit;
   for(j=0;j<i;j++)
   {
    sprintf_s(stmt_buf, sizeof stmt_buf, "UPDATE %s:ca_comp_acc_factor "
                "SET (fcard_class,qclass,pcomp_factor,drate,fcar_class) = (?,?,?,?,?) WHERE fcard_class matches ? and qclass = ? and drate=? and fcar_class matches ?",list[j].dbname);

    $PREPARE u_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      break;
     }
    $EXECUTE u_id USING $tmp_fcard_class,$qclass,$pcomp_factor,$drate,$tmp_fcar_class,$fcard_class,$cur_qclass,$cur_drate,$fcar_class;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      break;
     }
printf("here3\n");
    if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
     {
      sprintf_s(stmt_buf, sizeof stmt_buf, "INSERT INTO %s:ca_comp_acc_factor "
                        "(fcard_class,qclass,pcomp_factor,drate,fcar_class) VALUES (?,?,?,?,?)",list[j].dbname);

      $PREPARE ua_id FROM $stmt_buf;
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        break;
       }
      $EXECUTE ua_id USING $tmp_fcard_class,$qclass,$pcomp_factor,$drate,$tmp_fcar_class;
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        break;
       }
     }
#ifdef DEBUG 
printf("Update %d\n", j+1);
#endif
   } /* for loop */

   if( is_upd_fail ) goto errexit;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else
  {
   if(exitsub(reply,M_CM_WRONG_OPTION) == True)
    return M_CM_WRONG_OPTION;
   else
    return apiRC;
  }

 errexit:
   MsgCode = SQLCODE;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if( SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
    return MsgCode;
   else
    return apiRC;
}
