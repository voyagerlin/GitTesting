/*--------------------------------------------------------------------*/
/*   PROGRAM ID    : ca614q01s.ec                                     */
/*   PROGRAM NAME  : �t�P���t�պ��ƤU���@�~                         */
/*   AUTHOR        : Jessie                                           */
/*   DATE WRITTEN  : 2002/11/15                                       */
/*   MODIFY        : Jessie                                           */
/*   DATE MODIFY   : 2003/01/20                                       */
/*   MODIFY OPTION : �W�[�ߴګY��,�s�v�t�j�_,�t�d��                   */
/*   FILES         : sp_compute_prem     i                            */
/*                   car614.txt          o                            */
/*   TEMP FILES    : car614              io                           */
/*   Checked for ����100�~�M��                                        */
/*--------------------------------------------------------------------*/
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
#define False                 0
#include "safeclib.h"
/*--------------------------------------------------------------------*/
$char    imotor[11],icode[4],iyear[5],cdmg[6],clia[6],ccomp[6],fcomp[2];
$char    itype[2],ibrand[9],comp_code[4];
$char    sales_brand[21],nsex[4],nage[12],iins_type[12],nins_type[21];
$char    nded[16],remark1[21],remark2[21],remark3[21],remark4[21];
$char    remark5[21],remark6[21],dtl_brand[21];
$int     mprem = 0;
$double  mamt = 0,idmg = 0,ilia = 0,icomp = 0,pfactor = 0;
char     errmsg[200];

char     msgbuf[1024];

int      flen,cnt,cnt_1,cnt_2;
int      cnt_p,cnt_i,cnt_c;
FILE     *fp;
char     sApHome[30];
$char    fname[21];
char     filename[40];
$char    DBName[5], iForm_Tp[3];
$char    full_dbname[20];
char     BodyFile[ N_FILE+1];
char     TitleFile[ N_FILE+1];
char     outputf[N_FILE+1], userid[11];

$int     ItemRow, TotColumn;
$int     StartRow,TitleRow;
$int     PgLine, Width;

int  max_cnt;

/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
    int rc;

    batchinit();
    strcpy(DBName, isNULLstr(argv[1]));
    strcpy(userid, isNULLstr(argv[2]));
    strcpy(imotor, isNULLstr(argv[3]));
    strcpy(comp_code, isNULLstr(argv[4]));
    strcpy(icode, isNULLstr(argv[5]));
    strcpy(iyear, isNULLstr(argv[6]));
    strcpy(cdmg, isNULLstr(argv[7]));
    strcpy(clia, isNULLstr(argv[8]));
    strcpy(ccomp, isNULLstr(argv[9]));
    strcpy(fcomp, isNULLstr(argv[10]));
    strcpy(itype, isNULLstr(argv[11]));
    strcpy(outputf, isNULLstr(argv[12]));
   
    idmg=atof(cdmg);
    ilia=atof(clia);
    icomp=atof(ccomp);

    rc=car614_get_db();
    if ( rc != M_CM_OK) return rc;

    rc=car614_process();
    if ( rc != M_CM_OK)
       return rc;

    if (itype[0]=='0') {
       rc=car614_quick();
       if (rc!=M_CM_OK)
          return rc;
    }
    else {
       rc=car614_cap();
       if (rc!=M_CM_OK)
          return rc;
    }

    return rc;
}

/*--------------------------------------------------------------------*/
long car614_get_db()
{
    int rc;
    $whenever sqlerror goto errexit;

    if (db_select(DBName) == FALSE)
    {
        EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
        return M_CM_DB_NOTOPEN;
    }
    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }

    return M_CM_OK;
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car614_process()
{
    int    rc;

    $whenever sqlerror goto errexit;

    $create temp table car_quick
       (sales_brand char(20),
        dtl_brand   char(20),
        ibrand      char(08),
        mprize      decimal(10,2),
        nsex        char(4),
        nage        char(14),
        iins_type   char(10),
        nins_type   char(20),
        ndeduct     char(14),
        mprem       integer,
        icode       char(10),
        iyear       char(10),
        brg_f       char(15),
        p_rate      char(15),
        age_f       char(10),
        p_pure      char(15),
        pfactor     decimal(4,2)) with no log;

    $execute procedure sp_compute_prem($imotor,$comp_code,$icode,
                       $iyear,$idmg,$ilia,$icomp,$fcomp);

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;  
}

/*--------------------------------------------------------------------*/
long car614_cap()
{
    int    rc;

    $whenever sqlerror goto errexit;

    sprintf_s(filename, sizeof filename,"%s/rptftp/car614.txt",sApHome);
    fp=fopen(filename,"w");

    /* Title */
    fprintf(fp,"���t�G%s  �O�v�N���G%s  �褸�~���G%s  ����ߴګY�ơG%f  ���d�ߴګY�ơG%f  �j��ߴګY�ơG%f  \n",imotor,icode,iyear,idmg,ilia,icomp);
    fprintf(fp,"����\t����\t����\t�ʧO\t�~��\t�I�إN��\t�I�ئW��\t�ﶵ\t�O�O\t�O�v�N��\t�~��\t����/�ѵs�Y��\t�򥻯«O�O/�v\t�~�֩ʧO�Y��\t�«O�O�v\t�ߴګY��\t\n");

    cnt=0;
    $declare cur_1 cursor for
      select sales_brand,dtl_brand,mprize,nsex,nage,iins_type,
             nins_type,ndeduct,
             mprem,icode,iyear,brg_f,p_rate,age_f,p_pure,
             pfactor
        into $sales_brand,$dtl_brand,$mamt,$nsex,$nage,$iins_type,
             $nins_type,
             $nded,$mprem,$remark1,$remark2,$remark3,$remark4,
             $remark5,$remark6,$pfactor
        from car_quick
       order by 1,2,3,4 desc,5,6,8;
    $open    cur_1;
    while(1) {
       $fetch cur_1;
       if (SQLCODE==SQLNOTFOUND) break;
       cnt++;
       printf("ins[%s]ded[%s]prem[%d]\n",iins_type,nded,mprem);
       strcpy(sales_brand,rtrim(sales_brand));
       strcpy(dtl_brand,rtrim(dtl_brand));
       strcpy(nsex,rtrim(nsex));
       strcpy(nage,rtrim(nage));
       strcpy(iins_type,rtrim(iins_type));
       strcpy(nins_type,rtrim(nins_type));
       strcpy(nded,rtrim(nded));
       fprintf(fp,"%s\t%s\t%f\t%s\t%s\t%s\t%s\t%s\t%d\t%s\t%s\t%s\t%s\t%s\t%s\t%f\t\n",
            sales_brand,dtl_brand,mamt,nsex,nage,iins_type,nins_type,nded,
            mprem,remark1,remark2,remark3,remark4,remark5,remark6,pfactor);
    }
    $close cur_1;
    $free  cur_1;

    fclose(fp);
    rc=rptftpinsert(userid,"car614","car614.txt");
    if (rc!=0) {
        EWRITE(userid,rc,"�g�Jrptftplist���~");
        return rc;
    }

    sprintf_s(msgbuf, sizeof msgbuf,"��X��Ʀ@[%d]��",cnt);
    EWRITE(userid,M_CM_OK,msgbuf);
    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;  
}

/*--------------------------------------------------------------------*/
long car614_quick()
{
    int    rc,i,j;
    $char  t1_ins[4096],t2_ins[4096];
    $char  c_ins[100][26],ins_str[26];

    $whenever sqlerror goto errexit;

    sprintf_s(filename, sizeof filename,"%s/rptftp/car614.txt",sApHome);
    fp=fopen(filename,"w");

    /* Title */
    $declare cur_t cursor for
      select distinct nvl(iins_type,' ') || nvl(ndeduct,' '),
             nvl(ndeduct,' '),nvl(nins_type,' ')
        from car_quick
       order by 1;
    $open cur_t;
    i=0;
    t1_ins[0]='\0';
    t2_ins[0]='\0';
    while(1) {
       $fetch cur_t into $ins_str,$nded,$nins_type;
       if (SQLCODE==SQLNOTFOUND) break;
       strcpy(c_ins[i],ins_str);
       sprintf_s(t1_ins, sizeof t1_ins,"%s%s\t",t1_ins,nins_type);
       sprintf_s(t2_ins, sizeof t2_ins,"%s%s\t",t2_ins,nded);
       i++;
    }
    $close cur_t;
    $free  cur_t;

printf("t1[%s]\n",t1_ins);
printf("t2[%s]\n",t2_ins);
    fprintf(fp,"���t�G%s  �O�v�N���G%s  �褸�~���G%s  ����ߴګY�ơG%f  ���d�ߴګY�ơG%f  �j��ߴګY�ơG%f  \n",imotor,icode,iyear,idmg,ilia,icomp);
    fprintf(fp,"����\t����\t�t�P����\t����\t�ʧO\t�~��\t%s\n",t1_ins);
    fprintf(fp,"    \t    \t        \t    \t    \t    \t%s\n",t2_ins);
    cnt=0;
    $declare cur_2 cursor for
      select distinct sales_brand,dtl_brand,mprize,nsex,nage,ibrand
        into $sales_brand,$dtl_brand,$mamt,$nsex,$nage,$ibrand
        from car_quick
       order by 1,2,3,4 desc,5,6;
    $open    cur_2;
    while(1) {
       $fetch cur_2;
       if (SQLCODE==SQLNOTFOUND) break;
       $declare cur_21 cursor for
         select iins_type,nins_type,ndeduct,mprem,
                nvl(iins_type,' ') || nvl(ndeduct,' ')
           into $iins_type,$nins_type,$nded,$mprem,$ins_str
           from car_quick
          where sales_brand = $sales_brand
            and dtl_brand = $dtl_brand
            and ibrand = $ibrand
            and mprize = $mamt
            and nsex = $nsex
            and nage = $nage
          order by 5;
       $open cur_21;
       t1_ins[0]='\0';
       j=0;
       while(1) {
          $fetch cur_21;
          if (SQLCODE==SQLNOTFOUND) break; 
          if (strcmp(ins_str, c_ins[j]) > 0) {
             for(j;j<i;j++) {
                if (strcmp(ins_str,c_ins[j])==0) break;
                sprintf_s(t1_ins, sizeof t1_ins,"%s -\t",t1_ins);
             }
          }
          sprintf_s(t1_ins, sizeof t1_ins,"%s%d\t",t1_ins,mprem);
          j++;
       }
       printf("t1[%s]\n",t1_ins);
       cnt++;
       fprintf(fp,"%s\t%s\t%s\t%f\t%s\t%s\t%s\n",
               sales_brand,dtl_brand,ibrand,mamt,nsex,nage,
               rtrim(t1_ins));
    }
    $close cur_2;
    $free  cur_2;

    fclose(fp);


    printf("before rptftpinsert userid[%s] \n",userid);
    rc=rptftpinsert(userid,"car614","car614.txt");
    if (rc!=0) {
        EWRITE(userid,rc,"�g�Jrptftplist���~");
        return rc;
    }
    printf("rc[%ld]\n",rc);

    sprintf_s(msgbuf, sizeof msgbuf,"��X��Ʀ@[%d]��",cnt);
    EWRITE(userid,M_CM_OK,msgbuf);
    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;  
}
/*---------------------------------------------------------end program*/
