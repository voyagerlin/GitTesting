/************************************************/
/*   PROGRAM : ca842q01s.ec                     */
/*   MODIFY  : cyrus                            */
/*   DATE    : 104.08.18                        */
/*   NOTE    : �w�M�߮��k�ɾP�����Ӫ�           */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
$include datetime.h;
#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"

$char DBName[05], iForm_Tp[03], outputf[N_FILE+1];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1];
$char  userid[11];

char  msgbuf[100];
$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;
$int  PERIOD;

static int  max_count;

DBinfo  *list;
int     count_db;

$char sIbranch[BRANCH_ID], sIofficer[EMPLOYEE_ID];
$char sNname[EMPLOYEE_NAME];
$char sIclaim[CLAIM_NUM], sFcard_class[2], sDclaim[YYYYMMDD];
$char sYearMonth[7];
$char sIadjuster[EMPLOYEE_ID], sFclose[2], sIins_type[INSURANCE_TYPE];
$char sDclose[13], victim[11], flast[2];
$char sDgroup[11];
$char dgroup[11];
$long ldgroup;
$char sNgroup[5],sNadjuster[11];
$char sIupbranch[3], sNupgroup[11];
$char sFins_grp[2];
$char sBgnDate_e[11], sEndDate_e[11], sBgnDate[11], sEndDate[11];
$long lBgnDate, lEndDate;
$long iQorder, i, qmonth, lMins_stl;
$char ivictim[11];
$long qdmg_claim, qdmg_close, qdmg_nopay;       /** ���l **/
$long qlia_claim, qlia_close, qlia_nopay;       /** �d�� **/
$long qburg_claim, qburg_close, qburg_nopay;    /** �W�[�ѵs�����Ѩ��l�������X **/
$long qcomp_claim, qcomp_close, qcomp_nopay;    /** �j�� **/
$long qwea_claim, qwea_close, qwea_nopay;       /** �]�� **/
$long mins_stl;
$date lDclaim;
$char iclaim[21];
$int  iclose_type;
$int  icnt;
$char stmt[2000];
$char stmt3[9500];
$char sIinsType[INSURANCE_TYPE];
$char sIinsTypeB[INSURANCE_TYPE];

$char iins_item[INSURANCE_TYPE];

int qlia, qburg, qdmg, qwea;
$int iTmp;
$int iMaxCnt;
$int id1 = 0;
$int iMonthDiff;

$char m_bgn[11], m_end[11], r_bgn[11], r_end[11];
$char server[3];
$char iofficer[11];

long car842_build();
void car842_title();
long car842_body();
long car842_print();
void car842_print2();
int DiffMonth();

/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
   int rc;
   
   batchinit();
   strcpy(DBName   ,  isNULLstr(argv[1]));
   strcpy(userid   ,  isNULLstr(argv[2]));
   strcpy(sBgnDate ,  isNULLstr(argv[3]));
   strcpy(sEndDate ,  isNULLstr(argv[4]));

   strcpy(outputf  ,  isNULLstr(argv[5]));

   strcpy(sBgnDate_e, cm_to_infdate(sBgnDate));
   strcpy(sEndDate_e, cm_to_infdate(sEndDate));

   rstrdate(sBgnDate_e, &lBgnDate);
   rstrdate(sEndDate_e, &lEndDate);

   printf("sBgnDate_e[%s] sEndDate_e[%s]\n",sBgnDate_e , sEndDate_e);
 
   rc=car842_get_db();
   if (rc!=M_CM_OK)
      return rc;
   
   rc = car842_build();
   if (rc != M_CM_OK)
       return rc;

   return M_CM_OK;
   
errexit:
   printf("main :SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/

long car842_build()
{
   $char  TitleFmt[N_FILE+1],BodyFmt[N_FILE+1];
   int    rc;
   
   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT;
   
   if (db_select(DBName) == False)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   rc = car842_body();
   if (rc != M_CM_OK)
       return rc;
           
   rc = car842_print();
   if (rc != M_CM_OK)
       return rc;
 
   return M_CM_OK;

errexit:
   EWRITE(userid,rc,sqlca.sqlerrm);
   return SQLCODE;  
}

long car842_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

long car842_body()
{
    int i;
    long rc;
    $char sStmt[9500],sStmt1[9500],sStmt2[9500],sStmt3[9500],sStmt4[9500];
    $char stmt[9500];
    $char tmp[4096], tmp1[4096], tmp2[4096];
    $char stepcar[4096];
    $char iapp_unit[3];
    $char falldb[2];

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;

    $create temp table car842tbl
    (
       iclaim         char(20),
       fstl           char(1),
       iclose_type    int,
       dclose         date,
       itag           char(20),
       iassured       char(20),
       nassured       varchar(120),
       iacc_reason    char(10),
       nrecovery      char(60)
    )with no log;

    $select iapp_unit
       into $iapp_unit
       from cm_clm_adjuster
      where empl_no = $userid;
      if (SQLCODE == SQLNOTFOUND)
      {
         $select ibranch
            into $iapp_unit
            from officer
           where iofficer = $userid;
         if (SQLCODE == SQLNOTFOUND)
         {
            strcpy(iapp_unit,DBName);
         }
      }

    printf("iapp_unit[%s]\n",iapp_unit);

    sprintf_s(stmt,9500,
    " select falldb                \
         from %s:privilege         \
        where ipgid = 'car842'     \
          and iemp  = ? ",get_full_dbname(iapp_unit));

    printf("stmt [%s]\n",stmt);
    $prepare get_fallid from $stmt;
    $execute get_fallid into $falldb:id1 using $userid;
 
    printf("id1[%d]\n",id1);
    if (id1 < 0) strcpy(falldb,"N");  

    printf("falldb[%s]\n",falldb);

    for (i=0;i<count_db;i++)
    {
        if (falldb[0] != 'Y')
        {
           sprintf_s(tmp1,4096,
            "  and a.iclaim[3] = (select iupcomp from officer where iofficer = '%s') ", userid);
        }
        else
        {
           strcpy(tmp1," ");
        }

        sprintf_s(stmt,9500,
         "  insert into car842tbl   \
            select b.iclaim, b.fstl, b.iclose_type, b.dclose, a.itag, a.iassured, a.nassured, d.iacc_reason,     \
                   case d.frecover when '0' then '0:�����l�v'                \
                                   when '1' then '1:�ۦ�l�v'                \
                                   when '2' then '2:�w�ۦ�l�v'              \
                                   when '3' then '3:�k�Ȱl�v'                \
                                   when '4' then '4:�ۦ�l�v��k�Ȱl�v'      \
                                   when '5' then '5:�j���I�u��'              \
                                   when '6' then '6:�j���I�N���u�^'          \
                                   when '7' then '7:�\�i�K�l�v(����)'        \
                   else ' '                 \
                    end as frecover         \
              from ca_clm_process a, %s:settlement b, %s:appraisal d         \
             where a.iclaim      = b.iclaim            \
               and a.iclaim      = d.iclaim            \
               and d.iacc_reason not in ('21','23')    \
               and b.fstl        = '1'                 \
               and b.dclose     >= ?                   \
               and b.dclose     <= ?                   \
               and b.iclose_type = (select max(iclose_type)                  \
                                      from %s:settlement                     \
                                     where iclaim      = b.iclaim            \
                                       and fstl        = '1') %s ", list[i].dbname, list[i].dbname, list[i].dbname, tmp1);

            printf("stmt[%s]\n",stmt);		
    
            $prepare ins_tbl from $stmt;
            $execute ins_tbl
               using $lBgnDate, $lEndDate;
   }

  return M_CM_OK;
        
errexit:
   printf("car842_body ==> SQLCODE:[%ld][%s] \n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   printf("   end EWRITE \n");
   return SQLCODE;
}

long car842_print()
{
   $char stmt[4096], stmt1[1024], stmt2[1024];
   $long qorder;
   int i,x,j,k;
   $int COUNT;
   $char sfilename[200];
   $char stitle[1000];
   $char ssql[1000];
   $char dyearmonth_tmp[7];
   $char title_tmp[101];
   $char title_tmp0[101];
   $char title_tmp1[101];
   $char title_tmp2[101];
   $char filed[20][15];
   $char sqltmp[1024];
   $char filed_tmp[200];
   $char sErrmsg[100];
   $char stitletmp[512];
   $int  rc;
 
   $char sWhere1[1024];
   $char sWhere2[1024];
   $char sWhere3[1024];
   $char sWhere4[1024];

   $WHENEVER ERROR goto errexit;
   $SET LOCK MODE TO WAIT;

   strcpy(sfilename,"�w�M�߮��k�ɾP�����Ӫ�");
   printf("sfilename[%s]\n",sfilename);

   strcpy(stitle, sfilename);
   printf("stitle[%s]\n",stitle);
   strcat(stitle, "\n\t");
   strcat(stitle, "�鵲����G");
   strcat(stitle, sBgnDate_e);
   strcat(stitle, " ~ ");
   strcat(stitle, sEndDate_e);
   strcat(stitle, "\n\t�߮׸��X\t�ߥI�l�v�O\t�߰l����\t�鵲���\t���P\t�Q�O�I�HID\t�Q�O�I�H\t�X�I��]\t�l�v�O\t");

   printf("stitle[%s]\n",stitle);

   sprintf_s(ssql,1000,
    " select * from car842tbl ");

   printf("ssql[%s]\n",ssql);

   rc = unload_file(outputf," ",sfilename,stitle,ssql);

   if (rc != SUCCESS)
   {
       if (rc == 3501)
       {
          sprintf_s(sErrmsg,100," ��J���^������䤣���� ",sfilename);
       }
       else
       {
          sprintf_s(sErrmsg,100," %s �ɮ׵L�k���� ",sfilename);
       }

       EWRITE(userid, rc , sErrmsg);
       exit(1);
   }

   return M_CM_OK;

errexit:
  printf("SQL=[%d], sqlca.sqlerrm[%s]\n", SQLCODE, sqlca.sqlerrm);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  exit(1);
    
}

int DiffMonth(d1,d2)    /* input data should be date format */
long d1, d2;
{
short mdy1[3], mdy2[3];
int datediff=0;

    rjulmdy(d1,mdy1);
    rjulmdy(d2,mdy2);
    datediff=(mdy1[2]*12+mdy1[0])-(mdy2[2]*12+mdy2[0]);
    if (datediff<0) datediff=0;
    return datediff;
}

