/************************************************/      /*   adjustmemt_ply  ���z���@  */
/*   �z�ߥ��M�߮ש��Ӫ�                         */      /*   ���M�H�߮׬��Dfstl = '1' */
/*   PROGRAM : car825.ec by forest              */      /*   dclose is not null   */
/*   MODIFY BY NEWA                             */      /*   �j��    */
/*   MODIFY by SCOTT 890523                     */      /*   �j���I�� Cat  */
/*   MODIFY by ealex 891108                     */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "carmsgs.h"
#define SCOTT
#define fmt "---,---,--&"
#include "safeclib.h"

char *get_car_full_db();
extern char  RPTDIR[];

/****** Global variables ******/

$char  DBName[5], DBName2[5], sFullName[80], sOption[2];
char   BodyFile[21];
char   TitleFile[21];
$char  outputf[21];
$int   max_count ,Width=0;
$char  FormTp[3];
$int   TotColumn;
$int   StartRow,TitleRow;
$int   PgLine , ItemRow;
static int errCode;
$int   tmp_len;
$char  GHsDsal[11];

$char  sStmt[3072];
$char  sStmt1[3072];
$int   iSd, iEd, iSd2;
$int   iSdm, iEdm, iSd2m;
$int   fStat;
char   date_flag[2];

$char  frecov[2];
$char  GsFrecov_GsFsal[2];
char   GsFrecover_GsFsale[2];
$char  GsFreprocess[2];
$char  ibranch_flag[2];
$char  ibranch[6],iupbranch[3],ibranch_in[3];
$char  fcard_class[2];
$char  datebgn[10],dateend[10],datebgn_edate[11],dateend_edate[11];
$char  dclaimbgn[10],dclaimend[10],dclaim_ebgn[11],dclaim_eend[11];
$char  sDrpDate[10];
$char  sDrpDate_e[11];
$char  dclaim[11];
$char  factory1[11];
$char  nfactory[21];
$char  ivictim[11];
/*
char   yy[5],mm[5],dd[5];
*/
char   userid[11];
char   GsOption[2];



$char  sIins_type[5];
$long  lMins_app=0,lMins_stl=0,lMins_sum,mproc_app=0;
$int   iStlcnt=0;
$char  sCatIns[31];

/**** output to reportfile ****/

$char  Iclaim[CLAIM_NUM], Ipolicy[POLICY_NUM_1];
$char  Nassured[21], Ibrand[9], Itag[CA_TAG_NUM], Iengine[CA_ENGINE_NUM];
$char  Nname[11], Lawgiver[11], Iacc_area[3];
$char  Daccident[21];
char   GsDaccident[10];
$char  fstl[2];
$char  Dclose_edate[11];
$char  Iins_type[INSURANCE_TYPE];
$int   Iclose_type;
$int   Msettle,  Mrec_done,  Msal_done;
$int   TMsettle, TMrec_done, TMsal_done, TMmrecov;
$char  Drecov[11];
$char  GHsFrecov[2];
$char  GHsFrecover[2];
$char  GHsFreprocess[2];
$int   GHiMmrecov;

int  count;

void car825_title();
long car825_build();

main(argc, argv)
int  argc;
char **argv;
{
    char scriptFile[120];
    int  rc=0;

        batchinit();

        strcpy(DBName,                  isNULLstr(argv[1]));
        strcpy(userid,                  isNULLstr(argv[2]));

        strcpy(ibranch_flag,            isNULLstr(argv[3]));  /* ���z�����O */
        strcpy(ibranch,                 isNULLstr(argv[4]));  /* ���z��� */

        strcpy(dclaimbgn,               isNULLstr(argv[5]));  /* ���z�_�� */
        strcpy(dclaimend,               isNULLstr(argv[6]));  /* ���z�״� */

        strcpy(sDrpDate,                isNULLstr(argv[7]));

        strcpy(outputf,                 isNULLstr(argv[8]));


        printf("debug DBName [%s]\n",DBName);
        printf("debug userid [%s]\n",userid);

        printf("debug ibranch_flag [%s]\n",ibranch_flag);
        printf("debug ibranch [%s]\n",ibranch);

        printf("debug dclaimbgn [%s]\n",dclaimbgn);
        printf("debug dclaimend [%s]\n",dclaimend);

        printf("sDrpDate [%s]\n",sDrpDate);

        printf("debug outputf [%s]\n",outputf);


        if( dclaimbgn[0] =='*') strcpy(dclaimbgn, "87/01/01");
        if( dclaimend[0] == '*') strcpy(dclaimend, "99/12/30");

        strcpy(dclaim_ebgn,cm_to_infdate(dclaimbgn));
        strcpy(dclaim_eend,cm_to_infdate(dclaimend));
        strcpy(sDrpDate_e, cm_to_infdate(sDrpDate));

        printf("*****car825_build BEGIN !!!!*****\n");

        if((rc=car825_build()) == SUCCESS)
        {
            printf("***** car825_build SUCCESS !!!!! \n");

            create_sign_form("car825", BodyFile, Width);
            if((rc=save_form_info(F_BLK0,"CA",825,userid,FormTp,max_count,outputf))<0)
                  EWRITE(userid,rc,"save_form_info failed");
            else
                  printf("debugscott success on save_form_info!!\n\n");
        }

}

long car825_build()
{
   $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];
   int    b,BranchCnt;

   $WHENEVER SQLERROR GOTO errexit;

   if(db_select(DBName) == False)
   {
      EWRITE(userid,M_CM_DB_NOTOPEN,"M_CM_DB_NOTOPEN");
      return FAIL;
   }

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow, $ItemRow,
           $TotColumn, $PgLine, $Width, $FormTp
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 825 ;

   strcpy( TitleFmt, rtrim(TitleFmt));
   strcpy( BodyFmt,  rtrim(BodyFmt));
   sprintf_s( TitleFile,21,"%s.ti",outputf);
   sprintf_s( BodyFile,21, "%s.bd",outputf);

   /******* �إߤ@�� TEMP TABLE ******/

   $WHENEVER SQLERROR GOTO errexit;
   /* �s�W�߮��I���k�� add by sylvia 106.10.20 (1061012004_C1) */
   $CREATE TEMP TABLE car825_TEMP
   (
       sfullname      char(30),
       ibranch        char(10),
       iclaim         char(21),
       scatins        char(100),
       msettle        integer default 0,
       imaxadj        integer default 0,
       imaxapp        integer default 0     -- �߮��I���k��
   ) WITH NO LOG;

   $CREATE TEMP TABLE stlins
     (
       ins_type   char(5)
     )WITH NO LOG;


   /************* �B�z���Y ************/

   rgu_init_report( TitleFmt,TitleFile);
   car825_title();
 
   rgu_finish_report();

   /************* �B�z���� ************/
   rgu_init_report( BodyFmt,BodyFile);

   max_count=0;

   TMsettle = TMrec_done = TMsal_done = TMmrecov = 0;

   /****** �}�l��ƪ��B�z�οz�� *******/

   printf("[car825_process]!!\n");

   car825_process();

   printf("[car825_data]!!\n");

   car825_data();

   if (max_count == 0)
   {
       EWRITE(userid, M_CM_NOT_FOUND, "�L��ƥi�B�z!!! ");
       exit(1);
   }

   rgu_finish_report();

   return SUCCESS;

 errexit:
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(1);
}

void car825_title()
{
   char yy[4],mm[3],dd[3];
   char SysTm[30];

   strcpy( SysTm, cm_get_sysd());
   rgu_put_head_string( 1, cm_sysd_cdate_100(SysTm));   /* get_currdt */

   cm_split_ymd_100(datebgn, yy, mm, dd);
     rgu_put_head_string(1, yy);
     rgu_put_head_string(1, mm);
     rgu_put_head_string(1, dd);
   cm_split_ymd_100(dateend, yy, mm, dd);
     rgu_put_head_string(1, yy);
     rgu_put_head_string(1, mm);
     rgu_put_head_string(1, dd);
   rgu_put_head();
}

car825_process()
{
   
   $char iclaim[CLAIM_NUM],ipolicy[POLICY_NUM_1];
   $char iclaim_tmp[CLAIM_NUM],ipolicy_tmp[POLICY_NUM_1];
   $char nassured[21], ibrand[9], itag[CA_TAG_NUM], iengine[CA_ENGINE_NUM];
   $char iadjuster[11], nname[11], lawgiver[11], iacc_area[3];
   $char daccident[21];
   $char dclose[11];
   $char iins_type[5];
   $int  msettle,mrec_done,msal_done,iclose_type;
   $char drecov[11];
   $char frecov[2],freprocess[2];
   $char LHsFrecover[2];
  
   int   rtncode = 0; 
   int   rc=0;
   int   cnf_flag;
   $char LocalName[50];
   $char sFullName[20];     /*�߮ר��z��Ʈw*/
   $char sFullName1[20];    /*�O��Ҧb��Ʈw*/
   $char sFullName2[20];    /*�w���I�ة����ɩҦb��Ʈw*/
   $int  ins_count;
   $int  iMaxCnt=0;
   $int  imaxapp;   /* �߮��I���k�� */

   count=0;

   $WHENEVER SQLERROR GOTO errexit;

   if (strcmp(trim(ibranch_flag),"1")==0) 
   {
        printf("debugscott �H�`�����q�O�d��[%s] \n",iupbranch);

        strcpy(iupbranch,ibranch);
   }
   else
   {    /*** �H�߮ר��z���d�� ***/
        printf("debugscott �H�߮ר��z���O�d�� \n");

        sprintf_s(sStmt,3072,"SELECT iupbranch \
                         FROM v_branch \
                        WHERE ibranch = '%s' ",ibranch);

        $PREPARE acursor_0 FROM $sStmt;
        $DECLARE a_0 CURSOR FOR acursor_0;
        $OPEN a_0;
        while(1)  
        {
              $FETCH a_0 INTO  $iupbranch;

              printf("debugscott �H�߮ר��z���O�d��[%s]\n",iupbranch);

              if( SQLCODE == SQLNOTFOUND) break;
        }
        $CLOSE a_0;
        $FREE a_0;
   }

   $declare s_cur1 cursor for
     select branch
       from servertbl
      where branch != 'S1'
        and ((branch = $iupbranch) or ('*' = $iupbranch) or (branch = (select iupcomp from branch where ibranch = $iupbranch)))
      order by branch;
   
   $open s_cur1;
   for(;;)
   {
   $fetch s_cur1 into $iupbranch;
    if (SQLCODE == SQLNOTFOUND) break;

   strcpy(sFullName, get_full_dbname(iupbranch));

   if (strcmp(trim(ibranch_flag),"1")==0) /***�H�`/�����q�O�d��***/
   {
        sprintf_s(sStmt,3072,"SELECT a.iclaim,a.ipolicy,a.ibranch \
                         FROM %s:ca_local_clm a \
                        WHERE a.dclaim >= '%s' AND a.dclaim <= '%s' \
                        ORDER BY a.iclaim",sFullName,dclaim_ebgn,dclaim_eend);
   }
   else
   {    /*******�H���z������c�d��******/
        sprintf_s(sStmt,3072,"SELECT a.iclaim,a.ipolicy,a.ibranch  \
                         FROM %s:ca_local_clm a \
                        WHERE a.dclaim >= '%s' AND a.dclaim <= '%s' \
                          AND a.ibranch = '%s' \
                        ORDER BY iclaim",sFullName, dclaim_ebgn, dclaim_eend, ibranch);
   }

   printf("sStmt[%s]\n",sStmt);
   $PREPARE a_1 FROM $sStmt;
   $DECLARE acursor_1 CURSOR FOR a_1;
   $OPEN acursor_1;
   while(1)
   {
      $FETCH acursor_1 INTO $iclaim, $ipolicy, $ibranch;
      if( SQLCODE == SQLNOTFOUND) break;
      cnf_flag = 0;

      $SELECT ibranch_in
         INTO $ibranch_in
         FROM ca_clm_process
        WHERE iclaim = $iclaim;

       printf("ibranch_in[%s]\n",ibranch_in);

      if (SQLCODE==SQLNOTFOUND)
      {
          printf("SELECT ibranch_in in branch not found ===> iclaim[%s]\n",iclaim);
          continue;
      }

      strcpy(sFullName1, get_full_dbname(ibranch_in));

      sprintf_s(sStmt1,3072,
       " SELECT fcard_class     \
           FROM %s:ply_relation \
          WHERE ipolicy = '%s' ",sFullName1,ipolicy);
      $PREPARE ply FROM $sStmt1;
      $EXECUTE ply INTO $fcard_class;

     lMins_sum = 0;
     if (fcard_class[0] == '2')
     {
        sprintf_s(sStmt1,3072,
         " SELECT iins_type,mins_app,mproc_app \
             FROM %s:app_ins_type    \
            WHERE iclaim = '%s' ",sFullName1,iclaim);

        $PREPARE app_ins FROM $sStmt1;
        $DECLARE app_cur CURSOR FOR app_ins;
        $OPEN app_cur;
        for(;;)
        {
        $FETCH app_cur INTO $sIins_type,$lMins_app,$mproc_app;
        if (SQLCODE == SQLNOTFOUND) break;

          sprintf_s(sStmt1,3072,
           " SELECT count(*)                       \
               FROM %s:stl_ins_type                \
              WHERE iclaim    = '%s'               \
                AND iins_type = '%s'               \
                AND flast     = '1'                \
                AND dgroup   <= '%s' ", sFullName1, iclaim, sIins_type, sDrpDate_e);

           printf("sStmt1[%s]\n",sStmt1);
           $PREPARE stl_ins FROM $sStmt1;
           $EXECUTE stl_ins INTO $iStlcnt;
            if (iStlcnt > 0) continue;

          cnf_flag = 1;

          sprintf_s(sStmt1,3072,
           " SELECT NVL(SUM(DECODE(fstl,'1',mins_stl,'2',mins_stl * (-1),0)),0) \
               FROM %s:stl_ins_type       \
              WHERE iclaim    = '%s'      \
                AND iins_type = '%s'      \
                AND dgroup   <= '%s' ", sFullName1, iclaim, sIins_type, sDrpDate_e);

            printf("sStmt1[%s]\n",sStmt1);

           $PREPARE stl_sum FROM $sStmt1;
           $EXECUTE stl_sum INTO $lMins_stl;

           if ((lMins_app - lMins_stl) > 0)
           {
              lMins_sum = (lMins_app - lMins_stl) + lMins_sum;
           }
             
           $INSERT INTO stlins VALUES ($sIins_type);
        }
        $CLOSE app_cur;
        $FREE  app_cur;

        if (cnf_flag == 0) continue;
     }
     else
     {
        sprintf_s(sStmt1,3072,
         " SELECT iins_item,ivictim,mapp_cover,mapp_fee  \
             FROM %s:ca_app_victim      \
            WHERE iclaim = '%s' ",sFullName1,iclaim);
        $PREPARE vic_ins FROM $sStmt1;
        $DECLARE vic_cur CURSOR FOR vic_ins;
        $OPEN vic_cur;
        for(;;)
        {
        $FETCH vic_cur INTO $sIins_type,$ivictim,$lMins_app,$mproc_app;
        if (SQLCODE == SQLNOTFOUND) break;

        sprintf_s(sStmt1,3072,
         " SELECT count(*)                       \
             FROM %s:ca_stl_victim               \
            WHERE iclaim    = '%s'               \
              AND iins_item = '%s'               \
              and ivictim   = '%s'               \
              AND flast in ('1','2')             \
              AND dgroup   <= '%s' ", sFullName1, iclaim, sIins_type, ivictim, sDrpDate_e);
         printf(" sStmt1[%s]\n",sStmt1);
         $PREPARE vtl_ins FROM $sStmt1;
         $EXECUTE vtl_ins INTO $iStlcnt;

         if (iStlcnt > 0) continue;
          
          cnf_flag = 1;
          
          sprintf_s(sStmt1,3072,
           " SELECT NVL(SUM(DECODE(fstl,'1',mins_stl,'2',mins_stl * (-1),0)),0) \
               FROM %s:ca_stl_victim      \
              WHERE iclaim    = '%s'      \
                AND iins_item = '%s'      \
                AND ivictim   = '%s'      \
                AND dgroup   <= '%s' ", sFullName1, iclaim, sIins_type, ivictim, sDrpDate_e);
           printf(" sStmt1[%s]\n",sStmt1);
           $PREPARE vtl_sum FROM $sStmt1;
           $EXECUTE vtl_sum INTO $lMins_stl;

           if ((lMins_app - lMins_stl) > 0)
           {
              lMins_sum = (lMins_app - lMins_stl) + lMins_sum;
           }

            $INSERT INTO stlins VALUES ($sIins_type); 
        }
        $CLOSE vic_cur;
        $FREE  vic_cur;

        if(cnf_flag == 0) continue;
     }

     strcpy(sCatIns,"");

     $DECLARE stli_cur CURSOR FOR
       SELECT UNIQUE ins_type
         INTO $sIins_type
         FROM stlins
        ORDER BY 1;
     $OPEN stli_cur;
     for(;;)
     {
     $FETCH stli_cur;
     if (SQLCODE == SQLNOTFOUND) break;

        sprintf_s(sCatIns,31,"%s %s",rtrim(sCatIns),sIins_type);
        printf("sIins_type[%s]\n",sIins_type);
     }
     $CLOSE stli_cur;
     $FREE  stli_cur;

     /* �ѵs�I���ۨ����I���W�ߥX�� modify by sylvia 106.10.20 (1061012004_C1) */
     /*sprintf_s(sStmt,3072,
      "  select max( case when         "
                       "  (select count(*) "
                       "     from insurance_type "
                       "    where iins_type =  a.ins_type "
                       "      and fins_grp  =  '2' "
                       "      and fkind     <> '3') > 0 then 4 "
                       "  when "
                       "  (select count(*) "
                       "     from insurance_type "
                       "    where iins_type =  a.ins_type "
                       "      and fkind     = '3')  > 0 then 3 "
                       "  when "
                       " (select count(*) "
                       "    from cu_code_data "
                       "   where icode      =  a.ins_type "
                       "     and itype      = 'CT') > 0 then 2 "
                       "  when "
                       " (select count(*) "
                       "    from insurance_type "
                       "   where iins_type  =  a.ins_type"
                       "     and iins_ply   = '21') > 0 then 1 "   
                   " else 0 "
              " end) as maxadj "
        "  from stlins a "); */
      sprintf_s(sStmt,3072,  
      "  select max( case when         "
                       "  (select count(*) "
                       "     from insurance_type "
                       "    where iins_type =  a.ins_type "
                       "      and fins_grp  =  '2' "
                       "      and fkind     <> '3') > 0 then 5 "
                       "  when "
                       "  (select count(*) "
                       "     from insurance_type "
                       "    where iins_type =  a.ins_type "
                       "      and fkind     = '3')  > 0 then 4 "
                       "  when "
                       " (select count(*)         "
                       "    from insurance_type   "
                       "   where iins_type =  a.ins_type       "
                       "     and fkind     = '2')  > 0 then 3   "
                       "  when "
                       " (select count(*) "
                       "    from insurance_type "
                       "   where iins_type  =  a.ins_type"
                       "     and iins_ply   = '21') > 0 then 1 "   
                   " else 2 "
              " end) as maxadj "
        "  from stlins a ");
      printf("569sStmt=[%s]\n",sStmt );
      $prepare exe_maxadj from $sStmt;
      $execute exe_maxadj into $iMaxCnt;

     $DELETE FROM stlins WHERE 0 = 0;

     if (strlen(trim(sCatIns)) == 0) continue;
     
     /* �s�W�߮��I���k�� add by sylvia 106.10.20 (1061012004_C1) */
     if (fcard_class[0] == '2')
     {
         sprintf_s(sStmt,3072,  
         "  select max( case when         "
               "  (select count(*) "
               "     from insurance_type "
               "    where iins_type =  a.iins_type "
               "      and fins_grp  =  '2' "
               "      and fkind     <> '3') > 0 then 5 "
               "  when "
               "  (select count(*) "
               "     from insurance_type "
               "    where iins_type =  a.iins_type "
               "      and fkind     = '3')  > 0 then 4 "
               "  when "
               " (select count(*)         "
               "    from insurance_type   "
               "   where iins_type =  a.iins_type       "
               "     and fkind     = '2')  > 0 then 3   "
               "  when "
               " (select count(*) "
               "    from insurance_type "
               "   where iins_type  =  a.iins_type"
               "     and iins_ply   = '21') > 0 then 1 "   
           " else 2 "
          " end)  "
          "  from %s:app_ins_type a WHERE iclaim = '%s' ",sFullName1,iclaim);
          printf("605sStmt=[%s]\n",sStmt );
          $prepare exe_maxapp from $sStmt;
          $execute exe_maxapp into $imaxapp;
      }
      else
      {
         /* �j���I */
         imaxapp = 1;
      }  

      $INSERT INTO car825_TEMP
        VALUES ($sFullName1, $ibranch, $iclaim, $sCatIns, $lMins_sum, $iMaxCnt,$imaxapp);

      strcpy(sCatIns,"");
   }
   $CLOSE acursor_1;
   $FREE acursor_1;

   }
   $close s_cur1;
   $free  s_cur1;  

   printf("debugscott process SUCCESS !!\n\n");
   return SUCCESS;

errexit:
   printf( "*** SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
   rc = isEWRITE(SQLCODE,sqlca.sqlerrm);
   isfinish(rc);
} /* car825_process */

car825_data()
{
   int   i;
   $char ibranch[6];
   $char iclaim[16],Tmp[101];
   $char scatins[101],sFullName1[31];
   $long msettle=0;
   $char nname[21];
   $char iadjuster[21],nassured[101];
   $char dclaim[11],daccident[11];
   $int  count_825=0;
   $char iupcomp[3];
   $char nquota[41];
   $char nlocal[41];
   $int  imaxadj=0, imaxapp=0;

   $WHENEVER SQLERROR GOTO errexit;
   printf("enter car825_data[%s]\n", outputf);


$select count(*)
 into $count_825
 from car825_TEMP;
 
printf(" 666666666666666666666count_825[%d] \n",count_825); 

   $DECLARE Scur CURSOR FOR
     SELECT *
       INTO $sFullName1,$ibranch,$iclaim,$scatins,$msettle,$imaxadj,$imaxapp
       FROM car825_TEMP;
   $OPEN Scur;
   for(;;)
   {
   $FETCH Scur ;
   if (SQLCODE == SQLNOTFOUND) break;

   sprintf_s(sStmt,3072,
    "SELECT DATE(b.dclaim), a.nassured, b.iadjuster, DATE(a.daccident),b.factory_1  \
       FROM %s:adjustment_ply a ,%s:appraisal b                   \
      WHERE a.iclaim = '%s'                                       \
        AND b.iclaim = a.iclaim ",rtrim(sFullName1),rtrim(sFullName1),iclaim);

    printf("sStmt[%s]\n",sStmt);

   $PREPARE adj_id1 FROM $sStmt;
   $EXECUTE adj_id1 INTO $dclaim, $nassured, $iadjuster, $daccident,$factory1;

   printf("dclaim[%s]\n",dclaim);
   $SELECT nname, decode(iupcomp,'0','00','1','40','2','70','5','22','6','33','7','66') as iupcomp,
           (select xx.nbranch from sa_branch_type xx where xx.ibranch = officer.iquota) as nquota,
           (select yy.nchi_full from branch yy, cm_clm_adjuster zz where zz.iapp_unit = yy.ibranch and zz.empl_no = officer.iofficer) as nlocal
      INTO $nname, $iupcomp, $nquota, $nlocal
      FROM officer
     WHERE iofficer = $iadjuster;
     if (SQLCODE == SQLNOTFOUND)
     {
        strcpy(nname," ");
        strcpy(iupcomp," ");
        strcpy(nquota," ");
        strcpy(nlocal," ");
     }

/*********************************************************

   $SELECT nchi_full
      INTO $Tmp
      FROM v_branch
     WHERE ibranch = $ibranch;
   if (SQLCODE == SQLNOTFOUND) strcpy(Tmp,ibranch);

**********************************************************/
  
   $SELECT nchi_full
      INTO $nfactory
      FROM cu_customer
     WHERE ifpce_id = $factory1
       AND ifpce_id_ext = ' ';
     if (SQLCODE == SQLNOTFOUND) strcpy(nfactory," ");


   /* �`�����q�O  */
   rgu_put_body_string(1,iupcomp,1);

   /* ���        */
   rgu_put_body_string(1,trim(nquota),1);

   /* �Ҧb�a  */
   rgu_put_body_string(1,trim(nlocal),1);

   /* �z�ߤH�� */
   rgu_put_body_string(1,trim(nname),1);

   /* �߮׸��X */
   rgu_put_body_string(1,trim(iclaim),1);

   /* �Q�O�I�H */
   rgu_put_body_string(1,trim(nassured),1);

   /* ���z��� */
   rgu_put_body_string(1,trim(dclaim),1);

   /* �X�I��� */
   rgu_put_body_string(1,trim(daccident),1);

   /* ���M�I�� */
   rgu_put_body_string(1,rtrim(scatins),1);

   /* ���M�ߴ� */
   rfmtlong(msettle,fmt,Tmp);
   rgu_put_body_string(1,rtrim(Tmp),1);

   /* �ѵs�I���ۨ����I���W�ߥX�� modify by sylvia 106.10.20 (1061012004_C1) */ 
   strcpy(Tmp,"");
   switch(imaxadj)
   {
       case 5:   strcpy(Tmp,"�ˮ`");
                 break;
       case 4:   strcpy(Tmp,"�]�l");
                 break;
       case 3:   strcpy(Tmp,"�ѵs");
                 break;
       case 2:   strcpy(Tmp,"����");
                 break;
       case 1:   strcpy(Tmp,"�j��");
                 break;
       default:  strcpy(Tmp,"����");
                 break;
   }

   /* ���M�I���k�����O */
   rgu_put_body_string(1,rtrim(Tmp),1);

   rgu_put_body_string(1,rtrim(factory1),1);
   rgu_put_body_string(1,rtrim(nfactory),1);
   
   
   /* �s�W �߮��I���k�����O add by sylvia 106.10.20 (1061012004_C1) */ 
   strcpy(Tmp,"");
   switch(imaxapp)
   {
       case 5:   strcpy(Tmp,"�ˮ`");
                 break;
       case 4:   strcpy(Tmp,"�]�l");
                 break;
       case 3:   strcpy(Tmp,"�ѵs");
                 break;
       case 2:   strcpy(Tmp,"����");
                 break;
       case 1:   strcpy(Tmp,"�j��");
                 break;
       default:  strcpy(Tmp,"����");
                 break;
   }

   /* �߮��I���k�����O */
   rgu_put_body_string(1,rtrim(Tmp),1);
   
   rgu_put_body(1);     max_count++;


  }
  $CLOSE Scur;
  $FREE  Scur;

  return SUCCESS;

errexit:
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(1);
}

char *get_car_full_db(sIpolicy)

char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  static char sTmp_db_name[21];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, sTmpcomp);
  }
  return sTmp_db_name;
}

