/**********************************************************************/
/*   program id   : ca352p01s.ec                                      */
/*   program name : �Ȧ������O²�T�H�o�@�~                   	      */
/*   date written : 2019/06/27 by 071004                              */
/*   files        :                                                   */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <decimal.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "globdata.h"
#include "safeclib.h"

char ioption[2];

char  sApHome[30];
int   count_db,k; 
char  outputf[21];
$char userid[11];
$char DBName[05];
$char FormTp[03];
$char msgbuf[128];
$char Full_DBName[31],sDdate[11];
char  ddate[11];

$char mobil_phone[21],dply_end[11],itag[11],iofficer[21];
$char sIpolicy[21],sInext_ply[21];
 
int   max_count;
static char *get_car_full_db();
$char  sMsg[512];
FILE *sfp;
DBinfo *list;

/*********************************************************************/
main(argc, argv)
int argc;
char **argv;
{
 	int rc;

	batchinit();
	strcpy(DBName,         isNULLstr(argv[1]));
	strcpy(userid,         isNULLstr(argv[2]));
	strcpy(ioption,        isNULLstr(argv[3]));  /*1:�C��15��Ƶ{�H�o2�Ӥ��������O�q��²�T 2:�C��Ƶ{�H�o20�ѫ���������O����O�q��²�T�ȭ��j���I*/ 
	strcpy(ddate,          isNULLstr(argv[4]));  /* cyy/mm/dd */                                     
	strcpy(outputf,        isNULLstr(argv[5]));
	
        strcpy(sDdate,cm_to_infdate(ddate));   /* sDdate:MM/DD/YYYY */
        strcpy(sDdate,trim(sDdate));
        printf("-----sDdate : [%s]\n-----",sDdate);
    
        sfp = STARTLOG();
	rc = car352_get_db();
	if (rc != M_CM_OK)
		return rc;


        if(strcmp(ioption,"1")==0)  /*�C��15��Ƶ{�H�o2�Ӥ��������O�q��²�T*/
        {
              rc = car352_schedle1();
	      if (rc != M_CM_OK) 
		   return rc;
        }
        else if(strcmp(ioption,"2")==0)  /*�C��Ƶ{�H�o20�ѫ���������O����O�q��²�T�ȭ��j���I*/
        {
              rc = car352_schedle2();
	      if (rc != M_CM_OK) 
		   return rc;
        }
        

    
	ENDLOG(sfp);
}
/*----------------------------------------------------------------------------*/
long car352_get_db()
{
	int rc;
	$whenever sqlerror goto errexit;

	if (db_select(DBName) == FALSE) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}
	
        rc = getApHome(sApHome);
        if (rc < 0) {
            strcpy(msgbuf,"read Config file error!!-->getApHome\n");
            EWRITE(userid,rc,msgbuf);
            return rc;
        }
        
	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}


/*----------------------------------------------------------------------------*/
long car352_schedle1()  /*�C��15��Ƶ{�H�o2�Ӥ��������O�q��²�T*/
{
 
 FILE *fp0 ;
 FILE *report ;
 int rc;
 $char lExec_Date_YYY[4] = {"\0"} ;  /* ���o�~ */
 $char lExec_Date_MM[3] = {"\0"} ;   /* ���o�� */
 $char lExec_Date_DD[3] = {"\0"} ;   /* ���o�� */
 $char file0[151] = {"\0"} ;         /* �ɮצs�񪺦�m  */
 $char filename[151] = {"\0"} ;
 char  filename1[151];
 /*$char nassured[41],mobil_phone[21],dply_end[11],itag[11];*/
 $char dbegin[11],dend[11];
 int isms;
 char yy[5],mm[3],dd[3];
 $char stmt1[1024],stmt2[1024];
 char *dash_loc;
 	
	$WHENEVER SQLERROR GOTO errexit;

        
        
        isms=1;
        
	cm_char_split_3ymd( ddate, lExec_Date_YYY, lExec_Date_MM, lExec_Date_DD ) ;
	sprintf_s(file0,sizeof file0, "%s/rptftp/car352_%s_%s_%s_monthly.txt", sApHome, lExec_Date_YYY, lExec_Date_MM, lExec_Date_DD);
        fp0 = fopen( file0, "w" ) ;
	sprintf_s(filename,sizeof filename, "%s/rptftp/report_car352_monthly_%s%s%s.csv", sApHome, lExec_Date_YYY, lExec_Date_MM, lExec_Date_DD);
	sprintf_s(filename1,sizeof filename1, "report_car352_monthly_%s%s%s.csv", lExec_Date_YYY, lExec_Date_MM, lExec_Date_DD);
	report=fopen(filename,"w");
	sprintf_s( sMsg,sizeof sMsg,"�Ȧ������O²�T�H�o����(2�Ӥ����)");
	fprintf( report, "%s\n", sMsg);
	sprintf_s( sMsg,sizeof sMsg,"�g��N��,���P,������X,�O������,�O�渹,�Ƶ�");
	fprintf( report, "%s\n", sMsg);	
	/*�n�������O������_��*/
	if(atoi(lExec_Date_MM)<10)
	{
		$SELECT FIRST 1 MDY(MONTH($sDdate)+2,1, YEAR($sDdate)),MDY(MONTH($sDdate)+3,1, YEAR($sDdate))-1
		   INTO $dbegin,$dend
                   FROM systables;
		
	}
	else if(strcmp(lExec_Date_MM,"10")==0)
	{
		$SELECT FIRST 1 MDY(12,1, YEAR($sDdate)),MDY(1,1, YEAR($sDdate)+1)-1
                   INTO $dbegin,$dend
                   FROM systables;
	}
	else if(strcmp(lExec_Date_MM,"11")==0)
	{
	        $SELECT FIRST 1 MDY(1,1, YEAR($sDdate)+1),MDY(2,1, YEAR($sDdate)+1)-1
                   INTO $dbegin,$dend
                   FROM systables;
	}
	else if(strcmp(lExec_Date_MM,"12")==0)
	{
		$SELECT FIRST 1 MDY(2,1, YEAR($sDdate)+1),MDY(3,1, YEAR($sDdate)+1)-1
                  INTO $dbegin,$dend
                  FROM systables;	
	}
	printf("dbegin[%s]dend[%s]\n",dbegin,dend);
	

	
        /*������O�ɸg��N���O�x�s����R61025F014 �B �����O2�Ӥ뤧��*/
        /*�W�[�@�Ⱥ���R61032O (1111117007_SC1)*/
        sprintf_s( stmt1,sizeof stmt1," SELECT a.iofficer,a.itag,min(a.dply_begin),  "
                       "        min(b.mobil_phone),min(a.ipolicy) "
                       "   FROM policy_302 a,newa00:policy b "
                       "  WHERE a.dply_begin BETWEEN '%s' AND '%s' "
                       "    AND a.iofficer in ('R61025F014','R61032O') "
                       "    AND b.ipolicy = a.ipolicy "
                       "    AND b.mobil_phone IS NOT NULL AND b.mobil_phone!='' "
                       "  GROUP BY a.iofficer,a.itag "
                       "  ORDER BY a.iofficer,a.itag \n",dbegin,dend);
        printf("stmt1[%s]",stmt1);
        
        $PREPARE prep1 FROM $stmt1;
        $DECLARE curs1 CURSOR FOR prep1;
        $OPEN curs1;
        for(;;)
        {

            $FETCH curs1 INTO $iofficer,$itag,$dply_end,$mobil_phone,$sIpolicy;
        
            if( SQLCODE == SQLNOTFOUND) break;            
 
            yy[0] = dply_end[6];
            yy[1] = dply_end[7];
            yy[2] = dply_end[8];
            yy[3] = dply_end[9];
            yy[4] = '\0';
            strcpy(yy,itoa(atoi(trim(yy))-1911));

            mm[0] = dply_end[0];
            mm[1] = dply_end[1];
            mm[2] = '\0';
            strcpy(mm,trim(mm));

            dd[0] = dply_end[3];
            dd[1] = dply_end[4];
            dd[2] = '\0';
            strcpy(dd,trim(dd));

            /*�ˬd�O�_�w��O*/
            strcpy(Full_DBName,get_car_full_db(sIpolicy));
            sprintf_s(stmt2,sizeof stmt2,"SELECT inext_ply FROM %s:ply_relation WHERE ipolicy = '%s'",Full_DBName, trim(sIpolicy) );

            $PREPARE curs2 FROM $stmt2;
            $EXECUTE curs2 INTO $sInext_ply;

            if( strlen(trim(sInext_ply)) > 0 )
            {
      	         /* ����O���A���ܤw��O�A���H�o²�T */
                 sprintf_s( sMsg,sizeof sMsg,"%s,%s,%s,%s/%s/%s,%s,�w��O",iofficer,itag,mobil_phone,yy,mm,dd,trim(sIpolicy));
                 fprintf( report, "%s\n", sMsg);
                 /*WRITELOG( sfp, sMsg);*/
                 /*printf("mobil_phone[%s]dply_end[%s]itag[%s]sInext_ply[%s]\n",mobil_phone,dply_end,itag,sInext_ply);*/
            }
            else
            {
            	 /* �L��O���A���ܥ���O�A�H�o²�T */
                 sprintf_s(sMsg,sizeof sMsg,"%s,%s,%s,%s/%s/%s,%s,�N�H�o²�T",iofficer,itag,mobil_phone,yy,mm,dd,trim(sIpolicy));
                 fprintf(report, "%s\n", sMsg);  
                           	
            	 strcpy(itag,trim(itag));
            	 dash_loc=strstr(itag,"-");
            	 if (dash_loc != NULL)
            	 {
            	     itag[dash_loc-itag-1] = '*';
                     itag[dash_loc-itag+1] = '*';
            	 }
            	 
            	 if (strcmp(trim(iofficer),"R61025F014")==0)
            	 {
            	 	fprintf(fp0, "%s%d$$%s$$$$$$$$$$",trim(mobil_phone),isms,trim(mobil_phone));
            	 	fprintf(fp0, "�z�n�A�����z %s ���I�N�� %s/%s/%s ����12�ɨ���A�����z�ȥ������e�� https://tsbk.tw/7pyh8v �x�s�Ȧ�e��Fun�߫O������O�@�~�A���¡C\n",trim(itag),yy,mm,dd);
            	 }
                 else if (strcmp(trim(iofficer),"R61032O")==0)
                 {
            	 	fprintf(fp0, "%s%d$$%s$$$$$$$$$$",trim(mobil_phone),isms,trim(mobil_phone));
            	 	fprintf(fp0, "�z�n�A %s ���I�N�� %s/%s/%s ����12�ɨ���A�����z�ȥ������e�ܡu�Ĥ@�Ȧ�����Ȧ�/������O�M�ϡv������O�A���¡C\n",trim(itag),yy,mm,dd);
            	 }
                 /*WRITELOG( sfp, sMsg);*/
        
                 isms++;            	
            	
            }        

            strcpy(mobil_phone,"");
            strcpy(dply_end,"");
            strcpy(yy,"");
            strcpy(mm,"");
            strcpy(dd,"");
            strcpy(itag,"");
            strcpy(sInext_ply,"");
            
        }
        $FREE prep1;
        $CLOSE curs1;

        fclose(report);
 
        rc=rptftpinsert(userid,"car352",filename1);
        if (rc!=0) {
            EWRITE(userid,rc,"�g�Jrptftplist���~");
            return rc;
        }
        sprintf_s( sMsg,sizeof sMsg, "���I���ɮפU���@�~�d��[Q],�U�����G����[report_car352_monthly.csv]\n");
        WRITELOG( sfp, sMsg);       

	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	return SQLCODE;   
   
}
/*----------------------------------------------------------------------------*/
long car352_schedle2()  /*�C��Ƶ{�H�o20�ѫ���������O����O�q��²�T�ȭ��j���I*/
{
 
 FILE *fp0 ;
 FILE *report ;
 int rc;
 $char lExec_Date_YYY[4] = {"\0"} ;  /* ���o�~ */
 $char lExec_Date_MM[3] = {"\0"} ;   /* ���o�� */
 $char lExec_Date_DD[3] = {"\0"} ;   /* ���o�� */
 $char file0[151] = {"\0"} ;         /* �ɮצs�񪺦�m  */
 $char filename[151] = {"\0"} ; 
 /*$char nassured[41],mobil_phone[21],dply_end[11],itag[11];*/
 int isms;
 char filename1[151];
 char yy[5],mm[3],dd[3];
 $char stmt1[1024],stmt2[1024];
 char *dash_loc;
 	
	$WHENEVER SQLERROR GOTO errexit;
 
        isms=1;
        
	cm_char_split_3ymd( ddate, lExec_Date_YYY, lExec_Date_MM, lExec_Date_DD ) ;
	sprintf_s(file0,sizeof file0, "%s/rptftp/car352_%s_%s_%s_daily.txt", sApHome, lExec_Date_YYY, lExec_Date_MM, lExec_Date_DD);
        fp0 = fopen( file0, "w" ) ;
	sprintf_s(filename,sizeof filename, "%s/rptftp/report_car352_daily_%s%s%s.csv", sApHome, lExec_Date_YYY, lExec_Date_MM, lExec_Date_DD);
	sprintf_s(filename1,sizeof filename1, "report_car352_daily_%s%s%s.csv", lExec_Date_YYY, lExec_Date_MM, lExec_Date_DD);
	report=fopen(filename,"w");
	sprintf_s( sMsg,sizeof sMsg,"�x�s������O²�T�H�o����(20�����)");
	fprintf( report, "%s\n", sMsg);
	sprintf_s( sMsg,sizeof sMsg,"���P,������X,�O������,�O�渹,�Ƶ�");
	fprintf( report, "%s\n", sMsg);	


        /*������O�ɸg��N���O�x�s����R61025F014 �B ���j���I �B �����O20�ѫ�*/
        sprintf_s( stmt1,sizeof stmt1," SELECT  a.itag, min(a.dply_begin), min(b.mobil_phone),min(a.ipolicy) "
                       "   FROM  policy_302 a,newa00:policy b ,newa00:ply_relation c"
                       "  WHERE  a.dply_begin = date('%s')+20 "
                       "    AND  a.iofficer='R61025F014' AND b.ipolicy=a.ipolicy "
                       "    AND  b.mobil_phone IS NOT NULL AND b.mobil_phone!='' "
                       "    AND  c.fcard_class='1' AND b.ipolicy=c.ipolicy "
                       "  GROUP BY a.itag "
                       "  ORDER BY a.itag \n",sDdate);
        printf("stmt1[%s]",stmt1);
        
        $PREPARE prep3 FROM $stmt1;
        $DECLARE curs3 CURSOR FOR prep3;
        $OPEN curs3;
        for(;;)
        {

            $FETCH curs3 INTO $itag,$dply_end,$mobil_phone,$sIpolicy;
        
            if( SQLCODE == SQLNOTFOUND) break;
            
            yy[0] = dply_end[6];
            yy[1] = dply_end[7];
            yy[2] = dply_end[8];
            yy[3] = dply_end[9];
            yy[4] = '\0';
            strcpy(yy,itoa(atoi(trim(yy))-1911));

            mm[0] = dply_end[0];
            mm[1] = dply_end[1];
            mm[2] = '\0';
            strcpy(mm,trim(mm));

            dd[0] = dply_end[3];
            dd[1] = dply_end[4];
            dd[2] = '\0';
            strcpy(dd,trim(dd));

            /*�ˬd�O�_�w��O*/
            strcpy(Full_DBName,get_car_full_db(sIpolicy));
            sprintf_s(stmt2,sizeof stmt2,"SELECT inext_ply FROM %s:ply_relation WHERE ipolicy = '%s'",Full_DBName, trim(sIpolicy) );

            $PREPARE curs4 FROM $stmt2;
            $EXECUTE curs4 INTO $sInext_ply;

            if( strlen(trim(sInext_ply)) > 0 )
            {
      	         /* ����O���A���ܤw��O�A���H�o²�T */
                 sprintf_s( sMsg,sizeof sMsg,"%s,%s,%s/%s/%s,%s,�w��O",itag,mobil_phone, yy,mm,dd,trim(sIpolicy));
                 fprintf( report, "%s\n", sMsg);
                 /*WRITELOG( sfp, sMsg);*/
                 /*printf("mobil_phone[%s]dply_end[%s]itag[%s]sInext_ply[%s]\n",mobil_phone,dply_end,itag,sInext_ply);*/
            }
            else
            {
                 sprintf_s(sMsg,sizeof sMsg,"%s,%s,%s/%s/%s,%s,�N�H�o²�T",itag ,mobil_phone, yy,mm,dd,trim(sIpolicy));
                 fprintf(report, "%s\n", sMsg);    
                 
                         	
            	 strcpy(itag,trim(itag));
            	 dash_loc=strstr(itag,"-");
            	 if (dash_loc != NULL)
            	 {
            	     itag[dash_loc-itag-1] = '*';
                     itag[dash_loc-itag+1] = '*';
            	 }
            	
            	
            	 /* �L��O���A���ܥ���O�A�H�o²�T */
                 fprintf(fp0, "%s%d$$%s$$$$$$$$$$", trim(mobil_phone),isms, trim(mobil_phone));
                 fprintf(fp0, "�z�n�A�����z %s ���I�N�� %s/%s/%s ����12�ɨ���A�����z�ȥ������e�� https://tsbk.tw/7pyh8v �x�s�Ȧ�e��Fun�߫O������O�@�~�A���¡C\n",trim(itag),yy,mm,dd);
            

                 /*WRITELOG( sfp, sMsg);*/
        
                 isms++;            	
            	
            }        

            strcpy(mobil_phone,"");
            strcpy(dply_end,"");
            strcpy(yy,"");
            strcpy(mm,"");
            strcpy(dd,"");
            strcpy(itag,"");
            strcpy(sInext_ply,"");
            
            
        }
        $FREE prep3;
        $CLOSE curs3;
 
        fclose(report);
 
        rc=rptftpinsert(userid,"car352",filename1);
        if (rc!=0) {
            EWRITE(userid,rc,"�g�Jrptftplist���~");
            return rc;
        }
        sprintf_s( sMsg,sizeof sMsg, "���I���ɮפU���@�~�d��[Q],�U�����G����[report_car352_daily.csv]\n");
        WRITELOG( sfp, sMsg);       
        
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	return SQLCODE;   
   
}
/*--------------------------------------------------------------------*/
char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
        char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
        static char sTmp_db_name[21];

        sTmp_db_name[0]='\0';
        if (*sIpolicy != '\0' && *sIpolicy !=' ')
        {
           sTmp_db_name[0]='\0';
           strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
           strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
                  USE_BRANCH_ID));
           strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
        }
  return sTmp_db_name;
}
/*--------------------------------------------------------------------*/