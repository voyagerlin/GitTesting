/**********************************************************************/
/*   program id   : ca926m01s.ec                                      */
/*   program name : �j���I�F�d���u�վ����ﵽ���                    */
/*   date written : 2021/08/25                                        */
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include "cmnmsgs.h"
#include <math.h>
#include "safeclib.h"

long car926(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
  long rtncode;
  long car926_get_fpceid();
  long car926_multiple_query();
  char option;

  cm_buf_init(command);
  cm_buf_get("%c",&option);
  switch(option)
  {
  	case 'B':
           rtncode=car926_get_fpceid(reply);
           break;

    case 'M':
           rtncode=car926_multiple_query(reply);
           break;

    default :
           if(exitsub(reply,M_CM_WRONG_OPTION) == True)
            return M_CM_WRONG_OPTION;
           return apiRC;
  }
    return(rtncode);
}
/******************************************************************************/

long car926_get_fpceid(reply)
serverReply reply;
{
    $char DBName[DBNAME];
    $char sUserid[10], sStmt[2000], sIcompany[13], nbank[30], iaccbank[20],
          ifpce_id[11];

    char tmpbuf[4000];
    int count=0,repbuf_len=0,tmp_len=0,replycnt=0;

    cm_buf_get("%s %s ", DBName, sUserid);
    printf("-- car926_get_fpceid -- \n");
    $WHENEVER SQLERROR GOTO errexit;
    if (db_select(DBName) == False)
    {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True) return M_CM_DB_NOTOPEN;
        else return apiRC;
    }


    sprintf_s(sStmt,2000,
    	"SELECT trim(a.icode)||'�G'||trim(a.tcode_remark), ' ', ' ', ' '"
      " FROM cu_code_data a "
      "WHERE itype = 'HC' AND icode = '00' "
      "UNION all "
      "SELECT trim(a.icode)||'�G'||trim(a.tcode_remark), "
      "       trim(b.ibank)||' ('||trim(c.nchi_abv)||')', b.iaccount, b.ifpce_id "
      "  FROM cu_code_data a, cu_stl_obj b, bf_bank c "
      " WHERE a.ncode = b.ifpce_id AND b.ibank = c.ibank "
      "   AND a.itype = 'HC'" );

    $PREPARE ca_pre1 FROM $sStmt;
    $DECLARE ca_cur1 CURSOR FOR ca_pre1;
    $OPEN ca_cur1;

    for(;;) {

    	$FETCH ca_cur1 INTO $sIcompany, $nbank, $iaccbank, $ifpce_id;
    	if (SQLCODE != 0) break;

			strcpy(nbank, rtrim(nbank));
			strcpy(iaccbank, rtrim(iaccbank));
			strcpy(ifpce_id, rtrim(ifpce_id));

    	cm_buf_init(tmpbuf);
    	if ( count == 0 )
     	{
      	  cm_buf_res_msg();             /* reserve for MsgCode and count */
      	  cm_buf_res_count();
     	}
    	  cm_buf_put("%s %s %s %s", sIcompany, nbank, iaccbank,ifpce_id);
        tmp_len = cm_buf_len(tmpbuf);
    	if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
        {
      	  memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      	  repbuf_len += tmp_len;
      	  count++;
     	}
   	else                               /* more than 4K, send to client side */
     	{
      	  cm_buf_init(ReplyBuf);
      	  cm_buf_put_msg(M_CM_OK);
      	  cm_buf_put_count(count);
      	if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
        {
	        $CLOSE ca_cur1;
          return apiRC;
        }
      	else               /* clear ReplyBuf and count to start all over again */
        {
          replycnt++;
          if (replycnt == 10)   /* more than 30K, client cannot display,error */
          {
	  	      cm_buf_init(ReplyBuf);
          	cm_buf_put("%l",M_CM_OUT_SPACE);
          	tmp_len = cm_buf_len(ReplyBuf);
          	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
            	return apiRC;
            	return M_CM_OUT_SPACE;
          }
	        ReplyBuf[0] = '\0';
	        count = 0;
	        cm_buf_init(ReplyBuf);
          cm_buf_res_msg();           /* reserve for MsgCode and count */
          cm_buf_res_count();
          cm_buf_put("%s %s %s %s", sIcompany, nbank, iaccbank, ifpce_id);
	      repbuf_len = cm_buf_len(ReplyBuf);
	      count++;
       }
     }
  } /* for loop */

  $CLOSE ca_cur1;
  $FREE  ca_cur1;

  if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
   if(exitsub(reply,M_CM_NOT_FOUND) == True)
    return M_CM_NOT_FOUND;
   else
    return apiRC;
  }

errexit:
printf("--car926_get_fpceid-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
  if(exitsub(reply,SQLCODE) == True)  return SQLCODE;
  else return apiRC;
}
/******************************************************************************/

long car926_multiple_query(reply)
serverReply reply;
{
    $char DBName[DBNAME];
    $char sUserid[10], sStmt[1000], sIdate_ym[6], sCompany[21], sFlag[11],
          sItransno[31], sDcreate[11],sOthCpy[21] ;
		$int icnt = 0, imprem = 0;
    char tmpbuf[4000];
    int count=0,repbuf_len=0,tmp_len=0,replycnt=0;

    cm_buf_get("%s %s ", DBName, sUserid);
    printf("-- car926_multiple_query -- \n");
    $WHENEVER SQLERROR GOTO errexit;
    if (db_select(DBName) == False)
    {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True) return M_CM_DB_NOTOPEN;
        else return apiRC;
    }

    sprintf_s(sStmt,1000,
      "select unique idate_ym, icompany||'('||trim(b.tcode_remark)||')', "
      "       a.oth_company||'('||trim(c.tcode_remark)||')', "
      "       case when a.istl_flag = 'A' then "
      "						 a.istl_flag||' '||'�u�^' else a.istl_flag||' '||'�u�X' end, "
      "       count(unique iclaim), sum(mprem), date(a.dcreate), itransno "
      "  from ca_clm_com_trans a, cu_code_data b, cu_code_data c "
      " where a.icompany = b.icode AND a.oth_company = c.icode "
      "   and b.itype = 'HC' and c.itype = 'HC' "
      "   and a.dclose is null "
      "   and a.istl_flag in ('A','B') "
      " group by 1,2,3,4,7,8 ");

    $PREPARE ca_pre2 FROM $sStmt;
    $DECLARE ca_cur2 CURSOR FOR ca_pre2;
    $OPEN ca_cur2;
    for(;;) {
    	$FETCH ca_cur2 INTO $sIdate_ym, $sCompany, $sOthCpy, $sFlag, $icnt,
    	                    $imprem, $sDcreate, $sItransno;
    	if (SQLCODE != 0) break;

    	cm_buf_init(tmpbuf);
    	if ( count == 0 )
     	{
      	  cm_buf_res_msg();             /* reserve for MsgCode and count */
      	  cm_buf_res_count();
     	}
    	  cm_buf_put("%s %s %s %s %d %d %s %s", sIdate_ym, sCompany, sOthCpy, sFlag, icnt, imprem, sDcreate, sItransno);
        tmp_len = cm_buf_len(tmpbuf);
    	if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
        {
      	  memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      	  repbuf_len += tmp_len;
      	  count++;
     	}
   	else                               /* more than 4K, send to client side */
     	{
      	  cm_buf_init(ReplyBuf);
      	  cm_buf_put_msg(M_CM_OK);
      	  cm_buf_put_count(count);
      	if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
        {
	        $CLOSE ca_cur1;
          return apiRC;
        }
      	else               /* clear ReplyBuf and count to start all over again */
        {
          replycnt++;
          if (replycnt == 10)   /* more than 30K, client cannot display,error */
          {
	  	      cm_buf_init(ReplyBuf);
          	cm_buf_put("%l",M_CM_OUT_SPACE);
          	tmp_len = cm_buf_len(ReplyBuf);
          	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
            	return apiRC;
            	return M_CM_OUT_SPACE;
          }
	        ReplyBuf[0] = '\0';
	        count = 0;
	        cm_buf_init(ReplyBuf);
          cm_buf_res_msg();           /* reserve for MsgCode and count */
          cm_buf_res_count();
          cm_buf_put("%s %s %s %s %d %d %s %s", sIdate_ym, sCompany, sOthCpy, sFlag, icnt, imprem, sDcreate, sItransno);
	      repbuf_len = cm_buf_len(ReplyBuf);
	      count++;
       }
     }
  } /* for loop */

  $CLOSE ca_cur2;
  $FREE  ca_cur2;

  if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
   if(exitsub(reply,M_CM_NOT_FOUND) == True)
    return M_CM_NOT_FOUND;
   else
    return apiRC;
  }

errexit:
printf("--car926_multiple_query-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
  if(exitsub(reply,SQLCODE) == True)  return SQLCODE;
  else return apiRC;
}
