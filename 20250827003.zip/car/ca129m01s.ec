/************************************************/
/*                                              */
/*   PROGRAM : ca102m01s.ec by Pei-Chow Chen    */
/*                                              */
/*   PURPOSE : server side standard program     */
/*                                              */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "commsgs.h"
$include sqlca;
#include "safeclib.h"

long car129(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car129_insert(),car129_single_query(),car129_multiple_query(),
      car129_update_exec();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'A':
           rtncode=car129_insert(reply);
           break;
  case 'Q':
           rtncode=car129_single_query(reply);
           break;
  case 'M':
           rtncode=car129_multiple_query(reply);
           break;
  case 'T':
           rtncode=car129_tag_query(reply);
           break;
  case 'D':
  case 'U':
           rtncode=car129_update_exec(reply,command,com_len);
           break;
  default :
           if(exitsub(reply,M_CM_WRONG_OPTION) == True)
             return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}

long car129_insert(reply)
serverReply reply;
{
 $char DBName[5],assured[41],license[11],tag[CA_TAG_NUM];
 $char engine[CA_ENGINE_NUM],body[CA_BODY_NUM],reason[2];
 $char remark[101];
 $char str_dcreate[11],dcreate[11],icreate[11];
 long MsgCode;
 int tmp_len;
   DBinfo *list;
   int i, j, is_add_fail=0, api_f;
   $char stmt_buf[300];

 cm_buf_get("%s %s %s %s %s %s %s %s %s %s ",DBName,tag,engine,body,license,
                                assured,reason,remark,icreate,str_dcreate);

 strcpy(dcreate, cm_to_infdate(str_dcreate));

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
  }

 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
  {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
  }


 $BEGIN WORK;
 for(j=0;j<i;j++)
 {
  sprintf_s(stmt_buf,300, "INSERT INTO %s:reject_client\
         (nassured,ilicense,itag,iengine,ibody,freason,remark,icreate,dcreate,iupdate,dupdate) VALUES(?,?,?,?,?,?,?,?,today,?,current)"
                    ,list[j].dbname);

  $PREPARE a_id FROM $stmt_buf;
  if(SQLCODE != 0)
   {
    is_add_fail = 1;
    break;
   }
  $EXECUTE a_id USING $assured,$license,$tag,$engine,$body,$reason,$remark,$icreate,$icreate;
  if(SQLCODE != 0)
   {
    is_add_fail = 1;
    break;
   }
  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);
  tmp_len = cm_buf_len(ReplyBuf);
  if( j == i-1 )
     api_f = api_OKComplete;
  else
     api_f = api_OK;

  if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
    {
     is_add_fail = 2;
     break;
    }  
 } /* for loop */

 if( is_add_fail == 1 ) goto errexit;

 if( is_add_fail == 2 ) 
  {
   $ROLLBACK WORK;
   return apiRC;
  }


 $WHENEVER SQLERROR GOTO errexit;
 $COMMIT WORK;
 return api_OKComplete;

errexit:
   MsgCode = SQLCODE;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
     return MsgCode;
   else
     return apiRC;
}

long car129_single_query(reply)
serverReply reply;
{
 $char DBName[5],assured[41],license[11],tag[CA_TAG_NUM];
 $char engine[CA_ENGINE_NUM],body[CA_BODY_NUM],reason[2],remark[101];

 $char sWhereTag[27],sWhereEngine[35],sWhereBody[34];
 $char sWhereLicense[37],sWhereAssured[54];
 $char buff[250];
 $char icreate[11],dcreate[11],nname[20];

 int tmp_len;

 cm_buf_get("%s %s %s %s %s %s",DBName,tag,engine,body,license,assured);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
    return M_CM_DB_NOTOPEN;
   else
    return apiRC;
 }

 if (tag[0]==' ' || tag[0]=='\0') {
     strcpy(sWhereTag,"(itag is null or itag=' ')");
 } else {
     sprintf_s(sWhereTag,27,"(itag='%s')",tag);
 }
printf("----- tag [%s]\n",sWhereTag);

/* if (engine[0]==' ' || engine[0]=='\0') {
     strcpy(sWhereEngine,"AND (iengine is null or iengine=' ')");
 } else {
     sprintf_s(sWhereEngine,35,"AND (iengine='%s')",engine);
 }
printf("----- engine [%s]\n",sWhereEngine);*/
strcpy(sWhereEngine,"");

 if (body[0]==' ' || body[0]=='\0') {
     strcpy(sWhereBody,"AND (ibody is null or ibody=' ')");
 } else {
     sprintf_s(sWhereBody,34,"AND (ibody='%s')",body);
 }
printf("----- body [%s]\n",sWhereBody);

 if (license[0]==' ' || license[0]=='\0') {
     strcpy(sWhereLicense,"AND (ilicense is null or ilicense=' ')");
 } else {
     sprintf_s(sWhereLicense,37,"AND (ilicense='%s')",license);
 }
printf("----- license [%s]\n",sWhereLicense);

 if (assured[0]==' ' || assured[0]=='\0') {
     strcpy(sWhereAssured,"AND (nassured is null or nassured=' ')");
 } else {
     sprintf_s(sWhereAssured,54,"AND (nassured=?)");
 }
 printf("----- assured [%s]\n",sWhereAssured);


 sprintf_s(buff,250,"SELECT freason , remark ,icreate,dcreate, iengine  FROM reject_client WHERE %s %s %s %s %s AND freason = '6'",
              sWhereTag,sWhereEngine,sWhereBody,
              sWhereLicense,sWhereAssured);
 printf("----- buff [%s]\n",buff);
 $PREPARE CUR_SEL FROM $buff;
 $DECLARE scur CURSOR FOR CUR_SEL;
 if (assured[0]==' ' || assured[0]=='\0')
   $OPEN scur;
 else
   $OPEN scur USING $assured;
 $FETCH scur INTO $reason,$remark,$icreate,$dcreate,$engine;


 if(SQLCODE==SQLNOTFOUND)
  {
    $CLOSE scur;
   if(exitsub(reply,M_CM_NOT_FOUND) == True)      /*?*/
    return M_CM_NOT_FOUND;                        /*?*/
   else
    return apiRC;
  }
 printf("dcreate[%s]\n",dcreate);
 strcpy(dcreate,cm_from_infdate(dcreate));

 cm_buf_init(ReplyBuf);

 cm_buf_put("%l %s %s %s %s %s %s %s %s %s",M_CM_OK,tag,engine,license,assured,
                                    body,reason,remark,icreate,dcreate);


  $SELECT nname
     INTO $nname
     FROM officer
    WHERE iofficer = $icreate;

 cm_buf_put("%s",nname);



 $CLOSE scur;
 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
  return apiRC;
 else
  return api_OKComplete;

errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}

long car129_multiple_query(reply)
serverReply reply;
{
 $char DBName[5],assured[41],license[11],tag[CA_TAG_NUM];
 $char engine[CA_ENGINE_NUM],body[CA_BODY_NUM],reason[2],remark[101];

 $char key_assured[41],key_license[11],key_tag[CA_TAG_NUM];
 $char key_engine[CA_ENGINE_NUM],key_body[CA_BODY_NUM];
 $char sWhereTag[60],sWhereEngine[60],sWhereBody[60];
 $char sWhereLicense[60],sWhereAssured[60];
 $char buff[250];
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0;

 cm_buf_get("%s %s %s %s %s %s",DBName,key_tag,key_engine,key_body,
                                key_license,key_assured);


 if (key_tag[0]=='*') {
     strcpy(sWhereTag,"(itag MATCHES ? or itag is null)");
 } else {
     sprintf_s(sWhereTag,60,"(itag MATCHES ?)");
 }
printf("----- tag [%s]\n",sWhereTag);

 if (key_engine[0]=='*') {
     strcpy(sWhereEngine,"AND (iengine MATCHES ? or iengine is null)");
 } else {
     sprintf_s(sWhereEngine,60,"AND (iengine MATCHES ?)");
 }
printf("----- engine [%s]\n",sWhereEngine);

 if (key_body[0]=='*') {
     strcpy(sWhereBody,"AND (ibody MATCHES ?  or ibody is null)");
 } else {
     sprintf_s(sWhereBody,60,"AND (ibody MATCHES ?)");
 }
printf("----- body [%s]\n",sWhereBody);

 if (key_license[0]=='*') {
     strcpy(sWhereLicense,"AND (ilicense MATCHES ? or ilicense is null)");
 } else {
     sprintf_s(sWhereLicense,60,"AND (ilicense MATCHES ?)");
 }
printf("----- license [%s]\n",sWhereLicense);

 if (key_assured[0]=='*') {
     strcpy(sWhereAssured,"AND (nassured MATCHES ? or nassured is null)");
 } else {
     sprintf_s(sWhereAssured,60,"AND (nassured MATCHES ?)");
 }
printf("----- assured [%s]\n",sWhereAssured);




 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 
 sprintf_s(buff,250,"SELECT nassured, ilicense, iengine, ibody, freason, itag \
         FROM reject_client WHERE %s %s %s %s %s AND freason = '6' \
          ORDER BY itag",sWhereTag,sWhereEngine,sWhereBody,\
                         sWhereLicense,sWhereAssured);

printf("----- buff [%s]\n",buff);
 $PREPARE CUR FROM $buff;
 $DECLARE q_cur CURSOR FOR CUR;
 
 $OPEN q_cur USING $key_tag,$key_engine,$key_body,$key_license,$key_assured;

 for(;;)
  {
     $FETCH q_cur INTO $assured,$license,$engine,$body,$reason,$tag;
    if (SQLCODE != 0) break;
    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();
     }
    cm_buf_put("%s %s %s %s %s",tag,engine,license,assured,body);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
        $CLOSE q_cur;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s %s %s %s",tag,engine,license,assured,body);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
  } /* for loop */

 $CLOSE q_cur;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
    if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
      return M_CM_NOT_FOUND;                               /*?*/
    else
      return apiRC;
  }

errexit:
   if(exitsub(reply,SQLCODE) == True)
     return SQLCODE;
   else
     return apiRC;
}

long car129_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 $char DBName[5],assured[41],license[11],tag[CA_TAG_NUM];
 $char engine[CA_ENGINE_NUM],body[CA_BODY_NUM],reason[2],remark[101];

 $char cur_reason[2];

 $char old_assured[41],old_license[11],old_tag[CA_TAG_NUM];
 $char old_engine[CA_ENGINE_NUM],old_body[CA_BODY_NUM],old_reason[2];
 $char sWhereTag[27],sWhereEngine[35],sWhereBody[34];
 $char sWhereLicense[37],sWhereAssured[54];
 $char buff[250];
 $char u_create[11],d_create[11],create[11];
 $char icreate[11],dcreate[11],nname[20];

 char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
 int tmp_len,raw_len;
 long dummy;
 long MsgCode;
   DBinfo *list;
   int i, j, is_del_fail=0, is_upd_fail=0;
   $char stmt_buf[300];

 comm = (char *) command;
 cm_buf_init(command);
 cm_buf_get("%c %s",&option,DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
  {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
  }
 /* compare old record and current record, if the record has not been changed
    since last request, update or delete the record, otherwise return errmsg
    to client side */

 /* get old record info from command buffer */

 memcpy(&raw_len,&comm[com_len],sizeof(int));
 pos = &comm[com_len+sizeof(int)];
 raw_ptr = malloc(raw_len);
 if (raw_ptr != (char*)0){
	memcpy(raw_ptr,pos,raw_len);
 } else {
   if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */
     return M_CM_NOT_MALLOC;
   else
     return apiRC;
  }

 cm_buf_init(raw_ptr);          /* get index key from old record */

 cm_buf_get("%l %s %s %s %s %s",&dummy,tag,engine,license,assured,body);

 $BEGIN WORK;

 if (tag[0]==' ' || tag[0]=='\0') {
     strcpy(sWhereTag,"(itag is null or itag=' ')");
 } else {
     sprintf_s(sWhereTag,27,"(itag='%s')",tag);
 }
printf("----- tag [%s]\n",sWhereTag);

 if (engine[0]==' ' || engine[0]=='\0') {
     strcpy(sWhereEngine,"AND (iengine is null or iengine=' ')");
 } else {
     sprintf_s(sWhereEngine,35,"AND (iengine='%s')",engine);
 }
printf("----- engine [%s]\n",sWhereEngine);

 if (body[0]==' ' || body[0]=='\0') {
     strcpy(sWhereBody,"AND (ibody is null or ibody=' ')");
 } else {
     sprintf_s(sWhereBody,34,"AND (ibody='%s')",body);
 }
printf("----- body [%s]\n",sWhereBody);

 if (license[0]==' ' || license[0]=='\0') {
     strcpy(sWhereLicense,"AND (ilicense is null or ilicense=' ')");
 } else {
     sprintf_s(sWhereLicense,37,"AND (ilicense='%s')",license);
 }
printf("----- license [%s]\n",sWhereLicense);

 if (assured[0]==' ' || assured[0]=='\0') {
     strcpy(sWhereAssured,"AND (nassured is null or nassured=' ')");
 } else {
     sprintf_s(sWhereAssured,54,"AND (nassured=?)");
 }
printf("----- assured [%s]\n",sWhereAssured);

 sprintf_s(buff,250,"SELECT freason , remark,icreate,dcreate FROM reject_client WHERE %s %s %s %s %s",
              sWhereTag,sWhereEngine,sWhereBody,
              sWhereLicense,sWhereAssured);
printf("----- buff [%s]\n",buff);
 $PREPARE CUR_SEL1 FROM $buff;
 $DECLARE scur1 CURSOR FOR CUR_SEL1;
 if (assured[0]==' ' || assured[0]=='\0')
   $OPEN scur1;
 else
   $OPEN scur1 USING $assured;
 $FETCH scur1 INTO $cur_reason,$remark,$icreate,$dcreate;


  /* if key value has been changed then SQLNOTFOUND,else put current value
     into cur_buf for comparison */

 if (SQLCODE == SQLNOTFOUND)
 {$CLOSE scur1;
   MsgCode = M_CM_NOT_FOUND;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;              /* rollback fail */
   if(SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
     return MsgCode;
   else
     return apiRC;
 }

  $SELECT nname
     INTO $nname
     FROM officer
    WHERE iofficer = $icreate;

  $CLOSE scur1;

 strcpy(dcreate,cm_from_infdate(dcreate));
 cm_buf_init(cur_buf);
 cm_buf_put("%l %s %s %s %s %s %s %s %s %s",dummy,tag,engine,license,assured,body,
                                         cur_reason,remark,icreate,dcreate);

 cm_buf_put("%s",nname);

  printf("raw_len=[%d]\n", raw_len );
  printf("cuf_buf=[%s]\n", cur_buf );
  printf("raw_ptr=[%s]\n", raw_ptr );


 if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
 {
   MsgCode = M_CM_NOT_EQUAL;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;              /* rollback fail */
   if(SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
     return MsgCode;
   else
     return apiRC;
 }

 /* equal, then exec DB operation */

 if ( option == 'D' )
  {
  free(raw_ptr);
   for(j=0;j<i;j++)
   {
    sprintf_s(stmt_buf,300,"DELETE FROM %s:reject_client WHERE (itag=? or \
            itag is null) AND (iengine=? or iengine is null)\
        AND (ibody=? or ibody is null) AND (ilicense=? or ilicense is \
             null ) AND (nassured=? or nassured is null) AND \
            (freason=? or freason is null)",list[j].dbname);
    printf(" stmt_bufDDDDDDDDDDDDDDDDDD[%s]\n",stmt_buf);
    $PREPARE d_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      break;
     }
    $EXECUTE d_id USING $tag,$engine,$body,$license,$assured,$cur_reason;
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      break;
     }
   }/* for loop */

   if( is_del_fail ) goto errexit;
   
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
   {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
   }

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else if (option == 'U')
  {
   cm_buf_init(command);
   cm_buf_get("%c %s %s %s %s %s %s %s %s %s %s",&option,DBName,tag,engine,body,license,
                                     assured,reason,remark,create,d_create);

   printf("111111111d_create[%s]\n",d_create);
   strcpy(d_create,cm_to_infdate(d_create));
   printf("d_create[%s]\n",d_create);

   /* grasp old key */
   cm_buf_init(raw_ptr);
   free(raw_ptr);
   cm_buf_get("%l %s %s %s %s %s",&dummy,old_tag,old_engine,
               old_license, old_assured, old_body);

/*   $WHENEVER SQLERROR CONTINUE;*/
   for(j=0;j<i;j++)
   {
    sprintf_s(stmt_buf,300,"UPDATE %s:reject_client \
        SET (itag,iengine,ibody,ilicense,nassured,freason,remark,iupdate,dupdate)\
        =(?,?,?,?,?,?,?,?,current) WHERE (itag=? ) AND (iengine=?) \
        AND (ibody=?) AND (ilicense=?) \
        AND (nassured=? )",list[j].dbname);

    printf("stmt_buf[%s]\n",stmt_buf);
    $PREPARE u_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      break;
     }
    $EXECUTE u_id USING $tag,$engine,$body,$license,$assured,$reason,$remark,$create,
        $old_tag ,$old_engine ,$old_body ,$old_license ,$old_assured;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      break;
     }
    if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
     {
        sprintf_s(stmt_buf,300, "INSERT INTO %s:reject_client\
         (nassured,ilicense,itag,iengine,ibody,freason,remark,icreate,dcreate,\
	  iupdate,dupdate) VALUES(?,?,?,?,?,?,?,?,today,?,current)"
                    ,list[j].dbname);

      $PREPARE ua_id FROM $stmt_buf;
      if(SQLCODE != 0) {
        is_upd_fail = 1; 
        break;
       }
      $EXECUTE ua_id USING $assured,$license,$tag,$engine,$body,$reason,$remark,
			$create,$create;
      if(SQLCODE != 0) {
        is_upd_fail = 1; 
        break;
       }
     }
   } /* for loop */

   if( is_upd_fail ) goto errexit;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
   {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
   }
   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else
  {
   free(raw_ptr);
   MsgCode = M_CM_WRONG_OPTION;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;              /* rollback fail */
   if(SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
     return MsgCode;
   else
     return apiRC;
  }

errexit:
   MsgCode = SQLCODE;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;              /* rollback fail */
   if(SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
     return MsgCode;
   else
     return apiRC;
}

long car129_tag_query(reply)
serverReply reply;
{
 $char DBName[5],tag[CA_TAG_NUM],tag_flag[6];
 $char buff[250];

 int tmp_len;

 cm_buf_get("%s %s ",DBName,tag);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
    return M_CM_DB_NOTOPEN;
   else
    return apiRC;
 }

 sprintf_s(buff,250,"SELECT itag FROM reject_client \
                WHERE itag = '%s' AND freason = '6'",tag );

 printf("buff[%s]\n",buff);

 $PREPARE cur_tag FROM $buff;
 $EXECUTE cur_tag INTO $tag;

 if( SQLCODE == SQLNOTFOUND )
 {
     strcpy( tag_flag, "TRUE");
 }
 else strcpy( tag_flag ,"FALSE");

 cm_buf_init(ReplyBuf);
 cm_buf_put("%l %s ",M_CM_OK,tag_flag );

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
  return apiRC;
 else
  return api_OKComplete;

errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}
