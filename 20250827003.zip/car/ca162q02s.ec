/**********************************************************************/
/*   program id   : ca162q02s.ec                                      */
/*   program name : ����TXT���s                                       */
/*   date written : 2017/05/08                                        */
/*   date modify  : yyyy/mm/dd                                        */
/**********************************************************************/

#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include "print.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "othmsgs.h"
#include "commsgs.h"
#include "sqlfatal.h"
#include "carmsgs.h"
#include "safeclib.h"

#define SUCCESS                 1


char  	outputf[ N_FILE+1];
$char  	userid[11];
$char	DBName[5];
$char   iprovision_p[6],drate_ym_p[5],iclass_p[2],dbegin_p[11];


DBinfo  *list;
    
int     flen, count_db, i, j, k , count;
$char	v_sMsg[1024],sErrMsg[1024];
char	msgbuf[100];
$char   dtoday1[11];
$long	dsys;
$char   sWhere[512];
$char 	sIpolicy[21];


int iTryCnt,res1,iTryCnt2,res2;

int result;
char tar[512], gzip[121], cp[128], rm[128];
char  s[10],s1[10],s2[10],s3[10];

char    sApHome[30];
char    filename[30];
FILE    *fp;
int     flen;
$static char exec_time[20];

static char *get_car_full_db();
/*----------------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
	int rc;
	char  Message[1024];
	  
	batchinit();
	strcpy(DBName,         isNULLstr(argv[1]));
	strcpy(userid,         isNULLstr(argv[2]));
	strcpy(sIpolicy,       isNULLstr(argv[3])); 
	strcpy(outputf,        isNULLstr(argv[4]));
	
	rc = car_get_db();
	if (rc != M_CM_OK) {
		printf("error on car_get_db\n");
		return rc;
	}
	
	strcpy(sIpolicy,trim(sIpolicy));

	s[0]  = '\0';
	s1[0] = '\0';
	s2[0] = '\0';
	s3[0] = '\0';
	
	strcpy(dtoday1,cm_cdate_str(cm_today()));
	cm_char_split_3ymd(dtoday1,s1,s2,s3);
	
	/**** ����ɶ� exec_time [YYYY-MM-DD HH:MM] ****/
	strcpy(exec_time, cm_get_sysd());
	printf("{car1622.0001}:EXECUTE TIME[%s]\n",exec_time);
	/***********************************************/
	
	strncpy(filename," ",30);
	sprintf_s(filename, sizeof filename,"%s/rptftp/", sApHome);
	printf("{car1622.0002}:filename[%s]\n",filename);
	
	/*�������*/
	rc = create_provision();
	if ( rc != M_CM_OK ) {
	 	printf("error on create_provision\n");
	 	EWRITE(userid, rc, sErrMsg);
		return rc;	
	}
	strcpy(Message,  "\n�Цܦ@�θ귽[N]/�d��[B]/�ɮפU���@�~[cmn202]�U���ɮ�!\n");
	EWRITE(userid,M_CM_OK,Message);

	printf("END PROGRAM\n");
	return SUCCESS;

errexit:
	printf("-- Query_card -- SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
	return SQLCODE;     
}
/*----------------------------------------------------------------------------*/
long car_get_db()
{
	int rc;
	
	if (db_select(DBName) == False) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "��Ʈw�L�k�}��!");
		return M_CM_DB_NOTOPEN;
	}
	
	rc = getApHome(sApHome);
	if (rc < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		EWRITE(userid,rc,msgbuf);
	 	return rc;
	}
	
	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}
	
	return M_CM_OK;
}
/*----------------------------------------------------------------------------*/
/*char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
	char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
	char sTmp_db_name[21];
	
	sTmp_db_name[0]='\0';
	if (*sIpolicy != '\0' && *sIpolicy !=' ')
	{
	    sTmp_db_name[0]='\0';
	    strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
	    strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
	           USE_BRANCH_ID));
	    strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
	}        
	return sTmp_db_name;
}*/
/*----------------------------------------------------------------------------*/
long create_provision()
{
	
	$char drate[4],stmt[1024],stmt3[1024],stmt4[1024],stmt5[1024],stmp[512];
	$char sFullName[21];
	$char stmt_ins[1024],stmt_cu[1024];
	$char stmp1[256],stmp2[256],stmp3[256],stmp4[256];
	$char iprovision_in[6],drate_ym_in[5],iclass_in[2],dbegin_in[11],iprovision_after[6];
	$char iprovision[6],drate_ym[5],iclass[2],dbegin[11],nprovision[256],nnumber[256],fcont1[2],fcont2[2],narticle[256],ncontent[256],nnumber2[256],nprovision2[256],dbegin2[11];
	$char dbegin2_yy[4],dbegin2_mm[3],dbegin2_dd[3],nprovision_fcont[2],nnumber_fcont[2],ncontent2[256];
	$char dpolicy[11],dply_close[11],fcar_class[2],icar_type[3],iins_type[7],iins_provision_add[22],provision_add[6],iprovision_add[6],nprovision_add[6];
	$char cmp_provision[6],com_provision[6],iins_provision1[6],iins_provision2[6],iins_provision3[6];
	$int iarticle=0,icontent=0,cnt_cmp=0,cnt_com=0,qserial=0,qserial2=0,s=0;
	$char chn[5];
	$char *ptr,*ptr2;
	char  file_catalog[200];
	$char filename1[200];
	
	$WHENEVER SQLERROR GOTO errexit;
	$SET LOCK MODE TO WAIT;
	$BEGIN WORK;
        
        filename1[0]    = '\0';
	file_catalog[0] = '\0';
	
	sprintf_s(filename1, sizeof filename1,"car1622_provision_%s.txt",sIpolicy);
	strcpy(file_catalog, trim(filename));
	strcat(file_catalog, trim(filename1));
	
	fp=fopen(file_catalog,"w");
	/*--------------------------------------------------------------------------------------------------------------------------------------------------------*/
	/*����*/
	$create temp table ca3072_tmp
	(
	  ipolicy      char(20),
	  iprovision   char(5),
	  qserial      int,
	  qser2        int
	) with no log;
	$create index ca3072_cmp_ix1 on ca3072_tmp(ipolicy);
	
	strcpy(sFullName, get_car_full_db(sIpolicy));
	
	sprintf_s(stmt, sizeof stmt," SELECT UNIQUE a.dpolicy, a.icar_type, b.drate_ym ,a.dply_close"
	             "   FROM %s:ply_relation a, %s:ply_ins_type b "
	             "  WHERE a.ipolicy = b.ipolicy AND a.ipolicy = '%s'",sFullName,sFullName,sIpolicy);
	printf("stmt[%s]",stmt);
	$PREPARE ply_1 FROM $stmt;
	$EXECUTE ply_1 INTO $dpolicy,$icar_type,$drate_ym,$dply_close;
	
	/*�P�_�ۥΡB��~*/
	$SELECT case when fcar_class = '1' then 'C' else 'S' end
	            INTO $fcar_class
	            FROM car_type
	           WHERE icode = $icar_type AND fclass = '1';
	if(SQLCODE == SQLNOTFOUND) strcpy( fcar_class, " ");
	strcpy(drate,trim(drate));
	strcpy(fcar_class,trim(fcar_class));
	printf("drate[%s],dpolicy[%s] \n\n",drate,dpolicy);
	stmp[0] = '\0';
	
	if(strlen(dply_close)>0)
	{
		sprintf_s(stmt_ins, sizeof stmt_ins,"SELECT a.iins_type,trim(nvl(a.provision,' '))||';',"
		                 "       nvl(c.cmp_provision,' '),"
		                 "       nvl(c.com_provision,' '),"
		                 "       nvl(c.iins_provision1,' '),"
		                 "       nvl(c.iins_provision2,' '),"
		                 "       nvl(c.iins_provision3,' '),"
		                 "       b.qserial"
		                 " FROM %s:ori_ins_type a,insurance_type b,outer ca_prov_irate c "
		           	 "WHERE a.iins_type = b.iins_type AND a.iins_type = c.iins_type AND a.ipolicy= '%s' AND a.drate_ym = c.irate AND (c.iclass = '%s' OR c.iclass = 'A')" ,sFullName,sIpolicy,fcar_class);
	}
	else
	{
		sprintf_s(stmt_ins, sizeof stmt_ins,"SELECT a.iins_type,trim(nvl(a.provision,' '))||';',"
		                 "       nvl(c.cmp_provision,' '),"
		                 "       nvl(c.com_provision,' '),"    
		                 "       nvl(c.iins_provision1,' '),"
		                 "       nvl(c.iins_provision2,' '),"
		                 "       nvl(c.iins_provision3,' '),"
		                 "       b.qserial"
		                 " FROM %s:ply_ins_type a,insurance_type b,outer ca_prov_irate c "
		           	 "WHERE a.iins_type = b.iins_type AND a.iins_type = c.iins_type AND a.ipolicy= '%s' AND a.drate_ym = c.irate AND (c.iclass = '%s' OR c.iclass = 'A')" ,sFullName,sIpolicy,fcar_class);
	}
	printf("stmt_ins[%s]\n",stmt_ins);
	
	cnt_cmp = 0;    
	cnt_com = 0;
	$PREPARE iins FROM $stmt_ins;
	$DECLARE iins_cur CURSOR FOR iins;	 
	$OPEN    iins_cur;
	for(;;)
	{
		$FETCH iins_cur INTO $iins_type,$iins_provision_add,$cmp_provision,$com_provision,$iins_provision1,$iins_provision2,$iins_provision3,$qserial;
		if (SQLCODE == SQLNOTFOUND) break; 
		strcpy(iins_provision_add,trim(iins_provision_add));	
		strcpy(iins_type,trim(iins_type));		
		
		strcpy(cmp_provision,trim(cmp_provision));
		strcpy(com_provision,trim(com_provision));
		strcpy(iins_provision1,trim(iins_provision1));
		strcpy(iins_provision2,trim(iins_provision2)); 
		strcpy(iins_provision3,trim(iins_provision3));  
		
		/*���[����*/
		sprintf_s(stmt_cu, sizeof stmt_cu,"select trim(iprovision)||';',iprovision from ca_provision_main where iprovision not in ('C','E')");
		printf("stmt_cu[%s]\n",stmt_cu);
		$PREPARE ins_cu FROM $stmt_cu;
		$DECLARE ins_cucode CURSOR FOR ins_cu;	 
		$OPEN    ins_cucode;
		for(;;)
		{
			$FETCH ins_cucode INTO $iprovision_add,$nprovision_add;
			strcpy(iprovision_add,trim(iprovision_add));
			strcpy(nprovision_add,trim(nprovision_add));
			if (SQLCODE == SQLNOTFOUND) break; 
			printf("iins_provision_add[%s] iprovision_add[%s] nprovision_add[%s]\n",iins_provision_add,iprovision_add,nprovision_add);
			if(strstr(iins_provision_add,iprovision_add) != NULL)
			{
			
			    printf("--IN\n");
			    strcpy(nprovision_add,trim(nprovision_add));
			    printf("--iprovision_add[%s]\n",iprovision_add);
			    printf("--nprovision_add[%s]\n",nprovision_add);
			    /* 1071226006_SC4_�w���ƫ����վ�(���²v+�ĤT�H�d��) */
			    if (strcmp(iprovision_add,"P;") ==0 || strcmp(iprovision_add,"Q;") ==0 || strcmp(iprovision_add,"M;") ==0)
			    {
			        /* �w��D�I01�B05�B09�B11�B181�P�_����P�BQ�BM���� */
				if (strcmp(iins_type,"01") == 0 || strcmp(iins_type,"05") == 0 || strcmp(iins_type,"09") == 0 ||
				    strcmp(iins_type,"11") == 0 || strcmp(iins_type,"181") == 0)
				{
				    $INSERT INTO ca3072_tmp (ipolicy,iprovision,qserial,qser2) VALUES($sIpolicy,$nprovision_add,100,100);
				}
				else 
				    printf("Do Nothing \n");
			    }
			    else if (strcmp(iprovision_add,"V;") ==0)
			    {
			       	/* V���� 09�n�վ㬰V1  31�B32��V2 */
			       	if (strcmp(iins_type,"09") == 0) strcpy(nprovision_add,"V1");
			       	else if (strcmp(iins_type,"31") == 0 || strcmp(iins_type,"32") == 0) strcpy(nprovision_add,"V2");
			       	$INSERT INTO ca3072_tmp (ipolicy,iprovision,qserial,qser2) VALUES($sIpolicy,$nprovision_add,100,100);
			    }
			    else 
			       	$INSERT INTO ca3072_tmp (ipolicy,iprovision,qserial,qser2) VALUES($sIpolicy,$nprovision_add,100,100);
			    
			    printf("iins_type[%s] nprovision_add[%s] \n",iins_type,nprovision_add);			
			
			
			
			}
			

			
			
			
		}	
		$CLOSE ins_cucode;
		$FREE  ins_cucode;	 
		
		if(strlen(cmp_provision) != 0)
		{
			$INSERT INTO ca3072_tmp (ipolicy,iprovision,qserial,qser2) VALUES($sIpolicy,$cmp_provision,0,0);
			qserial2++;
		}
		if(strlen(com_provision) != 0)
		{
			$INSERT INTO ca3072_tmp (ipolicy,iprovision,qserial,qser2) VALUES($sIpolicy,$com_provision,1,1);
			qserial2++;
		}
		if(strlen(iins_provision1) != 0 )
		{
			$INSERT INTO ca3072_tmp (ipolicy,iprovision,qserial,qser2) VALUES($sIpolicy,$iins_provision1,$qserial,2);
			qserial2++;
		}
		if(strlen(iins_provision2) != 0 )
		{
			$INSERT INTO ca3072_tmp (ipolicy,iprovision,qserial,qser2) VALUES($sIpolicy,$iins_provision2,$qserial,2);
			qserial2++;
		}
		if(strlen(iins_provision3) != 0 )
		{
			$INSERT INTO ca3072_tmp (ipolicy,iprovision,qserial,qser2) VALUES($sIpolicy,$iins_provision3,$qserial,2); 
			qserial2++; 
		}
		printf("iins_provision_add[%s] cmp_provision[%s] com_provision[%s] iins_provision1[%s] iins_provision2[%s] iins_provision3[%s] \n",
		        iins_provision_add,cmp_provision,com_provision,iins_provision1,iins_provision2,iins_provision3);   
	}
	$CLOSE iins_cur;
	$FREE  iins_cur;
	
	stmp[0] = '\0';
	sprintf_s(stmp, sizeof stmp," AND a.drate_ym = '%s' AND (a.iclass = '%s' OR a.iclass = 'A') AND a.dbegin <= '%s' "
	             " AND (a.dend >= '%s' OR a.dend is null OR a.dend = ' ') "
	             " AND (a.dexpire is null or a.dexpire = ' ' or dexpire >= today)",drate_ym,fcar_class,dpolicy,dpolicy);
	printf("stmp[%s]\n\n",stmp);
	
	/*-------------------------------------------------------------------------------------------------------------------------------------------------------*/
	
	sprintf_s(stmt4, sizeof stmt4,"SELECT distinct a.iprovision,a.drate_ym,a.iclass,a.dbegin,b.qser2,b.qserial "
	            "     FROM ca_provision a , ca3072_tmp b "
		        " WHERE a.iprovision = b.iprovision  %s "
		        " AND b.ipolicy = '%s' "
		        " ORDER BY b.qser2,b.qserial ",stmp,sIpolicy);
	printf("stmt4[%s]\n\n\n",stmt4);
	$PREPARE outd FROM $stmt4;
	$DECLARE outdrate CURSOR FOR outd;  
	$OPEN    outdrate;	
	printf("-----> into drate_ym \n");
	s = 0;
	for(;;)
	{
		$FETCH outdrate INTO $iprovision_in,$drate_ym_in,$iclass_in,$dbegin_in;
		if (SQLCODE == SQLNOTFOUND) break;
		printf("--iprovision_in[%s],drate_ym_in[%s],iclass_in[%s],dbegin_in[%s]\n",iprovision_in,drate_ym_in,iclass_in,dbegin_in);
		s++;
		if(strcmp(iprovision_after,iprovision_in)==0 && s != 0) continue;
		else strcpy(iprovision_after,iprovision_in);
		
	    	sprintf_s(stmt5, sizeof stmt5,"SELECT a.iprovision,a.drate_ym,a.iclass,a.dbegin,cast(a.iarticle as int),a.fcont,a.narticle,b.icontent,b.fcont,b.ncontent "
	                      "   FROM ca_provision a , ca_prov_content b  "
	                      "  WHERE a.iprovision = b.iprovision "
	                      "    AND a.drate_ym = b.drate_ym "
	                      "    AND a.iclass = b.iclass "
	                      "    AND a.dbegin = b.dbegin "
	                      "    AND a.iarticle = b.iarticle "
	                      "    AND a.iprovision = '%s' "
	                      "    AND a.drate_ym = '%s' "
	                      "    AND a.iclass = '%s' "
	                      "    AND a.dbegin = '%s' "
	                      "    AND (a.dexpire IS NULL OR a.dexpire = '' OR a.dexpire >= today) "
	                    " ORDER BY 1,2,3,5,8 ",iprovision_in,drate_ym_in,iclass_in,dbegin_in);
		$PREPARE pro FROM $stmt5;
		$DECLARE pro1 CURSOR FOR pro;  
		$OPEN    pro1;
		printf("stmt5[%s]\n\n\n",stmt5);
    		for(;;)
		{		
		$FETCH pro1 INTO $iprovision,$drate_ym,$iclass,$dbegin,$iarticle,$fcont1,$narticle,$icontent,$fcont2,$ncontent; 
			if (SQLCODE == SQLNOTFOUND) break;
			strcpy(iprovision,trim(iprovision));
			strcpy(drate_ym,trim(drate_ym));
			strcpy(iclass,trim(iclass));
			strcpy(dbegin2,cm_from_infdate_100(dbegin));
		    cm_char_split_3ymd(dbegin2,dbegin2_yy,dbegin2_mm,dbegin2_dd);
		    strcpy(ncontent2,trim(ncontent));
			strcpy(ncontent,rtrim(ncontent));
			strcpy(narticle,rtrim(narticle));
			if(iarticle ==1 && icontent ==1)
			{
				 $SELECT fcont,narticle
				    INTO $nprovision_fcont,$nprovision
				    FROM ca_provision
			           WHERE iprovision = $iprovision
			             AND drate_ym = $drate_ym
			             AND iclass = $iclass
			             AND dbegin = $dbegin
			             AND iarticle = 'P';
			              	
				  $SELECT fcont,narticle
				    INTO $nnumber_fcont,$nnumber
				    FROM ca_provision
			           WHERE iprovision = $iprovision
			             AND drate_ym = $drate_ym
			             AND iclass = $iclass
			             AND dbegin = $dbegin
			             AND iarticle = 'N';		
			
				fprintf(fp,"~~%s_%s_%s_%s%s%s\n",iprovision,drate_ym,iclass,dbegin2_yy,dbegin2_mm,dbegin2_dd);
				ptr = strtok(nprovision,",");
				while(ptr)
			  	{
				  	nprovision2[0] = '\0';
				  	strcpy(nprovision2,ptr);
				  	strcpy(nprovision2,trim(nprovision2));
				  	if(strlen(nprovision2) == 0)
				  	break;
					fprintf(fp,"%s%s\n",nprovision_fcont,nprovision2);
					ptr = strtok(NULL, ",");
				}
				ptr2 = strtok(nnumber,",");
				while(ptr2)
			  	{
				  	nnumber2[0] = '\0';
				  	strcpy(nnumber2,ptr2);
				  	strcpy(nnumber2,rtrim(nnumber2));
				  	if(strlen(nnumber2) == 0)
				  	break;
					fprintf(fp,"%s%s\n",nnumber_fcont,nnumber2);
					ptr2 = strtok(NULL, ",");
				}					
				fprintf(fp,"%s%s\n%s%s\n",fcont1,narticle,fcont2,ncontent);
			}
			else if(iarticle !=1 && icontent ==1) 
			{
				if(strlen(ncontent2)==0)
				fprintf(fp,"%s%s\n",fcont1,narticle);
				else
				fprintf(fp,"%s%s\n%s%s\n",fcont1,narticle,fcont2,ncontent);	
			}
			else
				fprintf(fp,"%s%s\n",fcont2,ncontent);		
		}
	$CLOSE pro1;
        $FREE  pro1;	
	}
	$CLOSE outdrate;
        $FREE  outdrate;
        
        fclose(fp);
        
        EXEC SQL INSERT INTO rptftplist (nuserid, ipgid,     noutfile,   dcreate)
                              VALUES ($userid, 'car1622',  $filename1, $exec_time);
	$COMMIT WORK;
	return M_CM_OK;
	
errexit:
    fclose(fp);
    printf("-- Query_policy -- SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
    $ROLLBACK WORK;
    return SQLCODE;
}
/*-------------------------------THE END--------------------------------------*/


