/**********************************************************************/
/*   program id   : ca349p01s.ec                                      */
/*   program name : �Ϳ��O�NISID�iĵ����E-mail�q�� (1070720009_SC1 )  */
/*   date written : 2018/09/10                                        */
/*   date modify  : yyyy/mm/dd                                        */
/*   shell        : car3491_email.sh                                  */
/*   exec time    : �C��10��03:00����                                 */
/**********************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include "print.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "sqlfatal.h"
#include "safeclib.h"
#include <locator.h>

char  	outputf[ N_FILE+1];
$char  	userid[11],sDdate[11];
char  	ddate[11];
$char	ReportName[500];
char	dserchdate[11],ReportName[500];
char	syy[4],smm[3],sdd[3],sdate[11];
char    searchmonth[3],searchyear[4];
$char	DBName[5];
DBinfo  *list;
    
int     flen,count_db,i;
FILE    *fp;
char    sApHome[30];
$char   fname[60];
$char   filename[121];
$char	ftitle[1024],nsubject[512];
$char   ipolicy[21],icard[21],iofficer[11],nname[11],nassured[121],nalert[101],nclose[101],nattachment[100];
$char   idata[10];	
$char	mmsg[2048];

$char 	mbuf[11000];
$loc_t 	ctxt;
$char	stmt[1024],stmt_1[4096],stmt1[256];
char	msgbuf[100];
$int 	mail_count=0;



/* asempl */
$char	email[51],chinese_name[15];
$char stmt_tmp[1024];
/*----------------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
    int rc;
    batchinit();
    strcpy(DBName,  isNULLstr(argv[1]));
    strcpy(userid,  isNULLstr(argv[2]));
    strcpy(ddate,   isNULLstr(argv[3])); /* cyy/mm/dd */
    strcpy(outputf, isNULLstr(argv[4]));
    
    /*strcpy(DBName, "00");*/
    /*strcpy(ddate,cm_sysd_cdate_100(cm_get_sysd()));*/
    /*strcpy(ddate,"107/09/09");/*���ե�*/
    
    rc = car349_get_db();
    if (rc != M_CM_OK) {
        printf("error on car349_get_db\n");
        return rc;
    }
    

	/* �� temp table (car349) */        
	rc = car349_init_data();
	if (rc != M_CM_OK) {
		printf("error on car349_init_data\n");
		return rc;
	}
		        
	/* �d�߬������ */        
	rc = car349_ply_data();
	if (rc != M_CM_OK) {
		printf("error on car349_ply_data\n");
		return rc;
	}
		
	/* �H�eE-mail �q�� */
	rc = car349_send_email(); 
	if (rc != M_CM_OK) {
		printf("error on car349_send_email\n");
		return rc;
	}
		    
    
    
    printf("[car349]:process ok!\n"); 
}
/*----------------------------------------------------------------------------*/
long car349_get_db()
{
    int	rc;

    if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "��Ʈw�L�k�}��!");
       return M_CM_DB_NOTOPEN;
    }
    
    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }
    
    if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
       if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
          return M_CM_NOT_DBLIST;
    }

    return M_CM_OK;
}
/*----------------------------------------------------------------------------*/
long car349_init_data()
{
    $whenever sqlerror goto errexit;

    $create temp table car349(
		   ipolicy		char(20),
		   icard          	char(20),
		   iofficer        	char(10),
		   nname		char(14),
		   nassured        	char(120),
		   nalert		char(100),
		   nclose		char(100)
     )with no log;

    printf("-----ddate = [%s]-----\n",ddate);
    cm_char_split_3ymd(ddate,syy,smm,sdd);
    
    
    sprintf_s(sdate,sizeof sdate,"%s%s%s",syy,smm,sdd);
    printf("-----sdate = [%s]-----\n",sdate);
    
    /*��W�Ӥ몺���*/
    if(atoi(smm)-1==0)
    {
    	strcpy(searchmonth,"12");
    	strcpy(searchyear,itoa(atoi(syy)-1));
    	
    }
    else
    {
    	strcpy(searchmonth,itoa(atoi(smm)-1));
    	strcpy(searchyear,syy);	
    }
    
    printf("/////%s/%s/////\n",searchmonth,searchyear);
    /* ���Y */
    strcpy(ftitle,"�O�渹,�O�d��,�g��N��,�g��W��,�Q�O�I�H,�iĵ��],�B�z�覡\n");
    
    /* �D�� */
    sprintf_s(nsubject,sizeof nsubject,"�Ϳ��O�NISID�iĵ���ӳq��(%s�~%s��)",searchyear,searchmonth);
	
    return M_CM_OK;

errexit:
        sqlfatal();
        EWRITE(userid,SQLCODE,sqlca.sqlerrm);
        return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car349_ply_data()
{
   int	rc;
   
   $whenever sqlerror goto errexit;
   $SET LOCK MODE TO WAIT 5;  
   for(i=0;i<count_db;i++) 
   {  	 
   	

   	/*�M��ŦX�����ơA�s�J�Ȯ�table*/
     sprintf_s(stmt_1,sizeof stmt_1,"INSERT INTO car349 "
                   "SELECT a.ipolicy,a.icard,b.iofficer,b.nname,c.nassured,d.nalert,d.nclose" /*�O�渹�B�O�d���B�g��N���B�g��W�١B�Q�O�I�H�B�iĵ��]�B�B�z�覡*/
                   "  FROM %s:ori_ply_relation a,%s:officer b,%s:original_ply c , %s:cm_isid_risk d"
                   " WHERE YEAR(dpolicy) = '%d' AND MONTH(dpolicy) = '%s'"
                   "       AND a.iofficer[1]='A' AND a.iofficer=b.iofficer AND a.ipolicy=c.ipolicy"  /*A:�Ϳ��O�N*/
                   "       AND d.iref_num1 = a.ipolicy",list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,atoi(searchyear)+1911,searchmonth);
     	  
      printf("stmt1[%s]\n",stmt_1);
      $prepare pre_ply1 from $stmt_1;
      $execute pre_ply1 ;
	   
    }  

    return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car349_send_email()
{
	int	rc;
        char 	nalertnew[100];
        char 	nclosenew[120];
        $char IsInrptftplist[2];
	$whenever sqlerror goto errexit;
	 

    	strcpy(mbuf,"�˷R�������O�A�z�n:</P>\n\n  �q���z�A����O�s�w�F�ʮ��W���I-�Ϳ��O�NISID�iĵ���ӳq��</P>\n</P>  ����!</P></P>\n\n�s�w�F�ʮ��W�����O�I�ѥ��������q  �q��</P>\n");
    	ctxt.loc_loctype = LOCMEMORY;
    	ctxt.loc_buffer = mbuf;
    	ctxt.loc_bufsize = 9000;
    	ctxt.loc_size =  strlen(mbuf) + 1;
    	strcpy(email,"ksb06@kaishing.com.tw");  /*ksb06@kaishing.com.tw*/
    	strcpy(chinese_name,"�����O");
	/*ipolicy,icard,iofficer,nname,nassured,nalert,nclose*/

	
	memset(fname,0x00,sizeof(fname));
	memset(filename,0x00,sizeof(filename));
	sprintf_s(fname,sizeof fname,"%s�~%s��_�Ϳ��O�NISID�iĵ���ӳq��",searchyear,searchmonth);	
	sprintf_s(filename,sizeof filename,"%s/rptftp/car_email/%s.csv",sApHome,fname);
	printf("filename[%s]\n",filename);
	sprintf_s(nattachment,sizeof nattachment,"%s.csv",fname);
	fp=fopen(filename,"w");
		
	fprintf(fp,ftitle);
	
	$SELECT COUNT(*) INTO $idata FROM car349;
	printf("idata[%s]",trim(idata));

	strcpy(stmt,"SELECT ipolicy,icard,iofficer,nname,nassured[1,2]||'�ݢ�',nalert,nclose FROM car349 ");  /*�q�Ȧs��table�����X���*/
	$PREPARE pre_data from $stmt;
	$DECLARE cur_data CURSOR FOR pre_data;
	$OPEN cur_data;	
	
	for(int i=1;i<=atoi(trim(idata));i++)  /*�@���@���C�X���*/
	{
		
		$FETCH cur_data INTO $ipolicy,$icard,$iofficer,$nname,$nassured,$nalert,$nclose;
		strcpy(nalertnew,trim(nalert));
		
   		
        	char *loc = strstr(nclose, "\n");    /*������Ƥ��e��"\n"�M","�A�|�ɭP�������*/
        	if(loc == NULL) /*�S��\n*/
        	{
        		       
        		for(int i=0;i<=sizeof(nclose);i++)
        		{
        			if(nclose[i]==',')
        			{
        				nclose[i]=' ';
        			}
        		
        		}  	
        		strcpy(nclosenew,nclose);
    		}
    		else /*��\n*/
    		{
    			for(int i=0;i<=sizeof(nclose);i++)    
    			{
    				if(nclose[i]=='\n')
    				{
    					nclose[i]=' ';	
    				}	
    			}
    			
    			for(int i=0;i<=sizeof(nclose);i++)
        		{
        			if(nclose[i]==',')
        			{
        				nclose[i]=' ';
        			}
        		
        		}
    			strcpy(nclosenew,nclose);    			 

    		}
        	fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,\n",ipolicy,icard,iofficer,nname,rtrim(nassured),nalertnew,trim(nclosenew,'\n'));
        }

        

	
	$CLOSE cur_data;
	fclose(fp);
	$FREE  cur_data;

        
        	
            sprintf_s(ReportName,sizeof ReportName,"%s",fname);
            strcpy(IsInrptftplist,"");
            
            $SELECT COUNT(*) INTO $IsInrptftplist FROM rptftplist WHERE ipgid="car3491" AND noutfile= $ReportName; /*�O�_�w�����*/ 
            if(IsInrptftplist=='0')
            {
	        
	        rc=rptftpinsert("071004","car3491", ReportName );
	        if (rc!=0)
    	        {
        	    printf( "�g�Jrptftplist���~\n");
        	    return rc;
    	        }
    	    }
    	
    	
        
            rc = car349_write_email();
            if (rc!=M_CM_OK)
            {
	    	printf("error on car349_write_email\n");
		return rc;
	    }
        
           
    return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*---------------------------------------------------------------------------*/
long car349_write_email()
{
	$int IsInbatchemail=0;
	$char cc_email[51];
	$whenever sqlerror goto errexit;
	
	printf("-----email:[%s]-----\n",email);
	
	$SELECT COUNT(*) INTO $IsInbatchemail FROM batchemail WHERE project_id="CAR3491" AND mail_date=today+1; /*�O�_�w�����*/ 
	
	if(IsInbatchemail == 0)
	{
		$select email
		   into $cc_email
		   from personal:asempl
		  where empl_no = (select ileader from cm_route where iroute = 'CAB0A');
		
		strcpy(cc_email,trim(cc_email));
		strcat(cc_email,"@tmnewa.com.tw");
		printf("cc_email[%s]\n",cc_email);
		
		
		$INSERT INTO batchemail
		(project_id, mail_date, receiver_email,
		 receiver_name, cc, content, key, mail_count,nsubject,nattachment)
		VALUES
		("CAR3491", today, $email, $chinese_name,
		 $cc_email, $ctxt, $fname, 1, $nsubject, $nattachment);
	} 
    return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}