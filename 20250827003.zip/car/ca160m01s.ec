/*--------------------------------------------------*/
/*   PROGRAM : ca160m01s.ec  by 030344              */
/*   MODIFIER:                                      */
/*                                                  */
/*   DATE    : 2015/10/12                           */
/*--------------------------------------------------*/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;
#include <decimal.h>
#include "safeclib.h"

typedef struct {
    char   type;
    double car_price_bgn;
    double car_price_end;
    double pcar_price;
    char   drate[12];
    } car160_t;

$char userid[7];

/*--------------------------------------------------*/
long car160(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	long rtncode;
	long car160_insert(),car160_single_query(),car160_multiple_query(),car160_update_exec();
	char option;

	cm_buf_init(command);
 	cm_buf_get("%c",&option);

 	switch(option)
 	{
	  	case 'A':
    		rtncode=car160_insert(reply);
        	break;
  		case 'Q':
    		rtncode=car160_single_query(reply);
        	break;
  		case 'M':
        	rtncode=car160_multiple_query(reply);
        	break;
  		case 'D':
  		case 'U':
        	rtncode=car160_update_exec(reply,command,com_len);
        	break;
  		default :
    		if(exitsub(reply,M_CM_WRONG_OPTION) == True)
        		return M_CM_WRONG_OPTION;
           	return apiRC;
 	}
 	return(rtncode);
}

/*--------------------------------------------------*/
long car160_insert(reply)
serverReply reply;
{
	$char    DBName[3];
   	$char    drate[9],drate_e[12],str_rows[3];
   	$double  car_price_bgn,car_price_end,pcar_price;
        dec_t    dec_car_price_bgn,dec_car_price_end,dec_pcar_price;
        char     tmp_car_price_bgn[10],tmp_car_price_end[10],tmp_pcar_price[10];
   	int      rows,tmp_len,i;
   	long     MsgCode;
   	DBinfo   *list;
   	int      k,j,is_add_fail=0, api_f;
   	$char    stmt_buf[500];
   	car160_t *alist;

   	cm_buf_get("%s %s %s",DBName,userid,str_rows);

   	rows=atoi(str_rows);
printf("%d\n",rows);

   	if(db_select(DBName) == False)
   	{
    	if( exitsub(reply,M_CM_DB_NOTOPEN) == True )
        	return M_CM_DB_NOTOPEN;
      	return apiRC;
   	}
	/* $BEGIN WORK;*/
	/* because this is single table head-detail, so mark it */
 	/* $INSERT INTO compulsory_premium (icar_type,qperiod,mpremium)
            VALUES ($cartype,$insperiod,$premium); */
   	alist = (car160_t *) malloc(rows * sizeof (car160_t));

   	for (k=0; k<rows; k++)
   	{
    	cm_buf_get("%s %s %s %s",
		   tmp_car_price_bgn,tmp_car_price_end,tmp_pcar_price,drate);
       	deccvasc( tmp_car_price_bgn, strlen(tmp_car_price_bgn), &dec_car_price_bgn);
       	dectodbl( &dec_car_price_bgn, &car_price_bgn);

       	deccvasc( tmp_car_price_end, strlen(tmp_car_price_end), &dec_car_price_end);
       	dectodbl( &dec_car_price_end, &car_price_end);

       	deccvasc( tmp_pcar_price, strlen(tmp_pcar_price), &dec_pcar_price);
       	dectodbl( &dec_pcar_price, &pcar_price);

       	alist[k].car_price_bgn = car_price_bgn;
       	alist[k].car_price_end = car_price_end;
       	alist[k].pcar_price = pcar_price;
       	strcpy(alist[k].drate,cm_to_infdate(drate));

   	}

	$BEGIN WORK;

    	sprintf_s(stmt_buf, sizeof stmt_buf, "INSERT INTO car_price_factor "
      		   " (car_price_bgn,car_price_end,pcar_price,drate,icreate,dcreate,iupdate,dupdate) "
      	" VALUES (?,?,?,?,?,current,?,current)");

     	for (k=0; k<rows; k++)
     	{
        	$PREPARE b_id FROM $stmt_buf;
        		car_price_bgn = alist[k].car_price_bgn;
        		car_price_bgn = car_price_bgn * 10000;
       			car_price_end = alist[k].car_price_end;
       			car_price_end = car_price_end * 10000;
       			pcar_price = alist[k].pcar_price;
        	strcpy(drate_e,alist[k].drate);
        	$EXECUTE b_id
        		USING $car_price_bgn,$car_price_end,$pcar_price,$drate_e,$userid,$userid;
        	if(SQLCODE != 0)
        	{
	        	goto errexit;
       		}
    	}

		cm_buf_init(ReplyBuf);
  		cm_buf_put("%l",M_CM_OK);
  		tmp_len = cm_buf_len(ReplyBuf);
    		api_f = api_OKComplete;

    		if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
    		{
     			is_add_fail = 2;
    		}

		if( is_add_fail == 1 ) goto errexit;

		if( is_add_fail == 2 )
		{
		 	$ROLLBACK WORK;
			return apiRC;
		}

		for (i = 0; i < rows; i++)
	  		free( alist[i]);
		free ( (char *) alist);

   	$WHENEVER SQLERROR GOTO errexit;
   	$COMMIT WORK;
   	return api_OKComplete;

 errexit:
   	MsgCode = SQLCODE;
   	$WHENEVER SQLERROR CONTINUE;
   	$ROLLBACK WORK;
   	if( SQLCODE != 0) MsgCode = SQLCODE;
   	if(exitsub(reply,MsgCode) == True)
    	return MsgCode;
   	else
    	return apiRC;
}

/*--------------------------------------------------*/
long car160_single_query(reply)
serverReply reply;
{
    $long   drate_l = 0;
    $char   DBName[3];
    $char   drate_e[12],drate[10];
    $char   str_car_price_bgn[10],str_car_price_end[10],str_pcar_price[10];
    $double car_price_bgn_l,car_price_end_l,pcar_price_l,pcar_price;
    dec_t   dec_car_price_bgn,dec_car_price_end,dec_pcar_price;
    char    tmp_car_price_bgn[10],tmp_car_price_end[10],tmp_pcar_price[10];
    int     rows=0,tmp_len;
    $int    car_price_bgn,car_price_end;

    cm_buf_get("%s %s %s %s %s",DBName,tmp_car_price_bgn,tmp_car_price_end,tmp_pcar_price,drate);

    deccvasc( tmp_car_price_bgn, strlen(tmp_car_price_bgn), &dec_car_price_bgn);
    dectodbl( &dec_car_price_bgn, &car_price_bgn_l);
    car_price_bgn_l = car_price_bgn_l * 10000;

    deccvasc( tmp_car_price_end, strlen(tmp_car_price_end), &dec_car_price_end);
    dectodbl( &dec_car_price_end, &car_price_end_l);
    car_price_end_l = car_price_end_l * 10000;

    deccvasc( tmp_pcar_price, strlen(tmp_pcar_price), &dec_pcar_price);
    dectodbl( &dec_pcar_price, &pcar_price_l);

    strcpy(drate_e,cm_to_infdate(drate));

   	$WHENEVER SQLERROR GOTO errexit;

   	if (db_select(DBName) == False)
    	return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

   	cm_buf_init(ReplyBuf);
   	cm_buf_res_msg();
   	cm_buf_res_count();



printf("drate_e[%s]\n",drate_e);
printf("car_price_bgn_l[%f]\n",car_price_bgn_l);
printf("car_price_end_l[%f]\n",car_price_end_l);
printf("pcar_price_l[%f]\n",pcar_price_l);

   	$DECLARE q_cur CURSOR FOR
      SELECT car_price_bgn,car_price_end,pcar_price,drate
        INTO $car_price_bgn,$car_price_end,$pcar_price,$drate_l
        FROM car_price_factor
       WHERE car_price_bgn = $car_price_bgn_l
         AND drate=$drate_e;

   	$OPEN q_cur;

	for(;;)
   	{
    	$FETCH q_cur;
      	if (SQLCODE != 0) break;

	car_price_bgn = car_price_bgn /10000;
      	car_price_end = car_price_end /10000;
        sprintf_s(str_pcar_price, sizeof str_pcar_price, "%.5f",pcar_price_l);
        strcpy(drate,cm_cdate_str_100(drate_l));

printf("car_price_bgn[%d]\n",car_price_bgn);
printf("car_price_end[%d]\n",car_price_end);
printf("str_pcar_price[%s]\n",str_pcar_price);


        cm_buf_put("%d %d %s %s ",
          	    car_price_bgn,car_price_end,str_pcar_price,drate);

		rows++;

	}
   	$CLOSE q_cur;
   	$FREE q_cur;

   	if(rows > 0 || SQLCODE==0)      /* at least one row is selected */
   	{
    	cm_buf_put_msg(M_CM_OK);
      	cm_buf_put_count(rows);
      	tmp_len = cm_buf_len(ReplyBuf);
      	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        	return apiRC;
      	else
        	return api_OKComplete;
   	}
   	else
   	{
    	if( exitsub(reply,M_CA_NRATE) == True )
        	return M_CA_NRATE;
      	return apiRC;
   	}

errexit:
	if ( exitsub(reply,SQLCODE) == True )
    	return SQLCODE;
   	return apiRC;
}


/*--------------------------------------------------*/
long car160_multiple_query(reply)
serverReply reply;
{
	$char   DBName[3],k_car_price_bgn[10],drate_e[12];
   	$long   drate_l = 0;
   	$char   str_car_price_bgn[10],str_car_price_end[10],str_pcar_price[10],str_drate_bgn[12],str_drate_end[12];
   	$double tmp_car_price_bgn,pcar_price = 0.0;
   	char    tmpbuf[4000],drate[10];
   	dec_t   dec_car_price_bgn,dec_car_price_end,dec_pcar_price;
   	int     count=0,repbuf_len=0,tmp_len=0,replycnt=0;
   	int     i,total_count=0,flag;
   	$int    car_price_bgn,car_price_end;

    cm_buf_get("%s %s %s",DBName,k_car_price_bgn,drate);

   	$WHENEVER SQLERROR GOTO errexit;

   	if (db_select(DBName) == False)
   	{
    	if( exitsub(reply,M_CM_DB_NOTOPEN) == True )
        	return M_CM_DB_NOTOPEN;
      	return apiRC;
   	}

   	if(drate[0] == '*')
    	{
    	strcpy(str_drate_bgn,"01/01/1980");
      	strcpy(str_drate_end,"12/31/2999");
	}
   	else
    	{
    	strcpy(str_drate_bgn,cm_to_infdate(drate));
      	strcpy(str_drate_end,cm_to_infdate(drate));
	}

	deccvasc( k_car_price_bgn, strlen(k_car_price_bgn), &dec_car_price_bgn);
       	dectodbl( &dec_car_price_bgn, &tmp_car_price_bgn);

printf("tmp_car_price_bgn[%f]\n",tmp_car_price_bgn);

	tmp_car_price_bgn = tmp_car_price_bgn * 10000;

printf("tmp_car_price_bgn[%f]\n",tmp_car_price_bgn);


   	$DECLARE m1_cur CURSOR FOR
      SELECT car_price_bgn,car_price_end,pcar_price,drate
        INTO $car_price_bgn,$car_price_end,$pcar_price,$drate_l
        FROM car_price_factor
       WHERE car_price_bgn >= $tmp_car_price_bgn
         AND drate >=$str_drate_bgn
         AND drate <=$str_drate_end
       ORDER BY car_price_bgn;

	$OPEN m1_cur;

   	for(;;)
   	{
    	$FETCH m1_cur;
     	if (SQLCODE != 0) break;

      	cm_buf_init(tmpbuf);

      	if ( count == 0 )
      	{
        	cm_buf_res_msg();             /* reserve for MsgCode and count */
         	cm_buf_res_count();
      	}

      	strcpy(drate,cm_cdate_str_100(drate_l));
      	car_price_bgn = car_price_bgn /10000;
      	car_price_end = car_price_end /10000;
      	sprintf_s(str_pcar_price, sizeof str_pcar_price, "%.5f",pcar_price);

      	cm_buf_put("%d %d %s %s",car_price_bgn,car_price_end,str_pcar_price,drate);

      	tmp_len = cm_buf_len(tmpbuf);

      	if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
      	{
        	memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
         	repbuf_len += tmp_len;
         	count++;
     	}
      	else                               /* more than 4K, send to client side */
      	{
        	cm_buf_init(ReplyBuf);
         	cm_buf_put_msg(M_CM_OK);
         	cm_buf_put_count(count);
         	if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
         	{
            	$CLOSE m1_cur;
	    		$FREE m1_cur;
            	return apiRC;
			}
        	else               /* clear ReplyBuf and count to start all over again */
        	{
            	replycnt++;
	            if (replycnt == 10)   /* more than 30K, client cannot display,error */
    	        {
        	       	cm_buf_init(ReplyBuf);
            	   	cm_buf_put("%l",M_CM_OUT_SPACE);
	               	tmp_len = cm_buf_len(ReplyBuf);
               		if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
                  	return apiRC;
               		return M_CM_OUT_SPACE;
            	}

printf("car_price_bgn[%d]\n",car_price_bgn);
printf("car_price_end[%d]\n",car_price_end);

            	ReplyBuf[0] = '\0';
            	count = 0;
            	cm_buf_init(ReplyBuf);
            	cm_buf_res_msg();           /* reserve for MsgCode and count */
            	cm_buf_res_count();
            	strcpy(drate,cm_cdate_str_100(drate_l));
      		/*car_price_bgn = car_price_bgn /10000;
      		car_price_end = car_price_end /10000;*/
      		sprintf_s(str_pcar_price, sizeof str_pcar_price, "%.5f",pcar_price);

printf("car_price_bgn[%d]\n",car_price_bgn);
printf("car_price_end[%d]\n",car_price_end);

      			cm_buf_put("%d %d %s %s",car_price_bgn,car_price_end,str_pcar_price,drate);
            	repbuf_len = cm_buf_len(ReplyBuf);
            	count++;
        	}
		}
	} /* for loop */

   	$CLOSE m1_cur;
   	$FREE m1_cur;

   	if (count > 0)   /* break out, at least one record is selected */
   	{
      	cm_buf_init(ReplyBuf);
      	cm_buf_put_msg(M_CM_OK);
      	cm_buf_put_count(count);
      	if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
        	return apiRC;
      	return api_OKComplete;
   	}
   	else            /* break out, not any raw is found */
   	{
    	if( exitsub(reply,M_CA_NRATE) == True )
        	return M_CA_NRATE;
      	return apiRC;
   	}

errexit:
   	if ( exitsub(reply,SQLCODE) == True )
    	return SQLCODE;
   	return apiRC;
}


/*--------------------------------------------------*/
long car160_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	$char   DBName[3];
	$char   str_car_price_bgn[10],str_car_price_end[10],str_pcar_price[10],cur_str_pcar_price[10];
   	$char   drate_e[12];
   	$char   drate_l[12];
   	$double pcar_price,car_price_bgn_l;
   	$int    car_price_bgn,car_price_end,cur_car_price_bgn = 0,cur_car_price_end = 0;
   	$double new_car_price_bgn_l,new_car_price_end_l;
   	$int    new_car_price_bgn,new_car_price_end;
   	$double new_pcar_price;
   	$char   new_drate_e[12];
   	$double cur_pcar_price = 0.0;
   	$char   old_drate_e[12],drate_n[12];

    dec_t  dec_car_price_bgn,dec_car_price_end,dec_pcar_price;
    char   tmp_car_price_bgn[10],tmp_car_price_end[10],tmp_pcar_price[10],tmp_drate[10];

    int    tmp_len,raw_len,count,rows=0,i,flag,count1,y;

    char   old_drate[10];

	$char   cur_drate[12],drate[12];
    char  option,*pos,*raw_ptr,cur_buf[10000],*comm,type;
    long  dummy;
    long  MsgCode;
    int   first;
    int   k, j, is_del_fail=0, is_upd_fail=0;
   	$char  stmt_buf[500];

	car160_t *alist;
    DBinfo   *list;

   	comm = (char *) command;
   	cm_buf_init(command);
   	cm_buf_get("%c %s",&option,DBName);

   	$WHENEVER SQLERROR GOTO errexit;

   	if (db_select(DBName) == False)
    	return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;


   /* compare old record and current record, if the record has not been changed
      since last request, update or delete the record, otherwise return errmsg
      to client side */
   /* get old record info from command buffer */
	memcpy(&raw_len,&comm[com_len],sizeof(int));
   	pos = &comm[com_len+sizeof(int)];
   	raw_ptr = malloc(raw_len);

   	if (raw_ptr != (char*)0)
    	memcpy(raw_ptr,pos,raw_len);
   	else
   	{/* malloc fail */
    	return exitsub(reply,M_CM_NOT_MALLOC) ? M_CM_NOT_MALLOC : apiRC;
   	}

   /* get index key from old record, dummy is the MsgCode */

   	cm_buf_init(raw_ptr);
   	cm_buf_get("%l %d",&dummy,&count);
   	count1=count;

	cm_buf_get("%s %s %s %s ",
          	    str_car_price_bgn,str_car_price_end,str_pcar_price,drate);

printf("str_car_price_bgn[%s]\n",str_car_price_bgn);
printf("str_car_price_end[%s]str_pcar_price[%s]drate[%s]\n",str_car_price_end,str_pcar_price,drate);

	strcpy(drate,cm_to_infdate(drate));

   	$BEGIN WORK;

   	cm_buf_init(cur_buf);    /* must reserve msg and count for comparison */
   	cm_buf_res_msg();
   	cm_buf_res_count();


   	$WHENEVER SQLERROR GOTO errexit;

   	cm_buf_put_msg(dummy);
   	cm_buf_put_count(count);

printf("538\n");
   	deccvasc( str_car_price_bgn, strlen(str_car_price_bgn), &dec_car_price_bgn);
    	dectodbl( &dec_car_price_bgn, &car_price_bgn_l);
    	car_price_bgn_l = car_price_bgn_l * 10000;

printf("car_price_bgn_l[%f]\n",car_price_bgn_l);

    $DECLARE u_cur CURSOR FOR
      SELECT car_price_bgn,car_price_end,pcar_price,drate
        INTO $cur_car_price_bgn,$cur_car_price_end,$cur_pcar_price,$drate_l
        FROM car_price_factor
       WHERE car_price_bgn = $car_price_bgn_l
         AND drate=$drate;

   	$OPEN u_cur;

   	rows=0;

   	for(;;)
   	{
    	$FETCH u_cur;
      	if (SQLCODE == SQLNOTFOUND) break;

printf("562\n");
printf("drate_l[%s]\n",drate_l);
printf("cur_drate[%s]\n",cur_drate);

	sprintf_s(cur_str_pcar_price, sizeof cur_str_pcar_price, "%.5f",cur_pcar_price);
    	strcpy(cur_drate,drate_l);

    cm_buf_put("%d %d %s %s ",
               cur_car_price_bgn,cur_car_price_end,cur_str_pcar_price,cur_drate);

    rows++;

   	}/* end of for */
   	$CLOSE u_cur;
   	$FREE u_cur;

printf("1 count=%d\n",count);
printf("1 ROWS=%d\n",rows);

   	if(rows != count)      /* at least one row is selected */
   	{
      	MsgCode = M_CM_NOT_EQUAL;
      	$WHENEVER SQLERROR CONTINUE;
      	$ROLLBACK WORK;
      	if( SQLCODE != 0) MsgCode = SQLCODE;
      	return exitsub(reply,MsgCode) ? MsgCode : apiRC;
	} /* end of for */
   	$CLOSE u_cur;
   	$FREE u_cur;

printf("2 count=%d\n",count);
printf("2 ROWS=%d\n",rows);

   	if(rows != count)      /* at least one row is selected */
   	{
      	MsgCode = M_CM_NOT_EQUAL;
      	$WHENEVER SQLERROR CONTINUE;
      	$ROLLBACK WORK;
      	if( SQLCODE != 0) MsgCode = SQLCODE;
      	return exitsub(reply,MsgCode) ? MsgCode : apiRC;
   	}
   	$WHENEVER SQLERROR GOTO errexit;

	write(1, cur_buf, raw_len); printf("]\n[");
	write(1, raw_ptr, raw_len); printf("]\n");
	free(raw_ptr);
    /* compare 2 records, not equal */
    /*
   	if (memcmp(cur_buf,raw_ptr,raw_len) != 0)
   	{
      	MsgCode = M_CM_NOT_EQUAL;
      	$WHENEVER SQLERROR CONTINUE;
      	$ROLLBACK WORK;
      	if( SQLCODE != 0) MsgCode = SQLCODE;
      	return exitsub(reply,MsgCode) ? MsgCode : apiRC;
   	}*/
   	$WHENEVER SQLERROR GOTO errexit;

   	/* equal, then exec DB operation */
   	if( option == 'D' )
   	{
      		sprintf_s(stmt_buf, sizeof stmt_buf,
         	"DELETE FROM car_price_factor WHERE car_price_bgn=? AND drate=? ");
       		$PREPARE d_id FROM $stmt_buf;
       		$EXECUTE d_id USING $cur_car_price_bgn,$cur_drate;

     	cm_buf_init(ReplyBuf);
     	cm_buf_put("%l", M_CM_OK);
     	tmp_len = cm_buf_len(ReplyBuf);
     	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
     	{
        	$WHENEVER SQLERROR CONTINUE;
         	$ROLLBACK WORK;
         	return apiRC;
     	}
     	$WHENEVER SQLERROR GOTO errexit;
     	$COMMIT WORK;
     	return api_OKComplete;
   	}
   	else if(option == 'U')
   	{
    	cm_buf_init(command);
    		printf("--637 -- \n");
      	cm_buf_get("%c %s %s",&option,DBName,userid);
      	printf("--639 -- \n");

      	cm_buf_get("%d",&rows);
      	alist = (car160_t *) malloc(rows *sizeof (car160_t));

      	for (k = 0; k <rows; k++)
      	{
       		cm_buf_get("%c %s %s %s %s ",&type,tmp_car_price_bgn,tmp_car_price_end,tmp_pcar_price,tmp_drate);

	       	deccvasc( tmp_car_price_bgn, strlen(tmp_car_price_bgn),&dec_car_price_bgn);
    	   	dectodbl( &dec_car_price_bgn, &new_car_price_bgn_l);
       		deccvasc( tmp_car_price_end, strlen(tmp_car_price_end),&dec_car_price_end);
       		dectodbl( &dec_car_price_end, &new_car_price_end_l);
       		deccvasc( tmp_pcar_price, strlen(tmp_pcar_price), &dec_pcar_price);
       		dectodbl( &dec_pcar_price, &new_pcar_price);
       		alist[k].type = type;
       		alist[k].car_price_bgn=new_car_price_bgn_l;
       		alist[k].car_price_end=new_car_price_end_l;
       		alist[k].pcar_price=new_pcar_price;
        	strcpy(alist[k].drate,cm_to_infdate(tmp_drate));
	}

    	$WHENEVER SQLERROR GOTO errexit;

        	for(k=0; k < rows; k++)
		{
           		new_car_price_bgn = alist[k].car_price_bgn * 10000 ;
           		new_car_price_end = alist[k].car_price_end * 10000 ;
           		new_pcar_price = alist[k].pcar_price;
           		strcpy(new_drate_e,alist[k].drate);

                switch(alist[k].type)
                {
                	case 'A':
                    	sprintf_s(stmt_buf, sizeof stmt_buf,
                    	"INSERT INTO car_price_factor "
                                   " (car_price_bgn,car_price_end,pcar_price,drate,icreate,dcreate,iupdate,dupdate) "
                             " VALUES (?,?,?,?,?,current,?,current)");
						$PREPARE u1_id FROM $stmt_buf;
						$EXECUTE u1_id USING $new_car_price_bgn,$new_car_price_end,$new_pcar_price,$new_drate_e,$userid,$userid;
						if(SQLCODE != 0)
                        	is_upd_fail = 3;
						break;
					case 'D':
                    	sprintf_s(stmt_buf, sizeof stmt_buf,
                    	"DELETE FROM car_price_factor "
                       	" WHERE car_price_bgn=? AND drate=?");
						$PREPARE u2_id FROM $stmt_buf;
                        $EXECUTE u2_id USING $cur_car_price_bgn,$cur_drate;
						if(SQLCODE != 0)
                        	is_upd_fail = 3;
						break;
                    case 'U':
printf("708\n");
printf("new_car_price_bgn[%d]\n",new_car_price_bgn);
printf("new_car_price_end[%d]\n",new_car_price_end);
printf("new_pcar_price[%f]\n",new_pcar_price);
printf("new_drate_e[%s]\n",new_drate_e);
printf("cur_car_price_bgn[%d]\n",cur_car_price_bgn);
printf("userid[%s]\n",userid);
printf("cur_drate[%s]\n",cur_drate);


                       	sprintf_s(stmt_buf, sizeof stmt_buf,
                       	"UPDATE %s SET (%s %s)=(%s) %s ","car_price_factor",
                   	   			"car_price_bgn,car_price_end,",
                   				"pcar_price,drate,iupdate,dupdate",
                           		"?,?,?,?,?,current",
                               	"WHERE car_price_bgn=? AND drate=?");
                       	$PREPARE u3_id FROM $stmt_buf;
                       	$EXECUTE u3_id USING $new_car_price_bgn,$new_car_price_end,$new_pcar_price,
                       	                     $new_drate_e,$userid,
                                             $cur_car_price_bgn,$cur_drate;
						if(SQLCODE != 0)
                           	is_upd_fail = 3;
						break;
					default:
                        $WHENEVER SQLERROR CONTINUE;
                        $ROLLBACK WORK;
                        if(exitsub(reply,M_CM_WRONG_OPTION) == True)
                        	return M_CM_WRONG_OPTION;
						else
                           	return apiRC;
				}
			}
			
			for (i = 0; i < rows; i++){
				free( alist[i]);
			}
			free ( (char *) alist);
			
    	cm_buf_init(ReplyBuf);
    	cm_buf_put("%l",M_CM_OK);
    	tmp_len = cm_buf_len(ReplyBuf);
    	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    	{
    		$WHENEVER SQLERROR CONTINUE;
        	$ROLLBACK WORK;
        	return apiRC;
    	}
	    $WHENEVER SQLERROR GOTO errexit;
    	$COMMIT WORK;
    	return api_OKComplete;
   	}
   	else    /* option is not 'D' or 'U' */
   	{
    	return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
   	}

errexit:
	MsgCode = SQLCODE;
	$WHENEVER SQLERROR CONTINUE;
   	$ROLLBACK WORK;
   	if( SQLCODE != 0) MsgCode = SQLCODE;
   	return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
/*--------------------------------------------------*/
