/************************************************/
/*   PROGRAM : ca136m01s.ec by S.Y.J.           */
/*   DATE    : 2002/10/09                       */
/*             �t�P�����������X�ˮָ�ƺ��@     */
/*   TABLE   : brand_engine                     */
/************************************************/
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"
$include sqlca;

long car136(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
    long rtncode;
    long car136_insert(),car136_single_query(),car136_multiple_query();
    long car136_update_exec();
    char option;

    cm_buf_init(command);
    cm_buf_get("%c",&option);
    switch(option)
    {
        case 'A': rtncode=car136_insert(reply);
                  break;
        case 'Q': rtncode=car136_single_query(reply);
                  break;
        case 'M': rtncode=car136_multiple_query(reply);
                  break;
        case 'D':
        case 'U': rtncode=car136_update_exec(reply,command,com_len);
                  break;
        default : 
                  return exitsub(reply,M_CM_WRONG_OPTION)?M_CM_WRONG_OPTION:apiRC;
    }
    return(rtncode);
}

/*-----------------------------------------------------------------*/
long car136_insert(reply)
serverReply reply;
{
    $char  DBName[5];
    $char  ibrand[10], engine_title[11], check_type[3], Cdate[11];
    $int   engine_len, eng_pos_bgn, eng_pos_end, eng_length;
    $date  check_date;
    int    tmp_len;
    long   MsgCode;

    cm_buf_get("%s %s %d %s %s %d %d %s",
                DBName, ibrand,
                &engine_len,
                engine_title,
                check_type, &eng_pos_bgn, &eng_pos_end,
                Cdate);

    strcpy(ibrand, trim(ibrand));
    strcpy(engine_title, trim(engine_title));
    strcpy(Cdate, trim(Cdate));

    /** convert from CY/MM/DD string to DATE type **/
    check_date = cm_ymd_cdate(Cdate);

    if ((strcmp(trim(check_type),"N")==0) ||  (strcmp(trim(check_type),"U")==0))
    {
        eng_length = eng_pos_end - eng_pos_bgn + 1;
        if (eng_length < 0)
            eng_length = 0;
    }
    else
    {
        eng_length = 0;
    }

    printf("[%s][%d][%s][%s][%d][%d][%d][%s]\n",
            ibrand, engine_len, engine_title,
            check_type, eng_pos_bgn, eng_pos_end, eng_length,
            Cdate);

    $WHENEVER SQLERROR GOTO errexit;

    if(db_select(DBName) == False) 
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    $BEGIN WORK;

    $INSERT INTO brand_engine
            (ibrand, engine_len, engine_title, eng_position, eng_length, check_type, check_date)
     VALUES ($ibrand, $engine_len, $engine_title, $eng_pos_bgn, $eng_length, $check_type, $check_date);

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    tmp_len = cm_buf_len(ReplyBuf);

    if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        return apiRC;
    }  

    $WHENEVER SQLERROR GOTO errexit;
    $COMMIT WORK;
    return api_OKComplete;

errexit:
    MsgCode = SQLCODE;
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if( SQLCODE != 0) MsgCode = SQLCODE;
    return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

/*-----------------------------------------------------------------*/
long car136_single_query(reply)
serverReply reply;
{
    $char  DBName[5];
    $char  ibrand[10], engine_title[11], check_type[3], Cdate[11];
    $int   engine_len, eng_pos_bgn = 0, eng_pos_end, eng_length = 0;
    $date  check_date;

    int    tmp_len;

    cm_buf_get("%s",DBName);
    cm_buf_get("%s %d %s %s %s",ibrand,&engine_len,engine_title,check_type,Cdate);

    /*************************************
    strcpy(ibrand, trim(ibrand));
    strcpy(check_type, trim(check_type));
    strcpy(Cdate, trim(Cdate));
    *************************************/

    printf("[%s][%s][%s]\n",ibrand,check_type,Cdate);

    /** convert from CY/MM/DD string to DATE type **/
    check_date = cm_ymd_cdate(Cdate);
    printf("check_date[%ld]\n", check_date);

    $WHENEVER SQLERROR GOTO errexit;

    if(db_select(DBName) == False) 
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    printf( "SELECT brand_engine\n");
    $SELECT ibrand, engine_len, engine_title, eng_position, eng_length, check_type, check_date
       INTO $ibrand, $engine_len, $engine_title, $eng_pos_bgn, $eng_length, $check_type, $check_date
       FROM brand_engine
      WHERE ibrand     = $ibrand
        AND engine_len = $engine_len
        AND ( engine_title = $engine_title OR engine_title is null )
        AND check_type = $check_type
        AND check_date = $check_date;
    if(SQLCODE==SQLNOTFOUND) 
        return exitsub(reply,M_CM_NOT_FOUND) ? M_CM_NOT_FOUND : apiRC;

    /** convert from DATE type to CY/MM/DD string **/
    strcpy(Cdate, cm_cdate_str_100(check_date));

    if ((strcmp(trim(check_type),"N")==0) ||  (strcmp(trim(check_type),"U")==0))
    {
         eng_pos_end = eng_pos_bgn+eng_length-1;
         if (eng_pos_end < 0)
             eng_pos_end = 0;
    }
    else
    {
         eng_pos_end = 0;
    }

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %d %s %s %d %d %s",
                M_CM_OK,
                ibrand,
                engine_len,
                engine_title,
                check_type,
                eng_pos_bgn,
                eng_pos_end,
                Cdate);

    tmp_len = cm_buf_len(ReplyBuf);
    if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    return exitsub(reply, SQLCODE) ? SQLCODE : apiRC;
}

/*-----------------------------------------------------------------*/
long car136_multiple_query(reply)
serverReply reply;
{
    $char  DBName[5];

    $char  ibrand[10], engine_title[11], check_type[3], Cdate[11];
    $int   engine_len = 0, eng_pos_bgn = 0, eng_pos_end, eng_length = 0;
    $date  check_date;

    char   tmpbuf[4000];
    int    count=0,repbuf_len=0,tmp_len=0,replycnt=0;
    int    i,total_count=0;

    printf("car136_multiple_query \n");
    cm_buf_get("%s",DBName);
    cm_buf_get("%s %d %s %s %s",ibrand,&engine_len,engine_title,check_type,Cdate);

    strcpy(ibrand, trim(ibrand));
    strcpy(check_type, trim(check_type));
    strcpy(Cdate, trim(Cdate));

    /** convert from CY/MM/DD string to DATE type **/
    check_date = cm_ymd_cdate(Cdate);

    $WHENEVER SQLERROR GOTO errexit;
    if(db_select(DBName) == False) 
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    printf("Declare q_cur FOR brand_engine \n");
    $DECLARE q_cur CURSOR FOR
      SELECT ibrand, engine_len, engine_title, eng_position, eng_length, check_type, check_date
        INTO $ibrand, $engine_len, $engine_title, $eng_pos_bgn, $eng_length, $check_type, $check_date
        FROM brand_engine
       WHERE ibrand     matches $ibrand
         AND ( engine_title matches $engine_title OR engine_title is null )
         AND check_type matches $check_type
       ORDER BY ibrand;
    $OPEN q_cur;
    for(;;)
    {
        $FETCH q_cur;
        if(SQLCODE != 0) break;

        cm_buf_init(tmpbuf);
        if( count == 0 )
        {
             cm_buf_res_msg();    /* reserve for MsgCode and count */
             cm_buf_res_count();
        }

        /** convert from DATE type to CY/MM/DD string **/
        strcpy(Cdate, cm_cdate_str_100(check_date));

        if ((strcmp(trim(check_type),"N")==0) ||  (strcmp(trim(check_type),"U")==0))
        {
             eng_pos_end = eng_pos_bgn+eng_length-1;
             if (eng_pos_end < 0)
                 eng_pos_end = 0;
        }
        else
        {
             eng_pos_end = 0;
        }

        cm_buf_put("%s", ibrand);
        cm_buf_put("%d", engine_len);
        cm_buf_put("%s", engine_title);
        cm_buf_put("%s %d %d", check_type,eng_pos_bgn,eng_pos_end);
        cm_buf_put("%s", Cdate);

        tmp_len = cm_buf_len(tmpbuf);

        if( tmp_len + repbuf_len < 3000 )
        {    /* buffer size less than 4K */
            memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
            repbuf_len += tmp_len;
            count++;
        }
        else
        {    /* more than 4K, send to client side */
            cm_buf_init(ReplyBuf);
            cm_buf_put_msg(M_CM_OK);
            cm_buf_put_count(count);

            if(SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
            {
                $CLOSE q_cur;
                return apiRC;
            }
            else
            {    /* clear ReplyBuf and count to start all over again */
                replycnt++;

                if(replycnt == 8)
                {    /* more than 30K, client cannot display,error */
                    cm_buf_init(ReplyBuf);
                    cm_buf_put("%l",M_CM_OUT_SPACE);
                    tmp_len = cm_buf_len(ReplyBuf);
                    if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
                        return apiRC;
                    return M_CM_OUT_SPACE;
                }

                ReplyBuf[0] = '\0';
                count = 0;
                cm_buf_init(ReplyBuf);
                cm_buf_res_msg();    /* reserve for MsgCode and count */
                cm_buf_res_count();

                cm_buf_put("%s", ibrand);
                cm_buf_put("%d", engine_len);
                cm_buf_put("%s", engine_title);
                cm_buf_put("%s %d %d", check_type,eng_pos_bgn,eng_pos_end);
                cm_buf_put("%s", Cdate);

                repbuf_len = cm_buf_len(ReplyBuf);
                count++;
            }
        }
    }   /* for loop */

    $CLOSE q_cur;
    if(count > 0)
    {    /* break out, at least one record is selected */
        cm_buf_init(ReplyBuf);
        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(count);
        if(SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
            return apiRC;
        return api_OKComplete;
    }
    else    /* break out, not any row is found */
    {
        return exitsub(reply,M_CM_NOT_FOUND) ? M_CM_NOT_FOUND : apiRC;
    }

errexit:
    return exitsub(reply, SQLCODE) ? SQLCODE : apiRC;
}

/*-----------------------------------------------------------------*/
long car136_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
    $char  cur_ibrand[10], cur_Cdate[11];
    $char  ibrand[10], engine_title[11], check_type[3], Cdate[11];
    $int   engine_len = 0, eng_pos_bgn, eng_pos_end, eng_length,cur_engine_len;
    $char  cur_check_type[3],cur_engine_title[11];
    $date  check_date;
    $date  cur_check_date;

    char   option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
    int    tmp_len,raw_len;
    long   dummy;
    long   MsgCode;
    char   tmp_buf[20];
    long   tmp_long;

    $char  DBName[5];

    comm = (char *) command;
    cm_buf_init(command);
    cm_buf_get("%c %s",&option,DBName);

    $WHENEVER SQLERROR GOTO errexit;

    if(db_select(DBName) == False) 
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    /* compare old record and current record, if the record has not been changed
       since last request, update or delete the record, otherwise return errmsg
       to client side
    */

    /* get old record info from command buffer */

    /* raw_len = *(int *) &comm[com_len];
       memcpy(&raw_len,(void *)&command[com_len],sizeof(int));
    */

    memcpy(&raw_len,&comm[com_len],sizeof(int));
    pos = &comm[com_len+sizeof(int)];
    raw_ptr = malloc(raw_len);
    if(raw_ptr != (char*)0)
        memcpy(raw_ptr,pos,raw_len);
    else
    {
        if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */
            return M_CM_NOT_MALLOC;
        else
            return apiRC;
    }

    cm_buf_init(raw_ptr);    /* get index key from old record */
    cm_buf_get("%l %s %d %s %s %d %d %s",
               &dummy,
               cur_ibrand,&cur_engine_len,
               cur_engine_title,
               cur_check_type,&eng_pos_bgn,&eng_pos_end,
               cur_Cdate);

    /*******************************************
    strcpy(cur_ibrand, trim(cur_ibrand));
    strcpy(cur_check_type, trim(cur_check_type));
    strcpy(cur_Cdate, trim(cur_Cdate));
    *******************************************/

    /** convert from CY/MM/DD string to DATE type **/
    cur_check_date = cm_ymd_cdate(cur_Cdate);

    $BEGIN WORK;

    printf( "[UPDATE]:SELECT brand_engine[%s][%ld] \n",cur_ibrand,cur_check_date);
    $SELECT ibrand, engine_len, engine_title, eng_position, eng_length, check_type, check_date
       INTO $ibrand, $engine_len, $engine_title, $eng_pos_bgn, $eng_length, $check_type, $check_date
       FROM brand_engine
      WHERE ibrand     = $cur_ibrand
        AND engine_len = $cur_engine_len
        AND ( engine_title = $cur_engine_title OR engine_title is null )
        AND check_type = $cur_check_type
        AND check_date = $cur_check_date;
    if(SQLCODE == SQLNOTFOUND)
    {
        MsgCode = M_CM_NOT_FOUND;
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        if( SQLCODE != 0) MsgCode = SQLCODE;
        return exitsub(reply,MsgCode) ? MsgCode : apiRC;
    }

    /** convert from DATE type to CY/MM/DD string **/
    strcpy(Cdate, cm_cdate_str_100(check_date));

    if ((strcmp(trim(check_type),"N")==0) ||  (strcmp(trim(check_type),"U")==0))
    {
         eng_pos_end = eng_pos_bgn+eng_length-1;
         if (eng_pos_end < 0)
             eng_pos_end = 0;
    }
    else
    {
         eng_pos_end = 0;
    }

    cm_buf_init(cur_buf);
    cm_buf_put("%l %s %d %s %s %d %d %s",
                dummy,
                ibrand, engine_len,
                engine_title,
                check_type, eng_pos_bgn, eng_pos_end,
                Cdate);

    printf("cur_buf[%s]\n",cur_buf);
    printf("raw_ptr[%s]\n",raw_ptr);
    printf("raw_len[%d]\n",raw_len);

    if(memcmp(cur_buf,raw_ptr,raw_len) != 0)
    {   /* compare 2 records, not equal */
        MsgCode = M_CM_NOT_EQUAL;
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
		free(raw_ptr);
        if( SQLCODE != 0) MsgCode = SQLCODE;
        return exitsub(reply,MsgCode) ? MsgCode : apiRC;
    }

    /* equal, then exec DB operation */
    if( option == 'D' )
    {
        printf("OPTION D:ibrand[%s],cur_check_date[%ld]\n",cur_ibrand,cur_check_date);

        $DELETE FROM brand_engine
          WHERE ibrand     = $cur_ibrand
            AND engine_len = $cur_engine_len
            AND ( engine_title = $cur_engine_title OR engine_title is null )
            AND check_type = $cur_check_type
            AND check_date = $cur_check_date;

        cm_buf_init(ReplyBuf);
        cm_buf_put("%l",M_CM_OK);
        tmp_len = cm_buf_len(ReplyBuf);
        if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
        {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            return apiRC;
        }

        $WHENEVER SQLERROR GOTO errexit;
        $COMMIT WORK;
        return api_OKComplete;
    }
    else if(option == 'U')
    {
        printf("OPTION U:ibrand[%s],cur_check_date[%ld]\n",cur_ibrand,cur_check_date);

        cm_buf_init(command);
        cm_buf_get("%c %s ",
                    &option,DBName);

        cm_buf_get("%s %d %s %s %d %d %s",
                    ibrand,
                    &engine_len,
                    engine_title,
                    check_type, &eng_pos_bgn, &eng_pos_end,
                    Cdate);

        strcpy(ibrand, trim(ibrand));
        strcpy(Cdate, trim(Cdate));

        /** convert from CY/MM/DD string to DATE type **/
        check_date = cm_ymd_cdate(Cdate);

        if ((strcmp(trim(check_type),"N")==0) ||  (strcmp(trim(check_type),"U")==0))
        {
            eng_length = eng_pos_end - eng_pos_bgn + 1;
            if (eng_length < 0)
                eng_length = 0;
        }
        else
        {
            eng_length = 0;
        }

        $UPDATE brand_engine
            SET (engine_len, engine_title, check_type, eng_position, eng_length)
              = ($engine_len, $engine_title, $check_type, $eng_pos_bgn, $eng_length)
          WHERE ibrand     = $cur_ibrand
            AND engine_len = $cur_engine_len
            AND ( engine_title = $cur_engine_title OR engine_title is null )
            AND check_type = $cur_check_type
            AND check_date = $cur_check_date;
 
        if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
        {
            $INSERT INTO brand_engine
                    (ibrand, engine_len, engine_title, eng_position, eng_length, check_type, check_date)
             VALUES ($ibrand, $engine_len, $engine_title, $eng_pos_bgn, $eng_length, $check_type, $check_date);
        }

        cm_buf_init(ReplyBuf);
        cm_buf_put("%l",M_CM_OK);
        tmp_len = cm_buf_len(ReplyBuf);
        
        if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
        {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            return apiRC;
        }

        $WHENEVER SQLERROR GOTO errexit;
        $COMMIT WORK;
        return api_OKComplete;
    }
    else
    {
        return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
    }

errexit:
    MsgCode = SQLCODE;
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if( SQLCODE != 0) MsgCode = SQLCODE;
    return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
/*-----------------------------------------------------------------*/
