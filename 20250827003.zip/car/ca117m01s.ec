/************************************************/
/*                                              */
/*   PROGRAM : ca544m01s.ec by Pei-Chow Chen    */
/*   MODIFIER: Johnny Kuo 04/10/1997            */
/*   PURPOSE : server side standard program     */
/*                                              */
/************************************************/

#include <stdio.h>
#include <string.h>
#include <decimal.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "commsgs.h"
#include "carmsgs.h"
$include sqlca;
#include "safeclib.h"

long MsgCode;

long car117(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car117_insert(),car117_single_query(),car117_multiple_query(),
      car117_update_exec(),car117_squery();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'S': rtncode = car117_squery(reply);
                   break;
  case 'A':
           rtncode=car117_insert(reply);
           break;
  case 'Q':
           rtncode=car117_single_query(reply);
           break;
  case 'M':
           rtncode=car117_multiple_query(reply);
           break;
  case 'D':
  case 'U':
           rtncode=car117_update_exec(reply,command,com_len);
           break;  
  default :
        return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
 }
 return(rtncode);
}

long car117_squery(reply)
serverReply reply;
{
     $char DBName[5],D_dbsite[5];
     $char LHsBuffer[1024],sFullName[20];
     $char ibrand[9];
     $char s_ibrand[9];
     $char stmt[1024];

     int LHiBufLen;
     long MsgCode;

     cm_buf_get("%s",DBName);
     cm_buf_get("%s",ibrand);

     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
        { return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;}


     printf("ibrand[%s]\n",ibrand);

     sprintf_s(LHsBuffer, sizeof LHsBuffer, "SELECT ibrand "
                        "  FROM ca_car_model "
                        " WHERE ibrand = ? ");


     $PREPARE appraisal_pre FROM $LHsBuffer;
     $DECLARE appraisal_cur CURSOR FOR appraisal_pre;
     $OPEN appraisal_cur USING $ibrand;
     $FETCH appraisal_cur INTO $s_ibrand;

     printf(" LHsBuffer[%s]\n",LHsBuffer);

     if (SQLCODE == SQLNOTFOUND)
     {
         if(exitsub(reply,M_CA_NBRAND) == True)
             return M_CA_NBRAND;
         else
             return apiRC;
     }

     $CLOSE appraisal_cur;
     $FREE appraisal_cur;

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);

     LHiBufLen = cm_buf_len(ReplyBuf);

     if(SendSyncReply(reply,ReplyBuf,LHiBufLen,api_OKComplete) == False)
     {
         $WHENEVER SQLERROR CONTINUE;
         $ROLLBACK WORK;
         return apiRC;
     }

     $WHENEVER SQLERROR GOTO errexit;
     return api_OKComplete;

     errexit:
        printf("sqlerrm:%s\n",sqlca.sqlerrm);
        $WHENEVER SQLERROR CONTINUE;
        MsgCode = SQLCODE;
        if (SQLCODE != 0) MsgCode = SQLCODE;
        return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

long car117_insert(reply)
serverReply reply;
{
     $char DBName[5],DBName1[5];
     $char LsBuffer[1024], sFullName[20];
     $char sFullName_sys[20];
     $char c_imotor[7],c_sales_brand[21],c_dtl_brand[21];
     $char c_icar_type[3],c_ibrand[9];
     $char str_mprize[12];
     $double dec_mprize,d_mprize;

  
     int LiBufLen;
     cm_buf_get("%s",DBName);
     cm_buf_get("%s %s %s %s",c_imotor,c_sales_brand,c_dtl_brand,str_mprize);
     cm_buf_get("%s %s",c_icar_type,c_ibrand);

     printf(" %s %s %s %s %s %s \n",c_imotor,c_sales_brand,c_dtl_brand,str_mprize,c_icar_type,c_ibrand);
     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
         return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     deccvasc( str_mprize, strlen(str_mprize), &dec_mprize);
     dectodbl( &dec_mprize, &d_mprize);

     $BEGIN WORK;
     $WHENEVER SQLERROR GOTO errexit;

     
     sprintf_s(LsBuffer, sizeof LsBuffer,"INSERT INTO collate_brand "
            " (imotor,sales_brand,dtl_brand,mprize,icar_type,ibrand) "
      " VALUES (?,?,?,?,?,?)");
  
     $PREPARE a_id FROM $LsBuffer;
     $EXECUTE a_id USING $c_imotor,$c_sales_brand,$c_dtl_brand,$d_mprize,
                         $c_icar_type,$c_ibrand;
  

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);
     LiBufLen = cm_buf_len(ReplyBuf);   

     if(SendSyncReply(reply,ReplyBuf,LiBufLen,api_OKComplete) == False)
     {
       $WHENEVER SQLERROR CONTINUE;
       $ROLLBACK WORK;
       return apiRC;
     }

     $WHENEVER SQLERROR GOTO errexit;
     $COMMIT WORK;
     return api_OKComplete;

     errexit:
         printf(" sqlerrm = %s\n",sqlca.sqlerrm);
         $WHENEVER SQLERROR CONTINUE;
         MsgCode = SQLCODE;
         $ROLLBACK WORK;
         if (SQLCODE != 0) MsgCode = SQLCODE;
         return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}


long car117_single_query(reply)
serverReply reply;
{
 
 $char DBName[5];
 $char m_imotor[7], m_sales_brand[21],m_dtl_brand[21],m_icar_type[3],m_ibrand[9];


 $char q_imotor[7], q_sales_brand[21],q_dtl_brand[21],q_icar_type[3],q_ibrand[9];
 $double dec_m_mprize,d_m_mprize;
 $char str_m_mprize[12],str_q_mprize[12];
 $double d_q_mprize = 0.0,dec_q_mprize;

 int tmp_len;
 
 cm_buf_get("%s %s %s %s %s %s %s",DBName,m_imotor,m_sales_brand,m_dtl_brand,str_m_mprize,m_icar_type,m_ibrand);

 deccvasc( str_m_mprize, strlen(str_m_mprize), &dec_m_mprize);
 dectodbl( &dec_m_mprize, &d_m_mprize);
 
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }
     
     $SELECT imotor,sales_brand,dtl_brand,mprize,icar_type,ibrand
        INTO $q_imotor,$q_sales_brand,$q_dtl_brand,$d_q_mprize,$q_icar_type,$q_ibrand
        FROM collate_brand
       WHERE imotor = $m_imotor
         AND sales_brand = $m_sales_brand
         AND dtl_brand = $m_dtl_brand
         AND mprize = $d_m_mprize;



     
 if(SQLCODE==SQLNOTFOUND)
 {
  if(exitsub(reply,M_CM_NOT_FOUND) == True)
    return M_CM_NOT_FOUND;
  else
    return apiRC;
 }

 cm_buf_init(ReplyBuf);

 sprintf_s(str_q_mprize, sizeof str_q_mprize,"%.2f",d_q_mprize);
 cm_buf_put("%l %s %s %s %s %s %s",
             M_CM_OK, q_imotor,q_sales_brand,q_dtl_brand,str_q_mprize,q_icar_type,q_ibrand);


 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

 errexit:
   MsgCode = cm_show_sql_err("ca544_single_query", NULL);
  if(exitsub(reply,MsgCode) == True)
   return SQLCODE;
  else
   return apiRC;
}

long car117_multiple_query(reply)
serverReply reply;
{
 $char DBName[5];
 $char c_imotor[7],c_sales_brand[21],c_dtl_brand[21],c_icar_type[3],c_ibrand[9];
 $double c_mprize;
 $char m_imotor[7],m_sales_brand[21],m_dtl_brand[21],m_icar_type[3],m_ibrand[9];
 $double dec_m_mprize,d_m_mprize = 0.0;
 $char str_m_mprize[12];

 /* $char sFullName_sys[20];  */
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0;
 int OPEN_STAR;
 cm_buf_get("%s %s %s %s",DBName,c_imotor,c_sales_brand,c_dtl_brand);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 $DECLARE q_cur2 CURSOR FOR
   SELECT imotor,sales_brand,dtl_brand,mprize,icar_type,ibrand
     INTO $m_imotor,$m_sales_brand,$m_dtl_brand,$d_m_mprize,$m_icar_type,$m_ibrand
     FROM collate_brand
    WHERE imotor matches $c_imotor
      AND sales_brand matches $c_sales_brand
      AND dtl_brand matches $c_dtl_brand
    ORDER BY imotor;
    $OPEN q_cur2;
 
 for(;;)
  {
    $FETCH q_cur2;
   
    if (SQLCODE != 0) break;
    
    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();
     }


  /*  deccvasc( str_m_mprize, strlen(str_m_mprize), &dec_m_mprize);
    dectodbl( &dec_m_mprize, &d_m_mprize);   */

    sprintf_s(str_m_mprize, sizeof str_m_mprize,"%.2f",d_m_mprize);

    cm_buf_put("%s %s %s %s %s %s",m_imotor,m_sales_brand,m_dtl_brand,str_m_mprize,m_icar_type,m_ibrand);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
        $CLOSE q_cur;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;

        if(replycnt > 5) sleep(3);
        else if(replycnt > 3) sleep(2);
        else if(replycnt > 1) sleep(1);

        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();

        sprintf_s(str_m_mprize, sizeof str_m_mprize,"%.2f",d_m_mprize);
        cm_buf_put("%s %s %s %s %s %s",m_imotor,m_sales_brand,m_dtl_brand,str_m_mprize,m_icar_type,m_ibrand);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
  } /* for loop */

 $CLOSE q_cur2;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
    if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
      return M_CM_NOT_FOUND;                               /*?*/
    else
      return apiRC;
  }

 errexit:
   MsgCode = cm_show_sql_err("ca544_multiple_query", NULL);
   if(exitsub(reply,MsgCode) == True)
     return SQLCODE;
   else
     return apiRC;
}

long car117_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
        
 $char DBName[5];
 
 $char cur_imotor[7],cur_sales_brand[21];
 $char cur_dtl_brand[21],cur_icar_type[3],cur_ibrand[9];
 $char cur_mprize[12];
 $double mprize;

 $char u_imotor[7],u_sales_brand[21];
 $char u_dtl_brand[21],u_icar_type[3],u_ibrand[9];
 $double dec_u_mprize,d_u_mprize;
 $char str_u_mprize[12];

 $char q_imotor[7],q_sales_brand[21];
 $char q_dtl_brand[21],q_icar_type[3],q_ibrand[9];
 $double d_q_mprize,dec_q_mprize;
 $char str_q_mprize[12];


 char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
 int tmp_len,raw_len; long dummy;
   DBinfo *list;
   int i, j, is_del_fail=0, is_upd_fail=0;
   $char stmt_buf[300];

 comm = (char *) command;
 cm_buf_init(command);
 cm_buf_get("%c %s",&option,DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

/*  if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
     return exitsub(reply,M_CM_NOT_DBLIST) ? M_CM_NOT_DBLIST : apiRC;  */

 memcpy(&raw_len,&comm[com_len],sizeof(int));
 pos = &comm[com_len+sizeof(int)];
 raw_ptr = malloc(raw_len);
 if (raw_ptr != (char*)0)
  memcpy(raw_ptr,pos,raw_len);
 else
  { 
   return exitsub(reply,M_CM_NOT_MALLOC) ? M_CM_NOT_MALLOC : apiRC;
  }



 cm_buf_init(raw_ptr);          /* get index key from old record */
 cm_buf_get("%l %s %s %s %s %s %s ",
             &dummy,q_imotor,q_sales_brand,q_dtl_brand,str_q_mprize,q_icar_type,q_ibrand);

 deccvasc( str_q_mprize, strlen(str_q_mprize), &dec_q_mprize);
 dectodbl( &dec_q_mprize, &d_q_mprize);

 $BEGIN WORK;

 $SELECT imotor,sales_brand,dtl_brand,mprize,icar_type,ibrand
    INTO $cur_imotor,$cur_sales_brand,$cur_dtl_brand,$mprize,$cur_icar_type,$cur_ibrand
    FROM collate_brand
   WHERE imotor=$q_imotor AND sales_brand=$q_sales_brand AND dtl_brand = $q_dtl_brand
     AND mprize = $d_q_mprize;



  /* if key value has been changed then SQLNOTFOUND,else put current value
     into cur_buf for comparison */

 if (SQLCODE == SQLNOTFOUND)
 {
   MsgCode = M_CM_NOT_FOUND;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(SQLCODE != 0) MsgCode = SQLCODE;
   return exitsub(reply,MsgCode) ? MsgCode : apiRC;
 }

 cm_buf_init(cur_buf);
 sprintf_s(cur_mprize, sizeof cur_mprize,"%.2f",mprize);
 printf(" cur_mprize[%s]\n",cur_mprize);

 cm_buf_put("%l %s %s %s %s %s %s ",
             dummy,cur_imotor,cur_sales_brand,cur_dtl_brand,cur_mprize,
             cur_icar_type,cur_ibrand);

 write(1,raw_ptr,raw_len);
 write(1,"\n",1);
 write(1,cur_buf,raw_len);
 write(1,"\n",1);


 printf("cur_buf[%s]\n",cur_buf);
 printf("raw_ptr[%s]\n",raw_ptr);
 if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
 {
   MsgCode = M_CM_NOT_EQUAL;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(SQLCODE != 0) MsgCode = SQLCODE;
   return exitsub(reply,MsgCode) ? MsgCode : apiRC;
 }

 /* equal, then exec DB operation */

 if ( option == 'D' )
  {
 
    sprintf_s(stmt_buf, sizeof stmt_buf,"DELETE FROM collate_brand "
        " WHERE imotor= ? AND sales_brand = ? AND dtl_brand = ? "
        " AND mprize= ? ");
    $PREPARE d_id FROM $stmt_buf;


    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      
     }
    $EXECUTE d_id USING $q_imotor,$q_sales_brand,$q_dtl_brand,
                        $d_q_mprize;
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      
     }

   if( is_del_fail ) goto errexit;
   
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
   {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
   }

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
   else if (option == 'U')
  {
   cm_buf_init(command);

   cm_buf_get("%c %s %s %s %s %s %s %s",
           &option,DBName,u_imotor,u_sales_brand,u_dtl_brand,str_u_mprize,u_icar_type,u_ibrand);

    deccvasc( str_u_mprize, strlen(str_u_mprize),&dec_u_mprize);
    dectodbl( &dec_u_mprize, &d_u_mprize);


   /* grasp old key */
   cm_buf_init(raw_ptr);
   cm_buf_get("%l %s %s %s %s %s %s ",&dummy,
        q_imotor,q_sales_brand,q_dtl_brand,str_q_mprize,q_icar_type,q_ibrand);

   $WHENEVER SQLERROR CONTINUE;

    sprintf_s(stmt_buf, sizeof stmt_buf,
                "UPDATE collate_brand "
                "   SET (imotor,sales_brand,dtl_brand,mprize,icar_type,ibrand) "
                "     = (?,?,?,?,?,?) "
                " WHERE imotor = ? AND sales_brand=? AND dtl_brand = ? "
                "   AND mprize = ?  ");

    $PREPARE u_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
     
     }


    $EXECUTE u_id USING $u_imotor,$u_sales_brand,$u_dtl_brand,$str_u_mprize,
                        $u_icar_type,$u_ibrand,
                        $q_imotor,$q_sales_brand,$q_dtl_brand,$d_q_mprize;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      
     }
	 
	 free(raw_ptr);

 /* if(sqlca.sqlerrd[2] == 0)
    {
        printf(" ********************************* \n");
        sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO collate_brand \
         (imotor,sales_brand,dtl_brand,mprize,icar_type,ibrand)\
          VALUES (?,?,?,?,?,?)");

      $PREPARE ua_id FROM $stmt_buf;
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        
       }
      $EXECUTE ua_id USING $u_imotor,$u_sales_brand,$u_dtl_brand,$d_u_mprize,
                           $u_icar_type,$u_ibrand;
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        
       }
     }                                           */
 
   if( is_upd_fail ) goto errexit;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
   {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
   }
   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else
  {
   MsgCode = M_CM_WRONG_OPTION;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
    return MsgCode;
   else
    return apiRC;
  }

errexit:
  MsgCode = SQLCODE;
  cm_show_sql_err("ca544_update_exec", stmt_buf);
  $WHENEVER SQLERROR CONTINUE;
  $ROLLBACK WORK;
  if(SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True)
   return MsgCode;
  else
   return apiRC;
}
