/************************************************/
/*                                              */
/*   PROGRAM : car116.ec
/*                                              */
/************************************************/
     
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;
$include decimal;
#include "safeclib.h"


long car116(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car116_insert(),car116_single_query(),car116_multiple_query(),car116_update_exec();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'A':
	   rtncode=car116_insert(reply);
	   break;
  case 'Q':
	   rtncode=car116_single_query(reply);
	   break;
  case 'M':
           rtncode=car116_multiple_query(reply);
	   break;
  case 'D':
  case 'U':
	   rtncode=car116_update_exec(reply,command,com_len);
	   break;
  default :
	   if(exitsub(reply,M_CM_WRONG_OPTION) == True)
	    return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}

long car116_insert(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table depreciation_rate */
 $char carclass[2], Drate1[11], Drate2[11], Icreate[11];
 $long prdbgn,prdend;
 $dec_t dec;
 /* end of depreciation_rate */

 /* standard defined data */
 int tmp_len;
   DBinfo *list;
   int i, j, is_add_fail=0, api_f;
   $char stmt_buf[2000],stmtx[2000];
 /* end of standard data */

 /* self defined data */
 char rate[7];
 long MsgCode;
 /* end of self data */

 cm_buf_get("%s",DBName);
 cm_buf_get("%c %l %l %s %s %s",&(carclass[0]),&prdbgn,&prdend,rate,Drate1,Icreate);
 carclass[1]='\0';

 memset(&dec, 0, sizeof(dec));

 if (db_select(DBName) == False) 
  { 
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

 deccvasc(rate,6,&dec);
 
 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
  {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
  }
  
	strcpy(Drate2, cm_to_infdate(Drate1));
	printf("Drate1=[%s]Drate2=[%s] Icreate=[%s]\n",Drate1,Drate2,Icreate);
	
 $BEGIN WORK;
 for(j=0;j<i;j++)
 {
  sprintf_s(stmt_buf, sizeof stmt_buf, "INSERT INTO %s:depreciation_rate "
 	" (fcar_class,qperiod_bgn,qperiod_end,pdepreciate,row_guid, drate,icreate, dcreate, iupdate, dupdate) "
	" VALUES (?,?,?,?,0,?,?,current,?,current)" ,list[j].dbname);
	
  $PREPARE a_id FROM $stmt_buf;
  if(SQLCODE != 0)
   {
    is_add_fail = 1;
    break;
   }
  $EXECUTE a_id USING  $carclass,$prdbgn,$prdend,$dec,$Drate2,$Icreate,$Icreate;
  if(SQLCODE != 0)
   {
    is_add_fail = 1;
    break;
   }
  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);
  tmp_len = cm_buf_len(ReplyBuf);
  if( j == i-1 )
     api_f = api_OKComplete;
  else
     api_f = api_OK;

  if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
    {
     is_add_fail = 2;
     break;
    }  
#ifdef DEBUG 
printf("INSERT %d\n", j+1);
#endif
 } /* for loop */

 if( is_add_fail == 1 ) goto errexit;

 if( is_add_fail == 2 ) 
  {
   $ROLLBACK WORK;
   return apiRC;
  }


 $WHENEVER SQLERROR GOTO errexit;
 $COMMIT WORK;
 return api_OKComplete;

 errexit:
  $WHENEVER SQLERROR CONTINUE;    
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True) 
   return MsgCode;
  else  
   return apiRC;
}

long car116_single_query(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table depreciation_rate */
 $char carclass[2];
 $long prdbgn,prdend = 0;
 $dec_t dec;
 $char Drate[11], Drate2[11], Icreate[11], Ncreate[11], Dcreate[21], Iupdate[11], 
       Nupdate[11], Dupdate[21];
 /* end of depreciation_rate */

 /* standard defined data */
 int tmp_len;
 /* end of standard data */

 /* self defined data */
 char rate[7];
 /* end of self data */

 cm_buf_get("%s",DBName);
 cm_buf_get("%c %l %s",&(carclass[0]),&prdbgn, Drate);
 carclass[1] = '\0';

 memset(&dec,0,sizeof(dec));

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False) 
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

	strcpy(Drate2, cm_to_infdate(Drate));
	printf("Drate=[%s] Drate2=[%s]\n",Drate,Drate2);
	printf("carclass=[%s] prdbgn=[%ld]Drate2=[%s]\n",carclass,prdbgn,Drate2);
 $SELECT qperiod_end,pdepreciate,icreate,dcreate,iupdate,dupdate,
         (select nname from officer where iofficer = a.icreate),
         (select nname from officer where iofficer = a.iupdate)
  INTO $prdend,$dec, $Icreate, $Dcreate, $Iupdate, $Dupdate, $Ncreate, $Nupdate
  FROM depreciation_rate a
  WHERE fcar_class=$carclass and qperiod_bgn=$prdbgn and drate = $Drate2;

 if(SQLCODE==SQLNOTFOUND) 
  {
   if(exitsub(reply,M_CA_NDEPRE_RATE) == True) 
    return M_CA_NDEPRE_RATE; 
   else  
    return apiRC;
  }

 dectoasc(&dec,rate,6,2);
 rate[6]='\0';
 cm_buf_init(ReplyBuf); 
 cm_buf_put("%l",M_CM_OK);
 cm_buf_put("%c %l %l %s %s %s %s %s %s %s %s",carclass[0],prdbgn,prdend,rate,
 Drate, Icreate, Ncreate, Dcreate, Iupdate, Nupdate, Dupdate);
 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
  return apiRC;
 else
  return api_OKComplete;

 errexit:
  if(exitsub(reply,SQLCODE) == True) 
   return SQLCODE;
  else  
   return apiRC;
}

long car116_multiple_query(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table depreciation_rate */
 $char carclass[2];
 $long prdbgn,prdend = 0;
 $dec_t dec;
 $char keyclass[2];
 $char Drate[11], sTmp1[1000], sTmp2[100],rate[7];
 /* end of depreciation_rate */

 /* standard defined data */
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0; 
 /* end of standard data */

 /* self defined data */
 /* char rate[7]; */
 char pbegin[10];
 int flag;
 
 /* end of self data */

 cm_buf_get("%s",DBName);
 cm_buf_get("%c %s %s",&(keyclass[0]),pbegin,Drate);
 keyclass[1] = '\0';
 
 memset(&dec, 0, sizeof(dec));

	if (strcmp(Drate, "*") == 0)
	{
		strcpy(sTmp2, "");
	}
	else
	{
			strcpy(Drate, cm_to_infdate(Drate));
			sprintf_s(sTmp2, sizeof sTmp2, " and drate = '%s' ", Drate);
			printf("Drate=[%s]sTmp2=[%s]\n",Drate,sTmp2);
	}

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False) 
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

 if ( pbegin[0]=='*' )
  {  
		flag = 0;
    sprintf_s(sTmp1, sizeof sTmp1,
    		"SELECT fcar_class, qperiod_bgn, qperiod_end, pdepreciate, drate "
            " FROM depreciation_rate a "
    		" WHERE fcar_class matches '%s' %s "
            " ORDER BY fcar_class, qperiod_bgn, qperiod_end, drate;",keyclass, sTmp2);
    printf("sTmp1=[%s]\n",sTmp1);
    
		$PREPARE m0_pre FROM $sTmp1;
		$DECLARE m0_cur  CURSOR FOR m0_pre;
    $OPEN m0_cur;
  }
 else
  {
		flag = 1;
		prdbgn = atoi(pbegin);
   
    sprintf_s(sTmp1, sizeof sTmp1,
    		"SELECT fcar_class, qperiod_end, pdepreciate, drate "
            " FROM depreciation_rate a "
    		" WHERE fcar_class matches '%s' and qperiod_bgn=%ld %s "
            " ORDER BY fcar_class, qperiod_bgn, qperiod_end, drate;",
          keyclass,prdbgn, sTmp2);
    printf("sTmp1=[%s]\n",sTmp1);

		$PREPARE m1_pre FROM $sTmp1;
		$DECLARE m1_cur  CURSOR FOR m1_pre;
    $OPEN m1_cur;
  }

 for(;;)
  {
    if ( flag == 0 )
     $FETCH m0_cur into $carclass, $prdbgn, $prdend, $dec, $Drate;
    else
     $FETCH m1_cur into $carclass, $prdend, $dec, $Drate;
    if (SQLCODE != 0) break;

    cm_buf_init(tmpbuf); 
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();          
     }
    dectoasc(&dec,rate,6,2);
    rate[6]='\0';
    
    strcpy(Drate, cm_from_infdate_100(Drate));
    printf("Drate=[%s]\n",Drate);
    
    cm_buf_put("%c %l %l %s %s",carclass[0],prdbgn,prdend,rate,Drate);
/*    cm_buf_put("%c %l %l %s",carclass[0],prdbgn,prdend,rate); */
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */ 
     { 
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
	if ( flag == 0 )
	 $CLOSE m0_cur;
        else
	 $CLOSE m1_cur;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
	 cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE; 
        }
	ReplyBuf[0] = '\0';
	count = 0;
	cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();    
        cm_buf_put("%c %l %l %s %s",carclass[0],prdbgn,prdend,rate,Drate);
/*    cm_buf_put("%c %l %l %s",carclass[0],prdbgn,prdend,rate); */
	repbuf_len = cm_buf_len(ReplyBuf);
	count++;
       }
     } 
  } /* for loop */

 if ( flag == 0 )
  $CLOSE m0_cur;
 else
  $CLOSE m1_cur;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
   if(exitsub(reply,M_CA_NDEPRE_RATE) == True) 
    return M_CA_NDEPRE_RATE;
   else  
    return apiRC;
  } 

 errexit:
  if(exitsub(reply,SQLCODE) == True) 
   return SQLCODE;
  else  
   return apiRC;
}


long car116_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table depreciation_rate */
 $char carclass[2];
 $long prdbgn,prdend;
 $dec_t dec;
 $char old_carclass[2];
 $long old_prdbgn, old_prdend;
 $char old_rate[7], old_Drate[11], old_Icreate[11], old_Ncreate[11], 
       old_Dcreate[21], old_Iupdate[11], old_Nupdate[11], old_Dupdate[21];
 $char Dupdate1[21], Drate1[11],Dupdate2[21], Drate[11],Iupdate[11],Drate2[11];
 /* end of depreciation_rate */

 /* standard defined data */
 char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
 int tmp_len,raw_len;
 long dummy=0;
   DBinfo *list;
   int i, j, is_del_fail=0, is_upd_fail=0;
   $char stmt_buf[2000];
 /* end of standard data */

 /* self defined data */
 char rate[7];
 long MsgCode;
 /* end of self data */

 comm = (char *) command;
 cm_buf_init(command);
 cm_buf_get("%c %s",&option,DBName);
 
 memset(&dec, 0, sizeof(dec));

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
  {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
  }
 /* compare old record and current record, if the record has not been changed  
    since last request, update or delete the record, otherwise return errmsg
    to client side */

 /* get old record info from command buffer */ 
 memcpy(&raw_len,&comm[com_len],sizeof(int));   
 pos = &comm[com_len+sizeof(int)];
 raw_ptr = malloc(raw_len);
 if (raw_ptr != (char*)0)  
  memcpy(raw_ptr,pos,raw_len);
 else
  {
   if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */ 
    return M_CM_NOT_MALLOC;
   else  
    return apiRC;
  }
    
	cm_buf_init(raw_ptr);          /* get index key from old record */
	cm_buf_get("%l",&dummy);
	cm_buf_get("%c %l %l %s %s %s %s %s %s %s %s",
            &(old_carclass[0]),&old_prdbgn,&old_prdend,old_rate, old_Drate, 
            old_Icreate, old_Ncreate, old_Dcreate, old_Iupdate, old_Nupdate, 
            old_Dupdate);
	old_carclass[1] = '\0';
	strcpy(Drate1, cm_to_infdate(old_Drate));
	free(raw_ptr);
	printf("Drate1=[%s]old_Drate=[%s]\n",Drate1,old_Drate);
	
	$BEGIN WORK;                
	$SELECT qperiod_end,pdepreciate,dupdate
     INTO $prdend,$dec,$Dupdate1
     FROM depreciation_rate
    WHERE fcar_class=$old_carclass and qperiod_bgn=$old_prdbgn and drate=$Drate1;

  /* if key value has been changed then SQLNOTFOUND,else put current value
     into cur_buf for comparison */ 
 if (SQLCODE == SQLNOTFOUND)
  {
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(exitsub(reply,M_CM_NOT_FOUND) == True) 
    return M_CM_NOT_FOUND;
   else  
    return apiRC;
  }
   $WHENEVER SQLERROR GOTO errexit;

		dectoasc(&dec,rate,6,2);
		rate[6]='\0';
		printf("old_Dupdate=[%s]Dupdate1=[%s]\n",old_Dupdate,Dupdate1);
 
 		/* ��H��s������ */
		/* cm_buf_init(cur_buf);
		cm_buf_put("%l",dummy);
		cm_buf_put("%c %l %l %s",old_carclass[0],old_prdbgn,prdend,rate);
		if (memcmp(cur_buf,raw_ptr,raw_len) != 0) 
		{
		 $WHENEVER SQLERROR CONTINUE;
		 $ROLLBACK WORK;
		 if(exitsub(reply,M_CM_NOT_EQUAL) == True) 
		  return M_CM_NOT_EQUAL;
		 else  
		  return apiRC;
		} */
  
		if (strcmp(old_Dupdate,Dupdate1) != 0) 
		{
				$ROLLBACK WORK;
				return M_CM_NOT_EQUAL;
		}
		 $WHENEVER SQLERROR GOTO errexit;
  
 /* equal, then exec DB operation */

 if ( option == 'D' )
  {
   for(j=0;j<i;j++)
   {
    sprintf_s(stmt_buf, sizeof stmt_buf,
         "DELETE FROM %s:depreciation_rate WHERE fcar_class=? and qperiod_bgn=? "
         "  and drate = ?" ,list[j].dbname); 
    $PREPARE d_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      break;
     }
    $EXECUTE d_id USING $old_carclass,$old_prdbgn,$Drate1;
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      break;
     }
#ifdef DEBUG 
printf("Delete %d\n", j+1);
#endif
   }/* for loop */

   if( is_del_fail ) goto errexit;
   
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }  

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else if (option == 'U')
  {
   cm_buf_init(command);
   cm_buf_get("%c %s",&option,DBName);
   cm_buf_get("%c %l %l %s %s %s",&(carclass[0]),&prdbgn,&prdend,rate,Drate2,Iupdate);
   carclass[1] = '\0';
   deccvasc(rate,6,&dec);
   strcpy(Drate, cm_to_infdate(Drate2));
	 printf("Drate=[%s]Iupdate=[%s]\n",Drate,Iupdate);
	 printf();
   $WHENEVER SQLERROR CONTINUE;
   for(j=0;j<i;j++)
   {
    sprintf_s(stmt_buf, sizeof stmt_buf, "UPDATE %s:depreciation_rate "
   		" SET (fcar_class,qperiod_bgn,qperiod_end,pdepreciate,drate,iupdate,dupdate) "
	            "  =(?,?,?,?,?,?,current) WHERE fcar_class=? and qperiod_bgn=? and drate = ?",
                      list[j].dbname);

    $PREPARE u_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      break;
     }
    $EXECUTE u_id USING $carclass,$prdbgn,$prdend,$dec,$Drate, $Iupdate,
                        $old_carclass,$old_prdbgn,$Drate1;
                        
		printf("609: Drate=[%s]Iupdate=[%s]Drate1=[%s]\n",Drate,Iupdate,Drate1);
		
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      break;
     }
    if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
     {
  	sprintf_s(stmt_buf, sizeof stmt_buf, "INSERT INTO %s:depreciation_rate "
 	" (fcar_class,qperiod_bgn,qperiod_end,pdepreciate,row_guid,drate,icreate,dcreate,iupdate,dupdate) "
	" VALUES (?,?,?,?,0,?,?,current,?,current)" ,list[j].dbname);

      $PREPARE ua_id FROM $stmt_buf;
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        break;
       }
      $EXECUTE ua_id USING $carclass,$prdbgn,$prdend,$dec,$Drate,$Iupdate,$Iupdate;
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        break;
       }
     }
#ifdef DEBUG 
printf("Update %d\n", j+1);
#endif
   } /* for loop */

   if( is_upd_fail ) goto errexit;


   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }  

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else
  {
   if(exitsub(reply,M_CM_WRONG_OPTION) == True) 
    return M_CM_WRONG_OPTION;
   else  
    return apiRC;
  } 

 errexit:
  $WHENEVER SQLERROR CONTINUE;
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True) 
   return MsgCode;
  else  
   return apiRC;
}