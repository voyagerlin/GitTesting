/**********************************************************************/
/*   program id   : ca656q01s.ec                          	          */
/*   program name : �����I���īO��γ�����Ʃ���             	      */
/*   date written : 2021/04/01                             	          */
/*   temp table   : car656           io                    	          */
/**********************************************************************/
/*                             MODIFICATION LOG                        *
 *                                                                     *
 *   DATE         SE                         DESCRIPTION               *
 * --------  -------------  ----------------------------------------   *
 **********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <decimal.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "globdata.h"
#include "safeclib.h"
char yy[04], mm[03], dd[03];

$char icar_flag[2];
$char ipolicy[21], nleader[11], dply_begin[21], dply_end[21], itag[12], icar_type[3];
$char ibrand[9], dpolicy1[21], dply2begin1[21], dentry1[21], iestimate[21], idmg_rate[3], ibrg_rate[3];
$char tmp_dentry[21], dpolicy2[21], dply2begin2[21], dentry2[21];

char  msgbuf[100];
$char dbname[21];
$char DBName[05];
int   option=0;
$char opt[2];
char  outputf[N_FILE+1], userid[06];
int     k, count_db;
DBinfo  *list;

long car656_get_db();
long car656_build();
long car656_print();

main(argc,argv)
int  argc;
char **argv;
{
   int  rc;

	batchinit();
	strcpy(DBName,    isNULLstr(argv[1]));
	strcpy(userid,    isNULLstr(argv[2]));
	strcpy(ibrand,    isNULLstr(argv[3]));      /* �t�P�����N�� */   
	strcpy(opt,       isNULLstr(argv[4]));
	option = atoi(opt);
	
	if(option == 1 || option == 3 || option == 5)
	{
		strcpy(dpolicy1,    isNULLstr(argv[5])); /* ñ��� �}�l */
		strcpy(dpolicy2,    isNULLstr(argv[6])); /* ñ��� ���� */
		strcpy(outputf,     isNULLstr(argv[7]));
	}
	if(option == 2 || option == 4 || option == 6)
	{
		strcpy(dply2begin1, isNULLstr(argv[5])); /* ��J�� �}�l  */
		strcpy(dply2begin2, isNULLstr(argv[6])); /* ��J�� ����*/
		strcpy(dentry1,     isNULLstr(argv[7])); /* ��J�� �}�l */
		strcpy(dentry2,     isNULLstr(argv[8])); /* ��J�� ���� */
		strcpy(outputf,     isNULLstr(argv[9])); 
	}

	strcpy(dpolicy1,    cm_to_infdate(dpolicy1));
	strcpy(dpolicy2,    cm_to_infdate(dpolicy2));
	strcpy(dply2begin1, cm_to_infdate(dply2begin1));
	strcpy(dply2begin2, cm_to_infdate(dply2begin2));
	strcpy(dentry1,     cm_to_infdate(dentry1));
	strcpy(dentry2,     cm_to_infdate(dentry2));

	rc = car656_get_db();
	if (rc != M_CM_OK)
		return rc;
		
	rc = car656_build();
	if ( rc != M_CM_OK )
	     return rc;

	rc = car656_print();
	if ( rc != M_CM_OK )
	     return rc;
}

long car656_get_db()
{
	$whenever sqlerror goto errexit;

	if (db_select(DBName) == FALSE) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}

long car656_build()
{
    $char stmt[4096], stmt2[4096], stmt3[4096];
    $char stmt_tmp[2048];
    $char stmp_ins[256];
    
    $WHENEVER SQLERROR GOTO errexit;
    
	if (db_select(DBName) == FALSE)
	{
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}
	
	sprintf_s(stmt_tmp, sizeof stmt_tmp,"CREATE TEMP TABLE car656  "
	                 "( "
	                 "  ipolicy         char(21), "
	                 "  iestimate		char(21), "
	                 "  nleader         char(11), "
	                 "  dply_begin      date, "
	                 "  dply_end        date, "
	                 "  itag            char(%d), "
	                 "  icar_type       char(2), "
	                 "  idmg_rate       char(3), "
	                 "  ibrg_rate       char(3) "
	                 ")with no log; ",CA_TAG_NUM-1);
	$PREPARE stmp FROM $stmt_tmp;
	$EXECUTE stmp;
	printf("stmt_tmp[%s]\n",stmt_tmp);
	
	if(option == 1 || option == 3 || option == 5) /* ���īO�� */
	{
		
		if(option == 1) /* ���餣�t�ѵs*/
			strcpy(stmp_ins,"AND d.fins_grp = '1' AND d.iri_ins <> '11' ");
		if(option == 3) /* �ѵs*/
			strcpy(stmp_ins,"AND d.fins_grp = '1' AND d.iri_ins = '11' ");
		if(option == 5) /* �����I�t��*/
			strcpy(stmp_ins,"AND d.fins_grp = '1'");
		
		for(k=0;k<count_db;k++)
		{
			sprintf_s(stmt, sizeof stmt,"INSERT INTO car656  "
			            "SELECT a.ipolicy,'', "
			            "       (SELECT nname FROM officer WHERE iofficer = a.ileader) AS nleader,  "
			            "       dply_begin,dply_end,itag,icar_type,  "
			            "       c.idmg_rate,c.ibrg_rate  "
			            "  FROM %s:ply_relation a, %s:ply_ins_type b, %s:policy c, insurance_type d  "
			            " WHERE a.ipolicy = b.ipolicy  "
			            "   AND a.ipolicy = c.ipolicy  "
			            "   AND b.iins_type = d.iins_type %s  "
			            "   AND a.dpolicy BETWEEN ? AND ?  "
			            "   AND b.mdamage_cover > 0  "
			            "   AND a.dply_end >= today  "
			            "   AND a.ibrand = ? ", list[k].dbname,list[k].dbname,list[k].dbname,stmp_ins);
			printf("stmt[%s] \n",stmt);

			$PREPARE ply FROM $stmt;
			$EXECUTE ply USING $dpolicy1, $dpolicy2, $ibrand;
		}
	}

    if(option == 2 || option == 4 || option == 6) /* ������� */
    {
    	
		if(option == 2) /* ���餣�t�ѵs*/
			strcpy(stmp_ins,"AND d.fins_grp = '1' AND d.iri_ins <> '11' ");
		if(option == 4) /* �ѵs*/
			strcpy(stmp_ins,"AND d.fins_grp = '1' AND d.iri_ins = '11' ");
		if(option == 6) /* �����I�t��*/
			strcpy(stmp_ins,"AND d.fins_grp = '1' ");

		for(k=0;k<count_db;k++) /* ���s�����Gnewa00-newa70 */
		{
			sprintf_s(stmt2, sizeof stmt2,"INSERT INTO car656  "
			             "SELECT ' ',a.iestimate,  "
			             "       (SELECT nname FROM officer WHERE iofficer = (SELECT ileader FROM officer WHERE iofficer = a.iofficer2)),  "
			             "       dply2_begin,dply2_end,itag,icar_type2,a.idmg_rate,a.ibrg_rate  "
			             "  FROM %s:estimate a , %s:est_ins_type b ,insurance_type d  "
			             " WHERE a.iestimate = b.iestimate  "
			             "   AND b.iins_type = d.iins_type %s  "
			             "   AND a.ibrand = ?  "
			             "   AND a.ipolicy2 = ''  "
			             "   AND a.dply2_begin BETWEEN ? AND ?  "
			             "   AND a.dentry BETWEEN ? AND ? ", list[k].dbname,list[k].dbname,stmp_ins);
			printf("stmt2[%s] \n",stmt2);
			
			$PREPARE est FROM $stmt2;
			$EXECUTE est USING $ibrand, $dply2begin1, $dply2begin2, $dentry1, $dentry2;
		}
		
    	/* E�O��(���t���s�������)�Gnewa00 */   	
    	strcpy(tmp_dentry,dentry1);
    	cm_split_ymd(tmp_dentry,mm,dd,yy);
    	strcpy(tmp_dentry,yy);
    	strcat(tmp_dentry,"-");
    	strcat(tmp_dentry,mm);
    	strcat(tmp_dentry,"-");
    	strcat(tmp_dentry,dd);
    	strcat(tmp_dentry," 00:00:00");
    	printf("tmp_dentry[%s]\n",tmp_dentry);
    	
		sprintf_s(stmt3, sizeof stmt3,"INSERT INTO car656  "
		              "SELECT '',a.iquote,(select nname from officer where iofficer = b.ileader),  "
		              "       dins_bgn,dins_end,a.itag,icar_type,a.idmg_rate,a.ibrg_rate  "
		              "  FROM newa00:ca_quotation a, newa00:quotation_master b, newa00:ca_quotation_ins c, insurance_type d  "
		              " WHERE a.iquote = b.iquote  "
		              "   AND a.iquote = c.iquote  "
		              "   AND a.iins_kind_ply = b.iins_kind_ply  "
		              "   AND c.iins_type = d.iins_type %s  "
		              "   AND a.dcreate >= ?  "
		              "   AND ibrand = ?  "
		              "   AND dins_bgn BETWEEN ? AND ?  "
		              "   AND b.ipolicy = ''  "
		              "   AND NOT EXISTS (SELECT iestimate FROM car656 WHERE a.iquote = iestimate)",stmp_ins);
		printf("stmt3[%s] \n",stmt3);
		
		$PREPARE quot FROM $stmt3;
		$EXECUTE quot USING $tmp_dentry, $ibrand, $dply2begin1, $dply2begin2;
    }
   
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}

long car656_print()
{
	int     rc;
	char    sfilename[1024],stitle[2048],stmt[2048];
	$int    icnt;
    
    $WHENEVER SQLERROR GOTO errexit;
    
	strcpy(sfilename,"�����I���īO��γ�����Ʃ���");
	strcpy(stitle,"�{���N��:CAR656\t");
	strcat(stitle,sfilename);
	strcat(stitle,"\t�L����:");
	strcat(stitle,cm_get_sysd());
	strcat(stitle,"\n");

	icnt = 0;
    $select count(*) into $icnt from car656;
      
	if (icnt == 0) 
	{
		sprintf_s(msgbuf, sizeof msgbuf," %s �d�L���, �ɮ׵L�k���� ",sfilename);
		EWRITE(userid, rc , msgbuf);
		return  M_CM_NOT_FOUND;
	}
    
    
    
    if(option == 1 || option == 3 || option == 5)
    {
    	strcat(stitle,"\t�O�渹\t�޲z�H�W��\t�O�I�_��\t�O�I�����\t���P���X\t���إN��\t�����I�O�v�N��\t�ѵs�I�O�v�N��\t");
		strcpy(stmt,"SELECT UNIQUE   "
		                    "ipolicy,nleader,dply_begin,dply_end,  "
		                    "itag,chr(127)||icar_type,idmg_rate,ibrg_rate    "
		               "FROM car656 ");
		 /* SQL���� chr(127), �i�H�b��EXCEL����0�������,���|���@�Ů�,�p���s�ɻݨD, ���V�ΡC*/
	}
	else
	{
		strcat(stitle,"\t�����渹\t�޲z�H�W��\t�O�I�_��\t�O�I�����\t���P���X\t���إN��\t�����I�O�v�N��\t�ѵs�I�O�v�N��\t");
		strcpy(stmt,"SELECT UNIQUE   "
		                    "iestimate,nleader,dply_begin,dply_end,  "
		                    "itag,chr(127)||icar_type,idmg_rate,ibrg_rate    "
		               "FROM car656 ");
		 /* SQL���� chr(127), �i�H�b��EXCEL����0�������,���|���@�Ů�,�p���s�ɻݨD, ���V�ΡC*/
	}
    rc = unload_file(outputf," ",sfilename,stitle,stmt);

	printf("rc[%d]\n",rc);
	
    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }
	
    return M_CM_OK;
    
errexit:
    printf("--car656_print-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}
