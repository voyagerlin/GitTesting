/*   program name : �妸�X��                                               */
/*   date written : 05/23/2017                                             */
/*   date modify  : yyyy/mm/dd                                             */
/*   1090527002-�s�W181�I�ءA��������O�]�����ݭק�car3011                 */
/*   1100419003-���I�O�����QR Code�q�l��-                                 */
/*              feterms�X��  17N�̳�����  CR-�j��BEB�@�� 0(���o�XV9���N)  */
/*   1101201016-SC2-���q��-EB�q�ʦۦ樮�}�o�q�l����                        */
/***************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <decimal.h>
#include <math.h>
#include "is_def.h"
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "carmsgs.h"
#include "carmsg.h"
#include "commsgs.h"
#include "cmnmsgs.h"
$include sqlca;
$include cmnroute.h;
$include sqltypes;
$include datetime;
#include "ca301m01.h"
#include "comdata.h"
$include "ca301lib.h";
$include "ply_ins_cover.h";
$include "var_length.h";
$include "ply_ins_assured.h";
#include "cm_ply_info.h"
#include "rinmsgs.h"
#include "cachkrule.h"
#include "spcmsgs.h"
#include "car_common.h"
#include "sqlfatal.h"
#include "safeclib.h"

/** debug �}�� (#ifdef PRINTF_FLAG) make�W�u�ɭn�����]���ѱ��Ӧ�^�A�קK�v�T����ɶ� */
#define  PRINTF_FLAG

/* global variation must define in ca301lib.h */
static        InitData();
              
int           Cal_prem_21();
int           cm_get_serial_num_dwritten();
static int    SetFactor();
static int    SetCarAge();
static int    Cal_ins_premium();
static int    Calculate_cover_prem();
static int    Insert_INS_TYPE();
static int    Insert_INS_TYPE_48();
static int    Insert_INS_TYPE_35();
static int    Insert_INS_TYPE_56();
static int    Scan_INS_TYPE();
struct        PLY_INS_COVER *get_ply_ins_cover();
struct        PLY_INS_COVER *get_ply_ins_cover_302();
struct        PLY_INS_ASSURED *get_ply_ins_assured();
long          check_broker_commi_agent();
double        dbl_len8();
double        d45();
static double MyPower();
static int    IsFcomp24();
static        InsAbnID();
static int    CheckAbnCol();
static int    DiffMonth();    /* input data should be date format */
static int    DiffDay();      /* input data should be date format */
int           IsBlankNull();
long          car3011_load_data();
long          car3011_unload_data();


/********** ca3011p01s.ec selfish function **********/
/***************************************************/
static long  Car3011_A();
static       ClearSendBackData();
/***************************************************/
char         *cm_get_sysd();
char         *get_full_dbname();
char         *cm_edate_str();
char         *trim();
char         *rtrim();
char         *get_car_full_db();
char         *cm_cdate_str_100();
char         *cm_to_infdate();
char         *cm_from_infdate_100();
char         *get_upcomp(); 
char         *equip_delete();
char         *get_db_list();
char         *equip_insert();
char         *equip_put();
char         *itoa();
char         *cm_sysd_cdatetime_100();
char         *cm_eyear_str();
char         *refmtamt();
char         *equip_get();
char*        trimx();
/***************************************************/

$double  plia_acc2_ori, pdmg_acc_ori, pdmg_acc_ori2, pdmg_acc_ori3,punknown_acc_ori,punknown_acc_ori2;
/* �ȧ��|�Ψ�H�U��ơA�O��P���� CALL Cal_prem_21�A�O��u�O�n�ŦX�Ѽƶǻ� */
/* 1�~���k�w�`�O�O, ��1�~�W��[�k�w]�~�Ⱥ޲z�O��, 1�~���O�氷�����O�I�O��, ��1�~��ñ��~�ȶO��, ��1�~���ά�o�O��*/
$double  lFirstYear_bef, tmp_mbusiness_21, maintain21, ZA_mbusiness_1, research21;
/* 2�~���k�w�`�O�O, ��2�~�W��[�k�w]�~�Ⱥ޲z�O��, 2�~���O�氷�����O�I�O��, ��2�~��ñ��~�ȶO��, ��2�~���ά�o�O��*/
$double  lSecondYear_bef, dblSy_mbusiness, secMaintain21, ZA_mbusiness_2, secResearch21;
/* 3�~���k�w�`�O�O, ��3�~�W��[�k�w]�~�Ⱥ޲z�O��, 3�~���O�氷�����O�I�O��, ��3�~��ñ��~�ȶO��, ��3�~���ά�o�O��*/
$double  lThirdYear_bef, dblSy_mbusiness_3, thirdMaintain21, ZA_mbusiness_3, thirdResearch21;
/* 4�~���k�w�`�O�O, ��4�~�W��[�k�w]�~�Ⱥ޲z�O��, 4�~���O�氷�����O�I�O��, ��4�~��ñ��~�ȶO��, ��4�~���ά�o�O��*/
$double  lFourthYear_bef, dblSy_mbusiness_4, fourMaintain21, ZA_mbusiness_4, fourResearch21;
/* 5�~���k�w�`�O�O, ��5�~�W��[�k�w]�~�Ⱥ޲z�O��, 5�~���O�氷�����O�I�O��, ��5�~��ñ��~�ȶO��, ��5�~���ά�o�O��*/
$double  lFifthYear_bef, dblSy_mbusiness_5, fifMaintain21, ZA_mbusiness_5, fifResearch21;
$double  mcover1_32;/* ����29�I�حp���:�ĥ��»s��,mcover1_32 = 0; �ĥηs��,mcover1_32=32�I�ثO�B */
/* 62,63,64�I�ضO�v�p��վ�(�[�p�O�B1) add by sylvia 101.11.23 (1011123001_C1) */
$double  mcover1_626364;/* ����626364�I�حp���:�ĥ��»s��,mcover1_626364 = 0; �ĥηs��,mcover1_626364=�O�B1 */
/* ����109�I�حp��� add by larry 102.11.22 (1021001004_C1)*/
$char qcont[3];/* barcode��ӫO�զX, 0:Ū���̷s�O����  5,8:Ū����O�J�p�� 14,15,24,25:Ū����O�J�p��(���O�X��)*/
$double  mcover1_31,ins_premium31,wk_qpt; 
/* 1050801002_C1_����~�S�w�γ~�ΩT�w�ϥΤH���[����J */
$double  ins_premium_03,bef_ins_premium_03;
$double  mpure_prem_n,mpure_prem_n_03; 
$double  pcar_price_1;

$int     *fstate,icnt_105;
$int     car_age150151,car_age_year,Provision_Z_150;                                      /* 1050801007_C1_GKGT�s�ӫ~�t�λݨD */

$char    deffect[5], dsign[11],iassuredIsEqual[2],comp_fassured[2],icont[2],frenew_type[3];                       /* 1:�۵M�H, 2:�k�H */                                                                      /* barcode��ӫO�զX, 0:Ū���̷s�O����  5,8:Ū����O�J�p�� 14,15,24,25:Ū����O�J�p��(���O�X��)*/
$char    userid[EMPLOYEE_ID],frate[5], sTmp105[500], ire_ply[21], ipgid[7] = " " , DBName[5] ,txtfile[101] ;
$char    ffname[101] ,getfile[300] ,option[2] ,stmp[2048] ,errMsg[2048] ,ncode[101] ,sgliaclass[3] ,outputf1[50];
$char    v_errMsg[5000];
$char    ilicense_302[11]=" ",icar_type_302[3]=" ";
$int     flag58;
$char    sNquota[41];
$int     dmg_acc_Insert = 0; /* BUG-20181225�B�zF���ڨ���Y�Ƭ����k0�٭�P�_��*/

$int     iMaxDrate,iPlyYmChk;/* 1061026002-�O�v�N��88->89*/
$char    sfagency[2],sIscan_no[26],sIunder[11],sDunder[11],sDunderTime[21],sFappend[2];/*1060817004-C1 �q�lñ�p *//* 1101018008-SC1-�d����-�q�lñ�ݱ��y�s������X�W��25�X*/
$char    sfauto[2];/* 1070108012 -SC2 -���z�s���P�C���ɶǿ�վ� */
$char    isign_batch_car[11],isign_batch_oth[11];/*1070531010-SC1-�����۰ʥX��*/
char     v_sMsg[3000], fcalc[2];                                                         /* 1:�O�O�p��A2:�s�ɨ��o�պ⸹ */;
char     sMsg[3000], sMsg2[3000], sApHome[50],sColumn[21], sTable[21], sTable2[21], sDbname[21], sTable1[21];
char     err_sMsg[3000],chk_errmsg[3000];                                                /* ����ˮֵ{�������~�X Modified by Julia Han in 2007/07/30 */
char     haveF[2],bzfrom[3],fcheck[2];                                                   /* fcheck==Y�ˮֱj���I��������O, N:���ˮ� */
char     delimiter,errmsg_tmp[3000], errmsg_chk[10],sNeedChkCar[2],sTpdb[21],GetPlyInsMain[7];
char     fNewCompBusi[2];                                                                /* 1050812001_C2 �j���I�����~���u�f (�s����G"1" ;�±���G"0") */
char     g_frenew_type[3]=" ";
char     iassured_cntry_rba[2]= " ",iapplicant_cntry_rba[2]= " ";
static char  *bp;
$char    Msg[1024];
long     rtncode;
long     lngPrem05,lngPrem152,lngCover152;
long     lngPrem161,lngCover161;/* 1070212002-SC1 0301�O�v�վ�0501�ͮ� 93�O�v+161+162(�ˮ֤��152+153�A�O�O���98)*/
$double  dbl_ProP_main_dmg,dbl_ProQ_main_dmg,dbl_ProP_main_brg,dbl_ProQ_main_brg,NewYearDep;/*1071226006-SC1-��ã��-�w���ƫ����վ�(���²v+�ĤT�H�d��)*/
$double  dbl_ProM_main_dmg,dbl_ProM_main_brg;/* 1081105005-SC1-��ã��-�ק���~���w���ƫ������²v�Φۭt�B(M����)*/
$double  dbl_ProK_main_dmg;/* 1080408008-SC1-��ã��-98������09+K*/
$double  dbl_ProD_main_dmg;/* 1080815003-SC1-��ã��-�ק靈���[H�BD���ڭp�⤽��-���PQK*/
$double  dbl_ProH_main_dmg,dbl_ProH_main_lia;/* 1080815003-SC1-��ã��-�ק靈���[H�BD���ڭp�⤽��-���PQK*/
$double  dbl_ProF_main_dmg,dbl_ProF_main_brg,dbl_ProF_main_lia; /*1110317002_SC3_�ק�F���ڥi�ϥΤ��I�ؤΫO�O�p��վ�ηs�Wcar140�I�غ��@�]�w*/
$int     irate_ProF_main_dmg,irate_ProF_main_brg,irate_ProF_main_lia;
$double  dbl_ProY_main_dmg;/*1130827011_C02_�s�W�s�t��W�B���[����(Y)�A�Щ�11/1�W�u*/
$long    lngCover161_last;/* 1070531004-SC1-��ã��-�ק���sCAR301�A09+162��05+161��O���ˮ�*/
$char    *sChkProvTok,*sChkInsProvTok;/*1090708005-SC1-���ά�-�ˮ֪��[������줧���T��*/
$int     iChkProvision;/*1090708005-SC1-���ά�-�ˮ֪��[������줧���T��*/
$char    sChkProvMain[2049];/*1090708005-SC1-���ά�-�ˮ֪��[�������*/
$char    tmp_fulldb[21],stmt[1024];
char     drate_ym_sql[5];
static int   recLen=1024;
int      offset;
int      i;
int      qcount=0;
FILE     *sfp,*fp;


main(argc, argv)
int argc;
char **argv;
{
    batchinit();
    strcpy(localdb         ,isNULLstr(argv[1]));
    strcpy(examiner        ,isNULLstr(argv[2]));
    strcpy(sIbranchIcomp   ,isNULLstr(argv[3]));
    strcpy(isign_batch_car ,isNULLstr(argv[4]));
    strcpy(isign_batch_oth ,isNULLstr(argv[5]));
    strcpy(txtfile         ,isNULLstr(argv[6]));
    strcpy(outputf1        ,isNULLstr(argv[7]));
    
    strcpy(userid,trim(examiner));      /*** ��J�H�� ***/
    strcpy(entry,trim(examiner));
    strcpy(isign_batch_car,trim(isign_batch_car));
    strcpy(isign_batch_oth,trim(isign_batch_oth));

    printf("txtfile[%s]\n",txtfile);

    InitData();
    rtoday(&Today);     /* get today's datetime */

    if (db_select(localdb) == False)
    {
        EWRITE(userid,M_CM_DB_NOTOPEN,"M_CM_DB_NOTOPEN");
        return 0;
    }

    rtncode = getApHome(sApHome);
    if (rtncode < 0)
    {
        EWRITE(userid, M_CM_READ_CONFIG_ERR, "read Config file error!!");
        return FAIL;
    }
    
    /*** �Ntxt�����Jtmp table ***/
    rc=car3011_load_data();
    if (rc != M_CM_OK)
    {
        printf("[���楢��]\n");
        strcpy(stmp,"car3011_load_data ���楢�� ");
        /*strcat(stmp,errMsg);*/
        EWRITE(userid,rc,stmp);
        return rc;
    }
     
    strcpy(sChkProvMain,"");/*1090708005-SC1-���ά�-�ˮ֪��[������줧���T��*/
    /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X */
    $SELECT FIRST 1  replace(replace(replace(replace(replace( multiset
                    (SELECT trim(iprovision)||';' FROM ca_provision_main  
                      WHERE (dactive_sys <= today  OR dactive_sys IS NULL)         
                        AND (dexpire_sys >  today  OR dexpire_sys IS NULL)
                        AND (dexpire >  today -10 OR dexpire IS NULL)
                    )
                   ::lvarchar,'MULTISET{',''), 'ROW(''',''),''')',''),'}',''),',','')
       INTO $sChkProvMain
       FROM ca_provision_main;
    strcpy(sChkProvMain,trim(sChkProvMain));
    /*printf("ca_provision_main-sChkProvMain[%s]\n",sChkProvMain);*/
    v_errMsg[0] = "\0";
    
    if (g_frenew_type[0]=='9' || g_frenew_type[0]=='6')
    {
        /* ����֫O�� 17N �� ���X��*/
        rc=Car3011OptQL(1);
        if (rc != M_CM_OK)
        {
            printf("[���楢��]\n");
            strcpy(stmp,"Car3011OptQL ���楢�� ");
            EWRITE(userid,rc,stmp);
            return rc;
        }   
    }
    else if (g_frenew_type[0]=='5')
    {
        /* �j�����q���� CVQ */
        rc=Car3011_R5();
        if (rc != M_CM_OK)
        {
            printf("[���楢��]\n");
            strcpy(stmp,"Car3011_R5 ���楢�� ");
            EWRITE(userid,rc,stmp);
            return rc;
        }    
    }
    else
    {
        /* ��O���۰ʥX��� CR  */
        rc=Car3011_R2();
        if (rc != M_CM_OK)
        {
            printf("[���楢��]\n");
            strcpy(stmp,"Car3011_R2 ���楢�� ");
            EWRITE(userid,rc,stmp);
            return rc;
        }    
    }    


    rc=car3011_unload_data();
    if (rc != M_CM_OK)
    {
        printf("[���楢��]\n");
        strcpy(stmp,"car3011_unload_data ���楢�� ");
        EWRITE(userid,rc,stmp);
        return rc;
    }

    printf("return success\n");

    return SUCCESS;
}

void GetData(data, maxlen, delimiter)
char *data, delimiter;
int maxlen;
{
    int fori, pre_offset, cnt=0;

    data[0]='\0';
    pre_offset = offset;

    for (fori=pre_offset; bp[fori]!=0x00&&bp[fori]!=0x0d&&bp[fori]!=0x0a&&bp[fori]!=delimiter; fori++)
    {
        offset++;
        if (cnt < maxlen-1)
        {
            data[cnt]=bp[fori];
            cnt++;
        }
    }

    offset++; /* ���ܤU�@�� */
    if (cnt==0) data[cnt++]=0x20; /* �L��Ƶ��ť� */
    data[cnt]=0x00;
    /*printf("pre_offset[%d]offset[%d]len[%d]data[%s]\n", pre_offset, offset, cnt, data);*/
}

long car3011_load_data()
{
    $char iestimate[21],t_frenew_type[3],ilast_ply[21],itag[13],t_icont[2];
    $char iofficer[11],iofficer1[11],nofficer[51],nleader[51],nassured[121],dcoll_last[11];
    $char dacc_last[11],dply_begin[11],duw_status[3],s_macc[10];
    $char ipolicy[21],iscan_no[26];/* 1101018008-SC1-�d����-�q�lñ�ݱ��y�s������X�W��25�X*/
    $int  macc;

    EXEC SQL WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT 10;

    printf("sApHome[%s]\n",sApHome);
    /*printf("txtfile[%s]\n",txtfile);*/
    sprintf_s(getfile,sizeof getfile,"%s/dat/car/%s",sApHome,txtfile);
    printf("getfile[%s]\n",getfile);

    if ((fp=fopen(getfile,"rt"))==NULL)
    {
        return FAIL;
    }

    if ((bp=malloc(recLen))==NULL)
    {
        printf("System malloc failed  !\n");
        return FAIL;
    }

    /* ���j�Ÿ� */
    delimiter = '\t';
    $EXECUTE IMMEDIATE "DROP TABLE IF EXISTS car3011_temp";
    $CREATE TEMP table car3011_temp
    (
        iestimate       char(20),                  /*�����渹*/
        frenew_type     char(1),                   /*��O����*/
        ilast_ply       char(20),                  /*��O�渹*/
        itag            char(12),                  /*���P���X*/
        icont           char(1),                   /*�ӫO���e*/
        iofficer        char(10),                  /*�g��N��*/
        nofficer        char(50),                  /*�g��W��*/
        ileader         char(10),                  /*�޲z�H�N��*/
        nleader         char(50),                  /*�޲z�H�W��*/
        iassured        char(12),                  /*�Q�O�I�H�N��*/
        nassured        char(120),                 /*�Q�O�I�H�W��*/
        iquota          char(6),                   /*�~�Z���N��*/
        nquota          char(40),                  /*�~�Z���W��*/
        macc            int,                       /*ú�ڳ��`�O�O*/
        dcoll_last      date,                      /*ú�ڤ�*/
        dacc_last       date,                      /*�J�b��*/
        dply_begin1     date,                      /*�ӫO�_��(�j��)*/
        dply_begin2     date,                      /*�ӫO�_��(���N)*/
        duw_status      char(2),                   /*�O�_�w�X��*/
        fout            char(2),                   /*�e�~�C�L(Y/N)*/
        feply           char(2),                   /*�q�l�O��(Y/N)*/
        ipolicy1        char(20)   default ' ' ,   /*�j��O�渹�X*/
        ipolicy2        char(20)   default ' ' ,   /*���N�O�渹�X*/
        icard1          char(20)   default ' ' ,   /*�j��d��*/
        icard2          char(20)   default ' ' ,   /*���N�d��*/
        sMsg            char(5000) default ' ' ,   /*�ˮ�/�����T��*/
        iscan_no        char(25)                   /*1060817004-C1 �q�lñ�p ���y�Ǹ�*//* 1101018008-SC1-�d����-�q�lñ�ݱ��y�s������X�W��25�X*/
        
    )with no log;
    $CREATE INDEX idx_car3011_temp1 ON car3011_temp (iestimate); /* �t�X�W�[INDEX */
    $CREATE INDEX idx_car3011_temp2 ON car3011_temp (ilast_ply); 

    while(fgets(bp,recLen,fp))
    {
        if (feof(fp)) break;
        offset = 0;

        /* ��ƨ��o���Ǥ��i�ܰ� */
        GetData(iestimate,                  sizeof(iestimate),      delimiter);
        GetData(t_frenew_type,              sizeof(t_frenew_type),  delimiter);
        GetData(ilast_ply,                  sizeof(ilast_ply),      delimiter);
        GetData(itag,                       sizeof(itag),           delimiter);
        GetData(t_icont,                    sizeof(t_icont),        delimiter);
        GetData(iofficer,                   sizeof(iofficer),       delimiter);
        GetData(nofficer,                   sizeof(nofficer),       delimiter);
        GetData(nleader,                    sizeof(nleader),        delimiter);
        GetData(nassured,                   sizeof(nassured),       delimiter);
        GetData(s_macc,                     sizeof(macc),           delimiter);
        GetData(dcoll_last,                 sizeof(dcoll_last),     delimiter);
        GetData(dacc_last,                  sizeof(dacc_last),      delimiter);
        GetData(dply_begin,                 sizeof(dply_begin),     delimiter);
        GetData(duw_status,                 sizeof(duw_status),     delimiter);
        GetData(iscan_no,                   sizeof(iscan_no),       delimiter);/*1060817004-C1 �q�lñ�p ���y�Ǹ�*/
        
        strcpy(iestimate,trim(iestimate));
        strcpy(t_frenew_type,trim(t_frenew_type));
        strcpy(ilast_ply,trim(ilast_ply));
        strcpy(itag,trim(itag));
        strcpy(t_icont,trim(t_icont));
        strcpy(iofficer,trim(iofficer));
        strcpy(nofficer,trim(nofficer));
        strcpy(nleader,trim(nleader));
        strcpy(duw_status,trim(duw_status));
        macc = atoi(s_macc);
        
        strcpy(g_frenew_type, t_frenew_type);

        $insert into car3011_temp
         values ($iestimate,$t_frenew_type,$ilast_ply,$itag,$t_icont,$iofficer,$nofficer,
                 ' ',$nleader,' ',$nassured,' ',' ',$macc,$dcoll_last,$dacc_last,null,null,$duw_status,
                 ' ',' ',' ',' ',' ',' ',' ',$iscan_no);    /*1060817004-C1 �q�lñ�p ���y�Ǹ�*/

        memset(bp, ' ', recLen);
    }
    fclose(fp);

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

static Car3011_R2()
{
    long    code;
    $char   stmt[2048],stmt1[4096],TMP_MSG[512];
    char    dbsite2[3], FullDBName2[20];
    char    FullDBName2_rel[20];
    char    rmt_db[3],rmt_dbname[20];
    char    rel_dbname_1[20];
    $double plia_acc;
    $double psex_age_1, plia_acc_1, pdmg_acc_1,punknown_acc_1;
    char    yy0[5], mm0[3], dd0[3];
    char    yy[5], mm[3], dd[3];
    /*********************************************************/
    $char   lia_class_last[4];       /*** ���d�I�e���ż�     ***/
    $int    qdmg1, qdmg2, qdmg3;     /*** ���l�I���~�ߴڦ��� ***/
    /*********************************************************/
    $char   lia_class_last_tmp[4], drate_ym[5];
    $int    qdmg1_tmp, qdmg2_tmp, qdmg3_tmp;
    $char   str_freason[2];
    $int    yy1,tmp_iym_end;
    char    abn_buf[1000],iym_end[6],tmp_dply_end[10];
    $char   fagent[2],tmp_last_ply[POLICY_NUM_1],t_ipolicy1[POLICY_NUM_1];
    $char   t_ipolicy2[5],fcomp_class[3],ipay_way[2];
    $char   tmp_pfix_agent[10];
    $char   tmp_resource[3];
    $char   last_frate_comp[5]=" ", last_frate_volu[5]=" ";
    long    qdmg[3],qlia[3];
    long    mdmg[3],mlia[3];
    $long   qlia_acc,qdmg_acc;
    char    inumber[CA_ENGINE_NUM],fyear[4];
    int     frenew,rt_Kind,fambulance;
    $char   broker_tmp[11];
    int     ins33_flag, ins48_flag, ins35_flag, ins56_flag, ins136_flag, ins166_flag, ins266_flag;
    $int    iCount, iCount302_56;
    $double DblDummy = 0.00;
    $long   LngDummy = 0;
    $char   StrDummy[2];
    $double Total_comm_agt_rate = 0.00, pdiscount;
    $char   icar_type_t1[3], sTmp[512];
    $char   local_dbname[20], iyear[2];
    char    sDbirth[11], sDply_begin[11];
    int     adj_year;
    /* 'car9610231��~�βĤT�H�f�B�~���[���� */
    $double safe_rate;
    $double manage_rate;
    $double educated_rate;
    /* �«O�O�����v */
    $double deviation_rate;
    $double pextra_charge;/* ���[�O�βv */
    $double pbusiness;     /* �~�޶O�βv */
    $double psex_age;     /* �I�ةʧO�~�֫Y�� */		
    $char   tmp_iquery[17],tmp_last_card[CARD_NUM];   /* ��m��O�����T�Y�� */
    $double pshipping;    /* car9808043 �f�B�~���[����C */
    /* �q���ĤG���q�� */
    long    rcs, rcs_1, rcs1, rcs2;
    $struct cm_route_comm o_stcomm;
    int     o_qrec = 0;
    $char   sIcode[2];
    $char   cus_email[51], cus_tel_night[21], cus_mobil_phone[21];/* �ȪA��P��email */
    /* barcode ��O�� */
    $date   d302_begin,d302_end;
    $int    d302_period, icnt_302, icount_90;
    $char   i302_relative_ply[20],chk_relative[2], xDrate[11],execPly[21],icorps_302[11];
    double  mother_busi,dbl_mservice;
    char    icheck_busi[2], icheck_mservice[2];
    $date   dcoll_last;

    /* �t�X�������T�Y�Ʃ���T��(01,08�B05,09,85),������ĳ��O�զX�έ��O�զX�G��
       add by sylvia 102.11.15 */
    $int    qdmg_acc_sum_ori, qdmg_acc_sum_sug, count_dmg;
    $char   iquery_num_damage_ori[17],iquery_num_damage_sug[17];

    /* �s�r���� add by sylvia 103.01.10 (1020801002_C1) */
    /* ���j�H�W���� add by 061476 111.06.14 (1110608012_SC1) */
    $long   Qmdrunk_prem, Qmviolate_prem;
    $double Qmdrunk_pure_prem, Qmviolate_pure_prem;
    $int    Qdrunk_c, Qdrunk_v, Qviolate_c, Qviolate_v;
    
    $int    ftrans_check;
    $char   q_drate_ym_ply[21],fChk[2]=" ";
    $char   stmt_buf[513];
    $int    busi_discount=0; /* xxx*/
    $char   irate_type_302[2]=" ",iofficer_302[11]=" ",iroute_comm_302[3]= " ",tmp_car_type[3]=" ";
    $char   sIregFlag[2],sIcomm_qry[11],sTmpIregNo[21],sChkIregNo[2];/* 1080408005-SC1-��ã��-�j���һ{�ҷs�W�q����Ƥεn���Ҹ� */
    $WHENEVER SQLERROR GOTO opt1_R2_err;

    fuw_status = 500;
    stmt[0]='\0';

    strcpy(local_dbname, get_full_dbname(localdb));

    $EXECUTE IMMEDIATE "DROP TABLE IF EXISTS TMP_IINS";
    $CREATE TEMP TABLE TMP_IINS
    (   
        iins_type                           char(6),
        minjured_cover      integer         default 0,
        mdeath_cover        integer         default 0,
        mdamage_cover       integer         default 0,
        mdeduct             integer         default 0,
        mins_premium        integer         default 0,
        mpure_prem          DECIMAL(10,4)   default 0,
        pagent              DECIMAL(4,2)    default 0,
        pcommission         DECIMAL(4,2)    default 0,
        pdiscount           DECIMAL(4,2)    default 0,
        qday                INTEGER         default 0,
        mexpense            INTEGER         default 0,
        drate_ym            CHAR(4)         default ' ',
        qserial             SMALLINT        default 0,
        mprem               INTEGER         default 0,
        provision           CHAR(21)        default ' ',
        mdiscount           INTEGER         default 0,
        safe_rate           DECIMAL(6,4)    default 0,
        manage_rate         DECIMAL(6,4)    default 0,
        educated_rate       DECIMAL(6,4)    default 1,
        deviation_rate      DECIMAL(6,4)    default 0,
        pextra_charge       DECIMAL(6,4)    default 0,
        pbusiness           DECIMAL(6,4)    default 0,
        psex_age            DECIMAL(15,12)  default 1,
        pshipping           DECIMAL(6,4)    default 1
    )with no log;
    $CREATE INDEX idx_TMP_IINS1 ON TMP_IINS (iins_type);

    printf("Car3011_R2\n");
    
    /*1060817004-C1 �q�lñ�p sIscan_no*/
    sprintf_s(stmt,sizeof stmt," SELECT ilast_ply,iestimate,icont,frenew_type,dcoll_last,nvl(iscan_no,'') "
                               "   FROM car3011_temp WHERE iestimate matches '*CR*' ");

    $PREPARE CURTMP1 FROM $stmt;
    $DECLARE curtmp CURSOR WITH HOLD for CURTMP1;
    $OPEN curtmp;
    while (1)
    {
        InitData();/* 1090117010-SC1-��ã��-�ק�CAR301��Ưd�s���D*/
        $FETCH curtmp INTO $last_ply,$estimatei,$icont,$frenew_type,$dcoll_last,$sIscan_no; /*1060817004-C1 �q�lñ�p */
        if (NOT_FOUND) break;

        printf("last_ply[%s]estimatei[%s]\n",last_ply,estimatei);

        strcpy(rmt_dbname, get_car_full_db(last_ply));

        
        /*�ҡBCR�����椧�ȥ��O��u�q�l���ڡv���O�B�z�G
            i.���e��J���< 07/01/2021(�J�p��i�ήĴ��P�_)
              �B�J�p��� 07/01/2021 �ȥ��O�椧�u�q�l���ڡv���O�����q���@�߹w�]��1�q�l���ڡC
              �B�J�p��<  07/01/2021 �ȥ��O�椧�u�q�l���ڡv���O�����q���@�߹w�]��0�ȥ����ڡC 
              ->�]���w�g�l�H�X�h���S�������q�l���ڡA�u�i�ȥ��A�åB�G���J�p�u�|��j���|�����N�I
            ii.�e��J���� 07/01/2021�A�u�Ϋe�椧�̷s�O���ɡu�q�l���ڡv���O�C  -->2021/07�J�p2021/09�A�ҥH���Ĵ��P�_
            iii.�j���I�@�ߵ��O��0�FCR�w���i�XV9���N�I�C 
          �A�BEB�q�ʦۦ樮�BVW�O�T��������B�O��@�߬��ȥ��O��+�ȥ����ڡF�p�ݽվ�A��U�@���q�A�i��C
            2022/12/05 �_�����q�l���ڡAfeterms�@�ߩ�0 (1111005011_SC1) */
        /*   1101201016-SC2-���q��-�q�ʦۦ樮�}�o�q�l����-->car301�HCR������a�J��ƮɡA�����q���@�ߨϥ���O�J�p�ɪ������A���t��վ�� */

        sprintf_s(stmt1,sizeof stmt1,
                      "SELECT a.icard, a.fcard_class, a.irelative_ply, a.inext_ply, "
                      "       a.ibroker, a.icorps,"
                      "       a.iarea, a.iresource, a.drenew_print, a.dtransfer, a.fedr_class,"
                      "       a.ibig_branch, a.ibig_office, a.ibig_sales,"
                      "       a.ipro_year, a.ibrand, a.icar_type,"
                      "       a.qply_period, a.dply_begin, a.dply_end,"
                      "       a.fcomp_class, a.fdiscount, a.ipay_way,"
                      "       b.ixxcard, b.fassured, b.iassured, b.iassured_ext,"
                      "       b.nassured, b.ilicense, "
                      "       b.fsex, b.fmarriage, b.nuser, b.ibenef, b.nbenef,"
                      "       b.aassured, b.aassured_zip, b.itel, b.iply_area,"
                      "       b.apayment, b.apayment_zip, b.nbrand_abbr, b.fcar_note, b.qcylinder,"
                      "       b.iengine, b.ibody, b.itag, b.mcar_price, b.nequipment, b.iabn_type, b.fcal_way,"
                      "       b.qpt, b.fpt,"
                      "       b.plia_acc, b.pdmg_acc,"
                      "       b.lia_class, b.dmg_acc_1st, b.dmg_acc_2nd, b.dmg_acc_3rd,"
                      "       b.fhuman, b.fcomp_24, b.itel_night, b.mobil_phone, b.iemail,  a.iinstall, "
                      "       b.iext_policy, b.qpro_month, b.mkilo_ply, b.irisk, b.irelative_ext, "
                      "       b.napplicant, b.dbirth, b.dissue, "
                      "       b.iextra_charge, b.gextra_charge, b.pextra_charge, "
                      "       b.introducer, b.mequipment, "
                      "       b.survey_num, b.bound_num, b.abnormal_num, b.iapplicant, "
                      "       b.iroute_prop, b.iroute_accept, b.idm_number, b.iroute, "
                      "       a.irate_type, a.bzfrom, a.icomm_obj, "
                      "       b.fapplicant, b.fsex_appl, b.dbirth_appl, b.itel_appl, "
                      "       b.ndeputy_appl, b.nrelation_appl, b.ndeputy_assured, a.isecond_hand, "
                      "       a.icard_main, a.qdrunk_driving,a.fout_print, a.fmail_type,a.icomp_cartype_last,a.isign ,b.ibound,b.isurvey, "
                      "       b.npost_recipient,b.apost_zip,b.apost_address,b.iins_kit,b.mcover_limit ,b.iassured_cntry , b.iapplicant_cntry, b.nassured_cntry, b.napplicant_cntry, "
                      "       b.foccup, b.applicant_foccup, b.noccup, b.applicant_noccup,"
                      "       b.funknown_dmg,b.fequipment1,b.fequipment2,b.fequipment3,b.fequipment4,b.fequipment5,b.fequipment6,b.fequipment9,b.nequipment9,a.feply, "
                      "       (CASE WHEN a.ipolicy[6,7] IN ('EB') AND a.dcreate::DATE <'04/01/2022'  THEN ' ' "
                      "             WHEN a.fcard_class='2' AND a.feply <> '1'  AND a.ipolicy[6,7] NOT IN ('EB','VW') AND a.dcreate::DATE <'07/01/2021' AND a.dply_end >='09/01/2021' THEN '1' "
                      "             WHEN today >= '12/05/2022'  THEN '0' "
                      "             ELSE feterms END ),  a.aemail_eply,a.tmobile_eply, "
                      "       b.punknown_acc,a.icar_flag, b.tmobile_appl, b.aemail_appl,a.ireg_no, a.qviolate"
                      "  FROM ply_relation a, policy b"
                      " WHERE a.ipolicy = b.ipolicy AND a.ipolicy = ? ");

        /*printf("Car3011_R2:stmt[%s]\n",stmt1);*/

        $PREPARE CURstm1 FROM $stmt1;
        $DECLARE cur_R21 CURSOR FOR CURstm1;
        $OPEN    cur_R21 using $last_ply;
        $FETCH   cur_R21 INTO $last_card, $fcard_class, $irelative_ply, $inext_ply, 
                              $broker, $sIcorps,
                              $area, $resource, $drnw_print, $dtransfer, $fedr_class,
                              $big_branch, $big_office, $big_sales,
                              $pro_year, $brandi, $car_typei,
                              $qply_period, $dply_begin, $dply_end,
                              $fcomp_class, $fdiscount, $ipay_way,
                              $xxcard, $assuredf, $assuredi, $assuredi_ext,
                              $assuredn, $license,
                              $sex, $marriage, $user, $benefi, $benefn, $assureda,
                              $assureda_zip, $tel, $ply_area,
                              $paymenta, $paymenta_zip, $brandn, $fcar_note, $cylinder,
                              $engine, $body, $tagnum, $car_price, $equipment, $abn_type, $cal_way,
                              $qpt, $fpt,
                              $plia_acc, $pdmg_acc,
                              $lia_class_last_tmp, $qdmg1_tmp, $qdmg2_tmp, $qdmg3_tmp,
                              $fhuman, $fcomp_24, $tel_night , $mobil_phone, $iemail, $iinstall,
                              $iext_policy, $qpro_month, $mkilo_ply, $irisk, $irelative_ext,
                              $napplicant, $dbirth, $dissue,
                              $iextra_charge, $gextra_charge, $pextra_charge,
                              $introducer, $mequipment,
                              $survey_num, $bound_num, $abnormal_num, $iapplicant,
                              $iroute_prop, $iroute_accept, $idm_number, $iroute,
                              $irate_type, $bzfrom, $icomm_obj,
                              $fapplicant, $fsex_appl, $dbirth_appl, $itel_appl,
                              $ndeputy_appl, $nrelation_appl, $ndeputy_assured, $isecond_hand,
                              $icard_main, $qdrunk_driving,$fout_print, $fmail_type,$icomp_cartype_last,$isign,$ibound_x,$isurvey_x,
                              $npost_recipient, $apost_zip, $apost_address,$iins_kit, $mcover_limit ,$iassured_cntry , $iapplicant_cntry, $nassured_cntry, $napplicant_cntry,
                              $foccup, $applicant_foccup, $noccup, $applicant_noccup,
                              $funknown_dmg,$fequipment1,$fequipment2,$fequipment3,$fequipment4,$fequipment5,$fequipment6,$fequipment9,$nequipment9,$feply,$feterms,$aemail_eply,$tmobile_eply,
                              $punknown_acc,$icar_flag, $tmobile_appl, $aemail_appl,$sIreg_no,$qviolate;
                                    
        if (NOT_FOUND) 
        {
            $FREE  cur_R21;
            sprintf_s(v_errMsg,sizeof v_errMsg,"����O���Ƥ��s�b;");
            Update_car3011_temp(estimatei, "1", " ", " ", " ", " ", " ", " ", " ", v_errMsg);
            continue;
        }  
        $CLOSE cur_R21;
        $FREE  cur_R21;
                
        /*------------------ ��l�ܼ� �� ----------------------*/ 
        strcpy(sTmp,"");
        busi_discount = 0;         /* �j���I�����B */ 
        ply1f = FALSE;             /* �O�_���j���I */ 
        ply2f = FALSE;             /* �O�_�����N�I */
        abn_type[0]='\0';          /*��O��,abn_type�M���ť�*/
        strcpy(qprovision, "0");   /*��O��, ���w�r�p�H��(qprovision) = 0 add by sylvia 101.06.18 */
        strcpy(npost_recipient, " ");   strcpy(apost_zip, " ");             strcpy(apost_address, " ");
        strcpy(iofficer_prmt, " ");     strcpy(iquota_prmt," ");            strcpy(ileader_prmt," ");           strcpy(itmp_policy,estimatei);
        strcpy(chk_relative," ");       strcpy(i302_relative_ply," ");      strcpy(ilicense_302," "); /* 10307116,fix ���ochk_relative���޿�,�ê�l�Ƭ����ܼ� */
        strcpy(card2," ");              strcpy(icorps_302," ");     
        strcpy(officer1    , " ");      strcpy(car_typei1   , " ");         strcpy(bzfrom1     , " "); 
        strcpy(officer2    , " ");      strcpy(car_typei2   , " ");         strcpy(bzfrom2     , " "); 
        strcpy(irate_type1 , " ");      strcpy(iroute_comm1 , " ");         strcpy(icomm_obj1  , " "); 
        strcpy(irate_type2 , " ");      strcpy(iroute_comm2 , " ");         strcpy(icomm_obj2  , " ");
        strcpy(sIreg_no," ");           strcpy(sIregFlag ,"N");             strcpy(sIcomm_qry," ");             strcpy(sTmpIregNo," ");/* 1080408005-SC1-��ã��-�j���һ{�ҷs�W�q����Ƥεn���Ҹ� */
        ply2_begin=ply2_end=ply1_begin=ply1_end=0;
        ply1_period=ply2_period=0;
        fag01 = 0;
        strcpy(fcomp_24, "N");          premium1_24 = 0;

        Icurr=Ifirst=Ilast=NULL;             /* set INS_TYPE pointer to NULL */
        Icurr_33=Ifirst_33=Ilast_33=NULL;    /* set INS_TYPE_33 pointer to NULL */
        Icurr_48=Ifirst_48=Ilast_48=NULL;
        Icurr_35=Ifirst_35=Ilast_35=NULL;
        Icurr_56=Ifirst_56=Ilast_56=NULL;    
        IcurrPlyInsCover=IfirstPlyInsCover=IlastPlyInsCover=NULL;
        

        /*------------------ ��l�ܼ� �� --------------------*/ 
        strcpy(body   , rtrim(body));
        strcpy(engine , rtrim(engine));
        strcpy(assuredi  , trim(assuredi)); 
        strcpy(iapplicant, trim(iapplicant));    
        
        /* �ˮ���O��ID�P�̷s�O���ɬO�_�۲�,���Ŷ��^�ǰT�� */
        /* 1080408005-SC1-��ã��-�j���һ{�ҷs�W�q����Ƥεn���Ҹ� 
            A.�O�o�q��10(KB��)-�θg��N���dofficer(�g��H�����)���I����H�d�~�ȭ��n���M����cm_salesman_log.icomm_obj���oilicence
            B.�O�o�q��10(�DKB-���u��)+�O�o�q��40�A�|�H�X��ɥθg��N���dofficer(�g��H�����)���޲z�H�N���d�~�ȭ��n���M����cm_salesman_log.icomm_obj���oilicence
            C.��L�q��20.30���n���Ҹ��X�A�h�H��O�����ɬ�������O�����ɵn���Ҹ��a�J�C
        */
        /* 1080703003-SC1-�s�W�ϥΦ�ʧ�O�i��i�߰e�P����BA16687863�Y�x�O�g���u���z�s���v��T  */
        /* 1100701001-SC1-�B�Q��-�HCR������a�J��ƮɡA�ȥ��O��u�q�l���ڡv���O���A�����q���@�ߨϥ���O�J�p�ɪ�����*/
        $SELECT ilicense, qply_period, dply_begin, dply_end, irelative_ply,
                nvl((select 'Y' from policy_302 where ipolicy = a.irelative_ply
                        and ilicense = a.ilicense and year(dply_begin) = year(a.dply_begin)
                and month(dply_begin) = month(a.dply_begin)),'N'),isecond_hand,
                (CASE WHEN a.iroute  matches 'BA16687863*' THEN
                          (SELECT UNIQUE nvl(c.iapply_no,'') FROM cm_pre_receive b,cm_insured_app c
                            WHERE b.ipre_rcv = c.iquote AND b.dupload_esign IS NOT NULL
                              AND b.ipre_rcv = $estimatei)
                     ELSE a.iroute_accept END),
                bzfrom,bzfrom,iofficer,
                iroute,irate_type,iroute_comm,icar_type,ibig_sales,introducer,icorps,
                (CASE WHEN iroute[1,4]='KBTA' THEN 'A' WHEN bzfrom[1]='1' AND iroute[1,2]='KB' THEN 'A' WHEN bzfrom[1] IN ('1','4') THEN 'B' ELSE 'C' END ),ireg_no,feterms
           INTO $ilicense_302, $d302_period, $d302_begin, $d302_end, $i302_relative_ply,
                $chk_relative, $isecond_hand , $iroute_accept,$iextra_charge,$bzfrom,$iofficer_302,
                $iroute,$irate_type_302,$iroute_comm_302,$icar_type_302,$big_sales,$introducer,$icorps_302,
                $sIregFlag,$sIreg_no,$feterms
           FROM policy_302 a
          WHERE ipolicy = $last_ply;

        if (NOT_FOUND) 
        {
            sprintf_s(v_errMsg,sizeof v_errMsg,"��O��Ƥ��s�b;");
            Update_car3011_temp(estimatei, "1", " ", " ", " ", " ", " ", " ", " ", v_errMsg);
            continue;
        }
        
        strcpy(iroute      , trim(iroute));
        strcpy(iofficer_302, trim(iofficer_302));
        strcpy(ilicense_302, trim(ilicense_302));
        strcpy(icorps_302  , trim(icorps_302));
        if (((int)iofficer_302[0] >= 65) && ((int)iofficer_302[0] <= 80))
            icorps_302[0] = '\0';
                
        /* ���o�޲z�H������T */
        /* 1090114008-SC1-��ã��-�s�WCAR301�妸�X��g��N���ˮ� -���s�a�~�ȭ��n���Ҧr���B�O�v�O�B�~�ȱ���B�O�O�q���B�I����H�B�޲z�H            */
        $SELECT a.ileader,a.iquota,b.nbranch,a.icomm_obj ,a.irate_type ,a.icomm_obj ,a.iroute_comm
           INTO $sIleader,$sIquota,$sNquota,$sIcomm_qry ,$irate_type ,$icomm_obj ,$iroute_comm
           FROM officer a,sa_branch_type b
          WHERE a.iquota = b.ibranch
            AND a.iofficer = $iofficer_302;
        
        rc = cm_get_bzfrom( iofficer_302, icomm_obj, irate_type, bzfrom);
        strcpy(irate_type_302,irate_type);
        strcpy(iroute_comm_302,iroute_comm);
        
        strcpy(sTmpIregNo,""); /* �]�w�ɤ��̷s�������u���ϥ� */
        if (sIregFlag[0]=='A') 
        {  
            $SELECT first 1  nvl(ilicence,' ') into $sTmpIregNo
               FROM cm_salesman_log
              WHERE icomm_obj = $sIcomm_qry
                AND (dbusiness is null or dbusiness >= today)
              ORDER by dcreate desc;
            if (NOT_FOUND) 
            {
                sprintf_s(v_errMsg,sizeof v_errMsg, "[%s]�n���Ҹ���Ƥ��s�b(KB);",sIcomm_qry);
                Update_car3011_temp(estimatei, "1", " ", " ", " ", " ", " ", " ", " ", v_errMsg);
                continue;
            }
        }
        else if (sIregFlag[0]=='B') 
        {
            $SELECT first 1  nvl(ilicence,' ') into $sTmpIregNo
               FROM cm_salesman_log
              WHERE icomm_obj = $sIleader
                AND (dbusiness is null or dbusiness >= today)
              ORDER by dcreate desc;
            if (NOT_FOUND) 
            {
                sprintf_s(v_errMsg,sizeof v_errMsg, "[%s]�n���Ҹ���Ƥ��s�b;",sIleader);
                Update_car3011_temp(estimatei, "1", " ", " ", " ", " ", " ", " ", " ", v_errMsg);
                continue;
            }
        }
        else if (sIregFlag[0]=='C') 
        {
            $SELECT first 1 nvl(ireg_no,' ') into $sTmpIregNo
               FROM ca_big_office
              WHERE ibig_comp = $big_sales;
            if (NOT_FOUND) 
            {
                $SELECT first 1 nvl(ilicence,' ') into $sTmpIregNo
                   FROM cm_route_sales
                  WHERE isales = $big_sales
                    AND (iroute = $iroute or iroute = (select iroute_main from cm_route where iroute=$iroute));
                if (NOT_FOUND) 
                {
                    /* �@��q���i��S������ �ҥH�L��� �H�̷s�O���ɤ��������g�J*/
                    strcpy(sTmpIregNo,sIreg_no);
                }
            }
        }
        
        /* �Y�D�q���N�����q�T����ˮֵ��O��Y�A�h���o�妸�X�� (1110303014_SC1) */
        $SELECT count(*) into $ftrans_check
           FROM cm_route a, cm_route b
          WHERE a.iroute = b.iroute_main 
            AND a.ftrans_check = 'Y'
            AND b.iroute = $iroute;   
        
        if (ftrans_check > 0)
        {
            sprintf_s(v_errMsg,sizeof v_errMsg, "�q�T����ˮֵ��O��Y�A�г浧�X����[�~����Ʀ@��]���;");
            Update_car3011_temp(estimatei, "1", " ", " ", " ", " ", " ", " ", " ", v_errMsg);
            continue;
        }
        
        if ((fcard_class[0]=='1') || ((fcard_class[0]=='2') && (strlen(trim(irelative_ply))>0))) /* ��j || (�j+��)*/
        {
            strcpy(bzfrom1,bzfrom);
            /*1080408005-SC5-�j��{�ҷs�W�q����Ƥεn���Ҹ��ɵ{ -�W�w2019/09/4(43712) �_�ˮֱj���I�ӫO����쬰����J*/
            if ((Today >= 43712) && strlen(trim(sTmpIregNo))==0 )
            {
                sprintf_s(v_errMsg,sizeof v_errMsg , "�ӫO�j���I�ɡA�~�ȭ��n���Ҧr��������J���[%s]�A�Ь��ӫO���ӫ~��;",big_sales);
                Update_car3011_temp(estimatei, "1", " ", " ", " ", " ", " ", " ", " ", v_errMsg);
                continue;
            }
            else if ((Today >= 43712) && ((strncmp(bzfrom,"20",2) == 0) || (strncmp(bzfrom,"30",2) == 0))) /*1080806011-SC1-�����ΥX��ɡA�p�G�g��N���O�o�q����20�B30�A�h�ˮֵn���Ҥ���O10�q��*/
            {
                $SELECT CASE WHEN Count(*) > 0 THEN 'Y' ELSE 'N' END 
                   INTO $sChkIregNo
                   FROM cm_salesman_log
                  WHERE ilicence = $sTmpIregNo
                    AND (dbusiness is null or dbusiness >= today);
                
                strcpy(sChkIregNo,trim(sChkIregNo));
                if (sChkIregNo[0]=='Y') 
                {
                    sprintf_s(v_errMsg,sizeof v_errMsg , "�O�o�q����20�B30(�O�g�N�q��)�̡A���o��J�q��10(�~�ȭ��q��)���n���Ҹ��A�Ь��ӫO���ӫ~��[%s][%s];",big_sales,sTmpIregNo);
                    Update_car3011_temp(estimatei, "1", " ", " ", " ", " ", " ", " ", " ", v_errMsg);
                    continue;
                }
            }
            
        }
        strcpy(sTmpIregNo,trim(sTmpIregNo));
        if (strlen(trim(sTmpIregNo)) > 0 )
        {
            strcpy(sIreg_no,sTmpIregNo);
        }
        
        if (((fcard_class[0]=='1') || ((fcard_class[0]=='2') && (strlen(trim(irelative_ply))>0))) && 
            (Today >= 43712) && (strlen(trim(sIreg_no))==0) &&   
            (strncmp(bzfrom,"10",2)==0 || strncmp(bzfrom,"20",2)==0 || strncmp(bzfrom,"30",2)==0|| strncmp(bzfrom,"40",2)==0))
        {
            
            sprintf_s(v_errMsg,sizeof v_errMsg , "�ӫO�j���I�ɡA�~�ȭ��n���Ҧr��������J���A�Ь��ӫO���ӫ~��;");
            Update_car3011_temp(estimatei,"1", " ", " ", " ", " ", " ", " ", " ", v_errMsg);
            continue;
        }
        
         
        /*  ��O���O= 4 (�����_�O��) �� ������j��A���N�I������춷�����ťա��Τ����ȡG
            �O���B�O�I�_���B�O�I�����B�g��N���B�I�ة���
            
            �j��O�I�_�� = ���ú�ڤ�  (1101214006_SC1)
            
            �j��O�I���� = �j��O�I�_�� + 1�~ (���O�զX)  
            �j��O�I���� = �j��O�I�_�� + 2�~ (��ĳ��O�զX)       */
        
        if (frenew_type[0]=='4') 
        {
            if (fcard_class[0]=='1')
            {
                printf("-- trace dcoll_last[%ld]\n ",dcoll_last);
                d302_begin  = dcoll_last;
                printf("-- trace d302_begin[%ld]\n ",d302_begin);
                if (icont[0]=='4') 
                {
                    d302_period = 12 ;
                    $select first 1 date_add( $d302_begin, interval(1) year to year) 
                       into $d302_end
                       from systables;
                }
                else if (icont[0]=='5') 
                {
                    d302_period = 24 ;
                    $select first 1 date_add( $d302_begin, interval(2) year to year) 
                       into $d302_end
                       from systables;          
                }
                printf("-- trace d302_end[%ld]\n ",d302_end);
                strcpy(i302_relative_ply, " "); 
                
            }
            else
            {
                sprintf_s(v_errMsg,sizeof v_errMsg, "�����_�O��������j���I;");
                Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", " ", " ", v_errMsg);
                continue;            
            }        
        }
        
        
        /* 1060609 ���fuw_status */
        if (strcmp(icont,"4") == 0)
        {
            $SELECT fuw_status_ori
               INTO $fuw_status
               FROM policy_302
              WHERE ipolicy = $last_ply;
        }
        else
        {
            $SELECT fuw_status_sug
               INTO $fuw_status
               FROM policy_302
              WHERE ipolicy = $last_ply;
        }
        
        /* �g��B�޲z�H�O�_�]�w���y���i�۰ʥX��z(car140, ���O�N��=SK ) */
        /* �����N�I�~�ˮ�*/
        if (fcard_class[0]=='2' || (fcard_class[0]=='1' && icont[0]=='5' && frenew_type[0]!='4' ))
        {     
            rc = ChkAutoPly(iroute,iofficer_302, &rt_Kind);        
            if (rc == FALSE)
            { 
                if (strlen(trim(v_errMsg)) == 0 )
                {
                    if (rt_Kind > 0) 
                    {
                        if (rt_Kind==200)
                        {
                            sprintf_s(v_errMsg,sizeof v_errMsg,"�޲z�H�N��(%s)",sIleader);
                        }
                        else if (rt_Kind==300)
                        {
                            sprintf_s(v_errMsg,sizeof v_errMsg,"�g��H�N��(%s)",iofficer_302);
                        }
                        else if (rt_Kind==400)
                        {
                            sprintf_s(v_errMsg,sizeof v_errMsg,"�q���N��(%s)",iroute);
                        }
                        strcat(v_errMsg , " �w�]�w���u���i�۰ʥX��v�A�ݥ����ѫȤ�n�O�ѡA�̭�a��O���@�~�{�Ƕi��ñ��; ");
                    }
                }
                else
                {
                    strcpy(v_errMsg, rtrim(v_errMsg));
                }
                Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", " ", " ", v_errMsg);
                continue;        
            }
        }
                
        /* ---------------------------------- [DataCheck1()] -----------------------------------*/
        rc = DataCheck1();  
        if (rc != M_CM_OK)
        {                    
            if(strlen(trim(v_errMsg)) == 0)
            {
                strcpy(v_errMsg, cm_get_errmsg(rc));
            }        
            printf("v_errMsg[%s]\n",v_errMsg);
            Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", " ", " ", v_errMsg);
            continue;
        }
        else   
        {    
            if(strlen(trim(v_errMsg)) > 0) /* �����T�� */
            {
                Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", " ", " ", v_errMsg);         
            }
        }           
        /* ---------------------------------- [DataCheck1()] -----------------------------------*/      
       
            
        strcpy(irelative_ply, trim(irelative_ply));
        strcpy(i302_relative_ply, trim(i302_relative_ply));
        strcpy(icard_main, " "); /* A�����p�d��,Ū��O��ƮɫO���ť�  add by sylvia 102.12.19 (1021122001_C1) */
        if (strlen(i302_relative_ply) > 0)
        {
            if (strcmp(irelative_ply,i302_relative_ply) != 0)
            {
                sprintf_s(errmsg_tmp,sizeof errmsg_tmp, "��O�����p�O�渹�i %s �j�P�̷s�O�������p�O�渹�i %s �j���P�C;",i302_relative_ply, irelative_ply);
                strcpy(irelative_ply, i302_relative_ply); /* �H��O�ɬ��� */
            }

            if (strcmp(chk_relative,"N") == 0)
            {
                sprintf_s(errmsg_tmp,sizeof errmsg_tmp, "��O�����p�O�渹�i %s �j�P���O��ID���ũΫD�P�������C;",i302_relative_ply );
                strcpy(irelative_ply, " "); /* �����L���p�� */
            }
        }
        else
        {
            strcpy(irelative_ply, " "); /* �����L���p�� */
        }

        
        /* �e�~�C�L */ 
        strcpy(fout_print,"1");  strcpy(fmail_type,"1");
        rc = ChkOutPrint(estimatei,iroute,iofficer_302,&rt_Kind);        
        if (rc == FALSE)
        { 
            if (strlen(trim(v_errMsg)) == 0 )
            {      
                if (rt_Kind > 0) 
                {
                    strcpy(fout_print,"0");  strcpy(fmail_type,"0");
                    
                    if (rt_Kind==250)
                    {
                        strcpy(v_errMsg ,"�����G�����(�����渹�e�T�X)");
                    }
                    else if (rt_Kind==100)
                    {
                        sprintf_s(v_errMsg,sizeof v_errMsg,"�����G��[�q���N��(%s) + �g��H�N��(%s)]",iroute, iofficer_302);
                    }
                    else if (rt_Kind==150)
                    {
                        sprintf_s(v_errMsg,sizeof v_errMsg,"�����G�������渹(%s)(car646)",estimatei);	
                    }
                    strcat(v_errMsg , " �w�]�w���u��(�i)�e�~�C�L�v; ");
                    Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                }
            }
            else
            {
                strcpy(v_errMsg, rtrim(v_errMsg));
                Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                continue;
            }
        }
                
            
        if (fcard_class[0] == '1')
        {
            strcpy(icar_flag1,trim(icar_flag));
            /*** �N��O�椧�����j��żƭp�J�������e���ż� ***/
            strcpy(comp_class_last,fcomp_class);
            qdmg1=99;
            qdmg2=99;
            qdmg3=99;
            lia_class_last[0]='0';
            printf(" {Car3011_R2.0003}:Fcard_class[1].comp_class_last[%s]\n",comp_class_last);

            /* 1050425003_C1_�ӽЭץ����s�t��car320²���պ�w�]�O�v�N�� */
            if (strlen(trim(irelative_ply)) != 0)
            {
                /* �����N */
                /*�j �ϥ� */
                strcpy(q_drate_ym_ply,trim(irelative_ply));
                strcpy(fChk, "3");

                /*1050707003_C1 ���I�s�W�q�l�O��@�~*/
                /* 1070125001_SC5_�j��T���d���I�q�l���O�I�һ{�ҥ��x�Χ�O�t�ζ}�o */
                /* 1070125001_SC8_�j��T���d���I�q�l���O�I�һ{�ҥ��x�Χ�O�t�ζ}�o */
                /* 1080417001-SC1-���ά�-�s�W�q�l�O��H²�T�覡�o�etmobile_eply*/
                /* 1080408005-SC1-��ã��-�j���һ{�ҷs�W�q����Ƥεn���Ҹ� */
                /* 1100419003-SC1-���I�O�����QR Code�q�l�� feterms */
                if ((feply[0]=='2') || (feply[0]=='1'))  /* 2:�µ��O*/
                {
                    $SELECT a.feply,a.aemail_eply ,a.tmobile_eply,nvl(b.feterms,'')
                       INTO $fecard, $aemail_eply ,$tmobile_eply,$feterms
                       FROM ply_relation a, outer policy_302 b
                      WHERE a.ipolicy = b.ipolicy
                        AND a.ipolicy = $irelative_ply;
                }
                else strcpy(fecard,feply);
                
                /*1091007004-SC1-���ʱo-�~�ȭ��q��10�۰ʵo�e�j��q�l����(CX�ӷ����i��S���n�O�H�����mail)  
                                    �ΫO�o�q��40��KA�q��(��40KA�i��S���n�O�H�����mail �L�ݥt�~�B�z)
                                    �t���ȥ��γ�j�i�H����J�q�l�o�e��T 
                                    �ҥH�ˮֹq�l�O����쥼�d�������mail�̡A�N�n�O�H�������mail�ƻs�i�h���w�]��*/
                /*1101206002_SC1_�j��q�l���ұH�o�@�~�X�j-���q��*/
                if ((strlen(trim(aemail_eply))==0) && (strlen(trim(tmobile_eply))==0))
                {   
                    strcpy(tmobile_eply,tmobile_appl);
                    strcpy(aemail_eply,aemail_appl);
                }
            }
            else
            {
                /* ��j*/
                if((feply[0] == '2' || feply[0] == '1'))
                {
                    strcpy(fecard,"1");
                    if ((strlen(trim(aemail_eply))==0) && (strlen(trim(tmobile_eply))==0))
                    {   
                    	/*1091007004-SC1-���ʱo-�~�ȭ��q��(10)�ΫO�o�q��40��KA�q���۰ʵo�e�j��q�l����*/
                    	/*1101206002_SC1_�j��q�l���ұH�o�@�~�X�j-���q��*/
                        strcpy(tmobile_eply,tmobile_appl);
                        strcpy(aemail_eply,aemail_appl);
                    }
                }
                else 
                { 
                    /* �j��q�l���ұH�o�@�~�X�j-���q��
                       �B�ȥ��z�����|���q�l�O��������A�G�@�ߦ^�ɦ��n�O�H�p����T (1101206002_SC1) */
                    strcpy(fecard,"0");
                    strcpy(aemail_eply,aemail_appl);
                    strcpy(tmobile_eply,tmobile_appl);	/* 1080417001-SC1-���ά�-�s�W�q�l�O��H²�T�覡�o�e*/
                }
                strcpy(q_drate_ym_ply,trim(last_ply));
                strcpy(fChk, "1");
                strcpy(feterms , "0");  /*  1100419003-SC1-���I�O�����QR Code�q�l��  */
            }  

        }
        else   /** fcard_class == '2' **/
        {
            strcpy(icar_flag2,trim(icar_flag));
            qdmg1 = qdmg1_tmp;
            qdmg2 = qdmg2_tmp;
            qdmg3 = qdmg3_tmp;
            strcpy(lia_class_last, lia_class_last_tmp);
            printf(" {Car3011_R2.0004}:lia_class_last[%s],qdmg1[%d],qdmg2[%d],qdmg3[%d]\n", lia_class_last,    qdmg1,    qdmg2,    qdmg3);

            /* 1050425003_C1_�ӽЭץ����s�t��car320²���պ�w�]�O�v�N�� */
            /* 1070125001_SC5_�j��T���d���I�q�l���O�I�һ{�ҥ��x�Χ�O�t�ζ}�o */
            /* 1070125001_SC8_�j��T���d���I�q�l���O�I�һ{�ҥ��x�Χ�O�t�ζ}�o */
            strcpy(q_drate_ym_ply,trim(last_ply));
            if (strlen(trim(irelative_ply)) != 0)
            {  
            	/* ���j�� */
                strcpy(fChk, "3");
                if (feply[0]=='1') strcpy(fecard,feply);
                else strcpy(fecard,"0");
            }
            else
            {
                strcpy(fecard,"0");
                strcpy(fChk, "2");
            }
        }

        if (!IsBlankNull(inext_ply))  /*return M_CA_NEXT_PLY;  ** �w��O ***/
        {  
            strcpy(v_errMsg, cm_get_errmsg(M_CA_NEXT_PLY));              
            strcpy(v_errMsg, rtrim(v_errMsg));
            sprintf_s(sTmp,sizeof sTmp,"( �w�X�O�渹 = %s )", trim(inext_ply) );      
            strcpy(sTmp    , rtrim(sTmp));
            strcat(v_errMsg, sTmp);
            Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ",  fout_print, feply, v_errMsg);  
            continue;
        }

        strcpy(tmp_dply_end, cm_cdate_str_100(dply_end));

        printf(" {Car3011_R2.0005}:tmp_dply_end[%s],qply_period[%d]\n",tmp_dply_end,qply_period);

        if (strlen(tmp_dply_end) > 8)
        {
            strncpy(iym_end,&tmp_dply_end[0],3);
            iym_end[3]='\0';
            strncat(iym_end,&tmp_dply_end[4],2);
            iym_end[5]='\0';
        }
        else
        {
            strncpy(iym_end,&tmp_dply_end[0],2);
            iym_end[2]='\0';
            strncat(iym_end,&tmp_dply_end[3],2);
            iym_end[4]='\0';
        }

        printf("     {Car3011_R2.0006}:iym_end[%s]\n",iym_end);

        tmp_iym_end=atoi(iym_end);
        lDapply = Today; /*  �֫O�T�{�� ->1060817004  ���q�W�� ���j��q�lñ�p CR��H�q�lñ�p��ƥD�ɬ������֫O ��binsert�e�^���л\*/
        

        /*1050425003_C1_�ӽЭץ����s�t��car320²���պ�w�]�O�v�N��*/
        /** get �j��O�v�ͮĥN�� **/
        stmt[0]='\0';
        sprintf_s(stmt,sizeof stmt,"SELECT MAX(drate_ym) "
                                   "  FROM ply_ins_type_302 WHERE ipolicy = ? and iins_type='21'");
        printf("stmt[%s]\n", stmt);
        $PREPARE CURstm_frate FROM $stmt;
        $DECLARE cur_R22 CURSOR FOR CURstm_frate;
        $OPEN    cur_R22 USING $q_drate_ym_ply;
        $FETCH   cur_R22 INTO  $last_frate_comp;
        $CLOSE cur_R22;
        $FREE  cur_R22;
        if (strlen(trim(last_frate_comp)) == 0)
        {
            $SELECT icode  INTO $last_frate_comp
               FROM ca_rate_renew
              WHERE deffect_bgn <= $d302_begin
                AND deffect_end >= $d302_begin
                AND fcard_class = '1';
            if (strlen(trim(last_frate_comp)) == 0)
            {
                $SELECT MAX(icode)  INTO $last_frate_comp
                   FROM ca_rate_renew
                  WHERE fcard_class = '1';
                if (strlen(trim(last_frate_comp)) == 0) /*return M_CA_NRATE_RENEW;*/
                {
                    strcpy(v_errMsg, cm_get_errmsg(M_CA_NRATE_RENEW));
                    Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ",  fout_print, feply, v_errMsg);
                    continue;
                }
            }
        }
        
        /** get ���N�O�v�ͮĥN�� **/

        stmt[0]='\0';
        sprintf_s(stmt,sizeof stmt,"SELECT MAX(drate_ym) "
                                   "  FROM ply_ins_type_302 WHERE ipolicy = ? ");
        $PREPARE frate_v FROM $stmt;
        $DECLARE cur_R23 CURSOR FOR frate_v;
           $OPEN cur_R23 USING $q_drate_ym_ply;
          $FETCH cur_R23 INTO  $last_frate_volu;
          $CLOSE cur_R23;
           $FREE cur_R23;
        if (strlen(trim(last_frate_volu)) == 0)
        {
            $SELECT icode  INTO $last_frate_volu
               FROM ca_rate_renew
              WHERE deffect_bgn <= $dply_end
                AND deffect_end >= $dply_end
                AND fcard_class = '2';
            if (strlen(trim(last_frate_volu)) == 0)
            {
                $SELECT MAX(icode)  INTO $last_frate_volu
                   FROM ca_rate_renew
                  WHERE fcard_class = '2';
                if (strlen(trim(last_frate_volu)) == 0) /*return M_CA_NRATE_RENEW;*/
                {
                    strcpy(v_errMsg, cm_get_errmsg(M_CA_NRATE_RENEW)); 
                    Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ",  fout_print, feply, v_errMsg);
                    continue;
                }
            }
        }

        if (fChk[0]=='1') /* ��j */
        {
            strcpy(sgliaclass,last_frate_comp);
        }
        else
        {
            strcpy(sgliaclass,last_frate_volu);
        }
        /*********************** STEP 2 ***********************************/
        printf("     {Car3011_R2.0007}:irelative_ply=[%s]\n",irelative_ply);
        psex_age_1=0;
        plia_acc_1=0;
        pdmg_acc_1=0;
        punknown_acc_1=0;
        psex_age_damage=0;

        if (!IsBlankNull(irelative_ply))  /* ���p�O��s�b */
        {
            printf("     {Car3011_R2.0008}: irelative_ply[%s]\n",irelative_ply);
            strcpy(FullDBName2, get_car_full_db(irelative_ply));

            if (FullDBName2[0]=='\0') /*return M_CM_DB_NOTOPEN;*/
            {   
                sprintf_s(v_errMsg,sizeof v_errMsg,"���p�渹[=%s]�L�k���o��Ʈw(��O�渹[%s]);",irelative_ply,last_ply );
                Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ",  fout_print, feply, v_errMsg);
                continue;
            }

            /**** ���p�O���Ƭ��j���I ****/
            if ((strlen(trim(irelative_ply)) != 0) && (fcard_class[0] == '2'))
            {
                stmt[0]='\0';
                sprintf_s(stmt,sizeof stmt,"SELECT %s  FROM %s:%s WHERE %s",
                                           "fcomp_class",
                                           FullDBName2,
                                           "ply_relation",
                                           "ipolicy=?");
                $PREPARE cur_R24 FROM $stmt;
                $EXECUTE cur_R24 INTO $fcomp_class USING $irelative_ply ;
                /**** �j���I�e���ż� ****/
                strcpy(comp_class_last,trim(fcomp_class));
            }
            drnw_print_1=DATENULL;
            stmt[0]='\0';
            sprintf_s(stmt,sizeof stmt,"SELECT %s %s %s %s %s %s FROM %s:%s %s:%s WHERE %s",
                                       "a.icard, a.mdmg_prem, a.mlia_prem, a.inext_ply,",
                                       "a.qply_period, a.dply_begin, a.dply_end,",
                                       "a.icar_type, a.iofficer, a.ibroker, a.icorps,",
                                       "b.psex_age, b.psex_age_damage, b.plia_acc, b.pdmg_acc,",
                                       "b.lia_class, b.dmg_acc_1st, b.dmg_acc_2nd, b.dmg_acc_3rd, ",
                                       "a.irate_type, a.bzfrom, a.iroute_comm, a.icomm_obj,b.punknown_acc ",
                                       FullDBName2,"ply_relation a ,",
                                       FullDBName2,"policy b ",
                                       "a.ipolicy = b.ipolicy AND a.ipolicy=?");
            printf("stmt=[%s]\n",stmt);
            $PREPARE CUR_STMT5 FROM $stmt;
            $DECLARE cur_R25 CURSOR FOR CUR_STMT5;
            $OPEN    cur_R25 USING $irelative_ply;
            $FETCH   cur_R25 INTO  $icard_1, $mdmg_prem, $mlia_prem, $inext_ply_1,
                              $qply_period_1, $dply_begin_1, $dply_end_1,
                              $car_typei_1, $officer_1, $broker_1, $icorps_1,
                              $psex_age_1, $psex_age_damage, $plia_acc_1, $pdmg_acc_1,
                              $lia_class_last_tmp, $qdmg1_tmp, $qdmg2_tmp, $qdmg3_tmp,
                              $irate_type_1, $bzfrom_1, $iroute_comm_1, $icomm_obj_1,$punknown_acc_1;
            if (NOT_FOUND)  /*return M_CA_NPOLICY;*/
            {
                $FREE   cur_R25;
                sprintf_s(v_errMsg,sizeof v_errMsg,"���p�渹[=%s]���O���Ƥ��s�b(��O�渹[%s])",irelative_ply,last_ply);
                Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ",  fout_print, feply, v_errMsg);
                continue;
            }
            $CLOSE  cur_R25;
            $FREE   cur_R25;

            /* �d���p���b��O�ɪ��O�� add by sylvia 101/11/22 */
            $SELECT qply_period, dply_begin, dply_end ,iofficer
               INTO $qply_period_1, $dply_begin_1, $dply_end_1 ,$officer_1
               FROM policy_302
              WHERE ipolicy = $irelative_ply;
            

            if (fcard_class[0] == '1')  /** ���p�O�欰���N�I **/
            {
                qdmg1 = qdmg1_tmp;
                qdmg2 = qdmg2_tmp;
                qdmg3 = qdmg3_tmp;
                strcpy(lia_class_last, trim(lia_class_last_tmp));
            }

            if (!IsBlankNull(inext_ply_1)) /*���s�O��w������O*/
            {
                printf(" {Car3011_R2.0060}: irelative_ply==>inext_ply_1[%s]\n",irelative_ply);
                strcpy(irelative_ply,inext_ply_1);
                strcpy(FullDBName2_rel, get_car_full_db(irelative_ply));
                strcpy(icard_1," ");
                strcpy(inext_ply_1," ");
                mdmg_prem = mlia_prem = 0;
                mdmg_pure_prem = mlia_pure_prem = 0;
                drnw_print_1 = DATENULL;

                stmt[0]='\0';
                sprintf_s(stmt,sizeof stmt,"SELECT %s %s %s %s %s %s  FROM %s:%s %s:%s WHERE %s",
                                           "a.icard, a.mdmg_prem, a.mlia_prem, a.inext_ply, a.drenew_print,",
                                           "a.qply_period, a.dply_begin, a.dply_end,",
                                           "a.icar_type, a.iofficer, a.ibroker, a.icorps,",
                                           "b.psex_age, b.psex_age_damage, b.plia_acc, b.pdmg_acc,",
                                           "b.lia_class, b.dmg_acc_1st, b.dmg_acc_2nd, b.dmg_acc_3rd, a.fcomp_class, ",
                                           "a.irate_type, a.bzfrom, a.iroute_comm, a.icomm_obj,b.punknown_acc",
                                           FullDBName2_rel,"ply_relation a ,",
                                           FullDBName2_rel,"policy b ",
                                           "a.ipolicy = b.ipolicy AND a.ipolicy=?");
                $PREPARE CUR_STMT5_1 FROM $stmt;
                $DECLARE cur_R26 CURSOR FOR CUR_STMT5_1;
                $OPEN    cur_R26 USING $irelative_ply;
                $FETCH   cur_R26 INTO  $icard_1, $mdmg_prem, $mlia_prem, $inext_ply_1,
                                    $drnw_print_1, $qply_period_1, $dply_begin_1, $dply_end_1,
                                    $car_typei_1, $officer_1, $broker_1, $icorps_1,
                                    $psex_age_1, $psex_age_damage, $plia_acc_1, $pdmg_acc_1,
                                    $lia_class_last_tmp, $qdmg1_tmp, $qdmg2_tmp, $qdmg3_tmp, $fcomp_class,
                                    $irate_type_1, $bzfrom_1, $iroute_comm_1, $icomm_obj_1,$punknown_acc_1;
                if (NOT_FOUND)  /*return M_CA_NPOLICY;*/
                {
                    $FREE   cur_R26;
                    sprintf_s(v_errMsg,sizeof v_errMsg,"��O��[%s]�����p�O��w��O[%s]�A�����p�O��[%s]��Ƥ��s�b()",last_ply,inext_ply_1,irelative_ply);
                    Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ",  fout_print, feply, v_errMsg);
                    continue;
                }
                $CLOSE  cur_R26;
                $FREE   cur_R26;

                if (fcard_class[0] == '1')  /** ���p�O�欰���N�I **/
                {
                    qdmg1 = qdmg1_tmp;
                    qdmg2 = qdmg2_tmp;
                    qdmg3 = qdmg3_tmp;
                    strcpy(lia_class_last, lia_class_last_tmp);
                }
                else
                    strcpy(comp_class_last,trim(fcomp_class));
            }
            /* 1090114008-SC1-��ã��-�s�WCAR301�妸�X��g��N���ˮ� 
                           -���s�a�~�ȭ��n���Ҧr���B�O�v�O�B�~�ȱ���B�O�O�q���B�I����H�B�޲z�H   ���s���o �O�o�q���N��*/
            $select irate_type,icomm_obj,iroute_comm
               INTO $irate_type_1, $icomm_obj_1, $iroute_comm_1
               FROM officer 
              WHERE iofficer =$officer_1;
            rc = cm_get_bzfrom( officer_1, icomm_obj_1, irate_type_1, bzfrom_1);
            
        }

        /* �Y�O��g��H���O�N�A�h�N¾�ΥN���M�� ==> officer[0] between 'A' and 'M' */
        if (((int)iofficer_302[0] >= 65) && ((int)iofficer_302[0] <= 80))
            icorps_302[0] = '\0';

        /********************** STEP 3 ***********************************/
        psex_age1=0;
        psex_age2=0;
        psex_age_damage=0;

        printf("{Car3011_R2.0070}: dply_end_1[%l],dply_end[%l]\n",dply_end_1,dply_end);
        printf("{Car3011_R2.0070}: irelative_ply[%s],icard_1[%s]\n",irelative_ply,icard_1);
        printf("{Car3011_R2.0070}: fcard_class[%s],lia_class_last[%s],qdmg1[%d],qdmg2[%d],qdmg3[%d]\n", fcard_class,    lia_class_last,    qdmg1,    qdmg2,   qdmg3);

        if (*fcard_class=='1')  /*** �j���I ***/
        {
            ply1f = TRUE;
            ply1_period = d302_period;
            ply1_begin  = d302_begin;
            ply1_end    = d302_end;

            $SELECT icar_type  INTO $icar_type_t1
               FROM policy_302
              WHERE ipolicy = $last_ply;

            if (SQLCODE != SQLNOTFOUND)
                strcpy(car_typei,icar_type_t1);

            strcpy(policy1    , last_ply);
            strcpy(policy2    , irelative_ply);
            strcpy(car_typei1 , car_typei);
            strcpy(officer1   , iofficer_302);
            strcpy(bzfrom1, bzfrom);              /* �O�o�q���N�� -- �t�X�q���G�ק� */
            strcpy(irate_type1, irate_type_302);  /*xxx*/
            strcpy(iroute_comm1, iroute_comm_302);    /* �~�ȱ���N�� -- �t�X�q���G�ק� */
            strcpy(icomm_obj1, icomm_obj);        /* �I����H -- �t�X�q���G�ק� */
                    
            strcpy(car_typei2 , car_typei_1);
            strcpy(officer2   , officer_1);
            strcpy(bzfrom2, bzfrom_1);             /* �O�o�q���N�� -- �t�X�q���G�ק� */
            strcpy(irate_type2,irate_type_1);      /* �O�v�O -- �t�X�q���G�ק� */
            strcpy(iroute_comm2,iroute_comm_1);    /* �~�ȱ���N�� -- �t�X�q���G�ק� */
            strcpy(icomm_obj2, icomm_obj_1);       /* �I����H -- �t�X�q���G�ק� */

            sDbirth[0] = '\0';
            sDply_begin[0] = '\0';
            strcpy( sDbirth,     cm_cdate_str_100(dbirth));
            strcpy( sDply_begin, cm_cdate_str_100(ply1_begin));
            rc = get_age( sDbirth, sDply_begin, &age, v_sMsg);
            if( rc != M_CM_OK) /*return rc;*/
            {
                strcpy(v_errMsg, cm_get_errmsg(rc));
                Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ",  fout_print, feply, v_errMsg);
                continue;
            }


            if (assuredf[0]=='1' || assuredf[0]=='3' || assuredf[0]=='5')  /*** �۵M�H ***/
            {
                /* �j�� */
                rc = get_sex_age_factor( "1", &age, sex, last_frate_comp, &psex_age1, v_sMsg);
                if( rc != M_CM_OK)
                if( rc != M_CM_OK) /*return rc;*/
                {
                    strcpy(v_errMsg, cm_get_errmsg(rc));
                    Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                    continue;
                }
            }
            
            printf("{Car3011_R2.0009}: age[%d],psex_age1[%lf],psex_age_damage[%f]\n", age, psex_age1, psex_age_damage);
  
            if (tagnum[0]==' ' || tagnum[0]=='\0')
                strcpy(inumber,engine);
            else
                strcpy(inumber,tagnum);

            printf("     {Car3011_R2.0010}: inumber[%s]\n",inumber);

            if ((code=split_policy(last_ply,t_ipolicy1,t_ipolicy2)) != M_CM_OK)
            {
                strcpy(v_errMsg, cm_get_errmsg(code));  
                Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);    
                continue;
            }

            code=cm_get_unit_in(t_ipolicy1,"", "", "", "C1",sIcomp_in, sIbranch_in);
            if (code != M_CM_OK)
            {
                strcpy(v_errMsg, cm_get_errmsg(code)); 
                Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);  
                continue;
            }

            /*1050107005_C2 �X�w���z�s���W�h�ק�(�a��O�ɪ����z�s��)*/
            /*** �j���I�ߴڰO���Y�� ***/
            /*** ����check policy_302[��O��]��� ***/
            stmt[0]='\0';
            sprintf_s(stmt,sizeof stmt,"SELECT a.plia_acc_c,a.fcomp_class,a.qdrunk_driving,a.iassured_cntry,a.iapplicant_cntry,a.qviolate "
                                       "  FROM policy_302 a, %s:policy b"
                                       " WHERE a.ipolicy = ? "
                                       "   AND a.ipolicy = b.ipolicy"
                                       "   AND a.ilicense = b.iassured"
                                       "   AND a.itag = b.itag", rmt_dbname);

            $PREPARE CUR_302_TMP FROM $stmt;
            $DECLARE cur_R27 CURSOR FOR CUR_302_TMP;
            $OPEN    cur_R27 USING $last_ply;
            $FETCH   cur_R27 INTO  $plia_acc_c,$fcomp_class,$qdrunk_driving,$iassured_cntry,$iapplicant_cntry,$qviolate;
            if (NOT_FOUND)
            {
                printf("     {Car3011_R2.0100}:NOT FOUND policy_302 RECORD \n");
                pdmg_acc=0;
                plia_acc=0;
                qdmg_acc=0;
                qlia_acc=0;
                punknown_acc=0;
                fcomp_class[0] = ' ';
                qdrunk_driving = 0;
                qviolate = 0;
                
                /* �ק�car3011�h�ˮֻP��O�ɪ��������@�P�ݱĤH�u�X��(1120522003_C01) */
                sprintf_s(v_errMsg,sizeof v_errMsg,"[%s]��O�J�p��ƻP�̷s�O�樮���BID���šA�г浧�X��",last_ply);
                Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);  
                continue;

            }
            else
            {
                plia_acc = atof(plia_acc_c);
                /* ��X��O��Y�� */
                $SELECT iquery_serial INTO $tmp_iquery
                   FROM ca_trade_renew
                  WHERE icard = $last_card;

                if ( SQLCODE == SQLNOTFOUND)
                    strcpy(tmp_iquery," ");

                strcpy(iquery_num_c, tmp_iquery);
                printf(" {Car3011_R2.0110}: FOUND FROM policy_302 plia_acc_c[%s],plia_acc[%lf]\n",
                                                                  plia_acc_c,    plia_acc);
            }
            $CLOSE  cur_R27;
            $FREE  cur_R27;
            
            strcpy(comp_class, fcomp_class);
            printf("     {Car3011_R2.0110}:plia_acc1[%lf] , fcomp_class[%s]\n",plia_acc,comp_class);
            plia_acc1=plia_acc;	
             
            icnt_302 = 0;
            /* �ˮ֭Yú�ڬ�15, 25:��ĳ��O�զX, �O�_��21�I�إH�~���I�� */
            if (strcmp(icont,"5") == 0)
            {
                $select count(iins_type) into $icnt_302
                   from ply_ins_type_302
                  WHERE ipolicy = $last_ply
                    and iins_type <> '21'
                    and mdamage_cover > 0;
            }

            /* 106/07/01
               �����G
               1.Cal_prem_21()�O�O�p��ɻݭn�ϥ� �~�ȶO��(ZA_mbusiness)�A���O
                 �] policy_302���~�ȶO�����(mbusiness)�ȳ������p�����ȡA�L�k���ΡA
                 �G�Ѧb�����o�u�j���I�������B�v�ϱ��o��(�p�᪺: ZA_mbusiness = tmp_mbusiness_21 - busi_discount;)�A                 
               
               �`�N�G                                                                                     
               2.����������� 4(�����_�O��)�ɡA���O(�j���I�@�~��)�P��ĳ��O(�j���I�G�~��)���O�O���@��
                 �� ply_ins_type_302.mprem �u����ĳ��O�զX���A�G���Ȥ��O���O�ɡA�۴�|�o����~�������B
                 �ھ���O�J�p�W�h�A��������� 4�ɷ|�N�g���ର�~�ȭ��O�v�A�Y���|�������B�A���p��JB�q���h���������O�v�A
                 �G JB�q���B��������� 4�ɡA�����אּ�浧�X��
               
               �ѨM�G  
               3. policy_302 ���ɥ��~�ȶO�����(mbusiness)�ȡA�÷s�W���O�զX���ȶO�����(ex. mbusiness_ori)
                  ply_ins_type_302 ���s�W���O�զX���W���O�����(ex. mprem_ori)
            */  
            
            busi_discount = 0; /* �j���I�������B */
            if (irate_type1[0]!='C')
            {
                $SELECT (mprem - ori_premium) into $busi_discount 
                   FROM ply_ins_type_302
                  WHERE ipolicy = $last_ply
                    AND iins_type = '21';
            }                                   
                        
            /*** �j���I�����p�O�渹==>���N�I ***/
            if ((!IsBlankNull(irelative_ply)) || ( icnt_302 > 0))
            {
                ply2f       = TRUE;
                strcpy(relative_card , " ");
                if (IsBlankNull(irelative_ply))
                {
                    /* �L���p��������ĳ�I��, �O���P�j���I */
                    ply2_period = ply1_period;
                    ply2_begin  = ply1_begin;
                    ply2_end    = ply1_end;
                    strcpy(policy2    , last_ply);
                    strcpy(car_typei2 , car_typei1);
                    strcpy(officer2   , officer1);
                    strcpy(irate_type2, irate_type_302);  /*xxx*/
                }
                else
                { 
                    /* �����p��,�H���p������ */
                    ply2_period = qply_period_1;
                    ply2_begin  = dply_begin_1;
                    ply2_end    = dply_end_1;
                    strcpy(car_typei2 , car_typei_1);
                    strcpy(officer2   , officer_1);
                    strcpy(irate_type2, irate_type_1);  /*xxx*/
                }
                sDbirth[0] = '\0';
                sDply_begin[0] = '\0';
                strcpy(sDbirth,     cm_cdate_str_100(dbirth));
                strcpy(sDply_begin, cm_cdate_str_100(ply2_begin));
                rc = get_age(sDbirth, sDply_begin, &age, v_sMsg);
                if( rc != M_CM_OK)
                {
                    strcpy(v_errMsg, cm_get_errmsg(rc));  
                    Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);    
                    continue;
                }

                if (assuredf[0]=='1' || assuredf[0]=='3' || assuredf[0]=='5')  /*** �۵M�H ***/
                {
                    /* ���d */
                    rc = get_sex_age_factor( "2", &age, sex, last_frate_volu, &psex_age2, v_sMsg);                 
                    if( rc != M_CM_OK)
                    {
                        strcpy(v_errMsg, cm_get_errmsg(rc));
                        Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);    
                        continue;
                    }

                }

                /*** �p����N�I������Ψ��d�ߴګY�� ***/
                /*** ���N�I�ߴگżƤΫY�� ***/

                /* 1040720002_C1_�ץ��ߦw�����I�������l���p��覡 */
                stmt[0]='\0';

                strcpy(execPly, irelative_ply);
                if (strcmp(icont,"4") == 0)
                {
                    sprintf_s(stmt,sizeof stmt,"SELECT %s %s %s FROM %s WHERE %s",
                                               "plia_acc, dmg_ac_cnt1, dmg_ac_cnt2, dmg_ac_cnt3, nvl(pdmg_acc,0.0), ",
                                               "iquery_num_damage, iquery_num, qlia_acc_sum, qdmg_acc_sum, lia_class,funknown_dmg_ori,",
                                               "punknown_acc_ori , qunknown_acc_sum_ori, iquery_num_unknown_ori",
                                               "policy_302 ",
                                               "ipolicy = ?");
                }
                else
                {
                    sprintf_s(stmt,sizeof stmt,"SELECT %s %s %s FROM %s WHERE %s",
                                               "plia_acc, dmg_ac_cnt1, dmg_ac_cnt2, dmg_ac_cnt3, nvl(pdmg_acc,0.0), ",
                                               "iquery_num_damage, iquery_num, qlia_acc_sum, qdmg_acc_sum, lia_class,funknown_dmg_sug,",
                                               "punknown_acc_sug , qunknown_acc_sum_sug, iquery_num_unknown_sug",
                                               "policy_302 ",
                                               "ipolicy = ?");
                    if( icnt_302 > 0) /* ��j��ĳ���N�I */
                    {
                        strcpy(execPly, last_ply);
                    }
                }

                $PREPARE CUR_302_TMP1 FROM $stmt;
                $DECLARE cur_R28 CURSOR FOR CUR_302_TMP1;
                $OPEN    cur_R28 USING $execPly;
                $FETCH   cur_R28 INTO  $plia_acc_c, $dmg_acc_1st_c, $dmg_acc_2nd_c, $dmg_acc_3rd_c, $pdmg_acc_c,
                                       $iquery_num_damage, $iquery_num, $qlia_acc_sum, $qdmg_acc_sum, $lia_class, $funknown_dmg,
                                       $punknown_acc,$qunknown_acc_sum,$iquery_num_unknown;


                if (NOT_FOUND)
                {
                    dmg_acc_3rd = 99;
                    dmg_acc_2nd = 99;
                    dmg_acc_1st = 99;
                    pdmg_acc = 0;
                    plia_acc = 0;
                    punknown_acc = 0;
                    lia_class[0] = ' ';
                    funknown_dmg[0] = ' ';
                }
                else /*** IF FOUND ***/
                {
                    if (dmg_acc_1st_c[0] != '' && dmg_acc_1st_c[0] != '\0')
                        dmg_acc_1st = atoi(dmg_acc_1st_c);
                    else
                        dmg_acc_1st = 99;   /*** ���ܵL�O���εL�ӫO ***/

                    if (dmg_acc_2nd_c[0] != '' && dmg_acc_2nd_c[0] != '\0')
                        dmg_acc_2nd = atoi(dmg_acc_2nd_c);
                    else
                        dmg_acc_2nd = 99;   /*** ���ܵL�O���εL�ӫO ***/

                    if (dmg_acc_3rd_c[0] != '' && dmg_acc_3rd_c[0] != '\0')
                        dmg_acc_3rd = atoi(dmg_acc_3rd_c);
                    else
                        dmg_acc_3rd = 99;   /*** ���ܵL�O���εL�ӫO ***/

                    if (plia_acc_c[0] != '' && plia_acc_c[0] != '\0')
                        plia_acc = atof(plia_acc_c);
                    else
                        plia_acc = 0.0;

                    if (pdmg_acc_c[0] != '' && pdmg_acc_c[0] != '\0')
                        pdmg_acc = atof(pdmg_acc_c);
                    else
                        pdmg_acc = 0.0;
                }
                $CLOSE cur_R28;
                $FREE cur_R28;

                plia_acc2 = plia_acc;
                pdmg_acc  = pdmg_acc;
                printf("     {Car3011_R2.0013}:pdmg_acc[%lf]\n",pdmg_acc);
                
            }/*(!IsBlankNull(irelative_ply))*/
     
        }
        else   /**** fcard_class = '2' ****/
        {
            ply2f = TRUE;
            strcpy(policy2 , last_ply);
            ply2_period = d302_period;
            ply2_begin  = d302_begin;
            ply2_end    = d302_end;
            strcpy(policy1    , irelative_ply);
            strcpy(fcar_note2 , fcar_note);
            strcpy(car_typei2 , car_typei);
            strcpy(officer2   , iofficer_302);
            strcpy(bzfrom2, bzfrom);              /* �O�o�q���N�� -- �t�X�q���G�ק� */
            strcpy(irate_type2, irate_type_302);  /*xxx*/
            strcpy(iroute_comm2,iroute_comm_302);    /* �~�ȱ���N�� -- �t�X�q���G�ק� */
            strcpy(icomm_obj2, icomm_obj);       /* �I����H -- �t�X�q���G�ק� */

            sDbirth[0] = '\0';
            sDply_begin[0] = '\0';
            strcpy( sDbirth,     cm_cdate_str_100(dbirth));
            strcpy( sDply_begin, cm_cdate_str_100(ply2_begin));
            rc = get_age( sDbirth, sDply_begin, &age, v_sMsg);
            if( rc != M_CM_OK)
            {
                strcpy(v_errMsg, cm_get_errmsg(rc));  
                Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                continue;
            }

            if (assuredf[0]=='1' || assuredf[0]=='3' || assuredf[0]=='5')  /*** �۵M�H ***/
            {
                /* ���d */
                rc = get_sex_age_factor( "2", &age, sex, last_frate_volu, &psex_age2, v_sMsg);
                if( rc != M_CM_OK)
                {
                    strcpy(v_errMsg, cm_get_errmsg(rc));
                    Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);    
                    continue;
                }

            }

            if (tagnum[0]==' ' || tagnum[0]=='\0')
                strcpy(inumber,engine);
            else
                strcpy(inumber,tagnum);

            if ((code=split_policy(last_ply, t_ipolicy1, t_ipolicy2)) != M_CM_OK)            
            {
                strcpy(v_errMsg, cm_get_errmsg(code)); 
                Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);   
                continue;
            }

            code=cm_get_unit_in(t_ipolicy1,"", "", "", "C1", sIcomp_in, sIbranch_in);
            if (code != M_CM_OK)
            {
                strcpy(v_errMsg, cm_get_errmsg(code));  
                Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);  
                continue;
            }
            

            /*1050107005_C2 �X�w���z�s���W�h�ק�(�a��O�ɪ����z�s��)*/
            /*1040720002_C1_�ץ��ߦw�����I�������l���p��覡  */
            stmt[0]='\0';
            /* ����Ψ��d���T�d�ߧǸ�, �אּ����O�ɨ� modify by sylvia 100.08.23 */
            /* ��O�󪺨���/���d�T�~�ߴڦ���,����O��Ū¾ add by sylvia 100.10.25 */
            if (strcmp(icont,"4") == 0)
            {
                sprintf_s(stmt,sizeof stmt,"SELECT %s %s FROM %s WHERE %s",
                                           "plia_acc, dmg_ac_cnt1, dmg_ac_cnt2, dmg_ac_cnt3, nvl(pdmg_acc,0.0), ilicense, ",
                                           "iquery_num_damage, iquery_num, qlia_acc_sum, qdmg_acc_sum, lia_class,iassured_cntry , iapplicant_cntry,funknown_dmg_ori ",
                                           "policy_302 ",
                                           "ipolicy = ?");
            }
            else
            {
                sprintf_s(stmt,sizeof stmt,"SELECT %s %s FROM %s WHERE %s",
                                           "plia_acc, dmg_ac_cnt1, dmg_ac_cnt2, dmg_ac_cnt3, nvl(pdmg_acc,0.0), ilicense, ",
                                           "iquery_num_damage, iquery_num, qlia_acc_sum, qdmg_acc_sum, lia_class,iassured_cntry , iapplicant_cntry,funknown_dmg_sug ",
                                           "policy_302 ",
                                           "ipolicy = ?");
            }
            $PREPARE CUR_302_TMP2 FROM $stmt;
            $DECLARE cur_R29 CURSOR FOR CUR_302_TMP2;
            $OPEN    cur_R29 USING $last_ply;
            $FETCH   cur_R29 INTO  $plia_acc_c, $dmg_acc_1st_c, $dmg_acc_2nd_c, $dmg_acc_3rd_c, $pdmg_acc_c, $ilicense_302,
                                   $iquery_num_damage, $iquery_num, $qlia_acc_sum, $qdmg_acc_sum, $lia_class,$iassured_cntry , $iapplicant_cntry, $funknown_dmg;

            
            if (NOT_FOUND)
            {
                printf("     {Car3011_R2.0300}:NOT FOUND in policy_302 \n");
                dmg_acc_3rd = 99;
                dmg_acc_2nd = 99;
                dmg_acc_1st = 99;
                pdmg_acc = 0;
                plia_acc = 0;
                lia_class[0] = ' ';

                strcpy(iquery_num_damage, " ");
                strcpy(iquery_num, " ");
                qlia_acc_sum = 0;
                qdmg_acc_sum = 0;
                strcpy(sgliaclass, "");
                funknown_dmg[0] = ' ';
            }
            else /*** IF FOUND ***/
            {
                printf("     {Car3011_R2.0300}:FOUND in policy_302 \n");
                if (dmg_acc_1st_c[0] != '' && dmg_acc_1st_c[0] != '\0')
                    dmg_acc_1st = atoi(dmg_acc_1st_c);
                else
                    dmg_acc_1st = 99;   /*** ���ܵL�O���εL�ӫO ***/

                if (dmg_acc_2nd_c[0] != '' && dmg_acc_2nd_c[0] != '\0')
                    dmg_acc_2nd = atoi(dmg_acc_2nd_c);
                else
                    dmg_acc_2nd = 99;   /*** ���ܵL�O���εL�ӫO ***/

                if (dmg_acc_3rd_c[0] != '' && dmg_acc_3rd_c[0] != '\0')
                    dmg_acc_3rd = atoi(dmg_acc_3rd_c);
                else
                    dmg_acc_3rd = 99;   /*** ���ܵL�O���εL�ӫO ***/

                if (plia_acc_c[0] != '' && plia_acc_c[0] != '\0')
                    plia_acc = atof(plia_acc_c);
                else
                    plia_acc = 0.0;

                if (pdmg_acc_c[0] != '' && pdmg_acc_c[0] != '\0')
                    pdmg_acc = atof(pdmg_acc_c);
                else
                    pdmg_acc = 0.0;

            }
            $CLOSE cur_R29;
            $FREE cur_R29;

            plia_acc2 = plia_acc;
            pdmg_acc  = pdmg_acc;
            plia_acc2_ori = plia_acc2;
            
            printf("     {Car3011_R2.0220}:Fcard_class2==>plia_acc2[%lf], pdmg_acc[%lf]\n", plia_acc2,      pdmg_acc);

            /* 103.09.10 1030806002_C2�G�����㨮������OBarcode��ĳ�զX�W�C�j���I */
            icnt_302 = 0;
            /* �ˮ֭Yú�ڬ�15, 25:��ĳ��O�զX, �O�_����ĳ21�I�� */
            if (strcmp(icont,"5") == 0)
            {
                $select count(iins_type) into $icnt_302
                   from ply_ins_type_302
                  WHERE ipolicy = $last_ply
                    and iins_type = '21'
                    and mdamage_cover > 0;
            }

            if ((strlen(trim(irelative_ply)) != 0)|| ( icnt_302 > 0))  /*** ���N�I�����p�O��==>�j���I ***/
            {
                ply1f = TRUE;
                strcpy(relative_card," ");

                /* �j����N���P����Τ��P�O��(�L��)��,��O�J�p���|��ĳ�j���I�A���e���|�M��irelative_ply
                   �ҥH��IsBlankNull(irelative_ply)�P�_�|�L�k�o��irelative_ply�O�쥻���ũάO�Q�M�� */

                if ( icnt_302 > 0) /* �H��O�J�p�P�_���G���D�A�T�{�O�_����ĳ�j���I*/
                {
                    /* �L���p��������ĳ�I��, �O���P��O����N�I */
                    ply1_period = ply2_period;
                    ply1_begin  = ply2_begin;
                    ply1_end    = ply2_end;
                    strcpy(policy1    , last_ply);
                    strcpy(car_typei1 , car_typei2);
                    strcpy(officer1   , officer2);
                    strcpy(irate_type1, irate_type_302);  /*xxx*/

                    busi_discount = 0; /* �j���I�������B */
                    
                    if (irate_type1[0]!='C')
                    {
                        $select (mprem - mins_premium) into $busi_discount 
                          from ply_ins_type_302
                         where ipolicy = $last_ply
                           and iins_type = '21';
                    }   
                                        
                }
                else
                {
                    ply1_period = qply_period_1;
                    ply1_begin  = dply_begin_1;
                    ply1_end    = dply_end_1;
                    strcpy(car_typei1 , car_typei_1);
                    strcpy(officer1   , officer_1);
                    strcpy(irate_type1, irate_type_1);  /*xxx*/

                    busi_discount = 0; /* �j���I�������B */
                    if (irate_type1[0]!='C')
                    {
                        $select (mprem - ori_premium) into $busi_discount 
                          from ply_ins_type_302
                         where ipolicy = $irelative_ply
                           and iins_type = '21';
                    }   
                                    
                }

                strcpy(bzfrom1, bzfrom_1);              /* �O�o�q���N�� -- �t�X�q���G�ק� */
                strcpy(iroute_comm1,iroute_comm_1);    /* �~�ȱ���N�� -- �t�X�q���G�ק� */
                strcpy(icomm_obj1, icomm_obj_1);       /* �I����H -- �t�X�q���G�ק� */


                sDbirth[0] = '\0';
                sDply_begin[0] = '\0';
                strcpy( sDbirth,     cm_cdate_str_100(dbirth));
                strcpy( sDply_begin, cm_cdate_str_100(ply1_begin));
                rc = get_age( sDbirth, sDply_begin, &age, v_sMsg);
                if( rc != M_CM_OK)
                {
                    strcpy(v_errMsg, cm_get_errmsg(rc)); 
                    Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                    continue;
                }
                
                if (assuredf[0]=='1' || assuredf[0]=='3' || assuredf[0]=='5')  /*** �۵M�H ***/
                {
                    /* �j�� */
                    rc = get_sex_age_factor( "1", &age, sex, last_frate_comp, &psex_age1, v_sMsg);
                    if( rc != M_CM_OK)
                    {
                        strcpy(v_errMsg, cm_get_errmsg(rc));  
                        Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg); 
                        continue;
                    }
                }
                
                /*** �j���I�ߴڰO���Y�� ***/
                /*** ����check policy_302[��O��]��� ***/
                printf("     {Car3011_R2.0110}: FROM policy_302 Irelative_ply=>irelative_ply[%s]\n",
                                                                          irelative_ply);
                stmt[0]='\0';
                sprintf_s(stmt,sizeof stmt,"SELECT plia_acc_c, fcomp_class, icar_type, qdrunk_driving, qviolate "
                                           "  FROM policy_302 "
                                           " WHERE ipolicy = ? ");
                printf("-- trace stmt[%s]\n ",stmt);
                
                $PREPARE CUR_302_TMP3 FROM $stmt;
                $DECLARE cur_R30 CURSOR FOR CUR_302_TMP3;
                $OPEN    cur_R30 USING $irelative_ply;
                $FETCH   cur_R30 INTO  $plia_acc_c , $fcomp_class, $car_typei1, $qdrunk_driving, $qviolate;
                if (NOT_FOUND)
                {
                    printf("     {Car3011_R2.0110}: NOT FOUND FROM policy_302 \n");
                    plia_acc       = 0;
                    if (strncmp(car_typei1,"01",2)==0 || strncmp(car_typei1,"02",2)==0 || 
                        strncmp(car_typei1,"32",2)==0 || strncmp(car_typei1,"34",2)==0 ||
                        strncmp(car_typei1,"35",2)==0 )
                    {
                        fcomp_class[0]     = '4'; fcomp_class[1]     = '\0';
                        comp_class_last[0] = '4'; comp_class_last[1] = '\0';
                    }
                    else
                    {
                        fcomp_class[0] = '\0';
                    }
                }
                else
                {
                    plia_acc = atof(plia_acc_c);
                    /* ��X���p�渹(�j���I)���j��O�d�� */
                    stmt[0]='\0';
                    sprintf_s(stmt,sizeof stmt,"SELECT icard "
                                               "  FROM %s:ply_relation b"
                                               " WHERE ipolicy = ? ", FullDBName2);
                    $PREPARE CUR_302_TMP4 FROM $stmt;
                    $DECLARE cur_302_Rrel4a CURSOR FOR CUR_302_TMP4;
                    $OPEN    cur_302_Rrel4a USING $irelative_ply;
                    $FETCH   cur_302_Rrel4a INTO  $tmp_last_card;
                    if (NOT_FOUND)
                        strcpy(tmp_iquery," ");
                    else
                    {
                        /* ��X��O��Y�� */
                        $SELECT iquery_serial INTO $tmp_iquery
                           FROM ca_trade_renew
                          WHERE icard = $tmp_last_card;

                        if ( SQLCODE == SQLNOTFOUND)
                            strcpy(tmp_iquery," ");
                    }
                    $CLOSE  cur_302_Rrel4a;
                    $FREE   cur_302_Rrel4a;
                    strcpy(iquery_num_c, tmp_iquery);
                    printf("     {Car3011_R2.0110}: FOUND FROM policy_302 plia_acc_c[%s],plia_acc[%lf]\n",plia_acc_c, plia_acc);
                
                }
                $CLOSE cur_R30;
                $FREE cur_R30;

                strcpy(comp_class, fcomp_class);
                plia_acc1=plia_acc;
            }
        }/** end if-fcard_class=='1' **/


        /*** ���s�����g��N���θg���H�N��                               ***/
        broker_tmp[0]='\0';
        tmp_resource[0]='\0';
        if (icorps_302[0] != ' ' && icorps_302[0] != '\0')
        {
            EXEC SQL SELECT a.icar_broker , b.fprop
                       INTO :broker_tmp , :tmp_resource
                       FROM officer_broker a, officer b
                      WHERE a.iofficer = :icorps_302
                        AND a.iofficer = b.iofficer;
            if (SQLCODE == SQLNOTFOUND)
            {
                EXEC SQL SELECT a.icar_broker , b.fprop
                           INTO :broker_tmp , :tmp_resource
                           FROM officer_broker a , officer b
                          WHERE a.iofficer = :iofficer_302
                            AND a.iofficer = b.iofficer;
                strcpy(icorps_302," ");
            }
        }
        else
        {
            EXEC SQL SELECT a.icar_broker , b.fprop
                       INTO :broker_tmp , :tmp_resource
                       FROM officer_broker a , officer b
                      WHERE a.iofficer = :iofficer_302
                        AND a.iofficer = b.iofficer;
        }
        

        strcpy(tmp_resource, trim(tmp_resource));

        if ((NOT_FOUND) || ((broker_tmp[0]==' ') || (broker_tmp[0]=='\0')))
        { 
            strcpy(broker1,broker);
            strcpy(broker2,broker);
        }
        else
        {
            strcpy(broker1,trim(broker_tmp));
            strcpy(broker2,trim(broker_tmp));
            
            if (icorps_302[0] != ' ' && icorps_302[0] != '\0')  /* ¾�ΥN���Φ�P�N�� */
            {
                if ((strcmp(tmp_resource,"6")==0) &&
                   (assuredf[0] == '2' || assuredf[0] == '4' || assuredf[0] == '6'))
                {
                    strcpy(resource,"8");
                }
                else
                    strcpy(resource,tmp_resource);
            }
            else
            {
                if (isdigit(iofficer_302[0])!=0)  /* �g��N���Ĥ@�X���ƭ� */
                {
                    /* �ȸg��N�������u�N���B����¾�η~�ȤΦ�P�~�ȮɡA�~�Ȩӷ�����0[���u],3[������O],9[���u],Z[���u����] */
                    if (strcmp(tmp_resource,"0")!=0 &&  strcmp(tmp_resource,"3")!=0 &&
                        strcmp(tmp_resource,"9")!=0 &&  strcmp(tmp_resource,"G")!=0)
                    {
                        strcpy(resource,tmp_resource);
                    }
                }
                else
                    strcpy(resource,tmp_resource);
            }
        }  
        
        if (strlen(icorps_302)==0) strcpy(icorps_302," " ); 
        strcpy(sIcorps, icorps_302);  
                
            
        if (psex_age1==0)
            psex_age1_notfound=1;
        else
            psex_age1_notfound=0;

        if (psex_age2==0)
            psex_age2_notfound=1;
        else
            psex_age2_notfound=0;

        printf("     {Car3011_R2.0200}:: before step4&5 ply1f[%d],ply2f[%d]\n",ply1f,ply2f);
        printf("     {Car3011_R2.0200}:: psex_age2[%f] psex_age1[%f]\n",psex_age2,psex_age1);
        printf("     {Car3011_R2.0200}:: plia_acc2[%f] plia_acc1[%f]\n",plia_acc2,plia_acc1);
        printf("     {Car3011_R2.0200}:: pdmg_acc[%f]\n",pdmg_acc);
        printf("     {Car3011_R2.0200}:: comp_class[%s],comp_class_last[%s]\n", comp_class,comp_class_last);
        /************************** STEP 4 ***********************************/
        printf("     {Car3011_R2.0300}:brand[%s] pro_year[%s]\n",brandi,pro_year);


        $SELECT fcar_class  INTO $fcar_class1
           FROM car_type
          WHERE fclass = '1' AND icode  = $car_typei1;
        if (NOT_FOUND) strcpy(fcar_class1,"1");

        $SELECT fcar_class  INTO $fcar_class2
           FROM car_type
          WHERE fclass = '1' AND icode  = $car_typei2;
        if (NOT_FOUND) strcpy(fcar_class2,"1");

        /************************** STEP 5 ***********************************/
        if (ply1f==TRUE)
        {
            printf("     {Car3011_R2.0300}:step5---->ply1_period[%d]\n",ply1_period);
            printf("     {Car3011_R2.0300}:step5---->last_frate[%s]\n",last_frate);

            /* ��O��J�@�ߥH�@�~���� */
            if (*cal_way=='M')  /*Get Short Period Rate*/
            {
                $SELECT prate   INTO $short_prate_1
                   FROM short_period_rate
                  WHERE qperiod = 12;

                if (NOT_FOUND)  /*return M_CA_NSHORT_RATE;*/                 			
                {
                    strcpy(v_errMsg, cm_get_errmsg(M_CA_NSHORT_RATE));  
                    Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                    continue;
                }
                short_prate_1=short_prate_1/100.0;
            }
            else
            {
                $select first 1 ($ply1_end - $ply1_begin) /
                        (date_add( $ply1_begin, interval(1) year to year) - $ply1_begin)
                   into $short_prate_1
                   from systables;
            }

            printf("     {Car3011_R2.0320}:short_prate_1[%f]\n",short_prate_1);
            
            strcpy(comp_frate,last_frate_comp);
            DblDummy = 0.00;
            LngDummy = 0;
            StrDummy[0] = '\0';

            premium1 = 0;

        } /* ply1f==TRUE */

        /* �j���I�������C�� */
        if (strcmp(localdb,"03") == 0)
            premium1 = premium1*0.7;

        printf("     {Car3011_R2.0330}:compulsory_premium_2[%d]\n",premium1);
        printf("     {Car3011_R2.0400}:STEP7,freason=[%d] \n", freason);

        ins33_flag = 0;
        ins48_flag = 0;
        ins35_flag = 0;
        ins56_flag = 0;
        ins136_flag = 0;
        ins166_flag = 0; /* 1080225007-SC1-��ã��-�s�W166�r�� */
        ins266_flag = 0; /* 1110308005_SC1_�w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h */
        iCount302_56 = 0;

        $SELECT ibigcomp
           INTO $ibig_comp
           FROM officer
          WHERE iofficer=$officer1;
        if (NOT_FOUND) { ibig_comp[0]=' ';ibig_comp[1]='\0';}

        /************************** STEP 8 ***********************************/
        $DELETE FROM TMP_IINS WHERE 1 = 1;
        
        if (ply2f==TRUE)
        {
            /*�Y����N���y�P�~�j��d���z�A�h�H ��00�� ���N�� */
            if ((ply1f!=TRUE)&&(strlen(trim(xxcard))>0))
            {
                strcpy(xxcard, "00");
            }
                 
            /* �qofficer ��̷s������� */ 
            $select irate_type,iroute_comm,icomm_obj 
               into $irate_type2,$iroute_comm2,$icomm_obj2
               from officer 
              where iofficer = $officer2;

            /* ���s���o �O�o�q���N�� */ 
            rc = cm_get_bzfrom( officer2, icomm_obj2, irate_type2, bzfrom2);
            if( rc != M_CM_OK)
            {
                strcpy(v_errMsg, cm_get_errmsg(rc));   
                Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);   	
                continue;
            }
            strcpy(iextra_charge, bzfrom2);
                        
            rc = get_iins_cat( car_typei2, 1, ply2_period, iins_cat, iyear, v_sMsg ); /* xxx*/
            if( rc != M_CM_OK)
            {
                strcpy(v_errMsg, cm_get_errmsg(rc));   
                Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                continue;
            }

            strcpy( last_frate, last_frate_volu );
            
            damage_add_flag = 0;
            thief_add_flag = 0;

            stmt[0]='\0';
                         
            
            if (strcmp(icont,"4") == 0)
            {
                /* ���O�զX */

                sprintf_s(stmt,sizeof stmt,
                             "INSERT INTO TMP_IINS "
                             "SELECT A.iins_type, ori_inj_cover, ori_dea_cover, ori_dam_cover, ori_deduct,"
                             "       ori_premium, 0, 0, 0, 0,"
                             "       qday, 0,drate_ym,"
                             "       B.qserial, 0, A.provision, mdiscount, 0, 0, 1, "
                             "       0, 0, 0, 1, 1 "
                             "  FROM ply_ins_type_302 A, insurance_type B"
                             " WHERE ipolicy = ? "
                             "   AND A.iins_type=B.iins_type "
                             "   AND A.ori_dam_cover > 0 " );

                            /* �d���T�Y�� add by sylvia 102.11.14 (1020921001_C1) */
                            $select nvl(pdmg_acc,0.0), qdmg_acc_sum, iquery_num_damage,
                                    punknown_acc_ori,qunknown_acc_sum_ori,iquery_num_unknown_ori
                               into $pdmg_acc, $qdmg_acc_sum, $iquery_num_damage,
                                    $punknown_acc,$qunknown_acc_sum,$iquery_num_unknown
                               from policy_302
                              where ipolicy = $policy2;
            }
            else
            {
                /* ��ĳ��O�զX */
                sprintf_s(stmt,sizeof stmt,
                             "INSERT INTO TMP_IINS "
                             "SELECT A.iins_type, minjured_cover, mdeath_cover, mdamage_cover, mdeduct,"
                             "       mins_premium, 0, 0, 0, 0,"
                             "       qday, 0,drate_ym,"
                             "       B.qserial, 0, A.provision, mdiscount, 0, 0, 1, "
                             "       0, 0, 0, 1, 1 "
                             "  FROM ply_ins_type_302 A, insurance_type B"
                             " WHERE ipolicy = ? "
                             "   AND A.iins_type=B.iins_type "
                             "   AND A.mdamage_cover > 0 and A.iins_type <> '21' ");

                        /* �d���T�Y�� add by sylvia 102.11.14 (1020921001_C1) */
                            $select nvl(pdmg_acc_sug,0.0), qdmg_acc_sum_sug, iquery_num_damage_sug,
                                    punknown_acc_sug,qunknown_acc_sum_sug,iquery_num_unknown_sug
                               into $pdmg_acc, $qdmg_acc_sum, $iquery_num_damage,
                                    $punknown_acc,$qunknown_acc_sum,$iquery_num_unknown
                               from policy_302
                              where ipolicy = $policy2;
            }
            printf("36678-- stmt=[%s]policy2=[%s]\n",stmt,policy2);
            $PREPARE cur_R33 FROM $stmt;
            $EXECUTE cur_R33 USING $policy2;

            sprintf_s( stmt,sizeof stmt, 
                           " SELECT iins_type, minjured_cover, mdeath_cover, mdamage_cover, mdeduct, "
                           "        mins_premium, mpure_prem, pagent, pcommission, pdiscount, "
                           "        qday, mexpense,drate_ym, "
                           "        qserial, mprem, provision, mdiscount, safe_rate, manage_rate, educated_rate, "
                           "        deviation_rate, pextra_charge, pbusiness, psex_age, pshipping "
                           "   FROM TMP_IINS "
                           "  ORDER BY qserial ");
            
            printf("36689-- stmt=[%s]\n",stmt);
            $PREPARE CURstm3 FROM $stmt;
            $DECLARE cur_R34 CURSOR FOR CURstm3;
            $OPEN cur_R34;
            while (1)
            {
                $FETCH cur_R34
                  INTO $ins_type, $injured_cover, $death_cover, $damage_cover, $deduct,
                       $ins_premium, $pure_ins_premium,
                       $pagent, $pcommission, $pdiscount,
                       $qday, $mexpense,
                       $drate_ym, $qserial, $bef_ins_premium, $provision, $mdiscount,
                       $safe_rate, $manage_rate, $educated_rate, $deviation_rate,
                       $pextra_charge, $pbusiness, $psex_age, $pshipping;
                if (NOT_FOUND) break;

                strcpy(ins_type, trim(ins_type));
                printf("{Car3011_R2.0004}:ins_type[%s] provision[%s]\n",ins_type,provision);
                printf("{Car3011_R2.0004}:fhuman[%s],deduct[%d],ins_type[%s]\n",fhuman,deduct,ins_type);
                printf("{Car3011_R2.0004}:officer2[%s],broker2[%s],icorps[%s]\n",officer2,broker2,sIcorps);

                /*1030725001_C1 �ߦw(118)�B����(120)����[�N�B���O�I*/
                /* �������T�Y�Ʃ���T��(01,08�B05,09,85)  add by sylvia 102.11.15 */
                /* 1090812005-SC1-���ά�-�s�W�s�ӫ~-�T�����B���郞�I���l���O�I198�I*/
                /* 1100909003-SC1-�_�@�Ϯ��S�h���p�{������07+15�}���O181�I�ݨD*/
                if ((strcmp(trim(ins_type),"01")==0) || (strcmp(trim(ins_type),"05")==0) ||
                    (strcmp(trim(ins_type),"08")==0) || (strcmp(trim(ins_type),"09")==0) ||
                    (strcmp(trim(ins_type),"85")==0) || (strcmp(trim(ins_type),"198")==0)||
                    (strcmp(trim(ins_type),"181")==0)|| (strcmp(trim(ins_type),"201")==0)||
                    (strcmp(trim(ins_type),"205")==0)|| (strcmp(trim(ins_type),"209")==0)
                   )
                {
                    fag01 = 1; 
                    pdmg_acc_main = pdmg_acc;
                    qdmg_acc_sum_main = qdmg_acc_sum;
                    strcpy(iquery_num_damage_main,iquery_num_damage);
                    strcpy(drate_ym, trim(drate_ym));
                    code = GetReNewDMG(drate_ym,ins_type);
                    
                    if (assuredf[0]=='1' || assuredf[0]=='3' || assuredf[0]=='5')  /*** �۵M�H ***/
                    {
                        /* ���� */
                        rc = get_sex_age_factor( ins_type, &age, sex, last_frate_volu, &psex_age_damage, v_sMsg);
                        if( rc != M_CM_OK)
                        {
                            strcpy(v_errMsg, cm_get_errmsg(rc));  
                            Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);   
                            continue;
                        }
                            
                        psex_age = psex_age_damage;
                    }


                    if ((strcmp(trim(ins_type),"05")==0) || (strcmp(trim(ins_type),"09")==0)  || (strcmp(trim(ins_type),"198")==0) ||
                        (strcmp(trim(ins_type),"205")==0)|| (strcmp(trim(ins_type),"209")==0))
                    {
                        /* 1070212002-SC1 0301�O�v�վ�0501�ͮ� 93�O�v+161+162(�ˮ֤��152+153�A�O�O���98) 05.09��P01���T�J�`*/
                        /* 1090812005-SC1-���ά�-�s�W�s�ӫ~-�T�����B���郞�I���l���O�I198�I*/
                        iMaxDrate = atoi(drate_ym); 
                        if (iMaxDrate <93)
                            pdmg_acc_ori2 = pdmg_acc2;
                        else
                            pdmg_acc_ori = pdmg_acc;
                    }
                    else if (strcmp(trim(ins_type),"85")==0)
                    {
                        pdmg_acc_ori3 = pdmg_acc3;
                    }
                    else if (strcmp(trim(ins_type),"01")==0 || strcmp(trim(ins_type),"201")==0)
                    {
                        pdmg_acc_ori = pdmg_acc;
                    }
                            
                }
                else if ((strcmp(trim(ins_type),"152")==0)|| (strcmp(trim(ins_type),"153")==0))
                {
                    punknown_acc_main = punknown_acc;
                    qunknown_acc_sum_main = qunknown_acc_sum;
                    strcpy(iquery_num_unknown_main,iquery_num_unknown);
                    strcpy(drate_ym, trim(drate_ym));
                    code = GetReNewDMG(drate_ym,ins_type);

                    punknown_acc_ori  = punknown_acc ;          /* 152 153(�s)*/
                    punknown_acc_ori2 = punknown_acc2;         /* 152 153(��)*/
                                
                }
                else if ((strcmp(trim(ins_type),"31")==0) || (strcmp(trim(ins_type),"32")==0)  ||
                         (strcmp(trim(ins_type),"77")==0) || (strcmp(trim(ins_type),"78")==0)  ||
                         (strcmp(trim(ins_type),"113")==0)|| (strcmp(trim(ins_type),"114")==0) ||
                         (strcmp(trim(ins_type),"131")==0)|| (strcmp(trim(ins_type),"132")==0) ||
                         (strcmp(trim(ins_type),"133")==0)|| (strcmp(trim(ins_type),"134")==0) ||
                         (strcmp(trim(ins_type),"149")==0)|| 
                         (strcmp(trim(ins_type),"231")==0)||(strcmp(trim(ins_type),"232")==0)  ||
                         (strcmp(trim(ins_type),"331")==0)||(strcmp(trim(ins_type),"332")==0)  ||
                         (strcmp(trim(ins_type),"531")==0)||(strcmp(trim(ins_type),"532")==0)  ||
                         (strcmp(trim(ins_type),"249")==0)
                        )
                {
                    plia_acc2_ori = plia_acc2;
                }
                
                /* -------------------------------------------------------------------- */
                strcpy(sgliaclass, drate_ym);
                if (strcmp(trim(ins_type),"48")==0)
                {
                    ins48_flag=1;
                    pdiscount = 0;
                }

                if (strcmp(trim(ins_type),"35")==0)
                {
                    ins35_flag=1;
                    pdiscount = 0;
                }

                if (strcmp(trim(ins_type),"56")==0)
                {
                    ins56_flag=1;
                }
                
                if (strcmp(trim(ins_type),"136")==0)
                {
                    ins136_flag=1;
                }
                
                if (strcmp(trim(ins_type),"166")==0)/* 1080225007-SC1-��ã��-�s�W166�r�� */
                {
                    ins166_flag=1;
                }
                
                if (strcmp(trim(ins_type),"266")==0)/* 1110308005_SC1_�w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h */
                {
                    ins266_flag=1;
                }
                
                if ((strcmp(rtrim(ins_type),"11")==0 || strcmp(rtrim(ins_type),"129")==0 || strcmp(rtrim(ins_type),"211")==0) && (deduct!=10 && deduct!=20 && deduct!=0))
                    deduct=10;

                if ((strcmp(rtrim(ins_type),"96")==0) && (deduct!=10 && deduct!=20 && deduct!=0))
                    deduct=10;

                if (strcmp(trim(ins_type),"47")==0)
                    pdiscount = 0;

                /* �ഫ�W�B�d���I��h�O�B�N��qday���ĤT�H�d���I�O�I���B�@,�G,�T */
                if (strcmp(trim(ins_type),"29")==0)
                    rc = lReturnIns29BaseCover(qday,&coverage1_31,&coverage2_31,&coverage3_32);

                /*1030725001_C1 �ߦw(118)�B����(120)����[�N�B���O�I*/
                /* ���[�N�B���A�� */
                /* 1090812005-SC1-���ά�-�s�W�s�ӫ~-�T�����B���郞�I���l���O�I198�I*/
                /* 1100909003-SC1-�_�@�Ϯ��S�h���p�{������07+15�}���O181�I�ݨD*/
                if (((strcmp(trim(ins_type), "01")==0) || (strcmp(trim(ins_type), "05")==0) ||
                     (strcmp(trim(ins_type), "08")==0) || (strcmp(trim(ins_type), "09")==0) ||
                     (strcmp(trim(ins_type), "85")==0) || (strcmp(trim(ins_type),"105")==0) ||
                     (strcmp(trim(ins_type),"118")==0) || (strcmp(trim(ins_type),"120")==0) ||
                     (strcmp(trim(ins_type),"122")==0) || (strcmp(trim(ins_type),"125")==0) ||
                     (strcmp(trim(ins_type),"126")==0) || (strcmp(trim(ins_type),"198")==0) ||
                     (strcmp(trim(ins_type),"181")==0) || (strcmp(trim(ins_type),"201")==0) ||
                     (strcmp(trim(ins_type),"205")==0) || (strcmp(trim(ins_type),"209")==0)) && (qday > 0)
                   )
                {
                    damage_add_flag = 1;
                }
                else if ((strcmp(trim(ins_type),"11")==0 || strcmp(trim(ins_type),"129")==0 || strcmp(trim(ins_type),"211")==0) && (qday > 0))
                {
                    thief_add_flag = 1;
                }
                else if ( (strcmp(trim(ins_type), "29")==0) || (strcmp(trim(ins_type), "15")==0) ||
                          (strcmp(trim(ins_type), "16")==0) || (strcmp(trim(ins_type), "66")==0) ||
                          (strcmp(trim(ins_type), "67")==0) || (strcmp(trim(ins_type), "38")==0) ||
                          (strcmp(trim(ins_type), "39")==0) || (strcmp(trim(ins_type),"106")==0) ||
                          (strcmp(trim(ins_type),"119")==0) || (strcmp(trim(ins_type),"121")==0) ||
                          (strcmp(trim(ins_type),"123")==0) || 
                          (strcmp(trim(ins_type),"154")==0) || (strcmp(trim(ins_type),"155")==0) || 
                          (strcmp(trim(ins_type),"156")==0) || (strcmp(trim(ins_type),"238")==0) || 
                          (strcmp(trim(ins_type),"163")==0) 
                        ) /*1030725001_C1 �ߦw(118)�B����(120)����[�N�B���O�I 1070625011-SC1-��ã��-�s�W�s�A��+�����N�B���s�ӫ~(�I��163)�{���ޱ� 1100119001-SC1-���ά�-�s�W-�s�ӫ~238�I-�D���ϴ��O�Ϊ��[����*/
                {         /*1100311005-SC1-�����¦����s�A�������I�����{���]�w137�B138�B139�B141�B142�I��(strcmp(trim(ins_type),"139")==0) ||*/
                    mexpense = 0;
                    mexp_disc = 0;
                }
                else
                {
                    qday = 0;
                    mexpense = 0;
                    mexp_disc = 0;
                }

                /* �t�X�q���ĤG���q,get_commission_agent �s�W�Ѽ� modify by sylvia 100.06.04 */
                /* �t�X��椣�ˮֳq�����v, �T�w�ǫO�����O=P(�O��) modify by sylvia 101.02.07 */
                rc = get_commission_agent( iins_cat, broker2, ins_type, iyear, drate_ym,
                                           &broker_pagent, &broker_pdisc, &broker_pcommi, &mservice, &mother_busi,
                                           icheck_disc, icheck_commi, icheck_agent, icheck_busi, ipaid_base,
                                           &pfix_agent, icheck_mservice, itype_disc, fstart2,
                                           officer2, iroute, irate_type2, iroute_comm2, "P", v_sMsg );


                /* �t�X�q���ĤG���q,�g���H�N���ť�, �B�O�v�ۥѤƫ�@�ߥH�]�w�ɬ��D,�G��g���� modify by sylvia 100.06.17 */

                if((strcmp(trim(ins_type),"33")==0) || (strcmp(trim(ins_type),"48")==0) ||
                   (strcmp(trim(ins_type),"35")==0) || (strcmp(trim(ins_type),"47")==0) )
                {
                    broker_pdisc = 0;
                }

                if (strcmp(icheck_agent,"4")==0)  /* �B��--�̦����v */
                {   
                    /* �p���I�ĤT��L����i�� */
                    broker_pagent = (double)broker_pcommi * (double)(pfix_agent/100.00);
                    broker_pagent = broker_pagent + 0.009;
                    broker_pagent = (long)(broker_pagent*100);
                    broker_pagent = (double)((double)broker_pagent/100.00);
                }
                Total_comm_agt_rate = 0.00;

                /* �ˮ��I���u�f�v */
                if (itype_disc[0] == '2')
                {
                    if (strcmp(trim(icheck_disc),"0")==0)       /* 0:�T�w�ˮ� */
                        pdiscount = broker_pdisc;
                    else if (strcmp(trim(icheck_disc),"1")==0)  /* 1:�W���ˮ� */
                    {
                        if (pdiscount > broker_pdisc)
                            pdiscount   = broker_pdisc;

                        if (pdiscount <= broker_pdisc)
                            broker_pdisc = pdiscount;
                    }
                    else if (strcmp(trim(icheck_disc),"2")==0)  /* 2:�X���ˮ� */
                    {
                        Total_comm_agt_rate += broker_pdisc;
                        if (strcmp(trim(icheck_commi),"2")==0)
                            Total_comm_agt_rate += broker_pcommi;

                        if (strcmp(trim(icheck_agent),"2")==0)
                            Total_comm_agt_rate += broker_pagent;

                        if (pdiscount > Total_comm_agt_rate)
                            broker_pdisc = Total_comm_agt_rate;
                        else
                            broker_pdisc = pdiscount;
                    }
                    else
                        broker_pdisc = pdiscount;

                    pdiscount   = broker_pdisc;
                    mdiscount   = 0;
                    
                }/* (itype_disc[0] == '2') */
                else
                {
                    if (strcmp(trim(icheck_disc),"0")==0)       /* 0:�T�w�ˮ� */
                    {
                        mdiscount    = broker_pdisc;
                        broker_pdisc = 0;
                    }
                    else if (strcmp(trim(icheck_disc),"1")==0)  /* 1:�W���ˮ� */
                    {
                        if (mdiscount > broker_pdisc)
                            mdiscount   = broker_pdisc;

                        broker_pdisc    = 0;
                    }
                    pdiscount = 0;
                }
                sprintf_s(tmp_pfix_agent,sizeof tmp_pfix_agent,"%4.2f", pfix_agent);

                printf("{Car3011_R2.0004}:broker_pcommi[%lf],broker_pagent[%lf],broker_pdisc[%lf]\n", broker_pcommi,broker_pagent,broker_pdisc);

                pcommission = broker_pcommi;
                pagent      = broker_pagent;
                
                 
                /********************** �ˮ��I�جO�_����  ***********************************/
                 
                rc = chk_insurance_expire(ins_type, v_sMsg);
                if( rc != M_CM_OK)
                {
                    strcpy(v_errMsg, cm_get_errmsg(rc));   
                    Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                    continue;
                }

                /********************** ���[�O�βv  ***********************************/

                pbusiness = 0.0; pextra_charge =0.0;
                /*  1090916003-�����@-�I�߫O�N�����T�걵-���[�O�βv �W�[�D�q���N���P�_*/
                rc = get_cm_extra_charge_car( iextra_charge, drate_ym,
                                             &pextra_charge, &pbusiness, ply2_period, atoi(rtrim(ins_type)), iroute , v_sMsg);
                if( rc != M_CM_OK)
                {
                    strcpy(v_errMsg, cm_get_errmsg(rc));   
                    Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                    continue;
                }
                
                if (!Insert_INS_TYPE(ins_type,injured_cover,death_cover,damage_cover,deduct,
                      ins_premium,bef_ins_premium,
                      pagent,pcommission,pdiscount,
                      drate_ym,pure_ins_premium,
                      pagent,pcommission,pdiscount,
                      icheck_agent, icheck_commi, icheck_disc,
                      ipaid_base,pfix_agent,
                      qday,mexpense,provision,itype_disc,mdiscount,
                      safe_rate, manage_rate, educated_rate, deviation_rate,
                      pextra_charge, pbusiness, psex_age, pshipping," ",
                      Qmdrunk_prem, Qmdrunk_pure_prem, pcar_price_1, Qmviolate_prem, Qmviolate_pure_prem))
                {
                    printf("     {CAR301Opt1_302.0004}:malloc fail in struct INS_TYPE allocation!\n");
                    $CLOSE cur_R34;
                    $FREE cur_R34;
                                
                    strcpy(v_errMsg, cm_get_errmsg(M_CM_NOT_MALLOC));  
                    Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                    continue;

                }
                
                /*** �ˮ`�I���Ӹ��-48 ***/
                if (strcmp(trim(ins_type),"48")==0)
                {
                    stmt[0]='\0';
                    if (strcmp(icont,"4") == 0)
                    {
                        /* ���O�զX */
                        sprintf_s(stmt,sizeof stmt,
                            "select b.iinsurant, b.ninsurant, b.dbirth, b.iins_scope, "
                            "       b.mins_amt, b.mins_premium, 0, b.mdiscount, "
                            "       b.relation_appl, b.ori_daily_pay "
                            "  from %s:ply_ins_type_302 a, %s:ca_pa_ply_302 b "
                            " where a.ipolicy = b.ipolicy and a.iins_type = b.iins_type "
                            "   and a.ipolicy = '%s' and a.iins_type = '48' ",
                            local_dbname, local_dbname, policy2);
                    }
                    else
                    {
                        /* ��ĳ��O�զX */
                        sprintf_s(stmt,sizeof stmt,
                            "select b.iinsurant, b.ninsurant, b.dbirth, b.iins_scope, "
                            "       b.mins_amt, b.mins_premium, 0, b.mdiscount, "
                            "       b.relation_appl, b.daily_pay "
                            "  from %s:ply_ins_type_302 a, %s:ca_pa_ply_302 b "
                            " where a.ipolicy = b.ipolicy and a.iins_type = b.iins_type "
                            "   and a.ipolicy = '%s' and a.iins_type = '48' ",
                            local_dbname, local_dbname, policy2);
                    }

                    printf("stmt[%s]\n", stmt);
                    $PREPARE CURstm48 FROM $stmt;
                    $DECLARE cur_R48b  CURSOR FOR CURstm48;
                    $OPEN    cur_R48b ;
                    while (1)
                    {
                        $FETCH cur_R48b INTO :cIinsurant,:cNinsurant,
                                             :lDbirth,       :cIins_scope,
                                             :lMins_amt,     :lMins_premium,
                                             :dPdiscount,    :lMdiscount,
                                             :cRelation_appl,:cDaily_pay;
                        if (NOT_FOUND) break;

                        if (! Insert_INS_TYPE_48(cIinsurant, cNinsurant,
                                                 lDbirth,
                                                 cIins_scope,
                                                 lMins_amt, lMins_premium,
                                                 pcommission, 0, pagent, 0,
                                                 pdiscount, 0,
                                                 cRelation_appl,0,0,cDaily_pay))
                        {
                            $CLOSE cur_R48b;
                            $FREE  cur_R48b;
                            strcpy(v_errMsg, cm_get_errmsg(M_CM_NOT_MALLOC));  
                            Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);  
                            continue;
                        }
                    }
                    $CLOSE cur_R48b;
                    $FREE  cur_R48b;
                }

                /*** ���[�a�x�����ĤT�H-35 ***/
                if (strcmp(trim(ins_type),"35")==0)
                {
                    /* �ץ�35�I�ة��ӫO�B�^���覡(1090117011_SC1) */ 
                    stmt[0]='\0';
                    if (strcmp(icont,"4") == 0)
                    {
                        /* ���O�զX */
                        sprintf_s(stmt,sizeof stmt,
                            "select b.iinsurant, b.ninsurant, b.iins_scope,  "
                            "       b.mins_amt, b.mins_premium, 0, b.mdiscount "
                            "  from %s:ply_ins_type_302 a, %s:ca_pa_ply_302 b "
                            " where a.ipolicy = b.ipolicy and a.iins_type = b.iins_type "
                            "   and a.ipolicy = '%s' and a.iins_type = '35' ",
                            local_dbname, local_dbname, policy2);
                    }
                    else
                    {
                        /* ��ĳ��O�զX */
                        sprintf_s(stmt,sizeof stmt,
                            "select b.iinsurant, b.ninsurant, b.iins_scope,  "
                            "       b.mins_amt, b.mins_premium, 0, b.mdiscount "
                            "  from %s:ply_ins_type_302 a, %s:ca_pa_ply_302 b "
                            " where a.ipolicy = b.ipolicy and a.iins_type = b.iins_type "
                            "   and a.ipolicy = '%s' and a.iins_type = '35' ",
                            local_dbname, local_dbname, policy2);
                    }
                    printf("stmt[%s]\n", stmt);

                    $PREPARE CURstm35 FROM $stmt;
                    $DECLARE cur_R35b  CURSOR FOR CURstm35;
                    $OPEN    cur_R35b ;
                    while (1)
                    {
                        $FETCH cur_R35b INTO :cIinsurant,    :cNinsurant,
                                             :cIins_scope,
                                             :lMins_amt,     :lMins_premium,
                                             :dPdiscount,    :lMdiscount;

                        if (NOT_FOUND) break;

                        if (! Insert_INS_TYPE_35(cIinsurant, cNinsurant,
                                                 cIins_scope,
                                                 lMins_amt, lMins_premium,
                                                 pcommission, 0, pagent, 0,
                                                 pdiscount, 0))
                        {
                            $CLOSE cur_R35b;
                            $FREE  cur_R35b;
                            strcpy(v_errMsg, cm_get_errmsg(M_CM_NOT_MALLOC));   
                            Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                            continue;
                        }
                    }
                    $CLOSE cur_R35b;
                    $FREE  cur_R35b;
                }

                /*** �ˮ`�I���Ӹ��-56 ***/
                /* 1090221006-SC1-��ã��-��_56�r�p�H�W�U */
                /* 1080225007-SC1-��ã��-�s�W166�r�� */
                /* 1110308005_SC1_�w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h */
                if ( strcmp(trim(ins_type),"56")==0  || strcmp(trim(ins_type),"136")==0 || 
                     strcmp(trim(ins_type),"166")==0 || strcmp(trim(ins_type),"266")==0 )
                {
                    stmt[0]='\0';
                    if (strcmp(icont,"4") == 0)
                    {
                        /* ���O�զX */
                        sprintf_s(stmt,sizeof stmt,
                        "select b.iinsurant, b.ninsurant, b.dbirth, b.ainsurant, "
                        "       b.iins_scope, b.icareer, a.ori_dam_cover, "
                        "       a.ori_premium, 0, a.mdiscount, b.napplicant, "
                        "       b.relation_appl, b.nbeneficiary, b.relation_bene, "
                        "       b.ori_daily_pay, b.mr_ins_prem, b.mr_pure_prem, "
                        "       b.tbenef,       b.abenef_zip,     b.abenef "
                        "  from %s:ply_ins_type_302 a, %s:ca_pa_ply_302 b "
                        " where a.ipolicy = b.ipolicy and a.iins_type = b.iins_type "
                        "   and a.ipolicy = '%s' and a.iins_type = '%s' ",
                        local_dbname, local_dbname, policy2, ins_type);
                    }
                    else
                    {
                        /* ��ĳ��O�զX */
                        sprintf_s(stmt,sizeof stmt,
                        "select b.iinsurant, b.ninsurant, b.dbirth, b.ainsurant, "
                        "       b.iins_scope, b.icareer, a.mdamage_cover, "
                        "       a.mins_premium, 0, a.mdiscount, b.napplicant, "
                        "       b.relation_appl, b.nbeneficiary, b.relation_bene, "
                        "       b.daily_pay, b.mr_ins_prem, b.mr_pure_prem, "
                        "       b.tbenef,       b.abenef_zip,     b.abenef "
                        "  from %s:ply_ins_type_302 a, %s:ca_pa_ply_302 b "
                        " where a.ipolicy = b.ipolicy and a.iins_type = b.iins_type "
                        "   and a.ipolicy = '%s' and a.iins_type = '%s' ",
                        local_dbname, local_dbname, policy2, ins_type);
                    }
                    printf("stmt[%s]\n", stmt);
                    $PREPARE CURstm56 FROM $stmt;
                    $DECLARE cur_R56b  CURSOR FOR CURstm56;
                    $OPEN    cur_R56b  ;
                    while (1)
                    {
                        $FETCH cur_R56b INTO :cIinsurant,    :cNinsurant,
                                             :lDbirth,       :cAinsurant,
                                             :cIins_scope,   :cIcareer,
                                             :lMins_amt,     :lMins_premium,
                                             :dPdiscount,    :lMdiscount,
                                             :cNapplicant,   :cRelation_appl,
                                             :cNbeneficiary, :cRelation_bene, :cDaily_pay, :lMr_ins_premium, :lMr_pure_premium,
                                             :cTbenef,       :cAbenef_zip,    :cAbenef;
                        if (NOT_FOUND) break;

                        if (! Insert_INS_TYPE_56(cIinsurant, cNinsurant,
                                                  lDbirth, cAinsurant,
                                                  cIins_scope, cIcareer,
                                                  lMins_amt, lMins_premium,
                                                  pcommission, 0, pagent, 0,
                                                  pdiscount, 0,
                                                  cNapplicant, cRelation_appl,
                                                  cNbeneficiary, cRelation_bene, cDaily_pay, lMr_ins_premium, lMr_pure_premium,
                                                  cTbenef,       cAbenef_zip,    cAbenef))
                        {
                            $CLOSE cur_R56b;
                            $FREE  cur_R56b;
                            strcpy(v_errMsg, cm_get_errmsg(M_CM_NOT_MALLOC));  
                            Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                            continue;
                        }
                    }
                    $CLOSE cur_R56b;
                    $FREE  cur_R56b;
                }
            }
            $CLOSE cur_R34;
            $FREE  cur_R34;

            /* 1030725001_C1 �ߦw(118)�B����(120)����[�N�B���O�I*/
            /* �S�������I�ɪ����T�Y�ƳB�z--����01�I�� add by sylvia 102.11.15 (1020921001_C1) */
            /* 1090812005-SC1-���ά�-�s�W�s�ӫ~-�T�����B���郞�I���l���O�I198�I*/
            /* 1100909003-SC1-�_�@�Ϯ��S�h���p�{������07+15�}���O181�I�ݨD*/
            count_dmg = 0;
            $select count(iins_type) into $count_dmg
               from TMP_IINS
              where iins_type in ('01','05','08','09','85','105','118','120','122','125','126','181','198','201','205','209');
              
            if (count_dmg == 0)
            {
                pdmg_acc_main = 0.0;
                qdmg_acc_sum_main = qdmg_acc_sum;
                strcpy(iquery_num_damage_main,iquery_num_damage);
                strcpy(drate_ym, trim(drate_ym));
                code = GetReNewDMG(drate_ym,"00");
            }

            /* --------------------------------------------------------------- */

            strcpy( sDbname, rmt_dbname);
            strcpy( sColumn, "ipolicy");
            strcpy( sTable,  "ply_ins_cover");

            #ifdef CA_CONS
            strcpy(qcont,"0");
            strcat(qcont,icont);
             
            IfirstPlyInsCover = get_ply_ins_cover_302(policy2, qcont, &rtncode, v_sMsg);
            if( rtncode != M_CM_OK)
            {
                strcpy(v_errMsg, cm_get_errmsg(rtncode));  
                Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                continue;
            }    
            #endif

            strcpy( sTable,  "ply_ins_assured_302");
            IfirstPlyInsAssured = get_ply_ins_assured( sDbname, sTable, sColumn, policy2, &rtncode, v_sMsg);
            if( rtncode != M_CM_OK)
            {
                strcpy(v_errMsg, cm_get_errmsg(rtncode));   
                Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                continue;
            }   

            strcpy( sTable,  "ca_ply_bound");
            rtncode = get_ca_ply_bound( sDbname, sTable, sColumn, policy2, ibound, v_sMsg);
            if( rtncode != M_CM_OK)
            {
                strcpy(v_errMsg, cm_get_errmsg(rtncode));  
                Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg); 	
                continue;
            }   

            printf("{Car3011_R2.0004}:broker2[%s]icomm_obj2=[%s]\n",broker2,icomm_obj2);

            $select icode into $sIcode
               from v_commission_obj
              where icomm_obj = $icomm_obj2;

            if (strcmp(sIcode,"3") == 0)
            {
                $SELECT fagent
                   INTO $fagent
                   FROM broker_agent
                  WHERE ibroker=$icomm_obj2;
                if (NOT_FOUND) { fagent[0]='N';fagent[1]='\0';}
            }

            $SELECT ibigcomp
               INTO $ibig_comp
               FROM officer
              WHERE iofficer=$officer2;
            if (NOT_FOUND) { ibig_comp[0]=' ';ibig_comp[1]='\0';}


            /* �I��20,23�H��86�h��@�~ */
            /* �I��101,102(�q�ʦۦ樮)�]�n�h��@�~ modify by sylvia 102.08.10 (1020430001_C1) */
            if( Scan_INS_TYPE(20) || Scan_INS_TYPE(86) || Scan_INS_TYPE(23) ||
                Scan_INS_TYPE(101) || Scan_INS_TYPE(102)|| Scan_INS_TYPE(110)|| Scan_INS_TYPE(111))
                adj_year = 1;
            else
                adj_year = 0;
                
            /* 1061205007_C1_���������ڰӫ~�Χ��²v���[���ڤW�u */
            /* 1050226003_C1�s�W�u�T���O�I���w���²v���[���ڡv�@�~ */ 
            strcpy(fProvision_Z,"N");  strcpy(fProvision_P,"N");  strcpy(fProvision_Q,"N");  
            strcpy(fProvision_M,"N");  
            if(Scan_INS_TYPE_Prov("Z")) strcpy(fProvision_Z,"Y"); 
            if(Scan_INS_TYPE_Prov("P")) strcpy(fProvision_P,"Y");  
            if(Scan_INS_TYPE_Prov("Q")) strcpy(fProvision_Q,"Y");
            if(Scan_INS_TYPE_Prov("M")) strcpy(fProvision_M,"Y");/* 1081105005-SC1-��ã��-�ק���~���w���ƫ������²v�Φۭt�B(M����)*/
            
            code   = SetCarAge(officer2,brandi, adj_year, drate_ym);

            printf("{Car3011_R2.0004}:code[%d]\n",code);
            printf("{Car3011_R2.0004}:---------->cal_car_id[%s]---->\n",cal_car_id);

            car_tp = atoi(cal_car_id);

            printf("{Car3011_R2.0004}:bigcnt[%d]\n",bigcnt);
            printf("{Car3011_R2.0004}:pdmg_acc[%lf]\n",pdmg_acc);

            
            /********************** STEP 9 ***********************************/
            code=SetFactor();
            if (code != SUCCESS)
            {
                aa=0;
                bb2=0;
                cc=0;
                ee1=0;
                ee2=0;
                ee3=0;
            }

            ClearSendBackData();
                     
        }
       
        
        if (ply1f == TRUE)
        {

            /* �qofficer ��̷s������� */
            $select irate_type,iroute_comm,icomm_obj
               into $irate_type1,$iroute_comm1,$icomm_obj1
               from officer 
              where iofficer = $officer1; 
              
            /* ���s���o �O�o�q���N�� */    
            rc = cm_get_bzfrom( officer1, icomm_obj1, irate_type1, bzfrom1);
            if( rc != M_CM_OK)
            {
                strcpy(v_errMsg, cm_get_errmsg(rc));   
                Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                continue;
            }
            strcpy(iextra_charge, bzfrom1);
                                                            
            
            /*******************************  ********************/
            
            $int tmp_ply_period=0;
            $double tmp_mbusiness_21_2,tmp_mbusiness_21_3,tmp_mbusiness_21_4,tmp_mbusiness_21_5;
              
            tmp_mbusiness_21 = 0.0;  tmp_mbusiness_21_2 = 0.0; 
            tmp_mbusiness_21_3 = 0.0;tmp_mbusiness_21_4 = 0.0; tmp_mbusiness_21_5 = 0.0;
              
            tmp_ply_period = ply1_period > 12 ? 24 : 12 ;
            strcpy(comp_frate,"");
 
            strcpy(comp_frate, last_frate_comp);
            printf("comp_frate[%s]\n",comp_frate);
            
            /* car9712022 �j���I�ȳf������۵M�H�k�H�O�v */
            rc = get_comp_car_type_fassured( car_typei1, comp_frate, assuredf, tmp_car_type, comp_fassured, v_sMsg);
            if ( rc != M_CM_OK)
            {
                sprintf_s(v_errMsg,sizeof v_errMsg,"�j���I�O�v�ͮĤ�(car120)�䤣�� ( ��O�渹[%s] )",last_ply);
                Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                continue;
            }
            printf("-- trace tmp_car_type[%s]\n ",tmp_car_type);
            printf("-- trace tmp_ply_period[%d]\n ",tmp_ply_period);
            printf("-- trace qpt[%f]\n ",qpt);
            $SELECT mbusiness
               INTO $tmp_mbusiness_21
               FROM compulsory_premium
              WHERE icar_type = $tmp_car_type
                AND qperiod   = 12
                AND ((qcar_personbgn <= $qpt AND qcar_personend >= $qpt) OR (qcar_personbgn = 0))
                AND drate = (SELECT drate  FROM ca_rate_date WHERE icode  = $comp_frate  AND itable = 'compulsory_premium')
                AND fassured = $comp_fassured;

            if (NOT_FOUND)
            {
                sprintf_s(v_errMsg,sizeof v_errMsg, "�j���I�O�v���(car101)�䤣�� ( ��O�渹[%s], ����[%s] )",last_ply,tmp_car_type);
                Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                continue;
            }
              
            if (tmp_ply_period == 24 )
            {
                $SELECT mbusiness
                   INTO $tmp_mbusiness_21_2
                   FROM compulsory_premium
                  WHERE icar_type = $tmp_car_type
                    AND qperiod   = $tmp_ply_period
                    AND ((qcar_personbgn <= $qpt AND qcar_personend >= $qpt) OR (qcar_personbgn = 0))
                    AND drate = (SELECT drate  FROM ca_rate_date WHERE icode  = $comp_frate  AND itable = 'compulsory_premium')
                    AND fassured = $comp_fassured;
                 
                if (NOT_FOUND)
                {
                    sprintf_s(v_errMsg,sizeof v_errMsg, "�j���I�O�v���(car101)�䤣�� ( ��O�渹[%s], ����[%s] (�G�~��) )",last_ply,tmp_car_type);
                    Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                    continue;
                }  
            }  
            
            if (tmp_ply_period == 36 )
            {
                $SELECT mbusiness
                   INTO $tmp_mbusiness_21_3
                   FROM compulsory_premium
                  WHERE icar_type = $tmp_car_type
                    AND qperiod   = $tmp_ply_period
                    AND ((qcar_personbgn <= $qpt AND qcar_personend >= $qpt) OR (qcar_personbgn = 0))
                    AND drate = (SELECT drate  FROM ca_rate_date WHERE icode  = $comp_frate  AND itable = 'compulsory_premium')
                    AND fassured = $comp_fassured;
                 
                if (NOT_FOUND)
                {
                    sprintf_s(v_errMsg,sizeof v_errMsg, "�j���I�O�v���(car101)�䤣�� ( ��O�渹[%s], ����[%s] (�T�~��) )",last_ply,tmp_car_type);
                    Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                    continue;
                }  
            }
            
            if (tmp_ply_period == 48 )
            {
                $SELECT mbusiness
                   INTO $tmp_mbusiness_21_4
                   FROM compulsory_premium
                  WHERE icar_type = $tmp_car_type
                    AND qperiod   = $tmp_ply_period
                    AND ((qcar_personbgn <= $qpt AND qcar_personend >= $qpt) OR (qcar_personbgn = 0))
                    AND drate = (SELECT drate  FROM ca_rate_date WHERE icode  = $comp_frate  AND itable = 'compulsory_premium')
                    AND fassured = $comp_fassured;
                 
                if (NOT_FOUND)
                {
                    sprintf_s(v_errMsg,sizeof v_errMsg, "�j���I�O�v���(car101)�䤣�� ( ��O�渹[%s], ����[%s] (�|�~��) )",last_ply,tmp_car_type);
                    Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                    continue;
                }  
            }
            
            if (tmp_ply_period == 60 )
            {
                $SELECT mbusiness
                   INTO $tmp_mbusiness_21_5
                   FROM compulsory_premium
                  WHERE icar_type = $tmp_car_type
                    AND qperiod   = $tmp_ply_period
                    AND ((qcar_personbgn <= $qpt AND qcar_personend >= $qpt) OR (qcar_personbgn = 0))
                    AND drate = (SELECT drate  FROM ca_rate_date WHERE icode  = $comp_frate  AND itable = 'compulsory_premium')
                    AND fassured = $comp_fassured;
                 
                if (NOT_FOUND)
                {
                    sprintf_s(v_errMsg,sizeof v_errMsg, "�j���I�O�v���(car101)�䤣�� ( ��O�渹[%s], ����[%s] (���~��) )",last_ply,tmp_car_type);
                    Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                    continue;
                }  
            }
            
            tmp_mbusiness_21 = tmp_mbusiness_21 + tmp_mbusiness_21_2 + tmp_mbusiness_21_3 + tmp_mbusiness_21_4 + tmp_mbusiness_21_5;
            printf("end compute commission\n");
              
            printf("-- trace tmp_mbusiness_21[%f]\n ",tmp_mbusiness_21);
            printf("-- trace busi_discount[%d]\n ",busi_discount);
            ZA_mbusiness = tmp_mbusiness_21 - busi_discount;
            printf("-- trace ZA_mbusiness[%f]\n ",ZA_mbusiness);


            /******************************* get �j���I����Ocmn144 ********************/
            
            rc = get_iins_cat(car_typei1, 1, ply1_period, iins_cat1, iyear, v_sMsg);
            if( rc != M_CM_OK)
            {
                strcpy(v_errMsg, cm_get_errmsg(rc));
                Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                continue;
            }
             
            rc = get_commission_agent( iins_cat1, broker1, "21", iyear, comp_frate,
                                       &broker_pagent, &broker_pdisc, &broker_pcommi, &dbl_mservice, &mother_busi,
                                       icheck_disc, icheck_commi, icheck_agent, icheck_busi, ipaid_base,
                                       &pfix_agent, icheck_mservice, itype_disc, fstart1,
                                       officer1, iroute, irate_type1, iroute_comm1, "P", v_sMsg );
            if(rc != M_CM_OK)
            {
                strcpy(v_errMsg, cm_get_errmsg(rc));   strcpy(v_errMsg, rtrim(v_errMsg));
                Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);	
                continue;
            }
            mservice = (long)dbl_mservice;              
            printf("-- get_commission_agent() mservice[%ld]\n ",mservice);
                                                  
        }
        

        
        /* --------------------------- ���O �B�z �� ---------------------------*/
        /*
           �O�d���O�G03���O(�[�O�t��)�B115���O(���@��)�A��l�M��
           �s�W���O�G(1) 37���O(��Oú��)
                     (2)102���O(�۰ʥX��)
                     (3)103���O(�n�O�ѥ��^(�۰ʥX��)) (��j���~)	    */
        
        fambulance = 0; /* �O�_���O115���@�� 0:�_ 1:�O (1120316006_SC1) */
        if(equip_cmp(equipment,"115") == TRUE) fambulance = 1;
        
        
        if (equipment[2] == '1')
        {
            strcpy( equipment, "001000000000000000000000000000");
        }
        else   
        {
            strcpy( equipment, "000000000000000000000000000000"); 
        }  
        
        strcpy(equipment_tmp, equip_insert(equipment,"37"));
        strcpy(equipment    , equipment_tmp);
        /* 1070531010-SC1-��ã��-�]�������۰ʥX��\��A�ק�CAR301�wú�W�[��j�d�� +�����n�O�ѥ��^�����O
           ��R�}�Y���y�Ǹ��������³W�h�B�z(�t���N)	���O+102+103�A��L���A�B�z103
           1070531010-SC2-�O�d102�~��C�Lcar322�n�O��*/

        strcpy(equipment_tmp, equip_insert(equipment,"102"));
        strcpy(equipment    , equipment_tmp);
        if (strlen(trim(sIscan_no)) >0)
        { 
            if (ply2f == TRUE)
            {
                strcpy(equipment_tmp, equip_insert(equipment,"103"));	
                strcpy(equipment    , equipment_tmp);
            }
        }
        
        if(fambulance == 1) /* �٭���O115���@�� (1120316006_SC1)*/
        {
            strcpy(equipment_tmp, equip_insert(equipment,"115"));
            strcpy(equipment    , equipment_tmp);	
        } 
        
        
        /*  --------------------------- ���O �B�z �� ---------------------------*/
        
        
                              
        /** �s�¨��P�_�A�@�w���¨� **/
        strcpy(icar_flag, "2");
        strcpy(icar_flag1, "2");
        strcpy(icar_flag2, "2");

        /************************** STEP 10 **********************************/
        premium = premium1+premium2;

        /************************** STEP 11 **********************************/

        if (drnw_print==DATENULL)
           msg_code=M_CA_PLY_NDUE;

        /************ STEP 12 policy_expire ************/
        $SELECT ipart INTO $ipart
           FROM policy_expire
          WHERE ipolicy = $last_ply;


        /*** �X�� ***/
        rc=Car3011_A();
        if (rc != M_CM_OK)
        {
            
            if (rc<0)
            {                                          
                sprintf_s(TMP_MSG,sizeof TMP_MSG,"[���~]SQLCODE=[%d]sqlca.sqlerrm=[%s],sqlca.sqlerrd[1]=[%d]�A�Ь���T��", rc,sqlca.sqlerrm,sqlca.sqlerrd[1]);
                
                if(strlen(trim(v_errMsg)) > 0)
                    strcat(v_errMsg, rtrim(TMP_MSG));
                else
                    strcpy(v_errMsg, rtrim(TMP_MSG));
            }
            else
            {   
                if(strlen(trim(v_errMsg)) == 0)
                { 
                    strcpy(v_errMsg, cm_get_errmsg(rc));
                    
                    if(strlen(trim(v_errMsg)) == 0)  /*ex. 3568:�S��������������~�T��*/
                    {
                        sprintf_s(v_errMsg,sizeof v_errMsg,"���~�T���N�X:[%d]",rc);
                    }
                }
            }
            
            Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
            
            continue;
        }
    }
    $CLOSE curtmp;
    $FREE curtmp;

    return M_CM_OK;
    


opt1_R2_err:
    printf("SQLSTATE_R2[%s]\n", SQLSTATE);
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    sprintf_s(v_errMsg,sizeof v_errMsg,"Car3011_R2()���~:SQLCODE=[%d]sqlca.sqlerrm=[%s],sqlca.sqlerrd[1]=[%d]", SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);        
    return SQLCODE;
}

static Car3011_R5()
{
    $char   stmt[10000],TMP_MSG[512];
    $char   drate_ym[5],ipay_way[2],iyear[2];
    int     rt_Kind,fambulance;
    $char   local_dbname[20];
    char    sDbirth[11], sDply_begin[11];
    double  mother_busi,dbl_mservice;
    char    icheck_busi[2], icheck_mservice[2];
    $double pextra_charge;/* ���[�O�βv */	
    $date   dcoll_last;
    $char   abnormal_est[POLICY_NUM_1];
    $char   tmp_ipolicy1[21], tmp_ipolicy2[21], RouteCAJ[2], tmp_car_type[3]=" ";
    /* �s�r���� add by sylvia 103.01.10 (1020801002_C1) */
    /* ���j�H�W���� add by 061476 111.06.14 (1110608012_SC1) */
    $long   Qmdrunk_prem, Qmviolate_prem;
    $double Qmdrunk_pure_prem, Qmviolate_pure_prem;
    
    $int    busi_discount=0; /* xxx*/
    $WHENEVER SQLERROR GOTO opt1_R5_err;

    fuw_status = 500;
    stmt[0]='\0';

    strcpy(local_dbname, get_full_dbname(localdb));

    printf("Car3011_R5\n");
    
    /*1060817004-C1 �q�lñ�p sIscan_no*/
    sprintf_s(stmt,sizeof stmt," SELECT iestimate,dcoll_last,nvl(iscan_no,'') "
                               "   FROM car3011_temp WHERE iestimate matches '*CVQ*' ");

    $PREPARE cur_tmp1 FROM $stmt;
    $DECLARE curtmp_R5 CURSOR WITH HOLD for cur_tmp1;
    $OPEN curtmp_R5;
    while (1)
    {
        InitData();/* 1090117010-SC1-��ã��-�ק�CAR301��Ưd�s���D*/
        $FETCH curtmp_R5 INTO $estimatei,$dcoll_last,$sIscan_no; 
        if (NOT_FOUND) break;

        printf("estimatei[%s]\n",estimatei);

        rtncode = ca_quote_to_est(estimatei, localdb, &fstate, sMsg);
	printf("**********fstate[%d],sMsg[%s]*********\n",fstate,sMsg );

        if (rtncode != M_CM_OK) 
        {
            strcpy(v_errMsg, cm_get_errmsg(rtncode));
            Update_car3011_temp(estimatei, "1", " ", " ", " ", " ", " ", " ", " ", v_errMsg);
            continue;
        }

        $SELECT icard1,icard2,ilast_ply,ilast_card,irelative_card,ixxcard,
                nvl(qply2_period,0), dply2_begin,dply2_end,
                nvl(qply1_period,0), dply1_begin,dply1_end,
                fassured, iassured, iassured_ext,
                nassured,ilicense,fsex,fmarriage,
                nuser,ibenef,nbenef,aassured, aassured_zip,
                itel, nvl(itel_night,' '), mobil_phone, iemail,
                iply_area,apayment, apayment_zip,
                ipro_year, ibrand,nbrand_abbr,icar_type2,icar_type1,
                fcar_note2,qcylinder,iengine,ibody,itag,
                mcar_price,nequipment,
                pdmg_align,pbrg_align,plia_align,fcut,
                nvl(mpremium2,0), nvl(mpremium1,0), ibig_branch,
                ibig_office,ibig_sales,iresource,
                ibroker2,ibroker1, iofficer2,iofficer1, icorps,
                iarea, iexaminer,fcal_way,pdmg_factor,pbrg_factor,qpt,fpt,
                nvl(psex_age2,0), nvl(psex_age1,0), psex_age_damage,plia_acc2,plia_acc1,pdmg_acc,
                lia_class,dmg_acc_1st,dmg_acc_2nd,dmg_acc_3rd,
                fcomp_24,fbig_ply,iabn_type,
                fcomp_class,fcomp_class_last,mbusiness,
                fdiscount,ibig_comp, dapply,ipay_way,icar_flag1,icar_flag2,
                trans_prem, transno,
                ipolicy1, ipolicy2, iinstall, iquery_num, iquery_num_c,
                iext_policy, qpro_month, mkilo_ply, irisk, irelative_ext,
                napplicant, dbirth, dissue,
                iextra_charge, gextra_charge, pextra_charge,
                iquery_num_damage, introducer, mequipment,
                survey_num, bound_num, abnormal_num, iapplicant, iaccept, idm_number, iroute_prop, iroute,
                nfax_cus, nemail_cus, nroute_cus, nname_cus, itel_cus, mobil_phone_cus, nnote_cus, nnote_leader,
                decode(decode(iroute[1,2],'CA','T','F'),'T','T',decode(iroute[1,1],'J','T','F')),
                irate_type1, bzfrom1, iroute_comm1, icomm_obj1,
                irate_type2, bzfrom2, iroute_comm2, icomm_obj2, qprovision,
                isecond_hand, icard_main, qlia_acc_sum, qdmg_acc_sum,
                fapplicant, fsex_appl, dbirth_appl, itel_appl,
                ndeputy_appl, nrelation_appl, ndeputy_assured,
                fuw_status, iuw_first, duw_first,
                pdmg_acc2, qdmg_acc_sum2, iquery_num_damage2, 
                pdmg_acc3, qdmg_acc_sum3, iquery_num_damage3, 
                dcomp_lastdend,qdrunk_driving,fout_print, fmail_type,icomp_cartype_last,isign ,ibound,isurvey,
                npost_recipient,apost_zip,apost_address,iins_kit,mcover_limit,iassured_cntry , iapplicant_cntry,nassured_cntry,napplicant_cntry,
                foccup, applicant_foccup, noccup, applicant_noccup,
                funknown_dmg,fequipment1,fequipment2,fequipment3,fequipment4,fequipment5,fequipment6,fequipment9,nequipment9,ftrans_trade,feply, 
                feterms,
                aemail_eply,tmobile_eply,
                punknown_acc,qunknown_acc_sum,iquery_num_unknown,punknown_acc2,qunknown_acc_sum2,iquery_num_unknown2,ipolicy_last_brg, dply_end_last_brg, iquery_num_last_brg,
                abnormal_est,tmobile_appl,aemail_appl,fecard,ireg_no,qviolate
           INTO $card1,$card2,$last_ply,$last_card,$relative_card,$xxcard,
                $ply2_period,$ply2_begin,$ply2_end,
                $ply1_period,$ply1_begin,$ply1_end,
                $assuredf,$assuredi, $assuredi_ext,
                $assuredn,$license,$sex,$marriage,
                $user,$benefi,$benefn,$assureda, $assureda_zip,
                $tel, $tel_night, $mobil_phone, $iemail,
                $ply_area, $paymenta, $paymenta_zip,
                $pro_year,$brandi,
                $brandn,$car_typei2,$car_typei1,$fcar_note2,
                $cylinder,$engine,$body,
                $tagnum,$car_price,$equipment,
                $dmg_align,$brg_align,$lia_align,$cutf,
                $premium2,$premium1,
                $big_branch,$big_office,$big_sales,$resource,
                $broker2,$broker1, $officer2,$officer1, $sIcorps,
                $area,$examiner,$cal_way,
                $pdmg_factor_1st,$pbrg_factor_1st,$qpt,$fpt,
                $psex_age2,$psex_age1,$psex_age_damage,$plia_acc2,$plia_acc1,$pdmg_acc,
                $lia_class,$dmg_acc_1st,$dmg_acc_2nd,$dmg_acc_3rd,
                $fcomp_24,$fbig_ply,$abn_type,
                $comp_class,$comp_class_last,$mbusiness,
                $fdiscount,$ibig_comp, $lDapply,$ipay_way,$icar_flag1,$icar_flag2,
                $trans_prem,$sTransNo,
                $tmp_ipolicy1, $tmp_ipolicy2, $iinstall, $iquery_num, $iquery_num_c,
                $iext_policy, $qpro_month, $mkilo_ply, $irisk, $irelative_ext,
                $napplicant, $dbirth, $dissue,
                $iextra_charge, $gextra_charge, $pextra_charge,
                $iquery_num_damage, $introducer, $mequipment,
                $survey_num, $bound_num, $abnormal_num, $iapplicant, $iroute_accept, $idm_number, $iroute_prop, $iroute,
                $nfax_cus, $nemail_cus, $nroute_cus, $nname_cus, $itel_cus, $mobil_phone_cus, $nnote_cus, $nnote_leader,
                $RouteCAJ,
                $irate_type1, $bzfrom1, $iroute_comm1, $icomm_obj1,
                $irate_type2, $bzfrom2, $iroute_comm2, $icomm_obj2, $qprovision,
                $isecond_hand, $icard_main, $qlia_acc_sum, $qdmg_acc_sum,
                $fapplicant, $fsex_appl, $dbirth_appl, $itel_appl,
                $ndeputy_appl, $nrelation_appl, $ndeputy_assured,
                $fuw_status, $iuw_first, $duw_first,
                $pdmg_acc2, $qdmg_acc_sum2, $iquery_num_damage2, 
                $pdmg_acc3, $qdmg_acc_sum3, $iquery_num_damage3, 
                $dcomp_lastdend, $qdrunk_driving,$fout_print, $fmail_type,$icomp_cartype_last,$isign,$ibound_x,$isurvey_x,
                $npost_recipient, $apost_zip, $apost_address,$iins_kit, $mcover_limit,$iassured_cntry , $iapplicant_cntry,$nassured_cntry,$napplicant_cntry,
                $foccup, $applicant_foccup, $noccup, $applicant_noccup,
                $funknown_dmg,$fequipment1,$fequipment2,$fequipment3,$fequipment4,$fequipment5,$fequipment6,$fequipment9,$nequipment9,$ftrans_trade,$feply,
                $feterms,
                $aemail_eply,$tmobile_eply,
                $punknown_acc,$qunknown_acc_sum,$iquery_num_unknown,$punknown_acc2,$qunknown_acc_sum2,$iquery_num_unknown2,$ipolicy_last_brg, $dply_end_last_brg, $iquery_num_last_brg,
                $abnormal_est,$tmobile_appl,$aemail_appl,$fecard,$sIreg_no,$qviolate
           FROM estimate
          WHERE iestimate=$estimatei;
                                    
        if (NOT_FOUND) 
        {
            sprintf_s(v_errMsg,sizeof v_errMsg,"�����渹[%s]��Ƥ��s�b",estimatei);
            Update_car3011_temp(estimatei, "1", " ", " ", " ", " ", " ", " ", " ", v_errMsg);
            continue;
        }               
				        
	/*------------------ ��l�ܼ� �� ----------------------*/ 
       
        strcpy(assuredi, trim(assuredi)); 
        strcpy(card2," ");
        strcpy(fcomp_24, "N");    
        mcommission21=0;
        tmp_ipolicy1[0]='\0';  tmp_ipolicy2[0]='\0';
        Qmdrunk_prem = 0;      Qmdrunk_pure_prem = 0;
        Qmviolate_prem = 0;    Qmviolate_pure_prem = 0;
        ply1f = FALSE;  ply2f = FALSE;
		
	psex_age_damage=0;
	psex_age1=0;  psex_age2=0;
	strcpy(itmp_policy,estimatei);
	
	/*------------------ ��l�ܼ� �� --------------------*/ 
		
	/*********************** STEP 2 ***********************************/
        strcpy(body   , rtrim(body));
        strcpy(engine , rtrim(engine));
        strcpy(assuredi  , trim(assuredi)); 
        strcpy(iapplicant, trim(iapplicant));    
	strcpy(officer,officer1);    
		
		
		
	/* ���o�޲z�H������T */
        $SELECT a.ileader,a.iquota,b.nbranch
           INTO $sIleader,$sIquota,$sNquota
           FROM officer a,sa_branch_type b
          WHERE a.iquota = b.ibranch
            AND a.iofficer = $officer;
		
	if (strlen(trim(abnormal_est)) > 0)
        {
            sprintf_s(v_errMsg,sizeof v_errMsg, "���`��(%s):�w���o���`��,�ХH���`���X��C",abnormal_est);
            Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
            continue;
        }

	/*1080408005-SC5-�j��{�ҷs�W�q����Ƥεn���Ҹ��ɵ{�ˮֱj���I�ӫO����쬰����J*/
        if ((strlen(trim(sIreg_no))==0) && (strlen(trim(officer))>0) &&  (strncmp(bzfrom1,"10",2)==0 || strncmp(bzfrom1,"20",2)==0 || strncmp(bzfrom1,"30",2)==0|| strncmp(bzfrom1,"40",2)==0))
        {
            sprintf_s(v_errMsg,sizeof v_errMsg , "�ӫO�j���I�ɡA�~�ȭ��n���Ҧr��������J���A�Ь��ӫO���ӫ~��;");
            Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
            continue;
        }

        /*  ��O���O= 5 (��������q����) �� ������j��A
	    ���N�I������춷�����ťա��Τ����ȡG�O���B�O�I�_���B�O�I�����B�g��N���B�I�ة���
            
            �j��O�I�_�� = ���ú�ڤ�  (1101214006_SC1)
            �j��O�I���� = �j��O�I�_�� + 1�~    */
        if (strlen(trim(officer)) > 0)
	{
	    printf(" {Car3011_R5}:dcoll_last[%ld]\n ",dcoll_last);
	    ply1_begin  = dcoll_last;
	    printf(" {Car3011_R5}:ply1_begin[%ld]\n ",ply1_begin);

	    ply1_period = 12 ;
	    $select first 1 date_add( $ply1_begin, interval(1) year to year) 
	       into $ply1_end
	       from systables;
	    printf(" {Car3011_R5}:ply1_end[%ld]\n ",ply1_end);	
	}
	else
	{
	    sprintf_s(v_errMsg,sizeof v_errMsg, "��������q����������j���I;");
	    Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", " ", " ", v_errMsg);
	    continue;            
	}        
                
        /* ---------------------------------- [DataCheck1()] -----------------------------------*/
        rc = DataCheck1();  
        if (rc != M_CM_OK)
        {                    
            if(strlen(trim(v_errMsg)) == 0)
            {
                strcpy(v_errMsg, cm_get_errmsg(rc));
            }        
            printf("v_errMsg[%s]\n",v_errMsg);
            Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
            continue;
        }
        else   
        {    
            if(strlen(trim(v_errMsg)) > 0) /* �����T�� */
            {
                Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);         
            }
        }           
        /* ---------------------------------- [DataCheck1()] -----------------------------------*/  
        
        strcpy(iofficer_prmt, " "); strcpy(iquota_prmt," ");   strcpy(ileader_prmt," ");  
        
        /* �e�~�C�L */ 
        strcpy(fout_print,"1");  strcpy(fmail_type,"1");
        rc = ChkOutPrint(estimatei,iroute,iofficer,&rt_Kind);        
        if (rc == FALSE)
        { 
            if (strlen(trim(v_errMsg)) == 0 )
            {      
                if (rt_Kind > 0) 
                {
                    strcpy(fout_print,"0");  strcpy(fmail_type,"0");
                    
                    if (rt_Kind==250)
                    {
                        strcpy(v_errMsg ,"�����G�����(�����渹�e�T�X)");
                    }
                    else if (rt_Kind==100)
                    {
                        sprintf_s(v_errMsg,sizeof v_errMsg,"�����G��[�q���N��(%s) + �g��H�N��(%s)]",iroute, iofficer);
                    }
                    else if (rt_Kind==150)
                    {
                        sprintf_s(v_errMsg,sizeof v_errMsg,"�����G�������渹(%s)(car646)",estimatei);	
                    }
                    strcat(v_errMsg , " �w�]�w���u��(�i)�e�~�C�L�v; ");
                    Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                }
            }
            else
            {
                strcpy(v_errMsg, rtrim(v_errMsg));
                Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                continue;
            }
        }
		
	if((feply[0] == '2' || feply[0] == '1'))
	{
	    strcpy(fecard,"1");
	    if ((strlen(trim(aemail_eply))==0) && (strlen(trim(tmobile_eply))==0))
	    {   
	        /*1091007004-SC1-���ʱo-�~�ȭ��q��(10)�ΫO�o�q��40��KA�q���۰ʵo�e�j��q�l����*/
		/*1101206002_SC1_�j��q�l���ұH�o�@�~�X�j-���q��*/
		strcpy(tmobile_eply,tmobile_appl);
		strcpy(aemail_eply,aemail_appl);
	    }
	}
	else 
	{ 
	    /* �j��q�l���ұH�o�@�~�X�j-���q��
	       �B�ȥ��z�����|���q�l�O��������A�G�@�ߦ^�ɦ��n�O�H�p����T (1101206002_SC1) */
	    strcpy(fecard,"0");
	    strcpy(aemail_eply,aemail_appl);
	    strcpy(tmobile_eply,tmobile_appl);	/* 1080417001-SC1-���ά�-�s�W�q�l�O��H²�T�覡�o�e*/
	}
	strcpy(feterms , "0");  /*  1100419003-SC1-���I�O�����QR Code�q�l��  */
		
	rc = get_iins_cat( car_typei1, 1, ply1_period, iins_cat, iyear, v_sMsg );     
        if( rc != M_CM_OK)
        {
            strcpy(v_errMsg, cm_get_errmsg(rc));
            Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
            continue;
        }
		
	/** get �j��O�v�ͮĥN�� **/
        stmt[0]='\0';
	sprintf_s(stmt,sizeof stmt,"SELECT drate_ym,mcommission,"
                                   "       mdrunk_prem, mdrunk_pure_prem, mviolate_prem, mviolate_pure_prem "
                                   "  FROM est_ins_type"
                                   " WHERE iestimate='%s'"
                                   " ORDER BY qserial DESC", estimatei);

        $PREPARE prep_est2 FROM $stmt;
        $DECLARE curtmp_R52 CURSOR FOR prep_est2;
        $OPEN curtmp_R52;
        while (1)
        {
            $FETCH curtmp_R52
              INTO $drate_ym,$mcommission
                   $Qmdrunk_prem, $Qmdrunk_pure_prem, $Qmviolate_prem, $Qmviolate_pure_prem;

            if (NOT_FOUND) break;

            strcpy(comp_frate,drate_ym);
            mservice      = mcommission;  /* �j���I����O */
            mcommission21 = mcommission;
            Gdrunk_prem = Qmdrunk_prem;
            Gdrunk_pure_prem = Qmdrunk_pure_prem;
            mviolate_prem = Qmviolate_prem;
            mviolate_pure_prem = Qmviolate_pure_prem;
	}
	$CLOSE curtmp_R52;
        $FREE  curtmp_R52;		
        
	/*********************** STEP 2 ***********************************/
	/* �j���I */
	ply1f = TRUE;
	strcpy(policy1    , last_ply);		
	strcpy(policy2    , " ");		
	strcpy(car_typei2 , " ");
	strcpy(officer2   , " ");
	strcpy(bzfrom2, " ");         /* �O�o�q���N�� -- �t�X�q���G�ק� */
	strcpy(irate_type2," ");      /* �O�v�O -- �t�X�q���G�ק� */
	strcpy(iroute_comm2," ");     /* �~�ȱ���N�� -- �t�X�q���G�ק� */
	strcpy(icomm_obj2, " ");      /* �I����H -- �t�X�q���G�ק� */

	sDbirth[0] = '\0';
	sDply_begin[0] = '\0';
	strcpy( sDbirth,     cm_cdate_str_100(dbirth));
	strcpy( sDply_begin, cm_cdate_str_100(ply1_begin));
	
	rc = get_age( sDbirth, sDply_begin, &age, v_sMsg);
	if( rc != M_CM_OK) /*return rc;*/
	{
	    strcpy(v_errMsg, cm_get_errmsg(rc));
	    Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ",  fout_print, feply, v_errMsg);
	    continue;
	}
			
	if (assuredf[0]=='1' || assuredf[0]=='3' || assuredf[0]=='5')  /*** �۵M�H ***/
	{
	    /* �j�� */
	    rc = get_sex_age_factor( "1", &age, sex, comp_frate, &psex_age1, v_sMsg);
	    if( rc != M_CM_OK) /*return rc;*/
	    {
	        strcpy(v_errMsg, cm_get_errmsg(rc));
		Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
		continue;
	    }
	}

	busi_discount = 0; /* �j���I�������B */
	if (irate_type1[0]!='C')
	{
	    $SELECT (mprem - ori_premium) into $busi_discount 
	       FROM ply_ins_type_302
	      WHERE ipolicy = $last_ply
		AND iins_type = '21';
	}                                   				

        printf(" {Car3011_R5}:age[%d],psex_age1[%lf]\n",age,psex_age1);
        printf(" {Car3011_R5}:busi_discount[%f]\n",busi_discount);

        /*********************** STEP 3 ***********************************/
	/* ��O��J�@�ߥH�@�~���� */
	if (*cal_way=='M')  /*Get Short Period Rate*/
	{
	    $SELECT prate INTO $short_prate_1
	       FROM short_period_rate
	      WHERE qperiod = 12;

	    if (NOT_FOUND)  /*return M_CA_NSHORT_RATE;*/                 			
	    {
	        strcpy(v_errMsg, cm_get_errmsg(M_CA_NSHORT_RATE));  
		Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
		continue;
	    }
	    short_prate_1=short_prate_1/100.0;
	}
	else
	{
	    $select first 1 ($ply1_end - $ply1_begin) /
			    (date_add( $ply1_begin, interval(1) year to year) - $ply1_begin)
	       into $short_prate_1
	       from systables;
	}
	printf(" {Car3011_R5}:short_prate_1[%f]\n",short_prate_1);
		
	/* �qofficer ��̷s������� */
	$select irate_type,iroute_comm,icomm_obj
	   into $irate_type1,$iroute_comm1,$icomm_obj1
	   from officer 
	  where iofficer = $officer; 
		  
	/* ���s���o �O�o�q���N�� */    
	rc = cm_get_bzfrom( officer, icomm_obj1, irate_type1, bzfrom1);
	if( rc != M_CM_OK)
	{
	    strcpy(v_errMsg, cm_get_errmsg(rc));   
	    Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
	    continue;
	}
	strcpy(iextra_charge, bzfrom1);
																	
	$double tmp_mbusiness_21_2;
			  
	tmp_mbusiness_21 = 0.0; tmp_mbusiness_21_2 = 0.0;
		
	/* car9712022 �j���I�ȳf������۵M�H�k�H�O�v */
	rc = get_comp_car_type_fassured( car_typei1, comp_frate, assuredf, tmp_car_type, comp_fassured, v_sMsg);
	if ( rc != M_CM_OK)
	{
	    sprintf_s(v_errMsg,sizeof v_errMsg,"�j���I�O�v�ͮĤ�(car120)�䤣�� ( �����渹[%s] )",estimatei);
	    Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
	    continue;
	}

	$SELECT mbusiness
	   INTO $tmp_mbusiness_21
	   FROM compulsory_premium
	  WHERE icar_type = $tmp_car_type
	    AND qperiod   = 12
	    AND ((qcar_personbgn <= $qpt AND qcar_personend >= $qpt) OR (qcar_personbgn = 0))
	    AND drate = (SELECT drate  FROM ca_rate_date WHERE icode  = $comp_frate  AND itable = 'compulsory_premium')
	    AND fassured = $comp_fassured;

	if (NOT_FOUND)
	{
	    sprintf_s(v_errMsg,sizeof v_errMsg, "�j���I�O�v���(car101)�䤣�� ( ��O�渹[%s], ����[%s] )",last_ply,tmp_car_type);
	    Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
	    continue;
	}

	tmp_mbusiness_21 = tmp_mbusiness_21 + tmp_mbusiness_21_2;
	ZA_mbusiness = tmp_mbusiness_21 - busi_discount;
		
	printf(" {Car3011_R5}:tmp_mbusiness_21[%f]busi_discount[%d]\n ",tmp_mbusiness_21,busi_discount);
	printf(" {Car3011_R5}:ZA_mbusiness[%f]\n ",ZA_mbusiness);

	/******************************* get �j���I����Ocmn144 ********************/
	rc = get_iins_cat(car_typei1, 1, ply1_period, iins_cat, iyear, v_sMsg);
	if( rc != M_CM_OK)
	{
	    strcpy(v_errMsg, cm_get_errmsg(rc));
	    Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
	    continue;
	}
		 
	rc = get_commission_agent( iins_cat, broker1, "21", iyear, comp_frate,
				   &broker_pagent, &broker_pdisc, &broker_pcommi, &dbl_mservice, &mother_busi,
				   icheck_disc, icheck_commi, icheck_agent, icheck_busi, ipaid_base,
				   &pfix_agent, icheck_mservice, itype_disc, fstart1,
				   officer1, iroute, irate_type1, iroute_comm1, "P", v_sMsg );
	if(rc != M_CM_OK)
	{
	    strcpy(v_errMsg, cm_get_errmsg(rc));   strcpy(v_errMsg, rtrim(v_errMsg));
	    Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);	
	    continue;
	}
	mservice = (long)dbl_mservice;              
	printf(" {Car3011_R5}:get_commission_agent() mservice[%ld]\n ",mservice);

        /* --------------------------- ���O �B�z �� ---------------------------
           (1120307006_SC1_�Эק�CAR3011���O���n�^��(�۰ʥX����O102))
           �O�d���O�G03���O(�[�O�t��)�A��l�M��
           �s�W���O�G(1)102���O(�۰ʥX��)*/
           
        fambulance = 0; /* �O�_���O115���@�� 0:�_ 1:�O (1120316006_SC1) */
        if(equip_cmp(equipment,"115") == TRUE) fambulance = 1;
           
        if (equipment[2] == '1')
        {
            strcpy( equipment, "001000000000000000000000000000");
        }
        else   
        {
            strcpy( equipment, "000000000000000000000000000000"); 
        }  
        
        strcpy(equipment_tmp, equip_insert(equipment,"102"));
        strcpy(equipment    , equipment_tmp);
        
        if(fambulance == 1) /* �٭���O115���@�� (1120316006_SC1)*/
        {
            strcpy(equipment_tmp, equip_insert(equipment,"115"));
            strcpy(equipment    , equipment_tmp);	
        }
        
        
        /* --------------------------- ���O �B�z �� ---------------------------*/


        /*********************** STEP 5 ***********************************/   
        premium = premium1+premium2;

        if (drnw_print==DATENULL)
            msg_code=M_CA_PLY_NDUE;

        /*** �X�� ***/
        rc=Car3011_A();
        if (rc != M_CM_OK)
        {     
            if (rc<0)
            {                                          
                sprintf_s(TMP_MSG,sizeof TMP_MSG,"[���~]SQLCODE=[%d]sqlca.sqlerrm=[%s],sqlca.sqlerrd[1]=[%d]�A�Ь���T��",rc,sqlca.sqlerrm,sqlca.sqlerrd[1]);
                
                if(strlen(trim(v_errMsg)) > 0)
                    strcat(v_errMsg, rtrim(TMP_MSG));
                else
                    strcpy(v_errMsg, rtrim(TMP_MSG));
            }
            else
            {   
                if(strlen(trim(v_errMsg)) == 0)
                {
                     
                    strcpy(v_errMsg, cm_get_errmsg(rc));
                    
                    if(strlen(trim(v_errMsg)) == 0)  /*ex. 3568:�S��������������~�T��*/
                    {
                       
                        sprintf_s(v_errMsg,sizeof v_errMsg,"���~�T���N�X:[%d]",rc);
                    }
                }
            }
            
            Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
            continue;
        }
    }
    $CLOSE curtmp_R5;
    $FREE curtmp_R5;

    return M_CM_OK;
    

opt1_R5_err:
    printf("SQLSTATE_R5[%s]\n", SQLSTATE);
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    sprintf_s(v_errMsg,sizeof v_errMsg,"Car3011_R5()���~:SQLCODE=[%d]sqlca.sqlerrm=[%s],sqlca.sqlerrd[1]=[%d]", SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);        
    return SQLCODE;
}
static Car3011OptQL(type)
char type;
{
    $char   fins_grp[1+1];
    $char   stmt[10000],TMP_MSG[512];
    $char   abnormal_est[POLICY_NUM_1];
    $char   sIquotax1[7],sIquotax2[7];
    int     yy1;
    char    yy[3], mm[3], dd[3];
    $char   tmp_fcard_class[2], tmp_card[CARD_NUM];
    $char   tmp_rel_ply[POLICY_NUM_1], tmp_fcar_note[3];
    $int    tmp_ply_period,t_count=0;
    $date   tmp_ply_begin, tmp_ply_end;
    $long   tmp_mdmg_prem, tmp_mlia_prem;
    $double tmp_psex_age, tmp_plia_acc, tmp_pdmg_acc,tmp_punknown_acc;
    $char   tmp_ipolicy1[21], tmp_ipolicy2[21], itmp_estimate[21];
    $char   tmp_pfix_agent[10];
    $char   broker_tmp[11];
    $char   iyear[2], tmp_iins_type[INSURANCE_TYPE];
    long    code,idate ,fRtnCode;
    char    ymd[12];
    int     ins33_flag;    /*** �P�_�O�_���ӫO33�I�� ***/
    int     ins48_flag, ins35_flag, ins56_flag, ins136_flag, ins166_flag, ins266_flag;
    char    tmp_ply2_begin[11], local_dbname[21];
    char    iym_ply2_begin[6];
    $int    tmp_iym_ply2_begin;
    $char   last_frate_comp[5]=" ", last_frate_volu[5]=" ";

    /* GCAR�������[���ڷs�W���     */
    $int    irate;
    $double adjust_rate;
    $double mins_premium_n;
    $double mpure_prem_n;
    $long   mprem_n;

    /* 'car9610231��~�βĤT�H�f�B�~���[���� */
    $double safe_rate;
    $double manage_rate;
    $double educated_rate;

    /* �«O�O�����v */
    $double deviation_rate;
    $double pextra_charge;/* ���[�O�βv */
    $double pbusiness;     /* �~�޶O�βv */
    $double psex_age;     /* �I�ةʧO�~�֫Y�� */
    $double pshipping;    /* car9808043 �f�B�~���[����C */

    /* ��e���I�g�P�ӷ~�Ȥγ�줽�~�Ȫ��d���v��(�q���N���e�G�X=CA�γq���N���e�@�X=J add by sylvia 99.12.27  */
    $char RouteCAJ[2], sIquota1[7], sIquota2[7], sGroup[7];
    $char cus_email[51], cus_tel_night[21], cus_mobil_phone[21];/* �ȪA��P��EMAIL */
    $char fproject[2];/* ���O�X��--�M���ذe���O add by sylvia 102.03.11 */
    
    /* �s�r�[�O */
    $long    Qmdrunk_prem;
    $double  Qmdrunk_pure_prem;
    
    /* ���j�H�W�[�O */
    $long    Qmviolate_prem;
    $double  Qmviolate_pure_prem;
    
    $char stmt_buf[513];
    /*$int  chkECAR;*/
    
    
    EXEC SQL WHENEVER SQLERROR GOTO optql_err;

    msg_code=M_CM_OK;                    /* set default return message code */
     


    strcpy(local_dbname, get_full_dbname(localdb));


    printf("Car3011OptQL\n");
    /*1060817004-C1 �q�lñ�p */
    sprintf_s(stmt,sizeof stmt," SELECT ilast_ply,iestimate,nvl(iscan_no,' ') "
                               "   FROM car3011_temp WHERE iestimate not like '%%CR%%' ");

    $PREPARE prep_q FROM $stmt;
    $DECLARE cur_tmpQ CURSOR WITH HOLD for prep_q;
    $OPEN cur_tmpQ;
    while (1)
    {
        InitData();/* 1090117010-SC1-��ã��-�ק�CAR301��Ưd�s���D*/
        $FETCH cur_tmpQ INTO $last_ply,$estimatei,$sIscan_no;
        if (NOT_FOUND) break;

        strcpy(v_errMsg,"");
        printf("last_ply[%s]estimatei[%s]\n",last_ply,estimatei);

        
        rtncode = ca_quote_to_est(estimatei, localdb, &fstate, sMsg);
        printf("**********fstate[%d],sMsg[%s]*********\n",fstate,sMsg );
        if (rtncode != M_CM_OK) 
        {
            strcpy(v_errMsg, cm_get_errmsg(rtncode));
            Update_car3011_temp(estimatei, "1", " ", " ", " ", " ", " ", " ", " ", v_errMsg);
            continue;
        }

        
        /* 1080408005-SC1-�n���Ҥ����ƳB�z�A�Hca_quotation�g�J��Ƭ��� (���������H�����ˮ�)*/
        $SELECT icard1,icard2,ilast_ply,ilast_card,irelative_card,ixxcard,
                nvl(qply2_period,0), dply2_begin,dply2_end,
                nvl(qply1_period,0), dply1_begin,dply1_end,
                fassured, iassured, iassured_ext,
                nassured,ilicense,fsex,fmarriage,
                nuser,ibenef,nbenef,aassured, aassured_zip,
                itel, nvl(itel_night,' '), mobil_phone, iemail,
                iply_area,apayment, apayment_zip,
                ipro_year, ibrand,nbrand_abbr,icar_type2,icar_type1,
                fcar_note2,qcylinder,iengine,ibody,itag,
                mcar_price,nequipment,
                pdmg_align,pbrg_align,plia_align,fcut,
                nvl(mpremium2,0), nvl(mpremium1,0), ibig_branch,
                ibig_office,ibig_sales,iresource,
                ibroker2,ibroker1, iofficer2,iofficer1, icorps,
                iarea, iexaminer,fcal_way,pdmg_factor,pbrg_factor,qpt,fpt,
                nvl(psex_age2,0), nvl(psex_age1,0), psex_age_damage,plia_acc2,plia_acc1,pdmg_acc,
                lia_class,dmg_acc_1st,dmg_acc_2nd,dmg_acc_3rd,
                fcomp_24,fbig_ply,iabn_type,
                fcomp_class,fcomp_class_last,mbusiness,
                fdiscount,ibig_comp, dapply,ipay_way,icar_flag1,icar_flag2,
                trans_prem, transno,
                ipolicy1, ipolicy2, iinstall, iquery_num, iquery_num_c,
                iext_policy, qpro_month, mkilo_ply, irisk, irelative_ext,
                napplicant, dbirth, dissue,
                iextra_charge, gextra_charge, pextra_charge,
                iquery_num_damage, introducer, mequipment,
                survey_num, bound_num, abnormal_num, iapplicant, iaccept, idm_number, iroute_prop, iroute,
                nfax_cus, nemail_cus, nroute_cus, nname_cus, itel_cus, mobil_phone_cus, nnote_cus, nnote_leader,
                decode(decode(iroute[1,2],'CA','T','F'),'T','T',decode(iroute[1,1],'J','T','F')),
                irate_type1, bzfrom1, iroute_comm1, icomm_obj1,
                irate_type2, bzfrom2, iroute_comm2, icomm_obj2, qprovision,
                isecond_hand, icard_main, qlia_acc_sum, qdmg_acc_sum,
                fapplicant, fsex_appl, dbirth_appl, itel_appl,
                ndeputy_appl, nrelation_appl, ndeputy_assured,
                fuw_status, iuw_first, duw_first,
                pdmg_acc2, qdmg_acc_sum2, iquery_num_damage2, 
                pdmg_acc3, qdmg_acc_sum3, iquery_num_damage3, 
                dcomp_lastdend,qdrunk_driving,fout_print, fmail_type,icomp_cartype_last,isign ,ibound,isurvey,
                npost_recipient,apost_zip,apost_address,iins_kit,mcover_limit,iassured_cntry , iapplicant_cntry,nassured_cntry,napplicant_cntry,
                foccup, applicant_foccup, noccup, applicant_noccup,
                funknown_dmg,fequipment1,fequipment2,fequipment3,fequipment4,fequipment5,fequipment6,fequipment9,nequipment9,ftrans_trade,feply, 
                case WHEN today>='12/05/2022' then '0' else feterms END,
                aemail_eply,tmobile_eply,
                punknown_acc,qunknown_acc_sum,iquery_num_unknown,punknown_acc2,qunknown_acc_sum2,iquery_num_unknown2,ipolicy_last_brg, dply_end_last_brg, iquery_num_last_brg,
                abnormal_est,tmobile_appl,aemail_appl,fecard,ireg_no,qviolate
           INTO $card1,$card2,$last_ply,$last_card,$relative_card,$xxcard,
                $ply2_period,$ply2_begin,$ply2_end,
                $ply1_period,$ply1_begin,$ply1_end,
                $assuredf,$assuredi, $assuredi_ext,
                $assuredn,$license,$sex,$marriage,
                $user,$benefi,$benefn,$assureda, $assureda_zip,
                $tel, $tel_night, $mobil_phone, $iemail,
                $ply_area, $paymenta, $paymenta_zip,
                $pro_year,$brandi,
                $brandn,$car_typei2,$car_typei1,$fcar_note2,
                $cylinder,$engine,$body,
                $tagnum,$car_price,$equipment,
                $dmg_align,$brg_align,$lia_align,$cutf,
                $premium2,$premium1,
                $big_branch,$big_office,$big_sales,$resource,
                $broker2,$broker1, $officer2,$officer1, $sIcorps,
                $area,$examiner,$cal_way,
                $pdmg_factor_1st,$pbrg_factor_1st,$qpt,$fpt,
                $psex_age2,$psex_age1,$psex_age_damage,$plia_acc2,$plia_acc1,$pdmg_acc,
                $lia_class,$dmg_acc_1st,$dmg_acc_2nd,$dmg_acc_3rd,
                $fcomp_24,$fbig_ply,$abn_type,
                $comp_class,$comp_class_last,$mbusiness,
                $fdiscount,$ibig_comp, $lDapply,$ipay_way,$icar_flag1,$icar_flag2,
                $trans_prem,$sTransNo,
                $tmp_ipolicy1, $tmp_ipolicy2, $iinstall, $iquery_num, $iquery_num_c,
                $iext_policy, $qpro_month, $mkilo_ply, $irisk, $irelative_ext,
                $napplicant, $dbirth, $dissue,
                $iextra_charge, $gextra_charge, $pextra_charge,
                $iquery_num_damage, $introducer, $mequipment,
                $survey_num, $bound_num, $abnormal_num, $iapplicant, $iroute_accept, $idm_number, $iroute_prop, $iroute,
                $nfax_cus, $nemail_cus, $nroute_cus, $nname_cus, $itel_cus, $mobil_phone_cus, $nnote_cus, $nnote_leader,
                $RouteCAJ,
                $irate_type1, $bzfrom1, $iroute_comm1, $icomm_obj1,
                $irate_type2, $bzfrom2, $iroute_comm2, $icomm_obj2, $qprovision,
                $isecond_hand, $icard_main, $qlia_acc_sum, $qdmg_acc_sum,
                $fapplicant, $fsex_appl, $dbirth_appl, $itel_appl,
                $ndeputy_appl, $nrelation_appl, $ndeputy_assured,
                $fuw_status, $iuw_first, $duw_first,
                $pdmg_acc2, $qdmg_acc_sum2, $iquery_num_damage2, 
                $pdmg_acc3, $qdmg_acc_sum3, $iquery_num_damage3, 
                $dcomp_lastdend, $qdrunk_driving,$fout_print, $fmail_type,$icomp_cartype_last,$isign,$ibound_x,$isurvey_x,
                $npost_recipient, $apost_zip, $apost_address,$iins_kit, $mcover_limit,$iassured_cntry , $iapplicant_cntry,$nassured_cntry,$napplicant_cntry,
                $foccup, $applicant_foccup, $noccup, $applicant_noccup,
                $funknown_dmg,$fequipment1,$fequipment2,$fequipment3,$fequipment4,$fequipment5,$fequipment6,$fequipment9,$nequipment9,$ftrans_trade,$feply,
                $feterms,
                $aemail_eply,$tmobile_eply,
                $punknown_acc,$qunknown_acc_sum,$iquery_num_unknown,$punknown_acc2,$qunknown_acc_sum2,$iquery_num_unknown2,$ipolicy_last_brg, $dply_end_last_brg, $iquery_num_last_brg,
                $abnormal_est,$tmobile_appl,$aemail_appl,$fecard,$sIreg_no,$qviolate
           FROM estimate
          WHERE iestimate=$estimatei;

        
        if (NOT_FOUND)  /*/return M_CM_NOT_FOUND;*/
        {
            sprintf_s(v_errMsg,sizeof v_errMsg,"�����渹[%s]��Ƥ��s�b",estimatei);
            Update_car3011_temp(estimatei, "1", " ", " ", " ", " ", " ", " ", " ", v_errMsg);
            continue;
        } 
        strcpy(engine , rtrim(engine));
        strcpy(body   , rtrim(body));
        strcpy(assuredi  , trim(assuredi)); 
        strcpy(iapplicant, trim(iapplicant)); 
        if(strlen(trim(officer1)) > 0)
            strcpy(officer,officer1);    
        else
            strcpy(officer,officer2);
        
        /* ���o�޲z�H������T */
        $SELECT a.ileader,a.iquota,b.nbranch
           INTO $sIleader,$sIquota,$sNquota
           FROM officer a,sa_branch_type b
          WHERE a.iquota = b.ibranch
            AND a.iofficer = $officer;


        printf("abnormal_est[%s]\n",abnormal_est);

        if (strlen(trim(abnormal_est)) > 0)
        {
            sprintf_s(v_errMsg,sizeof v_errMsg,"���`��(%s):�w���o���`��,�ХH���`���X��C",abnormal_est);
            Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
            continue;
        }
        /* ---------------------------------- ��l�� -----------------------------------*/
        
        
        /*1080408005-SC5-�j��{�ҷs�W�q����Ƥεn���Ҹ��ɵ{ -�W�w2019/09/4(43712) �_�ˮֱj���I�ӫO����쬰����J*/
        if ((Today >= 43712) && (strlen(trim(sIreg_no))==0) && (strlen(trim(officer1))>0) &&  (strncmp(bzfrom1,"10",2)==0 || strncmp(bzfrom1,"20",2)==0 || strncmp(bzfrom1,"30",2)==0|| strncmp(bzfrom1,"40",2)==0))
        {
            sprintf_s(v_errMsg,sizeof v_errMsg, "�ӫO�j���I�ɡA�~�ȭ��n���Ҧr��������J���A�Ь��ӫO���ӫ~��;");
            Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
            continue;
        }
        
        /*  
        1090624010-SC1-���ά�-�s�W�wú��CAR3011�ˮ�JB���Ƥ������X�X��
        1. �s�W�wú������ˮ֡A�H�L���=�t�Τ�-60�餺�����Ƥ������X�X��̡A������O�渹�æb���浲�G��������ܿ��~�T���C
        2. �ư��������X���ťժ�
        3. ĵ�ܰT�����i�Ө���60�餺�w���ۦP�O�����X���j
        */
        if (strlen(engine)>0)
        {   
            if (g_frenew_type[0] != '6')
            {
                strcpy(v_errMsg,"");
                $SELECT first 1 ipolicy1
                   INTO $v_errMsg
                   FROM cm_pre_receive
                  WHERE ipolicy1 <> ''
                    AND iengine=$engine
                    AND iins_cat='C'
                    AND ftype ='P'
                    AND dprint is not null
                    AND dprint >=  (TODAY - 60);
            
                if (NOT_FOUND)  
                {
                    /* �S�����ƥX��*/
                }
                else
                {   
                    strcpy(v_errMsg,trim(v_errMsg));
                    strcat(v_errMsg, "�Ө���60�餺�w���ۦP�������X���X���;");
                    Update_car3011_temp(estimatei, "1", " ", " ", " ", " ", " ", " ", " ", v_errMsg);
                    continue;
                }            	
            }
            else
            {
                /*���X��A�u�ˮ֥��N�I���i���P�ˤ����� (1120923005_C02)*/
                strcpy(v_errMsg,"");
                $SELECT first 1 ipolicy1
                   INTO $v_errMsg
                   FROM cm_pre_receive
                  WHERE ipolicy1 <> ''
                    AND iengine=$engine
                    AND iins_cat='C'
                    AND iins_kind_ply='C2'
                    AND ftype ='P'
                    AND dprint is not null
                    AND dprint >=  (TODAY - 60);
            
                if (NOT_FOUND)  
                {
                    /* �S�����ƥX��*/
                }
                else
                {   
                    strcpy(v_errMsg,trim(v_errMsg));
                    strcat(v_errMsg, "�Ө���60�餺�w���ۦP�������X���X���;");
                    Update_car3011_temp(estimatei, "1", " ", " ", " ", " ", " ", " ", " ", v_errMsg);
                    continue;
                }       
            	
            }

        }
        Icurr=Ifirst=Ilast=NULL;             /* set INS_TYPE pointer to NULL */
        Icurr_33=Ifirst_33=Ilast_33=NULL;    /* set INS_TYPE_33 pointer to NULL */
        Icurr_48=Ifirst_48=Ilast_48=NULL;
        Icurr_35=Ifirst_35=Ilast_35=NULL;
        Icurr_56=Ifirst_56=Ilast_56=NULL;
        IcurrPlyInsCover=IfirstPlyInsCover=IlastPlyInsCover=NULL;
        
        rows_33=rows_48=rows_35=rows_56=0;
        strcpy(assuredi, trim(assuredi)); 
        strcpy(card2," ");
        strcpy(fcomp_24, "N"); premium1_24 = 0;   
        rows=0;	    
        mdmg_prem=mlia_prem=mcommission21=0;
        mdmg_pure_prem=mlia_pure_prem=0;
        ins33_flag=0;  ins48_flag=0;  ins35_flag=0;  ins56_flag=0;  ins136_flag=0;  ins166_flag=0;  ins266_flag=0;
        damage_add_flag = 0;   thief_add_flag = 0;
        tmp_ipolicy1[0]='\0';  tmp_ipolicy2[0]='\0';
        strcpy(fproject, " ");
        Qmdrunk_prem = 0;      Qmdrunk_pure_prem = 0;
        Qmviolate_prem = 0;    Qmviolate_pure_prem = 0;
        ply1f = FALSE;  ply2f = FALSE;
        /* ---------------------------------- [DataCheck1()] -----------------------------------*/

        
        rc = DataCheck1(); 	    
        if (rc != M_CM_OK)
        {
            if(strlen(trim(v_errMsg)) == 0)
            {
                strcpy(v_errMsg, cm_get_errmsg(rc));
            }
            Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
            continue;
        }
        else 
        {
            if(strlen(trim(v_errMsg)) > 0) /* �����T�� */
            {
                
                Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ",  fout_print, feply, v_errMsg);    
            }
        }
            
        /* ---------------------------------- [DataCheck1()] -----------------------------------*/

        /* 1130419008_C01_113.05.02 �Ĥ@���q�ۥΨ��w���ƫ��������.�����t���ˮ�*/
        /*chkECAR = 0;
        
        $SELECT count(*) 
           INTO $chkECAR 
           FROM est_ins_type a,estimate b,car_type c
          WHERE a.iestimate=b.iestimate AND a.iins_type IN ('01','05','09','11','31','32','149')
            AND b.ibrand[7,8]='01' AND c.fcar_class='1'
            AND b.icar_type2=c.icode AND c.fclass='1' AND b.dply2_begin>='07/01/2024'
            AND a.iestimate = $estimatei;
        
        if(chkECAR > 0)
        {
            strcpy(v_errMsg,"�q�ʨ��Ȱ������X��7/1�H��ͮīO��;");
            Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
            continue;	
        }*/
        
        
                
        /* W�}�Y���g��N��������X�^�k�᪺�g��N��,�޲z�H�η~�Z��� */
        strcpy(iofficer_prmt, " ");		strcpy(iquota_prmt," ");        strcpy(ileader_prmt," ");
        fag01 = 0;
        
        ZA_mbusiness = mbusiness;
        
        /*printf("ZA_mbusiness[%f],mbusiness[%f]\n",ZA_mbusiness,mbusiness);*/
        
        pdmg_acc_ori = pdmg_acc;    /* 01,08�I�� */
        pdmg_acc_ori2 = pdmg_acc2;  /* 05,09,120,125,126�I�� */
        pdmg_acc_ori3 = pdmg_acc3;  /* 85,105,118,137,138�I�� */
        
        plia_acc2_ori = plia_acc2;
        
        strcpy(itmp_policy,estimatei);
        

        if ((!IsBlankNull(tmp_ipolicy1)) || (!IsBlankNull(tmp_ipolicy2)))
        {
            strcpy(v_errMsg, cm_get_errmsg(M_CA_NEEDDEL_PLY));
            Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
            continue;
        }

        sCompClassNote17[0]='\0';
        sSynctranNote17[0]='\0';


        broker_tmp[0]='\0';
        if (sIcorps[0] != ' ' && sIcorps[0] != '\0')
        {
            EXEC SQL SELECT icar_broker
                       INTO :broker_tmp
                       FROM officer_broker
                      WHERE iofficer = :sIcorps;
        }

        if ((NOT_FOUND) || ((broker_tmp[0]==' ') || (broker_tmp[0]=='\0')))
        {
            /* Do nothing */
        }
        else
        {
            if (officer2[0] != ' ' && officer2[0] != '\0')
            {
                /* ---- �t�X�q���ĤG���q�ק� �P�_�O�_�ҥγq���~�ȱ��� ---------------- */
                rc = cm_get_route_auth("C", iroute, officer2, fstart2, fauth2);
                if (rc != M_CM_OK)
                {
                    strcpy(v_errMsg, cm_get_errmsg(rc));
                    Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                    continue;

                }
                
                if (strcmp(fstart2,"N") == 0)
                    strcpy(broker2 , trim(broker_tmp));
            }

            if (officer1[0] != ' ' && officer1[0] != '\0')
            {
                /* ---- �t�X�q���ĤG���q�ק� �P�_�O�_�ҥγq���~�ȱ��� ---------------- */
                rc = cm_get_route_auth("C", iroute, officer1, fstart1, fauth1);
                if (rc != M_CM_OK)
                {
                    strcpy(v_errMsg, cm_get_errmsg(rc));
                    Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                    continue;
                }
                
                if (strcmp(fstart1,"N") == 0)
                    strcpy(broker1 , trim(broker_tmp));
            }
        }


        printf("8220--estimatei=[%s]\n",estimatei);
        
        if (strlen(trim(car_typei2))>0)
            rc = get_iins_cat( car_typei2, 1, ply2_period, iins_cat, iyear, v_sMsg );
        else
            rc = get_iins_cat( car_typei1, 1, ply1_period, iins_cat, iyear, v_sMsg );
             
        if( rc != M_CM_OK)
        {
            strcpy(v_errMsg, cm_get_errmsg(rc));
            Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
            continue;
        }



        ins33_flag = 0;
        ins48_flag = 0;
        ins35_flag = 0;
        ins56_flag = 0;
        ins136_flag = 0;
        ins166_flag = 0; /* 1080225007-SC1-��ã��-�s�W166�r�� */
        ins266_flag = 0; /* 1110308005_SC1_�w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h */
        flag58 = 0;
        damage_add_flag = 0;
        thief_add_flag = 0;

        sprintf_s( stmt,sizeof stmt, "SELECT iins_type,minjured_cover,mdeath_cover,mdamage_cover,"
                                     "       mdeduct,mins_premium,mpure_prem,qserial,"
                                     "       pcommission,pagent,pdiscount,"
                                     "       qday,mexpense,"
                                     "       drate_ym,mprem,provision,mcommission,mdiscount,"
                                     "       safe_rate, manage_rate, educated_rate, deviation_rate,"
                                     "       pextra_charge, pbusiness, psex_age, pshipping,nvl(fproject,' '), "
                                     "       mdrunk_prem, mdrunk_pure_prem, mviolate_prem, mviolate_pure_prem "
                                     "  FROM est_ins_type"
                                     " WHERE iestimate='%s'"
                                     " ORDER BY qserial DESC", estimatei);

        $PREPARE prep_est FROM $stmt;
        $DECLARE OPT_QL2 CURSOR FOR prep_est;
        $OPEN OPT_QL2;
        while (1)
        {
            $FETCH OPT_QL2
              INTO $ins_type,$injured_cover,$death_cover,$damage_cover,
                   $deduct,$ins_premium,$pure_ins_premium,$qserial,
                   $pcommission,$pagent,$pdiscount,
                   $qday,$mexpense,
                   $drate_ym,$bef_ins_premium,$provision,$mcommission,$mdiscount,
                   $safe_rate, $manage_rate, $educated_rate, $deviation_rate,
                   $pextra_charge, $pbusiness, $psex_age, $pshipping, $fproject,
                   $Qmdrunk_prem, $Qmdrunk_pure_prem, $Qmviolate_prem, $Qmviolate_pure_prem;

            if (NOT_FOUND) break;

            strcpy(ins_type, trim(ins_type));
            if (strcmp(ins_type,"21")==0)
            {
                strcpy(comp_frate,drate_ym);
                mservice      = mcommission;  /* �j���I����O */
                mcommission21 = mcommission;
                Gdrunk_prem = Qmdrunk_prem;
                Gdrunk_pure_prem = Qmdrunk_pure_prem;
                mviolate_prem = Qmviolate_prem;
                mviolate_pure_prem = Qmviolate_pure_prem;
                continue;
            }
            else
                strcpy(sgliaclass, drate_ym);

            if (strcmp(ins_type,"33")==0)
            {
                ins33_flag = 1;
            }

            if (strcmp(ins_type,"48")==0)
            {
                ins48_flag = 1;
            }

            if (strcmp(ins_type,"35")==0)
            {
                ins35_flag = 1;
            }

            if (strcmp(ins_type,"56")==0)
            {
                ins56_flag = 1;
            }

            if (strcmp(ins_type,"136")==0)
            {
                ins136_flag = 1;
            }
            
            if (strcmp(ins_type,"166")==0)/* 1080225007-SC1-��ã��-�s�W166�r�� */
            {
                ins166_flag = 1;
            }
            
            if (strcmp(ins_type,"266")==0)/* 1110308005_SC1_�w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h */
            {
                ins266_flag = 1;
            }
            
            if (strcmp(ins_type,"58")==0)
            {
                flag58 = 1;
            }
            

            
            /* �ഫ�W�B�d���I��h�O�B�N��qday���ĤT�H�d���I�O�I���B�@,�G,�T */
            if (strcmp(ins_type,"29")==0)
            {
                rc = lReturnIns29BaseCover(qday,&coverage1_31,&coverage2_31,&coverage3_32);
            }
            /*1030725001_C1 �ߦw(118)�B����(120)����[�N�B���O�I*/
            /* ���[�N�B���A�� */
            /* 1090812005-SC1-���ά�-�s�W�s�ӫ~-�T�����B���郞�I���l���O�I198�I*/
            /* 1100909003-SC1-�_�@�Ϯ��S�h���p�{������07+15�}���O181�I�ݨD*/
            if (  (strcmp(trim(ins_type),"01")==0) || (strcmp(trim(ins_type),"05")==0) ||
                  (strcmp(trim(ins_type),"08")==0) || (strcmp(trim(ins_type),"09")==0) ||
                  (strcmp(trim(ins_type),"85")==0) || (strcmp(trim(ins_type),"198")==0)||
                  (strcmp(trim(ins_type),"181")==0)|| (strcmp(trim(ins_type),"201")==0)||
                  (strcmp(trim(ins_type),"205")==0)|| (strcmp(trim(ins_type),"209")==0)
               )                 
            {
                fag01 = 1; 
                if (qday > 0)
                {
                    damage_add_flag = 1;
                }  
                rc = GetEstDMG(ins_type);
                
            }
            else if (strcmp(ins_type,"152")==0 || strcmp(ins_type,"153")==0)
            {
                rc = GetEstDMG(ins_type);
            } 
            else if ((strcmp(ins_type,"11")==0 || strcmp(ins_type,"129")==0 || strcmp(ins_type,"211")==0) && (qday > 0))
            {
                thief_add_flag = 1;
            }
            else if ((strcmp(ins_type, "29")==0) || (strcmp(ins_type, "15")==0) ||
                     (strcmp(ins_type, "16")==0) || (strcmp(ins_type, "66")==0) ||
                     (strcmp(ins_type, "67")==0) || (strcmp(ins_type, "38")==0) ||
                     (strcmp(ins_type, "39")==0) || (strcmp(ins_type,"106")==0) ||
                     (strcmp(ins_type,"119")==0) || (strcmp(ins_type,"121")==0) ||
                     (strcmp(ins_type,"123")==0) ||
                     (strcmp(ins_type,"154")==0) || (strcmp(ins_type,"155")==0) || (strcmp(ins_type,"156")==0) ||
                     (strcmp(ins_type,"163")==0) || (strcmp(ins_type,"238")==0)
                    )  
            {   
            	/*1030725001_C1 �ߦw(118)�B����(120)����[�N�B���O�I 1070625011-SC1-��ã��-�s�W�s�A��+�����N�B���s�ӫ~(�I��163)�{���ޱ� 1100119001-SC1-���ά�-�s�W-�s�ӫ~238�I-�D���ϴ��O�Ϊ��[����*/
            	/*1100311005-SC1-�����¦����s�A�������I�����{���]�w137�B138�B139�B141�B142�I�� (strcmp(ins_type,"139")==0) ||*/
                mexpense = 0;
                mexp_disc = 0;
            }
            else
            {
                qday = 0;
                mexpense = 0;
                mexp_disc = 0;
            }

            
            double mservice, mother_busi;
            char   icheck_busi[2], icheck_mservice[2];

            /* �t�X�q���ĤG���q,get_commission_agent �s�W�Ѽ� modify by sylvia  */
            /* �t�X��椣�ˮֳq�����v, �T�w�ǫO�����O=P(�O��) modify by sylvia 101.02.07 */

            rc = get_commission_agent(iins_cat, broker2, ins_type, iyear, drate_ym,
                                          &broker_pagent, &broker_pdisc, &broker_pcommi, &mservice, &mother_busi,
                                          icheck_disc, icheck_commi, icheck_agent, icheck_busi, ipaid_base,
                                          &pfix_agent, icheck_mservice, itype_disc,
                                          fstart2, officer2, iroute, irate_type2, iroute_comm2, "P",v_sMsg );

            if( rc != M_CM_OK)
            {
                strcpy(v_errMsg, cm_get_errmsg(rc));
                Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                continue;
            }
            

            /* car9801122 57 59 60�I�ظg���N����000��,���t�~�b�{�������w�u�f,�H�����N�z�v�]�w�ɬ��D */
            /* �O�v�ۥѤƤ���@�ߥH�����N�z�v�]�w�ɬ��D */
            /* �t�X�q���ĤG���q,�g���H�N���ť�, �B�O�v�ۥѤƫ�@�ߥH�]�w�ɬ��D,�G��g���� modify by sylvia 100.06.17 */

            sprintf_s(tmp_pfix_agent,sizeof tmp_pfix_agent,"%4.2f", pfix_agent);

            if (strcmp(icheck_agent,"4")==0)  /* �B��--�̦����v */
            {   
            	/* �p���I�ĤT��L����i�� */
                broker_pagent = (double)broker_pcommi * (double)(pfix_agent/100.00);
                broker_pagent = broker_pagent + 0.009;
                broker_pagent = (long)(broker_pagent*100);
                broker_pagent = (double)((double)broker_pagent/100);

                pagent = (double)pcommission * (double)(pfix_agent/100.00);
                pagent = pagent + 0.009;
                pagent = (long)(pagent*100);
                pagent = (double)((double)pagent/100);
            }

            $SELECT fins_grp
               INTO $fins_grp
               FROM insurance_type
              WHERE iins_type=$ins_type;
            if (NOT_FOUND) 
            {
                strcpy(v_errMsg, cm_get_errmsg(M_CA_NINS_TYPE));
                Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                continue;
            }

            if (*fins_grp=='1')
                mdmg_prem=mdmg_prem+ins_premium;

            bef_premium=bef_premium+bef_ins_premium;
            
            /********************** �ˮ��I�جO�_����  ***********************************/
                 
            rc = chk_insurance_expire(ins_type, v_sMsg);
            if( rc != M_CM_OK)
            {
                strcpy(v_errMsg, cm_get_errmsg(rc));
                Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                continue;
            }

            /********************** ���[�O�βv  ***********************************/

            
            
            pbusiness = 0.0; pextra_charge =0.0;
            /*  1090916003-�����@-�I�߫O�N�����T�걵-���[�O�βv �W�[�D�q���N���P�_*/
            rc = get_cm_extra_charge_car( iextra_charge, drate_ym,
                                         &pextra_charge, &pbusiness, ply2_period, atoi(rtrim(ins_type)), iroute, v_sMsg);
            if( rc != M_CM_OK)
            {
                strcpy(v_errMsg, cm_get_errmsg(rc));
                Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply,iroute, v_errMsg);
                continue;
            }
            
            
            

            /* GCAR */
            
            if (! Insert_INS_TYPE(ins_type, injured_cover, death_cover, damage_cover, deduct,
                                  ins_premium, bef_ins_premium,
                                  pagent,pcommission,pdiscount,
                                  drate_ym,pure_ins_premium,
                                  broker_pagent,broker_pcommi,broker_pdisc,
                                  icheck_agent,icheck_commi,icheck_disc,
                                  ipaid_base,pfix_agent,
                                  qday,mexpense,provision,itype_disc,mdiscount,
                                  safe_rate, manage_rate, educated_rate, deviation_rate,
                                  pextra_charge, pbusiness, psex_age, pshipping, fproject,
                                  Qmdrunk_prem, Qmdrunk_pure_prem, pcar_price_1, Qmviolate_prem, Qmviolate_pure_prem))

            {
                $CLOSE OPT_QL2;
                $FREE  OPT_QL2;
                
                strcpy(v_errMsg, cm_get_errmsg(M_CM_NOT_MALLOC));
                Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                continue;
            }
            
        }
        $CLOSE OPT_QL2;
        $FREE  OPT_QL2;


        /*** GET �ˮ`�I���Ӹ��-48 ***/
        if (ins48_flag == 1)
        {
            stmt[0]='\0';
            sprintf_s(stmt,sizeof stmt,"SELECT %s %s %s %s FROM %s WHERE %s ",
                                       "iinsurant, ninsurant, dbirth, iins_scope, ",
                                       "mins_amt, mins_premium, ",
                                       "pcommission, mcommission, pagent, magent, pdiscount, mdiscount, ",
                                       "relation_appl, mr_ins_prem, mr_pure_prem, daily_pay ",
                                       " ca_pa_est",
                                       " iestimate = ? AND iins_type = '48'" );
            $PREPARE OPT_QL2_CUR_48_TMP FROM $stmt;
            $DECLARE OPT_QL2_CUR_48 CURSOR FOR OPT_QL2_CUR_48_TMP;
            $OPEN    OPT_QL2_CUR_48 USING $estimatei;
            while (1)
            {
                $FETCH OPT_QL2_CUR_48 INTO :cIinsurant, :cNinsurant, :lDbirth, :cIins_scope,
                                           :lMins_amt, :lMins_premium,
                                           :dPcommission, :lMcommission, :dPagent, :lMagent, :dPdiscount, :lMdiscount,
                                           :cRelation_appl, :lMr_ins_premium, :lMr_pure_premium, :cDaily_pay;

                if (NOT_FOUND) break;

                if (! Insert_INS_TYPE_48(cIinsurant, cNinsurant, lDbirth, cIins_scope,
                                         lMins_amt, lMins_premium,
                                         dPcommission, lMcommission, dPagent, lMagent, dPdiscount, lMdiscount,
                                         cRelation_appl, lMr_ins_premium, lMr_pure_premium, cDaily_pay))
                {
                    $CLOSE OPT_QL2_CUR_48;
                    $FREE  OPT_QL2_CUR_48;
                    strcpy(v_errMsg, cm_get_errmsg(M_CM_NOT_MALLOC));
                    Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                    continue;
                }
            }
            $CLOSE OPT_QL2_CUR_48;
            $FREE  OPT_QL2_CUR_48;
        }

        /*** GET �ĤT�H�d�����Ӹ��-35 ***/
        if (ins35_flag == 1)
        {
            stmt[0]='\0';
            sprintf_s(stmt,sizeof stmt,"SELECT %s %s %s FROM %s WHERE %s ",
                                       "iinsurant, ninsurant, iins_scope, ",
                                       "mins_amt, mins_premium, ",
                                       "pcommission, mcommission, pagent, magent, pdiscount, mdiscount ",
                                       " ca_pa_est",
                                       " iestimate = ? AND iins_type = '35'" );
            $PREPARE OPT_QL2_CUR_35_TMP FROM $stmt;
            $DECLARE OPT_QL2_CUR_35 CURSOR FOR OPT_QL2_CUR_35_TMP;
            $OPEN    OPT_QL2_CUR_35 USING $estimatei;
            while (1)
            {
                $FETCH OPT_QL2_CUR_35 INTO :cIinsurant, :cNinsurant, :cIins_scope,
                                           :lMins_amt, :lMins_premium,
                                           :dPcommission, :lMcommission, :dPagent, :lMagent, :dPdiscount, :lMdiscount;

                if (NOT_FOUND) break;

                if (! Insert_INS_TYPE_35(cIinsurant, cNinsurant, cIins_scope,
                                         lMins_amt, lMins_premium,
                                         dPcommission, lMcommission, dPagent, lMagent, dPdiscount, lMdiscount))
                {
                    $CLOSE OPT_QL2_CUR_35;
                    $FREE  OPT_QL2_CUR_35;
                    
                    strcpy(v_errMsg, cm_get_errmsg(M_CM_NOT_MALLOC));
                    Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                    continue;
                }
            }
            $CLOSE OPT_QL2_CUR_35;
            $FREE  OPT_QL2_CUR_35;
        }

        /*** GET �ˮ`�I���Ӹ��-56 ***/
        /*1080225007-SC1-��ã��-�s�W166�r��*/
        /* 1110308005_SC1_�w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h */
        if (ins56_flag == 1 || ins136_flag==1 || ins166_flag==1 || ins266_flag==1)
        {
            $char tmp_ins56[7];
            if (ins56_flag==1)
            {
                strcpy(tmp_ins56,"56");
            }
            else if (ins136_flag==1)
            {
                strcpy(tmp_ins56,"136");
            }
            else if (ins166_flag==1)
            {
                strcpy(tmp_ins56,"166");
            }
            else if (ins266_flag==1)
            {
                strcpy(tmp_ins56,"266");
            }
            
            stmt[0]='\0';
            sprintf_s(stmt,sizeof stmt,"SELECT %s %s %s %s %s %s FROM %s WHERE %s ",
                                       "iinsurant, ninsurant, dbirth, ainsurant, iins_scope, icareer, ",
                                       "mins_amt, mins_premium, ",
                                       "pcommission, mcommission, pagent, magent, pdiscount, mdiscount, ",
                                       "napplicant, relation_appl, nbeneficiary, relation_bene, ",
                                       "daily_pay, mr_ins_prem, mr_pure_prem, ",
                                       "tbenef, abenef_zip, abenef ",
                                       " ca_pa_est",
                                       " iestimate = ? AND iins_type = ? AND NOT (len(trim(iinsurant)) = 1 AND (trim(iinsurant)) = 'A' )" );
            $PREPARE OPT_QL2_CUR_56_TMP FROM $stmt;
            $DECLARE OPT_QL2_CUR_56 CURSOR FOR OPT_QL2_CUR_56_TMP;
            $OPEN    OPT_QL2_CUR_56 USING $estimatei,$tmp_ins56;
            while (1)
            {
                $FETCH OPT_QL2_CUR_56 INTO :cIinsurant, :cNinsurant, :lDbirth, :cAinsurant, :cIins_scope, :cIcareer,
                                           :lMins_amt, :lMins_premium,
                                           :dPcommission, :lMcommission, :dPagent, :lMagent, :dPdiscount, :lMdiscount,
                                           :cNapplicant, :cRelation_appl, :cNbeneficiary, :cRelation_bene,
                                           :cDaily_pay,  :lMr_ins_premium, :lMr_pure_premium,
                                           :cTbenef,     :cAbenef_zip,     :cAbenef;

                if (NOT_FOUND) break;

                if (! Insert_INS_TYPE_56(cIinsurant, cNinsurant, lDbirth, cAinsurant, cIins_scope, cIcareer,
                                         lMins_amt, lMins_premium,
                                         dPcommission, lMcommission, dPagent, lMagent, dPdiscount, lMdiscount,
                                         cNapplicant, cRelation_appl, cNbeneficiary, cRelation_bene,
                                         cDaily_pay,  lMr_ins_premium, lMr_pure_premium,
                                         cTbenef,     cAbenef_zip,     cAbenef))
                {
                    $CLOSE OPT_QL2_CUR_56;
                    $FREE  OPT_QL2_CUR_56;
                    
                    strcpy(v_errMsg, cm_get_errmsg(M_CM_NOT_MALLOC));
                    Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                    continue;
                }
            }
            $CLOSE OPT_QL2_CUR_56;
            $FREE  OPT_QL2_CUR_56;
        }
        strcpy( sDbname, local_dbname);
        strcpy( sColumn, "iestimate");
        strcpy( sTable,  "est_ins_cover");
        strcpy( sTable1, "est_ins_assured");
        strcpy( sTable2, "ca_est_bound");

        /*printf("entry[%s], userid[%s]\n",  entry, userid);*/
        strcpy(entry, trim(entry));
        strcpy(userid, trim(userid));
        strcpy(officer1, trim(officer1));
        strcpy(officer2, trim(officer2));


        #ifdef CA_CONS

        IfirstPlyInsCover = get_ply_ins_cover( sDbname, sTable, sColumn, estimatei, &rtncode, v_sMsg);

        if( rtncode != M_CM_OK)
        {
            strcpy(v_errMsg, cm_get_errmsg(rtncode));
            Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
            continue;
        }

        IcurrPlyInsCover = IfirstPlyInsCover;

        while( IcurrPlyInsCover)
        {
            /*printf("IcurrPlyInsCover->iins_type    [%s]\n"
                   "IcurrPlyInsCover->cover_name   [%s]\n"
                   "IcurrPlyInsCover->icover_type  [%s]\n"
                   "IcurrPlyInsCover->iprem_cover_type  [%s]\n"
                   "IcurrPlyInsCover->mcover       [%d]\n"
                   "IcurrPlyInsCover->mcover_prem  [%d]\n"
                   "IcurrPlyInsCover->mdiscount    [%d]\n"
                   "IcurrPlyInsCover->mprem        [%d]\n"
                   "IcurrPlyInsCover->mpure_prem   [%f]\n",
                    IcurrPlyInsCover->iins_type,
                    IcurrPlyInsCover->cover_name,
                    IcurrPlyInsCover->icover_type,
                    IcurrPlyInsCover->iprem_cover_type,
                    IcurrPlyInsCover->mcover,
                    IcurrPlyInsCover->mcover_prem,
                    IcurrPlyInsCover->mdiscount,
                    IcurrPlyInsCover->mprem,
                    IcurrPlyInsCover->mpure_prem);*/
            puts("");
            IcurrPlyInsCover = IcurrPlyInsCover->next;
        }

        #endif

        IfirstPlyInsAssured = get_ply_ins_assured( sDbname, sTable1, sColumn, estimatei, &rtncode, v_sMsg);
        if( rtncode != M_CM_OK)
        {
            strcpy(v_errMsg, cm_get_errmsg(rtncode));
            Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
            continue;
        }

        IcurrPlyInsAssured = IfirstPlyInsAssured;

        while( IcurrPlyInsAssured)
        {
            /*printf("IcurrPlyInsAssured->iins_type    [%s]\n"
                   "IcurrPlyInsAssured->provision    [%s]\n"
                   "IcurrPlyInsAssured->iassured     [%s]\n"
                   "IcurrPlyInsAssured->nassured     [%s]\n"
                   "IcurrPlyInsAssured->dbirth       [%s]\n"
                   "IcurrPlyInsAssured->nbenef       [%s]\n"
                   "IcurrPlyInsAssured->rel_benef    [%s]\n"
                   "IcurrPlyInsAssured->tbenef       [%s]\n"
                   "IcurrPlyInsAssured->abenef_zip   [%s]\n"
                   "IcurrPlyInsAssured->abenef       [%s]\n"
                   "IcurrPlyInsAssured->iserial      [%d]\n",
                    IcurrPlyInsAssured->iins_type,
                    IcurrPlyInsAssured->provision,
                    IcurrPlyInsAssured->iassured,
                    IcurrPlyInsAssured->nassured,
                    IcurrPlyInsAssured->dbirth,
                    IcurrPlyInsAssured->nbenef,
                    IcurrPlyInsAssured->rel_benef,
                    IcurrPlyInsAssured->tbenef,
                    IcurrPlyInsAssured->abenef_zip,
                    IcurrPlyInsAssured->abenef,
                    IcurrPlyInsAssured->iserial);*/
            puts("");
            IcurrPlyInsAssured = IcurrPlyInsAssured->next;
        }

        rtncode = get_ca_ply_bound( sDbname, sTable2, sColumn, estimatei, ibound, v_sMsg);
        if( rtncode != M_CM_OK)
        {
            strcpy(v_errMsg, cm_get_errmsg(rtncode));
            Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
            continue;
        }

        mlia_prem   = premium2-mdmg_prem;
        premium     = premium1+premium2;
        mlia_prem   = premium2-mdmg_prem;
        premium     = premium1+premium2;

        imark[0]='\0';


        /*printf("{CA301OptQL.0005}:car_typei2[%s]\n",car_typei2);*/
        /*printf("EA{CA301OptQL.0005}:ply2_begin[%s]\n",cm_edate_str(ply2_begin));*/

        strcpy(tmp_ply2_begin,cm_cdate_str_100(ply2_begin));

        strncpy(iym_ply2_begin,&tmp_ply2_begin[0],3);
        iym_ply2_begin[3]='\0';

        strncat(iym_ply2_begin,&tmp_ply2_begin[4],2);
        iym_ply2_begin[5]='\0';
        tmp_iym_ply2_begin=atoi(iym_ply2_begin);

        printf("ply2_begin[%d]\n", ply2_begin);


        /* b2c-9512051 B2C�����H�H�Υd�I��,MIS�H�պ⸹(17N*)�a�X���Ū��cm_credit_pay��� */
        /* �Y�H�պ⸹(17N*)�a�X��,�M��U���`Y���CX���`�պ⸹,�h17N*�պ⸹�|�g�Jabnormal_ply.itmp_policy */
        /* �Y�OCX���`�պ⸹,�h�Hitmp_policyŪ��cm_credit_pay�H�Υd��� */

        $SELECT nname
           INTO $nquota
           FROM officer
          WHERE iofficer = $examiner;
          
        /* 1041014001_C1 car301ñ��t�Υi�P�ɬ�����ոպ⸹ */
        strcpy(ipre_rcv_ori," ");
        
                
        /*** �X�� ***/
        rc=Car3011_A();
        if (rc != M_CM_OK)
        {
            if (rc<0)
            {  
                sprintf_s(TMP_MSG,sizeof TMP_MSG,"[���~]SQLCODE=[%d]sqlca.sqlerrm=[%s],sqlca.sqlerrd[1]=[%d]�A�Ь���T��", rc,sqlca.sqlerrm,sqlca.sqlerrd[1]);
                
                if(strlen(trim(v_errMsg)) > 0)
                    strcat(v_errMsg, rtrim(TMP_MSG));
                else
                    strcpy(v_errMsg, rtrim(TMP_MSG));
            }
            else
            {
                if(strlen(trim(v_errMsg)) == 0)
                {
                    strcpy(v_errMsg, cm_get_errmsg(rc));
                    if(strlen(trim(v_errMsg)) == 0)  /*ex. 3568:�S��������������~�T��*/
                    {
                        sprintf_s(v_errMsg,sizeof v_errMsg,"���~�T���N�X:[%d]",rc);
                    }
                }
            }
            
            Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
            
            continue;
        }
    }

    $CLOSE cur_tmpQ;
    $FREE cur_tmpQ;

    return M_CM_OK;

optql_err:
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    sprintf_s(v_errMsg,sizeof v_errMsg,"Car3011OptQL()���~:SQLCODE=[%d]sqlca.sqlerrm=[%s],sqlca.sqlerrd[1]=[%d]", SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);      
    return SQLCODE;
}

long GetEstDMG(Giins_type)
$char Giins_type[7];
{
    printf("----- GetEstDMG start -------------------\n");
    printf("Giins_type=[%s]\n",Giins_type);
    iMaxDrate = atoi(sgliaclass);
    printf("sgliaclass[%s]iMaxDrate[%d]\n",sgliaclass,iMaxDrate);
    strcpy(Giins_type, trim(Giins_type));

    if ((strcmp(Giins_type,"05")==0) || (strcmp(Giins_type,"09")==0) || (strcmp(Giins_type,"120")==0)|| 
        (strcmp(Giins_type,"125")==0)|| (strcmp(Giins_type,"126")==0)|| (strcmp(Giins_type,"198")==0)||
        (strcmp(Giins_type,"205")==0)|| (strcmp(Giins_type,"209")==0))
    {
    	/* 1070212002-SC1 0301�O�v�վ�0501�ͮ� 93�O�v+161+162(�ˮ֤��152+153�A�O�O���98)*/
        /* 1090812005-SC1-���ά�-�s�W�s�ӫ~-�T�����B���郞�I���l���O�I198�I*/
        if(iMaxDrate <93)
            if (funknown_dmg[0]==' ') strcpy(funknown_dmg,"2");
        else
            if (funknown_dmg[0]==' ') strcpy(funknown_dmg,"1");
    }
    else if ((strcmp(Giins_type,"85")==0) || (strcmp(Giins_type,"105")==0)|| (strcmp(Giins_type,"118")==0))
    {
        if (funknown_dmg[0]==' ') strcpy(funknown_dmg,"3");
    }
    else if ((strcmp(Giins_type,"01")==0) || (strcmp(Giins_type,"08")==0)|| (strcmp(Giins_type,"122")==0) || (strcmp(Giins_type,"201")==0))
    {
        if (funknown_dmg[0]==' ') strcpy(funknown_dmg,"1");
    }
    else if ((strcmp(Giins_type,"152")==0) || (strcmp(Giins_type,"153")==0))
    {
        if (funknown_dmg[0]==' ') strcpy(funknown_dmg,"5");
    }
    else
    {
        strcpy(funknown_dmg," ");
    }
    printf("----- GetPlyDMG End -------------------\n");

    return M_CM_OK;
}

static long Car3011_A()
{

    int   i;
    long  rcl, rcode, fRtnCode;
    char  f1[3];
    $char icard_year[6], icard_year_1[6];
    $char tmp_card1[CARD_NUM], tmp_card2[CARD_NUM];
    $char stmt[400],tmp_estimatei[CA_ESTIMATE_NUM];
    $char tmp_policy1[POLICY_NUM_1],tmp_policy2[POLICY_NUM_1];
    char  yy[3], mm[3], dd[3];
    int   yy1;
    $char TmpEstimate[21];
    $char dbegin[11],dend[11];
    $datetime year to second dexpire;
    $char rba_HG[2],rba_dbirth[11],rba_dbirth_appl[11],stmt_rba[1024];
    $char rba_foccup[2]  = " ";             /* �Q�O�I�H¾/��~�O */
    $char rba_applicant_foccup[2]  = " ";   /* �n�O�H¾/��~�O */
    $char rba_noccup[6]  = " ";             /* �Q�O�I�H¾/��~�O�N�� */
    $char rba_applicant_noccup[6]  = " ";   /* �n�O�H¾/��~�O�N�� */
    $char rba_HG_tmp[2] = " ";

    $char iref_num1[21],idata_type[2],imember[11],nmember[101],icountry[6],idept[11],ibranch_leader[3],iquota_leader[7],ftype_batch[2],iins_class_batch[3],iquota_grp[7];
    $datetime year to second dt_current;
    $date dbirth_batch;
    $int  fkind_batch, fstatus_batch,tmpCount;
    
    int iLoop_end;    
    $WHENEVER SQLERROR GOTO optA_err;

    qcount++;
    
    strncpy(sTmpIbranch, sIbranchIcomp , 2);
    sTmpIbranch[2] = '\0';
    strncpy(sTmpIcomp, sIbranchIcomp+2, 1);
    sTmpIcomp[1] = '\0';
    
    if (IS_branch_upcomp_match(sTmpIbranch, DEFAULT_USE_BRANCH_ID, sTmpIcomp, USE_SHORT_BRANCH_ID) == False)
        return M_CM_UPCOMP_NOT_MATCH;
    /*printf("-- trace localdb[%s]\n ",localdb); */  
    
    printf("-- trace get_upcomp=[%s]\n ",get_upcomp(localdb, USE_BRANCH_ID,USE_SHORT_BRANCH_ID));
    if (strncmp(sTmpIcomp, get_upcomp(localdb, USE_BRANCH_ID, USE_SHORT_BRANCH_ID), 1) != 0)
        return M_CM_DB_ERROR;
    
    /*�k�ݳ��*/
    fRtnCode = cm_get_unit_in("", localdb, userid, sIbranchIcomp, "C1", sIcomp_in, sIbranch_in);
    if (fRtnCode != M_CM_OK) return fRtnCode;
    /*printf("-- trace after cm_get_unit_in\n ");*/
    
    /*�B�z���*/
    fRtnCode = cm_get_unit_at(userid, "C1", sIcomp_at, sIbranch_at);
    if (fRtnCode != M_CM_OK) return fRtnCode;
    /*printf("-- trace after cm_get_unit_at\n ");*/
    premium1=0;
    premium2=0; premium=0;
    premium2_disc = 0;

    printf("premium1[%d] premium2[%d] premium[%d]\n",premium1,premium2,premium);
    
    printf("estimate=[%s]\n", (estimatei) );


    if (trim(comp_frate) == "")
    {

        $SELECT drate_ym INTO $comp_rym
           FROM est_ins_type
          WHERE iestimate=$estimatei
            AND iins_type="21";
        if( SQLCODE == SQLNOTFOUND)
            strcpy( comp_rym, comp_frate );

    }
    else
    {
        strcpy(comp_rym, comp_frate);
    }


    /* Call Cal_ins_prem �p�� mdmg_prem and ins->magent,ins->mcommi */
    
    strcpy(comp_frate, comp_rym);
    rc = CA3011OptAU('A');
    if (rc != SUCCESS) return rc;    

    $BEGIN WORK;

    /* �X��ɥ��N�j���I�t�B�ɸ�ƧR�� */
    /*printf("Car3011_A:TmpEstimate[%s]\n",TmpEstimate);*/
    if (!IsBlankNull(TmpEstimate))
    {
        printf("DELETE FROM ca_comp_return\n");
        EXEC SQL DELETE FROM ca_comp_return WHERE ipolicy=$TmpEstimate;
    }

    rc=CA3011_Step11(0);
    if (rc != SUCCESS)
    {
        $ROLLBACK WORK;
        return rc;
    }
    printf("estimatei[%s]\n",estimatei);
    Icurr=Ifirst;
    while( Icurr)
    {
        /*printf("iins_typeiins_typeiins_typeiins_typeiins_typeiins_type[%s]\n", Icurr->ins_type);*/
        Icurr=Icurr->next;
    }

    wk_fac=' ';
    rc=CA3011_Step12(1,wk_fac);
    if (rc != SUCCESS)
    {
        $ROLLBACK WORK;
        return rc;
    }

    

    
    
    /*----------------�� 1060606002_C4_RBA�t�έץ� ��----------------*/ 
         

    iLoop_end = 0;   strcpy(idata_type, "0");  strcpy(icountry ," "); strcpy(ibranch_leader ," "); strcpy(iquota_leader ," ");
    dtcurrent(&dt_current);
    fkind_batch = 2;  fstatus_batch = 10; strcpy(iins_class_batch , "C");

    /*printf("-- trace destimate[%s]\n ",destimate);*/
     
    /* 1061012002-SC3 ISID+rba�j���I�G�����X��@�~���L��� ���N�I ���ܦL��@�~���L��� �W�[�g�J�ӫO�@�~�G�޲z�H*/
    /* �������A�ˬd �@�ߥX��eISID*/
    $prepare rba_chk from 
        "insert into cm_isid_batch (iref_num1,iref_num2,iref_num3,idata_type,imember,nmember, \
                                   icountry,dbirth,idept,iins_class,fkind,ftype,icreate,dcreate,nbatch,fstatus,inotice,ileader) \
                            values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    $prepare getLeaderInfo from  "select ibranch, iquota from officer where iofficer = ? " ;
    $execute getLeaderInfo into $ibranch_leader, $iquota_leader using $sIleader ;
    /*printf("-- trace sIleader[%s], ibranch_leader[%s], iquota_leader[%s]\n ",sIleader,ibranch_leader, iquota_leader); */

    strcpy(iquota_grp," ");    /* ���n��� */
    $select c.iquota_grp INTO $iquota_grp
       from officer a, sa_branch_type b, branch c, sa_branch_type d
      where a.iofficer   = a.ileader
        and a.iquota     = b.ibranch and a.dexpire is null
        and a.iapp_unit != b.iply_branch
        and a.iapp_unit  = c.ibranch
        and c.iquota_grp = d.ibranch 
        AND a.iofficer   = $sIleader;
                 
    if (strlen(trim(iquota_grp))>0)
    {
        strncpy(idept, iquota_grp, 4);  idept[4]='\0';
    }
    else
    {   
    	/*1091222001-SC1  2021 1701��4101�U�����Y��*/
        /*1111227007_SC1  2023 4101��3701�U�����Y��*/
        if ((strcmp(ibranch_leader,"00")!=0) || (strncmp(iquota_leader,"1206",4)==0) || (strncmp(iquota_leader,"1701",4)==0) || (strncmp(iquota_leader,"4101",4)==0) || (strncmp(iquota_leader,"3701",4)==0) )
        {   
        	/* 2018/03/01 �ҥ� 170100	�q�l�Ӱȳ�*/
            strncpy(idept, iquota_leader, 4);  idept[4]='\0';
        }
        else  
        {
            strcpy(idept, "3201"); /* �`���q�f�ֳ��T�w���ӫO��(3201), �q��(1206)���~ */
        }
    }
    
    /* 1061012002-SC3 ISID+rba�j���I�GE  ���N�I B */
    if(strlen(trim(ply_num2)) > 0)
    {
        strcpy(ftype_batch , "B");
        strcpy(iref_num1, trim(ply_num2));
    }
    else
    {
        strcpy(ftype_batch , "E");
        strcpy(iref_num1, trim(ply_num1)); 
    }
    printf("-- trace iref_num1[%s]\n ",iref_num1);

    /* �ק�ISID��ưe�f�W�h (1101110005_SC1)  */
    if ((strcmp(assuredi,iapplicant) == 0) && (strcmp(napplicant, assuredn) == 0))
    { 
        iLoop_end = 1;
    }
    else
    {
        iLoop_end = 2;
    }
    
    for (i = 1;  i<=iLoop_end; i++)
    { 
             
        if (iLoop_end==1)
        {
            strcpy(idata_type, "3");               /*  idata_type = 1.�n�O�H 2.�Q�O�H  3.�n�O�H = �Q�O�H*/
        }
        else
        {
            strcpy(idata_type, itoa(i) ); 
        }
             
        if (i==1) /* �n�O�H */ 
        {
            strcpy(imember, trim(iapplicant));
            strcpy(nmember, trim(napplicant));

            if( iapplicant_cntry[0] == '9')
            {
                strcpy(icountry ,"TW");
            }
            else if( iapplicant_cntry[0] == '2')
            {
                strcpy(icountry ,"CN");
            }

            dbirth_batch = dbirth_appl;

        }
        else
        {

            strcpy(imember, trim(assuredi));
            strcpy(nmember, trim(assuredn));

            if( iassured_cntry[0] == '9')
            {
                strcpy(icountry ,"TW");
            }
            else if( iassured_cntry[0] == '2')
            {
                strcpy(icountry ,"CN");
            } 

            dbirth_batch = dbirth;
        } 

        $execute rba_chk using $iref_num1, ' ', ' ' ,$idata_type, $imember, $nmember, $icountry, $dbirth_batch, $idept, $iins_class_batch, 
                               $fkind_batch , $ftype_batch, $userid, $dt_current, ' ', $fstatus_batch, $userid, $sIleader;  
           
    }
     
 
    if (strncmp(ftype_batch,"E",1)==0)
    {    
    	/*********************   20180712  �ɤWRBA   1061012002-SC9   ********************************
         �妸�X��E�����i�ߧYcm_preview_rba�Afunction�|�B�z�ƫ���O
                   B�����b�L��e�T�{ISID�w�d�ߧ����A�~��cm_preview_rba�B�z�iĵ���A
        *******************************************************************************/	
        
        /*
        printf("�����I¾�~�ˮ�E��cm_preview_rba\n");
        printf("ply_num1[%s]\n",ply_num1);
        printf("ply_num2[%s]\n",ply_num2);
        printf("assuredi[%s]\n",assuredi);
        printf("assuredn[%s]\n",assuredn);
        printf("assuredf[%s]\n",assuredf);
        printf("dbirth[%d]\n",dbirth);
        printf("iassured_cntry[%s]\n",iassured_cntry);
        printf("bzfrom2[%s]\n",bzfrom2);
        printf("iroute[%s]\n",iroute);
        printf("(mdmg_prem+mlia_prem)[%ld]\n",mdmg_prem+mlia_prem);
        printf("foccup[%s]\n",foccup);
        printf("noccup[%s]\n",noccup);
        */     
        strcpy(rba_HG     , " "); 
        strcpy(rba_HG_tmp , " ");
        strcpy(iassured_cntry_rba  ,"N");     
        strcpy(iapplicant_cntry_rba,"N");

        if(dbirth == DATENULL)
        {
            strcpy(rba_dbirth," ");
        }
        else
        {
            strcpy(rba_dbirth,cm_edate_str(dbirth));
        }

        if( dbirth_appl == DATENULL )
        {
            strcpy(rba_dbirth_appl," ");
        }
        else
        {
            strcpy(rba_dbirth_appl, cm_edate_str(dbirth_appl));
        }
        /*
        printf("rba_dbirth[%s]\n",rba_dbirth);
        printf("rba_dbirth_appl[%s]\n",rba_dbirth_appl);
        */
        /* 1101124011_SC1_RBA�ק�@�~ �W�[4.5���������O */
        if(strncmp(iassured_cntry,"1",1)==0)
            strcpy(iassured_cntry_rba  ,"Y");
        else if(strncmp(iassured_cntry,"4",1)==0)
            strcpy(iassured_cntry_rba  ,"M");
        else if(strncmp(iassured_cntry,"5",1)==0)
            strcpy(iassured_cntry_rba  ,"S");
        	
        if(strncmp(iapplicant_cntry,"1",1)==0)
            strcpy(iapplicant_cntry_rba,"Y");
        else if(strncmp(iapplicant_cntry,"4",1)==0)
            strcpy(iapplicant_cntry_rba,"M");
        else if(strncmp(iapplicant_cntry,"5",1)==0)
            strcpy(iapplicant_cntry_rba,"S");

        strcpy(rba_foccup           ,trim(foccup));
        strcpy(rba_applicant_foccup ,trim(applicant_foccup));
        strcpy(rba_noccup           ,trim(noccup));
        strcpy(rba_applicant_noccup ,trim(applicant_noccup));

        if(strlen(rba_foccup)==0)
        {
            strcpy(rba_foccup, "Y"  );
            strcpy(rba_noccup, "999");
        }
         
        if(strlen(rba_applicant_foccup)==0)
        {
            strcpy(rba_applicant_foccup, "Y"  );
            strcpy(rba_applicant_noccup, "999");
        }
        if(strlen(rba_noccup)==0)
        {
            strcpy(rba_noccup, " "  );
        }
        if(strlen(rba_applicant_noccup)==0)
        {
            strcpy(rba_applicant_noccup, " "  );
        }
        /*  
        printf("rba_foccup[%s]\n",rba_foccup);    
        printf("rba_noccup[%s]\n",rba_noccup);        
        */
        /* 1101124011_SC1_RBA�ק�@�~ �W�[�ǤJ��a�W�� */ 
        if(strncmp(assuredi,iapplicant,10) == 0)
        {
            if(strlen(trim(ply_num1)) > 0)
            {        
                rc = cm_preview_rba("3"," ",ply_num1," "," ",assuredi,assuredn,assuredf,rba_dbirth,iassured_cntry_rba,bzfrom1,iroute,premium1,rba_foccup,rba_noccup,ply_num1," "," ",rba_HG,nassured_cntry);
                if (rc != SUCCESS)
                {
                    $ROLLBACK WORK;
                    return rc;
                }
            }
            
            if(strlen(trim(ply_num2)) > 0)
            {

                rc = cm_preview_rba("3"," ",ply_num2," "," ",assuredi,assuredn,assuredf,rba_dbirth,iassured_cntry_rba,bzfrom2,iroute,(mdmg_prem+mlia_prem),rba_foccup,rba_noccup,ply_num2," "," ",rba_HG,nassured_cntry);
                if (rc != SUCCESS)
                {
                    $ROLLBACK WORK;
                    return rc;
                }
            }  
        }
        else
        {
            /*1.�n�O�H 2.�Q�O�H*/
            if(strlen(trim(ply_num1)) > 0)
            {
                rc = cm_preview_rba("1"," ",ply_num1," "," ",iapplicant,napplicant,fapplicant,rba_dbirth_appl,iapplicant_cntry_rba,bzfrom1,iroute,premium1,rba_applicant_foccup,rba_applicant_noccup,ply_num1," "," ",rba_HG,napplicant_cntry);
                if (rc != SUCCESS)
                {
                    $ROLLBACK WORK;
                    return rc;
                }
                
                rc = cm_preview_rba("2"," ",ply_num1," "," ",assuredi,assuredn,assuredf,rba_dbirth,iassured_cntry_rba,bzfrom1,iroute,premium1,rba_foccup,rba_noccup,ply_num1," "," ",rba_HG,nassured_cntry);
                if (rc != SUCCESS)
                {
                    $ROLLBACK WORK;
                    return rc;
                }
            }

            if(strlen(trim(ply_num2)) > 0)
            {
                rc = cm_preview_rba("1"," ",ply_num2," "," ",iapplicant,napplicant,fapplicant,rba_dbirth_appl,iapplicant_cntry_rba,bzfrom2,iroute,(mdmg_prem+mlia_prem),rba_applicant_foccup,rba_applicant_noccup,ply_num2," "," ",rba_HG,napplicant_cntry);
                if (rc != SUCCESS)
                {
                    $ROLLBACK WORK;
                    return rc;
                }
                     
                rc = cm_preview_rba("2"," ",ply_num2," "," ",assuredi,assuredn,assuredf,rba_dbirth,iassured_cntry_rba,bzfrom2,iroute,(mdmg_prem+mlia_prem),rba_foccup,rba_noccup,ply_num2," "," ",rba_HG,nassured_cntry);
                if (rc != SUCCESS)
                {
                    $ROLLBACK WORK;
                    return rc;
                }
                 
            }
        }
        printf("rba_HG[%s]\n",rba_HG);
         
        /*********************    ����     20180712  �ɤWRBA  ����     *******************************************/
    }
    
    $COMMIT WORK;


    usleep(1250000);	/*1.25��*/
    

    msg_code=M_CM_OK;


    $WHENEVER SQLERROR CONTINUE;     /* reset error handling */
     
    while (Ifirst != NULL)
    {                                /* free all allocated memory */
        Icurr=Ifirst;
        Ifirst=Icurr->next;
        free(Icurr);
    }
     
    while (Ifirst_33 != NULL)
    {                                /* free all allocated memory */
        Icurr_33=Ifirst_33;
        Ifirst_33=Icurr_33->next;
        free(Icurr_33);
    }
    
    while (Ifirst_48 != NULL)
    {                                /* free all allocated memory */
        Icurr_48=Ifirst_48;
        Ifirst_48=Icurr_48->next;
        free(Icurr_48);
    }
    
    while (Ifirst_35 != NULL)
    {                                /* free all allocated memory */
        Icurr_35=Ifirst_35;
        Ifirst_35=Icurr_35->next;
        free(Icurr_35);
    }
    
    while (Ifirst_56 != NULL)
    {                                /* free all allocated memory */
        Icurr_56=Ifirst_56;
        Ifirst_56=Icurr_56->next;
        free(Icurr_56);
    }
    
    while (IfirstPlyInsCover != NULL)
    {                                /* free all allocated memory */
        IcurrPlyInsCover=IfirstPlyInsCover;
        IfirstPlyInsCover=IcurrPlyInsCover->next;
        free(IcurrPlyInsCover);
    }
    
    while (IfirstPlyInsAssured != NULL)
    {                                /* free all allocated memory */
        IcurrPlyInsAssured=IfirstPlyInsAssured;
        IfirstPlyInsAssured=IcurrPlyInsAssured->next;
        free(IcurrPlyInsAssured);
    }
    
    while (IfirstPlyInsCheck != NULL)
    {                                /* free ñ����ˮ� */
        IcurrPlyInsCheck=IfirstPlyInsCheck;
        IfirstPlyInsCheck=IcurrPlyInsCheck->next;
        free(IcurrPlyInsCheck);
    }    
       
    return M_CM_OK;

optA_err:
    printf("opta_err:sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    sprintf_s(v_errMsg,sizeof v_errMsg,"Car3011_A()���~:SQLCODE=[%d]sqlca.sqlerrm=[%s],sqlca.sqlerrd[1]=[%d]", SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);      
    $WHENEVER ERROR CONTINUE;   
    $ROLLBACK WORK;
    return SQLCODE;
}

static CA3011OptAU(type)
char type;
{
    $char  nassured[120], nuser[19], ibenef[11], nbenef[43], aassured[91];
    $char  aassured_zip[CA_ZIP];/* 1090525004-SC1-�]�y��-�s���l���ϸ�3+3   ZIP_CODE 5+1->CA_ZIP 6+1*/
    $char  iassured[11], fassured[2];
    $char  iassured_ext[3];
    $char  apayment[91], apayment_zip[CA_ZIP], itel[21], iply_area[11];/* 1090525004-SC1-�]�y��-�s���l���ϸ�3+3   ZIP_CODE 5+1->CA_ZIP 6+1*/
    $char  ipro_year[5], ibrand[9];
    $char  iengine[CA_ENGINE_NUM], ibody[CA_BODY_NUM], ilicense[11];
    $char  fsex[2], fmarriage[2], nequipment[31];
    $double   qcylinder;/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/ 
    $char  icard_year[6],icard_year_1[6],ch[2], org_acc_align[3];
    $char  icar_grp[2],icar_grp_1[2],icar_grp_2[2];
    $char  fins_grp[2];
    $char  locpolicy[POLICY_NUM_1],locply[POLICY_NUM_1];
    $int   qperiod;
    long   code;
    long   renew1, renew2, org_ins_premium;
    $long  dissuei, dbirthi;
    int    int_mcar_price, int_car_price;
    $float palign, palign_1;
    $char  stmt[400], tmp_iofficer[11];
    $char  tmp_iquota[CA_SA_QUOTA], tmp_ileader[LEADER];
    char   dbsite[3], FullDBName[20];
    char   dbsite6[3], FullDBName6[20];
    $char  FullDBName_card1[20];
    char   comp_ryy[3], comp_rmm[3],abn_buf[1000];
    $int   int_comp_ryy, int_comp_rmm,t_count = 0;
    char   TMP_MSG[200];
    $char  frate[5];
    $char  ply_bgn_yy[4], ply_bgn_mm[4], ply_bgn_dd[4], ply_bgn_str[6];
    char   yy[3], mm[3], dd[3];
    char   ply_yr[5];
    /*------------*/
    int     yy1;
    $char   fagent[2];
    int     iSecondYear=0;
    $double lSy_prem1_bef=0, lSecondYear_prem=0, lTmp_prem=0;
    char    sTmpyy1[4], sTmpmm1[3], sTmpdd1[3];
    char    sTmpyy2[4], sTmpmm2[3], sTmpdd2[3];
    long    lTmpPremium1;
    char    Iins_type_tmp[INSURANCE_TYPE];
    int     check_iins_01_flag;
    int     check_iins_11_flag;
    int     adj_year,intYear;
    $char   fexist[2], aemail[51];
    $int    intDiscMinLimit[3] = {0,0,0};
    $int    intDiscMinLimit35[4] = {0,0,0,0};
    $char   sFbackDcreate[11];/*1090504007-SC1-���ʱo-�ɤs�����{���}�o  �p���q�lñ�p�����A�h���Hsam403��������D*/
    $WHENEVER SQLERROR GOTO optau_err;
    
    Icurr=Ifirst;

    msg_code=M_CM_OK;                 /* set default return message code */
    times_3=FALSE;                    /* initialize local variables */
    if (IsBlankNull(acc_align)) strcpy(acc_align,"00");
    strcpy(org_acc_align,acc_align);  /* make a copy of org. acc_align */
    outplyf=FALSE;                    /* suppose last_ply is from SK */
    flag_new=FALSE;
    strcpy(policy1," ");  strcpy(policy2," ");  /* 1061129 fix*/

    
    if (!IsBlankNull(officer2))
    {
        $SELECT ibranch, ibigcomp, iquota, ileader, icomm_obj, iroute_comm ,iroute_prop
           INTO $ibranch2, $ibig_comp2, $sIquota2, $sIleader2, $icomm_obj2, $iroute_comm2, $iroute_prop2
           FROM officer
          WHERE iofficer=$officer2;
        if (NOT_FOUND)  return M_CMN_NOFFICER;
    }

    if (!IsBlankNull(officer1))
    {
        $SELECT ibranch, ibigcomp, iquota, ileader, icomm_obj, iroute_comm ,iroute_prop
           INTO $ibranch1, $ibig_comp1, $sIquota1, $sIleader1, $icomm_obj1, $iroute_comm1, $iroute_prop1
           FROM officer
          WHERE iofficer=$officer1;
        if (NOT_FOUND) return M_CMN_NOFFICER;
    }
    
    if (ply1_period > 0) ply1f = TRUE;
    if (ply2_period > 0) ply2f = TRUE; 

    strcpy(iroute, trim(iroute));
    
    strcpy(resource, trim(resource));		
    if(strcmp(resource,"0")==0) strcpy(resource,"3");	    

    /* 1070125001_SC5_�j��T���d���I�q�l���O�I�һ{�ҥ��x�Χ�O�t�ζ}�o */
    /* 1070125001_SC8_�j��T���d���I�q�l���O�I�һ{�ҥ��x�Χ�O�t�ζ}�o */
    /* �q�l�O����O �B�z */
    if (ply2_period>0)
    {
        /* car164(�j���k�H�Ȥ�)�����ɪ̡A�̸ӳ]�w��  */
        /*1080417001-SC1-���ά�-�s�W�q�l�O��H²�T�覡�o�e  �j���k�H�Ȥ�q�l�O��a�w�]�Ȥ��u�B�zemail�w�]�ȡA���B�z���²�T�w�]��*/
        strcpy(fexist,"0");    strcpy(aemail," "); 
        $select '1', aemail into $fexist, $aemail
           from ca_eply_mail 
          where iassured = $assuredi and iroute = $iroute
            and (dexpire is null or dexpire > today) ;
         
        if (fexist[0] == '1')
        {
            strcpy(feply, "1");
            strcpy(aemail_eply, aemail );
            strcpy(fecard, feply);
        }
    }
    else
    {
        /* ��j���I���i���O�q�l�O�� */
        if (feply[0] == '1')
        {
            strcpy(fecard, feply);
        }
        
        if (fecard[0] == '1')
        {
            if ((strlen(trim(aemail_eply))==0) && (strlen(trim(tmobile_eply))==0))
            {   
            	/*1091007004-SC1-���ʱo-�~�ȭ��q��10�۰ʵo�e�j��q�l����(CX�ӷ����i��S���n�O�H�����mail)  
                                 �ΫO�o�q��40��KA�q��(��40KA�i��S���n�O�H�����mail �L�ݥt�~�B�z)
                                 �t���ȥ��γ�j�i�H����J�q�l�o�e��T 
                                 �ҥH�ˮֹq�l�O����쥼�d�������mail�̡A�N�n�O�H�������mail�ƻs�i�h���w�]�� */
                /*1101206002_SC1_�j��q�l���ұH�o�@�~�X�j-���q��*/
                strcpy(tmobile_eply,tmobile_appl);
                strcpy(aemail_eply,aemail_appl);
            }
        }
        else 
        {
            /* �j��q�l���ұH�o�@�~�X�j-���q��
               �B�ȥ��z�����|���q�l�O��������A�G�@�ߦ^�ɦ��n�O�H�p����T (1101206002_SC1) */
            strcpy(fecard, "0");
            strcpy(aemail_eply, aemail_appl);
            strcpy(tmobile_eply, tmobile_appl); /*1080417001-SC1-���ά�-�s�W�q�l�O��H²�T�覡�o�e */
        }

    }  
       
    /* ------------------------------------------------------- */ 


    printf("type[%c]\n",type);

    printf("CAR305_INSERT ===> ply1f[%d] ply2f[%d]\n",ply1f,ply2f);

    if (ply1f==FALSE && ply2f==FALSE)  return M_CA_CARDS_DONE;


    if (IsBlankNull(last_ply))   /**** �L�e�O�渹 ****/
    {
        /*** �L�e�O�渹�X ***/
    }
    else
    {
        strcpy(FullDBName6, get_car_full_db(last_ply));  /*** �e�O����ݸ�Ʈw ***/

        if (FullDBName6[0]=='\0') return M_CM_DB_NOTOPEN;

        sprintf_s(stmt,sizeof stmt,"SELECT %s %s FROM %s:%s %s",
                                   "fcard_class, irelative_ply, inext_ply, drenew_print, ",
                                   "fedr_class, icard, dtransfer ",
                                   FullDBName6,"ply_relation ",
                                   "WHERE ipolicy=? ");
        $PREPARE CUR_STMT6_1 FROM $stmt;
        $DECLARE x9_305 CURSOR FOR CUR_STMT6_1;
        $OPEN x9_305 USING $last_ply;
        $FETCH x9_305 INTO $fcard_class,$irelative_ply,$inext_ply,$drnw_print,
                           $fedr_class, $icard, $dtransfer;
        $CLOSE x9_305;
        $FREE x9_305;

        if (NOT_FOUND) return  M_CA_NRELPLY_LASTPLY;

        if (!IsBlankNull(inext_ply))  return M_CA_LASTPLY_NEXTPLY;

        if (fcard_class[0]=='1' && ply1f==FALSE)
            return M_CA_LASTPLY_NOT_COMP;
        if (fcard_class[0]=='2' && ply2f==FALSE)
            return M_CA_LASTPLY_NOT_CARD;

        if ((fcard_class[0]=='1' && ply2f==TRUE) ||
            (fcard_class[0]=='2' && ply1f==TRUE))
        {
            if (!IsBlankNull(irelative_ply))
            {
                strcpy(FullDBName, get_car_full_db(irelative_ply));

                if (FullDBName[0]=='\0') return M_CM_DB_NOTOPEN;

                sprintf_s(stmt,sizeof stmt,"SELECT %s FROM %s:%s %s",
                                           "drenew_print, inext_ply, icard",
                                           FullDBName,"ply_relation", "WHERE ipolicy=?");
                $PREPARE CUR_STMT1 FROM $stmt;
                $DECLARE x1_305 CURSOR FOR CUR_STMT1;
                $OPEN x1_305 USING $irelative_ply;
                $FETCH x1_305 INTO $drnw_print_1, $inext_ply_1, $icard_1;
                if (NOT_FOUND) return M_CA_NRELPLY_LASTPLYREL;
                $CLOSE x1_305;
                $FREE x1_305;
                
                if (!IsBlankNull(inext_ply_1))  flag_no_rel=1;
            }
        }

        if (((fcard_class[0]=='1' && ply2f==TRUE)  ||
             (fcard_class[0]=='2' && ply1f==TRUE)) && flag_no_rel==0)
        {
            if (*fcard_class=='1')
            {
                if (!IsBlankNull(irelative_ply))
                {
                    strcpy(FullDBName, get_car_full_db(irelative_ply));

                    if (FullDBName[0]=='\0') return M_CM_DB_NOTOPEN;
                }
                else if (!IsBlankNull(last_ply))
                {
                    strcpy(FullDBName, get_car_full_db(last_ply));

                    if (FullDBName[0]=='\0') return M_CM_DB_NOTOPEN;
                }

                strcpy(policy1,last_ply);
                strcpy(policy2,irelative_ply);
                strcpy(officer, officer1);
                strcpy(sIquota, sIquota1);
                strcpy(sIleader, sIleader1);
                strcpy(car_typei,car_typei1);
                strcpy(icomm_obj, icomm_obj1);
                    
                strcpy(iroute_prop, iroute_prop1);
                    
                renew1=drnw_print;
                renew2=drnw_print_1;
                strcpy(last_card1,icard);
                strcpy(last_card2,icard_1);

                sprintf_s(stmt,sizeof stmt,"SELECT %s FROM %s:%s %s",
                                           "dply_end",
                                           FullDBName,"ply_relation", "WHERE ipolicy=?");
                $PREPARE CUR_STMT2 FROM $stmt;
                $DECLARE x2_305 CURSOR FOR CUR_STMT2;
                $OPEN x2_305 USING $irelative_ply;
                $FETCH x2_305 INTO $dply_end;
                $CLOSE x2_305;
                $FREE x2_305;
            }
            else
            {
                strcpy(policy1,irelative_ply);
                strcpy(policy2,last_ply);
                strcpy(officer, officer2);
                strcpy(sIquota, sIquota2);
                strcpy(sIleader, sIleader2);
                strcpy(car_typei,car_typei2);
                strcpy(icomm_obj, icomm_obj2);
                    
                strcpy(iroute_prop, iroute_prop2);

                renew1=drnw_print_1;
                renew2=drnw_print;
                strcpy(last_card2,icard);
                strcpy(last_card1,icard_1);

                $SELECT dply_end
                   INTO $dply_end
                   FROM ply_relation
                  WHERE ipolicy=$last_ply;
            }
        }
        else
        {
            if (*fcard_class=='1')
            {
                strcpy(policy1,last_ply);
                strcpy(policy2,"");
                strcpy(officer, officer1);
                strcpy(sIquota, sIquota1);
                strcpy(sIleader, sIleader1);
                strcpy(icomm_obj, icomm_obj1);
                strcpy(car_typei,car_typei1);
                renew1=drnw_print;
                renew2=DATENULL;
                strcpy(last_card1,icard);
                strcpy(last_card2,"");
                dply_end=DATENULL;
            }
            else
            {
                strcpy(policy1,"");
                strcpy(policy2,last_ply);
                strcpy(officer,officer2);
                strcpy(sIquota, sIquota2);
                strcpy(sIleader, sIleader2);
                strcpy(car_typei,car_typei2);
                strcpy(icomm_obj, icomm_obj2);

                renew1=DATENULL;
                renew2=drnw_print;
                strcpy(last_card2,icard);
                strcpy(last_card1,"");
                $SELECT dply_end
                   INTO $dply_end
                   FROM ply_relation
                  WHERE ipolicy=$last_ply;
            }
        }
    }


    /************************** STEP 3 ***********************************/
    /*printf("car_typei1[%s]car_typei2[%s]\n",car_typei1,car_typei2);*/
    
    if (ply1f==TRUE)
    {  
    	/*�Y�O�j��check���إN��*/
        $SELECT fcar_class
           INTO $fcar_class1
           FROM car_type
          WHERE fclass='1'
            AND icode=$car_typei1;
        if (NOT_FOUND)  return M_CA_NCARTYPE;

    }

    if (ply2f==TRUE)
    {  
    	/*�Y�O���Ncheck���إN��*/
        $SELECT fcar_class
           INTO $fcar_class2
           FROM car_type
          WHERE fclass='1'
            AND icode=$car_typei2;
        if (NOT_FOUND)  return M_CA_NCARTYPE;
    }

    /*printf("{CA3011OptAU.0001}:comp_frate[%s],frate[%s],brand[%s],pro_year[%s]\n", comp_frate,Icurr->frate,brandi,pro_year);*/
    strcpy(frate,Icurr->frate);
    if (ply2f==TRUE && strcmp(car_typei2,"51")!=0)
    {
        strcpy(frate,Icurr->frate);
        /* 1061026002-�O�v�N��88->89  �p�J��S�H�u�f�֥�A�h�@�ߤ�����*/
        /* 2018/01/10  1070110001 �q�ʦۦ樮(EB-����=51) �~�Ȥ�����87.88�O�v */     
        iMaxDrate = atoi(frate);
        iPlyYmChk = atoi(cm_eyear_str(ply2_begin));
        
        if ((iMaxDrate <= 87) && (iPlyYmChk == 2017) && (Today > 43107))   /*43107*/
        {
            strcpy(v_errMsg, "2017�ͮġA�O�v��87�Añ��I��鬰1070108");
            return M_CM_ORDINARY_CHECK;   
        }
        else if ((iMaxDrate == 88) && (iPlyYmChk == 2018) && (Today > 43099)) /*43099*/
        {
            strcpy(v_errMsg, "2018�ͮġA�O�v88�Añ��I��鬰1061231");
            return M_CM_ORDINARY_CHECK;                
        }
        
        if  (strcmp(car_typei2,"14") ==0|| strcmp(car_typei2,"2A") ==0)
        {        
            /* '1070123004-SC1-14+2A���ئ�1/24�_�u�����92�O�v or �O�v�ȯ�H�󥿳�β��`��X��(iabn_type=''S")�}�� */
            if(iMaxDrate < 92 )
            {
                strcpy(v_errMsg, "14.2A���ح��ζO�v92(�t)�H��");
                return M_CM_ORDINARY_CHECK; 
            }
        }
        
        /* 1070212002-SC1 0301�O�v�վ�0501�ͮ� 93�O�v+161+162(�ˮ֤��152+153�A�O�O���98)*/
        /*�����N�I�ͮĤ��05/01/2018(43221)�A�B�O�v��92��152+153�I�ءA��������Bñ��B�L��B�鵲�F93�O�v���A�]�w152+153*/
        if ((iMaxDrate < 93) && ply2_begin>= 43221 )  
        {   
            strcpy(v_errMsg, "�ͮĤ�� 1070501�A�O�v��92���I�ءA����ñ��");
            return M_CM_ORDINARY_CHECK;   
        }
    }
    else if (ply1f==TRUE)
    {
        strcpy(frate, comp_frate);
    }
    else
    {
        strcpy(frate,Icurr->frate);
    }
    
    strcpy(frate,trim(frate));

    /*printf("frate[%s]\n",frate);*/

    /* 104.09.09 fix ca_car_model �^���޿� */
    /* car9812112_C1 �t�P�����ɷs�W���Τ� modify by sylvia 100.09.21 */
    mcar_price = 0 ;  qpassenger = 0 ; 
    strcpy(icar_type_1, " ");    strcpy(fuse_type, " ");  strcpy(icar_series, " ");
    
    $SELECT mcar_price  ,icar_type    ,fuse_type  ,qpassenger  ,icar_series
       INTO $mcar_price ,$icar_type_1 ,$fuse_type ,$qpassenger ,$icar_series
       FROM ca_car_model
      WHERE ibrand    = $brandi
        AND ipro_year = $pro_year
        AND (dexpire is null or dexpire > today)
        AND drate     = (SELECT drate
                           FROM ca_rate_date
                          WHERE icode  = $frate
                            AND itable = 'ca_car_model');
    /*printf("qpassenger F [%d]\n", qpassenger);*/
    if (NOT_FOUND)
    {
        $DECLARE CA_OPT1_3A CURSOR FOR
          SELECT mcar_price  ,icar_type    ,fuse_type  ,qpassenger  ,icar_series  ,ipro_year
            INTO $mcar_price ,$icar_type_1 ,$fuse_type ,$qpassenger ,$icar_series
            FROM ca_car_model
           WHERE ibrand    = $brandi
             AND ipro_year < $pro_year
             AND (dexpire is null or dexpire > today)
             AND drate     = (SELECT drate
                                FROM ca_rate_date
                               WHERE icode  = $frate
                                 AND itable = 'ca_car_model')
           ORDER BY ipro_year DESC;
           
        $OPEN  CA_OPT1_3A;
        $FETCH CA_OPT1_3A;
        /*printf("qpassenger G [%d]\n", qpassenger);*/
        if (NOT_FOUND)
        {
            $DECLARE CA_OPT3B_305 CURSOR FOR
              SELECT mcar_price  ,fuse_type  ,qpassenger  ,icar_series  ,ipro_year
                INTO $mcar_price ,$fuse_type ,$qpassenger ,$icar_series
                FROM ca_car_model
               WHERE ibrand    = $brandi
                 AND ipro_year > $pro_year
                 AND (dexpire is null or dexpire > today)
                 AND drate     = (SELECT drate
                                    FROM ca_rate_date
                                   WHERE icode  = $frate
                                     AND itable = 'ca_car_model')
               ORDER BY ipro_year;
            $OPEN  CA_OPT3B_305;
            $FETCH CA_OPT3B_305;
            /*printf("qpassenger H [%d]\n", qpassenger);
            printf("---brandi[%s]pro_year[%s]frate[%s]\n", brandi,pro_year,frate);*/
            
            if (NOT_FOUND)
            {
                return M_CA_NBRAND;
                $CLOSE CA_OPT3B_305;
                $FREE  CA_OPT3B_305;
            }
            $CLOSE CA_OPT3B_305;
        }
        $CLOSE CA_OPT1_3A;
        $FREE  CA_OPT1_3A;
    }

    /************************** STEP 4 ***********************************/
    printf("---dmg_align_1[%s]brg_align_1[%s]lia_align_1[%s]\n",dmg_align_1,brg_align_1,lia_align_1);
    if (ply2f==TRUE)
    {
        if (dmg_align != 0)
        {
            dmg_align_1=(-1)*dmg_align;
            $SELECT icode FROM alignment
              WHERE fclass='4' AND palign=$dmg_align_1;
            if (NOT_FOUND)  return M_CA_NDMG_ALIGN;
        }

        if (brg_align != 0)
        {
            brg_align_1=(-1)*brg_align;
            $SELECT icode FROM alignment
              WHERE fclass='4' AND palign=$brg_align_1;
            if (NOT_FOUND)  return M_CA_NDMG_ALIGN;
        }

        if (lia_align != 0)
        {
            lia_align_1=(-1)*lia_align;
            $SELECT icode FROM alignment
              WHERE fclass='4' AND palign=$lia_align_1;
            if (NOT_FOUND)  return M_CA_NLIA_ALIGN;
        }
          
    }

    /************************** STEP 5 ***********************************/

    /************************** STEP 7 ***********************************/
    
    /* �֫O�H���G�@�߬� ��system�� (�t�ή֫O) */
    strcpy(isign, "system");
    /* 1060817004-C1 �q�lñ�p���y�Ǹ� 
    i.�֫O�H���G�qsystem��H�q�lñ�p��ƥD�ɬ������֫O�H��
    ii.�֫O����G�qcar301�妸�X���������H�q�lñ�p��ƥD�ɬ������֫O�C
    iii.���q�W�u�����ݧ���esign ����ƴN�ϥθ�^�g
    */
    strcpy(sDunder, "");
    strcpy(sIunder, "");
    strcpy(sDunderTime, "");
    strcpy(sfagency, "N");
    strcpy(sFappend, "N");
    $SELECT nvl(iunder,''),nvl(dunder,''),nvl(extend(dunder,year to second),''),nvl(fagency,'N'),nvl(fappend,'N')
       INTO $sIunder,$sDunder,$sDunderTime,$sfagency,$sFappend
       FROM cm_esign_data
      WHERE iscan_no =$sIscan_no;

    if ((SQLCODE == SQLNOTFOUND) || (strlen(trim(sIunder)) == 0 ) || (strlen(trim(sDunder)) == 0 ) || (strlen(trim(sIscan_no)) == 0))
    {   
        strcpy(sDunderTime, "");
        strcpy(sfagency,"N");
        strcpy(sFappend,"N");
        /* 1070531010-SC1 �W�[��j�d�� �����۰ʥX�� �èϥεe�����֫O�H��*/
        if (g_frenew_type[0] =='9')
            strcpy(isign, "system");
        else
            strcpy(isign, isign_batch_car);
        
    }
    else
    {
        strcpy(sDunder,cm_from_infdate_100(sDunder));
        lDapply = cm_cdate_lng(sDunder);
        strcpy(isign, sIunder);
    }
    if (strlen(isign) <= 2)	strcpy(isign, " ");
    printf("�֫O�H��isign[%s]\n",isign);
    
    /* ---------------------------------- [DataCheck2()] -----------------------------------*/
    /*1090504007-SC1-���ʱo-�ɤs�����{���}�o  */
    
    
    printf("iroute[%s]\n",iroute);
    if (strncmp(trim(iroute), "I808",4) == 0)
    {
        /*printf("officer1[%s]\n",officer1);
        printf("officer2[%s]\n",officer2);*/
        if ((strncmp(trim(officer1), "R61025Q03",9) == 0)||(strncmp(trim(officer2), "R61025Q03",9) == 0))
        {
            /*�q���N�����ɤsI808*�A�B�g��N���GR*�A���ư�R61025Q03�ɤs����g��N�� */
        }
        else if ((strncmp(trim(officer1), "R",1) == 0)||(strncmp(trim(officer2), "R",1) == 0))
        {
            strcpy(sFbackDcreate,"");
            
            $SELECT dcreate
               into $sFbackDcreate
               FROM sysdb:cm_route_fback
              WHERE iroute_main[1,4] ='I808'
                AND iroute_accept = $estimatei;
            if((SQLCODE == SQLNOTFOUND) ||  (strlen(trim(sFbackDcreate)) == 0))
            {
                strcpy(v_errMsg, "�q���N���GI808*+�g��N���GR*�|���פJ�פJ�wñ�p�M��A�Ь��ӫO���C");
                return M_CM_ORDINARY_CHECK;  
            }
        }
    }
    
    printf("sDunder[%s]\n",sDunder);
    rc = DataCheck2(INS_ptr, INS_ptr_56, INS_ptr_35 , INS_ptr_48 );  
    if (rc != M_CM_OK)
    {
        return rc;
    }
    else 
    {
        if(strlen(trim(v_errMsg)) > 0) /* �����T�� */
        {
            Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
        }
    }     
    /* ---------------------------------- [DataCheck2()] -----------------------------------*/
        
    /* �j��T���d���O�I */
    if ((ply1f==TRUE) &&
        (strncmp(car_typei1, "01", 2) !=0) &&
        (strncmp(car_typei1, "02", 2) !=0) &&
        (strncmp(car_typei1, "32", 2) !=0) &&
        (strncmp(car_typei1, "34", 2) !=0) &&
        (strncmp(car_typei1, "35", 2) !=0) &&
        (strncmp(car_typei1, "51", 2) !=0) &&
        (strncmp(car_typei1, "T1", 2) !=0) &&
        (strncmp(car_typei1, "T2", 2) !=0) )
    {
        strcpy(cartype1,car_typei1);
    }
    else
    {
        /*�u���إN���v�� 01�B02�B32�B34�B35 �� 51 �� T1�BT2�̡A�u�s�r���ơv�u���j�H�W���ơv���� 0 */
        qdrunk_driving = 0;
        qviolate = 0;
    }

    /*�j������d���I*/
    if ((ply1f==TRUE) &&
        ((strncmp(car_typei1, "01", 2) ==0) ||
         (strncmp(car_typei1, "02", 2) ==0) ||
         (strncmp(car_typei1, "32", 2) ==0) ||
         (strncmp(car_typei1, "34", 2) ==0) ||
         (strncmp(car_typei1, "35", 2) ==0)))
    {
        strcpy(cartype1,car_typei1);
    }
    
    /*--------------------------------------------------------------------------*/
    /* ���O���`�����վ��«O�O,�S�O�ǳƪ�,���v���,�w�w���,��ꦬ�q�̵M�n�� */
    /* �O�v�W���p����O�O������ user key �J�����B                               */
    /*--------------------------------------------------------------------------*/
    lTmpPremium1 = premium1;

    /* �j���I�O�I�O�p�� */
    /* 1100118005-SC1-�B�Q��-�j���I�����~���u�f���B�վ�
        1 ���ӫO�j���I�B�O�I�_��< 04/01/2021
        2 ����D�����O�v�~�B�z
        3 �P�ɲŦX�W�z�����̡A�P�_�ǤJcmn150�¶O�v�ͮĤ����04/01/2021����F�_�h�@�v�M�ťͮĤ���A�Ҳշ|�^��cmn144�̷s���]�w�C
        �Τ@��lib�B�z���t��վ� fNewCompBusi �P�_ */
        
    strcpy(fNewCompBusi,"1");
    if (ply1f==TRUE)
    {
        /* �ǤJ�Ѽ�=======> */
        /* ���ءA�ۥ���~���O */
        /* �g��N���A�~�Ⱥ޲z�O�βb�� */
        /* �O��ͮĤ�A�O������A�O�I���� */
        /* �g���H�N���A�O�v�ͮĥN�� */
        /* �Ӹ����� */
        /* �Q�O�I�H�����O�A�ʧO�~�֫Y�ơA�ߴڰO���Y�� */
        /* ���`����O�A���`�O�O */
        /* �t�X�q���ĤG���q, Cal_prem_21�s�W�|�ӰѼ�
          1.fstart1 -- �O�_�ҥγq������ Y:�w�ҥ� N:���ҥ�
          2.iroute1 -- �q���N��
          3.irate_type1 -- �O�v�O
          4.iroute_comm1 -- �~�ȱ��� */
        /* �t�X�s�r�[�O,�s�W�T�ӰѼ� add by sylvia 103.01.07 (1020801002_C1)
          �ǤJ��:qdrunk_driving  (�s�r����)*/

        /* �Ǧ^�Ѽ�=======> */
        /* �j���Iñ��O�I�O */
        /* �j���I�W���O�I�O */
        /* �S�O�ǳƪ��A���v����A�w�w��� */
        /* ���ά�s�o�i�O�ΡA��������A��ꦬ�q */
        /* �~�ȶO�βb�ȡA�k�w�~�ȶO�� */
        /* �«O�O�A����O */
        /* �j��s�O�O:�@�~���O�O */
        /* ������O�Ǹ� */
        /* �t�X�s�r�[�O,�s�W�T�ӰѼ� add by sylvia 103.01.07 (1020801002_C1)
           �Ǧ^��:Gdrunk_prem (�s�r�O�O), Gdrunk_pure_prem (�s�r�«O�O) */
        /* �t�X�L�q���W�[15�ӰѼ� abb by 061476 (1110718002_SC1) */
        /*printf("resource[%s]\n",resource);*/
        printf("-- trace bf Cal_prem_21() mservice[%d]\n ",mservice);

        /* �t�X��椣�ˮֳq�����v, �T�w�ǫO�����O=P(�O��) modify by sylvia 101.02.07 */
        
        code = Cal_prem_21 (cartype1, fcar_class1,
                            officer1, ZA_mbusiness,
                            ply1_begin, ply1_end, ply1_period,
                            broker1, comp_rym,
                            qpt,
                            assuredf, psex_age1, plia_acc1,
                            abn_type, lTmpPremium1,
                            fstart1, iroute, irate_type1, iroute_comm1,qdrunk_driving, qviolate,
                            &premium1,
                            &bef_ins_premium1,
                            &mready, &mcompensation, &mstable,
                            &mresearch, &mcapital, &minvest,
                            &maintain, &mbusiness, &mbus_rule,
                            &madjcom_prem, &mcommission21,
                            &premium1_24,estimatei,resource,mservice,
                            &lFirstYear_bef, &tmp_mbusiness_21, &maintain21, &ZA_mbusiness_1, &research21,
                            &lSecondYear_bef, &dblSy_mbusiness, &secMaintain21, &ZA_mbusiness_2, &secResearch21,
                            fcheck,"P",&Gdrunk_prem,&Gdrunk_pure_prem,fNewCompBusi,&mviolate_prem,&mviolate_pure_prem,
                            &lThirdYear_bef, &dblSy_mbusiness_3, &thirdMaintain21, &ZA_mbusiness_3, &thirdResearch21,
                            &lFourthYear_bef, &dblSy_mbusiness_4, &fourMaintain21, &ZA_mbusiness_4, &fourResearch21,
                            &lFifthYear_bef, &dblSy_mbusiness_5, &fifMaintain21, &ZA_mbusiness_5, &fifResearch21);
        if (code != SUCCESS)
        {
            return code;
        }
        
        /* �����~��: �j���I�����B �U���ˮ� */
        if (strncmp(bzfrom1,"40",2)==0 || strncmp(bzfrom1,"41",2)==0)
        {
            /* ���o�U���]�w��*/
            if(strncmp(car_typei1, "35", 2) != 0)
            {
                intYear=0;
                $DECLARE curDiscLimit CURSOR FOR
                  Select detail2::integer From car_code where kind = 'CD' and detail[1]<>'Y' order by detail[2] ;
                $OPEN curDiscLimit;
                for(;;)
                {
                    $FETCH curDiscLimit INTO $intDiscMinLimit[intYear];		         		         
                    if (SQLCODE == SQLNOTFOUND) break;
                    intYear++;	
                    /*printf("-- trace intYear[%d]\n ",intYear);
                    printf("-- trace intDiscMinLimit[%d][%d]\n ",intYear,intDiscMinLimit[intYear]);*/		         			         
                }
                $CLOSE curDiscLimit;
                $FREE curDiscLimit;
                printf("-- trace intYear[%d]\n ",intYear);
                if (intYear < 2)
                {
                    strcpy(v_errMsg, "�j���I�����~�ȡu�̧C�����B�v�]�w���~�A�Ь���T��(car140,���O=CD)");
                    return M_CM_ORDINARY_CHECK;  	
                }

                /* �ˮ� */
                intYear = 0;
                if( (strncmp(car_typei1, "01", 2) ==0) || 
                    (strncmp(car_typei1, "02", 2) ==0) || 
                    (strncmp(car_typei1, "32", 2) ==0) || 
                    (strncmp(car_typei1, "34", 2) ==0) ||
                    (strncmp(car_typei1, "35", 2) ==0) )
                {
                    intYear = (int)(ply1_period / 12) ;
                    if (intYear < 2) intYear = 1;
                    else if (intYear < 3) intYear = 2;
                    else if (intYear < 4) intYear = 3;
                    else if (intYear < 5) intYear = 4;
                    else intYear = 5;

                }
                /*
                printf("-- trace intYear[%d]\n ",intYear);
                printf("-- trace intDiscMinLimit[%d]=[%d]\n ",intYear,intDiscMinLimit[intYear]);
                printf("-- trace tmp_mbusiness_21[%f]\n ",tmp_mbusiness_21);
                printf("-- trace dblSy_mbusiness[%f]\n ",dblSy_mbusiness);
                printf("-- trace dblSy_mbusiness_3[%f]\n ",dblSy_mbusiness_3);
                printf("-- trace dblSy_mbusiness_4[%f]\n ",dblSy_mbusiness_4);
                printf("-- trace dblSy_mbusiness_5[%f]\n ",dblSy_mbusiness_5);
                printf("-- trace ZA_mbusiness[%f]\n ",ZA_mbusiness);
                */
                if (intYear == 1)
                {   
                    /*printf("-----1\n");*/
                    if ((tmp_mbusiness_21 - ZA_mbusiness) < intDiscMinLimit[intYear] )
                    {
                        sprintf_s(v_errMsg,sizeof v_errMsg,"�j���I�����~�ȡA�u�����B�v���o�C�� [%d]", intDiscMinLimit[intYear]);
                        return M_CM_ORDINARY_CHECK; 
                    }
                }
                else if (intYear == 2)
                {
                    /*printf("-----2\n");*/
                    if ((dblSy_mbusiness + tmp_mbusiness_21 - ZA_mbusiness) < intDiscMinLimit[intYear] )
                    {
                        sprintf_s(v_errMsg,sizeof v_errMsg,"�j���I�����~�ȡA�u�����B�v���o�C�� [%d]", intDiscMinLimit[intYear]);
                        return M_CM_ORDINARY_CHECK; 
                    }

                }
                else if (intYear == 3)
                {
                    /*printf("-----3\n");*/
                    if ((dblSy_mbusiness_3 + dblSy_mbusiness + tmp_mbusiness_21 - ZA_mbusiness) < intDiscMinLimit[intYear] )
                    {
                        sprintf_s(v_errMsg,sizeof v_errMsg,"�j���I�����~�ȡA�u�����B�v���o�C�� [%d]", intDiscMinLimit[intYear]);
                        return M_CM_ORDINARY_CHECK; 
                    }

                }
                else if (intYear == 4)
                {
                    /*printf("-----4\n");*/
                    if ((dblSy_mbusiness_4 + dblSy_mbusiness_3 + dblSy_mbusiness + tmp_mbusiness_21 - ZA_mbusiness) < intDiscMinLimit[intYear] )
                    {
                        sprintf_s(v_errMsg,sizeof v_errMsg,"�j���I�����~�ȡA�u�����B�v���o�C�� [%d]", intDiscMinLimit[intYear]);
                        return M_CM_ORDINARY_CHECK; 
                    }

                }
                else
                {
                    /*printf("-----5\n");*/
                    if ((dblSy_mbusiness_5 + dblSy_mbusiness_4 + dblSy_mbusiness_3 + dblSy_mbusiness + tmp_mbusiness_21 - ZA_mbusiness) < intDiscMinLimit[intYear] )
                    {
                        sprintf_s(v_errMsg,sizeof v_errMsg,"�j���I�����~�ȡA�u�����B�v���o�C�� [%d]", intDiscMinLimit[intYear]);
                        return M_CM_ORDINARY_CHECK; 
                    }

                }            	
            		
            }
            else
            {
                intYear=1;
                $DECLARE curDiscLimit35 CURSOR FOR
                  Select detail2::integer From car_code where kind = 'CD' and detail[1]='Y' order by detail[2] ;
                $OPEN curDiscLimit35;
                for(;;)
                {
                    $FETCH curDiscLimit35 INTO $intDiscMinLimit35[intYear];		         		         
                    if (SQLCODE == SQLNOTFOUND) break;
                    intYear++;	
                    /*printf("-- trace intYear[%d]\n ",intYear);
                    printf("-- trace intDiscMinLimit35[%d][%d]\n ",intYear,intDiscMinLimit35[intYear]);	*/	         			         
                }
                $CLOSE curDiscLimit35;
                $FREE curDiscLimit35;
                printf("-- trace intYear[%d]\n ",intYear);
                if (intYear < 2)
                {
                    strcpy(v_errMsg, "�j���I�����~�ȡu�̧C�����B�v�]�w���~�A�Ь���T��(car140,���O=CD)");
                    return M_CM_ORDINARY_CHECK;  	
                }

                /* �ˮ� */
                intYear = 0;
                if( (strncmp(car_typei1, "01", 2) ==0) || 
                    (strncmp(car_typei1, "02", 2) ==0) || 
                    (strncmp(car_typei1, "32", 2) ==0) || 
                    (strncmp(car_typei1, "34", 2) ==0) ||
                    (strncmp(car_typei1, "35", 2) ==0) )
                {
                    intYear = (int)(ply1_period / 12) ;
                    if (intYear < 2) intYear = 1;
                    else if (intYear < 3) intYear = 2;
                    else if (intYear < 4) intYear = 3;
                    else if (intYear < 5) intYear = 4;
                    else intYear = 5;

                }
                /*
                printf("-- trace intYear[%d]\n ",intYear);
                printf("-- trace intDiscMinLimit35[%d]=[%d]\n ",intYear,intDiscMinLimit35[intYear]);
                printf("-- trace tmp_mbusiness_21[%f]\n ",tmp_mbusiness_21);
                printf("-- trace dblSy_mbusiness[%f]\n ",dblSy_mbusiness);
                printf("-- trace dblSy_mbusiness_3[%f]\n ",dblSy_mbusiness_3);
                printf("-- trace dblSy_mbusiness_4[%f]\n ",dblSy_mbusiness_4);
                printf("-- trace dblSy_mbusiness_5[%f]\n ",dblSy_mbusiness_5);
                printf("-- trace ZA_mbusiness[%f]\n ",ZA_mbusiness);
                */
                if (intYear == 1)
                {   
                    /*printf("-----1\n");*/
                    if ((tmp_mbusiness_21 - ZA_mbusiness) < intDiscMinLimit35[intYear] )
                    {
                        sprintf_s(v_errMsg,sizeof v_errMsg,"�j���I�����~�ȡA�u�����B�v���o�C�� [%d]", intDiscMinLimit35[intYear]);
                        return M_CM_ORDINARY_CHECK; 
                    }
                }
                else if (intYear == 2)
                {
                    /*printf("-----2\n");*/
                    if ((dblSy_mbusiness + tmp_mbusiness_21 - ZA_mbusiness) < intDiscMinLimit35[intYear] )
                    {
                        sprintf_s(v_errMsg,sizeof v_errMsg,"�j���I�����~�ȡA�u�����B�v���o�C�� [%d]", intDiscMinLimit35[intYear]);
                        return M_CM_ORDINARY_CHECK; 
                    }

                }
                else if (intYear == 3)
                {
                    /*printf("-----3\n");*/
                    if ((dblSy_mbusiness_3 + dblSy_mbusiness + tmp_mbusiness_21 - ZA_mbusiness) < intDiscMinLimit35[intYear] )
                    {
                        sprintf_s(v_errMsg,sizeof v_errMsg,"�j���I�����~�ȡA�u�����B�v���o�C�� [%d]", intDiscMinLimit35[intYear]);
                        return M_CM_ORDINARY_CHECK; 
                    }

                }
                else if (intYear == 4)
                {
                    /*printf("-----4\n");*/
                    if ((dblSy_mbusiness_4 + dblSy_mbusiness_3 + dblSy_mbusiness + tmp_mbusiness_21 - ZA_mbusiness) < intDiscMinLimit35[intYear] )
                    {
                        sprintf_s(v_errMsg,sizeof v_errMsg,"�j���I�����~�ȡA�u�����B�v���o�C�� [%d]", intDiscMinLimit35[intYear]);
                        return M_CM_ORDINARY_CHECK; 
                    }

                }
                else
                {
                    /*printf("-----5\n");*/
                    if ((dblSy_mbusiness_5 + dblSy_mbusiness_4 + dblSy_mbusiness_3 + dblSy_mbusiness + tmp_mbusiness_21 - ZA_mbusiness) < intDiscMinLimit35[intYear] )
                    {
                        sprintf_s(v_errMsg,sizeof v_errMsg,"�j���I�����~�ȡA�u�����B�v���o�C�� [%d]", intDiscMinLimit35[intYear]);
                        return M_CM_ORDINARY_CHECK; 
                    }
                } 	
            }
        }
         
        /* 1050803001 _C1 �ӽзs�W�ܺ��I�j���I�Y�ɶǿ�@�~ */
        strcpy(ftrans_trade, "0");
        rc = GetTransTradeFlag(estimatei,ftrans_trade);	    
        if (rc != M_CM_OK)
        {     
            return rc;
        }
    }

    printf("CA3011OptAU=>mcommission21:%d>>\n",mcommission21);
    printf("CA3011OptAU=>compulsory_premium:%d>>\n",premium1);
    printf("COMPULSORY_PREM:madjcom_prem[%lf],mready[%lf],mcompensation[%lf],mstable[%lf]\n", madjcom_prem , mready , mcompensation , mstable);

    if (ply2f==TRUE)
    {
        iSecondYear2 = ply2_period - 12;

        if (iSecondYear2 > 0)
        {
            cm_long_split_3ymd(ply2_begin, sTmpyyB, sTmpmmB, sTmpddB);
            cm_long_split_3ymd(ply2_end, sTmpyyE, sTmpmmE, sTmpddE);
            ply3_period = 12;
        }
    }

    /***************** STEP 8 ***********************************/
    step_8:
    
    adj_year = 0;

    strcpy(idmg_rate,"00");
    strcpy(ibrg_rate,"00");
       
    adj_year = 0;

    if (ply2f!=TRUE)
    {
        /*** ��O�j���I ***/
    }
    else
    {
        t_count = 0;
        /* �I��20,23�H��86�h��@�~ */
        /* �I��101�B102(�q�ʦۦ樮)�]�n�h��@�~ add by sylvia 102.08.10 (1020430001_C1) */
        if( Scan_INS_TYPE(20)  || Scan_INS_TYPE(86)  || Scan_INS_TYPE(23) ||
            Scan_INS_TYPE(101) || Scan_INS_TYPE(102) || Scan_INS_TYPE(110)|| Scan_INS_TYPE(111))
        {
            /* 103.04.30:1030407005_C1_�ӽзs�ӫ~�W�u-������X�O�I*/
            /* �I��20,23�H��86�h��@�~ */
            /* �I��101,102(�q�ʦۦ樮)�]�n�h��@�~ add by sylvia 102.08.10(1020430001_C1) */        	
            adj_year = 1;
            
            if (car_price >= mcar_price*1.10)
            {
                t_count = 1;
            }
        }
        else if ( Scan_INS_TYPE(1)  || Scan_INS_TYPE(5)  || Scan_INS_TYPE(9)  || Scan_INS_TYPE(11)  ||
                  Scan_INS_TYPE(75) || Scan_INS_TYPE(76) || Scan_INS_TYPE(129)|| Scan_INS_TYPE(198) ||
                  Scan_INS_TYPE(181)|| Scan_INS_TYPE(201)|| Scan_INS_TYPE(205)|| Scan_INS_TYPE(209) ||
                  Scan_INS_TYPE(211)
                )
        {
            /* 1050829003_C1 ���m����W�L�]�w���B10%*/
            /* 1090812005-SC1-���ά�-�s�W�s�ӫ~-�T�����B���郞�I���l���O�I198�I*/
            /*1100909003-SC1-�_�@�Ϯ��S�h���p�{������07+15�}���O181�I�ݨD*/
            if ((car_price >= mcar_price*1.10) || (car_price <= mcar_price*0.90))
            {
                t_count = 1;
            }
        }           
        
        if (t_count == 1)
        {
            strcpy(errmsg_chk, itoa(M_CA_CAR_PRICE));
            if (strstr(errmsg_tmp, errmsg_chk) == NULL)
            {
                strcat(errmsg_tmp, errmsg_chk);
                strcat(errmsg_tmp, ";");
            }
        }
        
        /* 1061205007_C1_���������ڰӫ~�Χ��²v���[���ڤW�u */
        /* 1050226003_C1�s�W�u�T���O�I���w���²v���[���ڡv�@�~ */ 
        strcpy(fProvision_Z,"N");  strcpy(fProvision_P,"N");  strcpy(fProvision_Q,"N");  
        strcpy(fProvision_K,"N"); /* 1080408008-SC1-��ã��-98������09+K*/
        strcpy(fProvision_M,"N");/* 1081105005-SC1-��ã��-�ק���~���w���ƫ������²v�Φۭt�B(M����)*/
        if(Scan_INS_TYPE_Prov("Z")) strcpy(fProvision_Z,"Y"); 
        if(Scan_INS_TYPE_Prov("P")) strcpy(fProvision_P,"Y");  
        if(Scan_INS_TYPE_Prov("Q")) strcpy(fProvision_Q,"Y");
        if(Scan_INS_TYPE_Prov("K")) strcpy(fProvision_K,"Y"); 
        if(Scan_INS_TYPE_Prov("M")) strcpy(fProvision_M,"Y"); 

        printf("---- CA305OOptAU --------- \n");
        
        code = SetCarAge(officer,brandi, adj_year, frate);
        if (code != SUCCESS) return code;

        car_tp=atoi(cal_car_id);

        step_9:

        /**** calculate aa[������O], ee1[���l�h���u��], ee2[���d�I�h�����u��], ee3[�ѵs�I�h�����u��]  ****/
        code=SetFactor(acc_align);
        if (code != SUCCESS) return code;

        /**** check bb11:�t�P���ب��l�Y��,bb12:�t�P�����ѵs�Y�� ****/
        /*1040202006_C1 �s�W���ؤ���~�����²v�վ�*/
        bb11 = 0;            bb12 = 0;
        pdmg_factor_1st = 0; pdmg_factor_2nd = 0;
        pbrg_factor_1st = 0; pbrg_factor_2nd = 0;     
         
        if ((fcar_class2[0]=='1'
             && strcmp(car_typei2,"03")!=0
             && strcmp(car_typei2,"04")!=0
             && strcmp(car_typei2,"19")!=0
             && strcmp(car_typei2,"21")!=0
             && strcmp(car_typei2,"22")!=0 && (!(ISNEW_CAR1(car_typei2))) ) ||
            (fcar_class2[0]=='2'
             && strcmp(car_typei2,"07")!=0
             && strcmp(car_typei2,"08")!=0
             && strcmp(car_typei2,"14")!=0
             && strcmp(car_typei2,"15")!=0 && (!(ISNEW_CAR2(car_typei2))) )
          )
        {
            strncpy(tmp_brand,brandi,6);
            tmp_brand[6]='\0';
            /*printf("tmp_brand[%s], car_typei2[%s]\n",tmp_brand,car_typei2);
            printf("-- trace fag01[%d]\n ",fag01);*/
            $SELECT pdmg_factor, pbrg_factor,
                    pdmg_factor, pbrg_factor
               INTO $pdmg_factor_1st, $pbrg_factor_1st,
                    $pdmg_factor_2nd, $pbrg_factor_2nd
               FROM car_model_align
              WHERE ibrand    = $tmp_brand
                AND icar_type = $car_typei2
                AND drate = (SELECT drate
                               FROM ca_rate_date
                              WHERE icode=$frate
                                AND itable='car_model_align');

            if (NOT_FOUND && fag01==1)
                return M_CA_NCMODELALIGN;
            else if (NOT_FOUND)
            {
                bb11=0;
                bb12=0;
                pdmg_factor_1st=0;
                pbrg_factor_1st=0;
            }
            else
            {
                bb11 = pdmg_factor_1st;
                bb12 = pbrg_factor_1st;
                pdmg_factor_1st = pdmg_factor_1st;
                pbrg_factor_1st = pbrg_factor_1st;
            }
        }
        else
        {
            bb11 = 0;
            bb12 = 0;
            pdmg_factor_1st = 0;
            pbrg_factor_1st = 0;
        }/* end of car_model_align */


        code=Cal_ins_premium(INS_ptr,1,DATENULL,INS_ptr_33,INS_ptr_48, INS_ptr_35, INS_ptr_56);

        if (code != SUCCESS) return code;

        if (premium2<200) InsAbnID(PREMIUM2);

        mlia_prem=premium2-mdmg_prem;
        mlia_pure_prem=pure_premium-mdmg_pure_prem;
    }

    if (strlen(trim(last_ply))== 0)
    {

        if (!isalpha(ibig_comp1[0]) &&
            !isalpha(ibig_comp2[0]) &&
            strlen(estimatei)!=(CAR_ESTIMATE_LEN+CAR_TARGET_LEN))
            ABMSG[0]='\0';
    }

    premium = premium1+premium2;

    
    /* 1120923005_C02_�s�W�妸�X��\�� */
    /* �ˮ֬O�_���{���� */
    if (g_frenew_type[0]=='6')
    {
        if (ply2f==TRUE)
        {
            printf("*****�ˮ֬O�_���{����*****\n");
            rtncode = ca_fac_plycheck(Ifirst ,estimatei, " ", " ", "1", ply2_begin ,ply2_end ," ",'B');
            if (rtncode == M_CA_DO_FAC)
            {
                printf("**********���{��*********\n");
                strcpy(v_errMsg,"���{���A�Ч�ĳ浧�X��");
                return M_CM_ORDINARY_CHECK; 
            }
        }    	
    	
    }


    /************************** END **************************************/

    return SUCCESS;

optau_err:
    printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    sprintf_s(v_errMsg,sizeof v_errMsg,"CA3011OptAU()���~:SQLCODE=[%d]sqlca.sqlerrm=[%s],sqlca.sqlerrd[1]=[%d]", SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);     
    return SQLCODE;
}

static int CA3011_Step11(type)
int type;
{
    $char fagent[2], ins[INSURANCE_TYPE], fins_grp_1[2];

    $WHENEVER SQLERROR GOTO step11_err;

    mdmg_agent_1   = mlia_agent_1   = mdmg_commi_1 = mlia_commi_1 = 0;
    mdmg_agent_2   = mlia_agent_2   = mdmg_commi_2 = mlia_commi_2 = 0;
    mdmg_disco_2   = mlia_disco_2   = 0;
    mdmg_prem      = mlia_prem      = 0;
    mdmg_pure_prem = mlia_pure_prem = 0;

    if (ply2f==TRUE )
    {
        INS_ptr=Ifirst;
        while (INS_ptr)
        {
            strcpy(ins,trim(INS_ptr->ins_type));

            $SELECT fins_grp
               INTO $fins_grp_1
               FROM insurance_type
              WHERE iins_type=$ins;
            if (NOT_FOUND)  return M_CA_NINS_TYPE;

            printf("INS_ptr->ins_premium[%lf]\n",INS_ptr->ins_premium);
            printf("INS_ptr->pure_ins_premium[%lf]\n",INS_ptr->pure_ins_premium);

            if ((fins_grp_1[0]=='1') && (strcmp(trim(INS_ptr->fproject),"Y") != 0))
            {
                printf("In 305 CA3011_Step11 pdiscount1=%lf\n",INS_ptr->pdiscount);

                /* ���l�����N�z�O�[�` */
                mdmg_agent_2=mdmg_agent_2+INS_ptr->magent;
                mdmg_commi_2=mdmg_commi_2+INS_ptr->mcommission;
                mdmg_disco_2=mdmg_disco_2+INS_ptr->mdiscount;

                mdmg_prem      = mdmg_prem      + (long)INS_ptr->ins_premium;
                mdmg_pure_prem = mdmg_pure_prem + (long)INS_ptr->pure_ins_premium;
            }
            else if ((fins_grp_1[0]=='2') && (strcmp(trim(INS_ptr->fproject),"Y") != 0))
            {
                printf("In 305 CA3011_Step11 pdiscount2=%lf\n",INS_ptr->pdiscount);

                /* ���d�����N�z�O�[�` */
                mlia_agent_2=mlia_agent_2+INS_ptr->magent;
                mlia_commi_2=mlia_commi_2+INS_ptr->mcommission;
                mlia_disco_2=mlia_disco_2+INS_ptr->mdiscount;

                mlia_prem      = mlia_prem      + (long)INS_ptr->ins_premium;
                mlia_pure_prem = mlia_pure_prem + (long)INS_ptr->pure_ins_premium;
            }

            INS_ptr=INS_ptr->next;
        } /*while*/

        /* �ˮ־����[�O�Τ��o���t��,�Yñ��O�O���o�C��«O�I�O */
        printf("CA3011_Step11 check loading=>mdmg_prem[%ld],mlia_prem[%ld],mdmg_pure_prem[%ld],mlia_pure_prem[%ld]\n", mdmg_prem, mlia_prem, mdmg_pure_prem, mlia_pure_prem);

        if ((mdmg_prem+mlia_prem) - (mdmg_pure_prem+mlia_pure_prem) < 0)
            return M_CA_LOADING_ERROR;
            
    }/*���N*/

    if (ply1f==TRUE)
    {
        mlia_commi_1=(long)mcommission21;
        printf("step11:after calculate mlia_commi_1[%d]\n",mlia_commi_1);
    }

    return SUCCESS;

step11_err:
    printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    sprintf_s(v_errMsg,sizeof v_errMsg,"CA3011_Step11()���~:SQLCODE=[%d]sqlca.sqlerrm=[%s],sqlca.sqlerrd[1]=[%d]", SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);      
    return SQLCODE;
}

static int CA3011_Step12(type,wk_fac_1)
int  type;
char wk_fac_1;
{
    int   code, i, flag_back=0, fInsertCompulsory=FALSE,fTry;
    long  rcl;
    $char ymd[12], stmt_buf[300];
    $char ymd_Today[12];
    $char imark[CA_TARGET_NUM],fbig_ply[2],tmp_est[CA_ESTIMATE_NUM];
    $char tmp_icardyear[5];
    $char tmp_ply_num1[20],tmp_ply_num2[20];
    $char est[CA_ESTIMATE_NUM];
    char  sIbilling[4];
    $char sTmpIbranchCard[BRANCH_ID], sTmpIcompCard[BRANCH_ID];

    $char   rel_dbname1[20];
    $char   rel_dbname2[20];
    $char   last_dbname[20], sTmp[21];
    $int    iply_seq, iCount_accept;
    $char   iroute4[5];
    $char   sTmp_date[10]=" ";

    $WHENEVER SQLERROR GOTO step12_err;

    printf("----------->estimatei[%s]\n",estimatei);

    printf("{CAR305_step12}:relative_card[%s] , last_ply[%s] , last_card[%s] \n", relative_card , last_ply , last_card);
    /*printf("INTO CAR305_step12 equipment[%s]\n",equipment);*/

    /***** a. *****/
    code=0;
    strcpy(ply_num1  ,  " "); strcpy(ply_num2  ,  " ");
    strcpy(ymd_Today, cm_cdate_str_100(Today));
    strcpy(tmp_est  , estimatei);

    tmp_est[CAR_ESTIMATE_LEN]='\0';
    if (strlen(estimatei)==(CAR_ESTIMATE_LEN+CAR_TARGET_LEN))
        strcat(tmp_est,"0001");

    /*printf("tmp_est[%s]\n",tmp_est);*/

    if (strlen(estimatei)==(CAR_ESTIMATE_LEN+CAR_TARGET_LEN))
    {
        strncpy(imark,&estimatei[CAR_ESTIMATE_LEN],CAR_TARGET_LEN);
        imark[CAR_TARGET_LEN]='\0';
    }
    else
        imark[0]='\0';

    /*printf("imark[%s] , type[%d]\n",imark,type);*/
    
    
    /******************/
    /*  ���j��O�渹  */
    /******************/
    
    /*****************ply1f*****************/
    if (ply1f==TRUE)
    {
        sIbilling[0] = '\0';

        if ((strncmp(car_typei1, "01", 2) ==0) ||
            (strncmp(car_typei1, "02", 2) ==0) ||
            (strncmp(car_typei1, "32", 2) ==0) ||
            (strncmp(car_typei1, "34", 2) ==0) ||
            (strncmp(car_typei1, "35", 2) ==0))
        {
            if (strncmp(trim(iroute), "JB",2) == 0)
                strcpy(sIbilling, "MJ1"); /*** 080�����I ***/
            else
                strcpy(sIbilling, "MR"); /*** �����I ***/
        }
        else
        {
            if (strncmp(trim(iroute), "JB",2) == 0)
                strcpy(sIbilling, "CJ1"); /*** 080�T���I ***/
            else
                strcpy(sIbilling, "CR"); /*** �T���I ***/
        }

        sIbilling[3] = '\0';
        strcpy(ymd, cm_cdate_str_100(ply1_begin));        
        fTry = 0;

RETRY:
        /*  cm_get_serial_num_dwritten()���w��lock mode wait 2sec */
        for (i=0; i<2; i++)
        {
            code=cm_get_serial_num_dwritten("C1",sIbilling,sTmpIcomp,sTmpIbranch, ymd_Today, ymd_Today, ply_num1);
            if (code==0)
            {               
                break;
            } 
        }

        if (code!=0)
        {                                             
            if (fTry == 0)
            {
                sleep(1);
                fTry = 1;
                goto RETRY;
            }
            
            if (code==1 || code==2)  return M_CM_DB_NOTOPEN;
            else if (code==3)  return M_CMN_NAUTONUMBERING;
            else if (code!=0)  return code;
        }
        
        ply_num1[CAR_POLICY_LEN]='\0';
    }
    
    printf("--- ply_num1[%s]\n", ply_num1);
    
    
    /******************/
    /*  �����N�O�渹  */
    /******************/
    
    /*****************ply2f*****************/
    if (strlen(rtrim(estimatei))!= CAR_ESTIMATE_TAG_LEN ||
        strcmp(imark,"0001")==0)
    {    
    	/*�D�j�O��Τj�O��Ĥ@��*/
        if (ply2f==TRUE)
        {
            fTry = 0;
RETRY2:    
            /* �����O�T�D�O�渹��VW�r�y */
            if ( strncmp( iext_policy+(6-1),"VW",2)==0 )
            {
                code = get_VW_ipolicy_num( iext_policy, ply_num2, v_sMsg);  /* �������O�T�l�O�渹�A�p�G00095VW0005010001 */
                printf("1:ply_num2[%s]\n", ply_num2);
                if( code != M_CM_OK)
                    return code;
            }
            else
            {
                /* �P�_�q���N��=JB(����),���t�@�զr�y add by sylvia 101.10.23 (1011011002_C1) */
                strcpy(ymd,cm_cdate_str_100(ply2_begin));
                if (strncmp(trim(iroute), "JB",2) == 0)
                {
                    /* try 3 �� ( cm_get_serial_num_dwritten()���w��lock mode wait 2sec )*/
                    for (i=0; i<2; i++)
                    {
                        code=cm_get_serial_num_dwritten("C1", "CJ2",sTmpIcomp,sTmpIbranch,
                        ymd_Today, ymd_Today, ply_num2);
                        if (code==0)
                        {
                            break;
                        } 
                    }                
                }
                else
                {
                    /* �q�ʦۦ樮�t�~����(EB) add by sylvia 102.08.10 (10204300001_C1) */
                    /* try 3 �� ( cm_get_serial_num_dwritten()���w��lock mode wait 2sec )*/
                    for (i=0; i<2; i++)
                    {
                        /*1040505003_C1 �s�W���N�I�O��r�y-�Ϳ��O�N*/
                        if (ibig_comp2[0]=='A')
                        {
                            code=cm_get_serial_num_dwritten("C1", "CVA", sTmpIcomp, sTmpIbranch, ymd_Today, ymd_Today, ply_num2);
                        }
                        else if (strcmp(car_typei2,"51") == 0)
                        {
                            code=cm_get_serial_num_dwritten("C1", "CE", sTmpIcomp, sTmpIbranch, ymd_Today, ymd_Today, ply_num2);
                        }
                        else if (strcmp(car_typei2,"T1") == 0 || strcmp(car_typei2,"T2") == 0) /*1050105002_C1 �T���~���ը�����X�O�I*/
                        {
                            code=cm_get_serial_num_dwritten("C1", "CT", sTmpIcomp, sTmpIbranch, ymd_Today, ymd_Today, ply_num2);
                        }
                        else
                        {
                            code=cm_get_serial_num_dwritten("C1", "CB", sTmpIcomp, sTmpIbranch, ymd_Today, ymd_Today, ply_num2);
                        }

                        if (code==0)
                        {
                            break;
                        } 
                    }  
                }
                
                if (code!=0)
                {  
                    if (fTry == 0)
                    {
                        sleep(1);
                        fTry = 1;
                        goto RETRY2;
                    }                           
                    if (code==1 || code==2)  return M_CM_DB_NOTOPEN;
                    else if (code==3)  return M_CMN_NAUTONUMBERING;
                    else if (code!=0)  return code;
                }
                
                ply_num2[CAR_POLICY_LEN]='\0';
                if ((strncmp(&estimatei[5],"CR",2) == 0)||(strncmp(&estimatei[4],"CVQ",3) == 0))
                {
                    /* ��O�J�p���ު��� */
                }
                else
                    strncat(ply_num2,&estimatei[CAR_ESTIMATE_LEN],CAR_TARGET_LEN);
            }
        }
    }
    else
    {
        if (ply2f==TRUE)
        {
            if ( strncmp( iext_policy+(6-1),"VW",2)==0 )
            {
                code = get_VW_ipolicy_num( iext_policy, ply_num2, v_sMsg);  /* �������O�T�l�O�渹�A�p�G00095VW0005010001 */
                printf("2:ply_num2[%s]\n", ply_num2);
                if( code != M_CM_OK)
                    return code;
            }
            else
            {
                if (type==1)
                {
                    $SELECT ipolicy2 INTO $ply_num2
                       FROM estimate
                      WHERE iestimate=$tmp_est;
                    if (NOT_FOUND)
                    {
                        strncpy(est,tmp_est,CAR_ESTIMATE_LEN);
                        est[CAR_ESTIMATE_LEN]='\0';
                        strcat(est,"*");

                        $SELECT old_big_ply INTO $ply_num2
                           FROM estimate
                          WHERE iestimate=(SELECT MIN(iestimate) FROM estimate
                                            WHERE iestimate MATCHES $est);
                        if (NOT_FOUND)  return M_CA_NPOLICY;
                    }
                    if(ply_num2[0]==' ' || ply_num2[0]=='\0') return M_CA_NPOLICY1;
                }

                ply_num2[CAR_POLICY_LEN]='\0';
                strcat(ply_num2,imark);
            }
        }
    }
    printf("--- ply_num2[%s]\n", ply_num2);
    printf("-- trace card2[%s]\n ",card2);
    
    /****************/
    /*  �����N�d��  */
    /****************/
    
    /********** insert card2 **************************/
    /* 1030630002_C2_���M�ץ�@�~�Ҧ��վ�(N�g��M�ץ�Ѩt�Φ۰ʨ��d��) */
    if (ply2f==TRUE && IsBlankNull(card2))
    {
        strcpy(ymd,cm_cdate_str_100(ply2_begin));
        fTry = 0;
RETRY1:
        for (i=0; i<2; i++)
        {
            code=cm_get_serial_num_dwritten("C1", "CP", sTmpIcomp, sTmpIbranch, ymd_Today, ymd_Today, card2);
            if (code==0)
            {
                break;
            }                                            
        }                                            
        if (code!=0)
        {

            if (fTry == 0)
            {
                sleep(1);
                fTry = 1;
                goto RETRY1;
            }         
            if (code==1 || code==2)  return M_CM_DB_NOTOPEN;
            else if (code==3)  return M_CMN_NAUTONUMBERING;
            else if (code!=0)  return code;
        } 
         
        
        int icardYear;
        cm_long_split_3ymd( ply2_begin, sTmpyyB, sTmpmmB, sTmpddB);
        icardYear = atoi( sTmpyyB); /* ����~098�ର98 */
        sprintf_s( tmp_icardyear,sizeof tmp_icardyear,"%d", icardYear);
        

        $SELECT b.ibranch, b.iupbranch
           INTO :sTmpIbranchCard, :sTmpIcompCard
           FROM officer a , branch b
          WHERE a.ibranch = b.ibranch
            and a.iofficer = :officer2;
        if (SQLCODE==SQLNOTFOUND)
        {
            sTmpIbranchCard[0] = '\0';
            sTmpIcompCard[0] = '\0';
        }

        $INSERT INTO card
                (icard,iofficer,ioffice,icardyear,dissue,fstatus,ialter,
                 icar_type,iissue_branch,iissue_comp,iquota,
                 ireceive,ideliver,ideliver_old,dreceive,ddeliver)
         VALUES ($card2,$officer2,$ibranch2,$tmp_icardyear,$Today,"0", $entry,
                 $car_typei2,$sTmpIbranchCard,$sTmpIcompCard,$sIquota2,
                 $officer2,$officer2,$officer2,$Today,$Today);

    }
   

    /******** update relative *************************/
    printf("@@@@@@@@ply_num2[%s],tmp_icardyear[%s]\n",ply_num2,tmp_icardyear);

    /****************/
    /*  �����z�s��  */
    /****************/
    
    /*
     �P���󤣩�b CA3011OptAU()���@��  �H �]�� cm_get_serial_num() �����b������A�P���קK�X�楢�Ѧ��w����
     �P���󤣩�b InsertPly_Step1x()���H �]��InsertPly_Step1x() �|�j��B���N������@���A�y���U���@���s��
     => �G���O��b CA3011_Step12()(�D���`��) �P CA305_Step13()(���`��)�� ����
    */
    /* 1040909005_C1 �X�w���z�s���W�h�ק� :

         ��car301�X��ɡA�u���z�s���v��줣���\��J�A�Ѩt�Φ۰ʶ�J�~�޳��
         ��CAR148(ca_accept)��J�����z�s���A����^������G
        (1)�i���z��j�b�X���60��(�t�Τ�-60��)���d�򤺡C
        (2) �H�i�Q�O�I�HID�j+�i�����j���j�M����ǡC
        (3) ���z�s����[���A] ����[D�R��]�C
        (4) �|���X���(�w�X��̷|�^���O�渹)
         ==>
            (i)�Y���G���H�W�ɡA�h���̷s���@�ը��z�s���C
            (ii)�Y�䤣���ƮɡA�h�Ѩt�Φ۰ʨ����A�����W�h�p�U�G
                 217 + �J���(CYYMMDD) + �y����(3�X)   (�@13�X)
            ��	 �y�����ݱq ��501�� �_�l�A EX. 2171040924501
               (�]001~500�����X�w�ϥ�/���Ѥ����z�s���A����Jcar148��)

  ��        �Y�y���� �� 999�A�h�^�ǰT��"�Ȱ��۰ʵ���" *
  
    /* ----  ���X�w���z�s�� add by sylvia 101.09.24 (1010813001_C1)  -------- */
    /* �X�w�s��(�S����O�������s��)�۰ʦ�ca_accept���o���z�s��
        1.���z��b�X���60��(�t�Τ�-60��)�d��
        2.�H�Q�O�I�HID+�������j�M��¦
        3.���z�s�����A���� D (�R��)
        4.���X��(�L�j��O�渹�Υ��N�O�渹)
    ------------------------------------------------------------------------*/

    /*1050107005_C2 �X�w���z�s���W�h�ק�*/
    strcpy(iroute_accept, trim(iroute_accept));
    if (strlen(iroute_accept) == 0) /* ������L�u���z�s���v */
    {
        /* �D �X�w(I006)�A�p�G�����ɵL�u���z�s���v�A�h�X��ɨ��� */
        if (strncmp(iroute,"I006",4 ) != 0)
        {
            /*1050107005_C2 �X�w���z�s���W�h�ק�*/
            /* ��cm_ibank_pqnum()�bInsertPly_Step1x() �����A�|�O�j��B���N�U���@���A��� CA3011_Step12()�BCA305_Step13() ����
               �ç�� cm_ibank_pqnum2() */

            printf("***********Begin ���q�����z�s��***********\n");
            char tmpPqnum[3]= " ";
            char tmpIrouteAccept[21] = " ";


            if (strlen(trim(ply_num2))>0)
            {
                strcpy(tmpPqnum,substring(ply_num2,6,2));
            }
            else
            {
                strcpy(tmpPqnum,substring(ply_num1,6,2));
            }
            printf("-- trace tmpPqnum[%s]\n ",tmpPqnum);

            strcpy(sTmp_date," ");
            if (risnull(CLONGTYPE, &ply2_begin)!=1)
            {
                strcpy(sTmp_date,cm_cdate_str_100(ply2_begin)); /* �@�߶ǥͮĤ� */
            }
            else
            {
                strcpy(sTmp_date,cm_cdate_str_100(ply1_begin));
            }
            
            printf("-- trace sTmp_date[%s]\n ",sTmp_date);
            
            /* 1070108012 -SC2 -���z�s���P�C���ɶǿ�վ�  
               �ǤJ�ѼơG������O(*��)�B�O��r�y�B����q���N���B����B
               �۰���O����O(N.�D�۰���O������I��N�BA.�۰���O��)�B�s��/��O��(N.�s��BR.��O��)*/
            if (strlen(trim(last_ply)) > 2)
                strcpy(sfauto,"R");
            else
                strcpy(sfauto,"N");
            /*printf("1070108012 -SC2 -���z�s���P�C���ɶǿ�վ�--sfauto[%s]\nlast_ply[%s]\n",sfauto,last_ply);*/
            rc = cm_ibank_pqnum2("P1", tmpPqnum, iroute, sTmp_date, "N", sfauto,tmpIrouteAccept);
            
            /* �p�G�ӳq�����ݭn���z�s�� =>  rc = 0 ,tmpIrouteAccept = " " */
            if (rc != 0) 
            {
                return rc;
            }
            strcpy(iroute_accept, tmpIrouteAccept);
            /*printf("-- SUCCESS iroute_accept = %s --\n",iroute_accept);*/
        }
        else
        {
            /* �X�w(I006)�����ɵL�u���z�s���v���ˮ֤]������
               �e�ݷ|��cmn121��5149�z�s�����O�ˮ� "�X��ɬO�_�ݭn���z�s��" */
        }
    }
    printf("****** ���z�s��iroute_accept:[%s]\n",iroute_accept);

    /* ---------------------------------------------------------------------  */


    $WHENEVER SQLERROR GOTO step12_err;  /* resume error handle label */
    code=1;

    printf("***** step12 ***** ply1f[%d] ply2f[%d]\n",ply1f,ply2f);
    printf("***** step12 ***** card1[%s] card2[%s]\n",card1,card2);

    if (ply2f==FALSE) flag_back=1;
    
    
    
    /**********************/
    /*  �j���I�g�J�O����  */
    /**********************/
    
    /*** �X�j���I�����N���p�d�� ***/
    if (ply1f==TRUE && relative_card[0] !='\0' && relative_card[0] !=' ')
    {
        /*** �H���p���N�d���a���p�O�渹 ***/
        $SELECT ipolicy
           INTO $ply_num2
           FROM ply_relation
          WHERE icard = $relative_card;

        if (NOT_FOUND)
        {
            $SELECT ipolicy
               INTO $ply_num2
               FROM assured_vs_ply
              WHERE icard = $relative_card;

            if (NOT_FOUND) return M_CA_NASSURED_VS_PLY;
        }

        printf("{CAR305_step12}:relative_card[%s],ply_num2[%s]\n",relative_card,ply_num2);

        ply2f=TRUE;

        code=InsertPly_Step1x(ply_num1,ply_num2,policy2,policy1,card1,"1", ply2f,M_CA_NCARD1,1,wk_fac_1);

        /*printf("11\n");*/
        strcpy(rel_dbname2, get_car_full_db(ply_num2));

        stmt_buf[0] = '\0';
        sprintf_s(stmt_buf,sizeof stmt_buf,"UPDATE %s:ply_relation "
                                           "   SET irelative_ply = ? "
                                           " WHERE ipolicy = '%s'",
                rel_dbname2 , ply_num2);
        EXEC SQL PREPARE u1_rel FROM  :stmt_buf;
        EXEC SQL EXECUTE u1_rel USING :ply_num1;

        if (sqlca.sqlerrd[2]==0)
        {
            printf("***** update relative_ply 0 record\n");
        }

        if (flag_back==1)
        {
            ply2f=FALSE;
            strcpy(ply_num2," ");
        }
    }
    else if (ply1f==TRUE)
    {
        code=InsertPly_Step1x(ply_num1,ply_num2,policy2,policy1,card1,"1", ply2f,M_CA_NCARD1,1,wk_fac_1);
        printf("22=[%d]\n",code);
    }
    if (code != SUCCESS) return code;


    /**********************/
    /*  ���N�I�g�J�O����  */
    /**********************/

    if (ply2f==TRUE && relative_card[0] !='\0' && relative_card[0] !=' ')
    {
        $SELECT ipolicy
           INTO $ply_num1
           FROM ply_relation
          WHERE icard = $relative_card;

        if (NOT_FOUND)
        {
            $SELECT ipolicy
               INTO $ply_num1
               FROM assured_vs_ply
              WHERE icard = $relative_card;

            if (NOT_FOUND) return M_CA_NASSURED_VS_PLY;
        }

        ply1f=TRUE;

        code=InsertPly_Step1x(ply_num2,ply_num1,policy1,policy2,card2,"2", ply1f,M_CA_NCARD2,2,wk_fac_1);

        rel_dbname2[0] = '\0';
        strcpy(rel_dbname1, get_car_full_db(ply_num1));

        stmt_buf[0] = '\0';
        sprintf_s(stmt_buf,sizeof stmt_buf,"UPDATE %s:ply_relation "
                                           "   SET irelative_ply = ? "
                                           " WHERE ipolicy = '%s'",
                                           rel_dbname1 , ply_num1);
        EXEC SQL PREPARE u1_rel FROM :stmt_buf;
        EXEC SQL EXECUTE u1_rel USING :ply_num2;
    }
    else if (ply2f==TRUE)
    {
        printf("---ply_num2[%s]\n",ply_num2);
        printf("---ply_num1[%s]\n",ply_num1);
        printf("---policy1[%s]\n",policy1);
        printf("---policy2[%s]\n",policy2);
        printf("---card2[%s]\n",card2);
        /*
        printf("---ply1f[%s]\n",ply1f);
        printf("---M_CA_NCARD2[%s]\n",M_CA_NCARD2);
        printf("---wk_fac_1[%s]\n",wk_fac_1);
        */
        code=InsertPly_Step1x(ply_num2,ply_num1,policy1,policy2,card2,"2", ply1f,M_CA_NCARD2,2,wk_fac_1);
        /*printf("44\n");
        printf("END InsertPly_Step1x\n");*/
    }

    if (code != SUCCESS) return code;

    /*1060224008_C2 B2B������ɦ�e�O�����I����*/
    if (strncmp(&estimatei[5],"CR",2) != 0)
    {
        code=UpdateEst(estimatei);
        if (code != SUCCESS) return code;
    }

    return SUCCESS;

step12_err:
    printf("step12_err:sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    code=SQLCODE;
    sprintf_s(v_errMsg,sizeof v_errMsg,"CA3011_Step12()���~:SQLCODE=[%d]sqlca.sqlerrm=[%s],sqlca.sqlerrd[1]=[%d]", SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);     
    $WHENEVER SQLERROR CONTINUE;
    return code;
}

static int InsertPly_Step1x(plyn_1,plyn_2,pp2,pp1,card,fc,plyf,err_msg,
                            type,fac)
$char *plyn_1, *plyn_2, *pp2, *pp1, *card, *fc, fac;
int plyf, err_msg, type;
{
    $date   ply_begin, ply_end;
    $int    ply_period, rtncode;
    $char   fagent[2], treaty1[2], dexamine[12];
    $long   l_dexamine;
    int     code;
    $char   stmt_buf[4000];
    char    dbsite4[3], FullDBName4[20];
    $char   tmp_user[19],tmp_benefi[11],tmp_benefn[43],tmp_ply[POLICY_NUM_1];
    $int    int_yy,int_mm,ibatch_no,no_null;
    char    tmp_yy[3],tmp_mm[3];

    $double plia_acc, tmp_pdmg_acc, tmp_psex_age_damage;
    $char   tmp_last_card[CARD_NUM];
    $char   cartype_tmp[6], iroute4[5];
    $long   tmp_mdiscount;
    $double tmp_pdiscount;
    $long   tmp_mservice;
    long    test_prem=0, iRtnCode;
    int     flag_dmg=0;
    int     flag_lia=0;
    long    tmp_mlia_commi=0, tmp_mdmg_commi=0;
    long    tmp_mlia_agent=0, tmp_mdmg_agent=0;
    long    tmp_mlia_disco=0, tmp_mdmg_disco=0;
    long    tmp_mlia_prem=0, tmp_mdmg_prem=0;
    $char   tmp_equipment[31],  tmp_survey_num[21], tmp_bound_num[21];
    $int    i_rtn;
    /* GCAR�������[���ڷs�W���     */
    $int    irate;
    $double adjust_rate;
    $double mins_premium_n;
    $double mpure_prem_n;
    $long   mprem_n;
    /* 'car9610231��~�βĤT�H�f�B�~���[���� */
    $double safe_rate;
    $double manage_rate;
    $double educated_rate;
    /* �«O�O�����v */
    $double deviation_rate;
    $double pextra_charge;/* ���[�O�βv */
    $double pbusiness;     /* �~�޶O�βv */
    $double psex_age;
    $double pshipping;    /* car9808043 �f�B�~���[����C */
    $char   sViins_type[INSURANCE_TYPE];
    $int    sum_premv;
    $char   sTmpPolicy1[POLICY_NUM_1], sTmpPolicy2[POLICY_NUM_1];
    int     ins56_flag,ins136_flag,ins47_flag,ins50_flag,ins166_flag,ins266_flag;
    $double pcar_price;
    $char   feply_1[2]  = "0";
    $char   aemail_eply_1[51]  = " ";
    $char   tmobile_eply_1[21]  = " ";/*1080417001-SC1-���ά�-�s�W�q�l�O��H²�T�覡�o�e */
    $char   tmp_car_type[3],tmp_cardyear[3],tmp_char[2],tmp_char_out[2];
    $char   tmp_feterms[2]; /* 1100419003-���I�O�����QR Code�q�l��-�ȥ��O��u�q�l���ڡv   �j���I�@�߬�0 */
    struct PLY_RULE_OP *RUL_OP;
    memset(&RUL_OP,0, sizeof(RUL_OP));
    RUL_OP=(struct PLY_RULE_OP *)malloc(sizeof(struct PLY_RULE_OP));

    /* �������d���l�H�αj�����T�d�߫Y�� */
    $char tmp_dmg[17],tmp_lia[17];
    $char sTmpQprovD[2];
    $int tmp_lia_acc_sum, tmp_dmg_acc_sum;
    $char sIinkind[2],sIinkind_ply[3];

    /* �s�r�B���j�H�W���� */
    $int Qdrunk_c, Qdrunk_v, Qviolate_c, Qviolate_v;
    $long Qdrunk_prem, Qviolate_prem;
    $double Qdrunk_pure_prem, Qviolate_pure_prem;
    
    $double tmp_punknown_acc;
    $int    tmp_qunknown_acc_sum;
    $char   tmp_iquery_num_unknown[17]=" ";

    $char autoply_buf[1024]; /* 1060817004-C1 �q�lñ�p */
    $char sFtype[2],fs_type[2]; /* 1071105008-SC1-�����-�������Ȩ��z��(FS)���z�s�����s�X�W�h */
    
    /* 1090731009-SC1-���ά�-�ӤH���I�جd�֯ʥ��ﵽ���I*/
    $int iPlyCnt;
    $char sply_begin[11],sply_end[11];
    $char sProvDelimiter[22];    /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X  �����ɤW��������*/
    POLICY_INFO stCmPlyInfo;

    $WHENEVER SQLERROR GOTO ip_step1x_err;

    /* �w���U�@����_�Ǫ��O�渹..... */ 
    if (strlen(rtrim(plyn_1))<10)
    {
        sprintf_s(v_errMsg,sizeof v_errMsg, "������������O�渹(%s)�ɵo�Ͳ��`�A�Э���",plyn_1);
        return M_CM_ORDINARY_CHECK;
    }
    strcpy(tmp_feterms,"0");  /*   1100419003-���I�O�����QR Code�q�l��-�ȥ��O��u�q�l���ڡv */             
    /*printf("step1x**** into insertply_step1x, mlia_commi_1[%d]\n",mlia_commi_1);
    printf("step1x**** into insertply_step1x, type[%d]\n",type);
    printf("TTTTT  -----   > INTO step1x equipment[%s]\n",equipment);*/
    strcpy(GetPlyInsMain, " ");

    Qdrunk_c = Qdrunk_v = Qviolate_c = Qviolate_v= 0;
    Qdrunk_prem = Qviolate_prem = 0;
    Qdrunk_pure_prem = Qviolate_pure_prem = 0;
    ins56_flag = ins136_flag = ins166_flag = ins266_flag = 0;

    if (plyf==FALSE)
    {
        if (!IsBlankNull(pp2))
        {
            strcpy(irelative_ply, pp2);

            /*-----update relative_ply-----*/
            strcpy(FullDBName4, get_car_full_db(irelative_ply));

            if (FullDBName4[0]=='\0') return M_CM_DB_NOTOPEN;

            /*printf("step1x**** before update ply_relation, rel:DB[%s]\n",FullDBName4);*/

            sprintf_s(stmt_buf,sizeof stmt_buf,"UPDATE %s:%s %s",
                                               FullDBName4,"ply_relation",
                                               "SET irelative_ply=? WHERE ipolicy=?");
            $PREPARE x7 FROM $stmt_buf;
            $EXECUTE x7 USING $plyn_1,$pp2;
            if (sqlca.sqlerrd[2]==0) return M_CA_NREL_PLY;
            /*-----------------------------*/
        }
        else
            strcpy(irelative_ply,"");
    }
    else
    {
        strcpy(irelative_ply,plyn_2);
    }

    /*printf("step1x*** before insert ply_relation, mlia_commi_1[%d]\n",mlia_commi_1);*/

    if (strncmp(&estimatei[5],"CR",2) == 0)
    {
        if (strcmp(icont,"4") == 0)
        {
            $SELECT first 1 dupdate::date
               INTO $l_dexamine
               FROM policy_302
              WHERE iestimate_ori=$estimatei;
        }
        else
        {
            $SELECT first 1 dupdate::date
               INTO $l_dexamine
               FROM policy_302
              WHERE iestimate_sug=$estimatei;
        }
    }
    else
    {    
        $SELECT dexamine
           INTO $l_dexamine
           FROM estimate
          WHERE iestimate=$estimatei;
    }  
    
    strcpy(dexamine,cm_edate_str(l_dexamine));
    strcpy(destimate, dexamine);
    /*printf("---- 20349 iquery_num_c=[%s] --------------\n",iquery_num_c);*/
    if (big_branch[0]=='\0') strcpy(big_branch," ");
    if (big_office[0]=='\0') strcpy(big_office," ");
    if (big_sales[0]=='\0') strcpy(big_sales," ");
    if (iinstall[0]=='\0') strcpy(iinstall," ");
    if (iquery_num[0]=='\0') strcpy(iquery_num," ");
    if (iquery_num_c[0]=='\0') strcpy(iquery_num_c," ");

    /*-----insert ply_relation-----*/

    printf("pp1[%s]\n",pp1);

    if (!IsBlankNull(pp1))
    {
        strcpy(FullDBName4, get_car_full_db(pp1));

        if (FullDBName4[0]=='\0') return M_CM_DB_NOTOPEN;

        /*printf("========before insert ply_relation, DB[%s]\n",FullDBName4);*/

        sprintf_s(stmt_buf,sizeof stmt_buf,"SELECT icard FROM %s:ply_relation WHERE ipolicy=?",
                                           FullDBName4);
        $PREPARE CUR_PP1 FROM $stmt_buf;
        $DECLARE a_cur_pp1 CURSOR FOR CUR_PP1;
        $OPEN a_cur_pp1 USING $pp1;
        $FETCH a_cur_pp1 INTO $tmp_last_card;
        $CLOSE a_cur_pp1;
        $FREE a_cur_pp1;
    }
    else
        tmp_last_card[0]='\0';

    printf("========before insert ply_relation, last_card[%s]\n",tmp_last_card);
    printf("========before insert ply_relation, policy[%s],card[%s]\n",plyn_1,card);
    strcpy(sTmpQprovD, qprovision);

    strcpy(feply_1, feply );        /* 1050707003_C1 ���I�s�W�q�l�O��@�~ */
    strcpy(tmp_feterms,feterms);    /*1100419003-���I�O�����QR Code�q�l��-�ȥ��O��u�q�l���ڡv*/
    
    if (type==1)  /*** �j���I ***/
    {
        ply_period=ply1_period;
        ply_begin=ply1_begin;
        ply_end=ply1_end;
        strcpy(officer, officer1);
        strcpy(sIquota, sIquota1);
        strcpy(sIleader, sIleader1);
        strcpy(ibig_comp,ibig_comp1);
        strcpy(ibranch,ibranch1);
        strcpy(broker,broker1);
        strcpy(car_typei,car_typei1);
        strcpy(treaty1,"6");
        strcpy(icar_flag,icar_flag1);

        /* �t�X�q���ĤG���q�s�W */
        strcpy(irate_type, irate_type1);
        strcpy(bzfrom, bzfrom1);
        strcpy(iroute_comm,iroute_comm1);
        strcpy(icomm_obj,icomm_obj1);
        strcpy(qprovision, "0");		/* ���w�r�p�H�� */
        Qdrunk_c = qdrunk_driving;		/* �s�r���� */
        Qviolate_c = qviolate;		        /* ���j�H�W���� */
         
        /* 1070125001_SC5_�j��T���d���I�q�l���O�I�һ{�ҥ��x�Χ�O�t�ζ}�o */
        /* 1070125001_SC8_�j��T���d���I�q�l���O�I�һ{�ҥ��x�Χ�O�t�ζ}�o */
        strcpy(feply_1,fecard);
        if (feply_1[0]=='1')
        {
            if (fout_print[0]=='1')
            {
                strcpy(fout_print,"0");
                strcpy(fmail_type,"0");
            }

        }
        /* �j��q�l���ұH�o�@�~�X�j-���q��(1101206002_SC1) */
        strcpy(aemail_eply_1, aemail_eply );
        strcpy(tmobile_eply_1, tmobile_eply );   /*1080417001-SC1-���ά�-�s�W�q�l�O��H²�T�覡�o�e*/
        strcpy(tmp_feterms,"0");/*   1100419003-���I�O�����QR Code�q�l��-�ȥ��O��u�q�l���ڡv */             
    }
    else          /*** ���N�I ***/
    {
        ply_period=ply2_period;
        ply_begin=ply2_begin;
        ply_end=ply2_end;
        strcpy(officer, officer2);
        strcpy(sIquota, sIquota2);
        strcpy(sIleader, sIleader2);
        strcpy(ibig_comp,ibig_comp2);
        strcpy(ibranch,ibranch2);
        strcpy(broker,broker2);
        strcpy(car_typei,car_typei2);
        strcpy(treaty1,"1");
        strcpy(icar_flag,icar_flag2);

        /* �t�X�q���ĤG���q�s�W */
        strcpy(irate_type, irate_type2);
        strcpy(bzfrom, bzfrom2);
        strcpy(iroute_comm,iroute_comm2);
        strcpy(icomm_obj,icomm_obj2);
        strcpy(qprovision,sTmpQprovD);		/* ���w�r�p�H�� */

        Qdrunk_v = 0;			        /* �s�r���� */
        Qdrunk_prem = 0;		        /* �s�r�O�O */
        Qdrunk_pure_prem = 0.0;		        /* �s�r�«O�O */
        Qviolate_v = 0;			        /* ���j�H�W���� */
        Qviolate_prem = 0;		        /* ���j�H�W�O�O */
        Qviolate_pure_prem = 0.0;		/* ���j�H�W�«O�O */

        /* �P�ɦ��q�l�O��+�e�~���O => �q�l�O�� */
        if (feply[0]=='1')
        {
            if (fout_print[0]=='1')
            {
                strcpy(fout_print,"0");
                strcpy(fmail_type,"0");
            }
            
            strcpy(tmp_feterms,"0");/*   1100419003-���I�O�����QR Code�q�l��-�ȥ��O��u�q�l���ڡv �ȥ��O��~�|�f�t�q�l����*/             
        }
        strcpy(aemail_eply_1, aemail_eply );
        strcpy(tmobile_eply_1, tmobile_eply );/*1080417001-SC1-���ά�-�s�W�q�l�O��H²�T�覡�o�e*/

    }

    /*printf("========before insert ply_relation, ply_period[%d]\n",ply_period);*/
    printf("########Fcard_class[%s] , icar_flag[%s]\n",fc,icar_flag);

    /* --------------------------------------------------------------------  */

    /*  ���qB2B�����I update �T��O�渹 �`�N�j��(ipolicy2)���N(ipolicy)�O�渹�X��� �P���e���P */
    if (strncmp(itmp_policy,"YJ",2) == 0)
    {
        if (fc[0] == '1')
        {
            $UPDATE ot_estimate
                SET ipolicy2 = $plyn_1
              WHERE iestimate = $itmp_policy;
        }
        else
        {
            $UPDATE ot_estimate
                SET ipolicy = $plyn_1
              WHERE iestimate = $itmp_policy;
        }
    }

    /* ���ȥ�X��ɡA�^���j��O�渹�Υ��N�O�渹����Ȩ��z��ƶפJ�� add by larry 103.01.21 (1020307002_C6) */
    if (strncmp(iroute,"I009",4) == 0 )
    {
        if (strncmp(iroute_accept,"CARP17",6) == 0)
        {
            if (fc[0] == '1')
            {
                $UPDATE ca_apply_inward
                    SET ipolicy1 = $plyn_1
                  WHERE iroute_accept = $iroute_accept;
            }
            else
            {
                $UPDATE ca_apply_inward
                    SET ipolicy2 = $plyn_1
                  WHERE iroute_accept = $iroute_accept;
            }
        }

    }


    /* car9602122
    �Q�O�I�H�����Y���~(cu_company_dtl.irel_group='01')�B�ӥB�~�Ȩӷ���3:�@����u�B9:���u�A
    �~�Ȩӷ��אּ�@��8:���Y���~ */
    rtncode = change_iresource( assuredi, resource, v_sMsg);
    if( rtncode != M_CM_OK)
        return rtncode;

    /* ���j���� ------------------------------------------------------------- */
    strcpy(isecond_hand, trim(isecond_hand));
    if (strlen(isecond_hand) <= 2)	strcpy(isecond_hand, " ");
    /* A�����p�d�� ---------------------------------------------------------- */
    strcpy(icard_main, trim(icard_main));
    if (strlen(icard_main) <= 3) strcpy(icard_main, " ");
    /* --------------------------------------------------------------------- */
    printf("--AAAAAAAA fout_print[%s]fecard[%s]tmp_feterms[%s]feterms[%s]\n",fout_print,fecard,tmp_feterms,feterms);

    $char  tmp_office[2],tmp_office1[2],tmp_char_car[2];
    $char  dissue_card[11],card_Msg[256];
    strcpy(dissue_card, cm_edate_str(cm_today( )));
    
    if (fc[0] == '1')
    {
        /* 1070125001_SC8_�j��T���d���I�q�l���O�I�һ{�ҥ��x�Χ�O�t�ζ}�o */
        /* 1070125001_SCB_�j��T���d���I�q�l���O�I�һ{�ҥ��x�Χ�O�t�ζ}�o */
        /* �u�e�~�C�L�v��A��u�j���Ҹ��v�Y�Ѩt�Φ۰ʵ��� */
        
        /* CBUG_2019_1080611  �ץ����d�W�h - �����W�[�P�_�g��Ψt�λ�ΡA�קK�d�ҳQ�O���g��ϥ�*/
        /* �վ���P�_�Ӹg�즳�L���X���d(���u���R��)�A�B���t�λ�d */
        if (fout_print[0]=='1' && fecard[0] == '0')
        {
            /* ���o�e�~�u�j���Ҹ��v*/	
            if( (strncmp(car_typei, "01", 2) ==0) ||
                (strncmp(car_typei, "02", 2) ==0) ||
                (strncmp(car_typei, "32", 2) ==0) ||
                (strncmp(car_typei, "34", 2) ==0) ||
                (strncmp(car_typei, "35", 2) ==0) )
            {
                strcpy(tmp_car_type,"01");
                strcpy(tmp_char,"M");
                strcpy(tmp_char_out,"M");
            }
            else
            {
                strcpy(tmp_car_type,"03");
                strcpy(tmp_char,"C");
                strcpy(tmp_char_out,"Z");
            }
             
             /* ���S�����Χ����Ҹ� */ 
            strcpy(tmp_cardyear," "); strcpy(card1," ");
            $SELECT first 1 substr(cast((year(today)-1911) AS char(3)),2,2) 
               INTO $tmp_cardyear
               FROM systables WHERE 1=1;
            strcpy(tmp_cardyear,trim(tmp_cardyear));
             
            sprintf_s(stmt_buf,sizeof stmt_buf,
                    " SELECT nvl(min(icard),'') FROM compulsory_card "
                    "  WHERE icard[1,4] = '%s%s7' "
                    "    AND ioffice   = '7'  "
                    "    AND icardyear = '%s' "
                    "    AND icar_type = '%s' "
                    "    AND iofficer  = '%s' "
                    "    AND ireceive  = 'system' AND dissue BETWEEN today-30 AND today "
                    "    AND fstatus   = '0'", tmp_cardyear, tmp_char, tmp_cardyear, tmp_car_type, officer1);
            $PREPARE pre_getOutCard1 FROM $stmt_buf;             
            $EXECUTE pre_getOutCard1 INTO $card1;
            if (strlen(trim(card1))<3)
            {
                /* 1070125001_SC8_�j��T���d���I�q�l���O�I�һ{�ҥ��x�Χ�O�t�ζ}�o */
                rc = get_ca_compcard(officer1,"7",sIquota,tmp_char_out,tmp_car_type,tmp_cardyear,dissue_card,ply1_period,sIbranchIcomp,card_Msg);
                if( rc != M_CM_OK)
                {
                    strcpy(v_errMsg,"�u�j��q�l���ҡv��������~�A�t�εL�k���o�i�Τ��u�j���Ҹ��v�A�Ь��ӫO��");
                    return M_CM_ORDINARY_CHECK;
                }
                 
                sprintf_s(stmt_buf,sizeof stmt_buf,
                    " SELECT nvl(min(icard),'') FROM compulsory_card "
                    "  WHERE icard[1,4] = '%s%s7' "
                    "    AND ioffice   = '7'  "
                    "    AND icardyear = '%s' "
                    "    AND icar_type = '%s' "
                    "    AND iofficer  = '%s'"
                    "    AND ireceive  = 'system' AND dissue BETWEEN today-30 AND today "
                    "    AND fstatus   = '0'", tmp_cardyear, tmp_char, tmp_cardyear, tmp_car_type, officer1);
                $PREPARE pre_getOutCard2 FROM $stmt_buf;             
                $EXECUTE pre_getOutCard2 INTO $card1;

                if (strlen(trim(card1))<3)
                {
                    /*printf("---stmt_buf[%s]\n",stmt_buf);*/
                    strcpy(v_errMsg,"�u�e�~�C�L�v��A�t�εL�k���o�i�Τ��u�j���Ҹ��v�A�Ь��ӫO��");		         	 			         
                    return M_CM_ORDINARY_CHECK; 
                }
            }
        }
        else if (fecard[0]=='1')
        {
            /*1070125001_SC5_�j��T���d���I�q�l���O�I�һ{�ҥ��x�Χ�O�t�ζ}�o*/
            if ((strcmp(car_typei1, "01") == 0) ||
                (strcmp(car_typei1, "02") == 0) ||
                (strcmp(car_typei1, "32") == 0) ||
                (strcmp(car_typei1, "34") == 0) ||
                (strcmp(car_typei1, "35") == 0))
            {
                strcpy(tmp_car_type,"01");
                strcpy(tmp_char,"M");
            }
            else
            {
                strcpy(tmp_car_type,"03");
                strcpy(tmp_char,"C");
            }
            /*1100205005-SC1-���ά�-�ק���sCAR301�j���I�۰ʨ�������  �e�~����    �ް��¥d��iofficer �ç�s�d��*/ 
            strcpy(tmp_cardyear," "); strcpy(card1," ");
            $SELECT first 1 substr(cast((year(today)-1911) AS char(3)),2,2) 
               INTO $tmp_cardyear
               FROM systables WHERE 1=1;
               
            strcpy(tmp_cardyear,trim(tmp_cardyear));
            
            sprintf_s(stmt_buf,sizeof stmt_buf,
                 " SELECT nvl(min(icard),'') FROM compulsory_card "
                 "  WHERE icard[3,4] = '%s8' "
                 "    AND ioffice   = '8'  "
                 "    AND icardyear = '%s' "
                 "    AND icar_type = '%s' "
                 "    AND ireceive  = 'system' AND dissue BETWEEN today-30 AND today "
                 "    AND fstatus   = '0' AND ipolicy = '' AND iquota= '%s' ", tmp_char, tmp_cardyear, tmp_car_type, sIquota1);
                 
            $WHENEVER SQLERROR CONTINUE; 
            $PREPARE pre_getOutCard1 FROM $stmt_buf;             
            $EXECUTE pre_getOutCard1 INTO $card1;
            
            if(SQLCODE == -245)
            {
            	usleep(500000); /*0.5��*/
            	$WHENEVER SQLERROR GOTO ip_step1x_err;
                $PREPARE pre_getOutCard1_1 FROM $stmt_buf;        /*�Atry�@��*/     
                $EXECUTE pre_getOutCard1_1 INTO $card1;	
                $WHENEVER SQLERROR CONTINUE;
            }
            
            /*$WHENEVER SQLERROR GOTO ip_step1x_err;*/
            
            if (strlen(trim(card1))>=3)
            {
                $UPDATE compulsory_card
                    SET iissue_branch=$sTmpIbranch,
                        iquota = $sIquota1,
                        iissue_comp = (SELECT iupcomp from branch where ibranch = $sTmpIbranch) ,
                        iofficer = $officer1  ,
                        ialter = $userid  ,
                        dalter = today
                  WHERE icard = $card1
                    AND ioffice   = '8'
                    AND icardyear = $tmp_cardyear
                    AND icar_type = $tmp_car_type
                    AND ireceive  = 'system' 
                    AND fstatus   = '0';
                
                /*printf("---stmt_buf[%s] card1[%s]\n",stmt_buf);*/
                if (sqlca.sqlerrd[2]==0 || SQLCODE == -245) 
                {
                    printf("�ק��¥d����s�d��FAILLLLL\n"); 	
                    strcpy(card1,"");
                }           	
            	
            }

            
            
            if (strlen(trim(card1))<3)
            {
                rc = get_ca_compcard(officer1,"8",sIquota,tmp_char,tmp_car_type,tmp_cardyear,dissue_card,ply1_period,sIbranchIcomp,card_Msg);
                if( rc != M_CM_OK)
                {
                    /*�Atry�@��*/
                    rc = get_ca_compcard(officer1,"8",sIquota,tmp_char,tmp_car_type,tmp_cardyear,dissue_card,ply1_period,sIbranchIcomp,card_Msg);
                    if( rc != M_CM_OK)
                    {
                        strcpy(v_errMsg,"�u�j��q�l���ҡv��������~�A�t�εL�k���o�i�Τ��u�j���Ҹ��v�A�Ь��ӫO��");
                        return M_CM_ORDINARY_CHECK;                    	
                    }

                }
                
                sprintf_s(stmt_buf,sizeof stmt_buf,
                     " SELECT nvl(min(icard),'') FROM compulsory_card "
                     "  WHERE icard[1,4] = '%s%s8' "
                     "    AND ioffice   = '8'  "
                     "    AND icardyear = '%s' "
                     "    AND icar_type = '%s' "
                     "    AND iofficer  = '%s' "
                     "    AND ireceive  = 'system' AND dissue BETWEEN today-30 AND today "
                     "    AND fstatus   = '0' AND ipolicy = '' AND iquota= '%s' ", tmp_cardyear, tmp_char, tmp_cardyear, tmp_car_type, officer1, sIquota1);
                $PREPARE pre_getOutCard1 FROM $stmt_buf;             
                $EXECUTE pre_getOutCard1 INTO $card1;
                /*printf("--ecard-stmt_buf[%s] card1[%s]\n",stmt_buf,card1);*/
                
                if (SQLCODE == -245)
		{
		    usleep(500000); /*0.5��*/
		    $WHENEVER SQLERROR GOTO ip_step1x_err;
		    $PREPARE pre_getOutCard1_1 FROM $stmt_buf;      /*�Atry�@��*/       
                    $EXECUTE pre_getOutCard1_1 INTO $card1;
                    
		}
                $WHENEVER SQLERROR GOTO ip_step1x_err;
                
                if (strlen(trim(card1))<3)
                {
                    strcpy(v_errMsg,"�u�j��q�l���ҡv��A�t�εL�k���o�i�Τ��u�j���Ҹ��v�A�Ь��ӫO��");		         	 			         
                    return M_CM_ORDINARY_CHECK;
                }
            }
            printf("-- trace �j��q�l���� card1[%s]\n ",card1);
            $WHENEVER SQLERROR GOTO ip_step1x_err;
        }
        else
        {
            strcpy(card  ,trim(plyn_1)); 
            strcpy(card1 ,card);				    
        }
        printf("-- trace card[%s]\n ",card);
        printf("-- trace card1[%s]\n ",card1);    	 	    
    }
    
    /*1090831006-SC1-���ʱo-�{�ҥ��x�j��q�l���ҥ���g�����mail�ˮ� 
                           �n�O�H�P�ɵL��ʹq�ܻPemail�B�ݩ�q�l���ҿﶵ�L�H�o²�T����ʹq�ܻP�H�o��email�� 
        i.	�p�G�O�쥻�w�������渹�B�L�e�z�p����T�ɡA���������渹�ɡA���u�έ������ҰO�������O���ɶ��C
        ii.	�p�G���O�����������s�W�ɡA�h�H�s�W�����椧�ɶ��C
        iii.	�p�G���W�z�p����T���@�榳��ƮɡA���O���i�j��q�l�O��-�T�{�L�k���Ѥ��email�j���ťաC
                            */
    strcpy(sDnotifyornot," ");
    if ((strlen(trim(officer1)) >0) && (fc[0]=='1'))
    {
       
        $select nvl(dnotifyornot ,CURRENT) 
           into $sDnotifyornot 
           from estimate 
          where iestimate = $itmp_policy;
        /*printf("1090831006-itmp_policy[%s]\n",itmp_policy);*/
        if( SQLCODE == SQLNOTFOUND)
        {
            /* CR */
            $select current year to fraction(3) 
               into $sDnotifyornot
               from officer
              where iofficer = $examiner;
            /*printf("1090831006-CR\n");*/
        }
        
        /*  �n�O�H������X�B�n�O�Hemail �q�l�O��H�e��email �q�l�O��H�etmobile_eply*/
        /*
        printf("tmobile_appl[%s]\n",tmobile_appl);
        printf("aemail_appl[%s]\n",aemail_appl);
        printf("aemail_eply_1[%s]\n",aemail_eply_1);
        printf("tmobile_eply_1[%s]\n",tmobile_eply_1);
        */
        if ((strlen(trim(tmobile_appl))==0) && (strlen(trim(aemail_appl))==0)&&(strlen(trim(aemail_eply_1))==0) && (strlen(trim(tmobile_eply_1))==0))  
        {
            printf("sDnotifyornot[%s]\n",sDnotifyornot);
        }
        else
        {
            printf("�p����T���@�榳���\n");
            strcpy(sDnotifyornot," ");
        }
    }


    /* 1091215005-SC1-���ά�-���F�P�_�O���ӷ�, �n�s�W�x�s����{���N�X����� iprog*/
    /* �s�W�ĤT��ǿ���O��� (1110303014_SC1) */
    $INSERT INTO ply_relation
           (ipolicy,icard,fcard_class,irelative_ply,ilast_ply,ilast_card,
            iofficer, iquota, ileader, ibroker, icorps,
            iarea, icashier, iexaminer,dexamine,ientry,dentry,
            fprint,iresource,ibig_comp,ibig_branch,ibig_office,
            ibig_sales,
            qply_period,dply_begin,dply_end,ipro_year,ibrand,
            icar_type,itreaty,
            ibranch,fcomp_class,fcomp_class_last,
            mbusiness,mbus_rule,mresearch,mcapital,minvest,
            mready,mstable,mcompensation,madjcom_prem,maintain,
            icomp_in, ibranch_in, icomp_at, ibranch_at, dapply,ipay_way,
            itmp_policy, icar_flag, transno,iinstall,
            iofficer_prmt, iquota_prmt, ileader_prmt,
            irate_type, bzfrom, iroute_comm, icomm_obj, qprovision, isecond_hand,
            icard_main, qdrunk_driving, fout_print, fmail_type,isign,feply, feterms, aemail_eply,tmobile_eply,
            iscan_no,ireg_no,dnotifyornot,fsign_status,funder_chk,iprog,ftrans_third,qviolate)
     VALUES
           ($plyn_1, $card, $fc, $irelative_ply, $pp1, $tmp_last_card,
            $officer, $sIquota, $sIleader, $broker, $sIcorps,
            $localdb, $officer, $examiner, $dexamine, $entry, $Today,
            "0",$resource,$ibig_comp,$big_branch,$big_office,
            $big_sales,
            $ply_period,$ply_begin,$ply_end, $pro_year,$brandi,
            $car_typei,$treaty1,
            $ibranch,'0','0',
            0,0,0,0,0,0,0,0,0,0,
            $sIcomp_in, $sIbranch_in, $sIcomp_at, $sIbranch_at,$lDapply,
            $ipay_way,$itmp_policy, $icar_flag, $sTransNo,$iinstall,
            $iofficer_prmt, $iquota_prmt, $ileader_prmt,
            $irate_type, $bzfrom, $iroute_comm, $icomm_obj, $qprovision, $isecond_hand,
            $icard_main, $qdrunk_driving,$fout_print, $fmail_type,$isign,$feply_1,$tmp_feterms,$aemail_eply_1,$tmobile_eply_1,
            $sIscan_no,$sIreg_no,$sDnotifyornot,40,"N",'car3011','N',$qviolate);
    
    /* ����~�Z���W�� */
    strcpy(sNquota," ");

    $SELECT nbranch
       INTO $sNquota
       FROM sa_branch_type
      WHERE ibranch = $sIquota;

    /*printf("�T���q��I0�}�Y,���i��������15.07,�Ь���o��iroute[%s],car_typei[%s]\n",iroute,car_typei);*/
    
    /* 1070612006-SC4-��ã��-���sCAR301�s�W���ܰT���q��I0�}�Y,���i��������15.07,�Ь���o�� */
    if ( (strncmp(iroute,"I0",2) == 0 ) && ((strncmp(car_typei, "15", 2) ==0) ||  (strncmp(car_typei, "07", 2) ==0)))
    {
        strcpy(v_errMsg , " �q��I0�}�Y,���i��������15.07,�Ь���o��; ");
        Update_car3011_temp(itmp_policy, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply_1, v_errMsg);
    }
    
    if (!IsBlankNull(pp1))
    {
        strcpy(FullDBName4, get_car_full_db(pp1));

        if (FullDBName4[0]=='\0')
            return M_CM_DB_NOTOPEN;

        printf("**** update ply_relation==>inext_ply, rel:DB[%s]\n",FullDBName4);

        stmt_buf[0] = '\0';
        sprintf_s(stmt_buf,sizeof stmt_buf,"UPDATE %s:%s %s",
                                           FullDBName4,"ply_relation",
                                           "SET inext_ply=? WHERE ipolicy=?");
        $PREPARE next_ply_cur1 FROM  $stmt_buf;
        $EXECUTE next_ply_cur1 USING $plyn_1,$pp1;
        if (sqlca.sqlerrd[2]==0)	    
        {
            sprintf_s(v_errMsg,sizeof v_errMsg,"�����渹(%s)��O�渹(%s)��^����O�渹�ɵo�Ͳ��`�A�Э���",itmp_policy,pp1);
            return M_CM_ORDINARY_CHECK;
        }
    }
    printf("insert ply_relation complete\n");
    strcpy(qprovision,sTmpQprovD);/* �٭���w�r�p�H�� */
    if (type==1)
    {   
    	/*ply1f==TRUE */
        printf("=================== before update ply_relation\n");
        /* �j���I,A�����p�d���d��  add by sylvia 102.12.19 (1021122001_C1) */
        $UPDATE ply_relation
           SET (mdmg_agent,mdmg_commi,mdmg_discount,mdmg_prem,mdmg_pure_prem,
                mlia_agent,mlia_commi,mlia_discount,mlia_prem,mlia_pure_prem,
                fdiscount,fcomp_class,fcomp_class_last,
                mbusiness,mbus_rule,mresearch,mcapital,minvest,
                mready,mstable,mcompensation,madjcom_prem,dpolicy,maintain,
                icard_main, qdrunk_driving,icomp_cartype_last,ftrans_trade,qviolate)
             = (0,0,0,0,0,
                $mlia_agent_1,$mlia_commi_1,0,$premium1,$madjcom_prem,
                'N',$comp_class,$comp_class_last,
                $mbusiness,$mbus_rule,$mresearch,$mcapital,$minvest,
                $mready,$mstable,$mcompensation,$madjcom_prem,$Today,$maintain,
                ' ',$Qdrunk_c,$icomp_cartype_last,$ftrans_trade,$Qviolate_c)
         WHERE ipolicy=$plyn_1;

        tmp_mlia_commi=mlia_commi_1;
        tmp_mlia_agent=mlia_agent_1;
        tmp_mlia_disco=0;
        tmp_mdmg_disco=0;
        tmp_mdmg_prem = 0;
        tmp_mlia_prem = premium1;
        strcpy(plyn_1,trim(plyn_1));
        if (strcmp(trim(card),plyn_1)==0)
        {
            /* 1040828003_C1 �j���Iñ��ΦL�Һ޲z */
            /* �L�Үɤ~�^�� */
        }
        else
        {   
            /*(isalpha(card1[0]))*/
            $SELECT fstatus INTO $fstatus
               FROM compulsory_card WHERE icard=$card1;
            if (NOT_FOUND)  return err_msg;

            if (*fstatus=='1') return M_CA_PLY1_EXIST; /* 103.08.29 fix*/

            if (*fstatus=='0' || *fstatus=='5' || *fstatus=='6') *fstatus='1';

            printf("=================== before update compulsory_card\n");

            $UPDATE compulsory_card
                SET (fstatus,ialter,dalter,ipolicy)
                  = ($fstatus,$entry,$Today,$plyn_1)
              WHERE icard=$card1;
            
            if (sqlca.sqlerrd[2]==0) return M_CA_NOT_CARD;
        }


        /* �I����H��10000,������ add by sylvia 100.06.22 */
        if((strcmp(trim(icomm_obj),"10000") == 0)  && (mlia_commi_1 > 0)) /* �I����H10000,�����I���~�� */
        {
            return M_CA_CANT_HAVE_COMMI1;
        }

    }
    else
    {   
    	/* ply2f==TRUE */
        if (mdmg_prem<0 || mlia_prem<0)
        {
            return M_CA_PREM_NEGATIVE;
        }
        /*
        printf("step1x:before update ply_relation mdmg_prem[%d]\n",mdmg_prem);
        printf("step1x:before update ply_relation mdiscount[%d] \n",mdiscount);
        */
        $UPDATE ply_relation
            SET (fdiscount,
                mdmg_agent,mdmg_commi,mdmg_discount,mdmg_prem,mdmg_pure_prem,
                mlia_agent,mlia_commi,mlia_discount,mlia_prem,mlia_pure_prem, qprovision,
                qdrunk_driving,qviolate)
              = ($fdiscount,
                $mdmg_agent_2,$mdmg_commi_2,$mdmg_disco_2,$mdmg_prem,$mdmg_pure_prem,
                $mlia_agent_2,$mlia_commi_2,$mlia_disco_2,$mlia_prem,$mlia_pure_prem, $qprovision,
                $Qdrunk_v,$Qviolate_v)
         WHERE ipolicy=$plyn_1;
        puts("jack 1");
        tmp_mlia_agent=mlia_agent_2;
        tmp_mlia_commi=mlia_commi_2;
        tmp_mlia_disco=mlia_disco_2;
        tmp_mdmg_agent=mdmg_agent_2;
        tmp_mdmg_commi=mdmg_commi_2;
        tmp_mdmg_disco=mdmg_disco_2;
        tmp_mlia_prem=mlia_prem;
        tmp_mdmg_prem=mdmg_prem;

        if (isalpha(card2[2])) /*�O�N��*/
        {
            if (!IsBlankNull(card2))
            {
                sprintf_s(stmt_buf,sizeof stmt_buf,"SELECT fstatus FROM %s:card "
                                                   " WHERE icard=?",dbname_tp);
                $PREPARE card_2 FROM $stmt_buf;
                $DECLARE card_cur2 CURSOR FOR card_2;
                $OPEN card_cur2 USING $card2;
                $FETCH card_cur2 INTO $fstatus;
                if (NOT_FOUND)
                {
                    $CLOSE card_cur2;
                    $FREE card_cur2;
                    return err_msg;
                }
                $CLOSE card_cur2;
                $FREE card_cur2;
                
                if (*fstatus=='1') return M_CA_PLY2_EXIST; /* 103.08.29 fix*/
            
                if (*fstatus=='0' || *fstatus=='5' || *fstatus=='6') *fstatus='1';

                printf("dbname_tp --->before update compulsory_card\n");
            
                sprintf_s(stmt_buf,sizeof stmt_buf,"UPDATE %s:%s %s %s",
                                                   dbname_tp,"card",
                                                   "SET fstatus=?,ialter=?,dalter=?,ipolicy=?",
                                                   "WHERE icard=?");
                $PREPARE k2 FROM $stmt_buf;
                $EXECUTE k2 USING $fstatus,$entry,$Today,$plyn_1,$card2;
                if (sqlca.sqlerrd[2]==0) return M_CA_NOT_CARD;
            }
        }
        else
        { 
            /*�D�O�N��*/
            if (!IsBlankNull(card2))
            {
                $SELECT fstatus
                   INTO $fstatus
                   FROM card
                  WHERE icard=$card2;
                if (NOT_FOUND)  return err_msg;
           
                if (*fstatus=='1') return M_CA_PLY2_EXIST; /* 103.08.29 fix*/
           
                if (*fstatus=='0' || *fstatus=='5' || *fstatus=='6') *fstatus='1';

                $UPDATE card
                    SET (fstatus,ialter,dalter,ipolicy)
                      = ($fstatus,$entry,$Today,$plyn_1)
                  WHERE icard=$card2;
                if (sqlca.sqlerrd[2]==0) return M_CA_NOT_CARD;
            }
        }


        /* �I����H��10000,������ add by sylvia 100.06.22 */
        if((strcmp(trim(icomm_obj),"10000") == 0)  && ((mdmg_commi_2+mlia_commi_2) > 0)) /* �I����H10000,�����I���~�� */
        {
            return M_CA_CANT_HAVE_COMMI1;
        }

        /* 103.03 �e�~�C�L������ñ���  dpolicy = today*/
        /* 1061012002-SC3 ISID+rba�j���I�G�����X��@�~���L��� ���N�I ���ܦL��@�~���L���*/
        if (fout_print[0]!='0')
        {
            $UPDATE ply_relation
              SET fprint = 1
            WHERE ipolicy=$plyn_1;
        }
    }
    ins47_flag =0; ins50_flag =0;

    lngPrem05=lngPrem152=lngCover152=0;
    lngPrem161=lngCover161=0; /* 1070212002-SC1 0301�O�v�վ�0501�ͮ� 93�O�v+161+162(�ˮ֤��152+153�A�O�O���98)*/
    strcpy(RUL_OP->op_free_ins," ");
    Icurr=Ifirst;
    if (type==2 && rows>0)
    {
        while (Icurr)
        {
            if (EQUAL(rtrim(Icurr->ins_type),"**"))
            { 
            	/* deleted element */
                Icurr=Icurr->next;
                continue;
            }

            if (strcmp(Icurr->fproject,"Y") == 0)
            {
                sprintf_s(RUL_OP->op_free_ins,10,";%s;",rtrim(Icurr->ins_type));
                Icurr=Icurr->next;
                continue;
            }

            strcpy(ins_type,trim(Icurr->ins_type));
            strcpy(provision,Icurr->provision);

            if (strcmp(trim(ins_type),"56")==0)
            {
                ins56_flag = 1;
            }
            else if (strcmp(trim(ins_type),"136")==0)
            {
                ins136_flag = 1;
            }
            else if (strcmp(trim(ins_type),"166")==0)
            {
                ins166_flag = 1;  /*1080225007-SC1-��ã��-�s�W166�r��*/
            }
            else if (strcmp(trim(ins_type),"266")==0)
            {
                ins266_flag = 1;  /* 1110308005_SC1_�w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h */
            }
            else if (strcmp(trim(ins_type),"47")==0)
            {
                ins47_flag = 1;
            }
            else if (strcmp(trim(ins_type),"50")==0)
            {
                ins50_flag = 1;
            }
            
            strcpy(drate_ym_sql,Icurr->frate);
            /*1030725001_C1 �ߦw(118)�B����(120)����[�N�B���O�I*/
            /*1090812005-SC1-���ά�-�s�W�s�ӫ~-�T�����B���郞�I���l���O�I198�I*/
            /*1100909003-SC1-�_�@�Ϯ��S�h���p�{������07+15�}���O181�I�ݨD*/
            if ((strcmp(trim(ins_type),"01") == 0)  || (strcmp(trim(ins_type),"05") == 0) ||
                 (strcmp(trim(ins_type),"08") == 0) || (strcmp(trim(ins_type),"09") == 0) ||
                 (strcmp(trim(ins_type),"85") == 0) || (strcmp(trim(ins_type),"105") == 0)||
                 (strcmp(trim(ins_type),"118") == 0)|| (strcmp(trim(ins_type),"120") == 0)||
                 (strcmp(trim(ins_type),"122") == 0)|| (strcmp(trim(ins_type),"125") == 0)||
                 (strcmp(trim(ins_type),"126") == 0)|| (strcmp(trim(ins_type),"198") == 0)||
                 (strcmp(trim(ins_type),"181") == 0)|| (strcmp(trim(ins_type),"201") == 0)||
                 (strcmp(trim(ins_type),"205") == 0)|| (strcmp(trim(ins_type),"209") == 0)
               )
            {
                strcpy(GetPlyInsMain, trim(ins_type));
                rtncode = GetPlyDMG(GetPlyInsMain);
            }
            else if ((strcmp(trim(ins_type),"152")==0 || strcmp(trim(ins_type),"153")==0))
            {
                strcpy(GetPlyInsMain, trim(ins_type));
                rtncode = GetPlyDMG(GetPlyInsMain);
            }

            /*1030725001_C1 �ߦw(118)�B����(120)����[�N�B���O�I*/
            /* �O�I���B�d���H�U�L����˥h */
            /* 15�B16�B66�B67�B106�B107�I�ئܦʦ�*/
            if (strcmp(trim(ins_type),"15") ==0 || strcmp(trim(ins_type),"16") ==0 ||
                strcmp(trim(ins_type),"66") ==0 || strcmp(trim(ins_type),"67") ==0 ||
                strcmp(trim(ins_type),"19") ==0 || strcmp(trim(ins_type),"62") ==0 ||
                strcmp(trim(ins_type),"63") ==0 || strcmp(trim(ins_type),"64") ==0 ||
                strcmp(trim(ins_type),"34") ==0 || strcmp(trim(ins_type),"22") ==0 ||
                strcmp(trim(ins_type),"87") ==0 || strcmp(trim(ins_type),"97") ==0 ||
                strcmp(trim(ins_type),"106")==0 || strcmp(trim(ins_type),"107")==0 ||
                strcmp(trim(ins_type),"115")==0 || strcmp(trim(ins_type),"119")==0 ||
                strcmp(trim(ins_type),"121")==0 || strcmp(trim(ins_type),"123")==0 ||
                strcmp(trim(ins_type),"143")==0 || strcmp(trim(ins_type),"154")==0 ||
                strcmp(trim(ins_type),"155")==0 || strcmp(trim(ins_type),"156")==0 ||
                strcmp(trim(ins_type),"163")==0 || strcmp(trim(ins_type),"181")==0 ||
                strcmp(trim(ins_type),"237")==0
               )
            {   
            	/* 1070625011-SC1-��ã��-�s�W�s�A��+�����N�B���s�ӫ~(�I��163)�{���ޱ�*/
            	/*1100909003-SC1-�_�@�Ϯ��S�h���p�{������07+15�}���O181�I�ݨD*/
                /*1100311005-SC1-�����¦����s�A�������I�����{���]�w137�B138�B139�B141�B142�I��strcmp(trim(ins_type),"139")==0 ||strcmp(trim(ins_type),"141")==0 ||*/
                injured_cover = ((Icurr->injured_cover)/100)*100;
                death_cover   = ((Icurr->death_cover)/100)*100;
                damage_cover  = ((Icurr->damage_cover)/100)*100;
            }
            else if (strcmp(trim(ins_type),"12")==0) /* 1080422010-SC1-2�I�ثO�B���W���O�O�������t�@�i��α˥h�B�z */
            {
                injured_cover = ((Icurr->injured_cover)/100)*100;
                death_cover   = ((Icurr->death_cover)/100)*100;
                damage_cover  = ((Icurr->damage_cover)/1)*1;
            }
            else
            {
                injured_cover = ((Icurr->injured_cover)/1000)*1000;
                death_cover   = ((Icurr->death_cover)/1000)*1000;
                damage_cover  = ((Icurr->damage_cover)/1000)*1000;
            }

            deduct      = Icurr->deduct;
            pcommission = Icurr->pcommission;
            mcommission = Icurr->mcommission;
            pagent      = Icurr->pagent;
            magent      = Icurr->magent;
            pdiscount   = Icurr->pdiscount;
            mdiscount   = Icurr->mdiscount;
            qday        = Icurr->qday;
            mexpense    = Icurr->mexpense;
            mexp_disc   = Icurr->mexp_disc;

            if (strcmp(rtrim(ins_type),"29")==0)
            {
                qday = (long)lGetIns29BaseCover(coverage1_31,coverage2_31,coverage3_32);
            }

            /*1030725001_C1 �ߦw(118)�B����(120)����[�N�B���O�I*/
            /* 1090812005-SC1-���ά�-�s�W�s�ӫ~-�T�����B���郞�I���l���O�I198�I*/
            /*1100909003-SC1-�_�@�Ϯ��S�h���p�{������07+15�}���O181�I�ݨD*/
            if ((strcmp(rtrim(ins_type),"01") != 0) && (strcmp(rtrim(ins_type),"05") != 0) &&
                (strcmp(rtrim(ins_type),"08") != 0) && (strcmp(rtrim(ins_type),"09") != 0) &&
                (strcmp(rtrim(ins_type),"11") != 0) && (strcmp(rtrim(ins_type),"96") != 0) &&
                (strcmp(rtrim(ins_type),"85") != 0) && (strcmp(rtrim(ins_type),"105")!= 0) &&
                (strcmp(rtrim(ins_type),"118")!= 0) && (strcmp(rtrim(ins_type),"120")!= 0) &&
                (strcmp(rtrim(ins_type),"122")!= 0) && (strcmp(rtrim(ins_type),"125")!= 0) &&
                (strcmp(rtrim(ins_type),"126")!= 0) && (strcmp(rtrim(ins_type),"129")!= 0) && 
                (strcmp(rtrim(ins_type),"198")!= 0) && (strcmp(rtrim(ins_type),"181")!= 0) &&
                (strcmp(rtrim(ins_type),"201")!= 0) && (strcmp(rtrim(ins_type),"205")!= 0) &&
                (strcmp(rtrim(ins_type),"209")!= 0) && (strcmp(rtrim(ins_type),"211")!= 0)
               )
            {
                /* �[�ȥN�B���O�� */
                mexpense  = 0;
                mexp_disc = 0;
            }

            /* 103.10.14 �ĤT�H���d���Ƥ�������n��b qday�A��L���ĤT�H���d������ */
            if ((strcmp(rtrim(ins_type),"31")==0 || strcmp(rtrim(ins_type),"36")==0 || strcmp(rtrim(ins_type),"231")==0 || strcmp(rtrim(ins_type),"531")==0) && (injured_cover > 0))
            {
                qday = (long)(damage_cover / injured_cover) ;
            }

            strcpy(ipaid_base, trim(Icurr->ipaid_base));

            ins_premium      = (long)Icurr->ins_premium;
            bef_ins_premium  = (long)Icurr->bef_ins_premium;
            pure_ins_premium = (long)Icurr->pure_ins_premium;

            strcpy(drate_ym,Icurr->frate);

            test_prem += ins_premium;
            
            /* 1090812005-SC1-���ά�-�s�W�s�ӫ~-�T�����B���郞�I���l���O�I198�I*/
            /* 1100909003-SC1-�_�@�Ϯ��S�h���p�{������07+15�}���O181�I�ݨD*/
            if (strcmp(rtrim(ins_type),"01")==0  || strcmp(rtrim(ins_type),"05")==0  || strcmp(rtrim(ins_type),"08")==0  || strcmp(rtrim(ins_type),"09")==0  || strcmp(rtrim(ins_type),"85")==0 ||
                strcmp(rtrim(ins_type),"105")==0 || strcmp(rtrim(ins_type),"118")==0 || strcmp(rtrim(ins_type),"120")==0 || strcmp(rtrim(ins_type),"122")==0 ||
                strcmp(rtrim(ins_type),"11")==0  || strcmp(rtrim(ins_type),"96")==0  || strcmp(rtrim(ins_type),"12")==0  ||
                strcmp(rtrim(ins_type),"125")==0 || strcmp(rtrim(ins_type),"126")==0 || strcmp(rtrim(ins_type),"129")==0 || strcmp(rtrim(ins_type),"198")==0 || strcmp(rtrim(ins_type),"181")==0 ||
                strcmp(rtrim(ins_type),"201")==0 || strcmp(rtrim(ins_type),"205")==0 || strcmp(rtrim(ins_type),"209")==0 ||
                strcmp(rtrim(ins_type),"211")==0
               )
            {
                flag_dmg=1;
            }
            
            if (strcmp(rtrim(ins_type),"31")==0  || strcmp(rtrim(ins_type),"32")==0  ||
                strcmp(rtrim(ins_type),"36")==0  || strcmp(rtrim(ins_type),"37")==0  ||
                strcmp(rtrim(ins_type),"103")==0 || strcmp(rtrim(ins_type),"104")==0 ||
                strcmp(rtrim(ins_type),"113")==0 || strcmp(rtrim(ins_type),"114")==0 ||
                strcmp(rtrim(ins_type),"131")==0 || strcmp(rtrim(ins_type),"132")==0 ||
                strcmp(rtrim(ins_type),"133")==0 || strcmp(rtrim(ins_type),"134")==0 ||
                strcmp(rtrim(ins_type),"51")==0  || strcmp(rtrim(ins_type),"149")==0 ||
                strcmp(rtrim(ins_type),"231")==0 || strcmp(rtrim(ins_type),"232")==0 ||
                strcmp(rtrim(ins_type),"331")==0 || strcmp(rtrim(ins_type),"332")==0 ||
                strcmp(rtrim(ins_type),"531")==0 || strcmp(rtrim(ins_type),"532")==0 ||
                strcmp(rtrim(ins_type),"249")==0
               )
            {
                flag_lia=1;
            }

            if( strcmp(ins_type,"105") == 0 || strcmp(ins_type,"118") == 0 )
            {
                if (ins_premium < injured_cover)
                {
                    strcpy(sNeedChkCar,"Y");	/* 105�O�O<�������l,�w�]�����n�ɨ� */
                }
            }
            else if( strcmp(ins_type,"05") == 0 || strcmp(ins_type,"205") == 0)
            {
                lngPrem05  = ins_premium;
            }
            else if( strcmp(ins_type,"152") == 0 )
            {
                lngCover152 = damage_cover;
                lngPrem152  = ins_premium;
            }
            else if( strcmp(ins_type,"161") == 0 )
            {
                lngCover161_last = 0;
                lngCover161 = damage_cover;
                lngPrem161 = ins_premium;
                /* 1070531004-SC1-��ã��-�ק���sCAR301�A09+162��05+161��O���ˮ�*/ 
                if (strlen(trim(pp1)) > 0)
                {
                    strcpy(tmp_fulldb,get_car_full_db(pp1));
                    sprintf_s( stmt,sizeof stmt,"select mdamage_cover \n"
                                                "  from %s:ply_ins_type a \n"
                                                " where a.ipolicy = '%s'\n"
                                                "   AND iins_type = '161' ", tmp_fulldb, pp1);
                    $PREPARE pre_ply_ins_chk FROM $stmt;
                    $EXECUTE pre_ply_ins_chk INTO $lngCover161_last;
                    if( SQLCODE == SQLNOTFOUND)
                    {
                        lngCover161_last = 0;
                        
                    }
                    
                }
                else
                {
                    lngCover161_last = 0;
                }
            }

            $SELECT qserial
               INTO $qserial
               FROM insurance_type
              WHERE iins_type=$ins_type;
            if (NOT_FOUND)  return M_CA_NINS_TYPE;

            

            rc = get_iproduct_car(ins_type,car_typei,iproduct, provision,drate_ym);
            if (rc != M_CM_OK) return M_CA_NON_PRODUCT;
                
                
            irate          = Icurr->irate;
            adjust_rate    = Icurr->adjust_rate;
            mins_premium_n = Icurr->mins_premium_n;
            mpure_prem_n   = Icurr->mpure_prem_n;
            mprem_n        = Icurr->mprem_n;

            /* 'car9610231��~�βĤT�H�f�B�~���[���� */
            safe_rate      = Icurr->safe_rate;
            manage_rate    = Icurr->manage_rate;
            educated_rate  = Icurr->educated_rate;

            /* �«O�O�����v */
            deviation_rate  = Icurr->deviation_rate;

            pextra_charge  = Icurr->pextra_charge; /* ���[�O�βv */
            pbusiness      = Icurr->pbusiness;     /* �~�޶O�βv */
            psex_age       = Icurr->psex_age;      /* �I�ةʧO�~�֫Y�� */
            pshipping      = Icurr->pshipping;     /* car9808043 �f�B�~���[����C */
            pcar_price     = Icurr->pcar_price;    /* �������[�O�Y�� 104.10.13 (1021211003_C3_�T������l���O�I�O�O�p��ǤJ�������Y�ƶO�v) */

            if( mcommission < 0)
                return M_CA_COMMI_0;

            if( magent < 0)
                return M_CA_AGENT_0;
            /*        
            #ifdef PRINTF_FLAG
            printf("plyn_1[%s]\n",plyn_1);
            printf("ins_type[%s]\n",ins_type);
            printf("injured_cover[%d]\n",injured_cover);
            printf("death_cover[%d]\n",death_cover);
            printf("damage_cover[%d]\n",damage_cover);
            printf("deduct[%d]\n",deduct);
            printf("ins_premium[%d]\n",ins_premium);
            printf("pure_ins_premium[%d]\n",pure_ins_premium);
            printf("pcommission[%f]\n",pcommission);
            printf("mcommission[%f]\n",mcommission);
            printf("pagent[%f]\n",pagent);
            printf("magent[%f]\n",magent);
            printf("pdiscount[%f]\n",pdiscount);
            printf("mdiscount[%f]\n",mdiscount);
            printf("qserial[%d]\n",qserial);
            printf("drate_ym[%s]\n",drate_ym);
            printf("bef_ins_premium[%d]\n",bef_ins_premium);
            printf("iproduct[%s]\n",iproduct);
            printf("ipaid_base[%s]\n",ipaid_base);
            printf("qday[%d]\n",qday);
            printf("mexpense[%f]\n",mexpense);
            printf("mexp_disc[%f]\n",mexp_disc);
            printf("provision[%s]\n",provision);
            printf("irate[%d]\n",irate);
            printf("adjust_rate[%f]\n",adjust_rate);
            printf("mins_premium_n[%f]\n",mins_premium_n);
            printf("safe_rate[%f]\n",safe_rate);
            printf("manage_rate[%f]\n",manage_rate);
            printf("educated_rate[%f]\n",educated_rate);
            printf("deviation_rate[%f]\n",deviation_rate);
            printf("pextra_charge[%f]\n",pextra_charge);
            printf("pbusiness[%f]\n",pbusiness);
            printf("psex_age[%f]\n",psex_age);
            printf("pshipping[%f]\n",pshipping);
            printf("Qdrunk_prem[%f]\n",Qdrunk_prem);
            printf("Qdrunk_pure_prem[%f]\n",Qdrunk_pure_prem);
            printf("Qviolate_prem[%f]\n",Qviolate_prem);
            printf("Qviolate_pure_prem[%f]\n",Qviolate_pure_prem);
            printf("pcar_price[%f]\n",pcar_price);
            #endif
            */
                
            /*  1090708005-SC1-���ά�-�ˮ֪��[������줧���T�� */
            iChkProvision = 0; /* 1090708005-SC1-���ά�-�ˮ֪��[������줧���T��*/
            strcpy(provision,trim(provision));
            sprintf_s(sProvDelimiter,sizeof sProvDelimiter,"%s;",trim(provision));
            /*printf("sProvDelimiter[%s]\n",sProvDelimiter);*/
            sChkInsProvTok = strtok(sProvDelimiter,";");
            while (sChkInsProvTok) /* ���ΩӫO�����[���� �v�Ӷi��*/
            {
                printf("sChkProvMain[%s]sChkInsProvTok[%s]\n",sChkProvMain,sChkInsProvTok);
                if (strstr(sChkProvMain, sChkInsProvTok) == NULL)
                {
                    sprintf_s(v_errMsg,sizeof v_errMsg,"[%s]���s�b�����[���ڡA",sChkInsProvTok);   
                    Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                    return M_CA_EXTRA_CHARGE_DRATE;
                    
                }
                    
                /* �ˬdply_begin�Ĵ� dactive_sys �ҥΨt�Τ�  =>   �৹���������O�ŦX�W�h�A�ҥH���ݦA���ˮ�
                                     dactive     �ҥΥͮĤ�  =>   �৹���������O�ŦX�W�h�A�ҥH���ݦA���ˮ�      
                                     dexpire_sys ���Ψt�Τ�
                                     dexpire     ���ΥͮĤ�*/    
                $SELECT count(*)
                   INTO $iChkProvision
                   FROM ca_provision_main
                  WHERE iprovision = $sChkInsProvTok
                    AND (dexpire_sys <= today
                         OR  dexpire <= $ply_begin);
                        
                if(iChkProvision>0)
                {   
                    printf("7490=>iChkProvision[%d]\n",iChkProvision);
                    sprintf_s(v_errMsg,sizeof v_errMsg, "[%s]�����Ϊ��[���ڡA",sChkInsProvTok);   
                    Update_car3011_temp(estimatei, "1", sIleader, sIquota, sNquota, " ", " ", fout_print, feply, v_errMsg);
                    return M_CA_EXTRA_CHARGE_DRATE;
                }
                
                sChkInsProvTok = strtok(NULL,";");
            }
                

            $INSERT INTO  ply_ins_type
                          (ipolicy,iins_type,minjured_cover,
                           mdeath_cover,mdamage_cover,mdeduct,
                           mins_premium,mpure_prem,pcommission,mcommission,
                           pagent,magent,pdiscount,mdiscount,qserial,drate_ym,
                           mprem,iproduct,ipaid_base,
                           qday,mexpense,mexp_disc,provision,
                           irate, adjust_rate, mins_premium_n, mpure_prem_n, mprem_n,
                           safe_rate, manage_rate, educated_rate, deviation_rate,
                           pextra_charge, pbusiness, psex_age, pshipping,
                           mdrunk_prem,mdrunk_pure_prem,pcar_price,mviolate_prem,mviolate_pure_prem)
                  VALUES ($plyn_1,$ins_type,$injured_cover,
                          $death_cover,$damage_cover,$deduct,
                          $ins_premium,$pure_ins_premium,$pcommission,$mcommission,
                          $pagent,$magent,$pdiscount,$mdiscount,
                          $qserial,$drate_ym,$bef_ins_premium,$iproduct,$ipaid_base,
                          $qday,$mexpense,$mexp_disc,$provision,
                          $irate, $adjust_rate, $mins_premium_n, $mpure_prem_n, $mprem_n,
                          $safe_rate, $manage_rate, $educated_rate, $deviation_rate,
                          $pextra_charge, $pbusiness, $psex_age, $pshipping,
                          $Qdrunk_prem, $Qdrunk_pure_prem,$pcar_price,$Qviolate_prem,$Qviolate_pure_prem);
            puts("jack 2");
            
            Icurr=Icurr->next;
        }/* end while */

        if (test_prem != mdmg_prem+mlia_prem)
        {
            printf("### test_prem[%d] mdmg_prem[%d] mlia_prem[%d]\n",test_prem,mdmg_prem,mlia_prem);
            return M_CA_PREMIUM_NEQUAL;
        }
        
        if (flag_dmg==1 && mdmg_prem==0)
        {
            return M_CA_DMG_PREM_EQUAL_0;
        }
        
        if (flag_lia==1 && mlia_prem==0)
        {
            return M_CA_LIA_PREM_EQUAL_0;
        }

        /* 1051214006_C1 �]���D�޾������ܤ����X�W���l�I�U�[�ΰӫ~�s�W_�����ܧ�O�v�ץ� */
        /* (05 + 152)�O�O<�������l�O�B,�w�]�����n�ɨ� */
        /* 1070212002-SC1 0301�O�v�վ�0501�ͮ� 93�O�v+161+162(�ˮ֤��152+153�A�O�O���98)*/
        if (lngCover152 > 0 || lngCover161 > 0)
        {
            if ((( (lngPrem05+lngPrem152) < lngCover152) ||( (lngPrem05+lngPrem161) < lngCover161)) &&  lngCover161_last < lngCover161)
            {
                strcpy(sNeedChkCar,"Y");	/* 105�O�O<�������l,�w�]�����n�ɨ� */
            }
        }
    }



    /*** �ˮ`�I���Ӹ��-48 ***/
    Icurr_48=Ifirst_48;
    if (type==2 && rows_48>0)
    {
        while (Icurr_48)
        {
            strcpy(cIinsurant     , Icurr_48->cIinsurant);
            strcpy(cIins_type     , "48");
            strcpy(cNinsurant     , Icurr_48->cNinsurant);
            strcpy(cIins_scope    , Icurr_48->cIins_scope);
            strcpy(cRelation_appl , Icurr_48->cRelation_appl);
            lDbirth        = Icurr_48->lDbirth;
            lMins_amt      = Icurr_48->lMins_amt;
            lMins_premium  = (long)d45( Icurr_48->lMins_premium ,0);  /*1030523002_C1, ��L����˥h�A�אּ�|�ˤ��J*/
            lPure_premium  = (long)d45( Icurr_48->lPure_premium ,0);  /*1030523002_C1, ��L����˥h�A�אּ�|�ˤ��J*/
            lMr_ins_premium  = (long)d45( Icurr_48->lMr_ins_prem  ,0);  /*1030523002_C1, ��L����˥h�A�אּ�|�ˤ��J*/
            lMr_pure_premium = (long)d45( Icurr_48->lMr_pure_prem ,0);  /*1030523002_C1, ��L����˥h�A�אּ�|�ˤ��J*/
            dPcommission   = Icurr_48->dPcommission;
            lMcommission   = Icurr_48->lMcommission;
            dPagent        = Icurr_48->dPagent;
            lMagent        = Icurr_48->lMagent;
            dPdiscount     = Icurr_48->dPdiscount;
            lMdiscount     = Icurr_48->lMdiscount;
            cDaily_pay     = (long)Icurr_48->lDaily_pay;

            
            $INSERT INTO  ca_pa_ply
                          (ipolicy, iins_type,
                           iinsurant, ninsurant, dbirth,
                           iins_scope, mins_amt, mins_premium, mpure_prem,
                           pcommission, mcommission, pagent, magent,
                           pdiscount, mdiscount,
                           relation_appl, mr_ins_prem, mr_pure_prem, daily_pay )
                   VALUES ($plyn_1, $cIins_type,
                           $cIinsurant, $cNinsurant, $lDbirth,
                           $cIins_scope, $lMins_amt, $lMins_premium, $lPure_premium,
                           $dPcommission, $lMcommission, $dPagent, $lMagent,
                           $dPdiscount, $lMdiscount,
                           $cRelation_appl, $lMr_ins_premium, $lMr_pure_premium, $cDaily_pay );
            
            Icurr_48=Icurr_48->next;
        } /* end while */
    }

    /*** �ĤT�H�d�����Ӹ��-35 ***/
    Icurr_35=Ifirst_35;
    if (type==2 && rows_35>0)
    {
        while (Icurr_35)
        {
            strcpy(cIinsurant     , Icurr_35->cIinsurant);
            strcpy(cIins_type     , "35");
            strcpy(cNinsurant     , Icurr_35->cNinsurant);
            strcpy(cIins_scope    , Icurr_35->cIins_scope);
            lMins_amt      = Icurr_35->lMins_amt;
            lMins_premium  = (long)d45( Icurr_35->lMins_premium ,0);  /*1030523002_C1, ��L����˥h�A�אּ�|�ˤ��J*/
            lPure_premium  = (long)d45( Icurr_35->lPure_premium ,0);  /*1030523002_C1, ��L����˥h�A�אּ�|�ˤ��J*/
            dPcommission   = Icurr_35->dPcommission;
            lMcommission   = Icurr_35->lMcommission;
            dPagent        = Icurr_35->dPagent;
            lMagent        = Icurr_35->lMagent;
            dPdiscount     = Icurr_35->dPdiscount;
            lMdiscount     = Icurr_35->lMdiscount;

            
             $INSERT INTO  ca_pa_ply
                           (ipolicy, iins_type,
                            iinsurant, ninsurant,
                            iins_scope, mins_amt, mins_premium, mpure_prem,
                            pcommission, mcommission, pagent, magent,
                            pdiscount, mdiscount )
                   VALUES ($plyn_1, $cIins_type,
                           $cIinsurant, $cNinsurant,
                           $cIins_scope, $lMins_amt, $lMins_premium, $lPure_premium,
                           $dPcommission, $lMcommission, $dPagent, $lMagent,
                           $dPdiscount, $lMdiscount );
            
            Icurr_35=Icurr_35->next;
        } /* end while */
    }

    Icurr_56=Ifirst_56;
    if (type==2 && rows_56>0)
    {

        $char tmp_ins56[7];
        if (ins56_flag==1)
        {
            strcpy(tmp_ins56,"56");
        }
        else if (ins136_flag==1)
        {
            strcpy(tmp_ins56,"136");
        }
        else if (ins166_flag==1)
        {
            strcpy(tmp_ins56,"166"); /* 1080225007-SC1-��ã��-�s�W166�r�� */
        }
        else if (ins266_flag==1)
        {
            strcpy(tmp_ins56,"266"); /* 1110308005_SC1_�w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h */
        }
        
        while (Icurr_56)
        {
            strcpy(cIinsurant     , Icurr_56->cIinsurant);
            strcpy(cIins_type     , tmp_ins56);
            strcpy(cNinsurant     , Icurr_56->cNinsurant);
            strcpy(cAinsurant     , " ");
            strcpy(cIins_scope    , Icurr_56->cIins_scope);
            strcpy(cIcareer       , " ");
            strcpy(cNapplicant    , " ");
            strcpy(cRelation_appl , " ");
            strcpy(cTbenef , " ");
            strcpy(cAbenef_zip , " ");
            strcpy(cAbenef , " ");
            
            strcpy(cNbeneficiary  , Icurr_56->cNbeneficiary);
            strcpy(cRelation_bene , Icurr_56->cRelation_bene);
            lDbirth        = Icurr_56->lDbirth;
            lMins_amt      = Icurr_56->lMins_amt;
            lMins_premium  = (long)d45( Icurr_56->lMins_premium ,0); /*1030523002_C1, ��L����˥h�A�אּ�|�ˤ��J*/
            lPure_premium  = (long)d45( Icurr_56->lPure_premium ,0); /*1030523002_C1, ��L����˥h�A�אּ�|�ˤ��J*/
            lMr_ins_premium  = (long)d45( Icurr_56->lMr_ins_prem ,0); /*1030523002_C1, ��L����˥h�A�אּ�|�ˤ��J*/
            /*lMr_pure_premium = (long)Icurr_56->lMr_pure_prem;*/
            fMr_pure_premium = Icurr_56->lMr_pure_prem;    /*1030523002_C1,�����«O�O�������@�����p�� */
            cDaily_pay     = (long)Icurr_56->lDaily_pay;
            dPcommission   = Icurr_56->dPcommission;
            lMcommission   = Icurr_56->lMcommission;
            dPagent        = Icurr_56->dPagent;
            lMagent        = Icurr_56->lMagent;
            dPdiscount     = Icurr_56->dPdiscount;
            lMdiscount     = Icurr_56->lMdiscount;
            /*'1090221006-SC1-��ã��-��_56�r�p�H�W�U(�t���s�BE�O���BB2B�BB2C)�Ʊ��3��ק�4��W�u*/
            strcpy(cTbenef        , Icurr_56->cTbenef);
            strcpy(cAbenef_zip    , Icurr_56->cAbenef_zip);
            strcpy(cAbenef        , Icurr_56->cAbenef);
            
            $INSERT INTO  ca_pa_ply
                          (ipolicy, iins_type,
                           iinsurant, ninsurant, dbirth, ainsurant,
                           iins_scope, icareer, mins_amt, mins_premium, mpure_prem,
                           pcommission, mcommission, pagent, magent,
                           pdiscount, mdiscount,
                           napplicant, relation_appl, nbeneficiary, relation_bene,
                           daily_pay, mr_ins_prem, mr_pure_prem ,
                           tbenef,       abenef_zip,     abenef)
                  VALUES  ($plyn_1, $cIins_type,
                           $cIinsurant, $cNinsurant, $lDbirth, $cAinsurant,
                           $cIins_scope, $cIcareer, $lMins_amt, $lMins_premium, $lPure_premium,
                           $dPcommission, $lMcommission, $dPagent, $lMagent,
                           $dPdiscount, $lMdiscount,
                           $cNapplicant, $cRelation_appl, $cNbeneficiary, $cRelation_bene,
                           $cDaily_pay,  $lMr_ins_premium,$fMr_pure_premium,
                           $cTbenef,     $cAbenef_zip,    $cAbenef); /* $lMr_pure_premium );*/
            
            Icurr_56=Icurr_56->next;
        }/* end while */
    }

    printf("*** before insert ply_ins_type, ply[%s] ins_tp[%s]\n",plyn_1,ins_type);

    if (type==1)
    {
        strcpy(comp_rym, rtrim(comp_rym));
        strcpy(provision, " ");

        $SELECT drate
           FROM ca_rate_date
          WHERE icode=$comp_rym
            AND itable='compulsory_premium';
        if (NOT_FOUND)  return M_CA_NRATE_DATE;

        /*printf("car_typei=[%s]\n", car_typei);*/

        rc = get_iproduct_car("21",car_typei,iproduct, provision,comp_rym);
        if (rc != M_CM_OK) return M_CA_NON_PRODUCT;

        /* car9712022 �j���I�ȳf������۵M�H�k�H�O�v */
        rc = get_comp_car_type_fassured( car_typei, comp_rym, assuredf, cartype_tmp, comp_fassured, v_sMsg);
        if ( rc != M_CM_OK)  return rc;

        printf("cy dbg assuredf[%s],cartype_tmp[%s]\n",assuredf,cartype_tmp);
        printf("comp_rym[%s]\n",comp_rym);
        $SELECT mcoverage1,mcoverage2,mcoverage3
           INTO $injured_cover,$death_cover,$damage_cover
           FROM compulsory_premium
          WHERE icar_type=$cartype_tmp
            AND qperiod=12
            AND ((qcar_personbgn <= $qpt AND qcar_personend >= $qpt)
                 OR (qcar_personbgn=0))
            AND drate=(SELECT drate FROM ca_rate_date
                        WHERE icode=$comp_rym
                          AND itable='compulsory_premium')
            AND fassured = $comp_fassured;

        if (NOT_FOUND)  return M_CA_NCOMP_PREMIUM;

        strcpy(ins_type,"21    ");
        deduct          = 0;
        pcommission     = 0;
        pagent          = 0;
        pdiscount       = 0;
        mcommission     = 0;
        magent          = 0;
        mdiscount       = 0;
        ins_premium     = premium1;
        bef_ins_premium = bef_ins_premium1;  /* car920221 */
        qserial         = 0;
        irate          = 0;
        adjust_rate    = 0;
        mins_premium_n = ins_premium;
        mpure_prem_n   = madjcom_prem;
        mprem_n        = bef_ins_premium;

        /* 'car9610231��~�βĤT�H�f�B�~���[���� */
        safe_rate    = 0;
        manage_rate  = 0;
        educated_rate  = 1;

        /* �«O�O�����v */
        deviation_rate  = 0;

        pextra_charge = 0;
        pbusiness     = 0;
        psex_age     = 0;
        pshipping    = 0;

        if( mcommission21 < 0)
            return M_CA_SERVICE_1;

        if( magent < 0)
            return M_CA_AGENT_0;

        /* car9811303 �j���I99.3.1�O�v */
        rc = chk_commi_business( 1, abn_type, comp_rym, mcommission21, mbusiness, v_sMsg);

        if( rc != M_CM_OK)
            return rc;
        printf("INSERT  ply_ins_type mcommission21:%d>>\n",mcommission21); 
        $INSERT INTO  ply_ins_type
                    (ipolicy,iins_type,minjured_cover,mdeath_cover,
                     mdamage_cover,mdeduct,mins_premium,mpure_prem,pcommission,
                     mcommission,pagent,magent,pdiscount,mdiscount,
                     qserial,drate_ym,mprem,iproduct,
                     qday,mexpense,mexp_disc,provision,
                     irate, adjust_rate, mins_premium_n, mpure_prem_n, mprem_n, safe_rate, manage_rate,
                     educated_rate, deviation_rate, pextra_charge, pbusiness, psex_age, pshipping,
                     mdrunk_prem, mdrunk_pure_prem, mviolate_prem, mviolate_pure_prem)
             VALUES ($plyn_1,$ins_type,$injured_cover,$death_cover,
                     $damage_cover,$deduct,$ins_premium,$madjcom_prem,
                     $pcommission,$mcommission21,
                     $pagent,$magent,$pdiscount,$mdiscount,
                     $qserial,$comp_rym,$bef_ins_premium,$iproduct,
                     0,0,0,$provision,
                     $irate, $adjust_rate, $mins_premium_n, $mpure_prem_n, $mprem_n, $safe_rate, $manage_rate,
                     $educated_rate, $deviation_rate, $pextra_charge, $pbusiness, $psex_age, $pshipping,
                     $Gdrunk_prem, $Gdrunk_pure_prem, $mviolate_prem, $mviolate_pure_prem);
    }

    /* ------------------------------------------------------------------ */

    strcpy( sDbname, get_full_dbname(localdb));
    strcpy( sColumn, "ipolicy");
    strcpy( sTable,  "ply_ins_type");

    printf("������ ñ����ˮ� line19920 ������������ \n");
    strcpy(RUL_OP->op_sDbname, sDbname);            /* ��Ʈw */
    strcpy(RUL_OP->op_sTable, sTable);              /* ��ƪ��W�� */
    strcpy(RUL_OP->op_sColumn, sColumn);            /* ���W�� */
    strcpy(RUL_OP->op_sData, plyn_1);               /* ��Ƥ��e */
    strcpy(RUL_OP->op_iabn_type, abn_type);         /* ���`����O */
    strcpy(RUL_OP->op_nequipment, equipment);       /* ���O���O */
    strcpy(RUL_OP->op_option, fcalc);               /* 1:�O�O�p��A��L:�w�s��Ʈw */
    strcpy(RUL_OP->op_officer, officer2);           /* �g��N�� */
    strcpy(RUL_OP->op_cartype, car_typei);          /* ���� */
    strcpy(RUL_OP->op_nassured, assuredn);          /* �Q�O�I�H�m�W */
    strcpy(RUL_OP->op_ilicense, assuredi);          /* �Q�O�I�HID,1060523001_C1_���I�պ�X��@�~�s�W��-�Ȥᱱ�޷s�W�n�O�HID�ˮ� */
    strcpy(RUL_OP->op_iengine, engine);             /* �������X */
    strcpy(RUL_OP->op_ibody, body);                 /* �������X */
    strcpy(RUL_OP->op_itag, tagnum);                /* ���P���X */
    strcpy(RUL_OP->op_ply_edr, "P");                /* �O/�����O P:�O��BE:��� */
    if (ply1f==TRUE)
        strcpy(RUL_OP->op_ply1f, "1");             /* ���j���I */
    else
        strcpy(RUL_OP->op_ply1f, "0");             /* �L�j���I */
    strcpy(RUL_OP->op_iendorse, " ");               /* ��渹  */
    strcpy(RUL_OP->op_need_abn, " ");               /* ���H���`��f�� */
    strcpy(RUL_OP->op_need_mcheck, " ");            /* ���H�u�֫O add by sylvia 102.04.22*/
    strcpy(RUL_OP->op_iapplicant, iapplicant);      /* �n�O�HID  ,1060523001_C1_���I�պ�X��@�~�s�W��-�Ȥᱱ�޷s�W�n�O�HID�ˮ� */
    strcpy(RUL_OP->op_napplicant, napplicant);      /* �n�O�H�W��,1060523001_C1_���I�պ�X��@�~�s�W��-�Ȥᱱ�޷s�W�n�O�HID�ˮ� */
    strcpy(RUL_OP->op_iroute, iroute);              /* �q���N�� */

    /*printf("21189 RUL_OP->op_free_ins=[%s]\n",RUL_OP->op_free_ins);
    printf("ca_provision_main===>7876-sChkProvMain[%s]\n",sChkProvMain);*/
    rtncode = chk_ply_rule(RUL_OP, v_sMsg);
    /*printf("ca_provision_main===>7880-sChkProvMain[%s]\n",sChkProvMain);
    printf("-- trace chk_ply_rule() return rtncode[%d]\n ",rtncode);    
    printf("-- trace chk_ply_rule() return v_sMsg[%s]\n ",v_sMsg);  */  
    if( rtncode != M_CM_OK)
    {
        strcpy(v_errMsg, v_sMsg);
        return rtncode;
    }
           

    /*1050118006_C1:PA80521360(�Τ@�F��)�i��O�ѵs�I(�L�ۭt�B)���[�ѵs���l�K����(17)*/
    rtncode = chk_iins_type_relation( sDbname, sTable, sColumn, plyn_1, abn_type, equipment,iroute, v_sMsg);
    /* M_CA_ONLY1150 �O��W�ӫO11/50/11+50�ɷ|return���T��,�O�ΨӦb���ɧP�_,�G�O�泡�����ư� */
    if( rtncode != M_CM_OK && rtncode != M_CA_ONLY1150)
        return rtncode;

    #ifdef CA_CONS

    if (type==2) /* ���N�I */
    {
        strcpy( sDbname, get_full_dbname(localdb));
        strcpy( sColumn, "ipolicy");
        strcpy( sTable,  "ply_ins_cover");
        strcpy(sViins_type, " ");
        rtncode = insert_ply_ins_cover( sDbname, sTable, sColumn, plyn_1, IfirstPlyInsCover, sViins_type, v_sMsg);
        if( rtncode != M_CM_OK)
            return rtncode;
    }

    #endif

    if (type==2) /* ���N�I */
    {
        strcpy( sDbname, get_full_dbname(localdb));
        strcpy( sColumn, "ipolicy");
        strcpy( sTable,  "ply_ins_assured");
        strcpy(sViins_type, " ");
        rtncode = insert_ply_ins_assured( sDbname, sTable, sColumn, plyn_1, IfirstPlyInsAssured, sViins_type, v_sMsg);
        if( rtncode != M_CM_OK)
            return rtncode;

        /* car9903041 ���s�t�λP���O�B�ɨ�����s�� */
        strcpy( sTable,  "ca_ply_bound");
        rtncode = insert_ca_ply_bound( sDbname, sTable, sColumn, plyn_1, ibound, v_sMsg);
        if( rtncode != M_CM_OK)
            return rtncode;
    }
 
    /* 1120811012_C01_�j���I�i�H���O���O���� */
    if (type==1) /* �j���I */
    {
        strcpy( sDbname, get_full_dbname(localdb));
        strcpy( sColumn, "ipolicy");
        strcpy( sTable,  "ca_ply_bound");
        rtncode = insert_ca_ply_bound( sDbname, sTable, sColumn, plyn_1, ibound, v_sMsg);
        if( rtncode != M_CM_OK)
            return rtncode;
    }
    
    /* car9712122 �N�O�渹�g�Jca_accept */
    strncpy( iroute4, iroute, 4);
    iroute4[4] = '\0';

    printf("bef acc equipment[%s]\n",equipment);
    if (type==1)               /* �j���I */
    {
        ply_period=ply1_period;
        ply_begin=ply1_begin;
        ply_end=ply1_end;
        strcpy(treaty1,"6");
        strcpy(tmp_user," ");
        strcpy(tmp_benefi," ");
        strcpy(tmp_benefn," ");
        psex_age=psex_age1;
        plia_acc=plia_acc1;
        tmp_pdmg_acc=tmp_punknown_acc=0;
        facf[0]='\0';
        passf[0]='\0';
        facd=DATENULL;
        /*printf("21 equipment 1 [%s]\n",equipment);*/
        strcpy(equipment_tmp,equip_delete(equipment,"15"));
        /*printf("21 equipment 2 [%s] equipment_tmp[%s]\n",equipment,equipment_tmp);*/
        strcpy(tmp_equipment,equip_delete(equipment_tmp,"16"));

        /* car9903041 ���s�t�λP���O�B�ɨ�����s�� */
        
        strcpy(equipment_tmp,equip_delete(tmp_equipment,"1"));
        
        /* 1120811012_C01_�j���I�i�H���O���O���� */
        /*strcpy(tmp_equipment,equip_delete(equipment_tmp,"77"));*/
        strcpy(tmp_equipment,equipment_tmp);
        
        strcpy(equipment_tmp,equip_delete(tmp_equipment,"113"));  /* 1071009009-SC1-113�n�O�ѥ��^->�u��e�O�������X��~��113*/
        strcpy(tmp_equipment,equipment_tmp);
        
        strcpy( tmp_survey_num, " ");
        /* 1120811012_C01_�j���I�i�H���O���O���� */
        /*strcpy( tmp_bound_num, " ");*/
        strcpy( tmp_bound_num, bound_num);
        
        /*printf("21 equipment 3 [%s]\n",equipment);*/
        strcpy(tmp_dmg," ");
        strcpy(tmp_lia,iquery_num_c);
        strcpy(tmp_iquery_num_unknown," ");
        tmp_lia_acc_sum = 0;
        tmp_dmg_acc_sum = 0;
        tmp_qunknown_acc_sum = 0;

        tmp_psex_age_damage = 0;
        /*printf("---- 21445 iquery_num_c=[%s] tmp_lia=[%s]-\n",iquery_num_c,tmp_lia);*/


        strcpy(sIinkind_ply,"C1");
        
        /* 1060817004 �n�H���y�Ǹ��^�g�q�lñ�p��ƥD�ɫO�渹�Ϊ��A�w�X�� */
        if (strlen(trim(sIscan_no)) >0)
        {
            $UPDATE cm_esign_data  
                SET ipolicy = $plyn_1,
                    fstatus = '1',
                    iupdate = 'CAR3011-'||$userid,
                    dupdate = current
              WHERE iscan_no = $sIscan_no
                AND fstatus = '0';
         
            if (sqlca.sqlerrd[2]==0)
            {
                sprintf_s(v_errMsg,sizeof v_errMsg,"�q�lñ�p��ƥD�ɧ�s����[%s]",sIscan_no);
                Update_car3011_temp(estimatei, itoa(type), sIleader, sIquota, sNquota, " ", " ", fout_print, feply_1, v_errMsg);
                return M_CA_ESIGN_UPD_ERR;
            }
        }
    }
    else
    {
        ply_period=ply2_period;
        ply_begin=ply2_begin;
        ply_end=ply2_end;
        strcpy(treaty1,"1");
        strcpy(tmp_user,user);
        strcpy(tmp_benefi,benefi);
        strcpy(tmp_benefn,benefn);
        psex_age=psex_age2;
        plia_acc=plia_acc2;
        tmp_pdmg_acc=pdmg_acc;
        tmp_punknown_acc=punknown_acc;
        strcpy(fcar_note,fcar_note2);
        /* ���N�I�����O�j���I�t�B����O */
        strcpy(tmp_equipment,equip_delete(equipment,"17"));
        /* 1060817004-C1 �q�lñ�p���y�Ǹ� 
           �ݩ���N�I�O��q��20�B21�B30�B31�A�Y�q�lñ�p���������O�z�L�q�lñ�p��(N)fagency 
           ���ܨ��I���O��91���������F�䥦�q���O���B�z
            
           �n�H���y�Ǹ��^�g�q�lñ�p��ƥD�ɫO�渹�Ϊ��A�w�X��*/
        printf("tmp_equipment[%s]irelative_ply[%s]\n",tmp_equipment,irelative_ply);
        if (strlen(trim(sIscan_no)) >0)
        {    
            if ((strncmp(bzfrom2,"20",2) == 0) || (strncmp(bzfrom2,"21",2) == 0) ||(strncmp(bzfrom2,"30",2) == 0)||(strncmp(bzfrom2,"31",2) == 0))
            {
                if (sfagency[0]=='N')
                    strcpy(equipment_tmp,equip_insert(tmp_equipment,"91"));
                else
                    strcpy(equipment_tmp,equip_delete(tmp_equipment,"91"));
            }
            else
            {
                strcpy(equipment_tmp,equip_delete(tmp_equipment,"91"));
            }
            strcpy(tmp_equipment, equipment_tmp);
            
            $UPDATE cm_esign_data  
                SET ipolicy2 = $plyn_1,
                    fstatus2 = '1',
                    iupdate = 'CAR3011-'||$userid,
                    dupdate = current
              WHERE iscan_no = $sIscan_no
                AND fstatus2 = '0';   
            if (sqlca.sqlerrd[2]==0)
            {
                sprintf_s(v_errMsg,sizeof v_errMsg,"�q�lñ�p��ƥD�ɧ�s����[%s]",sIscan_no);
                Update_car3011_temp(estimatei, itoa(type), sIleader, sIquota, sNquota, " ", " ", fout_print, feply_1, v_errMsg);
                return M_CA_ESIGN_UPD_ERR;
            }
        }    

        strcpy(tmp_dmg,iquery_num_damage);
        strcpy(tmp_lia,iquery_num);
        strcpy(tmp_iquery_num_unknown,iquery_num_unknown);

        tmp_lia_acc_sum = qlia_acc_sum;
        tmp_dmg_acc_sum = qdmg_acc_sum;
        tmp_qunknown_acc_sum = qunknown_acc_sum;

        /* car9903041 ���s�t�λP���O�B�ɨ�����s�� */
        strcpy( tmp_survey_num, survey_num);
        strcpy( tmp_bound_num, bound_num);

        tmp_psex_age_damage = psex_age_damage;

        strcpy(sIinkind_ply,"C2");

    }
    /*printf("---- 21489 iquery_num_c=[%s] tmp_lia=[%s]-\n",iquery_num_c,tmp_lia);*/
    printf("***** before insert policy, ply[%s] card[%s]\n",plyn_1,card);
    printf("***** before insert policy, user[%s] benefn[%s]\n",user,benefn);
    if(type==2)
    {
        if (fac == 'Y')
            facf[0]='P';
        else
            facf[0]=' ';
    }
    facf[1]='\0';

    if (treaty1[0]=='\0' || treaty1[0]==' ') return M_CA_TREATY_ERROR;

    /******* ���פj�O��_�帹�@�ߵ� 0 ,�j�O��C�L�ɦA�M�w�帹 ***/

    ibatch_no=0;

    tmp_ply[CAR_POLICY_LEN]='\0';
    pextra_charge = 0; /* �D�ɪ�pextra_charge�S����,�H�I�ة��Ӭ��� */

    if ( iroute_accept[0] == ' ' || iroute_accept[0] == '\0') strcpy( iroute_accept," ");
    if ( idm_number[0] == ' ' || idm_number[0] == '\0') strcpy( idm_number," ");
    if ( iroute_prop[0] == ' ' || iroute_prop[0] == '\0' || (strcmp(iroute_prop,"00") == 0))
        strcpy( iroute_prop, " ");
    
    /*������null*/
    if ( engine[0] == ' ' || engine[0] == '\0') strcpy( engine," "); 
    /*
    printf("fapplicant=[%s], fsex_appl=[%s], dbirth_appl=[%ld], itel_appl=[%s]\n", fapplicant, fsex_appl, dbirth_appl, itel_appl);
    printf("ndeputy_appl=[%s], nrelation_appl=[%s], ndeputy_assured=[%s]\n", ndeputy_appl, nrelation_appl, ndeputy_assured);
    */
    
    /*1090401001-SC1-��ã��-�s�W�����������X�u���J�b���ˮ�*/
    int ilen ;
    ilen=0;
    if (strlen(trim(engine))>0)
    {
        for(ilen=0 ; ilen<strlen(trim(engine)) ;ilen++)
        {
            if((unsigned) engine[ilen]<128)
            {          
            	/*�Ʀr*/               
            }
            else
            {    
                sprintf_s(v_errMsg,sizeof v_errMsg,"�������X�i%s�j���o�����ΩΤ���;",engine);
                Update_car3011_temp(estimatei, itoa(type), sIleader, sIquota, sNquota, " ", " ", fout_print, feply_1, v_errMsg);
                return M_CA_ESIGN_UPD_ERR;
            }
        }
    }

    if (strlen(trim(engine))==0 && strlen(trim(body))==0 )
    {
        sprintf_s(v_errMsg,sizeof v_errMsg,"�������X�Ψ������X�ҥ���J;",engine);
        Update_car3011_temp(estimatei, itoa(type), sIleader, sIquota, sNquota, " ", " ", fout_print, feply_1, v_errMsg);
        return M_CM_VALUE;
    }
    
    /*1090722004-SC1-���ά�-�Эק�������X�ˮ�(�r���Τ���)�O�����ӿ�J���Ÿ�*/
    if ((strstr(engine,",") != NULL )  || (strstr(engine,";") != NULL ) )
    {
        sprintf_s(v_errMsg,sizeof v_errMsg,"�������X�i%s�j���o���r���Τ���;",engine);
        Update_car3011_temp(estimatei, itoa(type), sIleader, sIquota, sNquota, " ", " ", fout_print, feply_1, v_errMsg);
        return M_CA_ESIGN_UPD_ERR;
    }
    
    ilen=0;
    if (strlen(trim(body))>0)
    {
        for(ilen=0 ; ilen<strlen(trim(body)) ;ilen++)
        {
           
            if((unsigned) body[ilen]<128)
            {          
            	/*�Ʀr*/               
            }
            else
            {    
                sprintf_s(v_errMsg,sizeof v_errMsg,"�������X�i%s�j���o�����ΩΤ���;",body);
                Update_car3011_temp(estimatei, itoa(type), sIleader, sIquota, sNquota, " ", " ", fout_print, feply_1, v_errMsg);
                return M_CA_ESIGN_UPD_ERR;
            }
        }
    } 
    
    if (type==2)
    {
        /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N��*/
        sprintf_s(sProvDelimiter,sizeof sProvDelimiter,"%s;",trim(provision));
        if((strstr(sProvDelimiter, "F;") != NULL) || (strstr(sProvDelimiter, "G;") != NULL) || (strstr(sProvDelimiter, "I;") != NULL))
        {
            if (dmg_acc_Insert ==1) pdmg_acc_main = pdmg_acc_ori;
            if (dmg_acc_Insert ==2) pdmg_acc_main = pdmg_acc_ori2;
            if (dmg_acc_Insert ==3) pdmg_acc_main = pdmg_acc_ori3;
        }
        /*printf("--pdmg_acc_main[%f]-- dmg_acc_Insert=[%d]\n",pdmg_acc_main,dmg_acc_Insert);*/
        tmp_pdmg_acc = pdmg_acc_main;
        tmp_dmg_acc_sum = qdmg_acc_sum_main;
        strcpy(tmp_dmg, iquery_num_damage_main);

        tmp_punknown_acc = punknown_acc_main;
        tmp_qunknown_acc_sum = qunknown_acc_sum_main;
        strcpy(tmp_iquery_num_unknown, iquery_num_unknown_main);

        if (strlen(tmp_iquery_num_unknown)==0) strcpy(tmp_iquery_num_unknown, " ");
        /*
        printf("--21820-- tmp_pdmg_acc=[%f]\n",tmp_pdmg_acc);
        printf("--21821-- tmp_dmg_acc_sum=[%d]\n",tmp_dmg_acc_sum);
        printf("--21822-- tmp_dmg=[%s]\n",tmp_dmg);

        printf("--21820-- tmp_pdmg_acc=[%f]\n",tmp_punknown_acc);
        printf("--21821-- tmp_qunknown_acc_sum=[%d]\n",tmp_qunknown_acc_sum);
        printf("--21822-- tmp_iquery_num_unknown=[%s]\n",tmp_iquery_num_unknown);
        printf("--21820-- punknown_acc=[%f]\n",punknown_acc);
        printf("--21820-- punknown_acc2=[%f]\n",punknown_acc2);
        */
    }

    /* 1090401006-SC1-���O���o�O�ť�*/
    if(strlen(trim(tmp_equipment)) != 30)
    {
        return M_CA_EQUIPMENT_CHECKED;
    }
        
    printf("---- 21524 iquery_num_c=[%s] tmp_lia=[%s]-\n",iquery_num_c,tmp_lia);
    /*  1060817004 �q�lñ�p��ƥD�ɦ^�g�O�渹�Ϊ��A�w�X��    */
    $INSERT INTO policy
        (ipolicy,icard,itag,ixxcard,iabn_type,
         iassured, iassured_ext, fassured,fcut,nassured,
         nuser,ibenef,nbenef,aassured, aassured_zip,
         apayment, apayment_zip, itel,iply_area,
         nbrand_abbr,ncar_abbr,
         fcar_note,qcylinder,iengine,ibody,fcal_way,ilicense,
         fsex,fmarriage,pdmg_align,pbrg_align,plia_align,ffac,dfac,
         fpass,ipass,dpass,mcar_price,nequipment,idmg_rate,pdmg_factor,
         ibrg_rate,pbrg_factor,qpt,fpt,psex_age,psex_age_damage,plia_acc,pdmg_acc,
         lia_class,dmg_acc_1st,dmg_acc_2nd,dmg_acc_3rd,
         fcomp_24,fhuman,iemail, iext_policy, qpro_month, mkilo_ply, irisk, irelative_ext,
         napplicant, dbirth, dissue,
         iextra_charge, gextra_charge, pextra_charge,
         iquery_num_damage, iquery_num, introducer, mequipment,
         survey_num, bound_num, abnormal_num, iapplicant, iroute_prop, iroute_accept, idm_number, iroute,
         qlia_acc_sum, qdmg_acc_sum,itel_night, mobil_phone,
         fapplicant, fsex_appl, dbirth_appl, itel_appl,
         ndeputy_appl, nrelation_appl, ndeputy_assured,ibound,isurvey,npost_recipient,apost_zip,apost_address,
         iins_kit,mcover_limit,iassured_cntry , iapplicant_cntry, nassured_cntry, napplicant_cntry,funknown_dmg,fcharge_type,
         fequipment1,fequipment2,fequipment3,fequipment4,fequipment5,fequipment6,fequipment9,nequipment9,
         punknown_acc,qunknown_acc_sum,iquery_num_unknown,tmobile_appl,aemail_appl,
         foccup,noccup,applicant_foccup,applicant_noccup)
     VALUES
        ($plyn_1,$card,$tagnum,$xxcard,$abn_type,
         $assuredi, $assuredi_ext, $assuredf,$cutf,
         $assuredn,$tmp_user,$tmp_benefi,$tmp_benefn,
         $assureda, $assureda_zip, $paymenta, $paymenta_zip,
         $tel,$ply_area,
         $brandn,$car_typen,$fcar_note,
         $cylinder,$engine,$body,$cal_way,$license,$sex,
         $marriage,$dmg_align,$brg_align,$lia_align,$facf,$facd,$passf,
         $passi,$passd,$car_price,$tmp_equipment,$idmg_rate,$dmg_factor,
         $ibrg_rate,$brg_factor,$qpt,$fpt,$psex_age,$tmp_psex_age_damage,$plia_acc,$tmp_pdmg_acc,
         $lia_class,$dmg_acc_1st,$dmg_acc_2nd,$dmg_acc_3rd,
         $fcomp_24,"1",$iemail, $iext_policy, $qpro_month, $mkilo_ply, $irisk, $irelative_ext,
         $napplicant, $dbirth, $dissue,
         $iextra_charge, $gextra_charge, $pextra_charge,
         $tmp_dmg, $tmp_lia, $introducer, $mequipment,
         $tmp_survey_num, $tmp_bound_num, $abnormal_num, $iapplicant, $iroute_prop, $iroute_accept, $idm_number, $iroute,
         $tmp_lia_acc_sum, $tmp_dmg_acc_sum,$tel_night , $mobil_phone,
         $fapplicant, $fsex_appl, $dbirth_appl, $itel_appl,
         $ndeputy_appl, $nrelation_appl, $ndeputy_assured,$ibound_x,$isurvey_x,$npost_recipient, $apost_zip, $apost_address,
         $iins_kit, $mcover_limit,$iassured_cntry , $iapplicant_cntry, $nassured_cntry, $napplicant_cntry,$funknown_dmg,$fcharge_type,
         $fequipment1,$fequipment2,$fequipment3,$fequipment4,$fequipment5,$fequipment6,$fequipment9,$nequipment9,
         $tmp_punknown_acc,$tmp_qunknown_acc_sum,$tmp_iquery_num_unknown, $tmobile_appl, $aemail_appl,
         $foccup,$noccup,$applicant_foccup,$applicant_noccup);

    $UPDATE ply_relation
        SET ibatch_no=$ibatch_no
      WHERE ipolicy=$plyn_1;

    /* 103.06.03 �O�渹�^�g�@�γ�������  (���O�X��) .... ���즹�B*/
    strcpy(sIinkind,itoa(type));
    printf("-- trace sIinkind[%s]\n ",sIinkind);

    iPlyCnt=0;
    strcpy(sply_begin,"");
    strcpy(sply_end,"");
    if (strlen(trim(engine))>0)
    {
        /*printf("-- trace engine[%s][%d]\n ",engine,strlen(trim(engine)));*/
        strcpy(sply_begin,cm_edate_str(ply_begin));
        strcpy(sply_end,cm_edate_str(ply_end));
        printf("ply_begin[%d], ply_end[%d]\nsply_begin[%s]sply_end[%s],\nbzfrom[%s],officer[%s]\n", ply_begin, ply_end,sply_begin,sply_end,bzfrom,officer);        
        /*  1090731009-SC1-���ά�-�ӤH���I�جd�֯ʥ��ﵽ���I
        �ҡB	���L�׬O�_����J���p�渹�A����j���I�γ���N�I����s�X��ɡC
        �A�B	�ˮ֭��w�O�o�q���Obzfrom��10�O�I�~�ȭ���40�����~�ȡF���]�t41�����~��(������O)�C
        ���B	���ˮ̷ֳs�O���ɤ��A�Y�s�b�P�@�޲z�HsIleader �B�Q�O�I�T��(�ۦP�������Xengine�A�ư��ťո��)�B�P�@�ͮĤ骺���īO��$ply_begin,$ply_end��ñ��F�p�S���A�h�i�H�����X��C
        �B�B	�Y�j���I��40�����~�ȡA���N�I��10�O�I�~�ȭ��q���A�Ҷq�j���I��w�ɦ�������O�u�f�A��O��(���e�渹)�H�������u�f����h�A��������CX���`��B�z�F�Y�Ϥ��A�j���I10���N�I��40�h�n�ˮ֡C
       
         �j��      ���N     �s  ��  �O�_���ˮ�
         40         40      0   1
         40         40      1   0
         40         10      0   1   
         40         10      1   0   V
         10         40      0   1   V
         10         40      1   0   V
         10         10      0   1
         10         10      1   0
        */      
        /*1091015007-SC1-���ά�-�Эק���s�w����O�渹�N�ǤJ�ˮ�(���N�αj��ݬ��ۦP�O�o�q��)  �����L��+�ݥ��h�O*/
        /*1100107004-SC1-���ά�-�ק�O�o�q��10��40�����O�h����j�γ��*/
        sprintf_s(stmt_buf,sizeof stmt_buf,
                "SELECT "
                "    (SELECT count(*) FROM newa00:ply_relation a, newa00:policy b ,newa00:ply_ins_type d "
                "      WHERE a.ipolicy = b.ipolicy  AND a.ipolicy = d.ipolicy "
                "        AND b.iengine ='%s'        AND d.mdamage_cover > 0 "
                "        AND a.dply_begin = '%s'    AND a.dply_end = '%s'  "
                "        AND a.bzfrom <> '%s' AND a.bzfrom in ('10','40')  "
                "        AND a.fcard_class != '%s' "
                "        AND a.ileader = c.ileader) + "
                "    (SELECT count(*) FROM newa22:ply_relation a, newa22:policy b ,newa22:ply_ins_type d "
                "      WHERE a.ipolicy = b.ipolicy  AND a.ipolicy = d.ipolicy "
                "        AND b.iengine ='%s'        AND d.mdamage_cover > 0 "
                "        AND a.dply_begin = '%s'    AND a.dply_end = '%s'  "
                "        AND a.bzfrom <> '%s' AND a.bzfrom in ('10','40')  "
                "        AND a.fcard_class != '%s' "
                "        AND a.ileader = c.ileader) + "
                "    (SELECT count(*) FROM newa33:ply_relation a, newa33:policy b ,newa33:ply_ins_type d "
                "      WHERE a.ipolicy = b.ipolicy  AND a.ipolicy = d.ipolicy "
                "        AND b.iengine ='%s'        AND d.mdamage_cover > 0 "
                "        AND a.dply_begin = '%s'    AND a.dply_end = '%s'  "
                "        AND a.bzfrom <> '%s' AND a.bzfrom in ('10','40')  "
                "        AND a.fcard_class != '%s' "
                "        AND a.ileader = c.ileader) + "
                "    (SELECT count(*) FROM newa40:ply_relation a, newa40:policy b ,newa40:ply_ins_type d "
                "      WHERE a.ipolicy = b.ipolicy  AND a.ipolicy = d.ipolicy "
                "        AND b.iengine ='%s'        AND d.mdamage_cover > 0 "
                "        AND a.dply_begin = '%s'    AND a.dply_end = '%s'  "
                "        AND a.bzfrom <> '%s' AND a.bzfrom in ('10','40')  "
                "        AND a.fcard_class != '%s' "
                "        AND a.ileader = c.ileader) + "
                "    (SELECT count(*) FROM newa66:ply_relation a, newa66:policy b ,newa66:ply_ins_type d "
                "      WHERE a.ipolicy = b.ipolicy  AND a.ipolicy = d.ipolicy "
                "        AND b.iengine ='%s'        AND d.mdamage_cover > 0 "
                "        AND a.dply_begin = '%s'    AND a.dply_end = '%s'  "
                "        AND a.bzfrom <> '%s' AND a.bzfrom in ('10','40')  "
                "        AND a.fcard_class != '%s' "
                "        AND a.ileader = c.ileader) + "
                "    (SELECT count(*) FROM newa70:ply_relation a, newa70:policy b ,newa70:ply_ins_type d "
                "      WHERE a.ipolicy = b.ipolicy  AND a.ipolicy = d.ipolicy "
                "        AND b.iengine ='%s'        AND d.mdamage_cover > 0 "
                "        AND a.dply_begin = '%s'    AND a.dply_end = '%s'  "
                "        AND a.bzfrom <> '%s' AND a.bzfrom in ('10','40')  "
                "        AND a.fcard_class != '%s' "
                "        AND a.ileader = c.ileader) "
                "  FROM officer c WHERE c.iofficer ='%s' ;"
                ,engine, sply_begin,sply_end,bzfrom,fc
                ,engine, sply_begin,sply_end,bzfrom,fc
                ,engine, sply_begin,sply_end,bzfrom,fc
                ,engine, sply_begin,sply_end,bzfrom,fc
                ,engine, sply_begin,sply_end,bzfrom,fc
                ,engine, sply_begin,sply_end,bzfrom,fc,officer);
                       
        /*printf("2-stmt[%s]\n",stmt_buf);*/
        $PREPARE get_cnt2 FROM $stmt_buf;
        $EXECUTE get_cnt2 INTO $iPlyCnt;    
        
    }
    printf("=====iPlyCnt[%d]=====\n",iPlyCnt);
    if (iPlyCnt>0)
    {
        
        if ((fc[0]=='1') && (strcmp(trim(bzfrom),"40")== 0))
        {
            /** �j���I��40�����~�ȡA���N�I��10�O�I�~�ȭ��q�� ���e�O�渹pp1 ���פU**/
            printf("���פUengine[%s], sply_begin[%s], sply_end[%s],bzfrom[%s],officer[%s]",engine, sply_begin,sply_end,bzfrom,officer);        
        }
        else
        {
            
            printf("===v_errMsg[%s]\n",v_errMsg);
            Update_car3011_temp(estimatei, itoa(type), sIleader, sIquota, sNquota, plyn_1, card, fout_print, feply_1, v_errMsg);
            return M_CA_BZFROM1_2_NOT_EQUAL;
        }
    }
    
    
    printf("-- trace fuw_status[%d]\n ",fuw_status);
    /* 104.02.03 try fix */
    if (fuw_status < 500)
    {
        /*  ���O�X��G�X����ɥ��֫O���ץ�,�b�X��ɦ۰ʶi��֫O�T�{�@�~�g�J�@�γ�������
                      �åB�^��������(�p�G������)���f�֪��A��550*/
        printf("=== Insert_Cm_pre_receive : estimatei=[%s]plyn_1=[%s]\n",estimatei,plyn_1);
        rc = Insert_Cm_pre_receive(estimatei,abn_type,plyn_1,ipre_rcv_ori);

    }
    else
    {
        printf("=== Update_Cm_pre_receive : estimatei=[%s]plyn_1=[%s]\n",estimatei,plyn_1);
        rc = Update_Cm_pre_receive(estimatei,plyn_1,sIinkind,fout_print,abn_type,ipre_rcv_ori);
    }
    printf("-- trace rc[%ld]\n ",rc);
    if( rc != SUCCESS)
    {
        if( rc == M_CA_NESTIMATE)
        {
            strcat(v_errMsg,"�t�Φ��L���A���楢�ѡI�Э��s����I");
            return M_CA_CHKRULE;
        }
        else
        {
            return rc;
        }
     }

    /* ��se�O���@�~���A */
    $UPDATE quotation_master
        SET icurrent_state = 700
      WHERE iquote = $estimatei
        AND iins_kind_ply = $sIinkind_ply;

    /* ---------------------- Insert cu_customer table ---------------------- */
    
    /*printf("entry[%s]\n",entry);*/
    long lTmp_date=0;
    if ((iRtnCode = rstrdate(cm_to_infdate(cm_cdate_str_100(dbirth)), &lTmp_date)) != 0)
        lTmp_date=0;
    iRtnCode = cu_add_customer_common_data(assuredi, sAssured_num_ext,
                                           sOpt_type, assuredf, assuredn, "", "", resource,
                                           sIcorps, marriage, lTmp_date, assureda, assureda_zip,
                                           tel, "", paymenta, paymenta_zip, "",
                                           officer, entry,iemail);
    if (iRtnCode != M_CM_OK) return iRtnCode;

    
    strcpy(iroute_accept, trim(iroute_accept));


    /*--------   104.07.30 �����I����ޱ�   --------
      �����I�������:
        8/15�بt�Τ��11/14  ��
        11/15�بt�Τ� �B  8/15�إͮĤ��11/14
      ==> ��O47��50�I�ت̡A������ update_ilast_ply
      ==> ����J��O�渹�̡A������ update_ilast_ply */

    icnt_105 = 0;

    if (icnt_105==0)
    {
        $EXECUTE PROCEDURE update_ilast_ply($plyn_1) INTO $i_rtn;
    }
    
    printf("g_frenew_type[%s]estimatei[%s]plyn_1[%s]\n",g_frenew_type,estimatei,plyn_1);
    
    /* 1120923005_C02 ���X�� */
    if (g_frenew_type[0]=='6' && fc[0]=='1')
    {
        $UPDATE ply_relation
            SET isign = 'system',     
                dapply= today
          WHERE ipolicy =$plyn_1      
            AND fcard_class ='1'     
            AND iscan_no =' ';	
    }
    
    if (g_frenew_type[0]=='6' && fc[0]=='2')
    {
        $UPDATE ply_relation
            SET fsign_status= 20,
                funder_chk='Y',
                isign = ' ',
                dapply=null
          WHERE ipolicy =$plyn_1      
            AND ((isign != 'system') 
            AND (trim(iscan_no) ='') 
            AND (ipolicy[1,3] not in ('000','020','225','336','401','667','702')) 
            AND (icar_type !='51') AND (icar_type !='CS')
            AND (ipolicy[6,7] !='VW')) ;	
    } 
    
    
    /*  1090803002-SC1-�ӽ�HCC�֫O�ҫ�   �]���妸�X���Ƥ����ܰ�  �ҥH���Ʀ]�l���|���� �����ۼg�L�ɧY�i �O���ͮĤ�j�󵥩�2021/01/01��ñ��
                                        ���q�����O��ʽ�G�ꤺ�۵M�H(�����O = 1)������01�B02�B03�B04�B22�B32�B34�B35 */
    if (assuredf[0]=='1' && ply_begin >= 44197 && 
        (strcmp(car_typei,"01") == 0 || strcmp(car_typei,"02") == 0 || strcmp(car_typei,"03") == 0 || 
         strcmp(car_typei,"04") == 0 || strcmp(car_typei,"22") == 0 || strcmp(car_typei,"32") == 0 || 
         strcmp(car_typei,"34") == 0 ))  /* 44197�Ĵ�=01/01/2021*/
    {
        printf("-----HCC--BEGIN--\n");
        if (g_frenew_type[0]=='9' || g_frenew_type[0]=='6')
        {
            /* ����֫O�� 17N -JB �� ���X��*/
            if ((strncmp(iroute,"BA27986706",10) == 0) && (fc[0]=='1'))
            {
                /* 1090916003-SC2-�����@-�I�߫O�N�����T�걵  �}��iroute=BA27986706 
                  �j���I�����g�JHCC 
                */
            }
            else
            {
                if ((fc[0]=='1') && strlen(trim(irelative_ply)) > 0)
                {
                    /* 1100524007-SC1-��౻T   JB �� �j+�� �u�O�����N      ��j�~�O���j��       
                       printf("JB �� �j+�� �u�O�����N\n");
                    */
                    
                }
                else if (fc[0]=='1' && ply_begin >= 45078)
                {
                    /*printf("�O��>=06/01/2023 ����j�A���B�z\n");*/
                }
                else
                {
                    printf("JB -->  ca_hcc_policy \n");
                    sprintf_s(stmt_buf,sizeof stmt_buf,
                    " INSERT INTO ca_hcc_policy "
                    " SELECT first 1 '%s' "
                    "       ,a.iquote,a.iroute_main,a.drate "
                    "       ,a.i1_sex_marriage_value,a.p1_sex_marriage_factor "
                    "       ,a.q2_age_value,a.p2_age_factor "
                    "       ,a.q3_dmg_acc_sum_5y_value,a.p3_dmg_acc_sum_5y_factor "
                    "       ,a.q4_lia_acc_sum_5y_value "
                    "       ,a.p4_lia_acc_sum_5y_factor,a.q5_duty_acc_sum_5y_value "
                    "       ,a.p5_duty_acc_sum_5y_factor "
                    "       ,a.q8_car_age_value,a.p8_car_age_factor "
                    "       ,a.f10_lia_value,a.p10_lia_factor "
                    "       ,a.f11_brg_value,a.p11_brg_factor "
                    "       ,a.q12_ext_ins_sum_value,a.p12_ext_ins_sum_factor "
                    "       ,a.i13_ply_area_value,a.p13_ply_area_factor "
                    "       ,a.i14_cartype_year_value,a.p14_cartype_year_factor "
                    "       ,a.f15_injure_value,a.p15_injure_factor "
                    "       ,a.q16_product_sum_value,a.p16_product_sum_factor "
                    "       ,a.q17_acc_sum_5y_value,a.p17_acc_sum_5y_factor "
                    "       ,a.f18_have_newa_c_2y_value,a.p18_have_newa_c_2y_factor "
                    "       ,a.i19_series_value,a.p19_series_factor "
                    "       ,a.q20_ext_ins_notdmg_value,a.p20_ext_ins_notdmg_factor "
                    "       ,a.q21_ext_ins_isdmg_value,a.p21_ext_ins_isdmg_factor "
                    "       ,a.pscore,a.qlevel,b.dfirst_ply,a.icreate,a.dcreate "
                    "   FROM ca_quotation_hcc a ,ca_quotation b ,quotation_master c "
                    "  WHERE a.iquote = b.iquote  "
                    "    AND a.iquote = c.iquote  "
                    "    AND c.iins_kind_ply = '%s' "
                    "    AND b.iquote = '%s' ; ",plyn_1,sIinkind_ply,estimatei);
                    $PREPARE HCC_cur FROM $stmt_buf;
                    $EXECUTE HCC_cur ;  
                    
                    
                    if (sqlca.sqlerrd[2]==0)
                    {
                        printf("==============�X�槹�����g�JHCC��������==========\n");
                        if (strstr(v_errMsg, ";�X�槹�����g�JHCC�������ѡA�гq���ӫO���C") == NULL)
                        {
                            strcat(v_errMsg, ";�X�槹�����g�JHCC�������ѡA�гq���ӫO���C");
                        }
                        Update_car3011_temp(estimatei, itoa(type), sIleader, sIquota, sNquota, plyn_1, card, fout_print, feply_1, v_errMsg);
                    }
                }
            }
        }
        else
        {
            
            /***��O���۰ʥX��� CR     ca_hcc_302.qins_set=0�G���O 1�G��ĳ      
                                        cm_pre_receive.isys=4.��O-���O 5.��O-��ĳ icont
                                        ***/
            if ((fc[0]=='1') )
            {
                if ((strncmp(iroute,"JB",2) != 0) )
                {
                    /*printf("�DJB���j��\n");
                    ��O�J�p�S����ƥi�ۼg
                    �]���i�DJB����j����HCC�j�B�i�j+���H���N�I��Ƭ��D���B�z�j���I�����j
                   */
                }
                else if(strncmp(iroute,"JB",2) == 0 && ply_begin >= 45078 )
                {
                    /*JB�q�����j��A�ͮĤ�06/01/2023�_�A����HCC*/
                }
                else
                {
                    if (strcmp(icont,"4") == 0)
                    {    
                        printf("��O-���O\n");
                        $INSERT INTO ca_hcc_policy
                         SELECT c.ipolicy1
                               ,c.ipre_rcv,a.iroute_main,a.drate
                               ,a.i1_sex_marriage_value,a.p1_sex_marriage_factor
                               ,a.q2_age_value,a.p2_age_factor
                               ,a.q3_dmg_acc_sum_5y_value,a.p3_dmg_acc_sum_5y_factor
                               ,a.q4_lia_acc_sum_5y_value
                               ,a.p4_lia_acc_sum_5y_factor,a.q5_duty_acc_sum_5y_value
                               ,a.p5_duty_acc_sum_5y_factor
                               ,a.q8_car_age_value,a.p8_car_age_factor
                               ,a.f10_lia_value,a.p10_lia_factor
                               ,a.f11_brg_value,a.p11_brg_factor
                               ,a.q12_ext_ins_sum_value,a.p12_ext_ins_sum_factor
                               ,a.i13_ply_area_value,a.p13_ply_area_factor
                               ,a.i14_cartype_year_value,a.p14_cartype_year_factor
                               ,a.f15_injure_value,a.p15_injure_factor
                               ,a.q16_product_sum_value,a.p16_product_sum_factor
                               ,a.q17_acc_sum_5y_value,a.p17_acc_sum_5y_factor
                               ,a.f18_have_newa_c_2y_value,a.p18_have_newa_c_2y_factor
                               ,a.i19_series_value,a.p19_series_factor
                               ,a.q20_ext_ins_notdmg_value,a.p20_ext_ins_notdmg_factor
                               ,a.q21_ext_ins_isdmg_value,a.p21_ext_ins_isdmg_factor
                               ,a.pscore,a.qlevel,b.dfirst_ply,a.icreate,a.dcreate
                           FROM ca_hcc_302 a ,policy_302 b ,cm_pre_receive c
                          WHERE a.ipolicy = b.ipolicy 
                            AND a.qins_set = 0
                            AND c.ipre_rcv = b.iestimate_ori
                            AND c.iins_kind_ply = $sIinkind_ply
                            AND c.ipre_rcv = $estimatei;
                    }
                    else
                    {
                        printf("5.��O-��ĳ\n");
                        $INSERT INTO ca_hcc_policy
                         SELECT c.ipolicy1
                               ,c.ipre_rcv,a.iroute_main,a.drate
                               ,a.i1_sex_marriage_value,a.p1_sex_marriage_factor
                               ,a.q2_age_value,a.p2_age_factor
                               ,a.q3_dmg_acc_sum_5y_value,a.p3_dmg_acc_sum_5y_factor
                               ,a.q4_lia_acc_sum_5y_value
                               ,a.p4_lia_acc_sum_5y_factor,a.q5_duty_acc_sum_5y_value
                               ,a.p5_duty_acc_sum_5y_factor
                               ,a.q8_car_age_value,a.p8_car_age_factor
                               ,a.f10_lia_value,a.p10_lia_factor
                               ,a.f11_brg_value,a.p11_brg_factor
                               ,a.q12_ext_ins_sum_value,a.p12_ext_ins_sum_factor
                               ,a.i13_ply_area_value,a.p13_ply_area_factor
                               ,a.i14_cartype_year_value,a.p14_cartype_year_factor
                               ,a.f15_injure_value,a.p15_injure_factor
                               ,a.q16_product_sum_value,a.p16_product_sum_factor
                               ,a.q17_acc_sum_5y_value,a.p17_acc_sum_5y_factor
                               ,a.f18_have_newa_c_2y_value,a.p18_have_newa_c_2y_factor
                               ,a.i19_series_value,a.p19_series_factor
                               ,a.q20_ext_ins_notdmg_value,a.p20_ext_ins_notdmg_factor
                               ,a.q21_ext_ins_isdmg_value,a.p21_ext_ins_isdmg_factor
                               ,a.pscore,a.qlevel,b.dfirst_ply,a.icreate,a.dcreate
                           FROM ca_hcc_302 a ,policy_302 b ,cm_pre_receive c
                          WHERE a.ipolicy = b.ipolicy 
                            AND a.qins_set = 1
                            AND c.ipre_rcv = b.iestimate_sug
                            AND c.iins_kind_ply = $sIinkind_ply
                            AND c.ipre_rcv = $estimatei;
                    }
                    
                    if (sqlca.sqlerrd[2]==0)
                    {
                        printf("#####################�X�槹�����g�JHCC��������#####################\n");
                        if (strstr(v_errMsg, ";�X�槹�����g�JHCC�������ѡA�гq���ӫO���C") == NULL)
                        {
                            strcat(v_errMsg, ";�X�槹�����g�JHCC�������ѡA�гq���ӫO���C");
                        }
                        Update_car3011_temp(estimatei, itoa(type), sIleader, sIquota, sNquota, plyn_1, card, fout_print, feply_1, v_errMsg);
                    }                               
                }
            }
            else
            {
                
                if (strcmp(icont,"4") == 0)
                {    
                    printf("��O-���O\n");
                    $INSERT INTO ca_hcc_policy
                     SELECT c.ipolicy1
                           ,c.ipre_rcv,a.iroute_main,a.drate
                           ,a.i1_sex_marriage_value,a.p1_sex_marriage_factor
                           ,a.q2_age_value,a.p2_age_factor
                           ,a.q3_dmg_acc_sum_5y_value,a.p3_dmg_acc_sum_5y_factor
                           ,a.q4_lia_acc_sum_5y_value
                           ,a.p4_lia_acc_sum_5y_factor,a.q5_duty_acc_sum_5y_value
                           ,a.p5_duty_acc_sum_5y_factor
                           ,a.q8_car_age_value,a.p8_car_age_factor
                           ,a.f10_lia_value,a.p10_lia_factor
                           ,a.f11_brg_value,a.p11_brg_factor
                           ,a.q12_ext_ins_sum_value,a.p12_ext_ins_sum_factor
                           ,a.i13_ply_area_value,a.p13_ply_area_factor
                           ,a.i14_cartype_year_value,a.p14_cartype_year_factor
                           ,a.f15_injure_value,a.p15_injure_factor
                           ,a.q16_product_sum_value,a.p16_product_sum_factor
                           ,a.q17_acc_sum_5y_value,a.p17_acc_sum_5y_factor
                           ,a.f18_have_newa_c_2y_value,a.p18_have_newa_c_2y_factor
                           ,a.i19_series_value,a.p19_series_factor
                           ,a.q20_ext_ins_notdmg_value,a.p20_ext_ins_notdmg_factor
                           ,a.q21_ext_ins_isdmg_value,a.p21_ext_ins_isdmg_factor
                           ,a.pscore,a.qlevel,b.dfirst_ply,a.icreate,a.dcreate
                       FROM ca_hcc_302 a ,policy_302 b ,cm_pre_receive c
                      WHERE a.ipolicy = b.ipolicy 
                        AND a.qins_set = 0
                        AND c.ipre_rcv = b.iestimate_ori
                        AND c.iins_kind_ply = $sIinkind_ply
                        AND c.ipre_rcv = $estimatei;
                }
                else
                {
                    printf("5.��O-��ĳ\n");
                    $INSERT INTO ca_hcc_policy
                     SELECT c.ipolicy1
                           ,c.ipre_rcv,a.iroute_main,a.drate
                           ,a.i1_sex_marriage_value,a.p1_sex_marriage_factor
                           ,a.q2_age_value,a.p2_age_factor
                           ,a.q3_dmg_acc_sum_5y_value,a.p3_dmg_acc_sum_5y_factor
                           ,a.q4_lia_acc_sum_5y_value
                           ,a.p4_lia_acc_sum_5y_factor,a.q5_duty_acc_sum_5y_value
                           ,a.p5_duty_acc_sum_5y_factor
                           ,a.q8_car_age_value,a.p8_car_age_factor
                           ,a.f10_lia_value,a.p10_lia_factor
                           ,a.f11_brg_value,a.p11_brg_factor
                           ,a.q12_ext_ins_sum_value,a.p12_ext_ins_sum_factor
                           ,a.i13_ply_area_value,a.p13_ply_area_factor
                           ,a.i14_cartype_year_value,a.p14_cartype_year_factor
                           ,a.f15_injure_value,a.p15_injure_factor
                           ,a.q16_product_sum_value,a.p16_product_sum_factor
                           ,a.q17_acc_sum_5y_value,a.p17_acc_sum_5y_factor
                           ,a.f18_have_newa_c_2y_value,a.p18_have_newa_c_2y_factor
                           ,a.i19_series_value,a.p19_series_factor
                           ,a.q20_ext_ins_notdmg_value,a.p20_ext_ins_notdmg_factor
                           ,a.q21_ext_ins_isdmg_value,a.p21_ext_ins_isdmg_factor
                           ,a.pscore,a.qlevel,b.dfirst_ply,a.icreate,a.dcreate
                       FROM ca_hcc_302 a ,policy_302 b ,cm_pre_receive c
                      WHERE a.ipolicy = b.ipolicy 
                        AND a.qins_set = 1
                        AND c.ipre_rcv = b.iestimate_sug
                        AND c.iins_kind_ply = $sIinkind_ply
                        AND c.ipre_rcv = $estimatei;
                }
                if (sqlca.sqlerrd[2]==0)
                {
                    printf("#####################�X�槹�����g�JHCC��������#####################\n");
                    if (strstr(v_errMsg, ";�X�槹�����g�JHCC�������ѡA�гq���ӫO���C") == NULL)
                    {
                        strcat(v_errMsg, ";�X�槹�����g�JHCC�������ѡA�гq���ӫO���C");
                    }
                    Update_car3011_temp(estimatei, itoa(type), sIleader, sIquota, sNquota, plyn_1, card, fout_print, feply_1, v_errMsg);
                }
            }

        } 
           
        /* 1100322001-SC1-���ʱo-�w��S���Y�Ƭd�ߧǸ���ñ��A�s�W�q���ҲեN��ALL99JB99  */
        if (strlen(trim(tmp_dmg)) < 10 && strlen(trim(tmp_lia)) <10 && strlen(trim(tmp_iquery_num_unknown)) <10)
        {
            /* ���S���d�ߧǸ� ���ܨS���d�����T */
            $UPDATE ca_hcc_policy
                SET iroute_main = trim(iroute_main)||'99'
              WHERE ipolicy = $plyn_1
                AND itmp_policy = $estimatei;  
        }
        printf("-----HCC--END--\n");
    }
    
    printf("estimatei[%s]itoa(type)[%s]plyn_1[%s]\n,",estimatei,itoa(type),plyn_1,card);
    printf("card[%s]fout_print[%s]feply_1[%s]\n,",card,fout_print,feply_1);
    printf("v_errMsg[%s]\n",v_errMsg);
    
    Update_car3011_temp(estimatei, itoa(type), sIleader, sIquota, sNquota, plyn_1, card, fout_print, feply_1, v_errMsg);

    return SUCCESS;

ip_step1x_err:
    printf("ip_step1x_err:sqlerrcode=%ld, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    code=SQLCODE;
    sprintf_s(v_errMsg,sizeof v_errMsg,"InsertPly_Step1x()���~:SQLCODE=[%d]sqlca.sqlerrm=[%s],sqlca.sqlerrd[1]=[%d]", SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);    
    $WHENEVER SQLERROR CONTINUE;
    return code;
}


static int Cal_ins_premium(INS_ptr,mode,wk_date,INS_ptr_33,INS_ptr_48,INS_ptr_35,INS_ptr_56)
struct INS_TYPE *INS_ptr;
struct INS_TYPE_33 *INS_ptr_33, *INS_ptr_48, *INS_ptr_35, *INS_ptr_56;
int    mode;
$long  wk_date;
{
    $int    iTmp;
    int     code, flag_car, flag_dam, flag_person;
    $char   stmt[2048];
    $char   fcal_way[2], fins_grp[2], ical_ins[INSURANCE_TYPE];
    $char   isame_ins[INSURANCE_TYPE], fcal_class[2];
    $char   frate[5], iyear[2];
    $char   fagent[2];
    $char   FullDBName_rel[20];
    $char   Tmp_policy1[21];
    $char   Tmp_xxcard[21];
    $char   Tmp_policy2[21];
    $char   FullDBName_xxcard[20];
    $char   iins_scope_tmp[2], icareer_tmp[2];
    $date   max_drate=DATENULL;
    char    TMP_MSG[200];
    long    org_ins_premium;
    long    pprice;
    double  fprice;
    long    lMins_amt_33;
    $long   lMins_amt_48;
    $long   lMins_amt_35;
    $long   lMins_amt_56;
    $double cal_pagent,cal_pcommission,cal_pdiscount;
    $double lTmp_mbusiness;
    $long   cal_prem;
    $double prate_icareer, prate_add_med;

    $char   tmp_ipaid_base[3], ibroker_24[11];
    $long   prem_47_2; /** 47�I�زĤG�~�`�O�O **/

    /* �p��j��s�O�O */
    $char    car_type_24[3], fassured_24[2], drate_ym_24[5];
    $date    dply_begin_24 , dply_end_24;
    $long    qply_period_24;
    $char    ipro_year_24[5], ibrand_24[9];
    $double  qpt_24, psex_age_24, plia_acc_24;
    $char    fcar_class_24[2];
    $char    fuse_type_24[2];
    $long    LngDummy_24 = 0;
    $double  DblDummy_24 = 0.00;
    $double  mbusiness_24 = 0.00;
    $char    StrDummy_24[2];
    $long    Tmp_mlia_prem, insurance_cover_count;
    $char    sIofficer24[11], sIroute24[21], sIrate_type24[2], sBzfrom24[3],
             sIroute_comm24[4], sIcomm_obj24[11], sFstart24[2], sFauth[2];
    $long    LngMexpensePrem;    /* ���[�N�B��ñ��O�O */
    $long    LngMexpensePremOri; /* ���[�N�B���W���O�O */
    $long    LngMexpenseDisc;    /* ���[�N�B���u�f�O�O */
    $long    LngQday;
    $double  prate_dailypay, prate_mprem, cal_mr_pure_prem, msi_premium;
    $long    lDaily_pay_33, lDaily_pay_48, lDaily_pay_56;
    char     cal_deduct_c[21];
    $char    cal_itype_disc[2];
    double   cal_mdiscount;
    $double   t_car_price, t_mcar_price;
    char     CompanyId[3];
    $long    tmp_mdeduct, estPremium1, estPremium2;
    $char    max_rate[6];
    $char    sCCC1[101], sCCC2[101], sCCC3[101];
    double   rCCC1, rCCC2, rCCC3;
    double   rChk_12_prem;
    $double  mpure;
    $char    carteam[20], sNcode[2];
    $int     Ireject_count;    /* �ˮ`�I�W�U�tOTH�ګO�Ȥ�ƶq add by sylvia 100.10.13 (0991216002_C1) */
    /* 57,59,60 �I�بϥ� add by sylvia */
    $double  ins_premium1,ins_premium2,bef_ins_premium1, bef_ins_premium2,
             mpure_prem_n1, mpure_prem_n2;
    /* 38,39 �I�بϥΡ@*/
    $int  iCar_age;
    $char sIcode[2];
    char stmp_dpolicy[2];
    $char  tm1020131[1000];
    $double pDeduct_rate; /* 131�B 132�I�ۭt�B����v */
    $double pcar_price;
    $char chk_provision[7];/*  1081225006-SC1-���ά�-�X�R���[���ڥN�X 6 �X*/
    $char sProvDelimiter[22];    /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X  �����ɤW��������*/
    $char sIofficerChar[2];/* 1081018008-SC2-�ū\��-�s�W���M(�˥�)�ѵs�I��O�X��@�~�έק�B����O�J�p���� L*B*/
    $char  sProYM[11]; /*1100119001-SC1-���ά�-�s�W-�s�ӫ~238�I-�D���ϴ��O�Ϊ��[����*/
    $long  lProYM;/*1100119001-SC1-���ά�-�s�W-�s�ӫ~238�I-�D���ϴ��O�Ϊ��[����*/
    $double pmequipment_rate = 0.0; /* 1130827011_C02_�s�W�s�t��W�B���[����(Y)�A�Щ�11/1�W�u */
    lProYM =0;
    strcpy(sProYM,"");
    
    int iSrate;/* 1061026002 ��89�O�v�̡A�����O�o���m��600�U�۰ʪ��[S����*/
    
    $double dbl_psex_age=1.0;/* 1090812005-SC1-���ά�-�s�W�s�ӫ~-�T�����B���郞�I���l���O�I198�I*/
    
    carteam[0] = '\0';

    printf("INTO Cal_ins_prem()\n");

    mdmg_prem       = mlia_prem       = 0;
    mdmg_pure_prem  = mlia_pure_prem  = 0;
    mdmg_discount   = mlia_discount   = 0;
    mdmg_agent      = mdmg_commission = 0;
    mlia_agent      = mlia_commission = 0;
    premium_3132    = 0;
    premium_3132_n  = 0; /*1030523002_C1*/
    damage_cover_01 = 0;
    flag_car        = 0;
    disc_last       = 0;
    mpremium_sec    = 0;

    Ireject_count = 0;
    mcover1_32 = 0;
    mcover1_31 = 0;
    ins_premium31 = 0;
    mcover1_626364=0;
    strcpy(stmp_dpolicy, " ");
    dbl_pcar_price_01 = 1.0;

    rc = getCompanyId(CompanyId);
    if (rc < 0)
        return rc;

    if (*fuse_type=='1') /*** �ȳf��ε��O 1:�O 2:�_ ***/
    {
        if (strcmp(fcar_note2,"98")==0)     /*** 98:�f�� ***/
            strcpy(cal_car_id,"04");
        else if(strcmp(fcar_note2,"99")==0) /*** 99:�Ȩ� ***/
            strcpy(cal_car_id,"03");
    }

    /**************************************/
    printf("Cal_ins_prem()####### �p�⨮�� cal_car_id[%s]\n",cal_car_id);

    /**************************************/
    /* 1130827011_C02_�s�W�s�t��W�B���[����(Y)�A�Щ�11/1�W�u */
    /* �t�ƪ��B / ���m����(�������t�ƪ��B) */
    pmequipment_rate = 0.0;
    printf("mequipment[%f]car_price[%f]\n",mequipment,car_price);
    if(mequipment > 0)
    {
    	pmequipment_rate = d45((mequipment/(car_price - mequipment)),4);
    }
    printf("pmequipment_rate[%f]\n",pmequipment_rate);
    
    /********** Scan through every iins_type ***************/
    INS_ptr      = Ifirst;
    bef_premium  = 0;
    pure_premium = 0;
    dbl_ProK_main_dmg = 1; /* 1080408008-SC1-��ã��-98������09+K*/
    dbl_ProF_main_dmg = 0;
    dbl_ProF_main_brg = 0;
    dbl_ProF_main_lia = 0;
    irate_ProF_main_dmg = 0;
    irate_ProF_main_brg = 0;
    irate_ProF_main_lia = 0;
    printf("Ifirst[%s]\n",Ifirst);
    
    while (INS_ptr)
    {
        /*printf("\n\n\nCal_ins_prem()####### ------- IINS_TYPE [%s]\n",INS_ptr->ins_type);
        printf("Cal_ins_prem()####### ------- provision[%s]\n",INS_ptr->provision);
        printf("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^INS_ptr->pdiscount[%f]\n", INS_ptr->pdiscount);*/

        if (strcmp(trim(INS_ptr->ins_type),"**")==0)
        {
            INS_ptr = INS_ptr->next;
            continue;
        }

        strcpy(ins_type , trim(INS_ptr->ins_type));
        strcpy(cal_itype_disc, trim(INS_ptr->itype_disc));
        /*
        printf("\n------- paid_base ---\n");
        printf("paid_base = [%s]\n", trim(INS_ptr->ipaid_base));
        printf("frate     = [%s]\n", trim(INS_ptr->frate));
        printf("drate_ym  = [%s]\n", trim(INS_ptr->drate_ym));
        */
        iins            = atoi(rtrim(ins_type));
        cal_deduct      = 0;
        cal_deduct      = INS_ptr->deduct;

        org_ins_premium = INS_ptr->ins_premium;  /* �O�����`�O�O */

        /*printf("org_ins_premium[%d]\n", org_ins_premium);*/

        strcpy(tmp_ipaid_base    , trim(INS_ptr->ipaid_base));
        strcpy(tmp_provision     , trim(INS_ptr->provision));

        /******************************/
        /* �ˮ֥��N�I�����N�z���u�f�v */
        /******************************/
        /*printf("check_est_cal_prem[%d]\n",check_est_cal_prem);
        printf("broker2[%s]\n",broker2);*/
        if (check_est_cal_prem == 1)  
        {
            /* �պ⤧�O�O�p�⤣�ˮ� */
            printf("Do not check check_broker_commi_agent[]\n");
        }
        else
        {
            if ((strcmp(trim(broker2),"") != 0) || (strcmp(trim(icomm_obj2),"") != 0))
            {    
                /* �t�X�q���ĤG���q check_broker_commi_agent �s�W�Ѽ� */
                /* �t�X��椣�ˮֳq�����v, �T�w�ǫO�����O=P(�O��) modify by sylvia 101.02.07 */
                if (check_broker_commi_agent(broker2, car_typei2, ins_type,
                                             INS_ptr->pcommission,
                                             INS_ptr->pagent,
                                             INS_ptr->pdiscount,
                                             resource,
                                             ply2_period,
                                             INS_ptr->mdiscount, haveF, INS_ptr->frate,
                                             fstart2, officer2, iroute, irate_type2, iroute_comm2, icomm_obj2, "P") != M_CM_OK)
                {
                    return M_CA_BROKER_ERROR;
                }
            }
        }
        
        /*-------------------------------------------------------------------*/
        /*** �O�O�p���k[fcal_way] : 1�O�v��   2�O�B�O�O��                ***/
        /*** �ۭt�B�O[fdeduct]      : 1���ۭt�B 0�L�ۭt�B                  ***/
        /*** �l���d���O[fins_grp]   : 1���l�I   2���d�I   3�j��d���I      ***/
        /*** �P�I�N��[isame_ins] , �C�L�Ǹ�[qserial] , �O�B�Ӽ�[qcoverage] ***/
        /*-------------------------------------------------------------------*/
        printf("==================== Cal_ins_premium ===========\n");

        $SELECT fcal_way,  isame_ins,  qserial,  qcoverage,  fdeduct,  fins_grp
           INTO $fcal_way, $isame_ins, $qserial, $qcoverage, $fdeduct, $fins_grp
           FROM insurance_type
          WHERE iins_type = $ins_type;
        if (NOT_FOUND)  return M_CA_NINS_TYPE;

        insurance_cover_count = 0;

        #ifdef CA_CONS
        $SELECT COUNT(*)
           INTO $insurance_cover_count
           FROM insurance_cover
          WHERE iins_type = $ins_type;
        #endif

        printf("fcal_way[%s],ins_type[%s],mode[%d]\n",fcal_way,ins_type,mode);

        strcpy(frate,INS_ptr->frate);
        strcpy(frate,trim(frate));
      

        printf("cal_deduct[%d] ���N�I�O�v�ͮĥN��==>frate[%s]\n",cal_deduct,frate);

        /**** �ˮֶO�v�ͮĥN���O�_�s�b ****/
        $SELECT drate
           FROM ca_rate_date
          WHERE icode  = $frate
            AND itable = 'ca_car_model';

        if (NOT_FOUND)  return M_CA_NRATE_DATE;

        printf("�쨮��mcar_price[%lf],�s�ʨ���car_price[%lf]\n",mcar_price,car_price);

        /***************************************************************/
        /************** ��������I���ѵs�I�O�v�N���ΫY�� ***************/
        /***************************************************************/
        if (ply2f==TRUE)  /**** ���N�I ****/
        {
            /***** ���j���� fcar_class[�ۥ���~���O1:�ۥΨ� 2:��~��] *****/
            /***** car_typei2 ����03[�ۤp��] 04[�ۤp�f] 19[���p�f] 21[�����p�Ȩ�] 22[�ȳf��] *****/
            /***** car_typei2 ����07[��p��] 08[��p�f] 14[����p�Ȩ�] 15[�p�e��] *****/

            strcpy(cal_pro_year," " );    strcpy(idmg_rate," " );
            strcpy(ibrg_rate," " );    brg_factor = 0;  dmg_factor = 0;
            /*1040202006_C1 �s�W���ؤ���~�����²v�վ�*/
            if ((fcar_class2[0]=='1' &&
                (strcmp(car_typei2,"03")==0 || strcmp(car_typei2,"04")==0   ||
                 strcmp(car_typei2,"19")==0 || strcmp(car_typei2,"21")==0   ||
                 strcmp(car_typei2,"22")==0 || (ISNEW_CAR1(car_typei2)) )) ||
                (fcar_class2[0]=='2' &&
                (strcmp(car_typei2,"07")==0 || strcmp(car_typei2,"08")==0 ||
                 strcmp(car_typei2,"14")==0 || strcmp(car_typei2,"15")==0 || (ISNEW_CAR2(car_typei2)) ))
                )
            {
                printf("<<<<���j����>>>frate[%s]\n",frate);
                printf("�����I���ѵs�I�O�v�N�� \n");

                cal_pro_year[0] = '\0';
                idmg_rate[0]    = '\0';
                ibrg_rate[0]    = '\0';

                /*************** 1.��������I���ѵs�I�O�v�N�� *****************/
                /*printf("Select From ca_car_model where ipro_year = [%s] and brand = [%s]\n", pro_year, brandi);*/

                /* 104.09.09 fix ca_car_model �^���޿� */
                /* car9812112_C1 �t�P�����ɷs�W���Τ� modify by sylvia 100.09.21 */
                $SELECT idmg_rate  , ibrg_rate  , ipro_year
                   INTO $idmg_rate , $ibrg_rate , $cal_pro_year
                   FROM ca_car_model
                  WHERE ibrand    = $brandi
                    AND ipro_year = $pro_year
                    AND (dexpire is null or dexpire > today)
                    AND drate     = (SELECT drate
                                       FROM ca_rate_date
                                      WHERE icode  = $frate
                                        AND itable = 'ca_car_model');
                if(NOT_FOUND)
                {
                    $DECLARE CA_OPT11 CURSOR FOR
                      SELECT idmg_rate  , ibrg_rate  , ipro_year
                        INTO $idmg_rate , $ibrg_rate , $cal_pro_year
                        FROM ca_car_model
                       WHERE ibrand    = $brandi
                         AND ipro_year < $pro_year
                         AND (dexpire is null or dexpire > today)
                         AND drate     = (SELECT drate
                                            FROM ca_rate_date
                                           WHERE icode  = $frate
                                             AND itable = 'ca_car_model')
                       ORDER BY ipro_year DESC;
                    $OPEN  CA_OPT11;
                    $FETCH CA_OPT11;

                    if (NOT_FOUND)
                    {
                        $DECLARE CA_OPT11_1 CURSOR FOR
                          SELECT idmg_rate  , ibrg_rate  , ipro_year
                            INTO $idmg_rate , $ibrg_rate , $cal_pro_year
                            FROM ca_car_model
                           WHERE ibrand    = $brandi
                             AND ipro_year > $pro_year
                             AND (dexpire is null or dexpire > today)
                             AND drate     = (SELECT drate
                                                 FROM ca_rate_date
                                                WHERE icode  = $frate
                                                  AND itable = 'ca_car_model')
                            ORDER BY ipro_year ;
                        $OPEN  CA_OPT11_1;
                        $FETCH CA_OPT11_1;

                        if (NOT_FOUND)
                        {
                            $CLOSE CA_OPT11_1;
                            $FREE  CA_OPT11_1;
                            return M_CA_NBRAND;
                        }
                        $CLOSE CA_OPT11_1;
                        $FREE CA_OPT11_1;
                    }
                    $CLOSE CA_OPT11;
                    $FREE  CA_OPT11;
                }
                /***************************************************************/
                /***************************************************************/

                /**** �����I�O�v�N���Y�� ****/
                $SELECT pfactor
                   INTO $dmg_factor
                   FROM car_model_factor
                  WHERE fdmg_brg  = '1'
                    AND irate     = $idmg_rate
                    AND ipro_year = $pro_year
                    AND drate     = (SELECT drate
                                       FROM ca_rate_date
                                      WHERE icode  = $frate
                                        AND itable = 'car_model_factor');

                if (NOT_FOUND)
                {
                    $DECLARE CA_OPT11_2 CURSOR FOR
                      SELECT pfactor    
                        INTO $dmg_factor
                        FROM car_model_factor
                       WHERE fdmg_brg  = '1'
                         AND irate     = $idmg_rate
                         AND ipro_year > $pro_year
                         AND drate     = (SELECT drate
                                            FROM ca_rate_date
                                           WHERE icode  = $frate
                                             AND itable = 'car_model_factor')
                       ORDER BY ipro_year;

                    $OPEN  CA_OPT11_2;
                    $FETCH CA_OPT11_2;
                    if (NOT_FOUND)
                    {
                         $CLOSE CA_OPT11_2;
                         $FREE  CA_OPT11_2;
                         return M_CA_NCAR_MODEL_FACTOR;
                    }
                    $CLOSE CA_OPT11_2;
                    $FREE CA_OPT11_2;
                }

                /************* 2.���ѵs�O�v�N������ѵs�I�O�v�N���Y�� **************/
                $SELECT pfactor
                   INTO $brg_factor
                   FROM car_model_factor
                  WHERE fdmg_brg  = '2'
                    AND irate     = $ibrg_rate
                    AND ipro_year = $pro_year
                    AND drate     = (SELECT drate
                                       FROM ca_rate_date
                                      WHERE icode  = $frate
                                        AND itable = 'car_model_factor');

                if (NOT_FOUND)
                {
                    $DECLARE CA_OPT21_2 CURSOR FOR
                      SELECT pfactor     , ipro_year
                        INTO $brg_factor
                        FROM car_model_factor
                       WHERE fdmg_brg  = '2'
                         AND irate     = $ibrg_rate
                         AND ipro_year > $pro_year
                         AND drate     = (SELECT drate
                                            FROM ca_rate_date
                                            WHERE icode  = $frate
                                              AND itable = 'car_model_factor')
                       ORDER BY ipro_year;

                    $OPEN  CA_OPT21_2;
                    $FETCH CA_OPT21_2;
                    if (NOT_FOUND)
                    {
                        $CLOSE CA_OPT21_2;
                        $FREE  CA_OPT21_2;
                        return M_CA_NCAR_MODEL_FACTOR;
                    }
                    $CLOSE CA_OPT21_2;
                    $FREE CA_OPT21_2;
                }
                printf("pro_year[%s],cal_pro_year[%s],idmg_rate[%s],dmg_factor[%f],brg_factor[%f]\n", pro_year ,cal_pro_year ,idmg_rate ,dmg_factor  ,brg_factor);
                 
            }
            else
            {
                /**** ��L���� ****/
                dmg_factor = bb11;
                brg_factor = bb12;
            }
        }
        /******************�[�˳]��**********************/
        t_car_price = car_price * 10000;
        t_mcar_price = mcar_price * 10000;

        if((t_car_price-t_mcar_price)<=0)
            fprice=(((t_car_price-t_mcar_price)*100/t_mcar_price));
        else
            fprice=(((t_car_price-t_mcar_price)*100/t_mcar_price));

        /*printf("fprice[%f],idmg_rate[%s]\n",fprice,idmg_rate);*/

        /* car9905052 �����I�����O�v�N���վ� add by sylvia 101.03.12 (1001206008_C1)
           �HŪ�� car_code �]�w��, ���O16, �Ҩ��o�����(detail)�@�ϧO
           �O�v�ͮĤ� >= car_code �]�w, ���վ�O�v�N��
           �O�v�ͮĤ� < car_code �]�w, �����վ�O�v�N��                             */
        
        sprintf_s(idmg_rate,sizeof idmg_rate,"%02d",atoi(idmg_rate));
        
        /*printf("fprice[%f],idmg_rate[%s]\n",fprice,idmg_rate);*/

        if(fprice>=10)
        {
            printf("fprice >= 10 \n");
            if (ply2f==TRUE)  /**** ���N�I ****/
            {
                /*1040202006_C1 �s�W���ؤ���~�����²v�վ�*/
                /***** ���j���� *****/
                if ((fcar_class2[0]=='1' &&
                    (strcmp(car_typei2,"03")==0 || strcmp(car_typei2,"04")==0   ||
                     strcmp(car_typei2,"19")==0 || strcmp(car_typei2,"21")==0   ||
                     strcmp(car_typei2,"22")==0 || (ISNEW_CAR1(car_typei2)) )) ||
                    (fcar_class2[0]=='2' &&
                    (strcmp(car_typei2,"07")==0 || strcmp(car_typei2,"08")==0 ||
                     strcmp(car_typei2,"14")==0 || strcmp(car_typei2,"15")==0 || (ISNEW_CAR2(car_typei2))))
                   )
                {
                    /**** �����I�O�v�N���Y�� ****/
                    dmg_factor = 0;
                    $SELECT pfactor
                       INTO $dmg_factor
                       FROM car_model_factor
                      WHERE fdmg_brg  = '1'
                        AND irate     = $idmg_rate
                        AND ipro_year = $pro_year
                        AND drate     = (SELECT drate
                                           FROM ca_rate_date
                                          WHERE icode  = $frate
                                            AND itable = 'car_model_factor');

                    if (NOT_FOUND)
                    {
                        $DECLARE CA_OPT11_3 CURSOR FOR
                          SELECT pfactor    , ipro_year
                            INTO $dmg_factor
                            FROM car_model_factor
                           WHERE fdmg_brg  = '1'
                             AND irate     = $idmg_rate
                             AND ipro_year > $pro_year
                             AND drate     = (SELECT drate
                                                FROM ca_rate_date
                                               WHERE icode  = $frate
                                                 AND itable = 'car_model_factor')
                           ORDER BY ipro_year;
                        $OPEN  CA_OPT11_3;
                        $FETCH CA_OPT11_3;
                        if (NOT_FOUND)
                        {
                            $CLOSE CA_OPT11_3;
                            $FREE  CA_OPT11_3;
                            return M_CA_NCAR_MODEL_FACTOR;
                        }
                        $CLOSE CA_OPT11_3;
                        $FREE CA_OPT11_3;
                    }
                }
            }
        }
        printf("�[�˳]�ƫᨮ���I�O�v�ͮĥN���Y��idmg_rate[%s]\n",idmg_rate);

        #ifdef GCAR

        if (strncmp(iroute,"PE",2) == 0)
        {
            strncpy(carteam, &iroute[2], strlen(iroute)-2 );
            carteam[strlen(iroute)-2] = '\0';
            strcpy(carteam, trim(carteam));
        }

        /*printf(" carteam=[%s] \n\n ",carteam);*/
        printf("tmp_provision[%s]\n\n ",tmp_provision);

        INS_ptr->irate = 0;
        INS_ptr->adjust_rate = 0.0;
        INS_ptr->safe_rate   = 0.0;
        INS_ptr->manage_rate = 0.0;
        /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N��*/
        strcpy(sProvDelimiter,"");
        sprintf_s(sProvDelimiter,sizeof sProvDelimiter,"%s;",trim(tmp_provision));        
        if((strstr(sProvDelimiter, "F;") != NULL) || (strstr(sProvDelimiter, "G;") != NULL) || (strstr(sProvDelimiter, "I;") != NULL) )
        {
            strcpy(chk_provision,"");
            if((strstr(sProvDelimiter, "F;") != NULL))
                strcpy(chk_provision,"F");
            else if((strstr(sProvDelimiter, "G;") != NULL))
                strcpy(chk_provision,"G");
            else
                strcpy(chk_provision,"I");  
                
            printf("--chk_provision[%s]\n",chk_provision);
            /* 1081018008-SC2-�ū\��-�s�W���M(�˥�)�ѵs�I��O�X��@�~�έק�B����O�J�p���� L*B�g��*/
            strcpy(sIofficerChar,"");
            strcpy(sIofficerChar,substring(officer2,7,1));

            if (carteam[0] != ' ' && carteam[0] != '\0') /* ��¾�� */
            {
                /* car9902051 �M�ץX��n�ǰe�n�O�HID������,�DW�}�Y�g��N���h����Q�O�I�HID */
                /* �M�׸g�춷�[�A�[�JH�g��,���ư�H0-H2 modify by sylvia 103.01.07 (1021122001_C1) */
                /* 103.10.15 (1030630002_C2_���M�ץ�@�~�Ҧ��վ� ) '�M�ץ�N�g�쬰"���ӥ�"*/
                /* 1081018008-SC2-�ū\��-�s�W���M(�˥�)�ѵs�I��O�X��@�~�έק�B����O�J�p���� L*B�g��*/
                if ((officer2[0] == 'W') || (officer2[0] == 'N') ||
                      ((officer2[0] == 'H') && (strncmp(officer2,"H0",2) != 0) &&
                       (strncmp(officer2,"H1",2) != 0) && (strncmp(officer2,"H2",2) != 0)) ||
                      ((officer2[0] == 'L') && (sIofficerChar[0] == 'B') && strlen(officer2) == 7))
                {
                    rtncode = get_ca_id_officer( iapplicant, carteam, car_typei2, ins_type, cm_edate_str(ply2_begin),stmp_dpolicy,chk_provision,
                                                  &INS_ptr->irate, &INS_ptr->adjust_rate, v_sMsg);
                }
                else
                {
                    rtncode = get_ca_id_officer( assuredi, carteam, car_typei2, ins_type, cm_edate_str(ply2_begin),stmp_dpolicy,chk_provision,
                                                 &INS_ptr->irate, &INS_ptr->adjust_rate, v_sMsg);
                }
            }
            else /* �L¾�Υθg��N�� */
            {
                /* car9902051 �M�ץX��n�ǰe�n�O�HID������,�DW�}�Y�g��N���h����Q�O�I�HID */
                /* �M�׸g�춷�[�A�[�JH�g��,���ư�H0-H2 modify by sylvia 103.01.07 (1021122001_C1) */
                /*103.10.15 (1030630002_C2_���M�ץ�@�~�Ҧ��վ� ) '�M�ץ�N�g�쬰"���ӥ�"*/
                /* 1081018008-SC2-�ū\��-�s�W���M(�˥�)�ѵs�I��O�X��@�~�έק�B����O�J�p���� L*B�g��*/
                if ((officer2[0] == 'W') || (officer2[0] == 'N') ||
                    ((officer2[0] == 'H') && (strncmp(officer2,"H0",2) != 0) &&
                     (strncmp(officer2,"H1",2) != 0) && (strncmp(officer2,"H2",2) != 0)) ||
                    ((officer2[0] == 'L') && (sIofficerChar[0] == 'B') && strlen(officer2) == 7))
                {
                    rtncode = get_ca_id_officer( iapplicant, officer2, car_typei2, ins_type, cm_edate_str(ply2_begin),stmp_dpolicy,chk_provision,
                                                  &INS_ptr->irate, &INS_ptr->adjust_rate, v_sMsg);
                }
                else
                {
                    rtncode = get_ca_id_officer( assuredi, officer2, car_typei2, ins_type, cm_edate_str(ply2_begin),stmp_dpolicy,chk_provision,
                                                  &INS_ptr->irate, &INS_ptr->adjust_rate, v_sMsg);
                }
            }

            if( rtncode != M_CM_OK)
                return rtncode;
            
            /*1110317002_SC3_�ק�F���ڥi�ϥΤ��I�ؤΫO�O�p��վ�ηs�Wcar140�I�غ��@�]�w*/    
            /*07.10.17.109 ��D�I�����v*/
            if ((strcmp(ins_type,"07") == 0 || strcmp(ins_type,"10") == 0 || strcmp(ins_type,"17") == 0 || strcmp(ins_type,"109") == 0 )&& INS_ptr->irate == 0)
            {
            	if(strcmp(ins_type,"07") == 0 || strcmp(ins_type,"10") == 0)
            	{
            	    INS_ptr->irate = irate_ProF_main_dmg;
            	    INS_ptr->adjust_rate = dbl_ProF_main_dmg;	
            	}
            	else if(strcmp(ins_type,"17") == 0)
            	{
            	    INS_ptr->irate = irate_ProF_main_brg;
            	    INS_ptr->adjust_rate = dbl_ProF_main_brg;		
            	}
            	else if(strcmp(ins_type,"109") == 0)
            	{
            	    INS_ptr->irate = irate_ProF_main_lia;
            	    INS_ptr->adjust_rate = dbl_ProF_main_lia;
            	}
            }
                

            /* �������[���ڤ��Ҽ{�F�Ƭ����A���k�s�A���}function�A�٭� */
            plia_acc2 = 0;
            
        }
        else if(strstr(sProvDelimiter, "T;") != NULL)
        {
            /* 1030218002_C2 �O�O�p��Ū���f�B�~���[����T���]�w */
            /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N�� */        	
            
            rtncode = get_ca_truck_transport( assuredi, officer2, iroute, cm_edate_str(ply2_begin),stmp_dpolicy,
                                        &INS_ptr->safe_rate, &INS_ptr->manage_rate , v_sMsg);

            if( rtncode != M_CM_OK)
                return rtncode;
        }
        else
        {
            plia_acc2 = plia_acc2_ori;
        }

        #endif


        provision_D = 0;
        provision_J = 1.0;
        provision_C = 1.0;
        provision_H = 1.0;
        provision_P = 1.0; /* 1071226006-SC1-��ã��-�w���ƫ����վ�(���²v+�ĤT�H�d��*/
        provision_Q = 1.0;
        provision_K = 1.0; /* 1080408008-SC1-98������09+K*/
        provision_L = 1.0; /*1080708002-SC1-��ã��-�s�W��������L����*/
        provision_M = 1.0;/* 1081105005-SC1-��ã��-�ק���~���w���ƫ������²v�Φۭt�B(M����)*/
        provision_Y = 1.0; /* 1130827011_C02_�s�W�s�t��W�B���[����(Y)�A�Щ�11/1�W�u*/
        
        /*** �ˮ`�I�O�I�O���p��-48 ***/
        if (iins==48)
        {
            lMins_premium48 = 0;
            lPure_premium48 = 0;
            lMcommission48  = 0;
            lMagent48       = 0;
            lMdiscount48    = 0;
            lBef_premium48  = 0;
            lMins_premium48_n = 0;
            lPure_premium48_n = 0;
            lBef_premium48_n  = 0;
            lMdiscount48_n    = 0;

            INS_ptr_48      = Ifirst_48;
            while (INS_ptr_48)
            {
                strcpy(cIinsurant        , INS_ptr_48->cIinsurant);  /* �Q�O�I�Hid */
                strcpy(iins_scope_tmp    , INS_ptr_48->cIins_scope); /* �ӫO�d�� */
                lMins_amt_48             = INS_ptr_48->lMins_amt;
                lDaily_pay_48            = INS_ptr_48->lDaily_pay;

                INS_ptr_48->dPdiscount   = INS_ptr->pdiscount;
                INS_ptr_48->dPcommission = INS_ptr->pcommission;
                INS_ptr_48->dPagent      = INS_ptr->pagent;

                printf("lDaily_pay_48=[%d]\n", lDaily_pay_48 );

                /*1041117006_C1 �ˮ`�I�ګO���ˮ֭ק�(���� ireason[1,1] = 'A' WHERE ����)  */
                /* �ˮֳQ�O�I�H�O�_�ګO */
                /* �אּ�ȴ��ܤ����_ modify by sylvia 100.10.13 (991216002_C1) */
                /* 1121227003_C01_�����r���I�إh���AH�ګO���@��(���s) */
                /*if (check_est_cal_prem == 0)
                {
                    
                    $SELECT iassured
                       FROM ot_refused_cus
                      WHERE iassured = $cIinsurant;

                    if (SQLCODE != SQLNOTFOUND)
                        Ireject_count = Ireject_count + 1;
                }*/

                printf("\n\niins48 iins_scope[%s] Mins_amt_48[%d] cal_car_id[%s]\n", iins_scope_tmp, lMins_amt_48, cal_car_id );

                $SELECT drate
                   FROM ca_rate_date
                  WHERE icode  = $frate
                    AND itable = 'cover_vs_premium';
                if (NOT_FOUND)  return M_CA_NRATE_DATE;

                /* 1.���o���ݯ«O�O (mpremium), ���[�O�βv */
                $SELECT mpremium,  NVL(pextra_charge/100,0)
                   INTO $mpremium_1, $pextra_charge_1
                   FROM cover_vs_premium
                  WHERE icar_type = $cal_car_id
                    AND iins_type = '48'
                    AND mdeduct   = 0
                    AND mcoverage1 = 0
                    AND mcoverage2 = $lMins_amt_48
                    AND drate      = (SELECT drate
                                        FROM ca_rate_date
                                       WHERE icode  = $frate
                                         AND itable = 'cover_vs_premium');
                if (NOT_FOUND) return M_CA_NCOVER_PREM;


                pextra_charge_1 = INS_ptr->pextra_charge;

                printf("-------->mpremium_1=[%f]\n", mpremium_1 );

                /* 2.���o���[�����¶O (mpremium), ���[�O�βv */
                $SELECT mpremium,  NVL(pextra_charge/100,0)
                   INTO $mpremium_mr, $pextra_charge_mr
                   FROM cover_vs_premium
                  WHERE icar_type = $cal_car_id
                    AND iins_type = '48'
                    AND mdeduct   = 1
                    AND mcoverage1 = 0
                    AND mcoverage2 = $lDaily_pay_48
                    AND drate      = (SELECT drate
                                        FROM ca_rate_date
                                       WHERE icode  = $frate
                                         AND itable = 'cover_vs_premium');
                if (NOT_FOUND) return M_CA_NCOVER_PREM;


                pextra_charge_mr = INS_ptr->pextra_charge;


                printf("\n=== count premium \n");
                printf("lMins_amt_48[%d] mpremium_1[%f] pextra_charge_1[%f] mpremium_mr[%f] pextra_charge_mr[%f] \n", lMins_amt_48, mpremium_1, pextra_charge_1, mpremium_mr, pextra_charge_mr );
    
                /* 1.�ˮ`�M�I�O�O */
                INS_ptr_48->lPure_premium = (double)mpremium_1 * (double)short_prate *
                                            (double)(1 + INS_ptr->deviation_rate/100.0);
    
                /* 2.�ˮ`�W���O�O */
                INS_ptr_48->lMins_premium = (long)d45( INS_ptr_48->lPure_premium/(1-pextra_charge_1) ,0);
                lBef_premium48 += (long)INS_ptr_48->lMins_premium;    /* �W���O�O�t���� */
    
                #ifdef GCAR /* GCAR */
                /* �D�A�Ψ������«O�Ompure_prem_n�A�W���O�Omins_prem_n */
    
                INS_ptr_48->mpure_prem_n = INS_ptr_48->lPure_premium;
                INS_ptr_48->mprem_n = INS_ptr_48->lMins_premium;
                lBef_premium48_n += (long)INS_ptr_48->lMins_premium;
    
                /* 48�A�Ψ������[����(F),car9804233, 48���A�Τj�v���[����(B) */
                /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N�� */
                if((strstr(sProvDelimiter, "F;") != NULL) || (strstr(sProvDelimiter, "G;") != NULL) || (strstr(sProvDelimiter, "I;") != NULL))
                {
                    lBef_premium48 = 0;
                    INS_ptr_48->lPure_premium = (double)mpremium_1 * (double)short_prate
                                                * (double)(1 + INS_ptr->adjust_rate);
                    INS_ptr_48->lMins_premium = (long)d45( (INS_ptr_48->lPure_premium/(1-pextra_charge_1)) ,0);
                    lBef_premium48 += (long)INS_ptr_48->lMins_premium;    /* �W���O�O�t���� */
                }

                #endif
                if (INS_ptr_48->dPdiscount >= 0)
                {
                    disc_last =  0.500000000001;
                }
                else
                {
                    disc_last = -0.500000000001;
                }

                /* 3.�p���u�f���B */
                if (cal_itype_disc[0] == '2')
                {
                    INS_ptr_48->lMdiscount=(long)((double)INS_ptr_48->lMins_premium*INS_ptr_48->dPdiscount/100.0+disc_last);
                    INS_ptr_48->mdiscount_n=(long)((double)INS_ptr_48->mprem_n*INS_ptr_48->dPdiscount/100.0+disc_last);
                }
                else
                {
                    INS_ptr_48->lMdiscount   = INS_ptr->mdiscount;
                    INS_ptr_48->mdiscount_n  = INS_ptr->mdiscount;
                }

                /* 4.�p��ñ��O�O */
                INS_ptr_48->lMins_premium = INS_ptr_48->lMins_premium - INS_ptr_48->lMdiscount;

                #ifdef GCAR /* GCAR */
                /* �D�A�Ψ���ñ��O�Omins_premium_n */
                INS_ptr_48->mins_premium_n = INS_ptr_48->mprem_n - INS_ptr_48->mdiscount_n;
                #endif

                printf("lPure_premium[%f]\n", INS_ptr_48->lPure_premium);
                printf("lMins_premium[%f]\n", INS_ptr_48->lMins_premium);

                if( strcmp( iins_scope_tmp , "2" ) == 0 )
                {
                    /* 1.�����M�I�O�O */
                    INS_ptr_48->lMr_pure_prem = (double)mpremium_mr * (double)short_prate *
                                                (double)(1 + INS_ptr->deviation_rate/100.0);

                    /* 2.�����W���O�O */
                    INS_ptr_48->lMr_ins_prem=(long)d45( (INS_ptr_48->lMr_pure_prem/(1-pextra_charge_mr)) ,0);

                    /* �������[����,car9804233, 48���A�Τj�v���[���� */
                    /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N�� */
                    if((strstr(sProvDelimiter, "F;") == NULL) && (strstr(sProvDelimiter, "G;") == NULL)&& (strstr(sProvDelimiter, "I;") == NULL))
                        lBef_premium48 += (long)INS_ptr_48->lMr_ins_prem;    /* �W���O�O�t���� */

                    #ifdef GCAR /* GCAR */

                    INS_ptr_48->mr_mpure_prem_n = INS_ptr_48->lMr_pure_prem;
                    INS_ptr_48->mr_mprem_n = INS_ptr_48->lMr_ins_prem;
                    lBef_premium48_n += (long)INS_ptr_48->lMr_ins_prem;

                    /* 48�A�Ψ������[����(F),car9804233, 48���A�Τj�v���[����(B) */
                    /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N��*/
                    if((strstr(sProvDelimiter, "F;") != NULL) || (strstr(sProvDelimiter, "G;") != NULL)|| (strstr(sProvDelimiter, "I;") != NULL))
                    {
                        INS_ptr_48->lMr_pure_prem = (double)mpremium_mr * (double)short_prate
                                                  * (double)(1 + INS_ptr->adjust_rate);
                        INS_ptr_48->lMr_ins_prem=(long)d45( (INS_ptr_48->lMr_pure_prem/(1-pextra_charge_mr)) ,0);
                        lBef_premium48 += (long)INS_ptr_48->lMr_ins_prem;
                    }

                    #endif

                    /* 3.�����u�f���B */
                    if (cal_itype_disc[0] == '2')
                    {
                        INS_ptr_48->lMr_discount=(long)((double)INS_ptr_48->lMr_ins_prem*INS_ptr_48->dPdiscount/100.0+disc_last);
                        INS_ptr_48->mr_mdiscount_n=(long)((double)INS_ptr_48->mr_mprem_n*INS_ptr_48->dPdiscount/100.0+disc_last);
                    }
                    else
                    {
                        INS_ptr_48->lMr_discount   = 0;
                        INS_ptr_48->mr_mdiscount_n = 0;
                    }

                    /* 4.����ñ��O�O */
                    INS_ptr_48->lMr_ins_prem = INS_ptr_48->lMr_ins_prem - INS_ptr_48->lMr_discount;
                    #ifdef GCAR /* GCAR */
                    INS_ptr_48->mr_mins_premium_n = INS_ptr_48->mr_mprem_n - INS_ptr_48->mr_mdiscount_n;
                    #endif

                    printf("\nlMr_pure_prem[%f]\n", INS_ptr_48->lMr_pure_prem);
                    printf("lMr_ins_prem[%f]\n", INS_ptr_48->lMr_ins_prem);
                }
                else
                {
                    INS_ptr_48->lMr_pure_prem = 0;
                    INS_ptr_48->lMr_ins_prem  = 0;
                    INS_ptr_48->lMr_discount  = 0;

                    #ifdef GCAR /* GCAR */
                    INS_ptr_48->mr_mpure_prem_n   = 0;
                    INS_ptr_48->mr_mins_premium_n = 0;
                    INS_ptr_48->mr_mprem_n        = 0;
                    INS_ptr_48->mr_mdiscount_n    = 0;
                    #endif
                }

                /** �O�O = �ˮ` + ���� **/
                INS_ptr_48->lMdiscount += INS_ptr_48->lMr_discount;
                INS_ptr_48->lMins_premium += INS_ptr_48->lMr_ins_prem;
                INS_ptr_48->lPure_premium += INS_ptr_48->lMr_pure_prem;

                #ifdef GCAR /* GCAR */
                INS_ptr_48->mins_premium_n += INS_ptr_48->mr_mins_premium_n;
                INS_ptr_48->mpure_prem_n += INS_ptr_48->mr_mpure_prem_n;
                INS_ptr_48->mprem_n += INS_ptr_48->mr_mprem_n;
                INS_ptr_48->mdiscount_n += INS_ptr_48->mr_mdiscount_n;
                #endif

                if (cal_itype_disc[0] == '1')
                {
                    INS_ptr_48->dPdiscount   = d45((double)INS_ptr_48->lMdiscount /
                                                   (double)(INS_ptr_48->lMins_premium + INS_ptr_48->lMdiscount)*100.0,2);
                }

                /* 5.�p���u�f�v,�����v,�N�z�v */
                if (strcmp(tmp_ipaid_base,"A")==0)       /* ���u�ݫ�O�O�p�� */
                {
                    INS_ptr_48->lMcommission = (long)d45( ((double)INS_ptr_48->lMins_premium*INS_ptr_48->dPcommission/100.0) ,0);
                    INS_ptr_48->lMagent      = (long)d45( ((double)INS_ptr_48->lMins_premium*INS_ptr_48->dPagent/100.0) ,0);
                }
                else if (strcmp(tmp_ipaid_base,"B")==0)  /* ���u�ݫe�O�O�p��:�u�ݫe�O�O=ñ��O�O+�u�f���B */
                {
                    INS_ptr_48->lMcommission = (long)d45( ((double)(INS_ptr_48->lMins_premium+INS_ptr_48->lMdiscount)*INS_ptr_48->dPcommission/100.0) ,0);
                    INS_ptr_48->lMagent      = (long)d45( ((double)(INS_ptr_48->lMins_premium+INS_ptr_48->lMdiscount)*INS_ptr_48->dPagent/100.0) ,0);
                }
                else
                {
                    INS_ptr_48->lMcommission = (long)d45( ((double)INS_ptr_48->lMins_premium*INS_ptr_48->dPcommission/100.0) ,0);
                    INS_ptr_48->lMagent      = (long)d45( ((double)INS_ptr_48->lMins_premium*INS_ptr_48->dPagent/100.0) ,0);
                }

                lPure_premium48 += (long)d45( INS_ptr_48->lPure_premium ,0);
                lMins_premium48 += (long)INS_ptr_48->lMins_premium;
                lMcommission48  += INS_ptr_48->lMcommission;
                lMagent48       += INS_ptr_48->lMagent;
                lMdiscount48    += INS_ptr_48->lMdiscount;

                #ifdef GCAR /* GCAR */
                lPure_premium48_n += (long)d45( INS_ptr_48->mpure_prem_n ,0);
                lMins_premium48_n += (long)INS_ptr_48->mins_premium_n;
                lMdiscount48_n    += INS_ptr_48->mdiscount_n;
                #endif

                INS_ptr_48=INS_ptr_48->next;
            }

            INS_ptr->bef_ins_premium = lBef_premium48;
            INS_ptr->pure_ins_premium= lPure_premium48;
            INS_ptr->ins_premium     = lMins_premium48;
            INS_ptr->mcommission     = lMcommission48;
            INS_ptr->magent          = lMagent48;
            INS_ptr->mdiscount       = lMdiscount48;

            #ifdef GCAR /* GCAR */
            INS_ptr->mprem_n        = lBef_premium48_n;
            INS_ptr->mpure_prem_n   = lPure_premium48_n;
            INS_ptr->mins_premium_n = lMins_premium48_n;
            INS_ptr->mdiscount_n    = lMdiscount33_n;
            #endif

            if (cal_itype_disc[0] == '1')
            {
                INS_ptr->pdiscount       = d45((double)INS_ptr->mdiscount/(double)INS_ptr->bef_ins_premium * 100 , 2);
            }
            goto step_9_e_iii; /* �����p��O�O�X�p�Φ����B�N�z�B�����X�p���B */
            
        }

        /*** �T�����[�����ĤT�H�d���I�O�I�O���p��-35 ***/
        if (iins==35)
        {
            lMins_premium35 = 0;
            lPure_premium35 = 0;
            lMcommission35  = 0;
            lMagent35       = 0;
            lMdiscount35    = 0;
            lBef_premium35  = 0;

            lMins_premium35_n = 0;
            lPure_premium35_n = 0;
            lBef_premium35_n  = 0;
            lMdiscount35_n    = 0;

            INS_ptr_35      = Ifirst_35;
            while (INS_ptr_35)
            {
                strcpy(cIinsurant        , INS_ptr_35->cIinsurant);  /* �Q�O�I�Hid */
                strcpy(iins_scope_tmp    , INS_ptr_35->cIins_scope); /* �ӫO�d�� */
                lMins_amt_35             = INS_ptr_35->lMins_amt;
                INS_ptr_35->dPdiscount   = INS_ptr->pdiscount;
                INS_ptr_35->dPcommission = INS_ptr->pcommission;
                INS_ptr_35->dPagent      = INS_ptr->pagent;

                /* 1041117006_C1 �ˮ`�I�ګO���ˮ֭ק�(���� ireason[1,1] = 'A' WHERE ����)  */
                /* �ˮֳQ�O�I�H�O�_�ګO,�p�W���~�ˬd */
                /* �אּ�ȴ��ܤ����_ modify by sylvia 100.10.13 (991216002_C1) */
                /* 1121227003_C01_�����r���I�إh���AH�ګO���@��(���s) */
                /*if (check_est_cal_prem == 0 && strcmp( iins_scope_tmp , "1" ) == 0 )
                {
                    
                    $SELECT iassured
                       FROM ot_refused_cus
                      WHERE iassured = $cIinsurant;

                    if (SQLCODE != SQLNOTFOUND)
                        Ireject_count = Ireject_count + 1;

                }*/

                printf("\n\niins35 iins_scope[%s] Mins_amt_35[%d] cal_car_id[%s]\n", iins_scope_tmp, lMins_amt_35, cal_car_id );

                $SELECT drate
                   FROM ca_rate_date
                  WHERE icode  = $frate
                    AND itable = 'cover_vs_premium';
                if (NOT_FOUND)  return M_CA_NRATE_DATE;

                /* ���o�«O�O (mpremium), ���[�O�βv */
                $SELECT mpremium,  NVL(pextra_charge/100,0)
                   INTO $mpremium_1, $pextra_charge_1
                   FROM cover_vs_premium
                  WHERE icar_type = $cal_car_id
                    AND iins_type = '35'
                    AND mdeduct   = $iins_scope_tmp
                    AND mcoverage1 = 0
                    AND mcoverage2 = $lMins_amt_35
                    AND drate      = (SELECT drate
                                        FROM ca_rate_date
                                       WHERE icode  = $frate
                                           AND itable = 'cover_vs_premium');
                if (NOT_FOUND) return M_CA_NCOVER_PREM;


                pextra_charge_1 = INS_ptr->pextra_charge;

                printf("lMins_amt_35[%d] mpremium_1[%f] pextra_charge_1[%f] \n", lMins_amt_35, mpremium_1, pextra_charge_1 );

                /* 1.�ˮ`�M�I�O�O */
                INS_ptr_35->lPure_premium = (double)mpremium_1 * (double)short_prate *
                                            (double)(1 + INS_ptr->deviation_rate/100.0);
                printf("mpremium_1[%f]\n", mpremium_1);

                /* 2.�ˮ`�W���O�O */
                INS_ptr_35->lMins_premium = (long)d45( (INS_ptr_35->lPure_premium/(1-pextra_charge_1)) ,0);
                lBef_premium35 += (long)INS_ptr_35->lMins_premium;    /* �W���O�O�t���� */

                #ifdef GCAR /* GCAR */

                /* �D�A�Ψ������«O�Ompure_prem_n�A�W���O�Omins_prem_n */
                INS_ptr_35->mpure_prem_n = INS_ptr_35->lPure_premium;
                INS_ptr_35->mprem_n = INS_ptr_35->lMins_premium;
                lBef_premium35_n += (long)INS_ptr_35->lMins_premium;

                /* 38�A�Ψ������[����(F),car9804233, 35���A�Τj�v���[����(B) */
                /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N�� sProvDelimiter */
                if((strstr(sProvDelimiter, "F;") != NULL) || (strstr(sProvDelimiter, "G;") != NULL) || (strstr(sProvDelimiter, "I;") != NULL))
                {
                    lBef_premium35 = 0;
                    INS_ptr_35->lPure_premium = (double)mpremium_1 * (double)short_prate
                                              * (double)(1 + INS_ptr->adjust_rate);
                    INS_ptr_35->lMins_premium = (long)d45( (INS_ptr_35->lPure_premium/(1-pextra_charge_1)) ,0);
                    lBef_premium35 += (long)INS_ptr_35->lMins_premium;    /* �W���O�O�t���� */
                }
                #endif

                if (INS_ptr_35->dPdiscount >= 0)
                {
                    disc_last = 0.500000000001;
                }
                else
                {
                    disc_last = -0.500000000001;
                }

                /* 3.�p���u�f���B */
                if (cal_itype_disc[0] == '2')
                {
                    INS_ptr_35->lMdiscount=(long)((double)INS_ptr_35->lMins_premium*INS_ptr_35->dPdiscount/100.0+disc_last);
                    INS_ptr_35->mdiscount_n=(long)((double)INS_ptr_35->mprem_n*INS_ptr_35->dPdiscount/100.0+disc_last);
                }
                else
                {
                    INS_ptr_35->lMdiscount     = INS_ptr->mdiscount;
                    INS_ptr_35->mdiscount_n = 0;
                }

                /* 4.�p��ñ��O�O */
                INS_ptr_35->lMins_premium = INS_ptr_35->lMins_premium - INS_ptr_35->lMdiscount;

                #ifdef GCAR /* GCAR */
                /* �D�A�Ψ���ñ��O�Omins_premium_n */
                INS_ptr_35->mins_premium_n = INS_ptr_35->mprem_n - INS_ptr_35->lMdiscount;
                #endif

                printf("lPure_premium[%f]\n", INS_ptr_35->lPure_premium);
                printf("lMins_premium[%f]\n", INS_ptr_35->lMins_premium);

                INS_ptr_35->lMr_pure_prem = 0;
                INS_ptr_35->lMr_ins_prem  = 0;
                INS_ptr_35->lMr_discount  = 0;

                #ifdef GCAR /* GCAR */
                INS_ptr_35->mr_mpure_prem_n = 0;
                INS_ptr_35->mr_mins_premium_n  = 0;
                INS_ptr_35->mr_mprem_n  = 0;
                INS_ptr_35->mr_mdiscount_n  = 0;
                #endif

                if (cal_itype_disc[0] == '1')
                {
                    INS_ptr_35->dPdiscount   = d45((double)INS_ptr_35->lMdiscount /
                                                   (double)(INS_ptr_35->lMins_premium + INS_ptr_35->lMdiscount)*100.0,2);
                }

                /* 5.�p���u�f�v,�����v,�N�z�v */
                if (strcmp(tmp_ipaid_base,"A")==0)       /* ���u�ݫ�O�O�p�� */
                {
                    INS_ptr_35->lMcommission = (long)d45( ((double)INS_ptr_35->lMins_premium*INS_ptr_35->dPcommission/100.0) ,0);
                    INS_ptr_35->lMagent      = (long)d45( ((double)INS_ptr_35->lMins_premium*INS_ptr_35->dPagent/100.0) ,0);
                }
                else if (strcmp(tmp_ipaid_base,"B")==0)  /* ���u�ݫe�O�O�p��:�u�ݫe�O�O=ñ��O�O+�u�f���B */
                {
                    INS_ptr_35->lMcommission = (long)d45( ((double)(INS_ptr_35->lMins_premium+INS_ptr_35->lMdiscount)*INS_ptr_35->dPcommission/100.0) ,0);
                    INS_ptr_35->lMagent      = (long)d45( ((double)(INS_ptr_35->lMins_premium+INS_ptr_35->lMdiscount)*INS_ptr_35->dPagent/100.0) ,0);
                }
                else
                {
                    INS_ptr_35->lMcommission = (long)d45( ((double)INS_ptr_35->lMins_premium*INS_ptr_35->dPcommission/100.0) ,0);
                    INS_ptr_35->lMagent      = (long)d45( ((double)INS_ptr_35->lMins_premium*INS_ptr_35->dPagent/100.0) ,0);
                }

                /* �H�ݨD�渹car9606151,�ץ�35�I��PA���ӨS���|�ˤ��J,���I�د«O�O�o���|�ˤ��J���ͪ��~�t  */
                INS_ptr_35->lPure_premium = (long)d45( INS_ptr_35->lPure_premium ,0);

                lPure_premium35 += (long)d45( INS_ptr_35->lPure_premium ,0);
                lMins_premium35 += (long)INS_ptr_35->lMins_premium;
                lMcommission35  += INS_ptr_35->lMcommission;
                lMagent35       += INS_ptr_35->lMagent;
                lMdiscount35    += INS_ptr_35->lMdiscount;

                #ifdef GCAR /* GCAR */
                lPure_premium35_n += (long)d45( INS_ptr_35->mpure_prem_n ,0);
                lMins_premium35_n += (long)INS_ptr_35->mins_premium_n;
                lMdiscount35_n    += INS_ptr_35->mdiscount_n;
                #endif

                INS_ptr_35=INS_ptr_35->next;
            }

            INS_ptr->bef_ins_premium = lBef_premium35;
            INS_ptr->pure_ins_premium= lPure_premium35;
            INS_ptr->ins_premium     = lMins_premium35;
            INS_ptr->mcommission     = lMcommission35;
            INS_ptr->magent          = lMagent35;
            INS_ptr->mdiscount       = lMdiscount35;

            #ifdef GCAR /* GCAR */
            INS_ptr->mprem_n        = lBef_premium35_n;
            INS_ptr->mpure_prem_n   = lPure_premium35_n;
            INS_ptr->mins_premium_n = lMins_premium35_n;
            INS_ptr->mdiscount_n    = lMdiscount35_n;
            #endif

            if (cal_itype_disc[0] == '1')
            {
                INS_ptr->pdiscount       = d45((double)INS_ptr->mdiscount/(double)INS_ptr->bef_ins_premium * 100 , 2);
            }

            goto step_9_e_iii; /* �����p��O�O�X�p�Φ����B�N�z�B�����X�p���B */
        }

        /*** �ˮ`�I�O�I�O���p��-56 ***/
        if (iins==56 || iins==136 || iins==166 || iins==266 )
        {
            lMins_premium56 = 0;
            lPure_premium56 = 0;
            lMcommission56  = 0;
            lMagent56       = 0;
            lMdiscount56    = 0;
            lBef_premium56  = 0;
            lMins_premium56_n = 0;
            lPure_premium56_n = 0;
            lBef_premium56_n  = 0;
            lMdiscount56_n    = 0;

            INS_ptr_56      = Ifirst_56;
            while (INS_ptr_56)
            {
                strcpy(cIinsurant        , INS_ptr_56->cIinsurant);  /* �Q�O�I�Hid */
                strcpy(iins_scope_tmp    , INS_ptr_56->cIins_scope); /* �ӫO�d�� */
                lMins_amt_56             = INS_ptr_56->lMins_amt;
                lDaily_pay_56            = INS_ptr_56->lDaily_pay;
                INS_ptr_56->dPdiscount   = INS_ptr->pdiscount;
                INS_ptr_56->dPcommission = INS_ptr->pcommission;
                INS_ptr_56->dPagent      = INS_ptr->pagent;

                printf("lDaily_pay_56=[%d]  check_est_cal_prem=[%d], cIinsurant[%s]\n", lDaily_pay_56, check_est_cal_prem, cIinsurant );

                /*1041117006_C1 �ˮ`�I�ګO���ˮ֭ק�(���� ireason[1,1] = 'A' WHERE ����)  */
                /* �ˮֳQ�O�I�H�O�_�ګO */
                /* �אּ�ȴ��ܤ����_ modify by sylvia 100.10.13 (991216002_C1) */
                /* 1121227003_C01_�����r���I�إh���AH�ګO���@��(���s) */
                /*if (check_est_cal_prem == 0 && strlen( trim(cIinsurant)) != 0 )
                {
                    
                    $SELECT iassured
                       FROM ot_refused_cus
                      WHERE iassured = $cIinsurant;
                    printf("SQLCODE[%d]\n", SQLCODE);

                    if (SQLCODE != SQLNOTFOUND)
                        Ireject_count = Ireject_count + 1;

                }*/

                printf("lPure_premium56=[%d] lMins_premium56=[%d]\n", lPure_premium56, lMins_premium56 );

                if( (lPure_premium56 > 0) && ( lMins_premium56 > 0 ))
                {
                    INS_ptr_56->lMr_pure_prem = 0;
                    INS_ptr_56->lMr_ins_prem  = 0;
                    INS_ptr_56->lMr_discount  = 0;
                    INS_ptr_56->lPure_premium = 0;
                    INS_ptr_56->lMins_premium = 0;
                    INS_ptr_56->lMdiscount    = 0;
                    INS_ptr_56->lMcommission  = 0;
                    INS_ptr_56->lMagent       = 0;

                    #ifdef GCAR /* GCAR */
                    INS_ptr_56->mpure_prem_n = 0;
                    INS_ptr_56->mins_premium_n = 0;
                    INS_ptr_56->mprem_n = 0;
                    INS_ptr_56->mdiscount_n = 0;
                    INS_ptr_56->mr_mpure_prem_n = 0;
                    INS_ptr_56->mr_mins_premium_n = 0;
                    INS_ptr_56->mr_mprem_n = 0;
                    INS_ptr_56->mr_mdiscount_n = 0;
                    #endif

                    INS_ptr_56=INS_ptr_56->next;
                    continue;
                }

                printf("\n\niins56 iins_scope[%s] Mins_amt_56[%d] cal_car_id[%s]\n", iins_scope_tmp, lMins_amt_56, cal_car_id );

                $SELECT drate
                   FROM ca_rate_date
                  WHERE icode  = $frate
                    AND itable = 'cover_vs_premium';
                if (NOT_FOUND)  return M_CA_NRATE_DATE;

                /* 1.���o���ݯ«O�O (mpremium), ���[�O�βv */
                $SELECT mpremium,  NVL(pextra_charge/100,0)
                   INTO $mpremium_1, $pextra_charge_1
                   FROM cover_vs_premium
                  WHERE icar_type = $cal_car_id
                    AND iins_type = $ins_type
                    AND mdeduct   = 0
                    AND mcoverage1 = 0
                    AND mcoverage2 = $lMins_amt_56
                    AND drate      = (SELECT drate
                                        FROM ca_rate_date
                                       WHERE icode  = $frate
                                         AND itable = 'cover_vs_premium');
                if (NOT_FOUND) return M_CA_NCOVER_PREM;


                pextra_charge_1 = INS_ptr->pextra_charge;

                printf("-------->mpremium_1=[%f]\n", mpremium_1 );
                printf("========>cal_car_id=[%s] lDaily_pay_56=[%d]\n", cal_car_id, lDaily_pay_56 );

                /* 1031104004_C1,56�I�s�W����I�� */
                tmp_mdeduct = -1;
                if( strcmp( iins_scope_tmp , "2" ) == 0 )
                {
                    tmp_mdeduct = 1;
                }
                else if( strcmp( iins_scope_tmp , "3" ) == 0 )
                {
                    tmp_mdeduct = 2;
                }
                printf("-- trace tmp_mdeduct[%ld]\n ",tmp_mdeduct);

                /* 2.���o���[�����¶O (mpremium), ���[�O�βv */
                $SELECT mpremium,  NVL(pextra_charge/100,0), msi_premium
                   INTO $mpremium_mr, $pextra_charge_mr, $msi_premium
                   FROM cover_vs_premium
                  WHERE icar_type = $cal_car_id
                    AND iins_type = $ins_type
                    AND mdeduct   = $tmp_mdeduct
                    AND mcoverage1 = 0
                    AND mcoverage2 = $lDaily_pay_56
                    AND drate      = (SELECT drate
                                        FROM ca_rate_date
                                       WHERE icode  = $frate
                                         AND itable = 'cover_vs_premium');
                if (NOT_FOUND) return M_CA_NCOVER_PREM;

                pextra_charge_mr = INS_ptr->pextra_charge;

                printf("\n=== count premium \n");
                printf("lMins_amt_56[%d] mpremium_1[%f] pextra_charge_1[%f] mpremium_mr[%f] pextra_charge_mr[%f] \n", lMins_amt_56, mpremium_1, pextra_charge_1, mpremium_mr, pextra_charge_mr );

                /*1110308005_SC1_�w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h*/
                provision_H = 1.0; 
                if ((strcmp(ins_type, "266")==0) && (strstr(sProvDelimiter, "H;") != NULL))
                {
                    $SELECT coefficient
                       INTO $provision_H
                       FROM ca_add_provision
                      WHERE icar_type = $cal_car_id
                	AND iins_type = $ins_type
                	AND provision = 'H'
                	AND drate     = (SELECT drate
                	                   FROM ca_rate_date
                	                  WHERE icode  = $frate
                	                    AND itable = 'ca_add_provision');
                    if (NOT_FOUND)  return M_CA_NRATE_DATE;                   
                }                  
                
                /* 1.�ˮ`�M�I�O�O */
                INS_ptr_56->lPure_premium = (double)mpremium_1 * (double)provision_H * (double)short_prate *
                                            (double)(1 + INS_ptr->deviation_rate/100.0);

                /* 2.�ˮ`�W���O�O */
                INS_ptr_56->lMins_premium = (long)d45( (INS_ptr_56->lPure_premium/(1-pextra_charge_1)) ,0);
                lBef_premium56 += (long)INS_ptr_56->lMins_premium;    /* �W���O�O�t���� */

                #ifdef GCAR /* GCAR */

                /* �D�A�Ψ������«O�Ompure_prem_n�A�W���O�Omins_prem_n */

                INS_ptr_56->mpure_prem_n = INS_ptr_56->lPure_premium;
                INS_ptr_56->mprem_n = INS_ptr_56->lMins_premium;
                lBef_premium56_n += (long)INS_ptr_56->lMins_premium;


                /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N�� sProvDelimiter */
                if((strstr(sProvDelimiter, "F;") != NULL) ||
                   (strstr(sProvDelimiter, "B;") != NULL) ||
                   (strstr(sProvDelimiter, "A;") != NULL) ||
                   (strstr(sProvDelimiter, "G;") != NULL) ||
                   (strstr(sProvDelimiter, "I;") != NULL)  ) /* 56�A�Ψ������[����(F),car9804233 56�A�Τj�v���[����(B) */
                {
                    lBef_premium56  = 0;

                    /* 1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N�� sProvDelimiter*/
                    if((strstr(sProvDelimiter, "F;") != NULL) || (strstr(sProvDelimiter, "G;") != NULL) || (strstr(sProvDelimiter, "I;") != NULL) || (strstr(sProvDelimiter, "B;") != NULL))
                        INS_ptr_56->lPure_premium = (double)mpremium_1 * (double)provision_H * (double)short_prate
                                                  * (double)(1 + INS_ptr->adjust_rate);

                    INS_ptr_56->lMins_premium = (long)d45( (INS_ptr_56->lPure_premium/(1-pextra_charge_1)) ,0);
                    lBef_premium56 += (long)INS_ptr_56->lMins_premium;    /* �W���O�O�t���� */
                }

                #endif

                if (INS_ptr_56->dPdiscount >= 0)
                {
                    disc_last = 0.500000000001;
                }
                else
                {
                    disc_last = -0.500000000001;
                }

                /* 3.�p���u�f���B */
                if (cal_itype_disc[0] == '2')
                {
                    INS_ptr_56->lMdiscount=(long)((double)INS_ptr_56->lMins_premium*INS_ptr_56->dPdiscount/100.0+disc_last);
                    INS_ptr_56->mdiscount_n=(long)((double)INS_ptr_56->mprem_n*INS_ptr_56->dPdiscount/100.0+disc_last);
                }
                else
                {
                    INS_ptr_56->lMdiscount   = INS_ptr->mdiscount;
                    INS_ptr_56->mdiscount_n  = INS_ptr->mdiscount;
                }

                /* 4.�p��ñ��O�O */
                printf("���ݳW���O�O[%f]\n", INS_ptr_56->lMins_premium);
                INS_ptr_56->lMins_premium = INS_ptr_56->lMins_premium - INS_ptr_56->lMdiscount;
                printf("����ñ��O�O[%f]\n", INS_ptr_56->lMins_premium);
                printf("lBef_premium56[%f]\n", lBef_premium56);

                #ifdef GCAR /* GCAR */
                /* �D�A�Ψ���ñ��O�Omins_premium_n */
                INS_ptr_56->mins_premium_n = INS_ptr_56->mprem_n - INS_ptr_56->mdiscount_n;
                #endif

                printf("lPure_premium[%f]\n", INS_ptr_56->lPure_premium);
                printf("lMins_premium[%f]\n", INS_ptr_56->lMins_premium);

                /* 1031104004_C1,56�I�s�W����I�� */
                if( strcmp( iins_scope_tmp , "2" ) == 0 || strcmp( iins_scope_tmp , "3" ) == 0 )
                {
                    /* 1.�����M�I�O�O */
                    INS_ptr_56->lMr_pure_prem = (double)mpremium_mr * (double)provision_H * (double)short_prate *
                                                (double)(1 + INS_ptr->deviation_rate/100.0);

                    /* �]�«O�O�ӧC�A�H�P��O�O����@���A�G�h�[ msi_premium �վ�O�O */
                    cal_mr_pure_prem= (double)(mpremium_mr+msi_premium) * (double)provision_H * (double)short_prate *
                                      (double)(1 + INS_ptr->deviation_rate/100.0);

                    /* 2.�����W���O�O */
                    INS_ptr_56->lMr_ins_prem=(long)d45( (cal_mr_pure_prem/(1-pextra_charge_mr)) ,0);

                    /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N��*/
                    /* �������[����,car9804233�j�v���[���� */
                    if((strstr(sProvDelimiter, "F;") == NULL) &&
                       (strstr(sProvDelimiter, "B;") == NULL) &&
                       (strstr(sProvDelimiter, "A;") == NULL) &&
                       (strstr(sProvDelimiter, "G;") == NULL) &&
                       (strstr(sProvDelimiter, "I;") == NULL))  
                        lBef_premium56 += (long)INS_ptr_56->lMr_ins_prem;    /* �W���O�O�t���� */

                    #ifdef GCAR /* GCAR */

                    INS_ptr_56->mr_mpure_prem_n = INS_ptr_56->lMr_pure_prem;
                    INS_ptr_56->mr_mprem_n = INS_ptr_56->lMr_ins_prem;
                    lBef_premium56_n += (long)INS_ptr_56->lMr_ins_prem;
                    /* 1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N�� sProvDelimiter*/
                    if((strstr(sProvDelimiter, "F;") != NULL) ||
                       (strstr(sProvDelimiter, "B;") != NULL) ||
                       (strstr(sProvDelimiter, "A;") != NULL) ||
                       (strstr(sProvDelimiter, "G;") != NULL) ||
                       (strstr(sProvDelimiter, "I;") != NULL) 
                      ) 
                    {
                    	/* 56�A�Ψ������[����(F),car9804233 56�A�Τj�v���[����(B) */
                        /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N�� sProvDelimiter */
                        if((strstr(sProvDelimiter, "F;") != NULL) || (strstr(sProvDelimiter, "G;") != NULL) || (strstr(sProvDelimiter, "I;") != NULL) || (strstr(sProvDelimiter, "B;") != NULL))
                        {
                            INS_ptr_56->lMr_pure_prem = (double)mpremium_mr * (double)provision_H * (double)short_prate
                                                        * (double)(1 + INS_ptr->adjust_rate);
                            cal_mr_pure_prem= (double)(mpremium_mr+msi_premium) * (double)short_prate
                                                        * (double)(1 + INS_ptr->adjust_rate);
                        }
                        INS_ptr_56->lMr_ins_prem=(long)d45( (cal_mr_pure_prem/(1-pextra_charge_mr)) ,0);
                        lBef_premium56 += (long)INS_ptr_56->lMr_ins_prem;
                    }
                    #endif

                    /* 3.�����u�f���B */
                    if (cal_itype_disc[0] == '2')
                    {
                        INS_ptr_56->lMr_discount=(long)((double)INS_ptr_56->lMr_ins_prem*INS_ptr_56->dPdiscount/100.0+disc_last);
                        INS_ptr_56->mr_mdiscount_n=(long)((double)INS_ptr_56->mr_mprem_n*INS_ptr_56->dPdiscount/100.0+disc_last);
                    }
                    else
                    {
                        INS_ptr_56->lMr_discount   = 0;
                        INS_ptr_56->mr_mdiscount_n = 0;
                    }

                    /* 4.����ñ��O�O */
                    printf("�����W���O�O[%f]\n", INS_ptr_56->lMr_ins_prem);
                    INS_ptr_56->lMr_ins_prem = INS_ptr_56->lMr_ins_prem - INS_ptr_56->lMr_discount;
                    printf("����ñ��O�O[%f]\n", INS_ptr_56->lMr_ins_prem);

                    #ifdef GCAR /* GCAR */
                    INS_ptr_56->mr_mins_premium_n = INS_ptr_56->mr_mprem_n - INS_ptr_56->mr_mdiscount_n;
                    #endif

                    printf("\nlMr_pure_prem[%f]\n", INS_ptr_56->lMr_pure_prem);
                    printf("lMr_ins_prem[%f]\n", INS_ptr_56->lMr_ins_prem);
                }
                else
                {
                    INS_ptr_56->lMr_pure_prem = 0;
                    INS_ptr_56->lMr_ins_prem  = 0;
                    INS_ptr_56->lMr_discount  = 0;

                    #ifdef GCAR /* GCAR */
                    INS_ptr_56->mr_mpure_prem_n = 0;
                    INS_ptr_56->mr_mins_premium_n  = 0;
                    INS_ptr_56->mr_mprem_n  = 0;
                    INS_ptr_56->mr_mdiscount_n  = 0;
                    #endif
                }

                /** �O�O = �ˮ` + ���� **/
                INS_ptr_56->lMdiscount += INS_ptr_56->lMr_discount;
                INS_ptr_56->lPure_premium += INS_ptr_56->lMr_pure_prem;
                INS_ptr_56->lMins_premium += INS_ptr_56->lMr_ins_prem;

                #ifdef GCAR /* GCAR */
                INS_ptr_56->mins_premium_n += INS_ptr_56->mr_mins_premium_n;
                INS_ptr_56->mpure_prem_n += INS_ptr_56->mr_mpure_prem_n;
                INS_ptr_56->mprem_n += INS_ptr_56->mr_mprem_n;
                INS_ptr_56->mdiscount_n += INS_ptr_56->mr_mdiscount_n;
                #endif

                if (cal_itype_disc[0] == '1')
                {
                    INS_ptr_56->dPdiscount   = d45((double)INS_ptr_56->lMdiscount /
                                                   (double)(INS_ptr_56->lMins_premium + INS_ptr_56->lMdiscount)*100.0,2);
                }

                /* 5.�p���u�f�v,�����v,�N�z�v */
                if (strcmp(tmp_ipaid_base,"A")==0)       /* ���u�ݫ�O�O�p�� */
                {
                    INS_ptr_56->lMcommission = (long)d45( ((double)INS_ptr_56->lMins_premium*INS_ptr_56->dPcommission/100.0) ,0);
                    INS_ptr_56->lMagent      = (long)d45( ((double)INS_ptr_56->lMins_premium*INS_ptr_56->dPagent/100.0) ,0);
                }
                else if (strcmp(tmp_ipaid_base,"B")==0)  /* ���u�ݫe�O�O�p��:�u�ݫe�O�O=ñ��O�O+�u�f���B */
                {
                    INS_ptr_56->lMcommission = (long)d45( ((double)(INS_ptr_56->lMins_premium+INS_ptr_56->lMdiscount)*INS_ptr_56->dPcommission/100.0) ,0);
                    INS_ptr_56->lMagent      = (long)d45( ((double)(INS_ptr_56->lMins_premium+INS_ptr_56->lMdiscount)*INS_ptr_56->dPagent/100.0) ,0);
                }
                else
                {
                    INS_ptr_56->lMcommission = (long)d45( ((double)INS_ptr_56->lMins_premium*INS_ptr_56->dPcommission/100.0) ,0);
                    INS_ptr_56->lMagent      = (long)d45( ((double)INS_ptr_56->lMins_premium*INS_ptr_56->dPagent/100.0) ,0);
                }

                printf("-- trace INS_ptr_56->lPure_premium[%f]\n ",INS_ptr_56->lPure_premium);

                lPure_premium56 += (long)d45( INS_ptr_56->lPure_premium  ,0); /*1030523002_C1 ,fix���|�ˤ��J*/
                lMins_premium56 += INS_ptr_56->lMins_premium ;
                lMcommission56  += INS_ptr_56->lMcommission;
                lMagent56       += INS_ptr_56->lMagent;
                lMdiscount56    += INS_ptr_56->lMdiscount;

                #ifdef GCAR /* GCAR */
                lPure_premium56_n += (long)d45( INS_ptr_56->mpure_prem_n ,0);
                lMins_premium56_n += (long)d45( INS_ptr_56->mins_premium_n ,0);
                lMdiscount56_n    += INS_ptr_56->mdiscount_n;
                #endif

                INS_ptr_56=INS_ptr_56->next;
            }

            INS_ptr->bef_ins_premium = lBef_premium56;
            INS_ptr->pure_ins_premium= lPure_premium56;
            INS_ptr->ins_premium     = lMins_premium56;
            INS_ptr->mcommission     = lMcommission56;
            INS_ptr->magent          = lMagent56;
            INS_ptr->mdiscount       = lMdiscount56;

            #ifdef GCAR /* GCAR */
            INS_ptr->mprem_n        = lBef_premium56_n;
            INS_ptr->mpure_prem_n   = lPure_premium56_n;
            INS_ptr->mins_premium_n = lMins_premium56_n;
            INS_ptr->mdiscount_n    = lMdiscount56_n;
            #endif

            if (cal_itype_disc[0] == '1')
            {
                INS_ptr->pdiscount       = d45((double)INS_ptr->mdiscount/(double)INS_ptr->bef_ins_premium * 100 , 2);
            }
            goto step_9_e_iii; /* �����p��O�O�X�p�Φ����B�N�z�B�����X�p���B */
            
        }
        
        prate_1 = 0; pextra_charge = 0; mpremium = 0;
          
        /* �s��Q�ѷl���I */
        /* car_9611281 ���B�s�t�� */
        if (iins == 12 || iins == 28 || iins == 128)
        {
            /* �����ˮְt�X�s�W96�I���ˮ�,����[ñ����ˮ֪�]�� mark by sylvia 101.04.25(1010403003_C1) */
            /* -------------------------------------------------------------- */
            if (iins == 12 ) /* �s��Q�ѷl���I */
            {
                INS_ptr->damage_cover  = 0;
                INS_ptr->deduct        = 0;
            }
            INS_ptr->injured_cover = 0;
            INS_ptr->death_cover   = 0;
            cal_deduct             = INS_ptr->deduct;

            printf("���t�N��icar_series[%s],cal_deduct[%d]\n",icar_series,cal_deduct);

            $SELECT drate
               FROM ca_rate_date
              WHERE icode  = $frate
                AND itable = 'ca_rate';
            if (NOT_FOUND)  return M_CA_NRATE_DATE;

            if (iins == 12 ) /* �s��Q�ѷl���I */
            {            	
                $SELECT prate, pextra_charge/100
                   INTO $prate_1, $pextra_charge
                   FROM ca_rate
                  WHERE icar_type = $icar_series
                    AND iins_type = $ins_type
                    AND mdeduct   = $cal_deduct
                    AND drate     = (SELECT drate
                                       FROM ca_rate_date
                                      WHERE icode  = $frate
                                        AND itable = 'ca_rate');

                if (NOT_FOUND) return M_CA_NRATE;

                pextra_charge = INS_ptr->pextra_charge;

                printf("prate_1[%.20f]\n", prate_1);
                prate_1=prate_1/100.0;

                printf("Cal_ins_prem()#######12 �ѵs�I�O�Bpremium_12[%ld] prate_1[%f] series[%s]\n", premium_12, prate_1, icar_series);
                printf("INS_ptr->deviation_rate[%.20f]\n", INS_ptr->deviation_rate);
                printf("prate_1[%.20f]\n", prate_1);
                printf("premium_12[%.20d]\n", premium_12);

                /**** �«O�O ****/
                /* 1080218007-SC1-�ק�12�I�حp�⤽�� .(�«O�O*�u��)<1000 �n��������1000�A�A�h*F��T */
                INS_ptr->ins_premium = ((float)premium_12*prate_1) * ( 1 + INS_ptr->deviation_rate/100.0) * short_prate; 

                printf("INS_ptr->ins_premium[%.20f]\n", INS_ptr->ins_premium);
                printf("pextra_charge[%.20f]\n", pextra_charge);

                rChk_12_prem = 1000 * (1.0 - pextra_charge);

                printf("rChk_12_prem[%.20f]\n", rChk_12_prem);

                if (strcmp(icar_series,"10") == 0)                  /* �s���I�̧C�O�O */
                {
                    puts("�ڬO�겣��");
                    if (INS_ptr->ins_premium < rChk_12_prem)
                        INS_ptr->ins_premium = rChk_12_prem;
                }
                else
                {
                    if (INS_ptr->ins_premium < rChk_12_prem * 2)
                        INS_ptr->ins_premium = rChk_12_prem * 2;
                }
                printf("INS_ptr->ins_premium[%.20f]\n", INS_ptr->ins_premium);

                #ifdef GCAR

                INS_ptr->mpure_prem_n = INS_ptr->ins_premium;

                #endif

            }
            else if( iins == 28 || iins == 128)   /* car_9611281 ���B�s�t�� */
            {
                /* �����ˮְt�X�s�W96�I���ˮ�,����[ñ����ˮ֪�]�� mark by sylvia 101.04.25(1010403003_C1) */
                /* --------------------------------------------------------------------------------------- */
                injured_cover = INS_ptr->injured_cover;
                death_cover   = INS_ptr->death_cover;
                damage_cover  = INS_ptr->damage_cover;

                /* �s�t����w���O�I���B���o����Q�O�I�T���{��(��ګO�B)��75% */
                /* �ȴ��ܰT��,�����_�{������ modify by sylvia 100.07.26 (car990727) */
                /* 1080218008-SC1-�ק�28�I�ثO�B�p��W�h*/
                if( damage_cover >= premium_12 * NewYearDep)
                {
                    strcpy(errmsg_chk, itoa(M_CA_OVER_75_PERCENT));
                    if (strstr(errmsg_tmp, errmsg_chk) == NULL)
                    {
                        strcat(errmsg_tmp, errmsg_chk);
                        strcat(errmsg_tmp, ";");
                    }
                }
                
                $SELECT mpremium, pextra_charge/100
                   INTO $mpremium, $pextra_charge
                   FROM cover_vs_premium
                  WHERE icar_type  = $icar_series
                    AND iins_type  = $ins_type
                    AND mcoverage1 = $injured_cover
                    AND mcoverage2 = $damage_cover
                    AND mdeduct    = $cal_deduct
                    AND drate=(SELECT drate
                                 FROM ca_rate_date
                                WHERE icode  = $frate
                                  AND itable = 'cover_vs_premium');

                if (NOT_FOUND)  return M_CA_NCOVER_PREM;

                INS_ptr->ins_premium     = mpremium * short_prate;
            }

            INS_ptr->bef_ins_premium = INS_ptr->ins_premium;

            printf("IINS_TYPE:[%d] ins_premium[%lf]\n",iins,INS_ptr->ins_premium);
            printf("-- trace tmp_provision[%s]\n ",tmp_provision);
            goto step_9_e_iii;
            
        }
        printf("Cal_ins_prem()###### fcal_way[%s]\n",fcal_way);

        /*** get ���[���ڶO�v ***/
        /*1030523002_C1�GH���ڤ��D���ڤ覡�A���A������U�I�ثO�O�p�⤽�����B��A
                         ��b�̫�p��ñ��O�O�ɦA�[�W�U���ڦ]�l */
        /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N��  if(strstr(tmp_provision,"H") != NULL) */              
        if(strstr(sProvDelimiter,"H;") != NULL)
        {
            /* ���髬���[���� */
            $SELECT drate
               FROM ca_rate_date
              WHERE icode  = $frate
                AND itable = 'ca_rate';
            if (NOT_FOUND)  return M_CA_NRATE_DATE;

                                   
            /* 1080815003-SC1-��ã��-�ק���[H�BD���ڭp�⤽��  ��]�w�覡��p��
                �u�]�w�D�I05�B09�B31�B32 ���Y��	���A�]�w07�B10�B109 
                ���קK�L�״��H�γ]�w���~ �ɭP���[�I�h���Y�� �g���u��D�I*/
            /* 1110308005_SC1_�w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h */
            if( iins == 5 || iins == 9 || iins == 31 || iins == 32 || 
                iins == 149 || iins == 198 || iins == 255 || iins == 266 || iins == 302 ||
                iins == 205 || iins == 209 || iins == 231 || iins == 232 || iins == 249)
            {
                $SELECT coefficient
                   INTO $provision_H
                   FROM ca_add_provision
                  WHERE icar_type = $cal_car_id
                    AND iins_type = $ins_type
                    AND provision = 'H'
                    AND drate     = (SELECT drate
                                       FROM ca_rate_date
                                      WHERE icode  = $frate
                                        AND itable = 'ca_add_provision');
                if (NOT_FOUND)   return M_CA_NRATE_DATE;
            }
            else
                provision_H = 1.0;
           
        }
        else
            provision_H = 1.0;

           
        /* car9808043 �f�B�~���[����C */
        /*1030523002_C1�GC���ڤ��D���ڤ覡�A���A������U�I�ثO�O�p�⤽�����B��A
                         ��b�̫�p��ñ��O�O�ɦA�[�W�U���ڦ]�l */
        /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N��  sProvDelimiter if(strstr(tmp_provision,"C") != NULL) */                                  
        if(strstr(sProvDelimiter,"C;") != NULL)
        {
            /* �f�B�~���[���� */
            $SELECT drate
               FROM ca_rate_date
              WHERE icode  = $frate
                AND itable = 'ca_rate';
            if (NOT_FOUND)  return M_CA_NRATE_DATE;

            $SELECT coefficient
               INTO $provision_C
               FROM ca_add_provision
              WHERE icar_type = $cal_car_id
                AND iins_type = $ins_type
                AND provision = 'C'
                AND drate     = (SELECT drate
                                   FROM ca_rate_date
                                  WHERE icode  = $frate
                                    AND itable = 'ca_add_provision');
            if (NOT_FOUND)  return M_CA_NRATE;

            provision_C += 1.0;
        }
        else
            provision_C = 1.0;
            
        /* 1071226006-SC1-��ã��-�w���ƫ����վ�(���²v+�ĤT�H�d��) */
        /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N��  sProvDelimiter if(strstr(tmp_provision,"P") != NULL) */
        if(strstr(sProvDelimiter,"P;") != NULL)
        {
            $SELECT drate
               FROM ca_rate_date
              WHERE icode  = $frate
                AND itable = 'ca_rate';
            if (NOT_FOUND)  return M_CA_NRATE_DATE;
           
            $SELECT coefficient
               INTO $provision_P
               FROM ca_add_provision
              WHERE icar_type = (SELECT fcar_class FROM car_type WHERE fclass ='1'  AND icode=$cal_car_id)
                AND provision = 'P'
                AND iins_type = $ins_type
                AND drate     = (SELECT drate
                                   FROM ca_rate_date
                                  WHERE icode  = $frate
                                    AND itable = 'ca_add_provision');

            printf("======= provision_P=[%f]\n",provision_P);
            if (NOT_FOUND)  provision_P = 1;
        }
        else
            provision_P = 1;
        
        /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N��  sProvDelimiter if(strstr(tmp_provision,"Q") != NULL) */
        if(strstr(sProvDelimiter,"Q;") != NULL)
        {
            $SELECT coefficient
               INTO $provision_Q
               FROM ca_add_provision
              WHERE icar_type =  (SELECT fcar_class FROM car_type WHERE fclass ='1'  AND icode=$cal_car_id)
                AND provision = 'Q'
                AND iins_type = $ins_type
                AND drate     = (SELECT drate
                                   FROM ca_rate_date
                                  WHERE icode  = $frate
                                    AND itable = 'ca_add_provision');

            printf("======= provision_Q=[%f]\n",provision_Q);
            if (NOT_FOUND)  provision_Q = 1;
        }
        else
            provision_Q = 1;
            
            
        /* 1081105005-SC1-��ã��-�ק���~���w���ƫ������²v�Φۭt�B(M����)*/
        /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N��  sProvDelimiter if(strstr(tmp_provision,"M") != NULL) */
        if(strstr(sProvDelimiter,"M;") != NULL)
        {
            $SELECT coefficient
               INTO $provision_M
               FROM ca_add_provision
              WHERE icar_type =  (SELECT fcar_class FROM car_type WHERE fclass ='1'  AND icode=$cal_car_id)
                AND provision = 'M'
                AND iins_type = $ins_type
                AND drate     = (SELECT drate
                                   FROM ca_rate_date
                                  WHERE icode  = $frate
                                    AND itable = 'ca_add_provision');

            printf("======= provision_M=[%f]\n",provision_M);
            if (NOT_FOUND)  provision_M = 1;
        }
        else
            provision_M = 1;
            
            
        /*1030523002_C1�G
             (1)07�B17�B24�I���\���[D����,
             (2)�p��07�B17�B24�I���ҨϥΤ��D�I�O�O�A��"D���کΥ����L����" �u���e�v���O�O�A
                07�B17�B24�I�̷ӥ����O�_���[D���ڡA�M�w��O�O���P�_  */

        /* �����[���ڬ��w�r�p�H(D����)�O�v add by sylvia 101.06.12 (1010524008_C1) */
        /* 1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N��  sProvDelimiter if(strstr(tmp_provision,"D") != NULL) */
        if((strstr(sProvDelimiter,"D;") != NULL) )
        {
            /* �I��35,48,56,50,80,89,47,26,10,33 ����o�ϥ�D����(�b�ˮ֪����L�o)
               �I��07,17,24 �]�D�I�w���,�G���A���,provision_D = 0 */
            $SELECT drate
               FROM ca_rate_date
              WHERE icode  = $frate
                AND itable = 'ca_rate';
            if (NOT_FOUND)  return M_CA_NRATE_DATE;

            $SELECT coefficient
               INTO $provision_D
               FROM ca_add_provision
              WHERE icar_type = $qprovision
                AND provision = 'D'
                AND drate     = (SELECT drate
                                   FROM ca_rate_date
                                  WHERE icode  = $frate
                                    AND itable = 'ca_add_provision');

            printf("=====28413=== qprovision=[%s], provision_D=[%f]\n",qprovision,provision_D);
            if (NOT_FOUND)  provision_D = 0;
        }
        else
            provision_D = 0;
        
        if (iins == 07 ) provision_D = 0; /* 1080815003-SC1-�קK�D�I�w*�L�Y�ơA���[�I����*�Y��*/
        
        /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N��  J���ڤw����*/
        provision_J = 1;


        /* 1080408008-SC1-98������09+K*/
        if (iins==9)
        {
            if (fProvision_K[0]=='Y')
            {
                damage_cover  = INS_ptr->damage_cover;
                
                $SELECT coefficient
                  INTO $provision_K
                  FROM ca_add_provision
                 WHERE icar_type = $cal_car_id
                   AND provision = 'K'
                   AND iins_type = '09'
                   AND mexpense  = $damage_cover
                   AND drate     = (SELECT drate
                                      FROM ca_rate_date
                                     WHERE icode  = $frate
                                       AND itable = 'ca_add_provision');
                if (NOT_FOUND)  return M_CA_PROVISION_K;
                dbl_ProK_main_dmg=provision_K;
            }
            else
                dbl_ProK_main_dmg=1;
        }

        if (iins==209)
        {
            if (fProvision_K[0]=='Y')
            {
                damage_cover  = INS_ptr->damage_cover;
                
                $SELECT coefficient
                  INTO $provision_K
                  FROM ca_add_provision
                 WHERE icar_type = $cal_car_id
                   AND provision = 'K'
                   AND iins_type = '209'
                   AND mexpense  = $damage_cover
                   AND drate     = (SELECT drate
                                      FROM ca_rate_date
                                     WHERE icode  = $frate
                                       AND itable = 'ca_add_provision');
                if (NOT_FOUND)  return M_CA_PROVISION_K;
                dbl_ProK_main_dmg=provision_K;
            }
            else
                dbl_ProK_main_dmg=1;
        }
        
        /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N�� */
        if(strstr(sProvDelimiter,"L;") != NULL) /*1080708002-SC1-��ã��-�s�W��������L����*/
        {
            
            $SELECT coefficient
               INTO $provision_L
               FROM ca_add_provision
              WHERE icar_type = $cal_car_id
                AND provision = 'L'
                AND iins_type = $ins_type
                AND drate     = (SELECT drate
                                   FROM ca_rate_date
                                  WHERE icode  = $frate
                                    AND itable = 'ca_add_provision');

            printf("=====9703=== provision_L=[%f]\n",provision_L);
            if (NOT_FOUND)  provision_L = 1;
        }
        else
            provision_L = 1;
        printf("=====9530=== iins[%d]fProvision_K[%s]provision_K=[%f]dbl_ProK_main_dmg[%f]\n",iins,fProvision_K,provision_K,dbl_ProK_main_dmg);
        
        pcar_price = 1.0 ; /* �������[�O�Y�� */
        INS_ptr->pcar_price = pcar_price ;

        /* 1130827011_C02_�s�W�s�t��W�B���[����(Y)�A�Щ�11/1�W�u */
        if(strstr(sProvDelimiter,"Y;") != NULL)
        {

	    if( iins == 1   || iins == 5   || iins == 9   ||  
                iins == 201 || iins == 205 || iins == 209 || 
                iins == 198 )
            {

                $SELECT coefficient
                   INTO $provision_Y
                   FROM ca_add_provision
                  WHERE icar_type = $cal_car_id
                    AND iins_type = '*'
                    AND mexpense  = (SELECT max(mexpense) FROM ca_add_provision
   			              WHERE provision = 'Y'
				        AND icar_type = $cal_car_id
				        AND iins_type = '*' 
				        AND mexpense <= $pmequipment_rate
				        AND drate     = (SELECT drate
                	                                   FROM ca_rate_date
                	                                  WHERE icode  = $frate
                	                                    AND itable = 'ca_add_provision')) 
                    AND provision = 'Y'
                    AND drate     = (SELECT drate
                	               FROM ca_rate_date
                	              WHERE icode  = $frate
                	                AND itable = 'ca_add_provision');
                	                    	
                if (NOT_FOUND)  return M_CA_NRATE_DATE;	
                
            }
            else
                provision_Y = 1.0; 
        }
        else
            provision_Y = 1.0;
            
            
        strcpy(fcal_class," ");   strcpy(ical_ins," ");    	  
        prate_1= 0; mprem=0; pextra_charge = 0; wk_qpt=0;
        mpremium_sec=0;  mpremium=0; 
               	  
        switch (fcal_way[0])   /***�O�O�p���k 1:�O�v�� 2:�O�B�O�O�� 3:�O�T�I 4:�O�v�ɥ[�O�B�O�O ***/
        {
            case '1':   /* fcal_way 1:�O�v�ɭp��O�O */
            case '4':   /* fcal_way 2:�O�v�ɥ[�O�B�O�O(�ثe�ϥΥu��85,105,118,137,138�I��,�G���W�ߩ�}�t�~�@��case */

                /******* BEGIN:�̶O�v�ɭp��O�O **********/
                /*1030725001_C1 �ߦw(118)�B����(120)����[�N�B���O�I*/
                /*1100909003-SC1-�_�@�Ϯ��S�h���p�{������07+15�}���O181�I�ݨD*/
                if ((iins==1)  || (iins==5)   || (iins==9)  || (iins==8)  || (iins==85) || (iins==105)|| (iins==118)|| (iins==120)|| (iins==122)|| 
                    (iins==125)|| (iins==126) || (iins==152)|| (iins==153)|| (iins==181)|| (iins==201)|| (iins==205)|| (iins==209))
                {
                    if (strcmp(cal_car_id,"05")==0 ||
                        strcmp(cal_car_id,"06")==0 ||
                        strcmp(cal_car_id,"09")==0 ||
                        strcmp(cal_car_id,"10")==0 ||
                        strcmp(cal_car_id,"20")==0)
                        wk_qpt=qpt;


                    /* �������[�O�Y�� 104.11.16 (1021211003_C3_�T������l���O�I�O�O�p��ǤJ�������Y�ƶO�v) */
                    if ((iins!=152) && (iins!=153)) 
                    {
                        if (strcmp(cal_car_id,"03")==0 || strcmp(cal_car_id,"21")==0 || strcmp(cal_car_id,"22")==0 || strcmp(cal_car_id,"14")==0 ||
                           (IS2A(cal_car_id)) || (IS2B(cal_car_id)) || (IS2C(cal_car_id)) || (IS4A(cal_car_id)) )
                        {
                            $date   tmp_drate;

                            /* �O�v�ͮĤ� */
                            iTmp = 0;
                            $SELECT (CASE WHEN drate>='12/01/2015' THEN 1 ELSE 0 END) ,drate
                               Into $iTmp , $tmp_drate
                               FROM ca_rate_date
                              WHERE icode = $frate
                                AND itable='car_price_factor';

                            if (iTmp>0)
                            {
                                /* ���o�������[�O�Y��
                                   car103�����Gt_mcar_price,
                                   �e����J����(�t�t��):t_car_price )  */
                                printf("car_price_factor t_mcar_price[%f]\n",t_mcar_price);
                                $SELECT pcar_price  INTO $pcar_price
                                   FROM car_price_factor
                                  WHERE car_price_bgn <=  $t_mcar_price
                                    AND car_price_end  >  $t_mcar_price
                                    AND drate          =  $tmp_drate;
 
                                if (SQLCODE == SQLNOTFOUND) return M_CA_PRICE_FACTOR ;
                                /* 1061026002-�ĥΡ�89�O�v�̡A�����O�o���m��600�U�۰ʪ��[S����*/
                                iSrate = atoi(frate);
                                if(iSrate>=89) pcar_price = 1;
                                dbl_pcar_price_01   = pcar_price ;
                                INS_ptr->pcar_price = pcar_price ;
                            }
                        }
                        printf("pcar_price[%f]\n",pcar_price);
                    }      
                }


                if ((iins!=152) && (iins!=153))
                {
                    printf("Cal_ins_prem()####### fpt[%s] qpt[%f] wk_qpt[%f]\n",fpt,qpt,wk_qpt);
                    prate_1_sec = 0.0;

                    /* get �򥻫O�O,�p��v,�p���I��,������� */
                    if (fpt[0]=='P')
                    {
                        $SELECT drate
                           FROM ca_rate_date
                          WHERE icode  = $frate
                            AND itable = 'ca_rate';
                        if (NOT_FOUND)  return M_CA_NRATE_DATE;

                        if ((iins==24) || (iins==26))
                        {
                            /* 24,26�I�بS���ۭt�B���O�v  add by sylvia 103.01.06 1021210002_C1 */
                            $SELECT prate, mprem, ical_ins, fcal_class, pextra_charge/100
                               INTO $prate_1, $mprem, $ical_ins, $fcal_class, $pextra_charge
                               FROM ca_rate
                              WHERE icar_type = $cal_car_id
                                AND iins_type = $ins_type
                                AND qpt_bgn  <= $wk_qpt
                                AND qpt_end  >= $wk_qpt
                                AND drate     = (SELECT drate
                                                   FROM ca_rate_date
                                                  WHERE icode  = $frate
                                                    AND itable = 'ca_rate');

                        }
                        else if (iins==111) 
                        {
                            /* 103.04.30:1030407005_C1_�ӽзs�ӫ~�W�u-������X�O�I*/
                            $SELECT prate, mprem, ical_ins, fcal_class, pextra_charge/100
                               INTO $prate_1, $mprem, $ical_ins, $fcal_class, $pextra_charge
                               FROM ca_rate
                              WHERE icar_type = $cal_car_id
                                AND iins_type = $ins_type
                                AND mdeduct   = 1
                                AND qpt_bgn  <= $wk_qpt
                                AND qpt_end  >= $wk_qpt
                                AND drate     = (SELECT drate
                                                   FROM ca_rate_date
                                                  WHERE icode  = $frate
                                                    AND itable = 'ca_rate');
                            if (NOT_FOUND)  return M_CA_NRATE;

                            $SELECT prate, mprem, ical_ins, fcal_class, pextra_charge/100
                               INTO $prate_1_sec, $mprem, $ical_ins, $fcal_class, $pextra_charge
                               FROM ca_rate
                              WHERE icar_type = $cal_car_id
                                AND iins_type = $ins_type
                                AND mdeduct   = 2
                                AND qpt_bgn  <= $wk_qpt
                                AND qpt_end  >= $wk_qpt
                                AND drate     = (SELECT drate
                                                   FROM ca_rate_date
                                                  WHERE icode  = $frate
                                                    AND itable = 'ca_rate');
                        }
                        else if (iins==150 || iins==151)
                        {
                            /* 150�B151�I�ئۭt�B��쬰����(�T�~��)  1050801007_C1_GKGT�s�ӫ~�t�λݨD*/
                            /*1080305002-SC1_�ק�GK/GT�W�h
                                <104�O�v�̤������±���A�ͮĤ�-�o�Ӥp�󵥩�12�Ӥ뤴�⨮��1�~
                                >=104�O�v�̡A�ĥηs����A�ͮĤ�-�o�Ӥp��12�Ӥ�⨮��1�~�A�j�󵥩�12�Ӥ�⨮��2�~*/
                            printf("--- iins = 150,151 \n");
                            printf("ply2_begin[%d],dissue[%d]\n",ply2_begin,dissue);

                            car_age150151=DiffMonth(ply2_begin,dissue);

                            printf("car_age150151[%d]\n",car_age150151);
                            
                            if (atoi(frate) >=104)
                            {
                                if (car_age150151 >= 0 && car_age150151 < 12)
                                    car_age_year = 1;
                                else if (car_age150151 >= 12 && car_age150151 < 24)
                                    car_age_year = 2;
                                else
                                    car_age_year = 3;
                            }
                            else
                            {  
                                if (car_age150151 >= 0 && car_age150151 <= 12)
                                    car_age_year = 1;
                                else if (car_age150151 > 12 && car_age150151 <= 24)
                                    car_age_year = 2;
                                else
                                    car_age_year = 0;
                            }
                            printf("car_age_year[%d]\n",car_age_year);

                            $SELECT prate, mprem, ical_ins, fcal_class, pextra_charge/100
                              INTO $prate_1, $mprem, $ical_ins, $fcal_class, $pextra_charge
                              FROM ca_rate
                             WHERE icar_type = $cal_car_id
                               AND iins_type = $ins_type
                               AND mdeduct   = $car_age_year
                               AND qpt_bgn  <= $wk_qpt
                               AND qpt_end  >= $wk_qpt
                               AND drate     = (SELECT drate
                                                  FROM ca_rate_date
                                                 WHERE icode  = $frate
                                                   AND itable = 'ca_rate');
                        }
                        else
                        {
                            $SELECT prate, mprem, ical_ins, fcal_class, pextra_charge/100
                               INTO $prate_1, $mprem, $ical_ins, $fcal_class, $pextra_charge
                               FROM ca_rate
                              WHERE icar_type = $cal_car_id
                                AND iins_type = $ins_type
                                AND mdeduct   = $cal_deduct
                                AND qpt_bgn  <= $wk_qpt
                                AND qpt_end  >= $wk_qpt
                                AND drate     = (SELECT drate
                                                   FROM ca_rate_date
                                                  WHERE icode  = $frate
                                                    AND itable = 'ca_rate');
                        }
                        
                        printf("0010:cal_car_id[%s],ins_type[%s],cal_deduct[%d],SQLCODE[%d]\n", cal_car_id, ins_type, cal_deduct, SQLCODE);
                    }
                    else
                    {
                        /*1030725001_C1 �ߦw(118)�B����(120)����[�N�B���O�I*/
                        /*1100909003-SC1-�_�@�Ϯ��S�h���p�{������07+15�}���O181�I�ݨD*/
                        /*1100311005-SC1-�����¦����s�A�������I�����{���]�w137�B138�B139�B141�B142�I�� || iins==137|| iins==138*/
                        if ((strcmp(cal_car_id,"06")==0 || strcmp(cal_car_id,"10")==0 || strcmp(cal_car_id,"20")==0 )
                             && (iins==1   || iins==5  || iins==9 || iins==85 || iins==105 || iins==118 || iins==120 || iins==122 || 
                                 iins==125 || iins==126|| iins==181 || iins==201 || iins==205 || iins==209) )
                        {
                            printf("SELECT prate_1...frate[%s]\n",frate);
                 
                            $SELECT drate
                               FROM ca_rate_date
                              WHERE icode=$frate
                                AND itable='ca_rate';
                            if (NOT_FOUND)  return M_CA_NRATE_DATE;
                 
                            $SELECT prate, mprem, ical_ins, fcal_class, pextra_charge/100
                               INTO $prate_1, $mprem, $ical_ins, $fcal_class, $pextra_charge
                               FROM ca_rate
                              WHERE icar_type = $cal_car_id
                                AND iins_type = $ins_type
                                AND mdeduct   = $cal_deduct
                                AND qpt_bgn   < $wk_qpt
                                AND qpt_end  >= $wk_qpt
                                AND drate     = (SELECT drate
                                                   FROM ca_rate_date
                                                  WHERE icode  = $frate
                                                    AND itable = 'ca_rate');
                        }
                        else
                        {
                            $SELECT drate
                               FROM ca_rate_date
                              WHERE icode  = $frate
                                AND itable = 'ca_rate';
                            if (NOT_FOUND)  return M_CA_NRATE_DATE;

                            if ((iins==24) || (iins==26))
                            {
                                /* 24,26�I�بS���ۭt�B���O�v  add by sylvia 103.01.06 1021210002_C1 */
                                $SELECT prate   , mprem , ical_ins , fcal_class , pextra_charge/100
                                   INTO $prate_1, $mprem, $ical_ins, $fcal_class , $pextra_charge
                                   FROM ca_rate
                                  WHERE icar_type = $cal_car_id
                                    AND iins_type = $ins_type
                                    AND qpt_bgn  <= $wk_qpt
                                    AND qpt_end  >= $wk_qpt
                                    AND drate     = (SELECT drate
                                                       FROM ca_rate_date
                                                      WHERE icode  = $frate
                                                        AND itable = 'ca_rate');
                            }
                            else if (iins==150 || iins==151)
                            {
                                /* 150�B151�I�ئۭt�B��쬰����(�T�~��)  1050801007_C1_GKGT�s�ӫ~�t�λݨD*/
                                printf("--- iins = 150,151 \n");
                                printf("ply2_begin[%d],dissue[%d]\n",ply2_begin,dissue);
                                /*1080305002-SC1_�ק�GK/GT�W�h
                                    <104�O�v�̤������±���A�ͮĤ�-�o�Ӥp�󵥩�12�Ӥ뤴�⨮��1�~
                                    >=104�O�v�̡A�ĥηs����A�ͮĤ�-�o�Ӥp��12�Ӥ�⨮��1�~�A�j�󵥩�12�Ӥ�⨮��2�~*/
                                car_age150151=DiffMonth(ply2_begin,dissue);

                                printf("car_age150151[%d]\n",car_age150151);

                                if (atoi(frate) >=104)
                                {
                                    if (car_age150151 >= 0 && car_age150151 < 12)
                                        car_age_year = 1;
                                    else if (car_age150151 >= 12 && car_age150151 < 24)
                                        car_age_year = 2;
                                    else
                                        car_age_year = 3;
                                }
                                else
                                {  
                                    if (car_age150151 >= 0 && car_age150151 <= 12)
                                        car_age_year = 1;
                                    else if (car_age150151 > 12 && car_age150151 <= 24)
                                        car_age_year = 2;
                                    else
                                        car_age_year = 0;
                                }

                                printf("car_age_year[%d]\n",car_age_year);

                                $SELECT prate   , mprem , ical_ins , fcal_class , pextra_charge/100
                                   INTO $prate_1, $mprem, $ical_ins, $fcal_class , $pextra_charge
                                   FROM ca_rate
                                  WHERE icar_type = $cal_car_id
                                    AND iins_type = $ins_type
                                    AND mdeduct   = $car_age_year
                                    AND qpt_bgn  <= $wk_qpt
                                    AND qpt_end  >= $wk_qpt
                                    AND drate     = (SELECT drate
                                                       FROM ca_rate_date
                                                      WHERE icode  = $frate
                                                        AND itable = 'ca_rate');
                            }
                            else
                            {
                                $SELECT prate   , mprem , ical_ins , fcal_class , pextra_charge/100
                                   INTO $prate_1, $mprem, $ical_ins, $fcal_class , $pextra_charge
                                   FROM ca_rate
                                  WHERE icar_type = $cal_car_id
                                    AND iins_type = $ins_type
                                    AND mdeduct   = $cal_deduct
                                    AND qpt_bgn  <= $wk_qpt
                                    AND qpt_end  >= $wk_qpt
                                    AND drate     = (SELECT drate
                                                       FROM ca_rate_date
                                                      WHERE icode  = $frate
                                                        AND itable = 'ca_rate');
                            }
                        }
                    }

                    if (NOT_FOUND) return M_CA_NRATE;
                    prate_1=prate_1/100.0;
                    prate_1_sec=prate_1_sec/100.0;

                    printf("Cal_ins_prem()### iins_type[%d],prate_1[%f]\n",iins,prate_1);
                }

                /* ical_ins:�p���I��, fcal_class:�O�B�O�O�O */
                code = Calculate_cover_prem(INS_ptr,ical_ins,fcal_class,iins);
                if (code != SUCCESS) return code;
                
                /******* END:�̶O�v�ɭp��O�O **********/
                break;

            case '2':    /* fcal_way 2:�O�B�O�O�ɱo��O�O */

                /******* BEGIN:�̫O�B�O�O�ɭp��O�O **********/
                /* �ѳ��'��'�אּ���'�d' */
                injured_cover = INS_ptr->injured_cover;
                death_cover   = INS_ptr->death_cover;
                damage_cover  = INS_ptr->damage_cover;

                printf("Cal_ins_prem():CASE 2  inj[%ld] dea[%ld] dam[%ld]\n", injured_cover, death_cover, damage_cover);
                printf("0--cal_deduct[%d]\n",cal_deduct);
                /* CA_CONS */
                printf("-- trace insurance_cover_count[%d]\n ",insurance_cover_count);
                if( insurance_cover_count != 0)	/* ply_ins_cover ����� */
                {
                    /* �t�X�q���ĤG���q, cal_ply_ins_cover�s�W�ǤJ�Ѽ� */
                    /* �t�X��椣�ˮֳq�����v, �T�w�ǫO�����O=P(�O��) modify by sylvia 101.02.07 */
                    rtncode = cal_ply_ins_cover( &iins, IfirstPlyInsCover, cal_car_id, frate,
                                                 &short_prate, abn_type, fdiscount, cal_itype_disc,
                                                 INS_ptr->mdiscount, &INS_ptr->pdiscount,
                                                 tmp_provision, &INS_ptr->adjust_rate, INS_ptr->deviation_rate,
                                                 broker2, INS_ptr->safe_rate, INS_ptr->manage_rate,
                                                 INS_ptr->educated_rate, INS_ptr->pshipping,
                                                 fstart2, officer2, iroute, irate_type2, iroute_comm2, bzfrom2,"P",
                                                 ply2_period,v_sMsg);
                    if( rtncode != M_CM_OK)
                        return rtncode;

                    INS_ptr->ins_premium     = 0;
                    INS_ptr->bef_ins_premium = 0;
                    INS_ptr->pure_ins_premium = 0;
                    #ifdef GCAR
                    INS_ptr->mins_premium_n   = 0;
                    INS_ptr->mprem_n = 0;
                    INS_ptr->mpure_prem_n = 0;
                    #endif

                    IcurrPlyInsCover = IfirstPlyInsCover;

                    printf(" after cal_ply_ins_cover\n");

                    while( IcurrPlyInsCover)
                    {
                        if( iins == atoi( IcurrPlyInsCover->iins_type))
                        {
                            INS_ptr->ins_premium += IcurrPlyInsCover->mprem;
                            INS_ptr->bef_ins_premium += IcurrPlyInsCover->mprem;
                            INS_ptr->pure_ins_premium += IcurrPlyInsCover->mpure_prem;
                            INS_ptr->pextra_charge = IcurrPlyInsCover->pextra_charge;
                            INS_ptr->pbusiness = IcurrPlyInsCover->pbusiness;

                            #ifdef GCAR
                            INS_ptr->mins_premium_n += IcurrPlyInsCover->mcover_prem_n;
                            INS_ptr->mprem_n += IcurrPlyInsCover->mprem_n;
                            INS_ptr->mpure_prem_n += IcurrPlyInsCover->mpure_prem_n;
                            #endif

                            printf("   IcurrPlyInsCover->iins_type    [%s]\n"
                                   "   IcurrPlyInsCover->icover_type  [%s]\n"
                                   "   IcurrPlyInsCover->mcover       [%d]\n"
                                   "   IcurrPlyInsCover->mcover_prem  [%d]\n"
                                   "   IcurrPlyInsCover->mdiscount    [%d]\n"
                                   "   IcurrPlyInsCover->mprem        [%d]\n"
                                   "   IcurrPlyInsCover->mpure_prem   [%f]\n"
                                   "   IcurrPlyInsCover->pextra_charge[%f]\n"
                                   "   IcurrPlyInsCover->mcover_prem_n[%d]\n",
                                       IcurrPlyInsCover->iins_type,
                                       IcurrPlyInsCover->icover_type,
                                       IcurrPlyInsCover->mcover,
                                       IcurrPlyInsCover->mcover_prem,
                                       IcurrPlyInsCover->mdiscount,
                                       IcurrPlyInsCover->mprem,
                                       IcurrPlyInsCover->mpure_prem,
                                       IcurrPlyInsCover->pextra_charge,
                                       IcurrPlyInsCover->mcover_prem);
                        }
                        IcurrPlyInsCover = IcurrPlyInsCover->next;
                    }
                    printf("�W���O�O INS_ptr->ins_premium[%lf]\n",INS_ptr->ins_premium);
                    printf("�«O�O   INS_ptr->pure_ins_premium[%lf]\n",INS_ptr->pure_ins_premium);

                    INS_ptr->pure_ins_premium   = (long)d45( INS_ptr->pure_ins_premium ,0);
                    bef_premium  = bef_premium + (long)INS_ptr->ins_premium;
                    /*1030523002_C1*/
                    if (iins == 87)
                    {
                        premium_3132_n = premium_3132_n + INS_ptr->mpure_prem_n;
                    }
                    pure_premium = pure_premium + (long)INS_ptr->pure_ins_premium;
                    INS_ptr->mpure_prem_n   = (long)d45( INS_ptr->mpure_prem_n ,0);
                }
                else if (!IsBlankNull(isame_ins))
                {   
                    /* 31,32,36,37,71,72,29,30,38,39,113,114,149,301,302 */
                    $SELECT drate
                       FROM ca_rate_date
                      WHERE icode=$frate
                        AND itable='cover_vs_premium';
                    if (NOT_FOUND)  return M_CA_NRATE_DATE;

                    if (iins==71 || iins==72)
                    {
                        /* car9606151 �H�ۭt�B���o�򥻯«O�O */
                        if (iins==72 && !Scan_INS_TYPE(71))  return M_CA_71;

                        $SELECT mpremium, pextra_charge/100
                           INTO $mpremium, $pextra_charge
                           FROM cover_vs_premium
                          WHERE icar_type=$cal_car_id
                            AND iins_type=$ins_type
                            AND mcoverage2=$damage_cover
                            AND mdeduct = $cal_deduct
                            AND drate=(SELECT drate
                                         FROM ca_rate_date
                                        WHERE icode=$frate
                                          AND itable='cover_vs_premium');
                    }
                    else if (iins==29 || iins==30 || iins==124 || iins==301 || iins==302 || iins==530)
                    {
                        if (iins==30 )
                        {
                            /* 140407003_C1_�ӽзs�ӫ~�@�~-���ľ��c�q�~�H���T����X�O�I(104.11.11) */
                            /* 1100415003-SC1-���ά�-�s�W2�~�������W�B�d���I�ӫ~����     �����ӫO30�����ӫO�I�� 31+32  /  113+114 */
                            if (!Scan_INS_TYPE(31) && !Scan_INS_TYPE(133) && !Scan_INS_TYPE(113) && !Scan_INS_TYPE(231))  return M_CA_INS31;

                            strcpy(cal_deduct_c,itoa(cal_deduct));

                            if (IsFcomp24(cal_deduct_c))
                            {
                                if (!Scan_INS_TYPE(24))  return M_CA_INS24;
                            }
                            
                            /* 1100415003-�s�W2�~�������W�B�d���I�ӫ~����   ���� �ۭt�B�O�v�� 1/2 �~��  �T���S��*/
                            $SELECT mpremium, pextra_charge/100
                              INTO $mpremium, $pextra_charge
                              FROM cover_vs_premium
                             WHERE icar_type  = $cal_car_id
                               AND iins_type  = $ins_type
                               AND mcoverage1 = $injured_cover
                               AND mcoverage2 = $damage_cover
                               AND mdeduct    = 1+10*$cal_deduct
                               AND drate=(SELECT drate
                                            FROM ca_rate_date
                                           WHERE icode  = $frate
                                             AND itable = 'cover_vs_premium');
                            if(ply2_period > 12 )
                            { 
                                if (strcmp(cal_car_id,"01")==0 ||
                                    strcmp(cal_car_id,"02")==0 ||
                                    strcmp(cal_car_id,"32")==0 ||
                                    strcmp(cal_car_id,"34")==0 ||
                                    strcmp(cal_car_id,"35")==0)
                                {                    
                                    $SELECT mpremium, pextra_charge/100
                                      INTO $mpremium_sec, $pextra_charge
                                      FROM cover_vs_premium
                                     WHERE icar_type  = $cal_car_id
                                       AND iins_type  = $ins_type
                                       AND mcoverage1 = $injured_cover
                                       AND mcoverage2 = $damage_cover
                                       AND mdeduct    = 2+10*$cal_deduct
                                       AND drate=(SELECT drate
                                                    FROM ca_rate_date
                                                   WHERE icode  = $frate
                                                     AND itable = 'cover_vs_premium');                                                
                                }
                                else
                                    mpremium_sec = 0;
                            }
                        }
                        
                        if ( iins==301 || iins==302 || iins==530)
                        {
                            /* 140407003_C1_�ӽзs�ӫ~�@�~-���ľ��c�q�~�H���T����X�O�I(104.11.11) */ 
                            /* 1110308005_SC1_�w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h */
                            if (!Scan_INS_TYPE(31) && !Scan_INS_TYPE(133) && !Scan_INS_TYPE(231) && !Scan_INS_TYPE(531))  return M_CA_INS31;

                            strcpy(cal_deduct_c,itoa(cal_deduct));

                            if (IsFcomp24(cal_deduct_c))
                            {
                                if (!Scan_INS_TYPE(24))  return M_CA_INS24;
                            }
                             
                            $SELECT mpremium, pextra_charge/100
                               INTO $mpremium, $pextra_charge
                               FROM cover_vs_premium
                              WHERE icar_type  = $cal_car_id
                                AND iins_type  = $ins_type
                                AND mcoverage1 = $injured_cover
                                AND mcoverage2 = $damage_cover
                                AND mdeduct    = $cal_deduct
                                AND drate=(SELECT drate
                                             FROM ca_rate_date
                                            WHERE icode  = $frate
                                              AND itable = 'cover_vs_premium');
                        }

                        if (iins==29 || iins==124)
                        {
                            /* 29�I�ضO�v�p��վ�(�[�p32�I�ثO�B) add by sylvia 101.10.24 (1011001003_C1)
                               fcheck29_1 = 0 ���� 29�I�ثO�O�p�F�ĥ��¨�, mcover1_32 =0 (�T�w)
                               fcheck29_1 = 1 ���� 29�I�ثO�O�p�F�ĥηs��(�[�p32�I�ثO�B)
                               mcover1_32 ��32�O�B�̧C�ŶZ(�Y29�I�ثO�B1)
                                        20�U <= 32�I�ثO�B < 50�U, 29�I�ثO�B1=20�U
                                        50�U <= 32�I�ثO�B <= 100�U, 29�I�ثO�B1=50�U
                                        32�I�O�B<20�U��32�I�O�B>100�U,���i�ӫO
                            --------------------------------------------------------------------------   */


                            if ((mcover1_32 >= 200000) && (mcover1_32 < 500000))
                                mcover1_32 = 200000;
                            else if ((mcover1_32 >= 500000) && (mcover1_32 <= 1000000))
                                mcover1_32 = 500000;
                            else 
                                mcover1_32 = 0;

                            printf("mcover1_32=[%f]\n",mcover1_32);

                            $SELECT mpremium, pextra_charge/100
                              INTO $mpremium, $pextra_charge
                              FROM cover_vs_premium
                             WHERE icar_type  = $cal_car_id
                               AND iins_type  = $ins_type
                               AND mcoverage1 = $mcover1_32
                               AND mcoverage2 = $damage_cover
                               AND mdeduct    = $cal_deduct
                               AND drate=(SELECT drate
                                            FROM ca_rate_date
                                           WHERE icode  = $frate
                                             AND itable = 'cover_vs_premium');

                            printf("---- cal_deduct = [%d]mpremium=[%lf]pextra_charge=[%f]\n",cal_deduct,mpremium,pextra_charge);
                        }
                    }
                    else if ((iins == 38) || (iins == 39))
                    {
                        /* ����1:�H�ۭt�B(���{��||����)���o�򥻯«O�O
                        /* ����2:�ۭt�B205:�e2�X�����{��, ��1�X������.
                        /* ����3:���֭p�� = �s�y�~ �� �_�O�~
                        /* ����4:����5�~�H�W--���t5�~�� ( > 5)
                                 ����5�~�H�U--�t5�~ ( <= 5)
                                 �]�W,�Y���֤��~, ���H�ۭt�B=200�p��O�O */
                        iCar_age = atoi(cm_eyear_str(ply2_begin)) - atoi(pro_year); /* �D���ϴ��I�ب��� */
                        if ( iCar_age <= 0)   iCar_age = 1 ; /* ���~��1�~ */
                        else if ( iCar_age >= 9)   iCar_age = 9 ; /* �j��9�~��9�~ */

                        qday = INS_ptr->qday;
                        iCar_age = qday * 10 + iCar_age;

                        $SELECT a.mpremium, a.pextra_charge/100
                           INTO $mpremium, $pextra_charge
                           FROM cover_vs_premium a
                          WHERE a.icar_type=$cal_car_id
                            AND a.iins_type=$ins_type
                            AND a.mcoverage1 = $injured_cover
                            AND a.mcoverage2 = $damage_cover
                            AND drate=(SELECT drate
                                         FROM ca_rate_date
                                        WHERE icode=$frate
                                          AND itable='cover_vs_premium')
                            AND mdeduct = (select max(mdeduct) from cover_vs_premium
                                                where icar_type = a.icar_type
                                                  and iins_type = a.iins_type
                                                  and mcoverage1 = a.mcoverage1
                                                  and mcoverage2 = a.mcoverage2
                                                  and drate = a.drate
                                                  and mdeduct < $iCar_age
                                                  and ((mdeduct- mod(mdeduct,$qday))/10 = $qday));
                    }
                    else  /* 31,32,36,37,77,78,109,113,114,149 */
                    {
                        printf("Cal_ins_prem()#######31,32,36,37,77,78,149 ins_tp[%s]\n",ins_type);
                        printf("Cal_ins_prem()#######31,32,36,37,77,78,149 cal_car_id[%s] inj[%ld] dam[%ld]\n", cal_car_id, injured_cover, damage_cover);
                        /*1050106012_C1 �ӽЭץ���O�ۥΨT����X�I(77_78_87)�ӫO�W�h:�i���[�W�B�d���I-�򥻫�(29)*/
                        /* car9902082 32�I���^���O�B�O�O�ɦh�P�_�ۭt�B */
                        /* 1070813004-SC1-�s�W164�B165�d���O�I�ӫ~*/
                        if (iins==32 || iins==132 || iins==134 || iins==78 || iins==149 || iins==232 || iins==332 || iins==249 || iins==532)
                        {
                            pDeduct_rate = 0.0;
                            mcover1_32 = damage_cover; 	/* �O�d32�I�ثO�B, ��29�I�ثO�O�p��ϥ� add by sylvia 101.10.24 (1011001003_C1) */
                            $SELECT mpremium, pextra_charge/100, nvl(msi_premium,0.0)/100
                               INTO $mpremium, $pextra_charge ,$pDeduct_rate
                               FROM cover_vs_premium
                              WHERE icar_type  = $cal_car_id
                                AND iins_type  = $ins_type
                                AND mcoverage1 = $injured_cover
                                AND mcoverage2 = $damage_cover
                                AND mdeduct    = $cal_deduct
                                AND drate=(SELECT drate
                                             FROM ca_rate_date
                                            WHERE icode  = $frate
                                              AND itable = 'cover_vs_premium');
                        }
                        else if (iins==31 || iins==131 || iins==133 || iins==77 || iins==231 || iins==331 || iins==531)
                        {
                            /*1050106012_C1 �ӽЭץ���O�ۥΨT����X�I(77_78_87)�ӫO�W�h:�i���[�W�B�d���I-�򥻫�(29)*/
                            /* 31�I�ؼW�[�ۭt�B�P�_ modify by sylvia 102.10.18 (1021004001_C1) */
                            pDeduct_rate = 0.0;
                            mcover1_31 = injured_cover; /* �O�d31�I�ثO�B, ��109�I�ثO�O�p��ϥ� add by larry 102.11.22 (1021001004_C1) */
                            $SELECT mpremium, pextra_charge/100, nvl(msi_premium,0.0)/100
                               INTO $mpremium, $pextra_charge ,$pDeduct_rate
                               FROM cover_vs_premium
                              WHERE icar_type  = $cal_car_id
                                AND iins_type  = $ins_type
                                AND mcoverage1 = $injured_cover
                                AND mcoverage2 = $damage_cover
                                AND mdeduct    = $cal_deduct
                                AND drate=(SELECT drate
                                             FROM ca_rate_date
                                            WHERE icode  = $frate
                                              AND itable = 'cover_vs_premium');
                        }
                        else if (iins==109)
                        {
                            $SELECT mpremium, pextra_charge/100
                               INTO $mpremium, $pextra_charge
                               FROM cover_vs_premium
                              WHERE icar_type  = $cal_car_id
                                AND iins_type  = $ins_type
                                AND mcoverage1 = $mcover1_31
                                AND mcoverage2 = $death_cover
                                AND drate=(SELECT drate
                                             FROM ca_rate_date
                                            WHERE icode  = $frate
                                              AND itable = 'cover_vs_premium');
                        }
                        else if (iins==113 || iins==114) /* 103.04.30:1030407005_C1_�ӽзs�ӫ~�W�u-������X�O�I*/
                        {
                            /* 1070313002-SC �}��ۭt�B�]�w */                       
                            $SELECT mpremium, pextra_charge/100
                              INTO $mpremium, $pextra_charge
                              FROM cover_vs_premium
                             WHERE icar_type  = $cal_car_id
                               AND iins_type  = $ins_type
                               AND mcoverage1 = $injured_cover
                               AND mcoverage2 = $damage_cover
                               AND mdeduct    = 1+10*$cal_deduct
                               AND drate=(SELECT drate
                                            FROM ca_rate_date
                                           WHERE icode  = $frate
                                             AND itable = 'cover_vs_premium');
                            $SELECT mpremium, pextra_charge/100
                              INTO $mpremium_sec, $pextra_charge
                              FROM cover_vs_premium
                             WHERE icar_type  = $cal_car_id
                               AND iins_type  = $ins_type
                               AND mcoverage1 = $injured_cover
                               AND mcoverage2 = $damage_cover
                               AND mdeduct    = 2+10*$cal_deduct
                               AND drate=(SELECT drate
                                            FROM ca_rate_date
                                           WHERE icode  = $frate
                                             AND itable = 'cover_vs_premium');
                        }
                        else if (iins==164 || iins==165 )
                        {
                            $SELECT mpremium, pextra_charge/100
                               INTO $mpremium, $pextra_charge 
                               FROM cover_vs_premium
                              WHERE icar_type  = $cal_car_id
                                AND iins_type  = $ins_type
                                AND mcoverage1 = $injured_cover
                                AND mcoverage2 = $damage_cover
                                AND mdeduct    = $cal_deduct
                                AND drate=(SELECT drate
                                             FROM ca_rate_date
                                            WHERE icode  = $frate
                                              AND itable = 'cover_vs_premium');
                        }
                        else
                        {
                            $SELECT mpremium, pextra_charge/100
                               INTO $mpremium, $pextra_charge
                               FROM cover_vs_premium
                              WHERE icar_type  = $cal_car_id
                                AND iins_type  = $ins_type
                                AND mcoverage1 = $injured_cover
                                AND mcoverage2 = $damage_cover
                                AND drate=(SELECT drate
                                             FROM ca_rate_date
                                            WHERE icode  = $frate
                                              AND itable = 'cover_vs_premium');
                        }
                    }

                    if (NOT_FOUND)  return M_CA_NCOVER_PREM;

                    printf("Cal_ins_prem()#######iins[%d] mpremium[%lf]\n",iins, mpremium);
                    printf("-- trace111 psex_age2[%f]\n ",psex_age2);
                    /*1030523002_C1, premium_3132���� premium_3132_n, �s�񤣧t������[���ڧ��«O�O
                                     �î����p�⤽������"provision_H"(�אּ�Pprovision_D �ۦP�覡) */

                    if (iins==31  || iins==32  || iins==36  || iins==37  || iins==77  || iins==78  || 
                        iins==113 || iins==114 || iins==131 || iins==132 || iins==133 || iins==134 || iins==149 ||
                        iins==231 || iins==232 || iins==331 || iins==332 || iins==249 || iins==531 || iins==532)
                    {
                        if (fcar_class2[0]=='1')  /* �ۥΨ� */
                        {
                            if (strcmp(cal_car_id,"03")==0 ||
                                strcmp(cal_car_id,"04")==0 ||
                                strcmp(cal_car_id,"22")==0)
                            {
                                if (assuredf[0]=='1' ||
                                    assuredf[0]=='3' ||
                                    assuredf[0]=='5')
                                {
                                    if (iins==31 || iins==32 || iins==133 || iins==134 || iins==149 ||
                                        iins==231|| iins==232|| iins==249 || iins==531 || iins==532)
                                    {
                                        printf("-- trace1 psex_age2[%f]\n ",psex_age2);
                                        printf("-- trace1 plia_acc2[%f]\n ",plia_acc2);
                                        printf("-- trace1 short_prate[%f]\n ",short_prate);

                                        INS_ptr->ins_premium = mpremium*(psex_age2+plia_acc2)*short_prate;
                                        /* ���s�I�O�O�p���¦ */
                                        premium_3132_n = premium_3132_n + mpremium*(psex_age2+plia_acc2);

                                        if (iins==31||iins==133||iins==231||iins==531)
                                        {
                                            ins_premium31 = INS_ptr->ins_premium;
                                        }

                                    }
                                    else if (iins==77 || iins==78)    /* 77,78���p�F�ƥ[��O */
                                    {
                                        printf("========= 1. iins=[%d]premium_3132=[%f]\n",iins,premium_3132);
                                        INS_ptr->ins_premium = mpremium*INS_ptr->psex_age*short_prate;
                                        /* ���s�I�O�O�p���¦ */
                                        premium_3132_n = premium_3132_n + mpremium*INS_ptr->psex_age;
                                        printf("========= 2. iins=[%d]premium_3132=[%f]\n",iins,premium_3132);
                                    }
                                    else /* 36,37,113,114 ���p�F�ƥ[��O */
                                    {
                                        INS_ptr->ins_premium = mpremium*INS_ptr->psex_age*short_prate;
                                        /* ���s�I�O�O�p���¦ */
                                        premium_3132_n = premium_3132_n + mpremium*INS_ptr->psex_age;
                                    }

                                    INS_ptr->bef_ins_premium = INS_ptr->ins_premium;
                                }
                                else
                                {
                                    if (iins==31 || iins==32 || iins==133 || iins==134 || iins==149 ||
                                        iins==231|| iins==232|| iins==249 || iins==531 || iins==532)
                                    {
                                        INS_ptr->ins_premium = mpremium*(1.0+plia_acc2)*short_prate;
                                        /* ���s�I�O�O�p���¦ */
                                        premium_3132_n = premium_3132_n + mpremium*(1.0+plia_acc2);

                                        if (iins==31||iins==133||iins==231||iins==531)
                                        {
                                            ins_premium31 = INS_ptr->ins_premium;
                                        }

                                    }
                                    else if (iins==77 || iins==78)    /* 77,78���p�F�ƥ[��O */
                                    {
                                        INS_ptr->ins_premium = mpremium*(1.0)*short_prate;
                                        /* ���s�I�O�O�p���¦ */
                                        premium_3132_n = premium_3132_n + mpremium*(1.0);
                                    }
                                    else /* 36,37���p�F�ƥ[��O */
                                    {
                                        INS_ptr->ins_premium = mpremium*(1.0)*short_prate;
                                        /* ���s�I�O�O�p���¦ */
                                        premium_3132_n = premium_3132_n + mpremium*(1.0);
                                    }

                                    INS_ptr->bef_ins_premium = INS_ptr->ins_premium;
                                }
                            }
                            else
                            {
                                if (iins==31 || iins==32 || iins==133 || iins==134 || iins==149 ||
                                    iins==231|| iins==232|| iins==249 || iins==531 || iins==532)
                                {
                                    printf("-- trace2 psex_age2[%f]\n ",psex_age2);
                                    INS_ptr->ins_premium = mpremium*(1.0+plia_acc2)*short_prate;
                                    /* ���s�I�O�O�p���¦ */
                                    premium_3132_n = premium_3132_n + mpremium*(1.0+plia_acc2);

                                    if (iins==31||iins==133||iins==231||iins==531)
                                    {
                                        ins_premium31 = INS_ptr->ins_premium;
                                    }
                                }
                                else if (iins==77 || iins==78)        /* 77,78���p�F�ƥ[��O */
                                {
                                    INS_ptr->ins_premium = mpremium*(1.0)*short_prate;
                                    /* ���s�I�O�O�p���¦ */
                                    premium_3132_n = premium_3132_n + mpremium*(1.0);
                                }
                                else if (iins==113 || iins==114)
                                {
                                    if(ply2_period <= 12 )
                                    {       /* <= 1�~ */
                                        INS_ptr->ins_premium = mpremium*(1.0)*short_prate;

                                    }
                                    else if( ply2_period == 24 )
                                    {  
                                    	/* 1�~11�Ӥ�H�W��2�~�� */
                                        INS_ptr->ins_premium = mpremium_sec*(1.0)*short_prate;
                                    }
                                    else if((ply2_period > 12) && (ply2_period < 24))
                                    {  
                                    	/* �j��1�~�B �p�� 1�~11�Ӥ� */
                                        INS_ptr->ins_premium =  mpremium +((mpremium_sec-mpremium) * (iSecondYear2/12.0));
                                    }
                                    else
                                    {
                                        return M_CA_47_PERIOD; /*4533=�ӫO�~�����~�A�Ь��ӫO��*/
                                    }
                                }
                                else /* 36,37���p�F�ƥ[��O */
                                {
                                    INS_ptr->ins_premium = mpremium*(1.0)*short_prate;
                                    /* ���s�I�O�O�p���¦ */
                                    premium_3132_n = premium_3132_n + mpremium*(1.0);
                                }

                                INS_ptr->bef_ins_premium = INS_ptr->ins_premium;
                            }
                        }
                        else /** fcar_class2[0]=='2' **/
                        {   
                            /* ��~�� */
                            if (iins==31 || iins==32 || iins==133 || iins==134 || iins==149 ||
                                iins==231|| iins==232|| iins==249 || iins==531 || iins==532 )
                            {
                                INS_ptr->ins_premium     = mpremium*(1+plia_acc2)*short_prate;
                                /* ���s�I�O�O�p���¦ */
                                premium_3132_n = premium_3132_n + mpremium*(1+plia_acc2);
                                
                                /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X J���ڤw����*/
                                if (iins==31||iins==133||iins==231||iins==531)
                                {
                                    ins_premium31 = INS_ptr->ins_premium;
                                }

                            }
                            else if (iins == 77 || iins == 78)  /* 77,78 */
                            {
                                INS_ptr->ins_premium     = mpremium*(1.0)*short_prate;
                                /* ���s�I�O�O�p���¦ */
                                premium_3132_n = premium_3132_n + mpremium*(1.0);
                            }
                            else if (iins == 131 || iins == 132 || iins == 331 || iins == 332)
                            {
                            	/* 1030902003_C1 ���N���I�@�Υ��x�ק�:�s�W�u�p�{���ĤT�H�d���I�v*/
                                printf("-- trace pDeduct_rate[%f]\n ",pDeduct_rate);
                                printf("-- trace plia_acc2[%f]\n ",plia_acc2);

                                /* �«O�I�O �� �򥻯«O�O �� (1�Ϧۭt�B����v) �� (1�Ͻߴڬ����Y��) */
                                INS_ptr->ins_premium     = mpremium*(1+pDeduct_rate)*(1+plia_acc2)*short_prate;
                                /* ���s�I�O�O�p���¦ */
                                premium_3132_n = premium_3132_n + mpremium*(1.0);
                            }
                            else /* 36,37 */
                            {
                                INS_ptr->ins_premium     = mpremium*(1.0)*short_prate;
                                /* ���s�I�O�O�p���¦ */
                                premium_3132_n = premium_3132_n + mpremium*(1.0);
                            }
                            INS_ptr->bef_ins_premium = INS_ptr->ins_premium;
                        }
                        printf("31,32,36,37,77,78@@@@@ fcar_class2[%s],cal_car_id[%s],assuredf[%s]\n",fcar_class2,cal_car_id,assuredf);
                        printf("31,32,36,37,77,78@@@@@ ins_premium[%lf]\n",INS_ptr->ins_premium);
                        printf("31,32,36,37,77,78@@@@@ bef_ins_premium[%lf]\n",INS_ptr->bef_ins_premium);
                        printf("31,32,36,37,77,78@@@@@ premium_3132_n[%lf]\n",premium_3132_n);
                    }
                    else if (iins==109)
                    {
                        /* 109 �I�د«O�O = 31�I�د«O�O*109�I�ؼW�B���ƫY�� add by larry 102.11.22 (1021001004_C1)*/
                        /* 1080815003-SC1-��ã��-�ק靈���[H�BD���ڭp�⤽��-���PQK */
                        INS_ptr->ins_premium = ins_premium31*dbl_ProH_main_lia*(mpremium/100.0);
                        INS_ptr->bef_ins_premium = INS_ptr->ins_premium;

                        printf("109@@@@@ ins_premium[%lf]\n",INS_ptr->ins_premium);
                        printf("109@@@@@ bef_ins_premium[%lf]\n",INS_ptr->bef_ins_premium);
                    }
                    else if (iins==30)  /*1100415003-SC1-���ά�-�s�W2�~�������W�B�d���I�ӫ~����*/
                    {
                        
                        if(ply2_period <= 12 )
                        {
                            /* <= 1�~ */
                            INS_ptr->ins_premium = mpremium*(1.0)*short_prate;
                               
                        }
                        else if( ply2_period == 24 )
                        {  
                            /* 1�~11�Ӥ�H�W��2�~�� */
                            INS_ptr->ins_premium = mpremium_sec*(1.0)*short_prate;
                               
                        }
                        else if((ply2_period > 12) && (ply2_period < 24))
                        {  
                            /* �j��1�~�B �p�� 1�~11�Ӥ� */
                            INS_ptr->ins_premium =  mpremium +
                                     ((mpremium_sec-mpremium) * (iSecondYear2/12.0));
                        }
                        else
                        {
                            return M_CA_47_PERIOD; /*4533=�ӫO�~�����~�A�Ь��ӫO��*/
                        }    
                        
                        INS_ptr->bef_ins_premium = mpremium*short_prate;  /*** round ***/
                        
                    }
                    else  /* iins != 31,32,36,37,77,78,109 */
                    {
                        INS_ptr->ins_premium     = mpremium*short_prate;  /*** round ***/
                        INS_ptr->bef_ins_premium = mpremium*short_prate;  /*** round ***/

                        printf("71,72@@@@@ ins_premium[%lf]\n",INS_ptr->ins_premium);
                    }
                }
                else
                {
                    printf("1--cal_deduct[%d]\n",cal_deduct);
                    /* 14,61,65,68,69,25,51,52,47,27,101,102,103,104 */
                    /**************************************************/
                    /*  CKI 25 �I�ت�insurance_type.fcal_way='1'      */
                    /*  means�H�O�v�p��O�O,�ҥH�H�U���޿�w���A��    */
                    /**************************************************/
                    $SELECT drate
                       FROM ca_rate_date
                      WHERE icode  = $frate
                        AND itable = 'cover_vs_premium';
                    if (NOT_FOUND)  return M_CA_NRATE_DATE;

                    if (iins==25)   /*** ���ĶO�� ***/
                    {
                        $SELECT mpremium, pextra_charge/100
                           INTO $mpremium, $pextra_charge
                           FROM cover_vs_premium
                          WHERE icar_type  = $cal_car_id
                            AND iins_type  = $ins_type
                            AND mcoverage1 = $injured_cover
                            AND drate=(SELECT drate
                                         FROM ca_rate_date
                                        WHERE icode  = $frate
                                          AND itable = 'cover_vs_premium');
                        if (NOT_FOUND)  return M_CA_NCOVER_PREM;

                        printf("25@@@@@ basic prem[%lf] short_prate[%lf]\n",mpremium,short_prate);

                        INS_ptr->ins_premium     = ((float)damage_cover/(float)injured_cover)*mpremium*short_prate; /*** round ***/
                        INS_ptr->bef_ins_premium = ((float)damage_cover/(float)injured_cover)*mpremium*short_prate; /*** round ***/
                    }
                    else if (iins == 14 || iins == 61 || iins == 65 ||
                             iins == 68 || iins == 69 || iins == 19 ||
                             iins == 97 || iins == 27 ||
                             iins == 108|| iins == 157
                            )
                    {   
                        /* 106111111_C1_�ӽзs�ӫ~�@�~-�d���N�~�O�θ��v���[����(157) */
                        /* 103.04.30:1030407005_C1_�ӽзs�ӫ~�W�u-������X�O�I*/                    	
                    	/*1100311005-SC1-�����¦����s�A�������I�����{���]�w137�B138�B139�B141�B142�I��iins == 142|| */
                        /*** 14,61,65,68,69,19,97,108 �N���O ***/
                        /* 27 �߮v���v�O */
                        printf(" iins=[%d]damage_cover=[%d]\n",iins,damage_cover);
                        $SELECT mpremium, pextra_charge/100
                           INTO $mpremium, $pextra_charge
                           FROM cover_vs_premium
                          WHERE icar_type  = $cal_car_id
                            AND iins_type  = $ins_type
                            AND mcoverage2 = $damage_cover
                            AND drate=(SELECT drate
                                         FROM ca_rate_date
                                        WHERE icode  = $frate
                                          AND itable = 'cover_vs_premium');
                        if (NOT_FOUND)  return M_CA_NCOVER_PREM;

                        INS_ptr->ins_premium     = mpremium*short_prate;   /*** round ***/
                        INS_ptr->bef_ins_premium = mpremium*short_prate;   /*** round ***/
                    }
                    else if (iins == 15  || iins == 16  || iins == 66 || iins == 67 || iins == 106 ||
                             iins == 119 || iins == 121 || iins == 123||
                             iins == 154 || iins == 155 || iins == 156|| iins == 163)
                    {
                        /*1030725001_C1 �ߦw(118)�B����(120)����[�N�B���O�I*/
                        /* 1070625011-SC1-��ã��-�s�W�s�A��+�����N�B���s�ӫ~(�I��163)�{���ޱ�*/
                        /*1100311005-SC1-�����¦����s�A�������I�����{���]�w137�B138�B139�B141�B142�I�� iins == 139||*/
                        /*** 15,16,66,67,106 �N�B���O�I ***/
                        printf("-- trace1 iins[%d]\n ",iins);
                        printf("-- trace1 qday[%d]\n ",qday);
                        qday = 0;
                        $SELECT mpremium, pextra_charge/100, mcoverage2/mcoverage1
                           INTO $mpremium, $pextra_charge, $qday
                           FROM cover_vs_premium
                          WHERE icar_type  = $cal_car_id
                            AND iins_type  = $ins_type
                            AND mcoverage1 = $injured_cover
                            AND mcoverage2 = $damage_cover
                            AND drate=(SELECT drate
                                         FROM ca_rate_date
                                        WHERE icode  = $frate
                                          AND itable = 'cover_vs_premium');
                        if (NOT_FOUND)  return M_CA_NCOVER_PREM;
                        printf("-- trace2 qday[%d]\n ",qday);
                        INS_ptr->ins_premium     = mpremium*short_prate;   /*** round ***/
                        INS_ptr->bef_ins_premium = mpremium*short_prate;   /*** round ***/
                    }
                    else if (iins==62  || iins==63  || iins==64  || iins==86  ||
                             iins==98  || iins==101 || iins==102 || iins==103 ||
                             iins==104 || iins==107 || iins==143 ||
                             iins==145 || iins==146 || iins==148 || iins==161 || iins==162 )
                    {
                    	/* 1070212002-SC1 0301�O�v�վ�0501�ͮ� 93�O�v+161+162(�ˮ֤��152+153�A�O�O���98)*/
                        /* 1100311005-SC1-�����¦����s�A�������I�����{���]�w137�B138�B139�B141�B142�I�� iins==141 ||*/
                        printf("ins_type=[%s],cal_car_id=[%s],frate=[%s],car_price=[%f]\n",ins_type,cal_car_id,frate,car_price);
                        printf(" inj[%ld] dam[%ld]\n",injured_cover,damage_cover);

                        /* car9901061 86�I�ثO�B���h���¤@�~ */
                        if (iins == 86)
                        {
                            INS_ptr->injured_cover   = 0;
                            INS_ptr->death_cover     = 0;

                            /* 103.04.03 20,23,86 �i���[E���� */
                            /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N�� if (strstr( INS_ptr->provision, "E") != NULL){*/
                            if (strstr(sProvDelimiter, "E;") != NULL)
                            {
                                /* ��E���ڡA���ˮ֫O�B�W�� */
                            }
                            else
                            {

                                /* cover_20�b SetCarAge���w�g�p��X���«�@�~���O�B */
                                /* 86�I�ج��w���O�I���B���o����Q�O�I�T���{��(��ګO�B) */
                                printf("���«�cover_20[%ld],damage_cover[%ld]\n",cover_20,damage_cover);
                                /* �ȴ��ܰT��,�����_�{������ modify by sylvia 100.07.26 (car990727) */
                                if( damage_cover >= cover_20)
                                {
                                    strcpy(errmsg_chk, itoa(M_CA_OVER_75_PERCENT));
                                    if (strstr(errmsg_tmp, errmsg_chk) == NULL)
                                    {
                                        strcat(errmsg_tmp, errmsg_chk);
                                        strcat(errmsg_tmp, ";");
                                    }
                                }
                            }

                      
                            /*
                            �ӽЭץ�86�I�طs�W�ۭt�B���e�{�ΫO�O�p��@�~,�����p�U:
                            1.�s�W����01.02.34��O�I��86�ɤ��ۭt�B���(10%��20%)�e�{�ΫO�O�p��
                            2.�{�樮��32���ۭt�B���(�w�]�w�s�����ŶZ)��ƻݥ����ܫO�B�@����,�ץ��ηs�W�ۭt�B(10%��20%)���e�{�ΫO�O�p��
                            */
                            injured_cover = 0;
                            if (strcmp(cal_car_id,"32")==0)
                            {
                                $select min(mcoverage1) into $injured_cover
                                   from cover_vs_premium
                                  where iins_type   = $ins_type
                                    and icar_type = $cal_car_id
                                    and drate = (SELECT drate
                                                   FROM ca_rate_date
                                                  WHERE icode  = $frate
                                                    AND itable = 'cover_vs_premium')
                                                    AND mcoverage1 >= $car_price;
                                if (NOT_FOUND) injured_cover = 0;
                                printf("-- trace injured_cover[%ld]\n ",injured_cover);
                            }

                            printf("-- trace cal_deduct[%ld]\n ",cal_deduct);
                            printf("-- trace damage_cover[%ld]\n ",damage_cover);

                            $SELECT mpremium, pextra_charge/100
                               INTO $mpremium, $pextra_charge
                               FROM cover_vs_premium
                              WHERE icar_type  = $cal_car_id
                                AND iins_type  = $ins_type
                                AND mcoverage1 = $injured_cover
                                AND mcoverage2 = $damage_cover
                                AND mdeduct    = $cal_deduct
                                AND drate=(SELECT drate
                                             FROM ca_rate_date
                                            WHERE icode  = $frate
                                              AND itable = 'cover_vs_premium');
                            if (NOT_FOUND)  return M_CA_NCOVER_PREM;


                        }
                        else if ((iins == 101)||(iins == 102))
                        {
                            INS_ptr->injured_cover   = 0;
                            INS_ptr->death_cover     = 0;
                            /* cover_102�b SetCarAge���w�g�p��X���«�@�~���O�B */
                            /* 102�I�ج��w���O�I���B���o����Q�O�I�T���{��(��ګO�B) */
                            /* 101,102�I�ثO�B���o�j����«���B  */
                            printf("30662:iins=[%d] cover_102[%ld],damage_cover[%ld]\n",iins,cover_102,damage_cover);
                            if( damage_cover > cover_102)
                               return M_CA_COVER_01;
                  
                            $SELECT first 1 mpremium, pextra_charge/100
                               INTO $mpremium, $pextra_charge
                               FROM cover_vs_premium
                              WHERE icar_type  = $cal_car_id
                                AND iins_type  = $ins_type
                                AND mcoverage2 = $damage_cover
                                AND drate=(SELECT drate
                                             FROM ca_rate_date
                                            WHERE icode  = $frate
                                              AND itable = 'cover_vs_premium')
                              ORDER BY mcoverage2 desc;
                            if (NOT_FOUND) return M_CA_NCOVER_PREM;
                  
                        } 
                        else if ((iins == 103)||(iins == 104)||(iins == 107)||
                                 (iins == 145)||(iins == 146)||(iins == 148))
                        {
                            /*1050105002_C1 �T���~���ը�����X�O�I(145, 146, 148)*/
                            /*1100311005-SC1-�����¦����s�A�������I�����{���]�w137�B138�B139�B141�B142�I��(iins == 141)||*/
                            printf("iins=[%d]cal_car_id=[%s]ins_type=[%s]\n",iins,cal_car_id,ins_type);
                            printf("injured_cover=[%d]damage_cover=[%ld]cal_deduct=[%ld]\n",injured_cover,damage_cover,cal_deduct);
                            $SELECT mpremium, pextra_charge/100
                               INTO $mpremium, $pextra_charge
                               FROM cover_vs_premium
                              WHERE icar_type  = $cal_car_id
                                AND iins_type  = $ins_type
                                AND mcoverage1 = $injured_cover
                                AND mcoverage2 = $damage_cover
                                AND mdeduct    = $cal_deduct
                                AND drate=(SELECT drate
                                             FROM ca_rate_date
                                            WHERE icode  = $frate
                                              AND itable = 'cover_vs_premium');

                            if (NOT_FOUND)  return M_CA_NCOVER_PREM;
                        }
                        else if (iins == 98 || iins == 161 || iins == 162)
                        {
                            /* 1070212002-SC1 0301�O�v�վ�0501�ͮ� 93�O�v+161+162(�ˮ֤��152+153�A�O�O���98)*/
                            INS_ptr->injured_cover   = 0;
                            INS_ptr->death_cover     = 0;

                            /* 104.09.09 fix ca_car_model �^���޿� */
                            /* �̼t�P�����N���P�_�겣/�i�f�� */
                            printf("brandi=[%s]pro_year=[%s]frate[%s]\n", brandi,pro_year,frate);
                            strcpy( sNcode," ");
                            $SELECT b.ncode into $sNcode
                               FROM ca_car_model a, cu_code_data b
                              WHERE a.icar_series = b.icode
                                AND b.itype = 'CJ'
                                AND a.ibrand = $brandi
                                AND (dexpire is null or dexpire > today)
                                AND a.ipro_year = (select max(ipro_year)
                                                     from ca_car_model
                                                    where ibrand = a.ibrand
                                                      and ipro_year <= $pro_year
                                                      and drate = a.drate
                                                      and (dexpire is null or dexpire > today))
                                AND a.drate = (select drate from ca_rate_date
                                                where icode = $frate
                                                  and itable = 'ca_car_model');
                            if (NOT_FOUND)
                            {
                                $SELECT b.ncode into $sNcode
                                   FROM ca_car_model a, cu_code_data b
                                  WHERE a.icar_series = b.icode
                                    AND b.itype = 'CJ'
                                    AND a.ibrand = $brandi
                                    AND (dexpire is null or dexpire > today)
                                    AND a.ipro_year = (select min(ipro_year)
                                                         from ca_car_model
                                                        where ibrand = a.ibrand
                                                          and ipro_year > $pro_year
                                                          and drate = a.drate
                                                          and (dexpire is null or dexpire > today))
                                    AND a.drate = (select drate from ca_rate_date
                                                    where icode = $frate
                                                      and itable = 'ca_car_model');
                                if (NOT_FOUND)  return M_CA_NBRAND;
                            }

                            cal_deduct = atol(sNcode);
                            INS_ptr->deduct = cal_deduct;
                            printf("==> cal_deduct=[%ld],sNcode=[%s]\n",cal_deduct,sNcode);

                            $SELECT mpremium, pextra_charge/100
                               INTO $mpremium, $pextra_charge
                               FROM cover_vs_premium
                              WHERE icar_type  = $cal_car_id
                                AND iins_type  = $ins_type
                                AND mcoverage2 = $damage_cover
                                AND mdeduct    = $cal_deduct
                                AND drate=(SELECT drate
                                             FROM ca_rate_date
                                            WHERE icode  = $frate
                                              AND itable = 'cover_vs_premium');
                            if (NOT_FOUND)  return M_CA_NCOVER_PREM;
                        }
                        else
                        {
                            printf("INTO 62 damage_cover[%ld],cal_deduct[%ld]\n",damage_cover,cal_deduct);
                            /* 62,63,64�I�ضO�v�p��վ�(�[�p�O�B1) add by sylvia 101.11.23 (1011123001_C1)
                            fcheck626364_1 = 0 ���� 62,63,64�I�ثO�O�p�F�ĥ��¨�, mcover1_626364 =0 (�T�w)
                            fcheck626364_1 = 1 ���� 62,63,64�I�ثO�O�p�F�ĥηs��(�O�B1)  mcover1_626364 = injured_cover(��˫O�B)
                            --------------------------------------------------------------------------   */

                            mcover1_626364 = injured_cover;

                            $SELECT mpremium, pextra_charge/100
                               INTO $mpremium, $pextra_charge
                               FROM cover_vs_premium
                              WHERE icar_type  = $cal_car_id
                                AND iins_type  = $ins_type
                                AND mcoverage1 = $mcover1_626364
                                AND mcoverage2 = $damage_cover
                                AND mdeduct    = $cal_deduct
                                AND drate=(SELECT drate
                                             FROM ca_rate_date
                                            WHERE icode  = $frate
                                              AND itable = 'cover_vs_premium');
                            if (NOT_FOUND)  return M_CA_NCOVER_PREM;
                        }

                        INS_ptr->ins_premium     = mpremium*short_prate;   /*** round ***/
                        INS_ptr->bef_ins_premium = mpremium*short_prate;   /*** round ***/
                    }
                    else if (iins==198)  /*1090812005-SC1-���ά�-�s�W�s�ӫ~-�T�����B���郞�I���l���O�I198�I*/
                    {
                        /*
                        �ӤH�G1:�ꤺ�۵M�H3:��~�۵M�H5:�ꤺ�۵M�HID���~
                        �k�H�G2:�ꤺ�k�H4:��~�k�HID���~6:�ꤺ�k�HID���~
                        
                        �۵M�H�ӫO���ءG03�ۤp�ȡB22�ȳf��                          �򥻫O�I�O �� �Q�O�I�T���s�y�~�פζO�v�N���Y�� �� (�~�֩ʧO�Y��+�ߴڬ����Y��)
                        �k�H�ӫO���ءG03�ۤp�ȡB21�����p�Ȩ��B22�ȳf��              �򥻫O�I�O �� �Q�O�I�T���s�y�~�פζO�v�N���Y�� �� (1+�ߴڬ����Y��) �A
                        ��~�Ψ��ءG07��p�ȡB14����p�Ȩ��B15�p�{���B2A����p�ȳf  �򥻫O�I�O �� �Q�O�I�T���s�y�~�פζO�v�N���Y�� �ѡ]1+�ߴڬ����Y�ơ^
                        */
                        
                        printf("1090812005-SC1-���ά�-�s�W�s�ӫ~-�T�����B���郞�I���l���O�I198�I\n");
                        $SELECT mpremium, pextra_charge/100
                           INTO $mpremium, $pextra_charge
                           FROM cover_vs_premium
                          WHERE icar_type  = $cal_car_id
                            AND iins_type  = $ins_type
                            AND mcoverage1 = $injured_cover
                            AND mcoverage2 = $damage_cover
                            AND mdeduct    = 0
                            AND drate      =(SELECT drate
                                             FROM ca_rate_date
                                            WHERE icode  = $frate
                                              AND itable = 'cover_vs_premium');
                                              
                        if (NOT_FOUND) return M_CA_NCOVER_PREM;
                        
                        
                        pdmg_acc = pdmg_acc_ori;    
                        pdmg_acc_main = pdmg_acc;
                        if (dmg_acc_Insert==0) dmg_acc_Insert = 1;
                        qdmg_acc_sum_main = qdmg_acc_sum;
                        strcpy(iquery_num_damage_main , iquery_num_damage); 
                        printf("-- trace pdmg_acc_main[%f]\n ",pdmg_acc_main); 
                        printf("-- trace pdmg_acc[%f]\n ",pdmg_acc); 
                        printf("-- trace qdmg_acc_sum_main[%f]\n ",qdmg_acc_sum_main); 
                        printf("-- trace qdmg_acc_sum[%f]\n ",qdmg_acc_sum); 
                        printf("-- trace iquery_num_damage_main[%s]\n ",iquery_num_damage_main); 
                        printf("-- trace iquery_num_damage[%s]\n ",iquery_num_damage); 

                        
                        if ( (fcar_class2[0]=='2') || (assuredf[0]=='2' || assuredf[0]=='4' || assuredf[0]=='6') )
                        {
                            dbl_psex_age  = 1.0;
                        }
                        else
                        {
                            dbl_psex_age = INS_ptr->psex_age ;
                        }   
                     
                        printf("-- trace dbl_psex_age[%f]\n ",dbl_psex_age); 
                        
                        INS_ptr->ins_premium     = (mpremium*dmg_factor)*(dbl_psex_age+pdmg_acc_main)*short_prate; /*** round ***/
                        INS_ptr->bef_ins_premium = (mpremium*dmg_factor)*(dbl_psex_age+pdmg_acc_main)*short_prate; /*** round ***/
                        
                        printf("-- 198-INS_ptr->ins_premium--[%f]\n ",INS_ptr->ins_premium); 
                        printf("-- 198-INS_ptr->bef_ins_premium--[%f]\n ",INS_ptr->bef_ins_premium); 
                        ee1 = 0;
                    
                    }
                    else if (iins==238) 
                    {
                        /* 1100119001-SC1-���ά�-�s�W-�s�ӫ~238�I-�D���ϴ��O�Ϊ��[����
                           1130220002_C01_JB�q���}��10�~�������i�H��O238�I��
                        ����1:�H�ۭt�B(KM+����2�X)���o�򥻯«O�O(�«O�O*���֫Y��)
                        ����2:�T���ۭt�B10003:�e3�X�����{��, ��2�X������.  10003
                              �����ۭt�B 3003:�e2�X�����{��, ��2�X������.   3003
                        ����3:�H�~��۴�A���֭p�� = �_�O�~��  ��  �s�y�~�� 
                        ����4:238����               ����            �ŶZ
                              �T��(�D01;02;32;34;35)0~3(���t)�~     03
                                                    3~10(���t)�~    10
                                                    10~15(���t)�~   15
                                                    15�~�H�W        99
                              ����(01;02;32;34;35)  0~3(���t)�~     03
                                                    3~10(���t)�~    10
                        */
                        /* �D���ϴ��I�ب��� pro_year qpro_month */
                        if (qpro_month < 10)
                            sprintf_s(sProYM,sizeof sProYM,"0%d/01/%s",qpro_month,pro_year);
                        else
                            sprintf_s(sProYM,sizeof sProYM,"%d/01/%s",qpro_month,pro_year);
                            
                        strcpy(sProYM,cm_from_infdate_100(sProYM));
                        lProYM = cm_ymd_cdate(sProYM);    /* ����~���((y)yy/mm/dd)�নDate(long) */
                        printf("100119001-SC1-238[%s][%ld]\n",sProYM,lProYM);

                        iCar_age=DiffMonth(ply2_begin,lProYM);
                        
                        /* �Ϲj�T���� �B�z�ŶZ*/
                        if ( (strncmp(cal_car_id,"01",2) == 0) ||
                             (strncmp(cal_car_id,"02",2) == 0) ||
                             (strncmp(cal_car_id,"32",2) == 0) ||
                             (strncmp(cal_car_id,"34",2) == 0) ||
                             (strncmp(cal_car_id,"35",2) == 0) )
                        {
                            
                            if (iCar_age <  3*12)
                                iCar_age = 3;
                            else if (iCar_age <  10*12)
                                iCar_age = 10;
                            printf("����");
                        }
                        else
                        {
                            if (iCar_age <  3*12)
                                iCar_age = 3;
                            else if (iCar_age <  10*12)
                                iCar_age = 10;
                            else if (iCar_age <  15*12)
                                iCar_age = 15;
                            else 
                                iCar_age = 99;
                            printf("�T��");
                        }
                        printf("�ŶZ=[%d]\n",iCar_age);
                        qday = INS_ptr->qday;
                        iCar_age = qday * 100 + iCar_age;
                        
                        printf("iCar_age=[%d]\n",iCar_age);
                        
                        $SELECT a.mpremium, a.pextra_charge/100
                           INTO $mpremium, $pextra_charge
                           FROM cover_vs_premium a
                          WHERE a.icar_type=$cal_car_id
                            AND a.iins_type=$ins_type
                            AND a.mcoverage1 = $injured_cover
                            AND a.mcoverage2 = $damage_cover
                            AND drate=(SELECT drate
                                         FROM ca_rate_date
                                        WHERE icode=$frate
                                          AND itable='cover_vs_premium')
                            AND mdeduct = (select max(mdeduct) from cover_vs_premium
                                                where icar_type = a.icar_type
                                                  and iins_type = a.iins_type
                                                  and mcoverage1 = a.mcoverage1
                                                  and mcoverage2 = a.mcoverage2
                                                  and drate = a.drate
                                                  and mdeduct = $iCar_age
                                                  and ((mdeduct- mod(mdeduct,$qday))/100 = $qday));
                                                  
                        if (NOT_FOUND) return M_CA_NCOVER_PREM;                      
                                                  
                        INS_ptr->ins_premium     = mpremium*short_prate;   /*** round ***/
                        INS_ptr->bef_ins_premium = mpremium*short_prate;   /*** round ***/
                    }
                    else if (iins==237 || iins==178)
                    {
                        $SELECT mpremium, pextra_charge/100
	                   INTO $mpremium, $pextra_charge
	                   FROM cover_vs_premium
	                  WHERE icar_type  = $cal_car_id AND iins_type  = $ins_type
	                    AND mcoverage1 = $injured_cover AND mcoverage2 = $damage_cover
	                    AND mdeduct    = $cal_deduct
	                    AND drate=(SELECT drate
	                                 FROM ca_rate_date 
                                        WHERE icode  = $frate
	                                  AND itable = 'cover_vs_premium');

                        if (NOT_FOUND)  return M_CA_NCOVER_PREM;
                        INS_ptr->ins_premium    = mpremium*short_prate;  /*** round ***/
                        INS_ptr->bef_ins_premium = mpremium*short_prate;   /*** round ***/
                    }
                    else  /**** �I��:50,51,47,52,57,59,60,79,80,89,90 110 112 117  ****/
                    {

                        /* 103.04.30:1030407005_C1_�ӽзs�ӫ~�W�u-������X�O�I */
                        /* (1)111�I��ca_rate�p��覡,���b���B�z */
                        /* (2)115�I (����34�I)��ۭt�B���w�������|�B���G�O�v�]�w���ΡA�G�[�W
                            �~���]����A�ۭt�B�]�w�覡�N�p�U�G
                             �@�~���G�ۭt�B = 1 (���|); �ۭt�B = 2  (���G) (�@�~���P34�I�覡�ۦP)
                             �G�~���G�ۭt�B = 21(���|); �ۭt�B = 22 (���G)
                            �]iins==115 ���b���B�B�z,�P34�@�_�B�z  �^*/
                        if (iins==47 || iins==110 || iins==112  || iins==117 || iins==147 || iins==22 )
                        {
                            $long tmp_mcoverage2;

                            if (iins==47 || iins==117 || iins==147)
                            {
                                tmp_mcoverage2 = death_cover ;
                                if (iins==47 || iins==147)
                                {
                                    INS_ptr->damage_cover = (injured_cover + death_cover) ;
                                }
                            }
                            else
                            {
                                tmp_mcoverage2 = damage_cover ;
                            }

                            if (iins==110)
                            {
                                INS_ptr->injured_cover   = 0;
                                INS_ptr->death_cover     = 0;
                                /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N�� if (strstr( INS_ptr->provision, "E") != NULL)*/
                                if (strstr(sProvDelimiter, "E;") != NULL)
                                {
                                    /* ��E���ڡA���ˮ֫O�B�W�� */
                                }
                                else
                                {
                                    /* cover_20�b SetCarAge���w�g�p��X���«�@�~���O�B */
                                    /* 86�B110�I�ج��w���O�I���B���o����Q�O�I�T���{��(��ګO�B) */
                                    printf("���«�cover_20[%ld],damage_cover[%ld]\n",cover_20,damage_cover);
                                    /* �ȴ��ܰT��,�����_�{������  */
                                    if( damage_cover >= cover_20)
                                    {
                                        strcpy(errmsg_chk, itoa(M_CA_OVER_75_PERCENT));
                                        if (strstr(errmsg_tmp, errmsg_chk) == NULL)
                                        {
                                            strcat(errmsg_tmp, errmsg_chk);
                                            strcat(errmsg_tmp, ";");
                                        }
                                    }
                                }
                            }
                            else if (iins==117)
                            {
                                /* 1080107006-SC1-�����H�Ƨאּ�H�e���ǤJ���H�Ƭ���� qpassenger->qpt*/
                                if (damage_cover==0)
                                {
                                    damage_cover=(qpt-1)*death_cover;
                                    INS_ptr->damage_cover=(qpt-1)*death_cover;
                                }
                                else
                                {
                                    if (death_cover==0)
                                        return M_CA_NCOVER_PREM;

                                    flag_dam = damage_cover % death_cover;
                                    if (flag_dam != 0)
                                        return M_CA_QPT_55_ERR;

                                    flag_person = damage_cover / death_cover;

                                    /* �ӫO�H��!=�����H�ƴ�1 */
                                    /* �������ؤ@���ˮ�(1111128008_SC1)*/
                                    if ( flag_person != qpt-1 )
                                    {
                                        puts("M_CA_OPT_55_NOT_EQUAL");
                                        return M_CA_QPT_55_NOT_EQUAL;
                                    }
                                }
                            }

                            sprintf_s(stmt,sizeof stmt,"SELECT %s FROM %s WHERE %s %s %s %s %s %s %s %s %s",
                                                       "mpremium, pextra_charge/100 ",
                                                       "cover_vs_premium ",
                                                       "icar_type  = ? ",
                                                       "AND iins_type  = ? ",
                                                       "AND mcoverage1 = ? ",
                                                       "AND mcoverage2 = ? ",
                                                       "AND mdeduct    = 1 ",
                                                       "AND drate=(SELECT drate ",
                                                       "             FROM ca_rate_date ",
                                                       "            WHERE icode  = ? ",
                                                       "              AND itable = 'cover_vs_premium')");
    
                            printf("stmt=[%s]\n", stmt );
                            printf("cal_car_id=[%s] ins_type=[%s] injured_cover=[%d] death_cover=[%d] frate=[%s]\n", cal_car_id, ins_type, injured_cover, tmp_mcoverage2, frate);

                            EXEC SQL PREPARE CUR_47_stmt FROM   :stmt;
                            EXEC SQL DECLARE cur_47      CURSOR FOR CUR_47_stmt;
                            EXEC SQL OPEN    cur_47      USING  :cal_car_id , :ins_type ,
                                                                :injured_cover , :tmp_mcoverage2 , :frate;
                            EXEC SQL FETCH   cur_47 INTO :mpremium ,:pextra_charge;
                            if (NOT_FOUND)
                                return M_CA_NCOVER_PREM;
                            EXEC SQL CLOSE   cur_47;
                            EXEC SQL FREE    cur_47;
                            /* 1070314007-SC1�Ͱ����-�i��O��~�������ج������A���إN����01.02.32.34 */
                            if (strncmp( cal_car_id, "01", 2) ==0 || strncmp( cal_car_id, "02", 2) ==0 || 
                                strncmp( cal_car_id, "32", 2) ==0 || strncmp( cal_car_id, "34", 2) ==0 ||
                                strncmp( cal_car_id, "35", 2) ==0)
                            {
                                sprintf_s(stmt,sizeof stmt,"SELECT %s FROM %s WHERE %s %s %s %s %s %s %s %s %s",
                                                           "mpremium, pextra_charge/100 ",
                                                           "cover_vs_premium ",
                                                           "icar_type  = ? ",
                                                           "AND iins_type  = ? ",
                                                           "AND mcoverage1 = ? ",
                                                           "AND mcoverage2 = ? ",
                                                           "AND mdeduct    = 2 ",
                                                           "AND drate=(SELECT drate ",
                                                           "             FROM ca_rate_date ",
                                                           "            WHERE icode  = ? ",
                                                           "              AND itable = 'cover_vs_premium')");
                           
                                printf("stmt=[%s]\n", stmt );
                                printf("cal_car_id=[%s] ins_type=[%s] injured_cover=[%d] death_cover=[%d] frate=[%s]\n", cal_car_id, ins_type, injured_cover, tmp_mcoverage2, frate);
                           
                                EXEC SQL PREPARE CUR_47_stmta FROM   :stmt;
                                EXEC SQL DECLARE cur_47a      CURSOR FOR CUR_47_stmta;
                                EXEC SQL OPEN    cur_47a      USING  :cal_car_id , :ins_type ,
                                                                    :injured_cover , :tmp_mcoverage2 , :frate;
                                EXEC SQL FETCH   cur_47a INTO :mpremium_sec ,:pextra_charge;
                                if (NOT_FOUND)
                                    return M_CA_NCOVER_PREM;
                                EXEC SQL CLOSE   cur_47a;
                                EXEC SQL FREE    cur_47a;
                            }
                        }
                        else if ((iins==57) || (iins==59) || (iins==60))
                        {   
                            /* �I��57,59,60�s�W����I�� add by sylvia 100.01.07 (0991209006_C1) */
                            /* ��˯«O�O */
                            if (injured_cover==0)
                            {
                                mpremium = 0;
                                pextra_charge = 0;
                            }
                            else
                            {
                                sprintf_s(stmt,sizeof stmt,"SELECT %s FROM %s WHERE %s %s %s %s %s %s %s %s %s",
                                                           "mpremium, pextra_charge/100 ",
                                                           "cover_vs_premium ",
                                                           "icar_type  = ? ",
                                                           "AND iins_type  = ? ",
                                                           "AND mcoverage1 = ? ",
                                                           "AND mcoverage2 = 0 ",
                                                           "AND mdeduct    = 0 ",
                                                           "AND drate=(SELECT drate ",
                                                           "             FROM ca_rate_date ",
                                                           "            WHERE icode  = ? ",
                                                           "              AND itable = 'cover_vs_premium')");

                                printf("cal_car_id=[%s] ins_type=[%s] injured_cover=[%d] death_cover=[%d] frate=[%s]\n", cal_car_id, ins_type, injured_cover, death_cover, frate);

                                EXEC SQL PREPARE CUR_57_stmt FROM   :stmt;
                                EXEC SQL DECLARE cur_57      CURSOR FOR CUR_57_stmt;
                                EXEC SQL OPEN    cur_57      USING  :cal_car_id , :ins_type ,
                                                                    :injured_cover , :frate;
                                EXEC SQL FETCH   cur_57 INTO :mpremium ,:pextra_charge;
                                if (NOT_FOUND)
                                    return M_CA_NCOVER_PREM;
                                EXEC SQL CLOSE   cur_57;
                                EXEC SQL FREE    cur_57;
                            }
                            
                            /* ���ݯ«O�O */
                            sprintf_s(stmt,sizeof stmt,"SELECT %s FROM %s WHERE %s %s %s %s %s %s %s %s %s",
                                                       "mpremium, pextra_charge/100 ",
                                                       "cover_vs_premium ",
                                                       "icar_type  = ? ",
                                                       "AND iins_type  = ? ",
                                                       "AND mcoverage1 = 0 ",
                                                       "AND mcoverage2 = ? ",
                                                       "AND mdeduct    = 0 ",
                                                       "AND drate=(SELECT drate ",
                                                       "             FROM ca_rate_date ",
                                                       "            WHERE icode  = ? ",
                                                       "              AND itable = 'cover_vs_premium')");
                            EXEC SQL PREPARE CUR_57_stmta FROM   :stmt;
                            EXEC SQL DECLARE cur_57a      CURSOR FOR CUR_57_stmta;
                            EXEC SQL OPEN    cur_57a      USING  :cal_car_id , :ins_type ,
                                                                 :death_cover , :frate;
                            EXEC SQL FETCH   cur_57a INTO :mpremium_sec ,:pextra_charge;
                            if (NOT_FOUND)
                                return M_CA_NCOVER_PREM;
                            EXEC SQL CLOSE   cur_57a;
                            EXEC SQL FREE    cur_57a;
                        }
                        else if ((iins==79) || (iins==89) || (iins==90))
                        {
                            sprintf_s(stmt,sizeof stmt,"SELECT %s FROM %s WHERE %s %s %s %s %s %s %s",
                                                       "mpremium, pextra_charge/100 ",
                                                       "cover_vs_premium ",
                                                       "icar_type  = ? ",
                                                       "AND iins_type  = ? ",
                                                       "AND mcoverage2 = ? ",
                                                       "AND drate=(SELECT drate ",
                                                       "             FROM ca_rate_date ",
                                                       "            WHERE icode  = ? ",
                                                       "              AND itable = 'cover_vs_premium')");
                            EXEC SQL PREPARE CUR_79_stmt FROM   :stmt;
                            EXEC SQL DECLARE cur_79      CURSOR FOR CUR_79_stmt;
                            EXEC SQL OPEN    cur_79      USING  :cal_car_id , :ins_type ,
                                                                :damage_cover , :frate;
                            EXEC SQL FETCH   cur_79 INTO :mpremium ,:pextra_charge;
                            if (NOT_FOUND)
                                return M_CA_NCOVER_PREM;
                            EXEC SQL CLOSE   cur_79;
                            EXEC SQL FREE    cur_79;
                        }
                        else if (iins==80)
                        {
                            sprintf_s(stmt,sizeof stmt,"SELECT %s FROM %s WHERE %s %s %s %s %s %s %s %s",
                                                      "mpremium, pextra_charge/100 ",
                                                      "cover_vs_premium ",
                                                      "icar_type  = ? ",
                                                      "AND iins_type  = ? ",
                                                      "AND mcoverage1 = ? ",
                                                      "AND mcoverage2 = ? ",
                                                      "AND drate=(SELECT drate ",
                                                      "             FROM ca_rate_date ",
                                                      "            WHERE icode  = ? ",
                                                      "              AND itable = 'cover_vs_premium')");

                            EXEC SQL PREPARE CUR_80_stmt FROM   :stmt;
                            EXEC SQL DECLARE cur_80      CURSOR FOR CUR_80_stmt;
                            EXEC SQL OPEN    cur_80      USING  :cal_car_id , :ins_type ,
                                                                :injured_cover , :damage_cover , :frate;
                            EXEC SQL FETCH   cur_80 INTO :mpremium ,:pextra_charge;
                            if (NOT_FOUND)
                                return M_CA_NCOVER_PREM;
                            EXEC SQL CLOSE   cur_80;
                            EXEC SQL FREE    cur_80;
                        }
                        else
                        {
                            sprintf_s(stmt,sizeof stmt,"SELECT %s FROM %s WHERE %s %s %s %s %s %s %s %s",
                                                       "mpremium, pextra_charge/100 ",
                                                       "cover_vs_premium ",
                                                       "icar_type  = ? ",
                                                       "AND iins_type  = ? ",
                                                       "AND mcoverage1 = ? ",
                                                       "AND mcoverage2 = ? ",
                                                       "AND drate=(SELECT drate ",
                                                       "             FROM ca_rate_date ",
                                                       "            WHERE icode  = ? ",
                                                       "              AND itable = 'cover_vs_premium')");
                            EXEC SQL PREPARE CUR_51_stmt FROM   :stmt;
                            EXEC SQL DECLARE cur_51      CURSOR FOR CUR_51_stmt;
                            EXEC SQL OPEN    cur_51      USING  :cal_car_id , :ins_type ,
                                                                :injured_cover , :death_cover , :frate;
                            EXEC SQL FETCH   cur_51 INTO :mpremium ,:pextra_charge;
                            if (NOT_FOUND)
                                return M_CA_NCOVER_PREM;
                            EXEC SQL CLOSE   cur_51;
                            EXEC SQL FREE    cur_51;
                        }
  
                        

                        if (iins==55 || iins==135 || iins==53 || iins==255 || iins==253 || iins==555)
                        {
                            /* 1080107006-SC1-�����H�Ƨאּ�H�e���ǤJ���H�Ƭ���� qpassenger->qpt*/
                            if (damage_cover==0)
                            {
                                damage_cover=(qpt-1)*death_cover;

                                INS_ptr->damage_cover=(qpt-1)*death_cover;
                            }
                            else
                            {
                                if (death_cover==0)
                                    return M_CA_NCOVER_PREM;

                                flag_dam = damage_cover % death_cover;
                                if (flag_dam != 0)
                                    return M_CA_QPT_55_ERR;

                                flag_person = damage_cover / death_cover;
                                    
                                if (iins==53 || iins==253) /* 1060414007_C1 */
                                {                                      	 
                                    if (*abn_type != 'S')
                                    {
                                        if (fpt[0]=='P')
                                        {
                                            if ( flag_person != (qpt-1) )
                                            {
                                                puts("M_CA_OPT_53_NOT_EQUAL");
                                                return M_CA_QPT_55_NOT_EQUAL;
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    /*1040202006_C1 �s�W���ؤ���~�����²v�վ�*/
                                    /* �ӫO�H��!=�����H�ƴ�1�A�B���ج�03,21,22 */
                                    /* 1060323002-C1 �W�[ 04�B19�B08*/
                                    /* 1110720001_SC1_�ק���s�w�郞��12(�ۤj�S)�Ӹ���줧�ˮ� */
                                    /* �������ؤ@���ˮ�(1111128008_SC1)*/
                                    if (fpt[0]=='P')
                                    { 
                                        if ( flag_person != qpt-1 )
                                        {
                                            puts("M_CA_OPT_55_NOT_EQUAL");
                                            return M_CA_QPT_55_NOT_EQUAL;
                                        }
                                    }
                                }
                            }
                        }
                            
                        /* car9801122 �T���ȹB�����I, add by Julia in 2009/01/19 */
                        /* �O�B�p��覡�P55�ۦP,���O�O�p��覡�P51�ۦP */
                        /* 0991209006_C1 �T���ȹB�����I�s�W����I�� modify by sylvia 100.01.07 */
                        if (iins==57 || iins==59 || iins==60)
                        {
                            if (damage_cover==0)
                            {   
                                /* �ƬG�O�B = (��˫O�B+���ݫO�B)*(�����H��-1) */
                                /* �����H�Ƨאּ�H�e���ǤJ���H�Ƭ���� add by sylvia 100.01.21 (0991209006) */
                                damage_cover=(qpt-1)*(death_cover+injured_cover);

                                INS_ptr->damage_cover=(qpt-1)*(death_cover+injured_cover);
                            }
                            else
                            {
                                if (death_cover==0)
                                    return M_CA_NCOVER_PREM;

                                flag_dam = damage_cover % (death_cover+injured_cover);
                                if (flag_dam != 0)
                                {
                                    return M_CA_QPT_575960_ERR;
                                }
                                flag_person = damage_cover / (death_cover+injured_cover);

                                /* �ӫO�H��!=�����H�ƴ�1�A�B���ج�09 */

                                if ( flag_person != qpt - 1 &&
                                     strncmp( cal_car_id, "09", 2) == 0)
                                {
                                    puts("M_CA_QPT_575960_NOT_EQUAL");
                                    return M_CA_QPT_575960_NOT_EQUAL;
                                }
                            }
                        }
                        printf("####51,53 frate[%s],car_type[%s],ins_type[%s]\n", frate, cal_car_id, ins_type);
                        printf("####51,53 date[%s]\n",cm_cdate_str_100(wk_date));
                        printf("####51,53 short_prate[%f] mpremium[%f]\n",short_prate,mpremium);
                        printf("####51,53 injure [%d] death[%d] damage[%d]\n",injured_cover,death_cover,damage_cover);
                        printf("####51,53 (damage/death)*mpremium*short_prate\n");

                        /* �s�ӫ~79(��X�I�����I) add by sylvia 100.04.26 */
                        if (iins==79)
                        {
                            if (damage_cover==0)
                                return M_CA_NCOVER_PREM;

                            INS_ptr->damage_cover = damage_cover;
                        }
                            
                        /* car9801122 �T���ȹB�����I, add by Julia in 2009/01/19 */
                        /* �O�B�p��覡�P55�ۦP,���O�O�p��覡�P51�ۦP */
                        /* 09912090006_C1 �T���ȹB�����I(57,59,60)�s�W����I���O�O�p�� add by sylvia 100.01.07 */
                        /* �s�ӫ~79(��X�I�����I)80(��X�I�r���I)
                                 89(��X�I���[�r�˰���W�B�I)90(��X�I���[�r�ˤѨa�W�B�I) add by sylvia 100.04.26 */
                        if ((iins==50) || (iins==79) || (iins==80) || (iins==89) || (iins==90))
                        {
                            INS_ptr->ins_premium     = mpremium*short_prate; /* round */
                            INS_ptr->bef_ins_premium = mpremium*short_prate; /* round */
                        }
                        else if (iins==57 || iins==59 || iins==60)
                        {
                            ins_premium1=(mpremium*short_prate);/* ��� */
                            ins_premium2=(mpremium_sec*short_prate);/* ���� */
                            bef_ins_premium1 = (mpremium*short_prate);/* ��� */
                            bef_ins_premium2 = (mpremium_sec*short_prate);/* ���� */
                            INS_ptr->ins_premium = ins_premium1+ins_premium2;
                            INS_ptr->bef_ins_premium = bef_ins_premium1+bef_ins_premium2;
                        }
                        else if (iins==110 || iins==112  || iins==117 || iins==22)
                        {
                            printf("-- trace iins[%d]\n ",iins);
                            printf("-- trace ply2_period[%d]\n ",ply2_period);
                            printf("-- trace iSecondYear2[%d]\n ",iSecondYear2);
                            printf("-- trace short_prate[%f]\n ",short_prate);
                            printf("-- trace mpremium[%f]\n ",mpremium);
                            printf("-- trace mpremium_sec[%f]\n ",mpremium_sec);
                                
                            if(ply2_period <= 12 )
                            {       
                                /* <= 1�~ */
                                INS_ptr->ins_premium      = mpremium * short_prate;

                            }
                            else if( ply2_period == 24 )
                            {   
                                /* 1�~11�Ӥ�H�W��2�~�� */
                                INS_ptr->ins_premium      = mpremium_sec ;
                            }
                            else if((ply2_period > 12) && (ply2_period < 24))
                            {   
                                /* �j��1�~�B �p�� 1�~11�Ӥ� */
                                INS_ptr->ins_premium      =  mpremium +  ((mpremium_sec-mpremium) * (iSecondYear2/12.0));
                            }
                            else
                            {
                                return M_CA_47_PERIOD; /*4533=�ӫO�~�����~�A�Ь��ӫO��*/
                            }
                            INS_ptr->bef_ins_premium  = INS_ptr->ins_premium;
                        }
                        else if ( iins==47 || iins==147)
                        {
                            /**** 47:�����j���I���[�r�p�H�ˮ`�O�I ***/
                            /* �O�v�ۥѤƤ��� */
                            /* �O���p��@�~��,�O�O���ƨ̫����ҭp��«O�O,�p�Ʀ���G��,�ĤT��|�ˤ��J�C*/
                            /* �O�����@�~~�G�~��,�̭�l���󤧤����p��«O�O�p�Ʀ���G��,�ĤT��|�ˤ��J�C*/

                            /*103.04.30:1030407005_C1_�ӽзs�ӫ~�W�u-������X�O�I (47�ܧ󬰥D�I)
                            �O�v�ͮĤ�> 06/01/2014��,�έ�W��119���p�⤽��(�B�O��>12�Ӥ��G�~�������[�O�βv)�A
                            �_�h���ª��p�⤽��(�B�O��>12�Ӥ뤴�O��@�~�������[�O�βv)*/

                            double nDay;

                            nDay = 0.0;


                            if(ply2_period <= 12 )
                            {       
                                /* <= 1�~ */
                                INS_ptr->pure_ins_premium = mpremium * short_prate;
                            }
                            else if( ply2_period == 24 )
                            {  
                                /* 1�~11�Ӥ�H�W��2�~�� */
                                INS_ptr->pure_ins_premium = mpremium_sec ;
                            }
                            else if((ply2_period > 12) && (ply2_period < 24))
                            {   
                                /* �j��1�~�B �p�� 1�~11�Ӥ� */
                                INS_ptr->pure_ins_premium = mpremium + ((mpremium_sec-mpremium) * (iSecondYear2 - nDay)/12.0);
                            }
                            else
                            {
                                return M_CA_47_PERIOD; /*4533=�ӫO�~�����~�A�Ь��ӫO��*/
                            }

                            if (iins==47)
                            {
                                if ((strstr(sProvDelimiter, "F;") != NULL) || (strstr(sProvDelimiter, "G;") != NULL) || (strstr(sProvDelimiter, "I;") != NULL))
                                    INS_ptr->pure_ins_premium *= ( 1 + INS_ptr->adjust_rate);
                            }

                            /*1030523002_C1, fix "_n" �����O�O */
                            printf("iins[%d]provision_L=[%f]\n",iins,provision_L);/*1080708002-SC1-��ã��-�s�W��������L����*/
                            INS_ptr->mpure_prem_n = (long)d45( INS_ptr->pure_ins_premium ,0);
                            INS_ptr->mprem_n      = (long)d45( (INS_ptr->pure_ins_premium / ( 1 - INS_ptr->pextra_charge) ) ,0);
                            INS_ptr->mins_premium_n = INS_ptr->mprem_n;
                              
                            INS_ptr->ins_premium     = (long)d45( (INS_ptr->pure_ins_premium*provision_L / ( 1 - INS_ptr->pextra_charge) ) ,0);
                            INS_ptr->bef_ins_premium = INS_ptr->ins_premium;
                            INS_ptr->pure_ins_premium = d45( INS_ptr->pure_ins_premium*provision_L,0);
                              
                            printf("-- trace INS_ptr->pure_ins_premium[%f]\n ",INS_ptr->pure_ins_premium);
                            printf("-- trace mpremium[%f]\n ",mpremium);
                            printf("-- trace mpremium_sec[%f]\n ",mpremium_sec);
                              
                              
                            printf("iins[%d],ins_premium[%lf],pure_premium[%lf]\n", iins, INS_ptr->ins_premium, INS_ptr->pure_ins_premium);
                        }
                        else
                        {
                            INS_ptr->ins_premium     = ((float)damage_cover/(float)death_cover)*mpremium*short_prate; /* round */
                            printf("ccccccccccccccccc(float)damage_cover/(float)death_cover[%f]\n", (float)damage_cover/(float)death_cover);
                            INS_ptr->bef_ins_premium = ((float)damage_cover/(float)death_cover)*mpremium*short_prate; /* round */
                            printf("iins[%d]@@@@@ ins_premium[%lf]\n",iins,INS_ptr->ins_premium);
                        }
                    }
                }
                /******* END : �̫O�B�O�O�ɭp��O�O **********/
                break;

            case '3':    /* fcal_way 3:�����O�T�O�v�� */
            
                if (iins==58)   /*** �����O�T ***/
                {
                    /* 1030826001_C1 �O�T�I�O�v�p�⤽���վ�,�t�ηs�W�p��]�l*/
                    /* �t�X�q���ĤG���q, cal_ply_ins_cover�s�W�ǤJ�Ѽ� */
                    /* �t�X��椣�ˮֳq�����v, �T�w�ǫO�����O=P(�O��) modify by sylvia 101.02.07 */
                    rtncode = get_ca_rate_ext( irate ,icar_flag_ext ,iparts, &qperiod, &qmiles, irisk,
                                               pro_year, frate, broker2, qpro_month, ply2_begin,
                                               fstart2, officer2, iroute, irate_type2, iroute_comm2, bzfrom2,"P",INS_ptr->damage_cover,
                                               &mpure,
                                               &pextra_charge, &(INS_ptr->pbusiness), sMsg);
                    if( rtncode != M_CM_OK)
                        return rtncode;

                    INS_ptr->ins_premium     = mpure*short_prate;   /*** round ***/
                    INS_ptr->bef_ins_premium = mpure*short_prate;   /*** round ***/
                }

                break;
        }


        /*** step_9_e_iii ***/
        step_9_e_iii:


        /* ������add�G���[�β���S���� */
        /* 1061026002-�ĥΡ�89�O�v�̡A�����O�o���m��600�U�۰ʪ��[S����*/
        /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X S���ڰ���*/


        printf("INS_ptr->pdiscount[%f]\n", INS_ptr->pdiscount);
        if( INS_ptr->pdiscount != 0) /* �O�v�ۥѤƤ��ᤣ�i������ */
            return M_CA_PDISCOUNT_ERR;

        pextra_charge = INS_ptr->pextra_charge;
        
        printf("INS_ptr->pcommission[%f]\n", INS_ptr->pcommission);
        printf("INS_ptr->pagent[%f]\n", INS_ptr->pagent);
        printf("INS_ptr->pextra_charge[%f]\n", INS_ptr->pextra_charge);
        printf("INS_ptr->pbusiness[%f]\n", INS_ptr->pbusiness);

    
        sprintf_s( sCCC1 ,sizeof sCCC1,"%f", (double)(INS_ptr->pdiscount + INS_ptr->pcommission + INS_ptr->pagent));
        sprintf_s( sCCC2 ,sizeof sCCC2,"%f", (double)( (INS_ptr->pextra_charge - INS_ptr->pbusiness) * 100.0));

        rCCC1 = atof( sCCC1);
        rCCC2 = atof( sCCC2);

        printf("��+�N+�u[%-3.20f]\n", rCCC1);
        printf("��-�~   [%-3.20f]\n", rCCC2);
        if ( rCCC1 > rCCC2 )
            return M_CA_COMMI_ERR;

        printf("Cal_ins_premium:iins[%d]\n",iins);

        #ifdef GCAR

        /* 33,35,48,56�I�� INS_ptr->ins_premium �Oñ��O�O , ply_ins_cover���I�� INS_ptr->ins_premium �O�W���O�O */
        if( iins != 33 && iins != 35 && iins != 48 && iins != 56 && iins != 136 && iins != 166 && iins != 266 && insurance_cover_count == 0 )
        {
            if (iins==57 || iins==59 || iins==60)
            {
                mpure_prem_n1 = ins_premium1;/* ��� */
                mpure_prem_n2 = ins_premium2;/* ���� */
                INS_ptr->mpure_prem_n = mpure_prem_n1+mpure_prem_n2;
            }
            else
            {
                INS_ptr->mpure_prem_n = INS_ptr->ins_premium;
                printf("INS_ptr->ins_premium[%f]\n",INS_ptr->ins_premium);
                /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N��*/
                if (strstr(tmp_provision,"J") != NULL && iins != 11 && iins != 211)
                {
                    mpure_prem_n_03 = ins_premium_03;
                    printf("mpure_prem_n_03[%f],ins_premium_03[%f]\n",mpure_prem_n_03,ins_premium_03);
                }
            }
        }

        /* �������[����(F),car9804233�j�v���[����(B)���ܤU�@�ӧP�_���PT,A���ڦ@�Υt�@�q�޿� */
        /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N��  */
        if((strstr(sProvDelimiter, "F;") != NULL) || (strstr(sProvDelimiter, "G;") != NULL) || (strstr(sProvDelimiter, "I;") != NULL))
        {
            /* ���B��47�IINS_ptr->ins_premium,bef_ins_premium�w�O�W���O�O,��L�I���«O�O */
            /* 33,35,48,56�I�� INS_ptr->ins_premium �Oñ��O�O , ply_ins_cover���I�� INS_ptr->ins_premium �O�W���O�O */
            /* iins != 47 && iins != 33 && iins != 35 && iins != 48 && iins != 56 && insurance_cover_count == 0
               �ư��O�]���e���w�g�p��L�F */
            /* car9901221 ���F�e���p��L��47,33,35,48,56,34,�Ҧ��I�ب��ا��i�A�Ψ�������(F) */
            /* �q�ʦۦ樮(101,102,103,104)���i�����[���� modify by sylvia 102.08.10 (1020430001_C1)*/
            /*1100909003-SC1-�_�@�Ϯ��S�h���p�{������07+15�}���O181�I�ݨD*/
            /*1080225007-SC1-��ã��-�s�W166�r��*/
            /* 1110308005_SC1_�w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h */
            if( iins != 47 && iins != 33 && iins != 35 && iins != 48 && iins != 56 && iins != 136 && iins != 166 && iins != 266 && 
                iins != 181 && iins != 101 && iins != 102 && iins != 103 && iins != 104 && insurance_cover_count == 0)
            {
                if(iins == 57 || iins == 59 || iins == 60)
                {
                    ins_premium1 *= ( 1 + INS_ptr->adjust_rate);/* ��� */
                    ins_premium2 *= ( 1 + INS_ptr->adjust_rate);/* ���� */
                    bef_ins_premium1 *= ( 1 + INS_ptr->adjust_rate);/* ��� */
                    bef_ins_premium2 *= ( 1 + INS_ptr->adjust_rate);/* ���� */
                    INS_ptr->ins_premium = ins_premium1+ins_premium2;
                    INS_ptr->bef_ins_premium = bef_ins_premium1+bef_ins_premium2;
                }
                else
                {
                    /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X J���ڤw����*/
                    INS_ptr->ins_premium     *= ( 1 + INS_ptr->adjust_rate);
                    INS_ptr->bef_ins_premium *= ( 1 + INS_ptr->adjust_rate);
                }
            }
        }
        #endif

        /* car9610231��~�βĤT�H�f�B�~���[���� */
        /* car9804233�j�v���[���� */
        /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N�� sProvDelimiter*/
        if((strstr(sProvDelimiter, "T;") != NULL) || (strstr(sProvDelimiter, "B;") != NULL) || (strstr(sProvDelimiter, "A;") != NULL))
        {
            /* iins != 47 && iins != 33 && iins != 35 && iins != 48 && iins != 56 && insurance_cover_count == 0
              �ư��O�]���e���w�g�p��L�F, 35,48,57,58,59,60���A�Τj�v�~�Ȫ��[���� */
            /*1080225007-SC1-��ã��-�s�W166�r��*/
            /* 1110308005_SC1_�w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h */
            if( iins != 47 && iins != 33 && iins != 35 && iins != 48 && iins != 56 && iins != 136 && iins != 166 && iins != 266 && 
                insurance_cover_count == 0 && iins != 57 && iins != 58 && iins != 59 && iins != 60)
            {
                /* �j�v���[����(B)�ݦh��adjust_rate */

                /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X B�BJ���ڤw����*/
                INS_ptr->ins_premium     *= ( 1 + (INS_ptr->safe_rate/100.0) + (INS_ptr->manage_rate/100.0) );
                INS_ptr->bef_ins_premium *= ( 1 + (INS_ptr->safe_rate/100.0) + (INS_ptr->manage_rate/100.0) );
                INS_ptr->ins_premium     *= ( INS_ptr->educated_rate );
                INS_ptr->bef_ins_premium *= ( INS_ptr->educated_rate );

            }
        }

        /* car9808043 �f�B�~���[����C */

        /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N�� sProvDelimiter*/
        if((strstr(sProvDelimiter, "C;") != NULL) && (iins == 71))
        {
            /* INS_ptr->ins_premium �b71�I�ت��[C���ڤ����w�q���«O�O,���U�~�|�h�����H1-���[�O�βv���ʧ@ */
            /*1030523002_C1�GC���ڤ��D���ڤ覡�A���A������U�I�ثO�O�p�⤽�����B��A ��b�̫�p��ñ��O�O�ɦA�[�W�U���ڦ]�l */
        }

        /* �«O�O�����v 47���A��,12,33,35,48,56�b���e�w�g�p��L�F,
           insurance_cover_count�b cal_ply_ins_cover function �p�� */
        /* 1100909003-SC1-�_�@�Ϯ��S�h���p�{������07+15�}���O181�I�ݨD*/
        /* 1080225007-SC1-��ã��-�s�W166�r��*/
        /* 1110308005_SC1_�w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h */
        if( iins != 47 && iins != 33 && iins != 35 && iins != 48 && iins != 56 && iins != 136 && iins != 166 && iins != 266 && 
            iins != 181 && insurance_cover_count == 0 && iins != 12 )
        {
            if(iins == 57 || iins == 59 || iins == 60)
            {
                ins_premium1 *= ( 1 + INS_ptr->deviation_rate/100.0);/* ��� */
                ins_premium2 *= ( 1 + INS_ptr->deviation_rate/100.0);/* ���� */
                bef_ins_premium1 *= ( 1 + INS_ptr->deviation_rate/100.0);/* ��� */
                bef_ins_premium2 *= ( 1 + INS_ptr->deviation_rate/100.0);/* ���� */
                INS_ptr->ins_premium = ins_premium1+ins_premium2;
                INS_ptr->bef_ins_premium = bef_ins_premium1+bef_ins_premium2;
            }
            else
            {
                /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X J���ڤw����*/
                INS_ptr->ins_premium     *= ( 1 + INS_ptr->deviation_rate/100.0);
                INS_ptr->bef_ins_premium *= ( 1 + INS_ptr->deviation_rate/100.0);

            }
        }

        switch(iins)
        {
            /*1030523002_C1, fix "_n" �����O�O */
            case 47:
            case 147:
                bef_premium  = bef_premium  + (long)INS_ptr->bef_ins_premium;
                printf("47:INS_ptr->ins_premium [%lf]\n",INS_ptr->ins_premium);
                printf("47:INS_ptr->pure_ins_premium [%lf]\n",INS_ptr->pure_ins_premium);
                break;

            case 33: case 48: case 35: case 56: case 136: case 166: case 266:
                bef_premium  = bef_premium  + (long)INS_ptr->bef_ins_premium;
                break;
                    
            default:
                #ifdef CA_CONS
                if( insurance_cover_count != 0)	/* ply_ins_cover �����,�w�g�bcal_ply_ins_cover�p�� */
                    break;
                #endif

                /*** ����,�ѵs,�d���h���u�� ***/
                /*1030725001_C1 �ߦw(118)�B����(120)����[�N�B���O�I*/
                switch(iins)
                {     
                    /* 1070212002-SC1 0301�O�v�վ�0501�ͮ� 93�O�v+161+162(�ˮ֤��152+153�A�O�O���98)*/
                    /* 1090812005-SC1-���ά�-�s�W�s�ӫ~-�T�����B���郞�I���l���O�I198�I*/
                    /*1100909003-SC1-�_�@�Ϯ��S�h���p�{������07+15�}���O181�I�ݨD*/
                    case 1: case 5: case 8: case 9: case 85: case 98: case 105: case 118: 
                    case 120: case 122: case 125: case 126: case 198: case 181: 
                    case 201: case 205: case 209:
                        
                        ee_tmp = ee1;

                        /* �I��07�A10�A12�A17�A24���W���O�O�O�H��D�I�D�A�Ψ������ڤ��W���O�O�p�� */     
                        /*1030523002_C1�G�O���L���[���ڧ��(dbl_pure_prem01_n)���D�I�«O�O
                                         �H�Ѩ�������[�I�p��«O�O */
                        /* 1050801002_C1: �D�I�p���[J���ڡA�L���[���ڧ��(dbl_pure_prem01_n)
                                          ���D�I�«O�O�H����03�p�� */
                        /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X J���ڤw����*/
                        dbl_pure_prem01_n = INS_ptr->mpure_prem_n;
                                
                        dbl_ProP_main_dmg = provision_P;/*1071226006-SC1-��ã��-�w���ƫ����վ�(���²v+�ĤT�H�d��)*/
                        dbl_ProQ_main_dmg = provision_Q; 
                        dbl_ProM_main_dmg = provision_M; /* 1081105005-SC1-��ã��-�ק���~���w���ƫ������²v�Φۭt�B(M����)*/
                        dbl_ProD_main_dmg = provision_D;/*1080815003-SC1-��ã��-�ק靈���[H�BD���ڭp�⤽��-���PQK  D-01�B05�B09�B7(S)*/  
                        dbl_ProH_main_dmg = provision_H;/*1080815003-SC1-��ã��-�ק靈���[H�BD���ڭp�⤽��-���PQK  H-05�B09�B31�B32�B07�B10�B109*/ 
                        dbl_ProH_main_lia = 1;          /*1080815003-SC1-��ã��-�ק靈���[H�BD���ڭp�⤽��-���PQK*/
                        dbl_ProF_main_dmg = INS_ptr->adjust_rate; /*1110317002_SC3_�ק�F���ڥi�ϥΤ��I�ؤΫO�O�p��վ�ηs�Wcar140�I�غ��@�]�w*/
			dbl_ProY_main_dmg = provision_Y; /*1130827011_C02_�s�W�s�t��W�B���[����(Y)�A�Щ�11/1�W�u*/
			irate_ProF_main_dmg = INS_ptr->irate;	
                        break;
                        
                    case 86: 
                        /* 1070522002-SC1-�}��86���[10*/
                        /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X J���ڤw���� */
                        dbl_pure_prem01_n = INS_ptr->mpure_prem_n;

                        dbl_ProP_main_dmg = 1;
                        dbl_ProQ_main_dmg = 1;
                        dbl_ProM_main_dmg = 1;/* 1081105005-SC1-��ã��-�ק���~���w���ƫ������²v�Φۭt�B(M����)*/
                        dbl_ProD_main_dmg = 0;/* 1080815003-SC1-��ã��-�ק靈���[H�BD���ڭp�⤽��-���PQK*/  
                        dbl_ProH_main_dmg = 1;/* 1080815003-SC1-��ã��-�ק靈���[H�BD���ڭp�⤽��-���PQK*/  
                        dbl_ProH_main_lia = 1;/*1080815003-SC1-��ã��-�ק靈���[H�BD���ڭp�⤽��-���PQK*/
                        break;
                        
                    case 31: case 32: case 133: case 134: case 149: case 255: case 302:
                    case 231: case 232: case 249: case 531: case 532:
                        
                        ee_tmp = ee2;
                        dbl_ProH_main_lia = provision_H;/* 1080815003-SC1-��ã��-�ק靈���[H�BD���ڭp�⤽��-���PQK*/ 
                        dbl_ProD_main_dmg = 0;          /* 1080815003-SC1-��ã��-�ק靈���[H�BD���ڭp�⤽��-���PQK*/
                        dbl_ProF_main_lia = INS_ptr->adjust_rate; /*1110317002_SC3_�ק�F���ڥi�ϥΤ��I�ؤΫO�O�p��վ�ηs�Wcar140�I�غ��@�]�w*/
			irate_ProF_main_lia = INS_ptr->irate;  
                        break;
                        
                    case 266:   
                     
                        /* 1110308005_SC1_�w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h */
                        ee_tmp = 0.0;
                        dbl_ProH_main_lia = provision_H;
                        dbl_ProD_main_dmg = 0;          
                        break;
                        
                    case 11: case 129: case 211:
                    
                        ee_tmp = ee3;

                        /* �I��07�A10�A12�A17�A24���W���O�O�O�H��D�I�D�A�Ψ������ڤ��W���O�O�p�� */

                        /*1030523002_C1�G�O���L���[���ڧ��(dbl_pure_prem17_n)���D�I�«O�O�H�Ѩ�������[�I�p��«O�O */

                        dbl_pure_prem17_n = INS_ptr->mpure_prem_n;
                        dbl_ProP_main_brg = provision_P;/*1071226006-SC1-��ã��-�w���ƫ����վ�(���²v+�ĤT�H�d��)*/
                        dbl_ProQ_main_brg = provision_Q; 
                        dbl_ProM_main_brg = provision_M; /* 1081105005-SC1-��ã��-�ק���~���w���ƫ������²v�Φۭt�B(M����)*/
                        dbl_ProD_main_dmg = 0;/* 1080815003-SC1-��ã��-�ק靈���[H�BD���ڭp�⤽��-���PQK*/  
                        dbl_ProH_main_dmg = 1;/* 1080815003-SC1-��ã��-�ק靈���[H�BD���ڭp�⤽��-���PQK*/ 
                        dbl_ProH_main_lia = 1;/* 1080815003-SC1-��ã��-�ק靈���[H�BD���ڭp�⤽��-���PQK*/ 
                        dbl_ProF_main_brg = INS_ptr->adjust_rate; /*1110317002_SC3_�ק�F���ڥi�ϥΤ��I�ؤΫO�O�p��վ�ηs�Wcar140�I�غ��@�]�w*/
			irate_ProF_main_brg = INS_ptr->irate;
                        break;
                        
                    default:
                        ee_tmp = 0.0;
                        
                }
                
                printf("Cal_ins_prem()#######---------�h���u��ee_tmp[%.30f]\n",ee_tmp);
                printf("Cal_ins_prem()#######---------���[�O�βvpextra_charge[%.30f]\n",pextra_charge);
                printf("Cal_ins_prem()#######---------1-���[�O�βvpextra_charge[%.30f]\n",1.0-pextra_charge);
                printf("Cal_ins_prem()#######---------�M�I�O�O[%.30lf]\n",INS_ptr->ins_premium);
                printf("cal_ins_prem() ######---------�I��=[%d]D���ڧ��=[%f]dmg[%f]\n",iins,provision_D,dbl_ProD_main_dmg);
                printf("cal_ins_prem() ######---------�I��=[%d]H���ڧ��=[%f]dmg[%f]\n",iins,provision_H,dbl_ProH_main_dmg);
                printf("cal_ins_prem() ######---------�I��=[%d]C���ڧ��=[%f]\n",iins,provision_C);
                printf("cal_ins_prem() ######---------�I��=[%d]P����=[%f]brg[%f]dmg[%f]\n",iins,provision_P,dbl_ProP_main_brg,dbl_ProP_main_dmg);
                printf("cal_ins_prem() ######---------�I��=[%d]Q����=[%f]brg[%f]dmg[%f]\n",iins,provision_Q,dbl_ProQ_main_brg,dbl_ProQ_main_dmg);
                printf("cal_ins_prem() ######---------�I��=[%d]M����=[%f]brg[%f]dmg[%f]\n",iins,provision_M,dbl_ProM_main_brg,dbl_ProM_main_dmg);/* 1081105005-SC1-��ã��-�ק���~���w���ƫ������²v�Φۭt�B(M����)*/
                printf("cal_ins_prem() ######---------�I��=[%d]K����=[%f]\n",iins,provision_K);/* 1080408008-SC1-98������09+K*/
                printf("cal_ins_prem() ######---------�I��=[%d]L����=[%f]\n",iins,provision_L);/* 1080708002-SC1-��ã��-�s�W��������L���� */
                printf("cal_ins_prem() ######---------�I��=[%d]Y����=[%f]dbl_ProY_main_dmg\n",iins,provision_Y,dbl_ProY_main_dmg);/* 1130827011_C02_�s�W�s�t��W�B���[����(Y)�A�Щ�11/1�W�u*/
                
                if (iins==57 || iins==59 || iins==60)
                {
                    INS_ptr->bef_ins_premium   =  (long)d45( (bef_ins_premium1 * (1+provision_D)*provision_L*provision_K*provision_P*provision_Q*provision_M*provision_J*provision_H*provision_C*INS_ptr->pcar_price/(1.0-pextra_charge)*(1.0+(double)ee_tmp)) ,0)+
                                                  (long)d45( (bef_ins_premium2 * (1+provision_D)*provision_L*provision_K*provision_P*provision_Q*provision_M*provision_J*provision_H*provision_C*INS_ptr->pcar_price/(1.0-pextra_charge)*(1.0+(double)ee_tmp)) ,0);  /* round */
                    bef_premium                =  bef_premium + (long)INS_ptr->bef_ins_premium;

                    INS_ptr->pure_ins_premium  =  (long)d45( ((ins_premium1 * (1+provision_D)*provision_L*provision_K*provision_P*provision_Q*provision_M*provision_J*provision_H*provision_C*INS_ptr->pcar_price)) ,0)+
                                                  (long)d45( ((ins_premium2 * (1+provision_D)*provision_L*provision_K*provision_P*provision_Q*provision_M*provision_J*provision_H*provision_C*INS_ptr->pcar_price)) ,0);

                    INS_ptr->ins_premium       =  d45(ins_premium1 * (1+provision_D)*provision_L*provision_K*provision_P*provision_Q*provision_M*provision_J*provision_H*provision_C*INS_ptr->pcar_price/(1.0-pextra_charge)*(1.0+(double)ee_tmp), 0) +
                                                  d45(ins_premium2 * (1+provision_D)*provision_L*provision_K*provision_P*provision_Q*provision_M*provision_J*provision_H*provision_C*INS_ptr->pcar_price/(1.0-pextra_charge)*(1.0+(double)ee_tmp), 0);
                }
                else
                {
                    /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X J���ڤw����*/
                    printf("-- trace iins[%d]\n ",iins);
                    INS_ptr->bef_ins_premium    =  (long)d45( (INS_ptr->bef_ins_premium * (1+provision_D)*provision_L*provision_K*provision_P*provision_Q*provision_M*provision_J*provision_H*provision_C*provision_Y*INS_ptr->pcar_price/(1.0-pextra_charge)*(1.0+(double)ee_tmp)) ,0);  /* round */
                    bef_premium                 =  bef_premium + (long)INS_ptr->bef_ins_premium;
                    printf("11Cal_ins_prem()INS_ptr->ins_premium[%f]\n",INS_ptr->ins_premium);

                    INS_ptr->pure_ins_premium   =  (long)d45( ((INS_ptr->ins_premium * (1+provision_D)*provision_L*provision_K*provision_P*provision_Q*provision_M*provision_J*provision_H*provision_C*provision_Y*INS_ptr->pcar_price)) ,0);
                    INS_ptr->ins_premium        =  d45(INS_ptr->ins_premium * (1+provision_D)*provision_L*provision_K*provision_P*provision_Q*provision_M*provision_J*provision_H*provision_C*provision_Y*INS_ptr->pcar_price/(1.0-pextra_charge)*(1.0+(double)ee_tmp), 0);
                    printf("Cal_ins_prem()INS_ptr->pure_ins_premium[%f]\n",INS_ptr->pure_ins_premium);
                    printf("Cal_ins_prem()INS_ptr->bef_ins_premium[%f]\n",INS_ptr->bef_ins_premium);
                    printf("Cal_ins_prem()INS_ptr->ins_premium[%f]\n",INS_ptr->ins_premium);
                        
                }


                #ifdef GCAR
                if (iins==57 || iins==59 || iins==60)
                {
                    INS_ptr->mins_premium_n = (long)d45( (mpure_prem_n1 / (1.0-pextra_charge)*(1.0+(double)ee_tmp)) ,0) +
                                              (long)d45( (mpure_prem_n2 / (1.0-pextra_charge)*(1.0+(double)ee_tmp)) ,0);
                    INS_ptr->mprem_n        = INS_ptr->mins_premium_n;
                    INS_ptr->mpure_prem_n   = (long)d45( mpure_prem_n1 ,0) + (long)d45( mpure_prem_n2 ,0);
                }
                else
                {
                    INS_ptr->mins_premium_n = (long)d45( (INS_ptr->mpure_prem_n /(1.0-pextra_charge)*(1.0+(double)ee_tmp)) ,0);
                    INS_ptr->mprem_n        = INS_ptr->mins_premium_n;
                    INS_ptr->mpure_prem_n   = (long)d45( INS_ptr->mpure_prem_n ,0);

                }
                #endif

                printf("�W��INS_ptr->ins_premium[%lf]\n",INS_ptr->ins_premium);
                printf("�W��INS_ptr->mprem_n[%d]\n",INS_ptr->mprem_n);
                
                break;
        }
        
        printf("-------->INS_ptr->pcommission[%4.2f]\n",INS_ptr->pcommission);
        printf("-------->INS_ptr->pagent[%4.2f]\n",INS_ptr->pagent);
        printf("-------->INS_ptr->pdiscount[%4.2f]\n",INS_ptr->pdiscount);
        printf("-------->fdiscount[%s]\n",fdiscount);
        
        /************************/
        /* �u�f���B�p��         */
        /* �Y�H�W���O�O�p��o�� */
        /************************/
        /* �ˮ`�I�O�I�O�Φ����B�N�z�B�u�f�w�g�p��A�𶷭��s�p�� */
        if (iins==33 || iins==48 || iins== 35 || iins== 56 || iins== 136 || iins== 166 || iins== 266 )
        {
            /* �ˮ`�I�O�I����������2:���d�I */
            if (*fdiscount!='Y')
            {
                INS_ptr->mdiscount = 0;
                #ifdef GCAR
                INS_ptr->mdiscount_n = 0;
                #endif
            }
        }
        else
        {
            if (cal_itype_disc[0] == '2')    /*  �̤�v�]�w  */
            {
                cal_pdiscount = INS_ptr->pdiscount;
                if (cal_pdiscount >= 0)
                {
                    disc_last = 0.500000000001;
                }
                else
                {
                    disc_last = -0.500000000001;
                }
                
                /* �I���u�f�v���o�j���I�ت��[�O�βv */
                if (check_est_cal_prem == 1)
                {
                    sprintf_s( sCCC1,sizeof sCCC1,"%f", (double)(cal_pdiscount));
                    sprintf_s( sCCC2,sizeof sCCC2,"%f", (double)(pextra_charge * 100.0));

                    printf("INS_ptr->pdiscount[%-3.20f]\n", INS_ptr->pdiscount);
                    printf("cal_pdiscount[%-3.20f]\n", cal_pdiscount);
                    printf("pextra_charge[%-3.20f]\n", pextra_charge);
                    printf("sCCC1[%-3.20f]\nsCCC1[%-3.20f]\n", (double)(cal_pdiscount), (double)(pextra_charge * 100.0));

                    rCCC1 = atof( sCCC1);
                    rCCC2 = atof( sCCC2);

                    if ( rCCC1 > rCCC2 )
                    {
                        return M_CA_PDISC_OVER;
                    }
                }

                cal_prem      = INS_ptr->ins_premium;   /* �W���O�O */

                /* CA_CONS */
                if( insurance_cover_count != 0)	/* ply_ins_cover �����,�p���u�f */
                {
                    IcurrPlyInsCover = IfirstPlyInsCover;
                    INS_ptr->mdiscount = 0;
                    INS_ptr->mdiscount_n = 0;
                    while( IcurrPlyInsCover)
                    {
                        if( iins == atoi( IcurrPlyInsCover->iins_type))
                        {
                            /* �Ncal_ply_ins_cover�p��n���u�f���B�ۥ[,�N�O�I���u�f���B */
                            INS_ptr->mdiscount = INS_ptr->mdiscount + IcurrPlyInsCover->mdiscount;
                            #ifdef GCAR
                            INS_ptr->mdiscount_n = INS_ptr->mdiscount_n + IcurrPlyInsCover->mdiscount_n;
                            #endif
                        }
                        IcurrPlyInsCover = IcurrPlyInsCover->next;
                    }
                }
                else if (*fins_grp=='1' || *fins_grp=='2')  /*���l, ���d*/
                {
                    if (*fdiscount!='Y')
                    {
                        INS_ptr->mdiscount   = 0;
                        INS_ptr->pdiscount   = 0.0;
                        #ifdef GCAR
                        INS_ptr->mdiscount_n = 0;
                        #endif
                    }
                    else
                    {
                        printf("-------->cal_pdiscount[%4.2f]\n",cal_pdiscount);
                        printf("-------->cal_prem[%ld]\n",cal_prem);

                        INS_ptr->mdiscount   = (long)((float)cal_prem*cal_pdiscount/100.0+disc_last);
                        #ifdef GCAR
                        INS_ptr->mdiscount_n = (long)((float)INS_ptr->mprem_n*cal_pdiscount/100.0+disc_last);
                        #endif
                        printf("INS_ptr->mdiscount[%ld]\n",INS_ptr->mdiscount);
                    }
                }
            }
            else
            {
                printf("INTO itype_disc == '1' \n");
                cal_mdiscount = INS_ptr->mdiscount;
                cal_prem      = INS_ptr->ins_premium;   /* �W���O�O */

                cal_pdiscount = d45(cal_mdiscount /cal_prem * 100.0 , 2);

                INS_ptr->pdiscount = cal_pdiscount;
                printf("cal_pdiscount[%f]\n",cal_pdiscount);
                /* �I���u�f�v���o�j���I�ت��[�O�βv */
                if (check_est_cal_prem == 1)
                {

                    sprintf_s( sCCC1,sizeof sCCC1 ,"%f", (double)(cal_pdiscount));
                    sprintf_s( sCCC2,sizeof sCCC2 ,"%f", (double)(pextra_charge * 100.0));

                    printf("cal_pdiscount[%-3.20f]\n", cal_pdiscount);
                    printf("pextra_charge[%-3.20f]\n", pextra_charge);

                    printf("sCCC1[%-3.20f]\nsCCC1[%-3.20f]\n", (double)(cal_pdiscount), (double)(pextra_charge * 100.0));

                    rCCC1 = atof( sCCC1);
                    rCCC2 = atof( sCCC2);

                    if ( rCCC1 > rCCC2 )
                    {
                        return M_CA_PDISC_OVER;
                    }
                }

                if( insurance_cover_count != 0)	/* ply_ins_cover �����,�p���u�f */
                {
                    IcurrPlyInsCover = IfirstPlyInsCover;
                    INS_ptr->mdiscount = 0;
                    INS_ptr->mdiscount_n = 0;
                    while( IcurrPlyInsCover)
                    {
                        if( iins == atoi( IcurrPlyInsCover->iins_type))
                        {
                            /* �Ncal_ply_ins_cover�p��n���u�f���B�ۥ[,�N�O�I���u�f���B */
                            INS_ptr->mdiscount =   INS_ptr->mdiscount + IcurrPlyInsCover->mdiscount;
                            #ifdef GCAR
                            INS_ptr->mdiscount_n = INS_ptr->mdiscount_n + IcurrPlyInsCover->mdiscount_n;
                            #endif
                        }
                        IcurrPlyInsCover = IcurrPlyInsCover->next;
                    }
                }
                else if (*fins_grp=='1' || *fins_grp=='2')  /*���l, ���d*/
                {
                    if (*fdiscount!='Y')
                    {
                        INS_ptr->mdiscount = 0;
                        INS_ptr->pdiscount = 0.0;
                        #ifdef GCAR
                        INS_ptr->mdiscount_n = 0;
                        #endif
                    }
                    else
                    {
                        printf("-------->cal_pdiscount[%4.2f]\n",cal_pdiscount);
                        printf("-------->cal_prem[%ld]\n",cal_prem);

                        INS_ptr->mdiscount     = cal_mdiscount;
                        #ifdef GCAR
                        INS_ptr->mdiscount_n   = cal_mdiscount;
                        #endif
                        printf("INS_ptr->mdiscount[%ld]\n",INS_ptr->mdiscount);
                    }
                }
            }
        }

        /* �I��33�B48�w�����U�Ӷ��Q�O�I�H���u�f �A�w��ñ��O�O */
        /* �p��ñ��O�O */
        if((iins != 33) && (iins != 48) && (iins != 35) && (iins != 56) && (iins != 136)  && (iins != 166) && (iins != 266))
        {
            INS_ptr->ins_premium = INS_ptr->ins_premium - INS_ptr->mdiscount;

            #ifdef GCAR

            printf("INS_ptr->mdiscount_n   [%d]\n", INS_ptr->mdiscount_n);
            printf("INS_ptr->mins_premium_n[%f]\n",  INS_ptr->mins_premium_n);
            printf("INS_ptr->mprem_n       [%d]\n",  INS_ptr->mprem_n);

            INS_ptr->mins_premium_n = INS_ptr->mprem_n        - INS_ptr->mdiscount_n;

            #endif
        }

        premium2_disc += INS_ptr->ins_premium;

        /* �O�v�ۥѤƤ���
           24�I�t�j���@�ߥHñ��O�O�^���«O�O */
        if( iins==24 && *fcomp_24=='Y')
            INS_ptr->pure_ins_premium = (long)d45( (INS_ptr->ins_premium * (1-INS_ptr->pextra_charge)) ,0);


        /*1030725001_C1 �ߦw(118)�B����(120)����[�N�B���O�I*/
        /* ���[����N�B���Ϊ��[�ѵs�N�B�� */
        /*1100909003-SC1-�_�@�Ϯ��S�h���p�{������07+15�}���O181�I�ݨD*/
        /*1100311005-SC1-�����¦����s�A�������I�����{���]�w137�B138�B139�B141�B142�I��iins == 137 || iins == 138||*/

        if (((iins == 1   || iins == 5   || iins == 8   || iins == 9   || iins == 85 || iins == 105 ||
              iins == 118 || iins == 120 || iins == 122 || iins == 125 || iins == 126||  iins == 181||
              iins == 201 || iins == 205 || iins == 209) && (damage_add_flag == 1)) ||
            ((iins == 11  || iins == 96  || iins == 129 || iins == 211) && (thief_add_flag == 1)))
        {
            /*�I�� ins_type                 */
            /*���� car_typei2               */
            /*�Ѽ� LngQday = INS_ptr->qday  */
            /*�O��ͮİ_�� ply2_begin       */
            LngQday = INS_ptr->qday;
            LngMexpensePrem = 0;     
            $SELECT mexpense
               INTO :LngMexpensePrem
               FROM ca_add_mplace
              WHERE iins_type = :ins_type
                AND icar_type = :car_typei2
                AND qday      = :LngQday
                AND drate = (SELECT MAX(drate)
                               FROM ca_add_mplace
                              WHERE iins_type = :ins_type
                                AND icar_type = :car_typei2
                                AND qday      = :LngQday
                                AND drate     <= :ply2_begin);

            if (NOT_FOUND)
                return M_CA_NOT_ADD_MPLACE;

            LngMexpensePremOri = (long)d45( ((double)LngMexpensePrem*(1.0+(double)ee_tmp)*short_prate*provision_H) ,0);
            if (cal_pdiscount >= 0)
            {
                disc_last = 0.500000000001;
            }
            else
            {
                disc_last = -0.500000000001;
            }
            
            INS_ptr->mexp_disc = (long)(LngMexpensePremOri*cal_pdiscount/100.0+disc_last);
            printf("ori_mexpenseprem[%ld],mexp_disc[%ld]\n",LngMexpensePremOri,INS_ptr->mexp_disc);
            INS_ptr->mexpense  = LngMexpensePremOri - INS_ptr->mexp_disc;

            INS_ptr->bef_ins_premium += LngMexpensePremOri;
            INS_ptr->ins_premium     += INS_ptr->mexpense;

            #ifdef GCAR
            INS_ptr->mprem_n         += LngMexpensePremOri;
            INS_ptr->mins_premium_n  += INS_ptr->mexpense;
            #endif

            premium2_disc            += INS_ptr->mexpense;
            INS_ptr->mdiscount       += INS_ptr->mexp_disc;
            /* 1081105005-SC1-��ã��-�ק���~���w���ƫ������²v�Φۭt�B(M����)*/
            INS_ptr->pure_ins_premium = (long)d45( (INS_ptr->ins_premium / (1+provision_D)/ provision_L/provision_K/provision_P/provision_Q/provision_M/provision_J/ provision_H/provision_C * (1-INS_ptr->pextra_charge) ) ,0);
              
        }
        else if(iins == 15  || iins == 16  || iins == 66  || iins == 67  ||
                iins == 38  || iins == 39  || iins == 106 || iins == 119 ||
                iins == 121 || iins == 123 || iins == 238 ||
                iins == 154 || iins == 155 || iins == 156 || iins == 163
               ) 
        {       
            /*1030725001_C1 �ߦw(118)�B����(120)����[�N�B���O�I* 1070625011-SC1-��ã��-�s�W�s�A��+�����N�B���s�ӫ~(�I��163)�{���ޱ� 1100119001-SC1-���ά�-�s�W-�s�ӫ~238�I-�D���ϴ��O�Ϊ��[����*/
            /*1100311005-SC1-�����¦����s�A�������I�����{���]�w137�B138�B139�B141�B142�I��iins == 139 || */
            INS_ptr->qday      = qday;
            INS_ptr->mexp_disc = 0;
            INS_ptr->mexpense  = 0;
        }
        else if(iins == 29)
        {
            /* �W�B�d���I���Nqday�k0,qday���O����h�O�B�N�� */
        }
        else
        {
            INS_ptr->qday      = 0;
            INS_ptr->mexp_disc = 0;
            INS_ptr->mexpense  = 0;
        }

        printf("cal_deduct=[%d] INS_ptr->deduct=[%d]\n",cal_deduct, INS_ptr->deduct );

        pure_premium = pure_premium + (long)INS_ptr->pure_ins_premium;
        premium2 += INS_ptr->ins_premium;   /* ñ��O�O */

        /* �I��12:�s��Q�ѷl���I�O�I���B=[ñ��O�O]*6:�d��H�U�L����˥h */
        if (iins == 12)
        {
            /* car9611152 12�I�ثO�B�ѹꦬ�O�O�����אּ�W���O�O���� */
            /*1080422010-SC1-2�I�ثO�B���W���O�O�������t�@�i��α˥h�B�z*/
            INS_ptr->damage_cover  = (long)(INS_ptr->mprem_n*6);
        }

        printf("\n\n---> in Cal_ins_premium=[%s]\n", tmp_ipaid_base );

        /* �����N�z�v�ϥ�ñ��O�O����v�p�� */
        if (iins==33 || iins==48 || iins==56 || iins==136 || iins==166 || iins==266 )
        {
            /* �ˮ`�I�O�I����������2�G���d�I */
            mlia_commission += INS_ptr->mcommission;
            mlia_agent      += INS_ptr->magent;
        }
        else
        {
            cal_pagent      = INS_ptr->pagent;
            cal_pcommission = INS_ptr->pcommission;

            cal_prem        = INS_ptr->ins_premium;
            
            strcpy(sIcode," ");
            if (*fins_grp=='1')  /*���l*/
            {
                /* �t�X�q���ĤG���q, broker��Hicomm_obj(�I����H)�d�� by sylvia 100.06.15 */
                
                $select icode into $sIcode
                  from v_commission_obj
                 where icomm_obj = $icomm_obj2;

                if (strcmp(sIcode,"3") == 0)
                {
                    $SELECT fagent
                       INTO $fagent
                       FROM broker_agent
                      WHERE ibroker=$icomm_obj2;
                    if (NOT_FOUND) return M_CMN_NBROKER_AGENT;
                }

                if (strcmp(tmp_ipaid_base,"A")==0)       /* ���u�ݫ�O�O�p�� */
                {
                    INS_ptr->magent      = (long)d45( ((float)cal_prem*cal_pagent/100.0) ,0);
                    INS_ptr->mcommission = (long)d45( ((float)cal_prem*cal_pcommission/100.0) ,0);
                }
                else if (strcmp(tmp_ipaid_base,"B")==0)       /* ���u�ݫe�O�O�p�� */
                {
                    INS_ptr->magent      = (long)d45( ((float)(cal_prem+INS_ptr->mdiscount)*cal_pagent/100.0) ,0);
                    INS_ptr->mcommission = (long)d45( ((float)(cal_prem+INS_ptr->mdiscount)*cal_pcommission/100.0) ,0);
                }
                else
                {
                    INS_ptr->magent      = (long)d45( ((float)cal_prem*cal_pagent/100.0) ,0);
                    INS_ptr->mcommission = (long)d45( ((float)cal_prem*cal_pcommission/100.0) ,0);
                }
            }
            else
            {

                $select icode into $sIcode
                   from v_commission_obj
                  where icomm_obj = $icomm_obj2;

                if (strcmp(sIcode,"3") == 0)
                {
                    $SELECT fagent
                       INTO $fagent
                       FROM broker_agent
                      WHERE ibroker=$icomm_obj2;
                    if (NOT_FOUND) return M_CMN_NBROKER_AGENT;
                }

                if (strcmp(tmp_ipaid_base,"A")==0)       /* ���u�ݫ�O�O�p�� */
                {
                    INS_ptr->magent      = (long)d45( ((float)cal_prem*cal_pagent/100.0) ,0);
                    INS_ptr->mcommission = (long)d45( ((float)cal_prem*cal_pcommission/100.0) ,0);
                }
                else if (strcmp(tmp_ipaid_base,"B")==0)       /* ���u�ݫe�O�O�p�� */
                {
                    INS_ptr->magent      = (long)d45( ((float)(cal_prem+INS_ptr->mdiscount)*cal_pagent/100.0) ,0);
                    INS_ptr->mcommission = (long)d45( ((float)(cal_prem+INS_ptr->mdiscount)*cal_pcommission/100.0) ,0);
                }
                else
                {
                    INS_ptr->magent      = (long)d45( ((float)cal_prem*cal_pagent/100.0) ,0);
                    INS_ptr->mcommission = (long)d45( ((float)cal_prem*cal_pcommission/100.0) ,0);
                }
            }
        }

        if( INS_ptr->mdiscount != 0) /* �O�v�ۥѤƤ��ᤣ�i������ */
            return M_CA_DISCOUNT_ERR;

        if( strncmp( iextra_charge, "40", 2) == 0 || strncmp( iextra_charge, "41", 2) == 0) /* �����~�ȡA���i�������M�N�z�O */
        {
            if( INS_ptr->mcommission != 0)
                return M_CA_COMMI_ERR1;

            if( INS_ptr->magent != 0)
                return M_CA_COMMI_ERR2;
        }
     
        /* �ˮ֭p�⤧�O�O���o�p��ε���0 */
        if (INS_ptr->ins_premium <= 0)
        {
            printf("iins=[%d] INS_ptr->ins_premium=[%ld]\n", iins, INS_ptr->ins_premium );
            return M_CA_PREMIUM_0;
        }

        printf("++++++++++++++++++++fcalc[%s]++++++++++++++++++++\n" , fcalc);
        if ( fcalc[0] != '1' && (INS_ptr->pure_ins_premium >  INS_ptr->ins_premium))
        {
            return M_CA_PREMIUM_ERROR;
        }

        rec_ins_qcvg:
        /*** keep every insurance type's fdeduct & qcoverage.. ***/
        *(INS_ptr->fdeduct)  = *fdeduct;
        *(INS_ptr->fins_grp) = *fins_grp;
        INS_ptr->qcoverage   = qcoverage;
        INS_ptr->qserial     = qserial;

        printf("***************************************************INS_ptr->pdiscount[%f]\n", INS_ptr->pdiscount);
        INS_ptr=INS_ptr->next;
        
    }/** end while-INS_ptr **/

    /* �ˮ`�I�W�U���tA&H���ګO�Ȥ�,���^��ĵ�i�T�� add by sylvia 100.10.13 (0991216002_C1) */
    if (Ireject_count > 0)
    {		    
        strcat(errmsg_tmp, "�ˮ`�I�W�U�tA&H�z�ߩګO�Ȥ�G�г��֫O�����O�_�ӫO(��hth103);");
        return M_CM_ORDINARY_CHECK;		                
    }
    /* ---------------------------------------------------------------------- */
    
    printf("####### END OF Cal_ins_prem()####### qpt[%f]\n\n\n",qpt);
    printf("################################################################ \n");
    printf("################################################################ \n\n\n");

    #ifdef GCAR

    /* �������[����, car9804233�j�v���[���� */
    /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N�� sProvDelimiter */
    if((strstr(sProvDelimiter, "F;") != NULL) || (strstr(sProvDelimiter, "G;") != NULL) || (strstr(sProvDelimiter, "I;") != NULL) || (strstr(sProvDelimiter, "B;") != NULL)) /* �������[����, car9804233�j�v���[���� */
    {
        plia_acc2 = plia_acc2_ori; /* �٭�F�Ƭ��� */
    }

    #endif

    /* b2b9606252 �x�sb2b�󱱺޸պ��ɪ��B�P�p��X���O�O�n�@�P */
    iTmp = 0;
    if( estimatei[0] != '' && estimatei[0] != ' ' && estimatei[0] != '\0')
    {

        $SELECT mpremium1, mpremium2, 1
           INTO $estPremium1, $estPremium2, $iTmp
           FROM estimate
          WHERE iestimate = $estimatei
            AND flag_list like '%AmountFix%';
        puts("select from estimate");
        
        printf("estPremium1[%d], $estPremium2[%d], iTmp[%d]\n", estPremium1, estPremium2, iTmp);

        if( iTmp == 1)
        {
            if( premium1 != estPremium1 || premium2 != estPremium2)
                return M_CA_PREM_NOT_EQUAL;
        }
    }
    
    return SUCCESS;
}

/*****************************************************************/
static int Calculate_cover_prem(ins_ptr,ical_ins,fcal_class,iins)
struct INS_TYPE *ins_ptr;
char *ical_ins, *fcal_class;
int iins;
{
    long    int_cover, tmp_dmg, low_dmg_cover, high_dmg_cover;
    int     adj_age;
    double  adj_yr_dep;
    long    tmp_cover_dep, cover_dep, thousand_cover_dep;
    long    cover_dep_11;
    char    TMP_MSG[200];
    $long   tmpcover_1=0, tmpcover_3 = 0;
    $double tmp_pure=0.0, tmppure1=0.0;  /* 85�I�ؤ������l�«O�O */
    $double tmppure105=0.0;  /* 105,118�I�ؤ������l�«O�O */
    $char   tmp_iins[INSURANCE_TYPE],tmp_frate[5];
    $char   f1010515[2];
    /* �ѵs�I�O�O�p��վ� */
    long    lEcover11, lEthousand11;
    $double dbl_psex_age=1.0;	/* �s���²v */
    $char sProvDelimiter[22];    /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X  �����ɤW��������*/


    /* �������[���ڤ��Ҽ{�F�Ƭ����A���k�s�A���}function�A�٭� */
    /* car9804233�j�v���[����,���Ҽ{�F�Ƭ����A���k�s�A���}function�A�٭� */
    /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N�� sProvDelimiter */
    strcpy(sProvDelimiter,"");
    sprintf_s(sProvDelimiter,sizeof sProvDelimiter,"%s;",trim(ins_ptr->provision));
    printf("Calculate_cover_prem==>sProvDelimiter[%s]\n",sProvDelimiter);
    if((strstr(sProvDelimiter, "F;") != NULL) || (strstr(sProvDelimiter, "G;") != NULL) || (strstr(sProvDelimiter, "I;") != NULL) || (strstr(sProvDelimiter, "B;") != NULL))
    {
        pdmg_acc = 0;       /* 01,08�I�� */
        pdmg_acc2 = 0;      /* 05,09,120,125,126�I�� */
        pdmg_acc3 = 0;      /* 85,105,118,137,138�I�� */
        punknown_acc  = 0;  /* 152 153(�s)*/
        punknown_acc2 = 0;  /* 152 153(��)*/
    }
    else
    {
        pdmg_acc = pdmg_acc_ori;    /* 01,08�I�� */
        pdmg_acc2 = pdmg_acc_ori2;  /* 05,09,120,125,126�I�� */
        pdmg_acc3 = pdmg_acc_ori3;  /* 85,105,118,137,138�I�� */
        punknown_acc  = punknown_acc_ori;          /* 152 153(�s)*/
        punknown_acc2 = punknown_acc_ori2;         /* 152 153(��)*/
    }
    printf("a-- trace punknown_acc[%f]\n ",punknown_acc);
    tmppure1 = 0.0;
    tmp_pure = 0.0;

    strcpy(tmp_frate,ins_ptr->frate);

    /* 1051214006_C1 �]���D�޾������ܤ����X�W���l�I�U�[�ΰӫ~�s�W_�����ܧ�O�v�ץ� add 152, 153 */
    /*1030725001_C1 �ߦw(118)�B����(120)����[�N�B���O�I*/
    printf("####### Calculate_cover_prem:ical_ins[%s] , iins[%d]\n",ical_ins,iins);
    if (IsBlankNull(ical_ins))  /*** �����D�I ***/
    {
        /*---------------------------------------------*/
        low_dmg_cover  = (long)cover_01*0.9;
        high_dmg_cover = (long)cover_01*1.1;
        /*---------------------------------------------*/
        /* 1090812005-SC1-���ά�-�s�W�s�ӫ~-�T�����B���郞�I���l���O�I198�I*/
        /*1100909003-SC1-�_�@�Ϯ��S�h���p�{������07+15�}���O181�I�ݨD*/
        if (iins==1  || iins==5  || iins==9  || iins==8 || iins==85 || iins==105 || iins==118 || iins==120|| iins==122|| iins==125|| iins==126||
            iins==152|| iins==153|| iins==198|| iins==181 || iins==201  || iins==205  || iins==209) /*** ����l���I ***/
        {
            strcpy(tmp_iins, rtrim(ins_ptr->ins_type));

            printf("-- trace tmp_iins[%s]\n ",tmp_iins);

            /* �O�B */
            if (iins==152|| iins==153)
            {
                tmpcover_1 = ins_ptr->damage_cover;
            }
            else
            {
                tmpcover_1 = ins_ptr->injured_cover;
            }
            ins_ptr->injured_cover = 0;
            ins_ptr->death_cover   = 0;

            /* �A�Ϊ�����Y��--�]���T�ը���Y��,���C���u�|���@�վA��,
               �]���N�A�Ϊ��ӲիY�Ʃ��  pdmg_acc_main , �����N�J��O�O�p��{��,
               �H�קK�{�����ơC  add by sylvia 102.11.12 (10209210001_C1)*/

            /* 1040720002_C1_�ץ��ߦw�����I�������l���p��覡 */
            /*
                �u�������l�O���覡�O�v:
                1: �������l�Y���h���A���H�h���O��
                2: ���t�u�������l�v
                3: �������l�Y���h���A�u�O�@��*/
            printf("-- trace funknown_dmg[%s]\n ",funknown_dmg);
            /*1100909003-SC1-�_�@�Ϯ��S�h���p�{������07+15�}���O181�I�ݨD*/
            if (iins==5 || iins==9 || iins==120 || iins==125 || iins==126|| iins==198|| iins==181 ||
                iins==205 || iins==209)
            {
                iMaxDrate = atoi(tmp_frate);
                if(iMaxDrate<93)
                {
                    printf("11620::05+09\n");
                    pdmg_acc_main = pdmg_acc2;
                    if (dmg_acc_Insert==0) dmg_acc_Insert = 2;
                    qdmg_acc_sum_main = qdmg_acc_sum2;
                    strcpy(iquery_num_damage_main , iquery_num_damage2);
                }
                else
                {
                    /* 1070212002-SC1 0301�O�v�վ�0501�ͮ� 93�O�v+161+162(�ˮ֤��152+153�A�O�O���98) 05.09��P01���T�J�`*/
                    pdmg_acc_main = pdmg_acc;
                    if (dmg_acc_Insert==0) dmg_acc_Insert = 1;
                    qdmg_acc_sum_main = qdmg_acc_sum;
                    strcpy(iquery_num_damage_main , iquery_num_damage); 
                }
            }
            else if (iins==85 || iins==105 || iins==118 )
            {
                if (funknown_dmg[0]=='1') /* �������l�O���覡�O (�s��)*/
                {
                    pdmg_acc_main = pdmg_acc;
                    if (dmg_acc_Insert==0) dmg_acc_Insert = 1;
                    qdmg_acc_sum_main = qdmg_acc_sum;
                    strcpy(iquery_num_damage_main , iquery_num_damage);
                }
                else
                {
                    pdmg_acc_main = pdmg_acc3;
                    if (dmg_acc_Insert==0) dmg_acc_Insert = 3;
                    qdmg_acc_sum_main = qdmg_acc_sum3;
                    strcpy(iquery_num_damage_main , iquery_num_damage3);
                }
            }
            else if (iins==1 || iins==122 || iins==201)
            {
                pdmg_acc_main = pdmg_acc;
                if (dmg_acc_Insert==0) dmg_acc_Insert = 1;
                qdmg_acc_sum_main = qdmg_acc_sum;
                strcpy(iquery_num_damage_main , iquery_num_damage);

            }
            else if (iins==152 || iins==153)
            {
                if (funknown_dmg[0]=='4') /* �������l�O���覡�O (�s��)*/
                {
                    punknown_acc_main = punknown_acc;
                    qunknown_acc_sum_main = qunknown_acc_sum;
                    strcpy(iquery_num_unknown_main , iquery_num_unknown);
                }
                else
                {
                    punknown_acc_main = punknown_acc2;
                    qunknown_acc_sum_main = qunknown_acc_sum2;
                    strcpy(iquery_num_unknown_main , iquery_num_unknown2);
                }
            }

            printf("32293--pdmg_acc_main=[%f]qdmg_acc_sum_main=[%d]iquery_num_damage_main=[%s]\n",
            pdmg_acc_main,qdmg_acc_sum_main,iquery_num_damage_main);
            printf("32293--punknown_acc_main=[%f]qunknown_acc_sum_main=[%d]iquery_num_unknown_main=[%s]\n",
            punknown_acc_main,qunknown_acc_sum_main,iquery_num_unknown_main);

            /* *********************************************************************************************************************
               85�I�س����ܧ�@�~�{���ק� add by sylvia 101.04.12 (1010312006_C1)
               �HŪ�� car_code �]�w��, ���O22, �ӥإN��1 = 01 �Ҩ��o�����(detail)�@�ϧO

               �O�v�ͮĤ� >= car_code �]�w, �ķs�p���k :
                  (�I�������򥻯«O�I�O �� �Q�O�I�T���s�y�~�פζO�v�N���Y�� + �i���B�������l�«O�I�O�j) �� (�~�֩ʧO�Y�� + �ߴڬ����Y��)
               �O�v�ͮĤ� < car_code �]�w, ���­p���k :
                  �I�������򥻯«O�I�O �� �Q�O�I�T���s�y�~�פζO�v�N���Y�� �� (�~�֩ʧO�Y�� + �ߴڬ����Y��) + �i���B�������l�«O�I�O�j

               ��z��{���ץ���:
                  (�«O�I�O �� �Q�O�I�T���s�y�~�פζO�v�N���Y�� +(�s)�������l) �� (�~�֩ʧO�Y�� + �ߴڬ����Y��) + (��)�������l)
                  �O�v�ͮĤ� >= car_code �]�w : (��)�������l = 0;
                  �O�v�ͮĤ� < car_code �]�w : (�s)�������l = 0;
            *************************************************************************************************************************/

            if (iins==85)
            {
                $SELECT case when drate >=
                             (select date(detail2) from car_code
                               where kind = '22'and detail='01')
                        then '1' else '0' end
                   INTO $f1010515
                   FROM ca_rate_date
                  WHERE icode  = $tmp_frate
                    AND itable = 'cover_vs_premium';

                /* �I��85���������l�����ݭn�q�O�B�O�O�ɤ���X�򥻫O�O,�A�[�W����������I�O�O */
                $SELECT mpremium, mpremium, pextra_charge/100
                   INTO $tmppure1, $tmp_pure, $pextra_charge
                   FROM cover_vs_premium
                  WHERE icar_type  = $cal_car_id
                    AND iins_type  = $tmp_iins
                    AND mcoverage1 = $tmpcover_1
                    AND drate      = (SELECT drate
                                        FROM ca_rate_date
                                       WHERE icode=$tmp_frate
                                         AND itable='cover_vs_premium');
                if (SQLCODE == SQLNOTFOUND) return M_CA_NCOVER_PREM;

                if (f1010515[0] == '1')
                {
                    /* �A�ηs��k, �º�k���������l�«O�O=0 */
                    tmp_pure = 0.0;   /* �������l�«O�O(�º�k) */
                }
                else
                {
                    /* �A���º�k, �s��k���������l�«O�O=0 */
                    tmppure1 = 0.0;   /* �������l�«O�O(�s��k) */
                }
                printf("85�I�ح��B= (�s)tmppure1=[%f](��)tmp_pure=[%f]\n",tmppure1,tmp_pure);
            }

            tmppure105 = 0.0;
            if (iins==105 || iins==118 || iins==152 || iins==153) /*1030725001_C1 �ߦw(118)�B����(120)����[�N�B���O�I*/
            {
                /* �s�A������(105)�O�O�ס]�s�A�������I�«O�O�Ϥ������l�^�������I�s�y�~�׫Y�ơ��]�~�֩ʧO�Y�ơϬ����Y�ơ^�^���]���Ъ��[�O�βv�^*/
                /* �I��105���������l�����ݭn�q�O�B�O�O�ɤ���X�򥻫O�O */
                $SELECT mpremium, pextra_charge/100
                   INTO $tmppure105, $pextra_charge
                   FROM cover_vs_premium
                  WHERE icar_type  = $cal_car_id
                    AND iins_type  = $tmp_iins
                    AND mcoverage1 = $tmpcover_1
                    AND drate      = (SELECT drate
                                        FROM ca_rate_date
                                       WHERE icode=$tmp_frate
                                         AND itable='cover_vs_premium');
                if (SQLCODE == SQLNOTFOUND) return M_CA_NCOVER_PREM;
                printf("%d�I�ح��B= [%f]\n",iins,tmppure105);

            }
            /* car9901133 ���[����E�O�B,�ȾA�Ω���/���d */
            /* �Y�OE���ګh���ܼƥ������ѵe���L�Ӫ��O�B,����⧹�O�O
               �H�ά����ˮ֫�A�N�e���W���O�B��^�n�s�J��Ʈw���O�B�T��� */
            printf("juila tmpcover3[%ld],mcover3[%ld]\n",tmpcover_3,ins_ptr->damage_cover);


            if (iins!=152 && iins!=153 )
            {
                tmpcover_3 = ins_ptr->damage_cover;

                if (flag_new==TRUE)
                {
                    ins_ptr->damage_cover = cover_01;
                }
                else
                {
                    ins_ptr->damage_cover = cover_01;
                }

                
                damage_cover_01=ins_ptr->damage_cover;

                if(damage_cover_01<=1200000)
                    high_coef=1.00;
                else if((damage_cover_01>=1200001) && (damage_cover_01<=1800000))
                    high_coef=0.95;
                else if(damage_cover_01>=1800001)
                    high_coef=0.90;

                /***** ??????? *****/
                prem0203=damage_cover_01*0.00045;
                
            }
            /*  �]1041221009_C1_���T���d�I�Y�Ƭd�߳W�h�վ�^
                �����I�������P�_�i�H²�Ƭ��G
                [���ءG 03,04,21,22,2C,19,9B(�ۥ�)   + 07,08,14,15,2A,8A,4A,2B,9A(��~)	]
                  �] �Y 03,04,19,21,22,ISNEW_CAR1(s) + 07,08,14,15,ISNEW_CAR2(s) �^
                    �O�O�p�⤽�� = �򥻫O�O x �O�v�N���Y�� x (�ʧO�~�֫Y�� + �ߴڬ����Y��)
                           (�Y�� ��~�� �� �k�H, �ʧO�~�֫Y�� = 1 )
                [��L����]
                    �O�O�p�⤽�� = ���m���� �� �򥻶O�v �� ( 1 + �t�P���t�[��O�Y��) �� ( 1 + ���ִ�O�Y�� + �ߴڬ����Y�� )
            */
            /* �O�O */
            printf("01@@@@@ mprem[%f] dmg_factor[%f]\n",mprem,dmg_factor);
            printf("01@@@@@ psex_age2[%f] pdmg_acc[%f], psex_age_damage[%f]\n",psex_age2,pdmg_acc,psex_age_damage);
            printf("01@@@@@ ins_ptr->psex_age[%f]\n",ins_ptr->psex_age);
            printf("01@@@@@ iins = [%d]pdmg_acc2[%f] pdmg_acc3[%f], pdmg_acc_main[%f]\n",iins,pdmg_acc2,pdmg_acc3,pdmg_acc_main);
            printf("01@@@@@ punknown_acc_main[%f]\n",punknown_acc_main);
            printf("01@@@@@ prate_1[%f] short_prate[%f]\n",prate_1,short_prate);
            printf("01@@@@@ ���ִ�O�Y��[%f] ee1[%f]\n",aa,ee1);
            printf("01@@@@@ car_price[%f] bb11[%f]\n",car_price,bb11);
            printf("01@@@@@ high_coef[%f],prem0203[%d]\n",high_coef,prem0203);
            printf("01@@@@@ tmppure1=[%f]tmp_pure=[%f]tmppure105=[%f]\n",tmppure1,tmp_pure,tmppure105);
            printf("car9905052,ins_ptr->psex_age[%f]\n",ins_ptr->psex_age);


            /* car9905052 �s�O�v�����I�|�����P���Y��,�ҥH�n���I�ت��~�֩ʧO�Y�ƨӭp��O�O */
            /*1100909003-SC1-�_�@�Ϯ��S�h���p�{������07+15�}���O181�I�ݨD*/
            if (iins==181)
            {
                dbl_psex_age  = 1.0;
            }
            else if ( (fcar_class2[0]=='2') || (assuredf[0]=='2' || assuredf[0]=='4' || assuredf[0]=='6') )
            {
                dbl_psex_age  = 1.0;
            }
            else
            {
                dbl_psex_age = ins_ptr->psex_age ;
            }

            /* �t�X�����I���G��,�m���Ѽ� pdmg_acc �אּ pdmg_acc_main modify by sylvia 102.11.12 (10209210001_C1)*/
            if ( strcmp(cal_car_id,"03")==0 || strcmp(cal_car_id,"04")==0 || strcmp(cal_car_id,"21")==0 || strcmp(cal_car_id,"22")==0 || strcmp(cal_car_id,"19")==0 ||
                 strcmp(cal_car_id,"07")==0 || strcmp(cal_car_id,"08")==0 || strcmp(cal_car_id,"14")==0 || strcmp(cal_car_id,"15")==0 ||
                 (ISNEW_CAR1(cal_car_id))   || (ISNEW_CAR2(cal_car_id))
               )
            {
                double tmp_dmg_factor;
                double tmp_mprem;
                double tmp_punknown_acc_main;
                double tmp_pdmg_acc_main;

                tmp_dmg_factor = dmg_factor ;
                tmp_mprem = mprem ;
                tmp_punknown_acc_main = punknown_acc_main ;
                tmp_pdmg_acc_main = pdmg_acc_main;
                /*1100909003-SC1-�_�@�Ϯ��S�h���p�{������07+15�}���O181�I�ݨD*/
                if (iins==152 || iins==153|| iins==181)
                {
                    tmp_mprem = 0.0;
                    tmppure1 = 0.0;
                    if (iins==153|| iins==181) tmp_dmg_factor = 1;
                    tmp_pdmg_acc_main = 0.0;
                }
                else
                {
                    tmp_punknown_acc_main = 0.0;
                }
                if (iins==181)
                {
                    printf("==============181=====AAAAAAAAAAAAAA==============\n");
                    if (strstr( ins_ptr->provision, "E") != NULL)
                    {  
                        lEcover11 = tmpcover_3;
                    }
                    else
                    {
                        lEcover11 = ins_ptr->damage_cover;
                    }
                     
                    ins_ptr->ins_premium     = (double)(lEcover11)*prate_1*short_prate; /*** round ***/
                    ins_ptr->bef_ins_premium = (double)(lEcover11)*prate_1*short_prate; /*** round ***/  
                    printf("-- trace ins_ptr->ins_premium     [%f]\n ",ins_ptr->ins_premium );
                    printf("-- trace ins_ptr->bef_ins_premium [%f]\n ",ins_ptr->bef_ins_premium );             	             	            
                }
                else
                {

                    ins_ptr->ins_premium     = ((tmp_mprem+tmppure105)*tmp_dmg_factor + tmppure1)*(dbl_psex_age+tmp_pdmg_acc_main+tmp_punknown_acc_main)*short_prate; /*** round ***/
                    ins_ptr->bef_ins_premium = ((tmp_mprem+tmppure105)*tmp_dmg_factor + tmppure1)*(dbl_psex_age+tmp_pdmg_acc_main+tmp_punknown_acc_main)*short_prate; /*** round ***/
                }
                printf("ins_ptr->ins_premium[%f],ins_ptr->bef_ins_premium[%f]\n",ins_ptr->ins_premium,ins_ptr->bef_ins_premium);
                /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X J���ڰ���*/
                
            }
            else  /* ��L���� �L "�������l�I�ضO�v" */
            {
                if (iins==181)  /*1100909003-SC1-�_�@�Ϯ��S�h���p�{������07+15�}���O181�I�ݨD*/
                {   
                    printf("===========181===BBBBBBBBBBBBBBB===================\n");
                      
                    if (strstr( ins_ptr->provision, "E") != NULL)
                    {  
                        lEcover11 = tmpcover_3;
                    }
                    else
                    {
                        lEcover11 = ins_ptr->damage_cover;
                    }
                     
                    ins_ptr->ins_premium     = (double)(lEcover11)*prate_1*short_prate; /*** round ***/
                    ins_ptr->bef_ins_premium = (double)(lEcover11)*prate_1*short_prate; /*** round ***/                      
                    printf("-- trace lEcover11     [%f]\n ",lEcover11 );  
                    printf("-- trace ins_ptr->ins_premium     [%f]\n ",ins_ptr->ins_premium );
                    printf("-- trace ins_ptr->bef_ins_premium [%f]\n ",ins_ptr->bef_ins_premium );             	             	            
                    
                }
                else
                {
                    ins_ptr->ins_premium     = (car_price*10000.0*prate_1+tmppure1+tmppure105)*(1.0+bb11)*(1.0+aa+pdmg_acc_main)*short_prate;
                    ins_ptr->bef_ins_premium = (car_price*10000.0*prate_1+tmppure1+tmppure105)*(1.0+bb11)*(1.0+aa+pdmg_acc_main)*short_prate;
                }
            }

            if (iins==85)
            {
                /* �I��85���������l�����ݭn�q�O�B�O�O�ɤ���X�򥻫O�O,�A�[�W����������I�O�O */
                /* �������l�w�b�e������X��,�è� �O�v�ͮĤ�P�_�i���B�������l�«O�I�O�j���B */
                tmp_pure *= short_prate;
                ins_ptr->ins_premium += tmp_pure;
                ins_ptr->bef_ins_premium += tmp_pure;
                /*�����I�|�N�O�B�@�G�M���s,��85�I�حn�O�d�O�B�@*/
                ins_ptr->injured_cover =  tmpcover_1;
            }
            else if (iins==105||iins==118)
            {
                /*�����I�|�N�O�B�@�G�M���s,��105�I�حn�O�d�O�B�@*/
                ins_ptr->injured_cover =  tmpcover_1;
            }
            else if (iins==152||iins==153)
            {
                ins_ptr->damage_cover  =  tmpcover_1;
            }

            /* car9901133 ���[����E�O�B,�ȾA�Ω���/���d */
            printf("juila EEE tmpcover3[%ld],mcover3[%ld]\n",tmpcover_3,ins_ptr->damage_cover);

            if (iins!=152 && iins!=153 )
            {   
            	/* 1080408008-SC1-98������09+K */
                /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N�� sProvDelimiter */
                if ((strstr(sProvDelimiter, "E;") != NULL)||(strstr(sProvDelimiter, "K;") != NULL))
                    ins_ptr->damage_cover = tmpcover_3;
            }

        }
        else if ((iins==11) || (iins==96) || (iins==129) || (iins==211))
        {

            /* �O�B */
            ins_ptr->injured_cover = 0;
            ins_ptr->death_cover   = 0;
            /* damage_cover of '11' always equal to damage_cover of '01' */

            /* car9901133 ���[����E�O�B,�ȾA�Ω���/���d */
            /* �Y�OE���ګh���ܼƥ������ѵe���L�Ӫ��O�B,����⧹�O�O
                �H�ά����ˮ֫�A�N�e���W���O�B��^�n�s�J��Ʈw���O�B�T��� */
            /* �ѵs�I���O�O�p�⤽���������,�H���m���p�⪺�覡,�e���W��J���O�B�T���v�T�O�O
               ���t�@�حp�⪺�覡�O�H�O�B�T�ӭp��O�O��,�n�H�e���W��J���O�B�T�p��O�O */

            tmpcover_3 = ins_ptr->damage_cover;

            if (damage_cover_01==0)
            {
                /* car9612252 �����ѵs�O�B�p�� */
                ins_ptr->damage_cover = cover_01;

            }
            else
            {
                ins_ptr->damage_cover=damage_cover_01;
            }

            /* �O�O */
            printf("11@@@@@ prate_1[%f] short_prate[%f]\n",prate_1,short_prate);
            printf("11@@@@@ bb12[%f] ee3[%f]\n",bb12,ee3);

            /* 1050226003_C1�s�W�u�T���O�I���w���²v���[���ڡv�@�~ */
            /* 1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N�� if (strstr( ins_ptr->provision, "Z") != NULL) */
            if (strstr(sProvDelimiter, "Z;") != NULL)
            {
                strcpy(fProvision_Z,"Y");
                Provision_Z_150=1;
            }
            else
            {
                strcpy(fProvision_Z,"N");
                Provision_Z_150=0;
            }
            printf("-- trace fProvision_Z[%s]\n ",fProvision_Z);

            /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N�� if (strstr( ins_ptr->provision, "P") != NULL) */
            if (strstr(sProvDelimiter, "P;") != NULL)
            {
                strcpy(fProvision_P,"Y");
            }
            else
            {
                strcpy(fProvision_P,"N");
            }
            printf("-- trace fProvision_P[%s]\n ",fProvision_P);

            /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N�� if (strstr( ins_ptr->provision, "Q") != NULL) */
            if (strstr(sProvDelimiter, "Q;") != NULL)
            {
                strcpy(fProvision_Q,"Y");
            }
            else
            {
                strcpy(fProvision_Q,"N");
            }
            printf("-- trace fProvision_Q[%s]\n ",fProvision_Q);
            
            
            /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N�� if (strstr( ins_ptr->provision, "M") != NULL) */
            if (strstr(sProvDelimiter, "M;") != NULL)
            {
                strcpy(fProvision_M,"Y");
            }
            else
            {
                strcpy(fProvision_M,"N");
            }
            printf("-- trace fProvision_M[%s]\n ",fProvision_M);
            
            if (fProvision_Z[0]=='Y')
            {
                $SELECT 1-(pdepreciate/100) into $NewYearDep
                   FROM depreciation_rate a
                  WHERE drate = (select drate from ca_rate_date where icode = $tmp_frate
                                    and itable = 'depreciation_rate')
                    AND fcar_class = '4'
                    AND qperiod_end  = '12';
            }
            else if (fProvision_P[0]=='Y')  /* 1061205007_C1_���������ڰӫ~�Χ��²v���[���ڤW�u */
            {
                $SELECT 1-(pdepreciate/100) into $NewYearDep
                   FROM depreciation_rate a
                  WHERE drate = (select drate from ca_rate_date where icode = $tmp_frate
                                    and itable = 'depreciation_rate')
                    AND fcar_class   = '6'
                    AND qperiod_end  = '12';           	 
            }
            else if (fProvision_Q[0]=='Y')  /* 1061205007_C1_���������ڰӫ~�Χ��²v���[���ڤW�u */
            {
                $SELECT 1-(pdepreciate/100) into $NewYearDep
                   FROM depreciation_rate a
                  WHERE drate = (select drate from ca_rate_date where icode = $tmp_frate
                                    and itable = 'depreciation_rate')
                    AND fcar_class   = '7'
                    AND qperiod_end  = '12';           	 
            }
            else if (fProvision_M[0]=='Y')  /* 1081105005-SC1-��ã��-�ק���~���w���ƫ������²v�Φۭt�B(M����)*/
            {
                $SELECT 1-(pdepreciate/100) into $NewYearDep
                   FROM depreciation_rate a
                  WHERE drate = (select drate from ca_rate_date where icode = $tmp_frate
                                    and itable = 'depreciation_rate')
                    AND fcar_class   = '8'
                    AND qperiod_end  = '12';           	 
            }
            else
            {
   
                /**********************************************************/
                /* 11�B96�I�ت��O�O�p��H(cover_01_tmp/tmp_cover_dep)         */
                /* �ӫD(cover_01/cover_dep)-->for other insurance company */
                /**********************************************************/
                /* ��102/07/01�_���²v���̶O�v�N���Ϥ� */
                /* 1061205007_C1_���������ڰӫ~�Χ��²v���[���ڤW�u 
                   1071226006-SC1-��ã��-�w���ƫ����վ�(���²v+�ĤT�H�d��)  �������w�q��*/
                /* ��102/07/01���²v����ɦ�,��g�p�U,��P�_���� */
                
                printf("tmp_frate = [%s]\n",tmp_frate);
                $SELECT 1-(pdepreciate/100) into $NewYearDep
                   FROM depreciation_rate a
                  WHERE drate = (select drate from ca_rate_date where icode = $tmp_frate
                                    and itable = 'depreciation_rate')
                    AND fcar_class = (select case when icar_grp = '1' then '3' else fcar_class end
                                        from car_type where fclass = '1' and icode = $car_typei2)
                    AND qperiod_end  = '12';	
                
            }
            
            printf("-- trace NewYearDep[%f]\n ",NewYearDep);
            /*  �]1041221009_C1_���T���d�I�Y�Ƭd�߳W�h�վ�^
                �ѵs�I�������P�_�i�H²�Ƭ��G
                [���ءG 03,04,21,22,2C,19,9B(�ۥ�) + 07,08,14,15,2A,8A,4A,2B,9A(��~)	]
                �] �Y 03,04,19,21,22,ISNEW_CAR1(s) + 07,08,14,15,ISNEW_CAR2(s) �^
                    �O�O�p�⤽�� = ���m���� �� �򥻶O�v �� �O�v�N���Y�� �� �վ�Y��
                [��L����]
                    �O�O�p�⤽�� = �O�I���B �� �򥻶O�v �� ( 1 + �t�P���t�[��O�Y��)
            */

            if ( strcmp(cal_car_id,"03")==0 || strcmp(cal_car_id,"04")==0 || strcmp(cal_car_id,"21")==0 || strcmp(cal_car_id,"22")==0 || strcmp(cal_car_id,"19")==0 ||
                 strcmp(cal_car_id,"07")==0 || strcmp(cal_car_id,"08")==0 || strcmp(cal_car_id,"14")==0 || strcmp(cal_car_id,"15")==0 ||
                 (ISNEW_CAR1(cal_car_id))   || (ISNEW_CAR2(cal_car_id))
               )
            {
                adj_age = int_ply_yr - atoi(pro_year);
                if (adj_age > 4) adj_age = 4;

                adj_yr_dep = MyPower(NewYearDep, adj_age);

                printf("11@@@@@, adj_age[%d] adj_yr_dep[%f]NewYearDep=[%f]\n",adj_age,adj_yr_dep,NewYearDep);
                /* 2017/12/4 �d��H�U�L����˥h  d45�j���i��|�ɭP  999.5 �K~ 999.9�K �o�ͤ��p�߶i�� �Ρ] + 0.000000001 �^�A����ƪ��覡*/
                tmp_cover_dep = (long) (car_price*10000.0*adj_yr_dep + 0.000000001);
                thousand_cover_dep = tmp_cover_dep % 1000;
                if (thousand_cover_dep != 0)
                {
                    cover_dep    = (tmp_cover_dep)-(thousand_cover_dep)+1000;
                    cover_dep_11 = tmp_cover_dep - thousand_cover_dep;
                }
                else
                {
                    cover_dep    = tmp_cover_dep;
                    cover_dep_11 = tmp_cover_dep;
                }

                printf("11@@@@@ car_price[%f] brg_factor[%f]\n",car_price,brg_factor);
                printf("11@@@@@ cover_01_11[%ld], cover_dep_11[%ld]\n",cover_01_11,cover_dep_11);
                printf("PREM=car_price*prate_1*short_prate*brg_factor\n");
                printf("                      *(cover_01_11/cover_dep_11)\n");
                printf("-------->�ۥΨ� car_price=[%f]tmpcover_3=[%ld]\n",car_price,tmpcover_3);
                printf("-------->�ۥΨ���l cover_01_11 = [%ld] \n", cover_01_11);
                printf("year_dep=[%f]pdepreciate=[%f]\n",year_dep,pdepreciate);

                /* �A��E���ڮ�, �ѵs�I�O�O���վ�]�l, ����l�n�H�O�B3�ӭp�� modify by sylvia 101.05.30(1010315001_C1) */
                /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N�� if (strstr( ins_ptr->provision, "E") != NULL) */
                if (strstr(sProvDelimiter, "E;") != NULL)
                {
                    printf("----- �A�ηs�s -------- 30542\n");
                    lEcover11 = tmpcover_3;
                    lEthousand11 = lEcover11 % 1000;
                    if (lEthousand11 != 0)
                    {
                        cover_01_11 = lEcover11 - lEthousand11;
                    }
                    else
                    {
                        cover_01_11 = lEcover11;
                    }
                    printf("-------->�ۥΨ��A��E����: cover_01_11 = [%ld] \n", cover_01_11);
                }

                ins_ptr->ins_premium     = car_price*10000.0*prate_1*short_prate*brg_factor
                                           *((double)cover_01_11/(double)cover_dep_11);    /*** round ***/
                ins_ptr->bef_ins_premium = car_price*10000.0*prate_1*short_prate*brg_factor
                                            *((double)cover_01_11/(double)cover_dep_11);   /*** round ***/
                
                /* 1050801002_C1 ����~�S�w�γ~�ΩT�w�ϥΤH���[���� */
                ins_premium_03     = ins_ptr->ins_premium;
                bef_ins_premium_03 = ins_ptr->bef_ins_premium;

            }
            else
            { 
            	/* car9901133 ���l�վ�O�B���[����E��,�O�O�p��ϥεe���WE���ڪ��O�B */
                /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N�� if (strstr( ins_ptr->provision, "E") != NULL) */
                if (strstr(sProvDelimiter, "E;") != NULL)
                {
                    lEcover11 = tmpcover_3;
                }
                else
                {
                    lEcover11 = ins_ptr->damage_cover;
                }

                ins_ptr->ins_premium     = (double)(lEcover11)*prate_1*short_prate*(1.0+bb12); /*** round ***/
                ins_ptr->bef_ins_premium = (double)(lEcover11)*prate_1*short_prate*(1.0+bb12); /*** round ***/
            }

            printf("11@@@@@ ins_premium[%lf]\n",ins_ptr->ins_premium);
            printf("11@@@@@ bef_ins_premium[%lf]\n",ins_ptr->bef_ins_premium);

            /* car9901133 ���[����E�O�B,�ȾA�Ω���/���d */
            /* 1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N�� if (strstr( ins_ptr->provision, "E") != NULL) */
            if (strstr(sProvDelimiter, "E;") != NULL)
                ins_ptr->damage_cover = tmpcover_3;

            premium_11 = ins_ptr->damage_cover*short_prate+0.005;
            premium_12 = ins_ptr->damage_cover+0.005;
            printf("11@@@@@ premium_11[%d],premium_12[%d] FOR iins 12\n",premium_11,premium_12);
        }
        else if (iins==18)   /*   940210  */
        {
            /* �O�B */
            ins_ptr->injured_cover = 0;
            ins_ptr->death_cover   = 0;

            /* car9901133 ���[����E�O�B,�ȾA�Ω���/���d */
            /* �Y�OE���ګh���ܼƥ������ѵe���L�Ӫ��O�B,����⧹�O�O
               �H�ά����ˮ֫�A�N�e���W���O�B��^�n�s�J��Ʈw���O�B�T��� */
            /* �ѵs�I���O�O�p�⤽�����H���m���p��,���H�e���W��J���O�B�p�� */
            tmpcover_3 = ins_ptr->damage_cover;

            /* damage_cover of '11' always equal to damage_cover of '01' */
            if (damage_cover_01==0)
            {
                /* car9612252 �����ѵs�O�B�p�� */
                ins_ptr->damage_cover = cover_01;
            }
            else
            {
                ins_ptr->damage_cover=damage_cover_01;
            }

            /* car9901133 ���l�վ�O�B���[����E��,�O�O�p��ϥεe���WE���ڪ��O�B */
            /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N�� if (strstr( ins_ptr->provision, "E") != NULL) */
            if (strstr(sProvDelimiter, "E;") != NULL)
            {
                ins_ptr->ins_premium     = (double)(tmpcover_3)*prate_1*short_prate;
                ins_ptr->bef_ins_premium = (double)(tmpcover_3)*prate_1*short_prate;

                /* for calculate premium of iins_type='12' */
                premium_11 = tmpcover_3*short_prate+0.005;
                premium_12 = tmpcover_3+0.005;
            } 
            else
            {
                ins_ptr->ins_premium     = (double)(ins_ptr->damage_cover)*prate_1*short_prate;
                ins_ptr->bef_ins_premium = (double)(ins_ptr->damage_cover)*prate_1*short_prate;

                /* for calculate premium of iins_type='12' */
                premium_11 = ins_ptr->damage_cover*short_prate+0.005;
                premium_12 = ins_ptr->damage_cover+0.005;
            }

            printf("18@@@@@ ins_premium[%lf]\n",ins_ptr->ins_premium);
            printf("18@@@@@ bef_ins_premium[%lf]\n",ins_ptr->bef_ins_premium);

            /* car9901133 ���[����E�O�B,�ȾA�Ω���/���d */
            /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N�� if (strstr( ins_ptr->provision, "E") != NULL) */
            if (strstr(sProvDelimiter, "E;") != NULL)
                ins_ptr->damage_cover = tmpcover_3;

            printf("18@@@@@ premium_11[%d],premium_12[%d] FOR iins 12\n",premium_11,premium_12);
        }
        else if (iins==25)
        {
            printf("25@@@@@ prate_1[%f] short_prate[%f]\n",prate_1,short_prate);

            ins_ptr->death_cover=0;

            ins_ptr->ins_premium     = (double)ins_ptr->injured_cover*prate_1
                                       *((double)ins_ptr->damage_cover/(double)ins_ptr->injured_cover)
                                       *short_prate;           /*** round ***/

            ins_ptr->bef_ins_premium = (double)ins_ptr->injured_cover*prate_1
                                       *((double)ins_ptr->damage_cover/(double)ins_ptr->injured_cover)
                                       *short_prate;           /*** round ***/

            printf("25@@@@@ ins_premium[%lf]\n",ins_ptr->ins_premium);
        
        }
        else if (iins==20 || iins==23 || iins==102 || iins==111)
        {
            /* 103.04.30:1030407005_C1_�ӽзs�ӫ~�W�u-������X�O�I*/
            ins_ptr->injured_cover   = 0;
            ins_ptr->death_cover     = 0;

            /* 103.04.30 111 �i���[E����*/
            /* 103.04.03 20,23,86 �i���[E����*/
            tmpcover_3 = ins_ptr->damage_cover;
            if (iins==20||iins==111)
            {
                low_dmg_cover  = (long)cover_20*0.9;
                high_dmg_cover = (long)cover_20*1.1;

                if ( ins_ptr->damage_cover >= high_dmg_cover )
                {
                    ins_ptr->damage_cover=cover_20;
                }
                else if( ins_ptr->damage_cover == 0)
                    ins_ptr->damage_cover=cover_20;
            }
            else if (iins==23)
            {
                /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N�� if (strstr( ins_ptr->provision, "E") != NULL) */
                if (strstr(sProvDelimiter, "E;") != NULL)
                {
                    /* ��E���ڡA���ˮ֫O�B�W�� */
                }
                else
                {
                    /* 23�I�ثO�B�T���o�j�󭫸m������75% */
                    /* �ȴ��ܰT��,�����_�{������ modify by sylvia 100.07.26 (car990727) */
                    if( ins_ptr->damage_cover >= cover_20)
                    {
                        strcpy(errmsg_chk, itoa(M_CA_OVER_75_PERCENT));
                        if (strstr(errmsg_tmp, errmsg_chk) == NULL)
                        {
                            strcat(errmsg_tmp, errmsg_chk);
                            strcat(errmsg_tmp, ";");
                        }
                    }
                }
            }

            printf("-- trace ins_ptr->provision[%s]\n ",ins_ptr->provision);
            printf("-- trace ins_ptr->damage_cover[%ld]\n ",ins_ptr->damage_cover);

            if (iins==111)
            {
                printf("-- trace ply2_period[%d]\n ",ply2_period);
                if(ply2_period <= 12 )
                {       
                    /* <= 1�~ */
                    /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N�� if (strstr( ins_ptr->provision, "E") != NULL) */
                    if (strstr(sProvDelimiter, "E;") != NULL)
                    {
                        ins_ptr->ins_premium  = (double)tmpcover_3*prate_1*short_prate;
                        ins_ptr->damage_cover = tmpcover_3 ;
                    }
                    else
                    {
                        ins_ptr->ins_premium  = (double)ins_ptr->damage_cover*prate_1*short_prate;  /*** round ***/
                    }
                }
                else if( ply2_period == 24 )
                {  
                    /* 1�~11�Ӥ�H�W��2�~�� */
                    /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N�� if (strstr( ins_ptr->provision, "E") != NULL) */
                    if (strstr(sProvDelimiter, "E;") != NULL)
                    {
                        ins_ptr->ins_premium  = (double)tmpcover_3*prate_1_sec;
                        ins_ptr->damage_cover = tmpcover_3 ;
                    }
                    else
                    {
                        ins_ptr->ins_premium  = (double)ins_ptr->damage_cover*prate_1_sec;
                    }
                }
                else if((ply2_period > 12) && (ply2_period < 24))
                {  
                    /* �j��1�~�B �p�� 1�~11�Ӥ� */
                    double ins_premium_1st, ins_premium_sec;

                    /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N�� if (strstr( ins_ptr->provision, "E") != NULL) */
                    if (strstr(sProvDelimiter, "E;") != NULL)
                    {
                        ins_premium_1st  = (double)tmpcover_3*prate_1;
                        ins_premium_sec  = (double)tmpcover_3*prate_1_sec;
                    }
                    else
                    {
                        ins_premium_1st  = (double)ins_ptr->damage_cover*prate_1;
                        ins_premium_sec  = (double)ins_ptr->damage_cover*prate_1_sec;
                    }

                    ins_ptr->ins_premium = ins_premium_1st +
                                           ((ins_premium_sec-ins_premium_1st) * (iSecondYear2/12.0));
                }
                else
                {
                    return M_CA_47_PERIOD; /*4533=�ӫO�~�����~�A�Ь��ӫO��*/
                }

                ins_ptr->bef_ins_premium = ins_ptr->ins_premium ;
            }
            else
            {   
                /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N�� if (strstr( ins_ptr->provision, "E") != NULL) */
                if (strstr(sProvDelimiter, "E;") != NULL)
                {
                    printf("-- trace ins_ptr->provision[%s]\n ",ins_ptr->provision);
                    ins_ptr->ins_premium      = (double)tmpcover_3*prate_1*short_prate;  /*** round ***/
                    ins_ptr->bef_ins_premium  = (double)tmpcover_3*prate_1*short_prate;  /*** round ***/
                    ins_ptr->damage_cover     = tmpcover_3 ;
                }
                else
                {
                    ins_ptr->ins_premium      = (double)ins_ptr->damage_cover*prate_1*short_prate;  /*** round ***/
                    ins_ptr->bef_ins_premium  = (double)ins_ptr->damage_cover*prate_1*short_prate;  /*** round ***/
                }
            }
        }
        else
        {
            ins_ptr->injured_cover   = 0;
            ins_ptr->death_cover     = 0;

            ins_ptr->ins_premium     = (double)ins_ptr->damage_cover*prate_1*short_prate;  /*** round ***/
            ins_ptr->bef_ins_premium = (double)ins_ptr->damage_cover*prate_1*short_prate;  /*** round ***/
        }
        
    }
    else if (strcmp(trim(ical_ins),"01")==0)
    {   
    	/* �̨����I�p��           */
        /* 02,03,04               */
        /* 07    �����I���l�K���� 940210 */

        /********************************/
        /* �䭷�x���a�_�I               */
        /* �t�X���بT��JT�~�P�M�פ���� */
        /* ���ˮ֫O�d��91.08.05         */
        /* ���O�ĤE�쬰1:����JT�M��     */
        /********************************/


        if ((iins == 2) &&
            (equip_cmp(equipment,"9") == TRUE) &&
            ((strncmp(officer2, "C", 1) == 0) || (strncmp(officer2, "D", 1) == 0)) &&
            (dwritten <= cm_ymd_cdate("91/08/15")))
        {
            Scan_INS_TYPE(11);
        }
        else
        {
            if (! Scan_INS_TYPE(1))
            {
                if (! Scan_INS_TYPE(5))
                {
                    if(! Scan_INS_TYPE(9))
                        if (!Scan_INS_TYPE(8))
                            if (!Scan_INS_TYPE(85))
                                if (!Scan_INS_TYPE(86))
                                    if (!Scan_INS_TYPE(98))
                                        if (!Scan_INS_TYPE(105))
                                            if (!Scan_INS_TYPE(110))
                                                if (!Scan_INS_TYPE(118))
                                                    if (!Scan_INS_TYPE(120))
                                                        if (!Scan_INS_TYPE(122))
                                                            if (!Scan_INS_TYPE(125))
                                                                if (!Scan_INS_TYPE(126))
                                                                    if (!Scan_INS_TYPE(161))
                                                                        if (!Scan_INS_TYPE(162))
                                                                            if (!Scan_INS_TYPE(198))
                                                                                if (!Scan_INS_TYPE(181))
                                                                                    if (!Scan_INS_TYPE(201))
                                                                                        if (!Scan_INS_TYPE(205))
                                                                                            if (!Scan_INS_TYPE(209))
                                                                                                return M_CA_INS01;
                }/* 1070212002-SC1 0301�O�v�վ�0501�ͮ� 93�O�v+161+162(�ˮ֤��152+153�A�O�O���98)*/
            }/* 1090812005-SC1-���ά�-�s�W�s�ӫ~-�T�����B���郞�I���l���O�I198�I*/
            /*1100909003-SC1-�_�@�Ϯ��S�h���p�{������07+15�}���O181�I�ݨD*/
        }
        /* 1061205007_C1_���������ڰӫ~�Χ��²v���[���ڤW�u */
        /* P���� Q���� �Ȫ������i���[�A��150 151 ��03 22���إi�ӫO�A�G���ݳB�z */

        if (iins == 150)
        {
            printf("tmp_frate = [%s]\n",tmp_frate);
            printf("car_typei2 = [%s]\n",car_typei2);
            printf("NewYearDep[%f]\n",NewYearDep);
            printf("--150-- car_price[%f]\n", car_price * 10000);
            printf("--150-- cover_01_11[%f]\n", (double)cover_01_11 );

            ins_ptr->injured_cover = Icurr->injured_cover;
            ins_ptr->death_cover   = Icurr->death_cover;
            /* 20190318 ���ծɵo�{ ����ܨ�d���*/
            ins_ptr->damage_cover =  (long)(((car_price * 10000) - (cover_01_11 * NewYearDep))/1000)*1000;
            ins_ptr->deduct        = 0;

        }
        else if(iins == 176||iins == 177)
        {
            printf("iins[%d],mdamage_cover[%ld]\n",iins, Icurr->damage_cover);
            ins_ptr->injured_cover = Icurr->injured_cover;
            ins_ptr->death_cover   = Icurr->death_cover;
            ins_ptr->damage_cover  = Icurr->damage_cover;	
        }
        else
        {
            printf("iins[%d],mdamage_cover[%ld]\n",iins, Icurr->damage_cover);
            ins_ptr->injured_cover = Icurr->injured_cover;
            ins_ptr->death_cover   = Icurr->death_cover;
            ins_ptr->damage_cover  = Icurr->damage_cover;
            ins_ptr->deduct        = 0;
        }

        if (*fcal_class=='2')
        {    
            /* �̨����I�O�O�p��    */
            /* 07.�����I���l�K���� */
            /* 150.����l���O�I���l�z�߭��m�����¦���[����*/
            printf("INTO 07\n");
            printf("Icurr->ins_premium[%f]\n",Icurr->ins_premium);
            printf("prate_1[%f]\n",prate_1);

            if( iins==7 || iins==10 || iins==127 || iins==150 )
            {
                /* 07�����I���l�K����,�M10�K�l�v�H�����I "�W���O�O" �p��X�W���O�O,�A����«O�O */

                /*1030523002_C1*/
                printf("-- trace dbl_pcar_price_01[%f]\n ",dbl_pcar_price_01);
                printf("-- trace dbl_ProP_main_dmg[%f]\n ",dbl_ProP_main_dmg); 
                printf("-- trace dbl_ProQ_main_dmg[%f]\n ",dbl_ProQ_main_dmg); 
                printf("-- trace dbl_ProM_main_dmg[%f]\n ",dbl_ProM_main_dmg); /* 1081105005-SC1-��ã��-�ק���~���w���ƫ������²v�Φۭt�B(M����)*/
                printf("-- trace dbl_ProK_main_dmg[%f]\n ",dbl_ProK_main_dmg);  /* 1080408008-SC1-98������09+K*/
                printf("-- trace dbl_ProD_main_dmg[%f]\n ",dbl_ProD_main_dmg); /* 1080815003-SC1-��ã��-�ק靈���[H�BD���ڭp�⤽��-���PQK*/  
                printf("-- trace dbl_ProH_main_dmg[%f]\n ",dbl_ProH_main_dmg); /* 1080815003-SC1-��ã��-�ק靈���[H�BD���ڭp�⤽��-���PQK*/  
                printf("-- trace dbl_ProY_main_dmg[%f]\n ",dbl_ProY_main_dmg); /*1130827011_C02_�s�W�s�t��W�B���[����(Y)�A�Щ�11/1�W�u*/
                printf("-- trace provision_K[%f]\n ",provision_K);
                
                ins_ptr->pcar_price  = dbl_pcar_price_01 ;
                                            
                ins_ptr->ins_premium     = dbl_pure_prem01_n*dbl_ProK_main_dmg*dbl_ProP_main_dmg*dbl_ProQ_main_dmg*dbl_ProM_main_dmg*(1+dbl_ProD_main_dmg)*dbl_ProH_main_dmg*dbl_ProY_main_dmg*prate_1 ; /*1071226006-SC1-��ã��-�w���ƫ����վ�(���²v+�ĤT�H�d��) [�D�I�«O�O(�w�g*�L���[���ګY�Ʀ]�l)* �򥻶O�v  */
                ins_ptr->bef_ins_premium = ins_ptr->ins_premium ;
                ins_ptr->mpure_prem_n    = ins_ptr->ins_premium ;

                printf("-- trace dbl_pure_prem01_n        [%f]\n ",dbl_pure_prem01_n);
                printf("-- trace ins_ptr->ins_premium     [%f]\n ",ins_ptr->ins_premium );
                printf("-- trace ins_ptr->bef_ins_premium [%f]\n ",ins_ptr->bef_ins_premium );
                printf("-- trace ins_ptr->mpure_prem_n    [%f]\n ",ins_ptr->mpure_prem_n );
                printf("-- ins_ptr->provision  1  [%s]\n ",ins_ptr->provision );

            }
            else
            {
                ins_ptr->ins_premium     = (double)Icurr->ins_premium*prate_1;  /*** round ***/
                ins_ptr->bef_ins_premium = (double)Icurr->ins_premium*prate_1;  /*** round ***/
            }
        }
        else
        {   
            /* �̨����I�O�B�p�� */
            if (iins==2)
            {  
            	/* �䭷�x��     �a�_�I */
                ins_ptr->ins_premium     = (double)Icurr->damage_cover*prate_1; /*** round ***/
                ins_ptr->bef_ins_premium = (double)Icurr->damage_cover*prate_1; /*** round ***/
            }
            else
            {
                ins_ptr->ins_premium     = (double)Icurr->damage_cover*prate_1*short_prate; /*** round ***/
                ins_ptr->bef_ins_premium = (double)Icurr->damage_cover*prate_1*short_prate; /*** round ***/
            }
        }
    }
    else if (strcmp(trim(ical_ins),"11")==0)
    {   
    	/* 13:�r�p�V�m�ѵs�I 17:�ѵs�I���l�K���� 130:���ľ��c�ѵs���l�K���ª��[�I 151:�ѵs�l���O�I���l�z�߭��m�����¦���[���� */

        if (!Scan_INS_TYPE(11))
            if (!Scan_INS_TYPE(129))
                if (!Scan_INS_TYPE(211))
                    return M_CA_INS11;

        printf("-- trace iins[%d]\n ",iins);

        if (iins == 151)
        {
            printf("--151-- car_price[%f]\n", car_price * 10000);
            printf("NewYearDep[%f]\n",NewYearDep);
            ins_ptr->injured_cover = Icurr->injured_cover;
            ins_ptr->death_cover   = Icurr->death_cover;
            /* 20190318 ���ծɵo�{ ����ܨ�d���*/
            ins_ptr->damage_cover = (long)(((car_price * 10000) - (cover_01_11 * NewYearDep))/1000)*1000;
            ins_ptr->deduct        = 0;

        }
        else
        {
            ins_ptr->injured_cover = Icurr->injured_cover;
            ins_ptr->death_cover   = Icurr->death_cover;
            ins_ptr->damage_cover  = Icurr->damage_cover;
            ins_ptr->deduct=0;
        }

        if (*fcal_class=='2')
        {   
            /* �̥D�I:�ѵs�I11���u�ݫe�O�O�p�� */

            /* 17:�ѵs�I���l�K���� */
            /* 17:�ѵs�I���l�K���ª����p��W����ñ��O�O,�A����«O�O*/
            /*1030523002_C1*/ 
            /*1071226006-SC1-��ã��-�w���ƫ����վ�(���²v+�ĤT�H�d��) [�D�I�«O�O(�w�g*�L���[���ګY�Ʀ]�l)* �򥻶O�v  */
            ins_ptr->ins_premium     = dbl_pure_prem17_n*dbl_ProP_main_brg*dbl_ProQ_main_brg*dbl_ProM_main_brg*prate_1 ;
            ins_ptr->bef_ins_premium = ins_ptr->ins_premium ;
            ins_ptr->mpure_prem_n    = ins_ptr->ins_premium ;

            printf("-- trace dbl_pure_prem17_n        [%f]\n ",dbl_pure_prem17_n);
            printf("-- trace ins_ptr->ins_premium     [%f]\n ",ins_ptr->ins_premium );
            printf("-- trace ins_ptr->bef_ins_premium [%f]\n ",ins_ptr->bef_ins_premium );
            printf("-- trace ins_ptr->mpure_prem_n    [%f]\n ",ins_ptr->mpure_prem_n );
        }
        else
        {
            ins_ptr->ins_premium     = (double)Icurr->damage_cover*prate_1*short_prate; /* round */
            ins_ptr->bef_ins_premium = (double)Icurr->damage_cover*prate_1*short_prate; /* round */
        }

        /* for calculate premium of iins_type = '12' */
        premium_11 = ins_ptr->damage_cover*short_prate+0.005;
        premium_12 = ins_ptr->damage_cover+0.005;
    }
    else if (strcmp(trim(ical_ins),"31")==0)
    {   
    	/* 24,26 */

        if ( Scan_INS_TYPE(149) || Scan_INS_TYPE(249))
        {
            injured_cover   = Icurr->injured_cover;
            death_cover     = Icurr->injured_cover;
            damage_cover    = Icurr->damage_cover;
            deduct          = Icurr->deduct;
            ins_premium     = Icurr->ins_premium;
            bef_ins_premium = Icurr->bef_ins_premium;
        }
        else
        {
            if (! Scan_INS_TYPE(31) && ! Scan_INS_TYPE(36) && ! Scan_INS_TYPE(231) && ! Scan_INS_TYPE(531))  return M_CA_INS31;

            injured_cover   = Icurr->injured_cover;
            death_cover     = Icurr->injured_cover;
            damage_cover    = Icurr->damage_cover;
            deduct          = Icurr->deduct;
            ins_premium     = Icurr->ins_premium;
            bef_ins_premium = Icurr->bef_ins_premium;

            if (! Scan_INS_TYPE(32) && ! Scan_INS_TYPE(37) && ! Scan_INS_TYPE(232) && ! Scan_INS_TYPE(532));
            injured_cover   = injured_cover   + Icurr->injured_cover;
            death_cover     = death_cover     + Icurr->injured_cover;
            damage_cover    = damage_cover    + Icurr->damage_cover;
            deduct          = deduct          + Icurr->deduct;
            ins_premium     = ins_premium     + Icurr->ins_premium;
            bef_ins_premium = bef_ins_premium + Icurr->bef_ins_premium;
        }

        ins_ptr->injured_cover = injured_cover;
        ins_ptr->death_cover   = death_cover;
        ins_ptr->damage_cover  = damage_cover;
        ins_ptr->deduct        = deduct;

        /* 24,26�I�بS���ۭt�B(�k0)  add by sylvia 103.01.06 1021210002_C1 */
        ins_ptr->deduct = 0;
        /* ---------------------------------------------------------------- */
        printf("24@@@@@ prate_1[%f] short_prate[%f]\n",prate_1,short_prate);


        if (fcal_class[0]=='2')
        {   
            /* 24,26�I�ةҺ�X���O�O�O�W���O�O�ӫD���«O�O */

            pextra_charge = ins_ptr->pextra_charge;

            /*1030523002_C1*/
            ins_ptr->ins_premium     = premium_3132_n*prate_1*short_prate ;
            ins_ptr->bef_ins_premium = ins_ptr->ins_premium ;
            ins_ptr->mpure_prem_n    = ins_ptr->ins_premium ;

            printf("-- trace premium_3132_n           [%f]\n ",premium_3132_n);
            printf("-- trace ins_ptr->ins_premium     [%f]\n ",ins_ptr->ins_premium );
            printf("-- trace ins_ptr->bef_ins_premium [%f]\n ",ins_ptr->bef_ins_premium );
            printf("-- trace ins_ptr->mpure_prem_n    [%f]\n ",ins_ptr->mpure_prem_n );


        }
        else
        {
            ins_ptr->ins_premium     = (double)damage_cover*prate_1*short_prate;  /* round */
            ins_ptr->bef_ins_premium = (double)damage_cover*prate_1*short_prate;  /* round */
        }
        printf("{Calculate_cover_prem}:24 ins_premium[%lf]\n",ins_ptr->ins_premium);
        
    }
    else if (strcmp(trim(ical_ins),"77")==0)
    {   
    	/* �I��88:��X�I���[���s */
        printf("======== �I��88:��X�I���[���s ========================\n");
        if (! Scan_INS_TYPE(77) && ! Scan_INS_TYPE(78))  return M_CA_INS7778;

        if (! Scan_INS_TYPE(77));
        injured_cover   = Icurr->injured_cover;
        death_cover     = Icurr->injured_cover;
        damage_cover    = Icurr->damage_cover;
        deduct          = Icurr->deduct;
        ins_premium     = Icurr->ins_premium;
        bef_ins_premium = Icurr->bef_ins_premium;

        if (! Scan_INS_TYPE(78));
        injured_cover   = injured_cover   + Icurr->injured_cover;
        death_cover     = death_cover     + Icurr->injured_cover;
        damage_cover    = damage_cover    + Icurr->damage_cover;
        deduct          = deduct          + Icurr->deduct;
        ins_premium     = ins_premium     + Icurr->ins_premium;
        bef_ins_premium = bef_ins_premium + Icurr->bef_ins_premium;

        ins_ptr->injured_cover = injured_cover;
        ins_ptr->death_cover   = death_cover;
        ins_ptr->damage_cover  = damage_cover;
        ins_ptr->deduct        = deduct;

        if (fcal_class[0]=='2')
        {   
            /* 88 �I�ةҺ�X���O�O�O�W���O�O�ӫD���«O�O */

            pextra_charge = ins_ptr->pextra_charge;
            
            /*1030523002_C1*/
            ins_ptr->ins_premium     = premium_3132_n*prate_1*short_prate ;
            ins_ptr->bef_ins_premium = ins_ptr->ins_premium ;
            ins_ptr->mpure_prem_n    = ins_ptr->ins_premium ;

            printf("-- trace premium_3132_n           [%f]\n ",premium_3132_n);
            printf("-- trace ins_ptr->ins_premium     [%f]\n ",ins_ptr->ins_premium );
            printf("-- trace ins_ptr->bef_ins_premium [%f]\n ",ins_ptr->bef_ins_premium );
            printf("-- trace ins_ptr->mpure_prem_n    [%f]\n ",ins_ptr->mpure_prem_n );
        }
        else
        {
            ins_ptr->ins_premium     = (double)damage_cover*prate_1*short_prate;  /* round */
            ins_ptr->bef_ins_premium = (double)damage_cover*prate_1*short_prate;  /* round */
        }
        printf("{Calculate_cover_prem}:24 ins_premium[%lf]\n",ins_ptr->ins_premium);
    }

    #ifdef GCAR


    /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ݼW�[�����P�_�H�Q�Ϲj�h�X�N�� sProvDelimiter*/
    if((strstr(sProvDelimiter, "F;") != NULL) || (strstr(sProvDelimiter, "G;") != NULL) || (strstr(sProvDelimiter, "I;") != NULL) || (strstr(sProvDelimiter, "B;") != NULL))
    {
        /* �������[���ڤ��p��F�Ƭ����A�٭�F�Ƭ��� */
        /* car9804233�j�v���[����,���Ҽ{�F�Ƭ����A�٭�F�Ƭ��� */
        pdmg_acc = pdmg_acc_ori;			/* 01, 08,122�I�� */
        pdmg_acc2 = pdmg_acc_ori2;			/* 05, 09,120 ,125, 126�I�� */
        pdmg_acc3 = pdmg_acc_ori3;			/* 85,105,118,137,138�I�� */
        punknown_acc  = punknown_acc_ori;
        punknown_acc2 = punknown_acc_ori2;
    }
    printf("b-- trace punknown_acc[%f]\n ",punknown_acc);
    #endif
    printf("car9901133 ins_ptr->damage_cover[%ld]\n",ins_ptr->damage_cover);

    printf("-- trace iins[%d]\n ",iins);
    printf("-- ins_ptr->provision  3  [%s]sProvDelimiter[%s]\n ",ins_ptr->provision ,sProvDelimiter);
    return SUCCESS;
}

static int SetFactor()     /** calculate aa, bb2, cc, dd, ee1, ee2, ee3 **/
{
    int   car_age_yr, int_icode, flag_cnt=0;
    $char icode[3];
    $char ch[1+1];

    car_age_yr=car_age/12;

    $DECLARE cur_1 CURSOR FOR
      SELECT icode,palign
        INTO $icode,$aa
        FROM alignment
       WHERE fclass='5'
       ORDER BY icode DESC; /* AND MAX(icode)<=$car_age_year;*/
    $OPEN cur_1;
    $FETCH cur_1;
    if (NOT_FOUND) return M_CA_NALIGN_5;
    while (sqlca.sqlcode ==0)
    {
        int_icode=atoi(icode);
        if (int_icode <= car_age_yr)
        {
            flag_cnt++;
            break;
        }
        $FETCH cur_1;
    }
    $CLOSE cur_1;
    $FREE  cur_1;
    if (flag_cnt==0) aa=0;
    aa=aa/100.0;

    printf("-----------> dmg_align_1[%d]\n", dmg_align_1);
    printf("-----------> lia_align_1[%d]\n", lia_align_1);
    printf("-----------> brg_align_1[%d]\n", brg_align_1);

    ee1=0.00;
    ee2=0.00;
    ee3=0.00;

    return SUCCESS;
}

static int SetCarAge(off, bra, adj_year, Frate)
$char *off,*bra, *Frate;   /* off:iofficer, bra:brandi */
int adj_year;
{
    char  issue_ymd[12];         /* extend CY/MM to CY/MM/DD */
    char  datestring[16], yy[4], mm[3], dd[3], yy2[4], mm2[3];
    int   yy1,mm1,yy3,mm3, car_age20, car_age102;
    long  issue_date;
    $int  count_x=0;
    $long ply2_begin_next_year;
    double year_dep20, year_dep102;
    $double dep_rate;
    double year_dep_old, year_dep20_old;

    year_dep102 = 0;
    car_age102 = 0;
    printf("----------------adj_year[%d]\n", adj_year);
    
    /*** STEP 9 -- a. ; here we calculate car_age, year_dep ...etc.  ***/
    if (*cal_way=='M')
    {
        if (iSecondYear2 > 0)
        {
            $SELECT prate
               INTO $short_prate
               FROM short_period_rate
              WHERE qperiod=$ply3_period;
            if (NOT_FOUND)  return M_CA_NSHORT_RATE;
        }
        else
        {
            $SELECT prate INTO $short_prate
               FROM short_period_rate
              WHERE qperiod = $ply2_period;
            if (NOT_FOUND)  return M_CA_NSHORT_RATE;
        }
        short_prate=short_prate/100.0;
    }
    else
    {
        $select first 1 ($ply2_end - $ply2_begin) /
                (date_add( $ply2_begin, interval(1) year to year) - $ply2_begin)
           into $short_prate
           from systables;
    }
    
    /*** STEP 9 -- b. ***/
    cm_long_split_3ymd(dissue,yy,mm,dd);   /* Date(long)�ন����~�B��B��(yyy,mm,dd) */
    sprintf_s(issue_ymd,sizeof issue_ymd,"%s/%s/01",yy,mm);
    issue_date=cm_ymd_cdate(issue_ymd);    /* ����~���((y)yy/mm/dd)�নDate(long) */

    yy3=atoi(yy);
    mm3=atoi(mm);

    if( adj_year == 1) /* 20�I�ئh��@�~ */
    {
        $select first 1 (date_add( $ply2_begin, interval(1) year to year))
           into $ply2_begin_next_year
           from systables;

        car_age20=DiffMonth( ply2_begin_next_year, issue_date);
        car_age102=DiffMonth( ply2_begin_next_year, issue_date);


        if ((strcmp(car_typei2,"51") == 0) && ( car_age102/12 >= 4))
        {  
            /* �]���h��@�~�A�]���O>=4 */
            return M_CA_3_YEAR; /* ���֤T�~(�t)�H�W���q�ʦۦ樮.���i�ӱ� */
        }
    }

    car_age=DiffMonth(ply2_begin,issue_date);
    car_age_mth=car_age % 12;

    /** for flag_new **/
    strcpy(datestring,cm_cdate_str_100(ply2_begin)); /* Date(long)�ন����~���(yyy/mm/dd) */
    cm_split_ymd_100(datestring,yy,mm,dd);           /* ����~���((y)yy/mm/dd)��X�~�B��B�� */
    yy1=atoi(yy);
    int_ply_yr=yy1+1911; /* int_ply_yr for iins_type 11 */
    mm1=atoi(mm);

    if (yy3-yy1>0 || (yy3-yy1==0 && mm3-mm1>=0))
        flag_new=TRUE;
    else 
        flag_new=FALSE;

    /*** STEP 9 -- c. ***/
    printf("Frate = [%s]\n",Frate);
    printf("--in SetCarAge()1 trace fProvision_Z[%s]\n ",fProvision_Z);
    printf("--in SetCarAge()1 trace fProvision_P[%s]\n ",fProvision_P);
    printf("--in SetCarAge()1 trace fProvision_Q[%s]\n ",fProvision_Q);
    printf("--in SetCarAge()1 trace fProvision_M[%s]\n ",fProvision_M);/* 1081105005-SC1-��ã��-�ק���~���w���ƫ������²v�Φۭt�B(M����)*/
    
    if (fProvision_Z[0]=='Y')
    {
        $select 1-(pdepreciate/100) into $NewYearDep
           from depreciation_rate a
          where drate = (select drate from ca_rate_date where icode = $Frate
                           and itable = 'depreciation_rate')
            and fcar_class   = '4'
            and qperiod_end  = '12';           	 
    }
    else if (fProvision_P[0]=='Y')  /* 1061205007_C1_���������ڰӫ~�Χ��²v���[���ڤW�u */
    {
        $select 1-(pdepreciate/100) into $NewYearDep
           from depreciation_rate a
          where drate = (select drate from ca_rate_date where icode = $Frate
                            and itable = 'depreciation_rate')
            and fcar_class   = '6'
            and qperiod_end  = '12';           	 
    }
    else if (fProvision_Q[0]=='Y')  /* 1061205007_C1_���������ڰӫ~�Χ��²v���[���ڤW�u */
    {
        $select 1-(pdepreciate/100) into $NewYearDep
           from depreciation_rate a
          where drate = (select drate from ca_rate_date where icode = $Frate
                            and itable = 'depreciation_rate')
            and fcar_class   = '7'
            and qperiod_end  = '12';           	 
    }
    else if (fProvision_M[0]=='Y')  /* 1081105005-SC1-��ã��-�ק���~���w���ƫ������²v�Φۭt�B(M����)*/
    {
        $select 1-(pdepreciate/100) into $NewYearDep
           from depreciation_rate a
          where drate = (select drate from ca_rate_date where icode = $Frate
                           and itable = 'depreciation_rate')
            and fcar_class   = '8'
            and qperiod_end  = '12';           	 
    }
    else
    {
        /* ��102/07/01���²v����ɦ�,��g�p�U,��P�_���� */
        printf("Frate = [%s]\n",Frate);
        $select 1-(pdepreciate/100) into $NewYearDep
           from depreciation_rate a
          where drate = (select drate from ca_rate_date where icode = $Frate
                            and itable = 'depreciation_rate')
            and fcar_class = (select case when icar_grp = '1' then '3' else fcar_class end
                                from car_type where fclass = '1'
                                 and icode = $car_typei2)
            and qperiod_end  = '12';	
    }
    printf("--in SetCarAge()1 trace dep_rate--> NewYearDep[%f]\n ",NewYearDep);

    year_dep=MyPower(NewYearDep, car_age/12);
    if( adj_year == 1)
    {
        year_dep20=MyPower(NewYearDep, car_age20/12);
        year_dep102=MyPower(NewYearDep, car_age102/12);
    }

    printf("26093 -- Frate=[%s]NewYearDep=[%f]\n",Frate,NewYearDep);

    printf("########## car_age[%d] car_age_mth[%d]\n",car_age,car_age_mth);
    printf("########## fcar_class2[%s] year_dep[%f]year_dep20=[%f]year_dep102=[%f]\n", fcar_class2,year_dep,year_dep20,year_dep102);

    if (car_age_mth==0)
    {
        pdepreciate=0;
    }
    else
    {
        printf("--in SetCarAge()2 trace fProvision_Z[%s]\n ",fProvision_Z);
        if (fProvision_Z[0]=='Y')
        {
            $select max(pdepreciate), count(*)
               into $pdepreciate, $count_x
               from depreciation_rate
              where drate = (select drate from ca_rate_date
                              where icode = $Frate and itable = 'depreciation_rate')
                and fcar_class = '4'
                and qperiod_end >= $car_age_mth
                and qperiod_bgn < $car_age_mth;
        }
        else if (fProvision_P[0]=='Y')  /* 1061205007_C1_���������ڰӫ~�Χ��²v���[���ڤW�u */
        {
            $select max(pdepreciate), count(*)
               into $pdepreciate, $count_x
               from depreciation_rate
              where drate = (select drate from ca_rate_date
                              where icode = $Frate and itable = 'depreciation_rate')
                and fcar_class = '6'
                and qperiod_end >= $car_age_mth
                and qperiod_bgn < $car_age_mth;        	 
        }
        else if (fProvision_Q[0]=='Y')  /* 1061205007_C1_���������ڰӫ~�Χ��²v���[���ڤW�u */
        {
            $select max(pdepreciate), count(*)
               into $pdepreciate, $count_x
               from depreciation_rate
              where drate = (select drate from ca_rate_date
                              where icode = $Frate and itable = 'depreciation_rate')
               and fcar_class = '7'
               and qperiod_end >= $car_age_mth
               and qperiod_bgn < $car_age_mth;         	 
        }
        else if (fProvision_M[0]=='Y')  /* 1081105005-SC1-��ã��-�ק���~���w���ƫ������²v�Φۭt�B(M����)*/
        {
            $select max(pdepreciate), count(*)
               into $pdepreciate, $count_x
               from depreciation_rate
              where drate = (select drate from ca_rate_date
                              where icode = $Frate and itable = 'depreciation_rate')
                and fcar_class = '8'
                and qperiod_end >= $car_age_mth
                and qperiod_bgn < $car_age_mth;         
        }
        else
        {
            /* 1061205007_C1_���������ڰӫ~�Χ��²v���[���ڤW�u
               1071226006-SC1-��ã��-�w���ƫ����վ�(���²v+�ĤT�H�d��)  �������w�q��*/
               
            $select max(pdepreciate), count(*)
               into $pdepreciate, $count_x
               from depreciation_rate
              where drate = (select drate from ca_rate_date
                              where icode = $Frate and itable = 'depreciation_rate')
                and fcar_class = (select case when icar_grp = '1' then '3' else fcar_class end
                                    from car_type where fclass = '1' and icode = $car_typei2)
                and qperiod_end >= $car_age_mth
                and qperiod_bgn < $car_age_mth;
        }
        printf("--in SetCarAge()1 trace pdepreciate[%f]\n ",pdepreciate);

        if (count_x == 0)  return M_CA_NDEPRE_RATE;

        pdepreciate=pdepreciate/100.0;
    }

    printf("########## year_dep[%f] pdepreciate[%f]\n",year_dep,pdepreciate);
    printf("car_price*10000*year_dep*(1-pdepreciate)\n");

    /* 2017/12/4 �d��H�U�L����˥h  d45�j���i��|�ɭP  999.5 �K~ 999.9�K �o�ͤ��p�߶i�� �Ρ] + 0.000000001 �^�A����ƪ��覡*/
    cover_01_tmp = (long)floor(car_price*10000.0*year_dep*(1.0-pdepreciate)+ 0.000000001);    

    thousand_cover_01 = cover_01_tmp % 1000;
    printf("########## car_price[%f]\n",car_price);
    printf("########## cover_01_tmp[%ld]\n",cover_01_tmp);
    printf("########## thousand_cover_01[%ld]\n",thousand_cover_01);
    if (thousand_cover_01 != 0)
    {
        cover_01 = (cover_01_tmp)-(thousand_cover_01);
        cover_01_11 = cover_01_tmp - thousand_cover_01;
    }
    else
    {
        cover_01 = cover_01_tmp;
        cover_01_11 = cover_01_tmp;
    }
    printf("########## cover_01[%d]\n",cover_01);

    if( adj_year == 1) /* 20, 102�I�� */
    {
        cover_20_tmp = (long)floor(car_price*10000.0*year_dep20*(1.0-pdepreciate)+ 0.000000001);
        thousand_cover_20 = cover_20_tmp % 1000;
        if (thousand_cover_20 != 0)
        {
            cover_20 = (cover_20_tmp)-(thousand_cover_20);
        }
        else
        {
            cover_20 = cover_20_tmp;
        }
        printf("########## cover_20[%ld]\n",cover_20);

        cover_102_tmp = (long)floor(car_price*10000.0*year_dep102*(1.0-pdepreciate)+ 0.000000001);
        thousand_cover_102 = cover_102_tmp % 1000;
        if (thousand_cover_102 != 0)
        {
            cover_102 = (cover_102_tmp)-(thousand_cover_102);
        }
        else
        {
            cover_102 = cover_102_tmp;
        }
        printf("########## cover_102[%ld]\n",cover_102);
    }
    
    /*** STEP 9 -- d. ***/
    strcpy(cal_car_id,car_typei2);

    return SUCCESS;
}

static int Scan_INS_TYPE(itype)        /* return data in Icurr */
int itype;
{
    Icurr=Ifirst;
    while (Icurr)
    {
        if (atoi(rtrim(Icurr->ins_type))==itype) return SUCCESS;
        Icurr=Icurr->next;
    }
    return FAIL;
}

static int Scan_INS_TYPE_Prov(iprov)        /* return data in Icurr */
char iprov[7];
{
    $char sChkProvDelimiter[22];/*1081225006-SC1-���ά�-�X�R���[���ڥN�X    */
    Icurr=Ifirst;
    while (Icurr)
    {
        strcpy(sChkProvDelimiter,"");
        sprintf_s(sChkProvDelimiter,sizeof sChkProvDelimiter,"%s;",trim(Icurr->provision));
        printf("Scan_INS_TYPE_Prov[%s]-sChkProvDelimiter[%s]\n",iprov,sChkProvDelimiter);
        if (strstr(sChkProvDelimiter,iprov) != NULL) return SUCCESS;
        Icurr=Icurr->next;
    }
    return FAIL;
}

static ClearSendBackData()
{
    /***** It is option A&U STEP 10, or option 1234 STEP 9-g. ********/
    INS_ptr=Ifirst;
    while (INS_ptr)
    {
        if (*(INS_ptr->fdeduct)=='0')
        {
            INS_ptr->deduct=0;
        }
        INS_ptr=INS_ptr->next;
        
    }/** end while-INS_ptr **/
}

static int Insert_INS_TYPE(s1,
                           p1,p2,p3,
                           p4,
                           p5,p9,
                           p6,p7,p8,
                           s2,
                           p10,
                           p11,p12,p13,
                           s4, s5, s6,
                           s3,p14,
                           p15,p16, s7, s8, p17, safe_rate, manage_rate, educated_rate,
                           deviation_rate, pextra_charge, pbusiness, psex_age, pshipping, fproject,
                           lMdrunk_prem,dblMdrunk_pure_prem,pcar_price,lMviolate_prem,dblMviolate_pure_prem)
char   *s1,*s2;
char   *s3;
char   *s4, *s5, *s6, *s7, *s8, *fproject;
long   p1,p2,p3,p4;
long   p5,p9,p10;
double p6,p7,p8;
double p11,p12,p13,p14;
long   p15,p16,p17,lMdrunk_prem,lMviolate_prem;
double safe_rate, manage_rate, educated_rate, deviation_rate;
double pextra_charge, pbusiness, psex_age, pshipping,dblMdrunk_pure_prem,pcar_price,dblMviolate_pure_prem;
{

    /*** use a link list ***/
    Icurr=(struct INS_TYPE *)malloc(sizeof(struct INS_TYPE));
    if (Icurr==NULL) return FAIL;
    if (Ifirst==NULL)
    {     
        /* if it's first element?! */
        Ifirst=Ilast=Icurr;
        Icurr->next=NULL;
    }
    else  if (strcmp(trim(s1),"01")==0 || strcmp(trim(s1),"05")==0  || strcmp(trim(s1),"08")==0  || strcmp(trim(s1),"09")==0  ||
              strcmp(trim(s1),"85")==0 || strcmp(trim(s1),"105")==0 || strcmp(trim(s1),"118")==0 || strcmp(trim(s1),"120")==0 ||
              strcmp(trim(s1),"122")==0|| strcmp(trim(s1),"125")==0 || strcmp(trim(s1),"126")==0 ||
              strcmp(trim(s1),"11")==0 || strcmp(trim(s1),"96")==0  || strcmp(trim(s1),"129")==0 || strcmp(trim(s1),"98")==0 ||
              strcmp(trim(s1),"31")==0 || strcmp(trim(s1),"32")==0  || strcmp(trim(s1),"36")==0  || strcmp(trim(s1),"37")==0  ||
              strcmp(trim(s1),"77")==0 || strcmp(trim(s1),"78")==0  || strcmp(trim(s1),"103")==0 || strcmp(trim(s1),"104")==0 ||
              strcmp(trim(s1),"113")==0|| strcmp(trim(s1),"114")==0 || strcmp(trim(s1),"131")==0 || strcmp(trim(s1),"132")==0 ||
              strcmp(trim(s1),"133")==0|| strcmp(trim(s1),"134")==0 ||
              strcmp(trim(s1),"149")==0|| strcmp(trim(s1),"198")==0 || strcmp(trim(s1),"181")==0 ||
              strcmp(trim(s1),"201")==0|| strcmp(trim(s1),"205")==0 || strcmp(trim(s1),"209")==0 ||
              strcmp(trim(s1),"211")==0||
              strcmp(trim(s1),"231")==0|| strcmp(trim(s1),"232")==0 || strcmp(trim(s1),"331")==0 || strcmp(trim(s1),"332")==0 ||
              strcmp(trim(s1),"249")==0|| strcmp(trim(s1),"531")==0 || strcmp(trim(s1),"532")==0
             )
    { 
    	/*1090812005-SC1-���ά�-�s�W�s�ӫ~-�T�����B���郞�I���l���O�I198�I*/
        /*1100909003-SC1-�_�@�Ϯ��S�h���p�{������07+15�}���O181�I�ݨD*/
        /*1100311005-SC1-�����¦����s�A�������I�����{���]�w137�B138�B139�B141�B142�I�� strcmp(trim(s1),"137")==0 || strcmp(trim(s1),"138")==0 ||*/
        Icurr->next=Ifirst;
        Ifirst=Icurr;
    }
    else
    {
        Ilast->next=Icurr;
        Ilast=Icurr;
        Icurr->next=NULL;
    }

    strcpy(Icurr->ins_type,s1);
    strcpy(Icurr->frate,s2);

    Icurr->injured_cover    = p1;
    Icurr->death_cover      = p2;
    Icurr->damage_cover     = p3;
    Icurr->deduct           = p4;
    Icurr->ins_premium      = p5;
    Icurr->bef_ins_premium  = p9;
    Icurr->pure_ins_premium = p10;
    Icurr->pagent           = p6;
    Icurr->pcommission      = p7;
    Icurr->pdiscount        = p8;
    Icurr->broker_pagent    = p11;
    Icurr->broker_pcommi    = p12;
    Icurr->broker_pdisc     = p13;
    strcpy(Icurr->icheck_agent, s4);
    strcpy(Icurr->icheck_commi, s5);
    strcpy(Icurr->icheck_disc,  s6);
    strcpy(Icurr->ipaid_base,   s3);
    Icurr->pfix_agent       = p14;
    Icurr->qday             = p15;
    Icurr->mexpense         = p16;
    
    strcpy(Icurr->provision,  s7);
    strcpy(Icurr->itype_disc, s8);
    Icurr->mdiscount        = p17;

    Icurr->safe_rate        = safe_rate;      /* 'car9610231��~�βĤT�H�f�B�~���[���� */
    Icurr->manage_rate      = manage_rate;
    Icurr->educated_rate    = educated_rate;

    Icurr->deviation_rate   = deviation_rate; /* �«O�O�����v */
    Icurr->pextra_charge    = pextra_charge;
    Icurr->pbusiness        = pbusiness;
    Icurr->psex_age         = psex_age;       /* �I�ةʧO�~�֫Y�� */
    Icurr->pshipping        = pshipping;      /* car9808043 �f�B�~���[����C */
    strcpy(Icurr->fproject, fproject);        /* �O�_�M��(�ذe)�I��*/

    Icurr->mdrunk_prem      = lMdrunk_prem;  /* �s�r�[�O���� add by sylvia 103.01.09 (1020801002_C1) */
    Icurr->mdrunk_pure_prem = dblMdrunk_pure_prem;

    Icurr->pcar_price       = pcar_price;    /* �������[�O�Y�� 104.10.13 (1021211003_C3_�T������l���O�I�O�O�p��ǤJ�������Y�ƶO�v) */
    
    Icurr->mviolate_prem      = lMviolate_prem;  /* ���j�[�O�[�O���� add by 061476 111.06.14 (1110608012_SC1) */
    Icurr->mviolate_pure_prem = dblMviolate_pure_prem;

    rows++;

    return SUCCESS;
}

/*****
Insert_INS_TYPE_48(cIinsurant, cNinsurant, lDbirth, cIins_scope,
                   lMins_amt, lMins_premium,
                   dPcommission, lMcommission, dPagent, lMagent, dPdiscount, lMdiscount,
                   cRelation_appl, lMr_ins_premium, lMr_pure_premium )
****/
static int Insert_INS_TYPE_48(c1, c2, l1, c3, l2, l3, d1, l4, d2, l5, d3, l6, c4, l7, l8, l9)
char   *c1, *c2, *c3, *c4;
long   l1, l2, l3, l4, l5, l6, l7, l8, l9;
double d1, d2, d3;
{
    Icurr_48=(struct INS_TYPE_33 *)malloc(sizeof(struct INS_TYPE_33));

    if (Icurr_48==NULL) return FAIL;

    if (Ifirst_48==NULL)
    {
        Ifirst_48=Ilast_48=Icurr_48;
        Icurr_48->next=NULL;
    }
    else
    {
        Ilast_48->next = Icurr_48;
        Ilast_48       = Icurr_48;
        Icurr_48->next = NULL;
    }

    strcpy(Icurr_48->cIinsurant,     c1);
    strcpy(Icurr_48->cNinsurant,     c2);
    strcpy(Icurr_48->cIins_scope,    c3);
    strcpy(Icurr_48->cRelation_appl, c4);

    Icurr_48->lDbirth       = l1;
    Icurr_48->lMins_amt     = l2;
    Icurr_48->lMins_premium = l3;
    Icurr_48->dPcommission  = d1;
    Icurr_48->lMcommission  = l4;
    Icurr_48->dPagent       = d2;
    Icurr_48->lMagent       = l5;
    Icurr_48->dPdiscount    = d3;
    Icurr_48->lMdiscount    = l6;
    Icurr_48->lMr_ins_prem  = l7;
    Icurr_48->lMr_pure_prem = l8;
    Icurr_48->lDaily_pay    = l9;

    rows_48++;

    printf("--->in INS_TYPE_48 rows_48=[%d]\n", rows_48 );

    return SUCCESS;
}
/*****************************************************************/
static int Insert_INS_TYPE_35(c1, c2, c3, l1, l2, d1, l3, d2, l4, d3, l5 )
char   *c1, *c2, *c3;
long   l1, l2, l3, l4, l5;
double d1, d2, d3;
{
    Icurr_35=(struct INS_TYPE_33 *)malloc(sizeof(struct INS_TYPE_33));

    if (Icurr_35==NULL) return FAIL;

    if (Ifirst_35==NULL)
    {
        Ifirst_35=Ilast_35=Icurr_35;
        Icurr_35->next=NULL;
    }
    else
    {
        Ilast_35->next = Icurr_35;
        Ilast_35       = Icurr_35;
        Icurr_35->next = NULL;
    }

    strcpy(Icurr_35->cIinsurant,     c1);
    strcpy(Icurr_35->cNinsurant,     c2);
    strcpy(Icurr_35->cIins_scope,    c3);

    Icurr_35->lMins_amt     = l1;
    Icurr_35->lMins_premium = l2;
    Icurr_35->dPcommission  = d1;
    Icurr_35->lMcommission  = l3;
    Icurr_35->dPagent       = d2;
    Icurr_35->lMagent       = l4;
    Icurr_35->dPdiscount    = d3;
    Icurr_35->lMdiscount    = l5;

    rows_35++;

    printf("--->in INS_TYPE_35 rows_35=[%d]\n", rows_35 );

    return SUCCESS;
}
static int Insert_INS_TYPE_56(c1, c2, l1, c3, c4, c5, l2, l3, d1, l4, d2, l5, d3, l6, c6, c7, c8, c9, l7, l8, l9, c10, c11, c12)
char   *c1, *c2, *c3, *c4, *c5, *c6, *c7, *c8, *c9, *c10, *c11, *c12;
long   l1, l2, l3, l4, l5, l6, l7, l8, l9;
double d1, d2, d3;
{
    Icurr_56=(struct INS_TYPE_33 *)malloc(sizeof(struct INS_TYPE_33));

    if (Icurr_56==NULL) return FAIL;

    if (Ifirst_56==NULL)
    {
        Ifirst_56=Ilast_56=Icurr_56;
        Icurr_56->next=NULL;
    }
    else
    {
        Ilast_56->next = Icurr_56;
        Ilast_56       = Icurr_56;
        Icurr_56->next = NULL;
    }

    strcpy(Icurr_56->cIinsurant,     c1);
    strcpy(Icurr_56->cNinsurant,     c2);
    strcpy(Icurr_56->cAinsurant,     c3);
    strcpy(Icurr_56->cIins_scope,    c4);
    strcpy(Icurr_56->cIcareer,       c5);
    strcpy(Icurr_56->cNapplicant,    c6);
    strcpy(Icurr_56->cRelation_appl, c7);
    strcpy(Icurr_56->cNbeneficiary,  c8);
    strcpy(Icurr_56->cRelation_bene, c9);
    strcpy(Icurr_56->cTbenef,       c10);/*1090221006-SC1-��ã��-��_56�r�p�H�W�U*/
    strcpy(Icurr_56->cAbenef_zip,   c11);/*1090221006-SC1-��ã��-��_56�r�p�H�W�U*/
    strcpy(Icurr_56->cAbenef,       c12);/*1090221006-SC1-��ã��-��_56�r�p�H�W�U*/
    
    Icurr_56->lDbirth       = l1;
    Icurr_56->lMins_amt     = l2;
    Icurr_56->lMins_premium = l3;
    Icurr_56->dPcommission  = d1;
    Icurr_56->lMcommission  = l4;
    Icurr_56->dPagent       = d2;
    Icurr_56->lMagent       = l5;
    Icurr_56->dPdiscount    = d3;
    Icurr_56->lMdiscount    = l6;
    Icurr_56->lDaily_pay    = l7;
    Icurr_56->lMr_ins_prem  = l8;
    Icurr_56->lMr_pure_prem = l9;

    rows_56++;

    printf("--->in INS_TYPE_56 rows_56=[%d]\n", rows_56 );

    return SUCCESS;
}

/*1031111001_C1 ���O�X������{���վ� ( _CA_VERSION �w�q�b var_length.h )*/
/* 103.05.20 ���O�X��G�g�J cm_pre_receive.iins_kind_ply (�j��GC1 ; ���N�GC2)*/
static int Insert_Cm_pre_receive(iestimateno, sabntype, ipolicy_no, ipre_rcv_ori)   /* �g�J�@�γ������� */
char *iestimateno, *sabntype, *ipolicy_no, *ipre_rcv_ori;
{
    $char     iassured[20], ientry[7], icard1[21], icard2[21], ftype_pol[3], sIroute12[3];
    $double   mpremium1, mpremium2;
    $long     code,est_prem;
    $int      icount1, icount2, ifuw_status;
    $int      v_fstatus;

    $char     v_ipolicy[21],v_ipolicy1[21],v_ipolicy2[21],iins_kind[2],iins_kind_ply[3];
    $char     iofficer_tmp[11],sIleader_tmp[11],sIquota_tmp[7],icomm_obj_tmp[11],icard_tmp[21];	
    $date     ply_begin_tmp,ply_end_tmp;
    $double   mpremium_tmp;
    $char     sPaydate[11],ftype_sp[3],sDply_begin[11],sDply_end[11],sMsg[512],tmp_ipolicy[21];
     int      fEstPlyEdr = 0,iRtnCode;
    $char     tmp_fout_print[2] = " ",tmp_EstPlyEdr[21]=" ";
    $datetime year to second dt_dprint;
    $char     tmp_fcomp_daychk[2]= " ",fNonOutCard[2]=" ", sIpre_rcv_ori[21];
    $char     fsend_msg[2], mobile_phone[21], fassured[2],icar_type1[3],icar_type2[3],icar_type_tmp[3],irelative_ply[21];
    char      fIns58;
    $char fchk98[2] = " ";
    
    strcpy(estimatei, iestimateno);
    printf("estimatei=[%s]\n",estimatei);

    $WHENEVER SQLERROR GOTO ie_err;

    ifuw_status = 0;
    strcpy(v_ipolicy, ipolicy_no);
    if (strlen(trim(ipre_rcv_ori))==0)
    {   
        strcpy(sIpre_rcv_ori," ");
    }
    else
    {
        strcpy(sIpre_rcv_ori, ipre_rcv_ori);
    }
                    
    strcpy(iofficer_tmp ," ");
    strcpy(sIleader_tmp ," ");
    strcpy(sIquota_tmp  ," ");
    strcpy(icomm_obj_tmp," ");
    strcpy(icard_tmp    ," ");    
    strcpy(sDply_begin," ");
    strcpy(sDply_end," ");
    strcpy(sMsg," ");
    strcpy(iins_kind," ");
    strcpy(v_ipolicy1," ");
    strcpy(v_ipolicy2," ");
    tmp_fout_print[0] = '0';  tmp_fout_print[1] = '\0';
    strcpy(tmp_EstPlyEdr," ");
    strcpy(tmp_fcomp_daychk, "N"); 
    strcpy(fNonOutCard , " ");  /* �O�_�� "�D�~��d"(�j���I) */	
    strcpy(mobile_phone, " ");  
    strcpy(fsend_msg   , "N");  
    strcpy(fassured    , " ");
    strcpy(icar_type_tmp ," ");strcpy(icar_type1  , " ");strcpy(icar_type2  , " ");
    strcpy(irelative_ply , " ");
    fIns58 = 'N';
    fchk98[0] = 'N';        /*�O�_���O98:ñ�b�榬�^ (1130814005_C01_���OSP20�B�����Oñ�b�榬�^�ɡAcar301���ˬd�����v�~�i�H�X��) */
    fchk98[1] = '\0';
    
    dtcurrent(&dt_dprint);
            
    mpremium_tmp = 0.0;
    v_fstatus    = 10;    

    /* ����X��(�I�sInsert_Cm_pre_receive())��,�w�良�f�֪�������A�g�Jcm_pre_receive*/	
    if (strlen(trim(v_ipolicy))>0)
    { 

        printf("v_ipolicy=[%s]\n",v_ipolicy);
        
        /* 1040603001_c1 car301��car153�{���վ� */     	
        /*��O��(CR)�i��S���պ���(estimate)�A�G�@�߱q�O���ɧ� */
        $select a.itmp_policy, a.fcard_class,b.iassured,b.nassured,b.iapplicant,b.napplicant,
                b.itag,b.iengine, a.dply_begin,a.dply_end,(a.mdmg_prem+a.mlia_prem),a.iofficer,
                (select ileader from officer where iofficer = a.iofficer),
                (select iquota  from officer where iofficer = a.iofficer),
                a.icomm_obj,b.iroute, decode(a.ibig_comp, ' ', 'N', '2','N', '1'),
                a.ientry ,a.icard, b.iroute[1,2], a.fout_print, b.mobil_phone, b.fassured , a.icar_type,
                case when (a.fcard_class = '1' and nvl(c.qday_permit_c,0)>0) then 
                    case when (a.dply_begin-today) <= nvl(c.qday_permit_c,0) then 'Y' else 'N' end 
                else 'Y' end,
                case when a.fcard_class = '1' then 
                    case when a.icard = a.ipolicy then 'Y' else 'N' end
                else ' ' end , nvl(a.irelative_ply,' '),
                case when b.nequipment[8] in ('8','9','A','B','C','D','E','F') then 'Y' else 'N' end
           into $estimatei,$iins_kind, $iassured, $nassured, $iapplicant, $napplicant, 
                $itag, $iengine, $ply_begin_tmp,$ply_end_tmp, $mpremium_tmp, $iofficer_tmp,
                $sIleader_tmp, $sIquota_tmp, $icomm_obj_tmp, $iroute, $ibig_comp, 
                $ientry, $icard_tmp, $sIroute12 , $tmp_fout_print, $mobile_phone, $fassured, $icar_type_tmp,
                $tmp_fcomp_daychk, $fNonOutCard, $irelative_ply,
                $fchk98
           from ply_relation a, policy b, outer ca_permit c
          where a.ipolicy = b.ipolicy 
            and a.ipolicy = $v_ipolicy
            and (c.iclass = '05' AND b.iroute LIKE trim(c.icode)||'%' AND c.ftype_sp='20');
        printf("-- trace SQLCODE[%d]\n ",SQLCODE);	
        if (SQLCODE == SQLNOTFOUND) return M_CA_NESTIMATE;    
        
        ifuw_status = 550 ;
        fEstPlyEdr= 1 ; 
        strcpy(tmp_EstPlyEdr,v_ipolicy);
        
        if ((iRtnCode = split_policy(v_ipolicy, v_ipolicy1, v_ipolicy2)) != M_CM_OK)  return iRtnCode;   
        
        strcpy(iengine , rtrim(iengine));
        
        est_prem = 0 ;
        
        /* �p����N�I�M���`�O�O */
        if (iins_kind[0]=='1')
        {
            mpremium1  = mpremium_tmp;
            ply1_begin = ply_begin_tmp;
            ply1_end   = ply_end_tmp;
            strcpy(iofficer1  ,iofficer_tmp);
            strcpy(sIleader1  ,sIleader_tmp);
            strcpy(sIquota1   ,sIquota_tmp);
            strcpy(icomm_obj1 ,icomm_obj_tmp);
            strcpy(icard1     ,icard_tmp);
            strcpy(icar_type1 ,icar_type_tmp);
            
            mpremium2    = 0 ;
            strcpy(iofficer2," ");
            
            if (fNonOutCard[0]!='Y')
            { 
                /* �~��d =>�|������ñ��� */            	
                v_fstatus = 30;  /* �j���I => �w�L��(�����L��)*/
            }   
            
                    
        }
        else if (iins_kind[0]=='2')
        {
            
            mpremium2  = mpremium_tmp;
            ply2_begin = ply_begin_tmp;
            ply2_end   = ply_end_tmp;
            strcpy(iofficer2  ,iofficer_tmp);
            strcpy(sIleader2  ,sIleader_tmp);
            strcpy(sIquota2   ,sIquota_tmp);
            strcpy(icomm_obj2 ,icomm_obj_tmp);
            strcpy(icard2     ,icard_tmp);
            strcpy(icar_type2 ,icar_type_tmp);

            mpremium1    = 0 ;
            strcpy(iofficer1," ");
            /* 1061012002-SC3 ISID+rba�j���I�G�����X��@�~���L��� ���N�I ���ܦL��@�~���L���*/

            icount2 = 0 ;   
            $SELECT count(*) INTO $icount2
               FROM ply_ins_type
              WHERE ipolicy = $v_ipolicy
                AND iins_type = '58'; 
            if (icount2 > 0) fIns58 = 'Y';                        

        }

        /* 103.05.20 ���O�X��G�X����ɥ��֫O���ץ�,�b�X��ɦ۰ʶi��֫O�T�{�@�~�g�J�@�γ�������
                               �åB�^��������(�p�G������)���f�֪��A��550*/
        /*1060817004-C1 �q�lñ�p  system��q�lñ�p���֫O�H��isign �B�ݧ���ñ�p */
        printf("isign=[%s]sDunderTime[%s]\n",isign,sDunderTime);
        if (strncmp(isign,"system",6)==0)
        {    
            $Update estimate
                Set fuw_status = $ifuw_status,
                    iuw_first  = 'system',
                    duw_first  = current 
              Where iestimate  = $estimatei;
                
            if (strncmp(&estimatei[5],"CP",2) != 0 && strncmp(&estimatei[5],"CR",2) != 0)
            {
                $Update quotation_master
                    Set iapproval_status = 510
                  Where iquote  = $estimatei;
                  
                $Update ca_quotation
                    Set iuw_first  = 'system',
                        duw_first  = current
                  Where iquote  = $estimatei;
            }
        }
        else
        {
            $Update estimate
                Set fuw_status = $ifuw_status,
                    iuw_first  = $isign,
                    duw_first  = $sDunderTime 
              Where iestimate  = $estimatei;
                
            if (strncmp(&estimatei[5],"CP",2) != 0 && strncmp(&estimatei[5],"CR",2) != 0)
            {
                $Update quotation_master
                    Set iapproval_status = 510
                  Where iquote  = $estimatei;
                  
                $Update ca_quotation
                    Set iuw_first  = $isign,
                        duw_first  = $sDunderTime
                  Where iquote  = $estimatei;
            }
        }                                 
    }
    else
    {
           
        /* ���`�� */
        $select iestimate, iassured, nassured, iapplicant, napplicant, itag,
                iengine, dply1_begin, dply2_begin,dply1_end, dply2_end,
                mpremium1, mpremium2, iofficer1, iofficer2,
                (select ileader from officer where iofficer = iofficer1),
                (select ileader from officer where iofficer = iofficer2),
                (select iquota from officer where iofficer = iofficer1),
                (select iquota from officer where iofficer = iofficer2),
                icomm_obj1, icomm_obj2, iroute, mobil_phone, fassured,icar_type1,icar_type2,
                decode(ibig_comp, ' ', 'N', '2','N', '1'), ientry ,
                icard1, icard2, fuw_status, iroute[1,2]
           into $estimatei, $iassured, $nassured, $iapplicant, $napplicant, $itag,
                $iengine, $ply1_begin, $ply2_begin,$ply1_end, $ply2_end,
                $mpremium1, $mpremium2, $iofficer1, $iofficer2,
                $sIleader1, $sIleader2, $sIquota1, $sIquota2,
                $icomm_obj1, $icomm_obj2, $iroute, $mobile_phone, $fassured,$icar_type1,$icar_type2,
                $ibig_comp, $ientry,
                $icard1, $icard2, $ifuw_status, $sIroute12
           from estimate
          where iestimate = $estimatei;

        if (SQLCODE == SQLNOTFOUND) return M_CA_NESTIMATE;    

        strcpy(iengine , rtrim(iengine));
        
        /* �p����N�I�M���`�O�O */
        $select nvl(sum(nvl(mins_premium,0)),0) into $mpremium2
           from est_ins_type
          where iestimate =$estimatei
            and trim(iins_type) <> '21'
            and trim(fproject) <> 'Y';

        icount2 = 0 ;   
        $SELECT count(*) INTO $icount2
           FROM est_ins_type
          WHERE iestimate =$estimatei
            AND iins_type = '58'; 
        if (icount2 > 0) fIns58 = 'Y';

        /* 104.01.13 */
        /* ���FB2B��~, �X��ɤ~�|�g�J�O�d��.�b�պ�ɬҤ��g�J�O�d���ܦ@�γ������ɤ� */
        /* B2B�� : �I����H =BS(����) ; JH(���q) or �պ⸹[1,2] in ('BC','JC','VY') */
        strcpy(icomm_obj1, trim(icomm_obj1));
        strcpy(icomm_obj2, trim(icomm_obj2));
         
        /* �DB2B�����渹 */ 
        if( (strncmp(estimatei,"BC",2)!=0)&&(strncmp(estimatei,"JC",2)!=0)&&(strncmp(estimatei,"VY",2)!=0) )
        {        
            if ((strcmp(icomm_obj1,"BS")!=0)&&(strcmp(icomm_obj1,"JH")!=0)) /* �B�D���׶��q�I����H */ 
            {
                strcpy(icard1," ");
            }
            if ((strcmp(icomm_obj2,"BS")!=0)&&(strcmp(icomm_obj2,"JH")!=0)) /* �B�D���׶��q�I����H */ 
            {
                strcpy(icard2," ");
            }
        }       
        
        fEstPlyEdr= 0 ;  
        strcpy(tmp_EstPlyEdr, estimatei);
        
        /* 104.01.23 */
        if ((ifuw_status >= 500) && (ifuw_status < 600))
        {
            
            strcpy(iofficer1, trim(iofficer1));        
            if ((strlen(iofficer1) > 0) && (mpremium1 > 0))
            {
                
                icount1 = 0 ;
                $select count(ipre_rcv) into $icount1
                   from cm_pre_receive
                  where iins_cat = 'C'
                    and ipre_rcv = $estimatei
                    and iins_kind = '1';     
                if  (icount1 == 0)
                {
                    strcpy(iins_kind,"1");     /*  ���j�� */
                }
            }   
            
            strcpy(iofficer2, trim(iofficer2));            
            if ((strlen(iofficer2) > 0) && (mpremium2 > 0))
            {
                icount2 = 0 ; 
                $select count(ipre_rcv) into $icount2
                   from cm_pre_receive
                  where iins_cat = 'C'
                    and ipre_rcv = $estimatei
                    and iins_kind = '2'
                    and trim(ipre_end) = '';
                if  (icount2 == 0)
                {
                    if (iins_kind[0]=='1')
                    {
                        strcpy(iins_kind,"3"); /* �j+��*/
                    }
                    else
                    {
                        strcpy(iins_kind,"2"); /* �����N */
                    }
                }
            }
        }        
    }
    printf("-- trace ifuw_status[%d]\n ",ifuw_status);
    
    strcpy(iroute, trim(iroute));    
    strcpy(mobile_phone, trim(mobile_phone));
        
    if ((ifuw_status >= 500) && (ifuw_status < 600))
    {

        /* 1051214004_C2_�X�j²�T�q����H (�s�O)
           �]���ζ��`�޲z�B2017kpi�A�X�j���O²�T�q����H�A��պ�B�J��ɡA�̥H�U�ӫO�γq������g�J�@�γ����椧
          �u�O�_�o�e²�T(fsend_msg)�v�Ρu�Q�O�I�H��ʹq��(mobile_phone) �v���A�ѫ��򦬶O�ɰ]�|�ݱH�o²�T�ϥ�:
           1. �q���N�� = KA (�g��N�������s�έ��s+A)�C
           2. �Q�O�I�H���u�ꤺ�۵M�H�v�B��������X�C
           3. �ư�:��j���I�B�����B�q�ʦۦ樮�B�O�T�I�B���ը��C
           4. �ư�: �����X���J�b�ץ� (������Ѱ]�|�ݧP�_) �C
          
           �ŦX�W�z1.~3.����̡A������B�J��ᶷ��@�γ�������(cm_pre_receive.fsend_msg)
           ���O�� ���o�e²�T���A���O�w�q�p�U�A�æP�ɼg�J�u�Q�O�I�H��ʹq��(mobile_phone) �v:
           �O�_�o�e²�T(cm_pre_receive.fsend_msg)
           �o�e²�T	=>	1:��j 2:���  3:�j+��  (<= ����j�ݱư�)
           ���o�e²�T	=>	N*/
        /* 1051214004_C2_�X�j²�T�q����H (�s�O) */
        if ( (strlen(mobile_phone)==10) && (strncmp(mobile_phone,"09", 2)==0) )
        {
            if ( (fassured[0]=='1') && (strcmp(iroute,"KA")==0) && (fIns58 =='N') )
            {
                if ( fEstPlyEdr == 0 ) /* ���պ�� */
                {
                    if( ((iins_kind[0]=='2') || (iins_kind[0]=='3')) && (strlen(trim(icar_type2))>0) )
                    {
                        if ( strncmp(icar_type2,"01",2)!=0 && strncmp(icar_type2,"02",2)!=0 && strncmp(icar_type2,"32",2)!=0 && strncmp(icar_type2,"34",2)!=0 &&
                             strncmp(icar_type2,"35",2)!=0 && strncmp(icar_type2,"51",2)!=0 && strncmp(icar_type2,"T1",2)!=0 && strncmp(icar_type2,"T2",2)!=0 )
                        {
                            strcpy( fsend_msg, iins_kind);
                        }    
                    }
                }
                else                   /* �J���   */
                {
                    if ( strncmp(icar_type_tmp,"01",2)!=0 && strncmp(icar_type_tmp,"02",2)!=0 && strncmp(icar_type_tmp,"32",2)!=0 && strncmp(icar_type_tmp,"34",2)!=0 &&
                         strncmp(icar_type_tmp,"35",2)!=0 && strncmp(icar_type_tmp,"51",2)!=0 && strncmp(icar_type_tmp,"T1",2)!=0 && strncmp(icar_type_tmp,"T2",2)!=0 )
                    {
                        if (strlen(trim(irelative_ply))>0)  /* �����p�渹 =>  �j+�� */
                        {
                            strcpy(fsend_msg, "3");  
                        }
                        else
                        {
                            if (iins_kind[0]=='2') strcpy(fsend_msg, "2");  /* ��� */
                        }
                    }    
                }
            }  
        }
        else
        {    
            strcpy(mobile_phone, " " );
        }
        
        if (ply1f==TRUE) printf("--- 34663 ply1f==TRUE ----- \n");
        if (ply2f==TRUE) printf("--- 34664 ply2f==TRUE ----- \n");

        printf("ply2_begin=[%ld] ply1_begin=[%ld]\n",ply2_begin,ply1_begin);
        
        /* �j���I */
        /* 104.01.23 ,�ӫO"����N"�ɡA�p�G�����p�j��d�� => ply1f==TRUE  */
        if((iins_kind[0]=='1') || (iins_kind[0]=='3')) 
        {
            strcpy(sPaydate," ");   strcpy(ftype_pol, " ");  strcpy(ftype_sp," "); 
            code = get_pre_type_pol(tmp_EstPlyEdr, fEstPlyEdr , "1", sPaydate, ftype_pol, ftype_sp, sMsg);
            if (code != M_CM_OK) return code;

            printf("-- trace �j�� estimatei[%s]\n ",estimatei);
            printf("-- trace sPaydate[%s]\n ",sPaydate);
            printf("-- trace ftype_pol[%s]\n ",ftype_pol);
            printf("-- trace ftype_sp[%s]\n ",ftype_sp);
            if (strlen(trim(v_ipolicy))>0)
            {

                /* 1040416007_C1 �S�w�q��ñ��W�h�վ�
                    ��	�w��u�O�����O = SP-20�v�̡G
                    (1)	�Y[(�ͮĤ�-�t�Τ�) > 25��(�Y�uB2B���סB���q��v�h��10��)]
                        �B[�����O]�A�h�אּ���g�J��ñ��顨;�ӡu�@�γ�����v�����A���h
                        �g�J��10��(������)�B�L��ɶ����礣�g�J�C
                    (2)	�Y[(�ͮĤ�-�t�Τ�) �� 25��(�Y�uB2B���סB���q��v�h��10��)] 
                        ��[�w���O]�̡A�h�g�J��ñ���(=�t�Τ�)�� ;�ӡu�@�γ�����v�����A
                        ���h�g�J��60��(�w�X��-�w���O) �Ρ�30��(�w�X��-�����O)�A�L��ɶ�
                        ����P�ɼg�J(=�t�ήɶ�)�C    
                */
                if (tmp_fout_print[0]=='0')
                { 
                    /* �D�e�~ */
                    
                    if (fNonOutCard[0]=='Y') /* �D�~��d�A���gñ���(���׫O�����O����) */
                    { 
                        v_fstatus = 10;                           /* 10: ������, ���g�J��ñ��� �� */
                        
                        $Update ply_relation 
                            Set dpolicy = null, fprint = '0'
                          Where ipolicy = $v_ipolicy;
                         
                        rsetnull(CDTIMETYPE, (char *) &dt_dprint);	
                    }
                    else
                    {
                        if ((strcmp(ftype_pol,"SP")==0) && (strcmp(ftype_sp,"20")==0))
                        {
                            /* �����O */ 
                            if (tmp_fcomp_daychk[0]=='N')                 /* (�ͮĤ�-�t�Τ�) > (25���10��) */
                            {
                                v_fstatus = 10;                           /* 10: ������, ���g�J��ñ��� �� */
                                
                                $Update ply_relation 
                                    Set dpolicy = null, fprint = '0'
                                  Where ipolicy = $v_ipolicy;
                                 
                                rsetnull(CDTIMETYPE, (char *) &dt_dprint);
                            }
                        }
                    }
                }
                                            
            }
            else
            {
                rsetnull(CDTIMETYPE, (char *) &dt_dprint);                  
            }
           
            $insert into cm_pre_receive
                     (iins_cat, ipre_rcv, iins_kind, ipre_end, ftype,
                      iassured, nassured, iapplicant, napplicant, itag,
                      iengine, deffect, paydate, mprem, isub,
                      iofficer, ileader, iquota, icomm_obj, iroute,
                      fcommit, ientry, dentry, isys, igroup,
                      fstatus, iupdate, dupdate, icard, ftype_pol,iins_kind_ply,ftype_sp, dbegin, dend,
                      ipolicy1,ipolicy2,dprint,ipre_rcv_ori,fsend_msg,mobile_phone)
                  values
                     ('C', $estimatei, '1', ' ', 'P',
                      $iassured, $nassured, $iapplicant, $napplicant, $itag,
                      $iengine, $ply1_begin, $sPaydate, $mpremium1, $localdb,
                      $iofficer1, $sIleader1, $sIquota1, $icomm_obj1, $iroute,
                      $ibig_comp, $ientry, current, '1', ' ',
                      $v_fstatus, 'CAR3011', current, $icard1, $ftype_pol,'C1',$ftype_sp, $ply1_begin, $ply1_end,
                      $v_ipolicy1,$v_ipolicy2,$dt_dprint,$sIpre_rcv_ori,$fsend_msg,$mobile_phone);   
                                      
            printf("-- trace �j�� sqlca.sqlerrd[2][%d]\n ",sqlca.sqlerrd[2]);   
            if (sqlca.sqlerrd[2]==0) return M_CA_NESTIMATE;

        }
        
        /* ���N�I */
        /* 104.01.23 ,�ӫO"��j��"�ɡA�p�G�����p���N�d�� => ply2f==TRUE  */
        if ((iins_kind[0]=='2') || (iins_kind[0]=='3'))
        {
             
            strcpy(sPaydate," ");   strcpy(ftype_pol, " ");  strcpy(ftype_sp," "); 
            code = get_pre_type_pol(tmp_EstPlyEdr, fEstPlyEdr, "2", sPaydate, ftype_pol, ftype_sp, sMsg);
            if (code != M_CM_OK) return code;
              
            if (fchk98[0] == 'Y') /*1130814005_C01_���OSP20�B�����Oñ�b�榬�^�ɡAcar301���ˬd�����v�~�i�H�X��*/
            {
            	if (strncmp(iroute,"C",1) != 0) /*�ư�C*�q��*/
            	{
                    if ((strcmp(ftype_pol,"SP")==0) && (strcmp(ftype_sp,"20")==0))
                    {
                        /*�令PA*/
                        strcpy(ftype_pol, " ");  
                        strcpy(ftype_sp,"PA");
                    }            		
            	}

            }  
              
              
            printf("-- trace ���N estimatei[%s]\n ",estimatei);
            printf("-- trace sPaydate[%s]\n ",sPaydate);
            printf("-- trace ftype_pol[%s]\n ",ftype_pol);
            printf("-- trace ftype_sp[%s]\n ",ftype_sp);
             
            if ((strlen(trim(v_ipolicy))>0)&&(tmp_fout_print[0] != '0')) 
            {   
            	/* �e�~�C�L => �w�L��*/ 
                /* ���L��� dt_dprint */
                /* 1061012002-SC3 ISID+rba�j���I�G�����X��@�~���L��� ���N�I ���ܦL��@�~���L���*/
                rsetnull(CDTIMETYPE, (char *) &dt_dprint); 
            }
            else
            {
                rsetnull(CDTIMETYPE, (char *) &dt_dprint); 
            }   
  
            $insert into cm_pre_receive
              (iins_cat, ipre_rcv, iins_kind, ipre_end, ftype,
               iassured, nassured, iapplicant, napplicant, itag,
               iengine, deffect, paydate, mprem, isub,
               iofficer, ileader, iquota, icomm_obj, iroute,
               fcommit, ientry, dentry, isys, igroup,
               fstatus, iupdate, dupdate, icard, ftype_pol,iins_kind_ply,ftype_sp, dbegin, dend,
               ipolicy1,ipolicy2,dprint,ipre_rcv_ori,fsend_msg,mobile_phone)
            values
              ('C', $estimatei, '2', ' ', 'P',
               $iassured, $nassured, $iapplicant, $napplicant, $itag,
               $iengine, $ply2_begin, $sPaydate, $mpremium2, $localdb,
               $iofficer2, $sIleader2, $sIquota2, $icomm_obj2, $iroute,
                 $ibig_comp, $ientry, current, '1', ' ',
                 $v_fstatus, 'CAR3011', current, $icard2, $ftype_pol,'C2',$ftype_sp, $ply2_begin, $ply2_end,
                 $v_ipolicy1,$v_ipolicy2,$dt_dprint,$sIpre_rcv_ori,$fsend_msg,$mobile_phone); 
                                      
            printf("-- trace ���N sqlca.sqlerrd[2][%d]\n ",sqlca.sqlerrd[2]);
            if (sqlca.sqlerrd[2]==0) return M_CA_NESTIMATE; 

        }
    }
    return SUCCESS;

ie_err:
    code=SQLCODE;
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    sprintf_s(v_errMsg,sizeof v_errMsg,"Insert_Cm_pre_receive()���~:SQLCODE=[%d]sqlca.sqlerrm=[%s],sqlca.sqlerrd[1]=[%d]", SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]); 
    return code;
}

/*1031111001_C1 ���O�X������{���վ� ( _CA_VERSION �w�q�b var_length.h )*/
/* 103.03 �e�~�C�L */
/* ���o�O�渹�ɦ^���@�γ�������cm_pre_receive add by sylvia 102.03.21  */
static int Update_Cm_pre_receive(iestimate, ipolicyx, iinskind,f_out_print,abn_type,ipre_rcv_ori)
$char *iestimate,*ipolicyx, *iinskind,*f_out_print,*abn_type,*ipre_rcv_ori;
{
    $char sIestimate[21], sIpolicy1[21], sIpolicy2[21], ftype_pol[3],siins_kind[2];
    $int iFstatus,iFstatus_ori, iins_kind,iCount,icount_BD;
    $double dblMprem, dblMnt, iest_prem;
    $long code;	
    $char sItrans[21], sBarcode[2],sf_out_print[2],sAbn_type[2],fInsert;
    $char sPaydate[11],ftype_sp[3],sDply_begin[11],sDply_end[11],sMsg[512],tmp_nequipment[31],tmp_ilast_ply[21];
    $datetime year to second theCurrent;
    $datetime year to second dt_dprint;
    $char tmp_fcomp_daychk[2]= " ",fNonOutCard[2]= " ",sIpre_rcv_ori[21];
    $char fsend_msg[2], fassured[2],icar_type[3],irelative_ply[21],tmp_Ipolicy1[21];
    char  fIns58;
    $char fchk98[2] = " ";
    
    /* 1060609 */
    $double mins_premium,mpure_prem;
    
    strcpy(sIestimate  , trim(iestimate));
    strcpy(ipolicyx    , trim(ipolicyx));
    strcpy(sf_out_print, trim(f_out_print));
    strcpy(siins_kind  , trim(iinskind));
    strcpy(sAbn_type   , trim(abn_type));
    strcpy(sIpre_rcv_ori   , ipre_rcv_ori); /* ���itrim�A�]���i�ର�ť�" " */
    strcpy(fsend_msg   , "N");  
    fIns58 = 'N';
    fchk98[0] = 'N';  /*�O�_���O98:ñ�b�榬�^ (1130814005_C01_���OSP20�B�����Oñ�b�榬�^�ɡAcar301���ˬd�����v�~�i�H�X��) */
    fchk98[1] = '\0'; 
        
    iins_kind = atoi(iinskind);
    printf("estimatei=[%s]ipolicyx=[%s]\n",sIestimate,ipolicyx);
    printf("iinskind=[%s]sf_out_print=[%s],abn_type=[%s]\n",iinskind,sf_out_print,abn_type);

    /* 1051214004_C2_�X�j²�T�q����H (�s�O) */	 
    if ( strncmp( ipolicyx+(6-1),"VW",2)==0 ) fIns58 = 'Y';  
    
    if ( (strlen(trim(mobil_phone))==10) && (strncmp(mobil_phone,"09", 2)==0) )
    {
        if ( (assuredf[0]=='1') && (strcmp(iroute,"KA")==0) && (fIns58 =='N'))
        {
            if ( strncmp(car_typei,"01",2)!=0 && strncmp(car_typei,"02",2)!=0 && strncmp(car_typei,"32",2)!=0 && strncmp(car_typei,"34",2)!=0 &&
                 strncmp(car_typei,"35",2)!=0 && strncmp(car_typei,"51",2)!=0 && strncmp(car_typei,"T1",2)!=0 && strncmp(car_typei,"T2",2)!=0 )
            {
                printf("-- trace ply1_period[%d]\n ",ply1_period);
                printf("-- trace ply2_period[%d]\n ",ply2_period);
                
                if (ply2_period > 0)
                {
                    if (ply1_period>0)
                    {
                        strcpy(fsend_msg, "3");   /* �j+�� */
                    }
                    else
                    {
                        strcpy(fsend_msg, "2");	  /* ��� */
                    }
                }
            }  
        }
    }
    else
    {
        strcpy(mobil_phone," ");
    }
             
    $WHENEVER SQLERROR GOTO ie_err;

    strcpy(sIpolicy1," ");
    if (strlen(ipolicyx) > 13)
    {
        strncpy(sIpolicy1, &ipolicyx[0], 13);
        sIpolicy1[13] = '\0';
        strncpy(sIpolicy2, &ipolicyx[13], 4); /* fix sIpolicy1 => sIpolicy2*/
        sIpolicy2[4] = '\0';
    }
    else
    {
        strcpy(sIpolicy1, ipolicyx);
        strcpy(sIpolicy2," ");
    }

    printf("1:sIpolicy1=[%s]sIpolicy2=[%s]\n",sIpolicy1,sIpolicy2);

    $PREPARE preUpd_CmPre FROM 'update cm_pre_receive set \
          iassured   = ? ,nassured   = ? ,iapplicant = ? ,napplicant = ? ,itag   = ? ,iengine = ? ,fstatus   = ? \
         ,iupdate    = ? ,dupdate    = ? ,ipolicy1   = ? ,ipolicy2   = ? ,icard  = ? ,dprint  = ? ,ftype_pol = ? \
         ,iofficer   = ? ,ileader    = ? ,iquota     = ? ,icomm_obj  = ? ,iroute = ? ,paydate = ? ,iins_kind_ply = ? \
         ,ftype_sp   = ? ,dbegin     = ? ,dend       = ? ,deffect    = ? ,ipre_rcv_ori = ? ,fsend_msg = ? ,mobile_phone = ? \
         where current of cur_pre;';

    printf("-- after trace preUpd_CmPre\n ");

    dtcurrent(&theCurrent);
    dtcurrent(&dt_dprint);    
    
    iCount = 0; icount_BD = 0;
    iFstatus_ori = 0;    
    iFstatus = 0 ;dblMprem = 0.0 ; 
              
    $DECLARE cur_pre CURSOR FOR
      Select fstatus, nvl(mprem,0), ipolicy1
        From cm_pre_receive 
       Where iins_cat  = 'C'
         and ipre_rcv  = $sIestimate
         and iins_kind = $siins_kind
         and ipre_end  = ' '
       FOR UPDATE;
    $OPEN cur_pre;
    while (1)
    {
        $FETCH cur_pre INTO $iFstatus, $dblMprem, $tmp_Ipolicy1 ;

        
        if (SQLCODE == SQLNOTFOUND) 
        {
            if (iCount == 0) return M_CA_NESTIMATE;
        }
        iCount ++;

        if (strlen(trim(tmp_Ipolicy1)) > 0) return M_CA_NEEDDEL_PLY;    
        if (iCount > 1) break;   
        
        printf("-- trace cm_pre_receive.mprem[%f],fstatus[%d]\n ", dblMprem, iFstatus);
        
        dblMnt = 0.0 ; 	
        $select nvl(mnt,0) into $dblMnt
           from ao_prercv_pass 
          where iins_cat  = 'C'	        
            and ipre_rcv  = $sIestimate
            and iins_kind = $siins_kind
            and ipre_end  = ' ';
        printf("-- trace ao_prercv_pass.mnt[%f]\n ", dblMnt);
            
        strcpy(sPaydate," ");   strcpy(ftype_pol, " ");  strcpy(ftype_sp," "); 
        code = get_pre_type_pol(ipolicyx, 1, " " , sPaydate, ftype_pol, ftype_sp, sMsg);
        if (code != M_CM_OK) return code;
        printf("-- trace ���N1 estimatei[%s]\n ",estimatei);
        printf("-- trace sPaydate[%s]\n ",sPaydate);
        printf("-- trace ftype_pol[%s]\n ",ftype_pol);
        printf("-- trace ftype_sp[%s]\n ",ftype_sp);       	
        
        strcpy(sBarcode, "N"); 
        iest_prem = 0.0 ;
        strcpy(fNonOutCard, " ");   /* �O�_�� "�D�~��d"(�j���I) */     
          
            
        /* 1040603001_c1 car301��car153�{���վ� */
        /* 104.01.20 �ק���O�K�Q�ө���P�_�覡�]9100�N��104.2��O�J�p�ɨ����^(1031211002_C1) */
        strcpy(sItrans, " "); strcpy(tmp_nequipment, " ");  strcpy(tmp_ilast_ply, " "); strcpy(tmp_fcomp_daychk, "N"); 
        $select (a.mlia_prem+a.mdmg_prem), a.transno, b.nequipment,a.ilast_ply,
                case when (a.fcard_class = '1' and nvl(c.qday_permit_c,0)>0)  then 
                     case when (a.dply_begin-today) <= nvl(c.qday_permit_c,0) then 'Y' else 'N' end 
                else 'Y' end ,
                case when a.fcard_class = '1' then 
                    case when a.icard = a.ipolicy then 'Y' else 'N' end
                else ' ' end,
                case when b.nequipment[8] in ('8','9','A','B','C','D','E','F') then 'Y' else 'N' end
           into $iest_prem, $sItrans, $tmp_nequipment, $tmp_ilast_ply, $tmp_fcomp_daychk, $fNonOutCard, $fchk98
           from ply_relation a, policy b, outer ca_permit c
          where a.ipolicy = b.ipolicy 
            and a.ipolicy = $ipolicyx
            and (c.iclass = '05' AND b.iroute LIKE trim(c.icode)||'%' AND c.ftype_sp='20');
        
        printf("-34779---- fuw_status=[%d] ------ \n",fuw_status);
        printf("-- trace ply2_begin[%ld]\n ",ply2_begin);	
        printf("-- trace ply1_begin[%ld]\n ",ply1_begin);	
        
        iFstatus_ori = iFstatus;
        
        dtcurrent(&theCurrent);
        dtcurrent(&dt_dprint);
        
        if (iFstatus == 90)	 return M_CA_EST_INVALID;
        
        printf("-34779----dblMprem=[%f] iest_prem=[%f] ------ \n",dblMprem, iest_prem);
        
        /* 1060609 �W�u�ݲ��� */
        sprintf_s(stmp,sizeof stmp,"SELECT iins_type,drate_ym,mins_premium,mpure_prem    "
                                   "  FROM ply_ins_type " 
                                   " WHERE ipolicy = ?  ");
                     
        $PREPARE CUR1234 FROM $stmp;
        $DECLARE cur123 CURSOR WITH HOLD for CUR1234;
        $OPEN cur123 using $ipolicyx;
        while (1)
        {
            $FETCH cur123 INTO $ins_type,$drate_ym,$mins_premium,$mpure_prem;
            if (NOT_FOUND) break;
            
            printf("ins_type[%s]\n",ins_type);
            printf("drate_ym[%s]\n",drate_ym);
            printf("mins_premium[%f]\n",mins_premium);
            printf("mpure_prem[%f]\n",mpure_prem);
        }
        $CLOSE cur123;
        $FREE  cur123;
        
        
        if (iest_prem != dblMprem)
        {
            if((strncmp(sIestimate,"BC",2)!=0)&&(strncmp(sIestimate,"JC",2)!=0))
            {       
                printf(" �X��P�պ⤣�� \n");
                return M_CA_DIFFPREM;    /* �X��P�դ��� */
            }
        }
        
        /* �j���I */
        if ((iins_kind == 1) && ((ply1f==TRUE)&& ((fuw_status >= 500) && (fuw_status < 600))))
        { 
            
            /* 1040416007_C1 �S�w�q��ñ��W�h�վ�
                ��	�w��u�O�����O = SP-20�v�̡G
                (1)	�Y[(�ͮĤ�-�t�Τ�) > 25��(�Y�uB2B���סB���q��v�h��10��)]
                    �B[�����O]�A�h�אּ���g�J��ñ��顨;�ӡu�@�γ�����v�����A���h
                    �g�J��10��(������)�B�L��ɶ����礣�g�J�C
                (2)	�Y[(�ͮĤ�-�t�Τ�) �� 25��(�Y�uB2B���סB���q��v�h��10��)] 
                    ��[�w���O]�̡A�h�g�J��ñ���(=�t�Τ�)�� ;�ӡu�@�γ�����v�����A
                    ���h�g�J��60��(�w�X��-�w���O) �Ρ�30��(�w�X��-�����O)�A�L��ɶ�
                    ����P�ɼg�J(=�t�ήɶ�)�C    
            */
            if (fNonOutCard[0]=='Y') /* �D�~��d�A���gñ���(���׫O�����O����) */
            {
                iFstatus = iFstatus_ori;              /* 10: ������, ���g�J��ñ��� �� */
                
                $Update ply_relation 
                    Set dpolicy = null, fprint = '0'
                  Where ipolicy = $ipolicyx;
                 
                rsetnull(CDTIMETYPE, (char *) &dt_dprint);
            }
            else 
            {
                if ((strcmp(ftype_pol,"SP")==0) && (strcmp(ftype_sp,"20")==0))
                {
                    if ((dblMnt >= dblMprem ) && (dblMnt > 0))     /* �w���O */
                    { 
                        iFstatus = 60;
                    }
                    else                                          /* �����O */
                    {
                        if (tmp_fcomp_daychk[0]=='Y')                 /* (�ͮĤ�-�t�Τ�) �� (car153�]�w�Ѽ�) �� ������ */
                        {
                            iFstatus = 30;
                        }
                        else                                          /* (�ͮĤ�-�t�Τ�) > (car153�]�w�Ѽ�) */	
                        {
                            iFstatus = iFstatus_ori;                  /* 10: ������, ���g�J��ñ��� �� */
                            
                            $Update ply_relation 
                                Set dpolicy = null, fprint = '0'
                              Where ipolicy = $ipolicyx;
                             
                            rsetnull(CDTIMETYPE, (char *) &dt_dprint);
                        }
                    }
                }
                else  /* �~��d�A�DSP-20�A �����gñ��� */
                {
                    if ((dblMnt >= dblMprem) && (dblMnt > 0)){
                            
                        iFstatus = 60;          /* �v�X��--�w���O */
                    }
                    else
                    {
                        iFstatus = 30;          /* �v�X��--�����O */
                    }

                }
                
            }
                            
            printf("-- before trace �j�� sqlca.sqlerrd[2][%d]\n ",sqlca.sqlerrd[2]);
            sqlca.sqlerrd[2] = 0 ;
            printf("-- test sqlca.sqlerrd[2][%d]\n ",sqlca.sqlerrd[2]);
            $EXECUTE preUpd_CmPre USING 
                     $assuredi, $assuredn,  $iapplicant, $napplicant, $tagnum, $engine    , $iFstatus,
                     'CAR3011',  $theCurrent,$sIpolicy1 , $sIpolicy2 , $card1 , $dt_dprint, $ftype_pol,
                     $officer,  $sIleader,  $sIquota   , $icomm_obj , $iroute, $sPaydate, 'C1' ,
                     $ftype_sp, $ply1_begin,$ply1_end  , $ply1_begin, $sIpre_rcv_ori, $fsend_msg, $mobil_phone;
                       
            printf("-- after trace �j�� sqlca.sqlerrd[2][%d]\n ",sqlca.sqlerrd[2]);
            if (sqlca.sqlerrd[2]==0) return M_CA_NESTIMATE;

        }
        
        /* ���N�I */
        printf("-34852---- fuw_status=[%d] ------ \n",fuw_status);
        if ((iins_kind == 2) && ((ply2f==TRUE) && ((fuw_status >= 500) && (fuw_status < 600))))
        {

            /* �e�~�C�L(�������Wñ���) */
            /* 1061012002-SC3 ISID+rba�j���I�G�����X��@�~���L��� ���N�I ���ܦL��@�~���L���*/
            
            rsetnull(CDTIMETYPE, (char *) &dt_dprint);
            iFstatus = iFstatus_ori;	
            
            printf("-- before trace ���N sqlca.sqlerrd[2][%d]\n ",sqlca.sqlerrd[2]);
            sqlca.sqlerrd[2] = 0 ;
            printf("-- test sqlca.sqlerrd[2][%d]\n ",sqlca.sqlerrd[2]);	
              
	    if (fchk98[0] == 'Y') /*1130814005_C01_���OSP20�B�����Oñ�b�榬�^�ɡAcar301���ˬd�����v�~�i�H�X��*/
	    {
	    	if (strncmp(iroute,"C",1) != 0) /*�ư�C*�q��*/
	    	{
	            if ((strcmp(ftype_pol,"SP")==0) && (strcmp(ftype_sp,"20")==0))
	            {
                        /*�令PA*/
                        strcpy(ftype_pol, " ");
                        strcpy(ftype_sp,"PA");
	            }	    		
	    	}
	    	else
	    	{
	            if ((strcmp(ftype_pol,"SP")==0) && (strcmp(ftype_sp,"20")==0))
	            {
                        /*����SP/20*/
                        strcpy(ftype_pol, "SP");
                        strcpy(ftype_sp,"20");
	            }	
	    	}

	    }
	    else if (fchk98[0] == 'N')
	    {
	        if ((strcmp(ftype_pol,"SP")==0) && (strcmp(ftype_sp,"20")==0))
	        {
                    /*��^SP/20*/
                    strcpy(ftype_pol, "SP");
                    strcpy(ftype_sp,"20");
	        }	
	    	
	    }

                            
            /* �D�e�~�C�L */
            $EXECUTE preUpd_CmPre USING 
                     $assuredi, $assuredn,  $iapplicant, $napplicant, $tagnum, $engine   , $iFstatus,
                     'CAR3011',  $theCurrent,$sIpolicy1 , $sIpolicy2 , $card2 , $dt_dprint, $ftype_pol,
                     $officer,  $sIleader,  $sIquota   , $icomm_obj , $iroute, $sPaydate, 'C2' ,
                     $ftype_sp, $ply2_begin,$ply2_end  , $ply2_begin, $sIpre_rcv_ori, $fsend_msg, $mobil_phone;	                     	

            printf("-- trace ���N sqlca.sqlerrd[2][%d]\n ",sqlca.sqlerrd[2]);
            if (sqlca.sqlerrd[2]==0) return M_CA_NESTIMATE;

        }
    }
    $CLOSE cur_pre;
    $FREE cur_pre;
    
    return SUCCESS;

ie_err:
    code=SQLCODE;
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    sprintf_s(v_errMsg,sizeof v_errMsg,"Update_Cm_pre_receive()���~:SQLCODE=[%d]sqlca.sqlerrm=[%s],sqlca.sqlerrd[1]=[%d]", SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);        
    return code;
}

static int DiffMonth(d1,d2)    /* input data should be date format */
long d1, d2;
{
    short mdy1[3], mdy2[3];
    int datediff=0;

    rjulmdy(d1,mdy1);
    rjulmdy(d2,mdy2);
    datediff=(mdy1[2]*12+mdy1[0])-(mdy2[2]*12+mdy2[0]);
    if (datediff<0) datediff=0;
        return datediff;
}

static int CheckAbnCol()
{

    printf("=====> CheckAbnCol ABMSG=[%s]\n",ABMSG );

    if (ABMSG[0]!='\0') return TRUE;
    return FALSE;
}

static InsAbnID(id)
int id;
{
    int i;
    for (i=0; i<abn_col_idx; i++)
    {
        if (abn_col_id[i]==id) return;
    }
    abn_col_id[abn_col_idx]=id;
    abn_col_idx++;
}

int IsFcomp24(str)
char *str;
{
    while (*str)
    {
        if (*str == '2')
        {
            str++;
            if (*str == '4')
            {
                return TRUE;
            }
            else
            {
                str--;
            }
        }
        str++;
    }
    return FALSE;
}
/* 2017/12/4 float �� double �~���e�O���p�⪺�p�ƺ�T�פ@�P*/
static double MyPower(f1, i1)
double f1;
int i1;
{
    int i;
    double ff=1.0;

    for (i=0; i<i1; i++)
    {
        ff=ff*f1;
    }
    return ff;
}

long car3011_unload_data()
{
    $char sfilename[41];
    $char stitle[1024];
    $char sErrmsg[200];
    $char stmt[1024];
    $char msgbuf[128];

    $WHENEVER SQLERROR GOTO errexit;


    strcpy(sfilename,"�X���Ʃ��Ӫ�");
    strcpy(stitle,"�����渹\t��O�渹\t�Q�O�I�H�W��\t����\t�g��N��\t�g��W��\t�޲z�H�N��\t�޲z�H�W��\t�~�Z���N��\t�~�Z���W��\t�e�~�C�L(Y/N)\t�q�l�O��(Y/N)\t�j��O�渹\t�j��d��\t�j��_�O��\t���N�O�渹\t���N�d��\t���N�_�O��\t�ˮ֩δ����T��");
    strcpy(stmt," select iestimate,ilast_ply,nassured,itag,iofficer,nofficer,ileader,nleader,iquota,nquota,fout,feply,ipolicy1,icard1,dply_begin1,ipolicy2,icard2,dply_begin2,sMsg from car3011_temp order by iestimate ");


    rc = unload_file(outputf1," ",sfilename,stitle,stmt);
    if (rc != SUCCESS) 
    {
        sprintf_s(msgbuf,sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

  return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(1);
}

static InitData()
{

    strcpy( deffect, " ");
    strcpy( dsign,  " ");
    strcpy(idm_number, " ");	/* DM�s�� add by sylvia 102.07.10 (1020503002_C1) */

    
    strcpy( fcalc, "");
    strcpy( chk_errmsg, " ");
    strcpy( fcheck, "Y");
    fcomp_class_err[0] = '\0';
    mcommission21=0;
    strcpy( haveF, "N");
    strcpy( iassuredIsEqual, "Y");
    strcpy( provision, " ");
    pextra_charge = 0;
    gextra_charge = 0;
    strcpy( iextra_charge, "");
    strcpy( comp_fassured, "");
    memset( iext_policy,0,sizeof( iext_policy));
    memset( officer2,0,sizeof( officer2));
    strcpy( ibound, "");

    strcpy( ileader, "");
    /* barcode��ӫO�զX�N�� */
    strcpy( qcont, "0"); /*0:��barcode���¨�ΫDbarcode�� */
    fuw_status = 0;
    memset( sMsg2,0,sizeof( sMsg2));
    cover_102_tmp = 0;
    cover_102 = 0;
    thousand_cover_102 = 0;
    
    /* �������T�Y�Ƥ��T�� add by sylvia 102.11.15 */
    pdmg_acc2 = pdmg_acc3 = pdmg_acc_main = 0.0;
    qdmg_acc_sum2 = qdmg_acc_sum3 = qdmg_acc_sum_main = 0;
    memset( iquery_num_damage2,0,sizeof( iquery_num_damage2));
    memset( iquery_num_damage3,0,sizeof( iquery_num_damage3));
    memset( iquery_num_damage_main,0,sizeof( iquery_num_damage_main));
    memset( dcomp_lastdend,0,sizeof( dcomp_lastdend));

    /* 1051214006_C1 �]���D�޾������ܤ����X�W���l�I�U�[�ΰӫ~�s�W_�����ܧ�O�v�ץ� */
    /* �s�W�������l�Y�� */
    punknown_acc = punknown_acc2 = punknown_acc_main = 0.0;
    qunknown_acc_sum = qunknown_acc_sum2 = qunknown_acc_sum_main = 0;

    strcpy(iquery_num_unknown, " ");
    strcpy(iquery_num_unknown2, " ");
    strcpy(iquery_num_unknown_main, " ");

    /* �s�r�[�O���� */
    qdrunk_driving = 0;
    Gdrunk_prem = 0;
    Gdrunk_pure_prem = 0.0;
    
    /* ���j�H�W�[�O���� */
    qviolate = 0;
    mviolate_prem = 0;
    mviolate_pure_prem = 0.0;

    /*�e�~�C�L*/  
    strcpy(fout_print,"0"); 
    strcpy(fmail_type,"0");
      
    strcpy(icomp_cartype_last, " "); /* �j��e������ */
    strcpy(isign, " ");
    strcpy(ibound_x, " ");
    strcpy(isurvey_x, " ");    
    
    strcpy(npost_recipient, " ");    /* 1040717001_C1_�e�~��s�W�O��t�H������ */
    strcpy(apost_zip, " ");
    strcpy(apost_address, " ");    
    
    strcpy(iins_kit, " ");           /* 1050105002_C1 �T���~���ը�����X�O�I */
    mcover_limit = 0;   

    strcpy(iassured_cntry, " ");     /* �Q�O�I�H��O���O */
    strcpy(iapplicant_cntry, " ");   /* �n�O�H��O���O */
    
    strcpy(nassured_cntry, " ");     /* �Q�O�I�H���y�O */
    strcpy(napplicant_cntry, " ");   /* �n�O�H���y�O */

    strcpy(foccup, " ");             /* �Q�O�I�H¾/��~�O */
    strcpy(applicant_foccup, " ");   /* �n�O�H¾/��~�O */    
    strcpy(noccup, " ");             /* �Q�O�I�H¾/��~�N�� */
    strcpy(applicant_noccup, " ");   /* �n�O�H¾/��~�N�� */    

    strcpy(funknown_dmg, " ");       /* �������l�O���覡�O */
    
    strcpy(fequipment1, " ");	     /* �t��-���T���O */       
    strcpy(fequipment2, " ");        /* �t��-���c���O */       
    strcpy(fequipment3, " ");        /* �t��-�N����յ��O */   
    strcpy(fequipment4, " ");        /* �t��-���ءB������O */ 
    strcpy(fequipment5, " ");        /* �t��-�@���t�ε��O */   
    strcpy(fequipment6, " ");        /* �t��-�q�ʨ��q�����O */ 
    strcpy(fequipment9, " ");        /* �t��-��L */           
    strcpy(nequipment9, " ");        /* �t��-��L���� */
      
    strcpy(fcharge_type, " ");       /* ���O�覡 */  
    
    strcpy(ipre_rcv_ori, " ");       /* ���p�渹 */
    
    strcpy(fNewCompBusi, "1");       /* 1050812001_C2 �j���I�����~���u�f (�s����G1 ;�±���G0)*/
    
    strcpy(ftrans_trade, "0");       /* �y���T�Y�ɶǿ��z���O (1:�O  ;0:�_ ) */

    strcpy(feply, "0");              /* �q�l�O����O (1:�O  ;0:�_  ; 2:�ȱj���I�A��(���ܭn�H�o�j���I��O����) */
    strcpy(feterms, "0");            /* 1100419003-SC1-���I�O�����QR Code�q�l�� */
    strcpy(aemail_eply, " ");        /* �q�l�O��H�e��email */
    strcpy(tmobile_eply, " ");        /* �q�l�O��H�e 1080417001-SC1-���ά�-�s�W�q�l�O��H²�T�覡�o�e*/
    strcpy(sIreg_no," ");			  /* 1080408005-SC1-��ã��-�j���һ{�ҷs�W�q����Ƥεn���Ҹ� */
    strcpy(sNquota, " ");			 /* �~�Z���W�� */

    strcpy(tmobile_appl, " ");       /* �n�O�H������X */
    strcpy(aemail_appl, " ");        /* �n�O�Hemail    */  
    strcpy(fecard, "0");             /* �j��q�l����   */
    strcpy(sDnotifyornot," ");       /*1090831006-SC1-���ʱo-�{�ҥ��x�j��q�l���ҥ���g�����mail�ˮ�*/
    ins_premium_03 = 0;
    bef_ins_premium_03 = 0;
    mpure_prem_n_03 = 0;

    /* Sets buffers to a specified character */

    memset(estimatei,0,sizeof(estimatei));
    memset(irelative_ply,0,sizeof(irelative_ply));
    memset(last_ply,0,sizeof(last_ply));
    memset(policy1,0,sizeof(policy1));
    memset(policy2,0,sizeof(policy2));
    memset(tagnum,0,sizeof(tagnum));
    memset(relative_card,0,sizeof(relative_card));
    memset(card2,0,sizeof(card2));
    memset(card1,0,sizeof(card1));
    memset(xxcard,0,sizeof(xxcard));
    memset(last_card,0,sizeof(last_card));
    memset(abn_type,0,sizeof(abn_type));
    memset(assuredi,0,sizeof(assuredi));
    memset(assuredi_ext,0,sizeof(assuredi_ext));
    memset(assuredf,0,sizeof(assuredf));
    memset(cutf,0,sizeof(cutf));
    memset(assuredn,0,sizeof(assuredn));
    memset(user,0,sizeof(user));
    memset(benefi,0,sizeof(benefi));
    memset(benefn,0,sizeof(benefn));
    memset(assureda,0,sizeof(assureda));
    memset(assureda_zip, 0, sizeof(assureda_zip));
    memset(paymenta,0,sizeof(paymenta));
    memset(paymenta_zip, 0, sizeof(paymenta_zip));
    memset(tel,0,sizeof(tel));
    memset(tel_night,0,sizeof(tel_night));
    memset(mobil_phone,0,sizeof(mobil_phone));
    memset(iemail,0,sizeof(iemail));
    memset(ply_area,0,sizeof(ply_area));
    memset(passf,0,sizeof(passf));
    memset(pro_year,0,sizeof(pro_year));
    memset(brandi,0,sizeof(brandi));
    memset(brandn,0,sizeof(brandn));
    memset(car_typei2,0,sizeof(car_typei2));
    memset(car_typei1,0,sizeof(car_typei1));
    memset(car_typen2,0,sizeof(car_typen2));
    memset(car_typen1,0,sizeof(car_typen1));
    memset(engine,0,sizeof(engine));
    memset(body,0,sizeof(body));
    memset(cal_way,0,sizeof(cal_way));
    memset(license,0,sizeof(license));
    memset(sex,0,sizeof(sex));
    memset(marriage,0,sizeof(marriage));
    memset(icar_flag1,0,sizeof(icar_flag1));
    memset(icar_flag2,0,sizeof(icar_flag2));
    memset(officer2,0,sizeof(officer2));
    memset(officer1,0,sizeof(officer1));
    memset(broker2,0,sizeof(broker2));
    memset(broker1,0,sizeof(broker1));
    memset(area,0,sizeof(area));
    memset(sIcorps,0,sizeof(sIcorps));
    memset(resource,0,sizeof(resource));
    memset(big_branch,0,sizeof(big_branch));
    memset(big_office,0,sizeof(big_office));
    memset(big_sales,0,sizeof(big_sales));
    memset(iinstall,0,sizeof(iinstall));
    memset(iquery_num,0,sizeof(iquery_num));
    memset(iquery_num_c,0,sizeof(iquery_num_c));
    memset(equipment,0,sizeof(equipment));
    memset(sCompClassNote17,0,sizeof(sCompClassNote17));
    memset(sSynctranNote17,0,sizeof(sSynctranNote17));
    memset(sTransNo,0,sizeof(sTransNo));
    memset(ins_type,0,sizeof(ins_type));
    memset(facf,0,sizeof(facf));
    memset(treaty,0,sizeof(treaty));
    memset(passi,0,sizeof(passi));
    memset(ibig_comp,0,sizeof(ibig_comp));
    memset(fpt,0,sizeof(fpt));
    memset(ABMSG,0,sizeof(ABMSG));
    memset(ipaid_base,0,sizeof(ipaid_base));
    memset(icheck_commi,0,sizeof(icheck_commi));
    memset(icheck_agent,0,sizeof(icheck_agent));
    memset(icheck_disc,0,sizeof(icheck_disc));
    memset(itype_disc,0,sizeof(itype_disc));
    memset(icorps_1,0,sizeof(icorps_1));
    memset(icorps_2,0,sizeof(icorps_2));
    memset(comp_class,0,sizeof(comp_class));
    memset(comp_class_last,0,sizeof(comp_class_last));
    memset(comp_rym,0,sizeof(comp_rym));
    memset(sIquota1, 0, sizeof(sIquota1));
    memset(sIquota2, 0, sizeof(sIquota2));
    memset(sIleader1, 0, sizeof(sIleader1));
    memset(sIleader2, 0, sizeof(sIleader2));
    memset(ibig_comp1,0,sizeof(ibig_comp1));
    memset(ibig_comp2,0,sizeof(ibig_comp2));
    memset(icard_1,0,sizeof(icard_1));
    memset(sBranchCompany,0,sizeof(sBranchCompany));
    memset(fdiscount,0,sizeof(fdiscount));
    memset(car_typei,0,sizeof(car_typei));
    memset(car_typei_1,0,sizeof(car_typei_1));
    memset(car_typen,0,sizeof(car_typen));
    memset(icar_type,0,sizeof(icar_type));
    memset(icar_type_1,0,sizeof(icar_type_1));
    memset(cartype,0,sizeof(cartype));
    memset(officer,0,sizeof(officer));
    memset(broker,0,sizeof(broker));
    memset(officer_1,0,sizeof(officer_1));
    memset(broker_1,0,sizeof(broker_1));
    memset(drate_ym,0,sizeof(drate_ym));
    memset(fcar_class1,0,sizeof(fcar_class1));
    memset(fcar_class2,0,sizeof(fcar_class2));
    memset(imark,0,sizeof(imark));
    memset(fhuman,0,sizeof(fhuman));
    memset(ibig_est_ply,0,sizeof(ibig_est_ply));
    memset(fbig_ply,0,sizeof(fbig_ply));
    memset(lia_class,0,sizeof(lia_class));

    memset(ply_num1,0,sizeof(ply_num1));
    memset(ply_num2,0,sizeof(ply_num2));
    memset(itmp_policy,0,sizeof(itmp_policy));

    /* �q���ĤG���q */
    memset(irate_type,0,sizeof(irate_type));
    memset(irate_type_1,0,sizeof(irate_type_1));
    memset(irate_type1,0,sizeof(irate_type1));
    memset(irate_type2,0,sizeof(irate_type2));
    memset(bzfrom,0,sizeof(bzfrom));
    memset(bzfrom_1,0,sizeof(bzfrom_1));
    memset(bzfrom1,0,sizeof(bzfrom1));
    memset(bzfrom2,0,sizeof(bzfrom2));
    memset(iroute_comm,0,sizeof(iroute_comm));
    memset(iroute_comm_1,0,sizeof(iroute_comm_1));
    memset(iroute_comm1,0,sizeof(iroute_comm1));
    memset(iroute_comm2,0,sizeof(iroute_comm2));
    memset(icomm_obj,0,sizeof(icomm_obj));
    memset(icomm_obj_1,0,sizeof(icomm_obj_1));
    memset(icomm_obj1,0,sizeof(icomm_obj1));
    memset(icomm_obj2,0,sizeof(icomm_obj2));
    memset(qprovision,0,sizeof(qprovision));
    memset(iroute_prop_1,0,sizeof(iroute_prop_1));
    memset(iroute_prop1,0,sizeof(iroute_prop1));
    memset(iroute_prop2,0,sizeof(iroute_prop2));
    memset(iroute_1,0,sizeof(iroute_1));
    memset(iroute1,0,sizeof(iroute1));
    memset(iroute2,0,sizeof(iroute2));
    memset(fstart,0,sizeof(fstart));
    memset(fstart_1,0,sizeof(fstart_1));
    memset(fstart1,0,sizeof(fstart1));
    memset(fstart2,0,sizeof(fstart2));
    memset(fauth,0,sizeof(fauth));
    memset(fauth_1,0,sizeof(fauth_1));
    memset(fauth1,0,sizeof(fauth1));
    memset(fauth2,0,sizeof(fauth2));

    pfix_agent = 0;
    broker_pagent = broker_pcommi = broker_pdisc = 0;

    pdmg_factor_1st = pbrg_factor_1st = pdmg_factor_2nd = pbrg_factor_2nd = 0.000;
    bb11 = bb12 = 0.000;
    iSecondYear2=ply3_period=ply2_period=ply1_period=0;
    rows=cylinder=dmg_align=lia_align=0;
    dmg_align_1=lia_align_1=0;

    brg_align=brg_align_1=0;
    qpt=psex_age1=psex_age2=psex_age_damage=plia_acc1=plia_acc2=pdmg_acc=0;

    dmg_factor = 0;
    brg_factor = 0;

    ply2_begin=ply2_end=ply1_begin=ply1_end=0;
    passd=facd=0;
    car_price=0;
    injured_cover=death_cover=damage_cover=deduct=ins_premium=0;
    bef_ins_premium=bef_premium=0;
    bef_ins_premium1=0;
    pure_ins_premium=pure_premium = 0;

    lMins_premium33=0;
    lMcommission33=0;
    lMagent33=0;
    lMdiscount33=0;

    lMins_premium48=0;
    lMcommission48=0;
    lMagent48=0;
    lMdiscount48=0;

    lMins_premium35=0;
    lMcommission35=0;
    lMagent35=0;
    lMdiscount35=0;

    mdmg_prem=mlia_prem=0;
    premium2=0;
    premium2_disc=0;
    premium=0;
    premium1=0;
    qserial=qcoverage=0;
    mdiscount=magent=mcommission=0;
    pdiscount=pagent=pcommission=0;
    mdmg_pure_prem=mlia_pure_prem=0;
    diff_prem=comprem1=0;

    ZA_mbusiness=0;
    mbusiness=0;
    mbus_rule=0;
    minvest=0;
    readyrate=comprate=stablerate=investrate=0;
    interest=capital=research=0;
    mready=mcompensation=mstable=mcapital=0;
    mresearch=madjcom_prem=0;

    rows_33=rows_48=rows_35=0;
    dmg_acc_1st = dmg_acc_2nd = dmg_acc_3rd = 0;
    drnw_print_1=DATENULL;
    ddate_1st=DATENULL;
    ddate_2nd=DATENULL;
    mprem=0;
    trans_prem=0;
    premium1_bef=0;
    readyrate=comprate=stablerate=investrate=0;
    capital=research=0;
    comprem1=mbusiness=diff_prem=0;
    mcapital=mresearch=0;

    qday      = 0;
    mexpense  = 0;
    mexp_disc = 0;

    damage_add_flag = 0;
    thief_add_flag  = 0;

    damage_qday=0;
    thief_qday=0;
    mdamage_exp=0;
    mthief_exp=0;
    mdamage_disc=0;
    mthief_disc=0;
    coverage1_31=coverage2_31=coverage3_32=0;
    sEquip17Flag=0;
    Provision_Z_150=0;
    pcar_price_1 = 1.0;
    flag58=0;
    
    iDmg_acc_sum_5y = 0;  /* 1090803002-SC1-�ӽ�HCC�֫O�ҫ�   ����e���~�߮צ��� */
    iLia_acc_sum_5y = 0;  /* 1090803002-SC1-�ӽ�HCC�֫O�ҫ�   ���d�e���~�߮צ��� */
    iDuty_acc_sum_5y    = 0;  /* 1090803002-SC1-�ӽ�HCC�֫O�ҫ�   �e���~���F�d�p������(����+���d) */
    strcpy(sDfirst_ply1," ");     /* 1090803002-SC1-�ӽ�HCC�֫O�ҫ�    �j���I�̦���O�� */
    strcpy(sDfirst_ply2," ");     /* 1090803002-SC1-�ӽ�HCC�֫O�ҫ�    ���N�I�̦���O�� */
    qacc_sum_5y         = 0;      /* �L�h���~�߮צ��� (1120220002_SC1_�s�֫O�ҫ��ظm) */
    strcpy(fhave_newa_c_2y,"0");  /* �L�h2�~�O�_�b�s�w��O�L�T���I(1120220002_SC1_�s�֫O�ҫ��ظm) */
    lFirst_ply=0;

}

static int UpdateEst(est1)
$char *est1;
{
    int   code;
    $char tmp_plynum1[20],tmp_plynum2[20];

    $WHENEVER SQLERROR GOTO UpdateEst_err;

    printf("UpdateEst---->ply1f[%s],ply2f[%s],ply_num1[%s],ply_num2[%s]\n",ply1f,ply2f,ply_num1,ply_num2);

    /* 104.01.23 ,�ӫO"����N"�ɡA�p�G�����p�j��d�� => ply1f==TRUE (Line:20575) */
    /* �ҥH�[�W iofficer1 ����*/
    if (ply1f==TRUE)
    {
        $UPDATE estimate
            SET ipolicy1=$ply_num1
           WHERE iestimate=$est1 and iofficer1 <> ' ';

        $UPDATE quotation_master
            SET ipolicy=$ply_num1
          WHERE iquote=$est1 and iins_kind_ply = 'C1';

    }

    /* 104.01.23 ,�ӫO"��j��"�ɡA�p�G�����p���N�d�� => ply2f==TRUE (Line:20507) */
    /* �ҥH�[�W iofficer2 ����*/
    if (ply2f==TRUE)
    {
        $UPDATE estimate
            SET ipolicy2=$ply_num2
          WHERE iestimate=$est1 and iofficer2 <> ' ';

        $UPDATE quotation_master
            SET ipolicy=$ply_num2
          WHERE iquote=$est1 and iins_kind_ply = 'C2';

    }

    /* 1050107005_C2 �X�w���z�s���W�h�ק� */
    /* �X�w�s��^�����z�s�� add by sylvia 101.09.24 (1010813001_C1) */

    return SUCCESS;

UpdateEst_err:
    printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    code=SQLCODE;
    sprintf_s(v_errMsg,sizeof v_errMsg,"UpdateEst()���~:SQLCODE=[%d]sqlca.sqlerrm=[%s],sqlca.sqlerrd[1]=[%d]", SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);     
    return code;
}

/* �d��O���ݪ����T�Y�� add by sylvia 102.11.18 */
long GetReNewDMG(Gdrate_ym,Giins_type)
$char Gdrate_ym[5], Giins_type[7];
{
    $int CheckNawDMG;
    $char STM123[1000];
    printf("----- GetReNewDMG start -------------------\n");
    printf("Gdrate_ym=[%s]Giins_type=[%s]\n",Gdrate_ym,Giins_type);
    printf("pdmg_acc_main=[%f]qdmg_acc_sum_main=[%d]iquery_num_damage_main=[%s]\n", pdmg_acc_main,qdmg_acc_sum_main,iquery_num_damage_main);

    CheckNawDMG=0;

    if ((strcmp(Giins_type,"152")==0) || (strcmp(Giins_type,"153")==0))
    {
        punknown_acc = 0;
        qunknown_acc_sum = 0;
        memset( iquery_num_unknown,0,sizeof(iquery_num_unknown));
    }
    else
    {
        pdmg_acc = pdmg_acc2 = pdmg_acc3 = 0;
        qdmg_acc_sum = qdmg_acc_sum2 = qdmg_acc_sum3 = 0;
        memset( iquery_num_damage,0,sizeof(iquery_num_damage));
        memset( iquery_num_damage2,0,sizeof(iquery_num_damage2));
        memset( iquery_num_damage3,0,sizeof(iquery_num_damage3));
    }
    strcpy(Giins_type, trim(Giins_type));

    $WHENEVER SQLERROR GOTO GetReNew_err;
    sprintf_s(STM123,sizeof STM123,"select case when drate >= (select date(detail2) from car_code "
                                   "                            where kind = '22' and detail = '10') "
                                   "       then '1' else '0' end "
                                   "  from ca_rate_date "
                                   " where icode = '%s' "
                                   "   and itable = 'ca_rate'",Gdrate_ym);
                        
    printf("STM123=[%s]\n",STM123);
    
    $select case when drate >= (select date(detail2) from car_code
                                 where kind = '22' and detail = '10')
                 then '1' else '0' end
       into $CheckNawDMG
       from ca_rate_date
      where icode = $Gdrate_ym
        and itable = 'ca_rate';

    printf("---- 38916 --- CheckNawDMG = [%d]Gdrate_ym=[%s]\n",CheckNawDMG,Gdrate_ym);
    if (CheckNawDMG > 0)
    {
        /* 1030725001_C1 �ߦw(118)�B����(120)����[�N�B���O�I*/
        /* �O�v�ͮĤ�>=��Ǥ�,�u���Ӳ����T�Y�Ʀ��� */
        /* 1100909003-SC1-�_�@�Ϯ��S�h���p�{������07+15�}���O181�I�ݨD*/
        if ((strcmp(Giins_type,"05")==0) || (strcmp(Giins_type,"09")==0)|| (strcmp(Giins_type,"120")==0)|| 
            (strcmp(Giins_type,"125")==0)|| (strcmp(Giins_type,"126")==0)|| (strcmp(Giins_type,"198")==0)||
            (strcmp(Giins_type,"181")==0)|| (strcmp(Giins_type,"205")==0)|| (strcmp(Giins_type,"209")==0)
           )
        {   
            /* 1070212002-SC1 0301�O�v�վ�0501�ͮ� 93�O�v+161+162(�ˮ֤��152+153�A�O�O���98)*/
            /* 1090812005-SC1-���ά�-�s�W�s�ӫ~-�T�����B���郞�I���l���O�I198�I*/
            iMaxDrate = atoi(Gdrate_ym) ;
            if(iMaxDrate<93)
            {
                printf("38922---Giins_type=[%s]\n",Giins_type);
                pdmg_acc2 = pdmg_acc_main;
                qdmg_acc_sum2 = qdmg_acc_sum_main;

                strcpy(iquery_num_damage2, iquery_num_damage_main);
                strcpy(iquery_num_damage, "N");
                strcpy(iquery_num_damage3, "N");
                if (funknown_dmg[0]==' ') strcpy(funknown_dmg,"2");
            }
            else
            {
                printf("38941---Giins_type=[%s]\n",Giins_type);
                pdmg_acc = pdmg_acc_main;
                qdmg_acc_sum = qdmg_acc_sum_main;
                strcpy(iquery_num_damage, iquery_num_damage_main);
                strcpy(iquery_num_damage2, "N");
                strcpy(iquery_num_damage3, "N");
                if (funknown_dmg[0]==' ') strcpy(funknown_dmg,"1"); 
            }
        }
        else if ((strcmp(Giins_type,"85")==0) || (strcmp(Giins_type,"105")==0)|| (strcmp(Giins_type,"118")==0))
        {
            printf("38931---Giins_type=[%s]\n",Giins_type);

            if (funknown_dmg[0]=='1')  /* �������l�Y���h���A���H�h���O�� */
            {
                pdmg_acc = pdmg_acc_main;
                qdmg_acc_sum = qdmg_acc_sum_main;
                strcpy(iquery_num_damage2, "N");
                strcpy(iquery_num_damage , iquery_num_damage_main);
                strcpy(iquery_num_damage3, "N");
            }
            else  /* funknown_dmg= '3' �� ' ' */
            {
                pdmg_acc3 = pdmg_acc_main;
                qdmg_acc_sum3 = qdmg_acc_sum_main;
                strcpy(iquery_num_damage3, iquery_num_damage_main);
                strcpy(iquery_num_damage, "N");
                strcpy(iquery_num_damage2, "N");
                if (funknown_dmg[0]==' ') strcpy(funknown_dmg,"3");
            }
        }
        else if ((strcmp(Giins_type,"01")==0) || (strcmp(Giins_type,"08")==0) || (strcmp(Giins_type,"122")==0) || (strcmp(Giins_type,"201")==0))
        {
            /* 01,08�I�� */
            printf("38941---Giins_type=[%s]\n",Giins_type);
            pdmg_acc = pdmg_acc_main;
            qdmg_acc_sum = qdmg_acc_sum_main;
            strcpy(iquery_num_damage, iquery_num_damage_main);
            strcpy(iquery_num_damage2, "N");
            strcpy(iquery_num_damage3, "N");
            if (funknown_dmg[0]==' ') strcpy(funknown_dmg,"1");
        }
        else if ((strcmp(Giins_type,"152")==0) || (strcmp(Giins_type,"153")==0))
        {
            printf("-- trace funknown_dmg[%s]\n ",funknown_dmg);
            printf("-- trace punknown_acc_main[%f]\n ",punknown_acc_main);
            printf("-- trace iquery_num_unknown_main[%s]\n ",iquery_num_unknown_main);

            if (funknown_dmg[0]=='4')  /* �������l�Y���h���A���H�h���O�� */
            {
                punknown_acc = punknown_acc_main;
                qunknown_acc_sum = qunknown_acc_sum_main;
                strcpy(iquery_num_unknown, iquery_num_unknown_main);
                strcpy(iquery_num_unknown2, "N");
            }
            else  /* funknown_dmg= '5'  */
            {
                punknown_acc2 = punknown_acc_main;
                qunknown_acc_sum2 = qunknown_acc_sum_main;
                strcpy(iquery_num_unknown2, iquery_num_unknown_main);
                strcpy(iquery_num_unknown , "N");
                if (funknown_dmg[0]==' ') strcpy(funknown_dmg,"5");
            }
        }
        else if (strcmp(Giins_type,"00")==0)
        {
            printf("38965---Giins_type=[%s]\n",Giins_type);
            pdmg_acc = pdmg_acc_main;
            qdmg_acc_sum = qdmg_acc_sum_main;
            strcpy(iquery_num_damage  , iquery_num_damage_main);
            strcpy(iquery_num_damage2 , "N");
            strcpy(iquery_num_damage3 , "N");
        }
        else if (strcmp(Giins_type,"XX")==0)
        {
            punknown_acc = 0.00;
            qunknown_acc_sum = 0;
            strcpy(iquery_num_unknown , "N");
            strcpy(iquery_num_unknown2, "N");
        }
    }
    else
    {
        /* �O�v�ͮĤ�<��Ǥ�,�T�����T�Y�ƬۦP */
        /* 01,08�I�� */
        printf("38953---Giins_type=[%s]\n",Giins_type);
        pdmg_acc = pdmg_acc_main;
        qdmg_acc_sum = qdmg_acc_sum_main;
        strcpy(iquery_num_damage, iquery_num_damage_main);

        /* 05,09,120�I�� */
        printf("38959---Giins_type=[%s]\n",Giins_type);
        pdmg_acc2 = pdmg_acc_main;
        qdmg_acc_sum2 = qdmg_acc_sum_main;
        strcpy(iquery_num_damage2, iquery_num_damage_main);

        /* 85,105,118�I�� */
        printf("38965---Giins_type=[%s]\n",Giins_type);
        pdmg_acc3 = pdmg_acc_main;
        qdmg_acc_sum3 = qdmg_acc_sum_main;
        strcpy(iquery_num_damage3, iquery_num_damage_main);
        
    }
    printf("38970---Giins_type=[%s]\n",Giins_type);
    printf("pdmg_acc=[%f]qdmg_acc_sum=[%d]iquery_num_damage=[%s]\n", pdmg_acc,qdmg_acc_sum,iquery_num_damage);
    printf("pdmg_acc2=[%f]qdmg_acc_sum2=[%d]iquery_num_damage2=[%s]\n", pdmg_acc2,qdmg_acc_sum2,iquery_num_damage2);
    printf("pdmg_acc3=[%f]qdmg_acc_sum3=[%d]iquery_num_damage3=[%s]\n", pdmg_acc3,qdmg_acc_sum3,iquery_num_damage3);
    printf("----- GetReNewDMG End -------------------\n");

    return M_CM_OK;

    GetReNew_err:
    printf("SQLSTATE_R2[%s]\n", SQLSTATE);
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    sprintf_s(v_errMsg,sizeof v_errMsg,"GetReNewDMG()���~:SQLCODE=[%d]sqlca.sqlerrm=[%s],sqlca.sqlerrd[1]=[%d]", SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);        
    return SQLCODE;
}
long GetPlyDMG(Giins_type)
$char Giins_type[7];
{

    printf("----- GetPlyDMG start -------------------\n");
    printf("Giins_type=[%s]\n",Giins_type);
    printf("pdmg_acc_main=[%f]qdmg_acc_sum_main=[%d]iquery_num_damage_main=[%s]\n", pdmg_acc_main,qdmg_acc_sum_main,iquery_num_damage_main);
    printf("punknown_acc_main=[%f]qunknown_acc_sum_main=[%d]iquery_num_unknown_main=[%s]\n", punknown_acc_main,qunknown_acc_sum_main,iquery_num_unknown_main);
    printf("drate_ym_sql[%s]\n",drate_ym_sql);
    strcpy(Giins_type, trim(Giins_type));

    if ((strcmp(Giins_type,"05")==0) || (strcmp(Giins_type,"09")==0)|| (strcmp(Giins_type,"120")==0)||
        (strcmp(Giins_type,"125")==0)|| (strcmp(Giins_type,"126")==0)|| (strcmp(Giins_type,"198")==0)|| 
        (strcmp(Giins_type,"181")==0)|| (strcmp(Giins_type,"205")==0)|| (strcmp(Giins_type,"209")==0))
    {   
    	/* 1070212002-SC1 0301�O�v�վ�0501�ͮ� 93�O�v+161+162(�ˮ֤��152+153�A�O�O���98)*/
        /* 1090812005-SC1-���ά�-�s�W�s�ӫ~-�T�����B���郞�I���l���O�I198�I*/
        /* 1100909003-SC1-�_�@�Ϯ��S�h���p�{������07+15�}���O181�I�ݨD */
        iMaxDrate = atoi(drate_ym_sql) ;
        if(iMaxDrate<93)
        {
            pdmg_acc2 = pdmg_acc_main;
            qdmg_acc_sum2 = qdmg_acc_sum_main;
            strcpy(iquery_num_damage2, iquery_num_damage_main);
            if (funknown_dmg[0]==' ') strcpy(funknown_dmg,"2");
        }
        else
        {
            pdmg_acc = pdmg_acc_main;
            qdmg_acc_sum = qdmg_acc_sum_main;
            strcpy(iquery_num_damage, iquery_num_damage_main);
            if (funknown_dmg[0]==' ') strcpy(funknown_dmg,"1");            
        }
    }
    else if ((strcmp(Giins_type,"85")==0) || (strcmp(Giins_type,"105")==0)|| (strcmp(Giins_type,"118")==0))
    {
        if (funknown_dmg[0]=='1')  /* �������l�Y���h���A���H�h���O�� */
        {
            pdmg_acc = pdmg_acc_main;
            qdmg_acc_sum = qdmg_acc_sum_main;
            strcpy(iquery_num_damage , iquery_num_damage_main);	
        }
        else  /* funknown_dmg= '3' �� ' ' */
        {
            pdmg_acc3 = pdmg_acc_main;
            qdmg_acc_sum3 = qdmg_acc_sum_main;
            strcpy(iquery_num_damage3, iquery_num_damage_main);
            if (funknown_dmg[0]==' ') strcpy(funknown_dmg,"3");
        }
    }
    else if ((strcmp(Giins_type,"01")==0) || (strcmp(Giins_type,"08")==0) || (strcmp(Giins_type,"122")==0) || (strcmp(Giins_type,"201")==0))
    {
        /* 01,08�I�� */
        pdmg_acc = pdmg_acc_main;
        qdmg_acc_sum = qdmg_acc_sum_main;
        strcpy(iquery_num_damage, iquery_num_damage_main);
        if (funknown_dmg[0]==' ') strcpy(funknown_dmg,"1");
    }
    else if ((strcmp(Giins_type,"152")==0) || (strcmp(Giins_type,"153")==0))
    {
        if (funknown_dmg[0]=='4')   /* �s��:�������l�Y���h���A���H�h���O�� */
        {
            punknown_acc     = punknown_acc_main;
            qunknown_acc_sum = qunknown_acc_sum_main;
            strcpy(iquery_num_unknown , iquery_num_unknown_main);
        }
        else  /* funknown_dmg= '5'  */
        {
            punknown_acc2     = punknown_acc_main;
            qunknown_acc_sum2 = qunknown_acc_sum_main;
            strcpy(iquery_num_unknown2 , iquery_num_unknown_main);
            if (funknown_dmg[0]==' ') strcpy(funknown_dmg,"5");
        }
    }
    else
    {
        strcpy(funknown_dmg," ");
    }

    printf("pdmg_acc=[%f]qdmg_acc_sum=[%d]iquery_num_damage=[%s]\n", pdmg_acc,qdmg_acc_sum,iquery_num_damage);
    printf("pdmg_acc2=[%f]qdmg_acc_sum2=[%d]iquery_num_damage2=[%s]\n", pdmg_acc2,qdmg_acc_sum2,iquery_num_damage2);
    printf("pdmg_acc3=[%f]qdmg_acc_sum3=[%d]iquery_num_damage3=[%s]\n", pdmg_acc3,qdmg_acc_sum3,iquery_num_damage3);
    printf("----- GetPlyDMG End -------------------\n");

    return M_CM_OK;

}

int IsBlankNull(str)
char *str;
{
    while (*str)
    {
        if (*str!=' ') return FALSE;
        str++;
    }
    return TRUE;
}



/* rt_code = FALSE => ���]�w��(�i)�e�~  */
static int ChkOutPrint(iestimate,iroute,iofficer, rt_Kind)
$char *iestimate,*iroute,*iofficer;
$int  *rt_Kind;
{
    $WHENEVER SQLERROR GOTO ie_err;

    $int t_count; 
    int  rt_code;
    $char iunit[4];

    rt_code = TRUE;
    *rt_Kind = 0;
    strncpy(iunit, iestimate, 3);   iunit[3]='\0';

    /* car140(kind = ST)  */
    t_count = 0;
    $select count(*) into $t_count from car_code
      where kind = 'ST' and detail = '1' and trim(detail2) = $iunit
        and (trim(engname) = '' or nvl(engname::date,'12/31/2099'::date) > today);
    printf("-- trace t_count1[%d]\n ",t_count);
    if (t_count>0)
    {
        *rt_Kind = 250;	
    }
    else
    {
        /* car140(kind = SS)  */ 
        t_count = 0;
        $select count(*) into $t_count from car_code
          where kind = 'SS' and $iroute like trim(detail)||'%' and detail2 = $iofficer
            and (trim(engname) = '' or nvl(engname::date,'12/31/2099'::date) > today);
        printf("-- trace t_count1[%d]\n ",t_count);	    
        if (t_count>0)
        {
            *rt_Kind = 100;
        }
        else
        {
            /* car646 �e�~�浧�ި�*/
            $SELECT count(*) into $t_count
               FROM sysdb:ca_out_control 
              WHERE ipre_rcv = $iestimate ;
            printf("-- trace t_count2[%d]\n ",t_count);	    
            if (t_count>0)  
            {
                *rt_Kind = 150;
            }
        }
    }   

    if (*rt_Kind > 0)  rt_code = FALSE; 
    return rt_code;
          
ie_err:
    printf(" ChkOutPrint�]�^ sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    sprintf_s(v_errMsg,sizeof v_errMsg,"ChkOutPrint()���~:SQLCODE=[%d]sqlca.sqlerrm=[%s],sqlca.sqlerrd[1]=[%d]", SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);        
    return SQLCODE;    
}

/* rt_code = FALSE => ���]�w��(�i)�۰ʥX��  */
static int ChkAutoPly(iroute,iofficer, rt_Kind)
$char *iroute,*iofficer;
$int  *rt_Kind;
{
    $WHENEVER SQLERROR GOTO ie_err;

    $int  t_count; 
    int   rt_code;
    $char nofficer[11],v_ileader[11];

    printf("---- into ChkAutoPly() ----\n ");
    strcpy(v_errMsg,"");
    rt_code = TRUE;
    *rt_Kind = 0;
        
    strcpy(v_ileader," "); strcpy(nofficer," ");
    
    $SELECT ileader,nname Into $v_ileader,$nofficer 
       FROM officer WHERE iofficer = $iofficer;
       
    printf("-- trace ileader[%s]\n ",ileader);
                
    /* car140(kind = SK),detail:1 (�޲z�H); 2(�g��N��) ; 3(�ӳq���N��) */
    t_count = 0;
    $select count(*) into $t_count from car_code
      where kind = 'SK' and detail ='1' and detail2 = $v_ileader
        and (trim(engname) = '' or nvl(engname::date,'12/31/2099'::date) > today);
    printf("-- trace t_count3[%d]\n ",t_count);	    
    if (t_count==0)
    {   
        $select count(*) into $t_count from car_code
          where kind = 'SK' and detail ='2' and detail2 = $iofficer
            and (trim(engname) = '' or nvl(engname::date,'12/31/2099'::date) > today);
        if (t_count==0)
        {  
            $select count(*) into $t_count from car_code
              where kind = 'SK' and detail ='3' and detail2 = $iroute
                and (trim(engname) = '' or nvl(engname::date,'12/31/2099'::date) > today);
            if (t_count==0)
            {
                /* �����ި� */
            }
            else
            {
                *rt_Kind = 400;	/* "�ӳq��"�����ި� */
            }
        }
        else
        {
            *rt_Kind = 300;	/* "�g��H"�����ި� */
        }
    }
    else /* "�޲z�H"�����ި� */
    {
        *rt_Kind = 200;	
    }
   
    if (*rt_Kind > 0)  rt_code = FALSE;
    return rt_code;
          
ie_err:
    printf(" ChkOutPrint�]�^ sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    sprintf_s(v_errMsg,sizeof v_errMsg, "ChkAutoPly():SQLCODE(=%d),sqlca.sqlerrd[%s], sqlca.sqlerrd[1][=%d] ",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    return FALSE;    
}

/* [�ˮ�] ���ˮ֮ɶ��I�Ϥ� */

/* 1. ����O�B�������Ʊa�X��Y�i�Ĥ@�ɶ��ˮ֡A�q�`�� ��ƪťաB�榡���ҵ� */
static int DataCheck1()
{
    $WHENEVER SQLERROR GOTO chk_err;

    $int  t_count;
    int   rt_code, rc,fErr;
    char  sMsgChk[201], sTmp[50];
    $char rba_fresult[10],rba_nresult[512],rba_dbirth[11],rba_dbirth_appl[11]; /* 1061012002-SC3-ISID+RBA */
    $char sDply2_begin[11], sFelder_type[2], sErrmsg[128];
    strcpy(v_errMsg , ""); fErr = 0;
    rt_code = M_CM_OK;	 rc = 0;  strcpy(sMsgChk , "");  strcpy(sTmp , "");

    printf("---- into DataCheck1() ----\n ");
        
    /*------------------ [�ˮ�] �����渹�O�_�w���O�渹 �� ----------------------*/

    t_count = 0;
    $SELECT count(*) into $t_count
       FROM cm_pre_receive
      WHERE iins_cat = 'C' 
        AND ipre_rcv = $estimatei 	
        AND ipolicy1 <> ' ';
        
    printf("-- trace SQLCODE[%d]\n " ,SQLCODE);
    printf("-- trace t_count[%d]\n ",t_count);
    if (t_count>0)
    {
        sprintf_s(sMsgChk,sizeof sMsgChk,"�������渹(%s)�w�X��; ",estimatei);
        strcat(v_errMsg , rtrim(sMsgChk));
        fErr++;	    	
    }     
    /*------------------ [�ˮ�] �����渹�O�_�w���O�渹 �� ----------------------*/    	

    /*------------------ [�ˮ�] �Q�O�I�H������X �� ----------------------*/
    printf("-- trace mobil_phone[%s]\n ",mobil_phone);
    strcpy(sTmp , mobil_phone);   strcpy(sTmp , rtrim(sTmp));    
    if (strlen(sTmp) > 0)
    {        
        if (strlen(sTmp)!=10 || strncmp(sTmp,"09",2) != 0 || (!(IsInteger(sTmp))) ) 
        {
            sprintf_s(sMsgChk,sizeof sMsgChk, "�Q�O�I�H�u��ʹq�ܡv(%s)���~,�����O09�}�Y��10�X�Ʀr; ",mobil_phone);
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;
        }
    }
      
    /*------------------ [�ˮ�] �Q�O�I�H������X �� ----------------------*/

    /*------------------ [�ˮ�] �Q�O�I�Hemail �� ---------------------- */
    printf("-- trace iemail[%s]\n ",iemail);
    if (strlen(trim(iemail)) > 0)
    {
        printf("-- trace chk_email\n ");
        rc = chk_email(iemail);
        if (rc==0)
        {
            sprintf_s(sMsgChk,sizeof sMsgChk, "�u�Q�O�I�Hemail(%s) �v�榡���~; ",iemail);
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;
        }
    }
    /*------------------ [�ˮ�] �Q�O�I�Hemail �� ----------------------*/    

    /*------------------ [�ˮ�] �n�O�H������X �� ----------------------*/ /*1061003004_C2_�s�W�n�O�H���+EMAIL���*/

    printf("-- trace tmobile_appl[%s]\n ",tmobile_appl);
    strcpy(sTmp , trim(tmobile_appl));

    if (strlen(sTmp) > 0)
    {
        if (strlen(sTmp)!=10 || strncmp(sTmp,"09",2) != 0 || (!(IsInteger(sTmp))) ) 
        {
            sprintf_s(sMsgChk,sizeof sMsgChk, "�n�O�H�u��ʹq�ܡv(%s)���~,�����O09�}�Y��10�X�Ʀr; ",tmobile_appl);
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;
        }
    }
    else
    {
        
        strcpy(tmobile_appl , " ");
        if (strcmp(assuredi,iapplicant)==0)
        {
            if (strlen(trim(mobil_phone)) > 0) 
            {
                strcpy(tmobile_appl , trim(mobil_phone));
            }   
        }
    }

    /*------------------ [�ˮ�] �n�O�H������X �� ----------------------*/
    
    /*------------------ [�ˮ�] �n�O�Hemail �� ---------------------- */   /*1061003004_C2_�s�W�n�O�H���+EMAIL���*/

    printf("-- trace aemail_appl[%s]\n ",aemail_appl);
    if (strlen(trim(aemail_appl)) > 0)
    {
        printf("-- trace chk_email(aemail_appl)\n ");

        rc = chk_email(aemail_appl);
        if (rc==0)
        {
            sprintf_s(sMsgChk,sizeof sMsgChk, "�u�n�O�Hemail(%s) �v�榡���~; ",aemail_appl);
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;
        }
    }
    else
    {

        strcpy(aemail_appl , " ");
        if (strcmp(assuredi,iapplicant)==0)
        {
            if (strlen(trim(iemail)) > 0) 
            {
                strcpy(aemail_appl , trim(iemail));
            }   
        }
    }  

    /*
       1090317002-SC1--��ã��-�s�W�ˮֳ�j�αj+���@�߭n��J��ʸ��X��EMAIL���@(�t���s�BB2B�BE�O���A�Цb6�멳����)
       �ҡB	�{��2020/5/1�W�u�A�X��ɡA�ˮ֫O�o�q��10���j���I�O��C
       �A�B	�X��ɡA������ˮ֡A�u�ˮֳ�j�B�j+��(���u�ˬd�j���I)
       ���B	�ˬd�n�O�H���or EMAIL��J�䤤���@�F�p������J�h���_��ĵ�ܡi�ӫO�j���I�A�n�O�H����ʸ��X��email�n��J�䤤���@�j
       �B�B	�W�u��A�u���O��ͮ�5-6�몺CR�����椣�ˮ֡A��L�����泣�n�ˮ֡C
       ���B	�妸�X��B�wñ�p�a�X��B�wú��d�߱a�J�X��A���n�̴`�W�z�ˮ֡C
    */
    t_count = 0;
    $SELECT count(*) into $t_count
       FROM cm_pre_receive
      WHERE iins_cat = 'C' 
        AND ipre_rcv = $estimatei 
        AND NOT (ipre_rcv[6,7]='CR' AND dbegin <='06/30/2020')
        AND iins_kind ='1';
    
    if ((t_count>0) && (strncmp(bzfrom1,"10",2)==0))
    {
        if ((strlen(trim(mobil_phone)) == 0) && (strlen(trim(aemail_appl)) == 0) )
        {
            strcpy(sMsgChk,"�ӫO�j���I�A�n�O�H����ʸ��X��email�n��J�䤤���@;");
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;
        }
    }
    
    /*------------------ [�ˮ�] �n�O�Hemail �� ----------------------*/      
    /*------------------ [�ˮ�] �q���a�}�ˮ� �� ----------------------*/  
    printf("assureda[%s] paymenta[%s] \n",assureda,paymenta);
    /*rc = cmc_route_dupaddr(iroute, assureda, assuredf, sMsg);*/
    rc = cmc_route_dupaddr(iroute, assureda, assuredf, tel, tel_night, sMsg);/*1130507006_C01_�q����q�T����ˮ֡A�s�W�ˮֹq��*/
    strcpy(sMsg,trim(sMsg));
    if ( rc != M_CM_OK )
    {
        strcpy(sMsgChk,"cmc_route_dupaddrr()�ˮ֦��~�A�гq����T��");
        strcat(v_errMsg , rtrim(sMsgChk));
        fErr++;
    }
    else if( rc == M_CM_OK && strcmp(sMsg,"") != 0)
    {
        strcat(v_errMsg , sMsg);
        fErr++;
    }
    else
    {
        /*rc = cmc_route_dupaddr(iroute, paymenta, fapplicant, sMsg);*/
        rc = cmc_route_dupaddr(iroute, paymenta, fapplicant, itel_appl, "", sMsg);/*1130507006_C01_�q����q�T����ˮ֡A�s�W�ˮֹq��*/
        strcpy(sMsg,trim(sMsg));
        if ( rc != M_CM_OK )
        {
            strcpy(sMsgChk,"cmc_route_dupaddrr()�ˮ֦��~�A�гq����T��");
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;
        }
        else if( rc == M_CM_OK && strcmp(sMsg,"") != 0)
        {
            strcat(v_errMsg , sMsg);
            fErr++;
        }
    }
    /*------------------ [�ˮ�] �q���a�}�ˮ� �� ----------------------*/ 
    /*------------------ [�ˮ�] �a�}�ˮ� ��-------------1070926001-SC1-��ã��-�s�W�n�Q�O�H�a�}�ˮ� */
    if (((strstr(assureda,"��") == NULL) && (strstr(assureda,"��") == NULL) && (strstr(assureda,"�H�c") == NULL)) ||
        ((strstr(paymenta,"��") == NULL) && (strstr(paymenta,"��") == NULL) && (strstr(paymenta,"�H�c") == NULL)))
    {
        strcat(v_errMsg , rtrim("�Q�O�I�H�έn�O�H�a�}���]�t ""��(��)"" �� ""�H�c"" �A�нT�{�a�}�O�_��J����"));
        fErr++;
    }
    /*------------------ [�ˮ�] �a�}�ˮ� �� ----------------------*/ 
    /*------------------ [�ˮ�] ��O���O �� ----------------------*/
    printf("-- trace iassured_cntry[%s]\n ",iassured_cntry);    
    printf("-- trace nassured_cntry[%s]\n ",nassured_cntry); 
    /* 1101124011_SC1_RBA�ק�@�~ */
    if (iassured_cntry[0]=='2')   strcpy(nassured_cntry,  "����j��");
    if (iassured_cntry[0]=='9')   strcpy(nassured_cntry,  "���إ���");
    if (iapplicant_cntry[0]=='2') strcpy(napplicant_cntry,"����j��");
    if (iapplicant_cntry[0]=='9') strcpy(napplicant_cntry,"���إ���");

    if (strlen(trim(iassured_cntry))==0)
    {
        strcpy(sMsgChk, "�u�Q�O�I�H��O���O�v���i�ť�; ");
        strcat(v_errMsg , rtrim(sMsgChk));
        fErr++;
    }
    else if (iassured_cntry[0]=='1')
    { 
        strcpy(sTmp , trim(nassured_cntry));

        if (strlen(sTmp)==0)
        { 
            strcpy(sMsgChk, "�u�Q�O�I�H��O���O�v�� ��1���A��y���y�O�W�١z���i�ť�; ");
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;
        }
    }

    printf("-- trace iapplicant_cntry[%s]\n ",iapplicant_cntry);    
    printf("-- trace napplicant_cntry[%s]\n ",napplicant_cntry);        
    if (strlen(trim(iapplicant_cntry))==0)
    {
        strcpy(sMsgChk, "�u�n�O�I�H��O���O�v���i�ť�; ");
        strcat(v_errMsg , rtrim(sMsgChk));
        fErr++;
    }
    else if (iapplicant_cntry[0]=='1')
    {
        strcpy(sTmp , trim(napplicant_cntry)); 
        if (strlen(sTmp)==0)
        { 
            strcpy(sMsgChk, "�u�n�O�H��O���O�v�� ��1���A��y���y�O�W�١z���i�ť�; "); 
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;
        }
    }

    /*------------------ [�ˮ�] ��O���O �� ----------------------*/
    
    /*------------------ [�ˮ�] �s�y�� ��-----------------------*/
    /*1120210002_SC1_(�t)�ק�CAR301�X��{�����ˮ֥X�t�~��ݦ����*/
    if (qpro_month == 0)
    {
        strcat(v_errMsg , rtrim("�s�y�뤣�i��0;"));
        fErr++;
    }
    /*------------------ [�ˮ�] �s�y�� �� ----------------------*/ 
    
    

    /*------------------ [�ˮ�] ¾/��~�O�B�N�� �� ----------------------*/

    /*------------------ [�ˮ�] ¾/��~�O�B�N�� �� ----------------------*/


    /*------------------ [�ˮ�] �Ӹ갱�� �� ----------------------*/	  		

    rc = chk_personal_deny(assuredi, sMsg);
    if (rc != M_CM_OK)
    {
        sprintf_s(sMsgChk,sizeof sMsgChk, "%s(ID = %s) ", rtrim(sMsg), assuredi);
        strcat(v_errMsg , rtrim(sMsgChk));
        fErr++;
    }
    /*------------------ [�ˮ�] �Ӹ갱�� �� ----------------------*/

    /*------------------ [�ˮ�] ������ �� ----------------------*/
    /* 1130108009_01_�]2023��ƫ~��|ĳ�~�׷|ĳ�d�ֵ��G�A�W�[�ˮ�*/
    if (strcmp(trim(engine),"") != 0)
    {
        if(strlen(trim(engine)) < 3)
        {
            strcpy(sMsgChk, "�������X���פ��i�p��3�X; "); 
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;
        }
        
        if( !(65 <= (int)engine[0] && (int)engine[0] <= 90)  && /*���O A-Z*/
            !(97 <= (int)engine[0] && (int)engine[0] <= 122) && /*���O a-z*/
            !(48 <= (int)engine[0] && (int)engine[0] <= 57)  && /*���O 0-9*/
            !((int)engine[0] == 42)                             /*���O *  */
          )
        {
            strcpy(sMsgChk, "�������X�Ĥ@�X�ݬ��^��r���μƦr��*��; "); 
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;	
        }
    }
    /*------------------ [�ˮ�] ������ �� ----------------------*/
       
    /*------------------ [�ˮ�] ������ �� ----------------------*/
    /* 1130108009_01_�]2023��ƫ~��|ĳ�~�׷|ĳ�d�ֵ��G�A�W�[�ˮ�*/
    if (strcmp(trim(body),"") != 0)
    {
        if(strlen(trim(body)) < 3)
        {
            strcpy(sMsgChk, "�������X���פ��i�p��3�X; "); 
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;
        }
        
        if( !(65 <= (int)body[0] && (int)body[0] <= 90)  && /*���O A-Z*/
            !(97 <= (int)body[0] && (int)body[0] <= 122) && /*���O a-z*/
            !(48 <= (int)body[0] && (int)body[0] <= 57)  && /*���O 0-9*/
            !((int)body[0] == 42)                           /*���O *  */
          )
        {
            strcpy(sMsgChk, "�������X�Ĥ@�X�ݬ��^��r���μƦr��*��; "); 
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;	
        }
    }
    /*------------------ [�ˮ�] ������ �� ----------------------*/ 
    
    /*------------------ [�ˮ�] �Q�O�H�ʽ�(�u�ˮ֪��פέ^�Ʀr��m) �� ----------------------*/
    if(strcmp(trim(assuredf),"1") == 0) /* 1:�ꤺ�۵M�H */
    {
    	if(strlen(trim(assuredi)) != 10 )
    	{
            strcpy(sMsgChk, "�Q�O�H�ʽ謰[1:�ꤺ�۵M�H],�Q�O�HID��������10�X; "); 
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;	
    	}
    	
    	if((int)assuredi[0] < 65 || (int)assuredi[0] > 90) /*�Ĥ@�X�D A-Z*/
    	{
            strcpy(sMsgChk, "�Q�O�H�ʽ謰[1:�ꤺ�۵M�H],�Q�O�HID�Ĥ@�X�����j�g�^��r��; "); 
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;	
    	}
    	
    	if((int)assuredi[1] != 49 && (int)assuredi[1] != 50) /*�ĤG�X�D 1�B2*/
    	{
            strcpy(sMsgChk, "�Q�O�H�ʽ謰[1:�ꤺ�۵M�H],�Q�O�HID�ĤG�X����1��2; "); 
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;	
    	}
    	
    }
    else if(strcmp(trim(assuredf),"2") == 0) /* 2:�ꤺ�k�H */
    {
    	if(strlen(trim(assuredi)) != 8 )
    	{
            strcpy(sMsgChk, "�Q�O�H�ʽ謰[2:�ꤺ�k�H],�Q�O�HID��������8�X; "); 
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;	
    	}
    	
    	for(int i=0;i<=7;i++)
    	{
    	    if (assuredi[i] < 48 || assuredi[i] > 57)
    	    {
                strcpy(sMsgChk, "�Q�O�H�ʽ謰[2:�ꤺ�k�H],�Q�O�HID�����Ʀr; "); 
                strcat(v_errMsg , rtrim(sMsgChk));
                fErr++;	
    	    }
    	}
    }
    else if(strcmp(trim(assuredf),"3") == 0) /* 3:��~�۵M�H */
    {
    	if(strlen(trim(assuredi)) != 10 )
    	{
            strcpy(sMsgChk, "�Q�O�H�ʽ謰[3:��~�۵M�H],�Q�O�HID��������10�X; "); 
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;	
    	}
    	
    	if((int)assuredi[0] < 65 || (int)assuredi[0] > 90) /*�Ĥ@�X�D A-Z*/
    	{
            strcpy(sMsgChk, "�Q�O�H�ʽ謰[3:��~�۵M�H],�Q�O�HID�Ĥ@�X�����j�g�^��r��; "); 
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;	
    	}
    	
    	if((int)assuredi[1] != 56 && (int)assuredi[1] != 57 &&  /*�ĤG�X�D 8�B9�BA�BB�BC�BD�BE�BF*/
    	   (int)assuredi[1] != 65 && (int)assuredi[1] != 66 &&
    	   (int)assuredi[1] != 67 && (int)assuredi[1] != 68 &&
    	   (int)assuredi[1] != 69 && (int)assuredi[1] != 70 ) 
    	{
            strcpy(sMsgChk, "�Q�O�H�ʽ謰[3:��~�۵M�H],�Q�O�HID�ĤG�X����8�B9�BA�BB�BC�BD�BE�BF; "); 
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;	
    	}	
    }
    /*------------------ [�ˮ�] �Q�O�H�ʽ�(�u�ˮ֪��פέ^�Ʀr��m) �� ----------------------*/
    
    /*------------------ [�ˮ�] �n�O�H�ʽ�(�u�ˮ֪��פέ^�Ʀr��m) �� ----------------------*/
    if(strcmp(trim(fapplicant),"1") == 0) /* 1:�ꤺ�۵M�H */
    {
    	if(strlen(trim(iapplicant)) != 10 )
    	{
            strcpy(sMsgChk, "�n�O�H�ʽ謰[1:�ꤺ�۵M�H],�n�O�HID��������10�X; "); 
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;	
    	}
    	
    	if((int)iapplicant[0] < 65 || (int)iapplicant[0] > 90) /*�Ĥ@�X�D A-Z*/
    	{
            strcpy(sMsgChk, "�n�O�H�ʽ謰[1:�ꤺ�۵M�H],�n�O�HID�Ĥ@�X�����j�g�^��r��; "); 
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;	
    	}
    	
    	if((int)iapplicant[1] != 49 && (int)iapplicant[1] != 50) /*�ĤG�X�D 1�B2*/
    	{
            strcpy(sMsgChk, "�n�O�H�ʽ謰[1:�ꤺ�۵M�H],�n�O�HID�ĤG�X����1��2; "); 
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;	
    	}
    	
    }
    else if(strcmp(trim(fapplicant),"2") == 0) /* 2:�ꤺ�k�H*/
    {
    	if(strlen(trim(iapplicant)) != 8 )
    	{
            strcpy(sMsgChk, "�n�O�H�ʽ謰[2:�ꤺ�k�H],�n�O�HID��������8�X; "); 
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;	
    	}
    	
    	for(int i=0;i<=7;i++)
    	{
    	    if (iapplicant[i] < 48 || iapplicant[i] > 57)
    	    {
                strcpy(sMsgChk, "�n�O�H�ʽ謰[2:�ꤺ�k�H],�n�O�HID�����Ʀr; "); 
                strcat(v_errMsg , rtrim(sMsgChk));
                fErr++;	
    	    }
    	}
    }
    else if(strcmp(trim(fapplicant),"3") == 0) /* 3:��~�۵M�H */
    {
    	if(strlen(trim(iapplicant)) != 10 )
    	{
            strcpy(sMsgChk, "�n�O�H�ʽ謰[3:��~�۵M�H],�n�O�HID��������10�X; "); 
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;	
    	}
    	
    	if((int)iapplicant[0] < 65 || (int)iapplicant[0] > 90) /*�Ĥ@�X�D A-Z*/
    	{
            strcpy(sMsgChk, "�n�O�H�ʽ謰[3:��~�۵M�H],�n�O�HID�Ĥ@�X�����j�g�^��r��; "); 
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;	
    	}
    	
    	if((int)iapplicant[1] != 56 && (int)iapplicant[1] != 57 &&  /*�ĤG�X�D 8�B9�BA�BB�BC�BD�BE�BF*/
    	   (int)iapplicant[1] != 65 && (int)iapplicant[1] != 66 &&
    	   (int)iapplicant[1] != 67 && (int)iapplicant[1] != 68 &&
    	   (int)iapplicant[1] != 69 && (int)iapplicant[1] != 70 ) 
    	{
            strcpy(sMsgChk, "�n�O�H�ʽ謰[3:��~�۵M�H],�n�O�HID�ĤG�X����8�B9�BA�BB�BC�BD�BE�BF; "); 
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;	
    	}	
    }
    /*------------------ [�ˮ�] �n�O�H�ʽ�(�u�ˮ֪��פέ^�Ʀr��m) �� ----------------------*/
    
    
    
      
    /*-------------------------------- [CR�B17N �ӧO�P�_�ˮ�]  ���� --------------------------------------*/
    if (g_frenew_type[0]=='9' || g_frenew_type[0]=='5' || g_frenew_type[0]=='6') /* 17N + �j��q���� + ���X��*/
    {
    
    }
    else  /* CR */
    {
        /*------------------ [�ˮ�] �h�~�O��(�̷s�O����) ���O��ID�P��O�ɤ��O��ID���P �� ----------------------*/
        printf("-- trace ilicense_302[%s]\n ",ilicense_302);    
        printf("-- trace assuredi[%s]\n ",assuredi);
        if( strcmp( assuredi, ilicense_302) != 0 )
        {
            sprintf_s(sMsgChk,sizeof sMsgChk, "��O��Ƥ��Q�O�I�HID( %s )�P�̷s�O���ɤ��Q�O�I�HID( %s )����); ",ilicense_302,assuredi);	
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;
        }
        /*------------------ [�ˮ�] �h�~�O��(�̷s�O����) ���O��ID�P��O�ɤ��O��ID���P �� ----------------------*/    	
       
        /*------------------ [�ˮ�] �u�j���I�v�h�~�O��(�̷s�O��)���ػP�u��O�ɡv���ؤ��@�P �� ----------------------*/     
        if (fcard_class[0]=='1')
        {
            printf("-- trace car_typei[%s]\n ",car_typei);    
            printf("-- trace icar_type_302[%s]\n ",icar_type_302); 	   
            strcpy(car_typei    , trim(car_typei));
            strcpy(icar_type_302, trim(icar_type_302));
            if (strcmp(car_typei, icar_type_302)!=0)
            {
                sprintf_s(sMsgChk,sizeof sMsgChk, "�u�j���I�v�h�~�O��(�̷s�O��)����( %s )�P�u��O�ɡv����( %s )���@�P; ",car_typei,icar_type_302);	
                strcat(v_errMsg , rtrim(sMsgChk));
                fErr++;
            }
        }
        /*------------------ [�ˮ�] �u�j���I�v�h�~�O��(�̷s�O��)���ػP�u��O�ɡv���ؤ��@�P �� ----------------------*/ 
                    
        /*------------------ [�ˮ�] �D�s���A���P���X���i���ť� �� ----------------------*/ 
        printf("-- trace tagnum[%s]\n ",tagnum);     
        strcpy(sTmp    , tagnum); strcpy(sTmp , trim(sTmp));
        if (strncmp(car_typei,"51",2)!=0) /* 1070531010-SC1-��ã��-�]�������۰ʥX��\��A�ק�CAR301�wú�W�[��j�d�� */
        {
            if (strlen(sTmp) == 0)
            {
                strcpy(sMsgChk, "�D�s���A���P���X���i���ť�; ");
                strcat(v_errMsg , rtrim(sMsgChk));  
                fErr++;   
            }
        }
        /*------------------ [�ˮ�] �D�s���A���P���X���i���ť� �� ----------------------*/ 
        
    } 
    /*------------------------------- [CR�B17N �ӧO�P�_�ˮ�]  ���� --------------------------------------*/
    printf("-- trace fErr[%d]\n ",fErr);
    if (fErr>0)
    {
        rt_code = M_CM_ORDINARY_CHECK ;             
    }
    else  /* �����T�� */
    {  
        printf("-- trace iassured_cntry[%s]\n ",iassured_cntry);      
        /*------------------ [����] �j���H�h  �� ----------------------*/
        if (iassured_cntry[0]=='2' || iassured_cntry[0]=='8')
        {
            strcpy(sMsgChk, "�����G�p������m��̡A�ݴ��ѩ~�d�Ҽv���H�T�{�O�_���j���H�h; ");
            strcat(v_errMsg , rtrim(sMsgChk));	        
        }        
        printf("-- trace v_errMsg[%s]\n ",v_errMsg);
        /*------------------ [����] �j���H�h  �� ----------------------*/
    }
    
    /* �]���ֽҵ{���O�u�ˮ֥��N�I�A�B�]�|�Ψ�ͤ�A�G�ɥ�RBA�o�q�i���ˮ� (1110822005_SC1) */
    fErr = 0;
    t_count = 0;
    
    if(g_frenew_type[0]=='6')
    {
        $SELECT count(*) into $t_count
           FROM ca_quotation
          WHERE iquote = $estimatei 
            AND iins_kind_ply ='C2'; 
    }
    else
    {
        $SELECT count(*) into $t_count
           FROM cm_pre_receive
          WHERE iins_cat = 'C' 
            AND ipre_rcv = $estimatei 
            AND iins_kind ='2';    	
    }
    

        
    printf("\n\nestimatei[%s]\n\n",estimatei);
    printf("\n\nt_count[%d]\n\n",t_count);
    if (t_count > 0) /* 1070712009-SC1-��j��ƥi���ˮ�RBA  �����N�I�N�n */
    {       
        /* 1061012002-SC3 ISID+rba  ���e�����I�W��d�� �yS:�������z�A�h���o�X�� */
        printf("\n\nt_count[%d]\n\n",t_count);
        strcpy(iassured_cntry_rba  ,"N");     
        strcpy(iapplicant_cntry_rba,"N");
               
        if(dbirth == DATENULL)
        {
            strcpy(rba_dbirth," ");
        }
        else
        {
            strcpy(rba_dbirth,cm_edate_str(dbirth));
        }

        if( dbirth_appl == DATENULL )
        {
            strcpy(rba_dbirth_appl," ");
        }
        else
        {
            strcpy(rba_dbirth_appl, cm_edate_str(dbirth_appl));
        }
        
        /*-------------------[�ˮ�]���ֽҵ{�B�����ݫȬO�_���V �� ----------------------*/
        /* (1110822005_SC1) (1130103013_C03) */
        t_count = 0;
        $select count(*) into $t_count
           from officer 
          where iofficer = $officer
            and irate_type <> 'E';    /* �O�v�OE���ˬd */
        
        if (t_count > 0)
        {
            strcpy(sDply2_begin, cm_edate_str(ply2_begin));
            rc = cm_chk_elder(iroute, officer, big_sales, "Y", rba_dbirth, rba_dbirth_appl, sDply2_begin, sFelder_type, sErrmsg);  
        	
            if ( rc != M_CM_OK )
            {  
                strcpy(sMsgChk,"cm_chk_elder()�ˮ֦��~�A�гq����T��");
        	strcat(v_errMsg , rtrim(sMsgChk));
        	fErr++;
            }
            else
            {
        	if(strncmp(sFelder_type,"N",1) == 0) 
        	{
        	    strcpy(sMsgChk, sErrmsg);
        	    strcat(v_errMsg , rtrim(sMsgChk)); 
        	    fErr++; 
        	}
            }
        }
        /*-------------------[�ˮ�]���ֽҵ{�B�����ݫȬO�_���V �� ----------------------*/             
        
        /* 1101124011_SC1_RBA�ק�@�~ �]�禡���վ�A�ҥH�������O���ק� */
        if(strncmp(iassured_cntry,"1",1)==0)   strcpy(iassured_cntry_rba  ,"Y");
        if(strncmp(iapplicant_cntry,"1",1)==0) strcpy(iapplicant_cntry_rba,"Y");
        
        if(strncmp(assuredi,iapplicant,10) == 0)
        {
            rc = cm_check_simple_RBA( assuredi ,assuredn ,rba_dbirth ,iassured_cntry_rba ,rba_fresult ,rba_nresult );
            printf("111-rba_fresult[%s]\n",rba_fresult);
            printf("111-rba_nresult[%s]\n",rba_nresult);
            if (rc != M_CM_OK)
            {
                $ROLLBACK WORK;
                return rc;
            }
            if(strncmp(rba_fresult,"S",1) == 0)   
            {   
                strcat(v_errMsg , ";�n�Q�O�H");
                strcat(v_errMsg , iapplicant);
                strcat(v_errMsg , rtrim(rba_nresult));
                fErr++;
            }
        }
        else
        {
            /*1.�n�O�H 2.�Q�O�H*/
            rc = cm_check_simple_RBA(iapplicant,napplicant ,rba_dbirth_appl ,iapplicant_cntry_rba ,rba_fresult ,rba_nresult );
            if (rc != M_CM_OK)
            {
                $ROLLBACK WORK;
                return rc;
            }
            if(strncmp(rba_fresult,"S",1) == 0)   
            {   
                strcat(v_errMsg , ";�n�O�H");
                strcat(v_errMsg , iapplicant);
                strcat(v_errMsg , rtrim(rba_nresult));
                fErr++;
            }
            
            
            rc = cm_check_simple_RBA(assuredi,assuredn ,rba_dbirth ,iassured_cntry_rba ,rba_fresult ,rba_nresult );
            if (rc != M_CM_OK)
            {
                $ROLLBACK WORK;
                return rc;
            }
            if(strncmp(rba_fresult,"S",1) == 0)   
            {   
                strcat(v_errMsg , ";�Q�O�H");
                strcat(v_errMsg , assuredi);
                strcat(v_errMsg , rtrim(rba_nresult));
                fErr++;
            }
        }
    }
    
    if (fErr>0)
    {
        rt_code = M_CA_NCHK_RBA ;             
    }
     
    printf("end DataCheck1() :trace rt_code[%d]\n ",rt_code); 
    return rt_code;
          
chk_err:
    printf(" DataCheck1() sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    sprintf_s(v_errMsg,sizeof v_errMsg,"DataCheck1()���~:SQLCODE=[%d]sqlca.sqlerrm=[%s],sqlca.sqlerrd[1]=[%d]", SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);       
    return SQLCODE;    
}

/* 2. �ˮ֮ɶ��I����(�b CA3011OptAU()����Cal_prem_21() ���e) */    
static int DataCheck2(INS_ptr,INS_ptr_56,INS_ptr_35,INS_ptr_48)
struct INS_TYPE *INS_ptr;
struct INS_TYPE_33 *INS_ptr_56, *INS_ptr_35, *INS_ptr_48;
{
    $WHENEVER SQLERROR GOTO chk_err;

    $int     t_count;
    $char    v_ins_type[INSURANCE_TYPE],v_frate[5];
    int      rt_code, rc,fErr,fLia,rt_Kind;
    char     sMsgChk[201],sIins_cat[2],sValid[3],sTmp[1024];

    $long    sToday,sLdeffect,sLdeffect4,pass_mprem_2,sLdecard_35;
    $int     iTmp,jTmp,cn_day,qday_permit,iCount = 0,t_cnt = 0,illegal_cnt = 0,dwork = 0;
    $char    deffect4[11],deffect4_edr[11],sCommand[50],decard_35[11];
    $char    v_iofficer[11]=" ",v_ileader[11]=" ",v_iquota[7]=" ",v_icomm_obj[11]=" ",v_iroute_prop[3]=" ";
    $char    v_chk_msg[2];/*1090207006-SC2-���ɮi-�O��үd�s���q�T���(�t�q�l�l��H�c�a�}�q�ܤ��)���ޱ�*/
    $char    tmp_iemail[51],tmp_aemail_appl[51],tmp_aemail_eply[51];
    $char    fallowbat[2];
    fErr = 0; fLia = 0;
    rt_code = M_CM_OK;	 rc = 0;  strcpy(v_errMsg , ""); strcpy(sMsgChk , "");		
    strcpy(v_frate , " ");	strcpy(sValid , " ");
    printf("---- into DataCheck2() ----\n ");

    sToday = cm_today( );  /* �t�Τ� */    
    strcpy(sIins_cat , "C");

    if (ply1f == TRUE)
    {
        strcpy(v_iofficer  , officer1 );    strcpy(v_iquota      , sIquota1); 
        strcpy(v_icomm_obj , icomm_obj1);   strcpy(v_iroute_prop , iroute_prop1 );
        strcpy(v_ileader  ,  sIleader1 ); 
    }
    else
    {
        strcpy(v_iofficer  , officer2 );    strcpy(v_iquota      , sIquota2); 
        strcpy(v_icomm_obj , icomm_obj2);   strcpy(v_iroute_prop , iroute_prop2 );
        strcpy(v_ileader  ,  sIleader2 ); 
    }
    
    /* 1060913004_C1_���se�O��B2B�w�靈���p�����j�B���O�氵�����ˮ� */
    if ((ply1f == TRUE) && (ply2f == TRUE))
    {        
        char v_car_typei2[3];       
        
        strcpy(car_typei1, trim(car_typei1));
        strcpy(car_typei2, trim(car_typei2));
        if ( (strlen(car_typei1) > 0)  && (strlen(car_typei2) > 0) )
        {
            strcpy(v_car_typei2, TRANS_CAR_TYPE(car_typei2,v_frate)); /* ���N�I�����ഫ���O�o����*/
            if (strcmp(car_typei1, v_car_typei2)!=0)
            {
                sprintf_s(sMsgChk,sizeof sMsgChk,"�j���I����(%s)�P���N�I����(%s)���šA�Щ�ʲz���d����A�X��A�ΨϥΤH�u�f��(S)��X��; ",car_typei1, car_typei2);
                strcat(v_errMsg , rtrim(sMsgChk));
                fErr++;
            }
        }
    }
    
    if ((strncmp(car_typei,"51",2)==0)||(strncmp(car_typei,"T1",2)==0)||(strncmp(car_typei,"T2",2)==0))
    {
        strcpy(sIins_cat , "O");
        /* 1070531010-SC1 �W�[��j�d�� �����۰ʥX�� �èϥεe�����֫O�H��*/
        if(strlen(isign_batch_oth)==0)
        { 
            sprintf_s(sMsgChk,sizeof sMsgChk, "�ˮַs�خ֫O�H���ɵo�Ϳ��~(%s); ",car_typei);
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;
        }
        else
        {
            strcpy(isign, isign_batch_oth);
        }
    }

    if (strncmp(car_typei,"CS",2)==0)
    {

        /* 11120927002_C01_�R�q�ΰӫ~�}�o*/
        sprintf_s(sMsgChk,sizeof sMsgChk, "�R�q�ΰӫ~�г浧�X��(%s); ",car_typei);
        strcat(v_errMsg , rtrim(sMsgChk));
        fErr++;

    }
    
    
    INS_ptr      = Ifirst;
    printf("Ifirst[%s]\n",Ifirst);

    while (INS_ptr)
    {        
        if (strcmp(trim(INS_ptr->ins_type),"**")==0)
        {
            INS_ptr = INS_ptr->next;
            continue;
        }

        strcpy(v_ins_type , INS_ptr->ins_type); strcpy(v_ins_type , trim(v_ins_type));
        
        if (strcmp(v_ins_type,"21") == 0)
        {
            /* �j���I */
        }
        else
        {
            if (v_frate[0] == ' ' || v_frate[0] == '\0')
            {
                strcpy(v_frate, INS_ptr->frate);  strcpy(v_frate , trim(v_frate));
                printf("-- trace v_frate[%s]\n ",v_frate);
            }

            /* �P�_�O�_�ӫO�ĤT�H�d���I */                        	
            if ((strcmp(v_ins_type,"31" ) == 0)||(strcmp(v_ins_type,"32" ) == 0)||(strcmp(v_ins_type,"77" ) == 0)||(strcmp(v_ins_type,"78" ) == 0)||
                (strcmp(v_ins_type,"113") == 0)||(strcmp(v_ins_type,"114") == 0)||(strcmp(v_ins_type,"131") == 0)||(strcmp(v_ins_type,"132") == 0)||
                (strcmp(v_ins_type,"133") == 0)||(strcmp(v_ins_type,"134") == 0)||(strcmp(v_ins_type,"149") == 0)||
                (strcmp(v_ins_type,"231") == 0)||(strcmp(v_ins_type,"232") == 0)||(strcmp(v_ins_type,"331") == 0)||(strcmp(v_ins_type,"332") == 0)||
                (strcmp(v_ins_type,"249") == 0)||(strcmp(v_ins_type,"531") == 0)||(strcmp(v_ins_type,"532") == 0))
            {
                fLia = 1;
            }
            else if (strcmp(v_ins_type,"58" ) == 0)
            {
                strcpy(sIins_cat , "O");
                /* 1070531010-SC1 �W�[��j�d�� �����۰ʥX�� �èϥεe�����֫O�H��*/
                if(strlen(isign_batch_oth)==0)
                {
                    sprintf_s(sMsgChk,sizeof sMsgChk, "�ˮַs�خ֫O�H���ɵo�Ϳ��~(%s); ",v_ins_type);
                    strcat(v_errMsg , rtrim(sMsgChk));
                    fErr++;
                }
                else
                {
                    strcpy(isign, isign_batch_oth);
                }
            }
        }
          
        INS_ptr=INS_ptr->next;
    }
    printf("-- trace sIins_cat[%s]\n ",sIins_cat);
    

    /*================================ ���j���I�~�ˮ� �� ====================================*/      
    if (ply1f == TRUE)
    {

        /*------------------ [�ˮ�]�j���I�O��   �� ----------------------*/		    
        jTmp = 0;
        for(iTmp=1;jTmp<=4;iTmp++)
        {
            $select 1 
               from ca_holiday
              where (date($ply1_begin) + $iTmp) between holiday_bgn and holiday_end;
              
            if( SQLCODE == SQLNOTFOUND) jTmp++;
            
            printf("iTmp[%d,jTmp[%d]\n", iTmp, jTmp);
            
            if( jTmp == 4 ) break;
        }

        $select first 1 to_char(date($ply1_begin) + $iTmp) into $deffect4 from ca_holiday;
        
        printf("deffect4[%s]\n",deffect4);

        strcpy(deffect4_edr, cm_from_infdate_100(deffect4));
        sLdeffect4 = cm_ymd_cdate(deffect4_edr);

        printf("***** Today[%ld], Deffect4[%ld]*****\n", sToday, sLdeffect4);
        
        /*** �i�t�Τ� > �ͮĤ�+�|�Ӥu�@�ѡjor�i�t�Τ� = �ͮĤ�+�|�Ӥu�@�� �B �w�鵲�j--->�i�O����j ***/ 
        if (sToday > sLdeffect4)
        {
            sprintf_s(sMsgChk,sizeof sMsgChk, "�j���I�O����J�A�Шϥ�S��(�S����)�X��; ",sIleader);
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;
        }
        else if (sToday == sLdeffect4)
        {
            iCount = 0;
            strcpy(sCommand,"*");
            strcat(sCommand,"car5081");
            strcat(sCommand,"*");
            strcat(sCommand,localdb);
            strcat(sCommand,"*");
             
            printf("sCommand=[%s]\n",sCommand);
        
            $SELECT count(*)
               INTO $iCount
               FROM gb_ScheduleLog
              WHERE command matches $sCommand
                AND date(tctime) = today;
            
            if (iCount > 0)
            {
                sprintf_s(sMsgChk,sizeof sMsgChk, "�j���I�O����J�A�Шϥ�S��(�S����)�X��; ",sIleader);
                strcat(v_errMsg , rtrim(sMsgChk));
                fErr++;
            }
        }
        
        /*------------------ [�ˮ�]�j���I�O��   �� ----------------------*/
    
        /*-------------------[�ˮ�]�O�v�N��     �� ----------------------*/
        
        t_count = 0;
        $SELECT count(*)  Into $t_count
           FROM ca_rate_renew
         WHERE deffect_bgn <= $ply1_begin
           AND deffect_end >= $ply1_begin
           AND fcard_class = '1'
           AND ( (icode = $comp_rym)
                  OR 
                 (code_flag = 'Y' and (icode1 = $comp_rym OR icode2 = $comp_rym OR icode3 = $comp_rym))
               );
        if (t_count==0) 
        {
            sprintf_s(sMsgChk,sizeof sMsgChk, "�j��u�O�v�N���v(%s)�A�P�j��u�ͮĤ�v�i�ϥΤ��O�v�N���d�򤣲�(car128); ",comp_rym);
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;  
        }
        /*-------------------[�ˮ�]�O�v�N��     �� ----------------------*/
        
        /*-------------------[�ˮ�]�~�֩ʧO�Y�� �� ----------------------*/
        if ((assuredf[0]=='1' || assuredf[0]=='3' || assuredf[0]=='5'))
        {
            if (psex_age1 == 0)
            {
                strcpy(sMsgChk, "�۵M�H�ӫO�j���I�A�j��~�֩ʧO�Y�Ƥ��o�� 0; ");
                strcat(v_errMsg , rtrim(sMsgChk));
                fErr++;	
            }
        }
        /*-------------------[�ˮ�]�~�֩ʧO�Y�� �� ----------------------*/
        
        /*1111123004_SC1_(�t)�L�q���мW�[�ˮ֦b111.12.15�e�X��@�ߥu���i�q�l�j���ҡj*/
        /*-------------------[�ˮ�]�L�q��(35����)�ȭ���ܡu�j��q�l���ҡv �� ----------------------*/
        if (strcmp(car_typei1,"35")==0 && fecard[0] == '0')
        {
            strcpy(sMsgChk, "�L�q��(35����)�ȭ���ܡu�j��q�l���ҡv; ");
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;
        }
        /*-------------------[�ˮ�]�L�q��(35����)�ȭ���ܡu�j��q�l���ҡv �� ----------------------*/
        
    }


    /*================================ �����N�I�~�ˮ� �� ====================================*/ 
    if (ply2f == TRUE)
    {   
        /*------------------ [�ˮ�]���N�I�O��  �� ----------------------*/	

        /*** ���N�I�ͮĤ�p�󤵤ѤT�Ӥ�A�Шϥ�S��X�� ***/
        $SELECT count(dwork)
           INTO $dwork
           FROM cm_wrktbl
          WHERE dwork > $ply2_begin
            AND dwork <= today;
        
        printf("dwork[%d]\n",dwork);
        
        if (dwork > 90)
        {
            sprintf_s(sMsgChk,sizeof sMsgChk, "���N�I�ͮĤ�p�󤵤ѤT�Ӥ�A�ШϥΤH�u�f��(S)��X��; ",sIleader);
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;
        }        
        /*------------------ [�ˮ�]���N�I�O��  �� ----------------------*/
        
        /*-------------------[�ˮ�]�O�v�N��     �� ----------------------*/	 
        
        t_count = 0;
        $SELECT count(*)  Into $t_count
           FROM ca_rate_renew
         WHERE deffect_bgn <= $ply2_begin
           AND deffect_end >= $ply2_begin
           AND fcard_class = '2'
          AND ( (icode = $v_frate)
                  OR 
                (code_flag = 'Y' and (icode1 = $v_frate OR icode2 = $v_frate OR icode3 = $v_frate))
              );
        if (t_count==0) 
        {
            sprintf_s(sMsgChk,sizeof sMsgChk, "���N���u�O�v�N���v(%s)�A�P���N���u�ͮĤ�v�i�ϥΤ��O�v�N���d�򤣲�(car128); ",v_frate);
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;
        }
        /*-------------------[�ˮ�]�O�v�N��     �� ----------------------*/

        /*-------------------[�ˮ�]�~�֩ʧO�Y�� �� ----------------------*/
        if ((assuredf[0]=='1' || assuredf[0]=='3' || assuredf[0]=='5'))
        {
            if ((psex_age2 == 0) && (fLia==1))
            {         	
                strcpy(sMsgChk, "�۵M�H�ӫO�ĤT�H�d���I�A���d�~�֩ʧO�Y�Ƥ��o�� 0; ");
                strcat(v_errMsg , rtrim(sMsgChk));
                fErr++;
            }      
        }
        /*-------------------[�ˮ�]�~�֩ʧO�Y�� �� ----------------------*/    
        
                
    }  

    /*================================ �@�߳��n�ˮ� �� ====================================*/ 
            
    rc = cm_chk_policy("P", v_iofficer, " ", v_iquota, v_icomm_obj, "C", iroute, v_iroute_prop);
    if( rc != M_CM_OK)
    {
        strcpy(sMsgChk, cm_get_errmsg(rc));    	    
        strcat(v_errMsg , rtrim(sMsgChk));
        fErr++;  
    }

    /* ������u�޲z�H�v�s�b��cmn514(cm_signatory)�����Į֫O�H���� */         
    /*1091021005-SC1-���ά�-�s�W�A�Ȥ��ߩ�����*/
    rc = chk_valid_isign(sIins_cat,v_ileader," ", "U" ,sValid, sTmp);
    if( rc != M_CM_OK)
    {
        strcpy(sMsgChk, cm_get_errmsg(rc)); strcpy(sMsgChk, rtrim(sMsgChk));
        strcat(sMsgChk, "; ");
        strcat(v_errMsg , rtrim(sMsgChk));
        fErr++; 
    }
    else
    {
        printf("-- trace v_ileader[%s]- sValid[%s]\n ",v_ileader,sValid);
        if (sValid[0] != 'N')
        {
            sprintf_s(sMsgChk,sizeof sMsgChk, "�����椧�u�޲z�H�v(%s)���i���֫O�H��(cmn514)���@; ",v_ileader);
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;	
        }
    }
    /* 1090207006-SC2-���ɮi-�O��үd�s���q�T���(�t�q�l�l��H�c�a�}�q�ܤ��)���ޱ� 
        ���I�S�� �n�O�H�q��(�]) */
    /* �]cm_check_noisemp_email()�Nemail�j���ഫ���j�g�A�קK�ȶD�X��E-MAIL��ӭ�� (1100913005_SC1) */
    
    strcpy(sMsgChk,"");
    rc = cm_check_route_sales_comm("A",v_iofficer,iroute,"C",big_sales,introducer,v_iroute_prop,iroute_accept," ",
                                  assuredi,iapplicant,iemail,aemail_appl,aemail_eply,
                                  mobil_phone,tel,tel_night,tmobile_appl,itel_appl," ",tmobile_eply,sMsgChk);
    printf("rc=[%d]\n",rc);
    if( rc != TRUE)
    {
        strcat(v_errMsg , rtrim(sMsgChk));
        strcat(v_errMsg , "; ");
        fErr++;  
    }
    strcpy(v_chk_msg,"");
    strcpy(sMsgChk,"");
    strcpy(tmp_iemail,trim(iemail));
    strcpy(tmp_aemail_appl,trim(aemail_appl));
    strcpy(tmp_aemail_eply,trim(aemail_eply));
    rc = cm_check_noisemp_email(assuredi,iapplicant,tmp_iemail,tmp_aemail_appl,tmp_aemail_eply,v_chk_msg,sMsgChk);
    if( rc != TRUE)
    {
        if (v_chk_msg[0] == 'Y')
        {
            strcat(v_errMsg , rtrim(sMsgChk));
            strcat(v_errMsg , "; ");
            fErr++;  
        }
    }     
    /*------------------ [�ˮ�] �O�v�N�� �� ----------------------*/
    
    /*------------------ [�ˮ�]�O�渹�޲z����  �� ----------------------
    *** ���o�O�渹�޲z���� ***
 
    *------------------  [�ˮ�]�O�渹�޲z����  �� ----------------------*/
        
    /*--------------------- [CR�B17N �ӧO�P�_�ˮ�]  ���� --------------------------*/
    if (g_frenew_type[0]=='9') /* 17N */
    {   
    	/* 2019/07/05 �q���ܧ�q�l���i�藍�e�~*/
    }
    else if(g_frenew_type[0]=='6') /* ���X�� (1120923005_C02)*/
    {

    	/*����J�ͮīe�X��A�ҥH��J�餣�i�H�ߩ�ͮĤ�*/
    	if((ply1_begin < Today && ply1_begin > 0 ) || (ply2_begin < Today && ply2_begin > 0 ))
    	{
            sprintf_s(sMsgChk,sizeof sMsgChk, "6:���X���A�ȭ���ͮĤ�e�X��; ",v_ileader);
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;
    	}

    	
    	/*�ˬd�q���N�����]�w��car140���OBI*/
    	strcpy(fallowbat,"");
    	sprintf_s(stmt,sizeof stmt,"SELECT CASE WHEN count(*)>0 THEN 'Y' ELSE 'N' END FROM car_code "
	                           " WHERE kind='BI' AND detail matches '%s*'",iroute);
        $PREPARE pre_chkBI FROM $stmt;                        
	$EXECUTE pre_chkBI INTO $fallowbat ;
	if (strcmp(fallowbat,"N")==0)
	{
            sprintf_s(sMsgChk,sizeof sMsgChk, "���q���D�\\�i�ϥξ��X��\\�ध�q���A�г浧�X��; ",v_ileader);
            strcat(v_errMsg , rtrim(sMsgChk));
            fErr++;
	}
	
	
    }
    else  /* CR */
    {
        /*------------------ [�ˮ�] �q���~�ȭ� �� ----------------------*  
        

        /*------------------ [�ˮ�] �q���~�ȭ� �� ----------------------*/

        
    } 
    /*--------------------- [CR�B17N �ӧO�P�_�ˮ�]  ���� --------------------------*/
    
    if (fErr>0)
    {
        rt_code = M_CM_ORDINARY_CHECK ;
    }    
    else  /* �����T�� */
    {
        /*------------------ [����] xxx  �� ----------------------*/
      
        /*------------------ [����] xxx  �� ----------------------*/
    }

    return rt_code;
          
chk_err:
    printf(" DataCheck2() sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    sprintf_s(v_errMsg,sizeof v_errMsg,"DataCheck2()���~:SQLCODE=[%d]sqlca.sqlerrm=[%s],sqlca.sqlerrd[1]=[%d]", SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);        
    return SQLCODE;    
}


static int Update_car3011_temp(iestimate, fcard_class, ileader, iquota, nquota, iply_num, icard, fout_print, feply, sMsgX)
$char *iestimate,*fcard_class,*ileader,*iquota,*nquota,*iply_num,*icard,*fout_print,*feply,*sMsgX;
{
    $char v_fout_print[2]="N",v_feply[2]="N";

    if (fout_print[0]=='1') strcpy(v_fout_print,"Y");
    if (feply[0]=='1')      strcpy(v_feply,"Y");
         
    $WHENEVER SQLERROR GOTO ie_err;

    #ifdef PRINTF_FLAG
    printf("-- trace sMsgX[%s]\n ",sMsgX);
    printf("-- trace  strlen(sMsgX)[%d]\n ", strlen(sMsgX));
    #endif PRINTF_FLAG

    if (strlen(sMsgX) == 0) strcpy(sMsgX," ");            
        
    if (strcmp(fcard_class,"1") ==0)
    {
        $Update car3011_temp 
            Set ileader     = $ileader ,
                iquota      = $iquota,
                nquota      = $nquota,
                ipolicy1    = $iply_num ,
                icard1      = $icard ,
                fout        = $v_fout_print ,
                feply       = $v_feply ,
                dply_begin1 = $ply1_begin ,   /* ����������ܼ� */
                sMsg        = concat(nvl(rtrim(sMsg),' '),$sMsgX)
          Where iestimate   = $iestimate;
    }
    else
    {
        $Update car3011_temp 
            Set ileader     = $ileader ,
                iquota      = $iquota,
                nquota      = $nquota,
                ipolicy2    = $iply_num ,
                icard2      = $icard ,
                fout        = $v_fout_print ,
                feply       = $v_feply ,
                dply_begin2 = $ply2_begin ,   /* ����������ܼ� */
                sMsg        = concat(nvl(rtrim(sMsg),' '),$sMsgX)
          Where iestimate   = $iestimate;
    }     
        

    strcpy(v_errMsg,"");

    return SUCCESS;

ie_err:
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    sprintf_s(v_errMsg,sizeof v_errMsg,"Update_car3011_temp()���~:SQLCODE=[%d]sqlca.sqlerrm=[%s],sqlca.sqlerrd[1]=[%d]", SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);       
    return SQLCODE;
}

/* 1050803001 _C1 �ӽзs�W�ܺ��I�j���I�Y�ɶǿ�@�~ */
static long GetTransTradeFlag(iestimate,ftrans_trade)    
char *iestimate,*ftrans_trade;
{    
    $char sIestimate[21],s_fimmed_trans[2];
    $WHENEVER SQLERROR goto ErrExit;
    
    strcpy(sIestimate      , trim(iestimate));
    strcpy(s_fimmed_trans  , "0");
    
    if (strlen(sIestimate)>0)
    {
        $select case when fimmed_trans='Y' then '1' else '0' end 
           into $s_fimmed_trans 
           from ao_prercv_pass
          where ipre_rcv  = $sIestimate 
            and iins_kind = '1'
            and ipre_end  = ' ' ;
    }        
    strcpy(ftrans_trade  , s_fimmed_trans); 
    

    return M_CM_OK;
    
ErrExit:
    printf("GetTransTradeFlag: sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    sprintf_s(v_errMsg,sizeof v_errMsg,"GetTransTradeFlag()���~:SQLCODE=[%d]sqlca.sqlerrm=[%s],sqlca.sqlerrd[1]=[%d]", SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);      
    return SQLCODE;
}

/* trim() �[�j��, �R���r���Y���H�Τ��������� ' ', '\f' , '\n' , '\r' ,'\t' , '\v' ���r��*/
char* trimx (char *str)
{
    char *ibuf, *obuf;

    if (str)
    {
        for (ibuf = obuf = str; *ibuf; )
        {
            while (*ibuf && (isspace (*ibuf)))
                ibuf++;
            if (*ibuf && (obuf != str))
                *(obuf++) = ' ';
            while (*ibuf && (!isspace (*ibuf)))
                *(obuf++) = *(ibuf++);
        }
        *obuf = '\0';
    }
    return (str);
}
