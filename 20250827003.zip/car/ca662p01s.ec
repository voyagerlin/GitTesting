/**********************************************************************/
/*   program id   : ca662p01s.ec                                      */
/*   program name : �j��@����[��Oú�O������J                    */
/*   date written : 2022/01/18                                        */
/*   date modify  : 2022/07/20                                        */
/*   author       : 071004                                            */                                       
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h> 
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
#include "ISvar.h"
$include datetime.h;
#include "carmsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"
/****************************************************************************/
$char DBName[05],userid[11],GetFile[128];
$char dcreate_bgn[11],dcreate_end[11];
$char sDcreate_bgn[11],sDcreate_end[11];
$char iissue_comp[3],iofficer[11];
$char date[11],dToday[11],nyy[4],nmm[3],ndd[3];
$char errmsg[10000],errmpt1[100],delmsg[10000],addmsg[10000];
FILE  *fp, *fp1, *sfp;
$char sdata[20][201];
char  msgbuf[2048],sApHome[30];
char  iactiontype[2],v_sMsg[50000],v_sMsg2[11024],v_sMsg3[11024],v_sMsg4[11024];
char  fquery[2];
char  file_name[256],filename[200],tmpOutFile[200],outputf[N_FILE+1];
char  itransno[17],icard[21],itag[CA_TAG_NUM],fdate[2],
      dbgn[11],dend[11],dbgn2[11],dend2[11];
int   qcount,count_db,i,flen;
long  t;
int   strSearchReplace();
/****************************************************************************/
main(argc, argv)
int argc;
char **argv;
{  
	int rc;

	batchinit();
	strcpy(DBName, 		  isNULLstr(argv[1]));
	strcpy(userid, 		  isNULLstr(argv[2]));
	strcpy(iactiontype,       isNULLstr(argv[3]));  /* 1�G�@����[ú�O���X��T���ɮ���J 
	                                                   2�G��J��Ƭd�� 
	                                                   3�G��������O�q�����[ú�O���X��T���ɮ���J 
	                                                   4�G���s�O���p���覡�ШD��
	                                                   5�G�O���p���覡�^�����ɮ���J    */
	if (strcmp(iactiontype,"1")==0 || strcmp(iactiontype,"3")==0  || strcmp(iactiontype,"5")==0)
	{
	    strcpy(file_name,     isNULLstr(argv[4]));	
	    strcpy(outputf,       isNULLstr(argv[5]));
	    printf("-- iactiontype[%s], file_name[%s]\n",iactiontype,file_name);
	}
	else if (strcmp(iactiontype,"4")==0)
	{
	    strcpy(outputf,       isNULLstr(argv[4]));
	}
	else
	{
	    strcpy(itransno,      isNULLstr(argv[4]));
	    strcpy(icard,         isNULLstr(argv[5]));
	    strcpy(itag,          isNULLstr(argv[6]));
	    strcpy(fdate,         isNULLstr(argv[7]));
	    strcpy(dbgn,          isNULLstr(argv[8]));
	    strcpy(dend,          isNULLstr(argv[9]));
	    strcpy(fquery,        isNULLstr(argv[10]));
	    strcpy(outputf,       isNULLstr(argv[11])); 
	    
	    strcpy(itransno,  trim(itransno));
	    strcpy(icard,     trim(icard));
	    strcpy(itag,      trim(itag));
	    strcpy(fdate,     trim(fdate));
	    strcpy(dbgn,      trim(dbgn));
	    strcpy(dend,      trim(dend));	    
	    printf("-- iactiontype[%s], itransno[%s], icard[%s], itag[%s]\n",iactiontype,itransno,icard,itag);
	    printf("-- fdate[%s], dbgn[%s], dend[%s]\n",fdate,dbgn,dend);
	}

	sfp =  (FILE *)STARTLOG();
		
	rc = car662_get_db();
	if (rc != M_CM_OK) {
		EWRITE(userid,rc,msgbuf);
		return rc;
	}
	
  
        if (strncmp(iactiontype,"1",1) == 0)
        {	
            rc = car662_read_data();
            if (rc != M_CM_OK) 
            {
    		    EWRITE(userid, rc, "car662_read_data�ɮ���J���~!");
    		    return rc;
    	    }
    	    else
            {
                 printf("=============================> RETURN SUCCESS\n");
                 sprintf_s(v_sMsg, sizeof v_sMsg, "\n    �`���ơG%d��\n", qcount);       
                 WRITELOG( sfp, v_sMsg);
                 ENDLOG(sfp);       
            }
        }
        else if(strncmp(iactiontype,"2",1) == 0)
        {
        	
            rc = car662_query();
            if (rc != M_CM_OK) 
            {
    		    EWRITE(userid, rc, "�d�L���!");
    		    return rc;
    	    }

        }
        else if(strncmp(iactiontype,"3",1) == 0)
        {
        	
            rc = car662_read_data2();
            if (rc != M_CM_OK) 
            {
    		    EWRITE(userid, rc, "car662_read_data2�ɮ���J���~!");
    		    return rc;
    	    }
    	    else
            {
                 printf("=============================> RETURN SUCCESS\n");
                 sprintf_s(v_sMsg, sizeof v_sMsg, "\n    �`���ơG%d��\n", qcount);       
                 WRITELOG( sfp, v_sMsg);
                 ENDLOG(sfp);       
            }

        }
        else if(strncmp(iactiontype,"4",1) == 0)
        {
        	
            rc = car662_query2();
            if (rc != M_CM_OK) 
            {
    		    EWRITE(userid, rc, "�d�L���!");
    		    return rc;
    	    }

        }
        else if(strncmp(iactiontype,"5",1) == 0)
        {
        	
            rc = car662_read_data3();
            if (rc != M_CM_OK) 
            {
    		    EWRITE(userid, rc, "car662_read_data3�ɮ���J���~!");
    		    return rc;
    	    }
    	    else
            {
                 printf("=============================> RETURN SUCCESS\n");
                 sprintf_s(v_sMsg, sizeof v_sMsg, "\n    �`���ơG%d��\n", qcount);       
                 WRITELOG( sfp, v_sMsg);
                 ENDLOG(sfp);       
            }

        }
			
  return rc;
}
/******************************************************************************/
long car662_read_data()  /* 1110117005_SC1 */
{
	/* �@����[ú�O���X��T��(TVBCM17) */ 
        char  *bp;    
        int   rc, i, j, k, m, n;
        $char ibarcode1_in[10],itransno_in[17],ibarcode3_in[16],paydate_in[11],icard_in[18],
              itag_in[CA_TAG_NUM],itag_old_in[CA_TAG_NUM],iassured_in[11],icar_type_in[3];
        $long mprem_in;
        char  paydate_y_in[5],paydate_m_in[3],paydate_d_in[3];
        char  *pch[30];
        
        printf("BEGIN TO READ DATA\n");    

        $WHENEVER SQLERROR GOTO errexit;
    
        sprintf_s(filename, sizeof filename,"%s/dat/car/%s",sApHome,file_name);
        flen=1024;
        if ((fp=fopen(filename,"r"))==NULL) {
            sprintf_s(msgbuf, sizeof msgbuf,"%s �ɮ׶}�ҥ���",filename);
            EWRITE(userid,FALSE,msgbuf);
            return FALSE;
        }
        if ((bp=malloc(flen))==NULL) {
            sprintf_s(msgbuf, sizeof msgbuf,"System malloc failed !");
            EWRITE(userid,FALSE,msgbuf);
            free(bp);
            return FALSE;
        }
     
	qcount=0;	
	for (i=0;(feof(fp)==0);i++) 
	{
	    memset(bp,0x00,flen);
	    fgets(bp,flen,fp);
		        
	    if (bp[0]==0x00)	break;
	    if (strlen(trim(bp))<10)	break;
		 
	    /********************/
	    /**      �M��      **/  
	    /********************/ 
	     
	    for(j=0;j<10;j++)
	        sdata[j][0]='\0';
		 
		        	
	    /********************/
	    /**    Ū�����    **/  
	    /********************/ 
    
            strcpy(pch,"");
            strcpy(pch,strtok(bp,"||"));
	    for(j=0;j<10;j++)
	    {	
	    	strcpy(sdata[j],pch);
	    	strcpy(pch,strtok(NULL, "||"));
	    }
	    
	    printf("sdata[0] [%s] \n" ,sdata[0]);
	    printf("sdata[1] [%s] \n" ,sdata[1]);
	    printf("sdata[2] [%s] \n" ,sdata[2]);
	    printf("sdata[3] [%s] \n" ,sdata[3]);
	    printf("sdata[4] [%s] \n" ,sdata[4]);
	    printf("sdata[5] [%s] \n" ,sdata[5]);
	    printf("sdata[6] [%s] \n" ,sdata[6]);
	    printf("sdata[7] [%s] \n" ,sdata[7]);
	    printf("sdata[8] [%s] \n" ,sdata[8]); 	   
	    printf("sdata[9] [%s] \n" ,sdata[9]); 	   
	     	    	  
	    if (sdata[0][0]=='\0') continue;
	    
	    /********************/
	    /**   ��l�Ƹ��   **/  
	    /********************/   
	    
	    strcpy(ibarcode1_in,"");
	    strcpy(itransno_in,"");
	    strcpy(ibarcode3_in,"");
	    strcpy(paydate_y_in,"");
	    strcpy(paydate_m_in,"");
	    strcpy(paydate_d_in,"");
	    strcpy(paydate_in,"");
	    strcpy(icard_in,"");
	    strcpy(itag_in,"");
	    strcpy(itag_old_in,"");
	    strcpy(iassured_in,"");
	    strcpy(icar_type_in,"");
	    mprem_in=0.0;
	     
	    
	    /********************/
	    /**    ��ƳB�z    **/  
	    /********************/    
	    
	    /*  ú�O���X1 (1110622009_SC1) */
	    strcpy(ibarcode1_in,trim(sdata[0]));
	    strcpy(ibarcode1_in,trim(ibarcode1_in));
	    /*  ú�O���X2  */
	    strcpy(itransno_in,trim(sdata[1]));
	    strcpy(itransno_in,trim(itransno_in));
	    /*  ú�O���X3 (1110622009_SC1) */
	    strcpy(ibarcode3_in,trim(sdata[2]));
	    strcpy(ibarcode3_in,trim(ibarcode3_in));
	    /*  ú�O����   */
	    paydate_y_in[0]=sdata[3][0];
	    paydate_y_in[1]=sdata[3][1];
	    paydate_y_in[2]=sdata[3][2];
	    paydate_y_in[3]=sdata[3][3];
	    paydate_y_in[4]='\0';
	    paydate_m_in[0]=sdata[3][4];
	    paydate_m_in[1]=sdata[3][5];
	    paydate_m_in[2]='\0';
	    paydate_d_in[0]=sdata[3][6];
	    paydate_d_in[1]=sdata[3][7];
	    paydate_d_in[2]='\0';
	    sprintf_s(paydate_in, sizeof paydate_in,"%s/%s/%s",paydate_m_in,paydate_d_in,paydate_y_in);
	    strcpy(paydate_in,trim(paydate_in));
	    /*  ����O�I�Ҹ�  */
	    strcpy(icard_in,trim(sdata[4])+2);
	    strcpy(icard_in,trim(icard_in));
	    /*  ����  */
	    strcpy(itag_in,trim(sdata[5]));
	    strcpy(itag_in,trim(itag_in));
	    /*  �¨���  */
	    strcpy(itag_old_in,trim(sdata[6]));
	    strcpy(itag_old_in,trim(itag_old_in));
	    /*  �����Ҹ�/�νs  */
	    strcpy(iassured_in,trim(sdata[7]));
	    strcpy(iassured_in,trim(iassured_in));   
	    /*  ���إN�X  */
	    strcpy(icar_type_in,trim(sdata[8]));
	    strcpy(icar_type_in,trim(icar_type_in));     
	    /*  �O�I�O  */
	    mprem_in=atoi(trim(sdata[9]));
	    
	    if(strlen(itag_in)==0)  strcpy(itag_in," ");
	    if(strlen(itag_old_in)==0)  strcpy(itag_old_in," ");
	    
	    printf("ibarcode1_in[%s] \n" ,ibarcode1_in);
	    printf("itransno_in [%s] \n" ,itransno_in);
	    printf("ibarcode3_in[%s] \n" ,ibarcode3_in);
	    printf("paydate_in  [%s] \n" ,paydate_in);
	    printf("icard_in    [%s] \n" ,icard_in);
	    printf("itag_in     [%s] \n" ,itag_in);
	    printf("itag_old_in [%s] \n" ,itag_old_in);
	    printf("iassured_in [%s] \n" ,iassured_in);
	    printf("icar_type_in[%s] \n" ,icar_type_in);
	    printf("mprem_in    [%ld]\n" ,mprem_in);
	    
	    
	    
	    /* insert ca_comp_norenew_rcv */
            $INSERT INTO ca_comp_norenew_rcv
             VALUES('1',$ibarcode1_in,$itransno_in,$ibarcode3_in,$paydate_in,$icard_in,
                    $itag_in,$itag_old_in,$iassured_in,$icar_type_in,$mprem_in,
                    '','','','',current,null,null);
	    

	    qcount++;		  
	}
		   	 	      
        fclose(fp);
            
	    
    /*rc=rptftpinsert(userid,"car220",fname);
    if (rc != 0) return rc;*/
   
    return M_CM_OK;

errexit:
    printf("--car662_read_data-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car662_read_data2()  /* 1110222003_SC1 */
{
	/* ��������O�q�����[ú�O���X��T��(TVMCQ17) */
        char  *bp;    
        int   rc, i, j, k, m, n;
        $char ibarcode1_in[10],itransno_in[17],ibarcode3_in[16],paydate_in[11],icard_in[18],itag_in[CA_TAG_NUM];
        $long mprem_in;
        char  paydate_y_in[5],paydate_m_in[3],paydate_d_in[3];
        char  *pch[30];
        
        printf("BEGIN TO READ DATA\n");    

        $WHENEVER SQLERROR GOTO errexit;
    
        sprintf_s(filename, sizeof filename,"%s/dat/car/%s",sApHome,file_name);
        flen=1024;
        if ((fp=fopen(filename,"r"))==NULL) {
            sprintf_s(msgbuf, sizeof msgbuf,"%s �ɮ׶}�ҥ���",filename);
            EWRITE(userid,FALSE,msgbuf);
            return FALSE;
        }
        if ((bp=malloc(flen))==NULL) {
            sprintf_s(msgbuf, sizeof msgbuf,"System malloc failed !");
            EWRITE(userid,FALSE,msgbuf);
            free(bp);
            return FALSE;
        }
     
	qcount=0;	
	for (i=0;(feof(fp)==0);i++) 
	{
	    memset(bp,0x00,flen);
	    fgets(bp,flen,fp);
		        
	    if (bp[0]==0x00)	break;
	    if (strlen(trim(bp))<10)	break;
		 
	    /********************/
	    /**      �M��      **/  
	    /********************/ 
	    
	    for(j=0;j<7;j++)
	        sdata[j][0]='\0';
		 
		        	
	    /********************/
	    /**    Ū�����    **/  
	    /********************/ 
            
            strcpy(pch,"");
            strcpy(pch,strtok(bp,"||"));
	    for(j=0;j<7;j++)
	    {	
	    	strcpy(sdata[j],pch);
	    	strcpy(pch,strtok(NULL, "||"));
	    }
	    
	    printf("sdata[0] [%s] \n" ,sdata[0]);
	    printf("sdata[1] [%s] \n" ,sdata[1]);
	    printf("sdata[2] [%s] \n" ,sdata[2]);
	    printf("sdata[3] [%s] \n" ,sdata[3]);
	    printf("sdata[4] [%s] \n" ,sdata[4]);
	    printf("sdata[5] [%s] \n" ,sdata[5]);
	    printf("sdata[6] [%s] \n" ,sdata[6]);
	   
	     	    	  
	    if (sdata[0][0]=='\0') continue;
	    
	    /********************/
	    /**   ��l�Ƹ��   **/  
	    /********************/ 
	    
	    strcpy(ibarcode1_in,"");
	    strcpy(itransno_in,"");
	    strcpy(ibarcode3_in,"");
	    strcpy(paydate_y_in,"");
	    strcpy(paydate_m_in,"");
	    strcpy(paydate_d_in,"");
	    strcpy(paydate_in,"");
	    strcpy(icard_in,"");
	    strcpy(itag_in,"");
	    mprem_in=0.0;
	     
	    
	    /********************/
	    /**    ��ƳB�z    **/  
	    /********************/  
	    
	    /*  ú�O���X1  */
	    strcpy(ibarcode1_in,trim(sdata[0]));
	    strcpy(ibarcode1_in,trim(ibarcode1_in));
	    /*  ú�O���X2  */
	    strcpy(itransno_in,trim(sdata[1]));
	    strcpy(itransno_in,trim(itransno_in));
	    /*  ú�O���X3  */
	    strcpy(ibarcode3_in,trim(sdata[2]));
	    strcpy(ibarcode3_in,trim(ibarcode3_in));
	    /*  ú�O����  */
	    paydate_y_in[0]=sdata[3][0];
	    paydate_y_in[1]=sdata[3][1];
	    paydate_y_in[2]=sdata[3][2];
	    paydate_y_in[3]=sdata[3][3];
	    paydate_y_in[4]='\0';
	    paydate_m_in[0]=sdata[3][4];
	    paydate_m_in[1]=sdata[3][5];
	    paydate_m_in[2]='\0';
	    paydate_d_in[0]=sdata[3][6];
	    paydate_d_in[1]=sdata[3][7];
	    paydate_d_in[2]='\0';
	    sprintf_s(paydate_in, sizeof paydate_in,"%s/%s/%s",paydate_m_in,paydate_d_in,paydate_y_in);
	    strcpy(paydate_in,trim(paydate_in));
	    /*  ����O�I�Ҹ�  */
	    strcpy(icard_in,trim(sdata[4])+2);
	    strcpy(icard_in,trim(icard_in));
	    /*  ����  */
	    strcpy(itag_in,trim(sdata[5]));
	    strcpy(itag_in,trim(itag_in));     
	    /*  �O�I�O  */
	    mprem_in=atoi(trim(sdata[6]));
	    
	    if(strlen(itag_in)==0)  strcpy(itag_in," ");
	    
	    printf("itransno_in [%s] \n" ,ibarcode1_in);
	    printf("itransno_in [%s] \n" ,itransno_in);
	    printf("itransno_in [%s] \n" ,ibarcode3_in);
	    printf("paydate_in  [%s] \n" ,paydate_in);
	    printf("icard_in    [%s] \n" ,icard_in);
	    printf("itag_in     [%s] \n" ,itag_in);
	    printf("mprem_in    [%ld]\n" ,mprem_in);
	    
	    
	    
	    /*insert ca_comp_norenew_rcv*/
            $INSERT INTO ca_comp_norenew_rcv
             VALUES('2',$ibarcode1_in,$itransno_in,$ibarcode3_in,$paydate_in,$icard_in,
                    $itag_in,'','','',$mprem_in,
                    '','','','',current,null,null);
	    

	    qcount++;		  
	}
		   	 	      
        fclose(fp);
            
	    
    /*rc=rptftpinsert(userid,"car220",fname);
    if (rc != 0) return rc;*/
   
    return M_CM_OK;

errexit:
    printf("--car662_read_data2-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car662_read_data3()  /* 1110622009_SC1 */
{
	/* �O���p���覡�^������J��(ANSTVQIC17) */ 
        char  *bp;    
        int   rc, i, j, k, m, n;
        $char itransno_in[17],iassured_in[11],nassured_in[201],aassured_in[201],itel_in[17];
        char  *pch[30], scmd[1000], scmd2[1000];
        $char tmpOutFile[100], tmpOutFile2[100], strtime[14];
        
        printf("BEGIN TO READ DATA\n");    

        $WHENEVER SQLERROR GOTO errexit;
        
    
        $SELECT to_char(CURRENT,'%Y%m%d%H%M')
        INTO $strtime
        FROM systables WHERE tabid=1;
        
        strcpy(strtime, trim(strtime));
        sprintf_s(tmpOutFile, sizeof tmpOutFile,"%s/dat/car/%s",sApHome,file_name);
        sprintf_s(tmpOutFile2, sizeof tmpOutFile2,"%s/dat/car/car662_%s",sApHome,strtime);
        
        /*sprintf_s(scmd, sizeof scmd,"cp %s/dat/car/%s %s",sApHome,file_name,tmpOutFile);*/
        
        /* �NUTF-8�নBIG5 */
        sprintf_s(scmd2, sizeof scmd2,"iconv -c -f UTF-8 -t big5 %s > %s", tmpOutFile, tmpOutFile2);
        
        system(scmd);
	printf("scmd[%s]\n",scmd);
	system(scmd2);
	printf("scmd2[%s]\n",scmd2);

        
        flen=1024;
        if ((fp=fopen(tmpOutFile2,"r"))==NULL) {
            sprintf_s(msgbuf, sizeof msgbuf,"%s �ɮ׶}�ҥ���",tmpOutFile2);
            EWRITE(userid,FALSE,msgbuf);
            return FALSE;
        }
        if ((bp=malloc(flen))==NULL) {
            sprintf_s(msgbuf, sizeof msgbuf,"System malloc failed !");
            EWRITE(userid,FALSE,msgbuf);
            free(bp);
            return FALSE;
        }
 

     
	qcount=0;	
	for (i=0;(feof(fp)==0);i++) 
	{
	    memset(bp,0x00,flen);
	    fgets(bp,flen,fp);
		        
	    if (bp[0]==0x00)	break;
	    if (strlen(trim(bp))<10)	break;
		 
	    /********************/
	    /**      �M��      **/  
	    /********************/ 
	     
	    for(j=0;j<8;j++)
	        sdata[j][0]='\0';
		 
		        	
	    /********************/
	    /**    Ū�����    **/  
	    /********************/ 
    
            strcpy(pch,"");
            strcpy(pch,strtok(bp,"||"));
	    for(j=0;j<8;j++)
	    {	
	    	strcpy(sdata[j],pch);
	    	strcpy(pch,strtok(NULL, "||"));
	    }
	    
	    printf("sdata[0] [%s] \n" ,sdata[0]);
	    printf("sdata[1] [%s] \n" ,sdata[1]);
	    printf("sdata[2] [%s] \n" ,sdata[2]);
	    printf("sdata[3] [%s] \n" ,sdata[3]);
	    printf("sdata[4] [%s] \n" ,sdata[4]);
	    printf("sdata[5] [%s] \n" ,sdata[5]);
	    printf("sdata[6] [%s] \n" ,sdata[6]);
	    printf("sdata[7] [%s] \n" ,sdata[7]); 	   
	     	    	  
	    if (sdata[0][0]=='\0') continue;
	    
	    /********************/
	    /**   ��l�Ƹ��   **/  
	    /********************/   
	    
	    strcpy(itransno_in,"");
	    strcpy(nassured_in,"");
	    strcpy(aassured_in,"");
	    strcpy(itel_in,"");
	     
	    
	    /********************/
	    /**    ��ƳB�z    **/  
	    /********************/    
	    
	    /*  ú�O���X2  */
	    strcpy(itransno_in,trim(sdata[1]));
	    strSearchReplace(itransno_in,"\"",""); 
	    strcpy(itransno_in,trim(itransno_in));
	    /*  �����Ҹ�/�νs  */
	    strcpy(iassured_in,trim(sdata[4]));
	    strSearchReplace(iassured_in,"\"","");
	    strcpy(iassured_in,trim(iassured_in));
	    /*  �m�W  */
	    strcpy(nassured_in,trim(sdata[5]));
	    strSearchReplace(nassured_in,"\"","");
	    strcpy(nassured_in,trim(nassured_in));
	    /*  �a�}  */
	    strcpy(aassured_in,trim(sdata[6]));
	    strSearchReplace(aassured_in,"\"","");
	    strcpy(aassured_in,trim(aassured_in));   
	    /*  �q��  */
	    strcpy(itel_in,trim(sdata[7]));
	    strSearchReplace(itel_in,"\"","");
	    strcpy(itel_in,trim(itel_in));
	    if (strlen(itel_in) > 1)
	    {
	    	itel_in[strlen(itel_in)-1] = '\0';
	    	strcpy(itel_in,trim(itel_in));
	    }
	    else
	    	strcpy(itel_in," ");
	    
	    printf("itransno_in [%s] \n" ,itransno_in);
	    printf("iassured_in [%s] \n" ,iassured_in);
	    printf("nassured_in [%s] \n" ,nassured_in);
	    printf("aassured_in [%s] \n" ,aassured_in);
	    printf("itel_in     [%s] \n" ,itel_in);
	    
	    
	    /* update ca_comp_norenew_rcv */
            $UPDATE ca_comp_norenew_rcv
                SET nassured = $nassured_in,
                    aassured = $aassured_in,
                    itel     = $itel_in,
                    dupdate  = current
              WHERE itransno = $itransno_in
                AND iassured = $iassured_in;
	    

	    qcount++;		  
	}
		   	 	      
        fclose(fp);
            
	    
    /*rc=rptftpinsert(userid,"car220",fname);
    if (rc != 0) return rc;*/
   
    return M_CM_OK;

errexit:
    printf("--car662_read_data3-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car662_get_db()
{
	int return_code;
	
	$WHENEVER SQLERROR GOTO errexit;
	
	t = cm_today();
        strcpy(date,cm_edate_str(t));  
        strcpy(dToday,cm_from_infdate_100(date));
        cm_split_ymd_100(dToday,nyy,nmm,ndd);

	if (db_select(DBName) == False) {
		strcpy(msgbuf,"��Ʈw�L�k�}��");
		return M_CM_DB_NOTOPEN;
	}
	return_code = getApHome(sApHome);
	if (return_code < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		return return_code;
  }  
  return M_CM_OK;

errexit:
   printf("--car662_get_db-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/******************************************************************************/
long car662_query()
{
    
    $char stmt[2048];
    int   rc;
    char  sfilename[256],stitle[2048];
    char  swhere[30],swhere2[80];
    $WHENEVER SQLERROR GOTO errexit;


    strcpy(dbgn2, cm_to_infdate(dbgn));
    strcpy(dend2, cm_to_infdate(dend));


    if(strcmp(fquery,"1") == 0)
    {
    	strcpy(swhere,"AND ikind = '1' ");
    }
    else if(strcmp(fquery,"2") == 0)
    {
    	strcpy(swhere,"AND ikind = '2' ");	
    }
    else if(strcmp(fquery,"3") == 0)
    {
    	strcpy(swhere," ");		
    }
    
    
    if(strcmp(fdate,"0") == 0)
    	sprintf_s(swhere2, sizeof swhere2,"AND date(dcreate) between '%s' and '%s' ",dbgn2,dend2);
    else
    	sprintf_s(swhere2, sizeof swhere2,"AND date(dupdate) between '%s' and '%s' ",dbgn2,dend2);
    
    printf("swhere2[%s]\n",swhere2);
    
    sprintf_s(stmt, sizeof stmt,"SELECT decode(ikind,'1','�@����[ú�O��','��������O�q�����[ú�O��'), "
                 "       itransno, paydate, icard, nassured, aassured, chr(127)||trim(itel), itag, itag_old, "
                 "       iassured, icar_type, mprem, iestimate, to_char(dcreate,'%%Y/%%m/%%d %%H:%%M'), "
                 "       ibarcode1, chr(127)||ibarcode3, "
                 "       to_char(dprint,'%%Y/%%m/%%d %%H:%%M'), to_char(dupdate,'%%Y/%%m/%%d %%H:%%M') "
                 "  FROM ca_comp_norenew_rcv "
                 " WHERE itransno matches '%s' AND icard matches '%s' "
	         "   AND itag matches '%s' %s %s ",
	         itransno,icard,itag,swhere,swhere2);    

  

    strcpy(sfilename,"�@��Υ���O�q��ú�O��T����J����[car662]");	
    
    sprintf_s(stitle, sizeof stitle,"�@��Υ���O�q��ú�O��T����J����[car662]\n\t�d�߰϶�:%s~%s\t\n",dbgn,dend);
    strcat(stitle,"\t�������\t�O�o����ú�O���X\tú�O����\t����O�I�Ҹ�\t�m�W\t�a�}\t�q��\t����\t�¨���"
                  "\t�����Ҹ�/�νs\t���إN�X\t�O�I�O\t�����渹\t��J�ɶ�\t���X1\t���X3\t����ШD�ɮɶ�\t�^������J�ɶ�\t");
	
    rc = unload_file(outputf," ",sfilename,stitle,stmt);
	
    if (rc != SUCCESS) 
    {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }
	
    return M_CM_OK;
   

errexit:
    printf("--car662_query-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car662_query2()
{
    
    int   rc;
    char  sfilename[256],stitle[2048],stmt1[6000];
    $char ibarcode1_out[10],itransno_out[17],ibarcode3_out[16],itag_out[CA_TAG_NUM],iassured_out[11];
    $char  strtime[20];
    
    /* file */
    char   outputf[50],file1[50],prtstr1[1500];
    FILE   *fptr1;
    char   *bp;
    $WHENEVER SQLERROR GOTO errexit;
    
    /*if (db_select(DBName) == FALSE) {
        EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
        return M_CM_DB_NOTOPEN;
    }
    
    rc = getApHome(sApHome);
    if (rc < 0) {
    	strcpy(msgbuf,"read Config file error!!-->getApHome\n");
    	return rc;
    }*/
    
    $SELECT to_char(CURRENT,'%Y%m%d%H%M')
       INTO $strtime
       FROM systables WHERE tabid=1;
    
    strcpy(file1," ");
    sprintf_s(outputf, sizeof outputf, "ISQIC17.%s", trim(strtime));
    printf("outputf=[%s]\n", outputf );
    sprintf_s(file1, sizeof file1,"%s/rptftp/%s",sApHome,rtrim(outputf));
    /*fptr1=fopen(file1,"w");*/
    
    if ((fptr1=fopen(file1,"w")) == NULL){
    	sprintf_s(errmsg, sizeof errmsg,"Cannot open print file: %s",file1);
    	return M_CM_OPEN_FILE_FAIL;
    }
    
    $DECLARE CUR_Q2 CURSOR FOR
      SELECT a.ibarcode1, a.itransno, a.ibarcode3, a.itag, a.iassured  
        INTO $ibarcode1_out, $itransno_out, $ibarcode3_out, $itag_out, $iassured_out
        FROM ca_comp_norenew_rcv a, cm_pre_receive b
       WHERE a.iestimate = b.ipre_rcv 
         AND b.iins_cat = 'C' 
         AND a.ikind = '1'
         AND a.paydate >= today - 15
         AND a.dprint is null
         AND b.fstatus in (50,60);

    $OPEN CUR_Q2;
    
    while (1)
    {
    	$FETCH CUR_Q2;
    	  
    	if(SQLCODE == SQLNOTFOUND) break;
    	
    	strcpy(prtstr1,"\"");  /* ���޸� */
    	strcat(prtstr1,rtrim(ibarcode1_out)); /* ú�O���X1 */
    	strcat(prtstr1,"\"||\"");
        strcat(prtstr1,rtrim(itransno_out));  /* ú�O���X2 */
        strcat(prtstr1,"\"||\"");    
        strcat(prtstr1,rtrim(ibarcode3_out)); /* ú�O���X3 */
        strcat(prtstr1,"\"||\"");  
        strcat(prtstr1,rtrim(itag_out));      /* ���� */
        strcat(prtstr1,"\"||\"");    
        strcat(prtstr1,rtrim(iassured_out));  /* �����Ҹ�/�νs */ 
        strcat(prtstr1,"\"");
        /*strcat(prtstr1,"0x0a");  */
        fprintf(fptr1,"%s\n",prtstr1); 
        
        /* update ca_comp_norenew_rcv */
        $UPDATE ca_comp_norenew_rcv
            SET dprint  = current
          WHERE itransno = $itransno_out;
    }
    $CLOSE CUR_Q2;
    $FREE  CUR_Q2;
    fclose(fptr1);
    
    rc = rptftpinsert(userid,"car662",outputf);
    if (rc != 0){ 
    	printf("rptftp error\n");
    	goto errexit;
    }
    
    
/*
    printf("stmt[%s]",stmt);
   	
    rc = unload_file(outputf," "," "," ",stmt);
	
    if (rc != SUCCESS) 
    {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }
*/	
    EWRITE(userid, M_CM_OK, "�ШD�ɲ��s�����A�Ц��ɮפU���@�~(cmn202)�U��\n");
    
    return M_CM_OK;
   

errexit:
    printf("--car662_query2-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
int strSearchReplace(char *string,char *searchString,char *replaceString)
{
    char *currP, *baseStr;
    int  count = 0;
    
    currP = baseStr = NULL;
    
    while (*string)
    {
    	currP = strstr (!currP ? string : baseStr, searchString);
    	
    	if (currP)
    	{
    		count++;
    		baseStr = (currP + strlen (replaceString));
    		strcpy (currP, (currP + strlen (searchString)));
    		memmove (currP + strlen (replaceString), currP, strlen (currP) + 1);
    		memcpy (currP, replaceString, strlen (replaceString));
    	}
    	else
    	    break;
    }
    
    return count;
}
/******************************************************************************/