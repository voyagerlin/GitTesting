/**********************************************************************/
/*   program id   : ca633q01s.ec                                      */
/*   program name : ���w�r�p�H����                                    */
/*   date written : 2012/09/27                                        */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "safeclib.h"
$char DBName[05], userid[11];
char  outputf[21];
char  sdate1[11],sdate2[11];
$char msgbuf[128];
int   k, count_db;
DBinfo *list;
/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
    int rc;

    batchinit();
    strcpy(DBName,    		isNULLstr(argv[1]));
    strcpy(userid,    		isNULLstr(argv[2]));
    strcpy(sdate1,    		isNULLstr(argv[3]));	/* �d�߰_�� CYY/MM/DD */
    strcpy(sdate2,    		isNULLstr(argv[4]));	/* �d�ߨ��� CYY/MM/DD */
    strcpy(outputf,   		isNULLstr(argv[5]));	

    rc = car633_get_db();
    if (rc != M_CM_OK)
       return rc;
       
    rc = car633_temp_table();
    if (rc != M_CM_OK)
       return rc;

		rc = car633_prepare_data_0();
		if (rc != M_CM_OK)  return rc;

		rc = car633_build_0();
		if (rc != M_CM_OK)  return rc;

		return ;
}
/*--------------------------------------------------------------------*/
long car633_get_db()
{
   $whenever sqlerror goto errexit;
	 printf("------ car633_get_db ----------- \n");
   if (db_select(DBName) == FALSE) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }

   if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
      if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
         return M_CM_NOT_DBLIST;
   }
   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/
long car633_temp_table()
{
		$whenever sqlerror goto errexit;
		
		printf("------ car633_temp_table ----------- \n");
		$create temp table tb_6331
		(
			isign			char(10),		-- �֫O�H���N��
			nsign			char(30),		-- �֫O�H���N��
			iofficer	char(10),		-- �g��N��
			ipolicy		char(20),		-- �O�渹
			nassured	char(60),		-- �Q�O�I�H�m�W
			dpolicy		date,				-- ñ����
			dentry		date				-- ��J���
		)with no log;
		
		
   $delete from tb_6331 where 1=1;
   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/* --------------------------------------------------------------------- */
long car633_prepare_data_0()
{
	$char sTmpstr[2000];
	$char sDate_bgn[11], sDate_end[11];

	
	$whenever sqlerror goto errexit;

	printf("-------- start car633_prepare_data_0() --------------------------- \n");  
	strcpy(sDate_bgn, cm_to_infdate(sdate1));	/* ��J��_�� */
	strcpy(sDate_end, cm_to_infdate(sdate2));	/* ��J�騴�� */
	
	for(k=0;k<count_db;k++)
	{
    sprintf_s(sTmpstr, sizeof sTmpstr,
			" insert into tb_6331  "
		"		select c.isign, (select nname from officer d where d.iofficer = c.isign),  "
		"		       a.iofficer, a.ipolicy, b.nassured, a.dpolicy, a.dentry  "
		"		  from %s:ply_relation a  "
		"		  join %s:policy b on a.ipolicy = b.ipolicy  "
        " join %s:cm_signatory c on a.ileader = c.isign  "
        "where a.dpolicy >= '%s'  "
        "  and a.dply_close is not null  "
        "  and a.dentry >= '%s'   "
        "  and a.dentry <= '%s'  "
        "  and a.dentry >= c.deffect  "
        "  and ((c.dexpire is null) or (c.dexpire > a.dentry))  "
        "  and c.fsign = 'U' and c.iins_cat = 'C' ",
           list[k].dbname, list[k].dbname, list[k].dbname, 
           sDate_bgn, sDate_bgn, sDate_end);
          
			printf("sTmpstr=[%s]\n",sTmpstr);
		 
			$PREPARE pre_0 FROM $sTmpstr;
			$EXECUTE pre_0;
	 }
		return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car633_build_0()
{
		int rc;
    char    sfilename[81],stitle[1024],stmt[1024];
    
    $WHENEVER SQLERROR GOTO errexit;

		printf("-------- start car633_build_0() --------------------------- \n");  
    strcpy(sfilename,"���I�֫O�H���X��ޱ����Ӫ�[CAR633]");
    strcpy(stitle,"\t�{���N��:CAR633\t���I�֫O�H���X��ޱ����Ӫ�\t\t\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");
    
    strcat(stitle,"\t��J���:");
    strcat(stitle,sdate1);
    strcat(stitle,"��");
    strcat(stitle,sdate2);
    strcat(stitle,"\n\n");

    strcat(stitle,"\t�֫O�H���N��\t�֫O�H���W��\t�g��N��\t�O�渹�X\t�Q�O�I�H�W��\t");
    strcat(stitle,"ñ����\t��J���\t");
    sprintf_s(stmt, sizeof stmt,"select isign, nsign, iofficer, ipolicy, nassured, dpolicy, dentry  "
							     "from tb_6331 where 1=1 order by isign, iofficer, ipolicy ");
  
    rc = unload_file(outputf," ",sfilename,stitle,stmt);
    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}
