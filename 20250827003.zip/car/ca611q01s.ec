/**********************************************************************/
/*                                                                    */
/*   program id   : ca611q01s.ec                                      */
/*   program name : �O�N����@�����Ӹ�ƪ�                          */
/*   date written : 2002/01/30                                        */
/*   date modify  : 2002/04/10 �W�[�����C��H�W�B���t�����O�T��O   */
/*   author       : Jessie                                            */
/*   files        : ply_relation        i                             */
/*                  policy              i                             */
/*                  ext_policy          i                             */
/*                  ao_plyedr_prem      io                            */
/*   checked for ����100�~�M��                                        */
/**********************************************************************/
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
#define False                 0
#include "safeclib.h"
/*--------------------------------------------------------------------*/
$char dbgn1[11], dend1[11], dbgn2[11], dend2[11];
$char bgn_opt[2],ao_opt[2];
$char iofficer_N[11],dply_begin_N[11],iquota[7];
$char itag[CA_TAG_NUM],iagent[2],icar_type[3],dpolicy[11];
$char ipolicy[21],iofficer[11],dply_begin[11],ibrand[09],nbrand[31];
$char ilast_ply[21],ibig_sales[11],nbig_sales[11],ipro_year[5];
$char ncar_type[11],nquota[13],nofficer[11],dply_end[11];
$char agent_str[61],iply1[21],iply2[21];
$long dpolicy_long = 0,dply_end_long = 0;

$int    opt,opt_u;
$double mprem = 0,mdisc = 0,pcomm = 0;
$long   pdisc,mcomm;

DBinfo  *list;
int     count_db, i;

char  msgbuf[100];

$char DBName[5], iForm_Tp[3];
$char full_dbname[20];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1];
char  outputf[N_FILE+1], userid[11];

$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;

int  max_cnt = 0;

long car611_build();
long car611_body();
void car611_putbody();
void car611_print();
void car611_title();
static char *get_car_full_db();
/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
   int rc;
   batchinit();
   strcpy(DBName,    isNULLstr(argv[1]));
   strcpy(userid,    isNULLstr(argv[2]));
   strcpy(dbgn2,     isNULLstr(argv[3]));
   strcpy(dend2,     isNULLstr(argv[4]));
   strcpy(bgn_opt,   isNULLstr(argv[5]));
   strcpy(ao_opt,    isNULLstr(argv[6]));
   strcpy(agent_str,           argv[7] );
   strcpy(outputf,   isNULLstr(argv[8]));
   strcpy(dbgn1, cm_to_infdate(dbgn2));
   strcpy(dend1, cm_to_infdate(dend2));
   
   pcomm = 0.05;
   opt   = atoi(bgn_opt);
   opt_u = atoi(ao_opt);
   
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }
   rc = car611_build();
   if ( rc != M_CM_OK)
        return rc;
}
/*--------------------------------------------------------------------*/
long car611_build()
{
$char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];
int    rc,i,k;

   $whenever sqlerror goto errexit;

   $select nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      into $TitleFmt, $BodyFmt,  $StartRow,  $TitleRow,  $ItemRow,
           $TotColumn, $PgLine, $Width, $iForm_Tp
      from Form
     where ksys_grp = "CA" AND kPgmID = 611;   

   strcpy(TitleFmt,rtrim(TitleFmt));
   sprintf_s(TitleFile, sizeof TitleFile,"%s.ti",outputf);
   strcpy(BodyFmt, rtrim(BodyFmt));
   sprintf_s(BodyFile, sizeof BodyFile, "%s.bd",outputf);

   rgu_init_report(TitleFmt,TitleFile);
   car611_title();
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);
   rc = car611_body();
   if (rc != M_CM_OK)
      goto errexit;
   rgu_finish_report();

   if ((rc=save_form_info(F_BLK0, "CA", 611, userid, iForm_Tp, max_cnt,
      outputf))<0) {
      strcpy(msgbuf,"save_form_info failed");
      goto errexit;
   }
   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;  
}

/*--------------------------------------------------------------------*/
long car611_body()
{
$char   stmt[2048],st[2048],stmt1[1024];
$char   sTmt_buf[120];
$int    rc;

   $whenever sqlerror goto errexit;
   
   car611_putbody();

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   if (opt_u)
       $begin work;

   for (i=0;i<count_db;i++) {
      sprintf_s(stmt, sizeof stmt,
            "select a.ipolicy,ilast_ply,iofficer,dply_begin,itag,  "
                     "mdmg_prem + mlia_prem,mdmg_discount+mlia_discount,  "
                     "ibrand,icar_type,iquota[1,4] || '00',dpolicy,dpolicy  "
                "from %s:ply_relation a,%s:policy b  "
              "where iofficer[1] not between 'A' and 'P'  "
                 "and fcard_class = '2'  "
                 "and fedr_class != '1'  "
                 "and dply_close is not null  "
                 "and (ilast_ply != ' '  and ilast_ply is not null)  "
                 "and dpolicy >= ?  "
                 "and dpolicy <= ?  "
                 "and a.ipolicy = b.ipolicy  "
            "order by a.ipolicy ",list[i].dbname,list[i].dbname);
      
      $prepare preA from   $stmt;
      $declare curA cursor for preA;
      $open    curA using  $dbgn1,$dend1;
      
      while(1) {
         $fetch curA into $ipolicy,$ilast_ply,$iofficer_N,$dply_begin_N,
                          $itag,$mprem,$mdisc,$ibrand,$icar_type,$iquota,
                          $dpolicy_long,$dpolicy;
     
         if(SQLCODE == SQLNOTFOUND) break;
         if (mprem == 0) continue;
   
         printf("ipolicy[%s]ilast_ply[%s]\n",ipolicy,ilast_ply);
         strcpy(full_dbname,get_car_full_db(ilast_ply));
      
         sprintf_s(st, sizeof st,
                 "select a.iofficer,dply_begin,ibig_sales,c.nname,  "
                         "dply_end,dply_end  "
                    "from %s:ply_relation a,%s:policy b,officer c  "
                   "where a.ipolicy = ?  "
                     "and a.iofficer[1] in (%s)  "
                     "and a.ipolicy = b.ipolicy  "
                     "and a.iofficer = c.iofficer",
                         full_dbname,full_dbname,agent_str);
        
         
         $prepare preA_1 from   $st;
         $declare curA_1 cursor for preA_1;
         $open    curA_1 using $ilast_ply;
         $fetch   curA_1 into   $iofficer,$dply_begin,$ibig_sales,
                                $nofficer,$dply_end,$dply_end_long;
         
         if (SQLCODE == SQLNOTFOUND) {
            $CLOSE curA_1;
            continue;
         }
         $close curA_1;
         $free  curA_1;

         if (opt==1)
            if (strcmp(dply_begin_N,dply_end)!=0) continue;
         if (opt==2)
            if (strcmp(dply_begin_N,dply_end)==0) continue;
         if (opt==3)
            if ((dply_end_long - dpolicy_long) < 8) continue; 
         if (opt==4) {
            if ((dply_end_long - dpolicy_long) < 8) continue; 
            $select ipolicy
               from ext_policy
              where ipolicy = $ipolicy
                and irenew = '2'
                and iofficer[1] not in ('A','E'); 
            if (SQLCODE!=SQLNOTFOUND) continue;
         }

         if (mdisc == 0)
            pdisc = 0;
         else if (mprem != 0)
            pdisc = mdisc / mprem * 100 + 0.5;

         mcomm = mprem * pcomm + 0.5;

         strncpy(iagent,iofficer,1);

         printf("iofficer[%s]\n",iofficer);
         $declare cur_t1 cursor for
           select nbrand,ipro_year
             into $nbrand,$ipro_year
             from ca_car_model
            where ibrand = $ibrand
            order by ipro_year desc;
         $open  cur_t1;
         $fetch cur_t1;
         $close cur_t1;
         $free  cur_t1;

         $select ncode into $ncar_type
            from car_type
           where fclass = '1'
             and icode = $icar_type;
         $select nbranch into $nquota
            from sa_branch_type
           where ibranch = $iquota; 
         $select nname[1,10] into $nbig_sales
            from ca_big_office
           where fclass = '2'
             and ibig_comp = $ibig_sales;
         if (SQLCODE==SQLNOTFOUND)
            strcpy(nbig_sales," ");

         car611_print();

         if (opt_u) {
            if (strlen(trim(ipolicy))>13) {
               strncpy(iply1,ipolicy,13);
               strncpy(iply2,ipolicy+13,7);
            }
            else {
               strcpy(iply1,ipolicy);
               strcpy(iply2," ");
            }
            printf("iply1[%s]iply2[%s]\n",iply1,iply2);
            sprintf_s(stmt1, sizeof stmt1,
                    "update %s:ao_plyedr_prem set bn_flag = 'Y'  "
                    "  where ipolicy1 = ? and ipolicy2 = ? ",
                     list[i].dbname); 
            $prepare pre_ao from $stmt1;
            $execute pre_ao using $iply1, $iply2;
         }
      }
      $close  curA;
      $free   curA;
  }

  if (opt_u)
     $commit work;

  return M_CM_OK;

errexit:
   sqlfatal();
   if (opt_u) $rollback work;
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
}

/*--------------------------------------------------------------------*/
void car611_title()
{
   rgu_put_head_string(1, dbgn1);
   rgu_put_head_string(1, dend1);
   rgu_put_head_string(1, cm_get_sysd());
   rgu_put_head();
}
/*--------------------------------------------------------------------*/
void car611_putbody()

{

   rgu_put_body_string(1, dbgn1, 1);
   rgu_put_body_string(1, dend1, 1);
   rgu_put_body_string(1, cm_get_sysd(), 1);

   rgu_put_body(1);
   rgu_put_body(2);
   
}
/*--------------------------------------------------------------------*/
void car611_print()
{
char  str[20];
   switch (iagent[0]) {
      case 'A':
          rgu_put_body_string(3,"�ζ�",1);
          break;
      case 'B':
          rgu_put_body_string(3,"����",1);
          break;
      case 'C':
          rgu_put_body_string(3,"���q",1);
          break;
      case 'D':
          rgu_put_body_string(3,"�ؤ�",1);
          break;
      case 'E':
          rgu_put_body_string(3,"�ζ�",1);
          break;
      case 'F':
          rgu_put_body_string(3,"�֯S",1);
          break;
      case 'G':
          rgu_put_body_string(3,"�֯S",1);
          break;
      case 'H':
          rgu_put_body_string(3,"���h",1);
          break;
      case 'J':
          rgu_put_body_string(3,"���q(�s)",1);
          break;
      case 'K':
          rgu_put_body_string(3,"�ίq",1);
          break;
   }

   rgu_put_body_string(3, iofficer    , 1);
   rgu_put_body_string(3, nofficer    , 1);
   rgu_put_body_string(3, ibig_sales  , 1);
   rgu_put_body_string(3, nbig_sales  , 1);
   rgu_put_body_string(3, ilast_ply   , 1);
   rgu_put_body_string(3, dply_begin  , 1);
   rgu_put_body_string(3, ipolicy     , 1);
   rfmtlong(pdisc, "--&",  str);
   rgu_put_body_string(3, str         , 1);
   rgu_put_body_string(3, iofficer_N  , 1);
   rgu_put_body_string(3, dply_begin_N, 1);
   rgu_put_body_string(3, itag        , 1);
   rfmtdouble(mprem, "-----------&",  str);
   rgu_put_body_string(3, str         , 1);
   rfmtlong(mcomm, "-----------&",  str);
   rgu_put_body_string(3, str         , 1);
   rgu_put_body_string(3, ibrand      , 1);
   rgu_put_body_string(3, nbrand      , 1);
   rgu_put_body_string(3, ncar_type   , 1);
   rgu_put_body_string(3, nquota      , 1);
   rgu_put_body_string(3, dpolicy     , 1);
   rgu_put_body(3);
   max_cnt++;
}
/*---------------------------------------------------------end program*/
