/************************************************/
/*   PROGRAM : ca850q01s.ec                     */
/*   DATE    : 110.10.26                        */
/*   NOTE    : ���׵��׸��v��������             */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
$include datetime.h;
#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"

$char DBName[05], outputf[N_FILE+1];
$char option[2];
$char ibranch[3];
$char  userid[11];
DBinfo  *list;
int     count_db;


$char sBgnDate_e[11], sEndDate_e[11], sBgnDate[11], sEndDate[11], sArea[6];
$char sBasicDate[11], sBasicDate_e[11], sFwork[2];
$long lBgnDate, lEndDate;

long car850_build();
void car850_title();
long car850_body();
long car850_print();

/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
    int rc;
    
    batchinit();
    strcpy(DBName   ,  isNULLstr(argv[1]));
    strcpy(userid   ,  isNULLstr(argv[2]));
    strcpy(option   ,  isNULLstr(argv[3]));
    strcpy(ibranch  ,  isNULLstr(argv[4]));
    strcpy(sBgnDate ,  isNULLstr(argv[5]));  
    strcpy(sEndDate ,  isNULLstr(argv[6])); 
    strcpy(outputf  ,  isNULLstr(argv[7]));
    
    strcpy(sBgnDate_e, cm_to_infdate(sBgnDate));
    strcpy(sEndDate_e, cm_to_infdate(sEndDate));

    rc=car850_get_db();
    if (rc!=M_CM_OK)
        return rc;
   
    rc = car850_build();
    if (rc != M_CM_OK)
        return rc;

    return M_CM_OK;
   
errexit:
    printf("main :SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}

/*--------------------------------------------------------------------*/

long car850_build()
{
    int    rc;
    
    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;

    if (option[0] == '1')
    {
       rc = car850_body1();
       if (rc != M_CM_OK)
           return rc;

       rc = car850_print1();
       if (rc != M_CM_OK)
           return rc;
    }


    if (option[0] == '2')
    {
       rc = car850_body2();
       if (rc != M_CM_OK)
           return rc;

       rc = car850_print2();
       if (rc != M_CM_OK)
           return rc;
    }


    if (option[0] == '3')
    {
       rc = car850_body3();
       if (rc != M_CM_OK)
           return rc;

       rc = car850_print3();
       if (rc != M_CM_OK)
           return rc;
    }
          
   return M_CM_OK;

errexit:
   EWRITE(userid,rc,sqlca.sqlerrm);
   return SQLCODE;  
}

long car850_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

long car850_body1()
{
    long rc;
    int k;
    $char stmt[2200];


    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;

    $create temp table car850_temp1
     (
       nbranch00     char(30),
       nworkplace    char(30),
       nbranch       char(60),
       iclaim        char(20),
       dclaim        date,
       adjustment    char(10),
       nadjust       char(10),
       dappraisal    date
     ) with no log;            

    sprintf_s(stmt,2200,
     "insert into car850_temp1  \
       select (select nbranch from sa_branch_type where ibranch = c.iquota[1,4] || '00') as nbranch00,   \
              (select nchi_full from branch where ibranch = b.iapp_unit) as nworkplace,                  \
              d.nbranch,       \
              a.iclaim,        \
              a.dclaim,        \
              a.adjustment,    \
              c.nname,         \
              (select min(dappraisal) from claim_app_dtl_h where iclaim1 = a.iclaim) as dappraisal       \
         from ca_clm_process a, cm_clm_adjuster b, officer c, sa_branch_type d   \
        where a.adjustment  =  b.empl_no   \
          and a.dclaim between ? and ?     \
          and b.iapp_unit   matches  ?     \
          and b.empl_no     =  c.iofficer  \
          and c.iquota      =  d.ibranch   \
          and a.iclaim[6] not in ('S','T','W') ");
    
    $prepare pre1 from $stmt;
    $execute pre1 using $sBgnDate_e, $sEndDate_e, $ibranch;


    return M_CM_OK;
        
errexit:
   printf("car850_body ==> SQLCODE:[%ld][%s] \n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   printf("   end EWRITE \n");
   return SQLCODE;
}

long car850_body2()
{
    long rc;
    int k;
    $char stmt[2200];

    sprintf_s(stmt,2200,
     " select (select nbranch from sa_branch_type where ibranch = c.iquota[1,4] || '00') as nbranch00,   \
              (select nchi_full from branch where ibranch = b.iapp_unit) as nworkplace,                  \
              d.nbranch,           \
              a.dtrans,            \
              a.iclaim,            \
              (select nname from officer where iofficer = a.iadjuster_old) as nnameold,     \
              a.iadjuster_old,     \
              c.nname,             \
              a.iadjuster,         \
              a.ireason            \
         from adj_transfer a, cm_clm_adjuster b, officer c, sa_branch_type d                \
        where a.iadjuster   =   b.empl_no              \
          and a.iadjuster   =   c.iofficer             \
          and c.iquota      =   d.ibranch              \
          and a.iadjuster  !=   a.iadjuster_old        \
          and a.dtrans between ? and ?                 \
          and b.iapp_unit   matches ?                  \
         into temp car850_temp2 with no log ");

     $prepare body2a from $stmt;
     $execute body2a using $sBgnDate_e, $sEndDate_e, $ibranch;

    return M_CM_OK;
        
errexit:
   printf("car850_body ==> SQLCODE:[%ld][%s] \n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   printf("   end EWRITE \n");
   return SQLCODE;
}

long car850_body3()
{
    long rc;
    int i,j,k;
    $char stmt[2200];
    $char iclaim1[21];
    $long dappraisal;
    $char ibranch_in[3];
    $char iadjuster[11];
    $char instbname[20];

    $create temp table car850_adj
    (
        iclaim        char(20),
        iadjuster     char(10)
    )with no log;

    sprintf_s(stmt,2200,
     " SELECT iclaim1, dappraisal, count(*) AS cc, sum(CAST(fdecide AS smallint)) AS ss    \
         FROM claim_app_dtl_h                         \
        WHERE isys_source = 'CAR'                     \
          AND insure_type = 'C'                       \
          AND iclaim1[6] NOT IN ('S','T','W')         \
          AND iclaim1 IN (SELECT iclaim1              \
                            FROM claim_stl_dtl y      \
                           WHERE y.iclaim1 = claim_app_dtl_h.iclaim1    \
                             AND y.dgroup BETWEEN ? AND ?      \
                             AND y.insure_type = 'C'           \
                             AND y.isys_source = 'CAR'         \
                             AND y.iclaim1[6] NOT IN ('S','T','W'))     \
        GROUP BY 1,2     \
       HAVING sum(CAST(fdecide AS smallint))/count(*) = 1      \
         INTO temp app120 WITH NO log");

     $prepare body3a from $stmt;
     $execute body3a using $sBgnDate_e, $sEndDate_e;

    sprintf_s(stmt,2200,
     " SELECT iclaim1, min(dappraisal) AS dappraisal    \
         FROM app120         \
        GROUP BY 1           \
         INTO temp app220 WITH no log");

     $prepare body3b from $stmt;
     $execute body3b;

   for (i=0;i<count_db;i++)
   {
       for(j=1;j<=2;j++)
       {
           if (j == 1) strcpy(instbname,"stl_ins_type");
           if (j == 2) strcpy(instbname,"ca_stl_victim");

            sprintf_s(stmt,2200,
             " insert into car850_adj                                                   \
                select a.iclaim1, min(c.iadjuster) as iadjuster                         \
                  from app220 a, ca_clm_process b, %s:settlement c, %s:%s d             \
                 where a.iclaim1     = b.iclaim          \
                   and a.iclaim1     = c.iclaim          \
                   and c.iclaim      = d.iclaim          \
                   and c.fstl        = d.fstl            \
                   and c.iclose_type = d.iclose_type     \
                   and a.dappraisal  = d.dgroup          \
                   and a.dappraisal  between ? and ?     \
                   and b.ibranch_in  = '%s'              \
                 group by 1 ", list[i].dbname, list[i].dbname, instbname, list[i].dbbranch);
 
             printf("stmt[%s]\n",stmt);

            $prepare getfirst from $stmt;
            $execute getfirst using $sBgnDate_e, $sEndDate_e;
       }           
   } 

    sprintf_s(stmt,2200,
     " SELECT a.iclaim1, a.dappraisal, c.iofficer, c.nname,    \
       (SELECT nbranch FROM sa_branch_type x WHERE x.ibranch = c.iquota) AS nbranch,    \
       (SELECT nchi_full FROM branch WHERE ibranch = d.iapp_unit) AS nplace,    \
       (SELECT iupcomp FROM branch WHERE ibranch = d.iapp_unit) AS iupcomp,     \
       (SELECT sum(msettle-mfee) from claim_stl_dtl where iclaim1 = a.iclaim1 and fstl = '1' and dgroup <= '%s') as msettle,   \
       case when c.dexpire is null or c.dexpire > '%s' then 'Y' else 'N' end  as iexpire   \
         FROM app220 a, ca_clm_process b, officer c, cm_clm_adjuster d, car850_adj e    \
        WHERE a.iclaim1    = b.iclaim      \
          AND a.iclaim1    = e.iclaim      \
          AND e.iadjuster  = d.empl_no     \
          AND e.iadjuster  = c.iofficer    \
          AND a.dappraisal between ? and ? \
          AND d.iapp_unit  matches ?       \
         INTO temp car850_temp3 WITH NO LOG ", sEndDate_e, sEndDate_e);

     printf("stmt[%s]\n",stmt);

     $prepare body3c from $stmt;
     $execute body3c using $sBgnDate_e, $sEndDate_e, $ibranch;

    return M_CM_OK;
        
errexit:
   printf("car850_body ==> SQLCODE:[%ld][%s] \n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   printf("   end EWRITE \n");
   return SQLCODE;
}

long car850_print3()
{
   $char sfilename[200];
   $char stitle[1000];
   $char ssql[1000];
   $char sErrmsg[100];
   $int  rc;

   $WHENEVER ERROR goto errexit;
   $SET LOCK MODE TO WAIT;

   strcpy(sfilename,"���ץ�Ʋέp��");
   printf("sfilename[%s]\n",sfilename);

   strcpy(stitle, sfilename);
   printf("stitle[%s]\n",stitle);
   strcat(stitle, "\n\t");
   strcat(stitle, "���פ���G ");
   strcat(stitle, sBgnDate_e);
   strcat(stitle, " ~ ");
   strcat(stitle, sEndDate_e);
   strcat(stitle, "\n\t�׸�\t�Ĥ@�����פw�M���\t���s\t�m�W\t���\t�u�@�a\t�����q\t�`�p�ߴڪ��B\t�O�_�b¾\t");

   printf("stitle[%s]\n",stitle);

   sprintf_s(ssql,1000,
    " select * from car850_temp3 ");

   printf("ssql[%s]\n",ssql);

   rc = unload_file(outputf,"",sfilename,stitle,ssql);

   if (rc != SUCCESS)
   {
       if (rc == 3501)
       {
          sprintf_s(sErrmsg,100," ��J���^������䤣���� ",sfilename);
       }
       else
       {
          sprintf_s(sErrmsg,100," %s �ɮ׵L�k���� ",sfilename);
       }

       EWRITE(userid, rc , sErrmsg);
       exit(1);
   }
   
   return M_CM_OK;

errexit:
  printf("SQL=[%d], sqlca.sqlerrm[%s]\n", SQLCODE, sqlca.sqlerrm);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  exit(1);
}

long car850_print2()
{
   $char sfilename[200];
   $char stitle[1000];
   $char ssql[1000];
   $char sErrmsg[100];
   $int  rc;

   $WHENEVER ERROR goto errexit;
   $SET LOCK MODE TO WAIT;

   strcpy(sfilename,"�g���ܧ���Ӫ�");
   printf("sfilename[%s]\n",sfilename);

   strcpy(stitle, sfilename);
   printf("stitle[%s]\n",stitle);
   strcat(stitle, "\n\t");
   strcat(stitle, "�ܧ����G ");
   strcat(stitle, sBgnDate_e);
   strcat(stitle, " ~ ");
   strcat(stitle, sEndDate_e);
   strcat(stitle, "\n\t�z�ߤ���\t�u�@�a\t��O\t���\t�߮׸��X\t��g��m�W\t��g����s\t�s�g��m�W\t�s�g����s\t�ܧ��](1.�g����¾ 2.��L��])\t");

   printf("stitle[%s]\n",stitle);

   sprintf_s(ssql,1000,
    " select * from car850_temp2 ");

   printf("ssql[%s]\n",ssql);

   rc = unload_file(outputf,"",sfilename,stitle,ssql);

   if (rc != SUCCESS)
   {
       if (rc == 3501)
       {
          sprintf_s(sErrmsg,100," ��J���^������䤣���� ",sfilename);
       }
       else
       {
          sprintf_s(sErrmsg,100," %s �ɮ׵L�k���� ",sfilename);
       }

       EWRITE(userid, rc , sErrmsg);
       exit(1);
   }
   
   return M_CM_OK;

errexit:
  printf("SQL=[%d], sqlca.sqlerrm[%s]\n", SQLCODE, sqlca.sqlerrm);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  exit(1);
}

long car850_print1()
{
   $char sfilename[200];
   $char stitle[1000];
   $char ssql[1000];
   $char sErrmsg[100];
   $int  rc;
 
   $WHENEVER ERROR goto errexit;
   $SET LOCK MODE TO WAIT;

   strcpy(sfilename,"���z��Ʋέp��");
   printf("sfilename[%s]\n",sfilename);

   strcpy(stitle, sfilename);
   printf("stitle[%s]\n",stitle);
   strcat(stitle, "\n\t");
   strcat(stitle, "���z����G ");
   strcat(stitle, sBgnDate_e);
   strcat(stitle, " ~ ");
   strcat(stitle, sEndDate_e);
   strcat(stitle, "\n\t�z�ߤ���\t�u�@�a\t��O\t�׸�\t���z���\t���s\t�z�ߤH��\t�Ĥ@���w���ɶ�\t");

   printf("stitle[%s]\n",stitle);

   sprintf_s(ssql,1000,
    " select * from car850_temp1 ");

   printf("ssql[%s]\n",ssql);

   rc = unload_file(outputf,"",sfilename,stitle,ssql);

   if (rc != SUCCESS)
   {
       if (rc == 3501)
       {
          sprintf_s(sErrmsg,100," ��J���^������䤣���� ",sfilename);
       }
       else
       {
          sprintf_s(sErrmsg,100," %s �ɮ׵L�k���� ",sfilename);
       }

       EWRITE(userid, rc , sErrmsg);
       exit(1);
   }
   
   return M_CM_OK;

errexit:
  printf("SQL=[%d], sqlca.sqlerrm[%s]\n", SQLCODE, sqlca.sqlerrm);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  exit(1);
    
}
