/**********************************************************************/
/*   program id   : ca745q01s.ec                                      */
/*   program name : �@�~�@�ά����ɳ���                                 */
/*   date written : 2025/02/27                                        */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <decimal.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "globdata.h"
#include "safeclib.h"
#include "carmsgs.h"

int   count_db; 
$char dbgn[11], dbgn2[11], dbgn3[16], dbgn4[20];
$char dend[11], dend2[11], dend3[16], dend4[20];
$char ipgid[9];
$char ilog_number1[21];
$char outputf[21];
$char userid[11];
$char DBName[05];
$char msgbuf[128];
int   max_count;
DBinfo *list;

char *get_car_full_db();
/*********************************************************************/
main(argc, argv)
int argc;
char **argv;
{
    printf("131775 car745 start.\n");
    int rc;

    batchinit();
    strcpy(DBName,         isNULLstr(argv[1]));
    strcpy(userid,         isNULLstr(argv[2]));
    strcpy(dbgn,           isNULLstr(argv[3]));
    strcpy(dend,           isNULLstr(argv[4]));
    strcpy(ipgid,          isNULLstr(argv[5]));
    strcpy(ilog_number1,   isNULLstr(argv[6]));
    strcpy(outputf,        isNULLstr(argv[7]));

    strcpy(dbgn2, cm_to_infdate(dbgn));
    strcpy(dbgn3,cm_from_infdate_100(dbgn2));	/* CYY/MM/DD */
    strcat(dbgn3,"/00:00");		            	/* CYY/MM/DD/hh:mm */
    strcpy(dbgn4,cm_sysd_edatetime(dbgn3));	    /* YYYY-MM-DD hh:mm */
    strcat(dbgn4,":00");				        /* YYYY-MM-DD hh:mm:ss */

    strcpy(dend2, cm_to_infdate(dend));
    strcpy(dend3,cm_from_infdate_100(dend2));	/* CYY/MM/DD */
    strcat(dend3,"/23:59");			            /* CYY/MM/DD/hh:mm */
    strcpy(dend4,cm_sysd_edatetime(dend3));	    /* YYYY-MM-DD hh:mm */
    strcat(dend4,":59");				        /* YYYY-MM-DD hh:mm:ss */

    printf("131775 dbgn4=%s, dend4=%s\n", dbgn4, dend4);

    rc = ca_log_get_db();
    if (rc != M_CM_OK)
        return rc;

    rc = ca_log_build();
    if (rc != M_CM_OK)
        return rc;

}
/*----------------------------------------------------------------------------*/
long ca_log_get_db()
{
    $whenever sqlerror goto errexit;

    if (db_select(DBName) == FALSE) {
        EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
        return M_CM_DB_NOTOPEN;
    }

    if ((list = get_db_list(&count_db, DBName)) == (char *) 0) {
        if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
            return M_CM_NOT_DBLIST;
    }
    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long ca_log_build()
{
    int rc;
    char sfilename[256], stitle[2048], stmt[6000];
    $WHENEVER SQLERROR GOTO errexit;

    strcpy(sfilename, "�@�~�@�ά����ɳ���[car745]");
    sprintf_s(stitle, sizeof stitle, "�C�L�϶�:%s~%s\t", dbgn, dend);
    strcat(stitle, "\n");   
    strcat(stitle, "\t�{���N��\t�@�~���O\tlog�s��1\tlog�s��2\t�@�~���e\t��s�H��\t��s�ɶ�\t");

    if (strchr(ilog_number1, '*') != NULL) 
    {
        /* ilog_number1 �]�t "*"�A�O�d������� */
        sprintf_s(stmt, sizeof stmt, 
                  "SELECT ipgid, itype, ilog_number1, ilog_number2, ncontent, nname, TO_CHAR(a.dupdate, '%%Y/%%m/%%d %%H:%%M:%%S') "
                  " FROM ca_log a LEFT JOIN officer b ON a.iupdate = iofficer "
                  "WHERE a.dupdate BETWEEN '%s' AND '%s' "
                  "  AND ipgid = '%s' "
                  "  AND ilog_number1 MATCHES '%s'", 
                  dbgn4, dend4, ipgid, ilog_number1);
    } 
    else 
    {
        /* ilog_number1 ���]�t "*"�A����������� */
        sprintf_s(stmt, sizeof stmt, 
                  "SELECT ipgid, itype, ilog_number1, ilog_number2, ncontent, nname, TO_CHAR(a.dupdate, '%%Y/%%m/%%d %%H:%%M:%%S') "
                  " FROM ca_log a LEFT JOIN officer b ON a.iupdate = iofficer "
                  "WHERE ipgid = '%s' "
                  "  AND ilog_number1 = '%s'", 
                  ipgid, ilog_number1);
    }
    printf("stmt[%s] \n", stmt);
    rc = unload_file(outputf, " ", sfilename, stitle, stmt);

    if (rc != SUCCESS)
    {
        sprintf_s(msgbuf, sizeof msgbuf, " %s �ɮ׵L�k���� ", sfilename);
        EWRITE(userid, rc, msgbuf);
        return rc;
    }

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;

}
/*----------------------------------------------------------------------------*/