/****************************************************/
/*                                                  */
/*   PROGRAM      : ncar012.ec  BY Peter            */
/*   DATE WRITTEN : 1999/07/20                      */
/*   DATE MODIFY  : 2001/06/18                      */
/*                                                  */
/*   �l���v��ƦX��                                 */
/*   files        : ca_loss_info_wk     io          */
/*                                                  */
/****************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "api_xsrv.h"
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"

#include "commsgs.h"
$include sqlca;
$include datetime.h;
#include "glsmsgs.h"
#include "gls_array.h"
#include "gls_const.h"
$include sqltypes.h;
#include "sqlfatal.h"

/*-----------------------------------------------------------------------*/
char     sApHome[30];
$char    DBname[42];
$char    fname[21];
char     filename[30];
$char    s[10],s1[10],s2[10],s3[10],sysTm[11];
$char    server[21],dbname[21],connect_db[42];
$char    ibrand[7],iins_type[7],iofficer[11];
$char    datebgn[11],dateend[11],dhist_bgn[11];
$char    irule[2],imethod[2];

$double  qprem,mprem,qfull,mfull,qclaim,mstl,mend_outstl,mbgn_outstl;
int      flen,fg=0;

FILE  *fp;
/*-----------------------------------------------------------------------*/
long ncar012(dbname , Irule , Imethod , Datebgn , Dateend , Dhist_bgn )
char *Irule;
char *Imethod;
char *Datebgn;
char *Dateend;
char *Dhist_bgn;
char *dbname;
{
   long  rtncode;
   long  sysdt;
   EXEC SQL double rowid,ccnt;

   time_t lt;

   strcpy(irule,Irule);
   strcpy(imethod,Imethod);
   strcpy(datebgn,Datebgn);
   strcpy(dateend,Dateend);
   strcpy(DBname,dbname);

   printf("DBname[%s],irule[%s],imethod[%s]\n",
           DBname  ,  irule  ,  imethod);

   if (db_select(DBname) == False)
   {
        printf("M_CM_DB_NOTOPEN\n");
        exit(0);
   }
   printf("DBname:[%s]\n",DBname);

   EXEC SQL WHENEVER SQLERROR GOTO errexit;

   /***** �l���v�u�@�� *****/
   printf("\n*****Begin Merge Data*****\n\n");

   /***** change officer *****/
   lt = time(NULL);
   printf("####### Begin change officer start time===>");
   printf(ctime(&lt));
   printf("\n");

   rtncode = change_officer();
   if (rtncode<0)
      goto errexit;

   rtncode = change_officer_prj();
   if (rtncode<0)
      goto errexit;      

   lt = time(NULL);
   printf("####### END change officer end time===>");
   printf(ctime(&lt));
   printf("\n");

   /***** �t�P��������W���� *****/
   lt = time(NULL);
   printf("####### Begin merge_car_model start time===>");
   printf(ctime(&lt));
   printf("\n");

   rtncode = merge_car_model();
   if (rtncode<0)
       goto errexit;

   lt = time(NULL);
   printf("####### END merge_car_model end time===>");
   printf(ctime(&lt));
   printf("\n");

   /***** �g��H�W���� *****/
   lt = time(NULL);
   printf("####### Begin merge officer name start time===>");
   printf(ctime(&lt));
   printf("\n");

   rtncode = merge_officer_name();
   if (rtncode<0)
      goto errexit;

   lt = time(NULL);
   printf("####### END merge officer name end time===>");
   printf(ctime(&lt));
   printf("\n");

   /***** �~�Z�k�ݦW���� *****/
   lt = time(NULL);
   printf("####### Begin merge quota name start time===>");
   printf(ctime(&lt));
   printf("\n");

   rtncode = merge_quota_name();
   if (rtncode<0)
      goto errexit;

   lt = time(NULL);
   printf("####### END merge quota name end time===>");
   printf(ctime(&lt));
   printf("\n");

   printf("irule[%s]\n",irule);
   lt = time(NULL);
   printf("\n\nEND OF ncar012 ===>");
   printf(ctime(&lt));
   printf("\n");

   return M_CM_OK;

errexit:
   return rtncode;
}

/*********************************************************/
long change_officer()
{
   int    rtn;
   $char  tmp_officer[11],ori_officer[11];

   $char    ipolicy_13[4], iquota[7], iofficer[11], icar_flag[2], ibrand[7];
   $char    icar_type[3],  iins_type[7], iresource[3];
   $long    mcover, ideduct;
   $double  qprem, mprem, mpure_prem, qfull, mfull, mfull_pure;
   $double  mprem_disc, mfull_disc, qclaim, qend_outstl, qbgn_outstl;
   $double  mstl, mend_outstl, mbgn_outstl;
   $char    irule[2],dbgn[11],dend[11],dcalc[11];

   EXEC SQL whenever sqlerror goto errexit;

   /* �g��H G->F */

   $SELECT irule, dbgn, dend, dcalc,
           ipolicy_13, iquota, iofficer, icar_flag, ibrand,
           icar_type,  iins_type, iresource, mcover, ideduct,
           sum(qprem) qprem, sum(mprem) mprem, sum(mpure_prem) mpure_prem, 
           sum(qfull) qfull, sum(mfull) mfull, sum(mfull_pure) mfull_pure, 
           sum(mprem_disc) mprem_disc, sum(mfull_disc) mfull_disc, sum(qclaim) qclaim, 
           sum(qend_outstl) qend_outstl, sum(qbgn_outstl) qbgn_outstl, sum(mstl) mstl, 
           sum(mend_outstl) mend_outstl, sum(mbgn_outstl) mbgn_outstl
      FROM ca_loss_info_wk
     WHERE iofficer[1] = 'G'
     GROUP BY irule, dbgn, dend, dcalc,
              ipolicy_13, iquota, iofficer, icar_flag, ibrand,
              icar_type,  iins_type, iresource, mcover, ideduct
      INTO TEMP gofficer_temp;

   $DECLARE chg_g_cur CURSOR FOR
     SELECT irule, dbgn, dend, dcalc,
            ipolicy_13, iquota, iofficer, icar_flag, ibrand,
            icar_type,  iins_type, iresource, mcover, ideduct,
            qprem, mprem, mpure_prem, qfull, mfull, mfull_pure, 
            mprem_disc, mfull_disc, qclaim, qend_outstl, qbgn_outstl,
            mstl, mend_outstl, mbgn_outstl
       FROM gofficer_temp;
   $OPEN chg_g_cur;
   for(;;)
   {
   $FETCH chg_g_cur 
     INTO $irule, $dbgn, $dend, $dcalc,
          $ipolicy_13, $iquota, $iofficer, $icar_flag, $ibrand,
          $icar_type,  $iins_type, $iresource, $mcover, $ideduct,
          $qprem, $mprem, $mpure_prem, $qfull, $mfull, $mfull_pure,
          $mprem_disc, $mfull_disc, $qclaim, $qend_outstl, $qbgn_outstl,
          $mstl, $mend_outstl, $mbgn_outstl;
       if (SQLCODE == SQLNOTFOUND) break;

          ori_officer[0] = '\0';
          tmp_officer[0] = '\0';

          strcpy(tmp_officer,"F");
          strncat(tmp_officer,iofficer+1,4);
          tmp_officer[5]='\0';

          EXEC SQL SELECT iofficer
                     INTO :ori_officer
                     FROM officer
                    WHERE iofficer[1,5] = :tmp_officer;
          printf("iofficer[%s] -> ori_officer[%s]\n",iofficer,ori_officer);
          if (SQLCODE != SQLNOTFOUND) 
          {
              $UPDATE ca_loss_info_wk
                  SET qprem       = qprem       + $qprem      , 
                      mprem       = mprem       + $mprem      ,
                      mpure_prem  = mpure_prem  + $mpure_prem ,
                      qfull       = qfull       + $qfull      ,
                      mfull       = mfull       + $mfull      ,
                      mfull_pure  = mfull_pure  + $mfull_pure ,
                      mprem_disc  = mprem_disc  + $mprem_disc ,
                      mfull_disc  = mfull_disc  + $mfull_disc ,
                      qclaim      = qclaim      + $qclaim     ,
                      qend_outstl = qend_outstl + $qend_outstl,
                      qbgn_outstl = qbgn_outstl + $qbgn_outstl,
                      mstl        = mstl        + $mstl       ,
                      mend_outstl = mend_outstl + $mend_outstl, 
                      mbgn_outstl = mbgn_outstl + $mbgn_outstl
                WHERE irule       = $irule
                  AND dbgn        = $dbgn
                  AND dend        = $dend
                  AND dcalc       = $dcalc
                  AND ipolicy_13  = $ipolicy_13
                  AND iquota      = $iquota
                  AND iofficer    = $ori_officer
                  AND icar_flag   = $icar_flag
                  AND ibrand      = $ibrand
                  AND icar_type   = $icar_type
                  AND iins_type   = $iins_type
                  AND iresource   = $iresource
                  AND mcover      = $mcover
                  AND ideduct     = $ideduct;
                   if (sqlca.sqlerrd[2] == 0)
                   {
                       $INSERT INTO ca_loss_info_wk
                         (irule, dbgn, dend, dcalc,
                          ipolicy_13, iquota, iofficer, icar_flag, ibrand,
                          icar_type,  iins_type, iresource, mcover, ideduct,
                          qprem, mprem, mpure_prem, qfull, mfull, mfull_pure,
                          mprem_disc, mfull_disc, qclaim, qend_outstl, qbgn_outstl,
                          mstl, mend_outstl, mbgn_outstl)
                         VALUES
                         ($irule, $dbgn, $dend, $dcalc,
                          $ipolicy_13, $iquota, $ori_officer, $icar_flag, $ibrand,
                          $icar_type,  $iins_type, $iresource, $mcover, $ideduct,
                          $qprem, $mprem, $mpure_prem, $qfull, $mfull, $mfull_pure,
                          $mprem_disc, $mfull_disc, $qclaim, $qend_outstl, $qbgn_outstl,
                          $mstl, $mend_outstl, $mbgn_outstl);
                   }
              $DELETE FROM ca_loss_info_wk 
                WHERE irule       = $irule
                  AND dbgn        = $dbgn
                  AND dend        = $dend
                  AND dcalc       = $dcalc
                  AND ipolicy_13  = $ipolicy_13
                  AND iquota      = $iquota
                  AND iofficer    = $iofficer
                  AND icar_flag   = $icar_flag
                  AND ibrand      = $ibrand
                  AND icar_type   = $icar_type
                  AND iins_type   = $iins_type
                  AND iresource   = $iresource
                  AND mcover      = $mcover
                  AND ideduct     = $ideduct;
          }
   }
   $CLOSE chg_g_cur;
   $FREE  chg_g_cur;
     
   $DROP TABLE gofficer_temp;
   /* �g��H E02->G02 */

   $SELECT irule, dbgn, dend, dcalc,
           ipolicy_13, iquota, iofficer, icar_flag, ibrand,
           icar_type,  iins_type, iresource, mcover, ideduct,
           sum(qprem) qprem, sum(mprem) mprem, sum(mpure_prem) mpure_prem, 
           sum(qfull) qfull, sum(mfull) mfull, sum(mfull_pure) mfull_pure, 
           sum(mprem_disc) mprem_disc, sum(mfull_disc) mfull_disc, sum(qclaim) qclaim, 
           sum(qend_outstl) qend_outstl, sum(qbgn_outstl) qbgn_outstl, sum(mstl) mstl, 
           sum(mend_outstl) mend_outstl, sum(mbgn_outstl) mbgn_outstl
      FROM ca_loss_info_wk
     WHERE iofficer[1,3] = 'E02'
     GROUP BY irule, dbgn, dend, dcalc,
              ipolicy_13, iquota, iofficer, icar_flag, ibrand,
              icar_type,  iins_type, iresource, mcover, ideduct
      INTO TEMP eofficer_temp;

   $DECLARE chg_e_cur CURSOR FOR
     SELECT irule, dbgn, dend, dcalc,
            ipolicy_13, iquota, iofficer, icar_flag, ibrand,
            icar_type,  iins_type, iresource, mcover, ideduct,
            qprem, mprem, mpure_prem, qfull, mfull, mfull_pure, 
            mprem_disc, mfull_disc, qclaim, qend_outstl, qbgn_outstl,
            mstl, mend_outstl, mbgn_outstl
       FROM eofficer_temp;
   $OPEN chg_e_cur;
   for(;;)
   {
   $FETCH chg_e_cur 
     INTO $irule, $dbgn, $dend, $dcalc,
          $ipolicy_13, $iquota, $iofficer, $icar_flag, $ibrand,
          $icar_type,  $iins_type, $iresource, $mcover, $ideduct,
          $qprem, $mprem, $mpure_prem, $qfull, $mfull, $mfull_pure,
          $mprem_disc, $mfull_disc, $qclaim, $qend_outstl, $qbgn_outstl,
          $mstl, $mend_outstl, $mbgn_outstl;
       if (SQLCODE == SQLNOTFOUND) break;

          ori_officer[0] = '\0';
          tmp_officer[0] = '\0';

          strcpy(tmp_officer,"G");
          strncat(tmp_officer,iofficer+1,4);
          tmp_officer[5]='\0';

          EXEC SQL SELECT iofficer
                     INTO :ori_officer
                     FROM officer
                    WHERE iofficer[1,5] = :tmp_officer;
          printf("iofficer[%s] -> ori_officer[%s]\n",iofficer,ori_officer);
          if (SQLCODE != SQLNOTFOUND) 
          {
              $UPDATE ca_loss_info_wk
                  SET qprem       = qprem       + $qprem      , 
                      mprem       = mprem       + $mprem      ,
                      mpure_prem  = mpure_prem  + $mpure_prem ,
                      qfull       = qfull       + $qfull      ,
                      mfull       = mfull       + $mfull      ,
                      mfull_pure  = mfull_pure  + $mfull_pure ,
                      mprem_disc  = mprem_disc  + $mprem_disc ,
                      mfull_disc  = mfull_disc  + $mfull_disc ,
                      qclaim      = qclaim      + $qclaim     ,
                      qend_outstl = qend_outstl + $qend_outstl,
                      qbgn_outstl = qbgn_outstl + $qbgn_outstl,
                      mstl        = mstl        + $mstl       ,
                      mend_outstl = mend_outstl + $mend_outstl, 
                      mbgn_outstl = mbgn_outstl + $mbgn_outstl
                WHERE irule       = $irule
                  AND dbgn        = $dbgn
                  AND dend        = $dend
                  AND dcalc       = $dcalc
                  AND ipolicy_13  = $ipolicy_13
                  AND iquota      = $iquota
                  AND iofficer    = $ori_officer
                  AND icar_flag   = $icar_flag
                  AND ibrand      = $ibrand
                  AND icar_type   = $icar_type
                  AND iins_type   = $iins_type
                  AND iresource   = $iresource
                  AND mcover      = $mcover
                  AND ideduct     = $ideduct;
                   if (sqlca.sqlerrd[2] == 0)
                   {
                       $INSERT INTO ca_loss_info_wk
                         (irule, dbgn, dend, dcalc,
                          ipolicy_13, iquota, iofficer, icar_flag, ibrand,
                          icar_type,  iins_type, iresource, mcover, ideduct,
                          qprem, mprem, mpure_prem, qfull, mfull, mfull_pure,
                          mprem_disc, mfull_disc, qclaim, qend_outstl, qbgn_outstl,
                          mstl, mend_outstl, mbgn_outstl)
                         VALUES
                         ($irule, $dbgn, $dend, $dcalc,
                          $ipolicy_13, $iquota, $ori_officer, $icar_flag, $ibrand,
                          $icar_type,  $iins_type, $iresource, $mcover, $ideduct,
                          $qprem, $mprem, $mpure_prem, $qfull, $mfull, $mfull_pure,
                          $mprem_disc, $mfull_disc, $qclaim, $qend_outstl, $qbgn_outstl,
                          $mstl, $mend_outstl, $mbgn_outstl);
                   }
              $DELETE FROM ca_loss_info_wk 
                WHERE irule       = $irule
                  AND dbgn        = $dbgn
                  AND dend        = $dend
                  AND dcalc       = $dcalc
                  AND ipolicy_13  = $ipolicy_13
                  AND iquota      = $iquota
                  AND iofficer    = $iofficer
                  AND icar_flag   = $icar_flag
                  AND ibrand      = $ibrand
                  AND icar_type   = $icar_type
                  AND iins_type   = $iins_type
                  AND iresource   = $iresource
                  AND mcover      = $mcover
                  AND ideduct     = $ideduct;
          }
   }
   $CLOSE chg_e_cur;
   $FREE  chg_e_cur;
   $DROP TABLE eofficer_temp;

   rtn=0;
   return rtn;
errexit:
   return SQLCODE;
}

long change_officer_prj()
{
   int    rtn;
   $char  tmp_officer[11],ori_officer[11];

   $char    ipolicy_13[4], iquota[7], iofficer[11], icar_flag[2], ibrand[7];
   $char    icar_type[3],  iins_type[7], iresource[3];
   $char    project[11];
   $long    mcover, ideduct;
   $double  qprem, mprem, mpure_prem, qfull, mfull, mfull_pure;
   $double  mprem_disc, mfull_disc, qclaim, qend_outstl, qbgn_outstl;
   $double  mstl, mend_outstl, mbgn_outstl;
   $double  app_qlia,qlia_qclaim,qlia_qend_outstl,qlia_qbgn_outstl;
   $char    irule[2],dbgn[11],dend[11],dcalc[11];

   EXEC SQL whenever sqlerror goto errexit;

   /* �g��H G->F */

   $SELECT irule, dbgn, dend, dcalc,
           ipolicy_13, iquota, iofficer, icar_flag, ibrand,
           icar_type,  iins_type, iresource, mcover, ideduct, project,
           sum(qprem) qprem, sum(mprem) mprem, sum(mpure_prem) mpure_prem, 
           sum(qfull) qfull, sum(mfull) mfull, sum(mfull_pure) mfull_pure, 
           sum(mprem_disc) mprem_disc, sum(mfull_disc) mfull_disc, sum(qclaim) qclaim, 
           sum(qend_outstl) qend_outstl, sum(qbgn_outstl) qbgn_outstl, sum(mstl) mstl, 
           sum(mend_outstl) mend_outstl, sum(mbgn_outstl) mbgn_outstl,
           sum(app_qlia)    app_qlia   , sum(qlia_qclaim) qlia_qclaim,
           sum(qlia_qend_outstl) qlia_qend_outstl, sum(qlia_qbgn_outstl) qlia_qbgn_outstl
      FROM ca_loss_project
     WHERE iofficer[1] = 'G'
     GROUP BY irule, dbgn, dend, dcalc,
              ipolicy_13, iquota, iofficer, icar_flag, ibrand,
              icar_type,  iins_type, iresource, mcover, ideduct, project
      INTO TEMP gofficer_temp;

   $DECLARE chg_g_cur5 CURSOR FOR
     SELECT irule, dbgn, dend, dcalc,
            ipolicy_13, iquota, iofficer, icar_flag, ibrand,
            icar_type,  iins_type, iresource, mcover, ideduct, project,
            qprem, mprem, mpure_prem, qfull, mfull, mfull_pure, 
            mprem_disc, mfull_disc, qclaim, qend_outstl, qbgn_outstl,
            mstl, mend_outstl, mbgn_outstl, app_qlia, qlia_qclaim, 
            qlia_qend_outstl,qlia_qbgn_outstl
       FROM gofficer_temp;
   $OPEN chg_g_cur5;
   for(;;)
   {
   $FETCH chg_g_cur5 
     INTO $irule, $dbgn, $dend, $dcalc,
          $ipolicy_13, $iquota, $iofficer, $icar_flag, $ibrand,
          $icar_type,  $iins_type, $iresource, $mcover, $ideduct, $project,
          $qprem, $mprem, $mpure_prem, $qfull, $mfull, $mfull_pure,
          $mprem_disc, $mfull_disc, $qclaim, $qend_outstl, $qbgn_outstl,
          $mstl, $mend_outstl, $mbgn_outstl, $app_qlia, $qlia_qclaim, 
          $qlia_qend_outstl, $qlia_qbgn_outstl;
       if (SQLCODE == SQLNOTFOUND) break;

          ori_officer[0] = '\0';
          tmp_officer[0] = '\0';

          strcpy(tmp_officer,"F");
          strncat(tmp_officer,iofficer+1,4);
          tmp_officer[5]='\0';

          EXEC SQL SELECT iofficer
                     INTO :ori_officer
                     FROM officer
                    WHERE iofficer[1,5] = :tmp_officer;
          printf("iofficer[%s] -> ori_officer[%s]\n",iofficer,ori_officer);
          if (SQLCODE != SQLNOTFOUND) 
          {
              $UPDATE ca_loss_project
                  SET qprem       = qprem       + $qprem      , 
                      mprem       = mprem       + $mprem      ,
                      mpure_prem  = mpure_prem  + $mpure_prem ,
                      qfull       = qfull       + $qfull      ,
                      mfull       = mfull       + $mfull      ,
                      mfull_pure  = mfull_pure  + $mfull_pure ,
                      mprem_disc  = mprem_disc  + $mprem_disc ,
                      mfull_disc  = mfull_disc  + $mfull_disc ,
                      qclaim      = qclaim      + $qclaim     ,
                      qend_outstl = qend_outstl + $qend_outstl,
                      qbgn_outstl = qbgn_outstl + $qbgn_outstl,
                      mstl        = mstl        + $mstl       ,
                      mend_outstl = mend_outstl + $mend_outstl, 
                      mbgn_outstl = mbgn_outstl + $mbgn_outstl,
                      app_qlia    = app_qlia    + $app_qlia   ,
                      qlia_qclaim = qlia_qclaim + $qlia_qclaim,
                      qlia_qend_outstl = qlia_qend_outstl + $qlia_qend_outstl,
                      qlia_qbgn_outstl = qlia_qbgn_outstl + $qlia_qbgn_outstl
                WHERE irule       = $irule
                  AND dbgn        = $dbgn
                  AND dend        = $dend
                  AND dcalc       = $dcalc
                  AND ipolicy_13  = $ipolicy_13
                  AND iquota      = $iquota
                  AND iofficer    = $ori_officer
                  AND icar_flag   = $icar_flag
                  AND ibrand      = $ibrand
                  AND icar_type   = $icar_type
                  AND iins_type   = $iins_type
                  AND iresource   = $iresource
                  AND mcover      = $mcover
                  AND ideduct     = $ideduct
                  AND project     = $project;
                   if (sqlca.sqlerrd[2] == 0)
                   {
                       $INSERT INTO ca_loss_project
                         (irule, dbgn, dend, dcalc,
                          ipolicy_13, iquota, iofficer, icar_flag, ibrand,
                          icar_type,  iins_type, iresource, mcover, ideduct, project,
                          qprem, mprem, mpure_prem, qfull, mfull, mfull_pure,
                          mprem_disc, mfull_disc, qclaim, qend_outstl, qbgn_outstl,
                          mstl, mend_outstl, mbgn_outstl, app_qlia, qlia_qclaim, 
                          qlia_qend_outstl,qlia_qbgn_outstl)
                         VALUES
                         ($irule, $dbgn, $dend, $dcalc,
                          $ipolicy_13, $iquota, $ori_officer, $icar_flag, $ibrand,
                          $icar_type,  $iins_type, $iresource, $mcover, $ideduct, $project,
                          $qprem, $mprem, $mpure_prem, $qfull, $mfull, $mfull_pure,
                          $mprem_disc, $mfull_disc, $qclaim, $qend_outstl, $qbgn_outstl,
                          $mstl, $mend_outstl, $mbgn_outstl, $app_qlia, $qlia_qclaim, 
                          $qlia_qend_outstl, $qlia_qbgn_outstl);
                   }
              $DELETE FROM ca_loss_project 
                WHERE irule       = $irule
                  AND dbgn        = $dbgn
                  AND dend        = $dend
                  AND dcalc       = $dcalc
                  AND ipolicy_13  = $ipolicy_13
                  AND iquota      = $iquota
                  AND iofficer    = $iofficer
                  AND icar_flag   = $icar_flag
                  AND ibrand      = $ibrand
                  AND icar_type   = $icar_type
                  AND iins_type   = $iins_type
                  AND iresource   = $iresource
                  AND mcover      = $mcover
                  AND ideduct     = $ideduct
                  AND project     = $project;
          }
   }
   $CLOSE chg_g_cur5;
   $FREE  chg_g_cur5;
     
   $DROP TABLE gofficer_temp;
   /* �g��H E02->G02 */

   $SELECT irule, dbgn, dend, dcalc,
           ipolicy_13, iquota, iofficer, icar_flag, ibrand,
           icar_type,  iins_type, iresource, mcover, ideduct, project,
           sum(qprem) qprem, sum(mprem) mprem, sum(mpure_prem) mpure_prem, 
           sum(qfull) qfull, sum(mfull) mfull, sum(mfull_pure) mfull_pure, 
           sum(mprem_disc) mprem_disc, sum(mfull_disc) mfull_disc, sum(qclaim) qclaim, 
           sum(qend_outstl) qend_outstl, sum(qbgn_outstl) qbgn_outstl, sum(mstl) mstl, 
           sum(mend_outstl) mend_outstl, sum(mbgn_outstl) mbgn_outstl,
           sum(app_qlia)    app_qlia   , sum(qlia_qclaim) qlia_qclaim,
           sum(qlia_qend_outstl) qlia_qend_outstl, sum(qlia_qbgn_outstl) qlia_qbgn_outstl           
      FROM ca_loss_project
     WHERE iofficer[1,3] = 'E02'
     GROUP BY irule, dbgn, dend, dcalc,
              ipolicy_13, iquota, iofficer, icar_flag, ibrand,
              icar_type,  iins_type, iresource, mcover, ideduct, project
      INTO TEMP eofficer_temp;

   $DECLARE chg_e_cur5 CURSOR FOR
     SELECT irule, dbgn, dend, dcalc,
            ipolicy_13, iquota, iofficer, icar_flag, ibrand,
            icar_type,  iins_type, iresource, mcover, ideduct, project,
            qprem, mprem, mpure_prem, qfull, mfull, mfull_pure, 
            mprem_disc, mfull_disc, qclaim, qend_outstl, qbgn_outstl,
            mstl, mend_outstl, mbgn_outstl, app_qlia, qlia_qclaim, 
            qlia_qend_outstl,qlia_qbgn_outstl
       FROM eofficer_temp;
   $OPEN chg_e_cur5;
   for(;;)
   {
   $FETCH chg_e_cur5 
     INTO $irule, $dbgn, $dend, $dcalc,
          $ipolicy_13, $iquota, $iofficer, $icar_flag, $ibrand,
          $icar_type,  $iins_type, $iresource, $mcover, $ideduct, $project,
          $qprem, $mprem, $mpure_prem, $qfull, $mfull, $mfull_pure,
          $mprem_disc, $mfull_disc, $qclaim, $qend_outstl, $qbgn_outstl,
          $mstl, $mend_outstl, $mbgn_outstl, $app_qlia, $qlia_qclaim, 
          $qlia_qend_outstl, $qlia_qbgn_outstl;
       if (SQLCODE == SQLNOTFOUND) break;

          ori_officer[0] = '\0';
          tmp_officer[0] = '\0';

          strcpy(tmp_officer,"G");
          strncat(tmp_officer,iofficer+1,4);
          tmp_officer[5]='\0';

          EXEC SQL SELECT iofficer
                     INTO :ori_officer
                     FROM officer
                    WHERE iofficer[1,5] = :tmp_officer;
          printf("iofficer[%s] -> ori_officer[%s]\n",iofficer,ori_officer);
          if (SQLCODE != SQLNOTFOUND) 
          {
              $UPDATE ca_loss_project
                  SET qprem       = qprem       + $qprem      , 
                      mprem       = mprem       + $mprem      ,
                      mpure_prem  = mpure_prem  + $mpure_prem ,
                      qfull       = qfull       + $qfull      ,
                      mfull       = mfull       + $mfull      ,
                      mfull_pure  = mfull_pure  + $mfull_pure ,
                      mprem_disc  = mprem_disc  + $mprem_disc ,
                      mfull_disc  = mfull_disc  + $mfull_disc ,
                      qclaim      = qclaim      + $qclaim     ,
                      qend_outstl = qend_outstl + $qend_outstl,
                      qbgn_outstl = qbgn_outstl + $qbgn_outstl,
                      mstl        = mstl        + $mstl       ,
                      mend_outstl = mend_outstl + $mend_outstl, 
                      mbgn_outstl = mbgn_outstl + $mbgn_outstl,
                      app_qlia    = app_qlia    + $app_qlia   ,
                      qlia_qclaim = qlia_qclaim + $qlia_qclaim,
                      qlia_qend_outstl = qlia_qend_outstl + $qlia_qend_outstl,
                      qlia_qbgn_outstl = qlia_qbgn_outstl + $qlia_qbgn_outstl                      
                WHERE irule       = $irule
                  AND dbgn        = $dbgn
                  AND dend        = $dend
                  AND dcalc       = $dcalc
                  AND ipolicy_13  = $ipolicy_13
                  AND iquota      = $iquota
                  AND iofficer    = $ori_officer
                  AND icar_flag   = $icar_flag
                  AND ibrand      = $ibrand
                  AND icar_type   = $icar_type
                  AND iins_type   = $iins_type
                  AND iresource   = $iresource
                  AND mcover      = $mcover
                  AND ideduct     = $ideduct
                  AND project     = $project;
                   if (sqlca.sqlerrd[2] == 0)
                   {
                       $INSERT INTO ca_loss_project
                         (irule, dbgn, dend, dcalc,
                          ipolicy_13, iquota, iofficer, icar_flag, ibrand,
                          icar_type,  iins_type, iresource, mcover, ideduct, project,
                          qprem, mprem, mpure_prem, qfull, mfull, mfull_pure,
                          mprem_disc, mfull_disc, qclaim, qend_outstl, qbgn_outstl,
                          mstl, mend_outstl, mbgn_outstl, app_qlia, qlia_qclaim, 
                          qlia_qend_outstl,qlia_qbgn_outstl)
                         VALUES
                         ($irule, $dbgn, $dend, $dcalc,
                          $ipolicy_13, $iquota, $ori_officer, $icar_flag, $ibrand,
                          $icar_type,  $iins_type, $iresource, $mcover, $ideduct, $project,
                          $qprem, $mprem, $mpure_prem, $qfull, $mfull, $mfull_pure,
                          $mprem_disc, $mfull_disc, $qclaim, $qend_outstl, $qbgn_outstl,
                          $mstl, $mend_outstl, $mbgn_outstl, $app_qlia, $qlia_qclaim, 
                          $qlia_qend_outstl, $qlia_qbgn_outstl);
                   }
              $DELETE FROM ca_loss_project 
                WHERE irule       = $irule
                  AND dbgn        = $dbgn
                  AND dend        = $dend
                  AND dcalc       = $dcalc
                  AND ipolicy_13  = $ipolicy_13
                  AND iquota      = $iquota
                  AND iofficer    = $iofficer
                  AND icar_flag   = $icar_flag
                  AND ibrand      = $ibrand
                  AND icar_type   = $icar_type
                  AND iins_type   = $iins_type
                  AND iresource   = $iresource
                  AND mcover      = $mcover
                  AND ideduct     = $ideduct
                  AND project     = $project;
          }
   }
   $CLOSE chg_e_cur5;
   $FREE  chg_e_cur5;
   $DROP TABLE eofficer_temp;

   rtn=0;
   return rtn;
errexit:
   return SQLCODE;
}

/*********************************************************/
long merge_car_model()
{
   int   rtn;
   $char ibrand[7],nbrand_1[13],nbrand_2[31];
   $int  ipro_year;

   EXEC SQL whenever sqlerror goto errexit;

   EXEC SQL INSERT INTO ca_car_model_wk
                        (ibrand)
            SELECT distinct ibrand[1,6]
              FROM ca_car_model;
   
   EXEC SQL DECLARE cur_m1 cursor FOR
             SELECT ibrand
               INTO :ibrand
               FROM ca_car_model_wk;
   EXEC SQL OPEN cur_m1;

   while(1)
   {
        EXEC SQL FETCH cur_m1;
        if (SQLCODE == SQLNOTFOUND) break;

        EXEC SQL DECLARE cur_m2 CURSOR FOR
                  SELECT nbrand_abbr , nbrand    , ipro_year
                    INTO :nbrand_1   , :nbrand_2 , :ipro_year
                    FROM ca_car_model
                   WHERE ibrand[1,6] = :ibrand
                   ORDER BY ipro_year desc;
        EXEC SQL OPEN  cur_m2;
        EXEC SQL FETCH cur_m2;
        EXEC SQL CLOSE cur_m2;
        EXEC SQL FREE  cur_m2;

        EXEC SQL UPDATE ca_car_model_wk
                    SET nbrand_1 = :nbrand_1,
                        nbrand_2 = :nbrand_2
                  WHERE ibrand = $ibrand;
   }
   EXEC SQL CLOSE cur_m1;
   EXEC SQL FREE  cur_m1;

   EXEC SQL UPDATE ca_car_model_wk
               SET qorder = 2,
                   ntitle = '�ζ����t'
             WHERE ibrand[1,2] in ('01','58','59','A2');

   EXEC SQL UPDATE ca_car_model_wk
               SET qorder = 3,
                   ntitle = '�֯S���t'
             WHERE ibrand[1,2] in ('03','13','14');

   EXEC SQL UPDATE ca_car_model_wk
               SET qorder = 1,
                   ntitle = '���ب��t'
             WHERE ibrand[1,2] in ('07','50','52','C3');

   EXEC SQL UPDATE ca_car_model_wk
               SET qorder = 4,
                   ntitle = '��L���t'
             WHERE qorder is null;
     
   rtn=0;
   return rtn;
errexit:
   return SQLCODE;
}

/*********************************************************/
long merge_officer_name()
{  
   int  rtn;

   EXEC SQL whenever sqlerror goto errexit;

/*********************************************************
   EXEC SQL INSERT INTO officer_wk
            SELECT a.iofficer,c.ngroup,b.ngroup,a.nname,b.qorder
              FROM officer a,sa_frm_module b,sa_frm_module c
             WHERE a.idealer = b.igroup
               AND DECODE(a.idealer,'F99','X','E02','X',a.ibigcomp) = c.igroup
               AND b.ifrm_module = '02'
               AND c.ifrm_module = '02'
               AND a.imgr = '1'
               AND a.iofficer[1] != 'W';

   EXEC SQL INSERT INTO officer_wk
            SELECT a.iofficer,c.ngroup,b.ngroup,a.nname,b.qorder
              FROM officer a,sa_frm_module b,sa_frm_module c
             WHERE a.idealer = b.igroup
               AND a.ibus_location = c.igroup
               AND b.ifrm_module = '02'
               AND c.ifrm_module = '02'
               AND a.imgr = '1'
               AND a.iofficer[1] = 'W';
********************************************************/

   EXEC SQL INSERT INTO officer_wk
            SELECT icode,nlevel3,nlevel4,b.nname,qorder
              FROM v_channel a,officer b
             WHERE a.level3 != ' '
               AND a.icode = b.iofficer;

/**********************************************
   EXEC SQL DELETE FROM officer_wk
             WHERE iofficer[1]='G'
               AND iofficer[1,2] != 'G9';
***********************************************/

   EXEC SQL DELETE FROM officer_wk
             WHERE iofficer = 'G02018';

   EXEC SQL UPDATE officer_wk
               SET iofficer = 'G02018',
                   ntitle = '��L'
             WHERE iofficer = 'E02014';

   EXEC SQL UPDATE officer_wk
               SET ntitle = '��L'
             WHERE iofficer[1,3] = 'F17';

   EXEC SQL UPDATE officer_wk
               SET ntitle = '�ζ�'
             WHERE iofficer[1]='E';

   rtn=0;
   return rtn;
errexit:
   return SQLCODE;
}

/*********************************************************/
long merge_quota_name()
{  
   int   rtn;
   $char iquota[7];

   EXEC SQL whenever sqlerror goto errexit;

   EXEC SQL INSERT INTO quota_wk
            SELECT a.ibranch,a.nbranch,a.igroup,b.ngroup,b.qorder
              FROM sa_branch_type a,sa_frm_module b
             WHERE a.igroup = b.igroup
               AND b.ifrm_module = '01';

   rtn=0;
   return rtn;
errexit:
   return SQLCODE;
}

/*********************************************************/
