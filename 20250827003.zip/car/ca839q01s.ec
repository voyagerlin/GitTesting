/************************************************/
/*   PROGRAM : ca839q01s.ec                     */
/*   MODIFY  : cyrus                            */
/*   DATE    : 104.03.10                        */
/*   NOTE    : ������d�ּ˥����Ӫ�             */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
$include datetime.h;
#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"

$char DBName[05], iForm_Tp[03], outputf[N_FILE+1];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1];
char  userid[11];

char  msgbuf[100];
$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;
$int  PERIOD;

static int  max_count;

DBinfo  *list;
int     count_db;

$char sIbranch[BRANCH_ID], sIofficer[EMPLOYEE_ID];
$char sNname[EMPLOYEE_NAME];
$char sIclaim[CLAIM_NUM], sFcard_class[2], sDclaim[YYYYMMDD];
$char sYearMonth[7];
$char sIadjuster[EMPLOYEE_ID], sFclose[2], sIins_type[INSURANCE_TYPE];
$char sDclose[13], victim[11], flast[2];
$char sDgroup[11];
$char dgroup[11];
$long ldgroup;
$char sNgroup[5],sNadjuster[11];
$char sIupbranch[3], sNupgroup[11];
$char sFins_grp[2];
$char sBgnDate_e[11], sEndDate_e[11], sBgnDate[11], sEndDate[11];
$long lBgnDate, lEndDate;
$long iQorder, i, qmonth, lMins_stl;
$char ivictim[11];
$long qdmg_claim, qdmg_close, qdmg_nopay;       /** ���l **/
$long qlia_claim, qlia_close, qlia_nopay;       /** �d�� **/
$long qburg_claim, qburg_close, qburg_nopay;    /** �W�[�ѵs�����Ѩ��l�������X **/
$long qcomp_claim, qcomp_close, qcomp_nopay;    /** �j�� **/
$long qwea_claim, qwea_close, qwea_nopay;       /** �]�� **/
$long mins_stl;
$date lDclaim;
$char iclaim[21];
$int  iclose_type;
$int  icnt;
$char stmt[2000];
$char stmt3[9500];

$char iins_item[INSURANCE_TYPE];

int qlia, qburg, qdmg, qwea;
$int iTmp;
$int iMaxCnt;
$int id1;
$int iMonthDiff;

long car839_build();
void car839_title();
long car839_body();
long car839_print();
void car839_print2();
int DiffMonth();

/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
   int rc;
   
   batchinit();
   strcpy(DBName  , isNULLstr(argv[1]));
   strcpy(userid  , isNULLstr(argv[2]));
   strcpy(sBgnDate, isNULLstr(argv[3]));
   strcpy(sEndDate, isNULLstr(argv[4]));
   strcpy(outputf , isNULLstr(argv[5]));

   strcpy(sBgnDate_e, cm_to_infdate(sBgnDate));
   strcpy(sEndDate_e, cm_to_infdate(sEndDate));

   rstrdate(sBgnDate_e, &lBgnDate);
   rstrdate(sEndDate_e, &lEndDate);

   printf("sBgnDate_e[%s] sEndDate_e[%s]\n",sBgnDate_e , sEndDate_e);
 
   rc=car839_get_db();
   if (rc!=M_CM_OK)
      return rc;
   
   rc = car839_build();
   if (rc != M_CM_OK)
       return rc;

   return M_CM_OK;
   
errexit:
   printf("main :SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/

long car839_build()
{
   $char  TitleFmt[N_FILE+1],BodyFmt[N_FILE+1];
   int    rc;
   
   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT;
   
   if (db_select(DBName) == False)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   rc = car839_body();
   if (rc != M_CM_OK)
       return rc;
           
   rc = car839_print();
   if (rc != M_CM_OK)
       return rc;
 
   return M_CM_OK;

errexit:
   EWRITE(userid,rc,sqlca.sqlerrm);
   return SQLCODE;  
}

long car839_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

long car839_body()
{
    int i;
    long rc;
    $char sStmt[9500],sStmt1[9500],sStmt2[9500],sStmt3[9500],sStmt4[9500];
    $char stmt[9500];
    $char tmp[4096], tmp1[4096], tmp2[4096];

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;

    $create temp table setnote
    (
       iclaim          char(20),
       fstl            char(1),
       iclose_type     char(4),
       istl_note       char(3),
       mnote016        integer,
       iacc_reason     char(3),
       ncode           char(60)
    )with no log;

    $create index setnote_ix1 on setnote(iclaim, fstl, iclose_type);

    $create temp table setreason
    (
       iclaim          char(20),
       fstl            char(1),
       iclose_type     char(4),
       iacc_reason     char(4),
       ncode           char(40)
    )with no log;

    $create index axia2 on setreason(iclaim, fstl, iclose_type);

    $create temp table temp3 
    (
       iclaim          char(20),
       ipolicy         char(20),
       provision       char(20)
    )with no log;
    
    $create index temp3_1 on temp3(iclaim);

    for (i=0;i<count_db;i++)
    {
        sprintf_s(stmt,9500,
         "  insert into setnote          \
            select a.iclaim, a.fstl, cast(a.iclose_type as char(4)), a.istl_note, a.mnote016,    \
                   b.iacc_reason, (select ncode from adjustment_code where icode = b.iacc_reason and fclass = '1') as ncode    \
              from %s:settlement a, %s:appraisal b   \
             where a.istl_note = '016'               \
               and a.iclaim    = b.iclaim            \
               and a.mnote016  > 0 ", list[i].dbname, list[i].dbname);
        printf("stmt[%s]\n",stmt);
        $prepare insnote from $stmt; 
        $execute insnote;


        sprintf_s(stmt,9500,
         "  insert into setreason        \
            select a.iclaim, a.fstl, cast(a.iclose_type as char(4)),       \
                   b.iacc_reason, (select ncode from adjustment_code where icode = b.iacc_reason and fclass = '1') as ncode      \
              from %s:settlement a, %s:appraisal b     \
             where a.iclaim    = b.iclaim              \
               and a.iclaim    in (select iclaim1 from claim_stl_dtl where dgroup between ? and ? and iclaim1[6] != 'C' and iclaim1 = a.iclaim) ",
            list[i].dbname, list[i].dbname);
        printf("stmt[%s]\n",stmt);
        $prepare insreason from $stmt; 
        $execute insreason using $sBgnDate_e, $sEndDate_e;


        strcpy(tmp,"");       
        sprintf_s(tmp,4096,
         "  select nvl(z.prn_deduct,x.mdeduct) as prn_deduct \
                      from %s:ply_ins_type x, %s:ply_relation y, sysdb:ca_dmg_mdeduct z, sysdb:insurance_type zz    \
                     where x.ipolicy    = y.ipolicy      \
                       and y.ipolicy    = a.ipolicy      \
                       and y.icar_type  = z.icar_type    \
                       and x.mdeduct    = z.ideduct      \
                       and x.iins_type  = zz.iins_ply    \
                       and zz.iins_type = f.insure_instype  ", list[i].dbname, list[i].dbname);


        strcpy(tmp1,"");
        sprintf_s(tmp1,4096,
         "  select mdeduct from %s:app_ins_type where iclaim = a.iclaim and iins_type = f.insure_instype ",list[i].dbname);


        strcpy(tmp2,"");
        sprintf_s(tmp2,4096,
         "  select mins_dedu        \
              from %s:stl_ins_type  \
             where iclaim  = a.iclaim  \
               and fstl    = a.fstl    \
               and cast(iclose_type as smallint) = a.iclose_type   \
               and iins_type = a.iins_type ",list[i].dbname );


        if (i == 0)
        { 
           strcpy(sStmt1, tmp);
           strcpy(sStmt2, tmp1);
           strcpy(sStmt3, tmp2);
        }

        if (i > 0)
        {
           strcat(sStmt1," union ");  
           strcat(sStmt1, tmp);

           strcat(sStmt2," union ");  
           strcat(sStmt2, tmp1);

           strcat(sStmt3," union ");  
           strcat(sStmt3, tmp2);
        }
    }

    printf("sStmt1[%s]\n", sStmt1);
    printf("sStmt2[%s]\n", sStmt2);
    printf("sStmt3[%s]\n", sStmt3);

    strcpy(stmt3, sStmt3);

    sprintf_s(stmt,9500,
     "  select (select q.iupcomp   \
                  from cm_clm_adjuster p, branch q   \
                 where p.iapp_unit = q.ibranch       \
                   and p.empl_no   = a.adjustment) as iupcomp,   \
        c.nbranch, a.adjustment, d.chinese_name name_adj,  \
        d.administrator, e.chinese_name name_adm, \
        date(a.daccident) dacc, \
        a.daccident, \
        a.dclaim, \
        (select decode(m.iupcomp, '00','00:�x�_','22','22:�s�_',  \
                                  '33','33:���','40','40:�x��',  \
                                  '66','66:�x�n','70','70:����')  \
           from sa_branch_type m, policy_main n  \
          where a.ipolicy[1,13]  =  n.ipolicy1   \
            and a.ipolicy[14,17] =  n.ipolicy2   \
            and n.iendorsement   =  ' '          \
            and m.ibranch        =  n.iquota) as nupcomp,  \
        (select m.nbranch  \
           from sa_branch_type m, policy_main n  \
          where a.ipolicy[1,13]  =  n.ipolicy1   \
            and a.ipolicy[14,17] =  n.ipolicy2   \
            and n.iendorsement   =  ' '  \
            and m.ibranch        =  n.iquota) as nply_branch, \
        (select case when imgr = '1' then '�g�P��' else '�D�g�P��' end from officer where iofficer = b.iofficer) as imgr, \
        b.iofficer,  \
        (select nname from officer where iofficer = b.iofficer) as noffname, \
        a.ipolicy,   \
        b.dwritten,  \
        a.iclaim,    \
        a.nassured,  \
        (select nins_type  \
           from insurance_type  \
          where iins_type = g.insure_instype) as nins_type,  \
        f.insure_instype iins_type, f.mclaim_app,  \
        g.msettle, g.dgroup,    \
        nvl((select prn_deduct  \
              from ( %s )), 0) as prn_deduct,  \
        nvl((select mdeduct   \
               from ( %s )),0) as app_deduct,  \
           (select istl_note from setnote where iclaim = g.iclaim1 and fstl = g.fstl and iclose_type = g.iclose_type) as istl_note,  \
           (select mnote016  from setnote where iclaim = g.iclaim1 and fstl = g.fstl and iclose_type = g.iclose_type) as mnote016,   \
           (select iacc_reason from setreason where iclaim = g.iclaim1 and fstl = g.fstl and iclose_type = g.iclose_type) as iacc_reason,  \
           (select ncode from setreason where iclaim = g.iclaim1 and fstl = g.fstl and iclose_type = g.iclose_type) as ncode,  \
           g.fstl, g.iclose_type  \
   from ca_clm_process a, policy_new b, sa_branch_type c,  \
        personal:asempl d, personal:asempl e, claim_app_dtl f,  \
        claim_stl_dtl g  \
  where a.ipolicy[1,13]   = b.ipolicy1  \
    and a.ipolicy[14,17]  = b.ipolicy2  \
    and a.affiliated      = c.ibranch   \
    and a.adjustment      = d.empl_no   \
    and d.administrator   = e.empl_no   \
    and a.iclaim          = f.iclaim1   \
    and a.fclaim_status   = 501   \
    and f.iclaim1         = g.iclaim1   \
    and f.iclaim2         = g.iclaim2   \
    and f.insure_instype  = g.insure_instype  \
    and g.dgroup between ? and ?   \
    and a.iclaim[6]      != 'C'    \
  into temp temp1 with no log ", sStmt1, sStmt2);

  /*****
    and f.insure_instype in ('01','05','08','09','10','98','105',   \
                             '105A','105B','110','118','120',  \
                             '118A','118B','122','81','83',    \
                             '75','04','06','23','85','86')    \
   *****/


  printf("stmt[%s]\n",stmt);
 
  $prepare main_id from $stmt;
  $execute main_id using $sBgnDate_e, $sEndDate_e;

  $create index temp1_1 on temp1(iclaim);
  $create index temp1_2 on temp1(ipolicy);


  for (i=0;i<count_db;i++)
  {
     sprintf_s(stmt,9500,
      "  insert into temp3     \
           select a.iclaim, a.ipolicy, b.provision   \
             from temp1 a, %s:ply_ins_type b, insurance_type c   \
            where a.ipolicy   = b.ipolicy      \
              and a.iins_type = c.iins_type  \
              and c.iins_ply  = b.iins_type ", list[i].dbname);
     $prepare ins_temp3 from $stmt;
     $execute ins_temp3;
  }

  return M_CM_OK;
        
errexit:
   printf("car839_body ==> SQLCODE:[%ld][%s] \n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   printf("   end EWRITE \n");
   return SQLCODE;
}

long car839_print()
{
   $char stmt[4096], stmt1[1024], stmt2[1024];
   $long qorder;
   int i,x,j,k;
   $int COUNT;
   $char sfilename[31];
   $char stitle[10000];
   $char ssql[10000];
   $char dyearmonth_tmp[7];
   $char title_tmp[101];
   $char title_tmp0[101];
   $char title_tmp1[101];
   $char title_tmp2[101];
   $char filed[20][15];
   $char sqltmp[1024];
   $char filed_tmp[200];
   $char sErrmsg[100];
   $int  rc;

   $WHENEVER ERROR goto errexit;
   $SET LOCK MODE TO WAIT;

   strcpy(sfilename,"������d�ּ˥����Ӫ�");

   strcpy(stitle,"�J�p����G");
   strcat(stitle, sBgnDate_e);
   strcat(stitle, " ~ ");
   strcat(stitle, sEndDate_e);
   strcat(stitle,"\n\t�߮��Ұ�\t�߮ר��z���\t�z�߸g��ID\t�z�߸g��\t���D��ID\t���D��\t�X�I���\t���z���\t�~�Z�Ұ�\t�~�Z���\t���ӧO\t�X��g��N��\t�X��g��W��\t�O�渹�X\t�X����\t�߮׸��X\t�Q�O�I�H�m�W\t�߮׹w���I�ئW��\t�߮׹w���I�إN��\t�X�I��]�N��\t�X�I��]�W��\t�w�����B\t�z����B\t016���O\t016���B\t�O�_�����r����\t�J�p�~��\t�J�p���\t�O��ۭt�B\t�w���ۭt�B\t�ߥI�ۭt�B\t�ĴX���X�I\t�ۭt�B�o�����X�@\t�ۭt�B�o�����X�G\t�������ñ�O�_�w����\t");

  sprintf_s(ssql,10000,
    "   select decode(a.iupcomp, '00','00:�x�_','22','22:�s�_',      \
                                 '33','33:���','40','40:�x��',      \
                                 '66','66:�x�n','70','70:����'),     \
               a.nbranch, a.adjustment, a.name_adj,    \
               a.administrator, a.name_adm,    \
               a.dacc, a.dclaim, a.nupcomp, a.nply_branch, a.imgr, a.iofficer, a.noffname, a.ipolicy, a.dwritten,    \
               a.iclaim, a.nassured, a.nins_type,      \
               a.iins_type, a.iacc_reason, a.ncode,    \
               a.mclaim_app, a.msettle,a.istl_note,a.mnote016,    \
               NVL((select unique 'D'       \
                      from temp3 x   \
                     where x.iclaim = a.iclaim   \
                       and trim(x.provision)||';' matches '*D;*'),' '), year(dgroup),   \
               dgroup,prn_deduct,app_deduct,( %s ) as mins_dedu,            \
               (select count(*) from ca_clm_process where ipolicy = a.ipolicy and daccident <= a.daccident) as icnt,   \
               nvl(b.invoice_dedu1,''), nvl(b.invoice_dedu2,''),     \
               (select isign_est from ca_clm_process where iclaim = a.iclaim) as isign_est   \
         from temp1 a, outer ca_sign_receipt b    \
        where a.iclaim = b.iclaim   \
          and (b.invoice_dedu1 <> '' or b.invoice_dedu2 <> '')   \
        order by 1,2,3 ",stmt3);

   printf("ssql[%s]\n",ssql);

   rc = unload_file(outputf," ",sfilename,stitle,ssql);

   if (rc != SUCCESS)
   {
       if (rc == 3501)
       {
          sprintf_s(sErrmsg,100," ��J���^������䤣���� ",sfilename);
       }
       else
       {
          sprintf_s(sErrmsg,100," %s �ɮ׵L�k���� ",sfilename);
       }

       EWRITE(userid, rc , sErrmsg);
       exit(1);
   }

   return M_CM_OK;

errexit:
  printf("SQL=[%d], sqlca.sqlerrm[%s]\n", SQLCODE, sqlca.sqlerrm);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  exit(1);
    
}

int DiffMonth(d1,d2)    /* input data should be date format */
long d1, d2;
{
short mdy1[3], mdy2[3];
int datediff=0;

    rjulmdy(d1,mdy1);
    rjulmdy(d2,mdy2);
    datediff=(mdy1[2]*12+mdy1[0])-(mdy2[2]*12+mdy2[0]);
    if (datediff<0) datediff=0;
    return datediff;
}

