/**********************************************************************/
/*   program id   : ca203p03s.ec                                      */
/*   program name : �i�妸�j- ���I�e�~�O�I�ҦL�s�@�~                  */
/*   date written : 2014/03/12                                        */
/*   date modify  : yyyy/mm/dd                                        */
/*   author       : Larry Liao                                        */
/*   shell        : car_out                                           */
/*   exec time    :(�C����Q�G�I)                                     */
/**********************************************************************/

#include <stdio.h>
#include <math.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"

#include "carmsgs.h" 
#include "commsgs.h" 
#include "cmnmsgs.h" 
#include "gls_array.h" 
#include "gls_const.h"
#include "sqlfatal.h"
#include "safeclib.h"

char  	outputf[ N_FILE+1];
$char  	userid[11],sDdate[11],sDdate0[16],sDdate1[20],sDdate2[20];
char    cdate[11];
$char   cdate1[11],cdate2[11],cdate_3072[11];
char	  syy[4],smm[3],sdd[3],sdate[11];
$int    PgLine;
char    OutFile[31];
int     max_count;

$char	DBName[5];
$char FormTp[3];
DBinfo  *list;
static Today;
    
int     flen,count_db,i;
FILE    *fp;
char    sApHome[30];
$char   fname[60];
$char   filename[121];
$char	  ftitle[1024];

$char	v_sMsg[1024],sErrMsg[1024];
char	msgbuf[100];
$long	dsys;

$char sIpolicy[21],icard[21],iroute[21];
$char ipolicy[20],nassured[122],aassured[92],apayment[92],ilicense[12],ibirth[10];
$char iassured[11],fmail_type[2],outpolicy[16];
$char fsex[2],ncar_abbr[14],iissue_ym[8],itag[CA_TAG_NUM],dply_begin[14],dply_end[14];
$char icar_type[4],ibrand[10],nbrand_abbr[14],nbrand_abbr_1[14],ibody[CA_BODY_NUM+1],itel[21],iengine[CA_ENGINE_NUM+3];
$char irelative_ply[20],qcylinder_buf[20],qperiod_buf[20],mpremium_buf[20];
$char bcard1[20],bcard2[20],bcard3[20],rel_ins_type[24],pdate[16],pdate1[16],pdate2[16];
$char bak_ins[8],fmarriage[4],irelative_card[20], iquery_num[15];
$int qperiod = 0,mpremium = 0;
$double qcylinder = 0;
$char tmp_fcard_class[20], tmp_ipolicy[20], tmp_icard[20], tmp_itmp_policy[20], tmp_iroute[20], tmp_itag[CA_TAG_NUM];
$char tmp_nassured[20], tmp_aassured[20], tmp_apayment[20], tmp_icar_type[20];
$char tmp_ncar_abbr[20], tmp_iissue_ym[20], tmp_iengine[CA_ENGINE_NUM], tmp_nbrand_abbr[20]; 
$char tmp_ibrand[20], tmp_qcylinder[20], tmp_ibody[CA_BODY_NUM], tmp_dply_begin[20], tmp_dply_end[20]; 
$char tmp_qperiod[20], tmp_ilicense[20], tmp_ibirth[20], tmp_fsex[20], tmp_itel[20], tmp_pdate[20];
$char tmp_bcard1[20], tmp_fmarriage[20], tmp_mpremium[20], tmp_iofficer[20], tmp_fpt[20], tmp_qpt[20]; 
$char tmp_iassured[20], tmp_ileader[20], tmp_icorps[20], tmp_ibranch[20], tmp_iquery_num[20];
$char tmp_fmail_type[20], tmp_dply_close[20], tmp_ibatch_no[20], tmp_irelative_ply[20], tmp_fcomp_class[20], tmp_fcomp_class_last[20];
$char tmp_npost_recipient[20],tmp_apost_address[20],tmp_aassured_zip[20],tmp_apost_zip[20];

int tmp_prem,other_prem,flag1=0;
$double qpt;
$char  policy_y;
static char yy1[4], mm1[3], dd1[3];
$char fcomp_class[3],fcomp_class_last[3],fpt,cqpt[6];

$int c_holiday;
$char ck_holiday_year[4],ck_holiday[11];

$char Ipolicy[20],Iofficer[11],Iofficer_tmp[13],Nofficer[21];
$char ileader[10],Nleader[21];
$char icorps[11], ibranch[7];
$char Nbranch[19];
$int  out_ply_50, out_ply_47;
char  s_qlia[3][10], fyear[3];
char  s_dpolicy[14];
$date rate_date;
$char Inumber[30],ch_amt[40];
long  qlia[3];
$char itmp_policy[21],iroute1[21];
$int  out_cnt = 0;
$char sWhere[512];
$char fcar_class[2];
$int out_draw;
$char fout_print_r[2],fmail_type_r[2],dout_trans_r[20],dpolicy_r[11],dply_close[11];
$int cnt_comp = 0,cnt_out = 0;

char cmd_stmt[1024];

$int nbrand_abb_len = 0;
char sTmp_db_name[21];

static char *get_car_full_db();
void put_body();
/*----------------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
    int rc;
      
    batchinit();
    strcpy(DBName,  isNULLstr(argv[1]));
    strcpy(userid,  isNULLstr(argv[2]));
    strcpy(cdate,   isNULLstr(argv[3])); /* cyy/mm/dd */
    strcpy(outputf, isNULLstr(argv[4]));
    
    rc = car_get_db();
    if (rc != M_CM_OK) {
        printf("error on car_get_db\n");
        return rc;
    }   
    $WHENEVER SQLERROR GOTO errexit;
    
    strcpy(cdate_3072,cdate);
    strcpy(ck_holiday_year,"");
    strcpy(ck_holiday,"");
    strcpy(ck_holiday_year,cm_get_sysd());
    strcpy(ck_holiday_year,cm_sysd_cyear_100(ck_holiday_year));
    strcpy(ck_holiday,cm_get_sysd());
    strcpy(ck_holiday,cm_sysd_cdate_100(ck_holiday));
    strcpy(ck_holiday,cm_to_infdate(ck_holiday));
    /*strcpy(ck_holiday,cm_to_infdate(cdate1));*/
    /*strcpy(ck_holiday,"05/28/2016");*/
    printf("-----ck_holiday_year = [%s]-----\n",ck_holiday_year);
    printf("-----ck_holiday = [%s]-----\n",ck_holiday);
    $SELECT count(*)
       INTO $c_holiday 
       FROM ca_holiday  
      WHERE cyear = $ck_holiday_year
        AND $ck_holiday BETWEEN holiday_bgn AND holiday_end;   
    
    if(c_holiday == 0)
    {
	    /* �d�ߩe�~�O�I�� */
	    rc = Query_card();
	    if ( rc != M_CM_OK) {
		  printf("error on Query_card\n");
		  EWRITE(userid, rc, "�d�ߩe�~�O���Ʀ��~!");
	        return rc;
	    }
	    
	    /*���I�e�~�O��L�s�@�~*/
	    sprintf_s(cmd_stmt, sizeof cmd_stmt,"%s/exec/runbatch 00 100533 car3072 Q 1 %s",sApHome,cdate_3072);
	    printf("[%s]\n", cmd_stmt);
	    rc = system(cmd_stmt);
	    if ( rc != M_CM_OK) {
	    	printf("error on Query_card\n");
		EWRITE(userid, rc, "���I�e�~�O��L�s�@�~!");
	        return rc; 
	    }
	    c_holiday = 1;
    }
    
    printf("-----THE END-----\n");
   
errexit:
    printf("-- Query_card -- SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;             
}
/*----------------------------------------------------------------------------*/
void clear_data()
{
  ipolicy[0]=icard[0]=irelative_ply[0]=0;
  fcomp_class[0]=fcomp_class_last[0]=0;
  cqpt[0]=0;
  nassured[0]=aassured[0]=0;
  apayment[0]=0;
  ncar_abbr[0]=0;
  iissue_ym[0]=0;
  itag[0]=0;
  iengine[0]=0;
  icar_type[0]=0;
  nbrand_abbr[0]=0;
  ibrand[0]=0;
  qcylinder_buf[0]=0;
  ibody[0]=0;
  dply_begin[0]=dply_end[0]=0;
  qperiod_buf[0]=0;
  mpremium_buf[0]=0;
  ilicense[0]=0;
  ibirth[0]=0;
  fsex[0]=0;
  itel[0]=0;
  bcard1[0]=0;
  irelative_card[0]=0;
  rel_ins_type[0]=0;
  pdate[0]=0;
  pdate2[0]=0;
  fmarriage[0]=0;
  out_ply_50 = 0;
  out_ply_47 = 0;
  fcar_class[0] = 0;
  fout_print_r[0] = fmail_type_r[0] = 0;
  nbrand_abbr_1[0] = 0;
  
}
/*----------------------------------------------------------------------------*/
long car_get_db()
{
    int	rc;

    if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "��Ʈw�L�k�}��!");
       return M_CM_DB_NOTOPEN;
    }
    
    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }
    
    if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
       if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
          return M_CM_NOT_DBLIST;
    }

    return M_CM_OK;
}
/*----------------------------------------------------------------------------*/
long Query_card()
{
    $char FormFile[N_FILE+1];
    $char stmt[4096],sStmt[4096],stmt1[4096],stmt_out_type[2048];
    $int  rc;
    char  errmsg[201];
    max_count=0; 
    $char sFullName[21];

	  
    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT 5;
	
	/* 131775 �����e�~�Ƶ{��CAR345�C�L�n�O�p���{���ק��V (1120111003_C01)*/
    /* $DELETE FROM ca_out_temp;  */
	$DELETE FROM ca_out_temp WHERE fout_note IN ('Y','E');

	/* �O�_�e�~���O�������]��Y(�i�e�~)�ѫ���B�z */
	$UPDATE ca_out_temp
		SET fout_note = 'Y';	  
	
    $UPDATE cu_code_data
        SET ncode = 'N'
      WHERE itype = 'OT'
	AND icode = '2033';
    $UPDATE cu_code_data
        SET ncode = 'N'
      WHERE itype = 'OT'
	AND icode = '3072';
		
    $SELECT nForm_File, iForm_Tp
       INTO $FormFile, $FormTp
       FROM Form
      WHERE ksys_grp="CA" AND kPgmID = 203
        AND iform_tp = '8';
    
    printf("-----cdate = [%s]-----\n",cdate);
    
    if(strlen(trim(cdate)) == 0 )
    {
    	strcpy(cdate1,cm_cdate_str(cm_today() ));
    	sprintf_s(sWhere, sizeof sWhere, " AND a.dout_trans is null ");
    }
    else
    {
    	strcpy(sDdate,cm_to_infdate(cdate));		/* sDdate:MM/DD/YYYY */
    	strcpy(sDdate,trim(sDdate));
    	printf("-----ñ���� : [%s]\n-----",sDdate);
    		
    	strcpy(sDdate0,cm_from_infdate_100(sDdate));	/* CYY/MM/DD */
    	strcat(sDdate0,"/00:00");			/* CYY/MM/DD/hh:mm */
    	strcpy(sDdate1,cm_sysd_edatetime(sDdate0));	/* YYYY-MM-DD hh:mm */
    	strcat(sDdate1,":00");				/* YYYY-MM-DD hh:mm:ss */
    	
printf("sDdate1[%s]\n",sDdate1);
    	
    	strcpy(sDdate0,cm_from_infdate_100(sDdate));
    	strcat(sDdate0,"/23:59");
    	strcpy(sDdate2,cm_sysd_edatetime(sDdate0));
    	strcat(sDdate2,":59");

printf("sDdate2[%s]\n",sDdate2);

    	sprintf_s(sWhere, sizeof sWhere, " AND a.dout_trans between '%s' and '%s' ",sDdate1,sDdate2);
    	
    	$SELECT first 1 dwork
           INTO $cdate2
           FROM cm_wrktbl
          WHERE dwork < $sDdate
        ORDER BY 1 desc;
        strcpy(cdate1,cm_from_infdate_100(cdate2));
    }
    
    printf("-----cdate1 = [%s]-----\n",cdate1);
        
    /*   
    dsys = cm_ymd_cdate(cdate);
    cm_char_split_3ymd(cdate,syy,smm,sdd);
    */
    
    cm_char_split_3ymd(cdate1,syy,smm,sdd);
    sprintf_s(sdate, sizeof sdate,"%s%s%s",syy,smm,sdd);
    printf("-----sdate = [%s]-----\n",sdate);
        
    strcpy(FormFile,rtrim(FormFile));
    sprintf_s(OutFile, sizeof OutFile,"%s_card.tx",sdate);
    
    rgu_init_report(FormFile,OutFile);
    
    /* dpolicy >= '01/11/2016' 1041228004_C1_B2C²�T��׵o�e�y�{�ק� */    
    for(i=0;i<count_db;i++) 
    {  	 
      sprintf_s(stmt, sizeof stmt,"insert into ca_out_temp "
                   "SELECT a.ipolicy,a.fcard_class, a.icard, a.itmp_policy, b.iroute, b.itag ,"
                     "     b.nassured, b.aassured, b.apayment, a.icar_type, "
                      "    b.ncar_abbr,to_char(b.dissue,'%%Y')::integer - 1911 , "
                      "    b.iengine, b.nbrand_abbr,a.ibrand, b.qcylinder, "
                      "    b.ibody, a.dply_begin, a.dply_end,a.qply_period, b.ilicense, "
                      "    to_char(b.dbirth,'%%Y')::integer - 1911 || '/' || to_char(b.dbirth,'%%m/%%d'),"
                      "    b.fsex, b.itel,a.dpolicy, a.ilast_card, b.fmarriage, a.mlia_prem, a.iofficer,"
                      "    b.fpt, b.qpt , b.iassured, a.ileader, a.icorps, a.iquota[1,4]||'00' ibranch, "
                      "    b.iquery_num , a.fmail_type ,dply_close ,a.ibatch_no , a.irelative_ply, a.fcomp_class, a.fcomp_class_last,"
                      "    b.npost_recipient,b.apost_address,b.aassured_zip,b.apost_zip,b.mcar_price,(a.mdmg_prem+a.mlia_prem),"
                      "    b.napplicant,a.ilast_ply,b.apayment_zip,b.nequipment,(select max(drate_ym) from %s:ply_ins_type where ipolicy = a.ipolicy),a.dcreate,%d,b.iabn_type,"
	                  "    (select nvl(fout_print,' ') from %s:ply_relation where ipolicy = a.irelative_ply), "
	                  "    (select nvl(fmail_type,' ') from %s:ply_relation where ipolicy = a.irelative_ply), "
	                  "    (select nvl(dout_trans,' ') from %s:ply_relation where ipolicy = a.irelative_ply), "
	                  "    (select nvl(dpolicy,' ') from %s:ply_relation where ipolicy = a.irelative_ply),'Y' "
	                 "  FROM %s:ply_relation a, %s:policy b  "
	                 " WHERE a.ipolicy = b.ipolicy  "
	                 "   AND a.fout_print = '1'  "
	                 "   AND a.dpolicy >= '01/11/2016' "
	                 "   AND a.fmail_type != '0' "
					 "   AND a.ipolicy NOT IN (SELECT ipolicy FROM ca_out_temp) " /* 131775 �ư����Ƽg��ƶi ca_out_temp */
	                 "   AND a.dply_close is null  %s ",list[i].dbname,i,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,sWhere);
	                 
      sprintf_s(stmt1, sizeof stmt1,"insert into ca_out_temp "
                   "SELECT a.ipolicy,a.fcard_class, a.icard, a.itmp_policy, b.iroute, b.itag ,"
                     "     b.nassured, b.aassured, b.apayment, a.icar_type, "
                      "    b.ncar_abbr,to_char(b.dissue,'%%Y')::integer - 1911 , "
                      "    b.iengine, b.nbrand_abbr,a.ibrand, b.qcylinder, "
                      "    b.ibody, a.dply_begin, a.dply_end,a.qply_period, b.ilicense, "
                      "    to_char(b.dbirth,'%%Y')::integer - 1911 || '/' || to_char(b.dbirth,'%%m/%%d'),"
                      "    b.fsex, b.itel,a.dpolicy, a.ilast_card, b.fmarriage, a.mlia_prem, a.iofficer,"
                      "    b.fpt, b.qpt , b.iassured, a.ileader, a.icorps, a.iquota[1,4]||'00' ibranch, "
                      "    b.iquery_num , a.fmail_type ,dply_close ,a.ibatch_no , a.irelative_ply, a.fcomp_class, a.fcomp_class_last,"
                      "    b.npost_recipient,b.apost_address,b.aassured_zip,b.apost_zip,b.mcar_price,(a.mdmg_prem+a.mlia_prem),"
                      "    b.napplicant,a.ilast_ply,b.apayment_zip,b.nequipment,(select max(drate_ym) from %s:ori_ins_type where ipolicy = a.ipolicy),a.dcreate,%d,b.iabn_type,"
                      "    (select nvl(fout_print,' ') from %s:ori_ply_relation where ipolicy = a.irelative_ply), "
	                  "    (select nvl(fmail_type,' ') from %s:ori_ply_relation where ipolicy = a.irelative_ply), "
	                  "    (select nvl(dout_trans,' ') from %s:ori_ply_relation where ipolicy = a.irelative_ply), "
	                  "    (select nvl(dpolicy,' ') from %s:ori_ply_relation where ipolicy = a.irelative_ply),'Y' "
	                 "  FROM %s:ori_ply_relation a, %s:original_ply b  "
	                 " WHERE a.ipolicy = b.ipolicy  "
	                 "   AND a.fout_print = '1'  "
	                 "   AND a.dpolicy >= today - 15 "
					 "   AND a.ipolicy NOT IN (SELECT ipolicy FROM ca_out_temp) "
	                 "   AND a.fmail_type != '0' %s ",list[i].dbname,i,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,sWhere);
  
	        $EXECUTE IMMEDIATE $stmt;
	        $EXECUTE IMMEDIATE $stmt1;
	        printf("stmt[%s]\n\n\n",stmt);
	        printf("stmt1[%s]\n\n\n",stmt1);
	        printf("i[%d]\n\n\n",i);
	        
    	                 	                 
      }               

	sprintf_s(sStmt, sizeof sStmt," SELECT ipolicy, nassured, aassured, apayment, icar_type, "
                      "    ncar_abbr,iissue_ym, "
                      "    itag, iengine, nbrand_abbr,ibrand, qcylinder, "
                      "    ibody, dply_begin, dply_end,qperiod, ilicense, "
                      "    ibirth, "
                      "    fsex, itel,pdate, bcard1, fmarriage, mpremium, iofficer,"
                      "    fpt, qpt , iassured, ileader, icorps, ibranch, "
                      "    iquery_num , fmail_type , iroute ,itmp_policy ,icard,irelative_ply,fcomp_class,fcomp_class_last,"
                      "    fout_print_r, fmail_type_r, dout_trans_r ,dpolicy_r ,dply_close"
	                 "  FROM ca_out_temp  "
	                 " WHERE fcard_class = '1'");
            	                 	                 
	    $PREPARE out_compulsory FROM $sStmt;
	    $DECLARE COMP_CUR CURSOR FOR out_compulsory;
	    $OPEN COMP_CUR;
	    printf("-----> into COMP_CUR \n");
	    printf("sStmt[%s]\n\n\n",sStmt);
	    
	    for(;;)
	    {
	    	clear_data();
	    	policy_y = 'Y';
	    	$FETCH COMP_CUR INTO $ipolicy, $nassured, $aassured, $apayment, $icar_type,
                                     $ncar_abbr, $iissue_ym, $itag, $iengine, $nbrand_abbr, 
                                     $ibrand, $qcylinder, $ibody, $dply_begin, $dply_end, 
                                     $qperiod, $ilicense, $ibirth, $fsex, $itel, $pdate, 
                                     $bcard1, $fmarriage, $mpremium, $Iofficer, $fpt, $qpt, 
                                     $iassured, $ileader, $icorps, $ibranch, $iquery_num,
                                     $fmail_type, $iroute ,$itmp_policy,$icard,$irelative_ply,$fcomp_class,$fcomp_class_last,
                                     $fout_print_r,$fmail_type_r,$dout_trans_r,$dpolicy_r,$dply_close;
                                     
	    	if (SQLCODE == SQLNOTFOUND) break;
	    	
	    	strcpy(sFullName, get_car_full_db(ipolicy));
	    	printf("sFullName[%s]",sFullName);	    	
	    	strcpy(itmp_policy,trim(itmp_policy));
	    	strcpy(iroute1,trim(iroute));
	    	strcpy(fout_print_r,trim(fout_print_r));
	    	strcpy(fmail_type_r,trim(fmail_type_r));
	    	strcpy(dout_trans_r,trim(dout_trans_r));
	    	strcpy(dpolicy_r,trim(dpolicy_r));
	    	strcpy(dply_close,trim(dply_close));
	
	    	printf("--222 ipolicy:[%s], icard:[%s]\n", ipolicy, icard);
	    	printf("--223 itmp_policy:[%s], iroute1:[%s]\n", itmp_policy, iroute1);
	    	
	    	printf("--before nbrand_abbr:[%s] nbrand_abbr_1:[%s]\n",nbrand_abbr, nbrand_abbr_1);
	    	nbrand_abb_len = cc_split_chinese(nbrand_abbr,nbrand_abbr_1,8);
	    	printf("--after nbrand_abbr:[%s] nbrand_abbr_1:[%s]\n",nbrand_abbr, nbrand_abbr_1);
	    	
	    	/* 1061012002_SC6_ISID�PRBA */
	    	/* ��j�����p�渹���btable���~�򲣻s�_�h�i�J�P�_���p�渹*/
	    	cnt_comp = 0;
	    	$SELECT count(*)
	    	   INTO $cnt_comp 
	    	   FROM ca_out_temp a
              WHERE fcard_class = '1'
                AND ((SELECT count(*) FROM ca_out_temp WHERE ipolicy = a.irelative_ply) > 0
                 OR irelative_ply IS NULL)
                AND ipolicy = $ipolicy;
                 
            printf("--429 fout_print_r[%s],fmail_type_r[%s],dout_trans_r[%s],dpolicy_r[%s] \n",fout_print_r,fmail_type_r,dout_trans_r,dpolicy_r);
	    	
	    	if(cnt_comp == 0)
	    	{
	    		/*if(strncmp(fout_print_r,"1",1) == 0 && strncmp(fmail_type_r,"0",1) != 0 && strlen(dout_trans_r) != 0)
	    		{
	    			/*���p�渹�w�e�~*
	    		}
	    		else if(strncmp(fout_print_r,"1",1) == 0 && strncmp(fmail_type_r,"0",1) == 0 && strlen(dout_trans_r) == 0)
	    		{
	    			/*���p�渹�D�e�~*
	    		}
	    		else if(strncmp(fout_print_r,"1",1) != 0 && strncmp(fmail_type_r,"0",1) == 0 && strlen(dout_trans_r) == 0)
	    		{
	    			/*���p�渹�D�e�~*
	    		}*/
	    		
	    		if(strlen(dply_close) != 0)
	    		{
	    			if(strlen(fout_print_r) == 0 && strlen(fmail_type_r) == 0)
	    			{
			    		sprintf_s(stmt_out_type, sizeof stmt_out_type,"SELECT nvl(fout_print,' '),nvl(fmail_type,' '),nvl(dout_trans,' ') "
			                                  "  FROM %s:ply_relation "
			                                  " WHERE ipolicy = '%s' ",sFullName,irelative_ply);	                     
			            $PREPARE out_type FROM $stmt_out_type;
			            $EXECUTE out_type INTO $fout_print_r,$fmail_type_r,$dout_trans_r;
			            
			            strcpy(dout_trans_r,trim(dout_trans_r));
		    			strcpy(dpolicy_r,trim(dpolicy_r));
		    			printf("--456 fout_print_r[%s],fmail_type_r[%s],dout_trans_r[%s],dpolicy_r[%s] \n",fout_print_r,fmail_type_r,dout_trans_r,dpolicy_r);
		    		}
	    		}

				/* 131775 �j���Iñ�������p��W�L60�ѡA����OE ���e�~(1120111003_C01) */
				strcpy(pdate2,cm_from_infdate_100(pdate));
				if(cm_cdays_between(pdate2,cdate1) > 60)
				{
					$UPDATE ca_out_temp
	    		        SET fout_note = 'E' 
	    		      WHERE ipolicy = $ipolicy;
	    			continue;
				}

	    		if(strncmp(fout_print_r,"1",1) == 0 && strncmp(fmail_type_r,"0",1) != 0 && strlen(dout_trans_r) == 0)
	    		{
		    		/*���p�渹���e�~���|���L��*/
	    			$UPDATE ca_out_temp 
	    			    SET fout_note = 'N'
	    			  WHERE ipolicy = $ipolicy;
	    			continue;  /*�j�[���ݦP�ɲ��s�ǰe*/
	    		}
	    	}
	    	
	    	/*** B2C������O�A�ݦ�����n�O�Ѥ���~���H�e�ʧ@ ***/
	    	if(strncmp(itmp_policy,"17N",3) == 0 && strncmp(iroute1, "JB", 2) == 0)
			{
			sprintf_s(stmt, sizeof stmt,"SELECT count(*) "
	                     "  FROM %s:ca_quotation "
	                     " WHERE iquote = '%s' "
	                     "   AND dcust_apply is not null ",sFullName,itmp_policy);	                     
	        $PREPARE est_card FROM $stmt;
	        $EXECUTE est_card INTO $out_cnt;
printf("out_cnt[%d]\n",out_cnt); 
			if(out_cnt == 0) continue;
			}
		/*** ���P�_:�p�G���]�w��ca_out_draw��(car344)�A�åBfout_type = '0'�A�h�����H�e�ʰ� ***/
		out_draw = 0;
		$SELECT count(*)
   		   INTO $out_draw
   		   FROM ca_out_draw
  		  WHERE ipolicy = $ipolicy
    		    AND fout_type = '0';
printf("out_draw[%d]\n",out_draw);
    		if(out_draw > 0 ) continue;        
        
        /*** �e�~�C�L����@�ߧאּñ��� ***/	
        strcpy(pdate1,cm_from_infdate_100(pdate));
    	cm_split_ymd_100(pdate1,syy,smm,sdd);
printf("pdate[%s],pdate1[%s],syy[%s],smm[%s],sdd[%s]\n\n",pdate,pdate1,syy,smm,sdd);
        	        	 
          $SELECT  nname
             INTO  $Nofficer
             FROM  officer
            WHERE  iofficer = $Iofficer;

          $SELECT  nname
             INTO  $Nleader
             FROM  officer
            WHERE  iofficer = $ileader;

		      $SELECT nbranch
			       INTO $Nbranch
			       FROM sa_branch_type
			      WHERE ibranch = $ibranch;

          $SELECT  ncode,fcar_class
             INTO  $ncar_abbr,$fcar_class
             FROM  car_type
            WHERE  icode = $icar_type 
              AND  fclass = '1';
            
           ncar_abbr[8] = '\0';
           printf("--271 ncar_abbr[%s]--fcar_class[%s]\n",ncar_abbr,fcar_class);
             
          /*sprintf_s(stmt, sizeof stmt,"SELECT irelative_ply,fcomp_class,fcomp_class_last "
                       "  FROM ca_out_temp "
                       " WHERE ipolicy = '%s' ",ipolicy);
          $PREPARE ply_data FROM $stmt;
	        $DECLARE ply_cur CURSOR FOR ply_data;
	        $OPEN    ply_cur;
	        $FETCH   ply_cur INTO $irelative_ply,$fcomp_class,$fcomp_class_last;
          if (SQLCODE != SQLNOTFOUND) 
          {
             select �I�إN�X from �O���I�ة��� 
            sprintf_s(stmt, sizeof stmt,"SELECT iins_type "
                         "  FROM %s:ply_ins_type "  
                         " WHERE ipolicy = '%s' ",list[i].dbname,irelative_ply);
            $PREPARE ply_ins FROM $stmt;
	          $DECLARE ply_ins_cur CURSOR FOR ply_ins;
	          $OPEN    ply_ins_cur;
            for(;;)
            {
              $FETCH ply_ins_cur INTO $bak_ins;
              if (SQLCODE == SQLNOTFOUND) break;

              strcat(rel_ins_type,rtrim(bak_ins)); 
            }
            $CLOSE ply_ins_cur;
	          $FREE  ply_ins_cur;
          }
          $CLOSE ply_cur;
	        $FREE  ply_cur;
          */ 
          
          sprintf_s(stmt, sizeof stmt,"SELECT icard "
	                     "  FROM %s:ply_relation "
	                     " WHERE ipolicy = '%s' ",sFullName,irelative_ply);	                     
	        $PREPARE ply_card FROM $stmt;
	        $EXECUTE ply_card INTO $irelative_card;
	            
          printf("--308 irelative_card:[%s] \n",irelative_card);
/*
          sprintf_s(stmt, sizeof stmt,"SELECT bcard1 "
                       "  FROM ca_out_temp "
                       " WHERE icard = '%s' ",bcard1);
          $PREPARE ply_ilast FROM $stmt;
	        $DECLARE ply_ilast_cur CURSOR FOR ply_ilast;
	        $OPEN    ply_ilast_cur;
	        $FETCH   ply_ilast_cur INTO $bcard2;
          if (SQLCODE != SQLNOTFOUND)
          { 
             sprintf_s(stmt, sizeof stmt,"SELECT bcard1 "
                          "  FROM ca_out_temp "
                          " WHERE icard = '%s' ",bcard2);
             $PREPARE ply_ilast2 FROM $stmt;
	           $EXECUTE ply_ilast2 INTO $bcard3;            
          }
          $CLOSE ply_ilast_cur;
	        $FREE  ply_ilast_cur;
       }*/
       
       /* �e�~�O�� (�T��)�u�O50�I��-�O��A�ȥd(0:�����[)�B����(2:�����H)*/
       sprintf_s(stmt, sizeof stmt,"SELECT count(*) "
                    "  FROM %s:ply_relation a,%s:ply_ins_type b"
                    " WHERE a.ipolicy = b.ipolicy "
                    "   AND a.ipolicy = '%s'  "
                    "   AND b.iins_type != '50' ",sFullName,sFullName,irelative_ply);
       $PREPARE outply_50 FROM $stmt;
	     $EXECUTE outply_50 INTO $out_ply_50;
	     
	     /* �e�~�O�� (����)�u�O47�I��-����(1:�����H) */
	     sprintf_s(stmt, sizeof stmt,"SELECT count(*) "
                    "  FROM %s:ply_relation a,%s:ply_ins_type b"
                    " WHERE a.ipolicy = b.ipolicy "
                    "   AND a.ipolicy = '%s'  "
                    "   AND b.iins_type != '47' ",sFullName,sFullName,irelative_ply);
       $PREPARE outply_47 FROM $stmt;
	     $EXECUTE outply_47 INTO $out_ply_47;
       
       /* �Y���������ŭ�,�h�L�X������ */
       if(strlen(trim(iengine)) == 0) strcpy(iengine,ibody);

       /* �O�I�ҦL�s */
       put_body();  
                  
       sprintf_s(stmt, sizeof stmt,"UPDATE %s:ply_relation " 
                    "   SET fprint = '1' "
                    " WHERE ipolicy= '%s' " ,sFullName,ipolicy);
       $PREPARE up_fprint FROM $stmt;
	     $EXECUTE up_fprint;
	     
       sprintf_s(stmt, sizeof stmt,"UPDATE %s:ori_ply_relation " 
                    "   SET fprint = '1' "
                    " WHERE ipolicy= '%s' " ,sFullName,ipolicy);
       $PREPARE up_fprint1 FROM $stmt;
	     $EXECUTE up_fprint1;

     }
     $CLOSE COMP_CUR;
     $FREE  COMP_CUR;
     
    rgu_finish_report();    
    
    $UPDATE cu_code_data
        SET ncode = 'Y'
      WHERE itype = 'OT'
	AND icode = '2033';
    
    return M_CM_OK;

errexit:
    printf("-- Query_card -- SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*----------------------------------------------------------------------------*/
void put_body()
{
		char tmpbuf[150],tmpbuf1[150];
		char tmpicard[21];
		char yy[10],mm[10],dd[10];
		int i;
		char  *ilocation;
                char  s_qcylinder_tail[4];
                char  s_qcylinder[9];
		char yy_s[10],mm_s[10],dd_s[10], xqperiod[3];
		char yy_e[10],mm_e[10],dd_e[10], yy_o[10];
		char nbrand_abbr_again[14];
		char ch_amt01[40], ch_amt02[40],ch_amt03[40],ch_amt04[40],ch_amt05[40];
		printf("---------- put_body ------------------\n");
		strcpy(tmpicard,"�Ҹ�:");
		strcpy(icard,trim(icard));
		strcat(tmpicard,icard);
		printf("tmpicard==>[%s]\n",tmpicard);

		
		rate_date=cm_ymd_cdate(cm_from_infdate_100(dply_begin));
		if ((ipolicy[0]!='\0')&&(ipolicy[0]!=' '))
		{
			/*if ((itag[0]!='\0')&&(itag[0]!=' '))
			{ strcpy(Inumber, itag); }
			else
			{ strcpy(Inumber, iengine); }*/
		}
		else
		{
			strcpy(fyear,"NNN");
		}

		for(i=0;i<3;i++)
		{
    		printf("ca_accident[%d]:[%c]%ld\n",i,fyear[i],qlia[i]);
    		if (fyear[i]=='Y')
       			strcpy(s_qlia[i],itoa(qlia[i]));
    		else
       			strcpy(s_qlia[i]," ");
  	}
    strcpy(ch_amt03," ");
		if(mpremium==0)  /* �O�O */
    {
				rgu_put_body_string(17,"",RIGHT);
				rgu_put_body_string(17,"",RIGHT);
				rgu_put_body_string(17,"",RIGHT);
				rgu_put_body_string(17,"",RIGHT);
				rgu_put_body_string(17,"",RIGHT);
				rgu_put_body_string(47,"",RIGHT);
				rgu_put_body_string(47,"",RIGHT);
				rgu_put_body_string(47,"",RIGHT);
				rgu_put_body_string(47,"",RIGHT);
				rgu_put_body_string(47,"",RIGHT);
				strcpy(ch_amt01," ");		/* �U */
				strcpy(ch_amt02," ");		/* �d */
				strcpy(ch_amt03," ");		/* �� */
				strcpy(ch_amt04," ");		/* �B */
				strcpy(ch_amt05," ");		/* �� */
				
		}
		else
		{
       strcpy(mpremium_buf,refmtamt(mpremium,MILLIONTH));
       /* rgu_put_body_string(26,rtrim(mpremium_buf),LEFT); */

       tmp_prem=mpremium/10000;
       other_prem=mpremium%10000;
       num_to_chinese(ch_amt,tmp_prem); /* �N���ԧB�Ʀr �ন ����j�g�Ʀr */
       
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       	 
       strcpy(ch_amt01, ch_amt);
       strcpy(ch_amt01, trim(ch_amt01));
       rgu_put_body_string(17,ch_amt,RIGHT);
       rgu_put_body_string(47,ch_amt,RIGHT);
       
       tmp_prem=other_prem/1000;
       other_prem=other_prem%1000;
       num_to_chinese(ch_amt,tmp_prem);

       if (tmp_prem==0) strcpy(ch_amt,"�s");

       strcpy(ch_amt02, ch_amt);
       strcpy(ch_amt02, trim(ch_amt02));
       rgu_put_body_string(17,ch_amt,RIGHT);
       rgu_put_body_string(47,ch_amt,RIGHT);

       tmp_prem=other_prem/100;
       other_prem=other_prem%100;
       num_to_chinese(ch_amt,tmp_prem);
       
       printf("3:ch_amt=[%s]\n",ch_amt);
       if (tmp_prem==0) strcpy(ch_amt,"�s");

			 strcpy(ch_amt03,ch_amt);
			 strcpy(ch_amt03, trim(ch_amt03));
       rgu_put_body_string(17,ch_amt,RIGHT);
       rgu_put_body_string(47,ch_amt,RIGHT);
       
       tmp_prem=other_prem/10;
       other_prem=other_prem%10;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");

			 strcpy(ch_amt04,ch_amt);
			 strcpy(ch_amt04,trim(ch_amt04));
       rgu_put_body_string(17,ch_amt,RIGHT);
       rgu_put_body_string(47,ch_amt,RIGHT);
       
       num_to_chinese(ch_amt,other_prem);
       if (other_prem==0)
       		strcpy(ch_amt,"�s");

			 strcpy(ch_amt05,ch_amt);
			 strcpy(ch_amt05,trim(ch_amt05));
       rgu_put_body_string(17,ch_amt,RIGHT);
       rgu_put_body_string(47,ch_amt,RIGHT);
		}
		
		  strcpy(outpolicy,"~~"); /* �e��X�T�w�r�� */
      strcat(outpolicy,fmail_type); /* �l�H�覡 */
      if ((strncmp(icar_type,"01",2) == 0) || (strncmp(icar_type,"02",2) == 0) || 
      	  (strncmp(icar_type,"32",2) == 0) || (strncmp(icar_type,"34",2) == 0) || (strncmp(icar_type,"35",2) == 0)){
        strcat(outpolicy,"1"); /* ���� */
        strcat(outpolicy,"0"); /* �����@�ߤ����[�O��A�ȥd */
      }
      else {
        strcat(outpolicy,"2"); /* �T�� */
        strcat(outpolicy,"0"); /* �j���I�@�ߤ����[�O��A�ȥd */
        /*
        if (out_ply_50 > 0) strcat(outpolicy,"1");
        else strcat(outpolicy,"0");  �u�O50�I��,�����[�O��A�ȥd */
      }
      if (strncmp(iroute,"JB",2) == 0) strcat(outpolicy,"1"); /* ���� */
      else strcat(outpolicy,"0");
      
      if ((strncmp(icar_type,"01",2) == 0) || (strncmp(icar_type,"02",2) == 0) || 
      	  (strncmp(icar_type,"32",2) == 0) || (strncmp(icar_type,"34",2) == 0) || (strncmp(icar_type,"35",2) == 0)){
        if (out_ply_47 > 0) strcat(outpolicy,"0"); 
        else strcat(outpolicy,"1"); /* �u�O47�I��,���������H���� */      
      }
      else {
        if (out_ply_50 > 0)
        {
        	if (strcmp(fcar_class,"2") == 0)
        		strcat(outpolicy,"3");
        	else
        		strcat(outpolicy,"0");
        }
        else strcat(outpolicy,"2"); /* �u�O50�I��,�T�������H���� */
      }
      /* �s�±��ڤ��e(�j���I�������ڡA�@�ߵ�0) */
      strcat(outpolicy,"0");

      strcat(outpolicy,"0000000");
      rgu_put_body_string(63,outpolicy,LEFT);
      rgu_put_body(63);

		  rgu_put_body(1);
		  rgu_put_body(1);   
		  rgu_put_body(1);
  
  	/* �Ĥ@�p */
		split_ch(nassured,tmpbuf,tmpbuf1,30);
  	/*if (*fsex == '1')
    		strcat(tmpbuf," �g");
  	else if (*fsex == '2')
    		strcat(tmpbuf," �g");*/
		tmpbuf[30]=0;
		tmpbuf1[30]=0;
		rgu_put_body_string(11,tmpbuf,LEFT);	/* �Q�O�I�H */
		rgu_put_body_string(21,tmpbuf,LEFT);	/* �Q�O�I�H */
		rgu_put_body_string(41,tmpbuf,LEFT);	/* �Q�O�I�H */
		rgu_put_body_string(51," ",LEFT);
		rgu_put_body_string(51,tmpbuf,LEFT);	/* �Q�O�I�H */
		rgu_put_body_string(52,tmpbuf,LEFT);	/* �Q�O�I�H */
		rgu_put_body(11);
		
		split_ch(aassured,tmpbuf,tmpbuf1,30);
		if (strlen(tmpbuf1)==0) {
				rgu_put_body_string(12," ",LEFT);
		    rgu_put_body_string(13,tmpbuf,LEFT);
		    rgu_put_body_string(42," ",LEFT);
		    rgu_put_body_string(43,tmpbuf,LEFT);
		}
  	else {
				rgu_put_body_string(12,tmpbuf,LEFT);
				rgu_put_body_string(13,tmpbuf1,LEFT);
				rgu_put_body_string(42,tmpbuf,LEFT);
				rgu_put_body_string(43,tmpbuf1,LEFT);
		}
		rgu_put_body(12);	/* �q�T�B�Ĥ@�� */
		rgu_put_body(13); /* �q�T�B�ĤG�� */
		rgu_put_body(1);	/* �Ť@�� */
		rgu_put_body_string(14,substring(ncar_abbr,1,6),LEFT);		/* ���� */
		rgu_put_body_string(14,substring(nbrand_abbr_1,1,8),LEFT);	/* �t�P */

		
		strcpy(yy_o,iissue_ym);
		yy_o[3]=0;
		rgu_put_body_string(14,yy_o,LEFT);		/* �o�Ӧ~�� */
		
		
		/* car9901133 �Y��ܤ��L���P,�h���P���M���ť� */
		itag[12]= '\0';
		iengine[21]='\0';
					
		rgu_put_body_string(14,itag,LEFT);			/* ���P */
		rgu_put_body_string(14,iengine,LEFT);	/* ������ */
		
		rgu_put_body_string(44,substring(ncar_abbr,1,6),LEFT);		/* ���� */
		rgu_put_body_string(44,substring(nbrand_abbr_1,1,8),LEFT);	/* �t�P */
		rgu_put_body_string(44,yy_o,LEFT);		/* �o�Ӧ~�� */	
		rgu_put_body_string(44,itag,LEFT);			/* ���P */	
		rgu_put_body_string(44,iengine,LEFT);	/* ������ */
				
		rgu_put_body(14);
		/* �O�I�_�� */
		if(dply_begin[0]==0)
		{		
		     rgu_put_body_string(15,"",LEFT);
		     rgu_put_body_string(15,"",LEFT);
		     rgu_put_body_string(15,"",LEFT);
		     rgu_put_body_string(22,"",LEFT);
		     rgu_put_body_string(22,"",LEFT);
		     rgu_put_body_string(22,"",LEFT);
		     rgu_put_body_string(22,trim(bcard1),LEFT);		/* �«O�I�Ҹ��X */
		     rgu_put_body_string(45,"",LEFT);
		     rgu_put_body_string(45,"",LEFT);
		     rgu_put_body_string(45,"",LEFT);
		}else{
		     strcpy(tmpbuf,cm_from_infdate_100(dply_begin));
		     cm_split_ymd_100(tmpbuf,yy,mm,dd);
		     rgu_put_body_string(15,yy,LEFT);
		     rgu_put_body_string(15,mm,LEFT);
		     rgu_put_body_string(15,dd,LEFT);
		     rgu_put_body_string(22,yy,LEFT);
		     rgu_put_body_string(22,mm,LEFT);
		     rgu_put_body_string(22,dd,LEFT);
		     rgu_put_body_string(22,trim(bcard1),LEFT);		/* �«O�I�Ҹ��X */
		     rgu_put_body_string(45,yy,LEFT);
		     rgu_put_body_string(45,mm,LEFT);
		     rgu_put_body_string(45,dd,LEFT);
		}
		
		/* �O�I���� */
		if(dply_end[0]==0)
		{
		    rgu_put_body_string(16,"",LEFT);
		    rgu_put_body_string(16,"",LEFT);
		    rgu_put_body_string(16,"",LEFT);
		    rgu_put_body_string(23,"",LEFT);
		    rgu_put_body_string(23,"",LEFT);
		    rgu_put_body_string(23,"",LEFT);
		    rgu_put_body_string(46,"",LEFT);
		    rgu_put_body_string(46,"",LEFT);
		    rgu_put_body_string(46,"",LEFT);
		} else
		{
		    strcpy(tmpbuf,cm_from_infdate_100(dply_end));
		    cm_split_ymd_100(tmpbuf,yy,mm,dd);
		    rgu_put_body_string(16,yy,LEFT);
		    rgu_put_body_string(16,mm,LEFT);
		    rgu_put_body_string(16,dd,LEFT);
		    rgu_put_body_string(23,yy,LEFT);
		    rgu_put_body_string(23,mm,LEFT);
		    rgu_put_body_string(23,dd,LEFT);
		    rgu_put_body_string(46,yy,LEFT);
		    rgu_put_body_string(46,mm,LEFT);
		    rgu_put_body_string(46,dd,LEFT);
		}
		
		/* �~�� */	
		if(qperiod==0)
		{
				rgu_put_body_string(16,qperiod,LEFT);
				rgu_put_body_string(23,qperiod,LEFT);
				rgu_put_body_string(46,qperiod,LEFT);
		} 
		else
		{
		     strcpy(tmpbuf,itoa(qperiod));
		     rgu_put_body_string(16,tmpbuf,LEFT);
		     rgu_put_body_string(23,tmpbuf,LEFT);
		     rgu_put_body_string(46,tmpbuf,LEFT);
		}
		rgu_put_body(15);
		rgu_put_body(16);
		rgu_put_body(1);
		rgu_put_body(1);
		rgu_put_body(17);		/* �O�O(����j�g) */
		rgu_put_body(1);
		rgu_put_body_string(60,ileader,RIGHT);	/* �޲z�H */
		if  (policy_y == 'Y')
    {
       rgu_put_body_string(18,syy,RIGHT);
       rgu_put_body_string(18,smm,RIGHT);
       rgu_put_body_string(18,sdd,RIGHT);
       rgu_put_body_string(27,syy,RIGHT);
       rgu_put_body_string(27,smm,RIGHT);
       rgu_put_body_string(27,sdd,RIGHT);
       rgu_put_body_string(48,syy,RIGHT);
       rgu_put_body_string(48,smm,RIGHT);
       rgu_put_body_string(48,sdd,RIGHT);
       rgu_put_body_string(59,syy,RIGHT);
       rgu_put_body_string(59,smm,RIGHT);
       rgu_put_body_string(59,sdd,RIGHT);
       rgu_put_body_string(60,syy,RIGHT);
       rgu_put_body_string(60,smm,RIGHT);
       rgu_put_body_string(60,sdd,RIGHT);
    }else {
    	 rgu_put_body_string(18," ",RIGHT);
       rgu_put_body_string(18," ",RIGHT);
       rgu_put_body_string(18," ",RIGHT);
       rgu_put_body_string(27," ",RIGHT);
       rgu_put_body_string(27," ",RIGHT);
       rgu_put_body_string(27," ",RIGHT);
       rgu_put_body_string(48," ",RIGHT);
       rgu_put_body_string(48," ",RIGHT);
       rgu_put_body_string(48," ",RIGHT);
       rgu_put_body_string(59," ",RIGHT);
       rgu_put_body_string(59," ",RIGHT);
       rgu_put_body_string(59," ",RIGHT);
       rgu_put_body_string(60," ",RIGHT);
       rgu_put_body_string(60," ",RIGHT);
       rgu_put_body_string(60," ",RIGHT);
		}
    rgu_put_body(18);		/* ñ��� */
		rgu_put_body(1);
		/* rgu_put_body(1); */
		/* �վ����T�d�ߧǸ����Ҹ���� modify by larry 103.07.21 (1030211007_C1) */
		rgu_put_body_string(62, iquery_num,LEFT);
		rgu_put_body_string(62,tmpicard,LEFT);	
		rgu_put_body(62);
		rgu_put_body(1);
		rgu_put_body(1);
		/* �O�I�үd�s���  */
		rgu_put_body_string(21,ipolicy,LEFT);
		rgu_put_body(21);		/* �Q�O�I�H & �j��O�渹 */
		rgu_put_body(1);		/* �Ť@�� */
		rgu_put_body(22);		/* �O�I�_�� & �«O�I�Ҹ��X */
		strcpy(irelative_ply, trim(irelative_ply));
		rgu_put_body_string(23,irelative_ply,LEFT);
		rgu_put_body(23);		/* �O�I���� */
		
		if (strncmp(ilicense," ",1)==0)
		{
	            if (strncmp(iassured,"AAAAAAAAAA",10)!=0)
	                strcpy(ilicense,iassured);
                }
    
		for(i=0;i<10;i++) 
		{
				strncpy(tmpbuf,ilicense+i,1);
				tmpbuf[1]='\0';
				rgu_put_body_string(24,tmpbuf,LEFT);
		}
		rgu_put_body_string(24,trim(irelative_card),LEFT);		/* ���N�I�d�� */
		rgu_put_body(24);
		
		rgu_put_body_string(25,substring(ncar_abbr,1,8),LEFT);		/* ���� */
		rgu_put_body_string(55,substring(ncar_abbr,1,8),LEFT);		/* ���� */
		rgu_put_body_string(25,yy_o,LEFT);		/* �o�Ӧ~�� */
		rgu_put_body_string(55,yy_o,LEFT);		/* �o�Ӧ~�� */
		rgu_put_body_string(25,itag,LEFT);			/* ���P */
		rgu_put_body_string(55,itag,LEFT);			/* ���P */
		/* rgu_put_body_string(25,tmpicard,LEFT);		 �j���Ҹ� */
		rgu_put_body_string(25,fcomp_class,LEFT);		/* �����Y�� */
		rgu_put_body(25);
		rgu_put_body_string(26,substring(nbrand_abbr_1,1,8),RIGHT);	/* �t�P */
		rgu_put_body_string(57,substring(nbrand_abbr_1,1,8),RIGHT);	/* �t�P */
		rgu_put_body_string(58,substring(nbrand_abbr_1,1,8),RIGHT);	/* �t�P */

		/* �Ʈ�q */
		if (qcylinder == 0 && strncmp(icar_type,"35",2) != 0)
                { 
    		    rgu_put_body_string(26,"",LEFT);		
    		    rgu_put_body_string(57,"",LEFT);		
    		    rgu_put_body_string(58,"",LEFT);		
		}
                else
                { 
		    strcpy(s_qcylinder,"");	
		    sprintf_s(s_qcylinder, sizeof s_qcylinder,"%5.2f",qcylinder);
		    strcpy(s_qcylinder,trim(s_qcylinder) );
		    /*�Ʈ�q���ƧP�_�A�Y�O .00 �h�ٲ������*/
		    strcpy(s_qcylinder_tail,"");
                    ilocation = strstr(s_qcylinder, ".");
                    printf("�Ʈ�q�p��[%d]\n",ilocation-s_qcylinder);
                    printf("�Ʈ�q�p��[%c%c%c]\n",s_qcylinder[ilocation-s_qcylinder],s_qcylinder[ilocation-s_qcylinder+1],s_qcylinder[ilocation-s_qcylinder+2]);
                    sprintf_s(s_qcylinder_tail, sizeof s_qcylinder_tail,"%c%c%c",s_qcylinder[ilocation-s_qcylinder],s_qcylinder[ilocation-s_qcylinder+1],s_qcylinder[ilocation-s_qcylinder+2]);
                    printf("�Ʈ�q�p��[%s]\n",s_qcylinder_tail);
    
                    if(strcmp(s_qcylinder_tail,".00")==0)
                    {
                        s_qcylinder[ilocation-s_qcylinder]='\0';
                    }
                    printf("�Ʈ�q�p��[%s]\n",s_qcylinder);
                    
      	            rgu_put_body_string(26,s_qcylinder,RIGHT);
      	            rgu_put_body_string(57,s_qcylinder,RIGHT);
      	            rgu_put_body_string(58,s_qcylinder,RIGHT);
                }
		rgu_put_body_string(26,iengine,LEFT);				/* ������ */
		rgu_put_body_string(57,iengine,LEFT);				/* ������ */
		rgu_put_body_string(58,iengine,LEFT);				/* ������ */
		
		
		/* �ͤ� */
		if (ibirth[0]==0) 
		{		
				rgu_put_body_string(26,"",LEFT);
	      rgu_put_body_string(26,"",LEFT);
	      rgu_put_body_string(26,"",LEFT);
	  }else{
	      cm_split_ymd_100(ibirth,yy,mm,dd);
	      rgu_put_body_string(26,yy,LEFT);
	      rgu_put_body_string(26,mm,LEFT);
	      rgu_put_body_string(26,dd,LEFT);
	  }
		/* �ʧO */
	  if(fsex[0]=='1'){
	      rgu_put_body_string(26,"v",LEFT);
	      rgu_put_body_string(26,"",LEFT);
	  }else if(fsex[0]=='2'){
	      rgu_put_body_string(26,"",LEFT);
	      rgu_put_body_string(26,"v",LEFT);
	  }else{
	      rgu_put_body_string(26,"",LEFT);
	      rgu_put_body_string(26,"",LEFT);
	  }
	  /* �B�� */
	  if (fmarriage[0]=='1'){
	      rgu_put_body_string(26,"v",LEFT);
	      rgu_put_body_string(26,"",LEFT);
	  } else if (fmarriage[0]=='2') {
	      rgu_put_body_string(26,"",LEFT);
	      rgu_put_body_string(26,"v",LEFT);
	  }else{
	      rgu_put_body_string(26,"",LEFT); 
	      rgu_put_body_string(26,"",LEFT);
	  }
	  rgu_put_body_string(26,fcomp_class_last,LEFT);		/* �W���Y�� */
	  rgu_put_body(26);
	  rgu_put_body(1);
		rgu_put_body(27);		/* ñ��� */
		/*rgu_put_body_string(62, iquery_num,LEFT);
		rgu_put_body(62);*/
		rgu_put_body(1);
		rgu_put_body(1);
		rgu_put_body_string(31,Iofficer,LEFT); 
    rgu_put_body_string(31,Nofficer,LEFT); 
    rgu_put_body(31);		/* �g��H */
		rgu_put_body(1);
		rgu_put_body(1);
		rgu_put_body(1);
		rgu_put_body(1);
		
		/* �ĤG�p ��Q�O�I�H���� */
		rgu_put_body(41);		/* �Q�O�I�H */
		rgu_put_body(42);		/* �q�T�B�Ĥ@�� */
		rgu_put_body(43);		/* �q�T�B�Ĥ@�� */
		rgu_put_body(1);
		rgu_put_body(44);		/* ����,�t�P,�o�Ӧ~��,���P,������ */
		rgu_put_body(45);		/* �O�I�_����,�~�� */
		rgu_put_body(46);		/* �O�I�_����,�~�� */
		rgu_put_body(1);
		rgu_put_body(1);
		rgu_put_body(47);		/* �O�O */
		rgu_put_body(1);
		rgu_put_body(48);		/* ñ��� */
		
		
		/* �̤U���O�O�βĤT�p */
		rgu_put_body(1);
		rgu_put_body(1);
		rgu_put_body(1);
		rgu_put_body(1);
		rgu_put_body(51);		/* �k��Q�O�I�H */
		
		
		/* �O�I�_�� */
		if(dply_begin[0]==0)
		{		
		     strcpy(yy_s," ");
		     strcpy(mm_s," ");
		     strcpy(dd_s," ");
		}else{
		     strcpy(tmpbuf,cm_from_infdate_100(dply_begin));
		     cm_split_ymd_100(tmpbuf,yy_s,mm_s,dd_s);
		}
		
		/* �O�I���� */
		if(dply_end[0]==0)
		{
		    strcpy(yy_e," ");
		    strcpy(mm_e," ");
		    strcpy(dd_e," ");
		} else
		{
		    strcpy(tmpbuf,cm_from_infdate_100(dply_end));
		    cm_split_ymd_100(tmpbuf,yy_e,mm_e,dd_e);
		}

		/* �~�� */	
    strcpy(xqperiod,itoa(qperiod));
		
		split_ch(aassured,tmpbuf,tmpbuf1,30);
		if (strlen(tmpbuf1)==0) {
				rgu_put_body_string(52," ",LEFT);
				rgu_put_body_string(53,yy_s,LEFT);
	  		        rgu_put_body_string(53,mm_s,LEFT);
				rgu_put_body_string(53,dd_s,LEFT);
				rgu_put_body_string(53,xqperiod,LEFT);
		                rgu_put_body_string(53,tmpbuf,LEFT);
		}
  	        else {
				rgu_put_body_string(52,tmpbuf,LEFT);
				rgu_put_body_string(53,yy_s,LEFT);
	  		        rgu_put_body_string(53,mm_s,LEFT);
				rgu_put_body_string(53,dd_s,LEFT);
				rgu_put_body_string(53,xqperiod,LEFT);
				rgu_put_body_string(53,tmpbuf1,LEFT);
		}
		rgu_put_body(52);	/* �Q�O�I�H & �q�T�B�Ĥ@�� */
		rgu_put_body(53); /* �O�I�_�� & �q�T�B�ĤG�� */

		rgu_put_body_string(54,yy_e,LEFT);
	        rgu_put_body_string(54,mm_e,LEFT);
		rgu_put_body_string(54,dd_e,LEFT);
		rgu_put_body_string(54,yy_s,LEFT);
	        rgu_put_body_string(54,mm_s,LEFT);
		rgu_put_body_string(54,dd_s,LEFT);
		rgu_put_body_string(54,xqperiod,LEFT);
		
		rgu_put_body_string(55,yy_e,LEFT);
	        rgu_put_body_string(55,mm_e,LEFT);
		rgu_put_body_string(55,dd_e,LEFT);
		rgu_put_body(54); /* ���b�O�I���� & �k�b�O�I�_��B���� */
                rgu_put_body(55); /* ���b���ءB�o�Ӧ~��B���P */
                rgu_put_body_string(56,fcomp_class,LEFT);		/* �����Y�� */
                rgu_put_body_string(56,ncar_abbr,LEFT);		/* ���� */
                rgu_put_body_string(56,yy_o,LEFT);		/* �o�Ӧ~�� */
                rgu_put_body_string(56,itag,LEFT);			/* ���P */
 		rgu_put_body(56); /* �k�b���ءB�o�Ӧ~��B���P */
                rgu_put_body_string(57,fcomp_class,LEFT);		/* �����Y�� */
                rgu_put_body(57); /* ���b�t�P�B�Ʈ�q�B�������B�Y�� */
                rgu_put_body(58); /* �k�b�t�P�B�Ʈ�q�B�������B�Y�� */
                rgu_put_body(1); 
    
    printf("ch_amt01=[%s]\n",ch_amt01);
    printf("ch_amt02=[%s]\n",ch_amt02);
    printf("ch_amt03=[%s]\n",ch_amt03);
    printf("ch_amt04=[%s]\n",ch_amt04);
    printf("ch_amt05=[%s]\n",ch_amt05);
    
    rgu_put_body_string(59,ch_amt01,RIGHT);
    rgu_put_body_string(59,ch_amt02,RIGHT);
    rgu_put_body_string(59,ch_amt03,RIGHT);
    rgu_put_body_string(59,ch_amt04,RIGHT);
    rgu_put_body_string(59,ch_amt05,RIGHT);
    rgu_put_body(59); 
    rgu_put_body(1); 
    rgu_put_body(60); 
    rgu_put_body_string(61,Nbranch,RIGHT);
	  rgu_put_body_string(61,Nleader,LEFT);
	  rgu_put_body_string(61,icorps,LEFT);
	  rgu_put_body(61);
	  rgu_put_body(1); 
	  rgu_put_body(1); 
	  /* rgu_put_body(1);  */
   	max_count+=72;
}
/*----------------------------------------------------------------------------*/
int cc_split(s_buf,t_buf,len)
char *s_buf;
char *t_buf;
int len;
{
  int i,flag;

  for(i=0;i<len;) {
    if((unsigned) s_buf[i]>128)  /* �ˬd�O�_������r�A�Y s_buf[i] > 128 ���ܬ�����r */
    {                                    /* �h�@������Ӧr���A�_�@��catch�@�Ӧr�� */
      strncpy(&t_buf[i],&s_buf[i],2);
      t_buf[i+2]='\0';
      i+=2;
    } else {
      strncpy(&t_buf[i],&s_buf[i],1);
      t_buf[i+1]='\0';
      i++;
    }
    if(i>len ) {
      t_buf[i-2]='\0';
      return i-2;
    } else if(i==len ) {
      return i;
    }
  }
}
/*----------------------------------------------------------------------------*/
split_ch(source,s1,s2,l)
char source[],s1[],s2[];
int l;
{
  char oo[200];
  int i;
  strcpy(oo,rtrim(source));
  if (strlen(oo)> l)
  {
    i=cc_split(oo,s1,l);
    strcpy(s2,&oo[i]);
  }else{
    strcpy(s1,oo);
    s2[0]=0;
  }
}
/*------------------------------THE END---------------------------------------*/  
        	
char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
    char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
    /*char sTmp_db_name[21];*/

    sTmp_db_name[0]='\0';
    if (*sIpolicy != '\0' && *sIpolicy !=' ')
    {
        sTmp_db_name[0]='\0';
        strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
        strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
               USE_BRANCH_ID));
        strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
    }        
    return sTmp_db_name;
}        