/*-------------------------------------------------------------------
 * Program: ca425p01s.ec
 * Date   : 08/01/2007
 * Modified Date: 11/23/2007 by Julia Han
 *-------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <ca401field.h>
#include "is_def.h"
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
$include "safeclib.h";
$include datetime;
$include sqlca;
$include sqltypes;
#define FOUND sqlca.sqlcode != SQLNOTFOUND
#define NOT_FOUND sqlca.sqlcode == SQLNOTFOUND
#define LOAD_FAIL -1

/*****************************************************************/

int rc, rc1, rc2, rc3, rc4;

int rec_count, max_count, rec_count_1 = 0, label1 = 0;
$char DBName[5];
char outputf[50];
$char userid[11], iedr_examiner[11];
$char BodyFile[21], TitleFile[21], BodyFmt[21], FormTp[3];
$char TitleFmt[21], prtstr[10000];
$char FormFile[N_FILE + 1], OutFile[20];
$char iedr_field[9];
$int PgLine, Width;
char sMsg[10240];
FILE *sfp, *report, *report1;
char aphome[40];
int res;
char dply_begin[11], dply_end[11];
char v_sMsg[1512], sFileName[101];

/*****************************************************************/

main(argc, argv) int argc;
char **argv;
{
    char option[1];
    puts("============================car425 start=================================");
    batchinit();
    puts("============================end batchinit()=================================");
    strcpy(DBName, isNULLstr(argv[1]));
    strcpy(userid, isNULLstr(argv[2]));
    strcpy(option, isNULLstr(argv[3])); /* E:�j���I���ؾ����      Q:�z��̷s�O�樮�ػP�ʲz�����ؤ��P�����,
                                           D:�d�ߨT���j���I�̷s�O��W���O�O�P���T���Ѥ���O�O�O���Ÿ��
                                           M:�����j���I�L������  P:�O�o�j���Iñ��O�O�ˮָ�Ƥ��
                                           F:�j���I�P�����ʲz��Ʈw����--�H����Ƥ��ũ��� */
    strcpy(dply_begin, isNULLstr(argv[4]));
    strcpy(dply_end, isNULLstr(argv[5]));
    strcpy(sFileName, isNULLstr(argv[6]));
    strcpy(outputf, isNULLstr(argv[7]));
    printf("--sFileName=[%s]\n", sFileName);
    $WHENEVER SQLERROR GOTO errexit;

    sfp = (FILE *)STARTLOG();
    puts("============================end STARTLOG()=================================");

    if (db_select(DBName) == False)
    {
        EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
        return FAIL;
    }
    puts("============================end db_select()=================================");

    res = getApHome(aphome);
    if (res < 0)
    {
        EWRITE(userid, -1, "In sigalrmcatcher func==>read config file error!!");
        return FAIL;
    }
    puts("============================end getApHome()=================================");

    strcpy(iedr_examiner, trim(userid));
    strcat(iedr_examiner, "B"); /* �קאּ�̵n�J�t�Τ�����H���O�����H�����s+B */

    if (option[0] == 'Q')
        rc = car425_Q(); /* �z��̷s�O�樮�ػP�ʲz�����ؤ��P����� */
    else if (option[0] == 'D')
        rc = car425_D(); /* �d�ߨT���j���I�̷s�O��W���O�O�P���T���Ѥ���O�O�O���Ÿ�� */
    else if (option[0] == 'F')
        rc = car425_F(); /* �j���I�P�����ʲz��Ʈw����--�H����Ƥ��ũ��� */
    else if (option[0] == 'E')
    {
        /* ���M����� */
        $DELETE FROM ca_change_car_type WHERE 1 = 1;
        WRITELOG(sfp, "DELETE FROM ca_change_car_type Complete !!");

        $BEGIN WORK;
        rc = car425_E(); /* �NClient�ݪ����insert into ca_change_car_type,�Aselect �X�ӧ娮�� */
        if (rc == LOAD_FAIL)
            ; /* �p�G�O load data ���~���� commit work�]���|�g�Jrptftpinsert���i�H
                 rollback work,���Mcmn202�|�䤣����~log�� */
        else if (rc != M_CM_OK)
        {
            $ROllBACK WORK;
            EWRITE(userid, rc, sMsg);
            return rc;
        }
        $COMMIT WORK;
    }
    else if (option[0] == 'M')
    {
        /* ���M����� */
        $DELETE FROM ca_transfer_assured WHERE 1 = 1;
        WRITELOG(sfp, "DELETE FROM ca_transfer_assured Complete !!");

        $BEGIN WORK;
        rc = car425_M(); /* �NClient�ݪ����insert into ca_transfer_assured,�Aselect �X�ӧ娮�� */
        if (rc == LOAD_FAIL)
            ; /* �p�G�O load data ���~���� commit work�]���|�g�Jrptftpinsert���i�H
                 rollback work,���Mcmn202�|�䤣����~log�� */
        else if (rc != M_CM_OK)
        {
            $ROllBACK WORK;
            EWRITE(userid, rc, sMsg);
            return rc;
        }
        $COMMIT WORK;
    }
    else if (option[0] == 'P') /* �O�o�j���Iñ��O�O�ˮָ�Ƥ�� */
        rc = car425_P();
    else
    {
        EWRITE(userid, -1, "ERROR OPTION");
        return FAIL;
    }

    if (rc != M_CM_OK)
    {
        EWRITE(userid, rc, sMsg);
        return rc;
    }

    WRITELOG(sfp, sMsg);
    ENDLOG(sfp);
    return M_CM_OK;

errexit:
    printf("------car425_err: SQLCODE[%d]\n", SQLCODE);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    exit(1);
}
/* -------------------------------------------------------------------------------*/

long car425_Q()
{
    DBinfo *list;
    int i, count_db;
    $char select_stmt[1024], stmt[1024], sql_stmt[10240], cmd_stmt[20480];
    char FullLogName[50], LogName[30], filename[50], ReportName[30];

    WRITELOG(sfp, " ");
    WRITELOG(sfp, " ");
    WRITELOG(sfp, " ");
    sprintf_s(sMsg, sizeof sMsg, "�����d�߱���G�ͮĤ�[%s] ~ [%s]", dply_begin, dply_end);
    WRITELOG(sfp, sMsg);

    sprintf_s(LogName, sizeof LogName, "car425_query_err_%s.txt", outputf);
    sprintf_s(ReportName, sizeof ReportName, "car425_query_data_%s.txt", outputf);
    sprintf_s(filename, sizeof filename, "%s/rptftp/car425_q.body", aphome);
    sprintf_s(FullLogName, sizeof FullLogName, "%s/rptftp/%s", aphome, LogName);

    if ((list = get_db_list(&count_db, DBName)) == (char *)0)
    {
        EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
        return M_CM_NOT_DBLIST;
    }

    sprintf_s(select_stmt, sizeof select_stmt, "SELECT a.icard, b.iassured, b.itag, a.icar_type, a.fcomp_class, a.mlia_prem, b.nassured, "
                         "       b.dbirth, b.qpt, b.fpt, a.ipolicy, a.ibrand, a.dtransfer, "
                         "       c.iassured_1, c.itag_1, c.icar_type_1, c.nassured nassured_1, c.dbirthday_1,"
                         "       c.qpt_1, c.fpt_1, c.ierr_code, a.inext_ply,");

    sprintf_s(sql_stmt, sizeof sql_stmt, "%s a.fcomp_class fnext_comp_class "
                      "   FROM ply_relation a, policy b, ca_trade_diff c"
                      "  WHERE 1 = 0 INTO TEMP car425;\r\n",
            select_stmt);

    printf("sql_stmt[%s]\n", sql_stmt);

    for (i = 0; i < count_db; i++)
    {
        sprintf_s(stmt, sizeof stmt, " INSERT INTO car425"
                      " %s "
                      "        (SELECT fcomp_class FROM %s:ply_relation WHERE ipolicy = a.inext_ply) fnext_comp_class"
                      "   FROM %s:ply_relation a, %s:policy b, ca_trade_diff c"
                      "  WHERE a.ipolicy = b.ipolicy"
                      "    AND a.icard = c.icard[3,17]"
                      "    AND dply_begin between '%s' and '%s'"
                      "    AND a.icar_type <> c.icar_type_1"
                      "    AND a.fcard_class = '1';\r\n",
                select_stmt, list[i].dbname, list[i].dbname, list[i].dbname, dply_begin, dply_end);
        strcat(sql_stmt, stmt);
    }

    sprintf_s(stmt, sizeof stmt, "UNLOAD to %s delimiter '\t' "
                  "SELECT * FROM car425;\r\n",
            filename);

    strcat(sql_stmt, stmt);

    sprintf_s(cmd_stmt, sizeof cmd_stmt, "dbaccess %s > %s 2>&1 << !\r\n%s\r\n!", list[0].dbname, FullLogName, sql_stmt);

    printf("cmd_stmt[%s]\n", cmd_stmt);

    rc = system(cmd_stmt);
    printf("system rc[%d]\n", rc);
    if (rc != 0)
    {
        sprintf_s(sMsg, sizeof sMsg, "��Ƭd�߿��~,���I���ɮפU���@�~�d��[Q], �U���ɦW:[%s]�T�w���~��]", LogName);

        rc1 = rptftpinsert(userid, "car425", LogName);
        printf("rc1[%d]\n", rc1);
        if (rc1 != 0)
        {
            sprintf_s(sMsg, sizeof sMsg, "�g�Jrptftplist���~\r\n");
            return rc;
        }

        return rc;
    }

    /*�@�X�ּ��D */
    sprintf_s(cmd_stmt, sizeof cmd_stmt,
            "cd %s/rptftp/;"
            "cat ../form/car425_q.head car425_q.body > %s ;"
            "rm -f car425_q.body;",
            aphome, ReportName);

    printf("cmd_stmt=[%s]\r\n", cmd_stmt);
    rc = system(cmd_stmt);
    if (rc != 0)
    {
        printf("cat file���~\r\n");
        sprintf_s(sMsg, sizeof sMsg, "cat file���~\r\n");
        return rc;
    }

    rc = rptftpinsert(userid, "car425", ReportName);
    printf("rptftpinsert rc[%d]\n", rc);
    if (rc != 0)
    {
        sprintf_s(sMsg, sizeof sMsg, "�g�Jrptftplist���~\r\n");
        return rc;
    }

    sprintf_s(sMsg, sizeof sMsg, "�d�ߧ���,���I���ɮפU���@�~�d��[Q],�U��[%s] \r\n", ReportName);
    return M_CM_OK;

errexit:
    printf("sqlerrcode=%d, sqlerrmsg=%s\n", SQLCODE, sqlca.sqlerrm);
    sprintf_s(sMsg, sizeof sMsg, "sqlerrcode=%d, sqlerrmsg=%s\n", SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}

/* -------------------------------------------------------------------------------*/

long car425_D()
{
    DBinfo *list;
    int i, count_db;
    $char select_stmt[1024], stmt[1024], sql_stmt[10240], cmd_stmt[20480];
    char FullLogName[60], LogName[36], FullBodyName[50], BodyName[30], ReportName[30];

    WRITELOG(sfp, " ");
    WRITELOG(sfp, " ");
    WRITELOG(sfp, " ");
    sprintf_s(sMsg, sizeof sMsg, "�����d�߱���Gñ���[%s] ~ [%s]", dply_begin, dply_end);
    WRITELOG(sfp, sMsg);

    sprintf_s(LogName, sizeof LogName, "car425_prem_diff_err_%s.txt", outputf);
    sprintf_s(BodyName, sizeof BodyName, "car425_prem_diff_%s.body", outputf);
    sprintf_s(ReportName, sizeof ReportName, "car425_prem_diff_%s.txt", outputf);
    sprintf_s(FullBodyName, sizeof FullBodyName, "%s/rptftp/%s", aphome, BodyName);
    sprintf_s(FullLogName, sizeof FullLogName, "%s/rptftp/%s", aphome, LogName);
    
    printf("FullBodyName[%s]\n", FullBodyName);
    printf("FullLogName[%s]\n", FullLogName);

    if ((list = get_db_list(&count_db, DBName)) == (char *)0)
    {
        EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
        return M_CM_NOT_DBLIST;
    }

    sprintf_s(select_stmt, sizeof select_stmt, "SELECT ilast_ply, ilast_card, a.icard, a.ipolicy, nassured, iassured, itag, fsex,"
                         "       dbirth, icar_type, qpt, fpt, fcomp_class, qdrunk_driving, mdrunk_prem, mlia_prem,  "
                         "       mprem, dpolicy, mbus_rule, dply_begin, a.iofficer, e.nbranch, f.nname,mviolate_prem,qviolate");

    sprintf_s(sql_stmt, sizeof sql_stmt, "%s FROM ply_relation a, policy b, ply_ins_type c, officer d, sa_branch_type e, officer f"
                      "  WHERE 1 = 0 INTO TEMP car425_prem_diff;\r\n",
            select_stmt);

    printf("sql_stmt[%s]\n", sql_stmt);

    for (i = 0; i < count_db; i++)
    {
        sprintf_s(stmt, sizeof stmt, " INSERT INTO car425_prem_diff"
                      " %s "
                      "   FROM %s:ply_relation a, %s:policy b, %s:ply_ins_type c, officer d, sa_branch_type e, officer f"
                      "  WHERE a.ipolicy = b.ipolicy "
                      "    AND a.ipolicy = c.ipolicy "
                      "    AND dpolicy between '%s' and '%s'"
                      "    AND dply_close is not null "
                      "    AND fcard_class = '1' "
                      "    AND mprem <>0 "
                      "    AND icar_type not in ('01','02','32','34','35')"
                      "    AND a.iofficer = d.iofficer"
                      "    AND d.ileader = f.iofficer"
                      "    AND d.iquota = e.ibranch; \r\n",
                select_stmt, list[i].dbname, list[i].dbname, list[i].dbname, dply_begin, dply_end);
        strcat(sql_stmt, stmt);
    }

    sprintf_s(stmt, sizeof stmt, " create index x1 on car425_prem_diff ( itag);\r\n"
                  " create index x2 on car425_prem_diff ( iassured);\r\n");

    strcat(sql_stmt, stmt);

    /* �H�Q�O�I�HID,�M�����ۦP�A�B���T��O����餧�e�T�Ӥ뤧��@�Ӥ�ͮĪ��O��
       ñ��O�O�j�����T��O�O�O �� ���T��O�O�O - ñ��O�O > �W���~�ȶO��
       ���T��O�O�O��0�����(98/12/8౻T����) */

    sprintf_s(stmt, sizeof stmt, "UNLOAD to %s delimiter '\t' "
                  "SELECT a.icard, a.nassured, a.iassured, a.itag, a.fsex, a.dbirthday,"
                  "       a.icar_type, a.qpt, a.fpt, a.ilevel_new, a.qdrunk_driving, a.mdrunk_prem, a.prem_21_std,a.mviolate_prem,a.qviolate,"
                  "       '�e���O���T���A�᭱�O���s���', b.* "
                  "  FROM ca_trade_renew a, car425_prem_diff b "
                  " WHERE a.iassured = b.iassured "
                  "   AND a.itag = b.itag "
                  "   AND a.dply_end BETWEEN date_add( b.dply_begin, interval(-3) month to month)"
                  "   AND date_add( b.dply_begin, interval(1) month to month)"
                  "   AND ( (b.mlia_prem > a.prem_21_std) or (a.prem_21_std - b.mlia_prem > b.mbus_rule)); \r\n",
            FullBodyName);

    strcat(sql_stmt, stmt);

    sprintf_s(cmd_stmt, sizeof cmd_stmt, "dbaccess %s > %s 2>&1 << !\r\n%s\r\n!", list[0].dbname, FullLogName, sql_stmt);

    printf("cmd_stmt[%s]\n", cmd_stmt);

    rc = system(cmd_stmt);
    printf("system rc[%d]\n", rc);
    if (rc != 0)
    {
        printf("1system rc[%d]\n", rc);
        sprintf_s(sMsg, sizeof sMsg, "��Ƭd�߿��~,���I���ɮפU���@�~�d��[Q], �U���ɦW:[%s]�T�w���~��]", LogName);
        printf("2system rc[%d]\n", rc);
        printf("1 sMsg[%s]\n", sMsg);
        rc1 = rptftpinsert(userid, "car425", LogName);
        printf("rc1[%d]\n", rc1);
        if (rc1 != 0)
        {
            sprintf_s(sMsg, sizeof sMsg, "[%s]�g�Jrptftplist���~\r\n", LogName);
            return rc;
        }

        return rc;
    }

    /*�@�X�ּ��D */
    sprintf_s(cmd_stmt, sizeof cmd_stmt,
            "cd %s/rptftp/;"
            "cat ../form/car425_prem_diff.head %s > %s;"
            "rm -f %s;",
            aphome, BodyName, ReportName, BodyName);

    printf("cmd_stmt=[%s]\r\n", cmd_stmt);
    rc = system(cmd_stmt);
    if (rc != 0)
    {
        printf("cat file���~\r\n");
        sprintf_s(sMsg, sizeof sMsg, "cat file���~\r\n");
        return rc;
    }

    rc = rptftpinsert(userid, "car425", ReportName);
    printf("rptftpinsert rc[%d]\n", rc);
    if (rc != 0)
    {
        sprintf_s(sMsg, sizeof sMsg, "[%s]�g�Jrptftplist���~\r\n", ReportName);
        return rc;
    }

    sprintf_s(sMsg, sizeof sMsg, "�d�ߧ���,���I���ɮפU���@�~�d��[Q],�U��[%s] \r\n", ReportName);
    return M_CM_OK;

errexit:
    printf("sqlerrcode=%d, sqlerrmsg=%s\n", SQLCODE, sqlca.sqlerrm);
    sprintf_s(sMsg, sizeof sMsg, "sqlerrcode=%d, sqlerrmsg=%s\n", SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}

long car425_E()
{

    $char sIpolicy[21], sIcard[21], sItag[CA_TAG_NUM], sIassured[11], sIcar_type[3];           /* client�ݱNuser���Ѫ�����諸����� */
    $char ipolicy[21], icard[21], itag[CA_TAG_NUM], iassured[11], icar_type[3], nassured[121]; /* �̷s�O���ɸ�� */
    $char iendorse[21];
    char payresult[5], paystatus[100], paydate[100], notedate[100];
    char policy_1[POLICY_NUM_1], policy_2[POLICY_NUM_2];

    char sIcomp_in[BRANCH_ID], sIbranch_in[BRANCH_ID];
    char sIcomp_in_short[BRANCH_ID];
    char sIbranchIcomp[CA_POL_BRH_NUM];
    char sIbilling[3];

    $char ibatch_no[11], iquota[11], ileader[11], iofficer[11];
    int iCount, iTmp;
    char FullGetName[101], FullLogName[101], FullRptName[101];
    char GetName[51], LogName[51], RptName[51], TmpName[51];
    char sIupcompShort[2], policyDB[21], policyDBname[41];
    char local_dbname[41], sData[2048];
    $char stmt[20480], cmd_stmt[20480], datetime[12];
    $char fedr_class[2];
    long tt;
    $long dwritten;
    $char dlock[31], iroute[21], iroute_accept_edr[21];
    $char feply[2] = " ", tmobile_eply[21] = " ", aemail_eply[51] = " "; /*1090831006_SC2 �{�ҥ��x�j��q�l���ҥ���g�����mail�ˮ�*/
    $char tmobile_appl[21] = " ", aemail_appl[51] = " ", s_notifyornot[21] = "", fcard_class[2] = " ";
    $datetime year to second dnotifyornot;

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(local_dbname, get_full_dbname(DBName));

    $select first 1 current month to minute
        into $datetime
            from system_var;

    /* client�ݱNuser���Ѫ�����諸�����ftp��/dat/car/car425_e.txt */
    sprintf_s(GetName, sizeof GetName, "car425_e.txt");
    sprintf_s(LogName, sizeof LogName, "car425_load_err_%s.txt", outputf);
    sprintf_s(RptName, sizeof RptName, "car425_report.body", outputf);
    sprintf_s(FullGetName, sizeof FullGetName, "%s/dat/car/%s", aphome, GetName);
    sprintf_s(FullLogName, sizeof FullLogName, "%s/rptftp/%s", aphome, LogName);
    sprintf_s(FullRptName, sizeof FullRptName, "%s/rptftp/%s", aphome, RptName);

    if ((report = fopen(FullRptName, "w")) == NULL)
    {
        sprintf_s(sMsg, sizeof sMsg, "Cannot open Ouput file: %s\n", FullRptName);
        printf("%s", sMsg);
        return M_CM_OPEN_FILE_FAIL;
    }

    printf("FullGetName[%s]\n", FullGetName);

    sprintf_s(stmt, sizeof stmt, "load from %s delimiter '\t' \r\n"
                  "insert into ca_change_car_type; \r\n",
            FullGetName);
    sprintf_s(cmd_stmt, sizeof cmd_stmt, "dbaccess %s > %s 2>&1 << !\r\n"
                      "%s\r\n!",
            local_dbname, FullLogName, stmt);

    printf("cmd_stmt[%s]\n", cmd_stmt);

    rc = system(cmd_stmt);
    if (rc != 0)
    {
        sprintf_s(sMsg, sizeof sMsg, "���J������Ƶo�Ϳ��~\r\n"
                      "���I���ɮפU���@�~�d��[Q],�ɦW:[%s]�T�w���~��]",
                LogName);
        printf("sMsg[%s]\n", sMsg);
        rc1 = rptftpinsert(userid, "car425", LogName);
        printf("rc1[%d]\n", rc1);
        if (rc1 != 0)
        {
            sprintf_s(sMsg, sizeof sMsg, "%s�g�Jrptftplist���~\r\n", LogName);
            return LOAD_FAIL;
        }

        return LOAD_FAIL;
    }

    sprintf_s(sMsg, sizeof sMsg, "Loading %s to ca_change_car_type Complete!!\n", FullGetName);
    printf("sMsg[%s]\n", sMsg);
    WRITELOG(sfp, sMsg);

    /* -------------------------------------------------------*/
    /* ���o���椧�t�Τ�� */
    rtoday(&dwritten);

    memset(&iedr_field, 0, sizeof(iedr_field));

    for (iTmp = 0; iTmp < 8; iTmp++)
        FLD_SET(iedr_field, iTmp * 8 + 7);

    FLD_SET(iedr_field, 16); /* ��郞�� */

    iCount = 0;
    max_count = 0;

    $DECLARE curs1 CURSOR FOR
        SELECT ipolicy,
        icard, iassured, itag, icar_type FROM ca_change_car_type;

    $OPEN curs1;
    for (;;)
    {
        $FETCH curs1 INTO $sIpolicy, $sIcard, $sIassured, $sItag, $sIcar_type;

        if (SQLCODE == SQLNOTFOUND)
            break;

        sIupcompShort[0] = sIpolicy[2]; /* �O�渹�ĤT�X */
        sIupcompShort[1] = '\0';
        strcpy(policyDB, get_upcomp(sIupcompShort, USE_SHORT_BRANCH_ID, USE_BRANCH_ID));
        strcpy(policyDBname, get_full_dbname(policyDB));

        printf("user��client�ݴ��Ѥ��O�渹[%s][%s], �j���Ҹ�[%s]�B�Q�O�I�HID[%s]�B���P���X[%s]�B���ᨮ��[%s]\n",
               sIpolicy, policyDBname, sIcard, sIassured, sItag, sIcar_type);

        sprintf_s(stmt, sizeof stmt, "SELECT a.ipolicy, a.icard, iassured, itag, icar_type, nassured, ibatch_no, iofficer, a.fedr_class, a.dlock, b.iroute , "
                      "       a.feply , a.tmobile_eply , a.aemail_eply , b.tmobile_appl , b.aemail_appl, a.fcard_class "
                      "  FROM %s:ply_relation a, %s:policy b "
                      " WHERE a.ipolicy = b.ipolicy "
                      "   AND a.ipolicy = '%s' ",
                policyDBname, policyDBname, sIpolicy);
        printf("stmt[%s]\n", stmt);
        $PREPARE prep1 FROM $stmt;
        $EXECUTE prep1 INTO $ipolicy, $icard, $iassured, $itag, $icar_type, $nassured, $ibatch_no, $iofficer, $fedr_class, $dlock, $iroute,
            $feply, $tmobile_eply, $aemail_eply, $tmobile_appl, $aemail_appl, $fcard_class;

        strcpy(iendorse, " ");

        sprintf_s(sMsg, sizeof sMsg, "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t",
                sIpolicy, sIcard, iendorse, nassured,
                sIassured, sItag, icar_type, sIcar_type);

        if (SQLCODE == SQLNOTFOUND)
        {
            strcat(sMsg, "�O���Ƨ䤣��,�нT�{�O�渹�O�_���T");
            fprintf(report, "%s\n", sMsg);
            continue;
        }
        if (strcmp(sIcard, icard) != 0)
        {
            strcat(sMsg, "�z���Ѫ��Ҹ��P�̷s�O�椣�P,������,�нT�{");
            fprintf(report, "%s\n", sMsg);
            continue;
        }
        if (strcmp(sIassured, iassured) != 0)
        {
            strcat(sMsg, "�z���Ѫ��Q�O�I�HID�P�̷s�O�椣�P,������,�нT�{");
            fprintf(report, "%s\n", sMsg);
            continue;
        }
        if (strcmp(sItag, itag) != 0)
        {
            strcat(sMsg, "�z���Ѫ����P���X�P�̷s�O�椣�P,������,�нT�{");
            fprintf(report, "%s\n", sMsg);
            continue;
        }
        if (strcmp(sIcar_type, icar_type) == 0)
        {
            strcat(sMsg, "�z���Ѫ����ػP�̷s�O��ۦP,���Χ��");
            fprintf(report, "%s\n", sMsg);
            continue;
        }
        if (strlen(trim(dlock)) != 0) /* ���O��B2C��襤�A�ȮɵL�k��� */
        {
            strcat(sMsg, "���O��B2C��襤�A�ȮɵL�k���");
            fprintf(report, "%s\n", sMsg);
            continue;
        }

        $SELECT icode
            FROM car_type
                WHERE fclass = '1' AND icode = $sIcar_type;

        if (SQLCODE == SQLNOTFOUND)
        {
            strcat(sMsg, "�z���Ѫ����ئ��~,������");
            fprintf(report, "%s\n", sMsg);
            continue;
        }

        if (fedr_class[0] == '1')
        {
            strcat(sMsg, "�O����P,������");
            fprintf(report, "%s\n", sMsg);
            continue;
        }

        strncpy(sIbranchIcomp, ipolicy, CA_POL_BRH_NUM - 1);
        sIbranchIcomp[CA_POL_BRH_NUM - 1] = '\0';

        /* get ����k�ݤ�����c & �����q*/
        rc = cm_get_unit_in("", policyDB, userid, sIbranchIcomp, "C1", sIcomp_in, sIbranch_in);
        if (rc != M_CM_OK)
        {
            strcat(sMsg, "����k�ݤ�����c & �����q�䤣��");
            fprintf(report, "%s\n", sMsg);
            continue;
        }

        /* check ����k�ݤ����q�MDB�O�_�@�P*/
        if (strncmp(sIcomp_in, get_upcomp(policyDB, USE_BRANCH_ID, USE_BRANCH_ID), 1) != 0)
        {
            strcat(sMsg, "����k�ݤ����q�MDB���@�P");
            fprintf(report, "%s\n", sMsg);
            continue;
        }

        /**** ��涷���s����g��H�~�Z�k�ݳ��κ޲z�H ****/
        $SELECT iquota, ileader INTO $iquota, $ileader FROM officer WHERE iofficer = $iofficer;

        if (SQLCODE == SQLNOTFOUND)
        {
            strcat(sMsg, "�g��H��Ƨ䤣��");
            fprintf(report, "%s\n", sMsg);
            continue;
        }

        rc = chk_iquota_expire(iquota, v_sMsg);
        if (rc != M_CM_OK)
        {
            strcat(sMsg, v_sMsg);
            fprintf(report, "%s\n", sMsg);
            continue;
        }

        /* get ���s�X���O*/
        strncpy(sIbilling, ipolicy + CAR_POL_CHR_POS - 1, 2);
        sIbilling[2] = '\0';

        rc = cm_get_serial_num_dwritten("C2", sIbilling,
                                        sIupcompShort, sIbranch_in,
                                        cm_cdate_str_100(dwritten),
                                        cm_cdate_str_100(cm_today()), iendorse);
        if (rc != 0)
        {
            if (rc == 1 || rc == 2)
                strcat(sMsg, "��Ʈw�L�k�}��");
            else if (rc == 3)
                strcat(sMsg, "���۰ʵ�����Ƥ��s�b");
            else
                strcat(sMsg, "��浹�����~");

            fprintf(report, "%s\n", sMsg);
            continue;
        }

        rc = bk_401(policyDB, ipolicy, iendorse);
        if (rc != M_CM_OK)
        {
            strcat(sMsg, "�O��ƥ�����");
            fprintf(report, "%s\n", sMsg);
            continue;
        }

        /* 1090831006_SC2 �{�ҥ��x�j��q�l���ҥ���g�����mail�ˮ� */
        rsetnull(CDTIMETYPE, (char *)&dnotifyornot);
        strcpy(s_notifyornot, "");
        if (fcard_class[0] == '1')
        {
            if ((strlen(trim(tmobile_appl)) == 0 && strlen(trim(aemail_appl)) == 0) ||
                (feply[0] != '0' && strlen(trim(tmobile_eply)) == 0 && strlen(trim(aemail_eply)) == 0))
            {
                dtcurrent(&dnotifyornot);
                dttoasc(&dnotifyornot, s_notifyornot);
            }
            printf("--trace s_notifyornot[%s]", s_notifyornot);
        }

        policy_1[0] = '\0';
        policy_2[0] = '\0';

        strncpy(policy_1, ipolicy, CAR_POLICY_LEN);
        policy_1[CAR_POLICY_LEN] = 0;

        if (strlen(ipolicy) > CAR_POLICY_LEN)
            strcpy(policy_2, &ipolicy[CAR_POLICY_LEN]);
        else
            strcpy(policy_2, " ");

        ao_chk_charge(policyDB, 'A', policy_1, policy_2, ibatch_no,
                      payresult, paystatus, paydate, notedate);

        /* �U�CSQL��fedr_class�n��9:����A�e���T���ؤ~�|�ק� */
        sprintf_s(stmt, sizeof stmt, "INSERT INTO %s:edr_relation "
                "        (iendorse,      fcard_class,   ipolicy,       icard,             irelative_ply, "
                "         irelative_edr, fedr_class,    fpay,          ipay,              iedr_field, "
                "         dedr_begin,    dedr_end,      ipro_year,         ibrand, "
                "         icar_type,     medrdmg_agent, medrdmg_commi, medrdmg_prem,      medrdmg_pure_prem,"
                "         medrlia_agent, medrlia_commi, medrlia_prem,  medrlia_pure_prem, ibig_comp, "
                "         ibig_branch,   ibig_office,   ibig_sales,    iresource,         ibroker, "
                "         iofficer,      ileader,       icorps,        iedr_area,         iedr_cashier, "
                "         iedr_examiner, dedr_examine,  dentry,        dendorse,          fprint, "
                "         itreaty,       ibranch,       iquota,        icomp_in,          ibranch_in, "
                "         icomp_at,      ibranch_at,    medr_ready,    medr_stable,       medr_compensate, "
                "         medr_adjcom,   medr_research, medr_invest,   medr_bus_rule,     medr_business, "
                "         medr_capital,  medr_maintain, fcomp_class,   fcomp_class_last,  fdiscount, "
                "         medrdmg_disc,  medrlia_disc,  iedr_return,   icar_flag,         terminate_rsn, "
                "         qcount,        iofficer_prmt, iquota_prmt,   ileader_prmt,      irate_type, "
                "         bzfrom,        iroute_comm,   icomm_obj, qprovision, isecond_hand,icard_main, qdrunk_driving, isign,"
                "         feply,         feedr,         aemail_eply,   tmobile_eply,      ireg_no,    dnotifyornot,"
                "         isign_edr, dsign_edr, fsign_status_edr, funder_chk_edr, iprog,qviolate) "
                " SELECT  '%s',        fcard_class, ipolicy,     icard,            irelative_ply, "
                "         ' ',         '9',         ' ',         ' ',              ' ', "
                "         dply_begin,  dply_end,    ipro_year,        ibrand, "
                "         '%s',        0,           0,           0,                0, "
                "         0,           0,           0,           0,                ibig_comp, "
                "         ibig_branch, ibig_office, ibig_sales,  iresource,        ibroker, "
                "         iofficer,    '%s',        icorps,      iarea,            icashier, "
                "         '%s',        %ld,         %ld,         %ld ,             1, "
                "         itreaty,     ibranch,     '%s',        icomp_in,         ibranch_in, "
                "         icomp_at,    ibranch_at,  0,           0,                0, "
                "         0,           0,           0,           0,                0, "
                "         0,           0,           fcomp_class, fcomp_class_last, fdiscount, "
                "         0,           0,           '1',         icar_flag,        '0', "
                "         0,iofficer_prmt,  iquota_prmt,      ileader_prmt,        irate_type, "
                "         bzfrom,      iroute_comm,  icomm_obj, qprovision,        isecond_hand,icard_main, qdrunk_driving, isign,"
                "         feply,       '0',         aemail_eply, tmobile_eply,     ireg_no      ,   '%s', "
                "         'system',    today,       40,         'N',               'car425' ,qviolate "
                "   FROM %s:ply_relation "
                "  WHERE ipolicy = '%s'",
                policyDBname,
                iendorse, sIcar_type, ileader, iedr_examiner, dwritten, dwritten, dwritten, iquota, s_notifyornot, policyDBname, ipolicy);

        printf("[%s]\n", stmt);
        $PREPARE prep3 FROM $stmt;
        $EXECUTE prep3;

        /*1071105008_SC2_ �������Ȩ��z��(FS)�A�éw�ɦ۰ʤU���ɮ�*/
        strcpy(iroute_accept_edr, " ");
        if (strncmp(iroute, "I009", 4) == 0)
        {
            strcpy(iendorse, trim(iendorse));
            sprintf_s(iroute_accept_edr, sizeof iroute_accept_edr, "CHB%s", iendorse);
        }
        printf("-- trace iroute_accept_edr[%s]\n ", iroute_accept_edr);

        sprintf_s(stmt, sizeof stmt, "INSERT INTO %s:endorsement "
                "       (iendorse,    qply_period,  dply_begin,  dply_end,    fassured, "
                "        iassured,    iassured_ext, nassured,    ilicense,    "
                "        fsex,        fmarriage,    nuser,       ibenef,      nbenef, "
                "        aassured,    aassured_zip, itel,        apayment,    apayment_zip,"
                "        iply_area,   nbrand_abbr,  ncar_abbr,   fcar_note,   qcylinder, "
                "        iengine,     ibody,        itag,        mcar_price,  nequipment, "
                "        flimit,      pdmg_align,   pbrg_align,  plia_align,  idmg_rate, "
                "        pdmg_factor, ibrg_rate,    pbrg_factor, qpt,         fpt, "
                "        psex_age,    psex_age_damage, lia_class,    plia_acc,    dmg_acc_1st, dmg_acc_2nd, "
                "        dmg_acc_3rd, pdmg_acc,     fhuman,      fcomp_24,    payresult, "
                "        iext_policy, qpro_month,   mkilo_ply,   mkilo_edr,   irisk, "
                "        irelative_ext, "
                "        napplicant,  dbirth,   dissue, "
                "        iextra_charge, gextra_charge, pextra_charge,                 "
                "        iquery_num_damage, iquery_num, mequipment,       "
                "        survey_num,  bound_num,    abnormal_num, iapplicant, iroute, qlia_acc_sum, qdmg_acc_sum, "
                "        fapplicant,fsex_appl,dbirth_appl,itel_appl,ndeputy_appl,nrelation_appl,ndeputy_assured, "
                "        iassured_cntry, iapplicant_cntry, punknown_acc, iquery_num_unknown, qunknown_acc_sum, nassured_cntry, napplicant_cntry, "
                "        foccup, noccup, applicant_foccup, applicant_noccup, iroute_accept,tmobile_appl , aemail_appl) "
                " SELECT '%s', a.qply_period,           a.dply_begin,  a.dply_end,    b.fassured, "
                "        b.iassured,    b.iassured_ext, b.nassured,    b.ilicense,    "
                "        b.fsex,        b.fmarriage,    b.nuser,       b.ibenef,      b.nbenef, "
                "        b.aassured,    b.aassured_zip, b.itel,        b.apayment,    b.apayment_zip,"
                "        b.iply_area,   b.nbrand_abbr,  b.ncar_abbr,   b.fcar_note,   b.qcylinder, "
                "        b.iengine,     b.ibody,        b.itag,        b.mcar_price,  b.nequipment, "
                "        b.flimit,      b.pdmg_align,   b.pbrg_align,  b.plia_align,  b.idmg_rate, "
                "        b.pdmg_factor, b.ibrg_rate,    b.pbrg_factor, b.qpt,         b.fpt, "
                "        b.psex_age,    b.psex_age_damage, b.lia_class,    b.plia_acc,    b.dmg_acc_1st, b.dmg_acc_2nd, "
                "        b.dmg_acc_3rd, b.pdmg_acc,     b.fhuman,      b.fcomp_24,    '%s', "
                "        b.iext_policy, b.qpro_month,   b.mkilo_ply,   b.mkilo_edr,   b.irisk, "
                "        b.irelative_ext, "
                "        b.napplicant,  b.dbirth,   b.dissue,"
                "        b.iextra_charge, b.gextra_charge, b.pextra_charge,                    "
                "        b.iquery_num_damage, b.iquery_num, b.mequipment,         "
                "        b.survey_num, b.bound_num, b.abnormal_num, b.iapplicant, b.iroute, b.qlia_acc_sum, b.qdmg_acc_sum, "
                "        b.fapplicant,b.fsex_appl,b.dbirth_appl,b.itel_appl,b.ndeputy_appl,b.nrelation_appl,b.ndeputy_assured, "
                "        CASE WHEN b.iassured_cntry='' THEN CASE WHEN b.fassured IN ('3','4') THEN '8'  ELSE '9' END "
                "             ELSE b.iassured_cntry END, "
                "        CASE WHEN b.iapplicant_cntry='' THEN CASE WHEN b.fapplicant IN ('3','4') THEN '8'  ELSE '9' END "
                "             ELSE b.iapplicant_cntry END, "
                "        b.punknown_acc, b.iquery_num_unknown, b.qunknown_acc_sum, b.nassured_cntry, b.napplicant_cntry, "
                "        b.foccup, b.noccup, b.applicant_foccup, b.applicant_noccup,'%s',tmobile_appl , aemail_appl "
                "   FROM %s:ply_relation a, %s:policy b "
                "  WHERE a.ipolicy = b.ipolicy "
                "    AND a.ipolicy = '%s' ",
                policyDBname, iendorse, payresult, iroute_accept_edr, policyDBname, policyDBname, ipolicy);

        printf("[%s]\n", stmt);
        $PREPARE prep2 FROM $stmt;
        $EXECUTE prep2;

        /*1090831006_SC2 �{�ҥ��x�j��q�l���ҥ���g�����mail�ˮ�*/
        sprintf_s(stmt, sizeof stmt, "UPDATE %s:ply_relation "
                      "   SET icar_type = '%s',"
                      "       iquota    = '%s',"
                      "       ileader   = '%s', "
                      "       dnotifyornot = '%s'"
                      " WHERE ipolicy = '%s'",
                policyDBname, sIcar_type, iquota, ileader, s_notifyornot, ipolicy);
        printf("[%s]\n", stmt);
        $PREPARE prep4 FROM $stmt;
        $EXECUTE prep4;

        sprintf_s(stmt, sizeof stmt, "UPDATE %s:edr_relation SET iedr_field = ? WHERE iendorse = '%s'",
                policyDBname, iendorse);
        printf("[%s]\n", stmt);
        $PREPARE prep5 FROM $stmt;
        $EXECUTE prep5 USING $iedr_field;

        sprintf_s(sMsg, sizeof sMsg, "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s",
                sIpolicy, sIcard, iendorse, nassured,
                sIassured, sItag, icar_type, sIcar_type, "�w�X���");
        fprintf(report, "%s\n", sMsg);

        iCount++;

    } /* End for(;;) */

    printf("iCount=[%d]\n", iCount);
    $CLOSE curs1;
    $Free curs1;

    fclose(report);

    sprintf_s(TmpName, sizeof TmpName, "car425_report_%s.txt", outputf);

    /*�@�X�ּ��D */
    sprintf_s(cmd_stmt, sizeof cmd_stmt,
            "cd %s/rptftp/;"
            "cat ../form/car425_e.head %s > %s;"
            "rm -f %s;",
            aphome, RptName, TmpName, RptName);

    printf("cmd_stmt=[%s]\r\n", cmd_stmt);
    rc = system(cmd_stmt);
    if (rc != 0)
    {
        printf("cat file���~\r\n");
        sprintf_s(sMsg, sizeof sMsg, "cat file���~\r\n");
        return rc;
    }

    rc = rptftpinsert(userid, "car425", TmpName);
    printf("rptftpinsert rc[%d]\n", rc);
    if (rc != 0)
    {
        sprintf_s(sMsg, sizeof sMsg, "%s�g�Jrptftplist���~\r\n", RptName);
        return rc;
    }

    time(&tt);
    printf("�ɶ�[%s]\n", ctime(&tt));

    sprintf_s(sMsg, sizeof sMsg, "���槹��,�@[%d]��\n", iCount);
    WRITELOG(sfp, sMsg);
    printf("sMsg[%s]", sMsg);

    sprintf_s(sMsg, sizeof sMsg, "��粒��,���I���ɮפU���@�~�d��[Q],�U����ﵲ�G����[%s] \r\n", TmpName);

    return M_CM_OK;

errexit:

    fclose(report);
    sprintf_s(sMsg, sizeof sMsg, "SQLCODE[%d], ERRM[%s] �O�渹[%s], �j���Ҹ�[%s]�B�Q�O�I�HID[%s]�B���P���X[%s]�B���ᨮ��[%s]\n",
            SQLCODE, sqlca.sqlerrm, sIpolicy, sIcard, sIassured, sItag, sIcar_type);
    printf("sMsg[%s]\n", sMsg);
    return SQLCODE;
}

/* -------------------------------------------------------------------------------*/
/* Modified by Julia Han in 2007/11/23                                            */
/* �s�W�[�����L������                                                         */
/* -------------------------------------------------------------------------------*/
long car425_M()
{
    /* �q��r�ɨӪ���� */
    $char fold_iassured[11], fold_nassured[31], fold_DOB[11];
    $char ficard[18], fdedr_begin[11], fnew_iassured[11];
    $char fnew_nassured[31], fnew_DOB[11], fnew_itel[21];
    $char fnew_addr[76], fold_itag[CA_TAG_NUM], fiengine[41], fnew_itag[CA_TAG_NUM], fflag[2];
    $char fdata_date[9];

    /* �q����u�@�ɨӪ���� */
    $char old_iassured[13], new_iassured[13], old_nassured[121], new_nassured[121];
    $char old_DOB[11], new_DOB[11], old_compCard[21], new_tel[21], new_mobile[21];
    $char new_aassured[91], new_aassured_zip[CA_ZIP], old_itag[CA_TAG_NUM], new_itag[CA_TAG_NUM], new_iengine[CA_ENGINE_NUM];
    $char new_dedr_begin[11], new_aassured_all[96];

    /* �O���ɪ���� */
    $char iassured[13], icard[21], itag[CA_TAG_NUM];
    $char iendorse[21], sIpolicy[21];
    $long dwritten, tot_prem = 0;
    $char ibatch_no[11], old_dply_begin[11], old_fassured[2];
    $char old_aassured[91], old_aassured_zip[CA_ZIP], old_tel[21];
    $char old_fsex[2], old_fmarriage[2], old_dbirth[11], old_iengine[CA_ENGINE_NUM], iroute[21];

    /* �g�J����ɪ���� */
    $char new_ilicense[11], new_fassured[2], new_fsex[2];
    $char ply_area[11];
    $char new_dbirth[11];
    $char iquota[11], ileader[11], iofficer[11];

    /* General variables */
    $char stmt[20480], cmd_stmt[20480], datetime[12];
    char local_dbname[41], sData[2048];
    char GetName[51], LogName[51], RptName[51], TmpName[51];
    char FullGetName[101], FullLogName[101], FullRptName[101];
    int iCount, iTmp;
    char sIupcompShort[2], policyDB[21], policyDBname[41];
    char err_sMsg[1024];
    int Lng_zipcode;
    char policy_1[POLICY_NUM_1], policy_2[POLICY_NUM_2];
    char payresult[4], paystatus[100], paydate[100], notedate[100];

    char sIcomp_in[BRANCH_ID], sIbranch_in[BRANCH_ID];
    char sIcomp_in_short[BRANCH_ID];
    char sIbranchIcomp[CA_POL_BRH_NUM];
    char sIbilling[3], tmp_year[5], tmp_cyear[11], tmp_monthday[6];
    int int_year, icnt;
    long tt, i_dedr_begin, i_dply_begin;
    char readstr[670], fTmp[10], tmp_new_itel[21], sTmp[101];
    $char fedr_class[2];
    $char new_iassured_cntry[2], new_iapplicant_cntry[2];
    $char new_nassured_cntry[51], new_napplicant_cntry[51];
    $char dlock[31], sFcard_class[2], iroute_accept_edr[21];
    $int freasonB;
    $char tmp_new_nassured_cntry[21], tmp_new_napplicant_cntry[21];
    $char feply[2] = " ", tmobile_eply[21] = " ", aemail_eply[51] = " "; /*1090831006_SC2 �{�ҥ��x�j��q�l���ҥ���g�����mail�ˮ�*/
    $char tmobile_appl[21] = " ", aemail_appl[51] = " ", s_notifyornot[21] = "", fcard_class[2] = " ";
    int iTmpChk;
    $char s_icar_type[3]=" ",new_ibody[CA_BODY_NUM]=" ",old_ibody[CA_BODY_NUM]=" ";

    $datetime year to second dnotifyornot;

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(local_dbname, get_full_dbname(DBName));

    $select first 1 current month to minute
        into $datetime
            from system_var;

    /* client�ݱNuser���Ѫ�����諸�����ftp��/dat/car/car425_m.txt */
    sprintf_s(GetName, sizeof GetName, "car425_m.txt");
    sprintf_s(LogName, sizeof LogName, "car425_load_err_%s.txt", outputf);
    sprintf_s(RptName, sizeof RptName, "car425_report.body", outputf);
    sprintf_s(FullGetName, sizeof FullGetName, "%s/dat/car/%s", aphome, GetName);
    sprintf_s(FullLogName, sizeof FullLogName, "%s/rptftp/%s", aphome, LogName);
    sprintf_s(FullRptName, sizeof FullRptName, "%s/rptftp/%s", aphome, RptName);

    if ((report = fopen(FullGetName, "r")) == NULL)
    {
        sprintf_s(sMsg, sizeof sMsg, "Cannot open ftp file: %s\n", FullGetName);
        printf("%s", sMsg);
        return M_CM_OPEN_FILE_FAIL;
    }

    if ((report1 = fopen(FullRptName, "w")) == NULL)
    {
        sprintf_s(sMsg, sizeof sMsg, "Cannot open Output file: %s\n", FullRptName);
        printf("%s", sMsg);
        return M_CM_OPEN_FILE_FAIL;
    }

    printf("FullGetName[%s]\n", FullGetName);

    /*$BEGIN WORK;*/

    iCount = 0; /* �p���ɮ׵��� */
    icnt = 0;

    while (1)
    {
        fscanf(report, "%[^\n]%*c", readstr);

        if (feof(report))
            break;
        printf("READSTR[%s]\n", readstr);

        /* �N�ɮ׮ھکT�w�e��,Ū�X��� */
        strncpy(fold_iassured, &readstr[0], 10);
        fold_iassured[10] = '\0';

        strncpy(fold_nassured, &readstr[10], 200);
        fold_nassured[30] = '\0';

        strncpy(fTmp, &readstr[210], 8);
        fTmp[8] = '\0';
        formatDate(fTmp, fold_DOB); /* ������ഫ��db�i�������榡 */

        /* ���L���q�N�X "17" �A���d�� */
        strncpy(ficard, &readstr[220], 15);
        ficard[15] = '\0';

        strncpy(fTmp, &readstr[235], 8);            /* 245~252 �O�L����(YYYYMMDD) */
        fTmp[8] = '\0';
        formatDate(fTmp, fdedr_begin);

        strncpy(fnew_iassured, &readstr[249], 10);  /* 243~248 �O�L��ɶ�6�X(hhmmss) */
        fnew_iassured[10] = '\0';

        strncpy(fnew_nassured, &readstr[259], 200);
        fnew_nassured[30] = '\0';

        strncpy(fTmp, &readstr[459], 8);
        fTmp[8] = '\0';
        formatDate(fTmp, fnew_DOB);

        strncpy(tmp_new_itel, &readstr[467], 16);
        tmp_new_itel[16] = '\0';
        strcpy(fnew_itel, trim(tmp_new_itel));
        fnew_itel[14] = '\0';

        strncpy(fnew_addr, &readstr[483], 75);     /* �ھڳW��G������ڬ��G�����=> 483~485 �O�l���ϸ�(3�X),��l�O�a�}(72�X) */
        fnew_addr[75] = '\0';

        strncpy(fold_itag, &readstr[558], 12);
        fold_itag[12] = '\0';

        strncpy(fiengine, &readstr[570], 40);
        fiengine[40] = '\0';                       /* �ھڳW��G������ڬ��G�����=> �e20�X���������A��20�X��������, �{���N��X�ֵ����@�����(ps.35���إu�|������(���[)���X) */

        strncpy(fnew_itag, &readstr[610], 12);
        fnew_itag[12] = '\0';

        strncpy(fflag, &readstr[622], 1);
        fflag[1] = '\0';

        strncpy(fdata_date, &readstr[623], 8);
        fdata_date[8] = '\0';

        /* 1100625002_SC1 CAR425�ק��O���O�P�_ */
        /* ��O���O => �P�_�O�_���~��H */
        iTmpChk = 0;
        if ((isalpha(fnew_iassured[0]) && isalpha(fnew_iassured[1])) ||
            (isalpha(fnew_iassured[0]) && strlen(trim(fnew_iassured)) == 10 && (fnew_iassured[1] == '8' || fnew_iassured[1] == '9')))
        {
            iTmpChk = 1;
        }
        /*if ((fnew_iassured[0]>='a' && fnew_iassured[0]<='z') && (fnew_iassured[1]>='a' && fnew_iassured[1]<='z'))
        if (isalpha(fnew_iassured[0]) && isalpha(fnew_iassured[1]))*/
        if (iTmpChk == 1)
            strncpy(new_iassured_cntry, "8", 1);
        else
            strncpy(new_iassured_cntry, "9", 1);
        new_iassured_cntry[1] = '\0';

        /*if ((fnew_iassured[0]>='a' && fnew_iassured[0]<='z') && (fnew_iassured[1]>='a' && fnew_iassured[1]<='z'))
        if (isalpha(fnew_iassured[0]) && isalpha(fnew_iassured[1]))*/
        if (iTmpChk == 1)
            strncpy(new_iapplicant_cntry, "8", 1);
        else
            strncpy(new_iapplicant_cntry, "9", 1);
        new_iapplicant_cntry[1] = '\0';

        strcpy(tmp_new_nassured_cntry, "                    ");
        strncpy(new_nassured_cntry, tmp_new_nassured_cntry, 20);
        new_nassured_cntry[20] = '\0';

        strcpy(tmp_new_napplicant_cntry, "                    ");
        strncpy(new_napplicant_cntry, tmp_new_napplicant_cntry, 20);
        new_napplicant_cntry[20] = '\0';

        printf("fdata_date[%s]\n", fdata_date);
        /* �T�w�e���ɮפ��ε��� */

        $INSERT INTO ca_transfer_assured(old_iassured, old_nassured, old_DOB,
                                         old_compCard, dedr_begin, new_iassured,
                                         new_nassured, new_DOB, new_tel,
                                         new_aassured, old_itag, new_iengine, new_itag,
                                         data_date, new_iassured_cntry, new_iapplicant_cntry,
                                         new_nassured_cntry, new_napplicant_cntry)

            VALUES($fold_iassured, $fold_nassured, $fold_DOB,
                   $ficard, $fdedr_begin, $fnew_iassured,
                   $fnew_nassured, $fnew_DOB, $fnew_itel,
                   $fnew_addr, $fold_itag, $fiengine, $fnew_itag,
                   $fdata_date, $new_iassured_cntry, $new_iapplicant_cntry,
                   $new_nassured_cntry, $new_napplicant_cntry);

        iCount++;
        icnt++;
        if (icnt == 500)
        {
            icnt = 0;
            $COMMIT WORK;
            $BEGIN WORK;
        }
    } /* End of While */

    fclose(report);
    $COMMIT WORK;
    sprintf_s(fTmp, sizeof fTmp, "���槹��,[%d]��", iCount);

    /* -------������ for ISID ���U�� (1070817001_SC1 �s�WCAR425�L��ɶǰeISID) ------------*/

    $char iref_num1[21], iref_num3[21], idata_type[2], imember[11], nmember[101], icountry[6], idept[11], iquota_leader[7], ftype_batch[2], iins_class_batch[3];
    $char iquota_grp[7], sIassured[13], iapplicant[13], sNassured[101], napplicant[101], dbirth_batch[11];
    $datetime year to second dt_current;
    $int fkind_batch, fstatus_batch, tmpCount;
    int iLoop, i;

    $prepare pre_isid_batch from
        "insert into cm_isid_batch (iref_num1,iref_num2,iref_num3,idata_type,imember,nmember,icountry,dbirth,idept,iins_class,fkind,ftype,icreate,dcreate,nbatch,fstatus,inotice,ileader) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
         
    $prepare getLeaderInfo from "select iquota from officer where iofficer = ? ";

    /* -------������ for ISID ���U�� (1070817001_SC1 �s�WCAR425�L��ɶǰeISID) ------------*/

    /* -------------------------------------------------------*/

    /* ���o���椧�t�Τ�� */
    rtoday(&dwritten);
    iCount = 0;

    $BEGIN WORK;

    /* Init. iedr_field, to make every bit and byte = 0 */
    memset(&iedr_field, 0, sizeof(iedr_field));

    for (iTmp = 0; iTmp < 8; iTmp++)
        FLD_SET(iedr_field, iTmp * 8 + 7);

    $DECLARE cur_m CURSOR FOR
        SELECT old_iassured,
        old_compCard,
        dedr_begin, new_iassured, new_nassured, new_DOB,
        new_tel, new_aassured, old_itag, new_iengine, new_itag,
        new_iassured_cntry, new_iapplicant_cntry,
        new_nassured_cntry, new_napplicant_cntry FROM ca_transfer_assured;

    $OPEN cur_m;
    for (;;)
    {
        $FETCH cur_m INTO $old_iassured, $old_compCard,
            $new_dedr_begin, $new_iassured, $new_nassured, $new_DOB,
            $new_tel, $new_aassured_all, $old_itag, $new_iengine, $new_itag,
            $new_iassured_cntry, $new_iapplicant_cntry,
            $new_nassured_cntry, $new_napplicant_cntry;

        if (SQLCODE == SQLNOTFOUND)
            break;

        /* �h���h�l���ť� */
        strcpy(old_iassured, trim(old_iassured));
        strcpy(old_compCard, trim(old_compCard));
        strcpy(new_dedr_begin, trim(new_dedr_begin));
        strcpy(new_iassured, trim(new_iassured));
        strcpy(new_nassured, rtrim(new_nassured)); /* �����ťդ���trim*/
        strcpy(new_DOB, trim(new_DOB));
        strcpy(new_tel, trim(new_tel));
        strcpy(new_aassured, rtrim(new_aassured)); /* �����ťդ���trim*/
        strcpy(old_itag, trim(old_itag));
        strcpy(new_iengine, ltrim(new_iengine)); /* ������ڬ� ������+������ �X�֪����A�e20�X�����A��20�X����,35���إu�|������(���[)���X */
        strcpy(new_iengine, rtrim(new_iengine)); /* �����ťդ���trim*/
        strcpy(new_itag, trim(new_itag));
        strcpy(new_aassured_all, rtrim(new_aassured_all));
        strcpy(new_iassured_cntry, trim(new_iassured_cntry));
        strcpy(new_iapplicant_cntry, trim(new_iapplicant_cntry));

        strcpy(iendorse, " ");
        strcpy(sIpolicy, " ");

        /* �̾ڱj��d����X�O�渹 */
        $SELECT ipolicy, fcard_class INTO $sIpolicy, $sFcard_class FROM assured_vs_ply WHERE icard = $old_compCard;

        printf("assured_vs_ply�L����,ipolicy[%s],icard[%s]\n", sIpolicy, old_compCard);

        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(sMsg, sizeof sMsg, "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t",
                    sIpolicy, old_compCard, iendorse, new_iassured,
                    old_iassured, new_itag, old_itag, " ");

            strcat(sMsg, "�O���Ƨ䤣��,�нT�{�j��O�d���O�_���T");
            fprintf(report1, "%s\n", sMsg);
            continue;
        }

        strcpy(sIpolicy, trim(sIpolicy));

        sIupcompShort[0] = sIpolicy[2]; /* �O�渹�ĤT�X */
        sIupcompShort[1] = '\0';
        strcpy(policyDB, get_upcomp(sIupcompShort, USE_SHORT_BRANCH_ID, USE_BRANCH_ID));
        strcpy(policyDBname, get_full_dbname(policyDB));

        tot_prem = 0;
        sprintf_s(stmt, sizeof stmt, "SELECT a.icard, a.iassured, a.itag, b.ibatch_no, b.dply_begin, "
                      " a.fassured, a.aassured, a.aassured_zip, a.itel, "
                      " a.fsex, a.fmarriage, b.iofficer, dbirth, nassured, iengine, b.fedr_class, b.dlock, "
                      " (SELECT sum(mdamage_cover)::integer FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy ), a.iroute, "
                      " b.feply , b.tmobile_eply , b.aemail_eply , a.tmobile_appl , a.aemail_appl, b.fcard_class, b.icar_type, a.ibody "
                      "  FROM %s:policy a, %s:ply_relation b"
                      " WHERE a.ipolicy = b.ipolicy "
                      "   AND a.ipolicy = '%s' ",
                policyDBname, policyDBname, policyDBname, sIpolicy);
        printf("stmt[%s]\n", stmt);

        $PREPARE prep1 FROM $stmt;
        $EXECUTE prep1 INTO $icard, $iassured, $itag, $ibatch_no, $old_dply_begin,
            $old_fassured, $old_aassured, $old_aassured_zip, $old_tel,
            $old_fsex, $old_fmarriage, $iofficer, $old_dbirth, $old_nassured, $old_iengine, $fedr_class,
            $dlock, $tot_prem, $iroute,
            $feply, $tmobile_eply, $aemail_eply, $tmobile_appl, $aemail_appl, $fcard_class, $s_icar_type, $old_ibody;

        strcpy(icard, trim(icard));
        strcpy(iassured, trim(iassured));
        strcpy(itag, trim(itag));
        strcpy(ibatch_no, trim(ibatch_no));
        strcpy(old_dply_begin, trim(old_dply_begin));
        strcpy(old_fassured, trim(old_fassured));
        strcpy(old_aassured, rtrim(old_aassured));
        strcpy(old_aassured_zip, trim(old_aassured_zip));
        strcpy(old_tel, trim(old_tel));
        strcpy(old_fsex, trim(old_fsex));
        strcpy(old_fmarriage, trim(old_fmarriage));
        strcpy(old_nassured, rtrim(old_nassured));
        strcpy(old_iengine, rtrim(old_iengine));
        strcpy(s_icar_type, trim(s_icar_type));
        strcpy(old_ibody  , rtrim(old_ibody));
        strcpy(iendorse, " ");

        sprintf_s(sMsg, sizeof sMsg, "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t",
                sIpolicy, old_compCard, iendorse, new_iassured,
                old_iassured, new_itag, old_itag, " ");

        if (SQLCODE == SQLNOTFOUND)
        {
            strcat(sMsg, "�O���Ƨ䤣��,�нT�{�O�渹�O�_���T");
            fprintf(report1, "%s\n", sMsg);
            continue;
        }

        /* 1110718002_SC2 �s�W�L���q�ʤG���� */
        if (strlen(new_iengine) == 0)
        {
            if (strcmp(s_icar_type,"35")!=0)
            {
                strcat(sMsg, "�z���Ѫ��������X���ť�,������,�нT�{");
            }
            else
            {
                strcat(sMsg, "�z���Ѫ�������/���[���X���ť�,������,�нT�{");
            }
            
            fprintf(report1, "%s\n", sMsg);
            continue;
        }
          
        /* 1111019017_C01_����/�������X�P��椣�P���פU */
        if (strcmp(s_icar_type,"35")!=0)
        {
        	if (strcmp(new_iengine, old_iengine) != 0)
        	{
        		strcat(sMsg, "�z���Ѫ��������P�̷s�O�椣�P,������,�нT�{");
        		fprintf(report1, "%s\n", sMsg);
        		continue;
        	}
        }
        else
        {    	
        	if (strcmp(new_iengine, old_ibody) != 0)
        	{
        		strcat(sMsg, "�z���Ѫ����[���X�P�̷s�O�椣�P,������,�нT�{");
        		fprintf(report1, "%s\n", sMsg);
        		continue;
        	}
        }
        

        /* 1071027001_C1�]���q�l���ҤW�u�A�u�n�j��O��h�O�Y���i��CAR616�ɨ��P */
        if (tot_prem == 0)
        {
            strcat(sMsg, "���O��w�h�O,������,�нT�{");
            fprintf(report1, "%s\n", sMsg);
            continue;
        }

        if (strlen(trim(dlock)) != 0) /* ���O��B2C��襤�A�ȮɵL�k��� */
        {
            strcat(sMsg, "���O��B2C��襤�A�ȮɵL�k���");
            fprintf(report1, "%s\n", sMsg);
            continue;
        }

        if (strcmp(icard, old_compCard) != 0)
        {
            strcat(sMsg, "�z���Ѫ��Ҹ��P�̷s�O�椣�P,������,�нT�{");
            fprintf(report1, "%s\n", sMsg);
            continue;
        }
        
        if (strcmp(iassured, old_iassured) != 0)
        {
            strcat(sMsg, "�z���Ѫ��Q�O�I�HID�P�̷s�O�椣�P,������,�нT�{");
            fprintf(report1, "%s\n", sMsg);
            continue;
        }
        
        if (strcmp(itag, old_itag) != 0)
        {
            strcat(sMsg, "�z���Ѫ����P���X�P�̷s�O�椣�P,������,�нT�{");
            fprintf(report1, "%s\n", sMsg);
            continue;
        }

        if (fedr_class[0] == '1')
        {
            strcat(sMsg, "�O��w���P,������,�нT�{");
            fprintf(report1, "%s\n", sMsg);
            continue;
        }

        /*1071029004_SC2 �s�W���sCAR102�Ȥ���@�ɲ�10��---����W��H�� */
        freasonB = 0;
        $select nvl(sum(decode(freason, 'B', 1, 0)), 0)
           into $freasonB
           from reject_client
          where(dexpire is null or dexpire > today) and
            (nassured = case when trim(nassured) ='' then NULL else $new_nassured end or ilicense = case when trim(ilicense) ='' then NULL else $new_iassured end or itag = case when trim(itag) ='' then NULL else $new_itag end or iengine = case when trim(iengine) ='' then NULL else $new_iengine end);
        if (freasonB > 0)
        {
            strcat(sMsg, "�S���Ӯ׽Ь��ӫO��(car102�G���O B)");
            fprintf(report1, "%s\n", sMsg);
            continue;
        }

        strncpy(sIbranchIcomp, sIpolicy, CA_POL_BRH_NUM - 1);
        sIbranchIcomp[CA_POL_BRH_NUM - 1] = '\0';

        /* get ����k�ݤ�����c & �����q*/
        rc = cm_get_unit_in("", policyDB, userid, sIbranchIcomp, "C1", sIcomp_in, sIbranch_in);
        if (rc != M_CM_OK)
        {
            strcat(sMsg, "����k�ݤ�����c & �����q�䤣��");
            fprintf(report1, "%s\n", sMsg);
            continue;
        }

        /* check ����k�ݤ����q�MDB�O�_�@�P*/
        if (strncmp(sIcomp_in, get_upcomp(policyDB, USE_BRANCH_ID, USE_BRANCH_ID), 1) != 0)
        {
            strcat(sMsg, "����k�ݤ����q�MDB���@�P");
            fprintf(report1, "%s\n", sMsg);
            continue;
        }

        /* car9809141 �ʲz�����Ѥ����ͮĤ馭��O��ͮĤ�A�h�H�O��ͮĤ鬰���ͮĤ� */
        rc = rstrdate(new_dedr_begin, &i_dedr_begin); /* �Nmm/dd/yyyy�নlong */
        if (rc != 0)
        {
            strcat(sMsg, "���ͮĤ��ഫ���~");
            fprintf(report1, "%s[%s]\n", sMsg, new_dedr_begin);
            continue;
        }
        rc = rstrdate(old_dply_begin, &i_dply_begin); /* �Nmm/dd/yyyy�নlong */
        if (rc != 0)
        {
            strcat(sMsg, "�O��ͮĤ��ഫ���~");
            fprintf(report1, "%s[%s]\n", sMsg, old_dply_begin);
            continue;
        }
        if (i_dedr_begin < i_dply_begin)
            strcpy(new_dedr_begin, old_dply_begin);

        /**** ��涷���s����g��H�~�Z�k�ݳ��κ޲z�H ****/
        $SELECT iquota, ileader INTO $iquota, $ileader FROM officer WHERE iofficer = $iofficer;

        if (SQLCODE == SQLNOTFOUND)
        {
            strcat(sMsg, "�g��H��Ƨ䤣��");
            fprintf(report, "%s\n", sMsg);
            continue;
        }

        rc = chk_iquota_expire(iquota, v_sMsg);
        if (rc != M_CM_OK)
        {
            strcat(sMsg, v_sMsg);
            fprintf(report, "%s\n", sMsg);
            continue;
        }

        policy_1[0] = '\0';
        policy_2[0] = '\0';

        strncpy(policy_1, sIpolicy, CAR_POLICY_LEN);
        policy_1[CAR_POLICY_LEN] = 0;

        if (strlen(sIpolicy) > CAR_POLICY_LEN)
            strcpy(policy_2, &sIpolicy[CAR_POLICY_LEN]);
        else
            strcpy(policy_2, " ");

        ao_chk_charge(policyDB, 'A', policy_1, policy_2, ibatch_no,
                      payresult, paystatus, paydate, notedate);

        /* �T�{���O���A,���L�᪺���O���A�@�w�n���w���O */
        if (strncmp(payresult, "R", 1) != 0 || strncmp(payresult, "R6", 2) == 0)
        {
            strcat(sMsg, "�L�᪺���O���A�ݬ��w���O");
            fprintf(report1, "%s\n", sMsg);
            continue;
        }

        /* �Ѧa�}��Ƥ��X�l���ϸ��H�Φa�} */
        strncpy(new_aassured_zip, new_aassured_all, 3);
        new_aassured_zip[4] = '\0';
        strncpy(new_aassured, new_aassured_all + 3, 87);
        /*new_aassured[91] = '\0';*/
        new_aassured[87] = '\0';  /*1120207002_C02 ���I�֤ߨt�η��X�˴�*/

        Lng_zipcode = atoi(new_aassured_zip);

        /* ��X�ӫO�a�ϥN�� */
        if (Lng_zipcode >= 100 && Lng_zipcode <= 116)
            strcpy(ply_area, "01");
        else if (Lng_zipcode >= 220 && Lng_zipcode <= 253)
            strcpy(ply_area, "06");
        else if (Lng_zipcode >= 207 && Lng_zipcode <= 208)
            strcpy(ply_area, "06");
        else if (Lng_zipcode >= 200 && Lng_zipcode <= 206)
            strcpy(ply_area, "11");
        else if (Lng_zipcode >= 290 && Lng_zipcode <= 290)
            strcpy(ply_area, "11");
        else if (Lng_zipcode >= 260 && Lng_zipcode <= 272)
            strcpy(ply_area, "12");
        else if (Lng_zipcode >= 320 && Lng_zipcode <= 338)
            strcpy(ply_area, "13");
        else if (Lng_zipcode >= 300 && Lng_zipcode <= 315)
            strcpy(ply_area, "14");
        else if (Lng_zipcode >= 350 && Lng_zipcode <= 369)
            strcpy(ply_area, "15");
        else if (Lng_zipcode >= 400 && Lng_zipcode <= 408)
            strcpy(ply_area, "41");
        else if (Lng_zipcode >= 411 && Lng_zipcode <= 439)
            strcpy(ply_area, "42");
        else if (Lng_zipcode >= 540 && Lng_zipcode <= 558)
            strcpy(ply_area, "43");
        else if (Lng_zipcode >= 500 && Lng_zipcode <= 530)
            strcpy(ply_area, "44");
        else if (Lng_zipcode >= 630 && Lng_zipcode <= 655)
            strcpy(ply_area, "45");
        else if (Lng_zipcode >= 970 && Lng_zipcode <= 983)
            strcpy(ply_area, "81");
        else if (Lng_zipcode >= 950 && Lng_zipcode <= 966)
            strcpy(ply_area, "82");
        else if (Lng_zipcode >= 600 && Lng_zipcode <= 625)
            strcpy(ply_area, "61");
        else if (Lng_zipcode >= 700 && Lng_zipcode <= 709)
            strcpy(ply_area, "62");
        else if (Lng_zipcode >= 710 && Lng_zipcode <= 745)
            strcpy(ply_area, "63");
        else if (Lng_zipcode >= 800 && Lng_zipcode <= 813)
            strcpy(ply_area, "64");
        else if (Lng_zipcode >= 817 && Lng_zipcode <= 819)
            strcpy(ply_area, "64");
        else if (Lng_zipcode >= 820 && Lng_zipcode <= 852)
            strcpy(ply_area, "65");
        else if (Lng_zipcode >= 814 && Lng_zipcode <= 815)
            strcpy(ply_area, "65");
        else if (Lng_zipcode >= 900 && Lng_zipcode <= 947)
            strcpy(ply_area, "66");
        else if (Lng_zipcode >= 880 && Lng_zipcode <= 885)
            strcpy(ply_area, "67");
        else if (Lng_zipcode >= 890 && Lng_zipcode <= 896)
            strcpy(ply_area, "90");
        else if (Lng_zipcode >= 209 && Lng_zipcode <= 212)
            strcpy(ply_area, "91");
        else
        {
            strcat(sMsg, "�ӫO�a�ϵL�k����");
            fprintf(report1, "%s\n", sMsg);
            continue;
        }

        /* �B�z�ͤ�,�k�H�O�ŭ� */
        strcpy(new_dbirth, new_DOB);

        /* �P�_�Q�O�I�H�ʽ�,�Yid�Ĥ@�X�O�^��r�h���۵M�H,�Y�L�h���k�H */
        if (isalpha(new_iassured[0]))
        {
            if (strlen(trim(new_DOB)) > 0)
            {
                /* �B�z�Q�O�I�H�X�ͤ��,���T�ǨӪ���Ƭ��褸�~/��/��,���s�b��Ʈw����Ƭ�/��/��/�褸�~ */
                strncpy(tmp_year, new_DOB + 6, 4);
                /*tmp_year[5] = '\0';*/
                tmp_year[4] = '\0';  /*1120207002_C02 ���I�֤ߨt�η��X�˴�*/
                strncpy(tmp_monthday, new_DOB, 5);
                /*tmp_monthday[6] = '\0';*/
                tmp_monthday[5] = '\0'; /*1120207002_C02 ���I�֤ߨt�η��X�˴�*/
                int_year = atoi(tmp_year);
                sprintf_s(tmp_cyear, sizeof tmp_cyear, "%s/%d", tmp_monthday, int_year);
                strcpy(new_dbirth, tmp_cyear);
                new_dbirth[10] = '\0';

                /* 1130216002_C03 ��Q�Ʒ~�Τ@�s���ˬd�X�޿�ץ� */                                
                rc1 = check_id(new_iassured);
                if (rc1 == 0) 
                {
                    /* �����Ҹ�(�ꤺ�۵M�H) */                    
                    if( strlen(new_iassured) == 10 && new_iassured[0] >= 'A' && new_iassured[0] <= 'Z' ) 
                    {
                        if (new_iassured[1] >= 49 && new_iassured[1] <= 50)
                        {
                            strcpy(new_fassured, "1");  /* �ꤺ�۵M�H */
                            if (new_iassured[1] == 49) 
                            {
                                strcpy(new_fsex, "1");
                            }
                            else if (new_iassured[1] == 50)
                            {
                                strcpy(new_fsex, "2");
                            }
                        }
                        /*�~�d�Ҹ� �� �~�ӤH�f�s���Τ@�Ҹ�*/
                        else if ((new_iassured[1] >= 65 && new_iassured[1] <= 70) || (new_iassured[1] >= 56 && new_iassured[1] <= 57))
                        {
                            strcpy(new_fassured, "3"); 
                            if (new_iassured[1]==56 || new_iassured[1]==65 || new_iassured[1]==67 || new_iassured[1]==69 )  /* ��~�۵M�H(�ĤG�X 8�BA�BC�BE) */
                            {
                                strcpy(new_fsex, "1");
                            }
                            else if (new_iassured[1]== 57 || new_iassured[1]==68|| new_iassured[1]==67 || new_iassured[1]==70)  /* ��~�۵M�H(�ĤG�X 9�BB�BD�BF */
                            {
                                strcpy(new_fsex, "2");
                            }  
                        }
                        else
                        {
                            rc1 = -1;
                        }
                    }
                    else
                    {
                        rc1 = -1;
                    }                                       
                }
                /*
                rc1 = checkCitizenID(new_iassured, "1", "1", err_sMsg);
                if (rc1 == M_CM_OK)
                {
                    strcpy(new_fassured, "1");
                    strcpy(new_fsex, "1");
                }
                rc2 = checkCitizenID(new_iassured, "1", "2", err_sMsg);
                if (rc2 == M_CM_OK)
                {
                    strcpy(new_fassured, "1");
                    strcpy(new_fsex, "2");
                }
                rc3 = checkCitizenID(new_iassured, "3", "1", err_sMsg);
                if (rc3 == M_CM_OK)
                {
                    strcpy(new_fassured, "3");
                    strcpy(new_fsex, "1");
                }
                rc4 = checkCitizenID(new_iassured, "3", "2", err_sMsg);
                if (rc4 == M_CM_OK)
                {
                    strcpy(new_fassured, "3");
                    strcpy(new_fsex, "2");
                }
                
                if (rc1 != M_CM_OK && rc2 != M_CM_OK && rc3 != M_CM_OK && rc4 != M_CM_OK)
                */ 
                if (rc1 != 0)
                {
                    /*strcat( sMsg, "�۵M�H�����X�ͤ�,�k�H�L���X�ͤ�");*/
                    strcat(sMsg, "�s���DID���~�L�k���ѡA�нT�{");
                    fprintf(report1, "%s\n", sMsg);
                    continue;
                }
                strcpy(new_ilicense, new_iassured);
            }
            else
            {
                strcat(sMsg, "�Q�O�I�H�X�ͤ�����i���ť�,�нT�{");
                fprintf(report1, "%s\n", sMsg);
                continue;
            }
        }
        else
        {
            /* 1130216002_C03 ��Q�Ʒ~�Τ@�s���ˬd�X�޿�ץ� 
            rc1 = checked(new_iassured, "2", err_sMsg); * �ˮְꤺ�k�H *
            */
            rc1 = check_id(new_iassured);
            /*if (rc1 == M_CM_OK)*/
            if (rc1 == 0)
            { 
                strcpy(new_fassured, "2");
            }    
            else
            {
                if (strlen(trim(new_iassured)) == 8)
                {
                    strcpy(new_fassured, "6"); /* �ꤺ�k�HID���~ */
                }    
                else
                { 
                    strcpy(new_fassured, "4"); /* ��~�k�HID���~ */
                }    
            }
            strcpy(new_ilicense, "");
            strcpy(new_fsex, "");
            strcpy(new_dbirth, "");
        }

        /* 1101124011_SC2 RBA�ק�@�~ */
        /* new_iassured_cntry�Bnew_iapplicant_cntry �����J�ɮ׮ɵ{�����ȡA�L���A�ˬd */
        /*
        if(new_fassured[0] == '3' && new_iassured_cntry[0] == '9')
        {
             strcat( sMsg, "�Q�O�I�H����~�۵M�H,��O���O���i��9.����H");
         fprintf( report1, "%s\n", sMsg);
             continue;
        }
        if(new_fassured[0] != '3' && new_iassured_cntry[0] != '9')
        {
             strcat( sMsg, "�Q�O�I�H������~�۵M�H,��O���O������9.����H");
         fprintf( report1, "%s\n", sMsg);
             continue;
        }
        if( new_iassured_cntry[0] != '1' && new_iassured_cntry[0] != '2' && new_iassured_cntry[0] != '3' &&
            new_iassured_cntry[0] != '8' && new_iassured_cntry[0] != '9' )
        {
             strcat( sMsg, "�Q�O�I�H,��O���O������1,2,3,8,9");
         fprintf( report1, "%s\n", sMsg);
             continue;
        }
        if( new_iapplicant_cntry[0] != '1' && new_iapplicant_cntry[0] != '2' && new_iapplicant_cntry[0] != '3' &&
            new_iapplicant_cntry[0] != '8' && new_iapplicant_cntry[0] != '9' )
        {
             strcat( sMsg, "�n�O�H,��O���O������1,2,3,8,9");
         fprintf( report1, "%s\n", sMsg);
             continue;
        }
        if( (new_iassured_cntry[0] == '1'||new_iassured_cntry[0] == '3') && strlen(new_nassured_cntry) == 0)
        {
             strcat( sMsg, "�Q�O�I�H,���y�O������J");
         fprintf( report1, "%s\n", sMsg);
             continue;
        }
        if( (new_iapplicant_cntry[0] == '1'||new_iapplicant_cntry[0] == '3') && strlen(new_napplicant_cntry) == 0)
        {
             strcat( sMsg, "�n�O�H,���y�O������J");
         fprintf( report1, "%s\n", sMsg);
             continue;
        }
        */

        printf("�k�H(2)�٬O�۵M�H(1) == [%s], �k�H(1) or �k�H(2) == [%s]\n", new_fassured, new_fsex);

        rc = update_reject_policy(sIpolicy, iedr_examiner);
        if (rc != M_CM_OK)
        {
            sprintf_s(sTmp, sizeof sTmp, "����update_reject_policy()����,rc =[%d]", rc);
            strcpy(sTmp, rtrim(sTmp));
            strcat(sMsg, sTmp);
            fprintf(report1, "%s\n", sMsg);
            continue;
        }

        /* get ���s�X���O*/
        strncpy(sIbilling, sIpolicy + CAR_POL_CHR_POS - 1, 2);
        sIbilling[2] = '\0';

        rc = cm_get_serial_num_dwritten("C2", sIbilling,
                                        sIupcompShort, sIbranch_in,
                                        cm_cdate_str_100(dwritten),
                                        cm_cdate_str_100(cm_today()), iendorse);
        if (rc != 0)
        {
            if (rc == 1 || rc == 2)
                strcat(sMsg, "��Ʈw�L�k�}��");
            else if (rc == 3)
                strcat(sMsg, "���۰ʵ�����Ƥ��s�b");
            else
                strcat(sMsg, "��浹�����~");

            fprintf(report1, "%s\n", sMsg);
            continue;
        }

        printf("step1,iendorse[%s]\n", iendorse);

        rc = bk_401(policyDB, sIpolicy, iendorse);
        if (rc != M_CM_OK)
        {
            strcat(sMsg, "�O��ƥ�����");
            fprintf(report1, "%s\n", sMsg);
            continue;
        }

        if (risnull(SQLCHAR, new_iassured) == 1)
            strcpy(new_iassured, " ");
        if (risnull(SQLCHAR, new_fassured) == 1)
            strcpy(new_fassured, " ");
        if (risnull(SQLCHAR, new_fsex) == 1)
            strcpy(new_fsex, " ");

        strcpy(new_mobile, " ");
        if ((risnull(SQLCHAR, new_tel) == 1) || (strlen(new_tel) == 0))
        {
            strcpy(new_tel, " ");
        }
        else
        {
            if ((strncmp(new_tel, "09", 2) == 0) && (strlen(new_tel) == 10))
            {
                strcpy(new_mobile, new_tel);
            }
        }

        /* 1090831006_SC2 �{�ҥ��x�j��q�l���ҥ���g�����mail�ˮ� */
        rsetnull(CDTIMETYPE, (char *)&dnotifyornot);
        strcpy(s_notifyornot, "");
        if (fcard_class[0] == '1')
        {
            /*
            if ( ( strlen(trim(tmobile_appl))==0 && strlen(trim(aemail_appl))==0 ) ||
                ( feply[0]!='0' && strlen(trim(tmobile_eply))==0 && strlen(trim(aemail_eply))==0 )
                )  */
            /* �s�O��L email��T */
            if (strlen(trim(new_mobile)) == 0)
            {
                dtcurrent(&dnotifyornot);
                dttoasc(&dnotifyornot, s_notifyornot);
            }
        }
        printf("--trace s_notifyornot[%s]", s_notifyornot);

        /* �M�w������즳���,�M��N����諸���ؼg�Jiedr_field */
        /* ��諸��즳�i���ܰʪ���[�Q�O�I�HID],[�Q�O�I�H�ʽ�],[�Q�O�I�H�W��],
           [�Q�O�I�H�a�}],[�Q�O�I�H�q��],[�r�Ӹ��X],[�Q�O�I�H�ʧO],[�Q�O�I�H�B�ê��pdefault�w�B],
           [�Q�O�I�H�X�ͤ��][�P�Ӹ�] */

        if (strcmp(old_iassured, new_iassured) != 0)
            FLD_SET(iedr_field, 0);
        if (strcmp(old_fassured, new_fassured) != 0)
            FLD_SET(iedr_field, 1);
        if (strcmp(old_nassured, new_nassured) != 0)
            FLD_SET(iedr_field, 2);
        if (strcmp(old_aassured, new_aassured) != 0)
            FLD_SET(iedr_field, 6);

        if (strcmp(old_tel, new_tel) != 0)
            FLD_SET(iedr_field, 8);
        if (strlen(new_mobile) == 10)
            FLD_SET(iedr_field, 54);
        if (strcmp(old_fsex, new_fsex) != 0)
            FLD_SET(iedr_field, 24);
        if (strcmp(old_dbirth, new_dbirth) != 0)
            FLD_SET(iedr_field, 22);
        if (strcmp(old_itag, new_itag) != 0)
            FLD_SET(iedr_field, 20);
        if (strcmp(old_iengine, new_iengine) != 0)
            FLD_SET(iedr_field, 18);

        /* �s�W��Ʀ̷ܳs�O����(edr_relation) */
        sprintf_s(stmt, sizeof stmt, "INSERT INTO %s:edr_relation "
                "        (iendorse,      fcard_class,   ipolicy,       icard,             irelative_ply, "
                "         irelative_edr, fedr_class,    fpay,          ipay,              iedr_field, "
                "         dedr_begin,    dedr_end,      ipro_year,         ibrand, "
                "         icar_type,     medrdmg_agent, medrdmg_commi, medrdmg_prem,      medrdmg_pure_prem,"
                "         medrlia_agent, medrlia_commi, medrlia_prem,  medrlia_pure_prem, ibig_comp, "
                "         ibig_branch,   ibig_office,   ibig_sales,    iresource,         ibroker, "
                "         iofficer,      ileader,       icorps,        iedr_area,         iedr_cashier, "
                "         iedr_examiner, dedr_examine,  dentry,        dendorse,          fprint, "
                "         itreaty,       ibranch,       iquota,        icomp_in,          ibranch_in, "
                "         icomp_at,      ibranch_at,    medr_ready,    medr_stable,       medr_compensate, "
                "         medr_adjcom,   medr_research, medr_invest,   medr_bus_rule,     medr_business, "
                "         medr_capital,  medr_maintain, fcomp_class,   fcomp_class_last,  fdiscount, "
                "         medrdmg_disc,  medrlia_disc,  iedr_return,   icar_flag,         terminate_rsn, "
                "         qcount,        iofficer_prmt, iquota_prmt,   ileader_prmt,      irate_type, "
                "         bzfrom,        iroute_comm,   icomm_obj,     qprovision,        isecond_hand,icard_main, qdrunk_driving, isign,"
                "         feply,         feedr,         aemail_eply,   tmobile_eply,      ireg_no,      dnotifyornot , "
                "         isign_edr, dsign_edr, fsign_status_edr, funder_chk_edr, iprog, qviolate) "
                " SELECT  '%s',        fcard_class, ipolicy,     icard,            irelative_ply, "
                "         ' ',         '8',         ' ',         ' ',              ' ', "
                "         '%s',  dply_end,    ipro_year,        ibrand, "
                "         icar_type,        0,           0,           0,                0, "
                "         0,           0,           0,           0,                ibig_comp, "
                "         ibig_branch, ibig_office, ibig_sales,  iresource,        ibroker, "
                "         iofficer,    '%s',        icorps,      iarea,            icashier, "
                "         '%s',        %ld,         %ld,         %ld ,             1, "
                "         itreaty,     ibranch,     '%s',        icomp_in,         ibranch_in, "
                "         icomp_at,    ibranch_at,  0,           0,                0, "
                "         0,           0,           0,           0,                0, "
                "         0,           0,           fcomp_class, fcomp_class_last, fdiscount, "
                "         0,           0,           '1',         icar_flag,        '0', "
                "         0,iofficer_prmt,  iquota_prmt,         ileader_prmt,     irate_type, "
                "         bzfrom,        iroute_comm,   icomm_obj, qprovision,     isecond_hand,icard_main, qdrunk_driving, isign,"
                "         feply,       '0',         ' ',  '%s',     ireg_no ,  '%s' , "
                "         'system', today, 40, 'N', 'car425', qviolate "
                "   FROM %s:ply_relation "
                "  WHERE ipolicy = '%s'",
                policyDBname,
                iendorse, new_dedr_begin, ileader, iedr_examiner, dwritten, dwritten, dwritten, iquota, new_mobile, s_notifyornot, policyDBname, sIpolicy);

        printf("[%s]\n", stmt);
        $PREPARE prep3 FROM $stmt;
        $EXECUTE prep3;

        /*1071105008_SC2_ �������Ȩ��z��(FS)�A�éw�ɦ۰ʤU���ɮ�*/
        strcpy(iroute_accept_edr, " ");
        if (strncmp(iroute, "I009", 4) == 0)
        {
            strcpy(iendorse, trim(iendorse));
            sprintf_s(iroute_accept_edr, sizeof iroute_accept_edr, "CHB%s", iendorse);
        }
        printf("-- trace iroute_accept_edr[%s]\n ", iroute_accept_edr);

        
        /*1110718002_SC2 �s�W�L���q�ʤG����*/        
        if (strcmp(s_icar_type,"35")==0)
        {
            strcpy(new_ibody  , new_iengine);
            strcpy(new_iengine, " ");
        }
        else
        {
            strcpy(new_ibody  , old_ibody);
        }

        sprintf_s(stmt, sizeof stmt, "INSERT INTO %s:endorsement "
                "       (iendorse,    qply_period,  dply_begin,  dply_end,    fassured, "
                "        iassured,    iassured_ext, nassured,    ilicense,  "
                "        fsex,        fmarriage,    nuser,       ibenef,      nbenef, "
                "        aassured,    aassured_zip, itel,        itel_night,  mobil_phone, "
                "        iemail,      apayment,    apayment_zip, iply_area,   nbrand_abbr, "
                "        ncar_abbr,   fcar_note,   qcylinder,    iengine,     ibody, "
                "        itag,        mcar_price,  nequipment,   flimit,      pdmg_align, "
                "        pbrg_align,  plia_align,  idmg_rate,    pdmg_factor, ibrg_rate, "
                "        pbrg_factor, qpt,         fpt,          psex_age,    psex_age_damage, lia_class, "
                "        plia_acc,    dmg_acc_1st, dmg_acc_2nd,  dmg_acc_3rd, pdmg_acc, "
                "        fhuman,      fcomp_24,    payresult,    iext_policy, qpro_month, "
                "        mkilo_ply,   mkilo_edr,   irisk,        irelative_ext, "
                "        napplicant,  dbirth,    dissue, "
                "        iextra_charge, gextra_charge, pextra_charge, "
                "        iquery_num_damage, iquery_num, mequipment, "
                "        survey_num,  bound_num,   abnormal_num, iapplicant, iroute, qlia_acc_sum, qdmg_acc_sum, "
                "        fapplicant,fsex_appl,dbirth_appl,itel_appl,ndeputy_appl,nrelation_appl,ndeputy_assured, "
                "        iassured_cntry, iapplicant_cntry,punknown_acc, iquery_num_unknown, qunknown_acc_sum, "
                "        nassured_cntry, napplicant_cntry, "
                "        foccup, noccup, applicant_foccup, applicant_noccup, iroute_accept,tmobile_appl , aemail_appl ) "
                " SELECT '%s', a.qply_period, a.dply_begin,  a.dply_end, '%s', "
                "        '%s', '', '%s', '%s', "
                "        '%s', '2', '', '', '', "
                "        '%s', '%s', '%s', '', '%s', "
                "        '', '%s', '%s', '%s', b.nbrand_abbr, "
                "        b.ncar_abbr,   b.fcar_note,   b.qcylinder, '%s', '%s', "
                "        '%s', b.mcar_price,  b.nequipment, b.flimit, b.pdmg_align, "
                "        b.pbrg_align,  b.plia_align,  b.idmg_rate, b.pdmg_factor, b.ibrg_rate, "
                "        b.pbrg_factor, b.qpt, b.fpt, b.psex_age, b.psex_age_damage, b.lia_class,  "
                "        b.plia_acc,    b.dmg_acc_1st, b.dmg_acc_2nd, b.dmg_acc_3rd, b.pdmg_acc, "
                "        b.fhuman,      b.fcomp_24,    '%s', b.iext_policy, b.qpro_month, "
                "        b.mkilo_ply,   b.mkilo_edr,   b.irisk, b.irelative_ext, "
                "        '%s',  '%s',   b.dissue, "
                "        b.iextra_charge, b.gextra_charge, b.pextra_charge, "
                "        b.iquery_num_damage, b.iquery_num, b.mequipment, "
                "        b.survey_num,  b.bound_num,   b.abnormal_num, '%s', b.iroute, b.qlia_acc_sum, b.qdmg_acc_sum, "
                "        '%s','%s', '%s','%s',b.ndeputy_appl,'���H',b.ndeputy_assured, "
                "        '%s', '%s', b.punknown_acc, b.iquery_num_unknown, b.qunknown_acc_sum, '%s', '%s', "
                "        b.foccup, b.noccup, b.applicant_foccup, b.applicant_noccup,'%s','%s' , '' "
                "   FROM %s:ply_relation a, %s:policy b "
                "  WHERE a.ipolicy = b.ipolicy "
                "    AND a.ipolicy = '%s' ",
                policyDBname, iendorse, new_fassured,
                new_iassured, new_nassured, new_ilicense,
                new_fsex,
                new_aassured, new_aassured_zip, new_tel, new_mobile,
                new_aassured, new_aassured_zip, ply_area,
                new_iengine, new_ibody, new_itag, payresult, new_nassured, new_dbirth,
                new_iassured, new_fassured, new_fsex, new_dbirth, new_tel,
                new_iassured_cntry, new_iapplicant_cntry,
                new_nassured_cntry, new_napplicant_cntry, iroute_accept_edr, new_mobile,
                policyDBname, policyDBname, sIpolicy);

        printf("[%s]\n", stmt);
        $PREPARE prep2 FROM $stmt;
        $EXECUTE prep2;

        sprintf_s(stmt, sizeof stmt, "UPDATE %s:assured_vs_ply "
                        "   SET (nassured, itag, iengine, iassured) "
                        "     = (?,?,?,?) "
                        " WHERE ipolicy = '%s'",
                policyDBname, sIpolicy);
        printf("[%s]\n", stmt);
        $PREPARE prep4 FROM $stmt;
        $EXECUTE prep4 USING $new_nassured, $new_itag, $new_iengine, $new_iassured;

        sprintf_s(stmt, sizeof stmt, "UPDATE %s:edr_relation SET iedr_field = ? WHERE iendorse = '%s'",
                policyDBname, iendorse);
        printf("[%s]\n", stmt);
        $PREPARE prep5 FROM $stmt;
        $EXECUTE prep5 USING $iedr_field;

        sprintf_s(stmt, sizeof stmt, "UPDATE %s:ply_relation "
                         "   SET (dtransfer,fedr_class,dendorse, ileader, iquota, dnotifyornot,aemail_eply,tmobile_eply) "
                         "    = (?,'8',?,?,?,?,'',?) "
                         " WHERE ipolicy = '%s'",
                policyDBname, sIpolicy);
        printf("[%s]\n", stmt);
        $PREPARE prep6 FROM $stmt;
        $EXECUTE prep6 USING $dwritten, $dwritten, $ileader, $iquota, $s_notifyornot, $new_mobile;

        sprintf_s(stmt, sizeof stmt, "UPDATE %s:policy "
                        "   SET (fassured,iassured,nassured,ilicense, "
                        "        fsex,fmarriage,nuser,ibenef,nbenef, "
                        "        aassured,aassured_zip,itel,iemail,apayment, "
                        "        apayment_zip,iply_area,iengine,itag,napplicant,dbirth,iassured_cntry,iapplicant_cntry, "
                        "        iapplicant,fapplicant,fsex_appl,dbirth_appl,itel_appl,nrelation_appl, nassured_cntry, napplicant_cntry, "
                        "        mobil_phone,tmobile_appl,itel_night,aemail_appl,ibody ) "
                        "    = (?,?,?,?,?,'2','','','', "
                        "       ?,?,?,'',?,?,?,?,?,?,?,?,?, "
                        "       ?,?,?,?,?,'���H', ?,?,?,?,'','',?) "
                        " WHERE ipolicy = '%s'",
                policyDBname, sIpolicy);
        printf("[%s]\n", stmt);
        $PREPARE prep7 FROM $stmt;
        $EXECUTE prep7 USING $new_fassured, $new_iassured, $new_nassured, $new_ilicense,
            $new_fsex,
            $new_aassured, $new_aassured_zip, $new_tel, $new_aassured,
            $new_aassured_zip, $ply_area, $new_iengine, $new_itag,
            $new_nassured, $new_dbirth, $new_iassured_cntry, $new_iapplicant_cntry,
            $new_iassured, $new_fassured, $new_fsex, $new_dbirth, $new_tel,
            $new_nassured_cntry, $new_napplicant_cntry, $new_mobile, $new_mobile, $new_ibody;

        /* -------������ 1070817001_SC1 �s�WCAR425�L��ɶǰeISID ------------*/
        printf("-- trace ISID sIpolicy[%s] iendorse[%s]\n ", sIpolicy, iendorse);

        iLoop = 0;
        strcpy(idata_type, "0");
        strcpy(icountry, " ");
        strcpy(iquota_leader, " ");
        dtcurrent(&dt_current);
        fkind_batch = 2;
        strcpy(ftype_batch, "E");
        fstatus_batch = 10;
        strcpy(iins_class_batch, "C");

        strcpy(iref_num1, trim(sIpolicy));
        strcpy(iref_num3, trim(iendorse));

        strcpy(sIassured, trim(new_iassured));
        strcpy(iapplicant, trim(new_iassured)); /* �n�Q�O�P�@�H */

        strcpy(sNassured, trim(new_nassured));
        strcpy(napplicant, trim(new_nassured)); /* �n�Q�O�P�@�H */

        $execute getLeaderInfo into $iquota_leader using $userid;
        printf("-- trace userid[%s], iquota_leader[%s]\n ", userid, iquota_leader);

        strcpy(iquota_grp, " "); /* ���n��� */
        $select c.iquota_grp INTO $iquota_grp
            from officer a,
            sa_branch_type b, branch c, sa_branch_type d where a.iofficer = a.ileader and a.iquota = b.ibranch and a.dexpire is null and a.iapp_unit != b.iply_branch and a.iapp_unit = c.ibranch and c.iquota_grp = d.ibranch and a.iofficer = $userid;

        if (strlen(trim(iquota_grp)) > 0)
        {
            strncpy(idept, iquota_grp, 4);
        }
        else
        {
            strncpy(idept, iquota_leader, 4);
        }
        idept[4] = '\0';

        printf("idept[%s]\n", idept);

        if (strcmp(sIassured, iapplicant) == 0)
        {
            iLoop = 1;
        }
        else
        {
            iLoop = 2;
        }
        printf("-- trace iLoop[%d]\n ", iLoop);

        for (i = 1; i <= iLoop; i++)
        {

            if (iLoop == 1)
            {
                strcpy(idata_type, "3"); /*  idata_type = 1.�n�O�H 2.�Q�O�H  3.�n�O�H = �Q�O�H*/
            }
            else
            {
                strcpy(idata_type, itoa(i));
            }
            printf("i[%d] ,idata_type[%s]\n", i, idata_type);

            if (i == 1) /* �n�O�H */
            {
                strcpy(imember, trim(iapplicant));
                strcpy(nmember, trim(napplicant));

                if (new_iapplicant_cntry[0] == '9')
                {
                    strcpy(icountry, "TW");
                }
                else if (new_iapplicant_cntry[0] == '2')
                {
                    strcpy(icountry, "CN");
                }

                if (strlen(trim(new_dbirth)) == 0)
                { /* �n�Q�O�P�@�H */
                    strcpy(dbirth_batch, "");
                }
                else
                {
                    strcpy(dbirth_batch, new_dbirth);
                }
            }
            else
            {

                strcpy(imember, trim(sIassured));
                strcpy(nmember, trim(sNassured));

                if (new_iassured_cntry[0] == '9')
                {
                    strcpy(icountry, "TW");
                }
                else if (new_iassured_cntry[0] == '2')
                {
                    strcpy(icountry, "CN");
                }

                if (strlen(trim(new_dbirth)) == 0)
                { /* �n�Q�O�P�@�H */
                    strcpy(dbirth_batch, "");
                }
                else
                {
                    strcpy(dbirth_batch, new_dbirth);
                }
            }

            $execute pre_isid_batch using $iref_num1, ' ', $iref_num3, $idata_type, $imember, $nmember, $icountry, $dbirth_batch, $idept, $iins_class_batch,
                $fkind_batch, $ftype_batch, $iedr_examiner, $dt_current, ' ', $fstatus_batch, $userid, $ileader;
        }

        /* -------������ 1070817001_SC1 �s�WCAR425�L��ɶǰeISID ------------*/

        sprintf_s(sMsg, sizeof sMsg, "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t",
                sIpolicy, old_compCard, iendorse, new_iassured,
                old_iassured, new_itag, old_itag, new_fassured, "�w�X���");

        fprintf(report1, "%s\n", sMsg);

        iCount++;

    } /* End for(;;) */

    printf("iCount=[%d]\n", iCount);
    $CLOSE cur_m;
    $Free cur_m;

    fclose(report1);

    sprintf_s(TmpName, sizeof TmpName, "car425_report_%s.txt", outputf);

    /*�@�X�ּ��D */
    sprintf_s(cmd_stmt, sizeof cmd_stmt,
            "cd %s/rptftp/;"
            "cat ../form/car425_m.head %s > %s;"
            "rm -f %s;",
            aphome, RptName, TmpName, RptName);

    printf("cmd_stmt=[%s]\r\n", cmd_stmt);
    rc = system(cmd_stmt);
    if (rc != 0)
    {
        printf("cat file���~\r\n");
        sprintf_s(sMsg, sizeof sMsg, "cat file���~\r\n");
        return rc;
    }

    rc = rptftpinsert(userid, "car425", TmpName);
    printf("rptftpinsert rc[%d]\n", rc);
    if (rc != 0)
    {
        sprintf_s(sMsg, sizeof sMsg, "%s�g�Jrptftplist���~\r\n", RptName);
        return rc;
    }

    time(&tt);
    printf("�ɶ�[%s]\n", ctime(&tt));

    sprintf_s(sMsg, sizeof sMsg, "���槹��,�@[%d]��\n", iCount);
    WRITELOG(sfp, sMsg);
    printf("sMsg[%s]", sMsg);

    sprintf_s(sMsg, sizeof sMsg, "��粒��,���I���ɮפU���@�~�d��[Q],�U����ﵲ�G����[%s] \r\n", TmpName);

    return M_CM_OK;

errexit:

    fclose(report);
    fclose(report1);
    sprintf_s(sMsg, sizeof sMsg, "SQLCODE[%d], ERRM[%s] �O�渹[%s], �j���Ҹ�[%s]�B�Q�O�I�HID[%s]�B���P���X[%s]\n",
            SQLCODE, sqlca.sqlerrm, sIpolicy, icard, iassured, itag);
    printf("sMsg[%s]\n", sMsg);
    /* $WHENEVER SQLERROR CONTINUE;
    $ROllBACK WORK; */
    return SQLCODE;
}

/* -------------------------------------------------------------------------------*/
int formatDate(sTmp, sDate)
char sTmp[64];
char sDate[11];
{
    if (sTmp[0] == ' ' || sTmp[0] == '0' || sTmp[0] == '\0')
    {
        strcpy(sDate, " ");
        return;
    }
    sDate[0] = sTmp[4];
    sDate[1] = sTmp[5];
    sDate[2] = '/';
    sDate[3] = sTmp[6];
    sDate[4] = sTmp[7];
    sDate[5] = '/';
    sDate[6] = sTmp[0];
    sDate[7] = sTmp[1];
    sDate[8] = sTmp[2];
    sDate[9] = sTmp[3];
    sDate[10] = '\0';
}
/* -------------------------------------------------------------------------------*/
/* �O�o�j���Iñ��O�O�ˮָ�Ƥ�� */

char stitle[] = "���O�]�s�B��O�^\t�O�I�Ҹ�\t�«O�椧�O�I�Ҹ�\t�Q�O�I�H\t�����Ҹ��]�νs�^\t����\tñ��ʧO\tñ��X�ͦ~���\tñ�樮��\tñ������q\tñ���`�O�O\t�ˮֵ���\t�ˮ֩ʧO\t�ˮ֥X�ͦ~���\t�ˮ֨���\t�ˮָ����q\t�ˮְs�r����\t�ˮ֭��j�H�W����\t�ˮ��`�O�O\t\t�O�I�Ҹ�\t�e�@�~��O���j���Ҹ�\t�O�渹�e�T�X\t�O�渹�X\t�Q�O�I�HID\t�Q�O�I�H�W��\t�X�ͦ~���\t����\t�����ƶq\t�������\tñ�浥��\t�s�r����\t�s�r�[�O\t���j�H�W����\t���j�H�W�[�O\tñ��O�O\tñ����\t�g��N��\t�޲z�H����W��\t�~�Z���\t";

long car425_P()
{
    DBinfo *list;
    int i, count_db, fStat;
    $char select_stmt[1024], stmt[1024], sql_stmt[10240], cmd_stmt[20480];
    char FullLogName[50], LogName[30], filename[50], ReportName[201];
    char FullGetName[101], sdelimiter[2];

    WRITELOG(sfp, " ");
    sprintf_s(sMsg, sizeof sMsg, " ");
    WRITELOG(sfp, sMsg);

    sprintf_s(ReportName, sizeof ReportName, "%s_%s.txt", sFileName, outputf);

    if ((list = get_db_list(&count_db, DBName)) == (char *)0)
    {
        EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
        return M_CM_NOT_DBLIST;
    }

    /* t425a�O�Nclient�ݤ�r��load�i��, �p�G��X�[���, ���Y(stitle)�O�o�[ */
    $CREATE temp TABLE t425a(
        class char(40),                                    /* ���O�]�s�B��O�^    	*/
        icard char(20),                                    /* �O�I�Ҹ�	       	*/
        ilast_card char(20),                               /* �«O�椧�O�I�Ҹ�    	*/
        nassured char(20),                                 /* �Q�O�I�H	    	*/
        iassured char(20),                                 /* �����Ҹ��]�νs�^    	*/
        itag char(20),                                     /* ����		    	*/
        fsex char(20),                                     /* ñ��ʧO	     	*/
        dbirth char(20),                                   /* ñ��X�ͦ~���	*/
        icar_type char(20),                                /* ñ�樮��	    	*/
        fpt char(20),                                      /* ñ������q		*/
        mlia_prem char(20),                                /* ñ���`�O�O		*/
        fcomp_class_chk char(20),                          /* �ˮֵ���		*/
        fsex_chk char(20),                                 /* �ˮ֩ʧO		*/
        dbirth_chk char(20),                               /* �ˮ֥X�ͦ~���	*/
        itag_chk char(20),                                 /* �ˮ֨���		*/
        fpt_chk char(20),                                  /* �ˮָ����q		*/
        qdrunk_driving_chk char(20),                       /* �ˮְs�r����		*/
        qviolate_chk char(20), /* �ˮ֭��j�H�W����		*/ /*1110608012_SC2 �s�W�j��I�O�v�ǤJ���j�H�W�[�O���*/
        mlia_prem_chk char(20)                             /* �ˮ��`�O�O		*/
        ) with no log;

    /* t425b��ƨӷ��Ot425a�ھڥd���q��Ʈw�d�X�Ӫ�, �p�G��X�[���, ���Y(stitle)�O�o�[ */
    $CREATE temp TABLE t425b(icard char(20),                               /* �O�I�Ҹ�*/
                             ilast_card char(20),                          /* �e�@�~��O���j���Ҹ� */
                             ipolicy1_3 char(20),                          /* �O�渹�e�T�X	    */
                             ipolicy char(20),                             /* �O�渹�X	    */
                             iassured char(20),                            /* �Q�O�I�HID	    */
                             nassured char(20),                            /* �Q�O�I�H�W��	    */
                             dbirth char(20),                              /* �X�ͦ~���	    */
                             icar_type char(20),                           /* ����		    */
                             qpt char(20),                                 /* �����ƶq	    */
                             fpt char(20),                                 /* �������	    */
                             fcomp_class char(20),                         /* ñ�浥��	    */
                             qdrunk_driving char(20),                      /* �s�r����         */
                             mdrunk_prem char(20),                         /* �s�r�[�O         */
                             qviolate char(20), /* ���j�H�W����         */ /*1110608012_SC2 �s�W�j��I�O�v�ǤJ���j�H�W�[�O���*/
                             mviolate_prem char(20),                       /* ���j�H�W�[�O     */
                             mlia_prem char(20),                           /* ñ��O�O	    */
                             dpolicy char(20),                             /* ñ����	    */
                             iofficer char(20),                            /* �g��N��	    */
                             nname char(20),                               /* �޲z�H����W��   */
                             nbranch char(20)                              /* �g��̷s�~�Z��� */
                             ) with no log;

    sprintf_s(FullGetName, sizeof FullGetName, "%s/dat/car/car425_p.txt", aphome);

    strcpy(sdelimiter, "\t");
    if ((fStat = load_command1(FullGetName, outputf, "t425a", sdelimiter)) != SUCCESS)
    {
        sprintf_s(sMsg, sizeof sMsg, "Loading File[%s] Fail fStat[%d]\n", FullGetName, fStat);
        return LOAD_FAIL;
    }
    $update t425a set icard = icard[3, 20] where 1 = 1;
    for (i = 0; i < count_db; i++)
    {
        sprintf_s(sql_stmt, sizeof sql_stmt, " INSERT INTO t425b"
                          " SELECT a.icard, a.ilast_card, a.ipolicy[1,3], a.ipolicy, "
                          "        b.iassured, b.nassured, "
                          "        to_char(b.dbirth,'%%Y') || '/' || to_char(b.dbirth,'%%m/%%d'),"
                          "        a.icar_type, "
                          "        b.qpt, b.fpt, a.fcomp_class, a.qdrunk_driving, d.mdrunk_prem, a.qviolate, d.mviolate_prem, a.mlia_prem+a.mdmg_prem, "
                          "        to_char(a.dpolicy,'%%Y') || '/' || to_char(a.dpolicy,'%%m/%%d'),"
                          "        a.iofficer, "
                          "        (SELECT nname FROM officer WHERE iofficer = "
                          "        (SELECT ileader FROM officer WHERE iofficer = a.iofficer)), "
                          "        (SELECT nbranch FROM sa_branch_type WHERE ibranch = (SELECT iquota FROM officer WHERE iofficer = a.iofficer))"
                          "  FROM %s:ply_relation a, %s:policy b, t425a c, %s:ply_ins_type d"
                          " WHERE a.ipolicy = b.ipolicy"
                          "   AND a.ipolicy = d.ipolicy"
                          "   AND d.iins_type = '21'"
                          "   AND a.icard = c.icard;\r\n",
                list[i].dbname, list[i].dbname, list[i].dbname);
        printf("sql_stmt[%s]\n", sql_stmt);
        $PREPARE prep_p FROM $sql_stmt;
        $EXECUTE prep_p;
    }

    /* �p�G��X�[���, ���Y(stitle)�O�o�[ */
    sprintf_s(stmt, sizeof stmt, "SELECT a.*,'�e���O�O�o���,�᭱�O���s���',b.* "
                  "  FROM t425a a, t425b b WHERE a.icard = b.icard;\r\n");
    fStat = unload_file(outputf, " ", ReportName, stitle, stmt);
    if (fStat != SUCCESS)
    {
        sprintf_s(sMsg, sizeof sMsg, " %s �ɮ׵L�k���� ", ReportName);
        return fStat;
    }

    /* unload_file �ɮײ��ͦb aphome/batchfile, �n����aphome/rptftp, rptftpinsert�~��o���ɮ� */
    sprintf_s(cmd_stmt, sizeof cmd_stmt,
            "mv %s/batchfile/%s %s/rptftp/%s;", aphome, outputf, aphome, ReportName);

    printf("cmd_stmt=[%s]\r\n", cmd_stmt);
    rc = system(cmd_stmt);
    if (rc != 0)
    {
        printf("mv file���~\r\n");
        sprintf_s(sMsg, sizeof sMsg, "mv file���~\r\n");
        return rc;
    }

    rc = rptftpinsert(userid, "car425", ReportName);
    printf("rptftpinsert rc[%d]\n", rc);
    if (rc != 0)
    {
        sprintf_s(sMsg, sizeof sMsg, "�g�Jrptftplist���~\r\n");
        return rc;
    }

    sprintf_s(sMsg, sizeof sMsg, "�d�ߧ���,���I���ɮפU���@�~�d��[Q],�U��[%s] \r\n", ReportName);
    return M_CM_OK;

errexit:
    printf("sqlerrcode=%d, sqlerrmsg=%s\n", SQLCODE, sqlca.sqlerrm);
    sprintf_s(sMsg, sizeof sMsg, "sqlerrcode=%d, sqlerrmsg=%s\n", SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}

/* -------------------------------------------------------------------------------*/

/* �j���I�P�����ʲz��Ʈw����--�H����Ƥ��ũ���  add by sylvis 103.06.19 (1030529010_C1) */
long car425_F()
{
    DBinfo *list;
    int i, count_db, iCount;
    char FullGetName[101], FullRtnName[101], sfilename[81], stitle[2048];
    char readstr[284];
    $char sRtFilename[81], cardbname[51], stmt[1000], cmd_stmt[20480], sTmpSQL[3000];
    $char Icar_a[18], Itag_a[13], Iassured_a[11], Ibirth_a[9], Isex_a[2],
        Icartype_a[3], Iqpt_a[6], Ifpt_a[3], Icar_b[18], Itag_b[13],
        Iassured_b[11], Ibirth_b[9], Icartype_b[3], Iqpt_b[6], Ifpt_b[3],
        Dget_itag[9], Nassured[3], Dchg_name[9], Data_from[2], Err_1[31],
        Dchg_status[9], Ichg_status[5], Dchg_itag[9], Ichg_itag[5],
        sIpolicy[21];
    $char Icard_n[18], Itag_n[13], Iassured_n[11], Dbirth_n[9], Fsex_n[2],
        Icar_type_n[3], Qpt_n[6], Fpt_n[3], Iofficer_n[11], Ileader_n[21],
        Iquota_n[41], Ndata_from[21], Nchg_status[41], Nchg_itag[41], Nerr[301],
        TmpErr1[4], TmpErr2[41], sXdb[3];
    int lenErr, icnt, x;

    /* �s�Jca_trade_notify ���� (add by sylvia 104.12.11(1041105005_C1) */
    $char sdbirth_1[11], sdbirth_2[11], stag_change[11], stransfer[11], schg_status[11],
        schg_tag[11];
    $char errmsg[100], errmsg2[10000];
    $int icnt_err;

    printf("----- car425_F START --------------------------- \n");
    if ((list = get_db_list(&count_db, DBName)) == (char *)0)
    {
        EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
        return M_CM_NOT_DBLIST;
    }

    $WHENEVER SQLERROR GOTO errexit;

    /* �Ȧs�פJ���H�����Ÿ�� */
    $create temp table tmp_425f(

        icar_a char(17), --(�O�o)�j���Ҹ� 
        itag_a char(12), --(�O�o)���� 
        iassured_a char(10), --(�O�o)�����Ҹ� 
        ibirth_a char(8), --(�O�o)�ͤ�(yyymmdd) 
        isex_a char(1), --(�O�o)�ʧO 
        icartype_a char(2), --(�O�o)���� 
        iqpt_a char(5), --(�O�o)�����ƶq 
        ifpt_a char(2), --(�O�o)������� 
        icar_b char(17), --(�ʲz��)�j���Ҹ� 
        itag_b char(12), --(�ʲz��)���� 
        iassured_b char(10), --(�ʲz��)�����Ҹ� 
        ibirth_b char(8), --(�ʲz��)�ͤ�(yyymmdd) 
        icartype_b char(2), --(�ʲz��)���� 
        iqpt_b char(5), --(�ʲz��)�����ƶq 
        ifpt_b char(2), --(�ʲz��)������� 
        dget_itag char(8), --(�ʲz��)���s�P�Ӥ��(yyyymmdd) 
        nassured char(2), --(�ʲz��)�m�W(�m) 
        dchg_name char(8), --(�ʲz��)�L����(yyyymmdd) 
        data_from char(1), --(�O�o)��ƨӷ� 
        err_1 char(30), --(�O�o)�����~�N�X 
        dchg_status char(8), --(�ʲz��)�������A���ʤ�(yyyymmdd) 
        ichg_status char(4), --(�ʲz��)�������A���ʥN�X 
        dchg_itag char(8), --(�ʲz��)�P�Ӫ��A���ʤ�(yyyymmdd) 
        ichg_itag char(4)--(�ʲz��)�P�Ӫ��A���ʥN�X
        
        ) with no log;

    $create temp table tmp_425f2(

        icar_a char(17), --(�O�o)�j���Ҹ� 
        itag_a char(12), --(�O�o)���� 
        iassured_a char(10), --(�O�o)�����Ҹ� 
        ibirth_a char(8), --(�O�o)�ͤ�(yyymmdd) 
        isex_a char(1), --(�O�o)�ʧO 
        icartype_a char(2), --(�O�o)���� 
        iqpt_a char(5), --(�O�o)�����ƶq 
        ifpt_a char(2), --(�O�o)������� 
        icar_b char(17), --(�ʲz��)�j���Ҹ� 
        itag_b char(12), --(�ʲz��)���� 
        iassured_b char(10), --(�ʲz��)�����Ҹ� 
        ibirth_b char(8), --(�ʲz��)�ͤ�(yyymmdd) 
        icartype_b char(2), --(�ʲz��)���� 
        iqpt_b char(5), --(�ʲz��)�����ƶq 
        ifpt_b char(2), --(�ʲz��)������� 
        dget_itag char(8), --(�ʲz��)���s�P�Ӥ��(yyyymmdd) 
        nassured char(2), --(�ʲz��)�m�W(�m) 
        dchg_name char(8), --(�ʲz��)�L����(yyyymmdd) 
        data_from char(20), --(�O�o)��ƨӷ� 
        dchg_status char(8), --(�ʲz��)�������A���ʤ�(yyyymmdd) 
        ichg_status char(4), --(�ʲz��)�������A���ʥN�X 
        nchg_status char(40), --(�ʲz��)�������A���ʤ��� 
        dchg_itag char(8), --(�ʲz��)�P�Ӫ��A���ʤ�(yyyymmdd) 
        ichg_itag char(4), --(�ʲz��)�P�Ӫ��A���ʥN�X 
        nchg_itag char(40), --(�ʲz��)�P�Ӫ��A���ʥN�X 
        icar_n char(17), --(�s�w)�j���Ҹ� 
        ipolicy_n char(20), --(�s�w)�O�渹 
        itag_n char(12), --(�s�w)���� 
        iassured_n char(10), --(�s�w)�����Ҹ� 
        ibirth_n char(8), --(�s�w)�ͤ�(yyymmdd) 
        isex_n char(1), --(�s�w)�ʧO 
        icartype_n char(2), --(�s�w)���� 
        iqpt_n char(5), --(�s�w)�����ƶq 
        ifpt_n char(2), --(�s�w)������� 
        iofficer char(10), --(�s�w)�g��N�� 
        ileader char(20), --(�s�w)�޲z�H 
        iquota char(40), --(�s�w)�~�Z��� 
        err_1 char(30), --(�O�o)�����~�N�X 
        nrr_1 char(300), --(�O�o)�����~�T�� 
        iup_quota char(10) default ' ', --���󥿸�Ƴ�� 
        iup_status char(10) default ' ', --���B�z���G 
        nmark char(10) default ' ' --�Ƶ�

        ) with no log;

    /* �O��������J�Φ����D����� */
    $create temp table tmp_425f3(
        icard char(17),
        err_msg char(101)) with no log;

    $DELETE FROM tmp_425f WHERE 1 = 1;
    $DELETE FROM tmp_425f2 WHERE 1 = 1;
    $DELETE FROM tmp_425f3 WHERE 1 = 1;

    sprintf_s(FullGetName, sizeof FullGetName, "%s/dat/car/%s", aphome, sFileName);
    printf("FullGetName = [%s]sFileName=[%s]\n", FullGetName, sFileName);

    $select first 1 '�H�����Ÿ�Ʃ���_' || to_char(current, '%Y%m%d%H%M%S') || '.txt' into $sRtFilename from ply_relation;

    printf("outputf=[%s]sRtFilename=[%s]\n", outputf, sRtFilename);
    if ((report = fopen(FullGetName, "r")) == NULL)
    {
        sprintf_s(sMsg, sizeof sMsg, "Cannot open ftp file: %s\n", FullGetName);
        printf("%s", sMsg);
        return M_CM_OPEN_FILE_FAIL;
    }

    $WHENEVER SQLERROR CONTINUE;
    iCount = icnt_err = 0;
    while (1)
    {
        fscanf(report, "%[^\n]%*c", readstr);
        if (feof(report))
            break;

        /* �N�ɮ׮ھکT�w�e��,Ū�X��� */
        strncpy(Icar_a, &readstr[0], 17);
        Icar_a[17] = '\0'; /* (�O�o)�j���Ҹ� */
        printf("Icar_a=[%s]\n", Icar_a);

        strncpy(Itag_a, &readstr[17], 12);
        Itag_a[12] = '\0'; /* (�O�o)���� */

        strncpy(Iassured_a, &readstr[29], 10);
        Iassured_a[10] = '\0'; /* (�O�o)�����Ҹ� */

        strncpy(Ibirth_a, &readstr[39], 8);
        Ibirth_a[8] = '\0'; /* (�O�o)�ͤ�(yyymmdd) */
        memset(sdbirth_1, 0x00, sizeof(sdbirth_1));
        if (strlen(trim(Ibirth_a)) > 0)
        {
            sprintf_s(sdbirth_1, sizeof sdbirth_1, "%.1s%.1s/%.1s%.1s/%.1s%.1s%.1s%.1s", &Ibirth_a[4], &Ibirth_a[5], &Ibirth_a[6], &Ibirth_a[7], &Ibirth_a[0], &Ibirth_a[1], &Ibirth_a[2], &Ibirth_a[3]);
        }

        strncpy(Isex_a, &readstr[47], 1);
        Isex_a[1] = '\0'; /* (�O�o)�ʧO */

        strncpy(Icartype_a, &readstr[48], 2);
        Icartype_a[2] = '\0'; /* (�O�o)���� */

        strncpy(Iqpt_a, &readstr[50], 5);
        Iqpt_a[5] = '\0'; /* (�O�o)�����ƶq */

        strncpy(Ifpt_a, &readstr[55], 1);
        Ifpt_a[1] = '\0'; /* (�O�o)������� */

        strncpy(Icar_b, &readstr[56], 17);
        Icar_b[17] = '\0'; /* (�ʲz��)�j���Ҹ� */

        strncpy(Itag_b, &readstr[73], 12);
        Itag_b[12] = '\0'; /* (�ʲz��)���� */

        strncpy(Iassured_b, &readstr[85], 10);
        Iassured_b[10] = '\0'; /* (�ʲz��)�����Ҹ� */

        strncpy(Ibirth_b, &readstr[95], 8);
        Ibirth_b[8] = '\0'; /* (�ʲz��)�ͤ�(yyymmdd) */
        memset(sdbirth_2, 0x00, sizeof(sdbirth_2));
        if (strlen(trim(Ibirth_b)) > 0)
        {
            sprintf_s(sdbirth_2, sizeof sdbirth_2, "%.1s%.1s/%.1s%.1s/%.1s%.1s%.1s%.1s", &Ibirth_b[4], &Ibirth_b[5], &Ibirth_b[6], &Ibirth_b[7], &Ibirth_b[0], &Ibirth_b[1], &Ibirth_b[2], &Ibirth_b[3]);
        }

        strncpy(Icartype_b, &readstr[103], 2);
        Icartype_b[2] = '\0'; /* (�ʲz��)���� */

        strncpy(Iqpt_b, &readstr[105], 5);
        Iqpt_b[5] = '\0'; /* (�ʲz��)�����ƶq */

        strncpy(Ifpt_b, &readstr[110], 1);
        Ifpt_b[1] = '\0'; /* (�ʲz��)������� */

        strncpy(Dget_itag, &readstr[111], 8);
        Dget_itag[8] = '\0'; /* (�ʲz��)���s�P�Ӥ��(yyyymmdd) */
        memset(stag_change, 0x00, sizeof(stag_change));
        if (strlen(trim(Dget_itag)) > 0)
        {
            sprintf_s(stag_change, sizeof stag_change, "%.1s%.1s/%.1s%.1s/%.1s%.1s%.1s%.1s", &Dget_itag[4], &Dget_itag[5], &Dget_itag[6], &Dget_itag[7], &Dget_itag[0], &Dget_itag[1], &Dget_itag[2], &Dget_itag[3]);
        }

        strncpy(Nassured, &readstr[119], 2);
        Nassured[2] = '\0'; /* (�ʲz��)�m�W(�m) */

        strncpy(Dchg_name, &readstr[121], 8);
        Dchg_name[8] = '\0'; /* (�ʲz��)�L����(yyyymmdd) */
        memset(stransfer, 0x00, sizeof(stransfer));
        if (strlen(trim(Dchg_name)) > 0)
        {
            sprintf_s(stransfer, sizeof stransfer, "%.1s%.1s/%.1s%.1s/%.1s%.1s%.1s%.1s", &Dchg_name[4], &Dchg_name[5], &Dchg_name[6], &Dchg_name[7], &Dchg_name[0], &Dchg_name[1], &Dchg_name[2], &Dchg_name[3]);
        }
        strncpy(Data_from, &readstr[129], 1);
        Data_from[1] = '\0'; /* (�O�o)��ƨӷ� */

        strncpy(Err_1, &readstr[130], 30);
        Err_1[30] = '\0'; /* (�O�o)�����~�N�X */

        strncpy(Dchg_status, &readstr[160], 8);
        Dchg_status[8] = '\0'; /* (�ʲz��)�������A���ʤ�(yyyymmdd) */
        memset(schg_status, 0x00, sizeof(schg_status));
        if (strlen(trim(Dchg_status)) > 0)
        {
            sprintf_s(schg_status, sizeof schg_status, "%.1s%.1s/%.1s%.1s/%.1s%.1s%.1s%.1s", &Dchg_status[4], &Dchg_status[5], &Dchg_status[6], &Dchg_status[7], &Dchg_status[0], &Dchg_status[1], &Dchg_status[2], &Dchg_status[3]);
        }

        strncpy(Ichg_status, &readstr[168], 4);
        Ichg_status[4] = '\0'; /* (�ʲz��)�������A���ʥN�X */

        strncpy(Dchg_itag, &readstr[172], 8);
        Dchg_itag[8] = '\0'; /* (�ʲz��)�P�Ӫ��A���ʤ�(yyyymmdd) */
        memset(schg_tag, 0x00, sizeof(schg_tag));
        if (strlen(trim(Dchg_itag)) > 0)
        {
            sprintf_s(schg_tag, sizeof schg_tag, "%.1s%.1s/%.1s%.1s/%.1s%.1s%.1s%.1s", &Dchg_itag[4], &Dchg_itag[5], &Dchg_itag[6], &Dchg_itag[7], &Dchg_itag[0], &Dchg_itag[1], &Dchg_itag[2], &Dchg_itag[3]);
        }

        strncpy(Ichg_itag, &readstr[180], 4);
        Ichg_itag[4] = '\0'; /* (�ʲz��)�P�Ӫ��A���ʥN�X */

        $insert into tmp_425f(icar_a, itag_a, iassured_a, ibirth_a, isex_a,
                              icartype_a, iqpt_a, ifpt_a, icar_b, itag_b,
                              iassured_b, ibirth_b, icartype_b, iqpt_b, ifpt_b,
                              dget_itag, nassured, dchg_name, data_from, err_1,
                              dchg_status, ichg_status, dchg_itag, ichg_itag)
            values($Icar_a, $Itag_a, $Iassured_a, $Ibirth_a, $Isex_a,
                   $Icartype_a, $Iqpt_a, $Ifpt_a, $Icar_b, $Itag_b,
                   $Iassured_b, $Ibirth_b, $Icartype_b, $Iqpt_b, $Ifpt_b,
                   $Dget_itag, $Nassured, $Dchg_name, $Data_from, $Err_1,
                   $Dchg_status, $Ichg_status, $Dchg_itag, $Ichg_itag);

        $insert into ca_trade_notify
            values($Icar_a, $Itag_a, $Iassured_a, $sdbirth_1, $Isex_a,
                   $Icartype_a, $Iqpt_a, $Ifpt_a, $Icar_b, $Itag_b,
                   $Iassured_b, $sdbirth_2, $Icartype_b, $Iqpt_b, $Ifpt_b,
                   $stag_change, $Nassured, $stransfer, $Data_from, $Err_1,
                   $schg_status, $Ichg_status, $schg_tag, $Ichg_itag,
                   $userid, current, $userid, current);

        if (SQLCODE != 0)
        {
            icnt_err++;
            printf("ERR=[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
            if (SQLCODE == -239)
                sprintf_s(errmsg, sizeof errmsg, "%s", "�j���Ҹ�ƭ���!!");
            else
                sprintf_s(errmsg, sizeof errmsg, "%d:%s", SQLCODE, sqlca.sqlerrm);
            $insert into tmp_425f3
                values($Icar_a, $errmsg);
        }
        iCount++;

    } /* Ū�ɧ��� */
    fclose(report);

    $WHENEVER SQLERROR GOTO errexit;

    /* �d�s�w��� */
    $DECLARE cur425_F1 CURSOR for
      SELECT icar_a, itag_a, iassured_a, ibirth_a, isex_a,
             icartype_a, iqpt_a, ifpt_a, icar_b, itag_b,
             iassured_b, ibirth_b, icartype_b, iqpt_b, ifpt_b,
             dget_itag, nassured, dchg_name, data_from, err_1,
             dchg_status, ichg_status, dchg_itag, ichg_itag,
             nvl((select b.ipolicy from compulsory_card b
               where b.icard = trim(a.icar_a[3,17])),' ')
       FROM tmp_425f a;
    $OPEN cur425_F1;
    while (1)
    {
        $FETCH cur425_F1 INTO
            $Icar_a,
            $Itag_a, $Iassured_a, $Ibirth_a, $Isex_a,
            $Icartype_a, $Iqpt_a, $Ifpt_a, $Icar_b, $Itag_b,
            $Iassured_b, $Ibirth_b, $Icartype_b, $Iqpt_b, $Ifpt_b,
            $Dget_itag, $Nassured, $Dchg_name, $Data_from, $Err_1,
            $Dchg_status, $Ichg_status, $Dchg_itag, $Ichg_itag, $sIpolicy;
        if (SQLCODE == SQLNOTFOUND)
            break;

        strcpy(sIpolicy, trim(sIpolicy));
        printf("sIpolicy=[%s]\n", sIpolicy);

        if (strlen(sIpolicy) == 0)
        {
            printf("�d�L�s�w�O��---------- \n");
            $insert into tmp_425f2(icar_a, itag_a, iassured_a, ibirth_a, isex_a,
                                   icartype_a, iqpt_a, ifpt_a, icar_b, itag_b,
                                   iassured_b, ibirth_b, icartype_b, iqpt_b, ifpt_b,
                                   dget_itag, nassured, dchg_name, data_from, dchg_status,
                                   ichg_status, nchg_status, dchg_itag, ichg_itag, nchg_itag,
                                   icar_n, ipolicy_n, itag_n, iassured_n, ibirth_n, isex_n,
                                   icartype_n, iqpt_n, ifpt_n, iofficer, ileader,
                                   iquota, err_1, nrr_1)
                values($Icar_a, $Itag_a, $Iassured_a, $Ibirth_a, $Isex_a,
                       $Icartype_a, $Iqpt_a, $Ifpt_a, $Icar_b, $Itag_b,
                       $Iassured_b, $Ibirth_b, $Icartype_b, $Iqpt_b, $Ifpt_b,
                       $Dget_itag, $Nassured, $Dchg_name, $Ndata_from, $Dchg_status,
                       $Ichg_status, $Nchg_status, $Dchg_itag, $Ichg_itag, $Nchg_itag,
                       "�D�s�w�O��", " ", " ", " ", " ", " ",
                       " ", " ", " ", " ", " ",
                       " ", " ", " ");
            continue;
        }
        strncpy(sXdb, sIpolicy, 2);
        sXdb[2] = '\0';
        printf("sXdb=[%s]\n", sXdb);

        strcpy(cardbname, get_full_dbname(sXdb));
        printf("cardbname=[%s]\n", cardbname);

        /* �d�s�w��� */
        sprintf_s(sTmpSQL, sizeof sTmpSQL,
                "select b.icard, b.itag, b.iassured, to_char(b.dbirth,'%%Y%%m%%d'), b.fsex, "
                "    a.icar_type, b.qpt, b.fpt, a.iofficer,  "
                "    (select nname from officer where iofficer = a.ileader), "
                "    (select nbranch from sa_branch_type where ibranch = a.iquota) "
                " from %s:ply_relation a, %s:policy b "
                " where a.ipolicy = b.ipolicy and a.ipolicy = '%s';",
                cardbname, cardbname, sIpolicy);
        printf("sTmpSQL=[%s]\n", sTmpSQL);

        $PREPARE pre425_F2 FROM $sTmpSQL;
        $EXECUTE pre425_F2 INTO $Icard_n, $Itag_n, $Iassured_n, $Dbirth_n, $Fsex_n,
            $Icar_type_n, $Qpt_n, $Fpt_n, $Iofficer_n, $Ileader_n,
            $Iquota_n;
        /* �O�o��ƨӷ�   */
        if (strcmp(Data_from, "1") == 0)
            strcpy(Ndata_from, "1:��O�e���d�ߤ��");
        else
            strcpy(Ndata_from, Data_from);

        /* �������A���ʤ��� */
        strcpy(Nchg_status, " ");
        $select chiname into $Nchg_status
            from car_code
                where kind = '35'
                    and detail = 'A02'
                        and detail2 = $Ichg_status;

        /* �P�Ӫ��A���ʤ��� */
        strcpy(Nchg_itag, " ");
        $select chiname into $Nchg_itag
            from car_code
                where kind = '35'
                    and detail = 'A03'
                        and detail2 = $Ichg_itag;

        /* ���~�N�X�T�� */
        strcpy(Err_1, trim(Err_1));
        lenErr = strlen(Err_1);
        printf("Err_1=[%s]lenErr=[%d]\n", Err_1, lenErr);
        if (lenErr == 0)
            strcpy(Nerr, " "); /* �L���~�N�X */
        else
        {
            memset(Nerr, 0x00, sizeof(Nerr));
            icnt = lenErr / 3;

            for (i = 0; i < icnt; i++)
            {
                x = i * 3;
                strncpy(TmpErr1, &Err_1[x], 3);
                TmpErr1[3] = '\0';

                printf("TmpErr1=[%s]\n", TmpErr1);
                strcpy(TmpErr2, " ");
                $select trim(chiname) || ';' into $TmpErr2
                                             from car_code
                                                 where kind = '35'
                    and detail = 'A01'
                        and detail2 = $TmpErr1;

                strcat(Nerr, trim(TmpErr2));
            }
            printf("Nerr=[%s]\n", Nerr);
        }

        $insert into tmp_425f2(icar_a, itag_a, iassured_a, ibirth_a, isex_a,
                               icartype_a, iqpt_a, ifpt_a, icar_b, itag_b,
                               iassured_b, ibirth_b, icartype_b, iqpt_b, ifpt_b,
                               dget_itag, nassured, dchg_name, data_from, dchg_status,
                               ichg_status, nchg_status, dchg_itag, ichg_itag, nchg_itag,
                               icar_n, ipolicy_n, itag_n, iassured_n, ibirth_n, isex_n,
                               icartype_n, iqpt_n, ifpt_n, iofficer, ileader,
                               iquota, err_1, nrr_1)
            values($Icar_a, $Itag_a, $Iassured_a, $Ibirth_a, $Isex_a,
                   $Icartype_a, $Iqpt_a, $Ifpt_a, $Icar_b, $Itag_b,
                   $Iassured_b, $Ibirth_b, $Icartype_b, $Iqpt_b, $Ifpt_b,
                   $Dget_itag, $Nassured, $Dchg_name, $Ndata_from, $Dchg_status,
                   $Ichg_status, $Nchg_status, $Dchg_itag, $Ichg_itag, $Nchg_itag,
                   $Icard_n, $sIpolicy, $Itag_n, $Iassured_n, $Dbirth_n, $Fsex_n,
                   $Icar_type_n, $Qpt_n, $Fpt_n, $Iofficer_n, $Ileader_n,
                   $Iquota_n, $Err_1, $Nerr);
    } /* END while */

    strcpy(stitle, "(�O�o)�j���I�Ҹ��X\t(�O�o)����\t(�O�o)�����Ҹ�(�νs)\t");
    strcat(stitle, "(�O�o)�ͤ�\t(�O�o)�ʧO\t(�O�o)�j���I����\t(�O�o)�����ƶq\t");
    strcat(stitle, "(�O�o)�������\t(�ʲz��)�j���I�Ҹ��X\t(�ʲz��)����\t");
    strcat(stitle, "(�ʲz��)�����Ҹ�(�νs)\t(�ʲz��)�ͤ�\t(�ʲz��)�j���I����\t");
    strcat(stitle, "(�ʲz��)�����ƶq\t(�ʲz��)�������\t(�ʲz��)���s�P�Ӥ��\t");
    strcat(stitle, "(�ʲz��)�m�W(�m)\t(�ʲz��)�L����\t(�O�o)��ƨӷ�\t");
    strcat(stitle, "(�ʲz��)�������A���ʤ�\t(�ʲz��)�������A���ʥN�X\t");
    strcat(stitle, "(�ʲz��)�������A����(����)\t(�ʲz��)�P�Ӫ��A���ʤ�\t");
    strcat(stitle, "(�ʲz��)�P�Ӫ��A���ʥN�X\t(�ʲz��)�P�Ӫ��A����(����)\t");
    strcat(stitle, "(�s�w)�j���Ҹ�\t(�s�w)�O�渹\t(�s�w)����\t(�s�w)�����Ҹ�\t(�s�w)�ͤ�\t");
    strcat(stitle, "(�s�w)�ʧO\t(�s�w)�j���I����\t(�s�w)�����ƶq\t(�s�w)�������\t");
    strcat(stitle, "(�s�w)�g��N��\t(�s�w)�޲z�H�W��\t(�s�w)�~�Z���W��\t");
    strcat(stitle, "�s�w�κʲz����Ƥ����~�N�X\t�s�w�κʲz����Ƥ����~�����~��](����)\t");
    strcat(stitle, "���󥿸�Ƴ��\t���B�z���G\t�Ƶ�\t");

    sprintf_s(stmt, sizeof stmt, "SELECT * from tmp_425f2 where 1=1");

    printf("stmt[%s]\n", stmt);

    rc = unload_file(outputf, " ", sRtFilename, stitle, stmt);
    if (rc != SUCCESS)
    {
        sprintf_s(sMsg, sizeof sMsg, "%d:%s �ɮ׵L�k����", rc, sRtFilename);
        printf(sMsg);
        goto errexit;
    }

    /* unload_file �ɮײ��ͦb aphome/batchfile, �n����aphome/rptftp, rptftpinsert�~��o���ɮ� */
    sprintf_s(cmd_stmt, sizeof cmd_stmt,
            "mv %s/batchfile/%s  %s/rptftp/%s", aphome, outputf, aphome, sRtFilename);

    printf("cmd_stmt=[%s]\r\n", cmd_stmt);
    rc = system(cmd_stmt);
    if (rc != 0)
    {
        printf("mv file���~\r\n");
        sprintf_s(sMsg, sizeof sMsg, "mv file���~\r\n");
        return rc;
    }

    rc = rptftpinsert(userid, "car425", sRtFilename);
    printf("rptftpinsert rc[%d]\n", rc);
    if (rc != 0)
    {
        sprintf_s(sMsg, sizeof sMsg, "�g�Jrptftplist���~\r\n");
        return rc;
    }

    /* �d�U���~����!! */
    memset(errmsg2, 0x00, sizeof(errmsg2));
    if (icnt_err > 0)
    {
        strcpy(errmsg2, "\n\n ���ɦܸ�Ʈw���~�p�U�A�ЦA�T�{�I�I \n�@�j���Ҹ��@�@�@�@    ���~��]\n");
        $DECLARE cur425_FERR CURSOR for
            SELECT * from tmp_425f3;
        $OPEN cur425_FERR;
        while (1)
        {
            $FETCH cur425_FERR INTO $Icar_a, $errmsg;
            if (SQLCODE == SQLNOTFOUND)
                break;
            sprintf_s(Nerr, sizeof Nerr, " %.17s   %s \n", Icar_a, errmsg);
            strcat(errmsg2, Nerr);
        }
    }
    sprintf_s(sMsg, sizeof sMsg, "�d�ߧ���,���I���ɮפU���@�~�d��[Q],�U��[%s] \r\n", sRtFilename);
    strcat(sMsg, errmsg2);
    return M_CM_OK;

errexit:
    printf("sqlerrcode=%d, sqlerrmsg=%s\n", SQLCODE, sqlca.sqlerrm);
    sprintf_s(sMsg, sizeof sMsg, "car425_F: sqlerrcode=%d, sqlerrmsg=%s\n", SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}

/* ---------------------------------------------------------------------------- */
