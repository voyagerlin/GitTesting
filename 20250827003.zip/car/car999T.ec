/************************************************
 * Copyright (C) 1995 Intellisys Corporation    *
 *                                              *
 * Program : car999T.ec                         *
 *      ��o�i���߸�ƳB�z:�ި��               *
 ************************************************/
#include <stdio.h>
#include "api_xsrv.h"
#include "sqlfatal.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "car_common.h"
#include "safeclib.h"

/* standard data declaration */
  FILE *fptr, *fptr_err;
  $char userid[11], iquota[7];
  char prtfile[80],outputf[80],outputf1[80];
  char errmsg[200];
  $char errFile[120];
/* end of standard data */
/* private data */
/* end of private data */

$char localdb[5],Taipei_FullName[20];
int  i=0, flag_check=0;
/* end of standard defined data */

$char expdate[6];
char bgndate[10],enddate[10];
long car9990_build();
char option[2];
$static char remotedb[DBNAME];
$char   expdate_2[7];

$char DBName[05];
$char msgbuf[128];
DBinfo *list;
char  sApHome[30];
int   rtncode=0,rc=0;
char  filename[30];
FILE  *fp;
char  file_catalog[200];
$char filename1[200];
char sTmpMsg[1024];
/*************************************************************/

main(argc,argv)
int argc;
char **argv;
{
	int rtncode,rc;

	strcpy(DBName,       isNULLstr(argv[1]));
	strcpy(userid,       isNULLstr(argv[2]));
	strcpy(expdate,      isNULLstr(argv[3]));
	strcpy(outputf,      isNULLstr(argv[4]));
	
	printf("DBName[%s],userid[%s],expdate[%s],outputf[%s] \n",DBName,userid,expdate,outputf);
	
	rc = car999T_get_db();
	if (rc != M_CM_OK)
	{
		return rc;
	}
	
	rc = car999T_build();
	if ( rc != SUCCESS ) {
	 	printf("error on car999T_show \n");
	 	EWRITE(userid, rc, errmsg);
		return rc;
	}
}

long car999T_get_db()
{
	$whenever sqlerror goto errexit1;

	if (db_select(DBName) == DBName) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}
	
	rc = getApHome(sApHome);
	if (rc < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		EWRITE(userid,rc,msgbuf);
	 	return rc;
	}
	return M_CM_OK;

errexit1:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}

long car999T_build()
{
int     res=0;
$static date   Today;
$char   aphome[40];
$char   stmt[2000];
$char   prtstr[110];
int     rtn=0,idx=0;
$int    cnt=0;

$char   iclass[5];
$long   qcnt=0,mprem=0;
$double mhealth;
$double pure_mprem,mcompensation,mstable,mdrunk_pure_prem;
$char   qcnt_c[10],mprem_c[15],pure_mprem_c[19];
$char   mcompensation_c[19],mstable_c[19],mhealth_c[19],mdrunk_pure_prem_c[19];
$int    x=0;
$int    iexpdate=0;
int     z[6]= {1,2,3,9,0,4};
$int    z_tmp;

	$WHENEVER SQLERROR GOTO errexit;
	
	filename[0] = '\0';
	file_catalog[0] = '\0';
	sprintf_s(filename, sizeof filename,"%s/rptftp/", sApHome);
	sprintf_s(filename1, sizeof filename1,"AUTOT17_%d.txt",atoi(expdate)+191100);
	strcpy(file_catalog, trim(filename));
	strcat(file_catalog, trim(filename1));
	printf("file_catalog[%s] \n",file_catalog);
	
	if ((fptr=fopen(file_catalog,"w")) == NULL)
	{
		sprintf_s(errmsg, sizeof errmsg,"Cannot open print file:%s",outputf);
		return M_CM_OPEN_FILE_FAIL;
	}

	/* *** open error log file *** */
	res = getApHome(aphome);
	sprintf_s(errFile, sizeof errFile,"%s.%s.error",outputf,DBName);
	printf("ERRFILE[%s]\n",errFile);
	if ((fptr_err=fopen(errFile,"w")) == NULL)
	{
		sprintf_s(errmsg, sizeof errmsg,"Cannot open print file: %s",errFile);
		return M_CM_OPEN_FILE_FAIL;
	}
	
	printf("expdate[%s] \n",expdate);
	/*iexpdate = atoi(expdate)+191100;
	strcpy(expdate_2,itoa(iexpdate));*/
	sprintf_s(expdate_2, sizeof expdate_2,"%d",atoi(expdate)+191100);
	strcpy(expdate_2,trim(expdate_2));
	printf("expdate_2[%s] \n",expdate_2);

	prtstr[0] = '\0';
	x = 0;
	while( x < 6 )
	{
		strcpy(iclass,"999");
		strcat(iclass,itoa(z[x]));
		strcpy(iclass,trim(iclass));
		printf("--iclass[%s] \n",iclass);
		
		z_tmp = z[x];
		printf("z_tmp[%d] \n",z_tmp);
		
		mprem = 0;
		qcnt  = 0;
		pure_mprem    = 0.0;
		mcompensation = 0.0;
		mstable = 0.0;
		mhealth = 0;
		mdrunk_pure_prem = 0.0;
		
		/* SQL */
		sprintf_s(stmt, sizeof stmt,"SELECT nvl(sum(mprem),0), nvl(sum(qcnt),0), nvl(sum(pure_mprem),0), "
		             "       nvl(sum(mcompensation),0), nvl(sum(mstable),0), nvl(sum(mhealth),0), "
		             "       nvl(sum(mdrunk_pure_prem),0) "
	                 "  FROM ca_develop "
	                 " WHERE data_yyyymm = '%s' "
	                 "   AND iclass = '%s' "
	                 "   AND product_kind = '99';",expdate_2,iclass);
		$prepare ca_data from $stmt;
		printf("--stmt[%s] \n",stmt);
		$execute ca_data into $mprem,$qcnt,$pure_mprem,$mcompensation,$mstable,$mhealth,$mdrunk_pure_prem;
		printf("--mprem[%d],qcnt[%d],pure_mprem[%f],mcompensation[%f],mstable[%f],mhealth[%f],mdrunk_pure_prem[%f] \n",
		          mprem,qcnt,pure_mprem,mcompensation,mstable,mhealth,mdrunk_pure_prem);
		
		/* C1-6  �έp�~�� */
		strcat(prtstr,expdate_2);
		prtstr[6] = '\0';
		/* C7-8  ���q�N�� */
		strcat(prtstr,"17");
		prtstr[8] = '\0';
		/* C9-9  ��ƧO */
		switch(z_tmp)
		{
	  		case 0:
	           		strcat(prtstr,"M");
	           		break;
	  		case 1:
	           		strcat(prtstr,"P");
	           		break;
	        case 2:
	           		strcat(prtstr,"E");
	           		break;
	        case 3:
	           		strcat(prtstr,"C");
	           		break;
	        case 4:
	           		strcat(prtstr,"U");
	           		break;
	        case 9:
	           		strcat(prtstr,"S");
	           		break;
		}
		prtstr[9] = '\0';
		/* C10-18 ��Ƥ�� */
		qcnt_c[0] = '\0';
		rfmtlong(qcnt,"&&&&&&&&&",qcnt_c);
		printf("--qcnt_c[%s]\n",qcnt_c);
		strcat(prtstr,qcnt_c);
		prtstr[18] = '\0';
		
		/* C19-33 �`�O�O */
		mprem_c[0] = '\0';
		if(mprem >= 0)
	        strcat(prtstr,"+");
	    else 
	        strcat(prtstr,"-");
	    rfmtlong(mprem,"&&&&&&&&&&&&&&",mprem_c);
		strcat(prtstr,mprem_c);
		prtstr[33] = '\0';
		
		/* C34-52 �«O�O */
		mhealth_c[0] = '\0';
		pure_mprem_c[0] = '\0';
		if(z_tmp == 1 || z_tmp == 2)
		{
			pure_mprem *= 10000;
			if(pure_mprem >= 0)
		        strcat(prtstr,"+");
		    else 
		        strcat(prtstr,"-");
		    rfmtdouble(pure_mprem,"&&&&&&&&&&&&&&&&&&",pure_mprem_c);
			strcat(prtstr,pure_mprem_c);
		}
		else if(z_tmp == 3 || z_tmp == 9)
		{
			if(mhealth >= 0)
		        strcat(prtstr,"+");
		    else 
		        strcat(prtstr,"-");
		    mhealth *= 10000;
		    printf("mhealth[%f]\n",mhealth);
		    rfmtdouble(mhealth,"&&&&&&&&&&&&&&&&&&",mhealth_c);
			strcat(prtstr,mhealth_c);
		}
		else 
		{
			if(pure_mprem >= 0)
		        strcat(prtstr,"+");
		    else 
		        strcat(prtstr,"-");
		    rfmtdouble(pure_mprem,"&&&&&&&&&&&&&&&&&&",pure_mprem_c);
			strcat(prtstr,pure_mprem_c);
		}
		prtstr[52] = '\0';
		
		/* C53-71 �s�r�«O�O (��Ʈw�S���s�A��ʸɤW)*/
		if(z_tmp == 1 || z_tmp == 2)
		{
			mdrunk_pure_prem *= 10000;
			if(mdrunk_pure_prem >= 0)
		        strcat(prtstr,"+");
		    else 
		        strcat(prtstr,"-");
		    rfmtdouble(mdrunk_pure_prem,"&&&&&&&&&&&&&&&&&&",mdrunk_pure_prem_c);
			strcat(prtstr,mdrunk_pure_prem_c);
		}
		else 
		{
			strcat(prtstr,"+000000000000000000");
		}
		
		prtstr[71] = '\0';
		
		/* C72-90:�S�ɤ����B */
		mcompensation_c[0] = '\0';
		if(z_tmp == 1 || z_tmp == 2)
		{
		    mcompensation *= 10000;
		    if(mcompensation >= 0)
		        strcat(prtstr,"+");
		    else 
		        strcat(prtstr,"-");
		    rfmtdouble(mcompensation, "&&&&&&&&&&&&&&&&&&", mcompensation_c);
		    strcat(prtstr,mcompensation_c);
		    prtstr[90]='\0';
		    
		    /* C91-109:�w�w��� */
	        mstable *= 10000;
	        if(mstable >= 0)
	            strcat(prtstr,"+");
	        else 
	            strcat(prtstr,"-");
	        rfmtdouble(mstable, "&&&&&&&&&&&&&&&&&&", mstable_c);
	        strcat(prtstr,mstable_c);
        	prtstr[109]='\0';
        }
        else 
        {
        	strcat(prtstr,"+000000000000000000");
        	prtstr[90]='\0';
        	strcat(prtstr,"+000000000000000000");
        	prtstr[109]='\0';
        }
        x++;
        fprintf(fptr,"%s\n",prtstr);
	}

	fclose(fptr);
	
	res = getApHome(aphome);
	if (res<0) {
	    printf("In sigalrmcatcher func==>read config file error!!\n");
	    exit(1);
	}
	
	sprintf_s(sTmpMsg, sizeof sTmpMsg, "%s%s\n", "���ɧ���:", file_catalog);

	EWRITE(userid, M_CM_OK, sTmpMsg);
	
	return SUCCESS;

errexit:
	printf("userid=%s SOLCODE=%d sqlca.sqlerrm=%s\n",userid,SQLCODE,sqlca.sqlerrm);
	printf(errmsg,"userid=%s SOLCODE=%d sqlca.sqlerrm=%s",userid,SQLCODE,sqlca.sqlerrm);
	fprintf(fptr_err,"%d\n",SQLCODE);
	return SQLCODE;
}
