/**********************************************************************/
/*                                                                    */
/*   program id   : car998m01s.ec                                     */
/*   program name : �����T��ƳB�z�@�~                                */
/*   date written : 2001/10/05                                        */
/*   date modify  : 2001/mm/dd                                        */
/*   author       : salinna                                           */
/*   files        : ca_trade_exam          i                          */
/*                                                                    */
/**********************************************************************/

#include <stdio.h>
#include <string.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "sql.h"
#include "is_def.h"
#include "carmsgs.h"
#include "cmnmsgs.h"
#include "commsgs.h"
#include <time.h>
$include sqlca;
$include datetime.h;
long MsgCode;
#include "safeclib.h"

char   DBName[DBNAME];
static long car998_multiple_query();
static long car998_update_exec();

long rtncode;



$char stmt[1024];
int   i=0;
long  tot_count=0;
 $char stmt_buf[300];
 $char buf1[100];
 $char userid[11];
 $char iply_type[3],dbgn1[11],dend1[11],fcard_class[2];
 $char str_itrans_type[2];
 $char int_itrans_type[2];
 
 $int itrans_type=0;
 $char dbgn[11],dend[11];
 
 $char m_iply_type[3],m_dpolicy[11],m_fcard_class[2];
 $int  m_itrans_type=0, m_qcount=0,m_mamount=0,m_minjure=0,m_mcripple=0;
 $int m_mdeath=0,m_qtradevan=0,m_qerr=0,m_qout=0;
 
 /*char m_iply_type[3],m_dpolicy[11],m_fcard_class[2];
 int  m_itrans_type=0, m_qcount=0,m_mamount=0,m_minjure=0,m_mcripple=0;
 int m_mdeath=0,m_qtradevan=0,m_qerr=0,m_qout=0;*/
 
 $char u_iply_type[3],u_dpolicy[11],u_fcard_class[2];
 $int u_qcount=0,u_mamount=0,u_minjure=0,u_mcripple=0;
 $int u_mdeath=0,u_qtradevan=0,u_qerr=0,u_qout=0;
 $char temp_dpolicy[11];

 $int u_itrans_type=0;
 
 $int  ItemRow=0, TotColumn=0;
 $int  StartRow=0,TitleRow=0;
 $int  PgLine=0, Width=0;
 long  max_count=0;

/***************************************************************************/
long car998(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 
 char option;
 int  tmp_len;
 cm_buf_init(command);
 cm_buf_get("%c",&option); 
 
 switch(option)
 {
  case 'M':
           rtncode=car998_multiple_query(reply);
           break;

  case 'U':
	   rtncode=car998_update_exec(reply,command,com_len);
           break;              

  default :
           if(exitsub(reply,M_CM_WRONG_OPTION) == True)
              return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}
 
long car998_multiple_query(reply)
serverReply reply;
{

 char  tmpbuf[4000];
 int   count=0, repbuf_len=0,tmp_len=0,replycnt=0,is_fail=0;
 
 cm_buf_get("%s",DBName);
 cm_buf_get("%s",userid);
 cm_buf_get("%s",iply_type);
 cm_buf_get("%s",dbgn1);
 cm_buf_get("%s",dend1);
 cm_buf_get("%s",fcard_class);
 cm_buf_get("%s",str_itrans_type);
 
 printf("str_itrans_type[%s]\n",str_itrans_type);
 
 if(strncmp(trim(str_itrans_type),"*",1)==0)
 {
    sprintf_s(buf1, sizeof buf1, " ");
  }	
 
 else
 {    printf("str_itrans_type[%s]\n",str_itrans_type);
      strcpy(int_itrans_type,str_itrans_type);
      printf("int_itrans_type[%s]\n",int_itrans_type);
      itrans_type=atoi(int_itrans_type);
      printf("itrans_type[%d]\n",itrans_type);
      sprintf_s(buf1, sizeof buf1," AND itrans_type = %d ",itrans_type); 
  } 
 
 printf("int_itrans_type[%s]\n",int_itrans_type);
 strcpy(dbgn,cm_to_infdate(dbgn1));
 strcpy(dend,cm_to_infdate(dend1));
 
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False) {
     if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
         return M_CM_DB_NOTOPEN;
     else
         return apiRC;
 }
     
 
  sprintf_s(stmt, sizeof stmt,
      "SELECT iply_type,dpolicy,fcard_class,itrans_type,qcount, \
              mamount, minjure,mcripple, \
              mdeath,qtradevan, qerr, qout \
         FROM ca_trade_exam \
        WHERE iply_type matches ? \
          AND dpolicy >= ? \
          AND dpolicy <= ? \
          AND fcard_class matches ? %s \
        ORDER BY 2,4,1,3",buf1);

   
  printf("stmt[%s]\n",stmt);
  $PREPARE Pre1 FROM $stmt;
  $DECLARE Acursor CURSOR FOR Pre1;

  $WHENEVER SQLERROR GOTO errexit;

  printf("dbgn[%s]\n",dbgn);
  printf("dend[%s]\n",dend);
 
  $OPEN Acursor USING $iply_type,$dbgn,$dend,$fcard_class;

  printf("DBGN[%s]\n",dbgn);

  i=tot_count=0;

  while (1) {
     
       $FETCH Acursor
       INTO $m_iply_type, $m_dpolicy, $m_fcard_class, $m_itrans_type,$m_qcount,
            $m_mamount,$m_minjure,$m_mcripple,$m_mdeath,$m_qtradevan,
            $m_qerr,$m_qout;

      
      if(SQLCODE == SQLNOTFOUND) break;
      
      strcpy(m_dpolicy,cm_from_infdate_100(m_dpolicy));

      i++;
      tot_count++;

      cm_buf_init(tmpbuf);
      if (count == 0) {
          cm_buf_res_msg();
          cm_buf_res_count();
      }
      cm_buf_put("%s %s %s %d %d %d %d %d %d %d %d %d",
                 m_iply_type,m_dpolicy,m_fcard_class,m_itrans_type,
                 m_qcount,m_mamount,m_minjure,m_mcripple,
                 m_mdeath,m_qtradevan,m_qerr,m_qout);

      tmp_len = cm_buf_len(tmpbuf);

      if (tmp_len + repbuf_len < 3300)
      {
          memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
          repbuf_len += tmp_len;
          count++;
      } else {
          cm_buf_init(ReplyBuf);
          cm_buf_put_msg(M_CM_OK);
          cm_buf_put_count(count);
          sleep (3);
          if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False){
              $CLOSE Acursor; $FREE Acursor;
              return apiRC;
          } else {
             replycnt++;
             if (replycnt == 10){ /*more than 30K, client cannot display,error*/
                 cm_buf_init(ReplyBuf);
                 cm_buf_put("%l",M_CM_OUT_SPACE);
                 tmp_len = cm_buf_len(ReplyBuf);
                 if (SendSyncReply(reply,ReplyBuf,tmp_len,
                                   api_OKComplete)==False){
                     $CLOSE Acursor; $FREE Acursor;
                     return apiRC;
                 } else {
                     $CLOSE Acursor; $FREE Acursor;
                     return M_CM_OUT_SPACE;
                 }
             }
             ReplyBuf[0]='\0';
             count=0;
             cm_buf_init(ReplyBuf);
             cm_buf_res_msg();
             cm_buf_res_count();
             cm_buf_put("%s %s %s %d %d %d %d %d %d %d %d %d",
                         m_iply_type,m_dpolicy,m_fcard_class,m_itrans_type,
                         m_qcount,m_mamount,m_minjure,m_mcripple,
                         m_mdeath,m_qtradevan,m_qerr,m_qout);
               repbuf_len = cm_buf_len(ReplyBuf);
             count++;
          }
      }
 }
 $CLOSE Acursor;
 $FREE  Acursor;
printf(">>>>>>>>>>>> count[%d] tot_count[%d]\n",count,tot_count);
 if(is_fail)
      return exitsub(reply,M_CM_NOT_MALLOC) ? M_CM_NOT_MALLOC : apiRC;  

 if (count>0)
 {
     cm_buf_init(ReplyBuf);
     cm_buf_put_msg(M_CM_OK);
     cm_buf_put_count(count);
     if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
         return apiRC;
     return api_OKComplete;
 } else
     return exitsub(reply,M_CM_NOT_FOUND) ? M_CM_NOT_FOUND : apiRC;
errexit:
 
      return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long car998_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
   $char DBName[5];
   char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
   int tmp_len=0,raw_len=0; 
   long dummy=0;
   DBinfo *list;
   int i=0, j=0, is_del_fail=0, is_upd_fail=0;
   $char stmt_buf[300];
   int vbcount=0;
   $int up_count=0;
 comm = (char *) command;

 cm_buf_get("%s",DBName);
 cm_buf_get("%s",userid);
 cm_buf_get("%d",&up_count);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
     return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
 
 $BEGIN WORK;
 for(vbcount=1;vbcount<=up_count;vbcount++)
 {
 
   cm_buf_get("%s",u_iply_type);	
   cm_buf_get("%s",u_dpolicy);
   cm_buf_get("%s",u_fcard_class);
   cm_buf_get("%d",&u_itrans_type);
   cm_buf_get("%d",&u_qcount);
   cm_buf_get("%d",&u_mamount);
   cm_buf_get("%d",&u_minjure);
   cm_buf_get("%d",&u_mcripple);
   cm_buf_get("%d",&u_mdeath);
   cm_buf_get("%d",&u_qtradevan);
   cm_buf_get("%d",&u_qerr);
   cm_buf_get("%d",&u_qout); 

   strcpy(temp_dpolicy,cm_to_infdate(u_dpolicy));   
      
   $WHENEVER SQLERROR CONTINUE;

    sprintf_s(stmt_buf, sizeof stmt_buf,
		"UPDATE ca_trade_exam \
    		    SET (qtradevan,qerr,qout)\
		      = (?,?,?) \
		  WHERE iply_type = ? \
                    AND dpolicy = ? \
                    AND fcard_class = ? \
                    AND itrans_type = ? ");
    $PREPARE ua_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
     }
    $EXECUTE ua_id USING $u_qtradevan,$u_qerr,$u_qout,
                         $u_iply_type,$temp_dpolicy,$u_fcard_class,$u_itrans_type;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
     }
     
     if( is_upd_fail ) goto errexit;
   
   } /* END FOR LOOP  */
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
   {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
   }
   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
 
  errexit:  
  MsgCode = SQLCODE;
  cm_show_sql_err("car998_update_exec", stmt_buf);
  $WHENEVER SQLERROR CONTINUE;
  $ROLLBACK WORK;
  if(SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True)
   return MsgCode;
  else
   return apiRC;
}
