/*******************************************/
/*                                         */
/*   �M�׽дک���                          */
/*                                         */
/*   PROGRAM : ca626q01s.ec                */
/*   DATE    : 91.09.18                    */
/*   Modify  : 93.03.11                    */
/*******************************************/
#include <stdio.h>
#include <unistd.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "safeclib.h"
#define  head_line         1
#define  desc_line         2
#define  data_line         2

extern char RPTDIR[];

$char dbgn1[11], dend1[11];
$char dbgn_inf[11], dend_inf[11];
char  MsgCode[50];
$char Igroup[7],Ngroup[21];
char  iprmt[11],opt_date[2];
char  qnext_year[2];				/* Modified by Julia Han in 2007/04/30 */

$char iquota[7],icard[21],ipolicy[21],iendorse[21],iassured[18];
$char nassured[25],dpolicy[11],dply_begin[11],ibrand[9],ori_dpolicy[11];
$char iengine[21],iissue_ym[7],ibig_office[10],ibig_office_c[11],itag[CA_TAG_NUM],nbrand_abbr[13];
$long mprem_11,mprem_17,mprem_16,mprem_oth,mdiscount,pdiscount = 0;
$long mdis_11,mdis_17,mdis_16,medr_discount = 0;
$char iassured1[13],iassured2[3],iins_type[7],ipro_year[5],nbrand[31],drate[11];
$char bufA[80];
$double rSafe_16,rSafe_11,rSafe_17,rSafe_oth;
$double rMgmt_16,rMgmt_11,rMgmt_17,rMgmt_oth;
$char   napplicant[25],iapplicant[13];
$double tmp_safe=0,tmp_manage=0;

$char DBName[05], iForm_Tp[03];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1];
char  outputf[N_FILE+1], userid[11];

$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;
$char check1[2],check2[2],stmtX[1000],opt[2],fply_close[2];

int  max_cnt;

long car626_build1();
long car626_build2();
long car626_body1();
long car626_body2();
long car626_accumulate();
void car626_title();
void print_car626_body1();
void print_car626_body2();
/*----------------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
   int rc;
   batchinit();
   strcpy(DBName,  isNULLstr(argv[1]));
   strcpy(userid,  isNULLstr(argv[2]));
   strcpy(iprmt,   isNULLstr(argv[3]));
   strcpy(dbgn1,   isNULLstr(argv[4]));
   strcpy(dend1,   isNULLstr(argv[5]));
   strcpy(check1,  isNULLstr(argv[6]));
   strcpy(check2,  isNULLstr(argv[7]));
   strcpy(opt,     isNULLstr(argv[8]));
   strcpy(fply_close,  isNULLstr(argv[9]));
   strcpy(opt_date,isNULLstr(argv[10]));
   strcpy(qnext_year, isNULLstr(argv[11]));
   strcpy(outputf, isNULLstr(argv[12]));

printf("opt[%s]\n",opt); 

   if (opt[0]=='1') {      /* ca626q02s.ec ���ثP�P�M�� */      
      rc = car6261(DBName,userid,dbgn1,dend1,check1,check2,fply_close,qnext_year,outputf);
      return rc;
   }
   if ((opt[0]=='2')||(opt[0]=='7')) { /* ��L�P�P�M��:  2:�дک���_��L 7:�g�P�ӹ�b_��L   modify by sylvia 103.12.11(10311110001_C3)*/
      if (strncmp(iprmt,"C",1)==0) { /* ca626q05s.ec ���� */
         rc = car6265(DBName,userid,iprmt,dbgn1,dend1,check1,check2,
                   opt_date,fply_close,qnext_year,outputf);
         return rc;
      }
      else { /* ca626q03s.ec �P�P�M��*/
         rc = car6263(DBName,userid,iprmt,dbgn1,dend1,check1,check2,
                   opt_date,fply_close,qnext_year,outputf);
         return rc;
      }
   }
   if (opt[0]=='3') { /* ca626q04s.ec �����O���ŦX�M��,���ݤ��s/��O�� */
      rc = car6264(DBName,userid,iprmt,dbgn1,dend1,opt_date,outputf);
      return rc;
   }
/******
   if (opt[0]=='4') {
      printf("opt[%s]\n",opt);
      rc = car6265(DBName,userid,dbgn1,dend1,check1,check2,fply_close,qnext_year,outputf);
      printf("rc[%d]\n",rc);
      return rc;
   }
******/
   
   if (opt[0]=='5') {      /* ca626q06s.ec */
      rc = car6266(DBName,userid,dbgn1,dend1,check1,check2,fply_close,qnext_year,outputf);
      return rc;
   }
  
/********* ca625q07s.ec
   if (opt[0]=='6') {
      printf("opt[%s]\n",opt);
      rc = car6267(DBName,userid,dbgn1,dend1,check1,check2,fply_close,qnext_year,outputf);
      printf("rc[%d]\n",rc);
      return rc;
   }
**********/
 
   strcpy(dbgn_inf, cm_to_infdate(dbgn1));
   strcpy(dend_inf, cm_to_infdate(dend1));

   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False) {
       return M_CM_DB_NOTOPEN;
   }

   $CREATE TEMP TABLE CAR626
    (
      iquota        char(6)     default ' ',
      icard         char(20)    default ' ',
      ipolicy       char(20)    default ' ',
      iendorse      char(20)    default ' ',
      iassured1     char(12)    default ' ',
      iassured2     char(2)     default ' ',
      nassured      char(24)    default ' ',
      iapplicant    char(12)    default ' ',
      napplicant    char(24)    default ' ',
      dpolicy       char(10)    default ' ',
      dply_begin    char(10)    default ' ',
      ibrand        char(8)     default ' ',
      ipro_year     char(5)     default ' ',
      iengine       char(20)    default ' ',
      iissue_ym     char(6)     default ' ',
      ibig_office   char(9)     default ' ',
      itag          char(12)     default ' ',
      ori_dpolicy   char(10)    default ' ',
      mprem_11      integer     default 0 not null,
      mdis_11       integer     default 0 not null,
      mprem_17      integer     default 0 not null,
      mdis_17       integer     default 0 not null,
      mprem_16      integer     default 0 not null,
      mdis_16       integer     default 0 not null,
      mprem_oth     integer     default 0 not null,
      mdiscount     integer     default 0 not null,
      rSafe_11      decimal(9,7) default 0 not null,
      rSafe_17      decimal(9,7) default 0 not null,
      rSafe_16      decimal(9,7) default 0 not null,
      rSafe_oth     decimal(9,7) default 0 not null,
      rMgmt_11      decimal(9,7) default 0 not null,
      rMgmt_17      decimal(9,7) default 0 not null,
      rMgmt_16      decimal(9,7) default 0 not null,
      rMgmt_oth     decimal(9,7) default 0 not null
    ) WITH NO LOG;

    sprintf_s(stmtX, sizeof stmtX,"INSERT INTO CAR626 (iquota,icard,ipolicy,iendorse,iassured1,iassured2, "
                                  "   nassured,iapplicant,napplicant,dpolicy,dply_begin, "
                                  "   ibrand,ipro_year, "
                                  "   iengine,iissue_ym,ibig_office,itag,ori_dpolicy,mprem_11, "
                                  "   mdis_11,mprem_17,mdis_17,mprem_16,mdis_16, "
                                  "   mprem_oth,mdiscount, "
                                  "   rSafe_11,rSafe_17,rSafe_16,rSafe_oth,  "
                                  "   rMgmt_11,rMgmt_17,rMgmt_16,rMgmt_oth) "
                  "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
    $PREPARE a_id FROM $stmtX;

    rc = car626_accumulate();
    if ( rc != M_CM_OK)  {
         EWRITE(userid, rc, " ");
         return rc; }

   max_cnt=0;
 /*  strcpy(MsgCode," ");
   rc = car626_build1();
   if (rc != M_CM_OK)
   {
       if (MsgCode[0]==' ')
           EWRITE(userid, rc, " ");
       else
           EWRITE(userid, rc, MsgCode);
       return rc;

   }     */

errexit:
 printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
 return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car626_build1()
{
   $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];
   int    rc;
   $WHENEVER SQLERROR GOTO errexit;

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width, $iForm_Tp
      FROM Form
    WHERE ksys_grp = 'CA' AND kPgmID = 626 AND Iform_tp ='1';

   strcpy( TitleFmt,rtrim(TitleFmt));
   strcpy( BodyFmt,rtrim(BodyFmt));

   if (strncmp(check2,"1",1)==0)
     {sprintf_s(TitleFile, sizeof TitleFile,"%sA.ti",outputf);
      sprintf_s(BodyFile, sizeof BodyFile,"%sA.bd",outputf);
     }
   else
     {sprintf_s(TitleFile, sizeof TitleFile,"%s.ti",outputf);
      sprintf_s(BodyFile, sizeof BodyFile,"%s.bd",outputf);
     }
   rgu_init_report(TitleFmt,TitleFile);
   car626_title();
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);
   rc = car626_body1();
   if (rc != M_CM_OK)
       return rc;
   rgu_finish_report();

   if ((rc=save_form_info(F_BLK1, "CA", 626, userid, iForm_Tp, max_cnt, outputf))<0) {
        strcpy(MsgCode,"save_form_info failed");
        return rc;
   }

   return M_CM_OK;
  errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;  
}
/*----------------------------------------------------------------------------*/
long car626_build2()
{
   $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];
   int    rc;
   $WHENEVER SQLERROR GOTO errexit;

     $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
             kTot_Col, kPgNum_Line, kWidth, iForm_Tp
        INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
             $TotColumn, $PgLine, $Width, $iForm_Tp
      FROM Form
     WHERE ksys_grp = "CA" AND kPgmID = 626 AND Iform_tp ='2';

   strcpy( TitleFmt,rtrim(TitleFmt));
   strcpy( BodyFmt,rtrim(BodyFmt));

   if (strncmp(check1,"1",1)==0)
     {sprintf_s(TitleFile, sizeof TitleFile,"%sB.ti",outputf);
      sprintf_s(BodyFile, sizeof BodyFile,"%sB.bd",outputf);
     }
   else
     {sprintf_s(TitleFile, sizeof TitleFile,"%s.ti",outputf);
      sprintf_s(BodyFile, sizeof BodyFile,"%s.bd",outputf);
     }
   rgu_init_report(TitleFmt,TitleFile);
   car626_title();
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);
   rc = car626_body2();
   if (rc != M_CM_OK)
       return rc;
   rgu_finish_report();

   if ((rc=save_form_info(F_BLK1, "CA", 626, userid, iForm_Tp, max_cnt, outputf))<0) {
        strcpy(MsgCode,"save_form_info failed");
        return rc;
   }

   return M_CM_OK;
  errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car626_accumulate()
{
 $long qorder,mply_prem,qcount,mprem,medr_prem,mins_premium = 0,medrins_prem = 0;
 $char tmp_fulldb[200],stmt[1024],stmt1[512],stmt2[512],stmt_qnextyear[128];
 int i,j,count_db,rc;
 $long count_tot,edr_cont;
 DBinfo *list;

    $WHENEVER SQLERROR GOTO errexit;

printf("ca626q01s.ec is the running program.\n");
    if ((list = get_db_list (&count_db, DBName)) == (char *) 0)
    {
      if (EWRITE(userid, M_CM_NOT_DBLIST) == True)
        return M_CM_NOT_DBLIST;
      return M_CM_OK;
    }

   if (strncmp(fply_close,"1",1)==0) {
      strcpy(stmt1," AND a.dply_close is not null ");
      strcpy(stmt2," AND a.dedr_close is not null ");
   }
   else {
      strcpy(stmt1," "); 
      strcpy(stmt2," "); 
   }
   
   /* �P�_�����O��/�s�O��/��O�� Modified by Julia Han in 2007/04/30 */
   /* "A"�������O��,"0"���s�O��,"1"����O�� */
   if (strncmp(qnext_year,"0",1)==0) {
   	strcpy(stmt_qnextyear,"AND a.qnext_year = 0");
   } else if (strncmp(qnext_year,"1",1)==0) {
   				strcpy(stmt_qnextyear,"AND a.qnext_year > 0");
   } else {
   				strcpy(stmt_qnextyear,"");
   }

   for(j=0;j<count_db;j++)
   {

    if(strncmp(check1,"1",1)==0)
     {sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy,a.icard,a.dply_begin,a.ibrand,  "
                   "       to_char(b.dissue,'%%Y')::integer - 1911 || '/' || to_char(b.dissue,'%%m'), "
                   "       a.ibig_office,a.iquota,a.dpolicy,a.ipro_year, "
                   "       (a.mdmg_discount+a.mlia_discount), "
                   "       b.iassured,b.iassured_ext,b.nassured[1,24],b.iengine,b.itag,  "
                   "       b.iapplicant,b.napplicant[1,24] "
                   "FROM %s:ply_relation a, %s:policy b  "
                   "WHERE a.dpolicy >= ? AND a.dpolicy <= ? %s  "
                   "AND a.ipolicy = b.ipolicy  "
                   "AND a.fedr_class <> '1'  "
                   "AND a.iofficer[1] = 'W' AND a.iofficer[7,8] ='BE' %s",
              list[j].dbname,list[j].dbname,stmt1,stmt_qnextyear);
      $PREPARE a_id1 FROM $stmt;
      $DECLARE cur_A CURSOR FOR a_id1;
      $OPEN cur_A USING $dbgn_inf,$dend_inf;

      for(;;)
       { mprem_11=mprem_16=mprem_17=mprem_oth=0;
         mdis_11=mdis_16=mdis_17=0;
         $FETCH cur_A INTO $ipolicy,$icard,$dply_begin,$ibrand,$iissue_ym,
                           $ibig_office,$iquota,$dpolicy,$ipro_year,$mdiscount,
                           $iassured1,$iassured2,$nassured,$iengine,$itag,$iapplicant,$napplicant;
         if (SQLCODE == SQLNOTFOUND) break;

         sprintf_s(stmt, sizeof stmt,"SELECT iins_type,mins_premium,pdiscount,safe_rate,manage_rate  "
                      "FROM %s:ply_ins_type  "
                      "WHERE ipolicy = ? ",list[j].dbname);
         $PREPARE a_id2 FROM $stmt;
         $DECLARE cur_B CURSOR FOR a_id2;
         $OPEN cur_B USING $ipolicy;
         mprem_11=mprem_16=mprem_17=mprem_oth=0;
         mdis_11=mdis_16=mdis_17=0;
         for(;;)
          {
            $FETCH cur_B INTO $iins_type,$mins_premium,$pdiscount,$tmp_safe,$tmp_manage;
            if (SQLCODE == SQLNOTFOUND) break;

            if(strcmp(trim(iins_type),"11")==0)
              {mprem_11 = mins_premium;
               mdis_11 = pdiscount;
               rSafe_11 = tmp_safe;
               rMgmt_11 = tmp_manage;}
            else if(strcmp(trim(iins_type),"17")==0)
              {mprem_17 = mins_premium;
               mdis_17 = pdiscount;
               rSafe_17 = tmp_safe;
               rMgmt_17 = tmp_manage; }
            else if(strcmp(trim(iins_type),"16")==0)
              {mprem_16 = mins_premium;
               mdis_16 = pdiscount;
               rSafe_16 = tmp_safe;
               rMgmt_16 = tmp_manage; }
            else
            {
              mprem_oth = mprem_oth + mins_premium;
              rSafe_oth = tmp_safe;
              rMgmt_oth = tmp_manage;
            }
          }
          $CLOSE cur_B;
          $FREE cur_B;

         strcpy(iendorse," ");
         strcpy(ori_dpolicy," ");
         $EXECUTE a_id USING $iquota,$icard,$ipolicy,$iendorse,$iassured1,$iassured2,
                             $nassured,$iapplicant,$napplicant,$dpolicy,$dply_begin,
                             $ibrand,$ipro_year,
                             $iengine,$iissue_ym,$ibig_office,$itag,$ori_dpolicy,$mprem_11,
                             $mdis_11,$mprem_17,$mdis_17,$mprem_16,$mdis_16,$mprem_oth,
                             $mdiscount,$rSafe_11,$rSafe_17,$rSafe_16,$rSafe_oth,
                             $rMgmt_11,$rMgmt_17,$rMgmt_16,$rMgmt_oth;

       }$CLOSE cur_A;
        $FREE  cur_A;
     }

     if(strncmp(check2,"1",1)==0)
      {sprintf_s(stmt, sizeof stmt,"SELECT a.iendorse,a.ipolicy,a.icard,a.dedr_begin,a.ibrand, "
                    "      to_char(b.dissue,'%%Y')::integer - 1911 || '/' || to_char(b.dissue,'%%m'), "
                    "      a.ibig_office,a.iquota,a.dendorse,a.ipro_year, "
                    "      b.iassured,b.iassured_ext,b.nassured[1,24],b.iengine,b.itag, "
                    "      b.iapplicant,b.napplicant[1,24]  "
                    "FROM %s:edr_relation a, %s:endorsement b  "
                    "WHERE a.dendorse >= ? AND a.dendorse <= ? %s  "
                    "AND a.iendorse = b.iendorse  "
                    "AND a.fedr_class = '1'  "
                    "AND a.iofficer[1] = 'W' AND a.iofficer[7,8] ='BE'",
               list[j].dbname,list[j].dbname,stmt2);
      $PREPARE a_id3 FROM $stmt;
      $DECLARE cur_C CURSOR FOR a_id3;
      $OPEN cur_C USING $dbgn_inf,$dend_inf;
   
      for(;;)
        { mprem_11=mprem_16=mprem_17=mprem_oth=mdiscount=0;
          $FETCH cur_C INTO $iendorse,$ipolicy,$icard,$dply_begin,$ibrand,$iissue_ym,
                            $ibig_office,$iquota,$dpolicy,$ipro_year,$iassured1,
                            $iassured2,$nassured,$iengine,$itag,$iapplicant,$napplicant;

          if(SQLCODE==SQLNOTFOUND) break;

          sprintf_s(stmt, sizeof stmt,"SELECT dpolicy FROM %s:ori_ply_relation  "
                        "WHERE ipolicy = ? ",list[j].dbname);
          $PREPARE K_id FROM $stmt;
          $DECLARE curKX CURSOR FOR K_id;
          $OPEN curKX USING $ipolicy;
          $FETCH curKX INTO $ori_dpolicy;
          if(SQLCODE == SQLNOTFOUND) strcpy(ori_dpolicy," ");
          $CLOSE curKX;
          $FREE  curKX;

          sprintf_s(stmt, sizeof stmt,"SELECT iins_type,medrins_prem,pdiscount,medr_discount,safe_rate,manage_rate "
                  "FROM %s:edr_ins_type  "
                  "WHERE iendorse = ? ",list[j].dbname);
          $PREPARE a_id4 FROM $stmt;
          $DECLARE cur_D CURSOR FOR a_id4;
          $OPEN cur_D USING $iendorse;

          for(;;)
           {
             $FETCH cur_D INTO $iins_type,$medrins_prem,$pdiscount$medr_discount,$tmp_safe,$tmp_manage;
             if (SQLCODE == SQLNOTFOUND) break;

             mdiscount += medr_discount;
             if(strcmp(trim(iins_type),"11")==0)
               {mprem_11 = medrins_prem;
                mdis_11 = pdiscount;
                rSafe_11 = tmp_safe;
                rMgmt_11 = tmp_manage; }
             else if(strcmp(trim(iins_type),"17")==0)
               {mprem_17 = medrins_prem;
                mdis_17 = pdiscount;
                rSafe_17 = tmp_safe;
                rMgmt_17 = tmp_manage; }
             else if(strcmp(trim(iins_type),"16")==0)
               {mprem_16 = medrins_prem;
                mdis_16 = pdiscount; 
                rSafe_16 = tmp_safe;
                rMgmt_16 = tmp_manage; }
             else
               {
                mprem_oth +=  medrins_prem;
                rSafe_oth = tmp_safe;
                rMgmt_oth = tmp_manage;
               }

           }$CLOSE cur_D;
            $FREE  cur_D;

          $EXECUTE a_id USING $iquota,$icard,$ipolicy,$iendorse,$iassured1,$iassured2,
                              $nassured,$iapplicant,$napplicant,$dpolicy,$dply_begin,
                              $ibrand,$ipro_year,
                              $iengine,$iissue_ym,$ibig_office,$itag,$ori_dpolicy,
                              $mprem_11,$mdis_11,$mprem_17,$mdis_17,$mprem_16,$mdis_16,
                              $mprem_oth,$mdiscount,$rSafe_11,$rSafe_17,$rSafe_16,$rSafe_oth,
                              $rMgmt_11,$rMgmt_17,$rMgmt_16,$rMgmt_oth;

      }$CLOSE cur_C;
       $FREE  cur_C;
     }

    } /*end of for */

     if(strncmp(check1,"1",1)==0)
       {rc = car626_build1();
        if ( rc != M_CM_OK)  {
          EWRITE(userid, rc, " ");
          return rc; }
       }

     if(strncmp(check2,"1",1)==0)
       {rc = car626_build2();
        if ( rc != M_CM_OK)  {
          EWRITE(userid, rc, " ");
          return rc; }
       }

   return M_CM_OK;

  errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car626_body1()
{
 $long Qorder;
 $int  Qindent;

 char  Tmp[30];
 $char stmtA[500],stmt[1000];

       $WHENEVER SQLERROR GOTO errexit;
       rgu_put_body_string(1,cm_sysd_cdatetime_100(cm_get_sysd()),1);
       rgu_put_body_string(1,dbgn1,1);
       rgu_put_body_string(1,dend1,1);
       rgu_put_body(1);
       max_cnt ++;
       iquota[0]='\0';

       sprintf_s(stmt, sizeof stmt,"SELECT iquota[1,4],icard,ipolicy,iendorse,iassured1,iassured2, "
                      "     nassured,iapplicant,napplicant,dpolicy,dply_begin,ibrand, "
                      "     iengine,iissue_ym,ibig_office, "
                      "     itag,mprem_11,mdis_11,mprem_17,mdis_17,mprem_16,mdis_16, "
                      "     mprem_oth,mdiscount, "
                      "     rSafe_11,rSafe_17,rSafe_16,rSafe_oth, "
                      "     rMgmt_11,rMgmt_17,rMgmt_16,rMgmt_oth  "
                      "FROM car626 WHERE iendorse = ' ' "
                      "ORDER BY ipolicy,iendorse" );

       $PREPARE c_id FROM $stmt;
       $DECLARE cur CURSOR FOR c_id;
       $OPEN cur;

          for(;;)
            {
             $FETCH cur INTO $iquota,$icard,$ipolicy,$iendorse,$iassured1,$iassured2,
                             $nassured,$iapplicant,$napplicant,$dpolicy,$dply_begin,$ibrand,
                             $iengine,$iissue_ym,$ibig_office,$itag,
                             $mprem_11,$mdis_11,$mprem_17,$mdis_17,$mprem_16,$mdis_16,
                             $mprem_oth,$mdiscount,$rSafe_11,$rSafe_17,$rSafe_16,$rSafe_oth,
                             $rMgmt_11,$rMgmt_17,$rMgmt_16,$rMgmt_oth;

             if(SQLCODE == SQLNOTFOUND) break;

             $SELECT nname
                INTO $ibig_office_c
                FROM officer
               WHERE iofficer = $ibig_office;
             if(SQLCODE == SQLNOTFOUND) ibig_office_c[0] ='\0';

             if (strlen(trim(iassured1)) == 0 && strlen(trim(iassured2))==0)
               iassured[0] ='\0';
             else
              { strcpy(iassured,rtrim(iassured1));
                strcat(iassured,rtrim(iassured2));  }

             sprintf_s(stmt, sizeof stmt,"SELECT nbrand_abbr,nbrand,ipro_year "
                         "FROM ca_car_model  "
                         "WHERE ibrand = ? "
                         "ORDER BY ipro_year ");
             $PREPARE B_id FROM $stmt;
             $DECLARE curBX CURSOR FOR B_id;
             $OPEN curBX USING $ibrand;
             $FETCH curBX INTO $nbrand_abbr,$nbrand,$ipro_year;
             if(SQLCODE == SQLNOTFOUND)
               {nbrand_abbr[0]='\0';
                nbrand[0]='\0'; }
             $CLOSE curBX;
             $FREE  curBX;

             $SELECT nbranch INTO $Ngroup
                FROM sa_branch_type
               WHERE ibranch[1,4] = $iquota
                 AND ibranch[5,6] = '00';
             if(SQLCODE ==SQLNOTFOUND) Ngroup[0]='\0';

             print_car626_body1();

              }$CLOSE cur;
               $FREE  cur;

       return M_CM_OK;
   
   errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE; 
}
/*----------------------------------------------------------------------------*/
long car626_body2()
{
 $long Qorder;
 $int  Qindent;

 char  Tmp[30];
 $char stmtA[500],stmt[1000];

       $WHENEVER SQLERROR GOTO errexit;
       rgu_put_body_string(1,cm_sysd_cdatetime_100(cm_get_sysd()),1);
       rgu_put_body_string(1,dbgn1,1);
       rgu_put_body_string(1,dend1,1);
       rgu_put_body(1);
       max_cnt ++;
       iquota[0]='\0';

       sprintf_s(stmt, sizeof stmt,"SELECT iquota[1,4],icard,ipolicy,iendorse,iassured1,iassured2, "
                      "     nassured,iapplicant,napplicant,dpolicy,dply_begin,ibrand, "
                      "     iengine,iissue_ym,ibig_office, "
                      "     itag,ori_dpolicy,mprem_11,mdis_11,mprem_17,mdis_17,mprem_16, "
                      "     mdis_16,mprem_oth,mdiscount, "
                      "     rSafe_11,rSafe_17,rSafe_16,rSafe_oth, "
                      "     rMgmt_11,rMgmt_17,rMgmt_16,rMgmt_oth  "
                      "FROM car626 WHERE iendorse <> ' ' "
                      "ORDER BY ipolicy,iendorse" );

       $PREPARE c_id FROM $stmt;
       $DECLARE curQ CURSOR FOR c_id;
       $OPEN curQ;

          for(;;)
            {
             $FETCH curQ INTO $iquota,$icard,$ipolicy,$iendorse,$iassured1,$iassured2,
                             $nassured,$iapplicant,$napplicant,$dpolicy,$dply_begin,$ibrand,
                             $iengine,$iissue_ym,$ibig_office,$itag,$ori_dpolicy,
                             $mprem_11,$mdis_11,$mprem_17,$mdis_17,$mprem_16,$mdis_16,
                             $mprem_oth,$mdiscount,$rSafe_11,$rSafe_17,$rSafe_16,$rSafe_oth,
                             $rMgmt_11,$rMgmt_17,$rMgmt_16,$rMgmt_oth;

             if(SQLCODE == SQLNOTFOUND) break;

             $SELECT nname
                INTO $ibig_office_c
                FROM officer
               WHERE iofficer = $ibig_office;
             if(SQLCODE == SQLNOTFOUND) ibig_office_c[0] ='\0';

             if (strlen(trim(iassured1)) == 0 && strlen(trim(iassured2))==0)
               iassured[0] ='\0';
             else
              { strcpy(iassured,rtrim(iassured1));
                strcat(iassured,rtrim(iassured2));  }

             sprintf_s(stmt, sizeof stmt,"SELECT nbrand_abbr,nbrand,ipro_year "
                         "FROM ca_car_model  "
                         "WHERE ibrand = ? "
                         "ORDER BY ipro_year ");
             $PREPARE B_id FROM $stmt;
             $DECLARE curBXQ CURSOR FOR B_id;
             $OPEN curBXQ USING $ibrand;
             $FETCH curBXQ INTO $nbrand_abbr,$nbrand,$ipro_year;
             if(SQLCODE == SQLNOTFOUND)
               {nbrand_abbr[0]='\0';
                nbrand[0]='\0'; }
             $CLOSE curBXQ;
             $FREE  curBXQ;

             $SELECT nbranch INTO $Ngroup
                FROM sa_branch_type
               WHERE ibranch[1,4] = $iquota
                 AND ibranch[5,6] = '00';
             if(SQLCODE ==SQLNOTFOUND) Ngroup[0]='\0';

             print_car626_body2();

              }$CLOSE curQ;
               $FREE  curQ;

       return M_CM_OK;

   errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}
/*---------------------------------------------------------------------------------*/
void print_car626_body1()
{ char str[12],str1[8];

  rgu_put_body_string(2,iquota,LEFT);
  rgu_put_body_string(2,trim(Ngroup),LEFT);
  rgu_put_body_string(2,icard,LEFT);
  rgu_put_body_string(2,ipolicy,LEFT);
  rgu_put_body_string(2,iendorse,LEFT);
  rgu_put_body_string(2,iassured,LEFT);
  rgu_put_body_string(2,nassured,LEFT);
  rgu_put_body_string(2,iapplicant,LEFT);
  rgu_put_body_string(2,napplicant,LEFT);
  rgu_put_body_string(2,dpolicy,LEFT);
  rgu_put_body_string(2,dply_begin,LEFT);
  rgu_put_body_string(2,ibrand,LEFT);
  rgu_put_body_string(2,nbrand_abbr,LEFT);
  rgu_put_body_string(2,nbrand,LEFT);
  rgu_put_body_string(2,iengine,LEFT);
  rgu_put_body_string(2,iissue_ym,LEFT);
  rgu_put_body_string(2,ibig_office,LEFT);
  rgu_put_body_string(2,ibig_office_c,LEFT);
  rgu_put_body_string(2,itag,LEFT);
  rfmtlong(mprem_11,"---------&",str);
  rgu_put_body_string(2,str,LEFT);
  rfmtlong(mdis_11,"-------&",str1);
  rgu_put_body_string(2,str1,LEFT);
  rfmtlong(mprem_17,"---------&",str);
  rgu_put_body_string(2,str,LEFT);
  rfmtlong(mdis_17,"-------&",str1);
  rgu_put_body_string(2,str1,LEFT);
  rfmtlong(mprem_16,"---------&",str);
  rgu_put_body_string(2,str,LEFT);
  rfmtlong(mdis_16,"-------&",str1);
  rgu_put_body_string(2,str1,LEFT);
  rfmtlong(mprem_oth,"---------&",str);
  rgu_put_body_string(2,str,LEFT);
  rfmtlong(mdiscount,"---------&",str);
  rgu_put_body_string(2,str,LEFT);
  
  rfmtdouble(rSafe_11,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2); 
  rfmtdouble(rSafe_17,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2); 
  rfmtdouble(rSafe_16,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2); 
  rfmtdouble(rSafe_oth,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2); 
  rfmtdouble(rMgmt_11,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2); 
  rfmtdouble(rMgmt_17,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2); 
  rfmtdouble(rMgmt_16,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2); 
  rfmtdouble(rMgmt_oth,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2); 
  
  rgu_put_body(2);
  max_cnt++;

}
/*---------------------------------------------------------------------------*/
void print_car626_body2()
{ char str[12],str1[8];
 
  rgu_put_body_string(2,trim(Ngroup),LEFT);
  rgu_put_body_string(2,icard,LEFT);
  rgu_put_body_string(2,ipolicy,LEFT);
  rgu_put_body_string(2,iendorse,LEFT);
  rgu_put_body_string(2,iassured,LEFT);
  rgu_put_body_string(2,nassured,LEFT);
  rgu_put_body_string(2,iapplicant,LEFT);
  rgu_put_body_string(2,napplicant,LEFT);
  rgu_put_body_string(2,dpolicy,LEFT);
  rgu_put_body_string(2,ori_dpolicy,LEFT);
  rgu_put_body_string(2,dply_begin,LEFT);
  rgu_put_body_string(2,ibrand,LEFT);
  rgu_put_body_string(2,nbrand_abbr,LEFT);
  rgu_put_body_string(2,nbrand,LEFT);
  rgu_put_body_string(2,iengine,LEFT);
  rgu_put_body_string(2,iissue_ym,LEFT);
  rgu_put_body_string(2,ibig_office,LEFT);
  rgu_put_body_string(2,ibig_office_c,LEFT);
  rgu_put_body_string(2,itag,LEFT);
  rfmtlong(mprem_11,"---------&",str);
  rgu_put_body_string(2,str,LEFT);
  rfmtlong(mdis_11,"-------&",str1);
  rgu_put_body_string(2,str1,LEFT);
  rfmtlong(mprem_17,"---------&",str);
  rgu_put_body_string(2,str,LEFT);
  rfmtlong(mdis_17,"-------&",str1);
  rgu_put_body_string(2,str1,LEFT);
  rfmtlong(mprem_16,"---------&",str);
  rgu_put_body_string(2,str,LEFT);
  rfmtlong(mdis_16,"-------&",str1);
  rgu_put_body_string(2,str1,LEFT);
  rfmtlong(mprem_oth,"---------&",str);
  rgu_put_body_string(2,str,LEFT);
  rfmtlong(mdiscount,"---------&",str);
  rgu_put_body_string(2,str,LEFT);
  
  rfmtdouble(rSafe_11,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2); 
  rfmtdouble(rSafe_17,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2); 
  rfmtdouble(rSafe_16,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2); 
  rfmtdouble(rSafe_oth,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2); 
  rfmtdouble(rMgmt_11,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2); 
  rfmtdouble(rMgmt_17,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2);
  rfmtdouble(rMgmt_16,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2);
  rfmtdouble(rMgmt_oth,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2);
  
  
  rgu_put_body(2);
  max_cnt++;

}
/*------------------------------------------------------------------------*/
void car626_title()
{
     rgu_put_head();
}
