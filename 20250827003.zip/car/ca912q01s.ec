/*
 * Copyright (C) 1993 Intellisys Corporation
 * Program : car912q01s.ec (Type Block 1)  */

#include <stdio.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "safeclib.h"
#include "commsgs.h"

long car912_build();
void car912_title();
void car912_parm();
void car912_body();
void car912_brk();
void car912_tot();


$struct parameter
 {
  char dptbgn[3],dptend[3], brn[3];
  char adjusterbgn[11],adjusterend[11];
  char datebgn[10],dateend[10];
 }
pa;

$char BodyFmt[21];
$char TitleFmt[21];
char BodyFile[21];
char TitleFile[21];
char outputf[21];

$int StartRow,TitleRow;
$int ItemRow, TotColumn;
$int PgLine, Width = 0;
int  max_count,errCode;
$short dateind = 0;

$char DBName[5];
$char userid[11];
char FormTp[21];
$char cDatebgn[20], cDateend[20];
$char cBuf[20];

$struct car912
 {
  char ibranch[3];
  char iadjuster[11];
  char nassured[17];
  char icard[CARD_NUM];
  char iclaim[CLAIM_NUM];
  char ipolicy[POLICY_NUM_1];
  char dclaim[17];
  char daccident[17];
  char itag[CA_TAG_NUM];
 } v;

$char stmt[1024];
int iCnt = 0;
int FLAG = 0;
int iseq;
$char Dapp_entry[11];
$char nname[11];
$char sIclaim[CLAIM_NUM], sDBSite[3];
$char sIbranch[3], sIadjuster[11];
/*------------------------------------------------------------------*/
main(argc,argv)
int argc;
char **argv;
{
  int rc;
  batchinit();

  strcpy(DBName,isNULLstr(argv[1]));
  strcpy(userid,isNULLstr(argv[2]));
  strcpy(pa.dptbgn,isNULLstr(argv[3]));
  strcpy(pa.dptend,isNULLstr(argv[4]));
  strcpy(pa.adjusterbgn,isNULLstr(argv[5]));
  strcpy(pa.adjusterend,isNULLstr(argv[6]));
  strcpy(pa.datebgn,isNULLstr(argv[7]));
  strcpy(pa.dateend,isNULLstr(argv[8]));
  strcpy(outputf,isNULLstr(argv[9]));

  car912_parm();

  car912_build();

  rc=create_sign_form("car912",BodyFile,Width);
  if(rc != 0)
   {
     EWRITE(userid, rc,"Error on creating sign form");
     printf("Error on creating sign  form, rtncode=%d\n",rc);
     exit(1);
   }

  if((rc=save_form_info(F_BLK1,"CA",912,userid,FormTp,max_count,outputf))<0)
   {
     EWRITE(userid,rc,"save form  info failure!");
     exit(1);
   }
printf("main end\n");
} /* main */

/*---------------------------------------------------------------------*/
void car912_parm()
{

  if( pa.dptbgn[0] == '*') strcpy( pa.dptbgn, "  ");
  if( pa.dptend[0] == '*') strcpy( pa.dptend, "~~");
  if( pa.dptend[0] == ' ') strcpy( pa.dptend, pa.dptbgn);

  if( pa.adjusterbgn[0] == '*') strcpy( pa.adjusterbgn, "  ");
  if( pa.adjusterend[0] == '*') strcpy( pa.adjusterend, "~~");
  if( pa.adjusterend[0] == ' ') strcpy( pa.adjusterend, pa.adjusterbgn);

  if( pa.datebgn[0] == '*') strcpy( pa.datebgn, "80/01/01");
  if( pa.dateend[0] == '*') strcpy( pa.dateend, "199/12/31");
  if( pa.dateend[0] == ' ') strcpy( pa.dateend, pa.datebgn);
printf("&&& datebgn:[%s], dateend:[%s] &&&\n", pa.datebgn, pa.dateend);
  strcpy(cDatebgn, cm_to_infdate(pa.datebgn));
  strcpy(cDateend, cm_to_infdate(pa.dateend));

} /* car912_parm */

/*-------------------------------------------------------------------*/
long car912_build()
{
  int i, fFound;
  $char ibranch[3],server[25];
  $char Iclaim[CLAIM_NUM],Ipolicy[POLICY_NUM_1],Dclaim[17], Daccident[17];
  int first = 1 ;
  $char  stmt[2048];
  DBinfo  *list;
  int     count_db,x;
  $char		sFalldb[2], sLocaldb[25];

  $WHENEVER SQLERROR goto errexit;
  if (db_select(DBName)==False)
     {
      EWRITE(userid,M_CM_DB_NOTOPEN,"");
      exit(1);
     }

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
       if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
          return M_CM_NOT_DBLIST;
    }

  $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
      kTot_col, kPgNum_Line, kWidth
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow, $ItemRow,
      $TotColumn, $PgLine, $Width
      FROM Form
      WHERE ksys_grp="CA" AND kPgmID = 912;

  strcpy(TitleFmt,rtrim(TitleFmt));
  strcpy(BodyFmt,rtrim(BodyFmt));
  sprintf_s(TitleFile,21,"%s.ti",outputf);
  sprintf_s(BodyFile,21,"%s.bd",outputf);

  rgu_init_report(TitleFmt,TitleFile);
  car912_title();
  rgu_finish_report();

  rgu_init_report(BodyFmt,BodyFile);


	/* ���privilege.falldb�P�_�O�_�i�H�d���ٸ�� modify by sylvia 109.01.22 (1081106004_SC1) */
	$select falldb into $sFalldb
	   from privilege
	  where iemp = $userid
	    and ipgid = 'car912';
	if(SQLCODE == SQLNOTFOUND)
		strcpy(sFalldb,"N");

	strcpy(sLocaldb, get_full_dbname(DBName));
	strcpy(sLocaldb, trim(sLocaldb));

	for(x=0;x<count_db;x++)
	{
		strcpy(list[x].dbname, trim(list[x].dbname));
		printf("sFalldb=[%s]list[x].dbname=[%s]sLocaldb=[%s]\n",sFalldb,list[x].dbname,sLocaldb);

		if ((strcmp(sFalldb,"N") == 0) && (strcmp(list[x].dbname,sLocaldb) != 0))
			 continue;

	  sprintf_s(stmt,2048,
	  " SELECT b.ibranch, a.iadjuster, a.iclaim, a.ipolicy[1, 2] \
	      FROM %s:ca_local_clm a,v_branch b                         \
	     WHERE a.dclaim >= '%s' AND a.dclaim <= '%s'               \
	       AND b.ibranch >= '%s' AND b.ibranch <= '%s'             \
	       AND a.iadjuster >= '%s' AND a.iadjuster <= '%s'         \
	       AND a.iclaim[1,2]=b.ibranch                             \
	   ORDER BY ibranch, iadjuster ",
	   list[x].dbname, cDatebgn,cDateend,pa.dptbgn,pa.dptend,pa.adjusterbgn,
	                                 pa.adjusterend);

	   printf("188:stmt[%s]\n",stmt);
	  $PREPARE sid01 FROM $stmt;
	  $DECLARE b_acursor CURSOR FOR sid01;
	  $OPEN b_acursor;
	  for(i=0;;i++)
	  {
	    $FETCH b_acursor INTO $sIbranch, $sIadjuster, $sIclaim, $sDBSite;
	    if(SQLCODE == SQLNOTFOUND) break;

	    *server = '\0';
	    strcpy(server, get_full_dbname(sDBSite));
	    if(server[0] == '\0'){
	        EWRITE(userid,M_CM_DB_NOTOPEN,"");
	        exit(1);
	    }

	    sprintf_s(stmt,2048,
	      "SELECT iclaim[1,2], iadjuster, icard, iclaim, ipolicy, \
	              dclaim, daccident, dapp_entry \
	         FROM %s:appraisal \
	        WHERE iclaim = '%s' AND (dapp_entry IS NULL OR dapp_entry  = '') ",
	            server, sIclaim);
	    printf("210:stmt[%s]\n",stmt);
	    $PREPARE b_s1 FROM $stmt;
	    $DECLARE b_bcursor CURSOR FOR b_s1;
	    $OPEN b_bcursor;
	    $FETCH b_bcursor INTO $ibranch, $v.iadjuster,
	                          $v.icard, $Iclaim, $Ipolicy, $Dclaim,
	                          $Daccident, $Dapp_entry:dateind;
	    fFound = (SQLCODE == SQLNOTFOUND) ? 0 : 1;
	    $CLOSE b_bcursor;
	printf("--------------------- Iclaim[%s]\n",Iclaim);
	 /*   if(first)
	    {
	      strcpy(v.ibranch,ibranch);
	      car912_brk();
	      first = 0 ;
	    } else{ */
	    /*  if(strcmp(v.ibranch,ibranch)!=0)
	      {
	        strcpy(v.ibranch,ibranch);
	        car912_brk();
	      }
	    } */


	    if(!fFound) continue;

	    if(dateind != -1 && Dapp_entry[0] != ' ') continue;

	    sprintf_s(stmt,2048, "SELECT nassured[1,16], itag \
	                     FROM %s:adjustment_ply \
	                    WHERE iclaim = '%s' " ,
	            server, sIclaim);
	    $PREPARE b_s11 FROM $stmt;
	    $DECLARE b_bcursor1 CURSOR FOR b_s11;
	    $OPEN b_bcursor1;
	    $FETCH b_bcursor1 INTO $v.nassured, $v.itag;
	    fFound = (SQLCODE == SQLNOTFOUND) ? 0 : 1;
	    $CLOSE b_bcursor1;
	    if(!fFound) continue;

	    /*---------------------------*/
	    strcpy(v.iclaim, Iclaim);
	    /*v.iclaim[CLAIM_NUM-1] = '\0';
	    sprintf_s(v.iclaim,CLAIM_NUM, "%s-%c", v.iclaim, Iclaim[CLAIM_NUM-1]); */

	    strcpy(v.ipolicy, Ipolicy);
	    /*v.ipolicy[POLICY_NUM_1 - 1] = '\0';
	    sprintf_s(v.ipolicy,POLICY_NUM_1, "%s-%c", v.ipolicy, Ipolicy[POLICY_NUM_1 -1]); */

	    strcpy(v.dclaim, cm_sysd_cdatetime_100(Dclaim));

	    strcpy(cBuf, cm_sysd_cdatetime_100(Daccident));
	    strcpy(v.daccident, cBuf);
	    printf("263:v.ibranch=[%s],ibranch=[%s]sIclaim=[%s]\n",v.ibranch,ibranch,sIclaim);
	    if(first)
	    {
	      strcpy(v.ibranch,ibranch);
	      car912_brk();
	      first = 0 ;
	    }
	    if(strcmp(v.ibranch,ibranch)!=0)
	    {
	        car912_tot();
	        rgu_put_body (5);
	        max_count ++;
	        strcpy(v.ibranch,ibranch);
	        car912_brk();

	    }
	  	car912_body();

	    max_count++;
	  } /* while */
	  $CLOSE b_acursor;
	  $FREE b_acursor;
  }


  if(max_count == 0){
printf("&&& No record found &&&\n");
    EWRITE(userid, M_CM_NOT_FOUND, "");
    exit(1);
  }

  if (max_count != 0)
     car912_tot();
  rgu_finish_report();

printf("car912_build end\n");
return;
errexit:
  printf( "errexit:SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
  EWRITE(userid,SQLCODE,sqlca.sqlerrm);
  exit(1);
} /* car912_build */


/*------------------------------------------------------------------*/
void car912_title()
 {
  char yy[10],mm[10],dd[10];

  rgu_put_head_string(1, cm_sysd_cdatetime_100(cm_get_sysd()));   /* get_currdt */

  cm_split_ymd_100(pa.datebgn,yy,mm,dd);
  rgu_put_head_string(1, yy);
  rgu_put_head_string(1, mm);
  rgu_put_head_string(1, dd);

  cm_split_ymd_100(pa.dateend,yy,mm,dd);
  rgu_put_head_string(1, yy);
  rgu_put_head_string(1, mm);
  rgu_put_head_string(1, dd);
  rgu_put_head();

} /* car912_title */

/*----------------------------------------------------------------*/
void car912_body()
{
  char t_branch[3];
  char tmpIadjuster[11];


  max_count++;
  FLAG = 0;

  rgu_put_body_string(2, v.iadjuster, 1);
printf("---------------------1\n");
  $WHENEVER SQLERROR continue;
    $SELECT nname
       INTO $nname
       FROM officer
     WHERE  iofficer = $v.iadjuster;
    if(SQLCODE == SQLNOTFOUND) strcpy(nname, " ");

printf("---------------------2\n");
  rgu_put_body_string(2, nname, 1);
  rgu_put_body_long(2, ++iseq, 1);
  rgu_put_body_string(2, v.nassured, 1);
  rgu_put_body_string(2,v.icard,1);
  rgu_put_body_string(2,v.iclaim,1);
  rgu_put_body_string(2,v.ipolicy,1);
  rgu_put_body_string(2,v.dclaim,1);
  rgu_put_body_string(2,v.daccident,1);
  rgu_put_body_string(2,v.itag,1);
  rgu_put_body(2);
  rgu_put_body(6);

  max_count+= 2;
  iCnt++;
printf("car912_body end\n");
  return;

errexit:
  printf( "errexit:SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
  EWRITE(userid,SQLCODE,sqlca.sqlerrm);
  exit(1);
} /* car912_body */

/*-----------------------------------------------------------------*/
void car912_brk()
{
  /*$SELECT iclaim_name
      INTO $cBuf
      FROM claim_branch
      WHERE iclaim_branch = $v.ibranch; */

  $SELECT  nchi_abv
      INTO $cBuf
      FROM v_branch
      WHERE ibranch = $v.ibranch;
  if(SQLCODE != 0) strcpy(cBuf," ");

  rgu_put_body_string(1, cBuf, 2);
  rgu_put_body(1);
  max_count++;
printf("car912_brk end\n");

  return;

errexit:
  printf( "errexit:SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
  EWRITE(userid,SQLCODE,sqlca.sqlerrm);
  exit(1);
} /* car912_brk */
/*---------------------------------------------------------------------*/

void car912_tot()
{
  char buf1[20];

  rgu_put_body (3);
  max_count ++;

  sprintf_s(buf1,20,"%d",iseq);
  rgu_put_body_string  (4, buf1,2);
  rgu_put_body (4);
  max_count ++;

  iseq=0;
}
