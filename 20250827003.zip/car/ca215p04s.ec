/***********************************************************************/
/*   program id   : ca215p04s.ec                                       */
/*   program name : �����ʲz�����d�礧�O�I�Ҹ�ƻPñ���ƤĽ]���@�~ */
/*   date written : 2017/11/03  (1061030004_C1)                        */
/***********************************************************************/

#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include "print.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "othmsgs.h"
#include "commsgs.h"
#include "sqlfatal.h"
#include "safeclib.h"

/******************************************************************************/
$char  	DBName[5],outputf[ N_FILE+1],userid[11];
$char  	Opt[3],Date_type[2], Date1[11],Date2[11], sDate1[11], sDate2[11],Upfile[31];
int     flen,i;
char    sApHome[30],msgbuf[1000];

char    file1[105], file2[105];
FILE   *fp1,*fp2,*fp;

/******************************************************************************/
main(argc, argv)
int argc;
char **argv;
{
    int rc;

    batchinit();
    strcpy(DBName,      isNULLstr(argv[1]));
    strcpy(userid,      isNULLstr(argv[2]));
    strcpy(Opt,         isNULLstr(argv[3]));    /* �@�~���O:1:�ץX���~���� 20:�פJ���y�� 21:���O���� 22:�d�߸�� 3:��s�s�w�j���Ҹ� 4:�ץX�^�и�� */
    strcpy(Date_type,   isNULLstr(argv[4]));    /* 1:�ʲz����J�� 2.�s�w�פJ�� 3:�s�w��s�� */
    strcpy(Date1,       isNULLstr(argv[5]));    /* cyy/mm/dd */
    strcpy(Date2,       isNULLstr(argv[6]));    /* cyy/mm/dd */
    strcpy(Upfile,      isNULLstr(argv[7]));    /* �פJ�ɮ� */
    strcpy(outputf,     isNULLstr(argv[8]));

    strcpy(sDate1,cm_to_infdate(Date1));
    strcpy(sDate2,cm_to_infdate(Date2));

    rc = car2154_get_db();
    if (rc != M_CM_OK) {
        printf("error on car2154_get_db\n");
        return rc;
    }
    
    strcpy(Opt, trim(Opt));
    
    /* �ץX���~���� */
    if (strcmp(Opt,"1") == 0)
    {
        rc = car2154_GetErrRpt();
        if (rc != M_CM_OK) {
            printf("error on car2154_GetErrRpt\n");
            return rc;
        }
    }
    else if (strcmp(Opt,"20") == 0)
    {
        /* �פJ���y�� */
        strcpy(msgbuf,"���ɵ��G�p�U: \n\n");
        rc = car2154_ReadFile();
        if (rc != M_CM_OK) {
            printf("error on car2154_GetErrRpt\n");
            return rc;
        }
    }
    else if (strcmp(Opt,"21") == 0)
    {
        /* ���O���� */
        strcpy(msgbuf,"��ﵲ�G�p�U: \n\n");
        rc = car2154_CmpPlyData();
        if (rc != M_CM_OK) {
            printf("error on car2154_CmpPlyData\n");
            return rc;
        }
    }
    else if (strcmp(Opt,"22") == 0)
    {
        /* �d�߸�� */
        rc = car2154_QryPlyData();
        if (rc != M_CM_OK) {
            printf("error on car2154_QryPlyData\n");
            return rc;
        }
    }
    else if (strcmp(Opt,"3") == 0)
    {
        /* ��s�s�w�j���Ҹ� */
        rc = car2154_UpdIcardNewa();
        if (rc != M_CM_OK) {
            printf("error on car2154_UpdIcardNewa\n");
            return rc;
        }
    }
    else if (strcmp(Opt,"4") == 0)
    {
        /* �ץX�^�и�� */
        rc = car2154_GetAckRpt();
        if (rc != M_CM_OK) {
            printf("error on car2154_GetAckRpt\n");
            return rc;
        }
    }
    printf("[car2154]:process ok!\n");
}
/******************************************************************************/
long car2154_get_db()
{
    int	rc;

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "��Ʈw�L�k�}��!");
       return M_CM_DB_NOTOPEN;
    }

    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }

    return M_CM_OK;

errexit:
   printf("--car2154_get_db-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/******************************************************************************/
long car2154_GetErrRpt()
{
    char  filename1[31];
    $char stoday[11], stmp[500], stmp1[100];
    $char icard[21], sdentry[11], prtstr[26];
    int  rt;
    
    $WHENEVER SQLERROR GOTO errexit;
    
    $select first 1 to_char(today,'%Y%m%d') into $stoday
      from car_code where 1=1;
    
    strcpy(stoday, trim(stoday));  
    printf("stoday=[%s]\n",stoday);  
    
    memset(file1,0x00,sizeof(file1));
    
    
    sprintf_s(filename1, sizeof filename1,"QRYTVCU17%s.txt",stoday);
	sprintf_s(file1, sizeof file1,"%s/rptftp/%s",sApHome,filename1); /* �T�� */

    rt = rptftpinsert(userid,"car2154",filename1);
    
    if (strcmp(Date_type,"1") == 0)
        sprintf_s(stmp1, sizeof stmp1,"and dentry between '%s' and '%s' ", sDate1, sDate2); /* �ʲz����J�� */
    else 
        sprintf_s(stmp1, sizeof stmp1,"and date(dcreate) between '%s' and '%s' ", sDate1, sDate2); /* �s�w�פJ�� */
    
    fp1=fopen(file1,"w");
    

    sprintf_s(stmp, sizeof stmp, "select icard, to_char(dentry,'%%Y%%m%%d') from ca_card_road "
                    "where flast_status = 'w' %s ",stmp1);
    printf("stmp=[%s]\n",stmp);
    
    $PREPARE pre_1 from $stmp;
    $DECLARE cus_1 CURSOR FOR pre_1;
    $OPEN cus_1;
    while(1)
    {
        $FETCH cus_1 into $icard,$sdentry;
        if (SQLCODE==SQLNOTFOUND) break;
        
        strcpy(icard, trim(icard));
        strcpy(sdentry, trim(sdentry));
        
        sprintf_s(prtstr, sizeof prtstr,"%-17.17s%8.8s",icard,sdentry);
        fprintf(fp1,"%s\n",prtstr);
    }
    $CLOSE cus_1;
    $FREE cus_1;
    fclose(fp1);
    
    EWRITE(userid, M_CM_OK, "�Цܡi�ɮפU���@�~�]cmn202�^�j�U���ɮ�!");
    return M_CM_OK;
    
errexit:
   printf("--car2154_GetErrRpt-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/* -------------------------------------------------------------------------- */
/* �פJ���y��� */
long car2154_ReadFile()
{
    char  *bp;    
    char  filename[128],syy[5],smm[3],sdd[3];
    int   rc, i, j, k, m, n, qcount;
    $char sdata[9][121];
    $char sDbgn[11],sDend[11],sDentry[11],stmp1[11], stmp2[41];
    
    printf("---- car2154_ReadFile  start   ----- \n");    

    $whenever sqlerror continue;
    
    
    strcpy(Upfile, trim(Upfile));
    sprintf_s(filename, sizeof filename,"%s/dat/car/%s",sApHome,Upfile);
    flen=1024;
    if ((fp=fopen(filename,"r"))==NULL) {
       sprintf_s(msgbuf, sizeof msgbuf,"%s �ɮ׶}�ҥ���",filename);
       EWRITE(userid,FALSE,msgbuf);
       return FALSE;
    }
    if ((bp=malloc(flen))==NULL) {
       sprintf_s(msgbuf, sizeof msgbuf,"System malloc failed !");
       EWRITE(userid,FALSE,msgbuf);
       free(bp);
       return FALSE;
    }
    
    /* ��J���y��� */
	qcount = 0;	m = 0;
	for (i=0;(feof(fp)==0);i++) 
    {
        memset(bp,0x00,flen);
		fgets(bp,flen,fp);
		        
        if (bp[0]==0x00)	break;
		if (strlen(trim(bp))<10)	break;
		        	
        for(j=0;j<9;j++)
		   sdata[j][0]='\0';
		
		m=i+1;
		printf();
        strcpy(sdata[0],substring(bp,1,17));    /* �O�I�Ҹ� */
		strcpy(sdata[1],substring(bp,18,8));    /* ��J��� */
		strcpy(sdata[2],substring(bp,26,12));   /* ���� */
		strcpy(sdata[3],substring(bp,38,10));   /* �����Ҹ�/�νs */
		strcpy(sdata[4],substring(bp,48,25));   /* ������ */
		strcpy(sdata[5],substring(bp,73,25));   /* �������X */
		strcpy(sdata[6],substring(bp,98,8));    /* �O�I�_�� */
		strcpy(sdata[7],substring(bp,106,8));   /* �O�I���� */
		strcpy(sdata[8],substring(bp,114,120)); /* �N�˼t�W�� */
		
		if (sdata[0][0]=='\0') continue;
		for (k=0;k<9;k++)
		{
		    strcpy(sdata[k], trim(sdata[k]));
		    printf("sdata[k]=[%s]\n",sdata[k]);
		    if(k==1)
		    {   
		        memset(sDentry,0x00,sizeof(sDentry));
                strncpy(syy,sdata[k],4);
                syy[4]='\0';
                strncpy(smm,&sdata[k][4],2);
                smm[2]='\0';
                strncpy(sdd,&sdata[k][6],2);
                sdd[2]='\0';
                sprintf_s(sDentry, sizeof sDentry,"%s/%s/%s",smm,sdd,syy);
            }
		    else if(k==6)
		    {   
		        memset(sDbgn,0x00,sizeof(sDbgn));
		        if(strlen(sdata[k]) >2)
		        {
                    strncpy(syy,sdata[k],4);
                    syy[4]='\0';
                    strncpy(smm,&sdata[k][4],2);
                    smm[2]='\0';
                    strncpy(sdd,&sdata[k][6],2);
                    sdd[2]='\0';
                    sprintf_s(sDbgn, sizeof sDbgn,"%s/%s/%s",smm,sdd,syy);
                }
            }
            else if(k==7)
            {
                memset(sDend,0x00,sizeof(sDend));
		        if(strlen(sdata[k]) >2)
		        {
                    strncpy(syy,sdata[k],4);
                    syy[4]='\0';
                    strncpy(smm,&sdata[k][4],2);
                    smm[2]='\0';
                    strncpy(sdd,&sdata[k][6],2);
                    sdd[2]='\0';
                    sprintf_s(sDend, sizeof sDend,"%s/%s/%s",smm,sdd,syy);
                }
            }
            else
            {
                if (strlen(sdata[k])== 0)
                    strcpy(sdata[k]," ");
		    }
		        
		    printf("sdata[%d]=[%s]\n",k,sdata[k]);
		}
        printf("272:sDentry=[%s]sDbgn=[%s]sDend=[%s]\n",sDentry,sDbgn,sDend);
		$insert into sysdb:ca_card_road_rechk
		 (icard_ins, dendry_ins, itag_ins, iinsurand_ins, iengine_ins, 
          ibody_ins, dply_begin_ins, dply_end_ins, sfactroy, icard_newa,
          icreate, dcreate, iupdate, dupdate)
         values
         ($sdata[0], $sDentry, $sdata[2], $sdata[3], $sdata[4],
          $sdata[5], $sDbgn, $sDend, $sdata[8], " ",
          $userid, current, $userid, current);
          
         printf("SQLCODE=[%d]\n",SQLCODE); 
        if (SQLCODE != 0)
        {
            sprintf_s(stmp2, sizeof stmp2,"�� %d �����~,���~�N�X[%d %s] \n",m,SQLCODE,sqlca.sqlerrm);
            strcat(msgbuf,stmp2);
             printf("msgbuf=[%s] \n",msgbuf); 
            continue;
        }
        else
            qcount ++;
        
	}	   	 	      
    fclose(fp);
   printf("------- 294 i=[%d] qcount=[%d]--------- \n",i,qcount); 
    sprintf_s(stmp2, sizeof stmp2,"\n�ɮצ@ %d ��,������J %d �� \n",i,qcount);
    strcat(msgbuf,stmp2);
     EWRITE(userid,SQLCODE,msgbuf);
    return M_CM_OK;

errexit:
    printf("--car2154_ReadFile-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/* -------------------------------------------------------------------------- */
/* ���O���� */
long car2154_CmpPlyData()
{
    $char stmp[1000], stmp1[100], stmp2[100];
    int rc1;
    
    $WHENEVER SQLERROR GOTO errexit;
    
    if (strcmp(Date_type,"1") == 0)
    {
        /* �ʲz����J�� */
        sprintf_s(stmp1, sizeof stmp1," and a.dendry_ins between '%s' and '%s' ",sDate1,sDate2);
    }else if (strcmp(Date_type,"2") == 0){
        /* �s�w�פJ�� */
        sprintf_s(stmp1, sizeof stmp1," and date(a.dcreate) between '%s' and '%s' ",sDate1,sDate2);
    }else if (strcmp(Date_type,"3") == 0){
        /* �s�w��s�� */
        sprintf_s(stmp1, sizeof stmp1," and date(a.dupdate) between '%s' and '%s' ",sDate1,sDate2);
    }else
        strcpy(stmp1," ");
    
     /* �`�N:�U�CSQL����''�OASCII��127�X,�b�S�w�r���~�ݱo��,�������@�Ӧr��,
        ���i�H�b��Excel�ɮɥi�H��ܧ��㪺�Ʀr, ���i��|�y�������D,���V��.. */
    /* ���̨������ */
    sprintf_s(stmp, sizeof stmp,"select a.icard_ins, '17'||trim(b.itarget2) as icard_newa, "
                 "       ''||b.itarget1 as itag_newa, ''||b.iassured as iassured, "
                 "       ''||b.ntarget1 as iengine_newa, b.dins_bgn, "
                 "       b.dins_end, ''||b.iofficer as iofficer, "
                 "       (select nname from officer where iofficer = b.iofficer) as nofficer, "
                 "       ''||b.ileader as ileader, (select nname from officer "
                 "       where iofficer = b.ileader) as nleader, "
                 "       (select nbranch from sa_branch_type where ibranch = b.iquota) as nbranch, "
                 "       trim(b.ipolicy1)||trim(b.ipolicy2) as ipolicy "
                 "  from sysdb:ca_card_road_rechk a, policy_new b "
                 " where b.insure_type = 'C'  and b.insure_level = 'C1' "
                 "   and b.isys_source = 'CAR' and a.icard_newa = ' ' %s "
                 "   and b.dins_end >= today  and (a.itag_ins = b.itarget1 ) "
                 "  into temp tp_1 with no log; ",stmp1);
    $prepare pre_tag1 from $stmp;
    printf("356:stmp=[%s]\n",stmp);
	$execute pre_tag1;

    /* �A�O��������� */
    sprintf_s(stmp, sizeof stmp,"select a.icard_ins, '17'||trim(b.itarget2) as icard_newa, "
                 "       ''||b.itarget1 as itag_newa, ''||b.iassured as iassured, "
                 "       ''||b.ntarget1 as iengine_newa, b.dins_bgn, "
                 "       b.dins_end, ''||b.iofficer as iofficer, "
                 "       (select nname from officer where iofficer = b.iofficer) as nofficer, "
                 "       ''||b.ileader as ileader, (select nname from officer "
                 "       where iofficer = b.ileader) as nleader, "
                 "       (select nbranch from sa_branch_type where ibranch = b.iquota) as nbranch, "
                 "       trim(b.ipolicy1)||trim(b.ipolicy2) as ipolicy "
                 "  from sysdb:ca_card_road_rechk a, policy_new b "
                 " where b.insure_type = 'C'  and b.insure_level = 'C1' "
                 "   and b.isys_source = 'CAR' and a.icard_newa = ' '  %s "
                 "   and b.dins_end >= today  "
                 "   and a.icard_ins not in (select unique icard_ins from tp_1) "
                 "   and a.iengine_ins = b.ntarget1 "
                 "  into temp tp_2 with no log; ",stmp1);
    $prepare pre_iengine1 from $stmp;
    printf("376:stmp=[%s]\n",stmp);
	$execute pre_iengine1;
    
    /* �N��쪺��ƷJ�㦨�@��table */
    $select * from tp_1 
     union all 
     select * from tp_2
     into temp tp_3 with no log; 
     
    sprintf_s(stmp, sizeof stmp,
        "select a.icard_ins, a.dendry_ins, ''||a.itag_ins as itag_ins, "
        "       ''||a.iinsurand_ins as iinsurand_ins , ''||a.iengine_ins as iengine_ins, "
        "       ''||a.ibody_ins as ibody_ins, a.dply_begin_ins, a.dply_end_ins, "
        "       a.sfactroy, date(a.dcreate) as dcreate, b.icard_newa, b.itag_newa, "
        "       b.iassured, b.iengine_newa, b.dins_bgn, b.dins_end, b.iofficer, "
        "       b.nofficer, b.ileader, b.nleader, b.nbranch, date(a.dupdate) as dupdate, "
        "       b.ipolicy "
        "  from sysdb:ca_card_road_rechk a,  outer tp_3 b "
        " where a.icard_ins = b.icard_ins and a.icard_newa = ' ' %s  "
        "  into temp tp_all with no log ",stmp1);
        
    $prepare pre_21 from $stmp;
    
    printf("397:stmp=[%s]\n",stmp);
	$execute pre_21;
	
	rc1 = car2154_print_rpt();
    if (rc1 != M_CM_OK) {
        printf("error on car2154_print_rpt\n");
        EWRITE(userid, rc1, "���O�浲�G���~!");
        return rc1;
    }
    
    
    return M_CM_OK;
    
errexit:
   printf("--car2154_CmpPlyData-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

/* -------------------------------------------------------------------------- */
/* �d�߸�� */
long car2154_QryPlyData()
{
    DBinfo *list;
    int   count_db, k;
    
    $char stmp[1000], stmp1[100], stmp2[100];
    int rc1;
    
    $WHENEVER SQLERROR GOTO errexit;
    
    if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
        if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
            return M_CM_NOT_DBLIST;
    }
   
    $create temp table tp_q1 
    (
        icard_ins   char(17),
        icard_newa  char(17),
        ipolicy     char(20),
        itag        char(13),
        iassured    char(13),
        iengine     char(26),
        dply_begin  date,
        dply_end    date,
        iofficer    char(11),
        nofficer    char(20),
        ileader     char(11),
        nleader     char(20),
        nbranch     char(40)
    )with no log;
    
    
    if (strcmp(Date_type,"1") == 0)
    {
        /* �ʲz����J�� */
        sprintf_s(stmp1, sizeof stmp1," and a.dendry_ins between '%s' and '%s' ",sDate1,sDate2);
    }else if (strcmp(Date_type,"2") == 0){
        /* �s�w�פJ�� */
        sprintf_s(stmp1, sizeof stmp1," and date(a.dcreate) between '%s' and '%s' ",sDate1,sDate2);
    }else if (strcmp(Date_type,"3") == 0){
        /* �s�w��s�� */
        sprintf_s(stmp1, sizeof stmp1," and date(a.dupdate) between '%s' and '%s' ",sDate1,sDate2);
    }else
        strcpy(stmp1," ");
    
    for(k=0;k<count_db;k++)
    {
        sprintf_s(stmp, sizeof stmp,
            "insert into tp_q1 "
            "select a.icard_ins, a.icard_newa, b.ipolicy, ''||d.itag as itag, "
            "       ''||d.iassured as iassured, ''||d.iengine as iengine, "
            "       c.dply_begin, c.dply_end, ''||c.iofficer as iofficer, "
            "       (select nname from officer where iofficer = c.iofficer), "
            "       ''||c.ileader as ileader, (select nname from officer "
            "       where iofficer = c.ileader), "
            "       (select nbranch from sa_branch_type where ibranch = c.iquota) "
            "  from sysdb:ca_card_road_rechk a, compulsory_card b, "
            "       %s:ply_relation c, %s:policy d "
            " where a.icard_newa <> ' ' %s "
            "   and b.icard in (select unique icard_newa[3,17] from sysdb:ca_card_road_rechk "
            "       where icard_newa <> ' ') "
            "   and a.icard_newa[3,17] = b.icard and b.ipolicy = c.ipolicy "
            "   and b.ipolicy = d.ipolicy and c.fcard_class = '1' ",
            list[k].dbname, list[k].dbname, stmp1);
            printf("495:stmp=[%s]\n", stmp);
    }
    
    
    $prepare pre_q1 from $stmp;
	$execute pre_q1;
    
    /* �Nca_card_road_rechk�P��쪺�O���ƷJ�㦨�@��table */
    sprintf_s(stmp, sizeof stmp,
        "select a.icard_ins, a.dendry_ins, ''||a.itag_ins as itag_ins, "
        "       ''||a.iinsurand_ins as iinsurand_ins, ''||a.iengine_ins as iengine_ins, "
        "       ''||a.ibody_ins as ibody_ins, a.dply_begin_ins, a.dply_end_ins, "
        "       a.sfactroy, date(a.dcreate) as dcreate, b.icard_newa, ''||b.itag as itag, "
        "       ''||b.iassured as iassured, ''||b.iengine as iengine, b.dply_begin, "
        "       b.dply_end, ''||b.iofficer as iofficer, b.nofficer, ''||b.ileader as ileader, "
        "       b.nleader, b.nbranch, date(a.dupdate) as dupdate, b.ipolicy "
        "  from sysdb:ca_card_road_rechk a,  outer tp_q1 b "
        " where a.icard_ins = b.icard_ins  %s  "
        "  into temp tp_all with no log ",stmp1);
printf("495:stmp=[%s]\n", stmp);
    $prepare pre_q2 from $stmp;
	$execute pre_q2;
	
	rc1 = car2154_print_rpt();
    if (rc1 != M_CM_OK) {
        printf("error on car2154_print_rpt\n");
        EWRITE(userid, rc1, "��Ƭd�ߦ��~!");
        return rc1;
    }
    
    
    return M_CM_OK;
    
errexit:
   printf("--car2154_QryPlyData-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/* -------------------------------------------------------------------------- */
long car2154_print_rpt()
{
    int     rc;
    char    sfilename[100],stitle[1024],stmt[1024];

    $WHENEVER SQLERROR GOTO errexit;

    if (strcmp(Opt,"21") == 0)
        strcpy(sfilename,"���O�浲�G");
    else if (strcmp(Opt,"22") == 0)
        strcpy(sfilename,"�d�߳���");
    else
        strcpy(sfilename,"��L");
        
        
    strcpy(stitle,"�{���N��:CAR2154\t");
    strcat(stitle,sfilename);
    strcat(stitle,"\t\t\t\t\t\t\t\t\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");
    strcat(sfilename,"[CAR2154]");

    strcat(stitle,"\t�O�I�Ҹ�\t��J���\t����\t�����Ҹ�/�νs\t�������X\t�������X\t");
    strcat(stitle,"�O�I�}�l���\t�O�I�������\t�N�˼t�W��\t�s�w�פJ���\t");
    strcat(stitle,"�s�w�O�I�Ҹ�\t�s�w����\t�s�w�Q�O�HID\t�s�w������\t�s�w�O�I�_��\t");
    strcat(stitle,"�s�w�O�I����\t�s�w�g��N��\t�s�w�g��W��\t�s�w�޲z�H�N��\t");
    strcat(stitle,"�s�w�޲z�H�W��\t�s�w�~�Z���\t�s�w��s���\t�s�w�O�渹\t");

    strcpy(stmt,"select * from tp_all where 1=1");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);

    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;
    
errexit:
   printf("--car2154_print_rpt-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

/* -------------------------------------------------------------------------- */
/* ��s�s�w�j���Ҹ� */
long car2154_UpdIcardNewa()
{
    char  *bp;    
    char  filename[128],syy[5],smm[3],sdd[3];
    int   rc, i, j, k, m, n, qcount;
    $char sdata[10][121];
    $char sDbgn[11],sDend[11],sDentry[11],stmp1[11], stmp2[41];
    
    printf("---- car2154_UpdIcardNewa  start   ----- \n");    

    $WHENEVER SQLERROR GOTO errexit;
    
    
    strcpy(Upfile, trim(Upfile));
    sprintf_s(filename, sizeof filename,"%s/dat/car/%s",sApHome,Upfile);
    flen=1024;
    if ((fp=fopen(filename,"r"))==NULL) {
       sprintf_s(msgbuf, sizeof msgbuf,"%s �ɮ׶}�ҥ���",filename);
       EWRITE(userid,FALSE,msgbuf);
       return FALSE;
    }
    if ((bp=malloc(flen))==NULL) {
       sprintf_s(msgbuf, sizeof msgbuf,"System malloc failed !");
       EWRITE(userid,FALSE,msgbuf);
       free(bp);
       return FALSE;
    }
    
    /* ��s�s�w�j���Ҹ���� */
	$BEGIN WORK;
	
	for (i=0;(feof(fp)==0);i++) 
    {
        memset(bp,0x00,flen);
		fgets(bp,flen,fp);
		        
        if (bp[0]==0x00)	break;
		if (strlen(trim(bp))<10)	break;
		        	
        for(j=0;j<10;j++)
		   sdata[j][0]='\0';
		
		k=m=n=0;
        for (j=0;j<flen;j++)
        {
            if (bp[j]=='\t' || bp[j]=='\0' || bp[j]=='\n')
            {
                strncpy(sdata[k],bp+m,j-m);
                sdata[k][j-m]='\0';
                m=j+1;
                k++;
            }
            if (bp[j]=='\n')
                break;
            if (k > 10-1) break;
        }
		
		if (sdata[0][0]=='\0') continue;
		
		printf("649:sdata[0]=[%s] sdata[9]=[%s]\n",sdata[0],sdata[9]);
		
		$update sysdb:ca_card_road_rechk
		    set icard_newa = $sdata[9]
		  where icard_ins = $sdata[0]
		    and icard_newa = ' ';
        
	}	   	 	      
	
    fclose(fp);
    $COMMIT WORK;
    
    EWRITE(userid, M_CM_OK, "�i��s�s�w�j���Ҹ��j����!");
    return M_CM_OK;

errexit:
    printf("--car2154_UpdIcardNewa-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    $ROLLBACK WORK;
    return SQLCODE;
}
/* -------------------------------------------------------------------------- */
/* ���s�^�и�� */
long car2154_GetAckRpt()
{
    char  filename1[31],filename2[31];
    $char stoday[11], stmp[500], stmp1[100];
    $char icard_ins[21], sdentry[11], icard_newa[21],icar_type[3], prtstr[50];
    int  rt;
    
    $WHENEVER SQLERROR GOTO errexit;
    
    $select first 1 to_char(today,'%Y%m%d') into $stoday
      from car_code where 1=1;
    
    strcpy(stoday, trim(stoday));  
    printf("stoday=[%s]\n",stoday);  
    
    memset(file1,0x00,sizeof(file1));
    memset(file2,0x00,sizeof(file2));
    
    sprintf_s(filename1, sizeof filename1,"ACKTVCU17%s.txt",stoday);
	sprintf_s(file1, sizeof file1,"%s/rptftp/%s",sApHome,filename1); /* �T�� */
	
	sprintf_s(filename2, sizeof filename2,"ACKTVMU17%s.txt",stoday);
	sprintf_s(file2, sizeof file2,"%s/rptftp/%s",sApHome,filename2); /* ���� */
	
    rt = rptftpinsert(userid,"car2154",filename1);
    rt = rptftpinsert(userid,"car2154",filename2);

    if (strcmp(Date_type,"3") == 0)
        sprintf_s(stmp1, sizeof stmp1,"and date(a.dupdate) between '%s' and '%s' ", sDate1, sDate2); /* �s�w��s�� */
    else if (strcmp(Date_type,"2") == 0)
        sprintf_s(stmp1, sizeof stmp1,"and date(a.dcreate) between '%s' and '%s' ", sDate1, sDate2); /* �s�w�פJ�� */
    else
        sprintf_s(stmp1, sizeof stmp1,"and a.dendry_ins between '%s' and '%s' ", sDate1, sDate2); /* �ʲz����J�� */
        
    fp1=fopen(file1,"w");
    fp2=fopen(file2,"w");

    sprintf_s(stmp, sizeof stmp, "select a.icard_ins, to_char(a.dendry_ins,'%%Y%%m%%d'), a.icard_newa, "
                  "       case when b.icar_type in ('01','02','32','34') then "
                  "       'M' else 'C' end "
                  "  from sysdb:ca_card_road_rechk a, compulsory_card b "
                  " where a.icard_newa <> ' ' %s "
                  "   and b.icard in (select unique icard_newa[3,17] "
                  "       from sysdb:ca_card_road_rechk where icard_newa <> ' ') "
                  "   and a.icard_newa[3,17] = b.icard ",stmp1);
    printf("stmp=[%s]\n",stmp);
    
    $PREPARE pre_A1 from $stmp;
    $DECLARE cus_A1 CURSOR FOR pre_A1;
    $OPEN cus_A1;
    while(1)
    {
        $FETCH cus_A1 into $icard_ins, $sdentry, $icard_newa, $icar_type;
        if (SQLCODE==SQLNOTFOUND) break;
        
        strcpy(icard_ins, trim(icard_ins));
        strcpy(sdentry, trim(sdentry));
        strcpy(icard_newa, trim(icard_newa));
        strcpy(icar_type, trim(icar_type));
        
        if (strcmp(icar_type,"C") == 0)
        {
            sprintf_s(prtstr, sizeof prtstr,"%-17.17s%8.8s%-17.17s",icard_ins,sdentry,icard_newa);
            fprintf(fp1,"%s\n",prtstr);
        }
        else 
        {
            sprintf_s(prtstr, sizeof prtstr,"%-17.17s%8.8s%-17.17s",icard_ins,sdentry,icard_newa);
            fprintf(fp2,"%s\n",prtstr);
        }
	
    }
    $CLOSE cus_A1;
    $FREE cus_A1;
    fclose(fp1);
    fclose(fp2);
    
    EWRITE(userid, M_CM_OK, "�Цܡi�ɮפU���@�~�]cmn202�^�j�U���ɮ�(�@�G��)!");
    return M_CM_OK;
    
errexit:
   printf("--car2154_GetAckRpt-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}