/**********************************************************
 *                                                        *
 *   Program    : ca_loss_fun.ec                          *
 *                                                        *
 *   Description: �p��l�v��Ƭ��� Function               *
 *                                                        *
 *   Author     : Maggie 87.06.24                         *
 *                                                        *
 **********************************************************/

#include <stdio.h>
#include "api_xsrv.h"
#include "sql.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "commsgs.h"
#include "carmsgs.h"
$include sqlca;
$include datetime.h;
#include "safeclib.h"

#define SUCCESS                 1
#define FAIL                    0
#define FOUND                   sqlca.sqlcode!=SQLNOTFOUND
#define NOT_FOUND               sqlca.sqlcode==SQLNOTFOUND

#define YES                     1
#define NO                      0
 
/**#define _880422**/


/****************************************************************************/
/* �p�⺡���O�O,24���k   */
long ca_calc_24_mfull(p_dbgn, p_dend, p_dply_bgn, p_dply_end,
                      p_mprem, p_mfull)
long p_dbgn, p_dend;
long p_dply_bgn, p_dply_end;
long p_mprem, *p_mfull;
{
  char dbgn_ymd[YYYYMMDD], dend_ymd[YYYYMMDD];
  char dply_bgn_ymd[YYYYMMDD], dply_end_ymd[YYYYMMDD];
  char c_dbgn_yy[YYYY], c_dbgn_mm[MM];
  char c_dend_yy[YYYY], c_dend_mm[MM];
  int  dbgn_yy, dbgn_mm;
  int  dend_yy, dend_mm;

  long Mmiddle, Mbegin, Mend;
  long Sdm, Edm, Sdm_prev; 
  long tmp, PlySdm, PlyEdm;

printf("------1 into ca_calc_24_mfull()\n");
  /*----*/
  if (p_dply_bgn <= 0 || p_dply_end <= 0)
      return M_CA_DPLY_ERROR;

printf("------2\n");
  /*----*/
  strcpy(dbgn_ymd,cm_edate_str(p_dbgn));
  strcpy(dend_ymd,cm_edate_str(p_dend));
  strcpy(dply_bgn_ymd,cm_edate_str(p_dply_bgn));
  strcpy(dply_end_ymd,cm_edate_str(p_dply_end));

printf("------3 dbgn_ymd[%s] dend_ymd[%s]\n",dbgn_ymd,dend_ymd);
printf("------3 dply_bgn_ymd[%s] dply_end_ymd[%s]\n",dply_bgn_ymd,dply_end_ymd);
  /*----*/
  strncpy(c_dbgn_yy,&dbgn_ymd[6],4); dbgn_yy=atoi(c_dbgn_yy);
  strncpy(c_dbgn_mm,dbgn_ymd,2); dbgn_mm=atoi(c_dbgn_mm);
  Sdm=dbgn_yy * 12 + dbgn_mm;
  Sdm_prev=Sdm-1;

printf("------4 Sdm[%d] Sdm_prev[%d]\n",Sdm,Sdm_prev);

  strncpy(c_dend_yy,&dend_ymd[6],4); dend_yy=atoi(c_dend_yy);
  strncpy(c_dend_mm,dend_ymd,2); dend_mm=atoi(c_dend_mm);
  Edm=dend_yy * 12 + dend_mm;

printf("------5 Edm[%d]\n",Edm);
  /*----*/
  strncpy(c_dbgn_yy,&dply_bgn_ymd[6],4); dbgn_yy=atoi(c_dbgn_yy);
  strncpy(c_dbgn_mm,dply_bgn_ymd,2); dbgn_mm=atoi(c_dbgn_mm);
  PlySdm=dbgn_yy * 12 + dbgn_mm;

printf("------6 PlySdm[%d]\n",PlySdm);
  strncpy(c_dend_yy,&dply_end_ymd[6],4); dend_yy=atoi(c_dend_yy);
printf("------6-1 c_dend_yy[%s] dend_yy[%d]\n",c_dend_yy, dend_yy);
  strncpy(c_dend_mm,dply_end_ymd,2); dend_mm=atoi(c_dend_mm);
printf("------6-2 c_dend_mm[%s] dend_mm[%d]\n",c_dend_mm, dend_mm);
  PlyEdm=dend_yy * 12 + dend_mm;

printf("------6 PlyEdm[%d]\n",PlyEdm);
  /*----*/
  Mmiddle=Mbegin=Mend=0;

  if (p_dbgn <= p_dply_bgn && p_dply_end <= p_dend)
      Mmiddle = p_mprem;
  else
  {
      if (p_dply_bgn < p_dbgn && p_dply_end >= p_dbgn)
      {
        Mbegin = p_mprem * ((PlyEdm - Sdm_prev) * 2 - 1);
        tmp = (PlyEdm - PlySdm) * 2;
printf("------7 tmp[%d]\n",tmp);
        Mbegin = Mbegin / tmp;
      }
      if (p_dply_end > p_dend)
      { 
        Mend = p_mprem * ((PlyEdm - Edm) * 2 - 1);
        tmp = (PlyEdm - PlySdm) * 2;
printf("------8 tmp[%d]\n",tmp);
        Mend = Mend / tmp;
        Mmiddle = p_mprem;
      }
  }

  if (p_dply_bgn < p_dbgn && p_dply_end > p_dend)
      *p_mfull = Mbegin - Mend;
  else
      *p_mfull = Mbegin + Mmiddle - Mend;
 

  return SUCCESS;

}

/****************************************************************************/
/* �p�⺡���O�O,365���k */
long ca_calc_365_mfull(p_dbgn, p_dend, p_dply_bgn, p_dply_end,
                       p_mprem, p_mfull)
long p_dbgn, p_dend;
long p_dply_bgn, p_dply_end;
long p_mprem, *p_mfull;
{
  long dbgn_prev;
  long Mmiddle, Mbegin, Mend;

  if (p_dbgn <= 0 || p_dend <= 0)
      return M_CA_DATE_ERROR;

  dbgn_prev = p_dbgn - 1;

  Mmiddle=Mbegin=Mend=0;

  if (p_dply_bgn < p_dbgn && p_dply_end >= p_dbgn)
      Mbegin = p_mprem 
             * ((p_dply_end - dbgn_prev)*2-1) / (p_dply_end - p_dply_bgn) / 2;

  if (p_dbgn <= p_dply_bgn && p_dply_bgn <= p_dend)
      Mmiddle = p_mprem;

  if (p_dply_end > p_dend)
      Mend = p_mprem 
           * ((p_dply_end - p_dend)*2-1) / (p_dply_end - p_dply_bgn) / 2;

  *p_mfull = Mbegin + Mmiddle - Mend;

  return SUCCESS;

}
/**************/
long ca_loss_upd_InsTypTable_prem(p_wkinx, p_irule, p_imethod, p_dbgn, p_dend,
                                  p_ibranch, p_icar_type, p_iins_type,
                                  p_mprem, p_mfull)
$char *p_wkinx, *p_irule, *p_imethod;
$long p_dbgn, p_dend;
$char *p_ibranch, *p_icar_type, *p_iins_type;
$long p_mprem, p_mfull;
{
   $WHENEVER SQLERROR GOTO errexit;

   $UPDATE ca_loss_ins_type
       SET qprem = qprem + 1,
           mprem = mprem + $p_mprem,
           mfull = mfull + $p_mfull
     WHERE wkinx     = $p_wkinx
       AND irule     = $p_irule
       AND imethod   = $p_imethod
       AND dbgn      = $p_dbgn
       AND dend      = $p_dend
       AND ibranch   = $p_ibranch
       AND icar_type = $p_icar_type
       AND iins_type = $p_iins_type;
   if (sqlca.sqlerrd[2]==0)
   {
       $INSERT INTO ca_loss_ins_type
                    (wkinx, irule, imethod, dbgn, dend,
                     ibranch, icar_type, iins_type,
                     qprem, mprem, mfull)
             VALUES ($p_wkinx, $p_irule, $p_imethod, $p_dbgn, $p_dend,
                     $p_ibranch, $p_icar_type, $p_iins_type,
                     1, $p_mprem, $p_mfull);
   }

   return SUCCESS;

errexit:
   return SQLCODE;
}

/****************************************************************************/
/*  Update Or Insert ca_loss_ins_grp,   */
/*                   ca_loss_bigcomp,   */
/*                   ca_loss_officer    */

long ca_loss_upd_InsGrpTable_prem(p_wkinx, p_irule, p_imethod, p_dbgn, p_dend,
                                  p_ibranch, p_ibrand_12, p_icar_type, 
                                  p_iofficer,
                                  p_ibig_comp, p_ibig_branch, p_ibig_office,
                                  p_iins_grp, p_mprem, p_mfull)
$char p_wkinx[11], p_irule[2], p_imethod[2];
$long p_dbgn, p_dend;
$char p_ibranch[BRANCH_ID], p_ibrand_12[3];
$char p_icar_type[3], p_iofficer[EMPLOYEE_ID];
$char p_ibig_comp[2], p_ibig_branch[5], p_ibig_office[10];
$char p_iins_grp[2];
$long p_mprem, p_mfull;
{
   char buf1[11], buf2[11];

   $WHENEVER SQLERROR GOTO errexit;

strcpy(buf1,cm_cdate_str_100(p_dbgn));
printf("-----BGN[%s]\n",buf1);
strcpy(buf2,cm_cdate_str_100(p_dend));
printf("-----END[%s]\n",buf2);



/*printf("-----update ca_loss_ins_grp\n");*/
   /*---------------------------------*/
   $UPDATE ca_loss_ins_grp
       SET mprem = mprem + $p_mprem,
           mfull = mfull + $p_mfull
     WHERE wkinx     = $p_wkinx
       AND irule     = $p_irule
       AND imethod   = $p_imethod
       AND dbgn      = $p_dbgn
       AND dend      = $p_dend
       AND ibranch   = $p_ibranch
       AND ibrand_12 = $p_ibrand_12
       AND icar_type = $p_icar_type
       AND iins_grp  = $p_iins_grp ;
   if (sqlca.sqlerrd[2]==0)
   {
/*printf("-----insert ca_loss_ins_grp\n");
printf("-----[%s][%s][%s][%d][%d][%s][%s][%s][%s][%d][%d]\n",p_wkinx,p_irule,p_imethod,p_dbgn,p_dend,p_ibranch,p_ibrand_12,p_icar_type,p_iins_grp,p_mprem,p_mfull);*/

       $INSERT INTO ca_loss_ins_grp 
                    (wkinx, irule, imethod, dbgn, dend,
                     ibranch, ibrand_12, icar_type, iins_grp,
                     mprem, mfull)
             VALUES ($p_wkinx, $p_irule, $p_imethod, $p_dbgn, $p_dend,
                     $p_ibranch, $p_ibrand_12, $p_icar_type, $p_iins_grp,
                     $p_mprem, $p_mfull);
   }

   /*---------------------------------*/
   if (isalpha(p_ibig_comp[0])) {
printf("-----update ca_loss_bigcomp\n");

       $select wkinx from ca_loss_bigcomp
         where wkinx=$p_wkinx and irule=$p_irule
           and imethod=$p_imethod and dbgn=$p_dbgn
           and dend=$p_dend and ibig_comp=$p_ibig_comp
           and ibig_branch=$p_ibig_branch
           and ibig_office=$p_ibig_office
           and icar_type=$p_icar_type
           and iins_grp=$p_iins_grp;
       printf("-------SELECT CA_LOSS_BIGCOMP:SQLCODE[%d]\n",SQLCODE);

       $UPDATE ca_loss_bigcomp
           SET mfull = mfull + $p_mfull
         WHERE wkinx       = $p_wkinx
           AND irule       = $p_irule
           AND imethod     = $p_imethod
           AND dbgn        = $p_dbgn
           AND dend        = $p_dend
           AND ibig_comp   = $p_ibig_comp
           AND ibig_branch = $p_ibig_branch
           AND ibig_office = $p_ibig_office
           AND icar_type   = $p_icar_type
           AND iins_grp    = $p_iins_grp ;
       if (sqlca.sqlerrd[2]==0)
       {
printf("-----insert ca_loss_bigcomp\n");
printf("-----[%s][%s][%s][%d][%d][%s][%s][%s][%s][%s][%d]\n",p_wkinx,p_irule,p_imethod,p_dbgn,p_dend,p_ibig_comp,p_ibig_branch,p_ibig_office,p_icar_type,p_iins_grp,p_mfull);

           $INSERT INTO ca_loss_bigcomp 
                        (wkinx, irule, imethod, dbgn, dend,
                         ibig_comp, ibig_branch, ibig_office,
                         icar_type, iins_grp, mfull)
                 VALUES ($p_wkinx, $p_irule, $p_imethod, $p_dbgn, $p_dend,
                         $p_ibig_comp, $p_ibig_branch, $p_ibig_office, 
                         $p_icar_type, $p_iins_grp, $p_mfull);
       }
   }

printf("-----update ca_loss_officer\n");
   /*---------------------------------*/
   $UPDATE ca_loss_officer
       SET mfull = mfull + $p_mfull
     WHERE wkinx    = $p_wkinx
       AND irule    = $p_irule
       AND imethod  = $p_imethod
       AND dbgn     = $p_dbgn
       AND dend     = $p_dend
       AND ibranch  = $p_ibranch
       AND iofficer = $p_iofficer
       AND iins_grp = $p_iins_grp ;
   if (sqlca.sqlerrd[2]==0)
   {
printf("-----insert ca_loss_officer\n");
printf("-----[%s][%s][%s][%d][%d][%s][%s][%s][%d]\n",p_wkinx,p_irule,p_imethod,p_dbgn,p_dend,p_ibranch,p_iofficer,p_iins_grp,p_mfull);

       $INSERT INTO ca_loss_officer 
                    (wkinx, irule, imethod, dbgn, dend,
                     ibranch, iofficer, iins_grp, mfull)
             VALUES ($p_wkinx, $p_irule, $p_imethod, $p_dbgn, $p_dend,
                     $p_ibranch, $p_iofficer, $p_iins_grp, $p_mfull);
   }

   return SUCCESS;

errexit:
   return SQLCODE;
}

/****************************************************************************/
/*  Update Or Insert ca_loss_ins_type   */

long ca_loss_upd_InsTypTable_payment(p_wkinx, p_irule, p_imethod,
                                     p_dbgn, p_dend,
                                     p_ibranch, p_icar_type, p_iins_type,
                                     p_mstl, p_qstl,
                                     p_mend_outstl, p_qend_outstl,
                                     p_mbgn_outstl, p_qbgn_outstl)
$char *p_wkinx, *p_irule, *p_imethod;
$long p_dbgn, p_dend;
$char *p_ibranch, *p_icar_type, *p_iins_type;
$long p_mstl, p_qstl;
$long p_mend_outstl, p_qend_outstl;
$long p_mbgn_outstl, p_qbgn_outstl;
{
   $char tmp_iins_type[INSURANCE_TYPE];

   $WHENEVER SQLERROR GOTO errexit;

   /*   ��ƬO�_�����ǤJ ????????? */
   /*   93,94,95�αj���� ???????? */

   strcpy(p_iins_type,trim(p_iins_type));
   if (strcmp(p_iins_type,"93")==0 || 
       strcmp(p_iins_type,"94")==0 ||
       strcmp(p_iins_type,"95")==0)
       strcpy(tmp_iins_type, "31");
   else
       strcpy(tmp_iins_type, p_iins_type);
       

   $UPDATE ca_loss_ins_type
       SET qstl        = qstl + 1,
           mstl        = mstl + $p_mstl,
           qend_outstl = qend_outstl + 1,
           mend_outstl = mend_outstl + $p_mend_outstl,
           qbgn_outstl = qbgn_outstl + 1,
           mbgn_outstl = mbgn_outstl + $p_mbgn_outstl
     WHERE wkinx     = $p_wkinx 
       AND irule     = $p_irule
       AND imethod   = $p_imethod
       AND dbgn      = $p_dbgn
       AND dend      = $p_dend
       AND ibranch   = $p_ibranch
       AND icar_type = $p_icar_type
       AND iins_type = $tmp_iins_type;
   if (sqlca.sqlerrd[2]==0)
   {
       $INSERT INTO ca_loss_ins_type
                    (wkinx, irule, imethod, dbgn, dend,
                     ibranch, icar_type, iins_type,
                     qstl, mstl, qend_outstl, mend_outstl,
                     qbgn_outstl, mbgn_outstl)
             VALUES ($p_wkinx, $p_irule, $p_imethod, $p_dbgn, $p_dend,
                     $p_ibranch, $p_icar_type, $tmp_iins_type,
                     $p_qstl, $p_mstl,
                     $p_qend_outstl, $p_mend_outstl,
                     $p_qbgn_outstl, $p_mbgn_outstl);
   }

   return SUCCESS;

errexit:
   return SQLCODE;
}

/****************************************************************************/
/*  Update Or Insert ca_loss_ins_grp,   */
/*                   ca_loss_bigcomp,   */
/*                   ca_loss_officer    */

long ca_loss_upd_InsGrpTable_payment(p_wkinx, p_irule, p_imethod,
                                     p_dbgn, p_dend,
                                     p_ibranch, p_ibrand_12, p_icar_type,
                                     p_iofficer,
                                     p_ibig_comp, p_ibig_branch, p_ibig_office,
                                     p_iins_grp, p_mpayment)
$char *p_wkinx, *p_irule, *p_imethod;
$long p_dbgn, p_dend;
$char *p_ibranch, *p_ibrand_12, *p_icar_type, *p_iofficer;
$char *p_ibig_comp, *p_ibig_branch, *p_ibig_office;
$char *p_iins_grp;
$long p_mpayment;
{

   $WHENEVER SQLERROR GOTO errexit;
   
   /*---------------------------------*/
   $UPDATE ca_loss_ins_grp
       SET mpayment  = mpayment + $p_mpayment
     WHERE wkinx     = $p_wkinx
       AND irule     = $p_irule
       AND imethod   = $p_imethod
       AND dbgn      = $p_dbgn
       AND dend      = $p_dend
       AND ibranch   = $p_ibranch
       AND ibrand_12 = $p_ibrand_12
       AND icar_type = $p_icar_type
       AND iins_grp  = $p_iins_grp;
   if (sqlca.sqlerrd[2]==0)
   {
       $INSERT INTO ca_loss_ins_grp
                    (wkinx, irule, imethod, dbgn, dend,
                     ibranch, ibrand_12, icar_type, iins_grp,
                     mpayment)
             VALUES ($p_wkinx, $p_irule, $p_imethod, $p_dbgn, $p_dend,
                     $p_ibranch, $p_ibrand_12, $p_icar_type, $p_iins_grp,
                     $p_mpayment);
   }

   /*---------------------------------*/
   if (isalpha(p_ibig_comp[0])) {
       $UPDATE ca_loss_bigcomp
           SET mpayment  = mpayment + $p_mpayment
         WHERE wkinx       = $p_wkinx
           AND irule       = $p_irule
           AND imethod     = $p_imethod
           AND dbgn        = $p_dbgn
           AND dend        = $p_dend
           AND ibig_comp   = $p_ibig_comp
           AND ibig_branch = $p_ibig_branch
           AND ibig_office = $p_ibig_office
           AND icar_type   = $p_icar_type
           AND iins_grp    = $p_iins_grp;
       if (sqlca.sqlerrd[2]==0)
       {
           $INSERT INTO ca_loss_bigcomp
                        (wkinx, irule, imethod, dbgn, dend,
                         ibig_comp, ibig_branch, ibig_office, 
                         icar_type, iins_grp, mpayment)
                 VALUES ($p_wkinx, $p_irule, $p_imethod, $p_dbgn, $p_dend,
                         $p_ibig_comp, $p_ibig_branch, $p_ibig_office,
                         $p_icar_type, $p_iins_grp, $p_mpayment);
       }
   }

   /*---------------------------------*/
   $UPDATE ca_loss_officer
       SET mpayment  = mpayment + $p_mpayment
     WHERE wkinx    = $p_wkinx
       AND irule    = $p_irule
       AND imethod  = $p_imethod
       AND dbgn     = $p_dbgn
       AND dend     = $p_dend
       AND ibranch  = $p_ibranch
       AND iofficer = $p_iofficer
       AND iins_grp = $p_iins_grp;
   if (sqlca.sqlerrd[2]==0)
   {
       $INSERT INTO ca_loss_officer
                    (wkinx, irule, imethod, dbgn, dend,
                     ibranch, iofficer, iins_grp, mpayment)
             VALUES ($p_wkinx, $p_irule, $p_imethod, $p_dbgn, $p_dend,
                     $p_ibranch, $p_iofficer, $p_iins_grp, $p_mpayment);
   }

   return SUCCESS;

errexit:
   return SQLCODE;
}




/****************************************************************************/
/****************************************************************************/
/* �p��ߴڪ��B (�O���/��~�� �@��)                      */
/* return �ߴڪ��B, �w�M�ߴ�, �������M,     ���쥼�M      */
/*                  �w�M���, �������M���, ���쥼�M���  */

long ca_calc_payment(p_daccident, p_dappraisal, p_mapp, 
                     p_flag_close_dend, p_flag_close_dbgn,
                     p_mstl_dend, p_mstl_dbgn,
                     p_dbgn, p_mpayment,
                     p_mstl, p_qstl,
                     p_mbgn_outstl, p_qbgn_outstl,
                     p_mend_outstl, p_qend_outstl)
long  p_daccident, p_dappraisal;
long  p_mapp;
int   p_flag_close_dend, p_flag_close_dbgn;
long  p_mstl_dend, p_mstl_dbgn, p_dbgn;
long  *p_mpayment, *p_mstl, *p_qstl,
                   *p_mbgn_outstl, *p_qbgn_outstl,
                   *p_mend_outstl, *p_qend_outstl;
{
   $WHENEVER SQLERROR GOTO errexit;

   *p_mpayment=0;
   *p_mstl=*p_qstl=0;
   *p_mbgn_outstl=*p_qbgn_outstl=0;
   *p_mend_outstl=*p_qend_outstl=0;


   /*-----�w�M�ߴ�----*/
   *p_mstl = p_mstl_dend - p_mstl_dbgn;
   *p_qstl = 1;
   

   /*-----�������M----*/
   if (p_flag_close_dend == 0)  /* ������, ���������M */
   {
       *p_mend_outstl = p_mapp - p_mstl_dend;
       *p_qend_outstl = 1;
   }

   
   /*-----���쥼�M----*/
   if (p_daccident <= p_dbgn && p_dappraisal <= p_dbgn && p_flag_close_dbgn == 0)
   {
       *p_mbgn_outstl = p_mapp - p_mstl_dbgn;
       *p_qbgn_outstl = 1;
   }

   *p_mpayment = *p_mstl + *p_mend_outstl - *p_mbgn_outstl;

   return SUCCESS;

errexit:
   return SQLCODE;
}

/****************************************************************************/
/* �I�� p_date ����,�p��ߥI��l�v�ұo���ߥI�b�B */
/*              (�O���/��~�� �@��)             */
/* return [1]�ߥI�b�B;                           */
/*        [2]�w����(1) OR ������(0)              */

long ca_calc_msettle(p_DB, p_fcard_class, p_iclaim, p_iins, p_ivictim, p_date,
                     p_msettle, p_flag_close)
char  p_DB[BRANCH_ID];
char  p_fcard_class[2];
$char p_iclaim[CLAIM_NUM];
$char p_iins[INSURANCE_TYPE];
$char p_ivictim[CUSTOMER_ID];
$long p_date;
long  *p_msettle;
int   *p_flag_close;
{
   char  DBName[DB_FULL_NAME];
   $char stmt[1024];
   $char fstl[2], flast[2];
   $long mins_stl, mins_proc, mins_salv;


   $WHENEVER SQLERROR GOTO errexit;

   strcpy(DBName,get_full_dbname(p_DB));
   if (DBName[0]=='\0') return M_CM_DB_NOTOPEN;


   /*-----------------*/
   *p_msettle=0;
   *p_flag_close=0;


   if (p_fcard_class[0] == '2')
   {
       sprintf_s(stmt,1024,"SELECT %s FROM %s:%s WHERE %s",
                    "fstl, mins_stl, mins_proc, mins_salv, flast ",
                    DBName,"stl_ins_type",
                    "iclaim = ? AND iins_type = ? AND dgroup <= ?");
       $PREPARE STLINS_CUR FROM $stmt;
       $DECLARE year_stlins_cur CURSOR FOR STLINS_CUR;
       $OPEN year_stlins_cur USING $p_iclaim, $p_iins, $p_date;
       while (1)
       {
          $FETCH year_stlins_cur INTO $fstl, $mins_stl, $mins_proc, 
                                      $mins_salv, $flast;
          if (SQLCODE == SQLNOTFOUND) break;
   
          if (flast[0] == '1')
              *p_flag_close=1;

          if (fstl[0]=='1')
              *p_msettle += (mins_stl + mins_proc - mins_salv);
          else if (fstl[0]=='2')
              *p_msettle -= (mins_stl - mins_proc + mins_salv);
       }
       $CLOSE year_stlins_cur;
       $FREE year_stlins_cur;
   }
   if (p_fcard_class[0] == '1')
   {
       sprintf_s(stmt,1024,"SELECT %s FROM %s:%s WHERE %s %s",
                    "fstl, mins_stl, mins_proc, flast ",
                    DBName,"ca_stl_victim",
                    "iclaim = ? AND iins_item = ? AND ivictim = ? ",
                    " AND dgroup <= ?");
       $PREPARE STLINS_CUR FROM $stmt;
       $DECLARE year_stlvic_cur CURSOR FOR STLINS_CUR;
       $OPEN year_stlvic_cur USING $p_iclaim, $p_iins, $p_ivictim, $p_date;
       while (1)
       {
          $FETCH year_stlvic_cur INTO $fstl, $mins_stl, $mins_proc, $flast;
          if (SQLCODE == SQLNOTFOUND) break;
   
          if (flast[0] == '1')
              *p_flag_close=1;

          if (fstl[0]=='1')
              *p_msettle += (mins_stl + mins_proc);
          else if (fstl[0]=='2')
              *p_msettle -= (mins_stl - mins_proc);
       }
       $CLOSE year_stlvic_cur;
       $FREE year_stlvic_cur;
   }

   return SUCCESS;

errexit:
   return SQLCODE;
}

/*****************************************************************/
/*�s�¨�                                                         */
/*�o�Ӥ� �H�C��15����, �ӫO�_���b�o�Ӥ�@�Ӥ�(31)�������s��    */ 
/*�s�� 1 �¨� 2                                                  */
/*****************************************************************/
ca_check_car_new_old(p_iissue_ym, p_dply_begin, p_icar_flag)
char *p_iissue_ym;
long  p_dply_begin;
char *p_icar_flag; 
{
    long ldply, lissue , lissue_aft;
    long dply_beg;

    strcpy(p_iissue_ym, rtrim(p_iissue_ym));
    lissue = cm_ymd_cdate(p_iissue_ym);
    lissue_aft = lissue + 31;

    /****** �P�_�O�s��(�ӫO�l�� <= �o�Ӥ��@�Ӥ�) ******/
    if (p_dply_begin <= lissue_aft )
        strcpy(p_icar_flag, "1");
    else
        strcpy(p_icar_flag, "2");
}

/********************************************************************/
/* �p�⺡�����    365���k                                          */ 
/*  change                                                          */ 
/********************************************************************/
long ca_calc_365_qfull(p_dbgn, p_dend, p_dply_bgn, p_dply_end,
                       p_qfull)
long p_dbgn, p_dend;
long p_dply_bgn, p_dply_end;
double  *p_qfull;
{
  long dbgn_prev;

  if (p_dbgn <= 0 || p_dend <= 0)
      return M_CA_DATE_ERROR;

  dbgn_prev = p_dbgn - 1;
  
  if (p_dbgn== p_dply_bgn && p_dend == p_dply_end )
      p_qfull=1;
  else if (p_dbgn>= p_dply_bgn && p_dend >= p_dply_end )
      p_qfull = (p_dply_end - p_dbgn + 1)/(p_dply_end -p_dply_bgn +1);
  else if (p_dbgn<= p_dply_bgn && p_dend <= p_dply_end )
      p_qfull = (p_dend - p_dply_bgn  + 1)/(p_dply_end -p_dply_bgn +1);
  else if (p_dbgn>= p_dply_bgn && p_dend <= p_dply_end )
      p_qfull = (p_dend - p_dbgn + 1)/(p_dply_end -p_dply_bgn +1);
    
    
  return SUCCESS;

}

/**********************************************************************/
/* update or insert ca_loss_info                                      */
/**********************************************************************/
long ca_loss_upd_InfoTable_prem(p_dlabel, p_irule, p_imethod,p_dbgn,p_dend,
                                p_ipolicy_13, p_iquota, p_iofficer, p_icar_flag,
                                p_ibrand_14, p_icar_type, p_iresource,p_mcover,
                                p_iins_type, p_mprem, p_cnt, p_qfull, p_mfull)
$char *p_irule, *p_imethod;
$char *p_ipolicy_13, *p_iquota, *p_iofficer, *p_icar_flag;
$char *p_ibrand_14, *p_icar_type, *p_iins_type , *p_iresource;
$long  p_dlabel, p_dbgn, p_dend;
$int   p_mcover;
$double p_mprem;
$double p_qfull, p_mfull; 
$double   p_cnt; 
{
  $WHENEVER SQLERROR GOTO errexit;
#ifdef _880422 
   printf ("p_mprem[%f]\n",p_mprem);
   printf ("cnt[%f]\n",p_cnt );
   printf ("qfull[%f]\n",p_qfull);
   printf ("mfull[%f]\n",p_mfull);
#endif  
       
   strcpy (p_iins_type, rtrim(p_iins_type)); 
   strcpy(p_iresource, rtrim(p_iresource));

   $UPDATE ca_loss_info
       SET qprem = qprem + $p_cnt,
           mprem = mprem + $p_mprem,
           qfull = qfull + $p_qfull,
           mfull = mfull + $p_mfull
     WHERE dlabel     = $p_dlabel
       AND irule      = $p_irule
       AND imethod    = $p_imethod
       AND dbgn       = $p_dbgn
       AND dend       = $p_dend
       AND ipolicy_13 = $p_ipolicy_13
       AND iquota     = $p_iquota
       AND iofficer   = $p_iofficer
       AND icar_flag  = $p_icar_flag
       AND ibrand_14  = $p_ibrand_14
       AND icar_type  = $p_icar_type
       AND iresource  = $p_iresource
       AND mcover     = $p_mcover
       AND iins_type  = $p_iins_type;
    
      
   if (sqlca.sqlerrd[2]==0)
   { 
       $INSERT INTO ca_loss_info
                    (dlabel, irule, imethod, dbgn, dend,
                     ipolicy_13, iquota, iofficer, icar_flag, 
                     ibrand_14, icar_type,  iresource , mcover, 
                     iins_type,
                     qprem, mprem, qfull, mfull)
             VALUES ($p_dlabel, $p_irule, $p_imethod, $p_dbgn, $p_dend,
                     $p_ipolicy_13, $p_iquota, $p_iofficer, $p_icar_flag, 
                     $p_ibrand_14, $p_icar_type, $p_iresource, $p_mcover, 
                     $p_iins_type,
                     $p_cnt , $p_mprem, $p_qfull, $p_mfull);

   }
   
   return SUCCESS;

errexit:
   printf (" ca_loss_upd_InfoTable_prem error [%s]\n", p_iins_type);
   return SQLCODE;

}
 
 
/************* �p�⺡���O�O,365���k ,�������   �u�Φb�ƬG�o�ͨ�
long ca_calc_365_full(p_dbgn, p_dend, p_dply_bgn, p_dply_end,
                      p_mprem, p_cnt , p_mfull, p_qfull)
long p_dbgn, p_dend;
long p_dply_bgn, p_dply_end;
double p_mprem; 
double  p_cnt;
double *p_mfull, *p_qfull;
{
  long dbgn_prev;
  double Mmiddle, Mbegin, Mend;
  double Qmiddle, Qbegin, Qend;
  

  if (p_dbgn <= 0 || p_dend <= 0)
      return M_CA_DATE_ERROR;

  dbgn_prev = p_dbgn - 1;

  Mmiddle=Mbegin=Mend=0;
  Qmiddle=Qbegin=Qend=0;

  if (p_dply_bgn < p_dbgn && p_dply_end >= p_dbgn)
      {
      Mbegin = (double)(p_mprem * ((p_dply_end - dbgn_prev)*2-1) / (p_dply_end - p_dply_bgn) / 2);
      Qbegin = (double)(p_cnt * ((p_dply_end - dbgn_prev)*2-1) / (p_dply_end - p_dply_bgn) / 2);
      }

  if (p_dbgn <= p_dply_bgn && p_dply_bgn <= p_dend)
      {
      Mmiddle = (double)(p_mprem);
      Qmiddle = (double)(p_cnt);
      }
  if (p_dply_end > p_dend)
      {
      Mend = (double)(p_mprem * ((p_dply_end - p_dend)*2-1) / (p_dply_end - p_dply_bgn) / 2);
      Qend = (double)(p_cnt * ((p_dply_end - p_dend)*2-1) / (p_dply_end - p_dply_bgn) / 2);
      }
    
  *p_mfull = Mbegin + Mmiddle - Mend;
  *p_qfull = Qbegin + Qmiddle - Qend;
  return SUCCESS;
}
****************************************************************************/

/*  Update Or Insert ca_loss_info �߮׸��                                  
    p_dlabel            ��Ƽ���(�έp�״�) 
    p_irule             �έp���
    p_imethod           365���k
    p_dbgn, p_dend      �έp�_�� 
    p_ipolicy_13        �O���� 
    p_iquota            �~�Z���
    p_iofficer,         �g��H
    p_icar_flag,        �s�¨� 
    p_ibrand_14,        
    p_icar_type,        ���� 
    p_iresource,        �~�Ȩӷ�  
    p_mcover,           �O�B        
    p_iins_type,        �I��
    p_qclaim,           �z�ߥ��
    p_mstl,             �w�M��
    p_mend_outstl,      ���X���M
    p_mbgn_outstl       �������M                                            */
/****************************************************************************/
long ca_loss_upd_InfoTable_payment(p_dlabel , p_irule, p_imethod,
                                   p_dbgn, p_dend,
                                   p_ipolicy_13, p_iquota,p_iofficer,
                                   p_icar_flag, p_ibrand_14,
                                   p_icar_type, p_iresource, p_mcover,
                                   p_iins_type,
                                   p_qclaim,
                                   p_mstl,
                                   p_mend_outstl,
                                   p_mbgn_outstl)
$long p_dbgn, p_dend,p_dlabel;
$char *p_irule, *p_imethod;
$char *p_ipolicy_13, *p_icar_type, *p_iins_type; 
$char *p_icar_flag, *p_iofficer,*p_iquota, *p_ibrand_14; 
$char *p_iresource; 
$int p_mcover;  
$double p_qclaim;
$double p_mstl;  
$double p_mend_outstl;
$double p_mbgn_outstl;  
{
   $char tmp_iins_type[INSURANCE_TYPE];

   $WHENEVER SQLERROR GOTO errexit;
#ifdef _880422
     printf ("p_qclaim[%f]\n", p_qclaim); 
     printf ("p_mstl[%f]\n", p_mstl);
     printf ("p_mend[%f]\n", p_mend_outstl);
     printf ("p_mbgn[%f]\n", p_mbgn_outstl);
     printf ("ire[%s]\n", p_iresource);
     printf ("mcover[%s]\n", p_mcover);
     printf ("iins_type[%s]\n", tmp_iins_type);
     printf ("p_dlabel[%ld],p_dbgn[%ld],p_dend[%ld]\n",p_dlabel,p_dbgn,p_dend);
     printf ("1\n");
#endif

   /*   ��ƬO�_���� �ǤJ ????????? */
   /*   93,94�αj� ��� ???????? */
   strcpy(p_iins_type,trim(p_iins_type));
   if (strcmp(p_iins_type,"93")==0 || 
       strcmp(p_iins_type,"94")==0 ||
       strcmp(p_iins_type,"95")==0)
       strcpy(tmp_iins_type, "31");
   else
       strcpy(tmp_iins_type, rtrim(p_iins_type));

   strcpy(p_iresource, rtrim(p_iresource));     
  

   $UPDATE ca_loss_info
       SET qclaim      = qclaim  + $p_qclaim,
           mstl        = mstl + $p_mstl,
           mend_outstl = mend_outstl + $p_mend_outstl,
           mbgn_outstl = mbgn_outstl + $p_mbgn_outstl
     WHERE dlabel     = $p_dlabel
       AND irule     = $p_irule
       AND imethod   = $p_imethod
       AND dbgn      = $p_dbgn
       AND dend      = $p_dend
       AND ipolicy_13= $p_ipolicy_13
       AND iquota    = $p_iquota  
       AND iofficer  = $p_iofficer
       AND icar_flag = $p_icar_flag
       AND ibrand_14 = $p_ibrand_14
       AND icar_type = $p_icar_type
       AND iresource = $p_iresource
       AND mcover    = $p_mcover
       AND iins_type = $tmp_iins_type;
   if (sqlca.sqlerrd[2]==0)
   {
       $INSERT INTO ca_loss_info
                    (dlabel , irule, imethod, dbgn, dend,
                     ipolicy_13, iquota, iofficer, icar_flag,
                     ibrand_14, icar_type,iresource, mcover, iins_type,
                     qclaim, mstl,  mend_outstl, mbgn_outstl)
             VALUES ($p_dlabel, $p_irule, $p_imethod, $p_dbgn, $p_dend,
                     $p_ipolicy_13, $p_iquota, $p_iofficer,$p_icar_flag ,
                     $p_ibrand_14, $p_icar_type, $p_iresource, $p_mcover, $tmp_iins_type,
                     $p_qclaim, $p_mstl, $p_mend_outstl, $p_mbgn_outstl);
   }
   return SUCCESS;

errexit:
   printf("sqcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;

}


/*************************************************/
/* �I�� p_date ����,�p��ߥI��l�v�ұo���ߥI�b�B */
/*              (�O���/��~�� �@��)             */
/* return [1]�ߥI�b�B;                           */
/*        [2]�w����(1) OR ������(0)              */
/* for info only                                 */
/*************************************************/

long ca_calc_info_msettle(p_DB, p_fcard_class, p_iclaim, p_iins, p_ivictim,
                          p_date, p_msettle, p_flag_close)
char    p_DB[BRANCH_ID];
char    p_fcard_class[2];
$char   *p_iclaim;
$char   *p_iins;
$char   *p_ivictim;
$long   p_date;
double  *p_msettle;
int     *p_flag_close;
{
   char  DBName[DB_FULL_NAME];
   $char stmt[1024];
   $char fstl[2], flast[2],fflast[2];
   $long mins_stl, mins_proc, mins_salv, mstl_health;
   $long dgroup;

   $WHENEVER SQLERROR GOTO errexit;

   strcpy(DBName,get_full_dbname(p_DB));
   if (DBName[0]=='\0') return M_CM_DB_NOTOPEN;

   /*** printf ("DBName[%s]\n",DBName); ***/

   strcpy (p_iins, rtrim(p_iins));
   strcpy (p_iclaim, rtrim(p_iclaim));
   
   /*** printf ("p_iins[%s]\n",p_iins); ***/
   /*-----------------*/
   *p_msettle=0;
   *p_flag_close=0;
   flast[0]='\0';

   if (p_fcard_class[0] == '2')
   {
       /*** printf ("[%s][%s][%d]\n",p_iclaim,p_iins,p_date); ***/
         
       sprintf_s(stmt,1024,"SELECT %s FROM %s:%s WHERE %s",
                    "fstl, mins_stl, mins_proc, mins_salv, flast , dgroup",
                    DBName,"stl_ins_type",
                    "iclaim = ? AND iins_type = ?  AND dgroup <= ?"); 

       /*** printf ("[%s]\n",stmt); ***/

       $PREPARE STLINS_CUR FROM $stmt;
       $DECLARE year_ins_info_cur CURSOR FOR STLINS_CUR;
       $OPEN year_ins_info_cur USING $p_iclaim, $p_iins, $p_date; 

       /*** printf ("after [%s], [%s]\n", p_iclaim, p_iins); ***/

       for (;;)
       {
          $FETCH year_ins_info_cur INTO $fstl, $mins_stl, $mins_proc,
                                        $mins_salv, $flast, $dgroup;
          /*** printf("sqlerrd[%d]\n",sqlca.sqlerrd[2]); ***/

          if (SQLCODE == SQLNOTFOUND) break;
          /*** printf("----->SQLCODE[%d]\n", SQLCODE); ***/
          /*** printf("flast--->[%c]\n",flast[0]); ***/
           
           if (flast[0] == '1')
           {
              *p_flag_close=1;
              /*** printf("p_flag_close[%d]\n",*p_flag_close); ***/
           }

           if (fstl[0]=='1')
               *p_msettle += (double)(mins_stl + mins_proc - mins_salv);
           else if (fstl[0]=='2')
               *p_msettle -= (double)(mins_stl - mins_proc + mins_salv);
        
       }
       $CLOSE year_ins_info_cur;
       $FREE year_ins_info_cur;
   }
   if (p_fcard_class[0] == '1')
   {
       sprintf_s(stmt,1024,"SELECT %s FROM %s:%s WHERE %s %s",
                    "fstl, mins_stl, mins_proc, mstl_health, flast ",
                    DBName,"ca_stl_victim",
                    "iclaim = ? AND iins_item = ? AND ivictim = ? ",
                    " AND dgroup <= ?");
       $PREPARE STLINS_CUR FROM $stmt;
       $DECLARE year_vic_info_cur CURSOR FOR STLINS_CUR;

       $OPEN year_vic_info_cur USING $p_iclaim, $p_iins, $p_ivictim, $p_date;
       fflast[0] = '\0';
       while (1)
       {
          $FETCH year_vic_info_cur INTO $fstl, $mins_stl, $mins_proc, $mstl_health, $flast;
          if (SQLCODE == SQLNOTFOUND) break;

          if (flast[0] == '2')
              *p_flag_close=1;

          if (flast[0] == '1')
              strcpy(fflast,"Y");

          if (flast[0] == '1' && p_iins[0] == 'B')
              *p_flag_close=1;

          if (flast[0] == '1' && p_iins[0] == 'C')
              *p_flag_close=1;

          if (fstl[0]=='1')
              *p_msettle += (double)(mins_stl + mins_proc + mstl_health);
          else if (fstl[0]=='2')
              *p_msettle -= (double)(mins_stl - mins_proc + mstl_health);
       }
       $CLOSE year_vic_info_cur;
       $FREE year_vic_info_cur;

       /*******�K�ߵ���***********/
       if (*p_msettle == 0 && fflast[0] == 'Y')
            *p_flag_close = 1;
   }


#ifdef _880422
   printf ("msettle p_date[%d],p_msettle[%f]\n",p_date, *p_msettle);
#endif 
   return SUCCESS;

errexit:
   return SQLCODE;
}

/****************************************************************************/
/* �p��ߴڪ��B (�O���/��~�� �@��)                      */
/* return �ߴڪ��B, �w�M�ߴ�, �������M,     ���쥼�M      */
/*                  �w�M���, �������M���, ���쥼�M���  */
/* info                                                   */
long ca_calc_info_payment(p_daccident, p_dappraisal, p_mapp,
                          p_flag_close_dend, p_flag_close_dbgn,
                          p_mstl_dend, p_mstl_dbgn,
                          p_dbgn, 
                          p_mpayment,
                          p_mstl, 
                          p_mbgn_outstl,
                          p_mend_outstl)
long  p_daccident, p_dappraisal;
double  p_mapp;
int   p_flag_close_dend, p_flag_close_dbgn;
long p_dbgn; 
double p_mstl_dend, p_mstl_dbgn;
double *p_mpayment, *p_mstl, 
       *p_mbgn_outstl, 
       *p_mend_outstl;
{
   $WHENEVER SQLERROR GOTO errexit;

   *p_mpayment=0;
   *p_mstl=0;
   *p_mbgn_outstl=0;
   *p_mend_outstl=0;


   /*-----�����w�M�ߴ�----*/
   *p_mstl = p_mstl_dend - p_mstl_dbgn;

   /*-----�������M----*/
   if (p_flag_close_dend == 0)  /* ������, ���������M */
   {
       *p_mend_outstl = p_mapp - p_mstl_dend;
       if (*p_mend_outstl < 0)
          {
           *p_mend_outstl = 0;
          } 
   }

   /*-----���쥼�M----*/
   #ifdef _880422
      printf ("p_dacc[%d], p_dbgn[%d], p_dapp[%d]\n", p_daccident, p_dbgn, p_dappraisal);
   #endif

   if (p_daccident <= p_dbgn && p_dappraisal <= p_dbgn && p_flag_close_dbgn == 0 )
   {
       #ifdef _880422
              printf ("kldebug in payment \n");
       #endif
       *p_mbgn_outstl = p_mapp - p_mstl_dbgn;
       if (*p_mbgn_outstl < 0)
       {
           *p_mbgn_outstl = 0;
       }
   }

   *p_mpayment = *p_mstl + *p_mend_outstl - *p_mbgn_outstl;

   #ifdef _880422
   printf("### ca_loss_fun:p_mpayment[%f],p_mstl[%f],p_mend_outstl[%f],p_mbgn_outstl[%f]\n",
                           *p_mpayment  , *p_mstl  , *p_mend_outstl  , *p_mbgn_outstl);
   #endif

   return SUCCESS;

errexit:
   return SQLCODE;
}

long ca_loss_ins_PlyTmpTable(p_dbgn, p_dend , p_ipolicy, p_endorse,
                             p_dply_bgn, p_dply_end, p_iissue_ym,p_icar_flag,
                             p_iquota,p_iofficer, p_ibrand14, p_icar_type,
                             p_iins_type, p_cnt, p_tmp_prem, p_qfull, p_mfull)

$long    p_dbgn, p_dend;  
$char    *p_ipolicy, *p_endorse;
$long    p_dply_bgn, p_dply_end;
$char    *p_iissue_ym,*p_icar_flag;
$char    *p_iquota,*p_iofficer, *p_ibrand14, *p_icar_type;
$char    *p_iins_type; 
$double   p_cnt, p_tmp_prem, p_qfull, p_mfull;
{
       $WHENEVER SQLERROR GOTO errexit; 
#ifdef _880422 
  
       printf("dbgn[%d] dend[%d] , ipolicy[%s], endorse[%s]\n", 
                p_dbgn, p_dend , p_ipolicy, p_endorse);
       printf("dply_bgn[%d], dply_end[%d],iissue_ym[%s],icar_flag[%s]\n", p_dply_bgn, p_dply_end, p_iissue_ym,p_icar_flag);
       printf ("iquota[%s],iofficer[%s], ibrand14[%s], icar_type[%s]\n",
                       p_iquota,p_iofficer, p_ibrand14, p_icar_type);
       printf ("iins_type[%s], cnt[%f], tmp_prem[%f], qfull[%f]\n",
                       p_iins_type, p_cnt, p_tmp_prem, p_qfull);
       printf ("p_mfull[%f]\n" ,p_mfull);
#endif      
       strncpy(p_iissue_ym, p_iissue_ym, 5);
       p_iissue_ym[5]='\0';
       $INSERT INTO ca_loss_ply_tmp
                       (dbgn, dend , ipolicy, iendorse,
                       dply_begin, dply_end, iissue_ym,icar_flag,
                       iquota,iofficer, ibrand_14, icar_type,
                       iins_type, qprem, mprem, qfull, mfull)
               VALUES ($p_dbgn, $p_dend , $p_ipolicy, $p_endorse,
                       $p_dply_bgn, $p_dply_end, $p_iissue_ym,$p_icar_flag,
                       $p_iquota,$p_iofficer, $p_ibrand14, $p_icar_type,
                       $p_iins_type, $p_cnt, $p_tmp_prem, $p_qfull, $p_mfull);
   

   return SUCCESS;

errexit:
   printf ("INSERT INTO ca_loss_ply_tmp ERROR\n");
   printf("<ca_ins_ply_tmp> sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}
    
long ca_loss_ins_ClmTmpTable(p_dbgn,p_dend,p_iclaim,
                             p_iissue_ym, p_icar_flag,
                             p_iquota,p_iofficer,
                             p_ibrand14, p_icar_type,
                             p_dappraisal,
                             p_iins_type,
                             p_ivictim,
                             p_app,
                             p_mstl_dend,
                             p_flend,
                             p_mstl_dbgn ,
                             p_flbgn,
                             p_mstl,
                             p_mbgn_outstl  ,
                             p_mend_outstl)
$long   p_dbgn,p_dend;
$char   *p_iclaim;
$char   *p_iissue_ym, *p_icar_flag;
$char   *p_iquota,*p_iofficer;
$char   *p_ibrand14, *p_icar_type;
$long   p_dappraisal;
$char   *p_iins_type, *p_ivictim;
$int    p_flend, p_flbgn;
$double p_app, p_mstl_dend,p_mstl_dbgn,p_mstl,p_mbgn_outstl, p_mend_outstl;
{
       $WHENEVER SQLERROR GOTO errexit; 
       strncpy(p_iissue_ym, p_iissue_ym, 5);
       p_iissue_ym[5]='\0';
       $INSERT INTO ca_loss_clm_tmp
               VALUES ($p_dbgn,$p_dend,$p_iclaim, $p_iissue_ym, $p_icar_flag,
                       $p_iquota,$p_iofficer, $p_ibrand14, $p_icar_type,
                       $p_dappraisal, $p_iins_type, $p_ivictim,
                       $p_app, $p_mstl_dend, $p_flend, $p_mstl_dbgn,
                       $p_flbgn, $p_mstl, $p_mbgn_outstl, $p_mend_outstl);
   return SUCCESS;
errexit:
   printf ("INSERT INTO ca_loss_clm_tmp ERROR\n");
   printf("<ca_ins_clm_tmp> sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}
 
long ca_loss_get_edr_mdamage(p_ipolicy, p_iins_type, p_dendorse, p_mdamage_cover) 
$char *p_ipolicy, *p_iins_type;
$long p_dendorse;
$int *p_mdamage_cover;  
{  
       $int mdamage_cover;
 
       $WHENEVER SQLERROR GOTO errexit; 
      
       strcpy (p_iins_type,rtrim(p_iins_type)); 
       printf ("[%s], iins_type[%s], %d\n", p_ipolicy, p_iins_type , p_dendorse);

      
       $SELECT mdamage_cover
          INTO $mdamage_cover
          FROM ply_ins_type_hist
         WHERE ipolicy= $p_ipolicy
           AND (fedr_status IS NOT NULL  AND  fedr_status <> " ")
           AND iins_type =$p_iins_type
           AND dendorse =$p_dendorse ;
 
       *p_mdamage_cover= mdamage_cover;

       return SUCCESS;
 
errexit:
   printf (" ca_loss_get_edr_mdamage \n");
   return SQLCODE;
}

long ca_calc_365_full(p_dbgn, p_dend, p_dply_bgn, p_dply_end,
                      p_mprem, p_cnt , p_mfull, p_qfull, p_leap_flag)
long    p_dbgn, p_dend;/**** �έp�_����� ****/
long    p_dply_bgn, p_dply_end;   /**** �O���ͮĤΨ����� ****/
double  p_mprem;/**** �O���O�I�O ****/
double  p_cnt;
double  *p_mfull, *p_qfull;
long    p_leap_flag;
{
     long    dbgn_prev;
     double  Mmiddle, Mbegin, Mend;
     double  Qmiddle, Qbegin, Qend;
     long    Qyear;

     if (p_dbgn <= 0 || p_dend <= 0)
        return M_CA_DATE_ERROR;

     dbgn_prev = p_dbgn - 1;

     Mmiddle = Mbegin = Mend = 0;
     Qmiddle = Qbegin = Qend = 0;

     if (p_leap_flag == 1)   /*** �O�I�������|�~�G2��29�� ***/
     {
         Qyear = 366;
     }
     else
     {
         Qyear = 365;
     }

     /***** ���쥼�����O�O�Υ�� *****/
     if (p_dply_bgn < p_dbgn && p_dply_end >= p_dbgn)
     {
         Mbegin = (double)(p_mprem * ((p_dply_end - dbgn_prev)*2-1) / (p_dply_end - p_dply_bgn) / 2);
         Qbegin = (double)(p_cnt   * ((p_dply_end - dbgn_prev)*2-1) / (Qyear) / 2);
     }

     /***** �����O�O�Υ�� *****/
     if (p_dbgn <= p_dply_bgn && p_dply_bgn <= p_dend)
     {
         Mmiddle = (double)(p_mprem);
         Qmiddle = (double)(p_cnt * (p_dply_end - p_dply_bgn) / (Qyear));
     }

     /***** �����������O�O�Υ�� *****/
     if ((p_dply_end > p_dend) && (p_dply_bgn <= p_dend))
     {
         Mend = (double)(p_mprem * ((p_dply_end - p_dend)*2-1) / (p_dply_end - p_dply_bgn) / 2);
         Qend = (double)(p_cnt   * ((p_dply_end - p_dend)*2-1) / (Qyear) / 2);
     }

     /*** �����O�O = ���쥼�����O�O + ���������O�O - �����������O�O ***/
     *p_mfull = Mbegin + Mmiddle - Mend;

     /*** ������� = ���쥼������� + ����������� - ������������� ***/
     *p_qfull = Qbegin + Qmiddle - Qend;

     return SUCCESS;
}

long check_leap_year(p_dply_bgn, p_dply_end)
long p_dply_bgn, p_dply_end;   /**** �O��ͮĤΨ����� ****/
{
     long     Leap_flag;
     char     ply_yy[4],ply_mm[3],ply_dd[3];
     int      x1, x2, x3, x4;
     int      mod_year;
     long     leap_year, leap_year_ch, leap_year_flag;
     char     Cleap_year[13];
     long     lyyyy;

     cm_long_split_3ymd(p_dply_bgn , ply_yy , ply_mm , ply_dd);

     mod_year = (atoi(ply_yy)+1911) % 4;
     if (mod_year != 0)
     {
         x4 = 4 - mod_year;
     }
     else
     {
         x4 = 0;
     }
     leap_year_ch = atoi(ply_yy) + x4;

     lyyyy = 1911 + leap_year_ch;
     x1 = lyyyy % 4;
     x2 = lyyyy % 100;
     x3 = lyyyy % 400;

     if (x1==0)
         leap_year_flag=1;
     if (x2==0)
         leap_year_flag=0;
     if (x3==0)
         leap_year_flag=1;

     if (leap_year_flag == 0)
     {
         leap_year_ch = leap_year_ch + 4;

         lyyyy = 1911 + leap_year_ch;
         x1 = lyyyy % 4;
         x2 = lyyyy % 100;
         x3 = lyyyy % 400;

         if (x1==0)
             leap_year_flag=1;
         if (x2==0)
             leap_year_flag=0;
         if (x3==0)
             leap_year_flag=1;
     }

     if (leap_year_flag == 1)
     {
         strcpy(Cleap_year, ltoa(leap_year_ch));
         strcat(Cleap_year, "/02/29");
         leap_year = cm_ymd_cdate(Cleap_year);

         if (p_dply_bgn <= leap_year && p_dply_end >= leap_year)
             Leap_flag = 1;
         else
             Leap_flag = 0;
     }
     else
     {
         Leap_flag = 0;
     }

     return Leap_flag;
}

