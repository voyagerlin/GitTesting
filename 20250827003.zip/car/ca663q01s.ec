/**********************************************************************/
/*   program id   : ca663q01s.ec                                      */
/*   program name : �q����O��ƥ洫-�N�ӻȦ�                         */
/*   runbatch 00 930268 car663 P 2 '11210' 'R41010T'                  */
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <time.h>
#include <math.h>
#include "api_xsrv.h"
$include datetime.h;

/*--------------------------------------------------------------------*/
$char userid[11];
char  msgbuf[1000],sApHome[30];
$char DBName[05], stmt[5000];
char  outputf[N_FILE+1] ;
DBinfo  *list;
int   count_db;
$char   fname[100],fnameM[100];
$char   nattachment[201];
$char   filename[150];
$char	ftitle[1024], ftitleM[1024];
int     flen;
FILE    *fp;
$char    sDate1[11], sDate2[11], sMain_iroute[21], mmsg[100];
char    sYY[4], sMM[3], sYYMM[6];
$int    iyyyy;
/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
    int rc;

    time_t tstart, tstop;
    float tused=0;

    batchinit();
    strcpy(DBName,  isNULLstr(argv[1]));
    strcpy(userid,  isNULLstr(argv[2]));
    strcpy(sYYMM,  isNULLstr(argv[3]));          /* ��O�~��(CYYMM)*/
    strcpy(sMain_iroute, isNULLstr(argv[4]));    /* �q���N��*/
    strcpy(outputf, isNULLstr(argv[5]));

    strncpy(sYY, sYYMM,3);
    sYY[3]='\0';
    iyyyy = atoi(sYY)+1911;
    strncpy(sMM, &sYYMM[3],2);
    sMM[2]='\0';



    /***********************************************/
    time(&tstart);  /* �p�ɶ}�l */

    /***********************************************/
    printf("1.car663_get_db() \n");
    rc = car663_get_db();
    if (rc != M_CM_OK) {
        printf("error on car663_get_db\n");
        return rc;
    }

    printf("2.car663_init_data() \n");
    rc = car663_init_data();
    if (rc != M_CM_OK) {
        printf("error on car663_init_data\n");
        return rc;
    }


    rc = car663_ply_data();
    if (rc != M_CM_OK) {
        printf("error on car663_ply_data()\n");
        return rc;
    }


    /* ���s�ɮ� */
    printf("4.car663_build() \n");
    rc=car663_build();
    if (rc != M_CM_OK) {
        printf("error on car663_build\n");
        return rc;
    }



    printf("[car663]:process ok!\n");
    /***********************************************/
        time(&tstop);  /* �p�ɵ��� */
        tused=difftime(tstop, tstart);
        printf("������� = %f  ��\n", tused);
    /***********************************************/

}

/*--------------------------------------------------------------------*/
long car663_get_db()
{
    int	rc;

    if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
    }

    if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
    {
        EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
        return M_CM_NOT_DBLIST;

    }

    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }

    return M_CM_OK;
}
/*--------------------------------------------------------------------*/
long car663_init_data()
{
    $whenever sqlerror goto errexit;


    $create temp table tb_car663 (
        icompany        char(10) default '217', -- 1 �O�I���q�N�X
        iins_code       char(20),       -- 2 �I�ة���(��:6621M (�����j��))
        iestimate       char(20),       -- 3 ��O�����渹,������O��e�O�渹
        ipolicy         char(30),       -- 4 �e�O�渹
        fstauts         char(1),        -- 5 ���w��O���A:Y�۰���O,N�ڵ���O(�֫O),E�ڵ���O(�D�֫O),U�D�۰���O
        dply_begin      char(8),        -- 6 �s�~�׫O��_��(YYYYMMDD)
        dply_end        char(8),        -- 7 �s�~�׫O�樴��(YYYYMMDD)
        napplicant      char(100),      -- 8 �n�O�H�m�W
        iapplicant      char(20),       -- 9 �n�O�HID
		nassurand       char(100),      -- 10 �Q�O�H�m�W
		iassurand       char(20),       -- 11 �Q�O�HID
		ibank_ex        char(7) default '7777',       -- 12 ����N��,�T�w��777
        isales          char(10) default 'NCB0000001',  -- 13 �O�I�~�ȭ��N�X,�T�wNCB0000001
        mprem           decimal(14,4) default 0,  -- 14 �O�I�O (�������J�p��0)
        discount        decimal(14,4) default 0,  -- 15 �馩���B (�L��� 0)
        fcomm           decimal(14,4),  -- 16 �����v(���N�I�T�w7.27,�j���I0)
        mcomm           decimal(14,4),  -- 17 ����(����O)(���N�I0,�j���I:�T��110,����1�~65,2�~45)
        mservice        decimal(14,4),  -- 18 �A�ȶO
        sflag           char(50) default ' ', --19 ���O
        referee         char(10) default ' ', --20 ���ˤHID
        itransno        char(20) default ' ', --21 �P�b�s��(3017�}�Y)
        mTotal          decimal(14,4),        --22 ú�O���B
        nproject        char(10) default ' ', --23 �M�ץN��
        itag            char(30) default ' ', --24 ����
        fcharge         char(1)  default 'N', --25 �O�_��ĳ����(Y�O N�_)
        sreason         char(100) default ' ', -- 26 ĳ����]
        dply_bgn_pre    char(6),              -- 27 ��O�������
        mamt            decimal(10,0),        -- 28 �O�I���B
        spayway         char(1) default '5',  -- 29 ú�O�覡(1�k�H�״� 2���O�� 3��b�� 4 ��ú�� 5�H�Υd 6��L)
        szip            char(5) default ' ',  -- 30 �n�O�H�l���ϸ�
        saddress        char(90) default ' ' , -- 31 �n�O�H�a�}
        stel            char(20) default ' '  -- 32 �n�O�H�q��
    ) with no log;

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
/*  */
long car663_ply_data()
{
    int	rc;
    $char   sTmpSQL[2000];
    $int    icount=0;


    $whenever sqlerror goto errexit;

    printf("--- car663_ply_data start -------- \n");
    icount = 0;

    sprintf(sDate1,"%s/01/%d",sMM,iyyyy);
    printf("---- sDate1=[%s]\n",sDate1);

    $select first 1 date($sDate1), last_day(date($sDate1))
       into $sDate1, $sDate2
       from car_code
      where 1=1;
    printf("---- sDate1=[%s] sDate2=[%s]\n",sDate1,sDate2);

    /* ��O�J�p�ɥi�H��쪺 */
    $insert into tb_car663
     SELECT  '217',
             decode(a.fcard_class,1,'66','60')||trim(c.iins_type)||
       		      CASE WHEN a.icar_type IN ('01','02','32','34') THEN 'M' ELSE 'C' END ,
       	     decode(b.fuw_status_ori,500,b.iestimate_ori,b.ipolicy),
       	     b.ipolicy, decode(b.fuw_status_ori,500,'U','N'),
       	     to_char(b.dply_begin, '%Y%m%d'), to_char(b.dply_end, '%Y%m%d'),
       	     b.napplicant, b.iapplicant, b.nassured, b.ilicense, '7777',
       	     'NCB0000001', decode(b.fuw_status_ori,500,c.ori_premium,0), 0, 0, 0,
       	     0, ' ', ' ', decode(b.fuw_status_ori,500,b.itransno_ori,' '),
       	     decode(b.fuw_status_ori,500,b.comp_prem+v_ori_prem,0), ' ', b.itag,
       	     'N', ' ', to_char(b.dply_begin, '%Y%m'), c.mdamage_cover, '5',
		     d.apayment_zip, d.apayment, d.itel_appl
        FROM ply_relation a, policy d , policy_302f b, ply_ins_type_302 c
       WHERE 1=1
         AND a.ipolicy = b.ipolicy
         AND a.ipolicy = d.ipolicy
         AND b.ipolicy = c.ipolicy
         AND a.iofficer = 'R41010T'
         AND a.dply_end BETWEEN  $sDate1 AND $sDate2;

printf("------------ 1 ----------------- \n");

    /* ��O�J�p�ɧ䤣�쪺 */
    $insert into tb_car663
     SELECT  '217',
            decode(a.fcard_class,1,'66','60')||trim(c.iins_type)||
       		    CASE WHEN a.icar_type IN ('01','02','32','34') THEN 'M' ELSE 'C' END ,
       	    a.ipolicy,	b.ipolicy, 'E', to_char(a.dply_end, '%Y%m%d'),
       	    to_char(add_months(a.dply_end,12), '%Y%m%d'), b.napplicant,
       	    b.iapplicant, b.nassured, b.ilicense, '7777', 'NCB0000001', 0, 0,
       	    0, 0, 0, ' ', ' ', ' ', 0, ' ', b.itag, 'N', ' ', to_char(a.dply_end, '%Y%m'),
       	    c.mdamage_cover, '5', b.apayment_zip, b.apayment, b.itel_appl
       FROM ply_relation a, policy b , ply_ins_type c
      WHERE 1=1
        AND a.ipolicy = b.ipolicy
        AND b.ipolicy = c.ipolicy
        AND a.iofficer = 'R41010T'
        AND a.dply_end BETWEEN  $sDate1 AND $sDate2
        AND a.ipolicy NOT IN ( SELECT UNIQUE ipolicy FROM tb_car663);

printf("------------ 1 ----------------- \n");


    $select count(*) into $icount
        from tb_car663 ;

    printf("�@ %d ��\n",icount);

	return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* -------------------------------------------------------------------------------- */
long car663_build()
{
	int	rc;

	$char icompany[11], iins_code[21], iestimate[21], ipolicy[31], fstauts[2],
          dply_begin[9], dply_end[9], napplicant[101], iapplicant[21], nassurand[101],
		  iassurand[21], ibank_ex[8], isales[11], sflag[51], referee[11],
		  itransno[21], nproject[11], itag[31], fcharge[2], sreason[101],
		  dply_bgn_pre[7], spayway[2], szip[6], saddress[91], stel[21],
		  fp2[1000], sfcomm[5];
    $char stmt2[2000];
    $double mprem, discount, fcomm, mcomm, mservice, mTotal, mamt;


	$whenever sqlerror goto errexit;

    sprintf(stmt2, "select * from tb_car663 where 1=1");
    $prepare pre1 from $stmt2;
    $declare cur_dtl cursor for pre1;

    memset(fname,0x00,sizeof(fname));
	memset(filename,0x00,sizeof(filename));

	$SELECT FIRST 1 '217RO'||to_char(today,'%Y%m%d')||'001.txt' into $fname
       FROM car_code where 1=1;

    strcpy(fname, trim(fname));
    sprintf(filename,"%s/rptftp/next_bank/%s",sApHome,fname);

    printf("filename[%s]\n",filename);

	fp=fopen(filename,"w");

	fprintf(fp,ftitle);

	$open cur_dtl ;
	while(1)
	{
	    $fetch cur_dtl
		  into $icompany, $iins_code, $iestimate, $ipolicy, $fstauts,
		       $dply_begin, $dply_end, $napplicant, $iapplicant, $nassurand,
		       $iassurand, $ibank_ex, $isales, $mprem, $discount,
               $fcomm, $mcomm, $mservice, $sflag, $referee,
               $itransno, $mTotal, $nproject, $itag, $fcharge,
               $sreason, $dply_bgn_pre, $mamt, $spayway, $szip,
               $saddress, $stel;
        if (SQLCODE==SQLNOTFOUND) break;

		strcpy(icompany, trim(icompany));
		strcpy(iins_code, trim(iins_code));
		strcpy(iestimate, trim(iestimate));
		strcpy(ipolicy, trim(ipolicy));
		strcpy(fstauts, trim(fstauts));
		strcpy(dply_begin, trim(dply_begin));
		strcpy(dply_end, trim(dply_end));
		strcpy(napplicant, trim(napplicant));
		strcpy(iapplicant, trim(iapplicant));
		strcpy(nassurand, trim(nassurand));
		strcpy(iassurand, trim(iassurand));
		strcpy(ibank_ex, trim(ibank_ex));
		strcpy(isales, trim(isales));
		strcpy(sflag, " ");
		strcpy(referee," ");
        strcpy(itransno, trim(itransno));
        strcpy(nproject, " " );
        strcpy(itag, trim(itag));
        strcpy(fcharge, trim(fcharge));
        strcpy(sreason, trim(" "));
        strcpy(dply_bgn_pre, trim(dply_bgn_pre));
        strcpy(spayway, trim(spayway));
        strcpy(szip,trim(szip));
        strcpy(saddress, trim(saddress));
        strcpy(stel, trim(stel));

        if (fcomm > 0)
            sprintf(sfcomm,"%.2f",fcomm);
        else
            strcpy(sfcomm,"0");

        sprintf(fp2,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%.0f\t%.0f\t%s\t%.0f\t%.0f\t%s\t%s\t%s\t%.0f\t%s\t%s\t%s\t%s\t%s\t%.0f\t%s\t%s\t%s\t%s\t\n",
                    icompany, iins_code, iestimate, ipolicy, fstauts,
                    dply_begin, dply_end, napplicant, iapplicant, nassurand,
                    iassurand, ibank_ex, isales, (double)mprem, (double)discount,
                    sfcomm, (double)mcomm, (double)mservice, sflag, referee,
                    itransno, (double)mTotal, nproject, itag, fcharge,
                    sreason, dply_bgn_pre, (double)mamt, spayway, szip,
                    saddress, stel);
        printf("fp2=[%s]\n",fp2);

        fprintf(fp,"%s",fp2);


    }
    $close cur_dtl;
    fclose(fp);
    $free  cur_dtl;

    sprintf(mmsg,"��Ʋ��s����");
    EWRITE(userid,M_CM_OK,mmsg);

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/* ------------------------------------------------------------------------- */
