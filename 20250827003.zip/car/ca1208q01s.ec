/************************************************************************/
/*                                                                      */   
/*   program id   : ca1208q01s.ec                                       */
/*   program name : ���T�ɨ��O�Ω��Ӫ�                                  */
/*   date written : 2020/09/11                                          */
/*   author       : neo                                                 */
/************************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
#include "safeclib.h"
/*--------------------------------------------------------------------*/
$char DBName[05],userid[11],  dbgn[11] , dend[11];

char  msgbuf[2048], sApHome[30], rpt_type[2], getfile[101];
char  v_sMsg[1024], outputf[N_FILE+1];
int   count_db , i;
DBinfo  *list;
FILE    *fp;
$int k;


/*--------------------------------------------------------------------*/

main(argc,argv)
int  argc;
char **argv;
{  
   
   int rc;
   batchinit();
   strcpy(DBName,   		isNULLstr(argv[1]));
   strcpy(userid,  	 	isNULLstr(argv[2]));
   strcpy(dbgn,    		isNULLstr(argv[3]));  /* ���z����϶�-�}�l */
   strcpy(dend,     		isNULLstr(argv[4]));  /* ���z����϶�-���� */
   strcpy(outputf,  		isNULLstr(argv[5]));  


   printf("outputf:s\n",outputf);
	printf("--1.car1208_get_db ------ \n");
	rc = car1208_get_db();
	if (rc != M_CM_OK) {
		EWRITE(userid,rc,msgbuf);
		return rc;
	}
	
    
        printf("--2.car1208_init_data ------ \n");
        rc = car1208_init_data();
        if (rc != M_CM_OK) {
            printf("error on car1208_init_data\n");
    		EWRITE(userid,rc,"�إ� temp table ���~!");
    		return rc;
        }
    
        printf("--3.car1208_query_detail ------ \n");
    	rc = car1208_query_detail();
        if (rc != M_CM_OK) {
        printf("error on car1208_query_detail\n");
    		EWRITE(userid, rc, "���̷s�߮׸��X���~");
    		return rc;
    	}
    	 
    	printf("--4.car1208_print_detail ------ \n");
        rc = car1208_print_detail();
        if (rc != M_CM_OK) {
         printf("error on car1208_print_detail\n");
         EWRITE(userid, rc, "���s�������Ӧ��~!");
         return rc;
        }
       
    
			
    return rc;

}
/******************************************************************************/
long car1208_get_db()
{
	int return_code;
	
	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == False) {
		strcpy(msgbuf,"��Ʈw�L�k�}��");
		return M_CM_DB_NOTOPEN;
	}

	return_code = getApHome(sApHome);
	if (return_code < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		return return_code;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
       if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
          return M_CM_NOT_DBLIST;
	}

	return M_CM_OK;

errexit:
   printf("--car1208_get_db-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/******************************************************************************/
long car1208_init_data()
{   
    $WHENEVER SQLERROR GOTO errexit;

    $create temp table tb_ca12081
    (
       		iclaim 			varchar(20),   				-- �z�߮׸�
       		iclaimCode		char(5),   				-- �N�X
       		nunit			char(12),   				-- ���
		dclose 			date,    				-- �鵲��
		dgroup 			date,    				-- �J�p��
		fstl			char(1),				-- �߮שʽ�
		iclose_type     	char(5),       				-- �߮צ���
		istl_obj       		char(12),	       			-- ��H�N��
		istl_obj_ext      	char(2),	       			-- ��H����
		nstl_obj       		varchar(100),	       			-- ��H�W��
		dspeed       		char(2),	       			-- �ߴڳt��
		mpayment       		int	       				-- ���B
		
    )with no log;
	  
    return M_CM_OK;

errexit:
    printf("--car1208_init_data-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car1208_query_detail()
{
    int	    rc;
    $char   stmt1[4000],stmt2[100];
    $int    icnt;
   
    $WHENEVER SQLERROR GOTO errexit;
	
	
	printf("dbgn : %s \n",dbgn);
	printf("dend : %s \n",dend);
	 
	
    for(k=0 ; k<count_db ; k++){
        sprintf_s(stmt1,4000,
           "insert into tb_ca12081 \
           select a.iclose , a.iclose[1,3] , c.nchi_abv , a.dclose , a.dgroup , a.fstl , a.iclose_type , \
		  a.istl_obj , a.istl_obj_ext , a.nstl_obj , a.dspeed , b.mpayment  \
	     FROM %s:ao_stl_obj_close a  , %s:payment b , sysdb:branch c \
	    WHERE a.dgroup >= '%s' \
	      AND a.dgroup <= '%s' \
	      AND a.dpay is null \
	      AND (a.dspeed='8'   or a.istl_obj matches '????SF' ) \
	      AND a.iclose        =  b.iclaim \
	      AND a.fstl          =  b.fstl \
	      AND a.iclose_type   =  CAST(b.iclose_type as CHAR(5)) \
	      AND a.istl_obj      =  b.ipayment \
	      AND a.icls_dept     =  c.ibranch \
	      AND a.istl_obj_ext  =  b.ifpce_id_ext" ,   list[k].dbname , list[k].dbname , dbgn , dend );
	      
        printf("stmt1=[%s]\n",stmt1);
        $PREPARE pre_A1 FROM $stmt1;
        $EXECUTE pre_A1;
    }
     
    return M_CM_OK;
  
errexit:
    printf("--car1208_query_detail-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* ------------------------------------------------------------------------- */
long car1208_print_detail()
{
    int     rc;
    char    sfilename[128],stitle[2048],stmt[2048];
    $int    icnt;

    $WHENEVER SQLERROR GOTO errexit;
    
    strcpy(sfilename,"���T�ɨ��O�Ω��Ӫ�");
    strcpy(stitle,"�{���N��:car12081\t");
    strcat(stitle,sfilename);
    strcat(stitle,"\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");

    
    icnt = 0;
    $select count(*) into $icnt
      from tb_ca12081;
	  printf("icnt:%d\n",icnt);
    if (icnt == 0) 
    {
        sprintf_s(msgbuf,2048," %s �d�L���, �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return  M_CM_NOT_FOUND;
    }
    
    strcat(stitle,"\t�߮׸�\t�N�X\t���\t�鵲��\t�J�p��\t�ʽ�\t����\t��H�N��\t����\t��H�W��\t�ߥI�t��\t���B");

	
    strcpy(stmt,"select iclaim , ''''||iclaimCode , nunit , dclose , dgroup , fstl , iclose_type , istl_obj , istl_obj_ext ,\
                        nstl_obj , dspeed , mpayment \
				 from tb_ca12081 where 1=1   ");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);

    if (rc != SUCCESS) {

        sprintf_s(msgbuf,2048," %s �ɮ׵L�k���� ",sfilename);

        EWRITE(userid, rc , msgbuf);
        return rc;
    }
    return M_CM_OK;
    
errexit:
    printf("--car1208_print_detail-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}

/******************************************************************************/



