/**********************************************
 * Copyright (C) 1993 Intellisys Corporation  *
 *                                            *
 * Program : ca403q01s.ec (Type Block 1)      *
 *                                            *
 * Update : 2002.03.25 by Jessie �[�~�ȥγ��� *
 **********************************************/

#include <stdio.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"

#include "carmsgs.h" 
#include "commsgs.h" 
#include "sqlfatal.h"
$include "gls_for_ins.h";
$include "safeclib.h";

#define NEXTPAGE   7
#define MAXUNIT    40

/* standard data declaration */
$char  BodyFmt[N_FILE+1];
$char  TitleFmt[N_FILE+1];
$int   TotColumn;
$int   StartRow,TitleRow;
$int   ItemRow, PgLine, Width=0;

char   SysTm[N_TM+1];
char   BodyFile[2][N_FILE+1];
char   TitleFile[2][N_FILE+1];
char   outputf[N_FILE+1];
char   addname[1];

int    TotRows;
int    linenum;
int    IsBusiness;

$date  Today;
int    max_count[2];
/* end of standard data */

/* private data */
$char   dptbgn[BRANCH_ID], dptend[BRANCH_ID], plydate[YYYMMDD], cplydate[12];
$char   sIbranchIcomp[CA_POL_BRH_NUM+1];
$char   dbname[BRANCH_ID], nchi_abv[13];
$char   iacc_type[3],pre_branch[3];
char    ctype[1];
int     flag_check=0,itype;
$long   Mlia_prem;
$double Mpure_prem;
double  Mextra_charge,Pextra_charge,Minu_prem;
double  Brk_mpure_prem[4],Brk_mextra_charge[4];
double  Tot_mpure_prem[4],Tot_mextra_charge[4];
double  Brk_mply_prem[4],Tot_mply_prem[4];
double  Brk_minu_prem[4],Tot_minu_prem[4];
/* end of private data */

/* ���ƫO�O */
/* �j��T��[�ۥ�] */
double  Tot_mcompensation_car_14_pos  = 0.0;
double  Tot_mlia_prem_car_14_pos      = 0.0;
double  Tot_mlia_commi_car_14_pos     = 0.0;
/* �j��T��[�ӷ~] */
double  Tot_mcompensation_car_15_pos  = 0.0;
double  Tot_mlia_prem_car_15_pos      = 0.0;
double  Tot_mlia_commi_car_15_pos     = 0.0;
/* �j�����[�@�~��] */
double  Tot_mcompensation_moto_p1_pos = 0.0;
double  Tot_mlia_prem_moto_p1_pos     = 0.0;
double  Tot_mlia_commi_moto_p1_pos    = 0.0;
/* �j�����[�G�~��] */
double  Tot_mcompensation_moto_p2_pos = 0.0;
double  Tot_mlia_prem_moto_p2_pos     = 0.0;
double  Tot_mlia_commi_moto_p2_pos    = 0.0;

/* �j��L���q�ʤG��[�@�~��]  */
double  Tot_mcompensation_moto35_p1_pos = 0.0;
double  Tot_mlia_prem_moto35_p1_pos     = 0.0;
double  Tot_mlia_commi_moto35_p1_pos    = 0.0;
/* �j��L���q�ʤG��[�G�~��]  */
double  Tot_mcompensation_moto35_p2_pos = 0.0;
double  Tot_mlia_prem_moto35_p2_pos     = 0.0;
double  Tot_mlia_commi_moto35_p2_pos    = 0.0;
/* �j��L���q�ʤG��[�T�~��]  */
double  Tot_mcompensation_moto35_p3_pos = 0.0;
double  Tot_mlia_prem_moto35_p3_pos     = 0.0;
double  Tot_mlia_commi_moto35_p3_pos    = 0.0;
/*
* �j��L���q�ʤG��[�|�~��]  *
double  Tot_mcompensation_moto35_p4_pos = 0.0;
double  Tot_mlia_prem_moto35_p4_pos     = 0.0;
double  Tot_mlia_commi_moto35_p4_pos    = 0.0;
* �j��L���q�ʤG��[���~��]  *
double  Tot_mcompensation_moto35_p5_pos = 0.0;
double  Tot_mlia_prem_moto35_p5_pos     = 0.0;
double  Tot_mlia_commi_moto35_p5_pos    = 0.0;
*/

/* �t�ƫO�O */
/* �j��T��[�ۥ�] */
double  Tot_mcompensation_car_14_neg  = 0.0;
double  Tot_mlia_prem_car_14_neg      = 0.0;
double  Tot_mlia_commi_car_14_neg     = 0.0;
/* �j��T��[�ӷ~] */
double  Tot_mcompensation_car_15_neg  = 0.0;
double  Tot_mlia_prem_car_15_neg      = 0.0;
double  Tot_mlia_commi_car_15_neg     = 0.0;
/* �j�����[�@�~��] */
double  Tot_mcompensation_moto_p1_neg = 0.0;
double  Tot_mlia_prem_moto_p1_neg     = 0.0;
double  Tot_mlia_commi_moto_p1_neg    = 0.0;
/* �j�����[�G�~��] */
double  Tot_mcompensation_moto_p2_neg = 0.0;
double  Tot_mlia_prem_moto_p2_neg     = 0.0;
double  Tot_mlia_commi_moto_p2_neg    = 0.0;

/* �j��L���q�ʤG��[�@�~��]  */
double  Tot_mcompensation_moto35_p1_neg = 0.0;
double  Tot_mlia_prem_moto35_p1_neg     = 0.0;
double  Tot_mlia_commi_moto35_p1_neg    = 0.0;
/* �j��L���q�ʤG��[�G�~��]  */
double  Tot_mcompensation_moto35_p2_neg = 0.0;
double  Tot_mlia_prem_moto35_p2_neg     = 0.0;
double  Tot_mlia_commi_moto35_p2_neg    = 0.0;
/* �j��L���q�ʤG��[�T�~��]  */
double  Tot_mcompensation_moto35_p3_neg = 0.0;
double  Tot_mlia_prem_moto35_p3_neg     = 0.0;
double  Tot_mlia_commi_moto35_p3_neg    = 0.0;
/*
* �j��L���q�ʤG��[�|�~��]  *
double  Tot_mcompensation_moto35_p4_neg = 0.0;
double  Tot_mlia_prem_moto35_p4_neg     = 0.0;
double  Tot_mlia_commi_moto35_p4_neg    = 0.0;
* �j��L���q�ʤG��[���~��]  *
double  Tot_mcompensation_moto35_p5_neg = 0.0;
double  Tot_mlia_prem_moto35_p5_neg     = 0.0;
double  Tot_mlia_commi_moto35_p5_neg    = 0.0;
*/
/*********************************/

$char inf_plydate[YYYYMMDD];
/*1080912006_SC2 �s�Wñ��������ˮ�*/
long    lDiff_ca_gl=0;
char    buf_Diff[20],buf_GLS[20];
struct  GLS_FOR_INS *get_gls_for_ins();  

$char DBName[DBNAME];
char userid[USER_ID];
$char FormTp[3];
long rtncode;
int  i;
static int   DiffMonth();    /* input data should be date format */

/* end of standard defined data */

/*---------------------------------------------------------------------*/
void cvBusiness(f,s)
char *f, *s;
{
  strcpy(s,"");

  if (isalpha(f[0]))
  {
    switch (f[0])
    {
      case 'A':
              strcpy(s,"�g��");
              strcat(s,"-");
              strcat(s,f);
              break;
      case 'B':
              strcpy(s,"����");
              strcat(s,"-");
              strcat(s,f);
              break;
    }
  }
  else
  {
    switch (atoi(f)) 
    {
      case 1:
              strcpy(s,"���P");
              strcat(s,"-");
              strcat(s,f);
              break;

      case 2:
              strcpy(s,"�L��");
              strcat(s,"-");
              strcat(s,f);
              break;

      case 5:
              strcpy(s,"�@��");
              strcat(s,"-");
              strcat(s,f);
              break;

      case 3:
      case 4:
      case 6:
      case 7:
      case 9:
              strcpy(s,"���B");
              strcat(s,"-");
              strcat(s,f);
              break;
    }
  }
}

/*---------------------------------------------------------------------*/
void cvProtect(f,s)
char *f, *s;
{
  strcpy(s,"");

  if (isalpha(f[0]))
  {
    switch (f[0])
    {
      case 'A':
              strcpy(s,"�g��");
              strcat(s,"-");
              strcat(s,f);
              break;
      case 'B':
              strcpy(s,"����");
              strcat(s,"-");
              strcat(s,f);
              break;
    }
  }
  else
  {
    switch (atoi(f)) 
    {
      case 1:
              strcpy(s,"���P");
              strcat(s,"-");
              strcat(s,f);
              break;

      case 3:
      case 4:
      case 6:
      case 7:
      case 9:
              strcpy(s,"���B");
              strcat(s,"-");
              strcat(s,f);
              break;
    }
  }
}

/************************************************************************/
main(argc,argv)
int argc;
char **argv;
 {
   int   rc;
   
   char  buf[80];
   $char fname[101];
   $char yy[YYY], mm[MM], dd[DD];

   batchinit();
   strcpy(DBName,         isNULLstr(argv[1]));
   strcpy(userid,         isNULLstr(argv[2]));
   strcpy(plydate,        isNULLstr(argv[3]));
   strcpy(sIbranchIcomp,  isNULLstr(argv[4]));
   strcpy(ctype,          isNULLstr(argv[5]));
   strcpy(outputf,        isNULLstr(argv[6]));
   strcpy(sIbranchIcomp,  trim(sIbranchIcomp));
   strcat(sIbranchIcomp,  "*");
   itype = atoi(ctype);
   strcpy(addname,"");

   if (db_select(DBName) == False)
   {
       EWRITE(userid,M_CM_DB_NOTOPEN,"M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }
   strcpy(dbname,DBName);
   dbname[2]='\0';

   strcpy(inf_plydate,cm_to_infdate(plydate));

   rtoday(&Today);     /* get today's datetime */

   cm_split_ymd_100(plydate,yy,mm,dd);

   printf("itype[%d]\n",itype);
   if (itype==1 || itype==0)
   {
       rc=car403_build();
       if (rc != M_CM_OK) {
           EWRITE(userid,rc," ");
           return rc;
       }

       rc=create_sign_form("car403",BodyFile[0],Width);
       if (rc != 0) {
           EWRITE(userid,rc," ");
           return rc;
       }

       rc=create_sign_form("car403",BodyFile[1],Width);
       if (rc != 0) {
           EWRITE(userid,rc," ");
           return rc;
       }

       sprintf_s(buf, sizeof buf, "%sA", outputf);
       TotRows=max_count[0];
       if(rc=(save_form_info(F_BLK0,"CA",403,userid,FormTp,TotRows,outputf))<0)
       {
          EWRITE(userid,rc,"save_form_info  failed");
          return rc;
       }

       printf("plydate[%s]\n",plydate);
       sprintf_s(fname, sizeof fname,"�j��_���_%s%s%s",yy,mm,dd);
       printf("car403_build1:fname[%s]\n",fname);
       gen_filename(outputf,"A",fname);

       sprintf_s(buf, sizeof buf, "%sB", outputf);
       TotRows=max_count[1];
       if(rc=(save_form_info(F_BLK0,"CA",403,userid,FormTp,TotRows,outputf))<0)
       {
          EWRITE(userid,rc,"save_form_info  failed");
          return rc;
       }

       printf("plydate[%s]\n",plydate);
       sprintf_s(fname, sizeof fname,"�j��_���_%s%s%s",yy,mm,dd);
       printf("car403_build1:fname[%s]\n",fname);
       gen_filename(outputf,"B",fname);
   }

   itype=atoi(ctype);
   printf("itype[%d]\n",itype);

   if (itype==2 || itype==0)
   {
       printf("begin car403_build1\n");
       rc=car403_build1();
       if (rc != M_CM_OK) {
           EWRITE(userid,rc," ");
           return rc;
       }
       rc=create_sign_form("car403",BodyFile[0],Width);
       if (rc != 0) {
           EWRITE(userid,rc," ");
           return rc;
       }

       if(rc=(save_form_info(F_BLK1,"CA",403,userid,FormTp,TotRows,outputf))<0)
       {
          EWRITE(userid,rc,"save_form_info  failed");
          return rc;
       }

       printf("plydate[%s]\n",plydate);
       sprintf_s(fname, sizeof fname,"�j��_���[�~�ȥ�]_%s%s%s",yy,mm,dd);
       printf("car403_build1:fname[%s]\n",fname);
       gen_filename(outputf,"C",fname);
   }
}

/*--------------------------------------------------------------------*/
long car403_build()
{
   int    i=0,j;
   long   rtncode;

   $WHENEVER SQLERROR GOTO errexit;


   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow, $ItemRow ,
           $TotColumn, $PgLine, $Width, $FormTp
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 403 AND iForm_Tp = "1";

   strcpy(TitleFmt,rtrim(TitleFmt));
   strcpy(BodyFmt,rtrim(BodyFmt));

   /* For �~�ȥ� */
   IsBusiness = 1;

   sprintf_s(TitleFile[0], sizeof TitleFile[0],"%sA.ti",outputf);
   sprintf_s(BodyFile[0], sizeof BodyFile[0],"%sA.bd",outputf);

   rgu_init_report(TitleFmt,TitleFile[0]);
   car403_title(1);
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile[0]);
   rtncode=car403_body();
   if (rtncode != M_CM_OK) return rtncode;
   rgu_finish_report();
   max_count[0] = TotRows;

   /* For �]�ȥ� */
   IsBusiness = 0;

   sprintf_s(TitleFile[1], sizeof TitleFile[1],"%sB.ti",outputf);
   sprintf_s(BodyFile[1], sizeof BodyFile[1],"%sB.bd",outputf);

   rgu_init_report(TitleFmt,TitleFile[1]);
   car403_title(2);
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile[1]);
   rtncode=car403_body();
   if (rtncode != M_CM_OK) return rtncode;
   rgu_finish_report();
   max_count[1] = TotRows;

   printf("max_count[0]=%d, max_count[1]=%d\n",max_count[0],max_count[1]);

   return M_CM_OK;

errexit:
   sqlfatal();
   return SQLCODE;
} 

/*--------------------------------------------------------------------*/
long car403_build1()
{
   int    i=0,j;
   long   rtncode;

   $WHENEVER SQLERROR GOTO errexit;


   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow, $ItemRow ,
           $TotColumn, $PgLine, $Width, $FormTp
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 403 AND iForm_Tp = "2";

   strcpy(TitleFmt,rtrim(TitleFmt));
   strcpy(BodyFmt,rtrim(BodyFmt));
   if (itype==0)
       strcpy(addname,"C");

   /* For �~�ȥ� */
   IsBusiness = 1;

   sprintf_s(TitleFile[0], sizeof TitleFile[0],"%s%s.ti",outputf,addname);
   sprintf_s(BodyFile[0], sizeof BodyFile[0],"%s%s.bd",outputf,addname);

   rgu_init_report(TitleFmt,TitleFile[0]);
   rtncode=car403_title1();
   if (rtncode != M_CM_OK) return rtncode;
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile[0]);
   rtncode=car403_body1();
   if (rtncode != M_CM_OK) return rtncode;
   rgu_finish_report();
   max_count[0] = TotRows;

   return M_CM_OK;

errexit:
   sqlfatal();
   return SQLCODE;
} 

/*-------------------------------------------------------------------*/
long car403_title(i)
int i;
{
   $char yy[YYY], mm[MM], dd[DD];
   $char tmp_yy[YYY];
   $long dclosing=0,plydate_l, iyy;
   $char ivoucher[GL_VCHR_NO];
   char  sub_title[30];

   $WHENEVER SQLERROR GOTO errexit;

   if (i==1)
      rgu_put_head_string(1,"�~�ȥ�");
   else
      rgu_put_head_string(1,"�]�ȥ�");

   memcpy(yy,plydate,3); yy[3] = '\0';
   memcpy(mm,(plydate+4),2); mm[2] = '\0';
   memcpy(dd,(plydate+7),2); dd[2] = '\0';

   strncpy( tmp_yy, &yy[1],2);
   tmp_yy[2] = '\0';
   strcpy( yy, tmp_yy);
   printf("yy[%s]\n", yy);

   $SELECT dlast_closing,ivoucher
      INTO $dclosing, $ivoucher
      FROM last_daily_close
     WHERE ibill_type="CA2"
       AND iyear=$yy;

   $SELECT first 1 kcracc_num_tot 
      INTO $ivoucher
      FROM gl_vchrxn_sub 
     WHERE kcracc_num = $ivoucher AND isub = $DBName; 

   printf("SQLCODE[%d]\n", SQLCODE);

   plydate_l=cm_ymd_cdate(plydate);

   if (dclosing< plydate_l) 
   {
        flag_check=1;
        rgu_put_head_string(1, "(�ˮ֥�)");
   } 
   else if (dclosing == plydate_l) 
   {
        strcpy(sub_title, "(�s�����X:");
        strcat(sub_title, ivoucher);
        trim_tail_white(sub_title);
        strcat(sub_title, ")");
        rgu_put_head_string(1, sub_title);
   } 
   else 
   {
        rgu_put_head_string(1, "(�ɵo��)");
   }

   $SELECT nchi_abv INTO $nchi_abv FROM branch
     WHERE ibranch = $dbname;

   rgu_put_head_string(1,cm_sysd_cdatetime_100(cm_get_sysd()));

   rgu_put_head_string(1,dbname);
   rgu_put_head_string(1,nchi_abv);

   rgu_put_head_string(1,yy) ;
   rgu_put_head_string(1,mm) ;
   rgu_put_head_string(1,dd) ;
   rgu_put_head();

   return M_CM_OK;

errexit:
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

/*-------------------------------------------------------------------*/
long car403_title1()
{
   $char yy[YYY], mm[MM], dd[DD];
   $char tmp_yy[YYY];
   $long dclosing=0,plydate_l, iyy;
   $char ivoucher[GL_VCHR_NO];
   char  sub_title[30];

   $WHENEVER SQLERROR GOTO errexit;

   memcpy(yy,plydate,3); yy[3] = '\0';
   memcpy(mm,(plydate+4),2); mm[2] = '\0';
   memcpy(dd,(plydate+7),2); dd[2] = '\0';

   strncpy( tmp_yy, &yy[1],2);
   tmp_yy[2] = '\0';
   strcpy( yy, tmp_yy);
   printf("yy[%s]\n", yy);

   $SELECT dlast_closing,ivoucher
      INTO $dclosing, $ivoucher
      FROM last_daily_close
     WHERE ibill_type="CA2"
       AND iyear=$yy;

   plydate_l=cm_ymd_cdate(plydate);

   if (dclosing< plydate_l) 
   {
        flag_check=1;
        rgu_put_head_string(1, "(�~���ˮ֥�)");
   } 
   else 
   {
        rgu_put_head_string(1, "(�~�ȥ�)");
   }

   rgu_put_head_string(1,cm_sysd_cdatetime_100(cm_get_sysd()));
   rgu_put_head_string(1,yy) ;
   rgu_put_head_string(1,mm) ;
   rgu_put_head_string(1,dd) ;
   rgu_put_head();

   return M_CM_OK;

errexit:
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/
long car403_body()
{       
    $char   stmt_buf[1024];
    $char   ipolicy[POLICY_NUM_1],icard[CARD_NUM],fcard_class[2];
    $char   iofficer[EMPLOYEE_ID],ibroker[BROKER],icashier[EMPLOYEE_ID];
    $char   nassured[ASSURED_NAME],icar_type[CA_CAR_TYPE_NUM];
    $char   iendorse[ENDORSE_NUM],fedr_class[2], iedr[ENDORSE_NUM];
    $char   iedr_car[ENDORSE_NUM],iedr_moto[ENDORSE_NUM];
    $long   qply_begin=0,qply_end=0;
    $long   dply_begin,dply_end;
    $long   qply_period=0;
    $long   mdmg_prem,mdmg_commi,mdmg_agent,mlia_prem,mlia_commi,mlia_agent;
    $double sum1,sum2,tmpdata,tmpsum;
    $double tmpdata_car,tmpsum_car,tmpdata_moto,tmpsum_moto;/*car & moto*/
    $double dataline[4],pagesum[4],pos_sum[4],neg_sum[4];
    $double dataline_car[4],pagesum_car[4],pos_sum_car[4],neg_sum_car[4];/*car*/
    $double dataline_moto[4],pagesum_moto[4],pos_sum_moto[4],neg_sum_moto[4];/*moto*/
    char    typestr[5],buffer[21],abn_brk[4];
    char    buffer_car[21],buffer_moto[21];/*car & moto*/
    char    ch1[21];
    char    where_stat[50];
    $char   sFull[31], branch[3], stmt1[512];

    $char  iproduct[13];
    $char  kclsfyitem[5];
    $char  kreserve[6];
    $char  drate_ym[5];
    long   rtncode;

    int  i, j, totcnt;

    /*1080912006_SC2 �s�Wñ��������ˮ�*/
    char bufC1_14[20],bufC2_14[20],bufC3_14[20];
    char bufC1_15[20],bufC2_15[20],bufC3_15[20];
    char bufM1_P1[20],bufM2_P1[20],bufM3_P1[20];
    char bufM1_P2[20],bufM2_P2[20],bufM3_P2[20];

    char bufM2_P1_35[20],bufM3_P1_35[20];
    char bufM2_P2_35[20],bufM3_P2_35[20];
    char bufM2_P3_35[20],bufM3_P3_35[20];
    /*
    char bufM2_P4_35[20],bufM3_P4_35[20];
    char bufM2_P5_35[20],bufM3_P5_35[20];
    */

    char  v_sMsg[3000];
    $char kacctitem[5],eacc_title[41];
    $long mdeal;
    $int  iseq;
	long lng_Tot_mlia_prem_car_14,lng_Tot_mlia_commi_car_14,lng_Tot_mlia_prem_car_15,lng_Tot_mlia_commi_car_15;
	long lng_Tot_mlia_prem_moto_p1,lng_Tot_mlia_commi_moto_p1,lng_Tot_mlia_prem_moto_p2,lng_Tot_mlia_commi_moto_p2;
    long lng_Tot_mlia_prem_moto35_p1,lng_Tot_mlia_commi_moto35_p1,lng_Tot_mlia_prem_moto35_p2,lng_Tot_mlia_commi_moto35_p2;
    long lng_Tot_mlia_prem_moto35_p3,lng_Tot_mlia_commi_moto35_p3;    
    /*long lng_Tot_mlia_prem_moto35_p4,lng_Tot_mlia_commi_moto35_p4,lng_Tot_mlia_prem_moto35_p5,lng_Tot_mlia_commi_moto35_p5;*/
  

    $WHENEVER SQLERROR GOTO errexit;
    
    /*1080912006_SC2 �s�Wñ��������ˮ�*/
    $EXECUTE IMMEDIATE "DROP TABLE IF EXISTS tmp_gl_list";
    $CREATE TEMP TABLE tmp_gl_list
     (
         iseq        INTEGER         default 0,
         kacctitem   CHAR(4),
         kclsfyitem  CHAR(4),
         eacc_title  CHAR(40),
         mdeal       DECIMAL(15,0)    default 0
     ) with no log;
     $CREATE INDEX tmp_gl_idx ON tmp_gl_list (kclsfyitem);
    mdeal=0;
    strcpy(kclsfyitem,"");
    strcpy(kclsfyitem,"");
    strcpy(eacc_title,"");
    

    /*----------initialize-----*/
    TotRows=0;
    linenum=0;
    totcnt=0;

    Tot_mcompensation_car_14_pos  = 0.0;
    Tot_mlia_prem_car_14_pos      = 0.0;
    Tot_mlia_commi_car_14_pos     = 0.0;
    Tot_mcompensation_car_15_pos  = 0.0;
    Tot_mlia_prem_car_15_pos      = 0.0;
    Tot_mlia_commi_car_15_pos     = 0.0;
    Tot_mcompensation_moto_p1_pos = 0.0;
    Tot_mlia_prem_moto_p1_pos     = 0.0;
    Tot_mlia_commi_moto_p1_pos    = 0.0;
    Tot_mcompensation_moto_p2_pos = 0.0;
    Tot_mlia_prem_moto_p2_pos     = 0.0;
    Tot_mlia_commi_moto_p2_pos    = 0.0;
    Tot_mcompensation_car_14_neg  = 0.0;
    Tot_mlia_prem_car_14_neg      = 0.0;
    Tot_mlia_commi_car_14_neg     = 0.0;
    Tot_mcompensation_car_15_neg  = 0.0;
    Tot_mlia_prem_car_15_neg      = 0.0;
    Tot_mlia_commi_car_15_neg     = 0.0;
    Tot_mcompensation_moto_p1_neg = 0.0;
    Tot_mlia_prem_moto_p1_neg     = 0.0;
    Tot_mlia_commi_moto_p1_neg    = 0.0;
    Tot_mcompensation_moto_p2_neg = 0.0;
    Tot_mlia_prem_moto_p2_neg     = 0.0;
    Tot_mlia_commi_moto_p2_neg    = 0.0;

    Tot_mcompensation_moto35_p1_pos = 0.0;
    Tot_mlia_prem_moto35_p1_pos     = 0.0;
    Tot_mlia_commi_moto35_p1_pos    = 0.0;
    Tot_mcompensation_moto35_p2_pos = 0.0;
    Tot_mlia_prem_moto35_p2_pos     = 0.0;
    Tot_mlia_commi_moto35_p2_pos    = 0.0;
    Tot_mcompensation_moto35_p3_pos = 0.0;
    Tot_mlia_prem_moto35_p3_pos     = 0.0;
    Tot_mlia_commi_moto35_p3_pos    = 0.0;
/*    
    Tot_mcompensation_moto35_p4_pos = 0.0;
    Tot_mlia_prem_moto35_p4_pos     = 0.0;
    Tot_mlia_commi_moto35_p4_pos    = 0.0;
    Tot_mcompensation_moto35_p5_pos = 0.0;
    Tot_mlia_prem_moto35_p5_pos     = 0.0;
    Tot_mlia_commi_moto35_p5_pos    = 0.0;
*/
    Tot_mcompensation_moto35_p1_neg = 0.0;
    Tot_mlia_prem_moto35_p1_neg     = 0.0;
    Tot_mlia_commi_moto35_p1_neg    = 0.0;
    Tot_mcompensation_moto35_p2_neg = 0.0;
    Tot_mlia_prem_moto35_p2_neg     = 0.0;
    Tot_mlia_commi_moto35_p2_neg    = 0.0;
    Tot_mcompensation_moto35_p3_neg = 0.0;
    Tot_mlia_prem_moto35_p3_neg     = 0.0;
    Tot_mlia_commi_moto35_p3_neg    = 0.0;
/*    
    Tot_mcompensation_moto35_p4_neg = 0.0;
    Tot_mlia_prem_moto35_p4_neg     = 0.0;
    Tot_mlia_commi_moto35_p4_neg    = 0.0;
    Tot_mcompensation_moto35_p5_neg = 0.0;
    Tot_mlia_prem_moto35_p5_neg     = 0.0;
    Tot_mlia_commi_moto35_p5_neg    = 0.0;
*/

    for (j=0; j<4; j++)
    {
         pagesum[j] = 0;
         pos_sum[j] = 0;
         neg_sum[j] = 0;

         pos_sum_car[j] = 0;/*car*/
         neg_sum_car[j] = 0;

         pos_sum_moto[j] = 0;/*moto*/
         neg_sum_moto[j] = 0;
    }
    /*-------------------------*/
    strcpy(cplydate,cm_to_infdate(plydate));
    strcpy(abn_brk,"   ");
    printf("###### cplydate[%s]\n",cplydate);

    stmt_buf[0] = '\0';
    where_stat[0] = '\0';
    if (flag_check == 1)   /*** ���ˮ֥� ***/
    {
         where_stat[0] = '\0';
    }
    else
    {
         strcpy(where_stat, "AND a.dedr_close is not null ");
    }

      $DECLARE sscur CURSOR FOR
        SELECT branch
          FROM servertbl
         WHERE branch != 'S1'
         ORDER BY branch;
      $OPEN sscur;
      for(;;)
      {
      $FETCH sscur INTO $branch;
       if (SQLCODE == SQLNOTFOUND) break;
       strcpy(sFull,get_full_dbname(branch));

    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT a.ipolicy, a.medrlia_prem, a.medrlia_commi, a.iofficer,"
                      "       a.ibroker, a.iedr_cashier, a.dedr_begin, a.dedr_end,"
                      "       b.dply_begin, b.dply_end, a.medr_compensate,"
                      "       b.nassured, a.icar_type, a.icard, a.iendorse, a.fedr_class, b.qply_period "
                      "  FROM %s:edr_relation a , %s:endorsement b "
                      " WHERE fcard_class = '1' "
                      "   AND a.dendorse = ? "
                      "   AND b.iendorse = a.iendorse "
                      "   AND a.iendorse MATCHES ? "
                      " %s "
                      " ORDER BY a.iendorse, a.ipolicy", sFull, sFull, where_stat);

    $PREPARE CUR_STMT1 FROM $stmt_buf;
    $DECLARE X2 CURSOR FOR  CUR_STMT1;
    $OPEN X2 USING $cplydate , $sIbranchIcomp;
    printf("stmt_buf[%s]\n",stmt_buf);
    for (;;)
    {
          $FETCH X2 INTO $ipolicy,$dataline[2],$dataline[3],$iofficer,$ibroker,
                         $icashier,$qply_begin,$qply_end, 
                         $dply_begin,$dply_end,$dataline[1],$nassured,
                         $icar_type,
                         $icard,$iendorse,$fedr_class,$qply_period;

          if (SQLCODE == SQLNOTFOUND) break;

          /* qply_period = DiffMonth(dply_end,dply_begin); */

          /* ���v����|�ˤ��J�ܾ�Ʀ� */
          if (dataline[1] > 0)
          {
              dataline[1] = (double)((long)(dataline[1] + 0.5));
          }
          else if (dataline[1] < 0)
          {
              dataline[1] = (double)((long)(dataline[1] - 0.5));
          }

          if (IsBusiness==0)
          {
              /* car9602053 ���s�W���N�I�L�����O */
              if (fedr_class[0] !='1' && fedr_class[0] !='3' &&
                  fedr_class[0] !='4' && fedr_class[0] !='6' &&
                  fedr_class[0] !='7' && fedr_class[0] !='9' &&
                  fedr_class[0] !='8' &&
                  fedr_class[0] !='A' && fedr_class[0] !='B')
                  continue;
          }

          printf("##### ply[%s] edr[%s]\n",ipolicy,iendorse);

          if (((linenum >= MAXPGROW-3) ||
              strncmp( abn_brk,&iendorse[4],3) != 0) &&
             (strncmp( abn_brk,"   ", 3) != 0))
          {
              rgu_put_body(3);

              for (j=0; j<4; j++)
              {
                   if(j==0){
                      rfmtdouble(pagesum[j], "--,--&", buffer);
                   }else if(j==1){
                     rfmtdouble(pagesum[j], "---,--&", buffer);
                   }else {
                     if (j==2) rfmtdouble(pagesum[j],"---,---,--&",buffer);
                     else rfmtdouble(pagesum[j], "-,---,--&", buffer);
                   }
                   rgu_put_body_string(4,buffer,RIGHT);
              }
              rgu_put_body(4);
              for (j=0; j<4; j++) pagesum[j] = 0;
              rgu_put_body(3);
              rgu_put_body(NEXTPAGE);
              TotRows += 3;
              linenum = 0;
              strncpy(abn_brk, &iendorse[4], 3);
          }
          else
          {
              linenum++;
              totcnt++;
          }

          /* �T���j�� */
          sprintf_s(stmt1, sizeof stmt1, "SELECT medrlia_prem, medrlia_commi, medr_compensate"
                          "  FROM %s:edr_relation "
                          " WHERE iendorse=? "
                          "   AND icar_type not in ('01','02','32','34','35')", sFull);
          $PREPARE prep1 FROM $stmt1;
          $EXECUTE prep1 INTO $dataline_car[2],$dataline_car[3],$dataline_car[1] USING $iendorse;
          if (SQLCODE==SQLNOTFOUND) {
              dataline_car[2]=0,dataline_car[3]=0,dataline_car[1]=0;
          }
          $FREE prep1;

          /* ���v����|�ˤ��J�ܾ�Ʀ� */
          if (dataline_car[1] > 0)
          {
              dataline_car[1] = (double)((long)(dataline_car[1] + 0.5));
          }
          else if (dataline_car[1] < 0)
          {
              dataline_car[1] = (double)((long)(dataline_car[1] - 0.5));
          }

          /* �����j�� */
          sprintf_s(stmt1, sizeof stmt1, "SELECT medrlia_prem, medrlia_commi, medr_compensate"
                          "  FROM %s:edr_relation"
                          " WHERE iendorse=?"
                          "   AND icar_type in ('01','02','32','34','35')", sFull);

          $PREPARE prep2 FROM $stmt1;
          $EXECUTE prep2 INTO $dataline_moto[2],$dataline_moto[3],$dataline_moto[1] USING $iendorse;
          if (SQLCODE==SQLNOTFOUND) {
              dataline_moto[2]=0,dataline_moto[3]=0,dataline_moto[1]=0;
          }
          $FREE prep2;

          /* ���v����|�ˤ��J�ܾ�Ʀ� */
          if (dataline_moto[1] > 0)
          {
              dataline_moto[1] = (double)((long)(dataline_moto[1] + 0.5));
          }
          else if (dataline_moto[1] < 0)
          {
              dataline_moto[1] = (double)((long)(dataline_moto[1] - 0.5));
          }

          sprintf_s(stmt1, sizeof stmt1, "SELECT iendorse, iproduct[4,5], drate_ym"
                          "  FROM %s:edr_ins_type "
                          " WHERE iendorse=?", sFull);

          $PREPARE prep3 FROM $stmt1;
          $EXECUTE prep3 INTO $iedr, $iacc_type, $drate_ym USING $iendorse;

          if (SQLCODE==SQLNOTFOUND) {
              dataline[0] = 0;

              sprintf_s(stmt1, sizeof stmt1, "SELECT iproduct[4,5], drate_ym"
                              "  FROM %s:ply_ins_type "
                              " WHERE ipolicy=?", sFull);
              $PREPARE prep3_P FROM $stmt1;
              $EXECUTE prep3_P INTO $iacc_type, $drate_ym USING $ipolicy;                            

              strcpy(iedr, iendorse);
              $FREE prep3_P;
          }
          else
          {
              sprintf_s(stmt1, sizeof stmt1, "SELECT SUM(medrdmg_cover)"
                              "  FROM %s:edr_ins_type"
                              " WHERE iendorse=?", sFull);
              $PREPARE prep4 FROM $stmt1;
              $EXECUTE prep4 INTO $dataline[0] USING $iendorse;
          }
          $FREE prep3;
          $FREE prep4;

          printf("--trace drate_ym[%s]\n ",drate_ym);
          /* ���q�Ϥ������@�~���ΤG�~���A�ΨT���Ϥ��ۥΩΰӷ~�A */
          /* ����|�p��l�� */
          rtncode = get_product_code_car("C","21",icar_type,qply_period,iproduct,kclsfyitem,kreserve, "", drate_ym);
          if (rtncode != M_CM_OK)
          {
               return rtncode;
          }

          strcpy(kclsfyitem,trim(kclsfyitem));

          printf("--trace kclsfyitem[%s]\n ",kclsfyitem);
              
          if (strcmp(kclsfyitem,"1400")==0)  /* �j��ۥΨT���I */
          {
                   if (dataline_car[1] >= 0)
                   {
                        Tot_mcompensation_car_14_pos += dataline_car[1];
                   }
                   else
                   {
                        Tot_mcompensation_car_14_neg += dataline_car[1];
                   }

                   if (dataline_car[2] >= 0)
                   {
                        Tot_mlia_prem_car_14_pos     += dataline_car[2];
                   }
                   else
                   {
                        Tot_mlia_prem_car_14_neg     += dataline_car[2];
                   }

                   if (dataline_car[3] >= 0)
                   {
                        Tot_mlia_commi_car_14_pos    += dataline_car[3];
                   }
                   else
                   {
                        Tot_mlia_commi_car_14_neg    += dataline_car[3];
                   }
          }

          if (strcmp(kclsfyitem,"1500")==0)  /* �j��ӷ~�T���I */
          {
                   if (dataline_car[1] >= 0)
                   {
                        Tot_mcompensation_car_15_pos += dataline_car[1];
                   }
                   else
                   {
                        Tot_mcompensation_car_15_neg += dataline_car[1];
                   }
                   if (dataline_car[2] >= 0)
                   {
                        Tot_mlia_prem_car_15_pos     += dataline_car[2];
                   }
                   else
                   {
                        Tot_mlia_prem_car_15_neg     += dataline_car[2];
                   }
                   if (dataline_car[3] >= 0)
                   {
                        Tot_mlia_commi_car_15_pos    += dataline_car[3];
                   }
                   else
                   {
                        Tot_mlia_commi_car_15_neg    += dataline_car[3];
                   }
          }

          if (strcmp(kclsfyitem,"1600")==0)  /* �j������@�~�� */
          {
                   if (dataline_moto[1] >= 0)
                   {
                        Tot_mcompensation_moto_p1_pos += dataline_moto[1];
                   }
                   else
                   {
                        Tot_mcompensation_moto_p1_neg += dataline_moto[1];
                   }

                   if (dataline_moto[2] >= 0)
                   {
                        Tot_mlia_prem_moto_p1_pos     += dataline_moto[2];
                   }
                   else
                   {
                        Tot_mlia_prem_moto_p1_neg     += dataline_moto[2];
                   }

                   if (dataline_moto[3] >= 0)
                   {
                        Tot_mlia_commi_moto_p1_pos    += dataline_moto[3];
                   }
                   else
                   {
                        Tot_mlia_commi_moto_p1_neg    += dataline_moto[3];
                   }
          }

          if (strcmp(kclsfyitem,"1601")==0)  /* �j������G�~�� */
          {
                   if (dataline_moto[1] >= 0)
                   {
                        Tot_mcompensation_moto_p2_pos += dataline_moto[1];
                   }
                   else
                   {
                        Tot_mcompensation_moto_p2_neg += dataline_moto[1];
                   }

                   if (dataline_moto[2] >= 0)
                   {
                        Tot_mlia_prem_moto_p2_pos     += dataline_moto[2];
                   }
                   else
                   {
                        Tot_mlia_prem_moto_p2_neg     += dataline_moto[2];
                   }

                   if (dataline_moto[3] >= 0)
                   {
                        Tot_mlia_commi_moto_p2_pos    += dataline_moto[3];
                   }
                   else
                   {
                        Tot_mlia_commi_moto_p2_neg    += dataline_moto[3];
                   }
          }


          if (strcmp(kclsfyitem,"3210")==0)  /* �j��L�q���@�~�� */
          {
                   if (dataline_moto[1] >= 0)
                   {
                        Tot_mcompensation_moto35_p1_pos += dataline_moto[1];
                   }
                   else
                   {
                        Tot_mcompensation_moto35_p1_neg += dataline_moto[1];
                   }

                   if (dataline_moto[2] >= 0)
                   {
                        Tot_mlia_prem_moto35_p1_pos += dataline_moto[2];
                   }
                   else
                   {
                        Tot_mlia_prem_moto35_p1_neg     += dataline_moto[2];
                   }

                   if (dataline_moto[3] >= 0)
                   {
                        Tot_mlia_commi_moto35_p1_pos    += dataline_moto[3];
                   }
                   else
                   {
                        Tot_mlia_commi_moto35_p1_neg    += dataline_moto[3];
                   }
          }

          if (strcmp(kclsfyitem,"3220")==0)  /* �j��L�q���G�~�� */
          {
                   if (dataline_moto[1] >= 0)
                   {
                        Tot_mcompensation_moto35_p2_pos += dataline_moto[1];
                   }
                   else
                   {
                        Tot_mcompensation_moto35_p2_neg += dataline_moto[1];
                   }

                   if (dataline_moto[2] >= 0)
                   {
                        Tot_mlia_prem_moto35_p2_pos += dataline_moto[2];
                   }
                   else
                   {
                        Tot_mlia_prem_moto35_p2_neg     += dataline_moto[2];
                   }

                   if (dataline_moto[3] >= 0)
                   {
                        Tot_mlia_commi_moto35_p2_pos    += dataline_moto[3];
                   }
                   else
                   {
                        Tot_mlia_commi_moto35_p2_neg    += dataline_moto[3];
                   }
          }

          if (strcmp(kclsfyitem,"3230")==0)  /* �j��L�q���T�~�� */
          {
                   if (dataline_moto[1] >= 0)
                   {
                        Tot_mcompensation_moto35_p3_pos += dataline_moto[1];
                   }
                   else
                   {
                        Tot_mcompensation_moto35_p3_neg += dataline_moto[1];
                   }

                   if (dataline_moto[2] >= 0)
                   {
                        Tot_mlia_prem_moto35_p3_pos += dataline_moto[2];
                   }
                   else
                   {
                        Tot_mlia_prem_moto35_p3_neg     += dataline_moto[2];
                   }

                   if (dataline_moto[3] >= 0)
                   {
                        Tot_mlia_commi_moto35_p3_pos    += dataline_moto[3];
                   }
                   else
                   {
                        Tot_mlia_commi_moto35_p3_neg    += dataline_moto[3];
                   }
          }
/*
         if (strcmp(kclsfyitem,"3240")==0)  * �j��L�q���|�~�� *
          {
                   if (dataline_moto[1] >= 0)
                   {
                        Tot_mcompensation_moto35_p4_pos += dataline_moto[1];
                   }
                   else
                   {
                        Tot_mcompensation_moto35_p4_neg += dataline_moto[1];
                   }

                   if (dataline_moto[2] >= 0)
                   {
                        Tot_mlia_prem_moto35_p4_pos += dataline_moto[2];
                   }
                   else
                   {
                        Tot_mlia_prem_moto35_p4_neg     += dataline_moto[2];
                   }

                   if (dataline_moto[3] >= 0)
                   {
                        Tot_mlia_commi_moto35_p4_pos    += dataline_moto[3];
                   }
                   else
                   {
                        Tot_mlia_commi_moto35_p4_neg    += dataline_moto[3];
                   }
          }

         if (strcmp(kclsfyitem,"3250")==0)  * �j��L�q�����~�� *
          {
                   if (dataline_moto[1] >= 0)
                   {
                        Tot_mcompensation_moto35_p5_pos += dataline_moto[1];
                   }
                   else
                   {
                        Tot_mcompensation_moto35_p5_neg += dataline_moto[1];
                   }

                   if (dataline_moto[2] >= 0)
                   {
                        Tot_mlia_prem_moto35_p5_pos += dataline_moto[2];
                   }
                   else
                   {
                        Tot_mlia_prem_moto35_p5_neg     += dataline_moto[2];
                   }

                   if (dataline_moto[3] >= 0)
                   {
                        Tot_mlia_commi_moto35_p5_pos    += dataline_moto[3];
                   }
                   else
                   {
                        Tot_mlia_commi_moto35_p5_neg    += dataline_moto[3];
                   }
          }   
*/
          strcpy(icar_type , trim(icar_type));

          /*if ((ipolicy[5]=='M')&&(ipolicy[6]=='9')) */
          if ((strcmp(icar_type,"01")==0) || (strcmp(icar_type,"02")==0) || 
              (strcmp(icar_type,"32")==0) || (strcmp(icar_type,"34")==0) ||
              (strcmp(icar_type,"35")==0))
          {
              dataline_car[0] = 0;
              sprintf_s(stmt1, sizeof stmt1, "SELECT nvl(SUM(medrdmg_cover),0)"
                              "  FROM %s:edr_ins_type"
                              " WHERE iendorse=?", sFull);
              $PREPARE prep5 FROM $stmt1;
              $EXECUTE prep5 INTO $dataline_moto[0] USING $iendorse;
              $FREE prep5;
          }
          else
          {
              dataline_moto[0] = 0;
              sprintf_s(stmt1, sizeof stmt1, "SELECT nvl(SUM(medrdmg_cover),0)"
                              "  FROM %s:edr_ins_type"
                              " WHERE iendorse=?", sFull);
              $PREPARE prep6 FROM $stmt1;
              $EXECUTE prep6 INTO $dataline_car[0] USING $iendorse;
              $FREE prep6;
          }

          /* _CC body data */
          if (IsBusiness)
              cvBusiness(fedr_class,typestr);
          else
              cvProtect(fedr_class,typestr);

          strncpy(ch1,ipolicy,18);
          ch1[18]='\0';
          rgu_put_body_string( 2,ch1,LEFT);  /*1*/
          strncpy(ch1,icard,14);
          ch1[14]='\0';
          rgu_put_body_string( 2,ch1,LEFT);  /*2*/
          strncpy(ch1,iendorse,14);
          ch1[14]='\0';
          rgu_put_body_string( 2,ch1,LEFT);  /*3*/

          {
              char buf[13];
              buf[12] = '\0';
              strncpy(buf, nassured, 12);
              rgu_put_body_string(2,buf,LEFT); /*4*/
          }
          rgu_put_body_string(2,typestr,LEFT);    /*5*/
          rgu_put_body_string(2,icar_type,LEFT);  /*6*/
          rgu_put_body_string(2,ibroker,LEFT);    /*7*/

          rgu_put_body_string(2,cm_cdate_str_100(qply_begin),LEFT); /*8*/
          rgu_put_body_string(2,cm_cdate_str_100(qply_end),LEFT);   /*9*/

          for (j=0; j<4; j++)
          {
               if (j==0) {
                   tmpdata = dataline[j]/10000;
                   rfmtdouble(tmpdata, "--,---,--&", buffer);
               }else if(j==1){
                   tmpdata = dataline[j];
                   rfmtdouble(tmpdata,"---,--&",buffer);
               }else{
                   tmpdata = dataline[j];
                   if (j==2) rfmtdouble(tmpdata,"--,---,--&",buffer);
                   else rfmtdouble(tmpdata, "---,--&", buffer);
               }
               rgu_put_body_string(2,buffer,RIGHT);
               pagesum[j] += tmpdata;
          }
          rgu_put_body_string(2,iofficer,LEFT);
          rgu_put_body(2);

          /*--------------------------------------*/
          if (dataline[2] >= 0) {
              for (j=0; j<4; j++)
              {
                   pos_sum[j] += dataline[j];
              }
          }
          else
          {
              for (j=0; j<4; j++)
              {
                   neg_sum[j] += dataline[j];
              }
          }
          /*--------------------------------------*/

          /*--------------------------------------*/
          if (dataline_car[2] >= 0) {
              for (j=0; j<4; j++)
              {
                   pos_sum_car[j] += dataline_car[j];
              }
          } else {
              for (j=0; j<4; j++)
              {
                   neg_sum_car[j] += dataline_car[j];
              }
          }
          /*--------------------------------------*/

          /*--------------------------------------*/
          if (dataline_moto[2] >= 0)
          {
              for (j=0; j<4; j++)
              {
                   pos_sum_moto[j] += dataline_moto[j];
              }
          }
          else
          {
              for (j=0; j<4; j++)
              {
                   neg_sum_moto[j] += dataline_moto[j];
              }
          }
          /*--------------------------------------*/

          TotRows++;
    }
    $CLOSE X2;
    printf("####### totcnt[%d]\n",totcnt);

    /* rgu_put_body(3);
    TotRows++; */

      }
      $CLOSE sscur;
      $FREE  sscur;

    /* page total */
    for (j=0; j<4; j++)
    {
         if (j==0){
             rfmtdouble(pagesum[j], "---,---,--&", buffer);
         }else if(j==1){
             rfmtdouble(pagesum[j],"---,--&",buffer);
         }else {
             if (j==2) rfmtdouble(pagesum[j],"---,---,--&",buffer);
             else rfmtdouble(pagesum[j], "-,---,--&", buffer);
         }
         rgu_put_body_string(4,buffer,RIGHT);
    }
    rgu_put_body(4);
    rgu_put_body(3);
    TotRows+=2;

    /* ���X�p */
    /*-------------------------positive------*/
    for (j=0; j<4; j++)
    {
         if (j==0) {
             tmpsum = pos_sum[j]/10000;
             rfmtdouble(tmpsum, "---,---,--&", buffer); /* �O�B */
         }else if(j==1){
             tmpsum = pos_sum[j];
             rfmtdouble(tmpsum,"---,--&",buffer);  /* ���v�� */
         } else {
             tmpsum = pos_sum[j];
             if (j==2) rfmtdouble(tmpsum,"---,---,--&",buffer); /* �O�O */
             else rfmtdouble(tmpsum, "---,---,--&", buffer);    /* ����O */
         }
         rgu_put_body_string(9,buffer,RIGHT);
    }
    rgu_put_body(9);

    /*-------------------------negative------*/
    for (j=0; j<4; j++)
    {
         if (j==0) {
             tmpsum = neg_sum[j]/10000;
             rfmtdouble(tmpsum, "---,---,--&", buffer);  /* �O�B */
         }else if(j==1){
             tmpsum = neg_sum[j];
             rfmtdouble(tmpsum, "---,--&", buffer); /* ���v�� */
         } else {
             tmpsum = neg_sum[j];
             if (j==2) rfmtdouble(tmpsum,"---,---,--&",buffer);  /* �O�O */
             else rfmtdouble(tmpsum, "---,---,--&", buffer);     /* ����O */
         }
         rgu_put_body_string(10,buffer,RIGHT);
    }
    rgu_put_body(10);

    /*---------------------------------------*/
    rgu_put_body(3);

    /* ������C�L�`���� */
    rfmtlong(totcnt,"###,##&",buffer);
    rgu_put_body_string(12,buffer,RIGHT);
    rgu_put_body(12);
    rgu_put_body(3);

    TotRows += 5;

    rgu_put_body(13);  /* �ťզC */
    rgu_put_body(13);  /* �ťզC */
    TotRows += 2;

    rgu_put_body(5);  /* ���D�C */
    TotRows += 2;

    /* �j��T��[�ۥ�]���� */
    rfmtdouble(Tot_mlia_prem_car_14_pos, "---,---,--&", buffer_car); /* �O  �O */
    rgu_put_body_string(6,buffer_car,RIGHT);

    rgu_put_body_string(6,"0",RIGHT);  /* ��  �� */
    rgu_put_body_string(6,"0",RIGHT);  /* �N�z�O */

    rfmtdouble(Tot_mlia_commi_car_14_pos, "---,---,--&", buffer_car);/* ����O */
    rgu_put_body_string(6,buffer_car,RIGHT);

    /*
    rfmtdouble(Tot_mcompensation_car_14_pos,"---,--&",buffer_car);   * ���v�� *
    rgu_put_body_string(6,buffer_car,RIGHT);
    */

    /* �j��T��[�ۥ�]�t�� */
    rfmtdouble(Tot_mlia_prem_car_14_neg, "---,---,--&", buffer_car); /* �O  �O */
    rgu_put_body_string(6,buffer_car,RIGHT);

    rgu_put_body_string(6,"0",RIGHT);  /* ��  �� */
    rgu_put_body_string(6,"0",RIGHT);  /* �N�z�O */

    rfmtdouble(Tot_mlia_commi_car_14_neg, "---,---,--&", buffer_car);/* ����O */
    rgu_put_body_string(6,buffer_car,RIGHT);

    /*
    rfmtdouble(Tot_mcompensation_car_14_neg,"---,--&",buffer_car);   * ���v�� *
    rgu_put_body_string(6,buffer_car,RIGHT);
    */

    /* �j��T��[�ӷ~]���� */
    rfmtdouble(Tot_mlia_prem_car_15_pos, "---,---,--&", buffer_car); /* �O  �O */
    rgu_put_body_string(6,buffer_car,RIGHT);

    rgu_put_body_string(6,"0",RIGHT);  /* ��  �� */
    rgu_put_body_string(6,"0",RIGHT);  /* �N�z�O */

    rfmtdouble(Tot_mlia_commi_car_15_pos, "---,---,--&", buffer_car);/* ����O */
    rgu_put_body_string(6,buffer_car,RIGHT);

    /*
    rfmtdouble(Tot_mcompensation_car_15_pos,"---,--&",buffer_car);   * ���v�� *
    rgu_put_body_string(6,buffer_car,RIGHT);
    */

    /* �j��T��[�ӷ~]�t�� */
    rfmtdouble(Tot_mlia_prem_car_15_neg, "---,---,--&", buffer_car); /* �O  �O */
    rgu_put_body_string(6,buffer_car,RIGHT);

    rgu_put_body_string(6,"0",RIGHT);  /* ��  �� */
    rgu_put_body_string(6,"0",RIGHT);  /* �N�z�O */

    rfmtdouble(Tot_mlia_commi_car_15_neg, "---,---,--&", buffer_car);/* ����O */
    rgu_put_body_string(6,buffer_car,RIGHT);

    /*
    rfmtdouble(Tot_mcompensation_car_15_neg,"---,--&",buffer_car);   * ���v�� *
    rgu_put_body_string(6,buffer_car,RIGHT);
    */

    /**********************************************/
    /*-------------------------positive_car------*/
    tmpsum_car = pos_sum_car[2];   /* �O�O */
    rfmtdouble(tmpsum_car,"---,---,--&",buffer_car);
    rgu_put_body_string(6,buffer_car,RIGHT);

    rgu_put_body_string(6,"0",RIGHT);  /* ��  �� */
    rgu_put_body_string(6,"0",RIGHT);  /* �N�z�O */

    tmpsum_car = pos_sum_car[3];   /* ����O */
    rfmtdouble(tmpsum_car, "---,---,--&", buffer_car);
    rgu_put_body_string(6,buffer_car,RIGHT);

    /* ���v�� */
    tmpsum_car = pos_sum_car[1];
    rfmtdouble(tmpsum_car,"---,--&",buffer_car);
    /* rgu_put_body_string(6,buffer_car,RIGHT); */

    /*-------------------------negative_car------*/
    tmpsum_car = neg_sum_car[2];   /* �O�O */
    rfmtdouble(tmpsum_car,"---,---,--&",buffer_car);
    rgu_put_body_string(6,buffer_car,RIGHT);

    rgu_put_body_string(6,"0",RIGHT);  /* ��  �� */
    rgu_put_body_string(6,"0",RIGHT);  /* �N�z�O */

    tmpsum_car = neg_sum_car[3];   /* ����O */
    rfmtdouble(tmpsum_car, "---,---,--&", buffer_car);
    rgu_put_body_string(6,buffer_car,RIGHT);

    /* ���v�� */
    tmpsum_car = neg_sum_car[1];
    rfmtdouble(tmpsum_car,"---,--&",buffer_car);
    /* rgu_put_body_string(6,buffer_car,RIGHT); */

    rgu_put_body(6);
    TotRows += 8;

    /**********************************************/

    /*---------------------------------------*/

    /* �j�����[�@�~��]���� */
    rfmtdouble(Tot_mlia_prem_moto_p1_pos, "---,---,--&", buffer_car);   /* �O  �O */
    rgu_put_body_string(7,buffer_car,RIGHT);

    rgu_put_body_string(7,"0",RIGHT);  /* ��  �� */
    rgu_put_body_string(7,"0",RIGHT);  /* �N�z�O */

    rfmtdouble(Tot_mlia_commi_moto_p1_pos, "---,---,--&", buffer_car);  /* ����O */
    rgu_put_body_string(7,buffer_car,RIGHT);

    /*
    rfmtdouble(Tot_mcompensation_moto_p1_pos,"---,--&",buffer_car);     * ���v�� *
    rgu_put_body_string(7,buffer_car,RIGHT);
    */

    /* �j�����[�@�~��]�t�� */
    rfmtdouble(Tot_mlia_prem_moto_p1_neg, "---,---,--&", buffer_car);   /* �O  �O */
    rgu_put_body_string(7,buffer_car,RIGHT);

    rgu_put_body_string(7,"0",RIGHT);  /* ��  �� */
    rgu_put_body_string(7,"0",RIGHT);  /* �N�z�O */

    rfmtdouble(Tot_mlia_commi_moto_p1_neg, "---,---,--&", buffer_car);  /* ����O */
    rgu_put_body_string(7,buffer_car,RIGHT);

    /*
    rfmtdouble(Tot_mcompensation_moto_p1_neg,"---,--&",buffer_car);     * ���v�� *
    rgu_put_body_string(7,buffer_car,RIGHT);
    */

    /* �j�����[�G�~��]���� */
    rfmtdouble(Tot_mlia_prem_moto_p2_pos, "---,---,--&", buffer_car);   /* �O  �O */
    rgu_put_body_string(7,buffer_car,RIGHT);

    rgu_put_body_string(7,"0",RIGHT);  /* ��  �� */
    rgu_put_body_string(7,"0",RIGHT);  /* �N�z�O */

    rfmtdouble(Tot_mlia_commi_moto_p2_pos, "---,---,--&", buffer_car);  /* ����O */
    rgu_put_body_string(7,buffer_car,RIGHT);

    /*
    rfmtdouble(Tot_mcompensation_moto_p2_pos,"---,--&",buffer_car);     * ���v�� *
    rgu_put_body_string(7,buffer_car,RIGHT);
    */

    /* �j�����[�G�~��]�t�� */
    rfmtdouble(Tot_mlia_prem_moto_p2_neg, "---,---,--&", buffer_car);   /* �O  �O */
    rgu_put_body_string(7,buffer_car,RIGHT);

    rgu_put_body_string(7,"0",RIGHT);  /* ��  �� */
    rgu_put_body_string(7,"0",RIGHT);  /* �N�z�O */

    rfmtdouble(Tot_mlia_commi_moto_p2_neg, "---,---,--&", buffer_car);  /* ����O */
    rgu_put_body_string(7,buffer_car,RIGHT);

    /*
    rfmtdouble(Tot_mcompensation_moto_p2_neg,"---,--&",buffer_car);     * ���v�� *
    rgu_put_body_string(7,buffer_car,RIGHT);
    */

    rgu_put_body(7);
    TotRows += 6;

   /* �j��L�q��[�@�~��]���� */
    rfmtdouble(Tot_mlia_prem_moto35_p1_pos, "---,---,--&", buffer_car);   /* �O  �O */
    rgu_put_body_string(16,buffer_car,RIGHT);

    rgu_put_body_string(16,"0",RIGHT);  /* ��  �� */
    rgu_put_body_string(16,"0",RIGHT);  /* �N�z�O */

    rfmtdouble(Tot_mlia_commi_moto35_p1_pos, "---,---,--&", buffer_car);  /* ����O */
    rgu_put_body_string(16,buffer_car,RIGHT);

    /* �j��L�q��[�@�~��]�t�� */
    rfmtdouble(Tot_mlia_prem_moto35_p1_neg, "---,---,--&", buffer_car);   /* �O  �O */
    rgu_put_body_string(16,buffer_car,RIGHT);

    rgu_put_body_string(16,"0",RIGHT);  /* ��  �� */
    rgu_put_body_string(16,"0",RIGHT);  /* �N�z�O */

    rfmtdouble(Tot_mlia_commi_moto35_p1_neg, "---,---,--&", buffer_car);  /* ����O */
    rgu_put_body_string(16,buffer_car,RIGHT);

   /* �j��L�q��[�G�~��]���� */
    rfmtdouble(Tot_mlia_prem_moto35_p2_pos, "---,---,--&", buffer_car);   /* �O  �O */
    rgu_put_body_string(16,buffer_car,RIGHT);

    rgu_put_body_string(16,"0",RIGHT);  /* ��  �� */
    rgu_put_body_string(16,"0",RIGHT);  /* �N�z�O */

    rfmtdouble(Tot_mlia_commi_moto35_p2_pos, "---,---,--&", buffer_car);  /* ����O */
    rgu_put_body_string(16,buffer_car,RIGHT);

    /* �j��L�q��[�G�~��]�t�� */
    rfmtdouble(Tot_mlia_prem_moto35_p2_neg, "---,---,--&", buffer_car);   /* �O  �O */
    rgu_put_body_string(16,buffer_car,RIGHT);

    rgu_put_body_string(16,"0",RIGHT);  /* ��  �� */
    rgu_put_body_string(16,"0",RIGHT);  /* �N�z�O */

    rfmtdouble(Tot_mlia_commi_moto35_p2_neg, "---,---,--&", buffer_car);  /* ����O */
    rgu_put_body_string(16,buffer_car,RIGHT);


   /* �j��L�q��[�T�~��]���� */
    rfmtdouble(Tot_mlia_prem_moto35_p3_pos, "---,---,--&", buffer_car);   /* �O  �O */
    rgu_put_body_string(16,buffer_car,RIGHT);

    rgu_put_body_string(16,"0",RIGHT);  /* ��  �� */
    rgu_put_body_string(16,"0",RIGHT);  /* �N�z�O */

    rfmtdouble(Tot_mlia_commi_moto35_p3_pos, "---,---,--&", buffer_car);  /* ����O */
    rgu_put_body_string(16,buffer_car,RIGHT);

    /* �j��L�q��[�T�~��]�t�� */
    rfmtdouble(Tot_mlia_prem_moto35_p3_neg, "---,---,--&", buffer_car);   /* �O  �O */
    rgu_put_body_string(16,buffer_car,RIGHT);

    rgu_put_body_string(16,"0",RIGHT);  /* ��  �� */
    rgu_put_body_string(16,"0",RIGHT);  /* �N�z�O */

    rfmtdouble(Tot_mlia_commi_moto35_p3_neg, "---,---,--&", buffer_car);  /* ����O */
    rgu_put_body_string(16,buffer_car,RIGHT);

/*
   * �j��L�q��[�|�~��]���� *
    rfmtdouble(Tot_mlia_prem_moto35_p4_pos, "---,---,--&", buffer_car);   * �O  �O *
    rgu_put_body_string(16,buffer_car,RIGHT);

    rgu_put_body_string(16,"0",RIGHT);  * ��  �� *
    rgu_put_body_string(16,"0",RIGHT);  * �N�z�O *

    rfmtdouble(Tot_mlia_commi_moto35_p4_pos, "---,---,--&", buffer_car);  * ����O *
    rgu_put_body_string(16,buffer_car,RIGHT);

    * �j��L�q��[�|�~��]�t�� *
    rfmtdouble(Tot_mlia_prem_moto35_p4_neg, "---,---,--&", buffer_car);   * �O  �O *
    rgu_put_body_string(16,buffer_car,RIGHT);

    rgu_put_body_string(16,"0",RIGHT);  * ��  �� *
    rgu_put_body_string(16,"0",RIGHT);  * �N�z�O *

    rfmtdouble(Tot_mlia_commi_moto35_p4_neg, "---,---,--&", buffer_car);  * ����O *
    rgu_put_body_string(16,buffer_car,RIGHT);


   * �j��L�q��[���~��]���� *
    rfmtdouble(Tot_mlia_prem_moto35_p5_pos, "---,---,--&", buffer_car);   * �O  �O *
    rgu_put_body_string(16,buffer_car,RIGHT);

    rgu_put_body_string(16,"0",RIGHT);  * ��  �� *
    rgu_put_body_string(16,"0",RIGHT);  * �N�z�O *

    rfmtdouble(Tot_mlia_commi_moto35_p5_pos, "---,---,--&", buffer_car);  * ����O *
    rgu_put_body_string(16,buffer_car,RIGHT);

    * �j��L�q��[���~��]�t�� *
    rfmtdouble(Tot_mlia_prem_moto35_p5_neg, "---,---,--&", buffer_car);   * �O  �O *
    rgu_put_body_string(16,buffer_car,RIGHT);

    rgu_put_body_string(16,"0",RIGHT);  * ��  �� *
    rgu_put_body_string(16,"0",RIGHT);  * �N�z�O *

    rfmtdouble(Tot_mlia_commi_moto35_p5_neg, "---,---,--&", buffer_car);  * ����O *
    rgu_put_body_string(16,buffer_car,RIGHT);
*/
    rgu_put_body(16);
/*    TotRows += 10;*/
    TotRows += 6;
    /***********************************************/
    /*-------------------------positive_moto------*/
    tmpsum_moto = pos_sum_moto[2];   /* �O�O */
    rfmtdouble(tmpsum_moto,"---,---,--&",buffer_moto);
    rgu_put_body_string(17,buffer_moto,RIGHT);

    rgu_put_body_string(17,"0",RIGHT);  /* ��  �� */
    rgu_put_body_string(17,"0",RIGHT);  /* �N�z�O */

    tmpsum_moto = pos_sum_moto[3];  /* ����O */
    rfmtdouble(tmpsum_moto, "---,---,--&", buffer_moto);
    rgu_put_body_string(17,buffer_moto,RIGHT);

    tmpsum_moto = pos_sum_moto[1];  /* ���v�� */
    rfmtdouble(tmpsum_moto,"---,--&",buffer_moto);
    /* rgu_put_body_string(7,buffer_moto,RIGHT); */

    /*-------------------------negative_moto------*/
    tmpsum_moto = neg_sum_moto[2];   /* �O�O */
    rfmtdouble(tmpsum_moto,"---,---,--&",buffer_moto);
    rgu_put_body_string(17,buffer_moto,RIGHT);

    rgu_put_body_string(17,"0",RIGHT);  /* ��  �� */
    rgu_put_body_string(17,"0",RIGHT);  /* �N�z�O */

    tmpsum_moto = neg_sum_moto[3];  /* ����O */
    rfmtdouble(tmpsum_moto, "---,---,--&", buffer_moto);
    rgu_put_body_string(17,buffer_moto,RIGHT);

    tmpsum_moto = neg_sum_moto[1];  /* ���v�� */
    rfmtdouble(tmpsum_moto,"---,--&",buffer_moto);
    /* rgu_put_body_string(7,buffer_moto,RIGHT); */

    rgu_put_body(17);
    TotRows += 2;
    /***********************************************/
    /*
    rgu_put_body(7);
    TotRows += 8;*/

    /* �`�p */
    /*-------------------------total------*/
    tmpsum = pos_sum[2] + neg_sum[2];  /* �O�O   */
    rfmtdouble(tmpsum,"---,---,--&",buffer);
    rgu_put_body_string(8,buffer,RIGHT);

    rgu_put_body_string(8,"0",RIGHT); /* ����   */
    rgu_put_body_string(8,"0",RIGHT); /* �N�z�O */

    tmpsum = pos_sum[3] + neg_sum[3];  /* ����O */
    rfmtdouble(tmpsum,"---,---,--&",buffer);
    rgu_put_body_string(8,buffer,RIGHT);

    tmpsum = pos_sum[1] + neg_sum[1];  /* ���v�� */
    rfmtdouble(tmpsum,"---,---,--&",buffer);
    /* rgu_put_body_string(8,buffer,RIGHT); */

    /*-------------------------negative------*
    tmpsum = neg_sum[2];  * �O�O   *
    rfmtdouble(tmpsum,"---,---,--&",buffer);
    rgu_put_body_string(8,buffer,RIGHT);

    rgu_put_body_string(8,"0",RIGHT); * ����   *
    rgu_put_body_string(8,"0",RIGHT); * �N�z�O *

    tmpsum = neg_sum[3];  * ����O *
    rfmtdouble(tmpsum,"---,---,--&",buffer);
    rgu_put_body_string(8,buffer,RIGHT);

    tmpsum = neg_sum[1];  * ���v�� *
    rfmtdouble(tmpsum,"---,---,--&",buffer);
    * rgu_put_body_string(8,buffer,RIGHT); *
    ******************************************/

    rgu_put_body(8);
    TotRows += 1;


    /*1080912006_SC2 �s�Wñ��������ˮ�*/
    IfirstGlsForIns = get_gls_for_ins(inf_plydate, "C", "E", &rtncode, v_sMsg);
    if( rtncode != M_CM_OK) return rtncode;
    strcpy(kacctitem,    "");
    strcpy(kclsfyitem,    "");
    strcpy(eacc_title,    "");
    mdeal =0;    
    IcurrGlsForIns = IfirstGlsForIns;
    iseq = 0;
    while( IcurrGlsForIns)
    {
        printf("iseq[%d]kacctitem    [%s],"
               "kclsfyitem   [%s],"
               "eacc_title   [%s],"
               "mdeal        [%ld]\n",iseq,
                IcurrGlsForIns->kacctitem,
                IcurrGlsForIns->kclsfyitem,
                IcurrGlsForIns->eacc_title,
                IcurrGlsForIns->mdeal);
                
        strcpy(kacctitem,IcurrGlsForIns->kacctitem);
        strcpy(kclsfyitem,IcurrGlsForIns->kclsfyitem);
        strcpy(eacc_title,IcurrGlsForIns->eacc_title);
        mdeal =IcurrGlsForIns->mdeal;
        
        
        $INSERT INTO tmp_gl_list (iseq,kacctitem,kclsfyitem,eacc_title,mdeal)
              VALUES ($iseq,  $kacctitem,  $kclsfyitem,  $eacc_title,  $mdeal);
        iseq++;             
        IcurrGlsForIns = IcurrGlsForIns->next;
    }
    strcpy(kacctitem,    "");
    strcpy(kclsfyitem,    "");
    strcpy(eacc_title,    "");
    
    lng_Tot_mlia_prem_car_14=lng_Tot_mlia_commi_car_14=lng_Tot_mlia_prem_car_15=lng_Tot_mlia_commi_car_15=0;
    lng_Tot_mlia_prem_moto_p1=lng_Tot_mlia_commi_moto_p1=lng_Tot_mlia_prem_moto_p2= lng_Tot_mlia_commi_moto_p2=0;
    
    lng_Tot_mlia_prem_moto35_p1=lng_Tot_mlia_commi_moto35_p1=lng_Tot_mlia_prem_moto35_p2=lng_Tot_mlia_commi_moto35_p2=0; 
    lng_Tot_mlia_prem_moto35_p3=lng_Tot_mlia_commi_moto35_p3=0;
/*    
    lng_Tot_mlia_prem_moto35_p4=lng_Tot_mlia_commi_moto35_p4=0; 
    lng_Tot_mlia_prem_moto35_p5=lng_Tot_mlia_commi_moto35_p5=0;    
*/
    mdeal =0;
    rgu_put_body(13);                TotRows+=1;  /* �ťզC */
    rgu_put_body(14);                TotRows+=3;
    printf("*****************************************************************\n");
    $DECLARE gls_cur CURSOR FOR
      SELECT trim(kacctitem),trim(kclsfyitem),trim(eacc_title),mdeal
        INTO $kacctitem,     $kclsfyitem,      $eacc_title,     $mdeal
        FROM tmp_gl_list
       WHERE kclsfyitem in ('1400','1500','1600','1601','3210','3220','3230')/*,'3240','3250')*/
    ORDER BY iseq;
    $OPEN gls_cur;
    for(;;)
    {
         $FETCH gls_cur ;
         printf("kacctitem[%s]",kacctitem);
         printf("kclsfyitem[%s]\n",kclsfyitem);
         printf("mdeal[%ld]\n",mdeal);
         if (SQLCODE == SQLNOTFOUND) break;
    
        /*�|�p���4100�O�O���J/5103����O��X	�|�p�l��	��l�ئW��	�������B	�`�b���B	�t�B
         �]���^�Ǿ�i�ǲ����ӡA�ݬD�X�j���I���l�� 4100 �O�O���J 5103 ����O��X
         1400-�j��ۥΨT���I             1500-�j��ӷ~�T���I           1600-�j������@�~��            1601-�j������G�~��*/
        rgu_put_body_string(15,kacctitem,1);
        rgu_put_body_string(15,kclsfyitem,1);
        rgu_put_body_string(15,eacc_title,1);
        lDiff_ca_gl=0;
        
        strcpy(buf_GLS, refmtamt(mdeal,MILLIONTH));
        if (strncmp(kclsfyitem, "1400", 4) ==0)
        {
            if (strncmp(kacctitem, "4100", 4) ==0)
            {
                printf("Tot_mlia_prem_car_14_pos[%ld]\n",Tot_mlia_prem_car_14_pos);
                printf("Tot_mlia_prem_car_14_neg[%ld]\n",Tot_mlia_prem_car_14_neg);
                lng_Tot_mlia_prem_car_14 = Tot_mlia_prem_car_14_pos + Tot_mlia_prem_car_14_neg ;
                lDiff_ca_gl = abs(lng_Tot_mlia_prem_car_14) - mdeal ;  /* ������ȦA�۴�(�]��mdeal�]�O���L�����)*/
                printf("lDiff_ca_gl[%ld]\n",lDiff_ca_gl);
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));                
                strcpy(bufC2_14, refmtamt(abs(lng_Tot_mlia_prem_car_14),MILLIONTH));
                
                rgu_put_body_string(15,bufC2_14,1);
                rgu_put_body_string(15,buf_GLS,1);
                rgu_put_body_string(15,buf_Diff,1);
            }
            else
            {
            	lng_Tot_mlia_commi_car_14 = Tot_mlia_commi_car_14_pos + Tot_mlia_commi_car_14_neg; 
                lDiff_ca_gl = abs(lng_Tot_mlia_commi_car_14) - mdeal ;
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));
                strcpy(bufC3_14, refmtamt(abs(lng_Tot_mlia_commi_car_14),MILLIONTH));
                
                rgu_put_body_string(15,bufC3_14,1);
                rgu_put_body_string(15,buf_GLS,1);
                rgu_put_body_string(15,buf_Diff,1);
            }
        }
        else if (strncmp(kclsfyitem, "1500", 4) ==0)
        {
            
            if (strncmp(kacctitem, "4100", 4) ==0)
            {
            	lng_Tot_mlia_prem_car_15 = Tot_mlia_prem_car_15_pos + Tot_mlia_prem_car_15_neg;
                lDiff_ca_gl = abs(lng_Tot_mlia_prem_car_15) - mdeal ;
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));
                strcpy(bufC2_15, refmtamt(abs(lng_Tot_mlia_prem_car_15),MILLIONTH));
                
                rgu_put_body_string(15,bufC2_15,1);
                rgu_put_body_string(15,buf_GLS,1);
                rgu_put_body_string(15,buf_Diff,1);
            }
            else
            {
            	lng_Tot_mlia_commi_car_15 = Tot_mlia_commi_car_15_pos + Tot_mlia_commi_car_15_neg;
                lDiff_ca_gl = abs(lng_Tot_mlia_commi_car_15) - mdeal ;
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));
                strcpy(bufC3_15, refmtamt(abs(lng_Tot_mlia_commi_car_15),MILLIONTH));
                
                rgu_put_body_string(15,bufC3_15,1);
                rgu_put_body_string(15,buf_GLS,1);
                rgu_put_body_string(15,buf_Diff,1);
            }
        }
        else if (strncmp(kclsfyitem, "1600", 4) ==0)
        {
            if (strncmp(kacctitem, "4100", 4) ==0)
            {
            	lng_Tot_mlia_prem_moto_p1 = Tot_mlia_prem_moto_p1_pos + Tot_mlia_prem_moto_p1_neg;
                lDiff_ca_gl = abs(lng_Tot_mlia_prem_moto_p1) - mdeal ;
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));
                strcpy(bufM2_P1, refmtamt(abs(lng_Tot_mlia_prem_moto_p1),MILLIONTH));
                
                rgu_put_body_string(15,bufM2_P1,1);
                rgu_put_body_string(15,buf_GLS,1);
                rgu_put_body_string(15,buf_Diff,1);
            }
            else
            {
            	lng_Tot_mlia_commi_moto_p1 = Tot_mlia_commi_moto_p1_pos + Tot_mlia_commi_moto_p1_neg;
                lDiff_ca_gl = abs(lng_Tot_mlia_commi_moto_p1) - mdeal ;
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));
                strcpy(bufM3_P1, refmtamt(abs(lng_Tot_mlia_commi_moto_p1),MILLIONTH));
                
                rgu_put_body_string(15,bufM3_P1,1);
                rgu_put_body_string(15,buf_GLS,1);
                rgu_put_body_string(15,buf_Diff,1);
            }
        }
        else if (strncmp(kclsfyitem, "1601", 4) ==0)
        {
            if (strncmp(kacctitem, "4100", 4) ==0)
            {
            	lng_Tot_mlia_prem_moto_p2 = Tot_mlia_prem_moto_p2_pos + Tot_mlia_prem_moto_p2_neg;
                lDiff_ca_gl = abs(lng_Tot_mlia_prem_moto_p2) - mdeal ;
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));
                strcpy(bufM2_P2, refmtamt(abs(lng_Tot_mlia_prem_moto_p2),MILLIONTH));
                
                rgu_put_body_string(15,bufM2_P2,1);
                rgu_put_body_string(15,buf_GLS,1);
                rgu_put_body_string(15,buf_Diff,1);
            }
            else
            {
            	lng_Tot_mlia_commi_moto_p2 = Tot_mlia_commi_moto_p2_pos + Tot_mlia_commi_moto_p2_neg;
                lDiff_ca_gl = abs(lng_Tot_mlia_commi_moto_p2) - mdeal ;
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));
                strcpy(bufM3_P2, refmtamt(abs(lng_Tot_mlia_commi_moto_p2),MILLIONTH));
                
                rgu_put_body_string(15,bufM3_P2,1);
                rgu_put_body_string(15,buf_GLS,1);
                rgu_put_body_string(15,buf_Diff,1);
            }
        } 
        else if (strncmp(kclsfyitem, "3210", 4) ==0)
        {
            if (strncmp(kacctitem, "4100", 4) ==0)
            {
            	lng_Tot_mlia_prem_moto35_p1 = Tot_mlia_prem_moto35_p1_pos + Tot_mlia_prem_moto35_p1_neg;
                lDiff_ca_gl = abs(lng_Tot_mlia_prem_moto35_p1) - mdeal ;
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));
                strcpy(bufM2_P1_35, refmtamt(abs(lng_Tot_mlia_prem_moto35_p1),MILLIONTH));
                
                rgu_put_body_string(15,bufM2_P1_35,1);
                rgu_put_body_string(15,buf_GLS,1);
                rgu_put_body_string(15,buf_Diff,1);
            }
            else
            {
            	lng_Tot_mlia_commi_moto35_p1 = Tot_mlia_commi_moto35_p1_pos + Tot_mlia_commi_moto35_p1_neg;
                lDiff_ca_gl = abs(lng_Tot_mlia_commi_moto35_p1) - mdeal ;
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));
                strcpy(bufM3_P1_35, refmtamt(abs(lng_Tot_mlia_commi_moto35_p1),MILLIONTH));
                
                rgu_put_body_string(15,bufM3_P1_35,1);
                rgu_put_body_string(15,buf_GLS,1);
                rgu_put_body_string(15,buf_Diff,1);
            }
        }       
        else if (strncmp(kclsfyitem, "3220", 4) ==0)
        {
            if (strncmp(kacctitem, "4100", 4) ==0)
            {
            	lng_Tot_mlia_prem_moto35_p2 = Tot_mlia_prem_moto35_p2_pos + Tot_mlia_prem_moto35_p2_neg;
                lDiff_ca_gl = abs(lng_Tot_mlia_prem_moto35_p2) - mdeal ;
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));
                strcpy(bufM2_P2_35, refmtamt(abs(lng_Tot_mlia_prem_moto35_p2),MILLIONTH));
                
                rgu_put_body_string(15,bufM2_P2_35,1);
                rgu_put_body_string(15,buf_GLS,1);
                rgu_put_body_string(15,buf_Diff,1);
            }
            else
            {
            	lng_Tot_mlia_commi_moto35_p2 = Tot_mlia_commi_moto35_p2_pos + Tot_mlia_commi_moto35_p2_neg;
                lDiff_ca_gl = abs(lng_Tot_mlia_commi_moto35_p2) - mdeal ;
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));
                strcpy(bufM3_P2_35, refmtamt(abs(lng_Tot_mlia_commi_moto35_p2),MILLIONTH));
                
                rgu_put_body_string(15,bufM3_P2_35,1);
                rgu_put_body_string(15,buf_GLS,1);
                rgu_put_body_string(15,buf_Diff,1);
            }
        }  
        else if (strncmp(kclsfyitem, "3230", 4) ==0)
        {
            if (strncmp(kacctitem, "4100", 4) ==0)
            {
            	lng_Tot_mlia_prem_moto35_p3 = Tot_mlia_prem_moto35_p3_pos + Tot_mlia_prem_moto35_p3_neg;
                lDiff_ca_gl = abs(lng_Tot_mlia_prem_moto35_p3) - mdeal ;
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));
                strcpy(bufM2_P3_35, refmtamt(abs(lng_Tot_mlia_prem_moto35_p3),MILLIONTH));
                
                rgu_put_body_string(15,bufM2_P3_35,1);
                rgu_put_body_string(15,buf_GLS,1);
                rgu_put_body_string(15,buf_Diff,1);
            }
            else
            {
            	lng_Tot_mlia_commi_moto35_p3 = Tot_mlia_commi_moto35_p3_pos + Tot_mlia_commi_moto35_p3_neg;
                lDiff_ca_gl = abs(lng_Tot_mlia_commi_moto35_p3) - mdeal ;
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));
                strcpy(bufM3_P3_35, refmtamt(abs(lng_Tot_mlia_commi_moto35_p3),MILLIONTH));
                
                rgu_put_body_string(15,bufM3_P3_35,1);
                rgu_put_body_string(15,buf_GLS,1);
                rgu_put_body_string(15,buf_Diff,1);
            }
        }    
/*        else if (strncmp(kclsfyitem, "3240", 4) ==0)
        {
            if (strncmp(kacctitem, "4100", 4) ==0)
            {
            	lng_Tot_mlia_prem_moto35_p4 = Tot_mlia_prem_moto35_p4_pos + Tot_mlia_prem_moto35_p4_neg;
                lDiff_ca_gl = abs(lng_Tot_mlia_prem_moto35_p4) - mdeal ;
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));
                strcpy(bufM2_P4_35, refmtamt(abs(lng_Tot_mlia_prem_moto35_p4),MILLIONTH));
                
                rgu_put_body_string(15,bufM2_P4_35,1);
                rgu_put_body_string(15,buf_GLS,1);
                rgu_put_body_string(15,buf_Diff,1);
            }
            else
            {
            	lng_Tot_mlia_commi_moto35_p4 = Tot_mlia_commi_moto35_p4_pos + Tot_mlia_commi_moto35_p4_neg;
                lDiff_ca_gl = abs(lng_Tot_mlia_commi_moto35_p4) - mdeal ;
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));
                strcpy(bufM3_P4_35, refmtamt(abs(lng_Tot_mlia_commi_moto35_p4),MILLIONTH));
                
                rgu_put_body_string(15,bufM3_P4_35,1);
                rgu_put_body_string(15,buf_GLS,1);
                rgu_put_body_string(15,buf_Diff,1);
            }
        }    
        else if (strncmp(kclsfyitem, "3250", 4) ==0)
        {
            if (strncmp(kacctitem, "4100", 4) ==0)
            {
            	lng_Tot_mlia_prem_moto35_p5 = Tot_mlia_prem_moto35_p5_pos + Tot_mlia_prem_moto35_p5_neg;
                lDiff_ca_gl = abs(lng_Tot_mlia_prem_moto35_p5) - mdeal ;
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));
                strcpy(bufM2_P5_35, refmtamt(abs(lng_Tot_mlia_prem_moto35_p5),MILLIONTH));
                
                rgu_put_body_string(15,bufM2_P5_35,1);
                rgu_put_body_string(15,buf_GLS,1);
                rgu_put_body_string(15,buf_Diff,1);
            }
            else
            {
            	lng_Tot_mlia_commi_moto35_p5 = Tot_mlia_commi_moto35_p5_pos + Tot_mlia_commi_moto35_p5_neg;
                lDiff_ca_gl = abs(lng_Tot_mlia_commi_moto35_p5) - mdeal ;
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));
                strcpy(bufM3_P5_35, refmtamt(abs(lng_Tot_mlia_commi_moto35_p5),MILLIONTH));
                
                rgu_put_body_string(15,bufM3_P5_35,1);
                rgu_put_body_string(15,buf_GLS,1);
                rgu_put_body_string(15,buf_Diff,1);
            }
        }    
*/                                            
        rgu_put_body(15);                TotRows++;
    }
    $CLOSE gls_cur;
    $FREE  gls_cur;
    printf("=================gls================================\n");
    
    return M_CM_OK;

errexit:
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/*--------------------------------------------------------------------*/
long car403_body1()
{       
  $char stmt_buf[1024];
  $char ipolicy[POLICY_NUM_1],icard[CARD_NUM],fcard_class[2];
  $char iofficer[EMPLOYEE_ID],iquota[7];
  $char nassured[ASSURED_NAME];
  $char iendorse[ENDORSE_NUM],nbranch[21];
  char  ch1[21],abn_brk[3];
  char  where_stat[50];
  $char sFull[31], branch[3], stmt1[512];

  int  i, j, totcnt;

  $WHENEVER SQLERROR GOTO errexit;

  /*----------initialize-----*/
  TotRows=0;
  linenum=0;
  totcnt=0;
 
  for(i=0;i<4;i++) {
       Brk_mpure_prem[i]=Tot_mpure_prem[i]=0;
       Brk_mextra_charge[i]=Tot_mextra_charge[i]=0;
       Brk_mply_prem[i]=Tot_mply_prem[i]=0;
       Brk_minu_prem[i]=Tot_minu_prem[i]=0;
   }

  /*-------------------------*/

  strcpy(cplydate,cm_to_infdate(plydate));
  strcpy(pre_branch,"  ");
  printf("###### cplydate[%s]\n",cplydate);

  stmt_buf[0] = '\0';
  where_stat[0] = '\0';
  if (flag_check == 1)   /*** ���ˮ֥� ***/
  {
       where_stat[0] = '\0';
  }
  else
  {
       strcpy(where_stat, "AND a.dedr_close is not null ");
  }

      $DECLARE s1cur CURSOR FOR
        SELECT branch
          FROM servertbl
         WHERE branch != 'S1'
         ORDER BY branch;
      $OPEN s1cur;
      for(;;)
      {
      $FETCH s1cur INTO $branch;
       if (SQLCODE == SQLNOTFOUND) break;
       strcpy(sFull,get_full_dbname(branch));

  sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT a.ipolicy, a.icard, a.iendorse, a.iofficer,"
                    "       a.iquota[1,4], b.nassured[1,20], c.medrpure_prem,"
                    "       c.medrins_prem, c.iproduct[4,5]"
                    "  FROM %s:edr_relation a ,%s:endorsement b,%s:edr_ins_type c "
                    " WHERE fcard_class = '1' "
                    "   AND a.dendorse = ? "
                    "   AND a.iendorse = b.iendorse "
                    "   AND a.iendorse = c.iendorse "
                    "   AND a.iendorse MATCHES ? "
                    " %s "
                    "ORDER BY a.iendorse", sFull, sFull, sFull, where_stat);

  printf("stmt_buf[%s]\n",stmt_buf);
  $PREPARE CUR_STMT11 FROM $stmt_buf;
  $DECLARE X21 CURSOR FOR  CUR_STMT11;
  $OPEN X21 USING $cplydate , $sIbranchIcomp;
  for (;;)
  {
        $FETCH X21 INTO $ipolicy,$icard,$iendorse,$iofficer,$iquota,
                        $nassured,$Mpure_prem,$Mlia_prem,$iacc_type;
        
        if (SQLCODE == SQLNOTFOUND) break;

        if (Mpure_prem==0) {
            Mextra_charge=0;
            Minu_prem = Mlia_prem;
        }
        else {
            Mextra_charge = Mlia_prem - Mpure_prem;
            Minu_prem = 0;
        }
        iquota[4]='\0';
        strcat(iquota,"00");
        $SELECT nbranch INTO $nbranch
           FROM sa_branch_type
          WHERE ibranch = $iquota;

printf("##### ply[%s] edr[%s]\n",ipolicy,iendorse);
        
        if (strncmp(pre_branch,"  ", 2) == 0) {
            strncpy(pre_branch, iendorse, 2);
            pre_branch[2]='\0';
            $SELECT nchi_full INTO $nchi_abv FROM branch
              WHERE ibranch = $pre_branch;
            rgu_put_body_string(1,pre_branch,1);
            rgu_put_body_string(1,nchi_abv,1);
            rgu_put_body(1);
        }
        else if (strncmp(pre_branch, iendorse,2) != 0) {
            car403_tot();
            rgu_put_body(NEXTPAGE);
            strncpy(pre_branch, iendorse, 2);
            pre_branch[2]='\0';
            $SELECT nchi_full INTO $nchi_abv FROM branch
              WHERE ibranch = $pre_branch;
            rgu_put_body_string(1,pre_branch,1);
            rgu_put_body_string(1,nchi_abv,1);
            rgu_put_body(1);
        }
        else {
            linenum++;
            totcnt++;
        }

        strncpy(ch1,icard,14);
        ch1[14]='\0';
        rgu_put_body_string( 2,ch1,LEFT);       /*1*/
        strncpy(ch1,iendorse,14);
        ch1[14]='\0';
        rgu_put_body_string( 2,ch1,LEFT);       /*2*/
        rgu_put_body_string(2,nassured,LEFT);   /*3*/
        rgu_put_body_string(2,nbranch,LEFT);    /*4*/
        rgu_put_body_string(2,iofficer,LEFT);   /*5*/

        car403_dtl();
  }
  $CLOSE X21;
      }
      $CLOSE s1cur;
      $FREE  s1cur;

  car403_tot();

  return M_CM_OK;

errexit:
  EWRITE(userid,SQLCODE,sqlca.sqlerrm);
  return SQLCODE;
}
/*--------------------------------------------------------------------*/
car403_dtl()
{
   char buf1[20], buf2[20], buf3[20], buf4[20];
   char ch1[14], ch2[9];
   char buffer[30];
   double dtl_mpure_prem[4],dtl_mextra_charge[4],dtl_mply_prem[4]; 
   double dtl_pextra_charge[4];
   int    i,iacc;

   if ( linenum > 50 ) {
      car403_brk();
      rgu_put_body(NEXTPAGE);
      linenum=0;
   }
  
   for (i=0;i<3;i++) {
        dtl_mpure_prem[i]=dtl_mextra_charge[i]=dtl_mply_prem[i]=0;
        dtl_pextra_charge[i]=0;
   }

   if (Mlia_prem == 0 || Mpure_prem == 0)
       Pextra_charge = 0;
   else
       Pextra_charge = Mextra_charge / Mlia_prem * 100;

   iacc=atoi(iacc_type);
   iacc=iacc-14;
   for(i=0;i<3;i++) {
       if (i==iacc) {
           dtl_mpure_prem[i]=Mpure_prem;
           dtl_mextra_charge[i]=Mextra_charge;
           dtl_mply_prem[i]=Mlia_prem;
           dtl_pextra_charge[i]=Pextra_charge;
           Brk_mpure_prem[i] += Mpure_prem;
           Brk_mextra_charge[i] += Mextra_charge;
           Brk_mply_prem[i] += Mlia_prem;
           Brk_minu_prem[i] += Minu_prem;
       }
   }
      
   for (i=0;i<3;i++) {
       rfmtdouble(dtl_mpure_prem[i],"--,---,---.---",buf1);     
       rfmtdouble(dtl_mextra_charge[i],"--,---,---.---",buf2);     
       rfmtdouble(dtl_pextra_charge[i],"---.----",buf3);     
       rfmtdouble(dtl_mply_prem[i], "-,---,---,--&", buf4); 
       rgu_put_body_string( 2,buf1,2); /*6�«O�O*/
       rgu_put_body_string( 2,buf2,2); /*7���[�O��*/
       rgu_put_body_string( 2,buf3,2); /*8���[�O�βv*/
       rgu_put_body_string( 2,buf4,2); /*9ñ��O�O*/
   }
   rgu_put_body( 2);
   TotRows++;
}
/*--------------------------------------------------------------------*/
car403_brk()
{
   char buf1[20], buf2[20], buf3[20], buf4[20];
   int i;

   rgu_put_body( 3);
   for(i=0;i<3;i++) {
       Tot_mpure_prem[i] += Brk_mpure_prem[i];
       Tot_mextra_charge[i] += Brk_mextra_charge[i];
       Tot_mply_prem[i] += Brk_mply_prem[i];
       Tot_minu_prem[i] += Brk_minu_prem[i];
   }
   for (i=0;i<3;i++) {
       rfmtdouble(Brk_mpure_prem[i],"--,---,---.---",buf1);     
       rfmtdouble(Brk_mextra_charge[i],"--,---,---.---",buf2);     
       if (Brk_mply_prem[i]==0 || Brk_mpure_prem[i]==0)
           Pextra_charge = 0;
       else
           Pextra_charge = Brk_mextra_charge[i]/
                           (Brk_mply_prem[i] - Brk_minu_prem[i]) *100;
       rfmtdouble(Pextra_charge,"---.----",buf3);     
       rfmtdouble(Brk_mply_prem[i], "-,---,---,--&", buf4); 
       rgu_put_body_string( 4,buf1,2); /*6�«O�O*/
       rgu_put_body_string( 4,buf2,2); /*7���[�O��*/
       rgu_put_body_string( 4,buf3,2); /*8���[�O�βv*/
       rgu_put_body_string( 4,buf4,2); /*9ñ��O�O*/
   }
   rgu_put_body( 4);
   rgu_put_body( 3);
   TotRows +=3;

   for(i=0;i<4;i++)
       Brk_mply_prem[i]=Brk_mpure_prem[i]=Brk_mextra_charge[i]=Brk_minu_prem[i]=0;

}
/*--------------------------------------------------------------------*/
car403_tot()
{
   char buf1[20], buf2[20], buf3[20], buf4[20];
   int i;

   car403_brk();

   for(i=0;i<3;i++) {
       Tot_mpure_prem[3] += Tot_mpure_prem[i];
       Tot_mextra_charge[3] += Tot_mextra_charge[i];
       Tot_mply_prem[3] += Tot_mply_prem[i];
       Tot_minu_prem[3] += Tot_minu_prem[i];
   }
   for (i=0;i<3;i++) {
       rfmtdouble(Tot_mpure_prem[i],"--,---,---.---",buf1);     
       rfmtdouble(Tot_mextra_charge[i],"--,---,---.---",buf2);     
       if (Tot_mply_prem[i]==0 || Tot_mpure_prem[i]==0)
           Pextra_charge = 0;
       else
           Pextra_charge = Tot_mextra_charge[i]/
                           (Tot_mply_prem[i] - Tot_minu_prem[i]) *100;
       rfmtdouble(Pextra_charge,"---.----",buf3);     
       rfmtdouble(Tot_mply_prem[i], "-,---,---,--&", buf4); 
       rgu_put_body_string( 5,buf1,2); /*6�«O�O*/
       rgu_put_body_string( 5,buf2,2); /*7���[�O��*/
       rgu_put_body_string( 5,buf3,2); /*8���[�O�βv*/
       rgu_put_body_string( 5,buf4,2); /*9ñ��O�O*/
   }
   rgu_put_body( 5);
   rfmtdouble(Tot_mpure_prem[3],"--,---,---.---",buf1);     
   rfmtdouble(Tot_mextra_charge[3],"--,---,---.---",buf2);     
   if (Tot_mply_prem[3]==0 || Tot_mpure_prem[3]==0)
       Pextra_charge = 0;
   else
       Pextra_charge = Tot_mextra_charge[3]/
                       (Tot_mply_prem[3] - Tot_minu_prem[3]) * 100;
   rfmtdouble(Pextra_charge,"---.----",buf3);     
   rfmtdouble(Tot_mply_prem[3], "-,---,---,--&", buf4); 
   rgu_put_body_string( 6,buf1,2); /*6�«O�O*/
   rgu_put_body_string( 6,buf2,2); /*7���[�O��*/
   rgu_put_body_string( 6,buf3,2); /*8���[�O�βv*/
   rgu_put_body_string( 6,buf4,2); /*9ñ��O�O*/
   rgu_put_body( 6);
   rgu_put_body( 3);
   TotRows +=2;
   rgu_put_body(NEXTPAGE);
   for(i=0;i<4;i++)
       Tot_mply_prem[i]=Tot_mpure_prem[i]=Tot_mextra_charge[i]=Tot_minu_prem[i]=0;

}
/*--------------------------------------------------------------------*/

static int DiffMonth(d1,d2)    /* input data should be date format */
long d1, d2;
{
    short mdy1[3], mdy2[3];
    int datediff=0;

    rjulmdy(d1,mdy1);
    rjulmdy(d2,mdy2);
    datediff=(mdy1[2]*12+mdy1[0])-(mdy2[2]*12+mdy2[0]);
    if (datediff<0) datediff=0;
    return datediff;
}

