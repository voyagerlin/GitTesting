/**********************************************************************/
/*   program id   : ca1398p01s.ec                                     */
/*   program name : IFRS17��Ʀ^��                                    */
/*   date written : 2023/01/07                                        */
/*   shell        : car1398_upd                                       */
/*   runbatch 00 930268 car1398 E 3 110/01/01 110/01/31 'P'   �@��    */
/*   runbatch 00 930268 car1398 E 3 110/01/01 110/01/31 'C'   �ɯS�w���       */
/*   runbatch 00 930268 car1398 E 3 110/01/01 110/01/31 'R'   �ۯd�O�O�վ��� */
/**********************************************************************/

#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include "print.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "othmsgs.h"
#include "commsgs.h"
#include "sqlfatal.h"

char  	outputf[N_FILE+1];
$char	DBName[5];
DBinfo  *list;
int     count_db,i;
char    sApHome[30];
char	msgbuf[100];

$char  	userid[11],sDbgn[11],sDend[11];
char  	dbgn[11],dend[11];
char    sOpt[2];

/*----------------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
	int rc;

	batchinit();
	strcpy(DBName,  isNULLstr(argv[1]));
	strcpy(userid,  isNULLstr(argv[2]));
	strcpy(dbgn,    isNULLstr(argv[3]));  /* cyy/mm/dd */
	strcpy(dend,    isNULLstr(argv[4]));  /* cyy/mm/dd */
	strcpy(sOpt,    isNULLstr(argv[5]));  /* sOpt:P �O/��/�z�� C:�z���B�~���O���� R:�ۯd�O�O�վ��� */
	strcpy(outputf, isNULLstr(argv[6]));

	strcpy(sDbgn,cm_to_infdate(dbgn));
	strcpy(sDend,cm_to_infdate(dend));

	rc = car1398_get_db();
	if (rc != M_CM_OK) {
		printf("error on car1398_get_db\n");
		return rc;
	}

	rc = create_tmp_table();
	if (rc != M_CM_OK) {
		printf("error on car1398_get_data\n");
		return rc;
	}

	rc = car1398_get_data();
	if (rc != M_CM_OK) {
		printf("error on car1398_get_data\n");
		return rc;
	}

    if (strcmp(sOpt,"R") == 0)
        rc = car1398_upd_data_R();
    else
	    rc = car1398_upd_data();
	if (rc != M_CM_OK) {
		printf("error on car1398_upd_data\n");
		return rc;
	}

	printf("[car1398]:process ok!\n");
}
/*----------------------------------------------------------------------------*/
long car1398_get_db()
{
	int	rc;

	if (db_select(DBName) == False) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "��Ʈw�L�k�}��!");
		return M_CM_DB_NOTOPEN;
	}

	rc = getApHome(sApHome);
	if (rc < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		EWRITE(userid,rc,msgbuf);
		return rc;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
		return M_CM_NOT_DBLIST;
	}

	return M_CM_OK;
}
/*----------------------------------------------------------------------------*/
long create_tmp_table()
{
	$whenever SQLERROR goto errexit;

/*
	$create temp table car1398_main_ply
	(
	    ipolicy1        char(20),
	    ipolicy2        char(20),
	    ipolicy         char(20),
	    iendorse        char(20)
 	)with no log;

	$create temp table car1398_ori
	(
	    ipolicy         char(20),
	    ipolicy1        char(20),
	    ipolicy2        char(20),
	    fassured        char(1),
	    qpt             decimal(4,1),
	    fpt             char(1),
	    icar_type       char(2),
	    dply_begin      date,
	    dply_end        date
 	)with no log;
 	$create index car1398_ori_x1 on car1398_ori (ipolicy1,ipolicy2);
 	$create index car1398_ori_x2 on car1398_ori (ipolicy);

 	$create temp table car1398_ori_ins
	(
	    ipolicy         char(20),
	    ipolicy1        char(20),
	    ipolicy2        char(20),
	    icohort         char(4),
	    icar_type       char(2),
	    acode           char(1),
	    bcode           char(1),
	    iins_type       char(6),
	    mdamage_cover   int,
	    daily_pay       int,
	    kreserve        char(5)
 	)with no log;
 	$create index car1398_ori_ins_x1 on car1398_ori_ins (ipolicy1,ipolicy2,iins_type);
 	$create index car1398_ori_ins_x2 on car1398_ori_ins (ipolicy,iins_type);
 	$create index car1398_ori_ins_x3 on car1398_ori_ins (iins_type,acode,bcode);
 	$create index car1398_ori_ins_x4 on car1398_ori_ins (icohort,icar_type);

 	$create temp table car1398_ori_ifrs
	(
	    ipolicy1        char(20),
	    ipolicy2        char(20),
	    iins_type       char(6),
	    kreserve        char(5),
	    fapply          char(1),
	    fterm           char(1),
	    iportfolio      char(10),
	    igroup_profit   char(20)
 	)with no log;
 	$create index car1398_ori_ifrs_x1 on car1398_ori_ifrs (ipolicy1,ipolicy2,iins_type);

	$create temp table car1398_edr
	(
	    ipolicy         char(20),
	    ipolicy1        char(20),
	    ipolicy2        char(20),
	    iendorse        char(20),
	    fassured        char(1),
	    qpt             decimal(4,1),
	    fpt             char(1),
	    icar_type       char(2),
	    dedr_begin      date,
	    dedr_end        date
 	)with no log;
 	$create index car1398_edr_x1 on car1398_edr (ipolicy1,ipolicy2,iendorse);
 	$create index car1398_edr_x2 on car1398_edr (ipolicy,iendorse);

 	$create temp table car1398_edr_ins
	(
	    ipolicy         char(20),
	    ipolicy1        char(20),
	    ipolicy2        char(20),
	    iendorse        char(20),
	    icohort         char(4),
	    icar_type       char(2),
	    acode           char(1),
	    bcode           char(1),
	    iins_type       char(6),
	    medrdmg_cover   int,
	    daily_pay       int,
	    kreserve        char(5)
 	)with no log;
 	$create index car1398_edr_ins_x1 on car1398_edr_ins (ipolicy1,ipolicy2,iendorse,iins_type);
 	$create index car1398_edr_ins_x2 on car1398_edr_ins (ipolicy,iendorse,iins_type);
 	$create index car1398_edr_ins_x3 on car1398_edr_ins (iins_type,acode,bcode);
 	$create index car1398_edr_ins_x4 on car1398_edr_ins (icohort,icar_type);

 	$create temp table car1398_edr_ifrs
	(
	    ipolicy1        char(20),
	    ipolicy2        char(20),
	    iendorse        char(20),
	    iins_type       char(6),
	    kreserve        char(5),
	    fapply          char(1),
	    fterm           char(1),
	    iportfolio      char(10),
	    igroup_profit   char(20)
 	)with no log;
 	$create index car1398_edr_ifrs_x1 on car1398_edr_ifrs (ipolicy1,ipolicy2,iendorse,iins_type);

 	$create temp table car1398_claim
	(
	    iclaim1        char(20),
	    ipolicy1       char(20),
	    ipolicy2       char(20),
	    db             char(1)
 	)with no log;
 	$create index car1398_claim_x1 on car1398_claim (iclaim1);
 	$create index car1398_claim_x2 on car1398_claim (ipolicy1,ipolicy2);
 	$create index car1398_claim_x3 on car1398_claim (db);

 	$create temp table car1398_claim_dtl
	(
	    iclaim1        char(20),
	    ipolicy1       char(20),
	    ipolicy2       char(20),
	    db             char(1),
	    insure_instype char(6),
	    ivictim        char(10),
	    iins_ply       char(6),
	    iportfolio     char(10),
	    igroup_profit  char(20)
 	)with no log;
 	$create index car1398_claim_dtl_x1 on car1398_claim_dtl (iclaim1,insure_instype,ivictim);
 	$create index car1398_claim_dtl_x2 on car1398_claim_dtl (iportfolio);
 	$create index car1398_claim_dtl_x3 on car1398_claim_dtl (igroup_profit);
 	$create index car1398_claim_dtl_x4 on car1398_claim_dtl (db);

 	$create temp table car1398_claim_stl_dtl
	(
	    iclaim1        char(20),
	    fstl           char(1),
	    iclose_type    char(4),
	    insure_instype char(6),
	    ivictim        char(10),
	    mstl_health    int,
	    mstl_dutyshare decimal(12,0)
 	)with no log;
 	$create index car1398_claim_stl_dtl_x1 on car1398_claim_stl_dtl (iclaim1,fstl,iclose_type,insure_instype,ivictim);
 	$create index car1398_claim_stl_dtl_x2 on car1398_claim_stl_dtl (mstl_health);
 	$create index car1398_claim_stl_dtl_x3 on car1398_claim_stl_dtl (mstl_dutyshare);
*/
    $database newa00;
    $TRUNCATE TABLE car1398_main_ply;
    $TRUNCATE TABLE car1398_ori;
    $TRUNCATE TABLE car1398_ori_ins;
    $TRUNCATE TABLE car1398_ori_ifrs;
    $TRUNCATE TABLE car1398_edr;
    $TRUNCATE TABLE car1398_edr_ins;
    $TRUNCATE TABLE car1398_edr_ifrs;
    $TRUNCATE TABLE car1398_claim;
    $TRUNCATE TABLE car1398_claim_dtl;
    $TRUNCATE TABLE car1398_claim_stl_dtl;



	return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car1398_get_data()
{
	$char stmt[4096], stmt1[2048], stmt2[4096], stmt3[2048], stmt4[4096];
	$char db[2];

	$whenever SQLERROR goto errexit;

	printf("--- insert into car1398_main_ply sOpt=[%s] --------------- \n",sOpt);

	if (strcmp(sOpt,"P") == 0)
	{
	    /* �ɫO/��/�z�� */
	    printf("---------- 272 ------------ \n");
	    sprintf( stmt, " insert into car1398_main_ply                                              \n"
                       " select ipolicy1, ipolicy2, trim(ipolicy1)||trim(ipolicy2), iendorsement   \n"
                       "   from policy_main                                                        \n"
                       "  where insure_class = 'C' and insure_level in ('C1','C2')                 \n"
                       "    and isys_source = 'CAR'                                                \n"
                       "    and dwritten between '%s' and '%s' " , sDbgn, sDend );
	}
	else
	{
	    /* �t�X�z�ߤΦۯd�O�O���,�ɯS�w��� */
	    printf("---------- 283 ------------ \n");
	    sprintf( stmt, " insert into car1398_main_ply                                              \n"
                       " select ipolicy1, ipolicy2, trim(ipolicy1)||trim(ipolicy2), iendorsement   \n"
                       "   from policy_main                                                        \n"
                       "  where insure_class = 'C' and insure_level in ('C1','C2')                 \n"
                       "    and isys_source = 'CAR'                                                \n"
                       "    and EXISTS (select 1 from car1398_tmp a                                \n"
	                   "  where a.ipolicy1 = policy_main.ipolicy1                                  \n"
	                   "    and a.ipolicy2 = policy_main.ipolicy2); ");
	}

    $prepare insert_main_ply from $stmt;
 	$execute insert_main_ply;


	for (i=0;i<count_db;i++)
	{
        printf("--- insert into car1398_ori [%s]--------------- \n",list[i].dbname);
		sprintf( stmt1, " insert into car1398_ori                               \n"
		                " select a.ipolicy, a.ipolicy[1,13], a.ipolicy[14,20],  \n"
		                "        case when a.fassured in ('1','3','5') then '1' else '2' end as fassured, \n"
 	                    " 	     case when a.ipolicy[6,7] = 'V7' and icar_type <> '32' then 4  \n"
 	                    "             when a.ipolicy[6,7] = 'V7' and icar_type = '32'  then 2  \n"
 	                    "             else nvl(a.qpt,0) end,                         \n"
 	                    " 	     decode(a.ipolicy[6,7],'V7','P',nvl(a.fpt,'')),      \n"
 	                    "        b.icar_type, b.dply_begin, b.dply_end               \n"
 	                    "   from %s:original_ply a, %s:ori_ply_relation b            \n"
                        "  where a.ipolicy = b.ipolicy                               \n"
                        "    and a.ipolicy in (select ipolicy from car1398_main_ply where iendorse = '');\n"
                                , list[i].dbname, list[i].dbname);
                $prepare insert_ori from $stmt1;
                $execute insert_ori;

                printf("--- insert into car1398_ori_ins [%s]--------------- \n",list[i].dbname);
                sprintf( stmt2, " insert into car1398_ori_ins                                              \n"
		                " select a.ipolicy, a.ipolicy[1,13], a.ipolicy[14,20], year(c.dpolicy),    \n"
 	                        " 	 decode(c.fcard_class,'1',c.icar_type,''),                         \n"
 	                        " 	 case when decode(a.drate_ym, '0a',1,'1a',10,'2a',20,(a.drate_ym+0))>=63 and a.iins_type = '21'               \n"
 	                        "             then case when c.icar_type = '51' then '1'                   \n"
 	                        "                       when c.icar_type in ('01','02','32','34') then '5' \n"
 	                        "                       when c.icar_type = '35' then '6'                   \n"
 	                        "                       when (select fcar_class from car_type where icode = c.icar_type and fclass = '1') = '2' then '4'   \n"
 	                        "                       else (select fcar_class from car_type where icode = c.icar_type and fclass = '1') end              \n"
 	                        "             else case when c.icar_type in ('01','02','32','34','35') then '3'                                            \n"
 	                        "                       else (select fcar_class from car_type where icode = c.icar_type and fclass = '1') end end,         \n"
 	                        "        case when a.provision matches '*T*' then 'T'                      \n"
 	                        "             when (a.drate_ym+0)>=94 and a.iins_type = '58' then '2'      \n"
 	                        "             when (a.drate_ym+0)<94  and a.iins_type = '58' then '1'      \n"
 	                        "             when c.fcard_class = '1' and icar_type in ('01','02','32','34','35') and c.qply_period > 24 then '3'         \n"
 	                        "             when c.fcard_class = '1' and icar_type in ('01','02','32','34','35') and c.qply_period > 12 then '2'         \n"
 	                        "             when c.fcard_class = '1' and icar_type in ('01','02','32','34','35') then '1' else '' end,                   \n"
 	                        "        a.iins_type, decode(a.iins_type,'21',(a.minjured_cover+a.mdamage_cover),a.mdamage_cover), nvl(sum(b.daily_pay),0), \n"
 	                        "        (SELECT kreserve FROM policy_main_dtl WHERE isys_source = 'CAR' and ipolicy1 = a.ipolicy[1,13] \n"
 	                        "            AND ipolicy2 = a.ipolicy[14,20] \n"
 	                        "            AND iendorsement = ' '   AND insure_instype = a.iins_type) \n"
 	                        "   from %s:ori_ins_type a, %s:ori_ply_relation c, outer %s:ca_pa_ori b           \n"
 	                        "  where a.ipolicy = b.ipolicy and a.iins_type = b.iins_type                      \n"
 	                        "    and a.ipolicy = c.ipolicy and b.mr_ins_prem <> 0                             \n"
 	                        "    and a.ipolicy in (select ipolicy from car1398_main_ply where iendorse = '')  \n"
 	                        "  group by 1,2,3,4,5,6,7,8,9;                                                    \n"
                                , list[i].dbname, list[i].dbname, list[i].dbname);
                $prepare insert_ori from $stmt2;
                $execute insert_ori;

                printf("--- insert into car1398_edr [%s]--------------- \n",list[i].dbname);
                sprintf( stmt3, " insert into car1398_edr       \n"
		                " select b.ipolicy, b.ipolicy[1,13], b.ipolicy[14,20], a.iendorse,        \n"
		                "        case when a.fassured in ('1','3','5') then '1' else '2' end as fassured, \n"
 	                        " 	 case when b.ipolicy[6,7] = 'V7' and icar_type <> '32' then 4                \n"
 	                        "             when b.ipolicy[6,7] = 'V7' and icar_type = '32'  then 2                \n"
 	                        "             else nvl(a.qpt,0) end, decode(b.ipolicy[6,7],'V7','P',nvl(a.fpt,'')),  \n"
 	                        " 	 b.icar_type, b.dedr_begin, b.dedr_end              \n"
 	                        "   from %s:endorsement a, %s:edr_relation b                \n"
                                "  where a.iendorse = b.iendorse                            \n"
                                "    and a.iendorse in (select iendorse from car1398_main_ply where iendorse != ''); \n"
                                , list[i].dbname, list[i].dbname);
                $prepare insert_edr from $stmt3;
                $execute insert_edr;

                printf("--- insert into car1398_edr_ins [%s]--------------- \n",list[i].dbname);
                sprintf( stmt4, " insert into car1398_edr_ins                                                             \n"
		                " select c.ipolicy, c.ipolicy[1,13], c.ipolicy[14,20], a.iendorse,                        \n"
		                "        (SELECT year(d.dpolicy) FROM %s:ori_ply_relation d WHERE d.ipolicy = c.ipolicy), \n"
 	                        " 	 decode(c.fcard_class,'1',c.icar_type,''),                                        \n"
 	                        " 	 case when (a.drate_ym+0)>=63 and a.iins_type = '21'                              \n"
 	                        "             then case when a.iins_type = '51' then '1'                                  \n"
 	                        "                       when c.icar_type in ('01','02','32','34') then '5'                \n"
 	                        "                       when c.icar_type = '35' then '6'                                  \n"
 	                        "                       when (select fcar_class from car_type where icode = c.icar_type and fclass = '1') = '2' then '4'  \n"
 	                        "                       else (select fcar_class from car_type where icode = c.icar_type and fclass = '1') end             \n"
 	                        "             else case when c.icar_type in ('01','02','32','34','35') then '3'                                           \n"
 	                        "                       else (select fcar_class from car_type where icode = c.icar_type and fclass = '1') end end,        \n"
 	                        "        case when a.provision matches '*T*' then 'T'                      \n"
 	                        "             when (a.drate_ym+0)>=94 and a.iins_type = '58' then '2'      \n"
 	                        "             when (a.drate_ym+0)<94  and a.iins_type = '58' then '1'      \n"
 	                        "             when c.fcard_class = '1' and icar_type in ('01','02','32','34','35') and e.qply_period > 24 then '3'   \n"
 	                        "             when c.fcard_class = '1' and icar_type in ('01','02','32','34','35') and e.qply_period > 12 then '2'   \n"
 	                        "             when c.fcard_class = '1' and icar_type in ('01','02','32','34','35') then '1' else '' end,             \n"
 	                        "        a.iins_type, decode(a.iins_type,'21',(a.medrinj_cover+a.medrdmg_cover),a.medrdmg_cover), nvl(sum(b.medr_daily_pay),0),  \n"
 	                        "        (SELECT kreserve FROM policy_main_dtl WHERE isys_source = 'CAR' \n"
 	                        "            and ipolicy1 = c.ipolicy[1,13] AND ipolicy2 = c.ipolicy[14,20] \n"
 	                        "            AND iendorsement = c.iendorse  AND insure_instype = a.iins_type) \n"
 	                        "   from %s:edr_ins_type a, %s:edr_relation c, %s:endorsement e, outer %s:ca_pa_edr b     \n"
 	                        "  where a.iendorse = c.iendorse and a.iendorse = e.iendorse                              \n"
 	                        "    and a.iendorse = b.iendorse and a.iins_type = b.iins_type and b.medrins_prem <> 0    \n"
 	                        "    and a.iendorse in (select iendorse from car1398_main_ply where iendorse != '')       \n"
 	                        "   group by 1,2,3,4,5,6,7,8,9,10,12;                                                        \n"
                                , list[i].dbname, list[i].dbname, list[i].dbname, list[i].dbname, list[i].dbname);
                $prepare insert_edr_ins from $stmt4;
                $execute insert_edr_ins;
	}


    printf("--- insert into car1398_ori_ifrs--------------- \n");
	sprintf( stmt, " insert into car1398_ori_ifrs                                        \n"
                       " select a.ipolicy1, a.ipolicy2, a.iins_type, a.kreserve,             \n"
                       "        b.fapply,b.fterm, c.iportfolio, d.igroup_profit              \n"
                       "   from car1398_ori_ins a, cm_product_code b,                        \n"
                       "        sysdb:cm_reserve_portfolio c, cm_profit_code d               \n"
                       "  where b.iins_class = 'C' and b.iins_type = a.iins_type             \n"
                       "    and b.icode1 = a.acode and b.icode2 = a.bcode                    \n"
                       "    and c.ftype = 'D'      and c.fproportion = 'D'                   \n"
                       "    and c.fterm = b.fterm  and c.kreserve = a.kreserve               \n"
                       "    and d.iportfolio = c.iportfolio                                  \n"
                       "    and d.icohort = a.icohort and d.isubcode = ' ';          \n");
        $prepare insert_ori_ifrs from $stmt;
 	$execute insert_ori_ifrs;


    printf("--- insert into car1398_edr_ifrs--------------- \n");
 	sprintf( stmt, " insert into car1398_edr_ifrs                                        \n"
                       " select a.ipolicy1, a.ipolicy2, a.iendorse, a.iins_type, a.kreserve, \n"
                       "        b.fapply, b.fterm, c.iportfolio, d.igroup_profit             \n"
                       "   from car1398_edr_ins a, cm_product_code b,                        \n"
                       "        sysdb:cm_reserve_portfolio c, cm_profit_code d               \n"
                       "  where b.iins_class = 'C'  and b.iins_type = a.iins_type            \n"
                       "    and b.icode1 = a.acode  and b.icode2 = a.bcode                   \n"
                       "    and c.ftype  = 'D'      and c.fproportion = 'D'                  \n"
                       "    and c.fterm  = b.fterm  and c.kreserve = a.kreserve              \n"
                       "    and d.iportfolio = c.iportfolio                                  \n"
                       "    and d.icohort = a.icohort and d.isubcode = ' ';          \n");
        $prepare insert_edr_ifrs from $stmt;
 	$execute insert_edr_ifrs;

    printf("--- insert into car1398_claim--------------- \n");
 	sprintf( stmt, " insert into car1398_claim                                   \n"
                       " select iclaim1, ipolicy1, ipolicy2, ipolicy1[3]             \n"
                       "   from claim_app_main                                       \n"
                       "  where insure_type = 'C'                                    \n"
                       "    and EXISTS (select 1 from car1398_main_ply a             \n"
                       "                 where a.ipolicy1 = claim_app_main.ipolicy1  \n"
                       "                   and a.ipolicy2 = claim_app_main.ipolicy2 and a.iendorse = '');\n");
        $prepare insert_claim from $stmt;
 	$execute insert_claim;



    printf("--- insert into car1398_claim_dtl--------------- \n");
 	/* sprintf( stmt, " insert into car1398_claim_dtl                                               \n"
                       " select DISTINCT c.iclaim1, c.ipolicy1, c.ipolicy2, c.db,                \n"
                       "        a.insure_instype, a.ivictim, b.iins_ply,                         \n"
                       "        case when nvl(ori.iportfolio,'') <> '' then ori.iportfolio       \n"
                       " 	     else nvl(edr.iportfolio,'') end,                                \n"
                       " 	case when nvl(ori.igroup_profit,'') <> '' then ori.igroup_profit     \n"
                       "             else nvl(edr.igroup_profit,'') end                          \n"
                       "   from car1398_claim c, claim_app_dtl a, insurance_type b,              \n"
                       "        OUTER car1398_ori_ifrs ori, OUTER car1398_edr_ifrs edr           \n"
                       "  where a.insure_type = 'C'   and a.insure_instype = b.iins_type         \n"
                       "    and a.iclaim1 = c.iclaim1 and a.iclaim1 in (select iclaim1 from car1398_claim)              \n"
                       "    and ori.ipolicy1 = c.ipolicy1 and ori.ipolicy2 = c.ipolicy2 and ori.iins_type = b.iins_ply  \n"
                       "    and edr.ipolicy1 = c.ipolicy1 and edr.ipolicy2 = c.ipolicy2 and edr.iins_type = b.iins_ply; \n"); */

    sprintf( stmt, " insert into car1398_claim_dtl                                               \n"
                   " select DISTINCT c.iclaim1, c.ipolicy1, c.ipolicy2, c.db,                \n"
                   "        a.insure_instype, a.ivictim, b.iins_ply,                         \n"
                   "        (SELECT y.iportfolio FROM sysdb:cm_reserve_portfolio x , sysdb:cm_profit_code y \n"
                   "          WHERE x.iportfolio = y.iportfolio   AND x.ftype = 'D' \n"
                   "            AND x.kreserve = a.kreserve  AND y.icohort = \n"
                   "                (SELECT UNIQUE icohort FROM car1398_ori_ins \n"
                   "                  WHERE ipolicy1 = c.ipolicy1 AND ipolicy2 = c.ipolicy2) \n"
                   "                    AND x.fterm = (select fterm from car1398_ori_ifrs "
                   "                                    where ipolicy1=c.ipolicy1 and ipolicy2 = c.ipolicy2 "
                   "                                      and iins_type = b.iins_ply and kreserve = a.kreserve "
				   "                                    union  "
				   "                                   select unique fterm from car1398_edr_ifrs "
                   "                                    where ipolicy1=c.ipolicy1 and ipolicy2 = c.ipolicy2 "
                   "                                      and iins_type = b.iins_ply and kreserve = a.kreserve ))  AS iportfolio, \n"
                   " 	  (SELECT y.igroup_profit  FROM sysdb:cm_reserve_portfolio x , sysdb:cm_profit_code y \n"
                   "        WHERE x.iportfolio = y.iportfolio  AND x.ftype = 'D' \n"
                   "          AND x.kreserve = a.kreserve      AND y.icohort = \n"
                   "              (SELECT UNIQUE icohort FROM car1398_ori_ins \n"
                   "                WHERE ipolicy1 = c.ipolicy1 AND ipolicy2 = c.ipolicy2) \n"
                   "                    AND x.fterm = (select fterm from car1398_ori_ifrs "
                   "                                    where ipolicy1=c.ipolicy1 and ipolicy2 = c.ipolicy2 "
                   "                                      and iins_type = b.iins_ply and kreserve = a.kreserve "
				   "                                    union  "
				   "                                   select unique fterm from car1398_edr_ifrs "
                   "                                    where ipolicy1=c.ipolicy1 and ipolicy2 = c.ipolicy2 "
                   "                                      and iins_type = b.iins_ply and kreserve = a.kreserve))  AS igroup_profit \n"
                   "   from car1398_claim c, claim_app_dtl a, insurance_type b              \n"
                   "  where a.insure_type = 'C'   and a.insure_instype = b.iins_type         \n"
                   "    and a.iclaim1 = c.iclaim1 and a.iclaim1 in (select iclaim1 from car1398_claim)");
printf("stmt=[%s]\n",stmt);
    $prepare insert_claim_dtl from $stmt;
 	$execute insert_claim_dtl;

	for (i=0;i<count_db;i++)
	{
		if (i==0)      strcpy(db,"0");
		else if (i==1) strcpy(db,"5");
		else if (i==2) strcpy(db,"6");
		else if (i==3) strcpy(db,"1");
		else if (i==4) strcpy(db,"7");
		else           strcpy(db,"2");

        printf("--- insert into car1398_claim_stl_dtl db=[%s]--------------- \n",db);
		sprintf( stmt1, " insert into car1398_claim_stl_dtl                                      \n"
		                " select a.iclaim1, a.fstl, a.iclose_type, b.insure_instype, a.ivictim,  \n"
 	                        "        nvl((select nvl(decode(fstl, '1', mstl_health, -mstl_health),0) \n"
 	                        "               from %s:ca_stl_victim                                    \n"
 	                        "              where iclaim = a.iclaim1 and iclose_type = a.iclose_type  \n"
 	                        "                and fstl = a.fstl and iins_item = a.insure_instype      \n"
 	                        "                and ivictim = a.ivictim),0),                            \n"
 	                        "        case when (select istl_flag from %s:settlement                  \n"
 	                        "                    where iclaim = a.iclaim1 and fstl = a.fstl          \n"
 	                        "                      and iclose_type = a.iclose_type) in ('A','B')     \n"
 	                        "             then a.msettle else 0 end                                  \n"
 	                        "   from claim_stl_dtl a, car1398_claim_dtl b                            \n"
 	                        " where a.insure_type = 'C' and b.db = '%s' and isys_source = 'CAR'      \n"
 	                        "   and a.iclaim1 = b.iclaim1 and a.insure_instype = b.insure_instype    \n"
 	                        "   and a.ivictim = b.ivictim;                                           \n"
                                , list[i].dbname, list[i].dbname, db);
                $prepare insert_claim_stl_dtl from $stmt1;
                $execute insert_claim_stl_dtl;
	}

	return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car1398_upd_data()
{
	$whenever SQLERROR goto errexit;

	$begin work;

	/***** update �O���� *****/
printf("---- update policy_main ---- \n");
	$update policy_main
	    set icurr = 'NT',
	        macct_prem_ori = macct_prem,
	        mcomm_ori      = mdeal + mcommission + magent,
	        magent_ori     = 0,
	        fassured       = (select fassured from car1398_ori a
	                           where a.ipolicy1 = policy_main.ipolicy1
	                             and a.ipolicy2 = policy_main.ipolicy2),
	        icarrier       = (select a.icar_type from car1398_ori a
	                           where a.ipolicy1 = policy_main.ipolicy1
	                             and a.ipolicy2 = policy_main.ipolicy2),
	        qlimit_carrier = (select a.qpt from car1398_ori a
	                           where a.ipolicy1 = policy_main.ipolicy1
	                             and a.ipolicy2 = policy_main.ipolicy2),
	        iunit_carrier  = (select a.fpt from car1398_ori a
	                           where a.ipolicy1 = policy_main.ipolicy1
	                             and a.ipolicy2 = policy_main.ipolicy2)
	  where insure_class = 'C' and insure_level in ('C1','C2')
	    and isys_source = 'CAR' and iendorsement = ''
	    and EXISTS (select 1 from car1398_ori a
	                 where a.ipolicy1 = policy_main.ipolicy1
	                   and a.ipolicy2 = policy_main.ipolicy2);

printf("---- update policy_main_dtl ---- \n");
	$update policy_main_dtl
	    set fapply         = 'Y',
	        iportfolio     = (select iportfolio from car1398_ori_ifrs a
	                           where a.ipolicy1 = policy_main_dtl.ipolicy1
	                             and a.ipolicy2 = policy_main_dtl.ipolicy2
	                             and a.iins_type = policy_main_dtl.insure_instype),
	        igroup_profit  = (select igroup_profit from car1398_ori_ifrs a
	                           where a.ipolicy1 = policy_main_dtl.ipolicy1
	                             and a.ipolicy2 = policy_main_dtl.ipolicy2
	                             and a.iins_type = policy_main_dtl.insure_instype),
	        icohort        = (select a.icohort from car1398_ori_ins a
	                           where a.ipolicy1 = policy_main_dtl.ipolicy1
	                             and a.ipolicy2 = policy_main_dtl.ipolicy2
	                             and a.iins_type = policy_main_dtl.insure_instype),
	        dindem_bgn     = (select a.dply_begin from car1398_ori a
	                           where a.ipolicy1 = policy_main_dtl.ipolicy1
	                             and a.ipolicy2 = policy_main_dtl.ipolicy2),
	        dindem_end     = (select a.dply_end from car1398_ori a
	                           where a.ipolicy1 = policy_main_dtl.ipolicy1
	                             and a.ipolicy2 = policy_main_dtl.ipolicy2),
	        macct_prem_ori = macct_prem,
	        mcomm_ori      = mdeal + mcommission + magent,
	        mindem_ori     = (select (a.mdamage_cover+a.daily_pay)
	                            from car1398_ori_ins a
	                           where a.ipolicy1 = policy_main_dtl.ipolicy1
	                             and a.ipolicy2 = policy_main_dtl.ipolicy2
	                             and a.iins_type = policy_main_dtl.insure_instype),
	        mindem         = (select (a.mdamage_cover+a.daily_pay)
	                            from car1398_ori_ins a
	                           where a.ipolicy1 = policy_main_dtl.ipolicy1
	                             and a.ipolicy2 = policy_main_dtl.ipolicy2
	                             and a.iins_type = policy_main_dtl.insure_instype),
	        magent_ori     = 0
	  where insure_type = 'C' and iendorsement = '' and isys_source = 'CAR'
	    and EXISTS (select 1 from car1398_ori_ins a
	                 where a.ipolicy1 = policy_main_dtl.ipolicy1
	                   and a.ipolicy2 = policy_main_dtl.ipolicy2
	                   and a.iins_type = policy_main_dtl.insure_instype);

	/***** update ����� *****/
printf("---- update policy_main ---- \n");
	$update policy_main
	    set icurr = 'NT',
	        macct_prem_ori = macct_prem,
	        mcomm_ori      = mdeal + mcommission + magent,
	        magent_ori     = 0,
	        fassured       = (select a.fassured from car1398_edr a
	                           where a.ipolicy1 = policy_main.ipolicy1
	                             and a.ipolicy2 = policy_main.ipolicy2
	                             and a.iendorse = policy_main.iendorsement),
	        icarrier       = (select a.icar_type from car1398_edr a
	                           where a.ipolicy1 = policy_main.ipolicy1
	                             and a.ipolicy2 = policy_main.ipolicy2
	                             and a.iendorse = policy_main.iendorsement),
	        qlimit_carrier = (select a.qpt from car1398_edr a
	                           where a.ipolicy1 = policy_main.ipolicy1
	                             and a.ipolicy2 = policy_main.ipolicy2
	                             and a.iendorse = policy_main.iendorsement),
	        iunit_carrier  = (select a.fpt from car1398_edr a
	                           where a.ipolicy1 = policy_main.ipolicy1
	                             and a.ipolicy2 = policy_main.ipolicy2
	                             and a.iendorse = policy_main.iendorsement)
	  where insure_class = 'C' and insure_level in ('C1','C2')
	    and isys_source = 'CAR'
	    and EXISTS (select 1 from car1398_edr a
	                 where a.ipolicy1 = policy_main.ipolicy1
	                   and a.ipolicy2 = policy_main.ipolicy2
	                   and a.iendorse = policy_main.iendorsement);

printf("---- update policy_main_dtl ---- \n");
	$update policy_main_dtl
	    set fapply         = 'Y',
	        iportfolio     = (select iportfolio from car1398_edr_ifrs a
	                           where a.ipolicy1  = policy_main_dtl.ipolicy1
	                             and a.ipolicy2  = policy_main_dtl.ipolicy2
	                             and a.iendorse  = policy_main_dtl.iendorsement
	                             and a.iins_type = policy_main_dtl.insure_instype),
	        igroup_profit  = (select igroup_profit from car1398_edr_ifrs a
	                           where a.ipolicy1  = policy_main_dtl.ipolicy1
	                             and a.ipolicy2  = policy_main_dtl.ipolicy2
	                             and a.iendorse  = policy_main_dtl.iendorsement
	                             and a.iins_type = policy_main_dtl.insure_instype),
	        icohort        = (select a.icohort from car1398_edr_ins a
	                           where a.ipolicy1  = policy_main_dtl.ipolicy1
	                             and a.ipolicy2  = policy_main_dtl.ipolicy2
	                             and a.iendorse  = policy_main_dtl.iendorsement
	                             and a.iins_type = policy_main_dtl.insure_instype),
	        dindem_bgn     = (select a.dedr_begin from car1398_edr a
	                           where a.ipolicy1  = policy_main_dtl.ipolicy1
	                             and a.ipolicy2  = policy_main_dtl.ipolicy2
	                             and a.iendorse  = policy_main_dtl.iendorsement),
	        dindem_end     = (select a.dedr_end from car1398_edr a
	                           where a.ipolicy1 = policy_main_dtl.ipolicy1
	                             and a.ipolicy2 = policy_main_dtl.ipolicy2
	                             and a.iendorse = policy_main_dtl.iendorsement),
	        macct_prem_ori = macct_prem,
	        mcomm_ori      = mdeal + mcommission + magent,
	        mindem_ori     = (select (a.medrdmg_cover+a.daily_pay)
	                            from car1398_edr_ins a
	                           where a.ipolicy1  = policy_main_dtl.ipolicy1
	                             and a.ipolicy2  = policy_main_dtl.ipolicy2
	                             and a.iendorse  = policy_main_dtl.iendorsement
	                             and a.iins_type = policy_main_dtl.insure_instype),
	        mindem         = (select (a.medrdmg_cover+a.daily_pay)
	                            from car1398_edr_ins a
	                           where a.ipolicy1  = policy_main_dtl.ipolicy1
	                             and a.ipolicy2  = policy_main_dtl.ipolicy2
	                             and a.iendorse  = policy_main_dtl.iendorsement
	                             and a.iins_type = policy_main_dtl.insure_instype),
	        magent_ori     = 0
	  where insure_type = 'C' and isys_source = 'CAR'
	    and EXISTS (select 1 from car1398_edr_ins a
	                 where a.ipolicy1  = policy_main_dtl.ipolicy1
	                   and a.ipolicy2  = policy_main_dtl.ipolicy2
	                   and a.iendorse  = policy_main_dtl.iendorsement
	                   and a.iins_type = policy_main_dtl.insure_instype);

	/***** update �z�߸�� *****/
printf("---- update claim_app_main ---- \n");
	$update claim_app_main
	    set icurr          = 'NT',
	        mclaim_app_ori = mclaim_app,
	        mfee_app_ori   = mfee_app,
	        mret_app_ori   = mret_app
	  where iclaim1 in (select iclaim1 from car1398_claim);

printf("---- update claim_app_main_h ---- \n");
	$update claim_app_main_h
	    set icurr          = 'NT',
	        mclaim_app_ori = mclaim_app,
	        mfee_app_ori   = mfee_app,
	        mret_app_ori   = mret_app
	  where iclaim1 in (select iclaim1 from car1398_claim);


printf("---- update claim_app_dtl ---- \n");
	$update claim_app_dtl
	    set iportfolio     = (select iportfolio from car1398_claim_dtl a
	                           where a.iclaim1        = claim_app_dtl.iclaim1
	                             and a.insure_instype = claim_app_dtl.insure_instype
	                             and a.ivictim        = claim_app_dtl.ivictim),
	        igroup_profit  = (select igroup_profit from car1398_claim_dtl a
	                           where a.iclaim1        = claim_app_dtl.iclaim1
	                             and a.insure_instype = claim_app_dtl.insure_instype
	                             and a.ivictim        = claim_app_dtl.ivictim),
	        mclaim_app_ori = mclaim_app,
	        mfee_app_ori   = mfee_app,
	        mret_app_ori   = mret_app
	  where EXISTS (select 1 from car1398_claim_dtl a
	                 where a.iclaim1        = claim_app_dtl.iclaim1
	                   and a.insure_instype = claim_app_dtl.insure_instype
	                   and a.ivictim        = claim_app_dtl.ivictim);

printf("---- update claim_app_dtl_h ---- \n");
	$update claim_app_dtl_h
	    set iportfolio     = (select iportfolio from car1398_claim_dtl a
	                           where a.iclaim1        = claim_app_dtl_h.iclaim1
	                             and a.insure_instype = claim_app_dtl_h.insure_instype
	                             and a.ivictim        = claim_app_dtl_h.ivictim),
	        igroup_profit  = (select igroup_profit from car1398_claim_dtl a
	                           where a.iclaim1        = claim_app_dtl_h.iclaim1
	                             and a.insure_instype = claim_app_dtl_h.insure_instype
	                             and a.ivictim        = claim_app_dtl_h.ivictim),
	        mclaim_app_ori = mclaim_app,
	        mfee_app_ori   = mfee_app,
	        mret_app_ori   = mret_app
	  where EXISTS (select 1 from car1398_claim_dtl a
                         where a.iclaim1        = claim_app_dtl_h.iclaim1
                           and a.insure_instype = claim_app_dtl_h.insure_instype
                           and a.ivictim        = claim_app_dtl_h.ivictim);

printf("---- update claim_stl_dtl ---- \n");
	$update claim_stl_dtl
	    set mstl_health    = (select mstl_health from car1398_claim_stl_dtl a
	                           where a.iclaim1        = claim_stl_dtl.iclaim1
	                             and a.fstl           = claim_stl_dtl.fstl
	                             and a.iclose_type    = claim_stl_dtl.iclose_type
	                             and a.insure_instype = claim_stl_dtl.insure_instype
	                             and a.ivictim        = claim_stl_dtl.ivictim),
	        mstl_dutyshare = (select mstl_dutyshare from car1398_claim_stl_dtl a
	                           where a.iclaim1        = claim_stl_dtl.iclaim1
	                             and a.fstl           = claim_stl_dtl.fstl
	                             and a.iclose_type    = claim_stl_dtl.iclose_type
	                             and a.insure_instype = claim_stl_dtl.insure_instype
	                             and a.ivictim        = claim_stl_dtl.ivictim),
	        iportfolio     = (select iportfolio from car1398_claim_dtl a
	                           where a.iclaim1        = claim_stl_dtl.iclaim1
	                             and a.insure_instype = claim_stl_dtl.insure_instype
	                             and a.ivictim        = claim_stl_dtl.ivictim),
	        igroup_profit  = (select igroup_profit from car1398_claim_dtl a
	                           where a.iclaim1        = claim_stl_dtl.iclaim1
	                             and a.insure_instype = claim_stl_dtl.insure_instype
	                             and a.ivictim        = claim_stl_dtl.ivictim),
	        msettle_ori    = msettle,
	        mfee_ori       = mfee,
	        mret_ori       = mret
	  where EXISTS (select 1 from car1398_claim_dtl a
	                 where a.iclaim1 = claim_stl_dtl.iclaim1
	                   and a.insure_instype = claim_stl_dtl.insure_instype)
	    and isys_source = 'CAR';

	$commit work;
printf("---- all OK ---- \n");
	return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    $whenever sqlerror continue;
    $ROLLBACK WORK;
    return SQLCODE;
}

/* --------------------------------------------------------------------------- */
long car1398_upd_data_R()
{
	$whenever SQLERROR goto errexit;

	$begin work;

	/***** update �O���� *****/
printf("---- update policy_main ---- \n");
	$update policy_main
	    set icurr = 'NT',
	        macct_prem_ori = 0,
	        mcomm_ori      = 0,
	        magent_ori     = 0,
	        fassured       = (select fassured from car1398_ori a
	                           where a.ipolicy1 = policy_main.ipolicy1
	                             and a.ipolicy2 = policy_main.ipolicy2),
	        icarrier       = (select a.icar_type from car1398_ori a
	                           where a.ipolicy1 = policy_main.ipolicy1
	                             and a.ipolicy2 = policy_main.ipolicy2),
	        qlimit_carrier = (select a.qpt from car1398_ori a
	                           where a.ipolicy1 = policy_main.ipolicy1
	                             and a.ipolicy2 = policy_main.ipolicy2),
	        iunit_carrier  = (select a.fpt from car1398_ori a
	                           where a.ipolicy1 = policy_main.ipolicy1
	                             and a.ipolicy2 = policy_main.ipolicy2)
	  where insure_class = 'C' and insure_level in ('C1','C2')
	    and iendorsement[1,13] = policy_main.ipolicy1
	    and EXISTS (select 1 from car1398_ori a
	                 where a.ipolicy1 = policy_main.ipolicy1
	                   and a.ipolicy2 = policy_main.ipolicy2);

printf("---- update policy_main_dtl ---- \n");
	$update policy_main_dtl
	    set fapply         = 'Y',
	        iportfolio     = (select iportfolio from car1398_ori_ifrs a
	                           where a.ipolicy1 = policy_main_dtl.ipolicy1
	                             and a.ipolicy2 = policy_main_dtl.ipolicy2
	                             and a.iins_type = policy_main_dtl.insure_instype),
	        igroup_profit  = (select igroup_profit from car1398_ori_ifrs a
	                           where a.ipolicy1 = policy_main_dtl.ipolicy1
	                             and a.ipolicy2 = policy_main_dtl.ipolicy2
	                             and a.iins_type = policy_main_dtl.insure_instype),
	        icohort        = (select a.icohort from car1398_ori_ins a
	                           where a.ipolicy1 = policy_main_dtl.ipolicy1
	                             and a.ipolicy2 = policy_main_dtl.ipolicy2
	                             and a.iins_type = policy_main_dtl.insure_instype),
	        dindem_bgn     = (select a.dply_begin from car1398_ori a
	                           where a.ipolicy1 = policy_main_dtl.ipolicy1
	                             and a.ipolicy2 = policy_main_dtl.ipolicy2),
	        dindem_end     = (select a.dply_end from car1398_ori a
	                           where a.ipolicy1 = policy_main_dtl.ipolicy1
	                             and a.ipolicy2 = policy_main_dtl.ipolicy2),
	        macct_prem_ori = 0,
	        mcomm_ori      = 0,
	        mindem_ori     = 0,
	        mindem         = 0,
	        magent_ori     = 0
	  where insure_type = 'C' and iendorsement[1,13] = policy_main_dtl.ipolicy1
	    and EXISTS (select 1 from car1398_ori_ins a
	                 where a.ipolicy1 = policy_main_dtl.ipolicy1
	                   and a.ipolicy2 = policy_main_dtl.ipolicy2
	                   and a.iins_type = policy_main_dtl.insure_instype);

	/***** update ����� *****/
printf("---- update policy_main �ۯd---- \n");
	$update policy_main
	    set icurr = 'NT',
	        macct_prem_ori = 0,
	        mcomm_ori      = 0,
	        magent_ori     = 0,
	        fassured       = (select a.fassured from car1398_edr a
	                           where a.ipolicy1 = policy_main.ipolicy1
	                             and a.ipolicy2 = policy_main.ipolicy2
	                             and a.iendorse = policy_main.iendorsement[1,13]),
	        icarrier       = (select a.icar_type from car1398_edr a
	                           where a.ipolicy1 = policy_main.ipolicy1
	                             and a.ipolicy2 = policy_main.ipolicy2
	                             and a.iendorse = policy_main.iendorsement[1,13]),
	        qlimit_carrier = (select a.qpt from car1398_edr a
	                           where a.ipolicy1 = policy_main.ipolicy1
	                             and a.ipolicy2 = policy_main.ipolicy2
	                             and a.iendorse = policy_main.iendorsement[1,13]),
	        iunit_carrier  = (select a.fpt from car1398_edr a
	                           where a.ipolicy1 = policy_main.ipolicy1
	                             and a.ipolicy2 = policy_main.ipolicy2
	                             and a.iendorse = policy_main.iendorsement[1,13])
	  where insure_class = 'C' and insure_level in ('C1','C2')
	    and length(iendorsement) > 13
	    and iendorsement[1,13] != ipolicy1
      and ipolicy1 in (select ipolicy1 from car1398_edr)   ;

printf("---- update policy_main_dtl_�ۯd ---- \n");
	$update policy_main_dtl
	    set fapply         = 'Y',
	        iportfolio     = (select iportfolio from car1398_edr_ifrs a
	                           where a.ipolicy1  = policy_main_dtl.ipolicy1
	                             and a.ipolicy2  = policy_main_dtl.ipolicy2
	                             and a.iendorse  = policy_main_dtl.iendorsement[1,13]
	                             and a.iins_type = policy_main_dtl.insure_instype),
	        igroup_profit  = (select igroup_profit from car1398_edr_ifrs a
	                           where a.ipolicy1  = policy_main_dtl.ipolicy1
	                             and a.ipolicy2  = policy_main_dtl.ipolicy2
	                             and a.iendorse  = policy_main_dtl.iendorsement[1,13]
	                             and a.iins_type = policy_main_dtl.insure_instype),
	        icohort        = (select a.icohort from car1398_edr_ins a
	                           where a.ipolicy1  = policy_main_dtl.ipolicy1
	                             and a.ipolicy2  = policy_main_dtl.ipolicy2
	                             and a.iendorse  = policy_main_dtl.iendorsement[1,13]
	                             and a.iins_type = policy_main_dtl.insure_instype),
	        dindem_bgn     = (select a.dedr_begin from car1398_edr a
	                           where a.ipolicy1  = policy_main_dtl.ipolicy1
	                             and a.ipolicy2  = policy_main_dtl.ipolicy2
	                             and a.iendorse  = policy_main_dtl.iendorsement[1,13]),
	        dindem_end     = (select a.dedr_end from car1398_edr a
	                           where a.ipolicy1 = policy_main_dtl.ipolicy1
	                             and a.ipolicy2 = policy_main_dtl.ipolicy2
	                             and a.iendorse = policy_main_dtl.iendorsement[1,13]),
	        macct_prem_ori = 0,
	        mcomm_ori      = 0,
	        mindem_ori     = 0,
	        mindem         = 0,
	        magent_ori     = 0
	  where insure_type = 'C'
	    and length(iendorsement) > 13
	    and iendorsement[1,13] != ipolicy1
         and exists (select * from car1398_edr where ipolicy1 = policy_main_dtl.ipolicy1
                      and ipolicy2 = policy_main_dtl.ipolicy2);

	$commit work;
printf("----�ۯd�O�O�վ� all OK ---- \n");
	return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    $whenever sqlerror continue;
    $ROLLBACK WORK;
    return SQLCODE;
}





/* �^���߮׫O����--
TRUNCATE TABLE car1398_tmp;

INSERT INTO car1398_tmp
SELECT UNIQUE ipolicy1, ipolicy2
FROM dwsdb:claim_app_main
WHERE dclaim BETWEEN '2011/01/01' AND '2011/12/31'
AND isys_source='CAR';

INSERT INTO car1398_tmp
SELECT UNIQUE a.ipolicy1, a.ipolicy2
FROM dwsdb:claim_app_main a, dwsdb:claim_stl_dtl b
WHERE a.iclaim1 = b.iclaim1
AND a.iclaim2 = b.iclaim2
AND b.dgroup BETWEEN '2011/01/01' AND '2011/12/31'
AND a.isys_source='CAR';

runbatch 00 930268 car1398 E 3 100/01/01 100/12/31 'C'
runbatch 00 930268 car1398 E 3 101/01/01 101/12/31 'C'
runbatch 00 930268 car1398 E 3 102/01/01 102/12/31 'C'
runbatch 00 930268 car1398 E 3 103/01/01 103/12/31 'C'
runbatch 00 930268 car1398 E 3 104/01/01 104/12/31 'C'
runbatch 00 930268 car1398 E 3 105/01/01 105/12/31 'C'
runbatch 00 930268 car1398 E 3 106/01/01 106/12/31 'C'
runbatch 00 930268 car1398 E 3 107/01/01 107/12/31 'C'
runbatch 00 930268 car1398 E 3 108/01/01 108/12/31 'C'
runbatch 00 930268 car1398 E 3 109/01/01 109/12/31 'C'
runbatch 00 930268 car1398 E 3 110/02/01 110/03/31 'C'
 */