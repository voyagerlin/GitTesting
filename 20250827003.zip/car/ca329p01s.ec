/*-------------------------------------------------------------------
 * Program: car329p01s.ec
 * Date   : 05/10/2002
 *-------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "is_def.h"
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"
$include sqlca;
$include sqltypes;
#define FOUND                   sqlca.sqlcode!=SQLNOTFOUND
#define NOT_FOUND               sqlca.sqlcode==SQLNOTFOUND

/*****************************************************************/

$char  DBName[5];
$char  userid[10];
char   sfile[21];
char   outputf[50];
$char  Today[11];
char   getfile[50];
char stmp[121];

static char  *bp;
FILE   *sfp,*fp;
static int   recLen=1024;

$char  sData[5][21];

int    rc, max_count = 0;

$char  BodyFile[21],TitleFile[21],BodyFmt[21],FormTp[3];
$char  TitleFmt[21],prtstr[10000];
$char  FormFmt[N_FILE+1];
$char  FormFile[N_FILE+1], OutFile[20];
$int   ItemRow, TotColumn;
$int   StartRow,TitleRow;
$int   PgLine, Width;

/*****************************************************************/
long car329_readfile();
long car329_title();
long car329_build1();
char *sTranscom();

main(argc,argv)
int  argc;
char **argv;
{
    long src;

    batchinit();
    strcpy(DBName,  isNULLstr(argv[1]));
    strcpy(userid,  isNULLstr(argv[2]));
    strcpy(sfile,   isNULLstr(argv[3]));
    strcpy(outputf, isNULLstr(argv[4]));

    strcpy(Today,cm_edate_str(cm_today()));

    printf("sfile[%s]\n",sfile);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
        return M_CM_DB_NOTOPEN;
    }
  
    src = car329_readfile();
      
    if (src != M_CM_OK)
        return src;
    return M_CM_OK;

errexit:
    printf("------car329_err: SQLCODE[%d]\n",SQLCODE);
    EWRITE(userid, SQLCODE,sqlca.sqlerrm);
    exit(1);
}

long car329_readfile()
{
    int    rtncode;
    char   sApHome[20];
    $char  stmt[1024];
    $char  sTmp[1001];
    int    k,m;
    int    i;
    long   ccnt;
    $char  ipolicy[21];
    $char  ibus_location[11];
    $char  iofficer[11];
    $char  ibig_sales[11];
    $char  note[3];
    $char  stmt_buf[100];

    $WHENEVER SQLERROR GOTO errexit;

    $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
            kTot_Col, kPgNum_Line, kWidth, iForm_Tp
       INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
            $TotColumn, $PgLine, $Width, $FormTp
       FROM Form
      WHERE ksys_grp="CA"
        AND kPgmID = 329;

    strcpy(TitleFmt,rtrim(TitleFmt));
    strcpy(BodyFmt,rtrim(BodyFmt));

    sprintf_s(TitleFile, sizeof TitleFile,"%s.ti",outputf);
    sprintf_s(BodyFile, sizeof BodyFile,"%s.bd",outputf);

    rgu_init_report( TitleFmt,TitleFile);

    printf("titlefile[%s]\n",TitleFmt);
    printf("bodyfile[%s]\n",BodyFmt);

    rtncode = getApHome(sApHome);
    if (rtncode < 0)
    {
         printf("read Config file error!!\n");
         return M_CM_READ_CONFIG_ERR;
    }

    sprintf_s(getfile, sizeof getfile, "%s/dat/car/%s", sApHome, sfile);

    printf("getfile[%s]\n",getfile);
    if ((fp=fopen(getfile,"rt"))==NULL) return FALSE;

    if ((bp=malloc(recLen))==NULL)
    {
         printf("System malloc failed  !\n");
         free(bp);
         return FAIL;
    }

    $CREATE TEMP TABLE car329
    (
       ipolicy       char(20),
       ibig_sales    char(10),
       ibus_location char(10),
       note          char(2)       
     ) WITH NO LOG;

    sprintf_s(stmt, sizeof stmt, "INSERT INTO car329 (ipolicy, ibig_sales, ibus_location, note) VALUES (?,?,?,?)");
    $PREPARE insid1 FROM $stmt;

    while(fgets(bp,recLen,fp))
    {
        if (feof(fp)) break;
        sTmp[0]='\0';
        GetData(sTmp , bp  , 100);
        strcpy( sTmp ,trim(sTmp));

        printf("After Get Data[%s]\n",sTmp);

        k = 0;
        m = 1;

        /* initial data */
        for(i=0;i<4;i++)
           sData[i][0] = '\0';

        for(i=0;i<100;i++)
        {
            if ((int)sTmp[i]>128)
            {
                i++;
                continue;
            }

            if (sTmp[i] == ',' || sTmp[i] == '\0' || (int)sTmp[i] == 13)
            {
                if (k == 0)
                    memcpy(sData[m],sTmp,i-k);
                else
                {
                    strncpy(sData[m],sTmp+k+1,i-k-1);
                    sData[m][i-k-1] = '\0';
                }

                strcpy(sData[m],trim(sTranscom(sData[m])));
                if (sTmp[i] == '\0' || (int)sTmp[i] == 13) break;
                m++;
                k = i;
                if (m > 30) break;
            }
        }
        printf("[%s][%s][%s][%s]\n",sData[1],sData[2],sData[3],sData[4]);
        $EXECUTE insid1 USING $sData[1],$sData[2],$sData[3],$sData[4];
    } /* end of while */

    /* 990531,�W�Ǫ���ƶW�L2�Ӥ�~�R�� */ 
    /* ���R��table:ply_302_update����� */
    printf("Begin Delete from ply_302_update \n");
    $DELETE FROM ply_302_update           
     WHERE (date_add(dupdate ,interval(2) month to month) -today)<0;    
/*           
    $BEGIN  WORK;
    ccnt = 0;
    $DECLARE cur_A CURSOR WITH HOLD FOR
      SELECT ipolicy
        FROM ply_302_update;
    $OPEN cur_A;
    for(;;)
    {
           $FETCH cur_A INTO $ipolicy;
           if (SQLCODE == SQLNOTFOUND) break;

           ccnt ++;

           $DELETE FROM ply_302_update WHERE ipolicy = $ipolicy;      

           if (ccnt == 1000)
           {
              ccnt = 0;
              EXEC SQL COMMIT WORK;
              EXEC SQL BEGIN WORK;
           }
    }
    $CLOSE cur_A;
    $FREE  cur_A;
    $COMMIT WORK;
    printf("End   Delete from ply_302_update \n");
*/
    rc=car329_title();
    rgu_finish_report();

    rgu_init_report( BodyFmt,BodyFile);
    $BEGIN  WORK;
    ccnt = 0;    
    $DECLARE cursor CURSOR WITH HOLD FOR
      SELECT ipolicy, ibus_location, ibig_sales, note
        INTO $ipolicy, $ibus_location, $ibig_sales, $note
        FROM car329;
    $OPEN cursor;
    for(;;)
    {
         $FETCH cursor;
         if(SQLCODE == SQLNOTFOUND)
             break;
         strcpy(ipolicy,       trim(ipolicy));
         strcpy(ibus_location, trim(ibus_location));
         strcpy(ibig_sales,    trim(ibig_sales));
         strcpy(note,          trim(note));
         
         	
         printf("[%s][%s][%s][%s]\n",ipolicy,ibus_location,ibig_sales,note);

         $SELECT iofficer
            INTO $iofficer
            FROM officer
           WHERE ibus_location = $ibus_location
             AND icomm_obj IN ('BS','JH');
         if(SQLCODE == SQLNOTFOUND)
         {
             stmt_buf[0] = '\0';
             strcpy(stmt_buf,"���I�N�����s�b");
             rgu_put_body_string(2, trim(ipolicy),       2);
             rgu_put_body_string(2, trim(ibus_location), 2);
             rgu_put_body_string(2, trim(ibig_sales),    2);
             rgu_put_body_string(2, trim(stmt_buf),      2);
             rgu_put_body(2);
             max_count++;
             continue;
         }         

         stmt_buf[0] = '\0';
         
         if (strncmp(note,"1",1)==0)
         {
             strcpy(stmt_buf,"�󴫷~�N");
         }
         else if (strncmp(note,"2",1)==0)
         {
             strcpy(stmt_buf,"�󴫾��I");
         }
         else if (strncmp(note,"3",1)==0)
         {
             strcpy(stmt_buf,"�~�N�ξ��I��");
         }else{
             stmt_buf[0] = '\0';
             strcpy(stmt_buf,"�\��N�X���s�b");
             rgu_put_body_string(2, trim(ipolicy),       2);
             rgu_put_body_string(2, trim(ibus_location), 2);
             rgu_put_body_string(2, trim(ibig_sales),    2);
             rgu_put_body_string(2, trim(stmt_buf),      2);
             rgu_put_body(2);
             max_count++;
             continue;         	  
         }
         rgu_put_body_string(2, trim(ipolicy),    2);
         rgu_put_body_string(2, trim(iofficer),   2);
         rgu_put_body_string(2, trim(ibig_sales), 2);
         rgu_put_body_string(2, trim(stmt_buf),   2);
         rgu_put_body(2);
         max_count++;
                 
         /* �����ƪ��ܥ��R�� */
         $DELETE FROM ply_302_update WHERE ipolicy = $ipolicy;         

         $INSERT INTO ply_302_update
                      (ipolicy,iofficer,ibig_sales,note,iupdate,dupdate)
              VALUES  ($ipolicy,$iofficer,$ibig_sales,$note,$userid,current);
         ccnt++;     
         if (ccnt == 500)
         {
             ccnt = 0;
             $COMMIT WORK;
             $BEGIN WORK;
         }               
    } /*  end for */
    $CLOSE cursor;
    $FREE  cursor;
    $COMMIT WORK;

    printf("  -----------finish----------\n");
    rgu_finish_report();

    $DROP TABLE car329;

    FormTp[0] = '\0';

    if(rc=(save_form_info(F_BLK1,"CA",329,userid,FormTp,max_count,outputf))<0)
    {
       printf("*** save_form_info() fail\n");
       EWRITE(userid,rc,"save_form_info failed");
       return rc;
    }

    fclose(fp);
    return M_CM_OK;

errexit:
    printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    fclose(fp);
    return SQLCODE;
}

int GetData(data,offset,length)
char *data;
int offset,length;
{
    data[0]='\0';
    memcpy(data,offset,length);
    data[length] = 0x00;
    printf("data[%s]\n",data);
}                   

/***********************************************************************/
long car329_title()
{
    printf(" *******************************\n");
    rgu_put_head_string( 1, cm_get_sysd());
    rgu_put_head();
}

/*  �h�� " */
char *sTranscom(s)
char s[200];
{
    /*char stmp[121];*/
    int  i ;

    if (s[0] == '\"')
         strcpy(stmp,s+1);
    else
         strcpy(stmp,s);

    i = strlen(rtrim(stmp));

    if (i<=0) return stmp;
    if (stmp[i-1] == '\"')
        stmp[i-1] = '\0';

    strcpy(stmp,trim(stmp));
       return stmp;
}

