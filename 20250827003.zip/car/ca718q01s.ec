/**********************************************************************/
/*                                                                    */
/*   program id   : ca718q01s.ec                                      */
/*   program name : �g��H�̷s�O����                                */
/*   date written : 2003/08/01                                        */
/*                                                                    */
/*   author       : Ryback Hsu                                        */
/**********************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#include "is_def.h"
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"
$include sqlca;
$include sqltypes;

#define TURE                    1
#define FALSE                   0
#define FOUND                   sqlca.sqlcode!=SQLNOTFOUND
#define NOT_FOUND               sqlca.sqlcode==SQLNOTFOUND
#define EQU(s1,s2)              !strcmp(s1,s2)
#define NOT_EQU(s1,s2)          strcmp(s1,s2)
#define NEXTPAGE                5

/**********************************************/
$char localdb[3],user_id[11],uid[11];
$char iofficer[EMPLOYEE_ID], officerbgn[11], officerend[11],qfficer[11];
$char quotabgn[11],imgr[2];
$char quota[10],date[3],iquota[7],nname[11],fclass[5];
$char datebgn[12], dateend[12];
$char plydatebgn[12], plydateend[12];
$char stmt[1024], stmt1[1024], stmt2[1024], stmt3[1024], stmt4[1024];
$char FormTp[3], TitleFmt[21], BodyFmt[21];
char  BodyFile[21],TitleFile[21],outputf[21],ins_type[100];
$int  ItemRow,TotColumn;
$int  StartRow,TitleRow, PgLine, Width = 0;
int   miy,rc;
long  m_prem,mdamagecover;
$long  mdmg_prem = 0,mlia_prem = 0,mdamage_cover,mdamagecover;
$char m_falldb[4];
char  falldb[4],prem[20],officer[11];
$char ipolicy[21],icard[21],iissue_ym[15],dpolicy[15],dply_begin[15];
$char dply_end[15],ncode[11],icar_type[3],ibrand[9],ifpce_id[11];
$char nassured[121],iassured[13],itag[CA_TAG_NUM],iengine[CA_ENGINE_NUM],nbranch[41];
$char iassured_ext[3],ipro_year[10],fsex[2],fmarriage[2];
$char aassured_zip[CA_ZIP],aassured[91],itel[21],nbrand[31],officer_id[11];
$char tphone_con[21],imovephone[30],iins_type[50];
$char ire_type[3],iresource[21],ibirth[11];
$char fcomp[3],fcomp_last[3],fBig[2];
$double  qcylinder = 0;/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/ 
char  yy1[4],mm1[3],dd1[3],yy2[4],mm2[3],dd2[3],begin[12],end[12];
long  ca718_build();
long  ca718_body();
long  ca718_title();
long  ca718_group();
$char  fcard_class[2];
char  iofficer_tmp[11],officerid[11],name[11],iquota_tmp[7];
short first;
int   count;
$char nequipment[31],flag_check_nequipment[5],nequipment_val[5];

/* car9806052 �s�q�O�g�ݭnemail�H�����p�渹 */
$char irelative_ply[21],iemail[51];
$long irelative_prem=0;
char policy_c[21],policy_v[21],tmp_str[10];
long prem_c = 0, prem_v = 0;

$char tmp_buf[5000], tmp_buf1[100], tmp_buf2[100], tmp_buf3[100], tmp_buf4[100];

/***************************************************************************/
main(argc, argv)
int argc;
char **argv;
{
    batchinit();
    strcpy(localdb,isNULLstr(argv[1]));
    strcpy(user_id,isNULLstr(argv[2]));
    strcpy(quota,isNULLstr(argv[3]));
    strcpy(imgr,isNULLstr(argv[4]));
    strcpy(iofficer,isNULLstr(argv[5]));
    strcpy(date,isNULLstr(argv[6]));
    strcpy(fclass,isNULLstr(argv[7]));
    strcpy(datebgn,isNULLstr(argv[8]));
    strcpy(dateend,isNULLstr(argv[9]));
    strcpy(flag_check_nequipment,isNULLstr(argv[10]));
    strcpy(fBig,isNULLstr(argv[11]));            /* fBig == 1 �j�v�~�ȱM�� */
    strcpy(outputf,isNULLstr(argv[12]));

    strcpy(officerbgn,iofficer);
    strcpy(quotabgn,iofficer);

    printf("localdb[%s], fBig[%s]\n", localdb, fBig);

    if (datebgn[0]=='*')
        strcpy(datebgn,"080/01/01");
    if (dateend[0]=='*')
        strcpy(dateend,"199/12/31");
    if (dateend[0]==' ' || dateend[0]=='\0')
        strcpy(dateend,datebgn);

    strcpy(plydatebgn,cm_to_infdate(datebgn));
    strcpy(plydateend,cm_to_infdate(dateend));

   if( fBig[0] == '0')
   {    if ((rc=ca718_build()) != M_CM_OK) return;}
   else            /* fBig == 1 �j�v�~�ȱM�� */
   {   if ((rc=ca718_build1()) != M_CM_OK) return;}

   create_sign_form("car718",BodyFile,Width);

   if( fBig[0] == '0')
   {
       if ((rc=save_form_info(F_BLK1,"CA",718,user_id,FormTp,miy,outputf))<0)
           EWRITE(user_id,rc,"save_form_info failed");
   }
         
}
/*****************************************************************/
long ca718_build()
{
   $char  nname[11];
    $date  dpolicy,dendorse;
    $long   mlia_prem,medrlia_prem,mins_premium,medrins_prem,mdamage_cover;
    int    rc;
	$char stmtaa[5000];


    if (db_select(localdb) == FALSE) {
        EWRITE(user_id,M_CM_DB_NOTOPEN,"M_CM_DB_NOTOPEN");
        return M_CM_DB_NOTOPEN;
    }

$   WHENEVER SQLERROR GOTO err_exit;

    rc = check_privilege();
    if( rc != M_CM_OK) return rc;

     /* strcpy( FormTp, ""); */

     $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kTot_Col,
           kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow, $TotColumn,
           $PgLine, $Width, $FormTp
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 718  AND iform_tp is null;

     strcpy(TitleFmt,rtrim(TitleFmt));
     strcpy(BodyFmt,rtrim(BodyFmt));
     sprintf_s(TitleFile, sizeof TitleFile,"%s.ti",outputf);
     sprintf_s(BodyFile, sizeof BodyFile,"%s.bd",outputf);

     printf("TitleFile:%s.ti\n",outputf);
     printf("BodyFile:%s.bd\n",outputf);

     miy= 0;
     printf("flag 1\n");
     ca718_title();
     rgu_init_report(BodyFmt,BodyFile);
     /*ca718_group();*/
     ca718_body();

     rgu_finish_report();

     return M_CM_OK;
err_exit:
    rc=SQLCODE;
    EWRITE(uid,SQLCODE,sqlca.sqlerrm);
$   WHENEVER SQLERROR CONTINUE;     /* reset error handling */
    return rc;
}
/********* build title ************/
long ca718_title()

  {

    rgu_init_report(TitleFmt,TitleFile);
    rgu_put_head_string(1, cm_sysd_edatetime(cm_sysd_cdatetime_100(cm_get_sysd())));
    if (date[0] == '0')
    rgu_put_head_string(1,"ñ����");
    else
    rgu_put_head_string(1,"������");
    /*cm_split_ymd_100(datebgn,yy1,mm1,dd1);
    rgu_put_head_string(1, yy1);
    rgu_put_head_string(1, mm1);
    rgu_put_head_string(1, dd1);
    cm_split_ymd_100(dateend,yy2,mm2,dd2);
    rgu_put_head_string(1, yy2);
    rgu_put_head_string(1, mm2);
    rgu_put_head_string(1, dd2);*/

    strcpy(begin,cm_to_infdate(datebgn));
    strcpy(end,cm_to_infdate(dateend));
    rgu_put_head_string(1, begin);
    rgu_put_head_string(1, end);
    rgu_put_head();



    rgu_finish_report();
}



/*-------------------build body--------------------------------*/
long ca718_body()
{
	$char stmt_buf[5000]; 
	$char stmt[5000];
	
	printf("flag body\n");
	$WHENEVER SQLERROR GOTO err_exit;

	sprintf_s(stmt, sizeof stmt,"SELECT ncode       		 "
						"FROM car_type    	 "
						"WHERE icode = ?   	 "
                        "AND fclass = '1' ");
	$PREPARE CUR2 FROM $stmt;

	sprintf_s(stmt, sizeof stmt,"SELECT first 1 nbrand,ipro_year        "
						"FROM ca_car_model                "
						"WHERE ibrand = ?                 "
						"order by ipro_year desc");
	$PREPARE CUR3 FROM $stmt;

	sprintf_s(stmt, sizeof stmt,"SELECT ifpce_id,tphone_con,imovephone  "
						"FROM cu_customer                 "
						"WHERE ifpce_id = ?               "
                        "AND ifpce_id_ext = ? ");
	$PREPARE CUR4 FROM $stmt;

	sprintf_s(stmt, sizeof stmt,"select nbranch                      	 "
                       "from sa_branch_type 			 "
                       "WHERE ibranch = ? ");
	$PREPARE CUR6 FROM $stmt;

	sprintf_s(stmt, sizeof stmt,"select ncode                      	 "
                        "from cu_code_data 				 "
                       	"WHERE icode = ? AND itype = '10'");
	$PREPARE CUR7 FROM $stmt;

	sprintf_s(stmt, sizeof stmt,"SELECT iins_type   			 "
            			"FROM ply_ins_type    	 "
           				"WHERE ipolicy = ?     	 "
             			"AND mdamage_cover != 0");
	$PREPARE Acursor2_id FROM $stmt;
	$DECLARE Acursor2 CURSOR FOR Acursor2_id;
	
        get_condition();

printf("step1\n");

    sprintf_s(stmt_buf, sizeof stmt_buf,
        "SELECT %s %s %s %s %s %s %s %s %s FROM %s %s %s %s %s %s %s %s",
        "a.ipolicy,a.icard,b.nassured[1,32],b.iassured,b.iassured_ext,a.ipro_year,",
        "(to_char(b.dissue,'%Y')::integer - 1911) ||'/' || to_char(b.dissue,'%m'),",
        "a.dpolicy,a.dply_begin,a.dply_end,a.iquota,to_char(b.dbirth,'%Y/%m/%d'),",        
        "a.mdmg_prem,a.mlia_prem,b.itag,b.iengine,b.aassured_zip,b.qcylinder,",
        "b.aassured,a.icar_type,a.ibrand,b.itel,a.iofficer,c.nname,a.iresource,",
        "fsex,fmarriage,decode(a.fcard_class,'1',fcomp_class,' '),",
        "decode(a.fcard_class,'1',fcomp_class_last,' '),b.nequipment,",
        "a.fcard_class,b.iemail,a.irelative_ply,",
        "(select mdmg_prem+mlia_prem from ply_relation where ipolicy = a.irelative_ply)",        
        "ply_relation a,policy b,officer c",
        "WHERE (a.ipolicy = b.ipolicy) ",
        "AND (a.iofficer = c.iofficer) AND a.fedr_class <> '1'",tmp_buf,tmp_buf1,tmp_buf4,tmp_buf2,tmp_buf3);
        
printf("step2\n");        

	$PREPARE CUR_STMT3 FROM $stmt_buf;
	$DECLARE Acursor1 CURSOR FOR CUR_STMT3;
	first=0;
	iofficer_tmp[0]='\0';
	iquota_tmp[0]='\0';
      
	strcpy(nequipment_val, " ");
	
printf("step3,stmt[%s]\n",stmt_buf);			
      
	$OPEN Acursor1;
    while (1) 
    {
		$FETCH Acursor1
		INTO $ipolicy,$icard,$nassured,$iassured,$iassured_ext,$ipro_year,
           	$iissue_ym,$dpolicy,$dply_begin,$dply_end,$iquota,$ibirth,
           	$mdmg_prem,$mlia_prem,$itag,$iengine,$aassured_zip,$qcylinder,
           	$aassured,$icar_type,$ibrand,$itel,$officer_id,$nname,$ire_type,
           	$fsex,$fmarriage,$fcomp,$fcomp_last,$nequipment,$fcard_class,
           	$iemail,$irelative_ply,$irelative_prem;

		if (SQLCODE == SQLNOTFOUND)
			break;
			
printf("step4\n");			

       	strcpy(iquota,trim(iquota));
       	strcpy(officer_id,trim(officer_id));
       	strcpy(name,nname);
       	/*strcpy(dbirth, cm_to_infdate(ibirth));*/       	

      	printf("SQLCODE:%d\n",SQLCODE);

       	$EXECUTE CUR2 INTO $ncode USING $icar_type;

       	$EXECUTE CUR3 INTO $nbrand,$ipro_year USING $ibrand;

       	$EXECUTE CUR4 INTO $ifpce_id,$tphone_con,$imovephone USING $iassured,$iassured_ext;

       	$EXECUTE CUR6 INTO $nbranch USING $iquota;
       
       	$EXECUTE CUR7 INTO $iresource USING $ire_type;
       	
       	if (flag_check_nequipment[0] == '1')
       	{
       		if ( equip_cmp(nequipment,"50") )
       			strcpy(nequipment_val, "Y1");
       		else if ( equip_cmp(nequipment,"51") )
       			strcpy(nequipment_val, "Y2");
			else if ( equip_cmp(nequipment,"52") )
				strcpy(nequipment_val, "N");
			else
				strcpy(nequipment_val, "X");
       	}
		
       	$OPEN Acursor2 USING $ipolicy;
        ins_type[0]='\0';
       	while (1)
       	{
			$FETCH Acursor2 INTO $iins_type;
           	if( SQLCODE == SQLNOTFOUND) break;

       		strcat (ins_type,trim(iins_type));
       		strcat (ins_type," ");
		   }
		   $CLOSE Acursor2;
		   
		   /* �]���j�����N�O��/�O�O�����}��m,�G�ݭn�P�_�ӵ��O�欰�j��or���N,�~���D�n��m�b������� */
		   if (strncmp(fcard_class,"1",1) == 0)
		   {
		   	/* �j�� */
		   	strcpy(policy_c,ipolicy);
		   	strcpy(policy_v,irelative_ply);
		   	prem_c = mdmg_prem + mlia_prem;
		   	prem_v = irelative_prem;
		   } else {
		   	/* ���N */
		   	strcpy(policy_c,irelative_ply);
		   	strcpy(policy_v,ipolicy);
		   	prem_c = irelative_prem;
		   	prem_v = mdmg_prem + mlia_prem;
		   }

     	if ((strcmp(iofficer_tmp,officer_id) == 0) && (strcmp(iquota_tmp,iquota) == 0))
        {
			ca718_print();
        }
     	else
       	{
			if(first)
			{
             	rgu_put_body(5);
              	miy++;
			}
       		ca718_group();
       		ca718_print();
       		first = 1;
		}

        strcpy(iofficer_tmp,officer_id);
        strcpy(iquota_tmp,iquota);
	} /*END OF WHILE*/
	$CLOSE Acursor1;

 	return M_CM_OK;

err_exit:
    rc=SQLCODE;
    printf("SQLCODE[%d],errm[%s]\n",SQLCODE,sqlca.sqlerrm);
    EWRITE(user_id,SQLCODE,sqlca.sqlerrm);
	$WHENEVER SQLERROR CONTINUE;     /* reset error handling */
    return rc;

}
/**************************************************/
long ca718_print()

{
$   WHENEVER SQLERROR GOTO err_exit;
         
           m_prem = 0 ;
           m_prem = mdmg_prem+mlia_prem;
           rfmtlong(m_prem,"-,---,---,--&",prem);

          rgu_put_body_string(3,trim(ipolicy),1);
          rgu_put_body_string(3,trim(icard),1);
          rgu_put_body_string(3,trim(nassured),1);
          rgu_put_body_string(3,trim(iassured),1);
          rgu_put_body_string(3,trim(itag),1);
          rgu_put_body_string(3,trim(iengine),1);
          rgu_put_body_string(3,trim(iissue_ym),1);
          rgu_put_body_string(3,trim(ncode),1);
          rgu_put_body_string(3,trim(nbrand),1);
          rgu_put_body_string(3,trim(dpolicy),1);
          rgu_put_body_string(3,trim(dply_begin),1);
          rgu_put_body_string(3,trim(dply_end),1);
          rgu_put_body_string(3,trim(prem),2);
          rgu_put_body_string(3,rtrim(ins_type),1);
          rgu_put_body_string(3,trim(aassured_zip),1);
          rgu_put_body_string(3,trim(aassured),1);
          rgu_put_body_string(3,trim(itel),1);
          rgu_put_body_string(3,trim(tphone_con),1);
          rgu_put_body_string(3,trim(imovephone),1);
          rgu_put_body_string(3,trim(iresource),1);
          rgu_put_body_string(3,trim(ibirth),1);
          rfmtdouble(qcylinder,"--,--&.--",tmp_str);/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/
          rgu_put_body_string(3,trim(tmp_str),2);
          rgu_put_body_string(3,fsex,1);
          rgu_put_body_string(3,fmarriage,1);
          rgu_put_body_string(3,fcomp,1);
          rgu_put_body_string(3,fcomp_last,1);
          rgu_put_body_string(3,nequipment_val,1);
          rgu_put_body_string(3,iemail,1);
          rgu_put_body_string(3,policy_c,1);
          rgu_put_body_string(3,policy_v,1);
          rfmtlong(prem_c,"-,---,---,--&",tmp_str);
          rgu_put_body_string(3,trim(tmp_str),2);
          rfmtlong(prem_v,"-,---,---,--&",tmp_str);
          rgu_put_body_string(3,trim(tmp_str),2);
          rgu_put_body(3);
          miy++;
return M_CM_OK;
err_exit:
    rc=SQLCODE;
    EWRITE(uid,SQLCODE,sqlca.sqlerrm);
$   WHENEVER SQLERROR CONTINUE;     /* reset error handling */
    return rc;
}
/*****************************************************************/
long ca718_group()
{
$   WHENEVER SQLERROR GOTO err_exit;


             rgu_put_body_string(1,trim(nbranch),1);

             rgu_put_body(1);
             miy++;

             rgu_put_body_string(2,trim(officer_id),1);
             rgu_put_body_string(2,trim(nname),1);
             rgu_put_body(2);
             miy++;
return M_CM_OK;
err_exit:
    rc=SQLCODE;
    EWRITE(uid,SQLCODE,sqlca.sqlerrm);
$   WHENEVER SQLERROR CONTINUE;     /* reset error handling */
    return rc;
    }
long check_privilege()
{
    if (db_select(localdb) == FALSE) {
        EWRITE(user_id,M_CM_DB_NOTOPEN,"M_CM_DB_NOTOPEN");
        return M_CM_DB_NOTOPEN;
    }

    strcpy(uid,user_id);
    printf("133 uid:%s\n",uid);
    $SELECT falldb
       INTO $m_falldb
       FROM privilege
      WHERE iemp = $uid
        AND ipgid = 'car718';

     printf("139 m_falldb:%s\n",m_falldb);

    if (m_falldb[0] =='N')
    {
          if (quota[0]=='o')
          {
          		printf("uid = %s \n",uid);
          		printf("officerbgn = %s \n",officerbgn);
              $select b.iofficer
                 into $iofficer
                 from officer a,officer b
                where a.iofficer   = $uid
                  and b.iofficer   matches $officerbgn
                  and a.iquota[1,4]= b.iquota[1,4];
                  if (SQLCODE == SQLNOTFOUND)
                  {
                      EWRITE(uid,SQLCODE,"�v�������A����d�ߨ�L���g����");
                      return SQLCODE;
                  }
          }
          else if (quota[0]=='q')
          {
         	printf("uid = %s \n",uid);
         	printf("quotabgn = %s \n",quotabgn);

              if (strlen(trim(quotabgn))==4)
              {
                  $select iofficer
                     into $iofficer
                     from officer
                    where iquota[1,4] matches $quotabgn
                      and iofficer    = $uid;
              }
              else
              {
                  $select iofficer
                     into $iofficer
                     from officer
                    where iquota      matches $quotabgn
                      and iofficer    = $uid ;
              }
              if (SQLCODE == SQLNOTFOUND)
              {
                   EWRITE(uid,SQLCODE,"�v�������A����d�ߨ�L�����");
                   return SQLCODE;
              }
         }
     }

     return M_CM_OK;

err_exit:
    rc=SQLCODE;
    EWRITE(uid,SQLCODE,sqlca.sqlerrm);
$   WHENEVER SQLERROR CONTINUE;     /* reset error handling */
    return rc;
}
get_condition()
{
    /*******************************************************************************/
    if (quota[0] == 'q')
    {
    	if (strlen(trim(quotabgn))==4)
      	{
       	 	printf("flag 2\n");
        	sprintf_s(tmp_buf2, sizeof tmp_buf2,"and (a.iquota[1,4] matches '%s')",quotabgn);
      	}
      	else
      	{
			sprintf_s(tmp_buf2, sizeof tmp_buf2,"and (a.iquota matches '%s')",quotabgn);
      	}
    }
    else
    {
	sprintf_s(tmp_buf2, sizeof tmp_buf2,"and (a.iofficer matches '%s')",officerbgn);
    }

    if (fclass[0] == '1')
    {
		sprintf_s(tmp_buf1, sizeof tmp_buf1,"and (a.fcard_class = '1')");
    }
    else if (fclass[0] == '2')
    {
		sprintf_s(tmp_buf1, sizeof tmp_buf1,"and (a.fcard_class = '2')");
    }
    else
    {
		sprintf_s(tmp_buf1, sizeof tmp_buf1,"");
    }

    if (date[0] == '0')
	{
		sprintf_s(tmp_buf, sizeof tmp_buf,"and (a.dpolicy BETWEEN '%s' AND '%s')",
                                  plydatebgn,plydateend);
	}
	else
	{
		sprintf_s(tmp_buf, sizeof tmp_buf,"and (a.dply_end BETWEEN '%s' AND '%s')",
                                  plydatebgn,plydateend);
	}

	sprintf_s(tmp_buf3, sizeof tmp_buf3,"ORDER BY a.iquota,a.iofficer,a.ipolicy");
    
    if (imgr[0] == '1')
    {
		sprintf_s(tmp_buf4, sizeof tmp_buf4,"and (c.imgr = '1')");
    }
    else if (imgr[0] == '2')
    {
		sprintf_s(tmp_buf4, sizeof tmp_buf4,"and (c.imgr = '2')");
    }
    else
    {
		sprintf_s(tmp_buf4, sizeof tmp_buf4,"");
    }
}    
/*****************************************************************/

long ca718_build1()
{
    int    rc;

    $char   ipolicy[21],  iassured[21],  nassured[121],  dbirth[21],  dply_begin[21],  dply_end[21],  dissue[21];  
    $char   ipro_year[21],  qpro_month[21],  itag[CA_TAG_NUM],  ibrand[21],  qpt[21],  fpt[21],  icar_type[21],  qcylinder[21];  
    $char   mcar_price[21],  mequipment[21],  iofficer[21],  fcal_way[21],  fcomp_class[21],  lia_class[21],  pdmg_acc[21];
    $char   mpremium[21], iins_type[21],  minjured_cover[21],  mdeath_cover[21],  mdamage_cover[21],  mdeduct[21],  mins_premium[21]; 
    $char   sTmp[1024], class[21], sTmp2[101], stitle[1024];

    puts("ca718_build1");
    if (db_select(localdb) == FALSE) {
        EWRITE(user_id,M_CM_DB_NOTOPEN,"M_CM_DB_NOTOPEN");
        return M_CM_DB_NOTOPEN;
    }

    $WHENEVER SQLERROR GOTO err_exit;

    rc = check_privilege();
    if( rc != M_CM_OK) return rc;

    get_condition();

    strcpy( FormTp, "1");
    miy=0;

     $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kTot_Col,
           kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow, $TotColumn,
           $PgLine, $Width, $FormTp
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 718  AND iform_tp = $FormTp;

     strcpy(TitleFmt,rtrim(TitleFmt));
     strcpy(BodyFmt,rtrim(BodyFmt));
     sprintf_s(TitleFile, sizeof TitleFile,"%sA.ti",outputf);
     sprintf_s(BodyFile, sizeof BodyFile,"%sA.bd",outputf);

     if (date[0] == '0')
         strcpy( sTmp2, "ñ�����G");
     else
         strcpy( sTmp2, "�������G");

     rgu_init_report(TitleFmt,TitleFile);
     rgu_put_head_string(1, cm_sysd_edatetime(cm_sysd_cdatetime_100(cm_get_sysd())));
     sprintf_s(stitle, sizeof stitle, "CAR718 %s %s ~ %s     �C�L����G%s", sTmp2, datebgn, dateend, cm_sysd_edatetime(cm_sysd_cdatetime_100(cm_get_sysd())));
     rgu_put_head_string(1, stitle);
     rgu_put_head();
     rgu_finish_report();

    rgu_init_report(BodyFmt,BodyFile);
    sprintf_s(sTmp, sizeof sTmp, "\t�O�渹�X\t�Q�O�I�HID\t�Q�O�I�H�W��\t�ͤ�\t�ͮĤ�\t�����\t�o�Ӧ~��\t�s�y�~��\t�s�y��\t�P��\t�t�P�����N��\t�����ƶq\t�������P/T\t����\t�Ʈ�q\t��l����\t�t�ƻ�\t�g��N��\t�p��O\t�j��/���d�ż�\t����Y��\t�`�O�O\t");
    rgu_put_body_string( 1, sTmp, 1);
    rgu_put_body( 1);
    miy++;
    sprintf_s(stmt, sizeof stmt, "SELECT a.ipolicy, b.iassured, b.nassured, b.dbirth, a.dply_begin, a.dply_end, b.dissue, a.ipro_year, "
                   "       b.qpro_month, b.itag, a.ibrand, b.qpt, b.fpt, a.icar_type, b.qcylinder, b.mcar_price, b.mequipment, "
                   "       a.iofficer, b.fcal_way, case when a.fcard_class = '1' then a.fcomp_class else b.lia_class end, " 
                   "       b.pdmg_acc, a.mlia_prem+a.mdmg_prem "
                   "  FROM policy b, ply_relation a "
                   " WHERE a.ipolicy = b.ipolicy "
                   "   %s %s %s %s %s", tmp_buf, tmp_buf1, tmp_buf2, tmp_buf4, tmp_buf3);

    $PREPARE prep1 FROM $stmt;
    $DECLARE curs1 CURSOR FOR prep1;
    $OPEN curs1;
    for(;;)
    {
        $FETCH curs1 INTO $ipolicy, $iassured, $nassured, $dbirth, $dply_begin, $dply_end, $dissue, $ipro_year, 
                          $qpro_month, $itag, $ibrand, $qpt, $fpt, $icar_type, $qcylinder, $mcar_price, $mequipment, 
                          $iofficer, $fcal_way, $class, $pdmg_acc, $mpremium;
        if( SQLCODE == SQLNOTFOUND) break;
        iassured[3] = '*';
        iassured[4] = '*';
        iassured[5] = '*';
        sprintf_s(sTmp, sizeof sTmp,"\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t", 
                      ipolicy,  iassured,  nassured,  dbirth,  dply_begin,  dply_end,  dissue,  ipro_year,  qpro_month,  itag,  
                      ibrand,  qpt,  fpt,  icar_type,  qcylinder,  mcar_price,  mequipment,  iofficer,  fcal_way,  class,  
                      pdmg_acc,  mpremium);
        rgu_put_body_string( 1, sTmp, 1);
        rgu_put_body( 1);
        miy++;
    }
     rgu_finish_report();

    if ((rc=save_form_info(F_BLK0,"CA",718,user_id,FormTp,miy,outputf))<0)
        EWRITE(user_id,rc,"save_form_info failed");

    /* ���� ------------------------------------------------- */
     strcpy( FormTp, "2");
     miy=0;

     $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kTot_Col,
           kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow, $TotColumn,
           $PgLine, $Width, $FormTp
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 718  AND iform_tp = $FormTp;

     strcpy(TitleFmt,rtrim(TitleFmt));
     strcpy(BodyFmt,rtrim(BodyFmt));
     sprintf_s(TitleFile, sizeof TitleFile,"%sB.ti",outputf);
     sprintf_s(BodyFile, sizeof BodyFile,"%sB.bd",outputf);

     rgu_init_report(TitleFmt,TitleFile);
     rgu_put_head_string(1, cm_sysd_edatetime(cm_sysd_cdatetime_100(cm_get_sysd())));
     rgu_put_head_string(1, stitle);
     rgu_put_head();
     rgu_finish_report();

    rgu_init_report(BodyFmt,BodyFile);
    sprintf_s(sTmp, sizeof sTmp, "\t�O�渹�X\t�Q�O�I�HID\t�Q�O�I�H�W��\t�ͤ�\t�ͮĤ�\t�����\t�o�Ӧ~��\t�s�y�~��\t�s�y��\t�P��\t�t�P�����N��\t�����ƶq\t�������P/T\t����\t�Ʈ�q\t��l����\t�t�ƻ�\t�g��N��\t�p��O\t�j��/���d�ż�\t����Y��\t�`�O�O\t�I�إN��\t��˫O�B\t���`�O�B\t�ƬG�O�B\t�ۭt�B\t�I�ثO�O\t");
    rgu_put_body_string( 1, sTmp, 1);
    rgu_put_body( 1);
    miy++;
    sprintf_s(stmt, sizeof stmt, "SELECT a.ipolicy, b.iassured, b.nassured, b.dbirth, a.dply_begin, a.dply_end, b.dissue, a.ipro_year, "
                   "       b.qpro_month, b.itag, a.ibrand, b.qpt, b.fpt, a.icar_type, b.qcylinder, b.mcar_price, b.mequipment, "
                   "       a.iofficer, b.fcal_way, case when a.fcard_class = '1' then a.fcomp_class else b.lia_class end, " 
                   "       b.pdmg_acc, a.mlia_prem+a.mdmg_prem, "
                   "       c.iins_type, c.minjured_cover, c.mdeath_cover, c.mdamage_cover, c.mdeduct, c.mins_premium "
                   "  FROM policy b, ply_relation a, ply_ins_type c "
                   " WHERE a.ipolicy = b.ipolicy "
                   "   AND a.ipolicy = c.ipolicy "
                   "   %s %s %s %s %s", tmp_buf, tmp_buf1, tmp_buf2, tmp_buf4, tmp_buf3);

    $PREPARE prep2 FROM $stmt;
    $DECLARE curs2 CURSOR FOR prep2;
    $OPEN curs2;
    for(;;)
    {
        $FETCH curs2 INTO $ipolicy, $iassured, $nassured, $dbirth, $dply_begin, $dply_end, $dissue, $ipro_year, 
                          $qpro_month, $itag, $ibrand, $qpt, $fpt, $icar_type, $qcylinder, $mcar_price, $mequipment, 
                          $iofficer, $fcal_way, $class, $pdmg_acc, $mpremium, 
                          $iins_type, $minjured_cover, $mdeath_cover, $mdamage_cover, $mdeduct, $mins_premium;
        if( SQLCODE == SQLNOTFOUND) break;
        iassured[3] = '*';
        iassured[4] = '*';
        iassured[5] = '*';
        sprintf_s(sTmp, sizeof sTmp,"\t%s\t %s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t", 
                      ipolicy,  iassured,  nassured,  dbirth,  dply_begin,  dply_end,  dissue,  ipro_year,  qpro_month,  itag,  
                      ibrand,  qpt,  fpt,  icar_type,  qcylinder,  mcar_price,  mequipment,  iofficer,  fcal_way,  class,  
                      pdmg_acc,  mpremium, iins_type,  minjured_cover,  mdeath_cover,  mdamage_cover,  mdeduct,  mins_premium);
        rgu_put_body_string( 1, sTmp, 1);
        rgu_put_body( 1);
        miy++;
    }
     rgu_finish_report();

    if ((rc=save_form_info(F_BLK0,"CA",718,user_id,FormTp,miy,outputf))<0)
        EWRITE(user_id,rc,"save_form_info failed");

     return M_CM_OK;
err_exit:
    rc=SQLCODE;
    EWRITE(uid,SQLCODE,sqlca.sqlerrm);
$   WHENEVER SQLERROR CONTINUE;     /* reset error handling */
    return rc;
}
