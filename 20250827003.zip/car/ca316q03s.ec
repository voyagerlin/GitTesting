/*******************************************/
/*                                         */
/*   ���I��O�����έp��                    */
/*                                         */
/*   PROGRAM : car316q03s.ec               */
/*   �M�ץ���O�v                          */
/*******************************************/

#include <stdio.h>
#include <string.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"

#define  head_line         1
#define  data_line         2

#define PRINTF_FLAG

extern char RPTDIR[];

$char quota[6],type[2];
$char dclose[11],dclose_end[11],dopen[11],dopen_end[11];
$static char dbgn1[11], dend1[11];
$static char dbgn_inf[11], dend_inf[11];
char  MsgCode[50];

/** ca_promote **/
$char  iprmt[10], nprmt[30], iagent[10], iofficer_ch1[2], ioff_chk[10];
$char  iofficera_ch1[2];
$char  pro_no[6], fanother[3], iofficera_1[2], ioff_chka[10], iofficer_ch1[2];
$int   iremark, iofficer_len, ioff_ck_bgn, ioff_ck_len, ioff_ck_end;
$int   lofficera , ioff_chk_bgna, ioff_chk_lena, ioff_ch_enda;
$long  mlimit;
$int   iequip_flag;
$char  sequip_str[201], iequip_tmp[4], stroff[300], stroffb[200],stroffc[300];


$char DBName[5], iForm_Tp[3];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1];
char  outputf[N_FILE+1], userid[11];

$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;

int  max_cnt;

long car316_build1();
long car316_build2();
long car316_body1();
long car316_body2();
long car316_accumulate();
void car316_title();  
char *getdate();
char *setdate();

main(argc, argv)
int argc;
char **argv;
{
   int rc,str_len;

   batchinit();
   strcpy(DBName,  isNULLstr(argv[1]));
   strcpy(userid,  isNULLstr(argv[2]));
   strcpy(dbgn1,   isNULLstr(argv[3]));
   strcpy(dend1,   isNULLstr(argv[4]));
   strcpy(dopen,   isNULLstr(argv[5]));
   strcpy(dclose,  isNULLstr(argv[6]));
   strcpy(pro_no,  isNULLstr(argv[7]));

   strcpy(outputf, isNULLstr(argv[8]));

   strcpy(dbgn_inf,   cm_to_infdate(dbgn1));
   strcpy(dend_inf,   cm_to_infdate(dend1));
   strcpy(dopen_end,  cm_to_infdate(dopen));
   strcpy(dclose_end, cm_to_infdate(dclose));

   printf("dopen_end[%s]\n",dopen_end);
   
   rc = get_ca_promote();
   if( rc != M_CM_OK )
   {
      return rc;
   }

   rc = car316_accumulate();
   if ( rc != M_CM_OK)
   {
        EWRITE(userid, rc, " ");
        return rc;
   }

   max_cnt=0;


   
   strcpy(MsgCode," ");
   rc = car316_build1(); 
   if (rc != M_CM_OK)
   {
       if (MsgCode[0]==' ')
           EWRITE(userid, rc, " ");
       else
           EWRITE(userid, rc, MsgCode);
       return rc;
   }
   
   
   strcpy(MsgCode," ");
   rc = car316_build2();
   if (rc != M_CM_OK)
   {
       if (MsgCode[0]==' ')
           EWRITE(userid, rc, " ");
       else
           EWRITE(userid, rc, MsgCode);
       return rc;
   }
   
   strcpy(MsgCode," ");
   rc = car316_build3();
   if (rc != M_CM_OK)
   {
       if (MsgCode[0]==' ')
           EWRITE(userid, rc, " ");
       else
           EWRITE(userid, rc, MsgCode);
       return rc;
   }

}

long car316_build1()
{
   $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];

   int    rc;

   max_cnt = 0;
   printf("build1 start\n");
   $WHENEVER SQLERROR GOTO errexit;

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt,  $StartRow,  $TitleRow,  $ItemRow,
           $TotColumn, $PgLine, $Width, $iForm_Tp
      FROM Form
     WHERE ksys_grp = "CA" AND kPgmID = 3163
       AND iForm_Tp = '12';

   strcpy(TitleFmt,rtrim(TitleFmt));
   sprintf(TitleFile,"%sA.ti",outputf);  
   strcpy(BodyFmt, rtrim(BodyFmt));
   sprintf(BodyFile, "%sA.bd",outputf);

   rgu_init_report(TitleFmt,TitleFile);
   car316_title();                        
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);

   rc = car316_body1();  /** �έp�� **/

   if (rc != M_CM_OK)
       return rc;
   rgu_finish_report();

   if ((rc=save_form_info(F_BLK1, "CA", 3163, userid, iForm_Tp, max_cnt, outputf))<0) {
        strcpy(MsgCode,"save_form_info failed");
        return rc;
   }

   return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

long car316_build2()
{
   $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];

   int    rc;

   max_cnt = 0;
printf("build2 start\n");
   $WHENEVER SQLERROR GOTO errexit;

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt,  $StartRow,  $TitleRow,  $ItemRow,
           $TotColumn, $PgLine, $Width, $iForm_Tp
      FROM Form
     WHERE ksys_grp = "CA" AND kPgmID = 3163
       AND iForm_Tp = '13';

   strcpy(TitleFmt,rtrim(TitleFmt));
   sprintf(TitleFile,"%sB.ti",outputf);  
   strcpy(BodyFmt, rtrim(BodyFmt));
   sprintf(BodyFile, "%sB.bd",outputf);

   rgu_init_report(TitleFmt,TitleFile);
   car316_title();                        
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);

   rc = car316_body2(); /**** B����Ӫ� ****/

   if (rc != M_CM_OK)
       return rc;
   rgu_finish_report();

   if ((rc=save_form_info(F_BLK1, "CA", 3163, userid, iForm_Tp, max_cnt, outputf))<0) {
        strcpy(MsgCode,"save_form_info failed");
        return rc;
   }

   return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

long car316_build3()
{
   $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];

   int    rc;

   max_cnt = 0;
   printf("build3 start\n");
   $WHENEVER SQLERROR GOTO errexit;

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt,  $StartRow,  $TitleRow,  $ItemRow,
           $TotColumn, $PgLine, $Width, $iForm_Tp
      FROM Form
     WHERE ksys_grp = "CA" AND kPgmID = 3163
       AND iForm_Tp = '13';

   strcpy(TitleFmt,rtrim(TitleFmt));
   sprintf(TitleFile,"%sC.ti",outputf);  
   strcpy(BodyFmt, rtrim(BodyFmt));
   sprintf(BodyFile, "%sC.bd",outputf);

   rgu_init_report(TitleFmt,TitleFile);
   car316_title();                        
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);

   rc = car316_body3(); /**** A����Ӫ� ****/

   if (rc != M_CM_OK)
       return rc;
   rgu_finish_report();

   if ((rc=save_form_info(F_BLK1, "CA", 3163, userid, iForm_Tp, max_cnt, outputf))<0) {
        strcpy(MsgCode,"save_form_info failed");
        return rc;
   }

   return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

/*-----------------------------------------------------------------*/
/**
1.����XB���ơA�A��B���XA����

   �ĤG�~B�� -------> �ĤG�~A��
 -------------      -------------
   �e�@�~B�� -------> �e�@�~A��(�i��|�S��)

**/
long car316_accumulate()
{
   $char tmp_fulldb[40], stmt[4096], stmt1[1024], stmt2[1024], stmt3[1024];
   $char itop[2], idealer[4], iofficer[11], iresource[2], dissue[11];
   $char iresource_1[2], iresource_2[2];
   $char itop_t[2], idealer_t[4], iofficer_t[11], iresource_t[2], dissue_t[11];
   $char inext_ply[21], fcard_class[2], ins_type[INSURANCE_TYPE], fedr_class[2], tmp_year[4];
   $char iissue_yy[4], t_yy[4];
   $char iofficer_1[11], iofficer_2[11], dendorse[11], iedr_type[3];
   $char ipolicy[21], iquota[7], iquota_t[7], iquota_s[7], iofficer_old[11];
   $long prem_t, prem, con_cnt;
   $long mdamage_cover;
   $int  id1,id2,id3,id4, myear, mark, t_year, o_year, mark_edr, aidm, aid1;
   $int  ricnt,clmcnt;
   $double pdiscount;

   $char LHsIlast_ply[11] ;
   $char ori_dply_end[11], new_dply_end[11];
   $char iquota_1[7],iquota_2[7];
   $char iquota_old[7], ori_iassured[11];
   $char iengine[CA_ENGINE_NUM],iengine_t[CA_ENGINE_NUM], nassured[13], nassured_t[13];
   $char iofficer_next[11],ileader[11];
   $long duty_date, l_dply_begin;
   $char ori_dply_begin[11],new_dply_begin[11],ori_dpolicy[11],new_dpolicy[11];
   $char ori_ibigsales[11], new_ibigsales[11];
   $char ori_ibigoffice[11], new_ibigoffice[11];
   $char ibranch_in[3], ibranch_in_t[3], ibranch_in_old[3];
   $char iofficer_s[11], iofficer_w[11], iofficer_w_t[11];
   $char ori_tag[CA_TAG_NUM], new_tag[CA_TAG_NUM];
   $char stmt_assured[200], stmt_next[81];

   /** A�椺�e **/
   $char Aipolicy[21], Ainext_ply[21], Ailast_ply[21];
   $char Aiofficer[11], Aiofficer_t[11], Aiofficer_s[11], Aiofficer_1[11], Aiofficer_2[11];
   $char ori_Adply_end[13], ori_Adply_begin[13], ori_Adpolicy[13];
   $char new_Adply_begin[13], new_Adply_end[13], new_Adpolicy[13];
   $char Aibranch_in[3], Aibranch_in_t[3], Aibranch[3], Aibranch_old[3], Aibranch_t[3];
   $char Aiengine[CA_ENGINE_NUM], Aori_tag[CA_TAG_NUM], Aiengine_t[CA_ENGINE_NUM], Anew_tag[CA_TAG_NUM];
   $char Ains_type[INSURANCE_TYPE], Afedr_class[2], Adendorse[13], Anassured[13], Anassured_t[13];
   $char Aiquota[7], Aiquota_s[7], Aiquota_1[7], Aiquota_2[7],dply_end_A2[13];
   
   $long Aprem, Aprem_t, Amdamage_cover, lnew_dply_end;
   $long lnew_tmp1, lnew_tmp2;
   $int  Acon_cnt, Arenew_cnt;
   $double Apdiscount;
    int  no_add_316A, with_next, with_last;
    
   /** �X�� A+B **/
   $char ibranch_mge[3], iquota_mge[7], iengine_mge[CA_ENGINE_NUM], iofficer_mge[11];
   $int  renew_cnt_mge, con_cnt_mge;
   $long prem_mge;
   
   $long dperiod;   /* Modified by Julia in 2007/01/17 */

   int   rtncode = 0, LiFlag = 0, rc;
   int   k,count_db,j,m;
   DBinfo *list;

   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT;

   if (db_select(DBName) == False)
   {
       return M_CM_DB_NOTOPEN;
   }

   $CREATE TEMP TABLE CAR316
    (
      ibranch           char(3)  not null,
      ibranch_t         char(3)  not null,
      ibranch_old       char(3)  not null,
      iofficer          char(10) not null,
      iquota            char(6)  not null,
      iofficer_t        char(10) not null,
      iquota_t          char(6)  not null,
      iofficer_old      char(10) not null,
      iquota_old        char(6)  not null,
      ipolicy           char(20) not null,
      inext_ply         char(20),
      iengine           char(25),
      iengine_t         char(25),
      renew_cnt         integer       default 0 not null,
      con_cnt           integer       default 0 not null,
      prem              decimal(10,0) default 0 not null,
      pdiscount		decimal(5,2)  default 0 not null,
      nassured_t	char(12),
      nassured_old	char(12),
      ibig_sales_t      char(10),
      iofficer_w        char(10),
      iofficer_w_t      char(10),
      dply_begin_t	char(11),
      dply_end_t	char(11),
      dply_begin_old	char(11),
      dply_end_old	char(11),
      itag_t		char(12),
      itag_old		char(12)
    ) WITH NO LOG;
    /**
    ibranch           �k�ݳ��
    ibranch_t         �s���
    ibranch_old       �³��
    iofficer          �k�ݨ�����~��	iofficer_s
    iquota            �k�ݷ~�Z���	iquota_s
    iofficer_t        �s������~��	new_ibigoffice
    iquota_t          �s�~�Z���	iquota_2
    iofficer_old      �¨�����~��	old_ibigoffice
    iquota_old        �·~�Z���	iquota_1
    ipolicy           �O�渹
    inext_ply         ��O�渹
    renew_cnt         �i��O���
    con_cnt           ��O���
    iofficer_w        �¸g��N��	iofficer_1
    iofficer_w_t      �s�g��N��	iofficer_2
    **/
   
   $CREATE TEMP TABLE CAR316A
    (
      ibranch           char(3)  not null,
      ibranch_t         char(3)  not null,
      ibranch_old       char(3)  not null,
      iofficer          char(10) not null,
      iquota            char(6)  not null,
      iofficer_t        char(10) not null,
      iquota_t          char(6)  not null,
      iofficer_old      char(10) not null,
      iquota_old        char(6)  not null,
      ipolicy           char(20) not null,
      inext_ply         char(20),
      iengine_t         char(25),
      iengine_old       char(25),
      renew_cnt         integer       default 0 not null,
      con_cnt           integer       default 0 not null,
      prem              decimal(10,0) default 0 not null,
      pdiscount		decimal(5,2)  default 0 not null,
      nassured_t	char(12),
      nassured_old	char(12),
      dply_begin_t	char(11),
      dply_end_t	char(11),
      dply_begin_old	char(11),
      dply_end_old	char(11),
      itag_t		char(12),
      itag_old		char(12)
    ) WITH NO LOG;
    
    $CREATE TEMP TABLE CAR316_MGE
    (
      ibranch           char(3)  not null,
      iofficer          char(10) not null,
      iquota            char(6)  not null,
      iengine           char(25),
      renew_cnt         integer       default 0 not null,
      con_cnt           integer       default 0 not null,
      prem              decimal(10,0) default 0 not null
    ) WITH NO LOG;
    
    strcpy(fcard_class, "2");
    aid1 = id1 = 0;
   
   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 ) {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   for(k=0;k<count_db;k++)
   {
     
     sprintf(stmt,
     "  SELECT count(*)        \
         FROM reject_policy    \
        WHERE ipolicy = ?      \
          AND fins_grp = '3'  ");
     $PREPARE rpid FROM $stmt;

     sprintf(stmt,
     "  SELECT count(*)        \
         FROM %s:appraisal     \
        WHERE ipolicy = ?      \
          AND fpart IN ('1','2','3') ",list[k].dbname);
     $PREPARE clmid FROM $stmt;

     sprintf(stmt,
     "  SELECT iquota         \
         FROM officer         \
        WHERE iofficer = ? ");
     $PREPARE ioffid FROM $stmt;
     
     if( fanother[0] == 'Y' )
     {
      sprintf(stroff,"AND ((a.iofficer[1] = '%s' AND a.iofficer[%d,%d] = '%s' \
                      AND length(a.iofficer) = %d) OR (a.iofficer[1] = '%s'   \
                      AND a.iofficer[%d,%d] = '%s' AND length(a.iofficer) = %d)) "
                      ,iofficer_ch1, ioff_ck_bgn, ioff_ck_end, ioff_chk, iofficer_len,
                      iofficera_ch1, ioff_chk_bgna, ioff_ch_enda, ioff_chka, lofficera );
     }
     else
     {
      sprintf(stroff,"AND a.iofficer[1] = '%s' AND a.iofficer[%d,%d] = '%s' \
                      AND length(a.iofficer) = %d ",iofficer_ch1, ioff_ck_bgn, 
                      ioff_ck_end, ioff_chk, iofficer_len );
                      
      sprintf(stroffb,"AND iofficer[1] = '%s' AND iofficer[%d,%d] = '%s' \
                      AND length(iofficer) = %d ",iofficer_ch1, ioff_ck_bgn, 
                      ioff_ck_end, ioff_chk, iofficer_len );
     }
     
     /* �]�����g��N���ഫ���D(W -->H-->N), �g��N�����P�_��Ū ca_promote_officer ��
        modify by sylvia 103.09.18 (1030630002_C1) */
     sprintf(stroffc," AND a.iofficer in (select unique iofficer_ori from ca_promote_officer \
                       where iprmt = '%s') ",pro_no);
        
     
     iequip_flag = (iremark - 1) % 30 + 1;
     strcpy(iequip_tmp,itoa(iremark));
     strcpy(sequip_str,equip_instr(iequip_tmp));

     /* ��B��i��O���,B�椣�άݵ��O */
     /* ��M�׸g�쪺�P�_����  (stroff--> stroffc) */
     sprintf(stmt,"SELECT a.ipolicy,b.dissue,a.iofficer,a.iresource,a.inext_ply,a.mdmg_prem+a.mlia_prem,\
                          a.dply_end,a.dply_begin,a.dpolicy,a.ibig_sales,a.ibig_office,a.ibranch_in, \
                          iengine, nassured[1,12], itag, iassured, (a.dply_end - a.dply_begin) \
                     FROM %s:ply_relation a, %s:policy b \
                    WHERE a.fcard_class = ?  AND a.dpolicy <= ?  \
                      AND a.dply_end >= ?    AND a.dply_end <= ? \
                      AND a.fedr_class <> '1'  AND a.ipolicy = b.ipolicy %s "
                   ,list[k].dbname, list[k].dbname, stroffc);
     
/*printf("car316_accumulate:[%s]\n",stmt);*/
printf("-525--stm=[%s]\n",stmt);
     $PREPARE pol_cur1 FROM $stmt;
     $DECLARE pol_cur CURSOR FOR pol_cur1;
     $OPEN pol_cur USING $fcard_class, $dopen_end, $dbgn_inf, $dend_inf;
     while(1)
     {
       strcpy(iengine," ");
       strcpy(iengine_t," ");
       strcpy(nassured," ");
       ori_tag[0]='\0';
       ori_iassured[0]='\0';

       $FETCH pol_cur INTO $ipolicy, $dissue,
                           $iofficer, $iresource, $inext_ply, $prem,
                           $ori_dply_end,
                           $ori_dply_begin,$ori_dpolicy,$ori_ibigsales,
                           $ori_ibigoffice,$ibranch_in,
                           $iengine, $nassured, $ori_tag, $ori_iassured, $dperiod;
       if(SQLCODE == SQLNOTFOUND) break;
       
       rstrdate( ori_dply_begin  ,&l_dply_begin );
       
       /** B�泡�� **/
       /** �ګO��� **/
       
       $EXECUTE rpid
           INTO $ricnt
          USING $ipolicy;
       if (ricnt > 0) 
       {
          if (strlen(trim(inext_ply)) != 0)
          {
             strcpy(tmp_fulldb,get_car_full_db(inext_ply));
             sprintf(stmt,
             " SELECT count(*)          \
                 FROM %s:ply_relation   \
                WHERE ipolicy = ?       \
                  AND dpolicy <= ?      \
                  AND fedr_class != '1' \
                  AND dply_close IS NOT NULL ",tmp_fulldb);
             $PREPARE rpne FROM $stmt;
             $EXECUTE rpne 
                 INTO $ricnt
             USING $inext_ply,$dclose_end;
             if (ricnt == 0) 
             {
                /*printf("ipolicy[%s],inext_ply[%s] continue \n",ipolicy,inext_ply);*/
                continue;
             }
          }
          else
          {
                /*printf("ipolicy[%s],inext_ply[%s] continue \n",ipolicy,inext_ply);*/
                continue;
          }
       }
       strcpy( inext_ply, trim(inext_ply));

       /** ���l�� **/
       if( strlen(inext_ply) == 0 )
       {
       	   $EXECUTE clmid INTO $clmcnt USING $ipolicy;
           if (clmcnt > 0) continue;
       }

       con_cnt = mark = 0;

       sprintf(stmt2," SELECT iins_type, fedr_status, nvl(dendorse,' '), mdamage_cover \
                         FROM %s:ply_ins_type \
                        WHERE ipolicy = ?", list[k].dbname);
       $PREPARE ins_cur1 FROM $stmt2;
       $DECLARE ins_cur CURSOR FOR ins_cur1;
       $OPEN ins_cur USING $ipolicy;
       while(1)
       {
          $FETCH ins_cur INTO $ins_type, $fedr_class, $dendorse, $mdamage_cover;

          if(SQLCODE == SQLNOTFOUND) break;

          mark_edr = 0;

          /* �I�جO�_���Ĩ̫O�I���B�ӧP�_ */
          if (mdamage_cover > 0)
          {
              mark = 1;
              break;
          }

          /* �ҥ~�G33�I�سQ�O�I�H���h�ɡAfedr_class����'1','2','3'���O�I���B��0 */
          if ((fedr_class[0] != '1' && fedr_class[0] != '2' && fedr_class[0] != '3') && (mdamage_cover > 0))
          {
             mark = 1;
             break;
          }
          else
          {
             if (dendorse != " ")
             {
                 sprintf(stmt3,"select iedr_type \
                                  from %s:edr_relation a,%s:edr_ins_type b \
                                 where a.ipolicy = ? \
                                   and a.dendorse <= ? \
                                   and a.iendorse = b.iendorse ",
                         list[k].dbname,list[k].dbname);
                 $prepare pre_edr from $stmt3;
                 $declare cur_edr cursor for pre_edr;
                 $open cur_edr using $ipolicy, $dopen_end;
                 while(1)
                 {
                     $fetch cur_edr into $iedr_type;
                     if (SQLCODE==SQLNOTFOUND) break;
                     if (strncmp(iedr_type,"01",2)==0 ||
                         strncmp(iedr_type,"02",2)==0 ||
                         strncmp(iedr_type,"03",2)==0)
                     {
                          mark_edr = 1;
                     }

                     if (strncmp(iedr_type,"50",2)==0)
                     {
                          mark_edr = 0;
                     }
                }

                if (mark_edr==0)
                {
                     mark = 1;
                     break;
                }
             }
          }
       }
       $CLOSE ins_cur;
       $FREE  ins_cur;

       if(mark == 0)
       {
            /****    This policy is cancelled    ****/
            /*printf("  mark == 0 ���� \n");*/
            continue;
       }
       else
       {
            mark = 0;
       }
       
       
       if(inext_ply[0] == '\0' || inext_ply[0] == ' ')
       {
          /****    This policy is not continue ����O   ****/
          printf(" �S����O  ................... \n");
          strcpy(iofficer_s, ori_ibigoffice);
          strcpy(iofficer_1, ori_ibigoffice);
          strcpy(iofficer_2, " ");
          strcpy(iofficer_w, iofficer);
          strcpy(iofficer_w_t, " ");
          strcpy(new_ibigsales," ");
          strcpy(new_ibigoffice," ");
          strcpy(ibranch_in_t, " ");
          strcpy(ibranch_in_old, ibranch_in);
          strcpy(iengine_t," ");
          strcpy(new_tag," ");
          strcpy(new_dply_begin," ");
          strcpy(new_dply_end," " );
          strcpy(nassured_t," ");
          con_cnt = 0;
          prem = 0;
          pdiscount = 0;
          
          $EXECUTE ioffid 
              INTO $iquota
             USING $iofficer;
          if (SQLCODE == SQLNOTFOUND){
              printf("Can't find iofficer's[%s] iquota\n",iofficer);
              goto errexit; 
          }
          
          strcpy(iquota_s, iquota);
          strcpy(iquota_1, iquota);
          strcpy(iquota_2, " ");
       }
       else
       {
          /****    This policy is insured  again �w��O   ****/
          printf(" $$$$$$$$$$$$ ����O  \n");
          strcpy(tmp_fulldb,get_car_full_db(inext_ply));

          sprintf(stmt," SELECT iquota              \
                           FROM %s:ori_ply_relation \
                          WHERE ipolicy = ? ",tmp_fulldb);
          $PREPARE ori_id FROM $stmt;
          strcpy(iengine_t," ");
          /* �ק�M�ץ�N�g�쪺�P�_���� (stroffb --> stroffc) modify by sylvia 103.09.18(1030630002_C1) */
          sprintf(stmt1, "SELECT a.iofficer, a.iresource, a.mdmg_prem+a.mlia_prem, b.dissue,\
                                 a.ilast_ply, a.dply_begin, a.dply_end, a.dpolicy, \
                                 a.ibig_sales, a.ibig_office, a.ibranch_in \
                            FROM %s:ply_relation a, %s:policy b \
                           WHERE a.ipolicy = b.ipolicy AND a.ipolicy = ?        \
                             AND a.dpolicy <= ?       \
                             AND a.fedr_class != '1'  \
                             AND a.dply_close IS NOT NULL %s", 
                tmp_fulldb, tmp_fulldb, stroffc  );

          $PREPARE new_pol_1 FROM $stmt1;
          $DECLARE new_pol CURSOR FOR new_pol_1;
          $OPEN new_pol USING $inext_ply, $dclose_end;
          $FETCH new_pol INTO $iofficer_t,
                              $iresource_t,  $prem_t, $dissue_t,
                              $LHsIlast_ply, $new_dply_begin, 
                              $new_dply_end,
                              $new_dpolicy,  $new_ibigsales, $new_ibigoffice,
                              $ibranch_in_t;

          if (SQLCODE == SQLNOTFOUND)
          { 
            
             /****    This policy is not continue    ****/
             strcpy(iofficer_s, ori_ibigoffice);
             strcpy(iofficer_1, ori_ibigoffice);
             strcpy(iofficer_2, " ");
             strcpy(iofficer_w, iofficer);
             strcpy(iofficer_w_t, " ");             
             strcpy(new_ibigsales," ");
             strcpy(new_ibigoffice," ");
             strcpy(ibranch_in_t, " ");
             strcpy(ibranch_in_old, ibranch_in);
             strcpy(new_tag," ");
             strcpy(new_dply_begin," ");
             strcpy(new_dply_end," " );
             strcpy(nassured_t," ");
             con_cnt = 0;
             prem = 0;
             pdiscount=0;

             $EXECUTE ioffid 
                 INTO $iquota
                USING $iofficer;
             if (SQLCODE == SQLNOTFOUND){
                  printf("Can't find iofficer's[%s] iquota\n",iofficer);
                  goto errexit; 
             }
             
             strcpy(iquota_s, iquota);
             strcpy(iquota_1, iquota);
             strcpy(iquota_2, " ");
             strcpy(inext_ply," ");
         }
         else
         {
            
             sprintf(stmt,
             " SELECT iengine, nassured[1,12], itag \
                FROM %s:policy                 \
               WHERE ipolicy = ? ", tmp_fulldb);
             $PREPARE polid1 FROM $stmt;
             $EXECUTE polid1 INTO $iengine_t, $nassured_t, $new_tag
                USING $inext_ply;
             if (SQLCODE == SQLNOTFOUND)
             {
                 strcpy(iengine_t," ");
                 strcpy(nassured_t," ");
                 strcpy(new_tag," ");
             }
             
             sprintf(stmt,
             "SELECT pdiscount FROM %s:ply_ins_type \
               WHERE ipolicy = ? AND iins_type ='11'", tmp_fulldb);
             $PREPARE getdisc FROM $stmt;
             $EXECUTE getdisc INTO $pdiscount USING $inext_ply;
             if(SQLCODE == SQLNOTFOUND) 
                pdiscount = 0;
             
             strcpy(dissue, trim(dissue));
             strcpy(dissue_t, trim(dissue_t));

             if(strcmp(dissue, dissue_t)!=0)
                strcpy(dissue, dissue_t);

             prem = prem_t;
             con_cnt = 1;
             LiFlag = 0;

             strcpy(iofficer_s,new_ibigoffice);
             strcpy(iofficer_1,ori_ibigoffice);
             strcpy(iofficer_2,new_ibigoffice);
             
             $EXECUTE ioffid
                 INTO $iquota_1
                USING $iofficer;
             if (SQLCODE == SQLNOTFOUND){
                 printf("Can't find iofficer's[%s] iquota\n",iofficer);
                 goto errexit;
             }
             
             $EXECUTE ori_id
                 INTO $iquota_2
                USING $inext_ply;
             if (SQLCODE == SQLNOTFOUND){
                 printf("Can't not find ipolicy's[%s] iquota on ori_ply_relation\n",inext_ply);
                 goto errexit;
             }
             
             strcpy(iquota_s, iquota_2);
             strcpy(iofficer_w, iofficer );
             strcpy(iofficer_w_t, iofficer_t);
             strcpy(ibranch_in_old, ibranch_in);
             strcpy(ibranch_in, ibranch_in_t);
         }

         
         $CLOSE new_pol;
         $FREE  new_pol;
         
      }
      
      /**  
         no_add_316A = 1 ���ܵLA�檺�i��O��ƻP��O���
         with_last = 1   ���ܦ�����
         with_next = 1   ���ܦ����l�A�����l�����Ҭ�0�ɡAno_add_316A = 1 (�LA����) **/

      with_last = with_next = 1;
      no_add_316A = 0;
      Arenew_cnt = Acon_cnt = Aprem_t = Apdiscount = 0;
      /** �i��OB��w�ˮ֧����A���U���ˮ֥i��OA���� **/
      /** 1.1 ����XA�檺�i��O��� **/
      /* ���bB���Ʈw��,�䤣��A���L��Ʈw�� */
      sprintf(stmt,"SELECT a.ipolicy,a.iofficer,a.inext_ply,a.dply_end,\
                           a.dply_begin,a.dpolicy,a.ibranch_in, \
                           iengine, nassured[1,12], itag \
                      FROM %s:ply_relation a, %s:policy b \
                     WHERE a.fcard_class = '2' AND a.dpolicy <= ?  \
                       AND a.fedr_class <> '1' AND a.ipolicy = b.ipolicy \
                       AND b.iengine = ?       AND a.iofficer[1] = 'A' \
                       AND a.dply_begin >= %d   AND a.dply_begin <= %d \
                       AND b.nequipment[%d] in %s "
                   ,list[k].dbname, list[k].dbname, l_dply_begin-30, l_dply_begin+30,
                   iequip_flag, sequip_str );
      #ifdef PRINTF_FLAG
        printf("--> 874 stmt[%s] iengine=[%s] dopen_end[%s] \n", stmt, iengine, dopen_end );
      #endif
      
      $PREPARE g_Adata FROM $stmt;
      $DECLARE get_a1  CURSOR for g_Adata;
      $OPEN  get_a1 using  $dopen_end, $iengine;
      $FETCH get_a1 INTO $Aipolicy, $Aiofficer, $Ainext_ply,
                         $ori_Adply_end,
                         $ori_Adply_begin, $ori_Adpolicy, $Aibranch_in,
                         $Aiengine, $Anassured, $Aori_tag;
                           
      if(SQLCODE == SQLNOTFOUND)
      {
         for(j=0;j<count_db;j++) {
            if (j==k) continue;
            else {
            sprintf(stmt,"SELECT a.ipolicy,a.iofficer,a.inext_ply,a.dply_end,\
                           a.dply_begin,a.dpolicy,a.ibranch_in, \
                           iengine, nassured[1,12], itag \
                      FROM %s:ply_relation a, %s:policy b \
                     WHERE a.fcard_class = '2' AND a.dpolicy <= ?  \
                       AND a.fedr_class <> '1' AND a.ipolicy = b.ipolicy \
                       AND b.iengine = ?       AND a.iofficer[1] = 'A' \
                       AND a.dply_begin >= %d   AND a.dply_begin <= %d \
                       AND b.nequipment[%d] in %s "
                   ,list[j].dbname, list[j].dbname, l_dply_begin-30, l_dply_begin+30,
                   iequip_flag, sequip_str );
      
            $PREPARE g_Adata1 FROM $stmt;
            $DECLARE get_a11  CURSOR for g_Adata1;
            $OPEN  get_a11 using  $dopen_end, $iengine;
            $FETCH get_a11 INTO $Aipolicy, $Aiofficer, $Ainext_ply,
                         $ori_Adply_end,
                         $ori_Adply_begin, $ori_Adpolicy, $Aibranch_in,
                         $Aiengine, $Anassured, $Aori_tag;
            if (SQLCODE != SQLNOTFOUND)
               break;
            }
         }
      }
      else
         j=k;

      if(SQLCODE == SQLNOTFOUND)
      {
      	  /** �LA��i��O��� **/
      	  /** �N��L�i��O��ơA�٬O�i�঳���l����O��ơA�]�����q�u���ˮ֥i��O��ƪ��ܼ� **/
      	  
      	  /** �M�ťi��OA�檺��� **/
      	  #ifdef PRINTF_FLAG
      	     printf("ipolicy A1 not found\n");
      	  #endif
      	  strcpy(Aipolicy   ," ");
      	  strcpy(Aiofficer  ," ");
      	  strcpy(Ainext_ply ," ");
      	  strcpy(ori_Adply_end ," ");
      	  strcpy(ori_Adply_begin ," ");
      	  strcpy(ori_Adpolicy ," ");
      	  strcpy(Aibranch_in ," ");
      	  strcpy(Aiengine ," ");
      	  strcpy(Anassured ," ");
      	  strcpy(Aori_tag ," ");
      	  Arenew_cnt = 0;
      	  with_last = 0;
      }
      else
      {
      	  #ifdef PRINTF_FLAG
      	     printf("ipolicy A1 found Aipolicy=[%s]\n", Aipolicy );
      	  #endif
      	  
      	  /** ��A���� **/
      	  Arenew_cnt = 1;
      	  /** 1.2 **/
      	  $EXECUTE rpid
              INTO $ricnt
             USING $Aipolicy;
          if (ricnt > 0) 
          {
             if (strlen(trim(Ainext_ply)) != 0)
             {
                 strcpy(tmp_fulldb,get_car_full_db(Ainext_ply));
                 sprintf(stmt,
                 " SELECT count(*)          \
                     FROM %s:ply_relation   \
                    WHERE ipolicy = ?       \
                      AND dpolicy <= ?      \
                      AND fedr_class != '1' \
                      AND dply_close IS NOT NULL ",tmp_fulldb);
                 $PREPARE rpne FROM $stmt;
                 $EXECUTE rpne 
                     INTO $ricnt
                 USING $Ainext_ply,$dclose_end;
                 if (ricnt == 0) 
                 {
                    /*printf("Aipolicy[%s],Ainext_ply[%s] continue \n",Aipolicy,Ainext_ply);*/
                    continue;
                 }
             }
             else
             {
                 /*printf("Aipolicy[%s],Ainext_ply[%s] continue \n",Aipolicy,Ainext_ply);*/
                 continue;
             }
          }
       
          
          /** ���l�� **/
          $EXECUTE clmid INTO $clmcnt USING $Aipolicy;
          if (clmcnt > 0) continue;
          
          /* Modified by Julia - �Y�L��O�渹�B�O������273�ѫh���C�J��O�έp */
      	  if((Ainext_ply[0] == '\0' || Ainext_ply[0] == ' ') && dperiod < 273) 
      	     {  printf("dperiod and Ainext_ply[%ld][%s]\n",dperiod,Ainext_ply); continue; }

          Acon_cnt = mark = 0;

          sprintf(stmt2," SELECT iins_type, fedr_status, nvl(dendorse,' '), mdamage_cover \
                            FROM %s:ply_ins_type \
                           WHERE ipolicy = ?", list[j].dbname);
          $PREPARE ins_cur2 FROM $stmt2;
          $DECLARE ins_curA CURSOR FOR ins_cur2;
          $OPEN ins_curA USING $Aipolicy;
          while(1)
          {
             $FETCH ins_curA INTO $Ains_type, $Afedr_class, $Adendorse, $Amdamage_cover;

             if(SQLCODE == SQLNOTFOUND) break;

             mark_edr = 0;

             /* �I�جO�_���Ĩ̫O�I���B�ӧP�_ */
             if (Amdamage_cover > 0)
             {
                 mark = 1;
                 break;
             }

             /* �ҥ~�G33�I�سQ�O�I�H���h�ɡAfedr_class����'1','2','3'���O�I���B��0 */
             if ((Afedr_class[0] != '1' && Afedr_class[0] != '2' && Afedr_class[0] != '3') && (Amdamage_cover > 0))
             {
                mark = 1;
                break;
             }
             else
             {
                if (Adendorse != " ")
                {
                    sprintf(stmt3,"select iedr_type \
                                     from %s:edr_relation a,%s:edr_ins_type b \
                                    where a.ipolicy = ? \
                                      and a.dendorse <= ? \
                                      and a.iendorse = b.iendorse ",
                            list[j].dbname,list[j].dbname);
                    $prepare pre_edr1 from $stmt3;
                    $declare cur_edr1 cursor for pre_edr1;
                    $open cur_edr1 using $Aipolicy, $dopen_end;
                    while(1)
                    {
                        $fetch cur_edr1 into $iedr_type;
                        if (SQLCODE==SQLNOTFOUND) break;
                        if (strncmp(iedr_type,"01",2)==0 ||
                            strncmp(iedr_type,"02",2)==0 ||
                            strncmp(iedr_type,"03",2)==0)
                        {
                             mark_edr = 1;
                        }
 
                        if (strncmp(iedr_type,"50",2)==0)
                        {
                              mark_edr = 0;
                        }
                    }

                   if (mark_edr==0)
                   {
                        mark = 1;
                        break;
                   }
                }
             }
          }
          $CLOSE ins_curA;
          $FREE  ins_curA;
          
          /*printf("mark[%d]\n",mark);
          printf("Ainext_ply[%s]\n",Ainext_ply);*/
          if(mark == 0)
          {
              /****    This policy is cancelled    ****/
              mark = 0;
              /** �����LA��i��O��� **/
      	      /** �N��L�i��O��ơA�٬O�i�঳���l����O��ơA�]�����q�u���ˮ֥i��O��ƪ��ܼ� **/
      	  
      	      /** �M�ťi��OA�檺��� **/
      	      strcpy(Aipolicy   ," ");
      	      strcpy(Aiofficer  ," ");
      	      strcpy(Ainext_ply ," ");
      	      strcpy(ori_Adply_end ," ");
      	      strcpy(ori_Adply_begin ," ");
      	      strcpy(ori_Adpolicy ," ");
      	      strcpy(Aibranch_in ," ");
      	      strcpy(Aiengine ," ");
      	      strcpy(Anassured ," ");
      	      strcpy(Aori_tag ," ");
      	      Arenew_cnt = 0;
      	      with_last = 0;
          }
          else
          {
               mark = 0;
          }	
          
      }
      
      if( (inext_ply[0] == '\0' || inext_ply[0] == ' ') && (with_last == 0 ))
      {
      	  /** B��L��O�A�LA��,�h���LA2��ơC�BA��L�i��O��A **/
      	  no_add_316A = 1;
      }
      else
      {
          if ( (Ainext_ply[0] != '\0') && (Ainext_ply[0] != ' '))
          {
               /** A��w��O�A��A2�O����A2��� **/
               strcpy(tmp_fulldb,get_car_full_db(Ainext_ply));
               sprintf(stmt,"SELECT dply_end FROM %s:ply_relation \
                              WHERE ipolicy = '%s'",
                       tmp_fulldb, Ainext_ply);
               $PREPARE get_dply_a2 FROM $stmt;
               $EXECUTE get_dply_a2 INTO $dply_end_A2;
               
               rstrdate(dply_end_A2, &lnew_dply_end );
               sprintf(stmt_next,"AND a.ipolicy = '%s' ",Ainext_ply);
          }
          else if( (inext_ply[0] != '\0') && (inext_ply[0] != ' '))
          {
               /** B2�w��O�A��B2�O����A2��� **/
               strcpy(tmp_fulldb,get_car_full_db(inext_ply));
               strcpy(dply_end_A2, new_dply_end);
               rstrdate(dply_end_A2, &lnew_dply_end );
               strcpy(stmt_next," ");
          }
          else
          {
               /** B2�BA2����O�A��B1�O����A2��� **/
               strcpy(tmp_fulldb,get_car_full_db(ipolicy));
               strcpy(  dply_end_A2,ori_dply_end);
               rstrdate(dply_end_A2, &lnew_dply_end );
               lnew_dply_end = lnew_dply_end + 365;
               strcpy(stmt_next," ");
          }
          
          lnew_tmp1 = lnew_dply_end-30;
          lnew_tmp2 = lnew_dply_end+30;
      	  
          stmt_assured[0] = '\0';
          if(strlen(trim(ori_iassured)) > 0 )
      	      sprintf(stmt_assured,"AND b.iassured = '%s'",ori_iassured);
      	  
      	  #ifdef PRINTF_FLAG   
      	      printf("line 1087 stmt_assured=[%s] new_dply_end=[%s], lnew_tmp1=[%d] lnew_tmp2=[%d]",
      	              stmt_assured, new_dply_end, lnew_tmp1, lnew_tmp2 );
      	  #endif
          
          /** �H�U�P�_�O�_��A2����ơA�Q�Τ������X�[�O�����ơA��U�Ӹ�Ʈw�h�� **/
          /* ���b��O��Ʈw�� */ 
          sprintf(stmt,"SELECT a.ipolicy,a.iofficer,a.dply_end,a.dply_begin,\
      	                          a.dpolicy,a.ibranch_in, mdmg_prem+mlia_prem,\
                                  iengine, nassured[1,12], itag \
                          FROM %s:ply_relation a, %s:policy b \
                         WHERE a.fcard_class = '2' AND a.dpolicy <= ?  \
                           AND a.dply_end >= ?     AND a.dply_end <= ? \
                           AND a.fedr_class != '1' AND dply_close IS NOT NULL \
                           AND a.ipolicy = b.ipolicy AND b.iengine = ? \
                           AND a.iofficer matches '%s*' \
                           AND b.nequipment[%d] in %s %s %s",
                   tmp_fulldb, tmp_fulldb, trim(iagent), iequip_flag,
                   sequip_str, stmt_assured, stmt_next );
      	  #ifdef PRINTF_FLAG   
      	      printf("line 1087 find ipolicy A2 stmt=[%s]\n", stmt );
      	  #endif
      	  
      	  $PREPARE g_a2_d FROM $stmt;
      	  $DECLARE g_a2_x CURSOR for g_a2_d;
      	  $OPEN    g_a2_x USING $dclose_end, $lnew_tmp1, $lnew_tmp2, $iengine_t;
      	  $FETCH   g_a2_x INTO $Ainext_ply, $Aiofficer_t, $new_Adply_begin,
                   $new_Adply_end,
      	           $new_Adpolicy, $Aibranch_in_t, $Aprem_t,
                   $Aiengine_t, $Anassured_t, $Anew_tag;
      	  if(SQLCODE == SQLNOTFOUND)
      	  {
             for(m=0;m<count_db;m++) {
             sprintf(stmt,"SELECT a.ipolicy,a.iofficer,a.dply_end,a.dply_begin,\
      	                          a.dpolicy,a.ibranch_in, mdmg_prem+mlia_prem,\
                                  iengine, nassured[1,12], itag \
                          FROM %s:ply_relation a, %s:policy b \
                         WHERE a.fcard_class = '2' AND a.dpolicy <= ?  \
                           AND a.dply_end >= ?     AND a.dply_end <= ? \
                           AND a.fedr_class != '1' AND dply_close IS NOT NULL \
                           AND a.ipolicy = b.ipolicy AND b.iengine = ? \
                           AND a.iofficer matches '%s*' \
                           AND b.nequipment[%d] in %s %s",
                   list[m].dbname, list[m].dbname, trim(iagent), iequip_flag,
                   sequip_str, stmt_assured);
      	     $PREPARE g_a2_d1 FROM $stmt;
             $DECLARE g_a2_x1 CURSOR for g_a2_d1;
             $OPEN    g_a2_x1 USING $dclose_end, $lnew_tmp1, $lnew_tmp2,
                                    $iengine_t;
             $FETCH   g_a2_x1 INTO $Ainext_ply, $Aiofficer_t, $new_Adply_begin,
                                   $new_Adply_end, $new_Adpolicy,
                                   $Aibranch_in_t, $Aprem_t,
                                   $Aiengine_t, $Anassured_t, $Anew_tag;
             if (SQLCODE!=SQLNOTFOUND) {
                strcpy(tmp_fulldb,list[m].dbname);
                break;
             }
             }
          }


      	  if(SQLCODE == SQLNOTFOUND)
      	  {
      	      /** �䤣��A2��� **/
      	      with_next = 0;
      	  }
      	  else
      	  {
      	      /** �ˮ�A��O�_�ŦX���� **/
      	      rc = chk_AB_policy( Ainext_ply, ipolicy );
      	      if( rc != M_CM_OK )
              {
                  /** �ˮ֥��ѡA�LA2��� **/
      	          with_next = 0;
              }
              else
              {
                  with_next = 1;

                  Acon_cnt = 1;
             
                  strcpy(Aiofficer_s,Aiofficer_t);
                  strcpy(Aiofficer_1,Aiofficer);
                  strcpy(Aiofficer_2,Aiofficer_t);
                  
                  $EXECUTE ioffid
                      INTO $Aiquota_1
                     USING $iofficer;
                  if (SQLCODE == SQLNOTFOUND){
                      printf("Can't find iofficer's[%s] iquota\n",iofficer);
                      goto errexit;
                  }

                  sprintf(stmt1," SELECT iquota     \
                           FROM %s:ori_ply_relation \
                          WHERE ipolicy = ? ",tmp_fulldb);
                  $PREPARE ori_id1 FROM $stmt1;
                  
                  $EXECUTE ori_id1
                      INTO $Aiquota_2
                     USING $Ainext_ply;
                  if (SQLCODE == SQLNOTFOUND){
                      printf("Can't not find ipolicy's[%s][%s] iquota on ori_ply_relation\n",tmp_fulldb,Ainext_ply);
                      goto errexit;
                  }
                  
                  strcpy(Aiquota_s, Aiquota_2);
                  strcpy(Aibranch_old, Aibranch_in);
                  strcpy(Aibranch_t,   Aibranch_in_t);
                  strcpy(Aibranch,     Aibranch_in_t);
                  
              }  /** end chk_AB_policy() **/
      	  }     /** end get Aw      **/
      	  $CLOSE g_a2_x;
      	     
     }    /** end no_add_316A **/
     
     #ifdef PRINTF_FLAG
        printf("with_next = [%d] with_last = [%d]\n", with_next, with_last );
     #endif
     
     if((with_next == 0) && (with_last != 0) )	/** ��A1 �LA2 **/
     {
         strcpy(Aiofficer_s, Aiofficer);
         strcpy(Aiofficer_1, Aiofficer);
         strcpy(Aiofficer_2, " ");
         strcpy(Aibranch_t, " ");
         strcpy(Aibranch,     Aibranch_in);
         strcpy(Aibranch_old, Aibranch_in);
         strcpy(Aiengine_t," ");
         strcpy(Anew_tag," ");
         strcpy(new_Adply_begin," ");
         strcpy(new_Adply_end," " );
         strcpy(Anassured_t," ");
         Acon_cnt = 0;
         Aprem_t = 0;
         Apdiscount = 0;
          
         $EXECUTE ioffid 
             INTO $Aiquota
            USING $Aiofficer;
         if (SQLCODE == SQLNOTFOUND){
             printf("Can't find iofficer's[%s] iquota\n",Aiofficer);
             goto errexit;
         }
           
         strcpy(Aiquota_s, Aiquota);
         strcpy(Aiquota_1, Aiquota);
         strcpy(Aiquota_2, " ");
     }
     else if((with_next != 0) && (with_last != 0) )	/** ��A1 ��A2 **/
     {
     	 strcpy(Aiofficer_s,Aiofficer_t);
         strcpy(Aiofficer_1,Aiofficer);
         strcpy(Aiofficer_2,Aiofficer_t);
             
         $EXECUTE ioffid
             INTO $Aiquota_1
            USING $iofficer;
         if (SQLCODE == SQLNOTFOUND){
             printf("Can't find iofficer's[%s] iquota\n",iofficer);
             goto errexit;
         }
             
         sprintf(stmt1," SELECT iquota     \
                  FROM %s:ori_ply_relation \
                 WHERE ipolicy = ? ",tmp_fulldb);
         $PREPARE ori_id2 FROM $stmt1;
                  
         $EXECUTE ori_id2
             INTO $Aiquota_2
            USING $Ainext_ply;
         if (SQLCODE == SQLNOTFOUND){
             printf("Can't not find ipolicy's[%s] iquota on ori_ply_relation\n",Ainext_ply);
             goto errexit;
         }
             
         strcpy(Aiquota_s, Aiquota_2);
         strcpy(Aibranch_old, Aibranch_in);
         strcpy(Aibranch_t,   Aibranch_in_t);
         strcpy(Aibranch,     Aibranch_in_t);
     }
     else if((with_next != 0) && (with_last != 0) )	/** �L A1 ��A2 **/
     {
     	 strcpy(Aiofficer_s,Aiofficer_t);
         strcpy(Aiofficer_1," ");
         strcpy(Aiofficer_2,Aiofficer_t);
             
         $EXECUTE ori_id
            INTO $Aiquota_2
           USING $Ainext_ply;
         if (SQLCODE == SQLNOTFOUND){
             printf("Can't not find ipolicy's[%s] iquota on ori_ply_relation\n",Ainext_ply);
             goto errexit;
         }
             
         strcpy(Aiquota_1, " ");
         strcpy(Aiquota_s, Aiquota_2);
         strcpy(Aibranch_old, " ");
         strcpy(Aibranch_t,   Aibranch_in_t);
         strcpy(Aibranch,     Aibranch_in_t);
     }
     
     if( (with_last == 0) && (with_next == 0))
         no_add_316A=1;
     
     
     #ifdef PRINTF_FLAG
        printf("with_last=[%d] with_next=[%d] no_add_316A=[%d]\n",
                with_last, with_next, no_add_316A );
     #endif
      
     if( no_add_316A == 0 )
     {
          /*printf("Arenew_cnt[%d] Acon_cnt[%d] Aprem_t[%f] Adiscount[%f] \n",
                  Arenew_cnt,  Acon_cnt,  Aprem_t , Apdiscount );*/
       	  /** �gA���� **/
          $INSERT INTO CAR316A
           ( ibranch,ibranch_t,ibranch_old,iofficer,iquota,iofficer_t,
             iquota_t,iofficer_old,
             iquota_old,ipolicy,inext_ply,iengine_t,iengine_old,renew_cnt,con_cnt,prem,pdiscount,
             nassured_t,nassured_old,dply_begin_t,dply_end_t,dply_begin_old,dply_end_old,itag_t,
             itag_old )
          VALUES
           ( $Aibranch, $Aibranch_t, $Aibranch_old, $Aiofficer_s, $Aiquota_s, $Aiofficer_2, 
             $Aiquota_2, $Aiofficer_1, $Aiquota_1,  $Aipolicy,  $Ainext_ply,  $Aiengine_t, $Aiengine, 
             $Arenew_cnt, $Acon_cnt, $Aprem_t, $Apdiscount, $Anassured_t, $Anassured, $new_Adply_begin, 
             $new_Adply_end, $ori_Adply_begin, $ori_Adply_end, $Anew_tag, $Aori_tag );

          if(SQLCODE == 0)
          {
             aid1 = aid1 + 1;
          }
          else
            printf("Insert error Aipolicy[%s] Aiquota[%s] Aiofficer[%s]\n",Aipolicy,Aiquota,Aiofficer);
          
          if( (strlen(trim(Ainext_ply)) == 0) && (strlen(trim(inext_ply)) == 0) )
          {
              /** AB��ҥ���O�ɡAA��iofficer�PB��ibig_office���P�ɡA�HA�欰�� **/
              strcpy(ibranch_in,    Aibranch);
              strcpy(ibranch_in_old, Aibranch_old);
              strcpy(iofficer_s, Aiofficer_s);
              strcpy(iofficer_1, Aiofficer_1);
              strcpy(iquota_s,   Aiquota_s);
              strcpy(iquota_1,   Aiquota_1);
          }
     }
      
      if( Acon_cnt == 1 && con_cnt == 0 )
      {
      	  /** B�楼��O�AA��w��O�AB�� �H A���쬰�D **/
          strcpy(ibranch_in,    Aibranch);
          strcpy(ibranch_in_old, Aibranch_old);
          strcpy(iofficer_s, Aiofficer_s);
          strcpy(iofficer_1, Aiofficer_1);
          strcpy(iquota_s,   Aiquota_s);
          strcpy(iquota_1,   Aiquota_1);
      }
      
      /** �gB���� **/
      $INSERT INTO CAR316
          (ibranch, ibranch_t, ibranch_old, iofficer, iquota, iofficer_t, iquota_t, 
           iofficer_old, iquota_old, ipolicy, inext_ply, iengine, iengine_t, renew_cnt,  
           con_cnt, prem, pdiscount, nassured_t, nassured_old, ibig_sales_t, iofficer_w, 
           iofficer_w_t, dply_begin_t, dply_end_t, dply_begin_old, dply_end_old, itag_t, 
           itag_old )
       VALUES
          ($ibranch_in, $ibranch_in_t, $ibranch_in_old, $iofficer_s, $iquota_s, $iofficer_2, 
           $iquota_2, $iofficer_1, $iquota_1,  $ipolicy,  $inext_ply,  $iengine, $iengine_t, 
           1, $con_cnt, $prem, $pdiscount, $nassured_t, $nassured, $new_ibigsales, $iofficer_w, 
           $iofficer_w_t,  $new_dply_begin, $new_dply_end, $ori_dply_begin, $ori_dply_end,
           $new_tag, $ori_tag );

       if(SQLCODE == 0)
        {
         id1 = id1 + 1;
         /*printf("insert count[%d]\n",id1);*/
        }
       else
         printf("Insert error ipolicy[%s] iquota[%s] iofficer[%s]\n",ipolicy,iquota,iofficer);
       
       /** ���U�Ӱ�A�BB��X�֭p�⪺�ʧ@ **/
       if( con_cnt == 1 )
       {
       	  /** B��w��O�AA+B�H�s��쬰�D **/
          strcpy(ibranch_mge,  ibranch_in);
          strcpy(iquota_mge,   iquota_s);
          strcpy(iofficer_mge, iofficer_s);
          strcpy(iengine_mge,  iengine_t);
          renew_cnt_mge = 1;
          con_cnt_mge = 1;
          prem_mge = prem + Aprem_t;
       }
       else if( Acon_cnt == 1 && con_cnt == 0 )
       {
       	  /** B�楼��O�AA��w��O�AA+B�H A���쬰�D **/
          strcpy(ibranch_mge,  Aibranch);
          strcpy(iquota_mge,   Aiquota_s);
          strcpy(iofficer_mge, Aiofficer_s);
          strcpy(iengine_mge,  Aiengine_t);
          renew_cnt_mge = 1;
          con_cnt_mge = 1;
          prem_mge = Aprem_t;
       }
       else
       {
       	  /** AB�泣����O�AA+B�H B���쬰�D(���@��) **/
          strcpy(ibranch_mge,  ibranch_in);
          strcpy(iquota_mge,   iquota_s);
          strcpy(iofficer_mge, iofficer_s);
          strcpy(iengine_mge,  iengine_t);
          renew_cnt_mge = 1;
          con_cnt_mge = 0;
          prem_mge = 0;
       }
       
       $INSERT INTO CAR316_MGE
       ( ibranch, iofficer, iquota, iengine, renew_cnt, con_cnt, prem )
       VALUES
       ( $ibranch_mge, $iofficer_mge, $iquota_mge, $iengine_mge, $renew_cnt_mge,
         $con_cnt_mge, $prem_mge );
       if(SQLCODE == 0)
       {
          aidm = aidm + 1;
       }
       else
          printf("Insert error Aipolicy[%s] Aiquota[%s] Aiofficer[%s]\n",Aipolicy,Aiquota,Aiofficer);
      
     }   /*  End of pol_select cursor while  */
     $CLOSE pol_cur;
     $FREE  pol_cur;

   }

   printf("Accumulate successfully End!!!\n");
   return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

void car316_title()
{
      rgu_put_head();
}

long car316_body1()
{
 char  tmp_buf[16];
 int   rc,flag_first;
 $char iquota[7], itop[2], itop_t[2], idealer[4], idealer_t[4], iofficer[11];
 $char iofficer_t[11], ntop[10], ndealer[10], nname[21], nbranch[20];
 $char buf1[17], mcheck[2], iquota_t[7], iquota_n[7], ileader[10];
 $int  renew_cnt, con_cnt, renew_cnt1, con_cnt1, renew_cnt2, con_cnt2;
 $int  renew_cnt_a, con_cnt_a, renew_cnt_mge, con_cnt_mge; 
 $int  myear, id2;
 $long prem, prem1, prem2, prem_a, prem_mge, qord, qord1;
 $char off13[4];
 $char qorder[21], qqord[21];
 $char iofficer13[4], ibranch[4];

   $WHENEVER SQLERROR GOTO errexit;

   printf("Agent part Start!!!\n");
   flag_first=1;
   id2 = 0;
   max_cnt +=6;

   $CREATE TEMP TABLE AGENT
      (itop         char(2),
       idealer      char(3),
       iofficer     char(10),
       qorder       char(20),
       iquota       char(06),
       nofficer     char(10),
       ibranch      char(3),
       renew_cnt      integer default 0 not null,
       con_cnt        integer default 0 not null,
       prem           decimal(10,0) default 0 not null,
       renew_cnt_a    integer default 0 not null,
       con_cnt_a      integer default 0 not null,
       prem_a         decimal(10,0) default 0 not null,
       renew_cnt_mge  integer default 0 not null,
       con_cnt_mge    integer default 0 not null,
       prem_mge       decimal(10,0) default 0 not null
     )WITH NO LOG;


   $CREATE UNIQUE INDEX AG_ix1 ON AGENT (iofficer,iquota,ibranch);

   /** ��B��g���� **/
   $DECLARE agent_off CURSOR FOR
     SELECT UNIQUE b.iofficer, b.ibranch, b.iquota[1,4] || '00',
            nvl(a.nname,' '), nvl(a.imaker,' '), nvl(a.idealer,' ')
       INTO $iofficer, $ibranch, $iquota, $nname, $itop, $idealer
       FROM CAR316 b,outer officer a
      WHERE b.iofficer = a.iofficer
      ORDER BY 1;

   $OPEN agent_off;
   while(1)
    {
     $FETCH agent_off;
     if(SQLCODE == SQLNOTFOUND) break;

     $SELECT qorder
          INTO $qorder
          FROM v_channel
         WHERE icode = $iofficer;
     if (SQLCODE==SQLNOTFOUND) strcpy(qorder,"0");

     $INSERT INTO AGENT
        (itop, idealer, iofficer, iquota, nofficer, ibranch, 
         qorder, renew_cnt, con_cnt, prem )
      VALUES
        ($itop, $idealer, $iofficer, $iquota, $nname, $ibranch, 
         $qorder, 0, 0, 0);

     if(SQLCODE == 0)
      {
       id2 = id2 + 1;
      }
     else
       printf("Agent error insert itop[%s] idealer[%s] iofficer[%s]\n",itop,idealer,iofficer);
    }
   $CLOSE agent_off;
   $FREE  agent_off;

   /** ��A��g���� **/
   $DECLARE agent_offa CURSOR FOR
     SELECT UNIQUE b.iofficer, b.ibranch, b.iquota[1,4] || '00',
            nvl(a.nname,' '), nvl(a.imaker,' '), nvl(a.idealer,' ')
       INTO $iofficer, $ibranch, $iquota, $nname, $itop, $idealer
       FROM CAR316A b,officer a
      WHERE b.iofficer = a.iofficer
      ORDER BY 1;

   $OPEN agent_offa;
   while(1)
    {
     $FETCH agent_offa;
     if(SQLCODE == SQLNOTFOUND) break;

     $SELECT qorder INTO $qorder
        FROM v_channel
       WHERE icode = $iofficer;
     if (SQLCODE==SQLNOTFOUND) strcpy(qorder,"0");

     $SELECT iofficer,iquota FROM AGENT
       WHERE iofficer = $iofficer 
         AND iquota   = $iquota
         AND ibranch  = $ibranch;
     if(SQLCODE == SQLNOTFOUND)
     {
        $INSERT INTO AGENT
        (itop, idealer, iofficer, iquota, nofficer, ibranch, qorder,
         renew_cnt,     con_cnt,     prem, 
         renew_cnt_a,   con_cnt_a,   prem_a, 
         renew_cnt_mge, con_cnt_mge, prem_mge )
        VALUES
        ($itop, $idealer, $iofficer, $iquota, $nname, $ibranch, 
         $qorder, 0, 0, 0, 0, 0, 0, 0, 0, 0);
     
        if(SQLCODE == 0)
        {
           id2 = id2 + 1;
        }
        else
           printf("Agent error insert itop[%s] idealer[%s] iofficer[%s]\n",itop,idealer,iofficer);
     }
   }
   $CLOSE agent_offa;
   $FREE  agent_offa;

   /** UPDATE B�� Data **/
   $DECLARE agent CURSOR FOR
     SELECT iofficer, iquota[1,4] || '00', ibranch, sum(renew_cnt),
            sum(con_cnt), sum(prem)
       INTO $iofficer, $iquota, $ibranch, $renew_cnt, $con_cnt, $prem
       FROM CAR316
      GROUP BY 1,2,3;
   $OPEN agent;
   while(1)
   {
       $FETCH agent;
       if(SQLCODE == SQLNOTFOUND) break;
   
       $UPDATE AGENT
           SET renew_cnt = renew_cnt + $renew_cnt,
               con_cnt   = con_cnt   + $con_cnt,
               prem      = prem      + $prem
         WHERE iofficer  = $iofficer
           AND iquota    = $iquota
           AND ibranch   = $ibranch;
       
   }  /*  End of agent cursor while  */
   $CLOSE agent;
   $FREE  agent;

   /** UPDATE A�� Data **/
   $DECLARE agenta CURSOR FOR
     SELECT iofficer, iquota[1,4] || '00', ibranch, sum(renew_cnt),
            sum(con_cnt), sum(prem)
       INTO $iofficer, $iquota, $ibranch, $renew_cnt, $con_cnt, $prem
       FROM CAR316A
      GROUP BY 1,2,3;
   $OPEN agenta;
   while(1)
   {
       $FETCH agenta;
       if(SQLCODE == SQLNOTFOUND) break;
 
       $UPDATE AGENT
           SET renew_cnt_a = renew_cnt_a + $renew_cnt,
               con_cnt_a   = con_cnt_a   + $con_cnt,
               prem_a      = prem_a      + $prem
         WHERE iofficer  = $iofficer
           AND iquota    = $iquota
           AND ibranch   = $ibranch;
       
   }  /*  End of agent cursor while  */
   $CLOSE agenta;
   $FREE  agenta;

   /** UPDATE A�� Data **/
   $DECLARE agentmge CURSOR FOR
     SELECT iofficer, iquota[1,4] || '00', ibranch, sum(renew_cnt),
            sum(con_cnt), sum(prem)
       INTO $iofficer, $iquota, $ibranch, $renew_cnt, $con_cnt, $prem
       FROM CAR316_MGE
      GROUP BY 1,2,3;
   $OPEN agentmge;
   while(1)
   {
       $FETCH agentmge;
       if(SQLCODE == SQLNOTFOUND) break;
 
       $UPDATE AGENT
           SET renew_cnt_mge = renew_cnt_mge + $renew_cnt,
               con_cnt_mge   = con_cnt_mge   + $con_cnt,
               prem_mge      = prem_mge      + $prem
         WHERE iofficer  = $iofficer
           AND iquota    = $iquota
           AND ibranch   = $ibranch;
       
   }  /*  End of agent cursor while  */
   $CLOSE agentmge;
   $FREE  agentmge;

   /******     Start to print report(Excel Format)  ******/
   $DECLARE agent_prn CURSOR FOR
     SELECT a.qorder, a.iquota, a.ibranch, a.idealer, a.iofficer, 
            a.renew_cnt, a.con_cnt, a.prem, a.nofficer, c.nbranch,
            a.itop, a.renew_cnt_a, a.con_cnt_a, a.prem_a, 
            a.renew_cnt_mge, a.con_cnt_mge, a.prem_mge
       INTO $qqord, $iquota, $ibranch, $idealer, $iofficer,
            $renew_cnt,  $con_cnt, $prem, $nname,  $nbranch, $itop,
            $renew_cnt_a, $con_cnt_a, $prem_a, 
            $renew_cnt_mge, $con_cnt_mge, $prem_mge
       FROM AGENT a,sa_branch_type c
      WHERE a.iquota = c.ibranch
      ORDER BY a.qorder, itop,idealer,iofficer;

   $OPEN agent_prn;

   printf("Agent_prn Start!!\n");
   $FETCH agent_prn;
   if(SQLCODE == SQLNOTFOUND)
   {
       printf("Agent_prn fetch first failed!!!!!\n");
       goto errexit;
   }
   
   strcpy(idealer_t, " ");
   
   
   rgu_put_body_string(1, cm_get_sysd(), 1);
   rgu_put_body_string(1, nprmt, 1);
   rgu_put_body_string(1, dbgn_inf, 1);
   rgu_put_body_string(1, dend_inf, 1);
   rgu_put_body(1);

   while(1)
   {

       rgu_put_body_string(data_line, qqord, 1);
       strcpy(nbranch, trim(nbranch));
       rgu_put_body_string(data_line, nbranch, 1);

       
       if (strcmp(idealer,idealer_t) != 0) {
          $SELECT ncode  INTO $ndealer
             FROM cu_code_data
            WHERE itype = '23'
              AND icode = $idealer;
          if (SQLCODE==SQLNOTFOUND)
             strcpy(ndealer," ");
          else
             strcpy(ndealer, trim(ndealer));
       }

       rgu_put_body_string(data_line, ndealer, 1);

       strcpy(nname, trim(nname));
       rgu_put_body_string(data_line, nname, 1);
       rgu_put_body_string(data_line, iofficer, 1);

       rfmtlong(renew_cnt, "------&", buf1);
       rgu_put_body_string(data_line, buf1, 1);
       rfmtlong(con_cnt,   "------&", buf1);
       rgu_put_body_string(data_line, buf1, 1);
       rfmtlong(prem, "------------&", buf1);
       rgu_put_body_string(data_line, buf1, 1);
       
       rfmtlong(renew_cnt_a, "------&", buf1);
       rgu_put_body_string(data_line, buf1, 1);
       rfmtlong(con_cnt_a,   "------&", buf1);
       rgu_put_body_string(data_line, buf1, 1);
       rfmtlong(prem_a, "------------&", buf1);
       rgu_put_body_string(data_line, buf1, 1);
       
       rfmtlong(renew_cnt_mge, "------&", buf1);
       rgu_put_body_string(data_line, buf1, 1);
       rfmtlong(con_cnt_mge,   "------&", buf1);
       rgu_put_body_string(data_line, buf1, 1);
       rfmtlong(prem_mge, "------------&", buf1);
       rgu_put_body_string(data_line, buf1, 1);
              
       rgu_put_body(data_line);
       
       max_cnt = max_cnt + 1;

       strcpy(idealer_t, idealer);
       strcpy(iofficer_t, iofficer);

     $FETCH agent_prn;
     if(SQLCODE == SQLNOTFOUND) break;
   }  /******  End of agent_prn cursor while  ******/
   $CLOSE agent_prn;
   $FREE  agent_prn;

   $DROP TABLE AGENT;

   return M_CM_OK;
   
errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

long car316_body2()
{
     $char  buf1[10], ipolicy[21], inext_ply[21], nassured_t[12], nassured_old[13];
     $char  ibranch[6],ibranch_old[11], ibranch_t[11],nbranch[26];
     $char  ibranch_p[6],igroup_p[6];
     $char  iofficer[11],iofficer_t[11],ioff_name[11], nname[11];
     $char  iofficer_old[11], itag_old[CA_TAG_NUM], itag_t[CA_TAG_NUM];
     $char  iengine[CA_ENGINE_NUM], iengine_t[CA_ENGINE_NUM], iquota_old[7], iquota_t[7], iquota[7];
     $char  idealer[6], idealer_t[6], idea_name[21], idea_name_t[21];
     $char  dply_begin_old[13], dply_end_old[13], dply_begin_t[13], dply_end_t[13];
     $char  ndealer_new[10], idealer_new[6], ioff_name_new[11], ndealer[11];
     $int   qorder;
     $long  prem, iLength;
     $double pdiscount;
     $char  DBName2[5], sFullName2[20], stmt[1024],tmp_data[10], ioff_old_n[11];
     $char  prmp_n[30],temp_data[10];
       int  k=0;
       
     printf("body2 start!!\n");
     
     sprintf(stmt,"SELECT nbranch FROM sa_branch_type WHERE ibranch = ?");
     $PREPARE get_branch FROM $stmt;
     
     sprintf(stmt,"SELECT ncode FROM cu_code_data WHERE itype = '23' \
                      AND icode = ?");
     $PREPARE get_ngroup FROM $stmt;
     
     sprintf(stmt,"SELECT nname FROM officer WHERE iofficer = ?");
     $PREPARE get_offname FROM $stmt;

     $CREATE TEMP TABLE AORDER
      (
        iofficer     char(10),
        ioff_name    char(12),
        qorder       integer default 0 not null,
        idealer      char(3),
        idea_name    char(20)
      )WITH NO LOG;

     $CREATE UNIQUE INDEX AOR_ix1 ON AORDER ( iofficer );

     $DECLARE get_order CURSOR FOR
       SELECT UNIQUE b.iofficer, nvl(a.nname,' '), nvl(a.idealer,' ')
         INTO $iofficer, $ioff_name, $idealer
         FROM CAR316 b,outer officer a
        WHERE b.iofficer = a.iofficer
        ORDER BY b.iofficer;

     $OPEN get_order;
     while(1)
     {
        $FETCH get_order;
        if(SQLCODE == SQLNOTFOUND) break;

        $SELECT tcode_remark, ncode 
           INTO $qorder, $idea_name
           FROM cu_code_data
          WHERE itype = '23'
            AND icode = $idealer;
        if (SQLCODE==SQLNOTFOUND) {
           strcpy(idea_name," ");
           qorder = 0;
        }
            
        $INSERT INTO AORDER
         ( iofficer, ioff_name, qorder, idealer, idea_name )
        VALUES
         ( $iofficer, $ioff_name, $qorder, $idealer, $idea_name );
     }
     $CLOSE get_order;
     $FREE  get_order;
     
     strcpy(idealer_t," ");
     
     $DECLARE com_cur CURSOR FOR
       SELECT b.qorder, b.idea_name, a.iofficer_old, 
              (select nname from officer where iofficer = a.iofficer_old),
              a.ipolicy, a.dply_begin_old, a.dply_end_old, a.itag_old, 
              a.nassured_old, a.inext_ply, a.iofficer_t, a.dply_begin_t,
              a.dply_end_t, iengine_t, itag_t, nassured_t, 
              pdiscount, prem, 
              iquota_old[1,4] || '00', iquota_t[1,4] || '00', a.iofficer,
              b.ioff_name, a.iquota, a.ibranch
         INTO $qorder,  $idea_name, $iofficer_old, $ioff_old_n, 
              $ipolicy, $dply_begin_old, $dply_end_old, $itag_old,
              $nassured_old, $inext_ply, $iofficer_t, $dply_begin_t,
              $dply_end_t, $iengine_t, $itag_t, $nassured_t, 
              $pdiscount,  $prem, $iquota_old, $iquota_t, $iofficer,
              $ioff_name, $iquota, $temp_data
         FROM CAR316 a , AORDER b
        WHERE a.iofficer = b.iofficer
       ORDER BY a.ibranch, qorder, a.iofficer;
     $OPEN com_cur;
     $FETCH com_cur;
     if(SQLCODE == SQLNOTFOUND)
     {
       printf("Non_agent first fetch failed!!!\n");
       goto errexit;
     }

     rgu_put_body_string(1, cm_get_sysd(), 1);
     sprintf(prmp_n,"%s(B��)",trim(nprmt));
     rgu_put_body_string(1, prmp_n, 2);
     
     rgu_put_body_string(1, dbgn_inf, 1);
     rgu_put_body_string(1, dend_inf, 1);
     rgu_put_body(1);

     while(1)
     {   	
     	$EXECUTE get_branch INTO $ibranch_old using  $iquota;
     	if(SQLCODE == SQLNOTFOUND) 
     	   strcpy(ibranch_old," ");
     	   
     	rgu_put_body_string(data_line, ibranch_old, 1);
printf("===============================================================1:idea_name[%s]\n", idea_name);
        iLength=cc_split_chinese( idea_name, idea_name_t, 10);
     	rgu_put_body_string(data_line, idea_name_t, 1);
     	
     	rgu_put_body_string(data_line, iofficer, 1);
     	rgu_put_body_string(data_line, ioff_name, 1);
     	
     	rgu_put_body_string(data_line, iofficer_old, 1);
     	rgu_put_body_string(data_line, ioff_old_n, 1);
     	rgu_put_body_string(data_line, ipolicy, 1);
     	rgu_put_body_string(data_line, dply_begin_old, 1);
     	rgu_put_body_string(data_line, dply_end_old, 1);
     	rgu_put_body_string(data_line, itag_old, 1);
     	rgu_put_body_string(data_line, nassured_old, 1);
     	
     	if( strlen(trim(inext_ply)) > 0 )
     	{
     	    /** ����O�A�B�z�s�g�P�Ӥ��� **/
     	    $EXECUTE get_branch INTO $ibranch_t using  $iquota_t;
     	    if(SQLCODE == SQLNOTFOUND) 
     	      strcpy(ibranch_t," ");
     	    
            $SELECT idealer INTO $idealer_new
               FROM officer
              WHERE iofficer = $iofficer_t;
            if(SQLCODE == SQLNOTFOUND)
               strcpy(idealer_new," ");
     	    
     	    $EXECUTE get_ngroup INTO $ndealer_new using $idealer_new;
     	    if(SQLCODE == SQLNOTFOUND) 
     	       strcpy( ndealer_new, " ");
     	    
     	    $EXECUTE get_offname INTO $ioff_name_new using $iofficer_t;
     	    if(SQLCODE == SQLNOTFOUND) 
     	       strcpy( ioff_name_new, " ");
   
     	    rgu_put_body_string(data_line, ibranch_t, 1);
     	    rgu_put_body_string(data_line, ndealer_new, 1);
     	    rgu_put_body_string(data_line, iofficer_t, 1);
     	    rgu_put_body_string(data_line, ioff_name_new, 1);
     	    rgu_put_body_string(data_line, inext_ply, 1);
     	    rgu_put_body_string(data_line, dply_begin_t, 1);
     	    rgu_put_body_string(data_line, dply_end_t, 1);
     	    rgu_put_body_string(data_line, iengine_t, 1);
     	    rgu_put_body_string(data_line, itag_t, 1);
     	    rgu_put_body_string(data_line, nassured_t, 1);
     	
     	    rfmtdouble(pdiscount, "-###&.##", buf1);
            rgu_put_body_string(data_line,buf1,LEFT);
            rfmtlong(prem, "--------&", buf1);
            rgu_put_body_string(data_line, buf1);
     	}
     	else
     	{
     	    for(k=0;k<12;k++)
     	      rgu_put_body_string(data_line, " ", 1);
     	}
     	
        rgu_put_body(data_line);
        max_cnt = max_cnt + 1;
        
        $FETCH com_cur;
        if(SQLCODE == SQLNOTFOUND) break;
     }  /****** End of com_cur cursor while  ******/
     $CLOSE com_cur;
     $FREE  com_cur;

     $DROP TABLE AORDER;

     return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

long car316_body3()
{
     $char  buf1[10], ipolicy[21], inext_ply[21], nassured_t[12], nassured_old[13];
     $char  ibranch[6],ibranch_old[11], ibranch_t[11], ibranch_c[11], nbranch[26];
     $char  ibranch_p[6],igroup_p[6];
     $char  iofficer[11],iofficer_t[11],ioff_name[11], nname[11];
     $char  iofficer_old[11], itag_old[CA_TAG_NUM], itag_t[CA_TAG_NUM];
     $char  iengine[CA_ENGINE_NUM], iengine_t[CA_ENGINE_NUM], iquota_old[7], iquota_t[7], iquota[7];
     $char  idealer[6], idealer_t[6], idea_name[21], idea_name_t[21];
     $char  dply_begin_old[13], dply_end_old[13], dply_begin_t[13], dply_end_t[13];
     $char  ndealer_new[10], idealer_new[6], ioff_name_new[11], ndealer[11];
     $int   qorder;
     $long  prem, iLength;
     $double pdiscount;
     $char  DBName2[5], sFullName2[20], stmt[1024],tmp_data[10],ioff_old_n[11];
     $char  prmp_n[30], temp_data[10];
       int  k=0;
       
     printf("body3 start!!\n");
     
     sprintf(stmt,"SELECT nbranch FROM sa_branch_type WHERE ibranch = ?");
     $PREPARE get_branch FROM $stmt;
     
     sprintf(stmt,"SELECT ncode FROM cu_code_data WHERE itype = '23' \
                      AND icode = ?");
     $PREPARE get_ngroup FROM $stmt;
     
     sprintf(stmt,"SELECT nname FROM officer WHERE iofficer = ?");
     $PREPARE get_offname FROM $stmt;

     $CREATE TEMP TABLE AORDER
      (
        iofficer     char(10),
        ioff_name    char(12),
        qorder       integer default 0 not null,
        idealer      char(3),
        idea_name    char(20)
      )WITH NO LOG;

     $CREATE UNIQUE INDEX AOR_ix1 ON AORDER ( iofficer );

     $DECLARE get_ordera CURSOR FOR
       SELECT UNIQUE a.iofficer, a.nname, a.idealer
         INTO $iofficer, $ioff_name, $idealer
         FROM CAR316A b,officer a
        WHERE b.iofficer = a.iofficer
        ORDER BY a.iofficer;

     $OPEN get_ordera;
     while(1)
     {
        $FETCH get_ordera;
        if(SQLCODE == SQLNOTFOUND) break;

        $SELECT tcode_remark, ncode 
           INTO $qorder, $idea_name
           FROM cu_code_data 
          WHERE itype = '23'
            AND icode = $idealer;
            
        $INSERT INTO AORDER
         ( iofficer, ioff_name, qorder, idealer, idea_name )
        VALUES
         ( $iofficer, $ioff_name, $qorder, $idealer, $idea_name );
     }
     $CLOSE get_ordera;
     $FREE  get_ordera;
     
     strcpy(idealer_t," ");
     
     $DECLARE com_cura CURSOR FOR
       SELECT b.qorder, b.idea_name, a.iofficer_old,
              (select nname from officer where iofficer = a.iofficer_old), 
              a.ipolicy, a.dply_begin_old, a.dply_end_old, a.itag_old, 
              a.nassured_old, a.inext_ply, a.iofficer_t, a.dply_begin_t,
              a.dply_end_t, iengine_t, itag_t, nassured_t, 
              pdiscount, prem,
              iquota_old[1,4] || '00', iquota_t[1,4] || '00', 
              a.iofficer, b.ioff_name, a.iquota, a.ibranch
         INTO $qorder,  $idea_name, $iofficer_old, $ioff_old_n,
              $ipolicy, $dply_begin_old, $dply_end_old, $itag_old,
              $nassured_old, $inext_ply, $iofficer_t, $dply_begin_t,
              $dply_end_t, $iengine_t, $itag_t, $nassured_t, 
              $pdiscount,  $prem, $iquota_old, $iquota_t, 
              $iofficer,  $ioff_name, $iquota
         FROM CAR316A a , AORDER b
        WHERE a.iofficer = b.iofficer
       ORDER BY a.ibranch, qorder, a.iofficer;
     $OPEN com_cura;
     $FETCH com_cura;
     if(SQLCODE == SQLNOTFOUND)
     {
       printf("Non_agent first fetch failed!!!\n");
       goto errexit;
     }

     rgu_put_body_string(1, cm_get_sysd(), 1);
     sprintf(prmp_n,"%s(A��)",nprmt);
     rgu_put_body_string(1, trim(prmp_n), 1);

     rgu_put_body_string(1, dbgn_inf, 1);
     rgu_put_body_string(1, dend_inf, 1);
     rgu_put_body(1);

     while(1)
     {  	
     	$EXECUTE get_branch INTO $ibranch_c using  $iquota;
     	if(SQLCODE == SQLNOTFOUND) 
     	   strcpy(ibranch_c," ");
     	   
     	
     	$EXECUTE get_branch INTO $ibranch_old using  $iquota_old;
 	if(SQLCODE == SQLNOTFOUND) 
     	   strcpy(ibranch_old," ");   
     	
     	
     	rgu_put_body_string(data_line, ibranch_c, 1);
printf("===============================================================2:idea_name[%s]\n", idea_name);
        iLength=cc_split_chinese( idea_name, idea_name_t, 10);
     	rgu_put_body_string(data_line, idea_name_t, 1);
     	      
     	rgu_put_body_string(data_line, iofficer, 1);
     	rgu_put_body_string(data_line, ioff_name, 1);
     	   
     	if( strlen(trim(ibranch_old)) > 0 )
     	{
     	
     	   /** rgu_put_body_string(data_line, ibranch_old, 1);  **/
     	   
     	   rgu_put_body_string(data_line, iofficer_old, 1);
     	   rgu_put_body_string(data_line, ioff_old_n, 1);
     	
     	   rgu_put_body_string(data_line, ipolicy, 1);
     	   rgu_put_body_string(data_line, dply_begin_old, 1);
     	   rgu_put_body_string(data_line, dply_end_old, 1);
     	   rgu_put_body_string(data_line, itag_old, 1);
     	   rgu_put_body_string(data_line, nassured_old, 1);
     	}
     	else
     	{  
     	    for(k=0;k<7;k++)
     	      rgu_put_body_string(data_line, " ", 1);
     	}
     	
     	if( strlen(trim(inext_ply)) > 0 )
     	{
     	    /** ����O�A�B�z�s�g�P�Ӥ��� **/
     	    $EXECUTE get_branch INTO $ibranch_t using  $iquota_t;
     	    if(SQLCODE == SQLNOTFOUND) 
     	      strcpy(ibranch_t," ");
     	    
            $SELECT idealer INTO $idealer_new
               FROM officer
              WHERE iofficer = $iofficer_t;
            if(SQLCODE == SQLNOTFOUND)
               strcpy(idealer_new," ");
     	    
     	    $EXECUTE get_ngroup INTO $ndealer_new using $idealer_new;
     	    if(SQLCODE == SQLNOTFOUND) 
     	       strcpy( ndealer_new, " ");
     	    
     	    $EXECUTE get_offname INTO $ioff_name_new using $iofficer_t;
     	    if(SQLCODE == SQLNOTFOUND) 
     	       strcpy( ioff_name_new, " ");
     	       	    
     	    rgu_put_body_string(data_line, ibranch_t, 1);
     	    rgu_put_body_string(data_line, ndealer_new, 1);
     	    rgu_put_body_string(data_line, iofficer_t, 1);
     	    rgu_put_body_string(data_line, ioff_name_new, 1);
     	    rgu_put_body_string(data_line, inext_ply, 1);
     	    rgu_put_body_string(data_line, dply_begin_t, 1);
     	    rgu_put_body_string(data_line, dply_end_t, 1);
     	    rgu_put_body_string(data_line, iengine_t, 1);
     	    rgu_put_body_string(data_line, itag_t, 1);
     	    rgu_put_body_string(data_line, nassured_t, 1);
     	
     	    rfmtdouble(pdiscount, "-###&.##", buf1);
            rgu_put_body_string(data_line,buf1,LEFT);
            rfmtlong(prem, "--------&", buf1);
            rgu_put_body_string(data_line, buf1);
     	}
     	else
     	{
     	    for(k=0;k<12;k++)
     	      rgu_put_body_string(data_line, " ", 1);
     	}
     	
        rgu_put_body(data_line);
        max_cnt = max_cnt + 1;
        
        $FETCH com_cura;
        if(SQLCODE == SQLNOTFOUND) break;
     }  /****** End of com_cur cursor while  ******/
     $CLOSE com_cura;
     $FREE  com_cura;

     return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}
/*---------------------------------------------------------------------------*/
char *getdate(sDate)
char sDate[11];
{
char dply_end[9];

     dply_end[0] = sDate[6];
     dply_end[1] = sDate[7];
     dply_end[2] = sDate[8];
     dply_end[3] = sDate[9];
     dply_end[4] = sDate[0];
     dply_end[5] = sDate[1];
     dply_end[6] = sDate[3];
     dply_end[7] = sDate[4];
     dply_end[8] = '\0';

     return dply_end;   
}


char *setdate(sDate)
char sDate[11];
{
char duty_date[11];

     duty_date[0] = sDate[4];
     duty_date[1] = sDate[5];
     duty_date[2] = '/';
     duty_date[3] = sDate[6];
     duty_date[4] = sDate[7];
     duty_date[5] = '/';
     duty_date[6] = sDate[0];
     duty_date[7] = sDate[1];
     duty_date[8] = sDate[2];
     duty_date[9] = sDate[3];
     duty_date[10] = '\0';


     return duty_date;
}

long get_ca_promote()
{
   
   $whenever sqlerror goto errexit;
   
   if (db_select(DBName) == False)
   {
       return M_CM_DB_NOTOPEN;
   }
   
   printf("===== start  get_ca_promote \n");
  
   $SELECT iprmt, nprmt, iremark, iagent, iofficer_1, lofficer,
           ioff_chk_bgn, ioff_chk_len, ioff_chk, mlimit, fanother,
           iofficera_1, lofficera , ioff_chk_bgna, ioff_chk_lena, ioff_chka
      INTO $iprmt, $nprmt, $iremark, $iagent, $iofficer_ch1, $iofficer_len,
           $ioff_ck_bgn, $ioff_ck_len, $ioff_chk, $mlimit, $fanother,
           $iofficera_ch1, $lofficera , $ioff_chk_bgna, $ioff_chk_lena, $ioff_chka
      FROM ca_promote
     WHERE iprmt = $pro_no;
   if(SQLCODE != SQLNOTFOUND )
   {
      ioff_ck_end = ioff_ck_bgn + ioff_ck_len -1;
      strcpy( iofficer_ch1, trim(iofficer_ch1));
      
      if( fanother[0] == 'Y' )
      {
          ioff_ch_enda = ioff_chk_bgna + ioff_chk_lena -1;
          strcpy( iofficera_1, trim(iofficera_1));
      }
      else
          ioff_ch_enda=0;
          
      
      printf("===== finish get_ca_promote \n");
      
      return M_CM_OK;
   }
   
errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(FAIL);    
}

long  chk_AB_policy( ipolicy_A2, ipolicy_B1 )
$char ipolicy_A2[20];
$char ipolicy_B1[20];
{
   $char  stmt[1024], tmp_dbnameA[20], tmp_dbnameB[20], strA[512];
   $char  iassured_b1[11], iengine_b1[CA_ENGINE_NUM];
   $long  ldply_end_b1, ldply_begin_a2;
   $char  ilast_ply_a2[21], iengine_a2[CA_ENGINE_NUM], iassured_a2[11];
   $char  tmp_dbnamex[20];
   
   printf("----  in chk_AB_policy  ----\n");
   
   
   strcpy(tmp_dbnameA,get_car_full_db(ipolicy_A2));
   strcpy(tmp_dbnameB,get_car_full_db(ipolicy_B1));
   
   iequip_flag = (iremark - 1) % 30 + 1;
   strcpy(iequip_tmp,itoa(iremark));
   strcpy(sequip_str,equip_instr(iequip_tmp));
   
   sprintf(strA,"AND (a.mdmg_prem + a.mlia_prem) > %d \
                 AND b.nequipment[%d] in %s AND a.iofficer matches '%s*' \
                 ",mlimit, iequip_flag, sequip_str, trim(iagent) );
   
   sprintf(stmt,"SELECT a.ilast_ply, b.iengine, b.iassured, a.dply_begin \
                   FROM %s:ply_relation a, %s:policy b \
                  WHERE a.ipolicy = b.ipolicy \
                    AND a.ipolicy = '%s' %s",
           tmp_dbnameA, tmp_dbnameA, ipolicy_A2, strA );
 
   $PREPARE get_a2_d FROM $stmt;
   $EXECUTE get_a2_d INTO $ilast_ply_a2, $iengine_a2, $iassured_a2, $ldply_begin_a2;
   if(SQLCODE == SQLNOTFOUND)
   {
   	/** A2�L���Oor�O�O����or�D�O�N�X��**/
   	return 0;
   }
  
   sprintf(stmt,"SELECT a.dply_end, b.iassured, b.iengine \
                   FROM %s:ply_relation a , %s:policy b\
                  WHERE a.ipolicy = b.ipolicy \
                    AND a.ipolicy = '%s'", tmp_dbnameB, tmp_dbnameB, ipolicy_B1);
   
   $PREPARE get_b1_d FROM $stmt;
   $EXECUTE get_b1_d INTO $ldply_end_b1, $iassured_b1, $iengine_b1;
   if( SQLCODE == SQLNOTFOUND )
   {
   	/** �䤣��B1��� **/
   	return 0;
   }
   
   if( strlen(trim(ilast_ply_a2)) > 0 )
   {
   	/** ��A1��A���A1,A2�O�� **/
   	strcpy(tmp_dbnamex,get_car_full_db(ilast_ply_a2));
   	sprintf(stmt,"SELECT dply_end \
   	                FROM %s:ply_relation WHERE ipolicy = '%s'",
   	              tmp_dbnamex, ilast_ply_a2);
   	$PREPARE get_a1_d FROM $stmt;
   	$EXECUTE get_a1_d INTO $ldply_end_b1;
   }
   
   /** Ū����ƻ����A�i���ˮ֤������X�B�Q�O�Hid�B�O�� **/
   strcpy(iassured_b1, trim(iassured_b1));
   strcpy(iassured_a2, trim(iassured_a2));
   strcpy(iengine_a2,  trim(iengine_a2));
   strcpy(iengine_b1,  trim(iengine_b1));
   
   if( (ldply_end_b1 < ldply_begin_a2) ||
       ( strcmp(iengine_a2, iengine_b1) != 0 ) ||
       ( strcmp(iassured_a2, iassured_b1) != 0 ) )
   {
       /** �ˮ֥��� **/
       return 0;
   }
   
   printf("compress success \n");
   
   /** �ˮ֦��\ **/
   return M_CM_OK;
   
errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(FAIL);    
}
/*------------------------------------------------------end of program*/
