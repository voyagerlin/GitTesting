/*******************************************/
/*                                         */
/*   �֯S���AA�дک��Ӫ�                   */
/*                                         */
/*   PROGRAM : ca626q06s.ec                */
/*   DATE    : 2004/02/03                  */
/*   MODIFY  : yyyy/mm/dd                  */
/*   Checked for ����100�~                 */
/*******************************************/
#include <stdio.h>
#include <unistd.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include "safeclib.h"
#include <float.h>
#define  head_line         1
#define  desc_line         2
#define  data_line         2

extern char RPTDIR[];

$char dbgn1[11], dend1[11];
$char dbgn_inf[11], dend_inf[11];
char  MsgCode[50],fply_close[2],qnext_year[2];
$char Igroup[7],Ngroup[21];

$char iquota[7],icard[21],ipolicy[21],iendorse[21],iassured[18];
$char nassured[25],dpolicy[11],dply_begin[11],ibrand[9],ori_dpolicy[11];
$char iengine[21],iissue_ym[7],ibig_office[10],ibig_office_c[11];
$char itag[CA_TAG_NUM],nbrand_abbr[13],dendorse[11],ioff1[2],iofficer[11];
$char ibig_sales[11],nsales[11],iins_type[7],ioff_sales[4];
$char ncomp[11],nbig[21],dedr_close[11],fedr_class[2],d_today[11];
$long mprem_09,mprem,mprem_edr,mdisc_edr,mdiscount,pdiscount,mexpense;
$long magent_edr,medr_discount,magent,mprem1,mdisc1,magent1;
$long medr_09,medr_exp,mexp_09;
$char iassured1[13],iassured2[3],ipro_year[5],nbrand[31];
$char bufA[80];

/* car9805211 �s�W�n�O�H�H�Φw��/�޲z���I�[��T�� */
$char   napplicant[25],iapplicant[13];
$double rSafe_09 = 0;
$double rMgmt_09 = 0;
$double tmp_safe = 0, tmp_manage = 0;

DBinfo *list;
int   count_db;
$char DBName[05], iForm_Tp[03];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1];
char  outputf[N_FILE+1], userid[11];

$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;
$char check1[2],check2[2],stmtX[1000];

int  max_cnt;

long car6266_build1();
long car6266_build2();
long car6266_body1();
long car6266_body2();
long car6266_accumulate();
void car6266_title();
void print_car6266_body1();
void print_car6266_body2();
/*--------------------------------------------------------------------*/
car6266(DBName_h,userid_h,dbgn1_h,dend1_h,check1_h,check2_h,fclose_h,qnext_year_h,outputf_h)
char *DBName_h,*userid_h,*dbgn1_h,*dend1_h,*check1_h,*check2_h,*fclose_h;
char *qnext_year_h,*outputf_h;
{
   int rc;
   batchinit();

printf("begin car6266\n");

   strcpy(DBName,  DBName_h);
   strcpy(userid,  userid_h);
   strcpy(dbgn1,   dbgn1_h);
   strcpy(dend1,   dend1_h);
   strcpy(check1,  check1_h);
   strcpy(check2,  check2_h);
   strcpy(fply_close,  fclose_h);
   strcpy(qnext_year, qnext_year_h);
   strcpy(outputf, outputf_h);

   strcpy(dbgn_inf, cm_to_infdate(dbgn1));
   strcpy(dend_inf, cm_to_infdate(dend1));

   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False) {
       return M_CM_DB_NOTOPEN;
   }

   if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
      if (EWRITE(userid, M_CM_NOT_DBLIST) == True)
        return M_CM_NOT_DBLIST;
      return M_CM_OK;
   }

   max_cnt=0;
   if(strncmp(check1,"1",1)==0) {
      rc = car6266_build1();
      if ( rc != M_CM_OK)  {
          EWRITE(userid, rc, " ");
          return rc;
      }
   }

   max_cnt=0;
   if(strncmp(check2,"1",1)==0) {
      rc = car6266_build2();
      if ( rc != M_CM_OK)  {
          EWRITE(userid, rc, " ");
          return rc;
      }
   }
   return M_CM_OK;

errexit:
 sqlfatal();
 EWRITE(userid,SQLCODE,sqlca.sqlerrm);
 return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car6266_build1()
{
   $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];
   int    rc;
   $WHENEVER SQLERROR GOTO errexit;

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width, $iForm_Tp
      FROM Form
    WHERE ksys_grp = 'CA' AND kPgmID = 626 AND Iform_tp ='7';

   strcpy( TitleFmt,rtrim(TitleFmt));
   strcpy( BodyFmt,rtrim(BodyFmt));

   if (strncmp(check2,"1",1)==0)
     {sprintf_s(TitleFile, sizeof TitleFile,"%sA.ti",outputf);
      sprintf_s(BodyFile, sizeof BodyFile,"%sA.bd",outputf);
     }
   else
     {sprintf_s(TitleFile, sizeof TitleFile,"%s.ti",outputf);
      sprintf_s(BodyFile, sizeof BodyFile,"%s.bd",outputf);
     }

   rgu_init_report(TitleFmt,TitleFile);
   car6266_title();
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);
   rc = car6266_body1();
   if (rc != M_CM_OK)
       return rc;
   rgu_finish_report();

   if ((rc=save_form_info(F_BLK1, "CA", 626, userid, iForm_Tp, max_cnt,
        outputf))<0) {
        strcpy(MsgCode,"save_form_info failed");
        return rc;
   }

   return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car6266_build2()
{
   $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];
   int    rc;
   $WHENEVER SQLERROR GOTO errexit;

     $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
             kTot_Col, kPgNum_Line, kWidth, iForm_Tp
        INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
             $TotColumn, $PgLine, $Width, $iForm_Tp
      FROM Form
     WHERE ksys_grp = "CA" AND kPgmID = 626 AND Iform_tp ='7';

   strcpy( TitleFmt,rtrim(TitleFmt));
   strcpy( BodyFmt,rtrim(BodyFmt));

   if (strncmp(check1,"1",1)==0)
     {sprintf_s(TitleFile, sizeof TitleFile,"%sB.ti",outputf);
      sprintf_s(BodyFile, sizeof BodyFile,"%sB.bd",outputf);
     }
   else
     {sprintf_s(TitleFile, sizeof TitleFile,"%s.ti",outputf);
      sprintf_s(BodyFile, sizeof BodyFile,"%s.bd",outputf);
     }

   rgu_init_report(TitleFmt,TitleFile);
   car6266_title();
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);
   rc = car6266_body2();
   if (rc != M_CM_OK)
       return rc;
   rgu_finish_report();

   if ((rc=save_form_info(F_BLK1, "CA", 626, userid, iForm_Tp, max_cnt,
        outputf))<0) {
        strcpy(MsgCode,"save_form_info failed");
        return rc;
   }

   return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car6266_body1()
{
 int   j;
 $char stmt[1024],stmt1[1024],stmt2[512],stmt3[512],stmt_qnextyear[128];

 $WHENEVER SQLERROR GOTO errexit;

 rgu_put_body_string(1,"�̷s�O��"   ,1);
 rgu_put_body_string(1,cm_get_sysd(),1);
 rgu_put_body_string(1,dbgn1,1);
 rgu_put_body_string(1,dend1,1);
 rgu_put_body(1);
 max_cnt =6;

 if (strncmp(fply_close,"1",1)==0) 
     strcpy(stmt2," AND a.dply_close is not null ");
 else
     strcpy(stmt2," ");
     
 /* �P�_�����O��/�s�O��/��O�� Modified by Julia Han in 2007/04/30 */
 /* "A"�������O��,"0"���s�O��,"1"����O�� */
   if (strncmp(qnext_year,"0",1)==0) {
   	strcpy(stmt_qnextyear,"AND a.qnext_year = 0");
   } else if (strncmp(qnext_year,"1",1)==0) {
   				strcpy(stmt_qnextyear,"AND a.qnext_year > 0");
   } else {
   				strcpy(stmt_qnextyear,"");
   }

 for(j=0;j<count_db;j++) {
      sprintf_s(stmt, sizeof stmt,
             "SELECT a.ipolicy,a.icard,a.dply_begin,a.ibrand, "
             "to_char(b.dissue,'%%Y')::integer - 1911 || '/' || to_char(b.dissue,'%%m'), "
             "a.ibig_office,a.iquota[1,4]||'00',a.dpolicy, "
             "a.ipro_year,a.mdmg_prem + a.mlia_prem, "
             "mdmg_agent+mlia_agent,mdmg_discount+mlia_discount, "
             "b.iassured,b.iassured_ext,b.nassured[1,24],b.iapplicant,b.napplicant[1,24], "
             "b.iengine,b.itag,nvl(a.dendorse,' '),ibig_sales, "
             "a.fedr_class,today,a.iofficer  "
             "FROM %s:ply_relation a, %s:policy b  "
             "WHERE a.dpolicy >= ? AND a.dpolicy <= ?  "
             "AND a.ipolicy = b.ipolicy %s  "
             "AND a.iofficer[1,3] in ('F98','G98') %s",
             list[j].dbname,list[j].dbname,stmt2,stmt_qnextyear);
printf("body1.stmt[%s]\n",stmt);
      $PREPARE a_id1 FROM $stmt;
      $DECLARE cur_A CURSOR FOR a_id1;
      $OPEN cur_A USING $dbgn_inf,$dend_inf;
      for(;;) {
         mprem=magent=mdiscount=mprem_09=mprem_edr=mdisc_edr=medr_09=0;
         magent_edr=mprem1=mdisc1=magent1=mexpense=medr_exp=mexp_09=0;
         
         $FETCH cur_A
           INTO $ipolicy,$icard,$dply_begin,$ibrand,$iissue_ym,
                $ibig_office,$iquota,$dpolicy,$ipro_year,
                $mprem,$magent,$mdiscount,
                $iassured1,$iassured2,$nassured,$iapplicant,$napplicant,$iengine,
                $itag,$dendorse,$ibig_sales,
                $fedr_class,$d_today,$iofficer;
         if (SQLCODE == SQLNOTFOUND) break;
         if (strcmp(dendorse,d_today)!=0 && strncmp(fedr_class,"1",1)==0)
            continue;
         if (strncmp(fedr_class,"1",1)==0) {
            sprintf_s(stmt1, sizeof stmt1,"select iins_type,medr_expense,safe_rate,manage_rate  "
                           " from %s:edr_relation a,%s:edr_ins_type b  "
                           "where a.ipolicy = ?  "
                           "  and a.fedr_class = '1'  "
                           "  and a.dendorse is not null  "
                           "  and a.iendorse = b.iendorse  "
                           "  and iins_type in ('01','05','08','09')  "
                           "  and medrdmg_cover != 0 ",
                    list[j].dbname,list[j].dbname);
         }
         else {
            sprintf_s(stmt1, sizeof stmt1,"select iins_type,mexpense,safe_rate,manage_rate from %s:ply_ins_type  "
                          "where ipolicy = ? and mdamage_cover != 0  "
                          "  and iins_type in ('01','05','08','09') ", 
                    list[j].dbname);
         }
         $prepare a_id11 from $stmt1;
         $declare cur_A1 cursor for a_id11;
         $open cur_A1 using $ipolicy;
         $fetch cur_A1 into $iins_type,$mexpense,$tmp_safe,$tmp_manage;
         if (SQLCODE == SQLNOTFOUND) strcpy(iins_type,"00");
         $close cur_A1;

         strcpy(iendorse," ");
         if (strncmp(dendorse," ",1)!=0) {
            sprintf_s(stmt1, sizeof stmt1,
                   "SELECT a.iendorse,dply_begin,ibrand,ibig_sales, "
                   "to_char(b.dissue,'%%Y')::integer - 1911 || '/' || to_char(b.dissue,'%%m'), "
                   "ipro_year,medrdmg_prem+medrlia_prem, "
                   "medrdmg_disc+medrlia_disc, "
                   "medrdmg_agent+medrlia_agent, "
                   "iassured,iassured_ext,nvl(dedr_close,' ') "
                   " FROM %s:edr_relation a,%s:endorsement b "
                   "WHERE ipolicy = ?  "
                   "  AND dendorse is not null  "
                   "  AND a.iendorse = b.iendorse",
                   list[j].dbname,list[j].dbname);
            $PREPARE a_id2 FROM $stmt1;
            $DECLARE cur_B CURSOR FOR a_id2;
            $OPEN cur_B USING $ipolicy;
            for(;;) {
               $FETCH cur_B
                 INTO $iendorse,$dply_begin,$ibrand,$ibig_sales,
                      $iissue_ym,$ipro_year,$mprem1,$mdisc1,$magent1,
                      $iassured1,$iassured2,$dedr_close;
               if (SQLCODE == SQLNOTFOUND) break;
            
               if (strncmp(dedr_close," ",1)==0) {
                  mprem     -= mprem1;
                  mdiscount -= mdisc1;
                  magent    -= magent1;
               }
               else {
                  mprem_edr  += mprem1;
                  mdisc_edr  += mdisc1;
                  magent_edr += magent;
               }
               mprem1=medr_exp=0;
               sprintf_s(stmt3, sizeof stmt3,
                  "select medrins_prem,medr_expense from %s:edr_ins_type  "
                   "where iendorse = ? and iins_type = '09'  "
                   "  and iedr_type != '02' ",list[j].dbname);
               $prepare pre_BB from $stmt3; 
               $execute pre_BB into $mprem1,$medr_exp 
                              using $iendorse;
               medr_09 += mprem1;
               mexp_09 += medr_exp;
            }
            $CLOSE cur_B;
         }
         if (strcmp(trim(iins_type),"09")==0) 
         {
            mprem_09 = mprem - mexpense;
            if (abs(tmp_safe) < DBL_MAX)
            	rSafe_09 = tmp_safe;
            else
            	rSafe_09 = DBL_MAX;
            	
            if (abs(tmp_manage) < DBL_MAX)
            	rMgmt_09 = tmp_manage;
            else
            	rMgmt_09 = DBL_MAX;
         }
      	 else
      	 {
            mprem_09 = mprem - mprem_edr + medr_09 - medr_exp;         
         }
         $SELECT nname
            INTO $ibig_office_c
            FROM officer
           WHERE iofficer = $iofficer;
         if(SQLCODE == SQLNOTFOUND) {
           strcpy(ibig_office_c,ibig_office);
         }

         $select nname[1,10]
            into $nsales
            from ca_big_office
           where fclass = '2'
             and ibig_comp = $ibig_sales;
         if (SQLCODE==SQLNOTFOUND)
            strcpy(nsales," ");
 
         if (strlen(trim(iassured1)) == 0 && strlen(trim(iassured2))==0)
            iassured[0] ='\0';
         else {
            strcpy(iassured,rtrim(iassured1));
            strcat(iassured,rtrim(iassured2));  }

         sprintf_s(stmt, sizeof stmt,"SELECT nbrand_abbr,nbrand,ipro_year "
                     "FROM ca_car_model  "
                     "WHERE ibrand = ? "
                     "ORDER BY ipro_year ");
         $PREPARE B_id FROM $stmt;
         $DECLARE curBX CURSOR FOR B_id;
         $OPEN curBX USING $ibrand;
         $FETCH curBX INTO $nbrand_abbr,$nbrand,$ipro_year;
         if(SQLCODE == SQLNOTFOUND)
           {nbrand_abbr[0]='\0';
            nbrand[0]='\0'; }
         $CLOSE curBX;

         $SELECT nbranch INTO $Ngroup
            FROM sa_branch_type
           WHERE ibranch = $iquota;
         if(SQLCODE ==SQLNOTFOUND) Ngroup[0]='\0';

         print_car6266_body1();

       }
       $CLOSE cur_A;
    } 
    $FREE  cur_A;
    $FREE  cur_B;
    $FREE  cur_BX;

    return M_CM_OK;
   
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE; 
}
/*--------------------------------------------------------------------*/
long car6266_body2()
{
 int   j;
 $char stmt1[1024],stmt[1024],stmt2[512];

 $WHENEVER SQLERROR GOTO errexit;

 rgu_put_body_string(1,"���P���"   ,1);
 rgu_put_body_string(1,cm_get_sysd(),1);
 rgu_put_body_string(1,dbgn1,1);
 rgu_put_body_string(1,dend1,1);
 rgu_put_body(1);
 max_cnt = 6;

 if (strncmp(fply_close,"1",1)==0) 
     strcpy(stmt2," AND a.dedr_close is not null ");
 else
     strcpy(stmt2," ");

 for(j=0;j<count_db;j++) {
      sprintf_s(stmt, sizeof stmt,
             "SELECT a.ipolicy,a.icard,b.dply_begin,a.ibrand, "
             "to_char(b.dissue,'%%Y')::integer - 1911 || '/' || to_char(b.dissue,'%%m'), "
             "a.ibig_office,a.iquota[1,4]||'00',a.dendorse, "
             "a.ipro_year,medrdmg_prem+medrlia_prem, "
             "medrdmg_agent+medrlia_agent,medrdmg_disc+medrlia_disc, "
             "b.iassured,b.iassured_ext,b.nassured[1,24],b.iapplicant,b.napplicant[1,24], "
             "b.iengine,b.itag,a.dendorse,a.ibig_sales,c.dpolicy,a.iendorse,  "
             "a.iofficer  "
             "FROM %s:edr_relation a, %s:endorsement b,  "
             "     %s:ply_relation c  "
             "WHERE a.dendorse>= ? AND a.dendorse<= ? %s  "
             "AND a.iendorse = b.iendorse  "
             "AND a.ipolicy = c.ipolicy  "
             "AND a.fedr_class = '1'  "
             "AND a.iofficer[1,3] in ('F98','G98')",
             list[j].dbname,list[j].dbname,list[j].dbname,stmt2);

      $PREPARE a_id3 FROM $stmt;
      $DECLARE cur_C CURSOR FOR a_id3;
      $OPEN cur_C USING $dbgn_inf,$dend_inf;
      for(;;) {
         mprem=magent=mdiscount=mprem_09=mprem_edr=mdisc_edr=0; 
         magent_edr=mprem1=mdisc1=magent1=0;
         
         
         $FETCH cur_C
           INTO $ipolicy,$icard,$dply_begin,$ibrand,$iissue_ym,
                $ibig_office,$iquota,$dpolicy,$ipro_year,
                $mprem,$magent,$mdiscount,
                $iassured1,$iassured2,$nassured,$iapplicant,$napplicant,$iengine,
                $itag,$dendorse,$ibig_sales,$ori_dpolicy,
                $iendorse,$iofficer;
         if (SQLCODE == SQLNOTFOUND) break;

         $SELECT nname
            INTO $ibig_office_c
            FROM officer
           WHERE iofficer = $iofficer;
         if(SQLCODE == SQLNOTFOUND)
            strcpy(ibig_office_c,ibig_office);

         $select nname[1,10]
            into $nsales
            from ca_big_office
           where fclass = '2'
             and ibig_comp = $ibig_sales;
         if (SQLCODE==SQLNOTFOUND)
            strcpy(nsales," ");

         if (strlen(trim(iassured1)) == 0 && strlen(trim(iassured2))==0)
               iassured[0] ='\0';
         else
          { strcpy(iassured,rtrim(iassured1));
            strcat(iassured,rtrim(iassured2));  }

         sprintf_s(stmt, sizeof stmt,"SELECT nbrand_abbr,nbrand,ipro_year "
                     "FROM ca_car_model  "
                     "WHERE ibrand = ? "
                     "ORDER BY ipro_year ");
         $PREPARE B_id FROM $stmt;
         $DECLARE curBXQ CURSOR FOR B_id;
         $OPEN curBXQ USING $ibrand;
         $FETCH curBXQ INTO $nbrand_abbr,$nbrand,$ipro_year;
         if(SQLCODE == SQLNOTFOUND)
           {nbrand_abbr[0]='\0';
            nbrand[0]='\0'; }
         $CLOSE curBXQ;

         $SELECT nbranch INTO $Ngroup
            FROM sa_branch_type
           WHERE ibranch = $iquota;
         if(SQLCODE ==SQLNOTFOUND) Ngroup[0]='\0';                  

         print_car6266_body2();

      }
      $CLOSE cur_C;
    }
    $FREE cur_C;
    $FREE  curBXQ;

    return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
void print_car6266_body1()
{ char str[12],str1[8];

  rgu_put_body_string(2,iquota,LEFT);
  rgu_put_body_string(2,trim(Ngroup),LEFT);
  rgu_put_body_string(2,icard,LEFT);
  rgu_put_body_string(2,ipolicy,LEFT);
  rgu_put_body_string(2,iendorse,LEFT);
  rgu_put_body_string(2,iassured,LEFT);
  rgu_put_body_string(2,nassured,LEFT);
  rgu_put_body_string(2,iapplicant,LEFT);
  rgu_put_body_string(2,napplicant,LEFT);
  rgu_put_body_string(2,dpolicy,LEFT);
  rgu_put_body_string(2,dply_begin,LEFT);
  rgu_put_body_string(2,ibrand,LEFT);
  rgu_put_body_string(2,nbrand_abbr,LEFT);
  rgu_put_body_string(2,nbrand,LEFT);
  rgu_put_body_string(2,iengine,LEFT);
  rgu_put_body_string(2,iissue_ym,LEFT);
  rgu_put_body_string(2,itag,LEFT);
  rgu_put_body_string(2,ibig_office,LEFT);
  rgu_put_body_string(2,ibig_office_c,LEFT);
  rgu_put_body_string(2,ibig_sales,LEFT);
  rgu_put_body_string(2,nsales,LEFT);
  rfmtlong(mprem_09,"---------&",str);
  rgu_put_body_string(2,str,LEFT);
  rfmtlong(mdiscount,"-------&",str1);
  rgu_put_body_string(2,str1,LEFT);
  if (mprem_09==0)
     pdiscount = 0;
  else if(mprem_09 != 0 || mdiscount != 0)
     pdiscount = (double) mdiscount / (mprem_09+mdiscount) * 100 + 0.5;
  rfmtlong(pdiscount,"--&",str);
  rgu_put_body_string(2,str,LEFT);
  rfmtlong(magent,"-------&",str1);
  rgu_put_body_string(2,str1,LEFT);
  if (mprem_edr==0)
     pdiscount = 0;
  else if (mprem_edr != 0)
     pdiscount = (double) magent / (double) mprem_edr * 100 + 0.5;
  rfmtlong(pdiscount,"--&",str);
  rgu_put_body_string(2,str,LEFT);
  rfmtlong(mprem,"---------&",str);
  rgu_put_body_string(2,str,LEFT);
  rgu_put_body_string(2," ",LEFT);
  
  strcpy(iins_type, trim(iins_type));
  rgu_put_body_string(2,iins_type,LEFT);
  
  /* �w��/�޲z���I�[��T�� */
  	rfmtdouble(rSafe_09,"-&&.&&&&&&&",str);
   rgu_put_body_string(2,str,2);   
  	rfmtdouble(rMgmt_09,"-&&.&&&&&&&",str);
   rgu_put_body_string(2,str,2);
    
  rgu_put_body(2);
  max_cnt++;

}
/*--------------------------------------------------------------------*/
void print_car6266_body2()
{ char str[12],str1[8];

  rgu_put_body_string(2,iquota,LEFT);
  rgu_put_body_string(2,trim(Ngroup),LEFT);
  rgu_put_body_string(2,icard,LEFT);
  rgu_put_body_string(2,ipolicy,LEFT);
  rgu_put_body_string(2,iendorse,LEFT);
  rgu_put_body_string(2,iassured,LEFT);
  rgu_put_body_string(2,nassured,LEFT);
  rgu_put_body_string(2,iapplicant,LEFT);
  rgu_put_body_string(2,napplicant,LEFT);
  rgu_put_body_string(2,dpolicy,LEFT);
  rgu_put_body_string(2,dply_begin,LEFT);
  rgu_put_body_string(2,ibrand,LEFT);
  rgu_put_body_string(2,nbrand_abbr,LEFT);
  rgu_put_body_string(2,nbrand,LEFT);
  rgu_put_body_string(2,iengine,LEFT);
  rgu_put_body_string(2,iissue_ym,LEFT);
  rgu_put_body_string(2,itag,LEFT);
  rgu_put_body_string(2,ibig_office,LEFT);
  rgu_put_body_string(2,ibig_office_c,LEFT);
  rgu_put_body_string(2,ibig_sales,LEFT);
  rgu_put_body_string(2,nsales,LEFT);
  rgu_put_body_string(2," ",LEFT);
  rfmtlong(mdiscount,"-------&",str1);
  rgu_put_body_string(2,str1,LEFT);
  if (mprem==0 || mdiscount==0)
     pdiscount = 0;
  else if (mprem != 0 || mdiscount != 0)
     pdiscount = (double) mdiscount / (mprem+mdiscount) * 100 + 0.5;
  rfmtlong(pdiscount,"--&",str);
  rgu_put_body_string(2,str,LEFT);
  rfmtlong(magent,"-------&",str1);
  rgu_put_body_string(2,str1,LEFT);
  if (mprem==0 || magent==0)
     pdiscount = 0;
  else if (mprem != 0 || magent != 0)
     pdiscount = (double) magent / (mprem+mdiscount) * 100 + 0.5;
  rfmtlong(pdiscount,"--&",str);
  rgu_put_body_string(2,str,LEFT);
  rfmtlong(mprem,"---------&",str);
  rgu_put_body_string(2,str,LEFT);
  rgu_put_body_string(2,ori_dpolicy,LEFT);
  rgu_put_body_string(2," ",LEFT);
  
  /* �w��/�޲z���I�[��T��,���P�L����� */
  	rgu_put_body_string(2," ",LEFT);
  	rgu_put_body_string(2," ",LEFT);
   
  rgu_put_body(2);
  max_cnt++;

}
/*--------------------------------------------------------------------*/
void car6266_title()
{
   rgu_put_head();
}
/*--------------------------------------------------------------------*/
