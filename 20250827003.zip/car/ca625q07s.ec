/**********************************************************************/
/*   program id   : ca625q07s.ec                                      */
/*   program name : ���ثP�P�M�׸�Ƥ��@�~                          */
/*   date written : 2006/03/24                                        */
/*   date modify  : yyyy/mm/dd                                        */
/*   files        : ply_relation        i                             */
/*                  ply_ins_type        i                             */
/*                  policy              i                             */
/*   temp table   : car6257             io                            */
/*   Checked for ����100�~�M��                                        */
/**********************************************************************/
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
#include "car_equip.h"

/*--------------------------------------------------------------------*/
$char   h_dbgn[11],h_dend[11];
$char   icd[2][21],iply[2][21],icard[21],ipolicy[21],ibig_office_w[10];
$char   ibigo[2][11];
$char   ibig_sales[11],itag[CA_TAG_NUM],ibrand[9],iengine[21],ibig_office[10];
$char   nassured[121],iassured[13],dpolicy[11],iissue_ym[7];
$char   iofficer[11],iresource[2],iins_type[INSURANCE_TYPE],nofficer[11],fedr_class[2];
$char   ioff[2][11],noff[2][11],ires[2],icomp[4],ncomp[9],nbig_office[11];
$char   nbrand[31],iquota[10],nquota[21],fcard_class[2];
$char   iply1[21],iply2[21],nsales[11],ipro_year[5],icar_type[3];
$char   dbgn1[11],dend1[11],remark[41],ncar_abbr[13];
$char   remark1[2],remark2[2],remark3[2],nremark[91];
$char   dbgn2[11],dend2[11],dply_begin[11],ibus_location[2];
$char   iply_comp[21],icd_comp[21],ncode[21];
$long   mprem_dmg,mprem_11,mprem_17,mprem_oth,mlia_prem;
$long   mprem_51,mprem_51_1;
$long   mprem_31,mprem_31_1;
$long   mprem_01,mprem_01_1;
$long   mprem_09,mprem_09_1;
$long   mprem_upg, mprem_upg_1;
$long   mprem_11_1,mprem_17_1,mprem_oth_1;   
$long   mprem_21,mprem,mprem_21d;
$long   mexpense, mprem_dmg, mprem_dmg1, medr_dmg;
$long   medr_09, medr_exp, mprem1, mexp_09;
$char   napplicant[121],iapplicant[13];
$double rSafe_11, rSafe_17, rSafe_31, rSafe_51, rSafe_oth, rSafe_09;
$double rMgmt_11, rMgmt_17, rMgmt_31, rMgmt_51, rMgmt_oth, rMgmt_09;
$double tmp_safe=0,tmp_manage=0;

$char   dendorse[13], iendorse[21], stmt3[500], dedr_close[20];

$int    x,flag_11,x_cnt,cnt_comp;
int     iins,iclass,fcomp;
$char   nprmt[31],iofficer_1[2],ioff_chk[11],iagent[11];
$char   dprmt_bgn[11],dprmt_end[11],iprmt[11];
$char   fanother[2],ioff_chka[11],iofficera_1[2];
$int    lofficer,iremark,ioff_chk_bgn,ioff_chk_len,ioff_chk_lena;
$int    lofficera,ioff_chk_bgna;
$int    qfield_all,qfield_chk;

$char   sdata[30][41],dbase[40];
$long   mprice;

int     flen,cnt;
int     cnt_s,cnt_f;
FILE    *fp;
char    sApHome[30];
$char   fname[21];
char    filename[50],fulldb[21];

$char   DBName[05], iForm_Tp[03];
char    BodyFile[ N_FILE+1];
char    TitleFile[ N_FILE+1]; 
char    outputf[N_FILE+1], userid[11];

char    msgbuf[100];
$int    ItemRow, TotColumn;
$int    StartRow,TitleRow;
$int    PgLine, Width;

static int  max_cnt,num;
int     iTmpCode;
/*--------------------------------------------------------------------*/

car6257(DBName1,userid1,iprmt1,dbgn1,dend1,checkD,outputf1)
$char *DBName1,*userid1,*iprmt1,*dbgn1,*dend1,*checkD,*outputf1;
{  
   int rc;

   printf("dbname[%s]userid[%s]output[%s]checkD[%s]\n",
         DBName,userid,outputf,checkD);

   strcpy(DBName, DBName1);
   strcpy(userid, userid1);
   strcpy(iprmt,  iprmt1);
   strcpy(outputf,outputf1);
   strcpy(h_dbgn, dbgn1);
   strcpy(h_dend, dend1);

   rc = car6257_get_db();
   if (rc != SUCCESS) {
      EWRITE(userid,rc,msgbuf);
      return rc;
   }

   rc = car6257_read_prmt();
   if (rc != SUCCESS) {
      EWRITE(userid,rc,msgbuf);
      return rc;
   }

   rc = car6257_build();
   if (rc != SUCCESS) {
      EWRITE(userid,rc,msgbuf);
      return rc;
   }

   rc = car6257_build1();
   if (rc != SUCCESS) {
      EWRITE(userid,rc,msgbuf);
      return rc;
   }

   rc = car6257_build2();
   if (rc != SUCCESS) {
      EWRITE(userid,rc,msgbuf);
      return rc;
   }

   if (checkD[0]=='1') {
      rc = car6257_build3();
      if (rc != SUCCESS) {
         EWRITE(userid,rc,msgbuf);
         return rc;
      }
   }

   return rc;
}
/*--------------------------------------------------------------------*/
long car6257_get_db()
{
   int  rc;

   if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }

   rc = getApHome(sApHome);
   if (rc < 0) {
       strcpy(msgbuf,"read Config file error!!-->getApHome\n");
       EWRITE(userid,rc,msgbuf);
       return rc;
    }

   return SUCCESS;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car6257_read_prmt()
{
   int  rc;
   $char stmt[512];

   $select nprmt,iofficer_1,lofficer,iremark,ioff_chk_bgn,
           ioff_chk_len,ioff_chk,iagent,qfield_all,qfield_chk,
           dprmt_bgn,dprmt_end,fanother,ioff_chka,ioff_chk_lena,
           iofficera_1,lofficera,ioff_chk_bgna
      into $nprmt,$iofficer_1,$lofficer,$iremark,$ioff_chk_bgn,
           $ioff_chk_len,$ioff_chk,$iagent,$qfield_all,$qfield_chk,
           $dprmt_bgn,$dprmt_end,$fanother,$ioff_chka,$ioff_chk_lena,
           $iofficera_1,$lofficera,$ioff_chk_bgna
      from ca_promote
     where iprmt = $iprmt;
printf("fanother[%s]\n",fanother);

   if (SQLCODE==SQLNOTFOUND) {
      strcpy(msgbuf,"�d�L�M�׸��");
      return SQLCODE;
   }
    
   strcpy(stmt,
           "select '[' || trim(ncode) || ']' from cu_code_data \
            where itype = '25' and icode = ? ");
   $prepare pre_code from $stmt;

   return SUCCESS;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car6257_build()
{
   char   sfilename[101],stitle[1024],stmt[1024];
   int    rc;
   
   $whenever sqlerror goto errexit;

   rc = car6257_read_file();
   if (rc != SUCCESS)
      return rc;

   sprintf(sfilename,"%s�M�׸�Ƥ��@�~--��異��[%s]",
                     rtrim(nprmt),cm_get_sysd());
   strcpy(stitle," ");
   strcpy(stmt,"select * from car6257_tmp");
   unload_file(outputf,"A",sfilename,stitle,stmt);
   if (rc != SUCCESS) {
      sprintf(msgbuf," %s �ɮ׵L�k���� ",sfilename);
      return rc;
   }

   return SUCCESS;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car6257_build1()
{
   char   sfilename[101],stitle[1024],stmt[2048];
   int    rc;
   
   $whenever sqlerror goto errexit;

   sprintf(sfilename,"%s�M�׸�Ƥ��@�~--���ݢ�[%s]",
                     rtrim(nprmt),cm_get_sysd());
   strcpy(stitle,
         "���N�X\t�~�Z���\t�g�P��\t�O�d���X�@\t�O�渹�X�@\t�O�d���X�G\t\
�O�渹�X�G\t�Q�O�I�H�N��\t�Q�O�I�H�W��\t�n�O�HID\t�n�O�H�m�W\tñ����\t�_�O���\t���إN�X\t\
���ئW��\t�t���N��\t�t�P�����W��\t�������X\t�o�Ӧ~��\t�g��N��1\t���I�N��1\t\
���I�W��1\t�g��N��2\t���I�N��2\t���I�W��2\t�~�N�N�� \t�~�N�W��\t�P�Ӹ��X\t\
���������I�O�O\t����ɯūO�O\t�ѵs�I�O�O\t�ѧK��O�O\t�d���I�O�O\t�����I�O�O\t��L���N�I�O�O\t�j���I�O�O\t\
���N����\t�j��O�渹\t�j���Ҹ�\t�j���\t\
���������I�w�����I�[��T��\t�ѵs�I�w�����I�[��T��\t�ѧK��w�����I�[��T��\t\
�d���I�w�����I�[��T��\t�����I�w�����I�[��T��\t��L���N�I�w�����I�[��T��\t\
���������I�޲z���I�[��T��\t�ѵs�I�޲z���I�[��T��\t�ѧK��޲z���I�[��T��\t\
�d���I�޲z���I�[��T��\t�����I�޲z���I�[��T��\t��L���N�I�޲z���I�[��T��\t");
   strcpy(stmt,
     "select iquota,(select nvl(nbranch,' ') from sa_branch_type where \
             ibranch=iquota), ibus_loc, \
             icard1,ipolicy1,icard2,ipolicy2,iassured,\
             nassured,iapplicant,napplicant,dpolicy,dply_begin,icar_type,ncar_abbr,\
             ibrand,(select nvl(ncode,' ') from cm_group \
             where igroup = '04' and ilevel = 0 and icode = ibrand), \
             iengine,iissue_ym,    iofficer1,ibig_office1,\
             decode(ibig_office1,' ',' ',(select nvl(nname,' ') from \
             officer where ibus_location =ibig_office1 and \
             iofficer[1]= ibus_loc)),\
             iofficer2,ibig_office2,(select nvl(nname,' ') from officer \
             where iofficer = iofficer2), ibig_sales,\
             (select nvl(nname,' ') from ca_big_office \
             where fclass = '2' and ibig_comp=a.ibig_sales),\
             itag,mprem_09, mprem_upg,mprem_11,mprem_17,mprem_31,\
             mprem_51,mprem_oth,mprem_21,ply_cnt,iply_comp,icd_comp,cnt_comp,\
             rSafe_09,rSafe_11,rSafe_17,rSafe_31,rSafe_51,rSafe_oth,\
             rMgmt_09,rMgmt_11,rMgmt_17,rMgmt_31,rMgmt_51,rMgmt_oth \
      from car6257 a order by 1,3,4");

   unload_file(outputf,"B",sfilename,stitle,stmt);
   if (rc != SUCCESS) {
       sprintf(msgbuf," %s �ɮ׵L�k���� ",sfilename);
       return rc;
   }

   return SUCCESS;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car6257_build2()
{
   char   sfilename[101],stitle[1024],stmt[2048];
   int    rc;
   $int   cnt;
   
   $whenever sqlerror goto errexit;

   sprintf(sfilename,"%s�M�׸�Ƥ��@�~--�дک���[%s]",
                     rtrim(nprmt),cm_get_sysd());
   strcpy(stitle,
        "���N��\t�~�Z���\t�g�P��\t�j����N�O\t�O�d���X\t�O�渹�X\t\
�Q�O�I�H�N��\t�Q�O�I�H�W��\t�n�O�HID\t�n�O�H�m�W\tñ����\t�_�O���\t���إN�X\t���ئW��\t\
�t���N��\t�t�P�����W��\t�������X\t�o�Ӧ~��\t�g��N��\t���I�N��\t���I�W��\t\
�~�N�N��\t�~�N�W��\t�P�Ӹ��X\t���������I�O�O\t�����I�ɯūO�O\t�ѵs�I�O�O\t\
�ѧK��O�O\t�d���I�O�O\t�����I�O�O\t��L���N�I�O�O\t�j���I�O�O\t�O�浧��\t���O\t\
���������I�w�����I�[��T��\t�ѵs�I�w�����I�[��T��\t�ѧK��w�����I�[��T��\t\
�d���I�w�����I�[��T��\t�����I�w�����I�[��T��\t��L���N�I�w�����I�[��T��\t\
���������I�޲z���I�[��T��\t�ѵs�I�޲z���I�[��T��\t�ѧK��޲z���I�[��T��\t\
�d���I�޲z���I�[��T��\t�����I�޲z���I�[��T��\t��L���N�I�޲z���I�[��T��\t");
   strcpy(stmt,
   "select iquota,(select nbranch from sa_branch_type where ibranch = iquota),\
    ibus_loc,fcard_class,icard,ipolicy,iassured,nassured,\
    iapplicant,napplicant,dpolicy,dply_begin,icar_type,\
    ncar_abbr,ibrand,(select nvl(ncode,' ') from cm_group where igroup = '04' \
    and icode = ibrand),iengine,iissue_ym,iofficer,ibig_office,\
    decode(ibig_office,' ',(select nname from officer where iofficer = \
    a.iofficer),(select nvl(nname,ibus_location) from officer where \
    ibus_location = ibig_office group by 1)),ibig_sales,(select nvl(nname,' ') from \
    ca_big_office where fclass = '2' and ibig_comp=a.ibig_sales),itag, \
    mprem_09,mprem_upg, mprem_11,mprem_17,mprem_31,mprem_51,mprem_oth,\
    mprem_21,ply_cnt,remark,rSafe_09,rSafe_11,rSafe_17,rSafe_31,rSafe_51,rSafe_oth, \
    rMgmt_09,rMgmt_11,rMgmt_17,rMgmt_31,rMgmt_51,rMgmt_oth \
    from car6257_1 a where fcard_class = '2' order by 1,3,7,4");

   unload_file(outputf,"C",sfilename,stitle,stmt);
   if (rc != SUCCESS) {
       sprintf(msgbuf," %s �ɮ׵L�k���� ",sfilename);
       return rc;
   }
   return SUCCESS;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car6257_build3()
{
   char   sfilename[101],stitle[1024],stmt[2048];
   int    rc;
   
   $whenever sqlerror goto errexit;
   rc = car6257_body3();
   if (rc != SUCCESS)
      return rc;

   sprintf(stitle,"%s�M�׸�Ƥ��@�~--�g�P���q�L���[%s]",
           rtrim(nprmt),cm_get_sysd());
   strcpy(stitle,
         "���N�X\t�~�Z���\t�g�P��\t�O�d���X�@\t�O�渹�X�@\t�Q�O�I�H�N��\t�Q�O�I�H�W��\t\
ñ����\t�_�O���\t���إN�X\t\
���ئW��\t�t���N��\t�t�P�����W��\t�������X\t�o�Ӧ~��\t�g��N��\t���I�N��1\t���I�W��1\t\
�~�N�N�� \t�~�N�W��\t�P�Ӹ��X\t���N�I�O�O\t���N����");
   strcpy(stmt,"select * from car6257_2");
   unload_file(outputf,"D",sfilename,stitle,stmt);
   if (rc != SUCCESS) {
       sprintf(msgbuf," %s �ɮ׵L�k���� ",sfilename);
       return rc;
   }
   return SUCCESS;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car6257_read_ply()
{
   int    first,rc,y,fcomp_only;
   $char  stmt[1024],stmt1[512],iofficerx[11],stmtdt[81],iofficery[11];
   $char  edr_iins_type[INSURANCE_TYPE];

   $whenever sqlerror goto errexit;

   if (h_dbgn[0]=='*')
      strcpy(stmtdt," ");
   else
      sprintf(stmtdt,"and dpolicy between '%s' and '%s' ",h_dbgn,h_dend);

   $declare cur_vs cursor for
     select ipolicy,icard,iassured,itag,fcard_class,nassured
       into $ipolicy,$icard,$iassured,$itag,$fcard_class,$nassured
       from assured_vs_ply
      where iengine = $iengine
      order by fcard_class,ipolicy;
   $open cur_vs;
   x=0;
   first=1;
   cnt_comp=0;
   fcomp_only=1;
   for (y=0;y<2;y++) {
       strcpy(icd[y]," ");
       strcpy(iply[y]," ");
       strcpy(ioff[y]," ");
       strcpy(ibigo[y]," ");
   }
   strcpy(iply_comp," ");
   strcpy(icd_comp," ");
   strcpy(ibig_office_w," ");
   while(1) {
      $fetch cur_vs;
      if (SQLCODE==SQLNOTFOUND) {
         if (first) {
            rc=car6257_body();
            if (rc!=SUCCESS)
                return rc;
            first=0;
            break;
         }
         else { 
            if (fcomp_only) {
               rc=car6257_write_comp();
               if (rc!=SUCCESS)
                  return rc;
               break;
            }
            else {
               rc=car6257_write_data();
               if (rc!=SUCCESS)
                  return rc;
               break;
            }
         } 
      }
      printf("ipolicy[%s]\n",ipolicy);
      if (first) {
         mprem_dmg=mprem_11=mprem_17=mprem_oth=0;
         mprem_21=0;
         mprem_51=0;
         mprem_31=0;
         mprem_01=0;
         mprem_09=0;
         medr_dmg=0;
         x_cnt=0;
      }  
      strcpy(fulldb,get_car_full_db(ipolicy));
      iclass=atoi(fcard_class);
         mprem_21d=mprem_11_1=mprem_17_1=mprem_oth_1=flag_11=0;
         mprem_51_1=mprem_31_1=mprem_01_1=mprem_09_1=mprem_upg_1=0;
         medr_dmg=mprem_upg=0;
         sprintf(stmt,
                "select iquota[1,4] || '00',dpolicy,dply_begin,ibrand, \
                        to_char(b.dissue,'%%Y')::integer - 1911 || '/' || to_char(b.dissue,'%%m'), \
                        iofficer,ibig_sales,fedr_class, \
                        nequipment,ibig_office,mlia_prem,icar_type,\
                        (select ncode from car_type where fclass = '1' \
                        and icode = icar_type),dendorse,iapplicant,napplicant[1,40] \
                   from %s:ply_relation a,%s:policy b \
                  where a.ipolicy = ? %s\
                    and a.ipolicy = b.ipolicy ",fulldb,fulldb,stmtdt); 
         $prepare pre_2 from $stmt;
         $execute pre_2 into $iquota,$dpolicy,$dply_begin,$ibrand,
                        $iissue_ym,$iofficer,$ibig_sales,$fedr_class,
                        $remark,$ibig_office,$mlia_prem,$icar_type,
                        $ncar_abbr,$dendorse,$iapplicant,$napplicant
                  using $ipolicy;
         if (SQLCODE==SQLNOTFOUND) continue;
         if (first) first=0;
         if (strncmp(fedr_class,"1",1)==0) continue;
         strcpy(iofficerx,substring(iofficer,ioff_chk_bgn,ioff_chk_len));
         if (strncmp(fanother,"Y",1)==0)
             strcpy(iofficery,substring(iofficer,ioff_chk_bgna,ioff_chk_lena));
         if (iclass==1) {
         mprem_21 += mlia_prem;
         mprem_21d = mlia_prem;
         strcpy(iply_comp,ipolicy);
         strcpy(icd_comp,icard);
         cnt_comp++;
         rc=car6257_write_data_1();
         if (rc!=SUCCESS)
            return rc;  
         continue;
         }
         fcomp_only=0;
         if (strncmp(iofficer,iofficer_1,1) == 0 &&
             strncmp(iofficerx,ioff_chk,ioff_chk_len)==0) {
            strcpy(iply[0],ipolicy);
            strcpy(icd[0],icard);
            strcpy(ioff[0],iofficer);
            strcpy(ires,trim(iresource));
            strcpy(ibigo[0],ibig_office);
            strcpy(ibig_office_w,ibig_office);
         }
         else {
            if (strncmp(fanother,"Y",1)==0 &&
                strncmp(iofficer,iofficera_1,1) == 0 &&
                strncmp(iofficery,ioff_chka,ioff_chk_lena)==0) {
               strcpy(iply[0],ipolicy);
               strcpy(icd[0],icard);
               strcpy(ioff[0],iofficer);
               strcpy(ires,trim(iresource));
               strcpy(ibigo[0],ibig_office);
               strcpy(ibig_office_w,ibig_office);
            }
            else {
            if (x<2) {
               strcpy(iply[1],ipolicy);
               strcpy(icd[1],icard);
               strcpy(ioff[1],iofficer);
               strcpy(ibigo[1],ibig_office);
            }
            }
         }
         x++;
         sprintf(stmt1,
                "select iins_type,mins_premium,safe_rate,manage_rate \
                   from %s:ply_ins_type \
                  where ipolicy = ? ",fulldb);
         $prepare pre_2d from $stmt1;
         $declare cur_2d cursor for pre_2d;
         $open    cur_2d using $ipolicy;
         while(1) {
            $fetch cur_2d into $iins_type,$mprem,$tmp_safe,$tmp_manage;
            if (SQLCODE==SQLNOTFOUND) {
               
               mprem_dmg = mprem_01;
               /*-- �p������O�O --*/
               sprintf(stmt1,"select iins_type,mexpense from %s:ply_ins_type \
                               where ipolicy = ? and mdamage_cover != 0 \
                                 and iins_type in ('01','05','08','09') ", fulldb);
                
               $prepare a_id11 from $stmt1;
               $declare cur_A1 cursor for a_id11;
               $open cur_A1 using $ipolicy;
               $fetch cur_A1 into $iins_type,$mexpense;
               if (SQLCODE == SQLNOTFOUND) strcpy(iins_type,"00");
               $close cur_A1;
                
               medr_dmg=medr_09=medr_exp=0;
    
               strcpy(iendorse," ");
               if (strncmp(dendorse," ",1)!=0) {
                   sprintf(stmt1,
                          "SELECT a.iendorse, b.medrins_prem, nvl(dedr_close,' '), b.iins_type\
                            FROM %s:edr_relation a,%s:edr_ins_type b\
                           WHERE ipolicy = ? \
                             AND dendorse is not null \
                             AND b.iins_type in ('01','05','08','09') \
                             AND a.iendorse = b.iendorse",fulldb,fulldb);
                   printf("stmt1[%s]\n",stmt1);
                   $PREPARE a_id2 FROM $stmt1;
                   $DECLARE cur_B CURSOR FOR a_id2;
                   $OPEN cur_B USING $ipolicy;
                   for(;;) {
                      mprem_dmg1=0;
                      $FETCH cur_B
                        INTO $iendorse, $mprem_dmg1, $dedr_close, $edr_iins_type;
                      if (SQLCODE == SQLNOTFOUND) break;
                      printf("iendorse[%s] mprem_dmg1=[%d]\n",iendorse, mprem_dmg1);
                      if (strncmp(dedr_close," ",1)==0) {
                         mprem_dmg -= mprem_dmg1;
                      }
                      else {
                         medr_dmg   += mprem_dmg1;
                      }
                      
                      printf("medr_dmg=[%d]\n", medr_dmg );
                      
                      if( strcmp(trim(edr_iins_type),"09") == 0 )
                      {
                          mprem1=medr_exp=0;
                          sprintf(stmt3,
                             "select medrins_prem,medr_expense from %s:edr_ins_type \
                               where iendorse = ? and iins_type = '09' \
                                 and iedr_type != '02' ",fulldb);
                          $prepare pre_BB from $stmt3; 
                          $execute pre_BB into $mprem1,$medr_exp 
                                         using $iendorse;
                          medr_09 += mprem1;
                          mexp_09 += medr_exp;
                      }
                   }
                   $CLOSE cur_B;
               }
                
               printf("iins_type=[%s] mprem_dmg=[%d] medr_dmg=[%d] medr_09=[%d] medr_exp=[%d]\n\n",
                        iins_type, mprem_dmg , medr_dmg , medr_09 , medr_exp);
                        
               if (strcmp(trim(iins_type),"09")==0) 
                   mprem_09_1 = mprem_dmg - mexpense;
               else if (strcmp(trim(iins_type),"00") !=0 )
                   mprem_09_1 = mprem_dmg - medr_dmg + medr_09 - medr_exp;
                
               printf("mprem_09=[%d] mprem_09_1=[%d]\n\n", mprem_09, mprem_09_1 );
                
               mprem_upg_1 = mprem_01 - mprem_09_1;
               
               mprem_09 += mprem_09_1;
               mprem_upg += mprem_upg_1;
               
               printf("mprem_09=[%d] mprem_09_1=[%d]\n\n", mprem_09, mprem_09_1 );
               
               if (strncmp(iofficer,iofficer_1,1) == 0 &&
                     strncmp(iofficerx,ioff_chk,ioff_chk_len)==0 &&
                     strlen(trim(iofficer))==lofficer) {
                    x_cnt++;
                    rc=car6257_write_data_1();
                    if (rc!=SUCCESS)
                       return rc;
               }
               if (fanother[0]=='Y') {
                 if (strncmp(iofficer,iofficera_1,1) == 0 &&
                     strncmp(iofficery,ioff_chka,ioff_chk_lena)==0 &&
                     strlen(trim(iofficer))==lofficera) {
                    x_cnt++;
                    rc=car6257_write_data_1();
                    if (rc!=SUCCESS)
                       return rc;
                 }
               }
               
               break;
            }
            iins=atoi(iins_type);
            switch(iins) {
               case 1: case 5: case 8: case 9:
                  mprem_01 += mprem;
                  mprem_01_1 += mprem;
                  if (iins==9)
                  {
                  	rSafe_09 = tmp_safe;
                  	rMgmt_09 = tmp_manage;
                  }
                  break;
               case 11:
                  mprem_11 += mprem;
                  mprem_11_1 += mprem;
                  flag_11 = 1;
                  rSafe_11 = tmp_safe;
                  rMgmt_11 = tmp_manage;
                  break;
               case 17:
                  mprem_17   += mprem;
                  mprem_17_1 += mprem;
                  rSafe_17 = tmp_safe;
                  rMgmt_17 = tmp_manage;
                  break;
               case 31: case 32:
                  mprem_31   += mprem;
                  mprem_31_1 += mprem;
                  rSafe_31 = tmp_safe;
                  rMgmt_31 = tmp_manage;
                  break;
               case 51: case 55:
                  mprem_51   += mprem;
                  mprem_51_1 += mprem;
                  rSafe_51 = tmp_safe;
                  rMgmt_51 = tmp_manage;
               default:
                  mprem_oth += mprem;
                  mprem_oth_1 += mprem;
                  rSafe_oth = tmp_safe;
                  rMgmt_oth = tmp_manage;
                  break;
            }
         }
         $close cur_2d;
   }
   $close cur_vs;
   $free  cur_vs;
   return SUCCESS;
errexit:
   sqlfatal();
   strcpy(msgbuf,sqlca.sqlerrm);
   return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car6257_body()
{
int  x;
$char  stmt[2048];

  $whenever sqlerror goto errexit;

    strcpy(stmt,"insert into car6257_tmp values ( ");
    for(x=0;x<qfield_all-1;x++)
       sprintf(stmt,"%s '%s',",stmt,sdata[x]);
    sprintf(stmt,"%s '%s');",stmt,sdata[x]);
printf("insert_tmp[%s]\n",stmt);
    $prepare pre_tmp_i from $stmt;
    $execute pre_tmp_i;

    return SUCCESS;
errexit:
   sqlfatal();
   strcpy(msgbuf,sqlca.sqlerrm);
   return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car6257_body3()
{
DBinfo *list;
int    i,j,count_db,rc;
$int   cnt;
$char  stmt[1024],stmt1[1024],iofficero[11];

  $whenever sqlerror goto errexit;

  if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
     if (EWRITE(userid, M_CM_NOT_DBLIST) == True)
        return M_CM_NOT_DBLIST;
     return M_CM_OK;
  }

  printf("\n\n========== body3\n\n");

  for(j=0;j<count_db;j++) {
     sprintf(stmt,
     "select iquota,a.icard,a.ipolicy,iassured, \
             nassured,dpolicy,dply_begin,ibrand,iengine,iofficer, \
             ibig_sales,itag,mlia_prem + mdmg_prem,1,ibig_office, \
             icar_type,(select ncode from car_type where fclass = '1' \
             and icode = icar_type),\
             to_char(b.dissue,'%%Y')::integer - 1911 || '/' || to_char(b.dissue,'%%m'), \
             iapplicant,napplicant[1,40] \
        from %s:ply_relation a,%s:policy b \
       where dpolicy >= '%s' \
         and dpolicy <= '%s' \
         and fedr_class != '1' \
         and iofficer[1] = '%s' \
         and iofficer[%d,%d] = '%s' \
         and length(iofficer) = %d \
         and a.ipolicy = b.ipolicy ",list[j].dbname,list[j].dbname,
             dprmt_bgn,dprmt_end,iofficer_1,ioff_chk_bgn,
             ioff_chk_bgn+ioff_chk_len-1,ioff_chk,lofficer);
    printf("stmt=[%s]\n", stmt );

    $prepare pre_w from $stmt;
    $declare cur_w cursor for pre_w;
    $open cur_w;
    while(1) {
       $fetch cur_w
         into $iquota,$icard,$ipolicy,$iassured,
              $nassured,$dpolicy,$dply_begin,$ibrand,$iengine,$iofficero,
              $ibig_sales,$itag,$mprem_dmg,$x,$ibig_office,$icar_type,
              $ncar_abbr,$iissue_ym,$iapplicant,$napplicant;
       if (SQLCODE==SQLNOTFOUND) break;

printf("ipolicy[%s]\n",ipolicy);
       $select count(*) 
          into $cnt
          from car6257_1
         where ipolicy = $ipolicy;
       if (cnt > 0) continue;
       printf("------> cnt=[%d]\n", cnt ); 
            /**** �~�Z��� ***/
       $select nbranch into $nquota
          from sa_branch_type
         where ibranch = $iquota;
       if ( SQLCODE == SQLNOTFOUND )
          nquota[0]='\0';
   
            /**** �g��H����� ***/
       if (strncmp(ibig_office," ",1)==0) {
          nofficer[0] ='\0';
          strcpy(iofficer,iofficero);
       }
       else {
       $select iofficer,nname
          into $iofficer,$nofficer
          from officer
         where iofficer = $ibig_office;
       if ( SQLCODE == SQLNOTFOUND ) {
          nofficer[0] ='\0';
          strcpy(iofficer,iofficero);
       }
       }

            /**** �g�P�Ӹ�� ***/
       if (strncmp(iofficer[0],"B",1)==0)
          strcpy(ncomp,"����");
       else if (strncmp(iofficer[0],"J",1)==0)
          strcpy(ncomp,"���q");
       else
          strncpy(ncomp,iofficer,1);
       
            /*** ��~�ҷ~�N��ƺ��@�� ***/
       $select nname into $nsales
          from ca_big_office
         where ibig_comp = $ibig_sales 
           and fclass='2';
       if ( SQLCODE == SQLNOTFOUND )
          nsales[0]='\0';
            
           /*** �t�P���� ***/   
       $declare cur11 cursor for
         select nbrand, ipro_year
           into $nbrand,$ipro_year
           from ca_car_model 
          where ibrand= $ibrand
          order by ipro_year DESC ;
       $open cur11;
       $fetch cur11;
       if ( SQLCODE == SQLNOTFOUND )
          nbrand[0]='\0';
       $close cur11;
       $free cur11;
           
printf("insert car6257_2\n");
       $insert into car6257_2
        values ($iquota,$nquota,$ncomp,$icard,$ipolicy,$iassured,
              $nassured,$iapplicant,$napplicant,$dpolicy,$dply_begin,$icar_type,$ncar_abbr,
              $ibrand,$nbrand,$iengine,$iissue_ym,$iofficero,$ibig_office,
              $nofficer,$ibig_sales,$nsales,$itag,$mprem_dmg,$x);
    }
    $close cur_w;
  }
  $free cur_w;
   
  return SUCCESS;

errexit:
   sqlfatal();
   strcpy(msgbuf,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car6257_write_comp()
{
$char ioff1[2];
   $whenever sqlerror goto errexit;

   strncpy(ioff1,iofficer,1);
   $insert into car6257 values
    ($iquota,$icd[0],$iply[0],$icd[1],$iply[1],$iassured,$nassured,$iapplicant,$napplicant,
     $dpolicy,$dply_begin,$ibrand,$iengine,$iissue_ym,' ',' ',$iofficer,
     $ibig_office,$ibig_sales,$itag,0,0,0,0,0,0,0,$mprem_21,$x,' ',
     $iply_comp,$icd_comp,$cnt_comp,$icar_type,$ncar_abbr,$ioff1,
     0,0,0,0,0,0,0,0,0,0,0,0);

   return SUCCESS;
errexit:
    sqlfatal();
    strcpy(msgbuf,sqlca.sqlerrm);
    return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car6257_write_data()
{
   $whenever sqlerror goto errexit;

   /* ���o�O�N�N�� */
   /* �M�ץ�P�_�s�WM�g����ư�M0,M9  modify by sylvia 102.12.12 (1021122001_C1)
                �s�WN�g��A�~�Ȩӷ���E (1030630002_C4) */
   /* if (strncmp(ioff[0],"W",1)==0) */
   if ((strncmp(ioff[0],"W",1)==0) ||
   	   ((strncmp(ioff[0],"H",1)==0) && (strncmp(ioff[0],"H0",2)!=0) &&
   	    (strncmp(ioff[0],"H1",2)!=0) && (strncmp(ioff[0],"H2",2)!=0)) ||
      	   ((strncmp(ioff[0],"N",1) == 0) && (strncmp(ires,"E",1) == 0)))
   {
      $select ibus_location
         into $ibus_location
         from officer
        where iofficer = $ioff[0];
   }
   else
      strncpy(ibus_location,ioff[1],1);

printf("ibus_loc[%s]\n",ibus_location);

   $insert into car6257 values
    ($iquota,$icd[0],$iply[0],$icd[1],$iply[1],$iassured,$nassured,
     $iapplicant,$napplicant,
     $dpolicy,$dply_begin,$ibrand,$iengine,$iissue_ym,$ioff[0],
     $ibigo[0],$ioff[1],$ibigo[1],
     $ibig_sales,$itag,$mprem_09,$mprem_upg,$mprem_11,$mprem_17,$mprem_31,
     $mprem_51,$mprem_oth,$mprem_21,$x,$ibig_office_w,$iply_comp,
     $icd_comp,$cnt_comp,$icar_type,$ncar_abbr,$ibus_location,
     $rSafe_09,$rSafe_11,$rSafe_17,$rSafe_31,$rSafe_51,$rSafe_oth,
     $rMgmt_09,$rMgmt_11,$rMgmt_17,$rMgmt_31,$rMgmt_51,$rMgmt_oth);

   if (x_cnt > 1)               /* �P�@�������X���G���H�W�M�ץ� */
      $update car6257_1
          set ply_cnt = $x_cnt
        where iengine = $iengine
          and fcard_class = '2';

   if (cnt_comp > 1)            /* �P�@�������X���G���H�W�j���I */
      $update car6257_1
          set ply_cnt = $cnt_comp
        where iengine = $iengine
          and fcard_class = '1';

   return SUCCESS;
errexit:
    sqlfatal();
    strcpy(msgbuf,sqlca.sqlerrm);
    return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car6257_write_data_1()
{
extern struct sEquip *IfirstEquip, *IcurrEquip, *IlastEquip, *IEquip_ptr;
$char   equipdecode[201];

   $whenever sqlerror goto errexit;

   /* ���o�O�N�N�� */
   /* �M�ץ�P�_�s�WM�g����ư�M0,M9  modify by sylvia 102.12.12 (1021122001_C1)
                �s�WN�g��A�~�Ȩӷ���E (1030630002_C4) */
   /* if (strncmp(iofficer,"W",1)==0) */
   if ((strncmp(iofficer,"W",1)==0) ||
   	   ((strncmp(iofficer,"H",1)==0) && (strncmp(iofficer,"H0",2)!=0) &&
   	    (strncmp(iofficer,"H1",2)!=0) && (strncmp(iofficer,"H2",2)!=0)) ||
      	   ((strncmp(iofficer,"N",1) == 0) && (strncmp(iresource,"E",1) == 0)))
      $select ibus_location
         into $ibus_location
         from officer
        where iofficer = $iofficer;
   else
      strncpy(ibus_location,iofficer,1);

printf("write data 1 [%s]\n",ibus_location);
      nremark[0]='\0';
      strcpy(equipdecode,equip_get(remark));
      IEquip_ptr=IfirstEquip;
      while (IEquip_ptr)
      {
          strcpy(remark1,IEquip_ptr->sequip);
          iTmpCode = atoi(remark1);
          sprintf(remark1,"%02d",iTmpCode);
          
          $execute pre_code into $ncode using $remark1;
          if (SQLCODE != SQLNOTFOUND)
          {
             if ((strlen(nremark)+strlen(ncode))>90) break;
             strcat(nremark,rtrim(ncode));
             strcat(nremark," ");
          }

          IEquip_ptr=IEquip_ptr->next;
      }

   $insert into car6257_1 values
    ($iquota,$fcard_class,$icard,$ipolicy,$iassured,$nassured,$iapplicant,$napplicant,
     $dpolicy,$dply_begin,$ibrand,$iengine,$iissue_ym,$iofficer,
     $ibig_office,$ibig_sales,$itag,$mprem_09, $mprem_upg, $mprem_11_1,
     $mprem_17_1,$mprem_31_1,$mprem_51_1,$mprem_oth_1,$mprem_21d,1,
     $nremark,$icar_type,$ncar_abbr,$ibus_location,
     $rSafe_09,$rSafe_11,$rSafe_17,$rSafe_31,$rSafe_51,$rSafe_oth,
     $rMgmt_09,$rMgmt_11,$rMgmt_17,$rMgmt_31,$rMgmt_51,$rMgmt_oth);

   return SUCCESS;
errexit:
    sqlfatal();
    strcpy(msgbuf,sqlca.sqlerrm);
    return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car6257_read_file()
{
    char   *bp;
    int    rc,i,j,k,m,n;

    $whenever sqlerror goto errexit;

    rc=car6257_create_temp();
    if (rc != SUCCESS)
        return rc;

    sprintf(filename,"%s/dat/car/car625.txt",sApHome);
    flen=1024;
    if ((fp=fopen(filename,"r"))==NULL) {
       sprintf(msgbuf,"%s �ɮ׶}�ҥ���",filename);
       return FALSE;
    }
    if ((bp=malloc(flen))==NULL) {
       sprintf(msgbuf,"System malloc failed !");
       return FALSE;
    }

    for (i=0;(feof(fp)==0);i++) {
        memset(bp,0x00,flen);
        fgets(bp,flen,fp);
        if (bp[0]==0x00)
           break;
        for(j=0;j<qfield_all;j++)
           memset(sdata[j],0x00,41);
        k=m=n=0;
        for (j=0;j<flen;j++) {
            if (bp[j]=='\t' || bp[j]=='\0' || bp[j]=='\n') {
                strncpy(sdata[k],bp+m,j-m);
                sdata[k][j-m]='\0';
                m=j+1;
                k++;
            }
            if (bp[j]=='\n')
                break;
            if (k > (qfield_all - 1)) break;
        }      
        if (sdata[0][0]=='\0') continue;
        rtrim_alldata3();
        
        printf("iengine[%s]\n",iengine);
        rc=car6257_read_ply();
        if (rc!=SUCCESS)
           return rc;
    }

    return SUCCESS;
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car6257_create_temp()
{
$char  stmt[2048];
int    x;
    $whenever sqlerror goto errexit;
      
    strcpy(stmt,"create temp table car6257_tmp (");
    for(x=0;x<qfield_all-1;x++)
       sprintf(stmt,"%s f%d char(40),",stmt,x);
    sprintf(stmt,"%s f%d char(40) ) with no log",stmt,x);
printf("stmt[%s]\n",stmt);
    $prepare pre_tmp from $stmt;
    $execute pre_tmp;

    $create temp table car6257
     (iquota         char(6),
      icard1         char(20),
      ipolicy1       char(20),
      icard2         char(20),
      ipolicy2       char(20),
      iassured       char(12),
      nassured       char(40),
      iapplicant     char(12),
      napplicant     char(40),
      dpolicy        date,
      dply_begin     date,
      ibrand         char(8),
      iengine        char(20),
      iissue_ym      char(6),
      iofficer1      char(10),
      ibig_office1   char(10),
      iofficer2      char(10),
      ibig_office2   char(10),
      ibig_sales     char(10),
      itag           char(12),
      mprem_09       integer, 
      mprem_upg      integer,
      mprem_11       integer, 
      mprem_17       integer,
      mprem_31       integer,
      mprem_51       integer,
      mprem_oth      integer,
      mprem_21       integer,
      ply_cnt        integer,
      ibig_office    char(9),
      iply_comp      char(20),
      icd_comp       char(20),
      cnt_comp       integer,
      icar_type      char(02),
      ncar_abbr      char(12),
      ibus_loc       char(1),
      rSafe_09       decimal(9,7),
      rSafe_11       decimal(9,7),
      rSafe_17       decimal(9,7),
      rSafe_31       decimal(9,7),
      rSafe_51       decimal(9,7),
      rSafe_oth      decimal(9,7),
      rMgmt_09       decimal(9,7),
      rMgmt_11       decimal(9,7),
      rMgmt_17       decimal(9,7),
      rMgmt_31       decimal(9,7),
      rMgmt_51       decimal(9,7),
      rMgmt_oth      decimal(9,7)) 
     with no log;

    $create temp table car6257_1
     (iquota         char(6),
      fcard_class    char(1),
      icard          char(20),
      ipolicy        char(20),
      iassured       char(12),
      nassured       char(40),
      iapplicant     char(12),
      napplicant     char(40),
      dpolicy        date,
      dply_begin     date,
      ibrand         char(8),
      iengine        char(20),
      iissue_ym      char(6),
      iofficer       char(10),
      ibig_office    char(10),
      ibig_sales     char(10),
      itag           char(12),
      mprem_09       integer, 
      mprem_upg      integer,
      mprem_11       integer, 
      mprem_17       integer,
      mprem_31       integer,
      mprem_51       integer,
      mprem_oth      integer,
      mprem_21       integer,
      ply_cnt        integer,
      remark         char(90),
      icar_type      char(02),
      ncar_abbr      char(12),
      ibus_loc       char(1),
      rSafe_09       decimal(9,7),
      rSafe_11       decimal(9,7),
      rSafe_17       decimal(9,7),
      rSafe_31       decimal(9,7),
      rSafe_51       decimal(9,7),
      rSafe_oth      decimal(9,7),
      rMgmt_09       decimal(9,7),
      rMgmt_11       decimal(9,7),
      rMgmt_17       decimal(9,7),
      rMgmt_31       decimal(9,7),
      rMgmt_51       decimal(9,7),
      rMgmt_oth      decimal(9,7)) 
     with no log;

    $create temp table car6257_2
     (iquota         char(6),
      nquota         char(20),
      ncomp          char(10),
      icard          char(20),
      ipolicy        char(20),
      iassured       char(12),
      nassured       char(40),
      iapplicant     char(12),
      napplicant     char(40),
      dpolicy        date,
      dply_begin     date,
      icar_type      char(2),
      ncar_abbr      char(12),
      ibrand         char(8),
      nbrand         char(20),
      iengine        char(20),
      iissue_ym      char(6),
      iofficer       char(10),
      ibig_office    char(10),
      nofficer       char(10),
      ibig_sales     char(10),
      nbig_sales     char(10),
      itag           char(12),
      mprem_dmg      integer,
      ply_cnt        integer)
     with no log;

    return SUCCESS;
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;  
}
/*--------------------------------------------------------------------*/
rtrim_alldata3()
{
    int  x;
    for(x=0;x<qfield_all;x++)
       strcpy(sdata[x],rtrim(sdata[x]));
    strcpy(iengine,sdata[qfield_chk-1]);
}
/*--------------------------------------------------------------------*/
