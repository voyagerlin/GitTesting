/************************************************/
/*                                              */
/*   PROGRAM : ca163p01s.ec                     */
/*   PURPOSE : �w��J���L��}��@�~             */
/*                                              */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
$include sqlca;
$include decimal;
#include "safeclib.h"


DBinfo  *list;
int  count_db = 0;
$int  *fstate;

long car163(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
long rtncode;
long car163_single_query(),car163_update_exec(),car163_single_query_log();
long car163_multiple_query();
char option;

	cm_buf_init(command);
	cm_buf_get("%c",&option);
	switch(option)
	{
	 case 'M':
	          rtncode=car163_multiple_query(reply);
	          break;
	 case 'Q':
	   rtncode=car163_single_query(reply);
	   break;
	 case 'U':
	 case 'D':
	   rtncode=car163_update_exec(reply,command,com_len);
	   break;
	 default :
	   if(exitsub(reply,M_CM_WRONG_OPTION) == True)
	    return M_CM_WRONG_OPTION;
	          return apiRC;
	}
	return(rtncode);
}

/*******************************************************************/
long car163_multiple_query(reply)
serverReply reply;
{
$char DBName[3];

$char type1[2],s_itag[CA_TAG_NUM];
$char userid[11];
$char itag[CA_TAG_NUM],ipolicy[21],ipre_rcv[21],nassured[121],dply_begin[11],dply_end[11],iofficer[11],ileader[11],nleader[11];
$char tmp_fpass[21];
$char sWhere[256];
char  tmpbuf[4000],stmt_receive[200];
int   count=0,repbuf_len=0,tmp_len=0,replycnt=0;
int   i,total_count=0,k;
char  tIpolicy1[POLICY_NUM_1] , tIpolicy2[POLICY_NUM_2];
int   flag=0;
$char stmt[1000],stmt2[1000];
int   rc;

	cm_buf_get("%s",DBName);
	cm_buf_get("%s %s ",type1,s_itag);

	if (db_select(DBName) == False) {
	    if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
	       return M_CM_DB_NOTOPEN;
	    else
	       return apiRC;
	}

	$create temp table ca163tmp
	(
	    itag         char(12),          -- �P�Ӹ��X
	    ipolicy      char(20),          -- �O�渹
	    ipre_rcv     char(20),          -- �����渹
	    nassured     varchar(120),      -- �O��W��
	    dbegin       char(10),          -- �O�I�_��
	    dend         char(10),          -- �O�I����
	    iofficer     char(10),          -- �g��N��
	    ileader      char(10),          -- �޲z�H�N��
	    nleader      char(10)           -- �޲z�H�W��
	)with no log;

	if ( (list=get_db_list(&count_db,DBName)) == (char*)0 ) {
	       printf("get_db_list error accur \n");
	       return SQLCODE;
	   }
     
	
	if(strcmp(type1,"1")==0)
	{
		for(k=0 ; k<count_db ; k++)
		{   	
			 sprintf_s(stmt, sizeof stmt, "INSERT INTO ca163tmp "
		  		           "SELECT b.itag,a.ipolicy,a.itmp_policy,b.nassured,a.dply_begin,a.dply_end, "
		  		           "      a.iofficer,a.ileader,(SELECT nname FROM officer WHERE iofficer = a.ileader) "
		   		           " FROM %s:ply_relation a,%s:policy b,cm_pre_receive c "
				           " WHERE a.ipolicy =b.ipolicy "
				           "  and a.ipolicy[6,7] <> 'VW' "
		                   "  and a.icar_type not in ('51','T1','T2') "
		                   "  and a.iofficer[1,1] not in ('W','H','N') "
		                   "  and a.itmp_policy = c.ipre_rcv "
		                   "  and c.ftype_sp not in ('20','JC') "
				           "  AND a.dentry >= today-31 "
				           "  AND a.dpolicy IS NULL "
				           "  AND c.ipolicy1 = a.ipolicy "
				           "  AND c.ipolicy2= ' ' "
				           "  AND c.iins_kind = '2' "
		         		   "  AND c.ipre_end = ' ' "
		        		   "  AND c.fprint_note = 'Y' "
		         		   "  AND c.dprint_note IS NOT NULL "
				           "  AND b.itag = '%s' ",list[k].dbname ,list[k].dbname ,s_itag);		
			 printf("stmt[%s]\n", stmt);	    	    
			 $prepare ply1 from $stmt;
		     $execute ply1;
		}
	}
	else
	{
 		sprintf_s(stmt, sizeof stmt, "INSERT INTO ca163tmp "
			         " SELECT a.itag,b.ipolicy1,b.ipre_rcv,b.nassured,a.dply_begin,a.dply_end, "
		    		 "       a.iofficer,a.ileader,(SELECT nname FROM officer WHERE iofficer = a.ileader) "
			         "  FROM policy_302 a,cm_pre_receive b "
			         " WHERE (a.iestimate_ori = b.ipre_rcv OR a.iestimate_sug = b.ipre_rcv) "
			         "   AND b.iins_kind = '2' "
			         "   AND b.ipre_end = ' ' "
			         "   AND a.fcard_class = '2' "
			         "   AND b.ipolicy1 = '' "
			         "   AND b.ipolicy2 = '' "
			         "   AND b.dentry > today - 31 "
			         "   AND a.itag = '%s' ",s_itag);
		$prepare cm1 from $stmt;
		$execute cm1;
		sprintf_s(stmt, sizeof stmt, "INSERT INTO ca163tmp "
			          " SELECT a.itag,a.ipolicy2,a.iabnormal,a.nassured,a.dbegin,a.dend, "
		   			  "      a.iofficer2,(SELECT ileader FROM officer WHERE iofficer = a.iofficer2), "
		   			  "     (SELECT nname FROM officer WHERE iofficer = (SELECT ileader FROM officer WHERE iofficer = a.iofficer2)) "
			          " FROM newa00:abnormal_ply a "
			          " WHERE a.dentry >= today-31 "
			          "  AND a.ipolicy1 = '' "
			          "  AND a.ipolicy2 = '' "
			          "  AND a.itag = '%s' ",s_itag);
		$prepare ab1 from $stmt;
		$execute ab1;
		for(k=0 ; k<count_db ; k++)
		{
			sprintf_s(stmt, sizeof stmt, "INSERT INTO ca163tmp "
		  	               " SELECT a.itag,a.ipolicy2,a.iestimate,a.nassured,a.dply2_begin,a.dply2_end, "
			       	       "      a.iofficer2,(SELECT ileader FROM officer WHERE iofficer = a.iofficer2), "
		       		       "      (SELECT nname FROM officer WHERE iofficer = (SELECT ileader FROM officer WHERE iofficer = a.iofficer2)) "
		   	               " FROM %s:estimate a  "
		                   " WHERE a.dentry >= today-31 "
		                   "  AND a.ipolicy1 = '' "
			               "  AND a.ipolicy2 = '' "
			               "  AND a.itag = '%s' ",list[k].dbname ,s_itag);
			$prepare est1 from $stmt;
			$execute est1;
		}		
	}	
	sprintf_s(stmt2, sizeof stmt2, "SELECT distinct itag,ipolicy,ipre_rcv,nassured,dbegin,dend,iofficer,ileader,nleader FROM ca163tmp ");

	$PREPARE CUR_CAID FROM $stmt2;
	$DECLARE IDcur CURSOR FOR CUR_CAID;
	$OPEN IDcur;

	for(;;)
	{
		$FETCH IDcur INTO $itag,$ipolicy,$ipre_rcv,$nassured,$dply_begin,$dply_end,$iofficer,$ileader,$nleader;

		if (SQLCODE != 0) break;
		cm_buf_init(tmpbuf);
		
		if ( count == 0 )
		{
			cm_buf_res_msg();             /* reserve for MsgCode and count */
			cm_buf_res_count();
		}
		
		cm_buf_put("%s %s %s %s %s %s %s %s ", itag,ipolicy,ipre_rcv,dply_begin,dply_end,iofficer,ileader,type1);
		tmp_len = cm_buf_len(tmpbuf);
		if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
		{
			memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
			repbuf_len += tmp_len;
			count++;
		}
		else                               /* more than 4K, send to client side */
		{
			cm_buf_init(ReplyBuf);
			cm_buf_put_msg(M_CM_OK);
			cm_buf_put_count(count);
			if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
			{
				$CLOSE IDcur;
				return apiRC;
			}
			else               /* clear ReplyBuf and count to start all over again */
			{
				replycnt++;
				if (replycnt == 10)   /* more than 30K, client cannot display,error */
				{
				    cm_buf_init(ReplyBuf);
				    cm_buf_put("%l",M_CM_OUT_SPACE);
				    tmp_len = cm_buf_len(ReplyBuf);
				    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
				        return apiRC;
				    return M_CM_OUT_SPACE;
				}
				ReplyBuf[0] = '\0';
				count = 0;
				cm_buf_init(ReplyBuf);
				cm_buf_res_msg();           /* reserve for MsgCode and count */
				cm_buf_res_count();
				cm_buf_put("%s %s %s %s %s %s %s %s ", itag,ipolicy,ipre_rcv,dply_begin,dply_end,iofficer,ileader,type1);
				repbuf_len = cm_buf_len(ReplyBuf);
				count++;
			}
		}
	} /* for loop */

	$delete from ca163tmp;
	$CLOSE IDcur;
	if (count > 0)   /* break out, at least one record is selected */
	{
	  cm_buf_init(ReplyBuf);
	  cm_buf_put_msg(M_CM_OK);
	  cm_buf_put_count(count);
	  if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
	    return apiRC;
	  return api_OKComplete;
	}
	else            /* break out, not any row is found */
	{
	  if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
	    return M_CM_NOT_FOUND;                               /*?*/
	  else
	    return apiRC;
	}

	errexit:
	  if(exitsub(reply,SQLCODE) == True)
	     return SQLCODE;
	  else
	     return apiRC;
	}

/***********************************************************************/
long car163_single_query(reply)
serverReply reply;
{
 $char DBName[3],v_sMsg[2040];
 char  tmpbuf[4000];
 int   count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int   i,total_count=0;
 $char userid[11],ipolicy_in[25];
 $char option1[2],ftype[2];
 $char nquota[41],ipolicy[21],ipre_rcv[21],nassured[121],iassured[13],iengine[CA_ENGINE_NUM],itag[CA_TAG_NUM],dply_begin[11],dply_end[11];
 $char iofficer[11],nofficer[11],ileader[11],nleader[11],dentry[11],fassured[2],icar_type[3],dpolicy[11],iverify_note[2];
 $char reson_note[60],reson_note1[60],reson_note2[60];
 $char foccup[2],noccup[6],applicant_foccup[2],applicant_noccup[6];
 $char ncar_type[11],iroute[21],bzfrom[3],dbegin[11],s_dply_begin[11],ilog_type[10],ilog_type1[2],ilog_type2[2],ilog_type3[2];
 $int  mprem = 0,cn_day,qday_permit,cnt_est=0,cnt2030=0;
 $char after_date[11],dateline[11];
 $char ncontent_open[256],ncontent_verify[256],chk_rba_policy[25];
 $long sToday,ply2_begin,sLdeffect;
 int   flag=0;
 $char stmt[2048],stmt1[2048],stmp[1024],stmtt[2048];
 $char Full_DBName[31];
 int   rc,k=0,k2=0;
 $int cnt_punish=0;

  cm_buf_get("%s %s %s %s %s",DBName,userid,option1,ipolicy_in,ftype);

  $WHENEVER SQLERROR GOTO errexit;
  
  strcpy(ipolicy_in,trim(ipolicy_in));

  if (db_select(DBName) == False)
  {
     if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
       return M_CM_DB_NOTOPEN;
     else
       return apiRC;
  }

  if ( (list=get_db_list(&count_db,DBName)) == (char*)0 ) {
  	printf("get_db_list error accur \n");
  	return SQLCODE;
  }

  strcpy(Full_DBName,get_car_full_db(ipolicy_in));
  
  if (strcmp(trim(option1),"1") == 0)
   {
   	if(strcmp(trim(ftype),"7") == 0)
   	{
	  	 sprintf_s(stmt1, sizeof stmt1, "SELECT (SELECT nbranch FROM sa_branch_type WHERE ibranch = a.iquota), "
	         	" a.ipolicy,a.itmp_policy,b.nassured,b.iassured,b.iengine,b.itag,a.dply_begin,a.dply_end,(a.mdmg_prem+a.mlia_prem), "
	         	" a.iofficer,(SELECT nname FROM officer WHERE iofficer = a.iofficer), "
	         	" a.ileader,(SELECT nname FROM officer WHERE iofficer = a.ileader), "
	         	" a.dentry,b.fassured,a.icar_type,a.dpolicy, "
	         	" CASE WHEN c.fverify_note = '0' THEN '�f�֤��P�N' ELSE '�W�L�Ѽƨt�ΧP�w' END, "
	         	" b.foccup,b.noccup,b.applicant_foccup,b.applicant_noccup "
	    	    " FROM %s:ply_relation a,%s:policy b,cm_pre_receive c "
	   	        " WHERE a.ipolicy = b.ipolicy "
	   	        " and a.ipolicy[6,7] <> 'VW' "
	            " and a.icar_type not in ('51','T1','T2') "
	            " and a.iofficer[1,1] not in ('W','H','N') "
	            " and a.itmp_policy = c.ipre_rcv "
	            " and c.ftype_sp not in ('20','JC') "
	   	        " AND a.dentry < today "
	            " AND a.dpolicy IS NULL "
	     	    " AND a.ipolicy = '%s'"
	            " AND c.ipolicy1 = a.ipolicy "
		        " AND c.ipolicy2= ' ' "
	            " AND c.iins_kind = '2' "
	            " AND c.ipre_end = ' ' "
	            " AND c.fprint_note = 'Y' "
	            " AND c.dprint_note IS NOT NULL",Full_DBName,Full_DBName,ipolicy_in);

	             $prepare pply1 from $stmt1;
		         $execute pply1 into $nquota,$ipolicy,$ipre_rcv,$nassured,$iassured,$iengine,$itag,$dply_begin,$dply_end,$mprem,
	         	 $iofficer,$nofficer,$ileader,$nleader,$dentry,$fassured,$icar_type,$dpolicy,$reson_note,
	         	 $foccup,$noccup,$applicant_foccup,$applicant_noccup;

		if(SQLCODE==SQLNOTFOUND)
		{
			if(exitsub(reply,M_CM_NOT_FOUND) == True)
			return M_CM_NOT_FOUND;
			else
			return apiRC;
		}
	}
	else if(strcmp(trim(ftype),"8") == 0)
	{
			sprintf_s(stmt1, sizeof stmt1, "SELECT first 1 ilog_number1 FROM ca_log "
			               " WHERE (ipgid = 'car301' or ipgid = 'car3011') "
			               " AND itype = 'O' "
			               " AND ilog_number2 = 'A' "
			               " AND ilog_number1 = '%s' "
			               " order by dupdate desc ",ipolicy_in);
			$prepare rba_log from $stmt1;
			$execute rba_log into $chk_rba_policy;
			strcpy(chk_rba_policy,trim(chk_rba_policy));
			if(SQLCODE==SQLNOTFOUND)
			{
				if(exitsub(reply,M_CM_NOT_FOUND) == True)
				return M_CM_NOT_FOUND;
				else
				return apiRC;
			}
			if(strcmp(ipolicy_in,chk_rba_policy) == 0)
			{
				sprintf_s(stmt1, sizeof stmt1, "SELECT (SELECT nbranch FROM sa_branch_type WHERE ibranch = a.iquota), "
		         	" a.ipolicy,a.itmp_policy,b.nassured,b.iassured,b.iengine,b.itag,a.dply_begin,a.dply_end,(a.mdmg_prem+a.mlia_prem), "
		         	" a.iofficer,(SELECT nname FROM officer WHERE iofficer = a.iofficer), "
		         	" a.ileader,(SELECT nname FROM officer WHERE iofficer = a.ileader), "
		         	" a.dentry,b.fassured,a.icar_type,nvl(a.dpolicy,' '), "
		         	" ' ', b.foccup, b.noccup, b.applicant_foccup, b.applicant_noccup "
		    	    " FROM %s:ply_relation a,%s:policy b,cm_pre_receive c "
		   	        " WHERE a.ipolicy = b.ipolicy "
		            " and a.itmp_policy = c.ipre_rcv "
		            " AND a.dpolicy IS NULL "
		     	    " AND a.ipolicy = '%s' "
		            " AND c.ipolicy1 = a.ipolicy "
			        " AND c.ipolicy2= ' ' "
		            " AND c.iins_kind = '2' "
		            " AND c.ipre_end = ' ' ",Full_DBName,Full_DBName,ipolicy_in);
		             
				$prepare pply2 from $stmt1;
				$execute pply2 into $nquota,$ipolicy,$ipre_rcv,$nassured,$iassured,$iengine,$itag,$dply_begin,$dply_end,$mprem,
			         	            $iofficer,$nofficer,$ileader,$nleader,$dentry,$fassured,$icar_type,$dpolicy,
			         	            $reson_note,$foccup,$noccup,$applicant_foccup,$applicant_noccup;
				printf("foccup[%s]\n",foccup);
				if(SQLCODE==SQLNOTFOUND)
				{
					if(exitsub(reply,M_CM_NOT_FOUND) == True)
					return M_CM_NOT_FOUND;
					else
					return apiRC;
				}
			}
	}	 	          
   }
   else
   {
          if(strcmp(trim(ftype),"R") == 0)
          {
          	  sprintf_s(stmtt, sizeof stmtt, " SELECT a.nchi_full, "
			  " b.ipolicy1,b.ipre_rcv,b.nassured,b.iassured,a.iengine,a.itag,a.dply_begin,a.dply_end,b.mprem, "
			  " a.iofficer,(SELECT nname FROM officer WHERE iofficer = a.iofficer), "
			  " a.ileader,(SELECT nname FROM officer WHERE iofficer = a.ileader), "
			  " b.dentry,a.fassured,a.icar_type,' ',a.iroute,a.bzfrom "
		      " FROM policy_302 a,cm_pre_receive b "
		      " WHERE (a.iestimate_ori = b.ipre_rcv OR a.iestimate_sug = b.ipre_rcv) "
		      " AND b.ipre_rcv = '%s' "
		      " AND b.iins_kind = '2' "
		      " AND b.ipre_end = ' ' "
		      " AND a.fcard_class = '2' "
		      " AND b.ipolicy1 = '' "
		      " AND b.ipolicy2 = '' ",ipolicy_in);
		      $prepare estt from $stmtt;
	 }
	 else if(strcmp(trim(ftype),"X") == 0)
     {
         	  sprintf_s(stmtt, sizeof stmtt, "SELECT (SELECT nbranch FROM sa_branch_type WHERE ibranch = (SELECT iquota FROM officer WHERE iofficer = a.iofficer2)), "
       			 " a.ipolicy2,a.iabnormal,a.nassured,a.iassured,a.iengine,a.itag,a.dbegin,a.dend,mdali_prem, "
       			 " a.iofficer2,(SELECT nname FROM officer WHERE iofficer = a.iofficer2), "
       			 " (SELECT ileader FROM officer WHERE iofficer = a.iofficer2), "
       			 " (SELECT nname FROM officer WHERE iofficer = (SELECT ileader FROM officer WHERE iofficer = a.iofficer2)), "
       			 " a.dentry,a.fassured,a.icar_type2,' ',iroute,bzfrom2 "
		   " FROM newa00:abnormal_ply a "
		   " WHERE a.iabnormal = '%s' "
		   " AND a.ipolicy1 = '' "
		   " AND a.ipolicy2 = '' "
		   " AND length(trim(cast(a.dbegin as char(11)))) > 0",ipolicy_in);
		     $prepare estt from $stmtt;
	 }
	 else
     {
     	/*1060914008 �}��e�O������*/
     	rc = ca_quote_to_est(ipolicy_in, DBName, &fstate, v_sMsg);
     	printf("fstate[%d],v_sMsg[%s]\n", fstate, v_sMsg );
     	if (rc != M_CM_OK) return rc;

         for(k=0 ; k<count_db ; k++)
		{
         		sprintf_s(stmt, sizeof stmt, "SELECT count(*) "
		   	   " FROM %s:estimate a  "
		       "  WHERE iestimate = '%s' ",list[k].dbname ,ipolicy_in);
			 $prepare est1 from $stmt;
		         $execute est1 into $cnt_est;
		         if(cnt_est >0)
		         k2=k;
		         printf("k[%d]  ;  k2[%d]\n",k,k2);
		         
		}
		 sprintf_s(stmtt, sizeof stmtt, "SELECT (SELECT nbranch FROM sa_branch_type WHERE ibranch = (SELECT iquota FROM officer WHERE iofficer = a.iofficer2)), "
	       		 " a.ipolicy2,a.iestimate,a.nassured,a.iassured,a.iengine,a.itag,a.dply2_begin,a.dply2_end,mpremium2, "
	       		 " a.iofficer2,(SELECT nname FROM officer WHERE iofficer = a.iofficer2), "
	       		 " (SELECT ileader FROM officer WHERE iofficer = a.iofficer2), "
       			 " (SELECT nname FROM officer WHERE iofficer = (SELECT ileader FROM officer WHERE iofficer = a.iofficer2)), "
	       		 " a.dentry,a.fassured,a.icar_type2,' ',iroute,bzfrom2 "
		   " FROM %s:estimate a "
		   " WHERE iestimate = '%s' "
		   " AND a.ipolicy1 = '' "
		   " AND a.ipolicy2 = '' "
		   " AND length(trim(cast(a.dply2_begin as char(11)))) > 0" ,list[k2].dbname,ipolicy_in);
		     $prepare estt from $stmtt;
	 }
	 printf("stmtt[%s]\n", stmtt);
	 $execute estt INTO $nquota,$ipolicy,$ipre_rcv,$nassured,$iassured,$iengine,$itag,$dply_begin,$dply_end,$mprem,
	         	    $iofficer,$nofficer,$ileader,$nleader,$dentry,$fassured,$icar_type,$dpolicy,$iroute,$bzfrom;	 
	 if(SQLCODE==SQLNOTFOUND)
	 {
	    if(exitsub(reply,M_CM_NOT_FOUND) == True)
	      return M_CM_NOT_FOUND;
	    else
	      return apiRC;
	 } 
	 
	$SELECT count(*) 
	   INTO $cnt2030 
	   FROM car_code 
	  WHERE kind = 'SP' 
	    AND detail = '2'
	    AND detail2 = $iofficer; 

	sToday = cm_today( );
	strcpy(s_dply_begin,cm_from_infdate_100(dply_begin));
    	ply2_begin = cm_ymd_cdate(s_dply_begin);
    	printf("--sToday[%d]  ply2_begin[%d]\n",sToday,ply2_begin);
    	if(sToday > ply2_begin)
    	{
    		if((strncmp(bzfrom,"2",1) == 0 || strncmp(bzfrom,"3",1) == 0) && cnt2030 > 0)
    		{
			rc = chk_working_date( s_dply_begin, 15, &after_date, v_sMsg);
			strcpy(dateline,cm_to_infdate(after_date));
			printf("---310---dateline[%s]\n",dateline);
			sLdeffect = cm_ymd_cdate(after_date);
	
		        /* �t�Τ�>=�ͮĤ�+�]�w���u�@�� */
			if (sToday >= sLdeffect) 
				strcpy(reson_note1,"�t�Τ�>�ͮĤ�+15�Ӥu�@��");
			else 
				strcpy(reson_note1," ");	
    			
    		}
    		
    		else if(strncmp(bzfrom,"1",1) == 0 || strncmp(bzfrom,"4",1) == 0)
    		{
	    		/* �W�L�ͮĤ� */
			$SELECT nvl(min(qday_permit_c),7)
			   INTO $qday_permit
			   FROM ca_permit
			  WHERE (icode = (select iroute_main from cm_route where iroute = $iroute) 
				  OR icode = $iassured
				  OR icode = $iofficer)
			    AND ftype_sp in ('A3') 
			    AND (dexpire is null or dexpire > today);
			    
			if(SQLCODE==SQLNOTFOUND) qday_permit = 7;
			
			rc = chk_working_date( s_dply_begin, qday_permit, &after_date, v_sMsg);
			strcpy(dateline,cm_to_infdate(after_date));
			printf("---310---dateline[%s]\n",dateline);
			sLdeffect = cm_ymd_cdate(after_date);
	
		        /* �t�Τ�>=�ͮĤ�+�]�w���u�@�� */
			if (sToday >= sLdeffect) 
				strcpy(reson_note1,"�t�Τ�>�ͮĤ�+�]�w���u�@�Ѽ�");
			else 
				strcpy(reson_note1," ");
		}	
	}
	else 
	strcpy(reson_note1," ");
	cnt_punish = 0;
	/* �ި�W�� */
	if (((strncmp(bzfrom,"2",1) == 0 || strncmp(bzfrom,"3",1) == 0) && cnt2030 > 0) || (strncmp(bzfrom,"1",1) == 0 || strncmp(bzfrom,"4",1) == 0))
      	{
      	/* �P�_�O�_�����O�X��H�W�ɤ����޲z�H */
	      	$SELECT count(*)
	    	   INTO $cnt_punish
	           FROM ao_prercv_illegal
	          WHERE ileader = $ileader
	            AND punish = 'Y'
	   	    AND dend >= today
	   	    AND (dexpire IS NULL OR dexpire > today);
	  	
	  	if (cnt_punish > 0)
	  		strcpy(reson_note2,"�޲z�H��ި�W�椺");
	 	else 	  		
	 		strcpy(reson_note2," ");
	}
	if(strcmp(reson_note1," ")==0&&strcmp(reson_note2," ")==0)
	{
	      	return exitsub(reply,M_CM_NOT_FOUND) ? M_CM_NOT_FOUND :apiRC;
	}
	if(strcmp(reson_note1," ")==0)
	{
  		strcpy(reson_note,reson_note2);
	}
	else
	{
		strcat(reson_note1,"\n");
	   	strcat(reson_note1,reson_note2);
	   	strcpy(reson_note,reson_note1);
	} 
	
	strcpy(foccup," ");
	strcpy(noccup," ");
	strcpy(applicant_foccup," ");
	strcpy(applicant_noccup," ");

   }
	
	$SELECT a.itype
	  INTO $ilog_type1
	  FROM ca_log a
	 WHERE a.ipgid = 'car163'
	   AND a.ilog_number2 = '2'
	   AND a.ilog_number1 = $ipolicy_in
	   AND a.dupdate = (SELECT max(b.dupdate)
                              FROM ca_log b
                	     WHERE b.ipgid = a.ipgid
                  	       AND b.ilog_number1 = a.ilog_number1
                  	       AND b.ilog_number2 = a.ilog_number2);
        if(SQLCODE==SQLNOTFOUND) strcpy(ilog_type1,"X1");
	$SELECT a.itype
	  INTO $ilog_type2
	  FROM ca_log a
	 WHERE a.ipgid = 'car163'
	   AND a.ilog_number2 = '3'
	   AND a.ilog_number1 = $ipolicy_in
	   AND a.dupdate = (SELECT max(b.dupdate)
                              FROM ca_log b
                	     WHERE b.ipgid = a.ipgid
                  	       AND b.ilog_number1 = a.ilog_number1
                  	       AND b.ilog_number2 = a.ilog_number2);
        if(SQLCODE==SQLNOTFOUND) strcpy(ilog_type2,"X2");    
        $SELECT a.ilog_number2
	  INTO $ilog_type3
	  FROM ca_log a
	 WHERE a.ipgid = 'car163'
	   AND a.itype = 'O'
	   AND a.ilog_number1 = $ipolicy_in
	   AND a.dupdate = (SELECT max(b.dupdate)
                              FROM ca_log b
                	     WHERE b.ipgid = a.ipgid
                  	       AND b.ilog_number1 = a.ilog_number1
                  	       AND b.ilog_number2 = a.ilog_number2
                  	       AND b.itype = a.itype);
        if(SQLCODE==SQLNOTFOUND) strcpy(ilog_type3,"X3");   
        
   if (strcmp(trim(option1),"1") == 0 && strcmp(trim(ftype),"8") == 0)
   $select first 1 ncontent into $ncontent_open from ca_log where ipgid = 'car163' and ilog_number1 = $ipolicy order by dupdate desc;
   else
   $select first 1 ncontent into $ncontent_open from ca_log where ipgid = 'car163' and ilog_number1 = $ipre_rcv order by dupdate desc;
   if(SQLCODE==SQLNOTFOUND) strcpy(ncontent_open," "); 
   $select first 1 ncontent into $ncontent_verify from ca_log where ipgid = 'car161' and ilog_number1 = $ipolicy order by dupdate desc;
   if(SQLCODE==SQLNOTFOUND) strcpy(ncontent_verify," ");     	       
  
   strcpy(dply_begin,cm_from_infdate_100(dply_begin));
   strcpy(dply_end,cm_from_infdate_100(dply_end));
   strcpy(dentry,cm_from_infdate_100(dentry));
   strcpy(dpolicy,cm_from_infdate_100(dpolicy));
  
   strcpy(icar_type,trim(icar_type));
   if(strcmp(icar_type,"01")==0||strcmp(icar_type,"02")==0||strcmp(icar_type,"31")==0||strcmp(icar_type,"32")==0)
   strcpy(ncar_type,"����");
   else 
   strcpy(ncar_type,"�T��");


	printf("foccup[%s]noccup[%s]applicant_foccup[%s]applicant_noccup[%s]\n",foccup,noccup,applicant_foccup,applicant_noccup);

    cm_buf_init(ReplyBuf);
     cm_buf_put("%l %s %s %s %s %s %s %s %s %s %d %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s ",
	        M_CM_OK,nquota,ipolicy,ipre_rcv,nassured,iassured,iengine,itag,dply_begin,dply_end,mprem,
                iofficer,nofficer,ileader,nleader,dentry,fassured,ncar_type,dpolicy,reson_note,
                foccup,noccup,applicant_foccup,applicant_noccup,option1,ilog_type1,ilog_type2,ilog_type3,ncontent_verify,ncontent_open);
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
       return apiRC;
    else
       return api_OKComplete;

errexit:
  printf("SQLCODE:%d errmsg:%s\n",SQLCODE,sqlca.sqlerrm);
  if(exitsub(reply,SQLCODE) == True)
     return SQLCODE;
  else
     return apiRC;
}

/******************************************************************/
long car163_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 $char DBName[3];

 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0;
 char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
 int raw_len;
 long dummy=0;
 long MsgCode;
 $char userid[11],ipre_rcv[21],type1[2],type2[2],ncontent_open[256];
 $char stmt[1000];
 int   rc,is_upd_fail=0;
 $char stmt_buf[300];

 comm = (char *) command;
 cm_buf_init(command);
printf("123456789\n");
 cm_buf_get("%c %s",&option,DBName);

printf("0000000011111122222\n");

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
    return M_CM_DB_NOTOPEN;
   else
    return apiRC;
  }

 if (option == 'U')
  {
	$BEGIN WORK;
	cm_buf_init(command);
	cm_buf_get("%c %s",&option,DBName);
	cm_buf_get("%s %s %s %s %s",userid,type1,type2,ipre_rcv,ncontent_open);
	printf("type1[%s]\n",type1);
	$WHENEVER SQLERROR CONTINUE;
	strcpy(type1,trim(type1));
	strcpy(type2,trim(type2));
	strcpy(ncontent_open,trim(ncontent_open));
	if(strcmp(type1,"L")==0)
	{
		if(strcmp(type2,"7")==0)
		{
			if(strlen(ncontent_open)==0) strcpy(ncontent_open,"�}��i�L�O��");
			
				sprintf_s(stmt_buf, sizeof stmt_buf, "UPDATE cm_pre_receive SET "
		                                " (fprint_note,dprint_note) "
		                                "      = ('N',NULL) "
		                                "   WHERE iins_cat = 'C' "
		                                "     AND ipre_rcv=? AND iins_kind='2' AND ipre_end=' '");
		                printf("stmt_buf[%s]\n",stmt_buf);
		                $PREPARE cm1 FROM $stmt_buf;
		                $EXECUTE cm1 USING $ipre_rcv;
		
		                if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
		     		{
		                  printf("391391391391\n");
		     		}
		     	        sprintf_s(stmt_buf, sizeof stmt_buf, "insert into ca_log values ('car163','A',?,'1',?,?,current)");
		
		                $PREPARE ca1 FROM $stmt_buf;
		                $EXECUTE ca1 USING $ipre_rcv,$ncontent_open,$userid;	
		                
		                if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
		     		{
		                  printf("391391391391\n");
		     		}
		                 printf("stmt_buf[%s]\n",stmt_buf);  
		} 
		else
		{
			if(strlen(ncontent_open)==0) strcpy(ncontent_open,"�}�񰪭��I�W��");
			
			sprintf_s(stmt_buf, sizeof stmt_buf, "UPDATE cm_risk_preview "
					 "   SET (napprove,dapprove)"
					 "=(?,current)"
					 " WHERE ipolicy1 = ?"
					 "   AND ipolicy2 = ''");
			printf("stmt_buf[%s]\n",stmt_buf);
		        $PREPARE cm2 FROM $stmt_buf;
		        $EXECUTE cm2 USING $ncontent_open,$ipre_rcv;
		        /*�W��{����$ipre_rcv��ȬOipolicy(��client�ݱ���M�w)*/
		        
			if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
		     		{
		                  printf("391391391391\n");
		     		}
		     	
			
			sprintf_s(stmt_buf, sizeof stmt_buf, "insert into ca_log values ('car163','O',?,'D',?,?,current)");
	                $PREPARE ca2 FROM $stmt_buf;
	                $EXECUTE ca2 USING $ipre_rcv,$ncontent_open,$userid;
	                
	        	if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
		     		{
		                  printf("391391391391\n");
		     		}
		     	 printf("stmt_buf[%s]\n",stmt_buf);
		}			     		
	}
	else
	{
			if(strlen(ncontent_open)==0) strcpy(ncontent_open,"�}���J�n�O��");
			
			
			
			
			
		 	sprintf_s(stmt_buf, sizeof stmt_buf, "insert into ca_log values ('car163','A',?,?,?,?,current)");
		
		                $PREPARE ca2 FROM $stmt_buf;
		                $EXECUTE ca2 USING $ipre_rcv,$type2,$ncontent_open,$userid;
		
		                if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
		     		{
		                  printf("391391391391\n");
		     		}
		     	 printf("stmt_buf[%s]\n",stmt_buf);		
	}
	
	cm_buf_init(ReplyBuf);
	cm_buf_put("%l",M_CM_OK);
	tmp_len = cm_buf_len(ReplyBuf);
	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
	{
	$WHENEVER SQLERROR CONTINUE;
	$ROLLBACK WORK;
	return apiRC;
	}
	$WHENEVER SQLERROR GOTO errexit;
	$COMMIT WORK;
	return api_OKComplete;
 }
 else if(option == 'D')
 {
 	$BEGIN WORK;
	cm_buf_init(command);
	cm_buf_get("%c %s",&option,DBName);
	cm_buf_get("%s %s %s %s",userid,type1,type2,ipre_rcv);
	printf("type1[%s]\n",type1);
	$WHENEVER SQLERROR CONTINUE;
	strcpy(type1,trim(type1));
	strcpy(type2,trim(type2));
	if(strcmp(type1,"R")==0)
	{
	sprintf_s(stmt_buf, sizeof stmt_buf, "insert into ca_log values ('car163','D',?,?,'��J�n�O��',?,current)");
	
	                $PREPARE ca2 FROM $stmt_buf;
	                $EXECUTE ca2 USING $ipre_rcv,$type2,$userid;
	
	                if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
	     		{
	                  printf("391391391391\n");
	     		}
	     	 printf("stmt_buf[%s]\n",stmt_buf); 
	}    	  	 
     	cm_buf_init(ReplyBuf);
	cm_buf_put("%l",M_CM_OK);
	tmp_len = cm_buf_len(ReplyBuf);
	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
	{
	$WHENEVER SQLERROR CONTINUE;
	$ROLLBACK WORK;
	return apiRC;
	}
	$WHENEVER SQLERROR GOTO errexit;
	$COMMIT WORK;
	return api_OKComplete;
     	
 }  
  else
  {
   if(exitsub(reply,M_CM_WRONG_OPTION) == True)
    return M_CM_WRONG_OPTION;
   else
    return apiRC;
  }

errexit:
  printf("SQLCODE:%d errmsg:%s\n",SQLCODE,sqlca.sqlerrm);
  $WHENEVER SQLERROR CONTINUE;
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True)
   return MsgCode;
  else
   return apiRC;
}

