/*******************************************/
/*                                         */
/*   PROGRAM : ca701q01s.ec                */
/*                                         */
/*   DATE    : 88.08. 20                   */
/*                                         */
/*   Checked for ����100�~�M��             */
/*******************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "safeclib.h"
extern char RPTDIR[];

$char iassured[13],itag[CA_TAG_NUM],icard[21],iengine[CA_ENGINE_NUM],ibody[CA_BODY_NUM],car_type[3];
$char fcard_class[2],Ccar_type[3],Vcar_type[3],iquota[6];
$char nassured[101],flast[2],iins_item[7];
$char fflast[2],fstl[2];
$char dbgn1[YYYYMMDD],dend1[YYYYMMDD],dply_begin[YYYYMMDD],dply_end[YYYYMMDD];
$char ibrand[9],iissue_ym[7];
$char ipolicy[21],ivictim[11];
$char type1589[4],ilast_ply[21],new_pol[2];

$char iclaim[20];
$long mpremC,mdeductC,mprem11,mprem3,mprem24,mprem2,mprem12;
$long mprem51,mprem14,mpremOTH;
$long tot_mprem,tot_mdiscount,tot_mins_premium;
$long coverC,cover11,cover31,cover32,cover51;

$int  p_flag_close;

$long mprem_stl,mprem_loss;
$long sum_mprem_stl,sum_mprem_loss,sum_cmprem_stl,sum_cmprem_loss;
$long cmprem_stl,cmprem_loss,mprem1_stl,mprem1_loss;
/*$long sum_cprem_stl,sum_cmprem_loss;*/
$long mins_proc = 0,mins_stl = 0,mstl_health = 0;

char tmp_buf[16],dply_begin_1[YYYYMMDD],dply_end_1[YYYYMMDD];
char dply_begin_2[YYYYMMDD],dply_end_2[YYYYMMDD];
char itag_tmp[CA_TAG_NUM],iengine_tmp[CA_ENGINE_NUM],icard_tmp[21],ccar_tmp[3],vcar_tmp[3],nuser_tmp[19];
long mprem1,mpremV,mins_premium1,mins_premiumV;
int  first,flag;
$double plia_acc = 0,pdmg_acc = 0;
$double mcar_price;
$char nuser[19];

$char DBName[5],FormTp[3];
char  outputf[N_FILE+1], userid[6];

static int max_cnt=0;

$int car_cnt=0;

long car701_build();
long car701_detail();
long car701_accumulate();
static char *get_car_full_db();
void car701_body();

#define fmt "---,---,---,---"

/*----------------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
   int rc;

   batchinit();
   strcpy(DBName,    isNULLstr(argv[1]));
   strcpy(userid,    isNULLstr(argv[2]));
   strcpy(iassured,  isNULLstr(argv[3]));
   strcpy(dbgn1,     isNULLstr(argv[4]));
   strcpy(dend1,     isNULLstr(argv[5]));
   strcpy(iquota,    isNULLstr(argv[6]));
   strcpy(outputf,   isNULLstr(argv[7]));

   strcpy(dbgn1, cm_to_infdate(dbgn1));
   strcpy(dend1, cm_to_infdate(dend1));

   rc = car701_build();

   if (rc == api_OKComplete)
   {
         if ((rc=save_form_info(F_FREE, "CA", 701, userid, FormTp, max_cnt,
             outputf))<0)
            EWRITE(userid, rc, "save_form_info failed");
   }
}

/*----------------------------------------------------------------------------*/
long car701_build()
{
   $char  FormFmt[N_FILE+1];
   $int   StartRow, TitleRow, TotColumn, PgLine, Width;

   char   FormFile[N_FILE+1];

   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return FAIL;
   }

   $SELECT nForm_File, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $FormFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width, $FormTp
      FROM Form
     WHERE ksys_grp = "CA" AND kPgmID = 701;
   strcpy(FormFmt, rtrim(FormFmt));
   sprintf_s(FormFile, sizeof FormFile, "%s.tx", outputf);

   /* create & insert data with temp table */
   car701_accumulate();

   /* build report */
   rgu_init_report(FormFmt, FormFile);
   car701_detail();
   rgu_finish_report();

   $DROP TABLE CAR701;

   if (max_cnt == 0)
   {
      EWRITE(userid, M_CM_NOT_FOUND, "no data found in CAR701 !!");
      return FAIL;
   }

   return api_OKComplete;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return FAIL;
}


/*----------------------------------------------------------------------------*/
long car701_accumulate()
{
   $int  i;
   $char tmp_fulldb[50], stmt[1024];
   $char iins_type[7],buf1[100];
   $long mins_premium,mdiscount,mprem,mdeduct;
   $long mapp_loss,cmapp_loss;
   $long minjured_cover,mdeath_cover,mdamage_cover = 0;
   /*$char dpolicy[11];
   $long dpolicy_ln;*/
   $long dpolicy = 0;
   int iquota_len;
   $char stmt_tmp[2048];

   $WHENEVER SQLERROR GOTO errexit;

   sprintf_s(stmt_tmp, sizeof stmt_tmp,"CREATE TEMP TABLE CAR701 "
    "( "
    "  itag              char(%d), "
    "  nuser             char(19), "
    "  iengine           char(%d), "
    "  ipolicy           char(20), "
    "  icard             char(20), "
    "  fcard_class       char(1), "
    "  dply_begin        date, "
    "  dply_end          date, "
    "  type1589          char(3), "
    "  mpremC            integer default 0, "
    "  mdeductC          integer default 0, "
    "  mprem11           integer default 0, "
    "  mprem3            integer default 0, "
    "  mprem24           integer default 0, "
    "  mprem51           integer default 0, "
    "  mprem14           integer default 0, "
    "  mprem2            integer default 0, "
    "  mprem12           integer default 0, "
    "  mpremOTH          integer default 0, "
    "  tot_mprem         integer default 0, "
    "  tot_mins_premium  integer default 0, "
    "  coverC            integer default 0, "
    "  cover31           integer default 0, "
    "  cover32           integer default 0, "
    "  cover51           integer default 0, "
    "  Ccar_type         char(3), "
    "  Vcar_type         char(3), "
    "  sum_mprem_stl     integer default 0, "
    "  sum_mprem_loss    integer default 0, "
    "  sum_cmprem_stl    integer default 0, "
    "  sum_cmprem_loss   integer default 0, "
    "  ibrand            char(8), "
    "  iissue_ym         char(6), "
    "  plia_acc          decimal(5,2) default 0, "
    "  pdmg_acc          decimal(5,2) default 0, "
    "  mcar_price        decimal(5,1) default 0, "
    "  new_policy	    char(2) "
    ") WITH NO LOG;",CA_TAG_NUM-1,CA_ENGINE_NUM-1);
     $PREPARE stmp FROM $stmt_tmp;
     $EXECUTE stmp;

   i = 0;

   $SELECT nchi_full
      INTO $nassured
      FROM cu_customer
     WHERE ifpce_id = $iassured
       AND ifpce_id_ext = ' ';

   if (SQLCODE == SQLNOTFOUND)
   {
       EWRITE(userid, M_CM_NOT_FOUND, "�ȪA�ɵL���Ȥ�s��!!");
       exit(1);
   }

   iquota_len = strlen( rtrim(iquota));
   printf("iquota[%s] len[%d]\n",iquota,iquota_len);
   printf("iquota[4]=[%s]\n",substring(iquota,4,1));

   switch ( iquota_len )
   {
   	case 1:
   	   sprintf_s(buf1, sizeof buf1," ");
   	   break;
   	case 3:
   	   sprintf_s(buf1, sizeof buf1,"AND b.iquota[1,2] = '%s'",substring(iquota,1,2));
   	   break;
   	case 5:
   	   if( iquota[4] == '*')
   	   {
   	   	printf("iquota[%s]\n",substring(iquota,1,4));
   	   	sprintf_s(buf1, sizeof buf1,"AND b.iquota[1,4] = '%s'",substring(iquota,1,4));
   	   }
   	   else sprintf_s(buf1, sizeof buf1,"AND b.iquota = '%s'",iquota);
   	   break;
   	default:
   	   sprintf_s(buf1, sizeof buf1," ");
   	   break;
   }

/*   SELECT itag, iengine, ibody, ipolicy, icard, fcard_class
       INTO $itag, $iengine, $ibody, $ipolicy, $icard, $fcard_class
       FROM assured_vs_ply
      WHERE iassured = $iassured; */

   sprintf_s(stmt, sizeof stmt,"SELECT a.itag, a.iengine, a.ibody, a.ipolicy, a.icard, "
                "        a.fcard_class  "
                " FROM assured_vs_ply a, ply_relation b  "
                "WHERE a.iassured = ? AND a.ipolicy = b.ipolicy %s",buf1 );

   printf("stmt [%s]\n",stmt);

   $PREPARE Acur FROM $stmt;
   $DECLARE cur1 CURSOR for Acur;
   $OPEN cur1 USING $iassured;

   while(1)
   {
      $FETCH cur1 INTO $itag, $iengine, $ibody, $ipolicy, $icard, $fcard_class;

      if(SQLCODE == SQLNOTFOUND) break;

      trim_tail_white(ipolicy);

printf("\n\nipolicy[%s]\n", ipolicy);

      strcpy(tmp_fulldb, get_car_full_db(ipolicy));

printf("tmp_fulldb[%s]\n", tmp_fulldb);

      if (strlen(trim(iengine))==0)
      {
           printf("�L�������X!!\n");
           strcpy(iengine,ibody);
      }

      /*********************/
      /* �O��ͮĤ�&����� */
      /*********************/
      mcar_price = 0;
      sprintf_s(stmt, sizeof stmt,"SELECT a.dply_begin, a.dply_end, a.icar_type, a.ibrand,  "
                    "       to_char(b.dissue,'%%Y')::integer - 1911 || '/' || to_char(b.dissue,'%%m'),  "
                    "       b.nuser, b.plia_acc, b.pdmg_acc, b.mcar_price, a.ilast_ply, a.dpolicy  "
                    "  FROM %s:ply_relation a,%s:policy b  "
                    " WHERE a.ipolicy=b.ipolicy  "
                    "   AND a.ipolicy = ?  "
                    "   AND a.dpolicy BETWEEN ? AND ? ;", tmp_fulldb,tmp_fulldb);

      $PREPARE stmt_dply FROM $stmt;
      $DECLARE cur_dply  CURSOR FOR stmt_dply;
      $OPEN cur_dply USING $ipolicy, $dbgn1, $dend1;
      $FETCH cur_dply INTO $dply_begin,$dply_end,$car_type,$ibrand,$iissue_ym,
                           $nuser,$plia_acc,$pdmg_acc,$mcar_price,$ilast_ply,$dpolicy;

      if (SQLCODE == SQLNOTFOUND)
      {
     /*     printf("===== select ply_relation[%s] not found\n",ipolicy);  */
          $CLOSE cur_dply;
          $FREE cur_dply;
          continue;
      }
      printf("mcar_price[%f]\n",mcar_price);
      strcpy(nuser, trim(nuser));
      printf("nuser[%s]", nuser);
      printf("plia_acc[%lf]", plia_acc);
      printf("pdmg_acc[%lf]", pdmg_acc);


      /*** �P�_���اO ***/
      if (strcmp(trim(fcard_class), "2")==0)
      {
           strcpy(Ccar_type," ");
           strcpy(Vcar_type,trim(car_type));
      }
      else
      {
           strcpy(Ccar_type ,trim(car_type));
           strcpy(Vcar_type ," ");
      }

      $CLOSE cur_dply;
      $FREE cur_dply;

      if( ( strcmp(trim(fcard_class), "2")== 0) && (strlen(trim(ilast_ply)) == 0 ))
      {
      	   strcpy( new_pol , "Y" );
      }
      else if(( strcmp(trim(fcard_class), "2")== 0) && (strlen(trim(ilast_ply)) != 0 ))
      {
      	   strcpy( new_pol , "N" );
      }
      else
      {
      	  /* �j�� do nothing */
      }

      mpremC = mdeductC = mprem11 = mprem3 = mprem24 = mprem51 = 0;
      mprem14 = mprem2 = mprem12 = mpremOTH = 0;
      mdeduct = mins_premium = mdiscount = mprem = 0;
      coverC = cover11 = cover31 = cover32 = cover51 =0;

      type1589[0]='\0';
      mdeductC = 0;
      cmprem_stl = cmprem_loss = 0;
      mprem_stl  = mprem_loss  = 0;
      mapp_loss  = cmapp_loss  = 0;

      tot_mprem = tot_mdiscount = tot_mins_premium = 0;
      sum_mprem_loss  = sum_mprem_stl  = 0;
      sum_cmprem_loss = sum_cmprem_stl = 0;

      /**************/
      /* �U�I�ثO�O */
      /**************/
/*--910505
      sprintf_s(stmt, sizeof stmt,"SELECT iins_type, mins_premium  "
                    "  FROM %s:ply_ins_type  "
                    " WHERE ipolicy = ? ;", tmp_fulldb);
      $PREPARE pr1  FROM  $stmt;
      $DECLARE cur2 CURSOR FOR pr1;
      $OPEN    cur2 USING $ipolicy;*/

      if (dpolicy < 37346)
      {
          sprintf_s(stmt, sizeof stmt,"SELECT iins_type, minjured_cover, mdeath_cover, mdamage_cover,  "
                        "       mdeduct, mins_premium as mprem, mins_premium - mdiscount as mins_premium  "
                        "  FROM %s:ply_ins_type  "
                        " WHERE ipolicy = ? ;", tmp_fulldb);
      }
      else
      {
          sprintf_s(stmt, sizeof stmt,"SELECT iins_type, minjured_cover, mdeath_cover, mdamage_cover,  "
                        "       mdeduct, mins_premium as mprem, mins_premium  "
                        "  FROM %s:ply_ins_type  "
                        " WHERE ipolicy = ? ;", tmp_fulldb);
      }
      $PREPARE pr1  FROM  $stmt;
      $DECLARE cur2 CURSOR FOR pr1;
      $OPEN    cur2 USING $ipolicy;
      while (1)
      {
           $FETCH cur2 INTO $iins_type, $minjured_cover, $mdeath_cover, $mdamage_cover,
                            $mdeduct, $mprem, $mins_premium;
           if (SQLCODE == SQLNOTFOUND) break;

        /* cmprem_stl =  */
           cmprem_loss = 0;
           mprem_stl  = mprem_loss  = 0;
           mapp_loss  = cmapp_loss  = 0;
           flast[0]  = '\0';
           fflast[0] = '\0';
           strcpy( iins_type, trim( iins_type));
           
           car_cnt = 0;
           
           $SELECT count(*)
              INTO $car_cnt
	      FROM cu_code_data a,insurance_type b
	     WHERE a.icode = b.iins_type
	       AND a.itype = 'SH'
	       AND b.iins_ply = $iins_type;

           if (strcmp(iins_type,"21")==0)
           {
                printf("21�j���Imprem[%ld]\n", mprem);
           }
           else if (car_cnt > 0)
           {
                strcpy(type1589,trim(iins_type));
                mpremC = mprem;
                mdeductC = mdeduct;
                coverC = mdamage_cover;
           }
           else if (strcmp(iins_type,"11")==0)
           {
                mprem11 = mprem;
                cover11 = mdamage_cover;
           }
           else if (strcmp(iins_type,"31")==0||strcmp(iins_type,"32")==0)
           {
                mprem3 = mprem3 + mprem;
                if (strcmp(iins_type,"31")==0)
                {
                    cover31 = mdamage_cover;
                }
                else if (strcmp(iins_type,"32")==0)
                {
                    cover32 = mdamage_cover;
                }
           }
           else if (strcmp(iins_type,"24")==0)
           {
                mprem24 = mprem;
           }
           else if (strcmp(iins_type,"51")==0)
           {
                mprem51 = mprem;
                cover51 = mdamage_cover;
           }
           else if (strcmp(iins_type,"14")==0)
           {
                mprem14 = mprem;
           }
           else if (strcmp(iins_type,"02")==0)
           {
                mprem2 = mprem;
           }
           else if (strcmp(iins_type,"12")==0)
           {
                mprem12 = mprem;
           }
           else
           {
                mpremOTH = mpremOTH + mprem;
           }

           if (strcmp(trim(fcard_class),"2")==0)  /*** ���N�I�w���M�ߴ� ***/
           {
                 /**** �������I�عw����� ****/
                 /**** �P�@�i�O��P�@�I�إi��X�I�⦸�H�W,�G�����߮ץhselect ****/
                 sprintf_s(stmt, sizeof stmt,"SELECT a.iclaim , b.mins_app  "
                               "  FROM %s:appraisal a, %s:app_ins_type b  "
                               " WHERE a.iclaim  = b.iclaim  "
                               "   AND a.ipolicy = '%s'  "
                               "   AND b.iins_type = '%s'",
                         tmp_fulldb, tmp_fulldb, ipolicy, iins_type);

                 $PREPARE pr3 FROM $stmt;
                 EXEC SQL DECLARE v_loss_cur CURSOR FOR pr3;
                 EXEC SQL OPEN    v_loss_cur;
                 for(;;)
                 {
                     EXEC SQL FETCH v_loss_cur  INTO :iclaim , :mapp_loss;
                     if (SQLCODE == SQLNOTFOUND) break;

                     mprem_stl = 0;
                     mprem_loss = 0;
                     flast[0]  = '\0';
                     fflast[0] = '\0';
                     p_flag_close = 0;

                     sprintf_s(stmt, sizeof stmt,"SELECT %s FROM %s:%s WHERE %s",
                                  "fstl, mins_stl, mins_proc, flast",
                                  tmp_fulldb,"stl_ins_type",
                                  "iclaim = ? AND iins_type = ? AND dgroup is not null");

                     EXEC SQL PREPARE STLINS_CUR FROM :stmt;
                     EXEC SQL DECLARE ins_stl_cur CURSOR FOR STLINS_CUR;
                     EXEC SQL OPEN    ins_stl_cur USING :iclaim, :iins_type;

                     for (;;)
                     {
                          EXEC SQL FETCH ins_stl_cur INTO :fstl, :mins_stl, :mins_proc, :flast;

                          if (SQLCODE == SQLNOTFOUND) break;

                          if (flast[0] == '1')
                          {
                              p_flag_close = 1;
                          }

                          if (fstl[0] == '1')
                               mprem_stl += (mins_stl + mins_proc);
                          else if (fstl[0]=='2')
                               mprem_stl -= (mins_stl - mins_proc);
                     }
                     EXEC SQL CLOSE ins_stl_cur;

                     if (p_flag_close == 0) /*** �����סA�����M ***/
                     {
                         mprem_loss = mapp_loss - mprem_stl; /*** ���M���B ***/
                         if (mprem_loss < 0)
                             mprem_loss = 0;
                     }

                     sum_mprem_loss += mprem_loss;  /*** �X�p���M���B ***/
                     sum_mprem_stl  += mprem_stl;   /*** �X�p�v�M���B ***/
printf(" sum_mprem_loss [%d] \n ",sum_mprem_loss);
                 }
                 EXEC SQL CLOSE   v_loss_cur;

           }
           else
           {
                 /**** ���������`�H�w����� ****/
                 /**** �P�@�i�O��i��P�ɦh�H�X�I,�P�@�H���h�ص��I���ءA�G�����߮ץhselect ****/
                 sprintf_s(stmt, sizeof stmt,"SELECT a.iclaim , b.mapp_cover , b.ivictim , b.iins_item  "
                                " FROM %s:appraisal a, %s:ca_app_victim b  "
                                "WHERE a.iclaim  = b.iclaim  "
                                "  AND a.ipolicy = '%s' ",tmp_fulldb, tmp_fulldb, ipolicy);

                 $PREPARE pr4 FROM $stmt;
                 EXEC SQL DECLARE c_loss_cur CURSOR FOR pr4;
                 EXEC SQL OPEN    c_loss_cur;

                 for(;;)
                 {
                     EXEC SQL FETCH c_loss_cur  INTO :iclaim , :cmapp_loss , :ivictim , :iins_item;
                     if (SQLCODE == SQLNOTFOUND) break;

                        cmprem_stl = 0;
                        cmprem_loss = 0;
                     flast[0]  = '\0';
                     fflast[0] = '\0';
                     p_flag_close = 0;

                     sprintf_s(stmt, sizeof stmt,"SELECT %s FROM %s:%s WHERE %s",
                                  "fstl, mins_stl, mins_proc, mstl_health, flast",
                                  tmp_fulldb,"ca_stl_victim",
                                  "iclaim = ? AND ivictim = ? AND iins_item = ? AND dgroup is not null");

                     EXEC SQL PREPARE CASTL_CUR FROM :stmt;
                        EXEC SQL DECLARE ca_stl_cur CURSOR FOR CASTL_CUR;
                        EXEC SQL OPEN    ca_stl_cur USING :iclaim, :ivictim, :iins_item;

                     for (;;)
                     {
                          EXEC SQL FETCH ca_stl_cur INTO :fstl, :mins_stl, :mins_proc, :mstl_health, :flast;

                          if (SQLCODE == SQLNOTFOUND) break;

                          if (flast[0] == '2')
                          {
                              p_flag_close = 1;
                          }

                          if (flast[0] == '1')
                          {
                              strcpy(fflast,"Y");
                          }

                          if (flast[0] == '1' && iins_item[0] == 'B')
                          {
                              p_flag_close=1;
                          }

                          if (flast[0] == '1' && iins_item[0] == 'C')
                          {
                             p_flag_close=1;
                          }

                          if (fstl[0] == '1')
                                cmprem_stl += (mins_stl + mins_proc + mstl_health);
                          else if (fstl[0]=='2')
                               cmprem_stl -= (mins_stl - mins_proc + mstl_health);

                     }
                     EXEC SQL CLOSE ca_stl_cur;

                     /*******�K�ߵ���***********/
                    if ( cmprem_stl == 0 && fflast[0] == 'Y')
                    {
                       p_flag_close = 1;
                    }

                    if (p_flag_close == 0) /*** �����סA�����M ***/
                     {
                         cmprem_loss = cmapp_loss - cmprem_stl; /*** ���M���B ***/
                         if (cmprem_loss < 0)
                             cmprem_loss = 0;
                     }
                     sum_cmprem_loss += cmprem_loss;  /*** �X�p���M���B ***/
                     sum_cmprem_stl  += cmprem_stl;   /*** �X�p�v�M���B ***/
printf("sum_cmprem_loss [%d] sum_cmprem_stl [%d] \n ",sum_cmprem_loss,sum_cmprem_stl);
                 }
                 EXEC SQL CLOSE   c_loss_cur;

           }

           /* tot_mprem�O�O�X�p tot_mdiscount�����X�p tot_mins_premium�����O�O�X�p*/
           tot_mprem = tot_mprem + mprem;
           /*tot_mdiscount = tot_mdiscount + mdiscount;*/
           tot_mins_premium = tot_mins_premium + mins_premium;
      }
      $CLOSE cur2;
      $FREE  cur2;

      if (coverC == 0)
      {
          coverC = cover11;
      }

      /*********************/
      /* �O���� TEMP TABLE */
      /*********************/
printf("INSERT INTO TEMP TABLE!!\n");
      $INSERT INTO CAR701
             (itag,nuser,iengine,ipolicy,icard,
              fcard_class,dply_begin,dply_end,type1589,
              mpremC,mdeductC,mprem11,mprem3,mprem24,mprem51,
              mprem14,mprem2,mprem12,mpremOTH,tot_mprem,tot_mins_premium,
              coverC,cover31,cover32,cover51,
              Ccar_type,Vcar_type,sum_mprem_stl,
              sum_mprem_loss,sum_cmprem_stl,sum_cmprem_loss,ibrand,iissue_ym,
              plia_acc,pdmg_acc,mcar_price,new_policy)
       VALUES ($itag,$nuser,$iengine,$ipolicy,$icard,
               $fcard_class,$dply_begin,$dply_end,$type1589,
               $mpremC,$mdeductC,$mprem11,$mprem3,$mprem24,$mprem51,
               $mprem14,$mprem2,$mprem12,$mpremOTH,$tot_mprem,$tot_mins_premium,
               $coverC,$cover31,$cover32,$cover51,
               $Ccar_type,$Vcar_type,$sum_mprem_stl,
               $sum_mprem_loss,$sum_cmprem_stl,$sum_cmprem_loss,$ibrand,$iissue_ym,
               $plia_acc,$pdmg_acc,$mcar_price,$new_pol);

      printf("plia_acc[%lf]\n", plia_acc);
      i++;

printf("i=[%d]\n",i);

   }  /*  end of while */
   $CLOSE cur1;
   $FREE cur1;

printf("\nSUM i=[%d]\n",i);
     if(i == 0)
       {
        EWRITE(userid, M_CM_NOT_FOUND, "�L���O��O����!!");
        exit(1);
       }
     else
        return SUCCESS;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(1);
}

/*----------------------------------------------------------------------------*/
long car701_detail()
{
  int i;

  first = 1; flag = 0;

  rgu_put_body_string(1, dbgn1 ,1);
  rgu_put_body_string(1, dend1 ,1);
  rgu_put_body_string(1, iassured ,1);
  rgu_put_body_string(1, nassured ,1);
  rgu_put_body(1); max_cnt += 5;

printf("\ncar701_detail START!!\n");
   $WHENEVER SQLERROR GOTO errexit;

   $DECLARE cursor CURSOR FOR
     SELECT itag,nuser,iengine,icard,ipolicy,fcard_class,
            dply_begin,dply_end,type1589,
            mpremC,mdeductC,mprem11,mprem3,mprem24,mprem51,
            mprem14,mprem2,mprem12,mpremOTH,tot_mprem,tot_mins_premium,
            coverC,cover31,cover32,cover51,
            Ccar_type,Vcar_type,sum_mprem_stl,
            sum_mprem_loss,sum_cmprem_stl,sum_cmprem_loss,ibrand,iissue_ym,
            plia_acc,pdmg_acc,mcar_price,new_policy
       INTO $itag,$nuser,$iengine,$icard,$ipolicy,$fcard_class,
            $dply_begin,$dply_end,$type1589,
            $mpremC,$mdeductC,$mprem11,$mprem3,$mprem24,$mprem51,
            $mprem14,$mprem2,$mprem12,$mpremOTH,$tot_mprem,$tot_mins_premium,
            $coverC,$cover31,$cover32,$cover51,
            $Ccar_type,$Vcar_type,$sum_mprem_stl,
            $sum_mprem_loss,$sum_cmprem_stl,$sum_cmprem_loss,$ibrand,$iissue_ym,
            $plia_acc,$pdmg_acc,$mcar_price,$new_pol
       FROM CAR701
   ORDER BY iengine, fcard_class;

   $OPEN cursor;

   while(1) {

     $FETCH cursor;
     if (SQLCODE == SQLNOTFOUND) break;
printf("ipolicy [%s]   \n", ipolicy , sum_cmprem_loss);
printf("sum_cmprem_stl [%d] sum_cmprem_loss [%d]\n",sum_cmprem_stl,sum_cmprem_loss);
printf("sum_mprem_stl  [%d] sum_mprem_loss  [%d]\n",sum_mprem_stl,sum_mprem_loss);

       if (first==1)
       {
         strcpy(itag_tmp,itag);
         strcpy(iengine_tmp,iengine);
         strcpy(nuser_tmp,nuser);
         if (fcard_class[0]=='1')
         {
           strcpy(icard_tmp,icard);
           strcpy(dply_begin_1,dply_begin);
           strcpy(dply_end_1,dply_end);
           strcpy(ccar_tmp,Ccar_type);
           mprem1 = tot_mprem;
           mins_premium1 = tot_mins_premium;
           mprem1_stl = sum_cmprem_stl;
           mprem1_loss = sum_cmprem_loss;

           flag = 1;
         }
         else
         {
           icard_tmp[0]='\0'; dply_begin_1[0]='\0'; dply_end_1[0]='\0';
           mprem1 = 0;
           mins_premium1 = 0;
           mprem1_stl = 0;
           mprem1_loss =0;
           mpremV = tot_mprem;
           mins_premiumV = tot_mins_premium;
           strcpy(vcar_tmp,Vcar_type);
           strcpy(dply_begin_2,dply_begin);
           strcpy(dply_end_2,dply_end);

           car701_body();
         }

         first = 0;
         continue;
       }

       if (flag==0) /* �L�Ȧs */
       {
         strcpy(itag_tmp,itag);
         strcpy(iengine_tmp,iengine);
         strcpy(nuser_tmp,nuser);

         if (fcard_class[0]=='1')
         {
           strcpy(icard_tmp,icard);
           strcpy(ccar_tmp,Ccar_type);
           strcpy(dply_begin_1,dply_begin);
           strcpy(dply_end_1,dply_end);
           mprem1 = tot_mprem;
           mins_premium1 = tot_mins_premium;
           mprem1_stl = sum_cmprem_stl;
           mprem1_loss = sum_cmprem_loss;
           flag =1;
         }
         else
         {
           icard_tmp[0]='\0'; dply_begin_1[0]='\0'; dply_end_1[0]='\0';ccar_tmp[0]='\0';
           mprem1 = 0;
           mins_premium1 = 0;
           mprem1_stl = 0;
           mprem1_loss = 0;
           mpremV = tot_mprem;
           mins_premiumV = tot_mins_premium;
           strcpy(vcar_tmp,Vcar_type);
           strcpy(dply_begin_2,dply_begin);
           strcpy(dply_end_2,dply_end);

           car701_body(); flag =0;
         }
       }
       else /* ���Ȧs */
       {
         if (fcard_class[0]=='1')
         {
           ipolicy[0]='\0'; dply_begin_2[0]='\0'; dply_end_2[0]='\0';vcar_tmp[0]='\0';
           mpremC = mdeductC = mprem11 = mprem3 = mprem24 = mprem51 = 0;
           mprem14 = mprem2 = mprem12 = mpremOTH = mprem_stl = mprem_loss = 0;
           mpremV = mins_premiumV = 0;
           coverC = cover31 = cover32 = cover51 = 0;

           car701_body();

           strcpy(itag_tmp,itag);
           strcpy(nuser_tmp,nuser);
           strcpy(iengine_tmp,iengine);
           strcpy(icard_tmp,icard);
           strcpy(ccar_tmp,Ccar_type);
           strcpy(dply_begin_1,dply_begin);
           strcpy(dply_end_1,dply_end);
           mprem1 = tot_mprem;
           mins_premium1 = tot_mins_premium;
           mprem1_stl = sum_cmprem_stl;
           mprem1_loss = sum_cmprem_loss;

           flag =1;
         }
         else
         {
           if (strcmp(iengine_tmp,iengine)==0)
           {
             mpremV = tot_mprem;
             mins_premiumV = tot_mins_premium;
             strcpy(dply_begin_2,dply_begin);
             strcpy(dply_end_2,dply_end);
             strcpy(vcar_tmp,Vcar_type);
             strcpy(itag_tmp,itag);
             strcpy(nuser_tmp,nuser);
             strcpy(iengine_tmp,iengine);
             car701_body(); flag =0;
           }
           else
           {
             rgu_put_body_string(2, itag_tmp, 2);
             rgu_put_body_string(2, nuser_tmp, 1);
             rgu_put_body_string(2, ccar_tmp, 2);
             rgu_put_body_string(2, iengine_tmp, 2);
             rgu_put_body_string(2, icard_tmp, 2);
             rgu_put_body_string(2, dply_begin_1, 2);
             rgu_put_body_string(2, dply_end_1, 2);
             rfmtlong(mprem1, fmt, tmp_buf);
             rgu_put_body_string(2, tmp_buf, 2);
             rfmtlong(mprem1_stl, fmt, tmp_buf);
             rgu_put_body_string(2, tmp_buf, 2);
             rfmtlong(mprem1_loss, fmt, tmp_buf);
             rgu_put_body_string(2, tmp_buf, 2);

             for(i=0;i<14;i++) rgu_put_body_string(2, 0x00, 2);
             rgu_put_body(2); max_cnt++;

             icard_tmp[0]='\0'; dply_begin_1[0]='\0'; dply_end_1[0]='\0';ccar_tmp[0]='\0';
             mprem1 = 0;
             mins_premium1 = 0;
             mprem1_stl =0;
             mprem1_loss = 0;
             mpremV = tot_mprem;
             mins_premiumV = tot_mins_premium;
             strcpy(dply_begin_2,dply_begin);
             strcpy(dply_end_2,dply_end);
             strcpy(vcar_tmp,Vcar_type);
             strcpy(itag_tmp,itag);
             strcpy(nuser_tmp,nuser);
             strcpy(iengine_tmp,iengine);
             car701_body(); flag =0;
           }
         }
       }
   }
   $CLOSE cursor;
   $FREE  cursor;

   if (flag==1)
   {
     rgu_put_body_string(2, itag_tmp, 2);
     rgu_put_body_string(2, nuser_tmp, 1);
     rgu_put_body_string(2, ccar_tmp, 2);
     rgu_put_body_string(2, iengine_tmp, 2);
     rgu_put_body_string(2, icard_tmp, 2);
     rgu_put_body_string(2, dply_begin_1, 2);
     rgu_put_body_string(2, dply_end_1, 2);
     rfmtlong(mprem1, fmt, tmp_buf);
     rgu_put_body_string(2, tmp_buf, 2);
     rfmtlong(mprem1_stl, fmt, tmp_buf);
     rgu_put_body_string(2, tmp_buf, 2);
     rfmtlong(mprem1_loss, fmt, tmp_buf);
     rgu_put_body_string(2, tmp_buf, 2);

     for(i=0;i<14;i++) rgu_put_body_string(2, 0x00, 2);
     rgu_put_body(2); max_cnt++;
   }

   return SUCCESS;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(1);
}

/*----------------------------------------------------------------------------*/
char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  char sTmp_db_name[21];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
  }
  return sTmp_db_name;
}

/*----------------------------------------------------------------------------*/
void car701_body()
{
  char buf[19];

printf("IN car701_body\n");

  rgu_put_body_string(2, itag_tmp, 2);
  rgu_put_body_string(2, nuser_tmp, 1);
  rgu_put_body_string(2, ccar_tmp, 2);
  rgu_put_body_string(2, iengine_tmp, 2);
  rgu_put_body_string(2, icard_tmp, 2);
  rgu_put_body_string(2, dply_begin_1, 2);
  rgu_put_body_string(2, dply_end_1, 2);
  rfmtlong(mprem1, fmt, tmp_buf);
  rgu_put_body_string(2, tmp_buf, 2);
  rfmtlong(mprem1_stl, fmt, tmp_buf);
  rgu_put_body_string(2, tmp_buf, 2);
  rfmtlong(mprem1_loss, fmt, tmp_buf);
  rgu_put_body_string(2, tmp_buf, 2);
  rgu_put_body_string(2, ipolicy, 2);
  rgu_put_body_string(2, vcar_tmp, 2);
  rgu_put_body_string(2, dply_begin_2, 2);
  rgu_put_body_string(2, dply_end_2, 2);
/*910505
  if (mpremC>0) {
printf("type1589[%s]mpremC[%ld]\n", type1589, mpremC);
    strcpy(buf,type1589);
    strcat(buf,"/");
    rfmtlong(mpremC, fmt, tmp_buf);
    strcat(buf,trim(tmp_buf));
    rgu_put_body_string(2, buf, 2);
  } else {
    rgu_put_body_string(2, "  ", 2);
  }*/
  if (mpremC>0) {
printf("type1589[%s]mpremC[%ld]\n", type1589, mpremC);
    strcpy(buf,type1589);
    rgu_put_body_string(2, buf, 2);
    rfmtlong(mpremC, fmt, tmp_buf);
    rgu_put_body_string(2, tmp_buf, 2);
    rfmtlong(mdeductC, fmt, tmp_buf);
    rgu_put_body_string(2, tmp_buf, 2);
  }
  else
  {
    rgu_put_body_string(2, " ", 2);
    rgu_put_body_string(2, " ", 2);
    rgu_put_body_string(2, " ", 2);
  }

  rfmtlong(mprem11, fmt, tmp_buf);
  rgu_put_body_string(2, tmp_buf, 2);
  rfmtlong(mprem3, fmt, tmp_buf);
  rgu_put_body_string(2, tmp_buf, 2);
  rfmtlong(mprem24, fmt, tmp_buf);
  rgu_put_body_string(2, tmp_buf, 2);
  rfmtlong(mprem51, fmt, tmp_buf);
  rgu_put_body_string(2, tmp_buf, 2);
  rfmtlong(mprem14, fmt, tmp_buf);
  rgu_put_body_string(2, tmp_buf, 2);
  rfmtlong(mprem2, fmt, tmp_buf);
  rgu_put_body_string(2, tmp_buf, 2);
  rfmtlong(mprem12, fmt, tmp_buf);
  rgu_put_body_string(2, tmp_buf, 2);
  rfmtlong(mpremOTH, fmt, tmp_buf);
  rgu_put_body_string(2, tmp_buf, 2);
  rfmtlong(mpremV, fmt, tmp_buf);
  rgu_put_body_string(2, tmp_buf, 2);
  rfmtlong(sum_mprem_stl, fmt, tmp_buf);
  rgu_put_body_string(2, tmp_buf, 2);
  rfmtlong(sum_mprem_loss, fmt, tmp_buf);
  rgu_put_body_string(2, tmp_buf, 2);
  rgu_put_body_string(2,ibrand,2);
  rgu_put_body_string(2,iissue_ym,2);
  printf("plia_acc[%lf]\n", plia_acc);
  /*rfmtdouble(plia_acc, fmt, tmp_buf);
  rgu_put_body_string(2, tmp_buf, 2);
  rfmtdouble(pdmg_acc, fmt, tmp_buf);
  rgu_put_body_string(2, tmp_buf, 2); */
  rfmtdouble(plia_acc, "---,----&.--", tmp_buf);
  rgu_put_body_string(2, tmp_buf, 1);
  rfmtdouble(pdmg_acc, "---,---&.--", tmp_buf);
  rgu_put_body_string(2, tmp_buf, 1);
  rfmtdouble(mcar_price, "----&.&",tmp_buf);
  rgu_put_body_string(2, tmp_buf, 1);
  rgu_put_body_string(2, new_pol, 1);
  rfmtlong(coverC, fmt, tmp_buf);
  rgu_put_body_string(2, tmp_buf, 2);
  rfmtlong(cover31, fmt, tmp_buf);
  rgu_put_body_string(2, tmp_buf, 2);
  rfmtlong(cover32, fmt, tmp_buf);
  rgu_put_body_string(2, tmp_buf, 2);
  rfmtlong(cover51, fmt, tmp_buf);
  rgu_put_body_string(2, tmp_buf, 2);
  rfmtlong(mins_premiumV, fmt, tmp_buf);
  rgu_put_body_string(2, tmp_buf, 2);

  rgu_put_body(2); max_cnt++;
}
