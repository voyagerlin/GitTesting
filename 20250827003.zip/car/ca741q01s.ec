/**********************************************************************/
/*   program id   : ca741q01s.ec                                      */
/*   program name : �O�T�I��O���Ӹ��                                    */
/*   date written : 2022/02/17                               */
/*   files        :                                                   */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <decimal.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "globdata.h"

static char *get_car_full_db(); 
$char qry_iassured[11],qry_iroute[21];
$char dbgn[11],dbgn_q[21];
$char dend[11],dend_q[21];
$char option1[2];
$char stmpx[128];

int   count_db,k; 
char  outputf[21];
$char userid[11];
$char DBName[05];
$char msgbuf[128];

DBinfo *list;

main(argc, argv)
int argc;
char **argv;
{
    int rc;

    batchinit();
    strcpy(DBName,        isNULLstr(argv[1]));
    strcpy(userid,        isNULLstr(argv[2]));
    strcpy(qry_iassured,  isNULLstr(argv[3])); /* �Τ@�s��*/
    strcpy(qry_iroute,    isNULLstr(argv[4])); /* �q���N��*/
    strcpy(option1,       isNULLstr(argv[5])); /* 1.(�D�O��)�O������  OR  2.(���)ñ����   */
    strcpy(dbgn,          isNULLstr(argv[6])); 
    strcpy(dend,          isNULLstr(argv[7]));
    strcpy(outputf,       isNULLstr(argv[8]));
    rc = car741_get_db();
    if (rc != M_CM_OK)
        return rc;

    rc = car741_prepare_data();
    if (rc != M_CM_OK)
        return rc;

    rc = car741_build();
    if (rc != M_CM_OK) 
        return rc;
}

long car741_get_db()
{
    $whenever sqlerror goto errexit;

    if (db_select(DBName) == FALSE) {
        EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
        return M_CM_DB_NOTOPEN;
    }

    if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
        if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
            return M_CM_NOT_DBLIST;
    }	
    return M_CM_OK;

    errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

long car741_prepare_data()
{
    $char igroup[11],ngroup[21],fcard_class[2],imgr[2],iroute[21],iclass[2];
    $int qorder = 0,cnt = 0;
    $char stmt[8192],stmp1[128],stmp2[1024],stmp3[1024],stmp4[2048],stmp5[1024];
    $char sFullName[21];
    $char tmp_fulldb[21];
    
    $char    sql_ipolicy_ext[21]  ,sql_iassured[11]    ,sql_nassured[121]  , sql_dply_begin_ext[11], sql_dply_end_ext[11];
    $char    sql_icar_flag[2]     ,sql_iparts[2];
    
    $char    sql_dpolicy[11]      ,sql_ipolicy[21]     ,sql_ilast_ply[21]  , sql_irelative_ext[21] , sql_dply_begin[11]   , sql_dply_end[11];
    $char    sql_nowner[121]      ,sql_itel[21]        ,sql_itel_night[21] , sql_mobil_phone[21]   , sql_aassured[91];
    $char    sql_iowner[13]       ,sql_dbirth_owner[11],sql_itag[13];
    $char    sql_iengine[26]      ,sql_nbrand_abbr[13] ,sql_ibrand[9]      , sql_nbrand[31]        , sql_icar_type[3];
    $char    sql_ipro_year[5]     ,sql_dissue[11]      ,sql_fpt[2] ;
    $char    sql_fnequipment      ,sql_iins_type[7]    ,sql_nins_type[29] ;
    $char    sql_mins_premium[101],sql_irisk[2]        ,sql_iins_type_list[101], sql_iofficer[11];
    $char    sql_ileader[11]      ,sql_iquota[7]       ,sql_ireg_no[21]    , sql_iroute[21]        , sql_dply_close[11];
    $char    sql_iendorse[21]     ,sql_dedr_begin[11]  ,sql_dedr_end[11]   , sql_dendorse[21]      , sql_fedr_class[2];
    $char    sql_drate_ym[5];
    
    $int     sql_qperiod         ,sql_qpro_month        ,sql_qmiles          ,sql_mcover1         ,sql_mcover2          ,sql_qperiod_ori       , sql_qmiles_ori    , sql_mdeduct ;
    $double  sql_mkilo_ply       , sql_mkilo_edr ;
    $double  sql_qcylinder       ,sql_qpt            ,sql_mcar_price      ,sql_mequipment        ,sql_mdamage_cover;

    sql_qperiod =0;     sql_qmiles  =0;     sql_mcover1 =0;     sql_mcover2 =0;       sql_qperiod_ori =0;
    sql_qmiles_ori =0;  sql_mdeduct =0;     sql_mkilo_ply =0;   sql_mkilo_edr =0;     sql_qcylinder =0;
    sql_qpt =0;        sql_mcar_price =0;   sql_mequipment =0;  sql_mdamage_cover =0;
     
    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == FALSE)
    {
        EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
        return FAIL;
    }

     $CREATE TEMP TABLE CAR741
    (
        data_ipolicy_ext       CHAR (20),          /*car213�O�T�D�O�渹           */
        data_iassured          CHAR (10),          /*car213�Q�O�I�H�N��          */
        data_nassured          CHAR (120),         /*car213�Q�O�I�H              */
        data_dply_begin_ext    DATE,               /*car213�O�I�����_            */
        data_dply_end_ext      DATE,               /*car213�O�I������            */
        data_icar_flag         CHAR (1),           /*car213�s�¨�                */
        data_iparts            CHAR (1),           /*car213�O�T�s��              */
        data_qperiod           INTEGER,            /*car213�O�T��Ƥ�            */
        data_qmiles            INTEGER,            /*car213�O�T���{�Ƥ���        */
        data_mcover1           INTEGER,            /*car213�O�T�Ъ����̰����I���B */
        data_mcover2           INTEGER,            /*car213�֭p���B              */
        data_qperiod_ori       INTEGER,            /*car213��t�O�T���          */
        data_qmiles_ori        INTEGER,            /*car213��t�O�T���{��        */
        data_mdeduct           INTEGER,            /*car213�ۭt�B                */
        data_dpolicy           DATE,               /*car213ñ����              */
        data_ipolicy           CHAR (20),          /*�O�渹�X                    */
        data_ilast_ply         CHAR (20),          /*�e�O�渹                    */
        data_irelative_ext     CHAR (20),          /*�����O�T���p�渹            */
        data_dply_begin        DATE,               /*�O�I�����_                  */
        data_dply_end          DATE,               /*�O�I������                  */
        data_nowner            CHAR (120),         /*�O�T���D��Ʃm�W            */
        data_itel              CHAR (20),          /*�q��                        */
        data_itel_night        CHAR (20),          /*�Q�O�I�H�q�ܩ]              */
        data_mobil_phone       CHAR (20),          /*�Q�O�I�H��ʹq��            */
        data_aassured          CHAR (90),          /*�a�}                        */
        data_iowner            CHAR (12),          /*�����Ҧr��                  */
        data_dbirth_owner      DATE,               /*�X�ͦ~���                  */
        data_mkilo_ply         DECIMAL (9, 2),     /*�ӫO�ɨ��{��                */
        data_mkilo_edr         DECIMAL (9, 2),     /*���ɨ��{��                */
        data_itag              CHAR (12),          /*�P�Ӹ��X                    */
        data_iengine           CHAR (25),          /*�������X                    */
        data_nbrand_abbr       CHAR (12),          /*�t�P�W��                    */
        data_ibrand            CHAR (8),           /*�t�P����                    */
        data_nbrand            CHAR (30),          /*�t�P����                    */
        data_icar_type         CHAR (2),           /*����                        */
        data_ipro_year         CHAR (4),           /*�X�t�~                      */
        data_qpro_month        INTEGER,            /*�X�t��                      */
        data_dissue            DATE,               /*�o�Ӧ~��                    */
        data_qcylinder         DECIMAL (7, 2),     /*�Ʈ�q                      */
        data_fpt               CHAR(1),            /*�Ӹ����                    */
        data_qpt               DECIMAL (4, 1),     /*�����ƶq                    */
        data_mcar_price        DECIMAL (5, 1),     /*���m����                    */
        data_mequipment        DECIMAL (5, 1),     /*�t�ƻ�                      */
        data_fnequipment       CHAR (100),         /*�t�ƶ���                    */
        data_iins_type         CHAR (6),           /*�I��                        */
        data_nins_type         CHAR (28),          /*�I�ئW��                    */
        data_mins_premium      INTEGER,            /*�O�O��                      */
        data_irisk             CHAR (1),           /*�����O�T���I����            */
        data_mdamage_cover     INTEGER,            /*�ƬG�O�B�U                  */
        data_iins_type_list    CHAR (100),          /*���N�I��O�զX              */
        data_iofficer          CHAR (10),          /*�g��H                      */
        data_ileader           CHAR (10),          /*�޲z�H                      */
        data_iquota            CHAR (6),           /*�~�Z���                    */
        data_ireg_no           CHAR (20),          /*�n���Ҹ�                    */
        data_iroute            CHAR (20),          /*�q���N��                    */
        data_dply_close        DATE,               /*ñ����                    */
        data_iendorse          CHAR (20),          /*��渹�X                    */
        data_dedr_begin        DATE,               /*���ͮĴ���beg             */
        data_dedr_end          DATE,               /*���ͮĴ���                */
        data_dendorse          DATE,               /*�����                    */
        data_fedr_class        CHAR (1)            /*������O                    */
    ) WITH NO LOG;
    strcpy(dbgn_q,cm_to_infdate(dbgn));
    strcpy(dend_q,cm_to_infdate(dend));

    if(strncmp(option1,"1",1) == 0)  /*1.(car213�D�O��)ca_ply_ext�O������  OR  2.(���)ply_relationñ���� */
    {
        sprintf(stmp1,"a.dply_end between '%s' and '%s' ",dbgn_q,dend_q);
    }
    else
    {
        sprintf(stmp1,"b.dply_close between '%s' and '%s' ",dbgn_q,dend_q);
    }

    for(k=0;k<count_db;k++)
    { 
        sprintf(stmt,
            " SELECT  a.ipolicy     ,  a.iassured    ,  a.nassured     ,  a.dply_begin ,  a.dply_end    ,\n"
                    " a.icar_flag   ,  a.iparts      ,  a.qperiod      ,  a.qmiles     ,  a.mcover1     ,\n"
                    " a.mcover2     ,  a.qperiod_ori ,  a.qmiles_ori   ,  a.mdeduct    ,  a.dpolicy     ,\n"
                    " b.ipolicy     ,  b.ilast_ply   ,  c.irelative_ext,  b.dply_begin ,  b.dply_end    ,\n"
                    " c.nowner      ,  c.iowner      ,  c.dbirth_owner ,  c.mkilo_ply  ,  c.mkilo_edr   ,\n"
                    " c.itag        ,  c.iengine     ,  c.nbrand_abbr  , \n"
                    " b.ibrand      ,  b.icar_type   ,  b.ipro_year    , \n"
                    " c.qpro_month  ,  c.dissue      ,  c.qcylinder    ,  c.fpt        ,c.qpt        ,  c.mcar_price  ,\n"
                    " c.mequipment  , \n"
                    " decode(c.fequipment1,'1','���T ','0','')    || decode(c.fequipment2,'1','���c ','0','')||       \n"
                    " decode(c.fequipment3,'1','�N����� ','0','')|| decode(c.fequipment4,'1','���ءB���� ','0','')|| \n"
                    " decode(c.fequipment5,'1','�@���t�� ','0','')|| decode(c.fequipment6,'1','�q�ʨ��q�� ','0','')|| \n"
                    " decode(c.fequipment9,'1','��L-','0','')    || c.nequipment9 ,  \n"
                    " d.iins_type  , (SELECT nins_type FROM insurance_type e WHERE e.iins_type=d.iins_type) ,    d.mins_premium  ,\n"
                    " c.irisk      ,   d.mdamage_cover ,  \n"
                    " b.iofficer   ,   b.ileader       ,   b.iquota    ,  b.ireg_no    ,\n"
                    " c.iroute     ,   b.dply_close    ,   d.drate_ym \n"
              " FROM %s:ca_ply_ext a, %s:ori_ply_relation b , %s:original_ply c , %s:ori_ins_type d \n"
             " WHERE a.ipolicy=b.ipolicy[1,13]   AND b.ipolicy=c.ipolicy  \n"
              "  AND b.ipolicy=d.ipolicy  \n"
               " AND a.iassured matches '%s' "
               " AND a.iroute   matches '%s' "
               " AND %s  order by a.ipolicy,b.ipolicy"    ,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname
                            ,qry_iassured,qry_iroute,stmp1);

        printf("stmt [%s]\n",stmt);
        $PREPARE Acur FROM $stmt;
        $DECLARE cur1 CURSOR for Acur;
        $OPEN cur1 ;
        while(1)
        {
            $FETCH cur1 INTO  $sql_ipolicy_ext   ,$sql_iassured         ,$sql_nassured         ,$sql_dply_begin_ext   ,$sql_dply_end_ext     ,
                              $sql_icar_flag     ,$sql_iparts           ,$sql_qperiod          ,$sql_qmiles           ,$sql_mcover1          ,
                              $sql_mcover2       ,$sql_qperiod_ori      ,$sql_qmiles_ori       ,$sql_mdeduct          ,$sql_dpolicy          ,
                              $sql_ipolicy       ,$sql_ilast_ply        ,$sql_irelative_ext    ,$sql_dply_begin       ,$sql_dply_end         ,
                              $sql_nowner        ,$sql_iowner           ,$sql_dbirth_owner     ,$sql_mkilo_ply        ,$sql_mkilo_edr        ,
                              $sql_itag          ,$sql_iengine          ,$sql_nbrand_abbr      ,
                              $sql_ibrand        ,$sql_icar_type        ,$sql_ipro_year        ,
                              $sql_qpro_month    ,$sql_dissue           ,$sql_qcylinder        ,$sql_fpt              ,$sql_qpt              ,$sql_mcar_price       ,
                              $sql_mequipment    ,$sql_fnequipment      ,
                              $sql_iins_type     ,$sql_nins_type        ,$sql_mins_premium     ,
                              $sql_irisk         ,$sql_mdamage_cover    ,
                              $sql_iofficer      ,$sql_ileader          ,$sql_iquota           ,$sql_ireg_no          ,$sql_iroute           ,
                              $sql_dply_close    ,$sql_drate_ym;

            if(SQLCODE == SQLNOTFOUND) break;
            strcpy(tmp_fulldb,"");
            trim_tail_white(sql_irelative_ext);
            strcpy(tmp_fulldb, get_car_full_db(sql_irelative_ext));/* �]��VW��V9�i��s�b���@�Ӥ����q*/
            strcpy(tmp_fulldb,trim(tmp_fulldb));
            strcpy(stmp2,"");
            strcpy(sql_itel,"");
            strcpy(sql_itel_night,"");
            strcpy(sql_mobil_phone,"");
            strcpy(sql_aassured,"");
            strcpy(sql_iins_type_list,"");
            sprintf(stmp2, " select c.itel , c.itel_night, c.mobil_phone ,c.aassured ,\n"
                                   "  replace((replace(replace(replace(replace(replace(multiset (SELECT a.iins_type \n"
                                      "  FROM %s:ply_ins_type a, insurance_type b \n"
                                      " WHERE a.iins_type = b.iins_type  AND a.ipolicy=c.ipolicy \n"
                                       "  AND b.iins_type = b.iins_ply  )::lvarchar \n"
                                   " , 'MULTISET{',''), 'ROW(''',''),''')',''),'}',''),',',';')),' ') AS list \n"
                            "    from %s:policy c"
                             "  where c.ipolicy ='%s' \n " ,tmp_fulldb,tmp_fulldb,sql_irelative_ext);
            printf("stmp2 [%s]\n",stmp2);
            $PREPARE Acur_V9 FROM $stmp2;
            $DECLARE cur_V9  CURSOR FOR Acur_V9;
            $OPEN    cur_V9 ;
            $FETCH   cur_V9 INTO $sql_itel   ,$sql_itel_night   ,$sql_mobil_phone   ,$sql_aassured   ,$sql_iins_type_list ;
            if (SQLCODE == SQLNOTFOUND)
            { 
                $CLOSE cur_V9;
                $FREE cur_V9;
            }
            strcpy(stmp3,"");
            strcpy(sql_nbrand,"");
            sprintf(stmp3,"SELECT first 1 j.nbrand FROM ca_car_model j  "
                           "WHERE j.ibrand ='%s' \n"
                          "   AND j.drate  = (SELECT drate FROM ca_rate_date  WHERE icode  = '%s'  "
                                              "  AND itable = 'ca_car_model');\n",sql_ibrand ,sql_drate_ym );
            printf("stmp3 [%s]\n",stmp3);
            $PREPARE Acur_model FROM $stmp3;
            $DECLARE cur_model  CURSOR FOR Acur_model;
            $OPEN    cur_model ;
            $FETCH   cur_model INTO $sql_nbrand  ;

            if (SQLCODE == SQLNOTFOUND)
            {
         
                $CLOSE cur_model;
                $FREE cur_model;
            }
            $INSERT INTO CAR741
            (   data_ipolicy_ext   ,data_iassured      ,data_nassured      ,data_dply_begin_ext,data_dply_end_ext  ,
                data_icar_flag     ,data_iparts        ,data_qperiod       ,data_qmiles        ,data_mcover1       ,
                data_mcover2       ,data_qperiod_ori   ,data_qmiles_ori    ,data_mdeduct       ,data_dpolicy       ,
                data_ipolicy       ,data_ilast_ply     ,data_irelative_ext ,data_dply_begin    ,data_dply_end      ,
                data_nowner        ,data_itel          ,data_itel_night    ,data_mobil_phone   ,data_aassured      ,
                data_iowner        ,data_dbirth_owner  ,data_mkilo_ply     ,data_mkilo_edr     ,data_itag          ,
                data_iengine       ,data_nbrand_abbr   ,data_ibrand        ,data_nbrand        ,data_icar_type     ,
                data_ipro_year     ,data_qpro_month    ,data_dissue        ,data_qcylinder     ,data_fpt           ,data_qpt           ,
                data_mcar_price    ,data_mequipment    ,data_fnequipment   ,data_iins_type     ,data_nins_type     ,
                data_mins_premium  ,data_irisk         ,data_mdamage_cover ,data_iins_type_list,data_iofficer      ,
                data_ileader       ,data_iquota        ,data_ireg_no       ,data_iroute        ,data_dply_close    
            )
            VALUES 
            (
                $sql_ipolicy_ext   ,$sql_iassured      ,$sql_nassured      ,$sql_dply_begin_ext,$sql_dply_end_ext  ,
                $sql_icar_flag     ,$sql_iparts        ,$sql_qperiod       ,$sql_qmiles        ,$sql_mcover1       ,
                $sql_mcover2       ,$sql_qperiod_ori   ,$sql_qmiles_ori    ,$sql_mdeduct       ,$sql_dpolicy       ,
                $sql_ipolicy       ,$sql_ilast_ply     ,$sql_irelative_ext ,$sql_dply_begin    ,$sql_dply_end      ,
                $sql_nowner        ,$sql_itel          ,$sql_itel_night    ,$sql_mobil_phone   ,$sql_aassured      ,
                $sql_iowner        ,$sql_dbirth_owner  ,$sql_mkilo_ply     ,$sql_mkilo_edr     ,$sql_itag          ,
                $sql_iengine       ,$sql_nbrand_abbr   ,$sql_ibrand        ,$sql_nbrand        ,$sql_icar_type     ,
                $sql_ipro_year     ,$sql_qpro_month    ,$sql_dissue        ,$sql_qcylinder     ,$sql_fpt           ,$sql_qpt           ,
                $sql_mcar_price    ,$sql_mequipment    ,$sql_fnequipment   ,$sql_iins_type     ,$sql_nins_type     ,
                $sql_mins_premium  ,$sql_irisk         ,$sql_mdamage_cover ,$sql_iins_type_list,$sql_iofficer      ,
                $sql_ileader       ,$sql_iquota        ,$sql_ireg_no       ,$sql_iroute        ,$sql_dply_close    
            ) ;
            printf("end 1====\n");
            /* �ˬd�O�_��VW�����  
             ����椧�ӫO��ƭn�h��̷s�O����*/
            strcpy(stmp4,"");
            sprintf(stmp4,"SELECT a.iendorse    ,  a.dedr_begin  ,  a.dedr_end     ,  a.dendorse   ,  a.fedr_class,\n"
                               "  b.ilast_ply   ,  c.irelative_ext,  b.dply_begin ,  b.dply_end    ,\n"
                               "  c.nowner      ,  c.iowner      ,  c.dbirth_owner ,  c.mkilo_ply  ,  c.mkilo_edr   ,\n"
                               "  c.itag        ,  c.iengine     ,  c.nbrand_abbr  , \n"
                               "  b.ibrand      ,  b.icar_type   ,  b.ipro_year    , \n"
                               "  c.qpro_month  ,  c.dissue      ,  c.qcylinder    ,  c.fpt        ,c.qpt        ,  c.mcar_price  ,\n"
                               "  c.mequipment  , \n"
                               "  decode(c.fequipment1,'1','���T ','0','')    || decode(c.fequipment2,'1','���c ','0','')||       \n"
                               "  decode(c.fequipment3,'1','�N����� ','0','')|| decode(c.fequipment4,'1','���ءB���� ','0','')|| \n"
                               "  decode(c.fequipment5,'1','�@���t�� ','0','')|| decode(c.fequipment6,'1','�q�ʨ��q�� ','0','')|| \n"
                               "  decode(c.fequipment9,'1','��L-','0','')    || c.nequipment9 ,  \n"
                               "  d.iins_type  , (SELECT nins_type FROM insurance_type e WHERE e.iins_type=d.iins_type) ,    d.mins_premium  ,\n"
                               "  c.irisk      ,   d.mdamage_cover ,  \n"
                               "  b.iofficer   ,   b.ileader       ,   b.iquota    ,  b.ireg_no    ,\n"
                               "  c.iroute     ,   b.dply_close    ,   d.drate_ym             \n"
                          "  from %s:edr_relation a ,  %s:ply_relation b ,%s:policy c , %s:ply_ins_type d \n"
                          " where a.ipolicy = b.ipolicy \n"
                            " and b.ipolicy = c.ipolicy \n"
                            " and b.ipolicy = d.ipolicy \n"
                            " and b.ipolicy = '%s' "
                             " order by 1 ; \n"
                        ,list[k].dbname ,list[k].dbname ,list[k].dbname, list[k].dbname ,sql_ipolicy);
            printf("stmp4 [%s]\n",stmp4);
            $PREPARE Acur_edr FROM $stmp4;
            $DECLARE cur_edr  CURSOR FOR Acur_edr;
            $OPEN    cur_edr ;
            while(1)
            {
                $FETCH  cur_edr INTO
                        $sql_iendorse      ,$sql_dedr_begin       ,$sql_dedr_end         ,$sql_dendorse         ,$sql_fedr_class       ,
                        $sql_ilast_ply     ,$sql_irelative_ext    ,$sql_dply_begin       ,$sql_dply_end         ,
                        $sql_nowner        ,$sql_iowner           ,$sql_dbirth_owner     ,$sql_mkilo_ply        ,$sql_mkilo_edr        ,
                        $sql_itag          ,$sql_iengine          ,$sql_nbrand_abbr      ,
                        $sql_ibrand        ,$sql_icar_type        ,$sql_ipro_year        ,
                        $sql_qpro_month    ,$sql_dissue           ,$sql_qcylinder        ,$sql_fpt              ,$sql_qpt              ,$sql_mcar_price       ,
                        $sql_mequipment    ,$sql_fnequipment      ,
                        $sql_iins_type     ,$sql_nins_type        ,$sql_mins_premium     ,
                        $sql_irisk         ,$sql_mdamage_cover    ,
                        $sql_iofficer      ,$sql_ileader          ,$sql_iquota           ,$sql_ireg_no          ,$sql_iroute           ,
                        $sql_dply_close    ,$sql_drate_ym;
           
                if (SQLCODE == SQLNOTFOUND)
                {
             
                    $CLOSE cur_edr;
                    $FREE cur_edr;
                    break;
                }     
                
                strcpy(stmp5,"");
                strcpy(sql_nbrand,"");
                sprintf(stmp5,"SELECT first 1 j.nbrand FROM ca_car_model j  \n"
                               "WHERE j.ibrand ='%s' "
                              "   AND j.drate  = (SELECT drate FROM ca_rate_date  WHERE icode  = '%s'  \n"
                                                  "  AND itable = 'ca_car_model'); \n",sql_ibrand ,sql_drate_ym );
                printf("stmp5 [%s]\n",stmp5);
                $PREPARE Acur_edr_model FROM $stmp5;
                $DECLARE cur_edr_model  CURSOR FOR Acur_edr_model;
                $OPEN    cur_edr_model ;
                $FETCH   cur_edr_model INTO $sql_nbrand  ;

                
                $INSERT INTO CAR741
                (   data_ipolicy_ext   ,data_iassured      ,data_nassured      ,data_dply_begin_ext,data_dply_end_ext  ,
                    data_icar_flag     ,data_iparts        ,data_qperiod       ,data_qmiles        ,data_mcover1       ,
                    data_mcover2       ,data_qperiod_ori   ,data_qmiles_ori    ,data_mdeduct       ,data_dpolicy       ,
                    data_ipolicy       ,data_ilast_ply     ,data_irelative_ext ,data_dply_begin    ,data_dply_end      ,
                    data_nowner        ,data_itel          ,data_itel_night    ,data_mobil_phone   ,data_aassured      ,
                    data_iowner        ,data_dbirth_owner  ,data_mkilo_ply     ,data_mkilo_edr     ,data_itag          ,
                    data_iengine       ,data_nbrand_abbr   ,data_ibrand        ,data_nbrand        ,data_icar_type     ,
                    data_ipro_year     ,data_qpro_month    ,data_dissue        ,data_qcylinder     ,data_fpt           ,data_qpt           ,
                    data_mcar_price    ,data_mequipment    ,data_fnequipment   ,data_iins_type     ,data_nins_type     ,
                    data_mins_premium  ,data_irisk         ,data_mdamage_cover ,data_iins_type_list,data_iofficer      ,
                    data_ileader       ,data_iquota        ,data_ireg_no       ,data_iroute        ,data_dply_close    ,
                    data_iendorse      ,data_dedr_begin    ,data_dedr_end      ,data_dendorse      ,data_fedr_class    
                )
                VALUES 
                (
                    $sql_ipolicy_ext   ,$sql_iassured      ,$sql_nassured      ,$sql_dply_begin_ext,$sql_dply_end_ext  ,
                    $sql_icar_flag     ,$sql_iparts        ,$sql_qperiod       ,$sql_qmiles        ,$sql_mcover1       ,
                    $sql_mcover2       ,$sql_qperiod_ori   ,$sql_qmiles_ori    ,$sql_mdeduct       ,$sql_dpolicy       ,
                    $sql_ipolicy       ,$sql_ilast_ply     ,$sql_irelative_ext ,$sql_dply_begin    ,$sql_dply_end      ,
                    $sql_nowner        ,$sql_itel          ,$sql_itel_night    ,$sql_mobil_phone   ,$sql_aassured      ,
                    $sql_iowner        ,$sql_dbirth_owner  ,$sql_mkilo_ply     ,$sql_mkilo_edr     ,$sql_itag          ,
                    $sql_iengine       ,$sql_nbrand_abbr   ,$sql_ibrand        ,$sql_nbrand        ,$sql_icar_type     ,
                    $sql_ipro_year     ,$sql_qpro_month    ,$sql_dissue        ,$sql_qcylinder     ,$sql_fpt           ,$sql_qpt           ,
                    $sql_mcar_price    ,$sql_mequipment    ,$sql_fnequipment   ,$sql_iins_type     ,$sql_nins_type     ,
                    $sql_mins_premium  ,$sql_irisk         ,$sql_mdamage_cover ,$sql_iins_type_list,$sql_iofficer      ,
                    $sql_ileader       ,$sql_iquota        ,$sql_ireg_no       ,$sql_iroute        ,$sql_dply_close    ,
                    $sql_iendorse      ,$sql_dedr_begin    ,$sql_dedr_end      ,$sql_dendorse      ,$sql_fedr_class    
                ) ;
                printf("end 2====\n");
            }
        }
    }
    
    
        
    return M_CM_OK;
	
errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
/*--------------------------------------------------------------------*/


long car741_build()
{
 int rc;
 $char sfilename[256],stitle[2048],stmt1[4096],stmt11[8192];

	$WHENEVER SQLERROR GOTO errexit;
    
    strcpy(sfilename,"�O�T�I��O���Ӹ��\n");
    printf("car741_build===sfilename[%s]===\n",sfilename);
    strcpy(stitle,"�O�T�D�O�渹\t�Q�O�I�H�N��\t�Q�O�I�H\t�O�I�����_\t�O�I������\t�s�¨�\t�O�T�s��\t�O�T���(��)\t�O�T���{��(����)\t�O�T�Ъ����̰����I���B\t�֭p���B\t��t�O�T(��)\t��t�O�T���{��(����)\t�ۭt�B\tñ����\t�O�渹�X\t�e�O�渹\t�����O�T���p�渹\t�O�I�����_\t�O�I������\t�O�T���D���-�m�W\t�Q�O�I�H-�q��\t�Q�O�I�H-�q��(�])\t�Q�O�I�H-��ʹq��\t�Q�O�I�H-�a�}\t�����Ҧr��\t�X�ͦ~���\t�ӫO�ɨ��{��\t���ɨ��{��\t�P�Ӹ��X\t�������X\t�t�P�W��\t�t�P����\t�t�N�W��\t����\t�X�t�~\t�X�t��\t�o�Ӧ~��\t�Ʈ�q\t�����ƶq\t���m����\t�t�ƻ�\t�t�ƶ���\t�I��\t�I�ئW��\t�O�O(��)\t�����O�T���I����\t�ƬG�O�B(�U)\t���N�I��O�զX\t�g��H\t�޲z�H\t�~�Z���\t�n���Ҹ�\t�q���N��\tñ����\t��渹�X\t���ͮİ_\t���ͮĨ���\t�����\t������O\t");
    strcpy(stmt11,"SELECT a.data_ipolicy_ext    ,a.data_iassured       ,a.data_nassured       ,TO_CHAR(a.data_dply_begin_ext , '%Eg%Ey/%Om/%Od') ,TO_CHAR(a.data_dply_end_ext , '%Eg%Ey/%Om/%Od')\n"  
                      "  ,decode(a.data_icar_flag,'1','1�s��','2','2�¨�')      ,decode(a.data_iparts,'1','1����','2','2�ʤO�ǰʨt��')         ,a.data_qperiod        ,a.data_qmiles         ,a.data_mcover1     \n"  
                      "  ,a.data_mcover2        ,a.data_qperiod_ori    ,a.data_qmiles_ori     ,a.data_mdeduct        ,TO_CHAR(a.data_dpolicy , '%Eg%Ey/%Om/%Od')      \n"  
                      "  ,a.data_ipolicy        ,a.data_ilast_ply      ,a.data_irelative_ext  ,TO_CHAR(a.data_dply_begin , '%Eg%Ey/%Om/%Od')      ,TO_CHAR(a.data_dply_end , '%Eg%Ey/%Om/%Od')     \n"  
                      "  ,a.data_nowner         ,a.data_itel           ,a.data_itel_night     ,a.data_mobil_phone    ,a.data_aassured    \n"  
                      "  ,a.data_iowner         ,TO_CHAR(a.data_dbirth_owner , '%Eg%Ey/%Om/%Od')    ,a.data_mkilo_ply      ,a.data_mkilo_edr      ,a.data_itag        \n"  
                      "  ,a.data_iengine        ,a.data_nbrand_abbr    ,a.data_ibrand         ,a.data_nbrand         ,a.data_icar_type||'/'||(SELECT ncode FROM car_type WHERE icode =a.data_icar_type AND fclass ='1')   \n"  
                      "  ,a.data_ipro_year      ,a.data_qpro_month     ,TO_CHAR(a.data_dissue , '%Eg%Ey/%Om')      ,a.data_qcylinder      ,decode(a.data_fpt,'P',a.data_qpt||'�H','T',a.data_qpt||'��',a.data_qpt||a.data_fpt)         \n"  
                      "  ,a.data_mcar_price     ,a.data_mequipment     ,a.data_fnequipment    ,a.data_iins_type      ,a.data_nins_type   \n"  
                      "  ,a.data_mins_premium   ,a.data_irisk          ,a.data_mdamage_cover/10000  ,a.data_iins_type_list ,trim(a.data_iofficer)||'/'||b.nname    \n"  
                      "  ,trim(a.data_ileader)||'/'||trim(c.nname)     ,trim(a.data_iquota)||'/'||trim(d.nbranch)    ,a.data_ireg_no        ,trim(a.data_iroute)||'/'||trim(e.nroute)   ,TO_CHAR(a.data_dply_close , '%Eg%Ey/%Om/%Od')   \n"  
                      "  ,a.data_iendorse       ,a.data_dedr_begin     ,a.data_dedr_end       ,TO_CHAR(a.data_dendorse , '%Eg%Ey/%Om/%Od')        ,decode(a.data_fedr_class,'1','1:���P','2','2:�L��','4','4:�h���h�O','5','5:�@����','6','6:���B���','9','9:����',a.data_fedr_class)  \n"  
                   " FROM CAR741 a ,officer b , officer c , sa_branch_type d ,cm_route e "
                    "WHERE a.data_iofficer= b.iofficer "
                     " and a.data_ileader= c.iofficer "
                     " AND a.data_iquota = d.ibranch "
                     " and a.data_iroute = e.iroute "
                   "ORDER BY a.data_ipolicy_ext,a.data_ipolicy,a.data_iendorse ;");
    rc = unload_file(outputf," ",sfilename,stitle,stmt11);
    $DROP TABLE CAR741;
	printf("unload end\n");
	if (rc != SUCCESS) 
	{
	    sprintf(msgbuf," %s �ɮ׵L�k���� ",sfilename);
	    EWRITE(userid, rc , msgbuf);
	    return rc;
	}
	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	return SQLCODE;
}
char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  char sTmp_db_name[21];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
  }
  return sTmp_db_name;
}
