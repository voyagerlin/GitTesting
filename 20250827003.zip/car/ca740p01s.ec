/**********************************************************************/
/*   program id   : ca740p01s.ec                                      */
/*   program name : ���M�O�N������ɧ@�~(��O)                        */
/*   date written : 2018/10/19                                        */
/*   author       : 061476                                            */
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include "safeclib.h"
#include <math.h>

/****************************************************************************/
$char DBName[05],userid[11];
$char fclass[2],date1[10],date2[10],dbgn[11],dend[11], sYYMM[7];
int   count_db, k;

$char date[11],dToday[11],nyy[4],nmm[3],ndd[3];
char  msgbuf[2048],sApHome[30];
char  outputf[N_FILE+1];
int   count_db,k;
long  t;
DBinfo *list;

$char   icard[21],icard_c[21],ipolicy[21],ipolicy_c[21],ipolicy_B[21];
$char   nassured[121],ilicense[11],ibirth[9],dbirth[11],fsex[2],iassured_cntry[2],fmarriage[2],
        itel[21],imovephone[21],iemail[51],aassured_zip[CA_ZIP],aassured[91],
        nuser[19],nbenef[43],napplicant[121],fcar_class[2],iply_area[11],
        iengine[CA_ENGINE_NUM],ibody[CA_BODY_NUM],itag[CA_TAG_NUM],ibrand[9],nbrand_abbr[17],
        dissue[11],ipro_year[5],qpro_month[3],icar_type[3],ncar_type[17],
        qpt[5],fpt[2];
$char   fcomp_class[3],iquery_num_c[18];
$char   iquery_num[18],lia_class[3],last_policy_2[21],last_policy_3[21];
$char   dissue_mm[3],dissue_dd[3],dissue_yyyy[5],dmake_ym[7];
$char   tmp_yyyy[5],tmp_mm[3],tmp_dd[3];
$char   dply_begin_c[11],dply_end_c[11],pre_dply1_bgn[11],pre_dply1_end[11],
        dply_begin[11],dply_end[11],pre_dply2_bgn[11],pre_dply2_end[11];
$char   freason_reject_c[2],freason_reject[2];
$char   irelative_ply[21],irelative_ply_c[21],dply_pre[11],dply_pre_c[11],
        forcemsg[51],randmsg[51];
$char   sFullName[64];
/* �Ʈ�q(qcylinder)�X�ܤp���I2�� (1080902001_SC3) */
$double plia_acc=0.0,pdmg_acc=0.0,plia_acc_c=0.0,mcar_price=0.0,qcylinder=0.0,
        dmg_factor=0.0,brg_factor=0.0,psex_age=0.0,pdmg_factor=0.0,pbrg_factor=0.0;
$int    qdrunk_driving=0,comp_prem=0,mtot_amt=0,mtot_amt_sug=0,qcylinder_tmp=0,
        v_ori_prem=0,tot_prem=0,iqpro_month=0,pre_prem1=0,pre_prem2=0;

$int    fmsg=0; /* 1:�L�k�J�p */
$int    fins_149=0,icnt=0,iqty=0;
$char   nrelation_appl[3], iapplicant[13], dbirth_appl[11], fsex_appl[2],
        tmobile_appl[21], apayment_zip[7], apayment[101];

$char   Fname[128], FileName[128];
FILE    *fp;

long car740_get_db();
/****************************************************************************/
main(argc, argv)
int argc;
char **argv;
{
	int rc;

	init_data();

	batchinit();
	strcpy(DBName, isNULLstr(argv[1]));
	strcpy(userid, isNULLstr(argv[2]));
	strcpy(fclass, isNULLstr(argv[3]));  /* 1�G��O 2�G�z�� */
	strcpy(date1,  isNULLstr(argv[4]));
	strcpy(date2,  isNULLstr(argv[5]));
	strcpy(outputf,isNULLstr(argv[6]));

	strcpy(dbgn, cm_to_infdate(date1));
	strcpy(dend, cm_to_infdate(date2));
	printf("-- ����϶�(�褸):[%s] ~ [%s]\n",dbgn,dend);

	rc = car740_get_db();
	if (rc != M_CM_OK)
	{
		EWRITE(userid,rc,msgbuf);
		return rc;
	}

	/* ���褸�~��(201907) */
	$select to_char(date($dbgn),'%Y%m') into $sYYMM
	   from systables where tabid = 1;

	/* �ˬd��O�O�_�w����H�άO�_�}�� */
	rc = car740_check();
	if (rc != M_CM_OK)
	    return rc;

	$BEGIN WORK;
	rc = car740_body();
	if (rc != M_CM_OK)
	    return rc;
	$COMMIT WORK;

	EWRITE(userid, M_CM_OK, " ���ɧ��� ");

}
/******************************************************************************/
long car740_body()
{
    $char  stmt_buf[1024],stmt[128],stmt1[2048],stmt_B[2048];
    $int   isql2,cnt,freject;
    $char  nequipment[31];
	int rc;
	$char  sErrMsg[51];
	int has_error = 0;
	
	strcpy(FileName," ");
	strcpy(Fname," ");
	sprintf_s(Fname, sizeof Fname,"RiohoReplyError[%s].txt",sYYMM);	
	sprintf_s(FileName, sizeof FileName,"%s/rptftp/%s",sApHome,Fname);
	printf("--FileName--[%s]\n",FileName);
	fp=fopen(FileName,"w");

    cnt = 0;
    printf("BEGIN TO car740_body\n");
    $WHENEVER SQLERROR GOTO errexit;

    $DECLARE acur CURSOR for
    SELECT DISTINCT irand_no, iforce_no
      FROM sysdb:ca_rioho_ren_req	   
     WHERE dyyyymm = $sYYMM;

    $OPEN acur;
    while(1)
    {
    	$FETCH acur INTO $icard, $icard_c;

    	if (SQLCODE == SQLNOTFOUND) break;

    	init_data();

    	/* policy_302:icard �S�]index�A����policy_new��ipolicy */
    	if (strlen(trim(icard_c))!= 0)
    	{
    		$SELECT ipolicy1 INTO $ipolicy_c
    		   FROM policy_new
    		  WHERE isys_source = 'CAR'
    		    AND itarget2 = $icard_c
    		    AND ichannel[1,2] = 'CA';

    		if (SQLCODE == SQLNOTFOUND) strcpy(ipolicy_c," ");
    	}
    	else strcpy(ipolicy_c," ");

    	if (strlen(trim(icard))!= 0)
    	{
    		$SELECT ipolicy1 INTO $ipolicy
    		   FROM policy_new
    		  WHERE isys_source = 'CAR'
    		    AND itarget2 = $icard
    		    AND ichannel[1,2] = 'CA';

    		if (SQLCODE == SQLNOTFOUND) strcpy(ipolicy," ");
    	}
    	else strcpy(ipolicy," ");

		/* 131775 ���M��O���ɭץ� (1140106006_C01) */
		/* 1. �O������PsYYMM���A�P�~��~�~�����A���P�h�M�űj��/���N�O�渹�g�ɬ�����ƨѫ���H�H�ϥ� */
		/* 2. �O�渹�Y�w�s�b��ƪ�ca_rioho_ren_reply�̭��]�ݭn�ư� */
		if (strlen(trim(ipolicy_c))!= 0)
		{
			$SELECT ipolicy1
			   FROM policy_new
			  WHERE ipolicy1 = $ipolicy_c
			    AND to_char(dins_end, '%Y%m') = $sYYMM;

			if (SQLCODE == SQLNOTFOUND) 
			{				
				has_error = 1;
				fprintf(fp,"�O�渹�G%s\t�D������O���\n",ipolicy_c);
				strcpy(ipolicy_c," ");
			}
			else
			{
				$SELECT iold_force_insu_no
				   FROM sysdb:ca_rioho_ren_reply
				  WHERE iold_force_insu_no = $ipolicy_c;

				if (SQLCODE != SQLNOTFOUND) 
				{
					has_error = 1;
					fprintf(fp,"�O�渹�G%s\t�w�s�b��O���\n",ipolicy_c);
					strcpy(ipolicy_c," ");
				}
				
			}			
		}

		if (strlen(trim(ipolicy))!= 0)
		{
			$SELECT ipolicy1
			   FROM policy_new
			  WHERE ipolicy1 = $ipolicy
			    AND to_char(dins_end, '%Y%m') = $sYYMM;

			if (SQLCODE == SQLNOTFOUND) 
			{				
				has_error = 1;
				fprintf(fp,"�O�渹�G%s\t�D������O���\n",ipolicy);
				strcpy(ipolicy," ");
			}
			else
			{
				$SELECT iold_rand_insu_no
				   FROM sysdb:ca_rioho_ren_reply
				  WHERE iold_rand_insu_no = $ipolicy;

				if (SQLCODE != SQLNOTFOUND)
				{
					has_error = 1;
					fprintf(fp,"�O�渹�G%s\t�w�s�b��O���\n",ipolicy);
					strcpy(ipolicy," ");
				}
			}
		}

    	if ((strlen(trim(ipolicy_c))== 0) && (strlen(trim(ipolicy))== 0)) continue;

    	/* ����O(�򥻸��) */
    	/* �s�W�n�O�H������� add by sylvia 112.06.09 (1110531005_C01) */
    	sprintf_s(stmt_buf, sizeof stmt_buf,
    	  " SELECT first 1 nvl(nassured,''),nvl(ilicense,''),nvl(ibirth,''),decode(fsex,'1','1','2','2','3'), "
    	  "        decode(iassured_cntry,'9','1','2'),decode(fmarriage,'1','2','2','1',''), "
    	  "        nvl(itel,''),nvl(imovephone,''),nvl(iemail,''),nvl(aassured_zip,''),nvl(aassured,''), "
    	  "        nvl(nuser,''),nvl(nbenef,''),nvl(napplicant,''),nvl(fcar_class,''),nvl(iply_area,''),  "
    	  "        nvl(iengine,''),nvl(ibody,''),nvl(itag,''),nvl(ibrand,''),nvl(nbrand_abbr,''), "
    	  "        nvl(dissue,''),nvl(ipro_year,''),nvl(qpro_month,''),nvl(icar_type,''),nvl(ncar_type,''), "
    	  "        nvl(qpt,''),nvl(fpt,''),nvl(qcylinder,''),replace(mcar_price,',',''),nequipment,  "
    	  "        decode(trim(nrelation_appl),'���H','1','�t��','2','�l�k','3','����','4','�S�̩j�f','5','����','6','7'), "
    	  "        iapplicant, dbirth_appl, decode(fsex_appl,'1','1','2','2','3'), "
    	  "        tmobile_appl, apayment_zip, apayment "
    	  "   FROM policy_302 "
    	  "  WHERE ipolicy in ('%s','%s'); ",ipolicy,ipolicy_c);

    	$PREPARE main FROM $stmt_buf;
        $EXECUTE main INTO $nassured,$ilicense,$ibirth,$fsex,
                           $iassured_cntry,$fmarriage,
                           $itel,$imovephone,$iemail,$aassured_zip,$aassured,
                           $nuser,$nbenef,$napplicant,$fcar_class,$iply_area,
                           $iengine,$ibody,$itag,$ibrand,$nbrand_abbr,
                           $dissue,$ipro_year,$qpro_month,$icar_type,$ncar_type,
                           $qpt,$fpt,$qcylinder,$mcar_price,$nequipment,
                           $nrelation_appl, $iapplicant, $dbirth_appl, $fsex_appl,
                           $tmobile_appl, $apayment_zip, $apayment;

        if (SQLCODE == SQLNOTFOUND)
        {
        	fmsg = 1; /* ����J�p�A������ƥu������J�p����](��]�����N���T�Ǹ����) */
        	strcpy(nrelation_appl," ");  strcpy(iapplicant," ");
            strcpy(fsex_appl," ");       strcpy(tmobile_appl," ");
            strcpy(apayment_zip, " ");   strcpy(apayment," ");
        	sprintf_s(stmt1, sizeof stmt1,
        	    " SELECT first 1 CASE WHEN nvl(chiname,'') <> '' THEN chiname[1,16] "
                    "                     ELSE remark_reject[1,16] end "
        	    "   FROM policy_302f a, sysdb:car_renew_msg b, OUTER car_code c "
        	    "  WHERE a.ipolicy = b.ipolicy AND b.err_no = c.detail2 "
        	    "    AND kind = 'RN' AND detail = 'Mail_To_Leader' "
        	    "    AND a.dply_begin BETWEEN '%s' AND '%s' "
        	    "    AND freason = 'E' "
        	    "    AND err_no NOT in ('E27') "
        	    "    AND a.ipolicy in ('%s','%s'); ",dbgn,dend,ipolicy,ipolicy_c);

        	$PREPARE insert_main FROM $stmt1;
        	$EXECUTE insert_main INTO $iquery_num;
        	if (SQLCODE == SQLNOTFOUND) continue;
        }

        /* �j���I��� */
    	if (strlen(trim(ipolicy_c))!= 0)
    	{
    		sprintf_s(stmt_buf, sizeof stmt_buf,
    		  " SELECT nvl(fcomp_class,''),nvl(qdrunk_driving,0),nvl(psex_age_c,0.0),nvl(plia_acc_c,0.0), "
    		  "        nvl(iquery_num_c,''),comp_prem,dply_begin,dply_end, "
    		  "        pre_dply1_bgn,pre_dply1_end,icard,pre_prem1, "
    		  "        freason_reject,nvl(irelative_ply,'') "
    		  "   FROM policy_302 "
    		  "  WHERE ipolicy = '%s'; ",ipolicy_c);

    		$PREPARE main FROM $stmt_buf;
    		$EXECUTE main INTO $fcomp_class,$qdrunk_driving,$psex_age,$plia_acc_c,
    		                   $iquery_num_c,$comp_prem,$dply_begin_c,$dply_end_c,
    		                   $pre_dply1_bgn,$pre_dply1_end,$icard_c,$pre_prem1,
    		                   $freason_reject_c,$irelative_ply_c;
    	}

    	/* �ˬd�O�_����j��ĳ���N���O�� (1070719011_SC6) */
    	if ((strlen(trim(ipolicy_c))!= 0) && (strlen(trim(ipolicy))== 0))
        {
        	printf("��j�G[%s]\n",ipolicy_c);
        	$SELECT count(*) INTO $icnt
        	   FROM ply_ins_type_302
        	  WHERE ipolicy = $ipolicy_c
        	    AND iins_type != '21';

        	if (icnt > 0)
        	{
        		fins_149 = 1;
        		strcpy(ipolicy,trim(ipolicy_c));
        	}
        }

    	/* ���N�I��� */
    	if ((strlen(trim(ipolicy))!= 0) || (fins_149==1))
    	{
    		sprintf_s(stmt_buf, sizeof stmt_buf,
    		  " SELECT dply_begin,dply_end,nvl(iquery_num,''),v_ori_prem,tot_prem, "
    		  "        nvl(dmg_factor,0.0),nvl(brg_factor,0.0),nvl(lia_class,''), "
    		  "        nvl(last_policy_2,''),nvl(last_policy_3,''),decode(plia_acc,'','0',plia_acc), "
    		  "        CASE WHEN nvl(pdmg_acc,'') <> '' THEN pdmg_acc "
    		  "             ELSE (CASE WHEN nvl(pdmg_acc_sug,'') <> '' THEN pdmg_acc_sug "
    		  "                   ELSE '0' END) END, "
    		  "        pre_dply2_bgn,pre_dply2_end,icard, "
    		  "        freason_reject,nvl(irelative_ply,'') "
    		  "   FROM policy_302 "
    		  "  WHERE ipolicy = '%s'; ",ipolicy);

    		$PREPARE main FROM $stmt_buf;
    		$EXECUTE main INTO $dply_begin,$dply_end,$iquery_num,$v_ori_prem,$tot_prem,
    		                   $dmg_factor,$brg_factor,$lia_class,
    		                   $last_policy_2,$last_policy_3,$plia_acc,
    		                   $pdmg_acc,
    		                   $pre_dply2_bgn,$pre_dply2_end,$icard,
    		                   $freason_reject,$irelative_ply;

    		/* ��j��ĳ���N���ݭn����N�d�� (1070719011_SC6)*/
    		if (fins_149==1) strcpy(icard," ");

    		if (SQLCODE != SQLNOTFOUND)
    		{
    			strcpy(sFullName, get_car_full_db(ipolicy));
    			sprintf_s(stmt_buf, sizeof stmt_buf,
    			  " SELECT nvl(pdmg_factor,0.0),nvl(pbrg_factor,0.0) "
    			  "   FROM %s:policy "
    			  "  WHERE ipolicy = '%s'; ",sFullName,ipolicy);
    			$PREPARE pre_data FROM $stmt_buf;
    			$EXECUTE pre_data INTO $pdmg_factor,$pbrg_factor;
    		}

    		/*�D�ɥh�~�O�O��H�����ɥ[�`���D add by 061476(1100504003_SC1)*/
			/* �[�`�O�O���ư� -999 (1140313012_C01) */
    		sprintf_s(stmt_buf, sizeof stmt_buf,
    			" SELECT nvl(sum(pre_minsprem),0) "
    			"   FROM ply_ins_type_302  "
    			"  WHERE ipolicy = '%s' "
				"    AND pre_minsprem <> '-999'; ", ipolicy);
    		$PREPARE pre_prem FROM $stmt_buf;
    		$EXECUTE pre_prem INTO $pre_prem2;
    	}

    	qcylinder_tmp = (int)floor(qcylinder);
    	if ( fmsg == 0 ) /* fmsg=0,policy_302����� */
    	{
    		mtot_amt = v_ori_prem + comp_prem;
    		mtot_amt_sug = tot_prem + comp_prem;

    		/***** ��z��Ʀ��ŦXtable���榡 *****/

    		/*�o�Ӥ�אּ�~��鳣�n�� modify by 061476 (1090415006_SC1)*/
    		cm_split_ymd(dissue,dissue_mm,dissue_dd,dissue_yyyy);
    		sprintf_s(dissue, sizeof dissue, "%s%s%s",dissue_yyyy,dissue_mm,dissue_dd);

    		iqpro_month = atoi(qpro_month);
    		sprintf_s(dmake_ym, sizeof dmake_ym, "%s%02d",ipro_year,iqpro_month);

    		if (strlen(trim(ibirth)) > 0 )
    			strcpy(dbirth, cm_to_infdate(ibirth));
    	}

        /* add by 071004 (1101227001_SC1_���M��O���ɦ^���ɭץ�) */
        freject = 0;
        /* �ګO��]�� 7�B9�BB�BP�BY�BZ�A������ơA��]�����N���T�Ǹ���� */
        /* ���M�n�D���o�����Ѹ�� (1110712006_SC2) */
        if((freason_reject_c[0]=='7')||(freason_reject_c[0]=='9')||(freason_reject_c[0]=='B')||(freason_reject_c[0]=='P')||(freason_reject_c[0]=='Y')||(freason_reject_c[0]=='Z')||
	   (freason_reject[0]=='7')||(freason_reject[0]=='9')||(freason_reject[0]=='B')||(freason_reject[0]=='P')||(freason_reject[0]=='Y')||(freason_reject[0]=='Z'))
        {

            freject = 1;

            /*�M�ų��������*/
            /*strcpy(nassured," ");      strcpy(ilicense," ");      strcpy(dbirth," ");        strcpy(fsex," ");          strcpy(iassured_cntry," ");
            strcpy(fmarriage," ");     strcpy(itel," ");          strcpy(imovephone," ");    strcpy(iemail," ");        strcpy(aassured_zip," ");
            strcpy(aassured," ");      strcpy(nuser," ");         strcpy(nbenef," ");        strcpy(napplicant," ");    strcpy(fcar_class," ");
            strcpy(iply_area," ");     strcpy(iengine," ");       strcpy(ibody," ");         strcpy(itag," ");          strcpy(ibrand," ");
            strcpy(nbrand_abbr," ");   strcpy(dissue," ");        strcpy(dmake_ym," ");      strcpy(icar_type," ");      strcpy(ncar_type," ");
            strcpy(qpt," ");           strcpy(fpt," ");           strcpy(dply_begin," ");    strcpy(dply_end," ");      strcpy(fcomp_class," ");
            strcpy(iquery_num_c," ");  strcpy(dply_begin_c," ");  strcpy(dply_end_c," ");    strcpy(lia_class," ");     strcpy(last_policy_2," ");
            strcpy(last_policy_3," "); strcpy(pre_dply1_bgn," "); strcpy(pre_dply1_end," "); strcpy(pre_dply2_bgn," "); strcpy(pre_dply2_end," ");

            qcylinder_tmp = 0; mcar_price = 0.0;  qdrunk_driving = 0; plia_acc_c = 0.0; comp_prem = 0;
            v_ori_prem = 0;    mtot_amt = 0;      tot_prem = 0;       mtot_amt_sug = 0; dmg_factor = 0.0;
            brg_factor = 0.0;  psex_age = 0.0;    plia_acc = 0.0;     pdmg_acc = 0.0;   pre_prem1 = 0;
            pre_prem2 = 0;     pdmg_factor = 0.0; pbrg_factor = 0.0; */

            /*�ګO��]*/
            /*strcpy(iquery_num,"��������O�n�O��");*/

            /* �o������ƫO�O��0�Y�i add by 061476 */
            comp_prem = 0; v_ori_prem = 0; mtot_amt = 0; tot_prem = 0; mtot_amt_sug = 0;

        }

        /* (1120204011_SC1_�i���M�O�N�j��O�ɷs�W���ݨD) */
        if ((strlen(trim(ipolicy_c)) != 0) && (strlen(trim(ipolicy)) == 0) && (strlen(trim(irelative_ply_c)) != 0))
        {
        	/* ��j�����p�渹 */
        	strcpy(sFullName, get_car_full_db(irelative_ply_c));
        	sprintf_s(stmt_buf, sizeof stmt_buf,
        	        " SELECT dply_end "
        	        "   FROM %s:ply_relation "
        	        "  WHERE ipolicy = '%s' "
        	        "    AND dply_end not between '%s' and '%s'; "
        	        ,sFullName,irelative_ply_c,dbgn,dend);
        	$PREPARE pre_dend1 FROM $stmt_buf;
        	$EXECUTE pre_dend1 INTO $dply_pre_c;

        	if (SQLCODE != SQLNOTFOUND)
        	{
        		sprintf_s(forcemsg, sizeof forcemsg, "�������N�I��O�� %s ���",dply_pre_c);
        	}
        }
        if ((strlen(trim(ipolicy_c)) == 0) && (strlen(trim(ipolicy)) != 0) && (strlen(trim(irelative_ply)) != 0))
        {
        	/* ��������p�渹 */
        	strcpy(sFullName, get_car_full_db(irelative_ply));
        	sprintf_s(stmt_buf, sizeof stmt_buf,
        	        " SELECT dply_end "
        	        "   FROM %s:ply_relation "
        	        "  WHERE ipolicy = '%s' "
        	        "    AND dply_end not between '%s' and '%s'; "
        	        ,sFullName,irelative_ply,dbgn,dend);
        	$PREPARE pre_dend2 FROM $stmt_buf;
        	$EXECUTE pre_dend2 INTO $dply_pre;

        	if (SQLCODE != SQLNOTFOUND)
        	{
        		sprintf_s(randmsg, sizeof randmsg, "�����j���I��O�� %s ���",dply_pre);
        	}
        }


    	/******�즹insert��Ƴ��ǳƦn�F******/
    	printf("INSERT INTO ca_rioho_ren_reply\n");
    	
    	sprintf_s(stmt1, sizeof stmt1,
    	  " INSERT INTO sysdb:ca_rioho_ren_reply "
    	  "      VALUES (?,?,?,?,?,?,?, "
    	  "              ?,?,?,?,?, "
    	  "              ?,?,?,?,?, "
    	  "              ?,?,?,?,?,?,?, "
    	  "              ?,?,?,?,?,?, "
    	  "              ?,?,?,?,?,  "
    	  "              ?,?,?,?,   "
    	  "              ?,?,?,?,?, "
    	  "              ?,?,?,?, "
    	  "              ?,'','','',?,'','','',?,'','','', "
    	  "              0.0,0.0,0.0,?,?,?, "
    	  "              ?,?,?,?,?,   "
    	  "              ?,?,?,?,?,   "
    	  "              ?,?,'',current,'',?,?, "
    	  "              ?, ?, ?, ?, ?, ?, ? ) ");
	
    	$PREPARE insert_main FROM $stmt1;
    	$EXECUTE insert_main
    	   USING $sYYMM,$nassured,$ilicense,$dbirth,$fsex,$iassured_cntry,$fmarriage,
    	         $itel,$imovephone,$iemail,$aassured_zip,$aassured,
    	         $nuser,$nbenef,$napplicant,$fcar_class,$iply_area,
    	         $iengine,$ibody,$itag,$ibrand,$nbrand_abbr,$dissue,$dmake_ym,
    	         $icar_type,$ncar_type,$qpt,$fpt,$qcylinder_tmp,$mcar_price,
    	         $dply_begin,$dply_end,$fcomp_class,$qdrunk_driving,$plia_acc_c,
    	         $iquery_num_c,$comp_prem,$dply_begin_c,$dply_end_c,
    	         $iquery_num,$v_ori_prem,$mtot_amt,$tot_prem,$mtot_amt_sug,
    	         $dmg_factor,$brg_factor,$psex_age,$lia_class,
    	         $ipolicy,$last_policy_2,$last_policy_3,
    	         $plia_acc,$pdmg_acc,$plia_acc_c,
    	         $pre_dply1_bgn,$pre_dply1_end,$icard_c,$pre_prem1,$ipolicy_c,
    	         $pre_dply2_bgn,$pre_dply2_end,$icard,$pre_prem2,$ipolicy,
    	         $pdmg_factor,$pbrg_factor,$forcemsg,$randmsg,
    	         $nrelation_appl, $iapplicant, $dbirth_appl, $fsex_appl,
                 $tmobile_appl, $apayment_zip, $apayment;
		
		/* �e���O�O���ư� -999 (1140313012_C01) */
    	printf("INSERT INTO ca_rioho_ren_reply_dtl\n");
    	if (freject == 0)
    	{
    		sprintf_s(stmt1, sizeof stmt1,
    		" INSERT INTO sysdb:ca_rioho_ren_reply_dtl "
    		" SELECT '%s','%s','%s',iins_type,minjured_cover,"
			"        CASE iins_type WHEN '56' THEN mdamage_cover ELSE mdeath_cover END,"
			"        CASE iins_type WHEN '56' THEN nvl((SELECT MAX(daily_pay) FROM ca_pa_ply_302 WHERE ipolicy = a.ipolicy AND iins_type = a.iins_type),0) ELSE mdamage_cover END,"
			"        mdeduct,mins_premium, ori_inj_cover, "
    		"        CASE iins_type WHEN '56' THEN ori_dam_cover ELSE ori_dea_cover END,"
			"        CASE iins_type WHEN '56' THEN nvl((SELECT MAX(ori_daily_pay) FROM ca_pa_ply_302 WHERE ipolicy = a.ipolicy AND iins_type = a.iins_type),0) ELSE ori_dam_cover END,"
		    "        ori_deduct,ori_premium, pre_inj_cover,"
    		"        CASE iins_type WHEN '56' THEN pre_dam_cover ELSE pre_dea_cover END,"
			"        CASE iins_type WHEN '56' THEN nvl((SELECT MAX(pre_daily_pay) FROM ca_pa_ply_302 WHERE ipolicy = a.ipolicy AND iins_type = a.iins_type),0) ELSE pre_dam_cover END,"
			"        pre_deduct,CASE pre_minsprem WHEN -999 THEN 0 ELSE pre_minsprem END AS pre_minsprem,CURRENT,'',qday, "
    		"        nvl((SELECT distinct iins_scope FROM ca_pa_ply_302 WHERE ipolicy = a.ipolicy AND iins_type = a.iins_type),'') "
			"   FROM ply_ins_type_302 a"
    		"  WHERE ipolicy in ('%s','%s'); ",ipolicy_c,ipolicy,sYYMM,ipolicy_c,ipolicy );			
    	}
    	else   /* �ګO�����ɫO�O����0 (1110712006_SC2) */
    	{
    		sprintf_s(stmt1, sizeof stmt1,
    		" INSERT INTO sysdb:ca_rioho_ren_reply_dtl "
    		" SELECT '%s','%s','%s',iins_type,minjured_cover,"
			"        CASE iins_type WHEN '56' THEN mdamage_cover ELSE mdeath_cover END,"
			"        CASE iins_type WHEN '56' THEN nvl((SELECT MAX(daily_pay) FROM ca_pa_ply_302 WHERE ipolicy = a.ipolicy AND iins_type = a.iins_type),0) ELSE mdamage_cover END,"
			"        mdeduct,0,ori_inj_cover, "
			"        CASE iins_type WHEN '56' THEN ori_dam_cover ELSE ori_dea_cover END,"
			"        CASE iins_type WHEN '56' THEN nvl((SELECT MAX(ori_daily_pay) FROM ca_pa_ply_302 WHERE ipolicy = a.ipolicy AND iins_type = a.iins_type),0) ELSE ori_dam_cover END,"
			"        ori_deduct,0,pre_inj_cover, "
			"        CASE iins_type WHEN '56' THEN pre_dam_cover ELSE pre_dea_cover END,"
			"        CASE iins_type WHEN '56' THEN nvl((SELECT MAX(pre_daily_pay) FROM ca_pa_ply_302 WHERE ipolicy = a.ipolicy AND iins_type = a.iins_type),0) ELSE pre_dam_cover END,"
			"        pre_deduct,CASE pre_minsprem WHEN -999 THEN 0 ELSE pre_minsprem END AS pre_minsprem,CURRENT,'',qday, "
    		"        nvl((SELECT distinct iins_scope FROM ca_pa_ply_302 WHERE ipolicy = a.ipolicy AND iins_type = a.iins_type),'') "
			"   FROM ply_ins_type_302 a"
    		"  WHERE ipolicy in ('%s','%s'); ",ipolicy_c,ipolicy,sYYMM,ipolicy_c,ipolicy );			
    	}
    	$PREPARE insert_dtl FROM $stmt1;
    	$EXECUTE insert_dtl;

		
		
    	/* ���M�Ĥ@�~�M�׻ݭn�^�� add by 061476 108.12.16 (1081018008_SC1) */
    	/* modify by 071004 (1101227001_SC1_���M��O���ɦ^���ɭץ�)*/
    	if (equip_cmp(nequipment,"114") && freject == 0)
    	{
    		sprintf_s(stmt_buf, sizeof stmt_buf,
    		    " SELECT ipolicy "
    		    "   FROM policy_302 "
    		    "  WHERE ipolicy[1,13] = '%s' and ipolicy matches '*-B'; ",ipolicy);
    		$PREPARE pre_policy_B FROM $stmt_buf;
    		$EXECUTE pre_policy_B INTO $ipolicy_B;

    		if (SQLCODE != SQLNOTFOUND)
    		{
    			printf("B�� INSERT INTO ca_rioho_ren_reply\n");
    			iqpro_month=0;
    			strcpy( dissue," "); strcpy( ibirth," "); strcpy( ipro_year," "); strcpy( qpro_month," ");
    			strcpy( dissue_mm," "); strcpy( dissue_dd," "); strcpy( dissue_yyyy," "); strcpy( dmake_ym," ");strcpy( dbirth," ");

    			$select dissue, ibirth, ipro_year, qpro_month
    			   into $dissue, $ibirth, $ipro_year, $qpro_month
    			   from policy_302
    			  where ipolicy = $ipolicy_B;

   			/***** ��z��Ʀ��ŦXtable���榡 *****/

   			/*�o�Ӥ�אּ�~��鳣�n�� modify by 061476 (1090415006_SC1)*/
    			cm_split_ymd(dissue,dissue_mm,dissue_dd,dissue_yyyy);
    			sprintf_s(dissue, sizeof dissue, "%s%s%s",dissue_yyyy,dissue_mm,dissue_dd);

    			iqpro_month = atoi(qpro_month);
    			sprintf_s(dmake_ym, sizeof dmake_ym, "%s%02d",ipro_year,iqpro_month);

    			if (strlen(trim(ibirth)) > 0 )
    			    strcpy(dbirth, cm_to_infdate(ibirth));

    			sprintf_s(stmt_B, sizeof stmt_B,
    			    " INSERT INTO sysdb:ca_rioho_ren_reply "
    			    " SELECT '%s',nvl(nassured,''),nvl(ilicense,''),'%s',decode(fsex,'1','1','2','2','3'), "
    			    "        decode(iassured_cntry,'9','1','2'),decode(fmarriage,'1','2','2','1',''), "
    			    "        nvl(itel,''),nvl(imovephone,''),nvl(iemail,''),nvl(aassured_zip,''),nvl(aassured,''), "
    			    "        nvl(nuser,''),nvl(nbenef,''),nvl(napplicant,''),nvl(fcar_class,''),nvl(iply_area,''),  "
    			    "        nvl(iengine,''),nvl(ibody,''),nvl(itag,''),nvl(ibrand,''),nvl(nbrand_abbr,''), "
    			    "        '%s','%s',nvl(icar_type,''),nvl(ncar_type,''),  "
    			    "        nvl(qpt,''),nvl(fpt,''),qcylinder::int ,replace(mcar_price,',',''),"
    			    "        dply_begin,dply_end,'',0,0,'',0,'','',"
    			    "        nvl(iquery_num,''),v_ori_prem,v_ori_prem,tot_prem, tot_prem,"
    			    "        nvl(dmg_factor,0.0),nvl(brg_factor,0.0),0,nvl(lia_class,''), "
    			    "        '%s','','','','','','','','','','','',0,0,0,"
    			    "        decode(plia_acc,'','0',plia_acc),"
    			    "        CASE WHEN nvl(pdmg_acc,'') <> '' THEN pdmg_acc "
    		 	    "             ELSE (CASE WHEN nvl(pdmg_acc_sug,'') <> '' THEN pdmg_acc_sug "
    		    	    "             ELSE '0' END) END,0, '','','',0,'',"
    			    "        pre_dply2_bgn,pre_dply2_end,icard,0,'%s',0,0,'',current,'','','' ,"
    			    "        ' ',' ','', ' ', ' ', ' ', ' ' "
    			    "        FROM policy_302 WHERE ipolicy = '%s'; ",
    			    sYYMM, dbirth, dissue, dmake_ym, ipolicy_B, ipolicy_B, ipolicy_B);
    			$PREPARE insert_policy_b FROM $stmt_B;
    			$EXECUTE insert_policy_b;

    			/*�D�ɥh�~�O�O��H�����ɥ[�`���D add by 061476(1100504003_SC1)*/
    			sprintf_s(stmt_B, sizeof stmt_B,
    			        " SELECT nvl(sum(pre_minsprem),0) "
    			        "   FROM ply_ins_type_302  "
    			        "  WHERE ipolicy in ('%s','%s'); ", ipolicy, ipolicy_B);
    			$PREPARE pre_prem_b FROM $stmt_B;
    			$EXECUTE pre_prem_b INTO $pre_prem2;

    			$update sysdb:ca_rioho_ren_reply
    			    set iold_rand_amt = $pre_prem2
    			  where iold_rand_insu_no in ($ipolicy,$ipolicy_B);

    			sprintf_s(stmt_B, sizeof stmt_B,
    			    " INSERT INTO sysdb:ca_rioho_ren_reply_dtl "
    			    " SELECT '','%s','%s',iins_type,minjured_cover,"
					"        CASE iins_type WHEN '56' THEN mdamage_cover ELSE mdeath_cover END,"
			        "        CASE iins_type WHEN '56' THEN nvl((SELECT MAX(daily_pay) FROM ca_pa_ply_302 WHERE ipolicy = a.ipolicy AND iins_type = a.iins_type),0) ELSE mdamage_cover END,"
					"        mdeduct,mins_premium,ori_inj_cover,"
					"        CASE iins_type WHEN '56' THEN ori_dam_cover ELSE ori_dea_cover END,"
			        "        CASE iins_type WHEN '56' THEN nvl((SELECT MAX(ori_daily_pay) FROM ca_pa_ply_302 WHERE ipolicy = a.ipolicy AND iins_type = a.iins_type),0) ELSE ori_dam_cover END,"
					"        ori_deduct,ori_premium,pre_inj_cover,"
					"        CASE iins_type WHEN '56' THEN pre_dam_cover ELSE pre_dea_cover END,"
			        "        CASE iins_type WHEN '56' THEN nvl((SELECT MAX(pre_daily_pay) FROM ca_pa_ply_302 WHERE ipolicy = a.ipolicy AND iins_type = a.iins_type),0) ELSE pre_dam_cover END,"
					"        pre_deduct,pre_minsprem,CURRENT,'',qday, "
    			    "        nvl((SELECT distinct iins_scope FROM ca_pa_ply_302  WHERE ipolicy = a.ipolicy AND iins_type = a.iins_type),'') "
					"   FROM ply_ins_type_302 a"
    			    "  WHERE ipolicy = '%s'; ", ipolicy_B, sYYMM, ipolicy_B);
    			$PREPARE insert_detail_b FROM $stmt_B;
    			$EXECUTE insert_detail_b;
    		}
    	}

    	cnt++;
    }
    $CLOSE acur;
    $FREE acur;

    if (cnt > 0)
    {
    	$INSERT INTO sysdb:ca_rioho_log
    	(fsend_type,iyyyymm,dcreate) values ('1',$sYYMM,current);
    }
    else
    {
    	EWRITE(userid, M_CMN_NO_DATA_FOUND, " �L�����J�A�нT�{�I ");
    }

	fclose(fp);
	
	/* ��O���ɦ��~�q���ӫO�� */	
	if(has_error)
	{
		char cmd_email1[200],cmd_email2[200],cmd_email3[200];
		strcpy(cmd_email1,"");strcpy(cmd_email2,"");strcpy(cmd_email3,"");
		/*sprintf_s(cmd_email1, sizeof cmd_email1,"uuencode /TEST/IPIS/rptftp/%s /TEST/IPIS/rptftp/%s ",Fname,Fname);/*���ե�*/
		/*sprintf_s(cmd_email2, sizeof cmd_email2,"cat /mis/mis1/131775/car7401_message.txt /TEST/IPIS/rptftp/%s > /TEST/IPIS/rptftp/combined_car7401.txt",Fname);/*���ե�*/
		/*strcpy(cmd_email3,"mailx -r \"ipisnew@tmnewa.com.tw\" -s \"$(echo \"[����]���M��O���ɦ��~�q��\"\"\\nContent-Type: text/plain; charset=\\\"big5\\\"\")\" -c \" \" sharonwu@tmnewa.com.tw,Shannon.Gao@tmnewa.com.tw,jay.jang@tmnewa.com.tw < /TEST/IPIS/rptftp/combined_car7401.txt");/*���ե�*/
		
		sprintf_s(cmd_email1, sizeof cmd_email1,"uuencode /PROD/IPISNEW/rptftp/%s /PROD/IPISNEW/rptftp/%s ",Fname,Fname);/*������*/
		sprintf_s(cmd_email2, sizeof cmd_email2,"cat /MIS/131775/car7401_message.txt /PROD/IPISNEW/rptftp/%s > /PROD/IPISNEW/rptftp/combined_car7401.txt",Fname);/*������*/
		strcpy(cmd_email3,"mailx -r \"ipisnew@tmnewa.com.tw\" -s \"$(echo \"���M��O���ɦ��~�q��\"\"\\nContent-Type: text/plain; charset=\\\"big5\\\"\")\" -c \" \" sharonwu@tmnewa.com.tw,Shannon.Gao@tmnewa.com.tw,jay.jang@tmnewa.com.tw < /PROD/IPISNEW/rptftp/combined_car7401.txt");/*������*/
		rc = system(cmd_email1);
		rc = system(cmd_email2);
		rc = system(cmd_email3);		

		rc=rptftpinsert(userid,"car7401",Fname);
		if (rc != 0){
			sprintf_s(sErrMsg, sizeof sErrMsg,"%s�g�Jrptftplist���~",Fname);
			$ROLLBACK WORK;
			return rc;
		}	
	}

    return M_CM_OK;

errexit:
	fclose(fp);
    sqlfatal();
    isql2 = SQLCODE;
    $ROLLBACK WORK;
    EWRITE(userid,isql2,sqlca.sqlerrm);
    return isql2;
}
/****************************************************************************/
init_data()
{
    strcpy( nassured, " ");
    strcpy( ilicense, " ");
    strcpy( ibirth, " ");
    strcpy( dbirth, " ");
    strcpy( fsex, " ");
    strcpy( iassured_cntry, " ");
    strcpy( fmarriage, " ");
    strcpy( itel, " ");
    strcpy( imovephone, " ");
    strcpy( iemail, " ");
    strcpy( aassured_zip, " ");
    strcpy( aassured, " ");
    strcpy( nuser, " ");
    strcpy( nbenef, " ");
    strcpy( napplicant, " ");
    strcpy( fcar_class, " ");
    strcpy( iply_area, " ");
    strcpy( iengine, " ");
    strcpy( ibody, " ");
    strcpy( itag, " ");
    strcpy( ibrand, " ");
    strcpy( nbrand_abbr, " ");
    strcpy( dissue, " ");
    strcpy( ipro_year, " ");
    strcpy( qpro_month, " ");
    strcpy( icar_type, " ");
    strcpy( ncar_type, " ");
    strcpy( qpt, " ");
    strcpy( fpt, " ");

    strcpy( dply_begin_c, " ");
    strcpy( dply_end_c, " ");
    strcpy( pre_dply1_bgn, " ");
    strcpy( pre_dply1_end, " ");
    strcpy( dply_begin, " ");
    strcpy( dply_end, " ");
    strcpy( pre_dply2_bgn, " ");
    strcpy( pre_dply2_end, " ");

    strcpy( fcomp_class, " ");
    strcpy( iquery_num_c, " ");

    strcpy( iquery_num, " ");
    strcpy( lia_class, " ");
    strcpy( last_policy_2, " ");
    strcpy( last_policy_3, " ");

    strcpy( dissue_mm, " ");
    strcpy( dissue_dd, " ");
    strcpy( dissue_yyyy, " ");
    strcpy( dmake_ym, " ");
    strcpy( tmp_yyyy, " ");
    strcpy( tmp_mm, " ");
    strcpy( tmp_dd, " ");

    strcpy( freason_reject_c, " ");
    strcpy( freason_reject, " ");

    strcpy( irelative_ply, " ");
    strcpy( irelative_ply_c, " ");
    strcpy( dply_pre, " ");
    strcpy( dply_pre_c, " ");
    strcpy( forcemsg, " ");
    strcpy( randmsg, " ");

    fmsg = 0; /* �w�]�i�J�p */
    fins_149 = icnt = 0;
    plia_acc = pdmg_acc = plia_acc_c = mcar_price = qcylinder = 0.0;
    dmg_factor = brg_factor = psex_age = pdmg_factor = pbrg_factor = 0.0;
    qdrunk_driving = comp_prem = mtot_amt = mtot_amt_sug = qcylinder_tmp = 0;
    v_ori_prem = tot_prem = iqpro_month = pre_prem1 = pre_prem2 = 0;
}
/******************************************************************************/
long car740_get_db()
{
	int return_code;

	$WHENEVER SQLERROR GOTO errexit;

	t = cm_today();
	strcpy(date,cm_edate_str(t));
	strcpy(dToday,cm_from_infdate_100(date));
	cm_split_ymd_100(dToday,nyy,nmm,ndd);

	if (db_select(DBName) == False)
	{
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}
	if ( (list = get_db_list(&count_db,DBName)) == (char*)0 )
	{
		EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
		return M_CM_NOT_DBLIST;
	}

	return_code = getApHome(sApHome);
	if (return_code < 0)
	{
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		return return_code;
	}
  return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car740_check() /* �����n��O��ƶ}��~������ */
{
	$char  yy[4],mm[3],dd[3],dyymm[6],fopen[2];
	iqty = 0;

	$WHENEVER SQLERROR GOTO errexit;

	cm_split_ymd_100(date1,yy,mm,dd);
	sprintf_s(dyymm, sizeof dyymm, "%s%s",yy,mm); /* ����~��(10807) */

	$SELECT count(*) INTO $iqty
	   FROM sysdb:ca_rioho_log
	  WHERE fsend_type = '1'
            AND iyyyymm = $sYYMM;

        if (iqty > 0)
        {
        	EWRITE(userid, M_CMN_NO_DATA_FOUND, " ����w����L��O���� ");
		return M_CMN_NO_DATA_FOUND;
        }

	$SELECT chiname INTO $fopen
	   FROM car_code
	  WHERE kind = 'RN' AND detail = 'car302'
            AND chiname = 'Y' AND detail2 = $dyymm;

        if (SQLCODE == SQLNOTFOUND)
        {
        	EWRITE(userid, M_CMN_NO_DATA_FOUND, " ��O��Ʃ|���}�� ");
		return M_CMN_NO_DATA_FOUND;
        }

        return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/