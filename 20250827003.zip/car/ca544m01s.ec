/************************************************/
/*                                              */
/*   PROGRAM : ca544m01s.ec by Pei-Chow Chen    */
/*   MODIFIER: Johnny Kuo 04/10/1997            */
/*   PURPOSE : server side standard program     */
/*                                              */
/************************************************/

#include <stdio.h>
#include <string.h>
#include <decimal.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "commsgs.h"
#include "carmsgs.h"
$include sqlca;
#include "safeclib.h"

long MsgCode;

long car544(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car544_insert(),car544_single_query(),car544_multiple_query(),
      car544_update_exec(),car544_squery(),car544_xquery(),car544_query2();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'S' : rtncode = car544_squery(reply);
                   break;  
  case 'X' : rtncode = car544_xquery(reply);
                   break;                     
  case 'A':
           rtncode=car544_insert(reply);
           break;
  case 'Q':
           rtncode=car544_single_query(reply);
           break;
  case 'M':
           rtncode=car544_multiple_query(reply);
           break;
  case 'D':
  case 'U':
           rtncode=car544_update_exec(reply,command,com_len);
           break;  
  case 'W': 
        rtncode=car544_query2(reply);
        break;         
  
  default :
        return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
 }
 return(rtncode);
}


long car544_squery(reply)
serverReply reply;
{
     $char DBName[5],D_dbsite[5];
     $char LHsBuffer[1024],sFullName[20];
     $char ipolicy[21];
     $char ipolicyN[21];
     $char s_icard[21],s_iassured[13],s_itag[CA_TAG_NUM];
     $char stmt[1024];
     
     int LHiBufLen;
     long MsgCode;

     cm_buf_get("%s",DBName);
     cm_buf_get("%s",ipolicy);

     $WHENEVER SQLERROR GOTO errexit;
 
     if (db_select(DBName) == False)
        { return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;}
    
        
     printf("ipolicy[%s]\n",ipolicy);
strcpy(ipolicyN,ipolicy); 
     
     if(ipolicy[2] == '0' || ipolicy[2] == '1' || ipolicy[2] == '2' || ipolicy[2] == '5' || ipolicy[2] == '6' || ipolicy[2] == '7')
       {
         strcpy(sFullName,get_car_full_db(ipolicy));
         strcat(sFullName,":");
       }     
     else
       {
         strcpy(sFullName," ");
       } 
     

printf(" 00000000000000  ipolicy[%s]\n",ipolicyN);
          
     sprintf_s(LHsBuffer,1024, "SELECT icard, iassured, itag \
                         FROM %spolicy \
                         WHERE ipolicy = '%s' ",sFullName ,ipolicyN);
                        
     
     $PREPARE appraisal_pre FROM $LHsBuffer;
     $DECLARE appraisal_cur CURSOR FOR appraisal_pre;
     $OPEN appraisal_cur;
     $FETCH appraisal_cur INTO $s_icard,$s_iassured, $s_itag;

printf("    LHsBuffer[%s]\n",LHsBuffer);

     if (SQLCODE == SQLNOTFOUND)
     {
         if(exitsub(reply,M_CM_NOT_FOUND) == True)
             return M_CM_NOT_FOUND;
         else
             return apiRC;
     }

     $CLOSE appraisal_cur;
     $FREE appraisal_cur;

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);

     cm_buf_put("%s %s %s",s_icard,s_iassured,s_itag);

     LHiBufLen = cm_buf_len(ReplyBuf);

     if(SendSyncReply(reply,ReplyBuf,LHiBufLen,api_OKComplete) == False)
     {
         $WHENEVER SQLERROR CONTINUE;
         $ROLLBACK WORK;
         return apiRC;
     }

     $WHENEVER SQLERROR GOTO errexit;
     return api_OKComplete;

     errexit:
        printf("sqlerrm:%s\n",sqlca.sqlerrm);
        $WHENEVER SQLERROR CONTINUE;
        MsgCode = SQLCODE;
        if (SQLCODE != 0) MsgCode = SQLCODE;
        return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

long car544_xquery(reply)
serverReply reply;
{
     $char DBName[5],D_dbsite[5];
     $char LHsBuffer[1024],sFullName[20];
     $char noth_com[21];
     $char w_nrin_abbre[11];
     $char stmt[1024];
     
     int LHiBufLen;
     long MsgCode;

     cm_buf_get("%s",DBName);
     cm_buf_get("%s",noth_com);

     $WHENEVER SQLERROR GOTO errexit;
 
     if (db_select(DBName) == False)
        { return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;}

   
     $SELECT nrin_abbre
       INTO $w_nrin_abbre
       FROM ri_ricom_info
      WHERE frin_attr='2'
        AND irin_com = $noth_com;
 
     if (SQLCODE == SQLNOTFOUND)
     {
       strcpy(w_nrin_abbre," ");
     }

  

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);

     cm_buf_put("%s ",w_nrin_abbre);

     LHiBufLen = cm_buf_len(ReplyBuf);

     if(SendSyncReply(reply,ReplyBuf,LHiBufLen,api_OKComplete) == False)
     {
         $WHENEVER SQLERROR CONTINUE;
         $ROLLBACK WORK;
         return apiRC;
     }

     $WHENEVER SQLERROR GOTO errexit;
     return api_OKComplete;

     errexit:
        printf("sqlerrm:%s\n",sqlca.sqlerrm);
        $WHENEVER SQLERROR CONTINUE;
        MsgCode = SQLCODE;
        if (SQLCODE != 0) MsgCode = SQLCODE;
        return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}



long car544_insert(reply)
serverReply reply;
{
     $char DBName[5],DBName1[5];
     $char LsBuffer[1024], sFullName[20];
     $char sFullName_sys[20];
     $char c_ipolicy[21],c_daccident[11],c_icard[21];
     $char c_iassured[13],c_itag[CA_TAG_NUM];
     $char c_noth_assured[41],c_noth_itag[CA_TAG_NUM];
     $char c_ivictim[16],c_nvictim[21];
     $char c_noth_com[8],c_noth_adjuster[11],c_ioth_tel[18];
     $char c_com_pay[2];
  
     int LiBufLen;
     cm_buf_get("%s",DBName);

     cm_buf_get("%s %s %s %s %s %s " , c_ipolicy,c_daccident,c_icard,
                 c_iassured,c_itag,c_noth_assured);
     cm_buf_get(" %s %s %s %s %s %s %s ",          
                 c_ivictim,c_nvictim,c_noth_itag,c_noth_com,
                 c_noth_adjuster,c_ioth_tel,c_com_pay);
  
     strcpy(c_daccident,cm_to_infdate(c_daccident));

     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
         return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     $BEGIN WORK;
     $WHENEVER SQLERROR GOTO errexit;

     strcpy(sFullName_sys, get_full_dbname("S1"));
     
     sprintf_s(LsBuffer,1024,"INSERT INTO %s:comp_claim \
            (ipolicy,daccident,icard,iassured,itag,noth_assured,  \
            ivictim,nvictim,noth_itag,noth_com, \
            noth_adjuster,ioth_tel,com_pay,dentry)\
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,today)",sFullName_sys);
  
     $PREPARE a_id FROM $LsBuffer;
     $EXECUTE a_id USING $c_ipolicy,$c_daccident,$c_icard,$c_iassured,$c_itag,
                         $c_noth_assured,$c_ivictim,$c_nvictim,$c_noth_itag,
                         $c_noth_com,$c_noth_adjuster,$c_ioth_tel,$c_com_pay;
  

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);
     LiBufLen = cm_buf_len(ReplyBuf);   

     if(SendSyncReply(reply,ReplyBuf,LiBufLen,api_OKComplete) == False)
     {
       $WHENEVER SQLERROR CONTINUE;
       $ROLLBACK WORK;
       return apiRC;
     }

     $WHENEVER SQLERROR GOTO errexit;
     $COMMIT WORK;
     return api_OKComplete;

     errexit:
         printf(" sqlerrm = %s\n",sqlca.sqlerrm);
         $WHENEVER SQLERROR CONTINUE;
         MsgCode = SQLCODE;
         $ROLLBACK WORK;
         if (SQLCODE != 0) MsgCode = SQLCODE;
         return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}


long car544_query2(reply)
serverReply reply;
{
   $char w_irin_com[8],w_frin_attr[2],w_nrin_abbre[11],irin_com[8];
   int rows, i;  
   
   $char DBName[5];
   int tmp_len,count,rtncode;
   long MsgCode;
   long long_mprem;
   cm_buf_get("%s", DBName);
        
   $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False) {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True) {
            return M_CM_DB_NOTOPEN;
        } else {
            return apiRC;
        }
    }
   cm_buf_init(ReplyBuf);
   cm_buf_res_msg();
   cm_buf_res_count();

   $DECLARE q_cura CURSOR for
     SELECT irin_com,frin_attr,nrin_abbre
       INTO $w_irin_com,$w_frin_attr,$w_nrin_abbre
       FROM ri_ricom_info
      WHERE frin_attr='2'
   ORDER BY irin_com;

   
 
   $OPEN q_cura;
  
    count=0;
    for(;;) 
    {
       $FETCH q_cura;
        if (SQLCODE != 0) 
        {
            break;
        }
        count++;
        cm_buf_put("%s %s %s",w_irin_com,w_frin_attr,w_nrin_abbre);
    }
   $CLOSE q_cura; $FREE  q_cura;
    cm_buf_put_count_seq(1, count);
   
    cm_buf_put_msg(M_CM_OK);                                            
    tmp_len = cm_buf_len(ReplyBuf);                                     
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False) {  
        return apiRC;                                                   
    } else {                                                            
        return api_OKComplete;                                          
    }                                                                   
errexit:                                       
    if(exitsub(reply,SQLCODE) == True) {       
        return SQLCODE;                        
    } else {                                   
        return apiRC;                          
    }                                          
} 

long car544_single_query(reply)
serverReply reply;
{
 
 $char DBName[5];
 $char m_ipolicy[21], m_icard[21],mq_daccident[11],m_daccident[11];
 $char m_iassured[13],m_itag[CA_TAG_NUM];
 $char m_noth_assured[41],m_noth_itag[CA_TAG_NUM];
 $char m_ivictim[16],m_nvictim[21];
 $char m_noth_com[8],m_noth_adjuster[11],m_ioth_tel[18];
   
 $char q_ipolicy[21],q_icard[21],q_iassured[13],q_itag[CA_TAG_NUM];
 $char q_noth_assured[41],q_noth_itag[CA_TAG_NUM],q_noth_com[8];
 $char q_ivictim[16],q_nvictim[21];
 $char q_noth_adjuster[11],q_ioth_tel[18];
 $char q_com_pay[2];
 $date daccident;
 $char q_daccident[11];
 $char q_dentry[11];
 $char a_com_pay[2];
 
 char ipolicy[21];
 $char str_q_daccident[11];   
 int tmp_len;
 
 cm_buf_get("%s %s %s %s %s %s %s %s",DBName,m_ipolicy,m_daccident,m_icard,m_iassured,m_ivictim,m_itag,m_noth_itag);
 
 strcpy(mq_daccident,cm_to_infdate(m_daccident));
 
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }
    printf("m_ipolicy[%s],m_daccident[%s],m_ivictim[%s]\n", m_ipolicy,mq_daccident,m_ivictim);
 
     $SELECT ipolicy,daccident,icard,iassured,itag,noth_assured,ivictim,
             nvictim,noth_itag,noth_com,noth_adjuster,ioth_tel,com_pay, dentry
        INTO $q_ipolicy,$q_daccident,$q_icard,$q_iassured,$q_itag,
             $q_noth_assured,$q_ivictim,$q_nvictim,$q_noth_itag,
             $q_noth_com,$q_noth_adjuster,$q_ioth_tel,$q_com_pay, $q_dentry
        FROM comp_claim
       WHERE ipolicy = $m_ipolicy
         AND daccident = $mq_daccident
         AND ivictim =  $m_ivictim;
     
 if(SQLCODE==SQLNOTFOUND)
 {
  if(exitsub(reply,M_CM_NOT_FOUND) == True)       /*?*/
    return M_CM_NOT_FOUND;                        /*?*/
  else
    return apiRC;
 }

 cm_buf_init(ReplyBuf);
 
 strcpy(str_q_daccident,cm_from_infdate_100(q_daccident));
 strcpy(q_dentry,cm_from_infdate_100(q_dentry));
 cm_buf_put("%l %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
             M_CM_OK, q_ipolicy,str_q_daccident,q_icard,q_iassured,q_itag,q_noth_assured,
                      q_ivictim,q_nvictim,
                      q_noth_itag,q_noth_com,q_noth_adjuster,q_ioth_tel,q_com_pay,q_dentry);


 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

 errexit:
   MsgCode = cm_show_sql_err("ca544_single_query", NULL);
  if(exitsub(reply,MsgCode) == True)
   return SQLCODE;
  else
   return apiRC;
}

long car544_multiple_query(reply)
serverReply reply;
{
 $char DBName[5];
 $char c_ipolicy[21],c_daccident[11],c_icard[21],c_iassured[13];
 $char c_itag[CA_TAG_NUM],c_noth_itag[CA_TAG_NUM];
 $char c_dentry[11];
 $char m_ipolicy[21],m_daccident[11],m_icard[21],m_iassured[13],m_ivictim[13];
 $char m_itag[CA_TAG_NUM],m_noth_itag[CA_TAG_NUM];
 $char car544_stmt[1024];
 /* $char sFullName_sys[20];  */
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0;
 int OPEN_STAR;
 cm_buf_get("%s %s %s %s %s %s %s",DBName,c_ipolicy,c_icard,c_iassured,c_itag,c_noth_itag,c_dentry);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }
printf("c_dentry==>[%s]\n",c_dentry);
if (c_dentry[0] == '*')
{
	sprintf_s(car544_stmt,1024,"SELECT ipolicy,daccident,icard,iassured,ivictim,itag,noth_itag \
     FROM comp_claim \
    WHERE ipolicy matches '%s' \
      AND icard matches '%s' \
      AND iassured matches '%s' \
      AND itag matches '%s' \
      AND noth_itag matches '%s' \
	   ORDER BY ipolicy",c_ipolicy,c_icard,c_iassured,c_itag,c_noth_itag);
}
else
{
	strcpy(c_dentry,cm_to_infdate(trim(c_dentry)));
	sprintf_s(car544_stmt,1024,"SELECT ipolicy,daccident,icard,iassured,ivictim,itag,noth_itag \
     FROM comp_claim \
    WHERE ipolicy matches '%s' \
      AND icard matches '%s' \
      AND iassured matches '%s' \
      AND itag matches '%s' \
      AND noth_itag matches '%s' \
	  AND dentry = '%s' \
	   ORDER BY ipolicy",c_ipolicy,c_icard,c_iassured,c_itag,c_noth_itag,c_dentry);
}
printf("%s\n",car544_stmt);
$PREPARE PRE1_1 FROM $car544_stmt;
$DECLARE q_cur2 CURSOR FOR PRE1_1;
$OPEN q_cur2;
 for(;;)
  {
    $FETCH q_cur2
	INTO $m_ipolicy,$m_daccident,$m_icard,$m_iassured,$m_ivictim,$m_itag,$m_noth_itag;  
    if (SQLCODE != 0) break;
    
    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();
     }
     
    strcpy(m_daccident,cm_from_infdate_100(m_daccident)); 
    
    cm_buf_put("%s %s %s %s %s %s %s ",m_ipolicy,m_daccident,m_icard,m_iassured,m_ivictim,m_itag,m_noth_itag);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
        $CLOSE q_cur;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;

        if(replycnt > 5) sleep(3);
        else if(replycnt > 3) sleep(2);
        else if(replycnt > 1) sleep(1);

        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        strcpy(m_daccident,cm_from_infdate_100(m_daccident));
        cm_buf_put("%s %s %s %s %s %s",m_ipolicy,m_daccident,m_ivictim,m_iassured,m_itag,m_noth_itag);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
  } /* for loop */

 $CLOSE q_cur2;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
    if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
      return M_CM_NOT_FOUND;                               /*?*/
    else
      return apiRC;
  }

 errexit:
   MsgCode = cm_show_sql_err("ca544_multiple_query", NULL);
   if(exitsub(reply,MsgCode) == True)
     return SQLCODE;
   else
     return apiRC;
}

long car544_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
        
 $char DBName[5];
 
 $char temp1_daccident[11];
 $char temp2_daccident[11];
 $char temp_daccident[11];
 $long cur_daccident = 0;

 $char cur_ipolicy[21],cur_icard[21];
 $char cur_iassured[13],cur_itag[CA_TAG_NUM];
 $char cur_noth_assured[41],cur_noth_itag[CA_TAG_NUM],cur_noth_com[8];
 $char cur_ivictim[16],cur_nvictim[21];
 $char cur_noth_adjuster[11],cur_ioth_tel[18];
 $char cur_com_pay[2];
 $char u__daccident[11];
 $char u_ipolicy[21],u_icard[21];
 $char u_iassured[13],u_itag[CA_TAG_NUM];
 $char u_noth_assured[41],u_noth_itag[CA_TAG_NUM],u_noth_com[8];
 $char u_ivictim[16],u_nvictim[21];
 $char u_noth_adjuster[11],u_ioth_tel[18];
 $char u_com_pay[2];
 
 $char q_ipolicy[21],q_daccident[11],q_icard[21];
 $char q_iassured[13],q_itag[CA_TAG_NUM];
 $char q_noth_assured[41],q_noth_itag[CA_TAG_NUM],q_noth_com[8];
 $char q_ivictim[16],q_nvictim[21];
 $char q_noth_adjuster[11],q_ioth_tel[18];
 $char q_com_pay[2];
 
 $char yy_daccident[11];
 $char str_daccident[11];
 
 char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
 int tmp_len,raw_len; long dummy;
   DBinfo *list;
   int i, j, is_del_fail=0, is_upd_fail=0;
   $char stmt_buf[300];

 comm = (char *) command;
 cm_buf_init(command);
 cm_buf_get("%c %s",&option,DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
     return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

/*  if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
     return exitsub(reply,M_CM_NOT_DBLIST) ? M_CM_NOT_DBLIST : apiRC;  */

 memcpy(&raw_len,&comm[com_len],sizeof(int));
 pos = &comm[com_len+sizeof(int)];
 raw_ptr = malloc(raw_len);
 if (raw_ptr != (char*)0)
  memcpy(raw_ptr,pos,raw_len);
 else
  { 
   return exitsub(reply,M_CM_NOT_MALLOC) ? M_CM_NOT_MALLOC : apiRC;
  }



 cm_buf_init(raw_ptr);          /* get index key from old record */
 cm_buf_get("%l %s %s %s %s %s %s %s %s %s %s %s %s %s",
             &dummy,q_ipolicy,q_daccident,q_icard,q_iassured,q_itag,
             q_noth_assured,q_ivictim,q_nvictim,q_noth_itag,q_noth_com,q_noth_adjuster,q_ioth_tel,q_com_pay);


  strcpy(temp1_daccident,cm_to_infdate(q_daccident));   

 $BEGIN WORK;

 $SELECT ipolicy,daccident,icard,iassured,itag,
         noth_assured,ivictim,nvictim,noth_itag,noth_com,noth_adjuster,ioth_tel,com_pay
    INTO $cur_ipolicy,$cur_daccident,$cur_icard,$cur_iassured,$cur_itag,
         $cur_noth_assured,$cur_ivictim,$cur_nvictim,$cur_noth_itag,$cur_noth_com,$cur_noth_adjuster,$cur_ioth_tel,
         $cur_com_pay
    FROM comp_claim
   WHERE ipolicy=$q_ipolicy AND daccident=$temp1_daccident AND ivictim = $q_ivictim; 


  /* if key value has been changed then SQLNOTFOUND,else put current value
     into cur_buf for comparison */

 if (SQLCODE == SQLNOTFOUND)
 {
   MsgCode = M_CM_NOT_FOUND;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(SQLCODE != 0) MsgCode = SQLCODE;
   return exitsub(reply,MsgCode) ? MsgCode : apiRC;
 }

  strcpy(str_daccident,cm_cdate_str_100(cur_daccident));    
 
 
 cm_buf_init(cur_buf);

 cm_buf_put("%l %s %s %s %s %s %s %s %s %s %s %s %s %s",
             dummy,cur_ipolicy,str_daccident,cur_icard,cur_iassured,cur_itag,
             cur_noth_assured,cur_ivictim,cur_nvictim,cur_noth_itag,cur_noth_com,cur_noth_adjuster,
             cur_ioth_tel,cur_com_pay);

 write(1,raw_ptr,raw_len);
 write(1,"\n",1);
 write(1,cur_buf,raw_len);
 write(1,"\n",1);

 printf("cur_buf[%s]\n",cur_buf);
 printf("raw_ptr[%s]\n",raw_ptr);
 if (memcmp(cur_buf,raw_ptr,raw_len-10) != 0) /* compare 2 records, not equal */ /*��10�O���F����������*/
 {
   MsgCode = M_CM_NOT_EQUAL;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(SQLCODE != 0) MsgCode = SQLCODE;
   return exitsub(reply,MsgCode) ? MsgCode : apiRC;
 }

 /* equal, then exec DB operation */

 if ( option == 'D' )
  {
	free(raw_ptr);
    sprintf_s(stmt_buf,300,"DELETE FROM comp_claim WHERE ipolicy= ?\
        AND daccident=?"); 
    $PREPARE d_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      
     }
    $EXECUTE d_id USING $cur_ipolicy,$cur_daccident;
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      
     }

   if( is_del_fail ) goto errexit;
   
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
   {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
   }

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
   else if (option == 'U')
  {
   cm_buf_init(command);

   cm_buf_get("%c %s %s %s %s %s %s %s %s %s %s %s %s %s %s ",
               &option,DBName,u_ipolicy,u__daccident,u_icard,u_iassured,u_itag,
               u_noth_assured,u_ivictim,u_nvictim,u_noth_itag,u_noth_com,u_noth_adjuster,u_ioth_tel,u_com_pay);

   strcpy(temp2_daccident,cm_to_infdate(u__daccident));   
   printf("u_ipolicy[%s]\n",u_ipolicy);
   printf("temp2_daccident[%s]\n",temp2_daccident);
   /* grasp old key */
   cm_buf_init(raw_ptr);
   free(raw_ptr);
   cm_buf_get("%l %s %s %s %s %s %s %s %s %s %s %s %s %s ",&dummy,
        q_ipolicy,q_daccident,q_icard,q_iassured,q_itag,
        q_noth_assured,q_ivictim,q_nvictim,q_noth_itag,q_noth_com,q_noth_adjuster,q_ioth_tel,q_com_pay);

   strcpy(temp_daccident,cm_to_infdate(q_daccident));  
   printf("temp_daccident[%s]\n",temp_daccident);
   $WHENEVER SQLERROR CONTINUE;
   
    printf("u_noth_adjuster[%s]\n",u_noth_adjuster);
    sprintf_s(stmt_buf,300,
                "UPDATE comp_claim \
                    SET (ipolicy,daccident,icard,iassured,itag, \
                         noth_assured,ivictim,nvictim,noth_itag,noth_com,noth_adjuster,ioth_tel,com_pay)\
                      = (?,?,?,?,?,?,?,?,?,?,?,?,?) \
                  WHERE ipolicy = ? AND daccident=? AND ivictim = ?");
    printf(" ******************stmt_buf[%s]\n",stmt_buf);
    $PREPARE u_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
     
     }
    $EXECUTE u_id USING $u_ipolicy,$temp2_daccident,$u_icard,$u_iassured,$u_itag,$u_noth_assured,
                        $u_ivictim,$u_nvictim,
                        $u_noth_itag,$u_noth_com,$u_noth_adjuster,$u_ioth_tel,$u_com_pay,
                        $q_ipolicy,$temp_daccident,$q_ivictim;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      
     }
     printf("temp_daccident[%s]\n",temp_daccident);
     if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
     {  
        sprintf_s(stmt_buf,300,"INSERT INTO comp_claim \
         (ipolicy,daccident,icard,iassured,itag,noth_assured,ivictim,nvictim,noth_itag,\
          noth_com,noth_adjuster,ioth_tel,com_pay)\
          VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");

      $PREPARE ua_id FROM $stmt_buf;
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        
       }
      $EXECUTE ua_id USING $u_ipolicy,$temp2_daccident,$u_icard,$u_iassured,$u_itag,
                           $u_noth_assured,$u_ivictim,$u_nvictim,$u_noth_itag,$u_noth_com,
                           $u_noth_adjuster,$u_ioth_tel,$u_com_pay;
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        
       }
     }
 
   if( is_upd_fail ) goto errexit;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
   {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
   }
   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else
  {
   free(raw_ptr);
   MsgCode = M_CM_WRONG_OPTION;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
    return MsgCode;
   else
    return apiRC;
  }

errexit:
  MsgCode = SQLCODE;
  cm_show_sql_err("ca544_update_exec", stmt_buf);
  $WHENEVER SQLERROR CONTINUE;
  $ROLLBACK WORK;
  if(SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True)
   return MsgCode;
  else
   return apiRC;
}
