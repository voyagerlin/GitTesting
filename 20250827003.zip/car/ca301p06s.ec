/**********************************************************************/
/*   program id   : ca301p06s.ec                                      */
/*   program name : �w��J���L��޲z����_mail�q���@�~                 */
/*   date written : 2016/10/14                                        */
/*   shell        : car3016_email                                     */
/*   exec time    : 00:05     mail_time:05:00                         */
/**********************************************************************/

#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include "print.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "othmsgs.h"
#include "commsgs.h"
#include "sqlfatal.h"

$char	DBName[5], userid[11];
DBinfo  *list;
char  	outputf[ N_FILE+1],sApHome[30],msgbuf[100];;
$loc_t 	ctxt;
$char	ftitle[1024],nsubject[512], nsub_1A[100],nsub_1M[100],nsub_5M[100],
        nsub_5A[100],max_date[11],min_date[11],sdate3[11],pre_ileader[11],
        nsub_13M[100],nsub_13A[100],nattachment[1025];
int     i,count_db;
$char   fname[100],fnameM[100];
$char   filename[150], filenameM[150];
$int    mail_count, cnt_leader, cnt_mgr1, cnt_mgr5,cnt_mgr13 ;
FILE    *fp;

/*----------------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
    int rc;
      
    batchinit();
    strcpy(DBName,  isNULLstr(argv[1]));
    strcpy(userid,  isNULLstr(argv[2]));
    strcpy(outputf, isNULLstr(argv[3]));
    
    rc = car3016_get_db();
    if (rc != M_CM_OK) {
        printf("error on car3016_get_db\n");
        return rc;
    }
    
    /* create temp table */        
    rc = car3016_init_data();
    if (rc != M_CM_OK) {
        if (rc == 1)
        {
            EWRITE(userid, rc, "�D�u�@��,���o�eemail�q��!");
            return rc;
        }
        else
        {
            printf("error on car3016_init_data\n");
            return rc;
        }
    }
    $delete from batchemail
      where project_id = "CAR3016"
        and mail_date = today;
        
    cnt_leader = cnt_mgr1 =  cnt_mgr5 = cnt_mgr13 = 0;
    /* �d�߹O�����L���� */        
    rc = car3016_ply_data();
    if (rc != M_CM_OK) {
        printf("error on car3016_ply_data\n");
        EWRITE(userid, rc, "�d�߹O�����L���Ʀ��~!");
        return rc;
    }

    /* �w��J���L����ӹO�@�ѱH�oemail_�޲z�H */
    rc = car3016_send_email_ileader1(); 
    if (rc != M_CM_OK) {
        printf("error on car3016_send_email_ileader1\n");
        EWRITE(userid, rc, "�O�ͮĤ�w��J���L�����E-mail�q���޲z�H���~!");
        return rc;
    }
    
    /* �H�O�ͮĤ�w��J���L�����E-mail�q���W�G���D�� */
    rc = car3016_send_email_mgr1(); 
    if (rc != M_CM_OK) {
        printf("error on car3016_send_email_mgr1\n");
        EWRITE(userid, rc, "�O�ͮĤ�w��J���L�����E-mail�q���D�ަ��~!");
        return rc;
    }
    
    /* �w��J���L����ӹO5�u�@�ѱH�oemail_�޲z�H */
    rc = car3016_send_email_ileader5(); 
    if (rc != M_CM_OK) {
        printf("error on car3016_send_email_ileader5\n");
        EWRITE(userid, rc, "�w��J���L����ӹO5�u�@�ѱH�oemail_�g��޲z�H���~!");
        return rc;
    }
    
    /* �H�O�ͮĤ�5�u�@�Ѥw��J���L�����E-mail�q���D�� */
    rc = car3016_send_email_mgr5(); 
    if (rc != M_CM_OK) {
        printf("error on car3016_send_email_mgr5\n");
        EWRITE(userid, rc, "�O�ͮĤ�w��J���L�����E-mail�q���D�ަ��~!");
        return rc;
    }
    
    /* car_code.kind = 'SP' �w��J���L����ӹO13�u�@�ѱH�oemail_�޲z�H 
            add by sylvia 105.12.07 (1051130006_C3) */
    rc = car3016_send_email_ileader13(); 
    if (rc != M_CM_OK) {
        printf("error on car3016_send_email_ileader13\n");
        EWRITE(userid, rc, "�w��J���L����ӹO5�u�@�ѱH�oemail_�g��޲z�H���~!");
        return rc;
    }
    
    /* car_code.kind = 'SP' �H�O�ͮĤ�13�u�@�Ѥw��J���L�����E-mail�q���D�� 
            add by sylvia 105.12.07 (1051130006_C3)*/
    rc = car3016_send_email_mgr13(); 
    if (rc != M_CM_OK) {
        printf("error on car3016_send_email_mgr13\n");
        EWRITE(userid, rc, "�O�ͮĤ�w��J���L�����E-mail�q���D�ަ��~!");
        return rc;
    }
    
    /* �o�e���浲�G��mail���ϥΪ� (�Ƶ{�w�]��:�ӫO�� ���ʱo�Ʋz(882158)) */
    printf("car3016_final_email() \n");
    rc=car3016_final_email();
    if (rc != M_CM_OK) {
        printf("error on car3016_final_email\n");
        return rc;
    }
    
    /* �^������ƥi��cmn201�U�� */
    printf("car3016_print() \n");
    rc=car3016_print();
    if (rc != M_CM_OK) {
        printf("error on car641_print\n");
        return rc;
    }
    
    printf("[car3016]:process ok!\n"); 
}
/*----------------------------------------------------------------------------*/
long car3016_get_db()
{
    int	rc;

    if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "��Ʈw�L�k�}��!");
       return M_CM_DB_NOTOPEN;
    }
    
    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }
    
    if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
       if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
          return M_CM_NOT_DBLIST;
    }

    return M_CM_OK;
}
/*----------------------------------------------------------------------------*/
long car3016_init_data()
{
    $int icnt;
    $char yy[4],mm[3],dd[3];
    
    $whenever sqlerror goto errexit;

    $select count(*) into $icnt
       from ca_holiday
      where holiday_bgn <= today
        and holiday_end >= today;
    
    if (icnt > 0)   return 1;   /* �D�u�@��,���o�eemail */
    
    /* �O�ͮĤ�@�� */
    $create temp table tb_wk1
    (
        nbranch      char(40),          -- �~�Z���
        ipolicy      char(20),          -- �O�渹
        nassured     varchar(120,0),    -- �O��W��
        iassured     char(12),          -- �Ȥ�νs
        iengine      char(25),          -- ������
        itag         char(12),          -- ����
        dissue       char(10),          -- �o�Ӧ~��
        dply_begin   char(10),          -- �O�I�_��
        dply_end     char(10),          -- �O�I����
        mprem        int,               -- �����O�O
        iofficer     char(10),          -- �g��N��
        nofficer     char(10),          -- �g��W�� 
        ileader      char(10),          -- �޲z�H�N��
        nleader      char(10),          -- �޲z�H�W��
        dentry       char(10),          -- ��J��
        fassured     char(1),           -- �Ȥ�ʽ�
        ncar_type    char(10),          -- �T/����
        dpolicy      char(10),          -- ñ���
        iquota       char(10),          -- �~�Z���N��
        iroute_main  char(20),          -- �D�q���N��
        iup_leader1  char(10),          -- �W�@�h�D�ޥN��
        nup_leader1  char(10),          -- �W�@�h�D�ަW��
        iup_leader2  char(10),          -- �W�G�h�D�ޥN��
        nup_leader2  char(10)           -- �W�G�h�D�ަW��
    )with no log;

    /* �O�ͮĤ餭�� */
    $create temp table tb_wk5
    (
        nbranch      char(40),          -- �~�Z���
        ipolicy      char(20),          -- �O�渹
        nassured     varchar(120,0),    -- �O��W��
        iassured     char(12),          -- �Ȥ�νs
        iengine      char(25),          -- ������
        itag         char(12),          -- ����
        dissue       char(10),          -- �o�Ӧ~��
        dply_begin   char(10),          -- �O�I�_��
        dply_end     char(10),          -- �O�I����
        mprem        int,               -- �����O�O
        iofficer     char(10),          -- �g��N��
        nofficer     char(10),          -- �g��W�� 
        ileader      char(10),          -- �޲z�H�N��
        nleader      char(10),          -- �޲z�H�W��
        dentry       char(10),          -- ��J��
        fassured     char(1),           -- �Ȥ�ʽ�
        ncar_type    char(10),          -- �T/����
        dpolicy      char(10),          -- ñ���
        iquota       char(10),          -- �~�Z���N��
        iroute_main  char(20),          -- �D�q���N��
        iup_leader1  char(10),          -- �W�@�h�D�ޥN��
        nup_leader1  char(10)           -- �W�@�h�D�ަW��
    )with no log;
    
    /* �O�ͮĤ�Q�T�� */
    $create temp table tb_wk13
    (
        nbranch      char(40),          -- �~�Z���
        ipolicy      char(20),          -- �O�渹
        nassured     varchar(120,0),    -- �O��W��
        iassured     char(12),          -- �Ȥ�νs
        iengine      char(25),          -- ������
        itag         char(12),          -- ����
        dissue       char(10),          -- �o�Ӧ~��
        dply_begin   char(10),          -- �O�I�_��
        dply_end     char(10),          -- �O�I����
        mprem        int,               -- �����O�O
        iofficer     char(10),          -- �g��N��
        nofficer     char(10),          -- �g��W�� 
        ileader      char(10),          -- �޲z�H�N��
        nleader      char(10),          -- �޲z�H�W��
        dentry       char(10),          -- ��J��
        fassured     char(1),           -- �Ȥ�ʽ�
        ncar_type    char(10),          -- �T/����
        dpolicy      char(10),          -- ñ���
        iquota       char(10),          -- �~�Z���N��
        iroute_main  char(20),          -- �D�q���N��
        iup_leader1  char(10),          -- �W�@�h�D�ޥN��
        nup_leader1  char(10)           -- �W�@�h�D�ަW��
    )with no log;

   
    /* ���Y */
    sprintf(ftitle,"%s %s %s",
           "���W��,�O�渹�X,�O��W��,�Τ@�s��,������,�P�Ӹ��X,�o�Ӧ~��,�O�I�ͮĤ�,",
           "�O�I�����,�����O�O,�g��H�N��,�g��H�W��,�޲z�H�N��,�޲z�H�W��,��J��,",
           "�Q�O�I�H�ʽ�,�T/����,ñ���\n");

    
    /* �D�� */
    cm_long_split_3ymd(cm_today(), yy,mm,dd);
    sprintf(sdate3,"%s%s%s",yy,mm,dd);
    sprintf(nsub_1A,"%s�O�ͮĤ�w��J���L�����",sdate3);
    sprintf(nsub_1M,"%s�O�ͮĤ�w��J���L�����(�D��)",sdate3);
    sprintf(nsub_5M,"%s�O�ͮĤ�5�u�@�Ѥw��J���L�����(�D��)",sdate3);
    sprintf(nsub_5A,"%s�O�ͮĤ�5�u�@�Ѥw��J���L�����",sdate3);
    sprintf(nsub_13M,"%s�O�ͮĤ�13�u�@�Ѥw��J���L�����(�D��)",sdate3);
    sprintf(nsub_13A,"%s�O�ͮĤ�13�u�@�Ѥw��J���L�����",sdate3);
    
	
    return M_CM_OK;

errexit:
        sqlfatal();
        EWRITE(userid,SQLCODE,sqlca.sqlerrm);
        return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car3016_ply_data()
{
    int	rc, n, m;
    $char stmt[3000], st1[2], stmt2[100], f1051109[2];
    $char nbranch[41], nassured[121], iassured[13], iengine[26], itag[13],
          dissue[11], dply_begin[11], dply_end[11], iofficer[11], nofficer[11],
          ileader[11], nleader[11], dentry[11], fassured[2], ncar_type[11],
          dpolicy[11], iup_leader1[11], nup_leader1[11],iup_leader2[11], 
          nup_leader2[11], iquota[11], mleader[11], mnleader[11], top_unit[11];
    $int mprem;
    
    $whenever sqlerror goto errexit;
    
    /* �t�X�e����10/31(�t)�w��J���O�渹7�u�@�Ѥ���L���ú�O�ި�,11/9�ߤW�鵲�妸���^�f
       �s�W����P�_: �t�Τ�< 105/11/10 �A���s�W���޿�J�鶷>=105/11/01�~�C�J�z�����
                     �t�Τ�>= 105/11/10 �A�������޿�J��A�@�ߦC�J�z�����     
                     add by sylvia 105.11.04 (1051102003_C2) */
    strcpy(f1051109," ");
    $select first 1 case when today  >= '11/09/2016' then '1' else '0' end 
       into $f1051109
       from car_code  where 1=1;
 
    if (strcmp(f1051109,"0") == 0)
        strcpy(stmt2," and a.dentry >= '11/01/2016' ");
    else
        strcpy(stmt2," ");
   
    /* �O�ͮĤ饼�L�� */
    strcpy(st1,"0");
    rc = GetWorkDate(st1);   
    for(i=0;i<count_db;i++) 
    {  	 
        sprintf(stmt,
            "insert into tb_wk1 \
             select c.nbranch, a.ipolicy, \
                    case when fassured in ('1','3','5') then b.nassured[1,2]||'�ݢ�' else b.nassured end, \
                    b.iassured, b.iengine, \
                    b.itag, b.dissue, a.dply_begin, a.dply_end, a.mdmg_prem+a.mlia_prem, \
                    a.iofficer, d.nname, a.ileader, e.nname, a.dentry, b.fassured, \
                    case when a.icar_type in ('01','02','32','34','35') then '����' else '�T��' end, \
                    a.dpolicy, a.iquota,(select iroute_main from cm_route where iroute = b.iroute), \
                    ' ', ' ', ' ', ' ' \
               from %s:ply_relation a, %s:policy b, sa_branch_type c, officer d, \
                    officer e, cm_pre_receive f \
              where a.ipolicy = b.ipolicy \
              �@and a.iquota = c.ibranch \
              �@and a.iofficer = d.iofficer \
              �@and a.ileader = e.iofficer \
              �@and e.iofficer = e.ileader \
              �@and (a.dply_begin <= '%s' and dply_begin > '%s') \
                and a.dpolicy is null \
                and a.ipolicy[6,7] <> 'VW' \
                and a.icar_type not in ('51','T1','T2') \
                and a.ipolicy = f.ipolicy1 and f.ipolicy2 = ' ' \
                and a.itmp_policy = f.ipre_rcv and f.iins_kind = '2' and ipre_end = ' ' \
                and f.ftype_sp not in ('20','JC') \
                and f.fverify_note = ' ' and f.fprint_note = ' ' \
                and a.fcard_class = '2' \
                and a.iofficer[1] not in ('W','H','N')  %s ;",
                list[i].dbname,list[i].dbname,max_date,min_date,stmt2);

        printf("stmt[%s]\n",stmt);
	    $prepare pre_over1 from $stmt;
	    $execute pre_over1;
	    
	    /* �s�Wcar_code.kind=SP ���ި��H add by sylvia 105.12.07 (1051130006_C3) 
	    sprintf(stmt,
            "insert into tb_wk1 \
             select c.nbranch, a.ipolicy, \
                    case when fassured in ('1','3','5') then b.nassured[1,2]||'�ݢ�' else b.nassured end, \
                    b.iassured, b.iengine, \
                    b.itag, b.dissue, a.dply_begin, a.dply_end, a.mdmg_prem+a.mlia_prem, \
                    a.iofficer, d.nname, a.ileader, e.nname, a.dentry, b.fassured, \
                    case when a.icar_type in ('01','02','32','34') then '����' else '�T��' end, \
                    a.dpolicy, a.iquota,(select iroute_main from cm_route where iroute = b.iroute), \
                    ' ', ' ', ' ', ' ' \
               from %s:ply_relation a, %s:policy b, sa_branch_type c, officer d, \
                    officer e, cm_pre_receive f \
              where a.ipolicy = b.ipolicy \
              �@and a.iquota = c.ibranch \
              �@and a.iofficer = d.iofficer \
              �@and a.ileader = e.iofficer \
              �@and e.iofficer = e.ileader \
              �@and (a.dply_begin <= '%s' and dply_begin > '%s') \
                and a.dpolicy is null \
                and a.ipolicy[6,7] <> 'VW' \
                and a.icar_type not in ('51','T1','T2') \
                and a.ipolicy = f.ipolicy1 and f.ipolicy2 = ' ' \
                and a.itmp_policy = f.ipre_rcv and f.iins_kind = '2' and ipre_end = ' ' \
                and f.ftype_sp not in ('20','JC') \
                and f.fverify_note = ' ' and f.fprint_note = ' ' \
                and a.fcard_class = '2' \
                and a.iofficer[1] not in ('W','H','N')  \
                and a.iofficer in (select detail2 from car_code where kind = 'SP' \
                      and detail = '2' and (engname = ' ' or engname is null)) %s ;",
                list[i].dbname,list[i].dbname,max_date,min_date,stmt2);

        printf("stmt[%s]\n",stmt);
	    $prepare pre_over2 from $stmt;
	    $execute pre_over2;*/
	 }

	strcpy(st1,"5");
    rc = GetWorkDate(st1);   
    for(i=0;i<count_db;i++) 
    {  	 
        sprintf(stmt,
            "insert into tb_wk5 \
             select c.nbranch, a.ipolicy, \
                    case when fassured in ('1','3','5') then b.nassured[1,2]||'�ݢ�' else b.nassured end, \
                    b.iassured, b.iengine, \
                    b.itag, b.dissue, a.dply_begin, a.dply_end, a.mdmg_prem+a.mlia_prem, \
                    a.iofficer, d.nname, a.ileader, e.nname, a.dentry, b.fassured, \
                    case when a.icar_type in ('01','02','32','34','35') then '����' else '�T��' end, \
                    a.dpolicy, a.iquota, (select iroute_main from cm_route where iroute = b.iroute),' ', ' ' \
               from %s:ply_relation a, %s:policy b, sa_branch_type c, officer d, \
                    officer e, cm_pre_receive f \
              where a.ipolicy = b.ipolicy \
              �@and a.iquota = c.ibranch \
              �@and a.iofficer = d.iofficer \
              �@and a.ileader = e.iofficer \
              �@and e.iofficer = e.ileader \
              �@and (a.dply_begin <= '%s' and dply_begin > '%s') \
                and a.dpolicy is null \
                and a.ipolicy[6,7] <> 'VW' \
                and a.icar_type not in ('51','T1','T2') \
                and a.fcard_class = '2' \
                and a.ipolicy = f.ipolicy1 and f.ipolicy2 = ' ' \
                and a.itmp_policy = f.ipre_rcv and f.iins_kind = '2' and ipre_end = ' ' \
                and f.ftype_sp not in ('20','JC') \
                and f.fverify_note = ' ' and f.fprint_note = ' ' \
                and a.iofficer[1] not in ('W','H','N') %s;",
                list[i].dbname,list[i].dbname,max_date,min_date,stmt2);

        printf("stmt[%s]\n",stmt);
	    $prepare pre_over5 from $stmt;
	    $execute pre_over5;
	 }
	 
	 
	/* �s�Wcar_code.kind=SP ���ި��H,�n�o�O��13�u�@�ѳq�� add by sylvia 105.12.07 (1051130006_C3) */ 
	strcpy(st1,"13");
    rc = GetWorkDate(st1);   
    for(i=0;i<count_db;i++) 
    {  	 
        sprintf(stmt,
            "insert into tb_wk13 \
             select c.nbranch, a.ipolicy, \
                    case when fassured in ('1','3','5') then b.nassured[1,2]||'�ݢ�' else b.nassured end, \
                    b.iassured, b.iengine, \
                    b.itag, b.dissue, a.dply_begin, a.dply_end, a.mdmg_prem+a.mlia_prem, \
                    a.iofficer, d.nname, a.ileader, e.nname, a.dentry, b.fassured, \
                    case when a.icar_type in ('01','02','32','34','35') then '����' else '�T��' end, \
                    a.dpolicy, a.iquota, (select iroute_main from cm_route where iroute = b.iroute),' ', ' ' \
               from %s:ply_relation a, %s:policy b, sa_branch_type c, officer d, \
                    officer e, cm_pre_receive f \
              where a.ipolicy = b.ipolicy \
              �@and a.iquota = c.ibranch \
              �@and a.iofficer = d.iofficer \
              �@and a.ileader = e.iofficer \
              �@and e.iofficer = e.ileader \
              �@and (a.dply_begin <= '%s' and dply_begin > '%s') \
                and a.dpolicy is null \
                and a.ipolicy[6,7] <> 'VW' \
                and a.icar_type not in ('51','T1','T2') \
                and a.fcard_class = '2' \
                and a.ipolicy = f.ipolicy1 and f.ipolicy2 = ' ' \
                and a.itmp_policy = f.ipre_rcv and f.iins_kind = '2' and ipre_end = ' ' \
                and f.ftype_sp not in ('20','JC') \
                and f.fverify_note = ' ' and f.fprint_note = ' ' \
                and a.iofficer[1] not in ('W','H','N') \
                and a.iofficer in (select detail2 from car_code where kind = 'SP' \
                      and detail = '2' and (engname = ' ' or engname is null)) %s;",
                list[i].dbname,list[i].dbname,max_date,min_date,stmt2);

        printf("stmt[%s]\n",stmt);
	    $prepare pre_over13 from $stmt;
	    $execute pre_over13;
	 }
	 
	 /* �R���j�v�O����-�D�q���N�� */
	 $delete from tb_wk1 where iroute_main in 
	    (select icode from ca_permit where iclass = '05' and ftype_sp in ('A1','A2'));
	 
	 $delete from tb_wk5 where iroute_main in 
	    (select icode from ca_permit where iclass = '05' and ftype_sp in ('A1','A2'));
	    
	 $delete from tb_wk13 where iroute_main in 
	    (select icode from ca_permit where iclass = '05' and ftype_sp in ('A1','A2'));
	 
	 /* �R���j�v�O����-�g��N�� */   
	 $delete from tb_wk1 where iofficer in 
	    (select icode from ca_permit where iclass = '06' and ftype_sp in ('A1','A2'));   
	 
	 $delete from tb_wk5 where iofficer in 
	    (select icode from ca_permit where iclass = '06' and ftype_sp in ('A1','A2'));   
	    
	 $delete from tb_wk13 where iofficer in 
	    (select icode from ca_permit where iclass = '06' and ftype_sp in ('A1','A2'));   
	  
	 /* �R���j�v�O����-�Q�O�I�HID */   
	 $delete from tb_wk1 where iassured in 
	    (select icode from ca_permit where iclass = '01' and ftype_sp in ('A1','A2'));   
	 
	 $delete from tb_wk5 where iassured in 
	    (select icode from ca_permit where iclass = '01' and ftype_sp in ('A1','A2'));   
	 
	 $delete from tb_wk13 where iassured in 
	    (select icode from ca_permit where iclass = '01' and ftype_sp in ('A1','A2'));   
	 
	 /* �W�G���D�� */  
	 $select unique ileader, iquota from tb_wk1 
	   union 
	  select unique ileader, iquota from tb_wk5 
	   union 
	  select unique ileader, iquota from tb_wk13 
	    into temp mgr1 with no log;
	    
	 
    sprintf(stmt,"select a.resp_name, a.top_unit, b.nname, c.ileader \
                    from personal:unitid2ef a, officer b , mgr1 c \
                   where a.resp_name = b.iofficer \
                     and b.iofficer = b.ileader \
                     and a.code_no = c.iquota ; ");
    
    $prepare pre_mgr1 from $stmt;
    $declare cur_mgr1 cursor for pre_mgr1;
    $open cur_mgr1;
    while(1)
    {
        $fetch cur_mgr1
          into $mleader, $top_unit, $mnleader, $ileader;
        if (SQLCODE==SQLNOTFOUND) break; 
        

        
        strcpy(mleader, trim(mleader));
        strcpy(ileader, trim(ileader));
        if (strcmp(ileader,mleader) == 0)
        {
            $select d.resp_name, d.top_unit, e.nname
               into $mleader, $top_unit, $mnleader
               from personal:unitid2ef d, officer e  
              where d.resp_name = e.iofficer 
                and e.iofficer = e.ileader 
                and d.code_no = $top_unit ;
             if (SQLCODE==SQLNOTFOUND) 
             {
                strcpy(mleader," ");
                strcpy(mnleader," ");
             }
        }
            
        /* �W�@���D�� */
        $update tb_wk1
            set iup_leader1 = $mleader,
                nup_leader1 = $mnleader
          where ileader = $ileader;
        
        $update tb_wk5
            set iup_leader1 = $mleader,
                nup_leader1 = $mnleader
          where ileader = $ileader;
          
        $update tb_wk13
            set iup_leader1 = $mleader,
                nup_leader1 = $mnleader
          where ileader = $ileader;
          
        /*-------------------------------------------------------------*/
        $select d.resp_name, d.top_unit, e.nname
           into $mleader, $top_unit, $mnleader
           from personal:unitid2ef d, officer e  
          where d.resp_name = e.iofficer 
            and e.iofficer = e.ileader 
            and d.code_no = $top_unit ;
        if (SQLCODE==SQLNOTFOUND) 
        {
            strcpy(mleader," ");
            strcpy(mnleader," ");
        }
        /* �W�G���D�� */
        $update tb_wk1
            set iup_leader2 = $mleader,
                nup_leader2 = $mnleader
          where ileader = $ileader;
    }
	$close cur_mgr1;
	$free cur_mgr1;
	
	return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car3016_send_email_ileader1()
{
    int	rc;
    $char stmt[3000], sopt[3];
    $char nbranch[41], nassured[121], iassured[13], iengine[26], itag[13],
          dissue[11], dply_begin[11], dply_end[11], iofficer[11], nofficer[11],
          ileader[11], nleader[11], dentry[11], fassured[2], ncar_type[11],
          dpolicy[11], iup_leader1[11], nup_leader1[11],iup_leader2[11], 
          nup_leader2[11], iquota[11], mleader[11], mnleader[11],
          ileader1[11], ipolicy[21];
    $int mprem;

	$whenever sqlerror goto errexit;
	
	strcpy(sopt,"1A"); 
	strcpy(stmt,"select nbranch, ipolicy, nassured, iassured, iengine, \
                        itag, dissue, dply_begin, dply_end, mprem, \
                        iofficer, nofficer, ileader, nleader, dentry, \
                        fassured, ncar_type, dpolicy \
                   from tb_wk1 where ileader = ? order by iofficer, dply_begin");
    printf("stmt[%s]\n",stmt);
    $PREPARE pre_day1 from $stmt;
    $DECLARE cur_day1 CURSOR FOR pre_day1;
	
    $DECLARE cur_leader1 CURSOR FOR
      SELECT DISTINCT ileader  INTO $ileader1
		FROM tb_wk1
	   WHERE 1=1
       ORDER BY ileader;
    $OPEN  cur_leader1;
    $FETCH cur_leader1;
    strcpy(pre_ileader,ileader1);
    mail_count=0;
    for(;;) 
    {
        if (SQLCODE==SQLNOTFOUND) break;

		if (strcmp(ileader1,pre_ileader)!=0) 
        {
	        rc = car3016_write_email(sopt);
	    	if (rc != M_CM_OK) {
					printf("error on car3016_write_email\n");
					return rc;
            }
	    	mail_count=0;
        }
		strcpy(pre_ileader,ileader1);
	
        mail_count++;
		printf("---ileader1:[%s]---\n",ileader1);
        memset(fname,0x00,sizeof(fname));
		memset(filename,0x00,sizeof(filename));
		sprintf(fname,"%s_�O�ͮĤ�w��J���L�����_%s",sdate3,trim(ileader1));
		sprintf(filename,"%s/rptftp/car_email/%s.csv",sApHome,fname);
        printf("----filename[%s]----\n",filename);
		fp=fopen(filename,"w");
		fprintf(fp,ftitle);
			
        $OPEN cur_day1 USING $ileader1;
	
		for(;;)
		{
		    $FETCH cur_day1 INTO $nbranch, $ipolicy, $nassured, $iassured, $iengine, 
                                 $itag, $dissue, $dply_begin, $dply_end, $mprem, 
                                 $iofficer, $nofficer, $ileader, $nleader, $dentry, 
                                 $fassured, $ncar_type, $dpolicy;
	                           
		    if (SQLCODE==SQLNOTFOUND) break;
		   	
		    fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%s,%s,%s,%s,%s,%s,%s,%s\n",
		                nbranch, ipolicy, nassured, iassured, iengine, 
                        itag, dissue, dply_begin, dply_end, mprem, 
                        iofficer, nofficer, ileader, nleader, dentry, 
                        fassured, ncar_type, dpolicy);
        }
		$CLOSE cur_day1;
		fclose(fp);
		$fetch cur_leader1;
	}
	$FREE cur_day1;
    $CLOSE cur_leader1;
    $FREE  cur_leader1;
	    
    if (mail_count!=0) {
        rc = car3016_write_email(sopt);
        if (rc!=M_CM_OK) {
		    printf("error on car3016_write_email\n");
			return rc;
		}
    }
    cnt_leader = mail_count;
    
    return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* -------------------------------------------------------------------------- */
long car3016_send_email_mgr1()
{
    int	rc;
    $char stmt[3000], sopt[3];
    $char nbranch[41], nassured[121], iassured[13], iengine[26], itag[13],
          dissue[11], dply_begin[11], dply_end[11], iofficer[11], nofficer[11],
          ileader[11], nleader[11], dentry[11], fassured[2], ncar_type[11],
          dpolicy[11], iup_leader1[11], nup_leader1[11],iup_leader2[11], 
          nup_leader2[11], iquota[11], mleader[11], mnleader[11],
          ileader1[11], ipolicy[21];
    $int mprem;

	$whenever sqlerror goto errexit;
	
	$select unique iup_leader1 as upd_leader from tb_wk1 where iup_leader1 <> ' '
	 union
	 select unique iup_leader2 as upd_leader from tb_wk1 where iup_leader1 <> ' '
	 into temp mgr2 with no log;
	
	strcpy(sopt,"1M"); 
	strcpy(stmt,"select nbranch, ipolicy, nassured, iassured, iengine, \
                        itag, dissue, dply_begin, dply_end, mprem, \
                        iofficer, nofficer, ileader, nleader, dentry, \
                        fassured, ncar_type, dpolicy \
                   from tb_wk1 where iup_leader1 = ? \
                 union \
                 select nbranch, ipolicy, nassured, iassured, iengine, \
                        itag, dissue, dply_begin, dply_end, mprem, \
                        iofficer, nofficer, ileader, nleader, dentry, \
                        fassured, ncar_type, dpolicy \
                   from tb_wk1 where iup_leader2 = ?  \
                        and iup_leader1<>iup_leader2 \
                         order by ileader, dply_begin");
    printf("stmt[%s]\n",stmt);
    $PREPARE pre_day_m1 from $stmt;
    $DECLARE cur_day_m1 CURSOR FOR pre_day_m1;
	
    $DECLARE cur_mgr_m1 CURSOR FOR
      SELECT DISTINCT upd_leader  INTO $ileader1
		FROM mgr2
	   WHERE upd_leader not in 
              (select empl_no from personal:asempl 
                WHERE work_type IN ('AA','AB','IA','IB') AND move_type < 59)
       ORDER BY upd_leader;
    $OPEN  cur_mgr_m1;
    $FETCH cur_mgr_m1;
    strcpy(pre_ileader,ileader1);
    mail_count=0;
    for(;;) 
    {
        if (SQLCODE==SQLNOTFOUND) break;

		if (strcmp(ileader1,pre_ileader)!=0) 
        {
	        rc = car3016_write_email(sopt);
	    	if (rc != M_CM_OK) {
					printf("error on car3016_write_email \n");
					return rc;
            }
	    	mail_count=0;
        }
		strcpy(pre_ileader,ileader1);
	
        mail_count++;
		printf("---ileader1:[%s]---\n",ileader1);
        memset(fname,0x00,sizeof(fname));
		memset(filename,0x00,sizeof(filename));
		sprintf(fname,"%s_�O�ͮĤ�w��J���L�����(�D��)_%s",sdate3,trim(ileader1));
		sprintf(filename,"%s/rptftp/car_email/%s.csv",sApHome,fname);
        printf("----filename[%s]----\n",filename);
		fp=fopen(filename,"w");
		fprintf(fp,ftitle);
			
        $OPEN cur_day_m1 USING $ileader1,$ileader1;
	
		for(;;)
		{
		    $FETCH cur_day_m1 INTO $nbranch, $ipolicy, $nassured, $iassured, $iengine, 
                                 $itag, $dissue, $dply_begin, $dply_end, $mprem, 
                                 $iofficer, $nofficer, $ileader, $nleader, $dentry, 
                                 $fassured, $ncar_type, $dpolicy;
	                           
		    if (SQLCODE==SQLNOTFOUND) break;
		   	
		    fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%s,%s,%s,%s,%s,%s,%s,%s\n",
		                nbranch, ipolicy, nassured, iassured, iengine, 
                        itag, dissue, dply_begin, dply_end, mprem, 
                        iofficer, nofficer, ileader, nleader, dentry, 
                        fassured, ncar_type, dpolicy);
        }
		$CLOSE cur_day_m1;
		fclose(fp);
		$fetch cur_mgr_m1;
	}
	$FREE cur_day_m1;
    $CLOSE cur_mgr_m1;
    $FREE  cur_mgr_m1;
	    
    if (mail_count!=0) {
        rc = car3016_write_email(sopt);
        if (rc!=M_CM_OK) {
		    printf("error on car3016_write_email\n");
			return rc;
		}
    }
    
    cnt_mgr1 = mail_count;       
           
    return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* -------------------------------------------------------------------------- */

long car3016_send_email_mgr5()
{
    int	rc;
    $char stmt[3000], sopt[3];
    $char nbranch[41], nassured[121], iassured[13], iengine[26], itag[13],
          dissue[11], dply_begin[11], dply_end[11], iofficer[11], nofficer[11],
          ileader[11], nleader[11], dentry[11], fassured[2], ncar_type[11],
          dpolicy[11], iup_leader1[11], nup_leader1[11],iup_leader2[11], 
          nup_leader2[11], iquota[11], mleader[11], mnleader[11],
          ileader1[11], ipolicy[21];
    $int mprem;

	$whenever sqlerror goto errexit;
	
	strcpy(sopt,"5M"); 
	strcpy(stmt,"select nbranch, ipolicy, nassured, iassured, iengine, \
                        itag, dissue, dply_begin, dply_end, mprem, \
                        iofficer, nofficer, ileader, nleader, dentry, \
                        fassured, ncar_type, dpolicy \
                   from tb_wk5 where iup_leader1 = ? \
                         order by ileader, dply_begin");
    printf("stmt[%s]\n",stmt);
    $PREPARE pre_day_m5 from $stmt;
    $DECLARE cur_day_m5 CURSOR FOR pre_day_m5;
	
    $DECLARE cur_mgr_m5 CURSOR FOR
      SELECT DISTINCT iup_leader1  INTO $ileader1
		FROM tb_wk5
	   WHERE iup_leader1 not in 
              (select empl_no from personal:asempl 
                WHERE work_type IN ('AA','AB','IA','IB') AND move_type < 59)
       ORDER BY iup_leader1;
    $OPEN  cur_mgr_m5;
    $FETCH cur_mgr_m5;
    strcpy(pre_ileader,ileader1);
    mail_count=0;
    for(;;) 
    {
        if (SQLCODE==SQLNOTFOUND) break;

		if (strcmp(ileader1,pre_ileader)!=0) 
        {
	        rc = car3016_write_email(sopt);
	    	if (rc != M_CM_OK) {
					printf("error on car3016_write_email \n");
					return rc;
            }
	    	mail_count=0;
        }
		strcpy(pre_ileader,ileader1);
	
        mail_count++;
		printf("---ileader1:[%s]---\n",ileader1);
        memset(fname,0x00,sizeof(fname));
		memset(filename,0x00,sizeof(filename));
		sprintf(fname,"%s_�O�ͮĤ�5�u�@�Ѥw��J���L�����(M)_%s",sdate3,trim(ileader1));
		sprintf(filename,"%s/rptftp/car_email/%s.csv",sApHome,fname);
        printf("----filename[%s]----\n",filename);
		fp=fopen(filename,"w");
		fprintf(fp,ftitle);
			
        $OPEN cur_day_m5 USING $ileader1;
	
		for(;;)
		{
		    $FETCH cur_day_m5 INTO $nbranch, $ipolicy, $nassured, $iassured, $iengine, 
                                 $itag, $dissue, $dply_begin, $dply_end, $mprem, 
                                 $iofficer, $nofficer, $ileader, $nleader, $dentry, 
                                 $fassured, $ncar_type, $dpolicy;
	                           
		    if (SQLCODE==SQLNOTFOUND) break;
		   	
		    fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%s,%s,%s,%s,%s,%s,%s,%s\n",
		                nbranch, ipolicy, nassured, iassured, iengine, 
                        itag, dissue, dply_begin, dply_end, mprem, 
                        iofficer, nofficer, ileader, nleader, dentry, 
                        fassured, ncar_type, dpolicy);
        }
		$CLOSE cur_day_m5;
		fclose(fp);
		$fetch cur_mgr_m5;
	}
	$FREE cur_day_m5;
    $CLOSE cur_mgr_m5;
    $FREE  cur_mgr_m5;
	    
    if (mail_count!=0) {
        rc = car3016_write_email(sopt);
        if (rc!=M_CM_OK) {
		    printf("error on car3016_write_email\n");
			return rc;
		}
    }

    cnt_mgr5 = mail_count;    
     
    return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/* ------------------------------------------------------------------------- */
long car3016_send_email_ileader5()
{
    int	rc;
    $char stmt[3000], sopt[3];
    $char nbranch[41], nassured[121], iassured[13], iengine[26], itag[13],
          dissue[11], dply_begin[11], dply_end[11], iofficer[11], nofficer[11],
          ileader[11], nleader[11], dentry[11], fassured[2], ncar_type[11],
          dpolicy[11], iup_leader1[11], nup_leader1[11],iup_leader2[11], 
          nup_leader2[11], iquota[11], mleader[11], mnleader[11],
          ileader1[11], ipolicy[21];
    $int mprem;

	$whenever sqlerror goto errexit;
	
	strcpy(sopt,"5A"); 
	strcpy(stmt,"select nbranch, ipolicy, nassured, iassured, iengine, \
                        itag, dissue, dply_begin, dply_end, mprem, \
                        iofficer, nofficer, ileader, nleader, dentry, \
                        fassured, ncar_type, dpolicy \
                   from tb_wk5 where ileader = ? order by iofficer, dply_begin");
    printf("stmt[%s]\n",stmt);
    $PREPARE pre_day5 from $stmt;
    $DECLARE cur_day5 CURSOR FOR pre_day5;
	
    $DECLARE cur_leader5 CURSOR FOR
      SELECT DISTINCT ileader  INTO $ileader1
		FROM tb_wk5
	   WHERE 1=1
       ORDER BY ileader;
    $OPEN  cur_leader5;
    $FETCH cur_leader5;
    strcpy(pre_ileader,ileader1);
    mail_count=0;
    for(;;) 
    {
        if (SQLCODE==SQLNOTFOUND) break;

		if (strcmp(ileader1,pre_ileader)!=0) 
        {
	        rc = car3016_write_email(sopt);
	    	if (rc != M_CM_OK) {
					printf("error on car3016_write_email\n");
					return rc;
            }
	    	mail_count=0;
        }
		strcpy(pre_ileader,ileader1);
	
        mail_count++;
		printf("---ileader1:[%s]---\n",ileader1);
        memset(fname,0x00,sizeof(fname));
		memset(filename,0x00,sizeof(filename));
		sprintf(fname,"%s_�O�ͮĤ�5�u�@�Ѥw��J���L�����_%s",sdate3,trim(ileader1));
		sprintf(filename,"%s/rptftp/car_email/%s.csv",sApHome,fname);
        printf("----filename[%s]----\n",filename);
		fp=fopen(filename,"w");
		fprintf(fp,ftitle);
			
        $OPEN cur_day5 USING $ileader1;
	
		for(;;)
		{
		    $FETCH cur_day5 INTO $nbranch, $ipolicy, $nassured, $iassured, $iengine, 
                                 $itag, $dissue, $dply_begin, $dply_end, $mprem, 
                                 $iofficer, $nofficer, $ileader, $nleader, $dentry, 
                                 $fassured, $ncar_type, $dpolicy;
	                           
		    if (SQLCODE==SQLNOTFOUND) break;
		   	
		    fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%s,%s,%s,%s,%s,%s,%s,%s\n",
		                nbranch, ipolicy, nassured, iassured, iengine, 
                        itag, dissue, dply_begin, dply_end, mprem, 
                        iofficer, nofficer, ileader, nleader, dentry, 
                        fassured, ncar_type, dpolicy);
        }
		$CLOSE cur_day5;
		fclose(fp);
		$fetch cur_leader5;
	}
	$FREE cur_day5;
    $CLOSE cur_leader5;
    $FREE  cur_leader5;
	    
    if (mail_count!=0) {
        rc = car3016_write_email(sopt);
        if (rc!=M_CM_OK) {
		    printf("error on car3016_write_email\n");
			return rc;
		}
    }
    cnt_leader = mail_count;
    
    return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/*---------------------------------------------------------------------------*/
long car3016_write_email(opt)
char opt[4];
{
    $char mmsg[1000], email[51], chinese_name[11];
    $whenever sqlerror goto errexit;
    
    strcpy(opt, trim(opt));
    
    if (strcmp(opt,"1A") == 0)
    {
        /* email��� */
        sprintf(mmsg,
	        "�U��D�ޡB�P�� ��w�G</P>\n\n"
	        "���󬰸g��H�w��J���X��v�O�ͮĤ���ӡA�но��t�������O�X��C</P>\n"
	        "�s����� �ӫO���֫O�� �p�����D�Ь��U��쨮�I�֫O�H�� \n");
	    
	    /* mail �D�� */
	    strcpy(nsubject,nsub_1A);
    }
    else if(strcmp(opt,"1M") == 0)
    {
        /* email��� */
        sprintf(mmsg,
	        "�U��D�ޤ�w�G</P>\n\n"
	        "���󬰸g��H�w��J���X��v�O�ͮĤ���ӡA�но��t�������O�X��C</P>\n"
	        "�s����� �ӫO���֫O�� �p�����D�Ь��U��쨮�I�֫O�H�� \n");
	    
	    /* mail �D�� */
	    strcpy(nsubject,nsub_1M);

    }
    else if(strcmp(opt,"5M") == 0)
    {
        /* email��� */
        sprintf(mmsg,
	        "�U��D�ޤ�w�G</p>  \n\n"
                "���󬰸g��H�w��J���X��w�O�ͮĤ�5�u�@�ѩ��ӡA�но��t�ܮ��s�t��(car161)�����f�֧@�~�C</P> \n"
                "�s����� �ӫO���֫O�� �p�����D�Ь��U��쨮�I�֫O�H�� \n");
        
        /* mail �D�� */
	    strcpy(nsubject,nsub_5M);
    }
    else if(strcmp(opt,"5A") == 0)
    {
        /* email��� */
        sprintf(mmsg,
	        "�U��D�ޡB�P�� ��w�G</p>  \n\n"
                "���󬰸g��H�w��J���X��w�O�ͮĤ�5�u�@�ѩ��ӡA�но��t�������O�X��C</P> \n"
                "�s����� �ӫO���֫O�� �p�����D�Ь��U��쨮�I�֫O�H�� \n");
        
        /* mail �D�� */
	    strcpy(nsubject,nsub_5A);
    }
    else if(strcmp(opt,"13A") == 0)
    {
        /* email��� */
        sprintf(mmsg,
	        "�U��D�ޡB�P�� ��w�G</p>  \n\n"
                "���󬰸g��H�w��J���X��w�O�ͮĤ�13�u�@�ѩ��ӡA�но��t�������O�X��C</P> \n"
                "�s����� �ӫO���֫O�� �p�����D�Ь��U��쨮�I�֫O�H�� \n");
        
        /* mail �D�� */
	    strcpy(nsubject,nsub_13A);
    }
    else if(strcmp(opt,"13M") == 0)
    {
        /* email��� */
        sprintf(mmsg,
	        "�U��D�ޤ�w�G</p>  \n\n"
                "���󬰸g��H�w��J���X��w�O�ͮĤ�13�u�@�ѩ��ӡA�но��t�ܮ��s�t��(car161)�����f�֧@�~�C</P> \n"
                "�s����� �ӫO���֫O�� �p�����D�Ь��U��쨮�I�֫O�H�� \n");
        
        /* mail �D�� */
	    strcpy(nsubject,nsub_13M);
    }
    
 
    
    ctxt.loc_loctype = LOCMEMORY;
    ctxt.loc_buffer = mmsg;
    ctxt.loc_bufsize = 9000;
    ctxt.loc_size =  strlen(mmsg) + 1;

    strcpy(email," ");
    $select email,chinese_name
       into $email,$chinese_name
       from personal:asempl
      where empl_no = $pre_ileader;

    strcpy(email,trim(email));
    if (strlen(email) != 0){ 
      strcat(email,"@tmnewa.com.tw");
      
    /* ���R��batchemail�즳��mail,�A�s�W�@���s�� */
    $delete from batchemail
      where project_id = "CAR3016"
        and mail_date = today
        and receiver_email = $email
        and receiver_name = $chinese_name
        and nsubject = $nsubject;
			
      /* 1110322014_SC1_batchemail�ಾ�ܷs���x */
      if (strlen(trim(fname)) != 0) sprintf(nattachment,"%s.csv",trim(fname));
      printf("-----nattachment:[%s]-----\n",nattachment);
      
      $INSERT INTO batchemail
		  (project_id, mail_date, receiver_email, receiver_name, cc, 
		   content, key, mail_count, nsubject, nattachment)
       VALUES
		  ("CAR3016", today, $email, $chinese_name, " ", 
		   $ctxt, $fname, $mail_count, $nsubject, $nattachment);
    }
    
    return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/* -------------------------------------------------------------------- */
long car3016_send_email_ileader13()
{
    int	rc;
    $char stmt[3000], sopt[4];
    $char nbranch[41], nassured[121], iassured[13], iengine[26], itag[13],
          dissue[11], dply_begin[11], dply_end[11], iofficer[11], nofficer[11],
          ileader[11], nleader[11], dentry[11], fassured[2], ncar_type[11],
          dpolicy[11], iup_leader1[11], nup_leader1[11],iup_leader2[11], 
          nup_leader2[11], iquota[11], mleader[11], mnleader[11],
          ileader1[11], ipolicy[21];
    $int mprem;

	$whenever sqlerror goto errexit;
	
	strcpy(sopt,"13A"); 
	strcpy(stmt,"select nbranch, ipolicy, nassured, iassured, iengine, \
                        itag, dissue, dply_begin, dply_end, mprem, \
                        iofficer, nofficer, ileader, nleader, dentry, \
                        fassured, ncar_type, dpolicy \
                   from tb_wk13 where ileader = ? order by iofficer, dply_begin");
    printf("stmt[%s]\n",stmt);
    $PREPARE pre_day13 from $stmt;
    $DECLARE cur_day13 CURSOR FOR pre_day13;
	
    $DECLARE cur_leader13 CURSOR FOR
      SELECT DISTINCT ileader  INTO $ileader1
		FROM tb_wk13
	   WHERE 1=1
       ORDER BY ileader;
    $OPEN  cur_leader13;
    $FETCH cur_leader13;
    strcpy(pre_ileader,ileader1);
    mail_count=0;
    for(;;) 
    {
        if (SQLCODE==SQLNOTFOUND) break;

		if (strcmp(ileader1,pre_ileader)!=0) 
        {
	        rc = car3016_write_email(sopt);
	    	if (rc != M_CM_OK) {
					printf("error on car3016_write_email\n");
					return rc;
            }
	    	mail_count=0;
        }
		strcpy(pre_ileader,ileader1);
	
        mail_count++;
		printf("---ileader1:[%s]---\n",ileader1);
        memset(fname,0x00,sizeof(fname));
		memset(filename,0x00,sizeof(filename));
		sprintf(fname,"%s_�O�ͮĤ�13�u�@�Ѥw��J���L�����_%s",sdate3,trim(ileader1));
		sprintf(filename,"%s/rptftp/car_email/%s.csv",sApHome,fname);
        printf("----filename[%s]----\n",filename);
		fp=fopen(filename,"w");
		fprintf(fp,ftitle);
			
        $OPEN cur_day13 USING $ileader1;
	
		for(;;)
		{
		    $FETCH cur_day13 INTO $nbranch, $ipolicy, $nassured, $iassured, $iengine, 
                                 $itag, $dissue, $dply_begin, $dply_end, $mprem, 
                                 $iofficer, $nofficer, $ileader, $nleader, $dentry, 
                                 $fassured, $ncar_type, $dpolicy;
	                           
		    if (SQLCODE==SQLNOTFOUND) break;
		   	
		    fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%s,%s,%s,%s,%s,%s,%s,%s\n",
		                nbranch, ipolicy, nassured, iassured, iengine, 
                        itag, dissue, dply_begin, dply_end, mprem, 
                        iofficer, nofficer, ileader, nleader, dentry, 
                        fassured, ncar_type, dpolicy);
        }
		$CLOSE cur_day13;
		fclose(fp);
		$fetch cur_leader13;
	}
	$FREE cur_day13;
    $CLOSE cur_leader13;
    $FREE  cur_leader13;
	    
    if (mail_count!=0) {
        rc = car3016_write_email(sopt);
        if (rc!=M_CM_OK) {
		    printf("error on car3016_write_email\n");
			return rc;
		}
    }
    cnt_leader = mail_count;
    
    return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* -------------------------------------------------------------------------- */
long car3016_send_email_mgr13()
{
    int	rc;
    $char stmt[3000], sopt[4];
    $char nbranch[41], nassured[121], iassured[13], iengine[26], itag[13],
          dissue[11], dply_begin[11], dply_end[11], iofficer[11], nofficer[11],
          ileader[11], nleader[11], dentry[11], fassured[2], ncar_type[11],
          dpolicy[11], iup_leader1[11], nup_leader1[11],iup_leader2[11], 
          nup_leader2[11], iquota[11], mleader[11], mnleader[11],
          ileader1[11], ipolicy[21];
    $int mprem;

	$whenever sqlerror goto errexit;
	
	strcpy(sopt,"13M"); 
	strcpy(stmt,"select nbranch, ipolicy, nassured, iassured, iengine, \
                        itag, dissue, dply_begin, dply_end, mprem, \
                        iofficer, nofficer, ileader, nleader, dentry, \
                        fassured, ncar_type, dpolicy \
                   from tb_wk13 where iup_leader1 = ? \
                         order by ileader, dply_begin");
    printf("stmt[%s]\n",stmt);
    $PREPARE pre_day_m13 from $stmt;
    $DECLARE cur_day_m13 CURSOR FOR pre_day_m13;
	
    $DECLARE cur_mgr_m13 CURSOR FOR
      SELECT DISTINCT iup_leader1  INTO $ileader1
		FROM tb_wk13
	   WHERE iup_leader1 not in 
              (select empl_no from personal:asempl 
                WHERE work_type IN ('AA','AB','IA','IB') AND move_type < 59)
       ORDER BY iup_leader1;
    $OPEN  cur_mgr_m13;
    $FETCH cur_mgr_m13;
    strcpy(pre_ileader,ileader1);
    mail_count=0;
    for(;;) 
    {
        if (SQLCODE==SQLNOTFOUND) break;

		if (strcmp(ileader1,pre_ileader)!=0) 
        {
	        rc = car3016_write_email(sopt);
	    	if (rc != M_CM_OK) {
					printf("error on car3016_write_email \n");
					return rc;
            }
	    	mail_count=0;
        }
		strcpy(pre_ileader,ileader1);
	
        mail_count++;
		printf("---ileader1:[%s]---\n",ileader1);
        memset(fname,0x00,sizeof(fname));
		memset(filename,0x00,sizeof(filename));
		sprintf(fname,"%s_�O�ͮĤ�13�u�@�Ѥw��J���L�����(M)_%s",sdate3,trim(ileader1));
		sprintf(filename,"%s/rptftp/car_email/%s.csv",sApHome,fname);
        printf("----filename[%s]----\n",filename);
		fp=fopen(filename,"w");
		fprintf(fp,ftitle);
			
        $OPEN cur_day_m13 USING $ileader1;
	
		for(;;)
		{
		    $FETCH cur_day_m13 INTO $nbranch, $ipolicy, $nassured, $iassured, $iengine, 
                                 $itag, $dissue, $dply_begin, $dply_end, $mprem, 
                                 $iofficer, $nofficer, $ileader, $nleader, $dentry, 
                                 $fassured, $ncar_type, $dpolicy;
	                           
		    if (SQLCODE==SQLNOTFOUND) break;
		   	
		    fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%s,%s,%s,%s,%s,%s,%s,%s\n",
		                nbranch, ipolicy, nassured, iassured, iengine, 
                        itag, dissue, dply_begin, dply_end, mprem, 
                        iofficer, nofficer, ileader, nleader, dentry, 
                        fassured, ncar_type, dpolicy);
        }
		$CLOSE cur_day_m13;
		fclose(fp);
		$fetch cur_mgr_m13;
	}
	$FREE cur_day_m13;
    $CLOSE cur_mgr_m13;
    $FREE  cur_mgr_m13;
	    
    if (mail_count!=0) {
        rc = car3016_write_email(sopt);
        if (rc!=M_CM_OK) {
		    printf("error on car3016_write_email\n");
			return rc;
		}
    }

    cnt_mgr13 = mail_count;    
     
    return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* -------------------------------------------------------------------------- */

int GetWorkDate(wkdays)
char wkdays[2];
{
    int rc1,x1;
    $int icnt3,icnt2,icnt1,wkday;
    $int ddate1,ddate2;
    $char sdate1[11],sdate2[11],top_unit[11], mleader[11],v_sMsg[150];

    $WHENEVER SQLERROR GOTO errexit;

    icnt1 = atoi(wkdays);
    icnt3 = icnt2 = wkday = 0;
    x1 = 0;
    for(i=1;i<=30;i++)
    {
        icnt3 ++; 
        
        $select count(*) into $icnt2
           from ca_holiday
          where holiday_bgn <= today-$icnt3
            and holiday_end >= today-$icnt3;
            
        if (icnt2 == 0)
        {
            wkday++;
        }
        
        if (wkday ==  icnt1+1)
        {
            $select first 1 today-$icnt3 into $ddate1 from ca_holiday;
            strcpy(sdate1,cm_edate_str(ddate1));
            printf("[%d]�Ӥu�@��e��[%s]\n",icnt1,sdate1);
            if (x1 == 0)
                strcpy(max_date,sdate1);
                
            x1++;
        }
        
        if (wkday ==  icnt1+2)
        {
            $select first 1 today-$icnt3 into $ddate2 from ca_holiday;
            strcpy(sdate2,cm_edate_str(ddate2));
            printf("[%d]�Ӥu�@��e��[%s]\n",icnt1+1,sdate2);
            strcpy(min_date,sdate2);
            break;
        }
    }
    
    printf("\n �� %d �Ӥu�@�ѫe������϶���: %s ~ %s \n", icnt1, min_date,max_date );

    return M_CM_OK;


errexit:

  sprintf( v_sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  return SQLCODE;

}

/* ---------------------------------------------------------------------- */
long car3016_final_email()
{
    $char mmsg[1000],email[51],chinese_name[11],nproject[200],nattachment[1025];
    $int icnt_all;

    $whenever sqlerror goto errexit;

    $select email,chinese_name
       into $email,$chinese_name
       from personal:asempl
      where empl_no = $userid;

    strcpy(email,trim(email));
    strcat(email,"@tmnewa.com.tw");
    
        
    /* mail�D�� */  
    strcpy(nproject,"�O�ͮĤ�w��J���L����ӤιO�ͮĤ�5�B13�u�@�Ѥw��J���L�����_mail�@�~����");   
    
    /* mail���e */
    sprintf(mmsg,"�O�ͮĤ�w��J���L����ӤιO�ͮĤ�5�u�@�ѡB13�u�@�Ѥw��J���L����ӧ妸email�@�~�w���槹��!\n"
     		     "�ԲӸ�ƽжi���I�t��cmn201�d��(car3016)�C</P>\n");
    
    strcpy(mmsg,rtrim(mmsg));
    ctxt.loc_loctype = LOCMEMORY;
    ctxt.loc_buffer = mmsg;
    ctxt.loc_bufsize = 9000;
    ctxt.loc_size =  strlen(mmsg) + 1;


    icnt_all = 0;

    $select count(*) into $icnt_all 
       from batchemail
      where project_id = "CAR3016"
        and mail_date = today
        and receiver_email = $email
        and receiver_name = $chinese_name
        and mail_count = 0
        and nsubject = $nproject;

    if (icnt_all > 0)
    {
        $delete from batchemail
          where project_id = "CAR3016"
            and mail_date = today
            and receiver_email = $email
            and receiver_name = $chinese_name
            and mail_count = 0
            and nsubject = $nproject;
    }
    
    /* 1110322014_SC1_batchemail�ಾ�ܷs���x */
    $INSERT INTO batchemail
		(project_id, mail_date, receiver_email,	receiver_name, cc,
		 content, key, mail_count, nsubject, nattachment)
     VALUES
		("CAR3016", today, $email, $chinese_name, " ",
		 $ctxt, " ", 0, $nproject, " ");


    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* --------------------------------------------------------------------- */
long car3016_print()
{
    int     rc;
    char    sfilename[100],stitle[1024],stmt2[8000];
    $char   stmt[2000], tmp_mark[300],tmp_days[300],sMsg[200];
    $int    icnt1;

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(sfilename,"car3016_�O�ͮĤ�w��J���L�����_Email");
    strcpy(stitle,"�{���N��:CAR3016");


    strcpy(sfilename,"car3016_�w��J���L�����");
    strcpy(stitle,"�{���N��:CAR3016\t");
    strcat(stitle,sfilename);
    strcat(stitle,"\t\t\t\t\t\t\t\t\t\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");
    strcat(sfilename,"[CARCAR3016]");


    strcat(stitle,"\t��������\t�~�Z���\t�O�渹\t�O��W��\t�Ȥ�νs\t������\t����\t�o�Ӧ~��\t�O�I�_��\t�O�I����\t");
    strcat(stitle,"�����O�O\t�g��N��\t�g��W��\t�޲z�H�N��\t�޲z�H�W��\t��J��\t�Ȥ�ʽ�\t�T/����\t");
    strcat(stitle,"ñ���\t�~�Z���N��\t�D�q���N��\t�W�@���D�ޥN��\t�W�@���D�ަW��\t�W�G���D�ޥN��\t�W�G���D�ަW��\n");
    
    $select count(*) into $icnt1  from tb_wk1 where 1=1;
    
    if (icnt1 > 0)
    {
        sprintf(stmt2, 
            "select '�O1��', * from tb_wk1 where 1=1 union all \
             select '�O5��', *, ' ', ' ' from tb_wk5 where 1=1 union all \
             select '�O13��', *, ' ', ' ' from tb_wk13 where 1=1 ");
    }
    
    rc = unload_file(outputf," ",sfilename,stitle,stmt2);
    if (rc != SUCCESS) {
        sprintf(msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }
    
    return M_CM_OK;
errexit:
    sqlfatal();
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}

/* �{�����ըϥ�
runbatch 00 ���s car3016 E 0

*/