/************************************************/
/*           �߮׹w���B��֡B�ЮֹF���v�έp��   */
/* Program : car823.ec                          */
/*                                              */
/* Edit    : 11/04/1999      By Peter Sun       */
/* Note    : �F���v�зǦp�U==>                  */
/*           ���z��ܹw���鬰����               */
/*           ���z��ܪ�֤鬰����               */
/*           ���z����Ю֤鬰������             */
/*                                              */
/* Database: ca_clm_process, officer,           */
/*           sa_branch_type                     */
/************************************************/
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "carmsgs.h"


#include <math.h>
#include "gls_array.h"
#include "gls_const.h"
#include "safeclib.h"

#define SUCCESS                 1
#define FAIL                    0
#define YES                     1
#define NO                      0
#define NEXTPAGE                7
#define FOUND                   sqlca.sqlcode!=SQLNOTFOUND
#define NOT_FOUND               sqlca.sqlcode==SQLNOTFOUND

extern char RPTDIR[];

/****  get data from client  ****/
$char  DBName[5];
char   userid[11];
$char  ibranch[4];
$char  datebgn[11], dateend[11];
$char  outputf[21];

/****  car823_p  ****/
$char  cDatebgn[11], cDateend[11];

$char  path_DataFile[80];

static int pagenum=1;

char   BodyFile[ N_FILE+1];
char   TitleFile[ N_FILE+1];
$int   StartRow,TitleRow;
$int   ItemRow, TotColumn;
$int   PgLine, Width;
$int   iCnt;
int    max_count, errCode;
int    tmp_len;

$char  stmt[1024];
char  MsgCode[50];
$char Dappraisal_c[11],Dclaim_c[11];
$char Dapp_mm[3],Dcla_mm[3];
$char Iadjuster[11];
$int Mapp_loss = 0;
$char nchi_full[15], nbranch[51];
$char iclaim[21];
$char nname[15];
$char Iadjuster_nname[15];
$char dappraisal_c[11],dclaim_c[11];

char sFullName[50];
$char ibranch_in[3];
$int mapp_loss = 0;
int rc;

$struct Rec823 {
   char nchi_abv[6];
   char nchi_full[15];
   char nbranch[51];
   char iofficer[8];
   char nname[10];
   int  claim_total;
   int  appraisal_done;
   int  first_cnt;
   int  first_done;
   int  second_3_total;
   int  second_2_total;
   int  second_3_done;
   int  second_2_done;
} r;

long   msg_code;

long car823_build1();
long car823_build2();
long car823_title1();
long car823_title2();
long car823_body1();
long car823_body2();
int  getWorkCount();

main(argc,argv)
int  argc;
char **argv;
{


   batchinit();

   strcpy(DBName,       isNULLstr(argv[1]));
   strcpy(userid,       isNULLstr(argv[2]));
   strcpy(ibranch,      isNULLstr(argv[3]));  /* ���z��� */
   strcpy(datebgn,      isNULLstr(argv[4]));  /* ���z�_�� */
   strcpy(dateend,      isNULLstr(argv[5]));  /* ���z���� */
   strcpy(outputf,      isNULLstr(argv[6]));

printf(" 0000000000000000000000000000000 \n");

    rc = car823_p();

    if ( rc != M_CM_OK)  {
          EWRITE(userid, rc, " ");
          return rc;
     }


    max_count=0;
     strcpy(MsgCode," ");
     rc = car823_build1();

     if (rc != M_CM_OK)
     {
         if (MsgCode[0]==' ')
             EWRITE(userid, rc, " ");
         else
             EWRITE(userid, rc, MsgCode);
         return rc;
     }


     max_count=0;
     strcpy(MsgCode," ");
     rc = car823_build2();

     if (rc != M_CM_OK)
     {
         if (MsgCode[0]==' ')
             EWRITE(userid, rc, " ");
         else
             EWRITE(userid, rc, MsgCode);
         return rc;
     }

}

long car823_build1()
{
   $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];
   $char  FormTp[3];
   $char  iclaim[CLAIM_NUM], ipolicy[POLICY_NUM_1], daccident[15];
   $long  dclose_ctype, dclose_rtype;
   int    i;

   $WHENEVER SQLERROR GOTO errexit;

   printf("        into   car823        build1 \n");

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width, $FormTp
      FROM Form
     WHERE ksys_grp = "CA" AND kPgmID = 823 AND iform_tp = '1';


printf(" %s %s \n",TitleFmt,BodyFmt);
   strcpy(TitleFmt, rtrim(TitleFmt));
   strcpy(BodyFmt, rtrim(BodyFmt));
   sprintf_s(TitleFile,21, "%sA.ti", outputf);
   sprintf_s(BodyFile,21, "%sA.bd", outputf);


   printf("     11111111111111111111 title \n");
   /* �B�z���Y */
   rgu_init_report(TitleFmt, TitleFile);
   car823_title1();
   rgu_finish_report();

   /* �B�z���� */

  printf("  11111111111111111111111111 body \n");
   rgu_init_report(BodyFmt, BodyFile);

   $DECLARE Acursor1 CURSOR FOR
     SELECT nchi_abv,nchi_full,nbranch,nname,claim_total,appraisal_done,first_cnt,first_done,
            second_3_total,second_2_total,second_3_done,second_2_done
       FROM CAR823_TEMP
      ORDER BY 1,2;

   $OPEN Acursor1;

   for (i=0 ; ; i++)
   {
      $FETCH Acursor1
        INTO $r.nchi_abv,$r.nchi_full,$r.nbranch,$r.nname,
             $r.claim_total,$r.appraisal_done,$r.first_cnt,$r.first_done,
             $r.second_3_total,$r.second_2_total,$r.second_3_done,
             $r.second_2_done;

      if (SQLCODE == SQLNOTFOUND)
      {
         if (i == 0)
         {
            EWRITE(userid, SQLCODE, "�L�X�G���󪺸�� !");
            return 0;
         }
         break;
      }

      car823_body1();
   }
   $CLOSE Acursor1;
   $FREE Acursor1;

   rgu_put_body(2);
   rgu_put_body(3);
   rgu_finish_report();


   /*  create_sign_form("car823",BodyFile, Width); */
     if ((rc=save_form_info(F_BLK1,"CA",823,userid,FormTp,max_count,outputf))<0)
          EWRITE(userid,rc,"save_form_info_failed");


   $DROP TABLE CAR823_TEMP;

   return M_CM_OK;

errexit:
   /* printf("Lai:err,%d",SQLCODE);  */
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return 0;
}

long car823_build2()
{
   $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];
   $char  FormTp[3];

   $long  dclose_ctype, dclose_rtype;
   int    i;
   $int int_count = 0;

   $WHENEVER SQLERROR GOTO errexit;


   printf("        into   car823        build2222222\n");

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width, $FormTp
      FROM Form
     WHERE ksys_grp = "CA" AND kPgmID = 823 AND iform_tp = '2';

   printf(" %s %s %s \n",TitleFmt,BodyFmt,FormTp);

   strcpy(TitleFmt, rtrim(TitleFmt));
   strcpy(BodyFmt, rtrim(BodyFmt));
   sprintf_s(TitleFile,21, "%sB.ti", outputf);
   sprintf_s(BodyFile,21, "%sB.bd", outputf);


   /* �B�z���Y */
   rgu_init_report(TitleFmt, TitleFile);
   car823_title2();
   rgu_finish_report();

   /* �B�z���� */
   rgu_init_report(BodyFmt, BodyFile);


   $select count(*)
      into $int_count
   from CAR823_detail_TEMP;

printf(" int_count[%d]\n",int_count);

printf(" 77777777777777777777777777777777777 \n");

    /* rgu_put_body_string(1, cDatebgn,1);
    rgu_put_body_string(1, cDateend,1);
    rgu_put_body_string(1, cm_get_sysd(), 1);
    rgu_put_body(1); */


   $DECLARE Acursor12 CURSOR FOR
     SELECT nchi_full,nbranch,iclaim,nname,dappraisal_c,
            dclaim_c,mapp_loss
       FROM CAR823_detail_TEMP
      ORDER BY 1,2;

   $OPEN Acursor12;

   for (i=0 ; ; i++)
   {
      $FETCH Acursor12
        INTO $nchi_full,$nbranch,$iclaim,$nname,$dappraisal_c,
             $dclaim_c,$mapp_loss;

      if (SQLCODE == SQLNOTFOUND)
      {  break;
      }

      car823_body2();
   }
   $CLOSE Acursor12;
   $FREE Acursor12;

   rgu_finish_report();

   if ((rc=save_form_info(F_BLK1,"CA",823,userid,FormTp,max_count,outputf))<0)
       EWRITE(userid,rc,"save_form_info_failed");

   $DROP TABLE CAR823_detail_TEMP;

   return M_CM_OK;

errexit:
   /* printf("Lai:err,%d",SQLCODE);  */
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return 0;
}

car823_p()
{
     $char wherestat[50];
     $char IclaimTmp[21] = "";
	 $char Icl_Tmp[21] = ""; /*�h�ŧi�@��Icl_Tmp�ܼơA�b�U���u�w���F���v���ϰ�ϥΡA�T�O�C�ӱ�����䪺Icl_Tmp�����]�w�ȡA�A���h�ϥΡC*/
     $long Dclaim , Dappraisal , Dfirst , Dsecond;
     $char Frule[2] , Adjustment[11];
     $char Nname[12], Ibranch_1[3], Nchi_full[15], nbranch[51];
     $char Nchi_abv[6], LHsDsettle[5];
     $int  Claim_total , App_done , First_done, First_cnt;
     $int  Second_3 , Second_2 , Second_3_done , Second_2_done;
     $int  X1, X2, X3, X4;
     long  A1, A2, A3, A4, A5;
     long  t , check_t;

     Dclaim = Dappraisal = Dfirst = Dsecond = 0;
     Claim_total = App_done = First_done = First_cnt = 0;
     Second_3 = Second_2 = Second_3_done = Second_2_done = 0;
     X1 = X2 = X3 = X4 = 0;
     A1 = A2 = A3 = A4 = A5 = 0;

   $WHENEVER SQLERROR goto errexit;

     if(db_select(DBName) == False)
   {
       EWRITE(userid,M_CM_DB_NOTOPEN,"M_CM_DB_NOTOPEN");
       return FAIL;
   }

   $CREATE TEMP TABLE CAR823_TEMP
   (
        nchi_abv         char(6),
        nchi_full        char(14),
        nbranch          char(50),
        iofficer         char(8),
        nname            char(10),
        claim_total      integer DEFAULT 0,
        appraisal_done   integer DEFAULT 0,
        first_cnt        integer DEFAULT 0,
        first_done       integer DEFAULT 0,
        second_3_total   integer DEFAULT 0,
        second_2_total   integer DEFAULT 0,
        second_3_done    integer DEFAULT 0,
        second_2_done    integer DEFAULT 0
   )WITH NO LOG;


    $CREATE TEMP TABLE CAR823_detail_TEMP
   (
        nchi_full        char(14),
        nbranch          char(50),
        iclaim           char(21),
        nname            char(10),
        dappraisal_c       char(11),
        dclaim_c         char(11),
        mapp_loss        integer default 0

   )WITH NO LOG;


     /*** �߮ר��z����B�z ***/
     if (datebgn[0] == '*') strcpy(datebgn, "88/01/01");
     if (dateend[0] == '*') strcpy(dateend, "99/12/31");
     if (dateend[0] == ' ') strcpy(dateend, datebgn);

     strcpy(cDatebgn, cm_to_infdate(datebgn));
     strcpy(cDateend, cm_to_infdate(dateend));

     /*** �B�z ibranch (�H���z��쬰��h) ***/
     if (strcmp(trim(ibranch),"A") == 0)      /*** �_�� ***/
     {
         wherestat[0] == '\0';
         strcpy(wherestat,"AND c.iupbranch = '00'");
     }
     else if (strcmp(trim(ibranch),"B") == 0) /*** ���� ***/
     {
         wherestat[0] == '\0';
         strcpy(wherestat,"AND c.iupbranch = '40'");
     }
     else if (strcmp(trim(ibranch),"C") == 0) /*** �n�� ***/
     {
         wherestat[0] == '\0';
         strcpy(wherestat,"AND c.iupbranch = '70'");
     }
     else if (strcmp(trim(ibranch),"*") == 0) /*** ���� ***/
     {
         wherestat[0] == '\0';
         strcpy(wherestat,"AND c.ibranch matches '*'");
     }
     else  /*** ��J����@��� ***/
     {
         wherestat[0] == '\0';
         sprintf_s(wherestat,50,"AND c.ibranch = '%s'",ibranch);
     }

/*     printf("**[car823_p]:ibranch[%s],wherestat[%s]\n",ibranch,wherestat);   */

   sprintf_s(stmt,1024," SELECT a.empl_no,(SELECT nname FROM officer WHERE iofficer = a.empl_no), \
                         a.iapp_unit,c.nchi_full,c.nchi_abv, \
                         (select f.nbranch from officer e, sa_branch_type f \
                           where e.iquota = f.ibranch and e.iofficer = b.adjustment) as nbranch \
                    FROM cm_clm_adjuster a , ca_clm_process b, branch c \
                   WHERE a.empl_no = b.adjustment \
                     AND a.iapp_unit = c.ibranch %s \
                   GROUP BY 1,2,3,4,5,6 \
                   ORDER BY a.empl_no",wherestat);
     $PREPARE cur_tmp FROM $stmt;
     $DECLARE cur1 CURSOR FOR cur_tmp;
     $OPEN cur1;
     while(1)
     {
          $FETCH cur1 INTO $Adjustment , $Nname , $Ibranch_1 , $Nchi_full ,$Nchi_abv, $nbranch;

          if (SQLCODE == SQLNOTFOUND) break;

          /***** �d�߱�����������z���߮ץ� *****/
          $DECLARE clm_sel CURSOR FOR
            SELECT iclaim, dclaim, date(dfirst), date(dsecond), frule, dsettle,ibranch_in
              FROM ca_clm_process
             WHERE adjustment = $Adjustment
               AND dclaim BETWEEN $cDatebgn AND $cDateend
             ORDER BY 1;

          $OPEN clm_sel;
          while(1)
          {
                 $FETCH clm_sel INTO $IclaimTmp , $Dclaim , $Dfirst:X2 , $Dsecond:X3 , $Frule, $LHsDsettle:X4,$ibranch_in;
                 if((SQLCODE == SQLNOTFOUND) && (Claim_total == 0)) break;
                 printf("iclaim[%s], dclaim[%ld], dfirst[%ld], dsecond[%ld], LHsDsettle[%s]\n",IclaimTmp,Dclaim,Dfirst,Dsecond,LHsDsettle);
                 printf("X2[%d],X3[%d],X4[%d]\n",X2,X3,X4);
                 if((SQLCODE == SQLNOTFOUND) && (Claim_total > 0))
                 {
                     $INSERT INTO CAR823_TEMP
                     (nchi_abv, nchi_full, nbranch, nname,  iofficer ,   claim_total,  appraisal_done, first_cnt, first_done,
                      second_3_total, second_2_total, second_3_done,  second_2_done)
                     VALUES
                     ($Nchi_abv,$Nchi_full, $nbranch, $Nname, $Adjustment, $Claim_total, $App_done, $First_cnt, $First_done,
                      $Second_3     , $Second_2 ,     $Second_3_done, $Second_2_done);

                     Claim_total = App_done = First_done = First_cnt = 0;
                     Second_3 = Second_2 = Second_3_done = Second_2_done = 0;
                     A1 = A2 = A3 = A4 = A5 = 0;
                     break;
                 }

                 Claim_total ++;

                 if (IclaimTmp[5]=='C')
                 {
                     sprintf_s(stmt,1024,
                      " SELECT MIN(dappraisal) \
                          FROM %s:ca_app_victim_hist \
                         WHERE iclaim = ? ", get_full_dbname(ibranch_in));
                 }
                 else
                 {
                     sprintf_s(stmt,1024,
                      " SELECT MIN(dappraisal) \
                          FROM %s:app_ins_type_hist \
                         WHERE iclaim = ? ", get_full_dbname(ibranch_in));
                 }
                 $PREPARE pr1 FROM $stmt;
                 $EXECUTE pr1
                     INTO $Dappraisal:X1
                    USING $IclaimTmp;

/*                 printf("[car823]:Claim_total[%d]\n",Claim_total);*/
/*                 printf("iclaim[%s],dclaim[%ld],dappraisal[%ld],dfirst[%ld],dsecond[%ld],frule[%s],adjustment[%s] \n",
                         IclaimTmp , Dclaim , Dappraisal , Dfirst , Dsecond , Frule , Adjustment);  */

         /****** �w���F�� = (�w������Ш��z���) �����b���餧���~��F�� ******/

                   strcpy(Dclaim_c,cm_cdate_str_100(Dclaim));

                 if (X1 != -1)   /**** ���w����� ****/
                 {
                     strcpy(Dappraisal_c,cm_cdate_str_100(Dappraisal));
                     strcpy(Dapp_mm,substring(Dappraisal_c,4,2));
                     strcpy(Dclaim_c,cm_cdate_str_100(Dclaim));
                     strcpy(Dcla_mm,substring(Dclaim_c,4,2));
                     strcpy(IclaimTmp,trim(IclaimTmp));
					 
					 /*��IclaimTmp���ȵ�Icl_Tmp�A�T�OIcl_Tmp���ȡA�A���h�ϥΡC �ѨMUse_of_Uninitialized__Variable���I���D*/
					strcpy(Icl_Tmp,IclaimTmp);  
					
/*                   printf(" Dclaim[%ld]\n",Dclaim); */
/*                   printf(" Iclaim[%s]\n",Icl_Tmp);
                     printf(" Dappraisal_c[%s]\n",Dappraisal_c);
                     printf(" Dclaim_c[%s]\n",Dclaim_c);
                     printf(" Dapp_mm[%s]\n",Dapp_mm);
                     printf(" Dcla_mm[%s]\n",Dcla_mm);   */


                     /*  A1 = labs(Dappraisal-Dclaim);   */
                     A1 = getWorkCount(Dappraisal, Dclaim);
/*                   printf("Dappraisal - Dclaim = [%ld]\n",A1); */
                     if ((A1 <= 5) && (strcmp(Dapp_mm,Dcla_mm)==0))
                     {
                         App_done ++;
/*                         printf("App_done[%d]\n",App_done);*/

                     }
                     else
                     {
                        printf("  6666666666666666666666666666 \n");

                        strcpy(sFullName,get_full_dbname(ibranch_in));

                        sprintf_s(stmt,1024, "SELECT mapp_loss \
                                         FROM %s:appraisal \
                                        WHERE  iclaim = ? ",sFullName);

                         $PREPARE sg_1 FROM $stmt;
                         $DECLARE sg_A_cursor CURSOR FOR sg_1;
                         $OPEN sg_A_cursor USING $Icl_Tmp;
                         $FETCH sg_A_cursor INTO $Mapp_loss;

                         $INSERT INTO CAR823_detail_TEMP
                          (nchi_full, nbranch, iclaim,nname,
                           dappraisal_c,dclaim_c,mapp_loss)
                          VALUES
                          ($Nchi_full, $nbranch, $Icl_Tmp,$Nname,
                           $Dappraisal_c,$Dclaim_c,$Mapp_loss);
                     }
                 }
                 else
                 {
						strcpy(IclaimTmp,trim(IclaimTmp));
						/*��IclaimTmp���ȵ�Icl_Tmp�A�T�OIcl_Tmp���ȡA�A���h�ϥΡC �ѨMUse_of_Uninitialized__Variable���I���D*/
						strcpy(Icl_Tmp,IclaimTmp);
						
                         $INSERT INTO CAR823_detail_TEMP
                          (nchi_full, nbranch, iclaim,nname,
                           dappraisal_c,dclaim_c,mapp_loss)
                          VALUES
                          ($Nchi_full, $nbranch, $Icl_Tmp,$Nname,
                           ' ',$Dclaim_c,0);
                 }


         /****** �i��֥��  Daniel 20010208  ******/

         /**** �L��֤���B�L�z���h�����, �L��֤���B���z���h�������  (�K���)   ****/

                 if(X2 == -1 && X4 == -1) /**** �L��֤���B�L�z���   ****/
                 {
                      if (sChkFirst(IclaimTmp) == 0)   /*  0 ����֤~��  */
                         First_cnt ++;
                 }

                 if (X2 != -1)   /**** ����֤�� ****/
                 {
                         First_cnt ++;

         /****** ��ֹF�� = (��֤���Ш��z���) �����b�C�餧���~��F�� ******/

                     /*   A2 = labs(Dfirst-Dclaim);    */
                     A2 = getWorkCount(Dfirst, Dclaim);
/*                   printf("Dfirst - Dclaim = [%ld]\n",A2); */
                     if (A2 <= 7)
                         First_done ++;
/*                   printf("First_done[%d]\n",First_done); */
                 }

        /**** ���w�ЮֹF�� = (�Ю֤���Ш��z���) �����b�Q�|�餧���~��F�� ****/

                 t = cm_today();
                 if (Frule[0] == '2')
                 {
        /*** (�{���������Ш��z��)�����j��Q�|��~������Ю֥�� ***/

                        check_t = labs(t-Dclaim);

                     if ((X3 != -1) && (check_t > 14))
                     {
                         Second_2 ++;
                         /* A3 = labs(Dsecond-Dclaim);    */
                         A3 = getWorkCount(Dsecond, Dclaim);
                         printf("Dsecond - Dclaim = [%ld]\n",A3);
                         if (A3 <= 14)
                             Second_2_done ++;
                         printf("Second_2_done[%d]\n",Second_2_done);
                     }
                     else if ((X3 != -1) && (check_t <= 14))
                     {
                         Second_2 ++;
                         /* A3 = labs(Dsecond-Dclaim);    */
                         A3 = getWorkCount(Dsecond, Dclaim);
                         printf("Dsecond - Dclaim = [%ld]\n",A3);
                         if (A3 <= 14)
                             Second_2_done ++;
                         printf("Second_2_done[%d]\n",Second_2_done);
                     }
                     else if ((X3 == -1) && (check_t > 14))
                     {
                         Second_2 ++;
                     }
                     else if ((X3 == -1) && (check_t <= 14))
                     {
                         printf("���F���p�Ƽз�\n");
                     }
                 }

        /**** �۵M�ЮֹF�� = (�Ю֤���Ш��z���) �����b�Q�|�餧���~��F�� ****/

                 t = cm_today();
                 if (Frule[0] == '3')
                 {
               /*** (�{���������Ш��z��)�����j��Q�|��~������Ю֥�� ***/

                     check_t = labs(t-Dclaim);

                     if ((X3 != -1) && (check_t > 14))
                     {
                         Second_3 ++;
                         /*   A4 = labs(Dsecond-Dclaim);   */
                         A4 = getWorkCount(Dsecond, Dclaim);
                         printf("Dsecond - Dclaim = [%ld]\n",A4);
                         if (A4 <= 14)
                             Second_3_done ++;
                         printf("Second_3_done[%d]\n",Second_3_done);
                     }
                     else if ((X3 != -1) && (check_t <= 14))
                     {
                         Second_3 ++;
                         /*  A4 = labs(Dsecond-Dclaim);    */
                         A4 = getWorkCount(Dsecond, Dclaim);
                         printf("Dsecond - Dclaim = [%ld]\n",A4);
                         if (A4 <= 14)
                             Second_3_done ++;
                         printf("Second_3_done[%d]\n",Second_3_done);
                     }
                     else if ((X3 == -1) && (check_t > 14))
                     {
                         Second_3 ++;
                     }
                     else if ((X3 == -1) && (check_t <= 14))
                     {
                         printf("���F���p�Ƽз�\n");
                     }
                 }
          }
          $CLOSE clm_sel;
          $FREE  clm_sel;
     }
     $CLOSE cur1;
     $FREE  cur1;

     return M_CM_OK;

errexit:
  if (SQLCODE != 0) msg_code = SQLCODE;
  printf("car823_p():SQLCODE=[%ld], sqlerrm=[%s]\n",msg_code, sqlca.sqlerrm);
  return SQLCODE;
}

long car823_title1()
{
   char currdate[20];
   char yy[4], mm[3], dd[3];
   char yy1[4], mm1[3], dd1[3];

   /*** get current_date ***/
   strcpy(currdate,cm_sysd_cdate(cm_get_sysd()));
   cm_split_ymd_100(currdate, yy, mm, dd);

   rgu_put_head_string(1, yy);
   rgu_put_head_string(1, mm);
   rgu_put_head_string(1, dd);

   /*** �߮ר��z�϶� ***/
   cm_split_ymd_100(datebgn, yy1, mm1, dd1);
   rgu_put_head_string(1, yy1);
   rgu_put_head_string(1, mm1);
   rgu_put_head_string(1, dd1);
   cm_split_ymd_100(dateend, yy1, mm1, dd1);
   rgu_put_head_string(1, yy1);
   rgu_put_head_string(1, mm1);
   rgu_put_head_string(1, dd1);

   rgu_put_head();
}

long car823_title2()
{
   char currdate[20];
   char yy[4], mm[3], dd[3];
   char yy1[4], mm1[3], dd1[3];

   /*** get current_date ***/
   strcpy(currdate,cm_sysd_cdate(cm_get_sysd()));
   cm_split_ymd_100(currdate, yy, mm, dd);

   rgu_put_head_string(1, yy);
   rgu_put_head_string(1, mm);
   rgu_put_head_string(1, dd);

   /*** �߮ר��z�϶� ***/
   cm_split_ymd_100(datebgn, yy1, mm1, dd1);
   rgu_put_head_string(1, yy1);
   rgu_put_head_string(1, mm1);
   rgu_put_head_string(1, dd1);
   cm_split_ymd_100(dateend, yy1, mm1, dd1);
   rgu_put_head_string(1, yy1);
   rgu_put_head_string(1, mm1);
   rgu_put_head_string(1, dd1);

   rgu_put_head();

}

long car823_body1()
{
   char buf1[16];


printf(" intot car823  body1 \n");
   rgu_put_body_string(1, r.nchi_abv, LEFT);          /*** �����Ұ� ***/
   rgu_put_body_string(1, r.nbranch, LEFT);           /*** ��� ***/
   rgu_put_body_string(1, r.nchi_full, LEFT);         /*** �Ҧb�a ***/
   rgu_put_body_string(1, r.nname, LEFT);             /*** �z�ߤH�� ***/

   rfmtlong(r.claim_total, "#,##&", buf1);
   rgu_put_body_string(1, buf1, LEFT);                /*** ���ץ�� ***/

   rfmtlong(r.appraisal_done, "#,##&", buf1);
   rgu_put_body_string(1, buf1, LEFT);                /*** �w���F����� ***/

   rfmtlong(r.first_cnt, "#,##&", buf1);
   rgu_put_body_string(1, buf1, LEFT);                /*** ����֥�� ***/

   rfmtlong(r.first_done, "#,##&", buf1);
   rgu_put_body_string(1, buf1, LEFT);                /*** ��ֹF����� ***/

   rfmtlong(r.second_3_total, "#,##&", buf1);
   rgu_put_body_string(1, buf1, LEFT);                /*** �۵M���Ю֥�� ***/

   rfmtlong(r.second_2_total, "#,##&", buf1);
   rgu_put_body_string(1, buf1, LEFT);                /*** ���w���Ю֥�� ***/

   rfmtlong(r.second_3_done, "#,##&", buf1);
   rgu_put_body_string(1, buf1, LEFT);                /*** �۵M�F����� ***/

   rfmtlong(r.second_2_done, "#,##&", buf1);
   rgu_put_body_string(1, buf1, LEFT);                /*** ���w�F����� ***/

   rgu_put_body(1);
   max_count++;

   return M_CM_OK;
}

long car823_body2()
{
   char buf1[16];


   rgu_put_body_string(2, nbranch, LEFT);           /*** ���***/
   rgu_put_body_string(2, nchi_full, LEFT);         /*** �Ҧb�a ***/
   rgu_put_body_string(2, nname, LEFT);             /*** �z�߭� ***/
   rgu_put_body_string(2, iclaim, LEFT);             /*** �׸� ***/
   rgu_put_body_string(2, dclaim_c, LEFT);             /*** ���z�� ***/
   rgu_put_body_string(2, dappraisal_c, LEFT);             /*** �w���� ***/

   rfmtlong(mapp_loss, ",###,###,##&", buf1);
   rgu_put_body_string(2, buf1, LEFT);                /*** �ߴڪ��B ***/

   rgu_put_body(2);
   max_count++;
   return M_CM_OK;

}

int getWorkCount(ldate1, ldate2)
{
$char stmt[2048];
$long ltmp1;
$long ltmp2;
$int  icnt;

   printf("ldate1[%ld], ldate2[%ld]\n",ldate1, ldate2);

   $WHENEVER ERROR goto errexit;
   $SET LOCK MODE TO WAIT;

   if (ldate1 <= ldate2)
   {
      ltmp1 = ldate1;
      ltmp2 = ldate2;
   }
   else
   {
      ltmp1 = ldate2;
      ltmp2 = ldate1;
   }

   icnt = 0;
   strcpy(stmt,
   " select count(*)      "
   "   from cm_wrktbl     "
   "  where dwork >  ?    "
   "    and dwork <= ?    "
   "    and fwork  = 0    ");

   printf("stmt[%s]\n",stmt);

   $prepare getWk1 from $stmt;
   $execute getWk1
       into $icnt
      using $ltmp1, $ltmp2;

   printf("icnt[%d]\n",icnt);

   return icnt;

errexit:
  printf("SQL=[%d], sqlca.sqlerrm[%s]\n", SQLCODE, sqlca.sqlerrm);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  exit(1);
}

int sChkFirst(sFiclaim)
$char sFiclaim[21];
{
$char stmt[2048],branch[3];
$char adjustment[11];
$int  iCnt,DYY,DMM,TYY,TMM;
$long lMins_app;
int   rc;


   $WHENEVER SQLERROR GOTO errexit;

   printf("INTO sChkFirst\n");

   rc = FALSE;

   sprintf_s(stmt,1024,
    " SELECT ibranch_in,adjustment   \
        FROM ca_clm_process          \
       WHERE iclaim = ? ");
    $PREPARE fid01 FROM $stmt;
    $EXECUTE fid01
        INTO $branch,$adjustment
       USING $sFiclaim;
    if (SQLCODE == SQLNOTFOUND) return rc ;

   sprintf_s(stmt,1024,
    " SELECT count(*)         \
        FROM %s:app_ins_type  \
       WHERE iclaim = ?       \
         AND iins_type IN (select icode from cu_code_data where itype = 'CT') ",get_full_dbname(branch));
    $PREPARE fid02 FROM $stmt;
    $EXECUTE fid02
        INTO $iCnt
       USING $sFiclaim;
    if (iCnt > 0)
    {          /*  ���O���l�I    */
        iCnt = 0;
      sprintf_s(stmt,1024,
       " SELECT count(*),sum(mins_app)    \
           FROM %s:app_ins_type           \
          WHERE iclaim = ?  ",get_full_dbname(branch));
       $PREPARE fid03 FROM $stmt;
       $EXECUTE fid03
           INTO $iCnt,$lMins_app
          USING $sFiclaim;
       if ((iCnt == 1) && (lMins_app <= 20000))
       {      /*   �u�O���l�I�B�w���B�p�󵥩�20000    */

            sprintf_s(stmt,1024,
             " SELECT YEAR(dcreate),MONTH(dcreate)  \
                 FROM officer                       \
                WHERE iofficer = ?  ");
             $PREPARE fid05 FROM $stmt;
             $EXECUTE fid05 INTO $DYY,$DMM USING $adjustment;
              if (SQLCODE == SQLNOTFOUND) return rc;

            sprintf_s(stmt,1024,
             " SELECT YEAR(DATE(dclaim)),MONTH(DATE(dclaim))   \
                 FROM %s:appraisal                             \
                WHERE iclaim = ? ",get_full_dbname(branch));
             $PREPARE fid06 FROM $stmt;
             $EXECUTE fid06 INTO $TYY,$TMM USING $sFiclaim;
              if (SQLCODE == SQLNOTFOUND) return rc;

              if ( ((TYY - DYY) * 12 + (TMM - DMM))  > 6)
                   rc = TRUE;
       }
    }

    return rc;

errexit:
printf("SQLCODE[%s]\n",SQLCODE);
return FALSE;
}

