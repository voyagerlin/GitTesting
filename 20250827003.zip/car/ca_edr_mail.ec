/**********************************************************************/
/*                                                                    */
/*   program id   : ca_edr_mail.ec                                    */
/*   program name : �H�Υd����P�q��                                  */
/*   date written : 2006/10/11                                        */
/*   date modify  : yyyy/mm/dd                                        */
/*   author       : Jessie                                            */
/*   files        : edr_relation        i                             */
/*                  ao_io_credit        i                             */
/*                  batchemail          o                             */
/**********************************************************************/
#include <stdio.h>
#include <string.h>
#include <time.h>
$include sqlca;
#include "sql.h"
#include "sqlfatal.h"
#include "commsgs.h"
#include "safeclib.h"

/*--------------------------------------------------------------------*/
time_t   current_time;

$char    ipolicy[21],icard[21],dpolicy[11];
$char    nassured[21],nofficer[11],nleader[11];
$long    mprem=0;
int      edr_cnt;

$char    mbuf[9000];
$loc_t   ctxt;
$char    mmsg[1024];
$char    tbuf[128];

char     DBName[5];
/*--------------------------------------------------------------------*/
ca_edr_mail(db,dproc1)
char *db,*dproc1;
{
int      rc;

   strcpy(DBName,db);
   strcpy(dpolicy,dproc1);
   current_time=time(NULL);

   rc = read_cancel_data();
   if (rc != M_CM_OK)
      return rc;

   if (edr_cnt > 0) {
      rc = insert_batchemail();
      if (rc != M_CM_OK)
         return rc;
   }

   return M_CM_OK;
}
/*--------------------------------------------------------------------*/
long read_cancel_data()
{
$char    iply1[21],iply2[21];
int      rc;
$int     ao_cnt=0;

   $whenever sqlerror goto errexit;

   if (db_select(DBName) == 0) {
        printf("M_CM_DB_NOTOPEN");
        return M_CM_DB_NOTOPEN;
   }
   mmsg[0]='\0';
   sprintf_s(mmsg, sizeof mmsg,
          "���q���z�H�U�O��w���P�A�����H�Υd���O��ơA\n"
          "�Ьd���O�_�ݾP�f�h�^�H�Υd���d�H�C</P>\n"
          "<table border='1'>\n"
          "<tr><td>�O�d���X</td><td>�O�渹�X</td><td>�O��W��</td>"
          "<td>���B</td><td>�g��H</td><td>�޲z�H</td><td>���P��</td></tr>\n");

   strcpy(mbuf,mmsg);

   edr_cnt=0;
   $declare cur_edr cursor for
     select a.ipolicy,a.icard,nassured[1,20],medrdmg_prem+medrlia_prem,
            (select nname from officer where iofficer = a.iofficer),
            (select nname from officer where iofficer = a.ileader )
       into $ipolicy,$icard,$nassured,$mprem,$nofficer,$nleader
       from edr_relation a,endorsement b
      where dendorse = $dpolicy
        and fedr_class  = '1'
        and a.iendorse = b.iendorse;
   $open    cur_edr;

   while(1) {
      $fetch cur_edr;
      if (SQLCODE == SQLNOTFOUND) break;

      rc = split_policy(ipolicy,iply1,iply2);

      $select count(*)
       into $ao_cnt
       from ao_io_credit
      where ipolicy1 = $iply1
        and ipolicy2 = $iply2;

      if (ao_cnt==0) {
          $select count(*)
           into $ao_cnt
           from ao_io_credit
          where icard = $icard;
      }

      if (ao_cnt > 0) {
          printf("ao_cnt[%d]\n",ao_cnt);
          edr_cnt++;       
          sprintf_s(tbuf, sizeof tbuf,
                 "<tr><td>%s</td><td>%s</td><td>%s</td><td>%d</td>"
                 "<td>%s</td><td>%s</td><td>%s</td></tr>\n",
                 icard,ipolicy,nassured,mprem,nofficer,nleader,dpolicy);
          strcat(mbuf,tbuf);
      }
   }
   $close cur_edr;
   $free  cur_edr;

   strcat(mbuf,"</table>\n");

   return M_CM_OK;

errexit:
   sqlfatal();
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long insert_batchemail()
{
$char  chiname[41],engname[41];

   $whenever sqlerror goto errexit;

   ctxt.loc_loctype = LOCMEMORY;
   ctxt.loc_buffer  = mbuf;
   ctxt.loc_bufsize = 9000;
   ctxt.loc_size    =  strlen(mbuf) + 1;

   /* $begin work; */

   $declare cur_mail cursor for 
     select chiname,engname
       into $chiname,$engname
       from car_code
      where kind = '21'
        and detail > '00';
   $open    cur_mail;

   while(1) {
       $fetch cur_mail;
       if (SQLCODE==SQLNOTFOUND) break;

       $insert into batchemail
        (project_id,mail_date,receiver_email,receiver_name,cc,
         content,key,mail_count)
        values
        ('car5082',today+1,$engname,$chiname,' ',$ctxt,'Y',1);

   }
   $close cur_mail;
   $free  cur_mail;
   
   /* $commit work; */
   return M_CM_OK;

errexit:
   sqlfatal();
   /* $rollback work; */
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
