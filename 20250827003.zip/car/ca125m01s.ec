/************************************************/
/*                                              */
/*   PROGRAM : _RRxxxx.ec			*/
/*                                              */
/************************************************/
     
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;
#include "safeclib.h"


long car125(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car125_insert(),car125_single_query(),car125_multiple_query(),car125_update_exec();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 
 switch(option)
 {
  case 'A':
	   rtncode=car125_insert(reply);
	   break;
  case 'Q':
	   rtncode=car125_single_query(reply);
	   break;
  case 'M':
           rtncode=car125_multiple_query(reply);
	   break;
  case 'R':
           rtncode=car125_drate_query(reply);
	   break;
  case 'I':
           rtncode=car125_drate_insert(reply);
	   break;	   
  case 'D':
  case 'U':
	   rtncode=car125_update_exec(reply,command,com_len);
	   break;
  default :
	   if(exitsub(reply,M_CM_WRONG_OPTION) == True)
	    return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}

long car125_insert(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 $char fdmg_brg[2],irate[3],ipro_year[5],drate[11];
 $double pfactor; 

 /* standard defined data */
 int tmp_len;
 long MsgCode;
   DBinfo *list;
   int i, j, is_add_fail=0, api_f;
   $char stmt_buf[300];
 /* end of standard data */


 cm_buf_get("%s",DBName);
 cm_buf_get("%s %s %s %e %s\n",fdmg_brg,irate,ipro_year,&pfactor,drate);

  
 $WHENEVER SQLERROR GOTO errexit;
 
 if (db_select(DBName) == False) 
  {
   
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }
 
 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
  {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
  }

 $BEGIN WORK;
 for(j=0;j<i;j++)
 {
    
  sprintf_s(stmt_buf, sizeof stmt_buf, "INSERT INTO %s:car_model_factor "
                   " (fdmg_brg,irate, ipro_year,pfactor,drate) "
                   " VALUES (?,?,?,?,?)" ,list[j].dbname);
   
  $PREPARE a_id FROM $stmt_buf;
  if(SQLCODE != 0)
   {
    is_add_fail = 1;
    break;
   }
   
  $EXECUTE a_id USING $fdmg_brg,$irate,$ipro_year,$pfactor,$drate;
  if(SQLCODE != 0)
   {
     is_add_fail = 1;
    break;
   }
   cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);
  tmp_len = cm_buf_len(ReplyBuf);
  if( j == i-1 )
     api_f = api_OKComplete;
  else
     api_f = api_OK;

  if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
    {
      is_add_fail = 2;
     break;
    }  
#ifdef DEBUG 
printf("INSERT %d\n", j+1);
#endif
 } /* for loop */

printf("is_add_fail = %d\n", is_add_fail);
 if( is_add_fail == 1 ) goto errexit;

 if( is_add_fail == 2 ) 
  {
   $ROLLBACK WORK;
   return apiRC;
  }

 
 $WHENEVER SQLERROR GOTO errexit;
 $COMMIT WORK;
 return api_OKComplete;

 errexit:
  $WHENEVER SQLERROR CONTINUE;
   printf("in errexit: is_add_fail = %d, SQLCODE = %d\n", is_add_fail, SQLCODE);
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True) 
   return MsgCode;
  else  
   return apiRC;
}

long car125_drate_query(reply)
serverReply reply;
{

 $char DBName[5];
 $char drate[11];  
 int tmp_len;

 cm_buf_get("%s",DBName);
 
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False) 
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

 $SELECT max(drate) 
  INTO $drate
  FROM car_model_factor;

 if(SQLCODE==SQLNOTFOUND) 
  {
   if(exitsub(reply,M_CA_NCAR_MODEL_FACTOR) == True) 
    return M_CA_NCAR_MODEL_FACTOR; 
   else  
    return apiRC;
  }
 
 
 
 cm_buf_init(ReplyBuf); 
 cm_buf_put("%l",M_CM_OK);
 cm_buf_put("%s",cm_from_infdate_100(drate));
 tmp_len = cm_buf_len(ReplyBuf);
 
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
  return apiRC;
 else
  return api_OKComplete;

 errexit:
  if(exitsub(reply,SQLCODE) == True) 
   return SQLCODE;
  else  
   return apiRC;
   
}

long car125_single_query(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 $char fdmg_brg[2],irate[3],ipro_year[5],drate[11];  
 $double pfactor = 0.0;
 char    tmp_pfactor[20];

 /* standard defined data */
 int tmp_len;
 /* end of standard data */

 /* self defined data */
 /* end of self data */
 cm_buf_get("%s",DBName);
 cm_buf_get("%s",fdmg_brg);
 cm_buf_get("%s",irate);
 cm_buf_get("%s",ipro_year);
 cm_buf_get("%s",drate); 
 
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False) 
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

 $SELECT pfactor 
  INTO $pfactor
  FROM car_model_factor 
  WHERE fdmg_brg=$fdmg_brg 
    AND irate=$irate 
    AND ipro_year=$ipro_year 
    AND drate=$drate; 

 if(SQLCODE==SQLNOTFOUND) 
  {
   if(exitsub(reply,M_CA_NCAR_MODEL_FACTOR) == True) 
    return M_CA_NCAR_MODEL_FACTOR; 
   else  
    return apiRC;
  }

  sprintf_s(tmp_pfactor, sizeof tmp_pfactor, "%.4f",pfactor);


 cm_buf_init(ReplyBuf); 
 cm_buf_put("%l",M_CM_OK);
 cm_buf_put("%s %s %s %s %s",fdmg_brg,irate,ipro_year,tmp_pfactor,drate);
 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
  return apiRC;
 else
  return api_OKComplete;

 errexit:
  if(exitsub(reply,SQLCODE) == True) 
   return SQLCODE;
  else  
   return apiRC;
}

long car125_multiple_query(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table _RR */
 $char fdmg_brg[2],irate[3],ipro_year[5],drate[11];
 $char drate_bgn[11],drate_end[11];
 $double pfactor = 0.0; 
 char    tmp_pfactor[10];
 /* end of _RR */

 /* standard defined data */
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0; 
 /* end of standard data */

 /* self defined data */
 /* end of self data */

 cm_buf_get("%s",DBName);
 cm_buf_get("%s",fdmg_brg); 
 cm_buf_get("%s",irate);
 cm_buf_get("%s",ipro_year);
 cm_buf_get("%s",drate);
 if (drate[0]=='*'){
    strcpy(drate_bgn,"01/01/1910");
    strcpy(drate_end,"12/31/2200");
 } 
 else{
    strcpy(drate_bgn,drate);
    strcpy(drate_end,drate);
 }
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False) 
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

 $DECLARE q_cur CURSOR FOR
    SELECT fdmg_brg,irate,ipro_year,pfactor,drate 
    INTO  $fdmg_brg,$irate,$ipro_year,$pfactor,$drate
    FROM car_model_factor 
    WHERE fdmg_brg MATCHES $fdmg_brg 
    AND irate MATCHES $irate 
    AND ipro_year MATCHES $ipro_year 
    AND drate BETWEEN $drate_bgn AND $drate_end
    ORDER BY fdmg_brg; 

 $OPEN q_cur;

 for(;;)
  {
    $FETCH q_cur;
    if (SQLCODE != 0) break;

    cm_buf_init(tmpbuf); 
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();          
     }
    
     sprintf_s(tmp_pfactor, sizeof tmp_pfactor, "%.4f",pfactor);

    cm_buf_put("%s %s %s %s %s",fdmg_brg,irate,ipro_year,tmp_pfactor,drate);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */ 
     { 
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
	$CLOSE q_cur;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
	 cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE; 
        }
	ReplyBuf[0] = '\0';
	count = 0;
	cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
            
        sprintf_s(tmp_pfactor, sizeof tmp_pfactor, "%.4f",pfactor);

        cm_buf_put("%s %s %s %s %s",fdmg_brg,irate,ipro_year,tmp_pfactor,drate);
	repbuf_len = cm_buf_len(ReplyBuf);
	count++;
       }
     } 
  } /* for loop */

 $CLOSE q_cur;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
   if(exitsub(reply,M_CA_NCAR_MODEL_FACTOR) == True) 
    return M_CA_NCAR_MODEL_FACTOR;
   else  
    return apiRC;
  } 

 errexit:
  if(exitsub(reply,SQLCODE) == True) 
   return SQLCODE;
  else  
   return apiRC;
}


long car125_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table _RR */
 $char fdmg_brg[2],irate[3],ipro_year[5],drate[11];
 $double pfactor = 0.0;
 char    tmp_pfactor[10];
 $double old_pfactor;
 $char old_fdmg_brg[2],old_irate[3],old_ipro_year[5],old_drate[11];  
 /* end of _RR */

 /* standard defined data */
 char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
 int tmp_len,raw_len;
 long dummy;
   DBinfo *list;
   int i, j, is_del_fail=0, is_upd_fail=0;
   $char stmt_buf[300];
 /* end of standard data */

 /* self defined data */
 long MsgCode;
 /* end of self data */

 comm = (char *) command;
 cm_buf_init(command);
 cm_buf_get("%c %s",&option,DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
  {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
  }
 /* compare old record and current record, if the record has not been changed  
    since last request, update or delete the record, otherwise return errmsg
    to client side */

 /* get old record info from command buffer */ 

 memcpy(&raw_len,&comm[com_len],sizeof(int));   
 pos = &comm[com_len+sizeof(int)];
 raw_ptr = malloc(raw_len);
 if (raw_ptr != (char*)0)  
  memcpy(raw_ptr,pos,raw_len);
 else
  {
   if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */ 
    return M_CM_NOT_MALLOC;
   else  
    return apiRC;
  }
    
 cm_buf_init(raw_ptr);          /* get index key from old record */
 cm_buf_get("%l %s %s %s %e %s",&dummy,old_fdmg_brg,old_irate,
                             old_ipro_year,&old_pfactor,old_drate);

   $BEGIN WORK;                
 $SELECT pfactor 
  INTO $pfactor  
  FROM car_model_factor 
  WHERE fdmg_brg=$old_fdmg_brg and irate=$old_irate and
        ipro_year=$old_ipro_year and drate=$old_drate;

  /* if key value has been changed then SQLNOTFOUND,else put current value
     into cur_buf for comparison */ 

 if (SQLCODE == SQLNOTFOUND)
  {
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(exitsub(reply,M_CA_NCAR_MODEL_FACTOR) == True) 
    return M_CA_NCAR_MODEL_FACTOR;
   else  
    return apiRC;
  }
  $WHENEVER SQLERROR GOTO errexit;

  sprintf_s(tmp_pfactor, sizeof tmp_pfactor, "%.4f",pfactor);

 cm_buf_init(cur_buf);
 cm_buf_put("%l %s %s %s %s %s",dummy,old_fdmg_brg,
             old_irate,old_ipro_year,tmp_pfactor,old_drate);

 if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
  {
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   free(raw_ptr);
   if(exitsub(reply,M_CM_NOT_EQUAL) == True) 
    return M_CM_NOT_EQUAL;
   else  
    return apiRC;
  }
   $WHENEVER SQLERROR GOTO errexit;
  
 /* equal, then exec DB operation */

 if ( option == 'D' )
  {
   for(j=0;j<i;j++)
   {
    sprintf_s(stmt_buf, sizeof stmt_buf, "DELETE FROM %s: car_model_factor "
                       " WHERE fdmg_brg= ? AND irate=? "
                       " AND ipro_year=? AND drate=? " ,list[j].dbname); 
    $PREPARE d_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      break;
     }
    $EXECUTE d_id USING $old_fdmg_brg,$old_irate,$old_ipro_year,$old_drate; 
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      break;
     }
#ifdef DEBUG 
printf("Delete %d\n", j+1);
#endif
   }/* for loop */

   if( is_del_fail ) goto errexit;
   
   
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }  

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else if (option == 'U')
  {
/* 9/3/1993    $BEGIN WORK;               */ 
   cm_buf_init(command);
   cm_buf_get("%c %s %s %s %s %e %s",&option,DBName,fdmg_brg,
                   irate,ipro_year,&pfactor,drate);

   $WHENEVER SQLERROR CONTINUE;
   for(j=0;j<i;j++)
   {
    sprintf_s(stmt_buf, sizeof stmt_buf, "UPDATE %s:car_model_factor SET "
             " (fdmg_brg,irate,ipro_year ,pfactor,drate) "
             " = (?,?,?,?,?) WHERE fdmg_brg = ? AND irate = ? "
             " AND ipro_year = ? AND drate = ?",list[j].dbname);

    $PREPARE u_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      break;
     }
    $EXECUTE u_id USING $fdmg_brg,$irate,$ipro_year,$pfactor,$drate,
                        $old_fdmg_brg,$old_irate,$old_ipro_year,$old_drate;       
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      break;
     }
    if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
     {
  	sprintf_s(stmt_buf, sizeof stmt_buf, "INSERT INTO %s:car_model_factor (fdmg_brg,irate,ipro_year,pfactor,drate) VALUES (?,?,?,?,?)" ,list[j].dbname);

      $PREPARE ua_id FROM $stmt_buf;
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        break;
       }
      $EXECUTE ua_id USING $fdmg_brg,$irate,$ipro_year,$pfactor,$drate; 
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        break;
       }
     }
#ifdef DEBUG 
printf("Update %d\n", j+1);
#endif
   } /* for loop */

   if( is_upd_fail ) goto errexit;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }  

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else
  {
   if(exitsub(reply,M_CM_WRONG_OPTION) == True) 
    return M_CM_WRONG_OPTION;
   else  
    return apiRC;
  } 

 errexit:
  $WHENEVER SQLERROR CONTINUE;
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True) 
   return MsgCode;
  else  
   return apiRC;
}

long car125_drate_insert(reply)
serverReply reply;
{
     $char LsBuffer[1024], sFullName[20];
     $char DBName[5],insert_drate[11];
     $char fdmg_brg[2],irate[3],ipro_year[5],drate[11],max_drate[11];
     $int count_ipro_year = 0,count_drate0,count_drate1,count_drate2;
     $char ipro_year_check[2],check_drate[2],chk_ipro_year[2];
     long MsgCode;
     int LiBufLen;
     cm_buf_get("%s",DBName);
     cm_buf_get("%s ",insert_drate);
     strcpy(insert_drate,cm_to_infdate(insert_drate));
     printf("--drate[%s]\n",insert_drate);
     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
         return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
     
     $BEGIN WORK;
     $WHENEVER SQLERROR GOTO errexit;
    /*-------------------�ˮֶ}�l-------------------*/    
    
    /*�ͮĤ�O�_�j��ثe���@�ɳ̷s�ͮĤ�*/
     $SELECT MAX(drate) ,case when MAX(drate) < $insert_drate then 'Y' else 'N' end 
        INTO $max_drate , $check_drate 
       FROM car_model_factor;
     
     if(strcmp(check_drate,"N")==0)
      {
         $ROLLBACK WORK;	
         return exitsub(reply,M_CA_MAX_DRATE) ? M_CA_MAX_DRATE : apiRC;
      }
      
      printf("+++++max_drate[%s]\n",max_drate);
      /*�ͮĤ���P�s�y�~���̤j�~�������@�P*/
      $SELECT case when max(ipro_year)+1 = year($insert_drate) then 'Y' else 'N' end 
         INTO $chk_ipro_year
         FROM car_model_factor
        WHERE drate = $max_drate;
     
     if(strcmp(chk_ipro_year,"N")==0)
      {
         $ROLLBACK WORK;	
         return exitsub(reply,M_CA_MAX_IPRO_YEAR) ? M_CA_MAX_IPRO_YEAR : apiRC;
      }
           
     /*---�ˮ֦~�װ϶��O�_�����~---*/ 
     $DECLARE q_cur1 CURSOR for
       SELECT fdmg_brg,irate,count(ipro_year)
         INTO $fdmg_brg,$irate,$count_ipro_year
         FROM car_model_factor
        WHERE drate = $max_drate
        GROUP BY fdmg_brg,irate;         
     $OPEN q_cur1;
      for(;;)
      {   
    	 $FETCH q_cur1;
         if(SQLCODE != 0) break;        
         if(count_ipro_year > 5)
         {
          $ROLLBACK WORK;	
          return exitsub(reply,M_CA_YEAR_MORE_FIVE) ? M_CA_YEAR_MORE_FIVE : apiRC;
         }       	
      }
     $CLOSE q_cur1;
           
     $DECLARE q_cur2 CURSOR for
       SELECT CASE WHEN ipro_year BETWEEN year(drate)-4 AND year(drate) THEN 'Y' ELSE 'N' END
         INTO $ipro_year_check
         FROM car_model_factor
        WHERE drate = $max_drate;
        
      $OPEN q_cur2;   
      for(;;)
      { 	  
     	$FETCH q_cur2;
        if(SQLCODE != 0) break;
        if(strcmp(ipro_year_check,"N")==0)
        {
         $ROLLBACK WORK;	
         return exitsub(reply,M_CA_YEAR_MORE_FIVE) ? M_CA_YEAR_MORE_FIVE : apiRC;
        }
      }
     $CLOSE q_cur2;
         
/*-------------------�ˮֵ����}�l�s�W-------------------*/  
      
         
     sprintf_s(LsBuffer, sizeof LsBuffer, "INSERT INTO car_model_factor (fdmg_brg,irate,ipro_year,pfactor,drate) "
                            " SELECT fdmg_brg,irate,cast(ipro_year+1 as char(4)),pfactor,'%s' "
                            "   FROM car_model_factor "
                            "  WHERE drate BETWEEN '%s' AND '%s' ",insert_drate,max_drate,max_drate);    
     
     $PREPARE aaa FROM $LsBuffer;
     $EXECUTE aaa ;
     printf("LsBuffer[%s]\n",LsBuffer);
     
     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);
     LiBufLen = cm_buf_len(ReplyBuf);   

     if(SendSyncReply(reply,ReplyBuf,LiBufLen,api_OKComplete) == False)
     {
       $WHENEVER SQLERROR CONTINUE;
       $ROLLBACK WORK;
       return apiRC;
     }

     $WHENEVER SQLERROR GOTO errexit;
     $COMMIT WORK;
     return api_OKComplete;

     errexit:
         printf(" sqlerrm = %s\n",sqlca.sqlerrm);
         $WHENEVER SQLERROR CONTINUE;
         MsgCode = SQLCODE;
         $ROLLBACK WORK;
         if (SQLCODE != 0) MsgCode = SQLCODE;
         return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}