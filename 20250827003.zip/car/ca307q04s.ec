/**********************************************************************/
/*   program id   : ca307q04s.ec                                      */
/*   program name : �O��ɵo���Ӫ�                                    */
/*   date written : 10/16/2018                                        */
/*   date modify  : yyyy/mm/dd                                        */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <decimal.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "globdata.h"
#include <math.h>
#include "carmsgs.h" 
#include "cmnmsgs.h" 
#include "gls_array.h" 
#include "gls_const.h"
#include "safeclib.h"


$char stmt[1024],stmt1[1024],stmt2[1024],stmt3[1024],stmt4[6000],stmt5[1024],stmp[2048];
$char stmt6[1024],stmt7[1024],chk_yn[2];
$char ipolicy[21],iupdate[21],dupdate[22];
$char swhere[100],swhere2[100],datavalues[8],fIsLeader[2];
int   count_db=0,k=0,i=0; 
$int cnt_empl_no = 0,top_unit = 0,top_40 = 0,top_20 = 0,cnt_top_unit =0;
$char fIsLeader[2];
char  outputf[21];
$char userid[11];
$char DBName[05];
char  ipolicy_entry[21],iuser[21],dbgn[11],dend[11],iquota[4];
$char  dbgn2[11],dend2[11],userid_test[21];  /*userid_test�����v����*/
$char iclass[4],iclass1[10];
$char FormTp[03];
$char msgbuf[128];

int   max_count=0;

DBinfo *list;

/*********************************************************************/
main(argc, argv)
int argc;
char **argv;
{
 	int rc;

	batchinit();
	strcpy(DBName,    	isNULLstr(argv[1]));
	strcpy(userid,    	isNULLstr(argv[2]));
        strcpy(ipolicy_entry,   isNULLstr(argv[3])); 
        strcpy(iuser,     	isNULLstr(argv[4])); 
        strcpy(dbgn,      	isNULLstr(argv[5]));
        strcpy(dend, 	  	isNULLstr(argv[6]));
        strcpy(iquota,    	isNULLstr(argv[7])); 
        /*strcpy(userid_test,    	isNULLstr(argv[8]));   /*�����v����*/
        strcpy(outputf,   	isNULLstr(argv[8]));
	
	strcpy(dbgn2, cm_to_infdate(dbgn));
   	strcpy(dend2, cm_to_infdate(dend));
   	printf("dbgn[%s]--dend[%s]\n", dbgn, dend);
   	printf("dbgn2[%s]--dend2[%s]\n", dbgn2, dend2);

   	
   	
	rc = car3074_get_db();
	if (rc != M_CM_OK)
		return rc;

	rc = car3074_prepare_data();
	if (rc != M_CM_OK)
		return rc;
		
 	rc = car3074_build2();
	if (rc != M_CM_OK) 
		return rc;    

        if ((rc=save_form_info(F_FREE,"CA",307,userid,FormTp,max_count,outputf))<0)
        {
            EWRITE(userid,rc,"save_form_info failed");
            exit(FAIL);
        }
}
/*----------------------------------------------------------------------------*/
long car3074_get_db()
{
	$whenever sqlerror goto errexit;

	if (db_select(DBName) == FALSE) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
/*----------------------------------------------------------------------------*/
/*
long car3074_build()
{
 
 
 int rc;
 char sfilename[256],stitle[2048],stmt1[6000];

 
	$WHENEVER SQLERROR GOTO errexit;

	strcpy(sfilename,"�O��ɵo���Ӫ�[car3074]");	
	sprintf_s(stitle, sizeof stitle,"ñ�����϶�:%s~%s\t",dbgn,dend);
	strcat(stitle,"\n");
	
	strcat(stitle,"\t�O�渹\t���\t���W��\t�C�L�H��\t�C�L���\t�޲z�H�N��\t�޲z�H�W��\t�g��N��\t�q�l�O����O\t�C�L����\t��渹\t");
	
	sprintf_s(stmt2, sizeof stmt2,"SELECT ipolicy,iquota,nquota,iupdate,dupdate,ileader,nleader,iofficer,feply,times,iendorse FROM CAR3074_2 %s ;",swhere2);
	

	rc = unload_file(outputf," ",sfilename,stitle,stmt2);
	
	if (rc != SUCCESS) 
	{
	    sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
	    EWRITE(userid, rc , msgbuf);
	    return rc;
	}
	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	return SQLCODE;   
   
}
*/
/*----------------------------------------------------------------------------*/
long car3074_prepare_data()
{
   
   int rc=0;

   $WHENEVER SQLERROR GOTO errexit;

   $CREATE TEMP TABLE CAR3074_1
    ( 
      ilog_number1 	CHAR(20),  /*�O�渹*/
      iupdate 		CHAR(20),  /*�C�L�H��*/
      dupdate		VARCHAR(50)       /*�C�L���*/

    ) WITH NO LOG;
    


   $CREATE TEMP TABLE CAR3074_2
    ( 
      ipolicy 	        CHAR(20),  /*�O�渹*/
      iquota 		CHAR(20),  /*���*/
      nquota		CHAR(40),  /*���W��*/
      iupdate 		CHAR(20),  /*�C�L�H��*/
      nupdate		CHAR(40),
      dupdate		VARCHAR(50),      /*�C�L���*/      
      ileader		CHAR(20),  /*�޲z�H�N��*/ 
      nleader		CHAR(40),  /*�޲z�H�W��*/
      iofficer          CHAR(20),  /*�g��N��*/
      feply             CHAR(1),   /*�q�l�O����O*/
      times             CHAR(3),   /*�C�L����*/
      iendorse          CHAR(20)   /*��渹*/
    ) WITH NO LOG;
    
    
    /********�Nñ�����ŦX���O��ɵo��Ʀs�Jtemp table********/
    strcpy(swhere," ");
   
    if(strcmp(dbgn,"*") == 0 && strcmp(dend,"*") == 0)
    {
         strcpy(swhere," ");
    }    
    if (strcmp(dbgn,"*") == 0 && strcmp(dend,"*") == 1)
    {
         sprintf_s(swhere, sizeof swhere," AND a.dpolicy <= '%s' ",dend2);
    }
    if (strcmp(dbgn,"*") == 1 && strcmp(dend,"*") == 0)
    {
         sprintf_s(swhere, sizeof swhere," AND a.dpolicy >= '%s' ",dbgn2);
    }  	
    if(strcmp(dbgn,"*") == 1 && strcmp(dend,"*") == 1)
    {
         sprintf_s(swhere, sizeof swhere," AND a.dpolicy between '%s' and '%s' ",dbgn2,dend2);
    }

    printf("swhere[%s]\n",swhere);
    
    $char temp[100];
    strcpy(temp,"to_char(b.dupdate,'%Y/%m/%d %H:%M:%S')");
    sprintf_s(stmt4, sizeof stmt4,
    "INSERT INTO CAR3074_1 SELECT b.ilog_number1,b.iupdate,%s FROM ca_log b,newa00:ply_relation a WHERE b.ipgid = 'car307' AND b.ilog_number1=a.ipolicy %s ;"
    "INSERT INTO CAR3074_1 SELECT b.ilog_number1,b.iupdate,%s FROM ca_log b,newa22:ply_relation a WHERE b.ipgid = 'car307' AND b.ilog_number1=a.ipolicy %s ;"
    "INSERT INTO CAR3074_1 SELECT b.ilog_number1,b.iupdate,%s FROM ca_log b,newa33:ply_relation a WHERE b.ipgid = 'car307' AND b.ilog_number1=a.ipolicy %s ;"
    "INSERT INTO CAR3074_1 SELECT b.ilog_number1,b.iupdate,%s FROM ca_log b,newa40:ply_relation a WHERE b.ipgid = 'car307' AND b.ilog_number1=a.ipolicy %s ;"
    "INSERT INTO CAR3074_1 SELECT b.ilog_number1,b.iupdate,%s FROM ca_log b,newa66:ply_relation a WHERE b.ipgid = 'car307' AND b.ilog_number1=a.ipolicy %s ;"
    "INSERT INTO CAR3074_1 SELECT b.ilog_number1,b.iupdate,%s FROM ca_log b,newa70:ply_relation a WHERE b.ipgid = 'car307' AND b.ilog_number1=a.ipolicy %s ;",temp,swhere,temp,swhere,temp,swhere,temp,swhere,temp,swhere,temp,swhere);
    $PREPARE pre_ply4 from $stmt4; 
    $EXECUTE pre_ply4;  
    
    
    
    /********�A�qtemp table���N�O�渹�B����H���B���ŦX����X��*******/
    
    
	sprintf_s(stmt, sizeof stmt,"SELECT ilog_number1,iupdate,dupdate FROM CAR3074_1 WHERE ilog_number1 matches '%s' AND iupdate matches '%s' AND ilog_number1[1,3] matches '%s'",ipolicy_entry,iuser,iquota);
        sprintf_s(stmt3, sizeof stmt3,"SELECT COUNT(*) FROM CAR3074_1 WHERE ilog_number1 matches '%s' AND iupdate matches '%s' AND ilog_number1[1,3] matches '%s' ",ipolicy_entry,iuser,iquota);
        printf("stmt[%s]\n",stmt);

        $PREPARE pre_ply3 from $stmt3;
	$DECLARE cur_data3 CURSOR FOR pre_ply3;
      	$OPEN cur_data3;	
      	$FETCH cur_data3 INTO $datavalues;
        $CLOSE cur_data3;
	$FREE  cur_data3;       	
      	

      	$PREPARE pre_ply from $stmt;
	$DECLARE cur_data CURSOR FOR pre_ply;
      	$OPEN cur_data;	
      	for(int a=1;a<=atoi(trim(datavalues));a++)
      	{
        	$FETCH cur_data INTO $ipolicy,$iupdate,$dupdate;
        	
        	strcpy(ipolicy,trim(ipolicy));
        	strcpy(iupdate,trim(iupdate));
        	strcpy(dupdate,rtrim(dupdate));

        	for (i=0;i<count_db;i++)
        	{
        	/*�O�渹*//*���*//*���W��*//*�C�L�H��*//*�C�L���*//*�޲z�H�N��*//*�޲z�H�W��*//*�g��N��*//*�q�l�O����O*//*�C�L����*/   
          		sprintf_s(stmt1, sizeof stmt1,"INSERT INTO CAR3074_2(ipolicy,iquota,nquota,iupdate,nupdate,dupdate,ileader,nleader,iofficer,feply,times,iendorse)  \n"
                     	"SELECT first 1  a.ipolicy,a.iquota,b.nbranch,'%s',(select nname FROM officer where iofficer='%s'),'%s',a.ileader,c.nname,a.iofficer,a.feply,(SELECT COUNT(*) FROM  ca_log WHERE ipgid = 'car307' AND ilog_number1='%s'),d.iendorse  \n"
                       	"FROM  %s:ply_relation a,sa_branch_type b,officer c,outer %s:edr_relation d  \n"
                      	"WHERE  a.ipolicy='%s' AND b.ibranch = a.iquota AND a.ileader = c.iofficer AND d.iendorse not like '%%CVP%%' \n"
                      	"       AND d.ipolicy = a.ipolicy ORDER BY d.iendorse desc \n",iupdate,iupdate,dupdate,trim(ipolicy),list[i].dbname,list[i].dbname,trim(ipolicy));
			/*ORDER BY d.dcreate  desc*/
        		$PREPARE prep2 FROM $stmt1;
        		$EXECUTE prep2;

        	}	
	}
        $CLOSE cur_data;
	$FREE  cur_data; 
      	
        printf("�ŦX��J���󪺦@��[%s]��\n",trim(datavalues));

    
   /********�Ϥ��v��********/
	
	
	/*�Ϥ��O�_���ӫO���ӫ~��*/
	$SELECT count(*) 
	   INTO $cnt_empl_no
	   FROM personal:asempl 
	  WHERE unit_id[1,4] = '3201' 
	    AND move_type < 59 
	    AND empl_no = $userid;   /*userid_test�����v���ΡA�W�u�ɧאּuserid*/
	
	if(cnt_empl_no > 0) /*�O�ӫO���ӫ~��*/
        {
 	    	strcpy(stmp," FROM CAR3074_2 a \n ");
 	    	strcpy(chk_yn,"Y");
 	    	printf("##userid��%s�A�O�_�O�ӫO���ӫ~��:%s�A�i�d�ݥ������##\n",userid,chk_yn);/*userid_test�����v���ΡA�W�u�ɧאּuserid*/
 	}    
 	else                /*���O�ӫO���ӫ~��*/
 	{
 		strcpy(chk_yn,"N");
		printf("##userid��%s�A�O�_�O�ӫO���ӫ~��:%s ##\n",userid,chk_yn);/*userid_test�����v���ΡA�W�u�ɧאּuserid*/
		
		$SELECT  CASE WHEN count(*) > 0 THEN 'Y'  /*��A����ťD��*/
                             ELSE 'N' END                 /*���֫O*/
                   INTO  $fIsLeader
                   FROM  personal:unitid2ef
                  WHERE  resp_name = $userid 
                         AND code_no IN (SELECT ibranch FROM sa_branch_type WHERE dexpire IS NULL AND bud_type = 'B' AND fprop = '3'); 

		if(strcmp(fIsLeader,"Y") == 0 )
		{ 
			 
			printf("##��A����ťD�ޡA�i�d�ݸ��Ұϸ��##\n"); 
			if(strcmp(iuser,"*") == 0 && strcmp(iquota,"*") == 1)       /*�ҰϤ��֫O�H�����ɵo���*/  
			{           
	 			sprintf_s(stmp, sizeof stmp," FROM CAR3074_2 a,sa_branch_type b,officer c  \n "
	 				     " WHERE  b.ibranch = c.iquota AND a.iupdate = c.iofficer AND b.group2 = (SELECT group2 FROM sa_branch_type WHERE ibranch = (SELECT iquota FROM officer WHERE iofficer = '%s'))",userid);
	 		}
	 		else if(strcmp(iquota,"*") == 0 && strcmp(iuser,"*") == 1)  /*�ҰϤ��O�檺�ɵo���*/ 
	 		{
	 			sprintf_s(stmp, sizeof stmp," FROM CAR3074_2 a,sa_branch_type b \n "
	 				     " WHERE b.ibranch = a.iquota AND b.group2 = (SELECT group2 FROM sa_branch_type WHERE ibranch = (SELECT iquota FROM officer WHERE iofficer = '%s'))",userid);
	 		}
	 		else if(strcmp(iquota,"*") == 0 && strcmp(iuser,"*") == 0)
	 		{
	 			sprintf_s(stmp, sizeof stmp," FROM CAR3074_2 a,sa_branch_type b,officer c  \n "
	 				     " WHERE b.ibranch = c.iquota AND a.iupdate = c.iofficer AND b.group2 = (SELECT group2 FROM sa_branch_type WHERE ibranch = (SELECT iquota FROM officer WHERE iofficer = '%s')) " 
	 				     " UNION \n"
	 				     " SELECT a.ipolicy,a.iquota,a.nquota,a.iupdate,a.dupdate,a.ileader,a.nleader,a.iofficer,a.feply,a.times,a.iendorse \n"
	 				     " FROM CAR3074_2 a,sa_branch_type b \n "
	 			             "  WHERE b.ibranch = a.iquota AND b.group2 = (SELECT group2 FROM sa_branch_type WHERE ibranch = (SELECT iquota FROM officer WHERE iofficer = '%s'))",userid,userid);
	 		}
	 		else if(strcmp(iquota,"*") == 1 && strcmp(iuser,"*") == 1)
	 		{
	 			sprintf_s(stmp, sizeof stmp," FROM CAR3074_2 a,sa_branch_type b,officer c  \n "
	 				     " WHERE b.ibranch = c.iquota AND a.iupdate = c.iofficer AND b.group2 = (SELECT group2 FROM sa_branch_type WHERE ibranch = (SELECT iquota FROM officer WHERE iofficer = '%s')) " 
	 				     " UNION \n"
	 				     " SELECT a.ipolicy,a.iquota,a.nquota,a.iupdate,a.dupdate,a.ileader,a.nleader,a.iofficer,a.feply,a.times,a.iendorse \n"
	 				     " FROM CAR3074_2 a,sa_branch_type b \n "
	 			             "  WHERE b.ibranch = a.iquota AND b.group2 = (SELECT group2 FROM sa_branch_type WHERE ibranch = (SELECT iquota FROM officer WHERE iofficer = '%s'))",userid,userid);
	 		}		
	 			
	 	}
	 	else                           
	 	{
	 		printf("##��L�A�i�d�ݦۤv���##\n");
	 		sprintf_s(stmp, sizeof stmp," FROM CAR3074_2 a WHERE a.iupdate = '%s' ",userid);
						
	 	}
	}   
    

    
   return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(1);
}

long car3074_build2()
{
  $char FormFile[N_FILE+1];
  char  OutFile[N_FILE];
  long  rtncode;


   $char  ipolicy2[21],iquota2[21],nquota2[41],iupdate2[21],nupdate2[41],dupdate2[24],ileader2[21];  /*�o�@��*/
   $char  nleader2[41],iofficer2[21],feply2[2],times2[3],iendorse2[21];
   $char  ipolicy1[21],iquota1[21],nquota1[41],iupdate1[21],nupdate1[41],dupdate1[24],ileader1[21];  /*�W�@��*/
   $char  nleader1[41],iofficer1[21],feply1[2],times1[3],iendorse1[21];



  $WHENEVER SQLERROR GOTO errexit;


  $SELECT nForm_File, iForm_Tp
     INTO $FormFile, $FormTp
     FROM Form
    WHERE ksys_grp="CA" AND kPgmID = 307
      AND iform_tp = '4';
      
   if (SQLCODE == SQLNOTFOUND) 
   {
	$INSERT INTO form (ksys_grp,kpgmid,kform_grp,iform_tp,iprn_type,kstart_row,ktitle_row,kitem_row,ktot_col,kpgnum_line,ntitle_fmt,nbody_fmt,nform_file,kwidth,klines_page,fbackup)
	  VALUES ('CA',307,'F','4','',0,0,0,0,0,'','','car3074.fmt',100,0,'N');

   } 

  strcpy(FormFile,rtrim(FormFile));  /* FormFile=car3074.fmt */
  sprintf_s(OutFile, sizeof OutFile,"%s.tx",outputf);
  rgu_init_report(FormFile,OutFile);

  rgu_put_body(7);
  rgu_put_body_string(1,ipolicy_entry,LEFT);
  rgu_put_body(1);
  rgu_put_body_string(2,iuser,LEFT);
  rgu_put_body(2);
  rgu_put_body_string(3,dbgn,LEFT);
  rgu_put_body_string(3,dend,LEFT);
  rgu_put_body(3);
  rgu_put_body_string(4,iquota,LEFT);
  rgu_put_body(4);

  rgu_put_body(5);
  max_count+=9;

  /****************���v���z����*****************/

  sprintf_s(stmt5, sizeof stmt5, "SELECT a.ipolicy,a.iquota,a.nquota,''''||a.iupdate,a.nupdate,a.dupdate,''''||a.ileader,a.nleader,''''||a.iofficer,a.feply,a.times,a.iendorse \n"
                 "   %s ORDER BY a.ipolicy  \n",stmp);
  printf("stmt5[%s]",stmt5);
  $PREPARE prep5 FROM $stmt5;
  $DECLARE curs5 CURSOR FOR prep5;
  $OPEN curs5;
  for(;;)
  {
      $FETCH curs5 INTO $ipolicy2,$iquota2,$nquota2,$iupdate2,$nupdate2,$dupdate2,$ileader2,$nleader2,$iofficer2,$feply2,$times2,$iendorse2;
      
      
      if( SQLCODE == SQLNOTFOUND) break;
      
      if(strcmp(ipolicy1,"") == 1)
      {
      	/*�o�@���M�W�@���ۤ���A�p�G�C�L�H���Τ�����P�A��l��쳣�ۦP�A���ܦC�L����1���H�W*//*&& (strcmp(iupdate2,iupdate1) == 1 || strcmp(dupdate2,dupdate1) == 1 )*/
      	if(strcmp(ipolicy2,ipolicy1) == 0 && strcmp(times2,times1) == 0 && strcmp(iendorse2,iendorse1) == 0)
      	{
      		rgu_put_body_string(6,"  ",LEFT);
      		rgu_put_body_string(6,"  ",LEFT);
      		rgu_put_body_string(6,"  ",LEFT);
      		rgu_put_body_string(6,iupdate2,LEFT);
      		rgu_put_body_string(6,nupdate2,LEFT);
      		rgu_put_body_string(6,dupdate2,LEFT);
      		rgu_put_body_string(6,"  ",LEFT);
      		rgu_put_body_string(6,"  ",LEFT);
      		rgu_put_body_string(6,"  ",LEFT);
      		rgu_put_body_string(6,"  ",LEFT);
      		rgu_put_body_string(6,"  ",LEFT);
      		rgu_put_body_string(6,"  ",LEFT);
      		rgu_put_body(6);      	
      	}
      	else
      	{
      		rgu_put_body_string(6,ipolicy2,LEFT);
      		rgu_put_body_string(6,iquota2, LEFT);
      		rgu_put_body_string(6,nquota2,LEFT);
      		rgu_put_body_string(6,iupdate2,LEFT);
      		rgu_put_body_string(6,nupdate2,LEFT);
      		rgu_put_body_string(6,dupdate2,LEFT);
      		rgu_put_body_string(6,ileader2,LEFT);
      		rgu_put_body_string(6,nleader2,LEFT);
      		rgu_put_body_string(6,iofficer2,LEFT);
      		if(strcmp(feply2,"0") == 0){ 
      		    rgu_put_body_string(6,"�_",LEFT);
      		}else if(strcmp(feply2,"1") == 0){ 
      		    rgu_put_body_string(6,"�O",LEFT);      		
      		}else{
      		    rgu_put_body_string(6,feply2,LEFT); 
      	        }
      		rgu_put_body_string(6,times2,LEFT);
      		rgu_put_body_string(6,iendorse2,LEFT);
      		rgu_put_body(6);
      	}
      }
      
      max_count++;
      
      /*�x�s�_�ӡA�U�@�ӧP�_��*/
      strcpy(ipolicy1,ipolicy2);
      strcpy(iquota1,iquota2);
      strcpy(nquota1,nquota2);
      strcpy(iupdate1,iupdate2);
      strcpy(nupdate1,nupdate2);
      strcpy(dupdate1,dupdate2);
      strcpy(ileader1,ileader2);
      strcpy(nleader1,nleader2);
      strcpy(iofficer1,iofficer2);
      strcpy(feply1,feply2);     
      strcpy(times1,times2);
      strcpy(iendorse1,iendorse2);  
      

      
           
  }
  $FREE prep5;
  $CLOSE curs5;
  $FREE curs5;
  
  char total[6];
  sprintf_s(total, sizeof total,"%d",max_count-9);

  if(strcmp(total,"0") == 0)
  {  	
      	rgu_put_body_string(8,"�L��Ʃαz�L�d���v��!",LEFT);
      	rgu_put_body(8);
      	
  }else{
        rgu_put_body_string(8,"    ",LEFT);
        rgu_put_body(8);
 
  }
  
  
  
  rgu_put_body_string(9,total,LEFT);
  rgu_put_body(9);
  rgu_put_body(10);
  

  
  rgu_finish_report();
  printf("finish_code------>%d\n",rtncode);
  printf("�i�d�ݸ�Ʀ�[%s]��\n",total);
  return M_CM_OK;
  
errexit:
  sqlfatal();
  EWRITE(userid,SQLCODE,sqlca.sqlerrm);
  exit (FAIL);
} 

/*--------------------------------------------------------------------*/