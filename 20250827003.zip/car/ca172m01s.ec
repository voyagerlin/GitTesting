/************************************************/
/*                                              */
/*   PROGRAM : car172.ec
/*                                              */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;
$include decimal;
#include "safeclib.h"


long car172(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car172_insert(),car172_single_query(),car172_multiple_query(),car172_update_exec();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'A':
	   rtncode=car172_insert(reply);
	   break;
  case 'Q':
	   rtncode=car172_single_query(reply);
	   break;
  case 'M':
     rtncode=car172_multiple_query(reply);
	   break;
  case 'D': 
     rtncode=car172_delete(reply);
     break;
  case 'U': 
     rtncode=car172_update(reply);
     break;       
  default :
	   if(exitsub(reply,M_CM_WRONG_OPTION) == True)
	    return M_CM_WRONG_OPTION;
           return apiRC;
 }
 printf("rtncode[%d]\n",rtncode);
 return(rtncode);
}

long car172_insert(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */
 
 /* table ca_provision_product */
 $char iprovision[21], iins_type[7], iproduct[12], fclass[2], icar_type[3];
 $char foil_electric[2];
 $char userid[11];
 /* end of ca_provision_product */

 /* standard defined data */
 int tmp_len;
   DBinfo *list;
   int i, j, is_add_fail=0, api_f;
   $char stmt_buf[2000],stmtx[2000];
 /* end of standard data */

 /* self defined data */
 long MsgCode;
 /* end of self data */

 int LiBufLen;
 cm_buf_get("%s",DBName);
 cm_buf_get("%s %s %s %s %s %s %s",iprovision,iins_type,iproduct,fclass,icar_type,foil_electric,userid);

 $WHENEVER SQLERROR GOTO errexit;
 
 if (db_select(DBName) == False)
	return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

 $BEGIN WORK;
 $WHENEVER SQLERROR GOTO errexit;

	$INSERT INTO ca_provision_product
	       ( iprovision, iins_type, iproduct, fclass, icar_type, foil_electric, icreate,dcreate,iupdate,dupdate)
	VALUES ($iprovision,$iins_type,$iproduct,$fclass,$icar_type,$foil_electric,$userid,current,$userid,current);

 cm_buf_init(ReplyBuf);
 cm_buf_put("%l",M_CM_OK);
 LiBufLen = cm_buf_len(ReplyBuf);

 if(SendSyncReply(reply,ReplyBuf,LiBufLen,api_OKComplete) == False)
 {
	$WHENEVER SQLERROR CONTINUE;
	$ROLLBACK WORK;
	return apiRC;
 }


 $WHENEVER SQLERROR GOTO errexit;
 $COMMIT WORK;
 return api_OKComplete;

 errexit:
 printf(" sqlerrm = %s\n",sqlca.sqlerrm);
 $WHENEVER SQLERROR CONTINUE;
 MsgCode = SQLCODE;
 $ROLLBACK WORK;
 if (SQLCODE != 0) MsgCode = SQLCODE;
 return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

long car172_single_query(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table ca_provision_product */
 $char iprovision[21], iins_type[7], iproduct[12], fclass[2], icar_type[3];
 $char foil_electric[2];
 $char icreate[11], dcreate[21], iupdate[11], dupdate[21];
 $dec_t dec;
 /* end of ca_provision_product */

 /* standard defined data */
 int tmp_len;
 /* end of standard data */


 cm_buf_get("%s",DBName);
 cm_buf_get("%s %s %s %s %s %s",iprovision,iins_type,iproduct,fclass,icar_type,foil_electric);
 
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False) 
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

 $SELECT iprovision, iins_type, iproduct, fclass, icar_type, foil_electric, icreate, dcreate, iupdate, dupdate

       /*(select nname from officer where iofficer = a.icreate),
         (select nname from officer where iofficer = a.iupdate)*/
         
   INTO $iprovision, $iins_type, $iproduct, $fclass, $icar_type, $foil_electric, $icreate, $dcreate, $iupdate, $dupdate
   FROM ca_provision_product
  WHERE iprovision   = $iprovision 
    AND iins_type    = $iins_type 
    AND iproduct     = $iproduct 
    AND fclass       = $fclass 
    AND icar_type    = $icar_type
    AND foil_electric= $foil_electric;

 printf("155\n");
 if(SQLCODE == SQLNOTFOUND) 
 {
 	printf("158\n");
    if(exitsub(reply,M_CM_NOT_FOUND) == True)       /*?*/
			return M_CM_NOT_FOUND;                        /*?*/
		else
			return apiRC;
 }

  
 cm_buf_init(ReplyBuf); 
 cm_buf_put("%l",M_CM_OK);
 cm_buf_put("%s %s %s %s %s %s %s %s %s %s",
 iprovision, iins_type, iproduct, fclass, icar_type, foil_electric, icreate, dcreate, iupdate, dupdate);
 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
  return apiRC;
 else
  return api_OKComplete;

 errexit:
  if(exitsub(reply,SQLCODE) == True) 
   return SQLCODE;
  else  
   return apiRC;
}

long car172_multiple_query(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table ca_provision_product */
 $char iprovision[21], iins_type[7], iproduct[12], fclass[2], icar_type[3];
 $char foil_electric[2];
 $char userid[11];
 $char keyclass[2];
 $dec_t dec;
 $char sTmp1[1000], sTmp2[100],rate[7];
 $char sTmp3[100],sTmp4[100],sTmp5[100],sTmp6[100];
 /* end of ca_provision_product */

 /* standard defined data */
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0; 
 /* end of standard data */


 char pbegin[10];
 int flag;

 cm_buf_get("%s",DBName);
 cm_buf_get("%s %s %s %s %s %s",iprovision,iins_type,iproduct,fclass,icar_type,foil_electric);

 keyclass[1] = '\0';

	if (strcmp(iprovision, "*") == 0)
	{
		strcpy(sTmp2, "");
	}
	else
	{
		/* strcpy(iprovision, cm_to_infdate(iprovision)); */
		sprintf_s(sTmp2, sizeof sTmp2, " and iprovision = '%s' ", iprovision);
		printf("iprovision=[%s]sTmp2=[%s]\n",iprovision,sTmp2);
	}
	if (strcmp(iins_type, "*") == 0)
	{
		strcpy(sTmp3, "");
	}
	else
	{
		/* strcpy(iins_type, cm_to_infdate(iins_type)); */
		sprintf_s(sTmp3, sizeof sTmp3, " and iins_type = '%s' ", iins_type);
		printf("iins_type=[%s]sTmp3=[%s]\n",iins_type,sTmp3);
	}
	if (strcmp(iproduct, "*") == 0)
	{
		strcpy(sTmp4, "");
	}
	else
	{
		/* strcpy(iproduct, cm_to_infdate(iproduct)); */
		sprintf_s(sTmp4, sizeof sTmp4, " and iproduct = '%s' ", iproduct);
		printf("iproduct=[%s]sTmp4=[%s]\n",iproduct,sTmp4);
	}
	if (strcmp(fclass, "*") == 0)
	{
		strcpy(sTmp5, "");
	}
	else
	{
		/* strcpy(fclass, cm_to_infdate(fclass)); */
		sprintf_s(sTmp5, sizeof sTmp5, " and fclass = '%s' ", fclass);
		printf("fclass=[%s]sTmp5=[%s]\n",fclass,sTmp5);
	}
	if (strcmp(icar_type, "*") == 0)
	{
		strcpy(sTmp6, "");
	}
	else
	{
		/* strcpy(icar_type, cm_to_infdate(icar_type)); */
		sprintf_s(sTmp6, sizeof sTmp6, " and icar_type = '%s' ", icar_type);
		printf("icar_type=[%s]sTmp6=[%s]\n",icar_type,sTmp6);
	}
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
    return M_CM_DB_NOTOPEN;
   else
    return apiRC;
  }

  flag =0 ;

    sprintf_s(sTmp1, sizeof sTmp1,
    	   "SELECT iprovision, iins_type, iproduct, fclass, icar_type, foil_electric "
           " FROM ca_provision_product "
    	   " WHERE 1=1 %s %s %s %s %s "
           " ORDER BY iprovision, iins_type, iproduct, fclass, icar_type;", sTmp2, sTmp3, sTmp4, sTmp5, sTmp6);
    printf("sTmp1=[%s]\n",sTmp1);

		$PREPARE m0_pre FROM $sTmp1;
		$DECLARE m0_cur  CURSOR FOR m0_pre;
    $OPEN m0_cur;


 for(;;)
  {

     $FETCH m0_cur into $iprovision, $iins_type, $iproduct, $fclass, $icar_type, $foil_electric;

    if (SQLCODE != 0)
         break;

    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();
     }


    cm_buf_put("%s %s %s %s %s %s", iprovision, iins_type, iproduct, fclass, icar_type, foil_electric);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
	if ( flag == 0 )
	 $CLOSE m0_cur;
        else
	 $CLOSE m1_cur;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
	 cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
	ReplyBuf[0] = '\0';
	count = 0;
	cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s %s %s %s %s", iprovision, iins_type, iproduct, fclass, icar_type, foil_electric);
	repbuf_len = cm_buf_len(ReplyBuf);
	count++;
       }
     }
  } /* for loop */

 if ( flag == 0 )
  $CLOSE m0_cur;
 else
  $CLOSE m1_cur;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
   if(exitsub(reply,M_CM_NOT_FOUND) == True)
    return M_CM_NOT_FOUND;/* M_CA_NDEPRE_RATE */
   else
    return apiRC;
  }

 errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}


/*-----------------------------------------------------------------*/
            
long car172_delete(reply)
serverReply reply;
{
    $char iprovision[21], iins_type[7], iproduct[12], fclass[2], icar_type[3],foil_electric[2];
    $char DBName[5];
    $char sql_stmt[1024];
    int tmp_len;
    long MsgCode;


    cm_buf_get("%s",DBName);
    cm_buf_get("%s %s %s %s %s %s",iprovision, iins_type, iproduct, fclass, icar_type, foil_electric);

    $WHENEVER SQLERROR GOTO errexit;
    if(db_select(DBName) == False) 
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
        
    $WHENEVER SQLERROR GOTO errexit;
    $BEGIN WORK;    
      
    sprintf(sql_stmt,"delete from ca_provision_product \
           where iprovision = '%s' \
             and iins_type = '%s' \
             and iproduct = '%s' \
             and fclass = '%s' \
             and icar_type = '%s' \
             and foil_electric = '%s'",
             iprovision, iins_type, iproduct, fclass, icar_type, foil_electric);

    printf("sql_stmt=[%s]\n",sql_stmt) ;
 	  $EXECUTE IMMEDIATE $sql_stmt ;

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    tmp_len = cm_buf_len(ReplyBuf);

    if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        return apiRC;
    }  

    $WHENEVER SQLERROR GOTO errexit;
    $COMMIT WORK;
    return api_OKComplete;

errexit:
    MsgCode = SQLCODE;
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if( SQLCODE != 0) MsgCode = SQLCODE;
    return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
/*-----------------------------------------------------------------*/


long car172_update(reply)
serverReply reply;
{
    $char iprovision[21], iins_type[7], iproduct[12], fclass[2], icar_type[3],foil_electric[2];
    $char old_iprovision[21], old_iins_type[7], old_iproduct[12], old_fclass[2], old_icar_type[3],old_foil_electric[2];
    $char old_icreate[11],old_dcreate[21],old_iupdate[11],old_dupdate[21];
    $char DBName[5],userid[11];
    $char sql_stmt[2048];
    $long mlimit;
    int tmp_len;
    long MsgCode;
    
    cm_buf_get("%s",DBName);            
    cm_buf_get("%s %s %s %s %s %s %s",iprovision, iins_type, iproduct, fclass, icar_type, foil_electric, userid);
    cm_buf_get("%s %s %s %s %s %s",old_iprovision, old_iins_type, old_iproduct, old_fclass, old_icar_type, old_foil_electric);
    cm_buf_get("%s %s %s %s",old_icreate,old_dcreate,old_iupdate,old_dupdate);

    $WHENEVER SQLERROR GOTO errexit;


    if(db_select(DBName) == False) 
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;


    $BEGIN WORK;   
    /*
	  sprintf(sql_stmt,
           "UPDATE ca_provision_product \
               SET (iprovision, iins_type, iproduct, fclass, icar_type, foil_electric, iupdate, dupdate ) \
                = (?,?,?,?,?,?,?,current) \
             WHERE iprovision = '%s' AND iins_type = '%s' AND iproduct = '%s' AND fclass = '%s' AND icar_type = '%s' AND foil_electric = '%s' ",
           iprovision, iins_type, iproduct, fclass, icar_type, foil_electric);
    */ 
	  sprintf(sql_stmt,
           "DELETE FROM ca_provision_product \
             WHERE iprovision = '%s' AND iins_type = '%s' AND iproduct = '%s' AND fclass = '%s' AND icar_type = '%s' AND foil_electric = '%s' ",
           old_iprovision, old_iins_type, old_iproduct, old_fclass, old_icar_type, old_foil_electric);
    printf("sql_stmt del old[%s]\n",sql_stmt) ;
    $EXECUTE IMMEDIATE $sql_stmt;

    if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
    {
        SQLCODE = M_CM_NOT_FOUND;
        goto errexit;
    }

    sql_stmt[0]= '\0';
	  sprintf(sql_stmt,      
           "INSERT INTO ca_provision_product \
              (iprovision, iins_type, iproduct, fclass, icar_type, foil_electric, icreate, dcreate, iupdate, dupdate) \
            VALUES ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s', current)",
            iprovision,iins_type,iproduct,fclass,icar_type,foil_electric,old_icreate,old_dcreate,userid );
    printf("sql_stmt add new=[%s]\n",sql_stmt) ;
    $EXECUTE IMMEDIATE $sql_stmt;
                       
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    tmp_len = cm_buf_len(ReplyBuf);

    if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        
        return apiRC;
    }  

    $WHENEVER SQLERROR GOTO errexit;
    $COMMIT WORK;
    return api_OKComplete;
    
   
errexit:
    printf("in errexit car172_update\n");
    MsgCode = SQLCODE;
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if( SQLCODE != 0) MsgCode = SQLCODE;
    return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
/*-----------------------------------------------------------------*/