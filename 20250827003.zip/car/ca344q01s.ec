/**********************************************************************/
/*   program id   : ca344q01s.ec                                      */
/*   program name : �e�~�C�L�����ޱ�                                  */
/*   date written : 2016/04/26 by 030344                              */
/*   files        :                                                   */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "globdata.h"
#include "safeclib.h"

$char dbgn[11],dbgn_cond[11];
$char dend[11],dend_cond[11];

int   count_db,k;
char  outputf[21];
$char userid[11];
$char DBName[05];
$char msgbuf[128];
$char ipolicy[21],itmp_policy[21],itag[CA_TAG_NUM],dpolicy[11],fmail_type[11],iofficer[11] ,iroute[21];
$char stmt1[2048];
$char stmt_tmp[1024];

DBinfo *list;
long   rtncode;
char   sApHome[50];

/*--------------------------------------------------------------------*/

main(argc, argv)
int argc;
char **argv;
{
    int rc;

    batchinit();
    strcpy(DBName,    isNULLstr(argv[1]));
    strcpy(userid,    isNULLstr(argv[2]));
    strcpy(dbgn,      isNULLstr(argv[3]));
    strcpy(dend,      isNULLstr(argv[4]));
    strcpy(outputf,   isNULLstr(argv[5]));
    
    
    rc = car344_get_db();
    if (rc != M_CM_OK)
       return rc;
       
    rtncode = getApHome(sApHome);
    if (rtncode < 0)
    {
        EWRITE(userid, M_CM_READ_CONFIG_ERR, "read Config file error!!");
        return FAIL;
    }

    rc = car344_prepare_data();

    if (rc != M_CM_OK)
       return rc;


    /*build report - ����*/
    rc = car344_build();

    if (rc != M_CM_OK) {
       return rc;
    }

}
/*--------------------------------------------------------------------*/
long car344_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }

   if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
      if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
         return M_CM_NOT_DBLIST;
   }

   return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/
long car344_prepare_data()
{
   
   
   strcpy(dbgn_cond,cm_to_infdate(dbgn));
   strcpy(dend_cond,cm_to_infdate(dend));

   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == FALSE)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return FAIL;
   }

   /* Create table car634_tmp1 */
   sprintf_s(stmt_tmp, sizeof stmt_tmp,"create temp table car344_tmp1 "
   "( "
   "  ipolicy     	char(20), "
   "  itmp_policy 	char(20), "
   "  itag 		char(%d), "
   "  dpolicy    	DATE, "
   "  fmail_type	char(10), "
   "  iofficer		char(10), "
   "  iroute		varchar(20) "
   " )with no log;",CA_TAG_NUM-1);
     $PREPARE stmp FROM $stmt_tmp;
     $EXECUTE stmp;

  
    for(k=0;k<count_db;k++)
    {
      	 
	    sprintf_s(stmt1, sizeof stmt1,
	    "SELECT a.ipolicy ,b.itmp_policy ,a.itag,b.dpolicy,"
	    "       decode(b.fmail_type,'1','���H','2','����','3','����','4','����',b.fmail_type),"
	    "       b.iofficer ,a.iroute "
	    "  FROM %s:original_ply a,%s:ori_ply_relation b "
	    " WHERE a.ipolicy = b.ipolicy  "
	    "   AND b.dpolicy >= '01/11/2016' "
	    "   AND b.fout_print = '1' "
	    "   AND b.fmail_type != '0' "
	    "   AND b.dout_trans IS NULL "
	    "   AND b.dpolicy BETWEEN '%s' AND '%s' ",list[k].dbname,list[k].dbname,dbgn_cond,dend_cond); 
	
printf("stmt1[%s]\n\n", stmt1);
	      
	    $PREPARE pre1 FROM $stmt1;
	    $DECLARE cur_pre1 CURSOR for pre1;
	    $OPEN cur_pre1;

	     	while(1)
	      {	
	         	$FETCH cur_pre1 INTO $ipolicy,$itmp_policy,$itag,$dpolicy,$fmail_type,$iofficer,$iroute;
	
	         	if(SQLCODE == SQLNOTFOUND) break;
	
			
	              $INSERT INTO car344_tmp1
	               (ipolicy,itmp_policy,itag,dpolicy,fmail_type,iofficer,iroute)
	               VALUES($ipolicy,$itmp_policy,$itag,$dpolicy,$fmail_type,$iofficer,$iroute);
	        			  
	      }
	      $CLOSE cur_pre1;
	      $FREE cur_pre1;
    }

      return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/


long car344_build()
{
   int rc;
    char    sfilename[81],stitle[1024],stmt[1024];

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(sfilename,"���e�~����[CAR344]");
    strcpy(stitle,"\t�{���N��:car344\���e�~����\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");


    strcat(stitle,"\t�O�渹�X\t�����渹\t���P���X\tñ����\t�l�H�覡\t�g��N��\t�q���N��\t");
    strcpy(stmt,"select ipolicy,itmp_policy,itag,dpolicy,fmail_type,iofficer,iroute "
    		 "from car344_tmp1");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);

    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;

    }

    return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}
