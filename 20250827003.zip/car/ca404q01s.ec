/*********************************************
 * Copyright (C) 1993 Intellisys Corporation
 *
 * Program : ca404q01s.ec (Type Block 1)
 *
 *********************************************/
#include <stdio.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"

#include "carmsgs.h" 
#include "commsgs.h" 
#include "gls_array.h" 
#include "gls_const.h"
$include "gls_for_ins.h";

struct GLS_FOR_INS *get_gls_for_ins();  /*1080912006_SC2 �s�Wñ��������ˮ�*/

#define NEXTPAGE   7

$char  BodyFmt[N_FILE+1];
$char  TitleFmt[N_FILE+1];
$int   TotColumn;
$int   StartRow,TitleRow;
$int   ItemRow, PgLine, Width;

char   SysTm[N_TM+1];
char   BodyFile[2][N_FILE+1];
char   TitleFile[2][N_FILE+1];
char   outputf[N_FILE+1];

int    TotRows;
int    linenum;
int    IsBusiness;
int    flag_check=0;
int    max_count[2];

char  buf[80];
$char dptbgn[BRANCH_ID], dptend[BRANCH_ID], plydate[YYYMMDD], strPlyDate[YYYMMDD];
$char sIbranchIcomp[CA_POL_BRH_NUM+1];
$char dbname[BRANCH_ID], nchi_abv[13];
char  option;
char   ctype[1],addname[1];
$char  ipolicy[POLICY_NUM_1],iendorse[ENDORSE_NUM];
$char  iofficer[EMPLOYEE_ID];
$char  nassured[9],iquota[7],nbranch[9];
int    itype,iacc;
$char  pre_branch[3],iacc_type[3],iacc_name[4];
$char  inf_plydate[YYYYMMDD];

$long  dply_long;
$long  mply_prem,mpure_prem,mextra_charge,minu_prem;
$double pextra_charge;
$long  subtract_prem[5],subtract_self[2],subtract_busi[2];
$long  brk_subtract_prem[5],brk_subtract_self[2],brk_subtract_busi[2];
$long  tot_subtract_prem[5],tot_subtract_self[2],tot_subtract_busi[2];
$long  dtl_mply_prem[5],dtl_mpure_prem[5],dtl_mextra_charge[5];
$long  brk_mply_prem[5],brk_mpure_prem[5],brk_mextra_charge[5];
$long  tot_mply_prem[5],tot_mpure_prem[5],tot_mextra_charge[5];
$long  dtl_self_ply[2],dtl_self_pure[2],dtl_self_extra[2];
$long  dtl_busi_ply[2],dtl_busi_pure[2],dtl_busi_extra[2];
$long  brk_self_ply[2],brk_self_pure[2],brk_self_extra[2];
$long  brk_busi_ply[2],brk_busi_pure[2],brk_busi_extra[2];
$long  tot_self_ply[2],tot_self_pure[2],tot_self_extra[2];
$long  tot_busi_ply[2],tot_busi_pure[2],tot_busi_extra[2];

/* standard defined local data */
$char DBName[DBNAME];
char userid[USER_ID];
$char FormTp[3];
long rtncode;
int  i;
/* end of standard defined data */
static long DiffMonth();

/*************************************************************************/

void ca404_cvBusiness(f,s)
char *f, *s;
{
    strcpy(s,"");

    if (isalpha(f[0]))
    {
      switch (f[0])
      {
        case 'A':
                strcpy(s,"�g��");
                strcat(s,"-");
                strcat(s,f);
                break;
        case 'B':
                strcpy(s,"����");
                strcat(s,"-");
                strcat(s,f);
                break;
      }
    }
    else
    {
      switch (atoi(f))
      {
        case 1:
                strcpy(s,"���P");
                strcat(s,"-");
                strcat(s,f);
                break;

        case 2:
                strcpy(s,"�L��");
                strcat(s,"-");
                strcat(s,f);
                break;

        case 5:
                strcpy(s,"�@��");
                strcat(s,"-");
                strcat(s,f);
                break;

        case 3:
        case 4:
        case 6:
        case 7:
        case 8:
        case 9:
                strcpy(s,"���B");
                strcat(s,"-");
                strcat(s,f);
                break;
      }
    }
}

/*************************************************************************/
void ca404_cvProtect(f,s)
char *f, *s;
{
    strcpy(s,"");

    if (isalpha(f[0]))
    {
      switch (f[0])
      {
        case 'A':
                strcpy(s,"�g��");
                strcat(s,"-");
                strcat(s,f);
                break;
        case 'B':
                strcpy(s,"����");
                strcat(s,"-");
                strcat(s,f);
                break;
      }
    }
    else
    {
      switch (atoi(f))
      {
        case 1:
                strcpy(s,"���P");
                strcat(s,"-");
                strcat(s,f);
                break;

        case 3:
        case 4:
        case 6:
        case 7:
        case 8:
        case 9:
                strcpy(s,"���B");
                strcat(s,"-");
                strcat(s,f);
                break;
      }
    }
}

/*************************************************************************/
main(argc,argv)
int argc;
char **argv;
{
    int   rc;    

    batchinit();
    strcpy(DBName,         isNULLstr(argv[1]));
    strcpy(userid,         isNULLstr(argv[2]));
    strcpy(plydate,        isNULLstr(argv[3]));
    strcpy(sIbranchIcomp,  isNULLstr(argv[4]));
    strcpy(ctype,          isNULLstr(argv[5]));
    strcpy(outputf,        isNULLstr(argv[6]));
    strcpy(sIbranchIcomp,  trim(sIbranchIcomp));
    strcat(sIbranchIcomp,  "*");
    itype=atoi(ctype);
    strcpy(addname,"");

    strcpy(inf_plydate,cm_to_infdate(plydate));
    strcpy(strPlyDate,plydate);

    rc=car404_get_db();
    if (rc != M_CM_OK)
    {
        EWRITE(userid,rc," ");
        return rc;
    }

    if (itype==1 || itype==0)
    {
        rc=car404_build();
        if (rc != M_CM_OK) {
            EWRITE(userid,rc," ");
            return rc;
        }
    }

    itype=atoi(ctype);

    if (itype==2 || itype==0)
    {
        rc=car404_build1();
        if (rc != M_CM_OK)
        {
            EWRITE(userid,rc," ");
            return rc;
        }
    }
} 

/**********************************************************************/
long car404_get_db()
{
    if (db_select(DBName) == False) {
        EWRITE(userid,M_CM_DB_NOTOPEN,"M_CM_DB_NOTOPEN");
        return M_CM_DB_NOTOPEN;
    }
    strcpy(dbname,DBName);
    dbname[2]='\0';
    return M_CM_OK;
}
/**********************************************************************/
long car404_build()
{
    int    i=0,j,rc;
    long   rtncode;
    $char  yy[YYY], mm[MM], dd[DD];
    $char  fname[101];

    $WHENEVER SQLERROR GOTO errexit;

    $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
            kTot_Col, kPgNum_Line, kWidth, iForm_Tp
       INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow, $ItemRow ,
            $TotColumn, $PgLine, $Width, $FormTp
       FROM Form
      WHERE ksys_grp="CA" AND kPgmID = 404 AND iForm_Tp = "1";

    strcpy(TitleFmt,rtrim(TitleFmt));
    strcpy(BodyFmt,rtrim(BodyFmt));

    /* For Business */
    IsBusiness = 1;

    sprintf(TitleFile[0],"%sA.ti",outputf);
    sprintf(BodyFile[0],"%sA.bd",outputf);

    rgu_init_report(TitleFmt,TitleFile[0]);
    car404_title();
    rgu_finish_report();

    rgu_init_report(BodyFmt,BodyFile[0]);
    rtncode=car404_body();
    if (rtncode != M_CM_OK) return rtncode;
    rgu_finish_report();
    max_count[0] = TotRows;

    /* For Protect */
    IsBusiness = 0;

    sprintf(TitleFile[1],"%sB.ti",outputf);
    sprintf(BodyFile[1],"%sB.bd",outputf);

    rgu_init_report(TitleFmt,TitleFile[1]);
    car404_title();
    rgu_finish_report();

    rgu_init_report(BodyFmt,BodyFile[1]);
    rtncode=car404_body();
    if (rtncode != M_CM_OK) return rtncode;
    rgu_finish_report();
    max_count[1] = TotRows;

    create_sign_form("car404",BodyFile[0],Width);
    create_sign_form("car404",BodyFile[1],Width);

    sprintf(buf, "%sA", outputf);
    if((rc=save_form_info(F_BLK0,"CA",404,userid,FormTp,max_count[0],outputf))<0)
    {
        printf("[1.rc:%ld]\n", rc);
        EWRITE(userid,rc,"save_form_info failed");
        return rc;
    }

    cm_split_ymd_100(strPlyDate,yy,mm,dd);

    printf("strPlyDate[%s]\n",strPlyDate);
    sprintf(fname,"���N_���_%s%s%s",yy,mm,dd);
    printf("car403_build1:fname[%s]\n",fname);
    gen_filename(outputf,"A",fname);

    sprintf(buf, "%sB", outputf);
    if((rc=save_form_info(F_BLK0,"CA",404,userid,FormTp,max_count[1],outputf))<0)
    {
        printf("[2.rc:%ld]\n", rc);
        EWRITE(userid,rc,"save_form_info failed");
        return rc;
    }

    printf("strPlyDate[%s]\n",strPlyDate);
    sprintf(fname,"���N_���_%s%s%s",yy,mm,dd);
    printf("car403_build1:fname[%s]\n",fname);
    gen_filename(outputf,"B",fname);

    return M_CM_OK;

errexit:
    return SQLCODE;
} 

/**********************************************************************/
long car404_build1()
{
    int    i=0,j,rc;
    long   rtncode;
    $char  fname[101];
    $char  yy[YYY], mm[MM], dd[DD];

    $WHENEVER SQLERROR GOTO errexit;

    $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
            kTot_Col, kPgNum_Line, kWidth, iForm_Tp
       INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow, $ItemRow ,
            $TotColumn, $PgLine, $Width, $FormTp
       FROM Form
      WHERE ksys_grp="CA" AND kPgmID = 404 AND iForm_Tp = "2";

    strcpy(TitleFmt,rtrim(TitleFmt));
    strcpy(BodyFmt,rtrim(BodyFmt));

    if (itype==0) strcpy(addname,"C");

    sprintf(TitleFile[0],"%s%s.ti",outputf,addname);
    sprintf(BodyFile[0],"%s%s.bd",outputf,addname);

    rgu_init_report(TitleFmt,TitleFile[0]);
    car404_title1();
    rgu_finish_report();

    rgu_init_report(BodyFmt,BodyFile[0]);
    rtncode=car404_body1();
    if (rtncode != M_CM_OK) return rtncode;
    rgu_finish_report();
    max_count[0] = TotRows;

    create_sign_form("car404",BodyFile[0],Width);

    if((rc=save_form_info(F_BLK1,"CA",404,userid,FormTp,max_count[0],outputf))<0)
    {
        EWRITE(userid,rc,"save_form_info failed");
        return rc;
    }

    printf("strPlyDate[%s]\n",strPlyDate);
    cm_split_ymd_100(strPlyDate,yy,mm,dd);
    sprintf(fname,"���N_���[�~�ȥ�]_%s%s%s",yy,mm,dd);
    printf("car403_build1:fname[%s]\n",fname);
    gen_filename(outputf,"C",fname);

    return M_CM_OK;

errexit:
    return SQLCODE;
} 

/**********************************************************************/
long car404_title()
{
    $char yy[YYY], mm[MM], dd[DD];
    $char  tmp_yy[YYY];
    long currdt;
    $long dclosing,plydate_l, iyy;
    $char ivoucher[GL_VCHR_NO];
    char  sub_title[30];

    $WHENEVER SQLERROR GOTO errexit;

    memcpy(yy,plydate,3); yy[3] = '\0';
    memcpy(mm,(plydate+4),2); mm[2] = '\0';
    memcpy(dd,(plydate+7),2); dd[2] = '\0';

    if (IsBusiness == 1)
        rgu_put_head_string(1,"�~�ȥ�");
    else
        rgu_put_head_string(1,"�]�ȥ�");

    strncpy( tmp_yy, &yy[1],2);
    tmp_yy[2] = '\0';
    strcpy( yy, tmp_yy);
    printf("yy[%s]\n", yy);

     $SELECT dlast_closing,ivoucher
        INTO $dclosing, $ivoucher
        FROM last_daily_close
       WHERE ibill_type="CA2"
         AND iyear=$yy;

   $SELECT first 1 kcracc_num_tot
      INTO $ivoucher
      FROM gl_vchrxn_sub
     WHERE kcracc_num = $ivoucher AND isub = $DBName;

     plydate_l=cm_ymd_cdate(plydate);

     if (dclosing< plydate_l)
     {
          flag_check=1;
          rgu_put_head_string(1, "(�ˮ֥�)");
     } else if (dclosing == plydate_l) {
          strcpy(sub_title, "(�s�����X:");
          strcat(sub_title, ivoucher);
          trim_tail_white(sub_title);
          strcat(sub_title, ")");
          rgu_put_head_string(1, sub_title);
     } else {
          rgu_put_head_string(1, "(�ɵo��)");
     }

     $SELECT nchi_abv INTO $nchi_abv FROM branch
       WHERE ibranch = $dbname;

    strcpy(SysTm,cm_sysd_cdatetime_100(cm_get_sysd()));

    rgu_put_head_string(1,SysTm);
    rgu_put_head_string(1,dbname);
    rgu_put_head_string(1,nchi_abv);

    rgu_put_head_string(1,yy) ;
    rgu_put_head_string(1,mm) ;
    rgu_put_head_string(1,dd) ;

    rgu_put_head();

    return M_CM_OK;

errexit:
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/**********************************************************************/
long car404_title1()
{
    $char yy[YYY], mm[MM], dd[DD];
    $char  tmp_yy[YYY];
    long currdt;
    $long dclosing,plydate_l, iyy;

    $WHENEVER SQLERROR GOTO errexit;

    memcpy(yy,plydate,3); yy[3] = '\0';
    memcpy(mm,(plydate+4),2); mm[2] = '\0';
    memcpy(dd,(plydate+7),2); dd[2] = '\0';

    strncpy( tmp_yy, &yy[1],2);
    tmp_yy[2] = '\0';
    strcpy( yy, tmp_yy);
    printf("yy[%s]\n", yy);

     $SELECT dlast_closing
        INTO $dclosing
        FROM last_daily_close
       WHERE ibill_type="CA2"
         AND iyear=$yy;

     plydate_l=cm_ymd_cdate(plydate);

     if (dclosing< plydate_l)
     {
          flag_check=1;
          rgu_put_head_string(1, "(�~���ˮ֥�)");
     } else {
          rgu_put_head_string(1, "(�~�ȥ�)");
     }

    strcpy(SysTm,cm_sysd_cdatetime_100(cm_get_sysd()));

    rgu_put_head_string(1,SysTm);

    rgu_put_head_string(1,yy) ;
    rgu_put_head_string(1,mm) ;
    rgu_put_head_string(1,dd) ;

    rgu_put_head();

    return M_CM_OK;

errexit:
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/*************************************************************************/
long car404_body()
{       
     $char ipolicy[POLICY_NUM_1],icard[CARD_NUM],fcard_class[2];
     $char iofficer[EMPLOYEE_ID],ibroker[BROKER],icashier[EMPLOYEE_ID];
     $char nassured[ASSURED_NAME],icar_type[CA_CAR_TYPE_NUM];
     $char iendorse[ENDORSE_NUM],fedr_class[2];
     $char dpolicy[YYYYMMDD], ply_bgn[YYYMMDD], ply_end[YYYMMDD];
     $date qply_begin,qply_end;
     $long mdmg_prem,mdmg_commi,mdmg_agent,mlia_prem,mlia_commi,mlia_agent;
     $long mdmg_discount,mlia_discount;
     $long sum1,sum2;
     $long dataline[17],pagesum[15],pos_sum[15],neg_sum[15];
     $int  qserial, medrdmg_cover;
     int   dmg_cover;
     char  typestr[5],buffer[21],abn_brk[4];
     char  pstr1[5],pstr2[4],pstr3[8];
     char  yy[YYY],mm[MM],dd[DD],ch1[14];
     $double mpure_prem_33;
     $long lDpolicy;

     $char  iins_type[7];
     $long  medrins_prem,medr_commission,medr_agent,medr_discount;
     $char  iproduct[13];
     $char  kclsfyitem[5];
     $char  kreserve[6];
     $long  qply_period;
     $long  total_prem,total_agent,total_commi,total_disc;
     $char  ncode[20];
     $char  pos_neg[3];

     int    i, j, totcnt;
     $int   count;
     $char  where_stat[50];
     $char  stmt_buf[2048];
     long   rtncode;
     $char  provision[21];
     $char  sFull[31], branch[3], stmt1[512], drate_ym[5];

     /*1080912006_SC2 �s�Wñ��������ˮ�*/
     char   v_sMsg[3000];
     $char  gl_kacctitem[5],gl_kclsfyitem[5],gl_eacc_title[41];
     $long  gl_mdeal,tot_mdeal,lDiff_ca_gl;
     $int   gl_iseq;
     

     $WHENEVER SQLERROR GOTO errexit;

     /*1080912006_SC2 �s�Wñ��������ˮ�*/ 
     $EXECUTE IMMEDIATE "DROP TABLE IF EXISTS tmp_gl_list";
     $CREATE TEMP TABLE tmp_gl_list
     (
         iseq        INTEGER         default 0,
         kacctitem   CHAR(4),
         kclsfyitem  CHAR(4),
         eacc_title  CHAR(40),
         tot_mdeal   DECIMAL(15,0)    default 0,
         mdeal       DECIMAL(15,0)    default 0
     ) with no log;
     $CREATE INDEX tmp_gl_idx ON tmp_gl_list (kclsfyitem);
     gl_mdeal=0;gl_iseq = 0;tot_mdeal=0;
     strcpy(gl_kacctitem,"");
     strcpy(gl_kclsfyitem,"");
     strcpy(gl_eacc_title,"");      
     IfirstGlsForIns = get_gls_for_ins(inf_plydate, "C", "E", &rtncode, v_sMsg);
     if( rtncode != M_CM_OK) return rtncode;
     
     IcurrGlsForIns = IfirstGlsForIns;
     
     while( IcurrGlsForIns)
     {
         printf("iseq[%d]kacctitem    [%s],"
                "kclsfyitem   [%s],"
                "eacc_title   [%s],"
                "mdeal        [%ld]\n",gl_iseq,
                 IcurrGlsForIns->kacctitem,
                 IcurrGlsForIns->kclsfyitem,
                 IcurrGlsForIns->eacc_title,
                 IcurrGlsForIns->mdeal);
                 
         strcpy(gl_kacctitem,IcurrGlsForIns->kacctitem);
         strcpy(gl_kclsfyitem,IcurrGlsForIns->kclsfyitem);
         strcpy(gl_eacc_title,IcurrGlsForIns->eacc_title);
         gl_mdeal =IcurrGlsForIns->mdeal;
         
         
         $INSERT INTO tmp_gl_list (iseq,kacctitem,kclsfyitem,eacc_title,mdeal)
               VALUES ($gl_iseq,  $gl_kacctitem,  $gl_kclsfyitem,  $gl_eacc_title,  $gl_mdeal);
         gl_iseq++;             
         IcurrGlsForIns = IcurrGlsForIns->next;
     }


     /*------initialize------*/
     TotRows=0;
     linenum=0;
     totcnt=0;

     for (j=0; j<15; j++)
     {
          dataline[j] = 0;
          pagesum[j]  = 0;
          pos_sum[j]  = 0;
          neg_sum[j]  = 0;
     }
     /*----------------------*/

     strcpy(dpolicy,cm_to_infdate(plydate));
     strcpy(abn_brk,"   ");

     stmt_buf[0] = '\0';
     where_stat[0] = '\0';
     if (flag_check == 1)   /*** ���ˮ֥� ***/
     {
          where_stat[0] = '\0';
     }
     else
     {
          strcpy(where_stat, "AND a.dedr_close is not null ");
     }

      $DECLARE sscur CURSOR FOR
        SELECT branch
          FROM servertbl
         WHERE branch != 'S1'
         ORDER BY branch;
      $OPEN sscur;
      for(;;)
      {
      $FETCH sscur INTO $branch;
       if (SQLCODE == SQLNOTFOUND) break;
       strcpy(sFull,get_full_dbname(branch));

     sprintf(stmt_buf, "SELECT a.ipolicy, a.medrdmg_prem, a.medrdmg_commi, a.medrdmg_agent,"
                       "       a.medrlia_prem, a.medrlia_commi, a.medrlia_agent,"
                       "       a.medrdmg_disc,a.medrlia_disc,"
                       "       a.medrdmg_pure_prem,a.medrlia_pure_prem,"
                       "       a.iofficer,"
                       "       a.ibroker, a.iedr_cashier, a.dedr_begin, a.dedr_end,"
                       "       b.nassured, a.icar_type, a.icard, a.iendorse, a.fedr_class, c.dpolicy "
                       "  FROM %s:edr_relation a , %s:endorsement b , %s:ori_ply_relation c "
                       " WHERE a.fcard_class = '2' "
                       "   AND a.dendorse = ? "
                       "   AND b.iendorse = a.iendorse "
                       "   AND a.ipolicy = c.ipolicy "
                       "   AND a.iendorse MATCHES ? "
                       " %s "
                       "ORDER BY a.iendorse, a.ipolicy", sFull, sFull, sFull, where_stat);

     $PREPARE CUR_STMT FROM $stmt_buf;
     $DECLARE X2 CURSOR FOR CUR_STMT;
     $OPEN X2 USING $dpolicy , $sIbranchIcomp;
     /*printf("[%s]\n", sIbranchIcomp);*/
     printf("stmt_buf[%s]\n",stmt_buf);
     for (;;)
     {
           $FETCH X2
             INTO $ipolicy,$dataline[1],$dataline[2],$dataline[3],
                  $dataline[5],$dataline[6],$dataline[7],
                  $dataline[0],$dataline[4],
                  $dataline[15],$dataline[16],
                  $iofficer,
                  $ibroker,$icashier,$qply_begin,$qply_end,
                  $nassured,$icar_type,$icard,$iendorse,$fedr_class,$lDpolicy;
           if (SQLCODE == SQLNOTFOUND) break;

           /* �P�_�u�f���B�O�_��ܨíp�� */
           if (lDpolicy >= cm_ymd_cdate("91/04/01"))
           {
               dataline[0]=0;
               dataline[4]=0;
           }

           /* ���H�«O�O���P�_ ***************
           if (dataline[15]!=0) dataline[0]=0;
           if (dataline[16]!=0) dataline[4]=0;
           **********************************/

           sprintf( stmt1, "select medr_discount,medrins_prem,medr_commission,medr_agent,medrpure_prem"
                           "  from %s:edr_ins_type"
                           " where iendorse = ?" 
                           "   and iins_type = '33'", sFull);
           $PREPARE prep1 FROM $stmt1;
           $EXECUTE prep1 into $dataline[8],$dataline[9],$dataline[10],$dataline[11],$mpure_prem_33 USING $iendorse;

           if (SQLCODE==SQLNOTFOUND)
               dataline[8]=dataline[9]=dataline[10]=dataline[11]=0;
           $FREE prep1;

           if (mpure_prem_33 != 0) dataline[8] = 0;

           for(j=0;j<4;j++)
           {
               dataline[4+j]-=dataline[8+j];
           }

           if (IsBusiness==0) {
               /* car9602053 ���s�W���N�I�L�����O */
               if (fedr_class[0] !='1' && fedr_class[0] !='3' &&
                   fedr_class[0] !='4' && fedr_class[0] !='6' &&
                   fedr_class[0] !='7' && fedr_class[0] !='9' &&
                   fedr_class[0] !='8' &&
                   fedr_class[0] !='A' && fedr_class[0] != 'B')
                   continue;
           }

           if (((linenum >= MAXPGROW-3) ||
               strncmp( abn_brk,&iendorse[4],3) != 0) &&
              (strncmp( abn_brk,"   ", 3) != 0))
           {
               rgu_put_body(3);

               /*  page total */
               for (j=0; j<12; j++)
               {
                    if (j==1 || j==5 || j==9)
                    {
                        rfmtlong(pagesum[j],"---,---,--&",buffer);
                        rgu_put_body_string(4,buffer,RIGHT);
                    }
                    else if (j==3 || j==7 || j==11)
                    {
                        rfmtlong(pagesum[j],"-,---,--&",buffer);
                        rgu_put_body_string(4,buffer,RIGHT);
                    }
                    else if (j==0 || j==4 || j==8)
                    {
                        rfmtlong(pagesum[j],"--&",buffer);
                        rgu_put_body_string(4,buffer,RIGHT);
                    }
                    else
                    {
                        rfmtlong(pagesum[j],"-,---,--&",buffer);
                        rgu_put_body_string(4,buffer,RIGHT);
                    }
               }

               rfmtlong(pagesum[0]+pagesum[4]+pagesum[8],"--&",buffer);
               rgu_put_body_string(4,buffer,RIGHT);

               rfmtlong(pagesum[1]+pagesum[5]+pagesum[9],"---,---,--&",buffer);
               rgu_put_body_string(4,buffer,RIGHT);

               rfmtlong(pagesum[2]+pagesum[6]+pagesum[10],"-,---,--&",buffer);
               rgu_put_body_string(4,buffer,RIGHT);

               rfmtlong(pagesum[3]+pagesum[7]+pagesum[11],"---,--&",buffer);
               rgu_put_body_string(4,buffer,RIGHT);
               rgu_put_body(4);

               for (j=0; j<14; j++) pagesum[j] = 0;
               rgu_put_body(3);

               rgu_put_body(NEXTPAGE);

               TotRows += 3;
               linenum = 0;
               strncpy(abn_brk, &iendorse[4], 3);
           }
           else
           {
               linenum++;
               totcnt++;
           }

           /* _CC body data */
           if (IsBusiness)
               ca404_cvBusiness(fedr_class,typestr);
           else
               ca404_cvProtect(fedr_class,typestr);

           strncpy(ch1,ipolicy,18);
           ch1[18]='\0';
           rgu_put_body_string( 2,ch1,LEFT);   /*1*/

           strncpy(ch1,iendorse,14);
           ch1[14]='\0';
           rgu_put_body_string( 2,ch1,LEFT);   /*3*/

           strncpy(buffer,nassured,12);
           buffer[12]='\0';
           rgu_put_body_string(2,buffer,LEFT);    /*4*/

           rgu_put_body_string(2,typestr,LEFT);   /*5*/
           rgu_put_body_string(2,ibroker,LEFT);   /*7*/

           strcpy(ply_bgn,cm_cdate_str_100(qply_begin));
           rgu_put_body_string(2,ply_bgn,LEFT);   /*8*/

           strcpy(ply_end,cm_cdate_str_100(qply_end));
           rgu_put_body_string(2,ply_end,LEFT);   /*9*/

           for (j=0; j<12; j++)
           {
                if (j==1 || j==5 || j==9 )
                    rfmtlong(dataline[j],"--,---,--&",buffer);
                else if (j==0 || j==4 || j==8 )
                    rfmtlong(dataline[j],"--&",buffer);
                else
                    rfmtlong(dataline[j],"---,--&",buffer);
                rgu_put_body_string(2,buffer,RIGHT);
                pagesum[j] += dataline[j];
           }

           rfmtlong(dataline[0]+dataline[4]+dataline[8],"--&",buffer);
           rgu_put_body_string(2,buffer,RIGHT);

           rfmtlong(dataline[1]+dataline[5]+dataline[9],"--,---,--&",buffer);
           rgu_put_body_string(2,buffer,RIGHT);

           rfmtlong(dataline[2]+dataline[6]+dataline[10],"---,--&",buffer);
           rgu_put_body_string(2,buffer,RIGHT);

           rfmtlong(dataline[3]+dataline[7]+dataline[11],"-,---,--&",buffer);
           rgu_put_body_string(2,buffer,RIGHT);

           rgu_put_body_string(2,iofficer,LEFT);
           rgu_put_body(2);

           /*-------------------------positive,negative-----*/
           for(j=0;j<12;j++) {
               if (dataline[j] >= 0)
                   pos_sum[j] += dataline[j];
               if (dataline[j] < 0)
                   neg_sum[j] += dataline[j];
           }
           /*--------------------------------------*/
           TotRows++;
     }
     $CLOSE X2;

     /* rgu_put_body(3); */
     TotRows++;

      }
      $CLOSE sscur;
      $FREE  sscur;

     /*  page total */
     for (j=0; j<12; j++)
     {
          if (j==1 || j==5 || j==9)
          {
              rfmtlong(pagesum[j],"---,---,--&",buffer);
              rgu_put_body_string(4,buffer,RIGHT);
          }
          else if (j==3 || j==7 || j==11)
          {
              rfmtlong(pagesum[j],"-,---,--&",buffer);
              rgu_put_body_string(4,buffer,RIGHT);
          }
          else if (j==0 || j==4 || j==8)
          {
              rfmtlong(pagesum[j],"--&",buffer);
              rgu_put_body_string(4,buffer,RIGHT);
          }
          else
          {
              rfmtlong(pagesum[j],"-,---,--&",buffer);
              rgu_put_body_string(4,buffer,RIGHT);
          }
     }

     rfmtlong(pagesum[0]+pagesum[4]+pagesum[8],"--&",buffer);
     rgu_put_body_string(4,buffer,RIGHT);

     rfmtlong(pagesum[1]+pagesum[5]+pagesum[9],"---,---,--&",buffer);
     rgu_put_body_string(4,buffer,RIGHT);

     rfmtlong(pagesum[2]+pagesum[6]+pagesum[10],"-,---,--&",buffer);
     rgu_put_body_string(4,buffer,RIGHT);

     rfmtlong(pagesum[3]+pagesum[7]+pagesum[11],"-,---,--&",buffer);
     rgu_put_body_string(4,buffer,RIGHT);
     rgu_put_body(4);

     rgu_put_body(3);
     TotRows += 2;

     /*  branch total */
     /*--------------------------positive------*/
     for (j=0; j<12; j++)
     {
          if (j==1 || j==5 || j==9)
          {
              rfmtlong(pos_sum[j],"---,---,--&",buffer);
              rgu_put_body_string(5,buffer,RIGHT);
          }
          else if (j==3 || j==7 || j==11)
          {
              rfmtlong(pos_sum[j],"-,---,--&",buffer);
              rgu_put_body_string(5,buffer,RIGHT);
          }
          else if (j==0 || j==4 || j==8)
          {
              rfmtlong(pos_sum[j],"--&",buffer);
              rgu_put_body_string(5,buffer,RIGHT);
          }
          else
          {
              rfmtlong(pos_sum[j],"-,---,--&",buffer);
              rgu_put_body_string(5,buffer,RIGHT);
          }
     }

     rfmtlong(pos_sum[0]+pos_sum[4]+pos_sum[8],"--&",buffer);
     rgu_put_body_string(5,buffer,RIGHT);

     rfmtlong(pos_sum[1]+pos_sum[5]+pos_sum[9],"---,---,--&",buffer);
     rgu_put_body_string(5,buffer,RIGHT);

     rfmtlong(pos_sum[2]+pos_sum[6]+pos_sum[10],"-,---,--&",buffer);
     rgu_put_body_string(5,buffer,RIGHT);

     rfmtlong(pos_sum[3]+pos_sum[7]+pos_sum[11],"-,---,--&",buffer);
     rgu_put_body_string(5,buffer,RIGHT);
     rgu_put_body(5);

     /*--------------------------negative------*/
     for (j=0; j<12; j++)
     {
          if (j==1 || j==5 || j==9)
          {
              rfmtlong(neg_sum[j],"---,---,--&",buffer);
              rgu_put_body_string(6,buffer,RIGHT);
          }
          else if (j==3 || j==7 || j==11)
          {
              rfmtlong(neg_sum[j],"-,---,--&",buffer);
              rgu_put_body_string(6,buffer,RIGHT);
          }
          else if (j==0 || j==4 || j==8)
          {
              rfmtlong(neg_sum[j],"--&",buffer);
              rgu_put_body_string(6,buffer,RIGHT);
          }
          else
          {
              rfmtlong(neg_sum[j],"-,---,--&",buffer);
              rgu_put_body_string(6,buffer,RIGHT);
          }
     }

     rfmtlong(neg_sum[0]+neg_sum[4]+neg_sum[8],"--&",buffer);
     rgu_put_body_string(6,buffer,RIGHT);

     rfmtlong(neg_sum[1]+neg_sum[5]+neg_sum[9],"---,---,--&",buffer);
     rgu_put_body_string(6,buffer,RIGHT);

     rfmtlong(neg_sum[2]+neg_sum[6]+neg_sum[10],"-,---,--&",buffer);
     rgu_put_body_string(6,buffer,RIGHT);

     rfmtlong(neg_sum[3]+neg_sum[7]+neg_sum[11],"-,---,--&",buffer);
     rgu_put_body_string(6,buffer,RIGHT);
     rgu_put_body(6);
     TotRows += 2;

     rgu_put_body(3);
     TotRows += 1;

     /*������C�L�`����--------------------------*/
     rfmtlong(totcnt,"###,##&",buffer);
     rgu_put_body_string(8,buffer,RIGHT);
     rgu_put_body(8);
     rgu_put_body(3);
     TotRows += 2;

     rgu_put_body(12);
     rgu_put_body(12);
     TotRows += 2;

     /* �̦U�I�ؤ��|�p��l�ؤ��� */
     printf("Begin create temp table CAR404_TMP1\n");
     $CREATE TEMP TABLE CAR404_TMP1
      (
          iendorse     char(20) default ' ',
          kclsfyitem   char(4)  default ' ',
          total_prem   integer  default 0,
          total_commi  integer  default 0,
          total_agent  integer  default 0,
          total_disc   integer  default 0
      ) WITH NO LOG;

     $CREATE TEMP TABLE CAR404_TMP2
      (
          kclsfyitem   char(4)  default ' ',
          pos_neg      char(2)  default ' ',
          total_prem   integer  default 0,
          total_commi  integer  default 0,
          total_agent  integer  default 0,
          total_disc   integer  default 0
      ) WITH NO LOG;


     /*1111205010_SC1 �ץ�car404 ���N�I�����Ӫ��ư��j���I�L�q��, add'CR'*/
     $INSERT INTO CAR404_TMP2
      SELECT distinct kclsfyitem,'��',0,0,0,0
        FROM cm_product_code
       WHERE iins_class = 'C'
         AND iins_type not in  ('21','CR');
/*         AND iins_type <> '21';*/

     $INSERT INTO CAR404_TMP2
      SELECT distinct kclsfyitem,'��',0,0,0,0
        FROM cm_product_code
       WHERE iins_class = 'C'
         AND iins_type not in  ('21','CR');       
/*         AND iins_type <> '21';*/

     stmt_buf[0] = '\0';
     where_stat[0] = '\0';
     if (flag_check == 1)   /*** ���ˮ֥� ***/
     {
          where_stat[0] = '\0';
     }
     else
     {
          strcpy(where_stat, "AND a.dedr_close is not null ");
     }

      $DECLARE aacur CURSOR FOR
        SELECT branch
          FROM servertbl
         WHERE branch != 'S1'
         ORDER BY branch;
      $OPEN aacur;
      for(;;)
      {
	      $FETCH aacur INTO $branch;
	       if (SQLCODE == SQLNOTFOUND) break;
	       strcpy(sFull,get_full_dbname(branch));
	
	     sprintf(stmt_buf, "SELECT a.iendorse,b.iins_type,b.medrins_prem,b.medr_commission,b.medr_agent,b.medr_discount,"
	                       "a.icar_type,d.dply_begin,d.dply_end,c.dpolicy,d.qply_period, provision, b.drate_ym "
	                       " FROM %s:edr_relation a, %s:edr_ins_type b, %s:ori_ply_relation c, %s:endorsement d"
	                       " WHERE a.fcard_class  = '2' "
	                       " AND a.dendorse = ? "
	                       " AND a.iendorse = b.iendorse "
	                       " AND a.iendorse = d.iendorse "
	                       " AND a.ipolicy  = c.ipolicy "
	                       " AND a.iendorse MATCHES ? %s ", sFull, sFull, sFull, sFull, where_stat);
	
	     $PREPARE CUR_STMT FROM $stmt_buf;
	     $DECLARE X9 CURSOR FOR CUR_STMT;
	     $OPEN    X9 USING $dpolicy , $sIbranchIcomp;
	     printf("stmt_buf[%s]\n",stmt_buf);
	     for (;;)
	     {
	         $FETCH X9 INTO $iendorse, $iins_type, $medrins_prem, $medr_commission,$medr_agent,$medr_discount,
	                        $icar_type, $qply_begin, $qply_end, $lDpolicy, $qply_period, $provision, $drate_ym;
	
	         if (SQLCODE == SQLNOTFOUND) break;
	
	         /* �P�_�u�f���B�O�_��ܨíp�� */
	         if (lDpolicy >= cm_ymd_cdate("91/04/01"))
	         {
	              medr_discount = 0;
	         }
	
	         strcpy(iendorse, trim(iendorse));
	         strcpy(iins_type,trim(iins_type));
	         strcpy(icar_type,trim(icar_type));
	
	         /*** qply_period = DiffMonth(qply_end,qply_begin); ***/
	
	         printf("CAR404.0010:[%s][%s][%ld]\n",iins_type,icar_type,qply_period);
	         /* ����|�p��l�� */
	         rtncode = get_product_code_car("C",iins_type,icar_type,qply_period,iproduct,kclsfyitem,kreserve,provision, drate_ym);
	         if (rtncode != M_CM_OK)
	         {
	              return rtncode;
	         }
	
	         if ((medrins_prem != 0) || (medr_commission != 0) || (medr_agent != 0))
	         {
	              $UPDATE CAR404_TMP1
	                  SET total_prem  = total_prem  + $medrins_prem,
	                      total_commi = total_commi + $medr_commission,
	                      total_agent = total_agent + $medr_agent,
	                      total_disc  = total_disc  + $medr_discount
	                WHERE iendorse    = $iendorse
	                  AND kclsfyitem  = $kclsfyitem;
	
	              if (sqlca.sqlerrd[2]==0)
	              {
	                   $INSERT INTO CAR404_TMP1 (iendorse, kclsfyitem,  total_prem,    total_commi,      total_agent, total_disc)
	                                     VALUES ($iendorse,$kclsfyitem, $medrins_prem, $medr_commission, $medr_agent, $medr_discount);
	              }
	         }
	     }
	     $CLOSE X9;
      }
      $CLOSE aacur;
      $FREE  aacur;


     total_prem  = 0;
     total_commi = 0;
     total_agent = 0;
     total_disc  = 0;

     printf("Begin out put data from CAR404_TMP1\n");
     $DECLARE ply11_cur CURSOR FOR
       SELECT iendorse,  kclsfyitem,  total_prem,  total_commi,  total_agent,  total_disc
         INTO $iendorse, $kclsfyitem, $total_prem, $total_commi, $total_agent, $total_disc
         FROM CAR404_TMP1;
     $OPEN    ply11_cur;
     for(;;)
     {
         $FETCH ply11_cur;
         if (SQLCODE == SQLNOTFOUND) break;

         if (total_prem < 0)
         {
              $UPDATE CAR404_TMP2
                  SET total_prem  = total_prem  + $total_prem
                WHERE kclsfyitem  = $kclsfyitem
                  AND pos_neg     = '��';

              if (sqlca.sqlerrd[2]==0)
              {
                   $INSERT INTO CAR404_TMP2 (kclsfyitem, pos_neg, total_prem)
                                     VALUES ($kclsfyitem,'��', $total_prem);
              }
         }

         if (total_prem > 0)
         {
              $UPDATE CAR404_TMP2
                  SET total_prem  = total_prem  + $total_prem
                WHERE kclsfyitem  = $kclsfyitem
                  AND pos_neg     = '��';

              if (sqlca.sqlerrd[2]==0)
              {
                   $INSERT INTO CAR404_TMP2 (kclsfyitem, pos_neg, total_prem)
                                     VALUES ($kclsfyitem,'��', $total_prem);
              }
         }

         if (total_commi < 0)
         {
              $UPDATE CAR404_TMP2
                  SET total_commi = total_commi + $total_commi
                WHERE kclsfyitem  = $kclsfyitem
                  AND pos_neg     = '��';

              if (sqlca.sqlerrd[2]==0)
              {
                   $INSERT INTO CAR404_TMP2 (kclsfyitem, pos_neg, total_commi)
                                     VALUES ($kclsfyitem,'��', $total_commi);
              }
         }

         if (total_commi > 0)
         {
              $UPDATE CAR404_TMP2
                  SET total_commi = total_commi + $total_commi
                WHERE kclsfyitem  = $kclsfyitem
                  AND pos_neg     = '��';

              if (sqlca.sqlerrd[2]==0)
              {
                   $INSERT INTO CAR404_TMP2 (kclsfyitem, pos_neg, total_commi)
                                     VALUES ($kclsfyitem,'��', $total_commi);
              }
         }

         if (total_agent < 0)
         {
              $UPDATE CAR404_TMP2
                  SET total_agent = total_agent + $total_agent
                WHERE kclsfyitem  = $kclsfyitem
                  AND pos_neg     = '��';

              if (sqlca.sqlerrd[2]==0)
              {
                   $INSERT INTO CAR404_TMP2 (kclsfyitem, pos_neg, total_agent)
                                     VALUES ($kclsfyitem,'��', $total_agent);
              }
         }

         if (total_agent > 0)
         {
              $UPDATE CAR404_TMP2
                  SET total_agent = total_agent + $total_agent
                WHERE kclsfyitem  = $kclsfyitem
                  AND pos_neg     = '��';

              if (sqlca.sqlerrd[2]==0)
              {
                   $INSERT INTO CAR404_TMP2 (kclsfyitem, pos_neg, total_agent)
                                     VALUES ($kclsfyitem,'��', $total_agent);
              }
         }

         if (total_disc < 0)
         {
              $UPDATE CAR404_TMP2
                  SET total_disc  = total_disc  + $total_disc
                WHERE kclsfyitem  = $kclsfyitem
                  AND pos_neg     = '��';

              if (sqlca.sqlerrd[2]==0)
              {
                   $INSERT INTO CAR404_TMP2 (kclsfyitem, pos_neg, total_disc)
                                     VALUES ($kclsfyitem,'��', $total_disc);
              }
         }

         if (total_disc > 0)
         {
              $UPDATE CAR404_TMP2
                  SET total_disc  = total_disc  + $total_disc
                WHERE kclsfyitem  = $kclsfyitem
                  AND pos_neg     = '��';

              if (sqlca.sqlerrd[2]==0)
              {
                   $INSERT INTO CAR404_TMP2 (kclsfyitem, pos_neg, total_disc)
                                     VALUES ($kclsfyitem,'��', $total_disc);
              }
         }
         
         /*1080912006_SC2 �s�Wñ��������ˮ�*/
         $UPDATE tmp_gl_list
             set tot_mdeal = tot_mdeal + $total_prem     /* 4100�O�I�O */
           WHERE kacctitem ='4100'
             AND kclsfyitem = $kclsfyitem;

         $UPDATE tmp_gl_list
             set tot_mdeal = tot_mdeal + $total_commi    /* 5101��  �� */
           WHERE kacctitem ='5101'
             AND kclsfyitem = $kclsfyitem;   
             
         $UPDATE tmp_gl_list
             set tot_mdeal = tot_mdeal + $total_agent    /* 5102�N�z�O */
           WHERE kacctitem ='5102'
             AND kclsfyitem = $kclsfyitem;         
     }
     $CLOSE   ply11_cur;
     printf("End of Out put data\n");

     $DROP TABLE CAR404_TMP1;

     total_prem  = 0;
     total_commi = 0;
     total_agent = 0;
     total_disc  = 0;

     /* ���D�C */
     rgu_put_body(9);
     TotRows += 2;

     printf("Begin out put data from CAR404_TMP1\n");
     $DECLARE ply1_cur CURSOR FOR
       SELECT kclsfyitem,  pos_neg,  total_prem,  total_commi,  total_agent,  total_disc
         INTO $kclsfyitem, $pos_neg, $total_prem, $total_commi, $total_agent, $total_disc
         FROM CAR404_TMP2
        ORDER BY kclsfyitem,  pos_neg;
     $OPEN    ply1_cur;
     for(;;)
     {
         $FETCH ply1_cur;
         if (SQLCODE == SQLNOTFOUND) break;

         $SELECT ncode[1,14]
            INTO :ncode
            FROM cu_code_data
           WHERE itype = '30'
             AND icode = $kclsfyitem;

         if (SQLCODE == SQLNOTFOUND)
         {
              strcpy(ncode,kclsfyitem);
         }
         printf("[%s][%s][%ld][%ld][%ld][%ld]\n",kclsfyitem,ncode,total_prem,total_commi,total_agent,total_disc);

         /* �l�ئW�� */
         sprintf(ncode,"%s(%s)",trim(ncode),pos_neg);
         rgu_put_body_string(10, ncode, LEFT);

         /* �u�f */
         /*rfmtlong(total_disc,"---,--&",buffer);
           rgu_put_body_string(10,buffer,RIGHT);*/

         /* �O�O */
         rfmtlong(total_prem,"---,---,--&",buffer);
         rgu_put_body_string(10,buffer,RIGHT);

         /* ���� */
         rfmtlong(total_commi,"-,---,--&",buffer);
         rgu_put_body_string(10,buffer,RIGHT);

         /* �N�z */
         rfmtlong(total_agent,"--,---,---,--&",buffer);
         rgu_put_body_string(10,buffer,RIGHT);

         /* ����O */
         rgu_put_body_string(10,"0",RIGHT);

         rgu_put_body(10);

         TotRows ++;
     }
     $CLOSE   ply1_cur;
     printf("End of Out put data\n");

     $DROP TABLE CAR404_TMP2;

     rgu_put_body(11);
     TotRows ++;

     /*--------------------------total------*/
     rgu_put_body_string(10,"�`�p       ",LEFT);

     rfmtlong(pos_sum[1]+pos_sum[5]+pos_sum[9]+neg_sum[1]+neg_sum[5]+neg_sum[9],"---,---,--&",buffer);/* �O�O */
     rgu_put_body_string(10,buffer,RIGHT);

     rfmtlong(pos_sum[2]+pos_sum[6]+pos_sum[10]+neg_sum[2]+neg_sum[6]+neg_sum[10],"-,---,--&",buffer);   /* ���� */
     rgu_put_body_string(10,buffer,RIGHT);

     rfmtlong(pos_sum[3]+pos_sum[7]+pos_sum[11]+neg_sum[3]+neg_sum[7]+neg_sum[11],"--,---,---,--&",buffer); /* �N�z�O */
     rgu_put_body_string(10,buffer,RIGHT);

     rgu_put_body_string(10,"0",RIGHT);                              /* ����O */
     rgu_put_body(10);
     TotRows ++;

     /*--------------------------negative------*
     rgu_put_body_string(10,"�`�p   (��)",LEFT);
     rfmtlong(neg_sum[1]+neg_sum[5]+neg_sum[9],"---,---,--&",buffer);  * �O�O *
     rgu_put_body_string(10,buffer,RIGHT);

     rfmtlong(neg_sum[2]+neg_sum[6]+neg_sum[10],"---,--&",buffer);     * ���� *
     rgu_put_body_string(10,buffer,RIGHT);

     rfmtlong(neg_sum[3]+neg_sum[7]+neg_sum[11],"-,---,--&",buffer);   * �N�z�O *
     rgu_put_body_string(10,buffer,RIGHT);

     rgu_put_body_string(10,"0",RIGHT);                                * ����O *

     rgu_put_body(10);
     TotRows ++;
     *******************************************/

     /*1111205010_SC1 �ץ�car404 ���N�I�����Ӫ��ư��j���I�L�q��, add 3210,3220,3230*/
     /*1080912006_SC2 �s�Wñ��������ˮ�*/
     gl_mdeal=0;gl_iseq = 0;tot_mdeal=0;lDiff_ca_gl=0;
     strcpy(gl_kacctitem,"");
     strcpy(gl_kclsfyitem,"");
     strcpy(gl_eacc_title,"");
     rgu_put_body(12);                TotRows++;
     rgu_put_body(13);                TotRows+=3;
     printf("*****************************************************************\n");
     $DECLARE gls_cur CURSOR FOR
       SELECT trim(kacctitem),trim(kclsfyitem),trim(eacc_title),abs(tot_mdeal) ,mdeal     ,(abs(tot_mdeal) - mdeal)
         INTO $gl_kacctitem  ,$gl_kclsfyitem  ,$gl_eacc_title  ,$tot_mdeal,$gl_mdeal ,$lDiff_ca_gl
         FROM tmp_gl_list
        WHERE kclsfyitem not in ('1400','1500','1600','1601','3210','3220','3230')
     ORDER BY iseq;
     $OPEN gls_cur;
     for(;;)
     {
          $FETCH gls_cur ;
          printf("kacctitem[%s]",gl_kacctitem);
          printf("kclsfyitem[%s]\n",gl_kclsfyitem);
          printf("gl_mdeal[%ld]\n",gl_mdeal);
          printf("tot_mdeal[%ld]\n",tot_mdeal);
          if (SQLCODE == SQLNOTFOUND) break;
     
         /*�|�p���4100�O�O���J/5103����O��X	�|�p�l��	��l�ئW��	�������B	�`�b���B	�t�B
          �]���^�Ǿ�i�ǲ����ӡA�ݱư��j���I���l��*/
          
          
         rgu_put_body_string(14,gl_kacctitem,1);
         rgu_put_body_string(14,gl_kclsfyitem,1);
         rgu_put_body_string(14,gl_eacc_title,1);
         strcpy(buffer, refmtamt(gl_mdeal,MILLIONTH));
         rgu_put_body_string(14,buffer,1);
         strcpy(buffer, refmtamt(tot_mdeal,MILLIONTH));
         rgu_put_body_string(14,buffer,1);
         strcpy(buffer, refmtamt(lDiff_ca_gl,MILLIONTH));
         rgu_put_body_string(14,buffer,1);
             
         rgu_put_body(14);                TotRows++;
     }
     $CLOSE gls_cur;
     $FREE  gls_cur;
     printf("=================gls================================\n");
     

     return M_CM_OK;

errexit:
     EWRITE(userid,SQLCODE,sqlca.sqlerrm);
     return SQLCODE;
}
/**********************************************************************/
car404_body1()
{
    char   buffer[21];
    $char  stmt_buf1[400];
    int    i, j, first;
    $char where_stat[50];
    $char dpolicy[YYYYMMDD];
    $char sFull[31], branch[3], stmt1[512];

    $WHENEVER SQLERROR GOTO errexit;

    TotRows=linenum=0;
    for(i=0;i<5;i++) {
        subtract_prem[i]=brk_subtract_prem[i]=tot_subtract_prem[i]=0;
        dtl_mply_prem[i]=dtl_mpure_prem[i]=dtl_mextra_charge[i]=0;
        brk_mply_prem[i]=brk_mpure_prem[i]=brk_mextra_charge[i]=0;
        tot_mply_prem[i]=tot_mpure_prem[i]=tot_mextra_charge[i]=0;
       }
    for(i=0;i<2;i++) {
        subtract_self[i]=subtract_busi[i]=0;
        brk_subtract_self[i]=brk_subtract_busi[i]=0;
        tot_subtract_self[i]=tot_subtract_busi[i]=0;
        dtl_self_ply[i]=dtl_self_pure[i]=dtl_self_extra[i]=0;
        dtl_busi_ply[i]=dtl_busi_pure[i]=dtl_busi_extra[i]=0;
        brk_self_ply[i]=brk_self_pure[i]=brk_self_extra[i]=0;
        brk_busi_ply[i]=brk_busi_pure[i]=brk_busi_extra[i]=0;
        tot_self_ply[i]=tot_self_pure[i]=tot_self_extra[i]=0;
        tot_busi_ply[i]=tot_busi_pure[i]=tot_busi_extra[i]=0;
    }

    strcpy(dpolicy,cm_to_infdate(plydate));
    where_stat[0] = '\0';
    if (flag_check == 1)   /*** ���ˮ֥� ***/
    {
         where_stat[0] = '\0';
    }
    else
    {
         strcpy(where_stat, "AND a.dedr_close is not null ");
    }
    strcpy(pre_branch,"  ");

      $DECLARE s1cur CURSOR FOR
        SELECT branch
          FROM servertbl
         WHERE branch != 'S1'
         ORDER BY branch;
      $OPEN s1cur;
      for(;;)
      {
      $FETCH s1cur INTO $branch;
       if (SQLCODE == SQLNOTFOUND) break;
       strcpy(sFull,get_full_dbname(branch));

    /***** prepare cursor for select edr_relation *****/
    sprintf(stmt_buf1,"SELECT a.ipolicy,a.iendorse,a.iofficer,a.iquota[1,4],b.nassured[1,8],c.dpolicy"
                      "  FROM %s:edr_relation a, %s:endorsement b, %s:ply_relation c"
                      " WHERE a.fcard_class='2' AND a.dendorse =? "
                      "   AND a.iendorse MATCHES ? "
                      "   AND a.iendorse = b.iendorse AND a.ipolicy = c.ipolicy %s"
                      " ORDER BY 1", sFull, sFull, sFull, where_stat);
    printf("[%s]\n",stmt_buf1);
    $PREPARE CUR_STMT11 FROM $stmt_buf1;
    $DECLARE scur_ply11 CURSOR FOR CUR_STMT11;

    /***** prepare cursor for select ori_ins_type *****/
    sprintf(stmt_buf1,"SELECT iproduct[4,5],sum(medrins_prem),sum(medrpure_prem) "
                      "  FROM %s:edr_ins_type"
                      " WHERE iendorse =? "
                      " GROUP BY 1", sFull);
    printf("[%s]\n",stmt_buf1);
    $PREPARE CUR_STMT31 FROM $stmt_buf1;
    $DECLARE scur_ply_ins_a11 CURSOR FOR CUR_STMT31;

    /***** start process *****/
    $OPEN scur_ply11 USING $dpolicy, $sIbranchIcomp;

    while(1) {
        $FETCH scur_ply11    /* fetch first data */
        INTO $ipolicy,$iendorse,$iofficer,$iquota,$nassured,$dply_long;
        if(SQLCODE == SQLNOTFOUND) break;

        printf("[%s][%s]\n",ipolicy,iendorse);
        if (strncmp(pre_branch,"  ",2)==0) {
            strncpy(pre_branch,iendorse,2);
            $SELECT nchi_full INTO $nchi_abv FROM branch
              WHERE ibranch = $pre_branch;
            rgu_put_body_string(1,pre_branch,1);
            rgu_put_body_string(1,nchi_abv,1);
            rgu_put_body(1); TotRows++;
        }
        else if (strncmp(pre_branch,iendorse,2)!=0) {
            car404_tot();
            rgu_put_body(NEXTPAGE); TotRows++;
            strncpy(pre_branch,iendorse,2);
            $SELECT nchi_full INTO $nchi_abv FROM branch
              WHERE ibranch = $pre_branch;
            rgu_put_body_string(1,pre_branch,1);
            rgu_put_body_string(1,nchi_abv,1);
            rgu_put_body(1); TotRows++;
        }

        iquota[4]='\0';
        strcat(iquota,"00");
        $select nbranch[1,12] into $nbranch
           from sa_branch_type
          where ibranch = $iquota;

        $OPEN scur_ply_ins_a11 USING $iendorse;
        first=0;
        strcpy(iacc_name," ");
        while(1) {
            $FETCH scur_ply_ins_a11
              INTO $iacc_type,$mply_prem,$mpure_prem;
            if (SQLCODE==SQLNOTFOUND) {
                if (first) car404_dtl();
                break;
            }
            first=1;

            iacc=atoi(iacc_type);
            if (dply_long < 37346) {
                mextra_charge=0;
                minu_prem = mply_prem;
            }
            else {
                mextra_charge=mply_prem - mpure_prem;
                minu_prem = 0;
            }

            if (iacc==10) {
                strcpy(iacc_name,"�ۥ�");
                dtl_mply_prem[0]=dtl_self_ply[0]=mply_prem;
                dtl_mpure_prem[0]=dtl_self_pure[0]=mpure_prem;
                dtl_mextra_charge[0]=dtl_self_extra[0]=mextra_charge;
                subtract_self[0]=subtract_prem[0]=minu_prem;
            }
            if (iacc==11) {
                strcpy(iacc_name,"�ӷ~");
                dtl_mply_prem[0]=dtl_busi_ply[0]=mply_prem;
                dtl_mpure_prem[0]=dtl_busi_pure[0]=mpure_prem;
                dtl_mextra_charge[0]=dtl_busi_extra[0]=mextra_charge;
                subtract_busi[0]=subtract_prem[0]=minu_prem;
            }
            if (iacc==12) {
                strcpy(iacc_name,"�ۥ�");
                dtl_mply_prem[1]=dtl_self_ply[1]=mply_prem;
                dtl_mpure_prem[1]=dtl_self_pure[1]=mpure_prem;
                dtl_mextra_charge[1]=dtl_self_extra[1]=mextra_charge;
                subtract_self[1]=subtract_prem[1]=minu_prem;
            }
            if (iacc==13) {
                strcpy(iacc_name,"�ӷ~");
                dtl_mply_prem[1]=dtl_busi_ply[1]=mply_prem;
                dtl_mpure_prem[1]=dtl_busi_pure[1]=mpure_prem;
                dtl_mextra_charge[1]=dtl_busi_extra[1]=mextra_charge;
                subtract_busi[1]=subtract_prem[1]=minu_prem;
            }
            if (iacc==24) {
                dtl_mply_prem[2]=mply_prem;
                dtl_mpure_prem[2]=mpure_prem;
                dtl_mextra_charge[2]=mextra_charge;
                subtract_prem[2]=minu_prem;
            }
            if (iacc==28) {
                dtl_mply_prem[3]=mply_prem;
                dtl_mpure_prem[3]=mpure_prem;
                dtl_mextra_charge[3]=mextra_charge;
                subtract_prem[3]=minu_prem;
            }
       }
       $close scur_ply_ins_a11;
    }
    $close scur_ply11;
    $free  scur_ply11;
    $free  scur_ply_ins_a11;

      }
      $CLOSE s1cur;
      $FREE  s1cur;

    car404_tot();

    return M_CM_OK;

errexit:
  EWRITE(userid,SQLCODE,sqlca.sqlerrm);
  return ;
}
/*--------------------------------------------------------------------*/
car404_dtl()
{
    int   i;
    char  buf1[20],buf2[20],buf3[20],buf4[20];

    linenum++;
    if (linenum > 50) {
        car404_brk();
        rgu_put_body(NEXTPAGE);
        rgu_put_body_string(1,pre_branch,1);
        rgu_put_body_string(1,nchi_abv,1);
        rgu_put_body(1); TotRows++;
    }
    for(i=0;i<4;i++) {
        dtl_mply_prem[4]+=dtl_mply_prem[i];
        dtl_mpure_prem[4]+=dtl_mpure_prem[i];
        dtl_mextra_charge[4]+=dtl_mextra_charge[i];
        subtract_prem[4]+=subtract_prem[i];
    }
    for(i=0;i<5;i++) {
        brk_mply_prem[i]+=dtl_mply_prem[i];
        brk_mpure_prem[i]+=dtl_mpure_prem[i];
        brk_mextra_charge[i]+=dtl_mextra_charge[i];
        brk_subtract_prem[i]+=subtract_prem[i];
    }
    for(i=0;i<2;i++) {
        brk_self_ply[i]+=dtl_self_ply[i];
        brk_self_pure[i]+=dtl_self_pure[i];
        brk_self_extra[i]+=dtl_self_extra[i];
        brk_busi_ply[i]+=dtl_busi_ply[i];
        brk_busi_pure[i]+=dtl_busi_pure[i];
        brk_busi_extra[i]+=dtl_busi_extra[i];
        brk_subtract_self[i]+=subtract_self[i];
        brk_subtract_busi[i]+=subtract_busi[i];
    }
    rgu_put_body_string(2,ipolicy,1);
    rgu_put_body_string(2,iendorse,1);
    rgu_put_body_string(2,nassured,1);
    rgu_put_body_string(2,nbranch,1);
    rgu_put_body_string(2,iofficer,1);
    rgu_put_body_string(2,iacc_name,1);
    for(i=0;i<5;i++) {
        rfmtlong(dtl_mpure_prem[i], "-------&", buf1);
        rfmtlong(dtl_mextra_charge[i], "-------&", buf2);
        if (dtl_mply_prem[i]==0)
            pextra_charge=0;
        else
            pextra_charge=(double)dtl_mextra_charge[i]/dtl_mply_prem[i] * 100;
        rfmtdouble(pextra_charge, "---.--", buf3);
        rfmtlong(dtl_mply_prem[i], "-------&", buf4);
        rgu_put_body_string(2,buf1,1);
        rgu_put_body_string(2,buf2,1);
        rgu_put_body_string(2,buf3,1);
        rgu_put_body_string(2,buf4,1);
    }
    rgu_put_body(2); TotRows++;
    for(i=0;i<5;i++) {
        dtl_mply_prem[i]=dtl_mpure_prem[i]=dtl_mextra_charge[i]=0;
        subtract_prem[i]=0;
    }
    for(i=0;i<2;i++) {
        dtl_self_ply[i]=dtl_self_pure[i]=dtl_self_extra[i]=0;
        dtl_busi_ply[i]=dtl_busi_pure[i]=dtl_busi_extra[i]=0;
        subtract_self[i]=subtract_busi[i]=0;
    }
}
/*--------------------------------------------------------------------*/
car404_brk()
{
    int   i;
    char  buf1[20],buf2[20],buf3[20],buf4[20];

    for(i=0;i<5;i++) {
        tot_mply_prem[i]+=brk_mply_prem[i];
        tot_mpure_prem[i]+=brk_mpure_prem[i];
        tot_mextra_charge[i]+=brk_mextra_charge[i];
        tot_subtract_prem[i]+=brk_subtract_prem[i];
    }
    for(i=0;i<2;i++) {
        tot_self_ply[i]+=brk_self_ply[i];
        tot_self_pure[i]+=brk_self_pure[i];
        tot_self_extra[i]+=brk_self_extra[i];
        tot_busi_ply[i]+=brk_busi_ply[i];
        tot_busi_pure[i]+=brk_busi_pure[i];
        tot_busi_extra[i]+=brk_busi_extra[i];
        tot_subtract_self[i]+=brk_subtract_self[i];
        tot_subtract_busi[i]+=brk_subtract_busi[i];
    }
    for(i=0;i<5;i++) {
        rfmtlong(brk_mpure_prem[i], "-------&", buf1);
        rfmtlong(brk_mextra_charge[i], "-------&", buf2);
        if (brk_mply_prem[i]==0)
            pextra_charge=0;
        else
            pextra_charge=(double)brk_mextra_charge[i]/
                          (brk_mply_prem[i] - brk_subtract_prem[i]) * 100;
        rfmtdouble(pextra_charge, "---.--", buf3);
        rfmtlong(brk_mply_prem[i], "-------&", buf4);
        rgu_put_body_string(4,buf1,1);
        rgu_put_body_string(4,buf2,1);
        rgu_put_body_string(4,buf3,1);
        rgu_put_body_string(4,buf4,1);
    }
    rgu_put_body(3); TotRows++;
    rgu_put_body(4); TotRows++;
    rgu_put_body(3); TotRows++;
    for(i=0;i<5;i++) {
        brk_mply_prem[i]=brk_mpure_prem[i]=brk_mextra_charge[i]=0;
        brk_subtract_prem[i]=0;
    }
    for(i=0;i<2;i++) {
        brk_self_ply[i]=brk_self_pure[i]=brk_self_extra[i]=0;
        brk_busi_ply[i]=brk_busi_pure[i]=brk_busi_extra[i]=0;
        brk_subtract_self[i]=brk_subtract_busi[i]=0;
    }
    linenum=0;
}
/*--------------------------------------------------------------------*/
car404_tot()
{
    int   i;
    char  buf1[20],buf2[20],buf3[20],buf4[20];

    car404_brk();

    for(i=0;i<5;i++) {
        rfmtlong(tot_mpure_prem[i], "-------&", buf1);
        rfmtlong(tot_mextra_charge[i], "-------&", buf2);
        if (tot_mply_prem[i]==0)
            pextra_charge=0;
        else
            pextra_charge=(double)tot_mextra_charge[i]/
                          (tot_mply_prem[i] - tot_subtract_prem[i]) * 100;
        rfmtdouble(pextra_charge, "---.--", buf3);
        rfmtlong(tot_mply_prem[i], "-------&", buf4);
        rgu_put_body_string(5,buf1,1);
        rgu_put_body_string(5,buf2,1);
        rgu_put_body_string(5,buf3,1);
        rgu_put_body_string(5,buf4,1);
    }
    rgu_put_body(5); TotRows++;

    rgu_put_body_string(6,"�ۥ�" ,1);
    for(i=0;i<2;i++) {
        rfmtlong(tot_self_pure[i], "-------&", buf1);
        rfmtlong(tot_self_extra[i], "-------&", buf2);
        if (tot_self_ply[i]==0 )
            pextra_charge=0;
        else
            pextra_charge=(double)tot_self_extra[i]/
                          (tot_self_ply[i] - tot_subtract_self[i]) * 100;
        rfmtdouble(pextra_charge, "---.--", buf3);
        rfmtlong(tot_self_ply[i], "-------&", buf4);
        rgu_put_body_string(6,buf1,1);
        rgu_put_body_string(6,buf2,1);
        rgu_put_body_string(6,buf3,1);
        rgu_put_body_string(6,buf4,1);
    }
    rgu_put_body(6); TotRows++;
    rgu_put_body_string(6,"��~" ,1);
    for(i=0;i<2;i++) {
        rfmtlong(tot_busi_pure[i], "-------&", buf1);
        rfmtlong(tot_busi_extra[i], "-------&", buf2);
        if (tot_busi_ply[i]==0)
            pextra_charge=0;
        else
            pextra_charge=(double)tot_busi_extra[i]/
                          (tot_busi_ply[i] - tot_subtract_busi[i]) * 100;
        rfmtdouble(pextra_charge, "---.--", buf3);
        rfmtlong(tot_busi_ply[i], "-------&", buf4);
        rgu_put_body_string(6,buf1,1);
        rgu_put_body_string(6,buf2,1);
        rgu_put_body_string(6,buf3,1);
        rgu_put_body_string(6,buf4,1);
    }
    rgu_put_body(6); TotRows++;
    rgu_put_body(3); TotRows++;
    for(i=0;i<5;i++) {
        tot_mply_prem[i]=tot_mpure_prem[i]=tot_mextra_charge[i]=0;
        tot_subtract_prem[i]=0;
    }
    for(i=0;i<2;i++) {
        tot_self_ply[i]=tot_self_pure[i]=tot_self_extra[i]=0;
        tot_busi_ply[i]=tot_busi_pure[i]=tot_busi_extra[i]=0;
        tot_subtract_self[i]=tot_subtract_busi[i]=0;
    }
}

static long DiffMonth(d1,d2)    /* input data should be date format */
long d1, d2;
{
    short mdy1[3], mdy2[3];
    long  datediff=0;

    rjulmdy(d1,mdy1);
    rjulmdy(d2,mdy2);
    datediff=(mdy1[2]*12+mdy1[0])-(mdy2[2]*12+mdy2[0]);
    if (datediff<0) datediff=0;
    return datediff;
}

/*--------------------------------------------------------------------*/
