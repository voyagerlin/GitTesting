/**********************************************************************/
/*   program id   : ca703q01s.ec                                      */
/*   program name : �I�ة��Ӫ�                                        */
/*   date written : 2000/09/19                                        */
/*   author       : Ealex                                             */
/*   files        : ply_relation        i                             */
/*                  policy              i                             */
/*                  ply_ins_type        i                             */
/*                  insurance_type      i                             */
/*   temp table   : car703              io                            */
/**********************************************************************/
/*                             MODIFICATION LOG                        *
 *                                                                     *
 *   DATE         SE                         DESCRIPTION               *
 * --------  -------------  ----------------------------------------   *
 * 20110117  Jessie         �W�[���C�L                               *
 * 20230910  Teru           �W�[���Ĥ���d�߱���                       *
 **********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include "car_equip.h"


/*--------------------------------------------------------------------*/

$char dbgn1[11], dend1[11], dbgn2[11], dend2[11], iins_type[7];
$char Ipolicy[21],Nassured[121],Icar_type[3],Ndeputy_assured[51];
$char Iofficer[11],Ileader[11],Ibig_office[10];
$long Dpolicy,Dply_begin,Dply_end;
$char Mdmg_prem[9],Mlia_prem[9],Mins_premium[9];
$long minjured_cover,mdeath_cover,mdamage_cover;/*�O�B�@�B�O�B�G�B�O�B�T*/
$char Iins_type[7],Nins_type[35],cat_iins_type[11];
$char Nbranch[40],Iquota[10],icode[11],iappl[13],nappl[121],ipro[5],feplychk[2];
char  dtype[2],tit_dtype[9],ctype[2],paycheck[2],rmkcheck[2];
char  ptype[2],icar_type[3],cardclass[2];
$char iissue_ym[7],ipro_year[5],qpro_month[3],iengine[CA_ENGINE_NUM],ibrand[9],nbrand[31];
$char itag[CA_TAG_NUM],itel[21];
$char nofficer[11],ibig_comp[2];
char  fymark[201][4];
$char tcode[17][20];
char  msgbuf[1000];
char provision[52],provision_a[11],provision_b[41];
$char iassured[13];
$char iassured_ext[3];
$char tphone_con[21],imovephone[21];
$char Astmp[256];
$char icard[21],feply[2],aemail_eply[51];
$char iresource[2];
$char ileader[11],nname[11];
$char fedr_class[2],dendorse[20];
$char fassured[2];
$char fedr_status[2],ply_dendorse[20];
$long pdiscount;
$char ncode[30],F_ncode[30];
$char DBName[05], iForm_Tp[03];
$char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1];
char  outputf[N_FILE+1];
$char userid[11], userid2[11];
$char ibig_sales[11],s_name[21];
$char iins_cnt[3];
$char nequipment[31];
$char minjured_cover_c[21],mdeath_cover_c[21],mdamage_cover_c[21];
int   cnt;
$char iremark[3];

$char imgr[2],introducer[21],iroute[21],iroute_accept[21],dpay[21];
$char ntroducer[21],nroute[21];

$char ientry[121],dentry[11],nuser[19],nentry[121];
$char ilast_ply[21], fassured[2], dbirth[11], qpt[6], fpt[2],sDbirth[11];
$char qcylinder[11], fesign[2], iscan_no[26];
$char yy[4],mm[3],dd[3],sIassured[14];
$char Pdmg_acc[6],Plia_acc[6],qlia_acc_sum[5],qdmg_acc_sum[5] , fcard_class[2];
$double mret_prem; /*�ۯd�O�B*/
$char iply_area[5]; /*�ӫO�a�ϥN��*/
$char nply_area[10]; /*�ӫO�a�ϦW��*/

/* AOI ao_chk_charge */
$int  ibatch_no;
char  tmp_ibatch_no[3];
char  ao_policy1[POLICY_NUM_1], ao_policy2[CA_TARGET_NUM];
char  a0result[3], a0comment[31], a0date1[9], a0date2[9];
$char ao_note[2];
$char falldb[2],sIcard_main[21],sFS_ins[4];
extern struct sEquip *IfirstEquip, *IcurrEquip, *IlastEquip, *IEquip_ptr;
char equipdecode[201];

$int ItemRow, TotColumn;
$int StartRow,TitleRow;
$int PgLine, Width;
$int flevel;    /* �ϥμh���v�� add by sylvia 105.11.10 (1051007002_C1) */

$char dvalid1[11], dvalid2[11];   /* 1120910004_C01 �s�W���Ĥ���d�߱���*/

int max_cnt;
int rtncode;
int i,count_db,rnt;
int x;
DBinfo *list;

long car703_build();
long car703_accumulate();
void car703_title();
long car703_body();
void car703_print();
void car703_print_appl();
long car703_email();
char* get_nply_area();

char*   trimx();

$char iins_tmp[128];
int num; /*2017/10/06*/
$char nuser_pt[19];
/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
   int rc;
   int i,m=0,k=0,n;
   char *token;


   batchinit();
   strcpy(DBName,   isNULLstr(argv[1]));
   strcpy(userid2,  isNULLstr(argv[2]));
   strcpy(dbgn2,    isNULLstr(argv[3]));
   strcpy(dend2,    isNULLstr(argv[4]));
   strcpy(dvalid2,  isNULLstr(argv[5]));
   
   strcpy(iins_type,isNULLstr(argv[6]));
   strcpy(dtype,    isNULLstr(argv[7]));
   strcpy(iins_cnt, isNULLstr(argv[8]));
   cnt = atoi(iins_cnt);

   for(i=1;i<201;i++)
   { 

      fymark[i][0]='\0'; 

   }
   printf("-- trace cnt[%d]\n ",cnt);
   for(i=1;i<cnt+1;i++)
   {
     k=8+i;
     strncpy(fymark[i],isNULLstr(argv[k]),3);     
     fymark[i][3]='\0';
     printf("-- trace fymark[%d]=[%s]\n ",i,fymark[i]);
     strcpy(fymark[i] , trim(fymark[i]));
   }
    printf("-- trace k[%d]\n ",k); 
   if ( cnt != 0 )
     m = k + 1;
   else
     m = 9;

   strcpy(ctype,     isNULLstr(argv[m]));
   m++;
   strcpy(icode,     isNULLstr(argv[m]));
   m++;
   strcpy(iappl,     isNULLstr(argv[m]));
   m++;
   strcpy(nappl,     isNULLstr(argv[m]));
   m++;
   strcpy(ipro,      isNULLstr(argv[m]));
   m++;
   strcpy(feplychk,  isNULLstr(argv[m]));
   m++;
   strcpy(paycheck,  isNULLstr(argv[m]));
   m++;
   strcpy(rmkcheck,  isNULLstr(argv[m]));
   m++;
   strcpy(ptype,     isNULLstr(argv[m]));
   m++; 
   strcpy(icar_type, isNULLstr(argv[m]));
   m++;
   strcpy(cardclass, isNULLstr(argv[m]));
   m++;
   strcpy(provision, isNULLstr(argv[m]));
   m++;
   strcpy(outputf,   isNULLstr(argv[m]));
   
   if (strncmp(dtype,"1",1)==0 || strncmp(dtype,"2",1)==0)
   {
	    strcpy(dbgn1, cm_to_infdate(dbgn2));
	    strcpy(dend1, cm_to_infdate(dend2));
   }
   else
   {
	    strcpy(dvalid1, cm_to_infdate(dvalid2));
   }
   
   
   /*���[���ڥN���P�W�٤���*/
   token = strtok(provision,"-");
   strcpy(provision_a,trim(token));
   token = strtok(NULL,"-");
   strcpy(provision_b,trim(token));
   /*
   printf("-- trace provision_a[%s]\n ",provision_a);
   printf("-- trace provision_b[%s]\n ",provision_b);
   */
   printf("-- trace dbgn1[%s]\n ",dbgn1);
   printf("-- trace dend1[%s]\n ",dend1);
   printf("-- trace davlid1[%s]\n", dvalid1);
   printf("-- trace DBName[%s]\n ",DBName);
   
   strncpy(userid, userid2, 6);
   userid[6] = '\0';
   
   printf("userid = [%s], userid2 = [%s]\n", userid, userid2);
   
   
    if (db_select(DBName) == FALSE) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
    }

   rc = car703_check_id();
   if (rc != M_CM_OK)
       return rc;

   max_cnt=0;

   rc = car703_build();
   if (rc != M_CM_OK)
       return rc;
   
   
   /*if(strlen(trim(userid2)) == 7)
   {
	   printf("email\n");
	   rc = car703_email();
	   if (rc != M_CM_OK)
		  return rc;
   }*/
}

/*--------------------------------------------------------------------*/
long car703_build()
{
/**$char TitleFmt[N_FILE +1], BodyFmt[N_FILE +1];**/
$char TitleFmt[21], BodyFmt[21];
 int rc;

    $whenever sqlerror goto errexit;

    $select nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
            kTot_Col, kPgNum_Line, kWidth, iForm_Tp
       into $TitleFmt, $BodyFmt, $StartRow,  $TitleRow,  $ItemRow,
            $TotColumn, $PgLine, $Width, $iForm_Tp
       from Form
      where ksys_grp = "CA" AND kPgmID = 703;

    strcpy(TitleFmt,rtrim(TitleFmt));
    sprintf(TitleFile,"%s.ti",outputf);
    strcpy(BodyFmt,rtrim(BodyFmt));
    sprintf(BodyFile,"%s.bd",outputf);
    
    rgu_init_report(TitleFmt,TitleFile);
    printf("TitleFmt=%s,TitleFile=%s \n",TitleFmt,TitleFile);
    car703_title();
    rgu_finish_report();

    rgu_init_report(BodyFmt,BodyFile);
    printf("BodyFmt=%s,BodyFile=%s \n",BodyFmt,BodyFile);
    rc=car703_body();
    if (rc != M_CM_OK)
        return rc;
    rgu_finish_report();
	
	if(strlen(trim(userid2)) == 7) /* email�o�e */
    {
	   printf("email\n");
	   rc = car703_email();
	   if (rc != M_CM_OK)
		  return rc;
    }
	
    if ((rc=save_form_info(F_BLK0, "CA", 703, userid, iForm_Tp, max_cnt,
         outputf))<0)
    {
     strcpy(msgbuf,"save_form_info failed");
     return rc;
    }
    return M_CM_OK;
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/*--------------------------------------------------------------------*/
long car703_accumulate()
{
$char stmpA[2048],stmpB[100],str[5],stmpC[512],stmpD[256],stmpF[256],stmpG[256],stmpH[64],stmpI[100];
$char stmpJ[1024], stmpK[100], stmpL[512];   /*�ۯd�O�B J���ۯd�O�B��� K�����p����Ʈw L�����p����*/
int   rc,ply_cnt,n;
$int  flag,i,j,yy,kk;

    $whenever sqlerror goto errexit;
	
	strcpy(stmpJ, " ");
	strcpy(stmpK, " ");
	strcpy(stmpL, " ");

    printf("dtype[%s]\n",dtype);
    if (strncmp(dtype,"1",1)==0) {
        sprintf(stmpB,"a.dpolicy >= '%s' and a.dpolicy <= '%s' ",
                dbgn1,dend1);
    }
    else if (strncmp(dtype,"2",1)==0){
        sprintf(stmpB,"a.dply_end >= '%s' and a.dply_end <= '%s' ",
                dbgn1,dend1);
    }
	else{
		sprintf(stmpB, "a.dply_end >= '%s' and a.dply_begin <= '%s' ", dvalid1, dvalid1);
		strcpy(stmpJ, ", CASE WHEN (SELECT sum(macct_prem) FROM policy_main_dtl WHERE ipolicy1 = a.ipolicy[1,13] AND ipolicy2 = a.ipolicy[14,20] AND insure_instype = c.iins_type) = 0 THEN 0 "
		" ELSE (CASE WHEN (SELECT sum(mret_prem) FROM policy_main_dtl WHERE ipolicy1 = a.ipolicy[1,13] AND ipolicy2 = a.ipolicy[14,20] AND insure_instype = c.iins_type) = 0 THEN c.mdamage_cover "
		" ELSE c.mdamage_cover *(1 - (1 - round(((SELECT sum(mret_prem) FROM policy_main_dtl WHERE ipolicy1 = a.ipolicy[1,13] AND ipolicy2 = a.ipolicy[14,20]  AND insure_instype = c.iins_type)/(SELECT sum(macct_prem) FROM policy_main_dtl WHERE ipolicy1 = a.ipolicy[1,13] AND ipolicy2 = a.ipolicy[14,20] AND insure_instype = c.iins_type)), 2))) END)END ");
		strcpy(stmpK, "policy_main_dtl j,");
		strcpy(stmpL, "AND (j.ipolicy1 = a.ipolicy[1,13] AND j.ipolicy2 = a.ipolicy[14,20] AND c.iins_type = j.insure_instype AND c.iendorse = j.iendorsement) ");
	}
    printf("ctype[%s]\n",ctype);
    if (strncmp(ctype,"1",1)==0)
        sprintf(stmpC,"and a.iquota matches '%s' ",icode);
    else if (strncmp(ctype,"2",1)==0)
        sprintf(stmpC,"and a.iofficer matches '%s' %s ",icode,Astmp);
    else if (strncmp(ctype,"3",1)==0)
        sprintf(stmpC,"and b.iroute matches '%s' ",icode);
    else
	sprintf(stmpC,"and a.iofficer matches '%s' %s ",icode,Astmp);
	
    /* �n�O�H */
    if (strlen(rtrim(iappl))==0 && strlen(rtrim(nappl))== 0)
	strcpy(stmpD," ");
    else if (strlen(rtrim(iappl))!=0 && strlen(rtrim(nappl))!= 0)
	    sprintf(stmpD,
		"and (iapplicant = '%s' or napplicant = '%s') ",iappl,nappl);
    else if (strlen(rtrim(iappl))!=0)
	    sprintf(stmpD,"and iapplicant = '%s' ",iappl);
    else
            sprintf(stmpD,"and napplicant = '%s' ",nappl);
            
    /* �s�y�~�� */
    if (strlen(rtrim(ipro))==0)
    	strcpy(stmpF," ");
    else 
    	sprintf(stmpF,"and ipro_year = '%s' ",ipro);
    
    if (strncmp(feplychk,"1",1)==0)
    	strcpy(stmpG,"and feply = '1' ");
    else 
    	strcpy(stmpG," ");
    	
    if (strncmp(cardclass ,"1",1)==0 )
        sprintf(stmpH,"and a.fcard_class = '1' ");
    else if (strncmp(cardclass ,"2",1)==0 )
        sprintf(stmpH,"and a.fcard_class = '2' ");
    else
        sprintf(stmpH," ");
        
    /*���[���ڧP�w*/
    if (strncmp(trim(ptype) ,"6",1)==0 )
        sprintf(stmpI,"regex_match(c.provision,'(;| +|^)%s(;| +|$)')",provision_a);
    else
        sprintf(stmpI,"c.iins_type = ?");
    

/*--- Ū���O���� ---*/
   sIcard_main[0]='\0';
    sprintf(stmpA,
        "select a.ipolicy,a.icard,b.nassured[1,30],b.ndeputy_assured,a.icar_type, \
                a.iofficer,a.ileader,(select nname from officer where iofficer = a.ileader),a.ibig_office,a.dpolicy, \
                a.dply_begin,a.mdmg_prem,a.mlia_prem,c.mins_premium, \
                c.iins_type,a.iquota[1,4] || '00',(SELECT nbranch FROM sa_branch_type WHERE ibranch = (a.iquota[1,4] || '00')),dply_end, \
                to_char(b.dissue,'%%Y')::integer - 1911 || '/' || to_char(b.dissue,'%%m'), \
                ipro_year,qpro_month,iengine,ibrand,d.nname,a.ibig_sales, \
                b.fassured,(SELECT ncode FROM cu_code_data WHERE itype='09' AND icode = b.fassured), \
                a.iresource,(SELECT ncode FROM cu_code_data WHERE itype='10' AND icode = iresource),fedr_class,a.dendorse, \
                pdiscount,fedr_status,c.dendorse,a.ibig_comp, \
                ibatch_no,b.nequipment,b.itag,c.minjured_cover,c.mdeath_cover,c.mdamage_cover,b.itel, \
                b.iassured,b.iassured_ext, a.icard_main,  \
                d.imgr,b.introducer,b.iroute,b.iroute_accept, \
                (SELECT e.dpay FROM policy_main e WHERE e.ipolicy1 = a.ipolicy AND e.iendorsement = '' ), \
                a.ientry,(select nname from officer where iofficer = a.ientry),a.dentry,b.nuser, \
                nvl(a.ilast_ply,' '), b.qpt, b.fpt, b.dbirth, \
                a.feply,a.aemail_eply,a.feply,a.aemail_eply,b.itel_night,b.mobil_phone,g.nroute, \
                case WHEN d.imgr = '2' THEN h.nname ELSE i.nsales END, \
                b.pdmg_acc , b.plia_acc , b.qlia_acc_sum , b.qdmg_acc_sum , a.fcard_class , b.iply_area \
				%s \
           from ply_relation a,policy b,ply_ins_type c,officer d , %s OUTER cm_route g,OUTER ca_big_office h,OUTER cm_route_sales i \
          where %s %s %s %s %s %s\
            and a.dply_close is not null \
            and a.ipolicy = b.ipolicy \
            and a.ipolicy = c.ipolicy \
            and %s \
            and a.iofficer = d.iofficer \
			AND b.iroute = g.iroute \
			AND b.introducer = h.ibig_comp  \
			AND b.introducer = i.isales \
			AND (SELECT iroute_main FROM cm_route WHERE iroute = b.iroute) matches i.iroute \
			%s \
            order by 1", stmpJ, stmpK, stmpB, stmpC, stmpD ,stmpF, stmpG, stmpH,stmpI, stmpL);
     printf("stmpA[%s]\n",stmpA);
     
    $prepare preA from $stmpA;
    $declare curA cursor for preA;
    
    if(strncmp(trim(ptype) ,"6",1)==0 )
    	$open curA;
    else	
    	$open curA using $iins_type;
    	
    ply_cnt=0;
    
    while(1){
		if(strncmp(dtype,"1",1)==0 || strncmp(dtype,"2",1)==0)
		{
			$fetch curA
			into $Ipolicy,$icard,$Nassured,$Ndeputy_assured,$Icar_type,
              $Iofficer,$Ileader,$nname,$Ibig_office,$Dpolicy,
              $Dply_begin,$Mdmg_prem,$Mlia_prem,$Mins_premium,
              $Iins_type,$Iquota,$Nbranch,$Dply_end,
              $iissue_ym,$ipro_year,$qpro_month,$iengine,$ibrand,$nofficer,$ibig_sales,
              $fassured,$F_ncode,$iresource,$ncode,$fedr_class,$dendorse,
              $pdiscount,$fedr_status,$ply_dendorse,$ibig_comp,$ibatch_no,
              $nequipment,$itag,$minjured_cover,$mdeath_cover,$mdamage_cover,$itel,
              $iassured,$iassured_ext,$sIcard_main,
              $imgr,$introducer,$iroute,$iroute_accept,$dpay,
              $ientry,$nentry,$dentry,$nuser,
              $ilast_ply, $qpt, $fpt, $dbirth,
              $feply,$aemail_eply,$tphone_con,$imovephone,$nroute,
              $ntroducer,
              $Pdmg_acc, $Plia_acc , $qlia_acc_sum , $qdmg_acc_sum , $fcard_class, $iply_area;
		}
		else
		{
			$fetch curA
			into $Ipolicy,$icard,$Nassured,$Ndeputy_assured,$Icar_type,
              $Iofficer,$Ileader,$nname,$Ibig_office,$Dpolicy,
              $Dply_begin,$Mdmg_prem,$Mlia_prem,$Mins_premium,
              $Iins_type,$Iquota,$Nbranch,$Dply_end,
              $iissue_ym,$ipro_year,$qpro_month,$iengine,$ibrand,$nofficer,$ibig_sales,
              $fassured,$F_ncode,$iresource,$ncode,$fedr_class,$dendorse,
              $pdiscount,$fedr_status,$ply_dendorse,$ibig_comp,$ibatch_no,
              $nequipment,$itag,$minjured_cover,$mdeath_cover,$mdamage_cover,$itel,
              $iassured,$iassured_ext,$sIcard_main,
              $imgr,$introducer,$iroute,$iroute_accept,$dpay,
              $ientry,$nentry,$dentry,$nuser,
              $ilast_ply, $qpt, $fpt, $dbirth,
              $feply,$aemail_eply,$tphone_con,$imovephone,$nroute,
              $ntroducer,
              $Pdmg_acc, $Plia_acc , $qlia_acc_sum , $qdmg_acc_sum , $fcard_class , $iply_area , $mret_prem;
		}
        
         if (SQLCODE==SQLNOTFOUND) break;
         strcpy(Ndeputy_assured,trim(Ndeputy_assured));
            
         if (ply_cnt==0) 
         {
            if	(strncmp(trim(ptype) ,"6",1)==0 )
            	rc = car703_heading_pro();
            else
            	rc = car703_heading();
            	
            if (rc != M_CM_OK)
               return rc;
         }
         ply_cnt++;

         /*$SELECT tphone_con,imovephone
            INTO $tphone_con,$imovephone
            FROM cu_customer
           WHERE ifpce_id     = $iassured
             AND ifpce_id_ext = $iassured_ext;
              if (SQLCODE == SQLNOTFOUND)
              {
                 strcpy(tphone_con," ");
                 strcpy(imovephone," ");
              }*/
         
         rfmtlong(minjured_cover,"---,---,---,--&",minjured_cover_c);
         rfmtlong(mdeath_cover,"---,---,---,--&",mdeath_cover_c);
         rfmtlong(mdamage_cover,"---,---,---,--&",mdamage_cover_c);
         printf("ipolicy[%s] nequipment=[%s] \n",Ipolicy,nequipment);

         for(i=1;i<17;i++){
           strcpy(tcode[i]," ");
		}

         if (rmkcheck[0]=='1') 
	 {
         flag=0;
         for(i=1;i<201;i++)
	 {
            printf("213ipolicy=[%s]  i=[%d] fymark[i]=[%s]\n",Ipolicy,i,fymark[i]);
            if( strlen(trim(fymark[i])) > 0)
            { 
	      /********************
	      yy = atoi(fymark[i]);
              if (nequipment[yy-1] == '1')
	      *********************/

	      if (equip_cmp(nequipment,"87") == TRUE)
              { 
	         printf(" match nequipment \n");
                 flag=1;
                 break;
              }
            }
            else
            { 
	      break; 
	    }
         }  /* end of for */
         if (cnt==0) flag=1;   /*���O����=0,��ܩҦ����(���ܸ�Ƥ����Ҽ{}
                                 �O�_�t�����O�ﶵ)*/
         if (flag==0) continue;

         printf(" 251################### \n");
         strcpy(equipdecode,equip_get(nequipment));
         kk=1;
         j=1;

         IEquip_ptr=IfirstEquip;
         while(IEquip_ptr)
         {
            /***
            kk = IEquip_ptr->iequip;   
            ***/
            strcpy(iremark,IEquip_ptr->sequip);
	    if (j> 17)
            {  
	       SQLCODE = 4399;    
               goto errexit; 
	    }

            $SELECT ncode 
	       INTO $tcode[j]
               FROM cu_code_data
              WHERE itype = '25'
                AND icode = $iremark;
                 if (SQLCODE == SQLNOTFOUND) tcode[j][0]='\0';
                 printf("#######231 j=[%d] tcode[j]=[%s] \n",j,tcode[j]);

            IEquip_ptr=IEquip_ptr->next;    
	    j++;
         }

          }  /* end of rmkcheck */

         /* EXEC SQL SELECT nbranch
                   INTO :Nbranch
                   FROM sa_branch_type
                  WHERE ibranch = :Iquota;*/

        if (strncmp(ibig_sales," ",1)!=0) {
           if (strncmp(ibig_comp," ",1) != 0) {
              $select nname
                 into $s_name
                 from ca_big_office
                where ibig_comp = $ibig_sales 
                  and fclass = '2';
              if (SQLCODE == SQLNOTFOUND) 
                 strcpy(s_name," ");  
           }
           else {
              $select nchi_full[1,10]
                 into $s_name
                 from cu_customer
                where ifpce_id = $ibig_sales
                  and ifpce_id_ext = ' ';
              if (SQLCODE == SQLNOTFOUND) 
                 strcpy(s_name," ");  
           }
        }
        else strcpy(s_name," ");

        /* �t�P�������� */
		
        $declare curA1 cursor for
         select ipro_year, nbrand
           into $str, $nbrand
           from ca_car_model
          where ibrand = $ibrand
          order by ipro_year desc;
        $open curA1;
        $fetch curA1;
        if (SQLCODE==SQLNOTFOUND) strcpy(nbrand,"*****");
        $close curA1;
        $free  curA1;
		
		/* �ӫO�a�ϦW�� */
		strcpy(nply_area, "");
		strcpy(nply_area, get_nply_area(iply_area));
		printf("nply_area = [%s]\n", nply_area);

       /* �޲z�H���� */
          /*
       EXEC SQL SELECT nname
                  INTO :nname
                  FROM officer
                 WHERE iofficer = :Ileader;*/
                 
       /* ��J�H���� */
          
       /*EXEC SQL SELECT nname
                  INTO :nentry
                  FROM officer
                 WHERE iofficer = :ientry;*/
      
      /* �Ȥᨭ������ */
        
        /*$SELECT ncode
            INTO :F_ncode
            FROM cu_code_data
           WHERE itype='09'
             AND icode=:fassured;
         
          printf("F_ncode[%s]\n",F_ncode);   */ 

      /* �~�Ȩӷ����� */
        
         /*$SELECT ncode
            INTO :ncode
            FROM cu_code_data
           WHERE itype='10'
             AND icode=:iresource;
     
         printf("ncode[%s]\n",ncode);*/
         
      /* �q�����u���� */
      
      /*strcpy(imgr,trim(imgr));
      strcpy(introducer,trim(introducer));
      strcpy(iroute,trim(iroute));
      
      if(strncmp(imgr,"2",1)==0)
      {
      	$SELECT nname
      	  into :ntroducer
      	  FROM ca_big_office 
      	 WHERE ibig_comp = :introducer
      	   AND fclass = '2';
      	   
      	if (SQLCODE == SQLNOTFOUND) 
            strcpy(ntroducer," ");
      }
      else
      {
      	$SELECT nsales
      	  into :ntroducer
      	  FROM cm_route_sales
      	 WHERE isales = :introducer
      	   AND iroute matches (SELECT iroute_main FROM cm_route WHERE iroute = :iroute);
      	   
      	if (SQLCODE == SQLNOTFOUND) 
            strcpy(ntroducer," ");
      }*/
      
      
      /* �q���N������*/
      /*
      $select first 1 nroute
         into :nroute
         from cm_route
        where iroute = :iroute;
        
      if (SQLCODE == SQLNOTFOUND) 
            strcpy(nroute," ");
        
        printf("iroute=[%s]\nnroute=[%s]\n",iroute,nroute);*/
        
        /* ���O���O */
        
        if (paycheck[0]=='1') {
        memset (tmp_ibatch_no, 0, sizeof (tmp_ibatch_no));
        if (ibatch_no == 0)
            strcpy(tmp_ibatch_no, " ");
        else
            sprintf(tmp_ibatch_no,"%d",ibatch_no);
            
        rtncode = split_policy(Ipolicy, ao_policy1, ao_policy2);
        if ( rtncode != M_CM_OK )
           return rtncode;
             
             
        printf(" squery ao_policy1[%s],ao_policy2[%s],tmp_ibatch_no[%s]\n",
                    ao_policy1,ao_policy2,tmp_ibatch_no);

        ao_chk_charge( DBName, '1', ao_policy1, ao_policy2 , tmp_ibatch_no,
                      a0result, a0comment, a0date1, a0date2);

        printf("a0result[%s]\n",a0result);
        
        if( a0result[0] == 'R' )
            strcpy( ao_note , "Y" );
        else  
            strcpy( ao_note , "N" );
        }
        else
            strcpy( ao_note , " " );
        
        /* �֪@�ĤG�~�����I */
        if (equip_cmp(nequipment,"87") == TRUE)
        {
            rtncode = GetFS_DMG(sIcard_main, Ipolicy, &sFS_ins);
        }
        
        /* �ϥμh�ŦP��ťD��(flevel=1), �Ӹ����(�Q�O�H�ͤ�BID) �B�n,�_�h�n�B�n  */
        strcpy(sDbirth, cm_from_infdate_100(dbirth));
        
        /*
        if ((flevel != 1) && 
            ((strcmp(fassured,"1") == 0) || (strcmp(fassured,"3") == 0) || 
             (strcmp(fassured,"5") == 0)))
        {
            for (n=3;n<7;n++)
            {
                iassured[n] = '*';
            }
            strcat(iassured,"�@");
            
            sDbirth[4] = '*';
            sDbirth[5] = '*';
        }
        
        strcpy(dbirth, trim(sDbirth));
        */
        
        if ((flevel != 1) && 
           ((strcmp(fassured,"1") == 0) || (strcmp(fassured,"3") == 0) || 
            (strcmp(fassured,"5") == 0)))
        {
        	for (n=3;n<7;n++)
        	{
        		iassured[n] = '*';
        	}
        	strcat(iassured,"�@");
        	
        	sDbirth[0] = '*';
        	sDbirth[1] = '*';
        	sDbirth[2] = '*';
        	sDbirth[7] = '*';
        	sDbirth[8] = '*';
        }
        
        if (flevel != 1)
        {
	        for (n=0;n<2;n++)
	        {
	        	itag[n] = '*';
	        }
	        
	        if(strcmp(trim(nuser),"") != 0)
	        {
	        	strcpy(nuser_pt, nuser);
	        	strcpy(nuser,substring(nuser_pt,1,2));
	        	strcat(nuser,"�ݢ�");
	        }  
	        
	        num = strlen(rtrim(iengine));
	        for (n=num; n>num-5; n--)
	        {
	        	iengine[n] = '*';
	        }
	        strcat(iengine," ");
	    }
        
        strcpy(dbirth, trim(sDbirth) );
              
        car703_print();
    }
    $close curA;
    $free curA;
    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;  
}
/*--------------------------------------------------------------------*/
void car703_title()
{
    rgu_put_head();
}
/*--------------------------------------------------------------------*/
long car703_accumulate1()
{
$char stmpA[4096],stmpB[100],str[5],stmpC[512],stmpD[256],stmpF[256],stmpG[256],stmpH[64],stmpI[100];
$char stmpJ[1024], stmpK[100], stmpL[512];   /*�ۯd�O�B J���ۯd�O�B��� K�����p����Ʈw L�����p����*/
int   rc,ply_cnt,n;
$int  flag,i,j,yy,kk;

    $whenever sqlerror goto errexit;
	
	strcpy(stmpJ, " ");
	strcpy(stmpK, " ");
	strcpy(stmpL, " ");
    
    if ((list = get_db_list (&count_db, DBName)) == (char *) 0)
    {
        if (EWRITE(userid, M_CM_NOT_DBLIST) == True)
            return M_CM_NOT_DBLIST;
            return M_CM_OK;
    }


    printf("dtype[%s]\n",dtype);
    if (strncmp(dtype,"1",1)==0) {
        sprintf(stmpB,"a.dpolicy >= '%s' and a.dpolicy <= '%s' ",
                dbgn1,dend1);
    }
    else if (strncmp(dtype,"2",1)==0){
        sprintf(stmpB,"a.dply_end >= '%s' and a.dply_end <= '%s' ",
                dbgn1,dend1);
    }
	else{
		sprintf(stmpB, "a.dply_end >= '%s' and a.dply_begin <= '%s' ", dvalid1, dvalid1);
		strcpy(stmpJ, ", CASE WHEN (SELECT sum(macct_prem) FROM policy_main_dtl WHERE ipolicy1 = a.ipolicy[1,13] AND ipolicy2 = a.ipolicy[14,20] AND insure_instype = c.iins_type) = 0 THEN 0 "
		" ELSE (CASE WHEN (SELECT sum(mret_prem) FROM policy_main_dtl WHERE ipolicy1 = a.ipolicy[1,13] AND ipolicy2 = a.ipolicy[14,20] AND insure_instype = c.iins_type) = 0 THEN c.mdamage_cover "
		" ELSE c.mdamage_cover *(1 - (1 - round(((SELECT sum(mret_prem) FROM policy_main_dtl WHERE ipolicy1 = a.ipolicy[1,13] AND ipolicy2 = a.ipolicy[14,20]  AND insure_instype = c.iins_type)/(SELECT sum(macct_prem) FROM policy_main_dtl WHERE ipolicy1 = a.ipolicy[1,13] AND ipolicy2 = a.ipolicy[14,20] AND insure_instype = c.iins_type)), 2))) END)END ");
		strcpy(stmpK, "policy_main_dtl j,");
		strcpy(stmpL, "AND (j.ipolicy1 = a.ipolicy[1,13] AND j.ipolicy2 = a.ipolicy[14,20] AND c.iins_type = j.insure_instype AND c.iendorse = j.iendorsement) ");
	}
    printf("ctype[%s]\n",ctype);
    if (strncmp(ctype,"1",1)==0)
        sprintf(stmpC,"and a.iquota matches '%s' ",icode);
    else if (strncmp(ctype,"2",1)==0)
        sprintf(stmpC,"and a.iofficer matches '%s' %s ",icode,Astmp);
    else if (strncmp(ctype,"3",1)==0)
        sprintf(stmpC,"and b.iroute matches '%s' ",icode);
    else
	sprintf(stmpC,"and a.iofficer matches '%s' %s ",icode,Astmp);
        
    /* �n�O�H */
    if (strlen(rtrim(iappl))==0 && strlen(rtrim(nappl))== 0)
	strcpy(stmpD," ");
    else if (strlen(rtrim(iappl))!=0 && strlen(rtrim(nappl))!= 0)
	    sprintf(stmpD,
		"and (iapplicant = '%s' or napplicant = '%s') ",iappl,nappl);
    else if (strlen(rtrim(iappl))!=0)
	    sprintf(stmpD,"and iapplicant = '%s' ",iappl);
    else
            sprintf(stmpD,"and napplicant = '%s' ",nappl);
            
    /* �s�y�~�� */
    if (strlen(rtrim(ipro))==0)
    strcpy(stmpF," ");
    else 
    sprintf(stmpF,"and ipro_year = '%s' ",ipro);
    
    if (strncmp(feplychk,"1",1)==0)
    	strcpy(stmpG,"and feply = '1' ");
    else 
    	strcpy(stmpG," ");
    	
    if (strncmp(cardclass ,"1",1)==0 )
        sprintf(stmpH,"and a.fcard_class = '1' ");
    else if (strncmp(cardclass ,"2",1)==0 )
        sprintf(stmpH,"and a.fcard_class = '2' ");
    else
        sprintf(stmpH," ");
        
    /*���[���ڧP�w*/
    if (strncmp(trim(ptype) ,"6",1)==0 )
        sprintf(stmpI,"regex_match(c.provision,'(;| +|^)%s(;| +|$)')",provision_a);
    else
        sprintf(stmpI,"c.iins_type = ?");
    
    /*printf("stmpI[%s]\n",stmpI);*/
/*--- Ū���O���� ---*/

 x=0;
 sIcard_main[0]='\0';
 for(x=0;x<count_db;x++)
 {
    sprintf(stmpA,
        "select a.ipolicy,a.icard,b.nassured[1,30],b.ndeputy_assured,a.icar_type, \
                a.iofficer,a.ileader,(select nname from officer where iofficer = a.ileader),a.ibig_office,a.dpolicy, \
                a.dply_begin,a.mdmg_prem,a.mlia_prem,c.mins_premium, \
                c.iins_type,a.iquota[1,4] || '00',(SELECT nbranch FROM sa_branch_type WHERE ibranch = (a.iquota[1,4] || '00')),dply_end, \
                to_char(b.dissue,'%%Y')::integer - 1911 || '/' || to_char(b.dissue,'%%m'), \
                ipro_year,qpro_month,iengine,ibrand,d.nname,a.ibig_sales, \
                b.fassured,(SELECT ncode FROM cu_code_data WHERE itype='09' AND icode = b.fassured), \
                a.iresource,(SELECT ncode FROM cu_code_data WHERE itype='10' AND icode = iresource),fedr_class,a.dendorse, \
                pdiscount,fedr_status,c.dendorse,a.ibig_comp, \
                ibatch_no,b.nequipment,b.itag,c.minjured_cover,c.mdeath_cover,c.mdamage_cover,b.itel, \
                b.iassured,b.iassured_ext, a.icard_main,  \
                d.imgr,b.introducer,b.iroute,b.iroute_accept, \
                (SELECT e.dpay FROM policy_main e WHERE e.ipolicy1 = a.ipolicy AND e.iendorsement = '' ), \
                a.ientry,(select nname from officer where iofficer = a.ientry),a.dentry,b.nuser, \
                a.ilast_ply, b.qpt, b.fpt, b.dbirth, \
                a.feply,a.aemail_eply,b.itel_night,b.mobil_phone,g.nroute, \
                case WHEN d.imgr = '2' THEN h.nname ELSE i.nsales END, \
                b.pdmg_acc , b.plia_acc , b.qlia_acc_sum , b.qdmg_acc_sum , a.fcard_class ,\
                CASE WHEN a.iscan_no is null or a.iscan_no = '' THEN 'N' ELSE 'Y' END , a.iscan_no , b.qcylinder , b.iply_area \
				%s \
           from %s:ply_relation a,%s:policy b,%s:ply_ins_type c,officer d, %s OUTER cm_route g,OUTER ca_big_office h,OUTER cm_route_sales i \
          where %s %s %s %s %s %s\
            and a.dply_close is not null \
            and a.ipolicy = b.ipolicy \
            and a.ipolicy = c.ipolicy \
            and %s \
            and a.iofficer = d.iofficer \
			AND b.iroute = g.iroute \
			AND b.introducer = h.ibig_comp  \
			AND b.introducer = i.isales \
			AND (SELECT iroute_main FROM cm_route WHERE iroute = b.iroute) matches i.iroute \
			%s \
            order by 1", stmpJ, list[x].dbname,list[x].dbname,list[x].dbname, stmpK, stmpB, stmpC, stmpD, stmpF, stmpG, stmpH, stmpI, stmpL);
     printf("stmpA[%s]\n",stmpA);
     
     
    $prepare preA from $stmpA;
    $declare curAA cursor for preA;
   
    if(strncmp(trim(ptype) ,"6",1)==0 )
    	$open curAA;
    else	
    	$open curAA using $iins_type;
    	
    ply_cnt=0;
                
    while(1){
		if (strncmp(dtype,"1",1)==0 || strncmp(dtype,"2",1)==0)
		{
			$fetch curAA
			into $Ipolicy,$icard,$Nassured,$Ndeputy_assured,$Icar_type,
              $Iofficer,$Ileader,$nname,$Ibig_office,$Dpolicy,
              $Dply_begin,$Mdmg_prem,$Mlia_prem,$Mins_premium,
              $Iins_type,$Iquota,$Nbranch,$Dply_end,
              $iissue_ym,$ipro_year,$qpro_month,$iengine,$ibrand,$nofficer,$ibig_sales,
              $fassured,$F_ncode,$iresource,$ncode,$fedr_class,$dendorse,
              $pdiscount,$fedr_status,$ply_dendorse,$ibig_comp,$ibatch_no,
              $nequipment,$itag,$minjured_cover,$mdeath_cover,$mdamage_cover,$itel,
              $iassured,$iassured_ext,$sIcard_main,
              $imgr,$introducer,$iroute,$iroute_accept,$dpay,
              $ientry,$nentry,$dentry,$nuser,
              $ilast_ply, $qpt, $fpt, $dbirth,
              $feply,$aemail_eply,$tphone_con,$imovephone,$nroute,
              $ntroducer,
              $Pdmg_acc, $Plia_acc , $qlia_acc_sum , $qdmg_acc_sum , $fcard_class,
              $fesign, $iscan_no, $qcylinder , $iply_area;
		}
		else
		{
			$fetch curAA
			into $Ipolicy,$icard,$Nassured,$Ndeputy_assured,$Icar_type,
              $Iofficer,$Ileader,$nname,$Ibig_office,$Dpolicy,
              $Dply_begin,$Mdmg_prem,$Mlia_prem,$Mins_premium,
              $Iins_type,$Iquota,$Nbranch,$Dply_end,
              $iissue_ym,$ipro_year,$qpro_month,$iengine,$ibrand,$nofficer,$ibig_sales,
              $fassured,$F_ncode,$iresource,$ncode,$fedr_class,$dendorse,
              $pdiscount,$fedr_status,$ply_dendorse,$ibig_comp,$ibatch_no,
              $nequipment,$itag,$minjured_cover,$mdeath_cover,$mdamage_cover,$itel,
              $iassured,$iassured_ext,$sIcard_main,
              $imgr,$introducer,$iroute,$iroute_accept,$dpay,
              $ientry,$nentry,$dentry,$nuser,
              $ilast_ply, $qpt, $fpt, $dbirth,
              $feply,$aemail_eply,$tphone_con,$imovephone,$nroute,
              $ntroducer,
              $Pdmg_acc, $Plia_acc , $qlia_acc_sum , $qdmg_acc_sum , $fcard_class,
              $fesign, $iscan_no, $qcylinder, $iply_area, $mret_prem;
		}
        
         if (SQLCODE==SQLNOTFOUND) break;
         
         strcpy(Ndeputy_assured,trim(Ndeputy_assured));
 
         if (ply_cnt==0) 
         {
            if	(strncmp(trim(ptype) ,"6",1)==0 )
            	rc = car703_heading_pro();
            else
            	rc = car703_heading();
            	
            if (rc != M_CM_OK)
               return rc;
         }
         ply_cnt++;

         /*$SELECT tphone_con,imovephone
            INTO $tphone_con,$imovephone
            FROM cu_customer
           WHERE ifpce_id     = $iassured
             AND ifpce_id_ext = $iassured_ext;
              if (SQLCODE == SQLNOTFOUND)
              {
                 strcpy(tphone_con," ");
                 strcpy(imovephone," ");
              }
         */
         rfmtlong(minjured_cover,"---,---,---,--&",minjured_cover_c);
         rfmtlong(mdeath_cover,"---,---,---,--&",mdeath_cover_c);
         rfmtlong(mdamage_cover,"---,---,---,--&",mdamage_cover_c);
         printf("ipolicy[%s] nequipment=[%s] \n",Ipolicy,nequipment);

         for(i=1;i<17;i++)
           strcpy(tcode[i]," ");

         if (rmkcheck[0]=='1') 
	 {
           flag=0;
            for(i=1;i<201;i++)
            {
               printf("213ipolicy=[%s]  i=[%d] fymark[i]=[%s]\n",Ipolicy,i,fymark[i]);
               if (strlen(trim(fymark[i])) > 0)
               { 
               /********************
               yy = atoi(fymark[i]);
               if (nequipment[yy-1] == '1')
               *********************/
                  if (equip_cmp(nequipment,fymark[i]) == TRUE)
                  { 
                     printf(" match nequipment \n");
                     flag=1;
                     break;
                  }
               }
               else
               { 
                  break; 
               }
            }  /* end of for */

         if (cnt==0) flag=1;   /*���O����=0,��ܩҦ����(���ܸ�Ƥ����Ҽ{}
                                 �O�_�t�����O�ﶵ)*/
         if (flag==0) continue;
         printf(" 251################### \n");
         strcpy(equipdecode,equip_get(nequipment));
         kk=1;
         j=1;

         IEquip_ptr=IfirstEquip;
         while(IEquip_ptr)
         {
            strcpy(iremark,IEquip_ptr->sequip);
	         if (j> 17)
            {  
	            SQLCODE = 4399;    
               goto errexit; 
	         }

            $SELECT ncode 
	            INTO $tcode[j]
               FROM cu_code_data
              WHERE itype = '25'
                AND icode = $iremark;
                 if (SQLCODE == SQLNOTFOUND) tcode[j][0]='\0';
                 printf("#######231 j=[%d] tcode[j]=[%s] \n",j,tcode[j]);

            IEquip_ptr=IEquip_ptr->next;    
	         j++;
         }


          }  /* end of rmkcheck */

          /*EXEC SQL SELECT nbranch
                   INTO :Nbranch
                   FROM sa_branch_type
                  WHERE ibranch = :Iquota;*/

        if (strncmp(ibig_sales," ",1)!=0) {
           if (strncmp(ibig_comp," ",1) != 0) {
              $select trim(nname)
                 into $s_name
                 from ca_big_office
                where ibig_comp = $ibig_sales 
                  and fclass = '2';
              if (SQLCODE == SQLNOTFOUND) 
                 strcpy(s_name," ");  
           }
           else {
              $select nchi_full[1,10]
                 into $s_name
                 from cu_customer
                where ifpce_id = $ibig_sales
                  and ifpce_id_ext = ' ';
              if (SQLCODE == SQLNOTFOUND) 
                 strcpy(s_name," ");  
           }
        }
        else strcpy(s_name," ");

        /* �t�P�������� */

        $declare curAA1 cursor for
         select ipro_year, nbrand
           into $str, $nbrand
           from ca_car_model
          where ibrand = $ibrand
          order by ipro_year desc;
        $open curAA1;
        $fetch curAA1;
        if (SQLCODE==SQLNOTFOUND) strcpy(nbrand,"*****");
        $close curAA1;
        $free  curAA1;
		
		/* �ӫO�a�ϦW�� */
		strcpy(nply_area, "");
		strcpy(nply_area, get_nply_area(iply_area));
		printf("nply_area = [%s]\n", nply_area);

       /* �޲z�H���� */
          
       /*EXEC SQL SELECT nname
                  INTO :nname
                  FROM officer
                 WHERE iofficer = :Ileader;*/
                 
       /* ��J�H���� */
          
       /*EXEC SQL SELECT nname
                  INTO :nentry
                  FROM officer
                 WHERE iofficer = :ientry;*/      
           
      
      /* �Ȥᨭ������ */
        
        /*$SELECT ncode
            INTO :F_ncode
            FROM cu_code_data
           WHERE itype='09'
             AND icode=:fassured;
         
          printf("F_ncode[%s]\n",F_ncode);    */

      /* �~�Ȩӷ����� */
        
        /* $SELECT ncode
            INTO :ncode
            FROM cu_code_data
           WHERE itype='10'
             AND icode=:iresource;
     
         printf("ncode[%s]\n",ncode);*/
         
       /* �q�����u���� */
      /*
      strcpy(imgr,trim(imgr));
      strcpy(introducer,trim(introducer));
      strcpy(iroute,trim(iroute));
      
      if(strncmp(imgr,"2",1)==0)
      {
      	$SELECT nname
      	  into :ntroducer
      	  FROM ca_big_office 
      	 WHERE ibig_comp = :introducer
      	   AND fclass = '2';
      	   
      	if (SQLCODE == SQLNOTFOUND) 
            strcpy(ntroducer," ");
      }
      else
      {
      	$SELECT nsales
      	  into :ntroducer
      	  FROM cm_route_sales
      	 WHERE isales = :introducer
      	   AND iroute matches (SELECT iroute_main FROM cm_route WHERE iroute = :iroute);
      	   
      	if (SQLCODE == SQLNOTFOUND) 
            strcpy(ntroducer," ");
      }*/
      
      
      /* �q���N������*/
      /*
      $select first 1 nroute
         into :nroute
         from cm_route
        where iroute = :iroute;
        
      if (SQLCODE == SQLNOTFOUND) 
            strcpy(nroute," ");  
        
        printf("iroute=[%s]\nnroute=[%s]\n",iroute,nroute);*/
          
        
        /* ���O���O */
        
        if (paycheck[0]=='1') {
        memset (tmp_ibatch_no, 0, sizeof (tmp_ibatch_no));
        if (ibatch_no == 0)
            strcpy(tmp_ibatch_no, " ");
        else
            sprintf(tmp_ibatch_no,"%d",ibatch_no);
            
        rtncode = split_policy(Ipolicy, ao_policy1, ao_policy2);
        if ( rtncode != M_CM_OK )
           return rtncode;
             
             
        printf(" squery ao_policy1[%s],ao_policy2[%s],tmp_ibatch_no[%s]\n",
                    ao_policy1,ao_policy2,tmp_ibatch_no);

        ao_chk_charge( DBName, '1', ao_policy1, ao_policy2 , tmp_ibatch_no,
                      a0result, a0comment, a0date1, a0date2);

        printf("a0result[%s]\n",a0result);
        
        if( a0result[0] == 'R' )
            strcpy( ao_note , "Y" );
        else  
            strcpy( ao_note , "N" );
        }
        else
            strcpy( ao_note , " " );
            
        /* �֪@�ĤG�~�����I */
        
        if (equip_cmp(nequipment,"87") == TRUE)
        {
            rtncode = GetFS_DMG(sIcard_main, Ipolicy, &sFS_ins);
        }
        
        /* �ϥμh�ŦP��ťD��(flevel=1), �Ӹ����(�Q�O�H�ͤ�BID) �B�n,�_�h�n�B�n  */
        strcpy(sDbirth, cm_from_infdate_100(dbirth));
        
        
        if ((flevel != 1) && 
           ((strcmp(fassured,"1") == 0) || (strcmp(fassured,"3") == 0) || 
            (strcmp(fassured,"5") == 0)))
        {
        	for (n=3;n<7;n++)
        	{
        		iassured[n] = '*';
        	}
        	strcat(iassured,"�@");
        	
        	sDbirth[0] = '*';
        	sDbirth[1] = '*';
        	sDbirth[2] = '*';
        	sDbirth[7] = '*';
        	sDbirth[8] = '*';
        }
        
        if (flevel != 1)
        {
	        for (n=0;n<2;n++)
	        {
	        	itag[n] = '*';
	        }
	        
	        if(strcmp(trim(nuser),"") != 0)
	        {
	        	strcpy(nuser_pt, nuser);
	        	strcpy(nuser,substring(nuser_pt,1,2));
	        	strcat(nuser,"�ݢ�");
	        }  
	        
	        num = strlen(rtrim(iengine));
	        for (n=num; n>num-5; n--)
	        {
	        	iengine[n] = '*';
	        }
	        strcat(iengine," ");
        }
        strcat(iengine," ");
        
        strcpy(dbirth, trim(sDbirth) );
        
          
        car703_print();
    }
    $close curAA;
    $free curAA;
    
} /*  end three database    */

    
    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;  
}

/*--------------------------------------------------------------------*/
long car703_accumulate2()
{
$char stmpA[4096],stmpB[100],str[5],stmpC[512],stmpD[256],stmpE[256],stmpF[256],stmpG[256],stmpH[64];
int   rc,ply_cnt,n;
$int  flag,i,j,yy,kk;

    $whenever sqlerror goto errexit;
    
    if ((list = get_db_list (&count_db, DBName)) == (char *) 0)
    {
        if (EWRITE(userid, M_CM_NOT_DBLIST) == True)
            return M_CM_NOT_DBLIST;
            return M_CM_OK;
    }

    if (strncmp(dtype,"1",1)==0) {
        sprintf(stmpB,"a.dpolicy >= '%s' and a.dpolicy <= '%s' ",
                dbgn1,dend1);
    }
    else {
        sprintf(stmpB,"a.dply_end >= '%s' and a.dply_end <= '%s' ",
                dbgn1,dend1);
    }

    if (strncmp(ctype,"1",1)==0)
        sprintf(stmpC,"and a.iquota matches '%s' ",icode);
    else if (strncmp(ctype,"2",1)==0)
        sprintf(stmpC,"and a.iofficer matches '%s' %s ",icode,Astmp);
    else if (strncmp(ctype,"3",1)==0)
        sprintf(stmpC,"and b.iroute matches '%s' ",icode);
    else
	sprintf(stmpC,"and a.iofficer matches '%s' %s ",icode,Astmp);
	
    /* �n�O�H */
    if (strlen(rtrim(iappl))==0 && strlen(rtrim(nappl))== 0)
	strcpy(stmpD," ");
    else if (strlen(rtrim(iappl))!=0 && strlen(rtrim(nappl))!= 0)
	    sprintf(stmpD,
		"and (iapplicant matches '%s' or napplicant matches '%s') ",
		iappl,nappl);
    else if (strlen(rtrim(iappl))!=0)
	    sprintf(stmpD,"and iapplicant matches '%s' ",iappl);
    else
            sprintf(stmpD,"and napplicant matches '%s' ",nappl);
     
    /*1050105002_C1 �T���~���ը�����X�O�I*/        
	/* �O�_���q�ʦۦ樮 */            
	if (ptype[0]=='3')
	{
		sprintf(stmpE," and a.ipolicy[6,7] = 'EB' ");
	}
	else if (ptype[0]=='4')	
	{
		sprintf(stmpE," and a.ipolicy[6,7] = 'TV' ");
	}
	else if	(ptype[0]=='5')
	{
		sprintf(stmpE," and a.icar_type = '%s' ",icar_type);
	}
	else
	{
		sprintf(stmpE," and a.ipolicy[6,7] not in ('EB','TV') ");
	}
	
    /* �s�y�~�� */
    if (strlen(rtrim(ipro))==0)
    strcpy(stmpF," ");
    else 
    sprintf(stmpF,"and ipro_year = '%s' ",ipro);  
    
    if (strncmp(feplychk,"1",1)==0)
    	strcpy(stmpG,"and feply = '1' ");
    else 
    	strcpy(stmpG," ");
    	
    if (strncmp(cardclass ,"1",1)==0 )
        sprintf(stmpH,"and a.fcard_class = '1' ");
    else if (strncmp(cardclass ,"2",1)==0 )
        sprintf(stmpH,"and a.fcard_class = '2' ");
    else
        sprintf(stmpH," ");

/*--- Ū���O���� ---*/
   sIcard_main[0]='\0';
 for(x=0;x<count_db;x++)
 {
    printf("DBName[%s]dbbranch[%s]\n",DBName,list[x].dbbranch);
    if (falldb[0]!='Y')
 	if (strcmp(DBName,list[x].dbbranch)!=0) continue;

    sprintf(stmpA,
        "select a.ipolicy,a.icard,b.nassured[1,30],b.ndeputy_assured,a.icar_type, \
                a.iofficer,a.ileader,(select nname from officer where iofficer = a.ileader),a.ibig_office,a.dpolicy, \
                a.dply_begin,a.mdmg_prem+a.mlia_prem,\
                a.iquota[1,4] || '00',(SELECT nbranch FROM sa_branch_type WHERE ibranch = (a.iquota[1,4] || '00')),dply_end, \
                to_char(b.dissue,'%%Y')::integer - 1911 || '/' || to_char(b.dissue,'%%m'), \
                ipro_year,qpro_month,iengine,ibrand,d.nname,a.ibig_sales, \
                b.fassured,(SELECT ncode FROM cu_code_data WHERE itype='09' AND icode = b.fassured),a.iresource, \
                (SELECT ncode FROM cu_code_data WHERE itype='10' AND icode = iresource), \
                fedr_class,a.dendorse,a.ibig_comp, \
                ibatch_no,b.nequipment,b.itag,b.itel, \
                b.iassured,b.iassured_ext,a.icard_main,  \
                d.imgr,b.introducer,b.iroute,b.iroute_accept, \
                (SELECT e.dpay FROM policy_main e WHERE e.ipolicy1 = a.ipolicy AND e.iendorsement = '' ), \
                a.ientry,(select nname from officer where iofficer = a.ientry),a.dentry,b.nuser, \
                a.ilast_ply, b.qpt, b.fpt, b.dbirth, \
                a.feply,a.aemail_eply,b.itel_night,b.mobil_phone,g.nroute, \
                case WHEN d.imgr = '2' THEN h.nname ELSE i.nsales END ,\
                b.pdmg_acc , b.plia_acc , b.qlia_acc_sum , b.qdmg_acc_sum , a.fcard_class, \
                CASE WHEN a.iscan_no is null or a.iscan_no = '' THEN 'N' ELSE 'Y' END , a.iscan_no , b.qcylinder , b.iply_area \
           from %s:ply_relation a,%s:policy b,officer d,OUTER cm_route g,OUTER ca_big_office h,OUTER cm_route_sales i  \
          where %s %s %s %s %s %s %s\
            and a.dply_close is not null \
            and a.ipolicy = b.ipolicy \
            and a.iofficer = d.iofficer \
            AND b.iroute = g.iroute \
            AND b.introducer = h.ibig_comp \
            AND b.introducer = i.isales \
            AND (SELECT iroute_main FROM cm_route WHERE iroute = b.iroute) matches i.iroute \
            order by 1", list[x].dbname,list[x].dbname,stmpB, stmpC, stmpD, stmpE, stmpF, stmpG, stmpH);
     printf("stmpA[%s]\n",stmpA);
    $prepare preA from $stmpA;
    $declare curAC cursor for preA;
    $open curAC;
    ply_cnt=0;
                
    while(1){
        $fetch curAC
         into $Ipolicy,$icard,$Nassured,$Ndeputy_assured,$Icar_type,
              $Iofficer,$Ileader,$nname,$Ibig_office,$Dpolicy,
              $Dply_begin,$Mdmg_prem,$Iquota,$Nbranch,$Dply_end,
              $iissue_ym,$ipro_year,$qpro_month,$iengine,$ibrand,$nofficer,
	      	  $ibig_sales,
              $fassured,$F_ncode,$iresource,$ncode,$fedr_class,$dendorse,
              $ibig_comp,$ibatch_no,
              $nequipment,$itag,$itel,
              $iassured,$iassured_ext,$sIcard_main,
              $imgr,$introducer,$iroute,$iroute_accept,$dpay,
              $ientry,$nentry,$dentry,$nuser,
              $ilast_ply, $qpt, $fpt, $dbirth,
              $feply,$aemail_eply,$tphone_con,$imovephone,$nroute,
              $ntroducer,
              $Pdmg_acc , $Plia_acc , $qlia_acc_sum , $qdmg_acc_sum , $fcard_class, 
              $fesign, $iscan_no, $qcylinder , $iply_area;
         if (SQLCODE==SQLNOTFOUND) break;
         strcpy(Ndeputy_assured,trim(Ndeputy_assured));
         if (ply_cnt==0) {
            rc = car703_heading_appl();
            if (rc != M_CM_OK)
               return rc;
         }
         ply_cnt++;

        /* $SELECT tphone_con,imovephone
            INTO $tphone_con,$imovephone
            FROM cu_customer
           WHERE ifpce_id     = $iassured
             AND ifpce_id_ext = $iassured_ext;
              if (SQLCODE == SQLNOTFOUND)
              {
                 strcpy(tphone_con," ");
                 strcpy(imovephone," ");
              }
*/
        /* printf("888:ipolicy[%s] nequipment=[%s] \n",Ipolicy,nequipment);*/

         for(i=1;i<17;i++){
           strcpy(tcode[i]," ");
          /* printf("--tcode[%d] = [%s]\n",i,tcode[i]);*/
        }

         if (rmkcheck[0]=='1') 
	 {
	      printf("-----895-----\n");
           flag=0;
           for(i=1;i<201;i++)
           {
              if (strlen(trim(fymark[i])) > 0)
              { 
                 printf("fymark[i]= [%s] equip_get(nequipment)=[%s]\n",fymark[i],equip_get(nequipment));
                 printf("nequipment= [%s]\n",nequipment);
                  if (equip_cmp(nequipment,fymark[i]) == TRUE)
                  { 
      	             printf(" match nequipment \n");
                           flag=1;
                           break;
                  }
              }
              else
              { 
	          break; 
	      }
           }  /* end of for */

         if (cnt==0) flag=1;   /*���O����=0,��ܩҦ����(���ܸ�Ƥ����Ҽ{}
                                 �O�_�t�����O�ﶵ)*/
         if (flag==0) continue;
         strcpy(equipdecode,equip_get(nequipment));
         kk=1;
         j=1;

         IEquip_ptr=IfirstEquip;
         while(IEquip_ptr)
         {
            strcpy(iremark,IEquip_ptr->sequip);
            printf("iremark=[%s]\n",iremark);
	    if (j> 17)
            {  
	       SQLCODE = 4399;    
               goto errexit; 
	    }

            $SELECT ncode 
	       INTO $tcode[j]
               FROM cu_code_data
              WHERE itype = '25'
                AND icode = $iremark;
                 if (SQLCODE == SQLNOTFOUND) tcode[j][0]='\0';

            IEquip_ptr=IEquip_ptr->next;    
	    j++;
         }

         }  /* end of rmkcheck */

        
        if (strncmp(ibig_sales," ",1)!=0) {
           if (strncmp(ibig_comp," ",1) != 0) {
              $select nname
                 into $s_name
                 from ca_big_office
                where ibig_comp = $ibig_sales 
                  and fclass = '2';
              if (SQLCODE == SQLNOTFOUND) 
                 strcpy(s_name," ");  
           }
           else {
              $select nchi_full[1,10]
                 into $s_name
                 from cu_customer
                where ifpce_id = $ibig_sales
                  and ifpce_id_ext = ' ';
              if (SQLCODE == SQLNOTFOUND) 
                 strcpy(s_name," ");  
           }
        }
        else strcpy(s_name," ");

        /* �t�P�������� */

        $declare curAC1 cursor for
         select ipro_year, nbrand
           into $str, $nbrand
           from ca_car_model
          where ibrand = $ibrand
          order by ipro_year desc;
        $open curAC1;
        $fetch curAC1;
        if (SQLCODE==SQLNOTFOUND) strcpy(nbrand,"*****");
        $close curAC1;
        $free  curAC1;
        /*strcpy(nbrand,"*****");*/
		
		/* �ӫO�a�ϦW�� */
		strcpy(nply_area, "");
		strcpy(nply_area, get_nply_area(iply_area));
		printf("nply_area = [%s]\n", nply_area);

       /* �޲z�H���� */
          

                 
       /* ��J�H���� */
          
      
      /* �Ȥᨭ������ */
       
         
          /*printf("F_ncode[%s]\n",F_ncode);    */

      /* �~�Ȩӷ����� */
     
         /*printf("ncode[%s]\n",ncode);*/
         
     /* �q�����u���� */
      /*
      strcpy(imgr,trim(imgr));
      strcpy(introducer,trim(introducer));
      strcpy(iroute,trim(iroute));
      
      if(strncmp(imgr,"2",1)==0)
      {
      	$SELECT nname
      	  into :ntroducer
      	  FROM ca_big_office 
      	 WHERE ibig_comp = :introducer
      	   AND fclass = '2';
      	   
      	if (SQLCODE == SQLNOTFOUND) 
            strcpy(ntroducer," ");
      }
      else
      {
      	$SELECT nsales
      	  into :ntroducer
      	  FROM cm_route_sales
      	 WHERE isales = :introducer
      	   AND iroute matches (SELECT iroute_main FROM cm_route WHERE iroute = :iroute);
      	   
      	if (SQLCODE == SQLNOTFOUND) 
            strcpy(ntroducer," ");
      }*/
      
      
      /* �q���N������*/
      
      /*$select first 1 nroute
         into :nroute
         from cm_route
        where iroute = :iroute;
      
      if (SQLCODE == SQLNOTFOUND) 
            strcpy(nroute," ");*/
              
        /*printf("iroute=[%s]\nnroute=[%s]\n",iroute,nroute); */ 
        
        /* ���O���O */
        
        if (paycheck[0]=='1') {
        memset (tmp_ibatch_no, 0, sizeof (tmp_ibatch_no));
        if (ibatch_no == 0)
            strcpy(tmp_ibatch_no, " ");
        else
            sprintf(tmp_ibatch_no,"%d",ibatch_no);
            
        rtncode = split_policy(Ipolicy, ao_policy1, ao_policy2);
        if ( rtncode != M_CM_OK )
           return rtncode;
             
             
        printf(" squery ao_policy1[%s],ao_policy2[%s],tmp_ibatch_no[%s]\n",
                    ao_policy1,ao_policy2,tmp_ibatch_no);

        ao_chk_charge( DBName, '1', ao_policy1, ao_policy2 , tmp_ibatch_no,
                      a0result, a0comment, a0date1, a0date2);

        printf("a0result[%s]\n",a0result);
        
        if( a0result[0] == 'R' )
            strcpy( ao_note , "Y" );
        else  
            strcpy( ao_note , "N" );
        }
        else
            strcpy( ao_note , " " );
        
        /* �֪@�ĤG�~�����I */
        /*printf("--- 1060 --�֪@�ĤG�~�����I\n");
        printf("nequipment=[%s]sIcard_main=[%s]Ipolicy=[%s]\n",nequipment,sIcard_main,Ipolicy);*/
        if (equip_cmp(nequipment,"87") == TRUE)
        {
            rtncode = GetFS_DMG(sIcard_main, Ipolicy,  &sFS_ins);
        }
        
        /* �ϥμh�ŦP��ťD��(flevel=1), �Ӹ����(�Q�O�H�ͤ�BID) �B�n,�_�h�n�B�n  */
        strcpy(sDbirth, cm_from_infdate_100(dbirth));
                
        if ((flevel != 1) && 
           ((strcmp(fassured,"1") == 0) || (strcmp(fassured,"3") == 0) || 
            (strcmp(fassured,"5") == 0)))
        {
        	for (n=3;n<7;n++)
        	{
        		iassured[n] = '*';
        	}
        	strcat(iassured,"�@");
        	
        	sDbirth[0] = '*';
        	sDbirth[1] = '*';
        	sDbirth[2] = '*';
        	sDbirth[7] = '*';
        	sDbirth[8] = '*';
        }
        strcat(iengine," ");
        
        if (flevel != 1)
        {
	        for (n=0;n<2;n++)
	        {
	        	itag[n] = '*';
	        }
	        
	        if(strcmp(trim(nuser),"") != 0)
	        {
	        	strcpy(nuser_pt, nuser);
	        	strcpy(nuser,substring(nuser_pt,1,2));
	        	strcat(nuser,"�ݢ�");
	        }  
	        
	        num = strlen(rtrim(iengine));
	        for (n=num; n>num-5; n--)
	        {
	        	iengine[n] = '*';
	        }
	        strcat(iengine," ");
	    }
        
        strcpy(dbirth, trim(sDbirth) );
        
        car703_print_appl();
    }
    $close curAC;
    $free curAC;
    
} /*  end three database    */

    
    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;  
}

/*--------------------------------------------------------------------*/
long car703_body()
{   
int   rc,i;
char  iins_str[4][7];

    $whenever sqlerror goto errexit;

    if (strncmp(dtype,"1",1)==0)
        strcpy(tit_dtype,"ñ����");
    else if (strncmp(dtype,"2",1)==0)
        strcpy(tit_dtype,"������");
	else
		strcpy(tit_dtype,"���Ĥ��");
	
    rgu_put_body_string(1, tit_dtype, 1);
	
	if(strncmp(dtype,"1",1)==0 || strncmp(dtype,"2",1)==0)
	{
		rgu_put_body_string(1, dbgn1, 1);
		rgu_put_body_string(1, dend1, 1);
	}
	else
	{
		rgu_put_body_string(1, dvalid1, 1);
		rgu_put_body_string(1, " ", 1);
	}
	
    
    rgu_put_body_string(1, cm_get_sysd(), 1);
    rgu_put_body(1);
    max_cnt = 1;

   printf("ptype[%s]\n", ptype);
   
   /*1050105002_C1 �T���~���ը�����X�O�I*/
   /*1070129003_SC1_�s�W���ءB�j���O����*/
  if ((ptype[0]=='2') || (ptype[0]=='3') || (ptype[0]=='4') || (ptype[0]=='5')){ /* ��� �� �q�ʦۦ樮 �� ���ը� �� �S�w���� */
puts("���");
      rc = car703_accumulate2();
      return rc;
  }

  if(falldb[0]=='Y')
  {
    printf("  ���v��              ���v��      \n");
    if (strcmp(trim(iins_type),"A1")==0) { /* �����I */
       $declare cur_ins cursor for
	 select iins_type
	   from insurance_type
	  where qserial = 1
	  order by 1;
       $open cur_ins;
       while(1) {
	  $fetch cur_ins into $iins_type;
	  if (SQLCODE==SQLNOTFOUND) break;
          rc = car703_accumulate1();
          if (rc != M_CM_OK)
              return rc;
       }
       $close cur_ins;
       $free cur_ins;
    }
    else { 
       rc = car703_accumulate1();
       if (rc != M_CM_OK)
           return rc;
    }
 }
 else
 {
        printf("       �S�v��        �S�v��         �S�v��    \n");
    if (strcmp(trim(iins_type),"A1")==0) {
       $declare cur_ins1 cursor for
	 select iins_type
	   from insurance_type
	  where qserial = 1
	  order by 1;
       $open cur_ins1;
       while(1) {
	  $fetch cur_ins1 into $iins_type;
	  if (SQLCODE==SQLNOTFOUND) break;
          rc = car703_accumulate();
          if (rc != M_CM_OK)
              return rc;
       }
       $close cur_ins1;
       $free cur_ins1;
    }
    else { 
       rc = car703_accumulate();
       if (rc != M_CM_OK)
           return rc;
   }
        
}
 
    return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car703_heading()
{
    $whenever sqlerror goto errexit;

    $select nins_type
       into $Nins_type
       from insurance_type
      where iins_type = $iins_type;
	  
	if(strlen(userid2) == 7)
		strcat(Nins_type, "\n");

    rgu_put_body_string(2, iins_type, 1);
    rgu_put_body_string(2, Nins_type, 1);
    rgu_put_body(2);
    rgu_put_body(3);
	if(strlen(userid2) == 7)
	{
		rgu_put_body(61);
		rgu_put_body_string(61, "\n", 1);
	}

    max_cnt += 3;
    
    return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car703_heading_appl()
{
    $whenever sqlerror goto errexit;

    if (strlen(rtrim(iappl)) != 0 || strlen(rtrim(nappl)) != 0) {
    	rgu_put_body_string(21, iappl, 1);
    	rgu_put_body_string(21, nappl, 1);
    	rgu_put_body(21);
    }
    rgu_put_body(31);
    max_cnt += 3;
    
    return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car703_heading_pro()
{
    $whenever sqlerror goto errexit;

    
    
    rgu_put_body_string(51, provision_a, 1);
    rgu_put_body_string(51, provision_b, 1);
    
    rgu_put_body(51);
    rgu_put_body(3);
    max_cnt += 3;
    
    return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
void car703_print()
{
   char str1[20],str2[20];
   char str[20];
   char cat_iengine[CA_ENGINE_NUM+5],cat_itag[CA_TAG_NUM+1],cat_iassured[14],cat_ibrand[10],cat_icar_type[12],cat_ileader[20],cat_nbrand[32],cat_iply_area[10];
   char tmp_buf[16];
   
   sprintf(cat_iengine,"=\"%s\"",iengine);/*������*/  
   sprintf(cat_itag,"\'%s",itag);/*����*/
   strcpy(iassured, trim(iassured));
   sprintf(cat_iassured,"=\"%s\"",iassured);/*�Q�O�HID*/
   sprintf(cat_ibrand,"=\"%s\"",ibrand);/*�t�N*/
   sprintf(cat_nbrand,"\'%s",nbrand);/*�t�N*/
   sprintf(cat_icar_type,"=\"%s\"",Icar_type);/*����*/
   sprintf(cat_ileader,"=\"%s\"",Ileader);/*�޲z�H*/
   
   strcpy(iply_area, trim(iply_area));
   sprintf(cat_iply_area, "=\"%s\"", iply_area); /*�ӫO�a�ϥN��*/
   
   rgu_put_body_string(4, Ipolicy, 1);
   rgu_put_body_string(4, icard, 1);/*1060317003_C1  �W�[���  �O�d���B�q�l�O����O�B�q�l�O��H�eEMAIL*/
   rgu_put_body_string(4, Nassured, 1);
   rgu_put_body_string(4, Ndeputy_assured, 1);/*1120614002_C01�s�W���"�Q�O�I�H���k�H�N���H"*/
   rgu_put_body_string(4, cat_icar_type, 1);
   rgu_put_body_string(4, Iofficer, 1);
   rgu_put_body_string(4, nofficer, 1);
   rgu_put_body_string(4, cat_ileader, 1);
   rgu_put_body_string(4, nply_area, 1); /* 1130416006_C01 �s�W��� "�ӫO�a�ϦW��" */
   rgu_put_body_string(4, cat_iply_area, 1); /* 1130416006_C01 �s�W��� "�ӫO�a�ϥN��" */
   rgu_put_body_string(4, Ibig_office, 1);
   rgu_put_body_string(4, trim(ibig_sales), 1);
   strcpy(s_name,trimx(s_name));
   rgu_put_body_string(4, trimx(s_name), 1);

   strcpy(introducer,trim(introducer));
   rgu_put_body_string(4, introducer, 1);  /*�q�����u�N��*/
   strcpy(ntroducer,trim(ntroducer));
   rgu_put_body_string(4, ntroducer, 1);   /*�q�����u�m�W*/
   strcpy(iroute,trim(iroute));
   rgu_put_body_string(4, iroute, 1);      /*�q���N��*/
   rgu_put_body_string(4, trim(nroute), 1);      /*�q���N������*/

   strcpy(str1,cm_edate_str(Dpolicy));
  /* rfmtdate(dpolicy,"-----------&", str1); */
   rgu_put_body_string(4, str1, 1);
   strcpy(str2,cm_edate_str(Dply_begin));
  /* rfmtdate(dply_begin,"-----------&", str2); */
   rgu_put_body_string(4, str2, 1);
   strcpy(str2,cm_edate_str(Dply_end));
   rgu_put_body_string(4, str2, 1);
   rgu_put_body_string(4, Mdmg_prem, 1);
   rgu_put_body_string(4, Mlia_prem, 1);
   rgu_put_body_string(4, Mins_premium, 1);
   rgu_put_body_string(4, minjured_cover_c , 2);  /*�O�B�@*/
   rgu_put_body_string(4, mdeath_cover_c , 2);    /*�O�B�G*/
   rgu_put_body_string(4, mdamage_cover_c , 2);   /*�O�B�T*/
   rgu_put_body_string(4, Nbranch, 1);
   rgu_put_body_string(4, iissue_ym, 1);
   rgu_put_body_string(4, ipro_year, 1);
   rgu_put_body_string(4, qpro_month, 1);
   rgu_put_body_string(4, cat_iengine, 1);
   rgu_put_body_string(4, cat_itag,    1);
   /*1081211003_SC1_�s�WCAR703�O��Ʈ�q���*/
   rgu_put_body_string(4, qcylinder , 1);
   rgu_put_body_string(4, cat_ibrand , 1);
   rgu_put_body_string(4, cat_nbrand , 1);
   rgu_put_body_string(4, nname , 1);
   /* rgu_put_body_string(4, ncode, 1); */
   
   rgu_put_body_string(4, nentry, 1);		   /*��J�H��*/
   rgu_put_body_string(4, dentry, 1);		   /*��J���*/
   rgu_put_body_string(4, nuser, 1);		   /*�ϥΤH*/

   rgu_put_body_string(4,F_ncode,1);
   
   rgu_put_body_string(4, trim(iroute_accept), 1); /*���z�s��*/
   rgu_put_body_string(4, trim(dpay), 1);          /*���O��*/
   
   rgu_put_body_string(4,trim(itel),1);
   rgu_put_body_string(4,trim(tphone_con),1);
   rgu_put_body_string(4,trim(imovephone),1);
   rfmtlong(pdiscount, "------&", tmp_buf);
   rgu_put_body_string(4, tmp_buf, 1);

    if(strcmp(fedr_class,"1")==0)
    { 
         rgu_put_body_string(4,"���P",1);
         rgu_put_body_string(4,dendorse,1);
    }
    else if((strcmp(fedr_status,"1")==0) || (strcmp(fedr_status,"2")==0) ||
            (strcmp(fedr_status,"3")==0))
    {
         rgu_put_body_string(4,"�h�O",1);
         rgu_put_body_string(4,ply_dendorse,1);
    }  
    else
    { 
      rgu_put_body_string(4," ",1);
      rgu_put_body_string(4," ",1);
    }

    rgu_put_body_string(4, ao_note , 1);
    rgu_put_body_string(4, sFS_ins , 1);
    
    /* �s�W5�����:��O���B�Q�O�HID�B�X�ͤ���B�����ƶq�B�Ӹ���� add by sylvia 105.11.10 (1051007002_C1) */
    strcpy(ilast_ply,trim(ilast_ply));
    rgu_put_body_string(4, ilast_ply , 1);
    
    rgu_put_body_string(4, cat_iassured , 1);
    
    strcpy(dbirth,trim(dbirth));
    rgu_put_body_string(4, dbirth , 1);
    

    
    rgu_put_body_string(4, qpt , 1);
    rgu_put_body_string(4, fpt , 1);
    
    /*1090115015_SC1_�t�X���έp�q�lñ�p�ϥβv�ACAR703�s�W2�����*/
    rgu_put_body_string(4, fesign , 1);
    rgu_put_body_string(4, iscan_no , 1);
    
    /*1060317003_C1  �W�[���  �O�d���B�q�l�O����O�B�q�l�O��H�eEMAIL*/
    strcpy(feply,trim(feply));
    if(strcmp(feply,"1")==0)
    {
    	rgu_put_body_string(4,"Y",1);
    }
    else
    {
    	rgu_put_body_string(4,"N",1);
    }
    rgu_put_body_string(4, aemail_eply , 1);
    /*1080402 �W�[��� ����ߴګY�ơB���d�ߴګY��*/
    rgu_put_body_string(4 , Pdmg_acc , 1);
    rgu_put_body_string(4 , Plia_acc , 1);
    
    /*1080409 �W�[��� ����(�d)��T�~�O�_�X�I�A�P�_�O�_�j���I*/  
    strcpy(fcard_class,trim(fcard_class));
    if(strcmp(fcard_class,"1") == 0 )
    {
    	rgu_put_body_string(4 , "X" , 1);
    	rgu_put_body_string(4 , "X" , 1);
    }
    else
    {
    	strcpy(qdmg_acc_sum,trim(qdmg_acc_sum));
    	if(strcmp(qdmg_acc_sum,"0") == 0 )
	{
		rgu_put_body_string(4 , "N" , 1);
	}
	else 
	{
	    	rgu_put_body_string(4 , "Y" , 1);
	}
	strcpy(qlia_acc_sum,trim(qlia_acc_sum));
	if(strcmp(qlia_acc_sum,"0") == 0 )
	{
		rgu_put_body_string(4 , "N" , 1);
	}
	else 
	{
	    	rgu_put_body_string(4 , "Y" , 1);
	}
    }
	
	/*1121004 �W�[�U�I�ۯd���B���*/
	if(strncmp(dtype,"1",1)==0 || strncmp(dtype,"2",1)==0)
	{
		rgu_put_body_string(4, "X", 1);
	}
	else
	{
		/*if(mret_prem == 0)
		{
			strcpy(str, "0");
			str[1] = '\0';
		}
		else*/
			rfmtdouble(mret_prem,"---,---,--&", str);
		
		rgu_put_body_string(4, str, 1);
	}
	
  /* for(i=1;i<17;i++) */
  for(i=1;i<12;i++)
  {
 printf(" 271 ipolicy=[%s]  i=[%d]  tcode[i]=[%s] \n",Ipolicy,i,tcode[i]);
	
	/*if(i == 11/* && strlen(userid2) == 7)
	{
		strcat(tcode[i], "\n");
	}*/
 
    rgu_put_body_string(4,tcode[i],LEFT);
   }
     
	 if(strlen(userid2) == 7)
	 {
		rgu_put_body(61);
		rgu_put_body_string(61, "\n", 1);
	 }
	 
	 
    
printf(" end of print\n");
     rgu_put_body(4);
     max_cnt++;
   
     
}

/*--------------------------------------------------------------------*/
void car703_print_appl()
{
   char str1[20],str2[20];
   char cat_iengine[CA_ENGINE_NUM+5],cat_itag[CA_TAG_NUM+3],cat_iassured[17],cat_ibrand[12],cat_icar_type[6],cat_ileader[14],cat_nbrand[32],cat_iply_area[10];
   char tmp_buf[16];
   
   sprintf(cat_iengine,"=\"%s\"",iengine);/*������*/  
   sprintf(cat_itag,"\'%s",itag);/*����*/
   strcpy(iassured, trim(iassured));
   sprintf(cat_iassured,"=\"%s\"",iassured);/*�Q�O�HID*/
   sprintf(cat_ibrand,"=\"%s\"",ibrand);/*�t�N*/
   sprintf(cat_nbrand,"\'%s",nbrand);/*�t�N*/
   sprintf(cat_icar_type,"=\"%s\"",Icar_type);/*����*/
   sprintf(cat_ileader,"=\"%s\"",Ileader);/*�޲z�H*/ 
   
   strcpy(iply_area, trim(iply_area));
   sprintf(cat_iply_area, "=\"%s\"", iply_area); /*�ӫO�a�ϥN��*/
   
   rgu_put_body_string(41, Ipolicy, 1);
   rgu_put_body_string(41, icard, 1);/*1060317003_C1  �W�[���  �O�d���B�q�l�O����O�B�q�l�O��H�eEMAIL*/
   rgu_put_body_string(41, Nassured, 1);
   rgu_put_body_string(41, Ndeputy_assured, 1);/*1120614002_C01�s�W���"�Q�O�I�H���k�H�N���H*/
   rgu_put_body_string(41, cat_icar_type, 1);
   rgu_put_body_string(41, Iofficer, 1);
   rgu_put_body_string(41, nofficer, 1);
   rgu_put_body_string(41, cat_ileader, 1);
   rgu_put_body_string(41, nply_area, 1); /* 1130416006_C01 �s�W��� "�ӫO�a�ϦW��" */
   rgu_put_body_string(41, cat_iply_area, 1); /* 1130416006_C01 �s�W��� "�ӫO�a�ϥN��" */
   rgu_put_body_string(41, Ibig_office, 1);
   rgu_put_body_string(41, trim(ibig_sales), 1);
   strcpy(s_name,trimx(s_name));
   rgu_put_body_string(41, s_name, 1);
   
   strcpy(introducer,trim(introducer));
   rgu_put_body_string(41, introducer, 1);    /*�q�����u�N��*/
   strcpy(ntroducer,trim(ntroducer));
   rgu_put_body_string(41, ntroducer, 1);     /*�q�����u�m�W*/
   strcpy(iroute,trim(iroute));
   rgu_put_body_string(41, iroute, 1);        /*�q���N��*/
   rgu_put_body_string(41, trim(nroute), 1);        /*�q���N������*/

   strcpy(str1,cm_edate_str(Dpolicy));
   rgu_put_body_string(41, str1, 1);
   strcpy(str2,cm_edate_str(Dply_begin));
   rgu_put_body_string(41, str2, 1);
   strcpy(str2,cm_edate_str(Dply_end));
   rgu_put_body_string(41, str2, 1);
   rgu_put_body_string(41, Mdmg_prem, 1);
   rgu_put_body_string(41, Nbranch, 1);
   rgu_put_body_string(41, iissue_ym, 1);
   rgu_put_body_string(41, ipro_year, 1);
   rgu_put_body_string(41, qpro_month, 1);
   rgu_put_body_string(41, cat_iengine, 1);
   rgu_put_body_string(41, cat_itag,    1);
   /*1081211003_SC1_�s�WCAR703�O��Ʈ�q���*/
   rgu_put_body_string(41, qcylinder , 1);
   rgu_put_body_string(41, cat_ibrand , 1);
   rgu_put_body_string(41, cat_nbrand , 1);
   rgu_put_body_string(41, nname , 1);
   /* rgu_put_body_string(41, ncode, 1); */
   
   rgu_put_body_string(41, nentry, 1);		   /*��J�H��*/
   rgu_put_body_string(41, dentry, 1);		   /*��J���*/
   rgu_put_body_string(41, nuser, 1);		   /*�ϥΤH*/

   rgu_put_body_string(41,F_ncode,1);
   
   rgu_put_body_string(41,trim(iroute_accept),1);  /*���z�s��*/
   rgu_put_body_string(41,trim(dpay),1);           /*���O��*/
   
   rgu_put_body_string(41,trim(itel),1);
   rgu_put_body_string(41,trim(tphone_con),1);
   rgu_put_body_string(41,trim(imovephone),1);

    if(strcmp(fedr_class,"1")==0)
    { 
         rgu_put_body_string(41,"���P",1);
         rgu_put_body_string(41,dendorse,1);
    }
    else
    { 
      rgu_put_body_string(41," ",1);
      rgu_put_body_string(41," ",1);
    }
    
    rgu_put_body_string(41, ao_note , 1);
    rgu_put_body_string(41, sFS_ins , 1);
    
    /* �s�W5�����:��O���B�Q�O�HID�B�X�ͤ���B�����ƶq�B�Ӹ���� add by sylvia 105.11.10 (1051007002_C1) */
    strcpy(ilast_ply, trim(ilast_ply));
    rgu_put_body_string(41, ilast_ply , 1);
    
    
    rgu_put_body_string(41, cat_iassured , 1);
    
    strcpy(dbirth, trim(dbirth));
    rgu_put_body_string(41, dbirth , 1);
    rgu_put_body_string(41, qpt , 1);
    rgu_put_body_string(41, fpt , 1);
    
    /*1090115015_SC1_�t�X���έp�q�lñ�p�ϥβv�ACAR703�s�W2�����*/
    rgu_put_body_string(41, fesign , 1);
    rgu_put_body_string(41, iscan_no , 1);
    
    /*1060317003_C1  �W�[���  �O�d���B�q�l�O����O�B�q�l�O��H�eEMAIL*/
    strcpy(feply,trim(feply));
    if(strcmp(feply,"1")==0)
    {
    	rgu_put_body_string(41,"Y",1);
    }
    else
    {
    	rgu_put_body_string(41,"N",1);
    }
    rgu_put_body_string(41, aemail_eply , 1);

   /*1080402 �W�[��� ����ߴګY�ơB���d�ߴګY��*/
    rgu_put_body_string(41 , Pdmg_acc , 1);
    rgu_put_body_string(41 , Plia_acc , 1);  
    
   /*1080409 �W�[��� ����(�d)��T�~�O�_�X�I�A�P�_�O�_�j���I*/  
    strcpy(fcard_class,trim(fcard_class));
    if(strcmp(fcard_class,"1") == 0 )
    {
    	rgu_put_body_string(41 , "X" , 1);
    	rgu_put_body_string(41 , "X" , 1);
    }
    else
    {
    	strcpy(qdmg_acc_sum,trim(qdmg_acc_sum));
    	if(strcmp(qdmg_acc_sum,"0") == 0 )
	{
		rgu_put_body_string(41 , "N" , 1);
	}
	else 
	{
	    	rgu_put_body_string(41 , "Y" , 1);
	}
	strcpy(qlia_acc_sum,trim(qlia_acc_sum));
	if(strcmp(qlia_acc_sum,"0") == 0 )
	{
		rgu_put_body_string(41 , "N" , 1);
	}
	else 
	{
	    	rgu_put_body_string(41 , "Y" , 1);
	}
    }
    
  /* for(i=1;i<17;i++) */
  for(i=1;i<12;i++)
  {
    rgu_put_body_string(41,tcode[i],LEFT);
  }
    
  
  
    rgu_put_body(41);
    max_cnt++;
}
   
/*--------------------------------------------------------------------*/
long car703_check_id()
{
$char  user_iqu[7],group[4];
$int   fadu,cnt_iqu;

   /* 
      �v���� -- privilege
      ���ٸ�Ʈw falldb =Y �i�d�Ӹ�Ʈw�Ҧ����,�B��������϶�
      �H�U������w���P�@�~��
      �d��       fadu   =0 �i�d�ϥΪ̸ӳ��
      �s�W       fadu   =1 �i�d�ϥΪ̤��Ұ�
      ��       fadu   =2 �i�d�Ӹ�Ʈw�Ҧ���� 
   */
   
   /* �t�X�ӫO�ݨD,�����s�W5�����,�w���Ӹ곡���̨ϥμh���v���P�_�O�_�B�n
   
      �ϥμh���v��flevel = '0'  �Q�O�I�HID�B�ͤ鶷�B�n
                  flevel = '1'  �Q�O�I�HID�B�ͤ餣�B�n 
                  
        add by sylvia 105.11.10 (1051007002_C1) */
      
      
   strcpy(Astmp," ");

   $select falldb,fadu, flevel
      into $falldb,$fadu, $flevel
      from privilege
     where iemp = $userid
       and ipgid = 'car703';
   if (SQLCODE==SQLNOTFOUND) {
      strcpy(falldb,"N");
      fadu = 0;
      flevel = 0;
   }
   printf("falldb[%s]fadu[%d]\n",falldb,fadu);
   if (falldb[0]=='Y')  return M_CM_OK;
   if (strncmp(dbgn2,dend2,5)!=0) {
      strcpy(msgbuf,"����϶����w�P�@�Ӥ�,�Э��s��J���");
      EWRITE(userid,10,msgbuf);
      return 10;
   }
   if (fadu >= 2) return M_CM_OK;
   if (strncmp(icode,"*",1)==0) {
      strcpy(msgbuf,"�L�d�ߥ������v��,�п�J�S�w���θg��N��"); 
      EWRITE(userid,20,msgbuf);
      return 20;
   }
   $select iquota,group2
      into $user_iqu,$group
      from officer a,sa_branch_type b
     where iofficer = $userid
       and iquota = b.ibranch;
   if (SQLCODE==SQLNOTFOUND) {
      strcpy(msgbuf,"�ϥΪ̥N���D�g��N��,�L�k�d�߸��");
      EWRITE(userid,30,msgbuf);
      return 30;
   }
   if (fadu == 1) {
      if (ctype[0]=='1') {
         $select count(*) into $cnt_iqu
            from sa_branch_type
           where group2 = $group
             and ibranch matches $icode; 
         if (cnt_iqu ==0) {
            strcpy(msgbuf,"�L�v���d�ߨ�L��줧���");
            EWRITE(userid,40,msgbuf);
            return 40;
         }
      }
      else {
         sprintf(Astmp,"and a.iquota in (select ibranch from sa_branch_type \
                       where group2 = '%s') ",group); 
      }
   }
   else {
      if (ctype[0]=='1') {
         if (strncmp(icode,user_iqu,4)!=0) {
            strcpy(msgbuf,"�L�v���d�ߨ�L��줧���");
            EWRITE(userid,40,msgbuf);
            return 40;
         }
      }
      else {
         sprintf(Astmp,"and a.iquota[1,4] = '%s' ",substring(user_iqu,1,4));
      }
   }

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

long car703_email()
{
	$char mail_subject[128], mail_msg[512];
	$char cmd_stmt[1024], msgbuf[512];
	$char cmd_car140[1024], receiver_name[20], receiver_email[128];
	$loc_t ctxt;
	char aphome[40];
	int rc, res;
	
	res = getApHome(aphome);
    if (res<0)
	{
      EWRITE(userid, -1, "In sigalrmcatcher func==>read config file error!!");
      return FAIL;
	}
	
	sprintf(cmd_stmt, "mv %s/batchfile/%s %s/rptftp/car_email/%s;", aphome, BodyFile, aphome, BodyFile);
	
	rc = system(cmd_stmt);
    if (rc != 0) {
        printf("mv file���~\r\n");
        sprintf(msgbuf,"mv file���~\r\n");
        return rc;
    }
		
	sprintf(mail_subject, "(%s)�ӫO���s�����I�ӫ~�ֿn���Ħۯd�O�B�q��(%s�I��)", dvalid1, iins_type); /*�H��D��*/
	sprintf(mail_msg, "���q���ӫO���s�����I�ӫ~�ֿn���Ħۯd�O�B�q���Ԧp���ɡC\n"); /*�H�󤺤�*/
	
	ctxt.loc_loctype = LOCMEMORY;
    ctxt.loc_buffer = mail_msg;
    ctxt.loc_bufsize = 9000;
    ctxt.loc_size =  strlen(mail_msg) + 1;
	
	sprintf(cmd_car140, "SELECT chinese_name, trim(a.email)||'@tmnewa.com.tw' "
	                    "  FROM personal:asempl a, car_code b "
                        " WHERE a.empl_no = b.detail2 "
                        "   AND b.kind = '71' ");
	
	$WHENEVER SQLERROR GOTO errexit;
	
	$PREPARE prep_car140 FROM $cmd_car140;
	$DECLARE curs_car140 CURSOR FOR prep_car140;
	$OPEN curs_car140;
	
	while(1)
	{
		$FETCH curs_car140 INTO $receiver_name, $receiver_email;
		
		if( SQLCODE == SQLNOTFOUND ) break;
		
		$INSERT INTO batchemail
    	  (project_id, mail_date, receiver_email, receiver_name, cc,
    	   content, key, mail_count, nsubject ,nattachment)
		VALUES
    	  ('CAR703', today+1, $receiver_email, $receiver_name, " ",
           $ctxt, $BodyFile, 1 , $mail_subject, $BodyFile);
	}

	$FREE  prep_car140;
	$CLOSE curs_car140;

	return M_CM_OK;

errexit:
	printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;  
	
}
/*---------------------------------------------------------end program*/
/* �֪@�O��ĤG�~�����I */
static GetFS_DMG(sIcard_A,sIpolicy_A1,sDMG)
$char *sIcard_A,*sDMG,*sIpolicy_A1;
{
   $char sIcard[21], sIpolicy_A[21], sIpolicy_A2[21],
         sLast_ply[21],sInext_ply[21],sNeq87[31];
   $char FSDBName[51],stmt[1000];
   $int x1;
   
   $WHENEVER SQLERROR GOTO opt3_err;
   
   strcpy(sIcard, trim(sIcard_A));  /* A��d�� */
   
   
   printf("-GetFS_DMG start-- sIcard=[%s] sIpolicy_A1=[%s]--- \n",sIcard,sIpolicy_A1);

   strcpy(sDMG," ");
   
   if (strlen(sIcard) < 5)
      strcpy(sIpolicy_A, trim(sIpolicy_A1));    /* �LA��d��,�����H�O�渹�N�� */
   else
   {
      /* �HA��d��A�d��O�渹 */
      $SELECT ipolicy into $sIpolicy_A2
         from card
        WHERE icard=$sIcard;
   
      if (SQLCODE==SQLNOTFOUND) 
         strcpy(sIpolicy_A, trim(sIpolicy_A2));    /* �d�LA��d��,�����H�O�渹�N�� */
   }   
      
   sLast_ply[0] = '\0';
   sInext_ply[0] = '\0';
   /* �֪@�M�ץu��5�~ */
   for (x1=1;x1<=5;x1++)
   {
      strcpy(FSDBName, get_car_full_db(sIpolicy_A));
      
      stmt[0]='\0';
      sprintf(stmt,"SELECT a.ilast_ply,a.inext_ply,b.nequipment \
                      FROM %s:ply_relation a, %s:policy b \
                     WHERE a.ipolicy = b.ipolicy and a.ipolicy = '%s'",
                    FSDBName,FSDBName,sIpolicy_A);
      $PREPARE cur_fs1 FROM $stmt;
      $DECLARE fs1 CURSOR FOR cur_fs1;
      $OPEN fs1;
      $FETCH fs1 INTO $sLast_ply,$sInext_ply,$sNeq87;
      if (SQLCODE==SQLNOTFOUND) break;
      $CLOSE fs1;
      $FREE  fs1;
      printf("sIpolicy_A=[%s]sLast_ply=[%s]sInext_ply=[%s]\n",sIpolicy_A,sLast_ply,sInext_ply);
      printf("sNeq87=[%s]\n",sNeq87);
      if (equip_cmp(sNeq87,"87") != TRUE)
      {
         printf("--- �D�֪@ --- \n");
         return SUCCESS;
      }
      
      strcpy(sLast_ply, trim(sLast_ply));
      strcpy(sInext_ply, trim(sInext_ply));
      if ((sLast_ply[0] == '\0') && (sInext_ply[0] == '\0'))
      {
         /* �S���e��O�渹,����O����O���Ĥ@�~A�� */
         printf("-- sIpolicy_A=[%s]�S���e��O�渹,����O����O���Ĥ@�~A�� -- \n",sIpolicy_A);
         break;
      }
      else if(((sLast_ply[0] == '\0') && (sInext_ply[0] != '\0')) ||
              ((sLast_ply[0] == '\0') && (sInext_ply[0] == '\0') && (x == 2)))
      {
         /* ����O�Ĥ@�~A��,inext_ply�O�ĤG�~A�� */
         strcpy(FSDBName, get_car_full_db(sInext_ply));
         stmt[0]='\0';
         sprintf(stmt,"SELECT iins_type FROM %s:ply_ins_type \
                        WHERE ipolicy = '%s' and iins_type in ('01','05','105','118','122') \
                          and mdamage_cover > 0 ",
                       FSDBName,sInext_ply);
         $PREPARE cur_fs2 FROM $stmt;
         $DECLARE fs2 CURSOR FOR cur_fs2;
         $OPEN fs2;
         $FETCH fs2 INTO $sDMG;
         if (SQLCODE==SQLNOTFOUND) 
            strcpy(sDMG," ");
         $CLOSE fs2;
         $FREE  fs2;
         
         printf("-- ����[%s]�O�Ĥ@�~A��,inext_ply[%s]�O�ĤG�~A�� -- \n",sIpolicy_A,sInext_ply);
         printf("-- sInext_ply=[%s] sDMG=[%s] -- \n",sInext_ply,sDMG);
         break;
      }
      else
      {
         /* �ܤ֬O��2�~�H�W,�����T�w�O�ĴX�~,�ҥH�n�Ϋe�O�渹�~���... */
         printf("-- [%s]�ܤ֬O��2�~�H�W,�����T�w�O�ĴX�~,�ҥH�n�Ϋe�O�渹�~���... -- \n",sIpolicy_A);
         strcpy(sIpolicy_A,sLast_ply);
      }
   }
   
    
    printf("sLast_ply=[%s],sIpolicy_A=[%s],sInext_ply=[%s],sDMG=[%s]",
            sLast_ply,sIpolicy_A,sInext_ply,sDMG);
    return SUCCESS;

opt3_err:
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    return SQLCODE;
}

char *get_nply_area(iply_area)
char *iply_area;
{
	static char ply_name[15];
	strcpy(ply_name, "");
	printf("iply_area = [%s]\n", iply_area);
	
	if(strcmp(trim(iply_area), "01") == 0)
	{
		strcpy(ply_name,"�x�_��");
	}
	else if(strcmp(trim(iply_area), "06") == 0)
	{
		strcpy(ply_name,"�s�_��");
	}
	else if(strcmp(trim(iply_area), "11") == 0)
	{
		strcpy(ply_name,"�򶩥�");
	}
	else if(strcmp(trim(iply_area), "12") == 0)
	{
		strcpy(ply_name,"�y������");
	}
	else if(strcmp(trim(iply_area), "13") == 0)
	{
		strcpy(ply_name,"��饫");
	}
	else if(strcmp(trim(iply_area), "14") == 0)
	{
		strcpy(ply_name,"�s�˿���");
	}
	else if(strcmp(trim(iply_area), "15") == 0)
	{
		strcpy(ply_name,"�]�߿�");
	}
	else if(strcmp(trim(iply_area), "41") == 0)
	{
		strcpy(ply_name,"�x����");
	}
	else if(strcmp(trim(iply_area), "43") == 0)
	{
		strcpy(ply_name,"�n�뿤");
	}
	else if(strcmp(trim(iply_area), "44") == 0)
	{
		strcpy(ply_name,"���ƿ���");
	}
	else if(strcmp(trim(iply_area), "45") == 0)
	{
		strcpy(ply_name,"���L��");
	}
	else if(strcmp(trim(iply_area), "61") == 0)
	{
		strcpy(ply_name,"�Ÿq����");
	}
	else if(strcmp(trim(iply_area), "62") == 0)
	{
		strcpy(ply_name,"�x�n��");
	}
	else if(strcmp(trim(iply_area), "64") == 0)
	{
		strcpy(ply_name,"������");
	}
	else if(strcmp(trim(iply_area), "66") == 0)
	{
		strcpy(ply_name,"�̪F����");
	}
	else if(strcmp(trim(iply_area), "67") == 0)
	{
		strcpy(ply_name,"���");
	}
	else if(strcmp(trim(iply_area), "81") == 0)
	{
		strcpy(ply_name,"�Ὤ����");
	}
	else if(strcmp(trim(iply_area), "82") == 0)
	{
		strcpy(ply_name,"�x�F����");
	}
	else if(strcmp(trim(iply_area), "90") == 0)
	{
		strcpy(ply_name,"������");
	}
	else if(strcmp(trim(iply_area), "91") == 0)
	{
		strcpy(ply_name,"�s����");
	}
	else
	{
		strcpy(ply_name, "");
	}
	
	printf("ply_name = [%s]\n", ply_name);
	
	return ply_name;
}

char* trimx (char *str)
{
      char *ibuf, *obuf;

      if (str)
      {
            for (ibuf = obuf = str; *ibuf; )
            {
                  while (*ibuf && (isspace (*ibuf)))
                        ibuf++;
                  if (*ibuf && (obuf != str))
                        *(obuf++) = ' ';
                  while (*ibuf && (!isspace (*ibuf)))
                        *(obuf++) = *(ibuf++);
            }
            *obuf = '\0';
      }
      return (str);
}
