/************************************************/
/*                                              */
/*   PROGRAM : car174.ec
/*                                              */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;
$include decimal;
#include "safeclib.h"


long car174(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car174_insert(),car174_single_query(),car174_multiple_query(),car174_update_exec();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'A':
	   rtncode=car174_insert(reply);
	   break;
  case 'Q':
	   rtncode=car174_single_query(reply);
	   break;
  case 'M':
           rtncode=car174_multiple_query(reply);
	   break;
  case 'D':
  case 'U':
	   rtncode=car174_update_exec(reply,command,com_len);
	   break;
  default :
	   if(exitsub(reply,M_CM_WRONG_OPTION) == True)
	    return M_CM_WRONG_OPTION;
           return apiRC;
 }
 printf("rtncode[%d]\n",rtncode);
 return(rtncode);
}

long car174_insert(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */
 
 /* table ca_provision_main */
 $char iprovision[7], nprovision[41],nprint[41],ncar[21],fset[2],dactive[21],dexpire[21],dactive_sys[21],dexpire_sys[21];
 $char userid[11];
 /* end of ca_provision_main */

 /* standard defined data */
 int tmp_len;
   DBinfo *list;
   int i, j, is_add_fail=0, api_f;
   $char stmt_buf[2000],stmtx[2000];
 /* end of standard data */

 /* self defined data */
 long MsgCode;
 /* end of self data */

 int LiBufLen;
 cm_buf_get("%s",DBName);
 cm_buf_get("%s %s %s %s %s %s %s %s %s %s",iprovision,nprovision,nprint,ncar,fset,dactive,dexpire,dactive_sys,dexpire_sys,userid);
 
 strcpy(dactive,cm_to_infdate(dactive));
 strcpy(dexpire,cm_to_infdate(dexpire));
 strcpy(dactive_sys,cm_to_infdate(dactive_sys));
 strcpy(dexpire_sys,cm_to_infdate(dexpire_sys));

 $WHENEVER SQLERROR GOTO errexit;
 
 if (db_select(DBName) == False)
	return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

 $BEGIN WORK;
 $WHENEVER SQLERROR GOTO errexit;

	$INSERT INTO ca_provision_main
	       ( iprovision, nprovision, nprint, ncar, fset, dactive, dexpire, dactive_sys, dexpire_sys, icreate, dcreate, iupdate, dupdate)
	VALUES ($iprovision,$nprovision,$nprint,$ncar,$fset,$dactive,$dexpire,$dactive_sys,$dexpire_sys,$userid,current,$userid,current);

 cm_buf_init(ReplyBuf);
 cm_buf_put("%l",M_CM_OK);
 LiBufLen = cm_buf_len(ReplyBuf);

 if(SendSyncReply(reply,ReplyBuf,LiBufLen,api_OKComplete) == False)
 {
	$WHENEVER SQLERROR CONTINUE;
	$ROLLBACK WORK;
	return apiRC;
 }


 $WHENEVER SQLERROR GOTO errexit;
 $COMMIT WORK;
 return api_OKComplete;

 errexit:
 printf(" sqlerrm = %s\n",sqlca.sqlerrm);
 $WHENEVER SQLERROR CONTINUE;
 MsgCode = SQLCODE;
 $ROLLBACK WORK;
 if (SQLCODE != 0) MsgCode = SQLCODE;
 return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

long car174_single_query(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table ca_provision_main */
 $char iprovision[7], nprovision[41],nprint[41],ncar[21],fset[2],dactive[21],dexpire[21],dactive_sys[21],dexpire_sys[21];
 $char icreate[11], dcreate[21], iupdate[11], dupdate[21];
 $dec_t dec;
 /* end of ca_provision_main */

 /* standard defined data */
 int tmp_len;
 /* end of standard data */


 cm_buf_get("%s",DBName);
 cm_buf_get("%s %s",iprovision,nprovision);
 
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False) 
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

 $SELECT iprovision,nprovision,nprint,ncar,fset,dactive,dexpire,dactive_sys,dexpire_sys, icreate, dcreate, iupdate, dupdate

       /*(select nname from officer where iofficer = a.icreate),
         (select nname from officer where iofficer = a.iupdate)*/
         
  INTO $iprovision, $nprovision, $nprint, $ncar, $fset, $dactive, $dexpire, $dactive_sys, $dexpire_sys, $icreate, $dcreate, $iupdate, $dupdate
  FROM ca_provision_main
  WHERE iprovision=$iprovision;

 printf("155\n");
 if(SQLCODE == SQLNOTFOUND) 
 {
 	printf("158\n");
    if(exitsub(reply,M_CM_NOT_FOUND) == True)       /*?*/
			return M_CM_NOT_FOUND;                        /*?*/
		else
			return apiRC;
 }

 strcpy(dactive,cm_from_infdate_100(dactive));
 strcpy(dexpire,cm_from_infdate_100(dexpire));
 strcpy(dactive_sys,cm_from_infdate_100(dactive_sys));
 strcpy(dexpire_sys,cm_from_infdate_100(dexpire_sys));
 
 cm_buf_init(ReplyBuf); 
 cm_buf_put("%l",M_CM_OK);
 cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %s %s",
 iprovision, nprovision, nprint, ncar, fset, dactive, dexpire, dactive_sys, dexpire_sys, icreate, dcreate, iupdate, dupdate);
 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
  return apiRC;
 else
  return api_OKComplete;

 errexit:
  if(exitsub(reply,SQLCODE) == True) 
   return SQLCODE;
  else  
   return apiRC;
}

long car174_multiple_query(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table ca_provision_main */
 $char iprovision[7], nprovision[41],nprint[41],ncar[21],fset[2],dactive[21],dexpire[21],dactive_sys[21],dexpire_sys[21];
 $char userid[11];
 $char keyclass[2];
 $dec_t dec;
 $char sTmp1[1024], sTmp2[100],rate[7];
 $char sTmp3[100];
 /* end of ca_provision_main */

 /* standard defined data */
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0; 
 /* end of standard data */


 char pbegin[10];
 int flag;

 cm_buf_get("%s",DBName);
 cm_buf_get("%s %s",iprovision,nprovision);

 keyclass[1] = '\0';

	if (strcmp(iprovision, "*") == 0)
	{
		strcpy(sTmp2, "");
	}
	else
	{
		/* strcpy(iprovision, cm_to_infdate(iprovision)); */
		sprintf_s(sTmp2, sizeof sTmp2, " and iprovision matches '%s' ", iprovision);
		printf("iprovision=[%s]sTmp2=[%s]\n",iprovision,sTmp2);
	}
	if (strcmp(nprovision, "*") == 0)
	{
		strcpy(sTmp3, "");
	}
	else
	{
		/* strcpy(iins_type, cm_to_infdate(iins_type)); */
		sprintf_s(sTmp3, sizeof sTmp3, " and nprovision matches '%s' ", nprovision);
		printf("nprovision=[%s]sTmp3=[%s]\n",nprovision,sTmp3);
	}
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
    return M_CM_DB_NOTOPEN;
   else
    return apiRC;
  }

  flag =0 ;

    sprintf_s(sTmp1, sizeof sTmp1,
    	   "SELECT iprovision, nprovision "
           " FROM ca_provision_main "
    	   " WHERE 1=1 %s %s "
           " ORDER BY iprovision;", sTmp2, sTmp3);
    printf("sTmp1=[%s]\n",sTmp1);

		$PREPARE m0_pre FROM $sTmp1;
		$DECLARE m0_cur  CURSOR FOR m0_pre;
    $OPEN m0_cur;


 for(;;)
  {

     $FETCH m0_cur into $iprovision, $nprovision;

    if (SQLCODE != 0)
         break;

    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();
     }


    cm_buf_put("%s %s", iprovision, nprovision);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
	if ( flag == 0 )
	 $CLOSE m0_cur;
        else
	 $CLOSE m1_cur;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
	 cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
	ReplyBuf[0] = '\0';
	count = 0;
	cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s", iprovision, nprovision);
	repbuf_len = cm_buf_len(ReplyBuf);
	count++;
       }
     }
  } /* for loop */

 if ( flag == 0 )
  $CLOSE m0_cur;
 else
  $CLOSE m1_cur;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
   if(exitsub(reply,M_CM_NOT_FOUND) == True)
    return M_CM_NOT_FOUND;/* M_CA_NDEPRE_RATE */
   else
    return apiRC;
  }

 errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}


long car174_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table ca_provision_main */
 $char iprovision[7], nprovision[41],nprint[41],ncar[21],fset[2],dactive[21],dexpire[21],dactive_sys[21],dexpire_sys[21];
 $char old_iprovision[7], old_nprovision[41],old_nprint[41],old_ncar[21],old_fset[2],old_dactive[21],old_dexpire[21],old_dactive_sys[21],old_dexpire_sys[21];
 $char icreate[11], dcreate[21], iupdate[11], dupdate[21];
 $char old_icreate[11],old_dcreate[21],old_iupdate[11],old_dupdate[21];
 $char userid[11];
 /* end of ca_provision_main */

 /* standard defined data */
 char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
 int tmp_len,raw_len;
 long dummy=0;
   DBinfo *list;
   int i, j=0, is_del_fail=0, is_upd_fail=0;
   $char stmt_buf[1024];
   $char stmt_buf2[1024];
 /* end of standard data */

 /* self defined data */
 long MsgCode;
 /* end of self data */

 comm = (char *) command;
 cm_buf_init(command);
 cm_buf_get("%c %s %s",&option,DBName,userid);

printf("F001     \n");
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
    return M_CM_DB_NOTOPEN;
   else
    return apiRC;
  }

printf("F002     \n");
 if( (list=get_db_list(&i,DBName)) == (char*)0 )
  {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
  }
 /* compare old record and current record, if the record has not been changed
    since last request, update or delete the record, otherwise return errmsg
    to client side */

printf("F003     \n");
 /* get old record info from command buffer */

 memcpy(&raw_len,&comm[com_len],sizeof(int));
 pos = &comm[com_len+sizeof(int)];
 raw_ptr = malloc(raw_len);
printf("F004     \n");
 if (raw_ptr != (char*)0)
  memcpy(raw_ptr,pos,raw_len);
 else
  {
   if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */
    return M_CM_NOT_MALLOC;
   else
    return apiRC;
  }

printf("F005     \n");
 cm_buf_init(raw_ptr);          /* get index key from old record */
 cm_buf_get("%l %s %s",&dummy,old_iprovision, old_nprovision);

printf("F006     \n");
   $BEGIN WORK;
 $SELECT iprovision, nprovision, nprint, ncar, fset, dactive, dexpire, dactive_sys, dexpire_sys, icreate, dcreate, iupdate, dupdate
  INTO $old_iprovision, $old_nprovision, $old_nprint, $old_ncar, $old_fset, $old_dactive, $old_dexpire, $old_dactive_sys, $old_dexpire_sys, 
  		$old_icreate, $old_dcreate, $old_iupdate, $old_dupdate
  FROM ca_provision_main
  WHERE iprovision=$old_iprovision AND nprovision=$old_nprovision;

printf("F007     \n");
  /* if key value has been changed then SQLNOTFOUND,else put current value
     into cur_buf for comparison */

 if (SQLCODE == SQLNOTFOUND)
  {
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(exitsub(reply,M_CM_NOT_FOUND) == True) 
    return SQLNOTFOUND;
   else  
    return apiRC;;
  }
printf("F008     \n");
   $WHENEVER SQLERROR GOTO errexit;

printf("F009     \n");

 strcpy(old_dactive,cm_from_infdate_100(old_dactive));
 strcpy(old_dexpire,cm_from_infdate_100(old_dexpire));
 strcpy(old_dactive_sys,cm_from_infdate_100(old_dactive_sys));
 strcpy(old_dexpire_sys,cm_from_infdate_100(old_dexpire_sys));
 
 cm_buf_init(cur_buf);
 cm_buf_put("%l %s %s %s %s %s %s %s %s %s %s %s %s %s"
            ,dummy,old_iprovision, old_nprovision, old_nprint, old_ncar, old_fset, old_dactive, old_dexpire, old_dactive_sys, old_dexpire_sys, old_icreate,old_dcreate,old_iupdate,old_dupdate);
            
 strcpy(old_dactive,cm_to_infdate(old_dactive));
 strcpy(old_dexpire,cm_to_infdate(old_dexpire));
 strcpy(old_dactive_sys,cm_to_infdate(old_dactive_sys));
 strcpy(old_dexpire_sys,cm_to_infdate(old_dexpire_sys));
 printf("old_dactive : %s\n",old_dactive);
 printf("old_dexpire : %s\n",old_dexpire);
 printf("old_dactive_sys : %s\n",old_dactive_sys);
 printf("old_dexpire_sys : %s\n",old_dexpire_sys);
 
 write(1,cur_buf,raw_len); printf("\n");
 write(1,raw_ptr,raw_len); printf("\n");

 if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
  {
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   free(raw_ptr);
   if(exitsub(reply,M_CM_NOT_EQUAL) == True)
    return M_CM_NOT_EQUAL;
   else
    return apiRC;
  }
   $WHENEVER SQLERROR GOTO errexit;

 /* equal, then exec DB operation */

 if ( option == 'D' )
  {
   /* for(j=0;j<i;j++)
   {
   */
    sprintf_s(stmt_buf, sizeof stmt_buf, "DELETE FROM ca_provision_main WHERE iprovision = ? AND nprovision = ?" );
    $PREPARE d_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_del_fail = 1;
      /* break; */
     }
    $EXECUTE d_id USING $old_iprovision, $old_nprovision;
    if(SQLCODE != 0)
     {
      is_del_fail = 1;
      /* break; */
     }

  if(SQLCODE != 0)
   {
    is_del_fail = 1;
   }

#ifdef DEBUG
printf("Delete %d\n", j+1);
#endif
   /* } for loop */

   if( is_del_fail ) goto errexit;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else if (option == 'U')
  {
/* 9/3/1993    $BEGIN WORK;               */
   cm_buf_init(command);
   cm_buf_get("%c %s %s %s %s %s %s %s %s %s %s %s",&option,DBName, iprovision, nprovision, nprint, ncar, fset, dactive, dexpire, dactive_sys, dexpire_sys, userid);
   
   strcpy(dactive,cm_to_infdate(dactive));
   strcpy(dexpire,cm_to_infdate(dexpire));
   strcpy(dactive_sys,cm_to_infdate(dactive_sys));
   strcpy(dexpire_sys,cm_to_infdate(dexpire_sys));
   printf("dactive : %s\n",dactive);
   printf("dexpire : %s\n",dexpire);
   printf("dactive_sys : %s\n",dactive_sys);
   printf("dexpire_sys : %s\n",dexpire_sys);

   $WHENEVER SQLERROR CONTINUE;
/*
   for(j=0;j<i;j++)
   {
*/
    sprintf_s(stmt_buf, sizeof stmt_buf, "UPDATE ca_provision_main "
   		" SET (iprovision, nprovision, nprint, ncar, fset, dactive, dexpire, dactive_sys, dexpire_sys, iupdate, dupdate) = ('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s',current) "
   		" WHERE iprovision = '%s' AND nprovision = '%s'"
   		,iprovision, nprovision, nprint, ncar, fset, dactive, dexpire, dactive_sys, dexpire_sys, userid,
   		old_iprovision, old_nprovision);
   		
   		printf("stmt_buf[%s]\n",stmt_buf);

    $PREPARE u_id FROM $stmt_buf;

     printf("%s %s %s %s %s %s %s %s %s\n",iprovision, nprovision, nprint, ncar, fset, dactive, dexpire, dactive_sys, dexpire_sys);
     printf("%s %s %s %s %s %s %s %s %s\n",old_iprovision, old_nprovision, old_nprint, old_ncar, old_fset, old_dactive, old_dexpire, old_dactive_sys, old_dexpire_sys);
    $EXECUTE u_id;




     if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      /* break; */
     }

    if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
     {
  	sprintf_s(stmt_buf, sizeof stmt_buf, "INSERT INTO ca_provision_main (iprovision, nprovision, nprint, ncar, fset, dactive, dexpire, dactive_sys, dexpire_sys) "
  	         " VALUES (?,?,?,?,?,?,?,?,?)" );

      $PREPARE ua_id FROM $stmt_buf;
      if(SQLCODE != 0)
       {
        is_upd_fail = 1;
        /* break; */
       }
      $EXECUTE ua_id USING $iprovision,$nprovision,$nprint,$ncar,$fset,$dactive,$dexpire,$dactive_sys,$dexpire_sys;
printf("-----stmt_buf[%s]\n",stmt_buf);
      if(SQLCODE != 0)
       {
        is_upd_fail = 1;
        /* break; */
       }
     }
#ifdef DEBUG
printf("Update %d\n", j+1);
#endif
   /*} for loop */

   if( is_upd_fail ) goto errexit;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else
  {
   if(exitsub(reply,M_CM_WRONG_OPTION) == True)
    return M_CM_WRONG_OPTION;
   else
    return apiRC;
  }

 errexit:
  $WHENEVER SQLERROR CONTINUE;
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True)
   return MsgCode;
  else
   return apiRC;
}