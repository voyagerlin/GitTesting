/**********************************************************************/
/*   program id   : ca639q01s.ec                                      */
/*   program name : ���O�~�Ⱥ޲z                                      */
/*   date written : 2015/02/24 by 030344                              */
/*   files        : ply_relation                                      */
/*                                                                    */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"

#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"
$include decimal;
char delimiter;
int   count_db,k;
$char dentry[11],dentry_s[11];
$char ibranch[7];
$char user_iquota[5];

$char itag_in[CA_TAG_NUM];
$char iengine[CA_ENGINE_NUM];
$char iassured[13];
$char payment[2];

$char chkComp[2];

char  outputf[21];
$char userid[11];
$char DBName[05];
$char txtfile[101];
$char msgbuf[128];
$char iquota[7];
$char option[2];
$char fins_grp[2];
$char falldb[2];
$char bound_type[2];
$char getfile[300];
int offset = 0;
int have_sMsg0,have_sMsg1;
char   sApHome[50];
FILE   *fp;
static char  *bp;
long   rtncode;

$char ipolicy[21],iquota[7],nassured[121],icard[21],ilast_ply[21],itag[CA_TAG_NUM],iengine[CA_ENGINE_NUM],iassured[13];
$char icar_type[3],ibrand[9],iins_type[7],iofficer[11],nofficer[121],ileader[11],nleader[120],qnext[11],nquota[121];
$char iassured1[14],icar_type1[4],iins_type1[8],iofficer1[12];
$char sWhere[256];
$long dpolicy = 0,dply_begin = 0,dply_end = 0;
$char dentry_cond[11],dentry_s_cond[11];
$char bound_num[120],ibound[50],ez_ibound[4],isign[11],dapply[11],ffac[2],nffac[11];
$int  sIns_type,minjured_cover,mdamage_cover,mdeduct,tmp_mdamage_cover,iCount = 0,iins_count;
$char ibrand[9],icar_series[3],tmp_iins_type[8],dissue[5],tmp_ibound[50];
$char bound_nassured[121],bound_itag[CA_TAG_NUM],bound_iengine[CA_ENGINE_NUM],bound_nofficer[121];
$char nbound[1024],tmp_nbound[2048];
$char stmt[4096];
$char stmt_tmp1[2048];
int rc;

DBinfo *list;

main(argc, argv)
int argc;
char **argv;
{

    batchinit();
    strcpy(DBName,    isNULLstr(argv[1]));
    strcpy(userid,    isNULLstr(argv[2]));
    strcpy(txtfile,   isNULLstr(argv[3]));		/*** EasyFlow���O��� ***/
    strcpy(option,    isNULLstr(argv[4]));		/*** 1:�~�Z��� 2:�X����e�T�X ***/
    strcpy(ibranch,   isNULLstr(argv[5]));		/*** �~�Z���ΥX����e�T�X ***/
    strcpy(dentry_s,  isNULLstr(argv[6]));
    strcpy(dentry,    isNULLstr(argv[7]));
    strcpy(bound_type,isNULLstr(argv[8]));		/*** 1:�ӫO���O 2:�Ұϭ��O A:���� ***/
    strcpy(outputf,   isNULLstr(argv[9]));

printf("dentry_s[%s]dentry[%s];ibranch[%s];itag_in[%s];iengine[%s];iassured[%s];\n",dentry_s,dentry,ibranch,itag_in,iengine,iassured);

    rc = car639_get_db();
    if (rc != M_CM_OK)
       return rc;

    rtncode = getApHome(sApHome);
    if (rtncode < 0)
    {
        EWRITE(userid, M_CM_READ_CONFIG_ERR, "read Config file error!!");
        return FAIL;
    }

    rc = get_txt();
    if (rc != M_CM_OK)
       return rc;

    /* Create table car639_tmp1 */
    rc = ca639_create_temp();
    if (rc != M_CM_OK)
       return rc;


printf("falldb=[%s]\n",falldb);

    rc = ca639_branch();
    if (rc != M_CM_OK)
       return rc;

    /*** �ӫO���H���]���Ұϸ�Ʈw ***/
    if(strcmp(user_iquota,"3201") == 0)
    {
	rc = car639_prepare_data_ALL();
    	if (rc != M_CM_OK)
        return rc;
    }
    else
    {
	rc = car639_prepare_data();
    	if (rc != M_CM_OK)
        return rc;
    }

    	/*build report - ����*/
    	rc = car639_build();
    	if (rc != M_CM_OK) {
       	return rc;
    	}
}

void GetData(data, maxlen, delimiter)
char *data, delimiter;
int maxlen;
{
int fori, pre_offset, cnt=0;

    data[0]='\0';
    pre_offset = offset;

    for (fori=pre_offset; bp[fori]!=0x00&&bp[fori]!=0x0d&&bp[fori]!=0x0a&&bp[fori]!=delimiter; fori++)
    {
        offset++;
        if (cnt < maxlen-1)
        {
            data[cnt]=bp[fori];
            cnt++;
        }
    }

    offset++; /* ���ܤU�@�� */
    if (cnt==0) data[cnt++]=0x20; /* �L��Ƶ��ť� */
    data[cnt]=0x00;
    printf("pre_offset[%d]offset[%d]len[%d]data[%s]\n", pre_offset, offset, cnt, data);
}

/*--------------------------------------------------------------------*/
long car639_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }

   if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
      if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
         return M_CM_NOT_DBLIST;
   }

   return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

long car639_prepare_data()
{

   strcpy(dentry_cond,cm_to_infdate(dentry));
   strcpy(dentry_s_cond,cm_to_infdate(dentry_s));


   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == FALSE)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return FAIL;
   }

printf("prepared data, dentry_cond[%s]dentry_s_cond[%s]\n",dentry_cond,dentry_s_cond);

	if( strcmp(trim(option),"1") == 0)
            sprintf_s(sWhere, sizeof sWhere, " and b.iquota matches '%s' ",ibranch);
        else
            sprintf_s(sWhere, sizeof sWhere, " and b.ibranch_in matches '%s' ",ibranch);

printf("sWhere=[%s]\n",sWhere);

	/*******************�̷s�O����***********************/
	 sprintf_s(stmt, sizeof stmt,
		"SELECT b.dpolicy,b.iquota[1,4] || '00' ,a.ipolicy, a.icard,b.ilast_ply,a.nassured, "
		"       a.itag,a.iengine,a.iassured,b.dply_begin,b.dply_end,b.icar_type,b.ibrand,  "
		"       b.iofficer, (SELECT nname FROM officer WHERE iofficer = b.iofficer),  "
		"       b.ileader,(SELECT nname FROM officer WHERE iofficer = b.ileader),  "
		"       CASE WHEN qnext_year = 0 THEN '�s�O' ELSE '��O' END ,   "
		"       a.bound_num, a.ibound            "
		"  FROM policy a,ply_relation b    "
		" WHERE a.ipolicy = b.ipolicy            "
		"   AND b.fcard_class = '2'              "
		"   AND b.dply_close is not null         "
		"   AND a.ibound != ' '                  "
		"   AND b.dpolicy BETWEEN '%s' and '%s'  "
		"   %s                                   "
		,dentry_s_cond,dentry_cond,sWhere);

printf("stmt[%s]\n", stmt);

          $PREPARE pre1_1 FROM $stmt;
          $DECLARE cur_pre1_1 CURSOR for pre1_1;
      	  $OPEN cur_pre1_1;

      	while(1)
      	{
         		$FETCH cur_pre1_1 INTO $dpolicy,$iquota,$ipolicy,$icard,$ilast_ply,$nassured,$itag,$iengine,$iassured,$dply_begin,
         				     $dply_end,$icar_type,$ibrand,$iofficer,$nofficer,$ileader,$nleader,$qnext,$bound_num,$ibound;

         		if(SQLCODE == SQLNOTFOUND) break;

		have_sMsg0 = 0;
		have_sMsg1 = 0;
		
		/*** ���O���� ***/
		
		if(strSearchReplace(ibound,"A","A")>0)
			have_sMsg1 = 1;
		
		if(strSearchReplace(ibound,"B","B")>0)
			have_sMsg0 = 1;

          	/*** ���W�� ***/
 		$SELECT nbranch
 		   INTO $nquota
 		   FROM sa_branch_type
 		  WHERE ibranch = $iquota;

 		 if(SQLCODE == SQLNOTFOUND) strcpy(nquota," ");

		strcpy(nassured,trim(nassured));
		strcpy(nofficer,trim(nofficer));
		strcpy(nleader,trim(nleader));

		strcpy(bound_num,trim(bound_num));

		/*** EasyFlow���O��� ***/
		rc = EZ_car_bound();

      		/**���X�Ĥ@�X��0�A�����bexcel show �X*/
      		strcpy(iassured1, "�");
      		strcat(iassured1,trim(iassured));

      		strcpy(icar_type1, "�");
      		strcat(icar_type1,trim(icar_type));

      		strcpy(iins_type1, "�");
      		strcat(iins_type1,trim(iins_type));

      		strcpy(iofficer1, "�");
      		strcat(iofficer1,trim(iofficer));

      		if((strcmp(bound_type,"1") == 0) && (have_sMsg0 == 0))
      			continue;
      		if((strcmp(bound_type,"2") == 0) && ((have_sMsg1 == 0) || (have_sMsg0 == 1)))
      			continue;
      		if((have_sMsg0 == 0) && (have_sMsg1 == 0))
      			continue;

		$INSERT INTO car639_tmp1
          		     (dpolicy,nquota,ipolicy,icard,nassured,itag,iengine,iassured,dply_begin,
 			      dply_end,icar_type,ibrand,iofficer,nofficer,nleader,qnext,ibound,bound_num,
 			      ez_ibound,dentry,bound_nassured,bound_itag,bound_iengine,bound_nofficer,
 			      isign,dapply,nffac,nbound)
		      	VALUES
          		     ($dpolicy,$nquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured1,$dply_begin,
 			      $dply_end,$icar_type1,$ibrand,$iofficer1,$nofficer,$nleader,$qnext,$ibound,$bound_num,
 			      $tmp_ibound,$dentry,$bound_nassured,$bound_itag,$bound_iengine,$bound_nofficer,
 			      $isign,$dapply,$nffac,$tmp_nbound);

	}
        $CLOSE cur_pre1_1;
        $FREE cur_pre1_1;



     return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/
long car639_prepare_data_ALL()
{

   strcpy(dentry_cond,cm_to_infdate(dentry));
   strcpy(dentry_s_cond,cm_to_infdate(dentry_s));


   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == FALSE)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return FAIL;
   }

printf("prepared data, dentry_cond[%s]dentry_s_cond[%s]\n",dentry_cond,dentry_s_cond);

	if( strcmp(trim(option),"1") == 0)
            sprintf_s(sWhere, sizeof sWhere, " and b.iquota matches '%s' ",ibranch);
        else
            sprintf_s(sWhere, sizeof sWhere, " and b.ibranch_in matches '%s' ",ibranch);

printf("sWhere=[%s]\n",sWhere);

    for(k=0;k<count_db;k++)
    {

	/*******************�̷s�O����***********************/
	 sprintf_s(stmt, sizeof stmt,
		"SELECT b.dpolicy,b.iquota[1,4] || '00' ,a.ipolicy, a.icard,b.ilast_ply,a.nassured, "
		"       a.itag,a.iengine,a.iassured,b.dply_begin,b.dply_end,b.icar_type,b.ibrand,b.ibrand,  "
		"       b.iofficer, (SELECT nname FROM officer WHERE iofficer = b.iofficer),  "
		"       b.ileader,(SELECT nname FROM officer WHERE iofficer = b.ileader),  "
		"       CASE WHEN qnext_year = 0 THEN '�s�O' ELSE '��O' END ,   "
		"       a.bound_num,a.ibound             "
		"  FROM %s:policy a,%s:ply_relation b    "
		" WHERE a.ipolicy = b.ipolicy            "
		"   AND b.fcard_class = '2'              "
		"   AND b.dply_close is not null         "
		"   AND a.ibound != ' '                  "
		"   AND b.dpolicy BETWEEN '%s' and '%s'  "
		"   %s                                   "
		,list[k].dbname,list[k].dbname,dentry_s_cond,dentry_cond,sWhere);

printf("stmt[%s]\n", stmt);

          $PREPARE pre1 FROM $stmt;
          $DECLARE cur_pre1 CURSOR for pre1;
      	  $OPEN cur_pre1;

      	while(1)
      	{
         		$FETCH cur_pre1 INTO $dpolicy,$iquota,$ipolicy,$icard,$ilast_ply,$nassured,$itag,$iengine,$iassured,$dply_begin,
         				     $dply_end,$icar_type,$ibrand,$ibrand,$iofficer,$nofficer,$ileader,$nleader,$qnext,$bound_num,$ibound;

         		if(SQLCODE == SQLNOTFOUND) break;

		have_sMsg0 = 0;
		have_sMsg1 = 0;
		
		/*** ���O���� ***/
		
		if(strSearchReplace(ibound,"A","A")>0)
			have_sMsg1 = 1;
		
		if(strSearchReplace(ibound,"B","B")>0)
			have_sMsg0 = 1;


          	/*** ���W�� ***/
 		$SELECT nbranch
 		   INTO $nquota
 		   FROM sa_branch_type
 		  WHERE ibranch = $iquota;

 		 if(SQLCODE == SQLNOTFOUND) strcpy(nquota," ");

		strcpy(nassured,trim(nassured));
		strcpy(nofficer,trim(nofficer));
		strcpy(nleader,trim(nleader));

		strcpy(bound_num,trim(bound_num));

		/*** EasyFlow���O��� ***/
		rc = EZ_car_bound();

      		/**���X�Ĥ@�X��0�A�����bexcel show �X*/
      		strcpy(iassured1, "�");
      		strcat(iassured1,trim(iassured));

      		strcpy(icar_type1, "�");
      		strcat(icar_type1,trim(icar_type));

      		strcpy(iins_type1, "�");
      		strcat(iins_type1,trim(iins_type));

      		strcpy(iofficer1, "�");
      		strcat(iofficer1,trim(iofficer));

      		if(strcmp(bound_type,"1") == 0 && (have_sMsg0 == 0))
      			continue;
      		if((strcmp(bound_type,"2") == 0) && ((have_sMsg1 == 0) || (have_sMsg0 == 1)))
      			continue;
      		if((have_sMsg0 == 0) && (have_sMsg1 == 0))
      			continue;

		$INSERT INTO car639_tmp1
          		     (dpolicy,nquota,ipolicy,icard,nassured,itag,iengine,iassured,dply_begin,
 			      dply_end,icar_type,ibrand,iofficer,nofficer,nleader,qnext,ibound,bound_num,
 			      ez_ibound,dentry,bound_nassured,bound_itag,bound_iengine,bound_nofficer,
 			      isign,dapply,nffac,nbound)
		      	VALUES
          		     ($dpolicy,$nquota,$ipolicy,$icard,$nassured,$itag,$iengine,$iassured1,$dply_begin,
 			      $dply_end,$icar_type1,$ibrand,$iofficer1,$nofficer,$nleader,$qnext,$ibound,$bound_num,
 			      $tmp_ibound,$dentry,$bound_nassured,$bound_itag,$bound_iengine,$bound_nofficer,
 			      $isign,$dapply,$nffac,$tmp_nbound);

	}
        $CLOSE cur_pre1;
        $FREE cur_pre1;
     }
     return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

long get_txt()
{
    $char carbound[21],bound_kind[11],dentry[11],nassured[120],itag[CA_TAG_NUM],iengine[CA_ENGINE_NUM];
    $char iofficer[11],nofficer[120],nexaminer[120],dclose[11],fac[11];
    $char stmt_tmp[1024];	
    static int   recLen=1024;
    
    EXEC SQL WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;

    printf("sApHome[%s]\n",sApHome);
    printf("txtfile[%s]\n",txtfile);
    sprintf_s(getfile, sizeof getfile,"%s/dat/car/%s",sApHome,txtfile);
    printf("getfile[%s]\n",getfile);

    if ((fp=fopen(getfile,"rt"))==NULL)
    {
        return FAIL;
    }

    if ((bp=malloc(recLen))==NULL)
    {
        printf("System malloc failed  !\n");
        return FAIL;
    }

    /* ���j�Ÿ� */
    delimiter = '\t';

        /*carbound      varchar(120),	/*���O�s��*
        bound_kind    char(10),		/*���O�N�X*
        dentry        char(10),		/*��J���*
        nassured      varchar(120),	/*�Q�O�I�H*
        itag          char(8),		/*���P*
        iengine       char(20),		/*������*
        iofficer      char(10),		/*�g��N��*
        nofficer      varchar(120),	/*�g��W��*
        nexaminer     varchar(120),	/*�֫O�H��*
        dclose        char(10),		/*���פ��*
        fac           char(10)          /*�w���{������*/

    sprintf_s(stmt_tmp, sizeof stmt_tmp,"CREATE TEMP table car639_carbound "
    "( "
       "carbound      varchar(120),	 "
       "bound_kind    char(10),		 "
       "dentry        char(10),		 "
       "nassured      varchar(120),	 "
       "itag          char(%d),		 "
       "iengine       char(%d),		 "
       "iofficer      char(10),		 "
       "nofficer      varchar(120),	 "
       "nexaminer     varchar(120),	 "
       "dclose        char(10),		 "
       "fac           char(10)          "
   ")with no log;",CA_TAG_NUM-1,CA_ENGINE_NUM-1);
     $PREPARE stmp FROM $stmt_tmp;
     $EXECUTE stmp;

    while(fgets(bp,recLen,fp))
    {
       if (feof(fp)) break;
       offset = 0;

            /* ��ƨ��o���Ǥ��i�ܰ� */
            GetData(carbound,           sizeof(carbound),           delimiter);
            GetData(bound_kind,         sizeof(bound_kind),         delimiter);
            GetData(dentry,             sizeof(dentry),             delimiter);
            GetData(nassured,           sizeof(nassured),           delimiter);
            GetData(itag,               sizeof(itag),               delimiter);
            GetData(iengine,            sizeof(iengine),            delimiter);
            GetData(iofficer,           sizeof(iofficer),           delimiter);
            GetData(nofficer,           sizeof(nofficer),           delimiter);
            GetData(nexaminer,          sizeof(nexaminer),          delimiter);
            GetData(dclose,             sizeof(dclose),             delimiter);
            GetData(fac,                sizeof(fac),                delimiter);
printf("carbound[%s]nassured[%s]nofficer[%s]nexaminer[%s]\n",carbound,nassured,nofficer,nexaminer);
            $insert into car639_carbound(carbound, bound_kind, dentry, nassured, itag, iengine, iofficer, nofficer, nexaminer, dclose, fac)
             values ($carbound, $bound_kind, $dentry, $nassured, $itag, $iengine, $iofficer, $nofficer, $nexaminer, $dclose, $fac);

     }

	    return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

long car639_build()
{
   int rc;
    char    sfilename[81],stitle[2048],stmt[2048];

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(sfilename,"���O�~�Ⱥ޲z[CAR639]");

    strcpy(stitle,"\t�{���N��:CAR639\t���O�~�Ⱥ޲z\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");
    strcat(stitle,"\t�O���T\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t���O�����T");
    strcat(stitle,"\n");

    strcat(stitle,"\tñ����\t���W��\t�O�渹�X\t�O�I�Ҹ�\t�Q�O�I�H\t�P�Ӹ��X\t�������X\t�Q�O�I�H�N��\t");
    strcat(stitle,"�ӫO�_��\t�ӫO�״�\t���إN�X\t�t�P�����N��\t�g��N��\t�g��W��\t�޲z�H�W��\t�s��O\t���O���إN�X\t");
    strcat(stitle,"���O����\t���O���إN�X\t��J���\t�Q�O�I�H\t�P�Ӹ��X\t�������X\t�g��W��\t");
    strcat(stitle,"�֫O�H��\t���פ��\t�w���{���~��\t���O�~�ȶ��ص��O\t");

    strcpy(stmt,"select unique dpolicy,nquota,ipolicy,icard,nassured,itag,iengine,iassured,dply_begin,  "
         	"       dply_end,icar_type,ibrand,iofficer,nofficer,nleader,qnext,ibound,bound_num,ez_ibound,dentry, "
         	"       bound_nassured,bound_itag,bound_iengine,bound_nofficer,isign,dapply,nffac,nbound "
    		"  from car639_tmp1 "
    		"  order by ipolicy");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);
    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;

}

long ca639_create_temp()
{
   /* Create table car639_tmp1 */
   sprintf_s(stmt_tmp1, sizeof stmt_tmp1,"create temp table car639_tmp1 "
	"( "
	" dpolicy    		date, "
	" nquota     		varchar(120), "
	" ipolicy    		char(20), "
	" icard      		char(20), "
	" nassured   		varchar(120), "
	" itag       		char(%d), "
	" iengine    		char(%d), "
	" iassured   		char(13), "
	" dply_begin 		date, "
	" dply_end   		date, "
	" icar_type  		char(3), "
	" ibrand			char(8), "
	" iofficer          	char(11), "
	" nofficer          	varchar(120), "
	" nleader           	varchar(120), "
	" qnext       		varchar(10),  "
	" ibound			char(50), "
	" bound_num              varchar(120), "
	" ez_ibound              char(50), "
	" dentry                 char(10), "
	" bound_nassured   	varchar(120), "
	" bound_itag   		char(%d), "
	" bound_iengine    	char(%d), "
	" bound_nofficer        	varchar(120), "
	" isign                  varchar(120), "
	" dapply                 char(10), "
	" nffac                  char(10), "
	" nbound                 varchar(250) "
	")with no log;",CA_TAG_NUM-1,CA_ENGINE_NUM-1,CA_TAG_NUM-1,CA_ENGINE_NUM-1);
     $PREPARE stmp1 FROM $stmt_tmp1;
     $EXECUTE stmp1;

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

long ca639_branch()
{


    $WHENEVER SQLERROR GOTO errexit;

    $SELECT iquota[1,4]
       into $user_iquota
       FROM officer
      WHERE iofficer = $userid;

      if(SQLCODE == SQLNOTFOUND) goto errexit;

    return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;

}

long EZ_car_bound()
{
	if(strlen(bound_num) != 0)
	{
		strcpy(tmp_ibound," ");
		strcpy(tmp_nbound," ");
		strcpy(dentry," ");
		strcpy(bound_nassured," ");
		strcpy(bound_itag," ");
		strcpy(bound_iengine," ");
		strcpy(bound_nofficer," ");
		strcpy(isign," ");
		strcpy(dapply," ");
		strcpy(nffac," ");

		/*** ���O���إN�� ***/
		sprintf_s(stmt, sizeof stmt,
		"SELECT bound_kind  "
		"  FROM car639_carbound      "
		" WHERE carbound = '%s'      "
		,bound_num);

		$PREPARE pre3 FROM $stmt;
          	$DECLARE cur_pre3 CURSOR for pre3;
      	  	$OPEN cur_pre3;
      	  	while(1)
      	  	{
      	  		$FETCH cur_pre3 INTO $ez_ibound;

      	  		if(SQLCODE == SQLNOTFOUND) break;

      	  		strcat(tmp_ibound,trim(ez_ibound));
      	  		strcat(tmp_ibound,";");

      	  		$SELECT chiname || engname
      	  		   INTO $nbound
			   FROM car_code
			  WHERE kind = '10'
			    AND detail = $ez_ibound;

			if(SQLCODE == SQLNOTFOUND) strcpy(nbound," ");

			strcat(tmp_nbound,trim(nbound));
      	  		strcat(tmp_nbound,";");

      	  	}
      	  	$CLOSE cur_pre3;
        	$FREE cur_pre3;

        	/*** ���O��� ***/

        	sprintf_s(stmt, sizeof stmt,
		"SELECT first 1 dentry, "
		"	nassured,itag,iengine,nofficer,nexaminer,dclose,fac  "
		"  FROM car639_carbound   "
		" WHERE carbound = '%s'       "
		,bound_num);

printf("stmt[%s]\n", stmt);

		$PREPARE pre4 FROM $stmt;
          	$DECLARE cur_pre4 CURSOR for pre4;
      	  	$OPEN cur_pre4;
      	  	while(1)
      	  	{
      	  		$FETCH cur_pre4 INTO $dentry,$bound_nassured,$bound_itag,$bound_iengine,
      	  		                     $bound_nofficer,$isign,$dapply,$nffac;

      	  		if(SQLCODE == SQLNOTFOUND) break;

printf("bound_num[%s]dentry[%s]dapply[%s]\n",bound_num,dentry,dapply);
printf("bound_nofficer[%s]isign[%s]\n",bound_nofficer,isign);
printf("bound_nassured[%s]bound_itag[%s]bound_iengine[%s]\n",bound_nassured,bound_itag,bound_iengine);
      	  	}
      	  	$CLOSE cur_pre4;
          	$FREE cur_pre4;

	}
	else
	{
		strcpy(tmp_ibound," ");
		strcpy(tmp_nbound," ");
		strcpy(dentry," ");
		strcpy(bound_nassured," ");
		strcpy(bound_itag," ");
		strcpy(bound_iengine," ");
		strcpy(bound_nofficer," ");
		strcpy(isign," ");
		strcpy(dapply," ");
		strcpy(nffac," ");
	}

	return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

int strSearchReplace(char *string,char *searchString,char *replaceString)
{
 char *currP, *baseStr;
 int  count = 0;

 currP = baseStr = NULL;

 while (*string)
      {
      currP = strstr (!currP ? string : baseStr, searchString);

      if (currP)
           {
           count++;
           baseStr = (currP + strlen (replaceString));
           strcpy (currP, (currP + strlen (searchString)));
           memmove (currP + strlen (replaceString),
                      currP, strlen (currP) + 1);
           memcpy (currP, replaceString, strlen (replaceString));
           }
      else
           break;
      }

 return count;
}