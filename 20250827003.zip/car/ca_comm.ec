/*******************************************************/
/* ca_comm.ec ���I�@��function
/*******************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <varargs.h>
$include sqlca;
#include "commsgs.h"
#include "globdata.h"
#include "safeclib.h"
/*******************************************************/
/* get_deduct_info:���o�ۭt�B��ܤ�r                  */
/*******************************************************/
long get_deduct_info(Icar_type,Iins_type,Ideduct,Mdeduct,Prn_deduct)
$char *Icar_type,*Iins_type,*Ideduct,*Mdeduct,*Prn_deduct;
{
$char Ideduct_c[9];
char  deduct_18[11],start_18[11];
int   i_deduct;

        strcpy(Ideduct_c,trim(Ideduct));
        strcpy(Mdeduct," ");
        strcpy(Prn_deduct," ");

printf("deduct[%s][%s]\n",Iins_type,Ideduct_c);
        /****** 94.12.12 09�����I�禳�ۭt�B ********/
	if (strcmp(trim(Iins_type),"01")==0 || strcmp(trim(Iins_type),"05")==0 ||
            strcmp(trim(Iins_type),"08")==0 || strcmp(trim(Iins_type),"09")==0 ||
            strcmp(trim(Iins_type),"201")==0 || strcmp(trim(Iins_type),"205")==0 ||
            strcmp(trim(Iins_type),"209")==0
            )
        {
            if (strcmp(Ideduct_c,"0")==0) {
               strcpy(Mdeduct,"�L");
               strcpy(Prn_deduct,"�L");
               return M_CM_OK;
            }
            $SELECT mdeduct,prn_deduct
               INTO $Mdeduct,$Prn_deduct
               FROM ca_dmg_mdeduct
              WHERE icar_type=$Icar_type
                AND ideduct=$Ideduct_c;
            if (SQLCODE==SQLNOTFOUND) {
               strcpy(Mdeduct,Ideduct_c);
               i_deduct=atoi(Ideduct);
               rfmtlong(i_deduct,"---,---,--&",Prn_deduct);
               strcpy(Prn_deduct,trim(Prn_deduct));
               return M_CM_OK;
            }
            else
               return M_CM_OK;
        }

        /* car9902082 32�I�إi�L�ۭt�B */
        /* 31�I�ؤ]�i�L�ۭt�B modify by sylvia 103.02.07 */
        if (strcmp(trim(Iins_type),"02")==0 ||
            strcmp(trim(Iins_type),"15")==0 ||
            strcmp(trim(Iins_type),"16")==0 ||
            strcmp(trim(Iins_type),"29")==0 ||
            strcmp(trim(Iins_type),"30")==0 ||
            strcmp(trim(Iins_type),"35")==0 ||
            strcmp(trim(Iins_type),"48")==0 ||
            strcmp(trim(Iins_type),"51")==0) {
            strcpy(Mdeduct,"�L");
            strcpy(Prn_deduct,"�L");
            return M_CM_OK;
        }
        
        /* 24,26�I�ئۭt�B�B�אּ:�P�ĤT�H�d���I modify by sylvia 103.01.06(1021210002_C1) */
        if (strcmp(trim(Iins_type),"24")==0 ||
            strcmp(trim(Iins_type),"26")==0) {
            strcpy(Mdeduct,"�P�ĤT�H�d���I");
            strcpy(Prn_deduct,"�P�ĤT�H�d���I");
            return M_CM_OK;
        }

	if (strcmp(trim(Iins_type),"11")==0 || strcmp(trim(Iins_type),"211")==0) 
	{
            if (strcmp(Ideduct_c,"0")==0 || strcmp(Ideduct_c,"")==0) {
               strcpy(Mdeduct,"�L");
               strcpy(Prn_deduct,"�L");
               return M_CM_OK;
            }
            strcpy(Mdeduct,Ideduct_c);
            strcat(Mdeduct,"%");
            strcpy(Prn_deduct,Mdeduct);
            return M_CM_OK;
        }

	if (strcmp(trim(Iins_type),"18")==0) {
            strncpy(deduct_18,Ideduct_c+2,2);
            deduct_18[2] = '\0';
            strcpy(deduct_18,trim(deduct_18));

            strncpy(start_18,Ideduct,2);
            start_18[2]  = '\0';
            strcpy(start_18,trim(start_18));

            if (strcmp(deduct_18,"0") == 0) {
                strcpy(Prn_deduct,"�L");
                strcat(Prn_deduct," ");
            }
            else {
                strcpy(Prn_deduct,deduct_18);
                strcat(Prn_deduct,"%");
            }
            strcat(Prn_deduct,",�_���B");
            strcat(Prn_deduct,start_18);
            strcat(Prn_deduct,"%");
            strcpy(Mdeduct,Prn_deduct);
            return M_CM_OK;
       }
       if (strcmp(trim(Iins_type), "62")==0 || strcmp(trim(Iins_type), "63")==0 ||
           strcmp(trim(Iins_type), "64")==0) {
           strcpy(Prn_deduct,"���ݮɶ�");
           strcat(Prn_deduct,trim(Ideduct));
           strcat(Prn_deduct,"�p��");
           strcpy(Mdeduct,Prn_deduct);
           return M_CM_OK;
       }
       if (strcmp(trim(Iins_type),"10")==0) {
           strcpy(Prn_deduct,"�P�����I");
           strcpy(Mdeduct,Prn_deduct);
           return M_CM_OK;
       }

       if (strcmp(Ideduct," ")==0 || strcmp(Ideduct_c,"0")==0) {
           strcpy(Mdeduct,"�L");
           strcpy(Prn_deduct,"�L");
           return M_CM_OK;
       }
       else {
           strcpy(Mdeduct,Ideduct_c);
           strcpy(Prn_deduct,Ideduct_c);
           return M_CM_OK;
       }

}
/*******************************************************/
/* check_id:�ˮ֨����ҩβνs                           */
/*******************************************************/
long check_id(Iassured,Fassured,Fsex)
$char *Iassured,*Fassured,*Fsex;
/* Fassured ���O�o�W�w�N�� */
{
int  rc;

    printf("Iassured[%s]\n",Iassured);
    strcpy(Iassured,trim(Iassured));
    strcpy(Fsex,"0");
    if (isalpha(Iassured[0]) != 0 && strlen(Iassured)==10)
       rc = check_person(Iassured,Fassured,Fsex);
    else
       rc = check_company(Iassured,Fassured);
       
    return rc;
}
/*******************************************************/
/* check_person:�ˮ֦۵M�Hid                           */
/*******************************************************/
long check_person(Iassured,Fassured,Fsex)
$char *Iassured,*Fassured,*Fsex;
{
$char IDstr[27];
$char fststr[2],sndstr[2],sumstr[5];
$char tmpstr[12],tmpstr1[3],tmpstr2[3];
int  a1,a2,a3,a4,a5,a6,a7,a8,a9,aa,ab;
int  i,j,k;

     strcpy(fststr,substring(Iassured,1,1));
     printf("fststr[%s][%s]\n",fststr,substring(Iassured,1,1));

     if (isalpha(fststr[0])==0)       /* �D�ƭ� */
     {
         strcpy(Fassured,"8");     /* �۵M�H�����yid���~ */
         return M_CM_OK;
     }

     strcpy(sndstr,substring(Iassured,2,1));
     printf("sndstr[%s][%s]\n",sndstr,substring(Iassured,2,1));

     if (isalpha(sndstr[0])==0)
     {
        if (sndstr[0] != '1' && sndstr[0] != '2')
        {
            strcpy(Fassured,"8");  /* �۵M�H�����yid���~ */
            return M_CM_OK;
        }
        strcpy(Fsex,sndstr);

        strcpy(IDstr,"ABCDEFGHJKLMNPQRSTUVXYWZIO");

        j=0;
        for(i=0;i<26;i++)
        {
           if (strncmp(fststr,IDstr+i,1)==0)
           {
               j = i + 10;
               break;
           }
        }
        if (j==0)
        {
            strcpy(Fassured,"8");  /* �۵M�H�����yid���~ */
            return M_CM_OK;
        }

        strcpy(tmpstr1,itoa(j));
        a1 = atoi(substring(tmpstr1,1,1));
        a2 = atoi(substring(tmpstr1,2,1));
        a3 = atoi(substring(Iassured,2,1));
        a4 = atoi(substring(Iassured,3,1));
        a5 = atoi(substring(Iassured,4,1));
        a6 = atoi(substring(Iassured,5,1));
        a7 = atoi(substring(Iassured,6,1));
        a8 = atoi(substring(Iassured,7,1));
        a9 = atoi(substring(Iassured,8,1));
        aa = atoi(substring(Iassured,9,1));
        ab = atoi(substring(Iassured,10,1));
        printf("[%d][%d][%d][%d][%d][%d][%d][%d][%d][%d][%d]\n",
                a1,a2,a3,a4,a5,a6,a7,a8,a9,aa,ab);

        i = a1 + a2 * 9 + a3 * 8 + a4 * 7 + a5 * 6 +
            a6 * 5 + a7 * 4 + a8 * 3 + a9 * 2 + aa; 
        j = i / 10;
        k = i - j * 10;
        if ( k != 0 )
           k = 10 - k;
        if ( k == ab )
        {
            strcpy(Fassured,"1");  /* �����Ҹ� */
            return M_CM_OK;
        }
        else
        {
            strcpy(Fassured,"8");  /* �۵M�H�����yid���~ */
            return M_CM_OK;
        }
    }
    else
    {
        strcpy(IDstr,"ABCDEFGHJKLMNPQRSTUVXYWZIO");

        j=0;
        for(i=0;i<26;i++)
        {
           if (strncmp(fststr,IDstr+i,1)==0)
           {
               j = i + 10;
               break;
           }
        }

        if (j==0)
        {
            strcpy(Fassured,"7");  /* �۵M�H�~���yid���~ */
            return M_CM_OK;
        }
        strcpy(tmpstr1,itoa(j));

        j=0;
        for(i=0;i<4;i++)
        {
           if (strncmp(sndstr,IDstr+i,1)==0)
           {
               j = i + 10;
               break;
           }
        }
        if (j==0)
        {
            strcpy(Fassured,"7");  /* �۵M�H�~���yid���~ */
            return M_CM_OK;
        }
        strcpy(tmpstr2,itoa(j));

        if (j==10 || j==12)
            strcpy(Fsex,"1");
        else
            strcpy(Fsex,"2");

        a1 = atoi(substring(tmpstr1,1,1));
        a2 = atoi(substring(tmpstr1,2,1));
        a3 = atoi(substring(tmpstr2,2,1));
        a4 = atoi(substring(Iassured,3,1));
        a5 = atoi(substring(Iassured,4,1));
        a6 = atoi(substring(Iassured,5,1));
        a7 = atoi(substring(Iassured,6,1));
        a8 = atoi(substring(Iassured,7,1));
        a9 = atoi(substring(Iassured,8,1));
        aa = atoi(substring(Iassured,9,1));
        ab = atoi(substring(Iassured,10,1));
        printf("[%d][%d][%d][%d][%d][%d][%d][%d][%d][%d][%d]\n",
                a1,a2,a3,a4,a5,a6,a7,a8,a9,aa,ab);

        i = a1 + a2 * 9 + a3 * 8 + a4 * 7 + a5 * 6 +
            a6 * 5 + a7 * 4 + a8 * 3 + a9 * 2 + aa; 
        j = i / 10;
        k = i - j * 10;
        if ( k != 0 )
           k = 10 - k;
        if ( k == ab )
        {
            strcpy(Fassured,"2");  /* �~��H�~�d�Ҹ� */
            return M_CM_OK;
        }
        else
        {
            strcpy(Fassured,"7");  /* �۵M�H�~���yid���~ */
            return M_CM_OK;
        }
    }
}
/*******************************************************/
/* check_company:�ˮ֪k�Hid                            */
/*******************************************************/
long check_company(Iassured,Fassured)
$char *Iassured,*Fassured;
{
int  a1,a2,a3,a4,a5,a6,a7,a8;
int  i,j,k,m;

printf("*****************begin check company id\n");
    strcpy(Iassured,trim(Iassured));
    if (strlen(Iassured) != 8)
    {
        strcpy(Fassured,"9");    /* �k�Hid���~ */
        return M_CM_OK;
    }

    if (isalpha(Iassured[0])!=0 || isalpha(Iassured[1])!=0 ||
        isalpha(Iassured[2])!=0 || isalpha(Iassured[3])!=0 ||
        isalpha(Iassured[4])!=0 || isalpha(Iassured[5])!=0 ||
        isalpha(Iassured[6])!=0 || isalpha(Iassured[7])!=0)
    {
        strcpy(Fassured,"9");    /* �k�Hid���~ */
        return M_CM_OK;
    }

    a1 = atoi(substring(Iassured,1,1));
    a2 = atoi(substring(Iassured,2,1));
    a3 = atoi(substring(Iassured,3,1));
    a4 = atoi(substring(Iassured,4,1));
    a5 = atoi(substring(Iassured,5,1));
    a6 = atoi(substring(Iassured,6,1));
    a7 = atoi(substring(Iassured,7,1));
    a8 = atoi(substring(Iassured,8,1));

    printf("[%d][%d][%d][%d][%d][%d][%d][%d]\n",
            a1,a2,a3,a4,a5,a6,a7,a8);
    i = a1;
    j = a2 * 2;
    if (j >= 10)
    {
        k = j - 10; 
        j = 1;
    }
    else k = 0;
    i = i + j + k;
    i = i + a3;
    j = a4 * 2;
    if (j >= 10)
    {
        k = j - 10; 
        j = 1;
    }
    else k = 0;
    i = i + j + k;
    i = i + a5;
    j = a6 * 2;
    if (j >= 10)
    {
        k = j - 10; 
        j = 1;
    }
    else k = 0;
    i = i + j + k;
    i = i + a8;
    if (a7 == 7)
    {
        j = i / 10;
        k = i - j * 10;
        if (k == 0 || k == 9)
        {
            strcpy(Fassured,"3");    /* �k�H�νs */
            return M_CM_OK;
        }
        else
        {
            strcpy(Fassured,"9");    /* �k�Hid���~ */
            return M_CM_OK;
        }
    }
    else
    {
        j = a7 * 4;
        k = j / 10;
        m = j - k * 10;
        i = i + k + m;
        j = i / 10;
        k = i - j * 10;
        if (k == 0)
        {
            strcpy(Fassured,"3");    /* �k�H�νs */
            return M_CM_OK;
        }
        else
        {
            strcpy(Fassured,"9");    /* �k�Hid���~ */
            return M_CM_OK;
        }
    }
}
/*******************************************************/
