/**********************************************************************/
/*   program id   : ca540p01s.ec                                      */
/*   program name : �T����Q�I�������                                */
/*   date written : 11/12/2018                                        */
/*   date modify  : yyyy/mm/dd                                        */
/*                                                                    */
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>

#define TRUE 1
#define FALSE 0

char *get_car_full_db();

$char  DBName[5], sFullName[80];
$char  DBName1[5];
$char  errMsg[500000], errMsg2[200];
$char  errMsg1[5000];
$char  stmp[500000];
char   sApHome[50];
long   rtncode;
FILE   *sfp,*fp;
static char  *bp;
static int   recLen=1024;
$char userid[11];
$char txtfile[101];
$char outputf[21];
int offset;
$char getfile[400];
char delimiter;
$char isign_tmp[8];
int i,ipflag;
long rc;
$date Today;
$char ncode[101];
$long icount;
$char isign_tmp[8];
$char sTmpSQL1[5000];

DBinfo  *list;
int     count_db;

$char   sInumber_0800[21], sIpolicy[21], sItag[13], sNassured[121],
        sIassured[13], sIangine[26], sDaccident[17], sAdjustment[11],
        sIacc_area[3], sFacc_nation[2], sNacc_driver[19], sIacc_license[11],
        sIacc_birth[11], sFacc_sex[2], sFacc_marri[2], sIacc_reason[4],
        sFacc_rel[2], sMins_38[10], sMins_39[10], sIpayment[11], sDreceiver[11],
        sInvoice[21], sIdatano[21], sItransno[22], sIclaim[21], sIquota[7],
        iemail[51], itel[21], imobile[21], tfax[21], izipcode_con[CA_ZIP],
        aperm_con[101], sDacc_birth[11], sDaccident2[14], sPly_ins_type[201],
        sMamount[10], sMins_238[10];
$char   kcomp_no[3], kdept_no[3], dyear[3], kserial_index[7], kserial_num[12];
$int    iMins_38, iMins_39, iMins_238, iMamount;

char   datestr[9];

long car540_trans();
long car540_exec();
long car540_report();
long split_policy();

main(argc, argv)
int argc;
char **argv;
{
    long rc;

    batchinit();
    strcpy(DBName       ,isNULLstr(argv[1]));
    strcpy(userid       ,isNULLstr(argv[2]));
    strcpy(txtfile      ,isNULLstr(argv[3]));   /*��r��*/
    strcpy(sItransno    ,isNULLstr(argv[4]));   /*�{�����ɧǸ�*/
    strcpy(outputf      ,isNULLstr(argv[5]));
    printf("txtfile[%s]\n",txtfile);

    rtoday(&Today);     /* get today's datetime */

    if (db_select(DBName) == False)
    {
        EWRITE(userid,M_CM_DB_NOTOPEN,"M_CM_DB_NOTOPEN");
        return M_CM_DB_NOTOPEN;
    }

    if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
       if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
          return M_CM_NOT_DBLIST;
    }

    rtncode = getApHome(sApHome);
    if (rtncode < 0)
    {
        EWRITE(userid, M_CM_READ_CONFIG_ERR, "read Config file error!!");
        return FAIL;
    }

    printf("sItransno=[%s]\n",sItransno);

    $WHENEVER SQLERROR CONTINUE;

    strcpy(sIpayment,"16784078"); /*�ߥI��H�G���ӿ��~�ѥ��������q*/
    strcpy(sIacc_reason,"99");		/*�X�I��]*/

    rc=car540_trans();  /* �����JTemp Table �Ϊ�B�ˮ� */
    printf("122:errMsg = [%s]\n", errMsg);

    if (rc != M_CM_OK)
    {
	        printf("car540_trans:errMsg=[%s]\n",errMsg);
	        strcpy(stmp,"car540_trans ���楢��, �нT�{�íץ���A���s����!! \n\n ���~�N�X\t MEMO�渹\t ���~�T�� \n");
	        strcat(stmp,errMsg);
	        EWRITE(userid,rc,stmp);
	        return rc;
    }

    rc=car540_exec();   /* ���z�B�w���B�d�ҡB�ɮ֡B�z�� */
    if (rc != M_CM_OK)
    {

	        printf("[��Q�I��Ƽg�J�z�ߨt��  ���楢��]\n");
	        strcpy(stmp,"car540_exec ���楢��, ���~��Ʀp�U, �нT�{�íץ���A���s����!! \n\n");
	        strcat(stmp,errMsg);
	        EWRITE(userid,rc,stmp);
	        return rc;
    }
    printf("-------------- 141 -------\n");
    rc=car540_report();   /* ���s���� */

    printf("return success\n");
    sprintf(stmp,"��Q�I������ɧ���!, �@���s %ld ���߮׸��!! �Цۦ��cmn202�U���ɮס@\n",icount);
    /* EWRITE(userid,M_CM_OK,"��Q�I������ɧ���!"); */
    EWRITE(userid,M_CM_OK,stmp);

    return M_CM_OK;
}

/* ------------------------------------------------------------------------- */
void GetData(data, maxlen, delimiter)
char *data, delimiter;
int maxlen;
{
    int fori, pre_offset, cnt=0;

    data[0]='\0';
    pre_offset = offset;

    for (fori=pre_offset; bp[fori]!=0x00&&bp[fori]!=0x0d&&bp[fori]!=0x0a&&bp[fori]!=delimiter; fori++)
    {
        offset++;
        if (cnt < maxlen-1)
        {
            data[cnt]=bp[fori];
            cnt++;
        }
    }

    offset++; /* ���ܤU�@�� */
    if (cnt==0) data[cnt++]=0x20; /* �L��Ƶ��ť� */
    data[cnt]=0x00;
    printf("pre_offset[%d]offset[%d]len[%d]data[%s]\n", pre_offset, offset, cnt, data);
}

/* ------------------------------------------------------------------------- */
long car540_trans()
{
    $int    ipflag2, mdamage_cover, minjured_cover, icnt2;
    $int    icnt, iline, icnt_err, icnt3, iCntA, iCntB;

    $char   sTmp1[2000], sTmp2[2000];
    $char   sYYYY[5], sMM[3], sDD[3], sHH[3], sTmpDate1[21], sTmpDate2[21],
            sTmpDate3[21], sTmpClaim[21], chk1[2], chk2[2], chk3[2], chk4[2],
            chk5[2], sTmpCol[30],sFassured[2], fOver18[2], tmp_iclaim1[20],
            tmpNassured[121],sdply_end[21],sTag[13],strNassured[121];

    $char   sToday[11], icar_type[3], iportfolio[11], igroup_profit[21],
            fapply[2], kreserve[6], fterm[2], icohort[5], sYN[2];

    $char   sMsg[200];

    int     icnt1;

    /* $WHENEVER SQLERROR continue; */
    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT 10;

    ipflag = 0;

    printf("sApHome[%s]\n",sApHome);
    printf("txtfile[%s]\n",txtfile);
    sprintf(getfile,"%s/dat/car/%s",sApHome,txtfile);
    printf("getfile[%s]\n",getfile);

    if ((fp=fopen(getfile,"rt"))==NULL)
    {
        return FAIL;
    }

    if ((bp=malloc(recLen))==NULL) { printf("System malloc failed  !\n"); return
                                      FAIL; }

    /* ���j�Ÿ� */
    delimiter=''; /* �`�N:���j�Ÿ��� ascii(127) */

    $CREATE TEMP table car540_temp
    (
        inumber_0800    char(20)        not null,  					--1 0800MEMO�渹
    	ipolicy         char(20)        not null,  					--2 �O�渹
    	itag            char(12)        not null,  					--3 ���P���X
    	nassured        varchar(120)    not null,   			    --4 �Q�O�I�H�W��
    	iassured		char(12)		not null,					--5 �Q�O�I�HID
    	iengine			char(25)		not null,					--6 ������
    	daccident       datetime year to minute     not null,       --7 �X�I�ɶ�
    	dreceiver       date            not null,   				--8 �o����
    	invoice         char(20)        not null,   				--9 �o�����X
    	mamount	    	int             not null,   				--10 �ϴ����B
    	ply_ins_type    varchar(200)	not null, 					--11 �ӫO�I��
    	mins_38         int             not null,   				--12 38���v���B
    	mins_39         int             not null,   				--13 39���v���B
    	mins_238        int             not null,   				--14 238���v���B
    	iacc_area       char(2)         not null,   				--15 �X�I�a��
    	facc_nation     char(1)         not null,   				--16 ������~��H
    	nacc_driver     char(18)        not null,   				--17 �r�p�H�W��
    	iacc_license    char(10)        not null,   				--18 �r�p�H�ע�
    	iacc_birth      date            not null,   				--19 �X�ͤ��
    	facc_sex        char(1)         not null,   				--20 �ʧO
    	facc_marri      char(1)         not null,   				--21 �B��
    	facc_rel        char(1)         not null,   				--22 �P�Q�O�I�H���Y
    	adjustment      char(10)        not null,   				--23 �z�ߤH�����s
    	idatano         char(20)        not null,   				--24 ������ɧ帹
    	itransno        char(21)        not null,  					--25 �{������Ǹ�
    	iclaim          char(20)    default ' ' not null,           --26 �߮׸�
    	iCnt_Base       int,                                        --27 238�I�ة�Q�W��
    	iCnt238         int                                         --27 238�I�ؤw�X�I����
    )with no log;

    $create index car540_temp_dx1 on car540_temp(inumber_0800);

    $CREATE TEMP table car540_errlog
    (
        inumber_0800     char(20),
        errno			 char(4),
        errmsg           char(300)
    )with no log;

    $CREATE TEMP table car540_errlog2
    (
        ipolicy     char(20),
        errno		char(4),
        daccident	datetime year to minute,
        errmsg      char(300)
    )with no log;


    /* 1.1 IFRS�ˮֶ}�� */
     $select first 1 today into $sToday
        from car_code
       where 1=1;

    printf("sToday=[%s]\n",sToday);
    rtncode = cm_get_IFRS_DATE(sToday, &sYN);
    printf("sToday=[%s], sYN=[%s]\n",sToday,sYN);

    iline = 0;			/* �ɮ׵��� */
    icnt = 0;			/* ��B�ˮ֥��T���� */
    icnt_err = 0;		/* ���~���(�C�@���~�p�Ƥ@��) */
    while(fgets(bp,recLen,fp))
    {
        if (feof(fp)) break;
        offset = 0;

        /* ��ƨ��o���Ǥ��i�ܰ� */
        GetData(sInumber_0800,  sizeof(sInumber_0800),  delimiter);      /*1 0800MEMO�渹*/
        GetData(sIpolicy,       sizeof(sIpolicy)  ,     delimiter);      /*2 �O�渹*/
        GetData(sItag,          sizeof(sItag),          delimiter);      /*3 ���P���X*/
        GetData(sNassured,      sizeof(sNassured),      delimiter);      /*4 �Q�O�I�H�W��*/
        GetData(sDaccident,     sizeof(sDaccident),     delimiter);		 /*5 �X�I�ɶ� YYYY-MM-DD HH:mm */
        GetData(sDreceiver,     sizeof(sDreceiver),     delimiter);    	 /*6 �o���� MM/DD/YYYY */
        GetData(sInvoice,       sizeof(sInvoice),       delimiter);      /*7 �o�����X*/
        GetData(sMamount,       sizeof(sMamount),       delimiter);      /*8 �ϴ��O��*/
        GetData(sPly_ins_type,  sizeof(sPly_ins_type),  delimiter);      /*9 �ӫO�I��*/
        GetData(sMins_38,       sizeof(sMins_38),       delimiter);      /*10 38���v���B*/
        GetData(sMins_39,       sizeof(sMins_39),       delimiter);      /*11 39���v���B*/
        GetData(sMins_238,      sizeof(sMins_238),       delimiter);      /*12 238���v���B  add by sylvia 110.04.21 (1100310016_SC1) */
        GetData(sIacc_area,     sizeof(sIacc_area),     delimiter);      /*13 �X�I�a��*/
        GetData(sFacc_nation,   sizeof(sFacc_nation),   delimiter);      /*14 ������~��H*/
        GetData(sNacc_driver,   sizeof(sNacc_driver),   delimiter);      /*15 �r�p�H�W��*/
        GetData(sIacc_license,  sizeof(sIacc_license),  delimiter);      /*16 �r�p�H�ע�*/
        GetData(sTmpDate2,      sizeof(sTmpDate2),      delimiter);      /*17 �X�ͤ��(YYYYMMDD)*/
        GetData(sFacc_sex,      sizeof(sFacc_sex),      delimiter);      /*18 �ʧO*/
        GetData(sFacc_marri,    sizeof(sFacc_marri),    delimiter);      /*19 �B��*/
        GetData(sFacc_rel,      sizeof(sFacc_rel),      delimiter);      /*20 �P�Q�O�I�H���Y*/
        GetData(sAdjustment,    sizeof(sAdjustment),    delimiter);      /*21 �z�ߤH�����s*/
        GetData(sIdatano,     	sizeof(sIdatano),       delimiter);      /*22 �z�����ɧ帹*/
        /* -------------------------------------------------------------- */
        strcpy(sInumber_0800, trim(sInumber_0800));
        if (strcmp(sInumber_0800,"0800MEMO�渹") == 0)
        {
           memset(bp, ' ', recLen);
           continue;
        }

        iline++;
        ipflag = 0;

        strcpy(sInumber_0800, trim(sInumber_0800));  if(strlen(sInumber_0800) == 0) ipflag = 1;
        strcpy(sIpolicy, trim(sIpolicy));            if(strlen(sIpolicy) == 0) 		ipflag = 1;
        strcpy(sItag, trim(sItag));                  if(strlen(sItag) == 0) 		ipflag = 1;
        strcpy(sNassured, trim(sNassured));          if(strlen(sNassured) == 0) 	ipflag = 1;
        strcpy(sDaccident, rtrim(sDaccident));       if(strlen(sDaccident) == 0) 	ipflag = 1;
        strcpy(sDreceiver, trim(sDreceiver));        if(strlen(sDreceiver) == 0) 	ipflag = 1;
        strcpy(sInvoice, trim(sInvoice));            if(strlen(sInvoice) == 0) 		ipflag = 1;
        strcpy(sMamount, trim(sMamount));            if(strlen(sMamount) == 0) 		ipflag = 1;
        strcpy(sPly_ins_type, trim(sPly_ins_type));
        strcpy(sMins_38, trim(sMins_38));            if(strlen(sMins_38) == 0) 		ipflag = 1;
        strcpy(sMins_39, trim(sMins_39));            if(strlen(sMins_39) == 0) 		ipflag = 1;
        strcpy(sMins_238, trim(sMins_238));          if(strlen(sMins_238) == 0) 	ipflag = 1;
        strcpy(sIacc_area, trim(sIacc_area));        if(strlen(sIacc_area) == 0) 	ipflag = 1;
        strcpy(sFacc_nation, trim(sFacc_nation));
        strcpy(sNacc_driver, trim(sNacc_driver));
        strcpy(sIacc_license, trim(sIacc_license));
        strcpy(sTmpDate2, trim(sTmpDate2));
        strcpy(sFacc_sex, trim(sFacc_sex));
        strcpy(sFacc_marri, trim(sFacc_marri));
        strcpy(sFacc_rel, trim(sFacc_rel));          /* if(strlen(sFacc_rel) == 0) 	ipflag = 1; */
        strcpy(sAdjustment, trim(sAdjustment));      if(strlen(sAdjustment) == 0) 	ipflag = 1;
        strcpy(sIdatano, trim(sIdatano));        	 if(strlen(sIdatano) == 0) 		ipflag = 1;
        strcpy(sItransno, trim(sItransno));

        printf("---- [ %d ]  -----  \n", iline);
        printf("sInumber_0800=[%s]  sIpolicy=[%s]  sItag=[%s]  sNassured=[%s]\n",sInumber_0800, sIpolicy, sItag,sNassured);
        printf("sDaccident=[%s]  sDreceiver=[%s]  sInvoice=[%s]  sMamount=[%s]\n",sDaccident, sDreceiver, sInvoice,sMamount);
        printf("sPly_ins_type=[%s]  sMins_38=[%s]  sMins_39=[%s]  sIacc_area=[%s]\n",sPly_ins_type, sMins_38, sMins_39,sIacc_area);
        printf("sFacc_nation=[%s]  sNacc_driver=[%s]  sIacc_license=[%s]  sTmpDate2=[%s]\n",sFacc_nation, sNacc_driver, sIacc_license,sTmpDate2);
        printf("sFacc_sex=[%s]  sFacc_marri=[%s]  sIacc_reason=[%s]  sFacc_rel=[%s]\n",sFacc_sex, sFacc_marri, sIacc_reason,sFacc_rel);
        printf("sAdjustment=[%s]  sIdatano=[%s]\n",sAdjustment, sIdatano);

        iMins_38 = atoi(sMins_38);
        iMins_39 = atoi(sMins_39);
        iMins_238 = atoi(sMins_238);    /* add by sylvia 110.04.21 (1100310016_SC1) */
        iMamount = atoi(sMamount);
        iCntB = 0;  /* 238�I�ة�Q�W�� */

        /* �ƥ��ˮ� (start) ------------------------------------------------ */
        /* ��3/22�|ĳ����,�s�W�U�C�ˮ��޿�
           �r�p�H������:[sFacc_nation(������~��H)�BsNacc_driver(�r�p�H�W��)�BsTmpDate2(�r�p�H�ͤ�)�BsFacc_sex(�ʧO)�BsFacc_marri(�B��)]
           1.�r�p�HID = �Q�O�I�HID      ==> �r�p�H������=�Q�O�I�H
           2.�r�p�HID �ť�,�B���۵M�H�� ==> �r�p�H������=�Q�O�I�H
           3.�r�p�HID �ť�,�B���k�H��		==> �r�p�H�����줣�o�ť�
           4.�r�p�HID <> �Q�O�I�HID  		==> �r�p�H�����줣�o�ť�           */
        /* 4/9 �F���q��,�p�G�r�p�HID=�Q�O�I�HID��,�Ʊ�[�P�Q�O�I�H���Y]���]�i�۰ʱa�X1(���H) modify by sylvia 108.04.09*/
        /* �s�W 238�I��,�z�ߦ��ƶW�L����,����߮� add by sylvia 110.04.21 (1100310016_SC1) */

        if (ipflag == 0)
        {
            memset(sIassured,0x00,sizeof(sIassured));
			memset(sFassured,0x00,sizeof(sFassured));
            strcpy(sFullName, get_car_full_db(sIpolicy));
			sprintf(sTmp1,
           	    "select a.iassured, case when a.fassured in ('1','3','5') then '1' else '2' end as fassured,  \
           	            b.icar_type \
                   from %s:policy a, %s:ply_relation b \
                  where a.ipolicy = b.ipolicy \
                    and a.ipolicy = '%s' \
                    and b.dply_close is not null \
                    and b.fcard_class = '2' ", sFullName, sFullName, sIpolicy);
            printf("sTmp1=[%s]\n",sTmp1);
            $PREPARE pre_C1 FROM $sTmp1;
            $DECLARE cur_C1 CURSOR FOR pre_C1;
            $OPEN cur_C1;
            $FETCH cur_C1 into $sIassured, $sFassured, $icar_type;
            if (SQLCODE == SQLNOTFOUND)
            {   sprintf(errMsg,"��[%d]�� �O�渹[%s]�d�L�ӫO��� \n", iline, sIpolicy);
                $insert into car540_errlog(inumber_0800, errno , errmsg) values ($sInumber_0800, 'E001', $errMsg);
                ipflag = 1;
                icnt_err ++;
            }
            $CLOSE cur_C1;
            $FREE cur_C1;
            if (ipflag == 1)
            {
            	memset(bp, ' ', recLen);
            	continue;
            }

            strcpy(sIassured, trim(sIassured));
            /* 1.�r�p�HID = �Q�O�I�HID || 2.�r�p�HID �ť�,�B���۵M�H��
            	 �r�p�H��ơ׳Q�O�I�H��� */
            if((strcmp(sIassured, sIacc_license) == 0)||
               ((strcmp(sFassured, "1") == 0) && (strlen(sIacc_license) == 0)))
            {
                sprintf(sTmp1,
           		    "select case when fassured in ('1','5') then '1' else '2' end as fassured,  \
           		            nassured, to_char(dbirth,'%%Y%%m%%d') as dbirth, fsex, \
           		            fmarriage, '1' as sFacc_rel, iassured, '1' \
                       from %s:policy \
                      where ipolicy = '%s' ", sFullName, sIpolicy);
	            printf("sTmp1=[%s]\n",sTmp1);
	            $PREPARE pre_C2 FROM $sTmp1;
	            $DECLARE cur_C2 CURSOR FOR pre_C2;
	            $OPEN cur_C2;
	            $FETCH cur_C2 into $sFacc_nation, $sNacc_driver, $sTmpDate2, $sFacc_sex,
	                               $sFacc_marri, $sFacc_rel, $sIacc_license, $sFacc_rel;
	            $CLOSE cur_C2;
	            $FREE cur_C2;
            }
            else
            {
            	if(strlen(sFacc_nation) == 0) 	ipflag = 1;
        		if(strlen(sNacc_driver) == 0) 	ipflag = 1;
			    if(strlen(sIacc_license) == 0) ipflag = 1;
			    if(strlen(sTmpDate2) == 0) 		ipflag = 1;
			    if(strlen(sFacc_sex) == 0) 		ipflag = 1;
			    if(strlen(sFacc_marri) == 0) 	ipflag = 1;
			    if(strlen(sFacc_rel) == 0) 		ipflag = 1;
            }

            if (ipflag == 1)
            {
            	sprintf(errMsg,"��[%d]�� �U����Ƥ��o���ť� \n", iline);
	            $insert into car540_errlog(inumber_0800, errno, errmsg) values ($sInumber_0800, 'E002', $errMsg);
	            icnt_err ++;
	            printf("errMsg=[%s]\n",errMsg);
	            memset(bp, ' ', recLen);
	            continue;
            }
        }

        if (ipflag == 1)
        {
            sprintf(errMsg,"��[%d]�� �U����Ƥ��o���ť� \n", iline);
            $insert into car540_errlog(inumber_0800, errno, errmsg) values ($sInumber_0800, 'E002', $errMsg);
            icnt_err ++;
            printf("errMsg=[%s]\n",errMsg);
            memset(bp, ' ', recLen);
            continue;
        }

        /* �X�ͤ�� (YYYY/MM/DD)*/
        memset(sYYYY,0x00,sizeof(sYYYY));
        memset(sMM,0x00,sizeof(sMM));
        memset(sDD,0x00,sizeof(sDD));
        memset(sIacc_birth,0x00,sizeof(sIacc_birth)); /* (CYYMMDD) */
        memset(sDacc_birth,0x00,sizeof(sDacc_birth)); /* (MM/DD/YYYY) */
        strncpy(sYYYY,sTmpDate2,4);    sYYYY[4] = '\0';
        strncpy(sMM,&sTmpDate2[4],2);  sMM[2] = '\0';
        strncpy(sDD,&sTmpDate2[6],2);  sDD[2] = '\0';

        sprintf(sIacc_birth,"%d%s%s",atoi(sYYYY)-1911,sMM,sDD);
        sprintf(sDacc_birth,"%s/%s/%s",sMM,sDD,sYYYY);

        printf("sDaccident=[%s]  sDacc_birth=[%s]  sIacc_birth=[%s]  sDreceiver=[%s]\n",
                sDaccident, sDacc_birth, sIacc_birth, sDreceiver);

        /* �ˮ־r�p����18�� add by sylvia 108.04.18 (�F���q�����s�W�ˮ�) */
        strcpy(fOver18,"N");
        $select first 1 case when date(to_date($sDaccident,'%Y-%m-%d %H:%M')) >= add_months(date($sDacc_birth),216)
                then 'Y' else 'N' end
           into $fOver18
           from car_code;

        printf("453: sDaccident=[%s]  sDacc_birth=[%s] fOver18 =[%s]\n", sDaccident, sDacc_birth, fOver18);
        if (strcmp(fOver18,"N") == 0)
        {
            sprintf(errMsg,"��[%d]�� �r�p�H�ͤ�[%s] ��X�I��[%s]����18�� \n", iline, sDacc_birth, sDaccident);
            $insert into car540_errlog(inumber_0800, errno, errmsg) values ($sInumber_0800, 'E025', $errMsg);
            ipflag = 1;
            icnt_err ++;
        }

        /* �z�ߤH�� */
        $select iofficer into $sTmpCol
           from officer
          where iofficer = $sAdjustment
            and (dexpire is null or dexpire > today);
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf(errMsg,"��[%d]�� �d�L�z�߭�[%s]��� \n", iline, sAdjustment);
            $insert into car540_errlog(inumber_0800, errno, errmsg) values ($sInumber_0800, 'E003', $errMsg);
            ipflag = 1;
            icnt_err ++;
        }

        /* �X�I�a�� */
        $select dvp_code into $sTmpCol
           from ca_dvp_ply_area
          where dvp_code = $sIacc_area;
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf(errMsg,"��[%d]�� �X�I�a�ϥN�X[%s]���~ \n", iline, sIacc_area);
            $insert into car540_errlog(inumber_0800, errno, errmsg) values ($sInumber_0800, 'E004', $errMsg);
            ipflag = 1;
            icnt_err ++;
        }

        /* ��/�~��H */
        if ((strcmp(sFacc_nation,"1") !=0) && (strcmp(sFacc_nation,"2") !=0) &&
            (strcmp(sFacc_nation,"7") !=0) && (strcmp(sFacc_nation,"8") !=0))
        {
            sprintf(errMsg,"��[%d]�� �r�p�H��O[%s]���~ \n", iline, sFacc_nation);
            $insert into car540_errlog(inumber_0800, errno, errmsg) values ($sInumber_0800, 'E005', $errMsg);
            ipflag = 1;
            icnt_err ++;
        }
        if (strcmp(sFacc_nation,"1") ==0)
        {
        		if((sIacc_license[0] < 65) || (sIacc_license[0] > 90) || (sIacc_license[1] > 50) || (sIacc_license[1] < 49))
        		{
        			sprintf(errMsg,"��[%d]�� �r�p�HID[%s]���~ \n", iline, sIacc_license);
            	$insert into car540_errlog(inumber_0800, errno, errmsg) values ($sInumber_0800, 'E006', $errMsg);
            	ipflag = 1;
            	icnt_err ++;
        		}
        }

		/* 38/39/238���v���B�ˮ� */
        if((iMins_38<=0)&&(iMins_39<=0)&&(iMins_238<=0))
        {
            sprintf(errMsg,"��[%d]�� 38�B39�B238 �I�ؽ��v���B�ܤ֦��@�Ӷ��j��0 \n", iline);
            $insert into car540_errlog(inumber_0800, errno, errmsg) values ($sInumber_0800, 'E007', $errMsg);
            ipflag = 1;
            icnt_err ++;
        }

        if((iMins_38+iMins_39+iMins_238) != iMamount )
        {
            sprintf(errMsg,"��[%d]�� 38+39+238�I�ؽ��v���B[%d]������ϴ��O��[%d] \n", iline, iMins_38+iMins_39+iMins_238, iMamount);
            $insert into car540_errlog(inumber_0800, errno, errmsg) values ($sInumber_0800, 'E008', $errMsg);
            ipflag = 1;
            icnt_err ++;
        }

        /* �ʧO */
        if ((atoi(sFacc_sex) < 1) || (atoi(sFacc_sex) > 2))
        {
        	  sprintf(errMsg,"��[%d]�� �ʧO[%s]�u�ର 1 �� 2  \n", iline, sFacc_sex);
            $insert into car540_errlog(inumber_0800, errno, errmsg) values ($sInumber_0800, 'E009', $errMsg);
            ipflag = 1;
            icnt_err ++;
        }

        /* �B�� */
        if ((atoi(sFacc_marri) < 1) || (atoi(sFacc_marri) > 2))
        {
        	  sprintf(errMsg,"��[%d]�� �B��[%s]�u�ର 1 �� 2  \n", iline, sFacc_marri);
            $insert into car540_errlog(inumber_0800, errno, errmsg) values ($sInumber_0800, 'E010', $errMsg);
            ipflag = 1;
            icnt_err ++;
        }


        /* ���Y */
        if(((atoi(sFacc_rel) != 1)&&(atoi(sFacc_rel) != 4)&&(atoi(sFacc_rel) != 5)) &&
            ((sFacc_rel[0] < 65 ) || (sFacc_rel[0] > 71 )))
        {
            sprintf(errMsg,"��[%d]�� �r�p�P�Q�O�H���Y[%s]�Ȭ� 1�BA�BB�BC�BD�BE�BF�BG�B4�B5 \n", iline, sFacc_rel);
            $insert into car540_errlog(inumber_0800, errno, errmsg) values ($sInumber_0800, 'E011', $errMsg);
            ipflag = 1;
            icnt_err ++;
        }

        strcpy(sTmpClaim, "�L");
        ipflag2 = 0;

        /* 1.�P�@�O�渹�B�P�@�X�I�ɶ��O�_�w���X�I */
        $select first 1 iclaim
           into $sTmpClaim
           from ca_clm_process
          where ipolicy = $sIpolicy
            and daccident = $sDaccident;

        if (SQLCODE != SQLNOTFOUND)
        {
            sprintf(errMsg,"��[%d]�� �P�@�O�渹[%s]�P�@�X�I�ɶ��w���߮׸��, �߮׸�[%s] \n",iline, sIpolicy,trim(sTmpClaim));
            $insert into car540_errlog(inumber_0800, errno, errmsg) values ($sInumber_0800, 'E012', $errMsg);
            ipflag = 1;
            ipflag2 = 1;
            icnt_err ++;
            printf("errMsg=[%s] ipflag2=[%d]\n",errMsg,ipflag2);
        }

        /* 2.�ˮ֫O��򥻸�� */

        /* ---------------------------------------------------------------
        	 chk1:���P�O�_��  Y:�۲� N:���۲�
        	 chk2:�Q�O�H�W�٬O�_��  Y:�۲� N:���۲�
        	 chk3:�X�I��O�_>ñ��� Y:�۲� N:���۲� (���ˮ֤F)
        	 chk4:�O/���O�_�w���O Y:�w�� N:����
        	 chk5:�X�I��O�_�b�O����  Y:�b�O���� N:���b�O����
           --------------------------------------------------------------*/
        if (ipflag2 == 0)
        {
       	    memset(sIassured,0x00,sizeof(sIassured));
       	    memset(sIangine,0x00,sizeof(sIangine));

            strcpy(sFullName, get_car_full_db(sIpolicy));
            printf("519:sFullName=[%s]sIpolicy=[%s]\n",sFullName,sIpolicy);
            sprintf(sTmp1,
                "select decode(trim(b.itag), '%s', 'Y', 'N') as chk1, \
                        decode(replace(trim(b.nassured),' ',''), '%s', 'Y', 'N') as chk2, \
                        b.iassured, b.iengine, \
                        case when b.fassured in ('1','3','5') then '1' else '2' end as fassured, \
                        case when (select count(*) from ao_plyedr_prem \
                                    where insure_type = 'C' \
                                      and ipolicy1 = '%s' and ipolicy2 = ' ' \
                                      and ftype in ('P','E') and frcvpay  <> 'P') = 0 then \
                                   'Y' else 'N' end as chk4, \
                        case when extend(extend('%s', year to minute),year to hour) >= extend(dply_begin,year to hour)+ 12 UNITS hour \
                              and extend(extend('%s', year to minute),year to hour) <= extend(dply_end,year to hour)+ 12 UNITS hour then \
                              'Y' else 'N' end as chk5 , b.nassured , a.dply_end , b.itag  \
                   from %s:ply_relation a, %s:policy b \
                  where a.ipolicy = b.ipolicy \
                    and a.ipolicy = '%s' \
                    and a.dply_close is not null \
                    and a.fcard_class = '2' ",
                 sItag, sNassured,  sIpolicy, sDaccident, sDaccident,
                 sFullName, sFullName, sIpolicy);
            printf("sTmp1=[%s]\n",sTmp1);
            $PREPARE pre_A2 FROM $sTmp1;
            $DECLARE cur_A2 CURSOR FOR pre_A2 ;
            $OPEN cur_A2;
            $FETCH cur_A2 into $chk1, $chk2, $sIassured, $sIangine, $sFassured,
                               $chk4, $chk5, $tmpNassured, $sdply_end, $sTag;
            if (SQLCODE == SQLNOTFOUND)
            {   sprintf(errMsg,"��[%d]�� �O�渹[%s]�d�L�ӫO��� \n", iline, sIpolicy);
                $insert into car540_errlog(inumber_0800, errno, errmsg) values ($sInumber_0800, 'E001', $errMsg);
                ipflag = 1;
                ipflag2 = 1;
                icnt_err ++;
                printf("547:errMsg=[%s]\n",errMsg);
            }
            $CLOSE cur_A2;
            $FREE cur_A2;


            if (strcmp(chk1,"N") == 0)
            {
                sprintf(errMsg,"��[%d]�� ���P�P�O�渹[%s]�Ҹ����šA���P:[%s] \n", iline, sIpolicy, sTag);
                $insert into car540_errlog(inumber_0800, errno, errmsg) values ($sInumber_0800, 'E013', $errMsg);
                ipflag = 1;
                ipflag2 = 1;
                icnt_err ++;
            }

            /* �������ҥ�mark, �W�u�e�n���}�ˮ� (�]���W�r���B�n) */
            if ((ipflag2 == 0) && (strcmp(chk2,"N") == 0))
            {
            	printf("123456�Q�O�I�H:[%s]" , trim(tmpNassured));
            	sprintf(strNassured,trim(tmpNassured));
            	            	
            	printf("123456�Q�O�I�H:[%s]" , strNassured);

                sprintf(errMsg,"��[%d]�� 0800MEMO�渹[%s]�A�Q�O�I�H�W�ٻP�O�渹[%s]�Ҹ����šA�Q�O�I�H:[%s]�BID:[%s] \n",
                                iline, sInumber_0800,sIpolicy,strNassured, trim(sIassured));
                                
                printf("123456�Q�O�I�H:[%s]" , errMsg);
            
                $insert into car540_errlog(inumber_0800, errno, errmsg) values ($sInumber_0800, 'E013', $errMsg);
                ipflag = 1;
                ipflag2 = 1;
                icnt_err ++;
            }

            if (strcmp(chk4,"N") == 0)
            {
                sprintf(errMsg,"��[%d]��  �O�渹[%s]�A�O��/��� �����O \n",
                               iline, sIpolicy);
                $insert into car540_errlog
                    (inumber_0800, errno, errmsg)
                 values
                    ($sInumber_0800, 'E015', $errMsg);
                ipflag = 1;
                ipflag2 = 1;
                icnt_err ++;
            }

            if (strcmp(chk5,"N") == 0)
            {
                sprintf(errMsg,"��[%d]�� �X�I�ɶ����b�O��[%s]�O�����A���ͮİh�O��:[%s] \n",
                                iline, sIpolicy, sdply_end);
                $insert into car540_errlog
                    (inumber_0800, errno, errmsg)
                 values
                    ($sInumber_0800, 'E016', $errMsg);
                ipflag = 1;
                ipflag2 = 1;
                icnt_err ++;
            }

            /* �s�W�ˮ֡G�w�������l�A��h���o�פJ�߮�  add by sylvia 110.07.26 (1100707009_SC1) */
            strcpy(tmp_iclaim1,"");

            sprintf(sTmp1,
                "select first 1 iclaim \
                   from %s:appraisal \
                  where ipolicy = '%s' and fpart <> '4'  order by dclaim DESC; ",
                  sFullName, sIpolicy);

            printf("684:sTmp1=[%s]\n",sTmp1);
            $PREPARE pre_A3a FROM $sTmp1;
            $DECLARE cur_A3a CURSOR FOR pre_A3a ;
            $OPEN cur_A3a;
            $FETCH cur_A3a into $tmp_iclaim1;
            printf("sqlcode=[%d]\n",SQLCODE);
            if (SQLCODE != SQLNOTFOUND)
            {
                printf("------- 697 ---------- \n");
                sprintf(errMsg,"��[%d]�� �O��[%s]�w�����l��߮�[%s]���o�פJ�߮� \n",
                            iline, sIpolicy,tmp_iclaim1);

                $insert into car540_errlog
	                    (inumber_0800, errno, errmsg)
	                 values
	                    ($sInumber_0800, 'E027', $errMsg);
                ipflag = 1;
                ipflag2 = 1;
                icnt_err ++;
                printf("702:errMsg=[%s]\n",errMsg);
            }
            $CLOSE cur_A3a;
            $FREE cur_A3a;
			printf("----- 707 -----\n");

            /* ���Y�ˮ֤G */
            strcpy(sIassured, trim(sIassured));
            if (strcmp(sIassured, sIacc_license) == 0)
            {
                if (strcmp(sFacc_rel,"1") != 0)
            	{
	                sprintf(errMsg,"��[%d]�� �O�渹[%s]�A�r�p�HID = �Q�O�I�HID, ���Y���� 1 \n",
	                                iline, sIpolicy);
	                $insert into car540_errlog
	                    (inumber_0800, errno, errmsg)
	                 values
	                    ($sInumber_0800, 'E017', $errMsg);
	                ipflag = 1;
	                ipflag2 = 1;
	                icnt_err ++;
                }
            }
            else
            {
            	if (strcmp(sFassured,"1") == 0)	/* �۵M�H */
                {
            	    if ((sFacc_rel[0] > 68) || (sFacc_rel[0] < 65))
            	 	{
            	 		sprintf(errMsg,"��[%d]�� �O�渹[%s]�A�۵M�H��, ID���P, ���Y�u�ର A�BB�BC�BD \n", iline, sIpolicy);
		                $insert into car540_errlog(inumber_0800, errno, errmsg) values ($sInumber_0800, 'E018', $errMsg);
		                ipflag = 1;
		                ipflag2 = 1;
		                icnt_err ++;
            	 	}
            	}
            	else
            	{
            		if (((sFacc_rel[0] > 71) || (sFacc_rel[0] < 69)) &&
            		    (strcmp(sFacc_rel,"4") != 0) && (strcmp(sFacc_rel,"5") != 0))
            		{
            		 	sprintf(errMsg,"��[%d]�� �O�渹[%s]�A�k�H��, ���Y�u�ର E�BF�BG�B4�B5 \n", iline, sIpolicy);
						$insert into car540_errlog(inumber_0800, errno, errmsg) values ($sInumber_0800, 'E019', $errMsg);
		               	ipflag = 1;
		               	ipflag2 = 1;
		               	icnt_err ++;
            		}
            	}
            }

            mdamage_cover = minjured_cover = 0;
            printf("----- 702 -----\n");
            /*----------------------------------------------------------------*/
            /* IFRS�����ˮ� add by sylvia 111.10.24 (1110303007��SC3) */
            /*----------------------------------------------------------------*/
            strcpy(iportfolio, " ");
            strcpy(igroup_profit, " ");

            if (iMins_38 > 0)
            {
                sprintf(sTmp1,
                "select first 1 mdamage_cover \
                   from %s:ply_ins_type_hist \
                  where ipolicy = '%s' \
                    and iins_type = '38' \
                    and extend(extend('%s', year to minute),year to hour) >= extend(dedr_begin,year to hour)+ 12 UNITS hour \
                    and extend(extend('%s', year to minute),year to hour) <= extend(dedr_end,year to hour)+ 12 UNITS hour \
                    and fedr_status < 80 \
                  order by dedr_begin DESC, dendorse DESC, fedr_status DESC; ",
                sFullName, sIpolicy, sDaccident, sDaccident);
                printf("585:sTmp1=[%s]\n",sTmp1);
                $PREPARE pre_A3 FROM $sTmp1;
                $DECLARE cur_A3 CURSOR FOR pre_A3 ;
                $OPEN cur_A3;
                $FETCH cur_A3 into $mdamage_cover;
                if (SQLCODE == SQLNOTFOUND)
                {
                    ipflag = 1;
                    ipflag2 = 1;
                    icnt_err ++;
                    printf("600:errMsg=[%s]\n",errMsg);
                }
                $CLOSE cur_A3;
                $FREE cur_A3;
				printf("----- 729 -----\n");

                if (mdamage_cover == 0)
                {
                    sprintf(errMsg,"��[%d]�� �O�渹[%s]�d�L38�I�ةӫO��ƩΤw�h�O \n", iline, sIpolicy);
                    $insert into car540_errlog(inumber_0800, errno, errmsg) values ($sInumber_0800, 'E020', $errMsg);
                    ipflag = 1;
                    ipflag2 = 1;
                    icnt_err ++;
                    printf("612:errMsg=[%s]\n",errMsg);
                }
                else
                {
                    /* IFRS�ˮ� add by sylvia 111.10.26 
                    if (strcmp(sYN,"Y") == 0)
                    {
                        strcpy(iportfolio, " ");
                        strcpy(igroup_profit, " ");

                        rc = chk_IFRS_claim("2", sIpolicy, " ", "38", &iportfolio, &igroup_profit, &icnt1, &sMsg);
                        if (icnt1 > 0)
                        {
                            strcpy(errMsg, sMsg);
                            $insert into car540_errlog(inumber_0800, errno, errmsg) values ($sInumber_0800, 'E028', $errMsg);
                            ipflag = 1;
                            ipflag2 = 1;
                            icnt_err ++;
                        }
                    }*/
                }

            }

            if (iMins_39 > 0)
            {
                sprintf(sTmp1,
                "select first 1 mdamage_cover \
                   from %s:ply_ins_type_hist \
                  where ipolicy = '%s' \
                    and iins_type = '39' \
                    and extend(extend('%s', year to minute),year to hour) >= extend(dedr_begin,year to hour)+ 12 UNITS hour \
                    and extend(extend('%s', year to minute),year to hour) <= extend(dedr_end,year to hour)+ 12 UNITS hour \
                    and fedr_status < 80 \
                  order by dedr_begin DESC, dendorse DESC, fedr_status DESC; ",
                sFullName, sIpolicy, sDaccident, sDaccident);
                printf("613:sTmp1=[%s]\n",sTmp1);
                $PREPARE pre_A4 FROM $sTmp1;
                $DECLARE cur_A4 CURSOR FOR pre_A4 ;
                $OPEN cur_A4;
                $FETCH cur_A4 into $mdamage_cover;
                if (SQLCODE == SQLNOTFOUND)
                {
                    ipflag = 1;
                    ipflag2 = 1;
                    icnt_err ++;
                    printf("errMsg=[%s]\n",errMsg);
                }
                $CLOSE cur_A4;
                $FREE cur_A4;
                printf("----- 768 -----\n");
                if (mdamage_cover == 0)
                {
                    sprintf(errMsg,"��[%d]�� �O�渹[%s]�d�L39�I�ةӫO��ƩΤw�h�O \n", iline, sIpolicy);
                    $insert into car540_errlog(inumber_0800, errno, errmsg) values ($sInumber_0800, 'E020', $errMsg);
                    ipflag = 1;
                    ipflag2 = 1;
                    icnt_err ++;
                    printf("errMsg=[%s]\n",errMsg);
                }
                else
                {
                    /* IFRS�ˮ� add by sylvia 111.10.26 
                    if (strcmp(sYN,"Y") == 0)
                    {
                        strcpy(iportfolio, " ");
                        strcpy(igroup_profit, " ");

                        rc = chk_IFRS_claim("2", sIpolicy, " ", "39", &iportfolio, &igroup_profit, &icnt1, &sMsg);
                        if (icnt1 > 0)
                        {
                            strcpy(errMsg, sMsg);
                            $insert into car540_errlog(inumber_0800, errno, errmsg) values ($sInumber_0800, 'E028', $errMsg);
                            ipflag = 1;
                            ipflag2 = 1;
                            icnt_err ++;
                        }
                    }*/
                }
            }

            if (iMins_238 > 0)
            {
                sprintf(sTmp1,
                "select first 1 minjured_cover, mdamage_cover \
                   from %s:ply_ins_type_hist \
                  where ipolicy = '%s' \
                    and iins_type = '238' \
                    and extend(extend('%s', year to minute),year to hour) >= extend(dedr_begin,year to hour)+ 12 UNITS hour \
                    and extend(extend('%s', year to minute),year to hour) <= extend(dedr_end,year to hour)+ 12 UNITS hour \
                    and fedr_status < 80 \
                  order by dedr_begin DESC, dendorse DESC, fedr_status DESC; ",
                sFullName, sIpolicy, sDaccident, sDaccident);
                printf("613:sTmp1=[%s]\n",sTmp1);
                $PREPARE pre_A5 FROM $sTmp1;
                $DECLARE cur_A5 CURSOR FOR pre_A5 ;
                $OPEN cur_A5;
                $FETCH cur_A5 into $minjured_cover, $mdamage_cover;
                if (SQLCODE == SQLNOTFOUND)
                {
                    ipflag = 1;
                    ipflag2 = 1;
                    icnt_err ++;
                    printf("errMsg=[%s]\n",errMsg);
                }
                $CLOSE cur_A5;
                $FREE cur_A5;
                printf("----- 768 -----\n");
                if (mdamage_cover == 0)
                {
                    sprintf(errMsg,"��[%d]�� �O�渹[%s]�d�L238�I�ةӫO��ƩΤw�h�O\n", iline, sIpolicy);
                    $insert into car540_errlog(inumber_0800, errno, errmsg) values ($sInumber_0800, 'E020', $errMsg);
                    ipflag = 1;
                    ipflag2 = 1;
                    icnt_err ++;
                    printf("errMsg=[%s]\n",errMsg);
                }
                else
                {
                    /* IFRS�ˮ� add by sylvia 111.10.26 
                    if (strcmp(sYN,"Y") == 0)
                    {
                        strcpy(iportfolio, " ");
                        strcpy(igroup_profit, " ");

                        rc = chk_IFRS_claim("2", sIpolicy, " ", "238", &iportfolio, &igroup_profit, &icnt1, &sMsg);
                        if (icnt1 > 0)
                        {
                            strcpy(errMsg, sMsg);
                            $insert into car540_errlog(inumber_0800, errno, errmsg) values ($sInumber_0800, 'E028', $errMsg);
                            ipflag = 1;
                            ipflag2 = 1;
                            icnt_err ++;
                        }
                    }*/
                }

                /* �w�X�I238�ˮ� */
                iCntA = 0;
                iCntB = mdamage_cover / minjured_cover; /* 238�I�ة�Q���ƤW�� */

                sprintf(sTmp1,
                        "select count(*) from ca_clm_process a, %s:stl_ins_type b "
                        " where a.iclaim = b.iclaim   and b.fstl = '1' "
                        "   and b.iins_type = '238'   and b.mins_stl > 0 "
                        "   and a.ipolicy = '%s' ", sFullName, sIpolicy);
                $PREPARE pre_A6 FROM $sTmp1;
                $DECLARE cur_A6 CURSOR FOR pre_A6 ;
                $OPEN cur_A6;
                $FETCH cur_A6 into $iCntA;
                $CLOSE cur_A6;
                $FREE cur_A6;
                if (iCntA > iCntB)
                {
                    sprintf(errMsg,"��[%d]�� �O�渹[%s] 238�I�ؤw��Q�W�L�W��(%d��)  \n", iline, sIpolicy, iCntB);
                    $insert into car540_errlog(inumber_0800, errno, errmsg) values ($sInumber_0800, 'E026', $errMsg);
                    ipflag = 1;
                    ipflag2 = 1;
                    icnt_err ++;
                    printf("errMsg=[%s]\n",errMsg);
                }

            }
        }

        /* �ƥ��ˮ�(end) -------------------------------------------------- */

        if (ipflag == 0)
        {
        	printf("----- 785 -----\n");
        	printf("sInumber_0800=[%s] sIpolicy=[%s] sItag=[%s]",sInumber_0800,sIpolicy,sItag);
        	printf("sNassured=[%s] sIassured=[%s] sIangine=[%s]",sNassured,sIassured,sIangine);
        	printf("sDaccident=[%s] sDreceiver=[%s] sInvoice=[%s]",sDaccident,sDreceiver,sInvoice);
        	printf("iMamount=[%d] sPly_ins_type=[%s] iMins_38=[%d]",iMamount,sPly_ins_type,iMins_38);
        	printf("iMins_39=[%d] sIacc_area=[%s] sFacc_nation=[%d]",iMins_39,sIacc_area,sFacc_nation);
        	printf("sNacc_driver=[%s] sIacc_license=[%s] sDacc_birth=[%s]",sNacc_driver,sIacc_license,sDacc_birth);
        	printf("sFacc_sex=[%s] sFacc_marri=[%s] sFacc_rel=[%s]",sFacc_sex,sFacc_marri,sFacc_rel);
        	printf("sAdjustment=[%s] sIdatano=[%s] sItransno=[%s]",sAdjustment,sIdatano,sItransno);

           $INSERT INTO car540_temp
              VALUES ($sInumber_0800, $sIpolicy, $sItag, $sNassured, $sIassured,
                      $sIangine, $sDaccident, $sDreceiver, $sInvoice, $iMamount,
                      $sPly_ins_type, $iMins_38, $iMins_39, $iMins_238, $sIacc_area,
                      $sFacc_nation, $sNacc_driver, $sIacc_license, $sDacc_birth,
                      $sFacc_sex, $sFacc_marri, $sFacc_rel, $sAdjustment, $sIdatano,
                      $sItransno, ' ', $iCntB, $iCntA);

            printf("661: SQLCODE=[%d]\n",SQLCODE);

            if (SQLCODE != 0)
            {
                 sprintf(errMsg, "0800MEMO:[%s]\t SQLCODE=[%d] [%s] \n", sInumber_0800,SQLCODE,sqlca.sqlerrm);
                 $insert into car540_errlog(inumber_0800, errno, errmsg) values ($sInumber_0800, 'E000', $errMsg);
                 ipflag = 1;
                 icnt_err ++;
            }
            else
            {
          	    icnt++;
            }
        }
        memset(bp, ' ', recLen);
    }

    fclose(fp);
    printf("677: icnt=[%d]-------------------------------------- \n",icnt);
    if (iline == 0)
    {
        EWRITE(userid, M_CM_NOT_FOUND, "�ɮפ��L���!! \n");
        printf("681: -------------------------------------- \n");
        return FAIL;
    }

    printf("685: -------------------------------------- \n");
    icnt2 = 0;
    icnt3 = 0;

    /* �P�@0800MEMO�s�����h��(��������) */
    printf("--- 818 --- \n");
    $insert into car540_errlog
     select inumber_0800, 'E021', '0800MEMO�渹: '||inumber_0800||' �������ɦ��h�� ' || chr(10)
       from car540_temp
      where 1=1
      group by 1
      having count(*) > 1;

    /* �P�@�O�渹�B�P�@�X�I�ɶ����h��(��������) */
    printf("--- 827 --- \n");
    $insert into car540_errlog2
     select ipolicy, 'E022', daccident, '�P�@�O��:'||trim(ipolicy)||'�B�P�@�X�I�ɶ�: '||daccident||' �������ɦ��h�� ' || chr(10)
       from car540_temp
      where 1=1
      group by 1,3
      having count(*) > 1;

    /* �P�@0800MEMO�s�����h��(���g) */
    printf("--- 836 --- \n");
    $insert into car540_errlog
     select inumber_0800, 'E023', '0800MEMO�渹: '||inumber_0800||' �H�e�����ɹL ' || chr(10)
       from sysdb:ca_tow_away
      where 1=1
      group by 1
      having count(*) > 1;

    /* �P�@�O�渹�B�P�@�X�I�ɶ����h��(�z�ߨt�Φ��߮�) */
    printf("--- 845 --- \n");
    $select unique ipolicy, extend(daccident, year to hour) as daccident
       from car540_temp
       into temp tp_policy with no log;

    printf("--- 849 --- \n");

    $insert into car540_errlog2
     select ipolicy, errno, daccident,errmsg
       from (select b.ipolicy, 'E024' as errno, a.daccident, b.daccident as daccident2,
                    '�P�@�O��:'||trim(a.ipolicy)||'�B�P�@�X�I�ɶ�: '||extend(a.daccident,year to hour)||' ���h��(�z�ߨt�Φ��߮�)' || chr(10) as errmsg
               from ca_clm_process a, tp_policy b
              where a.ipolicy = b.ipolicy )
      where cast(daccident as datetime  year to hour) = daccident2;


    /* �ˮ�238�I�اt�������ɬO�_�W�L���� */
    printf("--- 966 --- \n");
    $select ipolicy, iCnt_Base, iCnt238, count(*)+iCnt238 as icnt2
       from car540_temp
      where mins_238 > 0
      group by 1,2,3
       into temp tb_over238 with no log;

    $INSERT INTO car540_errlog
     SELECT ipolicy, 'E26', '�O�渹:'||trim(ipolicy)||'�t�������ɤw�W�L238�I�ة�Q����'
       FROM tb_over238
      where icnt2 > iCnt_Base;

    printf("--- 860 --- \n");
    $select count(*) into $icnt2 from car540_errlog where 1=1;
    $select count(*) into $icnt3 from car540_errlog2 where 1=1;

    printf("--- 865 icnt2=[%d] icnt3=[%d]--- \n",icnt2,icnt3);
    if ((icnt2+icnt3) > 0)
    {
        ipflag = 1;
        icnt_err ++;
    }

    printf("icnt_err=[%d]\n",icnt_err);

    if (icnt_err > 0)
    {
        strcpy(errMsg2,"");
        strcpy(errMsg,"");

        $DECLARE get_errlog CURSOR FOR
          SELECT errno||'\t'||inumber_0800||'\t'||errmsg FROM car540_errlog where 1=1
          union all
          SELECT errno||'\t'||' '||'\t'||errmsg FROM car540_errlog2 where 1=1;

        $OPEN get_errlog;
        for(;;)
        {
            $FETCH get_errlog INTO $errMsg2 ;
            printf("errMsg2 = [%s]\n", errMsg2);
            if (SQLCODE == SQLNOTFOUND) break;
            strcat(errMsg,rtrim(errMsg2));
        }
        return FAIL;
    }
    return M_CM_OK;

errexit:
    printf("------> errexit: sInumber_0800[%s] \n", sInumber_0800);
    strcpy(errMsg1, errMsg);
    sprintf(errMsg," 0800MEMO��: [%s], errMsg: [%s] SQLCODE=[%d] \n", sInumber_0800, errMsg1,SQLCODE);
    rc = cm_show_sql_err("ca540_trans", "");
    return rc;
}
/*----------------------------------------------------------------------------*/
long car540_exec()
{

    $char   sTrsql[500];
    $int    tmpnum, icnt_base,icnt238;

    EXEC SQL WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT 2;


    $select first 1 'A'||to_char(today ,'%y%m%d')
       into $isign_tmp
       from car_code;

	  printf("isign_tmp=[%s]  sAdjustment=[%s]\n",isign_tmp,sAdjustment);

    $Begin Work;

    sprintf(sTrsql, "select *,extend(daccident, year to hour), \
                            to_char(iacc_birth,'%%Eg%%Ey%%0m%%0d') \
                       from car540_temp where 1=1 for update ");
    $PREPARE pre_E1 FROM $sTrsql;
    $DECLARE cur_E1 CURSOR for pre_E1 ;
    $OPEN cur_E1;
    while (1)
    {
        $FETCH cur_E1 into
            $sInumber_0800, $sIpolicy, $sItag, $sNassured, $sIassured,
            $sIangine, $sDaccident, $sDreceiver, $sInvoice, $iMamount,
            $sPly_ins_type, $iMins_38, $iMins_39, $iMins_238, $sIacc_area,
            $sFacc_nation, $sNacc_driver, $sIacc_license, $sDacc_birth, $sFacc_sex,
            $sFacc_marri, $sFacc_rel, $sAdjustment, $sIdatano, $sItransno, $sIclaim,
            $icnt_base,$icnt238, $sDaccident2, $sIacc_birth;

        if (SQLCODE == SQLNOTFOUND) break;

        /* ���߮׸� ------------------------------------------------------  */
        printf("-- 953 sAdjustment=[%s]\n",sAdjustment);
        printf("-- 953 sDacc_birth=[%s] sIacc_birth=[%s]\n",sDacc_birth,sIacc_birth);
        printf("-- 953 sDaccident=[%s] sDaccident2=[%s]\n",sDaccident,sDaccident2);

        $select c.ibranch_abbr, a.iapp_unit, lpad(year(today)-2011,2,0),
                a.iapp_unit||c.ibranch_abbr||lpad(year(today)-2011,2,0)||'T',
                d.iquota
           into $kcomp_no, $kdept_no, $dyear, $kserial_index, $sIquota
           from cm_clm_adjuster a, branch b, branch c, officer d
          where a.iapp_unit = b.ibranch
            and b.iupcomp = c.ibranch
            and a.empl_no = d.iofficer
            and a.empl_no = $sAdjustment;

        strcpy(kcomp_no, trim(kcomp_no));
        strcpy(kdept_no, trim(kdept_no));
        strcpy(dyear, trim(dyear));
        strcpy(kserial_index, trim(kserial_index));
        strcpy(sIquota, trim(sIquota));

        printf("kcomp_no=[%s] kdept_no=[%s] dyear=[%s] kserial_index=[%s]\n",
                kcomp_no, kdept_no, dyear, kserial_index);

        $select nvl(kserial_num,0)+1 into $tmpnum
           from autonumbering
          where kbill_grp = 'C3'
            and kbill_code = 'T'
            and kcomp_no = $kdept_no
            and kdept_no = $kcomp_no
            and dyear = $dyear
            and kserial_index = $kserial_index;

				if (SQLCODE == SQLNOTFOUND)
				{
						tmpnum = 0;
						$insert into autonumbering
						 (kbill_grp, kbill_code, kcomp_no, kdept_no, dyear,
						  dmth, dday, kserial_num, kserial_index)
						values
						 ('C3','T', $kdept_no, $kcomp_no, $dyear,
						  0, ' ', $tmpnum, $kserial_index);


				}

        if (tmpnum == 0)  tmpnum = 1;

        printf("tmpnum=[%d]\n ", tmpnum);

        sprintf(sIclaim, "%s%05d\n",kserial_index,tmpnum);

        sIclaim[11]='\0';   /* �߮׸� */

        printf("sIclaim=[%s]\n",sIclaim);

        /* ��s������ */

        $update autonumbering
            set kserial_num = $tmpnum
          where kcomp_no = $kdept_no
            and kdept_no = $kcomp_no
            and dyear = $dyear
            and kserial_index = $kserial_index;

        /* ���߮׸� (End)------------------------------------------------------  */


        /* 1.���z�@�~(car571) */
        rc=car571_insert();  /* �s�Wcar571 *//*�`�N:�����I�Φ��O���p���ˮ�, �ݽT�{!! */
        if (rc != SUCCESS)
            return rc;

        /* 2.�w���@�~(car572) */
        rc=car572_insert();  /* �s�Wcar572 */
        if (rc != SUCCESS)
            return rc;

        /* 3.�d�ҧ@�~(car573) */
        rc=car573_insert();  /* �s�Wcar573 */
        if (rc != SUCCESS)
            return rc;

        /* 4.�`�֧@�~(car574) */
        rc=car574_insert();  /* �s�Wcar574 */
        if (rc != SUCCESS)
            return rc;

        /* 5.ñ���@�~(car581) */
        rc=car581_insert();  /* �s�Wcar581 */
        if (rc != SUCCESS)
            return rc;


        /* 6.�z��@�~(car582) */
        rc=car582_insert();  /* �s�Wcar582 */
        if (rc != SUCCESS)
            return rc;

        printf(" --------------- 851 ------------- \n");
        $update car540_temp
            set iclaim = $sIclaim
          where current of cur_E1;
          printf(" --------------- 855 ------------- \n");
    }
    $CLOSE cur_E1;
    $FREE cur_E1;
    printf(" --------------- 859 ------------- \n");
    $commit work;


    return M_CM_OK;


errexit:
    printf("------> errexit: sInumber_0800[%s] \n", sInumber_0800);
    strcpy(errMsg1, errMsg);
    sprintf(errMsg,"0800MEMO��: [%s], errMsg: [%s] SQLCODE=[%d] \n", sInumber_0800, errMsg1,SQLCODE);
    rc = cm_show_sql_err("ca540", "");
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    $SET LOCK MODE TO NOT WAIT;
    return rc;
}
/* -------------------------------------------------------------------------- */
long split_policy(sIpolicy, sIpolicy1, sIpolicy2)
char *sIpolicy, *sIpolicy1, *sIpolicy2;
{
     strcpy(sIpolicy, trim(sIpolicy));
     printf("begin split_policy\n");

     if (strlen(sIpolicy) > CAR_POLICY_LEN)
     {
        strncpy(sIpolicy1, sIpolicy, CAR_POLICY_LEN);
        sIpolicy1[CAR_POLICY_LEN] = '\0';
        strncpy(sIpolicy2, sIpolicy+CAR_POLICY_LEN, CAR_TARGET_LEN);
        sIpolicy2[CAR_TARGET_LEN] = '\0';
        if (sIpolicy2[0]=='\0' || sIpolicy2[0]==' ') strcpy(sIpolicy2," ");
     }
     else
     {
        strcpy(sIpolicy1,sIpolicy);
        strcpy(sIpolicy2," ");
     }

     printf("---after split_policy -> sIpolicy[%s]\n", sIpolicy);
     printf("---after split_policy -> sIpolicy1[%s]\n", sIpolicy1);
     printf("---after split_policy -> sIpolicy2[%s]\n", sIpolicy2);

     return M_CM_OK;
}

/* ------------------------------------------------------------------------ */
long car571_insert()
{


    EXEC SQL WHENEVER SQLERROR GOTO errexit;

    strcpy(sFullName, get_car_full_db(sIpolicy));

    /* �g�J appraisal */
    sprintf(sTmpSQL1,
        "insert into %s:appraisal \
            (iclaim, fcard_class, ipolicy, icard, irelative_ply, \
             irelative_card, irelative_clm, icoclaim, dclaim, iacc_area, \
             daccident, iacc_reason, facc_duty, fdmg_duty, iadjuster, \
             frecover, fsale, nacc_driver, iacc_license, iacc_birth, dacc_birth, \
             facc_sex, facc_marri, facc_rel, facc_nation, \
             facc_car, iclm_entry, affiliated, inumber, iupdate, \
             dupdate, ifacnum, fcompensation, facoption) \
        select '%s', a.fcard_class, a.ipolicy, a.icard, a.irelative_ply, \
               nvl((select itarget2 from policy_new WHERE insure_type = 'C' \
                   AND insure_class = 'C' AND isys_source = 'CAR' \
                   AND ipolicy1 = a.irelative_ply AND ipolicy2 = ' '),' '), ' ', 'N', current, '%s', \
               '%s', '%s', '2', '2', '%s', \
               '0', '0', '%s', '%s', '%s', '%s', \
               '%s', '%s', '%s', '%s',\
               case when fassured in ('2','4','6') then '4' ELSE \
       		        CASE WHEN iassured = '%s' THEN	'1' ELSE '2' END END, \
               '%s', '%s', '%s', '%s', \
               current, ' ', '0', '0' \
          from %s:ply_relation a, %s:policy b \
         where a.ipolicy = b.ipolicy and a.ipolicy = '%s'; ",
           sFullName, sIclaim, sIacc_area, sDaccident2, sIacc_reason, sAdjustment,
           sNacc_driver, sIacc_license, sIacc_birth,  sDacc_birth, sFacc_sex,
           sFacc_marri, sFacc_rel, sFacc_nation, sIacc_license, userid, sIquota,
           sInumber_0800, userid, sFullName, sFullName, sIpolicy);
     printf("ca571_appraisal=[%s]\n",sTmpSQL1);

     $prepare ca571_appraisal from $sTmpSQL1;
     $execute ca571_appraisal;


     /* �g�J ca_clm_process */
     sprintf(sTmpSQL1,
        "insert into sysdb:ca_clm_process \
            (iclaim, ipolicy, dclaim, fmaterial, adjustment, \
             ibranch_in, \
             assign, fexam, fassist_exam, fclaim_status, iassured, \
             nassured, itag, daccident, iclm_entry, affiliated, \
             fsystem, fins, ifirst, isecond, iassist_first, iassist_second, \
             isign_est, noutstand_note, vouch_state, fexam_outs, fexam_recovery, \
             iauto_distrib,fprocess,dprocess1) \
        values \
            ('%s', '%s', today, 'N', '%s', \
              (select icomp_in from %s:ply_relation where ipolicy = '%s'), \
             '6', 0, 0, 101, '%s', \
             '%s', '%s', '%s', '%s', '%s', \
             'N', 20, ' ', ' ',  ' ', ' ', \
             ' ', ' ', 0, 0, 0, 0, 101, today) ",
       sIclaim, sIpolicy, sAdjustment, sFullName, sIpolicy, sIassured,
       sNassured, sItag, sDaccident, userid, sIquota);

     printf("ca571_ca_clm_process=[%s]\n",sTmpSQL1);
     $prepare ca571_ca_clm_process from $sTmpSQL1;
     $execute ca571_ca_clm_process;


     /* �g�J adjustment_ply */
     sprintf(sTmpSQL1,
        "insert into %s:adjustment_ply \
            (iclaim, dply_begin, dply_end, mdmg_prem, mlia_prem, \
             iofficer, iacc_area, daccident, ilicense, iassured, \
             iassured_ext, nassured, dbirth, fsex, fmarriage, \
             nuser, nbenef,  dissue, ipro_year, ibrand, \
             icar_type, qcylinder, iengine, ibody, itag, \
             moto_itag, nequipment, flimit, pdmg_align, pbrg_align, \
             plia_align, fcut, dtransfer, fpay_status, ibranch, \
             fcomp_24, iply_area, fcomp_class, mbusiness, madjcom_prem, \
             ibig_comp, ibig_branch, ibig_office, ileader, icorps, \
             iquota, icomp_in, ibranch_in, icomp_at, ibranch_at, \
             recipient, iemail, facc_rel, qpro_month,aassured, aassured_zip) \
        select '%s', a.dply_begin, a.dply_end, a.mdmg_prem, a.mlia_prem, \
               a.iofficer, '%s', '%s', ' ', b.iassured, \
               b.iassured_ext, b.nassured, b.dbirth, b.fsex, b.fmarriage, \
               b.nuser, b.nbenef, b.dissue, a.ipro_year, a.ibrand, \
               a.icar_type, b.qcylinder, b.iengine, b.ibody, b.itag, \
               ' ', b.nequipment, b.flimit, b.pdmg_align, b.pbrg_align, \
               b.plia_align, b.fcut, a.dtransfer, '1', a.ibranch, \
               b.fcomp_24, b.iply_area,  a.fcomp_class, a.mbusiness, a.madjcom_prem, \
               a.ibig_comp, a.ibig_branch, a.ibig_office, a.ileader, a.icorps, \
               a.iquota, a.icomp_in, a.ibranch, a.icomp_at, a.ibranch_at, \
               ' ', b.iemail, '%s', b.qpro_month, b.aassured, b.aassured_zip \
          from  %s:ply_relation a,  %s:policy b \
         where a.ipolicy = b.ipolicy \
           and a.ipolicy = '%s' ",
           sFullName, sIclaim, sIacc_area, sDaccident2, sFacc_rel, sFullName, sFullName, sIpolicy);

     printf("ca571_adjustment_ply=[%s]\n",sTmpSQL1);
     $prepare ca571_adjustment_ply from $sTmpSQL1;
     $execute ca571_adjustment_ply;


    /* �g�J ca_local_clm (��� ca_local_stl �u�g��x�_��Ʈw)*/
     sprintf(sTmpSQL1,
        "insert into newa00:ca_local_clm \
            (ibranch, iclaim, iadjuster, ipolicy, dclaim) \
         values \
            ('%s', '%s', '%s', '%s', today)",
           kdept_no, sIclaim, sAdjustment, sIpolicy);

     printf("ca571_ca_local_clm=[%s]\n",sTmpSQL1);
     $prepare ca571_ca_local_clm from $sTmpSQL1;
     $execute ca571_ca_local_clm;


    return SUCCESS;


errexit:
    printf("------> errexit: car571_insert: 0800�s�� [%s] \n", sInumber_0800);
    strcpy(errMsg1, errMsg);
    sprintf(errMsg,"car571_insert: \n  0800�s��: [%s], errMsg: [%s] SQLCODE=[%d] \n", sInumber_0800, errMsg1,SQLCODE);
    rc = cm_show_sql_err("car571_insert", "");
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    $SET LOCK MODE TO NOT WAIT;
    return rc;
}

/* -------------------------------------------------------------------------- */
long car572_insert()
{
    $int  iMappLoss;

    EXEC SQL WHENEVER SQLERROR GOTO errexit;

    strcpy(sFullName, get_car_full_db(sIpolicy));

    iMappLoss = iMins_38 + iMins_39 + iMins_238;

    /* ��s appraisal */
    sprintf(sTmpSQL1,
        "update %s:appraisal \
            set iacc_reason = '%s', \
                facc_duty = '2', \
                facc_duty = '2', \
                fpart = '4', \
                mapp_loss = '%d', \
                mapp_damage = '%d', \
                iapp_entry = iclm_entry, \
                dapp_entry = current \
          where iclaim = '%s' ",
           sFullName, sIacc_reason, iMappLoss, iMappLoss, sIclaim);
     printf("ca572_appraisal=[%s]\n",sTmpSQL1);

     $prepare ca572_appraisal from $sTmpSQL1;
     $execute ca572_appraisal;

     /* ��s ca_clm_process */
     printf("\n 1060:sIpolicy=[%s]\n\n",sIpolicy);
    sprintf(sTmpSQL1,
        "update sysdb:ca_clm_process \
            set dappraisal = today, \
                frule = '0', \
                fclaim_status = '201', \
                fins = '30', \
                fprocess = '101', \
                dprocess1 = today \
          where iclaim = '%s' and ipolicy = '%s' ",
           sIclaim, sIpolicy);
     printf("ca572_ca_clm_process=[%s]\n",sTmpSQL1);

     $prepare ca572_ca_clm_process from $sTmpSQL1;
     $execute ca572_ca_clm_process;


     /* �g�J app_ins_type, app_ins_type_hist */
     if (iMins_38 > 0)
     {
         sprintf(sTmpSQL1,
            "insert into %s:app_ins_type \
                (iclaim, iins_type, minjure_cover, mdeath_cover, mdamage_cover, \
                 mdeduct, mins_app, dappraisal) \
             select first 1 '%s', iins_type, minjured_cover, mdeath_cover, mdamage_cover, \
                    mdeduct, %d, today \
               from %s:ply_ins_type_hist \
              where ipolicy = '%s' \
                and  iins_type = '38' \
                and  dedr_begin <= date(to_date('%s','%%Y-%%m-%%d %%H:%%M')) \
                AND  dedr_end  >= date(to_date('%s','%%Y-%%m-%%d %%H:%%M')) \
              ORDER BY dedr_begin DESC, dendorse DESC, fedr_status DESC ",
               sFullName, sIclaim, iMins_38, sFullName, sIpolicy,
               sDaccident, sDaccident);

        printf("ca572_app_ins_type38=[%s]\n",sTmpSQL1);
        $prepare ca572_app_ins_type38 from $sTmpSQL1;
        $execute ca572_app_ins_type38;

        sprintf(sTmpSQL1,
            "insert into %s:app_ins_type_hist \
                (iclaim, iins_type, minjure_cover, mdeath_cover, mdamage_cover, \
                 mdeduct, mins_app, dappraisal, iupdate, dupdate) \
             select first 1 '%s', iins_type, minjured_cover, mdeath_cover, mdamage_cover, \
                    mdeduct, %d, today, '%s', current \
               from %s:ply_ins_type_hist \
              where ipolicy = '%s' \
                and  iins_type = '38' \
                and  dedr_begin <= date(to_date('%s','%%Y-%%m-%%d %%H:%%M')) \
                AND  dedr_end  >= date(to_date('%s','%%Y-%%m-%%d %%H:%%M')) \
              ORDER BY dedr_begin DESC, dendorse DESC, fedr_status DESC ",
               sFullName, sIclaim, iMins_38, userid, sFullName,
               sIpolicy, sDaccident, sDaccident);

        printf("ca572_app_ins_type_hist38=[%s]\n",sTmpSQL1);
        $prepare ca572_app_ins_type_hist38 from $sTmpSQL1;
        $execute ca572_app_ins_type_hist38;
     }

     if (iMins_39 > 0)
     {
         sprintf(sTmpSQL1,
            "insert into %s:app_ins_type \
                (iclaim, iins_type, minjure_cover, mdeath_cover, mdamage_cover, \
                 mdeduct, mins_app, dappraisal) \
             select first 1 '%s', iins_type, minjured_cover, mdeath_cover, mdamage_cover, \
                    mdeduct, %d, today \
               from %s:ply_ins_type_hist \
              where ipolicy = '%s' \
                and  iins_type = '39' \
                and  dedr_begin <= date(to_date('%s','%%Y-%%m-%%d %%H:%%M')) \
                AND  dedr_end  >= date(to_date('%s','%%Y-%%m-%%d %%H:%%M')) \
              ORDER BY dedr_begin DESC, dendorse DESC, fedr_status DESC ",
               sFullName, sIclaim, iMins_39, sFullName, sIpolicy,
               sDaccident, sDaccident);

        printf("ca572_app_ins_type39=[%s]\n",sTmpSQL1);
        $prepare ca572_app_ins_type39 from $sTmpSQL1;
        $execute ca572_app_ins_type39;

        sprintf(sTmpSQL1,
            "insert into %s:app_ins_type_hist \
                (iclaim, iins_type, minjure_cover, mdeath_cover, mdamage_cover, \
                 mdeduct, mins_app, dappraisal, iupdate, dupdate) \
             select first 1 '%s', iins_type, minjured_cover, mdeath_cover, mdamage_cover, \
                    mdeduct, %d, today, '%s', current \
               from %s:ply_ins_type_hist \
              where ipolicy = '%s' \
                and  iins_type = '39' \
                and  dedr_begin <= date(to_date('%s','%%Y-%%m-%%d %%H:%%M')) \
                AND  dedr_end  >= date(to_date('%s','%%Y-%%m-%%d %%H:%%M')) \
              ORDER BY dedr_begin DESC, dendorse DESC, fedr_status DESC ",
               sFullName, sIclaim, iMins_39, userid, sFullName,
               sIpolicy, sDaccident, sDaccident);

        printf("ca572_app_ins_type_hist39=[%s]\n",sTmpSQL1);
        $prepare ca572_app_ins_type_hist39 from $sTmpSQL1;
        $execute ca572_app_ins_type_hist39;
     }

    if (iMins_238 > 0)
     {
         sprintf(sTmpSQL1,
            "insert into %s:app_ins_type \
                (iclaim, iins_type, minjure_cover, mdeath_cover, mdamage_cover, \
                 mdeduct, mins_app, dappraisal) \
             select first 1 '%s', iins_type, minjured_cover, mdeath_cover, mdamage_cover, \
                    mdeduct, %d, today \
               from %s:ply_ins_type_hist \
              where ipolicy = '%s' \
                and  iins_type = '238' \
                and  dedr_begin <= date(to_date('%s','%%Y-%%m-%%d %%H:%%M')) \
                AND  dedr_end  >= date(to_date('%s','%%Y-%%m-%%d %%H:%%M')) \
              ORDER BY dedr_begin DESC, dendorse DESC, fedr_status DESC ",
               sFullName, sIclaim, iMins_238, sFullName, sIpolicy,
               sDaccident, sDaccident);

        printf("ca572_app_ins_type238=[%s]\n",sTmpSQL1);
        $prepare ca572_app_ins_type238 from $sTmpSQL1;
        $execute ca572_app_ins_type238;

        sprintf(sTmpSQL1,
            "insert into %s:app_ins_type_hist \
                (iclaim, iins_type, minjure_cover, mdeath_cover, mdamage_cover, \
                 mdeduct, mins_app, dappraisal, iupdate, dupdate) \
             select first 1 '%s', iins_type, minjured_cover, mdeath_cover, mdamage_cover, \
                    mdeduct, %d, today, '%s', current \
               from %s:ply_ins_type_hist \
              where ipolicy = '%s' \
                and  iins_type = '238' \
                and  dedr_begin <= date(to_date('%s','%%Y-%%m-%%d %%H:%%M')) \
                AND  dedr_end  >= date(to_date('%s','%%Y-%%m-%%d %%H:%%M')) \
              ORDER BY dedr_begin DESC, dendorse DESC, fedr_status DESC ",
               sFullName, sIclaim, iMins_238, userid, sFullName,
               sIpolicy, sDaccident, sDaccident);

        printf("ca572_app_ins_type_hist238=[%s]\n",sTmpSQL1);
        $prepare ca572_app_ins_type_hist238 from $sTmpSQL1;
        $execute ca572_app_ins_type_hist238;
     }



    return SUCCESS;


errexit:
    printf("------> errexit: car572_insert: 0800�s�� [%s] \n", sInumber_0800);
    strcpy(errMsg1, errMsg);
    sprintf(errMsg,"car572_insert: \n  0800�s��: [%s], errMsg: [%s] SQLCODE=[%d] \n", sInumber_0800, errMsg1,SQLCODE);
    rc = cm_show_sql_err("car572_insert", "");
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    $SET LOCK MODE TO NOT WAIT;
    return rc;
}
/* ---------------------------------------------------------------------- */
long car573_insert()
{

    $int  iMappLoss;

    EXEC SQL WHENEVER SQLERROR GOTO errexit;

    strcpy(sFullName, get_car_full_db(sIpolicy));

    iMappLoss = iMins_38 + iMins_39 + iMins_238;

    /* �s�W ca_ver_relation */
    $insert into sysdb:ca_ver_relation
            (iclaim, iverify)
     values ($sIclaim, $sIclaim);

    /* �s�W ca_verify */
    $insert into sysdb:ca_verify
        (iverify, nacc_place, iweather, iroad_state, fforce, isign,
         fverify_status, fduty_nosign, ientry, dentry,
         iupdate, dupdate, fsingle_acc, ichk_recovery)
     values
        ($sIclaim, ' ', '01', '01', '3', '00',
          200, '01', $userid, current,
         $userid, current, '3', '0');


     /* �s�W CA_CLM_VICTIM_DATA */
     strcpy(sIassured, trim(sIassured));
     strcpy(sIacc_license, trim(sIacc_license));

     if (strcmp(sIassured, sIacc_license) == 0)
     { /* �Q�O�I�H= �r�p (�۵M�H)  */
        sprintf(sTmpSQL1,
            "insert into sysdb:ca_clm_victim_data \
             select '%s', iassured, dbirth, \
                    decode(fassured,'1','1','3','2','5','8','7'),\
                    fsex, \
                    'F', '1', '1', itag, nassured, \
                    nvl(itel,' '), aassured, 'N', '00', '01', 0, \
                    ' ', 0, '00', ' ', 'N', \
                    '%s', current, '%s', current, ' ' , ' '\
               from %s:policy where ipolicy = '%s'",
               sIclaim, userid, userid, sFullName, sIpolicy);
        printf("ca573_ca_clm_process_F1=[%s]\n",sTmpSQL1);
        $prepare ca573_ca_clm_victim_data_F1 from $sTmpSQL1;
        $execute ca573_ca_clm_victim_data_F1;
     }
     else
     {
        /* �Q�O�I�H <> �r�p */
        /* G.���D */
        sprintf(sTmpSQL1,
        "insert into sysdb:ca_clm_victim_data \
         select '%s', iassured, dbirth, \
                 decode(fassured,'1','1','3','2','2','3','4','3','5','8','7'), \
                case when fassured in ('1','3','5') then fsex else '3' end , \
                'G', '1', '1', itag, nassured, \
                nvl(itel,' '), aassured, 'N', '00', '01', 0, \
                ' ', 0, '00', ' ', 'N', \
                '%s', current, '%s', current, ' ', ' ' \
           from %s:policy where ipolicy = '%s'",
        sIclaim, userid, userid, sFullName, sIpolicy);
        printf("ca573_ca_clm_process_G=[%s]\n",sTmpSQL1);
        $prepare ca573_ca_clm_victim_data_G from $sTmpSQL1;
        $execute ca573_ca_clm_victim_data_G;

        /* F0.�r�p */
        sprintf(sTmpSQL1,
        "insert into sysdb:ca_clm_victim_data \
            (iclaim, ivictim, dvictim, fvictim_nation, fvictim_sex, \
             fvictim_car, fdrive, facc_rel, itag, nassured, \
             itel, avictim, fdrink, iinjured_loc, fcause_adjuster, \
             qduty_adjuster, fcause_skip, qduty_skip, fcause_policy, fhealth, \
             fsubrogation, ientry, dentry, iupdate, dupdate, ncause_oth, irent_tag) \
         values \
            ('%s', '%s', '%s', '%s', '%s', \
             'F', '0', '%s', '%s', '%s', \
             ' ', ' ', 'N', '00', '01', \
             0, ' ',  0, '00', ' ', \
             'N', '%s', current, '%s', current,' ', ' ') ",
             sIclaim, sIacc_license, sDacc_birth, sFacc_nation, sFacc_sex,
             sFacc_rel, sItag, sNacc_driver, userid, userid);
        printf("ca573_ca_clm_process_F0=[%s]\n",sTmpSQL1);
        $prepare ca573_ca_clm_victim_data_F0 from $sTmpSQL1;
        $execute ca573_ca_clm_victim_data_F0;
     }

    /* �g�J ca_property */
    sprintf(sTmpSQL1,
        "insert into sysdb:ca_property \
            (iverify, ipro_no, ivictim, itype, npro, \
            itag, icar_type, diissue, mtotal_loss, fdirection, \
            fdamaged_loc, fcar_status, qpt, fpt, ioth_card_company, \
            ioth_icard, \
            iengine, ientry, dentry, iupdate, dupdate) \
        select '%s', 1 , a.iassured, '1', ' ', \
            a.itag, b.icar_type, a.dissue , 0 , '00', \
            '15', '01', a.qpt, a.fpt, '17', \
            nvl((select itarget2 from policy_new where ipolicy1 = b.irelative_ply and ipolicy2 = ' ' ), ' '), \
            a.iengine, '%s', current, '%s', current \
        from %s:policy a, %s:ply_relation b \
        where a.ipolicy = b.ipolicy  and a.ipolicy = '%s' ",
        sIclaim, userid, userid, sFullName, sFullName, sIpolicy);

    printf("ca573_ca_property=[%s]\n",sTmpSQL1);
    $prepare ca573_ca_property from $sTmpSQL1;
    $execute ca573_ca_property;

     /* ��s ca_clm_process */
     $update sysdb:ca_clm_process
         set dverify = today,
             fclaim_status = '401',
             fprocess = '351',
             dprocess1 = today
       where iclaim = $sIclaim;

    return SUCCESS;


errexit:
    printf("------> errexit: car573_insert: 0800�s�� [%s] \n", sInumber_0800);
    strcpy(errMsg1, errMsg);
    sprintf(errMsg,"car573_insert: \n  0800�s��: [%s], errMsg: [%s] SQLCODE=[%d] \n", sInumber_0800, errMsg1,SQLCODE);
    rc = cm_show_sql_err("car573_insert", "");
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    $SET LOCK MODE TO NOT WAIT;
    return rc;
}
/* ---------------------------------------------------------------------- */
long car574_insert()
{
    $int iserial;

    EXEC SQL WHENEVER SQLERROR GOTO errexit;

    strcpy(sFullName, get_car_full_db(sIpolicy));

    iserial = 0;

    /* �s�W ca_pro_ins */
    if (iMins_38 > 0)
    {
        iserial++;

        $insert into sysdb:ca_pro_ins
            (iclaim, iserial, iverify, ipro_no, iins_type,
             mamount, ientry, dentry, iupdate, dupdate, prate)
         values
            ($sIclaim, $iserial, $sIclaim, 1, '38',
             $iMins_38, $userid, current, $userid, current, 100);
    }

    if (iMins_39 > 0)
    {
        iserial++;

        $insert into sysdb:ca_pro_ins
            (iclaim, iserial, iverify, ipro_no, iins_type,
             mamount, ientry, dentry, iupdate, dupdate, prate)
         values
            ($sIclaim, $iserial, $sIclaim, 1, '39',
             $iMins_39, $userid, current, $userid, current, 100);
    }

    if (iMins_238 > 0)
    {
        iserial++;

        $insert into sysdb:ca_pro_ins
            (iclaim, iserial, iverify, ipro_no, iins_type,
             mamount, ientry, dentry, iupdate, dupdate, prate)
         values
            ($sIclaim, $iserial, $sIclaim, 1, '238',
             $iMins_238, $userid, current, $userid, current, 100);
    }

    /* �� ca_clm_process: �O�_����ñ�p��������� */
    $update sysdb:ca_clm_process
        set isign_est = '3'
      where iclaim = $sIclaim;


    return SUCCESS;

errexit:
    printf("------> errexit: car574_insert: 0800�s�� [%s] \n", sInumber_0800);
    strcpy(errMsg1, errMsg);
    sprintf(errMsg,"car574_insert: \n  0800�s��: [%s], errMsg: [%s] SQLCODE=[%d] \n", sInumber_0800, errMsg1,SQLCODE);
    rc = cm_show_sql_err("car574_insert", "");
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    $SET LOCK MODE TO NOT WAIT;
    return rc;
}
/* ---------------------------------------------------------------------- */
long car581_insert()
{
    $char isign[21], icard[21];
    $int iMappLoss;

    EXEC SQL WHENEVER SQLERROR GOTO errexit;

    strcpy(sFullName, get_car_full_db(sIpolicy));

    iMappLoss = iMins_38 + iMins_39 + iMins_238;

    /* ñ���渹 */
    $select nvl(left(max(isign),7)||lpad(cast(right(max(isign),4) +1 as int),4,0),'XXX')
       into $isign
       FROM ca_sign_receipt
      where isign[1,7] = $isign_tmp;

    if (strncmp(isign,"XXX",3) == 0)
        sprintf(isign,"%s0001",trim(isign_tmp));

    printf("1371: isign=[%s] isign_tmp=[%s]\n",isign, isign_tmp);

    /* �O�׼t��� */
    $select iemail, itel, imobile, ifax, izip, afactory
       into $iemail, $itel, $imobile, $tfax, $izipcode_con, $aperm_con
       from ca_factory
      where ifactory = $sIpayment;

    /* �s�Wca_sign_receipt */
    $insert into ca_sign_receipt
        (iclaim, ifpce_id, ifpce_id_ext, qserial, mpayment,
         invoice, dreceive, dpaperwork, dentry, isign,
         isign_type, pay_kind, fspeed, xfpay_cond, mprocess,
         iclose_type, icur, ientry, iupdate, dupdate,
         ideliver, icntry, iemail, itel, imobile,
         tfax, izipcode_con, aperm_con, izip, aperm,
         ffactory_type, fmodel_type)
     values
        ($sIclaim, $sIpayment, ' ', 1, $iMappLoss,
         $sInvoice, $sDreceiver, current, current, $isign,
         '1', '1', '1', '3', 0,
         0, ' ', $userid, $userid, current,
         ' ', '9', $iemail, $itel, $imobile,
         $tfax, $izipcode_con, $aperm_con, ' ', ' ',
         '11','00');

    /* ��s ca_pro_ins */
    $update ca_pro_ins
       set isign = $isign
     where iclaim = $sIclaim;


    return SUCCESS;


errexit:
    printf("------> errexit: car581_insert: 0800�s�� [%s] \n", sInumber_0800);
    strcpy(errMsg1, errMsg);
    sprintf(errMsg,"car581_insert: \n  0800�s��: [%s], errMsg: [%s] SQLCODE=[%d] \n", sInumber_0800, errMsg1,SQLCODE);
    rc = cm_show_sql_err("car581_insert", "");
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    $SET LOCK MODE TO NOT WAIT;
    return rc;
}
/* -------------------------------------------------------------------------- */
long car582_insert()
{
    $char isign[21], icard[21], sNote[100], iclm_upcomp[3];
    $int iMappLoss;

    EXEC SQL WHENEVER SQLERROR GOTO errexit;

    strcpy(sFullName, get_car_full_db(sIpolicy));

    iMappLoss = iMins_38 + iMins_39 + iMins_238;

    /* ���d�� */
    sprintf(sTmpSQL1,
        " select icard from %s:ply_relation where ipolicy = ? ",sFullName);
    printf("sTmpSQL1[%s]\n",sTmpSQL1);
    $prepare get_icard from $sTmpSQL1;
    $execute get_icard into $icard using $sIpolicy;

    /* �z�߳Ƶ� */
    strcpy(sIdatano, trim(sIdatano));
    printf("sIdatano=[%s]\n",sIdatano);
    sprintf(sNote,"��Q�I�妸����, ���ɧ帹: %s",sIdatano);
    strcpy(sNote, trim(sNote));

    /* �s�W settlement */
    sprintf(sTmpSQL1,
        "insert into %s:settlement \
            (iclaim, fstl, iclose_type, fcard_class, ipolicy, \
             icard, mdmg_stl, msettle, ientry, dentry, \
             iadjuster, frecover, fsale, istl_recover, ihealth, \
             istl_flag, iself_duty, ioth_duty, ianoth_duty, vouch_state, \
             iupdate, dupdate, nnote_claim, freject, ipayno, \
             ichk_recovery, ireason_norecovery) \
         values \
            ('%s', '1', '1', '2', '%s', \
             '%s', %d, %d, 'car540', current, \
             '%s', '0', '0', ' ', ' ', \
             '1', 0, 0, 100, 110, \
             'car540', current, '%s', 'N', '%s', '0', ' ')",
        sFullName, sIclaim, sIpolicy, icard, iMappLoss, iMappLoss,
        sAdjustment, sNote, sIdatano);

    printf("ca582_settlement=[%s]\n",sTmpSQL1);
    $prepare ca582_settlement from $sTmpSQL1;
    $execute ca582_settlement;
    printf("---------------- 1462 --------------\n");
    /* �s�W stl_ins_type */
    if (iMins_38>0)
    {
        printf("---------------- 1466 --------------\n");
        sprintf(sTmpSQL1,
        "insert into %s:stl_ins_type  \
            (iclaim, fstl, iclose_type, iins_type, mins_stl, flast) \
         values \
            ('%s', '1', '1', '38', %d, '1')",
         sFullName, sIclaim, iMins_38);

        printf("ca582_stl_ins_type38=[%s]\n",sTmpSQL1);
        $prepare ca582_stl_ins_type38 from $sTmpSQL1;
        $execute ca582_stl_ins_type38;
        printf("---------------- 1477 --------------\n");
    }

    if (iMins_39>0)
    {
        printf("---------------- 1482 --------------\n");
        sprintf(sTmpSQL1,
        "insert into %s:stl_ins_type \
            (iclaim, fstl, iclose_type, iins_type, mins_stl, flast) \
         values \
            ('%s', '1', '1', '39', %d, '1')",
         sFullName, sIclaim, iMins_39);

        printf("ca582_stl_ins_type39=[%s]\n",sTmpSQL1);
        $prepare ca582_stl_ins_type39 from $sTmpSQL1;
        $execute ca582_stl_ins_type39;
        printf("---------------- 1493 --------------\n");
    }

    if (iMins_238>0)
    {
        printf("---------------- 1482 --------------\n");
        sprintf(sTmpSQL1,
        "insert into %s:stl_ins_type \
            (iclaim, fstl, iclose_type, iins_type, mins_stl, flast) \
         values \
            ('%s', '1', '1', '238', %d, '1')",
         sFullName, sIclaim, iMins_238);

        printf("ca582_stl_ins_type238=[%s]\n",sTmpSQL1);
        $prepare ca582_stl_ins_type238 from $sTmpSQL1;
        $execute ca582_stl_ins_type238;
        printf("---------------- 1493 --------------\n");
    }

printf("---------------- 1495 --------------\n");
    $select iupcomp
       into $iclm_upcomp
       from branch
      where ibranch = (select iapp_unit from cm_clm_adjuster where empl_no = $sAdjustment);
    if (SQLCODE == SQLNOTFOUND)
    {
        sprintf(errMsg," branch �L�k���z�ߤW�h�����q�N���A�z�߭����s[%s] ", sAdjustment);
        goto errexit;
    }

    printf("iclm_upcomp=[%s]\n",iclm_upcomp);

    /* �s�W�ߥI��H�� payment */
    sprintf(sTmpSQL1,
        "insert into %s:payment \
            (iclaim, fstl, iclose_type, ipayment, ifpce_id_ext, \
             qserial, irepair_shop, fassured, nchi_full, npayment, \
             xsettle_type, ipay_area, xibank, xiaccount, aperm_con, mpayment, \
             fspeed, dreceiver, dpaperwork, pay_kind, iemail, \
             imobile, tfax, izipcode_con, xfpay_cond ) \
         select '%s', '1', '1', ifpce_id, ' ', \
                '1', ' ', fassured, nfactory, npayment, \
                fsettle_type, '%s', ibank, iaccount, afactory, %d, \
                '1', '%s', today, '1',  iemail, \
                imobile, ifax, izip, '3' \
           from ca_factory \
          where ifactory = '%s'  and ifactory_ext = ' ' ",
         sFullName, sIclaim, iclm_upcomp, iMappLoss, sDreceiver, sIpayment);

    printf("ca582_payment=[%s]\n",sTmpSQL1);
    $prepare ca582_payment from $sTmpSQL1;
    $execute ca582_payment;

    /* �s�Wca_local_stl (�t�X�x�_���b,�u�g��x�_) */
    sprintf(sTmpSQL1,
        " insert into newa00:ca_local_stl                              \
             (dentry, ipolicy, icard, iclaim, fstl, iclose_type,   \
              ientry, ibranch, fchoose,userid)                            \
           values \                                        \
             (today, ?, ?, ?, '1', '1', ?, ?, '1',?) ");
        printf("ca582_ca_local_stl[%s]\n",sTmpSQL1);
        $prepare ca582_ca_local_stl from $sTmpSQL1;
        $execute ca582_ca_local_stl
           using $sIpolicy, $icard, $sIclaim, $userid, $iclm_upcomp,$userid;

    /* ��sappraisal */
    sprintf(sTmpSQL1,
        "update %s:appraisal \
            set msettle = %d, \
                ifacnum = '%s' \
          where iclaim = '%s' ",
         sFullName, iMappLoss, sIpayment, sIclaim);

    printf("ca582_appraisal=[%s]\n",sTmpSQL1);
    $prepare ca582_appraisal from $sTmpSQL1;
    $execute ca582_appraisal;


    /* �g�J�O���� */
    $insert into sysdb:ca_tow_away
        (inumber_0800, ipolicy,   itag,        nassured,     daccident,
         dreceiver,    invoice,   mamount,     ply_ins_type, mins_38,
         mins_39,      mins_238,  iacc_area,   facc_nation,  nacc_driver,
         iacc_license, iacc_birth,   facc_sex,  facc_marri,  facc_rel,
         adjustment,   idatano,    itransno,    icreate,     dcreate,
         iclaim,       dclose,     iqserial,    iupdate,     dupdate)
     values
        ($sInumber_0800, $sIpolicy, $sItag, $sNassured, $sDaccident,
         $sDreceiver, $sInvoice,  $iMamount,  $sPly_ins_type, $iMins_38,
         $iMins_39,   $iMins_238, $sIacc_area, $sFacc_nation, $sNacc_driver,
         $sIacc_license, $sDacc_birth, $sFacc_sex, $sFacc_marri, $sFacc_rel,
         $sAdjustment, $sIdatano, $sItransno, $userid, current,
         $sIclaim,   '', ' ', ' ', '');

    return SUCCESS;

errexit:
    printf("------> errexit: car582_insert: 0800�s�� [%s] \n", sInumber_0800);
    strcpy(errMsg1, errMsg);
    sprintf(errMsg,"car582_insert: \n  0800�s��: [%s], errMsg: [%s] SQLCODE=[%d] \n", sInumber_0800, errMsg1,SQLCODE);
    rc = cm_show_sql_err("car582_insert", "");
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    $SET LOCK MODE TO NOT WAIT;
    return rc;
}

/* ------------------------------------------------------------------------------ */
long car540_report()
{

    $char   fname1[100], filename1[150], ftitle[500];
    $char   sdate1[9];
    $char   sIclaim1[22], sInumber[22], sItag1[14], sIpolicy1[22], sDreceiver1[12],
            sInvoice1[22], sIdatano[22];
    $int    imins38, imins39, imins238, itotal;
    int     rtncode;

    $WHENEVER SQLERROR GOTO errexit;

    printf("---------car540_report     (1)----------- \n ");

    $select first 1 to_char(today,'%Y%m%d') into $sdate1
       from cu_code_data;

    printf("---------car540_report     (2)----------- \n ");
    memset(fname1,0x00,sizeof(fname1));
	  memset(filename1,0x00,sizeof(filename1));

    sprintf(fname1,"��Q�I���ɩ���_%s.csv",sdate1);
    sprintf(filename1,"%s/rptftp/%s",sApHome,fname1);


    strcpy(ftitle,"�߮׸�, 0800MEMO, �P�Ӹ��X, 38�I�ت��B, 39�I�ت��B, 238�I�ت��B, \
                   ��Q�I���B, �O�渹, �o�����, �o���X, ���ɧ帹\n");


    /* �`�N:�U�CSQL����''�OASCII��127�X,�b�S�w�r���~�ݱo��,�������@�Ӧr��,
       ���i�H�b��Excel�ɮɥi�H��ܧ��㪺�Ʀr, ���|�y�������D,���V��..
       add by sylvia 107.12.17 */
    printf("---------car540_report     (3)----------- \n ");
    sprintf(sTmpSQL1,
        "select iclaim, chr(127)||inumber_0800, chr(127)||itag, \
                mins_38, mins_39, mins_238, mamount, \
                ipolicy, dreceiver, invoice, idatano \
           from car540_temp where 1=1;");

	fp=fopen(filename1,"w");
	fprintf(fp,ftitle);
	$PREPARE pre_rpt1 FROM $sTmpSQL1;
  $DECLARE cur_rpt1 CURSOR FOR pre_rpt1 ;
	$open cur_rpt1 ;
  icount = 0;
  while(1)
	{
	    $fetch cur_rpt1
        into $sIclaim1, $sInumber, $sItag1, $imins38, $imins39, $imins238,
             $itotal,   $sIpolicy1, $sDreceiver1, $sInvoice1, $sIdatano;
        if (SQLCODE==SQLNOTFOUND) break;

        printf("---------car540_report     (4)----------- \n ");
        fprintf(fp,"%s,%s,%s,%d,%d,%d,%d,%s,%s,%s,%s\n",
		           sIclaim1, sInumber, sItag1, imins38, imins39, imins238,
		           itotal, sIpolicy1, sDreceiver1, sInvoice1, sIdatano);

        icount++;
    }
    printf("---------car540_report     (5)----------- \n ");
    $close cur_rpt1;
    $free cur_rpt1;
	fclose(fp);

	rtncode = rptftpinsert( userid , "car540" , fname1 );

	printf("---------car540_report     (6)----------- \n ");
    return M_CM_OK;


errexit:
    rc = cm_show_sql_err("car540_report", "");
    $WHENEVER SQLERROR CONTINUE;
    return rc;
}
/* -------------------------------------------------------------------------- */

char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  char sTmp_db_name[31];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
  }
  return sTmp_db_name;
}

/* -------------------------------------------------------------------------- */
