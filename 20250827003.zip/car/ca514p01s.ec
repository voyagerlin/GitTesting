/************************************************/
/*                                              */
/*   PROGRAM : ca514p01s.ec                     */
/*                                              */
/*   REVISER : Johnny 7/16/1997                 */
/*   Modify  : Jessie 6/29/2006 �W�[�������pD   */
/************************************************/
     
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "carmsgs.h"
#include "carmsg.h"
#include "safeclib.h"
$include sqlca;

#define BLANK_14 "              "
#define BLANK_9 "         "

 /* standard defined host variables */
 $char DBName[5], tpfullname[31];
 $char stmt[512],fulldb1[41],fulldb2[41],fulldb3[41];

 /* table policy */
 $char ipolicy1[POLICY_NUM_1],icard1[CARD_NUM],itag1[CA_TAG_NUM],nassured1[121];
 $long dply_begin1,dply_end1;
 $char ipolicy2[POLICY_NUM_1],icard2[CARD_NUM],itag2[CA_TAG_NUM],nassured2[121];
 $long dply_begin2,dply_end2;
 $char fcomp_24[2],fcomp_242[2];

 /* table ply_relation */
 $char irply1[POLICY_NUM_1],inext_ply1[POLICY_NUM_1];
 $char irply2[POLICY_NUM_1],inext_ply2[POLICY_NUM_1];
 $char ucode[POLICY_NUM_1];
 $char irelative_ply[POLICY_NUM_1];
 $char ipolicy_1[2];
 $char ipolicy_2[2];
 $char c_code[POLICY_NUM_1];
 $int irelative_ply_isnull = 0;
 $char V_icode[2];
 $char V_ircode[2];
 $char icard[21],ixxcard[21];
 $char i_icard[25];
 $char fcomp_ipolicy[POLICY_NUM_1];
 $char irelative_ply_1[POLICY_NUM_1],irelative_ply_2[POLICY_NUM_1];
 /* table appraisal */
 $char dacc1[20],fcar1[2];
 $char dacc2[20],fcar2[2];
 $char option[2];
 /* standard defined data */
 int  tmp_len;
 long MsgCode;

 /* self defined data */
  char type,inp,s_begin[11],s_end[11];
 $char icode[20+1],ircode[20+1];
 $char stmt_buf[200];


long car514(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car514_query1(),car514_update();
 long car514_update_U(),car514_update_C();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case '1':
  case '2':
           rtncode=car514_query1(reply);
           break;
  case 'P':
           rtncode=car514_update(reply);
           break;
  case 'U':
           rtncode=car514_update_U(reply);
           break;
  case 'C':
            rtncode=car514_update_C(reply);
            break;
  case 'D':
            rtncode=car514_update_D(reply);
            break;

  default :
          return exitsub(reply,M_CM_WRONG_OPTION) ?M_CM_WRONG_OPTION :apiRC;
 }
 return(rtncode);
}

/***********************************************************************/
long car514_query1(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];

 /* table policy */
 $char ipolicy[POLICY_NUM_1],icard[CARD_NUM],itag[CA_TAG_NUM],nassured[121];
 $long dply_begin = 0;
 $long dply_end = 0;

 /* standard defined data */
 int tmp_len;
 long MsgCode;

 /* self defined data */
 char type,inp,s_begin[11],s_end[11];
 $char icode[20+1],tmp_code[20+1];

 cm_buf_get("%s",DBName);
 cm_buf_get("%c %c %s",&type,&inp,icode);

 if (db_select(DBName) == False) 
  { return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC; }

 printf("type=[%c],inp=[%c],icode[%s]\n",type,inp,icode);
 if (type == '2') {
     $DECLARE x1 CURSOR FOR
       select ipolicy into $tmp_code
         from appraisal
        where iclaim = $icode;
     $OPEN x1;
     $FETCH x1;
     if (SQLCODE == SQLNOTFOUND) 
        return exitsub(reply,M_CA_NAPPRAISAL) ? M_CA_NAPPRAISAL : apiRC;
 }
 else{
     strcpy(tmp_code,icode);
 }

 if (type=='1' && inp=='2') { 
   $select ipolicy into $tmp_code
      from assured_vs_ply
     where icard = $icode;
   if (SQLCODE == SQLNOTFOUND) 
      return exitsub(reply,M_CA_NOT_CARD) ? M_CA_NOT_CARD : apiRC; 
 }

 strcpy(fulldb1,get_car_full_db(tmp_code));
 sprintf_s(stmt,512,
 "SELECT a.ipolicy,a.icard,dply_begin,dply_end,a.itag,a.nassured,a.fcomp_24\
    FROM %s:policy a,%s:ply_relation b \
    WHERE a.ipolicy = b.ipolicy AND a.ipolicy = ? ",fulldb1,fulldb1);
 $prepare pre_ply from $stmt;
 $execute pre_ply
     into $ipolicy,$icard,$dply_begin,$dply_end,$itag,$nassured,
          $fcomp_24
    using $tmp_code;

 if (SQLCODE == SQLNOTFOUND) 
    return exitsub(reply,M_CA_NOT_CARD) ? M_CA_NOT_CARD : apiRC; 

 strcpy(s_begin,cm_cdate_str_100(dply_begin));
 strcpy(s_end,cm_cdate_str_100(dply_end));
 cm_buf_init(ReplyBuf);
 cm_buf_put("%l",M_CM_OK);
 cm_buf_put("%s %s %s %s %s %s %s",ipolicy,icard,s_begin,s_end,itag,nassured,
             fcomp_24);
 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
    return apiRC;
 else 
    return api_OKComplete;

 errexit:
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/***********************************************************************/
long car514_update(reply)
serverReply reply;
{
$char tmp_icode[21],tmp_ircode[21];

 cm_buf_get("%s",DBName);
 cm_buf_get("%c %c %s %s",&type,&inp,icode,ircode);

 if (db_select(DBName) == False)
     return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

 printf("option[%s]\n",option);
 printf("--P1--\n");

 if (type == '1') {
    printf("--P1.1--\n");
    $WHENEVER NOT FOUND GOTO errexit1;

    if (inp != '1') {
       $select ipolicy into $tmp_icode
          from assured_vs_ply
         where icard = $icode;

       $select ipolicy into $tmp_ircode
          from assured_vs_ply
         where icard = $ircode;
    }
    else {
       strcpy(tmp_icode,icode);
       strcpy(tmp_ircode,ircode);
    }

       printf("--P1.1.1a--\n");
       strcpy(fulldb1,get_car_full_db(tmp_icode));
       sprintf_s(stmt,512,
       "SELECT  a.ipolicy,a.icard,dply_begin,dply_end,a.itag,a.nassured, \
                b.irelative_ply,b.inext_ply \
          FROM %s:policy a,%s:ply_relation b \
         WHERE a.ipolicy=b.ipolicy AND a.ipolicy = ? ",fulldb1,fulldb1);
       $prepare pre_ply from $stmt;
       $execute pre_ply 
           into $ipolicy1,$icard1,$dply_begin1,$dply_end1,$itag1,$nassured1,
                $irply1,$inext_ply1
          using $tmp_icode;

       printf("--P1.1.1b--\n");
       strcpy(fulldb2,get_car_full_db(tmp_ircode));
       sprintf_s(stmt,512,
       "SELECT  a.ipolicy,a.icard,dply_begin,dply_end,a.itag,a.nassured, \
                b.irelative_ply,b.inext_ply \
          FROM %s:policy a,%s:ply_relation b \
         WHERE a.ipolicy=b.ipolicy AND a.ipolicy = ? ",fulldb2,fulldb2);
       $prepare pre_ply from $stmt;
       $execute pre_ply
           into $ipolicy2,$icard2,$dply_begin2,$dply_end2,$itag2,$nassured2,
                $irply2,$inext_ply2
          using $tmp_ircode;

    printf("--P1.1.3--\n");

    $WHENEVER NOT FOUND CONTINUE;
    $WHENEVER SQLERROR CONTINUE;

    if ((irply1[0] != '\0' && irply1[0]!=' ') || 
        (irply2[0] != '\0' && irply2[0]!=' ')) 
      { return exitsub(reply,M_CA_NOREL_ERR) ? M_CA_NOREL_ERR : apiRC; }

    if ((inext_ply1[0]!='\0' && inext_ply1[0]!=' ') ||
        (inext_ply2[0]!='\0' && inext_ply2[0]!=' ')) 
      { return exitsub(reply,M_CA_NEXTEXIST) ? M_CA_NEXTEXIST : apiRC; }

    if (strcmp(itag1,itag2) != 0) {
       if ((itag1[0]!='\0' && itag1[0]!=' ') &&
           (itag2[0]!='\0' && itag2[0]!=' ')) {
          return exitsub(reply,M_CA_COND_NOTMATCH)?M_CA_COND_NOTMATCH:apiRC;
       }else if (strcmp(nassured1,nassured2) != 0) {
          return exitsub(reply,M_CA_COND_NOTMATCH)?M_CA_COND_NOTMATCH:apiRC;
       }
    }

    printf("--P1.1.4--\n");
    $BEGIN WORK;
    $WHENEVER SQLERROR GOTO errexit;

    /*-----*/
    sprintf_s(stmt,512,
    "UPDATE %s:ply_relation SET (irelative_ply) = (?) \
      WHERE ipolicy = ? ",fulldb1);
    $prepare pre_upd from $stmt;
    $execute pre_upd
       using $ipolicy2,$ipolicy1;

    sprintf_s(stmt,512,
    "UPDATE %s:ply_relation SET (irelative_ply) = (?) \
      WHERE ipolicy = ? ",fulldb2);
    $prepare pre_upd from $stmt;
    $execute pre_upd
       using $ipolicy1,$ipolicy2;

    sprintf_s(stmt,512,
    "UPDATE %s:policy SET (ixxcard) = (' ') \
      WHERE ipolicy = ? ",fulldb1);
    $prepare pre_upd from $stmt;
    $execute pre_upd
       using $ipolicy1;

    sprintf_s(stmt,512,
    "UPDATE %s:policy SET (ixxcard) = (' ') \
      WHERE ipolicy = ? ",fulldb2);
    $prepare pre_upd from $stmt;
    $execute pre_upd
       using $ipolicy2;

    /*-----*/
    sprintf_s(stmt,512,
    "UPDATE %s:ori_ply_relation SET (irelative_ply) = (?) \
      WHERE ipolicy = ? ",fulldb1);
    $prepare pre_upd from $stmt;
    $execute pre_upd
       using $ipolicy2,$ipolicy1;

    sprintf_s(stmt,512,
    "UPDATE %s:ori_ply_relation SET (irelative_ply) = (?) \
      WHERE ipolicy = ? ",fulldb2);
    $prepare pre_upd from $stmt;
    $execute pre_upd
       using $ipolicy1,$ipolicy2;

    sprintf_s(stmt,512,
    "UPDATE %s:original_ply SET (ixxcard) = (' ') \
      WHERE ipolicy = ? ",fulldb1);
    $prepare pre_upd from $stmt;
    $execute pre_upd
       using $ipolicy1;

    sprintf_s(stmt,512,
    "UPDATE %s:original_ply SET (ixxcard) = (' ') \
      WHERE ipolicy = ? ",fulldb2);
    $prepare pre_upd from $stmt;
    $execute pre_upd
       using $ipolicy2;

    /*-----*/
    sprintf_s(stmt,512,
    "UPDATE %s:edr_relation SET (irelative_ply) = (?) \
      WHERE ipolicy = ? ",fulldb1);
    $prepare pre_upd from $stmt;
    $execute pre_upd
       using $ipolicy2,$ipolicy1;

    sprintf_s(stmt,512,
    "UPDATE %s:edr_relation SET (irelative_ply) = (?) \
      WHERE ipolicy = ? ",fulldb2);
    $prepare pre_upd from $stmt;
    $execute pre_upd
       using $ipolicy1,$ipolicy2;

    /*-----*/
    sprintf_s(stmt,512,
    "UPDATE %s:ply_relation_bak SET (irelative_ply) = (?) \
      WHERE ipolicy = ? ",fulldb1);
    $prepare pre_upd from $stmt;
    $execute pre_upd
       using $ipolicy2,$ipolicy1;

    sprintf_s(stmt,512,
    "UPDATE %s:ply_relation_bak SET (irelative_ply) = (?) \
      WHERE ipolicy = ? ",fulldb2);
    $prepare pre_upd from $stmt;
    $execute pre_upd
       using $ipolicy1,$ipolicy2;

    sprintf_s(stmt,512,
    "UPDATE %s:policy_bak SET (ixxcard) = (' ') \
      WHERE ipolicy = ? ",fulldb1);
    $prepare pre_upd from $stmt;
    $execute pre_upd
       using $ipolicy1;

    sprintf_s(stmt,512,
    "UPDATE %s:policy_bak SET (ixxcard) = (' ') \
      WHERE ipolicy = ? ",fulldb2);
    $prepare pre_upd from $stmt;
    $execute pre_upd
       using $ipolicy2;

    /*-----*/
    sprintf_s(stmt,512,
    "UPDATE %s:appraisal SET (irelative_ply) = (?) \
      WHERE ipolicy = ? ",fulldb1);
    $prepare pre_upd from $stmt;
    $execute pre_upd
       using $ipolicy2,$ipolicy1;

    sprintf_s(stmt,512,
    "UPDATE %s:appraisal SET (irelative_ply) = (?) \
      WHERE ipolicy = ? ",fulldb2);
    $prepare pre_upd from $stmt;
    $execute pre_upd
       using $ipolicy1,$ipolicy2;

    printf("--P1.1.5--\n");

    /*-----*/
    strcpy(tpfullname, get_full_dbname("00"));
    sprintf_s(stmt_buf,200,"UPDATE %s:abnormal_ply %s %s",
                     tpfullname, 
                     "SET (irelative_ply,ixxcard)=(?,' ')",
                     "WHERE iabnormal=?");
    printf("--P1.1.6-- stmt[%s]\n",stmt_buf);
    $PREPARE u_id1 FROM $stmt_buf;
    $EXECUTE u_id1 USING $ipolicy1,$ipolicy2;
    $EXECUTE u_id1 USING $ipolicy2,$ipolicy1;

    sprintf_s(stmt_buf,200,"UPDATE %s:abn_edr_relation %s %s",
                     tpfullname,
                     "SET irelative_ply = ?",
                     "WHERE ipolicy = ?");
    printf("--P1.1.7-- stmt[%s]\n",stmt_buf);
    $PREPARE u_id3 FROM $stmt_buf;
    $EXECUTE u_id3 USING $ipolicy2,$ipolicy1;
    $EXECUTE u_id3 USING $ipolicy1,$ipolicy2;


    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    tmp_len = cm_buf_len(ReplyBuf);
    if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
      $WHENEVER SQLERROR CONTINUE;
      $ROLLBACK WORK;
      return apiRC;
    }  

    $WHENEVER SQLERROR GOTO errexit;
    $COMMIT WORK;
    return api_OKComplete;
 } /* type == '2' */ 
 else 
 {
  printf("--P1.2--\n");
  $WHENEVER NOT FOUND GOTO errexit2; 
  /*$SELECT ipolicy,irelative_ply,daccident,fcar_class*/ 
  $SELECT ipolicy,irelative_ply,daccident
     INTO $ipolicy1,$irply1,$dacc1
     FROM appraisal
    WHERE iclaim=$icode;
  $SELECT ipolicy,irelative_ply,daccident
     INTO $ipolicy2,$irply2,$dacc2
     FROM appraisal
    WHERE iclaim=$ircode;

  $WHENEVER NOT FOUND CONTINUE;
  $WHENEVER SQLERROR CONTINUE;

  if ((irply1[0]=='\0'||irply1[0]==' ')||(irply2[0]=='\0'||irply2[0]==' ')||
      (strcmp(irply1,ipolicy2)!=0 || strcmp(irply2,ipolicy1)!=0)) 
  {  return exitsub(reply,M_CA_NORELPLY) ? M_CA_NORELPLY : apiRC; }

  dacc1[10] = dacc2[10] = '\0';
  if (strcmp(dacc1,dacc2) != 0)
     return exitsub(reply,M_CA_NOMATCH) ? M_CA_NOMATCH : apiRC;

 
  printf("--P1.2.1--\n");
  $BEGIN WORK;

  $UPDATE appraisal SET (irelative_clm) = ($ircode)
    WHERE iclaim = $icode;  

  $UPDATE appraisal SET (irelative_clm) = ($icode)
    WHERE iclaim = $ircode;  

 } /*type=1*/

  printf("--Pend--\n");
  cm_buf_init(ReplyBuf);
  cm_buf_put("%l",M_CM_OK);
  tmp_len = cm_buf_len(ReplyBuf);
  if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
   {
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    return apiRC;
   }  

  $WHENEVER SQLERROR GOTO errexit;
  $COMMIT WORK;
  return api_OKComplete;
  errexit1:
    $WHENEVER SQLERROR CONTINUE;
    return exitsub(reply,M_CA_NPOLICY) ? M_CA_NPOLICY : apiRC;

  errexit2:
    $WHENEVER SQLERROR CONTINUE;
    return exitsub(reply,M_CA_NAPPRAISAL) ? M_CA_NAPPRAISAL : apiRC;

  errexit:
    MsgCode = SQLCODE;
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);

    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if (SQLCODE != 0) MsgCode = SQLCODE;
    return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}


/*    �󥿫O�����p     */
long car514_update_U(reply)
serverReply reply;
{


      cm_buf_get("%s",DBName);
      cm_buf_get("%c %c %s %s %s",&type,&inp,icode,ircode,ucode);

      if (db_select(DBName) == False)
         return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

      printf("--P1--\n");


      printf("icode[%s]\n",icode);
      printf("ircode[%s]\n",ircode);
      printf("ucode[%s]\n",ucode);
      strcpy(icode,trim(icode));
      strcpy(ircode,trim(ircode));
      strcpy(ucode,trim(ucode));


     $WHENEVER SQLERROR GOTO errexit;

    /*  �n�Q���������p�渹�����O�j� ���P�_���@�ӫO�渹���j��O��  */

    strcpy(ipolicy_1,substring(icode,6,1));
    printf("ipolicy_1[%s]\n",ipolicy_1);
    if(strcmp(ipolicy_1,"V")!=0)
    {

     printf("�j��O�欰icode\n");

     /*   ���������p�� check ���������p    */

     strcpy(fulldb1,get_car_full_db(ucode));
     sprintf_s(stmt,512,
            "select irelative_ply \
               from %s:ply_relation \
              where ipolicy = ? ",fulldb1);
     $prepare pre_rel from $stmt;
     $execute pre_rel
         into $irelative_ply_1
        using $ucode;

     strcpy(fulldb2,get_car_full_db(ircode));
     sprintf_s(stmt,512,
            "select irelative_ply \
               from %s:ply_relation \
              where ipolicy = ? ",fulldb2);
     $prepare pre_rel from $stmt;
     $execute pre_rel
         into $irelative_ply_2
        using $ircode;

     strcpy(irelative_ply_1,trim(irelative_ply_1));
     strcpy(irelative_ply_2,trim(irelative_ply_2));

     /*  �S�����p�hRETURN MSG  */
     if((strcmp(ucode,irelative_ply_2)!=0) && (strcmp(ircode,irelative_ply_1)!=0))
     {    return exitsub(reply,M_CA_NO_REL) ? M_CA_NO_REL : apiRC;   }



     /*  ���N���O�j��s������  */
     /*  �j��s���O��ܩ�e��,�ѨϥΪ̦ۦ�M�w 2006.09.22
     $select ipolicy
        into $fcomp_ipolicy
        from policy
       where ipolicy = $ircode
         and fcomp_24='Y';


     if(SQLCODE!=SQLNOTFOUND)
     {    return exitsub(reply,M_CA_FCOMP) ? M_CA_FCOMP : apiRC;   }
     */


        /*  ��check ����蠟�j��O��S�����p�渹  */
        strcpy(fulldb3,get_car_full_db(icode));
        sprintf_s(stmt,512,
               "select irelative_ply \
                  from %s:ply_relation \
                 where ipolicy = ? ",fulldb3);
        $prepare pre_rel from $stmt;
        $execute pre_rel
            into $irelative_ply:irelative_ply_isnull
           using $icode;

        printf("irelative_ply[%s]\n",irelative_ply);

        if(irelative_ply_isnull==-1)
           {   strcpy(irelative_ply," ");    }

        if(irelative_ply[0]!=' ')
           { return exitsub(reply,M_CA_UCODE) ? M_CA_UCODE : apiRC;   }

             printf("  icode ���j��  \n");

             $BEGIN WORK;

              /*   ucode ���j��O�� �N�P���N�����p���� */
              sprintf_s(stmt,512,
                     "UPDATE %s:ply_relation SET (irelative_ply) = (' ') \
                       WHERE ipolicy = ? ",fulldb1);
              $prepare pre_upd from $stmt;
              $execute pre_upd using $ucode;

              sprintf_s(stmt,512,
                     "UPDATE %s:ori_ply_relation SET (irelative_ply) = (' ') \
                       WHERE ipolicy = ? ",fulldb1);
              $prepare pre_upd from $stmt;
              $execute pre_upd using $ucode;

              sprintf_s(stmt,512,
                     "UPDATE %s:appraisal SET (irelative_ply) = (' ') \
                       WHERE ipolicy = ? ",fulldb1);
              $prepare pre_upd from $stmt;
              $execute pre_upd using $ucode;

              sprintf_s(stmt,512,
                     "UPDATE %s:ply_relation_bak SET (irelative_ply) = (' ') \
                       WHERE ipolicy = ? ",fulldb1);
              $prepare pre_upd from $stmt;
              $execute pre_upd using $ucode;

              sprintf_s(stmt,512,
                     "UPDATE %s:edr_relation SET (irelative_ply) = (' ') \
                       WHERE ipolicy = ? ",fulldb1);
              $prepare pre_upd from $stmt;
              $execute pre_upd using $ucode;

             /*  �N���N�����p�渹update�ӱ���蠟�j��O��  */

              sprintf_s(stmt,512,
                     "UPDATE %s:ply_relation SET (irelative_ply) = (?) \
                       WHERE ipolicy = ? ",fulldb2);
              $prepare pre_upd from $stmt;
              $execute pre_upd using $icode,$ircode;

              sprintf_s(stmt,512,
                     "UPDATE %s:ori_ply_relation SET (irelative_ply) = (?) \
                       WHERE ipolicy = ? ",fulldb2);
              $prepare pre_upd from $stmt;
              $execute pre_upd using $icode,$ircode;

              sprintf_s(stmt,512,
                     "UPDATE %s:appraisal SET (irelative_ply) = (?) \
                       WHERE ipolicy = ? ",fulldb2);
              $prepare pre_upd from $stmt;
              $execute pre_upd using $icode,$ircode;



              sprintf_s(stmt,512,
                     "UPDATE %s:ply_relation_bak SET (irelative_ply) = ?) \
                       WHERE ipolicy = ? ",fulldb2);
              $prepare pre_upd from $stmt;
              $execute pre_upd using $icode,$ircode;


              sprintf_s(stmt,512,
                     "UPDATE %s:edr_relation SET (irelative_ply) = ?) \
                        WHERE ipolicy = ? ",fulldb2);
              $prepare pre_upd from $stmt;
              $execute pre_upd using $icode,$ircode;


              /*  �N����蠟�j�����p����N�渹   */
              sprintf_s(stmt,512,
                     "UPDATE %s:ply_relation SET (irelative_ply) = (?) \
                       WHERE ipolicy = ? ",fulldb3);
              $prepare pre_upd from $stmt;
              $execute pre_upd using $ircode,$icode;

              sprintf_s(stmt,512,
                     "UPDATE %s:ori_ply_relation SET (irelative_ply) = (?) \
                       WHERE ipolicy = ? ",fulldb3);
              $prepare pre_upd from $stmt;
              $execute pre_upd using $ircode,$icode;

              sprintf_s(stmt,512,
                     "UPDATE %s:appraisal SET (irelative_ply) = (?) \
                        WHERE ipolicy = ? ",fulldb3);
              $prepare pre_upd from $stmt;
              $execute pre_upd using $ircode,$icode;

              sprintf_s(stmt,512,
                     "UPDATE %s:ply_relation_bak SET (irelative_ply) = (?) \
                       WHERE ipolicy = ? ",fulldb3);
              $prepare pre_upd from $stmt;
              $execute pre_upd using $ircode,$icode;

              sprintf_s(stmt,512,
                     "UPDATE %s:edr_relation SET (irelative_ply) = (?) \
                         WHERE ipolicy = ? ",fulldb3);
              $prepare pre_upd from $stmt;
              $execute pre_upd using $ircode,$icode;
    }

    strcpy(ipolicy_2,substring(ircode,6,1));
    printf("ipolicy_2[%s]\n",ipolicy_2);

    if (strcmp(ipolicy_2,"V")!=0)
    {

        printf("�j��O�欰ircode\n");

        /*   ���������p�� check ���������p    */
        strcpy(fulldb1,get_car_full_db(ucode));
        sprintf_s(stmt,512,
               "select irelative_ply \
                  from %s:ply_relation \
                 where ipolicy = ? ",fulldb1);
        $prepare pre_rel from $stmt;
        $execute pre_rel
            into $irelative_ply_1
           using $ucode;

        strcpy(fulldb2,get_car_full_db(icode));
        sprintf_s(stmt,512,
               "select irelative_ply \
                  from %s:ply_relation \
                 where ipolicy = ? ",fulldb2);
        $prepare pre_rel from $stmt;
        $execute pre_rel
            into $irelative_ply_2
           using $icode;

        strcpy(irelative_ply_1,trim(irelative_ply_1));
        strcpy(irelative_ply_2,trim(irelative_ply_2));


        /*  �S�����p�hRETURN MSG  */
        if((strcmp(icode,irelative_ply_1)!=0) && (strcmp(ucode,irelative_ply_2)!=0))
        {    return exitsub(reply,M_CA_NO_REL) ? M_CA_NO_REL : apiRC;   }


        /*  ���N�O�榳�O�j��s�L�k��  */
        /*  �j��s���O��ܩ�e��,�ѨϥΪ̦ۦ�M�w 2006.09.22
        $select ipolicy
          into $fcomp_ipolicy
          from policy
         where ipolicy = $icode
           and fcomp_24='Y';

        if(SQLCODE!=SQLNOTFOUND)
        {    return exitsub(reply,M_CA_FCOMP) ? M_CA_FCOMP : apiRC;   }
        */

        /*  ��check ����蠟�j��O��S�����p�渹  */
        strcpy(fulldb3,get_car_full_db(ircode));
        sprintf_s(stmt,512,
               "select irelative_ply \
                  from %s:ply_relation \
                 where ipolicy = ? ",fulldb3);
        $prepare pre_rel from $stmt;
        $execute pre_rel
            into $irelative_ply:irelative_ply_isnull
           using $ircode;

        printf("irelative_ply[%s]\n",irelative_ply);

        if(irelative_ply_isnull==-1)
        {   strcpy(irelative_ply," ");    }

        if(irelative_ply[0]!=' ')
        { return exitsub(reply,M_CA_UCODE) ? M_CA_UCODE : apiRC;   }

        printf("  ucode[%s]\n",ucode);

        $begin work;

        /*   ircode ���j��O�� �N�P���N�����p���� */
        sprintf_s(stmt,512,
               "UPDATE %s:ply_relation SET (irelative_ply) = (' ') \
                 WHERE ipolicy = ? ",fulldb1);
        $prepare pre_upd from $stmt;
        $execute pre_upd using $ucode;

        sprintf_s(stmt,512,
               "UPDATE %s:ori_ply_relation SET (irelative_ply) = (' ') \
                 WHERE ipolicy = ? ",fulldb1);
        $prepare pre_upd from $stmt;
        $execute pre_upd using $ucode;

        sprintf_s(stmt,512,
               "UPDATE %s:appraisal SET (irelative_ply) = (' ') \
                 WHERE ipolicy = ? ",fulldb1);
        $prepare pre_upd from $stmt;
        $execute pre_upd using $ucode;

        sprintf_s(stmt,512,
               "UPDATE %s:ply_relation_bak SET (irelative_ply) = (' ') \
                 WHERE ipolicy = ? ",fulldb1);
        $prepare pre_upd from $stmt;
        $execute pre_upd using $ucode;

        sprintf_s(stmt,512,
               "UPDATE %s:edr_relation SET (irelative_ply) = (' ') \
                 WHERE ipolicy = ? ",fulldb1);
        $prepare pre_upd from $stmt;
        $execute pre_upd using $ucode;

        /*  �N���N�����p�渹update�ӱ���蠟�j��O��  */

        sprintf_s(stmt,512,
               "UPDATE %s:ply_relation SET (irelative_ply) = (?) \
                 WHERE ipolicy = ? ",fulldb2);
        $prepare pre_upd from $stmt;
        $execute pre_upd using $ircode,$icode;

        sprintf_s(stmt,512,
               "UPDATE %s:ori_ply_relation SET (irelative_ply) = (?) \
                 WHERE ipolicy = ? ",fulldb2);
        $prepare pre_upd from $stmt;
        $execute pre_upd using $ircode,$icode;

        sprintf_s(stmt,512,
               "UPDATE %s:appraisal SET (irelative_ply) = (?) \
                 WHERE ipolicy = ? ",fulldb2);
        $prepare pre_upd from $stmt;
        $execute pre_upd using $ircode,$icode;

        sprintf_s(stmt,512,
               "UPDATE %s:ply_relation_bak SET (irelative_ply) = (?) \
                 WHERE ipolicy = ? ",fulldb2);
        $prepare pre_upd from $stmt;
        $execute pre_upd using $ircode,$icode;

        sprintf_s(stmt,512,
               "UPDATE %s:edr_relation SET (irelative_ply) = (?) \
                 WHERE ipolicy = ? ",fulldb2);
        $prepare pre_upd from $stmt;
        $execute pre_upd using $ircode,$icode;

        /*  �N����蠟�j�����p����N�渹   */
        sprintf_s(stmt,512,
               "UPDATE ply_relation SET (irelative_ply) = (?) \
                 WHERE ipolicy = ? ",fulldb3);
        $prepare pre_upd from $stmt;
        $execute pre_upd using $icode,$ircode;

        sprintf_s(stmt,512,
               "UPDATE ori_ply_relation SET (irelative_ply) = (?) \
                 WHERE ipolicy = ? ",fulldb3);
        $prepare pre_upd from $stmt;
        $execute pre_upd using $icode,$ircode;

        sprintf_s(stmt,512,
               "UPDATE appraisal SET (irelative_ply) = (?) \
                 WHERE ipolicy = ? ",fulldb3);
        $prepare pre_upd from $stmt;
        $execute pre_upd using $icode,$ircode;

        sprintf_s(stmt,512,
               "UPDATE ply_relation_bak SET (irelative_ply) = (?) \
                 WHERE ipolicy = ? ",fulldb3);
        $prepare pre_upd from $stmt;
        $execute pre_upd using $icode,$ircode;


        sprintf_s(stmt,512,
               "UPDATE edr_relation SET (irelative_ply) = (?) \
                 WHERE ipolicy = ? ",fulldb3);
        $prepare pre_upd from $stmt;
        $execute pre_upd using $icode,$ircode;

      }

      cm_buf_init(ReplyBuf);
      cm_buf_put("%l",M_CM_OK);
      tmp_len = cm_buf_len(ReplyBuf);
      if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
      {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        return apiRC;
      }

    $WHENEVER SQLERROR GOTO errexit;
    $COMMIT WORK;
    return api_OKComplete;
    errexit1:
      $WHENEVER SQLERROR CONTINUE;
      return exitsub(reply,M_CA_NPOLICY) ? M_CA_NPOLICY : apiRC;

    errexit2:
      $WHENEVER SQLERROR CONTINUE;
      return exitsub(reply,M_CA_NAPPRAISAL) ? M_CA_NAPPRAISAL : apiRC;

    errexit:
      MsgCode = SQLCODE;
      printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);

      $WHENEVER SQLERROR CONTINUE;
      $ROLLBACK WORK;
      if (SQLCODE != 0) MsgCode = SQLCODE;
      return exitsub(reply,MsgCode) ? MsgCode : apiRC;

}


/*     �����O�����p   */
long car514_update_C(reply)
serverReply reply;
{
     cm_buf_get("%s",DBName);
     cm_buf_get("%c %c %s %s ",&type,&inp,icode,ircode);

     if (db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     printf("--P1--\n");

     $WHENEVER SQLERROR GOTO errexit;
    /*   ���������p�� check ���������p    */
    strcpy(fulldb1,get_car_full_db(icode));
    sprintf_s(stmt,512,
           "select irelative_ply \
              from %s:ply_relation \
             where ipolicy = ? ",fulldb1);
    $prepare pre_rel from $stmt;
    $execute pre_rel
        into $irelative_ply_1
       using $icode;

    strcpy(fulldb2,get_car_full_db(ircode));
    sprintf_s(stmt,512,
           "select irelative_ply \
              from %s:ply_relation \
             where ipolicy = ? ",fulldb2);
    $prepare pre_rel from $stmt;
    $execute pre_rel
        into $irelative_ply_2
       using $ircode;

    strcpy(irelative_ply_1,trim(irelative_ply_1));
    strcpy(irelative_ply_2,trim(irelative_ply_2));

    /*  �S�����p�hRETURN MSG  */
    if((strcmp(icode,irelative_ply_2)!=0) && (strcmp(ircode,irelative_ply_1)!=0))
    {    return exitsub(reply,M_CA_NO_REL) ? M_CA_NO_REL : apiRC;   }

    else
    {

    strcpy(V_icode, substring(icode,6,1));
    strcpy(V_ircode, substring(ircode,6,1));
    if(strcmp(V_icode,"V")==0)
    {
        /*   �����O�����p���N�O��ݤw���P  */
        sprintf_s(stmt,512,
               "select ipolicy \
                  from %s:edr_relation \
                 where ipolicy = ? \
                   and fedr_class = '1' ",fulldb1);
        $prepare pre_edr from $stmt;
        $execute pre_edr using $icode;

        if(SQLCODE==SQLNOTFOUND)
        { return exitsub(reply,M_CA_NOT_CANCEL) ? M_CA_NOT_CANCEL : apiRC;   }
        else
        {

            sprintf_s(stmt,512,
                   "select icard from %s:ply_relation \
                     where ipolicy = ? ",fulldb2);
            $prepare pre_card from $stmt;
            $execute pre_card into $icard using $ircode;

            printf("icard[%s]\n",icard);
            strcpy(i_icard,"17");
            strcat(i_icard,icard);
            printf("i_icard[%s]\n",i_icard);

            $BEGIN WORK;
          
            sprintf_s(stmt,512,
                   "UPDATE %s:ply_relation SET (irelative_ply) = (' ') \
                       WHERE ipolicy = ? ",fulldb1);
            $prepare pre_upd from $stmt;
            $execute pre_upd using $icode;

            sprintf_s(stmt,512,
                   "UPDATE %s:ori_ply_relation SET (irelative_ply) = (' ') \
                     WHERE ipolicy = ? ",fulldb1);
            $prepare pre_upd from $stmt;
            $execute pre_upd using $icode;

            sprintf_s(stmt,512,
                   "UPDATE %s:appraisal SET (irelative_ply) = (' ') \
                     WHERE ipolicy = ? ",fulldb1);
            $prepare pre_upd from $stmt;
            $execute pre_upd using $icode;

            sprintf_s(stmt,512,
                   "UPDATE %s:ply_relation_bak SET (irelative_ply) = (' ') \
                     WHERE ipolicy = ? ",fulldb1);
            $prepare pre_upd from $stmt;
            $execute pre_upd using $icode;

            sprintf_s(stmt,512,
                   "UPDATE %s:edr_relation SET (irelative_ply) = (' ') \
                     WHERE ipolicy = ? ",fulldb1);
            $prepare pre_upd from $stmt;
            $execute pre_upd using $icode;


            sprintf_s(stmt,512,
                   "UPDATE %s:ply_relation SET (irelative_ply) = (' ') \
                     WHERE ipolicy = ? ",fulldb2);
            $prepare pre_upd from $stmt;
            $execute pre_upd using $ircode;

            sprintf_s(stmt,512,
                   "UPDATE %s:ori_ply_relation SET (irelative_ply) = (' ') \
                     WHERE ipolicy = ? ",fulldb2);
            $prepare pre_upd from $stmt;
            $execute pre_upd using $ircode;

            sprintf_s(stmt,512,
                   "UPDATE %s:appraisal SET (irelative_ply) = (' ') \
                     WHERE ipolicy = ? ",fulldb2);
            $prepare pre_upd from $stmt;
            $execute pre_upd using $ircode;

            sprintf_s(stmt,512,
                   "UPDATE %s:ply_relation_bak SET (irelative_ply) = (' ') \
                     WHERE ipolicy = ? ",fulldb2);
            $prepare pre_upd from $stmt;
            $execute pre_upd using $ircode;

            sprintf_s(stmt,512,
                   "UPDATE %s:edr_relation SET (irelative_ply) = (' ') \
                     WHERE ipolicy = ? ",fulldb2);
            $prepare pre_upd from $stmt;
            $execute pre_upd using $ircode;


            sprintf_s(stmt,512,
                   "UPDATE %s:policy SET (ixxcard) = (?) \
                     WHERE ipolicy = ? ",fulldb1);
            $PREPARE u_id FROM $stmt;
            $EXECUTE u_id USING $i_icard,$icode;


         }

     }

     if(strcmp(V_ircode,"V")==0)
     {

         sprintf_s(stmt,512,
                "select ipolicy from %s:edr_relation \
                  where ipolicy = ? and fedr_class = '1' ",fulldb2);
         $prepare pre_edr from $stmt;
         $execute pre_edr using $ircode;

         if(SQLCODE==SQLNOTFOUND)
         {  return exitsub(reply,M_CA_NOT_CANCEL) ? M_CA_NOT_CANCEL : apiRC;  }

         else
         {
             printf("************************\n");
             sprintf_s(stmt,512,
                    "select icard from %s:ply_relation \
                      where ipolicy = ? ",fulldb1);
             $prepare pre_card from $stmt;
             $execute pre_card into $icard using $icode;

             strcpy(i_icard,"17");
             printf("icard[%s]\n",icard);

             strcat(i_icard,icard);

             printf("i_icard[%s]\n",i_icard);
             printf(" ircode[%s]\n",ircode);
             $BEGIN WORK;

             sprintf_s(stmt,512,
                    "UPDATE %s:ply_relation SET (irelative_ply) = (' ') \
                      WHERE ipolicy = ? ",fulldb2);
             $prepare pre_upd from $stmt;
             $execute pre_upd using $ircode;

             sprintf_s(stmt,512,
                    "UPDATE %s:ori_ply_relation SET (irelative_ply) = (' ') \
                      WHERE ipolicy = ? ",fulldb2);
             $prepare pre_upd from $stmt;
             $execute pre_upd using $ircode;

             sprintf_s(stmt,512,
                    "UPDATE %s:appraisal SET (irelative_ply) = (' ') \
                      WHERE ipolicy = ? ",fulldb2);
             $prepare pre_upd from $stmt;
             $execute pre_upd using $ircode;

             sprintf_s(stmt,512,
                    "UPDATE %s:ply_relation_bak SET (irelative_ply) = (' ') \
                      WHERE ipolicy = ? ",fulldb2);
             $prepare pre_upd from $stmt;
             $execute pre_upd using $ircode;

             sprintf_s(stmt,512,
                    "UPDATE %s:edr_relation SET (irelative_ply) = (' ') \
                      WHERE ipolicy = ? ",fulldb2);
             $prepare pre_upd from $stmt;
             $execute pre_upd using $ircode;

             sprintf_s(stmt,512,
                    "UPDATE %s:ply_relation SET (irelative_ply) = (' ') \
                      WHERE ipolicy = ? ",fulldb1);
             $prepare pre_upd from $stmt;
             $execute pre_upd using $icode;

             sprintf_s(stmt,512,
                    "UPDATE %s:ori_ply_relation SET (irelative_ply) = (' ') \
                      WHERE ipolicy = ? ",fulldb1);
             $prepare pre_upd from $stmt;
             $execute pre_upd using $icode;

             sprintf_s(stmt,512,
                     "UPDATE %s:appraisal SET (irelative_ply) = (' ') \
                       WHERE ipolicy = ? ",fulldb1);
             $prepare pre_upd from $stmt;
             $execute pre_upd using $icode;

             sprintf_s(stmt,512,
                     "UPDATE %s:ply_relation_bak SET (irelative_ply) = (' ') \
                       WHERE ipolicy = ? ",fulldb1);
             $prepare pre_upd from $stmt;
             $execute pre_upd using $icode;

             sprintf_s(stmt,512,
                     "UPDATE %s:edr_relation SET (irelative_ply) = (' ') \
                       WHERE ipolicy = ? ",fulldb1);
             $prepare pre_upd from $stmt;
             $execute pre_upd using $icode;


             sprintf_s(stmt,512,
                    "UPDATE %s:policy SET (ixxcard) = (?) \
                      WHERE ipolicy = ? ",fulldb2);
             $PREPARE u_id FROM $stmt;
             $EXECUTE u_id USING $i_icard,$ircode;


              }
         }

       }
       cm_buf_init(ReplyBuf);
       cm_buf_put("%l",M_CM_OK);
       tmp_len = cm_buf_len(ReplyBuf);
       if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
       {
         $WHENEVER SQLERROR CONTINUE;
         $ROLLBACK WORK;
         return apiRC;
        }

 $WHENEVER SQLERROR GOTO errexit;
 $COMMIT WORK;
 return api_OKComplete;
 errexit1:
   $WHENEVER SQLERROR CONTINUE;
   return exitsub(reply,M_CA_NPOLICY) ? M_CA_NPOLICY : apiRC;

 errexit2:
   $WHENEVER SQLERROR CONTINUE;
   return exitsub(reply,M_CA_NAPPRAISAL) ? M_CA_NAPPRAISAL : apiRC;

 errexit:
   MsgCode = SQLCODE;
   printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);

   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if (SQLCODE != 0) MsgCode = SQLCODE;
   return exitsub(reply,MsgCode) ? MsgCode : apiRC;

}
/**********************************************************************/
/***  �����O�����p,�g�J�P�~�Ҹ�  ***/
long car514_update_D(reply)
serverReply reply;
{
    cm_buf_get("%s",DBName);
    cm_buf_get("%c %c %s %s %s ",&type,&inp,icode,ircode,ixxcard);

    if (db_select(DBName) == False)
       return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    printf("--P1--\n");

    $WHENEVER SQLERROR GOTO errexit;

    /*   ���������p�� check ���������p    */
    strcpy(fulldb1,get_car_full_db(icode));
    sprintf_s(stmt,512,
           "select irelative_ply from %s:ply_relation \
             where ipolicy = ? ",fulldb1);
    $prepare pre_rel from $stmt;
    $execute pre_rel
        into $irelative_ply_1
       using $icode;

    strcpy(fulldb2,get_car_full_db(ircode));
    sprintf_s(stmt,512,
           "select irelative_ply from %s:ply_relation \
             where ipolicy = ? ",fulldb2);
    $prepare pre_rel from $stmt;
    $execute pre_rel
        into $irelative_ply_2
       using $ircode;

    strcpy(irelative_ply_1,trim(irelative_ply_1));
    strcpy(irelative_ply_2,trim(irelative_ply_2));

    /*  �S�����p�hRETURN MSG  */
    if((strcmp(icode,irelative_ply_2)!=0) ||
       (strcmp(ircode,irelative_ply_1)!=0))
    {    return exitsub(reply,M_CA_NO_REL) ? M_CA_NO_REL : apiRC;   }

    strcpy(V_icode, substring(icode,6,1));
    strcpy(V_ircode, substring(ircode,6,1));

    if (strcmp(V_icode,"V")==0)
    {
       /*  ���N�O�榳�O�j��s�L�k��  */
       /*  �j��s���O��ܩ�e��,�ѨϥΪ̦ۦ�M�w 2006.09.22
       $select ipolicy
          into $fcomp_ipolicy
          from policy
         where ipolicy = $icode
           and fcomp_24='Y';

       if(SQLCODE!=SQLNOTFOUND)
       {    return exitsub(reply,M_CA_FCOMP) ? M_CA_FCOMP : apiRC;   }
       */

       $BEGIN WORK;
          
       sprintf_s(stmt,512,
              "UPDATE %s:ply_relation SET (irelative_ply) = (' ') \
                WHERE ipolicy = ? ",fulldb1);
       $prepare pre_upd from $stmt;
       $execute pre_upd using $icode;

       sprintf_s(stmt,512,
              "UPDATE %s:ori_ply_relation SET (irelative_ply) = (' ') \
                WHERE ipolicy = ? ",fulldb1);
       $prepare pre_upd from $stmt;
       $execute pre_upd using $icode;

       sprintf_s(stmt,512,
              "UPDATE %s:appraisal SET (irelative_ply) = (' ') \
                WHERE ipolicy = ? ",fulldb1);
       $prepare pre_upd from $stmt;
       $execute pre_upd using $icode;

       sprintf_s(stmt,512,
              "UPDATE %s:ply_relation_bak SET (irelative_ply) = (' ') \
                WHERE ipolicy = ? ",fulldb1);
       $prepare pre_upd from $stmt;
       $execute pre_upd using $icode;

       sprintf_s(stmt,512,
              "UPDATE %s:edr_relation SET (irelative_ply) = (' ') \
                WHERE ipolicy = ? ",fulldb1);
       $prepare pre_upd from $stmt;
       $execute pre_upd using $icode;

       sprintf_s(stmt,512,
              "UPDATE %s:ply_relation SET (irelative_ply) = (' ') \
                WHERE ipolicy = ? ",fulldb2);
       $prepare pre_upd from $stmt;
       $execute pre_upd using $ircode;

       sprintf_s(stmt,512,
              "UPDATE %s:ori_ply_relation SET (irelative_ply) = (' ') \
                WHERE ipolicy = ? ",fulldb2);
       $prepare pre_upd from $stmt;
       $execute pre_upd using $ircode;

       sprintf_s(stmt,512,
              "UPDATE %s:appraisal SET (irelative_ply) = (' ') \
                WHERE ipolicy = ? ",fulldb2);
       $prepare pre_upd from $stmt;
       $execute pre_upd using $ircode;

       sprintf_s(stmt,512,
              "UPDATE %s:ply_relation_bak SET (irelative_ply) = (' ') \
                WHERE ipolicy = ? ",fulldb2);
       $prepare pre_upd from $stmt;
       $execute pre_upd using $ircode;

       sprintf_s(stmt,512,
              "UPDATE %s:edr_relation SET (irelative_ply) = (' ') \
                WHERE ipolicy = ? ",fulldb2);
       $prepare pre_upd from $stmt;
       $execute pre_upd using $ircode;

       /* �g�J�P�~�Ҹ� */
       sprintf_s(stmt,512,
              "UPDATE %s:policy SET (ixxcard) = (?) \
                WHERE ipolicy = ? ",fulldb1);
       $prepare pre_upd from $stmt;
       $execute pre_upd using $ixxcard,$icode;
     }

     if (strcmp(V_ircode,"V")==0)
     {
       /*  ���N�O�榳�O�j��s�L�k��  */
       /*  �j��s���O��ܩ�e��,�ѨϥΪ̦ۦ�M�w 2006.09.22
       $select ipolicy
          into $fcomp_ipolicy
          from policy
         where ipolicy = $ircode
           and fcomp_24='Y';

       if(SQLCODE!=SQLNOTFOUND)
       {    return exitsub(reply,M_CA_FCOMP) ? M_CA_FCOMP : apiRC;   }
       */

        $BEGIN WORK;

        sprintf_s(stmt,512,
               "UPDATE %s:ply_relation SET (irelative_ply) = (' ') \
                 WHERE ipolicy = ? ",fulldb2);
        $prepare pre_upd from $stmt;
        $execute pre_upd using $ircode;

        sprintf_s(stmt,512,
               "UPDATE %s:ori_ply_relation SET (irelative_ply) = (' ') \
                 WHERE ipolicy = ? ",fulldb2);
        $prepare pre_upd from $stmt;
        $execute pre_upd using $ircode;

        sprintf_s(stmt,512,
               "UPDATE %s:appraisal SET (irelative_ply) = (' ') \
                 WHERE ipolicy = ? ",fulldb2);
        $prepare pre_upd from $stmt;
        $execute pre_upd using $ircode;

        sprintf_s(stmt,512,
               "UPDATE %s:ply_relation_bak SET (irelative_ply) = (' ') \
                 WHERE ipolicy = ? ",fulldb2);
        $prepare pre_upd from $stmt;
        $execute pre_upd using $ircode;

        sprintf_s(stmt,512,
               "UPDATE %s:edr_relation SET (irelative_ply) = (' ') \
                 WHERE ipolicy = ? ",fulldb2);
        $prepare pre_upd from $stmt;
        $execute pre_upd using $ircode;

        sprintf_s(stmt,512,
               "UPDATE %s:ply_relation SET (irelative_ply) = (' ') \
                 WHERE ipolicy = ? ",fulldb1);
        $prepare pre_upd from $stmt;
        $execute pre_upd using $icode;

        sprintf_s(stmt,512,
               "UPDATE %s:ori_ply_relation SET (irelative_ply) = (' ') \
                 WHERE ipolicy = ? ",fulldb1);
        $prepare pre_upd from $stmt;
        $execute pre_upd using $icode;

        sprintf_s(stmt,512,
               "UPDATE %s:appraisal SET (irelative_ply) = (' ') \
                 WHERE ipolicy = ? ",fulldb1);
        $prepare pre_upd from $stmt;
        $execute pre_upd using $icode;

        sprintf_s(stmt,512,
               "UPDATE %s:ply_relation_bak SET (irelative_ply) = (' ') \
                 WHERE ipolicy = ? ",fulldb1);
        $prepare pre_upd from $stmt;
        $execute pre_upd using $icode;

        sprintf_s(stmt,512,
               "UPDATE %s:edr_relation SET (irelative_ply) = (' ') \
                 WHERE ipolicy = ? ",fulldb1);
        $prepare pre_upd from $stmt;
        $execute pre_upd using $icode;

        /* ���N�O��g�J�P�~�Ҹ� */
        sprintf_s(stmt,512,
               "UPDATE %s:policy SET (ixxcard) = (?) \
                 WHERE ipolicy = ? ",fulldb2);
        $prepare pre_upd from $stmt;
        $execute pre_upd using $ixxcard,$ircode;

     }
     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);
     tmp_len = cm_buf_len(ReplyBuf);
     if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
     {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        return apiRC;
     }

 $WHENEVER SQLERROR GOTO errexit;
 $COMMIT WORK;
 return api_OKComplete;

 errexit:
   MsgCode = SQLCODE;
   printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);

   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if (SQLCODE != 0) MsgCode = SQLCODE;
   return exitsub(reply,MsgCode) ? MsgCode : apiRC;

}
/**********************************************************************/
