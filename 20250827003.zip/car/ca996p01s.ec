 /* Copyright (C) 2001 Intellisys Corporation
  * Program : ca997p03s.ec
  * ����v����z�߸��
  * Time �G94/06/09
  *********************************************/
 
#include <stdio.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"
#include "sqlfatal.h"

#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"

/*--------------------------------------------------------------------*/

DBinfo  *list;
int     i,count_db,rc;

char userid[11],option[2],outputf[21];
$char DBName[05];
$char datebgn[11],dateend[11];
$char sApHome[31],tmp_dbname[20];
char errmsg[200];
FILE *errfpt;
FILE *fptr,*fptr1,*fptr2,*fptr3;
$int number;

$char  errFile[30],errlog[300];

static char localdb[5];
static int  i,flag_check=0;

static char sExpdate[10];
static char sBgndate[10],sEnddate[10];
$static char  sDappraisal_bgn[11], sDappraisal_end[11];
long rtncode;

/*static char sPrtstr[250]; */

$static char  sDgroup[11];
$static char  sTmt_buf[1024];

/* data  ca_trad_exam */
$long prem_total, cntrlrec;
$long minjure, mcripple, mdeath;
$long qcount,Tinjure, Tcripple, Tdeath,Tamount;
$long policy_day;
char companyid[3];
int rtn;

/* data ca_trad_exam */
$char iply_type[3];

/* others data */
$char sDappraisal_c[11],Tmp1[20],file0[51],file1[51],file2[51],file3[51];       
$char fcard_class[2],close_date_c[11];
char  day_yy[4],day_mm[3],day_dd[3];
char  strlog[500],cntrlrec_c[7],prtstr[500];
$long cntrlrec=0;
$long close_date, old_close_date;
$char ibranch_in[5];
$char  company_flag;
$char  iclaim_flag;
$int   count;
$char  COMPANY[3];
$char  COMPANY_F[3];

$char filename[20];
$long filecount;
$int   PgLine, Width;
$char  FormFile[N_FILE+1];
$char  OutFile[51];
 

$define  INJURE         "93";
$define  DEATH          "94";
$define  CRIPPLE        "95";
$define  COMPULSORY     "21";

static long car996_clam(); 
static long car996_inju();
static long car996_car(); 
static long car996_org(); 

long car996_get_db();
extern char *sformat_trade();
extern long split_policy();
extern int rptftpinsert();
long check_if_exist();

/*--------------------------------------------------------------------*/

main(argc,argv)
int   argc;
char  **argv;
{
int   rc;

   batchinit();

   strcpy(DBName,isNULLstr(argv[1]));
   strcpy(userid,isNULLstr(argv[2]));
   strcpy(datebgn,isNULLstr(argv[3]));
   strcpy(dateend,isNULLstr(argv[4]));
   strcpy(outputf,isNULLstr(argv[5]));
   
   if (datebgn[0]=='*' || datebgn[0] == '\0') 
     strcpy(datebgn,  "80/01/01");
   if (dateend[0]=='*' || dateend[0] == '\0') 
     strcpy(dateend,  "99/12/31");

   strcpy(sDappraisal_bgn,cm_to_infdate(datebgn));
   strcpy(sDappraisal_end,cm_to_infdate(dateend));
   
   $WHENEVER SQLERROR GOTO errexit;
   
   errfpt = (FILE *) STARTLOG();   
   
   
   rc=car996_get_db();
   if (rc!=M_CM_OK)
      return rc;
    
   rc = getApHome(sApHome);
   if (rc < 0) {
        printf("read Config file error!!\n");
        return M_CM_READ_CONFIG_ERR;
   } 
   
   sApHome[31] = '\0';
   
   printf("sApHome[%s]\n",sApHome);
   
   

    rtncode=car996_clam();  printf("rtncode[%d]\n",rtncode); 
 
   if (rtncode != SUCCESS )
   {
        
        rgetmsg(rtncode, errlog, sizeof(errlog));
        
        sprintf(strlog,"%s\n\n\t\t     ",errlog);
        
        printf("option [%s]\n",option);
        
   
         
         strcat(strlog," iscm17_�j��T���z�߻s�@���� ");
                 
  
        
        printf("strlog[%s]\n",strlog); 
        
        EWRITE(userid,rc,strlog);
        
        exit(1);
   }
   

    
   rtncode=car996_inju();  printf("rtncode[%d]\n",rtncode); 
 
   if (rtncode != SUCCESS )
   {
        
        rgetmsg(rtncode, errlog, sizeof(errlog));
        
        sprintf(strlog,"%s\n\n\t\t     ",errlog);
        
        printf("option [%s]\n",option);
        
   
         
         strcat(strlog," iscm17_�j��T���z�߻s�@���� ");
                 
  
        
        printf("strlog[%s]\n",strlog); 
        
        EWRITE(userid,rc,strlog);
        
        exit(1);
   }

   rtncode=car996_car();  printf("rtncode[%d]\n",rtncode); 
 
   if (rtncode != SUCCESS )
   {
        
        rgetmsg(rtncode, errlog, sizeof(errlog));
        
        sprintf(strlog,"%s\n\n\t\t     ",errlog);
        
        printf("option [%s]\n",option);
        
   
         
         strcat(strlog," iscm17_�j��T���z�߻s�@���� ");
                 
  
        
        printf("strlog[%s]\n",strlog); 
        
        EWRITE(userid,rc,strlog);
        
        exit(1);
   }

   rtncode=car996_org();  printf("rtncode[%d]\n",rtncode); 
 
   if (rtncode != SUCCESS )
   {
        
        rgetmsg(rtncode, errlog, sizeof(errlog));
        
        sprintf(strlog,"%s\n\n\t\t     ",errlog);
        
        printf("option [%s]\n",option);
        
   
         
         strcat(strlog," iscm17_�j��T���z�߻s�@���� ");
                 
  
        
        printf("strlog[%s]\n",strlog); 
        
        EWRITE(userid,rc,strlog);
        
        exit(1);
   }

    $SELECT kPgNum_Line,nForm_File
       INTO $PgLine,$FormFile
       FROM Form
      WHERE ksys_grp="CA" AND kpgmid = 302;

    strcpy(FormFile,rtrim(FormFile));
    sprintf(OutFile,"%s.tx",outputf);

    rgu_init_report(FormFile,OutFile);

    rgu_put_body_string(1,"���v����@�~���� ok ",1);
    rgu_put_body(1);
    rgu_finish_report();
   if(rc=(save_form_info(F_FREE,"CA",302,userid,"",1,outputf))<0)
   {
      printf("*** save_form_info() fail\n");
   }



   return 0 ;
 /*  exit(0); */
   
errexit:
    printf("car996-main:sqlcode=%d, sqlmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    
    
    return SQLCODE; 
   
}

/*----------------------------------------------------------------------*/

long car996_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   return M_CM_OK;

errexit:
 /*  sqlfatal(); */
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);

   return SQLCODE;
}

/*--------------------------�u�߸����------------------------------------------*/

long car996_clam()
{
  
     long   iRtnCode;
     int    iFetch; 
 
     $char stmt_buf1[1000],stmt_buf2[200],Tstmt[500];
     char sPrtstr[251];
     $char iclaim[18],daccident[15],iins_item[4];
     $int  mcompro,mins_stl;
     $char datone[11],dgroup[11],ibranch[3],iadjuster[11];
     $char nname[20];
     $char yyyy[5],yy[3],mm[3],dd[3],hh[3];
     $char yyyy1[5],yy1[3],mm1[3],dd1[3],hh1[3];
     $char yyyy2[5],yy2[3],mm2[3],dd2[3],hh2[3];
     $char str_iins_item[4];
     $char iins_item_C[3];


     memset(sTmt_buf,' ',sizeof(sTmt_buf));
     
     $WHENEVER SQLERROR GOTO errexit;

     $CREATE TEMP TABLE STl_CLAM
     (
     
        iclaim    char(20),
        daccident char(15),
        iins_item char(3),
        mcompro   integer,
        datone    char(11), /* ca_clm_process */
        mins_stl  integer,
        dgroup    char(10),
        ibranch   char(2),
        iadjuster char(10)
     )WITH NO LOG;
     
     
     for( i=0; i<count_db; i++)
     {
        sprintf(Tstmt,"SELECT distinct a.iclaim,a.daccident,c.dcomp ,a.iclaim[1,2],"
                      "       a.iadjuster ,c.dgroup  "
                      "  FROM %s:appraisal a ,ca_clm_process b ,%s:ca_stl_victim c "
                      " WHERE dgroup BETWEEN '%s' AND '%s' "
                      "  AND  a.iclaim = b.iclaim  AND a.iclaim = c.iclaim"
                      "  AND  c.fstl = '1'    "
                      " ORDER BY iclaim  ",list[i].dbname,list[i].dbname,
                      sDappraisal_bgn, sDappraisal_end );
        
        printf("Tstmt[%s]\n",Tstmt);
        
        $PREPARE TSTMT FROM $Tstmt;
        $DECLARE CUSTSTMT CURSOR for TSTMT;
        
        $OPEN CUSTSTMT;
        while(1)
        {
            $FETCH CUSTSTMT INTO $iclaim,$daccident,$datone,$ibranch,$iadjuster,$dgroup;
                        
            if( SQLCODE == SQLNOTFOUND ) break;
            
            sprintf(Tstmt,"select sum(mins_stl),sum(mcompro) \
                                from %s:ca_stl_victim a,%s:settlement b  \
                               where a.iclaim = b.iclaim  \
                                 and a.fstl = b.fstl \
                                 and a.iclose_type = b.iclose_type  \
                                 and a.dgroup = '%s'       \
                                 and a.iclaim = '%s' ",list[i].dbname,list[i].dbname,dgroup,iclaim);
                           
            $prepare pre_dgroup from $Tstmt;
            $execute pre_dgroup into $mins_stl,$mcompro;       
            
            if( SQLCODE == SQLNOTFOUND )
            { 
               mins_stl = 0;
               mcompro  = 0;
            }
          
           sprintf(Tstmt,
               "select distinct iins_item[1]   \
                  from %s:ca_stl_victim \
                 where iclaim = '%s'    \
                 order by 1",list[i].dbname,iclaim );

        EXEC SQL PREPARE Acursor  FROM :Tstmt;
        EXEC SQL DECLARE Acursor1 CURSOR FOR Acursor;
        EXEC SQL OPEN Acursor1;
        while (1)
        {
            $FETCH Acursor1 INTO $iins_item;
            
             if (SQLCODE == SQLNOTFOUND) break; 
             
             if(strcmp(trim(iins_item),"A")==0)
             {          
                strcpy(str_iins_item,"A00");
             } 
             else if(strcmp(trim(iins_item),"B")==0)
             {
                strcpy(str_iins_item,"AB0");
             }
             else if(strcmp(trim(iins_item),"C")==0)
             {  
                 sprintf(Tstmt,"select max(iins_item[2,3]) \
                                from %s:ca_stl_victim  \
                               where iclaim = '%s'     \
                                 and iins_item[1]= 'C' ",list[i].dbname,iclaim);
                           
            $prepare pre_C from $Tstmt;
            $execute pre_C into $iins_item_C; 
                strcpy(str_iins_item,"A");
                strcat(str_iins_item,iins_item_C);
                
                
             }
        }
        
           $INSERT INTO STl_CLAM (iclaim, daccident, iins_item, mcompro, datone ,
                                   mins_stl , dgroup, ibranch,iadjuster)
                           VALUES ($iclaim, $daccident, $str_iins_item, $mcompro, $datone,
                                   $mins_stl , $dgroup, $ibranch, $iadjuster );
            
           str_iins_item[0]='\0'; 
        }
        $CLOSE CUSTSTMT;
        $FREE  CUSTSTMT;
     }
     
       sprintf(Tmp1,"CLAM17");
       sprintf(file0,"%s/rptftp/%s",trim(sApHome),Tmp1);
       printf("file0[%s] Tmp1[%s]\n",file0,Tmp1);
       fptr=fopen(file0,"w");
     
       $DECLARE CUS2 CURSOR for
         SELECT iclaim,    daccident, iins_item, mcompro, datone ,
                mins_stl , dgroup,    ibranch,   iadjuster
           INTO $iclaim,   $daccident, $iins_item, $mcompro, $datone ,
                $mins_stl ,$dgroup,    $ibranch,   $iadjuster
           FROM STl_CLAM
          ORDER BY iclaim;
        
       $OPEN CUS2;
       while (1)
       {
            
           memset(sPrtstr,' ',sizeof(sPrtstr));
           
           $FETCH CUS2;
           
           if (SQLCODE == SQLNOTFOUND) break;
           
           cm_split_ymd_100(daccident,day_yy,day_mm,day_dd);
           
           strcpy(sPrtstr, iclaim);       sPrtstr[17]='\0';     /*C1:�׸�*/

printf(" daccident[%s]\n",daccident);           

           yyyy[0]='\0'; 
           yy[0]='\0';
           mm[0]='\0';
           dd[0]='\0';
           hh[0]='\0';

           strcpy(yyyy,substring(daccident,1,4));  yyyy[4]='\0';
printf(" yyyy[%s]\n",yyyy);           
           strncpy(mm, daccident+5, 2); mm[2]='\0';
printf(" mm[%s]\n",mm);            
           strncpy(dd, daccident+8, 2); dd[2]='\0';
           strncpy(hh, daccident+11, 2); hh[2]='\0';
 
printf("    yyyy[%s],mm[%s],dd[%s],hh[%s]\n",yyyy,mm,dd,hh);
           strcpy(yy,itoa((atoi(yyyy)-1911)));
printf(" yy[%s]\n",yy);             
           
           strcat(sPrtstr, yy );   sPrtstr[19]='\0'; 
           strcat(sPrtstr, mm );   sPrtstr[21]='\0'; 
           strcat(sPrtstr, dd );   sPrtstr[23]='\0'; 
           strcat(sPrtstr, hh );   sPrtstr[25]='\0'; 
printf(" iins_item[%s]\n",iins_item);                      
           strcat(sPrtstr, iins_item);    sPrtstr[28]='\0';     /*C2:�I��*/
printf("  mcompro[%d]\n",mcompro);          
           strcat(sPrtstr, sformat_trade(&mcompro,1,7));        /* �M�Ѫ��B  */
           sPrtstr[35]='\0';  
printf("      datone[%s]\n",datone);  


    
if(strcmp(trim(datone),"")!=0)
{
           yyyy1[0]='\0'; 
           yy1[0]='\0';
           mm1[0]='\0';
           dd1[0]='\0';
           hh1[0]='\0';

           strcpy(mm1,substring(datone,1,2));  mm1[2]='\0';
           strncpy(dd1, datone+3, 2); dd1[2]='\0';
           strncpy(yyyy1, datone+6, 4); yyyy1[4]='\0';
           
 
printf("    yyyy1[%s],mm1[%s],dd1[%s]\n",yyyy1,mm1,dd1);
           strcpy(yy1,itoa((atoi(yyyy1)-1911)));
          
           
           strcat(sPrtstr, yy1 );   sPrtstr[37]='\0';     /*C2:�M�Ѥ�� */
           strcat(sPrtstr, mm1 );   sPrtstr[39]='\0'; 
           strcat(sPrtstr, dd1 );   sPrtstr[41]='\0'; 
           strcat(sPrtstr, "  " );   sPrtstr[43]='\0'; 
         
}
else
{
           strcat(sPrtstr, "        " );  sPrtstr[43]='\0';  
}          
printf("    mins_stl[%d]\n",mins_stl);      
           strcat(sPrtstr, sformat_trade(&mins_stl,1,7));       /* �ߥI���B */
           sPrtstr[50]='\0';  
           
           yyyy2[0]='\0'; 
           yy2[0]='\0';
           mm2[0]='\0';
           dd2[0]='\0';
           hh2[0]='\0';

 
           strcpy(mm2,substring(dgroup,1,2));  mm2[2]='\0';
           strncpy(dd2, dgroup+3, 2); dd2[2]='\0';
           strncpy(yyyy2, dgroup+6, 4); yyyy2[4]='\0';
           
 
printf("    yyyy2[%s],mm2[%s],dd2[%s]\n",yyyy2,mm2,dd2);
           strcpy(yy2,itoa((atoi(yyyy2)-1911)));
          
           
           strcat(sPrtstr, yy2 );   sPrtstr[52]='\0';     /*C2:�J�p��� */
           strcat(sPrtstr, mm2 );   sPrtstr[54]='\0'; 
           strcat(sPrtstr, dd2 );   sPrtstr[56]='\0'; 
           strcat(sPrtstr, "  " );   sPrtstr[58]='\0'; 
    
           strcat(sPrtstr, "17");  sPrtstr[60]='\0';         /*C2:���z���c*/
           
           $select nname 
              into $nname
              from officer
             where iofficer =$iadjuster;
           
           strcat(sPrtstr, nname);  sPrtstr[80]='\0';       /*C2:�z�߭� */
           printf(" sPrtstr[%s]\n",sPrtstr);

           fprintf(fptr,"%s\n",sPrtstr);
           
           cntrlrec++;
           
           printf("cntrlrec[%d] \n",cntrlrec );
           
        } 

        
           strcpy(sPrtstr,"CNTRLREC");
           rfmtlong(cntrlrec,"&&&&&&",cntrlrec_c);
           strcat(sPrtstr,cntrlrec_c);
           fprintf(fptr, "%s\n", sPrtstr);  
           cntrlrec = 0;
        
        $CLOSE CUS2;
        $FREE  CUS2;
        
     
     return(SUCCESS);
     
     

errexit:
     return(SQLCODE);
}

/*--------------------------���`�H�����------------------------------------------*/

long car996_inju()
{
     char sPrtstr1[48];
     long   iRtnCode;
     int    iFetch; 
     $char stmt_buf1[1000],stmt_buf2[200],Tstmt[500];
     
     $char  sIclaim[CLAIM_NUM],sIvictim[11],sNvictim[21];
     $char  iclaim[CLAIM_NUM],ivictim[11],nvictim[21];
     
    

     memset(sTmt_buf,' ',sizeof(sTmt_buf));
     
     $WHENEVER SQLERROR GOTO errexit;

     $CREATE TEMP TABLE STL_INJU
     (
     
        iclaim   char(20),
        ivictim  char(10),
        nvictim  char(20)

        
     )WITH NO LOG;
     
     for( i=0; i<count_db; i++)
     {
        sprintf(Tstmt,"SELECT distinct iclaim,ivictim    "
                      "  FROM %s:ca_stl_victim  "
                      " WHERE dgroup BETWEEN '%s' AND '%s' "
                      "  AND  fstl = '1'    "
                      " ORDER BY iclaim,ivictim  ",list[i].dbname,
                      sDappraisal_bgn, sDappraisal_end );
        
        printf("Tstmt[%s]\n",Tstmt);
        
        $PREPARE TSTMT FROM $Tstmt;
        $DECLARE CUSTSTMT1 CURSOR for TSTMT;
        
        $OPEN CUSTSTMT1;
        while(1)
        {
            $FETCH CUSTSTMT1 INTO $iclaim, $ivictim;
            
            if( SQLCODE == SQLNOTFOUND ) break;
            
            
            $select nchi_full
               into $nvictim
               from cu_customer
              where ifpce_id = $ivictim
                and ifpce_id_ext = ' ';
           
            if (SQLCODE == SQLNOTFOUND)
            {
               strcpy(nvictim," ");
            }
            
            $INSERT INTO STL_INJU ( iclaim , ivictim , nvictim )
                          VALUES ( $iclaim, $ivictim ,$nvictim );
        }
        $CLOSE CUSTSTMT1;
        $FREE  CUSTSTMT1;
     }
     
        sprintf(Tmp1,"INJU17");
        sprintf(file1,"%s/rptftp/%s",trim(sApHome),Tmp1);
        printf("file1[%s] Tmp1[%s]\n",file1,Tmp1);
        fptr1=fopen(file1,"w");
     
     
       $DECLARE CUS21 CURSOR for
         SELECT iclaim, ivictim , nvictim
           INTO $sIclaim,$sIvictim , $sNvictim
           FROM STL_INJU
          ORDER BY iclaim;
        
       $OPEN CUS21;
       while (1)
       {
           memset(sPrtstr1,' ',sizeof(sPrtstr1));
           
           $FETCH CUS21;
           
           if (SQLCODE == SQLNOTFOUND) break;
 
           
           strcpy(sPrtstr1,sIclaim ); sPrtstr1[17]='\0';       /*C1:�׸�*/
           strcat(sPrtstr1,sIvictim); sPrtstr1[27]='\0';       /*C2:���`�H*/
           strcat(sPrtstr1,sNvictim); sPrtstr1[47]='\0';       /*C3:���`�H����*/
          
           prtstr[48] = '\n';
           prtstr[49]= '\0';
printf("      sPrtstr1[%s]\n",sPrtstr1);      
         
           fprintf(fptr1,"%s\n",sPrtstr1); 
           cntrlrec++;
           
           printf("cntrlrec[%d] \n",cntrlrec );
           
        } 
           strcpy(sPrtstr1,"CNTRLREC");
           rfmtlong(cntrlrec,"&&&&&&",cntrlrec_c);
           strcat(sPrtstr1,cntrlrec_c);
           fprintf(fptr1, "%s\n", sPrtstr1);  
           cntrlrec = 0;
        
        printf ("end lApp_comp\n");
        
        $CLOSE CUS21;
        $FREE  CUS21;

     return(SUCCESS);
     
     

errexit:
     return(SQLCODE);
}

/*--------------------------�ƬG�T�������------------------------------------------*/

long car996_car()
{
     char sPrtstr2[48];
     long   iRtnCode;
     int    iFetch; 
     $char stmt_buf1[1000],stmt_buf2[200],Tstmt[500];
     
     $char iclaim[18];
     $char nacc_driver[21];
     $char iacc_license[11];
     $char nassured[21];
     $char iassured[11];
     $char itag[9];
     
    
     memset(sTmt_buf,' ',sizeof(sTmt_buf));
     
     $WHENEVER SQLERROR GOTO errexit;

     $CREATE TEMP TABLE STL_CAR
     (
     
        iclaim       char(17),
        nacc_driver  char(20),
        iacc_license char(10),
        nassured     char(20),
        iassured     char(10),
        itag         char(8)

     )WITH NO LOG;
     
     for( i=0; i<count_db; i++)
     {
        sprintf(Tstmt,"SELECT distinct a.iclaim,b.nacc_driver,b.iacc_license,c.nassured,c.iassured,c.itag     "
                      "  FROM %s:ca_stl_victim a,%s:appraisal b,%s:adjustment_ply c "
                      " WHERE a.dgroup BETWEEN '%s' AND '%s' "
                      "   AND a.iclaim = b.iclaim AND a.iclaim = c.iclaim "
                      "   AND a.fstl = '1'    "
                      " ORDER BY iclaim  ",list[i].dbname,list[i].dbname,list[i].dbname,
                      sDappraisal_bgn, sDappraisal_end );
        
        printf("Tstmt[%s]\n",Tstmt);
        
        $PREPARE TSTMT FROM $Tstmt;
        $DECLARE CUSTSTMT2 CURSOR for TSTMT;
        
        $OPEN CUSTSTMT2;
        while(1)
        {
            
            $FETCH CUSTSTMT2 INTO $iclaim,$nacc_driver,$iacc_license,$nassured,$iassured,$itag;
            
            if( SQLCODE == SQLNOTFOUND ) break;
            
            
            $INSERT INTO STL_CAR ( iclaim,nacc_driver,iacc_license,nassured,iassured,itag)
                          VALUES ( $iclaim,$nacc_driver,$iacc_license,$nassured,$iassured,$itag);
                          
        }
        $CLOSE CUSTSTMT2;
        $FREE  CUSTSTMT2;
        
     }
     
        sprintf(Tmp1,"CAR17");
        sprintf(file2,"%s/rptftp/%s",trim(sApHome),Tmp1);
        printf("file2[%s] Tmp1[%s]\n",file2,Tmp1);
        fptr2=fopen(file2,"w");
     
     
       $DECLARE CUS22 CURSOR for
         SELECT iclaim,nacc_driver,iacc_license,nassured,iassured,itag
           INTO $iclaim,$nacc_driver,$iacc_license,$nassured,$iassured,$itag
           FROM STL_CAR
          ORDER BY iclaim;
        
       $OPEN CUS22;
       while (1)
       {
            
           memset(sPrtstr2,' ',sizeof(sPrtstr2));
           
           $FETCH CUS22;
           
           if (SQLCODE == SQLNOTFOUND) break;
 
           
           strcpy(sPrtstr2,iclaim ); sPrtstr2[17]='\0';       /*C1:�׸�*/
           strcat(sPrtstr2,nacc_driver); sPrtstr2[37]='\0';       /*C2:�r�p�m�W*/
           strcat(sPrtstr2,iacc_license); sPrtstr2[47]='\0';       /*C3:�r�p*/
           strcat(sPrtstr2,nassured); sPrtstr2[67]='\0';       /*C3:�Q�O�I�H�m�W*/
           strcat(sPrtstr2,iassured); sPrtstr2[77]='\0';       /*C3:�Q�O�I�H*/
           strcat(sPrtstr2,itag); sPrtstr2[85]='\0';       /*C3:���P���X */
          
           
printf("      sPrtstr2[%s]\n",sPrtstr2);      
         
           fprintf(fptr2,"%s\n",sPrtstr2); 
           cntrlrec++;
           
           printf("cntrlrec[%d] \n",cntrlrec );
           
        } 
        
        
           strcpy(sPrtstr2,"CNTRLREC");
           rfmtlong(cntrlrec,"&&&&&&",cntrlrec_c);
           strcat(sPrtstr2,cntrlrec_c);
           fprintf(fptr2, "%s\n", sPrtstr2);  
           cntrlrec = 0;
        
        printf ("end lApp_comp\n");
        
        $CLOSE CUS22;
        $FREE  CUS22;

     return(SUCCESS);
     
     

errexit:
     return(SQLCODE);
}

/*--------------------------�u�߾��c��ƶ��ػ�����------------------------------------------*/

long car996_org()
{
     char sPrtstr3[48];
     long   iRtnCode;
     int    iFetch; 
     $char stmt_buf1[1000],stmt_buf2[200],Tstmt[500];
     
     $char iclaim[18];
     $char dgroup[11];
     $char ioth_branch[3];
     $int  mins_stl,ioth_mins_stl;
     $char yyyy2[5],yy2[3],mm2[3],dd2[3],hh2[3];
    
     memset(sTmt_buf,' ',sizeof(sTmt_buf));
     
     $WHENEVER SQLERROR GOTO errexit;

     $CREATE TEMP TABLE STL_ORG
     (
     
        iclaim       char(17),
        dgroup       char(11),
        ioth_branch char(10),
        ioth_mins_stl integer
        
     )WITH NO LOG;
     
     for( i=0; i<count_db; i++)
     {
        sprintf(Tstmt,"SELECT iclaim,dgroup,sum(mins_stl) "
                      "  FROM %s:ca_stl_victim "
                      " WHERE dgroup BETWEEN '%s' AND '%s' "
                      "  AND  fstl = '1'    "
                      " GROUP BY 1,2     "
                      " ORDER BY iclaim  ",list[i].dbname,
                      sDappraisal_bgn, sDappraisal_end );
        
        printf("Tstmt[%s]\n",Tstmt);
        
        $PREPARE TSTMT FROM $Tstmt;
        $DECLARE CUSTSTMT3 CURSOR for TSTMT;
        
        $OPEN CUSTSTMT3;
        while(1)
        {
            
            $FETCH CUSTSTMT3 INTO $iclaim,$dgroup,$mins_stl;
            
            if( SQLCODE == SQLNOTFOUND ) break;
            
            ioth_mins_stl = mins_stl / 2;
            
            $INSERT INTO STL_ORG ( iclaim,dgroup,ioth_branch,ioth_mins_stl)
                          VALUES ( $iclaim,$dgroup,"17",$ioth_mins_stl);
                          
        }
        $CLOSE CUSTSTMT3;
        $FREE  CUSTSTMT3;
        
     }
     
        sprintf(Tmp1,"ORG17");
        sprintf(file3,"%s/rptftp/%s",trim(sApHome),Tmp1);
        printf("file3[%s] Tmp1[%s]\n",file3,Tmp1);
        fptr3=fopen(file3,"w");
     
     
       $DECLARE CUS23 CURSOR for
         SELECT iclaim,dgroup,ioth_branch,ioth_mins_stl
           INTO $iclaim,$dgroup,$ioth_branch,$ioth_mins_stl
           FROM STL_ORG
          ORDER BY iclaim;
        
       $OPEN CUS23;
       while (1)
       {
            
           memset(sPrtstr3,' ',sizeof(sPrtstr3));
           
           $FETCH CUS23;
           
           if (SQLCODE == SQLNOTFOUND) break;
 
           
           strcpy(sPrtstr3,iclaim ); sPrtstr3[17]='\0';       /*C1:�׸�*/
           
           yyyy2[0]='\0'; 
           yy2[0]='\0';
           mm2[0]='\0';
           dd2[0]='\0';
           hh2[0]='\0';

 
           strcpy(mm2,substring(dgroup,1,2));  mm2[2]='\0';
           strncpy(dd2, dgroup+3, 2); dd2[2]='\0';
           strncpy(yyyy2, dgroup+6, 4); yyyy2[4]='\0';
           
 
printf("    yyyy2[%s],mm2[%s],dd2[%s]\n",yyyy2,mm2,dd2);
           strcpy(yy2,itoa((atoi(yyyy2)-1911)));
          
           
           strcat(sPrtstr3, yy2 );   sPrtstr3[19]='\0';     /*C2:�J�p��� */
           strcat(sPrtstr3, mm2 );   sPrtstr3[21]='\0'; 
           strcat(sPrtstr3, dd2 );   sPrtstr3[23]='\0'; 
           strcat(sPrtstr3, "  " );   sPrtstr3[25]='\0'; 
  
           strcat(sPrtstr3,ioth_branch); sPrtstr3[27]='\0';       /*C3:�u�߾��c */
          
           strcat(sPrtstr3, sformat_trade(&ioth_mins_stl,1,7));       /* �ߥI���B */
           sPrtstr3[34]='\0';  
          
           
printf("      sPrtstr3[%s]\n",sPrtstr3);      
         
           fprintf(fptr3,"%s\n",sPrtstr3); 
           cntrlrec++;
           
           printf("cntrlrec[%d] \n",cntrlrec );
           
        } 
        
        
           strcpy(sPrtstr3,"CNTRLREC");
           rfmtlong(cntrlrec,"&&&&&&",cntrlrec_c);
           strcat(sPrtstr3,cntrlrec_c);
           fprintf(fptr3, "%s\n", sPrtstr3);  
           cntrlrec = 0;
        
        printf ("end lApp_comp\n");
        
        $CLOSE CUS23;
        $FREE  CUS23;

     return(SUCCESS);
     
     

errexit:
     return(SQLCODE);
}




long check_if_exist( iply_type, dpolicy, fcard_class, trans_type )
$char *iply_type;
$int dpolicy;
$char *fcard_class;
$int trans_type;
{
   
   $long trade_count, err_count, out_count;
   
   printf("iply_type[%s] dpolicy[%d]\n",iply_type,dpolicy);
   printf("fcard_class[%s] trans_type[%d]\n",fcard_class,trans_type);
   
   
   $SELECT qtradevan, qerr, qout
      INTO $trade_count, $err_count, $out_count
      FROM ca_trade_exam 
     WHERE iply_type = $iply_type
       AND dpolicy = $dpolicy
       AND fcard_class = $fcard_class 
       AND itrans_type = $trans_type;
  
    if ( SQLCODE == SQLNOTFOUND )  return M_CM_OK;      
    
   printf("trade_count[%d] [%d] [%d]\n",trade_count,err_count,out_count);
   
        
   if ( trade_count==0 && err_count==0 && out_count==0 )
   {
       
       $DELETE FROM ca_trade_exam 
         WHERE iply_type = $iply_type
           AND dpolicy = $dpolicy
           AND fcard_class = $fcard_class 
           AND itrans_type = $trans_type;
           
        return M_CM_OK; 
   
   }
   
   strcpy(sqlca.sqlerrm ,"�L�k���J�s�C - �b UNIQUE INDEX ��즳���Э�");
   
   return 239;
   
errexit:
    printf("check_if_exist:sqlcode=%d, sqlmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    rc = SQLCODE;
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return rc;  
   
}
