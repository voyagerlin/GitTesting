/************************************************************************************/
/*                                                                                  */
/*      PROGRAM : ca157q01s.ec                                                      */
/*      Modify  :                                                                   */
/************************************************************************************/

#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "is_def.h"
#include "othmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "cmprint.h"
$include sqlca;
$include sqltypes;
#include <decimal.h>
#include "print.h"
#include "sqlfatal.h"
#include "safeclib.h"

$char g_sDbName[5],g_iassured[13],g_iofficer[11],g_iroute[20];
$char  g_sUserId[11],g_dply_begin[31],g_dply_begin1[31],g_dply_end[31],g_dply_end1[31];
$char ipolicy[21],sfilename[41],stitle[1000],outputf[21],sErrmsg[200],dapplicant[31];
$char iassured[13],nassured[11],itag[CA_TAG_NUM],iengine[CA_ENGINE_NUM],dply_begin[20],dply_end[20],iroute[20];
$char iofficer[11],nofficer[11],nleader[11],safe_rate[10],manage_rate[10];
$char iassured1[14],ipolicy1[22],itag1[CA_TAG_NUM],iengine1[CA_ENGINE_NUM+1],iofficer1[12],iins_type[6],pcommission[10];
$char icar_type[3],ncar_type[11],icar_type1[3];
$int  mins_premium,sunrate;
$char    stmt[3000];
char     g_sMsgBuf[1024];
long     rc;

int      count_db = 0,i;
char     sApHome[30];
DBinfo   *list;

$char stmt_tmp[1024];
       
main (argc, argv)
int argc;
char **argv;
{
    int rtc;

    batchinit();

    strcpy(g_sDbName,isNULLstr(argv[1]));
    strcpy(g_sUserId,isNULLstr(argv[2]));
    strcpy(g_iassured,isNULLstr(argv[3])); 
    strcpy(g_iofficer,isNULLstr(argv[4]));
    strcpy(g_iroute,isNULLstr(argv[5]));
    strcpy(g_dply_begin,isNULLstr(argv[6]));
    strcpy(g_dply_end,isNULLstr(argv[7]));
    strcpy(outputf,isNULLstr(argv[8]));
    
    /*�N����~�ର�褸�~*/
    strcpy(g_dply_begin1,cm_to_infdate(g_dply_begin));
    strcpy(g_dply_end1,cm_to_infdate(g_dply_end));
    
    rtc = car157_get_db();
    if (rtc != M_CM_OK) {
	EWRITE(g_sUserId,rtc,g_sMsgBuf);
	return rtc;
	}

      if ((rtc=car157_init()) != SUCCESS)
        {
           EWRITE(g_sUserId,rtc,g_sMsgBuf);
           return rtc;
        }
      if ((rtc=car157_cacul()) != SUCCESS)
        {
            EWRITE(g_sUserId, rtc, g_sMsgBuf);
            return rtc;
        }
    
      rtc=car157_dtl_rptA();
    
if (rtc != SUCCESS)
  {
        EWRITE(g_sUserId,rtc,g_sMsgBuf);
        return rtc;
  }
    
}

car157_init()
{
    $WHENEVER SQLERROR goto errexit;

    if(db_select(g_sDbName) == False)
    {
     	strcpy(g_sMsgBuf,"DB [%s] : is not opened",g_sDbName);
     	return M_CM_DB_NOTOPEN;
    }
/*
    $CREATE TEMP TABLE car157_tmp
    (
        iassured       char(13)    ,                        /*�Q�O�I�H�N��
        nassured       char(10)    ,                        /*�Q�O�I�H�W��
        ipolicy        char(21)    ,                        /*�O�渹
        icar_type      char(3)     ,                        /*���إN��
        ncar_type      char(11)    ,                        /*���ئW��
        itag           char(9)     ,                        /*����
        iengine        char(21)    ,                        /*�������X
        dply_begin     date        ,                        /*�ͮĤ�
    	dply_end       date        ,                        /*�����
    	iofficer       char(11)    ,                        /*�g��N��
    	nofficer       char(10)    ,                        /*�g��W��
    	nleader        char(10)    ,                        /*�޲z�H�W��
    	safe_rate      decimal(9,7),                        /*�w���[��O�T��
    	manage_rate    decimal(9,7),                        /*�޲z�[��O�T��
    	iins_type      char(6)     ,                        /*�I�إN��
    	sunrate        char(10)    ,                        /*�[��O�T���`�M
    	mins_premium   int         ,                        /*ñ��O�O
    	iroute         char(20)    ,                        /*�q���N��
    	pcommission    char(10)                             /*�����v
    )WITH NO LOG;
*/

    sprintf_s(stmt_tmp, sizeof stmt_tmp, "CREATE TEMP TABLE car157_tmp "
        "("
        " iassured       char(13)    , "
        " nassured       char(10)    , "
        " ipolicy        char(21)    , "
        " icar_type      char(3)     , "
        " ncar_type      char(11)    , "
        " itag           char(%d)    , "
        " iengine        char(%d)    , "
        " dply_begin     date        , "
    	" dply_end       date        , "
    	" iofficer       char(11)    , "
    	" nofficer       char(10)    , "
    	" nleader        char(10)    , "
    	" safe_rate      decimal(9,7), "
    	" manage_rate    decimal(9,7), "
    	" iins_type      char(6)     , "
    	" sunrate        char(10)    , "
    	" mins_premium   int         , "
    	" iroute         char(20)    , "
    	" pcommission    char(10)      "
        ")WITH NO LOG;",CA_TAG_NUM-1,CA_ENGINE_NUM-1);
    $PREPARE stmp FROM $stmt_tmp;
    $EXECUTE stmp;


    return SUCCESS;

errexit:
  printf("Steven:err[%ld][%s]\n",SQLCODE,sqlca.sqlerrm);
  sprintf_s(g_sMsgBuf, sizeof g_sMsgBuf, "%s",sqlca.sqlerrm);
  return SQLCODE;
}

car157_cacul()
{

    $WHENEVER SQLERROR goto errexit;
    
 for(i=0;i<count_db;i++) 
 {
    
    sprintf_s(stmt, sizeof stmt, " SELECT a.iassured , "
                        "  a.nassured , "
                        "  a.ipolicy , "
                        "  b.icar_type, "
                        "  (SELECT ncode FROM car_type e WHERE e.icode = b.icar_type AND fclass = '1') AS ncar_type, "
                        "  a.itag , "
                        "  a.iengine , "
                        "  b.dply_begin, "
                        "  b.dply_end, "
                        "  b.iofficer , "
                        "  (SELECT nname FROM officer d WHERE d.iofficer = b.iofficer) AS nofficer, "
                        "  (SELECT nname FROM officer d WHERE d.iofficer = b.ileader) AS nleader, "
                        "  c.safe_rate , "
                        "  c.manage_rate , "
                        "  c.iins_type, "
                        "  (c.safe_rate + c.manage_rate) as sunrate, "
                        "  c.mins_premium, "
                        "  a.iroute, "
                        "  c.pcommission "
                     " FROM %s:policy a, %s:ply_relation b, %s:ply_ins_type c "
                     " WHERE a.ipolicy = b.ipolicy "
                     " AND a.ipolicy = c.ipolicy "
                     " AND trim(nvl(c.provision,' '))||';' matches '*T;*' "
                     " AND a.iassured matches '%s' "
                     " AND b.iofficer matches '%s' "
                     " AND a.iroute matches '%s' "
                     " AND b.dply_begin between '%s' and '%s' ",list[i].dbname,list[i].dbname,list[i].dbname,g_iassured,g_iofficer,g_iroute,g_dply_begin1,g_dply_end1);             
                      

printf("=== 1111111 [%s] \n\n", stmt);

    $PREPARE P1 FROM $stmt;
    $DECLARE cur_1 cursor for P1;
    $OPEN cur_1;

    for(;;)
    {
	    $FETCH cur_1
	      INTO $iassured ,$nassured ,$ipolicy ,$icar_type ,$ncar_type ,$itag ,$iengine ,$dply_begin ,$dply_end ,$iofficer ,$nofficer ,$nleader ,$safe_rate ,$manage_rate ,$iins_type,$sunrate,$mins_premium,$iroute,$pcommission;
	      	           
        if (SQLCODE==SQLNOTFOUND) break;

               
              strcpy(iassured1, "�");                       /*���X�Ĥ@�X��0�A�����bexcel show �X*/
              strcat(iassured1,trim(iassured));
              
              strcpy(ipolicy1, "�");
              strcat(ipolicy1,trim(ipolicy));
              
              strcpy(icar_type1, "�");
              strcat(icar_type1,trim(icar_type));
              
              strcpy(itag1, "�");
              strcat(itag1,trim(itag));
              
              strcpy(iengine1, "�");
              strcat(iengine1,trim(iengine));
              
              strcpy(iofficer1, "�");
              strcat(iofficer1,trim(iofficer));
              
              printf("iofficer[%s]\n",iofficer1);
              /*printf("****************dcreate = %s*****************\n",dcreate);*/
	      $INSERT INTO car157_tmp
	 	 VALUES ($iassured1 ,$nassured ,$ipolicy1 ,$icar_type1 ,$ncar_type ,$itag1 ,$iengine ,$dply_begin ,$dply_end ,$iofficer1 ,$nofficer ,$nleader ,$safe_rate ,$manage_rate ,$iins_type, $sunrate,$mins_premium,$iroute,$pcommission);   /*���ӤW��car157_tmp����*/

    }
    $CLOSE cur_1;
    $FREE cur_1;
    
 }
    
    return SUCCESS;

errexit:
  printf("Steven:err[%ld][%s]\n",SQLCODE,sqlca.sqlerrm);
  sprintf_s(g_sMsgBuf, sizeof g_sMsgBuf, "%s",sqlca.sqlerrm);
  return SQLCODE;
}

car157_dtl_rptA()
{
    char tmp[30];

    strcpy(sfilename,"�ӫO����");

    memset(stmt, 0x00, sizeof(stmt));
   
    sprintf_s(stmt, sizeof stmt, " SELECT iassured ,nassured ,ipolicy ,icar_type ,ncar_type ,itag ,iengine ,dply_begin ,dply_end ,iofficer ,nofficer ,nleader ,safe_rate ,manage_rate,iins_type,sunrate,mins_premium,iroute,pcommission "
                 " FROM car157_tmp ");
                 
    sprintf_s(stitle, sizeof stitle, "�ӫO���Ӫ� \n \t�d�ߥͮĤ�϶�:%s��%s \n \t",g_dply_begin,g_dply_end);
    strcat(stitle,"�Q�O�I�H�N��\t�Q�O�I�H�W��\t�O�渹\t���إN��\t���ئW��\t����\t�������X\t�ͮĤ�\t�����\t�g��N��\t�g��W��\t�޲z�H�W��\t�w���[��O�T��\t�޲z�[��O�T��\t�I�إN��\t�[��O�T���`�M\tñ��O�O\t�q���N��\t�����v");

 
    rc = unload_file(outputf," ",sfilename,stitle,stmt);
 
    if (rc != SUCCESS)
    {
        sprintf_s(sErrmsg, sizeof sErrmsg, " %s �ɮ׵L�k���� ",sfilename);
        EWRITE(g_sUserId, rc , sErrmsg);
        exit(1);
    }

    return SUCCESS;
      
errexit:
  printf("Steven:err[%ld][%s]\n",SQLCODE,sqlca.sqlerrm);
  sprintf_s(g_sMsgBuf, sizeof g_sMsgBuf, "%s",sqlca.sqlerrm);
  return SQLCODE;
}

long car157_get_db()
{
	int rtc;

	if (db_select(g_sDbName) == False) {
		strcpy(g_sMsgBuf,"M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}
	rtc = getApHome(sApHome);
	if (rtc < 0) {
		strcpy(g_sMsgBuf,"read Config file error!!-->getApHome\n");
		return rtc;
  }
  
  if ((list = get_db_list (&count_db, g_sDbName)) == (char *) 0) {
       if (EWRITE(g_sUserId, M_CM_NOT_DBLIST) == TRUE)
          return M_CM_NOT_DBLIST;
  }

  return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(g_sUserId,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}