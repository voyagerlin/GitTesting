/************************************************************************************/
/*                                                                                  */
/*      PROGRAM : ca657q01s.ec                                                      */
/*      Modify  :                                                                   */
/************************************************************************************/

#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "is_def.h"
#include "othmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "cmprint.h"
$include sqlca;
$include sqltypes;
#include <decimal.h>
#include "print.h"
#include "sqlfatal.h"
#include <stdio.h>
#include <stdlib.h>
#include "sql.h"
#include "api_xsrv.h"
#include "safeclib.h"
$char g_sDbName[5];
$char g_sUserId[11];
$char sfilename[41],stitle[1000],outputf[21],sErrmsg[200];

$char ipolicy[21], dpolicy[21], icard[21], iproduct[21], iendorse[21], dendorse[21], ded_business[2];
$char dpolicy1[21],dpolicy2[21],plyrel_DB[21];
$char ipolicy_tmp[21],dpolicy_tmp[21];
$double mbusiness;
$long ichk_dpolicy=0;

$char    stmt[3000];
char     g_sMsgBuf[1024];
long     rc;

int      count_db,i;
DBinfo   *list;


main (argc, argv)
int argc;
char **argv;
{
    int rtc;

    batchinit();

    strcpy(g_sDbName,isNULLstr(argv[1]));
    strcpy(g_sUserId,isNULLstr(argv[2]));
    strcpy(dpolicy1,isNULLstr(argv[3]));
    strcpy(dpolicy2,isNULLstr(argv[4]));
    strcpy(outputf,isNULLstr(argv[5]));

    strcpy(dpolicy1,cm_to_infdate(dpolicy1));
	strcpy(dpolicy2,cm_to_infdate(dpolicy2));

	printf("dpolicy1[%s]\n",dpolicy1);
	printf("dpolicy2[%s]\n",dpolicy2);

      if ((rtc=car657_init()) != SUCCESS)
        {
           EWRITE(g_sUserId,rtc,g_sMsgBuf);
           return rtc;
        }
      if ((rtc=car657_cacul()) != SUCCESS)
        {
            EWRITE(g_sUserId, rtc, g_sMsgBuf);
            return rtc;
        }

      rtc=car657_dtl_rptA();

if (rtc != SUCCESS)
  {
        EWRITE(g_sUserId,rtc,g_sMsgBuf);
        return rtc;
  }

}

car657_init()
{
    $WHENEVER SQLERROR goto errexit;

    if(db_select(g_sDbName) == False)
    {
     	strcpy(g_sMsgBuf,"DB [%s] : is not opened",g_sDbName);
     	return M_CM_DB_NOTOPEN;
    }

    $CREATE TEMP TABLE car657_tmp
    (
        ipolicy         char(21)     ,
        dpolicy         char(21)     ,
        icard		    char(21)     ,
        iendorse        char(21)     ,
        dendorse        char(21)     ,
    	mbusiness       decimal(9,4) ,
    	iproduct        char(20)      ,
        ded_business    char(2)
    )WITH NO LOG;

    return SUCCESS;

errexit:
  printf("Steven:err[%ld][%s]\n",SQLCODE,sqlca.sqlerrm);
  sprintf_s(g_sMsgBuf, sizeof g_sMsgBuf,"%s",sqlca.sqlerrm);
  return SQLCODE;
}

car657_cacul()
{
    int     k;
	$char   stmp[4096],stmt1[4096], stmt2[4096];

	$WHENEVER SQLERROR GOTO errexit;

	if ( (list=get_db_list(&count_db,g_sDbName)) == (char*)0 )
	{
		printf("174\n");
		EWRITE(g_sUserId, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
		return M_CM_NOT_DBLIST;
	}
	
	for(k=0;k<count_db;k++) /* �O�� */
	{
		printf("181\n");

		sprintf_s(stmt1, sizeof stmt1,
		"insert into car657_tmp  "
		"select a.ipolicy,a.dpolicy,a.icard,'','',mbusiness, "
		      "CASE WHEN a.icar_type IN ('01','02','32','34') AND a.qply_period <= 12 THEN '16_�����@�~��'   "
		      "     WHEN a.icar_type IN ('01','02','32','34') AND a.qply_period > 12 THEN '16_������~��'  "
		      "     WHEN a.icar_type = '35' AND a.qply_period <= 12 THEN '32_�L�q���@�~��'  "
		      "     WHEN a.icar_type = '35' AND a.qply_period > 12 AND a.qply_period <= 24 THEN '32_�L�q���G�~��'  "
		      "     WHEN a.icar_type = '35' AND a.qply_period > 24 AND a.qply_period <= 36 THEN '32_�L�q���T�~��'  "
		      "     WHEN a.icar_type = '35' AND a.qply_period > 36 AND a.qply_period <= 48 THEN '32_�L�q���|�~��'  "
		      "     WHEN a.icar_type = '35' AND a.qply_period > 48 THEN '32_�L�q�����~��'  "
	          "     ELSE b.iproduct[4,5]||'_�T��' END AS iproduct,''  "
		"from %s:ori_ply_relation a,%s:ori_ins_type b  "
		"WHERE a.dpolicy BETWEEN ? AND ?  "
		"AND a.ipolicy = b.ipolicy  "
		"AND fcard_class = '1'",
		list[k].dbname,list[k].dbname,list[k].dbname);
		printf("stmt[%s] \n",stmt1);

		$PREPARE pre FROM $stmt1;
		$EXECUTE pre USING $dpolicy1, $dpolicy2;
	}

	printf("145\n");

    for(k=0;k<count_db;k++) /* ��� */
    {
    	sprintf_s(stmt2, sizeof stmt2,
        		"select r.ipolicy,a.dpolicy,r.icard,i.iendorse,r.dendorse,r.medr_business,  "
        		"CASE WHEN r.icar_type IN ('01','02','32','34') AND e.qply_period <= 12 THEN '16_�����@�~��'  "
        		"     WHEN r.icar_type IN ('01','02','32','34') AND e.qply_period > 12 THEN '16_������~��'  "
        		"     WHEN r.icar_type = '35' AND e.qply_period <= 12 THEN '32_�L�q���@�~��'  "
        		"     WHEN r.icar_type = '35' AND e.qply_period > 12 AND e.qply_period <= 24 THEN '32_�L�q���G�~��'  "
        		"     WHEN r.icar_type = '35' AND e.qply_period > 24 AND e.qply_period <= 36 THEN '32_�L�q���T�~��'  "
        		"     WHEN r.icar_type = '35' AND e.qply_period > 36 AND e.qply_period <= 48 THEN '32_�L�q���|�~��'  "
        		"     WHEN r.icar_type = '35' AND e.qply_period > 48 THEN '32_�L�q�����~��'  "
        		"     ELSE i.iproduct[4,5]||'_�T��' END AS iproduct,  "
        		"CASE WHEN e.ded_business = '1' THEN 'Y' ELSE 'N' END AS ded_business  "
        		"from %s:edr_relation r,%s:edr_ins_type i,%s:endorsement e,%s:ori_ply_relation a  "
        		"where r.fcard_class = '1'  "
        		"and r.iendorse[6,8] != 'CVP'  "
        		"and r.dendorse BETWEEN '%s' AND '%s'  "
        		"and i.iendorse = r.iendorse  "
        		"and iedr_type IN ('01','02','03')  "
        		"and r.ipolicy = a.ipolicy  "
        		"and i.iendorse = e.iendorse",
        		list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,dpolicy1,dpolicy2);
    	printf("stmt2[%s]\n", stmt2);

    	$PREPARE P1 FROM $stmt2;
    	$DECLARE cur_1 cursor for P1;
    	$OPEN cur_1;

	    for(;;)
	    {
		    $FETCH cur_1
		      INTO $ipolicy,$dpolicy,$icard,$iendorse,$dendorse,$mbusiness,$iproduct,$ded_business;
		      	           
	        if (SQLCODE==SQLNOTFOUND) break;
			
	    	strcpy(plyrel_DB, get_car_full_db(ipolicy));
	
			sprintf_s(stmp, sizeof stmp,"SELECT count(*)  "
		                 "  FROM %s:ori_ply_relation  "
		                 " WHERE dpolicy >= '04/01/2021'  "
		                 "   AND ipolicy = '%s'",
		                     plyrel_DB,ipolicy);
	
			$PREPARE ply_dpolicy_tmp FROM $stmp;
			$EXECUTE ply_dpolicy_tmp INTO $ichk_dpolicy;
	
	    	if(ichk_dpolicy >= 0)
	    	{
	     		$INSERT INTO car657_tmp
	 	  		 VALUES ($ipolicy,$dpolicy,$icard,$iendorse,$dendorse,$mbusiness,$iproduct,$ded_business);   /*���ӤW��car657_tmp����*/
	    	}
	
	    }
    	$CLOSE cur_1;
    	$FREE cur_1;
	}

	printf("163\n");
	return SUCCESS;

	errexit:
	printf("234\n");
	sqlfatal();
	EWRITE(g_sUserId,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}

car657_dtl_rptA()
{
    char tmp[30];

    strcpy(sfilename,"�j��~�ȶO��30��/�󴣼��έp�{�� ");

    memset(stmt, 0x00, sizeof(stmt));

    sprintf_s(stmt, sizeof stmt," SELECT * FROM car657_tmp ");

    sprintf_s(stitle, sizeof stitle,"�j��~�ȶO��30��/�󴣼��έp�{�� \n \t ");
    strcat(stitle,"�O�渹�X\t�O��ñ���\t�O�I��/�d��\t��渹�X\t���ñ���\t�~�ȶO��(��)\t�I�O\t�O�_���j��h�O�����~�ȶO��\t");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);

    if (rc != SUCCESS)
    {
        sprintf_s(sErrmsg, sizeof sErrmsg," %s �ɮ׵L�k���� ",sfilename);
        printf("-----IN");
        EWRITE(g_sUserId, rc , sErrmsg);
        exit(1);
    }

    return SUCCESS;

errexit:
  printf("Steven:err[%ld][%s]\n",SQLCODE,sqlca.sqlerrm);
  sprintf_s(g_sMsgBuf, sizeof g_sMsgBuf,"%s",sqlca.sqlerrm);
  return SQLCODE;
}