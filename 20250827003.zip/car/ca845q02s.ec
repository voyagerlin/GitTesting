#include <stdio.h>
#include <stdlib.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"

#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"

$include decimal;
char delimiter;
int count_db,k;
char  outputf[21];
$char userid[11];
$char DBName[05];
char   sApHome[50];
char    msgbuf[1000];

static char  *bp;
long   rtncode;
int rc;
DBinfo *list;

char    sfilename[128],stitle[2048];

main(argc, argv)
int argc;
char **argv;
{

    batchinit();
    strcpy(DBName,    isNULLstr(argv[1]));
    strcpy(userid,    isNULLstr(argv[2]));
    strcpy(outputf,   isNULLstr(argv[3])); /*�T�w���̫�@�ӰѼ�*/

    rc = car8452_get_db();
    if (rc != M_CM_OK) {
        printf("error on car8452_get_db\n");
        EWRITE(userid, rc, "error on car8452_get_db");
        return rc;
    }

    rc = car8452_init_data();
    if (rc != M_CM_OK) {
        printf("error on car8452_init_data\n");
        EWRITE(userid, rc, "error on car8452_init_data");
        return rc;
    }

    rc = car8452_prepare();
	if (rc != M_CM_OK) {
        printf("error on car8452_prepare\n");
        EWRITE(userid, rc, "error on car8452_prepare");
        return rc;
    }

    rc = car8452_print();
    if (rc != M_CM_OK) {
        printf("error on car8452_print\n");
        EWRITE(userid, rc, "error on car8452_print");
        return rc;
    }

    return rc;
}


/*--------------------------------------------------------------------*/
long car8452_get_db()
{
    int	rc;

    if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
    }

    if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
    {
        EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
        return M_CM_NOT_DBLIST;
    }

    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }

    return M_CM_OK;
}

/* ------------------------------------------------------------------------- */
long car8452_init_data()
{
    $whenever sqlerror goto errexit;
    $char stmp2[25];

    $create temp table temp1
    (
        adjustment     char(10),
        nadjustment    char(20),
        nquota         char(60),
        iclaim         char(20),
        iins_type      char(100)
    )with no log;

    $select first 1 current into $stmp2
       from officer where 1=1;

    strcpy(sfilename,"�Y�ɥ��M�έp����");
    sprintf_s(stitle,2048, " \t CAR845�Y�ɥ��M���Ӫ� \t  %s \t \n",stmp2);
    strcat(stitle,"\t �z�ߤH�����s\t�z�ߤH���m�W\t�z�ߤH�����\t�߮׸��X\t�I��\t");

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* -------------------------------------------------------------------------- */
/* ���M��� */
long car8452_prepare()
{
    int     rc, i;
    $char   stmt1[2000];
    $int icnt1 ;

    $WHENEVER SQLERROR GOTO errexit;

    /* SQL���� chr(127), �i�H�b��EXCEL����0�������,���|���@�Ů�,�p���s�ɻݨD, ���V�ΡC
    add by sylvia 109.8.7)
     */

    for (i=0; i<count_db; i++)
    {
        sprintf_s(stmt1,2000,
            "insert into temp1 \
             SELECT chr(127)||adjustment, nname, nbranch, a.iclaim,  \
                    case when a.fclaim_status = 101 then '���w��' else \
		            CASE WHEN fcard_class = '1' THEN  chr(127)||'21'  else \
                    case when (select count(*) from %s:app_ins_type f \
                                where f.iclaim = a.iclaim and f.fclose = '0' ) = 0 then '���w��' else \
                    chr(127)||replace(replace(replace(replace(replace( multiset \
                            (select trim(iins_type) from %s:app_ins_type e \
                              where e.iclaim = a.iclaim and e.fclose = '0' )::lvarchar, \
                            'MULTISET',''),'{',''),'}',''),'ROW(''',''),''')','') end end end  AS iins_type \
               FROM ca_clm_process a, officer b, sa_branch_type c, %s:appraisal d \
              WHERE a.adjustment = b.iofficer \
                AND b.iquota = c.ibranch \
                AND a.iclaim = d.iclaim \
                AND a.fsystem = 'N' \
                AND a.fclaim_status < 501 ", list[i].dbname,list[i].dbname,list[i].dbname);
        printf("stmt1=[%s]\n",stmt1);
        $prepare pre_get1 from $stmt1;
        $execute pre_get1;
    }

    icnt1 = 0;

    $select count(*) into $icnt1
       from temp1
      where 1=1;

    if (icnt1 == 0)
    {
        $insert into temp1 (adjustment) values ('�d�L���!!');
    }

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}

/* -------------------------------------------------------------------------- */
long car8452_print()
{
    int     rc;
    char    stmt[200];


    $WHENEVER SQLERROR GOTO errexit;

    strcpy(stmt,"select * from temp1 where 1=1 ORDER BY 3 ");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);

    if (rc != SUCCESS) {
        sprintf_s(msgbuf,1000," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}