/**********************************************************************/
/*   program id   : ca546q01s.ec                                      */
/*   program name : ���T�O������                                      */
/*   date written : 11/17/2023                                        */
/*   date modify  : yyyy/mm/dd                                        */
/**********************************************************************/
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
#include "safeclib.h"

#define TRUE 1
#define FALSE 0

$char outputf[21];
$char DBName[5];
$char DBName1[5];
$char userid[11], begin_day[11], end_day[11];
char status[2];

int ipflag;
$char  errMsg[30000], errMsg2[200];
$long icount;
long rc;
long   rtncode;
$char sStmt[2048];
$char errMsg1[30000];
$char  stmp[30000];
$char isign_tmp[8];
$char sItransno[13];
long split_policy();



main(argc, argv)
int argc;
char **argv;
{
    long rc;

    batchinit();
    strcpy(DBName       ,isNULLstr(argv[1]));
    strcpy(userid       ,isNULLstr(argv[2]));
    strcpy(status       ,isNULLstr(argv[3]));   /*1:���z����T�O�Ω��Ӫ� 2:�z����J�@�~ 3:���T�O�γ���*/
    strcpy(begin_day    ,isNULLstr(argv[4]));   /*�_�l�ɶ�*/
    strcpy(end_day      ,isNULLstr(argv[5]));   /*�����ɶ�*/
    strcpy(outputf      ,isNULLstr(argv[6]));
	
	printf("���������� GOGO\n");


    if (db_select(DBName) == False)
    {
        EWRITE(userid,M_CM_DB_NOTOPEN,"M_CM_DB_NOTOPEN");
        return 0;
    }
	switch(status[0])
	{
	    case '1':
    	    rc = car546_1();
    	    break;
	    case '2':
    	    rc = car546_2();
    	    break;
	    case '3':
    	    rc = car546_3();
    	    break;
	}
	
	
	$WHENEVER SQLERROR CONTINUE;     /* reset error handling */
	if (rc != M_CM_OK)
	{
		printf("[���T�O�βz����J�@�~  ���楢��]\n");
		strcpy(stmp,"car546_2 ���楢��, ���~��Ʀp�U, �нT�{�íץ���A���s����!! \n\n");
		strcat(stmp,errMsg);
		EWRITE(userid,rc,stmp);
		return rc;
	}


	return M_CM_OK;
}

/* ���z����T�O�Ω��Ӫ� */
long car546_1()
{	
	printf("���������� car546_1\n");
	long rc;

    $char iclaim[21],iins_type[7],itag[13],ifactory[21],fpay_kind[2];
	$int iclose_type = 0,mprocess = 0,iclose_type_2;
	$date dgroup;
		
	
	$char  stmt[1000],stmt_DBName[4096];
    $char sFullName[25];
    $char begin[11], end[11];
	$int icnt = 0;

	/* 1 */
	$CREATE TEMP table car546_temp
    (
        iclaim            char(20),			-- �߮׸�
        iclose_type       int,     			-- �߰l����
        iins_type         char(6),    		-- �I�إN��
        itag              char(12),   		-- �ɮ֨���
        ifactory          char(20),   		-- ���ӥN��
        nfactory          char(100),    	-- �O�׼t�W��		
		
        tcode_remark      char(20),     	-- �O�����O (�qcu_code_data���줤��W��)
        mprocess          int,        		-- �O��
		iupdate			  char(10),			-- ���ɤH��
		dupdate			  date,				-- ���ɤ��
		dclose			  date,				-- �鵲��		
        dgroup            date       		-- �J�p���
    )with no log;
	
	
    /* �J�p����_�W�ɶ� */
     strcpy(begin,cm_to_infdate(begin_day));
     strcpy(end,cm_to_infdate(end_day));
	 
	printf("���������� begin=[%s]end=[%s]\n",begin,end);
     
    /* ���Ҧ���DBNAME */
	sprintf_s(stmt_DBName,4096,
	" select dbname  \
	    from servertbl  \
	   where branch != 'S1'  \
	   ORDER BY branch ");
	
	$PREPARE serverdtl FROM $stmt_DBName;
    $DECLARE status1_server_cur CURSOR FOR serverdtl ;
    $OPEN status1_server_cur;
    for(;;)
    {
        $FETCH status1_server_cur INTO $sFullName;
		
        if (SQLCODE == SQLNOTFOUND) break;
	printf("���������� sFullName=[%s]\n",sFullName);
        
        /* ��UDB�� �������z�⪺��� */
        sprintf_s(stmt,4096,
    	" insert into car546_temp \
		  select a.iclaim,a.iclose_type,a.iins_type,b.itag,b.ifactory,   \
				 CASE WHEN c.dexpire <= CURRENT THEN '(�w����)'||c.nfactory ELSE c.nfactory END,   \
    	         d.tcode_remark,b.mprocess,'','','',a.dgroup \
    	    from %s:stl_ins_type a, %s:ca_viewer_pay b, ca_factory c,(SELECT * FROM cu_code_data WHERE itype = 'G6') d  \
    	   where a.iclaim = b.iclaim  \
    	     and a.fstl = b.fstl  \
    	     and a.iclose_type = b.iclose_type  \
    	     and a.iins_type = b.iins_type  \
			 and b.ifactory = c.ifactory  \
			 and b.fpay_kind = d.icode  \
    	     and b.iclose_type_2 = 0 \
    	     and a.dgroup >= ?  \
    	     and a.dgroup <= ? \
			 order by a.iclaim,a.iclose_type" , sFullName, sFullName);
    	     
    	$PREPARE tb546 FROM $stmt;
		$execute tb546 USING :begin, :end ;			
        
        /* ��UDB�� �����n�B�z�����(End) */  

	}
	$CLOSE status1_server_cur;
	$FREE  status1_server_cur;
	
	
	$select count(*) into $icnt
	  from car546_temp
	 where 1=1; 
	 
	
    if (icnt == 0)
    {
        EWRITE(userid, M_CM_NOT_FOUND, "�϶������T�O�άҤw�z�⧹��!! \n");
        return FAIL;
    } 
	
	rc = car546_build();

		return rc;
		
	
errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
	   
	   
	   
}

/* �z����J�@�~ */
long car546_2()
{	
    $char stmt[4096],stmt_DBName[4096], stmt_errlog[30000];
    $char sFullName[25],begin[11], end[11];
    
    $char iclaim[21],fstl[2],iins_type[7],itag[13],ifactory[21],fpay_kind[2],dgroup[31];
	$int iclose_type = 0,mprocess,iclose_type_2;
	
	$char ipolicy[21],iadjuster[11], sYN[2], iportfolio[11],igroup_profit[21],
	      sMsg[200], nnote_claim[100];
    $char sIpolicy1[POLICY_NUM_1] , sIpolicy2[POLICY_NUM_2];
	
	int icnt_err = 0, icnt1, icnt = 0;
	$int  iclose_type_tmp = 0;
    $int  iclose_type_last;
    $char dclose_tmp[15]; 	
	
    $int id1 = 0;
	
    $char iverify[21];
    $char icard[21];
    $int  iself_duty, ioth_duty, ianoth_duty;

    $int  tmp_cnt;
	$char fassured[2], nfactory[101],ifpce_id[11],nchi_full[101],npayment[101], fsettle_type[2],ibank[8],iaccount[15],
		�@afactory[101],izip[7],iemail[51], itel[21], imobile[21], flast[2],isign[21], fspeed[2],
		  ffactory_type[3],fmodel_type[3],ncontact[101],ifax[21],isettle_type[2];	
	
	$int  qserial;
	$char iclm_upcomp[3];
    char  sIunit[6], sIbranch_in[BRANCH_ID];
	$char itransno_tmp[11],iseq_tmp[3];

    $CREATE TEMP table car546_temp
    (
        iclaim            char(20),   -- �߮׸�
        fstl              char(1),    -- �߮שʽ�
        iclose_type       int,        -- �߰l����
        iins_type         char(6),    -- �I�إN��
        itag              char(12),   -- ���P���X
        ifactory          char(20),   -- ���ӥN��
        fpay_kind         char(1),    -- �O�����O
        mprocess          int,        -- �O��
        iclose_type_2     int,        -- �߰l����2 �z����J��^�g
		dbname            char(25)    -- daname
		
    )with no log;
    $create unique index car546_temp_dx1 on car546_temp(iclaim, fstl, iclose_type, iins_type, itag, ifactory, fpay_kind);
    
    $CREATE TEMP table car546_errlog
    (
        iclaim     char(20),
        errmsg     char(300)
    )with no log;
	
	$CREATE TEMP table car546_Adding_temp
    (
        iclaim            char(20)   -- �߮׸�
    )with no log;    
	
    /* �J�p����_�W�ɶ� */
	strcpy(begin,cm_to_infdate(begin_day));
	strcpy(end,cm_to_infdate(end_day));
	      
	/* �ˮ֤��L�ɡA�ϥΥH�USQL�y�k */
	sprintf_s(stmt_errlog, 30000, "insert into car546_errlog(iclaim, errmsg) values (?, ?)");
	$prepare insert_errlog from $stmt_errlog;
    
    /* ���Ҧ���DBNAME */
	sprintf_s(stmt_DBName,4096,
	" select dbname  \
	    from servertbl  \
	   where branch != 'S1'  \
	   ORDER BY branch ");
	
	$PREPARE serverdtl FROM $stmt_DBName;
    $DECLARE server_cur CURSOR FOR serverdtl ;
    $OPEN server_cur;
    for(;;)
    {
        $FETCH server_cur INTO $sFullName;
        if (SQLCODE == SQLNOTFOUND) break;		
        
        /* ��UDB�� �����n�B�z����� */
        sprintf_s(stmt,4096,
    	" select a.iclaim,a.fstl,a.iclose_type,a.iins_type,  \
    	         b.itag,b.ifactory,b.fpay_kind,b.mprocess,b.iclose_type_2  \
    	    from %s:stl_ins_type a, %s:ca_viewer_pay b  \
    	   where a.iclaim = b.iclaim  \
    	     and a.fstl = b.fstl  \
    	     and a.iclose_type = b.iclose_type  \
    	     and a.iins_type = b.iins_type  \
    	     and iclose_type_2 = 0 \
    	     and a.dgroup >= ?  \
    	     and a.dgroup <= ? " , sFullName, sFullName);
    	$PREPARE paydtl FROM $stmt;
        $DECLARE pay_cur CURSOR FOR paydtl ;
        $OPEN pay_cur USING :begin, :end ;
        for(;;)
        {	
            $FETCH pay_cur INTO $iclaim, $fstl, $iclose_type, $iins_type,
                                $itag, $ifactory, $fpay_kind, $mprocess, $iclose_type_2;
            if (SQLCODE == SQLNOTFOUND) break;
			
			ipflag = 0;
			            
            /* �ˮ֬O�_�w���w�����(���B�D�n�Ψӧ�ipolicy) */
            $select ipolicy
               into $ipolicy
               from ca_clm_process
              where iclaim = $iclaim;
        
            if (SQLCODE == SQLNOTFOUND)
            {	
               sprintf_s(errMsg,30000,"�߮׸�:[%s]\t�bca_clm_process �߮׬y�{�ɸ�Ƨ䤣�� \n",iclaim);
        	   $execute insert_errlog
        		  using $iclaim, $errMsg;
               ipflag = 1;
               icnt_err ++;
            }
            else
            {  
                /* �ˮ֫e�@���z��Y���鵲�A���o���U�@�����z�� */
                sprintf_s(stmt,4096,
                " select first 1 iclose_type, dclose      \
                    from %s:settlement                    \
                   where iclaim = ?                       \
                   order by iclose_type desc ", sFullName);
                
                $prepare get_last_dclose from $stmt;
                $execute get_last_dclose
                    into $iclose_type_tmp, $dclose_tmp:id1
                   using $iclaim;  
				   
				   
                /* if (id1 < 0) */
                if ((SQLCODE != SQLNOTFOUND) && (id1 < 0))
                {
                   sprintf_s(errMsg,30000, "A�߮׸�:[%s]\t�e�@���z��|���鵲�A�e�@���z�ߦ���[%d] \n", iclaim, iclose_type_tmp);
                   /*$insert into car546_errlog(iclaim, errmsg) values ($iclaim, $errMsg);*/
        		   $execute insert_errlog
        			  using $iclaim, $errMsg;
                   ipflag = 1;
                   icnt_err ++;
printf("iclaim:[%s]\n ipflag:[%d]\n ", iclaim, ipflag);
                }
                /* �ƥ��ˮ�(end) -------------------------------------------------- */

                if (ipflag == 0)
                {	
                    /* �N����J����Ƽg�Jcar546_temp */
                    $INSERT INTO car546_temp
                      VALUES ($iclaim, $fstl, $iclose_type, $iins_type,
                              $itag, $ifactory, $fpay_kind, $mprocess, $iclose_type_2,$sFullName);							  
                    /* �N����J����Ƽg�Jcar546_temp(end) */
					
					icnt++;
                    if (SQLCODE != 0)
                    {
                        sprintf_s(errMsg,30000, "�߮׸�:[%s]\t SQLCODE=[%d] [%s ] \n", iclaim,SQLCODE,sqlca.sqlerrm);
                        /*$insert into car546_errlog(iclaim, errmsg) values ($iclaim, $errMsg);*/
                        $execute insert_errlog
                        using $iclaim, $errMsg;
                        ipflag = 1;
                        icnt_err ++;
                    }
                }
            }		
        }
        $CLOSE pay_cur;
        $FREE  pay_cur;
        /* ��UDB�� �����n�B�z�����(End) */ 		
	}
	$CLOSE server_cur;
	$FREE  server_cur;
		
	int tmp_iline = 0;
    printf("icnt_err=[%d]\n",icnt_err);
    EXEC SQL WHENEVER SQLERROR GOTO errexit;
    if (icnt_err > 0)
    {
        strcpy(errMsg2,"");
        strcpy(errMsg,"");
		
        $DECLARE get_errlog CURSOR FOR
          SELECT DISTINCT errmsg INTO $errMsg2 FROM car546_errlog where 1=1;

        $OPEN get_errlog;
        for(;;)
        {
            $FETCH get_errlog;
			
            if (SQLCODE == SQLNOTFOUND) break;
			tmp_iline++;
			if (tmp_iline > 450) break;
            strcat(errMsg,trim(errMsg2));
			if (tmp_iline == 450) strcat(errMsg,"�]���~�T���W�L450���A�H�U�ٲ�����ܡA�Хt�~�d�߿��~��]�I�I\n");
        }
        $CLOSE get_errlog;
        $FREE get_errlog;
    
        printf("errMsg[%s]\n",errMsg);
		EWRITE(userid, M_CM_NOT_FOUND, errMsg);

        return FAIL;
    }
	
    if (icnt == 0)
    {
        EWRITE(userid, M_CM_NOT_FOUND, "�϶����L��ƥi��!! \n");
        return FAIL;
    } 
	
	/* ����ˮ֥��`�L�~, �}�l�g�J��Ʈw */
	EXEC SQL WHENEVER SQLERROR GOTO errexit;

	$BEGIN WORK;	
	
	icount=0;
	ipflag = 0;
	
	$select first 1 'A'||to_char(today ,'%y%m%d')
	   into $isign_tmp
	   from car_code;
	
	/* ���̷s����Ǹ� */	
	$select first 1 to_char(CURRENT ,'%y%m%d%H%M')
	   into $itransno_tmp
	   from car_code;
	   
	strcpy(itransno_tmp, trim(itransno_tmp));
	strcpy(sItransno, trim(itransno_tmp));
	
	strcat(itransno_tmp,"%");		
	
	/* itransno */
	sprintf_s(stmt,4096,
	" select first 1 LPAD(CAST(RIGHT(itransno,2) + 1 AS INT),2,'0')      \
		from \
		(select itransno from newa00:ca_viewer_pay \
				  union all \
				  select itransno from newa22:ca_viewer_pay \
				  union all \
				  select itransno from newa33:ca_viewer_pay \
				  union all \
				  select itransno from newa40:ca_viewer_pay \
				  union all \
				  select itransno from newa66:ca_viewer_pay \
				  union all \
				  select itransno from newa70:ca_viewer_pay )  \
	   where itransno like '%s' \
	   order by itransno desc ", itransno_tmp);
	printf("stmt[%s]\n",stmt);
	$prepare get_itransno from $stmt;
	$execute get_itransno
		into $iseq_tmp;
					
	if (SQLCODE == SQLNOTFOUND)
	{
	   strcat(sItransno,"01");			   
	}
	else
	{			
		strcpy(iseq_tmp, trim(iseq_tmp));
		strcat(sItransno,iseq_tmp);	
	}			
	
printf("-- 817 sItransno=[%s]\n",sItransno);
	
	/* ��z�n�B�z����� ����key�� */		
	$DECLARE key_cur CURSOR FOR
	  SELECT DISTINCT iclaim, fstl, iclose_type,dbname FROM car546_temp where 1=1 order by iclaim, fstl, iclose_type;
	$OPEN key_cur;	
	
	for(;;)
	{
		$FETCH key_cur INTO $iclaim, $fstl, $iclose_type,$sFullName;
		if (SQLCODE == SQLNOTFOUND) break;	
		
sprintf_s(errMsg,30000," iclaim=%s\t fstl=%s\t  iclose_type=%s\t   dbname=%s\n", iclaim,fstl,iclose_type,sFullName);		
EWRITE(userid,M_CM_OK, errMsg);
	
		ipflag = 0;
		icount++;					
		
		/* ���O�渹�X */
		sprintf_s(stmt,4096,
		" select ipolicy, adjustment \
			from ca_clm_process \
		   where iclaim = ? ");
		$prepare get_base_info from $stmt;
		$execute get_base_info
			into $ipolicy, $iadjuster
		   using $iclaim;
		if (SQLCODE == SQLNOTFOUND)
		{
		   strcpy(errMsg,"ca_clm_process �߮׬y�{�ɸ�Ƨ䤣�� ");
		   goto errexit;
		}	
		
		$select iupcomp
		   into $iclm_upcomp
		   from branch
		  where ibranch = (select iapp_unit from cm_clm_adjuster where empl_no = $iadjuster);
		if (SQLCODE == SQLNOTFOUND)
		{
			sprintf_s(errMsg,30000," branch �L�k���z�ߤW�h�����q�N���A�z�߭����s[%s] ", iadjuster);
			goto errexit;
		}

		if ((rtncode = split_policy(ipolicy, sIpolicy1, sIpolicy2)) != M_CM_OK)
		{
		   sprintf_s(errMsg,30000, "�O�渹�X[%s]�������O�渹�X�@�B�O�渹�X�G���~ ", ipolicy);
		   goto errexit;
		}
		
		/* �����N�O�q������DB����ƥX�� �ҥH���ΦA���T�{DBName */
		/*rtncode = cm_get_unit_in(sIpolicy1, DBName,  " ", sIunit,"C3",DBName1,
								 sIbranch_in);
		if(rtncode != M_CM_OK)
		{
		   sprintf_s(errMsg,30000, "cm_get_unit_in ���o�O���즳�~�A�O�渹�X�G[%s] ",ipolicy);
		   goto errexit;
		}*/

		/*** �ˮ֫e�@���z��Y���鵲�A���o���U�@�����z�� ***/
		sprintf_s(stmt,4096,
		" select first 1 iclose_type, dclose      \
			from %s:settlement                    \
		   where iclaim = ?                       \
		   order by iclose_type desc ", sFullName);

		$prepare get_last_dclose from $stmt;
		$execute get_last_dclose
			into $iclose_type_tmp, $dclose_tmp:id1
		   using $iclaim;			
	

		if ((SQLCODE != SQLNOTFOUND) && (id1 < 0))
		{		
			/* ��car546_Adding_temp�T�{�O�_�O�����@�~��s�W�� */
			$select unique iclaim
				from car546_Adding_temp
				where iclaim = $iclaim;
				
			if (SQLCODE == SQLNOTFOUND)
			{
				sprintf_s(errMsg,30000, "B�߮׸�:[%s]\t�e�@���z��|���鵲�A�e�@���z�ߦ���[%d] ", iclaim, iclose_type_tmp);
				goto errexit;
			}
		}

		iclose_type_last = iclose_type_tmp;

		if (SQLCODE == SQLNOTFOUND)
		{
		   iclose_type_tmp = 1;
		}
		else
		{
		   iclose_type_tmp += 1;
		}
		
		/* ����iverify */
		$select iverify
			into $iverify
			from ca_ver_relation
		   where iclaim = $iclaim;
		if (SQLCODE == SQLNOTFOUND) strcpy(iverify, iclaim);
		
		/* ���T�O�Υu�A�� ���N�I ���|����y������ �ҥH�]���ݭn�h���h�s�W */
		/**** �g�J�p��ѹ�y������ ****/
		/*sprintf_s(stmt,4096,
		" select * from %s:stl_oth_dtl where iclaim = ? and fstl = '1' and iclose_type = ?     \
			into temp stl_oth_tmp1 with no log ",sFullName);


		$prepare get_stl_oth from $stmt;
		$execute get_stl_oth
		   using $iclaim, $iclose_type_last;

		sprintf_s(stmt,4096,
		" update stl_oth_tmp1                       \
			 set iclose_type = iclose_type + 1      \
		   where iclaim = ? ");

		printf("stmt[%s]\n",stmt);

		$prepare upd_stl_oth from $stmt;
		$execute upd_stl_oth
		   using $iclaim;

		if (sqlca.sqlerrd[2] > 0)
		{
		   sprintf_s(stmt,4096,
			" insert into %s:stl_oth_dtl            \
			   select * from stl_oth_tmp1 ",sFullName);

		   printf("stmt[%s]\n",stmt);

		   $prepare ins_stl_oth from $stmt;
		   $execute ins_stl_oth;
		}
		$drop table stl_oth_tmp1;*/
		

		/****  �g�J�p�����  ****/	

		sprintf_s(stmt,4096,
		" select icard             \
			from %s:ply_relation   \
		   where ipolicy = ? ",sFullName);
		printf("stmt[%s]\n",stmt);
		$prepare get_icard from $stmt;
		$execute get_icard
			into $icard
		   using $ipolicy;

		printf("icard[%s]ipolicy=[%s]\n iclaim=[%s]\n",icard,ipolicy,iclaim);
		if (SQLCODE == SQLNOTFOUND)
		{
		   sprintf_s(errMsg,30000, "ply_relation �̷s�O���ɸ�Ƥ��s�b�A�O�渹�X�G[%s] ",ipolicy);
		   goto errexit;
		}	
		
		iself_duty = 0;
		ioth_duty  = 0;
		ianoth_duty = 0;

		/* ���� */
		$select  nvl(max(qduty_adjuster),0) into $iself_duty
		   from ca_clm_victim_data
		  where iclaim = $iverify
			and fvictim_car = 'F';
printf("iself_duty[%d]iverify=[%s]\n",iself_duty,iverify);

		/* ��訮 */
		$select  nvl(max(qduty_adjuster),0) as qduty_adjuster into $ioth_duty
		   from ca_clm_victim_data
		  where iclaim = $iverify
			and fvictim_car = 'E'
		�@order by qduty_adjuster desc;
printf("��訮:ioth_duty[%d]iverify=[%s]\n",ioth_duty,iverify);

		/* ��L�� */
		ianoth_duty = 100 - iself_duty - ioth_duty;
		
		if(ianoth_duty < 0)
			ianoth_duty = 0;
		
printf("��L��:ianoth_duty[%d]iverify=[%s]\n",ianoth_duty,iverify);
		
		/* �Ƶ� */
		sprintf_s(nnote_claim,100,"�z��ѧǸ�: %d ���T�O�θ����J�C",iclose_type);
		/* �t�X���ɶ������鵲,���@�ּg�Jñ�֪��A�ήɶ� modify by sylvia 107.04.30 (1070403001_SC1) */
		sprintf_s(stmt,4096,
		" insert into %s:settlement \
			 (iclaim, fstl, iclose_type, fcard_class, ipolicy, \
			  icard, msettle, ientry, dentry, iadjuster, \
			  frecover, fsale, istl_flag, iself_duty, ioth_duty, \
			  ianoth_duty, iupdate, dupdate, freject, \
			  nnote_claim, ipayno, dvouch_bgn, dvouch_end, vouch_state) \
			values (?, '1', ?, '2', ?, \
					?, '0', 'car546', current, ?, \
					'0', '0', '1', ?, ?, \
					?, 'car546', current, 'N', \
					?, '', today, today, '130') ", sFullName);

		$prepare ins_settle from $stmt;
		$execute ins_settle
		   using $iclaim, $iclose_type_tmp, $ipolicy,
				 $icard, $iadjuster,
				 $iself_duty, $ioth_duty,
				 $ianoth_duty,
				 $nnote_claim;	

sprintf_s(errMsg,30000," select * from %s:settlement where iclaim=%s and fstl=%s and iclose_type=%s \n", sFullName,iclaim,fstl,iclose_type);		
EWRITE(userid,M_CM_OK, errMsg);
				 
					
		/* ��P�@���z�⪺���T�O�μ��X�� */
		$DECLARE c_cur CURSOR FOR
		  SELECT ifactory,mprocess
		  FROM car546_temp where iclaim = $iclaim and fstl = $fstl and iclose_type = $iclose_type;
		$OPEN c_cur;
		
		for(;;)
		{				
			$FETCH c_cur INTO $ifactory, $mprocess;
			if (SQLCODE == SQLNOTFOUND) break;
			
			/* �����ߥI��H��� */				
			$select fassured,ifpce_id,
					CASE WHEN dexpire <= CURRENT THEN '(�w����)' ELSE '' END || nfactory AS nfactory,
					CASE trim(npayment) WHEN '' THEN nfactory ELSE npayment END AS npayment,
					fsettle_type, ibank, iaccount,
					izip, nvl(iemail,' '), nvl(itel,' '), nvl(imobile,' '),
					ffactory_type,fmodel_type,ncontact,
					ifax,afactory						
				into $fassured,$ifpce_id,
					$nchi_full,
					$npayment,
					$isettle_type, $ibank, $iaccount,
					$izip, $iemail, $itel,$imobile,
					$ffactory_type,$fmodel_type,$ncontact,
					$ifax,$afactory
				from ca_factory
			   where ifactory = $ifactory;	
			
			if (SQLCODE == SQLNOTFOUND)
			{
				sprintf_s(errMsg,30000,"�d�L�ߥI��H [%s] ���", ifactory);
				goto errexit;
			}
			printf("715 - iclaim=[%s]\n nchi_full=[%d]\n npayment=[%s]\n ",iclaim,nchi_full,npayment);


			/****  �g�Jñ����  ****/
			
			/* ���Ǹ� */
			sprintf_s(stmt,4096,
			" select nvl(max(qserial),0) + 1    \
				from ca_sign_receipt        \
			   where iclaim = ?             \
				 and ifpce_id = ? ");
			printf("stmt[%s]\n",stmt);
			$prepare get_max_qser from $stmt;
			$execute get_max_qser
				into $qserial
			   using $iclaim, $ifactory;
			
			/* ��ñ���渹 */
			$select 'A'||to_char(today,'%y%m%d')||Lpad(CAST(substr(nvl(max(isign),'A'||to_char(today,'%y%m%d')||'0000'),8,4) AS INT) + 1,4,0)
			   into $isign
			   FROM ca_sign_receipt
			  where isign[1,7] = $isign_tmp;

printf("-- 683 ca_sign_r Weceipt isign [%s] isign_tmp=[%s]\n",isign,isign_tmp);


			/* bug�ץ�:�[�W ifpce_id_ext = $proce_id_ext �P�_  modify by sylvia 107.03.09 */
			sprintf_s(stmt,4096,
			" insert into ca_sign_receipt \
				(iclaim, ifpce_id, ifpce_id_ext, qserial, mpayment, \
				 invoice, dpaperwork, dentry,dsettle, isign,  \
				 isign_type, pay_kind, fspeed, xfpay_cond, mprocess, \
				 iclose_type, ientry, iupdate, dupdate, ideliver, icntry, \
				 iemail, imobile, itel, tfax, izipcode_con, \
				 aperm_con, aperm, ffactory_type,fmodel_type, \
				 xibank, xiaccount ) \
				values (?, ?, ' ', ?, 0,\
						' ',CURRENT,CURRENT,today, ?, \
						'1', '4', '8', '3', ?, \
						?, ?, ?,current,' ','9',\
						?, ?, ?, ?, ?,\
						?, ' ', ?, ?, \
						?, ?) ");
			printf("stmt[%s]\n",stmt);
			$prepare ins_sign from $stmt;
			$execute ins_sign
			   using $iclaim, $ifactory, $qserial,
					 $isign, 
					 $mprocess, 
					 $iclose_type_tmp, $userid, $userid, 
					 $iemail, $imobile, $itel, $ifax, $izip,
					 $afactory,$ffactory_type,$fmodel_type,
					 $ibank ,$iaccount;					 

sprintf_s(errMsg,30000," select * from %s:ca_sign_receipt where iclaim=%s and qserial=%s \n", sFullName,iclaim,qserial);		
EWRITE(userid,M_CM_OK, errMsg);					 
					 

printf("-- �g�Jñ����(S)");
printf("iclaim[%s]\n ifpce_id=[%s] \n qserial=[%d]\n",iclaim,ifactory,qserial);
printf("isign[%s]\n mprocess=[%d] \n iclose_type_tmp=[%d]  \n",isign,mprocess,iclose_type_tmp);
printf("userid[%s]\n iemail=[%s] \n itel=[%s]  \n imobile=[%s]  \n",userid,iemail,itel,imobile);
printf("ifax[%s]\n izipcode_con=[%s] \n aperm_con=[%s]  \n",ifax,izip,afactory);
printf("ffactory_type[%s]\n fmodel_type=[%s] \n xibank=[%s] \n xiaccount=[%s] \n",ffactory_type,fmodel_type,ibank,iaccount);
printf("-- �g�Jñ����(E)");
				
			/****  �g�J�ߥI��H��  ****/
			sprintf_s(stmt,4096,
			" insert into %s:payment                                            \
				(iclaim,  fstl, iclose_type, ipayment,   \
				 qserial, fassured, nchi_full, npayment, \
				 xsettle_type, ipay_area, xptax,  xfpay_cond, xibank, \
				 xiaccount, aperm_con, mpayment, fspeed, \
				 pay_kind, dpaperwork, iemail, imobile, tfax, \
				 izipcode_con )                \
				values                               \
				(?, '1', ?, ?,             \
				 ?, ?, ?, ?,                        \
				 ?, ?, 0, '3', ?,                     \
				 ?, ?, ?, '8',                        \
				 '4', today, ?, ?, ?,                 \
				 ? ) ",sFullName);
			$prepare ins_payment from $stmt;
			$execute ins_payment
			   using $iclaim, $iclose_type_tmp, $ifactory,
					 $qserial, $fassured, $nchi_full, $npayment,
					 $isettle_type, $iclm_upcomp, $ibank, 
					 $iaccount, $afactory,	$mprocess,
					 $iemail, $imobile, $ifax,
					 $izip;					 

sprintf_s(errMsg,30000," select * from %s:payment where iclaim=%s and qserial=%s \n", sFullName,iclaim,qserial);		
EWRITE(userid,M_CM_OK, errMsg);						 
				
printf("�g�J�ߥI��H��stmt[%s]\n",stmt);
printf("iclaim=[%s]\n iclose_type=[%d]\n ipayment=[%s]\n qserial=[%d]\n",iclaim,iclose_type_tmp,ifactory,qserial);
printf("fassured=[%s]\n nchi_full=[%s]\n xsettle_type=[%s]\n  ipay_area=[%s]\n",fassured,nfactory,isettle_type,iclm_upcomp);
printf("xibank=[%s]\n xiaccount=[%s]\n aperm_con=[%s]\n ",ibank,iaccount,afactory);
printf("mpayment=[%d]\n iemail=[%s]\n imobile=[%s]\n tfax=[%s]\n izipcode_con=[%s]\n",mprocess,iemail,imobile,ifax,izip);
printf("-- �g�J�ߥI��H��(E)\n");

		}
		$CLOSE c_cur;
		$FREE  c_cur;
		
		$DECLARE c_cur2 CURSOR FOR
		  SELECT iins_type,sum(mprocess)
		  FROM car546_temp 
		  WHERE iclaim = $iclaim and fstl = $fstl and iclose_type = $iclose_type
		  GROUP BY iclaim,iins_type;
		  

printf("c_cur2");
printf("iclaim=[%s]\n iclose_type=[%s]\n ",iclaim,iclose_type);			  
		  

		$OPEN c_cur2;
		for(;;)
		{				
			$FETCH c_cur2 INTO $iins_type,$mprocess;
			if (SQLCODE == SQLNOTFOUND) break;	

			/* ���I�س̫�@����ƪ����O */
			sprintf_s(stmt,4096,"select first 1 flast from %s:stl_ins_type \
				  where iclaim = ? and fstl = '1' \
					and iins_type = ?  and dgroup is not null\
					order by iclose_type desc", sFullName);
			printf("864:stmt[%s]\n",stmt);
			$prepare get_ins4 from $stmt;
			$execute get_ins4 into $flast
			   using $iclaim, $iins_type;			

printf("���I�س̫�@����ƪ����Ostmt[%s]\n",stmt);
printf("iclaim=[%s]\n iins_type=[%s]\n  flast=[%s]\n ",iclaim,iins_type,flast);
printf("-- ���I�س̫�@����ƪ����O(E)\n");

			/****  �g�J�p����I�ة�����  ****/
			sprintf_s(stmt,4096,
			" insert into %s:stl_ins_type                                  \
				(iclaim, fstl, iclose_type, iins_type, mins_proc, flast)   \
				values                               \
				(?, '1', ?, ?, ?, ?) ",sFullName);

			printf("stmt[%s]\n",stmt);
			printf("877:stmt[%s]\n",stmt);
			$prepare stl_ins from $stmt;
			$execute stl_ins
			   using $iclaim, $iclose_type_tmp, $iins_type, $mprocess, $flast;				   

sprintf_s(errMsg,30000," select * from %s:stl_ins_type where iclaim=%s and iclose_type=%d and iins_type=%s and mins_proc=%d and flast=%s \n", sFullName,iclaim,iclose_type_tmp,iins_type,mprocess,flast);		
EWRITE(userid,M_CM_OK, errMsg);					   
			   

printf("�g�J�p����I�ة�����stmt[%s]\n",stmt);
printf("iclaim=[%s]\n  iclose_type=[%d]\n iins_type=[%s]\n  flast=[%s]\n ",iclaim,iclose_type_tmp,iins_type,flast);
printf("-- �g�J�p����I�ة�����(E)\n");
		}
		$CLOSE c_cur2;
		$FREE  c_cur2;		
		


printf("-- 856 iclose_type_2=[%d]\n itransno=[%s]\n iclaim=[%s]\n fstl=[%s]\n iclose_type=[%d]\n",iclose_type_tmp,sItransno,iclaim,fstl,iclose_type);
				 
		/*** �g�Jca_local_stl ***/
		/* �t�X���ɪ����鵲, �u�g�x�_��Ʈw(���) modify by sylvia 107.05.01 (1070403001_SC1) */
		sprintf_s(stmt,4096,
		" select count(*)                     \
			from ca_local_stl              \
		   where iclaim = ?                   \
			 and fstl   = '1'                 \
			 and iclose_type = ?              \
			 and dclose is null ");

printf("868:stmt[%s]\n",stmt);
		$prepare get_local_cnt from $stmt;
		$execute get_local_cnt into $tmp_cnt using $iclaim, $iclose_type_tmp;
		if (tmp_cnt > 0)
		{
		   sprintf_s(stmt,4096,
			" delete from ca_local_stl     \
			   where iclaim = ?               \
				 and fstl = '1'               \
				 and iclose_type = ?          \
				 and dclose is null ");
			printf("879:stmt[%s]\n",stmt);
			$prepare del_local_cnt from $stmt;
			$execute del_local_cnt using $iclaim, $iclose_type_tmp;
		}

printf("-- 884 tmp_cnt=[%d]\n iclaim=[%s]\n iclose_type=[%d]\n",tmp_cnt,iclaim,iclose_type_tmp);

		/****   ientry ����car546����H��id  ****/
		sprintf_s(stmt,4096,
		" insert into ca_local_stl                              \
			 (dentry, ipolicy, icard, iclaim, fstl, iclose_type,   \
			  ientry, ibranch, fchoose,userid)                            \
		   values                                                  \
			 (today, ?, ?, ?, '1', ?, ?, ?, '1',?) ");
		printf("stmt[%s]\n",stmt);
		printf("894:stmt[%s]\n",stmt);
		$prepare ins_local_stl from $stmt;
		$execute ins_local_stl
		   using $ipolicy, $icard, $iclaim, $iclose_type_tmp, $userid, $iclm_upcomp,$userid;
 printf("-- trace sqlca.sqlerrd[2]=[%d]\n ",sqlca.sqlerrd[2]);
 
sprintf_s(errMsg,30000," select * from ca_local_stl where iclaim=%s and iclose_type=%d \n", iclaim,iclose_type_tmp);		
EWRITE(userid,M_CM_OK, errMsg);				   
		   

printf("-- 904 ipolicy=[%s]\n icard=[%s]\n iclaim=[%s]\n iclose_type=[%d]\ientry=[%s]\n ibranch=[%s]\n",ipolicy,icard,iclaim,iclose_type_tmp,userid,iclm_upcomp);

		/*** �^�g���p�߰l���ƩM����Ǹ� ***/
		sprintf_s(stmt,4096,
		" update %s:ca_viewer_pay  \
			 set iclose_type_2 = ? ,itransno = ? \
		   where iclaim = ? and fstl = '1' and iclose_type = ? ", sFullName);
			 
		$prepare upd_ca_viewer_pay from $stmt;
		$execute upd_ca_viewer_pay
		   using $iclose_type_tmp,$sItransno,
				 $iclaim,$iclose_type;

sprintf_s(errMsg,30000," select * from %s:ca_viewer_pay where iclaim=%s and iclose_type=%d \n", sFullName,iclaim,iclose_type_tmp);		
EWRITE(userid,M_CM_OK, errMsg);	
		
		/* �g�Jtemp */
		$insert into car546_Adding_temp 
			(iclaim) 
		values 
			($iclaim);		
		
	}
	$CLOSE key_cur;
	$FREE  key_cur;        	
	
	/* ����ˮ֥��`�L�~, �}�l�g�J��Ʈw(End) */	

printf("COMMIT WORK\n");
$COMMIT WORK;   
EWRITE(userid,M_CM_OK,"���ɧ���!! �нT�{�鵲���G!!");

	printf("�������� car546_call_car5083 �������������� \n");
	
	rc = car546_call_car5083();

	printf("rc = [%d]\n");
	printf("*******************************************************");

	return M_CM_OK;
		
	
errexit:
    printf("------> errexit: iclaim[%s] SQLCODE=[%d] \n", iclaim, SQLCODE);
    printf("sStmt[%s]\n",sStmt);
    strcpy(errMsg1, errMsg);
    sprintf_s(errMsg,30000," �߮׸�: [%s], errMsg: [%s] SQLCODE=[%d] \n", iclaim, errMsg1,SQLCODE);
    rc = cm_show_sql_err("ca546", "");
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    $SET LOCK MODE TO NOT WAIT ;
    return rc;
	
}
/* ------------------------------------------------------------------------ */

long split_policy(sIpolicy, sIpolicy1, sIpolicy2)
char *sIpolicy, *sIpolicy1, *sIpolicy2;
{
     strcpy(sIpolicy, trim(sIpolicy));
     printf("begin split_policy\n");

     if (strlen(sIpolicy) > CAR_POLICY_LEN)
     {
        strncpy(sIpolicy1, sIpolicy, CAR_POLICY_LEN);
        sIpolicy1[CAR_POLICY_LEN] = '\0';
        strncpy(sIpolicy2, sIpolicy+CAR_POLICY_LEN, CAR_TARGET_LEN);
        sIpolicy2[CAR_TARGET_LEN] = '\0';
        if (sIpolicy2[0]=='\0' || sIpolicy2[0]==' ') strcpy(sIpolicy2," ");
     }
     else
     {
        strcpy(sIpolicy1,sIpolicy);
        strcpy(sIpolicy2," ");
     }

     printf("---after split_policy -> sIpolicy[%s]\n", sIpolicy);
     printf("---after split_policy -> sIpolicy1[%s]\n", sIpolicy1);
     printf("---after split_policy -> sIpolicy2[%s]\n", sIpolicy2);

     return M_CM_OK;
}


/* �I�s5083 */
long car546_call_car5083()
{
	int result;
	char p0[201];
	char command[512],ch_dwritten[11];

	strcpy(ch_dwritten , cm_sysd_cdate(cm_get_sysd( )));
    printf("���������� DBName=[%s]userid=[%s]ch_dwritten=[%s]sItransno=[%s]\n",DBName,userid,ch_dwritten,sItransno);

	/* sprintf_s( p0,201,"runbatch %s %s car5083 P 4 'D' '%s' '%s' '%s' >/dev/null &", DBName,userid,ch_dwritten,userid,sItransno); */
	sprintf_s( p0,201,"runbatch %s %s car5083 P 4 'D' '%s' '%s' '%s' ", DBName,userid,ch_dwritten,userid,sItransno);

	sprintf_s(command,512, "%s", p0);
	result = system(command);
	printf("result[%d]\n", result);
	puts("test_data ok");
	return M_CM_OK;

}
/* ------------------------------------------------------------------------ */


/* ���T�O�γ��� */
long car546_3()
{
	long rc;	

	$char iclaim[21],fstl[2],iins_type[7],itag[13],ifactory[21],fpay_kind[2];
	$int iclose_type,mprocess,iclose_type_2;
	$date dgroup;
	
	$char  stmt[1000],stmt_DBName[4096];
    $char sFullName[25];
    $char begin[11], end[11];
	$int icnt;

	/* 3 */
	$CREATE TEMP table car546_temp
    (
        iclaim            char(20),			-- �߮׸�
        iclose_type       int,     			-- �߰l����
        iins_type         char(6),    		-- �I�إN��
        itag              char(12),   		-- �ɮ֨���
        ifactory          char(20),   		-- ���ӥN��
        nfactory          char(100),    	-- �O�׼t�W��		
		
        tcode_remark      char(20),     	-- �O�����O (�qcu_code_data���줤��W��)
        mprocess          int,        		-- �O��
		iupdate			  char(10),			-- ���ɤH��
		dupdate			  date,				-- ���ɤ��
		dclose			  date,				-- �鵲��		
        dgroup            date       		-- �J�p���
    )with no log;
	
    /* �J�p����_�W�ɶ� */
     strcpy(begin,cm_to_infdate(begin_day));
     strcpy(end,cm_to_infdate(end_day));
	 	      
     
    /* ���Ҧ���DBNAME */
	sprintf_s(stmt_DBName,4096,
	" select dbname  \
	    from servertbl  \
	   where branch != 'S1'  \
	   ORDER BY branch ");
	
	$PREPARE serverdtl FROM $stmt_DBName;
    $DECLARE status2_server_cur CURSOR FOR serverdtl ;
    $OPEN status2_server_cur;
    for(;;)
    {
        $FETCH status2_server_cur INTO $sFullName;
        if (SQLCODE == SQLNOTFOUND) break;
	printf("sFullName[%s]\n ", sFullName);
        
        /* ��UDB�� �H��^��iclose_type_2���p�߰l���� join stl_ins_type���߰l���� */
		/* �����϶����w�鵲����� */
        sprintf_s(stmt,4096,
    	" insert into car546_temp \
		  select a.iclaim,a.iclose_type,a.iins_type,b.itag,b.ifactory,  \
				 CASE WHEN c.dexpire <= CURRENT THEN '(�w����)'||c.nfactory ELSE c.nfactory END,   \
    	         d.tcode_remark,b.mprocess,b.iupdate,b.dupdate,b.dclose,a.dgroup \
    	    from %s:stl_ins_type a, %s:ca_viewer_pay b, ca_factory c,(SELECT * FROM cu_code_data WHERE itype = 'G6') d  \
    	   where a.iclaim = b.iclaim  \
    	     and a.fstl = b.fstl  \
    	     and a.iclose_type = b.iclose_type_2  \
    	     and a.iins_type = b.iins_type  \
			 and b.ifactory = c.ifactory  \
			 and b.fpay_kind = d.icode  \
    	     and a.dgroup >= ?  \
    	     and a.dgroup <= ? \
			 order by a.iclaim,a.iclose_type" , sFullName, sFullName);
    	     
    	$PREPARE tb546 FROM $stmt;
		$execute tb546 USING :begin, :end ;	
        
        /* ��UDB�� �����n�B�z�����(End) */        
	}
	$CLOSE status2_server_cur;
	$FREE  status2_server_cur;
		
	$select count(*) into $icnt
	  from car546_temp
	 where 1=1; 	 
	
    if (icnt == 0)
    {
        EWRITE(userid, M_CM_NOT_FOUND, "�϶������T�O�άҥ������鵲!! \n");
        return FAIL;
    } 
	
	rc = car546_build();
	
	return rc;
		
	
errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
/* ------------------------------------------------------------------------ */

/* �����s�@ */
long car546_build()
{	
	$char    sfilename[51], stitle[1000], stmt[1000];
	$char msgbuf[1000];
	
	$WHENEVER SQLERROR GOTO errexit;
	
	if(status[0] == "1")
	{		
		strcpy(sfilename,"���z����T�O�Ω��Ӫ�");
	}
	else
	{
		strcpy(sfilename,"���T�O�γ���");
	}
	
    sprintf(stitle,"�J�p���:%s~%s\t",begin_day,end_day);
	strcat(stitle,"\n");
	strcat(stitle,"\t�߮׸�\t�߰l����\t�I�إN��\t���P���X\t�O�׼t�s��\t�O�׼t�W��\t");
	strcat(stitle,"�O������\t�O��\t���ɤH��\t���ɤ��\t�鵲��\t�J�p��\t");
	printf("���������� sfilename=[%s]\nstitle=[%s]\n",sfilename,stitle);
	
	sprintf(stmt,
	    "select * from car546_temp order by 1 ");	
		
	
	rc = unload_file(outputf," ",sfilename,stitle,stmt);
	
	if (rc != SUCCESS) 
	{
	    sprintf(msgbuf," %s �ɮ׵L�k���� ",sfilename);
	    EWRITE(userid, rc , msgbuf);
	    return rc;
	}
	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	return SQLCODE;
	
}
/* ------------------------------------------------------------------------ */


