/************************************************/
/*                                              */
/*   PROGRAM : ca909q01s.ec by CJLI             */
/*             �g�P�ӽ߮ץI�ک��Ӫ�             */
/*   DATE    : 88.06.30                         */
/*   pidE3  �D�b�g�P���q�X��b�g�P�Ӻ���        */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "carmsgs.h"
#define  fmt  "---,---,---,--&"
#define  fmt1 "---,---,---,--&.&&"

/*------------------------------------*/
extern char RPTDIR[];

$char clsdatebgn[10], clsdateend[10];
$char ibranch[3] ;
$char ibranchbgn[3] , ibranchend[3];
$long loss_amt;
$long loss_amt_note;
$static long lDend; 

$char DBName[5], sFullName[80], sDataFile[20];
$char FormTp[3];
char  BodyFile[21];
char  TitleFile[21];
char  outputf[21];
char  userid[11];
$char officer13[11];
$char cls_datebgn[15], cls_dateend[15];

static int pagenum=1;

$int  TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;
static int max_count, errCode;
int   tmp_len;
$long mpayment,dply_begin;
$char iclaim[CLAIM_NUM], ipolicy[POLICY_NUM_1];
$char ipolicy1[3],icard[21],itag[CA_TAG_NUM];
$char ibig_comp[2] , iofficer[11],ngroup[13],ins_knd[5],iquota[7],iquota0[7],
      manufactor[9] ,cy[4],cm[3],cd[3],cply_begin[9];
$char nchi_full[101]; 
$char ipayment[11];
$char daccident[15],dclose[11]; 
$char fstl[2]; 
$char nname[11],buf[16];
$char type[2],con_str[15],type_date[3];
char  outputf[N_FILE+1];
$char   stmt[3000],sWhere1[1024];
$char   Reportkind[2];
$char   sBranch[3];
$char   TitleFmt[21], BodyFmt[21] ;
$char   FormFmt[N_FILE+1];
char    FormFile[N_FILE+1];

$char   iadjuster[11], iadjuster_name[11];
$char   ibig_sales[11], nsales[11], ibig_office[11];
$char   nassured[41];
$char   ibrand[9];
$char   igroup[4];
$int    dmg_cnt_tp1;
int rc;

long car909_buildB();
long car909_buildC();
long car909_buildD();
long car909_buildE();
long car909_buildF();
long car909_buildG();

long car909_build1();
long car909_build2();
long car909_title1();
long car909_body1();
double d45();
void payment_read();
void app_put_body();
void rfmtput();
void rfmtput1();
void InsTemp();

main(argc, argv)
int argc;
char **argv;
{

   batchinit();
   strcpy(DBName    , isNULLstr(argv[1]));
   strcpy(userid    , isNULLstr(argv[2]));
   strcpy(ibranch   , isNULLstr(argv[3]));    /* �`�����q�O */
   strcpy(clsdatebgn, isNULLstr(argv[4]));
   strcpy(clsdateend, isNULLstr(argv[5]));
   strcpy(Reportkind, isNULLstr(argv[6]));
   strcpy(type      , isNULLstr(argv[7]));
   strcpy(con_str   , isNULLstr(argv[8]));
   strcpy(type_date , isNULLstr(argv[9]));
   strcpy(outputf   , isNULLstr(argv[10]));
    
   if(clsdatebgn[0] == '*') strcpy(clsdatebgn, "80/01/01");
   if(clsdateend[0] == '*') strcpy(clsdateend, "199/12/31");
   if(clsdateend[0] == ' ') strcpy(clsdateend, clsdatebgn);

   strcpy(cls_datebgn,clsdatebgn);
   strcpy(cls_dateend,clsdateend);

   strcpy(clsdatebgn, cm_to_infdate(clsdatebgn));
   strcpy(clsdateend, cm_to_infdate(clsdateend));
   lDend = cm_ymd_cdate(cls_dateend);
   if (strncmp(ibranch,"A",1) != 0)
       sprintf(sWhere1," AND branch = '%s' ",ibranch);
   else
       sprintf(sWhere1," ");

   printf("lDend[%d]\n",lDend);
   printf("clsdatebgn[%s]\n",clsdatebgn);
   printf("clsdateend[%s]\n",clsdateend);
   
   rc = car909_build1();
   if (rc == api_OKComplete)
   {
       create_sign_form("car909",BodyFile, Width);
       if ((rc=save_form_info(F_BLK1,"CA",909,userid,FormTp,max_count,outputf))<0)
            EWRITE(userid,rc,"save_form_info_failed");
   }
printf(" 33333333333333333 \n");

   if (Reportkind[0] == '2')      /* ���ͤ������� */
       rc = car909_build2();
printf(" 44444444444444444  \n");


   /*
   if(rc == api_OKComplete)
   {
       printf("max_count------[%d]\n",max_count);
       if((rc=save_form_info(F_FREE,"CA",909,userid,FormTp,max_count,outputf))<0)
          EWRITE(userid,rc,"save_form_info failed");
   }
   */
}

/*******************************************************************/

long car909_build2()
{
   $char   FullName[20];
   int     rtc;

   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return FAIL;
   }

   $SELECT nform_file,ntitle_fmt, nbody_fmt, kstart_row, ktitle_row,
           ktot_col, kpgnum_line, kwidth, iform_tp
      INTO $FormFmt, $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width, $FormTp
      FROM Form
     WHERE ksys_grp = "CA" AND kPgmID = 909 AND iForm_tp = '2';

       strcpy(TitleFmt, rtrim(TitleFmt));
       strcpy(BodyFmt, rtrim(BodyFmt));

       rtc = car909_buildB() ;      /* �ζ� */
       if (rtc != TRUE){
           printf("car909_buildB FAIL:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
           EWRITE(userid, SQLCODE, sqlca.sqlerrm);
           exit(FAIL);
       }
    
       rtc = car909_buildC() ;      /* �֯S */
       if (rtc != TRUE){
           printf("car909_buildC FAIL:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
           EWRITE(userid, SQLCODE, sqlca.sqlerrm);
           exit(FAIL);
       }

       rtc = car909_buildD() ;
       if (rtc != TRUE){
           printf("car909_buildD FAIL:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
           EWRITE(userid, SQLCODE, sqlca.sqlerrm);
           exit(FAIL);
       }

       rtc = car909_buildE() ;
       if (rtc != TRUE){
           printf("car909_buildE FAIL:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
           EWRITE(userid, SQLCODE, sqlca.sqlerrm);
           exit(FAIL);
       }
       rtc = car909_buildF() ;
       if (rtc != TRUE){
           printf("car909_buildF FAIL:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
           EWRITE(userid, SQLCODE, sqlca.sqlerrm);
           exit(FAIL);
       }
       rtc = car909_buildG() ;
       if (rtc != TRUE){
           printf("car909_buildG FAIL:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
           EWRITE(userid, SQLCODE, sqlca.sqlerrm);
           exit(FAIL);
       }



       /*
       create_sign_form("car909",BodyFile, Width);
       if ((rc=save_form_info(F_BLK1,"CA",909,userid,FormTp,max_count,outputf))<0)
            EWRITE(userid,rc,"save_form_info_failed");
       */
       return TRUE;

errexit:
  printf("car909_build2:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  exit(FAIL);

}


long car909_buildB()
{
$double  s_mdmg,s_mlia,s_mthft_fac;
$double  r_mdmg,r_mlia,r_mthft_fac;
$double  o_mdmg,o_mlia,o_mthft_fac;
$double  s_mthft_per,s_moth,s_mproc;
$double  s_poly,r_poly;
$double  p_mdmg,p_mlia,p_mthft_fac;
$double  p_mthft_per,p_moth,p_mproc;
$double  s_mstl,p_mstl,n_mstl;
$char    tmp[20];
$double  s_factor,r_factor,o_factor;
$char    ibig_comp[2];

$double  sum_s_mdmg,sum_s_mlia,sum_s_mthft_fac ;
$double  sum_s_mthft_per,sum_s_moth,sum_s_mproc ;




   $WHENEVER SQLERROR GOTO errexit;

       s_mdmg = s_mlia = s_mthft_fac = 0;
       r_mdmg = r_mlia = r_mthft_fac = 0;
       o_mdmg = o_mlia = o_mthft_fac = 0;
       s_mthft_per = s_moth = s_mproc = 0;
       s_poly = r_poly = 0;
       p_mdmg = p_mlia = p_mthft_fac = 0;
       p_mthft_per = p_moth = p_mproc = 0;
       s_mstl = p_mstl = n_mstl = 0;
       s_factor = r_factor = o_factor = 0;
  

       sum_s_mdmg = sum_s_mlia = sum_s_mthft_fac  = 0;
       sum_s_mthft_per = sum_s_moth = sum_s_mproc = 0;

       max_count = 0;
       printf("INTO buildB \n");
       sprintf(TitleFile, "%sB.ti", outputf);
       sprintf(BodyFile, "%sB.bd", outputf);

       rgu_init_report(TitleFmt, TitleFile);
       car909_title2();
       rgu_finish_report();

       rgu_init_report(BodyFmt, BodyFile);

        sprintf(stmt,
         " SELECT NVL(SUM(mdmg),0),NVL(SUM(mlia),0),NVL(SUM(mthft_fac),0),   \
                  NVL(SUM(mthft_per),0),NVL(SUM(moth),0),NVL(SUM(mproc),0)   \
             FROM car9092                                                    \
            WHERE ibranch = ?  ");
         $PREPARE pidB FROM $stmt;

        sprintf(stmt,
         " SELECT NVL(SUM(mdmg),0),NVL(SUM(mlia),0),NVL(SUM(mthft_fac),0),   \
                  NVL(SUM(mthft_per),0),NVL(SUM(moth),0),NVL(SUM(mproc),0)   \
             FROM car9092                                                    \
            WHERE ibranch IN ('A08','A12','A21') ");
         $PREPARE pidB1 FROM $stmt;

        sprintf(stmt,
         " SELECT NVL(SUM(mdmg),0),NVL(SUM(mlia),0),NVL(SUM(mthft_fac),0),   \
                  NVL(SUM(mthft_per),0),NVL(SUM(moth),0),NVL(SUM(mproc),0)   \
             FROM car9092                                                    \
            WHERE ibranch IN ('A13','A22') ");
         $PREPARE pidB2 FROM $stmt;

        sprintf(stmt,
         " SELECT NVL(SUM(mdmg),0),NVL(SUM(mlia),0),NVL(SUM(mthft_fac),0),   \
                  NVL(SUM(mthft_per),0),NVL(SUM(moth),0),NVL(SUM(mproc),0)   \
             FROM car9092                                                    \
            WHERE ibranch[1] = ?  ");
         $PREPARE pidB3 FROM $stmt;

        sprintf(stmt,
         " SELECT NVL(SUM(mdmg),0),NVL(SUM(mlia),0),NVL(SUM(mthft_fac),0)   \
             FROM car9092                              \
            WHERE ifactory = ?                         \
              AND ibranch = ? ");
         $PREPARE pidD FROM $stmt;

        sprintf(stmt,
         " SELECT NVL(SUM(mdmg),0),NVL(SUM(mlia),0),NVL(SUM(mthft_fac),0)   \
             FROM car9092                                                   \
            WHERE ifactory IN ('A08','A12','A21')                           \
              AND ibranch  IN ('A08','A12','A21') ");
         $PREPARE pidD1 FROM $stmt;

        sprintf(stmt,
         " SELECT NVL(SUM(mdmg),0),NVL(SUM(mlia),0),NVL(SUM(mthft_fac),0)   \
             FROM car9092                                                   \
            WHERE ifactory IN ('A13','A22')                                 \
              AND ibranch  IN ('A13','A22') ");
         $PREPARE pidD2 FROM $stmt;

      /* ���סB���q�B�ؤ� �ϥ� */
        sprintf(stmt,
         " SELECT NVL(SUM(mdmg),0),NVL(SUM(mlia),0),NVL(SUM(mthft_fac),0)   \
             FROM car9092                              \
            WHERE ibranch = ?                          \
              AND ibig_comp = ? ");
         $PREPARE pidD3 FROM $stmt;

        sprintf(stmt,
         " SELECT NVL(SUM(mdmg),0),NVL(SUM(mlia),0),NVL(SUM(mthft_fac),0)   \
             FROM car9092                              \
            WHERE ibranch[1] = ?                          \
              AND ibig_comp = ? ");
         $PREPARE pidD4 FROM $stmt;


        sprintf(stmt,
         " SELECT NVL(SUM(mdmg+mlia+mthft_fac),0)      \
             FROM car9092                              \
            WHERE ifactory = ?                         \
              AND ibranch != ?   ");
         $PREPARE pidE FROM $stmt;

        sprintf(stmt,
         " SELECT NVL(SUM(mdmg+mlia+mthft_fac),0)      \
             FROM car9092                              \
            WHERE ifactory IN ('A08','A12','A21')      \
              AND ibranch NOT IN ('A08','A12','A21') ");
         $PREPARE pidE1 FROM $stmt;

        sprintf(stmt,
         " SELECT NVL(SUM(mdmg+mlia+mthft_fac),0)      \
             FROM car9092                              \
            WHERE ifactory IN ('A13','A22')      \
              AND ibranch NOT IN ('A13','A22') ");
         $PREPARE pidE2 FROM $stmt;

        sprintf(stmt,
         " SELECT NVL(SUM(mdmg+mlia+mthft_fac),0)      \
             FROM car9092                              \
            WHERE ifactory = ?                         \
              AND ibranch[1] != ?   ");
         $PREPARE pidE3 FROM $stmt;

        sprintf(stmt,
         " SELECT NVL(SUM(mdmg+mlia+mthft_fac),0)      \
             FROM car9092                              \
            WHERE ifactory[1] = ?                      \
              AND ibranch[1] != ?   ");
         $PREPARE pidE4 FROM $stmt;

       $DECLARE curB CURSOR FOR
         SELECT igroup,ngroup
           INTO $igroup,$ngroup
           FROM sa_frm_module
          WHERE ifrm_module = '02'
            AND (igroup[1] = 'A' OR igroup[1,3] = 'E01')
            AND igroup[1,3] NOT IN ('A08','A12','A13','A00','E00','E02')
            AND qindent != 0
          ORDER BY 1;
       $OPEN curB;
       for(;;){
       $FETCH curB;
       if (SQLCODE == SQLNOTFOUND) break;

   
           printf("igroup[%s]\n",igroup);
           printf("ngroup[%s]\n",ngroup);   

           /* �X��U�I�ت��B  */

         if (strncmp(igroup,"A22",3) == 0)
          $EXECUTE pidB2
              INTO $s_mdmg,$s_mlia,$s_mthft_fac,
                   $s_mthft_per,$s_moth,$s_mproc;
         else if (strncmp(igroup,"A21",3) == 0)
          $EXECUTE pidB1
              INTO $s_mdmg,$s_mlia,$s_mthft_fac,
                   $s_mthft_per,$s_moth,$s_mproc;
         else
          $EXECUTE pidB
              INTO $s_mdmg,$s_mlia,$s_mthft_fac,
                   $s_mthft_per,$s_moth,$s_mproc
             USING $igroup;



           printf("s_mdmg[%f],s_mlia[%f],s_mthft_fac[%f],  \
                   s_mthft_per[%f],s_mproc[%f],s_moth[%f]\n",
                   s_mdmg,s_mlia,s_mthft_fac,s_mthft_per,
                   s_mproc,s_moth);         

          /* �X��U�I�ت��B�[�` */            
             s_poly = s_mdmg + s_mlia + s_mthft_fac +
                      s_mthft_per + s_mproc + s_moth;

             sum_s_mdmg += s_mdmg;
             sum_s_mlia += s_mlia;
             sum_s_mthft_fac += s_mthft_fac;
             sum_s_mthft_per += s_mthft_per;
             sum_s_mproc += s_mproc;
             sum_s_moth +=  s_moth;

           printf("s_poly[%f]\n",s_poly);
          /* �X��U�I�ئʤ��� */
             p_mdmg      = s_poly == 0 ? 0 : d45(100 * s_mdmg / s_poly , 2);
             p_mlia      = s_poly == 0 ? 0 : d45(100 * s_mlia / s_poly , 2);
             p_mthft_fac = s_poly == 0 ? 0 : d45(100 * s_mthft_fac / s_poly ,2);
             p_mthft_per = s_poly == 0 ? 0 : d45(100 * s_mthft_per / s_poly ,2);
             p_mproc     = s_poly == 0 ? 0 : d45(100 * s_mproc / s_poly ,2);
             p_moth      = s_poly == 0 ? 0 : d45(100 * s_moth / s_poly ,2);
       
           printf("p_mdmg[%f],p_mlia[%f],p_mthft_fac[%f],   \
                   p_mthft_per[%f],p_mproc[%f],p_moth[%f]\n",
                   p_mdmg,p_mlia,p_mthft_fac,p_mthft_per,
                   p_mproc,p_moth);         

             rgu_put_body_string(1,trim(ngroup),1);
             rfmtput(s_mdmg);
             rfmtput1(p_mdmg);
             rfmtput(s_mlia);
             rfmtput1(p_mlia);
             rfmtput(s_mthft_fac);
             rfmtput1(p_mthft_fac);
             rfmtput(s_mthft_per);
             rfmtput1(p_mthft_per);
             rfmtput(s_mproc);
             rfmtput1(p_mproc);
             rfmtput(s_moth);
             rfmtput1(p_moth);
             rfmtput(s_poly);
             /*
             rfmtput(p_mstl);
             */
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             /* �^�t�v */
             s_factor = s_mdmg+s_mthft_fac;
             rfmtput(s_factor);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body(1); max_count++;

          /* �b�g�P���q�X��B�^��t���B */

         if (strncmp(igroup,"A22",3) == 0)
          $EXECUTE pidD2 INTO $r_mdmg,$r_mlia,$r_mthft_fac;
         else if (strncmp(igroup,"A21",3) == 0)
          $EXECUTE pidD1 INTO $r_mdmg,$r_mlia,$r_mthft_fac;
         else
          $EXECUTE pidD
              INTO $r_mdmg,$r_mlia,$r_mthft_fac
             USING $igroup,$igroup;
      
          /* ���b�g�P���q�X����^��t���B */

         if (strncmp(igroup,"A22",3) == 0)
         $EXECUTE pidE2 INTO $n_mstl;
         else if (strncmp(igroup,"A21",3) == 0)
         $EXECUTE pidE1 INTO $n_mstl;
         else
         $EXECUTE pidE
             INTO $n_mstl 
            USING $igroup,$igroup;
  
             printf("r_mdmg[%f],r_mlia[%f],r_mthft_fac[%f]\n",
                     r_mdmg,r_mlia,r_mthft_fac);
                    

             strcpy(ngroup,trim(ngroup));
             strcat(ngroup,"�t");
             rgu_put_body_string(1,ngroup,1);
             rfmtput(r_mdmg);
             rgu_put_body_string(1," ",1);
             rfmtput(r_mlia);
             rgu_put_body_string(1," ",1);
             rfmtput(r_mthft_fac);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rfmtput(n_mstl);
             rgu_put_body_string(1," ",1);
             /* �^�t�v */
             r_factor = r_mdmg+r_mlia+r_mthft_fac+n_mstl;
             rfmtput(r_factor);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body(1); max_count++;
        
             rgu_put_body_string(1,"�~�ר�",1);
             o_mdmg = s_mdmg - r_mdmg;
             rfmtput(o_mdmg);
             rgu_put_body_string(1," ",1);
             o_mlia = s_mlia - r_mlia;
             rfmtput(o_mlia);
             rgu_put_body_string(1," ",1);
             o_mthft_fac = s_mthft_fac - r_mthft_fac;
             rfmtput(o_mthft_fac);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             o_factor = o_mdmg + o_mlia + o_mthft_fac ;
             rfmtput(o_factor);
             rgu_put_body_string(1," ",1); 
             rgu_put_body_string(1," ",1); 
             rgu_put_body_string(1," ",1); 
             rgu_put_body(1); max_count++;

         printf("igroup[%s]\n",igroup);
      
         /*
         if (strncmp(igroup,"E01",3) == 0){
             printf(" igroup E01 INTO sleep(20) \n");
          
             sleep(20);
         }
         */
       }
       $CLOSE curB;
       $FREE  curB;

       /* �}�l�C�X�X�p�� */

        /*
        strcpy(ibig_comp,"A");
          $EXECUTE pidB3
              INTO $s_mdmg,$s_mlia,$s_mthft_fac,
                   $s_mthft_per,$s_moth,$s_mproc
             USING $ibig_comp;
        */

          /* �X��U�I�ت��B�[�` */            
             s_poly = sum_s_mdmg + sum_s_mlia + sum_s_mthft_fac +
                      sum_s_mthft_per + sum_s_mproc + sum_s_moth;

           printf("s_poly[%f]\n",s_poly);
          /* �X��U�I�ئʤ��� */
             p_mdmg      = s_poly == 0 ? 0 : d45(100 * sum_s_mdmg / s_poly , 2);
             p_mlia      = s_poly == 0 ? 0 : d45(100 * sum_s_mlia / s_poly , 2);
             p_mthft_fac = s_poly == 0 ? 0 : d45(100 * sum_s_mthft_fac / s_poly ,2);
             p_mthft_per = s_poly == 0 ? 0 : d45(100 * sum_s_mthft_per / s_poly ,2);
             p_mproc     = s_poly == 0 ? 0 : d45(100 * sum_s_mproc / s_poly ,2);
             p_moth      = s_poly == 0 ? 0 : d45(100 * sum_s_moth / s_poly ,2);
       
           printf("p_mdmg[%f],p_mlia[%f],p_mthft_fac[%f],   \
                   p_mthft_per[%f],p_mproc[%f],p_moth[%f]\n",
                   p_mdmg,p_mlia,p_mthft_fac,p_mthft_per,
                   p_mproc,p_moth);         

             rgu_put_body_string(1,"�X�p",1);
             rfmtput(sum_s_mdmg);
             rfmtput1(p_mdmg);
             rfmtput(sum_s_mlia);
             rfmtput1(p_mlia);
             rfmtput(sum_s_mthft_fac);
             rfmtput1(p_mthft_fac);
             rfmtput(sum_s_mthft_per);
             rfmtput1(p_mthft_per);
             rfmtput(sum_s_mproc);
             rfmtput1(p_mproc);
             rfmtput(sum_s_moth);
             rfmtput1(p_moth);
             rfmtput(s_poly);
             /*
             rfmtput(p_mstl);
             */
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             /* �^�t�v */
             s_factor = sum_s_mdmg+sum_s_mthft_fac;
             rfmtput(s_factor);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body(1); max_count++;

         sprintf(stmt,
          " SELECT NVL(SUM(mdmg),0),NVL(SUM(mlia),0),NVL(SUM(mthft_fac),0)              \
              FROM car9092                                                              \
             WHERE (ibranch[1] = 'A' OR ibranch[1,3] = 'E01')                           \
               AND ifactory[1] IN ('A','E')                         ");  
          $PREPARE pidD4B FROM $stmt;

          $EXECUTE pidD4B
              INTO $r_mdmg,$r_mlia,$r_mthft_fac;

         sprintf(stmt,
          " SELECT NVL(SUM(mdmg+mlia+mthft_fac),0)      \
              FROM car9092                              \
             WHERE ifactory[1] IN ('A','E')             \
               AND ibranch[1] != 'A'                    \
               AND ibranch[1,3] != 'E01'  ");
          $PREPARE pidE4B FROM $stmt;

          $EXECUTE pidE4B
              INTO $n_mstl;

             printf("r_mdmg[%f],r_mlia[%f],r_mthft_fac[%f]\n",
                     r_mdmg,r_mlia,r_mthft_fac);
                    
             /*
             strcpy(ngroup,trim(ngroup));
             strcat(ngroup,"�t");
             */
             rgu_put_body_string(1,"�ζ�",1);
             rfmtput(r_mdmg);
             rgu_put_body_string(1," ",1);
             rfmtput(r_mlia);
             rgu_put_body_string(1," ",1);
             rfmtput(r_mthft_fac);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rfmtput(n_mstl);
             rgu_put_body_string(1," ",1);
             /* �^�t�v */
             r_factor = r_mdmg+r_mlia+r_mthft_fac+n_mstl;
             rfmtput(r_factor);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body(1); max_count++;
        
             rgu_put_body_string(1,"�~�ר�",1);
             o_mdmg = sum_s_mdmg - r_mdmg;
             rfmtput(o_mdmg);
             rgu_put_body_string(1," ",1);
             o_mlia = sum_s_mlia - r_mlia;
             rfmtput(o_mlia);
             rgu_put_body_string(1," ",1);
             o_mthft_fac = sum_s_mthft_fac - r_mthft_fac;
             rfmtput(o_mthft_fac);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             o_factor = o_mdmg + o_mlia + o_mthft_fac ;
             rfmtput(o_factor);
             rgu_put_body_string(1," ",1); 
             rgu_put_body_string(1," ",1); 
             rgu_put_body_string(1," ",1); 
             rgu_put_body(1); max_count++;

       rgu_finish_report();
       create_sign_form("car909",BodyFile, Width);
       if ((rc=save_form_info(F_BLK1,"CA",909,userid,FormTp,max_count,outputf))<0)
            EWRITE(userid,rc,"save_form_info_failed");

    return TRUE;
errexit:
  printf("car909_buildB:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  exit(FAIL);
}

long car909_buildC()
{
$double  s_mdmg,s_mlia,s_mthft_fac;
$double  r_mdmg,r_mlia,r_mthft_fac;
$double  o_mdmg,o_mlia,o_mthft_fac;
$double  s_mthft_per,s_moth,s_mproc;
$double  s_poly,r_poly;
$double  p_mdmg,p_mlia,p_mthft_fac;
$double  p_mthft_per,p_moth,p_mproc;
$double  s_mstl,p_mstl,n_mstl;
$char    tmp[20];
$double  s_factor,r_factor,o_factor;
$char    tmp_igroup[4];
$char    igroup23[3];

   $WHENEVER SQLERROR GOTO errexit;

       s_mdmg = s_mlia = s_mthft_fac = 0;
       r_mdmg = r_mlia = r_mthft_fac = 0;
       o_mdmg = o_mlia = o_mthft_fac = 0;
       s_mthft_per = s_moth = s_mproc = 0;
       s_poly = r_poly = 0;
       p_mdmg = p_mlia = p_mthft_fac = 0;
       p_mthft_per = p_moth = p_mproc = 0;
       s_mstl = p_mstl = n_mstl = 0;
       s_factor = r_factor = o_factor = 0;

       max_count = 0;
       printf("INTO buildC \n");
       sprintf(TitleFile, "%sC.ti", outputf);
       sprintf(BodyFile, "%sC.bd", outputf);

       rgu_init_report(TitleFmt, TitleFile);
       car909_title2();
       rgu_finish_report();

       rgu_init_report(BodyFmt, BodyFile);

 
       /*
       {
       $char A[20],B[20],C[20];

       $DECLARE curSS CURSOR FOR
         SELECT ibig_comp,ibranch,ifactory
           FROM car9092
          WHERE (ibranch[1] = 'F' OR ifactory[1] = 'F') ;
       $OPEN curSS;
        for(;;){
       $FETCH curSS INTO $A,$B,$C;
        if (SQLCODE == SQLNOTFOUND) break;
 
        printf("A[%s],B[%s],C[%s]\n",A,B,C);    


        }
       $CLOSE curSS;
       $FREE  curSS;

        exit(1);
   
       } 
       */

       $DECLARE curC CURSOR FOR
         SELECT igroup,ngroup
           INTO $igroup,$ngroup
           FROM sa_frm_module
          WHERE ifrm_module = '02'
            AND igroup[1] = 'F'
            AND igroup[1,3] != 'F17'
            AND qindent != 0
          ORDER BY 1;
       $OPEN curC;
       for(;;){
       $FETCH curC;
       if (SQLCODE == SQLNOTFOUND) break;

   
           printf("igroup[%s]\n",igroup);
           printf("ngroup[%s]\n",ngroup);   

           /* �X��U�I�ت��B  */
           strcpy(igroup23,substring(igroup,2,2));

        sprintf(stmt,
         " SELECT NVL(SUM(mdmg),0),NVL(SUM(mlia),0),NVL(SUM(mthft_fac),0),     \
                  NVL(SUM(mthft_per),0),NVL(SUM(moth),0),NVL(SUM(mproc),0)     \
             FROM car9092                                                      \
            WHERE ibranch[1] IN ('F','G')                                      \
              AND ibranch[2,3] = ? ");
         $PREPARE pidBC FROM $stmt;

          $EXECUTE pidBC
              INTO $s_mdmg,$s_mlia,$s_mthft_fac,
                   $s_mthft_per,$s_moth,$s_mproc
             USING $igroup23;

           printf("s_mdmg[%f],s_mlia[%f],s_mthft_fac[%f],  \
                   s_mthft_per[%f],s_mproc[%f],s_moth[%f]\n",
                   s_mdmg,s_mlia,s_mthft_fac,s_mthft_per,
                   s_mproc,s_moth);         

          /* �X��U�I�ت��B�[�` */            
             s_poly = s_mdmg + s_mlia + s_mthft_fac +
                      s_mthft_per + s_mproc + s_moth;

           printf("s_poly[%f]\n",s_poly);
          /* �X��U�I�ئʤ��� */
             p_mdmg      = s_poly == 0 ? 0 : d45(100 * s_mdmg / s_poly , 2);
             p_mlia      = s_poly == 0 ? 0 : d45(100 * s_mlia / s_poly , 2);
             p_mthft_fac = s_poly == 0 ? 0 : d45(100 * s_mthft_fac / s_poly ,2);
             p_mthft_per = s_poly == 0 ? 0 : d45(100 * s_mthft_per / s_poly ,2);
             p_mproc     = s_poly == 0 ? 0 : d45(100 * s_mproc / s_poly ,2);
             p_moth      = s_poly == 0 ? 0 : d45(100 * s_moth / s_poly ,2);
       
           printf("p_mdmg[%f],p_mlia[%f],p_mthft_fac[%f],   \
                   p_mthft_per[%f],p_mproc[%f],p_moth[%f]\n",
                   p_mdmg,p_mlia,p_mthft_fac,p_mthft_per,
                   p_mproc,p_moth);         

             rgu_put_body_string(1,trim(ngroup),1);
             rfmtput(s_mdmg);
             rfmtput1(p_mdmg);
             rfmtput(s_mlia);
             rfmtput1(p_mlia);
             rfmtput(s_mthft_fac);
             rfmtput1(p_mthft_fac);
             rfmtput(s_mthft_per);
             rfmtput1(p_mthft_per);
             rfmtput(s_mproc);
             rfmtput1(p_mproc);
             rfmtput(s_moth);
             rfmtput1(p_moth);
             rfmtput(s_poly);
             /*
             rfmtput(p_mstl);
             */
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             /* �^�t�v */
             s_factor = s_mdmg+s_mthft_fac;
             rfmtput(s_factor);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body(1); max_count++;


          /* �b�g�P���q�X��B�^��t���B */

        sprintf(stmt,
         " SELECT NVL(SUM(mdmg),0),NVL(SUM(mlia),0),NVL(SUM(mthft_fac),0)   \
             FROM car9092                              \
            WHERE ifactory[1] IN ('F','G')             \
              AND ifactory[2,3] = ?                    \
              AND ibranch[1] IN ('F','G')              \
              AND ibranch[2,3] = ?          ");
         $PREPARE pidDC FROM $stmt;

         $EXECUTE pidDC
             INTO $r_mdmg,$r_mlia,$r_mthft_fac 
            USING $igroup23,$igroup23;
      
          /* ���b�g�P���q�X����^��t���B */

        sprintf(stmt,
         " SELECT NVL(SUM(mdmg+mlia+mthft_fac),0)      \
             FROM car9092                              \
            WHERE ifactory[1] IN ('F','G')             \
              AND ifactory[2,3] = ?                    \
              AND NOT (ibranch[1] IN ('F','G') AND ibranch[2,3] = ?)  ");
         $PREPARE pidEC FROM $stmt;

         $EXECUTE pidEC
             INTO $n_mstl 
            USING $igroup23,$igroup23;
  
             printf("r_mdmg[%f],r_mlia[%f],r_mthft_fac[%f]\n",
                     r_mdmg,r_mlia,r_mthft_fac);
                    
             strcpy(ngroup,trim(ngroup));
             strcat(ngroup,"�t");
             rgu_put_body_string(1,ngroup,1);
             rfmtput(r_mdmg);
             rgu_put_body_string(1," ",1);
             rfmtput(r_mlia);
             rgu_put_body_string(1," ",1);
             rfmtput(r_mthft_fac);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rfmtput(n_mstl);
             rgu_put_body_string(1," ",1);
             /* �^�t�v */
             r_factor = r_mdmg+r_mlia+r_mthft_fac+n_mstl;
             rfmtput(r_factor);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body(1); max_count++;
        
             rgu_put_body_string(1,"�~�ר�",1);
             o_mdmg = s_mdmg - r_mdmg;
             rfmtput(o_mdmg);
             rgu_put_body_string(1," ",1);
             o_mlia = s_mlia - r_mlia;
             rfmtput(o_mlia);
             rgu_put_body_string(1," ",1);
             o_mthft_fac = s_mthft_fac - r_mthft_fac;
             rfmtput(o_mthft_fac);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             o_factor = o_mdmg + o_mlia + o_mthft_fac ;
             rfmtput(o_factor);
             rgu_put_body_string(1," ",1); 
             rgu_put_body_string(1," ",1); 
             rgu_put_body_string(1," ",1); 
             rgu_put_body(1); max_count++;

       }
       $CLOSE curC;
       $FREE  curC;


       /* �}�l�C�X�X�p�� */
        strcpy(ibig_comp,"F");

        sprintf(stmt,
         " SELECT NVL(SUM(mdmg),0),NVL(SUM(mlia),0),NVL(SUM(mthft_fac),0),     \
                  NVL(SUM(mthft_per),0),NVL(SUM(moth),0),NVL(SUM(mproc),0)     \
             FROM car9092                                                      \
            WHERE ibranch[1] IN ('F','G')                                      \
              AND ibranch != 'F17' ");
         $PREPARE pidB3C FROM $stmt;

          $EXECUTE pidB3C
              INTO $s_mdmg,$s_mlia,$s_mthft_fac,
                   $s_mthft_per,$s_moth,$s_mproc;

          /* �X��U�I�ت��B�[�` */            
             s_poly = s_mdmg + s_mlia + s_mthft_fac +
                      s_mthft_per + s_mproc + s_moth;

           printf("s_poly[%f]\n",s_poly);
          /* �X��U�I�ئʤ��� */
             p_mdmg      = s_poly == 0 ? 0 : d45(100 * s_mdmg / s_poly , 2);
             p_mlia      = s_poly == 0 ? 0 : d45(100 * s_mlia / s_poly , 2);
             p_mthft_fac = s_poly == 0 ? 0 : d45(100 * s_mthft_fac / s_poly ,2);
             p_mthft_per = s_poly == 0 ? 0 : d45(100 * s_mthft_per / s_poly ,2);
             p_mproc     = s_poly == 0 ? 0 : d45(100 * s_mproc / s_poly ,2);
             p_moth      = s_poly == 0 ? 0 : d45(100 * s_moth / s_poly ,2);
       
           printf("p_mdmg[%f],p_mlia[%f],p_mthft_fac[%f],   \
                   p_mthft_per[%f],p_mproc[%f],p_moth[%f]\n",
                   p_mdmg,p_mlia,p_mthft_fac,p_mthft_per,
                   p_mproc,p_moth);         

             rgu_put_body_string(1,"�X�p",1);
             rfmtput(s_mdmg);
             rfmtput1(p_mdmg);
             rfmtput(s_mlia);
             rfmtput1(p_mlia);
             rfmtput(s_mthft_fac);
             rfmtput1(p_mthft_fac);
             rfmtput(s_mthft_per);
             rfmtput1(p_mthft_per);
             rfmtput(s_mproc);
             rfmtput1(p_mproc);
             rfmtput(s_moth);
             rfmtput1(p_moth);
             rfmtput(s_poly);
             /*
             rfmtput(p_mstl);
             */
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             /* �^�t�v */
             s_factor = s_mdmg+s_mthft_fac;
             rfmtput(s_factor);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body(1); max_count++;

        sprintf(stmt,
         " SELECT NVL(SUM(mdmg),0),NVL(SUM(mlia),0),NVL(SUM(mthft_fac),0)   \
             FROM car9092                              \
            WHERE ibranch[1] IN ('F','G')              \
              AND ibranch[1,3] != 'F17'                \
              AND ifactory[1] IN ('F','G') ");
         $PREPARE pidD4C FROM $stmt;

          $EXECUTE pidD4C
              INTO $r_mdmg,$r_mlia,$r_mthft_fac;


        sprintf(stmt,
         " SELECT NVL(SUM(mdmg+mlia+mthft_fac),0)      \
             FROM car9092                              \
            WHERE ifactory[1] IN ('F','G')             \
              AND ibranch[1] NOT IN ('F','G')          \
              AND ibranch != 'F17' ");
         $PREPARE pidE4C FROM $stmt;

          $EXECUTE pidE4C
              INTO $n_mstl;


             printf("r_mdmg[%f],r_mlia[%f],r_mthft_fac[%f]\n",
                     r_mdmg,r_mlia,r_mthft_fac);
                    
             /*
             strcpy(ngroup,trim(ngroup));
             strcat(ngroup,"�t");
             */
             rgu_put_body_string(1,"�֯S",1);
             rfmtput(r_mdmg);
             rgu_put_body_string(1," ",1);
             rfmtput(r_mlia);
             rgu_put_body_string(1," ",1);
             rfmtput(r_mthft_fac);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rfmtput(n_mstl);
             rgu_put_body_string(1," ",1);
             /* �^�t�v */
             r_factor = r_mdmg+r_mlia+r_mthft_fac+n_mstl;
             rfmtput(r_factor);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body(1); max_count++;
        
             rgu_put_body_string(1,"�~�ר�",1);
             o_mdmg = s_mdmg - r_mdmg;
             rfmtput(o_mdmg);
             rgu_put_body_string(1," ",1);
             o_mlia = s_mlia - r_mlia;
             rfmtput(o_mlia);
             rgu_put_body_string(1," ",1);
             o_mthft_fac = s_mthft_fac - r_mthft_fac;
             rfmtput(o_mthft_fac);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             o_factor = o_mdmg + o_mlia + o_mthft_fac ;
             rfmtput(o_factor);
             rgu_put_body_string(1," ",1); 
             rgu_put_body_string(1," ",1); 
             rgu_put_body_string(1," ",1); 
             rgu_put_body(1); max_count++;



       rgu_finish_report();
       create_sign_form("car909",BodyFile, Width);
       if ((rc=save_form_info(F_BLK1,"CA",909,userid,FormTp,max_count,outputf))<0)
            EWRITE(userid,rc,"save_form_info_failed");

    return TRUE;
errexit:
  printf("car909_buildC:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  exit(FAIL);
}

long car909_buildD()
{
$double  s_mdmg,s_mlia,s_mthft_fac;
$double  r_mdmg,r_mlia,r_mthft_fac;
$double  o_mdmg,o_mlia,o_mthft_fac;
$double  s_mthft_per,s_moth,s_mproc;
$double  s_poly,r_poly;
$double  p_mdmg,p_mlia,p_mthft_fac;
$double  p_mthft_per,p_moth,p_mproc;
$double  s_mstl,p_mstl,n_mstl;
$char    tmp[20];
$double  s_factor,r_factor,o_factor;
$char    ibig_comp[2];

$double  sum_n_mstl;
$double  sum_s_mdmg,sum_s_mlia,sum_s_mthft_fac;
$double  sum_s_mthft_per,sum_s_moth,sum_s_mproc;
$double  sum_s_poly;
$double  sum_r_mdmg,sum_r_mlia,sum_r_mthft_fac;



   $WHENEVER SQLERROR GOTO errexit;

       s_mdmg = s_mlia = s_mthft_fac = 0;
       r_mdmg = r_mlia = r_mthft_fac = 0;
       o_mdmg = o_mlia = o_mthft_fac = 0;
       s_mthft_per = s_moth = s_mproc = 0;
       s_poly = r_poly = 0;
       p_mdmg = p_mlia = p_mthft_fac = 0;
       p_mthft_per = p_moth = p_mproc = 0;
       s_mstl = p_mstl = n_mstl = 0;
       s_factor = r_factor = o_factor = 0;


       sum_n_mstl = 0;
       sum_s_mdmg = sum_s_mlia = sum_s_mthft_fac = 0;
       sum_s_mthft_per = sum_s_moth = sum_s_mproc = 0;
       sum_s_poly = 0;
       sum_r_mdmg = sum_r_mlia = sum_r_mthft_fac = 0;



       max_count = 0;
       printf("INTO buildD \n");
       sprintf(TitleFile, "%sD.ti", outputf);
       sprintf(BodyFile, "%sD.bd", outputf);

       rgu_init_report(TitleFmt, TitleFile);
       car909_title2();
       rgu_finish_report();

       rgu_init_report(BodyFmt, BodyFile);

       $DECLARE curD CURSOR FOR
         SELECT igroup,ngroup
           INTO $igroup,$ngroup
           FROM sa_frm_module
          WHERE ifrm_module = '02'
            AND igroup[1] = 'B'
            AND qindent != 0
          ORDER BY 1;
       $OPEN curD;
       for(;;){
       $FETCH curD;
       if (SQLCODE == SQLNOTFOUND) break;

           strcpy(ibig_comp,substring(igroup,1,1));
           printf("igroup[%s]\n",igroup);
           printf("ngroup[%s]\n",ngroup);   

           /* �X��U�I�ت��B  */

          $EXECUTE pidB
              INTO $s_mdmg,$s_mlia,$s_mthft_fac,
                   $s_mthft_per,$s_moth,$s_mproc
             USING $igroup;

           printf("s_mdmg[%f],s_mlia[%f],s_mthft_fac[%f],  \
                   s_mthft_per[%f],s_mproc[%f],s_moth[%f]\n",
                   s_mdmg,s_mlia,s_mthft_fac,s_mthft_per,
                   s_mproc,s_moth);         

             sum_s_mdmg      += s_mdmg;
             sum_s_mlia      += s_mlia;
             sum_s_mthft_fac += s_mthft_fac;
             sum_s_mthft_per += s_mthft_per;
             sum_s_moth      += s_moth;
             sum_s_mproc     += s_mproc;

          /* �X��U�I�ت��B�[�` */            
             s_poly = s_mdmg + s_mlia + s_mthft_fac +
                      s_mthft_per + s_mproc + s_moth;

             sum_s_poly += s_poly;

           printf("s_poly[%f]\n",s_poly);
          /* �X��U�I�ئʤ��� */
             p_mdmg      = s_poly == 0 ? 0 : d45(100 * s_mdmg / s_poly , 2);
             p_mlia      = s_poly == 0 ? 0 : d45(100 * s_mlia / s_poly , 2);
             p_mthft_fac = s_poly == 0 ? 0 : d45(100 * s_mthft_fac / s_poly ,2);
             p_mthft_per = s_poly == 0 ? 0 : d45(100 * s_mthft_per / s_poly ,2);
             p_mproc     = s_poly == 0 ? 0 : d45(100 * s_mproc / s_poly ,2);
             p_moth      = s_poly == 0 ? 0 : d45(100 * s_moth / s_poly ,2);
       
           printf("p_mdmg[%f],p_mlia[%f],p_mthft_fac[%f],   \
                   p_mthft_per[%f],p_mproc[%f],p_moth[%f]\n",
                   p_mdmg,p_mlia,p_mthft_fac,p_mthft_per,
                   p_mproc,p_moth);         

             rgu_put_body_string(1,trim(ngroup),1);
             rfmtput(s_mdmg);
             rfmtput1(p_mdmg);
             rfmtput(s_mlia);
             rfmtput1(p_mlia);
             rfmtput(s_mthft_fac);
             rfmtput1(p_mthft_fac);
             rfmtput(s_mthft_per);
             rfmtput1(p_mthft_per);
             rfmtput(s_mproc);
             rfmtput1(p_mproc);
             rfmtput(s_moth);
             rfmtput1(p_moth);
             rfmtput(s_poly);
             /*
             rfmtput(p_mstl);
             */
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             /* �^�t�v */
             s_factor = s_mdmg+s_mthft_fac;
             rfmtput(s_factor);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body(1); max_count++;

          /* �b�g�P���q�X��B�^��ϳ����B */

          $EXECUTE pidD3
              INTO $r_mdmg,$r_mlia,$r_mthft_fac
             USING $igroup,$ibig_comp;
      
          /* ���b�g�P���q�X����^��t���B */

         $EXECUTE pidE3
             INTO $n_mstl 
            USING $igroup,$ibig_comp;
  
             printf("r_mdmg[%f],r_mlia[%f],r_mthft_fac[%f]\n",
                     r_mdmg,r_mlia,r_mthft_fac);

             sum_r_mdmg      += r_mdmg;
             sum_r_mlia      += r_mlia;
             sum_r_mthft_fac += r_mthft_fac;
             sum_n_mstl      += n_mstl;
                    
             /*
             strcpy(ngroup,trim(ngroup));
             strcat(ngroup,"�t");
             */
             rgu_put_body_string(1,"���׼t",1);
             rfmtput(r_mdmg);
             rgu_put_body_string(1," ",1);
             rfmtput(r_mlia);
             rgu_put_body_string(1," ",1);
             rfmtput(r_mthft_fac);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rfmtput(n_mstl);
             rgu_put_body_string(1," ",1);
             /* �^�t�v */
             r_factor = r_mdmg+r_mlia+r_mthft_fac+n_mstl;
             rfmtput(r_factor);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body(1); max_count++;
        
             rgu_put_body_string(1,"�~�ר�",1);
             o_mdmg = s_mdmg - r_mdmg;
             rfmtput(o_mdmg);
             rgu_put_body_string(1," ",1);
             o_mlia = s_mlia - r_mlia;
             rfmtput(o_mlia);
             rgu_put_body_string(1," ",1);
             o_mthft_fac = s_mthft_fac - r_mthft_fac;
             rfmtput(o_mthft_fac);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             o_factor = o_mdmg + o_mlia + o_mthft_fac ;
             rfmtput(o_factor);
             rgu_put_body_string(1," ",1); 
             rgu_put_body_string(1," ",1); 
             rgu_put_body_string(1," ",1); 
             rgu_put_body(1); max_count++;

       }
       $CLOSE curD;
       $FREE  curD;

       /* �}�l�X�p��� */

             p_mdmg      = sum_s_poly == 0 ? 0 : d45(100 * sum_s_mdmg / sum_s_poly , 2);
             p_mlia      = sum_s_poly == 0 ? 0 : d45(100 * sum_s_mlia / sum_s_poly , 2);
             p_mthft_fac = sum_s_poly == 0 ? 0 : d45(100 * sum_s_mthft_fac / sum_s_poly ,2);
             p_mthft_per = sum_s_poly == 0 ? 0 : d45(100 * sum_s_mthft_per / sum_s_poly ,2);
             p_mproc     = sum_s_poly == 0 ? 0 : d45(100 * sum_s_mproc / sum_s_poly ,2);
             p_moth      = sum_s_poly == 0 ? 0 : d45(100 * sum_s_moth / sum_s_poly ,2);
       
           printf("p_mdmg[%f],p_mlia[%f],p_mthft_fac[%f],   \
                   p_mthft_per[%f],p_mproc[%f],p_moth[%f]\n",
                   p_mdmg,p_mlia,p_mthft_fac,p_mthft_per,
                   p_mproc,p_moth);         

             rgu_put_body_string(1,"�X�p",1);
             rfmtput(sum_s_mdmg);
             rfmtput1(p_mdmg);
             rfmtput(sum_s_mlia);
             rfmtput1(p_mlia);
             rfmtput(sum_s_mthft_fac);
             rfmtput1(p_mthft_fac);
             rfmtput(sum_s_mthft_per);
             rfmtput1(p_mthft_per);
             rfmtput(sum_s_mproc);
             rfmtput1(p_mproc);
             rfmtput(sum_s_moth);
             rfmtput1(p_moth);
             rfmtput(sum_s_poly);
             /*
             rfmtput(p_mstl);
             */
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             /* �^�t�v */
             s_factor = sum_s_mdmg+sum_s_mthft_fac;
             rfmtput(s_factor);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body(1); max_count++;

             rgu_put_body_string(1,"����",1);
             rfmtput(sum_r_mdmg);
             rgu_put_body_string(1," ",1);
             rfmtput(sum_r_mlia);
             rgu_put_body_string(1," ",1);
             rfmtput(sum_r_mthft_fac);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rfmtput(sum_n_mstl);
             rgu_put_body_string(1," ",1);
             /* �^�t�v */
             r_factor = sum_r_mdmg+sum_r_mlia+sum_r_mthft_fac+sum_n_mstl;
             rfmtput(r_factor);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body(1); max_count++;
        
             rgu_put_body_string(1,"�~�ר�",1);
             o_mdmg = sum_s_mdmg - sum_r_mdmg;
             rfmtput(o_mdmg);
             rgu_put_body_string(1," ",1);
             o_mlia = sum_s_mlia - sum_r_mlia;
             rfmtput(o_mlia);
             rgu_put_body_string(1," ",1);
             o_mthft_fac = sum_s_mthft_fac - sum_r_mthft_fac;
             rfmtput(o_mthft_fac);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             o_factor = o_mdmg + o_mlia + o_mthft_fac ;
             rfmtput(o_factor);
             rgu_put_body_string(1," ",1); 
             rgu_put_body_string(1," ",1); 
             rgu_put_body_string(1," ",1); 
             rgu_put_body(1); max_count++;


       rgu_finish_report();
       create_sign_form("car909",BodyFile, Width);
       if ((rc=save_form_info(F_BLK1,"CA",909,userid,FormTp,max_count,outputf))<0)
            EWRITE(userid,rc,"save_form_info_failed");

    return TRUE;
errexit:
  printf("car909_buildD:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  exit(FAIL);

}

long car909_buildE()
{

$double  s_mdmg,s_mlia,s_mthft_fac;
$double  r_mdmg,r_mlia,r_mthft_fac;
$double  o_mdmg,o_mlia,o_mthft_fac;
$double  s_mthft_per,s_moth,s_mproc;
$double  s_poly,r_poly;
$double  p_mdmg,p_mlia,p_mthft_fac;
$double  p_mthft_per,p_moth,p_mproc;
$double  s_mstl,p_mstl,n_mstl;
$char    tmp[20];
$double  s_factor,r_factor,o_factor;
$char    ibig_comp[2];

$double  sum_n_mstl;
$double  sum_s_mdmg,sum_s_mlia,sum_s_mthft_fac;
$double  sum_s_mthft_per,sum_s_moth,sum_s_mproc;
$double  sum_s_poly;
$double  sum_r_mdmg,sum_r_mlia,sum_r_mthft_fac;

   $WHENEVER SQLERROR GOTO errexit;


       s_mdmg = s_mlia = s_mthft_fac = 0;
       r_mdmg = r_mlia = r_mthft_fac = 0;
       o_mdmg = o_mlia = o_mthft_fac = 0;
       s_mthft_per = s_moth = s_mproc = 0;
       s_poly = r_poly = 0;
       p_mdmg = p_mlia = p_mthft_fac = 0;
       p_mthft_per = p_moth = p_mproc = 0;
       s_mstl = p_mstl = n_mstl = 0;
       s_factor = r_factor = o_factor = 0;

       sum_n_mstl = 0;
       sum_s_mdmg = sum_s_mlia = sum_s_mthft_fac = 0;
       sum_s_mthft_per = sum_s_moth = sum_s_mproc = 0;
       sum_s_poly = 0;
       sum_r_mdmg = sum_r_mlia = sum_r_mthft_fac = 0;


       max_count = 0;
       printf("INTO buildE \n");
       sprintf(TitleFile, "%sE.ti", outputf);
       sprintf(BodyFile, "%sE.bd", outputf);

       rgu_init_report(TitleFmt, TitleFile);
       car909_title2();
       rgu_finish_report();

       rgu_init_report(BodyFmt, BodyFile);

       $DECLARE curE CURSOR FOR
         SELECT igroup,ngroup
           INTO $igroup,$ngroup
           FROM sa_frm_module
          WHERE ifrm_module = '02'
            AND igroup[1] = 'C'
            AND qindent != 0
          ORDER BY 1;
       $OPEN curE;
       for(;;){
       $FETCH curE;
       if (SQLCODE == SQLNOTFOUND) break;

           strcpy(ibig_comp,substring(igroup,1,1));
           printf("igroup[%s]\n",igroup);
           printf("ngroup[%s]\n",ngroup);   

           /* �X��U�I�ت��B  */

          $EXECUTE pidB
              INTO $s_mdmg,$s_mlia,$s_mthft_fac,
                   $s_mthft_per,$s_moth,$s_mproc
             USING $igroup;

           printf("s_mdmg[%f],s_mlia[%f],s_mthft_fac[%f],  \
                   s_mthft_per[%f],s_mproc[%f],s_moth[%f]\n",
                   s_mdmg,s_mlia,s_mthft_fac,s_mthft_per,
                   s_mproc,s_moth);

             sum_s_mdmg      += s_mdmg;
             sum_s_mlia      += s_mlia;
             sum_s_mthft_fac += s_mthft_fac;
             sum_s_mthft_per += s_mthft_per;
             sum_s_moth      += s_moth;
             sum_s_mproc     += s_mproc;

          /* �X��U�I�ت��B�[�` */            
             s_poly = s_mdmg + s_mlia + s_mthft_fac +
                      s_mthft_per + s_mproc + s_moth;

             sum_s_poly += s_poly;

           printf("s_poly[%f]\n",s_poly);
          /* �X��U�I�ئʤ��� */
             p_mdmg      = s_poly == 0 ? 0 : d45(100 * s_mdmg / s_poly , 2);
             p_mlia      = s_poly == 0 ? 0 : d45(100 * s_mlia / s_poly , 2);
             p_mthft_fac = s_poly == 0 ? 0 : d45(100 * s_mthft_fac / s_poly ,2);
             p_mthft_per = s_poly == 0 ? 0 : d45(100 * s_mthft_per / s_poly ,2);
             p_mproc     = s_poly == 0 ? 0 : d45(100 * s_mproc / s_poly ,2);
             p_moth      = s_poly == 0 ? 0 : d45(100 * s_moth / s_poly ,2);
       
           printf("p_mdmg[%f],p_mlia[%f],p_mthft_fac[%f],   \
                   p_mthft_per[%f],p_mproc[%f],p_moth[%f]\n",
                   p_mdmg,p_mlia,p_mthft_fac,p_mthft_per,
                   p_mproc,p_moth);         

             rgu_put_body_string(1,trim(ngroup),1);
             rfmtput(s_mdmg);
             rfmtput1(p_mdmg);
             rfmtput(s_mlia);
             rfmtput1(p_mlia);
             rfmtput(s_mthft_fac);
             rfmtput1(p_mthft_fac);
             rfmtput(s_mthft_per);
             rfmtput1(p_mthft_per);
             rfmtput(s_mproc);
             rfmtput1(p_mproc);
             rfmtput(s_moth);
             rfmtput1(p_moth);
             rfmtput(s_poly);
             /*
             rfmtput(p_mstl);
             */
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             /* �^�t�v */
             s_factor = s_mdmg+s_mthft_fac;
             rfmtput(s_factor);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body(1); max_count++;

          /* �b�g�P���q�X��B�^��ϳ����B */

          $EXECUTE pidD3
              INTO $r_mdmg,$r_mlia,$r_mthft_fac
             USING $igroup,$ibig_comp;
      
          /* ���b�g�P���q�X����^��t���B */

         $EXECUTE pidE3
             INTO $n_mstl 
            USING $igroup,$ibig_comp;
  
             printf("r_mdmg[%f],r_mlia[%f],r_mthft_fac[%f]\n",
                     r_mdmg,r_mlia,r_mthft_fac);

             sum_r_mdmg      += r_mdmg;
             sum_r_mlia      += r_mlia;
             sum_r_mthft_fac += r_mthft_fac;
             sum_n_mstl      += n_mstl;
                    
             /*
             strcpy(ngroup,trim(ngroup));
             strcat(ngroup,"�t");
             */
             rgu_put_body_string(1,"���q�t",1);
             rfmtput(r_mdmg);
             rgu_put_body_string(1," ",1);
             rfmtput(r_mlia);
             rgu_put_body_string(1," ",1);
             rfmtput(r_mthft_fac);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rfmtput(n_mstl);
             rgu_put_body_string(1," ",1);
             /* �^�t�v */
             r_factor = r_mdmg+r_mlia+r_mthft_fac+n_mstl;
             rfmtput(r_factor);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body(1); max_count++;
        
             rgu_put_body_string(1,"�~�ר�",1);
             o_mdmg = s_mdmg - r_mdmg;
             rfmtput(o_mdmg);
             rgu_put_body_string(1," ",1);
             o_mlia = s_mlia - r_mlia;
             rfmtput(o_mlia);
             rgu_put_body_string(1," ",1);
             o_mthft_fac = s_mthft_fac - r_mthft_fac;
             rfmtput(o_mthft_fac);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             o_factor = o_mdmg + o_mlia + o_mthft_fac ;
             rfmtput(o_factor);
             rgu_put_body_string(1," ",1); 
             rgu_put_body_string(1," ",1); 
             rgu_put_body_string(1," ",1); 
             rgu_put_body(1); max_count++;

       }
       $CLOSE curE;
       $FREE  curE;


       /* �}�l�X�p��� */

             p_mdmg      = sum_s_poly == 0 ? 0 : d45(100 * sum_s_mdmg / sum_s_poly , 2);
             p_mlia      = sum_s_poly == 0 ? 0 : d45(100 * sum_s_mlia / sum_s_poly , 2);
             p_mthft_fac = sum_s_poly == 0 ? 0 : d45(100 * sum_s_mthft_fac / sum_s_poly ,2);
             p_mthft_per = sum_s_poly == 0 ? 0 : d45(100 * sum_s_mthft_per / sum_s_poly ,2);
             p_mproc     = sum_s_poly == 0 ? 0 : d45(100 * sum_s_mproc / sum_s_poly ,2);
             p_moth      = sum_s_poly == 0 ? 0 : d45(100 * sum_s_moth / sum_s_poly ,2);
       
           printf("p_mdmg[%f],p_mlia[%f],p_mthft_fac[%f],   \
                   p_mthft_per[%f],p_mproc[%f],p_moth[%f]\n",
                   p_mdmg,p_mlia,p_mthft_fac,p_mthft_per,
                   p_mproc,p_moth);         

             rgu_put_body_string(1,"�X�p",1);
             rfmtput(sum_s_mdmg);
             rfmtput1(p_mdmg);
             rfmtput(sum_s_mlia);
             rfmtput1(p_mlia);
             rfmtput(sum_s_mthft_fac);
             rfmtput1(p_mthft_fac);
             rfmtput(sum_s_mthft_per);
             rfmtput1(p_mthft_per);
             rfmtput(sum_s_mproc);
             rfmtput1(p_mproc);
             rfmtput(sum_s_moth);
             rfmtput1(p_moth);
             rfmtput(sum_s_poly);
             /*
             rfmtput(p_mstl);
             */
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             /* �^�t�v */
             s_factor = sum_s_mdmg+sum_s_mthft_fac;
             rfmtput(s_factor);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body(1); max_count++;

             rgu_put_body_string(1,"���q",1);
             rfmtput(sum_r_mdmg);
             rgu_put_body_string(1," ",1);
             rfmtput(sum_r_mlia);
             rgu_put_body_string(1," ",1);
             rfmtput(sum_r_mthft_fac);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rfmtput(sum_n_mstl);
             rgu_put_body_string(1," ",1);
             /* �^�t�v */
             r_factor = sum_r_mdmg+sum_r_mlia+sum_r_mthft_fac+sum_n_mstl;
             rfmtput(r_factor);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body(1); max_count++;
        
             rgu_put_body_string(1,"�~�ר�",1);
             o_mdmg = sum_s_mdmg - sum_r_mdmg;
             rfmtput(o_mdmg);
             rgu_put_body_string(1," ",1);
             o_mlia = sum_s_mlia - sum_r_mlia;
             rfmtput(o_mlia);
             rgu_put_body_string(1," ",1);
             o_mthft_fac = sum_s_mthft_fac - sum_r_mthft_fac;
             rfmtput(o_mthft_fac);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             o_factor = o_mdmg + o_mlia + o_mthft_fac ;
             rfmtput(o_factor);
             rgu_put_body_string(1," ",1); 
             rgu_put_body_string(1," ",1); 
             rgu_put_body_string(1," ",1); 
             rgu_put_body(1); max_count++;


       rgu_finish_report();
       create_sign_form("car909",BodyFile, Width);
       if ((rc=save_form_info(F_BLK1,"CA",909,userid,FormTp,max_count,outputf))<0)
            EWRITE(userid,rc,"save_form_info_failed");

    return TRUE;
errexit:
  printf("car909_buildE:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  exit(FAIL);

}

long car909_buildF()
{

$double  s_mdmg,s_mlia,s_mthft_fac;
$double  r_mdmg,r_mlia,r_mthft_fac;
$double  o_mdmg,o_mlia,o_mthft_fac;
$double  s_mthft_per,s_moth,s_mproc;
$double  s_poly,r_poly;
$double  p_mdmg,p_mlia,p_mthft_fac;
$double  p_mthft_per,p_moth,p_mproc;
$double  s_mstl,p_mstl,n_mstl;
$char    tmp[20];
$double  s_factor,r_factor,o_factor;
$char    ibig_comp[2];

$double  sum_n_mstl;
$double  sum_s_mdmg,sum_s_mlia,sum_s_mthft_fac;
$double  sum_s_mthft_per,sum_s_moth,sum_s_mproc;
$double  sum_s_poly;
$double  sum_r_mdmg,sum_r_mlia,sum_r_mthft_fac;

   $WHENEVER SQLERROR GOTO errexit;


       s_mdmg = s_mlia = s_mthft_fac = 0;
       r_mdmg = r_mlia = r_mthft_fac = 0;
       o_mdmg = o_mlia = o_mthft_fac = 0;
       s_mthft_per = s_moth = s_mproc = 0;
       s_poly = r_poly = 0;
       p_mdmg = p_mlia = p_mthft_fac = 0;
       p_mthft_per = p_moth = p_mproc = 0;
       s_mstl = p_mstl = n_mstl = 0;
       s_factor = r_factor = o_factor = 0;

       sum_n_mstl = 0;
       sum_s_mdmg = sum_s_mlia = sum_s_mthft_fac = 0;
       sum_s_mthft_per = sum_s_moth = sum_s_mproc = 0;
       sum_s_poly = 0;
       sum_r_mdmg = sum_r_mlia = sum_r_mthft_fac = 0;

       max_count = 0;
       printf("INTO buildF \n");
       sprintf(TitleFile, "%sF.ti", outputf);
       sprintf(BodyFile, "%sF.bd", outputf);

       rgu_init_report(TitleFmt, TitleFile);
       car909_title2();
       rgu_finish_report();

       rgu_init_report(BodyFmt, BodyFile);

       $DECLARE curF CURSOR FOR
         SELECT igroup,ngroup
           INTO $igroup,$ngroup
           FROM sa_frm_module
          WHERE ifrm_module = '02'
            AND igroup[1] = 'D'
            AND qindent != 0
          ORDER BY 1;
       $OPEN curF;
       for(;;){
       $FETCH curF;
       if (SQLCODE == SQLNOTFOUND) break;

           strcpy(ibig_comp,substring(igroup,1,1));
           printf("igroup[%s]\n",igroup);
           printf("ngroup[%s]\n",ngroup);   

           /* �X��U�I�ت��B  */

          $EXECUTE pidB
              INTO $s_mdmg,$s_mlia,$s_mthft_fac,
                   $s_mthft_per,$s_moth,$s_mproc
             USING $igroup;

           printf("s_mdmg[%f],s_mlia[%f],s_mthft_fac[%f],  \
                   s_mthft_per[%f],s_mproc[%f],s_moth[%f]\n",
                   s_mdmg,s_mlia,s_mthft_fac,s_mthft_per,
                   s_mproc,s_moth);

             sum_s_mdmg      += s_mdmg;
             sum_s_mlia      += s_mlia;
             sum_s_mthft_fac += s_mthft_fac;
             sum_s_mthft_per += s_mthft_per;
             sum_s_moth      += s_moth;
             sum_s_mproc     += s_mproc;

          /* �X��U�I�ت��B�[�` */            
             s_poly = s_mdmg + s_mlia + s_mthft_fac +
                      s_mthft_per + s_mproc + s_moth;

             sum_s_poly += s_poly;

           printf("s_poly[%f]\n",s_poly);
          /* �X��U�I�ئʤ��� */
             p_mdmg      = s_poly == 0 ? 0 : d45(100 * s_mdmg / s_poly , 2);
             p_mlia      = s_poly == 0 ? 0 : d45(100 * s_mlia / s_poly , 2);
             p_mthft_fac = s_poly == 0 ? 0 : d45(100 * s_mthft_fac / s_poly ,2);
             p_mthft_per = s_poly == 0 ? 0 : d45(100 * s_mthft_per / s_poly ,2);
             p_mproc     = s_poly == 0 ? 0 : d45(100 * s_mproc / s_poly ,2);
             p_moth      = s_poly == 0 ? 0 : d45(100 * s_moth / s_poly ,2);
       
           printf("p_mdmg[%f],p_mlia[%f],p_mthft_fac[%f],   \
                   p_mthft_per[%f],p_mproc[%f],p_moth[%f]\n",
                   p_mdmg,p_mlia,p_mthft_fac,p_mthft_per,
                   p_mproc,p_moth);         

             rgu_put_body_string(1,trim(ngroup),1);
             rfmtput(s_mdmg);
             rfmtput1(p_mdmg);
             rfmtput(s_mlia);
             rfmtput1(p_mlia);
             rfmtput(s_mthft_fac);
             rfmtput1(p_mthft_fac);
             rfmtput(s_mthft_per);
             rfmtput1(p_mthft_per);
             rfmtput(s_mproc);
             rfmtput1(p_mproc);
             rfmtput(s_moth);
             rfmtput1(p_moth);
             rfmtput(s_poly);
             /*
             rfmtput(p_mstl);
             */
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             /* �^�t�v */
             s_factor = s_mdmg+s_mthft_fac;
             rfmtput(s_factor);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body(1); max_count++;

          /* �b�g�P���q�X��B�^��ϳ����B */

          $EXECUTE pidD3
              INTO $r_mdmg,$r_mlia,$r_mthft_fac
             USING $igroup,$ibig_comp;
      
          /* ���b�g�P���q�X����^��t���B */

         $EXECUTE pidE3
             INTO $n_mstl 
            USING $igroup,$ibig_comp;
  
             printf("r_mdmg[%f],r_mlia[%f],r_mthft_fac[%f]\n",
                     r_mdmg,r_mlia,r_mthft_fac);

             sum_r_mdmg      += r_mdmg;
             sum_r_mlia      += r_mlia;
             sum_r_mthft_fac += r_mthft_fac;
             sum_n_mstl      += n_mstl;
                    
             /*
             strcpy(ngroup,trim(ngroup));
             strcat(ngroup,"�t");
             */
             rgu_put_body_string(1,"�ؤ��t",1);
             rfmtput(r_mdmg);
             rgu_put_body_string(1," ",1);
             rfmtput(r_mlia);
             rgu_put_body_string(1," ",1);
             rfmtput(r_mthft_fac);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rfmtput(n_mstl);
             rgu_put_body_string(1," ",1);
             /* �^�t�v */
             r_factor = r_mdmg+r_mlia+r_mthft_fac+n_mstl;
             rfmtput(r_factor);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body(1); max_count++;
        
             rgu_put_body_string(1,"�~�ר�",1);
             o_mdmg = s_mdmg - r_mdmg;
             rfmtput(o_mdmg);
             rgu_put_body_string(1," ",1);
             o_mlia = s_mlia - r_mlia;
             rfmtput(o_mlia);
             rgu_put_body_string(1," ",1);
             o_mthft_fac = s_mthft_fac - r_mthft_fac;
             rfmtput(o_mthft_fac);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             o_factor = o_mdmg + o_mlia + o_mthft_fac ;
             rfmtput(o_factor);
             rgu_put_body_string(1," ",1); 
             rgu_put_body_string(1," ",1); 
             rgu_put_body_string(1," ",1); 
             rgu_put_body(1); max_count++;

       }
       $CLOSE curF;
       $FREE  curF;

       /* �}�l�X�p��� */

             p_mdmg      = sum_s_poly == 0 ? 0 : d45(100 * sum_s_mdmg / sum_s_poly , 2);
             p_mlia      = sum_s_poly == 0 ? 0 : d45(100 * sum_s_mlia / sum_s_poly , 2);
             p_mthft_fac = sum_s_poly == 0 ? 0 : d45(100 * sum_s_mthft_fac / sum_s_poly ,2);
             p_mthft_per = sum_s_poly == 0 ? 0 : d45(100 * sum_s_mthft_per / sum_s_poly ,2);
             p_mproc     = sum_s_poly == 0 ? 0 : d45(100 * sum_s_mproc / sum_s_poly ,2);
             p_moth      = sum_s_poly == 0 ? 0 : d45(100 * sum_s_moth / sum_s_poly ,2);
       
           printf("p_mdmg[%f],p_mlia[%f],p_mthft_fac[%f],   \
                   p_mthft_per[%f],p_mproc[%f],p_moth[%f]\n",
                   p_mdmg,p_mlia,p_mthft_fac,p_mthft_per,
                   p_mproc,p_moth);         

             rgu_put_body_string(1,"�X�p",1);
             rfmtput(sum_s_mdmg);
             rfmtput1(p_mdmg);
             rfmtput(sum_s_mlia);
             rfmtput1(p_mlia);
             rfmtput(sum_s_mthft_fac);
             rfmtput1(p_mthft_fac);
             rfmtput(sum_s_mthft_per);
             rfmtput1(p_mthft_per);
             rfmtput(sum_s_mproc);
             rfmtput1(p_mproc);
             rfmtput(sum_s_moth);
             rfmtput1(p_moth);
             rfmtput(sum_s_poly);
             /*
             rfmtput(p_mstl);
             */
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             /* �^�t�v */
             s_factor = sum_s_mdmg+sum_s_mthft_fac;
             rfmtput(s_factor);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body(1); max_count++;

             rgu_put_body_string(1,"�ؤ�",1);
             rfmtput(sum_r_mdmg);
             rgu_put_body_string(1," ",1);
             rfmtput(sum_r_mlia);
             rgu_put_body_string(1," ",1);
             rfmtput(sum_r_mthft_fac);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rfmtput(sum_n_mstl);
             rgu_put_body_string(1," ",1);
             /* �^�t�v */
             r_factor = sum_r_mdmg+sum_r_mlia+sum_r_mthft_fac+sum_n_mstl;
             rfmtput(r_factor);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body(1); max_count++;
        
             rgu_put_body_string(1,"�~�ר�",1);
             o_mdmg = sum_s_mdmg - sum_r_mdmg;
             rfmtput(o_mdmg);
             rgu_put_body_string(1," ",1);
             o_mlia = sum_s_mlia - sum_r_mlia;
             rfmtput(o_mlia);
             rgu_put_body_string(1," ",1);
             o_mthft_fac = sum_s_mthft_fac - sum_r_mthft_fac;
             rfmtput(o_mthft_fac);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             o_factor = o_mdmg + o_mlia + o_mthft_fac ;
             rfmtput(o_factor);
             rgu_put_body_string(1," ",1); 
             rgu_put_body_string(1," ",1); 
             rgu_put_body_string(1," ",1); 
             rgu_put_body(1); max_count++;


       rgu_finish_report();
       create_sign_form("car909",BodyFile, Width);
       if ((rc=save_form_info(F_BLK1,"CA",909,userid,FormTp,max_count,outputf))<0)
            EWRITE(userid,rc,"save_form_info_failed");

    return TRUE;
errexit:
  printf("car909_buildD:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  exit(FAIL);

}

long car909_buildG()
{
$double  s_mdmg,s_mlia,s_mthft_fac;
$double  r_mdmg,r_mlia,r_mthft_fac;
$double  o_mdmg,o_mlia,o_mthft_fac;
$double  s_mthft_per,s_moth,s_mproc;
$double  s_poly,r_poly;
$double  p_mdmg,p_mlia,p_mthft_fac;
$double  p_mthft_per,p_moth,p_mproc;
$double  s_mstl,p_mstl,n_mstl;
$char    tmp[20];
$double  s_factor,r_factor,o_factor;
$char    ibig_comp[2];
$int     i;

   $WHENEVER SQLERROR GOTO errexit;


       s_mdmg = s_mlia = s_mthft_fac = 0;
       r_mdmg = r_mlia = r_mthft_fac = 0;
       o_mdmg = o_mlia = o_mthft_fac = 0;
       s_mthft_per = s_moth = s_mproc = 0;
       s_poly = r_poly = 0;
       p_mdmg = p_mlia = p_mthft_fac = 0;
       p_mthft_per = p_moth = p_mproc = 0;
       s_mstl = p_mstl = n_mstl = 0;
       s_factor = r_factor = o_factor = 0;

       max_count = 0;
       printf("INTO buildG \n");
       sprintf(TitleFile, "%sG.ti", outputf);
       sprintf(BodyFile, "%sG.bd", outputf);

       rgu_init_report(TitleFmt, TitleFile);
       car909_title2();
       rgu_finish_report();

       rgu_init_report(BodyFmt, BodyFile);

       for(i=1 ; i<= 3; i++){

           if (i == 1){
               strcpy(ibig_comp,"B");
               strcpy(ngroup,"����");
           }else if (i == 2){
               strcpy(ibig_comp,"C");
               strcpy(ngroup,"���q");
           }else if (i == 3){
               strcpy(ibig_comp,"D");
               strcpy(ngroup,"�ؤ�");
           }

           printf("igroup[%s]\n",igroup);
           printf("ngroup[%s]\n",ngroup);   

           /* �X��U�I�ت��B  */

          $EXECUTE pidB3
              INTO $s_mdmg,$s_mlia,$s_mthft_fac,
                   $s_mthft_per,$s_moth,$s_mproc
             USING $ibig_comp;

           printf("s_mdmg[%f],s_mlia[%f],s_mthft_fac[%f],  \
                   s_mthft_per[%f],s_mproc[%f],s_moth[%f]\n",
                   s_mdmg,s_mlia,s_mthft_fac,s_mthft_per,
                   s_mproc,s_moth);         

          /* �X��U�I�ت��B�[�` */            
             s_poly = s_mdmg + s_mlia + s_mthft_fac +
                      s_mthft_per + s_mproc + s_moth;

           printf("s_poly[%f]\n",s_poly);
          /* �X��U�I�ئʤ��� */
             p_mdmg      = s_poly == 0 ? 0 : d45(100 * s_mdmg / s_poly , 2);
             p_mlia      = s_poly == 0 ? 0 : d45(100 * s_mlia / s_poly , 2);
             p_mthft_fac = s_poly == 0 ? 0 : d45(100 * s_mthft_fac / s_poly ,2);
             p_mthft_per = s_poly == 0 ? 0 : d45(100 * s_mthft_per / s_poly ,2);
             p_mproc     = s_poly == 0 ? 0 : d45(100 * s_mproc / s_poly ,2);
             p_moth      = s_poly == 0 ? 0 : d45(100 * s_moth / s_poly ,2);
       
           printf("p_mdmg[%f],p_mlia[%f],p_mthft_fac[%f],   \
                   p_mthft_per[%f],p_mproc[%f],p_moth[%f]\n",
                   p_mdmg,p_mlia,p_mthft_fac,p_mthft_per,
                   p_mproc,p_moth);         

             rgu_put_body_string(1,trim(ngroup),1);
             rfmtput(s_mdmg);
             rfmtput1(p_mdmg);
             rfmtput(s_mlia);
             rfmtput1(p_mlia);
             rfmtput(s_mthft_fac);
             rfmtput1(p_mthft_fac);
             rfmtput(s_mthft_per);
             rfmtput1(p_mthft_per);
             rfmtput(s_mproc);
             rfmtput1(p_mproc);
             rfmtput(s_moth);
             rfmtput1(p_moth);
             rfmtput(s_poly);
             /*
             rfmtput(p_mstl);
             */
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             /* �^�t�v */
             s_factor = s_mdmg+s_mthft_fac;
             rfmtput(s_factor);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body(1); max_count++;

          /* �b�g�P���q�X��B�^��ϳ����B */

          $EXECUTE pidD4
              INTO $r_mdmg,$r_mlia,$r_mthft_fac
             USING $ibig_comp,$ibig_comp;
      
          /* ���b�g�P���q�X����^��t���B */

          $EXECUTE pidE3
              INTO $n_mstl 
             USING $ibig_comp,$ibig_comp;
  
             printf("r_mdmg[%f],r_mlia[%f],r_mthft_fac[%f]\n",
                     r_mdmg,r_mlia,r_mthft_fac);
                    
             strcpy(ngroup,trim(ngroup));
             strcat(ngroup,"�t");
             rgu_put_body_string(1,ngroup,1);
             rfmtput(r_mdmg);
             rgu_put_body_string(1," ",1);
             rfmtput(r_mlia);
             rgu_put_body_string(1," ",1);
             rfmtput(r_mthft_fac);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rfmtput(n_mstl);
             rgu_put_body_string(1," ",1);
             /* �^�t�v */
             r_factor = r_mdmg+r_mlia+r_mthft_fac+n_mstl;
             rfmtput(r_factor);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body(1); max_count++;
        
             rgu_put_body_string(1,"�~�ר�",1);
             o_mdmg = s_mdmg - r_mdmg;
             rfmtput(o_mdmg);
             rgu_put_body_string(1," ",1);
             o_mlia = s_mlia - r_mlia;
             rfmtput(o_mlia);
             rgu_put_body_string(1," ",1);
             o_mthft_fac = s_mthft_fac - r_mthft_fac;
             rfmtput(o_mthft_fac);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             o_factor = o_mdmg + o_mlia + o_mthft_fac ;
             rfmtput(o_factor);
             rgu_put_body_string(1," ",1); 
             rgu_put_body_string(1," ",1); 
             rgu_put_body_string(1," ",1); 
             rgu_put_body(1); max_count++;

       }


       /* �}�l�C�X�X�p�� */


        sprintf(stmt,
         " SELECT NVL(SUM(mdmg),0),NVL(SUM(mlia),0),NVL(SUM(mthft_fac),0),   \
                  NVL(SUM(mthft_per),0),NVL(SUM(moth),0),NVL(SUM(mproc),0)   \
             FROM car9092                                                    \
            WHERE ibranch[1] IN ('B','C','D') ");
         $PREPARE pidB6 FROM $stmt;

          $EXECUTE pidB6
              INTO $s_mdmg,$s_mlia,$s_mthft_fac,
                   $s_mthft_per,$s_moth,$s_mproc;

          /* �X��U�I�ت��B�[�` */            
             s_poly = s_mdmg + s_mlia + s_mthft_fac +
                      s_mthft_per + s_mproc + s_moth;

           printf("s_poly[%f]\n",s_poly);
          /* �X��U�I�ئʤ��� */
             p_mdmg      = s_poly == 0 ? 0 : d45(100 * s_mdmg / s_poly , 2);
             p_mlia      = s_poly == 0 ? 0 : d45(100 * s_mlia / s_poly , 2);
             p_mthft_fac = s_poly == 0 ? 0 : d45(100 * s_mthft_fac / s_poly ,2);
             p_mthft_per = s_poly == 0 ? 0 : d45(100 * s_mthft_per / s_poly ,2);
             p_mproc     = s_poly == 0 ? 0 : d45(100 * s_mproc / s_poly ,2);
             p_moth      = s_poly == 0 ? 0 : d45(100 * s_moth / s_poly ,2);
       
           printf("p_mdmg[%f],p_mlia[%f],p_mthft_fac[%f],   \
                   p_mthft_per[%f],p_mproc[%f],p_moth[%f]\n",
                   p_mdmg,p_mlia,p_mthft_fac,p_mthft_per,
                   p_mproc,p_moth);         

             rgu_put_body_string(1,"�X�p",1);
             rfmtput(s_mdmg);
             rfmtput1(p_mdmg);
             rfmtput(s_mlia);
             rfmtput1(p_mlia);
             rfmtput(s_mthft_fac);
             rfmtput1(p_mthft_fac);
             rfmtput(s_mthft_per);
             rfmtput1(p_mthft_per);
             rfmtput(s_mproc);
             rfmtput1(p_mproc);
             rfmtput(s_moth);
             rfmtput1(p_moth);
             rfmtput(s_poly);
             /*
             rfmtput(p_mstl);
             */
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             /* �^�t�v */
             s_factor = s_mdmg+s_mthft_fac;
             rfmtput(s_factor);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body(1); max_count++;

        sprintf(stmt,
         " SELECT NVL(SUM(mdmg),0),NVL(SUM(mlia),0),NVL(SUM(mthft_fac),0)   \
             FROM car9092                                                   \
            WHERE ibranch[1] IN ('B','C','D')                               \
              AND ibig_comp IN ('B','C','D')  ");
         $PREPARE pidD6 FROM $stmt;

         $EXECUTE pidD6
             INTO $r_mdmg,$r_mlia,$r_mthft_fac;

        sprintf(stmt,
         " SELECT NVL(SUM(mdmg+mlia+mthft_fac),0)      \
             FROM car9092                              \
            WHERE ifactory[1] IN ('B','C','D')         \
              AND ibranch[1] NOT IN ('B','C','D')  ");
         $PREPARE pidE6 FROM $stmt;

         $EXECUTE pidE6 INTO $n_mstl;


             printf("r_mdmg[%f],r_mlia[%f],r_mthft_fac[%f]\n",
                     r_mdmg,r_mlia,r_mthft_fac);
                    
             /*
             strcpy(ngroup,trim(ngroup));
             strcat(ngroup,"�t");
             */
             rgu_put_body_string(1,"����",1);
             rfmtput(r_mdmg);
             rgu_put_body_string(1," ",1);
             rfmtput(r_mlia);
             rgu_put_body_string(1," ",1);
             rfmtput(r_mthft_fac);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rfmtput(n_mstl);
             rgu_put_body_string(1," ",1);
             /* �^�t�v */
             r_factor = r_mdmg+r_mlia+r_mthft_fac+n_mstl;
             rfmtput(r_factor);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body(1); max_count++;
        
             rgu_put_body_string(1,"�~�ר�",1);
             o_mdmg = s_mdmg - r_mdmg;
             rfmtput(o_mdmg);
             rgu_put_body_string(1," ",1);
             o_mlia = s_mlia - r_mlia;
             rfmtput(o_mlia);
             rgu_put_body_string(1," ",1);
             o_mthft_fac = s_mthft_fac - r_mthft_fac;
             rfmtput(o_mthft_fac);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             rgu_put_body_string(1," ",1);
             o_factor = o_mdmg + o_mlia + o_mthft_fac ;
             rfmtput(o_factor);
             rgu_put_body_string(1," ",1); 
             rgu_put_body_string(1," ",1); 
             rgu_put_body_string(1," ",1); 
             rgu_put_body(1); max_count++;

       rgu_finish_report();
       create_sign_form("car909",BodyFile, Width);
       if ((rc=save_form_info(F_BLK1,"CA",909,userid,FormTp,max_count,outputf))<0)
            EWRITE(userid,rc,"save_form_info_failed");

    return TRUE;
errexit:
  printf("car909_buildD:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  exit(FAIL);
}

long car909_build1()
{
   $char   FullName[20];
   int     paid,unpaid,paid_proc,app_cnt;
   $int    mins_app,mins_stl,mins_proc;
   long    mdmg_close,mdmg_uclose,mthft_close,mthft_uclose;
   long    mlia_close,mlia_uclose,moth_close,moth_uclose,code;
   $char   fclose;
   $char   iins_type[INSURANCE_TYPE],factory[11],fcard_class[2],acc_reason[3],thft_nme[9];
   $char   factory_1[11],factory_2[11],factory32_1[11],factory32_2[11],
           factory32_3[11],factory32_4[11];
   $long   dgroup,fac_app_1,fac_app_2,fac_app32_1,fac_app32_2,fac_app32_3,
           fac_app32_4;
   double  mstl_dend;
   int     flag_close_dend;
   $char   ibigcomp[2];
   $char   sFull[30];
   $date   Today;
   $char cToday[11];
   $char buf1[50],buf2[100],buf3[30],date_buf[200],buf4[30];
   $char ofacname_10[11], ofacname_30[31];
   

   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return FAIL;
   }
   
   Today=cm_today();

       
   $CREATE TEMP TABLE car9092
    (
     ibig_comp       char(1),
     ibranch         char(3),
     ifactory        char(10),
     mdmg            decimal(17,0) default 0 ,
     mlia            decimal(17,0) default 0 ,
     mthft_fac       decimal(17,0) default 0 ,
     mthft_per       decimal(17,0) default 0 ,
     moth            decimal(17,0) default 0 ,
     mproc           decimal(17,0) default 0 
    )WITH NO LOG;
               

   $SELECT nform_file,ntitle_fmt, nbody_fmt, kstart_row, ktitle_row,
           ktot_col, kpgnum_line, kwidth, iform_tp
      INTO $FormFmt, $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width, $FormTp
      FROM Form
     WHERE ksys_grp = "CA" AND kPgmID = 909 AND iForm_tp = '1';

   mins_proc = 0;
   paid_proc = 0;

   strcpy(TitleFmt, rtrim(TitleFmt));
   strcpy(BodyFmt, rtrim(BodyFmt));

   if (Reportkind[0] != '2'){
       sprintf(TitleFile, "%s.ti", outputf);
       sprintf(BodyFile, "%s.bd", outputf);
   }else{
       sprintf(TitleFile, "%sA.ti", outputf);
       sprintf(BodyFile, "%sA.bd", outputf);
   }

   printf("TitleFmt[%s]\n",TitleFmt);
   printf("BodyFmt[%s]\n",BodyFmt);
   printf("TitleFile[%s]\n",TitleFile);
   printf("BodyFile[%s]\n",BodyFile);
   
   rgu_init_report(TitleFmt, TitleFile);
   car909_title1();
   rgu_finish_report();

   rgu_init_report(BodyFmt, BodyFile);

   /*
   strcpy(FormFmt, rtrim(FormFmt));
   sprintf(FormFile, "%s.tx", outputf);
   rgu_init_report(FormFmt,FormFile);
   car909_title();
   */

   $WHENEVER SQLERROR GOTO errexit;


    sprintf(stmt,
   " SELECT branch            \
       FROM servertbl         \
      WHERE branch != 'S1'    \
        %s                    \
      ORDER BY branch ",sWhere1);

   $PREPARE sid1  FROM $stmt;
   $DECLARE s_cur CURSOR FOR sid1;
   $OPEN s_cur;
   for(;;){
   $FETCH s_cur INTO $sBranch;
   if (SQLCODE == SQLNOTFOUND) break;

       strcpy(sFull,get_full_dbname(sBranch));

             sprintf(stmt,
           "  SELECT nassured[1,40],itag   \
                FROM %s:policy             \
               WHERE ipolicy = ? ",sFull);
            $PREPARE sid3 FROM $stmt;

             sprintf(stmt,
           "  SELECT nname                 \
                FROM officer               \
               WHERE iofficer = ? ");
            $PREPARE sid4 FROM $stmt;

             sprintf(stmt,
            " SELECT iins_type,mins_app   \
                FROM %s:app_ins_type      \
               WHERE iclaim = ? ",sFull) ;
            $PREPARE sid5 FROM $stmt;
            $DECLARE Acursor6 CURSOR FOR sid5;

             sprintf(stmt,
           "  SELECT mins_stl,dgroup,mins_proc      \
                FROM %s:stl_ins_type                \
               WHERE iclaim = ?                     \
                 AND fstl = '1'                     \
                 AND iins_type = ?                  \
                 AND dgroup IS NOT NULL ",sFull);

            $PREPARE sid6 FROM $stmt;
            $DECLARE Acursor7 CURSOR FOR sid6;
            
        if (strncmp(type_date,"0",1)==0)
          {sprintf(date_buf,"WHERE date(a.daccident) >= '%s' AND date(a.daccident) <= '%s' ",clsdatebgn,clsdateend);
           /*sprintf(buf3," "); 
           sprintf(buf4," ");      �s�W�鵲�����*/
		   sprintf(buf3,", ca_clm_process x " ); 
           sprintf(buf4," AND a.iclaim = x.iclaim "); }
        else
          {sprintf(date_buf,"WHERE x.dclose >= '%s' AND x.dclose <= '%s' ",clsdatebgn,clsdateend);
           sprintf(buf3,", ca_clm_process x " ); 
           sprintf(buf4," AND a.iclaim = x.iclaim "); }
           
        if (strncmp(type,"1",1)==0 )
          {
            sprintf(buf1,", %s:policy e",sFull);
            sprintf(buf2,"AND c.ipolicy=e.ipolicy AND e.iassured ='%s' ",trim(con_str));    
          }
        else if(strncmp(type,"2",1)==0 )
          {sprintf(buf1," ");
           sprintf(buf2,"AND c.iofficer = '%s' ",trim(con_str));
          }
        else if (strncmp(type,"3",1)==0 )
          {sprintf(buf1," ");
           sprintf(buf2,"AND c.iquota matches '%s' ",trim(con_str));
          }
        else
          { sprintf(buf1," ");
            sprintf(buf2," ");
           }

    printf("buf1=[%s] \n buf2=[%s] \n buf3=[%s]\n buf4=[%s] \n",buf1,buf2,buf3,buf4);
    printf("con_str=[%s]\n",con_str);

        sprintf(stmt,
        "  SELECT date(a.daccident),a.iclaim,c.icard,c.iofficer,d.nname,c.ibig_office,            \
                  a.factory,a.fcard_class,a.iacc_reason,c.iquota[1,4],a.factory_1,a.fac_app_1,    \
                  a.factory_2,a.fac_app_2,a.factory32_1,fac_app32_1,factory32_2,                  \
                  fac_app32_2,factory32_3,fac_app32_3,factory32_4,fac_app32_4,                    \
                  c.dply_begin,c.ipolicy,c.ibig_sales,c.ibrand,a.iadjuster,c.ibig_comp,           \
                  NVL(x.dclose,' '), a.ofacname[1,10], a.ofacname[1,30]                           \
                  FROM %s:appraisal a ,%s:ply_relation c,%s:officer d %s  %s  %s                  \
                  AND a.fcard_class = '2'                                                         \
                  AND a.ipolicy  = c.ipolicy  %s                                                    \
                  AND c.iofficer = d.iofficer %s                                                 \
                  ORDER BY c.iofficer,a.iclaim ",sFull ,
                                                 sFull ,
                                                 sFull ,
                                                 buf1,buf3,date_buf,buf4,buf2    );
                  

         
  printf("###stmt=[%s] \n",stmt);
           
         $PREPARE sid2 FROM $stmt;
         $DECLARE Acursor5 CURSOR FOR sid2;
         $OPEN Acursor5;

         while (1)
         {
             $FETCH Acursor5 INTO $daccident,$iclaim,$icard,$iofficer,$nname,$ibig_office,
                                  $factory,$fcard_class,$acc_reason,$iquota,
                                  $factory_1,$fac_app_1,
                                  $factory_2,$fac_app_2,$factory32_1,$fac_app32_1,
                                  $factory32_2,$fac_app32_2,$factory32_3,$fac_app32_3,
                                  $factory32_4,$fac_app32_4,$dply_begin,$ipolicy,$ibig_sales,
                                  $ibrand,$iadjuster,$ibigcomp,$dclose, $ofacname_10, $ofacname_30;

             if (SQLCODE == SQLNOTFOUND) break;

            $EXECUTE sid3
                INTO $nassured,$itag
               USING $ipolicy;

            $EXECUTE sid4
                INTO $iadjuster_name
               USING $iadjuster;

             printf("ipolicy[%s],nassured[%s],ibig_sales[%s],iadjuster_name[%s],ibrand[%s]iofficer[%s]ibig_comp[%s]\n",
                     ipolicy  ,  nassured  ,  ibig_sales  ,  iadjuster_name  ,  ibrand,   iofficer,   ibigcomp);

             printf("dply_begin[%ld]\n",dply_begin);

             /**���ͫO��ͮĦ~***/
             strcpy(cply_begin,cm_cdate_str_100(dply_begin));
             cm_split_ymd_100(cply_begin,cy,cm,cd);

             sprintf(iquota0,"%s00",trim(iquota));
             manufactor[0]='\0';
             /****Ū�����ӦW��****/

             if (strlen(trim(ibigcomp)) != 0) {
                /*strcpy(officer13,substring(iofficer,1,3));
                if (iofficer[0] == 'F')
                   strcpy(manufactor,"�֯S");
                else if (iofficer[0] == 'E')
                   strcpy(manufactor,"�ζ�");
                else {
                   $ SELECT ngroup
                       INTO $manufactor
                       FROM sa_frm_module
                      WHERE ifrm_module = "02"
                        AND igroup = $iofficer[0];
                    if (SQLCODE == SQLNOTFOUND) strcpy(manufactor," ");
                }
                $SELECT ngroup
                   INTO $ngroup
                   FROM sa_frm_module
                  WHERE ifrm_module = "02"
                    AND igroup = $officer13;*/
				$SELECT nlevel3, nlevel4
				INTO $manufactor,$ngroup
				FROM v_channel
				WHERE icode = $iofficer;
				if (SQLCODE == SQLNOTFOUND) strcpy(manufactor," ");
				
             }
             else {
                strcpy(officer13,iofficer);
                $SELECT nbranch
                   INTO $ngroup
                   FROM sa_branch_type
                  WHERE ibranch = $iquota0;
             }

             /* 0991130001�~�N�m�W */
             if (get_route_data(1,iofficer,ibig_office,ibig_sales,nsales,stmt) != M_CM_OK) strcpy(nsales, " ");


             mdmg_close = mdmg_uclose = mthft_close = mthft_uclose = mlia_close
                        = mlia_uclose = moth_close  = moth_uclose  = 0;

             /******�P�_�w�M�Υ��M(�Ϥ����l�A�ѵs�A�]�l�A�N�~,�O��*********/

             $OPEN Acursor6 USING $iclaim;
             while (1)
             {
                 $FETCH Acursor6 INTO $iins_type,$mins_app;

                 if (SQLCODE == SQLNOTFOUND) break;

                 /****** flag_close_dend = 1 �w���סA0--���� *****/

                 if (strcmp(trim(iins_type),"51")==0)
                     continue;
                 if (strcmp(trim(iins_type),"11") == 0)
                     if (strncmp(acc_reason,"21",2)==0)
                         strcpy(thft_nme,"�㨮�Q��");
                     else if (strncmp(acc_reason,"23",2)==0)
                         strcpy(thft_nme,"�M�^�״_");
                     else if (strncmp(acc_reason,"24",2)==0)
                         strcpy(thft_nme,"�ѵs���E");

                 if (strcmp(trim(iins_type),"12") == 0 || strcmp(trim(iins_type),"28") == 0)
                     strcpy(thft_nme,"�s��Q��");

                 code = ca_calc_info_msettle(sBranch,fcard_class,
                                             iclaim, iins_type, " ", Today,
                                             &mstl_dend, &flag_close_dend);
                 printf("dbname[%s],iclaim[%s],fcard_class[%s],iins[%s] ,flag[%d]\n",
                         sBranch  ,  iclaim  ,  fcard_class  ,  iins_type,flag_close_dend);

                 /***�p��w�M���B*******/
                 paid = 0;
                 paid_proc = 0;

                 $OPEN    Acursor7 USING $iclaim,$iins_type;
                 while (1)
                 {
                     $FETCH Acursor7 INTO $mins_stl,$dgroup,$mins_proc;
                     printf("lDend------->[%d]\n",lDend);
                     printf("dgroup------->[%d]\n",dgroup);
printf("  55555555555555555555  mins_stl[%ld] \n" ,mins_stl);
                     if (SQLCODE == SQLNOTFOUND) break;
printf("  55555555555555555555  dgroup[%ld] \n" ,dgroup);
printf("  55555555555555555555  cm_today[%ld] \n" ,cm_today() );
                     if (dgroup <= cm_today() )
                     {
printf("   66666666666666666666    paid[%ld] \n",paid);                  	
                        paid += mins_stl;
                        paid_proc += mins_proc;
                     }
                 }
                 $CLOSE  Acursor7;

                 /******�p�⥼�M���B***********/
                 printf("bef out stl paid_proc[%d]\n",paid_proc);
                 printf("out_stl begin\n");
 printf(" 66666666666666666666666  flag_close_dend[%d] \n" ,flag_close_dend);                 
                 if (flag_close_dend == 1)
                     unpaid = 0;
                 else
                 {
               	
                     unpaid = mins_app - paid;
 printf("666666666666666666 unpaid [%ld]\n" , unpaid );                        
                     if (unpaid < 0 )
                         unpaid = 0;
                 }

                 dmg_cnt_tp1 = 0;
                 $select count(*) 
                    into $dmg_cnt_tp1
                    from cu_code_data
                   where itype = 'CT'
                     and icode = $iins_type;

                 /*****
                 if((strcmp(trim(iins_type),"01")==0)||(strcmp(trim(iins_type),"02")==0)||
                    (strcmp(trim(iins_type),"03")==0)||(strcmp(trim(iins_type),"04")==0)||
                    (strcmp(trim(iins_type),"05")==0)||(strcmp(trim(iins_type),"09")==0)||
                    (strcmp(trim(iins_type),"81")==0)||(strcmp(trim(iins_type),"08")==0) )
                 *****/
                 if (dmg_cnt_tp1 > 0)
                 {
                           mdmg_close     += paid ;
                           mdmg_uclose    += unpaid;
                 }

                 else if((strcmp(trim(iins_type),"11")==0)||(strcmp(trim(iins_type),"12")==0)||
                         (strcmp(trim(iins_type),"13")==0)||(strcmp(trim(iins_type),"82")==0)||
                         (strcmp(trim(iins_type),"14")==0)||(strcmp(trim(iins_type),"28")==0))
                 {
                           mthft_close    += paid ;
                           mthft_uclose   += unpaid;
                 }
                 else if(strcmp(trim(iins_type),"32")==0)
                 {
                           mlia_close     += paid ;
                           mlia_uclose    += unpaid;
                 }
                 else
                 {
printf(" 7777777777777777777777   moth_close[%ld] ,  moth_uclose[%ld] \n",  moth_close, moth_uclose);       	
                           moth_close     += paid;
                           moth_uclose    += unpaid;
                 }

             }
             $CLOSE Acursor6;

             /***************Ū��payment*********************/
             printf("paid_proc [%d]\n",paid_proc);
             printf("mdmg_close[%d],mdmg_uclose[%d]\n",mdmg_close,mdmg_uclose);
             if(mdmg_close != 0 || mdmg_uclose != 0)
             {
                 if (mdmg_close != 0)
                 {
                     sprintf(stmt,"SELECT nchi_full,mpayment,ipayment    \
                                     FROM %s:payment                     \
                                    WHERE iclaim = '%s' AND fstl = '1'      \
                                      AND pay_kind = '1' ",sFull , iclaim);
                     printf("payment_read--->mdmg bgn\n");
                     payment_read("���l",0,mdmg_close,mdmg_uclose);
                     printf("payment_read--->mdmg end\n");
                 }
                 else
                 {
                     /****** ����w���M���B�L�@���Y�i************/
                     app_cnt = 0;
                     if (strlen(trim(factory_1)) !=0)
                     {
                        app_put_body("���l",mdmg_uclose,factory_1,app_cnt,fac_app_1," ");
                        app_cnt += 1;
                     }
                     if (strlen(trim(factory_2)) !=0)
                     {
                        app_put_body("���l",mdmg_uclose,factory_2,app_cnt,fac_app_2," ");
                        app_cnt += 1;
                     }
                     if (strlen(trim(ofacname_10)) !=0)
                     {
                        app_put_body("���l",mdmg_uclose,ofacname_10,app_cnt,0,ofacname_30);
                        app_cnt += 1;
                     }
                     if(app_cnt ==0)
                        app_put_body("���l",mdmg_uclose,factory,app_cnt,mdmg_uclose," ");

                 }
             }
             printf("mthf_close[%d],mthf_uclose[%d]\n",mthft_close,mthft_uclose);

             if(mthft_close != 0 || mthft_uclose != 0)
             {
                 if (mthft_close != 0)
                 {
                     sprintf(stmt,"SELECT nchi_full,mpayment,ipayment             \
                                     FROM %s:payment                              \
                                    WHERE iclaim = '%s'                              \
                                      AND fstl = '1'                              \
                                      AND pay_kind = '2' ",sFull , iclaim);
                     payment_read(thft_nme,0,mthft_close,mthft_uclose);
                 }
                 else
                 {
                     app_cnt = 0;
                     if (strlen(trim(factory_1)) !=0)
                     {
                        app_put_body(thft_nme,mthft_uclose,factory_1,app_cnt,fac_app_1," ");
                        app_cnt += 1;
                     }

                     if (strlen(trim(factory_2)) !=0)
                     {
                        app_put_body(thft_nme,mthft_uclose,factory_2,app_cnt,fac_app_2," ");
                        app_cnt += 1;
                     }

                     if (strlen(trim(ofacname_10)) !=0)
                     {
                        app_put_body(thft_nme,mthft_uclose,ofacname_10,app_cnt,0,ofacname_30);
                        app_cnt += 1;
                     }

                     if (app_cnt == 0)
                       app_put_body(thft_nme,mthft_uclose,factory,app_cnt,mthft_uclose," ");
                 }
             }
             printf("mlia_close[%d],mlia_uclose[%d]\n",mlia_close,mlia_uclose);

             if(mlia_close != 0 || mlia_uclose != 0)
             {
                  if (mlia_close != 0)
                  {
                      sprintf(stmt,"SELECT nchi_full,mpayment,ipayment     \
                                      FROM %s:payment                      \
                                     WHERE iclaim = '%s'                      \
                                       AND fstl = '1'                      \
                                       AND pay_kind = '3' ",sFull ,iclaim  );
                      payment_read("�]�l",0,mlia_close,mlia_uclose);
                  }
                  else
                  {
                      app_cnt = 0;
                      if (strlen(trim(factory32_1)) !=0)
                      {
                          app_put_body("�]�l",mlia_uclose,factory32_1,app_cnt,fac_app32_1," ");
                          app_cnt += 1;
                      }

                      if (strlen(trim(factory32_2)) !=0)
                      {
                          app_put_body("�]�l",mlia_uclose,factory32_2,app_cnt,fac_app32_2," ");
                          app_cnt += 1;
                      }

                      if (strlen(trim(factory32_3)) !=0)
                      {
                          app_put_body("�]�l",mlia_uclose,factory32_3,app_cnt,fac_app32_3," ");
                          app_cnt += 1;
                      }

                      if (strlen(trim(factory32_4)) !=0)
                      {
                          app_put_body("�]�l",mlia_uclose,factory32_4,app_cnt,fac_app32_4," ");
                          app_cnt += 1;
                      }

                      if (strlen(trim(ofacname_10)) !=0)
                      {
                          app_put_body("�]�l",mlia_uclose,ofacname_10,app_cnt,0,ofacname_30);
                          app_cnt += 1;
                      }
                      if (app_cnt == 0)
                          app_put_body("�]�l",mlia_uclose,factory,app_cnt,mlia_uclose," ");
                  }
             }

             if(moth_close != 0 || moth_uclose !=0)
             {
                 if (moth_close != 0)
                 {
                     sprintf(stmt,"SELECT nchi_full,mpayment,ipayment   \
                                     FROM %s:payment                    \
                                    WHERE iclaim = '%s'                    \
                                      AND fstl = '1'                    \
                                      AND pay_kind = '5' ",sFull  ,iclaim);
printf(" 0000000000000000 moth_close[%ld] , moth_uclose [%ld] \n",moth_close , moth_uclose );                                      
                     payment_read("���",0,moth_close,moth_uclose);
printf(" 111111111111111111 \n");                     
                 }
                 else
                 {
                      app_cnt = 0;
                      app_put_body("���",moth_uclose," ",app_cnt,0," ");
                 }
             }

             
             if (paid_proc != 0)
             {
                     sprintf(stmt,"SELECT nchi_full,mpayment,ipayment   \
                                     FROM %s:payment                    \
                                    WHERE iclaim = '%s'                    \
                                      AND fstl = '1'                    \
                                      AND pay_kind = '4' ",sFull , iclaim  );

                     printf("INTO STMT paid_proc [%d]\n",paid_proc);

                     payment_read("�O��",0,paid_proc,0);

             }

         }
         $CLOSE Acursor5;
         $FREE Acursor5;
   }
   $CLOSE s_cur;
   $FREE  s_cur;
            
   if (max_count == 0)
   {
      EWRITE(userid, M_CM_NOT_FOUND, "no data found in [car908_tmp] !!");
      return FAIL;
   }

   rgu_finish_report();
   return SUCCESS;

errexit:
  printf("build:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  exit(FAIL);
}

void payment_read(type,cnt,mclose,muclose)
char type[5];
int  cnt;
long mclose,muclose;
{
    $char payment_13[4];
    $char ibig_comp[2];
    $long dMstl ;

     printf("stmt [%s]\n",stmt);
    $PREPARE stmt_p   FROM    $stmt;
    $DECLARE Acursor8 CURSOR  FOR stmt_p;
    $OPEN Acursor8;
    while (1)
    {
       $FETCH Acursor8 INTO $nchi_full,$mpayment,$ipayment;
       if (SQLCODE == SQLNOTFOUND) 
            break;
       /*Ū���ר��t���ݸg�P�ӡB�ϳ�*/
       $SELECT     ibig_branch ,ibig_comp
          INTO     $payment_13 , $ibig_comp
          FROM     cu_stl_obj
         WHERE     ifpce_id =  $ipayment
           AND     ifpce_id_ext = ' ';

       if (SQLCODE)
          strncpy(payment_13,ipayment,3);

       /* �P�@�ߥI���O�A�w���M��C�L�@�� */
       if (cnt > 0)
       {
         mclose  = 0;
         muclose = 0;
       }
       rgu_put_body_string(9,manufactor,1); 
       rgu_put_body_string(9,ngroup,1);
       rgu_put_body_string(9,officer13,1);
       rgu_put_body_string(9,nname,1);
       rgu_put_body_string(9,ibig_sales,1);
       rgu_put_body_string(9,nsales,1);
       rgu_put_body_string(9,ipolicy,1);
       rgu_put_body_string(9,icard,1);
       rgu_put_body_string(9,nassured,1);
       rgu_put_body_string(9,ibrand,1);
       rgu_put_body_string(9,itag,1);
       rgu_put_body_string(9,trim(iclaim),1);
       rgu_put_body_string(9,iadjuster_name,1);
       rgu_put_body_string(9,trim(daccident),1);
       rgu_put_body_string(9,type,1);
       rfmtlong(mclose, "---,---,--&", buf);
       rgu_put_body_string(9,buf,1);
       rfmtlong(muclose, "---,---,--&", buf);
       rgu_put_body_string(9,buf,1);
       rgu_put_body_string(9,payment_13,1);
       rgu_put_body_string(9,trim(nchi_full),1);
       rfmtlong(mpayment, "---,---,--&", buf);
       rgu_put_body_string(9,buf,1);
       printf("mpayment-----[%s]\n",buf);
       rgu_put_body_string(9,cy,1);
	   rgu_put_body_string(9,dclose,1);
       rgu_put_body(9); 
       max_count += 1;
       cnt += 1;
       
       printf( " 3333333333333 mclose[%ld] , muclose[%ld] \n", mclose,muclose );
       dMstl = mclose + muclose;

       /*
       printf("BEF INTO InsTemp FOR payment_read \n "); 
       printf("ibig_comp[%s],officer13[%s],payment_13[%s], \
               dMstl[%f],type[%s]\n",ibig_comp,officer13,payment_13,dMstl,type);
       */
       printf(" 4444444444444444  dMstl[%ld] type[%s] \n",dMstl, type);
       InsTemp(ibig_comp,officer13,payment_13,dMstl,type);

    }
    $CLOSE Acursor8;
    $FREE  Acursor8;

    /* �Y cnt == 0 �h�䤣�� ipayment �����i�q�X�� */

    if (cnt == 0)
    {

        printf("INTO payment count = 0 iclaim[%s]\n",iclaim);
        rgu_put_body_string(9,manufactor,1); 
        rgu_put_body_string(9,ngroup,1);
        rgu_put_body_string(9,officer13,1);
        rgu_put_body_string(9,nname,1);
        rgu_put_body_string(9,ibig_sales,1);
        rgu_put_body_string(9,nsales,1);
        rgu_put_body_string(9,ipolicy,1);
        rgu_put_body_string(9,icard,1);
        rgu_put_body_string(9,nassured,1);
        rgu_put_body_string(9,ibrand,1);
        rgu_put_body_string(9,itag,1);
        rgu_put_body_string(9,trim(iclaim),1);
        rgu_put_body_string(9,iadjuster_name,1);
        rgu_put_body_string(9,trim(daccident),1);
        rgu_put_body_string(9,type,1);
        rfmtlong(mclose, "---,---,--&", buf);
        rgu_put_body_string(9,buf,1);
        rfmtlong(muclose, "---,---,--&", buf);
        rgu_put_body_string(9,buf,1);
        rgu_put_body_string(9,payment_13,1);
        rgu_put_body_string(9,trim(nchi_full),1);
        rfmtlong(mpayment, "---,---,--&", buf);
        rgu_put_body_string(9,buf,1);
        printf("mpayment-----[%s]\n",buf);
        rgu_put_body_string(9,cy,1);
		rgu_put_body_string(9,dclose,1);
        rgu_put_body(9);
        max_count += 1;
       /*
       InsTemp(ibig_comp,officer13,payment_13,dMstl,type);
       */
    }
    return;

errexit:
  printf("payment_read:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  exit(FAIL);
}


void app_put_body(ap_pay_kind,ap_munclose,ap_nchi,app_cnt,mfix,ofacname)
$char  ap_pay_kind[5],app_cnt;
$long  ap_munclose,mfix;
$char ap_nchi[11];
$char ofacname[31];
{
      $char ap_chi_full[101];
      $char ibig_comp[2];
      $char ibig_branch[5];
 
      ap_chi_full[0] = '\0';
      if(strcmp(ap_nchi,"AAAAAA") == 0)
          strcpy(ap_chi_full,"�@��ר��t");
      else if (ap_nchi[0] > 'Z' || ap_nchi[0] < 'A')
      {
          if (strlen(trim(ofacname))!=0) strcpy(ap_chi_full,ofacname);
          else strcpy(ap_chi_full,ap_nchi);
      }
      else if (strlen(trim(ap_nchi))!=0)
          $SELECT nchi_full
          INTO $ap_chi_full
          FROM cu_customer
          WHERE ifpce_id = $ap_nchi
            AND ifpce_id_ext = ' ' ;

      /****���M���B�u�C�L�@��***********/
      if(app_cnt > 0) 
        ap_munclose = 0;

      rgu_put_body_string(9,manufactor,1);
      rgu_put_body_string(9,ngroup,1);
      rgu_put_body_string(9,officer13,1);
      rgu_put_body_string(9,nname,1);
      rgu_put_body_string(9,ibig_sales,1);
      rgu_put_body_string(9,nsales,1);
      rgu_put_body_string(9,ipolicy,1);
      rgu_put_body_string(9,icard,1);
      rgu_put_body_string(9,nassured,1);
      rgu_put_body_string(9,ibrand,1);
      rgu_put_body_string(9,itag,1);
      rgu_put_body_string(9,trim(iclaim),1);
      rgu_put_body_string(9,iadjuster_name,1);
      rgu_put_body_string(9,trim(daccident),1);
      rgu_put_body_string(9,ap_pay_kind,1);
      rfmtlong(0,"---,---,--&", buf);
      rgu_put_body_string(9,buf,1);
      rfmtlong(ap_munclose, "---,---,--&", buf);
      rgu_put_body_string(9,buf,1);
      /****ñ���O�׼t��X���ݸg�P�ӡB�ϳ�***/
      if (ap_nchi[0] >= 'A' && ap_nchi[0] <= 'Z')
      {
          $SELECT     ibig_branch,ibig_comp
             INTO     $ibig_branch,$ibig_comp
             FROM     cu_stl_obj
            WHERE     ifpce_id =  $ap_nchi
              AND     ifpce_id_ext = ' ';

          if (SQLCODE)
               ap_nchi[0] = '\0';
      }
      else{
           ap_nchi[0] = '\0';
           strcpy(ibig_branch," ");
           strcpy(ibig_comp," ");
      }
      rgu_put_body_string(9,ibig_branch,1);
      rgu_put_body_string(9,ap_chi_full,1);
      rfmtlong(0, "---,---,--&", buf);
      rgu_put_body_string(9,buf,1);
      rgu_put_body_string(9,cy,1);
	  rgu_put_body_string(9,dclose,1);
      rgu_put_body(9);
      max_count += 1;


      /*
      printf("BEF INTO InsTemp FOR app_put_body\n");
      printf("ibig_comp[%s],officer13[%s],ap_nchi[%s],ap_munclose[%ld],  \
              ap_pay_kind[%s]\n",
              ibig_comp,officer13,ap_nchi,ap_munclose,ap_pay_kind);
      */

      InsTemp(ibig_comp,officer13,ap_nchi,ap_munclose,ap_pay_kind);
      return;

errexit:
  printf("ap_put_body:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  exit(FAIL);

}


long car909_title1()
{
   char yy[4], mm[3], dd[3], buf[11];

   rgu_put_head_string(1, cm_sysd_cdate_100(cm_get_sysd()));
   cm_split_ymd_100(cls_datebgn, yy, mm, dd);
   rgu_put_head_string(1,yy);
   rgu_put_head_string(1,mm);
   rgu_put_head_string(1,dd);

   cm_split_ymd_100(cls_dateend, yy, mm, dd);
   rgu_put_head_string(1,yy);
   rgu_put_head_string(1,mm);
   rgu_put_head_string(1,dd);
   rgu_put_head();

}


long car909_title2()
{
   char yy[4], mm[3], dd[3], buf[11];

   rgu_put_head_string(1, cm_sysd_cdate_100(cm_get_sysd()));
   cm_split_ymd_100(cls_datebgn, yy, mm, dd);
   rgu_put_head_string(1,yy);
   rgu_put_head_string(1,mm);
   rgu_put_head_string(1,dd);

   cm_split_ymd_100(cls_dateend, yy, mm, dd);
   rgu_put_head_string(1,yy);
   rgu_put_head_string(1,mm);
   rgu_put_head_string(1,dd);
   rgu_put_head();

}



void InsTemp(xIbig_comp,xIbranch,xIfactory,xMstl,xType)
$char   xIbig_comp[2],xIbranch[4];
$char   xIfactory[11];
$long   xMstl ;
$char   xType[20];
{
$double mdmg,mlia,mthft_fac;
$double mthft_per,moth,mproc;

$double mdmg_pay,mlia_pay,mthft_fac_pay;


   $WHENEVER SQLERROR GOTO errexit;

    printf("INTO InsTemp\n");
    printf("xMstl[%ld]\n",xMstl); 
    printf("xType[%s]\n",xType);
printf(" *00000000000000000000 \n");
        mdmg = mlia = mthft_fac = 0;
printf(" 0101010101010101010101 \n");        
        mthft_per = moth = mproc = 0;
printf(" 11111111111111111111111 \n");
    if (strncmp(xType,"���l",4) == 0){
        mdmg      = xMstl;
    }
    else if (strncmp(xType,"�]�l",4) == 0){
        mlia      = xMstl;
    }
    else if (strncmp(xType,"�s��Q��",8) == 0)
        mthft_fac = xMstl;
    else if (strncmp(xType,"�㨮�Q��",8) == 0)
        mthft_per = xMstl;
    else if (strncmp(xType,"�M�^�״_",8) == 0){
        mthft_fac = xMstl;
    }
    else if (strncmp(xType,"�ѵs���E",8) == 0){
        mthft_fac = xMstl;
    }
    else if (strncmp(xType,"���",4) == 0)
        moth      = xMstl;
    else if (strncmp(xType,"�O��",4) == 0)
        mproc     = xMstl;
    else{

        mdmg = mlia = mthft_fac = 0;
        mthft_per = moth = mproc = 0;
    }

printf(" *********************************\n");
     printf("xIbig_comp[%s],xIbranch[%s],xIfactory[%s],       \
             mdmg[%f],mlia[%f],mthft_fac[%f],mthft_per[%f],   \
             moth[%f],mproc[%f]\n",xIbig_comp,xIbranch,xIfactory,
                                   mdmg,mlia,mthft_fac,
                                   mthft_per,moth,mproc);     
 
    $INSERT INTO car9092
      VALUES ($xIbig_comp,$xIbranch,$xIfactory,
              $mdmg,$mlia,$mthft_fac,$mthft_per,
              $moth,$mproc);

    /*
    $INSERT INTO car9092_TEMP
      VALUES ($xIbig_comp,$xIbranch,$xIfactory,
              $mdmg,$mlia,$mthft_fac,$mthft_per,
              $moth,$mproc);
    */
    return ;

errexit:
  printf("InsTemp FAIL:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  exit(FAIL);

}

void rfmtput(ff)
double ff;
{
char  ss[20];

   rfmtdouble(ff,fmt,ss);
   rgu_put_body_string(1,trim(ss),2);

}

void rfmtput1(ff1)
double ff1;
{
char  ss[20];

   rfmtdouble(ff1,fmt1,ss);
   rgu_put_body_string(1,trim(ss),2);

}


double d45(num,num1)
double num;
int num1;
{
long tmplong;
double var1;
double ten;
int i;


    ten = 1;
    for(i = 1 ;i<=num1;i++)
    ten *= 10;

    num *= ten;
    if (num >= 0) var1 = 0.5;
    else var1 = (-0.5);

    num = num + var1;
    tmplong = num;

    num = tmplong/ten;
    return(num);
}



