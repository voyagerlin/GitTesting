/************************************************/
/*                                              */
/*   PROGRAM : ca102m01s.ec by Pei-Chow Chen    */
/*                                              */
/*   PURPOSE : server side standard program     */
/*                                              */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "commsgs.h"
#include "safeclib.h"
$include sqlca;

long car102(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car102_insert(),car102_single_query(),car102_multiple_query(),
      car102_update_exec(),car102_query_iquota();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'A':
           rtncode=car102_insert(reply);
           break;
  case 'Q':
           rtncode=car102_single_query(reply);
           break;
  case 'M':
           rtncode=car102_multiple_query(reply);
           break;
  case 'D':
  case 'U':
           rtncode=car102_update_exec(reply,command,com_len);
           break;
  case 'L':
           rtncode=car102_query_iquota(reply);
           break;
  default :
           if(exitsub(reply,M_CM_WRONG_OPTION) == True)
             return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}

long car102_insert(reply)
serverReply reply;
{
 $char DBName[5],assured[121],license[11],tag[CA_TAG_NUM];
 $char engine[CA_ENGINE_NUM],body[CA_BODY_NUM],reason[2];
 $char remark[255];
 $char str_dexpire[11],dexpire[11],dcreate[11],icreate[11];
 long MsgCode;
 int tmp_len;
   DBinfo *list;
   int i, j, is_add_fail=0, api_f;
   $char stmt_buf[300];

 cm_buf_get("%s %s %s %s %s %s %s %s %s %s ",DBName,tag,engine,body,license,
                                assured,reason,remark,str_dexpire,icreate);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
  }

 strcpy(dexpire, cm_to_infdate(str_dexpire));
 if (strlen(trim(tag))==0) strcpy(tag," ");
 if (strlen(trim(engine))==0) strcpy(engine," ");
 if (strlen(trim(body))==0) strcpy(body," ");
 if (strlen(trim(license))==0) strcpy(license," ");
 if (strlen(trim(assured))==0) strcpy(assured," ");

 $BEGIN WORK;
 $INSERT INTO reject_client
        (nassured,ilicense,itag,iengine,ibody,freason,remark,
	 dexpire,icreate,dcreate,iupdate,dupdate)
  VALUES($assured,$license,$tag,$engine,$body,$reason,$remark,
	 $dexpire,$icreate,today,$icreate,current);

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l",M_CM_OK);
  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
  {
      $WHENEVER SQLERROR CONTINUE;
      $ROLLBACK WORK;
      return apiRC;
  }

 $WHENEVER SQLERROR GOTO errexit;
 $COMMIT WORK;
 return api_OKComplete;

errexit:
   MsgCode = SQLCODE;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
     return MsgCode;
   else
     return apiRC;
}

long car102_single_query(reply)
serverReply reply;
{
 $char DBName[5],assured[121],license[11],tag[CA_TAG_NUM];
 $char engine[CA_ENGINE_NUM],body[CA_BODY_NUM],reason[2],remark[255];
 $char dexpire[11];

 $char buff[250];
 $char icreate[11],dcreate[11],nname[11];
 $char iupdate[11],dupdate[25],nupdate[11];
 $char update[25];

 int tmp_len;

 cm_buf_get("%s %s %s %s %s %s %s %s ",DBName,tag,engine,body,license,
		assured,reason,update);
		
 printf("[%s] [%s] [%s] [%s] [%s] [%s] [%s] [%s] ",DBName,tag,engine,body,license,assured,reason,update);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
    return M_CM_DB_NOTOPEN;
   else
    return apiRC;
 }

 $SELECT freason,remark,dexpire,icreate,dcreate,iupdate,dupdate
    INTO $reason,$remark,$dexpire,$icreate,$dcreate,$iupdate,$dupdate
    FROM reject_client
   WHERE itag     = $tag
     AND iengine  = $engine
     AND ibody    = $body
     AND ilicense = $license
     AND nassured = $assured
     AND freason  = $reason
     AND dupdate  = $update;

 if(SQLCODE==SQLNOTFOUND)
  {
   if(exitsub(reply,M_CM_NOT_FOUND) == True)      /*?*/
    return M_CM_NOT_FOUND;                        /*?*/
   else
    return apiRC;
  }

 strcpy(dexpire,cm_from_infdate_100(dexpire));
 cm_buf_init(ReplyBuf);

  $SELECT nname
     INTO $nname
     FROM officer
    WHERE iofficer = $icreate;

  if (SQLCODE==SQLNOTFOUND) strcpy(nname," ");

  $SELECT nname
     INTO $nupdate
     FROM officer
    WHERE iofficer = $iupdate;

  if (SQLCODE==SQLNOTFOUND) strcpy(nupdate," ");

 cm_buf_put("%l %s %s %s %s %s %s %s %s %s %s %s %s",
	M_CM_OK,tag,engine,license,assured,body,reason,dupdate,remark,dexpire,
	icreate,dcreate,iupdate);
 cm_buf_put("%s %s",nname,nupdate);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
  return apiRC;
 else
  return api_OKComplete;

errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}

long car102_multiple_query(reply)
serverReply reply;
{
 $char DBName[5],assured[121],license[11],tag[CA_TAG_NUM];
 $char engine[CA_ENGINE_NUM],body[CA_BODY_NUM],reason[2],remark[255];
 $char dupdate[25];

 $char key_assured[121],key_license[11],key_tag[CA_TAG_NUM];
 $char key_engine[CA_ENGINE_NUM],key_body[CA_BODY_NUM],KEY_freason[2];
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0;

 cm_buf_get("%s %s %s %s %s %s %s",DBName,key_tag,key_engine,key_body,
                                key_license,key_assured,KEY_freason);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 $DECLARE q_cur cursor for 
  SELECT nassured, ilicense, iengine, ibody, freason, itag, dupdate
    FROM reject_client
   WHERE itag     matches $key_tag 
     AND iengine  matches $key_engine
     AND ibody    matches $key_body  
     AND ilicense matches $key_license
     AND nassured matches $key_assured
     AND freason  matches $KEY_freason 
   ORDER BY itag;

 $OPEN q_cur;

 for(;;)
  {
     $FETCH q_cur INTO $assured,$license,$engine,$body,$reason,$tag,$dupdate;
    if (SQLCODE != 0) break;
    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();
     }
    cm_buf_put("%s %s %s %s %s %s %s",tag,engine,license,assured,body,reason,dupdate);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
        $CLOSE q_cur;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s %s %s %s %s %s",tag,engine,license,assured,body,reason,dupdate);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
  } /* for loop */

 $CLOSE q_cur;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
    if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
      return M_CM_NOT_FOUND;                               /*?*/
    else
      return apiRC;
  }

errexit:
   if(exitsub(reply,SQLCODE) == True)
     return SQLCODE;
   else
     return apiRC;
}

long car102_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 $char DBName[5],assured[121],license[11],tag[CA_TAG_NUM];
 $char engine[CA_ENGINE_NUM],body[CA_BODY_NUM],reason[2],remark[255];
 $char dexpire[11];

 $char cur_reason[2];

 $char old_assured[121],old_license[11],old_tag[CA_TAG_NUM];
 $char old_engine[CA_ENGINE_NUM],old_body[CA_BODY_NUM],old_reason[2],old_dupdate[25];
 $char create[11];
 $char icreate[11],dcreate[11],nname[11];
 $char iupdate[11],dupdate[25],nupdate[11];
 $char update[25];

 char  option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
 int   tmp_len,raw_len;
 long  dummy;
 long  MsgCode;
 DBinfo *list;
 int   i, j, is_del_fail=0, is_upd_fail=0;
 $char stmt_buf[300];

 comm = (char *) command;
 cm_buf_init(command);
 cm_buf_get("%c %s",&option,DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 /* compare old record and current record, if the record has not been changed
    since last request, update or delete the record, otherwise return errmsg
    to client side */

 /* get old record info from command buffer */

 memcpy(&raw_len,&comm[com_len],sizeof(int));
 pos = &comm[com_len+sizeof(int)];
 raw_ptr = malloc(raw_len);
 if (raw_ptr != (char*)0){
	 memcpy(raw_ptr,pos,raw_len);
 }
     
 else {
   if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */
     return M_CM_NOT_MALLOC;
   else
     return apiRC;
  }

 cm_buf_init(raw_ptr);          /* get index key from old record */
 cm_buf_get("%l %s %s %s %s %s %s %s",&dummy,tag,engine,license,assured,
		body,reason,update);

 $BEGIN WORK;

 $SELECT freason,remark,dexpire,icreate,dcreate,iupdate,dupdate
    INTO $cur_reason,$remark,$dexpire,$icreate,$dcreate,$iupdate,$dupdate
    FROM reject_client
   WHERE itag     = $tag
     AND iengine  = $engine
     AND ibody    = $body
     AND ilicense = $license 
     AND nassured = $assured
     AND freason  = $reason
     AND dupdate  = $update;

  /* if key value has been changed then SQLNOTFOUND,else put current value
     into cur_buf for comparison */

 if (SQLCODE == SQLNOTFOUND)
 {
   MsgCode = M_CM_NOT_FOUND;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;              /* rollback fail */
   if(SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
     return MsgCode;
   else
     return apiRC;
 }

 strcpy(dexpire,cm_from_infdate_100(dexpire));
 cm_buf_init(cur_buf);

  $SELECT nname
     INTO $nname
     FROM officer
    WHERE iofficer = $icreate;

  if(SQLCODE==SQLNOTFOUND) strcpy(nname," ");

  $SELECT nname
     INTO $nupdate
     FROM officer
    WHERE iofficer = $iupdate;

  if(SQLCODE==SQLNOTFOUND) strcpy(nupdate," ");

 cm_buf_put("%l %s %s %s %s %s %s %s %s %s %s %s %s",
	dummy,tag,engine,license,assured,body,cur_reason,
	dupdate,remark,dexpire,icreate,dcreate,iupdate);
 cm_buf_put("%s %s",nname,nupdate);
 
 write(1, raw_ptr, raw_len);
 printf("\n\n\n");
 write(1, cur_buf, raw_len);
 

 if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
 {
   MsgCode = M_CM_NOT_EQUAL;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;              /* rollback fail */
   if(SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
     return MsgCode;
   else
     return apiRC;
 }

 /* equal, then exec DB operation */

 if ( option == 'D' )
  {
    $DELETE FROM reject_client
      WHERE itag=$tag
        AND iengine=$engine
        AND ibody=$body
        AND ilicense=$license
        AND nassured=$assured
        AND freason=$cur_reason
        AND dupdate=$dupdate;

    if(SQLCODE != 0) goto errexit;
   
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
   {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
   }
   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else if (option == 'U')
  {
   cm_buf_init(command);
   cm_buf_get("%c %s %s %s %s %s %s %s %s %s %s %s",
	&option,DBName,tag,engine,body,license,
	assured,reason,remark,dexpire,create,dupdate);

   strcpy(dexpire,cm_to_infdate(dexpire));
   printf("dexpire[%s]\n",dexpire);
   printf("dupdate[%s]\n",dupdate);
   /* grasp old key */
   cm_buf_init(raw_ptr);
   cm_buf_get("%l %s %s %s %s %s %s %s",&dummy,old_tag,old_engine,
               old_license, old_assured, old_body, old_reason, old_dupdate);

/*   $WHENEVER SQLERROR CONTINUE;*/
    $UPDATE reject_client
        SET (itag,iengine,ibody,ilicense,nassured,freason,remark,
	     dexpire,iupdate,dupdate)
          = ($tag,$engine,$body,$license,$assured,$reason,$remark,
	     $dexpire,$create,current)
      WHERE itag=$old_tag  AND iengine=$old_engine
        AND ibody=$old_body AND ilicense=$old_license
        AND nassured=$old_assured AND dupdate=$old_dupdate;

    if(SQLCODE != 0) goto errexit;
	
	free(raw_ptr);

    if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
     {
        $INSERT INTO reject_client
         (itag,iengine,ibody,ilicense,nassured,freason,remark,dexpire,
	  icreate,dcreate,iupdate,dupdate)
	 VALUES($tag,$engine,$body,$license,$assured,$reason,$remark,$dexpire,
		$create,today,$create,current);
      if(SQLCODE != 0) goto errexit; 
     }

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
   {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
   }
   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else
  {
   MsgCode = M_CM_WRONG_OPTION;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;              /* rollback fail */
   if(SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
     return MsgCode;
   else
     return apiRC;
  }

errexit:
   MsgCode = SQLCODE;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;              /* rollback fail */
   if(SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
     return MsgCode;
   else
     return apiRC;
}


long car102_query_iquota(reply)
serverReply reply;
{
 $char DBName[5], checkCode[3];
 $char detail2[7];
 int tmp_len;

 cm_buf_get("%s %s ",DBName,checkCode);
 printf("[%s] [%s] ",DBName,checkCode);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
    return M_CM_DB_NOTOPEN;
   else
    return apiRC;
 }

 $SELECT detail2
    INTO $detail2
    FROM car_code
   WHERE kind    = 'VX'
     AND detail  = $checkCode;

 if(SQLCODE==SQLNOTFOUND)
  {
   if(exitsub(reply,M_CM_NOT_FOUND) == True)
    return M_CM_NOT_FOUND;
   else
    return apiRC;
  }

 cm_buf_init(ReplyBuf);

 cm_buf_put("%l %s ",	M_CM_OK,detail2);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
  return apiRC;
 else
  return api_OKComplete;

errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}
