/**********************************************************************/
/*   program id   : ca539p01s.ec                                      */
/*   program name : ����[���ӤH���{���B�z�O������                    */
/*   date written : 12/26/2017                                        */
/*   date modify  : yyyy/mm/dd                                        */
/**********************************************************************/
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
#include "safeclib.h"

#define TRUE 1
#define FALSE 0

$char outputf[21];
$char  DBName[5];
$char  DBName1[5];
$char  errMsg[30000], errMsg2[200];
$char  errMsg1[30000];
$char  stmp[30000];
char   sApHome[50];
long   rtncode;
FILE   *sfp,*fp;
static char  *bp;
static int   recLen=1024;
$char userid[11];
$char txtfile[101];
int offset;
$char getfile[400];
char delimiter;
$char sStmt[2048];
$char isign_tmp[8];
$char sItransno[21];
int i,ipflag;
long rc;
$date Today;
$char ncode[101];
$long icount;
long car539_exec();
long split_policy();
long car539_call_car5083();

main(argc, argv)
int argc;
char **argv;
{
    long rc;

    batchinit();
    strcpy(DBName       ,isNULLstr(argv[1]));
    strcpy(userid       ,isNULLstr(argv[2]));
    strcpy(txtfile      ,isNULLstr(argv[3]));    /*��r��*/
    strcpy(sItransno    ,isNULLstr(argv[4]));    /*���ɧǸ�*/
    strcpy(outputf      ,isNULLstr(argv[5]));
    printf("txtfile[%s]\n",txtfile);

    rtoday(&Today);     /* get today's datetime */

    if (db_select(DBName) == False)
    {
        EWRITE(userid,M_CM_DB_NOTOPEN,"M_CM_DB_NOTOPEN");
        return 0;
    }

    rtncode = getApHome(sApHome);
    if (rtncode < 0)
    {
        EWRITE(userid, M_CM_READ_CONFIG_ERR, "read Config file error!!");
        return FAIL;
    }

    printf("sItransno=[%s]\n",sItransno);
    rc=car539_exec();

    $WHENEVER SQLERROR CONTINUE;

    if (rc != M_CM_OK)
    {
        printf("[�ƬG�{���B�z�O������  ���楢��]\n");
        strcpy(stmp,"car539_exec ���楢��, ���~��Ʀp�U, �нT�{�íץ���A���s����!! \n\n");
        strcat(stmp,errMsg);
        EWRITE(userid,rc,stmp);
        return rc;
    }

    printf("return success\n");
    sprintf_s(stmp,30000,"�ƬG�{���B�z�O�����ɧ���!, �@��J %ld �����!! \n",icount);
    /* EWRITE(userid,M_CM_OK,"�ƬG�{���B�z�O�����ɧ���!"); */
    EWRITE(userid,M_CM_OK,stmp);

    return SUCCESS;
}

/* ------------------------------------------------------------------------- */
void GetData(data, maxlen, delimiter)
char *data, delimiter;
int maxlen;
{
    int fori, pre_offset, cnt=0;

    data[0]='\0';
    pre_offset = offset;

    for (fori=pre_offset; bp[fori]!=0x00&&bp[fori]!=0x0d&&bp[fori]!=0x0a&&bp[fori]!=delimiter; fori++)
    {
        offset++;
        if (cnt < maxlen-1)
        {
            data[cnt]=bp[fori];
            cnt++;
        }
    }

    offset++; /* ���ܤU�@�� */
    if (cnt==0) data[cnt++]=0x20; /* �L��Ƶ��ť� */
    data[cnt]=0x00;
    printf("pre_offset[%d]offset[%d]len[%d]data[%s]\n", pre_offset, offset, cnt, data);
}

/* ------------------------------------------------------------------------- */
long car539_exec()
{
    $char iclaim[21];
    $char proce_id[11];
    $char dclose_tmp[15];
    $long lMpay;
    $long lMpay_total;
    $int  icnt;
    char  sIunit[6], sIbranch_in[BRANCH_ID];
    $char ipolicy[21];
    $char icard[21];
    $char  sFullName[25];
    $char sIpolicy1[POLICY_NUM_1] , sIpolicy2[POLICY_NUM_2];
    $char iverify[21];
    $char stmt[4096];
	$char stmt_errlog[30000];
    $int  iclose_type_tmp;
    $int  iclose_type_last;
    $char daccident[11];
    $int id1 = 0;
    $char iadjuster[11];
    $int  iself_duty, ioth_duty, ianoth_duty;
    $int  qserial,icnt_pa;
    $char fassured[2];
    $char nchi_full[101];
    $char aperm_con[121];
    $char tstl_remark[61];
    $char isettle_type[2];
    $char fpay_cond[2];
    $char ibank[8];
    $char iaccbank[15];
    $char affiliated[7];
    $char iclm_upcomp[3],proce_id_ext[3], iproce_type_tmp[2];

    $char nname[11], iins_item[7], iinsurant[12];
    $int  tmp_cnt;
    $char itag[CA_TAG_NUM], itag_tmp[CA_TAG_NUM], iproce_type[2],
          mpay[10], iins_type[INSURANCE_TYPE], iofficer[11], ifpce_id[11],
          ifpce_id_ext[3],isign[21], flast[2], fspeed[2], ffactory_type[3],
          iemail[51], imovephone[21],ipayno[13],nnote_claim[100],
          dcreate_tmp[11],ipayno_tmp[21], sToday[11], sYN[2], fapply[2],
          kreserve[6], iportfolio[11],igroup_profit[21], fterm[2], icohort[5],
          sMsg[200];
    int   iline, icnt_err, rtn, icnt1;

    $WHENEVER SQLERROR continue;
    /*EXEC SQL WHENEVER SQLERROR GOTO errexit;*/
    $SET LOCK MODE TO WAIT 30;

    ipflag = 0;

    printf("sApHome[%s]\n",sApHome);
    printf("txtfile[%s]\n",txtfile);
    sprintf_s(getfile,400,"%s/dat/car/%s",sApHome,txtfile);
    printf("getfile[%s]\n",getfile);

    if ((fp=fopen(getfile,"rt"))==NULL)
    {
        return FAIL;
    }

    if ((bp=malloc(recLen))==NULL)
    {
        printf("System malloc failed  !\n");
		free(bp);
        return FAIL;
    }

    /* ���j�Ÿ� */
    /* delimiter = '|'; */
    delimiter=''; /* �`�N:���j�Ÿ��� ascii(127) */

    $CREATE TEMP table car539_temp
    (
        iclaim          char(20),   -- �߮׸�
        itag            char(12),   -- ����
        iproce_type     char(2),    -- �B�z�H�����O
        nname           char(30),   -- �B�z�H���W��
        proce_id        char(12),   -- �B�z�H�����s
        proce_id_ext    char(2),    -- �B�z�H��_����
        mpay            int,        -- �O�Ϊ��B
        ipayno          char(12)    -- �w�����渹
    )with no log;
    $create unique index car539_temp_dx1 on car539_temp(iclaim);

    $CREATE TEMP table car539_errlog
    (
        iclaim     char(20),
        errmsg     char(300)
    )with no log;

    /* $CREATE TEMP table car539_err1
    (
        iclaim     char(20),
        itype      char(300)
    )with no log; */

    /* 1.1 IFRS�ˮֶ}�� */
    $select first 1 today into $sToday
       from car_code
      where 1=1;

    printf("sToday=[%s]\n",sToday);
    rtn = cm_get_IFRS_DATE(sToday, &sYN);
    printf("sToday=[%s], sYN=[%s]\n",sToday,sYN);

    icnt = 0;
    iline = 0;
    icnt_err = 0;
    while(fgets(bp,recLen,fp))
    {
        if (feof(fp)) break;
        offset = 0;

        /* ��ƨ��o���Ǥ��i�ܰ� */
        GetData(iclaim,              sizeof(iclaim)  ,            delimiter);      /*�߮׸�*/
        GetData(itag,                sizeof(itag)  ,              delimiter);      /*����*/
        GetData(iproce_type,         sizeof(iproce_type),         delimiter);      /*�B�z�H�����O*/
        GetData(nname,               sizeof(nname),               delimiter);      /*�B�z�H���W��*/
        GetData(proce_id,            sizeof(proce_id),            delimiter);      /*�B�z�H�����s/ID*/
        GetData(proce_id_ext,        sizeof(proce_id_ext),        delimiter);      /*�B�z�H��_����*/
        GetData(mpay,                sizeof(mpay),                delimiter);      /*�z�ߪ��B*/
        GetData(ipayno,              sizeof(ipayno),              delimiter);      /*�w�����渹*/

        strcpy(iclaim, trim(iclaim));

        if (strcmp(iclaim,"�߮׸�") == 0)
        {
           memset(bp, ' ', recLen);
           continue;
        }

        iline++;
        strcpy(iclaim, trim(iclaim));
        strcpy(itag, trim(itag));
        strcpy(iproce_type,trim(iproce_type));
        strcpy(nname,trim(nname));
        strcpy(proce_id, trim(proce_id));
        strcpy(proce_id_ext, trim(proce_id_ext));
        if (strlen(proce_id_ext) == 0)
            strcpy(proce_id_ext," ");

        strcpy(mpay, trim(mpay));
        strcpy(ipayno, trim(ipayno));
		
		/* �ˮ֤��L�ɡA�ϥΥH�USQL�y�k */
		sprintf_s(stmt_errlog, 30000, "insert into car539_errlog(iclaim, errmsg) values (?, ?)");
		$prepare insert_errlog from $stmt_errlog;
		
                printf("stmt_errlog[%s]\n",stmt_errlog);
        printf("iclaim [%s],itag[%s],iproce_type[%s], nname[%s],proce_id[%s], mpay[%s], ipayno[%s]\n",
                iclaim,itag,iproce_type,nname,proce_id,mpay,ipayno);

        ipflag = 0;


        /* �ƥ��ˮ� (start) ------------------------------------------------ */
        if ((strlen(iclaim) == 0) || (strlen(iproce_type) == 0) ||
            (strlen(nname) == 0)  || (strlen(proce_id) == 0) ||
            (strlen(mpay) == 0) || (strlen(itag) == 0) || (strlen(ipayno) == 0))
        {
            ipflag = 1;
            sprintf_s(errMsg,30000,"��[%d]�� �߮׸�[%s]�U����Ƥ��o���ť� \n", iline, iclaim);
            /*$insert into car539_errlog(iclaim, errmsg) values ($iclaim, $errMsg);*/
			$execute insert_errlog
			   using $iclaim, $errMsg;
            icnt_err ++;
            printf("1\n");
        }

        if (iclaim[6] == 'C')
        {
            ipflag = 1;
            sprintf_s(errMsg,30000,"�߮׸�:[%s]\t��J����������N�I�߮׸� \n",iclaim );
            /*$insert into car539_errlog(iclaim, errmsg) values ($iclaim, $errMsg);*/
			$execute insert_errlog
			   using $iclaim, $errMsg;
            icnt_err ++;
            printf("2\n");
        }

        if((iproce_type[0]<65)||(iproce_type[0]>69))
        {
            ipflag = 1;
            sprintf_s(errMsg,30000,"�߮׸�:[%s]\t�B�z�H�����O[%s]  �ȯର A�BB�BC�BD�BE ���� \n", iclaim, mpay);
            /*$insert into car539_errlog(iclaim, errmsg) values ($iclaim, $errMsg);*/
			$execute insert_errlog
			   using $iclaim, $errMsg;
            icnt_err ++;
            printf("3\n");
        }

        for(i=0;i<strlen(mpay);i++)
        {
           if (mpay[i] == ',')
           {
              ipflag = 1;
              sprintf_s(errMsg,30000,"�߮׸�:[%s]\t���B[%s]���i�H���d����Ÿ� \n", iclaim, mpay);
              /*$insert into car539_errlog(iclaim, errmsg) values ($iclaim, $errMsg);*/
			  $execute insert_errlog
			     using $iclaim, $errMsg;
      
            printf("4\n");
              icnt_err ++;
              break;
           }
           if (!isdigit(mpay[i]))
           {
              ipflag = 1;
              sprintf_s(errMsg,30000,"�߮׸�:[%s]\t���B[%s]�����Ʀr \n", iclaim, mpay);
              /*$insert into car539_errlog(iclaim, errmsg) values ($iclaim, $errMsg);*/
			  $execute insert_errlog
			     using $iclaim, $errMsg;
               
            printf("5\n");
              icnt_err ++;
              break;
           }
        }

        if (ipflag == 0)
        {
            if(iproce_type[0] == 'A')
            {
                $select iofficer into $iofficer
                  from officer
                 where iofficer = $proce_id;
                if (SQLCODE == SQLNOTFOUND)
                {
                    ipflag = 1;
                    sprintf_s(errMsg,30000,"�߮׸�:[%s]\t�B�z�H�����s[%s]���~�A�ЦA�T�{�I\n", iclaim,proce_id);
                    /*$insert into car539_errlog(iclaim, errmsg) values ($iclaim, $errMsg);*/
					$execute insert_errlog
					   using $iclaim, $errMsg;
                    icnt_err ++;
            printf("5\n");
                }

                if ((atoi(mpay) != 300) && (atoi(mpay) != 700) && (atoi(mpay) != 1000))
                {
                  ipflag = 1;
                  sprintf_s(errMsg,30000,"�߮׸�:[%s]\t�B�z�H�����O:A  ���B[%s]����300�B700��1000�A�ЦA�T�{�I\n", iclaim, mpay);
                  /*$insert into car539_errlog(iclaim, errmsg) values ($iclaim, $errMsg);*/
				  $execute insert_errlog
				     using $iclaim, $errMsg;
                  icnt_err ++;
            printf("5\n");
                }
            }

            if(iproce_type[0] == 'B')
            {
                $select first 1 ifpce_id into $iofficer
                   from cu_customer
                  where ifpce_id = $proce_id;

                if (SQLCODE == SQLNOTFOUND)
                {
                    ipflag = 1;
                    sprintf_s(errMsg,30000,"�߮׸�:[%s]\t�B�z�H��ID[%s]���~�A�ЦA�T�{�I�I\n", iclaim, proce_id);
                    /*$insert into car539_errlog(iclaim, errmsg) values ($iclaim, $errMsg);*/
					$execute insert_errlog
					   using $iclaim, $errMsg;
                    icnt_err ++;
                }
                /* �̻ݨD���������ˮ� mark by sylvia 108.04.03 */
                /* if (atoi(mpay) != 1200)
                {
                    ipflag = 1;
                    sprintf_s(errMsg,30000,"�߮׸�:[%s]\t�B�z�H�����O:B ���B[%s]����1200�A�ЦA�T�{�I�I \n", iclaim, mpay);
                    $insert into car539_errlog(iclaim, errmsg) values ($iclaim, $errMsg);
					$execute insert_errlog
					   using $iclaim, $errMsg;
                    icnt_err ++;
                } */
            }

            if (((iproce_type[0] == 'C') || (iproce_type[0] == 'D')) &&
                (strcmp(proce_id, "16784078") != 0))
            {
                ipflag = 1;
                sprintf_s(errMsg,30000,"�߮׸�:[%s]\t���Ӫ��Τ@�s��[%s]���~�A�ЦA�T�{�I�I \n", iclaim, proce_id);
                /*$insert into car539_errlog(iclaim, errmsg) values ($iclaim, $errMsg);*/
				$execute insert_errlog
				   using $iclaim, $errMsg;
                icnt_err ++;
            }
			
			if (iproce_type[0] == 'E' && strcmp(proce_id, "83446817") != 0)
            {
                ipflag = 1;
                sprintf_s(errMsg,30000,"�߮׸�:[%s]\t���ת��Τ@�s��[%s]���~�A�ЦA�T�{�I�I \n", iclaim, proce_id);
                /*$insert into car539_errlog(iclaim, errmsg) values ($iclaim, $errMsg);*/
				$execute insert_errlog
				   using $iclaim, $errMsg;
                icnt_err ++;
            }
        }

        /* �ˮ֬O�_�w���w����� */
        $select 'newa'||trim(ibranch_in), itag, ipolicy
           into $sFullName, $itag_tmp, $ipolicy
           from ca_clm_process
          where iclaim = $iclaim;

        if (SQLCODE == SQLNOTFOUND)
        {
           sprintf_s(errMsg,30000,"�߮׸�:[%s]\t�bca_clm_process �߮׬y�{�ɸ�Ƨ䤣�� \n",iclaim);
           /*$insert into car539_errlog(iclaim, errmsg) values ($iclaim, $errMsg);*/
		   $execute insert_errlog
			  using $iclaim, $errMsg;
           ipflag = 1;
           icnt_err ++;
        }
        else
        {
            strcpy(sFullName, trim(sFullName));
            strcpy(itag_tmp, trim(itag_tmp));

            if (strcmp(itag_tmp,itag) != 0)
            {
                ipflag = 1;
                sprintf_s(errMsg,30000,"�߮׸�:[%s]\t�߮׸��Ψ���[%s]�P���z�ɤ��@�P�A�ЦA�T�{�I \n", iclaim, itag);
                /*$insert into car539_errlog(iclaim, errmsg) values ($iclaim, $errMsg);*/
				$execute insert_errlog
			       using $iclaim, $errMsg;
                icnt_err ++;
            }

            sprintf_s(stmt,4096, " select first 1 iins_type  \
                              from %s:app_ins_type           \
                             where iclaim = ? ", sFullName);

            $prepare chk_ins_type from $stmt;
            $execute chk_ins_type into $iins_type  using $iclaim;
            if (SQLCODE == SQLNOTFOUND)
            {
                ipflag = 1;
                sprintf_s(errMsg,30000,"�߮׸�:[%s]\t�|�������w���@�~�A�нT�{�I \n", iclaim);
                /*$insert into car539_errlog(iclaim, errmsg) values ($iclaim, $errMsg);*/
				$execute insert_errlog
				   using $iclaim, $errMsg;
                icnt_err ++;
            }
            else
            {
                /* --------------------------------------------------------- */
                /* �s�WIFRS �զX�N�X(iportfolio)�θs�եN�X(igroup_profit)�d��
                   add by sylvia 111010.07 (1110303007��SC3) */
                /* --------------------------------------------------------- */
                /*   1120914001_A01_IFRS17 �t�X��Ʀ^�ɬ����ק�   */
                strcpy(sYN,"N");
                if (strcmp(sYN,"Y") == 0)
                {
                    strcpy(iportfolio, " ");
                    strcpy(igroup_profit, " ");

                    rc = chk_IFRS_claim("2", ipolicy, iclaim, iins_type, &iportfolio, &igroup_profit, &icnt1, &sMsg);
                    if (icnt1 > 0)
                    {
                        strcpy(errMsg, sMsg);
                        /*$insert into car539_errlog(iclaim, errmsg) values ($iclaim, $errMsg);*/
						$execute insert_errlog
						   using $iclaim, $errMsg;
                        ipflag = 1;
                        icnt_err ++;
                    }
                    printf("iportfolio=[%s] igroup_profit=[%s]\n",iportfolio, igroup_profit);
                }
                /* End IFRS �ˮ� --------------------------------------------------------------------------------------- */
            }

            /* �ˮ֫e�@���z��Y���鵲�A���o���U�@�����z�� */
            sprintf_s(stmt,4096,
            " select first 1 iclose_type, dclose      \
                from %s:settlement                    \
               where iclaim = ?                       \
                 and fstl   = '1'                     \
               order by iclose_type desc ", sFullName);

            printf("stmt[%s]\n",stmt);

            $prepare get_last_dclose from $stmt;
            $execute get_last_dclose
                into $iclose_type_tmp, $dclose_tmp:id1
               using $iclaim;

            /* if (id1 < 0) */
            if ((SQLCODE != SQLNOTFOUND) && (id1 < 0))
            {
               sprintf_s(errMsg,30000, "A�߮׸�:[%s]\t�e�@���z��|���鵲�A�e�@���z�ߦ���[%d] \n", iclaim, iclose_type_tmp);
               /*$insert into car539_errlog(iclaim, errmsg) values ($iclaim, $errMsg);*/
			   $execute insert_errlog
				  using $iclaim, $errMsg;
               ipflag = 1;
               icnt_err ++;
            }
        }
        /* �ƥ��ˮ�(end) -------------------------------------------------- */

        if (ipflag == 0)
        {
           lMpay = atol(mpay);
           $INSERT INTO car539_temp
              VALUES ($iclaim, $itag, $iproce_type, $nname, $proce_id, $proce_id_ext, $lMpay, $ipayno);

          if (SQLCODE != 0)
          {
             sprintf_s(errMsg,30000, "�߮׸�:[%s]\t SQLCODE=[%d] [%s ] \n", iclaim,SQLCODE,sqlca.sqlerrm);
             /*$insert into car539_errlog(iclaim, errmsg) values ($iclaim, $errMsg);*/
			 $execute insert_errlog
			    using $iclaim, $errMsg;
             ipflag = 1;
             icnt_err ++;
          }

        }
        memset(bp, ' ', recLen);
        icnt++;
    }

    fclose(fp);

    if (icnt == 0)
    {
        EWRITE(userid, M_CM_NOT_FOUND, "�ɮפ��L���!! \n");
        return FAIL;
    }

	int tmp_iline = 0;
    printf("icnt_err=[%d]\n",icnt_err);
    EXEC SQL WHENEVER SQLERROR GOTO errexit;
    if (icnt_err > 0)
    {
        strcpy(errMsg2,"");
        strcpy(errMsg,"");
		
        $DECLARE get_errlog CURSOR FOR
          SELECT errmsg INTO $errMsg2 FROM car539_errlog where 1=1;

        $OPEN get_errlog;
        for(;;)
        {
            $FETCH get_errlog;
			
            if (SQLCODE == SQLNOTFOUND) break;
			tmp_iline++;
			if (tmp_iline > 450) break;
            strcat(errMsg,trim(errMsg2));
			if (tmp_iline == 450) strcat(errMsg,"�]���~�T���W�L450���A�H�U�ٲ�����ܡA�Хt�~�d�߿��~��]�I�I\n");
        }
        $CLOSE get_errlog;
        $FREE get_errlog;
    
        printf("errMsg[%s]\n",errMsg);

        return FAIL;
    }


    /* ����ˮ֥��`�L�~, �}�l�g�J��Ʈw */
    EXEC SQL WHENEVER SQLERROR GOTO errexit;

    $BEGIN WORK;
    icount=0;
    ipflag = 0;

    $select first 1 'A'||to_char(today ,'%y%m%d')
       into $isign_tmp
       from car_code;

    printf("-- 502 isign_tmp = [%s]\n",isign_tmp);

    $DECLARE c_cur CURSOR FOR
      SELECT * FROM car539_temp where 1=1;
    $OPEN c_cur;

    for(;;)
    {
        $FETCH c_cur INTO $iclaim, $itag, $iproce_type, $nname, $proce_id,
                          $proce_id_ext, $mpay, $ipayno;
        if (SQLCODE == SQLNOTFOUND) break;

        lMpay_total = atoi(mpay);
        ipflag = 0;
        icount++;

        sprintf_s(stmt,4096,
        " select ipolicy, adjustment, date(daccident), affiliated \
            from ca_clm_process \
           where iclaim = ? ");
        $prepare get_base_info from $stmt;
        $execute get_base_info
            into $ipolicy, $iadjuster, $daccident, $affiliated
           using $iclaim;
        if (SQLCODE == SQLNOTFOUND)
        {
           strcpy(errMsg,"ca_clm_process �߮׬y�{�ɸ�Ƨ䤣�� ");
           goto errexit;
        }
        printf("538:ipolicy=[%s]iadjuster=[%s]daccident=[%s]affiliated=[%s]\n",ipolicy,iadjuster,daccident,affiliated);

        $select iupcomp
           into $iclm_upcomp
           from branch
          where ibranch = (select iapp_unit from cm_clm_adjuster where empl_no = $iadjuster);
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(errMsg,30000," branch �L�k���z�ߤW�h�����q�N���A�z�߭����s[%s] ", iadjuster);
            goto errexit;
        }
        printf("549:iclm_upcomp=[%s]\n",iclm_upcomp);

        if ((rtncode = split_policy(ipolicy, sIpolicy1, sIpolicy2)) != M_CM_OK)
        {
           sprintf_s(errMsg,30000, "�O�渹�X[%s]�������O�渹�X�@�B�O�渹�X�G���~ ", ipolicy);
           goto errexit;
        }

        rtncode = cm_get_unit_in(sIpolicy1, DBName,  " ", sIunit,"C3",DBName1,
                                 sIbranch_in);
        if(rtncode != M_CM_OK)
        {
           sprintf_s(errMsg,30000, "cm_get_unit_in ���o�O���즳�~�A�O�渹�X�G[%s] ",ipolicy);
           goto errexit;
        }

        /*** �O��(�Y�߮��k��)��Ʈw ***/
        DBName1[2]='\0';
        strcpy(sFullName, get_full_dbname(DBName1));
        printf("568:sFullName=[%s]\n",sFullName);
        iclose_type_tmp = 0;


        /*** �ˮ֦P�@�߮׸��O�_���w���P�@���B�z�H����� add by sylvia 107.04.29 (1070403001_SC1) ***/
        sprintf_s(stmt,4096,
        " select first 1 a.iclose_type, b.iprocess_type \
            from %s:settlement a, %s:payment b    \
           where a.iclaim = b.iclaim  \
             and a.iclose_type = b.iclose_type \
             and a.fstl = b.fstl \
             and a.iclaim = ?                       \
             and a.fstl   = '1'                     \
             and b.iprocess_type = ?  \
           order by a.iclose_type desc ", sFullName, sFullName);

        printf("stmt[%s]\n",stmt);
        printf("iclaim[%s]\n",iclaim);

        $prepare get_same_proce_type from $stmt;
        $execute get_same_proce_type
            into $iclose_type_tmp, $iproce_type_tmp:id1
           using $iclaim, $iproce_type;

        if ((SQLCODE != SQLNOTFOUND) && (id1 < 0))
        {
           sprintf_s(errMsg,30000, "�߮׸�:[%s]\t�e�@���z�ߦ���[%d]�w����J[%s]���H���B�z�O ", iclaim, iclose_type_tmp, iproce_type_tmp);
           goto errexit;
        }

        /* �ˮ����ɤ��e�O�_������ add by sylvia 108.05.16 */
        sprintf_s(stmt,4096,
        " select first 1 iclose_type,date(dcreate),ipayno \
            from sysdb:ca_onsiteproc_cost    \
           where iclaim = ?                       \
             and itype = ?  ");
        printf("stmt[%s]\n",stmt);
        printf("iclaim[%s]\n",iclaim);

        $prepare get_same_proce_type2 from $stmt;
        $execute get_same_proce_type2
            into $iclose_type_tmp, $dcreate_tmp, $ipayno_tmp
           using $iclaim, $iproce_type;

        if (SQLCODE != SQLNOTFOUND)
        {
           sprintf_s(errMsg,30000, "�߮׸�:[%s]\t [%s]���B�z�O�w���ɹL ���ɤ��[%s] �w�����渹[%s] ",
                            iclaim, iproce_type, dcreate_tmp, ipayno_tmp);
           goto errexit;
        }
        /* ------------------------------------------------------------- */

        /*** �ˮ֫e�@���z��Y���鵲�A���o���U�@�����z�� ***/
        sprintf_s(stmt,4096,
        " select first 1 iclose_type, dclose      \
            from %s:settlement                    \
           where iclaim = ?                       \
             and fstl   = '1'                     \
           order by iclose_type desc ", sFullName);

        printf("stmt[%s]\n",stmt);
        printf("iclaim[%s]\n",iclaim);

        $prepare get_last_dclose from $stmt;
        $execute get_last_dclose
            into $iclose_type_tmp, $dclose_tmp:id1
           using $iclaim;

        if ((SQLCODE != SQLNOTFOUND) && (id1 < 0))
        {
           sprintf_s(errMsg,30000, "B�߮׸�:[%s]\t�e�@���z��|���鵲�A�e�@���z�ߦ���[%d] ", iclaim, iclose_type_tmp);
           goto errexit;
        }

        iclose_type_last = iclose_type_tmp;

        if (SQLCODE == SQLNOTFOUND)
        {
           iclose_type_tmp = 1;
        }
        else
        {
           iclose_type_tmp += 1;
        }

        /* �g�J�O����(ca_onsiteproc_cost) add by sylvia 107.04.29 (1070403001_SC1) */
        sprintf_s(stmt,4096,
        " insert into sysdb:ca_onsiteproc_cost \
             (iclaim, iclose_type, itag, itype, nprocess, iprocess, \
              iprocess_ext, mamt, ipayno, itransno, icreate, \
              dcreate, iqserial, iupdate) \
            values \
             (?, ?, ?, ?, ?, ?, \
              ?, ?, ?, ?, ?,  \
              current, ' ', ' ') ");

        printf("stmt settlement[%s]\n", stmt);

        $prepare insert_ca_trans_cost from $stmt;
        $execute insert_ca_trans_cost
           using $iclaim, $iclose_type_tmp, $itag, $iproce_type, $nname, $proce_id,
                 $proce_id_ext, $mpay, $ipayno, $sItransno, $userid;


         $select iverify
            into $iverify
            from ca_ver_relation
           where iclaim = $iclaim;
        if (SQLCODE == SQLNOTFOUND) strcpy(iverify, iclaim);


        /**** �g�J�p��ѹ�y������ ****/
        sprintf_s(stmt,4096,
        " select * from %s:stl_oth_dtl where iclaim = ? and fstl = '1' and iclose_type = ?     \
            into temp stl_oth_tmp1 with no log ",sFullName);

        printf("stmt[%s]\n",stmt);

        $prepare get_stl_oth from $stmt;
        $execute get_stl_oth
           using $iclaim, $iclose_type_last;

        sprintf_s(stmt,4096,
        " update stl_oth_tmp1                       \
             set iclose_type = iclose_type + 1      \
           where iclaim = ? ");

        printf("stmt[%s]\n",stmt);

        $prepare upd_stl_oth from $stmt;
        $execute upd_stl_oth
           using $iclaim;

        if (sqlca.sqlerrd[2] > 0)
        {
           sprintf_s(stmt,4096,
            " insert into %s:stl_oth_dtl            \
               select * from stl_oth_tmp1 ",sFullName);

           printf("stmt[%s]\n",stmt);

           $prepare ins_stl_oth from $stmt;
           $execute ins_stl_oth;
        }
        $drop table stl_oth_tmp1;

        /****  �g�J�p�����  ****/

        sprintf_s(stmt,4096,
        " select icard             \
            from %s:ply_relation   \
           where ipolicy = ? ",sFullName);
        printf("stmt[%s]\n",stmt);
        $prepare get_icard from $stmt;
        $execute get_icard
            into $icard
           using $ipolicy;

        printf("icard[%s]ipolicy=[%s]\n",icard,ipolicy);
        if (SQLCODE == SQLNOTFOUND)
        {
           sprintf_s(errMsg,30000, "ply_relation �̷s�O���ɸ�Ƥ��s�b�A�O�渹�X�G[%s] ",ipolicy);
           goto errexit;
        }

        iself_duty = 0;
        ioth_duty  = 0;
        ianoth_duty = 0;

        /* ���� */
        $select  nvl(max(qduty_adjuster),0) into $iself_duty
           from ca_clm_victim_data a
          where iclaim = $iverify
            and fvictim_car = 'F';
printf("iself_duty[%d]iverify=[%s]\n",iself_duty,iverify);

        /* ��訮 */
        $select  nvl(max(qduty_adjuster),0) into $ioth_duty
           from ca_clm_victim_data a
          where iclaim = $iverify
            and fvictim_car not  in ('A','F','G');
printf("��訮:ioth_duty[%d]iverify=[%s]\n",ioth_duty,iverify);

        sprintf_s(nnote_claim,100,"�ƬG�{���B�z�O�ΡA�w�����渹: %s",ipayno);

        /* �t�X���ɶ������鵲,���@�ּg�Jñ�֪��A�ήɶ� modify by sylvia 107.04.30 (1070403001_SC1) */
        sprintf_s(stmt,4096,
        " insert into %s:settlement \
             (iclaim, fstl, iclose_type, fcard_class, ipolicy, \
              icard, msettle, ientry, dentry, iadjuster, \
              frecover, fsale, istl_flag, iself_duty, ioth_duty, \
              ianoth_duty, iupdate, dupdate, freject, \
              nnote_claim, ipayno, dvouch_bgn, dvouch_end, vouch_state) \
            values (?, '1', ?, '2', ?, \
                    ?, ?, 'car539', current, ?, \
                    '0', '0', '1', ?, ?, \
                    ?, 'car539', current, 'N', \
                    ?, ?, today, today, '130') ", sFullName);

        printf("stmt settlement[%s]\n", stmt);

        printf("695:iclaim[%s]iclose_type_tmp=[%d]ipolicy=[%s]\n", iclaim,iclose_type_tmp,ipolicy);
        printf("695:icard[%s]lMpay_total=[%ld]iadjuster=[%s]\n", icard,lMpay_total,iadjuster);
        printf("695:iself_duty[%d]ioth_duty=[%ld]ianoth_duty=[%d]\n", iself_duty,ioth_duty,ianoth_duty);
        printf("695:nnote_claim[%s]ioth_ipaynoduty=[%s]\n", nnote_claim,ipayno);
        $prepare ins_settle from $stmt;
        $execute ins_settle
           using $iclaim, $iclose_type_tmp, $ipolicy,
                 $icard, $lMpay_total, $iadjuster,
                 $iself_duty, $ioth_duty,
                 $ianoth_duty,
                 $nnote_claim, $ipayno;


       if (strcmp(iproce_type,"A") == 0)
       {
            $select a.fassured, a.nchi_full, b.tstl_remark,
                   b.isettle_type, b.fpay_cond, b.ibank, b.iaccount,
                   a.aperm_con, a.ifpce_id, nvl(a.iemail,' '), nvl(a.imovephone,' ')
              into $fassured, $nchi_full, $tstl_remark,
                   $isettle_type, $fpay_cond, $ibank, $iaccbank,
                   $aperm_con, $ifpce_id, $iemail, $imovephone
              from cu_customer a,cu_stl_obj b
             where a.ifpce_id      =   b.ifpce_id
               and a.ifpce_id_ext  =   b.ifpce_id_ext
               and a.ifpce_id      =
                    (select id_no from personal:asempl where empl_no = $proce_id)
               and a.ifpce_id_ext = $proce_id_ext;
       }
       else
       {
           $select a.fassured, a.nchi_full, b.tstl_remark,
                   b.isettle_type, b.fpay_cond, b.ibank, b.iaccount,
                   a.aperm_con, a.ifpce_id, nvl(a.iemail,' '), nvl(a.imovephone,' ')
              into $fassured, $nchi_full, $tstl_remark,
                   $isettle_type, $fpay_cond, $ibank, $iaccbank,
                   $aperm_con, $ifpce_id,$iemail, $imovephone
              from cu_customer a,cu_stl_obj b
             where a.ifpce_id      =   b.ifpce_id
               and a.ifpce_id_ext  =   b.ifpce_id_ext
               and a.ifpce_id      =   $proce_id
               and a.ifpce_id_ext  =   $proce_id_ext;
        }

        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(errMsg,30000,"�d�L�ߥI��H [%s-%s] ���", proce_id,proce_id_ext);
            goto errexit;
        }

        /****  �g�Jñ����  ****/
        /* bug�ץ�:�[�W ifpce_id_ext = $proce_id_ext �P�_  modify by sylvia 107.03.09 */
        sprintf_s(stmt,4096,
        " select nvl(max(qserial),0) + 1    \
            from ca_sign_receipt        \
           where iclaim = ?             \
             and ifpce_id = ?  \
             and ifpce_id_ext = ? ");
        printf("stmt[%s]\n",stmt);
        $prepare get_max_qser from $stmt;
        $execute get_max_qser
            into $qserial
           using $iclaim, $ifpce_id, $proce_id_ext;

        printf("ca_sign_receipt qserial [%d]\n",qserial);

        $select 'A'||to_char(today,'%y%m%d')||Lpad(CAST(substr(nvl(max(isign),'A'||to_char(today,'%y%m%d')||'0000'),8,4) AS INT) + 1,4,0)
           into $isign
           FROM ca_sign_receipt
          where isign[1,7] = $isign_tmp;

        printf("ca_sign_receipt isign [%s] isign_tmp=[%s]\n",isign,isign_tmp);

        /* �t�X�]�ȳ��ݨD,�t�קO�@�߬�B modify by sylvia 107.04.29 (1070403001_SC1) */
        /* if ((strcmp(iproce_type,"A") == 0)||(strcmp(iproce_type,"C") == 0))
            strcpy(fspeed,"B");
        else
            strcpy(fspeed,"A"); */

        strcpy(fspeed,"B");

        if ((strcmp(iproce_type,"A") == 0)||(strcmp(iproce_type,"B") == 0))
        {
            strcpy(ffactory_type,"11");
            strcpy(fassured,"1");
            strcpy(isettle_type,"2");
        }
        else
        {
            strcpy(ffactory_type,"10");
            strcpy(fassured,"2");
            strcpy(isettle_type,"1");
        }

       /* bug�ץ�:�[�W ifpce_id_ext = $proce_id_ext �P�_  modify by sylvia 107.03.09 */
        sprintf_s(stmt,4096,
        " insert into ca_sign_receipt \
            (iclaim, ifpce_id, ifpce_id_ext, qserial, mpayment, \
             invoice, dpaperwork, dentry, isign,  \
             isign_type, ideliver, pay_kind, fspeed, xfpay_cond, mprocess, \
             iclose_type, ientry, iupdate, dupdate, icntry, \
             iemail, imobile, tfax, itel, izipcode_con, \
             aperm_con, izip, aperm, ffactory_type) \
            values (?, ?, ?, ?, 0,\
                    ' ',today,CURRENT, ?, \
                    '2',' ', '4', ?, '3', ?, \
                    ?, ?,?,current,'9',\
                    ?, ?,' ',' ',' ',\
                    ' ',' ',' ',? ) ");
        printf("stmt[%s]\n",stmt);
        $prepare ins_sign from $stmt;
        $execute ins_sign
           using $iclaim, $ifpce_id,$proce_id_ext, $qserial, $isign, $fspeed,
                 $lMpay_total, $iclose_type_tmp, $userid, $userid, $iemail,
                 $imovephone, $ffactory_type;


        /****  �g�J�ߥI��H��  ****/

        /* �s�W���:iprocess_type (�{���B�z�H�����O) add by sylvia 107.04.29 (1070403001_SC1) */
        sprintf_s(stmt,4096,
        " insert into %s:payment                                            \
            (iclaim,  fstl,         iclose_type, ipayment,  ifpce_id_ext,   \
             qserial, irepair_shop, fassured,    nchi_full, npayment, \
             xsettle_type, ipay_area, xptax,  xfpay_cond, xibank, \
             xiaccount, aperm_con, xastl_obj_c, mpayment, fspeed, \
             pay_kind, dpaperwork, iemail, imobile, tfax, \
             izipcode_con, iprocess_type )                \
            values                               \
            (?, '1', ?, ?, ? ,              \
             ?, ' ', ?, ?, ?,                        \
             ?, ?, 0, '3', ?,                     \
             ?, ?, ' ', ?, ?,                        \
             '4', today, 1, ' ', ' ',                 \
             ' ', ? ) ",sFullName);

        printf("�g�J�ߥI��H��stmt[%s]\n",stmt);
        printf("iclaim=[%s]iclose_type_tmp=[%d]ifpce_id=[%s]fassured=[%s]\n",iclaim,iclose_type_tmp,ifpce_id,fassured);
        printf("nchi_full=[%s]tstl_remark=[%s]isettle_type=[%s]iclm_upcomp=[%s]\n",nchi_full,tstl_remark,isettle_type,iclm_upcomp);
        printf("ibank=[%s]iaccbank=[%s]aperm_con=[%s]lMpay_total=[%d]fspeed=[%s]\n",ibank,iaccbank,aperm_con,lMpay_total,fspeed);
        $prepare ins_payment from $stmt;
        $execute ins_payment
           using $iclaim, $iclose_type_tmp, $ifpce_id, $proce_id_ext,
                 $qserial, $fassured, $nchi_full, $tstl_remark,
                 $isettle_type, $iclm_upcomp,
                 $ibank, $iaccbank, $aperm_con,
                 $lMpay_total, $fspeed, $iproce_type;

        /****  �g�J�p����I�ة�����  ****/
        sprintf_s(stmt,4096,"select first 1 a.iins_type  \
                       from %s:app_ins_type a \
                      where iclaim = '%s' and iins_type in \
                      (select icode from cu_code_data where itype = 'CT')",
                      sFullName, iclaim);
        printf("833:stmt[%s]\n",stmt);
        $prepare get_ins1 from $stmt;
        $execute get_ins1 into $iins_type;

        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(stmt,4096,"select first 1 a.iins_type  \
                            from %s:app_ins_type a \
                           where iclaim = '%s' and iins_type in \
                           (select iins_type from insurance_type where fkind ='3')",
                           sFullName, iclaim);
            printf("844:stmt[%s]\n",stmt);
            $prepare get_ins2 from $stmt;
            $execute get_ins2 into $iins_type;

            if (SQLCODE == SQLNOTFOUND)
            {
                icnt_pa = 0;
                sprintf_s(stmt,4096,"select first 1 a.iins_type , \
                                    (select count(*) from %s:app_pa_type \
                                      where iclaim = a.iclaim and pa_ins = a.iins_type) \
                                from %s:app_ins_type a \
                               where iclaim = '%s' ", sFullName, sFullName, iclaim);
                printf("853:stmt[%s]\n",stmt);
                $prepare get_ins3 from $stmt;
                $execute get_ins3 into $iins_type, $icnt_pa;
            }
        }
        printf("iins_type=[%s]\n",iins_type);
        strcpy(flast,"0");

        /* �󥿹w���O�ΤθɤJ���v�� add by sylvia 108.05.16 (1080401005_SC1) */
        /* 1.update app_ins_type */
        sprintf_s(stmt,4096,
        		" update %s:app_ins_type \
            	   set mproc_app  =  mproc_app + %ld \
           		 where iclaim = '%s' and iins_type = '%s' ",
             	 sFullName, lMpay_total, iclaim, iins_type);


        printf("967:stmt[%s]\n",stmt);
        $prepare app_ins_1 from $stmt;
        $execute app_ins_1;

        /* 2.insert app_ins_type_hist */
        sprintf_s(stmt,4096,
        		"delete from %s:app_ins_type_hist \
              where iclaim = '%s' and dappraisal = today; ",
              sFullName, iclaim);
        $prepare app_ins_3 from $stmt;
        $execute app_ins_3;

        sprintf_s(stmt,4096,
        		"insert into %s:app_ins_type_hist \
             select iclaim, iins_type, minjure_cover, mdamage_cover, mdeath_cover, \
                    mdeduct, qlia, mins_app, mplace_app, mproc_app, today, \
                    qfree_app, qmore_app, '%s', current \
               from %s:app_ins_type \
              where iclaim = '%s'; ",
              sFullName, userid, sFullName, iclaim);


        printf("982:stmt[%s]\n",stmt);
        $prepare app_ins_2 from $stmt;
        $execute app_ins_2;

        /* 3.��sca_clm_process.dappraisal */
        $update ca_clm_process
            set dappraisal = today
          where iclaim = $iclaim;

        /* ----------------------------------------------------------------- */
        sprintf_s(stmt,4096,"select flast from %s:stl_ins_type \
                      where iclaim = ? and fstl = '1' \
                        and iclose_type = ? and iins_type = ? ", sFullName);
        printf("864:stmt[%s]\n",stmt);
        $prepare get_ins4 from $stmt;
        $execute get_ins4 into $flast
           using $iclaim, $iclose_type_last, $iins_type;


        sprintf_s(stmt,4096,
        " insert into %s:stl_ins_type                                  \
            (iclaim, fstl, iclose_type, iins_type, mins_proc, flast)   \
            values                               \
            (?, '1', ?, ?, ?,?) ",sFullName);

        printf("stmt[%s]\n",stmt);
        printf("877:stmt[%s]\n",stmt);
        $prepare stl_ins from $stmt;
        $execute stl_ins
           using $iclaim, $iclose_type_tmp, $iins_type, $lMpay_total, $flast;


        /* �������߮רS������B���d�I,�u�����, �ҥH�n�T�{�I�جO�_����˥�, �g�J�ˮ`�I��  add by sylvia 107.08.08 */
        if (icnt_pa > 0)
        {
            strcpy(iins_item," ");
            strcpy(iinsurant," ");
            sprintf_s(stmt,4096,"select first 1 a.iins_item , a.iinsurant \
                                from %s:app_pa_type a \
                               where iclaim = '%s' and pa_ins = '%s'",
                          sFullName, iclaim, iins_type);
                printf("945:stmt[%s]\n",stmt);
                $prepare get_pa1 from $stmt;
                $execute get_pa1 into $iins_item, $iinsurant;


            sprintf_s(stmt,4096,
                " insert into %s:stl_pa_type                     \
                      (iclaim, fstl, iclose_type, pa_ins, iins_item, iinsurant, \
                       mins_comp, mins_stl, mins_proc, flast,  dclose, dgroup, \
                       pa_type_level, pa_daily, fracture_level, disability_code) \
                  VALUES ( ?, '1', ?, ?, ?, ?, \
                           0, 0, ?, ?, NULL, NULL, \
                           '', 0, 0, '') ",sFullName);

            printf("959:stmt[%s]\n",stmt);
            $prepare stl_pa from $stmt;
            $execute stl_pa
                using $iclaim, $iclose_type_tmp, $iins_type, $iins_item, $iinsurant,
                      $lMpay_total, $flast;
        }

        printf("iclaim[%s], iclose_type[%d]\n",iclaim, iclose_type_tmp);

        /* �g�Jca_local_stl */
        /* �t�X���ɪ����鵲, �u�g�x�_��Ʈw modify by sylvia 107.05.01 (1070403001_SC1) */
        sprintf_s(stmt,4096,
        " select count(*)                     \
            from ca_local_stl              \
           where iclaim = ?                   \
             and fstl   = '1'                 \
             and iclose_type = ?              \
             and dclose is null ");

        printf("894:stmt[%s]\n",stmt);
        $prepare get_local_cnt from $stmt;
        $execute get_local_cnt into $tmp_cnt using $iclaim, $iclose_type_tmp;
        if (tmp_cnt > 0)
        {
           sprintf_s(stmt,4096,
            " delete from ca_local_stl     \
               where iclaim = ?               \
                 and fstl = '1'               \
                 and iclose_type = ?          \
                 and dclose is null ");
            printf("905:stmt[%s]\n",stmt);
            $prepare del_local_cnt from $stmt;
            $execute del_local_cnt using $iclaim, $iclose_type_tmp;
        }

        /****   ientry ����car539����H��id  ****/
        sprintf_s(stmt,4096,
        " insert into ca_local_stl                              \
             (dentry, ipolicy, icard, iclaim, fstl, iclose_type,   \
              ientry, ibranch, fchoose,userid)                            \
           values                                                  \
             (today, ?, ?, ?, '1', ?, ?, ?, '1',?) ");
        printf("stmt[%s]\n",stmt);
        printf("918:stmt[%s]\n",stmt);
        $prepare ins_local_stl from $stmt;
        $execute ins_local_stl
           using $ipolicy, $icard, $iclaim, $iclose_type_tmp, $userid, $iclm_upcomp,$userid;

    }
    $CLOSE c_cur;
    $FREE  c_cur;

    printf("COMMIT WORK\n");
    $COMMIT WORK;

    EWRITE(userid,M_CM_OK,"���ɧ���!! �нT�{�鵲���G!!");

    printf("�������� car539_call_car5083 �������������� \n");
    /* �I�s�鵲�{�H�����鵲�@�~ add by sylvia 107.05.01 */
    rc = car539_call_car5083();

    printf("rc = [%d]\n");
    printf("*******************************************************");

    return M_CM_OK;


errexit:
    printf("------> errexit: iclaim[%s] SQLCODE=[%d] \n", iclaim, SQLCODE);
    printf("sStmt[%s]\n",sStmt);
    strcpy(errMsg1, errMsg);
    sprintf_s(errMsg,30000," �߮׸�: [%s], errMsg: [%s] SQLCODE=[%d] \n", iclaim, errMsg1,SQLCODE);
    rc = cm_show_sql_err("ca539", "");
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    $SET LOCK MODE TO NOT WAIT ;
    return rc;
}

long split_policy(sIpolicy, sIpolicy1, sIpolicy2)
char *sIpolicy, *sIpolicy1, *sIpolicy2;
{
     strcpy(sIpolicy, trim(sIpolicy));
     printf("begin split_policy\n");

     if (strlen(sIpolicy) > CAR_POLICY_LEN)
     {
        strncpy(sIpolicy1, sIpolicy, CAR_POLICY_LEN);
        sIpolicy1[CAR_POLICY_LEN] = '\0';
        strncpy(sIpolicy2, sIpolicy+CAR_POLICY_LEN, CAR_TARGET_LEN);
        sIpolicy2[CAR_TARGET_LEN] = '\0';
        if (sIpolicy2[0]=='\0' || sIpolicy2[0]==' ') strcpy(sIpolicy2," ");
     }
     else
     {
        strcpy(sIpolicy1,sIpolicy);
        strcpy(sIpolicy2," ");
     }

     printf("---after split_policy -> sIpolicy[%s]\n", sIpolicy);
     printf("---after split_policy -> sIpolicy1[%s]\n", sIpolicy1);
     printf("---after split_policy -> sIpolicy2[%s]\n", sIpolicy2);

     return M_CM_OK;
}

/* ------------------------------------------------------------------------ */
long car539_call_car5083()
{
	int result;
	char p0[201];
	char sApHome[31],command[512],ch_dwritten[11];

	result = getApHome(sApHome);
	if(result < 0)
	{
		printf("read Config file error!!\n");
		return M_CM_READ_CONFIG_ERR;
	}

	strcpy(ch_dwritten , cm_sysd_cdate(cm_get_sysd( )));
    printf("���������� DBName=[%s]userid=[%s]ch_dwritten=[%s]sItransno=[%s]\n",DBName,userid,ch_dwritten,sItransno);

	/* sprintf_s( p0,201,"runbatch %s %s car5083 P 4 'A' '%s' '%s' '%s' >/dev/null &", DBName,userid,ch_dwritten,userid,sItransno); */
	sprintf_s( p0,201,"runbatch %s %s car5083 P 4 'A' '%s' '%s' '%s' ", DBName,userid,ch_dwritten,userid,sItransno);

	sprintf_s(command,512, "%s", p0);
	result = system(command);
	printf("result[%d]\n", result);
	puts("test_data ok");
	return M_CM_OK;

}
