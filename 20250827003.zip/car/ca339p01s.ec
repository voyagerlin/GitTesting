/*-------------------------------------------------------------------
 * Program: ca339p01s.ec
 * Date   : 01/25/2011
 *-------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <ca401field.h>
#include "is_def.h"
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
$include sqlca;
$include sqltypes;
$include datetime;
$include "safeclib.h";

#define FOUND                   sqlca.sqlcode!=SQLNOTFOUND
#define NOT_FOUND               sqlca.sqlcode==SQLNOTFOUND
#define LOAD_FAIL               -1 
#define COLS                    8 
char *get_car_full_db();
/*****************************************************************/

int  rc;
int   max_count = 0;
$char DBName[5];
char  outputf[N_FILE+1];
$char userid[11];
$char BodyFile[21],TitleFile[21],BodyFmt[21],FormTp[3];
$char TitleFmt[21];
$char FormFile[N_FILE+1], OutFile[20];
$int  PgLine, Width;
$char sMsg[1025];
FILE  *report;
char  aphome[40];
int   res; 
char  v_sMsg[512], sFileName[101]; 
$date  dwritten;
$char iedr_field[9];
$char pre_ileader[11], sys_time[12];
$char send_date[11], nproject[255], sContent[5000],nsubject[512],nattachment[1025];;
$char email[51], chinese_name[15], Porj_id[11];
$char fname[100],filename[150],ftitle[1024];
$int  mail_count;

/*1090831006_SC2 �{�ҥ��x�j��q�l���ҥ���g�����mail�ˮ�*/
$char s_notifyornot[21]="";
$datetime year to second dnotifyornot;

$loc_t 	ctxt;
/*****************************************************************/

main(argc,argv)
int argc;
char **argv;
{
char option[1];
long iTmp;
  puts("============================car339 start=================================");
  batchinit();
  puts("============================end batchinit()=================================");
  strcpy(DBName,     isNULLstr(argv[1]));
  strcpy(userid,     isNULLstr(argv[2]));
  strcpy(option,     isNULLstr(argv[3]));	/* I:�j���I���P��ƶפJ�]�O�o���Ѫ��ɮס^�פJca_change_tag_ori
                                                   J:���N�I���P��ƶפJ�]���T���Ѫ��ɮס^�פJca_change_tag_ori
                                                   P:�j��B���N���P��ƾ����
                                                   C:�@���郞�P�]AC�^�]�O��L���P�Ψ��P���~�^ */
  strcpy(sFileName,   isNULLstr(argv[4]));
  strcpy(outputf,    isNULLstr(argv[5]));

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return FAIL;
  }
  puts("============================end db_select()=================================");

  res = getApHome(aphome);
  if (res<0) {
      EWRITE( userid, -1, "In sigalrmcatcher func==>read config file error!!");
      return FAIL;
  }
  puts("============================end getApHome()=================================");

  /* ���o���椧�t�Τ�� */
  rtoday(&dwritten);

  /* Init. iedr_field, to make every bit and byte = 0 */
  memset (&iedr_field, 0, sizeof (iedr_field));
  for( iTmp = 0; iTmp < 8; iTmp++)
      FLD_SET ( iedr_field, iTmp*8 + 7);
  /* �M�w������즳���,�M��N����諸���ؼg�Jiedr_field */
  /* ��諸��즳�i���ܰʪ���[�P�Ӹ�] */
  FLD_SET (iedr_field, 20);
       
  if( option[0] != 'I' && option[0] != 'P' && option[0] != 'J' && option[0] != 'C')
  {
      EWRITE(userid, -1, "ERROR OPTION");
      return FAIL;
  }
  $SELECT kPgNum_Line, nForm_File INTO $PgLine, $FormFile
     FROM Form
    WHERE ksys_grp="CA" AND kPgmID = 339;

  if( SQLCODE == SQLNOTFOUND)
  {
      EWRITE(userid, -1, "form not found");
      return FAIL;
  }

  strcpy(FormFile,rtrim(FormFile));
  sprintf_s(OutFile, sizeof OutFile,"%s.tx",outputf);

  rgu_init_report(FormFile, OutFile);
    
  strcpy( sMsg, " ");
  if( option[0] == 'I')   /* I:�j���I���P��ƶפJ�]�O�o���Ѫ��ɮס^�פJca_change_tag_ori */
  {
      puts("============================BEGIN car339_I");
      rc = car339_I();
      puts("============================END car339_I");
  }
  strcpy( sMsg, " ");
  if( option[0] == 'J')   /* J:���N�I���P��ƶפJ�]���T���Ѫ��ɮס^�פJca_change_tag_ori */
  {
      puts("============================BEGIN car339_J");
      rc = car339_J();
      puts("============================END car339_J");
  }
  strcpy( sMsg, " ");
  if( option[0] == 'P') /* P:���P��ƾ���� */
  {
      puts("============================BEGIN car339_P_email_init");
	  rc = car339_P_email_init();
	  if (rc != M_CM_OK) {
          EWRITE(userid,rc, sMsg);
          return rc; 
	  }
      puts("============================BEGIN car339_P");
      rc = car339_P();      /* select ca_change_tag_ori �X�ӧ娮�P */
      if (rc != M_CM_OK)
      {
          EWRITE(userid,rc, sMsg);
          return rc; 
      } 
      puts("============================BEGIN car339_P_send_email");
      rc=car339_P_send_email();
      if (rc != M_CM_OK) {
          printf("error on car339_P_send_email\n");
          EWRITE(userid,rc, sMsg);
          return rc; 
      }
      puts("============================END car339_P_send_email");


  } 
  strcpy( sMsg, " ");
  if( option[0] == 'C') /* C:�@���郞�P�]AC�^�]�O��L���P�Ψ��P���~�^ */
  {
      puts("============================BEGIN car339_AC");
      rc = car339_AC();
      if (rc != M_CM_OK)
      {
          EWRITE(userid,rc, sMsg);
          return rc; 
      } 
      puts("============================END car339_AC");
  } 
  rgu_finish_report();
  if (rc=(save_form_info(F_FREE,"CA",306,userid,FormTp,max_count,outputf))<0)
      EWRITE(userid,rc,"save_form_info failed");

  return M_CM_OK;

errexit:
    printf("------car339_err: SQLCODE[%d]\n",SQLCODE);
    EWRITE(userid, SQLCODE,sqlca.sqlerrm);
    exit(1);
}
/* -------------------------------------------------------------------------------*/
/* �N�O�o���Ѥ��j���I���P��ƶפJca_change_tag_ori */
/* -------------------------------------------------------------------------------*/
long car339_I() 
{
$char itype[2], icard[21], itag_last[13], itag_next[13];
$char dply_begin[11], dply_end[11], dchange_ori[11];
$char ipolicy[21], fcard_class[2];
$char iassured[13], iengine[CA_ENGINE_NUM], itag[13], icard2[21];

/* General variables */
$char fstatus[2];
char  FullGetName[101];
long  iCount, iCountSuccess, iCountError;
char  readstr[284],sDate[11];
char  sIupcompShort[2], policyDB[21], policyDBname[41];
$char stmt[2048];

    $WHENEVER SQLERROR continue;

    /* client�ݱNuser���Ѫ�����諸�����ftp��/dat/car/ */
    sprintf_s(FullGetName, sizeof FullGetName, "%s/dat/car/%s", aphome, sFileName); 
    
    if ((report=fopen(FullGetName,"r"))==NULL)
    {
        sprintf_s(sMsg, sizeof sMsg, "Cannot open ftp file: %s\n", FullGetName);
        printf("%s", sMsg);
        return M_CM_OPEN_FILE_FAIL;
    }
    iCount = iCountSuccess = iCountError = 0;
    /* ���Y, �s�W����, �����@�_�s�W */
    sprintf_s(sMsg, sizeof sMsg, "���~��]\t��N��\t���ʧO\t�j���Ҹ�\t�W�����P\t���P���P\t"
                  "���P���\t�O�I�ͮĤ�\t�O�I�פ��\t\t\t");

    rgu_put_body_string(1, sMsg,LEFT);
    rgu_put_body(1);
        
    while(1)
    { 
    	 fscanf(report,"%[^\n]%*c",readstr);
    	
    	 if(feof(report)) break;
    	 printf("READSTR[%s]\n", readstr);          
    	
    	 /* �N�ɮ׮ھکT�w�e��,Ū�X��� */
    	 strncpy( itype, &readstr[0], 1);
    	 itype[1] = '\0';
    	
    	 /* ���L���q�N�X "17" �A���d�� */
    	 strncpy( icard, &readstr[3], 15);
    	 icard[15] = '\0';
    	 
    	 strncpy( itag_last, &readstr[18], 12);
    	 itag_last[13-1] = '\0';
    	 
    	 strncpy( itag_next, &readstr[30], 12);
    	 itag_next[13-1] = '\0';     
    	
    	 strncpy( sDate, &readstr[42], 8);
    	 sDate[8] = '\0';
    	 formatDate( sDate, dchange_ori); /* ������ഫ��db�i�������榡 */
    	
    	 strncpy( sDate, &readstr[50], 8);
    	 sDate[8] = '\0';
    	 if (strlen(trim(sDate))==0) strcpy(sDate,"19710101");  /* �ťշ|�ɭP "�פJ����SQLCODE[-703]" ,1070118006_SC1 �s�WCAR339���O�\��*/
    	 formatDate( sDate, dply_begin); /* ������ഫ��db�i�������榡 */
    	
    	 strncpy( sDate, &readstr[58], 8);
    	 sDate[8] = '\0';    	 if (strlen(trim(sDate))==0) strcpy(sDate,"19710101");  /* �ťշ|�ɭP "�פJ����SQLCODE[-703]" ,1070118006_SC1 �s�WCAR339���O�\��*/
    	 formatDate( sDate, dply_end); /* ������ഫ��db�i�������榡 */
    	
    	  iCount++;          
    	 /* �T�w�e���ɮפ��ε��� */
    	 
    	 /*1070118006_SC1 �s�WCAR339���O�\��*/
    	 /*���� car339_P() �B�z/�ˮ� */
    	 /* �̾ڱj��d����X�O�渹 
    	 $SELECT ipolicy, fcard_class, iengine, itag, iassured 
    	    INTO $ipolicy, $fcard_class, $iengine, $itag, $iassured
    	    FROM assured_vs_ply
    	   WHERE icard = $icard;
    	 if (SQLCODE == SQLNOTFOUND)
    	 {
    	      sprintf_s(sMsg, sizeof sMsg, "���p�ɫO�渹�䤣��\t��[%d]��\t%s\t%s\t%s\t%s\t"
    	                    "%s\t%s\t%s\t\t\t", 
    	                    iCount, itype, icard, itag_last, itag_next, dchange_ori, dply_begin, dply_end);
    	      rgu_put_body_string(1, sMsg,LEFT);
    	      rgu_put_body(1);
    	      iCountError ++;
    	      continue;
    	 }
    	 */
    	 strcpy(ipolicy," "); strcpy(fcard_class,"1");
    	
    	 $INSERT INTO ca_change_tag_ori
    	         ( itype, icard, itag_last,
    	           itag_next, dchange,   dply_begin, dply_end, ipolicy, fcard_class, icreate)
    	 VALUES (  $itype, $icard, $itag_last,
    	           $itag_next, $dchange_ori, $dply_begin, $dply_end, $ipolicy, $fcard_class, $userid);
    	
    	 if( SQLCODE != 0)
    	 {
    	     /* �����~�T����춶�ǥ����P���Y���Ǥ@�P */
             if ((SQLCODE==-268) || (SQLCODE==-239))
             {
    	         sprintf_s(sMsg, sizeof sMsg, "�פJ���ѡA��Ƥw�s�b(SQLCODE[%d]),\t��[%d]��\t%s\t%s\t%s\t%s\t"
    	                       "%s\t%s\t%s\t\t\t", 
    	                       SQLCODE, iCount, itype, icard, itag_last, itag_next, dchange_ori, dply_begin, dply_end);
             }
             else
             { 
    	         sprintf_s(sMsg, sizeof sMsg, "�פJ����(SQLCODE[%d]),ERRM[%s]\t��[%d]��\t%s\t%s\t%s\t%s\t"
    	                       "%s\t%s\t%s\t\t\t", 
    	                       SQLCODE, sqlca.sqlerrm, iCount, itype, icard, itag_last, itag_next, dchange_ori, dply_begin, dply_end);
    	     }
    	     rgu_put_body_string(1, sMsg,LEFT);
    	     rgu_put_body(1);
    	     iCountError ++;
    	     continue;
    	 }
    	  iCountSuccess++;
    } /* End of While */
    
    fclose( report);
    sprintf_s(sMsg, sizeof sMsg, "���P��ƶפJ: ��J[%d]��, ����[%d]��, �@[%d]��\t\t\t\t\t\t\t\t\t\t\t", iCountSuccess, iCountError, iCount);
    rgu_put_body_string(1, sMsg,LEFT);
    rgu_put_body(1);
    rgu_put_body_string(1, "\t\t\t\t\t\t\t\t\t\t\t",LEFT);
    rgu_put_body(1);

    return M_CM_OK;
}
  
/* -------------------------------------------------------------------------------*/
/* �N���T���Ѥ����N�I���P��ƶפJca_change_tag_ori */
/* -------------------------------------------------------------------------------*/
long car339_J() 
{
$char itype[21], icard[21], itag_last[21], itag_next[21];
$char dply_begin[21], dply_end[21], dchange_ori[21];
$char ipolicy[21], fcard_class[21];
$char iassured[21], iengine[CA_ENGINE_NUM], itag[21], icard2[21];

/* General variables */
$char fstatus[2];
char  FullGetName[101];
long  iCount, iCountSuccess, iCountError, iStart, iLen, iTmp;
char  readstr[284],sDate[11], sData[COLS][21];
char  sIupcompShort[2], policyDB[21], policyDBname[41];
$char stmt[2048];
char  *pStart;

    $WHENEVER SQLERROR continue;

    /* client�ݱNuser���Ѫ�����諸�����ftp��/dat/car/ */
    sprintf_s(FullGetName, sizeof FullGetName, "%s/dat/car/%s", aphome, sFileName); 
    
    if ((report=fopen(FullGetName,"r"))==NULL)
    {
        sprintf_s(sMsg, sizeof sMsg, "Cannot open ftp file: %s\n", FullGetName);
        printf("%s", sMsg);
        return M_CM_OPEN_FILE_FAIL;
    }
    iCount = iCountSuccess = iCountError = 0;
    /* ���Y, �s�W����, �����@�_�s�W */
    sprintf_s(sMsg, sizeof sMsg, "���~��]\t��N��\t���ʧO\t���N�I�O�渹�X\t�O�I�ͮĤ��\t�O�I�פ���\t��P�Ӹ��X\t�s�P�Ӹ��X\t"
                  "���s���P���\t\t\t");

    rgu_put_body_string(1, sMsg,LEFT);
    rgu_put_body(1);
        
    while(1)
    { 
     fscanf(report,"%[^\n]%*c",readstr);

     if( strncmp( readstr, "CNTRLREC", 8) == 0) break;
     printf("READSTR[%s]\n", readstr);          

     /* �ɮץHTab���j,Ū�X��� */
     iStart = -1;
     iLen = 0;
     for( iTmp = 0; iTmp < COLS; iTmp++)
     {
         iStart = iStart + iLen + 1;
         pStart = &readstr[iStart];
         iLen = strstr( pStart,"|")-pStart; 
         if( strstr( pStart,"|") == NULL) 
         {   puts("NULL");
             iLen = strlen( readstr) - iStart; 
         }
         printf("iLen[%d]\n", iLen); 
         strncpy( sData[iTmp], pStart, iLen); 
         sData[iTmp][iLen] = '\0'; 
         printf("sData[%d][%s]\n", iTmp, sData[iTmp]); 
     } 

     strcpy( itype, sData[0]);      /* ���ʧO */

     strncpy( ipolicy, sData[1]+2, CAR_POLICY_LEN); /* �O�渹 */
     ipolicy[CAR_POLICY_LEN] = '\0';

     formatDate( sData[3], dply_begin); /* �O�I�ͮĤ�� */ /* ������ഫ��db�i�������榡 */

     formatDate( sData[4], dply_end);   /* �O�I������ */ /* ������ഫ��db�i�������榡 */

     strcpy( itag_last, sData[5]);      /* ��P�Ӹ��X */

     strcpy( itag_next, sData[6]);      /* �s�P�Ӹ��X */

     formatDate( sData[7], dchange_ori);    /* ���s���P��� */ /* ������ഫ��db�i�������榡 */

      iCount++;
      /* ���H�i�L�Ъ����j���O�渹��X������� */
      $SELECT icard, fcard_class, iengine, itag, iassured 
         INTO $icard, $fcard_class, $iengine, $itag, $iassured
         FROM assured_vs_ply
        WHERE ipolicy = $ipolicy;

      printf("ipolicy[%s]\n ", ipolicy);

      if (SQLCODE == SQLNOTFOUND) /* �䤣��A�H�i�Ъ����j���O�渹��X������� */
      {
          strcat( ipolicy, sData[2]);
          printf("ipolicy&�Ъ���[%s]\n ", ipolicy);
          $SELECT icard, fcard_class, iengine, itag, iassured 
             INTO $icard, $fcard_class, $iengine, $itag, $iassured
             FROM assured_vs_ply
            WHERE ipolicy = $ipolicy;
          if (SQLCODE == SQLNOTFOUND)
          {
              sprintf_s(sMsg, sizeof sMsg, "���p�ɫO�渹�䤣��\t��[%d]��\t%s\t%s\t%s\t%s\t"
                            "%s\t%s\t%s\t\t\t", iCount, itype, ipolicy, 
                             dply_begin, dply_end, itag_last, itag_next, dchange_ori); 
              rgu_put_body_string(1, sMsg,LEFT); 
              rgu_put_body(1);
              iCountError ++;
              continue;
          }
      }

      $INSERT INTO ca_change_tag_ori
              ( itype, icard, itag_last,
                itag_next, dchange,   dply_begin, dply_end, ipolicy, fcard_class, icreate)
      VALUES (  $itype, $icard, $itag_last,
                $itag_next, $dchange_ori, $dply_begin, $dply_end, $ipolicy, $fcard_class, $userid);

      if( SQLCODE != 0)
      {
          /* �����~�T����춶�ǥ����P���Y���Ǥ@�P */
          sprintf_s(sMsg, sizeof sMsg, "�פJ����SQLCODE[%d],ERRM[%s]\t��[%d]��\t%s\t%s\t%s\t%s\t"
                        "%s\t%s\t%s\t\t\t", SQLCODE, sqlca.sqlerrm, iCount, itype, ipolicy, 
                         dply_begin, dply_end, itag_last, itag_next, dchange_ori); 
          rgu_put_body_string(1, sMsg,LEFT); 
          rgu_put_body(1);
          iCountError ++;
          continue;
      }
      iCountSuccess++;
     } /* End of While */
    
     fclose( report);
     sprintf_s(sMsg, sizeof sMsg, "���P��ƶפJ: ��J[%d]��, ����[%d]��, �@[%d]��\t\t\t\t\t\t\t\t\t\t\t", iCountSuccess, iCountError, iCount);
     rgu_put_body_string(1, sMsg,LEFT);
     rgu_put_body(1);
     rgu_put_body_string(1, "\t\t\t\t\t\t\t\t\t\t\t",LEFT);
     rgu_put_body(1);

     return M_CM_OK;
}
/* -------------------------------------------------------------------------------*/
$struct DATA
{
	char iendorse[25],sIpolicy[21];
	char nerror[256];
	char sIupcompShort[2], policyDB[21], policyDBname[41];
	char policy_1[POLICY_NUM_1],policy_2[POLICY_NUM_2];
	char payresult[5], paystatus[100], paydate[100], notedate[100];
	char sIcomp_in[BRANCH_ID], sIbranch_in[BRANCH_ID];
	char sIcomp_in_short[BRANCH_ID];
	char icomp_at[BRANCH_ID], ibranch_at[BRANCH_ID];
	char sIbranchIcomp[CA_POL_BRH_NUM];
	char sIbilling[3];
	char itype[2]; 
	char icard[21], icard_ply[21];             /* �ܼƷ|���,���ץ����ۦP */
	char itag_last[CA_TAG_NUM], itag_next[CA_TAG_NUM], itag[CA_TAG_NUM];  /* �ܼƷ|���,���ץ����ۦP */
	char dchange[11];       /* �ʲz�����Ѥ����ͮĤ�dchange_ori����O��ͮĤ�A�h�H�O��ͮĤ鬰���ͮĤ� */
	char dchange_ori[11];
	char dply_begin[11], dply_end[11];
	char ibatch_no[11];
	char iassured[13], iengine[CA_ENGINE_NUM], irelative_ply[21], old_dply_begin[11];
	char iquota[11], ileader[11], iofficer[11];
	long i_old_dply_begin, i_dchange_ori;
	char fedr_class[2];
	char sColumnData[512];
	char fstatus[2];
	char icar_type[3];
	long dissue;
	char fcard_class[2];
	char iroute[21];
	char dtransfer[11]; /* �L���*/
	char nleader[11], nofficer[11];
    char tmobile_appl[21],aemail_appl[51],feply[2],tmobile_eply[21],aemail_eply[51];  /*1090831006_SC2 �{�ҥ��x�j��q�l���ҥ���g�����mail�ˮ�*/
    char dpolicy[11];   
};

/* 1070118006_SC1 �s�WCAR339���O�\��, �s�W/�ק��ˮ֡Bemail�q����� */ 
/* **********************���P��郞�P�]P�^********************** */
$struct DATA data;

long car339_P()
{
/* General variables */
$char stmt[2048],tmp_str[21];
long  iCount, iCountSuccess, iCountError;
long  iCountNoTag, iCountTagError;
char  sNoTagFile[128], sTagErrorFile[128];
char  sNoTagFileFull[256], sTagErrorFileFull[256];
FILE *fNoTagFile, *fTagErrorFile;

    $WHENEVER SQLERROR GOTO errexit;

    iCount = iCountSuccess = iCountError = 0;
    iCountNoTag = iCountTagError = 0;
    
    /* ���Y, �s�W����, �����@�_�s�W */
    sprintf_s(sMsg, sizeof sMsg, "���~��]\t���A\t�O�渹\t��渹\t���ʧO\t�j���Ҹ�\t�W�����P\t���P���P\t"
                  "���P���\t�O�I�ͮĤ�\t�O�I�פ��\t");

    rgu_put_body_string(1, sMsg,LEFT);
    rgu_put_body(1);
        
    $DECLARE cur_m CURSOR WITH HOLD FOR 
       SELECT itype, icard, itag_last, itag_next, dchange, dply_begin, dply_end, fcard_class
         FROM ca_change_tag_ori
        WHERE fstatus = 'N';
         
    $OPEN cur_m;
    for(;;)
    {
         memset( &(data), 0, sizeof(struct DATA));
         $FETCH cur_m INTO $data.itype, $data.icard, $data.itag_last, $data.itag_next, $data.dchange_ori, 
                           $data.dply_begin, $data.dply_end, $data.fcard_class;
                              
         if (SQLCODE == SQLNOTFOUND) break;
         
         sprintf_s(data.sColumnData, sizeof data.sColumnData, "%s\t%s\t%s\t%s\t%s\t%s\t%s\t",
                        data.itype, data.icard, data.itag_last, data.itag_next, data.dchange_ori, data.dply_begin, data.dply_end);
         printf("data.sColumnData[%s]\n", data.sColumnData);
         iCount++;
         $BEGIN WORK;
	 
         strcpy( data.fedr_class, "7"); /* ���P��� */     
         strcpy( data.fstatus, "E"); /* ���D��w�] = E => ����email�q��*/
         strcpy( data.iendorse, " "); strcpy( data.sIpolicy ,  " ");
         strcpy( data.nerror ,  " "); strcpy( data.ileader ,  " ");

         if( data.itype[0] != '9')  /* �������O��9 �s�W */
         {
             $SELECT ipolicy1, iofficer, 
                     (SELECT nname FROM officer WHERE iofficer = cm_pre_receive.iofficer),
                     ileader ,
                     (SELECT nname FROM officer WHERE iofficer = cm_pre_receive.ileader)  
                Into $data.sIpolicy, $data.iofficer, $data.nofficer, $data.ileader, $data.nleader
                FROM cm_pre_receive
               WHERE icard = $data.icard and ipolicy1 <> ' ' and ipre_end = ' ';
             if (SQLCODE != SQLNOTFOUND) 
             { 
                 strcpy( data.fstatus, "T"); /* ���D�� =>  ��email�q��*/
                 strcpy( data.nerror, "�������O���R��");
             }else{
                 strcpy( data.nerror, "�������O���R��(�B�|���J��)");
             } 

             rc = log_P_data( &data);
             $COMMIT WORK;   /* �������~�icommit work�ᰵ�U�@�� */
             iCountError ++;
             continue;
         }
 
         /* �̾ڱj��d����X�O�渹 */         
         $SELECT ipolicy INTO $data.sIpolicy FROM assured_vs_ply
           WHERE icard = $data.icard;
         if (SQLCODE == SQLNOTFOUND)     /* �|���J�� �� �w�J��|���鵲 */
         {          
             if (data.fcard_class[0]=='1')
             {
                 $SELECT ipolicy,iofficer, 
                         (SELECT nname FROM officer WHERE iofficer = compulsory_card.iofficer) 
                    Into $data.sIpolicy,$data.ileader, $data.nleader
                    FROM compulsory_card
                   WHERE icard = $data.icard;
	             if (SQLCODE == SQLNOTFOUND) 
	             {
	                 strcpy( data.nerror, "���p�ɫO�渹�䤣��(�B�Ҹ����s�b�ҥd��)");
	             }
             }
             else if (data.fcard_class[0]=='2')
             {
                 $SELECT ipolicy,iofficer, 
                         (SELECT nname FROM officer WHERE iofficer = card.iofficer) 
                    Into $data.sIpolicy,$data.ileader, $data.nleader
                    FROM card
                   WHERE icard = $data.icard;
	             if (SQLCODE == SQLNOTFOUND) 
	             {
	                 strcpy( data.nerror, "���p�ɫO�渹�䤣��(�B�d�����s�b���N�d��)");
	             }
             }  

             if (strlen(trim(data.ileader))>0)       /* �ҡB�d�ɦ���ơA�B���g��N�� */
             {	                  
	             if (strlen(trim(data.sIpolicy))>0)  /* �w���o�O�渹 */
	             {
	                 $SELECT iofficer, 
	                         (SELECT nname FROM officer WHERE iofficer = cm_pre_receive.iofficer),
                             ileader ,
                             (SELECT nname FROM officer WHERE iofficer = cm_pre_receive.ileader)  
	                    Into $data.iofficer, $data.nofficer, $data.ileader, $data.nleader
	                    FROM cm_pre_receive
	                   WHERE ipolicy1 = $data.sIpolicy and ipre_end = ' ';

	                 strcpy( data.nerror, "���p�ɫO�渹�䤣��(�w�J��,�|���鵲)");
	             }else{
	                 strcpy( data.nerror, "���p�ɫO�渹�䤣��(�|���J��)");  /* �L�O�渹�A�q���d�Һ޲z�H*/
	             }
	             strcpy( data.fstatus, "T"); /* ���D�� =>  ��email�q��*/
             }      
                       
             rc = log_P_data( &data);
             $COMMIT WORK;   /* �������~�icommit work�ᰵ�U�@�� */
             iCountError ++;
             continue;
         }            
 
         if( find_policy( &data) != M_CM_OK)
         {
             rc = log_P_data( &data);
             $COMMIT WORK;   /* �������~�icommit work�ᰵ�U�@�� */
             iCountError ++;
             continue;
         }
         rc = check_P_data( &data);
         if(rc != M_CM_OK)
         {
             if( rc == -10) /* �O��L���P, �g�ɬ�����, �H�@����ɨ��P */
             {
                 if( iCountNoTag == 0)
                 {
                     sprintf_s(sNoTagFile, sizeof sNoTagFile,"�L���P_%s.txt", outputf);
                     sprintf_s(sNoTagFileFull, sizeof sNoTagFileFull,"%s/rptftp/%s", aphome, sNoTagFile);
                     if (( fNoTagFile=fopen(sNoTagFileFull,"w"))==NULL)
                     {
                         sprintf_s(sMsg, sizeof sMsg, "Cannot open Ouput file: %s\n", sNoTagFile);
                         printf("%s", sMsg);
                         $ROLLBACK WORK;
                         return M_CM_OPEN_FILE_FAIL;
                     }
                 }
                 fprintf( fNoTagFile, "%s\t%s\n", data.sIpolicy, data.itag_last); 
                 iCountNoTag++;
             }
             if( rc == -20) /* �O�樮�P����, �g�ɬ�����, �H�@�����郞�P */
             {
                 if( iCountTagError == 0)
                 {
                     sprintf_s(sTagErrorFile, sizeof sTagErrorFile,"�O�樮�P����_%s.txt", outputf);
                     sprintf_s(sTagErrorFileFull, sizeof sTagErrorFileFull,"%s/rptftp/%s", aphome, sTagErrorFile);
                     if (( fTagErrorFile=fopen(sTagErrorFileFull,"w"))==NULL)
                     {
                         sprintf_s(sMsg, sizeof sMsg, "Cannot open Ouput file: %s\n", sTagErrorFile);
                         printf("%s", sMsg);
                         $ROLLBACK WORK;
                         return M_CM_OPEN_FILE_FAIL;
                     }
                 }
                 fprintf( fTagErrorFile, "%s\t%s\n", data.sIpolicy, data.itag_last); 
                 iCountTagError++;
             }
             rc = log_P_data( &data);
             $COMMIT WORK;   /* �������~�icommit work�ᰵ�U�@�� */
             iCountError ++;
             continue;
         }
         rc = insert_edr( &data);
         printf("rc[%d]\n", rc);
         printf("data.iendorse[%s]\n", data.iendorse);
         if( rc != M_CM_OK)
         {
             strcpy( data.iendorse, " ");
             $ROLLBACK WORK;
             rc = log_P_data( &data);

             iCountError ++;
             continue;
         }
         else
         {
             strcpy( data.fstatus, "Y");
             rc = log_P_data( &data);
             if( rc != M_CM_OK)
             {
                 $ROLLBACK WORK;   /* ������令�\��T����, ����rollback work */
                 iCountError ++;
                 continue;
             }
             else
                 $COMMIT WORK;
             iCountSuccess ++;
         }
    } /* End for(;;) */
    if( iCountNoTag != 0)
    {
        fclose( fNoTagFile); 
        rc=rptftpinsert(userid,"car339", sNoTagFile );
        printf("rptftpinsert rc[%d]\n", rc);
        if (rc!=0)
        {
           sprintf_s(sMsg, sizeof sMsg,"�g�Jrptftplist���~\r\n");
           return rc;
        }
    }
    if( iCountTagError != 0)
    {
        fclose( fTagErrorFile); 
        rc=rptftpinsert(userid,"car339", sTagErrorFile );
        printf("rptftpinsert rc[%d]\n", rc);
        if (rc!=0)
        {
           sprintf_s(sMsg, sizeof sMsg,"�g�Jrptftplist���~\r\n");
           return rc;
        }
    }

    printf( "iCount=[%d]\n", iCount);
    $CLOSE cur_m;   
    $Free cur_m;

     sprintf_s(sMsg, sizeof sMsg, "���P���: ����[%d]��, ����[%d]��, �@[%d]��\t\t\t\t\t\t\t\t\t\t\t", iCountSuccess, iCountError, iCount);
     rgu_put_body_string(1, sMsg,LEFT);
     rgu_put_body(1);
     rgu_put_body_string(1, "\t\t\t\t\t\t\t\t\t\t\t",LEFT);
     rgu_put_body(1);

    printf("sMsg[%s]", sMsg);

    return M_CM_OK;

 errexit:

    sprintf_s(data.nerror, sizeof data.nerror, "SQLCODE[%d], ERRM[%s]", SQLCODE, sqlca.sqlerrm);
    sprintf_s(sMsg, sizeof sMsg, "%s\t%s\t%s\t%s\t%s", data.nerror, data.fstatus, data.sIpolicy, data.iendorse, data.sColumnData);
    printf("sMsg[%s]\n", sMsg);
    fclose( fNoTagFile); 
    fclose( fTagErrorFile); 
    return SQLCODE;
}
/* **********************�@���郞�P�]AC�^�]�O��L���P�Ψ��P���~�^********************** */
long car339_AC()
{
/* General variables */
$char stmt[2048];
long  iLen, iStart;
char  readstr[284],sDate[11];
long  iCount, iCountSuccess, iCountError;
char  FullGetName[101];
$char itype[2], ipolicy[21];
char  *pStart;

    $WHENEVER SQLERROR GOTO errexit;
    iCount = iCountSuccess = iCountError = 0;
    
    /* client�ݱNuser���Ѫ�����諸�����ftp��/dat/car/ */
    sprintf_s(FullGetName, sizeof FullGetName, "%s/dat/car/%s", aphome, sFileName); 
    
    if ((report=fopen(FullGetName,"r"))==NULL)
    {
        sprintf_s(sMsg, sizeof sMsg, "Cannot open ftp file: %s\n", FullGetName);
        printf("%s", sMsg);
        return M_CM_OPEN_FILE_FAIL;
    }
    iCount = iCountSuccess = iCountError = 0;
    /* ���Y, �s�W����, �����@�_�s�W */
    sprintf_s(sMsg, sizeof sMsg, "���~��]\t�O�渹\t��渹\t���P\t");

    rgu_put_body_string(1, sMsg,LEFT);
    rgu_put_body(1);
        
    while(1)
    { 
         fscanf(report,"%[^\n]%*c",readstr);

         if(feof(report)) break;
         printf("READSTR[%s]\n", readstr);          
         memset( &(data), 0, sizeof(struct DATA));
         /* �ɮץHTab���j,Ū�X��� */
         iStart = 0;
         pStart = &readstr[iStart];
         iLen = strstr( pStart,"\t")-pStart;
         printf("iLen[%d]\n", iLen);
         strncpy( data.sIpolicy, pStart, iLen);
         data.sIpolicy[20] = '\0';                        /* �O�渹 */
         printf("sIpolicy[%s]\n", data.sIpolicy);

         iStart = iStart + iLen + 1;
         pStart = &readstr[iStart];
         iLen = strstr( pStart,"\t") ? strstr( pStart,"\t")-pStart: pStart - readstr;
         strncpy( data.itag_next, pStart, iLen);
         data.itag_next[CA_TAG_NUM-1] = '\0';                        /* ���P */
         printf("itag_next[%s]\n", data.itag_next);
         
         sprintf_s(data.sColumnData, sizeof data.sColumnData, "%s\t", data.itag_next);
         printf("data.sColumnData[%s]\n", data.sColumnData);
         iCount++;
         strcpy( data.fedr_class, "5");     /* �@���郞�P */

         if( find_policy( &data) != M_CM_OK)
         {
             rc = log_AC_data( &data);
             iCountError ++;
             continue;
         }
         strcpy( data.dchange, data.old_dply_begin);
         $BEGIN WORK;
         if( insert_edr( &data) != M_CM_OK)
         {
             $ROLLBACK WORK;
             rc = log_AC_data( &data);

             iCountError ++;
             continue;
         }
         else
         {
             $COMMIT WORK;
             sprintf_s(sMsg, sizeof sMsg, "%s\t%s\t%s\t%s\t", data.nerror, data.sIpolicy, data.iendorse, data.sColumnData);
             rgu_put_body_string(1, sMsg,LEFT);
             rgu_put_body(1);

             iCountSuccess ++;
         }
    } /* End while */

    printf( "iCount=[%d]\n", iCount);

     sprintf_s(sMsg, sizeof sMsg, "�@���郞�P: ����[%d]��, ����[%d]��, �@[%d]��\t\t\t\t", iCountSuccess, iCountError, iCount);
     rgu_put_body_string(1, sMsg,LEFT);
     rgu_put_body(1);
     rgu_put_body_string(1, "\t\t\t\t",LEFT);
     rgu_put_body(1);

    printf("sMsg[%s]", sMsg);

    return M_CM_OK;

 errexit:

    sprintf_s(data.nerror, sizeof data.nerror, "SQLCODE[%d], ERRM[%s]", SQLCODE, sqlca.sqlerrm);
    sprintf_s(sMsg, sizeof sMsg, "%s\t%s\t%s\t%s", data.nerror, data.sIpolicy, data.iendorse, data.sColumnData);
    printf("sMsg[%s]\n", sMsg);
    return SQLCODE;
}
/* **********************���P���error log�]P�^********************** */
long log_P_data( data)
$struct DATA *data;
{
    $char tmp_dply_begin[11],tmp_dply_end[11];

    $WHENEVER SQLERROR GOTO errexit;
    printf("data->nerror[%s], data->sIpolicy[%s], data->iendorse[%s], data->sColumnData[%s]\n", 
            data->nerror, data->sIpolicy, data->iendorse, data->sColumnData);
    printf("data->fstatus[%s]\n", data->fstatus);
    printf("data->itype[%s]\n", data->itype);
    printf("data->icard[%s]\n", data->icard);
    printf("data->itag_last[%s]\n", data->itag_last);
    printf("data->itag_next[%s]\n", data->itag_next);
    printf("data->dchange_ori[%s]\n", data->dchange_ori);
    printf("data->dply_begin[%s]\n", data->dply_begin);
    printf("data->dply_end[%s]\n", data->dply_end);
    strcpy(data->nerror, rtrim(data->nerror));
    $UPDATE ca_change_tag_ori
        SET nerror  = $data->nerror , iupdate = $userid, dupdate = current year to second,
            fstatus = $data->fstatus, iendorse = $data->iendorse , ipolicy = $data->sIpolicy 
      WHERE itype = $data->itype AND
            icard = $data->icard AND
            itag_last =  $data->itag_last AND
            itag_next =  $data->itag_next AND
            dchange =  $data->dchange_ori AND
            dply_begin = $data->dply_begin AND
            dply_end =  $data->dply_end;
    printf("SQLCODE[%d]\n", SQLCODE);
    if (sqlca.sqlerrd[2] == 0) /* update ���� error */
    {
        sprintf_s(data->nerror, sizeof data->nerror, "��s���P����ɥ���,SQLCODE[%d]", SQLCODE);
        strcpy( data->iendorse, "");
        sprintf_s(sMsg, sizeof sMsg, "%s\t%s\t%s\t%s\t%s\t", data->nerror, data->fstatus, data->sIpolicy, data->iendorse, data->sColumnData);
        rgu_put_body_string(1, sMsg,LEFT);
        rgu_put_body(1);
        return -30;
    }
    else
    {
        sprintf_s(sMsg, sizeof sMsg, "%s\t%s\t%s\t%s\t%s\t", data->nerror, data->fstatus, data->sIpolicy, data->iendorse, data->sColumnData);
        rgu_put_body_string(1, sMsg,LEFT);
        rgu_put_body(1);

        /* �ݭn�q������A�g�J tmp_car339_P */ 
        if (strncmp(data->fstatus,"T",1)==0)
        {  
            strcpy(tmp_dply_begin, data->dply_begin);
            strcpy(tmp_dply_end  , data->dply_end);

            /* �O�o�פJ��ƵL�ӫO�_����A���w�J�� */
            if ( (strcmp(data->dply_begin,"01/01/1971")==0) && (strlen(trim(data->sIpolicy))>0) )
            {
		         /* ���o�޲z�H( for email �q��)*/                 		         
				 $SELECT dbegin,dend
		            Into $tmp_dply_begin, $tmp_dply_end
		            FROM cm_pre_receive
		           WHERE ipolicy1 = $data->sIpolicy AND ipre_end = ' ';
            }
			$INSERT INTO tmp_car339_P (itype, icard, itag_last, itag_next, dpolicy, dchange, dply_begin, dply_end, ipolicy, icar_type, iengine, nerror, iofficer, nofficer, ileader, nleader)
			 VALUES ($data->itype, $data->icard, $data->itag_last, $data->itag_next, $data->dpolicy, $data->dchange_ori, $tmp_dply_begin, $tmp_dply_end,
                      $data->sIpolicy, $data->icar_type, $data->iengine, $data->nerror, $data->iofficer, $data->nofficer, $data->ileader, $data->nleader );
            
        }       
    }

    return M_CM_OK;
 errexit:

    printf("SQLCODE[%d]\n", SQLCODE);
    sprintf_s(data->nerror, sizeof data->nerror, "SQLCODE[%d], ERRM[%s]", SQLCODE, sqlca.sqlerrm);
    sprintf_s(sMsg, sizeof sMsg, "log_P_data:%s\t%s\t%s\t%s\t%s", data->nerror, data->fstatus, data->sIpolicy, data->iendorse, data->sColumnData);
    printf("sMsg[%s]\n", sMsg);
    return SQLCODE;
}
/* **********************�@���郞�Perror log�]AC�^********************** */
long log_AC_data( data)
$struct DATA *data;
{
    sprintf_s(sMsg, sizeof sMsg, "%s\t%s\t%s\t%s\t", data->nerror, data->sIpolicy, data->iendorse, data->sColumnData);
    rgu_put_body_string(1, sMsg,LEFT);
    rgu_put_body(1);

    return M_CM_OK;
 errexit:

    sprintf_s(data->nerror, sizeof data->nerror, "SQLCODE[%d], ERRM[%s]", SQLCODE, sqlca.sqlerrm);
    sprintf_s(sMsg, sizeof sMsg, "log_AC_data:%s\t%s\t%s\t%s", data->nerror, data->sIpolicy, data->iendorse, data->sColumnData);
    printf("sMsg[%s]\n", sMsg);
    return SQLCODE;
}
/* **********************���P�������ˮ֡]P�^********************** */
long check_P_data( data)
$struct DATA *data;
{
$char stmt[2048];
long lng_dtransfer;

         $WHENEVER SQLERROR GOTO errexit;


         if( strcmp( data->icard, data->icard_ply) != 0) 
         {
             sprintf_s(data->nerror, sizeof data->nerror, "���P��ƪ��Ҹ��P�̷s�O���Ҹ�[%s]���P", data->icard_ply);
             return FAIL;
         }
         if( strlen( trim(data->itag)) == 0) 
         {
             strcpy( data->fstatus, "T"); /* ���D�� =>  ��email�q��*/
             /*sprintf_s(data->nerror, sizeof data->nerror, "�̷s�O���ƵL���P,������[%s], �e������[%s], �ХHcar339�ɨ��P ", data->iengine, data->itag_last);*/
             strcpy( data->nerror, "�̷s�O���ƵL���P");
             return -10;
         }

         if( strcmp( data->itag_last, data->itag) != 0)  /* �W�����P ��  �̷s�O�樮�P */
         {
             /* �B  �̷s�O�樮�P �� ���P���P  */
             if( strcmp( data->itag, data->itag_next) != 0) 
             {
                 strcpy( data->fstatus, "T"); /* ���D�� =>  ��email�q��*/ 
	             sprintf_s(data->nerror, sizeof data->nerror, "���P��ƤW�����P[%s]�P�̷s�O�樮�P[%s]���P", 
	                                     data->itag_last, data->itag);
             }
             else /* �̷s�O�樮�P = ���P���P (���w���)  */
             {
	             sprintf_s(data->nerror, sizeof data->nerror, "���P��ƤW�����P[%s]�P�̷s�O�樮�P[%s]���P,�����P���P[%s]�P�̷s�O�樮�P�ۦP(���w�ۦ洫�P)", 
	                                     data->itag_last, data->itag, data->itag_next);  
             }

             return -20;
         }
         /* �ʲz�����Ѥ����ͮĤ馭��O��ͮĤ�A�h�H�O��ͮĤ鬰���ͮĤ� */
         rc = rstrdate( data->dchange_ori, &data->i_dchange_ori );  /* �Nmm/dd/yyyy�নlong */
         if( rc!=0)
         {
             sprintf_s(data->nerror, sizeof data->nerror, "���s���P����ഫ���~");
             return FAIL;
         }
         rc = rstrdate( data->old_dply_begin, &data->i_old_dply_begin );  /* �Nmm/dd/yyyy�নlong */
         if( rc!=0)
         {
             sprintf_s(data->nerror, sizeof data->nerror, "�O��ͮĤ��ഫ���~");
             return FAIL;
         }

         if( data->i_dchange_ori < data->i_old_dply_begin) 
             strcpy( data->dchange, data->old_dply_begin);
         else
             strcpy( data->dchange, data->dchange_ori);

         
         /* chk if �̷s�O��w�L��,�B�L���ٴ��P�� */
         if (strlen(trim(data->dtransfer))>0){
             rc = rstrdate( data->dtransfer, &lng_dtransfer );  /* �Nmm/dd/yyyy�নlong */
             if (lng_dtransfer >= data->i_dchange_ori)
             {
	             sprintf_s(data->nerror, sizeof data->nerror, "�̷s�O��w�L��,�B�L���[%s]�ٴ��P��[%s]",data->dtransfer,data->dchange_ori);
	             return FAIL; 
             }
         }
           

         return M_CM_OK;
 errexit:

    sprintf_s(data->nerror, sizeof data->nerror, "SQLCODE[%d], ERRM[%s]", SQLCODE, sqlca.sqlerrm);
    sprintf_s(sMsg, sizeof sMsg, "%s\t%s\t%s\t%s\t%s", data->nerror, data->fstatus, data->sIpolicy, data->iendorse, data->sColumnData);
    printf("sMsg[%s]\n", sMsg);
    return SQLCODE;
}
/*****************************************************************************/
/* ���o�O���ƻP�@���ˮ�  */
/*****************************************************************************/
long find_policy( data)
$struct DATA *data;
{
$char stmt[2048];
$char dlock[31];
$char tmp_ipolicy[21];

         $WHENEVER SQLERROR GOTO errexit;
         /* ���o�O���Ʈw */
         data->sIupcompShort[0] = data->sIpolicy[2]; /* �O�渹�ĤT�X */
         data->sIupcompShort[1] = '\0';
         strcpy( data->policyDB, get_upcomp(data->sIupcompShort, USE_SHORT_BRANCH_ID, USE_BRANCH_ID));
         strcpy( data->policyDBname, get_full_dbname(data->policyDB));

         strncpy( data->sIbranchIcomp,  data->sIpolicy, CA_POL_BRH_NUM - 1);
         data->sIbranchIcomp[CA_POL_BRH_NUM - 1] = '\0';

         /* get ����k�ݤ�����c & �����q*/
         rc = cm_get_unit_in("", data->policyDB, userid, data->sIbranchIcomp, "C1", data->sIcomp_in, data->sIbranch_in);
         if ( rc != M_CM_OK)
         {
             sprintf_s(data->nerror, sizeof data->nerror, "����k�ݤ�����c & �����q�䤣��");
             return rc;
         }

         /* check ����k�ݤ����q�MDB�O�_�@�P*/
         if (strncmp( data->sIcomp_in, get_upcomp( data->policyDB, USE_BRANCH_ID, USE_BRANCH_ID), 1) != 0)
         {
             sprintf_s(data->nerror, sizeof data->nerror, "����k�ݤ����q�MDB���@�P");
             return FAIL;
         }

          /* get �O���k�ݤ����q²�X */
          strcpy( data->sIcomp_in_short, get_upcomp(data->sIcomp_in, USE_BRANCH_ID, USE_SHORT_BRANCH_ID));

          /* get ���B�z������c & �����q*/
          rc = cm_get_unit_at( userid, "C2", data->icomp_at, data->ibranch_at);
          if (rc != M_CM_OK)
         {
             sprintf_s(data->nerror, sizeof data->nerror, "���B�z������c & �����q�䤣��");
             return rc;
         }

         sprintf_s(stmt, sizeof stmt, "SELECT a.icard, a.iassured, a.itag, a.iengine, b.irelative_ply, b.dply_begin,"
                        "       b.iofficer, b.icar_type, a.dissue, b.dlock, a.iroute, b.dtransfer,b.fcard_class, "
                        "       b.feply , b.tmobile_eply , b.aemail_eply , a.tmobile_appl , a.aemail_appl,nvl(b.dpolicy,'') " 
                        "  FROM %s:policy a, %s:ply_relation b"
                        " WHERE a.ipolicy = b.ipolicy "
                        "   AND a.ipolicy = '%s' " , data->policyDBname, data->policyDBname, data->sIpolicy);
         printf("stmt[%s]\n", stmt);

         $PREPARE prep1 FROM $stmt;
         $EXECUTE prep1 INTO $data->icard_ply, $data->iassured, $data->itag, $data->iengine, $data->irelative_ply, $data->old_dply_begin,
                             $data->iofficer, $data->icar_type, $data->dissue, $dlock, $data->iroute, $data->dtransfer, $data->fcard_class,
                             $data->feply , $data->tmobile_eply , $data->aemail_eply , $data->tmobile_appl , $data->aemail_appl,$data->dpolicy;
         if( SQLCODE == SQLNOTFOUND)
         {
             strcpy( data->nerror, "�O���Ƨ䤣��"); /*���Ӥ��ӥi��A�]�� assured_vs_ply ��o�� */
             return FAIL;
         }

         /**** ��涷���s����g��H�~�Z�k�ݳ��κ޲z�H ****/
         $SELECT iquota, ileader ,nname
            INTO $data->iquota, $data->ileader ,$data->nofficer
            FROM officer
           WHERE iofficer = $data->iofficer;

         if (SQLCODE == SQLNOTFOUND)
         {
             strcpy( data->fstatus, "T");
             sprintf_s(data->nerror, sizeof data->nerror, "�g��H��Ƨ䤣��");
             return FAIL;
         }

         $SELECT nname
            INTO $data->nleader
            FROM officer
           WHERE iofficer = $data->ileader;

         rc = chk_iquota_expire( data->iquota, v_sMsg);
         if( rc != M_CM_OK)
         {
             strcpy( data->fstatus, "T");
             sprintf_s(data->nerror, sizeof data->nerror, "%s,�g��N��[%s],�޲z�H[%s]", v_sMsg, data->iofficer, data->ileader); 
             return FAIL;
         }

         /* chk �O�_�w�h�O */ 
         sprintf_s(stmt, sizeof stmt, "SELECT ipolicy FROM %s:ply_ins_type "
                        " WHERE ipolicy = '%s' "
                        " GROUP BY 1 "
                        " HAVING sum(mdamage_cover) > 0 " , data->policyDBname,  data->sIpolicy);
         printf("stmt[%s]\n", stmt);
         $PREPARE prepChk FROM $stmt;
         $EXECUTE prepChk INTO $tmp_ipolicy;
         if( SQLCODE == SQLNOTFOUND)
         {
             strcpy( data->nerror, "���O��w�h�O");
             return FAIL;
         }

         if (strncmp(data->iroute,"PA",2)==0)
         {
             strcpy( data->fstatus, "T"); /* ���D�� =>  ��email�q��*/
             sprintf_s(data->nerror, sizeof data->nerror, "�̷s�O��q���N�� = PA*(�q���N��[%s])",data->iroute);
             return FAIL;
         }

         if( strlen(trim(dlock)) != 0 ) /* ���O��B2C��襤�A�ȮɵL�k��� */
         {
              strcpy( data->fstatus, "T");
              strcpy( data->nerror, "���O��B2C��襤�A�ȮɵL�k���");
              return FAIL;
         }

         rc = ca_checkCarNo(data->itag_next, data->icar_type, data->dissue, v_sMsg);
         printf("ca_checkCarNo..rc[%d]\n", rc);
         if( rc != M_CM_OK)
         {
             strcpy( data->fstatus, "T");
             sprintf_s(data->nerror, sizeof data->nerror, "���P[%s]�榡���~(����[%s])", data->itag_next, data->icar_type); 
             return FAIL;
         }

         return M_CM_OK;
 errexit:

    sprintf_s(data->nerror, sizeof data->nerror, "SQLCODE[%d], ERRM[%s]", SQLCODE, sqlca.sqlerrm);
    sprintf_s(sMsg, sizeof sMsg, "%s\t%s\t%s\t%s\t%s", data->nerror, data->fstatus, data->sIpolicy, data->iendorse, data->sColumnData);
    printf("sMsg[%s]\n", sMsg);
    return SQLCODE;
}
/*****************************************************************************/
/* �s�W�����(�@��)  */
/*****************************************************************************/
long insert_edr( data)
$struct DATA *data;
{
$char stmt[20480],iroute_accept_edr[21];
int rc1;
         $WHENEVER SQLERROR GOTO errexit;         
         
         /* get ���s�X���O*/
         strncpy(data->sIbilling, data->sIpolicy+CAR_POL_CHR_POS-1, 2);
         data->sIbilling[2]='\0';

         rc = cm_get_serial_num_dwritten ("C2", &data->sIbilling,
                                           &data->sIcomp_in_short, &data->sIbranch_in,
                                           cm_cdate_str_100 (dwritten),
                                           cm_cdate_str_100 (cm_today ()), &data->iendorse);
         if (rc != 0)
         {
             if ( rc == 1 ||  rc == 2)
                 sprintf_s(data->nerror, sizeof data->nerror, "���~�N��[%d]:��Ʈw�L�k�}��", rc);
             else if ( rc == 3)
                 sprintf_s(data->nerror, sizeof data->nerror, "���~�N��[%d]:���۰ʵ�����Ƥ��s�b", rc);
             else 
                 sprintf_s(data->nerror, sizeof data->nerror, "���~�N��[%d]", rc);
             return rc;
         }
         
         printf("data->policyDB[%s]\n",data->policyDB);
         printf("data->sIpolicy[%s]\n",data->sIpolicy);
         printf("data->iendorse[%s]\n",data->iendorse);

         rc = bk_401( &data->policyDB, &data->sIpolicy, &data->iendorse);
         if ( rc != M_CM_OK)
         {
             sprintf_s(data->nerror, sizeof data->nerror, "�O��ƥ�����");
             return rc;
         }

         /* 1090831006_SC2 �{�ҥ��x�j��q�l���ҥ���g�����mail�ˮ� */
         rsetnull(CDTIMETYPE, (char *) &dnotifyornot);	
         strcpy(s_notifyornot,"");         
         if (data->fcard_class[0] == '1')
         {            
            if (
                 ( strlen(trim(data->tmobile_appl))==0 && strlen(trim(data->aemail_appl))==0 ) &&
                 ( ( data->feply[0]=='1' && strlen(trim(data->tmobile_eply))==0 && strlen(trim(data->aemail_eply))==0 ) || data->feply[0]=='0' )
               )
            {
                dtcurrent(&dnotifyornot);
                dttoasc(&dnotifyornot, s_notifyornot);
            }
            printf("--trace s_notifyornot[%s]",s_notifyornot);
         }

         data->policy_1[0]='\0';
         data->policy_2[0]='\0';

         strncpy(data->policy_1, data->sIpolicy, CAR_POLICY_LEN);
         data->policy_1[CAR_POLICY_LEN]=0;

         if (strlen(data->sIpolicy)>CAR_POLICY_LEN)
             strcpy(data->policy_2,&data->sIpolicy[CAR_POLICY_LEN]);
         else
             strcpy(data->policy_2," ");         

         ao_chk_charge( data->policyDB, 'A', data->policy_1, data->policy_2, data->ibatch_no,
                        data->payresult, data->paystatus, data->paydate, data->notedate);                        

         /*1071105008_SC2_ �������Ȩ��z��(FS)�A�éw�ɦ۰ʤU���ɮ�*/
         strcpy(iroute_accept_edr," ");         
         if(strncmp(data->iroute,"I009",4)==0)
	     {
             strcpy(data->iendorse, trim(data->iendorse));             
	         sprintf_s(iroute_accept_edr, sizeof iroute_accept_edr, "CHB%s", data->iendorse);             
	     }
	     printf("-- trace iroute_accept_edr[%s]\n ", iroute_accept_edr); 
	                             
         sprintf_s(stmt, sizeof stmt,"INSERT INTO %s:endorsement "
                "     (iendorse,    qply_period,  dply_begin,  dply_end,    fassured,"
                "      iassured,    iassured_ext, nassured,    ilicense,   "
                "      fsex,        fmarriage,    nuser,       ibenef,      nbenef,"
                "      aassured,    aassured_zip, itel,        apayment,    apayment_zip,"
                "      iply_area,   nbrand_abbr,  ncar_abbr,   fcar_note,   qcylinder,"
                "      iengine,     ibody,        itag,        mcar_price,  nequipment,"
                "      flimit,      pdmg_align,   pbrg_align,  plia_align,  idmg_rate,"
                "      pdmg_factor, ibrg_rate,    pbrg_factor, qpt,         fpt,"
                "      psex_age,    psex_age_damage, lia_class,    plia_acc,    dmg_acc_1st, dmg_acc_2nd,"
                "      dmg_acc_3rd, pdmg_acc,     fhuman,      fcomp_24,    payresult,"
                "      iext_policy, qpro_month,   mkilo_ply,   mkilo_edr,   irisk,"
                "      irelative_ext,"
                "      napplicant,  dbirth,   dissue,   "
                "      iextra_charge, gextra_charge, pextra_charge,  "
                "      iquery_num_damage, iquery_num, mequipment,         "
                "      survey_num,  bound_num,    abnormal_num, iapplicant, iroute, qlia_acc_sum, qdmg_acc_sum,"
                "      fapplicant,fsex_appl,dbirth_appl,itel_appl,ndeputy_appl,nrelation_appl,ndeputy_assured,"
                "       iassured_cntry, iapplicant_cntry, punknown_acc, iquery_num_unknown, qunknown_acc_sum, nassured_cntry, napplicant_cntry,"
                "       foccup, noccup, applicant_foccup, applicant_noccup, iroute_accept, tmobile_appl , aemail_appl) "
                " SELECT '%s', a.qply_period,           a.dply_begin,  a.dply_end,    b.fassured,"
                "      b.iassured,    b.iassured_ext, b.nassured,    b.ilicense,    "
                "      b.fsex,        b.fmarriage,    b.nuser,       b.ibenef,      b.nbenef,"
                "      b.aassured,    b.aassured_zip, b.itel,        b.apayment,    b.apayment_zip,"
                "      b.iply_area,   b.nbrand_abbr,  b.ncar_abbr,   b.fcar_note,   b.qcylinder,"
                "      b.iengine,     b.ibody,        '%s',          b.mcar_price,  b.nequipment,"
                "      b.flimit,      b.pdmg_align,   b.pbrg_align,  b.plia_align,  b.idmg_rate,"
                "      b.pdmg_factor, b.ibrg_rate,    b.pbrg_factor, b.qpt,         b.fpt,"
                "      b.psex_age,    b.psex_age_damage, b.lia_class,    b.plia_acc,    b.dmg_acc_1st, b.dmg_acc_2nd,"
                "      b.dmg_acc_3rd, b.pdmg_acc,     b.fhuman,      b.fcomp_24,    '%s',"
                "      b.iext_policy, b.qpro_month,   b.mkilo_ply,   b.mkilo_edr,   b.irisk,"
                "      b.irelative_ext,"
                "      b.napplicant,  b.dbirth,   b.dissue,"
                "      b.iextra_charge, b.gextra_charge, b.pextra_charge, "
                "      b.iquery_num_damage, b.iquery_num, b.mequipment,   "
                "      b.survey_num,  b.bound_num,    b.abnormal_num, b.iapplicant, b.iroute, b.qlia_acc_sum, b.qdmg_acc_sum,"
                "      b.fapplicant,b.fsex_appl,b.dbirth_appl,b.itel_appl,b.ndeputy_appl,b.nrelation_appl,b.ndeputy_assured,"
                "       CASE WHEN b.iassured_cntry='' THEN CASE WHEN b.fassured IN ('3','4') THEN '8'  ELSE '9' END"
                "            ELSE b.iassured_cntry END,"
                "       CASE WHEN b.iapplicant_cntry='' THEN CASE WHEN b.fapplicant IN ('3','4') THEN '8'  ELSE '9' END"
                "            ELSE b.iapplicant_cntry END,"
                "       b.punknown_acc, b.iquery_num_unknown, b.qunknown_acc_sum, b.nassured_cntry, b.napplicant_cntry,"
                "       b.foccup, b.noccup, b.applicant_foccup, b.applicant_noccup,'%s',b.tmobile_appl , b.aemail_appl"
                "  FROM %s:ply_relation a, %s:policy b"
                " WHERE a.ipolicy = b.ipolicy"
                "   AND a.ipolicy = '%s' ", data->policyDBname, data->iendorse, data->itag_next, data->payresult, 
                                            iroute_accept_edr,  data->policyDBname, data->policyDBname, data->sIpolicy);

         printf("[%s]\n",stmt);
         $PREPARE prep2 FROM  $stmt;
         $EXECUTE prep2;
         printf("SQLCODE[%d]\n", SQLCODE);
         /* 1091215005_SC2 �s�W�x�s����{���N�X����� */
         /* �U�CSQL��fedr_class�� 5:�@���� �� 7:���P��� */
         sprintf_s(stmt, sizeof stmt, "INSERT INTO %s:edr_relation "
                "       (iendorse,      fcard_class,   ipolicy,       icard,             irelative_ply, "
                "        irelative_edr, fedr_class,    fpay,          ipay,              iedr_field, "
                "        dedr_begin,    dedr_end,      ipro_year,     ibrand, "
                "        icar_type,     medrdmg_agent, medrdmg_commi, medrdmg_prem,      medrdmg_pure_prem,"
                "        medrlia_agent, medrlia_commi, medrlia_prem,  medrlia_pure_prem, ibig_comp, "
                "        ibig_branch,   ibig_office,   ibig_sales,    iresource,         ibroker, "
                "        iofficer,      ileader,       icorps,        iedr_area,         iedr_cashier, "
                "        iedr_examiner, dedr_examine,  dentry,        fprint, "
                "        itreaty,       ibranch,       iquota,        icomp_in,          ibranch_in, "
                "        icomp_at,      ibranch_at,    medr_ready,    medr_stable,       medr_compensate, "
                "        medr_adjcom,   medr_research, medr_invest,   medr_bus_rule,     medr_business, "
                "        medr_capital,  medr_maintain, fcomp_class,   fcomp_class_last,  fdiscount, "
                "        medrdmg_disc,  medrlia_disc,  iedr_return,   icar_flag,         terminate_rsn, "
                "        qcount,        iofficer_prmt, iquota_prmt,   ileader_prmt,      irate_type, "
                "        bzfrom,        iroute_comm,   icomm_obj,     isecond_hand,icard_main, qdrunk_driving, isign,"
                "        feply,         feedr,         aemail_eply,   tmobile_eply,      ireg_no,      dnotifyornot, "
                "        isign_edr, dsign_edr, fsign_status_edr, funder_chk_edr, iprog,qviolate ) "
                " SELECT  '%s',        fcard_class, ipolicy,     icard,            irelative_ply, "
                "        ' ',         '%s',         ' ',         ' ',              ' ', "
                "        '%s',        dply_end,    ipro_year,        ibrand, "
                "        icar_type,        0,           0,           0,                0, "
                "        0,           0,           0,           0,                ibig_comp, "
                "        ibig_branch, ibig_office, ibig_sales,  iresource,        ibroker, "
                "        iofficer,    '%s',        icorps,      iarea,            icashier, "
                "        '%s',        %ld,         %ld,         0, "
                "        itreaty,     ibranch,     '%s',        '%s',             '%s', "
                "        '%s',        '%s',        0,           0,                0, "
                "        0,           0,           0,           0,                0, "
                "        0,           0,           fcomp_class, fcomp_class_last, fdiscount, "
                "        0,           0,           '1',         icar_flag,        '0', "
                "        0,           iofficer_prmt, iquota_prmt, ileader_prmt,   irate_type, "
                "        bzfrom,      iroute_comm,   icomm_obj , isecond_hand,icard_main, qdrunk_driving, isign,"
                "        feply,       '0',         aemail_eply, tmobile_eply,     ireg_no , '%s' , "
                "        'system',    today,       40,          'N' ,             'car339',qviolate "
                "  FROM %s:ply_relation "
                " WHERE ipolicy = '%s'",
                 data->policyDBname, data->iendorse, data->fedr_class, data->dchange, data->ileader, trim(userid), dwritten,
                 dwritten, data->iquota, data->sIcomp_in, data->sIbranch_in,data->icomp_at,
                 data->ibranch_at, s_notifyornot, data->policyDBname, data->sIpolicy);

         $PREPARE prep3 FROM  $stmt;
         $EXECUTE prep3;
         printf("SQLCODE[%d]\n", SQLCODE);

         sprintf_s(stmt, sizeof stmt, "UPDATE %s:ply_relation "
                       "   SET iquota    = '%s',"
                       "       ileader   = '%s',"
                       "       fedr_class = '%s',"
                       "       dendorse = %d ,"
                       "       dnotifyornot   = '%s' "
                       " WHERE ipolicy = '%s'",
                             data->policyDBname, data->iquota, data->ileader, data->fedr_class, dwritten,s_notifyornot, data->sIpolicy);
         printf("[%s]\n",stmt);
         $PREPARE prep4 FROM  $stmt;
         $EXECUTE prep4;
         printf("SQLCODE[%d]\n", SQLCODE);

         sprintf_s(stmt, sizeof stmt, "UPDATE %s:edr_relation SET iedr_field = ? WHERE iendorse = '%s'",
                       data->policyDBname, data->iendorse);

         printf("[%s]\n",stmt);
         printf("iedr_field[%s]\n",iedr_field);
         $PREPARE prep5 FROM  $stmt;
         $EXECUTE prep5 USING $iedr_field;
         printf("SQLCODE[%d]\n", SQLCODE);

         sprintf_s(stmt, sizeof stmt, "UPDATE %s:policy "
                       "   SET itag    = '%s'"
                       " WHERE ipolicy = '%s'", data->policyDBname, data->itag_next, data->sIpolicy);

         $PREPARE prep6 FROM  $stmt;
         $EXECUTE prep6;
         printf("SQLCODE[%d]\n", SQLCODE);

         sprintf_s(stmt, sizeof stmt, "UPDATE %s:assured_vs_ply "
                         "  SET (itag) "
                         "    = (?) "
                         "WHERE ipolicy = '%s'",
                               data->policyDBname, data->sIpolicy);
         printf("[%s]\n",stmt);
         $PREPARE prep7 FROM  $stmt;
         $EXECUTE prep7 USING $data->itag_next;
         printf("SQLCODE[%d]\n", SQLCODE);

         if( data->fedr_class[0] == '7')
             sprintf_s(data->nerror, sizeof data->nerror, "�������P��郞�P");
         else
             sprintf_s(data->nerror, sizeof data->nerror, "�����@���郞�P");

    return M_CM_OK;

 errexit:

    rc1 = SQLCODE;
    sprintf_s(data->nerror, sizeof data->nerror, "SQLCODE[%d], ERRM[%s]", SQLCODE, sqlca.sqlerrm);
    sprintf_s(sMsg, sizeof sMsg, "%s\t%s\t%s\t%s\t%s", data->nerror, data->fstatus, data->sIpolicy, data->iendorse, data->sColumnData);
    printf("sMsg[%s]\n", sMsg);
    /* strcpy( data->iendorse, "");
    rc = log_P_data( &data);
    return rc1; */
    return SQLCODE;
}

int formatDate(char sTmp[11],char sDate[11])
{
        if( sTmp[0]==' ' || sTmp[0] == '0' || sTmp[0] == '\0')
        {   strcpy( sDate, " ");
            return;
        }
        sDate[0] = sTmp[4];
        sDate[1] = sTmp[5];
        sDate[2] = '/';
        sDate[3] = sTmp[6];
        sDate[4] = sTmp[7];
        sDate[5] = '/';
        sDate[6] = sTmp[0];
        sDate[7] = sTmp[1];
        sDate[8] = sTmp[2];
        sDate[9] = sTmp[3];
        sDate[10] = '\0';
}


char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  char sTmp_db_name[31];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
  }
  return sTmp_db_name;
}


/* -------------------------------------------------------------------------------- */
long car339_P_send_email()
{
	long	rc;
	int     sum_mail,mail_count ;
    $char   stmpA[13],stmpB[13], stmt[1024],ileader[11];
    FILE    *fp;

	$whenever sqlerror goto errexit;
	
	printf("--- car339_P_send_email() --- \n");

    /* mail���޲z�H(���ҥd�޲z�H) */
	sprintf_s(stmt, sizeof stmt,
	    "select * from tmp_car339_P "
	    "  where ileader = ? "
	    "  order by ipolicy;");

    printf("stmt[%s]\n",stmt);
    $prepare pre_s1 from $stmt;
    $declare cur_s1 cursor for pre_s1;

    
    strcpy(pre_ileader," ");
    strcpy(ileader," ");
    $declare cur_L1 cursor for
      select distinct ileader into $ileader
        from tmp_car339_P
       order by ileader;
    $open cur_L1;
    $fetch cur_L1;

    strcpy(pre_ileader,ileader);
    mail_count = 0; sum_mail= 0;
    while(1)
    {
	    if (SQLCODE==SQLNOTFOUND) break;

        printf("�޲z�H:ileader=[%s] pre_ileader=[%s]\n",ileader,pre_ileader);
		if (strcmp(ileader,pre_ileader)!=0)
		{
            printf("----- 111 ------ \n");
	        rc = car339_P_write_email();
	    	if (rc!=M_CM_OK) {
					printf("error on car339_P_write_email()��1\n");
					return rc;
	    	}
	    	mail_count=0;
	    	sum_mail++;
		}

		strcpy(pre_ileader,ileader);
        mail_count++;

		memset(fname,0x00,sizeof(fname));
		memset(filename,0x00,sizeof(filename));

		sprintf_s(fname, sizeof fname,"%s_carlink17�������P_%s",sys_time,trim(ileader));				
		sprintf_s(filename, sizeof filename,"%s/rptftp/car_email/%s.csv",aphome,fname);
				
		fp=fopen(filename,"w");
		fprintf(fp,ftitle);
		$open cur_s1 using $ileader;

		while(1)
		{
            memset( &(data), 0, sizeof(struct DATA));

		    $fetch cur_s1
		      into  $data.itype ,$data.icard,$data.itag_last,$data.itag_next,$data.dpolicy,$data.dchange,$data.dply_begin,$data.dply_end,
                    $data.sIpolicy,$data.icar_type,$data.iengine,$data.nerror,$data.iofficer,$data.nofficer,$data.ileader,$data.nleader;
		    if (SQLCODE==SQLNOTFOUND) break;
            
            if (data.iofficer[0]=='0'){            
                strcpy(stmpA,""); strcat(stmpA,data.iofficer);
            }else{
                strcpy(stmpA,data.iofficer);
            }

            if (data.ileader[0]=='0'){            
                strcpy(stmpB,""); strcat(stmpB,data.ileader);
            }else{
                strcpy(stmpB,data.ileader);
            }
            
		    fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s \n",
		            data.nerror, data.itype, data.icard, data.itag_last, data.itag_next, data.dpolicy, data.dchange,
                    data.dply_begin, data.dply_end, data.sIpolicy, data.icar_type, data.iengine,stmpA, data.nofficer,
                    stmpB, data.nleader);
        }

        $close cur_s1;
		fclose(fp);
		$fetch cur_L1;
    }
    $free  cur_s1;
    $close cur_L1;
    $free  cur_L1;

    if (mail_count!=0)
    {
        rc = car339_P_write_email();
        if (rc!=M_CM_OK) {
		    printf("error on car339_P_write_email()��2\n");
			return rc;
		}
        sum_mail++;
    }
    
    
    /* mail���֫O�H�� */
	sprintf_s(stmt, sizeof stmt,
	    "select * from tmp_car339_P "
	    "  where ipolicy[1,3]  in "
        "         (select unique detail from car_code "
	    "           where kind = 'T1' and detail = tmp_car339_P.ipolicy[1,3] and detail2 = ?) "
        "    and ipolicy <> '' "
	    "  order by ipolicy;");

    printf("stmt[%s]\n",stmt);
    $prepare pre_s2 from $stmt;
    $declare cur_s2 cursor for pre_s2;

    
    strcpy(pre_ileader," ");
    strcpy(ileader," ");
    
    $declare cur_L2 cursor for
      select distinct a.detail2 into $ileader
        from car_code a
       where a.kind = 'T1'
         and a.detail2 <> ' '
         and a.detail in (select distinct ipolicy[1,3] from tmp_car339_P where ipolicy <> '')
       order by a.detail2;
    $open cur_L2;
    $fetch cur_L2;

    strcpy(pre_ileader,ileader);
    mail_count= 0;
    while(1)
    {
	    if (SQLCODE==SQLNOTFOUND) break;

		if (strcmp(ileader,pre_ileader)!=0)
		{
	        rc = car339_P_write_email();
	    	if (rc!=M_CM_OK) {
					printf("error on car339_P_write_email() ��1\n");
					return rc;
	    	}
	    	mail_count=0;
	    	sum_mail++;
		}

		strcpy(pre_ileader,ileader);
        mail_count++;

		memset(fname,0x00,sizeof(fname));
		memset(filename,0x00,sizeof(filename));

		sprintf_s(fname, sizeof fname,"%s_carlink17�������P_%s",sys_time,trim(ileader));				
		sprintf_s(filename, sizeof filename,"%s/rptftp/car_email/%s.csv",aphome,fname);

		fp=fopen(filename,"w");

		fprintf(fp,ftitle);
		$open cur_s2 using $ileader;

		while(1)
		{
		    $fetch cur_s2
		      into  $data.itype ,$data.icard,$data.itag_last,$data.itag_next,$data.dpolicy,$data.dchange,$data.dply_begin,$data.dply_end,
                    $data.sIpolicy,$data.icar_type,$data.iengine,$data.nerror,$data.iofficer,$data.nofficer,$data.ileader,$data.nleader;

		    if (SQLCODE==SQLNOTFOUND) break;
		    
            if (data.iofficer[0]=='0'){            
                strcpy(stmpA,""); strcat(stmpA,data.iofficer);
            }else{
                strcpy(stmpA,data.iofficer);
            }

            if (data.ileader[0]=='0'){            
                strcpy(stmpB,""); strcat(stmpB,data.ileader);
            }else{
                strcpy(stmpB,data.ileader);
            }
            
		    fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s \n",
		            data.nerror, data.itype, data.icard, data.itag_last, data.itag_next, data.dpolicy, data.dchange,
                    data.dply_begin, data.dply_end, data.sIpolicy, data.icar_type, data.iengine,stmpA, data.nofficer,
                    stmpB, data.nleader);
        }

        $close cur_s2;
		fclose(fp);
		$fetch cur_L2;
    }
    $free  cur_s2;
    $close cur_L2;
    $free  cur_L2;

    if (mail_count!=0)
    {
        rc = car339_P_write_email();
        if (rc!=M_CM_OK) {
		    printf("error on car339_P_write_email() ��2\n");
			return rc;
		}
        sum_mail++;
    }


    return M_CM_OK;

errexit:
    sprintf_s(sMsg, sizeof sMsg, "car339_P_send_email(): SQLCODE[%d], ERRM[%s]", SQLCODE, sqlca.sqlerrm);    
    printf("sMsg[%s]\n", sMsg);
    return SQLCODE;
}
/* ------------------------------------------------------------------------- */

/* ------------------------------------------------------------------------- */
long car339_P_write_email()
{
    $whenever sqlerror goto errexit;

    printf("--- car339_P_write_email() --- \n");
    $select email,chinese_name
       into $email,$chinese_name
       from personal:asempl
      where empl_no = $pre_ileader;

    strcpy(email,trim(email));
    if (strlen(email) > 0){ 
         strcat(email,"@tmnewa.com.tw");
         printf("email[%s]\n",email);

         /*�קK���Ƶo�e 
         $delete from batchemail
           where project_id = $Porj_id
             and mail_date = today+1
             and receiver_email = $email
             and key = $fname;
         */    

        /*1110322014_SC2 batchemail�ಾ�ܷs���x */
        printf("--trace fname[%s]", fname);
        strcpy(nattachment," ");
        if (strlen(trim(fname)) > 0) 
        {
            sprintf_s(nattachment, sizeof nattachment, "%s.csv",trim(fname));
        }
        printf("--trace nattachment[%s]", nattachment);

         $INSERT INTO batchemail
		    (project_id, mail_date, receiver_email, receiver_name, cc,
		     content, key, mail_count, nsubject, nattachment)
         VALUES
		    ($Porj_id, today+1 , $email, $chinese_name, " ",
		     $ctxt, $fname, $mail_count, $nsubject, $nattachment);
    }
    return M_CM_OK;

errexit:
    sprintf_s(sMsg, sizeof sMsg, "car339_P_write_email(): SQLCODE[%d], ERRM[%s]", SQLCODE, sqlca.sqlerrm);    
    printf("sMsg[%s]\n", sMsg);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/

long car339_P_email_init()
{
    $char stmt[1024] ;

    $whenever sqlerror goto errexit;

    /* �t�ήɶ�(cyymmHHMM) */
    $select first 1 (year(today)-1911)||to_char(CURRENT,'%m%d%H%M') into $sys_time
       from car_code;
    strcpy(sys_time, trim(sys_time));
	printf("sys_time=[%s] \n",sys_time);


    $EXECUTE IMMEDIATE "DROP TABLE IF EXISTS tmp_car339_P";
    sprintf_s(stmt, sizeof stmt,"CREATE TEMP TABLE tmp_car339_P (\
		   itype		    char(1) ,\
	       icard            char(21),\
		   itag_last        char(%d),\
		   itag_next        char(%d),\
	       dpolicy		char(11),\
	       dchange          char(11),\
	       dply_begin       char(11),\
	       dply_end         char(11),\
	       ipolicy          char(20),\
	       icar_type	char(3),\
	       iengine		char(26),\
	       nerror           char(255),\
	       iofficer         char(10),\
	       nofficer         char(10),\
	       ileader          char(10),\
	       nleader          char(10)\
      ) With No Log;",CA_TAG_NUM-1,CA_TAG_NUM-1);
    $PREPARE pre_tmp FROM $stmt;
    $EXECUTE pre_tmp;


    strcpy(Porj_id,"CAR339");
    	    
    /* email������Y */
    strcpy(ftitle,
           "���~��],�������O,�j���Ҹ�,�W�����P,���P���P,ñ���,���P���,�O��ͮĤ�,"
           "�O��פ��,�O�渹,����,�������X,�g��N��,�g��W��,�޲z�H�N��,�޲z�H�W��\n");
    
    /* email�D�� */
    strcpy(nsubject,"");
    /*
    if (strstr( aphome, "PROD") == NULL)
    {
       strcpy(nsubject," [ �������ե� ] ");
    }*/
        
    strcat(nsubject,"�j���I���P��Ƨ��");



    /* email���e */
    sprintf_s(sContent, sizeof sContent ,
    "<html> \n" 
    "   <head> \n "
    "     <meta http-equiv=\"content-type\" content=\"text/html; charset=Big5\" > \n"
    "   </head>\n"
    "   <body>\n"
    "       <div style=\" width: 750px; text-align: left;\">\n"
    "           &nbsp;&nbsp;&nbsp;�z�n�G<br><br> \n"
    "           &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n"
    "           &nbsp;&nbsp;&nbsp;����O�ʲz�����Ѩ������P��ơA�g�P�����q�̷s�O���Ƥ�靈�H�U�e�t�Τ��i���f<br> \n"
    "           &nbsp;&nbsp;&nbsp;�����p�A�ݽЦU����U�T�{�ʲz�����Ѹ�ƪ����T�ʡA�p�T�{�ݧ�郞���̡A�Цۦ洣�X<br> \n"
    "           &nbsp;&nbsp;&nbsp;���ӽЮѶi��奿�A���¡C<br><br> \n"
    "           &nbsp;&nbsp;&nbsp;�� �t�Τ��i����������]�p�U�G<br><br> \n"
    "       </div>\n"
    "       <table style=\"text-align: left; width: 800; background-color: white; \" border=\"1\" BORDERCOLOR=\"#000000\" cellpadding=\"1\" cellspacing=\"1\">\n"
    "           <tr><td style= \"text-align: center; background-color:#BEBEBE; \">�t�Τ��i��諸���p</td>\n"
    "               <td style= \"text-align: center; background-color:#BEBEBE; \">���ŭ�]�ν����i��@�~</td>\n"
    "           </tr>\n"
    "           <tr><td>���p�ɫO�渹�䤣�� </td>\n"
    "               <td><li>�Ҹ��w�ܺʲz���ϥδ��P�A���t�Υ��J��A�Ш�U���t�J��A�ۦ��郞���C</li> \n"
    "                   <li>�Ҹ��w�X��A���t�Υ��鵲�A�鵲��Цۦ��郞���C</li>\n"
    "               </td>\n"
    "           </tr>\n"
    "           <tr><td>���P�榡���~ </td>\n"
    "               <td>�����榡���~�A�д��X���ӽЮѳq���֫O���奿</td>\n"
    "           </tr>\n"
    "           <tr><td>�O���ƵL���P </td>\n"
    "               <td>�����ťաA�ХH�̷s����+�O��ID�ۺʲz���Ьd�Ө����A�T�{�L�~�̡A���˪��Ӻʲz���e�����X���ӽЮѳq���֫O���奿</td>\n"
    "           </tr>\n"
    "           <tr><td>���P��ƤW�����P�P�̷s�O�樮�P���P </td>\n"
    "               <td>�O�o���ѭ�l���P�P�t�γ̷s���P���ŵL�k�۰ʧ��A�нT�{�C</td>\n"
    "           </tr>\n"
    "           <tr><td>�O��q���N��=PA* </td>\n"
    "               <td>����q�����P�i��v�T���ءA�G�@�߻ݥѳ��d�ҫ�A����</td>\n"
    "           </tr>\n"
    "           <tr><td>�������O���R�� </td>\n"
    "               <td>�ʲz�����ѤF���P�q���A�S�A�R���Ӵ��P��T�A�Ш�U�ۺʲz���d��</td>\n"
    "           </tr>\n"
    "       </table>\n"
    "       <br><br>&nbsp;&nbsp;&nbsp;�ӫO���~�Ȧ�F��&nbsp;&nbsp;�q��<br><br><br><br> \n"
    "   </body></html>	\n");
    ctxt.loc_loctype = LOCMEMORY;
    ctxt.loc_buffer = sContent;
    ctxt.loc_bufsize = 9000;
    ctxt.loc_size =  strlen(sContent) + 1;	
    return M_CM_OK;

errexit:

    sprintf_s(sMsg, sizeof sMsg, "car339_P_email_init(): SQLCODE[%d], ERRM[%s]", SQLCODE, sqlca.sqlerrm);    
    printf("sMsg[%s]\n", sMsg);
    return SQLCODE;
}