/**********************************************************************/
/*                                                                    */
/*   program id   : ca330q01s.ec                                      */
/*   program name : �ζ������ѵs�I�����@�~                            */
/*   date written : 2004/06/28                                        */
/*   date modify  : 2006/08/17 A�榬�O��ƼW�[��L�O�N                */
/*   author       : Neo Chen                                          */
/*                                                                    */
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "carmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
#include "safeclib.h"
$include "car_common.h";

/*--------------------------------------------------------------------*/
$char  option[2], pro_no[5], dbgn[11], dend[11], ctype[2];
$char  dbegin1[13], dend1[13];
$char  iprmt[11], nprmt[31], iagent[11], iofficer_1[2], ioff_chk[11], str_iagent[21];
$char  dply_bgn[13], dply_end[13], fanother[2], iofficera_1[2], ioff_chka[10];
$int   iremark = 0, iofficer_len, ioff_ck_bgn, ioff_ck_len, ioff_ck_end;
$int   lofficera , ioff_chk_bgna, ioff_chk_lena, ioff_ch_enda;
$long  mlimit;
int    optioni;
$char  icard[21], iquota[8];
$int   qins_type,qins_cnt;
$char  iins_type[11],str_iins[51];

/** �p��O�O **/
$char    ibrand[11], dissue[11], ipro_year[5], frate[4];
$double  car_price;
$int     mdeduct;
$char    fcar_class2[2];

/* SetCarage*/
$long    ply2_begin;
$long   cover_01_tmp, cover_01_11;
$long   cover_01, thousand_cover_01,damage_cover_01;
$int    car_age, car_age_mth;
$double year_dep, pdepreciate, brg_factor, car_price , s5_factor;
$double pdep_rate_year;

/* premium */
int     adj_age , int_ply_yr , tmp_cover_dep , thousand_cover_dep;
int     cover_dep , cover_dep_11;
double  adj_yr_dep;
long    mins_prem11;

/** static **/
$char  ipolicy[21],iofficer[10], nname[21], inext_ply[21];
$char  nassured[61], iengine[CA_ENGINE_NUM], itag[CA_TAG_NUM], nchi_full[31];
$char  dply_bgn1[13], dply_end1[13];
$char  ibig_office[10], iassured_A2[11], iassured_B1[11];
char   prt_title[21], prt_type[11], tmp_buf[21];
$int   iequip_flag;
$char  sequip_str[201], iequip_tmp[4];

/* car331_put_body4 */
$long   mins_premium, mins_premium_A, ldply_end_A, mdamage_cover_A,ldnext_bgn,ldnext_end,ldply_bgn_A;
$double pdiscount;
$char   dnext_bgn[13], dnext_end[13], dpolicy[13], ipolicy_A[21], dpay[13], dpayB[13];
$char   fedr_class[2], iofficer_B[11], fmail_to[2],nequipment_90[2],sIbig_sales[11],sales_name[41];

  int  i,j,count_db,rc;
DBinfo  *dbList;
DBinfo  *list;
DBinfo *get_sysdb_list();

$char DBName[05], iForm_Tp[03];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1];
char  outputf[N_FILE+1];
$char userid[11],choice[2];

char  msgbuf[100];
$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;

$char iapplicant_B[13];
$char napplicant_B[121];
$char f_FS_0105105[2];  /* �֪@�O�_���O01,05,105�I�� */
$int  FS_premium;       /* �֪@���N�I�`�O�O */

static int  max_cnt,num;

long car331_build();
void car331_title();
long car331_body();
void car331_print();
void car331_print_1();
void car331_put_body4();
long car3331_main();
static char *get_car_full_db();  /*   �ǤJ�O�渹��X���O�檺�k�ݸ�Ʈw */
static float MyPower();
double dbl_len8();
$char  dissue_A[11]=" ";
$long  lng_dissue_A;
$char  ipro_year_A[5]=" ";
$char  dissue_B[11]=" ";
$long  lng_dissue_B;
$long  lng_dply_begin_B = 0;
$int   qnext_year_chk= 99;
$int   qnext_year_B  = 0 ;
$char  ipro_year_B[5]=" ";
$char  v_sMsg[512];
$char  sFilterOption[2] = " ";
$char  fSend[2] = " ";
$char  iestimate[21],inumber[71];
$char  icar_type_1[3],iestimate_B[21];
$char  sIbranch[3],sFullDBName[31],sIQuota[5],sFullDBName_list[31];
int    fAdmin = 1; /* �O�_���ӫO�� */

/* N*�g�����  add by sylvia (1030630002_C1) */
/* �n�ഫ��N*�g�쪺�M�ץN��:C17,C18,Y50,Y54,Y55,Y57,Y58,Y59


/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
   int rc;

   batchinit();
   $WHENEVER SQLERROR GOTO errexit;
   strcpy(DBName, isNULLstr(argv[1]));
   strcpy(userid, isNULLstr(argv[2]));
   strcpy(option, isNULLstr(argv[3]));
   strcpy(pro_no, isNULLstr(argv[4]));
   strcpy(ctype,  isNULLstr(argv[5]));
   strcpy(dbgn, isNULLstr(argv[6]));
   strcpy(dend, isNULLstr(argv[7]));
   strcpy(sFilterOption, isNULLstr(argv[8]));
   strcpy(outputf,isNULLstr(argv[9]));

   strcpy(dbegin1, cm_to_infdate(dbgn));
   strcpy(dend1,   cm_to_infdate(dend));

   printf("option [%s] pro_no [%s] dbgn [%s] dend [%s]\n",
           option,  pro_no , dbgn, dend );
   printf("dbegin1 [%s] dend1 [%s] \n", dbegin1, dend1 );


   if (db_select(DBName) == FALSE) {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   /* '1071205001_SC1_ �վ�{���W�٨æ^�k���s�t��*/
   /* �Y�n�J�̤��~�Z��줣���u�ӫO���v�A�h�^������ƽd�򬰡��n�J�̩����ҰϤ���ơ� */
   strcpy(sFullDBName,"");  fAdmin = 1;
   strcpy(sIbranch,"");     strcpy(sIQuota,"");
   $SELECT ibranch,iquota[1,4] 
      into $sIbranch, $sIQuota
      FROM officer
     WHERE iofficer = $userid ; 
   if (SQLCODE==SQLNOTFOUND) return M_CMN_NOFFICER;
   if (strlen(sIbranch)==0) return M_CMN_NBRANCH;
   if (strcmp(sIQuota,"3201") != 0)
   {
       fAdmin = 0; 
       strcpy (sFullDBName, get_full_dbname (sIbranch));
       strcpy (sFullDBName, trim(sFullDBName));
   }
   

   max_cnt=0;
   rc = car331_build();

   if (rc != FAIL)
   {
       if ((rc=save_form_info(F_BLK0, "CA", 331, userid, iForm_Tp, max_cnt, outputf))<0) {
           strcpy(msgbuf,"save_form_info failed");
           return rc;
       }
   }

   return ;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;

}
/*--------------------------------------------------------------------*/

long car331_build()
{
   $char  TitleFmt[N_FILE+1],BodyFmt[N_FILE+1];
   int    rc,rtncode;
   $char stmt[500];


   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth ,iform_tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width ,$iForm_Tp
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 331 AND iform_tp = $option;

   strcpy( TitleFmt,rtrim(TitleFmt));
   strcpy( BodyFmt,rtrim(BodyFmt));
   sprintf_s(TitleFile, sizeof TitleFile,"%s.ti",outputf);
   sprintf_s(BodyFile, sizeof BodyFile,"%s.bd",outputf);

   printf("@@@@@@@@@@@@@@@@@@ titlefmt = [%s]",TitleFile);
   printf(" iForm_Tp [%s] \n",iForm_Tp);

   rgu_init_report(TitleFmt,TitleFile);
   car331_title();
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);

   rc = get_ca_promote();
   if( rc != M_CM_OK )
   {
      return rc;
   }

   if ((list = get_db_list (&count_db, DBName)) == (char *) 0)
   {
      if (EWRITE(userid, M_CM_NOT_DBLIST) == True)
            return M_CM_NOT_DBLIST;
      return M_CM_OK;
   }

   optioni = atoi(trim(option));
   switch (optioni)
   {
       case 0:  /** 102.03, ���M�׵��O��A�� **/
              rtncode = car331_body0();  printf("rtncode=[%d]\n", rtncode );
              if( rtncode != M_CM_OK )
                  return rtncode;

              break;

       case 1:  /** A��w��O�B�ŦX���� **/
              rtncode = car331_body1();  printf("rtncode=[%d]\n", rtncode );
              if( rtncode != M_CM_OK )
                  return rtncode;

              break;
              
       /*1071206003_SC1_car331���O2�uA��w��O�A�����ŦX����v�վ�A��ܡu2. A��w��O�A�����ŦX����v�Ƶ{����*/       
       case 2:  /** A��w��O�����ŦX���� **/
              rtncode = car331_body2();
              if( rtncode != M_CM_OK )
                  return rtncode;

              break;
       case 3:  /** A�楼��O **/
              rtncode = car331_body3();
              if( rtncode != M_CM_OK )
                  return rtncode;

              break;
       case 4:  /** B��w��O **/
              rtncode = car331_body4();
              if( rtncode != M_CM_OK )
                  return rtncode;

              break;
       case 5:  /** B�楼��O **/
              rtncode = car331_body5();
              if( rtncode != M_CM_OK )
                  return rtncode;

              break;
       default:
              return M_CM_WRONG_OPTION;

   }

   rgu_finish_report();
   printf( " next is M_CM_OK \n");
   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

void car331_title()
{
   rgu_put_head_string(1," ");
   rgu_put_head_string(1," ");
   rgu_put_head();
}

/* 0.���M�׵��O��A�� */
long car331_body0()
{
     int  searchB, no_found_B1,count_tot;
   $char  stmt[2048], stroff[300];
   $char  dply_bgn_A1[13], dply_end_A1[13], last_ply[21];
   $char  dply_bgn_B1[13], dply_end_B1[13], ipolicy_B1[21];
   $char  bIpolicy[21], inext_ply_B1[21], itag_B1[CA_TAG_NUM], iengine_B1[CA_ENGINE_NUM];
   $long  ldbgn1, ldend1, ldbgn2, ldend2;
   $long  ldbegin_A1, ldend_A1, mprem_A1;
   $int   iequip_flag, ply_ins_cnt, qnext_year, qyear_A1;
   $char  sequip_str[201];
   $char  iequip_tmp[4], iofficer_B1[11];
   $char  nequipment[31], temp_data[3];
   $char  ibig_comp_A[2]= " ";
   $int   tmp_cnt=0;
   $char  iengine_A2[CA_ENGINE_NUM] = " ";
   $char  s_dissue_A1[11],ioffice_A1[11],noffice_A1[11],ipolicy_A1[21],inext_ply_A1[21],iassured_A1[11],ipro_year_A1[5];

   /** ���� temp table (for �s�����body ) **/
   /*  ���O      	���I�N��  	    ���I����      �O�渹�X         	�O�����_��	�O��������	�o�Ӧ~��
       �s�y�~��	    �������X   	    ���P          �Q�O�I�H         	�Q�O�I�HID 	    �O�O            B��O�渹
       B��g��N��	�O�����_��	�O��������	�Q�O�I�HID 	  �������X
   */
   $CREATE TEMP TABLE CAR331_BODY0
   (
       nchi_full     char(30),
       iofficer      char(11),
       nofficer      char(20),
       ipolicy_a1    char(20),
       dply_bgn_a1   char(13),
       dply_end_a1   char(13),
       iengine       char(25),
       itag          char(12),
       iassured      char(11),
       nassured      char(61),
       dissue        char(10),
       ipro_year     char(4) ,
       mprem         integer ,
       ipolicy_b1    char(20),
       dply_bgn_b1   char(13),
       dply_end_b1   char(13),
       iassured_b1   char(11),
       iengine_b1    char(25),
       iofficer_b1   char(10)
   )
   WITH NO LOG;

   $CREATE INDEX CAR331_BODY0_ix1 ON CAR331_BODY0( ipolicy_a1 );
   $CREATE INDEX CAR331_BODY0_ix2 ON CAR331_BODY0( ipolicy_b1 );

   printf("in car331_body0  ���M�׵��O��A��\n");
   strcpy(prt_title,"���M�׵��O��A��");
   strcpy(prt_type,"�O������");

   strcpy(dply_bgn, dbegin1);
   strcpy(dply_end, dend1  );
   count_tot = 0;
   for( i=0; i< count_db; i++)
   {
      /** Part 1 �ѲĤ@�~ A ���ĤG�~ A �� **/
      /** 1. �Q�βĤ@�~A����� => ��O�渹(inext_ply) => ��XA��w��O��� **/
      strcpy(ipolicy_A1   , " " );   strcpy(ioffice_A1  , " " );  strcpy(noffice_A1 , " " );
      strcpy(dply_bgn_A1  , " " );   strcpy(dply_end_A1 , " " );  strcpy(nassured   , " " );
      strcpy(inext_ply_A1 , " " );   strcpy(iengine     , " " );  strcpy(itag       , " " );
      strcpy(s_dissue_A1  , " " );   strcpy(nchi_full   , " " );  strcpy(iassured_A1, " " );
      mprem_A1 = 0;

      iequip_flag = (iremark - 1) % 30 + 1;
      strcpy(iequip_tmp,rtrim(itoa(iremark)));
      strcpy(sequip_str,equip_instr(iequip_tmp));

      sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy, a.iofficer , (select nname from officer where iofficer = a.iofficer), "
                          "dply_begin, dply_end, b.nassured, a.inext_ply, b.iengine, b.itag,  "
                          "(a.mdmg_prem + a.mlia_prem), to_char(b.dissue,'%%Y')::integer - 1911 || '/' || to_char(b.dissue,'%%m'), "
                          "(select nbranch from sa_branch_type where ibranch = a.iquota),b.iassured,a.ipro_year  "
                    " FROM %s:ply_relation a , %s:policy b  "
                    "WHERE a.ipolicy = b.ipolicy AND  a.fcard_class = '2'  "
                    "  AND a.dply_end between '%s' AND '%s'  "
                    "  AND a.iofficer[1] in %s AND b.nequipment[%d] in %s  "
                    "  AND a.fedr_class <> '1' ",
                   list[i].dbname, list[i].dbname, dply_bgn, dply_end, trim(str_iagent),iequip_flag,sequip_str);

      printf("--> ��A��B���M�׵��O stmt[%s]\n", stmt);
      $PREPARE car331_0 FROM $stmt;
      $DECLARE car331_0a CURSOR for car331_0;
      $OPEN car331_0a;
      while(1)
      {
         $FETCH car331_0a INTO $ipolicy_A1, $ioffice_A1, $noffice_A1, $dply_bgn_A1, $dply_end_A1,
                               $nassured, $inext_ply_A1, $iengine, $itag ,$mprem_A1, $s_dissue_A1,$nchi_full,
                               $iassured_A1,$ipro_year_A1;
         if(SQLCODE == SQLNOTFOUND) break;
         count_tot ++;
         rstrdate( dply_end_A1, &ldend1 );
         rstrdate( dply_bgn_A1, &ldbgn1 );

         printf("trace ipolicy_A1[%s],iengine[%s]\n ",ipolicy_A1,iengine);
         /*------------------------------- ������� B ����  --------------------------------*/
         /*
              �Y���  �A�h�ˬdB��O�_�w��O�A�w��O�� continu
              �Y�����A�h�ˬd�O�_�� "A��Ĥ@�~�LB��" ���M�סA
                  �Y�O�A�h�P���ˬdB��O�_�w��O�A�w��O�� continu
         */
         /* �]����W,H�নN�����D, �אּŪ��ca_promote_officer�P�_�O�_���M�ץ� modify by sylvia 103.09.19 */
         /* if( fanother[0] == 'Y' )
         {
             sprintf_s(stroff, sizeof stroff,"AND((a.iofficer[1] = '%s' AND a.iofficer[%d,%d] = '%s'  "
                "AND length(a.iofficer) = %d) OR (a.iofficer[1] = '%s'  "
                "AND a.iofficer[%d,%d] = '%s' AND length(a.iofficer) = %d)) "
                 ,iofficer_1, ioff_ck_bgn, ioff_ck_end, ioff_chk, iofficer_len,
                 iofficera_1, ioff_chk_bgna, ioff_ch_enda, ioff_chka, lofficera );
         }
         else
         {
             sprintf_s(stroff, sizeof stroff,"AND a.iofficer[1] = '%s' AND a.iofficer[%d,%d] = '%s'  "
                "AND length(a.iofficer) = %d ",iofficer_1, ioff_ck_bgn,
                 ioff_ck_end, ioff_chk, iofficer_len );
         } */
         sprintf_s(stroff, sizeof stroff, " AND a.iofficer in (select unique iofficer_ori  "
                       "from ca_promote_officer where iprmt = '%s') ",pro_no);

         if( strcmp( pro_no ,"Y03") == 0 )
             strcat(stroff," AND a.iofficer[9,10] <> 'ES'");
         printf("trace s_dissue_A1[%s]\n ",s_dissue_A1);
         strcpy(s_dissue_A1,trim(s_dissue_A1));
		   lng_dissue_A = cm_build_date_ym(s_dissue_A1,1);
		   /*rstrdate(s_dissue_A1, &lng_dissue_A );*/
		   printf("trace lng_dissue_A[%ld]\n ",lng_dissue_A);
		   printf("trace ldbgn1[%ld]\n ",ldbgn1);
	  	   /*�H(�O��_��-�o�Ӧ~��)�p��M�׬��ĴX�~��,�Y�Ĥ@�~, qyear_A1=0 */
		   qyear_A1 = (int)floor((ldbgn1 - lng_dissue_A)/365.0 );  /* �L����˥h */

         printf("trace qyear_A1[%d]\n ",qyear_A1);

         /*
             ldbgn1                    ldend1
                �m           A1            �m              A2             �m

             |  �m           B1         |  �m              B2           | �m
           -30  �m                         �m                             �m
                �m |                       �m |                           �m |
                �m+30                      �m                             �m
         */
         strcpy(bIpolicy    , " " );   strcpy(dply_bgn_B1  , " " );  strcpy(dply_end_B1 , " " );
         strcpy(iassured_B1 , " " );   strcpy(inext_ply_B1 , " " );  strcpy(itag_B1     , " " );
         strcpy(iengine_B1  , " " );   strcpy(iofficer_B1  , " " );  strcpy(dissue_B    , " " );
         no_found_B1 = 0;

         for(searchB=0; searchB< count_db; searchB++)
         {
             sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy, a.dply_begin , a.dply_end, b.iassured, a.inext_ply,  "
                                 "b.itag, b.iengine, a.iofficer,(year(dissue)-1911)||'/'||TO_CHAR(dissue,'%%m')  "
                          " FROM %s:ply_relation a, %s:policy b, %s:ply_ins_type c  "
                          "WHERE a.ipolicy = b.ipolicy AND b.ipolicy = c.ipolicy  "
                          "  AND c.mdamage_cover > 0  "
                          "  AND b.iengine = '%s' AND a.fcard_class = '2'  "
                          "  AND b.nequipment[%d] in %s %s "
                          "  AND a.dply_begin >= %d AND a.dply_begin <= %d ",
                          list[searchB].dbname, list[searchB].dbname, list[searchB].dbname,
                          iengine, iequip_flag,sequip_str,stroff, ldbgn1 -30 , ldbgn1 + 30);

             $PREPARE pre_c0 FROM $stmt;
             $DECLARE cur_c0 CURSOR for pre_c0;
             $OPEN cur_c0;
             $FETCH cur_c0 INTO $bIpolicy, $lng_dply_begin_B, $dply_end_B1, $iassured_B1, $inext_ply_B1,
                           $itag_B1, $iengine_B1, $iofficer_B1,$dissue_B;
             if(SQLCODE == 0)
             {
             	 strcpy(dply_bgn_B1,cm_edate_str(lng_dply_begin_B));
             	 no_found_B1 = 1;
                 break;
             }
             $CLOSE cur_c0;
             $FREE  cur_c0;
         }
         printf("trace no_found_B1[%d]\n ",no_found_B1);
         if( no_found_B1 == 0 ) /* �S��������B�� */
         {
         	/* �T�{�O�_�� "A��Ĥ@�~�LB��" ���M��,1020805:�s�WY45  */
            /* Y18 �ΫH50part2 B��b�s���I�X��,���M�n�C�X�� */
            /* �s�W�ζ�������(Y62)�BDLR������(Y63) add by sylvia 104.03.10 (1040212008_C1) */
            if( (strcmp( pro_no, "Y18") == 0) || (ISPROJ_NO_FST_PLY_B(pro_no)&&(qyear_A1==0)) )
            {
                /* �ˬd�O�_��"�w��O"(�ĤG�~)��B�� */
		        for(searchB=0; searchB< count_db; searchB++)
		        {
		             /* �s�WN*�M�׸g�쪺�P�_����  modify by sylvia 103.09.16(1030630002_C1) */
		             sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy  "
		                          " FROM %s:ply_relation a, %s:policy b, %s:ply_ins_type c  "
		                          "WHERE a.ipolicy = b.ipolicy AND b.ipolicy = c.ipolicy  "
		                          "  AND c.mdamage_cover > 0  "
		                          "  AND b.iengine = '%s' AND a.fcard_class = '2'  "
		                          "  AND b.nequipment[%d] in %s  "
		                          "  and (a.iofficer[1] = 'W' or (a.iofficer[1] = 'H' and a.iofficer[2] not in ('0','1','2'))  "
		                          "        or a.iofficer in (select iofficer_ori from ca_promote_officer where iofficer_ori[1,1] = 'N'))  "
		                          "  AND a.dply_begin >= %d AND a.dply_begin <= %d ",
		                          list[searchB].dbname, list[searchB].dbname, list[searchB].dbname,
		                          iengine, iequip_flag,sequip_str, ldend1 -30 , ldend1 + 30);

		             $PREPARE pre_chk0 FROM $stmt;
		             $DECLARE cur_chk0 CURSOR for pre_chk0;
		             $OPEN cur_chk0;
		             $FETCH cur_chk0 INTO $inext_ply_B1;
		             if(SQLCODE == SQLNOTFOUND){
		             	 strcpy( inext_ply_B1, " ");
		             }else{
		              	 /* �Ĥ@�~�LB�� , ���ĤG�~B��w��O�X�� => strlen(trim(inext_ply_B1)) > 0 ) */
		             	 break;
		             }
		             $CLOSE cur_chk0;
		             $FREE  cur_chk0;
		        }
            }
            else{ /* �S��������B��A�B���O "A��Ĥ@�~�LB��" ���M�� */
                continue;
            }
         }else{ /* ��������B�� => �ˬd�M�׬O�_�w��� */

         	 /* 101.11,�]���Z�Ĩ��A  "+0.2(2.4�Ӥ�)" �אּ "-0.5(6�Ӥ�)"  */
             printf(" ------- dissue_B = [%s]\n " , dissue_B);
             printf(" ------- dply_begin_B_ch = [%s]\n " , cm_cdate_str_100(lng_dply_begin_B));
             if (dissue_B[0]!='\0'){
             	 strcpy(dissue_B,trim(dissue_B));
                 lng_dissue_B = cm_build_date_ym(dissue_B,1);
                 qnext_year_B    = (int)((lng_dply_begin_B - lng_dissue_B)/365.0 - 0.5 + 0.5);
                 printf(" ------- qnext_year_B = [%d]\n " , qnext_year_B);
                 printf(" ------- qnext_year_chk = [%d]\n " , qnext_year_chk);
                 if( qnext_year_B >= qnext_year_chk -1 )  continue;
             }
         }

         printf("bIpolicy=[%s]  inext_ply_B1=[%s]\n",bIpolicy, inext_ply_B1);
         /* B��w��O�A�����~����� */
         if( strlen(trim(inext_ply_B1)) > 0 ){
            	continue;
         }
         strcpy(itag,trim(itag));
         strcpy(iengine, trim(iengine));
         strcpy(iengine_B1, trim(iengine_B1));

         /** �L�X���� **/
         $INSERT INTO CAR331_BODY0 VALUES
         ($nchi_full, $ioffice_A1, $noffice_A1, $ipolicy_A1, $dply_bgn_A1, $dply_end_A1, $iengine, $itag,$iassured_A1,
          $nassured, $s_dissue_A1,$ipro_year_A1,$mprem_A1,$bIpolicy,$dply_bgn_B1,$dply_end_B1, $iassured_B1,$iengine_B1,$iofficer_B1);
      }
      $CLOSE car331_0a;
      $FREE  car331_0a;

   }
   printf("trace count_tot[%d]\n ",count_tot);

   /****************************************************************************************/
   /* ����title */
   rgu_put_body_string(1,prt_title,1);
   rgu_put_body_string(1,prt_type,1);
   rgu_put_body_string(1,dply_bgn,1);
   rgu_put_body_string(1,dply_end,1);
   rgu_put_body_string(1, cm_get_sysd(),1);
   rgu_put_body(1);
   max_cnt += 7;

   /* ����body */
   /*  ���O      	���I�N��  	    ���I����      �O�渹�X         	�O�����_��	�O��������	�o�Ӧ~��
       �s�y�~��	    �������X   	    ���P          �Q�O�I�H         	�Q�O�I�HID 	    �O�O        	B��O�渹
       B��g��N��	�O�����_��	�O��������	�Q�O�I�HID 	  �������X
   */
   $DECLARE rep_331_0 CURSOR FOR
     SELECT nchi_full ,iofficer ,nofficer ,ipolicy_a1, dply_bgn_a1, dply_end_a1, iengine , itag , iassured ,
            nassured ,dissue ,ipro_year,mprem, ipolicy_b1 ,dply_bgn_b1, dply_end_b1, iassured_b1, iengine_b1 , iofficer_b1
       INTO $nchi_full, $ioffice_A1, $noffice_A1, $ipolicy_A1, $dply_bgn_A1, $dply_end_A1, $iengine, $itag,$iassured_A1,
            $nassured, $s_dissue_A1, $ipro_year_A1,$mprem_A1,$bIpolicy,$dply_bgn_B1,$dply_end_B1, $iassured_B1,$iengine_B1,$iofficer_B1
       FROM CAR331_BODY0;
   $OPEN rep_331_0;
   while(1)
   {
   	$FETCH rep_331_0;

   	if(SQLCODE == SQLNOTFOUND) break;

        rgu_put_body_string(2,trim(nchi_full),LEFT);
        rgu_put_body_string(2,ioffice_A1 ,LEFT);
        rgu_put_body_string(2,noffice_A1 ,LEFT);
        rgu_put_body_string(2,trim(ipolicy_A1),LEFT);
        rgu_put_body_string(2,trim(dply_bgn_A1),LEFT);
        rgu_put_body_string(2,trim(dply_end_A1),LEFT);
        rgu_put_body_string(2,trim(s_dissue_A1),LEFT);
        rgu_put_body_string(2,trim(ipro_year_A1),LEFT);
        rgu_put_body_string(2,iengine,LEFT);
        rgu_put_body_string(2,itag,LEFT);
        rgu_put_body_string(2,nassured,LEFT);
        rgu_put_body_string(2,iassured_A1,LEFT);
        printf("--mprem_A1 [%d]\n", mprem_A1 );
        rfmtlong(mprem_A1, "---------&", tmp_buf);
        printf("trace tmp_buf[%s]\n ",tmp_buf);
        rgu_put_body_string(2,tmp_buf,LEFT);

        rgu_put_body_string(2,trim(bIpolicy),LEFT);
        rgu_put_body_string(2,iofficer_B1,LEFT);
        rgu_put_body_string(2,dply_bgn_B1,LEFT);
        rgu_put_body_string(2,dply_end_B1,LEFT);
        rgu_put_body_string(2,iassured_B1,LEFT);
        rgu_put_body_string(2,iengine_B1,LEFT);

        rgu_put_body(2);

        max_cnt += 1;

   }
   $CLOSE rep_331_0;
   $FREE  rep_331_0;

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(FAIL);
}

long car331_body1()
{

  $long  ldbgn, ldend, b_ldbgn, b_ldend, ldend2, ldendA1;
  $char  bIpolicy[21], Adpolicy[13], Adbegin[13], Adend[13];
  $char  bIofficer[11], bnname[21];
  $char  stmt[2048], ilast_ply[21], lastdbname[20], icard[21];
  $char  str_date[200], stroff[400];
   int   l_m_cm_ok=3500, found_B1,k;
  $int   ply_ins_cnt,qyear_A2;
  $char  iquota_A[7]= " ", iquota_B[7]=" ";
  $char  f_iquota_diff[2]= " ";
  $char  ioff_chk_B[6]=" ";
  $char  iofficer_exec[11]= " ";
  $char  iquota14[5]= " ";
  $char  pre_aIofficer[11]=" ", pre_aNofficer[21]=" ";
  $double dbl_estimate_prem;
  $long  estimate_prem;
  $char  nequipment_A[31]=" ",nequipment_90[2] = " ";
  $long  tmp_1101_chk,tmp_1201_chk,tmp_Y63_chk;
  $char  feply[2] = " "; /* �s�W�q�l�O����O (1070809006_SC4) */

  /* �]�� 2014/08/01-2014/08/31 ����X�ѵs�I�s�� add by sylvia (1030724002_C3)  */
  $int  f201408,pre_count11,icnt302;  /* 0:�_�O�餣�b2014/08/01  1:�_�O��b2014/08/01 */
  char  scount11[2];
  $char cm_iofficer[11];   /* �@�γ������ɤ����g��N�� */
  char  sTmpMsg[31];       /* �T�� */
  /* --------------------------------------------- */
  $char iassured_cntry[2], iapplicant_cntry[2];  /* RBA�t�Ϋظm add by sylvia 105.03.03 */
  $char foccup[2], noccup[6], applicant_foccup[2], applicant_noccup[6];  /* RBA�t�έק� add by sylvia 106.08.10 (1060606002_C5)*/
  max_cnt = 0;

  printf("in car331_body1  A��w��O�B�ŦX����\n");

  strcpy(prt_title,"A��w��O�B�ŦX����");

  if(strcmp(ctype,"1")==0)
  {
      strcpy(prt_type,"�O��ñ���");
      sprintf_s(str_date, sizeof str_date,"AND a.dpolicy >= '%s' AND a.dpolicy <= '%s'", dbegin1, dend1);
  }
  else if(strcmp(ctype,"2")==0)
  {
      strcpy(prt_type,"�O������");
      sprintf_s(str_date, sizeof str_date,"AND a.dply_end >= '%s' AND a.dply_end <= '%s' AND a.dpolicy is not null ", dbegin1, dend1);
  }
  else if(strcmp(ctype,"3")==0)
  {
      strcpy(prt_type,"���O���");
  }

  /* �]����W,H�নN�����D, �אּŪ��ca_promote_officer�P�_�O�_���M�ץ� modify by sylvia 103.09.19 */
  /*if( fanother[0] == 'Y' )
  {
      sprintf_s(stroff, sizeof stroff,"AND (( a.iofficer[1] = '%s' AND a.iofficer[%d,%d] = '%s'  "
                     "AND length(a.iofficer) = %d) OR ( a.iofficer[1] = '%s'  "
                     "AND a.iofficer[%d,%d] = '%s' AND length(a.iofficer) = %d)) "
                      ,iofficer_1, ioff_ck_bgn, ioff_ck_end, ioff_chk, iofficer_len,
                      iofficera_1, ioff_chk_bgna, ioff_ch_enda, ioff_chka, lofficera );
  }
  else
  {
      sprintf_s(stroff, sizeof stroff,"AND a.iofficer[1] = '%s' AND a.iofficer[%d,%d] = '%s'  "
                     "AND length(a.iofficer) = %d ",iofficer_1, ioff_ck_bgn,
                      ioff_ck_end, ioff_chk, iofficer_len );
  }*/

  sprintf_s(stroff, sizeof stroff, " AND a.iofficer in (select unique iofficer_ori  "
                       "from ca_promote_officer where iprmt = '%s') ",pro_no);

  if( strcmp( pro_no ,"Y03") == 0 )
     strcat(stroff," AND a.iofficer[9,10] <> 'ES'");

  printf("stroff=[%s]\n", stroff );

  rgu_put_body_string(1,prt_title,1);
  rgu_put_body_string(1,prt_type,1);
  rgu_put_body_string(1,dbegin1,1);
  rgu_put_body_string(1,dend1,1);
  rgu_put_body_string(1, cm_get_sysd(),1);
  rgu_put_body(1);

  max_cnt += 6;
  $WHENEVER SQLERROR GOTO errexit;

  /* 101.08.24 ,�ӧ�M�ץ�n�O�H����� (car152) , ��car331�������ݭn�n�ɤH���,car330 �X��ɥhcar152��K�i
    load �n�O�H���
  printf("Trace -- before load_iapp_data \n");
  rc = load_iapp_data();
  if (rc != M_CM_OK) {
     EWRITE(userid,rc,"M_CM_LOAD_FAIL");
     exit(FAIL);
  }
  */

  f201408 = 0;
  for( i=0; i< count_db; i++)
  {

      /* '1071205001_SC1_ �վ�{���W�٨æ^�k���s�t��*/
      /* �Y�n�J�̤��~�Z��줣���u�ӫO���v�A�h�^������ƽd�򬰡��n�J�̩����ҰϤ���ơ� */
      strcpy(sFullDBName_list , trim(list[i].dbname) );
      printf("-- trace sFullDBName_list[%s]\n ",sFullDBName_list);
      printf("-- trace sFullDBName[%s]\n ",sFullDBName);
      if (fAdmin==0){  /*�D�ӫO��*/
         if (strcmp(sFullDBName, sFullDBName_list) != 0) continue;
      }
      
      /**  1. ��X�ŦX����(����϶��B�M�׵��O)�� "�w�X��(��O)��A����"  **/
      iequip_flag = (iremark - 1) % 30 + 1;
      strcpy(iequip_tmp,rtrim(itoa(iremark)));
      strcpy(sequip_str,equip_instr(iequip_tmp));
      strcpy(iassured_cntry, " ");      /* �Q�O�I�H��O���O(RBA�t�Ϋظm) add by sylvia 105.03.03  (1050105008_C4) */
      strcpy(iapplicant_cntry, " ");    /* �n�O�H��O���O(RBA�t�Ϋظm) add by sylvia 105.03.03  (1050105008_C4) */
      strcpy(foccup," ");               /* �Q�O�I�H¾/��~�O(RBA�t�Ϋظm)  add by sylvia 106.08.10 (1060606002_C5) */
      strcpy(noccup," ");               /* �Q�O�I�H¾/��~�O�N��(RBA�t�Ϋظm)  add by sylvia 106.08.10 (1060606002_C5) */
      strcpy(applicant_foccup, " ");    /* �n�O�H¾/��~�O(RBA�t�Ϋظm)  add by sylvia 106.08.10 (1060606002_C5) */
      strcpy(applicant_noccup, " ");    /* �n�O�H¾/��~�O�N��(RBA�t�Ϋظm)  add by sylvia 106.08.10 (1060606002_C5) */
      /* �s�WN*�g�쪺�P�_���� modify by sylvia 103.09.16(1030630002_C1) */
      if(strcmp(ctype,"3")!=0) /* �O��ñ���, �O������ */
          sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy, a.iofficer , (select nname from officer  "
                              "where iofficer = a.iofficer), dply_begin, dply_end,  "
                              "b.nassured, b.iengine, b.itag, a.dpolicy, b.iassured,  "
                              "(select nbranch from sa_branch_type where ibranch = a.iquota),  "
                              "ilast_ply, a.icard , (year(dissue)-1911)||'/'||TO_CHAR(dissue,'%%m'),a.ipro_year,a.iquota,b.nequipment,  "
                              "case when (a.dply_begin >= '08/01/2014' ) then 1 else 0 end,  "
                              "b.iassured_cntry, b.iapplicant_cntry,  "
                              "b.foccup, b.noccup, b.applicant_foccup, b.applicant_noccup, a.feply  "
                        "  FROM %s:ply_relation a , %s:policy b  "
                        "WHERE a.ipolicy = b.ipolicy  "
                        "  AND a.fcard_class = '2' AND a.icar_flag = '2'  "
                        "  AND a.iofficer[1] in %s AND b.nequipment[%d] in %s  "
                        "  AND a.fedr_class <> '1'  "
                        "  AND a.iofficer not in (select unique iofficer_ori from ca_promote_officer where iprmt = '%s')  "
                        "  AND (a.dpolicy - a.dply_begin) < 30  "
                        "  AND (a.mdmg_prem + a.mlia_prem) >= %d %s",
                       list[i].dbname, list[i].dbname, trim(str_iagent), iequip_flag, sequip_str, pro_no, mlimit, str_date );
      else	/* ���O�� */
          sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy, a.iofficer , (select nname from officer  "
                              "where iofficer = a.iofficer), dply_begin, dply_end,  "
                              "b.nassured, b.iengine, b.itag, a.dpolicy, b.iassured,  "
                              "(select nbranch from sa_branch_type where ibranch = a.iquota),  "
                              "ilast_ply, a.icard , (year(dissue)-1911)||'/'||TO_CHAR(dissue,'%%m'),a.ipro_year,a.iquota,b.nequipment,  "
                              "case when (a.dply_begin >= '08/01/2014' ) then 1 else 0 end,  "
                              "b.iassured_cntry, b.iapplicant_cntry,  "
                              "b.foccup, b.noccup, b.applicant_foccup, b.applicant_noccup, a.feply  "
                        " FROM %s:ply_relation a , %s:policy b, %s:ao_plyedr_prem c  "
                        "WHERE a.ipolicy = b.ipolicy  "
                        "  AND b.ipolicy = c.ipolicy1  "
                        "  AND a.fcard_class = '2' AND a.icar_flag = '2'  "
                        "  AND a.iofficer[1] in %s AND b.nequipment[%d] in %s  "
                        "  AND a.fedr_class <> '1'  "
                        "  AND a.iofficer not in (select unique iofficer_ori from ca_promote_officer where iprmt = '%s')  "
                        "  AND (a.dpolicy - a.dply_begin) < 30  "
                        "  AND (a.mdmg_prem + a.mlia_prem) >= %d  "
                        "  AND c.dpay between '%s' AND '%s'  "
                        "  AND c.ftype = 'P' ",
                       list[i].dbname, list[i].dbname, list[i].dbname, trim(str_iagent),
                       iequip_flag, sequip_str, pro_no, mlimit, dbegin1, dend1);

      printf("--> line 330 stmt[%s]\n", stmt);
      $PREPARE car331_1 FROM $stmt;
      $DECLARE car331_1a CURSOR for car331_1;
      $OPEN car331_1a;
      while(1)
      {

         $FETCH car331_1a INTO $ipolicy,  $iofficer, $nname, $ldbgn, $ldend,
                               $nassured, $iengine, $itag, $Adpolicy, $iassured_A2,
                               $nchi_full, $ilast_ply, $icard,$dissue_A,$ipro_year_A,$iquota_A,$nequipment_A,
                               $f201408, $iassured_cntry, $iapplicant_cntry,
                               $foccup, $noccup, $applicant_foccup, $applicant_noccup, $feply;
         if(SQLCODE == SQLNOTFOUND)
         {
            printf("in SQLNOTFOUND \n");
            break;
         }
         printf("--- 747 f201408=[%d]\n ",f201408);
         /*printf("ipolicy[%s] ldbgn[%d] nchi_full[%s]\n", ipolicy, ldbgn, nchi_full);
         printf("ipolicy[%s] ilast_ply=[%s]\n", ipolicy,ilast_ply ); */
         /** check A ��Y�L�D�I => �C�L���D�� **/
         sprintf_s(stmt, sizeof stmt,"SELECT count(*) FROM %s:ply_ins_type  "
                       "WHERE ipolicy = '%s' AND iins_type in (SELECT iins_type FROM insurance_type WHERE iins_type = imain_ins)  "
                       "  AND mdamage_cover > 0 ",list[i].dbname, ipolicy );
         $PREPARE g_ins_cnt FROM $stmt;
         $EXECUTE g_ins_cnt INTO $ply_ins_cnt;
         if( ply_ins_cnt == 0 )
             continue;

         strcpy(Adbegin, cm_edate_str(ldbgn));
         strcpy(Adend,   cm_edate_str(ldend));

         /** ���ĤG�~�O��A��Ĥ@�~ B �� **/
         /** A��ĤG�~�O�����e��45�ѧ�Ĥ@�~B��**/
         /** 960227, �U�o�ֱM�ײĤ@�~�LB�� **/
         /** 970813, �s�߶R�@�e�|�M�ײĤ@�~�LB�� **/
/*
         �m           A1            �m              A2             �m
      |  �m           B1         |  �m              B2           | �m
         �m                    -45  �m                             �m
         �m |         B1            �m |            B2             �m |
         �m                         �m +45                         �m
*/
         b_ldbgn = ldbgn - 45;
         b_ldend = ldbgn + 45;
         strcpy(dissue_A, trim(dissue_A));
         lng_dissue_A = cm_build_date_ym(dissue_A,1);

         /*960724, �H(�O��_��-�o�Ӧ~��)�p��M�׬��ĴX�~��,�Y�ĤG�~��O, qyear_A2==1 */
         qyear_A2 = (int)floor((ldbgn - lng_dissue_A)/365.0 ); /* �L����˥h */
         printf(" ------- Adbegin = [%s]\n " , Adbegin);
         printf(" ------- ldbgn = [%ld]\n " , ldbgn);
         printf(" ------- dissue_A = [%s]\n " , dissue_A);
         printf(" ------- lng_dissue_A = [%ld]\n " , lng_dissue_A);

         printf("qyear_A2[%d]  ilast_ply[%s]\n ", qyear_A2, ilast_ply);

         /**  2. �ˬd�O�_���e�@�~B���ơG
                       �H"�w�X��(��O)��A����" ���y�ͮĤ���e�B��45�ѡz ,��������������϶�����  **/

         /*      (1) �w��O��A��S���e�O�渹  */

         if( strlen(trim(ilast_ply)) == 0 )
         {
             printf(" ------- �w��O��A��S���e�O�渹[%s]\n" ,ipolicy );
             g_b_data:

             found_B1=0;
             /** 990510, ���ظU�o�ֱM��(C17)�Ĥ@�~�LB��*/
             /** ���קK����X��A�Ҧ���Ʈw���ݧ��� **/
             /** 960227, �U�o�ֱM�ײĤ@�~�LB�� **/ /** 970813, �s�߶R�@�e�|�M�ײĤ@�~�LB�� **/
             /*  => �S��B��i�Hcheck, ��check �e�@�~A����O������O�_�ŦX */
             /*
             if(((strcmp( pro_no, "C17") == 0)||(strcmp( pro_no, "C15") == 0)||(strcmp( pro_no, "P01") == 0)||
                 (strcmp( pro_no, "Y47") == 0)||(strcmp( pro_no, "Y48") == 0)||(strcmp( pro_no, "Y49") == 0)||(strcmp( pro_no, "Y50") == 0))&&(qyear_A2==1)
               )*/
             /* ISPROJ_NO_FST_PLY_B()����,�w�q��car_common.h ,1020805:�s�WY45, 1030423:�s�WC18�֪@�M�ס@*/
             /* �s�W�ζ�������(Y62)�BDLR������(Y63) add by sylvia 104.03.10 (1040212008_C1) */
             if (ISPROJ_NO_FST_PLY_B(pro_no)&&(qyear_A2==1))
             {
                printf("---------------------------- \n");
	             for( k=0; k< count_db; k++)
	             {
		               sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy  "
		                        " FROM %s:ply_relation a , %s:policy b  "
		                        "WHERE a.ipolicy = b.ipolicy  "
		                        "  AND a.fcard_class = '2'  "
		                        "  AND a.iofficer[1] in %s AND b.nequipment[%d] in %s  "
		                        "  AND a.fedr_class <> '1'  "
		                        "  AND a.iofficer not in (select unique iofficer_ori from ca_promote_officer where iprmt = '%s')  "
		                        "  AND (a.mdmg_prem + a.mlia_prem) >= %d  "
		                        "  AND b.iengine = '%s'  "
		                        "  AND a.dply_end >= %d AND a.dply_end <= %d",
		                       list[k].dbname, list[k].dbname, trim(str_iagent), iequip_flag, sequip_str,pro_no, mlimit,iengine, b_ldbgn, b_ldend );

		               printf("lin 376 stmt=[%s]\n", stmt );

		               $PREPARE PRE_a4 FROM $stmt;
		               $DECLARE cur_a4 CURSOR for PRE_a4;
		               $OPEN cur_a4;
		               $FETCH cur_a4 INTO $bIpolicy;
		               if(SQLCODE != SQLNOTFOUND)
		               {
		                  $CLOSE cur_a4;
		                  $FREE  cur_a4;
		                  found_B1 = 1;

	                      printf(" ------- test1 \n ");
	                      strcpy( bIpolicy, " ");
	                      ldend2 = 0;
	                      strcpy( iassured_B1, " ");
	                      strcpy( bIofficer, " ");
	                      strcpy( bnname, " ");
	                      strcpy( iquota_B," ");

		                  break;
		               } else{
		                  $CLOSE cur_a4;
		                  $FREE  cur_a4;
		               }
                  }
             }else{
	             for( k=0; k< count_db; k++)
	             {
	             	 sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy, a.iofficer, a.dply_end, iassured,(year(dissue)-1911)||'/'||TO_CHAR(dissue,'%%m'),a.dply_begin,  "
	             	          "(select nname from officer where iofficer = a.iofficer),a.iquota,a.ibig_office,b.iapplicant,b.napplicant  "
	                       " FROM %s:ply_relation a, %s:policy b, %s:ply_ins_type c  "
	                       "WHERE a.ipolicy = b.ipolicy AND b.ipolicy = c.ipolicy  "
	                       "  AND c.mdamage_cover > 0 AND a.fedr_class <> '1'  "
	                       "  AND b.iengine = '%s' AND a.fcard_class = '2'  "
	                       "  AND b.nequipment[%d] in %s  "
	                       "  AND a.dply_end >= %d AND a.dply_end <= %d  "
	                       "  AND a.iofficer in (select unique iofficer_ori from ca_promote_officer where iprmt = '%s')",
	                 list[k].dbname, list[k].dbname, list[k].dbname,
	                 iengine, iequip_flag, sequip_str, b_ldbgn, b_ldend, pro_no );
	                 printf("lin 377 stmt=[%s]\n", stmt );

	               	 $PREPARE cur_b3 FROM $stmt;
	                 $DECLARE cur_b4 CURSOR for cur_b3;
	                 $OPEN cur_b4;
	                 $FETCH cur_b4 INTO $bIpolicy, $bIofficer, $ldend2, $iassured_B1,$dissue_B,$lng_dply_begin_B,$bnname,$iquota_B,
	                                    $ibig_office,$iapplicant_B,$napplicant_B;
	                 if(SQLCODE != SQLNOTFOUND)
	                 {
	                    $CLOSE cur_b4;
	                    $FREE  cur_b4;
	                    found_B1 = 1;
	                    break;
	                 } else{
	                    $CLOSE cur_b4;
	                    $FREE  cur_b4;
	                 }
	             }
	             printf(" ------- found_B1 = [%d]\n " , found_B1);
             }
             /* �L�e�@�~B����,�B�e�@�~A�椣�ŦX�M�ױ���(���O�B�O�O) */
             if( found_B1 == 0 )
             {
                /* �����M�ײĤ@�~�LB��, Y18 �ΫH50part2 B��b�s���I�X�� */
                if(strcmp( pro_no, "Y18") == 0)
                {
                    printf(" ------- test1 \n ");
                    strcpy( bIpolicy, " ");
                    ldend2 = 0;
                    strcpy( iassured_B1, " ");
                    strcpy( bIofficer, " ");
                    strcpy( bnname, " ");
                    strcpy( iquota_B," ");
                }else{
                    continue;
                }
             }else{

             	 strcpy(bIofficer,trim(bIofficer));
             	 /* 101.11,�]���Z�Ĩ��A  "+0.2(2.4�Ӥ�)" �אּ "-0.5(6�Ӥ�)"  */
                 /* 980109, ���e�@�~B���� => check �M�׬O�_�w���
                            �e�@�~�LB�檺,�����ˬd */
                 printf(" ------- dissue_B = [%s]\n " , dissue_B);
                 printf(" ------- dply_begin_B = [%s]\n " , cm_cdate_str_100(lng_dply_begin_B));
                 if (dissue_B[0]!='\0'){
                 	 strcpy(dissue_B,trim(dissue_B));
                     lng_dissue_B = cm_build_date_ym(dissue_B,1);
                     qnext_year_B    = (int)((lng_dply_begin_B - lng_dissue_B)/365.0 - 0.5 + 0.5);
                     printf(" ------- qnext_year_B = [%d]\n " , qnext_year_B);
                     printf(" ------- qnext_year_chk = [%d]\n " , qnext_year_chk);
                     if( qnext_year_B >= qnext_year_chk -1 )  continue;
                 }
             }
              printf(" ------- bIofficer = [%s]\n " , bIofficer);
         }
         else
         /*      (2) �w��O��A�榳�e�O�渹 */
         {

             strcpy(lastdbname,get_car_full_db(ilast_ply));
             /** 990510, ���ظU�o�ֱM��(C17)�Ĥ@�~�LB��*/
             /** 960227, �U�o�ֱM�ײĤ@�~�LB�� **/ /** 970813, �s�߶R�@�e�|�M�ײĤ@�~�LB�� **/
             /*  => �S��B��i�Hcheck, ��check �e�@�~A����O������O�_�ŦX */
             /* �s�W�ζ�������(Y62)�BDLR������(Y63) add by sylvia 104.03.10 (1040212008_C1) */
             if (ISPROJ_NO_FST_PLY_B(pro_no)&&(qyear_A2==1))  /*1020805:�s�WY45*/
             {
	               sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy  "
	                        " FROM %s:ply_relation a , %s:policy b  "
	                        "WHERE a.ipolicy = b.ipolicy  "
	                        "  AND a.fcard_class = '2'  "
	                        "  AND a.iofficer[1] in %s AND b.nequipment[%d] in %s  "
	                        "  AND a.fedr_class <> '1'  "
	                        "  AND a.iofficer not in (select unique iofficer_ori from ca_promote_officer where iprmt = '%s')  "
	                        "  AND (a.mdmg_prem + a.mlia_prem) >= %d  "
	                        "  AND b.iengine = '%s'  "
	                        "  AND a.dply_end >= %d AND a.dply_end <= %d",
	                       lastdbname, lastdbname, trim(str_iagent), iequip_flag, sequip_str,pro_no, mlimit,iengine, b_ldbgn, b_ldend );

	               printf("lin 568 stmt=[%s]\n", stmt );

	               $PREPARE PRE_a3 FROM $stmt;
	               $DECLARE cur_a3 CURSOR for PRE_a3;
	               $OPEN cur_a3;
	               $FETCH cur_a3 INTO $bIpolicy;
	               if(SQLCODE == SQLNOTFOUND)
	               {
	                    $CLOSE cur_a3;
	                    $FREE  cur_a3;
                        goto g_b_data;
	               } else{
                        printf(" ------- test11 \n ");
                        strcpy( bIpolicy, " ");
                        ldend2 = 0;
                        strcpy( iassured_B1, " ");
                        strcpy( bIofficer, " ");
                        strcpy( bnname, " ");
                        strcpy( iquota_B," ");
	                    $CLOSE cur_a3;
	                    $FREE  cur_a3;
	               }
             }else{

	              sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy, a.iofficer, a.dply_end, iassured, (year(dissue)-1911)||'/'||TO_CHAR(dissue,'%%m'),a.dply_begin,  "
	                           "(select nname from officer where iofficer = a.iofficer),a.iquota,a.ibig_office,b.iapplicant,b.napplicant  "
	                        " FROM %s:ply_relation a, %s:policy b, %s:ply_ins_type c  "
	                        "WHERE a.ipolicy = b.ipolicy AND b.ipolicy = c.ipolicy  "
	                        "  AND c.mdamage_cover > 0 AND a.fedr_class <> '1'  "
	                        "  AND b.iengine = '%s' AND a.fcard_class = '2'  "
	                        "  AND b.nequipment[%d] in %s  "
	                        "  AND a.dply_end >= %d AND a.dply_end <= %d  "
	                        "  AND a.iofficer in (select unique iofficer_ori from ca_promote_officer where iprmt = '%s')",
	                        lastdbname, lastdbname, lastdbname,
	                        iengine, iequip_flag, sequip_str, b_ldbgn, b_ldend, pro_no );
	              printf(" ==407=> stmt=[%s]\n", stmt );

	              $PREPARE cur_b1 FROM $stmt;
	              $DECLARE cur_b2 CURSOR for cur_b1;
	              $OPEN cur_b2;
	              $FETCH cur_b2 INTO $bIpolicy, $bIofficer, $ldend2, $iassured_B1,$dissue_B,$lng_dply_begin_B,$bnname,$iquota_B,
	                                 $ibig_office,$iapplicant_B,$napplicant_B;
	              if(SQLCODE == SQLNOTFOUND)
	              {
	              	 /* �L�e�@�~B���� */
	              	 /* =>  ���קK����X��A���s�j�M�Ҧ���Ʈw�]�Q�� g_b_data �^ */

	                  $CLOSE cur_b2;
	                  $FREE  cur_b2;
	                  goto g_b_data;
	              }else{
	              	 strcpy(bIofficer,trim(bIofficer));
	              	  /* 101.11,�]���Z�Ĩ��A  "+0.2(2.4�Ӥ�)" �אּ "-0.5(6�Ӥ�)"  */
	                  /* 980109, ���e�@�~B���� => check �M�׬O�_�w��� */
	                  printf(" ------- bIofficer = [%s]\n " , bIofficer);
	                  printf(" ------- dissue_B = [%s]\n " , dissue_B);
	                  printf(" ------- dply_begin_B = [%s]\n " , cm_cdate_str_100(lng_dply_begin_B));
	                 if (dissue_B[0]!='\0'){
	                 	strcpy(dissue_B,trim(dissue_B));
	                     lng_dissue_B = cm_build_date_ym(dissue_B,1);
	                     qnext_year_B    = (int)((lng_dply_begin_B - lng_dissue_B)/365.0 - 0.5 + 0.5);
	                     printf(" ------- qnext_year_B = [%d]\n " , qnext_year_B);
	                     printf(" ------- qnext_year_chk = [%d]\n " , qnext_year_chk);
	                     if( qnext_year_B >= qnext_year_chk -1 ){
		                     $CLOSE cur_b2;
		                     $FREE  cur_b2;
	                         continue;
	                     }
	                 }
		             $CLOSE cur_b2;
		             $FREE  cur_b2;
	              }
             }

         }

 printf("---before �_�O \n ");
         /**  3. �ˬd�O�_���_�O  **/
         /** ��e�@�~�O��O��    **/
         /** �O�����त�_�A��A���A��P�_�_�O�A�LA��h��B��P�_ **/
         if( strlen(trim(ilast_ply)) > 0 )
         {
             sprintf_s(stmt, sizeof stmt, "SELECT dply_end FROM %s:ply_relation  "
                            "WHERE ipolicy = '%s'",lastdbname , ilast_ply );
             $PREPARE cur_endA1 FROM $stmt;
             $EXECUTE cur_endA1 INTO $ldendA1;
             if(SQLCODE == SQLNOTFOUND)
                 ldendA1 = 0;

             if( ldbgn > ldendA1 )
                continue;
         }
         else
         {
         	 /* �LA��h��B��P�_, ���Ĥ@�~�LB��̰��~ */
         	 /* �s�W�ζ�������(Y62)�BDLR������(Y63) add by sylvia 104.03.10 (1040212008_C1) */
             if (ISPROJ_NO_FST_PLY_B(pro_no)&&(qyear_A2==1))  /*1020805:�s�WY45*/
             {
             	  /* �Ĥ@�~�LB��̰��~�]ldend2=0�^ */
             	  printf(" ---�ˬd�O�_���_�O,�Ĥ@�~�LB��̰��~\n " );
         	 }else{
                if( ldbgn > ldend2 )
                  continue;
             }
         }

         printf("iassured_A2[%s] iassured_B1[%s]\n", iassured_A2, iassured_B1 );
         /** ���i�L��AA�BB��Q�O�I�H�ݬۦP **/

         /*
         if( strlen(trim(iassured_B1)) != 0 && strcmp(iassured_A2, iassured_B1) != 0 )
             continue;
         */
printf("---before �L�� \n ");
         if( strlen(trim(iassured_B1)) > 0){

         	/* �U�o�ֱM�ײĤ@�~�LB��,�B�L����i�X�� */
         	    /* �s�W�֪@(c18)�M�� add by sylvia 103.04.23 */

         	/* �]�� 2014/08/01-2014/08/31 ����X�ѵs�I�s��,�L��礣���\ add by sylvia (1030724002_C3)  */
         	/* if ((strcmp( pro_no, "C17") == 0)||(strcmp( pro_no, "C15") == 0) ||
         	    (strcmp( pro_no, "C18") == 0)){

            }else{ */
            	if (strcmp(iassured_A2, iassured_B1) != 0){
            		continue;
            	}
         	/* } */
         }

         /** ���Ĥ@�~ B��A�� B���O�O�A�����v�� 0 **/
         /** �Ĥ@�~ B ��O�渹 bIpolicy ,
             �Ĥ@�~ A ��ͮĤ� ldbgn
             �ĤG�~ �O�O mins_prem11  **/
         printf("---before car331_iins11_prem \n ");

         /* ���κ�e�@�~B��O�O */
         mins_prem11 = 0;
         /*
         if( strlen( trim(bIpolicy)) != 0)
         {
         	 mins_prem11 = 0;

             rc = car331_iins11_prem( bIpolicy , ldbgn );
             if( rc != M_CM_OK)
             {
                 return rc;
             }
         }
         else{ */
         	  /** 970813, �s�߶R�@�e�|�M�ײĤ@�~�LB�� **/
         	  /** 960227, �U�o�ֱM�ײĤ@�~�LB��,�βĤ@�~A���O�O **/
         	  /** 980115, �U�o�ֱM�ײĤ@�~�LB��,�����O�O �]�� 0   **/
         	  /*
         	 printf("qyear_A2[%d] \n", qyear_A2 );
         	 printf("ilast_ply[%s]\n", ilast_ply );
         	 if (((strcmp( pro_no, "C15") == 0)||(strcmp( pro_no, "P01") == 0))&&(qyear_A2==1)){
	         *   rc = car331_iins11_prem( ilast_ply , ldbgn );
	              if( rc != M_CM_OK)
	              {
	                 return rc;
	              }
         	 }else{         *
         		  mins_prem11 = 0;
             }
         }
         printf("qyeamins_prem11[%ld] \n", mins_prem11 ); */


         printf("nchi_full[%s]\n", nchi_full );
         printf("iquota_B[%s]\n", iquota_B );
         printf("iquota_A[%s]\n", iquota_A );

         /* N*�g��PA��g��~�Z���ۦP modify by sylvia 103.09.16(1030630002_C1) */
         if (bIofficer[0] == 'N')
         {
            if (strcmp(iquota_B,iquota_A) == 0){
               strcpy( f_iquota_diff," ");
            }else{
            	strcpy( f_iquota_diff,"1");
            }
         }
         else
         {
            if (strncmp(iquota_B,iquota_A,4) == 0){
               strcpy( f_iquota_diff," ");
            }else{
            	strcpy( f_iquota_diff,"1");
            }
         }
         printf(" ------- f_iquota_diff = [%s]\n " , f_iquota_diff);

         /******               ��XB����O�Ϊ��g�� =>��car330�X�檽����            *****/

         /* �~�Z���[1,4]���P�βĤ@�~�LB��=> �յۧ�XB����O�n�Ϊ��g�� =>��car330�X��� */
         printf("ipolicyA[%s]\n " , ipolicy);

      	if( strncmp(f_iquota_diff ,"1",1 )==0)
      	{
      	 	 printf("  -------�~�Z���[1,4]���P�βĤ@�~�LB��\n " );
      		 refind_officer_B:
      		 strncpy(iquota14,iquota_A,4);
      		 strcpy(iofficer_exec, " ");

      	     /* 990119,�e�@B��B��OA�椧�~�Z��줣�P�Ϋe�@�LB��
      	      => ���s�H��OA�椧�g��N���ܸg��H�ɨ��o�̷s�~�Z���A
      	         �A�H�̷s�~�Z���+�M�ץN�X��B�椧�g��N�� */

      	    printf("Trace -- iquota14 old = [%s] \n",  iquota14);
             $SELECT iquota[1,4], iquota INTO $iquota14,$iquota_A FROM officer 
               WHERE iofficer = $iofficer;
             printf("Trace -- iquota14 new = [%s] \n",  iquota14);

      		 /** ��異�ѡA��iquota_A...������� officer ���� **/
      		 /* �s�WN*�M�׸g�쪺�P�_����  modify by sylvia 103.09.16(1030630002_C1) */
      		 if (strcmp(iofficer_1, "N") == 0)
      		 {
      		   sprintf_s(stmt, sizeof stmt, "SELECT iofficer FROM officer  "
      	                    "WHERE iquota = '%s' AND iofficer[1] = '%s'  "
      	                      "AND iofficer[%d,%d] = '%s'  "
      	                      "AND length(iofficer) = %d   "
      	                      "AND sbus_source = '%s'",
      	     iquota_A, iofficer_1, ioff_ck_bgn, ioff_ck_end, trim(ioff_chk), iofficer_len, iprmt );
      		 }
      		 else
      		 {
      	     sprintf_s(stmt, sizeof stmt, "SELECT iofficer FROM officer  "
      	                    "WHERE iquota[1,4] = '%s' AND iofficer[1] = '%s'  "
      	                      "AND iofficer[%d,%d] = '%s'  "
      	                      "AND length(iofficer) = %d   "
      	                      "AND sbus_source = '%s'",
      	     iquota14, iofficer_1, ioff_ck_bgn, ioff_ck_end, trim(ioff_chk), iofficer_len, iprmt );
      	    }
      	     printf("stmt=[%s]\n", stmt);

      	     $PREPARE cur_getoff FROM $stmt;
      	     $DECLARE cur_getoff1 CURSOR for cur_getoff;
      	     $OPEN cur_getoff1;
      	     $FETCH cur_getoff1 INTO $iofficer_exec;

      	     printf("--SQLCODE =[%d]\n",  SQLCODE );

      	     if(SQLCODE != SQLNOTFOUND){
      	        $CLOSE cur_getoff1;
      	        $FREE  cur_getoff1;
      	        printf("--iofficer_exec=[%s]\n", iofficer_exec );
      	     }else{
      	        $CLOSE cur_getoff1;
      	        $FREE  cur_getoff1;
      	     }

      	 }else{
      	 	  printf("  -------�~�Z���[1,4]�ۦP \n " );
      	 	  /* �~�Z���[1,4]�ۦP                                 */
      	 	  /* =>�~���ˮ֥h�~B��g��O�_���ŦX�M�׳]�w���ˮֱ��� */

      	 	 strcpy(ioff_chk,trim(ioff_chk));
      	 	 strcpy(ioff_chk_B,trim(ioff_chk_B));
	          strncpy(ioff_chk_B, bIofficer + ioff_ck_bgn -1 , ioff_ck_len);

	          printf("bIofficer=[%s],iofficer_len=[%d]\n",bIofficer,iofficer_len);
	          printf("ioff_chk_B=[%s],ioff_chk = [%s]\n " , ioff_chk_B, ioff_chk);
	          printf("bIofficer[0]=[%c],iofficer_1[0] = [%c]\n " , bIofficer[0], ioff_chk[0]);
	          if( (strlen(bIofficer) == iofficer_len) && ( strcmp(ioff_chk_B, ioff_chk)==0) && (bIofficer[0]==iofficer_1[0]) )
	          {
	      	      /** ��令�\�A�i�έ�g��X�� **/
	      	      strcpy( iofficer_exec, bIofficer);
	          }
	          else if( (fanother[0] == 'Y') && (strlen(iofficer_exec) == lofficera) &&
	                   ( strcmp(ioff_chk_B, ioff_chka)==0))
	          {
	              /** ��令�\�A�i�έ�g��X�� **/
	      	      strcpy( iofficer_exec, bIofficer);
	      	  }else{
	      	  	  /** ��異�ѡA���s��i�ΥX��g�� **/
	      	  	  printf("  -------��異�ѡA���s��i�ΥX��g�� \n " );
	      	  	  goto refind_officer_B;
	      	  }
      	 }
         printf("iofficer_exec=[%s]\n", iofficer_exec );



         /* 103.02
			�M      ��			�Y�e�@�~A�欰�s����A��ƺI�����P�ɺ����H�U����
			------------------	-----------------------------------------------------------
			Y48			W�g��	�ηs2-5�~�ѵs�I�M��	�e�@�~A�椧ñ��� ��102/12/1
			Y53					�Ǵ����u�R�@�e�|�v�M��II	�e�@�~A�椧ñ��� ��102/11/1
			Y57			H�g��	�ηs2-5�~�ѵs�I�M��	���A�椧ñ��� ��102/12/1
			Y58					�Ǵ����u�R�@�e�|�v�M��II	�e�@�~A�椧ñ��� ��102/11/1
            Y45			W�g��   �ζ�2-6�~�ѵs�I�M�� 	�e�@�~A�椧ñ��� <103/11/1   add by sylvia 104.03.12(1040212008_C1)
			Y63			N�g��	DLR�u�����١v �e�@�~A�椧ñ��� ��103/11/1   add by sylvia 104.03.12(1040212008_C1)
         */

         strcpy(pre_aIofficer," "); /*  �e�@�~A��g��N�� */
         tmp_1101_chk = 0; tmp_1201_chk = 0; tmp_Y63_chk = 0;
         pre_count11 = 0;
         /*  980225, get �e�@�~A��g��N�� */
         if( strlen(trim(ilast_ply)) > 0 ){
             strcpy(lastdbname,get_car_full_db(ilast_ply));
             sprintf_s(stmt, sizeof stmt,"SELECT a.iofficer,(a.dpolicy-'11/01/2013'::date),(a.dpolicy-'12/01/2013'::date),  "
                           "nvl((select count(iins_type) from %s:ply_ins_type  "
                                "where ipolicy = a.ipolicy and iins_type = '11'  "
                                  "and mdamage_cover > 0),0),(a.dpolicy-'11/01/2014'::date)  "
                           " FROM %s:ply_relation a , %s:policy b  "
                           "WHERE a.ipolicy = b.ipolicy  "
                           "  AND a.ipolicy = '%s'" ,
                          lastdbname, lastdbname, lastdbname, ilast_ply );

             printf("lin 568 stmt=[%s]\n", stmt );
             $PREPARE PRE_a31 FROM $stmt;
             $DECLARE cur_a31 CURSOR for PRE_a31;
             $OPEN cur_a31;
             $FETCH cur_a31 INTO $pre_aIofficer,$tmp_1101_chk, $tmp_1201_chk, $pre_count11, $tmp_Y63_chk;
             $CLOSE cur_a31;
             $FREE  cur_a31;
             printf("-- 1228 ilast_ply=[%s] pre_count11=[%d]\n",ilast_ply, pre_count11);
         }else{
	         for( k=0; k< count_db; k++)
	         {
	               sprintf_s(stmt, sizeof stmt,"SELECT a.iofficer,(a.dpolicy-'11/01/2013'::date),(a.dpolicy-'12/01/2013'::date),  "
	                               "nvl((select count(iins_type) from %s:ply_ins_type  "
                                        "where ipolicy = a.ipolicy and iins_type = '11'  "
                                        "  and mdamage_cover > 0),0),(a.dpolicy-'11/01/2014'::date)  "
	                        " FROM %s:ply_relation a , %s:policy b  "
	                        "WHERE a.ipolicy = b.ipolicy  "
	                        "  AND a.fcard_class = '2'  "
	                        "  AND a.iofficer[1] in %s  "
	                        "  AND a.iofficer not in (select unique iofficer_ori from ca_promote_officer where iprmt = '%s')  "
	                        "  AND b.iengine = '%s'  "
	                        "  AND a.dply_end >= %d AND a.dply_end <= %d",
	                       list[k].dbname, list[k].dbname, list[k].dbname, trim(str_iagent),pro_no, iengine,b_ldbgn, b_ldend );

	               printf(" stmt=[%s]\n", stmt );

	               $PREPARE PRE_a41 FROM $stmt;
	               $DECLARE cur_a41 CURSOR for PRE_a41;
	               $OPEN cur_a41;
	               $FETCH cur_a41 INTO $pre_aIofficer,$tmp_1101_chk, $tmp_1201_chk, $pre_count11, $tmp_Y63_chk;
	               if(SQLCODE != SQLNOTFOUND)
	               {
	                  $CLOSE cur_a41;
	                  $FREE  cur_a41;
	                  break;
	               }
	               printf("-- 1257 ilast_ply=[%s] pre_count11=[%d]\n",ilast_ply, pre_count11);
	          }
         }
         printf("pre_aIofficer1=[%s]\n", pre_aIofficer );
         strcpy(pre_aNofficer," ");
         if( strlen(trim(pre_aIofficer)) > 0 ){
         	$Select nname Into $pre_aNofficer From Officer Where iofficer = $pre_aIofficer;
         	strcpy(pre_aNofficer,trim(pre_aNofficer));
         }

         printf("-- trace pro_no[%s]\n ",pro_no);
         printf("-- trace tmp_1101_chk[%ld]\n ",tmp_1101_chk);
         printf("-- trace tmp_1201_chk[%ld]\n ",tmp_1201_chk);

         if(qyear_A2==1){ /* �e�@�~A�欰�s���� */

         	  if (strcmp( pro_no, "Y48") == 0 ){        /* �ηs2-5�~�ѵs�I�M�� (W*�g��) */
         	  	  if (tmp_1201_chk >= 0) continue;
         	  }else if (strcmp( pro_no, "Y53") == 0 ){  /* �Ǵ����u�R�@�e�|�v�M��II (W*�g��) */
         	  	  if (tmp_1101_chk >= 0) continue;
         	  }else if (strcmp( pro_no, "Y45") == 0 ){  /* �ζ�2-6�~�ѵs�I�M�� add by sylvia 104.03.12 (1040212008_C1) */
         	  	  if (tmp_Y63_chk >= 0) continue;
         	  }

         	  if (strcmp( pro_no, "Y57") == 0 ){        /* �ηs2-5�~�ѵs�I�M�� (H*�g��) */
         	  	  if (tmp_1201_chk < 0) continue;
         	  }else if (strcmp( pro_no, "Y58") == 0 ){  /* �Ǵ����u�R�@�e�|�v�M��II (H*�g��) */
         	  	  if (tmp_1101_chk < 0) continue;
         	  }else if (strcmp( pro_no, "Y63") == 0 ){  /* DLR������ add by sylvia 104.03.12  (1040212008_C1) */
         	  	  if (tmp_Y63_chk < 0) continue;
         	  }
         }


         if (equip_cmp(nequipment_A,"90") == True){
         	 strcpy(nequipment_90, "1" );
         }else{
         	 strcpy(nequipment_90, "0" );
         }

         /* 101.08.24, car331���ݭn�n�O�H��T
            980520, get �n�O�HID�B�n�O�H�W��
            980520~990520�X�椧B�� �B�Ĥ@�~�LB��� , �n�O�HID���L��� ,
         if (strlen(trim(iapplicant_B))==0){

			 printf("Trace -- bIofficer = [%s] \n",  bIofficer);
			 printf("Trace -- iofficer_exec = [%s] \n",  iofficer_exec);

	         $SELECT first 1 iapplicant,napplicant
	            INTO $iapplicant_B,$napplicant_B
	            FROM iapp_data
	           WHERE iofficer = $iofficer_exec;
	         printf("Trace -- SQLNOTFOUND = [%d] \n",  SQLNOTFOUND);

	         if(SQLCODE == SQLNOTFOUND){
	         	* 981231,�A�έ�B��g���@�� *
	            $SELECT first 1 iapplicant,napplicant
	               INTO $iapplicant_B,$napplicant_B
	               FROM iapp_data
	              WHERE iofficer = $bIofficer;
	              if(SQLCODE == SQLNOTFOUND){
    	         	  strcpy(iapplicant_B," ");
	             	  strcpy(napplicant_B," ");
	              }
	         }
             strcpy(iapplicant_B,trim(iapplicant_B));
             strcpy(napplicant_B,trim(napplicant_B));

	         printf("1Trace -- iapplicant_B = [%s] \n", iapplicant_B);
	         printf("2Trace -- napplicant_B = [%s] \n", napplicant_B);

		 }
	         printf("3Trace -- iapplicant_B = [%s] \n", iapplicant_B);
	         printf("4Trace -- napplicant_B = [%s] \n", napplicant_B);
         */
         /* 102.03 ���o�����渹 */
         strcpy(iengine, trim(iengine));   strcpy(itag, trim(itag));
         if (strlen(iengine) > 0) {
         	 sprintf_s(inumber, sizeof inumber," AND a.iengine = b.iengine AND a.iengine = '%s' ", iengine);
         }else if (strlen(itag) > 0) {
         	 sprintf_s(inumber, sizeof inumber," AND a.itag = b.itag AND a.itag = '%s' "   , itag);
         }
         /* 103.02 �����O�J�p���ͤ�������(���O�զX)*/
         strcpy(iestimate," "); dbl_estimate_prem = 0.0;
         strcpy(cm_iofficer," ");

         sprintf_s(stmt, sizeof stmt,"SELECT first 1 b.ipre_rcv,b.mprem,b.iofficer   "
                       " FROM policy_302 a, cm_pre_receive b  "
	                   "WHERE a.iestimate_ori = b.ipre_rcv   "
	                   "  AND a.dply_begin = b.deffect    "
	                   "  AND b.iins_cat = 'C'  AND b.iins_kind = '2'  AND b.ipre_end = ' '  "
	                   "  AND a.dply_begin = %d %s %s  "
	                   "  AND b.isys = '4' order by b.ipre_rcv ", ldbgn, inumber, stroff);

	     printf("preIestimate stmt=[%s]\n", stmt);
	     $PREPARE preIestimate FROM $stmt;
	     $EXECUTE preIestimate Into  $iestimate, $dbl_estimate_prem,$cm_iofficer;

         printf("trace iestimate[%s]\n ",iestimate);

        /* �]��W,H�g����N�g��,�i��|�P�J�p�ɪ��g��N�����P,�H�J�p�ɪ��g��N������ */
        strcpy(cm_iofficer, trim(cm_iofficer));
        strcpy(iofficer_exec, trim(iofficer_exec));
        if (strcmp(iofficer_exec,cm_iofficer) != 0)
            strcpy(iofficer_exec, trim(cm_iofficer));
        /*----------------------------------------------------------------------- */

        /* �s�W�ˮ�:�HB������渹���ǡA�ˮֶ��P��O�J�p�ɤ��������B�Q�O�I�HID�B�O���۲�
           add by sylvia 103.08.01 (1030724002_C3) -----------------------------------*/
         icnt302 = 0;

         $select count(ipolicy) into $icnt302
            from policy_302
           where iestimate_ori = $iestimate
             and iengine = $iengine
             and ilicense = $iassured_A2
             and dply_begin = $ldbgn;

         printf("1365 -- iestimate=[%s]iengine=[%s]iassured_A2=[%s]ldbgn=[%ld]icnt302=[%d]\n",
                 iestimate,iengine,iassured_A2,ldbgn,icnt302);
         if  (icnt302 == 0) continue;
         /* --------------------------------------------------------------------------- */
         strcpy(itag,trim(itag));
         rgu_put_body_string(2,nchi_full,LEFT);
         rgu_put_body_string(2,iofficer, LEFT);
         rgu_put_body_string(2,nname,    LEFT);
         rgu_put_body_string(2,ipolicy,  LEFT);
         rgu_put_body_string(2,icard,    LEFT);
         rgu_put_body_string(2,Adpolicy, LEFT);
         rgu_put_body_string(2,Adbegin,  LEFT);
         rgu_put_body_string(2,Adend,    LEFT);
         rgu_put_body_string(2,dissue_A,    LEFT);
         rgu_put_body_string(2,ipro_year_A,    LEFT);
         rgu_put_body_string(2,iengine,  LEFT);
         rgu_put_body_string(2,itag,     LEFT);
         rgu_put_body_string(2,nassured, LEFT);

         rgu_put_body_string(2,iassured_cntry, LEFT);   /* �Q�O�I�H��O���O(RBA) add by sylvia 105.03.03 (1050105008_C4) */
         rgu_put_body_string(2,iapplicant_cntry, LEFT); /* �n�O�H��O���O(RBA) add by sylvia 105.03.03 (1050105008_C4) */
         
         rgu_put_body_string(2,foccup, LEFT);   /* �Q�O�I�H��¾�~�O(RBA) add by sylvia 106.08.10 (1060606002_C5) */
         rgu_put_body_string(2,noccup, LEFT); /* �Q�O�I�H��¾�~�N��(RBA) add by sylvia 106.08.10 (1060606002_C5) */
         rgu_put_body_string(2,applicant_foccup, LEFT);   /* �n�O�I�H��¾�~�O(RBA) add by sylvia 106.08.10 (1060606002_C5) */
         rgu_put_body_string(2,applicant_noccup, LEFT); /* �n�O�I�H��¾�~�O(RBA) add by sylvia 106.08.10 (1060606002_C5) */

         rgu_put_body_string(2,iofficer, LEFT);
         rgu_put_body_string(2,nname,    LEFT);

         rgu_put_body_string(2,bIpolicy, LEFT);
         rgu_put_body_string(2,bIofficer,LEFT);
         rgu_put_body_string(2,bnname,   LEFT);
         rgu_put_body_string(2,iquota_B ,LEFT);
         rgu_put_body_string(2,iquota_A ,LEFT);
         rgu_put_body_string(2,f_iquota_diff ,LEFT);
         rgu_put_body_string(2,iofficer_exec ,LEFT);
         rgu_put_body_string(2,Adbegin,  LEFT);
         rgu_put_body_string(2,Adend,    LEFT);
         /* �����v�B�e�@�~B��O�O ���O��0�A�G���������
         rgu_put_body_string(2,"0.0",    LEFT);

         printf("--mins11 --- mins_prem11[%d]\n", mins_prem11 );
         rfmtlong(mins_prem11, "---------&", tmp_buf);
         printf("--mins11 --- tmp_buf[%s]\n", tmp_buf );
         rgu_put_body_string(2,tmp_buf,LEFT);      */
         rgu_put_body_string(2,pre_aIofficer,LEFT);
         rgu_put_body_string(2,pre_aNofficer,LEFT);

         rgu_put_body_string(2,iestimate, LEFT);
         estimate_prem = (long)dbl_estimate_prem;
         rfmtlong(estimate_prem, "---------&", tmp_buf);
         rgu_put_body_string(2,tmp_buf,LEFT);
         rgu_put_body_string(2,nequipment_90, LEFT);

         /* A��O��b08/01/2014-08/31/2014�~�n --------------------------------------- */
         strcpy(scount11," ");
         printf("--- 1394 bIpolicy=[%s]f201408=[%d]pre_count11=[%d]\n ",bIpolicy,f201408,pre_count11);
         if (f201408 > 0)
         {
            if (strlen(trim(bIpolicy)) > 0)
                  pre_count11 = 1; /* �e�榳B��, ���ܫe�@�~�צ�11�I�� */

            strcpy(scount11, itoa(pre_count11));
         }
         printf("--- 1402 f201408=[%d] pre_count11=[%d] scount11=[%s]\n ",
                 f201408, pre_count11, scount11);

         rgu_put_body_string(2,scount11, LEFT); /* �e�@�~11�I�حӼ� */
         /* --------------------------------------------------------------- */
         /* �s�W�T��:���~A��P�h�~A�檺�g��N�����P��, ����ܰT��  add by sylvia 103.10.20 */
         strcpy(iofficer, trim(iofficer));
         strcpy(pre_aIofficer, trim(pre_aIofficer));
         strcpy(sTmpMsg, " ");
         printf("1481==>iofficer=[%s]pre_aIofficer=[%s]\n",iofficer,pre_aIofficer);
         if ((strlen(pre_aIofficer) > 0) && (strcmp(iofficer, pre_aIofficer) != 0))
            strcpy(sTmpMsg,"���~A��g�즳����");
         rgu_put_body_string(2,sTmpMsg, LEFT); /* ��L�`�N�ƶ� */
         rgu_put_body_string(2,feply, LEFT);   /* �q�l�O����O */

         rgu_put_body(2);

         max_cnt += 1;

      }
      $CLOSE car331_1a;
      $FREE  car331_1a;
      printf("max_cnt=[%d] CLOSE car331_1a \n", max_cnt);
  }
  /*$DROP TABLE iapp_data;  */
  printf("before return [%d]\n", l_m_cm_ok);

  return l_m_cm_ok;

  printf("after M_CM_OK\n");

errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(FAIL);
}

long  car331_body2()
{
   /*1071206003_SC1_car331���O2�uA��w��O�A�����ŦX����v�վ�A��ܡu2. A��w��O�A�����ŦX����v�Ƶ{����*/
   int  chi, ifoundA, searchB, no_found_B1;
   $char  stmt[2048], lastdbname[20], nextdbname[20], stroff[300];
   $char  dply_bgn_A1[13], dply_end_A1[13], last_ply[21];
   $char  dply_bgn_A2[13], dply_end_A2[13], iofficer_A2[10], ipolicy_A2[21], nequip_A2[2];
   $char  dply_bgn_B1[13], dply_end_B1[13], ipolicy_B1[21], dpolciy_B2[13],  dpolicy_A2[13];
   $char  bIpolicy[21], inext_ply_B1[21], itag_B1[CA_TAG_NUM], iengine_B1[CA_ENGINE_NUM], itag_A2[CA_TAG_NUM];
   $long  ldbgn1, ldend1, ldbgn2, ldend2;
   $long  ldbegin_A2, ldend_A2, mprem_A2;
   $int   iequip_flag, ply_ins_cnt, qnext_year, qyear_A2;
   $char  sequip_str[201];
   $char  iequip_tmp[4], iofficer_B1[11], flag1[2], flag2[2], flag3[2], flag4[2];
   $char  nequipment[31], temp_data[3];
   $char  ibig_comp_A[2]= " ";
   $int   tmp_cnt=0;
   $char  iengine_A2[CA_ENGINE_NUM] = " ";
   $long  tmp_1101_chk,tmp_1201_chk, tmp_Y63_chk;
   $char  dpolicy_A2_100[10],dply_bgn_A2_100[10];
   $int   dpolicy_A2_int,dply_bgn_A2_int;

   /* �]�� 2014/08/01-2014/08/31 ����X�ѵs�I�s�� add by sylvia (1030724002_C3)  */
  $int  f201408,pre_count11,icnt302;  /* 0:�_�O�餣�b2014/08/01  1:�_�O��b2014/08/01 */
  $char  scount11[2];
  /* --------------------------------------------- */

   /** ���i temp table **/
   $CREATE TEMP TABLE CAR331_BODY2
   (
       nchi_full     char(30),
       iofficer      char(11),
       nname         char(20),
       last_ply      char(20),
       dply_bgn_a1   char(13),
       dply_end_a1   char(13),
       iengine       char(25),
       itag          char(12),
       nassured      char(61),
       iassured_a2   char(11),
       ipolicy_a2    char(20),
       dpolicy_a2    char(13),
       dply_bgn_a2   char(13),
       dply_end_a2   char(13),
       iofficer_a2   char(11),
       mprem_a2      integer,
       nequip_a2     char(2),
       flag1         char(2),
       flag2         char(2),
       flag3         char(2),
       flag4	     char(2),
       ipolicy_b1    char(20),
       dply_bgn_b1   char(13),
       dply_end_b1   char(13),
       iassured_b1   char(11),
       iengine_b1    char(25),
       iofficer_b1   char(10),
       dissue        char(10),
       ipro_year     char(4),
       ibig_comp_a2  char(1) default ' '
   )
   WITH NO LOG;

   $CREATE INDEX CAR331_BODY2_ix1 ON CAR331_BODY2( last_ply );
   $CREATE INDEX CAR331_BODY2_ix2 ON CAR331_BODY2( ipolicy_b1 );


   $CREATE TEMP TABLE REC_A
   (
      ipolicy   char(20)
   )
   WITH NO LOG;

   $CREATE INDEX REC_A1 ON REC_A( ipolicy );

   $CREATE TEMP TABLE tmp_dup_record
   (
      ipolicy   char(20),
      iengine   char(25)
   )
   WITH NO LOG;

   $CREATE INDEX idx_dup_record ON tmp_dup_record( ipolicy );


   printf("in car331_body2  A��w��O�����ŦX����\n");
   strcpy(prt_title,"A��w��O�A�����ŦX����");
   strcpy(prt_type,"�O������");

   strcpy(dply_bgn, dbegin1);
   strcpy(dply_end, dend1  );

   ifoundA=0;
   rgu_put_body_string(1,prt_title,1);
   rgu_put_body_string(1,prt_type,1);
   rgu_put_body_string(1,dply_bgn,1);
   rgu_put_body_string(1,dply_end,1);
   rgu_put_body_string(1, cm_get_sysd(),1);
   rgu_put_body(1);

   max_cnt += 7;

   for( i=0; i< count_db; i++)
   {
      /** Part 1 �ѲĤ@�~ A ���ĤG�~ A �� **/
      /** 1. �Q�βĤ@�~A����� => ��O�渹(inext_ply) => ��XA��w��O��� **/

      tmp_1101_chk = 0; tmp_1201_chk = 0; tmp_Y63_chk = 0;
      iequip_flag = (iremark - 1) % 30 + 1;
      strcpy(iequip_tmp,rtrim(itoa(iremark)));
      strcpy(sequip_str,equip_instr(iequip_tmp));
      sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy, a.iofficer , (select nname from officer  "
                          "where iofficer = a.iofficer), dply_begin, dply_end,  "
                          "b.nassured, a.inext_ply, b.iengine, b.itag,  "
                          "(a.dpolicy-'11/01/2013'::date),(a.dpolicy-'12/01/2013'::date),  "
                          "(a.dpolicy-'11/01/2014'::date)  "
                    " FROM %s:ply_relation a , %s:policy b  "
                    "WHERE a.ipolicy = b.ipolicy AND a.fcard_class = '2'  "
                    "  AND ( a.inext_ply != ' ' AND a.inext_ply is not null )  "
                    "  AND a.dply_end >= '%s' AND a.dply_end <= '%s'  "
                    "  AND a.iofficer[1] in %s AND b.nequipment[%d] in %s  "
                    "  AND a.fedr_class <> '1' ",
                   list[i].dbname, list[i].dbname, dply_bgn, dply_end, trim(str_iagent),iequip_flag,sequip_str);

      printf("--> line 515 stmt[%s]\n", stmt);
      $PREPARE car331_2 FROM $stmt;
      $DECLARE car331_2a CURSOR for car331_2;
      $OPEN car331_2a;
      while(1)
      {
         $FETCH car331_2a INTO $ipolicy, $iofficer, $nname, $dply_bgn1, $dply_end1,
                               $nassured, $inext_ply, $iengine, $itag,$tmp_1101_chk, $tmp_1201_chk, $tmp_Y63_chk;
         if(SQLCODE == SQLNOTFOUND)
         {
            break;
         }


         printf("inext_ply[%s]\n", inext_ply );
         /** 2.�Ϋ�O�渹��X��O��A��O�_���ŦX����
               2.1 ���N�I�O�O >= mlimit
               2.2 �g��N���Ĥ@�X�� A  (<== ���S�� ,�����z��)
               2.3 �ݦ����O
               2.4 �����_�O 
               2.5 A�檺ñ��� - A��O�I�_�� < 30�� (1080103010_SC1) **/
         getAnotherPly:

         strcpy(nextdbname,get_car_full_db(inext_ply));
         printf(" ------- inext_ply = [%s]\n " , inext_ply);
         sprintf_s(stmt, sizeof stmt,"SELECT a.dpolicy, a.dply_begin, a.dply_end, a.iofficer,  "
                      "(a.mdmg_prem + a.mlia_prem), b.nequipment, b.iassured,  "
                      "(select nbranch from sa_branch_type where ibranch = a.iquota),  "
                      "a.ipolicy[1,2], b.itag, a.qnext_year, (year(dissue)-1911)||'/'||TO_CHAR(dissue,'%%m'), a.ipro_year,nvl(a.ibig_comp,' '),b.iengine   "
                      "  FROM %s:ply_relation a, %s:policy b  "
                      " WHERE a.ipolicy = b.ipolicy AND a.ipolicy = '%s'  "
                      "   AND a.fedr_class <> '1'", nextdbname,
                      nextdbname, inext_ply );

         $PREPARE smt_chk1 FROM $stmt;
         $EXECUTE smt_chk1 INTO $dpolicy_A2, $dply_bgn_A2, $dply_end_A2, $iofficer_A2, $mprem_A2,
                                $nequipment ,  $iassured_A2, $nchi_full, $temp_data, $itag_A2, $qnext_year,
                                $dissue_A, $ipro_year_A, $ibig_comp_A,$iengine_A2;
         if(SQLCODE == SQLNOTFOUND) continue;

         strcpy(iequip_tmp,rtrim(itoa(iremark)));
         strcpy(dissue_A, trim(dissue_A));
         if (equip_cmp(nequipment,iequip_tmp) == TRUE)
         {
            strcpy(nequip_A2,"1"); /* ��O��A�榳�M�׵��O*/
         }
         else
         {
            strcpy(nequip_A2,"0"); /* ��O��A��L�M�׵��O*/
         }

         /** A��ݩӫO�D�I **/
         sprintf_s(stmt, sizeof stmt,"SELECT count(*) FROM %s:ply_ins_type  "
                       "WHERE ipolicy = '%s' AND mdamage_cover > 0  "
                       "  AND iins_type in ('01','05','08','09','85','98','105','11','31','32')",
                      nextdbname, inext_ply );
         $PREPARE g_ply_ins1 FROM $stmt;
         $EXECUTE g_ply_ins1 INTO $ply_ins_cnt;

         /** �O���ĤG�~A����Ǥw�g�B�z�L **/
         $INSERT INTO REC_A VALUES ($inext_ply );

         rstrdate( dply_end1, &ldend1 );
         rstrdate( dply_bgn_A2, &ldbgn2 );
         rstrdate( dply_bgn1, &ldbgn1 );

         printf("mprem_A2 = [%d]\n", mprem_A2 );
         printf("iofficer_A2 = [%s]\n", iofficer_A2 );
         printf("nequip_A2 = [%s] \n", nequip_A2 );
         printf("ldend1 = [%d] ldbgn2 = [%d]\n", ldend1, ldbgn2 );

         /*** ��X�e�@�~ B ��O�渹 ***/
         /* �]����W,H�নN�����D, �אּŪ��ca_promote_officer�P�_�O�_���M�ץ� modify by sylvia 103.09.19 */
         /* if( fanother[0] == 'Y' )
         {
             sprintf_s(stroff, sizeof stroff,"AND((a.iofficer[1] = '%s' AND a.iofficer[%d,%d] = '%s'  "
                "AND length(a.iofficer) = %d) OR (a.iofficer[1] = '%s'  "
                "AND a.iofficer[%d,%d] = '%s' AND length(a.iofficer) = %d)) "
                 ,iofficer_1, ioff_ck_bgn, ioff_ck_end, ioff_chk, iofficer_len,
                 iofficera_1, ioff_chk_bgna, ioff_ch_enda, ioff_chka, lofficera );
         }
         else
         {
             sprintf_s(stroff, sizeof stroff,"AND a.iofficer[1] = '%s' AND a.iofficer[%d,%d] = '%s'  "
                "AND length(a.iofficer) = %d ",iofficer_1, ioff_ck_bgn,
                 ioff_ck_end, ioff_chk, iofficer_len );
         } */
         sprintf_s(stroff, sizeof stroff, " AND a.iofficer in (select unique iofficer_ori  "
                       "from ca_promote_officer where iprmt = '%s') ",pro_no);

         if( strcmp( pro_no ,"Y03") == 0 )
             strcat(stroff," AND a.iofficer[9,10] <> 'ES'");


		  lng_dissue_A = cm_build_date_ym(dissue_A,1);

	  	  /*960724, �H(�O��_��-�o�Ӧ~��)�p��M�׬��ĴX�~��,�Y�ĤG�~��O, qyear_A2==1 */
		  qyear_A2 = (int)floor((ldbgn2 - lng_dissue_A)/365.0 );  /* �L����˥h */

         /** ��O��A�䤣��e�@�~B��A�Y�N���h�~�D�M�סA���X�{�b���D�� **/
         printf(" ------- dissue_A = [%s]\n " , dissue_A);
         printf(" ------- ldbgn2 = [%ld]\n " , ldbgn2);
         printf(" ------- lng_dissue_A = [%ld]\n " , lng_dissue_A);
         printf(" ------- qyear_A2 = [%d]\n " , qyear_A2);


         /* 103.02
			�M      ��			�Y�e�@�~A�欰�s����A��ƺI�����P�ɺ����H�U����
			------------------	-----------------------------------------------------------
			Y48			W�g��	�ηs2-5�~�ѵs�I�M��	�e�@�~A�椧ñ��� ��102/12/1
			Y53					�Ǵ����u�R�@�e�|�v�M��II	�e�@�~A�椧ñ��� ��102/11/1
			Y57			H�g��	�ηs2-5�~�ѵs�I�M��	���A�椧ñ��� ��102/12/1
			Y58					�Ǵ����u�R�@�e�|�v�M��II	�e�@�~A�椧ñ��� ��102/11/1

         */

         if(qyear_A2==1){ /* �e�@�~A�欰�s���� */

         	  if (strcmp( pro_no, "Y48") == 0 ){        /* �ηs2-5�~�ѵs�I�M�� (W*�g��) */
         	  	  if (tmp_1201_chk >= 0) continue;
         	  }else if (strcmp( pro_no, "Y53") == 0 ){  /* �Ǵ����u�R�@�e�|�v�M��II (W*�g��) */
         	  	  if (tmp_1101_chk >= 0) continue;
         	  }else if (strcmp( pro_no, "Y45") == 0 ){   /* �ζ�2-6�~�ѵs�I�M�� add by sylvia 104.03.12(1040212008_C1) */
         	  	  if (tmp_Y63_chk >= 0) continue;
         	  }

         	  if (strcmp( pro_no, "Y57") == 0 ){        /* �ηs2-5�~�ѵs�I�M�� (H*�g��) */
         	  	  if (tmp_1201_chk < 0) continue;
         	  }else if (strcmp( pro_no, "Y58") == 0 ){  /* �Ǵ����u�R�@�e�|�v�M��II (H*�g��) */
         	  	  if (tmp_1101_chk < 0) continue;
         	  }else if (strcmp( pro_no, "Y63") == 0 ){  /* DLR�u�����١vadd by sylvia 104.03.12(1040212008_C1) */
         	  	  if (tmp_Y63_chk < 0) continue;
         	  }
         }

         no_found_B1 = 0;
/*

         �m           A1            �m              A2             �m
      |  �m           B1         |  �m              B2           | �m
    -30  �m                         �m                             �m
         �m |         B1            �m |            B2             �m |
         �m+30                      �m                             �m
*/


         for(searchB=0; searchB< count_db; searchB++)
         {
             sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy, a.dply_begin , a.dply_end, b.iassured, a.inext_ply,  "
                                " b.itag, b.iengine, a.iofficer,(year(dissue)-1911)||'/'||TO_CHAR(dissue,'%%m')  "
                          " FROM %s:ply_relation a, %s:policy b, %s:ply_ins_type c  "
                          "WHERE a.ipolicy = b.ipolicy AND b.ipolicy = c.ipolicy  "
                          "  AND c.mdamage_cover > 0  "
                          "  AND b.iengine = '%s' AND a.fcard_class = '2'  "
                          "  AND b.nequipment[%d] in %s  "
                          "  and (a.iofficer[1] = 'W' or (a.iofficer[1] = 'H' and a.iofficer[2] not in ('0','1','2'))  "
                                 "or a.iofficer in (select iofficer_ori from ca_promote_officer where iofficer_ori[1,1] = 'N'))  "
                            "AND a.dply_begin >= %d AND a.dply_begin <= %d ",
                          list[searchB].dbname, list[searchB].dbname, list[searchB].dbname,
                          iengine, iequip_flag,sequip_str, ldbgn1 -30 , ldbgn1 + 30);

             $PREPARE cur_c1 FROM $stmt;
             $DECLARE cur_c2 CURSOR for cur_c1;
             $OPEN cur_c2;
             $FETCH cur_c2 INTO $bIpolicy, $lng_dply_begin_B, $dply_end_B1, $iassured_B1, $inext_ply_B1,
                           $itag_B1, $iengine_B1, $iofficer_B1,$dissue_B;
             if(SQLCODE == 0)
             {
             	 strcpy(dply_bgn_B1,cm_edate_str(lng_dply_begin_B));
             	 no_found_B1 = 1;    /* ���B�� */
                 break;
             }
             $CLOSE cur_c2;
             $FREE  cur_c2;
         }

         /* 960306 */ /*1020805:�s�WY45*/
         if( no_found_B1 == 0 ) /* �䤣��B�� */
         {
            /* Y18 �ΫH50part2 B��b�s���I�X��,���M�n�C�X�� */
            /* �s�W�ζ�������(Y62)�BDLR������(Y63) add by sylvia 104.03.10 (1040212008_C1) */
            if( (strcmp( pro_no, "Y18") == 0) || (ISPROJ_NO_FST_PLY_B(pro_no)&&(qyear_A2==1)) )
            {
                strcpy( bIpolicy, " ");
                strcpy( dply_bgn_B1, " ");
                strcpy( dply_end_B1, " ");
                strcpy( iassured_B1, " ");
                /*strcpy( inext_ply_B1, " ");*/
                strcpy( itag_B1, " ");
                strcpy( iengine_B1, " ");
                strcpy( iofficer_B1, " ");

                /* 98.11 fix*/
            	/* �T�{B��O�_�w��O�G�Τw��O��A��O�� �� ������ �h�� */
		        for(searchB=0; searchB< count_db; searchB++)
		        {
		             sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy  "
		                          " FROM %s:ply_relation a, %s:policy b, %s:ply_ins_type c  "
		                          "WHERE a.ipolicy = b.ipolicy AND b.ipolicy = c.ipolicy  "
		                          "  AND c.mdamage_cover > 0  "
		                          "  AND b.iengine = '%s' AND a.fcard_class = '2'  "
		                          "  AND b.nequipment[%d] in %s  "
		                          "  and (a.iofficer[1] = 'W' or (a.iofficer[1] = 'H' and a.iofficer[2] not in ('0','1','2'))  "
		                                 "or a.iofficer in (select iofficer_ori from ca_promote_officer where iofficer_ori[1,1] = 'N'))  "
		                            "AND a.dply_begin >= %d AND a.dply_begin <= %d ",
		                          list[searchB].dbname, list[searchB].dbname, list[searchB].dbname,
		                          iengine_A2, iequip_flag,sequip_str, ldbgn2 -30 , ldbgn2 + 30);

		             $PREPARE pre_chk FROM $stmt;
		             $DECLARE cur_chk CURSOR for pre_chk;
		             $OPEN cur_chk;
		             $FETCH cur_chk INTO $inext_ply_B1;
		             if(SQLCODE == SQLNOTFOUND){
		             	 strcpy( inext_ply_B1, " ");
		             }else{
		              	 /* �Ĥ@�~�LB�� , ���ĤG�~B��w��O�X�� */
		             	 break;
		             }
		             $CLOSE cur_chk;
		             $FREE  cur_chk;
		        }
            }
            else{
                continue;
            }
         }else{
         	 /* 101.11,�]���Z�Ĩ��A  "+0.2(2.4�Ӥ�)" �אּ "-0.5(6�Ӥ�)"  */
             /* 980109, ���e�@�~B���� => check �M�׬O�_�w��� */
             printf(" ------- dissue_B = [%s]\n " , dissue_B);
             printf(" ------- dply_begin_B_ch = [%s]\n " , cm_cdate_str_100(lng_dply_begin_B));
             if (dissue_B[0]!='\0'){
             	 strcpy(dissue_B,trim(dissue_B));
                 lng_dissue_B = cm_build_date_ym(dissue_B,1);
                 qnext_year_B    = (int)((lng_dply_begin_B - lng_dissue_B)/365.0 - 0.5 + 0.5);
                 printf(" ------- qnext_year_B = [%d]\n " , qnext_year_B);
                 printf(" ------- qnext_year_chk = [%d]\n " , qnext_year_chk);
                 if( qnext_year_B >= qnext_year_chk -1 )  continue;
             }
         }

         printf("bIpolicy=[%s]  inext_ply_B1=[%s] qyear_A2=[%d]\n",bIpolicy, inext_ply_B1, qyear_A2);
         /* B��w��O�A�����~����� */
         if( strlen(trim(inext_ply_B1)) > 0 ){
            	continue;
         }

         /** �ĤT�~�H�WA��A���e�@�~B��w�L��O�A�h�ĤT�~A�榳���O�����ݲ��� **/
         /** �ҡG��1A�B2A�B3A  ���u�� 1B�� **/
         if( (qnext_year >= 2 ) && ( strlen(trim(bIpolicy)) == 0 ))
             continue; /* �w���ŦX��O������,�������� sylvia */

         /** �ĤT�~�H�WA��A���e�@�~B��w�L��O�A�h�ĤT�~A�榳���O�����ݲ��� **/
         /** �ҡG��1A�B2A�B3A  ���u�� 1B�� **/
         if( (qyear_A2 >= 2 ) && ( strlen(trim(bIpolicy)) == 0 ))
             continue; /* �w���ŦX��O������,�������� sylvia */

         printf("iassured_A2[%s], iassured_B1[%s]\n", iassured_A2, iassured_B1 );
         /** AB��Q�O�HID�ݬۦP **/
         /* if( (mprem_A2 >= mlimit) && (strncmp(iofficer_A2,iagent,1) == 0) && */


         printf("dpolicy_A2[%s], \n", dpolicy_A2);
         printf("mprem_A2[%d], mlimit[%d]\n", mprem_A2, mlimit );
         printf("ldend1[%ld], ldbgn2[%ld]\n", ldend1, ldbgn2 );
         printf("nequip_A2[%s], \n", nequip_A2);
         printf("ply_ins_cnt[%d], \n", ply_ins_cnt);

         /* �s�W�ˮ�:�ˮֶ��P��O�J�p�ɤ��������B�Q�O�I�HID�B�O���۲�
           add by sylvia 103.08.01 (1030724002_C3) -----------------------------------*/
         icnt302 = 0;
         $select count(*) into $icnt302
            from policy_302
           where ipolicy =$bIpolicy
             and ilicense = $iassured_A2;

         /* A�檺ñ��� - A��O�I�_�� (1080103010_SC1) */
         strcpy(dpolicy_A2_100," "); strcpy(dply_bgn_A2_100," "); 
         dpolicy_A2_int = dply_bgn_A2_int = 0;
         if ( strlen(trim(dpolicy_A2)) != 0 )
         {
         	strcpy(dpolicy_A2_100,cm_from_infdate_100(dpolicy_A2));  /* �褸����� */
         	dpolicy_A2_int = cm_ymd_cdate(dpolicy_A2_100);           /* ������Date */
         }
         strcpy(dply_bgn_A2_100,cm_from_infdate_100(dply_bgn_A2));
         dply_bgn_A2_int = cm_ymd_cdate(dply_bgn_A2_100);

         printf("1834 --icnt302=[%d]bIpolicy=[%s]iassured_A2=[%s]\n ",icnt302,bIpolicy,iassured_A2);
         if( (mprem_A2 >= mlimit) &&
             (ldend1 >= ldbgn2) && (strcmp(nequip_A2,"1") == 0) &&
             ( ply_ins_cnt > 0 ) && (dpolicy_A2_int-dply_bgn_A2_int) < 30 )
         {
             if ( strcmp(iassured_A2, iassured_B1) == 0 )
             {
               if (icnt302 > 0)
               	 continue;  /* ��ƻP��O�ɬ۲�,���L */
             }else{
		      	 /* �U�o�ֱM�׹L����i�X�� */
		      	 /* �]�� 2014/08/01-2014/08/31 ����X�ѵs�I�s��,�L��礣���\ add by sylvia (1030724002_C3)  */
		      	 /* if ((strcmp( pro_no, "C17") == 0)||(strcmp( pro_no, "C15") == 0)
		      	     ||(strcmp( pro_no, "C18") == 0))
		      	 	continue;                	 */

                 if((strcmp( pro_no, "Y18") == 0)||((strcmp( pro_no, "P01") == 0)&&(qyear_A2==1)))
                 	continue;
             }
         }

         strcpy(iengine, trim(iengine));
         strcpy(iengine_B1, trim(iengine_B1));
         strcpy(iengine_A2, trim(iengine_A2));
         /** B1�L��ơA�����ˮ֤��ݦL�X **/
         if( strlen(trim(bIpolicy)) == 0 )
         {
         	 /*960726, A��O�_�_�O�٬O�n��� */
             /*strcpy( flag1, " ");*/
             if(ldend1 < ldbgn2)
                strcpy( flag1, "Y");
             else
                strcpy( flag1, "N");

             strcpy( flag2, " ");
             /*strcpy( flag3, " ");*/

             /* 981230,�ץ������A�椧�e������� */
             /*  if ( strcmp(iengine, iengine_B1) == 0 )*/


             if ( strcmp(iengine, iengine_A2) == 0 )
                 strcpy( flag3, "N");
             else
                 strcpy( flag3, "Y");


             /*960726, A��O�_���D�I�٬O�n��� */
             /*strcpy( flag4, " ");*/
             if ( ply_ins_cnt > 0 )
                 strcpy( flag4, "N");
             else
                 strcpy( flag4, "Y");
         }
         else
         {
             if(ldend1 < ldbgn2)
                strcpy( flag1, "Y");
             else
                strcpy( flag1, "N");

               /* �Q�O�HID���P��O�J�ppolicy_302�ۦP sylvia 103.08.01 */
             if (( strcmp(iassured_A2, iassured_B1) == 0 ) && (icnt302 > 0))
                strcpy( flag2, "N");
             else
                strcpy( flag2, "Y");
              printf("-- 1901 icnt302=[%d]iassured_B1=[%s]iassured_A2=[%s]\n ",icnt302,iassured_B1,iassured_A2);

             /* 981230,�ץ������A�椧�e������� */
             /*  if ( strcmp(iengine, iengine_B1) == 0 )*/
             /* �s�W�ˮ�:�ˮֶ��P��O�J�p�ɤ��������B�Q�O�I�HID�B�O���۲�
               add by sylvia 103.08.01 (1030724002_C3) -----------------------------------*/
               icnt302 = 0;
               $select count(*) into $icnt302
                  from policy_302
                 where ipolicy =$bIpolicy
                   and iengine = $iengine;

             if (( strcmp(iengine, iengine_A2) == 0 ) && (icnt302 > 0) )
                 strcpy( flag3, "N");
             else
                 strcpy( flag3, "Y");

             printf("-- 1918 icnt302=[%d]iengine_A2=[%s]iengine=[%s]\n ",icnt302,iengine_A2,iengine);

             if ( ply_ins_cnt > 0 )
                 strcpy( flag4, "N");
             else
                 strcpy( flag4, "Y");
         }

         printf("flag1=[%s] flag2=[%s] flag3=[%s] flag4=[%s]\n",
                 flag1, flag2, flag3, flag4 );

         /** ���ŦX����A�L�X���� **/
         $INSERT INTO CAR331_BODY2 VALUES
         ($nchi_full, $iofficer, $nname, $ipolicy, $dply_bgn1, $dply_end1, $iengine, $itag,
          $nassured,$iassured_A2,$inext_ply,$dpolicy_A2,$dply_bgn_A2,$dply_end_A2,$iofficer_A2,
          $mprem_A2,$nequip_A2,$flag1,$flag2,$flag3,$flag4,$bIpolicy,$dply_bgn_B1,$dply_end_B1,
          $iassured_B1,$iengine_B1,$iofficer_B1,$dissue_A,$ipro_year_A,$ibig_comp_A);


         /*980113, �Y�O�w��O��A��O�@���,�n�Acheck�O�_�P�ɦ��O�N��
                   �]���p�G�O�Ĥ@�~�LB�檺�M��,�|�L�k�Ϋ᭱�� "Part 2 �ѲĤ@�~ B ���ĤG�~ A ��" ��w��O��A��
                   �i��N�|�|���O�N�� */
         if ( strlen(trim(ibig_comp_A)) == 0 ){

         	 printf(" ------- iengine_A2 = [%s]\n " , iengine_A2);
             strcpy(nextdbname, get_car_full_db(inext_ply));

             sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy  "
                    "FROM %s:ply_relation a, %s:policy b  "
                "WHERE a.ipolicy = b.ipolicy  "
                "AND a.fcard_class = '2' AND a.fedr_class <> '1' AND nvl(a.ibig_comp,'')<>''  "
                "AND (a.iofficer[1] not in ('W','H') and a.iofficer not in  "
                "     (select iofficer_ori from ca_promote_officer where iofficer_ori[1,1] = 'N'))  "
                "AND b.iengine = '%s'  "
                "AND a.dply_begin >= %d  AND a.dply_begin <= %d ",
             nextdbname, nextdbname, trim(iengine_A2), ldbgn2-30,ldbgn2+30);

             $PREPARE chk_tmp FROM $stmt;
             $DECLARE A2_to_A2 CURSOR for chk_tmp;
             $OPEN A2_to_A2;
             $FETCH A2_to_A2 INTO $inext_ply ;
             if(SQLCODE != SQLNOTFOUND )
             {
                printf(" -----getAnotherPly \n " );
                $CLOSE A2_to_A2;
                $FREE A2_to_A2;
                goto getAnotherPly;
             }else{
                $CLOSE A2_to_A2;
                $FREE A2_to_A2;
             }
         }
      }
      $CLOSE car331_2a;
      $FREE  car331_2a;

      /* printf("iofficer_1 = [%s]\n", trim(iofficer_1)); */

      /*1020805:�s�WY45*/
      /** Part 2 �ѲĤ@�~ B ���ĤG�~ A �� **/
      /** 980113, �Ĥ@�~�SB�沤�L **/
      /** 1. �Q�ΫO�������XB�楼��O��� **/
      /* �s�W�ζ�������(Y62)�BDLR������(Y63) add by sylvia 104.03.10 (1040212008_C1) */
      if( (strcmp( pro_no, "Y18") == 0) || (ISPROJ_NO_FST_PLY_B(pro_no)&&(qyear_A2==1)) )
      {

      }else{

	      iequip_flag = (iremark - 1) % 30 + 1;
	      strcpy(iequip_tmp,rtrim(itoa(iremark)));
	      strcpy(sequip_str,equip_instr(iequip_tmp));

	      /* �]����W,H�নN�����D, �אּŪ��ca_promote_officer�P�_�O�_���M�ץ� modify by sylvia 103.09.19 */
	      /*if( fanother[0] == 'Y' )
	      {
	         sprintf_s(stroff, sizeof stroff,"AND((a.iofficer[1] = '%s' AND a.iofficer[%d,%d] = '%s'  "
	                "AND length(a.iofficer) = %d) OR (a.iofficer[1] = '%s'  "
	                "AND a.iofficer[%d,%d] = '%s' AND length(a.iofficer) = %d)) "
	                 ,iofficer_1, ioff_ck_bgn, ioff_ck_end, ioff_chk, iofficer_len,
	                 iofficera_1, ioff_chk_bgna, ioff_ch_enda, ioff_chka, lofficera );
	      }
	      else
	      {
	         sprintf_s(stroff, sizeof stroff,"AND a.iofficer[1] = '%s' AND a.iofficer[%d,%d] = '%s'  "
	                "AND length(a.iofficer) = %d ",iofficer_1, ioff_ck_bgn,
	                 ioff_ck_end, ioff_chk, iofficer_len );
	      } */

	      sprintf_s(stroff, sizeof stroff, " AND a.iofficer in (select unique iofficer_ori  "
                       "from ca_promote_officer where iprmt = '%s') ",pro_no);

	      if( strcmp( pro_no ,"Y03") == 0 )
	          strcat(stroff," AND a.iofficer[9,10] <> 'ES'");

	      sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy, dply_begin, dply_end, b.iengine,  "
	                          "b.itag, b.nassured, b.iassured, a.iofficer  "
	                    " FROM %s:ply_relation a , %s:policy b  "
	                    "WHERE a.ipolicy = b.ipolicy  "
	                    "  AND ( a.inext_ply = ' ' or a.inext_ply is null )  "
	                    "  AND a.dply_end >= '%s' AND a.dply_end <= '%s'  "
	                    "  AND a.fedr_class <> '1' AND b.nequipment[%d] in %s  "
	                    "  AND (a.iofficer[1] = 'W' or (a.iofficer[1] = 'H' and a.iofficer[2] not in ('0','1','2'))  "
	                           "or a.iofficer in (select iofficer_ori from ca_promote_officer where iofficer_ori[1,1] = 'N'))  "
      	                  "AND a.iofficer[%d,%d] = '%s'  "
      	                  "AND length(a.iofficer) = %d ",
	                list[i].dbname, list[i].dbname, dply_bgn, dply_end,iequip_flag, sequip_str,
	                ioff_ck_bgn, ioff_ck_end, trim(ioff_chk), iofficer_len  );

	      printf("stmt[%s]\n", stmt);
	      $PREPARE car331_21 FROM $stmt;
	      $DECLARE car331_2b CURSOR for car331_21;
	      $OPEN car331_2b;
	      while(1)
	      {
	         $FETCH car331_2b INTO $ipolicy_B1, $dply_bgn1, $dply_end1, $iengine,
	                               $itag, $nassured, $iassured_B1, $iofficer_B1;
	         if(SQLCODE == SQLNOTFOUND)
	         {
	            break;
	         }

	         /** �Q��B��B�������X��X�ĤG�~ A �� **/
	         /** A �榳�i�������O�A�]��B��A�n�T�Ӹ�Ʈw���� **/
	         rstrdate( dply_end1, &ldend1 );
	         ifoundA=0;

	         for( chi=0; chi< count_db; chi++)
	         {
	         	 /* 980113, �R��AND a.ibig_comp <> ' '����,      */
	             strcpy(lastdbname,list[chi].dbname);
	             sprintf_s(stmt, sizeof stmt,"SELECT distinct a.ipolicy, a.dply_begin, a.dply_end, a.dpolicy, a.iofficer,  "
	                            " (a.mdmg_prem + a.mlia_prem), b.nequipment, a.ilast_ply,  "
	                            " (select nname from officer where iofficer = a.iofficer ), b.iassured,  "
	                            " (select nbranch from sa_branch_type where ibranch = a.iquota),(year(dissue)-1911)||'/'||TO_CHAR(dissue,'%%m'),a.ipro_year,nvl(a.ibig_comp,' ')  "
	                       " FROM %s:ply_relation a, %s:policy b, %s:ply_ins_type c  "
	                       "WHERE a.ipolicy = b.ipolicy AND a.ipolicy = c.ipolicy  "
	                       "  AND c.mdamage_cover > 0 AND a.ibig_comp <> ' ' "
	                       "  AND a.fedr_class <> '1'  "
	                       "  AND b.iengine = '%s' AND a.fcard_class = '2'  "
	                       "  AND a.dply_begin >= %d AND a.dply_begin <= %d",
	                       list[chi].dbname, list[chi].dbname, list[chi].dbname,
	                       iengine, ldend1-60, ldend1+60 );

	             $PREPARE chk_tmp FROM $stmt;
	             $DECLARE B1_to_A2 CURSOR for chk_tmp;
	             $OPEN B1_to_A2;
	             $FETCH B1_to_A2 INTO $ipolicy_A2, $ldbegin_A2, $ldend_A2,  $dpolicy_A2,
	                    $iofficer_A2, $mprem_A2, $nequipment, $last_ply, $nname, $iassured_A2, $nchi_full, $dissue_A, $ipro_year_A, $ibig_comp_A;
	             if(SQLCODE != SQLNOTFOUND )
	             {
	                ifoundA=1;
	                $CLOSE B1_to_A2;
	                $FREE B1_to_A2;
	                break;
	             }else{
	             	ifoundA=0;
	             	strcpy(ipolicy_A2," ");
	                $CLOSE B1_to_A2;
	                $FREE B1_to_A2;
	             }
	         }

	         printf("ifoundA=[%d] ipolicy_A2=[%s]\n", ifoundA, ipolicy_A2 );

	         if(ifoundA==0)
	            continue;

	         strcpy(iequip_tmp,rtrim(itoa(iremark)));
	         if (equip_cmp(nequipment,iequip_tmp) == TRUE)
	         {
	            strcpy(nequip_A2,"1"); /* ��O��A�榳�M�׵��O*/
	         }
	         else
	         {
	            strcpy(nequip_A2,"0");
	         }

	         /** �簣�W�@�q�w�ˮֹL��A�� **/
	         $SELECT ipolicy
	            FROM REC_A
	           WHERE ipolicy = $ipolicy_A2;
	         if( SQLCODE != SQLNOTFOUND )
	         {
	             continue;
	         }

	         printf("last_ply=[%s]\n", last_ply );

	         if( strlen(trim(last_ply)) > 0 )
	         {
	             /* AB���������P����A�y���W�q�ˮ֤�����OA�� */
	             ldend1 = ldend_A2;
	              sprintf_s(stmt, sizeof stmt,"SELECT dply_end FROM %s:ply_relation  "
	                           "WHERE ipolicy = '%s'", lastdbname, last_ply );
	             $PREPARE cur_getlast FROM $stmt;
	             $EXECUTE cur_getlast INTO $ldend1;
	         }

	         strcpy(nextdbname,get_car_full_db(ipolicy_A2));
	         sprintf_s(stmt, sizeof stmt,"SELECT count(*) FROM %s:ply_ins_type  "
	                       "WHERE ipolicy = '%s' AND mdamage_cover > 0  "
	                       "  AND iins_type in ('01','05','08','09','11','31','32')",
	                      nextdbname, ipolicy_A2);

	         $PREPARE g_ply_ins2 FROM $stmt;
	         $EXECUTE g_ply_ins2 INTO $ply_ins_cnt;

	         printf("mprem_A2=[%d] mlimit=[%d]\n", mprem_A2, mlimit );
	         printf("iofficer_A2=[%s]\n", iofficer_A2 );
	         printf("ldend1=[%d] ldbegin_A2=[%d]\n", ldend1 , ldbegin_A2 );
	         printf("nequip_A2=[%s] ply_ins_cnt=[%d]\n", nequip_A2, ply_ins_cnt );
	         printf("iassured_A2=[%s], iassured_B1=[%s]\n",iassured_A2, iassured_B1 );


	/*         if( (mprem_A2 >= mlimit) && (strncmp(iofficer_A2,"A",1) == 0) &&
	             (ldend1 >= ldbegin_A2) && (strcmp(nequip_A2,"1") == 0) &&
	             ( strcmp(iassured_A2, iassured_B1) == 0 ) &&
	             ( ply_ins_cnt > 0 ) ) */

	         /*�ץ��G980113,�u�n�O�O�N��,�B�ŦX����,�N continue */

	         /* �s�W�ˮ�:�ˮֶ��P��O�J�p�ɤ��������B�Q�O�I�HID�B�O���۲�
               add by sylvia 103.08.04 (1030724002_C3) -----------------------------------*/
               icnt302 = 0;
               $select count(*) into $icnt302
                  from policy_302
                 where ipolicy =$ipolicy_B1
                   and ilicense = $iassured_A2;

	       /* A�檺ñ��� - A��O�I�_�� (1080103010_SC1) */
	       strcpy(dpolicy_A2_100," "); strcpy(dply_bgn_A2_100," "); 
	       dpolicy_A2_int = dply_bgn_A2_int = 0;
	       if ( strlen(trim(dpolicy_A2)) != 0 )
	       {
	           strcpy(dpolicy_A2_100,cm_from_infdate_100(dpolicy_A2));  /* �褸����� */
	           dpolicy_A2_int = cm_ymd_cdate(dpolicy_A2_100);           /* ������Date */
	       }
	       strcpy(dply_bgn_A2_100,cm_from_infdate_100(dply_bgn_A2));
	       dply_bgn_A2_int = cm_ymd_cdate(dply_bgn_A2_100);
	         
	         printf("--2139 -- icnt302=[%d]ipolicy_B1=[%s]iassured_A2=[%s]\n",icnt302,ipolicy_B1,iassured_A2);
	         if( (mprem_A2 >= mlimit) && ( strlen(trim(ibig_comp_A)) > 0 ) &&
	             (ldend1 >= ldbegin_A2) && (strcmp(nequip_A2,"1") == 0) &&
	             ( strcmp(iassured_A2, iassured_B1) == 0 ) &&
	             ( ply_ins_cnt > 0 ) && (icnt302 > 0) &&
	             (dpolicy_A2_int-dply_bgn_A2_int) < 30 )
	         {
	             /** ��B��O�渹�B�������X�� CAR331_BODY2�A�Y����ƫh�R��
	                 For �ĤG�~�X�h���O���ƥ� **/
	             $DELETE FROM CAR331_BODY2
	               WHERE ipolicy_b1 = $ipolicy_B1
	                 AND iengine    = $iengine;
	             printf("--2150 -- icnt302=[%d]ipolicy_B1=[%s]iengine=[%s]\n",icnt302,ipolicy_B1,iengine);
	             continue;
	         }else{
	         	/* ��l���p���n�C�G
	         	   �u���O�N�󤣲ŦX
	         	   �u���@���]���ױ���^
	         	   �P�@�������O�N�󤣲ŦX �� �@��� �]��case�y��n�R���@��󪺫O��,�ȯd�O�N�� �^
	         	*/
	         }

	         strcpy( dply_bgn_A2, cm_edate_str(ldbegin_A2));
	         strcpy( dply_end_A2, cm_edate_str(ldend_A2));

	         /** ���ŦX����A�L�X���� **/
	         if( strlen(trim(last_ply)) == 0 )
	         {
	            strcpy(last_ply, " ");
	            strcpy(dply_bgn_A1," ");
	            strcpy(dply_end_A1, " ");
	         }
	         else
	         {
	            sprintf_s(stmt, sizeof stmt,"SELECT dply_begin, dply_end  "
	                          " FROM %s:ply_relation WHERE ipolicy = '%s'",
	                          lastdbname, last_ply );
	            $PREPARE get_d_A1 FROM $stmt;
	            $EXECUTE get_d_A1 into $dply_bgn_A1, $dply_end_A1;
	         }

	         if( ldend1 < ldbegin_A2 )
	         {
	             strcpy(flag1,"Y");
	         }
	         else
	             strcpy(flag1,"N");

	         /* �s�W�ˮ�:�ˮֶ��P��O�J�p�ɤ��������B�Q�O�I�HID�B�O���۲�
               add by sylvia 103.08.01 (1030724002_C3) -----------------------------------*/
               icnt302 = 0;
               $select count(*) into $icnt302
                  from policy_302
                 where ipolicy =$ipolicy_B1
                   and iengine = $iassured_A2;

	         printf("--2139 -- icnt302=[%d]ipolicy_B1=[%s]iassured_A2=[%s]\n",icnt302,ipolicy_B1,iassured_A2);
	         if (( strcmp(iassured_A2, iassured_B1) == 0 ) && (icnt302 > 0))
	         {
	             strcpy(flag2,"N");
	         }
	         else
	             strcpy(flag2,"Y");

	         strcpy(flag3,"N");

	         if( ply_ins_cnt > 0 )
	             strcpy(flag4,"N");
	         else
	             strcpy(flag4,"Y");

	         printf("iengine=[%s] insert into CAR331_BODY2 \n");

	         $INSERT INTO CAR331_BODY2 VALUES
	         ($nchi_full, $iofficer, $nname, $last_ply, $dply_bgn_A1, $dply_end_A1, $iengine, $itag,
	          $nassured,$iassured_A2,$ipolicy_A2,$dpolicy_A2,$dply_bgn_A2,$dply_end_A2,$iofficer_A2,
	          $mprem_A2,$nequip_A2,$flag1,$flag2,$flag3,$flag4,$ipolicy_B1,$dply_bgn1,$dply_end1,
	          $iassured_B1,$iengine,$iofficer_B1,$dissue_A,$ipro_year_A,$ibig_comp_A);

	      }
	      $CLOSE car331_2b;
	      $FREE  car331_2b;
      }
   }


   /* 980113: **************************************************************************************
      ��o�䪺�O�污�p���bCAR331_BODY2���]�P�@�����Ө��^�G
      1.�u���O�N��G�����ŦX���� �]���d�U�^
      2.�u���@��� �]���d�U�^
      3.�P�@�������O�N�󤣲ŦX �� �@��� �]�u�d�U�O�N��^ Ex. iengine = '4G18ETM007829'
      4.�P�@�������O�N��ŦX �� �@��� �]�����d�U�^

      => �P�_CAR331_BODY2�����,�P�@�����O�_�� "�u���@���" ���O��, �Y���h�����d�U; �Y��(�@��+�O�N),�h���R���@��� */

   /* �Ѥ@����ݬݬO�_���O�N�� */
   $DECLARE rep_331_x CURSOR FOR
     SELECT iengine,ipolicy_a2,dply_bgn_a2
       INTO $iengine,$inext_ply,$dply_bgn_A2
       FROM CAR331_BODY2 WHERE ibig_comp_a2 = ' ';
   $OPEN rep_331_x;
   while(1)
   {
   	   $FETCH rep_331_x;
   	   if(SQLCODE == SQLNOTFOUND) break;

       strcpy(nextdbname,get_car_full_db(inext_ply));
       rstrdate( dply_bgn_A2, &ldbegin_A2 );
       tmp_cnt = 0;
       sprintf_s(stmt, sizeof stmt,"SELECT count(*) FROM %s:ply_relation a, %s:policy b  "
                 "WHERE a.ipolicy = b.ipolicy AND a.fedr_class <> '1' AND a.fcard_class = '2' "
                   "AND a.iofficer[1] not in ('W','H')  "
                   "AND a.iofficer not in (select iofficer_ori from ca_promote_officer where iofficer_ori[1,1] = 'N')  "
                   "AND nvl(a.ibig_comp,' ')<> ' ' AND iengine = '%s'  "
                   "AND a.dply_begin >= %d AND a.dply_begin <= %d",
                  nextdbname, nextdbname, iengine, ldbegin_A2-45, ldbegin_A2+45 );
       printf(" ------- stmt = [%s]\n " , stmt);
       $PREPARE pre_tmp_cnt FROM $stmt;
       $EXECUTE pre_tmp_cnt into $tmp_cnt;

       /* �P�@����,���F���@���~,�٦��O�N�� => �C�J�ݧR�����@��� */
       if (tmp_cnt>0){
       	   $INSERT INTO tmp_dup_record VALUES($inext_ply, $iengine);
       }
   }
   $CLOSE rep_331_x;
   $FREE  rep_331_x;

   /* �R���W�zcase3.���@��󪺫O��, �ȯd�O�N��     */
   $DELETE FROM CAR331_BODY2
     WHERE ipolicy_a2 IN (SELECT ipolicy FROM tmp_dup_record );

   /****************************************************************************************/

   printf("----> start rep_331_2 \n");
   /* �]�� 2014/08/01-2014/08/31 ����X�ѵs�I�s��,��X�e�@�~�׬O�_���ӫO11�I��   */
   $DECLARE rep_331_2 CURSOR FOR
     SELECT nchi_full,iofficer,nname,NVL(last_ply," "),NVL(dply_bgn_a1," "),NVL(dply_end_a1," "),
            iengine,itag,nassured,iassured_a2,ipolicy_a2,dpolicy_a2,dply_bgn_a2,dply_end_a2,
            iofficer_a2,mprem_a2,nequip_a2,flag1,flag2,flag3,flag4,NVL(ipolicy_b1," "),
            NVL(dply_bgn_b1," "),NVL(dply_end_b1," "),iassured_b1,iengine_b1,iofficer_b1,dissue,ipro_year,ibig_comp_a2,
            case when (dply_bgn_a2 >= '08/01/2014') then 1 else 0 end
       INTO $nchi_full, $iofficer, $nname, $ipolicy, $dply_bgn1, $dply_end1, $iengine, $itag,
            $nassured, $iassured_A2, $inext_ply, $dpolicy_A2, $dply_bgn_A2, $dply_end_A2, $iofficer_A2,
            $mprem_A2, $nequip_A2, $flag1, $flag2, $flag3, $flag4,$bIpolicy, $dply_bgn_B1, $dply_end_B1,
            $iassured_B1, $iengine_B1, $iofficer_B1,$dissue_A,$ipro_year_A,$ibig_comp_A,
            $f201408
       FROM CAR331_BODY2;
   $OPEN rep_331_2;
   while(1)
   {
   	$FETCH rep_331_2;
   	if(SQLCODE == SQLNOTFOUND) break;

   	printf("inext_ply=[%s] ipolicy=[%s] bIpolicy=[%s]\n",
   	        inext_ply, ipolicy, bIpolicy );
   	printf("flag1=[%s] flag2=[%s] flag3=[%s] flag4=[%s]\n",
                flag1, flag2, flag3, flag4 );
    printf(" ------- ibig_comp_A = [%s]\n " , ibig_comp_A);
        strcpy(itag,trim(itag));
        rgu_put_body_string(2,nchi_full,LEFT);
        rgu_put_body_string(2,iofficer ,LEFT);
        rgu_put_body_string(2,nname    ,LEFT);
        rgu_put_body_string(2,trim(ipolicy),LEFT);
        rgu_put_body_string(2,trim(dply_bgn1),LEFT);
        rgu_put_body_string(2,trim(dply_end1),LEFT);
        rgu_put_body_string(2,trim(dissue_A),LEFT);
        rgu_put_body_string(2,trim(ipro_year_A),LEFT);
        rgu_put_body_string(2,iengine,LEFT);
        rgu_put_body_string(2,itag,LEFT);
        rgu_put_body_string(2,nassured,LEFT);
        rgu_put_body_string(2,iassured_A2,LEFT);

        rgu_put_body_string(2,inext_ply,LEFT);
        rgu_put_body_string(2,dpolicy_A2,LEFT);
        rgu_put_body_string(2,dply_bgn_A2,LEFT);
        rgu_put_body_string(2,dply_end_A2,LEFT);
        rgu_put_body_string(2,iofficer_A2,LEFT);
        rfmtlong(mprem_A2, "---------&", tmp_buf);
        rgu_put_body_string(2,tmp_buf,LEFT);
        rgu_put_body_string(2,nequip_A2,LEFT);

        rgu_put_body_string(2,flag1,LEFT);
        rgu_put_body_string(2,flag2,LEFT);
        rgu_put_body_string(2,flag3,LEFT);
        rgu_put_body_string(2,flag4,LEFT);

        rgu_put_body_string(2,trim(bIpolicy),LEFT);
        rgu_put_body_string(2,iofficer_B1,LEFT);
        rgu_put_body_string(2,dply_bgn_B1,LEFT);
        rgu_put_body_string(2,dply_end_B1,LEFT);
        rgu_put_body_string(2,iassured_B1,LEFT);
        rgu_put_body_string(2,iengine_B1,LEFT);

        /* �w��O��A��O���b2014/08/01-2014/08/31�~�n�C�L */
        strcpy(scount11, " ");
        if (f201408 >0)
        {
            if (strlen(trim(bIpolicy)) > 0)
               strcpy(scount11, "1");  /* ���O��1�~B��,���ܫe�@�~�פw���ӫO11�I�� */
            else
            {
               /* �L�e�@�~��B��,���d�e�@�~��A��O�_��11�I�� */
               pre_count11=0;
               if (strlen(trim(ipolicy)) > 0)
               {
                  /* ���e�O�渹, �H�e�O�渹�d */
                  strcpy(lastdbname,get_car_full_db(ipolicy));
                  sprintf_s(stmt, sizeof stmt,"select count(*) from  %s:ply_ins_type  "
                                "where ipolicy = '%s' and iins_type = '11'  "
                                "  and mdamage_cover > 0 ",lastdbname, ipolicy );
               }
               else
               {
                  /* �L�e�O�渹, �H��O���O�渹�d */
                  strcpy(lastdbname,get_car_full_db(inext_ply));
                  sprintf_s(stmt, sizeof stmt,"select count(*) from  %s:ply_ins_type  "
                                "where ipolicy = '%s' and iins_type = '11'  "
                                "  and mdamage_cover > 0 ",lastdbname, inext_ply );

               }
               $PREPARE pre_count11 FROM $stmt;
               $EXECUTE pre_count11 INTO $pre_count11;

               strcpy(scount11, itoa(pre_count11));
            }
        }
        rgu_put_body_string(2,scount11,LEFT);

        rgu_put_body(2);

        max_cnt += 1;

   }
   $CLOSE rep_331_2;
   $FREE  rep_331_2;

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(FAIL);
}


long  car331_body3()
{

   $char  stmt[2048], stmt2[2048];
   $int   iequip_flag, ricnt, clmcnt, mark;
   $char  sequip_str[201], iequip_tmp[4], nequipment[31];
   $char  ins_type[INSURANCE_TYPE], fedr_class[2], dendorse[11];
   $long  mdamage_cover;
   $char  ibig_sales[11],ibig_office[11],LHsIbig_Nname[11];
   $long  tmp_1101_chk,tmp_1201_chk, tmp_Y63_chk;
   $int   qyear_A1;

   printf("in car331_body3 A�楼��O���\n");
   strcpy(prt_title,"A�楼��O���");
   strcpy(prt_type,"�O������");

   rgu_put_body_string(1,prt_title,1);
   rgu_put_body_string(1,prt_type,1);
   rgu_put_body_string(1,dbegin1,1);
   rgu_put_body_string(1,dend1,1);
   rgu_put_body_string(1, cm_get_sysd(),1);
   rgu_put_body(1);

   max_cnt += 6;

   strcpy(dply_bgn, dbegin1);
   strcpy(dply_end, dend1  );

   printf("dply_end[%s]\n", dply_end );

   for( i=0; i< count_db; i++)
   {

      sprintf_s(stmt, sizeof stmt,
      "  SELECT count(*)             "
         " FROM reject_policy         "
         "WHERE ipolicy = ?           "
         "  AND fins_grp = '3'  ");
      $PREPARE rpid FROM $stmt;

      sprintf_s(stmt, sizeof stmt,
      "  SELECT count(*)             "
         " FROM %s:appraisal          "
         "WHERE ipolicy = ?           "
         "  AND fpart IN ('1','2','3') ",list[i].dbname);
      $PREPARE clmid FROM $stmt;

      tmp_1101_chk = 0; tmp_1201_chk = 0; tmp_Y63_chk = 0;
      iequip_flag = (iremark - 1) % 30 + 1;
      strcpy(iequip_tmp,rtrim(itoa(iremark)));
      strcpy(sequip_str,equip_instr(iequip_tmp));
      sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy, a.iofficer , (select nname from officer  "
                          "where iofficer = a.iofficer), dply_begin, dply_end,  "
                          "b.nassured, b.iengine, b.itag, (select nbranch from  "
                          "sa_branch_type where ibranch = a.iquota ),a.ibig_sales,a.ibig_office, "
                          "dply_begin,dissue,(a.dpolicy-'11/01/2013'::date),(a.dpolicy-'12/01/2013'::date),  "
                          "(a.dpolicy-'11/01/2014'::date)  "
                    " FROM %s:ply_relation a , %s:policy b  "
                    "WHERE a.ipolicy = b.ipolicy AND a.fedr_class not in  ('1','2','3')  "
                    "  AND a.fcard_class = '2' AND ( a.inext_ply = ' ' or a.inext_ply is null )  "
                    "  AND a.dply_end >= '%s' AND a.dply_end <= '%s'  "
                    "  AND a.iofficer[1] in %s AND b.nequipment[%d] in %s ",
                   list[i].dbname, list[i].dbname, dply_bgn, dply_end, trim(str_iagent), iequip_flag,sequip_str );

      printf("--> line 913 stmt[%s]\n", stmt);
      $PREPARE car331_3 FROM $stmt;
      $DECLARE car331_3a CURSOR for car331_3;
      $OPEN car331_3a;
      while(1)
      {
         $FETCH car331_3a INTO $ipolicy,  $iofficer, $nname, $dply_bgn1, $dply_end1,
                               $nassured, $iengine,  $itag, $nchi_full,$ibig_sales,$ibig_office,
                               $ldply_bgn_A,$lng_dissue_A,$tmp_1101_chk,$tmp_1201_chk,$tmp_Y63_chk;
         if(SQLCODE == SQLNOTFOUND)
         {
            break;
         }

         /* 103.02
			�M      ��			�Y�e�@�~A�欰�s����A��ƺI�����P�ɺ����H�U����
			------------------	-----------------------------------------------------------
			Y48			W�g��	�ηs2-5�~�ѵs�I�M��	�e�@�~A�椧ñ��� ��102/12/1
			Y53					�Ǵ����u�R�@�e�|�v�M��II	�e�@�~A�椧ñ��� ��102/11/1
			Y57			H�g��	�ηs2-5�~�ѵs�I�M��	���A�椧ñ��� ��102/12/1
			Y58					�Ǵ����u�R�@�e�|�v�M��II	�e�@�~A�椧ñ��� ��102/11/1
            Y45			W�g��   �ζ�2-6�~�ѵs�I�M�� 	�e�@�~A�椧ñ��� <103/11/1   add by sylvia 104.03.12(1040212008_C1)
			Y63			N�g��	DLR�u�����١v �e�@�~A�椧ñ��� ��103/11/1   add by sylvia 104.03.12(1040212008_C1)
         */
	  	 /*�H(�O��_��-�o�Ӧ~��)�p��M�׬��ĴX�~��,�Y�Ĥ@�~, qyear_A1=0 */
		 qyear_A1 = (int)floor((ldply_bgn_A - lng_dissue_A)/365.0 );  /* �L����˥h */
		 printf("-- 2558 -- qyear_A1=[%d] tmp_Y63_chk=[%ld] pro_no = [%s]\n", qyear_A1,tmp_Y63_chk,pro_no);
         if(qyear_A1==0){ /* ���A�欰�s���� */

         	  if (strcmp( pro_no, "Y48") == 0 ){        /* �ηs2-5�~�ѵs�I�M�� (W*�g��) */
         	  	  if (tmp_1201_chk >= 0) continue;
         	  }else if (strcmp( pro_no, "Y53") == 0 ){  /* �Ǵ����u�R�@�e�|�v�M��II (W*�g��) */
         	  	  if (tmp_1101_chk >= 0) continue;
         	  }else if (strcmp( pro_no, "Y45") == 0 ){  /* �ζ�2-6�~�ѵs�I�M�� add by sylvia 104.03.12(1040212008_C1) */
         	        printf(" --- 2566 ---- \n");
         	  	  if (tmp_Y63_chk >= 0) continue;
         	  }

         	  if (strcmp( pro_no, "Y57") == 0 ){        /* �ηs2-5�~�ѵs�I�M�� (H*�g��) */
         	  	  if (tmp_1201_chk < 0) continue;
         	  }else if (strcmp( pro_no, "Y58") == 0 ){  /* �Ǵ����u�R�@�e�|�v�M��II (H*�g��) */
         	  	  if (tmp_1101_chk < 0) continue;
         	  }else if (strcmp( pro_no, "Y63") == 0 ){  /* DLR�u�����١v add by sylvia 104.03.12(1040212008_C1) */
         	    printf(" --- 2575 ---- \n");
         	  	  if (tmp_Y63_chk < 0) continue;
         	  }
         }

         /** �ˬd���ګO�Υ��l�����ݥX�{��� **/
         $EXECUTE rpid
             INTO $ricnt
            USING $ipolicy;
         if (ricnt > 0)  continue;

         $EXECUTE clmid INTO $clmcnt USING $ipolicy;
         if (clmcnt > 0) continue;

         mark=0;
         sprintf_s(stmt2, sizeof stmt2," SELECT iins_type, fedr_status, nvl(dendorse,' '), mdamage_cover  "
                         " FROM %s:ply_ins_type  "
                         "WHERE ipolicy = ?", list[i].dbname);
         $PREPARE ins_cur1 FROM $stmt2;
         $DECLARE ins_cur CURSOR FOR ins_cur1;
         $OPEN ins_cur USING $ipolicy;
         while(1)
         {
             $FETCH ins_cur INTO $ins_type, $fedr_class, $dendorse, $mdamage_cover;
             if(SQLCODE == SQLNOTFOUND) break;

             printf("iins_type[%s],fedr_class[%s]\n",ins_type,fedr_class);

             /* �I�جO�_���Ĩ̫O�I���B�ӧP�_ */
             if (mdamage_cover > 0)
             {
                mark = 1;
                break;
             }

         }
         $CLOSE ins_cur;
         $FREE  ins_cur;

         if(mark == 0)
         {
            /****    This policy is cancelled    ****/
            printf("  mark == 0 ���� \n");
            continue;
         }

        /* 990119,Ū��������~��/�q����~������****/
        /* get_route_data(), input=> ( 1:����/�q����~��; 2:����/�q����~��),�g��N��,������~��/�q���N��,���ӳq����~���N��
                             output => ����/�q����~������W��  */
        LHsIbig_Nname[0]='';
        LHsIbig_Nname[1]='\0';
        rc = get_route_data(1, iofficer, ibig_office, ibig_sales, LHsIbig_Nname, v_sMsg);
        if (rc != M_CM_OK) strcpy(LHsIbig_Nname," ");
         strcpy(itag,trim(itag));
         /** �Ĥ@�~��� **/
         rgu_put_body_string(2,nchi_full,LEFT);
         rgu_put_body_string(2,iofficer ,LEFT);
         rgu_put_body_string(2,nname    ,LEFT);
         rgu_put_body_string(2,ipolicy  ,LEFT);
         rgu_put_body_string(2,dply_bgn1,LEFT);
         rgu_put_body_string(2,dply_end1,LEFT);
         rgu_put_body_string(2,iengine  ,LEFT);
         rgu_put_body_string(2,itag     ,LEFT);
         rgu_put_body_string(2,nassured ,LEFT);
         rgu_put_body_string(2,ibig_sales ,LEFT);
         rgu_put_body_string(2,LHsIbig_Nname ,LEFT);

         /** �ĤG�~��� **/
         rgu_put_body_string(2," ",LEFT);
         rgu_put_body_string(2," ",LEFT);
         rgu_put_body_string(2," ",LEFT);
         rgu_put_body_string(2," ",LEFT);
         rgu_put_body_string(2," ",LEFT);
         rgu_put_body(2);

         max_cnt += 1;

      }
      $CLOSE car331_3a;
      $FREE  car331_3a;


   }

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(FAIL);
}


long  car331_body4()
{
   $char   stmt[2048], stroff[512];
   $char   ipolicy12[5], str_date[200], str_date1[200];;
   $char   lastdbname[20], nextdbname[20];
   $long   ldbgn2, ldend1;
   $char   nequipment_B[31]="",nequipment_A[31]="";
   printf("in car331_body4 B��w��O���\n");
   strcpy(prt_title,"B��w��O���");

   if(strcmp(ctype,"1")==0)
   {
      strcpy(prt_type,"�O��ñ���");
   }
   else if(strcmp(ctype,"2")==0)
   {
      strcpy(prt_type,"�O������");
   }
   else if(strcmp(ctype,"3")==0)
   {
      strcpy(prt_type,"���O��");
   }
   else
      strcpy(prt_type," ");

   rgu_put_body_string(1,prt_title,1);
   rgu_put_body_string(1,prt_type,1);
   rgu_put_body_string(1,dbegin1,1);
   rgu_put_body_string(1,dend1,1);
   rgu_put_body_string(1, cm_get_sysd(),1);
   rgu_put_body(1);

   max_cnt += 6;
   strcpy(nequipment_90," ");

   if(strcmp(ctype,"1")==0) /* ñ��� */
   {
      /* �O��ñ���A�w�ĤG�~B�橹�^�� */
      /* ��X��ñ���d��A�w�g��O��B��*/
      dpay[0] = '\0';
      iofficer_B[0] = '\0';
      mins_premium_A = 0;
      sprintf_s(str_date, sizeof str_date,"AND a.dpolicy >= '%s' AND a.dpolicy <= '%s'", dbegin1, dend1 );
      for( i=0; i< count_db; i++)
      {
	      /* '1071205001_SC1_ �վ�{���W�٨æ^�k���s�t��*/
	      /* �Y�n�J�̤��~�Z��줣���u�ӫO���v�A�h�^������ƽd�򬰡��n�J�̩����ҰϤ���ơ� */
	      strcpy(sFullDBName_list , trim(list[i].dbname) );
	      if (fAdmin==0){  /*�D�ӫO��*/
	         if (strcmp(sFullDBName, sFullDBName_list) != 0) continue;
	      }
      	   iequip_flag = (iremark - 1) % 30 + 1;
           strcpy(iequip_tmp,rtrim(itoa(iremark)));
           strcpy(sequip_str,equip_instr(iequip_tmp));

      	/* �]����W,H�নN�����D, �אּŪ��ca_promote_officer�P�_�O�_���M�ץ� modify by sylvia 103.09.19 */
          /* if( fanother[0] == 'Y' )
          {
             sprintf_s(stroff, sizeof stroff,"AND((a.iofficer[1] = '%s' AND a.iofficer[%d,%d] = '%s'  "
                     "AND length(a.iofficer) = %d) OR (a.iofficer[1] = '%s'  "
                     "AND a.iofficer[%d,%d] = '%s' AND length(a.iofficer) = %d)) "
                      ,iofficer_1, ioff_ck_bgn, ioff_ck_end, ioff_chk, iofficer_len,
                      iofficera_1, ioff_chk_bgna, ioff_ch_enda, ioff_chka, lofficera );
          }
          else
          {
             sprintf_s(stroff, sizeof stroff,"AND a.iofficer[1] = '%s' AND a.iofficer[%d,%d] = '%s'  "
                        "AND length(a.iofficer) = %d ",iofficer_1, ioff_ck_bgn,
                         ioff_ck_end, ioff_chk, iofficer_len );
          } */

          if (strcmp(pro_no,"X00") == 0)
          {
             sprintf_s(stroff, sizeof stroff, " AND a.iofficer in  "
                              "(select unique iofficer_ori from ca_promote_officer  "
                              "where iprmt <> '' and iprmt not in  "
                              "(select detail2 from car_code where kind = 'RN' and detail = 'PROJ_X'))");
          }
          else
          {
             sprintf_s(stroff, sizeof stroff, " AND a.iofficer in (select unique iofficer_ori  "
                          "from ca_promote_officer where iprmt = '%s') ",pro_no);
          }

          if( strcmp( pro_no ,"Y03") == 0 )
              strcat(stroff," AND a.iofficer[9,10] <> 'ES'");

      	  printf("stroff=[%s]\n", stroff);
          printf("strdate=[%s]\n", str_date );

          /* 971112,�ק����I�W�ٳW�h */
      	  sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy, a.dpolicy, a.dply_begin, a.dply_end,  "
                             " a.ipolicy[1,2], a.ibig_office,  "
                             "(select nbranch from sa_branch_type where ibranch = a.iquota ),  "
                             "nvl(nvl( "
                                 "(select nname from officer where iofficer =  "
                                 "  (SELECT iofficer FROM ca_promote_officer  "
                                 "  WHERE iofficer_ori = a.iofficer AND ibig_office = a.ibig_office)),  "
                                 " (select nname from officer where iofficer = a.ibig_office)),  "
                                "(select nname from officer where iquota[1,4]=a.iquota[1,4] and ibus_location = a.ibig_office )) ,  "
                            "  nvl(case when ilast_ply matches '*-B' then ' ' else ilast_ply end ,' '),  "
                            "   c.nassured, c.itag, c.iengine,  "
                            " a.icard, a.iquota, b.dpay,(year(dissue)-1911)||'/'||TO_CHAR(dissue,'%%m'), "
                            " a.ipro_year,a.iofficer, a.dply_begin, a.dply_end,a.itmp_policy,  "
                            " a.ibig_sales, (select nname[1,20] from ca_big_office where fclass = '2' and ibig_comp = a.ibig_sales)  "
                       " FROM %s:ply_relation a , %s:policy c , outer %s:ao_plyedr_prem b "
                       "WHERE a.ipolicy = c.ipolicy  "
                       "  AND a.ipolicy = b.ipolicy1  "
                       "  AND c.nequipment[%d] in %s  "
                       "  AND a.icar_flag = '2'  "
                       "  AND b.iendorse=''  "
                       "  AND a.fedr_class <> '1' %s %s  "
                       " ORDER BY 1", list[i].dbname, list[i].dbname, list[i].dbname,
                       iequip_flag, sequip_str, str_date, stroff );

           printf("stmt[%s]\n", stmt);
           $PREPARE car331_41 FROM  $stmt;
           $DECLARE car331_41x CURSOR for car331_41;
           $OPEN car331_41x;
           while(1)
           {
           	   /* inext_ply => �w��O��B�檺�O�渹
           	      ipolicy   => �w��O��B�檺�e�O�渹 */

               $FETCH car331_41x INTO $inext_ply, $dpolicy, $dnext_bgn, $dnext_end,
                       $ipolicy12, $iofficer, $nchi_full,  $nname, $ipolicy,
                       $nassured, $itag, $iengine, $icard, $iquota, $dpayB,$dissue_B,
                       $ipro_year_B,$iofficer_B,$ldnext_bgn,$ldnext_end,$iestimate_B,
                       $sIbig_sales,$sales_name;

               if(SQLCODE == SQLNOTFOUND)
                   break;

               /* N�g�쪺���I�N���ΦW�٭ק� modify by sylvia 103.09.17 (1030630002_C1) */
               if (strncmp(iofficer_B,"N",1) == 0)
               {
                  $select a.ibig_office, b.nname
                     into $iofficer, $nname
                   from ca_promote_officer a, officer b
                   where a.iofficer = b.iofficer
                     and a.iofficer_ori = $iofficer_B;
               }
               /*-----------------------------------------------------------------------*/

               sprintf_s(stmt, sizeof stmt,"SELECT sum(mins_premium) , sum(mdiscount)/sum(mprem)*100  "
                             " FROM %s:ply_ins_type  "
                             "WHERE ipolicy = '%s' AND mdamage_cover > 0 "
                              , list[i].dbname, inext_ply );

               $PREPARE get_mins_prem FROM $stmt;
               $DECLARE get_mins CURSOR FOR get_mins_prem;
               $OPEN  get_mins;
               $FETCH get_mins INTO $mins_premium, $pdiscount;
               $CLOSE get_mins;
               $FREE  get_mins;

               pdiscount = (long)((pdiscount*100)+0.5);
               pdiscount = pdiscount / 100;

               strcpy(ipolicy, trim(ipolicy));
               if( strlen(ipolicy) > 0 )
               {
                   strcpy(lastdbname, get_car_full_db(ipolicy));
                   printf("Trace -- lastdbname = [%s] \n",  lastdbname);
                   printf("ipolicy=[%s] inext_ply=[%s]\n", ipolicy, inext_ply );
                   sprintf_s(stmt, sizeof stmt,"SELECT dply_begin, dply_end  "
                                 " FROM %s:ply_relation  "
                                 "WHERE ipolicy = '%s'", lastdbname, ipolicy );
                   printf("Trace -- stmt = [%s] \n",  stmt);
                   $PREPARE car331_4be FROM $stmt;
                   $EXECUTE car331_4be INTO $dply_bgn1, $dply_end1;
                   if(SQLCODE == SQLNOTFOUND)
                       continue;
               }
               else
               {
               	   strcpy( dply_end1, " ");
               	   strcpy( dply_bgn1, " ");
               }

               /* 100.09.26 ,�s�W �w��O��B�檺�g��N��(iofficer_B) / A��O�O / A��O�渹 / A�榬�O��       (�|�������)*/
               strcpy(lastdbname, get_car_full_db(inext_ply));
               sprintf_s(str_date1, sizeof str_date1," AND a.dply_end between %ld AND %ld", ldnext_end-30, ldnext_end+30 );

               sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy, (a.mdmg_prem + a.mlia_prem) , c.dpay, b.nequipment  "
                        " FROM %s:ply_relation a , %s:policy b, outer %s:ao_plyedr_prem c  "
                        "WHERE a.ipolicy = b.ipolicy AND a.ipolicy = c.ipolicy1  "
                        "  AND b.iengine = '%s'  "
                        "  AND a.fcard_class = '2' AND a.icar_flag = '2'  "
                        "  AND c.ftype ='P'  "
                        "  AND a.iofficer[1] in %s AND b.nequipment[%d] in %s  "
                        "  AND a.fedr_class <> '1' and a.iofficer[1] not in ('W','H')  "
                        "  AND a.iofficer not in (select iofficer_ori from ca_promote_officer where iofficer_ori[1,1] = 'N')  "
                        "  AND (a.mdmg_prem + a.mlia_prem) >= %d %s" ,
                       lastdbname, lastdbname,lastdbname,
                       iengine, trim(str_iagent), iequip_flag, sequip_str, mlimit, str_date1 );
               printf("Trace -- get_ply_A_prem stmt = [%s] \n",  stmt);
               $PREPARE get_ply_A_prem FROM $stmt;
               $DECLARE cur_ply_A CURSOR FOR get_ply_A_prem;
               $OPEN  cur_ply_A;
               $FETCH cur_ply_A INTO $ipolicy_A, $mins_premium_A, $dpay, $nequipment_A;
               $CLOSE cur_ply_A;
               $FREE  cur_ply_A;


               if (equip_cmp(nequipment_A,"90") == True){
               	 strcpy(nequipment_90, "1" );
               }else{
               	 strcpy(nequipment_90, "0" );
               }

               /** �C�L��� **/
               car331_put_body4();

           }
           $CLOSE car331_41x;
      	   $FREE  car331_41x;
      }

   }
   else if(strcmp(ctype,"2")==0) /* ����� */
   {
      dpay[0] = '\0';
      ipolicy_A[0] = '\0';
      mins_premium_A = 0;
      $CREATE TEMP TABLE B2_PLY
      (
          ipolicy   char(20)
      )
      WITH NO LOG;

      for( i=0; i< count_db; i++)
      /*for ( i=0; i< 0; i++)*/
      {

	      /* '1071205001_SC1_ �վ�{���W�٨æ^�k���s�t��*/
	      /* �Y�n�J�̤��~�Z��줣���u�ӫO���v�A�h�^������ƽd�򬰡��n�J�̩����ҰϤ���ơ� */
	      strcpy(sFullDBName_list , trim(list[i].dbname) );
	      if (fAdmin==0){  /*�D�ӫO��*/
	         if (strcmp(sFullDBName, sFullDBName_list) != 0) continue;
	      }

          iequip_flag = (iremark - 1) % 30 + 1;
          strcpy(iequip_tmp,rtrim(itoa(iremark)));
          strcpy(sequip_str,equip_instr(iequip_tmp));
          stroff[0]='\0';

          /* �]����W,H�নN�����D, �אּŪ��ca_promote_officer�P�_�O�_���M�ץ� modify by sylvia 103.09.19 */
          /* if( fanother[0] == 'Y' )
          {
             sprintf_s(stroff, sizeof stroff,"AND((a.iofficer[1] = '%s' AND a.iofficer[%d,%d] = '%s'  "
                     "AND length(a.iofficer) = %d) OR (a.iofficer[1] = '%s'  "
                     "AND a.iofficer[%d,%d] = '%s' AND length(a.iofficer) = %d)) "
                      ,iofficer_1, ioff_ck_bgn, ioff_ck_end, ioff_chk, iofficer_len,
                      iofficera_1, ioff_chk_bgna, ioff_ch_enda, ioff_chka, lofficera );
          }
          else
          {
             sprintf_s(stroff, sizeof stroff,"AND a.iofficer[1] = '%s' AND a.iofficer[%d,%d] = '%s'  "
                        "AND length(a.iofficer) = %d ",iofficer_1, ioff_ck_bgn,
                         ioff_ck_end, ioff_chk, iofficer_len );
          } */

          if (strcmp(pro_no,"X00") == 0)
          {
             sprintf_s(stroff, sizeof stroff, " AND a.iofficer in  "
                              "(select unique iofficer_ori from ca_promote_officer  "
                              "where iprmt <> '' and iprmt not in  "
                              "(select detail2 from car_code where kind = 'RN' and detail = 'PROJ_X'))");
          }
          else
          {
             sprintf_s(stroff, sizeof stroff, " AND a.iofficer in (select unique iofficer_ori  "
                          "from ca_promote_officer where iprmt = '%s') ",pro_no);
          }

          if( strcmp( pro_no ,"Y03") == 0 )
              strcat(stroff," AND a.iofficer[9,10] <> 'ES'");

         sprintf_s(str_date, sizeof str_date,"AND a.dply_end >= '%s' AND a.dply_end <= '%s'", dbegin1, dend1);

         printf("stroff=[%s]\n", stroff );
         printf("str_date=[%s]\n\n", str_date );

         /* step.1 �O������A�ѲĤ@�~B�橹��� */
         sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy, dply_begin, dply_end,  "
                          "b.nassured, b.itag, b.iengine, a.inext_ply  "
                    " FROM %s:ply_relation a , %s:policy b , %s:policy c "
                    "WHERE a.ipolicy = b.ipolicy AND a.ipolicy = c.ipolicy  "
                    "  AND ( a.inext_ply != ' ' AND a.inext_ply is not null )  "
                    "  AND a.fedr_class <> '1' AND c.nequipment[%d] in %s %s %s  "
                    "  ORDER BY 7", list[i].dbname, list[i].dbname, list[i].dbname,
                       iequip_flag, sequip_str, stroff, str_date );

         printf("stmt[%s]\n", stmt);
         $PREPARE car331_4 FROM $stmt;
         $DECLARE car331_4a CURSOR for car331_4;
         $OPEN car331_4a;
         while(1)
         {
            $FETCH car331_4a INTO $ipolicy, $dply_bgn1, $dply_end1,
                               $nassured, $itag, $iengine, $inext_ply;
            if(SQLCODE == SQLNOTFOUND)
            {
               break;
            }
            strcpy(nextdbname, get_car_full_db(inext_ply));

            /* 971112,�ק����I�W�ٳW�h */
            printf("ipolicy=[%s] inext_ply=[%s]\n", ipolicy, inext_ply );
            sprintf_s(stmt, sizeof stmt,"SELECT a.dpolicy, a.dply_begin, a.dply_end, a.ipolicy[1,2], a.ibig_office,  "
                             "(select nbranch from sa_branch_type where ibranch = a.iquota ),  "
                             "nvl(nvl( "
                                " (select nname from officer where iofficer =  "
                                "   (SELECT iofficer FROM ca_promote_officer  "
                                "   WHERE iofficer_ori = a.iofficer AND ibig_office = a.ibig_office)),  "
                                "  (select nname from officer where iofficer = a.ibig_office)),  "
                                "(select nname from officer where iquota[1,4]=a.iquota[1,4] and ibus_location = a.ibig_office )) ,  "
                            " a.icard, a.iquota, a.iofficer, b.dpay,(year(dissue)-1911)||'/'||TO_CHAR(dissue,'%%m'), "
                            " a.ipro_year,a.itmp_policy,  "
                            " a.ibig_sales, (select nname[1,20] from ca_big_office where fclass = '2' and ibig_comp = a.ibig_sales)  "
                       " FROM %s:ply_relation a, %s:policy c, outer %s:ao_plyedr_prem b  "
                       "WHERE a.ipolicy = b.ipolicy1  "
                       "  AND a.ipolicy = '%s'  "
                       "  AND a.ipolicy = c.ipolicy  "
                       "  AND b.iendorse = '' AND a.fedr_class <> '1' ",
                        nextdbname, nextdbname, nextdbname, inext_ply );

            $PREPARE ca331_b1 FROM $stmt;
            $EXECUTE ca331_b1 INTO $dpolicy, $dnext_bgn, $dnext_end,
                                   $ipolicy12, $iofficer, $nchi_full, $nname,$icard,
                                   $iquota, $iofficer_B, $dpayB, $dissue_B,$ipro_year_B,
                                   $iestimate_B,$sIbig_sales,$sales_name;
            if(SQLCODE == SQLNOTFOUND)
               continue;

            /* N�g�쪺���I�N���ΦW�٭ק� modify by sylvia 103.09.17 (1030630002_C1) */
            if (strncmp(iofficer_B,"N",1) == 0)
            {
               $select a.ibig_office, b.nname
                  into $iofficer, $nname
                from ca_promote_officer a, officer b
                where a.iofficer = b.iofficer
                  and a.iofficer_ori = $iofficer_B;
            }
            /*-----------------------------------------------------------------------*/

            sprintf_s(stmt, sizeof stmt,"SELECT sum(mins_premium) , sum(mdiscount)/sum(mprem)*100  "
                          " FROM %s:ply_ins_type  "
                          "WHERE ipolicy = '%s' AND mdamage_cover > 0 "
                           , nextdbname, inext_ply );

            $PREPARE get_mins_prem1 FROM $stmt;
            $DECLARE get_mins1 CURSOR FOR get_mins_prem1;
            $OPEN  get_mins1;
            $FETCH get_mins1 INTO $mins_premium, $pdiscount;
            $CLOSE get_mins1;
            $FREE  get_mins1;

            pdiscount = (long)((pdiscount*100)+0.5);
            pdiscount = pdiscount / 100;

            printf("itag=[%s] iengine=[%s]\n", itag, iengine );

            /** �C�L��� **/
            car331_put_body4();

            $INSERT INTO B2_PLY VALUES ($inext_ply);

         }
         $CLOSE car331_4a;
         $FREE  car331_4a;
      }


      rstrdate( dend1,   &ldend1 );
      rstrdate( dbegin1, &ldbgn2 );
      ipolicy[0] = '\0';
      dply_bgn1[0] = '\0';
      dply_end1[0] = '\0';

      printf("dbegin1 =[%s] ldbgn2=[%d] \n",dbegin1, ldbgn2 );
      printf("dend1   =[%s] ldend1=[%d] \n",dend1, ldend1 );


      for( i=0; i< count_db; i++)
      {
         /** step2 �LB1��AB2���O�I�_���� **/

         /* 971112,�ק����I�W�ٳW�h */
         sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy, a.dply_begin , a.dply_end,  "
                             "a.dpolicy, a.ibig_office,  "
                             "(select nbranch from sa_branch_type where ibranch = a.iquota ),  "
                             "nvl(nvl( "
                                " (select nname from officer where iofficer =  "
                                "   (SELECT iofficer FROM ca_promote_officer  "
                                "   WHERE iofficer_ori = a.iofficer AND ibig_office = a.ibig_office)),  "
                                "  (select nname from officer where iofficer = a.ibig_office)),  "
                                "(select nname from officer where iquota[1,4]=a.iquota[1,4] and ibus_location = a.ibig_office )) ,  "
                            " a.icard, a.iquota, b.itag, b.iengine, b.nassured[1,30],  "
                            " a.iofficer, c.dpay,(year(dissue)-1911)||'/'||TO_CHAR(dissue,'%%m'),a.ipro_year,a.itmp_policy,  "
                            " a.ibig_sales, (select nname[1,20] from ca_big_office where fclass = '2' and ibig_comp = a.ibig_sales)  "
                       " FROM %s:ply_relation a, %s:policy b, outer %s:ao_plyedr_prem c  "
                       "WHERE a.ipolicy = b.ipolicy AND a.ipolicy = c.ipolicy1  "
                       "  AND a.fedr_class <> '1' AND c.iendorse=''  "
                       "  AND a.dply_end >= %d AND a.dply_end <= %d %s ",
                       list[i].dbname, list[i].dbname, list[i].dbname, ldbgn2+365, ldend1+365, stroff );

         printf("stmt[%s]\n", stmt);
         $PREPARE car331_get_b2_pre FROM $stmt;
         $DECLARE car331_get_b2 CURSOR for car331_get_b2_pre;
         $OPEN car331_get_b2;
         while(1)
         {
             $FETCH car331_get_b2
               INTO $inext_ply, $dnext_bgn, $dnext_end, $dpolicy,
                    $iofficer, $nchi_full, $nname, $icard, $iquota,
                    $itag, $iengine, $nassured, $iofficer_B, $dpayB, $dissue_B,
                    $ipro_year_B,$iestimate_B,$sIbig_sales,$sales_name;
             if( SQLCODE == SQLNOTFOUND ) break;

             /* N�g�쪺���I�N���ΦW�٭ק� modify by sylvia 103.09.17 (1030630002_C1) */
               if (strncmp(iofficer_B,"N",1) == 0)
               {
                  $select a.ibig_office, b.nname
                     into $iofficer, $nname
                   from ca_promote_officer a, officer b
                   where a.iofficer = b.iofficer
                     and a.iofficer_ori = $iofficer_B;
               }
               /*-----------------------------------------------------------------------*/


             /** ������O�w�B�z **/
             $SELECT ipolicy FROM B2_PLY
               WHERE ipolicy = $inext_ply;
             if( SQLCODE == 0 )
                 continue;

 printf("itag=[%s] iengine = [%s]\n", itag, iengine );

             sprintf_s(stmt, sizeof stmt,"SELECT mins_premium, pdiscount  "
                           " FROM %s:ply_ins_type  "
                           "WHERE ipolicy = '%s' AND iins_type = '11'",
                          list[i].dbname, inext_ply );
             $PREPARE get_b2_prem FROM $stmt;
             $EXECUTE get_b2_prem INTO $mins_premium, $pdiscount;
             if( SQLCODE == SQLNOTFOUND )
             {
                 mins_premium = 0;
                 pdiscount    = 0;
             }

             /** �C�L��� **/
            car331_put_body4();
         }
         $CLOSE car331_get_b2;
         $FREE  car331_get_b2;
      }
   }
   else
   {
      /** �Ѧ��O����� **/
      for( i=0; i< count_db; i++)
      {

	      /* '1071205001_SC1_ �վ�{���W�٨æ^�k���s�t��*/
	      /* �Y�n�J�̤��~�Z��줣���u�ӫO���v�A�h�^������ƽd�򬰡��n�J�̩����ҰϤ���ơ� */
	      strcpy(sFullDBName_list , trim(list[i].dbname) );
	      if (fAdmin==0){  /*�D�ӫO��*/
	         if (strcmp(sFullDBName, sFullDBName_list) != 0) continue;
	      }

      	  /** step 1 ����dpay ��X�ζ��M�ת��۶O��O�� **/

      	  /* �ץ� b.iofficer[1] <> 'W' ��=> (b.iofficer[1] Between 'A' And 'P') */
      	  sprintf_s(stmt, sizeof stmt,"SELECT b.ipolicy, c.iengine, b.dply_end, a.dpay, b.fedr_class,  "
      	                      "(b.mdmg_prem + b.mlia_prem), c.nequipment  "
      	                " FROM %s:ao_plyedr_prem a, %s:ply_relation b, %s:policy c  "
      	                "WHERE a.ipolicy1 = b.ipolicy AND b.ipolicy = c.ipolicy  "
      	                "  AND a.ftype = 'P' AND b.fcard_class = '2' AND (b.iofficer[1] Between 'A' And 'P')  "
      	                "  AND a.dpay >= '%s' AND a.dpay <= '%s' AND a.iendorse='' ",
      	                   list[i].dbname, list[i].dbname, list[i].dbname, dbegin1, dend1 );

      	  /*
      	  sprintf_s(stmt, sizeof stmt,"SELECT b.ipolicy, c.iengine, b.dply_end, a.dpay, b.fedr_class, (b.mdmg_prem + b.mlia_prem)  "
      	                " FROM %s:ao_plyedr_prem a, %s:ply_relation b, %s:policy c  "
      	                "WHERE a.ipolicy1 = b.ipolicy AND b.ipolicy = c.ipolicy  "
      	                "  AND a.ftype = 'P' AND b.fcard_class = '2' AND b.iofficer[1] <> 'W'  "
      	                "  AND a.dpay >= '%s' AND a.dpay <= '%s' ",
      	                   list[i].dbname, list[i].dbname, list[i].dbname, dbegin1, dend1 );   */
          printf("stmt[%s]\n",stmt);
      	  $PREPARE car331_dpay FROM $stmt;
      	  $DECLARE car331_get_dpay CURSOR FOR car331_dpay;
      	  $OPEN car331_get_dpay;
      	  while(1)
      	  {
      	      $FETCH car331_get_dpay
      	        INTO $ipolicy_A, $iengine, $ldply_end_A, $dpay, $fedr_class,
      	             $mins_premium_A, $nequipment_A;

      	      if( SQLCODE == SQLNOTFOUND ) break;

      	      printf("==> ipolicy_A = [%s] iengine[%s]\n",ipolicy_A,iengine );
      	      printf("==>  Trace -- ldply_end_A = [%ld]  dpay=[%s]\n",  ldply_end_A,dpay);

      	      /** step2 ��A���������X�O�_��B��O�渹**/
      	      /* 971112,�ק����I�W�ٳW�h */
      	      sprintf_s(stmt, sizeof stmt,"SELECT a.iquota, (select nbranch from sa_branch_type where ibranch = a.iquota ),  "
      	                        "  a.ibig_office, nvl(nvl( "
                                " (select nname from officer where iofficer =  "
                                "   (SELECT iofficer FROM ca_promote_officer  "
                                "   WHERE iofficer_ori = a.iofficer AND ibig_office = a.ibig_office)),  "
                                "  (select nname from officer where iofficer = a.ibig_office)),  "
                                "(select nname from officer where iquota[1,4]=a.iquota[1,4] and ibus_location = a.ibig_office )) ,  "
      	                        "  b.itag, b.nassured[1,40], a.ipolicy, a.icard,  "
      	                        "  a.dpolicy, a.dply_begin, a.dply_end, a.ilast_ply, a.iofficer, c.dpay, (year(dissue)-1911)||'/'||TO_CHAR(dissue,'%%m'),a.ipro_year ,b.nequipment,a.itmp_policy,  "
      	                        "  (select fmail_to from ca_promote d where d.iprmt =  "
      	                        "       (select sbus_source from officer where iofficer = a.iofficer)),  "
                                " a.ibig_sales, (select nname[1,20] from ca_big_office where fclass = '2' and ibig_comp = a.ibig_sales)  "
      	                    " FROM %s:ply_relation a, %s:policy b, outer %s:ao_plyedr_prem c  "
      	                    "WHERE a.ipolicy = b.ipolicy  "
      	                    "  AND a.ipolicy = c.ipolicy1  "
      	                    "  AND b.iengine = '%s' AND a.fedr_class <> '1'  "
      	                    "  AND a.icar_flag = '2' AND a.fcard_class = '2'  "
      	                    "  AND (a.iofficer[1] = 'W' or (a.iofficer[1] = 'H' and a.iofficer[2] not in ('0','1','2'))  "
      	                    "       or a.iofficer in (select iofficer_ori from ca_promote_officer where iofficer_ori[1,1] = 'N'))  "
      	                    "  AND c.iendorse=''  "
      	                    "  AND a.dply_end >= %d AND a.dply_end <= %d ",
      	                    list[i].dbname, list[i].dbname, list[i].dbname, iengine, ldply_end_A-30, ldply_end_A+30 );

printf("stmt[%s]\n",stmt);
      	      $PREPARE car331_atob2 FROM $stmt;
      	      $DECLARE car331_atob2_1 CURSOR for car331_atob2;
      	      $OPEN car331_atob2_1;
      	      while(1)
      	      {
      	      	 /* �`�N�����G a.ipolicy   => inext_ply �]�w��O��B�渹�^ ;
      	      	               a.ilast_ply => ipolicy   �]�e�@�~B�渹  �^*/
      	      	 $FETCH car331_atob2_1 INTO $iquota, $nchi_full, $iofficer,   $nname,
      	      	                   $itag,   $nassured,  $inext_ply,  $icard,  $dpolicy,
      	      	                   $dnext_bgn, $dnext_end, $ipolicy, $iofficer_B, $dpayB, $dissue_B,$ipro_year_B,$nequipment_B,$iestimate_B,
      	      	                   $fmail_to,$sIbig_sales,$sales_name;
      	      	 if(SQLCODE == SQLNOTFOUND) break;


      	      	 /* N�g�쪺���I�N���ΦW�٭ק� modify by sylvia 103.09.17 (1030630002_C1) */
                  if (strncmp(iofficer_B,"N",1) == 0)
                  {
                     $select a.ibig_office, b.nname
                        into $iofficer, $nname
                      from ca_promote_officer a, officer b
                      where a.iofficer = b.iofficer
                        and a.iofficer_ori = $iofficer_B;
                  }
               /*-----------------------------------------------------------------------*/

      	      	 printf("inext_ply=[%s] ipolicy=[%s]\n", inext_ply, ipolicy );

      	      	 /* 990601 */
      	      	 if (sFilterOption[0]=='0'){        /* ���H�o����*/
      	      	 	if (equip_cmp(nequipment_B,"75") == True ){
      	      	 		continue;
      	      	 	}
      	      	 	fSend[0] = '0';
      	      	 }else if (sFilterOption[0]=='1'){  /* �w�H�o����*/
      	      	 	if (equip_cmp(nequipment_B,"75") != True ){
      	      	 		continue;
      	      	 	}
      	      	 	fSend[0] = '1';
      	      	 }else{
      	      	 	if (equip_cmp(nequipment_B,"75") == True ){
      	      	 		fSend[0] = '1';
      	      	 	}else{
      	      	 		fSend[0] = '0';
      	      	 	}
      	      	 }
      	      	 fSend[1] = '\0';


                if (strlen(trim(ipolicy))==0){
	                /* => �u�� ilast_ply ���O�I */
	            	/* ��ʧ�XB��e�@�O�渹�A�b�����D�ثe�O��O��M�ױ���U,��nequipment�ӽT�{�e���O�_�P�@�ӱM�� */
	            	/* �]���]�e��B��b�P�@�Ӥ����q(��Ʈw)�X��^ */
		             sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy  "
		                          " FROM %s:ply_relation a, %s:policy b, %s:ply_ins_type c  "
		                          "WHERE a.ipolicy = b.ipolicy AND b.ipolicy = c.ipolicy  "
		                          "  AND c.mdamage_cover > 0  "
		                          "  AND b.iengine = '%s' AND a.fcard_class = '2'  "
		                          "  and (a.iofficer[1] = 'W' or (a.iofficer[1] = 'H' and a.iofficer[2] not in ('0','1','2'))  "
		                          "       or a.iofficer in (select iofficer_ori from ca_promote_officer where iofficer_ori[1,1] = 'N'))  "
		                          "  AND a.dply_begin >= %d AND a.dply_begin <= %d  "
		                          "  and b.nequipment = '%s'",
		                          list[i].dbname, list[i].dbname, list[i].dbname,iengine,
		                          ldply_end_A-365-30, ldply_end_A-365+30 ,nequipment_B);

		             $PREPARE pre_chk1 FROM $stmt;
		             $DECLARE cur_chk1 CURSOR for pre_chk1;
		             $OPEN cur_chk1;
		             $FETCH cur_chk1 INTO $ipolicy;
		             if(SQLCODE == SQLNOTFOUND){
		             	 strcpy( ipolicy, " ");
		             }
		             $CLOSE cur_chk1;
		             $FREE  cur_chk1;
                 }

      	      	 /** Get B2 mins_premium, pdiscount **/
      	      	 /*  960327, ����sql����,B���ذe���I�� */
      	      	 sprintf_s(stmt, sizeof stmt,"SELECT mins_premium, pdiscount  "
      	      	               " FROM %s:ply_ins_type  "
      	      	               "WHERE ipolicy = '%s'  "
                               "  AND mdamage_cover > 0 ",
      	      	              list[i].dbname, inext_ply);
/*
      	      	 sprintf_s(stmt, sizeof stmt,"SELECT mins_premium, pdiscount  "
      	      	               " FROM %s:ply_ins_type  "
      	      	               "WHERE ipolicy = '%s'  "
                               "  AND mdamage_cover > 0  "
                               "  AND iins_type in %s",
      	      	              list[i].dbname, inext_ply, str_iins );*/
                 printf("stmt[%s]\n",stmt);
      	      	 $PREPARE get_b2_prem FROM $stmt;
                 $DECLARE cur_get_b2 CURSOR FOR get_b2_prem;
                 $OPEN    cur_get_b2;
                 qins_cnt=0;
                 while(1)
                 {
      	      	     $FETCH cur_get_b2 INTO $mins_premium, $pdiscount;
         	     if( SQLCODE == SQLNOTFOUND ) break;
                     qins_cnt++;
                 }
                 $CLOSE cur_get_b2;
                 $FREE  cur_get_b2;
                 if (qins_cnt < qins_type)
      	      	     continue;      /** �L�ذe�I�ؤ��M�� **/

      	      	 /** ���B2 ��B1**/
      	      	 if( strlen(trim(ipolicy)) > 0 )
      	      	 {
      	      	     strcpy(lastdbname, get_car_full_db(ipolicy));

      	      	     sprintf_s(stmt, sizeof stmt,"SELECT dply_begin, dply_end  "
      	      	                   " FROM %s:ply_relation  "
      	      	                   "WHERE ipolicy = '%s'",
                             lastdbname, ipolicy );
      	      	     $PREPARE get_b1_data FROM $stmt;
      	      	     $EXECUTE get_b1_data INTO $dply_bgn1, $dply_end1;
      	      	 }
      	      	 else
      	      	 {
      	      	     dply_bgn1[0] = '';
      	      	     dply_end1[0] = '';
      	      	 }

      	      	 /** Get A mins_premium **/
      	      	 if( fedr_class[0] == '1' )
      	      	 {
      	      	     /** ���P => �O�O�B���O�鬰�ť� **/
      	      	     dpay[0] = '\0';
      	      	     mins_premium_A = 0;
      	      	 }
      	      	 else
      	      	 {
      	      	     sprintf_s(stmt, sizeof stmt,"SELECT sum(mdamage_cover)  "
      	      	                   " FROM %s:ply_ins_type  "
      	      	                   "WHERE ipolicy = '%s'  "
      	      	                   "  AND iins_type in ('01','05','08','09','11','31','32')",
      	      	                   list[i].dbname, ipolicy_A );
      	      	     $PREPARE get_A_prem FROM $stmt;
      	      	     $EXECUTE get_A_prem INTO $mdamage_cover_A;
      	      	     if( SQLCODE == SQLNOTFOUND )
      	      	     {
      	      	     	 mins_premium_A = 0;
      	      	     	 mdamage_cover_A = 0;
      	      	     }

      	      	     if( mdamage_cover_A == 0 )
      	      	     	dpay[0] = '\0';

      	      	 }

      	         if (equip_cmp(nequipment_A,"90") == True){
               	   strcpy(nequipment_90, "1" );
                  }else{
                  	strcpy(nequipment_90, "0" );
                  }
      	         /** �C�L��� **/
                 car331_put_body4();
      	      }
      	      $CLOSE car331_atob2_1;
      	      $FREE  car331_atob2_1;

      	  }
      	  $CLOSE car331_get_dpay;
      	  $FREE  car331_get_dpay;
      }
      /** end of dblist **/

   }

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(FAIL);
}

long  car331_body5()
{

   $char  stmt[2048], stroff[300], stmt2[2048];
   $char  office_name[10], sales_name[10], iofficer13[10], ibig_sales[10];
   $char  ins_type[INSURANCE_TYPE], fedr_class[2], dendorse[11],inext_ply_B1[21];
   $long  mdamage_cover,lng_dissue_B,lng_dply_begin_B;
   $int   ricnt, clmcnt, mark=0,searchB;
   $char  dissue_B[11]=" ";
   $int   qnext_year_B  = 0 ;
   $char  Biofficer[11];

   printf("in car331_body5 B�楼��O���\n");
   strcpy(prt_title,"B�楼��O���");
   strcpy(prt_type,"�O������");

   strcpy(dply_bgn, dbegin1);
   strcpy(dply_end, dend1  );

   rgu_put_body_string(1,prt_title,1);
   rgu_put_body_string(1,prt_type,1);
   rgu_put_body_string(1,dply_bgn,1);
   rgu_put_body_string(1,dply_end,1);
   rgu_put_body_string(1, cm_get_sysd(),1);
   rgu_put_body(1);

   max_cnt += 6;

   for( i=0; i< count_db; i++)
   {

      iequip_flag = (iremark - 1) % 30 + 1;
      strcpy(iequip_tmp,rtrim(itoa(iremark)));
      strcpy(sequip_str,equip_instr(iequip_tmp));

      /* �]����W,H�নN�����D, �אּŪ��ca_promote_officer�P�_�O�_���M�ץ� modify by sylvia 103.09.19  */
      /* if( fanother[0] == 'Y' )
      {
         sprintf_s(stroff, sizeof stroff,"AND((a.iofficer[1] = '%s' AND a.iofficer[%d,%d] = '%s'  "
                     "AND length(a.iofficer) = %d) OR (a.iofficer[1] = '%s'  "
                     "AND a.iofficer[%d,%d] = '%s' AND length(a.iofficer) = %d)) "
                      ,iofficer_1, ioff_ck_bgn, ioff_ck_end, ioff_chk, iofficer_len,
                      iofficera_1, ioff_chk_bgna, ioff_ch_enda, ioff_chka, lofficera );
      }
      else
      {
         sprintf_s(stroff, sizeof stroff,"AND a.iofficer[1] = '%s' AND a.iofficer[%d,%d] = '%s'  "
                        "AND length(a.iofficer) = %d ",iofficer_1, ioff_ck_bgn,
                         ioff_ck_end, ioff_chk, iofficer_len );
      } */

      sprintf_s(stroff, sizeof stroff, " AND a.iofficer in (select unique iofficer_ori  "
                       "from ca_promote_officer where iprmt = '%s') ",pro_no);

      if( strcmp( pro_no ,"Y03") == 0 )
          strcat(stroff," AND a.iofficer[9,10] <> 'ES'");

      printf("stroff=[%s]\n", stroff );
      printf("sequip_str=[%s]\n\n", sequip_str );


      sprintf_s(stmt, sizeof stmt,
      "  SELECT count(*)             "
         " FROM reject_policy         "
         "WHERE ipolicy = ?           "
         "  AND fins_grp = '3'  ");
      $PREPARE rpid FROM $stmt;

      sprintf_s(stmt, sizeof stmt,
      "  SELECT count(*)             "
         " FROM %s:appraisal          "
         "WHERE ipolicy = ?           "
         "  AND fpart IN ('1','2','3') ",list[i].dbname);
      $PREPARE clmid FROM $stmt;

      /* 971112,�ק����I�W�ٳW�h */
      sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy, a.ibig_office ,   "
                             "nvl(nvl( "
                                " (select nname from officer where iofficer =  "
                                "   (SELECT iofficer FROM ca_promote_officer  "
                                "   WHERE iofficer_ori = a.iofficer AND ibig_office = a.ibig_office)),  "
                                "  (select nname from officer where iofficer = a.ibig_office)),  "
                                "(select nname from officer where iquota[1,4]=a.iquota[1,4] and ibus_location = a.ibig_office )) ,  "
                          "dply_begin, dply_end,  "
                          "b.nassured, b.itag, b.iengine, (select nbranch from sa_branch_type  "
                          "where ibranch = a.iquota), ibig_sales,  "
                          "(select nname from ca_big_office where fclass = '2' and ibig_comp = a.ibig_sales ) , "
                          "(select ibig_branch from ca_big_office where fclass = '1' and ibig_comp =  "
                                      "(SELECT iofficer FROM ca_promote_officer  "
                                      "  WHERE iofficer_ori = a.iofficer AND ibig_office = a.ibig_office)) ,  "
                         "(year(dissue)-1911)||'/'||TO_CHAR(dissue,'%%m'),dply_begin, a.iofficer  "
                    " FROM %s:ply_relation a , %s:policy b  "
                    "WHERE a.ipolicy = b.ipolicy  "
                    "  AND a.fedr_class <> '1'   "
                    "  AND ( a.inext_ply = ' ' or a.inext_ply is null )  "
                    "  AND a.dply_end >= '%s' AND a.dply_end <= '%s'  "
                    "  AND a.fedr_class <> '1' AND b.nequipment[%d] in %s %s",
                       list[i].dbname, list[i].dbname, dply_bgn, dply_end, iequip_flag,
                       sequip_str, stroff );

      printf("--> line 1271 stmt[%s]\n\n", stmt);
      $PREPARE car331_5 FROM $stmt;
      $DECLARE car331_5a CURSOR for car331_5;
      $OPEN car331_5a;
      while(1)
      {
         $FETCH car331_5a INTO $ipolicy, $ibig_office, $nname, $dply_bgn1, $dply_end1,
                               $nassured, $itag, $iengine, $nchi_full, $ibig_sales,
                               $sales_name, $office_name,$dissue_B,$lng_dply_begin_B,
                               $Biofficer;
         if(SQLCODE == SQLNOTFOUND)
         {
            break;
         }
         printf("ipolicy[%s] itag[%s]\n", ipolicy, itag );

         /* N�g�쪺���I�N���ΦW�٭ק� modify by sylvia 103.09.17 (1030630002_C1) */
         if (strncmp(iofficer_B,"N",1) == 0)
         {
            $select a.ibig_office, b.nname
               into $ibig_office, $nname
               from ca_promote_officer a, officer b
              where a.iofficer = b.iofficer
                and a.iofficer_ori = $Biofficer;
         }
         /*-----------------------------------------------------------------------*/


         /** �ˬd���ګO�Υ��l�����ݥX�{��� **/
         $EXECUTE rpid
             INTO $ricnt
            USING $ipolicy;
         if (ricnt > 0)  continue;

         $EXECUTE clmid INTO $clmcnt USING $ipolicy;
         if (clmcnt > 0) continue;


         /* 98.12.29 fix*/
    	 /* ���M inext_ply = ' ' �]���i��ӳ�w��O�A�A�T�{B��O�_�w��O�G�� (B��O���ͮĤ�+365) �� ������ �h�� */
    	 mark=0;
         for(searchB=0; searchB< count_db; searchB++)
         {
              sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy  "
                           " FROM %s:ply_relation a, %s:policy b, %s:ply_ins_type c  "
                           "WHERE a.ipolicy = b.ipolicy AND b.ipolicy = c.ipolicy  "
                           "  AND c.mdamage_cover > 0  "
                           "  AND b.iengine = '%s' AND a.fcard_class = '2'  "
                           "  AND b.nequipment[%d] in %s %s  "
                           "  AND a.dply_begin >= %d AND a.dply_begin <= %d ",
                           list[searchB].dbname, list[searchB].dbname, list[searchB].dbname,
                           iengine, iequip_flag,sequip_str, stroff,lng_dply_begin_B +365 -30 , lng_dply_begin_B +365 +30);

              $PREPARE pre_chkB FROM $stmt;
              $DECLARE cur_chkB CURSOR for pre_chkB;
              $OPEN cur_chkB;
              $FETCH cur_chkB INTO $inext_ply_B1;
              if(SQLCODE == SQLNOTFOUND){
              	 strcpy( inext_ply_B1, " ");
              	 mark=1; /* B�楼��O */
              }else{
              	 mark=0; /* B��w��O */
              	 break;
              }
              $CLOSE cur_chkB;
              $FREE  cur_chkB;
         }

         if(mark == 0)
         {
            /****    This policy is cancelled    ****/
            printf(" B��[iengine=%s]�w��O[ipolicy=%s] \n",iengine,inext_ply_B1);
            continue;
         }

         mark=0;
         sprintf_s(stmt2, sizeof stmt2," SELECT iins_type, fedr_status, nvl(dendorse,' '), mdamage_cover  "
                         " FROM %s:ply_ins_type  "
                         "WHERE ipolicy = ?", list[i].dbname);
         $PREPARE ins_cura1 FROM $stmt2;
         $DECLARE ins_cura CURSOR FOR ins_cura1;
         $OPEN ins_cura USING $ipolicy;
         while(1)
         {
             $FETCH ins_cura INTO $ins_type, $fedr_class, $dendorse, $mdamage_cover;
             if(SQLCODE == SQLNOTFOUND) break;

             printf("iins_type[%s],fedr_class[%s]\n",ins_type,fedr_class);

             /* �I�جO�_���Ĩ̫O�I���B�ӧP�_ */
             if (mdamage_cover > 0)
             {
                mark = 1;
                break;
             }

         }
         $CLOSE ins_cura;
         $FREE  ins_cura;

         if(mark == 0)
         {
            /****    This policy is cancelled    ****/
            printf("  mark == 0 ���� \n");
            continue;
         }
         /* 101.11,�]���Z�Ĩ��A  "+0.2(2.4�Ӥ�)" �אּ "-0.5(6�Ӥ�)"  */
         /*  98.12.29  check �M�׬O�_�w��� */
         printf(" ------- dissue_B = [%s]\n " , dissue_B);
         printf(" ------- lng_dply_begin_B_ch = [%s]\n " , cm_cdate_str_100(lng_dply_begin_B));
         if (dissue_B[0]!='\0'){
         	 strcpy(dissue_B,trim(dissue_B));
             lng_dissue_B = cm_build_date_ym(dissue_B,1);
             qnext_year_B    = (int)((lng_dply_begin_B - lng_dissue_B)/365.0 - 0.5 + 0.5);
             printf(" ------- qnext_year_B = [%d]\n " , qnext_year_B);
             printf(" ------- qnext_year_chk = [%d]\n " , qnext_year_chk);
             if( qnext_year_B >= qnext_year_chk -1 )  continue;
         }
         strcpy(itag,trim(itag));
         rgu_put_body_string(2,nchi_full  ,LEFT);
         rgu_put_body_string(2,office_name,LEFT);
         rgu_put_body_string(2,ibig_office,LEFT);
         rgu_put_body_string(2,nname,LEFT);
         rgu_put_body_string(2,ibig_sales,LEFT);
         rgu_put_body_string(2,sales_name,LEFT);
         rgu_put_body_string(2,ipolicy,LEFT);
         rgu_put_body_string(2,dply_bgn1,LEFT);
         rgu_put_body_string(2,dply_end1,LEFT);
         rgu_put_body_string(2,iengine,LEFT);
         rgu_put_body_string(2,itag,LEFT);
         rgu_put_body_string(2,nassured,LEFT);
         rgu_put_body_string(2,dissue_B,LEFT);
         rgu_put_body(2);

         max_cnt += 1;
      }
      $CLOSE car331_5a;
      $FREE  car331_5a;
   }


   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(FAIL);
}

char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  char sTmp_db_name[21];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
  }
  return sTmp_db_name;
}

long get_ca_promote()
{
   int iTmp;
   char sTmp[11];

   $whenever sqlerror goto errexit;

   printf("===== start  get_ca_promote \n");
   printf("===== pro_no [%s] \n", pro_no );

   strcpy(fmail_to, "0");
   if( strncmp(trim(pro_no)+1, "00",2) == 0 )
   {

      $SELECT qins_type,iins_type,iagent,fmail_to
         INTO $qins_type,$iins_type,$iagent, $fmail_to
         FROM ca_promote
        WHERE iprmt = $pro_no;
      if (SQLCODE==SQLNOTFOUND)
      {
      	 /*960320, X00 ��O�󦬶O���*/
         if(strncmp(trim(pro_no), "X00",3) == 0){
	          qins_type = 1;
	          /* 960327, str_iins �w�Τ���,B�檺 sql stmt �w�g�����ذe�I�ر���  */
	          strcpy(str_iins,"('01','05','08','09','11','31','32','51')");

         }else{
	          qins_type = 1;
	          strcpy(str_iins,"('11')");
	          strcpy(str_iagent,"('A')");
         }
          return M_CM_OK;
      }

      strcpy( str_iins, "('" );

      for( iTmp=0; iTmp < strlen(iins_type) - 1; iTmp++)
      {
          if( iins_type[iTmp] == ',')
          {
              strcat( str_iins, "','");
          }
          else if( iins_type[iTmp] != '\0' && iins_type[iTmp] != ' ' )
          {

              sTmp[0] = iins_type[iTmp];
              sTmp[1] = '\0';

              strcat( str_iins, sTmp);
          }
      }
      strcat( str_iins, "')" );

      strcpy( str_iagent, "(" );
      for( iTmp=0; iTmp < strlen(iagent) - 1; iTmp++)
      {
          if( iagent[iTmp] == ',')
          {
              strcat( str_iagent, ",");
          }
          else if( iagent[iTmp] != '\0' && iagent[iTmp] != ' ' )
          {
              strcat( str_iagent, "'" );

              sTmp[0] = iagent[iTmp];
              sTmp[1] = '\0';

              strcat( str_iagent, sTmp);
              strcat( str_iagent, "'" );
          }
      }
      strcat( str_iagent, ")" );

      return M_CM_OK;
   }
   else
   {
      $SELECT iprmt, nprmt, iremark, iagent, iofficer_1, lofficer,
              ioff_chk_bgn, ioff_chk_len, ioff_chk, mlimit, fanother,
              iofficera_1, lofficera , ioff_chk_bgna, ioff_chk_lena, ioff_chka,qyear,
              fmail_to
         INTO $iprmt, $nprmt, $iremark, $iagent, $iofficer_1, $iofficer_len,
              $ioff_ck_bgn, $ioff_ck_len, $ioff_chk, $mlimit, $fanother,
              $iofficera_1, $lofficera , $ioff_chk_bgna, $ioff_chk_lena, $ioff_chka,$qnext_year_chk,
              $fmail_to
         FROM ca_promote
        WHERE iprmt = $pro_no;
      if(SQLCODE != SQLNOTFOUND )
      {
         ioff_ck_end = ioff_ck_bgn + ioff_ck_len -1;
         strcpy( iofficer_1, trim(iofficer_1));

         if( fanother[0] == 'Y' )
         {
             ioff_ch_enda = ioff_chk_bgna + ioff_chk_lena -1;
             strcpy( iofficera_1, trim(iofficera_1));
         }
         else
             ioff_ch_enda=0;

         strcpy( str_iagent, "(" );

         for( iTmp=0; iTmp < strlen(iagent) - 1; iTmp++)
         {
             if( iagent[iTmp] == ',')
             {
                 strcat( str_iagent, ",");
             }
             else if( iagent[iTmp] != '\0' && iagent[iTmp] != ' ' )
             {
                 strcat( str_iagent, "'" );

                 sTmp[0] = iagent[iTmp];
                 sTmp[1] = '\0';

                 strcat( str_iagent, sTmp);
                 strcat( str_iagent, "'" );
             }
         }
         strcat( str_iagent, ")" );

         /* �֪@�M��(C18)���O�O���B,��1-2�~�O5000,��3-5�~�O3000,�ä��T�w�C
            �]�����w�]��3000, �D�n��A��X��{�����ެO�_�ŦX�֪@�M�ױ���C
            add by sylvia 103.04.23 */
         if(strncmp(trim(pro_no), "C18",3) == 0)
         {
            mlimit = 3000;
         }
         /* end �֪@(C18)------------------------------------------------ */
         printf("iagent[%s], str_iagent[%s] \n", iagent, str_iagent);

         printf("===== finish get_ca_promote \n");

         return M_CM_OK;
      }
   }

errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(FAIL);
}


long car331_iins11_prem( bipolicy1, ldbgn )
$char bipolicy1[21];
$long ldbgn;
{
   char dyy[4],dmm[3],ddd[3];
   int  code,i;
   double ins_premium , pure_ins_premium , short_prate ;
   double cal_ins_premium , cal_discount , mins_discount , mins_premium;
   $int dyy1, model_year, t_ipro_year;

   $char    A_dbegin[13], drate_ym[5], Fulldbname[20], ibranch_in[3];
   $char    stmt[2048];
   $int     i_drate_ym;

   /* ca_car_model */
   $int     cal_pro_year;
   $double  mcar_price, qpassenger;
   $char    ibrg_rate[3], fuse_type[2] ,icar_series[3];

   /* ca_rate */
   $double  prate_1, rate_prem, pextra_charge;
   $char    ical_ins[3], fcal_class[2];

   $WHENEVER sqlerror goto errexit;

   /** Step 1.1 Ū�� B �������� **/

   printf("Step 1.1 get ipolicy B \n");


   strncpy(ibranch_in, bipolicy1 , 2);
   ibranch_in[2] = '\0';
   strcpy(Fulldbname,get_car_full_db(bipolicy1));

   sprintf_s(stmt, sizeof stmt, "SELECT ibrand, (year(dissue)-1911)||'/'||TO_CHAR(dissue,'%%m'), ipro_year, mcar_price, mdeduct  "
                  " FROM %s:ply_relation a, %s:policy b, %s:ply_ins_type c "
                  "WHERE a.ipolicy = b.ipolicy  "
                  "  AND a.ipolicy = c.ipolicy  "
                  "  AND c.iins_type = '11' AND c.mdamage_cover > 0  "
                  "  AND a.ipolicy = '%s'",
                 Fulldbname, Fulldbname, Fulldbname,bipolicy1);

   printf("stmt = [%s]\n", stmt );
   $PREPARE cur_bx1 from $stmt;
   $EXECUTE cur_bx1 INTO $ibrand, $dissue, $ipro_year, $car_price, $mdeduct;

   if( SQLCODE == SQLNOTFOUND )
   {
       mins_prem11 = 0;
       return M_CM_OK;
   }

   /** Step 1.2 Ū���O�v�ͮĥN�� **/

   $SELECT icode
      INTO $frate
      FROM ca_rate_renew
     WHERE fcard_class = '2'
       AND deffect_bgn <= $ldbgn
       AND deffect_end >= $ldbgn;

   if( SQLCODE == SQLNOTFOUND )
   {
      sprintf_s(msgbuf, sizeof msgbuf,"drate[%d] not in ca_rate_renew ", i_drate_ym);
      EWRITE(userid, M_CA_NRATE_DATE, msgbuf);
      return M_CA_NRATE_DATE;
   }

   printf("in car331_iins11_prem frate[%s] \n", frate );

   short_prate = 1.0;

   /* Step 2.1 SELECT �t�P������ */
   /* �אּ����<ipro_year ���̤j�~��, �A�䤣��~�� >ipro_year ���̤p�~��
         ��: ��J���s�y�~����2014, �Y�d�L2014�~�������, �h���� <2014����1�� (2013), �A�d����h�� >2014����@��(2015)
         modify by sylvia 104.09.15  (1040714001_C3)
      */
   $SELECT mcar_price  ,icar_type    ,fuse_type  ,qpassenger  ,icar_series
      INTO $mcar_price ,$icar_type_1 ,$fuse_type ,$qpassenger ,$icar_series
      FROM ca_car_model
     WHERE ibrand    = $ibrand
       AND ipro_year = $ipro_year
       AND drate     = (SELECT drate
                           FROM ca_rate_date
                          WHERE icode  = $frate
                            AND itable = 'ca_car_model');
    if (SQLCODE==SQLNOTFOUND)
    {
        $DECLARE CA_OPT1_3A CURSOR FOR
          SELECT mcar_price  ,icar_type    ,fuse_type  ,qpassenger  ,icar_series  ,ipro_year
            INTO $mcar_price ,$icar_type_1 ,$fuse_type ,$qpassenger ,$icar_series
            FROM ca_car_model
           WHERE ibrand    = $ibrand
             AND ipro_year < $ipro_year
             AND drate     = (SELECT drate
                                FROM ca_rate_date
                               WHERE icode  = $frate
                                 AND itable = 'ca_car_model')
           ORDER BY ipro_year desc;
        $OPEN  CA_OPT1_3A;
        $FETCH CA_OPT1_3A;
        if (SQLCODE==SQLNOTFOUND)
        {
	        $CLOSE CA_OPT1_3A;
	        $FREE  CA_OPT1_3A;

            $DECLARE CA_OPT3B_305 CURSOR FOR
              SELECT mcar_price  ,icar_type,   fuse_type  ,qpassenger  ,icar_series  ,ipro_year
                INTO $mcar_price ,$icar_type_1,$fuse_type ,$qpassenger ,$icar_series
                FROM ca_car_model
               WHERE ibrand    = $ibrand
                 AND ipro_year > $ipro_year
                 AND drate     = (SELECT drate
                                    FROM ca_rate_date
                                   WHERE icode  = $frate
                                     AND itable = 'ca_car_model')
               ORDER BY ipro_year ;
            $OPEN  CA_OPT3B_305;
            $FETCH CA_OPT3B_305;
            if (SQLCODE==SQLNOTFOUND)
            {
                $CLOSE CA_OPT3B_305;
                $FREE  CA_OPT3B_305;
                sprintf_s(msgbuf, sizeof msgbuf,"ibrand[%s], ipro_year[%s], frate[%s] not in ca_car_model ", ibrand, ipro_year, frate);
                EWRITE(userid, M_CA_NBRAND, msgbuf);
                return M_CA_NBRAND;

            }else{
	            $CLOSE CA_OPT3B_305;
	            $FREE  CA_OPT3B_305;
            }
        }else{
	        $CLOSE CA_OPT1_3A;
	        $FREE  CA_OPT1_3A;
        }
   }

   printf("Step 1 icar_type[%s]\n", icar_type_1);
   /* Step 2.2 check �ۥ���~���O */
   $SELECT fcar_class
      INTO $fcar_class2
      FROM car_type
     WHERE fclass='1'
       AND icode=$icar_type_1;

   /*** STEP 3 check insurance 11 ***/
   /*** STEP 4 ���w�����j���ؤ��@
               ���ѵs�O�v�N������ѵs�I�O�v�N���Y��   ***/

   /* �אּ����<ipro_year ���̤j�~��, �A�䤣��~�� >ipro_year ���̤p�~��
         ��: ��J���s�y�~����2014, �Y�d�L2014�~�������, �h���� <2014����1�� (2013), �A�d����h�� >2014����@��(2015)
         modify by sylvia 104.09.15  (1040714001_C3)
      */
   $SELECT ibrg_rate  , ipro_year
      INTO $ibrg_rate , $cal_pro_year
      FROM ca_car_model
     WHERE ibrand    = $ibrand
       AND ipro_year = $ipro_year
       AND drate     = (SELECT drate
                          FROM ca_rate_date
                         WHERE icode  = $frate
                           AND itable = 'ca_car_model');
   if(SQLCODE==SQLNOTFOUND)
   {
      $DECLARE CA_OPT11 CURSOR FOR
        SELECT ibrg_rate  , ipro_year
          INTO $ibrg_rate , $cal_pro_year
          FROM ca_car_model
         WHERE ibrand    = $ibrand
           AND ipro_year < $ipro_year
           AND drate     = (SELECT drate
                              FROM ca_rate_date
                             WHERE icode  = $frate
                               AND itable = 'ca_car_model')
         ORDER BY ipro_year desc;

      $OPEN  CA_OPT11;
      $FETCH CA_OPT11;
      if (SQLCODE==SQLNOTFOUND)
      {
         $DECLARE CA_OPT11_1 CURSOR FOR
           SELECT ibrg_rate  , ipro_year
             INTO $ibrg_rate , $cal_pro_year
             FROM ca_car_model
            WHERE ibrand    = $ibrand
              AND ipro_year > $ipro_year
              AND drate     = (SELECT drate
                                 FROM ca_rate_date
                                WHERE icode  = $frate
                                  AND itable = 'ca_car_model')
            ORDER BY ipro_year ;

            $OPEN  CA_OPT11_1;
            $FETCH CA_OPT11_1;
            if (SQLCODE==SQLNOTFOUND)
            {
                $CLOSE CA_OPT11_1;
                $FREE  CA_OPT11_1;
                sprintf_s(msgbuf, sizeof msgbuf,"ibrand[%s], ipro_year[%s],frate[%s] not in ca_car_model ", ibrand, ipro_year, frate);
                EWRITE(userid, M_CA_NBRAND, msgbuf);
                return M_CA_NBRAND;
            }else{
               $CLOSE CA_OPT11_1;
               $FREE  CA_OPT11_1;
            }
      }
      $CLOSE CA_OPT11;
      $FREE  CA_OPT11;
   }

   /*** STEP 5 get �ѵs�Y�� ***/
   $DECLARE cur_model CURSOR for
     SELECT ipro_year, pfactor
       FROM car_model_factor
      WHERE fdmg_brg  = '2'
        AND ipro_year = $ipro_year
        AND irate     = $ibrg_rate
        AND drate     = (SELECT drate
                           FROM ca_rate_date
                          WHERE icode  = $frate
                           AND itable = 'car_model_factor')
      ORDER BY ipro_year DESC;
   $OPEN  cur_model;
   $FETCH cur_model INTO $t_ipro_year, $brg_factor;
   $CLOSE cur_model;
   $FREE  cur_model;

   /*** STEP 6 get �򥻫O�O,�p��v,�p���I��,������� ***/
   /*printf("Step 6 icar_type[%s] mdeduct[%d] frate[%s]\n", icar_type_1, mdeduct, frate );  */
   $SELECT prate, mprem, ical_ins, fcal_class, pextra_charge/100
      INTO $prate_1, $rate_prem, $ical_ins, $fcal_class, $pextra_charge
      FROM ca_rate
     WHERE icar_type = $icar_type_1
       AND iins_type = '11'
       AND mdeduct   = $mdeduct
       AND qpt_bgn  <= 0
       AND qpt_end  >= 0
       AND drate     = (SELECT drate
                          FROM ca_rate_date
                         WHERE icode  = $frate
                           AND itable = 'ca_rate');

   if (SQLCODE==SQLNOTFOUND)
   {
       sprintf_s(msgbuf, sizeof msgbuf,"icar_type[%s], mdeduct[%d],frate[%s] not in ca_rate ", icar_type_1, mdeduct, frate);
       EWRITE(userid, M_CA_NRATE, msgbuf);
       return M_CA_NRATE;
   }

   prate_1=prate_1/100.0;

   /*** Step 7 �p��O�O ***/
   /*** Step 7.1  �s�@�ӫO�_�� ***/
   ply2_begin = ldbgn;

   /** Step 7.2 SetCarAge **/
   code = SetCarAge(frate);

   /** Step 7.3 �p��M�I�O�O **/
   {

      adj_age = int_ply_yr - atoi(ipro_year);
      if (adj_age > 4) adj_age = 4;
      /* 102.07.01 */
      /*adj_yr_dep=MyPower(0.75,adj_age);*/
      adj_yr_dep = MyPower(1-pdep_rate_year, adj_age);

      tmp_cover_dep = (int)(car_price*10000.0*adj_yr_dep);
      thousand_cover_dep = tmp_cover_dep % 1000;

      if (thousand_cover_dep != 0)
      {
          cover_dep    = (tmp_cover_dep)-(thousand_cover_dep)+1000;
          cover_dep_11 = tmp_cover_dep - thousand_cover_dep;
      }
      else
      {
          cover_dep    = tmp_cover_dep;
          cover_dep_11 = tmp_cover_dep;
      }

      printf("\n");

      printf("11@@@@@ car_price[%f] brg_factor[%f]\n",car_price,brg_factor);
      printf("11@@@@@ prate_1[%f] short_prate[%f]\n",prate_1,short_prate);
      printf("11@@@@@ cover_01_11[%ld], cover_dep_11[%ld]\n",cover_01_11,cover_dep_11);
      printf("PREM=car_price*prate_1*short_prate*brg_factor\n");
      printf("                      *(cover_01_11/cover_dep_11)\n");

      /* �«O�O(���p���I) */
      ins_premium     = car_price*10000.0*prate_1*short_prate*brg_factor
                        *((double)cover_01_11/(double)cover_dep_11);

   }

   printf("=====ins_premium[%f] \n", ins_premium );

   /** Step 7.4 �p��W���O�O **/
   {
      /* �«O�O(�|�ˤ��J) */
      pure_ins_premium   = (long)(ins_premium+0.5);

      /* �W���O�O(�|�ˤ��J) */
      cal_ins_premium = (long)(dbl_len8(ins_premium)/(1.0-pextra_charge)+0.5);

      printf("�W��ins_premium[%lf]\n",cal_ins_premium);
   }

   /** Step 7.5 �p��������B�Añ��O�O **/
   {
       /*  �������B���w�]�� 0 ���A�X��ɦA�����w�����v
       cal_discount = 0.0;
       mins_discount = (long)( cal_ins_premium*cal_discount/100 + 0.5 ); */

       mins_discount = 0;
       mins_premium = cal_ins_premium - mins_discount;
   }

   mins_prem11 = mins_premium;

   printf("mins_prem11 = [%d]\n", mins_prem11 );

   return M_CM_OK;

errexit:
    printf("error in car6265_iins11_prem \n");
    printf("ERROR CODE = [%d] \n", SQLCODE );
    return SQLCODE;
}

/* 102.07.01 */
/* static int SetCarAge() */
static int SetCarAge(frate2)
char *frate2;
{
    char   dissue_ymd[12];         /* extend CY/MM to CY/MM/DD */
    char   datestring[16], yy[4], mm[3], dd[3], yy2[4], mm2[3];
    int    yy1,mm1,yy3,mm3;
    long   iissue_date;
    $int   count_x=0;
    $double pdepreciate_year = 0.0;
    $char  v_frate2[4];

    $WHENEVER SQLERROR GOTO errexit;

    printf("trace frate2[%s]\n ",frate2);
    strcpy(v_frate2,frate2);

    /*** STEP 7.2 -- a. ; here we calculate car_age, year_dep ...etc.  ***/

    /*** STEP 7.2.1 -- b. ***/
    sprintf_s(dissue_ymd, sizeof dissue_ymd,"%s/01",trim(dissue));
    iissue_date=cm_ymd_cdate(dissue_ymd);
    car_age=DiffMonth(ply2_begin,iissue_date);
    car_age_mth=car_age % 12;

    /** STEP 7.2.2 for flag_new **/
    strcpy(datestring,cm_cdate_str_100(ply2_begin));
    cm_split_ymd_100(datestring,yy,mm,dd);
    yy1=atoi(yy);
    int_ply_yr=yy1+1911; /* int_ply_yr for iins_type 11 */
    mm1=atoi(mm);

    cm_char_split_3ym( dissue, yy2, mm2);
    yy3=atoi(yy2);
    mm3=atoi(mm2);

    /*** STEP 7.2.3 �~���� ***/
	/* 102.07.01, ���o�Ө��ؤ� "�~���²v", ��� car116�]�w*/
	$SELECT a.pdepreciate/100.0 Into $pdepreciate_year
	   FROM depreciation_rate a ,car_type b
	  WHERE a.fcar_class =
	         ( CASE WHEN b.icar_grp = '1' then '3'
	           ELSE b.fcar_class END )
        AND b.fclass = '1' AND b.icode =  $icar_type_1
 	    AND a.qperiod_end = 12
  	    AND a.drate = (SELECT drate FROM ca_rate_date
	                    WHERE itable = 'depreciation_rate' AND icode = $v_frate2 ) ;
	if (SQLCODE==SQLNOTFOUND) return M_CA_NDEPRE_RATE;

	pdep_rate_year = pdepreciate_year;
    year_dep = MyPower(1-pdepreciate_year, car_age/12);
    /*
    if (fcar_class2[0]=='1') * �ۥΨ� *
        year_dep=MyPower(0.75, car_age/12);
    else
        year_dep=MyPower(0.70, car_age/12);
    */
    printf("########## car_age[%d] car_age_mth[%d]\n",car_age,car_age_mth);
    printf("########## fcar_class2[%s] year_dep[%f]\n",fcar_class2,year_dep);

    /*** SETP 7.2.4 ����� ***/

    pdepreciate=0.0;

    /*** SETP 7.2.5 �p��O�I���B�B����«᪺�O�I���B ***/

    printf("########## year_dep[%f] pdepreciate[%f]\n",year_dep,pdepreciate);
    printf("car_price*10000*year_dep*(1-pdepreciate)\n");

    cover_01_tmp = car_price*10000.0*year_dep*(1.0-pdepreciate);
    thousand_cover_01 = cover_01_tmp % 1000;
    if (thousand_cover_01 != 0)
    {
        cover_01 = (cover_01_tmp)-(thousand_cover_01);
        cover_01_11 = cover_01_tmp - thousand_cover_01;
    }
    else
    {
        cover_01 = cover_01_tmp;
        cover_01_11 = cover_01_tmp;
    }
    printf("########## cover_01[%d] cover_01_11[%d]   \n",cover_01, cover_01_11);


    return SUCCESS;

errexit:
	return FAIL;
}
static int DiffMonth(d1,d2)    /* input data should be date format */
long d1, d2;
{
    short mdy1[3], mdy2[3];
    int datediff=0;

    rjulmdy(d1,mdy1);
    rjulmdy(d2,mdy2);
    datediff=(mdy1[2]*12+mdy1[0])-(mdy2[2]*12+mdy2[0]);
    if (datediff<0) datediff=0;
    return datediff;
}

/*****************************************************************/
static float MyPower(f1, i1)
float f1;
int i1;
{
    int i;
    float ff=1.0;

    for (i=0; i<i1; i++)
    {
        ff=ff*f1;
    }
    return ff;
}
/*******************/
double dbl_len8(fulldbl)
double fulldbl;
{

     int chk_flag;
     if (fulldbl < 0)
          chk_flag = 1;
     else
          chk_flag = 0;

     fulldbl = fabs(fulldbl);

     fulldbl = (floor(fulldbl*pow(10,8)))/pow(10,8);

     if (chk_flag == 1)
         return -1 * fulldbl;
     else
         return fulldbl;
}


void car331_put_body4()
{
    strcpy(itag,trim(itag));
    /** �Ĥ@�~��� **/
    rgu_put_body_string(2,iquota,LEFT);
    rgu_put_body_string(2,nchi_full,LEFT);
    rgu_put_body_string(2,iofficer ,LEFT);   /* ���I�N�� */
    rgu_put_body_string(2,nname    ,LEFT);   /* ���I����:A��g��N�����W�� */
    rgu_put_body_string(2,trim(ipolicy),LEFT);
    rgu_put_body_string(2,dply_bgn1,LEFT);
    rgu_put_body_string(2,dply_end1,LEFT);
    rgu_put_body_string(2,trim(dissue_B),LEFT);
    rgu_put_body_string(2,trim(ipro_year_B),LEFT);
    rgu_put_body_string(2,iengine,LEFT);
    rgu_put_body_string(2,itag,LEFT);
    rgu_put_body_string(2,nassured,LEFT);

    printf("mins_premium[%d] pdiscount[%f]\n", mins_premium, pdiscount );

    /** �ĤG�~��� **/
    rgu_put_body_string(2,inext_ply,LEFT);
    rgu_put_body_string(2,icard,LEFT);
    rgu_put_body_string(2,iofficer_B,LEFT);
    rgu_put_body_string(2,dpolicy,LEFT);
    rgu_put_body_string(2,dnext_bgn,LEFT);
    rgu_put_body_string(2,dnext_end,LEFT);
    rfmtdouble(pdiscount, "-###&.###", tmp_buf);
    rgu_put_body_string(2,tmp_buf,LEFT);
    printf("disc  tmp_buf[%s]\n", tmp_buf );

    rfmtlong(mins_premium, "---------&", tmp_buf);
    rgu_put_body_string(2,tmp_buf,LEFT);
    printf("mins  tmp_buf[%s]\n", tmp_buf);
    rgu_put_body_string(2,dpayB,LEFT);

    /** A���� **/
    rgu_put_body_string(2,ipolicy_A,LEFT);
    rgu_put_body_string(2,dpay,LEFT);
    rfmtlong(mins_premium_A, "---------&", tmp_buf);
    rgu_put_body_string(2,tmp_buf,LEFT);
    rgu_put_body_string(2,fSend,LEFT);
    rgu_put_body_string(2,iestimate_B,LEFT);
    rgu_put_body_string(2,fmail_to,LEFT);
    rgu_put_body_string(2,nequipment_90,LEFT);
    rgu_put_body_string(2,sIbig_sales,LEFT);
    rgu_put_body_string(2,sales_name,LEFT);
    rgu_put_body(2);

    max_cnt += 1;

}


/* 980520, load �n�O�H��� */
int load_iapp_data(){

	char data_file[20] = "";
	char sApHome[31]   = "";
	int  rc            = 0 ;
	char path_DataFile[80] = "";
	char syscmd[100]   = "";

	$WHENEVER sqlerror goto errexit;

	strcpy(data_file,"ca331_iapp.txt"); /* check ca331_iapp.txt �O�_�s�b */

    rc = getApHome(sApHome);
    if (rc < 0)
    {
        printf("read Config file error!!\n");
        return M_CM_READ_CONFIG_ERR;
    }
     sprintf_s(path_DataFile, sizeof path_DataFile,"%s/exec/%s", sApHome,data_file);
 	 printf("path_DataFile=[%s]\n",path_DataFile);
     sprintf_s(syscmd, sizeof syscmd,"ls %s", path_DataFile);
	 rc = system(syscmd);
	 printf("check file >>%s (rc code=[%d])\n",syscmd,rc);

	 if (rc!=0){
	 	 printf("The file %s does not exist!\n",path_DataFile);
	     return M_CM_READ_CONFIG_ERR	;
	 }

	 $CREATE TEMP TABLE iapp_data
	 (
	     iofficer             char(10),
	  /*   ibig_office         char(10) default '',*/
	     iapplicant          char(12)  default '',
	     napplicant          char(120) default ''
	 ) WITH NO LOG;

	/* $CREATE INDEX iapp_data_ix1 ON iapp_data( iofficer,ibig_office );*/
	 $CREATE INDEX iapp_data_ix1 ON iapp_data( iofficer);
	 printf("\nLoading ca331_iapp.txt to iapp_data .....\n");

	/*---------Load iapp_data.txt to iapp_data -------------------------*/
	if ((rc=load_command(path_DataFile,outputf,"iapp_data")) != SUCCESS){
    	printf("Loading File fail , rc[%d]\n",rc);
    	return rc;
	}
	printf("Loading ca331_iapp.txt to iapp_data Complete!!\n");
    return M_CM_OK;

errexit:
    printf("error in load_iapp_data() \n");
    printf("ERROR CODE = [%d] \n", SQLCODE );
    return SQLCODE;
}


