/*--------------------------------------------------------------------*/
/*   PROGRAM ID    : ca616q01s.ec                                     */
/*   PROGRAM NAME  : ���بT�������X�[�ɵP�ӧ@�~                     */
/*   AUTHOR        : Jessie                                           */
/*   DATE WRITTEN  : 2002/02/28                                       */
/*   MODIFY        : Jessie                                           */
/*   DATE MODIFY   : 2003/10/06�ɵP�ӥu��s�̷s�O����,�W�[�H�Ҹ��ɸ��*/
/*                   2005/09/15���ױƵ{�אּ�C�g�G��                   */
/*                   2005/11/03���קאּ�C�����                       */
/*                   2008/07/18�P�ӧאּ�������覡�ɵn           */
/*                   2011/03/03��O�ɨ��P�ư����P�� by Jessie         */
/*   MODIFY OPTION : statement                                        */
/*   FILES         : ply_relation        i                            */
/*                   policy              io                           */
/*                   ca_080_updtag       io                           */
/*                 ( ncar013_na          io �w���ϥ�                  */
/*                   ncar005_m           o                            */
/*                   ncar005_d           o )                          */
/*  TEMP FILES     : car616              io                           */
/*                   car616_1            io                           */
/*  Runbatch�g�k   : runbatch 00 703552 car616 P 4 '7' '99/04/13' '99/04/13' 'Y'	*/
/*--------------------------------------------------------------------*/
#include <stdio.h>
#include <ca401field.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include <string.h>
#include "api_xsrv.h"
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
$include sqltypes;
$include datetime;
#define False                 0
#define LOAD_FAIL            -1
#include "safeclib.h"
/*--------------------------------------------------------------------*/
$char    type[1];
$char    dbgn1[11],dend1[11],dbgn2[11],dend2[11],dbgn3[17],dend3[17];
$char    fbig_office[2];
$int     id1 = 0,id2 = 0,qcount = 0,ply_cnt,dtl_cnt = 0;
int      itype;
char     errmsg[200];
char     sysEd[11],sysTm[9];
long     sysdt;

DBinfo   *list;
int      count_db,i,rc;
char     msgbuf[1024];

int      flen,cnt,cnt_1,cnt_2;
int      cnt_p,cnt_i,cnt_c;
FILE     *fp,*fp1,*fp2,*fp3,*fp4;
FILE     *fp_sym, *fp_sym1;
char     sApHome[30];
$char    fname[21];
char     filename[50],filename1[50],filename2[50],filename3[50],filename4[50];
char     file_sym[50], file_sym1[50];
$char    DBName[5], iForm_Tp[3];
$char    full_dbname[20];
char     BodyFile[ N_FILE+1];
char     TitleFile[ N_FILE+1];
char     outputf[N_FILE+1], userid[11];
char     pgid[11];

$int     ItemRow, TotColumn;
$int     StartRow,TitleRow;
$int     PgLine, Width;

int  max_cnt;

$char stmt_tmp1[1024],stmt_tmp2[1024];
static int   recLen=1024;
static char  *bp;
char  delimiter;
int   offset = 0;

/* for�P�Ӿ���� */
FILE   *sfp, *report, *report1;
char   sMsg[10240];

static char *get_car_full_db();

double d45();

/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{    
    batchinit();
    strcpy(DBName, isNULLstr(argv[1]));
    strcpy(userid, isNULLstr(argv[2]));
    strcpy(type, isNULLstr(argv[3]));
    strcpy(dbgn2, isNULLstr(argv[4]));
    strcpy(dend2, isNULLstr(argv[5]));
    /* fbig_office = N(��ƨӷ���car616), Y(��ƨӷ����ζ�), H(��ƨӷ�������) */
    strcpy(fbig_office, isNULLstr(argv[6])); 
    strcpy(outputf, isNULLstr(argv[7]));

    strcpy(dbgn1, cm_to_infdate(dbgn2));
    strcpy(dend1, cm_to_infdate(dend2));
    
printf("*************************\n");
printf("bgn1[%s],dend1[%s],dbgn2[%s],dend2[%s]\n",dbgn1,dend1,dbgn2,dend2);

   
    rc=car616_get_db();
    if ( rc != M_CM_OK) return rc;

    sysdt=cm_today();
    strcpy(sysEd,cm_edate_str(sysdt));
    strcpy(sysTm,substring(sysEd,7,4));
    strncat(sysTm,sysEd,2);
    strncat(sysTm,sysEd+3,2);    

    strcpy(pgid,"car616");
printf("type:[%s],fbig_office[%s] \n",type,fbig_office);
    itype=atoi(type);

    switch(itype){
        case 1:                                     /* �������X��X */
           rc=car616_unload_engine();
           if ( rc != M_CM_OK) return rc;
           break;
        case 2: case 6:                             /* ����郞�P�� 2=>������, 6=> �j��d�� */     
           /* ���M����� */
           $DELETE FROM ca_fill_itag WHERE 1=1;
           WRITELOG( sfp, "DELETE FROM ca_fill_itag Complete !!");

           $BEGIN WORK;
           rc = car616_update_tag(); /* �NClient�ݪ����insert into ca_fill_itag,�Aselect �X�ӧ�P�� */
           if (rc == LOAD_FAIL); /* �p�G�O load data ���~���� commit work�]���|�g�Jrptftpinsert���i�H
                               rollback work,���Mcmn202�|�䤣����~log�� */
           else if (rc != M_CM_OK)
           {
                $ROllBACK WORK;
                EWRITE(userid, rc, sMsg);
                return rc;
           }
           $COMMIT WORK;                                         
           break;   

        case 3: /*1111212004_SC1 �w��L�q���w��P��ƶǿ�{���ݨD�G�u�L�q���v�j���I���(��)���P ( + �O�I�_���B�o�Ӥ��)*/

           $BEGIN WORK; 
           $DELETE FROM ca_fill_itag WHERE 1=1; 
           rc = car616_get_TVMETPxx();              /* �NClient�ݪ����insert into ca_fill_itag */
           if (rc != M_CM_OK)
           {
               $ROllBACK WORK;
               EWRITE(userid, rc, "car616_get_TVMETPxx() != M_CM_OK");
               return rc;
           }
           $COMMIT WORK;

           $BEGIN WORK;
           rc = car616_update_tag();               /* �NClient�ݪ����insert into ca_fill_itag,�Aselect �X�ӧ�P�� */
           if (rc == LOAD_FAIL);                   /* �p�G�O load data ���~���� commit work�]���|�g�Jrptftpinsert���i�H
                                                       rollback work,���Mcmn202�|�䤣����~log�� */
           else if (rc != M_CM_OK)
           {
                $ROllBACK WORK;
                EWRITE(userid, rc, sMsg);
                return rc;
           }
           $COMMIT WORK;                                         

           break;

        /*case 3:                                     /* �����T(�ثe����) */
           /*rc=car616_tradevan(DBName,userid,errmsg,outputf,pgid);
           if ( rc != M_CM_OK) return rc;
           sprintf_s(msgbuf, sizeof msgbuf,"%s%s",msgbuf,errmsg);*/
           /********
           rc=car616_080memo();
           if ( rc != M_CM_OK) return rc;
           ********/
           /*EWRITE(userid,rc,msgbuf);
           break;*/
        case 4:                                    /* ��O�����X�H�ΥX��� */
           $DELETE FROM ca_fill_itag WHERE 1=1;
           WRITELOG( sfp, "DELETE FROM ca_fill_itag Complete !!");
           
           rc = car616_get_renew();                /* �N��諸���insert into ca_fill_itag */
           if (rc != M_CM_OK) return rc;
           
           $BEGIN WORK;
           rc = car616_update_tag();               /* �NClient�ݪ����insert into ca_fill_itag,�Aselect �X�ӧ�P�� */
           if (rc == LOAD_FAIL);                   /* �p�G�O load data ���~���� commit work�]���|�g�Jrptftpinsert���i�H
                                                      rollback work,���Mcmn202�|�䤣����~log�� */
           else if (rc != M_CM_OK)
           {
                $ROllBACK WORK;
                EWRITE(userid, rc, sMsg);
                return rc;
           }
           $COMMIT WORK;                                         
           break;
                       
        case 5:                                     /* �ӫO�z�߸����X */
           rc=car616_unload_fmc();
           if ( rc != M_CM_OK) return rc;
           break;
        /*case 6:
           rc=car616_update_by_card();
           if ( rc != M_CM_OK) return rc;
           rc=car616_tradevan(DBName,userid,errmsg,outputf,pgid);
           if ( rc != M_CM_OK) return rc;
           sprintf_s(msgbuf, sizeof msgbuf,"%s%s",msgbuf,errmsg); 
           EWRITE(userid,rc,msgbuf);
           break;
           /*******************************************/
           /* ���q�b�|���ק�ݨDcar9701043�ɴN�w�g���ѤF
              rc=car616_080memo();
              if ( rc != M_CM_OK) return rc; */ 
           /*******************************************/                     
        case 7:
           /* [�Ƶ{�ϥ�]���ױM�ݰ���ɵP��--�t�αƵ{,��J���ɮצW�٤��P */
           rc=car616_updtag_fmc();
           if ( rc != M_CM_OK) return rc;
           EWRITE(userid,rc,msgbuf);
           break;
        case 8:
           /* [�Ƶ{�ϥ�]���ױM�ݰ���ɵP��--�t���Ͷǰe���T�ɮ� */
           rc=car616_updtag_fmc();
           if ( rc != M_CM_OK) return rc;
           strcpy(pgid,"���׸ɵP��");
           /* �]���ɵn�P�Ӥ@�ߨϥξ��X���,�ҥH���T��Ƥ��q������-car9701043 */
           /*rc=car616_tradevan(DBName,userid,errmsg,outputf,pgid);
           if ( rc != M_CM_OK) return rc;
           sprintf_s(msgbuf, sizeof msgbuf,"%s%s",msgbuf,errmsg);*/
           EWRITE(userid,rc,msgbuf);
           break;
        case 9:
           /* [�Ƶ{�ϥ�]���ײ����ɮש� rptftp/fmc */
           rc=car616_unload_fmc();
           if ( rc != M_CM_OK) return rc;
           break;
    }
    /*return rc;*/
    
     if (rc != M_CM_OK)
     { 
        EWRITE(userid, rc, sMsg);
        return rc;
     }

     WRITELOG( sfp, sMsg);
     ENDLOG(sfp);
     return M_CM_OK;

errexit:
    printf("------car616_err: SQLCODE[%d]\n",SQLCODE);
    EWRITE(userid, SQLCODE,sqlca.sqlerrm);
    exit(1);
}

/*--------------------------------------------------------------------*/
long car616_get_db()
{
    int rc;
    $whenever sqlerror goto errexit;
    
    sfp =  (FILE *)STARTLOG();

    if (db_select(DBName) == FALSE)
    {
        EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
        return M_CM_DB_NOTOPEN;
    }
    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }
    if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
    {
       EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
       return M_CM_NOT_DBLIST;
    }

    return M_CM_OK;
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;  
}

/******************************************************************************************/
void GetData(data, maxlen, delimiter)
char *data, delimiter;
int maxlen;
{
int fori, pre_offset, cnt=0;

    data[0]='\0';
    pre_offset = offset;

    for (fori=pre_offset; bp[fori]!=0x00&&bp[fori]!=0x0d&&bp[fori]!=0x0a&&bp[fori]!=delimiter; fori++)
    {
        offset++;
        if (cnt < maxlen-1)
        {
            data[cnt]=bp[fori];
            cnt++;
        }
    }

    offset++; /* ���ܤU�@�� */
    if (cnt==0) data[cnt++]=0x20; /* �L��Ƶ��ť� */
    data[cnt]=0x00;
    /*printf("data[%s]\n",data);*/
}
/*--------------------------------------------------------------------*/
long car616_unload_engine()
{
    int    rc;
    $char  stmt[1024];
    $char  fcard_class[2],iengine[CA_ENGINE_NUM];

    $whenever sqlerror goto errexit;

    sprintf_s(filename, sizeof filename,"%s/rptftp/car616_eng.txt",sApHome);
    fp=fopen(filename,"w");

    cnt=cnt_1=cnt_2=0;
    for (i=0;i<count_db;i++) {
        sprintf_s(stmt, sizeof stmt,
                "select a.fcard_class,b.iengine  "
                "  from %s:ply_relation a,%s:policy b  "
                " where a.dpolicy >= ?  "
                "   and a.dpolicy <= ?  "
                "   and a.iofficer[1] = 'B'  "
                "   and a.ipolicy = b.ipolicy  "
                "   and (b.itag = ' ' or b.itag is null)",
                 list[i].dbname,list[i].dbname);
        $prepare pre_1 from $stmt;
        $declare cur_1 cursor for pre_1;
        $open    cur_1 using $dbgn1, $dend1;
        while(1) {
            $fetch cur_1 into $fcard_class,$iengine;
            if (SQLCODE==SQLNOTFOUND) break;
            cnt++;
            if (strncmp(fcard_class,"1",1)==0)
                cnt_1++;
            else
                cnt_2++;
            printf("iengine[%s]\n",iengine);
            fprintf(fp,"%s\t\n",iengine);
        }
        $close cur_1;
        $free  cur_1;
    }
    fclose(fp);
    rc=rptftpinsert(userid,"car616","car616_eng.txt");
    if (rc!=0) {
        EWRITE(userid,rc,"�g�Jrptftplist���~");
        return rc;
    }

    sprintf_s(msgbuf, sizeof msgbuf,"��X�������X�@[%d]��,�j��[%d]��,���N[%d]��",
            cnt,cnt_1,cnt_2);
    EWRITE(userid,M_CM_OK,msgbuf);
    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;  
}

/*--------------------------------------------------------------------*/
long car616_update_tag()
{
   $char sIpolicy[21], sItag[CA_TAG_NUM], itag[CA_TAG_NUM]; /* client�ݱNuser���Ѫ�����諸����� */    
   $char iendorse[21], key_value[21], db_keyvalue[CA_ENGINE_NUM], iedr_field[9];
   char  payresult[5], paystatus[100], paydate[100], notedate[100];
   char  policy_1[POLICY_NUM_1],policy_2[POLICY_NUM_2];
   char   sIcomp_in[BRANCH_ID], sIbranch_in[BRANCH_ID];
   char   sIbranchIcomp[CA_POL_BRH_NUM], sIbilling[3];   
   $char ibatch_no[11], iquota[11], ileader[11], iofficer[11];
   $char fcard_class[2],icar_type[3],iroute[21], iofficer_prmt[11];
   $char iroute_off[21],ibig_office[10];
   $long tmp_cnt=0,tot_prem=0;
   
   int   iCount, iTmp, rc1;
   char  FullGetName[101], FullLogName[101], FullRptName[101];
   char  GetName[51], LogName[51], RptName[51], TmpName[51];
   char  sIupcompShort[2], policyDB[21], policyDBname[41];
   char  sIupcompShortNext[2], policyDBNext[21], policyDBnameNext[41];
   char  local_dbname[41];
   $char stmt[10240], stmt1[2048], cmd_stmt[20480], datetime[12];
   $char fedr_class[2], inext_ply[21];
   $char fassured_next[2], fcomp_class_next[3];
   long  tt, code;
   $long dwritten, dissue;
   char  v_sMsg[512],err_sMsg[512];     
   $char dlock[31],iroute_accept_edr[21];
   $char  feply[2]=" ",tmobile_eply[21]=" ",aemail_eply[51]=" "; /*1090831006_SC2 �{�ҥ��x�j��q�l���ҥ���g�����mail�ˮ�*/
   $char  tmobile_appl[21]=" ",aemail_appl[51]=" ",s_notifyornot[21]="";
   $char sIcard[21],sIpro_year[5];
   $datetime year to second dnotifyornot;   
   $long dply_begin = 0,dply_end,lngDply_begin = 0,lngDissue = 0,dply_begin_ym = 0,dpro_ym = 0,dpro_202212 = 0;
   $int  qpro_month = 0;
     int iEdr;


    $WHENEVER SQLERROR GOTO errexit;        

    strcpy(local_dbname, get_full_dbname(DBName));
    
    $select first 1 current month to minute
       into $datetime
       from system_var;

    /* client�ݱNuser���Ѫ�����諸�����ftp��/dat/car/car616_t.txt */
    sprintf_s(GetName, sizeof GetName, "car616_t.txt");
    sprintf_s(LogName, sizeof LogName, "car616_load_err_%s.txt", outputf);
    sprintf_s(RptName, sizeof RptName, "car616_report.body", outputf);
    sprintf_s(FullGetName, sizeof FullGetName, "%s/dat/car/%s", sApHome, GetName); 
    sprintf_s(FullLogName, sizeof FullLogName, "%s/rptftp/%s", sApHome, LogName);
    sprintf_s(FullRptName, sizeof FullRptName, "%s/rptftp/%s", sApHome, RptName);
    
    if ((report=fopen(FullRptName,"w"))==NULL)
    {
        sprintf_s(sMsg, sizeof sMsg, "Cannot open Ouput file: %s\n", FullRptName);
        printf("%s", sMsg);
        return M_CM_OPEN_FILE_FAIL;
    }
    printf("what's itype [%d]\n",itype);    

    /*1111212004_SC1 �w��L�q���w��P��ƶǿ�{���ݨD*/
    /* car9610162 �Y�ﶵ��4���𶷱qcar616_t.txt�ˤJ��Ʀ�ca_fill_itag */
    if (itype == 4 || itype == 3)
    { 
    	/* �]��car616_get_renew()�w�N��Ƽg�Jca_fill_itag,�G�L��Ū��car616_t.txt */
    } 
    else
    {
        printf("FullGetName[%s]\n", FullGetName);
        
        sprintf_s(stmt, sizeof stmt, "load from %s delimiter '\t' \r\n "
                       "insert into ca_fill_itag(key_field,itag); \r\n", FullGetName);
        sprintf_s(cmd_stmt, sizeof cmd_stmt,"dbaccess %s > %s 2>&1 << !\r\n" 
                          "%s\r\n!", local_dbname, FullLogName, stmt);
	 
        printf("cmd_stmt[%s]\n",cmd_stmt);

        rc = system(cmd_stmt);

        if (rc != 0) {
            sprintf_s(sMsg, sizeof sMsg, "���J������Ƶo�Ϳ��~\r\n "
                            "���I���ɮפU���@�~�d��[Q],�ɦW:[%s]�T�w���~��]", LogName);
            printf("sMsg[%s]\n", sMsg);
            rc1=rptftpinsert(userid,"car616", LogName);
            printf("rc1[%d]\n", rc1);
            if (rc1!=0) 
            {
                sprintf_s(sMsg, sizeof sMsg,"%s�g�Jrptftplist���~\r\n", LogName);
                return LOAD_FAIL;
            }

            return LOAD_FAIL;
        }

         sprintf_s(sMsg, sizeof sMsg, "Loading %s to ca_fill_itag Complete!!\n", FullGetName);  
         printf ("sMsg[%s]\n", sMsg);
         WRITELOG( sfp, sMsg);
     } /* end of car9610162 */
	
    /* -------------------------------------------------------*/
    /* �}�l�X��� */
    /* ���o���椧�t�Τ�� */
    rtoday(&dwritten);

    memset (&iedr_field, 0, sizeof (iedr_field));

    for( iTmp = 0; iTmp < 8; iTmp++)
        FLD_SET ( iedr_field, iTmp*8 + 7);


    iCount = 0;    

    $DECLARE curs1 CURSOR FOR 
       SELECT key_field,itag, dply_begin, dissue, icard
         FROM ca_fill_itag;
         
    $OPEN curs1;
    for(;;)
    {
         $FETCH curs1 INTO $key_value, $sItag, $lngDply_begin, $lngDissue, $sIcard;
                              
         if (SQLCODE == SQLNOTFOUND) break;   
         
         strcpy(stmt1,""); 
         strcpy(stmt,""); 
         strcpy(sIpolicy,""); 
         strcpy(key_value, rtrim(key_value));
         /* �ھ�itype��X�o�������O�H�������٬O�O�d������key�� */
         if (itype == 2)
         {
           $SELECT max(ipolicy) INTO $sIpolicy FROM assured_vs_ply
             WHERE iengine = $key_value
               AND (itag IS NULL OR itag = '');
           strcpy(stmt1," SELECT b.iengine ");
         } 
         else if (itype == 3)  /*1111212004_SC1 �w��L�q���w��P��ƶǿ�{���ݨD*/
         {
            $SELECT max(ipolicy) INTO $sIpolicy FROM assured_vs_ply
              WHERE ibody = $key_value ;
                /*AND (itag IS NULL OR itag = '');*/
            strcpy(stmt1," SELECT b.ibody ");
         }
         else
         {
         	$SELECT max(ipolicy) INTO $sIpolicy FROM assured_vs_ply
             WHERE icard = $key_value;
            strcpy(stmt1," SELECT a.icard ");
         }                  
           
         printf("assured_vs_ply ���,ipolicy[%s],key_value[%s]\n",sIpolicy,key_value); 

         if ((SQLCODE == SQLNOTFOUND) || (sIpolicy[0] == '\0' || sIpolicy[0] == ' '))
         {         	 
         	 sprintf_s(sMsg, sizeof sMsg, "%s\t%s\t%s\t%s\t%s\t%s\t%s\t", key_value, " ", " "," ", " ", " ", " ");
             if (itype != 3) 
             {
                 strcat( sMsg, "�O���Ƨ䤣��(assured_vs_ply)�άO���P�w�s�b" ); 
             }
             else
             {
                 strcat( sMsg, "�O���Ƨ䤣��(assured_vs_ply)" );
             }
             
             fprintf( report, "%s\n", sMsg);
             continue;
         }       
         
         /* �ݥX�j����N�U�@�i,�@��i���ɨ��� */
         for (i=0;i<2;i++)
         {
              iEdr = 0;   /* 0:�u�娮�P ; 1:�娮�P + �O�I�_���B�o�Ӥ�� ; 2:�u��O�I�_���B�o�Ӥ�� */

              /* �p�G����ĤG��,�N�N���n�h�����p�O�檺�O�渹 */
              strcpy(stmt," ");
              strcpy(inext_ply,"");
              strcpy(fassured_next,"");
              strcpy(fcomp_class_next,"");
              if (i==1)
              { 
              		sprintf_s(stmt, sizeof stmt, "SELECT irelative_ply  "
                        "  FROM %s:ply_relation  "
                        " WHERE ipolicy = '%s' ", policyDBname,  sIpolicy);
                        
                  $PREPARE prep_rel FROM $stmt;
                  $EXECUTE prep_rel INTO $sIpolicy;
                  
                  if (sIpolicy[0] == '\0' || sIpolicy[0] == ' ') break;
               }
               sIupcompShort[0] = sIpolicy[2]; /* �O�渹�ĤT�X */
               sIupcompShort[1] = '\0';
               strcpy( policyDB, get_upcomp(sIupcompShort, USE_SHORT_BRANCH_ID, USE_BRANCH_ID));
               strcpy( policyDBname, get_full_dbname(policyDB));                              

               printf("i=[%d],user��client�ݴ��Ѥ��O�渹[%s][%s]\n",i, sIpolicy, policyDBname);

               tot_prem=0; 
               sprintf_s(stmt, sizeof stmt, "%s, b.itag, a.iofficer, a.fcard_class, a.icar_type, b.iroute, a.iofficer_prmt, a.ibig_office, a.fedr_class, a.inext_ply, b.dissue, a.dlock ,  "
                        " (SELECT sum(mdamage_cover)::integer FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy ) , "
                        " a.feply , a.tmobile_eply , a.aemail_eply , b.tmobile_appl , b.aemail_appl, a.dply_begin,a.dply_end, b.qpro_month,a.ipro_year, " 
                        " mdy(month(a.dply_begin) , 15 , year(a.dply_begin)), CASE WHEN b.qpro_month>0 then mdy(b.qpro_month,15,a.ipro_year) ELSE mdy(1,1,1971) END,mdy(12,15,2022) "
                        "  FROM %s:ply_relation a, %s:policy b  "
                        " WHERE a.ipolicy = b.ipolicy  "
                        "   AND a.dply_close is NOT NULL  "
                        "   AND a.ipolicy = '%s' ", stmt1, policyDBname, policyDBname, policyDBname, sIpolicy);

               $PREPARE prep1 FROM $stmt;
               $EXECUTE prep1 INTO $db_keyvalue, $itag, $iofficer, $fcard_class, $icar_type, $iroute, $iofficer_prmt, $ibig_office,$fedr_class,
                                   $inext_ply, $dissue, $dlock, $tot_prem,
                                   $feply , $tmobile_eply , $aemail_eply , $tmobile_appl , $aemail_appl,
                                   $dply_begin, $dply_end, $qpro_month, $sIpro_year, $dply_begin_ym, $dpro_ym, $dpro_202212;
               code = SQLCODE; 
               printf("db_keyvalue [%s]\n", db_keyvalue);

               if( strlen( trim(inext_ply)) !=0)
               {
                   sIupcompShortNext[0] = inext_ply[2]; /* ��O�渹�ĤT�X */
                   sIupcompShortNext[1] = '\0';
                   strcpy( policyDBNext, get_upcomp(sIupcompShortNext, USE_SHORT_BRANCH_ID, USE_BRANCH_ID));
                   strcpy( policyDBnameNext, get_full_dbname(policyDBNext));                              

                   sprintf_s(stmt, sizeof stmt, "SELECT b.fassured, a.fcomp_class from %s:ply_relation a, %s:policy b  "
                                  " where a.ipolicy = b.ipolicy and a.ipolicy = '%s'", policyDBnameNext, policyDBnameNext, inext_ply);

                   $PREPARE prep7 FROM $stmt;
                   $EXECUTE prep7 INTO $fassured_next, $fcomp_class_next;
               }
               sprintf_s(sMsg, sizeof sMsg, "%s\t%s\t%s\t%s\t%s\t%s\t%s\t", key_value, sItag, sIpolicy, fassured_next, inext_ply, fcomp_class_next, " ");

               if (code == SQLNOTFOUND)
               {
                   strcat( sMsg, "�O���Ƨ䤣��Υ��鵲,�нT�{�O�渹�O�_���T" );
                   fprintf( report, "%s\n", sMsg);
                   continue;
               }
               /* db_keyvalue�i�ରiengine or icard, ��itype�M�w */
               strcpy(iendorse, " "); 	
               
               if( strlen(trim(dlock)) != 0 ) /* ���O��B2C��襤�A�ȮɵL�k��� */
               {
                   strcat( sMsg, "���O��B2C��襤�A�ȮɵL�k���" );
                   fprintf( report, "%s\n", sMsg);
                   continue;
	           }              

               /* �ھګO�渹��X����,�ˮֵP�ӥ��T�� */                   
               strcpy(sItag, trim(sItag));
               printf("Client�ݴ��Ѥ� sItag [%s]\n", sItag);  
               strcpy(db_keyvalue, rtrim(db_keyvalue));
               strcpy(err_sMsg, " ");  /* 111.12 fix */
               rc = ca_checkCarNo(sItag, icar_type, &dissue, err_sMsg);
        	   if( rc != M_CM_OK) 
        	   {        
                   strcat( sMsg, err_sMsg);
                   fprintf( report, "%s\n", sMsg);
                   continue;               
               }       

               if (itype == 2 && strcmp( key_value, db_keyvalue) != 0)         
               {
                   strcat( sMsg, "�z���Ѫ��������P�̷s�O�椣�P,������,�нT�{" );
                   fprintf( report, "%s\n", sMsg);
                   continue;
               }
               if (fcard_class[0] == '1' && itype == 6 && strcmp(key_value, db_keyvalue) != 0)
               {
                   strcat( sMsg, "�z���Ѫ��O�d���P�̷s�O�椣�P,������,�нT�{" );
                   fprintf( report, "%s\n", sMsg);
                   continue;
               }

               /*1111212004_SC1 �w��L�q���w��P��ƶǿ�{���ݨD*/  
               if (itype == 3)
               {           
                        
                   if (strncmp(icar_type,"35", 2) != 0)
                   {
                       strcat( sMsg, "�̷s�O��D35����,������,�нT�{" );
                       fprintf( report, "%s\n", sMsg);
                       continue;
                   }

                   if (strcmp(key_value, db_keyvalue) != 0)
                   {
                       strcat( sMsg, "�z���Ѫ����[���X�P�̷s�O�椣�P,������,�нT�{" );
                       fprintf( report, "%s\n", sMsg);
                       continue;
                   }

                   /* �j���I�ŦX�H�U���󶷧��O�I�_���B�o�Ӥ��  
                        1.�O�o��P��ڷs�w�̷s�O��ͮĤ� =>�¨�(�o�̤w�g���L�O�o��ƤF)
                        2.�s�w�s�y�~��ڷs�w�̷s�O��ͮĤ� =>�¨�
                        3.�s�y���<111.12 =>�¨�
                   */
                   if (fcard_class[0] == '1')
                   {
                        printf("lngDissue     [%ld]\n", lngDissue);
                        printf("dissue        [%ld]\n", dissue);
                        printf("dply_begin    [%ld]\n", dply_begin);
                        printf("dply_end      [%ld]\n", dply_end);
                        printf("qpro_month    [%ld]\n", qpro_month);
                        printf("dpro_ym       [%ld]\n", dpro_ym);
                        printf("dply_begin_ym [%ld]\n", dply_begin_ym);
                        printf("dpro_202212   [%ld]\n", dpro_202212);

                        if (lngDissue != dply_begin) /* ���T���Ѥ���P��� �� �̷s�O��ͮĤ�� */
                        {
                            if (qpro_month > 0) 
                            {
                                /* �̷s�O�椧�s�y�~�� �� �̷s�O�椧�O��ͮĦ~�� �B �̷s�O�椧�s�y�~�� < 111.12*/
                                if ((dpro_ym != dply_begin_ym) && (dpro_ym < dpro_202212))
                                {                                    
                                    iEdr = 1;  /*���O�I�_���B�o�Ӥ�� �Ψ��P(�p�G���P����)*/

                                    dply_end   = dply_end   + (lngDissue - dply_begin);
                                    dply_begin = lngDissue;
                                    dissue     = lngDissue ;

                                    printf("(dply_begin - lngDissue)[%ld]\n", (dply_begin - lngDissue)); 
                                    printf("dply_end   [%ld]\n", dply_end);
                                    printf("dply_begin [%ld]\n", dply_begin);
                                    printf("dissue     [%ld]\n", dissue);
                                }
                            }
                            else
                            {
                                strcat( sMsg, "�̷s�O��u�s�y����v�� 0 ,������,�нT�{" );
                                fprintf( report, "%s\n", sMsg);
                                continue;
                            }
                        }
                   }
               }

               printf("iEdr 1 [%d]\n", iEdr);  
               
               if(itag[0] != '\0' && itag[0] != ' ')  /*�̷s�O���Ƥ� ���P�Y������*/
               {
                   printf("�̷s�O�� itag [%s]\n", itag);  
                   /* 0:�u�娮�P ; 1:�娮�P + �O�I�_���B�o�Ӥ�� ; 2:�u��O�I�_���B�o�Ӥ�� */

                   if (iEdr == 0)  /* ���P�Y�����šA�B�ӵ��u�娮�P�ɡA�h����� */
                   {
                       strcat( sMsg, "�ӫO�檺�̷s�O���Ƥ��w������,������,�нT�{" );  
                       fprintf( report, "%s\n", sMsg);
                       continue;

                   }
                   else 
                   {
                       if (iEdr == 1) /* ��w�]�n���P�Y�����šA�B�ӵ��P�ɭn���O�I�_���B�o�Ӥ�� �ɡA�h�n�~���� �O�I�_���B�o�Ӥ�� */
                       {
                           iEdr = 2;  /* �אּ�u��� �O�I�_���B�o�Ӥ�� */
                           strcpy(sItag, itag); /* ���娮�P => �N���P������̷s�O�樮�P */
                       }

                   }                   
               }  
               printf("iEdr 2 [%d]\n", iEdr);  

               if(fedr_class[0] == '1') 
               {
                   strcat( sMsg, "�ӫO��w���P,������,�нT�{" );  
                   fprintf( report, "%s\n", sMsg);
                   continue;
               }  

               /* 1071027001_C1�]���q�l���ҤW�u�A�u�n�j��O��h�O�Y���i��CAR616�ɨ��P */
               if (tot_prem==0)
               {
                   strcat( sMsg, "���O��w�h�O,������,�нT�{" );
                   fprintf( report, "%s\n", sMsg);
                   continue;   
               }

               strncpy(sIbranchIcomp, sIpolicy, CA_POL_BRH_NUM - 1);
               sIbranchIcomp[CA_POL_BRH_NUM - 1] = '\0';

               /* get ����k�ݤ�����c & �����q*/
               rc = cm_get_unit_in("", policyDB, userid, sIbranchIcomp, "C1", sIcomp_in, sIbranch_in);
               if ( rc != M_CM_OK)
               {
                   strcat( sMsg, "����k�ݤ�����c & �����q�䤣��");
                   fprintf( report, "%s\n", sMsg);
                   continue;
               }

               /* check ����k�ݤ����q�MDB�O�_�@�P*/
               if (strncmp( sIcomp_in, get_upcomp( policyDB, USE_BRANCH_ID, USE_BRANCH_ID), 1) != 0)
               {
                   strcat( sMsg, "����k�ݤ����q�MDB���@�P");
                   fprintf( report, "%s\n", sMsg);
                   continue;
               }

               /**** ��涷���s����g��H�~�Z�k�ݳ��κ޲z�H ****/
               $SELECT iquota, ileader, iroute
                  INTO $iquota, $ileader, $iroute_off
                  FROM officer
                 WHERE iofficer = $iofficer;

               if (SQLCODE == SQLNOTFOUND)
               {
                   strcat( sMsg, "�g��H��Ƨ䤣��");
                   fprintf( report, "%s\n", sMsg);
                   continue;
               }

               strcpy(v_sMsg," ");  /* 111.12 fix */
               rc = chk_iquota_expire( iquota, v_sMsg);
               if( rc != M_CM_OK)
               {
                   strcat( sMsg, v_sMsg);
                   fprintf( report, "%s\n", sMsg);
                   continue;
               }

               /* bis9901141 �q���M�� */
               /* W�}�Y���g��N���n�Φ^�k�᪺�g��N���h��w�]�q���N�� */
               if (iofficer[0] == 'W')
               {
                    strcpy(iofficer_prmt,trim(iofficer_prmt));
                    /* �Y��O��S���^�k�᪺�g��N��,�N�����^ca_promote_officer�h�� */
                    if (iofficer_prmt[0] == ' ' || iofficer_prmt[0] == '\0')
                    {
                    	   $SELECT iofficer INTO $iofficer_prmt FROM ca_promote_officer
                          WHERE iofficer_ori = $iofficer
                            AND ibig_office = $ibig_office;
                            
                        if (SQLCODE == SQLNOTFOUND) strcpy(iofficer_prmt," ");
                    }
 
                    $SELECT iroute INTO $iroute FROM officer where iofficer = $iofficer_prmt;
                    if (SQLCODE == SQLNOTFOUND) strcpy(iroute," ");
               } else
               {
               	/* �Y�q���N���ťթάO���s�b,�ϥθg��N���w�]�q���N�� */
               	if (iroute[0] == ' ' || iroute[0] == '\0') strcpy(iroute,iroute_off);
               }             	           
               	
               /* �Y�q���N���ťթάO���s�b,�ϥιw�]�q���N�� */
               strcpy(iroute,trim(iroute));
               if (iroute[0] == ' ' || iroute[0] == '\0')
               {        	            
               	 strcat( sMsg, "�q���N�����ťթ�NULL");
                   fprintf( report, "%s\n", sMsg);
                   continue;                                   
               } else  
               {
               	/* �ˬd�q���N���O�_�s�b��q���ɤ� */
                  $SELECT count(*) INTO $tmp_cnt FROM cm_route
                    WHERE iroute = $iroute;
                  if (tmp_cnt == 0)
                  {
           	            strcat( sMsg, "�q����Ƥ��s�b");
                        fprintf( report, "%s\n", sMsg);
                        continue;
                   }
               }               

               /* get ���s�X���O*/
               strncpy(sIbilling, sIpolicy+CAR_POL_CHR_POS-1, 2);
               sIbilling[2]='\0';

               rc = cm_get_serial_num_dwritten ("C2", sIbilling,
                                                sIupcompShort, sIbranch_in,
                                                cm_cdate_str_100(dwritten),
                                                cm_cdate_str_100(cm_today ()), iendorse);
               if (rc != 0)
               {
                    if ( rc == 1 ||  rc == 2) strcat( sMsg, "��Ʈw�L�k�}��");
                    else if ( rc == 3) strcat( sMsg, "���۰ʵ�����Ƥ��s�b");
                    else strcat( sMsg, "����渹���~");

                    fprintf( report, "%s\n", sMsg);
                    continue;
               }

               rc = bk_401( policyDB, sIpolicy, iendorse);
               if ( rc != M_CM_OK)
               {
                    strcat( sMsg, "�O��ƥ�����");
                    fprintf( report, "%s\n", sMsg);
                    continue;
               }

               /* 1090831006_SC2 �{�ҥ��x�j��q�l���ҥ���g�����mail�ˮ� */
               rsetnull(CDTIMETYPE, (char *) &dnotifyornot);	
               strcpy(s_notifyornot,"");         
               if (fcard_class[0] == '1')
               {            
                   if ( 
                        ( strlen(trim(tmobile_appl))==0 && strlen(trim(aemail_appl))==0 ) && 
                        ( (feply[0]=='1' && strlen(trim(tmobile_eply))==0 && strlen(trim(aemail_eply))==0 ) || feply[0]=='0')
                      )
                   {
                       dtcurrent(&dnotifyornot);
                       dttoasc(&dnotifyornot, s_notifyornot);
                   }
                   printf("--trace s_notifyornot[%s]",s_notifyornot);
               }

               policy_1[0]='\0';
               policy_2[0]='\0';

               strncpy(policy_1, sIpolicy, CAR_POLICY_LEN);
               policy_1[CAR_POLICY_LEN]=0;

               if (strlen(sIpolicy)>CAR_POLICY_LEN) strcpy(policy_2,&sIpolicy[CAR_POLICY_LEN]);
               else strcpy(policy_2," ");

               ao_chk_charge( policyDB, 'A', policy_1, policy_2, ibatch_no,
                              payresult, paystatus, paydate, notedate);

	           /*1071105008_SC2_ �������Ȩ��z��(FS)�A�éw�ɦ۰ʤU���ɮ�*/
	           strcpy(iroute_accept_edr," ");         
	           if(strncmp(iroute,"I009",4)==0)
	           {
	               strcpy(iendorse, trim(iendorse));             
	               sprintf_s(iroute_accept_edr, sizeof iroute_accept_edr, "CHB%s", iendorse);             
	           }
	           printf("-- trace iroute_accept_edr[%s]\n ", iroute_accept_edr); 
         
               sprintf_s(stmt, sizeof stmt,"INSERT INTO %s:endorsement  "
                    "       (iendorse,    qply_period,  dply_begin,  dply_end,    fassured,  "
                    "        iassured,    iassured_ext, nassured,    ilicense,     "
                    "        fsex,        fmarriage,    nuser,       ibenef,      nbenef,  "
                    "        aassured,    aassured_zip, itel,        apayment,    apayment_zip, "
                    "        iply_area,   nbrand_abbr,  ncar_abbr,   fcar_note,   qcylinder,  "
                    "        iengine,     ibody,        itag,        mcar_price,  nequipment,  "
                    "        flimit,      pdmg_align,   pbrg_align,  plia_align,  idmg_rate,  "
                    "        pdmg_factor, ibrg_rate,    pbrg_factor, qpt,         fpt,  "
                    "        psex_age,    psex_age_damage, lia_class,    plia_acc,    dmg_acc_1st, dmg_acc_2nd,  "
                    "        dmg_acc_3rd, pdmg_acc,     fhuman,      fcomp_24,    payresult,  "
                    "        iext_policy, qpro_month,   mkilo_ply,   mkilo_edr,   irisk,  "
                    "        irelative_ext,  "
                    "        napplicant,  dbirth,   dissue,     "
                    "        iextra_charge, gextra_charge, pextra_charge,                     "
                    "        iquery_num_damage, iquery_num, mequipment,           "
                    "        survey_num,  bound_num,    abnormal_num, iapplicant, iroute, qlia_acc_sum, qdmg_acc_sum,  "
                    "        fapplicant,fsex_appl,dbirth_appl,itel_appl,ndeputy_appl,nrelation_appl,ndeputy_assured,  "
                    "        iassured_cntry, iapplicant_cntry,nassured_cntry, napplicant_cntry,  "
                    "        foccup, noccup, applicant_foccup, applicant_noccup, iroute_accept,tmobile_appl , aemail_appl)  "
                    "  SELECT '%s', a.qply_period,          %ld,   %ld,    b.fassured,  "
                    "        b.iassured,    b.iassured_ext, b.nassured,    b.ilicense,      "
                    "        b.fsex,        b.fmarriage,    b.nuser,       b.ibenef,      b.nbenef,  "
                    "        b.aassured,    b.aassured_zip, b.itel,        b.apayment,    b.apayment_zip, "
                    "        b.iply_area,   b.nbrand_abbr,  b.ncar_abbr,   b.fcar_note,   b.qcylinder,  "
                    "        b.iengine,     b.ibody,        '%s',          b.mcar_price,  b.nequipment,  "
                    "        b.flimit,      b.pdmg_align,   b.pbrg_align,  b.plia_align,  b.idmg_rate,  "
                    "        b.pdmg_factor, b.ibrg_rate,    b.pbrg_factor, b.qpt,         b.fpt,  "
                    "        b.psex_age,    b.psex_age_damage, b.lia_class,    b.plia_acc,    b.dmg_acc_1st, b.dmg_acc_2nd,  "
                    "        b.dmg_acc_3rd, b.pdmg_acc,     b.fhuman,      b.fcomp_24,    '%s',  "
                    "        b.iext_policy, b.qpro_month,   b.mkilo_ply,   b.mkilo_edr,   b.irisk,  "
                    "        b.irelative_ext,  "
                    "        b.napplicant,  b.dbirth,   %ld, "
                    "        b.iextra_charge, b.gextra_charge, b.pextra_charge,                     "
                    "        b.iquery_num_damage, b.iquery_num, b.mequipment,         "
                    "        b.survey_num,  b.bound_num,    b.abnormal_num, b.iapplicant, '%s', b.qlia_acc_sum, b.qdmg_acc_sum,  "
                    "        b.fapplicant,b.fsex_appl,b.dbirth_appl,b.itel_appl,b.ndeputy_appl,b.nrelation_appl,b.ndeputy_assured,  "
                    "        CASE WHEN b.iassured_cntry='' THEN '8' ELSE b.iassured_cntry END,  "
                    "        CASE WHEN b.iapplicant_cntry='' THEN '8' ELSE b.iapplicant_cntry END, b.nassured_cntry, b.napplicant_cntry, "
                    "        b.foccup, b.noccup, b.applicant_foccup, b.applicant_noccup, '%s',b.tmobile_appl , b.aemail_appl  "
                    "    FROM %s:ply_relation a, %s:policy b  "
                    "   WHERE a.ipolicy = b.ipolicy  "
                    "     AND a.ipolicy = '%s' ", policyDBname, iendorse, dply_begin, dply_end, sItag, payresult, dissue, iroute, iroute_accept_edr, policyDBname, policyDBname, sIpolicy);
					
               printf("[%s]\n",stmt);
               $PREPARE prep2 FROM  $stmt;
               $EXECUTE prep2;

               /* �U�CSQL��fedr_class�n��5:�@���� */
               sprintf_s(stmt, sizeof stmt, "INSERT INTO %s:edr_relation  "
                    "         (iendorse,      fcard_class,   ipolicy,       icard,             irelative_ply,  "
                    "          irelative_edr, fedr_class,    fpay,          ipay,              iedr_field,  "
                    "          dedr_begin,    dedr_end,      ipro_year,         ibrand,  "
                    "          icar_type,     medrdmg_agent, medrdmg_commi, medrdmg_prem,      medrdmg_pure_prem, "
                    "          medrlia_agent, medrlia_commi, medrlia_prem,  medrlia_pure_prem, ibig_comp,  "
                    "          ibig_branch,   ibig_office,   ibig_sales,    iresource,         ibroker,  "
                    "          iofficer,      ileader,       icorps,        iedr_area,         iedr_cashier,  "
                    "          iedr_examiner, dedr_examine,  dentry,        dendorse,          fprint,  "
                    "          itreaty,       ibranch,       iquota,        icomp_in,          ibranch_in,  "
                    "          icomp_at,      ibranch_at,    medr_ready,    medr_stable,       medr_compensate,  "
                    "          medr_adjcom,   medr_research, medr_invest,   medr_bus_rule,     medr_business,  "
                    "          medr_capital,  medr_maintain, fcomp_class,   fcomp_class_last,  fdiscount,  "
                    "          medrdmg_disc,  medrlia_disc,  iedr_return,   icar_flag,         terminate_rsn,  "
                    "          qcount,        iofficer_prmt, iquota_prmt,   ileader_prmt,      irate_type,  "
                    "          bzfrom,        iroute_comm,   icomm_obj,     qprovision,        isecond_hand,icard_main, qdrunk_driving, isign, "
                    "          feply,         feedr,         aemail_eply,   tmobile_eply,      ireg_no ,  dnotifyornot,  "
                    "          isign_edr, dsign_edr, fsign_status_edr, funder_chk_edr, iprog ,qviolate )  "
                    "  SELECT  '%s',        fcard_class, ipolicy,     icard,            irelative_ply,  "
                    "          ' ',         '5',         ' ',         ' ',              ' ',  "
                    "          %ld,         %ld,         ipro_year,        ibrand,  "
                    "          icar_type,        0,           0,           0,                0,  "
                    "          0,           0,           0,           0,                ibig_comp,  "
                    "          ibig_branch, ibig_office, ibig_sales,  iresource,        ibroker,  "
                    "          iofficer,    '%s',        icorps,      iarea,            icashier,  "
                    "          'car616',    %ld,         %ld,         %ld ,             1,  "
                    "          itreaty,     ibranch,     '%s',        icomp_in,         ibranch_in,  "
                    "          icomp_at,    ibranch_at,  0,           0,                0,  "
                    "          0,           0,           0,           0,                0,  "
                    "          0,           0,           fcomp_class, fcomp_class_last, fdiscount,  "
                    "          0,           0,           '1',         icar_flag,        '0',  "
                    "          0,           iofficer_prmt, iquota_prmt, ileader_prmt,   irate_type,  "
                    "          bzfrom,      iroute_comm, icomm_obj,   qprovision,       isecond_hand,icard_main, qdrunk_driving, isign, "
                    "          feply, (CASE WHEN fcard_class='2' THEN feply ELSE '0' END) AS feedr, aemail_eply, tmobile_eply,     ireg_no ,'%s' ,  "
                    "          'system',    today,       40,          'N' ,             'car616' ,qviolate  "
                    "    FROM %s:ply_relation  "
                    "   WHERE ipolicy = '%s'", policyDBname,
                       iendorse, dply_begin, dply_end, ileader, dwritten, dwritten, dwritten, iquota, s_notifyornot, policyDBname, sIpolicy);

               $PREPARE prep3 FROM  $stmt;
               $EXECUTE prep3;

               sprintf_s(stmt, sizeof stmt, "UPDATE %s:ply_relation  "
                             "   SET iquota    = '%s', "
                             "       ileader   = '%s',  "
                             "       dnotifyornot = '%s',  "
                             "       dply_begin   =  %ld,  "
                             "       dply_end     =  %ld   "
                             " WHERE ipolicy = '%s'", 
                                   policyDBname, iquota, ileader, s_notifyornot, dply_begin, dply_end, sIpolicy);
               $PREPARE prep4 FROM  $stmt;
               $EXECUTE prep4;

               if (iEdr == 0)   /* 0:�u�娮�P ; 1:�娮�P + �O�I�_���B�o�Ӥ�� ; 2:�u��O�I�_���B�o�Ӥ�� */  
               {
                   FLD_SET ( iedr_field, 20);  /* ��郞�P(�N����20) */ 
               }
               else if (iEdr == 1)
               { 
                   FLD_SET ( iedr_field, 20);  /* ��郞�P       (�N����20) */ 
                   FLD_SET ( iedr_field, 10);  /* ���dply_begin(�N����10) */ 
                   FLD_SET ( iedr_field, 11);  /* ���dply_end  (�N����11) */ 
                   FLD_SET ( iedr_field, 12);  /* ���dissue    (�N����12) */ 
               }
               else
               {
                   FLD_SET ( iedr_field, 10);  /* ���dply_begin(�N����10) */ 
                   FLD_SET ( iedr_field, 11);  /* ���dply_end  (�N����11) */ 
                   FLD_SET ( iedr_field, 12);  /* ���dissue    (�N����12) */ 
               }
               

               sprintf_s(stmt, sizeof stmt, "UPDATE %s:edr_relation SET iedr_field = ? WHERE iendorse = '%s'", 
                             policyDBname, iendorse);
                             
               $PREPARE prep5 FROM  $stmt;
               $EXECUTE prep5 USING $iedr_field;
         
               sprintf_s(stmt, sizeof stmt, "UPDATE %s:policy  "
                             "   SET itag    = '%s',  "
                             "       dissue  =  %ld   "
                             " WHERE ipolicy = '%s'", policyDBname, sItag,dissue, sIpolicy);

               $PREPARE prep6 FROM  $stmt;
               $EXECUTE prep6;

               if (iEdr == 2)
               {
                    sprintf_s(sMsg, sizeof sMsg, "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t", 
                                key_value, sItag, sIpolicy, fassured_next, inext_ply, fcomp_class_next, iendorse, "�w�X���(�O�樮�P�D�ťաA�ȧ��O�I�_���B�o�Ӥ��)" );  
               }
               else if (iEdr == 1)
               {
                    sprintf_s(sMsg, sizeof sMsg, "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t", 
                                key_value, sItag, sIpolicy, fassured_next, inext_ply, fcomp_class_next, iendorse, "�w�X���(��郞�P�B�O�I�_���εo�Ӥ��)" );  
               }
               else
               {
                    sprintf_s(sMsg, sizeof sMsg, "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t", 
                                key_value, sItag, sIpolicy, fassured_next, inext_ply, fcomp_class_next, iendorse, "�w�X���" );  
               }
               fprintf( report, "%s\n", sMsg);
         } /* End of ����i��檺�j�� */
         
         iCount++;            
    } /* End for(;;) */
    
    printf( "iCount=[%d]\n", iCount);
    $CLOSE curs1;   
    $Free curs1;

    fclose(report);

    sprintf_s(TmpName, sizeof TmpName, "car616_report_%s.txt", outputf);

    /*�@�X�ּ��D */
    sprintf_s(cmd_stmt, sizeof cmd_stmt,
        "cd %s/rptftp/; "
        "cat ../form/car616_e_t.fmt %s > %s; "
        "rm -f %s;", sApHome, RptName, TmpName, RptName);

    printf("cmd_stmt=[%s]\r\n", cmd_stmt);
    rc = system( cmd_stmt);
    if (rc != 0) {
        printf("cat file���~\r\n");
        sprintf_s(sMsg, sizeof sMsg, "cat file���~\r\n");
        return rc;
    }

    rc=rptftpinsert(userid,"car616", TmpName);
    printf("rptftpinsert rc[%d]\n", rc);
    if (rc!=0) 
    {
        sprintf_s(sMsg, sizeof sMsg,"%s�g�Jrptftplist���~\r\n", RptName);
        return rc;
    }

    time(&tt);
    printf("�ɶ�[%s]\n", ctime(&tt));

    sprintf_s(sMsg, sizeof sMsg, "���槹��,�@[%d]��\n", iCount);
    WRITELOG( sfp, sMsg);
    printf("sMsg[%s]", sMsg);

    sprintf_s(sMsg, sizeof sMsg,"��粒��,���I���ɮפU���@�~�d��[Q],�U����ﵲ�G����[%s] \r\n", TmpName);

    return M_CM_OK;

 errexit:

    sprintf_s(v_sMsg, sizeof v_sMsg, "SQLCODE[%d], ERRM[%s] �O�渹[%s], �j���Ҹ�/������[%s]�B���P���X[%s]\n",
          SQLCODE, sqlca.sqlerrm, sIpolicy, key_value, sItag);

    strcat( sMsg, v_sMsg);
    fprintf( report, "%s\n", sMsg);
    fclose(report);
    printf("sMsg[%s]\n", sMsg);
    return SQLCODE; 
}

/*--------------------------------------------------------------------*/
long car616_updtag_fmc()
{
    $char  sdata[3][21],cmd_stmt[201];
    int    rc;
    char  readstr[51];

    $whenever sqlerror goto errexit;

    if (strncmp(fbig_office,"H",1) == 0)
    {
         /*-----------------------------------------
         �B�z���q�ɨ��P�ɮ�, 
         1.�Ƶ{����fmcftpget,�NnewaYYYYMMDD_sym.txt get �� aphome/dat/car/
         2.�Ƶ{����run616_updtag,����car616�@�~,�NnewaYYYYMMDD_sym.txt�X�֬�sym.txt, �çR�� newaYYYYMMDD_sym.txt 
         3.Ū��sym.txt�[�WTab�x�s��newa_sym.txt
         4.�]�ɦW��newa_sym.txt,����M���ת��ɮר֤JFMC*.txt
         -----------------------------------------*/

         sprintf_s(cmd_stmt, sizeof cmd_stmt,"cat %s/dat/car/newa*_sym.txt > %s/dat/car/sym.txt ; rm -f %s/dat/car/newa*_sym.txt", sApHome, sApHome,  sApHome);

         printf("cmd_stmt[%s]\n",cmd_stmt);

         rc = system(cmd_stmt);
         printf("rc[%d]\n", rc);

         file_sym[0] = '\0';
         file_sym1[0] = '\0';
         sprintf_s(file_sym, sizeof file_sym, "%s/dat/car/sym.txt", sApHome);
         sprintf_s(file_sym1, sizeof file_sym1,"%s/dat/car/newa_sym.txt", sApHome);

         printf( "file_sym  [%s]\n", file_sym);
         printf( "file_sym1 [%s]\n", file_sym1);

         if ((fp_sym=fopen(file_sym,"r"))==NULL) {
            printf("%s �ɮ׶}�ҥ���\n",file_sym);
            return FALSE;
         }

         puts("fopen fp_sym ok");
         fp_sym1=fopen(file_sym1,"w");
         puts("fopen fp_sym1 ok");
         while(1)
         {
             fscanf(fp_sym,"%[^\n]%*c",readstr);
             puts("fscanf ok");
             printf("readstr[%s]\n", readstr);

             if(feof(fp_sym)) break;
             puts("feof ok ");

             readstr[20]='\t'; /* �[tab */
             puts("�[ tab ok");

             printf("readstr[%s]\n", readstr);

             fprintf( fp_sym1, "%s\n", readstr);
             puts("fwrite ok");
         }
         fclose(fp_sym);
         puts("fclose fp_sym ok");
         fclose(fp_sym1);
         puts("fclose fp_sym1 ok");
         /*-----------------------------------------------*/
         sprintf_s(cmd_stmt, sizeof cmd_stmt,"cat %s/dat/car/newa* > %s/dat/car/FMC_%s.txt; rm -f %s/dat/car/newa_sym.txt sym.txt; ", sApHome, sApHome, sysTm, sApHome);

         printf("cmd_stmt[%s]\n",cmd_stmt);

         rc = system(cmd_stmt);
         printf("rc[%d]\n", rc);

         sprintf_s(filename, sizeof filename,"%s/dat/car/FMC_%s.txt",sApHome,sysTm);
         rc=car616_read_file();              /* ���רϥ�tab���j */
         if (rc != M_CM_OK ) return rc;
    }
    else if (strncmp(fbig_office,"Y",1) == 0)
    {   	
         sprintf_s(cmd_stmt, sizeof cmd_stmt,"cat %s/dat/car/EGNO_VHNO_*.TXT > %s/dat/car/YL_%s.txt \r\n", sApHome, sApHome, sysTm);

         printf("cmd_stmt[%s]\n",cmd_stmt);

         rc = system(cmd_stmt);

         sprintf_s(filename, sizeof filename,"%s/dat/car/YL_%s.txt",sApHome,sysTm);
         rc=car616_read_file_fix();          /* �ζ��ϥΩT�w�e�� */
         if (rc != M_CM_OK ) return rc;
    }
    else 
    {
    	     strcpy(msgbuf,"�ﶵ���~(�D���פ]�D�ζ�)");
    	     return M_CM_OK;
    }
printf("filename[%s]\n",filename);        
   
    if (qcount==0) {
        strcpy(msgbuf,"�L�P�Ӹ�ƥi��");
        return M_CM_OK;
    }


    $DELETE FROM ca_fill_itag WHERE 1=1;   
    
    $begin work; 
    $delete from ca_080_updtag where fstatus = '2';
    rc=car616_read_policy();
    if (rc != M_CM_OK ) {
         $rollback work; 
        
        return rc;
    }
     $commit work; 

    return M_CM_OK;
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;  
}

/*--------------------------------------------------------------------
long car616_update_by_card()
{
    $char  sdata[3][21];
    int    rc;

    $whenever sqlerror goto errexit;

    rc=car616_read_file_by_card();
    if (rc != M_CM_OK )
        return rc;
    
    if (qcount==0) {
        EWRITE(userid,0,"�L�P�Ӹ�ƥi��");
        return 0;
    }

    $begin work;
    $delete from ca_080_updtag where fstatus = '2';
    rc=car616_read_policy_by_card();
    if (rc != M_CM_OK ) {
        $rollback work;
        return rc;
    }
    $commit work; 

    return M_CM_OK;
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;  
} */

/*--------------------------------------------------------------------*/
/********************
long car616_080memo()
{
    $char db[17];
    $char stmt_ply1[2048];
    $char sTmt_buf1[120];
    $int  rc;

    $whenever sqlerror goto errexit;

    $BEGIN WORK;
    $LOCK TABLE ncar005_m IN EXCLUSIVE MODE;
    $LOCK TABLE ncar005_d IN EXCLUSIVE MODE;
    $DELETE FROM ncar005_m;
    $DELETE FROM ncar005_d;

    ply_cnt=dtl_cnt=0;
    for (i=0;i<count_db;i++) {
        strcpy(com,get_upcomp(list[i].dbbranch,1,0));
        rc = read_ncar013();
        if (rc < 0) {
            $rollback work;
            return rc;
        }
    }
    $commit work;
    if (ply_cnt==0)
       sprintf_s(msgbuf, sizeof msgbuf,"%s�L�ɵP�Ӹ�ƥi����\n",msgbuf);
    else
       sprintf_s(msgbuf, sizeof msgbuf,"%s080Memo�ɵP�ӫO��:[%5d]�� �I��:[%6d]��\n",
            msgbuf,ply_cnt,dtl_cnt);

    return M_CM_OK;
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
***********************/
/*--------------------------------------------------------------------*/
long car616_unload_fmc()
{
    $int  rc,pcnt;
    char  yy[5],mm[3],dd[3];
    char  f1[24],f2[24],f3[24],f4[24];
    int   iyear = 0;
    char  tmp_date[17];
    
    char cp1[128],cp2[128],cp3[128],cp4[128];
    char command1[256],command2[256],command3[256],command4[128];
    int result1,result2,result3,result4;
    
    $whenever sqlerror goto errexit;
    filename1[0]='\0';
    filename2[0]='\0';
    filename3[0]='\0';
    filename4[0]='\0';
    sprintf_s(f1, sizeof f1,"car616_ply_%s",sysTm);
    sprintf_s(f2, sizeof f2,"car616_ins_%s",sysTm);
    sprintf_s(f3, sizeof f3,"car616_clm_%s",sysTm);
    sprintf_s(f4, sizeof f4,"car616_bis_%s",sysTm);
    if (itype==9) {
       sprintf_s(filename1, sizeof filename1,"%s/rptftp/%s",sApHome,f1);
       sprintf_s(filename2, sizeof filename2,"%s/rptftp/%s",sApHome,f2);
       sprintf_s(filename3, sizeof filename3,"%s/rptftp/%s",sApHome,f3);
       sprintf_s(filename4, sizeof filename4,"%s/rptftp/%s",sApHome,f4);
    }
    else {
       sprintf_s(filename1, sizeof filename1,"%s/rptftp/%s",sApHome,f1);
       sprintf_s(filename2, sizeof filename2,"%s/rptftp/%s",sApHome,f2);
       sprintf_s(filename3, sizeof filename3,"%s/rptftp/%s",sApHome,f3);
       sprintf_s(filename4, sizeof filename4,"%s/rptftp/%s",sApHome,f4);
    }
    printf("file1[%s]\n",filename1);
    fp1=fopen(filename1,"w");
    fp2=fopen(filename2,"w");
    fp3=fopen(filename3,"w");
    fp4=fopen(filename4,"w");
    
printf("dbgn1[%s],dend1[%s]\n",dbgn1,dend1);
    strcpy(tmp_date,cm_from_infdate_100(dbgn1));
    cm_split_ymd_100(tmp_date,yy,mm,dd);
    iyear = atoi(yy) + 1911;    
    sprintf_s(dbgn3, sizeof dbgn3,"%d-%s-%s 00:00",iyear,mm,dd); 
       
    strcpy(tmp_date,cm_from_infdate_100(dend1));
    cm_split_ymd_100(tmp_date,yy,mm,dd);
    iyear = 0;
    iyear = atoi(yy) + 1911;
    sprintf_s(dend3, sizeof dend3,"%d-%s-%s 23:59",iyear,mm,dd);    

    cnt_p=cnt_i=cnt_c=0;
    cnt=cnt_1=cnt_2=0;
    for (i=0;i<count_db;i++) {
        rc = car616_read_ply();
        if (rc != M_CM_OK)
            return rc;
        rc = car616_read_edr();
        if (rc != M_CM_OK)
            return rc;
        rc = car616_read_clm();
        if (rc != M_CM_OK)
            return rc;
        rc = car616_read_bis();
        if (rc != M_CM_OK)
            return rc;              
    }  
            
    fclose(fp1);
    fclose(fp2);
    fclose(fp3);
    fclose(fp4);
/*********** 93.08.26 �C�g�۰ʰ���,�]�����A�P�_�L�P�Ӥ��
    if (cnt_p!=0) {
        pcnt=(double)cnt/cnt_p*100 + 0.5;
        printf("pcnt[%d]\n",pcnt);
        if (pcnt > 10) {
            sprintf_s(msgbuf, sizeof msgbuf,"�L�P�Ӹ��[%d]��ҶW�L10%,�а���������X��X,�A�ж��׸ɵP�Ӹ��[%d]",
            cnt,cnt_p);
            EWRITE(userid,cnt,msgbuf);
            return cnt;
        }
    }
**********/
    rc=rptftpinsert(userid,"car616",f1);
    if (rc!=0) {
        EWRITE(userid,rc,"car616_ply�g�Jrptftplist���~");
        return rc;
    }
    rc=rptftpinsert(userid,"car616",f2);
    if (rc!=0) {
        EWRITE(userid,rc,"car616_ins�g�Jrptftplist���~");
        return rc;
    }
    rc=rptftpinsert(userid,"car616",f3);
    if (rc!=0) {
        EWRITE(userid,rc,"car616_clm�g�Jrptftplist���~");
        return rc;
    }
    rc=rptftpinsert(userid,"car616",f4);
    if (rc!=0) {
        EWRITE(userid,rc,"car616_bis�g�Jrptftplist���~");
        return rc;
    }    
    
    sprintf_s(cp1, sizeof cp1,"cp %s/rptftp/%s %s/rptftp/fmc/%s",sApHome,f1,sApHome,f1);
	printf("cp1[%s]\n", cp1);
	sprintf_s(command1, sizeof command1, "%s", cp1);
	result1 = system(command1);
	
	sprintf_s(cp2, sizeof cp2,"cp %s/rptftp/%s %s/rptftp/fmc/%s",sApHome,f2,sApHome,f2);
	printf("cp2[%s]\n", cp2);
	sprintf_s(command2, sizeof command2, "%s", cp2);
	result2 = system(command2);
	
	sprintf_s(cp3, sizeof cp3,"cp %s/rptftp/%s %s/rptftp/fmc/%s",sApHome,f3,sApHome,f3);
	printf("cp3[%s]\n", cp3);
	sprintf_s(command3, sizeof command3, "%s", cp3);
	result3 = system(command3);
	
	sprintf_s(cp4, sizeof cp4,"cp %s/rptftp/%s %s/rptftp/fmc/%s",sApHome,f4,sApHome,f4);
	printf("cp4[%s]\n", cp4);
	sprintf_s(command4, sizeof command4, "%s", cp4);
	result4 = system(command4);
    
    sprintf_s(msgbuf, sizeof msgbuf,"��X�O��[%d]��,�I�ة���[%d]��,�w���I��[%d]��;�L�P��[%d]��",
            cnt_p,cnt_i,cnt_c,cnt);
    EWRITE(userid,M_CM_OK,msgbuf);
    

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car616_read_file()
{
    $char  sdata[3][21];
    char   *bp;
    int    rc,j,k,m,n,dt[7];

    $whenever sqlerror goto errexit;

    flen=1024;
    if ((fp=fopen(filename,"r"))==NULL) {
       sprintf_s(msgbuf, sizeof msgbuf,"%s �ɮ׶}�ҥ���",filename);
       EWRITE(userid,FALSE,msgbuf);
       return FALSE;
    }
    if ((bp=malloc(flen))==NULL) {
       sprintf_s(msgbuf, sizeof msgbuf,"System malloc failed !");
       EWRITE(userid,FALSE,msgbuf);
       free(bp);
       return FALSE;
    }

    rc=car616_create_temp();
    if (rc != M_CM_OK)
        return rc;

    for (i=0;(feof(fp)==0);i++) {
        memset(bp,0x00,flen);
        fgets(bp,flen,fp);
        if (bp[0]==0x00)
           break;
        if (strlen(trim(bp))<6)
           break;
        printf("bp[%s][%d]\n",bp,strlen(trim(bp)));
        for(j=0;j<3;j++)
            for(k=0;k<21;k++)
                sdata[j][k]='\0';
        k=m=n=0;
        for (j=0;j<flen;j++) {
            if (bp[j]=='\t' || bp[j]=='\0' || bp[j]=='\n' || bp[j]=='\r' ) { /* �ץ��r����ݦh�@�� \r  ���D */
                strncpy(sdata[k],bp+m,j-m);
                sdata[k][j-m]='\0';
                printf("j[%d]k[%d]sdata[%s]\n",j,k,sdata[k]);
                m=j+1;
                k++;
            }
            if (bp[j]=='\n')
                break;
            if (k > 1) break;
        }      
        printf("sdata[%s][%s][%s]\n",sdata[0],sdata[1],sdata[2]);
        if (sdata[1][0]=='\0' || isalnum(sdata[1][0])==0) continue;
        	
        /* 6�ӼƦr������-    add by sylvia 101.09.07 (1010906005_C1) */
        dt[0]=dt[1]=dt[2]=dt[3]=dt[4]=dt[5]=dt[6]=0; 
        for(j=0;j<7;j++) {
            if (isdigit(sdata[1][j])) dt[j]=1;
        } 
        if( strstr( sdata[1], "-"))
        {
                for (j=0;j<21;j++)
                     sdata[1][j]=toupper(sdata[1][j]);
                strcpy(sdata[2],sdata[1]);
        }
        else if (dt[0] && dt[1] && dt[2] && dt[3] && dt[4] && dt[5]) {   /* �¦��P�� */
        	  /* 6�ӼƦr������-  , �����P�ˮֵ{���������X  ���P[XXXXXX]�榡����  ���T�� */
        		strcpy(sdata[2],sdata[1]);
        }
        else if (dt[0] && dt[1] && dt[2] && dt[3]) {   /* �¦��P�� */
            if (sdata[1][4]=='-') {
                for (j=5;j<7;j++)
                     sdata[1][j]=toupper(sdata[1][j]);
                strcpy(sdata[2],sdata[1]);
            }
            else {
                for (j=4;j<6;j++)
                     sdata[1][j]=toupper(sdata[1][j]);
                strncpy(sdata[2],sdata[1],4);
                strcat(sdata[2],"-");
                strcat(sdata[2],substring(sdata[1],5,2));
            }
        }
        else if (dt[0] && dt[1] && dt[2]) {   /* �¦��P�� */
            if (sdata[1][3]=='-') {
                for (j=4;j<7;j++)
                     sdata[1][j]=toupper(sdata[1][j]);
                strcpy(sdata[2],sdata[1]);
            }
            else {
                for (j=3;j<6;j++)
                     sdata[1][j]=toupper(sdata[1][j]);
                strncpy(sdata[2],sdata[1],3);
                strcat(sdata[2],"-");
                strcat(sdata[2],substring(sdata[1],4,3));
            }
        }
        else if( strlen(trim(sdata[1])) == 7)  /* �s���P�� */
        {
            for (j=0;j<3;j++)
                sdata[1][j]=toupper(sdata[1][j]);

            strncpy(sdata[2],sdata[1],3);
            strcat(sdata[2],"-");
            strcat(sdata[2],substring(sdata[1],4,4));
        }
        else if ( (!dt[0]) &&  (!dt[1]) &&  (!dt[2])) /* �s,�¦��P�ӬҦ��e3�^��,��3�^�� */
        {
            for (j=0;j<3;j++)
                sdata[1][j]=toupper(sdata[1][j]);

            strncpy(sdata[2],sdata[1],3);
            strcat(sdata[2],"-");
            strcat(sdata[2],substring(sdata[1],4,3));
        }
        else {                     /* �¦��P�� */
            for (j=0;j<2;j++)
                sdata[1][j]=toupper(sdata[1][j]);
            if (sdata[1][2]=='-')
                strcpy(sdata[2],sdata[1]);
            else {
                strncpy(sdata[2],sdata[1],2);
                strcat(sdata[2],"-");
                strcat(sdata[2],substring(sdata[1],3,4));
            }
        }
        
        printf("sdata[%s][%s]\n",sdata[0],sdata[2]);
        $delete from car616_1 where iengine = $sdata[0];
        $insert into car616_1
         values ($sdata[0],$sdata[2]);
    }

    $insert into car616
     select distinct iengine,itag
       from car616_1
      where itag is not null
        and itag != ' ';

    $select count(*)
       into $qcount
       from car616;

    printf("insert into car616[%d]\n",qcount);

    return M_CM_OK;
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;  
}

/*--------------------------------------------------------------------*/
/* �ζ��ϥΩT�w�e��,iengine(20),itag(5)                               */
/*--------------------------------------------------------------------*/
long car616_read_file_fix()
{
    $char  fiengine[CA_ENGINE_NUM],fitag[CA_TAG_NUM];
    char   tmp_itag[CA_TAG_NUM],readstr[284];
    int    rc,j,k,m,n,dt[7];

    $whenever sqlerror goto errexit;

    flen=1024;
    if ((fp=fopen(filename,"r"))==NULL) {
       sprintf_s(msgbuf, sizeof msgbuf,"%s �ɮ׶}�ҥ���",filename);
       EWRITE(userid,FALSE,msgbuf);
       return FALSE;
    }
   
    rc=car616_create_temp();
    if (rc != M_CM_OK)
        return rc;
        
     while(1)
   { 
     fscanf(fp,"%[^\n]%*c",readstr);

     if(feof(fp)) break;
printf("READSTR[%s]\n", readstr); 

     strcpy(tmp_itag,"");
     strcpy(fitag,"");         

     /* �N�ɮ׮ھکT�w�e��,Ū�X��� */
     strncpy( fiengine, &readstr[0], 20);
     fiengine[CA_ENGINE_NUM-1] = '\0';
     
     strncpy( fitag, &readstr[20], 8);
     fitag[8] = '\0';      
printf("iengine[%s],itag[%s]\n",fiengine,fitag);                
		
        printf("strlen(trim(fitag) ) == %d\n", strlen(trim(fitag) ));

        if (isalnum(fitag[0])==0) continue;

			/* 6�ӼƦr������-    add by sylvia 101.09.07 (1010906005_C1) */                
        dt[0]=dt[1]=dt[2]=dt[3]=dt[4]=dt[5]=dt[6]=0;
        for(j=0;j<7;j++) {
            if (isdigit(fitag[j])) dt[j]=1;
        } 

        printf("strlen(trim(fitag) ) == %d\n", strlen(trim(fitag) ));

        if (strstr( fitag, "-"))
        {
                for (j=0;j<8;j++)
                     fitag[j]=toupper(fitag[j]);
        	strcpy(tmp_itag,fitag);
        }
        else if (dt[0] && dt[1] && dt[2] && dt[3] && dt[4] && dt[5]) {       	/* �¦��P�� */
        	strcpy(tmp_itag,fitag);
        }
        else if (dt[0] && dt[1] && dt[2] && dt[3]) {       	/* �¦��P�� */
            if (fitag[4]=='-') {
                for (j=5;j<7;j++)
                     fitag[j]=toupper(fitag[j]);
                strcpy(tmp_itag,fitag);
            }
            else {
                for (j=4;j<6;j++)
                     fitag[j]=toupper(fitag[j]);
                strncpy(tmp_itag,fitag,4);
                tmp_itag[4] = '\0';
                strcat(tmp_itag,"-");
                strcat(tmp_itag,substring(fitag,5,2));
            }
            tmp_itag[8]= '\0';       
        }       
        else if (dt[0] && dt[1] && dt[2]) {         	/* �¦��P�� */
            if (fitag[3]=='-') {
                for (j=4;j<7;j++)
                     fitag[j]=toupper(fitag[j]);
                strcpy(tmp_itag,fitag);
            }
            else {
                for (j=3;j<6;j++)
                     fitag[j]=toupper(fitag[j]);
                strncpy(tmp_itag,fitag,3);
                tmp_itag[4] = '\0';
                strcat(tmp_itag,"-");
                strcat(tmp_itag,substring(fitag,4,3));
            }
            tmp_itag[7]= '\0'; 
        }
        else if( strlen(trim(fitag)) == 7)  /* �s���P�� */
        {
            for (j=0;j<3;j++)
                fitag[j]=toupper(fitag[j]);

            strncpy(tmp_itag,fitag,3);
            tmp_itag[3] = '\0';
            strcat(tmp_itag,"-");
            strcat(tmp_itag,substring(fitag,4,4));
            tmp_itag[8]= '\0';             
        }
        else if ( (!dt[0]) &&  (!dt[1]) &&  (!dt[2])) /* �s,�¦��P�ӬҦ��e3�^��,��3�^�� */
        {
        printf("strlen(trim(fitag) ) == %d\n", strlen(trim(fitag) ));
            for (j=0;j<3;j++)
                fitag[j]=toupper(fitag[j]);

            strncpy(tmp_itag,fitag,3);
            tmp_itag[3] = '\0';
            strcat(tmp_itag,"-");
            strcat(tmp_itag,substring(fitag,4,3));
            tmp_itag[7]= '\0';             
        }
        else {
            for (j=0;j<2;j++)
                fitag[j]=toupper(fitag[j]);
            if (fitag[2]=='-')
                strcpy(tmp_itag,fitag); 
            else { 
                strncpy(tmp_itag,fitag,2);
                tmp_itag[2] = '\0';
                strcat(tmp_itag,"-");
                strcat(tmp_itag,substring(fitag,3,4));
            }
            tmp_itag[8]= '\0';             
        }
        
        strcpy(fitag,tmp_itag);
        
printf("iengine[%s],itag[%s]\n",fiengine,fitag);
        $delete from car616_1 where iengine = $fiengine;
        $insert into car616_1
         values ($fiengine,$fitag);
    }

    $insert into car616
     select distinct iengine,itag
       from car616_1
      where itag is not null
        and itag != ' ';

    $select count(*)
       into $qcount
       from car616;           

    printf("insert into car616[%d]\n",qcount);

    return M_CM_OK;
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;  
}

/*--------------------------------------------------------------------*/
long car616_read_file_by_card()
{
    $char  sdata[3][21];
    char   *bp;
    int    rc,j,k,m,n,dt[4];

    $whenever sqlerror goto errexit;

    sprintf_s(filename, sizeof filename,"%s/dat/car/car616.txt",sApHome);
    flen=1024;
    if ((fp=fopen(filename,"r"))==NULL) {
       sprintf_s(msgbuf, sizeof msgbuf,"%s �ɮ׶}�ҥ���",filename);
       EWRITE(userid,FALSE,msgbuf);
       return FALSE;
    }
    if ((bp=malloc(flen))==NULL) {
       sprintf_s(msgbuf, sizeof msgbuf,"System malloc failed !");
       EWRITE(userid,FALSE,msgbuf);
       free(bp);
       return FALSE;
    }

    rc=car616_create_temp();
    if (rc != M_CM_OK)
        return rc;

    for (i=0;(feof(fp)==0);i++) {
        memset(bp,0x00,flen);
        fgets(bp,flen,fp);
        if (bp[0]==0x00)
           break;
        if (strlen(trim(bp))<6)
           break;
        printf("bp[%s][%d]\n",bp,strlen(trim(bp)));
        for(j=0;j<3;j++)
            for(k=0;k<21;k++)
                sdata[j][k]='\0';
        k=m=n=0;
        for (j=0;j<flen;j++) {
            if (bp[j]=='\t' || bp[j]=='\0' || bp[j]=='\n') {
                strncpy(sdata[k],bp+m,j-m);
                sdata[k][j-m]='\0';
                printf("j[%d]k[%d]sdata[%s]\n",j,k,sdata[k]);
                m=j+1;
                k++;
            }
            if (bp[j]=='\n')
                break;
            if (k > 1) break;
        }      
        printf("sdata[%s][%s][%s]\n",sdata[0],sdata[1],sdata[2]);
        if (sdata[1][0]=='\0') continue;
        
        $insert into car616
         values ($sdata[0],$sdata[1]); /* �Ҹ� + �P�� */
    }

    $select count(*)
       into $qcount
       from car616;

    printf("insert into car616[%d]\n",qcount);

    return M_CM_OK;
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car616_create_temp()
{
    $whenever sqlerror goto errexit;
    sprintf_s(stmt_tmp1, sizeof stmt_tmp1,"create temp table car616_1 "
    "(iengine    char(%d), "
    " itag       char(%d)) "
    "with no log;",CA_ENGINE_NUM-1,CA_TAG_NUM-1);
     $PREPARE stmp1 FROM $stmt_tmp1;
     $EXECUTE stmp1;
      
    sprintf_s(stmt_tmp2, sizeof stmt_tmp2,"create temp table car616 "
    "(iengine    char(%d), "
    " itag       char(%d)) "
    "with no log;",CA_ENGINE_NUM-1,CA_TAG_NUM-1);
     $PREPARE stmp2 FROM $stmt_tmp2;
     $EXECUTE stmp2;

    return M_CM_OK;
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car616_read_policy()
{
$char   ipolicy[21],iassured[11],iengine[CA_ENGINE_NUM],itag[CA_TAG_NUM];
$char   tag_buf[CA_TAG_NUM],s1[3],s2[5];
$char   stmp[1024],stmt[1024];

char    filename[50],fname[21];
FILE    *fp;
int     tmp_itype = 0, rc = 0;


   ply_cnt=cnt_1=cnt_2=0;
   $whenever sqlerror goto errexit;
   
   /* ���q�{������q,���hupdate ca_080_updtag & ca_ply_period, 
      �M��N��������(or�ζ�)�ݭn�諸���,unload to /dat/car/car616_t.txt����,�A�h����
      car616_update_tag�h��岣�ͧ�� */      

   $declare curA cursor for
     select a.ipolicy,a.iassured,a.iengine,b.itag
       from car616 b,assured_vs_ply a
      where b.iengine  = a.iengine
        and (a.itag = ' ' or a.itag is null);
 
   $open curA;
   for(;;)
   {
     $fetch curA
       into $ipolicy,$iassured,$iengine,$itag;
     if (SQLCODE==SQLNOTFOUND) break;
     ply_cnt++;
     printf("ipolicy:[%s]iengine:[%s]iassured:[%s]itag:[%s]\n",ipolicy,
             iengine,iassured,itag);
     if (ipolicy[5]=='V')
         cnt_1++;
     else
         cnt_2++;
     /*----- insert ncar013_na -----*/
     $insert into ca_080_updtag
             (ipolicy,itag,fstatus)
      values ($ipolicy,$itag,'0');
     strcpy(full_dbname,get_car_full_db(ipolicy));
          
     /*----- update ca_ply_period -----*/
     stmp[0]='\0';
     sprintf_s(stmp, sizeof stmp,
             "update %s:ca_ply_period set inumber = ?  "
             " where ipolicy = ? ",full_dbname);
     $prepare pre_AC from $stmp;
     $execute pre_AC using $itag,$ipolicy;
    
   }
   $close curA;
   $free  curA;
   
   /* �N����car616�����load��/dat/car/car616_t.txt */
    strcpy(filename," ");
    sprintf_s(fname, sizeof fname,"car616_t.txt");
    sprintf_s(filename, sizeof filename,"%s/dat/car/%s",sApHome,fname);
    fp=fopen(filename,"w");
    
    sprintf_s(stmt, sizeof stmt,"select iengine,itag from car616 ");
    $prepare pre_616 from $stmt;
    $declare cur_616 cursor for pre_616;  
    
    $open cur_616;        

    while(1)
    {
        $FETCH cur_616 INTO $iengine, $itag;
        if (SQLCODE==SQLNOTFOUND) break;
                    
         fprintf(fp,"%s\t%s\t\n",iengine,itag);
                   
     }
     $close cur_616;

     fclose(fp);

     rc=rptftpinsert(userid,"car616",fname);
     if (rc!=0) {
         sprintf_s(msgbuf, sizeof msgbuf,"%s�g�J/dat/car/���~",fname);
         EWRITE(userid,rc,msgbuf);
         return rc;
     }     
   /* end of process 1 */
   
   /* start process 2 */
   /* ���M����� */
      /* ���N��ڤW��itype��temp�ܼưO���U��,�ѩ���׳��O�������,�ҥHitype = 2 */
      tmp_itype = itype;
      itype = 2;
      $DELETE FROM ca_fill_itag WHERE 1=1;
      WRITELOG( sfp, "DELETE FROM ca_fill_itag Complete !!");      
     
      rc = car616_update_tag(); /* �NClient�ݪ����insert into ca_fill_itag,�Aselect �X�ӧ娮�� */      
      
      if (rc != M_CM_OK)
      {          
          EWRITE(userid, rc, sMsg);
          return rc;
      }      
           
      itype = tmp_itype; /* �Nitype�b���w�^��������A */
   /* end of process 2 */        
   
   if (ply_cnt==0) strcpy(msgbuf,"�L�O���ƥi�ɵP��!");
   else
      sprintf_s(msgbuf, sizeof msgbuf,"�ɵP��:[%5d]�� �j��[%d]���N[%d]!\n",
              ply_cnt,cnt_2,cnt_1);
              
printf("read policy ply_cnt[%d]\n",ply_cnt);
   return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}     
/*--------------------------------------------------------------------*/
long car616_read_policy_by_card()
{
$char   ipolicy[21],iassured[11],iengine[CA_ENGINE_NUM],itag[CA_TAG_NUM];
$char   tag_buf[CA_TAG_NUM],s1[3],s2[5],irel_ply[21];
$char   stmp[1024];
$int    id = 0;

   ply_cnt=cnt_1=cnt_2=0;
   $whenever sqlerror goto errexit;

   $declare curA_card cursor for
     select a.ipolicy,a.iassured,a.iengine,b.itag
       from car616 b,assured_vs_ply a
      where b.iengine  = a.icard
        and (a.itag = ' ' or a.itag is null);
 
   $open curA_card;
   for(;;)
   {
     $fetch curA_card
       into $ipolicy,$iassured,$iengine,$itag;
     if (SQLCODE==SQLNOTFOUND) break;
     ply_cnt++;
     printf("ipolicy:[%s]iengine:[%s]iassured:[%s]itag:[%s]\n",ipolicy,
             iengine,iassured,itag);
     if (ipolicy[5]=='V')
         cnt_1++;
     else
         cnt_2++;
     /*----- insert ncar013_na -----*/
     $insert into ca_080_updtag
             (ipolicy,itag,fstatus)
      values ($ipolicy,$itag,'0');
     strcpy(full_dbname,get_car_full_db(ipolicy));
     /*----- update policy -----*/
     stmp[0]='\0';
     sprintf_s(stmp, sizeof stmp,
             "update %s:policy set itag = ? where ipolicy = ? ",
              full_dbname);
     $prepare pre_AA_card from $stmp;
     $execute pre_AA_card using $itag,$ipolicy;
     /*----- update ca_ply_period -----*/
     stmp[0]='\0';
     sprintf_s(stmp, sizeof stmp,
             "update %s:ca_ply_period set inumber = ?  "
             " where ipolicy = ? ",full_dbname);
     $prepare pre_AC_card from $stmp;
     $execute pre_AC_card using $itag,$ipolicy;
     /*----- update assured_vs_ply -----*/
     $update assured_vs_ply
         set itag = $itag
       where ipolicy = $ipolicy;

     /*----- Ū�����p�O���� -----*/
     stmp[0]='\0';
     sprintf_s(stmp, sizeof stmp,
             "select irelative_ply from %s:ply_relation  "
             " where ipolicy = ? ",full_dbname);
     $prepare pre_R1 from $stmp;
     $execute pre_R1 into $irel_ply:id using $ipolicy;
     if (id<0) continue;
     if (strncmp(irel_ply," ",1)==0) continue;
     $select ipolicy,iassured,iengine
        into $ipolicy,$iassured,$iengine
        from assured_vs_ply
       where ipolicy = $irel_ply
        and (itag = ' ' or itag is null);
     if (SQLCODE==SQLNOTFOUND) continue;
     ply_cnt++;
     printf("ipolicy:[%s]iengine:[%s]iassured:[%s]itag:[%s]\n",ipolicy,
             iengine,iassured,itag);
     if (ipolicy[5]=='V')
         cnt_1++;
     else
         cnt_2++;
     /*----- insert ncar013_na -----*/
     $insert into ca_080_updtag
             (ipolicy,itag,fstatus)
      values ($ipolicy,$itag,'0');
     strcpy(full_dbname,get_car_full_db(ipolicy));
     /*----- update policy -----*/
     stmp[0]='\0';
     sprintf_s(stmp, sizeof stmp,
             "update %s:policy set itag = ? where ipolicy = ? ",
              full_dbname);
     $prepare pre_AA1 from $stmp;
     $execute pre_AA1 using $itag,$ipolicy;
     /*----- update ca_ply_period -----*/
     stmp[0]='\0';
     sprintf_s(stmp, sizeof stmp,
             "update %s:ca_ply_period set inumber = ?  "
             " where ipolicy = ? ",full_dbname);
     $prepare pre_AC1 from $stmp;
     $execute pre_AC1 using $itag,$ipolicy;
     /*----- update assured_vs_ply -----*/
     $update assured_vs_ply
         set itag = $itag
       where ipolicy = $ipolicy;
   }
   $close curA_card;
   $free  curA_card;
   if (ply_cnt==0) {
      EWRITE(userid,0,"�L�O���ƥi�ɵP��!");
      return 0;
   }
   else
      sprintf_s(msgbuf, sizeof msgbuf,"�ɵP��:[%5d]�� �j��[%d]���N[%d]!\n",
              ply_cnt,cnt_2,cnt_1);

   return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}     
/*--------------------------------------------------------------------*/
/*****************
long read_ncar013()
{
$char Nassured[121],Itag[9],Ipolicy[21],Ibig_office[10];
$char Iins_type[7],Fedr_status[2],Iassured[13];
$char iofficer[11],icorps[11],iresource[2],km[3],iquota[7];
$long Dply_end_long,Dply_begin_long,Dpolicy_long,dexpire;
$double Minjured_cover,Mdeath_cover,Mdamage_cover;
$int  id1,id2,id3,rescue_km;
$char stmp[1024];

   $whenever sqlerror goto errexit;

   $declare curB cursor for
     select ipolicy
       into $Ipolicy
       from ca_080_updtag
      where ipolicy[3]=$com;

   $open curB;
   while(1) {
     $FETCH curB;
     if (SQLCODE==SQLNOTFOUND) break;

     stmp[0]='\0';
     sprintf_s(stmp, sizeof stmp,"%s%s %s %s%s%s%s %s %s",
             "SELECT a.ipolicy,b.itag,b.iassured,b.nassured,a.dply_begin,a.iquota,",
             "a.dply_end,a.ibig_office,a.dpolicy,icorps,iresource,iofficer",
             " FROM",list[i].dbname,":ply_relation a,",
             list[i].dbname,":policy b",
             " WHERE a.ipolicy = ? and a.dply_close is not null",
             " and a.ipolicy = b.ipolicy;");

     printf("stmp[%s]\n",stmp);
     $PREPARE preB1 FROM $stmp;
     $DECLARE curB1 CURSOR FOR preB1;
     $OPEN    curB1 USING $Ipolicy;
     $FETCH   curB1
       INTO   $Ipolicy,$Itag,$Iassured,$Nassured,$Dply_begin_long:id1,$iquota,
              $Dply_end_long:id2,$Ibig_office,$Dpolicy_long,
              $icorps,$iresource,$iofficer;
     if (SQLCODE==SQLNOTFOUND)
        continue;
     if (strncmp(iofficer,"Z03029",6)==0)
        strcpy(Ibig_office,iofficer);
     else if (strncmp(iresource,"5",1)==0 && strncmp(iquota,"00305",5)==0) {
             if (strlen(trim(icorps))!=0) {
                $select nvl(dexpire,0) into $dexpire
                   from officer
                  where iofficer = $icorps
                    and fprop = '5';
                if (SQLCODE!=SQLNOTFOUND && dexpire == 0)
                   strcpy(Ibig_office,"Z03029");
             }
     }
     else {
        $select rescue_km into $rescue_km
           from rescue_policy
          where ipolicy = $Ipolicy;
        if (SQLCODE!=SQLNOTFOUND) {
           rfmtlong(rescue_km,"&&",km);
           strcpy(Ibig_office,"KM");
           strcat(Ibig_office,km);
        }
     } 
     if (id1<0)
        Dply_begin_long=0;
     if (id2<0)
        Dply_end_long=0;
     $CLOSE   curB1;
     $FREE    curB1;
     ply_cnt++;
     printf("[%s][%s][%s][%d][%d]",Ipolicy,Nassured,Itag,
             Dply_begin_long,Dply_end_long);

     $INSERT INTO ncar005_m
             (itype,ipolicy,nassured,itag,ibig_office,
              dply_begin,dply_end,dpolicy,iassured)
      VALUES ("E",$Ipolicy,$Nassured,$Itag,$Ibig_office,
              $Dply_begin_long,$Dply_end_long,$Dpolicy_long,$Iassured);

     stmp[0]='\0';
     sprintf_s(stmp, sizeof stmp,"%s%s %s %s%s %s",
             "SELECT iins_type,minjured_cover,mdeath_cover,mdamage_cover,",
             "fedr_status",
             " FROM",list[i].dbname,":ply_ins_type",
             " WHERE ipolicy = ?;");
     printf("%s\n",stmp);
     $PREPARE pre_BB FROM $stmp;
     $DECLARE curBB CURSOR FOR pre_BB;
     $OPEN curBB USING $Ipolicy;
     for(;;)
     {
       $FETCH curBB
         INTO $Iins_type,$Minjured_cover,$Mdeath_cover,$Mdamage_cover,
              $Fedr_status;
       if (SQLCODE==SQLNOTFOUND) break;
       dtl_cnt++;

       $INSERT INTO ncar005_d
               (ipolicy,iins_type,minjured_cover,
                mdeath_cover,mdamage_cover,fedr_status)
        VALUES ($Ipolicy,$Iins_type,$Minjured_cover,
                $Mdeath_cover,$Mdamage_cover,$Fedr_status);
     }
     $CLOSE curBB;
     $FREE  curBB;
   }
   $CLOSE curB;
   $FREE  curB;

   return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}     
*********************/
/*--------------------------------------------------------------------*/
long car616_read_ply()
{
$char  ipolicy[21],iengine[CA_ENGINE_NUM],itag[CA_TAG_NUM],icar_flag[2];
$char  icard[21],fcard_class[2],nassured[121],aassured[91];
$char  itel[21],nbenef[43],dply_begin[11],dply_end[11];
$char  icar_type[3],iins_type[7],dpolicy[11],imodel[3],ibig_sales[11];
$long  mdamage_cover = 0,mins_premium = 0;
$char  stmt[1024],stmt1[512];

   $whenever sqlerror goto errexit;

   sprintf_s(stmt, sizeof stmt,
          "select a.ipolicy,iengine,itag,icar_flag,dpolicy, "
          "       a.icard,fcard_class,nassured,aassured,itel, "
          "       nbenef,dply_begin,dply_end,icar_type,ibrand[1,2],ibig_sales  "
          "  from %s:ply_relation a,%s:policy b  "
          " where dpolicy >= ? and dpolicy <= ?  "
          "   and iofficer[1] = 'B'  "
          "   and dply_close is not null  "
          "   and a.ipolicy = b.ipolicy ",
            list[i].dbname,list[i].dbname);
   printf("stmt[%s]\n",stmt);
   $prepare pre_ply from $stmt;
   $declare cur_ply cursor for pre_ply;
   $open    cur_ply using $dbgn1, $dend1;
   while(1) {
      $fetch cur_ply into $ipolicy,$iengine,$itag,$icar_flag,
             $dpolicy,$icard,$fcard_class,$nassured,$aassured,
             $itel,$nbenef,$dply_begin,$dply_end,$icar_type,
             $imodel,$ibig_sales;
      if (SQLCODE==SQLNOTFOUND) break;
      cnt_p++;
      if (strlen(trim(itag))==0) cnt++;
      printf("ipolicy[%s]iengine[%s]\n",ipolicy,iengine);
      sprintf_s(stmt1, sizeof stmt1,
             "select iins_type,mdamage_cover,mins_premium  "
             "  from %s:ply_ins_type  "
             " where ipolicy = ? ",list[i].dbname);
      $prepare pre_ins from $stmt1;
      $declare cur_ins cursor for pre_ins;
      $open    cur_ins using $ipolicy;
      while(1) {
         $fetch cur_ins into $iins_type,$mdamage_cover,$mins_premium;
         if (SQLCODE==SQLNOTFOUND) break;
         cnt_i++;
         printf("iins_type[%s]mdamage_cover[%d]mins_prem[%d]\n",
                 iins_type,mdamage_cover,mins_premium);
         fprintf(fp2,"%s\t%s\t%d\t%d\t\n",
                 ipolicy,iins_type,mdamage_cover,mins_premium);
      }
      $close cur_ins;
      $free  cur_ins;
      fprintf(fp1,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t\n",
              ipolicy,iengine,itag,icar_flag,dpolicy,icard,
              fcard_class,nassured,aassured,itel,nbenef,dply_begin,
              dply_end,icar_type,imodel,ibig_sales);
   }
   $close cur_ply;
   $free  cur_ply;
   return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car616_read_edr()
{
$char  ipolicy[21],iengine[CA_ENGINE_NUM],itag[CA_TAG_NUM],icar_flag[2],ibig_sales[11];
$char  icard[21],fcard_class[2],nassured[121],aassured[91];
$char  itel[21],nbenef[43],dply_begin[11],dply_end[11];
$char  icar_type[3],iins_type[7],dpolicy[11],pre_policy[21];
$char  imodel[3];
$long  mdamage_cover = 0,mins_premium = 0;
$char  stmt[1024],stmt1[512];

   $whenever sqlerror goto errexit;

   sprintf_s(stmt, sizeof stmt,
          "select a.ipolicy,b.iengine,b.itag,a.icar_flag,a.dpolicy, "
          "       a.icard,a.fcard_class,b.nassured,b.aassured,b.itel, "
          "       b.nbenef,a.dply_begin,a.dply_end,a.icar_type,a.ibrand[1,2], "
          "       a.ibig_sales  "
          "  from %s:edr_relation c,%s:ply_relation a,%s:policy b  "
          " where c.dendorse>= ? and c.dendorse<= ?  "
          "   and c.iofficer[1] = 'B'  "
          "   and c.ipolicy = a.ipolicy  "
          "   and a.dpolicy < ?  "
          "   and c.ipolicy = b.ipolicy order by 1",
            list[i].dbname,list[i].dbname,list[i].dbname);
   printf("stmt[%s]\n",stmt);
   $prepare pre_edr from $stmt;
   $declare cur_edr cursor for pre_edr;
   $open    cur_edr using $dbgn1, $dend1, $dbgn1;
   strcpy(pre_policy," ");
   while(1) {
      $fetch cur_edr into $ipolicy,$iengine,$itag,$icar_flag,
             $dpolicy,$icard,$fcard_class,$nassured,$aassured,
             $itel,$nbenef,$dply_begin,$dply_end,$icar_type,
             $imodel,$ibig_sales;
      if (SQLCODE==SQLNOTFOUND) break;
      if (strcmp(ipolicy,pre_policy)==0) continue;
      strcpy(pre_policy,ipolicy);
      cnt_p++;
      if (strlen(trim(itag))==0) cnt++;
      printf("ipolicy[%s]iengine[%s]\n",ipolicy,iengine);
      sprintf_s(stmt1, sizeof stmt1,
             "select iins_type,mdamage_cover,mins_premium  "
             "  from %s:ply_ins_type  "
             " where ipolicy = ? ",list[i].dbname);
      $prepare pre_edrins from $stmt1;
      $declare cur_edrins cursor for pre_edrins;
      $open    cur_edrins using $ipolicy;
      while(1) {
         $fetch cur_edrins into $iins_type,$mdamage_cover,$mins_premium;
         if (SQLCODE==SQLNOTFOUND) break;
         cnt_i++;
         printf("iins_type[%s]mdamage_cover[%d]mins_prem[%d]\n",
                 iins_type,mdamage_cover,mins_premium);
         fprintf(fp2,"%s\t%s\t%d\t%d\t\n",
                 ipolicy,iins_type,mdamage_cover,mins_premium);
      }
      $close cur_edrins;
      $free  cur_edrins;
      fprintf(fp1,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t\n",
              ipolicy,iengine,itag,icar_flag,dpolicy,icard,
              fcard_class,nassured,aassured,itel,nbenef,dply_begin,
              dply_end,icar_type,imodel,ibig_sales);
   }
   $close cur_edr;
   $free  cur_edr;
   return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car616_read_clm()
{
$char  ipolicy[21],daccident[11],iacc_reason[3],iins_type[7];
$char  iofficer[11];
$char  stmt[1024];

   $whenever sqlerror goto errexit;

   sprintf_s(stmt, sizeof stmt,
          "select a.ipolicy,date(a.daccident),iacc_reason, "
          "       nvl(c.iins_type,' '),iofficer  "
          "  from %s:appraisal a,%s:adjustment_ply b, "
          "       outer %s:app_ins_type c "
          " where ((dclaim >= ? and dclaim <= ?)  "
          "    or (dapp_entry >= ? and dapp_entry <= ?))  "
          "   and a.fcard_class = '2'  "
          "   and a.iclaim = b.iclaim  "
          "   and a.iclaim = c.iclaim ",
            list[i].dbname,list[i].dbname,list[i].dbname);
   printf("stmt[%s]\n",stmt);
   $prepare pre_clm from $stmt;
   $declare cur_clm cursor for pre_clm;
   $open    cur_clm using $dbgn3, $dend3, $dbgn1, $dend1;
   while(1) {
      $fetch cur_clm into $ipolicy,$daccident,$iacc_reason,
             $iins_type,$iofficer;
      if (SQLCODE==SQLNOTFOUND) break;
      if (iofficer[0]!='B') continue;
      cnt_c++;
      printf("ipolicy[%s],daccident[%s]iins_type[%s]\n",
             ipolicy,daccident,iins_type);
      fprintf(fp3,"%s\t%s\t%s\t%s\t\n",ipolicy,iins_type,daccident,
              iacc_reason);
   }
   $close cur_clm;
   $free  cur_clm;
   sprintf_s(stmt, sizeof stmt,
          "select a.ipolicy,date(a.daccident),iacc_reason, "
          "       '21',iofficer  "
          "  from %s:appraisal a,%s:adjustment_ply b "
          " where ((dclaim >= ? and dclaim <= ?)  "
          "    or (dapp_entry >= ? and dapp_entry <= ?))  "
          "   and a.fcard_class = '1'  "
          "   and a.iclaim = b.iclaim ",
            list[i].dbname,list[i].dbname);
   printf("stmt[%s]\n",stmt);
   $prepare pre_vic from $stmt;
   $declare cur_vic cursor for pre_vic;
   $open    cur_vic using $dbgn3, $dend3, $dbgn1, $dend1;
   while(1) {
      $fetch cur_vic into $ipolicy,$daccident,$iacc_reason,
             $iins_type,$iofficer;
      if (SQLCODE==SQLNOTFOUND) break;
      if (iofficer[0]!='B') continue;
      cnt_c++;
      printf("ipolicy[%s],daccident[%s]iins_type[%s]\n",
             ipolicy,daccident,iins_type);
      fprintf(fp3,"%s\t%s\t%s\t%s\t\n",ipolicy,iins_type,daccident,
              iacc_reason);
   }
   $close cur_vic;
   $free  cur_vic;
   return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

long car616_read_bis()
{
$char  ipolicy[21],icard[21],fassured[13],iassured[13],iassured_ext[3],nassured[121];
$char  ibirth[11],fsex[3],fmarriage[5],nuser[19],aassured[91],aassured_zip[CA_ZIP],itel[21];
$char  itel_night[21],mobil_phone[21],iemail[51];
$int   qcylinder,dmg_acc_1st,dmg_acc_2nd,dmg_acc_3rd,qpro_month;
$char  iengine[CA_ENGINE_NUM],ibody[CA_BODY_NUM],itag[CA_TAG_NUM];
$double mcar_price,qpt,psex_age,psex_age_damage,mequipment;
$char  nequipment[31],flimit[2],fcal_way[2],fpt[2];
$char  napplicant[121],dbirth[11],dissue[11];
$char  iroute[21],fapplicant[2],fsex_appl[2],fcard_class[5];

$int   qply_period,mdmg_prem,mlia_prem,qnext_year,qprovision,qcount;
$int   minjured_cover,mdeath_cover,mdamage_cover,mdeduct,mins_premium;
$char  irelative_ply[21],ilast_ply[21],inext_ply[21];
$char  dply_begin[11],dply_end[11],iissue_ym[8],ipro_year[5],ibrand[9];
$char  icar_type[3],ibig_comp[2];
$char  ibig_office[10],ibig_sales[11],iresource[15];
$char  ibroker[11],iofficer[11],dentry[11],dpolicy[11],dply_close[11],dtransfer[11];
$char  nbranch[41],nchi_abv[13],nchi_full[41],nchi_full_in[41],icar_flag[5];
$char  iofficer_prmt[11],iquota_prmt[7],ileader_prmt[11];
$char  iins_type[7],fedr_status[9],dendorse[11],provision[21],iclaim_note[7];


$char  stmt[7000],stmt1[7000];

   $whenever sqlerror goto errexit;

   sprintf_s(stmt, sizeof stmt,
          "select a.ipolicy,a.icard,                                                   "
          "       decode(a.fassured,'1','�ꤺ�۵M�H','3','��~�۵M�H',                 "
          "                         '5','�۵M�HID���~','2','�ꤺ�k�H','4','��~�k�H',  "
          "                         '6','�k�HID���~') as fassured,                     "
          "       a.iassured,a.iassured_ext,a.nassured,  "
          "       nvl(substr(a.dbirth,7,4) || '/' || substr(dbirth,1,2) || substr(dbirth,3,3),' ') as ibirth,  "
          "       decode(a.fsex,'1','�k','2','�k','�k�H') as fsex,                        "
          "       decode(a.fmarriage,'1','�w�B','2','���B',' ') as fmarriage,          "
          "       nvl(a.nuser,' '),a.aassured,a.aassured_zip,a.itel,                   "
          "       a.itel_night,a.mobil_phone,a.iemail,a.qcylinder,a.iengine,nvl(a.ibody,' '),nvl(a.itag,' '),    "
          "       a.mcar_price,a.nequipment,nvl(a.flimit,' '),a.fcal_way,a.qpt,a.fpt,          "
          "       a.psex_age,a.psex_age_damage,a.dmg_acc_1st,a.dmg_acc_2nd,           "
          "       a.dmg_acc_3rd,a.qpro_month,a.napplicant,  "
          "       nvl(substr(a.dbirth,7,4) || '/' || substr(a.dbirth,1,2) || substr(a.dbirth,3,3),' ') as dbirth,  "
          "       nvl(substr(a.dissue,7,4) || '/' || substr(a.dissue,1,2) || substr(a.dissue,3,3),' ') as dissue,  "
          "       nvl(a.mequipment,0),a.iroute,a.fapplicant,a.fsex_appl,                     "
          "       decode(b.fcard_class,'1','�j��','2','���N') as fcard_class,         "
          "       nvl(b.irelative_ply,' '),nvl(b.ilast_ply,' '),nvl(b.inext_ply,' '),b.qply_period,              "
          "       nvl(substr(b.dply_begin,7,4) || '/' || substr(b.dply_begin,1,2) || substr(b.dply_begin,3,3),' ') as dply_begin,  "
          "       nvl(substr(b.dply_end,7,4) || '/' || substr(b.dply_end,1,2) || substr(b.dply_end,3,3),' ') as dply_end,  "
          "       case b.iissue_ym when '' then '' else trunc(b.iissue_ym[1,2]+1911) || b.iissue_ym[3,5] end as iissue_ym,  "
          "       b.ipro_year,b.ibrand,           "
          "       b.icar_type,b.mdmg_prem,b.mlia_prem,b.ibig_comp,      "
          "       b.ibig_office[1,3],b.ibig_sales,                                         "
          "       decode(b.iresource,'1','��t���O�N','2','�g���H','3','���u����',    "
          "              '4','�@��¾��','5','������P','6','���Y���~���u',            "
          "              '9','���u','8','���Y���~�k�H','A','��t�~�O�N',              "
          "              'B','��L�O�N','C','�����Ʒ~','D','�~�ȭ�','E','�M�׷~��',   "
          "              'H','��t�~��','K','����~��','Z','���u����',                "
          "              'L','���I�q��',' ') as iresource,                            "
          "       nvl(b.ibroker,' '),b.iofficer,  "
          "       nvl(substr(b.dentry,7,4) || '/' || substr(b.dentry,1,2) || substr(b.dentry,3,3),' ') as dentry,  "
          "       nvl(substr(b.dpolicy,7,4) || '/' || substr(b.dpolicy,1,2) || substr(b.dpolicy,3,3),' ') as dpolicy,  "
          "       nvl(substr(b.dply_close,7,4) || '/' || substr(b.dply_close,1,2) || substr(b.dply_close,3,3),' ') as dply_close,  "
          "       nvl(substr(b.dtransfer,7,4) || '/' || substr(b.dtransfer,1,2) || substr(b.dtransfer,3,3),' ') as dtransfer,  "
          "(select nchi_full from branch where ibranch = b.ibranch) as nchi_full,       "
          "(select nbranch from sa_branch_type where ibranch = b.iquota) as nbranch,       "
          "(select nchi_abv from branch where ibranch = b.icomp_in) as nchi_abv,      "
          "(select nchi_full from branch where ibranch = b.ibranch_in) as nchi_full_in,  "
          "      decode(b.icar_flag,'1','�s��','2','�¨�') as icar_flag,              "
          "      b.qnext_year,nvl(b.iofficer_prmt,' '),nvl(b.iquota_prmt,' '),nvl(b.ileader_prmt,' '),           "
          "      b.qprovision,c.iins_type,c.minjured_cover,c.mdeath_cover,            "
          "      c.mdamage_cover,c.mdeduct,c.mins_premium,                            "
          "      decode(c.fedr_status,'1','���h','2','�j�h','3','�h���h�O',           "
          "     '4','��[','5','���','���h') as fedr_status,nvl(c.dendorse,' '),nvl(c.provision,' '),  "
          "      (select sum(qcount) from policy_main where ipolicy1=a.ipolicy[1,13]  "
          "       and ipolicy2=trim(a.ipolicy[14,17])) as qcount,                     "
          "      decode((select count(*) from ca_clm_process where ipolicy=a.ipolicy),'0','�L�X�I','���X�I') as  iclaim_note  "
          "  from %s:policy a,%s:ply_relation b,%s:ply_ins_type c                     "
          " where (b.dpolicy >= ? and b.dpolicy <= ?)                                 "
          "   and b.iofficer[1] = 'B'                                                 "
          "   and b.dply_close is not null                                            "
          "   and a.ipolicy = b.ipolicy  and a.ipolicy = c.ipolicy",list[i].dbname,list[i].dbname,list[i].dbname);                     
   printf("stmt[%s]\n",stmt);
   $prepare pre_bis from $stmt;
   $declare cur_bis cursor for pre_bis;
   $open    cur_bis using $dbgn1, $dend1;
   while(1) {
      $fetch cur_bis into $ipolicy,$icard,$fassured,$iassured,$iassured_ext,$nassured,
                          $ibirth,$fsex,$fmarriage,$nuser,$aassured,$aassured_zip,$itel,
                          $itel_night,$mobil_phone,$iemail,$qcylinder,
                          $iengine,$ibody,$itag,$mcar_price,
                          $nequipment,$flimit,$fcal_way,$qpt,$fpt,$psex_age,
                          $psex_age_damage,$dmg_acc_1st,$dmg_acc_2nd,
                          $dmg_acc_3rd,$qpro_month,$napplicant,$dbirth,$dissue,
                          $mequipment,$iroute,$fapplicant,$fsex_appl,$fcard_class,
                          $irelative_ply,$ilast_ply,$inext_ply,$qply_period,
                          $dply_begin,$dply_end,$iissue_ym,$ipro_year,$ibrand,
                          $icar_type,$mdmg_prem,$mlia_prem,$ibig_comp,
                          $ibig_office,$ibig_sales,$iresource,
                          $ibroker,$iofficer,$dentry,$dpolicy,$dply_close,$dtransfer,
                          $nchi_full,$nbranch,$nchi_abv,$nchi_full_in,$icar_flag,
                          $qnext_year,$iofficer_prmt,$iquota_prmt,$ileader_prmt,
                          $qprovision,$iins_type,$minjured_cover,$mdeath_cover,
                          $mdamage_cover,$mdeduct,$mins_premium,
                          $fedr_status,$dendorse,$provision,$qcount,$iclaim_note;
                          
      if (SQLCODE==SQLNOTFOUND) break;
      
      printf("ipolicy[%s]\n",ipolicy);
      fprintf(fp4,"\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%9d\",\"%s\",\"%s\",\"%s\",\"%5.1f\",\"%s\",\"%s\",\"%s\",\"%4.1f\",\"%s\",\"%15.12f\",\"%15.12f\",\"%9d\",\"%9d\",\"%9d\",\"%9d\",\"%s\",\"%s\",\"%s\",\"%5.1f\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%9d\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%9d\",\"%9d\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%9d\",\"%s\",\"%s\",\"%s\",\"%9d\",\"%s\",\"%9d\",\"%9d\",\"%9d\",\"%9d\",\"%9d\",\"%s\",\"%s\",\"%s\",\"%9d\",\"%s\"\n",
              ipolicy,icard,fassured,iassured,iassured_ext,nassured,
              ibirth,fsex,fmarriage,nuser,aassured,aassured_zip,itel,
              itel_night,mobil_phone,iemail,qcylinder,
              iengine,ibody,itag,mcar_price,
              nequipment,flimit,fcal_way,qpt,fpt,psex_age,
              psex_age_damage,dmg_acc_1st,dmg_acc_2nd,
              dmg_acc_3rd,qpro_month,napplicant,dbirth,dissue,
              mequipment,iroute,fapplicant,fsex_appl,fcard_class,
              irelative_ply,ilast_ply,inext_ply,qply_period,
              dply_begin,dply_end,iissue_ym,ipro_year,ibrand,
              icar_type,mdmg_prem,mlia_prem,ibig_comp,
              ibig_office,ibig_sales,iresource,
              ibroker,iofficer,dentry,dpolicy,dply_close,dtransfer,
              nchi_full,nbranch,nchi_abv,nchi_full_in,icar_flag,
              qnext_year,iofficer_prmt,iquota_prmt,ileader_prmt,
              qprovision,iins_type,minjured_cover,mdeath_cover,
              mdamage_cover,mdeduct,mins_premium,
              fedr_status,dendorse,provision,qcount,iclaim_note);
   }
   
   $whenever sqlerror goto errexit;
   
   sprintf_s(stmt1, sizeof stmt1,
          "select a.ipolicy,a.icard,                                                   "
          "       decode(a.fassured,'1','�ꤺ�۵M�H','3','��~�۵M�H',                 "
          "                         '5','�۵M�HID���~','2','�ꤺ�k�H','4','��~�k�H',  "
          "                         '6','�k�HID���~') as fassured,                     "
          "       a.iassured,a.iassured_ext,a.nassured,  "
          "       nvl(substr(a.dbirth,7,4) || '/' || substr(dbirth,1,2) || substr(dbirth,3,3),' ') as ibirth,  "
          "       decode(a.fsex,'1','�k','2','�k','�k�H') as fsex,                        "
          "       decode(a.fmarriage,'1','�w�B','2','���B',' ') as fmarriage,          "
          "       nvl(a.nuser,' '),a.aassured,a.aassured_zip,a.itel,                   "
          "       a.itel_night,a.mobil_phone,a.iemail,a.qcylinder,a.iengine,nvl(a.ibody,' '),nvl(a.itag,' '),    "
          "       a.mcar_price,a.nequipment,nvl(a.flimit,' '),a.fcal_way,a.qpt,a.fpt,          "
          "       a.psex_age,a.psex_age_damage,a.dmg_acc_1st,a.dmg_acc_2nd,           "
          "       a.dmg_acc_3rd,a.qpro_month,a.napplicant,  "
          "       nvl(substr(a.dbirth,7,4) || '/' || substr(a.dbirth,1,2) || substr(a.dbirth,3,3),' ') as dbirth,  "
          "       nvl(substr(a.dissue,7,4) || '/' || substr(a.dissue,1,2) || substr(a.dissue,3,3),' ') as dissue,  "
          "       nvl(a.mequipment,0),a.iroute,a.fapplicant,a.fsex_appl,                     "
          "       decode(b.fcard_class,'1','�j��','2','���N') as fcard_class,         "
          "       nvl(b.irelative_ply,' '),nvl(b.ilast_ply,' '),nvl(b.inext_ply,' '),b.qply_period,              "
          "       nvl(substr(b.dply_begin,7,4) || '/' || substr(b.dply_begin,1,2) || substr(b.dply_begin,3,3),' ') as dply_begin,  "
          "       nvl(substr(b.dply_end,7,4) || '/' || substr(b.dply_end,1,2) || substr(b.dply_end,3,3),' ') as dply_end,  "
          "       case b.iissue_ym when '' then '' else trunc(b.iissue_ym[1,2]+1911) || b.iissue_ym[3,5] end as iissue_ym,  "
          "       b.ipro_year,b.ibrand,           "
          "       b.icar_type,b.mdmg_prem,b.mlia_prem,b.ibig_comp,      "
          "       b.ibig_office[1,3],b.ibig_sales,                                         "
          "       decode(b.iresource,'1','��t���O�N','2','�g���H','3','���u����',    "
          "              '4','�@��¾��','5','������P','6','���Y���~���u',            "
          "              '9','���u','8','���Y���~�k�H','A','��t�~�O�N',              "
          "              'B','��L�O�N','C','�����Ʒ~','D','�~�ȭ�','E','�M�׷~��',   "
          "              'H','��t�~��','K','����~��','Z','���u����',                "
          "              'L','���I�q��',' ') as iresource,                            "
          "       nvl(b.ibroker,' '),b.iofficer,  "
          "       nvl(substr(b.dentry,7,4) || '/' || substr(b.dentry,1,2) || substr(b.dentry,3,3),' ') as dentry,  "
          "       nvl(substr(b.dpolicy,7,4) || '/' || substr(b.dpolicy,1,2) || substr(b.dpolicy,3,3),' ') as dpolicy,  "
          "       nvl(substr(b.dply_close,7,4) || '/' || substr(b.dply_close,1,2) || substr(b.dply_close,3,3),' ') as dply_close,  "
          "       nvl(substr(b.dtransfer,7,4) || '/' || substr(b.dtransfer,1,2) || substr(b.dtransfer,3,3),' ') as dtransfer,  "
          "(select nchi_full from branch where ibranch = b.ibranch) as nchi_full,       "
          "(select nbranch from sa_branch_type where ibranch = b.iquota) as nbranch,       "
          "(select nchi_abv from branch where ibranch = b.icomp_in) as nchi_abv,      "
          "(select nchi_full from branch where ibranch = b.ibranch_in) as nchi_full_in,  "
          "      decode(b.icar_flag,'1','�s��','2','�¨�') as icar_flag,              "
          "      b.qnext_year,nvl(b.iofficer_prmt,' '),nvl(b.iquota_prmt,' '),nvl(b.ileader_prmt,' '),           "
          "      b.qprovision,c.iins_type,c.minjured_cover,c.mdeath_cover,            "
          "      c.mdamage_cover,c.mdeduct,c.mins_premium,                            "
          "      decode(c.fedr_status,'1','���h','2','�j�h','3','�h���h�O',           "
          "     '4','��[','5','���','���h') as fedr_status,nvl(c.dendorse,' '),nvl(c.provision,' '),  "
          "      (select sum(qcount) from policy_main where ipolicy1=a.ipolicy[1,13]  "
          "       and ipolicy2=trim(a.ipolicy[14,17])) as qcount,                     "
          "      decode((select count(*) from ca_clm_process where ipolicy=a.ipolicy),'0','�L�X�I','���X�I') as  iclaim_note  "
          "  from %s:policy a,%s:ply_relation b,%s:ply_ins_type c,%s:edr_relation d      "
          " where (d.dendorse >= ? and d.dendorse <= ?)                               "
          "   and d.iofficer[1] = 'B'                                                 "
          "   and (b.dpolicy < ?)                                                     "
          "   and a.ipolicy = b.ipolicy  and a.ipolicy = c.ipolicy                    "
          "   and a.ipolicy = d.ipolicy",list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname);
   printf("stmt1[%s]\n",stmt1);
   
   $prepare pre_edr_bis from $stmt1;
   $declare cur_edr_bis cursor for pre_edr_bis;
   $open    cur_edr_bis using $dbgn1, $dend1, $dbgn1;
   while(1) {
      $fetch cur_edr_bis into $ipolicy,$icard,$fassured,$iassured,$iassured_ext,$nassured,
                          $ibirth,$fsex,$fmarriage,$nuser,$aassured,$aassured_zip,$itel,
                          $itel_night,$mobil_phone,$iemail,$qcylinder,
                          $iengine,$ibody,$itag,$mcar_price,
                          $nequipment,$flimit,$fcal_way,$qpt,$fpt,$psex_age,
                          $psex_age_damage,$dmg_acc_1st,$dmg_acc_2nd,
                          $dmg_acc_3rd,$qpro_month,$napplicant,$dbirth,$dissue,
                          $mequipment,$iroute,$fapplicant,$fsex_appl,$fcard_class,
                          $irelative_ply,$ilast_ply,$inext_ply,$qply_period,
                          $dply_begin,$dply_end,$iissue_ym,$ipro_year,$ibrand,
                          $icar_type,$mdmg_prem,$mlia_prem,$ibig_comp,
                          $ibig_office,$ibig_sales,$iresource,
                          $ibroker,$iofficer,$dentry,$dpolicy,$dply_close,$dtransfer,
                          $nchi_full,$nbranch,$nchi_abv,$nchi_full_in,$icar_flag,
                          $qnext_year,$iofficer_prmt,$iquota_prmt,$ileader_prmt,
                          $qprovision,$iins_type,$minjured_cover,$mdeath_cover,
                          $mdamage_cover,$mdeduct,$mins_premium,
                          $fedr_status,$dendorse,$provision,$qcount,$iclaim_note;
                                              
      if (SQLCODE==SQLNOTFOUND) break;
      
      printf("ipolicy1[%s]\n",ipolicy);
      fprintf(fp4,"\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%9d\",\"%s\",\"%s\",\"%s\",\"%5.1f\",\"%s\",\"%s\",\"%s\",\"%4.1f\",\"%s\",\"%15.12f\",\"%15.12f\",\"%9d\",\"%9d\",\"%9d\",\"%9d\",\"%s\",\"%s\",\"%s\",\"%5.1f\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%9d\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%9d\",\"%9d\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%9d\",\"%s\",\"%s\",\"%s\",\"%9d\",\"%s\",\"%9d\",\"%9d\",\"%9d\",\"%9d\",\"%9d\",\"%s\",\"%s\",\"%s\",\"%9d\",\"%s\"\n",
              ipolicy,icard,fassured,iassured,iassured_ext,nassured,
              ibirth,fsex,fmarriage,nuser,aassured,aassured_zip,itel,
              itel_night,mobil_phone,iemail,qcylinder,
              iengine,ibody,itag,mcar_price,
              nequipment,flimit,fcal_way,qpt,fpt,psex_age,
              psex_age_damage,dmg_acc_1st,dmg_acc_2nd,
              dmg_acc_3rd,qpro_month,napplicant,dbirth,dissue,
              mequipment,iroute,fapplicant,fsex_appl,fcard_class,
              irelative_ply,ilast_ply,inext_ply,qply_period,
              dply_begin,dply_end,iissue_ym,ipro_year,ibrand,
              icar_type,mdmg_prem,mlia_prem,ibig_comp,
              ibig_office,ibig_sales,iresource,
              ibroker,iofficer,dentry,dpolicy,dply_close,dtransfer,
              nchi_full,nbranch,nchi_abv,nchi_full_in,icar_flag,
              qnext_year,iofficer_prmt,iquota_prmt,ileader_prmt,
              qprovision,iins_type,minjured_cover,mdeath_cover,
              mdamage_cover,mdeduct,mins_premium,
              fedr_status,dendorse,provision,qcount,iclaim_note);
              
   } 
   $close cur_bis;
   $free  cur_bis;        
   $close cur_edr_bis;
   $free  cur_edr_bis;
   return M_CM_OK;
   
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/
/* Read ��O��� into ca_fill_itag                                    */
/* Purpose: 1. ��user��Jñ����,�N������϶����ҥX���O��,             
            ��X�O�_���e�O�渹,�����ܥN������O��C
            
            2. ��X�e�O���,�A��X�ӫe�O��O�_���ʨ��P? 
            
            3. �Y���ʨ��P,�h�H���覡,�H�O�d��key��,
               ����O�󪺨��P�X���                                   */
/* Add by Julia Han in 2009/05/26                                     */   
/*--------------------------------------------------------------------*/         
long car616_get_renew()
{
$char   ipolicy[21],icard[21],itag[CA_TAG_NUM];
$char   ilast_ply[21];
$char   stmp[1024],stmt[1024];

char  sIupcompShort[2], policyDB[21], policyDBname[41];

   $whenever sqlerror goto errexit;
   
printf("bgn1[%s],dend1[%s],dbgn2[%s],dend2[%s]\n",dbgn1,dend1,dbgn2,dend2);

   for (i=0;i<count_db;i++) {
   	  sprintf_s(stmt, sizeof stmt,
                 "select a.ipolicy,b.itag,a.ilast_ply  "
                 "  from %s:ply_relation a,%s:policy b  "
                 " where dpolicy >= ? and dpolicy <= ?  "
                 "   and a.ilast_ply is not null  "
                 "   and a.ilast_ply <> ' '  "
                 "   and dply_close is not null  "
				 "	 and a.fedr_class != '1'  "
                 "   and a.ipolicy = b.ipolicy and nvl(b.itag,' ') != ' '",list[i].dbname,list[i].dbname);
        
/*printf("stmt[%s]\n",stmt);*/
        $prepare renew_ply from $stmt;
        $declare cur_renew_ply cursor for renew_ply;
        $open    cur_renew_ply using $dbgn1, $dend1;
        while(1) {
               $fetch cur_renew_ply into $ipolicy,$itag,$ilast_ply;
          
               if (SQLCODE==SQLNOTFOUND) break;
               
               sIupcompShort[0] = ilast_ply[2]; /* �O�渹�ĤT�X */
               sIupcompShort[1] = '\0';
               strcpy( policyDB, get_upcomp(sIupcompShort, USE_SHORT_BRANCH_ID, USE_BRANCH_ID));
               strcpy( policyDBname, get_full_dbname(policyDB)); 
               
               sprintf_s(stmp, sizeof stmp,"select icard from %s:policy  "
                            "where ipolicy = ?  "
                            "and (itag is null or itag = ' ')",policyDBname);
                             
printf("stmp[%s]\n",stmp);
                             
               $prepare stmt1 FROM $stmp;
               $declare cur1 CURSOR FOR stmt1;
               $OPEN cur1 USING $ilast_ply;
               $FETCH cur1 INTO $icard;               
               
printf("icard[%s][%s]\n",icard, ilast_ply);
               /* �䤣���~��fetch,�䪺��N�N�d���򨮵P�g�Jca_fill_itag */
               if (SQLCODE==SQLNOTFOUND) continue;
               else
               {
                   $whenever sqlerror continue;
                   $INSERT INTO ca_fill_itag VALUES($icard,$itag);
		   if (SQLCODE==-239) 
                   {
                       $whenever sqlerror goto errexit;
                       continue;
                   }
                   $whenever sqlerror goto errexit;
               }               
        }
   }

   return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}     

/*---------------------------------------------------------end program*/


/* key_field(���[���X), itag, dply_begin, dissue, icard */
long car616_get_TVMETPxx()
{
    $char  ipolicy[21],icard[21],itag[CA_TAG_NUM],ibody[21],dply_begin[11],dissue[11];
    $char  tmp_icard[23],tmp_dply_bgn[9],tmp_dissue[9];
    $char  stmp[1024],stmt[1024],FullGetName[101];
    int    icnt,iFlag=0;

    $whenever sqlerror goto errexit;
    /* client�ݱNuser���Ѫ�����諸�����ftp��/dat/car/ */
    sprintf_s(fname, sizeof fname,"car616_t.txt");
    sprintf_s(FullGetName, sizeof FullGetName, "%s/dat/car/%s", sApHome, fname); 
    printf("FullGetName[%s]\n",FullGetName);

    if ((report=fopen(FullGetName,"rt"))==NULL)
    {
        sprintf_s(sMsg, sizeof sMsg, "Cannot open ftp file: %s\n", FullGetName);
        printf("%s", sMsg);
        return M_CM_OPEN_FILE_FAIL;
    }

    if ((bp=malloc(recLen))==NULL)
    {
        printf("System malloc failed  !\n");
        return FAIL;
    }
    
    delimiter = '\t'; /* ���j�Ÿ� */

    icnt = 0;
    while(fgets(bp,recLen,report))
    {
        if (feof(report)) break;
        iFlag  = 0;
        offset = 0;
       
        strcpy(ibody       , "");
        strcpy(itag        , "");
        strcpy(dply_begin  , "");
        strcpy(dissue      , "");
        strcpy(icard       , "");

        strcpy(tmp_dply_bgn, "");
        strcpy(tmp_dissue  , "");
        strcpy(tmp_icard   , "");

        /* ��ƨ��o���Ǥ��i�ܰ� */
        GetData(ibody       , sizeof(ibody)       , delimiter);
        GetData(itag        , sizeof(itag)        , delimiter);
        GetData(tmp_dply_bgn, sizeof(tmp_dply_bgn), delimiter);
        GetData(tmp_dissue  , sizeof(tmp_dissue)  , delimiter);
        GetData(tmp_icard   , sizeof(tmp_icard)   , delimiter);

        formatDate( tmp_dply_bgn, dply_begin);  /* YYYYMMDD => MM/DD/YYYY */
        formatDate( tmp_dissue  , dissue);      /* YYYYMMDD => MM/DD/YYYY */

        strcpy(tmp_icard, trim(tmp_icard));
        strncpy(icard, trim(tmp_icard)+2,20);

        $whenever sqlerror continue;

INS239:
       
        $INSERT INTO ca_fill_itag
    	        ( key_field, itag, dply_begin, dissue, icard)
    	 VALUES ( $ibody ,$itag ,$dply_begin ,$dissue ,$icard);
    	
        if (SQLCODE==-239 && iFlag == 0) 
        {        
            $DELETE FROM ca_fill_itag 
              WHERE key_field = $ibody 
                AND itag      = $itag;
            printf("-239�Gibody[%s], itag[%s]\n", ibody,itag);    

            iFlag = 1;
            goto INS239;                
        }
        
    	icnt++;  
        printf("icnt[%d]\n", icnt);  

        $whenever sqlerror goto errexit;      
    }
            


    fclose(report);
    return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}


int formatDate(char sTmp[8],char sDate[11])
{
        if( sTmp[0]==' ' || sTmp[0] == '0' || sTmp[0] == '\0')
        {   strcpy( sDate, " ");
            return;
        }
        sDate[0] = sTmp[4];
        sDate[1] = sTmp[5];
        sDate[2] = '/';
        sDate[3] = sTmp[6];
        sDate[4] = sTmp[7];
        sDate[5] = '/';
        sDate[6] = sTmp[0];
        sDate[7] = sTmp[1];
        sDate[8] = sTmp[2];
        sDate[9] = sTmp[3];
        sDate[10] = '\0';
}

/*********************************************************************************************/
