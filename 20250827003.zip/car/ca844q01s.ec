/************************************************/
/*   PROGRAM : ca844q01s.ec                     */
/*   MODIFY  : cyrus                            */
/*   DATE    : 104.12.15                        */
/*   NOTE    : ����J�߮פ�x���Ӫ�             */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
$include datetime.h;
#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"

$char DBName[05], iForm_Tp[03], outputf[N_FILE+1];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1];
$char  userid[11];

char  msgbuf[100];
$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;
$int  PERIOD;

static int  max_count;

DBinfo  *list;
int     count_db;

$char sIbranch[BRANCH_ID], sIofficer[EMPLOYEE_ID];
$char sNname[EMPLOYEE_NAME];
$char sIclaim[CLAIM_NUM], sFcard_class[2], sDclaim[YYYYMMDD];
$char sYearMonth[7];
$char sIadjuster[EMPLOYEE_ID], sFclose[2], sIins_type[INSURANCE_TYPE];
$char sDclose[13], victim[11], flast[2];
$char sDgroup[11];
$char dgroup[11];
$long ldgroup;
$char sNgroup[5],sNadjuster[11];
$char sIupbranch[3], sNupgroup[11];
$char sFins_grp[2];
$char sBgnDate_e[11], sEndDate_e[11], sBgnDate[11], sEndDate[11];
$char sBasicDate[11], sBasicDate_e[11];
$char sIroute[21];
$long lBgnDate, lEndDate;
$long lBasicDate;
$long iQorder, qmonth, lMins_stl;
$char ivictim[11];
$long qdmg_claim, qdmg_close, qdmg_nopay;       /** ���l **/
$long qlia_claim, qlia_close, qlia_nopay;       /** �d�� **/
$long qburg_claim, qburg_close, qburg_nopay;    /** �W�[�ѵs�����Ѩ��l�������X **/
$long qcomp_claim, qcomp_close, qcomp_nopay;    /** �j�� **/
$long qwea_claim, qwea_close, qwea_nopay;       /** �]�� **/
$long mins_stl;
$date lDclaim;
$char iclaim[21];
$int  iclose_type;
$int  icnt;
$char stmt[2000];
$char stmt3[9500];
$char sIinsType[INSURANCE_TYPE];
$char sIinsTypeB[INSURANCE_TYPE];

$char iins_item[INSURANCE_TYPE];

int qlia, qburg, qdmg, qwea;
$int iTmp;
$int iMaxCnt;
$int id1;
$int iMonthDiff;

$char m_bgn[11], m_end[11], r_bgn[11], r_end[11];
$char server[3];
$char iofficer[11];

long car844_build();
void car844_title();
long car844_body();
long car844_print();
void car844_print2();
int DiffMonth();

/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
   int rc;

   batchinit();
   strcpy(DBName   ,  isNULLstr(argv[1]));
   strcpy(userid   ,  isNULLstr(argv[2]));
   strcpy(sBgnDate ,  isNULLstr(argv[3]));
   strcpy(sEndDate ,  isNULLstr(argv[4]));

   strcpy(sBasicDate ,  isNULLstr(argv[5]));

   strcpy(outputf  ,  isNULLstr(argv[6]));

   strcpy(sBgnDate_e, cm_to_infdate(sBgnDate));
   strcpy(sEndDate_e, cm_to_infdate(sEndDate));

   strcpy(sBasicDate_e, cm_to_infdate(sBasicDate));

   rstrdate(sBgnDate_e, &lBgnDate);
   rstrdate(sEndDate_e, &lEndDate);

   rstrdate(sBasicDate_e, &lBasicDate);

   printf("sBgnDate_e[%s] sEndDate_e[%s]\n",sBgnDate_e , sEndDate_e);

   rc=car844_get_db();
   if (rc!=M_CM_OK)
      return rc;

   rc = car844_build();
   if (rc != M_CM_OK)
       return rc;

   return M_CM_OK;

errexit:
   printf("main :SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/

long car844_build()
{
   $char  TitleFmt[N_FILE+1],BodyFmt[N_FILE+1];
   int    rc;

   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT;

   if (db_select(DBName) == False)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   rc = car844_body();
   if (rc != M_CM_OK)
       return rc;

   rc = car844_print();
   if (rc != M_CM_OK)
       return rc;

   rc = car844_print_2();
   if (rc != M_CM_OK)
       return rc;

   return M_CM_OK;

errexit:
   EWRITE(userid,rc,sqlca.sqlerrm);
   return SQLCODE;
}

long car844_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

long car844_body()
{
    int i;
    long rc;
    $char sStmt[9500],sStmt1[9500],sStmt2[9500],sStmt3[9500],sStmt4[9500];
    $char stmt[9500];
    $char tmp[4096], tmp1[4096], tmp2[4096];
    $char stepcar[4096];
    $char iapp_unit[3];
    $char falldb[2];
    $char k;

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;


    $create temp table appkind
    (
       iclaim   char(20),
       iflag    int
    )with no log;

    $create temp table app3839
    (
       iclaim   char(20)
    )with no log;

    $create temp table car844tbl
    (
       iclaim      char(20),    --�߮׸��X
       dclaim      date,        --���z���
       ibranch     char(2),     --���ݤ����q
       nchi_full   char(40),    --�z�߳��
       nbranch     char(40),    --�z�߬�O
       nname       char(10),    --�z�ߤH��
       nmgr        char(10),    --�z�ߥD��
       iins_type   char(10),
       mins_app    int,
       dcreate     char(20)
    )with no log;

    for(k=0;k<count_db;k++)
    {
       sprintf_s(stmt,9500,
       "insert into appkind                    \
         select iclaim,                        \
            max(case when                      \
                  (select count(*)             \
                     from insurance_type       \
                    where iins_type =  x.iins_type        \
                      and fins_grp  =  '2'                \
                      and fkind     <> '3') > 0 then 4    \
                     when                      \
                  (select count(*)             \
                     from insurance_type       \
                    where iins_type =  x.iins_type        \
                      and fkind     = '3')  > 0 then 3    \
                     when     \
                  (select count(*)    \
                     from insurance_type       \
                    where iins_type =  x.iins_type        \
                      and fkind     = '2')  > 0 then 2    \
               else 1            \
                end) as iflag    \
           from %s:app_ins_type x          \
          where iclaim in (select iclaim   \
                             from ca_clm_process y           \
                            where x.iclaim = y.iclaim        \
                              and y.dclaim between ? and ?   \
                              and y.iclaim[6] <> 'C')        \
          group by 1 ", list[k].dbname);

        printf("stmt[%s]\n",stmt);

        $prepare idstmt1 from $stmt;
        $execute idstmt1 using $lBgnDate, $lEndDate;

       sprintf_s(stmt,9500,
       "insert into app3839          \
         select unique iclaim        \
           from %s:app_ins_type a    \
	  where a.iins_type in ('38','39','238')   \
	    and not exists (select *         \
	                      from %s:app_ins_type b         \
			     where a.iclaim  =  b.iclaim     \
			       and b.iins_type not in ('38','39','238')) ", list[k].dbname, list[k].dbname);

        printf("stmt[%s]\n",stmt);

        $prepare idstmt2 from $stmt;
        $execute idstmt2;


       sprintf_s(stmt,9500,
       " insert into car844tbl          \
         select a.iclaim as �߮׸��X,   \
                a.dclaim as ���z���,   \
               (select ibranch          \
                  from branch           \
                 where ibranch_abbr = a.iclaim[3]) as ���ݤ����q,    \
               (select nchi_full        \
                  from branch           \
                 where ibranch = replace(a.iclaim[1,2],'A','0')) as �z�߳��, \
               (select nbranch          \
                  from sa_branch_type   \
                 where ibranch = a.affiliated) as �z�߬�O,    \
               (select nname            \
                  from officer          \
                 where iofficer = a.adjustment) as �z�ߤH��,   \
               (select x.nname          \
                  from officer x, personal:asempl y            \
                 where x.iofficer = y.administrator            \
                   and y.empl_no  = a.adjustment) as �z�ߥD��, \
		v.iins_type, v.mins_app, \
		(select min(p.dcreate) from ca_ver_relation o,ca_clm_journal p where o.iverify = p.iverify and o.iclaim = a.iclaim) as �Ĥ@����J�߮פ�x��� \
           from ca_clm_process a, %s:app_ins_type v   \
          where a.iclaim   =  v.iclaim                \
            and a.iclaim in (select iclaim1 from dwsdb:claim_app_main r where r.insure_type = 'C' and r.isys_source = 'CAR'   \
	                                                                  and a.iclaim = r.iclaim1 and (r.ddecide is null or r.ddecide > ?))   \
            and a.iclaim in (select iclaim from appkind where iflag > 1)       \
	    and a.iclaim not in (select iclaim from app3839)  ", list[k].dbname);

        printf("stmt[%s]\n",stmt);

        $prepare idstmt3 from $stmt;
        $execute idstmt3 using $lBasicDate;
    }


  return M_CM_OK;

errexit:
   printf("car844_body ==> SQLCODE:[%ld][%s] \n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   printf("   end EWRITE \n");
   return SQLCODE;
}

long car844_print()
{
   $char stmt[4096], stmt1[1024], stmt2[1024];
   $long qorder;
   int i,x,j,k;
   $int COUNT;
   $char sfilename[200];
   $char stitle[1000];
   $char ssql[1000];
   $char dyearmonth_tmp[7];
   $char title_tmp[101];
   $char title_tmp0[101];
   $char title_tmp1[101];
   $char title_tmp2[101];
   $char filed[20][15];
   $char sqltmp[1024];
   $char filed_tmp[200];
   $char sErrmsg[100];
   $char stitletmp[512];
   $int  rc;

   $char sWhere1[1024];
   $char sWhere2[1024];
   $char sWhere3[1024];
   $char sWhere4[1024];

   $WHENEVER ERROR goto errexit;
   $SET LOCK MODE TO WAIT;

   strcpy(sfilename,"�߮ש��Ӫ�");
   printf("sfilename[%s]\n",sfilename);

   strcpy(stitle, sfilename);
   printf("stitle[%s]\n",stitle);
   strcat(stitle, "\n\t");
   strcat(stitle, "���z����G ");
   strcat(stitle, sBgnDate_e);
   strcat(stitle, " ~ ");
   strcat(stitle, sEndDate_e);
   strcat(stitle, "���׺I���G ");
   strcat(stitle, sBasicDate_e);
   strcat(stitle, "\n\t�߮׸��X\t���z���\t���ݤ����q\t�z�߳��\t�z�߬�O\t�z�ߤH��\t�z�ߥD��\t�I�إN��\t�w�����B\t�Ĥ@����J�߮פ�x���\t");

   printf("stitle[%s]\n",stitle);

   sprintf_s(ssql,1000,
    " select * from car844tbl ");

   printf("ssql[%s]\n",ssql);

   rc = unload_file(outputf,"A",sfilename,stitle,ssql);

   if (rc != SUCCESS)
   {
       if (rc == 3501)
       {
          sprintf_s(sErrmsg,100," ��J���^������䤣���� ",sfilename);
       }
       else
       {
          sprintf_s(sErrmsg,100," %s �ɮ׵L�k���� ",sfilename);
       }

       EWRITE(userid, rc , sErrmsg);
       exit(1);
   }




   return M_CM_OK;

errexit:
  printf("SQL=[%d], sqlca.sqlerrm[%s]\n", SQLCODE, sqlca.sqlerrm);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  exit(1);

}

int DiffMonth(d1,d2)    /* input data should be date format */
long d1, d2;
{
short mdy1[3], mdy2[3];
int datediff=0;

    rjulmdy(d1,mdy1);
    rjulmdy(d2,mdy2);
    datediff=(mdy1[2]*12+mdy1[0])-(mdy2[2]*12+mdy2[0]);
    if (datediff<0) datediff=0;
    return datediff;
}

long car844_print_2()
{
   $char stmt[4096], stmt1[1024], stmt2[1024];
   $long qorder;
   int i,x,j,k;
   $int COUNT;
   $char sfilename[200];
   $char stitle[1000];
   $char ssql[1000];
   $char dyearmonth_tmp[7];
   $char title_tmp[101];
   $char title_tmp0[101];
   $char title_tmp1[101];
   $char title_tmp2[101];
   $char filed[20][15];
   $char sqltmp[1024];
   $char filed_tmp[200];
   $char sErrmsg[100];
   $char stitletmp[512];
   $int  rc;

   $char sWhere1[1024];
   $char sWhere2[1024];
   $char sWhere3[1024];
   $char sWhere4[1024];

   $WHENEVER ERROR goto errexit;
   $SET LOCK MODE TO WAIT;

   strcpy(sfilename,"�߮פ�x���Ӫ�");
   printf("sfilename[%s]\n",sfilename);

   strcpy(stitle, sfilename);
   printf("stitle[%s]\n",stitle);
   strcat(stitle, "\n\t");
   strcat(stitle, "���z����G ");
   strcat(stitle, sBgnDate_e);
   strcat(stitle, " ~ ");
   strcat(stitle, sEndDate_e);
   strcat(stitle, "���׺I���G ");
   strcat(stitle, sBasicDate_e);
   strcat(stitle, "\n\t�߮׸��X\t���p�׸�\t�Ǹ�\t���z��\t�z�߳��\t�z�߬�O\t�z�ߤH��\t��x�ƥ���\t�a�I\t��x��H�W��\t��x���e\t��x��J�H��\t��x��J���\t");

   printf("stitle[%s]\n",stitle);


   $select a.iclaim, replace(replace(replace(replace(replace(multiset(
             select trim(iclaim) from ca_ver_relation  where iverify = a.iverify
                and iclaim <> a.iclaim)::lvarchar,'MULTISET{',''),'ROW(''',''),''')',''),'}',''),',','�B') as iclm_relation,
             b.iserial, (select unique dclaim from car844tbl where iclaim = a.iclaim) as dclaim,
             (select unique nchi_full from car844tbl where iclaim = a.iclaim) as nchi_full,
             (select unique nbranch from car844tbl where iclaim = a.iclaim) as nbranch,
             (select unique nname from car844tbl where iclaim = a.iclaim) as nname,
             b.drecord, b.nplace, b.njournal,
             nvl(replace(replace(nremark,CHR(13),''),CHR(10),''),' ') as nremark,
             (select trim(nname) from officer where iofficer = b.ientry) as nofficer,
             trim(b.dentry::lvarchar) as dentry
        from ca_ver_relation a, ca_clm_journal b
       where a.iverify = b.iverify
         and a.iclaim in (select distinct  iclaim from car844tbl)
    into temp car844tb2 with no log;

    for(k=0;k<count_db;k++)
    {
       sprintf_s(stmt,4096,  "insert into car844tb2 "
        "select a.iclaim, replace(replace(replace(replace(replace(multiset( "
        "       select trim(iclaim) from ca_ver_relation  where iclaim = a.iclaim "
        "       and iverify <> a.iclaim)::lvarchar,'MULTISET{',''),'ROW(''',''),''')',''),'}',''),',','�B') as iclm_relation, "
        "       b.iserial, (select unique dclaim from car844tbl where iclaim = a.iclaim) as dclaim, "
        "       (select unique nchi_full from car844tbl where iclaim = a.iclaim) as nchi_full, "
        "       (select unique nbranch from car844tbl where iclaim = a.iclaim) as nbranch, "
        "       (select unique nname from car844tbl where iclaim = a.iclaim) as nname, "
        "       b.drecord, b.nplace, b.njournal, "
        "       nvl(replace(replace(nremark,CHR(13),''),CHR(10),''),' ') as nremark, "
        "       (select trim(nname) from officer where iofficer = b.ientry) as nofficer, "
        "       trim(b.dentry::lvarchar) as dentry "
        "  from %s:appraisal a, ca_clm_journal b "
        " where a.inumber = b.iverify "
        "   and a.iclaim in (select distinct iclaim from car844tbl) ",list[k].dbname);

        printf("--508 stmt= [%s]\n",stmt);
        $prepare appstm1 from $stmt;
        $execute appstm1;

    }

   /* sprintf_s(ssql,1000,
    " select a.iclaim, \
             replace(replace(replace(replace(replace(multiset(select trim(iclaim) from ca_ver_relation  where iverify = a.iverify and iclaim <> a.iclaim)::lvarchar,'MULTISET{',''),'ROW(''',''),''')',''),'}',''),',','�B'), \
             b.iserial, b.drecord, b.nplace, b.njournal, \
             replace(replace(nremark,CHR(13),''),CHR(10),''), \
             (select nname from officer where iofficer = b.ientry), b.dentry \
        from ca_ver_relation a, ca_clm_journal b \
       where a.iverify = b.iverify \
         and a.iclaim in (select distinct  iclaim from car844tbl) "); */

   sprintf_s(ssql,1000,"select * from car844tb2 order by 1,13");

   printf("ssql[%s]\n",ssql);

   rc = unload_file(outputf,"B",sfilename,stitle,ssql);

   if (rc != SUCCESS)
   {
       if (rc == 3501)
       {
          sprintf_s(sErrmsg,100," �䤣���ƽ߮פ�x���� ",sfilename);
       }
       else
       {
          sprintf_s(sErrmsg,100," %s �ɮ׵L�k���� ",sfilename);
       }

       EWRITE(userid, rc , sErrmsg);
       exit(1);
   }




   return M_CM_OK;

errexit:
  printf("SQL=[%d], sqlca.sqlerrm[%s]\n", SQLCODE, sqlca.sqlerrm);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  exit(1);

}