/************************************************/
/*                                              */
/*   PROGRAM : ca307q01s.ec by Dennis Chang     */
/*                                              */
/*   DATE    : 1994/03/04                       */
/*                                              */
/************************************************/
#include <stdio.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include <malloc.h>
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "print.h"
#include "is_def.h"
#include "carmsgs.h"
#include "commsgs.h"

$int PgLine;
char OutFile[20];
int  errCode;
int  tmp_len;

extern void trim_cspace() ;

$static char fixIns[9][3] = {"01","11","12","31","32","24","25","51","52"};

static int pagenum=1;

   /*** Screen Variable ***/
   char   choice[2],ptr[2],type[2],ptr1[2],list_print[2],PrintDlist[2],ProtectData[2];
   $char  plybgn[POLICY_NUM_1], plyend[POLICY_NUM_1];
   $char  cardbgn[CARD_NUM], cardend[CARD_NUM];
   $char  ibatchno[4], ikind[2], EveryBigPolicy[2], printW[2], old_iply[2];
   $char  iedr_examiner[11], tmp_feply[2], sPasswd[13];
   $char  tmp_iroute[21],tmp_iofficer[11],tmp_dpolicy_bgn[11],tmp_dpolicy_end[11];
   int iPrintlist = 0;

   /*** Report Variable ***/
   $char  XIcard2[ CARD_NUM];
   $char  XIcard1[ CARD_NUM];
   $char  XIpolicy[ POLICY_NUM_1];
   $char  XIrelative_ply[ POLICY_NUM_1];
   $char  XIlast_ply[ POLICY_NUM_1];
   $char  XIbroker[ BROKER];
   $char  XIofficer[ EMPLOYEE_ID];
   $char  XIcashier[ EMPLOYEE_ID];
   $long  XMdmg_prem;
   $long  XMlia_prem;
   $date  XDpolicy;
   $char  XIexaminer[ EMPLOYEE_ID];
   $char  XIentry[ EMPLOYEE_ID];

   $char  YFassured[ 2];
   $char  YNassured[ ASSURED_NAME];
   $char  YNuser[ 41];
   $char  YNbenef[ 43];
   $char  YAassured[ 92];
   $char  YItel[ 12];
   $char  YApayment[92];
   $int   YQply_period;
   $long  YDply_begin;
   $long  YDply_end;
   $char  YIissue_ym[ 6];
   $char  YIpro_year[ 5];
   $char  YIbrand[ 9];
   $char  YIcar_type[ CA_CAR_TYPE_NUM];
   $int   YQcylinder;
   $char  YIengine[ 21];
   $char  YIbody[ 21];
   $char  YItag[ CA_TAG_NUM];
   $char  ANbrand_abbr[14];
   $char  BNcode[14];
   $char  YIlicense[ CUSTOMER_ID];
   $char  YIbirth[ 9];
   $char  YFsex[ 2];
   $char  YFmarriage[ 2];
   $int   YPdmg_align;
   $int   YPlia_align;

   $char  Iins_type[INSURANCE_TYPE];
   $char  Nins_type[29];
   $int   Qcoverage;
   $char  Fprint[2];
   $char  Edomain1[25];
   $char  Edomain2[25];
   $char  Fdeduct[2];
   $int   Minjured_cover;
   $int   Mdeath_cover;
   $int   Mdamage_cover;
   $int   Mdeduct;
   $int   Mins_premium;
   $int   Qserial;
   $int   TMins_premium;
   $long  premium2;
   
   char   sEterms[2];

   $date  Today;
   int    flag_exist=0;

   $char  sErrMsg[1024], v_sMsg[1024];

   $char  sIresource[2];
   $char  XIcard[21], sIapplicant[13];
   $char  sFout_print[2],sFmail_type[2],sDout_trans[11];
/*****************************/

   $char DBName[DBNAME];
   $char  userid[USER_ID];
   char  FormTp[3];
   char  TitleFmt[N_FILE+1];
   char  outputf[20];
   int   max_count=0;

/*** Loacl Function ***/
   long car307_build();
   long car307_body();
   long car307_body1();
   long car307_fix_ins();
   long car307_var_ins();
   int  ca_rpt_policy();
   int  ca_rpt_policy_old();
   long ca_rpt_pa();
/*---------------------------------------------------------------------*/

main(argc,argv)
int argc;
char **argv;
{
    int rc, rtncode;
    char sMsg[1024];

    batchinit();
    strcpy(DBName,isNULLstr(argv[1]));
    strcpy(userid,isNULLstr(argv[2]));
    strcpy(choice,isNULLstr(argv[3]));      		/* 1:�O�渹�X, 2:�O�I�d���X */
                                            		/* 3:��ﴣ�Ѥ��-���L�O��G���H�� 
                                                	     �u�n���Ŀ�i���L�O��j�٨S�L�L���A�|���ƦL�X�A�L�L�Y�L�k�A�H���ﶵ�C�L 
                                                	   4.�q���N��+ñ���
                                                	   5.�g��N��+ñ��� 
                                                	     (4�B5�u�w��q�l�O��@�ɦL)*/
    strcpy(type,isNULLstr(argv[4]));  			/* a:�Ъ���, b:�帹 */
    strcpy(plybgn,isNULLstr(argv[5])); 			/* �O��_ */
    strcpy(plyend,isNULLstr(argv[6])); 			/* �O��W */
    strcpy(cardbgn,isNULLstr(argv[7])); 		/* �d���_ */
    strcpy(cardend,isNULLstr(argv[8])); 		/* �d���� */
    strcpy(ptr,isNULLstr(argv[9]));     		/* 1:�C�L�ɵo�r�� */
    strcpy(ptr1,isNULLstr(argv[10]));       		/* 1:�C�L�ˮ`�I��� */
    strcpy(ikind,   isNULLstr(argv[11]));     		/* 1:�C�L�u�f���B */
    strcpy(EveryBigPolicy,   isNULLstr(argv[12])); 	/* Y:�C�L�j�O��C�i�� */
    strcpy(printW,   isNULLstr(argv[13]));        	/* Y:�C�L�M�ץ�O�� */
    strcpy(old_iply, isNULLstr(argv[14]));      	/* �P�_�O�_���«O��C�L */
    strcpy(list_print, isNULLstr(argv[15]));    	/* �P�_�O�_�C�L�W�U */
    strcpy(PrintDlist, isNULLstr(argv[16]));    	/* �P�_�O�_�C�L���w�r�p�H�W�U */
    strcpy(ProtectData, isNULLstr(argv[17]));   	/* �Ӹ�B�n 0:���B�n 1:�B�n */
    strcpy(iedr_examiner, isNULLstr(argv[18]));   	/* ���H�� */
    strcpy(tmp_feply,isNULLstr(argv[19]));		/* �q�l�O�� 0:�_ 1:�O */
    strcpy(tmp_iroute,isNULLstr(argv[20]));	 	/* �q���N��  */
    strcpy(tmp_iofficer,isNULLstr(argv[21]));	 	/* �g��N��  */
    strcpy(tmp_dpolicy_bgn,isNULLstr(argv[22]));	/* ñ��_��  */
    strcpy(tmp_dpolicy_end,isNULLstr(argv[23]));	/* ñ�樴��  */
    strcpy(sEterms,isNULLstr(argv[24]));                /* ���ګ��� 0:�̷̳s�O���� 1:�q�l���� 2:�ȥ�����*/
    strcpy(outputf,isNULLstr(argv[25]));
    
    printf("***** plybgn[%s] plyend[%s] cardbgn[%s] cardend[%s]\n",
          plybgn,plyend,cardbgn,cardend);
    printf("*****before car307_build() choice[%s] type[%s] \n",choice,type);

    printf("*****sEterms[%s] \n",sEterms);

    strcpy(ptr1,trim(ptr1));
    iPrintlist = atoi(list_print);

    if (strcmp(ptr1,"0")==0)
    {
        rtncode=car307_build();

        if (rtncode == M_CA_NREL_PLY)
        {
             EWRITE(userid, rtncode, "�O�楼�L�L�Χ䤣�즹�O�渹!");
             return rtncode;
        }
        else if (rtncode == M_CA_NLENGTH)
        {
             EWRITE(userid, rtncode, "�O�渹��J���~!");
             return rtncode;
        }
        else if (rtncode == M_CA_TOBE_NO_PRINT)
        {
             EWRITE(userid, rtncode, "�C�L���O�欰�M�׷~�ȡA�G�N����ܫO�椺�e���!");
             return rtncode;
        }
        else if (rtncode == M_CA_PREMIUM_ERR)
        {
            sprintf( sMsg, "�O��[%s],�I�ة��ӫO�O�[�`�P�`�O�O���۵�!\n", XIpolicy);
            EWRITE(userid, rtncode, sMsg);
            return rtncode;
        }
        else if (rtncode == M_CA_HAVE_equipment_88)
        {
            sprintf( sMsg, "�O��[%s],�O����O�i88 �ΫH�����ɤA���M�סj���o�ɦL�O��I\n", XIpolicy);
            EWRITE(userid, rtncode, sMsg);
            return rtncode;
        }
        else if (rtncode != M_CM_OK)
        {

        	printf("rtncode=[%d]\n",rtncode);
        	strcpy(sMsg, "�O��C�L���ѽЭ��դ@��! \n");
        	strcat(sMsg, rtrim(sErrMsg));
        	printf("sMsg=[%s]sErrMsg=[%s]\n",sMsg,sErrMsg);
            EWRITE(userid, rtncode, sMsg);
            return rtncode;
        }

        if (old_iply[0] == 'A')
        {
printf("�s��\n");
             if (rc=(save_form_info(F_FREE,"CA",306,userid,FormTp,max_count,outputf))<0)
             EWRITE(userid,rc,"save_form_info failed");
        } else {
printf("�ª�\n");
        	    if (rc=(save_form_info(F_FREE,"CA",3062,userid,FormTp,max_count,outputf))<0)
             EWRITE(userid,rc,"save_form_info failed");
        }
    }
    else
    {
        printf("car307_build_pa\n");
        rtncode=car307_build_pa();

        if (rtncode == M_CA_NREL_PLY)
        {
             EWRITE(userid, rtncode, "�䤣�즹�O�渹!");
             return rtncode;
        }
        else if (rtncode == M_CM_NOT_FOUND)
        {
             EWRITE(userid, rtncode, "�нT�{���L�ӫO�ˮ`�I!");
             return rtncode;
        }
        else if (rtncode != M_CM_OK)
        {
             EWRITE(userid, rtncode, "�C�L���ѽЭ��դ@��!");
             return rtncode;
        }

        printf("Begin save_form_info \n");
        if (rc=(save_form_info(F_FREE,"CA",33,userid,FormTp,max_count,outputf))<0)
             EWRITE(userid,rc,"save_form_info failed");
    }
}

/******************************************************************************/
long car307_build()
{
    int   i, j;
    int   rc, count, rc2;
    int   count_no_tobe=0;
    $char FormFile[N_FILE+1];
    $char stmt[400],stmt1[512];
    char  dbsite[3], FullDBName[40];
    $char ipolicy[POLICY_NUM_1];
    $int  ibatch_no, iEqm88;
    $char sTmpbgn1[POLICY_NUM_1], sTmpbgn2[POLICY_NUM_1];
    $char sTmpend1[POLICY_NUM_1], sTmpend2[POLICY_NUM_1];
    $char sTmpbgn1_1[POLICY_NUM_1], sTmpbgn2_1[POLICY_NUM_1], iendorse[21];
    int   iFpolicy, iFbig;
    $char sTmpiofficer[ EMPLOYEE_ID];
    $char sIassured[13],sIassured1[13];
    $int  iCountDeny ,iCountFunsale ,count_out=0;
    $char  sItag[CA_TAG_NUM],sIengine[21],sIengine1[21],sIleader[11];
    $char Msg[1024];
	$char sIrelative_ply[21],sIestimate[21],sIcard1[21],sIserial[12],sIquota1[7],sNassured1[121];
    $char date[11],dToday[11],ireceipt[21];
    long t;
    $int res;
    $datetime year to second dt_dprint;
    $char sIcomp_in[3],sDply_end[11],sDpolicy1[11],sDply_bgn[11];
    $char e_nfile[36],sIroute[21],yyyy[5];
    $int eply_cnt;
    $char feply[2],aemail_eply[51];
    $int  iserno,chk_ftype,fspeed;
    $char feedr[2],siserno[3];
    
    $char tmobile_eply[21];

    if (db_select(DBName) == False)
        return M_CM_DB_NOTOPEN;

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;
    $begin work;
    /* A���s��,B���ª� */
    if (old_iply[0] == 'A')
    {
        $SELECT kPgNum_Line, nForm_File INTO $PgLine, $FormFile
           FROM Form
          WHERE ksys_grp="CA" AND kPgmID = 306;
    } else
    {
    	  $SELECT kPgNum_Line, nForm_File INTO $PgLine, $FormFile
           FROM Form
          WHERE ksys_grp="CA" AND kPgmID = 3062;
    }
printf("filename[%s]\n",FormFile,PgLine);
    strcpy(FormFile,rtrim(FormFile));
    sprintf(OutFile,"%s.tx",outputf);
    
    printf("what is file name? [%s]\n",OutFile);

    iFpolicy = TRUE;
    iFbig = FALSE;

    if (choice[0]=='1')
    {
        if (plyend[0] == '*' || plyend[0] == ' ' || plyend[0] == '\0')
            strcpy(plyend,plybgn);
    }
    else if (choice[0]=='2')
    {
        if (cardend[0] == '*' || cardend[0] == ' ' || cardend[0] == '\0')
            strcpy(cardend,cardbgn);
    }

    if (iFpolicy)
    {
        if (choice[0]=='1')
        {
            if (type[0]=='a')
            {
                rc = split_policy(plybgn, sTmpbgn1, sTmpbgn2);
                if (rc !=  M_CM_OK)
                {
                	$ROLLBACK WORK;
                	return rc;
                }
                rc = split_policy(plyend, sTmpend1, sTmpend2);
                if (rc !=  M_CM_OK)
                {
                	$ROLLBACK WORK;
                	return rc;
                }

                if (strcmp(sTmpbgn1, sTmpend1) != 0)
                {
                    strcpy(plybgn, sTmpbgn1);
                    strcpy(plyend, sTmpend1);
                    iFbig = FALSE;
                }
                else
                {
                    if (strlen(sTmpbgn2) == CAR_TARGET_LEN &&
                        strlen(sTmpend2) == CAR_TARGET_LEN)
                    {
                        if (strcmp(sTmpbgn2, sTmpend2) == 0) iFbig = FALSE;
                        else iFbig = TRUE;
                    }
                    else
                    {
                        strcpy(plybgn, sTmpbgn1);
                        strcpy(plyend, sTmpend1);
                        iFbig = FALSE;
                    }
                }
            }
            else if (type[0]=='b')
            {
                strcpy(sTmpbgn1_1, substring(plybgn,1,13));
                strcpy(sTmpbgn2_1, substring(plybgn,14,4));
                if (strlen(sTmpbgn2_1) <= 3 &&
                    strlen(sTmpbgn2_1) >= 1)
                {
                    strcpy(plybgn, sTmpbgn1_1);
                    strcpy(ibatchno, sTmpbgn2_1);
                    iFbig = TRUE;
                }
                else
                {
                    iFbig = FALSE;
                }
                printf("-----> TYPE:b : sTmpbgn1_1:[%s],sTmpbgn2_1:[%s] \n",sTmpbgn1_1,sTmpbgn2_1);
            }
        }
        else
        {
        	    iFbig = FALSE;
        	    strcpy(type,"b"); /* �O�I�ҦC�L�O�椣�|�L�s�j�O��,�Gdefault�ȵ����帹���ﶵ */
        }
    }
    
    /* 104.01.09 �ư��M�ץ� */
    if (iFpolicy)
    {
        if (iFbig)
        {
            if (type[0]=='a')
            {
                /* $DECLARE PLY_CUR_1 CURSOR FOR
                  SELECT ipolicy, ibatch_no, iofficer,
                         (select nequipment[28,28] from policy where ipolicy = a.ipolicy)
                    FROM ply_relation a
                   WHERE fcard_class='2'
                     AND dpolicy is NOT NULL
                     AND ipolicy BETWEEN $plybgn AND $plyend; */
                $DECLARE PLY_CUR_1 CURSOR FOR
                  SELECT a.ipolicy, a.irelative_ply, a.itmp_policy,a.ibatch_no, a.iofficer,
                         b.nequipment[28,28], b.iassured,a.iresource,a.icard,b.iapplicant,
                         a.fout_print,a.fmail_type,a.dout_trans,b.itag,b.iengine,a.ileader,
                         a.icomp_in,a.dply_end,
                         b.iassured,b.iroute,a.feply,a.aemail_eply,a.tmobile_eply,year(a.dpolicy),a.dply_begin
                    FROM ply_relation a, policy b
                   WHERE a.ipolicy = b.ipolicy
                     and a.fcard_class='2'
                     AND a.dpolicy is NOT NULL
                     AND (a.iofficer[1] not in ('W','N') and not (a.iofficer[1] = 'H' and a.iofficer[2] not in ('0','1','2')) ) 
                     AND a.ipolicy BETWEEN $plybgn AND $plyend;
                printf("-----> into PLY_CUR_1\n");
            }
            else if (type[0]=='b')
            {
                /* $DECLARE PLY_CUR_1_1 CURSOR FOR
                  SELECT ipolicy, ibatch_no, iofficer,
                         (select nequipment[28,28] from policy where ipolicy = a.ipolicy)
                    FROM ply_relation a
                   WHERE fcard_class='2'
                     AND dpolicy is NOT NULL
                     AND ipolicy[1,13] = $plybgn
                     AND ibatch_no = $ibatchno; */
                $DECLARE PLY_CUR_1_1 CURSOR FOR
                  SELECT a.ipolicy, a.irelative_ply, a.itmp_policy,a.ibatch_no, a.iofficer,
                         b.nequipment[28,28], b.iassured,a.iresource,a.icard,b.iapplicant,
                         a.fout_print,a.fmail_type,a.dout_trans,b.itag,b.iengine,a.ileader,
                         a.icomp_in,a.dply_end,
                         b.iassured,b.iroute,a.feply,a.aemail_eply,a.tmobile_eply,year(a.dpolicy),a.dply_begin
                    FROM ply_relation a, policy b
                   WHERE a.ipolicy = b.ipolicy
                     and a.fcard_class='2'
                     AND a.dpolicy is NOT NULL
                     AND a.ipolicy[1,13] = $plybgn
                     AND (a.iofficer[1] not in ('W','N') and not (a.iofficer[1] = 'H' and a.iofficer[2] not in ('0','1','2')) ) 
                     AND a.ibatch_no = $ibatchno;
                printf("-----> TYPE:b : plybgn:[%s],ibatchno:[%s] \n",plybgn,ibatchno);
                printf("-----> into PLY_CUR_1_1\n");
            }
        }
        else
        {
            if (choice[0] == '1')
            {
                /* $DECLARE PLY_CUR_2 CURSOR FOR
                  SELECT ipolicy, ibatch_no, iofficer,
                         (select nequipment[28,28] from policy where ipolicy = a.ipolicy)
                    FROM ply_relation a
                   WHERE fcard_class='2'
                     AND dpolicy is NOT NULL
                     AND ipolicy BETWEEN $plybgn AND $plyend
                   ORDER BY ipolicy; */
                $DECLARE PLY_CUR_2 CURSOR FOR
                  SELECT a.ipolicy, a.irelative_ply, a.itmp_policy, a.ibatch_no, a.iofficer,
                         b.nequipment[28,28], b.iassured,a.iresource,a.icard,b.iapplicant,
                         a.fout_print,a.fmail_type,a.dout_trans,b.itag,b.iengine,a.ileader,
                         a.icomp_in,a.dply_end,
                         b.iassured,b.iroute,a.feply,a.aemail_eply,a.tmobile_eply,year(a.dpolicy),a.dply_begin
                    FROM ply_relation a, policy b
                   WHERE a.ipolicy = b.ipolicy
                     and a.fcard_class='2'
                     AND a.dpolicy is NOT NULL
                     AND a.ipolicy BETWEEN $plybgn AND $plyend
                     AND (a.iofficer[1] not in ('W','N') and not (a.iofficer[1] = 'H' and a.iofficer[2] not in ('0','1','2')) ) 
                   ORDER BY a.ipolicy;
                printf("-----> into PLY_CUR_2\n");
            }
            else if (choice[0] == '2')
            {
                /* $DECLARE PLY_CUR_3 CURSOR FOR
                  SELECT ipolicy, ibatch_no, iofficer,
                         (select nequipment[28,28] from policy where ipolicy = a.ipolicy)
                    FROM ply_relation a
                   WHERE fcard_class='2'
                     AND dpolicy is NOT NULL
                     AND LENGTH(ipolicy) = 13
                     AND icard BETWEEN $cardbgn AND $cardbgn
                   ORDER BY ipolicy; */
                $DECLARE PLY_CUR_3 CURSOR FOR
                  SELECT a.ipolicy, a.irelative_ply, a.itmp_policy,a.ibatch_no, a.iofficer,
                         b.nequipment[28,28], b.iassured,a.iresource,a.icard,b.iapplicant,
                         a.fout_print,a.fmail_type,a.dout_trans,b.itag,b.iengine,a.ileader,
                         a.icomp_in,a.dply_end,
                         b.iassured,b.iroute,a.feply,a.aemail_eply,a.tmobile_eply,year(a.dpolicy),a.dply_begin
                    FROM ply_relation a, policy b
                   WHERE a.ipolicy = b.ipolicy
                     and a.fcard_class='2'
                     AND a.dpolicy is NOT NULL
                     AND a.LENGTH(ipolicy) = 13
                     AND a.icard BETWEEN $cardbgn AND $cardbgn
                     AND (a.iofficer[1] not in ('W','N') and not (a.iofficer[1] = 'H' and a.iofficer[2] not in ('0','1','2')) ) 
                   ORDER BY a.ipolicy;
                printf("-----> cardbgn:[%s],cardbgn:[%s]\n",cardbgn,cardbgn);
                printf("-----> into PLY_CUR_3\n");
            }
            else if (choice[0] == '3')
            {
                $DECLARE PLY_CUR_5 CURSOR FOR
                  SELECT distinct a.ipolicy, a.irelative_ply, a.itmp_policy,a.ibatch_no, a.iofficer,
                         b.nequipment[28,28], b.iassured,a.iresource,a.icard,b.iapplicant,
                         a.fout_print,a.fmail_type,a.dout_trans,b.itag,b.iengine,a.ileader,
                         a.icomp_in,a.dply_end,
                         b.iassured,b.iroute,a.feply,a.aemail_eply,a.tmobile_eply,year(a.dpolicy),a.dply_begin
                    FROM ply_relation a, policy b, edr_relation c
                   WHERE a.ipolicy = b.ipolicy
                     AND a.ipolicy = c.ipolicy
                     AND c.iendorse not like '%CVP%'
                     and a.fcard_class='2'
                     AND a.dpolicy is NOT NULL
                     AND c.fply_print = '1' AND iedr_examiner = $iedr_examiner 
                     AND (a.iofficer[1] not in ('W','N') and not (a.iofficer[1] = 'H' and a.iofficer[2] not in ('0','1','2')) ) 
                   ORDER BY a.ipolicy;
                printf("-----> cardbgn:[%s],cardbgn:[%s]\n",cardbgn,cardbgn);
                printf("-----> into PLY_CUR_3\n");
            }
            else if (choice[0] == '4')
            {
                $DECLARE PLY_CUR_6 CURSOR FOR
                  SELECT a.ipolicy, a.irelative_ply, a.itmp_policy, a.ibatch_no, a.iofficer,
                         b.nequipment[28,28], b.iassured,a.iresource,a.icard,b.iapplicant,
                         a.fout_print,a.fmail_type,a.dout_trans,b.itag,b.iengine,a.ileader,
                         a.icomp_in,a.dply_end,
                         b.iassured,b.iroute,a.feply,a.aemail_eply,a.tmobile_eply,year(a.dpolicy),a.dply_begin
                    FROM ply_relation a, policy b
                   WHERE a.ipolicy = b.ipolicy
                     and a.fcard_class='2'
                     AND a.dpolicy is NOT NULL
                     AND b.iroute = $tmp_iroute
                     AND a.dpolicy between $tmp_dpolicy_bgn and $tmp_dpolicy_end
                     AND a.feply = '1'
                     AND (a.iofficer[1] not in ('W','N') and not (a.iofficer[1] = 'H' and a.iofficer[2] not in ('0','1','2')) ) 
                   ORDER BY a.ipolicy;

                printf("-----> into PLY_CUR_6\n");
            }
            else
            {
                $DECLARE PLY_CUR_7 CURSOR FOR
                  SELECT a.ipolicy, a.irelative_ply, a.itmp_policy, a.ibatch_no, a.iofficer,
                         b.nequipment[28,28], b.iassured,a.iresource,a.icard,b.iapplicant,
                         a.fout_print,a.fmail_type,a.dout_trans,b.itag,b.iengine,a.ileader,
                         a.icomp_in,a.dply_end,
                         b.iassured,b.iroute,a.feply,a.aemail_eply,a.tmobile_eply,year(a.dpolicy),a.dply_begin
                    FROM ply_relation a, policy b
                   WHERE a.ipolicy = b.ipolicy
                     and a.fcard_class='2'
                     AND a.dpolicy is NOT NULL
                     AND a.iofficer = $tmp_iofficer
                     AND a.dpolicy between $tmp_dpolicy_bgn and $tmp_dpolicy_end
                     AND a.feply = '1'
                     AND (a.iofficer[1] not in ('W','N') and not (a.iofficer[1] = 'H' and a.iofficer[2] not in ('0','1','2')) ) 
                   ORDER BY a.ipolicy;

                printf("-----> into PLY_CUR_7\n");
            }
        }
    }
    else
    {
        /* $DECLARE PLY_CUR_4 CURSOR FOR
          SELECT ipolicy, ibatch_no, iofficer,
                 (select nequipment[28,28] from policy where ipolicy = a.ipolicy)
            FROM ply_relation a
           WHERE fcard_class='2'
             AND dpolicy is NOT NULL
             AND LENGTH(ipolicy) = 13
           ORDER BY ipolicy; */
       $DECLARE PLY_CUR_4 CURSOR FOR
          SELECT a.ipolicy, a.irelative_ply, a.itmp_policy,a.ibatch_no, a.iofficer,
                 b.nequipment[28,28], b.iassured,a.iresource,a.icard,b.iapplicant,
                 a.fout_print,a.fmail_type,a.dout_trans,b.itag,b.iengine,a.ileader,
                 a.icomp_in,a.dply_end,
                 b.iassured,b.iroute,a.feply,a.aemail_eply,a.tmobile_eply,year(a.dpolicy),a.dply_begin
            FROM ply_relation a, policy b
           WHERE a.ipolicy = b.ipolicy
             and a.fcard_class='2'
             AND a.dpolicy is NOT NULL
             AND LENGTH(a.ipolicy) = 13
             AND (a.iofficer[1] not in ('W','N') and not (a.iofficer[1] = 'H' and a.iofficer[2] not in ('0','1','2')) ) 
           ORDER BY a.ipolicy;
        printf("-----> into PLY_CUR_4\n");
    }

    rgu_init_report(FormFile,OutFile);

    if (iFpolicy)
    {
        if (iFbig)
        {
            if (type[0]=='a')
            {
                $OPEN PLY_CUR_1;
            }
            else if (type[0]=='b')
            {
                $OPEN PLY_CUR_1_1;
            }
        }
        else
        {
            if (choice[0] == '1') 
                $OPEN PLY_CUR_2;
            else if (choice[0] == '2') 
                $OPEN PLY_CUR_3;
            else if (choice[0] == '3')
                $OPEN PLY_CUR_5;
            else if (choice[0] == '4')
                $OPEN PLY_CUR_6;
            else
                $OPEN PLY_CUR_7;
        }
    }
    else $OPEN PLY_CUR_4;

    count = 0;
    count_no_tobe = 0;
    while (1)
    {
        XIpolicy[0] = '\0';
        if (iFpolicy)
        {
            if (iFbig)
            {
                if (type[0]=='a')
                {
                    $FETCH PLY_CUR_1 INTO $XIpolicy, $sIrelative_ply, $sIestimate, $ibatch_no, $sTmpiofficer, $iEqm88, $sIassured , $sIresource , $XIcard , $sIapplicant , $sFout_print , $sFmail_type ,$sDout_trans,$sItag,$sIengine,$sIleader,$sIcomp_in,$sDply_end,$sPasswd,$sIroute,$feply,$aemail_eply,$tmobile_eply,$yyyy,$sDply_bgn;
                }
                else if (type[0]=='b')
                {
                    $FETCH PLY_CUR_1_1 INTO $XIpolicy, $sIrelative_ply, $sIestimate, $ibatch_no, $sTmpiofficer, $iEqm88, $sIassured , $sIresource , $XIcard , $sIapplicant , $sFout_print , $sFmail_type,$sDout_trans,$sItag,$sIengine,$sIleader,$sIcomp_in,$sDply_end,$sPasswd,$sIroute,$feply,$aemail_eply,$tmobile_eply,$yyyy,$sDply_bgn;
                }
            }
            else
            {
                if (choice[0] == '1')
                    $FETCH PLY_CUR_2 INTO $XIpolicy, $sIrelative_ply, $sIestimate, $ibatch_no, $sTmpiofficer, $iEqm88, $sIassured , $sIresource , $XIcard , $sIapplicant , $sFout_print , $sFmail_type,$sDout_trans,$sItag,$sIengine,$sIleader,$sIcomp_in,$sDply_end,$sPasswd,$sIroute,$feply,$aemail_eply,$tmobile_eply,$yyyy,$sDply_bgn;
                else if (choice[0] == '2')
                    $FETCH PLY_CUR_3 INTO $XIpolicy, $sIrelative_ply, $sIestimate, $ibatch_no, $sTmpiofficer, $iEqm88, $sIassured , $sIresource , $XIcard , $sIapplicant , $sFout_print , $sFmail_type,$sDout_trans,$sItag,$sIengine,$sIleader,$sIcomp_in,$sDply_end,$sPasswd,$sIroute,$feply,$aemail_eply,$tmobile_eply,$yyyy,$sDply_bgn;
                else if (choice[0] == '3')
                    $FETCH PLY_CUR_5 INTO $XIpolicy, $sIrelative_ply, $sIestimate, $ibatch_no, $sTmpiofficer, $iEqm88, $sIassured , $sIresource , $XIcard , $sIapplicant , $sFout_print , $sFmail_type,$sDout_trans,$sItag,$sIengine,$sIleader,$sIcomp_in,$sDply_end,$sPasswd,$sIroute,$feply,$aemail_eply,$tmobile_eply,$yyyy,$sDply_bgn;
                else if (choice[0] == '4')
                    $FETCH PLY_CUR_6 INTO $XIpolicy, $sIrelative_ply, $sIestimate, $ibatch_no, $sTmpiofficer, $iEqm88, $sIassured , $sIresource , $XIcard , $sIapplicant , $sFout_print , $sFmail_type,$sDout_trans,$sItag,$sIengine,$sIleader,$sIcomp_in,$sDply_end,$sPasswd,$sIroute,$feply,$aemail_eply,$tmobile_eply,$yyyy,$sDply_bgn;
                else
                    $FETCH PLY_CUR_7 INTO $XIpolicy, $sIrelative_ply, $sIestimate, $ibatch_no, $sTmpiofficer, $iEqm88, $sIassured , $sIresource , $XIcard , $sIapplicant , $sFout_print , $sFmail_type,$sDout_trans,$sItag,$sIengine,$sIleader,$sIcomp_in,$sDply_end,$sPasswd,$sIroute,$feply,$aemail_eply,$tmobile_eply,$yyyy,$sDply_bgn;
            }
        }
        else $FETCH PLY_CUR_4 INTO $XIpolicy, $sIrelative_ply, $sIestimate, $ibatch_no, $sTmpiofficer, $iEqm88, $sIassured , $sIresource , $XIcard , $sIapplicant , $sFout_print , $sFmail_type,$sDout_trans,$sItag,$sIengine,$sIleader,$sIcomp_in,$sDply_end,$sPasswd,$sIroute,$feply,$aemail_eply,$tmobile_eply,$yyyy,$sDply_bgn;

        if (SQLCODE == SQLNOTFOUND) break;
        count++;

        strcpy(sIroute, trim(sIroute));
        
	/* ���O88���o�ɵo�C�L�O��  add by sylvia 102.07.23 (1020715001_C1) */
	if (iEqm88 > 3)
	{
	    $ROLLBACK WORK;
	    return M_CA_HAVE_equipment_88;
	}
	/* --------------------------------------------------------------- */

	/* �ˮ֭Ӹ�O�_�w����ϥ�  add by sylvia 103.02.27 (1020924002_C2) */
	$select count(*) into $iCountDeny
           from cm_personal_deny
          where iassured = $sIassured
            and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
            and ddeny <= today
            and (dexpire is null or dexpire >= today);
	if (iCountDeny > 0)
	{
	    $ROLLBACK WORK;
	    return M_CA_PERSONAL_DENY;
	}
		
	$SELECT count(*) 
	   INTO $count_out
	   FROM ca_out_temp
	  WHERE ipolicy = $XIpolicy;
	if (count_out > 0)
	{
	    sprintf( sErrMsg, "�O�渹[%s],�w�e�~", XIpolicy);
	    $ROLLBACK WORK;
	    return 0;
	}
		
		
	/* --------------------------------------------------------------- */

	/* �O�������ˮ�   add by sylvia 103.02.14 (1020924002_C2) 
	strcpy(sIleader,trim(sIleader));
	strcpy(userid,trim(userid));
	
printf("sIleader[%s],userid[%s]\n",sIleader,userid);

	if (strcmp(sIleader,userid) != 0)
	{

		rc = chk_spec_deny( XIpolicy, XIcard, sIassured, sIapplicant, sItag, sIengine, v_sMsg);
        	if (rc != M_CM_OK)
        	{
        		sprintf( sErrMsg, "�O�渹[%s], %s", XIpolicy, v_sMsg);
        		$ROLLBACK WORK;
        		return rc;
        	}
	}
        */

        strcpy( iendorse, "");
        sprintf( stmt, " SELECT first 1 iendorse,feedr "
                       "   FROM edr_relation "
                       "  WHERE ipolicy = '%s'"
                       "    AND iendorse not like '%%CVP%%'"
                       "  ORDER BY dcreate DESC; ", XIpolicy );
printf("[%s]\n", stmt);
        $PREPARE prep1 FROM $stmt;
        $EXECUTE prep1 INTO $iendorse,$feedr;

        rc = chk_iendorse_status( iendorse, v_sMsg);
        if(rc != M_CM_OK)
        {
            sprintf( sErrMsg, "�O�渹[%s], %s", XIpolicy, v_sMsg);
   	    $ROLLBACK WORK;
            return rc;
        }

        strcpy(sTmpiofficer, trim(sTmpiofficer));
        printf("sTmpiofficer = [%s] \n", sTmpiofficer );
        /* �g��N�����M�׷~�ȮɡA�h�𶷻s�@������ */
        if( (strncmp(sTmpiofficer,"W",1)==0) && (strncmp(sTmpiofficer+6,"LE30",4)!=0) && printW[0] == 'N')
        {
             printf("422 in do not call ca_rpt_policy\n");
             /* Do not call ca_rpt_policy() */
             rc = M_CM_OK;
        }

        /* �M�ץ�P�_:�s�WH�g��B������H0-H2 modify by sylvia 102.12.12 (1021122001_C1) */
        if( (strncmp(sTmpiofficer,"H",1)==0) &&
        	  ((strncmp(sTmpiofficer,"H0",2)!=0) && (strncmp(sTmpiofficer,"H1",2)!=0)
        	    && (strncmp(sTmpiofficer,"H2",2)!=0)) &&
        	  (printW[0] == 'N'))
        {
             printf("422 in do not call ca_rpt_policy\n");
             /* Do not call ca_rpt_policy() */
             rc = M_CM_OK;
        }
        /* �M�ץ�P�_:�s�WN�g��*/
        strcpy(sIresource, trim(sIresource));
        printf("sTmpiofficer=%s\nsIresource=%s\nprintW=%s\n",sTmpiofficer,sIresource,printW);
        if( (strncmp(sTmpiofficer,"N",1)==0) && (strncmp(sIresource,"E",1)==0) && printW[0] == 'N')
        {
             printf("422 in do not call ca_rpt_policy\n");
             /* Do not call ca_rpt_policy() */
             rc = M_CM_OK;
        }

        /**
        else if ( (strcmp(sTmpiofficer,"F9813501")==0) || (strcmp(sTmpiofficer,"F9814201")==0) && printW[0] == 'N')
        {
              Do not call ca_rpt_policy()
             rc = M_CM_OK;
        }
        ***/
        else
        {
        	if(strcmp(tmp_feply,"0") == 0)
        	{
        	     
        	     if (strncmp(XIpolicy+5,"V7",2)==0)
        	     {
            	        sprintf( sErrMsg, "�O�渹[%s]:V7�r�y�O�椣�o�ɵo�ȥ��O��A�ФĿﲣ�s�q�l�O��!", XIpolicy);
			$ROLLBACK WORK;            		
			return 0;	
        	     	
        	     }
        	     
        	     
        	     
	             if( EveryBigPolicy[0] == 'N')
	             {
	                 if (ptr[0]=='1')
	                 {
	                 	  /* old_iply��A���O�s���O��,B�h���¦��O��,iPrintlist�h���O�_�C�L�W�U(0�L,1���L) */
	                 	  /* type == 'a' �O�Ъ���, type == 'b'�O�帹, �H�O�I�Ҹ��C�L�O�椣�|�C�L�j�O�� */
	                 	  /* �Ytype���Ъ����ɻݭn���D�������O�渹,�~��p��j�O�檺�O�O */
	                 	  if (old_iply[0] == 'A')
	                              rc=ca_rpt_policy(XIpolicy, "�ɵo", ibatch_no, ikind, iFbig, iPrintlist, type, plyend,userid,PrintDlist,ProtectData,DBName,"0","","","",sEterms);
	                          else
	                              rc=ca_rpt_policy_old(XIpolicy, "�ɵo", ibatch_no, ikind, iFbig);
	
	                          if (rc != M_CM_OK)
	                          {
	                    	      strcpy(v_sMsg, cm_get_errmsg(rc));
	             		      sprintf( sErrMsg, "�O�渹[%s], %s", XIpolicy, v_sMsg);
	             		      $ROLLBACK WORK;
	                    	      return rc;
	                          }
		         }
			 else
	                 {
	                 	  /* old_iply��A���O�s���O��,B�h���¦��O��,iPrintlist�h���O�_�C�L�W�U(0�L,1���L) */
	                 	  /* type == 'a' �O�Ъ���, type == 'b'�O�帹, �H�O�I�Ҹ��C�L�O�椣�|�C�L�j�O�� */
	                 	  if (old_iply[0] == 'A')
	                              rc=ca_rpt_policy(XIpolicy, "0", ibatch_no, ikind, iFbig, iPrintlist, type, plyend, userid,PrintDlist,ProtectData,DBName,"0","","","",sEterms);
	                          else
	                              rc=ca_rpt_policy_old(XIpolicy, "0", ibatch_no, ikind, iFbig);
	
	                          if (rc != M_CM_OK)
	                          {
	                    	      strcpy(v_sMsg, cm_get_errmsg(rc));
	             		      sprintf( sErrMsg, "�O�渹[%s], %s", XIpolicy, v_sMsg);
	             		      $ROLLBACK WORK;
	                    	      return rc;
	                          }
	                 }
	             }
	             else
	             {
	                 if (ptr[0]=='1')
	                 {
	                 	  /* old_iply��A���O�s���O��,B�h���¦��O�� */
	                 	  /* type == 'a' �O�Ъ���, type == 'b'�O�帹, �H�O�I�Ҹ��C�L�O�椣�|�C�L�j�O�� */
	                 	  /* �Y�C�L�j�O��C�i���,���|���O�O�p�⪺���D,�Gply_end�L�ݶǤJ */
	                 	  if (old_iply[0] == 'A')
	                              rc=ca_rpt_policy(XIpolicy, "�ɵo", ibatch_no, ikind, FALSE, iPrintlist, type, "", userid,PrintDlist,ProtectData,DBName,"0","","","",sEterms);
	                          else
	                              rc=ca_rpt_policy_old(XIpolicy, "�ɵo", ibatch_no, ikind, FALSE);
	
	                          if (rc != M_CM_OK)
	                          {
	                    	      strcpy(v_sMsg, cm_get_errmsg(rc));
	             		      sprintf( sErrMsg, "�O�渹[%s], %s", XIpolicy, v_sMsg);
	             		      $ROLLBACK WORK;
	                    	      return rc;
	                          }
		         }
			 else
	                 {
	                 	  /* old_iply��A���O�s���O��,B�h���¦��O�� */
	                 	  /* type == 'a' �O�Ъ���, type == 'b'�O�帹, �H�O�I�Ҹ��C�L�O�椣�|�C�L�j�O�� */
	                 	  if (old_iply[0] == 'A')
	                              rc=ca_rpt_policy(XIpolicy, "0", ibatch_no, ikind, FALSE, iPrintlist, type, "", userid,PrintDlist,ProtectData,DBName,"0","","","",sEterms);
	                          else
	                              rc=ca_rpt_policy_old(XIpolicy, "0", ibatch_no, ikind, FALSE);
	
	                          if (rc != M_CM_OK)
	                          {
	                    		strcpy(v_sMsg, cm_get_errmsg(rc));
	             			sprintf( sErrMsg, "�O�渹[%s], %s", XIpolicy, v_sMsg);
	             			$ROLLBACK WORK;
	                    		return rc;
	                          }
	                 }
	             }
	        }
                else
                {
            	    /*** �D�q�l�O��ݥ���אּ�q�l�O���A�ɱH�e�q�l�O�� ***/
            	    if (strcmp(feply,"1") != 0)
            	    {
            	        sprintf( sErrMsg, "�O�渹[%s]:�Цܧ��{�����q�l�O����O�A�l�i�i��ɵo�@�~�E", XIpolicy);
			$ROLLBACK WORK;            		
			return 0;
            	    }
				
		    /*** ��w���q�l�O��A�����z�Le�O���ɵo�q�l�O�� ***/
		    strcpy(iendorse,trim(iendorse));
		    if(strcmp(iendorse,"")==0)
		        sprintf(stmt1," ");
		    else
		        sprintf(stmt1,"AND iendorse = '%s'",iendorse);

		    sprintf( stmt, " select count(*)       "
                                   "   from cm_e_policy    "
                                   "  WHERE ipolicy = '%s' "
                                   "    %s ;" , XIpolicy,stmt1 );
				
		    printf("stmt[%s]\n",stmt);
				
		    $PREPARE prep_cnt FROM $stmt;
        	    $EXECUTE prep_cnt INTO $eply_cnt;
            	    
            	    printf("eply_cnt[%d]XIpolicy[%s]iendorse[%s]\n",eply_cnt,XIpolicy,iendorse);
            	 
            	    if (eply_cnt > 0)
            	    {
            		sprintf( sErrMsg, "�O�渹[%s]:�w�ɵo�L�q�l�O��A�Цܩx��������e�O��CM0901�ɱH�Ȥ�Y�i�C", XIpolicy);
			$ROLLBACK WORK;            		
			return 0;
            	    }
            	    else if (strcmp(feedr,"2") != 0)
            	    {
            		sprintf( sErrMsg, "�O�渹[%s]:�Цܧ��{�����q�l�O��-�̷s�O����O�A�l�i�i��ɵo�@�~�C", XIpolicy);
			$ROLLBACK WORK;            		
			return 0;
            	    }



             	    strcpy(sIrelative_ply,trim(sIrelative_ply));
             	
             	    if (strcmp(aemail_eply) == "") strcpy(aemail_eply," ");
             	    if (strcmp(tmobile_eply) == "") strcpy(tmobile_eply," ");
        	 	
        	 	/* car344 �e�~��אּ�q�l�O���
				$update ply_relation
				    set feply = '1',aemail_eply = $tmp_aemail_eply
				  where ipolicy = $XIpolicy;
				  
				$update ori_ply_relation
				    set feply = '1',aemail_eply = $tmp_aemail_eply
				  where ipolicy = $XIpolicy;
				*/
    	            /* 1060328006_C1 �s�W�q�l�O�椽�ΫH�c(�q�ӳ��ϥ�) */
    	            if (strcmp(sIroute,"JB") == 0) strcpy(sIcomp_in , "88");
    	        	        	 	
        	    /* �q�l�O�椣�ݦL�X�ȥ���ơA�ݱN�O���Ƽg�J�q�l�O������ */
        	    $select nvl(max(iserno),0)+1
                       into $iserno
                       from cm_e_policy
                      where ipolicy = $XIpolicy;
                      
                    sprintf( siserno, "%02d", iserno);  
                    
    	            /*�P�_�r�y��V7-->�ֳt��*/
    	            fspeed=1;
    	            if (strncmp(XIpolicy+5,"V7",2)==0) fspeed=2;
    	            
                    /*�O�o���ɦW*/
        	    strcpy(e_nfile,"");
        	    strcat(e_nfile,"P17CAR_");
        	    strcat(e_nfile,trim(XIpolicy));
        	    strcat(e_nfile,"_");
        	    strcat(e_nfile,trim(yyyy));
        	    strcpy(e_nfile,trim(e_nfile));
        	    
                    
                    /*�P�_�O�_���ǰe�L�O�o����*/
                    $select count(*)
                       into $chk_ftype
                       from cm_e_policy
                      where ipolicy = $XIpolicy and ftype='2' and iins_cat='C';
                      
                     
                    if(chk_ftype > 0 )  /*�j��0���ܦ��ǰe�L�O�o����-->�쬰�q�l(�O�o)�ɵo�q�l(�O�o)*/
                    {
                    	
            		sprintf( sErrMsg, "�O�渹[%s]:�Ц�car409���s�q�l���C", XIpolicy);
			$ROLLBACK WORK;            		
			return 0;

                    	
                    }
                    else  /*����0���ܥ��ǰe�L�O�o����-->�쬰�ȥ��ɵo�q�l or �쬰�q�l(TWCA)�ɵo�q�l(�O�o)*/ 
                    {
                    	
        	        if (ptr[0]=='1')
        	        {
        	        	
        	            $INSERT INTO cm_e_policy (iins_cat,ipolicy,iendorse,iserno,ftype,fspeed,iins_kind_ply,
                                                      iendorse_ti,fprocess,fdata,ibranch_code,icustomer,npassword,
                                                      nemai_send,tsms_mobile,nfile,dbgn,dend,fstatus,
                                                      iapplicant,iassured,ientry,dentry,iupdate,dupdate,
                                                      nplyidx1,nplyidx2,nplyidx3,nedridx1,nedridx2,nedridx3)
                                              VALUES ('C',$XIpolicy, $iendorse, $siserno,'2',$fspeed,'C2',
                                                      '', 'A','P',$sIcomp_in,$sIapplicant,$sPasswd,
                                                      $aemail_eply,$tmobile_eply,$e_nfile,$sDply_bgn,$sDply_end,100,
                                                      $sIapplicant,$sIassured,$userid,CURRENT,'car307',CURRENT,
                                                      ' ',' ',' ',' ',' ',' ');
 
        	        }
        	        else
        	        {
        	            $INSERT INTO cm_e_policy (iins_cat,ipolicy,iendorse,iserno,ftype,fspeed,iins_kind_ply,
                                                      iendorse_ti,fprocess,fdata,ibranch_code,icustomer,npassword,
                                                      nemai_send,tsms_mobile,nfile,dbgn,dend,fstatus,
                                                      iapplicant,iassured,ientry,dentry,iupdate,dupdate,
                                                      nplyidx1,nplyidx2,nplyidx3,nedridx1,nedridx2,nedridx3)
                                              VALUES ('C',$XIpolicy, $iendorse, $siserno,'2',$fspeed,'C2',
                                                      '', 'A','P',$sIcomp_in,$sIapplicant,$sPasswd,
                                                      $aemail_eply,$tmobile_eply,$e_nfile,$sDply_bgn,$sDply_end,100,
                                                      $sIapplicant,$sIassured,$userid,CURRENT,'car3071',CURRENT,
                                                      ' ',' ',' ',' ',' ',' ');
        	        } 

                    }

                    
                    /*TWCA�q�l�O��*/
                    /*
                    sprintf( e_nfile, "%s%s", trim(XIpolicy), siserno);
        	    if (ptr[0]=='1')
        	    {
        	        $INSERT INTO cm_e_policy(iins_cat,ipolicy,iendorse,iserno,ibranch_code,icustomer,npassword,nemai_send,tsms_mobile,nfile,dend,fstatus,ientry,dentry,iupdate,dupdate)
				         VALUES ('C',$XIpolicy,$iendorse,$siserno,$sIcomp_in,$sIapplicant,$sPasswd,$aemail_eply,$tmobile_eply,$e_nfile,$sDply_end,100,$userid,CURRENT,'car307',CURRENT);
        	    }
        	    else
        	    {
        	 	$INSERT INTO cm_e_policy(iins_cat,ipolicy,iendorse,iserno,ibranch_code,icustomer,npassword,nemai_send,tsms_mobile,nfile,dend,fstatus,ientry,dentry,iupdate,dupdate)
					 VALUES ('C',$XIpolicy,$iendorse,$siserno,$sIcomp_in,$sIapplicant,$sPasswd,$aemail_eply,$tmobile_eply,$e_nfile,$sDply_end,100,$userid,CURRENT,'car3071',CURRENT);
        	    }
        	    */
            	

		    /* �q�l��O���� */
		    if(strlen(sIrelative_ply) > 0)
		    {
		        /* �P�ɱH�o�j���I��O���� */
			$SELECT a.icard,nvl(a.dpolicy," "),a.iquota,b.nassured,b.iassured,b.iengine
			   INTO $sIcard1,$sDpolicy1,$sIquota1,$sNassured1,$sIassured1,$sIengine1
			   FROM ply_relation a,policy b
			  WHERE a.ipolicy = b.ipolicy
			    AND a.ipolicy = $sIrelative_ply
			    AND a.dply_end >= today;
					
			if (SQLCODE != SQLNOTFOUND)
			{
			    strcpy(sDpolicy1,trim(sDpolicy1));

			    if(strlen(sDpolicy1) != 0)
			    {
			        strcpy(sIassured,trim(sIassured));
				strcpy(sIassured1,trim(sIassured1));
				strcpy(sIengine,trim(sIengine));
				strcpy(sIengine1,trim(sIengine1));
							
				if ((strcmp(sIassured,sIassured1) == 0) && (strcmp(sIengine,sIengine1) == 0))
				{
					/* ���P�ɱH�o�j���I��O���� */
					$update ply_relation
					    set feply = '2'
					  where ipolicy = $sIrelative_ply;
					/*  
					$update ori_ply_relation
					    set feply = '2'
					  where ipolicy = $sIrelative_ply;
					*/
				}
			    }
			}
		    }
                }
                count_no_tobe ++;
        }
        if (rc!=M_CM_OK)
        {
        	$ROLLBACK WORK;
        	return rc;
        }
        
        rc2 = insert_ca_log("car307","P",XIpolicy," ","�O��ɵo",userid,Msg);
        printf("Msg[%s] rc[%d]",Msg,rc2);
        if( rc2 != M_CM_OK)
        {
        	SQLCODE = rc2;
        	goto errexit;
        }

        /* 1001003001_C1 ���r�y����CVP�A�L�����(edr_relation.dendorse)�A�C�L����~�g�J�����(�浧�C�L) */
        $UPDATE edr_relation
            SET dendorse = today, fprint = '1'
          WHERE ipolicy = $XIpolicy
            AND dendorse is null
            AND iendorse not like '%CVP%';
    
        $UPDATE edr_relation
            SET fply_print = '2'
          WHERE ipolicy = $XIpolicy
            AND fply_print = '1'
            AND iendorse not like '%CVP%';
    
        /* �Ȥ��{�d�C�L�e�~�O���(car344)
           �^���l�H�覡(0:���e�~�l�H) add by larry 103.03.13 (1010523004_C2) 
   
        	$UPDATE ply_relation
            	    SET fmail_type = '0'
          	  WHERE ipolicy = $XIpolicy
            	    AND dpolicy = today
            	    AND fout_print = '1'
            	    AND fmail_type != '0'
            	    AND dply_close is null;
	*/
	
	/* �Ȥ��{�d�C�L�e�~�O���(car344)
           �^���l�H�覡(0:���e�~�l�H) add by �L�� 105.01.26 (1050115002_C1) */
        if (strlen(trim(sDout_trans)) == 0 && strcmp(trim(sFout_print),"1") == 0 && strcmp(trim(sFmail_type),"0") != 0)
        {
        	$UPDATE ply_relation
            	    SET fmail_type = '0'
          	  WHERE ipolicy = $XIpolicy
            	    AND fout_print = '1'
            	    AND fmail_type != '0'
            	    AND dout_trans is Null;

            	$UPDATE ori_ply_relation
            	    SET fmail_type = '0'
          	  WHERE ipolicy = $XIpolicy
            	    AND fout_print = '1'
            	    AND fmail_type != '0'
            	    AND dout_trans is Null;
        }
       
        

        if (iFpolicy && iFbig && EveryBigPolicy[0] == 'N') break;
    }
    printf("------>iFpolicy [%d]\n", iFpolicy);
    printf("------>iFbig [%d],type[%s]\n", iFbig, type);

    if (iFpolicy)
    {
        if (iFbig)
        {
            if (type[0]=='a')
            {
                $CLOSE PLY_CUR_1;
            }
            else if (type[0]=='b')
            {
                $CLOSE PLY_CUR_1_1;
            }
        }
        else
        {
            if (choice[0] == '1') 
                $CLOSE PLY_CUR_2;
            else if (choice[0] == '2') 
                $CLOSE PLY_CUR_3;
            else if (choice[0] == '3') 
                $CLOSE PLY_CUR_5;
            else if (choice[0] == '4') 
                $CLOSE PLY_CUR_6;
            else
                $CLOSE PLY_CUR_7;
        }
    }
    else $CLOSE PLY_CUR_4;

    if (iFpolicy)
    {
        if (iFbig)
        {
            if (type[0]=='a')
            {
                $FREE PLY_CUR_1;
            }
            else if (type[0]=='b')
            {
                 $FREE PLY_CUR_1_1;
            }
        }
        else
        {
            if (choice[0] == '1') 
                $FREE PLY_CUR_2;
            else if (choice[0] == '2') 
                $FREE PLY_CUR_3;
            else if (choice[0] == '3') 
                $FREE PLY_CUR_5;
            else if (choice[0] == '4') 
                $FREE PLY_CUR_6;
            else
                $FREE PLY_CUR_7;
        }
    }
    else $FREE PLY_CUR_4;

    if (count == 0){
    	return M_CA_NREL_PLY;
    }

    /* �C�L�O��B���ζ�TOBE�M�׮ɡA�h��ܤ��o�C�L�O�椺�e���T�� */
    if ((count_no_tobe == 0))
    {
        return M_CA_TOBE_NO_PRINT;
    }

    $commit work;
    rgu_finish_report();

    return M_CM_OK;

errexit:
    printf("SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
    $rollback work;
    return SQLCODE;
}

/**** �C�L�ˮ`�I��� ****/
static long car307_build_pa()
{
    int     rc, res;
    char    OutFile[20], tmpcmd[40], hostname[20];
    char    tmpOutFile[51];
    $char   FormFile[21];
    $int    ibatch_no ,id;
    char    aphome[40];
    $char   cIpolicy[21];

    $char   ymd_Today[12];

    if (db_select(DBName) == False)
        return M_CM_DB_NOTOPEN;

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;

    strcpy(ymd_Today, cm_cdate_str(Today));

    $SELECT kPgNum_Line, nForm_File
       INTO $PgLine, $FormFile
       FROM Form
      WHERE ksys_grp = "CA"
        AND kPgmID   = 33;
    if (SQLCODE==SQLNOTFOUND)
    {
        return M_CM_NOT_FOUND;
    }

    strcpy(FormFile , rtrim(FormFile));
    sprintf(OutFile , "%s.tx",outputf);

    printf("FormFile[%s],OutFile[%s]\n",FormFile,OutFile);
    rgu_init_report(FormFile,OutFile);

    printf("begin ca_rpt_pa \n");
    $declare cur_pa cursor for
      select distinct a.ipolicy
        into $cIpolicy
        from ply_relation a,ply_ins_type b, insurance_type c
       where a.ipolicy between $plybgn and $plyend
         and a.dpolicy is not null
         and a.ipolicy = b.ipolicy
         and b.iins_type = c.iins_type
         and (b.iins_type in ('33','35','48','56') or c.pa_list = 'Y')
         and b.mdamage_cover != 0;
    $open cur_pa;

    while(1)
    {
        $fetch cur_pa;
        if (SQLCODE==SQLNOTFOUND) break;

        printf("ipolicy[%s]\n",cIpolicy);
        rc = ca_rpt_pa(cIpolicy);
        printf("end   ca_rpt_pa \n");
        if (rc != M_CM_OK) return rc;
    }

    rgu_finish_report();

    return M_CM_OK;

errexit:
    printf("SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/**************************************************************************END*/
