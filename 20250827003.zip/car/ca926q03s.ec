/**********************************************************************/
/*   program id   : ca926q03s.ec                                      */
/*   1.�����߷s�w������                                               */
/*                                                                    */
/*   �ݳB�z�G                                                         */
/*        1.��Ƥ��:���P�B�Q�O�I�H���ˮ� policy_bak                  */
/*        2.�O�����:�Ҧ��I�ؤ�� ply_ins_type_hist                   */
/*        3.                                                          */
/*   �ݽT�{:                                                          */
/*        1.�h�i��檺��� (�ثe�ݨ��i�O�榳29�i���, �@���b���L��) */
/*        2.���ƤH��Ƥ���޿� (�������p(�������D,�����r�p,��訮���D,��訮�r�p) */
/*        3.���ƤH ���`�H����H�B�~��H�B�ʧO �P�_                    */
/*        4.���`�H�z�߶��جO�n�v���٦X��                              */
/*        5.�z�ߧP�_�]��                                              */
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
#define TRUE 1
#define FALSE 0
#include "safeclib.h"

long   rtncode;

DBinfo  *list;
int     count_db;
char   	sApHome[50];
$char  	DBName[5], userid[11], sRpt1[2], txtfile[101], outputf[21];
$char  	errMsg[5000000], stmp[5000000], sFullName[80],errMsg2[150], sItransno[51],
        sErrorMsg[400];
int 		offset;
FILE   *sfp,*fp;
static char  *bp;
static int   recLen=1024;
$char getfile[400];
char delimiter;
char fNewClaim[2];  /* �O�_���߷s�� Y:�s�� N:�w���®� */
/* ------------------------------------------------------------------------- */
$char g_company[3], g_bank[8], g_accbank[21];
/* ------------------------------------------------------------------------- */
$char	sInumber[6], sIcompany[3], sOth_claim[21], sOth_card[21], sOth_nation[2],
		sOth_CarType[3], sOth_qpt[6], sOth_fpt[2], sOth_tag[13], sDaccident[17],
    	sOth_reason[3], sNewa_reason[3], sOth_area[3], sOth_nassured[21], sOth_victim[11],
		sOth_Dvictim[11], sOth_item1[4], sOth_item2[2], sOth_Mstl[8],
		sOth_fvictim[2], sOth_adjuster1[4], sOth_adjuster2[4],
		sOth_adjuster3[4], sOth_tag2[13], sOth_cpy2[3], sOth_card2[22],
		sOth_prem[8], sDvp_abbr[21], sAdjustment[11], sYY[5], sMM[3], sDD[3],
		sHH[3],sMS[3], sIins_item[5], sItag3[13], sIclaim[21], sIpolicy[21],
		sDacc_birth[11], sNacc_area[21], sFassured[2], sNacc_driver[121],
        sIacc_license[12], sIacc_birth[11], sFacc_sex[2], sFacc_marri[2],
        sFacc_rel[2], sDaccident2[25], sFacc_nation[2],sIaccuserid[12],
        sItag[13],sIacc_area[3], sDacc_mdy[11], sFadjuster[3], sDataYM[6],
    sDoth_birth[11], sIoth_birth[11];

$double	dblQpt;
$int	iNumber, icompany, iMins_stl, iQduty1, iQduty2, iQduty3, iMprem, iline,
            iYY, iMM, iDD, iHH, iMS, ierrcnt;
/* ------------------------------------------------------------------------- */
$char  sIassured[13], sNassured[121], sFvictim_car[2], sFdrive[2];
$char sTmpSQL573[5000];
/*----------------------------------------------------------------------------*/
$char isign_tmp[8];
$char   kcomp_no[3], kdept_no[3], dyear[3], kserial_index[7], kserial_num[12],
        sIquota[7], g_fpce_id[11], g_cmp[15], fqpt[2];

long car926_trans();
long rc;

char *get_car_full_db();

main(argc, argv)
int argc;
char **argv;
{
    batchinit();
    strcpy(DBName       ,isNULLstr(argv[1]));
    strcpy(userid       ,isNULLstr(argv[2]));
    strcpy(g_company    ,isNULLstr(argv[3]));   /*�߮פ��q�O*/
    strcpy(g_fpce_id    ,isNULLstr(argv[4]));   /*�Ȥ�s��*/
    strcpy(g_bank    	,isNULLstr(argv[5]));   /*��w�N�X*/
    strcpy(g_accbank    ,isNULLstr(argv[6]));   /*�Ȧ�b��*/
    strcpy(sItransno    ,isNULLstr(argv[7]));   /*���ɧ帹*/
    strcpy(sDataYM    	,isNULLstr(argv[8]));   /*��Ʀ~��*/
    strcpy(sAdjustment  ,isNULLstr(argv[9])); /*�u�߸g��*/
    strcpy(fqpt         ,isNULLstr(argv[10])); /*�u�߸g��*/
    strcpy(txtfile      ,isNULLstr(argv[11]));   /*��r��*/
    strcpy(outputf      ,isNULLstr(argv[12]));

		strcpy(sItransno, trim(sItransno));
    printf("sItransno = [%s] txtfile = [%s]\n",sItransno, txtfile);

		strcpy(g_fpce_id, trim(g_fpce_id));
		strcpy(g_bank, trim(g_bank));
		strcpy(g_accbank, trim(g_accbank));

    rc = car9263_get_db();
    if (rc != M_CM_OK) {
        printf("error on car926_get_db\n");
        EWRITE(userid, rc, "error on car926_get_db");
        return rc;
    }

    $WHENEVER SQLERROR CONTINUE;

   	rc=car9263_trans_M();  /* ����ˮ� */
    if (rc != M_CM_OK)
    {
	        printf("car9263_trans:errMsg=[%s]\n",errMsg);
	        strcpy(stmp,"car9263_trans ���ɥ���, �нT�{�íץ���A���s����!! \n\n\n");
	        strcat(stmp,"�Ǹ�\t�߮פ��q�N��\t�߮׸��X\t�Q�O�I�H�Ҹ�\t���~�N�X\t���~�T��\n");
	        strcat(stmp,errMsg);
	        EWRITE(userid,rc,stmp);
	        return rc;
    }

    /* ���z�B�w���B�d�ҡB�ɮ֡B�z�� */
    rc=car9263_exec();
    if (rc != M_CM_OK)
    {

	        printf("[�j���I�u�߸�Ƽg�J�z�ߨt��  ���楢��]\n");
	        sprintf_s(stmp,5000000,"car9263_exec ���楢��,�нT�{�íץ���A���s����!! \n\n ");
	        strcat(stmp,errMsg);
	        EWRITE(userid,rc,stmp);
	        return rc;
    }
    printf("-------------- 133 -------\n");

    $SELECT trim(icode) || ' (' ||trim(tcode_remark)||')'    into $g_cmp
       FROM cu_code_data
      WHERE itype = 'HC' and icode = $g_company;

    sprintf_s(stmp,5000000,"�P�~ %s �j���I�߮��u�X���ɧ���!�@\n\n",g_cmp);
    strcat(stmp,"�߮פ��q\t�P�~�׸�\t�P�~�d��\t�P�~����\t�s�w�߮׸�\t����\t�ߴ� \n");
    strcat(stmp, errMsg);
    EWRITE(userid,M_CM_OK,stmp);
		/* exit(SUCCESS); */
    return M_CM_OK;
}

/* ------------------------------------------------------------------------- */
void GetData(data, maxlen, delimiter)
char *data, delimiter;
int maxlen;
{
    int fori, pre_offset, cnt=0;

    data[0]='\0';
    pre_offset = offset;

    for (fori=pre_offset; bp[fori]!=0x00&&bp[fori]!=0x0d&&bp[fori]!=0x0a&&bp[fori]!=delimiter; fori++)
    {
        offset++;
        if (cnt < maxlen-1)
        {
            data[cnt]=bp[fori];
            cnt++;
        }
    }

    offset++; /* ���ܤU�@�� */
    if (cnt==0) data[cnt++]=0x20; /* �L��Ƶ��ť� */
    data[cnt]=0x00;
    printf("pre_offset[%d]offset[%d]len[%d]data[%s]\n", pre_offset, offset, cnt, data);
}

/* ------------------------------------------------------------------------- */
long car9263_trans_M()
{
    $char   sTmpData1[50], sTpTmp1[3000], sTp_id[11], sTp_bank[11], sTp_accbank[21],
            sTmpClaim[20], sIins_ply[7];

    $int    ichk1, ichk2, icnt, mfactor, fchk1, icnt1, iMprem_A, iMins_stl_A;

    $int    rtn;

    $char sToday[11], sYN[2], iportfolio[11], igroup_profit[21], ibranch[6],
          sfulldb[25], sIcar_type[3], fapply[2], kreserve[6], icohort[5], fterm[2];
    $char sMsg[200];

    $WHENEVER SQLERROR GOTO errexit;

    sprintf_s(getfile,400,"%s/dat/car/%s",sApHome,txtfile);
    printf("getfile[%s]\n",getfile);

    if ((fp=fopen(getfile,"rt"))==NULL)
    {
        return FAIL;
    }

    if ((bp=malloc(recLen))==NULL) 
	{ 
		printf("System malloc failed  !\n"); 
		free(bp);
		return FAIL; 
	}

    /* ���j�Ÿ� */
    delimiter=''; /* �`�N:���j�Ÿ��� ascii(127) */
    /* $delete from car9263_tpm1 where 1=1; */

    $CREATE TEMP table car9263_tpm1
    (
    	inumber				int,					-- 1 �Ǹ�
			icompany			char(2),			-- 2 �O�I���q
			iclaim				char(20),			-- 3 �߮׸�
			icard					char(20),			-- 4 �O�I�Ҹ�
			fvictim_nation		char(1),	-- 5 �Q�O�H�����N��
			icar_type			char(2),			-- 6 ���إN��
    	qpt						decimal(4,1),	-- 7 �����ƶq
    	fpt						char(1),			-- 8 �������
    	itag					char(12),			-- 9 ���P���X
    	dacc_yy			  char(4),		  -- 10 �X�I���(�褸�~)
    	dacc_mm			  char(2),		  -- 11 �X�I���(��)
    	dacc_dd 			char(2),		  -- 12 �X�I���(��)
    	dacc_hh 			char(2),		  -- 13 �X�I���(��)
    	dacc_ms 			char(2),		  -- 14 �X�I���(��)
    	iacc_reason		char(2),			-- 15 �X�I��]�N��
    	iacc_area			char(2),			-- 16 �X�I�a�ϥN��
    	nassured			char(20),			-- 17 ���`�H�m�W
    	ivictim				char(10),			-- 18 ���`�H�����Ҹ�
    	dvictim				char(8),			-- 19 ���`�H�ͤ�
    	iins_item1		char(3),			-- 20 ���I���O�ζ���1(A���� B���` C����)
    	iins_item2		char(1),			-- 21 ���I���O�ζ���2
    	mins_stl			int,					-- 22 �z�ߪ��B
    	fvictim_car				char(1),	-- 23 ���`�H�O
      qduty_adjuster		int,			-- 24 �����F�d�ʤ���
      qduty_adjuster2		int,			-- 25 ��y���F�d�ʤ���
      qduty_adjuster3		int,			-- 26 ��L�F�d�ʤ���
      itag2					char(12),			-- 27 ��y���P���X
      oth_company		char(2),			-- 28 ��y���q�N�X
      oth_card			char(21),			-- 29 ��y�O�I�Ҹ�
      mprem					int,					-- 30 ���u���B
      iclaim_2      char(20),			-- 31 �s�w�߮׸�
      adjustment    char(10),			-- 32 �u�߸g��
      daccident     datetime year to minute, -- 33 �X�I�ɶ�
      iins_item     char(4),      -- 34 ��������
      ipolicy       char(20)     	-- 35 �O�渹
    )with no log;

    $create index car9263_tpm1_x1 on
    	car9263_tpm1(icompany, iclaim);


    /* 1.1 IFRS�ˮֶ}�� */
    $select first 1 today into $sToday
       from car_code
      where 1=1;

    printf("sToday=[%s]\n",sToday);
    rtn = cm_get_IFRS_DATE(sToday, &sYN);
    printf("sToday=[%s], sYN=[%s]\n",sToday,sYN);


    iline = 0;			/* �ɮ׵��� */
    while(fgets(bp,recLen,fp))
    {
        if (feof(fp)) break;
        offset = 0;

        /* ��ƨ��o���Ǥ��i�ܰ� */
				GetData(sInumber,       sizeof(sInumber),       delimiter);     /* 1 �Ǹ�*/
    		strcpy(sInumber, trim(sInumber));
    		iNumber = atoi(sInumber);

    		GetData(sTmpData1,      sizeof(sTmpData1),	    delimiter);     /* 2 �P�~�O�I���q*/
    		strcpy(sTmpData1, trim(sTmpData1));
    		icompany = atoi(sTmpData1);
    		sprintf_s(sIcompany,3, "%02d", icompany);

    		GetData(sOth_claim,     sizeof(sOth_claim),     delimiter);     /* 3 �P�~�߮׸�*/
    		strcpy(sOth_claim, trim(sOth_claim));

    		GetData(sOth_card,      sizeof(sOth_card),      delimiter);     /* 4 �P�~�O�I�Ҹ�*/
    		strcpy(sOth_card, trim(sOth_card));

    		GetData(sOth_nation,    sizeof(sOth_nation),    delimiter);     /* 5 �P�~�Q�H�H�����N�� */
    		strcpy(sOth_nation, trim(sOth_nation));

    		GetData(sTmpData1,      sizeof(sTmpData1),      delimiter);     /*6 �P�~���إN�� */
    		strcpy(sTmpData1, trim(sTmpData1));
    		sprintf_s(sOth_CarType,3, "%02d", atoi(sTmpData1));

    		GetData(sOth_qpt,       sizeof(sOth_qpt),       delimiter);     /* 7 �P�~�����ƶq*/
    		strcpy(sOth_qpt, trim(sOth_qpt));
    		if (fqpt[0] == '1')
    		    dblQpt = atof(sOth_qpt)/10;
    		else
    		    dblQpt = atof(sOth_qpt);



    		GetData(sOth_fpt,       sizeof(sOth_fpt),       delimiter);     /* 8 �P�~�������*/
    		strcpy(sOth_fpt, trim(sOth_fpt));

    		GetData(sOth_tag,       sizeof(sOth_tag),  		delimiter);     	/* 9 �P�~���P���X*/
    		strcpy(sOth_tag, trim(sOth_tag));

    		GetData(sYY,            sizeof(sYY),	        delimiter);     	/* 10 �X�I���(�褸�~) */
    		strcpy(sYY, trim(sYY));

    		GetData(sMM,	        sizeof(sMM),	        delimiter);     		/* 11 �X�I���(��) */
    		strcpy(sMM, trim(sMM));

    		GetData(sDD,	        sizeof(sDD),	        delimiter);     		/* 12 �X�I���(��) */
    		strcpy(sDD, trim(sDD));

    		GetData(sHH,	        sizeof(sHH),	        delimiter);     		/* 13 �X�I���(��) */
    		strcpy(sHH, trim(sHH));

    		GetData(sMS,	        sizeof(sMS),	        delimiter);     		/* 14 �X�I���(��) */
    		strcpy(sMS, trim(sMS));

    		GetData(sOth_reason,    sizeof(sOth_reason),	delimiter);     	/* 15 �P�~�X�I��]�N�� */
    		strcpy(sOth_reason, trim(sOth_reason));

    		GetData(sTmpData1,      sizeof(sTmpData1),      delimiter);     /* 16 �P�~�X�I�a�ϥN�� */
    		strcpy(sTmpData1, trim(sTmpData1));
    		sprintf_s(sOth_area,3, "%02d", atoi(sTmpData1));

    		GetData(sOth_nassured,  sizeof(sOth_nassured),  delimiter);     /* 17 �P�~���`�H�m�W */
    		strcpy(sOth_nassured, rtrim(sOth_nassured));

    		GetData(sOth_victim,    sizeof(sOth_victim),    delimiter);     /* 18 �P�~���`�H�����Ҹ� */
    		strcpy(sOth_victim, rtrim(sOth_victim));

    		GetData(sOth_Dvictim,   sizeof(sOth_Dvictim),   delimiter);     /* 19 �P�~���`�H�ͤ� */
    		strcpy(sOth_Dvictim, rtrim(sOth_Dvictim));

    		GetData(sOth_item1,	    sizeof(sOth_item1),	    delimiter);     /* 20 �P�~���I���O�ζ���1 */
    		strcpy(sOth_item1, trim(sOth_item1));

    		GetData(sOth_item2,     sizeof(sOth_item2),	    delimiter);     /* 21 �P�~���I���O�ζ���2*/
    		strcpy(sOth_item2, trim(sOth_item2));

    		GetData(sOth_Mstl,      sizeof(sOth_Mstl),		delimiter);     	/* 22 �P�~�z�ߪ��B*/
    		strcpy(sOth_Mstl, trim(sOth_Mstl));
    		iMins_stl = atoi(sOth_Mstl);

    		GetData(sOth_fvictim,   sizeof(sOth_fvictim),	delimiter);     	/* 23 �P�~���`�H�O*/
    		strcpy(sOth_fvictim, trim(sOth_fvictim));

    		GetData(sOth_adjuster1, sizeof(sOth_adjuster1), delimiter);     /* 24 �P�~�����F�d�ʤ��� */
    		strcpy(sOth_adjuster1, trim(sOth_adjuster1));
    		iQduty1 = atoi(sOth_adjuster1);

    		GetData(sOth_adjuster2, sizeof(sOth_adjuster2),	delimiter);     /* 25 �P�~��y���F�d�ʤ��� */
    		strcpy(sOth_adjuster2, trim(sOth_adjuster2));
    		iQduty2 = atoi(sOth_adjuster2);

    		GetData(sOth_adjuster3, sizeof(sOth_adjuster3),	delimiter);     /* 26 �P�~��L�F�d�ʤ��� */
    		strcpy(sOth_adjuster3, trim(sOth_adjuster3));
    		iQduty3 = atoi(sOth_adjuster3);

   			GetData(sOth_tag2,      sizeof(sOth_tag2),      delimiter);     /* 27 �P�~��y���P���X */
   			strcpy(sOth_tag2, trim(sOth_tag2));

   			GetData(sOth_cpy2,      sizeof(sOth_cpy2),	    delimiter);     /* 28 �P�~��y���q�N�X */
   			GetData(sOth_card2,     sizeof(sOth_card2),		delimiter);     	/* 29 �P�~��y�O�I�Ҹ� */
   			strcpy(sOth_card2, trim(sOth_card2));

   			GetData(sOth_prem,      sizeof(sOth_prem),      delimiter);     /* 30 ���u���B */
   			strcpy(sOth_prem, trim(sOth_prem));
   			iMprem = atoi(sOth_prem);

        GetData(sIclaim,        sizeof(sIclaim),        delimiter);     /* 21 �s�w�߮� */
        strcpy(sIclaim, trim(sIclaim));

        /* -------------------------------------------------------------- */
        /* �X�I�ɶ� */
        iYY = atoi(sYY);
        iMM = atoi(sMM);
        iDD = atoi(sDD);
        iHH = atoi(sHH);
        iMS = atoi(sMS);
        sprintf_s(sDaccident,17,"%04d-%02d-%02d %02d:%02d", iYY, iMM, iDD, iHH, iMS);
        sprintf_s(sDacc_mdy,11,"%02d/%02d/%d",iMM,iDD,iYY);

        /* �������� */
        sprintf_s(sIins_item,5,"%s%01d",sOth_item1, atoi(sOth_item2));

        printf("259:  sDaccident=[%s],sIins_item[%s] \n\n",sDaccident, sIins_item);

        printf("255:  iline=[%d],[%d] \n\n",iline, strlen(sInumber));
    		if (strlen(sInumber) == 0)
    		{
       	    memset(bp, ' ', recLen);
       			continue;
    		}

        iline++;

        /* �Ȧ�b���ˮ� */
        $select b.ifpce_id, b.ibank, b.iaccount
           into $sTp_id, $sTp_bank, $sTp_accbank
           from cu_code_data a, cu_stl_obj b
          where a.ncode = b.ifpce_id
            and a.itype = 'HC' AND a.icode = $sIcompany;

         if (SQLCODE == SQLNOTFOUND)
         {
         		$insert into ca9263_msg
             values
             ($iNumber, $sIcompany, $sOth_claim, $sOth_card,
              'E01', '��i�ȪA��P�j�d�L�P�~�N�X!!');
             	memset(bp, ' ', recLen);
         	 		break;
         }

         strcpy(sTp_id, trim(sTp_id));
         strcpy(sTp_bank, trim(sTp_bank));
         strcpy(sTp_accbank, trim(sTp_accbank));

         if((strcmp(g_fpce_id, sTp_id) != 0)||(strcmp(g_bank, sTp_bank) != 0)||
            (strcmp(g_accbank, sTp_accbank) != 0))
         {
         		$insert into ca9263_msg
             values
             ($iNumber, $sIcompany, $sOth_claim, $sOth_card,
              'E02', '�d�L�ŦX����w�N���λȦ�b��!!');
             memset(bp, ' ', recLen);
             break;
         }

        /* ���ˮ� */
        if (strlen(sIclaim) == 0)
        {   /* ���߮�..... */
	
            /* 1.�O�I���q�ˮ� */
            if (atoi(sOth_cpy2) != 17)
            {
                $insert into ca9263_msg
                 values
                 ($iNumber, $sIcompany, $sOth_claim, $sOth_card,
                  'E03', '��y���q�N�X�D17,�D�s�w�O��');

                memset(bp, ' ', recLen);
                continue;
            }

            printf("-- 319 -- \n");

            /* 2.�O�渹�ˮ� */
            sIpolicy[0]= '\0';
            $select ipolicy into $sIpolicy
               from compulsory_card
              where ipolicy <> ' ' and icard = $sOth_card2;

            if((SQLCODE == SQLNOTFOUND) || (strlen(sIpolicy) == 0))
            {
            		sprintf_s(errMsg2,150,"���O�I�Ҹ��i%s�j�d�L�O�渹 ", sOth_card2);

                $insert into ca9263_msg
                 values
                 ($iNumber, $sIcompany, $sOth_claim, $sOth_card,
                  'E04', $errMsg2);

                memset(bp, ' ', recLen);
                continue;
            }

            /* 3.�O���ˮ� */
            ichk1 = 0; ichk2 = 0; icnt=0;
            strcpy(sFullName, get_car_full_db(sIpolicy));
            sprintf_s(sTpTmp1,3000,
                    "SELECT count(*) from %s:ply_ins_type_hist "
                    " where ipolicy = '%s' "
                    "   AND dedr_begin <= mdy('%s','%s','%s') "
                    "   AND dedr_end >= mdy('%s','%s','%s') ",
                     sFullName, sIpolicy,
                     sMM, sDD, sYY, sMM, sDD, sYY);
            printf("�O���ˮ�: sTpTmp1=[%s]\n",sTpTmp1);
            $PREPARE pre_E03 FROM $sTpTmp1;
            $execute pre_E03 into $icnt;
            if (icnt == 0)
            {
            		sprintf_s(errMsg2,150,"�X�I������b�O��i%s�j�O���� ", sIpolicy);
                $insert into ca9263_msg
                 values
                 ($iNumber, $sIcompany, $sOth_claim, $sOth_card,
                  'E05', $errMsg2);

                memset(bp, ' ', recLen);
                continue;
            }
            else if (icnt > 1)
            {
                $insert into ca9263_msg
                 values
                 ($iNumber, $sIcompany, $sOth_claim, $sOth_card,
                  'E06', '���h�i���,�Ф�ʿ�J�߮� ');

                memset(bp, ' ', recLen);
                continue;
            }

            /* 4.���P�ˮ� */
            sprintf_s(sTpTmp1,3000,
                    "SELECT CASE WHEN itag = '%s' THEN '1' ELSE '0' end "
                    "  FROM %s:ply_relation a, %s:policy b "
                    " WHERE a.ipolicy = b.ipolicy "
                    "   AND a.ipolicy = '%s' ",
                     sOth_tag2, sFullName, sFullName, sIpolicy);
            printf("4.���P�ˮ�=[%s]\n",sTpTmp1);
            $PREPARE pre_E05 FROM $sTpTmp1;
            $execute pre_E05 into $ichk1;

            if (ichk1 == 0)
            {
            		sprintf_s(errMsg2,150,"���P�P�̷s�O��i%s�j���P���P ", sIpolicy);
                $insert into ca9263_msg
                 values
                 ($iNumber, $sIcompany, $sOth_claim, $sOth_card,
                  'E07', $errMsg2);

                 memset(bp, ' ', recLen);
                 continue;
            }

            /* �½߮׬d�� */
            strcpy(sTmpClaim, "");
            sprintf_s(sTpTmp1,3000,
                    "SELECT first 1 iclaim "
                    "  from ca_clm_process "
                    " where iclaim[6] = 'C' "
                    "   and (itag = '%s' or ipolicy = '%s') "
                    "   and date(daccident) = '%s' "
                    "  order by dclaim desc ",
                     sOth_tag2, sIpolicy,sDacc_mdy);
            $PREPARE pre_E06 FROM $sTpTmp1;
            $execute pre_E06 into $sTmpClaim;

						strcpy(sTmpClaim,trim(sTmpClaim));

            if (strlen(sTmpClaim) > 0)
            {
            		sprintf_s(errMsg2,150,"�s�w�w�߽߮� (%s)", sTmpClaim);

                $insert into ca9263_msg
                 values
                 ($iNumber, $sIcompany, $sOth_claim, $sOth_card,
                  'E08', $errMsg2);
                 memset(bp, ' ', recLen);
                 continue;
            }

            /* ���I�����ˮ� */
            strcpy(sIins_ply,"000");
            printf("sDacc_mdy=[%s]sIins_item=[%s]\n",sDacc_mdy,sIins_item);
            $select iins_ply into $sIins_ply
               from sysdb:insurance_type
              where iins_type = $sIins_item;
						strcpy(sIins_ply, trim(sIins_ply));
						printf("sIins_item=[%s]\n",sIins_item);
            if ((SQLCODE == SQLNOTFOUND)|| (strcmp(sIins_ply,"21") != 0))
            {
								sprintf_s(errMsg2,150,"���I���ءi%s�j���b�Ͳνd��!!", sIins_item);
	            	$insert into ca9263_msg
	               values
	               ($iNumber, $sIcompany, $sOth_claim, $sOth_card,
	                 'E09', $errMsg2);
	                 memset(bp, ' ', recLen);
	                 continue;
            }

			
			/* �j���I�����O�ε��I�з��ˮ� */
			mfactor = 0;
			printf("sDacc_mdy=[%s]sIins_item=[%s]\n",sDacc_mdy,sIins_item);
			$select mfactor into $mfactor
			   from sysdb:ca_reco_factor
			  where itype = '6'
				and dbegin <= $sDacc_mdy AND dend >= $sDacc_mdy
				and icode = $sIins_item;
			
			if (SQLCODE != SQLNOTFOUND)
			{
				if ((mfactor < iMins_stl) || (mfactor < iMprem))
				{
					sprintf_s(errMsg2,150,"���I���ءi%s�j���B�W�L�e�j���I�����O�ε��I�зǡf!!", sIins_item);
					$insert into ca9263_msg
					 values
					 ($iNumber, $sIcompany, $sOth_claim, $sOth_card,
					  'E10', $errMsg2);
					 memset(bp, ' ', recLen);
					 continue;
				}
			}
		
			/* �������ح����ˮ� */
			fchk1 = 0;
			printf("sDacc_mdy=[%s]sIins_item=[%s]\n",sDacc_mdy,sIins_item);
			$select count(*) into $fchk1
			   from car9263_tpm1
			  where iclaim = $sOth_claim
				and ivictim = $sOth_victim
				and iins_item = $sIins_item;

			if (fchk1 > 0)
			{
						sprintf_s(errMsg2,150,"�P�@���`�H���I���ءi%s�j����!!", sIins_item);
						$insert into ca9263_msg
					 values
					 ($iNumber, $sIcompany, $sOth_claim, $sOth_card,
					  'E11', $errMsg2);
					 memset(bp, ' ', recLen);
					 continue;
			}
			
			
			/*�j���I�������إ[�`���i�W�L�t�γ]�w*/
			if(sIins_item[0] == 'A')
			{
				iMprem_A = 0;
				iMins_stl_A = 0;
				
				$select mfactor into $mfactor
				   from sysdb:ca_reco_factor
				  where itype = '6'
					and dbegin <= $sDacc_mdy AND dend >= $sDacc_mdy
					and icode = 'A000';
				
				$select nvl(sum(mprem),0),nvl(sum(mins_stl),0) 
				into $iMprem_A, $iMins_stl_A
				   from car9263_tpm1
				 where iclaim = $sOth_claim
					and ivictim = $sOth_victim
					and iins_item[1] = 'A';
				
				iMins_stl_A = iMins_stl + iMins_stl_A;
				iMprem_A = iMprem + iMprem_A;
				
		
				if ((mfactor < iMins_stl_A) || (mfactor < iMprem_A))
				{
					sprintf_s(errMsg2,150,"�Ҧ��������ضO��(A�}�Y)�[�`�A�w�W�L�j���I�����O�ε��I�з�!");
					$insert into ca9263_msg
					 values
					 ($iNumber, $sIcompany, $sOth_claim, $sOth_card,
					  'E10', $errMsg2);
					 memset(bp, ' ', recLen);
					 continue;
				}
			}

            /*----------------------------------------------------------------*/
            /* IFRS�����ˮ� add by sylvia 111.10.18 (1110303007��SC3) */
            /*----------------------------------------------------------------*/

            /*   1120914001_A01_IFRS17 �t�X��Ʀ^�ɬ����ק�   */
            strcpy(sYN,"N");
            if (strcmp(sYN,"Y") == 0)
            {
                strcpy(iportfolio, " ");
                strcpy(igroup_profit, " ");

                rc = chk_IFRS_claim("1", sIpolicy, " ", "21", &iportfolio, &igroup_profit, &icnt1, &sMsg);
                if (icnt1 > 0)
                {
                    strcpy(errMsg2, sMsg);

                    $insert into ca9263_msg
	                 values
	                 ($iNumber, $sIcompany, $sOth_claim, $sOth_card,
	                  'E12', $errMsg2);
	                 memset(bp, ' ', recLen);
	                 continue;
                }

             }

            /*----------------------------------------------------------------*/


        }
        else
        {
            /* �w�߮�.... */
            continue;
            ichk1 = 0;
            $select case when itag = $sOth_tag2 then 1 else 0 end
               into $ichk1
               from ca_clm_process
              where iclaim = $sIclaim;

						if (SQLCODE == SQLNOTFOUND){
					    $insert into ca9263_msg
               values
               ($iNumber, $sIcompany, $sOth_claim, $sOth_card,
                'E10', '�s�w�߮׸����~');

               memset(bp, ' ', recLen);
               continue;
						}

            if (ichk1 == 0)
            {
                $insert into ca9263_msg
                 values
                 ($iNumber, $sIcompany, $sOth_claim, $sOth_card,
                  'E11', '���P���P�s�w�߮׫O�����P');

                 memset(bp, ' ', recLen);
                 continue;
            }
        }

        /* �g�JTemp Table */
        /* $sOth_qpt 110.10.06 */
        $insert into car9263_tpm1
        (
            inumber, icompany, iclaim, icard, fvictim_nation,
		    		icar_type, qpt, fpt, itag, dacc_yy,
    	    	dacc_mm, dacc_dd, dacc_hh, dacc_ms, iacc_reason,
    	    	iacc_area, nassured, ivictim, dvictim, iins_item1,
    	    	iins_item2, mins_stl, fvictim_car, qduty_adjuster, qduty_adjuster2,
    	    	qduty_adjuster3, itag2, oth_company, oth_card, mprem,
    	    	iclaim_2, adjustment, daccident, iins_item, ipolicy
    	  )
        values
        (
            $sInumber, $sIcompany, $sOth_claim, $sOth_card, $sOth_nation,
            $sOth_CarType, $dblQpt, $sOth_fpt, $sOth_tag, $sYY,
            $sMM, $sDD, $sHH, $sMS, $sOth_reason,
            $sOth_area, $sOth_nassured, $sOth_victim, $sOth_Dvictim, $sOth_item1,
            $sOth_item2, $iMins_stl, $sOth_fvictim, $iQduty1, $iQduty2,
            $iQduty3, $sOth_tag2, $sOth_cpy2, $sOth_card2, $iMprem,
            $sIclaim, $sAdjustment, $sDaccident, $sIins_item, $sIpolicy
        );

        memset(bp, ' ', recLen);
    }
    fclose(fp);

    if (iline == 0)
    {
        EWRITE(userid, M_CM_NOT_FOUND, "�ɮפ��L���!! \n");
        return FAIL;
    }

    ierrcnt = 0;
    $select count(*) into $ierrcnt
       from ca9263_msg where 1=1;

    if (ierrcnt > 0)
    {
        $DECLARE get_errlog CURSOR FOR
          SELECT inumber||'\t'||icompany||'\t'||iclaim||'\t'||icard||'\t'||errno||'\t'||errmsgs
            FROM ca9263_msg where 1=1;
        $OPEN get_errlog;
        for(;;)
        {
            $FETCH get_errlog INTO $errMsg2 ;
            printf("errMsg2 = [%s]\n", errMsg2);
            if (SQLCODE == SQLNOTFOUND) break;
            strcat(errMsg,rtrim(errMsg2));
            strcat(errMsg,"\n");
        }
        return FAIL;
    }

    return M_CM_OK;

errexit:
    rc = cm_show_sql_err("ca926_trans", "");
    return rc;
}
/*----------------------------------------------------------------------------*/
long car9263_get_db()
{
    int	rc;
    char msgbuf[60];

    if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
    }

    if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
    {
        EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
        return M_CM_NOT_DBLIST;
    }

    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }

    $create temp table ca9263_msg
    (
      inumber			int,				-- 1 �Ǹ�
      icompany		char(2),		-- 2 �O�I���q
			iclaim			char(20),		-- 3 �߮׸�
			icard				char(20),		-- 4 �O�I�Ҹ�
			errno       char(3),    -- 5 ���~�N�X
			errmsgs     char(100)   -- 6 ���~��]
    )with no log;

		$create temp table ca9263_clm
    (
      icompany		char(2),		-- 1 �O�I���q
			iclaim1			char(20),		-- 2 �P�~�߮׸�
			icard1			char(20),		-- 3 �P�~�O�I�Ҹ�
			iclaim2			char(20),		-- 4 �s�w�߮׸�
			iclose_type	int,				-- 5 �ߥI����
			mstl2				int					-- 6 �ߥI���B
    )with no log;


    return M_CM_OK;


errexit:
    rc = cm_show_sql_err("ca926_trans", "");
    return rc;
}

/* ------------------------------------------------------------------------- */
char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  char sTmp_db_name[31];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
  }
  return sTmp_db_name;
}

/* ------------------------------------------------------------------------- */
long car9263_exec()
{

    $char   sTrsqlm[1000], sTrsqld[1000], strsqld3[1000];
    $int    tmpnum, icnt_base,icnt238;

    EXEC SQL WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT 2;

    /* �s�W ca_clm_victim_data */
    sprintf_s(sTmpSQL573,5000,
        "insert into sysdb:ca_clm_victim_data \
            (iclaim, ivictim, dvictim, fvictim_nation, fvictim_sex, \
             fvictim_car, fdrive, facc_rel, itag, nassured, \
             itel, avictim, fdrink, iinjured_loc, fcause_adjuster, \
             qduty_adjuster, fcause_skip, qduty_skip, fcause_policy, fhealth, \
             fsubrogation, ientry, dentry, iupdate, dupdate, ncause_oth, irent_tag) \
         values \
            (?, ?, ?, ?, ?, \
             ?, ?, ?, ?, ?, \
             ' ', ' ', '1', '99', ?, \
             ?, ' ',  0, '00', 'N', \
             'N', ?, current, ?, current,' ', ' ') ");
    $prepare ca573_ca_clm_victim_data from $sTmpSQL573;

		$SELECT ('A'||to_char(today ,'%y%m%d'))
		   into $isign_tmp
		   from systables where tabid = 1;


    printf("isign_tmp=[%s]\n",isign_tmp);

    $Begin Work;

    sprintf_s(sTrsqlm,1000,
        "select unique icompany, iclaim, icard, fvictim_nation, "
		"       icar_type, qpt, fpt, itag, dacc_yy, "
		"       dacc_mm, dacc_dd, iacc_reason, iacc_area, qduty_adjuster, "
		"       qduty_adjuster2, qduty_adjuster3, itag2, "
        "       oth_company, oth_card, iclaim_2, adjustment, "
        "       daccident, ipolicy, "
        "       decode(iacc_reason,'21','11',iacc_reason) "
        "from car9263_tpm1 where 1=1 ");
    $PREPARE pre_E1 FROM $sTrsqlm;
    $DECLARE cur_E1 CURSOR for pre_E1;
    $OPEN cur_E1;
    while (1)
    {

        $FETCH cur_E1 into
             $sIcompany, $sOth_claim, $sOth_card, $sOth_nation,
			 $sOth_CarType, $dblQpt, $sOth_fpt, $sOth_tag, $sYY,
			 $sMM, $sDD, $sOth_reason, $sOth_area, $iQduty1,
			 $iQduty2, $iQduty3, $sOth_tag2,
			 $sOth_cpy2, $sOth_card2, $sIclaim, $sAdjustment,
			 $sDaccident, $sIpolicy, $sNewa_reason;

        if (SQLCODE == SQLNOTFOUND) break;

        printf("***** 820: dblQpt=[%f]\n",dblQpt);

        strcpy(sIclaim, trim(sIclaim));

        if (strlen(sIclaim) == 0)
            strcpy(fNewClaim, "Y");
        else
            strcpy(fNewClaim, "N");

        /* ���`�H��Ƽg�JTemp Table */
        $select nassured, ivictim, dvictim, fvictim_car, sum(mprem) as sum_mprem
           from car9263_tpm1
          where ipolicy = $sIpolicy and iclaim = $sOth_claim
           group by 1,2,3,4
           into temp car9263_d1 with no log;

        if (strcmp(fNewClaim, "Y") == 0)
        {
            /* �߷s��, ���߮׸� ------------------------------------------  */
            printf("-- 953 sAdjustment=[%s]\n",sAdjustment);
            printf("-- 953 sDacc_birth=[%s] sIacc_birth=[%s]\n",sDacc_birth,sIacc_birth);
            printf("-- 953 sDaccident=[%s] sDacc_mdy=[%s]\n",sDaccident,sDacc_mdy);

            $select c.ibranch_abbr, a.iapp_unit, (year(today)-2011),
                    a.iapp_unit||c.ibranch_abbr||(year(today)-2011)||'C',
                    d.iquota
               into $kcomp_no, $kdept_no, $dyear, $kserial_index, $sIquota
               from cm_clm_adjuster a, branch b, branch c, officer d
              where a.iapp_unit = b.ibranch
                and b.iupcomp = c.ibranch
                and a.empl_no = d.iofficer
                and a.empl_no = $sAdjustment;

            strcpy(kcomp_no, trim(kcomp_no));
            strcpy(kdept_no, trim(kdept_no));
            strcpy(dyear, trim(dyear));
            strcpy(kserial_index, trim(kserial_index));
            strcpy(sIquota, trim(sIquota));

            printf("kcomp_no=[%s] kdept_no=[%s] dyear=[%s] kserial_index=[%s]\n",
                    kcomp_no, kdept_no, dyear, kserial_index);

            $select nvl(kserial_num,0)+1 into $tmpnum
               from autonumbering
              where kbill_grp = 'C3'
                and kbill_code = 'C'
                and kcomp_no = $kdept_no
                and kdept_no = $kcomp_no
                and dyear = $dyear
                and kserial_index = $kserial_index;

			if (SQLCODE == SQLNOTFOUND)
			{
				tmpnum = 0;
				$insert into autonumbering
				 (kbill_grp, kbill_code, kcomp_no, kdept_no, dyear,
				  dmth, dday, kserial_num, kserial_index)
				values
				 ('C3','C', $kdept_no, $kcomp_no, $dyear,
				  0, ' ', $tmpnum, $kserial_index);
			}

            if (tmpnum == 0)  tmpnum = 1;

            printf("tmpnum=[%d]\n ", tmpnum);

            sprintf_s(sIclaim,21, "%s%05d\n",kserial_index,tmpnum);

            sIclaim[11]='\0';   /* �߮׸� */


            printf("sIclaim=[%s]\n",sIclaim);

            /* ��s������ */

            $update sysdb:autonumbering
                set kserial_num = $tmpnum
              where kcomp_no = $kdept_no
                and kdept_no = $kcomp_no
                and dyear = $dyear
                and kserial_index = $kserial_index;

            printf("---- update sysdb:autonumbering OK ---- \n");
            /* ���߮׸� (End)------------------------------------------------------  */


            /* 1.���z�@�~(car571) */
            rc=car571_insert();  /* �s�Wcar571 *//*�`�N:�����I�Φ��O���p���ˮ�, �ݽT�{!! */
            if (rc != SUCCESS)
                return rc;

            /* 2.�d�ҧ@�~(car573) */
            rc=car573_insert();  /* �s�Wcar573 */
            if (rc != SUCCESS)
                return rc;

            /* 3.�w���@�~(car572) */
            rc=car572_insert();  /* �s�Wcar572 */
            if (rc != SUCCESS)
                return rc;

            /* 4.�l���@�~(car575) */
            rc=car575_insert();  /* �s�Wcar575 */
            if (rc != SUCCESS)
                return rc;

            /* 5.ñ���@�~(car581) */
            rc=car581_insert();  /* �s�Wcar581 */
            if (rc != SUCCESS)
                return rc;


            /* 6.�z��@�~(car582) */
            rc=car582_insert();  /* �s�Wcar582 */
            if (rc != SUCCESS)
                return rc;
        }
        else
        {
            /* �w���®� */
        }

        $drop table car9263_d1;

       printf(" --------------- 851 ------------- \n");
       $update car9263_tpm1
           set iclaim_2 = $sIclaim
         where iclaim = $sOth_claim;
       printf(" --------------- 855 ------------- \n");

    }
    $CLOSE cur_E1;
    $FREE cur_E1;
    printf(" --------------- 859 ------------- \n");

    $commit work;
    return M_CM_OK;


errexit:
    rc = cm_show_sql_err("ca9263_exec", "");
    rgetmsg(SQLCODE, sErrorMsg, sizeof(sErrorMsg));
    sprintf_s(errMsg2,150, sErrorMsg, sqlca.sqlerrm);
    sprintf_s(errMsg,5000000, "[%s]\n �i�P�~�׸�:%s�j SQLERROR(%d):%s\n",
            "ca9263_exec:", trim(sOth_claim), SQLCODE, errMsg2);
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    $SET LOCK MODE TO NOT WAIT;
    return rc;
}

/* -------------------------------------------------------------------------- */
long car571_insert()
{
    EXEC SQL WHENEVER SQLERROR GOTO errexit;

    $char   sTmpSQL[1000],sTmpSQL1[50000];
    $int    ioth_fvictim, iyy, imm, idd;
    $char   stmpstr1[11], stmpstr2[11], stmpstr3[11];

    printf("------- car571_insert ------ \n");

    strcpy(sFullName, get_car_full_db(sIpolicy));

    sprintf_s(sTmpSQL,1000,
        "select a.iassured, a.nassured, a.fassured, a.ibirth, a.dbirth, "
        "       a.fmarriage, a.fsex, a.itag, "
        "       case when a.fassured in ('2','4','6') then '5' ELSE "
       	"	         case WHEN iassured = '%s' THEN '1' ELSE 'D' END END as facc_rel "
        "  from %s:policy a "
        " where a.ipolicy = '%s' ",
        sOth_victim, sFullName, sIpolicy );

    printf("sTmpSQL=[%s]\n",sTmpSQL);

    $prepare ca571_q1 from $sTmpSQL;
    $execute ca571_q1
        into $sIassured, $sNassured, $sFassured, $sIacc_birth, $sDacc_birth,
             $sFacc_marri, $sFacc_sex, $sItag, $sFacc_rel;


    strcpy(sIassured, trim(sIassured));
    strcpy(sNassured, rtrim(sNassured));


    /* �X�I�a�� */
    $select dvp_abbr into $sNacc_area
       from ca_dvp_ply_area
      where dvp_code = $sOth_area;

    /* �P�~���`�H��� */
    $select first 1 nassured, ivictim, dvictim, fvictim_car,
            to_char(dvictim[5,6]||'/'||dvictim[7,8]||'/'||dvictim[1,4]),
            trunc(dvictim-19110000)
       into $sOth_nassured, $sOth_victim, $sOth_Dvictim, $sOth_fvictim,
            $sDoth_birth, $sIoth_birth
       from car9263_d1
      where 1=1  order by fvictim_car desc;

    /* �P�~���`�H�O */
    strcpy(sOth_fvictim, trim(sOth_fvictim));
    ioth_fvictim = atoi(sOth_fvictim);

    /* �P�~���`�HID */
    strcpy(sOth_victim, trim(sOth_victim));

    /* �P�~���`�H�W�� */
    strcpy(sOth_nassured, rtrim(sOth_nassured));
    /* strcpy(sIacc_birth, " "); */
    /* strcpy(sDacc_birth, " "); */

    if (ioth_fvictim == 5)
    {
        /* ioth_fvictim=5 �P�~����訮�r�p=�����q�������r�p */
        if(strcmp(sOth_victim, sIassured) != 0)
        {
             /* �����r�p <> �Q�O�I�H (F0) */
            strcpy(sNacc_driver, sOth_nassured);    /* �F�ƾr�p */
            strcpy(sIacc_license, sOth_victim);     /* �F�ƾr�pID */

            strcpy(sFacc_marri,"1");    /* �B�� */

            if ((sIacc_license[1] == '1') || (sIacc_license[1] == '2'))
            {
                strcpy(sFacc_nation,"1");   /* ����H*/
                strncpy(sFacc_sex, &sIacc_license[1], 1);
                sFacc_sex[1]='\0';  /* �ʧO */
            }
            else
            {
                printf("---- 830 --- \n");
                strcpy(sFacc_nation,"2");   /* �~��H*/
                strcpy(sFacc_sex, "1");     /* �ʧO */
            }
            strcpy(sFvictim_car,"F");
            strcpy(sFdrive,"0");
            strcpy(sFadjuster,"02");	/* �z�ߧP�_�]��:02��p���� */

            if((strcmp(sFassured,"2") == 0) || (strcmp(sFassured,"4") == 0) || (strcmp(sFassured,"6") == 0))
                strcpy(sFacc_rel,"5");
            else
                strcpy(sFacc_rel,"D");

            strcpy(sIacc_birth, trim(sIoth_birth)); /* �ͤ�(CYYMMDD) */
            strcpy(sDacc_birth, trim(sDoth_birth)); /* �ͤ�(MM/DD/YYYY) */
        }
        else
        {
            /* �����r�p = �Q�O�I�H (F1) */
            strcpy(sNacc_driver, sNassured);    /* �F�ƾr�p */
            strcpy(sIacc_license, sIassured);     /* �F�ƾr�pID */
            strcpy(sIacc_birth, trim(sIacc_birth)); /* �ͤ�(CYYMMDD) */
            strcpy(sDacc_birth, trim(sDacc_birth)); /* �ͤ�(MM/DD/YYYY) */
            strcpy(sFacc_marri,trim(sFacc_marri));  /* �B�� */
            strcpy(sFacc_sex, trim(sFacc_sex));     /* �ʧO */
            strcpy(sFacc_nation, trim(sFassured));   /* ��/�~��H */
            strcpy(sFvictim_car,"F");
            strcpy(sFdrive,"1");
            strcpy(sFacc_rel,"1");
            strcpy(sFadjuster,"02");	/* �z�ߧP�_�]��:02��p���� */
        }

        /* ���K�N�����r�p��Ƽg�Jca_clm_victim_data  */
        $execute ca573_ca_clm_victim_data
           using $sIclaim, $sIacc_license, $sDacc_birth, $sFacc_nation, $sFacc_sex,
                 $sFvictim_car, $sFdrive, $sFacc_rel, $sItag, $sNacc_driver,
                 $sFadjuster, $iQduty2, $userid, $userid;
    }
    else
    {
        /* ���`�H<> �r�p (1,3,4) */
        if((strcmp(sFassured,"1") == 0) || (strcmp(sFassured,"3") == 0) || (strcmp(sFassured,"5") == 0))
        {
            /* �Y�Q�O�H=�۵M�H,�w�]�����r�p = �Q�O�I�H */
            strcpy(sNacc_driver, sNassured);    /* �F�ƾr�p */
            strcpy(sIacc_license, sIassured);     /* �F�ƾr�pID */
            strcpy(sIacc_birth, trim(sIacc_birth)); /* �ͤ�(CYYMMDD) */
            strcpy(sDacc_birth, trim(sDacc_birth)); /* �ͤ�(MM/DD/YYYY) */
            strcpy(sFacc_marri,trim(sFacc_marri));  /* �B�� */
            strcpy(sFacc_sex, trim(sFacc_sex));     /* �ʧO */
            strcpy(sFacc_nation, trim(sFassured));   /* ��/�~��H */
        }
        else
        {
            /* �w�]�����r�p = �Ӳz�����w�]�� */
            strcpy(sNacc_driver, "�F��A");          /* �F�ƾr�p */
            strcpy(sIacc_license, "B");             /* �F�ƾr�pID */
            strcpy(sIacc_birth, "0700101");         /* �ͤ�(CYYMMDD) */
            strcpy(sDacc_birth, "01/01/1981");      /* �ͤ�(MM/DD/YYYY) */
            strcpy(sFacc_marri,"1");                /* �B��:�w�B */
            strcpy(sFacc_sex, "1");                 /* �ʧO:�k1 */
            strcpy(sFacc_nation, "1");              /* ��/�~��H */
        }
    }



    strncpy(sDaccident2, sDaccident,13);
    sDaccident2[13] = '\0';

    /* �g�J appraisal */
    sprintf_s(sTmpSQL1,50000,
        "insert into %s:appraisal "
        "    (iclaim, fcard_class, ipolicy, icard, irelative_ply, "
        "     irelative_card, irelative_clm, icoclaim, dclaim, iacc_area, "
        "     daccident, iacc_reason, facc_duty, fdmg_duty, iadjuster, fpart, "
        "     frecover, fsale, nacc_driver, iacc_license, iacc_birth, dacc_birth, "
        "     facc_sex, facc_marri, facc_rel, facc_nation, "
        "     facc_car, iclm_entry, affiliated, inumber, iupdate, "
        "     dupdate, ifacnum, fcompensation, facoption) "
        " select '%s', a.fcard_class, a.ipolicy, a.icard, a.irelative_ply, "
        "        nvl((select itarget2 from policy_new WHERE insure_type = 'C' "
        "           AND insure_class = 'C' AND isys_source = 'CAR' "
        "           AND ipolicy1 = a.irelative_ply AND ipolicy2 = ' '),' '), "
        "        ' ', 'N', current, '%s' , "
        "        '%s' , '%s' , '3', '2', '%s', '4', "
        "        '0', '0', '%s', '%s', '%s', '%s', "
        "        '%s', '%s', '%s', '%s', "
       	"	     case when fassured in ('2','4','6') then '4' ELSE "
       	"	         CASE WHEN iassured = '%s' THEN	'1' ELSE '2' END END as facc_car, "
       	"	     '%s', '%s', ' ', '%s', current, ' ', '0', '0' "
        "   from %s:ply_relation a, %s:policy b "
        "  where a.ipolicy = b.ipolicy "
        "    and a.ipolicy = '%s' ",
        sFullName, sIclaim, sOth_area, sDaccident2, sNewa_reason, sAdjustment,
        sNacc_driver, sIacc_license, sIacc_birth, sDacc_birth,
        sFacc_sex, sFacc_marri, sFacc_rel, sFacc_nation, sIacc_license, userid,
        sIquota, userid, sFullName, sFullName, sIpolicy);

    printf("ca571_appraisal=[%s]\n",sTmpSQL1);

    $prepare ca571_appraisal from $sTmpSQL1;
    $execute ca571_appraisal;

    /* �g�J ca_clm_process */
    sprintf_s(sTmpSQL1,50000,
        "insert into sysdb:ca_clm_process \
            (iclaim, ipolicy, dclaim, fmaterial, adjustment, \
             ibranch_in, \
             assign, fexam, fassist_exam, fclaim_status, iassured, \
             nassured, itag, daccident, iclm_entry, affiliated, \
             fsystem, fins, ifirst, isecond, iassist_first, iassist_second, \
             isign_est, noutstand_note, vouch_state, fexam_outs, fexam_recovery, \
             iauto_distrib,fprocess,dprocess1) \
        values \
            ('%s', '%s', today, 'N', '%s', \
              (select icomp_in from %s:ply_relation where ipolicy = '%s'), \
             '0', 0, 0, 101, '%s', \
             '%s', '%s', '%s', '%s', '%s', \
             'N', 1, ' ', ' ',  ' ', ' ', \
             ' ', ' ', 0, 0, 0, 0, 101, today) ",
       sIclaim, sIpolicy, sAdjustment, sFullName, sIpolicy, sIassured,
       sNassured, sItag, sDaccident, userid, sIquota);

     printf("ca571_ca_clm_process=[%s]\n",sTmpSQL1);
     $prepare ca571_ca_clm_process from $sTmpSQL1;
     $execute ca571_ca_clm_process;


     /* �g�J adjustment_ply */
     sprintf_s(sTmpSQL1,50000,
        "insert into %s:adjustment_ply \
            (iclaim, dply_begin, dply_end, mlia_prem, \
             iofficer, iacc_area, daccident, ilicense, iassured, \
             iassured_ext, nassured, dbirth, fsex, fmarriage, \
             nuser, nbenef,  dissue, ipro_year, ibrand, \
             icar_type, qcylinder, iengine, ibody, itag, \
             moto_itag, nequipment, flimit, pdmg_align, pbrg_align, \
             plia_align, fcut, dtransfer, fpay_status, ibranch, \
             fcomp_24, iply_area, fcomp_class, mbusiness, madjcom_prem, \
             ibig_comp, ibig_branch, ibig_office, ileader, icorps, \
             iquota, icomp_in, ibranch_in, icomp_at, ibranch_at, \
             recipient, iemail, facc_rel, qpro_month,aassured, aassured_zip) \
        select '%s', a.dply_begin, a.dply_end, a.mlia_prem, \
               a.iofficer, '%s', '%s', '%s', b.iassured, \
               b.iassured_ext, b.nassured, b.dbirth, b.fsex, b.fmarriage, \
               b.nuser, b.nbenef, b.dissue, a.ipro_year, a.ibrand, \
               a.icar_type, b.qcylinder, b.iengine, b.ibody, b.itag, \
               ' ', b.nequipment, b.flimit, b.pdmg_align, b.pbrg_align, \
               b.plia_align, b.fcut, a.dtransfer, '1', a.ibranch, \
               b.fcomp_24, b.iply_area,  a.fcomp_class, a.mbusiness, a.madjcom_prem, \
               a.ibig_comp, a.ibig_branch, a.ibig_office, a.ileader, a.icorps, \
               a.iquota, a.icomp_in, a.ibranch, a.icomp_at, a.ibranch_at, \
               ' ', b.iemail, \
               case when b.fassured in ('2','4','6') then '5' ELSE \
       		         case WHEN iassured = '%s' THEN '1' ELSE 'D' END END ,\
       		   b.qpro_month, b.aassured, b.aassured_zip \
          from  %s:ply_relation a,  %s:policy b \
         where a.ipolicy = b.ipolicy \
           and a.ipolicy = '%s' ",
           sFullName, sIclaim, sOth_area, sDaccident2, sIacc_license,
           sOth_victim, sFullName, sFullName, sIpolicy);

     printf("ca571_adjustment_ply=[%s]\n",sTmpSQL1);
     $prepare ca571_adjustment_ply from $sTmpSQL1;
     $execute ca571_adjustment_ply;


    /* �g�J ca_local_clm (��� ca_local_stl �u�g��x�_��Ʈw)*/
     sprintf_s(sTmpSQL1,50000,
        "insert into newa00:ca_local_clm \
            (ibranch, iclaim, iadjuster, ipolicy, dclaim) \
         values \
            ('%s', '%s', '%s', '%s', today)",
           kdept_no, sIclaim, sAdjustment, sIpolicy);

     printf("ca571_ca_local_clm=[%s]\n",sTmpSQL1);
     $prepare ca571_ca_local_clm from $sTmpSQL1;
     $execute ca571_ca_local_clm;

    printf("-- car571 insert ok!! ");
    return SUCCESS;


errexit:
    rc = cm_show_sql_err("car571_insert", "");
    rgetmsg(SQLCODE, sErrorMsg, sizeof(sErrorMsg));
    sprintf_s(errMsg2,150, sErrorMsg, sqlca.sqlerrm);
    sprintf_s(errMsg,5000000, "[%s]\n �i�P�~�׸�:%s�j SQLERROR(%d):%s\n",
            "car571_insert:", trim(sOth_claim), SQLCODE, errMsg2);

    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    $SET LOCK MODE TO NOT WAIT;
    return rc;
}

/* --------------------------------------------------------------------------*/
/* �d�ҧ@�~ */
long car573_insert()
{
    $char sTmpSQL2[5000],  sTmpSQL3[5000], sDbirth[11], sSex[2],
          stmpstr1[11], stmpstr2[11], stmpstr3[11];

    $int  icntF, icntG, icntH, ipro_no, ioth_fvictim, iyy, imm, idd, iQduty_victim;

    EXEC SQL WHENEVER SQLERROR GOTO errexit;

    strcpy(sFullName, get_car_full_db(sIpolicy));
    ipro_no = 0;


    /* �s�W ca_ver_relation */
    $insert into sysdb:ca_ver_relation
            (iclaim, iverify)
     values ($sIclaim, $sIclaim);

    /* �s�W ca_verify */
    $insert into sysdb:ca_verify
        (iverify, nacc_place, iweather, iroad_state, fforce,
         nforce_name, isign, ihandle, npolice, itel_police,
         fverify_status, ndoc_other, fduty_nosign, ientry, dentry,
         iupdate, dupdate, fsingle_acc, ichk_recovery)
     values
        ($sIclaim, ' ', '01', '01', '1',
         ' ', '00', ' ', ' ', ' ',
          200, ' ', '00', $userid, current,
         $userid, current, '1', '0');

    /* �g�J ca_clm_victim_data ---------------------------------------- */
    /* �P�~���`�H��� */
    sprintf_s(sTmpSQL2,5000,
        "select unique nassured, ivictim, dvictim, fvictim_car "
        "  from car9263_d1 where 1=1  order by fvictim_car desc");

    $PREPARE pre_car5731 FROM $sTmpSQL2;
	$DECLARE cur_car5731 CURSOR FOR pre_car5731;
	$OPEN cur_car5731;
	while(1)
	{
	    $FETCH cur_car5731 into $sOth_nassured, $sOth_victim, $sOth_Dvictim, $sOth_fvictim;
	    if (SQLCODE == SQLNOTFOUND) break;

	    strcpy(sOth_nassured, trim(sOth_nassured)); /*�P�~���`�H�m�W*/
	    strcpy(sOth_victim, trim(sOth_victim));     /*�P�~���`�HID*/
	    strcpy(sOth_Dvictim, trim(sOth_Dvictim));   /*�P�~���`�H�ͤ�*/

        strncpy(stmpstr1, sOth_Dvictim, 4);
        stmpstr1[4]='\0';
        iyy = atoi(stmpstr1);
        strncpy(stmpstr2, &sOth_Dvictim[4], 2);
        stmpstr2[2]='\0';
        imm = atoi(stmpstr2);
        strncpy(stmpstr3, &sOth_Dvictim[6], 2);
        stmpstr3[2]='\0';
        idd = atoi(stmpstr3);
        sprintf_s(sDbirth,11,"%02d/%02d/%d",imm, idd, iyy); /* �ͤ�(MM/DD/YYYY) */

        /* �ʧO */
	    if ((sOth_victim[1] == '1') || (sOth_victim[1] == '2'))
        {
            strncpy(sSex,&sOth_victim[1],1);
            sSex[2]='\0';
        }
        else
            strcpy(sSex,"1");

        strcpy(sOth_fvictim, trim(sOth_fvictim));   /*�P�~���`�H�O*/
	    ioth_fvictim = atoi(sOth_fvictim);

	    if (ioth_fvictim == 5)  continue;   /* ���`�H�������r�p,�bcar571�ɤw���g�J */
		else if (ioth_fvictim == 4)
        {
            strcpy(sFvictim_car, "A");  /*�P�~��譼��(�Y��������)*/
            strcpy(sFadjuster,"00");	/* �z�ߧP�_�]��:00�п�� */
            if(strcmp(sOth_victim, trim(sIassured)) == 0)
            {
                strcpy(sFdrive,"1");
                strcpy(sFacc_rel, "1");
            }
            else
            {
                strcpy(sFdrive,"0");
                if((strcmp(sFassured,"1") == 0) || (strcmp(sFassured,"3") == 0) || (strcmp(sFassured,"5") == 0))
                    strcpy(sFacc_rel, "D");
                else
                    strcpy(sFacc_rel, "5");
            }

            $execute ca573_ca_clm_victim_data
                   using $sIclaim, $sOth_victim, $sDbirth, '1', $sSex,
                         $sFvictim_car, $sFdrive, $sFacc_rel, $sOth_tag2, $sOth_nassured,
                         $sFadjuster, $iQduty2, $userid, $userid;
        }
        else if (ioth_fvictim == 3)
        {
			strcpy(sFadjuster,"99");	/* �z�ߧP�_�]��:99��L */
            if(strcmp(sOth_victim, trim(sIassured)) == 0)
            {
                strcpy(sFvictim_car, "G");  /*�P�~���~(�������D-�D���ȫD�r�p)*/
                strcpy(sFdrive,"1");
                strcpy(sFacc_rel, "1");

                $execute ca573_ca_clm_victim_data
                   using $sIclaim, $sOth_victim, $sDbirth, '1', $sSex,
                         $sFvictim_car, $sFdrive, $sFacc_rel, $sOth_tag, $sOth_nassured,
                         $sFadjuster, $iQduty2, $userid, $userid;
            }
            else
            {
				/* ���~���`�̻F�d = 100 - (�����F�d + ��y�F�d + ��L�F�d)*/
				iQduty_victim = 100 - (iQduty1 + iQduty2 + iQduty3);
                strcpy(sFvictim_car, "C");  /*�P�~���~(���~--�D�����B�D��y)*/
                strcpy(sFdrive,"0");
                if((strcmp(sFassured,"1") == 0) || (strcmp(sFassured,"3") == 0) || (strcmp(sFassured,"5") == 0))
                    strcpy(sFacc_rel, "D");
                else
                    strcpy(sFacc_rel, "5");

                $execute ca573_ca_clm_victim_data
                   using $sIclaim, $sOth_victim, $sDbirth, '1', $sSex,
                         $sFvictim_car, $sFdrive, $sFacc_rel, ' ', $sOth_nassured,
                         $sFadjuster, $iQduty_victim, $userid, $userid;

                /* ���K�g�@���i ca_property */
                $insert into sysdb:ca_property
                (iverify, ipro_no, ivictim, itype, npro,
                 itag, icar_type, mtotal_loss, fdirection, fdamaged_loc,
                 fcar_status, qpt, fpt, ioth_card_company, ioth_icard,
                 iengine, dfirst_estimate, ientry, dentry, iupdate, dupdate)
                 values
                 ($sIclaim, $ipro_no, $sOth_victim, '2', ' ',
                  ' ', ' ', '0', '00', '00',
                  '00', 0, ' ', ' ', ' ',
                  ' ', NULL, $userid, current, $userid, current);
            }
        }
        else
        {
            strcpy(sFvictim_car, "D");  /* �P�~��������(�Y��訮����)*/
            strcpy(sFadjuster,"99");	/* �z�ߧP�_�]��:99��L */
            if((strcmp(sOth_nation,"3") == 0)||(strcmp(sOth_nation,"9") == 0))
            {
                strcpy(sFdrive,"0");
                strcpy(sFacc_rel, "5");
            }
            else
            {
                strcpy(sFdrive,"0");
                strcpy(sFacc_rel, "D");
            }

            $execute ca573_ca_clm_victim_data
                   using $sIclaim, $sOth_victim, $sDbirth, '1', $sSex,
                         $sFvictim_car, $sFdrive, $sFacc_rel, $sOth_tag, $sOth_nassured,
                         $sFadjuster, $iQduty1, $userid, $userid;
        }
    }
    $CLOSE cur_car5731;
	$FREE cur_car5731;

    /* �T�{�������ƤH��� */
    /* �����r�p */
    $select count(*) into $icntF
       from ca_clm_victim_data
      where iclaim = $sIclaim
        and fvictim_car = 'F';

    /* ���D��� */
    $select count(*) into $icntG
       from ca_clm_victim_data
      where iclaim = $sIclaim
        and fvictim_car in ('F','A','G')
        and fdrive = '1' ;

	/*�g�J�s�w�������ƤH*/
     if ((icntF == 0) && (icntG==0))
     {
        if((strcmp(sFassured,"1") == 0) || (strcmp(sFassured,"3") == 0) || (strcmp(sFassured,"5") == 0))
        {
        		strcpy(sFadjuster,"02");	/* �z�ߧP�_�]��:02��p���� */
            /* �����r�p(���D) */
            sprintf_s(sTmpSQL3,5000,
                "insert into sysdb:ca_clm_victim_data \
                 select '%s', iassured, dbirth, \
                        decode(fassured,'1','1','3','2','5','8','7'),\
                        fsex, \
                        'F', '1', '1', itag, nassured, \
                        nvl(itel,' '), aassured, '1', '99', '%s', %d, \
                        ' ', 0, '00', 'N', 'N', \
                        '%s', current, '%s', current, ' ', ' ' \
                   from %s:policy where ipolicy = '%s'",
                   sIclaim, sFadjuster, iQduty2, userid, userid, sFullName, sIpolicy);
            printf("ca573_ca_clm_process_F1=[%s]\n",sTmpSQL3);
            $prepare ca573_ca_clm_victim_data_F from $sTmpSQL3;
            $execute ca573_ca_clm_victim_data_F;
        }
        else
        {
            /* �������D(�D����,�D�r�p) */
            strcpy(sFadjuster,"00");	/* �z�ߧP�_�]��:00�п�� */
            sprintf_s(sTmpSQL3,5000,
            "insert into sysdb:ca_clm_victim_data \
             select '%s', iassured, dbirth, \
                     decode(fassured,'1','1','3','2','2','3','4','3','5','8','7'), \
                    case when fassured in ('1','3','5') then fsex else '3' end , \
                    'G', '1', '1', itag, nassured, \
                    nvl(itel,' '), aassured, '1', '99', '%s', 0, \
                    ' ', 0, '00', 'N', 'N', \
                    '%s', current, '%s', current, ' ', ' ' \
               from %s:policy where ipolicy = '%s'",
            sIclaim, sFadjuster, userid, userid, sFullName, sIpolicy);
            printf("ca573_ca_clm_process_G=[%s]\n",sTmpSQL3);
            $prepare ca573_ca_clm_victim_data_G from $sTmpSQL3;
            $execute ca573_ca_clm_victim_data_G;

            /* �����r�p(�D���D) */
            strcpy(sFadjuster,"02");	/* �z�ߧP�_�]��:02��p���� */
            $execute ca573_ca_clm_victim_data
             using $sIclaim, 'B', '01/01/1981', '8', '1',
                   'F', '0', '5', $sItag, '�F��A',
                   $sFadjuster, $iQduty2, $userid, $userid;
        }
     }
     else if((icntF == 0) && (icntG > 0))
     {
          /* �����r�p(�D���D) */
          strcpy(sFadjuster,"02");	/* �z�ߧP�_�]��:02��p���� */
          $execute ca573_ca_clm_victim_data
           using $sIclaim, 'B', '01/01/1981', '8', '1',
                 'F', '0', '5', $sItag, '�F��A',
                 $sFadjuster, $iQduty2, $userid, $userid;
     }
     else if((icntF > 0) && (icntG == 0))
     {
           /* �������D(�D����,�D�r�p) */
           strcpy(sFadjuster,"00");	/* �z�ߧP�_�]��:00���� */
            sprintf_s(sTmpSQL3,5000,
            "insert into sysdb:ca_clm_victim_data \
             select '%s', iassured, dbirth, \
                     decode(fassured,'1','1','3','2','2','3','4','3','5','8','7'), \
                    case when fassured in ('1','3','5') then fsex else '3' end , \
                    'G', '1', '1', itag, nassured, \
                    nvl(itel,' '), aassured, '1', '99', '%s', 0, \
                    ' ', 0, '00', 'N', 'N', \
                    '%s', current, '%s', current, ' ', ' ' \
               from %s:policy where ipolicy = '%s'",
            sIclaim, sFadjuster, userid, userid, sFullName, sIpolicy);
            printf("ca573_ca_clm_process_G=[%s]\n",sTmpSQL3);
            $prepare ca573_ca_clm_victim_data_G from $sTmpSQL3;
            $execute ca573_ca_clm_victim_data_G;
     }

	/*�g�J�P�~��y���ƤH*/
    /* �T�{�����ƤH��� */
    if((strcmp(sOth_nation,"3") == 0)||(strcmp(sOth_nation,"9") == 0))
    {
    		if (iQduty1 > 0)
    			strcpy(sFadjuster,"02");	/* �z�ߧP�_�]��:02��p���� */
    		else
    			strcpy(sFadjuster,"01");	/* �z�ߧP�_�]��:01�L�F�Ʀ]�� */

        $execute ca573_ca_clm_victim_data
           using $sIclaim, 'ID002',  '01/01/1981', '8', '1',
                 'E', '0', '5', $sOth_tag, '�F��B',
                 $sFadjuster, $iQduty1, $userid, $userid;

				strcpy(sFadjuster,"00");	/* �z�ߧP�_�]��:00�п�� */
        $execute ca573_ca_clm_victim_data
           using $sIclaim, 'ID003',  ' ', '3', '3',
                 'H', '1', '1', $sOth_tag, '�F��C',
                 $sFadjuster, $iQduty1, $userid, $userid;
    }
    else
    {
    		if (iQduty1 > 0)
    			strcpy(sFadjuster,"02");	/* �z�ߧP�_�]��:02��p���� */
    		else
    			strcpy(sFadjuster,"01");	/* �z�ߧP�_�]��:01�L�F�Ʀ]�� */

        $execute ca573_ca_clm_victim_data
           using $sIclaim, 'ID002',  '01/01/1981', '8', '1',
                 'E', '1', '1', $sOth_tag, '�F��B',
                 $sFadjuster, $iQduty1, $userid, $userid;
    }

    /* �g�Jca_property ----------------------------------------------- */
    /* 1.�g�J������� */
    ipro_no ++;
    sprintf_s(sTmpSQL3, 5000,
        "insert into sysdb:ca_property \
            (iverify, ipro_no, ivictim, itype, npro, \
            itag, icar_type, diissue, mtotal_loss, fdirection, \
            fdamaged_loc, fcar_status, qpt, fpt, ioth_card_company, \
            ioth_icard, \
            iengine, dfirst_estimate, ientry, dentry, iupdate, dupdate) \
        select '%s', %d , a.iassured, '1', ' ', \
            a.itag, b.icar_type, a.dissue , 0 , '00', \
            '00', '00', a.qpt, a.fpt, '17', \
            '17'||trim(a.icard), \
            a.iengine, NULL::DATETIME YEAR TO SECOND, '%s', current, '%s', current \
        from %s:policy a, %s:ply_relation b \
        where a.ipolicy = b.ipolicy and a.ipolicy = '%s' ",
        sIclaim, ipro_no, userid, userid, sFullName, sFullName, sIpolicy);

    printf("ca573_ca_property=[%s]\n",sTmpSQL3);
    $prepare ca573_ca_property from $sTmpSQL3;
    $execute ca573_ca_property;

    /* 2.�g�J��y��� */
    ipro_no ++;

    sprintf_s(sTmpSQL3,5000,
        "insert into sysdb:ca_property \
            (iverify, ipro_no, ivictim, itype, npro, \
            itag, icar_type, diissue, mtotal_loss, fdirection, \
            fdamaged_loc, fcar_status, qpt, fpt, ioth_card_company, \
            ioth_icard, iengine, dfirst_estimate, ientry, dentry, iupdate, dupdate) \
        select a.iclaim, %d , a.ivictim, '1', ' ', \
            a.itag, '%s', '' , 0 , '00', \
            '00', '00', %f, '%s', '%s', \
            '%s', ' ', NULL::DATETIME YEAR TO SECOND, '%s', current, '%s', current \
        from ca_clm_victim_data a \
        where a.iclaim = '%s' \
            and a.fdrive = '1' \
            and fvictim_car in ('E','H')",
        ipro_no, sOth_CarType, dblQpt, sOth_fpt, sIcompany, sOth_card, userid, userid, sIclaim);
    
    printf("1566:sTmpSQL3=[%s]\n", sTmpSQL3);
    $prepare ca573_ca_property_2 from $sTmpSQL3;
    $execute ca573_ca_property_2;
	
    /* ��s ca_clm_process */
    $update sysdb:ca_clm_process
        set dverify = today,
            fclaim_status = '401',
            fclaim_status_pre = '201',
            fprocess = '351',
            dprocess1 = today
        where iclaim = $sIclaim;

    printf("-- car573 insert ok!! \n");
    return SUCCESS;

errexit:
    rc = cm_show_sql_err("car573_insert", "");
    rgetmsg(SQLCODE, sErrorMsg, sizeof(sErrorMsg));
    sprintf_s(errMsg2,150, sErrorMsg, sqlca.sqlerrm);
    sprintf_s(errMsg,5000000, "[%s]\n �i�P�~�׸�:%s�j SQLERROR(%d):%s\n",
            "car573_insert:", trim(sOth_claim), SQLCODE, errMsg2);

    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    $SET LOCK MODE TO NOT WAIT;
    return rc;
}
/* --------------------------------------------------------------------------*/
long car572_insert()
{
    $char sTrSQL[5000], sTmpSQL1[5000];

    EXEC SQL WHENEVER SQLERROR GOTO errexit;

    strcpy(sFullName, get_car_full_db(sIpolicy));
    /* �g�Jca_app_victim */
    sprintf_s(sTrSQL,5000,
        "insert into %s:ca_app_victim "
        "SELECT unique '%s', a.iins_item, a.ivictim, "
        "       CASE a.iins_item1[1,1] WHEN  'B' THEN "
        "           nvl((SELECT max(mdeath_cover) FROM %s:ply_ins_type_hist b"
        "                 WHERE b.ipolicy = a.ipolicy "
        "                   AND b.dedr_begin <= DATE(a.daccident) "
        "                   AND b.dedr_end >= DATE(a.daccident)),0) "
        "       else "
   	    "           nvl((SELECT c.mfactor FROM ca_reco_factor c "
   	    "                 WHERE c.itype = decode(a.iins_item[1],'A','6','7') "
   	    "                   AND c.icode = a.iins_item "
        "                   AND c.dbegin <= DATE(a.daccident) "
        "                   AND c.dend >=  DATE(a.daccident)),0) end as mcoverage, "
        "       a.mprem, 0, '0', '','', today,'','' "
        "  FROM car9263_tpm1 a "
        " WHERE a.ipolicy = '%s' and a.iclaim = '%s' ",
        sFullName, sIclaim, sFullName, sIpolicy, sOth_claim);

		printf("1427:sTrSQL=[%s]\n",sTrSQL);
    $PREPARE pre_572a1 FROM $sTrSQL;
    $execute pre_572a1;

    /* �g�Jca_app_victim_hist */
    sprintf_s(sTrSQL,5000,
        "insert into %s:ca_app_victim_hist "
        "SELECT unique '%s', a.iins_item, a.ivictim, "
        "       CASE a.iins_item1[1,1] WHEN  'B' THEN "
        "           nvl((SELECT max(mdeath_cover) FROM %s:ply_ins_type_hist b"
        "                 WHERE b.ipolicy = a.ipolicy "
        "                   AND b.dedr_begin <= DATE(a.daccident) "
        "                   AND b.dedr_end >= DATE(a.daccident)),0) "
        "       else "
   	    "           nvl((SELECT c.mfactor FROM ca_reco_factor c "
   	    "                 WHERE c.itype = decode(a.iins_item[1],'A','6','7') "
   	    "                   AND c.icode = a.iins_item "
        "                   AND c.dbegin <= DATE(a.daccident) "
        "                   AND c.dend >=  DATE(a.daccident)),0) end as mcoverage, "
        "       a.mprem, 0, today, '%s', current "
        "  FROM car9263_tpm1 a "
        " WHERE a.ipolicy = '%s' and a.iclaim = '%s' ",
        sFullName, sIclaim, sFullName, userid, sIpolicy, sOth_claim);
printf("1450:sTrSQL=[%s]\n",sTrSQL);
    $PREPARE pre_572a2 FROM $sTrSQL;
    $execute pre_572a2;

    /* �g�Jca_accident */
    $insert into sysdb:ca_accident
    (inumber, daccident, iclaim, ipolicy, fcard_class,
     fdmg, mdmg_app, mdmg_stl, flia, mlia_app, mlia_stl, ftrans)
     values
     ($sOth_tag2, $sDacc_mdy, $sIclaim, $sIpolicy, '1',
      0, 0, 0, 0, 0, 0, 'A');
printf("1461:�g�Jca_accident\n");
    /* ��s appraisal */
    sprintf_s(sTmpSQL1,5000,
        "update %s:appraisal \
            set iacc_reason = '%s', \
                inspect = '2', \
                facc_duty = '3', \
                fdmg_duty = '2', \
                fpart = '4', \
                qacar_death = (SELECT count(UNIQUE ivictim) FROM car9263_tpm1 \
                                WHERE iclaim = '%s' AND ipolicy = '%s' \
                                  AND fvictim_car IN ('4','5') AND iins_item[1] = 'B'), \
                qacar_cripple = (SELECT count(UNIQUE ivictim) FROM car9263_tpm1 \
                                WHERE iclaim = '%s' AND ipolicy = '%s' \
                                  AND fvictim_car IN ('4','5') AND iins_item[1] = 'C'), \
                qacar_injure = (SELECT count(UNIQUE ivictim) FROM car9263_tpm1 \
                                WHERE iclaim = '%s' AND ipolicy = '%s' \
                                  AND fvictim_car IN ('4','5') AND iins_item[1] = 'A'), \
                qbcar_death = (SELECT count(UNIQUE ivictim) FROM car9263_tpm1 \
                                WHERE iclaim = '%s' AND ipolicy = '%s' \
                                  AND fvictim_car IN ('1') AND iins_item[1] = 'B'), \
                qbcar_cripple = (SELECT count(UNIQUE ivictim) FROM car9263_tpm1 \
                                WHERE iclaim = '%s' AND ipolicy = '%s' \
                                  AND fvictim_car IN ('1') AND iins_item[1] = 'C'), \
                qbcar_injure = (SELECT count(UNIQUE ivictim) FROM car9263_tpm1 \
                                WHERE iclaim = '%s' AND ipolicy = '%s' \
                                  AND fvictim_car IN ('1') AND iins_item[1] = 'A'), \
                qccar_death = (SELECT count(UNIQUE ivictim) FROM car9263_tpm1 \
                                WHERE iclaim = '%s' AND ipolicy = '%s' \
                                  AND fvictim_car IN ('3') AND iins_item[1] = 'B'), \
                qccar_cripple = (SELECT count(UNIQUE ivictim) FROM car9263_tpm1 \
                                  WHERE iclaim = '%s' AND ipolicy = '%s' \
                                    AND fvictim_car IN ('3') AND iins_item[1] = 'C'), \
                qccar_injure = (SELECT count(UNIQUE ivictim) FROM car9263_tpm1 \
                                WHERE iclaim = '%s' AND ipolicy = '%s' \
                                  AND fvictim_car IN ('3') AND iins_item[1] = 'A'), \
                mapp_loss = (SELECT sum(mprem) FROM car9263_tpm1 \
                              WHERE iclaim = '%s' AND ipolicy = '%s' ), \
                mapp_damage = 0, \
                iapp_entry = '%s', \
                dapp_entry = current \
          where iclaim = '%s' ",
           sFullName, sNewa_reason, sOth_claim, sIpolicy, sOth_claim, sIpolicy,
           sOth_claim, sIpolicy, sOth_claim, sIpolicy, sOth_claim, sIpolicy,
           sOth_claim, sIpolicy, sOth_claim, sIpolicy, sOth_claim, sIpolicy,
           sOth_claim, sIpolicy, sOth_claim, sIpolicy, userid, sIclaim);
     printf("ca572_appraisal=[%s]\n",sTmpSQL1);

     $prepare ca572_appraisal from $sTmpSQL1;
     $execute ca572_appraisal;

     /* ��s ca_clm_process */
     printf("\n 1060:sIpolicy=[%s]\n\n",sIpolicy);
    sprintf_s(sTrSQL,5000,
        "update sysdb:ca_clm_process \
            set dappraisal = today, \
                frule = '0', \
                fclaim_status = '401', \
                fclaim_status_pre = '201', \
                fins = '10', \
                fprocess = '351', \
                dprocess1 = today \
          where iclaim = '%s' and ipolicy = '%s' ",
           sIclaim, sIpolicy);
     printf("ca572_ca_clm_process=[%s]\n",sTmpSQL1);

     $prepare ca572_ca_clm_process from $sTrSQL;
     $execute ca572_ca_clm_process;

    printf("-- car572 insert ok!! \n");
    return SUCCESS;

errexit:
    rc = cm_show_sql_err("car572_insert", "");
    rgetmsg(SQLCODE, sErrorMsg, sizeof(sErrorMsg));
    sprintf_s(errMsg2,150, sErrorMsg, sqlca.sqlerrm);
    sprintf_s(errMsg,5000000, "[%s]\n �i�P�~�׸�:%s�j SQLERROR(%d):%s\n",
            "car572_insert:", trim(sOth_claim), SQLCODE, errMsg2);

    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    $SET LOCK MODE TO NOT WAIT;
    return rc;
}
/* --------------------------------------------------------------------------*/
/* �l���@�~ */
long car575_insert()
{
		$char sIhuman_est[21];
		$char sTrSQL1[3000], sTrSQL2[3000], sTrSQL3[3000];
		$char sIvictim[11], sFhurt[2];
		$int	matone, qpa_daily, mfactor, iage, iyy;

		EXEC SQL WHENEVER SQLERROR GOTO errexit;
printf("---- 1548 ---- \n ");
		qpa_daily = 0;
		mfactor = 0;
		iyy = atoi(sYY);

		$select mfactor into $mfactor
		   from sysdb:ca_reco_factor
		  where itype = '13'
		    and icode = 'A022'
		    and dbegin <= $sDacc_mdy
		    and dend >= $sDacc_mdy;
printf("---- 1559 ---- \n ");
		sprintf_s(sTrSQL2,3000,
			"select ivictim, CASE WHEN iins_item[1] IN ('A','C') THEN '1' ELSE '2' END AS fhurt, "
			"       sum(mapp_cover) as matone, "
			"       max((CASE WHEN iins_item = 'A022' THEN  ceil(mapp_cover/%d ) ELSE 0 END)) as qpa_daily "
			"  from %s:ca_app_victim "
      " WHERE iclaim = '%s' GROUP BY 1,2 ",mfactor,sFullName, sIclaim );
printf("---- 1566 sTrSQL2=[%s] ---- \n ",sTrSQL2);
    $prepare ca575_1 from $sTrSQL2;
    $DECLARE cur_car5751 CURSOR FOR ca575_1;
		$OPEN cur_car5751;
		while(1)
		{
	  	$FETCH cur_car5751 into $sIvictim, $sFhurt, $matone, $qpa_daily;
	    if (SQLCODE == SQLNOTFOUND) break;


			/* ���l���s�� */
			$select case when count(*) == 0 then
	        			'B'|| to_char(today,'%y%m%d')||'0001'
	       			else
	        			'B'||cast(max(ihuman_est[2,11]) as decimal(15,0))+1
	       			end
	       into $sIhuman_est
	  	   from ca_human_est
	      where date(dentry) = today;


			printf("---- 1588 ---- \n ");
			/* �s�W ca_human_est */
			$insert into ca_human_est
				(ihuman_est, iclaim, iverify, fhuman, ivictim,
				 noccupation, nwork, fhurt, ndiagnosis, nhospital,
				 ndoctor, ioffice, nprocurator, ninspector, fburial,
				 qsibling, qpartner, fproof, qloss, pa_type_level,
				 qpa_daily, fracture_level, disability_code, msalary, msalary_loss,
				 qrecover, disability_level, ploss, mamount_com, mamount_arb,
				 mdmg, ncomment, mupper_limit, matone, mdeduct,
				 mclaim, fstatus_human, fupgrade, destimate, dapprove,
				 iapprove, fadjuster, datone_victim, datone, ientry,
				 dentry, iupdate, dupdate, iatone, nbefcomment,
				 datone_approve, iatone_approve, mspirit, mspirit_tot, ninj_names,
				 iunpredict, ibothered, qchild)
			values
			($sIhuman_est, $sIclaim, $sIclaim, '0', $sIvictim,
			 ' ', ' ', $sFhurt, '�F�d���u�ץ�',' ',
			 ' ','00',' ',' ','0',
			 0, 0, '0', 0, ' ',
			 $qpa_daily, 0, ' ', 0, 0,
			 0, ' ', 0, $matone, 0,
			 0, ' ', 0, $matone, 0,
			 0, 130, 'N', current, '',
			 ' ', ' ', '', '', $userid,
			 current, $userid, current, ' ', ' ',
			 '', ' ', 0, 0, ' ',
			 -1,-1,0);

printf("---- 1617 ---- \n ");
			 /* �s�W ca_human_est_hist */
			$insert into ca_human_est_hist
				(ihuman_est, iserial, mestimate_ori, qduty, mdmg,
				 qduty_oth, mestimate, ncomment, mupper_limit, matone,
				 mdeduct, mclaim, fstatus_human, destimate,
				 ientry, dentry)
			values
			($sIhuman_est, 1, 0, 0, 0,
			 0, 0, ' ', 0, $matone,
			 0, 0, 130, today,
			 $userid, current);

printf("-------- 1630 ------- \n ");
			 /* �s�W ca_human_com */
			 sprintf_s(sTrSQL3,3000,
			 	"insert into sysdb:ca_human_com "
			  "select '%s', iins_item, ' ', 0, '1', "
			  "       (SELECT nins_type FROM sysdb:insurance_type "
			  "         WHERE iins_type = a.iins_item) AS nitem, "
        "        CASE WHEN iins_item IN ('A021','A022','A023','A024','A025','A040') THEN "
        "        (SELECT mfactor FROM sysdb:ca_reco_factor "
        "          WHERE itype = '13' AND icode = a.iins_item "
        "            AND dbegin <= '%s' AND dend >= '%s') ELSE mapp_cover end mprice_unit, "
        "        CASE WHEN iins_item IN ('A021','A022','A023','A024','A025','A040') THEN "
        "             ceil(a.mapp_cover / (SELECT mfactor FROM sysdb:ca_reco_factor "
        "                                   WHERE itype = '13' AND icode = a.iins_item "
        "                                     AND dbegin <= '%s' AND dend >= '%s')) "
        "        ELSE  1 end as qqty, "
        "        mapp_cover, '%s', current, '%s', current, 0, 0 "
        "  from %s:ca_app_victim a "
        " where iclaim = '%s' and ivictim = '%s' ",
         sIhuman_est, sDacc_mdy, sDacc_mdy, sDacc_mdy, sDacc_mdy,
         userid, userid, sFullName, sIclaim, sIvictim );
			 $prepare ca575_ca_human_com from $sTrSQL3;
    	 $execute ca575_ca_human_com;

printf("1654 sTrSQL3=[%s] \n ",sTrSQL3);
    	 /* �s�W ca_human_ins */
    	 sprintf_s(sTrSQL3,3000,
			 	"insert into sysdb:ca_human_ins "
			  "select '%s', 0, '1', iins_item, ' ', "
        "        mapp_cover, ' ', '%s', current, '%s', current"
        "  from %s:ca_app_victim a "
        " where iclaim = '%s' and ivictim = '%s' ",
         sIhuman_est, userid, userid, sFullName, sIclaim, sIvictim );
			 $prepare ca_human_ins from $sTrSQL3;
    	 $execute ca_human_ins;

printf("1666 sTrSQL3=[%s] \n ",sTrSQL3);
    	 /* �s�W ca_inherit */
    	 if (strcmp(sFhurt,"2") == 0)
    	 {
    	 		printf("  --- 1670  sIhuman_est=[%s] ---------- \n ", sIhuman_est);
    	 		iage = iyy - 1986;
    	 		$insert into sysdb:ca_inherit
    	 			(ihuman_est, iserial, finherit, nother, iinherit,
						 ninherit, dbirth, qage, malimony, mcomfort,
						 ical_type, ical_area )
					 values
					 ($sIhuman_est, '1', '1', ' ', 'ID004',
					  '�F��D', '01/01/1986', $iage, 0, 0,
					  '1', '00');
    	 }

printf("  -------- 1682 ---------- \n ");
    	 /* ��s ca_clm_process */
    	 $update sysdb:ca_clm_process
         set fprocess = '351',
             dprocess1 = today
       where iclaim = $sIclaim;
		}
		$close cur_car5751;
		$free cur_car5751;

    printf("-- car575 insert ok!! \n");
    return SUCCESS;

errexit:
    rc = cm_show_sql_err("car575_insert", "");
    rgetmsg(SQLCODE, sErrorMsg, sizeof(sErrorMsg));
    sprintf_s(errMsg2,150, sErrorMsg, sqlca.sqlerrm);
    sprintf_s(errMsg,5000000, "[%s]\n �i�P�~�׸�:%s�j SQLERROR(%d):%s\n",
            "car575_insert:", trim(sOth_claim), SQLCODE, errMsg2);

    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    $SET LOCK MODE TO NOT WAIT;
    return rc;
}
/* --------------------------------------------------------------------------*/
/* ñ���@�~ */
long car581_insert(){

		$char isign[21], icard[21], sIfpce_id[11];
    $int sum_mprem;

    EXEC SQL WHENEVER SQLERROR GOTO errexit;

    strcpy(sFullName, get_car_full_db(sIpolicy));

		/* ñ���渹 */
    $select nvl(left(max(isign),7)||lpad(cast(right(max(isign),4) +1 as int),4,0),'XXX')
       into $isign
       FROM ca_sign_receipt
      where date(dentry) = today
        and isign[1,7] = $isign_tmp;
printf("----- 1808 isign=[%s]------\n", isign);

    if (strncmp(isign,"XXX",3) == 0)
        sprintf_s(isign,21,"%s0001",trim(isign_tmp));

		/* �ߴڪ��B */
		$select sum(sum_mprem) into $sum_mprem
       from car9263_d1
      where 1=1;
printf("----- 1817 sum_mprem------\n");
		/* �I�ڹ�HID */
		$SELECT b.ifpce_id
		   into $sIfpce_id
		   FROM cu_code_data a, cu_customer b
		  WHERE a.ncode = b.ifpce_id
		    AND b.ifpce_id_ext = ' '
		    AND a.itype = 'HC'
		    AND a.icode = $sIcompany;
printf("----- 1826------\n");
		/* �s�Wñ������(ca_sign_receipt) */
		$insert into ca_sign_receipt
		(iclaim, ifpce_id, ifpce_id_ext, qserial, mpayment,
		 dpaperwork, dentry,
		 isign, isign_type, pay_kind, fspeed,
		 xfpay_cond, mprocess, iclose_type, icur, frec_type,
		 izipcode, aaddress, nreceiver, iofficer, ioff_branch,
		 ioff_tel_ext, itelephone, imobilephone, nremark, fchange,
		 ientry, iupdate, dupdate, ideliver, invoice_dedu1,
		 invoice_dedu2, icntry, iemail, itel, imobile,
		 tfax, izipcode_con, aperm_con, izip, aperm,
		 ffactory_type, fmodel_type, dsettle
		)
		values
		(
			$sIclaim, $sIfpce_id, ' ', 1,  $sum_mprem,
			current, current,
			$isign, '2', '5', 'C',
			'3', 0, 1, ' ', ' ',
			' ', ' ', ' ', ' ', ' ',
			' ', ' ', ' ', ' ', ' ',
			$userid, $userid, current, ' ', ' ',
			' ', '9', '*', '*', '*',
			'*', '*', '*', ' ', ' ',
			'00','00',today
		);
printf("-- 1853 isign=[%s] ------\n",isign);
		/* ��s ca_human_ins */
		$UPDATE ca_human_ins
				SET iupdate = $userid,
				    dupdate = current,
				    isign = $isign
      WHERE ihuman_est in (select ihuman_est from ca_human_est a, car9263_d1 b
                           where a.ivictim = b.ivictim
                             and a.iclaim = $sIclaim)
        AND iitem = ' '
        AND isign = ' ';


    printf("-- car581 insert ok!! \n");
    return SUCCESS;


errexit:
    rc = cm_show_sql_err("car581_insert", "");
    rgetmsg(SQLCODE, sErrorMsg, sizeof(sErrorMsg));
    sprintf_s(errMsg2,150, sErrorMsg, sqlca.sqlerrm);
    sprintf_s(errMsg,5000000, "[%s]\n �i�P�~�׸�:%s�j SQLERROR(%d):%s\n",
            "car581_insert:", trim(sOth_claim), SQLCODE, errMsg2);

    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    $SET LOCK MODE TO NOT WAIT;
    return rc;
}
/* --------------------------------------------------------------------------*/
/* �ߥI�z�� */
long car582_insert(){

		$char sNote[100], iclm_upcomp[3], sTmpSQL1[50000], icard[21];
		$int sum_mprem,iQduty_Oth;

    EXEC SQL WHENEVER SQLERROR GOTO errexit;

    strcpy(sFullName, get_car_full_db(sIpolicy));

    /* ���d�� */
    sprintf_s(sTmpSQL1,50000,
        " select icard from %s:ply_relation where ipolicy = ? ",sFullName);
    printf("sTmpSQL1[%s]\n",sTmpSQL1);
    $prepare get_icard from $sTmpSQL1;
    $execute get_icard into $icard using $sIpolicy;

		/* �z�߳Ƶ� */
    sprintf_s(sNote,100,"�j���I�F�d���u�վ�@�~--�妸����");
    strcpy(sNote, trim(sNote));

    /* �ߴڪ��B */
		$select sum(sum_mprem) into $sum_mprem
       from car9263_d1
      where 1=1;

    /* iupcomp */
    $select iupcomp
       into $iclm_upcomp
       from branch
      where ibranch = (select iapp_unit from cm_clm_adjuster where empl_no = $sAdjustment);
    if (SQLCODE == SQLNOTFOUND)
    {
        sprintf_s(errMsg,5000000," branch �L�k���z�ߤW�h�����q�N���A�z�߭����s[%s] ", sAdjustment);
        goto errexit;
    }
    printf("iclm_upcomp=[%s]\n",iclm_upcomp);
	/* ��L�F�d = 100 - (���� + ��y) */
	iQduty_Oth = 100 - (iQduty1 + iQduty2);
		/* �s�W settlement */
    sprintf_s(sTmpSQL1,50000,
        "insert into %s:settlement \
            (iclaim, fstl, iclose_type, fcard_class, ipolicy, \
             icard, ientry, dentry, iadjuster, frecover, \
             fsale, istl_recover, ihealth, istl_flag, ioth_fassured, \
             ioth_cartype, ioth_qpt, ioth_fpt, iself_duty, ioth_duty, \
             ianoth_duty, ioth_tag, ioth_compancy, vouch_state, iupdate, \
             dupdate, nnote_claim, freject, msettle, dvouch_bgn, ipayno) \
         values \
            ('%s', '1', '1', '1', '%s', \
             '%s', '%s', current, '%s', 0, \
             0, '1', '1', 'B','%s', \
              '%s', %f, '%s', %d, %d, \
             %d, '%s', '%s', 110, '%s', \
             current, '%s', 'N', '%d', today,'%s')",
        sFullName,
        sIclaim, sIpolicy,
        icard, userid, sAdjustment,
        sOth_nation,
        sOth_CarType, dblQpt, sOth_fpt, iQduty2, iQduty1,
        iQduty_Oth, sOth_tag, sIcompany, userid,
        sNote,sum_mprem,sItransno);

		printf("ca582_settlement=[%s]\n",sTmpSQL1);
    $prepare ca582_settlement from $sTmpSQL1;
    $execute ca582_settlement;


		/* �s�W��ƨ�e�p��ѹ�y������ (stl_oth_dtl)�f */
		sprintf_s(sTmpSQL1,50000,
		  "insert into %s:stl_oth_dtl "
			"SELECT a.iclaim, '1' as fstl, '1' as iclose_type, "
			"       decode(a.fvictim_nation,'3','1','2') AS ioth_fassured, a.itag, "
      "       b.icar_type, b.qpt, b.fpt, b.ioth_card_company, 0 as ioth_mprem, "
      "       a.nassured, a.ivictim, a.itel, "
      "       CASE WHEN a.fvictim_car = 'E' THEN a.nassured ELSE "
      " 	         (SELECT nassured FROM sysdb:ca_clm_victim_data "
      "              WHERE iclaim = a.iclaim AND fvictim_car = a.fvictim_car "
      "                AND a.fdrive = '0') END as driver_nassured, "
      "       CASE WHEN a.fvictim_car = 'E' THEN a.nassured ELSE "
      "          	(SELECT ivictim FROM sysdb:ca_clm_victim_data "
      "              WHERE iclaim = a.iclaim  AND fvictim_car = a.fvictim_car "
      "                AND a.fdrive = '0') END	as driver_iassured, "
      "       a.itel, b.ioth_card_company, b.ioth_icard "
      "  FROM sysdb:ca_clm_victim_data a, sysdb:ca_property b "
      " WHERE a.iclaim = b.iverify     AND a.ivictim = b.ivictim "
      "   AND a.iclaim = '%s'          AND a.fvictim_car IN ('H','D','E') "
      "   AND a.fdrive = '1' ", sFullName, sIclaim);

		printf("ca582_stl_oth_dtl=[%s]\n",sTmpSQL1);
    $prepare ca582_stl_oth_dtl from $sTmpSQL1;
    $execute ca582_stl_oth_dtl;

		/* �s�W��e���`�H�z�߸���� (ca_stl_victim)�f */
		sprintf_s(sTmpSQL1,50000,
			"insert into %s:ca_stl_victim "
			"	(iclaim, fstl, iclose_type, iins_item, ivictim, "
			"  mins_stl, mins_proc, flast, mstl_health) "
			"SELECT iclaim, '1', 1, iins_item, ivictim, "
			"       mapp_cover, mapp_fee, '2', 0 "
      "  FROM %s:ca_app_victim "
      " WHERE iclaim =  '%s' ",sFullName, sFullName, sIclaim);

    printf("ca582_stl_oth_dtl=[%s]\n",sTmpSQL1);
    $prepare ca582_ca_stl_victim from $sTmpSQL1;
    $execute ca582_ca_stl_victim;

		/* �y�ߥI��H��ơz�϶��ݭn�s�W��e�߮׽ߥI��H�� (payment) */
    sprintf_s(sTmpSQL1,50000,
        "insert into %s:payment (iclaim, fstl, iclose_type, ipayment, ifpce_id_ext, qserial, "
                "irepair_shop, fassured, nchi_full, npayment, xsettle_type, ipay_area, xptax, xfpay_cond, "
                "xibank, xiaccount, aperm_con, xastl_obj_c, mpayment, fspeed, dreceiver, dpaperwork, "
                "pay_kind, xmark, icur, frec_type, izipcode, aaddress, nreceiver, iofficer, ioff_branch, "
                "ioff_tel_ext, itelephone, imobilephone, nremark, fchange, iemail, imobile, tfax, izipcode_con, iprocess_type) "
        "SELECT '%s', '1', '1', c.ifpce_id, c.ifpce_id_ext, "
        "       1, ' ', b.fassured, b.nchi_full, c.tstl_remark, "
        "       c.isettle_type, c.ipay, 0, c.fpay_cond, c.ibank, "
        "       c.iaccount, b.aperm, ' ', %d, 'C', "
        "       '', today, '5', ' ', ' ', "
        "       ' ', ' ', ' ', ' ', ' ', "
        "       ' ', ' ', ' ', ' ', ' ', "
        "       ' ', ' ', ' ', ' ',  b.izipcode, ' ' "
        "  FROM cu_code_data a, cu_customer b, cu_stl_obj c "
        " WHERE a.ncode = b.ifpce_id "
        "   AND b.ifpce_id = c.ifpce_id "
        "   AND b.ifpce_id_ext = c.ifpce_id_ext "
        "   AND b.ifpce_id_ext = ' ' "
        "   AND a.itype = 'HC' AND a.icode = '%s'",
        sFullName, sIclaim, sum_mprem, sIcompany);

    printf("ca582_payment=[%s]\n",sTmpSQL1);
    $prepare ca582_payment from $sTmpSQL1;
    $execute ca582_payment;

    /* �s�Wca_local_stl (�t�X�x�_���b,�u�g��x�_) */
    sprintf_s(sTmpSQL1,50000,
        " insert into newa00:ca_local_stl                              \
             (dentry, ipolicy, icard, iclaim, fstl, iclose_type,   \
              ientry, ibranch, fchoose,userid)                            \
           values \                                        \
             (today, ?, ?, ?, '1', '1', ?, ?, '1',?) ");
        printf("ca582_ca_local_stl[%s]\n",sTmpSQL1);
        $prepare ca582_ca_local_stl from $sTmpSQL1;
        $execute ca582_ca_local_stl
           using $sIpolicy, $icard, $sIclaim, $userid, $iclm_upcomp,$userid;

    /* �󥿡e���z�w���� (appraisal)�f����������� */
    sprintf_s(sTmpSQL1,50000,
        "update %s:appraisal \
            set msettle = %d \
          where iclaim = '%s' ",
         sFullName, sum_mprem, sIclaim);

    printf("ca582_appraisal=[%s]\n",sTmpSQL1);
    $prepare ca582_appraisal from $sTmpSQL1;
    $execute ca582_appraisal;

 
		/* �g�J�O���� */
		sprintf_s(sTmpSQL1,50000,
    	"insert into sysdb:ca_clm_com_trans "
			"	(inumber, icompany, iclaim_p, icard_p, fvictim_nation, "
			"  icar_type, qpt, fpt, itag, dacc_yy, "
			"  dacc_mm, dacc_dd, dacc_hh, dacc_ms, iacc_reason, "
			"  iacc_area, nassured, ivictim, dvictim, iins_item1, "
			"  iins_item2, mins_stl, fvictim_car,  qduty_adjuster, qduty_adjuster2, "
  		"  qduty_adjuster3, itag2, oth_company, oth_card, mprem, "
  		"  itransno, ipolicy, iclaim, fstl, iclose_type, "
  		"  adjustment, daccident, iins_item, istl_flag, "
  		"  icreate, dcreate,idate_ym, itmp_no ) "
     	"select inumber, icompany, iclaim, icard, fvictim_nation, "
			"       icar_type, qpt, fpt, itag, dacc_yy, "
    	"       dacc_mm, dacc_dd, dacc_hh, dacc_ms, iacc_reason, "
    	"       iacc_area, nassured, ivictim, dvictim, iins_item1, "
    	"       nvl(iins_item2,' '), mins_stl, fvictim_car, qduty_adjuster, qduty_adjuster2, "
      "       qduty_adjuster3, itag2, oth_company, oth_card, mprem, "
      "       '%s', ipolicy, '%s', '1', 1, "
      "       adjustment, daccident, iins_item, 'B', "
      "       '%s', current, '%s' , ' ' "
      "  from car9263_tpm1 "
      " where icompany = '%s' and iclaim = '%s'; ",
      sItransno, sIclaim, userid, sDataYM, sIcompany, sOth_claim);

		printf("sTmpSQL1=[%s]\n",sTmpSQL1);

		$prepare ca582_ca_clm_com_trans from $sTmpSQL1;
    $execute ca582_ca_clm_com_trans;


		sprintf_s(errMsg2,150,"%s\t%s\t%s\t%4.1f\t%s\t%d\t%d\n",
		                sIcompany, sOth_claim, sOth_card, dblQpt, sIclaim, 1, sum_mprem);
		strcat(errMsg,errMsg2);
    printf("-- car582 insert ok!! \n");
    return SUCCESS;


errexit:
    rc = cm_show_sql_err("car582_insert", "");
    rgetmsg(SQLCODE, sErrorMsg, sizeof(sErrorMsg));
    sprintf_s(errMsg2,150, sErrorMsg, sqlca.sqlerrm);
    sprintf_s(errMsg,5000000, "[%s]\n �i�P�~�׸�:%s�j SQLERROR(%d):%s\n",
            "car582_insert:", trim(sOth_claim), SQLCODE, errMsg2);
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    $SET LOCK MODE TO NOT WAIT;
    return rc;
}
/* --------------------------------------------------------------------------*/
