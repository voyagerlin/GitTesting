/**********************************************************************/
/*   program id   : ca625q03s.ec                                      */
/*   program name : �ζ��P�P�M�׸�Ƥ��@�~                          */
/*   date written : 2003/09/05                                        */
/*   date modify  : 2004/03/08                                        */
/*   files        : ply_relation        i                             */
/*                  ply_ins_type        i                             */
/*                  policy              i                             */
/*   temp table   : car6253             io                            */
/*   Checked for ����100�~�M��                                        */
/**********************************************************************/
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>

/*--------------------------------------------------------------------*/
$char   h_dbgn[11],h_dend[11];
$char   icd[2][21],iply[2][21],icard[21],ipolicy[21],ibig_office_w[10];
$char   ibig_sales[11],itag[CA_TAG_NUM],ibrand[9],iengine[21],ibig_office[10];
$char   nassured[121],iassured[13],dpolicy[11],iissue_ym[7];
$char   iofficer[11],iofficer_prmt[11],iins_type[7],nofficer[11],fedr_class[2];
$char   ioff[2][11],noff[2][11],icomp[4],ncomp[9],nbig_office[11];
$char   nbrand[31],iquota[7],nquota[21],fcard_class[2];
$char   iply1[21],iply2[21],nsales[11],ipro_year[5];
$char   dbgn1[11],dend1[11],remark[31];
$char   remark1[2],remark2[2],remark3[2];
$char   dbgn2[11],dend2[11],dply_begin[11];
$long   mprem_dmg,mprem_11,mprem_17,mprem_oth;   
$long   mprem_11_1,mprem_17_1,mprem_oth_1;   
$long   mprem_21,mprem;
$double rSafe_dmg,rSafe_11,rSafe_17,rSafe_oth;
$double rMgmt_dmg,rMgmt_11,rMgmt_17,rMgmt_oth;
$double tmp_safe=0,tmp_manage=0;
$char   napplicant[121],iapplicant[13];
$int    x,flag_11,x_cnt;
int     iins,iclass,fcomp;
$char   nprmt[31],iofficer_1[2],ioff_chk[11],iagent[11];
$char   dprmt_bgn[11],dprmt_end[11],iprmt[11],iendorse[21],iendorse_tmp[21];
$int    lofficer,iremark,ioff_chk_bgn,ioff_chk_len;
$int    qfield_all,qfield_chk;

$char   sdata[24][41],dbase[40];
$long   mprice;

int     flen,cnt;
int     cnt_s,cnt_f;
FILE    *fp;
char    sApHome[30];
$char   fname[21];
char    filename[50],fulldb[21];

$char   DBName[05], iForm_Tp[03];
char    BodyFile[ N_FILE+1];
char    TitleFile[ N_FILE+1]; 
char    outputf[N_FILE+1], userid[11];

char    msgbuf[100];
$int    ItemRow, TotColumn;
$int    StartRow,TitleRow;
$int    PgLine, Width;

static int  max_cnt,num;
/*--------------------------------------------------------------------*/
/**
main(argc, argv)
int argc;
char **argv;
**/
car6253(DBName1,userid1,iprmt1,dbgn1,dend1,checkD,outputf1)
$char *DBName1,*userid1,*iprmt1,*dbgn1,*dend1,*checkD,*outputf1;
{  
   int rc;

   printf("dbname[%s]userid[%s]output[%s]checkD[%s]\n",
         DBName,userid,outputf,checkD);

   strcpy(DBName, DBName1);
   strcpy(userid, userid1);
   strcpy(iprmt,  iprmt1);
   strcpy(outputf,outputf1);
   strcpy(h_dbgn, dbgn1);
   strcpy(h_dend, dend1);
/**
   strcpy(dbgn2,  isNULLstr(argv[3]));
   strcpy(dend2,  isNULLstr(argv[4]));
   strcpy(dbgn1, cm_to_infdate(dbgn2));
   strcpy(dend1, cm_to_infdate(dend2));  
**/
   rc = car6253_get_db();
   if (rc != SUCCESS) {
      EWRITE(userid,rc,msgbuf);
      return rc;
   }

   rc = car6253_read_prmt();
   if (rc != SUCCESS) {
      EWRITE(userid,rc,msgbuf);
      return rc;
   }

   rc = car6253_build();
   if (rc != SUCCESS) {
      EWRITE(userid,rc,msgbuf);
      return rc;
   }
printf("step5\n");    

   rc = car6253_build1();
   if (rc != SUCCESS) {
      EWRITE(userid,rc,msgbuf);
      return rc;
   }

   rc = car6253_build2();
   if (rc != SUCCESS) {
      EWRITE(userid,rc,msgbuf);
      return rc;
   }

   if (checkD[0]=='1') {
      rc = car6253_build3();
      if (rc != SUCCESS) {
         EWRITE(userid,rc,msgbuf);
         return rc;
      }
   }

   return rc;
}
/*--------------------------------------------------------------------*/
long car6253_get_db()
{
   int  rc;

   if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }

   rc = getApHome(sApHome);
   if (rc < 0) {
       strcpy(msgbuf,"read Config file error!!-->getApHome\n");
       EWRITE(userid,rc,msgbuf);
       return rc;
    }
    
   return SUCCESS;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car6253_read_prmt()
{
   int  rc;

   $select nprmt,iofficer_1,lofficer,iremark,ioff_chk_bgn,
           ioff_chk_len,ioff_chk,iagent,qfield_all,qfield_chk,
           dprmt_bgn,dprmt_end
      into $nprmt,$iofficer_1,$lofficer,$iremark,$ioff_chk_bgn,
           $ioff_chk_len,$ioff_chk,$iagent,$qfield_all,$qfield_chk,
           $dprmt_bgn,$dprmt_end
      from ca_promote
     where iprmt = $iprmt;

   if (SQLCODE==SQLNOTFOUND) {
      strcpy(msgbuf,"�d�L�M�׸��");
      return SQLCODE;
   }
   return SUCCESS;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car6253_build()
{
   $char  TitleFmt[N_FILE+1],BodyFmt[N_FILE+1];
   int    rc;
   
   $whenever sqlerror goto errexit;

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width, $iForm_Tp
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 625
       AND iForm_Tp="7";

   strcpy( TitleFmt,rtrim(TitleFmt));
   strcpy( BodyFmt,rtrim(BodyFmt));
   sprintf( TitleFile,"%sA.ti",outputf);
   sprintf( BodyFile,"%sA.bd",outputf);

   rgu_init_report(TitleFmt,TitleFile);
   car6253_title();
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);
   rc = car6253_read_file();
   
printf("step4\n");    
   if (rc != SUCCESS)
      return rc;
   rgu_finish_report();

   if ((rc=save_form_info(F_BLK0, "CA", 625, userid, iForm_Tp,
        max_cnt, outputf))<0) {
        strcpy(msgbuf,"save_form_info failed");
        return rc;
   }
   return SUCCESS;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car6253_build1()
{
   $char  TitleFmt[N_FILE+1],BodyFmt[N_FILE+1];
   int    rc;
   
   $whenever sqlerror goto errexit;

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width, $iForm_Tp
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 625
       AND iForm_Tp="8";

   strcpy( TitleFmt,rtrim(TitleFmt));
   strcpy( BodyFmt,rtrim(BodyFmt));
   sprintf( TitleFile,"%sB.ti",outputf);
   sprintf( BodyFile,"%sB.bd",outputf);

   rgu_init_report(TitleFmt,TitleFile);
   car6253_title();
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);
   rc = car6253_body1();
   if (rc != SUCCESS)
      return rc;
   rgu_finish_report();

   if ((rc=save_form_info(F_BLK0, "CA", 625, userid, iForm_Tp,
        max_cnt, outputf))<0) {
        strcpy(msgbuf,"save_form_info failed");
        return rc;
   }
   return SUCCESS;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car6253_build2()
{
   $char  TitleFmt[N_FILE+1],BodyFmt[N_FILE+1];
   int    rc;
   
   $whenever sqlerror goto errexit;

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width, $iForm_Tp
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 625
       AND iForm_Tp="9";

   strcpy( TitleFmt,rtrim(TitleFmt));
   strcpy( BodyFmt,rtrim(BodyFmt));
   sprintf( TitleFile,"%sC.ti",outputf);
   sprintf( BodyFile,"%sC.bd",outputf);

   rgu_init_report(TitleFmt,TitleFile);
   car6253_title();
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);
   rc = car6253_body2();
   if (rc != SUCCESS)
      return rc;
   rgu_finish_report();

   if ((rc=save_form_info(F_BLK0, "CA", 625, userid, iForm_Tp,
        max_cnt, outputf))<0) {
        strcpy(msgbuf,"save_form_info failed");
        return rc;
   }
   return SUCCESS;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car6253_build3()
{
   $char  TitleFmt[N_FILE+1],BodyFmt[N_FILE+1];
   int    rc;
   
   $whenever sqlerror goto errexit;

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width, $iForm_Tp
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 625
       AND iForm_Tp="8";

   strcpy( TitleFmt,rtrim(TitleFmt));
   strcpy( BodyFmt,rtrim(BodyFmt));
   sprintf( TitleFile,"%sD.ti",outputf);
   sprintf( BodyFile,"%sD.bd",outputf);

   rgu_init_report(TitleFmt,TitleFile);
   car6253_title();
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);
   rc = car6253_body3();
   if (rc != SUCCESS)
      return rc;
   rgu_finish_report();

   if ((rc=save_form_info(F_BLK0, "CA", 625, userid, iForm_Tp,
        max_cnt, outputf))<0) {
        strcpy(msgbuf,"save_form_info failed");
        return rc;
   }
   return SUCCESS;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;  
}
/*--------------------------------------------------------------------*/
car6253_title()
{
  rgu_put_head();
}
/*--------------------------------------------------------------------*/
long car6253_read_ply()
{
int    first,rc,y;
$char  stmt[1024],stmt1[512],iofficerx[11],stmtdt[81],stmt2[512];

   $whenever sqlerror goto errexit;

   if (h_dbgn[0]=='*')
      strcpy(stmtdt," ");
   else
      sprintf(stmtdt,"and dpolicy between '%s' and '%s' ",h_dbgn,h_dend);

   $declare cur_vs cursor for
     select ipolicy,icard,iassured,itag,fcard_class,nassured
       into $ipolicy,$icard,$iassured,$itag,$fcard_class,$nassured
       from assured_vs_ply
      where iengine = $iengine;
   $open cur_vs;
   x=0;
   first=1;
   for (y=0;y<2;y++) {
       strcpy(icd[y]," ");
       strcpy(iply[y]," ");
       strcpy(ioff[y]," ");
   }
   strcpy(ibig_office_w," ");
   while(1) {
      $fetch cur_vs;
      if (SQLCODE==SQLNOTFOUND) {
         if (first) {
            car6253_body();
            first=0;
            break;
         }
         else { 
            if (x==0)
               car6253_body();
            else {
               rc=car6253_write_data();
               if (rc!=SUCCESS)
                  return rc;
            }
            break;
         } 
      }
      printf("ipolicy[%s]\n",ipolicy);
      if (first) {
         mprem_dmg=mprem_11=mprem_17=mprem_oth=0;
         mprem_21=0;
         x_cnt=0;
      }  
      strcpy(fulldb,get_car_full_db(ipolicy));
      iclass=atoi(fcard_class);
      if (iclass==1) {
         sprintf(stmt,
                "select mlia_prem from %s:ply_relation \
                  where ipolicy = ? %s",fulldb,stmtdt);
         $prepare pre_1 from $stmt;
         $execute pre_1 into $mprem_21 using $ipolicy;
         if (SQLCODE==SQLNOTFOUND) continue;
         if (first) first=0;
      }
      else {
         mprem_11_1=mprem_17_1=mprem_oth_1=flag_11=0;
         sprintf(stmt,
                "select iquota[1,4] || '00',dpolicy,dply_begin,ibrand, \
                        (to_char(dissue,'%%Y')::integer - 1911) || '/' || to_char(dissue,'%%m'), \
                        iofficer,iofficer_prmt,ibig_sales,fedr_class, \
                        nequipment,ibig_office,iapplicant,napplicant[1,40] \
                   from %s:ply_relation a,%s:policy b \
                  where a.ipolicy = ? %s\
                    and a.ipolicy = b.ipolicy ",fulldb,fulldb,stmtdt); 
         $prepare pre_2 from $stmt;
         $execute pre_2 into $iquota,$dpolicy,$dply_begin,$ibrand,
                        $iissue_ym,$iofficer,$iofficer_prmt,$ibig_sales,$fedr_class,
                        $remark,$ibig_office,$iapplicant,$napplicant
                  using $ipolicy;
                  
printf("ipolicy[%s],dissue[%s]\n",ipolicy,iissue_ym);                  
         if (SQLCODE==SQLNOTFOUND) continue;
         if (first) first=0;
         if (strncmp(fedr_class,"1",1)==0) continue;
         strcpy(iofficerx,substring(iofficer,ioff_chk_bgn,
                ioff_chk_len));
         if (strncmp(iofficer,iofficer_1,1) == 0 &&
             strncmp(iofficerx,ioff_chk,ioff_chk_len)==0) {
            strcpy(iply[0],ipolicy);
            strcpy(icd[0],icard);
            strcpy(ioff[0],iofficer);
            strcpy(ibig_office_w,ibig_office);
         }
         else {
            if (x<2) {
               strcpy(iply[1],ipolicy);
               strcpy(icd[1],icard);
               strcpy(ioff[1],iofficer);
            }
         }
         
printf("step1\n");
         
         x++;
         sprintf(stmt1,
                "select iins_type,mins_premium,safe_rate,manage_rate,iendorse \
                   from %s:ply_ins_type \
                  where ipolicy = ? order by 1 desc",fulldb);
         $prepare pre_2d from $stmt1;
         $declare cur_2d cursor for pre_2d;
         $open    cur_2d using $ipolicy;
         while(1) {
         	$fetch cur_2d into $iins_type,$mprem,$tmp_safe,$tmp_manage,$iendorse_tmp;
         	/*printf("478--ipolicy=%s\niendorse=%s\n",ipolicy,iendorse_tmp);
         	printf("iofficer=%s\niofficer_1=%s\nlofficer=%d\n",iofficer,iofficer_1,lofficer);
         	printf("iofficerx=%s\nioff_chk=%s\nioff_chk_len=%d\n",iofficerx,ioff_chk,ioff_chk_len);*/
            if (SQLCODE==SQLNOTFOUND) {
               if (flag_11) {
                  if (strncmp(iofficer,iofficer_1,1) == 0 &&
                      strncmp(iofficerx,ioff_chk,ioff_chk_len)==0 &&
                      strlen(trim(iofficer))==lofficer) {
                     x_cnt++;
                     rc=car6253_write_data_1();
                     if (rc!=SUCCESS)
                        return rc;
                  }
               }
               break;
            }
            
printf("step2\n");            
            iins=atoi(iins_type);
            switch(iins) {
               case 1: case 5: case 8: case 9:
                  mprem_dmg += mprem;
                  mprem_oth_1 += mprem;
                  rSafe_dmg = tmp_safe;
                  rMgmt_dmg = tmp_manage;
                  break;
               case 11:
                  mprem_11 += mprem;
                  mprem_11_1 += mprem;
                  flag_11 = 1;
                  rSafe_11 = tmp_safe;
                  rMgmt_11 = tmp_manage;
                  break;
               case 17:
                  mprem_17 += mprem;
                  mprem_17_1 += mprem;
                  rSafe_17 = tmp_safe;
                  rMgmt_17 = tmp_manage;
                  strcpy( iendorse, iendorse_tmp);
                  /* 1020111001_C2 ���O�X����@�~ */
                  sprintf( stmt2, "UPDATE %s:edr_relation "
                                  "   SET dlock = current year to fraction(3) "
                                  " WHERE iendorse = '%s' "
                                  "   AND dendorse is null "
                                  "   AND dedr_close is null "
                                  "   AND dlock is null ", fulldb, iendorse);
                  $prepare pre1 from $stmt2;
                  $execute pre1;

                  break;
               default:
                  mprem_oth += mprem;
                  mprem_oth_1 += mprem;
                  rSafe_oth = tmp_safe;
                  rMgmt_oth = tmp_manage;
                  break;
            }
printf("step3\n");            
         }
         $close cur_2d;
      }
   }
   $close cur_vs;
   $free  cur_vs;
   return SUCCESS;
errexit:
   sqlfatal();
   strcpy(msgbuf,sqlca.sqlerrm);
   return SQLCODE;  
}
/*--------------------------------------------------------------------*/
car6253_body_tit()
{
int  x;
char tit[11],tit_h[41];

    sprintf(tit_h,"%s�M�׸�Ƥ��@�~--��異��",rtrim(nprmt));
    rgu_put_body_string(1,tit_h,1);
    rgu_put_body_string(1,cm_get_sysd(),1);
    for(x=0;x<qfield_all;x++) {
       if (x==(qfield_chk - 1))
          rgu_put_body_string(1,"�������X",1);
       else {
          sprintf(tit,"���%d",x+1);      
          rgu_put_body_string(1,tit,1);
       }
    }
    for(x;x<15;x++)
       rgu_put_body_string(1," ",1);
    rgu_put_body(1);
    max_cnt=5;
}
/*--------------------------------------------------------------------*/
car6253_body()
{
int  x;
    for(x=0;x<qfield_all;x++) {
       if (strlen(sdata[x])>20)
          sdata[x][20]='\0';
       rgu_put_body_string(2,sdata[x],1);
    }
    for(x;x<15;x++)
       rgu_put_body_string(2," ",1);
    rgu_put_body(2);
    max_cnt++;
}
/*--------------------------------------------------------------------*/
long car6253_body1()
{
int  i;
char tit_h[41];

    sprintf(tit_h,"%s�M�׸�Ƥ��@�~--��粒��",rtrim(nprmt));
    rgu_put_body_string(1,tit_h,        1);
    rgu_put_body_string(1,cm_get_sysd(),1);
    rgu_put_body(1);
    max_cnt=5;
    
printf("step6\n");     

    $declare cur_s cursor for
      select iquota,icard1,icard2,ipolicy1,ipolicy2,iassured,
             nassured,iapplicant,napplicant,dpolicy,dply_begin,ibrand,iengine,iofficer1,
             iofficer2,ibig_sales,itag,mprem_dmg,mprem_11,
             mprem_17,mprem_oth,mprem_21,ply_cnt,ibig_office,
             rSafe_dmg,rSafe_11,rSafe_17,rSafe_oth,
             rMgmt_dmg,rMgmt_11,rMgmt_17,rMgmt_oth
        into $iquota,$icd[0],$icd[1],$iply[0],$iply[1],$iassured,
             $nassured,$iapplicant,$napplicant,
             $dpolicy,$dply_begin,$ibrand,$iengine,$ioff[0],
             $ioff[1],$ibig_sales,$itag,$mprem_dmg,$mprem_11,
             $mprem_17,$mprem_oth,$mprem_21,$x,$ibig_office,
             $rSafe_dmg,$rSafe_11,$rSafe_17,$rSafe_oth,
             $rMgmt_dmg,$rMgmt_11,$rMgmt_17,$rMgmt_oth
        from car6253
       order by 1,2;
                                  
    $open cur_s;

    while(1) {
       $fetch cur_s;
       if (SQLCODE==SQLNOTFOUND) break;
       
printf("step7\n");        
            /**** �~�Z��� ***/
       $select nbranch into $nquota
          from sa_branch_type
         where ibranch = $iquota;
       if ( SQLCODE == SQLNOTFOUND )
          nquota[0]='\0';
   
            /**** �g��H����� ***/
       for(i=0;i<2;i++) {
          if ( ioff[i][0] == ' ') {
             noff[i][0]='\0';
             continue;
          }
          $select nname into $noff[i]
             from officer
            where iofficer = $ioff[i];
          if ( SQLCODE == SQLNOTFOUND )
             noff[i][0]='\0';
       }
            /**** �g�P�ӦW�� ***/
       if (strncmp(ioff[1],iagent,1)==0)
          strncpy(icomp,ioff[1],3);
       else
          strncpy(icomp,ibig_office,3);
       $select ncode into $ncomp
          from cu_code_data
         where itype = '23'
           and icode = $icomp;
       if (SQLCODE==SQLNOTFOUND)
          ncomp[0]='\0';
       $select nname
          into $nbig_office
          from officer
         where iofficer = $ibig_office;
       if (SQLCODE==SQLNOTFOUND)
          nbig_office[0]='\0';

            /*** ��~�ҷ~�N��ƺ��@�� ***/
       $select nname into $nsales
          from ca_big_office
         where ibig_comp = $ibig_sales 
           and fclass='2';
       if ( SQLCODE == SQLNOTFOUND )
          nsales[0]='\0';
            
           /*** �t�P���� ***/   
       $declare cur cursor for
         select nbrand, ipro_year
           into $nbrand,$ipro_year
           from ca_car_model 
          where ibrand= $ibrand
          order by ipro_year DESC ;
       $open cur;
       $fetch cur;
       if ( SQLCODE == SQLNOTFOUND )
          nbrand[0]='\0';
       $close cur;
       $free cur;
       
printf("step8\n");        
           
       car6253_print();
    }
    $close cur_s;
    $free cur_s;
   
    return SUCCESS;

errexit:
   sqlfatal();
   strcpy(msgbuf,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car6253_body2()
{
char tit_h[41];
char remark_tmp[2];

    sprintf(tit_h,"%s�M�׸�Ƥ��@�~--�дک���",rtrim(nprmt));
    rgu_put_body_string(1,tit_h,        1);
    rgu_put_body_string(1,cm_get_sysd(),1);
    rgu_put_body_string(1,rtrim(nprmt), 1);
    rgu_put_body(1);
    max_cnt=5;

    $declare cur_p cursor for
      select iquota,icard,ipolicy,iassured,
             nassured,iapplicant,napplicant,
             dpolicy,dply_begin,ibrand,iengine,iofficer,ibig_office,
             ibig_sales,itag,mprem_11,
             mprem_17,mprem_oth,ply_cnt,remark,
             rSafe_11,rSafe_17,rSafe_oth,rMgmt_11,rMgmt_17,rMgmt_oth,iendorse
        into $iquota,$icard,$ipolicy,$iassured,
             $nassured,$iapplicant,$napplicant,
             $dpolicy,$dply_begin,$ibrand,$iengine,$iofficer,$ibig_office,
             $ibig_sales,$itag,$mprem_11,
             $mprem_17,$mprem_oth,$x,$remark,
             $rSafe_11,$rSafe_17,$rSafe_oth,$rMgmt_11,$rMgmt_17,$rMgmt_oth,$iendorse
        from car6253_1
       order by 1,2;
                                  
    $open cur_p;

    while(1) {
       $fetch cur_p;
       if (SQLCODE==SQLNOTFOUND) break;
            /**** �~�Z��� ***/
       $select nbranch into $nquota
          from sa_branch_type
         where ibranch = $iquota;
       if ( SQLCODE == SQLNOTFOUND )
          nquota[0]='\0';
   
            /**** �g��H����� ***/
       $select nname into $nofficer
          from officer
         where iofficer = $iofficer;
       if ( SQLCODE == SQLNOTFOUND )
          nofficer[0]='\0';
          
          /****�g�P��****/
       strncpy(icomp,iofficer,3);
       $select ncode into $ncomp
          from cu_code_data
         where itype = '23'
           and icode = $icomp;
       if ( SQLCODE == SQLNOTFOUND)
          ncomp[0]='\0';

            /*** ��~�ҷ~�N��ƺ��@�� ***/
       $select nname into $nsales
          from ca_big_office
         where ibig_comp = $ibig_sales 
           and fclass='2';
       if ( SQLCODE == SQLNOTFOUND )
          nsales[0]='\0';
            
           /*** �t�P���� ***/   
       $declare cur_1 cursor for
         select nbrand, ipro_year
           into $nbrand,$ipro_year
           from ca_car_model 
          where ibrand= $ibrand
          order by ipro_year DESC ;
       $open cur_1;
       $fetch cur_1;
       if ( SQLCODE == SQLNOTFOUND )
          nbrand[0]='\0';
       $close cur_1;
       $free cur_1;

       if (equip_cmp(remark,"18") == TRUE)
       {
           strcpy(remark1,"1");
       }
       else
       {
           strcpy(remark1,"0");
       }

       if (equip_cmp(remark,"11") == TRUE)
       {
           strcpy(remark2,"1");
       }
       else
       {
           strcpy(remark2,"0");
       }
     
       strcpy(remark_tmp,itoa(iremark));
       if (equip_cmp(remark,remark_tmp) == TRUE)
       {
           strcpy(remark3,"1");
       }
       else
       {
           strcpy(remark3,"0");
       }

/**************************************************
       remark1[0]=remark[17];          �DTOBE(18) 
       remark2[0]=remark[10];          TOBE(11)   
       remark3[0]=remark[iremark-1];   �M�׵��O   
**************************************************/

       car6253_print1();
    }
    $close cur_p;
    $free cur_p;
   
    return SUCCESS;

errexit:
   sqlfatal();
   strcpy(msgbuf,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car6253_body3()
{
DBinfo *list;
int    i,j,count_db,rc;
$int   cnt;
$char  stmt[1024],stmt1[1024],iofficero[11];
char tit_h[61];

  $whenever sqlerror goto errexit;

  if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
     if (EWRITE(userid, M_CM_NOT_DBLIST) == True)
        return M_CM_NOT_DBLIST;
     return M_CM_OK;
  }


  sprintf(tit_h,"%s�M�׸�Ƥ��@�~--�g�P���q�L���",rtrim(nprmt));
  rgu_put_body_string(4,tit_h,        1);
  rgu_put_body_string(4,cm_get_sysd(),1);
  rgu_put_body(4);
  max_cnt=5;

  for(j=0;j<count_db;j++) {
     sprintf(stmt,
     "select iquota,a.icard,a.ipolicy,iassured, \
             nassured,dpolicy,dply_begin,ibrand,iengine,iofficer, \
             ibig_sales,itag,mlia_prem + mdmg_prem,1,ibig_office, \
             iapplicant,napplicant[1,40] \
        from %s:ply_relation a,%s:policy b \
       where dpolicy >= '%s' \
         and dpolicy <= '%s' \
         and fedr_class != '1' \
         and iofficer[1] = '%s' \
         and iofficer[%d,%d] = '%s' \
         and length(iofficer) = %d \
         and a.ipolicy = b.ipolicy ",list[j].dbname,list[j].dbname,
             dprmt_bgn,dprmt_end,iofficer_1,ioff_chk_bgn,
             ioff_chk_bgn+ioff_chk_len-1,ioff_chk,lofficer);
    $prepare pre_w from $stmt;
    $declare cur_w cursor for pre_w;
    $open cur_w;
    while(1) {
       $fetch cur_w
         into $iquota,$icard,$ipolicy,$iassured,
              $nassured,$dpolicy,$dply_begin,$ibrand,$iengine,$iofficero,
              $ibig_sales,$itag,$mprem_dmg,$x,$ibig_office,$iapplicant,$napplicant;
       if (SQLCODE==SQLNOTFOUND) break;

       $select count(*) 
          into $cnt
          from car6253_1
         where ipolicy = $ipolicy;
       if (cnt > 0) continue;
        
            /**** �~�Z��� ***/
       $select nbranch into $nquota
          from sa_branch_type
         where ibranch = $iquota;
       if ( SQLCODE == SQLNOTFOUND )
          nquota[0]='\0';
   
            /**** �g��H����� ***/
       $select iofficer,nname
          into $iofficer,$nofficer
          from officer
         where iofficer = $ibig_office;
       if ( SQLCODE == SQLNOTFOUND ) {
          nofficer[0] ='\0';
          strcpy(iofficer,iofficero);
       }

            /**** �g�P�Ӹ�� ***/
       strncpy(icomp,iofficer,3);
       $select ncode into $ncomp
          from cu_code_data
         where itype = '23'
           and icode = $icomp;
       if ( SQLCODE == SQLNOTFOUND )
          ncomp[0]='\0';
       
            /*** ��~�ҷ~�N��ƺ��@�� ***/
       $select nname into $nsales
          from ca_big_office
         where ibig_comp = $ibig_sales 
           and fclass='2';
       if ( SQLCODE == SQLNOTFOUND )
          nsales[0]='\0';
            
           /*** �t�P���� ***/   
       $declare cur11 cursor for
         select nbrand, ipro_year
           into $nbrand,$ipro_year
           from ca_car_model 
          where ibrand= $ibrand
          order by ipro_year DESC ;
       $open cur11;
       $fetch cur11;
       if ( SQLCODE == SQLNOTFOUND )
          nbrand[0]='\0';
       $close cur11;
       $free cur11;
           
       car6253_print2();
    }
    $close cur_w;
  }
  $free cur_w;
   
  return SUCCESS;

errexit:
   sqlfatal();
   strcpy(msgbuf,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car6253_write_data()
{
   $whenever sqlerror goto errexit;

   $insert into car6253 values
    ($iquota,$icd[0],$iply[0],$icd[1],$iply[1],$iassured,$nassured,$iapplicant,$napplicant,
     $dpolicy,$dply_begin,$ibrand,$iengine,$iissue_ym,$ioff[0],
     $ioff[1],
     $ibig_sales,$itag,$mprem_dmg,$mprem_11,$mprem_17,
     $mprem_oth,$mprem_21,$x,$ibig_office_w,$rSafe_dmg,$rSafe_11,$rSafe_17,$rSafe_oth,
     $rMgmt_dmg,$rMgmt_11,$rMgmt_17,$rMgmt_oth);

   if (x_cnt > 1)
      $update car6253_1
          set ply_cnt = $x_cnt
        where iengine = $iengine;

   return SUCCESS;
errexit:
    sqlfatal();
    strcpy(msgbuf,sqlca.sqlerrm);
    return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car6253_write_data_1()
{
   $whenever sqlerror goto errexit;
   if( strncmp(iofficer,"N",1) == 0 )          /*N�g��:iofficer��"�^�k�g��N��iofficer_prmt"*/
   {
   $insert into car6253_1 values
    ($iquota,$icard,$ipolicy,$iassured,$nassured,$iapplicant,$napplicant,
     $dpolicy,$dply_begin,$ibrand,$iengine,$iissue_ym,$iofficer_prmt,$ibig_office,
     $ibig_sales,$itag,$mprem_11_1,$mprem_17_1,
     $mprem_oth_1,1,$remark,$rSafe_11,$rSafe_17,$rSafe_oth,
     $rMgmt_11,$rMgmt_17,$rMgmt_oth,$iendorse_tmp);

   return SUCCESS;
   }
   else
   {
   $insert into car6253_1 values
    ($iquota,$icard,$ipolicy,$iassured,$nassured,$iapplicant,$napplicant,
     $dpolicy,$dply_begin,$ibrand,$iengine,$iissue_ym,$ibig_office,$ibig_office,
     $ibig_sales,$itag,$mprem_11_1,$mprem_17_1,
     $mprem_oth_1,1,$remark,$rSafe_11,$rSafe_17,$rSafe_oth,
     $rMgmt_11,$rMgmt_17,$rMgmt_oth,$iendorse_tmp);

   return SUCCESS;
   }

errexit:
    sqlfatal();
    strcpy(msgbuf,sqlca.sqlerrm);
    return SQLCODE;  
}
/*--------------------------------------------------------------------*/
car6253_print()
{
  char str[20];
  char brand14[6], noff2[10];
  
  rgu_put_body_string(2,iquota,1);
  rgu_put_body_string(2,nquota,1);
  rgu_put_body_string(2,ncomp ,1);
  rgu_put_body_string(2,icd[0],1);
  rgu_put_body_string(2,iply[0],1);
  rgu_put_body_string(2,icd[1],1);
  rgu_put_body_string(2,iply[1],1);
  rgu_put_body_string(2,iassured,1);
  rgu_put_body_string(2,nassured,1);
  rgu_put_body_string(2,iapplicant,1);
  rgu_put_body_string(2,napplicant,1);
  rgu_put_body_string(2,dpolicy,1);
  rgu_put_body_string(2,dply_begin,1);
  
  strncpy(brand14, ibrand, 4 );
  brand14[4] = '\0';
  
  rgu_put_body_string(2,brand14,1);  
  rgu_put_body_string(2,ibrand,1);
  rgu_put_body_string(2,nbrand,1);
  rgu_put_body_string(2,iengine,1);
  rgu_put_body_string(2,iissue_ym,1);
  
/*******
  strncpy(noff2, noff[1], 4 );
  noff2[4] = '\0';
********/
  
  rgu_put_body_string(2,ioff[0] ,1);
  rgu_put_body_string(2,noff[0] ,1);
  rgu_put_body_string(2,nbig_office ,1);
  rgu_put_body_string(2,ioff[1] ,1);
  rgu_put_body_string(2,noff[1] ,1);
  rgu_put_body_string(2,ibig_sales,1);
  rgu_put_body_string(2,nsales,1);
  rgu_put_body_string(2,itag,1);
  rfmtlong(mprem_dmg, "---------&", str);
  rgu_put_body_string(2,str,2);
  rfmtlong(mprem_11, "---------&", str);
  rgu_put_body_string(2,str,2);
  rfmtlong(mprem_17, "---------&", str);
  rgu_put_body_string(2,str,2);
  rfmtlong(mprem_oth, "---------&", str);
  rgu_put_body_string(2,str,2);
  rfmtlong(mprem_21, "---------&", str);
  rgu_put_body_string(2,str,2);
  rfmtlong(x       , "-&", str);
  rgu_put_body_string(2,str,2);
  
printf("step9\n");   
  
  rfmtdouble(rSafe_dmg,"-&&.&&&&&&&", str);
  rgu_put_body_string(2,str,2);
  rfmtdouble(rSafe_11,"-&&.&&&&&&&", str);
  rgu_put_body_string(2,str,2);
  rfmtdouble(rSafe_17,"-&&.&&&&&&&", str);
  rgu_put_body_string(2,str,2);
  rfmtdouble(rSafe_oth,"-&&.&&&&&&&", str);
  rgu_put_body_string(2,str,2);
  rfmtdouble(rMgmt_dmg,"-&&.&&&&&&&", str);
  rgu_put_body_string(2,str,2);
  rfmtdouble(rMgmt_11,"-&&.&&&&&&&", str);
  rgu_put_body_string(2,str,2);
  rfmtdouble(rMgmt_17,"-&&.&&&&&&&", str);
  rgu_put_body_string(2,str,2);
  rfmtdouble(rMgmt_oth,"-&&.&&&&&&&", str);
  rgu_put_body_string(2,str,2);
  
printf("step10\n");  
  
  rgu_put_body(2);
  max_cnt++;
}   
/*--------------------------------------------------------------------*/
car6253_print1()
{
  char str[20];
  char brand14[6], noff2[10];
  
  rgu_put_body_string(2,iquota,1);
  rgu_put_body_string(2,nquota,1);
  rgu_put_body_string(2,ncomp ,1);
  rgu_put_body_string(2,icard,1);
  rgu_put_body_string(2,ipolicy,1);
  rgu_put_body_string(2,iendorse,1);
  rgu_put_body_string(2,iassured,1);
  rgu_put_body_string(2,nassured,1);
  rgu_put_body_string(2,iapplicant,1);
  rgu_put_body_string(2,napplicant,1);
  rgu_put_body_string(2,dpolicy,1);
  rgu_put_body_string(2,dply_begin,1);
  
  strncpy(brand14, ibrand, 4 );
  brand14[4] = '\0';
  
  rgu_put_body_string(2,brand14,1);
  rgu_put_body_string(2,ibrand,1);
  rgu_put_body_string(2,nbrand,1);
  rgu_put_body_string(2,iengine,1);
  rgu_put_body_string(2,iissue_ym,1);
  
  rgu_put_body_string(2,iofficer,1);
  rgu_put_body_string(2,ibig_office,1);     /*���I�N��*/
  rgu_put_body_string(2,nofficer,1);
  rgu_put_body_string(2,ibig_sales,1);
  rgu_put_body_string(2,nsales,1);
  rgu_put_body_string(2,itag,1);
  rfmtlong(mprem_11, "---------&", str);
  rgu_put_body_string(2,str,2);
  rfmtlong(mprem_17, "---------&", str);
  rgu_put_body_string(2,str,2);
  rfmtlong(mprem_oth, "---------&", str);
  rgu_put_body_string(2,str,2);
  /*rfmtlong(x       , "-&", str);
  rgu_put_body_string(2,str,2);
  rgu_put_body_string(2,remark1,1);
  rgu_put_body_string(2,remark2,1);*/
  rgu_put_body_string(2,remark3,1);
    
  /*rfmtdouble(rSafe_11,"-&&.&&&&&&&", str);
  rgu_put_body_string(2,str,2);
  rfmtdouble(rSafe_17,"-&&.&&&&&&&", str);
  rgu_put_body_string(2,str,2);
  rfmtdouble(rSafe_oth,"-&&.&&&&&&&", str);
  rgu_put_body_string(2,str,2);  
  rfmtdouble(rMgmt_11,"-&&.&&&&&&&", str);
  rgu_put_body_string(2,str,2);
  rfmtdouble(rMgmt_17,"-&&.&&&&&&&", str);
  rgu_put_body_string(2,str,2);
  rfmtdouble(rMgmt_oth,"-&&.&&&&&&&", str);
  rgu_put_body_string(2,str,2);*/
  
  rgu_put_body(2);
  max_cnt++;
}   
/*--------------------------------------------------------------------*/
car6253_print2()
{
  char str[20];
  char brand14[6], noff2[10];
  
  rgu_put_body_string(2,iquota,1);
  rgu_put_body_string(2,nquota,1);
  rgu_put_body_string(2,ncomp ,1);
  rgu_put_body_string(2,icard ,1);
  rgu_put_body_string(2,ipolicy,1);
  rgu_put_body_string(2," "   ,1);
  rgu_put_body_string(2," "   ,1);
  rgu_put_body_string(2,iassured,1);
  rgu_put_body_string(2,nassured,1);
  rgu_put_body_string(2,iapplicant,1);
  rgu_put_body_string(2,napplicant,1);
  rgu_put_body_string(2,dpolicy,1);
  rgu_put_body_string(2,dply_begin,1);
  
  strncpy(brand14, ibrand, 4 );
  brand14[4] = '\0';
  
  rgu_put_body_string(2,brand14,1);
  rgu_put_body_string(2,ibrand,1);
  rgu_put_body_string(2,nbrand,1);
  rgu_put_body_string(2,iengine,1);
  rgu_put_body_string(2,iissue_ym,1);
  
  rgu_put_body_string(2,iofficer,1);
  rgu_put_body_string(2,nofficer,1);
  rgu_put_body_string(2," "     ,1);
  rgu_put_body_string(2," "     ,1);
  rgu_put_body_string(2," "     ,1);
  rgu_put_body_string(2,ibig_sales,1);
  rgu_put_body_string(2,nsales,1);
  rgu_put_body_string(2,itag,1);
  rfmtlong(mprem_dmg, "---------&", str);
  rgu_put_body_string(2,str,2);
  strcpy(str," ");
  rgu_put_body_string(2,str,2);
  rgu_put_body_string(2,str,2);
  rgu_put_body_string(2,str,2);
  rgu_put_body_string(2,str,2);
  rfmtlong(x       , "-&", str);
  rgu_put_body_string(2,str,2);
  
  rgu_put_body(2);
  max_cnt++;
}   
/*--------------------------------------------------------------------*/
long car6253_read_file()
{
    char   *bp;
    int    rc,i,j,k,m,n;

    $whenever sqlerror goto errexit;

    rc=car6253_create_temp();
    if (rc != SUCCESS)
        return rc;

    sprintf(filename,"%s/dat/car/car625.txt",sApHome);
    flen=1024;
    if ((fp=fopen(filename,"r"))==NULL) {
       sprintf(msgbuf,"%s �ɮ׶}�ҥ���",filename);
       return FALSE;
    }
    if ((bp=malloc(flen))==NULL) {
       sprintf(msgbuf,"System malloc failed !");
       return FALSE;
    }

    car6253_body_tit();

    for (i=0;(feof(fp)==0);i++) {
        memset(bp,0x00,flen);
        fgets(bp,flen,fp);
        if (bp[0]==0x00)
           break;
        for(j=0;j<qfield_all;j++)
           memset(sdata[j],0x00,41);
        k=m=n=0;
        for (j=0;j<flen;j++) {
            if (bp[j]=='\t' || bp[j]=='\0' || bp[j]=='\n') {
                strncpy(sdata[k],bp+m,j-m);
                sdata[k][j-m]='\0';
                m=j+1;
                k++;
            }
            if (bp[j]=='\n')
                break;
            if (k > (qfield_all - 1)) break;
        }      
        if (sdata[0][0]=='\0') continue;
        rtrim_alldata2();
        
        printf("iengine[%s]\n",iengine);
        rc=car6253_read_ply();
        if (rc!=SUCCESS)
           return rc;
    }

    return SUCCESS;
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car6253_create_temp()
{
    $whenever sqlerror goto errexit;
      
    $create temp table car6253
     (iquota         char(6),
      icard1         char(20),
      ipolicy1       char(20),
      icard2         char(20),
      ipolicy2       char(20),
      iassured       char(12),
      nassured       char(40),
      iapplicant     char(12),
      napplicant     char(40),
      dpolicy        date,
      dply_begin     date,
      ibrand         char(8),
      iengine        char(20),
      iissue_ym      char(6),
      iofficer1      char(10),
      iofficer2      char(10),
      ibig_sales     char(10),
      itag           char(12),
      mprem_dmg      integer,
      mprem_11       integer, 
      mprem_17       integer,
      mprem_oth      integer,
      mprem_21       integer,
      ply_cnt        integer,
      ibig_office    char(9),
      rSafe_dmg      decimal(9,7),
      rSafe_11       decimal(9,7),
      rSafe_17       decimal(9,7),
      rSafe_oth      decimal(9,7),
      rMgmt_dmg      decimal(9,7),
      rMgmt_11       decimal(9,7),
      rMgmt_17       decimal(9,7),
      rMgmt_oth      decimal(9,7)) 
     with no log;

    $create temp table car6253_1
     (iquota         char(6),
      icard          char(20),
      ipolicy        char(20),
      iassured       char(12),
      nassured       char(40),
      iapplicant     char(12),
      napplicant     char(40),
      dpolicy        date,
      dply_begin     date,
      ibrand         char(8),
      iengine        char(20),
      iissue_ym      char(6),
      iofficer       char(10),
      ibig_office    char(10),
      ibig_sales     char(10),
      itag           char(12),
      mprem_11       integer, 
      mprem_17       integer,
      mprem_oth      integer,
      ply_cnt        integer,
      remark         char(30),
      rSafe_11       decimal(9,7),
      rSafe_17       decimal(9,7),
      rSafe_oth      decimal(9,7),
      rMgmt_11       decimal(9,7),
      rMgmt_17       decimal(9,7),
      rMgmt_oth      decimal(9,7),
      iendorse       char(20))
     with no log;

    return SUCCESS;
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;  
}
/*--------------------------------------------------------------------*/
rtrim_alldata2()
{
    int  x;
    for(x=0;x<qfield_all;x++)
       strcpy(sdata[x],rtrim(sdata[x]));
    strcpy(iengine,sdata[qfield_chk-1]);
}
/*--------------------------------------------------------------------*/
