/**********************************************************************/
/*   program id   : ca402q01s.ec                                      */
/*   program name : ���H�u�f�ֲέp����                              */
/*   date written : 2018/01/02 by 061476                              */
/**********************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <decimal.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "globdata.h"
$include "safeclib.h";

$char ipass[11],dpass_bgn[10],dpass_end[10],ipolicy[21],iendorse[21],ibranch[3],fpass[2];


int   count_db,k; 
char  outputf[21];
$char userid[11];
$char DBName[05];
$char msgbuf[128];

DBinfo *list;
/*--------------------------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
 int rc;

	batchinit();
	strcpy(DBName,         isNULLstr(argv[1]));
	strcpy(userid,         isNULLstr(argv[2]));
	strcpy(ipass,          isNULLstr(argv[3]));  /*�f�֤H��*/
	strcpy(dpass_bgn,      isNULLstr(argv[4]));  /*�f�ְ϶�(�_:CYYMMDD)*/
	strcpy(dpass_end,      isNULLstr(argv[5]));  /*�f�ְ϶�(��)*/
	strcpy(ipolicy,        isNULLstr(argv[6]));  /*�O�渹*/
	strcpy(iendorse,       isNULLstr(argv[7]));  /*��渹*/
	strcpy(ibranch,        isNULLstr(argv[8]));  /*�X����(�O��e��X)*/
	strcpy(fpass,          isNULLstr(argv[9]));  /*�f�֪��A*/
	strcpy(outputf,        isNULLstr(argv[10]));
	
	printf("1.car402_get_db() \n");
	rc = car402_get_db();
	if (rc != M_CM_OK)
		return rc;
		
	printf("2.car402_build() \n");	
	rc = car402_build();
	if (rc != M_CM_OK) 
		return rc;
}
/*--------------------------------------------------------------------------------------*/
long car402_get_db()
{
	$whenever sqlerror goto errexit;

	if (db_select(DBName) == FALSE) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
/*--------------------------------------------------------------------------------------*/
long car402_build()
{
	int rc;
	char sfilename[256],stitle[2048],stmt[6000];
	$char stmt1[1024];
	$char stmp_ipass[64],stmp_dbgn[64],stmp_ipolicy[64];
	$char stmp_iendorse[64],stmp_ibranch[64],stmp_fpass[64];
	$char dbgn[11],dend[11];

	$WHENEVER SQLERROR goto errexit;
	
	if (db_select(DBName) == FALSE)
	{
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return FAIL;
	}

	strcpy(ipass,trim(ipass));
	strcpy(ipolicy,trim(ipolicy));
	strcpy(iendorse,trim(iendorse));
	strcpy(ibranch,trim(ibranch));
	strcpy(fpass,trim(fpass));
		
	if(strncmp(ipass,"*",1) != 0)
	    sprintf_s(stmp_ipass, sizeof stmp_ipass,"AND a.ipass = '%s' ",ipass);
	else
	    sprintf_s(stmp_ipass, sizeof stmp_ipass,"  ");
	
	if(strncmp(dpass_bgn,"*",1) != 0)
	{
		strcpy(dbgn,cm_to_infdate(dpass_bgn));  
	    strcpy(dend,cm_to_infdate(dpass_end)); 
	    sprintf_s(stmp_dbgn, sizeof stmp_dbgn,"AND a.dpass between '%s' and '%s' ",dbgn,dend); 
	}
	else
	    sprintf_s(stmp_dbgn, sizeof stmp_dbgn,"  ");
	
	if(strncmp(ipolicy,"*",1) != 0)
	    sprintf_s(stmp_ipolicy, sizeof stmp_ipolicy,"AND a.ipolicy = '%s' ",ipolicy);
	else
	    sprintf_s(stmp_ipolicy, sizeof stmp_ipolicy,"  ");
	
	if(strncmp(iendorse,"*",1) != 0)
	    sprintf_s(stmp_iendorse, sizeof stmp_iendorse,"AND a.iendorse = '%s' ",iendorse);
	else
	    sprintf_s(stmp_iendorse, sizeof stmp_iendorse,"  ");
	
	if(strncmp(ibranch,"*",1) != 0)
	    sprintf_s(stmp_ibranch, sizeof stmp_ibranch,"AND a.ipolicy[1,2] = '%s' ",ibranch);
	else
	    sprintf_s(stmp_ibranch, sizeof stmp_ibranch,"  ");
	
	if(strncmp(fpass,"Y",1) == 0)
	    sprintf_s(stmp_fpass, sizeof stmp_fpass,"AND a.fpass in ('Y','P') ");
	else 
	    sprintf_s(stmp_fpass, sizeof stmp_fpass,"AND a.fpass = 'N' ");
	    
	$create temp table car402_tmp1
	(
	    nassured      char(120),
	    iabnormal     char(20),
		ipolicy       char(20),
		iendorse      char(20),
		itag          char(12),
		dply_begin    char(10),
		dply_end      char(10),
		dedr_begin    char(10),
		dedr_end      char(10),
		ipass         char(21),
		dpass         char(10),
		npass         char(100)
	) with no log;
	
	/* SQL����''��ASCII��127�X,�i����EXCEL�ɮɥi������ܼƦr���e,���|���@�Ӧr��,
       �p�G�s�ɷ|�y������x�s�Τ����D,���V�� */
	
	sprintf_s(stmt1, sizeof stmt1,"INSERT INTO car402_tmp1 "
			" SELECT b.nassured,a.iabnormal,a.ipolicy,a.iendorse,b.itag,b.dply_begin, "
			"        b.dply_end,a.dedr_begin,a.dedr_end, "
			"        trim(a.ipass)||':'||(SELECT nname FROM officer WHERE iofficer = a.ipass),a.dpass,a.npass  "
			" FROM abn_edr_relation a,abnormal_edr b "
			" WHERE a.iabnormal = b.iabnormal "  
	  		" %s %s %s %s %s %s "
	  		,stmp_ipass,stmp_dbgn,stmp_ipolicy,stmp_iendorse,stmp_ibranch,stmp_fpass);
	  		
	printf("--stmt1[%s]\n", stmt1);
	$PREPARE ply_tmp FROM $stmt1;
	$EXECUTE ply_tmp;

	strcpy(sfilename,"���H�u�f�ֲέp����[car402]");
    sprintf_s(stitle, sizeof stitle,"�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");
	
	strcat(stitle,"\t�Q�O�I�H\t���`��\t�O�渹\t��渹\t����\t�O�I�_��\t�O�I����");
	strcat(stitle,"\t���_��\t��樴��\t�}��H��\t�}����\t�֭��]");
    
    strcpy(stmt,"select * from car402_tmp1 where 1=1 ");
	               
	rc = unload_file(outputf," ",sfilename,stitle,stmt);
	
	if (rc != SUCCESS) 
	{
	    sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
	    EWRITE(userid, rc , msgbuf);
	    return rc;
	}
	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	return SQLCODE;
}
