/*******************************************/
/*                                         */
/*   PROGRAM : ca419q01s.ec                */
/*                                         */
/*   DATE    : 920402                      */
/*   �O�o�ק�j���I�s�W���� -> car413      */
/*   ���`�N�U��Ʈw�����A�ŧ˿�            */
/*   ipaid_base ���^��                     */
/*   �ק�鵲                              */
/*   ���P�ɭY�P�ɦ�2�i���h���P�ɩ�w���O */
/*   �����姹�~������A�婵���O�T�_�h      */
/*   �����O�T�|�A�ߤ@��                    */
/*                                         */
/*******************************************/

#include <stdio.h>
#include <math.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
#include "carmsgs.h"
#include "carmsg.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqltypes.h"
$include cmnroute.h;

extern char RPTDIR[];

int  first,flag;


$char DBName[5],FormTp[3];
$char outputf[N_FILE+1], userid[6];
static int max_cnt=0;
$char sDB[3];
$char processid[21];
$char sErrmsg[51];
$char prep_stmt[4096];
$char icar_type[3];
$char iins_cat[2];
$char sDBa[3];
$int  qply_period;
$char iyear[2];

long car419_build();
long car419_accumulate();
long car417_report();
char *get_db();
FILE   *sfp;
$char    v_sMsg[1512], sErrMsg[1024];

#define fmt "---,---,---,---"

/*----------------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
   int rc;
   char afstatus[2];

   batchinit();
   strcpy(DBName,    isNULLstr(argv[1]));
   strcpy(userid,    isNULLstr(argv[2]));
   strcpy(processid, isNULLstr(argv[3]));
   strcpy(outputf,   isNULLstr(argv[4]));

   printf("processid[%s]\n",processid);

   rc = car419_build();
   if (rc != M_CM_OK)
   {
       EWRITE(userid, rc, "car419 �g�J�ɮצ��~");
       exit(1);
   }

   strcpy(afstatus,"5");
   printf("afstatus[%s]\n",afstatus);
   rc = car417_report(DBName,userid,processid,afstatus,outputf);
   if (rc != M_CM_OK)
   {
       EWRITE(userid, rc, "car419 ���ͳ������~");
       exit(1);
   }
}

/*----------------------------------------------------------------------------*/
long car419_build()
{
   $char  FormFmt[N_FILE+1];
   $int   StartRow, TitleRow, TotColumn, PgLine, Width;
    long  rc;

   char   FormFile[N_FILE+1];

   $WHENEVER SQLERROR GOTO errexit;


   if (db_select(DBName) == False)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return FAIL;
   }

   $SELECT nForm_File, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $FormFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width, $FormTp
      FROM Form
     WHERE ksys_grp = "CA" AND kPgmID = 419;
   strcpy(FormFmt, rtrim(FormFmt));
   sprintf(FormFile, "%s.tx", outputf);

   /* create & insert data with temp table */
   rc = car419_accumulate();
   if (rc != M_CM_OK)
       goto errexit;

   return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return FAIL;
}


long car419_accumulate()
{
   $char   stmt[10000], stmp[128];
   $char   ipolicy[21];
   $char   ibroker[11];
   $char   iins_type[7];
   $char   dpolicy_bgn[11],dpolicy_end[11];
   $char   sFull[31];
   $char   sFulla[31];
   $long   existcnt;

   /*  ca_comm_balance */
   $long   mcomm_diff_old,magent_diff_old,mdeal_diff_old;
   $long   mcomm_diff,magent_diff,mdeal_diff;

   /*  ori_ins_type   edr_ins_type  */
   $long   mins_premium;
   $long   mdiscount;
   $long   mcommission,magent;
   $char   iendorse[21];
   $char   fcard_class[2];

   /*  commission_agent  */
   $double pcommission,pagent;
   $double pcommission_new,pagent_new, pbusiness_new, pdiscount_new, pextra_charge_new;
   $long   mcommission_new;
   $long   mservice;
   $char   ipaid_base[2], drate_ym[5], drate_ym_rel[5];
   $char   fstatus[2];

   /*  ca_pa_ori   ca_pa_edr  */
   $long   mcomm_33,magent_33;
   $long   mcomm_new,magent_new;
   $long   mcomm_33_old,magent_33_old;
   $long   mcomm_33_diff,magent_33_diff;
   $char   iinsurant[11];
   $char   iins_scope[2];
   $char   icareer[2];

   /*  comm edr    */
   $char sIdir[9];
   $date dwritten;
   $char iedr_type[3];
   $char ori_fcard_class[2];
   $char ori_iofficer[11];
   $char ori_ibroker[11];
   $int  ibatch_no;
   $char ori_fedr_class[2];
   $char ibus_location[11];
    char sIbilling[3];
    char sIbranchIcomp[CA_POL_BRH_NUM];
    char sIcomp_in[BRANCH_ID], sIbranch_in[BRANCH_ID];
   $char ibranch_at[3],icomp_at[3];
   $long fRtnCode;
    char sIcomp_in_short[BRANCH_ID];
   $char temp[POLICY_NUM_1];
   $long stepi;
   $char policy_1[21],policy_2[21];
    char payresult[3], paystatus[32], paydate[9], notedate[9];
   $char fpay[2];
   $char batchno[4];
   $long mdmg_commi,mdmg_agent;
   $long mlia_commi,mlia_agent;
   $char fins_grp[2];
   $char branch[3];
   $double dMod;
   $char iendor68[4];
   $char iins_cat[3];
   $char icar_type[3];
    int  ihasdata;
   $date dply_begin,dply_end;
   $int  same;
   $long mservice_tmp;
   long  rc;
   $char   sCCC1[101], sCCC2[101], sCCC3[101], f980401[2], irelative_ply[21];
   double rCCC1, rCCC2, rCCC3;

   $long medr_commission,medr_agent, lMcommission;
   $char deffect[11], iabn_type[2], comp_frate[6];
   $double mbusiness;

   /* 1000311003 �q��2 */
   $char   insure_type[2], iofficer[11], fstart[2], fauth[2];
   $char   irate_type[2],iroute_comm[4];
   $char   ileader[11], iquota[11], icomm_obj[11], iroute[21], iroute_prop[3];
   $char   opt[2], swhere[128];
   int     *o_qrec;
   $struct cm_route_comm o_stcomm;
   $char   ipgid[11];
   $char dlock[31],iroute_accept_edr[21];

   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT;

    existcnt = 0;
    mcomm_diff_old = magent_diff_old = mdeal_diff_old = 0;
    mins_premium = mdiscount = mcommission = magent = 0;
    pcommission = pagent = 0;
    mservice = 0;
    mservice_tmp = 0;
    mcomm_33 = magent_33;
    mcomm_33_old = magent_33_old = 0;
    mcomm_33_diff = magent_33_diff = 0;
    pcommission_new = pagent_new = pbusiness_new = pdiscount_new = pextra_charge_new = 0; 
    dMod = 0;

    rtoday(&dwritten);
    strcpy(iedr_type,"84");

    $BEGIN WORK;
    $CREATE TEMP TABLE pa_temp 
    (
      ipolicy     char(20) default ' ',
      iins_type   char(6)  default ' ',
      iinsurant   char(10) default ' ',
      iins_scope  char(1)  default ' ',
      icareer     char(1)  default ' ',
      mcommission integer  default 0,
      magent      integer  default 0
    ) WITH NO LOG;

    $CREATE UNIQUE INDEX pa_temp_ix_1 on pa_temp 
    (ipolicy,iins_type,iinsurant,iins_scope,icareer);
    $CREATE INDEX pa_temp_ix_2 on pa_temp
    (ipolicy);

    $SELECT idir
       INTO $sIdir
       FROM user
      WHERE iemp = $userid;
         if (SQLCODE == SQLNOTFOUND)
         {
             sprintf(sErrmsg,"[%s]�ϥΪ̩|������",userid);
             printf("sErrmsg[%s]\n",sErrmsg);
             goto errexit;
         }

         strncpy(ibranch_at, sIdir, BRANCH_ID-1);
         ibranch_at[BRANCH_ID-1] = '\0';
         printf("userid[%s],sIdir[%s],ibranch_at[%s]\n",userid,sIdir,ibranch_at);

    $SELECT iupcomp
       INTO $icomp_at
       FROM sa_branch_type
      WHERE ibranch = $sIdir;
         if (SQLCODE == SQLNOTFOUND)
         {
             sprintf(sErrmsg,"�L�k���ϥΪ�[%s]�W�h���[%s]",userid,ibranch_at);
             printf("sErrmsg[%s]\n",sErrmsg);
             goto errexit;
         }
             printf("icomp_at[%s]\n",icomp_at);

    sprintf(stmt,
     " UPDATE ca_comm_balance            \
          SET (fstatus,dadjust,iendorse,remark) \
            = (?,?,?,?)                    \
        WHERE ipolicy  = ?               \
          AND iprocess = ?  ");
     $PREPARE up_bal FROM $stmt; 

    sprintf(stmt,
     " UPDATE ca_comm_balance            \
          SET (fstatus,dadjust,iendorse) \
            = (?,?,?)                    \
        WHERE ipolicy  = ?               \
          AND iins_type = ?              \
          AND iprocess = ?  ");
     $PREPARE up_bal_a FROM $stmt; 

    sprintf(stmt,
     " SELECT unique ipaid_base  \
         FROM commission_agent                     \
        WHERE iins_cat = ?                         \
          AND ibroker = ?                          \
          AND iins_type = ?                        \
          AND iyear = ? ");
     $PREPARE comid FROM $stmt;

    sprintf(stmt,
     " SELECT unique ipaid_base  \
         FROM commission_agentc                    \
        WHERE iins_cat = ?                         \
          AND ibroker = ?                          \
          AND iins_type = ?                        \
          AND deffect = ?                          \
          AND iyear = ?");
     $PREPARE comid_deffect FROM $stmt;

    sprintf(stmt,
     " SELECT pagent*100,pcommiss*100,mservice,ipaid_base  \
         FROM commission_agent                     \
        WHERE iins_cat = 'C'                       \
          AND ibroker = ?                          \
          AND iins_type = ?                        \
	  AND iyear     = ? ");
     $PREPARE comid_a FROM $stmt;

    sprintf(stmt,
     " SELECT pagent*100,pcommiss*100,mservice,ipaid_base  \
         FROM commission_agent                     \
        WHERE iins_cat = ?                         \
          AND ibroker = ?                          \
          AND iins_type = ?                        \
	  AND iyear     = ? ");
     $PREPARE comid_c FROM $stmt;
     
    /****************
    sprintf(stmt,
     " SELECT pagent*100,pcommiss*100,mservice,ipaid_base  \
         FROM commission_agentc                    \
        WHERE iins_cat = 'C'                       \
          AND ibroker = ?                          \
          AND iins_type = ?                        \
          AND deffect   = ? ");
     $PREPARE comid_a_deffect FROM $stmt;
    *****************/

    sprintf(stmt,
     " SELECT fins_grp                             \
         FROM insurance_type                       \
        WHERE iins_type = ? ");
     $PREPARE surid FROM $stmt;

    sprintf(stmt,
     " INSERT INTO pa_temp                                          \
         (ipolicy,iins_type,iinsurant,iins_scope,icareer,mcommission,magent)  \
       VALUES (?,?,?,?,?,?,?) ");
     $PREPARE ins_pa FROM $stmt;

    sprintf(stmt,
     " UPDATE pa_temp                       \
          SET (mcommission,magent)          \
            = (mcommission + ?,magent + ?)  \
        WHERE ipolicy = ?                   \
          AND iins_type = ?                 \
          AND iinsurant = ?                 \
          AND iins_scope = ?                \
          AND icareer = ? ");
     $PREPARE up_pa FROM $stmt;

     sprintf(stmt,
     " SELECT ibroker,dpolicy_bgn,dpolicy_end,iins_type,      \
              pcomm,pagent,mdeal,mcomm_diff,magent_diff,mdeal_diff,deffect, iroute, irate_type, iroute_comm \
         FROM ca_comm_balance                                \
        WHERE iprocess = ?                                   \
          AND ipolicy  = ?                                   \
          AND NVL(fstatus,' ') = ' '                         \
          AND dadjust IS NULL ");
     $PREPARE pro_id FROM $stmt;
     $DECLARE pro_cur CURSOR FOR pro_id;
    
    ihasdata = 0;

   /* 1000311003 �q��2 */
    memset(&o_stcomm, 0, sizeof(o_stcomm));
    o_qrec = 0;
    strcpy( insure_type, "C");
    iofficer[0] = fstart[0] = fauth[0] = '\0';

    sprintf(stmt,
    "  SELECT distinct ipolicy                       \
         FROM ca_comm_balance                        \
        WHERE iprocess = ?                           \
          AND NVL(fstatus,' ') = ' '                 \
          AND dadjust IS NULL                        \
        ORDER BY ipolicy ");
     $PREPARE main_id FROM $stmt;
     $DECLARE main_cur CURSOR FOR main_id;
     $OPEN main_cur USING $processid;
     for(;;)
     {
     $FETCH main_cur INTO $ipolicy;
     if (SQLCODE == SQLNOTFOUND) break;
     ihasdata = 1;
     strcpy(sDB,get_db(ipolicy));
     strcpy(sFull,trim(get_full_dbname(sDB)));

          sprintf(stmt, "SELECT a.irelative_ply,  \
                                a.iofficer, a.ileader, a.iquota, a.icomm_obj, b.iroute, b.iroute_prop, \
                                a.irate_type, a.iroute_comm, a.dlock \
                           FROM %s:ply_relation a, %s:policy b \
                          WHERE a.ipolicy = b.ipolicy \
                            AND a.ipolicy = ? " ,sFull, sFull);
          $PREPARE get_new_ply FROM $stmt;
          $EXECUTE get_new_ply INTO $irelative_ply, $iofficer, $ileader, $iquota, $icomm_obj, 
                                    $iroute, $iroute_prop, $irate_type, $iroute_comm, $dlock
             USING $ipolicy;
          $FREE get_new_ply;

          strcpy(fstatus, "F");
          strcpy( temp, "");

          if( strlen(trim(dlock)) != 0 ) /* ���O��B2C��襤�A�ȮɵL�k��� */
          {
              sprintf( sErrMsg, "�O�渹[%s]�����, �]���G���O��B2C��襤�A�ȮɵL�k���", ipolicy);
              printf("sErrMsg[%s]\n",sErrMsg);
              $EXECUTE up_bal
                 USING $fstatus,$dwritten,$temp, $sErrMsg, $ipolicy, $processid;
              continue;
          }

          /* 1000311003 �q��2 */
          /* �~�Z���O�_���� */
          strcpy( opt, "2");
          rc = cm_chk_policy( opt, iofficer, ileader, iquota, icomm_obj, insure_type, iroute, iroute_prop);
          if( rc != M_CM_OK)
          {
              strcpy(stmp, cm_get_errmsg( rc));
              sprintf( sErrMsg, "�O�渹[%s]�����, �]���G%s,����������N�z�O���", ipolicy, stmp);
              printf("sErrMsg[%s]\n",sErrMsg);
              $EXECUTE up_bal
                 USING $fstatus,$dwritten,$temp, $sErrMsg, $ipolicy, $processid;
              continue;
          }
          /* �I����H�O�_����O */
          strcpy( opt, "5");
          rc = cm_chk_policy( opt, iofficer, ileader, iquota, icomm_obj, insure_type, iroute, iroute_prop);
          if( rc != M_CM_OK)
          {
              strcpy(stmp, cm_get_errmsg( rc));
              sprintf(sErrMsg,"�O�渹[%s],�I����H[%s],���~�T��[%s][%d]\n", ipolicy, icomm_obj, stmp,rc);
              printf("sErrMsg[%s]\n",sErrMsg);
              $EXECUTE up_bal
                 USING $fstatus,$dwritten,$temp, $sErrMsg, $ipolicy, $processid;
              continue;
          }

          /* �I����H���L�X���� */
          strcpy( opt, "6");
          rc = cm_chk_policy( opt, iofficer, ileader, iquota, icomm_obj, insure_type, iroute, iroute_prop);
          if( rc != M_CM_OK)
          {
              strcpy(stmp, cm_get_errmsg( rc));
              sprintf(sErrMsg,"�O�渹[%s],�I����H[%s],���~�T��[%s][%d]\n", ipolicy, icomm_obj, stmp,rc);
              printf("sErrMsg[%s]\n",sErrMsg);
              $EXECUTE up_bal
                 USING $fstatus,$dwritten,$temp, $sErrMsg, $ipolicy, $processid;
              continue;
          }

          strcpy( fstart, "Y");

          sprintf(stmt,
         " SELECT pcommission,pagent,mcommission, pbusiness, drate_ym, pdiscount, pextra_charge  \
             FROM %s:ply_ins_type     \
            WHERE ipolicy = ?         \
              AND iins_type = ? ",sFull);
         $PREPARE get_new_com FROM $stmt;

          sprintf(stmt,
         " SELECT iins_type, iinsurant, iins_scope,icareer,mins_premium,mdiscount,  \
                  mcommission,magent         \
             FROM %s:ca_pa_ori               \
            WHERE ipolicy = ? ",sFull);
         $PREPARE ins33id FROM $stmt;
         $DECLARE ins33_cur CURSOR FOR ins33id;

          sprintf(stmt,
         " SELECT iins_type,iinsurant,iins_scope,icareer,medrins_prem,medr_discount,  \
                  medr_commission,medr_agent                                \
             FROM %s:ca_pa_edr                                              \
            WHERE iendorse = ? ",sFull);
         $PREPARE ins33id_edr FROM $stmt;
         $DECLARE ins33_edr_cur CURSOR FOR ins33id_edr;

          sprintf(stmt,
         " SELECT mins_premium,mdiscount,mcommission,magent  \
             FROM %s:ori_ins_type                            \
            WHERE ipolicy = ?                                \
              AND iins_type = ? ",sFull);
         $PREPARE ins_id FROM $stmt;

          sprintf(stmt,
         " SELECT fcard_class,icar_type,qply_period        \
             FROM %s:ori_ply_relation                      \
            WHERE ipolicy = ? ",sFull);
         $PREPARE oriply_id FROM $stmt;
         $EXECUTE oriply_id
             INTO $fcard_class,$icar_type, $qply_period
            USING $ipolicy;
               if (SQLCODE == SQLNOTFOUND)
               {
                   sprintf(sErrmsg,"�L�k���[%s]��l�O����",ipolicy);
                   printf("sErrmsg[%s]\n",sErrmsg);
                   goto errexit;
               }

         rc = get_iins_cat( icar_type, 1, qply_period, iins_cat, iyear, v_sMsg );
         if( rc != M_CM_OK)
         {
              sprintf(sErrmsg,"�O��[%s]����[%s],�ӫO���[%d],�I�O�~�����s�b",ipolicy,icar_type,qply_period);
              printf("sErrmsg[%s]\n",sErrmsg);
              goto errexit;
         }

          same = 0;

         $OPEN pro_cur USING $processid,$ipolicy ;
         for(;;)
         {
         $FETCH pro_cur
           INTO $ibroker,$dpolicy_bgn,$dpolicy_end,$iins_type,
                $pcommission,$pagent,$mservice,$mcomm_diff_old,$magent_diff_old,$mdeal_diff_old,
                $deffect, $iroute, $irate_type, $iroute_comm;

             if (SQLCODE == SQLNOTFOUND) break;

             if( strlen( trim(ibroker)) != 0)  /* ����Jibroker */
             {
                 rc = chk_ibroker_expire( ibroker, sErrmsg);
                 if( rc != M_CM_OK)
                 {
                     goto errexit;
                 }
             }
             strcpy( iins_type, trim( iins_type));
             strcpy(fstatus,"S");
             mdeal_diff = 0;
             mcomm_diff = magent_diff = 0;
             mcomm_33 = magent_33 = 0;
             mcomm_new = magent_new = 0;
             mcomm_33_old = magent_33_old = 0;
             mcomm_33_diff = magent_33_diff = 0;

             /* �O���� */
             $EXECUTE ins_id
                 INTO $mins_premium,$mdiscount,$mcommission,$magent
                USING $ipolicy,$iins_type;
               if (SQLCODE == SQLNOTFOUND)
               {
                   /***  doint nothing ��Ӥ~��[�A�ѧ��q�B�z
                   sprintf(sErrmsg,"�L�k���[%s]��l�O��[%s]�I�ظ��",ipolicy,iins_type);
                   printf("sErrmsg[%s]\n",sErrmsg);
                   goto errexit;
                   ***/
               }
               else
               {
                    /* 1000311003 �q��2 */
                    if( fstart[0] == 'Y')
                    {
                        rc = cm_get_insure_comm(iroute, irate_type, iroute_comm, insure_type, iins_cat, iins_type, iyear, &o_qrec, &o_stcomm, deffect);
                        if (rc != M_CM_OK)
                        {
                            strcpy(stmp, cm_get_errmsg( rc));
                            sprintf(sErrMsg,"�O�渹[%s],��渹[%s],�q���N��[%s],�O�v�O[%s],�~�ȱ���[%s],�I��[%s],�~��[%s],�ͮĤ�[%s],���~�T��:[%s][%d]\n",
                                             ipolicy, iendorse, iroute, irate_type, iroute_comm, iins_type, iyear, deffect, stmp, rc );
                            printf("sErrMsg[%s]\n",sErrMsg);
                            goto errexit;
                        }
                        else if( o_qrec == 0)
                        {
                            if (iins_cat[0] == 'C' || iins_cat[0] == 'X' || iins_cat[0] == 'Z')
                            {
                                memset(&o_stcomm, 0x00, sizeof(o_stcomm));
                                o_qrec = 0;
                                strcpy( iins_cat, "C");
                                strcpy( iyear, "0");
                                rc = cm_get_insure_comm(iroute, irate_type, iroute_comm, insure_type, iins_cat, iins_type, iyear, &o_qrec, &o_stcomm, deffect);

                                if (rc != M_CM_OK )
                                {
                                    strcpy(stmp, cm_get_errmsg( rc));
                                    sprintf(sErrmsg,"�O�渹[%s],�q���N��[%s],�O�v�O[%s],�~�ȱ���[%s],�I��[%s],�~��[%s],�ͮĤ�[%s],���~�T��:[%s][%d]\n",
                                                     ipolicy, iroute, irate_type, iroute_comm, iins_type, iyear, deffect, stmp,rc );
                                    printf("sErrmsg[%s]\n",sErrmsg);
                                    goto errexit;
                                }
                            }
                            if( o_qrec == 0)
                            {
                                sprintf(sErrmsg,"�O�渹[%s],�q���N��[%s],�O�v�O[%s],�~�ȱ���[%s],�I��[%s],�~��[%s],�ͮĤ�[%s],�����N�z�v�ɸ�Ƨ䤣��\n",
                                                 ipolicy, iroute, irate_type, iroute_comm, iins_type, iyear, deffect );
                                printf("sErrmsg[%s]\n",sErrmsg);
                                goto errexit;
                            }
                        }

                        /* �u����ipaid_base, ��L��ƨ� ca_comm_balance */
                        strcpy( ipaid_base, o_stcomm.ipaid_base);
                   }
                   else
                   {
                       if ((deffect[0] == ' ') || (deffect[0] == '\0'))
                       {
                          $EXECUTE comid
                              INTO $ipaid_base
                             USING $iins_cat,$ibroker,$iins_type, $iyear;
                             if (SQLCODE == SQLNOTFOUND)
                             {
                                 sprintf(sErrmsg,"[%s]�g���H[%s]�|������",ibroker,iins_type);
                                 printf("sErrmsg[%s]\n",sErrmsg);
                                 goto errexit;
                             }
                       }
                       else
                       {
                          $EXECUTE comid_deffect
                              INTO $ipaid_base
                             USING $iins_cat,$ibroker,$iins_type,$deffect,$iyear;
                             if (SQLCODE == SQLNOTFOUND)
                             {
                                 sprintf(sErrmsg,"[%s]�g���H[%s]�|������",ibroker,iins_type);
                                 printf("sErrmsg[%s]\n",sErrmsg);
                                 goto errexit;
                             }
                       }
                   }

                   $EXECUTE get_new_com
                       INTO $pcommission_new,$pagent_new,$mcommission_new, $pbusiness_new, $drate_ym,
                          $pdiscount_new, $pextra_charge_new
                      USING $ipolicy,$iins_type;

                      if (SQLCODE == SQLNOTFOUND)
                      {
                          sprintf(sErrmsg,"[%s]�̷s�O��[%s]�I�ؤ��s�b",ipolicy,iins_type);
                          printf("sErrmsg[%s]\n",sErrmsg);
                          goto errexit;
                      }
                      if (fcard_class[0] == '1')
                      {
                          if ((mcommission_new == 0) || (mcommission_new == mservice))
                          {
                               same = 1;
                          }
                          
                          /* car9803311���q���ץ��N�I�Y�O�¶O�v,�ӱj���I�H�¤���O��I,����� */
                          if( strlen(trim( irelative_ply)) !=0 &&
                              (strncmp( trim(ibroker), "JH",2) == 0 ||
                               strncmp( trim(ibroker), "BD",2) == 0 )
                            )
                          {
                              sprintf( stmt, "SELECT max(drate_ym)"
                                             "  FROM %s:ori_ins_type"
                                             " WHERE ipolicy = ?", sFull);
    
                              $PREPARE prep1 FROM $stmt;
                              $EXECUTE prep1 INTO $drate_ym_rel USING $irelative_ply;

                              if (risnull(SQLCHAR, drate_ym_rel) != 1) /* �����N�I�O�v�N�� */
                              {
                                  $SELECT case when drate >= date('04/01/2009') then '1' else '0' end
                                     INTO $f980401
                                     FROM ca_rate_date
                                    WHERE icode  = $drate_ym_rel
                                     AND itable = 'cm_extra_charge';
    
                                  if (SQLCODE == SQLNOTFOUND)
                                  {
                                     sprintf(sErrmsg,"�O�v�N��[%s],���[�O�βv�O�v�ͮĤ�䤣��,�Ь��ӫO����car120�]�w", drate_ym);
                                     printf("sErrmsg[%s]\n",sErrmsg);
                                     goto errexit;
                                  }
                                  /* ���N�I���¶O�v,����� */
                                  if( f980401[0] == '0')
                                      continue;
                              }
                          }
                      }
                      else
                      {   printf("pagent_new[%f],pagent[%f]\n",pagent_new,pagent);
                          if ((pcommission_new == pcommission) && (pagent_new == pagent))
                          {
                               same = 1;
                          }

                          $SELECT case when drate >= date('04/01/2009') then '1' else '0' end
                             INTO $f980401
                             FROM ca_rate_date
                            WHERE icode  = $drate_ym
                                           AND itable = 'cm_extra_charge';

                          if (SQLCODE == SQLNOTFOUND)
                          {
                             sprintf(sErrmsg,"�O�v�N��[%s],���[�O�βv�O�v�ͮĤ�䤣��,�Ь��ӫO����car120�]�w", drate_ym);
                             printf("sErrmsg[%s]\n",sErrmsg);
                             goto errexit;
                          }

                          /* �O�v�ۥѤƤ��� */
                          if( f980401[0] == '1')
                          {
                              printf("�̷s�O��pdiscount_new[%f]\n", pdiscount_new);
                              if( pdiscount_new != 0) /* �O�v�ۥѤƤ��ᤣ�i������ */
                              {
                                 sprintf(sErrmsg,"�O�渹[%s],�O�v�ۥѤƤ��ᤣ�i������", ipolicy);
                                 printf("sErrmsg[%s]\n",sErrmsg);
                                 goto errexit;
                              }

                              sprintf( sCCC1 ,"%f", (double)(pdiscount_new + pcommission + pagent));
                              sprintf( sCCC2 ,"%f", (double)( (pextra_charge_new - pbusiness_new) * 100.0));

                              rCCC1 = atof( sCCC1);
                              rCCC2 = atof( sCCC2);
    
                              printf("��+�N+�u[%-3.20f]\n", rCCC1);
                              printf("��-�~   [%-3.20f]\n", rCCC2);
    
                              if ( rCCC1 > rCCC2 )
                              {
                                 sprintf(sErrmsg,"�O�渹[%s],(�����v+�~�޶O�βv) ���i�j�� ���[�O�βv,�Ь��ӫO��", ipolicy);
                                 printf("sErrmsg[%s]\n",sErrmsg);
                                 goto errexit;
                              }
                          }

                      }
                      if (fcard_class[0] == '1')
                      {
                          mdeal_diff = mservice - mcommission;
                      }
                      else
                      {
                          if (strcmp(iins_type,"33") == 0 ||
                              strcmp(iins_type,"35") == 0 ||
                              strcmp(iins_type,"48") == 0 ||
                              strcmp(iins_type,"56") == 0 ||
                              strcmp(iins_type,"136") == 0 ||
                              strcmp(iins_type,"166") == 0 || 
                              strcmp(iins_type,"266") == 0 )
                          {
                              $OPEN ins33_cur USING $ipolicy;
                              for(;;)
                              {
puts("iii");
                              $FETCH ins33_cur
                                INTO $iins_type, $iinsurant, $iins_scope,$icareer,$mins_premium,$mdiscount,
                                     $mcomm_33_old,$magent_33_old;
puts("jjj");
                                  if (SQLCODE == SQLNOTFOUND) break;

                                  if (ipaid_base[0] == 'B')
                                  {
                                      mcomm_33   = (long)((float)(mins_premium+mdiscount)*pcommission/100.0+0.5);
                                      magent_33  = (long)((float)(mins_premium+mdiscount)*pagent/100.0+0.5);
                                  }
                                  else
                                  {
                                      mcomm_33   = (long)((float)mins_premium*pcommission/100.0+0.5);
                                      magent_33  = (long)((float)mins_premium*pagent/100.0+0.5);
                                  }
                                  mcomm_33_diff  = mcomm_33  - mcomm_33_old;
                                  magent_33_diff = magent_33 - magent_33_old;

puts("kkk");
                                  $EXECUTE ins_pa
                                     USING $ipolicy,$iins_type,$iinsurant,$iins_scope,$icareer,
                                           $mcomm_33_diff,$magent_33_diff;
puts("lll");

                                  mcomm_new  += mcomm_33;
                                  magent_new += magent_33;
                              }
                              $CLOSE ins33_cur;
                          }
                          else
                          {
                              if (ipaid_base[0] == 'B')
                              {
                                  mcomm_new   = (long)((float)(mins_premium+mdiscount)*pcommission/100.0+0.5);
                                  magent_new  = (long)((float)(mins_premium+mdiscount)*pagent/100.0+0.5);
                              }
                              else
                              {
                                  mcomm_new   = (long)((float)mins_premium*pcommission/100.0+0.5);
                                  magent_new  = (long)((float)mins_premium*pagent/100.0+0.5);
                              }
                          }
                          mcomm_diff  = mcomm_new  - mcommission;
                          magent_diff = magent_new - magent;
                      }
               }

             printf("begin iendorse \n");
             printf("mdeal_diff[%ld]\n",mdeal_diff);
             /* ����� */
             sprintf(stmt,
             " SELECT a.iendorse,b.iins_type,b.medrins_prem,b.medr_discount,            \
                      b.medr_commission,b.medr_agent,a.icar_type, c.qply_period         \
                 FROM %s:edr_relation a,%s:edr_ins_type b, %s:endorsement c             \
                WHERE a.iendorse = b.iendorse                                           \
                  AND a.iendorse = c.iendorse                                           \
                  AND a.dendorse  < ?                                                   \
                  AND b.iins_type = ?                                                   \
                  AND a.dedr_close IS NOT NULL                                          \
                  AND ((b.medr_commission != 0) OR (b.medr_agent != 0))                 \
                  AND a.ipolicy = ? ",sFull,sFull,sFull);

             $PREPARE main_id_edr FROM $stmt;
             $DECLARE main_cur_edr CURSOR FOR main_id_edr;
             $OPEN  main_cur_edr USING $dwritten,$iins_type,$ipolicy;
             for(;;)
             {
             $FETCH main_cur_edr
               INTO $iendorse,$iins_type,$mins_premium,$mdiscount,
                    $mcommission,$magent,$icar_type, $qply_period;
                 if (SQLCODE == SQLNOTFOUND) break;

                 rc = get_iins_cat( icar_type, 1, qply_period, iins_cat, iyear, v_sMsg );
                 if( rc != M_CM_OK)
                 {
                      sprintf(sErrmsg,"�O��[%s]����[%s],�ӫO���[%d],�I�O�~�����s�b",ipolicy,icar_type,qply_period);
                      printf("sErrmsg[%s]\n",sErrmsg);
                      goto errexit;
                 }
                 strcpy( iins_type, trim( iins_type));
                 mcomm_33 = magent_33 = 0;
                 mcomm_new = magent_new = 0;
                 mcomm_33_diff = magent_33_diff = 0;
                 mcomm_33_old = magent_33_old = 0;
                 dMod = 0;

               $EXECUTE get_new_com
                   INTO $pcommission_new,$pagent_new,$mcommission_new,$pbusiness_new,$drate_ym,
                          $pdiscount_new, $pextra_charge_new
                  USING $ipolicy,$iins_type;
                  if (SQLCODE == SQLNOTFOUND)
                  {
                      sprintf(sErrmsg,"[%s]�̷s�O��[%s]�I�ؤ��s�b",ipolicy,iins_type);
                      printf("sErrmsg[%s]\n",sErrmsg);
                      goto errexit;
                  }
                  if (fcard_class[0] == '1')
                  {
                      if ((mcommission_new == 0) || (mcommission_new == mservice))
                      {
                           same = 1;
                      }

                      /* car9803311���q���ץ��N�I�Y�O�¶O�v,�ӱj���I�H�¤���O��I,����� */
                      if( strlen(trim( irelative_ply)) !=0 &&
                          (strncmp( trim(ibroker), "JH",2) == 0 ||
                           strncmp( trim(ibroker), "BD",2) == 0 )
                        )
                      {
                          sprintf( stmt, "SELECT max(drate_ym)"
                                         "  FROM %s:ply_ins_type"
                                         " WHERE ipolicy = ?", sFull);

                          $PREPARE prep2 FROM $stmt;
                          $EXECUTE prep2 INTO $drate_ym_rel USING $irelative_ply;

                          if (risnull(SQLCHAR, drate_ym_rel) != 1) /* �����N�I�O�v�N�� */
                          {
                              $SELECT case when drate >= date('04/01/2009') then '1' else '0' end
                                 INTO $f980401
                                 FROM ca_rate_date
                                WHERE icode  = $drate_ym_rel
                                 AND itable = 'cm_extra_charge';

                              if (SQLCODE == SQLNOTFOUND)
                              {
                                 sprintf(sErrmsg,"�O�v�N��[%s],���[�O�βv�O�v�ͮĤ�䤣��,�Ь��ӫO����car120�]�w", drate_ym);
                                 printf("sErrmsg[%s]\n",sErrmsg);
                                 goto errexit;
                              }
                              /* ���N�I���¶O�v,����� */
                              if( f980401[0] == '0')
                                  continue;
                          }
                      }

                  }
                  else
                  {   printf("pagent_new[%f],pagent[%f]\n",pagent_new,pagent);
                      if ((pcommission_new == pcommission) && (pagent_new == pagent))
                      {
                           same = 1;
                      }
                      $SELECT case when drate >= date('04/01/2009') then '1' else '0' end
                         INTO $f980401
                         FROM ca_rate_date
                        WHERE icode  = $drate_ym
                                       AND itable = 'cm_extra_charge';

                      if (SQLCODE == SQLNOTFOUND)
                      {
                         sprintf(sErrmsg,"�O�v�N��[%s],���[�O�βv�O�v�ͮĤ�䤣��,�Ь��ӫO����car120�]�w", drate_ym);
                         printf("sErrmsg[%s]\n",sErrmsg);
                         goto errexit;
                      }

                      /* �O�v�ۥѤƤ��� */
                      if( f980401[0] == '1')
                      {
                          printf("�̷s�O��pdiscount_new[%f]\n", pdiscount_new);
                          if( pdiscount_new != 0) /* �O�v�ۥѤƤ��ᤣ�i������ */
                          {
                             sprintf(sErrmsg,"�O�渹[%s],�O�v�ۥѤƤ��ᤣ�i������", ipolicy);
                             printf("sErrmsg[%s]\n",sErrmsg);
                             goto errexit;
                          }

                          sprintf( sCCC1 ,"%f", (double)(pdiscount_new + pcommission + pagent));
                          sprintf( sCCC2 ,"%f", (double)( (pextra_charge_new - pbusiness_new) * 100.0));

                          rCCC1 = atof( sCCC1);
                          rCCC2 = atof( sCCC2);

                          printf("��+�N+�u[%-3.20f]\n", rCCC1);
                          printf("��-�~   [%-3.20f]\n", rCCC2);

                          if ( rCCC1 > rCCC2 )
                          {
                             sprintf(sErrmsg,"�O�渹[%s],(�����v+�~�޶O�βv) ���i�j�� ���[�O�βv,�Ь��ӫO��", ipolicy);
                             printf("sErrmsg[%s]\n",sErrmsg);
                             goto errexit;
                          }
                      }
                  }

                  if (fcard_class[0] == '1')
                  {
                      printf("mservice[%ld],mins_premium[%ld]\n",mservice,mins_premium);
                      /*
                      if ((mins_premium < 0) || (mcommission < 0))
                      {
                          mservice_tmp = mservice * (-1);
                      }
                      else
                      {
                          mservice_tmp = mservice;
                      }
                      */
                      mdeal_diff = mdeal_diff  - mcommission;
                      printf("iendorse[%s],mcommission[%ld],mdeal_diff[%ld]\n",iendorse,mcommission,mdeal_diff);
                  }
                  else
                  {
                      if (strcmp(iins_type,"33") == 0 ||
                          strcmp(iins_type,"35") == 0 ||
                          strcmp(iins_type,"48") == 0 ||
                          strcmp(iins_type,"56") == 0 ||
                          strcmp(iins_type,"136") == 0 ||
                          strcmp(iins_type,"166") == 0 ||
                          strcmp(iins_type,"266") == 0)
                      {
                          $OPEN ins33_edr_cur USING $iendorse;
                          for(;;)
                          {
                          $FETCH ins33_edr_cur
                            INTO $iins_type,$iinsurant,$iins_scope,$icareer,$mins_premium,$mdiscount,
                                 $mcomm_33_old,$magent_33_old;
                              if (SQLCODE == SQLNOTFOUND) break;

                              if (mins_premium < 0)
                                  dMod = -0.5;
                              else
                                  dMod = 0.5;
                                  
                              if (ipaid_base[0] == 'B')
                              {
                                  mcomm_33   = (long)((float)(mins_premium+mdiscount)*pcommission/100.0+dMod);
                                  magent_33  = (long)((float)(mins_premium+mdiscount)*pagent/100.0+dMod);
                              }
                              else
                              {
                                  mcomm_33   = (long)((float)mins_premium*pcommission/100.0+dMod);
                                  magent_33  = (long)((float)mins_premium*pagent/100.0+dMod);
                              }
                              mcomm_33_diff  = mcomm_33  - mcomm_33_old;
                              magent_33_diff = magent_33 - magent_33_old;

                              $EXECUTE up_pa
                                 USING $mcomm_33_diff,$magent_33_diff,$ipolicy,$iins_type,$iinsurant,$iins_scope,$icareer;
                                    if (sqlca.sqlerrd[2] == 0)
                                    {
                                        $EXECUTE ins_pa 
                                           USING $ipolicy,$iins_type,$iinsurant,$iins_scope,$icareer,
                                                 $mcomm_33,$magent_33;
                                    }
                              mcomm_new  += mcomm_33;
                              magent_new += magent_33;
                          }
                          $CLOSE ins33_edr_cur;
                      }
                      else
                      {
                          if (mins_premium < 0)
                              dMod = -0.5;
                          else
                              dMod = 0.5;

                          if (ipaid_base[0] == 'B')
                          {
                              mcomm_new   = (long)((float)(mins_premium+mdiscount)*pcommission/100.0+dMod);
                              magent_new  = (long)((float)(mins_premium+mdiscount)*pagent/100.0+dMod);
                          }
                          else
                          {
                              mcomm_new   = (long)((float)mins_premium*pcommission/100.0+dMod);
                              magent_new  = (long)((float)mins_premium*pagent/100.0+dMod);
                          }
                      }
                      mcomm_diff  += mcomm_new  - mcommission;
                      magent_diff += magent_new - magent;
                  }
             }
             $CLOSE  main_cur_edr;
             $FREE   main_cur_edr;

             printf("mcomm_diff_old[%ld],mcomm_diff[%ld]\n",mcomm_diff_old,mcomm_diff);
             printf("magent_diff_old[%ld],magent_diff[%ld]\n",magent_diff_old,magent_diff);
             printf("mdeal_diff_old[%ld],mdeal_diff[%ld]\n",mdeal_diff_old,mdeal_diff);
             if ((mcomm_diff_old  != mcomm_diff) || (magent_diff_old != magent_diff) || (mdeal_diff_old  != mdeal_diff))
             {
                  puts("debug 1");
                  strcpy(fstatus,"F");
                  if (fstatus[0] == 'F')
                  {
                      $EXECUTE up_bal
                         USING $fstatus,$dwritten,' ',' ',$ipolicy,$processid;
                       puts("debug 2");
                       continue;
                  }
                  puts("debug 3");
                  break;
                  puts("debug 4");
             }
             printf("same[%d]\n", same);
             if (same == 1)
             {   
                  puts("debug 5");
                  same = 0;
                  strcpy(fstatus,"F");
                  if (fstatus[0] == 'F')
                  {
                      $EXECUTE up_bal
                         USING $fstatus,$dwritten,' ',' ',$ipolicy,$processid;
                       puts("debug 6");
                       continue;
                  }
                  puts("debug 7");
                  break;
                  puts("debug 8");
             }
             puts("debug 9");

            sprintf (stmt, "SELECT mdmg_commi+mlia_commi, ibroker, ileader, mbusiness "
                           "  FROM %s:ply_relation WHERE ipolicy=?", sFull);
            printf ("[%s]\n", stmt);

            $PREPARE prep3 FROM $stmt;
            $EXECUTE prep3 INTO $lMcommission, $ibroker, $ileader, $mbusiness USING $ipolicy;

            lMcommission = lMcommission + mcomm_diff + magent_diff + mdeal_diff;

            if( strncmp( icomm_obj, "10000", 5) == 0 && lMcommission != 0)
            {
                strcpy(fstatus, "F");
                strcpy( temp, "");
                sprintf( sErrMsg, "�O�渹[%s]�����, �]���G���I���~�Ȥ��i�H������,����������N�z�O���", ipolicy);
                $EXECUTE up_bal
                   USING $fstatus,$dwritten,$temp, $sErrMsg, $ipolicy, $processid;
                continue;
            }

            /* car9811303 �j���I99.3.1�O�v */
            if (fcard_class[0] == '1')
            {
                strcpy( iabn_type, "");

                sprintf (stmt, "SELECT drate_ym"
                               "  FROM %s:ply_ins_type WHERE ipolicy=? AND iins_type = '21'", sFull);
                printf ("[%s]\n", stmt);

                $PREPARE prep4 FROM $stmt;
                $EXECUTE prep4 INTO $comp_frate USING $ipolicy;

                rc = chk_commi_business( 1, iabn_type, comp_frate, lMcommission, mbusiness, v_sMsg);
       
                if( rc != M_CM_OK)
                {    strcpy(fstatus, "F");
                     strcpy( temp, "");
                     sprintf( sErrMsg, "�O�渹[%s]�����, �]���G%s", ipolicy, v_sMsg);
                     $EXECUTE up_bal
                        USING $fstatus,$dwritten,$temp, $sErrMsg, $ipolicy, $processid;
                     continue;
                }
            }
         }
         $CLOSE pro_cur;
         strcpy(fstatus,"S");

          /*  �妸�X��  */
          sprintf(stmt,
         " SELECT a.fcard_class, a.iofficer, a.ibroker, a.ibatch_no, a.fedr_class, a.ibig_office,  \
                  a.dply_begin, a.dply_end \
             FROM %s:ply_relation a \
            WHERE ipolicy = ? ",sFull);
         $PREPARE ply_id FROM $stmt;
         $EXECUTE ply_id 
             INTO $ori_fcard_class, $ori_iofficer, $ori_ibroker, $ibatch_no, $ori_fedr_class, $ibus_location, $dply_begin, $dply_end
            USING $ipolicy;
            if (SQLCODE == SQLNOTFOUND)
            {
               sprintf(sErrmsg,"�L�k���[%s]�̷s�O�����ɸ��",ipolicy);
               printf("sErrmsg[%s]\n",sErrmsg);
               goto errexit;
            }
            /* get ���s�X���O*/
            strncpy(sIbilling, ipolicy+CAR_POL_CHR_POS-1, 2);
            sIbilling[2]='\0';
            printf("sIbilling[%s]\n",sIbilling);
              /* get ����k�ݤ�����c & �����q*/
            strncpy(sIbranchIcomp, ipolicy, CA_POL_BRH_NUM - 1);
            sIbranchIcomp[CA_POL_BRH_NUM - 1] = '\0';
            printf("sIbranchIcomp[%s]\n",sIbranchIcomp);
    
            fRtnCode = cm_get_unit_in("", sIbranchIcomp, userid,
                                          sIbranchIcomp, "C1", sIcomp_in, sIbranch_in);
            if (fRtnCode != M_CM_OK)
            {
               sprintf(sErrmsg,"�L�k���o[%s]���N��",sIbranchIcomp);
               printf("sErrmsg[%s]\n",sErrmsg);
               goto errexit;
            }
            /* 00 40 70 */
            printf("sIcomp_in[%s]\n",sIcomp_in);
            /* 00 20 30 40 ...87 */
            printf("sIbranch_in[%s]\n",sIbranch_in);

            strcpy(sIcomp_in_short, get_upcomp(sIcomp_in, USE_BRANCH_ID, USE_SHORT_BRANCH_ID));
            stepi = cm_get_serial_num("C4", sIbilling,
                                            sIcomp_in_short, sIbranch_in,
                                            cm_cdate_str_100(cm_today()),
                                            temp);
            if (stepi != 0)
            {
                 if (stepi == 1 || stepi == 2)
                   stepi = M_CM_DB_NOTOPEN;
                 else if (stepi == 3)
                   stepi = M_CMN_NAUTONUMBERING;

                 sprintf(sErrmsg,"�۰ʵ����ɦ��~[%ld]",stepi);
                 printf("sErrmsg[%s]\n",sErrmsg);
                 goto errexit;
            }

            policy_1[0]='\0';
            policy_2[0]='\0';
    
            strncpy(policy_1, ipolicy, CAR_POLICY_LEN);
            policy_1[CAR_POLICY_LEN]=0;
    
            printf("END ipolicy split \n");
    
            if (strlen(ipolicy)>CAR_POLICY_LEN)
                strcpy(policy_2,&ipolicy[CAR_POLICY_LEN]);
            else
                strcpy(policy_2," ");
    
            printf("policy_1[%s]\n",policy_1);
            printf("policy_2[%s]\n",policy_2);
            printf("ibatch_no[%d]\n",ibatch_no);
  
            strcpy(batchno,itoa(ibatch_no));
            printf("batchno[%s]\n",batchno);
            ao_chk_charge(sDB, '3', policy_1, policy_2, batchno,
                          payresult, paystatus, paydate, notedate);
    
            printf("ipolicy[%s],payresult[%s]\n",ipolicy,payresult);
    
            if (payresult[0] == 'R')
            {
                strcpy(fpay," ");
            }
            else
            {
                strcpy(fpay,"1");
            }
    
            /**** START �ƥ� ****/
            rc = bk_401(sDB, ipolicy, temp);
            if ( rc != M_CM_OK)
            {
                sprintf(sErrmsg,"�ƥ��O��[%s]��Ʀ��~",ipolicy);
                printf("sErrmsg[%s]\n",sErrmsg);
                goto errexit;
            }
            /**** END   �ƥ� ****/
           mdmg_commi = mdmg_agent = 0;
           mlia_commi = mlia_agent = 0;

           strcpy(sDBa,get_db(ipolicy));
           strcpy(sFulla,trim(get_full_dbname(sDBa)));

          sprintf(stmt,
         " SELECT fcard_class,icar_type, qply_period       \
             FROM %s:ori_ply_relation                      \
            WHERE ipolicy = ? ",sFulla);
         $PREPARE oriply_ida FROM $stmt;
         $EXECUTE oriply_ida
             INTO $fcard_class,$icar_type, $qply_period
            USING $ipolicy;
               if (SQLCODE == SQLNOTFOUND)
               {
                   sprintf(sErrmsg,"�L�k���[%s]��l�O����",ipolicy);
                   printf("sErrmsg[%s]\n",sErrmsg);
                   goto errexit;
               }

            rc = get_iins_cat( icar_type, 1, qply_period, iins_cat, iyear, v_sMsg );
            if( rc != M_CM_OK)
            {
                 sprintf(sErrmsg,"�O��[%s]����[%s],�ӫO���[%d],[%s]",ipolicy,icar_type,qply_period,v_sMsg);
                 printf("sErrmsg[%s]\n",sErrmsg);
                 goto errexit;
            }

           $OPEN pro_cur USING $processid,$ipolicy ;
           for(;;)
           {
           $FETCH pro_cur
             INTO $ibroker,$dpolicy_bgn,$dpolicy_end,$iins_type,
                  $pcommission,$pagent,$mservice,$mcomm_diff_old,$magent_diff_old,$mdeal_diff_old,
                  $deffect, $iroute, $irate_type, $iroute_comm;
               if (SQLCODE == SQLNOTFOUND) break;
               strcpy( iins_type, trim( iins_type));
               /* 1000311003 �q��2 */
               if( fstart[0] == 'Y')
               {
                   rc = cm_get_insure_comm(iroute, irate_type, iroute_comm, insure_type, iins_cat, iins_type, iyear, &o_qrec, &o_stcomm, deffect);
                   if (rc != M_CM_OK)
                   {
                       strcpy(stmp, cm_get_errmsg( rc));
                       sprintf(sErrMsg,"�O�渹[%s],��渹[%s],�q���N��[%s],�O�v�O[%s],�~�ȱ���[%s],�I��[%s],�~��[%s],�ͮĤ�[%s],���~�T��:[%s][%d]\n",
                                        ipolicy, iendorse, iroute, irate_type, iroute_comm, iins_type, iyear, deffect, stmp, rc );
                       printf("sErrMsg[%s]\n",sErrMsg);
                       goto errexit;
                   }
                   else if( o_qrec == 0)
                   {
                       if (iins_cat[0] == 'C' || iins_cat[0] == 'X' || iins_cat[0] == 'Z')
                       {
                           memset(&o_stcomm, 0x00, sizeof(o_stcomm));
                           o_qrec = 0;
                           strcpy( iins_cat, "C");
                           strcpy( iyear, "0");
                           rc = cm_get_insure_comm(iroute, irate_type, iroute_comm, insure_type, iins_cat, iins_type, iyear, &o_qrec, &o_stcomm, deffect);

                           if (rc != M_CM_OK )
                           {
                               strcpy(stmp, cm_get_errmsg( rc));
                               sprintf(sErrmsg,"�O�渹[%s],�q���N��[%s],�O�v�O[%s],�~�ȱ���[%s],�I��[%s],�~��[%s],�ͮĤ�[%s],���~�T��:[%s][%d]\n",
                                                ipolicy, iroute, irate_type, iroute_comm, iins_type, iyear, deffect, stmp,rc );
                               printf("sErrmsg[%s]\n",sErrmsg);
                               goto errexit;
                           }
                       }
                       if( o_qrec == 0)
                       {
                           sprintf(sErrmsg,"�O�渹[%s],�q���N��[%s],�O�v�O[%s],�~�ȱ���[%s],�I��[%s],�~��[%s],�ͮĤ�[%s],�����N�z�v�ɸ�Ƨ䤣��\n",
                                            ipolicy, iroute, irate_type, iroute_comm, iins_type, iyear, deffect );
                           printf("sErrmsg[%s]\n",sErrmsg);
                           goto errexit;
                       }
                   }

                   /* �u����ipaid_base, ��L��ƨ� ca_comm_balance */
                   strcpy( ipaid_base, o_stcomm.ipaid_base);
               }
               else
               {
                   $EXECUTE comid
                       INTO $ipaid_base
                      USING $iins_cat,$ibroker,$iins_type,$iyear;
                      if (SQLCODE == SQLNOTFOUND)
                      {
                          sprintf(sErrmsg,"[%s]�g���H[%s]�|������",ibroker,iins_type);
                          printf("sErrmsg[%s]\n",sErrmsg);
                          goto errexit;
                      }
               }
               if (fcard_class[0] == '1')
               {
                   mcomm_diff_old = mdeal_diff_old;
               }

               if (strcmp(iins_type,"33") == 0 ||
                   strcmp(iins_type,"35") == 0 ||
                   strcmp(iins_type,"48") == 0 ||
                   strcmp(iins_type,"56") == 0 ||
                   strcmp(iins_type,"136") == 0 ||
                   strcmp(iins_type,"166") == 0 ||
                   strcmp(iins_type,"266") == 0 )
               {
                   sprintf(stmt,
                   " INSERT INTO %s:ca_pa_edr                                 \
                     (iendorse, iins_type, iinsurant, iedr_type, ninsurant, dbirth,      \
                      ainsurant, iins_scope, icareer, medrins_amt, fcal_way,  \
                      pcal, medrins_prem, medrpure_prem, pcommission,         \
                      medr_commission, pagent, medr_agent, pdiscount,         \
                      medr_discount, dendorse, napplicant, relation_appl,     \
                      nbeneficiary,relation_bene,medr_daily_pay,medr_mr_ins_prem,medr_mr_pure_prem,tbenef, abenef_zip, abenef)   \
                     SELECT '%s', a.iins_type, a.iinsurant, '%s', a.ninsurant, a.dbirth,   \
                            a.ainsurant, a.iins_scope, a.icareer, 0, 'M',     \
                            100, 0, 0, %.2f - a.pcommission,                  \
                            b.mcommission, %.2f - a.pagent, b.magent, 0,      \
                            0, %ld, a.napplicant, a.relation_appl,            \
                            a.nbeneficiary, a.relation_bene,0,0,0,a.tbenef, a.abenef_zip, a.abenef  \
                       FROM %s:ca_pa_ply a,pa_temp b                          \
                      WHERE a.ipolicy    = '%s'                               \
                        AND a.ipolicy    = b.ipolicy                          \
                        AND a.iins_type  = b.iins_type                        \
                        AND a.iinsurant  = b.iinsurant                        \
                        AND a.iins_scope = b.iins_scope                       \
                        AND a.icareer    = b.icareer ",
                        sFull ,temp ,iedr_type ,pcommission ,pagent ,dwritten ,sFull , ipolicy);
                      printf("stmt[%s]\n",stmt);
                   $PREPARE caedr FROM $stmt;
                   $EXECUTE caedr;

                   sprintf(stmt,
                   " UPDATE %s:ca_pa_ply                                                     \
                        SET (pcommission, mcommission, pagent, magent, iendorse,             \
                             dendorse, dedr_begin, dedr_end)                                 \
                          = ((SELECT %.2f, %s:ca_pa_ply.mcommission + pa_temp.mcommission,   \
                                     %.2f, %s:ca_pa_ply.magent      + pa_temp.magent, '%s',  \
                                     %ld, %ld, %ld                                           \
                                FROM pa_temp                                                 \
                               WHERE %s:ca_pa_ply.ipolicy    = pa_temp.ipolicy               \
                                 AND %s:ca_pa_ply.iins_type  = pa_temp.iins_type             \
                                 AND %s:ca_pa_ply.iinsurant  = pa_temp.iinsurant             \
                                 AND %s:ca_pa_ply.iins_scope = pa_temp.iins_scope            \
                                 AND %s:ca_pa_ply.icareer    = pa_temp.icareer               \
                                 AND pa_temp.ipolicy = '%s'                                  \
                            ))                                                               \
                      WHERE EXISTS (SELECT *                                                 \
                                      FROM pa_temp                                           \
                                     WHERE %s:ca_pa_ply.ipolicy    = pa_temp.ipolicy         \
                                       AND %s:ca_pa_ply.iins_type  = pa_temp.iins_type       \
                                       AND %s:ca_pa_ply.iinsurant  = pa_temp.iinsurant       \
                                       AND %s:ca_pa_ply.iins_scope = pa_temp.iins_scope      \
                                       AND %s:ca_pa_ply.icareer    = pa_temp.icareer         \
                                       AND pa_temp.ipolicy = '%s')                           \
                        AND ipolicy = '%s' ",
                      sFull,pcommission,sFull,pagent,sFull,temp,dwritten,dply_begin,dply_end,
                      sFull,sFull,sFull,sFull,sFull,ipolicy,sFull,sFull,sFull,sFull,sFull,ipolicy,ipolicy);
                      printf("stmt[%s]\n",stmt);
                   $PREPARE up_pa_edr FROM $stmt;
                   $EXECUTE up_pa_edr;
               }

                sprintf(stmt,
                "INSERT INTO %s:edr_ins_type                                         \
                 (iendorse, iins_type, iedr_type, medrinj_cover,                     \
                  medrdea_cover, medrdmg_cover, mdeduct, medrins_prem,               \
                  medrpure_prem, fcal_way, pcal, qserial, pcommission,               \
                  medr_commission, pagent, medr_agent, pdiscount, medr_discount,     \
                  drate_ym, medr_prem, iproduct, ipaid_base,qcount,provision, psex_age, \
                  mdrunk_prem, mdrunk_pure_prem, mviolate_prem,mviolate_pure_prem)   \
                  SELECT '%s', iins_type, '%s', 0,                                   \
                          0, 0, 0, 0,                                                \
                          0, 'M', 100, qserial, %.2f - pcommission, %ld,             \
                          %.2f - pagent, %ld, 0, 0,                                  \
                          drate_ym, 0, iproduct, '%s', 0, provision, psex_age, 0,0 , 0,0   \
                    FROM %s:ply_ins_type                                             \
                   WHERE ipolicy = '%s'                                              \
                     AND iins_type = '%s' ",                                         \
                     sFull, temp, iedr_type, pcommission, mcomm_diff_old,            \
                     pagent, magent_diff_old, ipaid_base, sFull, ipolicy, iins_type);
                   printf("stmt[%s]\n",stmt);
                $PREPARE eins2 FROM $stmt;
                $EXECUTE eins2 ;

                sprintf(stmt,
                " UPDATE %s:ply_ins_type                                                 \
                     SET (iendorse,dendorse,dedr_begin,dedr_end,                         \
                          pcommission,mcommission,                                       \
                          pagent     ,magent     ,                                       \
                          ipaid_base)                                                    \
                       = (?,?,?,?,?,mcommission + ?,?,magent + ?,?)                      \
                   WHERE ipolicy = ?                                                     \
                     AND iins_type = ? ",sFull);
                  printf("stmt[%s]\n",stmt);
                $PREPARE pins2 FROM $stmt;
                $EXECUTE pins2
                   USING $temp,$dwritten,$dply_begin,$dply_end,
                         $pcommission,$mcomm_diff_old,$pagent,$magent_diff_old,$ipaid_base,
                         $ipolicy,$iins_type;
                   if (sqlca.sqlerrd[2] == 0)
                   {
                       sprintf(sErrmsg,"�L�k��s�̷s�O��[%s][%s]�I�ظ��",ipolicy,iins_type);
                       printf("sErrmsg[%s]\n",sErrmsg);
                       goto errexit;
                   }
                $EXECUTE surid
                    INTO $fins_grp
                   USING $iins_type;
                   if (SQLCODE == SQLNOTFOUND)
                   {
                       sprintf(sErrmsg,"�L�k�P�_[%s]�O��[%s]�I�ؤ��I��",ipolicy,iins_type);
                       printf("sErrmsg[%s]\n",sErrmsg);
                       goto errexit;
                   }
                 printf("fins_grp[%s]\n",fins_grp);
                 switch(fins_grp[0])
                 {
                   case '1':
                            mdmg_commi += mcomm_diff_old;
                            mdmg_agent += magent_diff_old;
                            break;
                   case '2':
                            mlia_commi += mcomm_diff_old;
                            mlia_agent += magent_diff_old;
                            break;
                   case '3':
                            mlia_commi += mcomm_diff_old;
                            mlia_agent += magent_diff_old;
                            break;
                   default :
                            sprintf(sErrmsg,"[%s]�O��[%s]�I���I���P�_���~->�I��[%s]",ipolicy,iins_type,fins_grp);
                            printf("sErrmsg[%s]\n",sErrmsg);
                            goto errexit;
                            break;
                 }

                $EXECUTE up_bal_a
                   USING $fstatus,$dwritten,$temp,$ipolicy,$iins_type,$processid;
                      if (sqlca.sqlerrd[2] != 1)
                      {
                          sprintf(sErrmsg,"�󥿦��\���O���~[%s]�O��[%s]�I��",ipolicy,iins_type);
                          printf("sErrmsg[%s]\n",sErrmsg);
                          goto errexit;
                      }
           }
           $CLOSE pro_cur;

            sprintf(stmt,
            " INSERT INTO %s:edr_relation \
              (iendorse, fcard_class, ipolicy, icard, irelative_ply, irelative_edr, \
               fedr_class, fpay, ipay, iedr_field, dedr_begin, dedr_end,\
               ipro_year, ibrand, icar_type, medrdmg_agent, medrdmg_commi,  \
               medrdmg_prem, medrdmg_pure_prem, medrlia_agent, medrlia_commi, \
               medrlia_prem, medrlia_pure_prem, ibig_comp, ibig_branch, ibig_office,\
               ibig_sales, iresource, ibroker, iofficer, ileader, icorps, iedr_area,  \
               iedr_cashier, iedr_examiner, dedr_examine, dentry, dendorse, \
               fprint, itreaty, ibranch, iquota, icomp_in, ibranch_in, icomp_at,\
               ibranch_at, medr_ready, medr_stable, medr_compensate, medr_adjcom, \
               medr_research, medr_invest, medr_bus_rule, \
               medr_business, medr_capital, fcomp_class, fcomp_class_last, fdiscount, medrdmg_disc,   \
               medrlia_disc, iedr_return, icar_flag, terminate_rsn, qcount, \
               iofficer_prmt, iquota_prmt, ileader_prmt, irate_type, bzfrom, iroute_comm, icomm_obj, qprovision, isecond_hand, icard_main, qdrunk_driving, isign,\
               feply, feedr, aemail_eply,tmobile_eply,isign_edr,dsign_edr,fsign_status_edr,funder_chk_edr,iprog,qviolate)  \
              SELECT '%s', fcard_class, ipolicy, icard, irelative_ply, ' ', \
               '%s', '%s', ' ', ' ', dply_begin, dply_end,  \
               ipro_year, ibrand, icar_type, %ld, %ld,\
               0, 0, %ld, %ld,  \
               0, 0, ibig_comp, ibig_branch, ibig_office, \
               ibig_sales, iresource, ibroker, iofficer, ileader, icorps, iarea,  \
               '%s', '%s', %ld, %ld, %ld, \
                '1', itreaty, ibranch, iquota, icomp_in, ibranch_in, '%s',  \
                '%s', 0, 0, 0, 0, \
                0, 0, 0,  \
                0, 0, fcomp_class, fcomp_class_last, fdiscount, 0,\
                0, '2', icar_flag, '0', 0,  \
                iofficer_prmt, iquota_prmt, ileader_prmt, irate_type, bzfrom, iroute_comm, icomm_obj, qprovision, isecond_hand,icard_main, qdrunk_driving, isign,\
                feply, '0', aemail_eply, tmobile_eply,'system',today,40,'N','car419',qviolate  \
                FROM %s:ply_relation  \
               WHERE ipolicy = '%s' ",sFull, temp, "B", fpay, 
                                      mdmg_agent,mdmg_commi,mlia_agent,mlia_commi,
                                      userid, userid,
                                      dwritten, dwritten, dwritten,
                                      icomp_at, ibranch_at, sFull, ipolicy);
               printf("stmt[%s]\n",stmt);
             $PREPARE edr2 FROM $stmt;
             $EXECUTE edr2;

           /*1071105008_SC2_ �������Ȩ��z��(FS)�A�éw�ɦ۰ʤU���ɮ�*/
           strcpy(iroute_accept_edr," ");         
           if(strncmp(iroute,"I009",4)==0)
           {
               strcpy(temp, trim(temp));             
               sprintf(iroute_accept_edr, "CHB%s", temp);             
           }
           printf("-- trace iroute_accept_edr[%s]\n ", iroute_accept_edr); 
         
           sprintf(stmt,
           " INSERT INTO %s:endorsement                                                            \
             (iendorse, qply_period, dply_begin, dply_end, fassured, iassured,                     \
              iassured_ext, nassured, ilicense, fsex, fmarriage, nuser,                    \
              ibenef, nbenef, aassured, aassured_zip, itel, apayment, apayment_zip,                \
              iply_area, nbrand_abbr, ncar_abbr, fcar_note, qcylinder, iengine, ibody,             \
              itag, mcar_price, nequipment, flimit, pdmg_align, pbrg_align, plia_align,            \
              idmg_rate, pdmg_factor, ibrg_rate, pbrg_factor, qpt, fpt, psex_age, psex_age_damage, lia_class,       \
              plia_acc, dmg_acc_1st, dmg_acc_2nd, dmg_acc_3rd, pdmg_acc, fhuman, fcomp_24,         \
              payresult, iext_policy, qpro_month, mkilo_ply, mkilo_edr, irisk, irelative_ext,      \
              napplicant, dbirth, dissue, iextra_charge, gextra_charge, pextra_charge,             \
              iquery_num_damage, iquery_num, mequipment, survey_num, bound_num,        \
              abnormal_num, iapplicant, iroute, qlia_acc_sum, qdmg_acc_sum, \
              fapplicant,fsex_appl,dbirth_appl,itel_appl,ndeputy_appl,nrelation_appl,ndeputy_assured, \
              iassured_cntry, iapplicant_cntry, nassured_cntry, napplicant_cntry, \
              foccup, noccup, applicant_foccup, applicant_noccup, iroute_accept,tmobile_appl,aemail_appl, \
              dinstall, isequence, ainstall_zip, ainstall) \
              SELECT '%s', a.qply_period, a.dply_begin, a.dply_end,                                \
                     b.fassured, b.iassured, b.iassured_ext, b.nassured,                           \
                     b.ilicense, b.fsex, b.fmarriage, b.nuser,                           \
                     b.ibenef, b.nbenef, b.aassured, b.aassured_zip, b.itel,                       \
                     b.apayment, b.apayment_zip, b.iply_area, b.nbrand_abbr,                       \
                     b.ncar_abbr, b.fcar_note, b.qcylinder, b.iengine, b.ibody,                    \
                     b.itag, b.mcar_price, b.nequipment, b.flimit, b.pdmg_align,                   \
                     b.pbrg_align, b.plia_align, b.idmg_rate, b.pdmg_factor,                       \
                     b.ibrg_rate, b.pbrg_factor, b.qpt, b.fpt, b.psex_age, b.psex_age_damage,      \
                     b.lia_class, b.plia_acc, b.dmg_acc_1st, b.dmg_acc_2nd,                        \
                     b.dmg_acc_3rd, b.pdmg_acc, b.fhuman, b.fcomp_24,                              \
                     '%s', b.iext_policy, b.qpro_month, b.mkilo_ply, b.mkilo_edr, b.irisk, b.irelative_ext, \
                     b.napplicant, b.dbirth, b.dissue, b.iextra_charge, b.gextra_charge, b.pextra_charge,   \
                     b.iquery_num_damage, b.iquery_num, b.mequipment, b.survey_num, b.bound_num, \
                     b.abnormal_num, b.iapplicant, b.iroute, b.qlia_acc_sum, b.qdmg_acc_sum, \
                     b.fapplicant,b.fsex_appl,b.dbirth_appl,b.itel_appl,b.ndeputy_appl,b.nrelation_appl,b.ndeputy_assured, \
                     CASE WHEN b.iassured_cntry='' THEN '8' ELSE b.iassured_cntry END, \
                     CASE WHEN b.iapplicant_cntry='' THEN '8' ELSE b.iapplicant_cntry END, b.nassured_cntry, b.napplicant_cntry, \
                     b.foccup, b.noccup, b.applicant_foccup, b.applicant_noccup,'%s',b.tmobile_appl,b.aemail_appl, \
                     b.dinstall, b.isequence, b.ainstall_zip, b.ainstall \
                FROM %s:ply_relation a,%s:policy b                                                 \
               WHERE a.ipolicy = b.ipolicy                                                         \
                 AND a.ipolicy = '%s' ",sFull ,temp ,payresult, iroute_accept_edr,sFull ,sFull ,ipolicy);
               printf("stmt[%s]\n",stmt);
            $PREPARE endor2 FROM $stmt;
            $EXECUTE endor2;

            sprintf(stmt,
            "  UPDATE %s:ply_relation                                     \
                  SET (mdmg_agent,mdmg_commi,mlia_agent,mlia_commi)       \
                    = (mdmg_agent + %ld,mdmg_commi + %ld,                 \
                       mlia_agent + %ld,mlia_commi + %ld)                 \
                WHERE ipolicy = '%s' ",sFull,mdmg_agent,mdmg_commi,mlia_agent,mlia_commi,ipolicy);
               printf("stmt[%s]\n",stmt);
             $PREPARE up_new_ply FROM $stmt;
             $EXECUTE up_new_ply;

          strcpy( ipgid, "car419");
          rc = insert_cm_pre_receive_edr( temp, ipolicy, ipgid, v_sMsg);
          if( rc != M_CM_OK)
              goto errexit;

          /* �����妸�X�� */

         medr_commission = 0;
         medr_agent      = 0;

          /*  ������պ�Υ��鵲�����B�N�z�O��� */
         sprintf(stmt,
          " SELECT iins_type,medrins_prem,medr_discount,medr_commission,medr_agent \
              FROM %s:edr_ins_type                      \
             WHERE iendorse = ?                         \
               AND ((medr_commission != 0) OR (medr_agent != 0))   \
               AND medrins_prem != 0      \
               FOR UPDATE ",sFull);
          $PREPARE icvp_ins FROM $stmt;
          $DECLARE icvp_ins_cur CURSOR FOR icvp_ins;

         sprintf(stmt,
          " UPDATE %s:edr_ins_type                                            \
               SET (pcommission,medr_commission,pagent,medr_agent,ipaid_base) \
                 = (?,medr_commission+?,?,medr_agent+?,?)     \
             WHERE CURRENT OF icvp_ins_cur ",sFull);
          $PREPARE up_cvp_ins FROM $stmt;

         sprintf(stmt,
          " SELECT iins_type,iinsurant,iins_scope,icareer,medrins_prem,medr_discount,medr_commission,   \
                   medr_agent                   \
              FROM %s:ca_pa_edr                 \
             WHERE iendorse = ?                 \
               FOR UPDATE ",sFull);
          $PREPARE icvp_pa FROM $stmt;
          $DECLARE icvp_pa_cur CURSOR FOR icvp_pa;

         sprintf(stmt,
          " UPDATE %s:ca_pa_edr                     \
               SET (pcommission,medr_commission,    \
                    pagent,medr_agent)              \
                 = (?,medr_commission+?,?,medr_agent+?)  \
             WHERE CURRENT OF icvp_pa_cur ",sFull);
          $PREPARE up_cvp_pa FROM $stmt;

         sprintf(stmt,
          " UPDATE %s:edr_relation                  \
               SET (medrdmg_agent,medrdmg_commi,medrlia_agent,medrlia_commi)  \
                 = (medrdmg_agent+?,medrdmg_commi+?,medrlia_agent+?,medrlia_commi+?)    \
             WHERE CURRENT OF icvp_main_cur ",sFull);
          $PREPARE up_cvp_edr FROM $stmt;

         sprintf(stmt,
          " UPDATE %s:ca_pa_ply                               \
               SET (pcommission,mcommission,pagent,magent)    \
                 = (?,mcommission+?,?,magent+?)               \
             WHERE ipolicy = ?                                \
               AND iins_type = ?                              \
               AND iinsurant = ?                              \
               AND iins_scope = ?                             \
               AND icareer = ? ",sFull);
          $PREPARE up_cvp_plyins FROM $stmt;

         sprintf(stmt,
          " UPDATE %s:ply_ins_type                                       \
               SET (pcommission,mcommission,pagent,magent,ipaid_base)    \
                 = (?,mcommission+?,?,magent+?,?)                        \
             WHERE ipolicy = ?                                           \
               AND iins_type = ? ",sFull);
          $PREPARE up_cvp_instype FROM $stmt;

         sprintf(stmt,
          "  UPDATE %s:ply_relation                                     \
                SET (mdmg_agent,mdmg_commi,mlia_agent,mlia_commi)       \
                  = (mdmg_agent + ?,mdmg_commi + ?,                     \
                     mlia_agent + ?,mlia_commi + ?)                     \
              WHERE ipolicy = ? ",sFull);
           $PREPARE up_cvp_ply1 FROM $stmt;

         sprintf(stmt,
          " SELECT a.fcard_class,a.iendorse,a.ipolicy,a.iendorse[6,8],a.ipolicy,a.icar_type   \
              FROM %s:edr_relation a                                        \
             WHERE ((a.iendorse[6,8] = 'CVP') OR (a.dedr_close IS NULL))    \
               AND a.iendorse[6,8] != 'V9A'                                 \
               AND a.ipolicy = ?                                            \
               AND a.iendorse != ?                                          \
               FOR UPDATE ",sFull);
          $PREPARE icvp_main FROM $stmt;
          $DECLARE icvp_main_cur CURSOR FOR icvp_main;
          $OPEN icvp_main_cur USING $ipolicy,$temp;
          for(;;)
          {
          $FETCH icvp_main_cur INTO $fcard_class,$iendorse,$ipolicy,$iendor68,$ipolicy,$icar_type;
          if (SQLCODE == SQLNOTFOUND) break;
 
             sprintf(stmt,
              " SELECT qply_period        \
                  FROM %s:endorsement     \
                 WHERE iendorse = ? ",sFull);
              $PREPARE get_per FROM $stmt;
              $EXECUTE get_per 
                  INTO $qply_period
                 USING $iendorse;
              if (SQLCODE == SQLNOTFOUND)
              {
                 qply_period = 12;
              } 

             mdmg_commi = mdmg_agent = 0;
             mlia_commi = mlia_agent = 0;
            
             rc = get_iins_cat( icar_type, 1, qply_period, iins_cat, iyear, v_sMsg );
             if( rc != M_CM_OK)
             {
                  sprintf(sErrmsg,"�O��[%s]����[%s],�ӫO���[%d],�I�O�~�����s�b",ipolicy,icar_type,qply_period);
                  printf("sErrmsg[%s]\n",sErrmsg);
                  goto errexit;
             }

             $OPEN icvp_ins_cur USING $iendorse;
             for(;;)
             {
             $FETCH icvp_ins_cur INTO $iins_type,$mins_premium,$mdiscount,$medr_commission,
                                      $medr_agent;
              if (SQLCODE == SQLNOTFOUND) break;

                mcomm_33 = magent_33 = 0;
                mcomm_new = magent_new = 0;
                strcpy( iins_type, trim( iins_type));
                /* 1000311003 �q��2 */
                if( fstart[0] == 'Y')
                {
                    rc = cm_get_insure_comm(iroute, irate_type, iroute_comm, insure_type, iins_cat, iins_type, iyear, &o_qrec, &o_stcomm, deffect);
                    if (rc != M_CM_OK||o_qrec==0)
                    {
                        strcpy(stmp, cm_get_errmsg( rc));
                        sprintf(sErrMsg,"�O�渹[%s],��渹[%s],�q���N��[%s],�O�v�O[%s],�~�ȱ���[%s],�I��[%s],�~��[%s],�ͮĤ�[%s],���~�T��:[%s][%d]\n",
                                         ipolicy, iendorse, iroute, irate_type, iroute_comm, iins_type, iyear, deffect, stmp, rc );
                        printf("sErrMsg[%s]\n",sErrMsg);
                        goto errexit;
                    }
                    pagent = o_stcomm.pagent*100;
                    pcommission = o_stcomm.pcommiss*100;
                    mservice = o_stcomm.mservice;
                    strcpy( ipaid_base, o_stcomm.ipaid_base);
                }
                else
                {
     
                    $EXECUTE comid_c
                         INTO $pagent,$pcommission,$mservice,$ipaid_base
                        USING $ibroker,$iins_type,$iins_cat,$iyear;
                     if (SQLCODE == SQLNOTFOUND)
                     {               
                         $EXECUTE comid_a
                             INTO $pagent,$pcommission,$mservice,$ipaid_base
                            USING $ibroker,$iins_type,$iyear;
                            if (SQLCODE == SQLNOTFOUND)
                            {
                                sprintf(sErrmsg,"[%s]�g���H[%s]�|������",ibroker,iins_type);
                                printf("sErrmsg[%s]\n",sErrmsg);
                                goto errexit;
                            }
                     }
                  }

                  if (fcard_class[0] == '1')
                  {

                      if (mins_premium < 0)
                          mservice *= -1;

                      mcomm_new = mservice - medr_commission;
                  }
                  else
                  {
                      if (strcmp(iins_type,"33") == 0 ||
                          strcmp(iins_type,"35") == 0 ||
                          strcmp(iins_type,"48") == 0 ||
                          strcmp(iins_type,"56") == 0 ||
                          strcmp(iins_type,"136") == 0 ||
                          strcmp(iins_type,"166") == 0 ||
                          strcmp(iins_type,"266") == 0 )
                      {
                          $OPEN icvp_pa_cur USING $iendorse;
                          for(;;)
                          {
                          $FETCH icvp_pa_cur
                            INTO $iins_type,$iinsurant,$iins_scope,$icareer,$mins_premium,$mdiscount,
                                 $medr_commission,$medr_agent;
                              if (SQLCODE == SQLNOTFOUND) break;

                              strcpy( iins_type, trim( iins_type));
                              if (mins_premium < 0)
                                  dMod = -0.5;
                              else
                                  dMod = 0.5;

                              if (ipaid_base[0] == 'B')
                              {
                                  mcomm_33   = (long)((float)(mins_premium+mdiscount)*pcommission/100.0+dMod);
                                  magent_33  = (long)((float)(mins_premium+mdiscount)*pagent/100.0+dMod);
                              }
                              else
                              {
                                  mcomm_33   = (long)((float)mins_premium*pcommission/100.0+dMod);
                                  magent_33  = (long)((float)mins_premium*pagent/100.0+dMod);
                              }
  
                              mcomm_33  = mcomm_33  - medr_commission;
                              magent_33 = magent_33 - medr_agent;  

                              $EXECUTE up_cvp_pa
                                 USING $pcommission,$mcomm_33,$pagent,$magent_33;
                                 if (sqlca.sqlerrd[2] != 1)
                                 {
                                     sprintf(sErrmsg,"�L�k��spa�պ�Υ��鵲�����[%s]�I��[%s]",iendorse,iins_type);
                                     printf("sErrmsg[%s]\n",sErrmsg);
                                     goto errexit;
                                 }
                              if (strncmp(iendor68,"CVP",3) != 0)
                              {
                                  $EXECUTE up_cvp_plyins
                                     USING $pcommission,$mcomm_33,$pagent,$magent_33,
                                           $ipolicy,$iins_type,$iinsurant,$iins_scope,$icareer;
                                 if (sqlca.sqlerrd[2] != 1)
                                 {
                                     sprintf(sErrmsg,"�L�k��spa�̷s�O����[%s]�I��[%s]",ipolicy,iins_type);
                                     printf("sErrmsg[%s]\n",sErrmsg);
                                     goto errexit;
                                 }
                              }
                              mcomm_new  += mcomm_33;
                              magent_new += magent_33;
                          }
                          $CLOSE icvp_pa_cur;
                      }
                      else
                      {
                          if (mins_premium < 0)
                              dMod = -0.5;
                          else
                              dMod = 0.5;

                          if (ipaid_base[0] == 'B')
                          {
                              mcomm_new   = (long)((float)(mins_premium+mdiscount)*pcommission/100.0+dMod);
                              magent_new  = (long)((float)(mins_premium+mdiscount)*pagent/100.0+dMod);
                          }
                          else
                          {
                              mcomm_new   = (long)((float)mins_premium*pcommission/100.0+dMod);
                              magent_new  = (long)((float)mins_premium*pagent/100.0+dMod);
                          }
                      }
                      mcomm_new  = mcomm_new  - medr_commission;
                      magent_new = magent_new - medr_agent; 
                  }
                  $EXECUTE up_cvp_ins
                     USING $pcommission,$mcomm_new,$pagent,$magent_new,$ipaid_base;
                        if (sqlca.sqlerrd[2] != 1)
                        {
                            sprintf(sErrmsg,"�L�k��s�պ�Υ��鵲�����[%s]�I��[%s]",iendorse,iins_type);
                            printf("sErrmsg[%s]\n",sErrmsg);
                            goto errexit;
                        }
                  if (strncmp(iendor68,"CVP",3) != 0)
                  {
                  $EXECUTE up_cvp_instype
                     USING $pcommission,$mcomm_new,$pagent,$magent_new,$ipaid_base,
                           $ipolicy,$iins_type;
                        if (sqlca.sqlerrd[2] != 1)
                        {
                            sprintf(sErrmsg,"�L�k��s[%s]�̷s�O��[%s]�I�ؤ��I��",ipolicy,iins_type);
                            printf("sErrmsg[%s]\n",sErrmsg);
                            goto errexit;
                        }
                  }
                  $EXECUTE surid
                      INTO $fins_grp
                     USING $iins_type;
                        if (SQLCODE == SQLNOTFOUND)
                        {
                            sprintf(sErrmsg,"�L�k�P�_[%s]���[%s]�I�ؤ��I��",iendorse,iins_type);
                            printf("sErrmsg[%s]\n",sErrmsg);
                            goto errexit;
                        }
                  printf("fins_grp[%s]\n",fins_grp);
                  switch(fins_grp[0])
                  {
                    case '1':
                             mdmg_commi += mcomm_new;
                             mdmg_agent += magent_new;
                             break;
                    case '2':
                             mlia_commi += mcomm_new;
                             mlia_agent += magent_new;
                             break;
                    case '3':
                             mlia_commi += mcomm_new;
                             mlia_agent += magent_new;
                             break;
                    default :
                             sprintf(sErrmsg,"[%s]���[%s]�I���I���P�_���~->�I��[%s]",iendorse,iins_type,fins_grp);
                             printf("sErrmsg[%s]\n",sErrmsg);
                             goto errexit;
                             break;
                  }
             }
             $CLOSE icvp_ins_cur;
             $EXECUTE up_cvp_edr
                USING $mdmg_agent,$mdmg_commi,$mlia_agent,$mlia_commi;
                   if (sqlca.sqlerrd[2] != 1)
                   {
                       sprintf(sErrmsg,"�L�k��s[%s]�������N�z�O���",iendorse);
                       printf("sErrmsg[%s]\n",sErrmsg);
                       goto errexit;
                   }
             if (strncmp(iendor68,"CVP",3) != 0)
             {
               $EXECUTE up_cvp_ply1 
                  USING $mdmg_agent,$mdmg_commi,$mlia_agent,$mlia_commi,$ipolicy;
                     if (sqlca.sqlerrd[2] != 1)
                     {
                         sprintf(sErrmsg,"�L�k��s[%s]�̷s�O������N�z�O���",ipolicy);
                         printf("sErrmsg[%s]\n",sErrmsg);
                         goto errexit;
                     }
             }
          }
          $CLOSE icvp_main_cur;
          $FREE icvp_main_cur;

     }
     $CLOSE main_cur;
     $FREE  main_cur;
     /* ��s�O��w�X�楼�鵲��� */

/***********    ���q�Ȯɤ�����A�]�����O�T�޿褣�A��  

      $SELECT distinct ibroker
         INTO $ibroker
         FROM ca_comm_balance
        WHERE processid = $processid;

     $DECLARE s_cur CURSOR FOR 
       SELECT branch 
         FROM servertbl
        WHERE branch != 'S1'
        ORDER BY branch;
        $OPEN s_cur;
        for(;;)
        {
        $FETCH s_cur INTO $branch;
         if (SQLCODE == SQLNOTFOUND) break;
         strcpy(sFull,get_full_dbname(branch));

            sprintf(stmt,
           " SELECT iins_type,mins_premium,mdiscount     \
               FROM %s:ply_ins_type                      \
              WHERE ipolicy = ?                          \
                FOR UPDATE ",sFull);
           $PREPARE iply_ins FROM $stmt;
           $DECLARE iply_ins_cur CURSOR FOR iply_ins;

            sprintf(stmt,
           " UPDATE %s:ply_ins_type                                    \
                SET (pcommission,mcommission,pagent,magent,ipaid_base) \
                  = (?,?,?,?,?)     \
              WHERE CURRENT OF iply_ins_cur ",sFull);
           $PREPARE up_ply_ins FROM $stmt;

            sprintf(stmt,
           " SELECT mins_premium,mdiscount       \
               FROM %s:ca_pa_ply                 \
              WHERE ipolicy = ?                  \
                FOR UPDATE ",sFull);
           $PREPARE iply_pa FROM $stmt;
           $DECLARE iply_pa_cur CURSOR FOR iply_pa;

           sprintf(stmt,
           " UPDATE %s:ca_pa_ply                     \
                SET (pcommission,mcommission,        \
                     pagent,magent)                  \
                  = (?,?,?,?)                        \
              WHERE CURRENT OF iply_pa_cur ",sFull);
           $PREPARE up_ply_pa FROM $stmt;

           sprintf(stmt,
           " UPDATE %s:ply_relation                  \
                SET (mdmg_agent,mdmg_commi,mlia_agent,mlia_commi)  \
                  = (?,?,?,?)                        \
              WHERE CURRENT OF nclose_ply_cur ",sFull);
           $PREPARE up_ply_tion FROM $stmt;

          sprintf(stmt,
           " SELECT fcard_class,ipolicy,icar_type, qply_period       \
               FROM %s:ply_relation           \
              WHERE dply_close IS NULL        \
                AND ibroker = ?               \
                FOR UPDATE ",sFull);
           $PREPARE nclose_ply FROM $stmt;
           $DECLARE nclose_ply_cur CURSOR FOR nclose_ply;
           $OPEN nclose_ply_cur USING $ibroker;
           for(;;)
           {
           $FETCH nclose_ply_cur INTO $fcard_class,$ipolicy,$icar_type,$qply_period;
            if (SQLCODE == SQLNOTFOUND) break;

            mdmg_commi = mdmg_agent = 0;
            mlia_commi = mlia_agent = 0;

              $OPEN iply_ins_cur USING $ipolicy;
              for(;;)
              {
              $FETCH iply_ins_cur INTO $iins_type,$mins_premium,$mdiscount;
              if (SQLCODE == SQLNOTFOUND) break;

                mcomm_33 = magent_33 = 0;
                mcomm_new = magent_new = 0;
               strcpy( iins_type, trim( iins_type));
	    if ((strncmp(icar_type,"01",2) == 0) || (strncmp(icar_type,"02",2) == 0) ||
	        (strncmp(icar_type,"32",2) == 0) || (strncmp(icar_type,"34",2) == 0)) 
            {
               strcpy(iins_cat,"Z");
               if( qply_period == 24)
                   strcpy( iyear, "2");
               else
                   strcpy( iyear, "1");

	    }
	    else if ((strncmp(icar_type,"03",2) == 0) || (strncmp(icar_type,"04",2) == 0) ||
	             (strncmp(icar_type,"19",2) == 0) || (strncmp(icar_type,"21",2) == 0) ||
		     (strncmp(icar_type,"22",2) == 0))
	    {
               strcpy(iins_cat,"C");
               strcpy( iyear, "0");
	    }
	    else
	    {
	       strcpy(iins_cat,"X");
               strcpy( iyear, "0");
	    }


               $EXECUTE comid
                   INTO $ipaid_base
                  USING $iins_cat,$ibroker,$iins_type,$iyear;
                  if (SQLCODE == SQLNOTFOUND)
                  {
                      sprintf(sErrmsg,"[%s]�g���H[%s]�|������",ibroker,iins_type);
                      printf("sErrmsg[%s]\n",sErrmsg);
                      goto errexit;
                  }
                  if (fcard_class[0] == '1')
                  {
                      mcomm_new = mservice;
                  }
                  else
                  {
                      if (strcmp(iins_type,"33") == 0)
                      {
                          $OPEN iply_pa_cur USING $ipolicy;
                          for(;;)
                          {
                          $FETCH iply_pa_cur
                            INTO $mins_premium,$mdiscount;
                              if (SQLCODE == SQLNOTFOUND) break;

                              if (ipaid_base[0] == 'B')
                              {
                                  mcomm_33   = (long)((float)(mins_premium+mdiscount)*pcommission/100.0+0.5);
                                  magent_33  = (long)((float)(mins_premium+mdiscount)*pagent/100.0+0.5);
                              }
                              else
                              {
                                  mcomm_33   = (long)((float)mins_premium*pcommission/100.0+0.5);
                                  magent_33  = (long)((float)mins_premium*pagent/100.0+0.5);
                              }
                              $EXECUTE up_ply_pa
                                 USING $pcommission,$mcomm_33,$pagent,$magent_33;
                                 if (sqlca.sqlerrd[2] != 1)
                                 {
                                     sprintf(sErrmsg,"�L�k��s���鵲pa�O����[%s]�I��[%s]",ipolicy,iins_type);
                                     printf("sErrmsg[%s]\n",sErrmsg);
                                     goto errexit;
                                 }
                              mcomm_new  += mcomm_33;
                              magent_new += magent_33;
                          }
                          $CLOSE iply_pa_cur;
                      }
                      else
                      {
                          if (ipaid_base[0] == 'B')
                          {
                              mcomm_new   = (long)((float)(mins_premium+mdiscount)*pcommission/100.0+0.5);
                              magent_new  = (long)((float)(mins_premium+mdiscount)*pagent/100.0+0.5);
                          }
                          else
                          {
                              mcomm_new   = (long)((float)mins_premium*pcommission/100.0+0.5);
                              magent_new  = (long)((float)mins_premium*pagent/100.0+0.5);
                          }
                      }
                  }
                  $EXECUTE up_ply_ins
                     USING $pcommission,$mcomm_new,$pagent,$magent_new,$ipaid_base;
                        if (sqlca.sqlerrd[2] != 1)
                        {
                            sprintf(sErrmsg,"�L�k��s���鵲�O����[%s]�I��[%s]",ipolicy,iins_type);
                            printf("sErrmsg[%s]\n",sErrmsg);
                            goto errexit;
                        }
                  $EXECUTE surid
                      INTO $fins_grp
                     USING $iins_type;
                        if (SQLCODE == SQLNOTFOUND)
                        {
                            sprintf(sErrmsg,"�L�k�P�_[%s]�O��[%s]�I�ؤ��I��",ipolicy,iins_type);
                            printf("sErrmsg[%s]\n",sErrmsg);
                            goto errexit;
                        }
                  printf("fins_grp[%s]\n",fins_grp);
                  switch(fins_grp[0])
                  {
                    case '1':
                             mdmg_commi += mcomm_new;
                             mdmg_agent += magent_new;
                             break;
                    case '2':
                             mlia_commi += mcomm_new;
                             mlia_agent += magent_new;
                             break;
                    case '3':
                             mlia_commi += mcomm_new;
                             mlia_agent += magent_new;
                             break;
                    default :
                             sprintf(sErrmsg,"[%s]�O��[%s]�I���I���P�_���~->�I��[%s]",ipolicy,iins_type,fins_grp);
                             printf("sErrmsg[%s]\n",sErrmsg);
                             goto errexit;
                             break;
                  }
              }
              $CLOSE iply_ins_cur;

              $EXECUTE up_ply_tion
                 USING $mdmg_agent,$mdmg_commi,$mlia_agent,$mlia_commi;
                    if (sqlca.sqlerrd[2] != 1)
                    {
                        sprintf(sErrmsg,"�L�k��s[%s]�̷s�O������N�z�O���",ipolicy);
                        printf("sErrmsg[%s]\n",sErrmsg);
                        goto errexit;
                    }
           }
           $CLOSE nclose_ply_cur;
           $FREE  nclose_ply_cur;
        }
        $CLOSE s_cur;
        $FREE  s_cur;

*****************************/

      if (ihasdata == 0)
      {
          sprintf(sErrmsg,"���B�z�Ǹ��L��ƥi�ѧ��");
          printf("sErrmsg[%s]\n",sErrmsg);
          goto errexit;
      }
     $COMMIT WORK;
     return M_CM_OK;
errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   rc = SQLCODE;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   EWRITE(userid, rc, sErrmsg);
   exit(1);
}

char *get_db(sIpolicy)
char *sIpolicy;
{
  $char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  $char sTmp_db_name[21];
   char rtnd[11];

  $WHENEVER SQLERROR GOTO errexit;

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     printf("sTmpScomp = %s\n", sTmpScomp);
     $SELECT iupcomp 
        INTO $sTmpcomp
        FROM branch
       WHERE ibranch_abbr = $sTmpScomp;
      if (SQLCODE==SQLNOTFOUND)
      {
          strcpy(rtnd,itoa(SQLCODE));
          goto errexit;
      }
     /*
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     */
     printf("sTmpcomp = %s\n", sTmpcomp);
     strcpy(sTmp_db_name, sTmpcomp);
  }
  return sTmp_db_name;

errexit:
return rtnd;
}
