/**********************************************************************/
/*   program id   : ca203p04s.ec                                      */
/*   program name : �j���Iñ��ި�E-Mail�q��                          */
/*   date written : 2015/11/02                                        */
/*   date modify  : yyyy/mm/dd                                        */
/*   author       : Yin-Tsun Chang                                    */
/*   shell        : car2034_email                                     */
/**********************************************************************/

#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include "print.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "othmsgs.h"
#include "commsgs.h"
#include "sqlfatal.h"
#include "cmnmsgs.h"
#include "carmsgs.h"
#include "safeclib.h"

/******************************************************************************/
$char  	userid[11],sDdate[11];
char  	ddate[11],syy[4],smm[3],sdd[3],sdate[11];

int     flen,i;

FILE    *fp;
char    sApHome[30],msgbuf[512];
$char   fname[128],filename[121],ftitle[1024],nsubject[512],nattachment[1025];
$char	mmsg[1024],tbuf[501],mbuf[9000];
$loc_t 	ctxt;


$char	pre_ileader[11],sNleader[11],ileader[11];
$int 	mail_count;
$long	dsys;

$char stmt[4069];


int checkErr_cnt;
$char datebgn[11];
int   count_db,k;
DBinfo *list;
$char  	DBName[5],outputf[ N_FILE+1];

/* asempl */
$char	email[51],chinese_name[15];

$char stmt_tmp[1024];

/******************************************************************************/
main(argc, argv)
int argc;
char **argv;
{
    int rc;

    batchinit();
    strcpy(DBName,  isNULLstr(argv[1]));
    strcpy(userid,  isNULLstr(argv[2]));
    strcpy(ddate,   isNULLstr(argv[3])); /* cyy/mm/dd */
    strcpy(outputf, isNULLstr(argv[4]));

    strcpy(sDdate,cm_to_infdate(ddate));
    printf("-----��� : [%s] -----\n",sDdate);


    rc = car2034_get_db();
    if (rc != M_CM_OK) {
        printf("error on car2034_get_db\n");
        return rc;
    }

    /* �� temp table */
    rc = car2034_init_data();
    if (rc != M_CM_OK) {
        printf("error on car2034_init_data\n");
        return rc;
    }

    /* �d�ߧֹO���������O���i�C�L���� */
    rc = car2034_query_detail();
    if (rc != M_CM_OK) {
        printf("error on car2034_query_status\n");
        EWRITE(userid, rc, "�d�ߧֹO���������O���i�C�L���Ӧ��~!");
        return rc;
    }

    /* �H�e�ֹO���������O���i�C�L����Mail�q�����޲z�H */
    rc = car2034_send_email_ileader();
    if (rc != M_CM_OK) {
        printf("error on car2034_send_email_ileader\n");
        EWRITE(userid, rc, "�H�oMail�q���޲z�H���~!");
        return rc;
    }

    /* ���s�ֹO���������O���i�C�L���ӳ��� */
    rc = car2034_print_detail();
    if (rc != M_CM_OK) {
        printf("error on car2034_print_detail\n");
        EWRITE(userid, rc, "�����M�沣�s���~!");
        return rc;
    }

    printf("[car2034]:process ok!\n");
}
/******************************************************************************/
long car2034_get_db()
{
    int rc;

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "��Ʈw�L�k�}��!");
       return M_CM_DB_NOTOPEN;
    }

    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }

    if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
      if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
         return M_CM_NOT_DBLIST;
    }

    return M_CM_OK;

errexit:
   printf("--car2034_get_db-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/******************************************************************************/
long car2034_init_data()
{
    $WHENEVER SQLERROR GOTO errexit;
    /*
    	    ipolicy		char(20),		/*�O�渹�X*
	    tmp_policy		char(20),		/*�����渹
	    nassured		varchar(120),		/*�Q�O�I�H�W��*
	    itag		char(8),		/*���P���X*
	    dply_bgn		char(11),		/*�_�O��*
	    dply_end		char(11),		/*�����*
	    dentry		char(11),		/*��J���*
	    iofficer		char(11),		/*�g��N��*
	    nofficer		varchar(120),		/*�g��N���W��*
	    ileader		char(11),		/*�޲z�H�N��*
	    nleader		varchar(120),		/*�޲z�H�W��*
	    mprem		int,			/*�O�I�O*
	    deffect4		char(11),		/*�ˮִ���*
	    remark		varchar(120),		/*��]����*
	    payStatus		varchar(120)		/*���O���A*
    */
    sprintf_s(stmt_tmp, sizeof stmt_tmp,"create temp table car2034_tmp( "
	    "ipolicy		char(20),		 "
	    "tmp_policy		char(20),		 "
	    "nassured		varchar(120),		 "
	    "itag		char(%d),		 "
	    "dply_bgn		char(11),		 "
	    "dply_end		char(11),		 "
	    "dentry		char(11),		 "
	    "iofficer		char(11),		 "
	    "nofficer		varchar(120),		 "
	    "ileader		char(11),		 "
	    "nleader		varchar(120),	 "
	    "mprem		int,		 "
	    "deffect4		char(11),	 "
	    "remark		varchar(120),	 "
	    "payStatus		varchar(120)	 "
     ")with no log;",CA_TAG_NUM-1);
     $PREPARE stmp FROM $stmt_tmp;
     $EXECUTE stmp;

printf("-----cdate = [%s]-----\n",ddate);

    dsys = cm_ymd_cdate(ddate);
    cm_char_split_3ymd(ddate,syy,smm,sdd);
    sprintf_s(sdate, sizeof sdate,"%s%s%s",syy,smm,sdd);

    /* ���Y */
    strcpy(ftitle,"�O�渹�X,�����渹,�Q�O�I�H�W��,���P���X,�_�O��,�����,��J���,�g��N��,�g��N���W��,");
    strcat(ftitle,"�޲z�H�W��,�O�I�O,�ˮִ���,��]����,���O���A\n");

    /* �D�� */
    sprintf_s(nsubject, sizeof nsubject,"�j���Iñ��ި�q��(%s/%s/%s)",syy,smm,sdd);

    return M_CM_OK;

errexit:
   printf("--car2034_init_data-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/******************************************************************************/
long car2034_query_detail()
{
   int rc;

   	$char sIpolicy[21], sItmp_policy[21], sItag[CA_TAG_NUM], sDply_bgn[11],sDply_end[11];
	$char sDentry[11], sIofficer[11], sNofficer[11],sIleader[11], sIquota[8];
	$char sIcomm_obj[11], sIroute[21], sIroute_prop[3];
	$varchar sNassured[120];
	$char payStatus[7],ftype_sp[3],deffect4[11];
	$char remark[512];
	$int  count_pass = 0, sMprem, count_receive;

   $WHENEVER SQLERROR GOTO errexit;

    /*** �j�Ѱ_��ĤT�Ӥu�@�ѹO���q�� ***/
    strcpy(datebgn,"");

    $SELECT skip 3 first 1 dwork
       INTO $datebgn
       FROM cm_wrktbl
      WHERE dwork <= $sDdate
        AND fwork = '0'
      order by 1 desc;
printf("-----�ͮĤ� : [%s] -----\n",datebgn);
/*
strcpy(datebgn,"11/07/2015");
printf("-----�ͮĤ� : [%s] -----\n",datebgn);
*/

    $SELECT first 1 dwork
       INTO $deffect4
       FROM cm_wrktbl
      WHERE dwork > $sDdate
        AND fwork = '0';
        
printf("-----�ˮ֤� : [%s] -----\n",datebgn);


   for(k=0;k<count_db;k++)
   {
	   sprintf_s(stmt, sizeof stmt,
	          "SELECT a.ipolicy, b.itmp_policy, a.nassured, a.itag, b.dply_begin, "
	          "       b.dply_end, b.dentry, b.iofficer, b.ileader, "
	          "       NVL((SELECT nname FROM officer WHERE iofficer = b.iofficer), ''), "
	          "       NVL((SELECT nname FROM officer WHERE iofficer = b.ileader), ''), "
	          "      (b.mlia_prem+b.mdmg_prem) mprem, b.iquota, b.icomm_obj, "
	          "       a.iroute, a.iroute_prop  "
		 	      "  FROM %s:policy a, %s:ply_relation b "
		 	      " WHERE a.ipolicy = b.ipolicy    "
		 	      "   AND a.ipolicy = b.icard      "
		 	      "   AND a.icard = b.ipolicy      "
		 	      "   AND b.ibig_comp = ' '        "
		 	      "   AND b.dply_begin = '%s'      "
		 	      "   ORDER BY b.dply_begin DESC;  ",list[k].dbname,list[k].dbname,datebgn);

printf("stmt[%s]\n\n\n\n\n",stmt);

	    $PREPARE ca_card FROM $stmt;
	    $DECLARE no_outside_cur CURSOR FOR ca_card;
	    $OPEN no_outside_cur;
	    for(;;)
	    {
	        $FETCH no_outside_cur INTO $sIpolicy, $sItmp_policy, $sNassured, $sItag,
	                                   $sDply_bgn, $sDply_end, $sDentry, $sIofficer,$sIleader,
	                                   $sNofficer, $sNleader, $sMprem, $sIquota,
	                                   $sIcomm_obj, $sIroute, $sIroute_prop;

	        if(SQLCODE == SQLNOTFOUND) break;

	        checkErr_cnt = 0;
        	strcpy(remark, "");

	        $SELECT count(ipre_rcv) INTO $count_pass
			     FROM ao_prercv_pass
			    WHERE iins_cat  = 'C'
			      AND ipre_rcv  = $sItmp_policy
			      AND iins_kind = '1'
			      AND ipre_end  = ' ';

		/* email�u�H�e�����O�ץ� */
		if (count_pass > 0)
		{
			strcpy(payStatus, "�w���O");
			continue;
		}
		else
		{
			strcpy(payStatus, "�����O");
		}
		
		/* �ˮ֬O�_��PA�� �DPA�󤣱H�e*/
	        count_receive = 0;
	        $SELECT ftype_sp,count(*)
	           INTO $ftype_sp,$count_receive
	           FROM cm_pre_receive
	          WHERE iins_cat = 'C'
	            AND ipre_rcv = $sItmp_policy
	            AND iins_kind = '1'
	            AND ipre_end = ' '
	          GROUP BY ftype_sp;

	        if (count_receive > 0 && strcmp(ftype_sp,"PA") == 0)
	        {
	        	checkErr_cnt++;
	        	strcpy(remark," ");
	        }
	        else
	        {
	        	continue;
	        }

	        /* �ˮ�(�@)�g��N���O�_���� */
	        if( sIofficer[0] != 'W')
	        {
	            rc = cm_chk_policy("1", sIofficer, " ", " ", " ", " ", " ", " ");
	            if( rc != M_CM_OK)
	            {
	            	checkErr_cnt++;
	                strcpy(remark, cm_get_errmsg(rc));
	            }
	        }
	        /* �ˮ�(�G)�~�Z���O�_���� */
	        rc = cm_chk_policy("2", " ", " ", sIquota, " ", " ", " ", " ");
	        if( rc != M_CM_OK)
	        {
	            checkErr_cnt++;
	            strcpy(remark, trim(remark));
	            if (strlen(remark) != 0)
	            {
	               strcat(remark, ";");
	               strcat(remark, cm_get_errmsg(rc));
	            }
	            else
	            {
	               strcpy(remark, cm_get_errmsg(rc));
	            }
	        }
	        /* �ˮ�(�T)�I����H�O�_����X�� */
	        rc = cm_chk_policy("4", " ", " ", " ", sIcomm_obj, " ", " ", " ");
	        if( rc != M_CM_OK)
	        {
	            checkErr_cnt++;
	            strcpy(remark, trim(remark));
	            if (strlen(remark) != 0)
	            {
	               strcat(remark, ";");
	               strcat(remark, cm_get_errmsg(rc));
	            }
	            else
	            {
	            strcpy(remark, cm_get_errmsg(rc));
	            }
	        }
	        /* �ˮ�(�|)�I����H���L�X���� */
	        rc = cm_chk_policy("6", " ", " ", " ", sIcomm_obj, "C", " ", " ");
	        if( rc != M_CM_OK)
	        {
	            checkErr_cnt++;
	            strcpy(remark, trim(remark));
	            if (strlen(remark) != 0)
	            {
	               strcat(remark, ";");
	               strcat(remark, cm_get_errmsg(rc));
	            }
	            else
	            {
	               strcpy(remark, cm_get_errmsg(rc));
	            }
	        }
	        /* �ˮ�(��)�q���N���P�q���ۭq�~�ȥN���������Y�O�_���T */
	        rc = cm_chk_policy("7", " ", " ", " ", " ", " ", sIroute, sIroute_prop);
	        if( rc != M_CM_OK)
	        {
	            checkErr_cnt++;
	            strcpy(remark, trim(remark));
	            if (strlen(remark) != 0)
	            {
	               strcat(remark, ";");
	               strcat(remark, cm_get_errmsg(rc));
	            }
	            else
	            {
	               strcpy(remark, cm_get_errmsg(rc));
	            }
	        }
	        
printf("checkErr_cnt[%d]remark[%s]\n\n",checkErr_cnt,remark);

     	  	if (checkErr_cnt > 0)
     	      	{
     	      		$INSERT INTO car2034_tmp
          		     (ipolicy,tmp_policy,nassured,itag,dply_bgn,dply_end,dentry,
          		      iofficer,nofficer,ileader,nleader,mprem,deffect4,remark,payStatus)
		      	VALUES
          		     ($sIpolicy,$sItmp_policy,$sNassured,$sItag,$sDply_bgn,$sDply_end,$sDentry,
          		      $sIofficer,$sNofficer,$sIleader,$sNleader,$sMprem,$deffect4,$remark,$payStatus);
     	      	}

	    }
	    $CLOSE no_outside_cur;
            $FREE no_outside_cur;
   }

	  return M_CM_OK;

errexit:
   printf("--car2034_query_detail-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/******************************************************************************/
long car2034_send_email_ileader()
{
	  int	rc;
	  $char sStmt[1024];
	  $char sIpolicy[21], sItmp_policy[21], sItag[CA_TAG_NUM], sDply_bgn[11],sDply_end[11];
	  $char sDentry[11], sIofficer[11], sNofficer[11],sIleader[11], sNleader[11];
	  $varchar sNassured[120];
	$char payStatus[7],deffect4[11];
	$char remark[512];
	$int  sMprem;


    $WHENEVER SQLERROR GOTO errexit;

	  strcpy(sStmt,"SELECT ipolicy,tmp_policy,nassured,itag,dply_bgn,dply_end,dentry, "
          	       "       iofficer,nofficer,ileader,nleader,mprem,deffect4,remark,payStatus  "
                       "  FROM car2034_tmp     "
		       " WHERE ileader = ?     "
                       " ORDER BY dentry       ");
    printf("stmt[%s]\n",sStmt);
    $PREPARE pre_data from $sStmt;
    $DECLARE cur_data CURSOR FOR pre_data;

    $DECLARE cur_temp CURSOR FOR
      SELECT DISTINCT ileader
				INTO $ileader
				FROM car2034_tmp
       ORDER BY ileader;
    $OPEN  cur_temp;
    $FETCH cur_temp;
    strcpy(pre_ileader,ileader);

    mail_count=0;
    for(;;)
    {
			if (SQLCODE==SQLNOTFOUND) break;

			if (strcmp(ileader,pre_ileader)!=0)
			{
	    	rc = car2034_write_email_ileader();
	    	if (rc != M_CM_OK) {
					printf("error on car2034_write_email_ileader\n");
					return rc;
	    	}
	    	mail_count=0;
			}
			strcpy(pre_ileader,ileader);

			mail_count++;
			printf("---ileader:[%s]---\n",ileader);
			memset(fname,0x00,sizeof(fname));
			memset(filename,0x00,sizeof(filename));
			sprintf_s(fname, sizeof fname,"%s_�j���Iñ��ި�q������_%s",sdate,trim(ileader));
			sprintf_s(filename, sizeof filename,"%s/rptftp/car_email/%s.csv",sApHome,fname);
			printf("----filename[%s]----\n",filename);
			fp=fopen(filename,"w");

			fprintf(fp,ftitle);

			$OPEN cur_data USING $ileader;

			for(;;)
		  {
		    $FETCH cur_data INTO $sIpolicy,$sItmp_policy,$sNassured,$sItag,$sDply_bgn,$sDply_end,
		                         $sDentry,$sIofficer,$sNofficer,$sIleader,$sNleader,$sMprem,$deffect4,
		                         $remark,$payStatus;

		    if (SQLCODE==SQLNOTFOUND) break;

		    fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%s,%s,%s\n",
		            sIpolicy,sItmp_policy,sNassured,sItag,sDply_bgn,sDply_end,sDentry,
          		    sIofficer,sNofficer,sNleader,sMprem,deffect4,remark,payStatus);
		 }
			$CLOSE cur_data;
			fclose(fp);
			$FETCH cur_temp;
		}
    $FREE  cur_data;
    $CLOSE cur_temp;
    $FREE  cur_temp;

    if (mail_count!=0) {
        rc = car2034_write_email_ileader();
        if (rc!=M_CM_OK) {
			    printf("error on car2034_write_email_ileader\n");
			    return rc;
				}
    }

    return M_CM_OK;

errexit:
    printf("--car2034_send_email_ileader-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car2034_write_email_ileader()
{
    $whenever sqlerror goto errexit;

    $SELECT nname
       INTO $sNleader
       FROM officer
      WHERE iofficer = $pre_ileader;
    if (SQLCODE==SQLNOTFOUND) strcpy(sNleader,"�P��");

    strcpy(sNleader,trim(sNleader));
    /* email��� */
    sprintf_s(mmsg, sizeof mmsg,
	  "�˷R�� %s,�z�n</P>\n\n"
	  "���ɩ��ө|�L���O�����A���鬰�ĤT�Ӥu�@�ѿ�J�����A�O���ݭ��s���w�n�O�A�q�Ш�U�T�{�C</P>\n",sNleader);

    strcpy(mbuf,rtrim(mmsg));
    ctxt.loc_loctype = LOCMEMORY;
    ctxt.loc_buffer = mbuf;
    ctxt.loc_bufsize = 9000;
    ctxt.loc_size =  strlen(mbuf) + 1;

    strcpy(email," ");
    $select email,chinese_name
       into $email,$chinese_name
       from personal:asempl
      where empl_no = $pre_ileader;

    strcpy(email,trim(email));
    if (strlen(email) != 0){

      strcpy(email,trim(email));
      strcat(email,"@tmnewa.com.tw");
      printf("-----email:[%s]-----\n",email);
      /*strcpy(email,"JessicaWeng@tmnewa.com.tw");*/
      
      /* 1110322014_SC1_batchemail�ಾ�ܷs���x */
      if (strlen(trim(fname)) != 0) sprintf_s(nattachment, sizeof nattachment,"%s.csv",trim(fname));
      printf("-----nattachment:[%s]-----\n",nattachment);

      $INSERT INTO batchemail
                  (project_id, mail_date, receiver_email,
                   receiver_name, cc, content, key, mail_count, nsubject,
                   nattachment)
       VALUES
                  ("CAR2034", today, $email, $chinese_name,
                   " ", $ctxt, $fname, $mail_count, $nsubject,
                   $nattachment);
    }

    return M_CM_OK;

errexit:
   printf("--car2034_write_email_ileader-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/******************************************************************************/
long car2034_print_detail()
{
    int     rc;
    char    sfilename[100],stitle[1024];

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(sfilename,"�j���Iñ��ި�q������(E-Mail�q��)");
    strcpy(stitle,"�{���N��:car2034\t");
    strcat(stitle,sfilename);
    strcat(stitle,"\t\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");
    strcat(sfilename,"[car2034]");

    strcat(stitle,"\t�O�渹�X\t�����渹\t�Q�O�I�H�W��\t���P���X\t�_�O��\t�����\t��J���");
    strcat(stitle,"\t�g��N��\t�g��N���W��\t�޲z�H�W��\t�O�I�O\t�ˮִ���\t��]����\t���O���A\t");

    strcpy(stmt,"SELECT ipolicy,tmp_policy,nassured,itag,dply_bgn,dply_end,dentry, "
          	"	iofficer,nofficer,nleader,mprem,deffect4,remark,payStatus  "
                "  FROM car2034_tmp "
                " ORDER BY dentry   ");
printf("stmt[%s]\n",stmt);
    rc = unload_file(outputf," ",sfilename,stitle,stmt);

    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;

errexit:
   printf("--car2034_print_detail-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}
/******************************************************************************/