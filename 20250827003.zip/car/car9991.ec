/*********************************************
 * Copyright (C) 1995 Intellisys Corporation
 *
 * Program : car9991.ec �o�i���߱j���I�O��
 *           Modify by Thomas 880101
 *********************************************/

#include <stdio.h>
#include <stdlib.h>
#include "api_xsrv.h"
#include "sqlfatal.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"

#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "car_common.h"
#include "safeclib.h"

$char localdb[5],Taipei_FullName[20];
int  i=0, flag_check=0;
$char userid[11], iquota[7];
char expdate[6];
char bgndate[10],enddate[10];

char prtfile[80],outputf[80],outputf1[80],tmp_outputf[21];
char option[2];
char errmsg[200];
 FILE *fptr, *fptr_err;
$char  errFile[120];
$static char remotedb[DBNAME];
int   count_db,k; 

$char DBName[05];
$char msgbuf[128];
DBinfo *list;
char  sApHome[30];
int   rtncode=0,rc=0;
char  filename[30];
FILE  *fp;
char  file_catalog[200];
$char filename1[200];
$char  data_yyyymm[7];

$char iproduct_tmp[3];
$long mprem_14 = 0,mprem_15 = 0,mprem_16 = 0,mprem_32 = 0;
$long mprem_pure_14 = 0,mprem_pure_15 = 0,mprem_pure_16 = 0,mprem_pure_32 = 0;

long car9991_get_db();
long car9991_build();
long car9991_final();
/*************************************************************/
main(argc,argv)
int argc;
char **argv;
{
   int rtncode=0,rc=0;

	strcpy(DBName, isNULLstr(argv[1]));
	strcpy(userid, isNULLstr(argv[2]));
	strcpy(expdate,isNULLstr(argv[3]));
	strcpy(outputf,isNULLstr(argv[4]));

	printf("DBName[%s],userid[%s],expdate[%s],outputf[%s] \n",DBName,userid,expdate,outputf);

	rc = car9991_get_db();
	if (rc != M_CM_OK)
	{
		return rc;
	}

	rc = car9991_build();
	if ( rc != SUCCESS ) {
	 	printf("error on car9991_build \n");
	 	EWRITE(userid, rc, errmsg);
		return rc;	
	}

	rc = car9991_final();
	if ( rc != SUCCESS ) {
	 	printf("error on car9991_show \n");
	 	EWRITE(userid, rc, errmsg);
		return rc;	
	}
}

long car9991_get_db()
{
	$whenever sqlerror goto errexit1;

	if (db_select(DBName) == DBName) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}
	
	rc = getApHome(sApHome);
	if (rc < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		EWRITE(userid,rc,msgbuf);
	 	return rc;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}	
	return M_CM_OK;

errexit1:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
/*---------------------------------------------------------------------*/
long car9991_build()
{
	char   bgn_yy[5],bgn_mm[3],end_mm[3];
	int    endyy=0,endmm=0,dply_begin_yyyy=0,dply_end_yyyy=0;
	$long  dwritten_l=0,dpolicy=0;
	$char  ipolicy[21],ilast_ply[21],icard[21],ilast_card[21],objno[5];
	$char  dpolicy_str[9];
	$char  dpolicy_eng[11];
	$char  icode[11];
	$char  ilicense[11],ibirth[9],fsex[2],fmarriage[2],icar_type[3];
	$char  ibrand[9],ibrand_new[9],drate_ym[7],drate_yyyymm[7],ipro_year[5],iengine[CA_ENGINE_NUM];
	$char  ibody[CA_BODY_NUM],itag[CA_TAG_NUM],fpt[2],iassured[13],fcar_class[2];
	$char  iengine_tmp[CA_ENGINE_NUM],ibody_tmp[CA_BODY_NUM];
	$char  fcomp_class[3],fcomp_class_last[3],iproduct[13];
	$long  dply_begin=0,dply_end=0,mins_premium=0,bgndate_l=0,enddate_l=0;
	$double pure_total;
	$long  mbusiness_l=0, maintain_l=0, madjcom_prem_l=0;
	$double qpt=0,madjcom_prem=0,mbusiness=0,maintain=0;
	$int   qcylinder=0,qply_period=0;
	$char  stmt_buf1[1024], stmt_buf2[1024], stmt_buf3[1024], buf1[30];
	char   dply_begin_c[11],dply_end_c[11],mins_premium_c[10],qcylinder_c[6];
	char   madjcom_prem_c[14],mbusiness_c[10], maintain_c[10];
	$char   qply_period_c[3],dpolicy_c[11],iissue_yy[5];
	char   dply_begin_yy[5],dply_begin_mm[3],dply_begin_dd[3];
	char   dply_end_yy[4],dply_end_mm[3],dply_end_dd[3];
	$char   dply_yy[4],dply_mm[3],tmp_dd[3];
	$char   ipolicy_br[3],ilast_ply_br[3],prtstr[293],ttday[20];
	char   cmdbuf[100],prem_c[13],ttday_yy[5],ttday_mm[3],ttday_dd[3];
	$long   count1=0,prem_total=0;
	$char  drate[11], drate_c[11];
	char   drate_yy[4],drate_mm[3],drate_dd[3],tmp_yyyy[5],sTmp_buf[21];
	$static date   Today;
	long   drate_yyyy,dply_yyyy,iissue_yyyy;
	int    i=0, j=0, s_branch_cnt=0;
	int    res=0;
	$char   aphome[40],stmt[4096];
	$char  sIply_area[3];
	$char  sFassured[2];
	$char  product_kind[3];
	$char  ibroker[11], fbusiness[2],ibroker_top[11],bzfrom[3];
	$char  ibrand6[7],ibrand_78[3];
	$int   cnt=0;
	$double mcompensation, mstable;
	$double tot_mcompensation, tot_mstable, tot_mdrunk_pure_prem;
	$char icar_flag[2];
	$int qdrunk_driving=0;
	char qdrunk_driving_c[2];
	$long mdrunk_prem=0;
	$double mdrunk_pure_prem=0;
	$long  mdrunk_pure_prem_l=0;
	$char chk_dpolicy[2];
	$long mprem=0;
	$char mprem_c[10];
	
	$int cnt_L = 0;
	$char fcar_kind[2],irelative_ply[21];
	$char PLY_DB[31];
	$char stmtt[4096];
	
	/* ca_dev_ply_edr_comp */
	$char  t_data_yyyymm[7],t_idata[2],t_ipolicy[21],t_icard_company[3],t_icard_br[3],t_icard[16],t_icard_last_company[3],t_icard_last_br[3],t_icard_last[16];
	$char  t_iedr_company[3],t_iedr_br[3],t_iendorse[14],t_iarea[3],t_dedr_begin[9],t_dedr_end[9],t_dply_begin[9],t_dply_end[9],t_iobjno[5],t_iissue_year[5],t_ipro_year[5],t_ibrand[9];
	$char  t_icar_type[3],t_icar_type_no[3],t_iengine[26],t_itag[13],t_fpt[2],t_fassured[2],t_iassured[11],t_dbirth[9],t_fsex[2],t_fmarriage[2];
	$char  t_fcomp_class_last[3],t_fcomp_class[3],t_iedr_type[3];
	$char  t_iproduct[13],t_drate_ym[7],t_dpolicy_ym[7],t_bzfrom[3],t_dsend[9];
	$long  t_qcylinder=0,t_qpt,t_qdrunk_driving=0,t_mprem=0,t_mins_premium=0,t_mdrunk_prem=0;
	$double t_madjcom_prem,t_mbusiness,t_maintain,t_mcompensation,t_mstable,t_mdrunk_pure_prem;

	filename[0] = '\0';
	file_catalog[0] = '\0';
	sprintf_s(filename, sizeof filename,"%s/rptftp/", sApHome);
	sprintf_s(filename1, sizeof filename1,"AUTOP17_%d.txt",atoi(expdate)+191100);
	strcpy(file_catalog, trim(filename));
	strcat(file_catalog, trim(filename1));
	printf("file_catalog[%s] \n",file_catalog);
	
	if ((fptr=fopen(file_catalog,"w")) == NULL)
	{
		sprintf_s(errmsg, sizeof errmsg,"Cannot open print file:%s",outputf);
		return M_CM_OPEN_FILE_FAIL;
	}
	
	printf("202\n");
	printf(">>>expdate=%s\n",expdate);
	strncpy(bgn_yy,&expdate[0],3);
	bgn_yy[3]='\0';
	strncpy(bgn_mm,&expdate[3],2);
	bgn_mm[2]='\0';
	if (strncmp(bgn_mm, "12",2) == 0)
	{
		endyy=atoi(bgn_yy)+1;
		endmm=1;
	}
	else
	{
		endyy=atoi(bgn_yy);
		endmm=atoi(bgn_mm)+1;
	}
	rfmtlong(endmm,"&&",end_mm);

	sprintf_s(bgndate, sizeof bgndate,"%s/%s/%s",bgn_yy,bgn_mm,"01");
	sprintf_s(enddate, sizeof enddate,"%d/%s/%s",endyy,end_mm,"01");
	sprintf_s(data_yyyymm, sizeof data_yyyymm,"%s%s",itoa(atoi(bgn_yy)+1911),bgn_mm);
	
	printf(">>>bgndate=[%s] enddate=[%s]\n",bgndate,enddate);
	
	$WHENEVER SQLERROR GOTO errexit;
	
	bgndate_l=cm_ymd_cdate(bgndate);
	enddate_l=cm_ymd_cdate(enddate);

    /* C273-280 ��ƻs�e�� */
	strcpy(ttday , cm_get_sysd());
	strncpy(ttday_yy,&ttday[0],4); ttday_yy[4] = '\0';
	strncpy(ttday_mm,&ttday[5],2); ttday_mm[2] = '\0';
	strncpy(ttday_dd,&ttday[8],2); ttday_dd[2] = '\0';

	prem_total=0;count1=0;pure_total=0.0;
	tot_mcompensation=0;tot_mstable=0;tot_mdrunk_pure_prem=0;
	for(k=0;k<count_db;k++)
	{
		printf(">>>before prepare ori_ply_relarion\n");
		
		sprintf_s(stmt, sizeof stmt,"DELETE FROM %s:ca_dev_ply_edr_comp WHERE data_yyyymm = '%s' AND idata = 'P'",list[k].dbname,data_yyyymm);
		$PREPARE DE_ca_dev_ply_edr_comp FROM $stmt;
		$EXECUTE DE_ca_dev_ply_edr_comp;
	
	     /***** prepare cursor for select ori_ply_relation *****/
	     /* car950512 maintain */ 
		sprintf_s(stmt_buf1, sizeof stmt_buf1,"SELECT %s %s %s %s FROM %s:%s %s %s %s %s",
		                  "ipolicy,ilast_ply,icard,ilast_card,dpolicy,icar_type,ibrand,ipro_year,ibroker,",
		                  "dply_begin,dply_end,qply_period,madjcom_prem,mbusiness,(maintain + mresearch),fcomp_class,fcomp_class_last,dply_begin,",
		                  "mcompensation,mstable,icar_flag,bzfrom,qdrunk_driving,"
		                  "case when dpolicy < '08/01/2016' then 'Y' else 'N' end,ibrand[7,8],",
		                  "nvl(irelative_ply,'') ",
		                  list[k].dbname,"ori_ply_relation ",
		                  "WHERE fcard_class IN ('1' ,'3') AND ",
		                  "dpolicy >= ? AND dpolicy < ? AND ipolicy[14,15] <> '-1'",
		                  " ",
		                  "ORDER BY ipolicy");
		printf("stmt[%s]\n",stmt_buf1);
		$PREPARE CUR_STMT1 FROM $stmt_buf1;
		$DECLARE scur_ply1 CURSOR FOR CUR_STMT1;
		printf(">>>before prepare original_ply\n");
		/***** prepare cursor for select original_ply *****/
		/* 0991022002�]�����F�������X�֭p�� */
		/* 1.���a�ϥN����42�u�x�����v�A�h�վ㬰41�u�x�����v */
		/* 2.���a�ϥN����63�u�x�n���v�A�h�վ㬰62�u�x�n���v */
		/* 3.���a�ϥN����65�u�������v�A�h�վ㬰64�u�������v */
		sprintf_s(stmt_buf2, sizeof stmt_buf2,"SELECT %s %s %s FROM %s:%s %s",
		                  "ilicense,YEAR(dissue),to_char(dbirth,'%Y%m%d'),",
		                  "fsex,fmarriage,qcylinder,qpt,fpt,iengine,ibody,",
		                  "itag,iassured, DECODE(iply_area,'42','41','63','62','65','64',iply_area), fassured",
		                  list[k].dbname,"original_ply ",
		                  "WHERE ipolicy=? ");
		printf("stmt[%s]\n",stmt_buf2);
		$PREPARE CUR_STMT2 FROM $stmt_buf2;
		$DECLARE scur_policy1 CURSOR FOR CUR_STMT2;
		printf(">>>before prepare ori_ins_type\n");
	
		/***** prepare cursor for select ori_ins_type *****/
		sprintf_s(stmt_buf3, sizeof stmt_buf3,"SELECT %s FROM %s:%s %s",
	                      "mins_premium,drate_ym,iproduct,mdrunk_prem,mdrunk_pure_prem,mprem",
	                      list[k].dbname,"ori_ins_type",
	                      "WHERE ipolicy=? ");
		printf("stmt[%s]\n",stmt_buf3);
	
		/***** prepare cursor for select ca_car_model *****/
		/* 1000530002�t�P�����N���H�ഫ�t�P�����N�����e */
		sprintf_s(stmt, sizeof stmt, "SELECT ibrand_new "
		              "  FROM ca_car_model "
		              " WHERE ibrand = ? "
		              "   AND ibrand_new != ' ' "
		              " ORDER BY drate DESC;");
		$PREPARE pr_ibrand FROM $stmt;
		$DECLARE cur_ibrand CURSOR FOR pr_ibrand;
		printf("stmt[%s]\n", stmt);
	
		$PREPARE CUR_STMT3 FROM $stmt_buf3;
		$DECLARE scur_ply_ins_a1 CURSOR FOR CUR_STMT3;
	
		$OPEN scur_ply1 USING $bgndate_l,$enddate_l;
		chk_dpolicy[0] = '\0';
		madjcom_prem = 0.0;
		while(1) 
		{
			/* car950512 maintain */
			$FETCH scur_ply1 INTO $ipolicy,$ilast_ply,$icard,$ilast_card,$dpolicy,$icar_type,
			                      $ibrand,$ipro_year,$ibroker,$dply_begin,
			                      $dply_end,$qply_period,$madjcom_prem,$mbusiness,
			                      $maintain,$fcomp_class,$fcomp_class_last,$dpolicy_eng,
			                      $mcompensation,$mstable,$icar_flag,$bzfrom,$qdrunk_driving,$chk_dpolicy,$ibrand_78,$irelative_ply;
			
			if (SQLCODE == SQLNOTFOUND) break;
			strcpy(dpolicy_str,dpolicy_eng+6);
			strcat(dpolicy_str,substring(dpolicy_eng,1,2));
			strcat(dpolicy_str,substring(dpolicy_eng,4,2));
			printf("dpolicy_eng[%s]\n",dpolicy_eng);
			printf("dpolicy_str[%s]\n",dpolicy_str);
			strcpy(t_ipolicy,ipolicy);
			
			$OPEN scur_policy1 USING $ipolicy;
			$FETCH scur_policy1 INTO $ilicense,$iissue_yy,$ibirth,$fsex,$fmarriage,$qcylinder,$qpt,$fpt,$iengine,$ibody,$itag,$iassured,$sIply_area,$sFassured;
			
			if (SQLCODE == SQLNOTFOUND) 
			{
				$CLOSE scur_policy1;
				continue;
			}
			$CLOSE scur_policy1;
			
			$OPEN scur_ply_ins_a1 USING $ipolicy;
			$FETCH scur_ply_ins_a1 INTO $mins_premium,$drate_ym,$iproduct,$mdrunk_prem,$mdrunk_pure_prem,$mprem;
			
			prem_total+=mins_premium; /*�`�O�O*/
			/*pure_total+=madjcom_prem; �`�«O�O*/
			
			if (SQLCODE==SQLNOTFOUND) 
			{
				$CLOSE scur_ply_ins_a1;
				continue;
			}
			$CLOSE scur_ply_ins_a1;
			
			tot_mcompensation += mcompensation;
			tot_mstable += mstable;
			
			strcpy(prtstr, CAR_COMPANY);                    /*C1-2:���q�N��*/
			strcpy(t_icard_company,CAR_COMPANY);
			prtstr[2]='\0';
			
			strcpy(ipolicy, trim(ipolicy));
			strcpy(drate_ym, trim(drate_ym));
			
			strncpy(ipolicy_br, ipolicy, 2); ipolicy_br[2]='\0';
			if (ipolicy_br[0]=='\0') 
			{
				strcat(prtstr,"  ");
				strcpy(t_icard_br," ");
			}
			else 
			{
				strcat(prtstr,ipolicy_br); /*C3-4:������c*/
				strcpy(t_icard_br,ipolicy_br);
			}
			prtstr[4]='\0';
			
			strncat(prtstr, icard, 15);					/*C5-19�j��O�I�ҽs��  add in 2008/1*/
			strncpy(t_icard,icard,15);
			prtstr[19]='\0';
			
			if (strlen(rtrim(ilast_card)) == 0)
			{
				strcat(prtstr,"                   ");	/*C20-38  add in 2008/1*/
				strcpy(t_icard_last_company," ");
				strcpy(t_icard_last_br," ");
				strcpy(t_icard_last," ");
			}
			else
			{
				strcat(prtstr, CAR_COMPANY);			/*C20-21:��O���q�N��  2008/1*/
				strcpy(t_icard_last_company,CAR_COMPANY);
				prtstr[21] = '\0';
				strncpy(ilast_ply_br, ilast_ply, 2); ilast_ply_br[2]='\0';
				if (ilast_ply_br[0]=='\0') 
				{
					strcat(prtstr,"  "); 
					strcpy(t_icard_last_br," ");
				}
				else 
				{
					strcat(prtstr,ilast_ply_br);		/*C22-23:��O������c*/
					strcpy(t_icard_last_br,ilast_ply_br);
				}
				prtstr[23] = '\0';
				strncat(prtstr, ilast_card, 15);		/*C24-38:��O�j��O�I�ҽs��*/
				strcpy(t_icard_last,ilast_card);
				prtstr[38] = '\0';
			}
			
			if (strlen(ipolicy) >= 17 ) 
			{           /* ���j�O��*/
				strncpy(objno, ipolicy+CAR_POLICY_LEN, CAR_TARGET_LEN);
				/* ISconstant.hh:#define CAR_TARGET_LEN     4     �Ъ���������(�O��) */
				objno[CAR_TARGET_LEN]='\0';  
			}
			else
			{
				strcpy(objno,"0001");
				objno[CAR_TARGET_LEN]='\0';
			}
			
			strcat(prtstr, sIply_area);             /*C39-40*/
			strcpy(t_iarea,sIply_area);
			
			strcpy(dply_begin_c,cm_cdate_str_100(dply_begin));
			cm_split_ymd_100(dply_begin_c,dply_begin_yy,dply_begin_mm,dply_begin_dd);
			
			if (dply_begin_yy[0] == '\0' ) 
			{
				strcat(prtstr,"0000");
				strcpy(t_dply_begin,"0000");
			}
			else 
			{
				dply_begin_yyyy = atoi( dply_begin_yy ) + 1911;
				rfmtlong(dply_begin_yyyy,"&&&&",tmp_yyyy);
				strcat(prtstr,tmp_yyyy);
				strcpy(t_dply_begin,tmp_yyyy);
			}
			if (dply_begin_mm[0] == '\0') 
			{
				strcat(prtstr,"00");
				strcat(t_dply_begin,"00");
			}
			else 
			{
				strcat(prtstr,dply_begin_mm);
				strcat(t_dply_begin,dply_begin_mm);
			}
			
			if (dply_begin_dd[0] == '\0') 
			{
				strcat(prtstr,"00");
				strcat(t_dply_begin,"00");
			}
			else 
			{
				strcat(prtstr,dply_begin_dd);      /*C41-48:�O��_��*/
				strcat(t_dply_begin,dply_begin_dd);
			}
			prtstr[48]='\0';
			
			strcpy(dply_end_c,cm_cdate_str_100(dply_end));
			cm_split_ymd_100(dply_end_c,dply_end_yy,dply_end_mm,dply_end_dd);
			
			if (dply_end_yy[0] == '\0' ) 
			{
				strcat(prtstr,"0000");
				strcpy(t_dply_end,"0000");
			}
			else
			{
				dply_end_yyyy = atoi( dply_end_yy ) + 1911;
				rfmtlong(dply_end_yyyy,"&&&&",tmp_yyyy);
				strcat(prtstr,tmp_yyyy);
				strcpy(t_dply_end,tmp_yyyy);
			}
			if (dply_end_mm[0] == '\0') 
			{
				strcat(prtstr,"00");
				strcat(t_dply_end,"00");
			}
			else 
			{
				strcat(prtstr,dply_end_mm);
				strcat(t_dply_end,dply_end_mm);
			}
			if (dply_end_dd[0] == '\0') 
			{
				strcat(prtstr,"00");
				strcat(t_dply_end,"00");
			}
			else 
			{
				strcat(prtstr,dply_end_dd);      /*C49-56:�O�樴��*/
				strcat(t_dply_end,dply_end_dd);
			}
			prtstr[56]='\0';
			
			if (strlen(rtrim(objno))==0) 
			{
				strcat(prtstr,"0001");
				strcpy(t_iobjno,"0001");
			}
			else 
			{
				strcat(prtstr,objno);            /*C57-60:�O��Ъ���*/
				strcpy(t_iobjno,objno);
			}
	
			if (iissue_yy[0] == '\0' ) 
			{
				strcat(prtstr,"0000");
				strcpy(t_iissue_year,"0000");
			}
			else 
			{
				iissue_yyyy = atoi( iissue_yy );
				rfmtlong(iissue_yyyy,"&&&&",tmp_yyyy);
				strcat(prtstr,tmp_yyyy);
				strcpy(t_iissue_year,tmp_yyyy);
			}                               /*C61-64:�o�Ӧ~��*/
			prtstr[64]='\0';
			
			if (ipro_year[0] == '\0') 
			{
				strcat(prtstr,"0000");
				strcpy(t_ipro_year,"0000");
			}
			else 
			{
				strcat(prtstr,ipro_year);        /*C65-68:�s�Ӧ~��*/
				strcpy(t_ipro_year,ipro_year);
			}
			prtstr[68]='\0';
			
			/* 1000530002�t�P�����N���H�ഫ�t�P�����N�����e */
			ibrand_new[0]='\0';
			$OPEN cur_ibrand USING $ibrand;
			$FETCH cur_ibrand INTO $ibrand_new;
			if (ibrand_new[0]!='\0') strcpy(ibrand, ibrand_new);
			$CLOSE cur_ibrand;
			printf("ibrand[%s]ibrand_new[%s]\n", ibrand, ibrand_new);
			
			/* field 12 88-95 �t�P�����N�� */
			if(strncmp(ibrand,"151001",6)==0) strcpy(ibrand,"15010100");
			if(strncmp(ibrand,"090737",6)==0) strcpy(ibrand, "09013700");
			if(strncmp(ibrand,"561002",6)==0) strcpy(ibrand, "56081900");
			if(strncmp(ibrand,"561001",6)==0) strcpy(ibrand, "56080110");
			if(strncmp(ibrand,"MF0002",6)==0)  strcpy(ibrand, "ME000200");
			if( (strncmp(ibrand,"MR0001",6)==0) || (strncmp(ibrand,"MT0001",6)==0) ) strcpy(ibrand, "MM000100");
			
			/* �O�o�������t�P�����e6�X */
			strncpy(ibrand6, ibrand, 6);
			ibrand6[6]='\0';
			$SELECT COUNT(*)
			   INTO $cnt
			   FROM cu_code_data
			  WHERE itype='B9'
			    AND icode=$ibrand6;
			if (cnt>0) ibrand[4]=ibrand[5]='0';
			
			if (ibrand[0] == '\0' || ibrand[0] == ' ')
			{
				strcat(prtstr,"00000000");
				strcpy(t_ibrand, "00000000");
			}
			else
			{
				strcat(prtstr,ibrand);
				strcpy(t_ibrand, ibrand);
			}                                     /*C69-76:�����N��*/
			prtstr[76]='\0';
			
			strcpy(icar_type,TRANS_CAR_TYPE(icar_type));
			strcpy(icar_type,trim(icar_type));
			if (icar_type[0] == '\0') 
			{
				strcat(prtstr,"00");
				strcpy(t_icar_type,"00");
			}
			else if (strcmp(trim(icar_type),"51") == 0) 
			{
				strcat(prtstr,"34");
				strcpy(t_icar_type,"34");
			}
			else 
			{
				strcat(prtstr,icar_type);        /*C77-78:���إN��*/
				strcpy(t_icar_type,icar_type);
			}
			prtstr[78]='\0';
			
			/*C79-80 �����������O*/
			if((strcmp(icar_type,"01") == 0) || (strcmp(icar_type,"02") == 0) || (strcmp(icar_type,"32") == 0) || (strcmp(icar_type,"34") == 0))
			{	
				strcpy(irelative_ply,trim(irelative_ply));
				if (strcmp(irelative_ply,"") != 0)
				{
					strcpy(PLY_DB,get_car_full_db(irelative_ply));
					sprintf_s(stmtt, sizeof stmtt,"SELECT count(*) FROM %s:ply_ins_type WHERE ipolicy = '%s' AND (provision = 'L' OR provision matches '*;L*' OR provision matches '*L;*') ",PLY_DB,irelative_ply);
					printf("stmtt[%s]\n",stmtt);
					$PREPARE ply_L FROM $stmtt;
					$EXECUTE ply_L INTO $cnt_L;
				}
				else 
					cnt_L = 0;
				
				if (cnt_L > 0) 
				{
					strcat(prtstr,"02");
					strcpy(t_icar_type_no,"02");
				}
				else 
				{
					strcat(prtstr,"01");
					strcpy(t_icar_type_no,"01");
				}
			}
			else if ((strcmp(icar_type,"07") == 0) || (strcmp(icar_type,"15") == 0))
			{
				$SELECT FIRST 1 nvl(fkind,'')
				   INTO $fcar_kind
				   FROM ca_taxi_type
				  WHERE icard = $icard
				  ORDER BY dupdate DESC;
				if (SQLCODE == SQLNOTFOUND) strcpy(fcar_kind,"N");
				
				if(strcmp(fcar_kind,"Y") == 0) 
				{
					strcat(prtstr,"04");
					strcpy(t_icar_type_no,"04");
				}
				else 
				{
					strcat(prtstr,"03");
					strcpy(t_icar_type_no,"03");
				}
			}
			else 
			{
				strcat(prtstr,"00");
				strcpy(t_icar_type_no,"00");
			}
			prtstr[80]='\0';
			
			if( ((strcmp(icar_type,"02") == 0)) && (qcylinder > 49) && (strncmp(ibrand_78,"01",2) != 0))
				qcylinder = 49;
			else if((strcmp(icar_type,"01") == 0) && (qcylinder < 50) && (strncmp(ibrand_78,"01",2) != 0))
				qcylinder = 124;
			else if((strcmp(icar_type,"32") == 0) && (qcylinder < 251) && (strncmp(ibrand_78,"01",2) != 0))
				qcylinder = 251;
			
			if( (strcmp(ibrand,"E8013601")==0) && (qcylinder < 40) )
				qcylinder = 40;
			if( (strcmp(ibrand,"E8020601")==0) && (qcylinder < 40) )
				qcylinder = 40;
			rfmtlong(qcylinder,"&&&&&",qcylinder_c);
			strcat(prtstr,qcylinder_c);             /*C81-85:�Ʈ�q*/
			t_qcylinder = qcylinder;
			prtstr[85]='\0';
			
			strcpy(iengine_tmp,trim(iengine));
			strcpy(ibody_tmp,trim(ibody));
			if ((iengine_tmp[0]=='\0' || iengine_tmp[0]==' ') &&
			    (ibody_tmp[0]=='\0' || ibody_tmp[0]==' ')) 
			{
				strcat(prtstr,"                         ");
				strcpy(t_iengine," ");
			} 
			else if (iengine_tmp[0]=='\0' || iengine_tmp[0]==' ') 
			{
				strcat(prtstr, ibody);
				strcpy(t_iengine,ibody);
			} 
			else 
			{
				strcat(prtstr, iengine);
				strcpy(t_iengine,iengine);
			}                                      /*C86-110:����/�������X*/ 
			prtstr[110]='\0';
			
			/*C111-122:�W���P�Ӹ��X*/       
			printf("----icard[%s] icar_type[%s] chk_dpolicy[%s]\n",icard,icar_type,chk_dpolicy);
			if (icar_flag[0]=='1' || itag[0]=='\0' || itag[0]==' ' || (strcmp(icar_type,"27") == 0 && strcmp(chk_dpolicy,"Y") == 0)) 
			{
				strcat(prtstr,"            ");
				strcpy(t_itag," ");
			}
			else 
			{
				strcat(prtstr,itag);
				strcpy(t_itag,itag);
			}
			prtstr[122]='\0';
			/*C123-134:�����P�Ӹ��X*/
			if (itag[0]=='\0' || itag[0]==' ' || (strcmp(icar_type,"27") == 0 && strcmp(chk_dpolicy,"Y") == 0)) 
			{
				strcat(prtstr,"            ");
				strcpy(t_itag," ");
			}
			else 
			{
				strcat(prtstr,itag);
				strcpy(t_itag,itag);
			}
			prtstr[134]='\0';
			
			rfmtdouble((qpt*10),"&&&&", buf1);
			if ((strlen(rtrim(buf1))) == 0) 
			{
				strcat(prtstr,"0050");
				t_qpt = 50;
			}
			else 
			{
				strcat(prtstr,buf1);              /*C135-138:�����ƶq*/  
				t_qpt = qpt;
			}
			
			if (strlen(trim(fpt)) == 0) 
			{
				strcat(prtstr,"P");
				strcpy(t_fpt,"P");
			}
			else 
			{
				strcat(prtstr,fpt);               /*C139-139:�������*/ 
				strcpy(t_fpt,fpt);
			} 
			prtstr[139]='\0';
			
			if (strcmp(sFassured, "1") == 0 || strcmp(sFassured, "3") == 0 || strcmp(sFassured, "5") == 0) 
			{
				/*�۵M�H*/
				/* car950512 */
				if( sFassured[0] == '1' )
				{
					strcat(prtstr, "1");
					strcpy(t_fassured,"1");
				}
				else if( sFassured[0] == '3' )
				{
					strcat(prtstr, "2");
					strcpy(t_fassured,"2");
				}
				else if( sFassured[0] == '5' )
				{
					strcat(prtstr, "8");
					strcpy(t_fassured,"8");
				}
				else
				{
					strcat(prtstr, "1");
					strcpy(t_fassured,"1");
				}
				/* car950512 */
				/*C140-140:�Q�O�I�H����*/
				strcat(prtstr, rtrim(iassured));
				strcpy(t_iassured,rtrim(iassured));
				for(i=0 ; i < (10-strlen(rtrim(iassured))); i++)
				strcat(prtstr, " ");					/*C141-150:�ҷӸ��X*/
				if ((strlen(rtrim(ibirth))) == 0) 
				{
					strcat(prtstr, "00000000");
					strcpy(t_dbirth,"00000000");
				}
				else
				{
					strcat(prtstr,rtrim(ibirth));          /*C151-158:�X�ͤ��-�褸*/
					strcpy(t_dbirth,ibirth);
					for(i=0 ; i < (8-strlen(rtrim(ibirth))); i++) strcat(prtstr, " ");
				}
				if (strlen(rtrim(fsex)) == 0) 
				{
					strcat(prtstr, "0");
					strcpy(t_fsex,"0");
				}
				else 
				{
					strcat(prtstr, rtrim(fsex));			/*C159-159:�ʧO�N��*/
					strcpy(t_fsex,fsex);
				}
				if (strlen(rtrim(fmarriage)) == 0) 
				{
					strcat(prtstr, "0");
					strcpy(t_fmarriage,"0");
				}
				else 
				{
					strcat(prtstr, rtrim(fmarriage));	/*C160-160:�B�çO�N��*/
					strcpy(t_fmarriage,fmarriage);
				}
			}
			else /*�k�H*/
			{ 
				/* car950512 */
				if (strlen(trim(iassured)) == 8)
				{
					strcat(prtstr, "3");					/*C141-150:�Q�O�I�H����*/
					strcpy(t_fassured,"3");
					strcat(prtstr, rtrim(iassured));		/*C151-158:�ҷӸ��X*/
					for(i=0 ; i < (10-strlen(rtrim(iassured))); i++) strcat(prtstr, " ");
					strcat(prtstr, "00000000");			/*C159-159:�X�ͤ��-�褸*/
					strcat(prtstr, "00");				/*C160-160:�ʧO�N��+�B�çO�N��*/
				}
				/* car950512 */
				else
				{
					/*strcat(prtstr, "AAAAAAAAAA");*/
					strcat(prtstr,"9");					/*C141-150:�Q�O�I�H����*/
					strcpy(t_fassured,"9");
					strcat(prtstr, rtrim(iassured));		/*C151-158:�ҷӸ��X*/
					for(i=0 ; i < (10-strlen(rtrim(iassured))); i++) strcat(prtstr, " ");
					strcat(prtstr, "00000000");			/*C159-159:�X�ͤ��-�褸*/
					strcat(prtstr, "00");				/*C160-160:�ʧO�N��+�B�çO�N��*/
				}
				strcpy(t_iassured,rtrim(iassured));
				strcpy(t_dbirth,"00000000");
				strcpy(t_fsex,"0");
				strcpy(t_fmarriage,"0");
			}
			
			/*C161-162:�W���ż�*/
			if ((strlen(rtrim(fcomp_class_last))) == 0) 
			{
				strcat(prtstr,"00");
				strcpy(t_fcomp_class_last,"00");
			}
			else if ((strlen(rtrim(fcomp_class_last))) == 1) 
			{
				sprintf_s(sTmp_buf, sizeof sTmp_buf, "0%d", atoi(fcomp_class_last));
				strcat(prtstr, sTmp_buf);
				strcpy(t_fcomp_class_last,sTmp_buf);
			} 
			else 
			{
				strcat(prtstr, fcomp_class_last);
				strcpy(t_fcomp_class_last,fcomp_class_last);
			}
			
			/*C163-164:�����ż�*/
			if(strcmp(trim(fcomp_class),"0")==0) 
			{
				strcpy(fcomp_class,"4");
			}
			
			if ((strlen(rtrim(fcomp_class))) == 0) 
			{
				strcat(prtstr,"04");
				strcpy(t_fcomp_class,"04");
			}
			else if ((strlen(rtrim(fcomp_class))) == 1) 
			{
				sprintf_s(sTmp_buf, sizeof sTmp_buf, "0%d", atoi(fcomp_class));
				strcat(prtstr, sTmp_buf);
				strcpy(t_fcomp_class,sTmp_buf);
			} 
			else 
			{
				strcat(prtstr, fcomp_class);
				strcpy(t_fcomp_class,fcomp_class);
			}
			
			/*C165-166:�����s��r���H�W����*/
			rfmtlong(qdrunk_driving,"&&",qdrunk_driving_c);      
			strcat(prtstr,qdrunk_driving_c);
			t_qdrunk_driving = qdrunk_driving;
			
			/*C167-176:�k�w�`�O�O*/
			if( mprem >= 0 )
				strcat(prtstr,"+");
			else 
				strcat(prtstr,"-");
			rfmtlong(mprem,"&&&&&&&&&",mprem_c);
			strcat(prtstr,mprem_c); 
			t_mprem = mprem;
			prtstr[176]='\0';
			
			/*C177-186:�`�O�O*/
			if( mins_premium >= 0 )
				strcat(prtstr,"+");
			else 
				strcat(prtstr,"-");
			rfmtlong(mins_premium,"&&&&&&&&&",mins_premium_c);
			strcat(prtstr,mins_premium_c);
			t_mins_premium = mins_premium;
			prtstr[186]='\0';
			
			/*C187-200:�«O�O*/
			madjcom_prem_l=dtol(madjcom_prem*10000);
			if( madjcom_prem >= 0 )
				strcat(prtstr,"+");
			else 
				strcat(prtstr,"-");        
			rfmtlong(madjcom_prem_l,"&&&&&&&&&&&&&",madjcom_prem_c);
			strcat(prtstr,madjcom_prem_c);
			t_madjcom_prem = madjcom_prem;
			prtstr[200]='\0';
			pure_total += madjcom_prem;
			
			/*C201-210:�~�ȶO��*/
			mbusiness_l=dtol(mbusiness*100);
			if( mbusiness_l >= 0 )
				strcat(prtstr,"+");
			else 
				strcat(prtstr,"-");
			rfmtlong(mbusiness_l,"&&&&&&&&&",mbusiness_c);
			strcat(prtstr,mbusiness_c);
			t_mbusiness = mbusiness;
			prtstr[210]='\0';
			
			/*211-220:�����O�I�O��*/
			maintain_l=dtol(maintain*100);
			if( maintain_l >= 0 )
				strcat(prtstr,"+");
			else 
				strcat(prtstr,"-");
			rfmtlong(maintain_l,"&&&&&&&&&",maintain_c);
			strcat(prtstr,maintain_c);
			t_maintain = maintain;
			prtstr[220]='\0';
			
			
			/*C221-230:�S�ɤ����B*/
			t_mcompensation = mcompensation;
			mcompensation *= 10000;
			if(mcompensation >= 0)
				strcat(prtstr,"+");
			else 
				strcat(prtstr,"-");
			rfmtdouble(mcompensation, "&&&&&&&&&", sTmp_buf);
			strcat(prtstr,sTmp_buf);
			prtstr[230]='\0';
			
			/*C231-240:�w�w���*/
			t_mstable = mstable;
			mstable *= 10000;
			if(mstable >= 0)
				strcat(prtstr,"+");
			else 
				strcat(prtstr,"-");
			rfmtdouble(mstable, "&&&&&&&&&", sTmp_buf);
			strcat(prtstr,sTmp_buf);
			prtstr[240]='\0';
			
			/*C241-247:�s��r���[�O*/
			if(mdrunk_prem >= 0)
			strcat(prtstr,"+");
			else 
			strcat(prtstr,"-");
			rfmtdouble(mdrunk_prem, "&&&&&&", sTmp_buf);
			strcat(prtstr,sTmp_buf);
			t_mdrunk_prem = mdrunk_prem;
			prtstr[247]='\0';
			
			/*248-258:�s��r���«O�O*/
			mdrunk_pure_prem_l=dtol(mdrunk_pure_prem*10000);
			/*mdrunk_pure_prem_l=mdrunk_pure_prem*10000;*/
			if(mdrunk_pure_prem_l >= 0)
			strcat(prtstr,"+");
			else 
			strcat(prtstr,"-");
			rfmtdouble(mdrunk_pure_prem_l, "&&&&&&&&&&", sTmp_buf);
			strcat(prtstr,sTmp_buf);
			tot_mdrunk_pure_prem += mdrunk_pure_prem;
			t_mdrunk_pure_prem = mdrunk_pure_prem;
			prtstr[258]='\0';
			
			/* �ӫ~�N�X */
			if ((strlen(rtrim(iproduct))) == 0) 
			{
				strcat(prtstr,"000000000000");
				strcpy(t_iproduct,"000000000000");
			}
			else 
			{
				strcat(prtstr,iproduct);  /* 259-270 �ӫ~�N�X */
				strcpy(t_iproduct,iproduct);
			}
			
			strncpy(iproduct_tmp,iproduct+3,2);
			iproduct_tmp[2] = '\0';
			printf("iproduct_tmp[%s] \n",iproduct_tmp);
			if (strcmp(iproduct_tmp,"14") == 0) 
			{
				mprem_14 += mins_premium;
				mprem_pure_14 += madjcom_prem;
			}
			else if (strcmp(iproduct_tmp,"15") == 0) 
			{
				mprem_15 += mins_premium;
				mprem_pure_15 += madjcom_prem;
			}
			else if (strcmp(iproduct_tmp,"16") == 0) 
			{
				mprem_16 += mins_premium;
				mprem_pure_16 += madjcom_prem;
			}
			else if (strcmp(iproduct_tmp,"32") == 0) 
			{
				mprem_32 += mins_premium;
				mprem_pure_32 += madjcom_prem;
			}
			
			sprintf_s(stmt, sizeof stmt, "SELECT to_char(drate, '%%Y%%m') FROM ca_rate_date \
			                WHERE itable = 'compulsory_premium' AND icode = ? ");
			$PREPARE get_drate FROM $stmt;
			$EXECUTE get_drate INTO $drate_yyyymm USING $drate_ym;
			
			if (SQLCODE == SQLNOTFOUND)
			{
				strcpy(drate_c, "92/01/01");
				cm_split_ymd_100(drate_c,drate_yy,drate_mm,drate_dd);
				/*if (drate_yy[0] == '\0' ) strcat(prtstr,"000000");*/
			}
			strcat(prtstr,drate_yyyymm);                /*271-276:�O�v�~��*/ 
			strcpy(t_drate_ym,drate_yyyymm);
			prtstr[276]='\0';
			
			strcpy(dpolicy_c,cm_cdate_str_100(dpolicy));
			cm_split_ymd_100(dpolicy_c,dply_yy,dply_mm,tmp_dd);
			
			if (dply_yy[0] == '\0' ) 
			{
				strcat(prtstr,"0000");
				strcpy(t_dpolicy_ym,"0000");
			}
			else 
			{
				dply_yyyy = atoi( dply_yy ) + 1911;
				rfmtlong(dply_yyyy,"&&&&",tmp_yyyy);
				strcat(prtstr,tmp_yyyy);
				strcpy(t_dpolicy_ym,tmp_yyyy);
			}
			if (dply_mm[0] == '\0') 
			{
				strcat(prtstr,"00");
				strcat(t_dpolicy_ym,"00");
			}
			else 
			{
				strcat(prtstr,dply_mm);            /*277-282:ñ��~��*/
				strcat(t_dpolicy_ym,dply_mm);
			}
			prtstr[282]='\0';
			
			strcat(prtstr,bzfrom);					/*281-282:�q���O�N�� 2009.2�W�C�榡*/
			strcpy(t_bzfrom,bzfrom);
			prtstr[284] = '\0';
			
			/* C283-290 ��ƻs�e�� */
			strcat(prtstr,ttday_yy);
			strcat(prtstr,ttday_mm);
			strcat(prtstr,ttday_dd);
			strcpy(t_dsend,ttday_yy);
			strcat(t_dsend,ttday_mm);
			strcat(t_dsend,ttday_dd);
			
			prtstr[292]='\0';         /* C283-290 ��ƻs�e�� */
			
			fprintf(fptr,"%s\n",prtstr);
			
			count1++; /*����*/ 
			
			strcpy(t_iedr_company," ");
			strcpy(t_iedr_br," ");
			strcpy(t_iendorse," ");
			strcpy(t_dedr_begin,"00000000");
			strcpy(t_dedr_end,"00000000");
			strcpy(t_iedr_type," ");
			printf("data_yyyymm[%s],ipolicy[%s],t_icard_company[%s],t_icard_br[%s],t_icard[%s],t_icard_last_company[%s],t_icard_last_br[%s],t_icard_last[%s] \n",
			        data_yyyymm,ipolicy,t_icard_company,t_icard_br,t_icard,t_icard_last_company,t_icard_last_br,t_icard_last);
			printf("t_iedr_company[%s],t_iedr_br[%s],t_iendorse[%s],t_iarea[%s],t_dedr_begin[%s],t_dedr_end[%s],t_dply_begin[%s],t_dply_end[%s],t_iobjno[%s],t_iissue_year[%s],t_ipro_year[%s] \n",
			        t_iedr_company,t_iedr_br,t_iendorse,t_iarea,t_dedr_begin,t_dedr_end,t_dply_begin,t_dply_end,t_iobjno,t_iissue_year,t_ipro_year);
			printf("t_ibrand[%s],t_icar_type[%s],t_icar_type_no[%s],t_qcylinder[%d],t_iengine[%s],t_itag[%s],t_qpt[%d],t_fpt[%s],t_fassured[%s],t_iassured[%s],t_dbirth[%s],t_fsex[%s],t_fmarriage[%s],t_fcomp_class_last[%s],t_fcomp_class[%s] \n",
			        t_ibrand,t_icar_type,t_icar_type_no,t_qcylinder,t_iengine,t_itag,t_qpt,t_fpt,t_fassured,t_iassured,t_dbirth,t_fsex,t_fmarriage,t_fcomp_class_last,t_fcomp_class);
			printf("t_iedr_type[%s],t_qdrunk_driving[%d],t_mprem[%d],t_mins_premium[%d],t_madjcom_prem[%f],t_mbusiness[%f],t_maintain[%f],t_mcompensation[%f],t_mstable[%f],t_mdrunk_prem[%d],t_mdrunk_pure_prem[%f] \n",
			        t_iedr_type,t_qdrunk_driving,t_mprem,t_mins_premium,t_madjcom_prem,t_mbusiness,t_maintain,t_mcompensation,t_mstable,t_mdrunk_prem,t_mdrunk_pure_prem);
			printf("t_iproduct[%s],t_drate_ym[%s],t_dpolicy_ym[%s],t_bzfrom[%s],t_dsend[%s] \n",
			        t_iproduct,t_drate_ym,t_dpolicy_ym,t_bzfrom,t_dsend);
	
			/* �d�s��� */
			sprintf_s(stmt, sizeof stmt,"INSERT INTO %s:ca_dev_ply_edr_comp \
			                     (data_yyyymm,idata,ipolicy,icard_company,icard_br,icard,icard_last_company,icard_last_br,icard_last, \
			                      iedr_company,iedr_br,iendorse,iarea,dedr_begin,dedr_end,dply_begin,dply_end,iobjno,iissue_year,ipro_year, \
			                      ibrand,icar_type,icar_type_no,qcylinder,iengine,itag,qpt,fpt,fassured,iassured,dbirth,fsex,fmarriage,fcomp_class_last,fcomp_class, \
			                      iedr_type,qdrunk_driving,mprem,mins_premium,madjcom_prem,mbusiness,maintain,mcompensation,mstable,mdrunk_prem,mdrunk_pure_prem, \
			                      iproduct,drate_ym,dpolicy_ym,bzfrom,dsend) \
			              VALUES(?,'P',?,?,?,?,?,?,?, \
			                     ?,?,?,?,?,?,?,?,?,?,?, \
			                     ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, \
			                     ?,?,?,?,?,?,?,?,?,?,?, \
			                     ?,?,?,?,?)",list[k].dbname);
			$PREPARE insert_ply_edr FROM $stmt;
			$EXECUTE insert_ply_edr using $data_yyyymm,$ipolicy,$t_icard_company,$t_icard_br,$t_icard,$t_icard_last_company,$t_icard_last_br,$t_icard_last,
			                              $t_iedr_company,$t_iedr_br,$t_iendorse,$t_iarea,$t_dedr_begin,$t_dedr_end,$t_dply_begin,$t_dply_end,$t_iobjno,$t_iissue_year,$t_ipro_year,
			                              $t_ibrand,$t_icar_type,$t_icar_type_no,$t_qcylinder,$t_iengine,$t_itag,$t_qpt,$t_fpt,$t_fassured,$t_iassured,$t_dbirth,$t_fsex,$t_fmarriage,$t_fcomp_class_last,$t_fcomp_class,
			                              $t_iedr_type,$t_qdrunk_driving,$t_mprem,$t_mins_premium,$t_madjcom_prem,$t_mbusiness,$t_maintain,$t_mcompensation,$t_mstable,$t_mdrunk_prem,$t_mdrunk_pure_prem,
			                              $t_iproduct,$t_drate_ym,$t_dpolicy_ym,$t_bzfrom,$t_dsend;
		} /* end of while */
	     
		$CLOSE scur_ply1;
		$FREE  scur_ply1;
	 }
     fclose(fptr);

     rfmtlong(prem_total,"&&&&&&&&&&&&",prem_c);
     res = getApHome(aphome);
     if (res<0) {
         printf("In sigalrmcatcher func==>read config file error!!\n");
         exit(1);
     }
 
    if(count1==0) fprintf(fptr_err,"%s\n","�L���!!");
    else
	{
		$WHENEVER SQLERROR GOTO errexit;
        /* �s����� */
        $SELECT iquota INTO $iquota FROM officer WHERE iofficer=$userid;

     	rtoday(&Today);     /* get today's datetime */
		printf("### Today[%d],ipolicy_br[%s],prem_total[%d],count1[%d]\n",
 		 Today,ipolicy_br,prem_total,count1);

        strcpy(Taipei_FullName, get_full_dbname("00"));

        sprintf_s(stmt, sizeof stmt,"DELETE FROM %s:ca_develop \
                WHERE iclass='9991' AND ibranch=? AND data_yyyymm = ? ",Taipei_FullName);
        printf("stmt[%s]\n",stmt);
        $PREPARE insert_cus1 FROM $stmt;
        $EXECUTE insert_cus1 USING $DBName,$data_yyyymm;

		sprintf_s(stmt, sizeof stmt,"INSERT INTO %s:ca_develop \
		              (iquota,data_yyyymm,iclass,dsend,ibranch, \
		               product_kind,iins_class,mprem,qcnt,pure_mprem,mdrunk_pure_prem) \
		              VALUES(?,?,'9991',?,?,'14','C',?,0,?,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus14 FROM $stmt;
		$EXECUTE insert_cus14 USING $iquota,$data_yyyymm,$Today,$DBName,$mprem_14,$mprem_pure_14;

		sprintf_s(stmt, sizeof stmt,"INSERT INTO %s:ca_develop \
		              (iquota,data_yyyymm,iclass,dsend,ibranch, \
		               product_kind,iins_class,mprem,qcnt,pure_mprem,mdrunk_pure_prem) \
		              VALUES(?,?,'9991',?,?,'15','C',?,0,?,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus15 FROM $stmt;
		$EXECUTE insert_cus15 USING $iquota,$data_yyyymm,$Today,$DBName,$mprem_15,$mprem_pure_15;

		sprintf_s(stmt, sizeof stmt,"INSERT INTO %s:ca_develop \
		              (iquota,data_yyyymm,iclass,dsend,ibranch, \
		               product_kind,iins_class,mprem,qcnt,pure_mprem,mdrunk_pure_prem) \
		              VALUES(?,?,'9991',?,?,'16','C',?,0,?,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus16 FROM $stmt;
		$EXECUTE insert_cus16 USING $iquota,$data_yyyymm,$Today,$DBName,$mprem_16,$mprem_pure_16;
		
		sprintf_s(stmt, sizeof stmt,"INSERT INTO %s:ca_develop \
		              (iquota,data_yyyymm,iclass,dsend,ibranch, \
		               product_kind,iins_class,mprem,qcnt,pure_mprem,mdrunk_pure_prem) \
		              VALUES(?,?,'9991',?,?,'32','C',?,0,?,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus32 FROM $stmt;
		$EXECUTE insert_cus32 USING $iquota,$data_yyyymm,$Today,$DBName,$mprem_32,$mprem_pure_32;

        printf("pure_total[%f]\n",pure_total);
        sprintf_s(stmt, sizeof stmt,"INSERT INTO %s:ca_develop \
                      (iquota,data_yyyymm,iclass,dsend,ibranch,product_kind,iins_class,mprem,qcnt,pure_mprem,mcompensation,mstable,mdrunk_pure_prem) \
                VALUES(?,?,'9991',?,?,'99','C',?,?,?,?,?,?)",Taipei_FullName);
        printf("stmt[%s]\n",stmt);

        $PREPARE insert_cus2 FROM $stmt;
        $EXECUTE insert_cus2
           USING $iquota,$data_yyyymm,$Today,$DBName,$prem_total,$count1,$pure_total,$tot_mcompensation,$tot_mstable,$tot_mdrunk_pure_prem;

		/*�έp29�I��*//*���έ��]�A�����s�]�X�Ӫ����*/
	}
	printf("END\n");
	fclose(fptr_err);
	return SUCCESS;

errexit:
	printf("userid=%s SOLCODE=%d sqlca.sqlerrm=%s\n",userid,SQLCODE,sqlca.sqlerrm);
	printf(errmsg,"userid=%s SOLCODE=%d sqlca.sqlerrm=%s",userid,SQLCODE,sqlca.sqlerrm);
	fprintf(fptr_err,"%d\n",SQLCODE);
	return SQLCODE;
}

long car9991_final()
{
	char sTmpMsg[1024];
	$char sfilename[81],stitle[1024],stmt[1024];
	$char DBName1[5];
	$long mprem, pure_mprem, qcnt;
	$double mdrunk_pure_prem;
	$char product_kind[3];
    
	$WHENEVER SQLERROR GOTO errexit;
	
	strcpy(DBName1,"00");
	if (db_select(DBName1) == False)  return M_CM_DB_NOTOPEN;
	
	$SELECT sum(mprem), sum(qcnt), sum(pure_mprem) ,sum(mdrunk_pure_prem)
	   INTO $mprem, $qcnt, $pure_mprem, $mdrunk_pure_prem
	   FROM ca_develop
	  WHERE iclass = '9991' AND product_kind = '99'
	    AND data_yyyymm = $data_yyyymm;

	sprintf_s(sTmpMsg, sizeof sTmpMsg, "%s%s\n", "���ɧ���:", file_catalog);
	sprintf_s(sTmpMsg, sizeof sTmpMsg, "%s�O�O=[%d] �«O�O=[%d] �s�r�«O�O=[%.4f] ����=[%d]\n",sTmpMsg, mprem, pure_mprem, mdrunk_pure_prem, qcnt );
	
	/*29�I���p�p����*/
	sprintf_s(stmt, sizeof stmt,"SELECT product_kind, sum(mprem), sum(qcnt), sum(pure_mprem) \
	                FROM ca_develop \
	               WHERE iclass = '9991' AND product_kind <> '99' AND data_yyyymm = '%s' \
	               GROUP BY product_kind order by 1",data_yyyymm);
	$PREPARE pre_29_kind1 FROM $stmt;
	$DECLARE cur_29_kind2 CURSOR FOR pre_29_kind1;
	$OPEN cur_29_kind2;
	while (1)
	{
		$FETCH cur_29_kind2 INTO $product_kind ,$mprem, $qcnt, $pure_mprem;
		if (SQLCODE == SQLNOTFOUND) break;
		sprintf_s(sTmpMsg, sizeof sTmpMsg, "%s�I��=[%s] �O�O=[%d] �«O�O=[%d] ����=[%d]\n",sTmpMsg, product_kind, mprem, pure_mprem, qcnt );
	}

	EWRITE(userid, M_CM_OK, sTmpMsg);
	exit(SUCCESS);
	isfinish(rtncode);

errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

