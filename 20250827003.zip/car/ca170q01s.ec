/**********************************************************************/
/*   program id   : ca170q01s.ec                                      */
/*   program name : �O�vTXT���s                                       */
/*   date written : 2021/03/22                                        */
/*   date modify  : yyyy/mm/dd                                        */
/**********************************************************************/

#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include "print.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "othmsgs.h"
#include "commsgs.h"
#include "sqlfatal.h"
#include "carmsgs.h"
#include "safeclib.h"

#define SUCCESS 1

char  	outputf[ N_FILE+1];
$char  	userid[11];
$char	DBName[5];
$char   iroute_p[21],iextra_charge_p[11],iins_type_p[INSURANCE_TYPE],drate_tmp[11],drate_p[11];

DBinfo  *list;
int     flen, count_db, i, j, k , count;
$char	v_sMsg[1024],sErrMsg[1024];
char	msgbuf[100];
$char   dtoday1[11];
$long	dsys;
$char   sWhere[512];

int iTryCnt,res1,iTryCnt2,res2;
int result;
char tar[512], gzip[121], cp[128], rm[128];
char  s[10],s1[10],s2[10],s3[10];
char    sApHome[30];
char    filename[30];
FILE    *fp;
int     flen;
$static char exec_time[20];

main(argc, argv)
int argc;
char **argv;
{
	int rc;
	char  Message[1024];

	batchinit();
	strcpy(DBName,          isNULLstr(argv[1]));
	strcpy(userid,          isNULLstr(argv[2]));
	strcpy(iroute_p,        isNULLstr(argv[3]));
	strcpy(iextra_charge_p, isNULLstr(argv[4]));
	strcpy(iins_type_p,     isNULLstr(argv[5]));
	strcpy(drate_tmp,       isNULLstr(argv[6]));
	strcpy(outputf,         isNULLstr(argv[7]));

	rc = car_get_db();
	if (rc != M_CM_OK) {
		printf("error on car_get_db\n");
		return rc;
	}
	
	strcpy(iroute_p,trim(iroute_p));
	strcpy(iextra_charge_p,trim(iextra_charge_p));
	strcpy(iins_type_p,trim(iins_type_p));
	strcpy(drate_p,cm_to_infdate(drate_tmp));

	 s[0] = '\0';
	s1[0] = '\0';
	s2[0] = '\0';
	s3[0] = '\0';
	strcpy(dtoday1,cm_cdate_str(cm_today()));
	cm_char_split_3ymd(dtoday1,s1,s2,s3);
	
	/**** ����ɶ� exec_time [YYYY-MM-DD HH:MM] ****/
	strcpy(exec_time, cm_get_sysd());
	printf("{car170.0001}:EXECUTE TIME[%s]\n",exec_time);
	/***********************************************/
	
	strncpy(filename," ",30);
	sprintf_s(filename, sizeof filename, "%s/rptftp/", sApHome);
	printf("{car162.0002}:filename[%s]\n",filename);
	
	/*�������*/
	rc = create_data();
	if ( rc != M_CM_OK ) {
	 	printf("error on create_data \n");
	 	EWRITE(userid, rc, sErrMsg);
		return rc;	
	}
	
	strcpy(Message,  "\n�Цܦ@�θ귽[N]/�d��[B]/�ɮפU���@�~[cmn202]�U���ɮ�!\n");
	
	EWRITE(userid,M_CM_OK,Message);

	printf("END PROGRAM\n");
	return SUCCESS;

errexit:
	printf("-- Query_card -- SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
	return SQLCODE;     
}

long car_get_db()
{
	int rc;
	if (db_select(DBName) == False) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "��Ʈw�L�k�}��!");
		return M_CM_DB_NOTOPEN;
	}
	
	rc = getApHome(sApHome);
	if (rc < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		EWRITE(userid,rc,msgbuf);
	 	return rc;
	}
	
	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}
	
	return M_CM_OK;
}

long create_data()
{
	$char stmt[2048];
	$char stmp1[256],stmp2[256],stmp3[256],stmp4[256];
	$char iins_cat[2],iyear[2],iextra_charge[11],iroute[21];
   	$char iins_type[INSURANCE_TYPE],drate[11];
   	$double pextra_charge = 0.0,pbusiness = 0.0;
	$char file_catalog[200];
	$char filename1[200];

	$WHENEVER SQLERROR GOTO errexit;
	$SET LOCK MODE TO WAIT;
	$BEGIN WORK;

	filename1[0]    = '\0';
	file_catalog[0] = '\0';
	
	sprintf_s(filename1, sizeof filename1, "car170_data.txt");
	strcpy(file_catalog, trim(filename));
	strcat(file_catalog, trim(filename1));
	
	fp=fopen(file_catalog,"w");

	if(strlen(iroute_p) == 0 || strncmp(iroute_p,"*",1) == 0)
		strcpy(stmp1," ");
	else
		sprintf_s(stmp1, sizeof stmp1, "AND iroute matches '%s' ",iroute_p);
		
	if(strlen(iextra_charge_p) == 0 || strncmp(iextra_charge_p,"*",1) == 0)
		strcpy(stmp2," ");
	else
		sprintf_s(stmp2, sizeof stmp2, "AND iextra_charge matches '%s' ",iextra_charge_p);
		
	if(strlen(iins_type_p) == 0 || strncmp(iins_type_p,"*",1) == 0)
		strcpy(stmp3," ");
	else
		sprintf_s(stmp3, sizeof stmp3, "AND iins_type matches '%s' ",iins_type_p);
	
	if(strlen(drate_p) == 0 || strncmp(drate_p,"*",1) == 0)
		strcpy(stmp4," ");
	else
		sprintf_s(stmp4, sizeof stmp4, "AND drate = '%s' ",drate_p);
	
	sprintf_s(stmt, sizeof stmt, "SELECT iins_cat,iyear,iextra_charge,iroute,iins_type,drate,pextra_charge,pbusiness "
	                " FROM cm_extra_charge "
	                " WHERE 1= 1 %s %s %s %s ",stmp1,stmp2,stmp3,stmp4);
	printf("stmt[%s]\n\n\n",stmt);
	$PREPARE data_out1 FROM $stmt;
	$DECLARE data_out CURSOR FOR data_out1;  
	$OPEN    data_out;	
	printf("-----> into drate_ym \n");
	for(;;)
	{
		$FETCH data_out INTO $iins_cat,$iyear,$iextra_charge,$iroute,$iins_type,$drate,$pextra_charge,$pbusiness;
		if (SQLCODE == SQLNOTFOUND) break;
		fprintf(fp,"%s\t%s\t%s\t%s\t%s\t%s\t%.4f\t%.4f\n",iins_cat,iyear,iextra_charge,iroute,iins_type,drate,pextra_charge,pbusiness);			
	}
	$CLOSE data_out;
	$FREE  data_out;
   
	fclose(fp);
        
	EXEC SQL INSERT INTO rptftplist (nuserid, ipgid,     noutfile,   dcreate)
	                         VALUES ($userid, 'car170',  $filename1, $exec_time);
	$COMMIT WORK;
	return M_CM_OK;
	
errexit:
    fclose(fp);
    printf("-- cm_extra_charge -- SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
    $ROLLBACK WORK;
    return SQLCODE;
}
