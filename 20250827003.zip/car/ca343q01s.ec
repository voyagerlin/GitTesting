/**********************************************************************/
/*   program id   : ca343q01s.ec                                      */
/*   program name : ���T���N�I����O��ƶפJ�@�~                      */
/*   date written : 2013/12/18                                        */
/*   date modify  : yyyy/mm/dd                                        */
/*   author       : Larry Liao                                        */                                       
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
#include "safeclib.h"

/****************************************************************************/
char msgbuf[2048],msgbuf1[2048],msgbuf2[256],msgbuf3[2048];
char sApHome[30];
$char DBName[05];
$char userid[11];
$char sDpolicy_bgn[11],sDpolicy_end[11];
$char date[11],dToday[11],nyy[4],nmm[3],ndd[3];
char  filename[200];
int   flen;
FILE  *fp;
DBinfo  *list;
$char sdata[500][73];
int   qcnt,qcnt1,count_db,i;
long  t;
$char GetFileName[80];
char  outputf[N_FILE+1];
/****************************************************************************/
main(argc, argv)
int argc;
char **argv;
{  
	  int rc;

    batchinit();
    strcpy(DBName, 		  (const char *)isNULLstr(argv[1]));
    strcpy(userid, 		  (const char *)isNULLstr(argv[2]));
    strcpy(GetFileName, (const char *)isNULLstr(argv[3]));
    strcpy(outputf,		  (const char *)isNULLstr(argv[4]));
	
	  printf("--GetFileName--[%s]\n",GetFileName);
	
    rc = car343_get_db();
    if (rc != M_CM_OK) {
        EWRITE(userid,rc,msgbuf);
        return rc;
	  }

    /* Ū���פJ�����N�I����O��� */
    rc = car343_read_data();
    if (rc != M_CM_OK) {
        EWRITE(userid,rc,msgbuf);
        return rc;
	  }
   		
   	return rc;	
}
/********************************************************************************/
long car343_read_data()
{
    char   *bp;
    int    rc,j,k,m,n,i;
    $int   iChkDays;
    
		printf("BEGIN TO READ DATA\n");    

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(GetFileName, trim(GetFileName));
    sprintf_s(filename, sizeof filename,"%s/dat/car/%s",sApHome,GetFileName);
    flen=1024;
    if ((fp=fopen(filename,"r"))==NULL) {
       sprintf_s(msgbuf, sizeof msgbuf,"%s �ɮ׶}�ҥ���",filename);
       EWRITE(userid,FALSE,msgbuf);
       return FALSE;
    }
    if ((bp=malloc(flen))==NULL) {
       sprintf_s(msgbuf, sizeof msgbuf,"System malloc failed !");
       EWRITE(userid,FALSE,msgbuf);
       return FALSE;
    }
    
		qcnt=qcnt1=0;
		strcpy(msgbuf1,"");
		
    for (i=0;(feof(fp)==0);i++) 
	  {
		    memset(bp,0x00,flen);
		    fgets(bp,flen,fp);
		        
		    if (bp[0]==0x00)	break;
		    if (strlen(trim(bp))<10)	break;
		        	
		    for(j=0;j<500;j++)
		    sdata[j][0]='\0';
		            
		    k=m=n=0;
		    for (j=0;j<flen;j++) 
		    {
		        if (bp[j]=='\0' || bp[j]=='\n' || bp[j] == '\"') 
					  {
		            strncpy(sdata[k],bp+m,j-m);
		            sdata[k][j-m]='\0';
		            m=j+1;
		            k++;
		        }
		        if (bp[j]=='\n')	break;
		        if (k > 35) break;
		    }      
				printf("sdata[%s][%s][%s][%s][%s]\n",sdata[1],sdata[3],sdata[5],sdata[7],sdata[9]);
				if (strncmp(sdata[1],"CNTRLREC",8) == 0) break;
				
		    rc = car343_insert_data();
		    if (rc != M_CM_OK)
		    {
		        strcat(msgbuf1,sdata[1]);
		        strcat(msgbuf1," ");
		        qcnt1++;
		        continue;
		    }
		    qcnt++;
		}	    
		    sprintf_s(msgbuf, sizeof msgbuf,"���T���N�I����O�����J����[%d]\n",qcnt);
		    sprintf_s(msgbuf2, sizeof msgbuf2,"��J���~����[%d]\n",qcnt1);
		    strcat(msgbuf,msgbuf2);
		    if (qcnt1 != 0)
		    {
		       sprintf_s(msgbuf3, sizeof msgbuf3,"�O�渹[%s]��Ʀ��~\n",msgbuf1);
		       strcat(msgbuf,msgbuf3);
		       return M_CM_FORMAT;
		    }
		    
    fclose(fp);
	free(bp);
	 
	  EWRITE(userid,M_CM_OK,msgbuf);
    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/***********************************�פJ�ɮ�******************************************/
long car343_insert_data()
{
    $char sIpolicy[21],sIins[5],sIassured[11],sItag[CA_TAG_NUM];
    $char sDply_end[11],sFno_next_type[2],sIstatus[4];
    $char ipolicy[21],dply_end[9],stmt[512];
    $int j;
    
    $WHENEVER SQLERROR GOTO errexit;
    
    printf("BEGIN INSERT INTO DATA\n"); 

	  $BEGIN WORK;
	  strcpy(ipolicy ,         sdata[1]);
    strcpy(sIins ,           sdata[3]);
    strcpy(sIassured ,       sdata[5]);
    strcpy(sItag ,           sdata[7]);
    strcpy(dply_end ,        sdata[9]);
    strcpy(sFno_next_type ,  sdata[11]);
    strcpy(sIstatus ,        sdata[13]);
    
    /* �O��e��X17����J��Ʈw */
    strcpy(ipolicy,trim(ipolicy));
    strcpy(sIpolicy, substring(ipolicy,3,18));

    /* �r���ഫ����榡 20131218 -> 12/18/2013 */
    strcpy(sDply_end,transdate(dply_end));

    if (strlen(sIins) == 0)  strcpy(sIins," ");
    if (strlen(sIassured) == 0) strcpy(sIassured," ");
    if (strlen(sIstatus) == 0)  strcpy(sIstatus," ");
    
    j = 0;
    sprintf_s(stmt, sizeof stmt,"INSERT INTO %s:ca_no_next_policy "
                 " VALUES (?,?,?,?,?,?,?,?,current)",list[j].dbname);
    $PREPARE no_next_cur FROM $stmt;
    $EXECUTE no_next_cur USING $sIpolicy,$sIins,$sIassured,$sItag,$sDply_end,
                               $sFno_next_type,$sIstatus,$userid;
      
    $COMMIT WORK;		
    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    $rollback work;
    return SQLCODE; 
}
/*********************************************************************************/ 
long car343_get_db()
{
	int return_code;

	if (db_select(DBName) == False) {
		strcpy(msgbuf,"��Ʈw�L�k�}��");
		return M_CM_DB_NOTOPEN;
	}
	return_code = getApHome(sApHome);
	if (return_code < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		return return_code;
  }
  if( (list=get_sysdb_list(&i,DBName)) == (char*)0 ){
    strcpy(msgbuf,"���٦U��Ʈw�W�٧䤣��");
    return M_CM_NOT_DBLIST;
  }
    
  return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/**************************************************************************/
/* �r���ഫ����榡 */                         
transdate(date)
char *date;
{
	 char trans_date[11];
	 strcpy(date,trim(date));
	 if(strlen(date) == 0)
	 {
	 	strcpy(trans_date,"");
	 }
	 else{	 
	  strcpy(trans_date,substring(date,5,2));
	  strcat(trans_date,"/");
	  strcat(trans_date,substring(date,7,2));
	  strcat(trans_date,"/");
	  strcat(trans_date,substring(date,1,4));
   }
}
    