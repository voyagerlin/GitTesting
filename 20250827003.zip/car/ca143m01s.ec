/*--------------------------------------------------*/
/*   PROGRAM : ca143m01s.ec by Julia Han            */
/*   DATE    : 2006/10/05                           */
/*   Checked 2008/08/14 for ����100�~�M��           */
/*--------------------------------------------------*/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;
#include <decimal.h>
#include <safeclib.h>

typedef struct {
    char   type;
    char   irisk[2];
    long    iyear;
    double mpure;
    double pextra_charge;
    char   dentry[20];
    } car143_t;

/*--------------------------------------------------*/
long car143(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	long rtncode;
	long car143_insert(),car143_single_query(),car143_multiple_query(),car143_update_exec();
	long car143_file();
	char option;

	cm_buf_init(command);
 	cm_buf_get("%c",&option);

 	switch(option)
 	{
	  	case 'A':
    			rtncode=car143_insert(reply);
        		break;
  		case 'Q':
    			rtncode=car143_single_query(reply);
        		break;
  		case 'M':
        		rtncode=car143_multiple_query(reply);
        		break;
  		case 'D':
  		case 'U':
        		rtncode=car143_update_exec(reply,command,com_len);
        		break;
        	case 'I':
        		rtncode=car143_file(reply);
        		break;
  		default :
    		if(exitsub(reply,M_CM_WRONG_OPTION) == True)
        		return M_CM_WRONG_OPTION;
           	return apiRC;
 	}
 	return(rtncode);
}

/*--------------------------------------------------*/
long car143_insert(reply)
serverReply reply;
{
	$char    DBName[3],irate[11],icar_flag[2],iparts[2];
   	$char    str_rows[3];
   	$long    qperiod,qmiles,iyear;
   	$char    irisk[2],ientry[11];
   	$double  mpure,pextra_charge;
        dec_t    dec_mpure,dec_pextra_charge;
       
        char     tmp_mpure[10],tmp_pextra_charge[9];
        char     tmp_qperiod[3],tmp_qmiles[10],tmp_iyear[5];
   	int      rows,tmp_len,i;
   	long     MsgCode;
   	DBinfo   *list;
   	int      k,j,is_add_fail=0, api_f;
   	$char    stmt_buf[500];
   	car143_t *alist;

   	cm_buf_get("%s %s %s %s %s %s %s",
		        DBName,irate,icar_flag,iparts,tmp_qperiod,tmp_qmiles,str_rows);

	qperiod = atol(tmp_qperiod);
	qmiles = atol(tmp_qmiles);
   	rows=atoi(str_rows);

   	if(db_select(DBName) == False)
   	{
    	if( exitsub(reply,M_CM_DB_NOTOPEN) == True )
        	return M_CM_DB_NOTOPEN;
      	return apiRC;
   	}
	/* $BEGIN WORK;*/
	/* because this is single table head-detail, so mark it */
 	/* $INSERT INTO compulsory_premium (icar_type,qperiod,mpremium)
            VALUES ($cartype,$insperiod,$premium); */
   	alist = (car143_t *) malloc(rows * sizeof (car143_t));

   	for (k=0; k<rows; k++)
   	{
    	cm_buf_get("%s %s %s %s",
		        irisk,tmp_iyear,tmp_mpure,tmp_pextra_charge);
		        	
	
	iyear = atol(tmp_iyear);

       	deccvasc( tmp_mpure, strlen(tmp_mpure), &dec_mpure);
       	dectodbl( &dec_mpure, &mpure);
       	deccvasc( tmp_pextra_charge, strlen(tmp_pextra_charge), &dec_pextra_charge);
       	dectodbl( &dec_pextra_charge, &pextra_charge);
      	
       	/*alist[k].qperiod= qperiod;
       	alist[k].qmiles=qmiles;*/
       	strcpy(alist[k].irisk,irisk);
       	alist[k].iyear=iyear;
       	alist[k].mpure=mpure;
       	alist[k].pextra_charge=pextra_charge;
   	}
   	
   	cm_buf_get("%s",ientry);

 	if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
  	{
   		if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    	return M_CM_NOT_DBLIST;
   		return apiRC;
  	}

	$BEGIN WORK;

 	for(j=0;j<i;j++)
 	{
    	sprintf_s(stmt_buf, sizeof stmt_buf, "INSERT INTO %s:ca_rate_ext "
      		   " (irate,icar_flag,iparts,qperiod,qmiles,irisk,iyear,mpure,pextra_charge,ientry,dentry) "
      	" VALUES (?,?,?,?,?,?,?,?,?,?,current)", list[j].dbname);
     	for (k=0; k<rows; k++)
     	{
        	$PREPARE b_id FROM $stmt_buf;
	 		/*qperiod = alist[k].qperiod;
  	 		qmiles = alist[k].qmiles;*/
	 		strcpy(irisk,alist[k].irisk);
	 		iyear=alist[k].iyear;
        		mpure=alist[k].mpure;
        		pextra_charge=alist[k].pextra_charge;
        		
        	$EXECUTE b_id
        		USING $irate,$icar_flag,$iparts,$qperiod,$qmiles,$irisk,$iyear,
        		      $mpure,$pextra_charge,$ientry;
        	if(SQLCODE != 0)
        	{
	        	is_add_fail = 3;
    	      	break;
       		}
    	}

     	if (is_add_fail == 3)
     	{
      		is_add_fail = 1;
		    break;
     	}

		cm_buf_init(ReplyBuf);
  		cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);
  		tmp_len = cm_buf_len(ReplyBuf);
  		if( j == i-1 )
    		api_f = api_OKComplete;
  		else
    		api_f = api_OK;

  		if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
    	{
    		is_add_fail = 2;
     		break;
    	}
 	} /* for loop */

	for (i = 0; i < rows; i++)
  		free( alist[i]);
	free ( (char *) alist);
	if( is_add_fail == 1 ) goto errexit;
	if( is_add_fail == 2 )
	{
   		$ROLLBACK WORK;
   		return apiRC;
  	}
   	$WHENEVER SQLERROR GOTO errexit;
   	$COMMIT WORK;
   	return api_OKComplete;

 errexit:
   	MsgCode = SQLCODE;
   	$WHENEVER SQLERROR CONTINUE;
   	$ROLLBACK WORK;
   	if( SQLCODE != 0) MsgCode = SQLCODE;
   	if(exitsub(reply,MsgCode) == True)
    	return MsgCode;
   	else
    	return apiRC;
}

/*--------------------------------------------------*/
long car143_single_query(reply)
serverReply reply;
{
    $char   DBName[3],irate[11],icar_flag[2],iparts[2];
    $char   irisk[2],ientry[11],dentry[20],iupdate[11],dupdate[20];
    $long   qperiod,qmiles,iyear = 0;
    $double mpure = 0.0,pextra_charge = 0.0;
    dec_t   dec_mpure,dec_pextra_charge;
    char    tmp_mpure[10],tmp_pextra_charge[9];
    int     rows=0,tmp_len;
    char    strtmp1[50],strtmp2[50];
    
    char    tmp_qperiod[3],tmp_qmiles[10],tmp_iyear[5];

    cm_buf_get("%s %s %s %s %s %s",DBName,irate,icar_flag,iparts,
    		tmp_qperiod,tmp_qmiles);
    		
    qperiod = atol(tmp_qperiod);
    qmiles = atol(tmp_qmiles);
    /*iyear = atol(tmp_iyear);*/

printf("DBname[%s];;irate[%s];;icar_flag[%s];;iparts[%s]\n",DBName,irate,icar_flag,iparts);
printf("qperiod[%ld];;qmiles[%ld]\n",qperiod,qmiles);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    	return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    cm_buf_init(ReplyBuf);
    cm_buf_res_msg();
    cm_buf_res_count();

    $DECLARE q_cur CURSOR for
      SELECT irisk,iyear,mpure,pextra_charge,dentry,ientry,dupdate,iupdate
        INTO $irisk,$iyear,$mpure,$pextra_charge,$dentry,$ientry,$dupdate,$iupdate
        FROM ca_rate_ext
       WHERE irate = $irate 
         AND icar_flag = $icar_flag
         AND iparts = $iparts
         AND qperiod = $qperiod
         AND qmiles = $qmiles;
         /*AND irisk = $irisk
         AND iyear = $iyear;*/

     $OPEN q_cur;
     
     /*cm_buf_put("%s %s %s",irate,icar_flag,iparts);*/

     for(;;)
   	{
    	$FETCH q_cur;
      	if (SQLCODE != 0) break;
      
      	cm_buf_put("%s %s %s",irate,icar_flag,iparts);
        cm_buf_put("%l %l %s %l",qperiod,qmiles,irisk,iyear);
      
	rows++;

      	sprintf_s(strtmp1, sizeof strtmp1, "%.3f",mpure);
      	sprintf_s(strtmp2, sizeof strtmp2, "%.4f",pextra_charge);

	cm_buf_put("%s %s",strtmp1,strtmp2);
	cm_buf_put("%s %s %s %s",dentry,ientry,dupdate,iupdate);
	}
printf("strtmp1[%s];;strtmp2[%s]\n",strtmp1,strtmp2);
printf("dentry[%s];;no. of rows=[%d]\n",dentry,rows);
	
     $CLOSE q_cur;
     $FREE q_cur;

     if(rows > 0 || SQLCODE==0)      /* at least one row is selected */
   	{
    	cm_buf_put_msg(M_CM_OK);
      	cm_buf_put_count(rows);
      	tmp_len = cm_buf_len(ReplyBuf);
      	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        	return apiRC;
      	else
        	return api_OKComplete;
   	}
     else
   	{
    	if( exitsub(reply,M_CA_NRATE) == True )
        	return M_CA_NRATE;
      	return apiRC;
   	}

errexit:
	if ( exitsub(reply,SQLCODE) == True )
    	return SQLCODE;
   	return apiRC;
}

/*--------------------------------------------------*/
long car143_multiple_query(reply)
serverReply reply;
{
	$char   DBName[3],irate[11],icar_flag[2],iparts[2],irisk[2];
   	$long   qperiod = 0,qmiles = 0,iyear;
   	$char   str_mpure[10],str_pextra_charge[9];
   	$double mpure,pextra_charge;
   	char    tmpbuf[4000];
   	dec_t   dec_mpure,dec_pextra_charge;
   	int     count=0,repbuf_len=0,tmp_len=0,replycnt=0;
   	int     i,total_count=0,flag;
   	char    tmp_qperiod[3],tmp_qmiles[10];

        cm_buf_get("%s %s %s %s",DBName,irate,icar_flag,iparts);

   	$WHENEVER SQLERROR GOTO errexit;

   	if (db_select(DBName) == False)
   	{
    	if( exitsub(reply,M_CM_DB_NOTOPEN) == True )
        	return M_CM_DB_NOTOPEN;
      	return apiRC;
   	}

       $DECLARE m1_cur CURSOR FOR
         SELECT irate,icar_flag,iparts,qperiod,qmiles
           INTO $irate,$icar_flag,$iparts,$qperiod,$qmiles
           FROM ca_rate_ext
          WHERE irate matches $irate 
            AND icar_flag matches $icar_flag
            AND iparts matches $iparts 
       GROUP BY irate,icar_flag,iparts,qperiod,qmiles
       ORDER BY irate,icar_flag,iparts;

	$OPEN m1_cur;

   	for(;;)
   	{
    	$FETCH m1_cur;
     	if (SQLCODE != 0) break;

      	cm_buf_init(tmpbuf);

      	if ( count == 0 )
      	{
        	cm_buf_res_msg();             /* reserve for MsgCode and count */
         	cm_buf_res_count();
      	}

      	cm_buf_put("%s %s %s %l %l",irate,icar_flag,iparts,qperiod,qmiles);
      	/*cm_buf_put("%s %s %s",irate,icar_flag,iparts);*/

      	tmp_len = cm_buf_len(tmpbuf);

      	if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
      	{
        	memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
         	repbuf_len += tmp_len;
         	count++;
     	}
      	else                               /* more than 4K, send to client side */
      	{
        	cm_buf_init(ReplyBuf);
         	cm_buf_put_msg(M_CM_OK);
         	cm_buf_put_count(count);
         	if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
         	{
            	$CLOSE m1_cur;
	    		$FREE m1_cur;
            	return apiRC;
			}
        	else               /* clear ReplyBuf and count to start all over again */
        	{
            	replycnt++;
	            if (replycnt == 10)   /* more than 30K, client cannot display,error */
    	        {
        	       	cm_buf_init(ReplyBuf);
            	   	cm_buf_put("%l",M_CM_OUT_SPACE);
	               	tmp_len = cm_buf_len(ReplyBuf);
               		if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
                  	return apiRC;
               		return M_CM_OUT_SPACE;
            	}
            	ReplyBuf[0] = '\0';
            	count = 0;
            	cm_buf_init(ReplyBuf);
            	cm_buf_res_msg();           /* reserve for MsgCode and count */
            	cm_buf_res_count();
            	
      		cm_buf_put("%s %s %s %l %l",irate,icar_flag,iparts,qperiod,qmiles);
      		/*cm_buf_put("%s %s %s",irate,icar_flag,iparts);*/
            	repbuf_len = cm_buf_len(ReplyBuf);
            	count++;
        	}
	 }
	} /* for loop */

   	$CLOSE m1_cur;
   	$FREE m1_cur;

   	if (count > 0)   /* break out, at least one record is selected */
   	{
      	cm_buf_init(ReplyBuf);
      	cm_buf_put_msg(M_CM_OK);
      	cm_buf_put_count(count);
      	if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
        	return apiRC;
      	return api_OKComplete;
   	}
   	else            /* break out, not any raw is found */
   	{
    	if( exitsub(reply,M_CA_NRATE) == True )
        	return M_CA_NRATE;
      	return apiRC;
   	}

errexit:
   	if ( exitsub(reply,SQLCODE) == True )
    	return SQLCODE;
   	return apiRC;
}

/*--------------------------------------------------*/
long car143_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
   /* Variables for db usage */
	$char   DBName[3],irate[11],icar_flag[2],iparts[2],irisk[2];
	$char   irate_old[11],icar_flag_old[2],iparts_old[2],irisk_old[2];
   	$long   qperiod,qmiles,iyear;
   	$long   qperiod_old,qmiles_old,iyear_old;
   	$double mpure,pextra_charge;
   	$double mpure_old,pextra_charge_old;
   	$char   dbdate[20],dbdate_old[20];
   	$char   iupdate[11];
   /* Variable for db usage ends */
   	
   /* For transfer to different data type */
    dec_t  dec_mpure,dec_pextra_charge;
    dec_t  dec_cur_mpure,dec_cur_pextra_charge;
    char   tmp_mpure[10],tmp_pextra_charge[9];
    char   tmp_cur_mprem[21],tmp_cur_pextra_charge[21];
    char   tmp_qperiod[3],tmp_qmiles[10],tmp_iyear[5];
   /* For transfer to different data type ends */
   
   /* Program variables declare */
    /*int    tmp_len,raw_len,count,rows=0,i,flag,count1,y;*/
    int    tmp_len,rows=0;
    char   *comm,type,option;
    char   strtmp1[50],strtmp2[50];
    $char  stmt_buf[500];
    car143_t *alist;
    DBinfo   *list;
    long   MsgCode;
    int   k, j, is_del_fail=0, is_upd_fail=0;
   	
   	
   	comm = (char *) command;
   	cm_buf_init(command);
   	cm_buf_get("%c %s",&option,DBName);

   	$WHENEVER SQLERROR GOTO errexit;

   	if (db_select(DBName) == False)
    	return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
    	
    	$BEGIN WORK;
 		$WHENEVER SQLERROR GOTO errexit;
		$LOCK TABLE ca_rate_ext IN SHARE MODE;


   	if( option == 'D' )
   	{
   	  /* Get delete data (not repeated part)*/
   	        cm_buf_init(command);
      	  	cm_buf_get("%c %s",&option,DBName);
      		cm_buf_get("%s %s %s %s %s",irate_old,icar_flag_old,iparts_old,tmp_qperiod,tmp_qmiles);
      		
      		qperiod_old = atol(tmp_qperiod);
    		qmiles_old = atol(tmp_qmiles);
    		
      		cm_buf_get("%d",&rows);
      		
      		for (k = 0; k <rows; k++)
      		{
      	  	   /* Get delete data (repeated part)*/
    			cm_buf_get("%s %s %s",irisk_old,tmp_iyear,dbdate_old);
    		   /* Get delete data (repeated part) ends*/
    				
    		   /* Attribute transfer */
    		   	iyear_old = atol(tmp_iyear);
    		   /* transformation ends */
    		   
    		   /* Get original date in database */
    		   
    		   	/*$BEGIN WORK;
 			      $WHENEVER SQLERROR GOTO errexit;
			      $LOCK TABLE ca_rate_ext IN SHARE MODE;*/
			
    		   	$SELECT dentry
    		   	 INTO $dbdate
    		   	 FROM ca_rate_ext
    		   	 WHERE irate = $irate_old
    		   	 AND icar_flag = $icar_flag_old
    		   	 AND iparts = $iparts_old
    		   	 AND qperiod = $qperiod_old
    		   	 AND qmiles = $qmiles_old
    		   	 AND irisk = $irisk_old
    		   	 AND iyear = $iyear_old;
    		   	 
    		   	 if (SQLCODE == SQLNOTFOUND)
        		{
    				$WHENEVER SQLERROR CONTINUE;
    				$ROLLBACK WORK;
    				if (exitsub(reply,M_CM_NOT_FOUND) == True)
        				return M_CM_NOT_FOUND;
    				else
        				return apiRC;
    			}
    		   /* Get original date in database ends */
    		   
    		   /* Comparing date to make sure that data can be deleted */
    		   	if (strcmp(dbdate,dbdate_old) != 0)
        		{
printf("dates are different");
    				$WHENEVER SQLERROR CONTINUE;
    				$ROLLBACK WORK;
    				if(exitsub(reply,M_CM_NOT_EQUAL) == True)
        				return M_CM_NOT_EQUAL;
    				else
        				return apiRC;
    			}
    		   /* Comparing date to make sure that data can be deleted ends */
    		   	
      			sprintf_s(stmt_buf, sizeof stmt_buf,
         		"DELETE FROM ca_rate_ext WHERE irate=? AND icar_flag=? "
         		" AND iparts=? AND qperiod=? AND qmiles=? AND irisk=? AND iyear=? ");
       			$PREPARE d_id FROM $stmt_buf;
       			$EXECUTE d_id USING $irate_old,$icar_flag_old,$iparts_old,
       					$qperiod_old,$qmiles_old,$irisk_old,$iyear_old;
     		}
     		
     		/*cm_buf_get("%s",iupdate);*/
     		
     		cm_buf_init(ReplyBuf);
     		cm_buf_put("%l", M_CM_OK);
     		tmp_len = cm_buf_len(ReplyBuf);
     		if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
     		{
        		$WHENEVER SQLERROR CONTINUE;
         		$ROLLBACK WORK;
         		return apiRC;
     		}
     		$WHENEVER SQLERROR GOTO errexit;
     		$COMMIT WORK;
     		return api_OKComplete;
   	}
   	else if(option == 'U')
   	{
    		cm_buf_init(command);
      		cm_buf_get("%c %s",&option,DBName);
      		cm_buf_get("%s %s %s %s %s",irate,icar_flag,iparts,tmp_qperiod,tmp_qmiles);
		
		qperiod = atol(tmp_qperiod);
    		qmiles = atol(tmp_qmiles);
    		
      		cm_buf_get("%d",&rows);
      		alist = (car143_t *) malloc(rows *sizeof (car143_t));
      		
      		/*$BEGIN WORK;
 				$WHENEVER SQLERROR GOTO errexit;
				$LOCK TABLE ca_rate_ext IN SHARE MODE;*/
      		
      		for (k = 0; k <rows; k++)
      		{
       		   /* Get update data (repeated part)*/
    			cm_buf_get("%c %s %s %s %s %s",&type,irisk,
    				tmp_iyear,tmp_mpure,tmp_pextra_charge,dbdate_old);
    		   /* Get delete data (repeated part) ends*/
    				
    		   /* Attribute transfer */
    		   	iyear = atol(tmp_iyear);
    		   	deccvasc( tmp_mpure, strlen(tmp_mpure), &dec_mpure);
       			dectodbl( &dec_mpure, &mpure);
       			deccvasc( tmp_pextra_charge, strlen(tmp_pextra_charge), &dec_pextra_charge);
       			dectodbl( &dec_pextra_charge, &pextra_charge);
       			
       			alist[k].type = type;
       			/*alist[k].qperiod = qperiod;
       			alist[k].qmiles = qmiles;*/
       			strcpy(alist[k].irisk,irisk);
       			alist[k].iyear = iyear;
       			alist[k].mpure=mpure;
       			alist[k].pextra_charge=pextra_charge;
       			strcpy(alist[k].dentry,dbdate_old);
    		   /* transformation ends */
    		  }
    		  
    		  cm_buf_get("%s",iupdate);
printf("update iupdate[%s]\n",iupdate);
	   
    		/*$WHENEVER SQLERROR GOTO errexit;*/
    		
        	for(k=0; k < rows; k++)
		{
			/*qperiod = alist[k].qperiod;
			qmiles = alist[k].qmiles;*/
			strcpy(irisk,alist[k].irisk);
			iyear = alist[k].iyear;
			mpure = alist[k].mpure;
			pextra_charge = alist[k].pextra_charge;
			strcpy(dbdate_old,alist[k].dentry);
			
			 /* Get original date in database */
    		   
    		   /*$BEGIN WORK;
 				$WHENEVER SQLERROR GOTO errexit;
				$LOCK TABLE ca_rate_ext IN SHARE MODE;*/
			
    		   		$SELECT dentry
    		   	 	INTO $dbdate
    		   	 	FROM ca_rate_ext
    		   	 	WHERE irate = $irate
    		   	 	AND icar_flag = $icar_flag
    		   	 	AND iparts = $iparts
    		   	 	AND qperiod = $qperiod
    		   	 	AND qmiles = $qmiles
    		   	 	AND irisk = $irisk
    		   	 	AND iyear = $iyear;
  		   	 
    		   	 	if (SQLCODE == SQLNOTFOUND)
        			{
    					$WHENEVER SQLERROR CONTINUE;
    					$ROLLBACK WORK;
    					if (exitsub(reply,M_CM_NOT_FOUND) == True)
        					return M_CM_NOT_FOUND;
    					else
        					return apiRC;
    				}
    		   	/* Get original date in database ends */
    		   	
    		   	/* Comparing date to make sure that data can be deleted */
    		   		if (strcmp(dbdate,dbdate_old) != 0)
        			{
printf("dates are different");
    					$WHENEVER SQLERROR CONTINUE;
    					$ROLLBACK WORK;
    					if(exitsub(reply,M_CM_NOT_EQUAL) == True)
        					return M_CM_NOT_EQUAL;
    					else
        					return apiRC;
    				}
    		   /* Comparing date to make sure that data can be deleted ends */

printf("what is the type?[%c]\n",alist[k].type);          		
                  switch(alist[k].type)
                  {
                	case 'A':
                    		sprintf_s(stmt_buf, sizeof stmt_buf,
                    		"INSERT INTO ca_rate_ext "
                            "       (irate,icar_flag,iparts,qperiod,qmiles,irisk,iyear, "
                            "        mpure,pextra_charge,dentry,ientry) "
                         	" VALUES (?,?,?,?,?,?,?,?,?,current,?)");
                         	
				$PREPARE u1_id FROM $stmt_buf;
				$EXECUTE u1_id USING $irate,$icar_flag,$iparts,$qperiod,$qmiles,
					$irisk,$iyear,$mpure,$pextra_charge,$iupdate;
				if(SQLCODE != 0)
                        		is_upd_fail = 3;
				break;
				
			case 'D':
                    		sprintf_s(stmt_buf, sizeof stmt_buf,
                    		"DELETE FROM ca_rate_ext "
                       	  	" WHERE irate = ? AND icar_flag = ? AND iparts = ? "
                       	  	" AND qperiod = ? AND qmiles = ? AND irisk = ? "
                       	  	" AND iyear = ?");
                       	    		
				$PREPARE u2_id FROM $stmt_buf;
                        	$EXECUTE u2_id USING $irate,$icar_flag,$iparts,$qperiod,
                        		$qmiles,$irisk,$iyear;
                        		
				if(SQLCODE != 0)
                        		is_upd_fail = 3;
				break;
				
                    	case 'U':
                       		sprintf_s(stmt_buf, sizeof stmt_buf, "UPDATE ca_rate_ext "
                                 " SET (irate,icar_flag,iparts,qperiod,qmiles,irisk,iyear, "
                                 " mpure,pextra_charge,dupdate,iupdate) "
                                 " = (?,?,?,?,?,?,?,?,?,current,?) "
                                 " WHERE irate = ? AND icar_flag = ? AND iparts = ? "
                       	  		 " AND qperiod = ? AND qmiles = ? AND irisk = ? "
                       	  		 " AND iyear = ?");
                            	
                       		$PREPARE u3_id FROM $stmt_buf;
                       		$EXECUTE u3_id USING $irate,$icar_flag,$iparts,$qperiod,$qmiles,
                       			$irisk,$iyear,$mpure,$pextra_charge,$iupdate,
                       			$irate,$icar_flag,$iparts,$qperiod,$qmiles,$irisk,$iyear;

				if(SQLCODE != 0)
                           		is_upd_fail = 3;
				break;
				
			default:
                        	$WHENEVER SQLERROR CONTINUE;
                        	$ROLLBACK WORK;
                        	if(exitsub(reply,M_CM_WRONG_OPTION) == True)
                        		return M_CM_WRONG_OPTION;
				else
                           		return apiRC;
		  }
		}
		
		for (int i = 0; i < rows; i++)
			free( alist[i]);
		free ( (char *) alist);

printf("see if it passed...[%s]\n",stmt_buf);	
    		cm_buf_init(ReplyBuf);
    		cm_buf_put("%l",M_CM_OK);
    		tmp_len = cm_buf_len(ReplyBuf);
    	
    		if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    		{
    			$WHENEVER SQLERROR CONTINUE;
        		$ROLLBACK WORK;
        		return apiRC;
    		}
		$WHENEVER SQLERROR GOTO errexit;
    		$COMMIT WORK;
    		return api_OKComplete;
   	}
   	else    /* option is not 'D' or 'U' */
   	{
    		return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
   	}

errexit:
	MsgCode = SQLCODE;
	$WHENEVER SQLERROR CONTINUE;
   	$ROLLBACK WORK;
   	if( SQLCODE != 0) MsgCode = SQLCODE;
   	return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
/*--------------------------------------------------*/
long car143_file(reply)
{
int   rc;
$int  cnt = 0;
$char  DBName[3],stmt[2048];
$char  localdb[41],tbname[50];
char  cmd_str[2048];
char  errbuf[128];
int   stmt_len;

char    sApHome[30];
char    filename[50],logname[50];
char    msgbuf[1000];
char    userid[11],outputf[21];
char    ctype[1];
int     itype = 0,tmp_len;
long  MsgCode;

   /* ���o��Ʈw�W�� */
   
   cm_buf_get("%s",DBName);
    		
   $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    	return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
	
   rc = getApHome(sApHome);
   if (rc<0) {
      strcpy(msgbuf,"read Config file error!!-->getApHome\n");
      /*EWRITE(userid,rc,msgbuf);
      return rc;*/
      return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;  /****need to correct error msg ****/
   }

   sprintf_s(filename, sizeof filename, "%s/dat/car/car143.txt", sApHome);
   sprintf_s(logname, sizeof logname, "%s/rptftp/car143_log.txt",sApHome);

   if (db_select(DBName) == FALSE) {
      /*EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;*/
      return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
   }
   
printf("it starts with here\n");   
   cm_buf_get("%s %s",localdb,tbname);
 
printf("dbname[%s],localdb[%s],tbname[%s]\n",DBName,localdb,tbname);  
   /* ���ɵ{�� */
   $whenever sqlerror goto errexit;

   strcpy(stmt," ");
   sprintf_s(stmt, sizeof stmt, "select count(*) from %s ",tbname);
   $prepare pre_cnt from $stmt;
   $execute pre_cnt into $cnt;
   strcpy(msgbuf,"�즳���:");
   sprintf_s(msgbuf, sizeof msgbuf, "%s[%d]",trim(msgbuf),cnt);

   /* ����J�Ȧs��,�T�{��J���O�_���T */
   stmt_len = 0;
   stmt_len += sprintf_s(stmt+stmt_len, sizeof stmt,
              "select * from %s where 1=0 into temp temp1 with no log;\r\n",
               tbname);
   stmt_len += sprintf_s(stmt+stmt_len, sizeof stmt,
                      "load from %s delimiter '\t' insert into temp1; \r\n",
                       filename);
   sprintf_s(cmd_str, sizeof cmd_str, "dbaccess %s > %s 2>&1 << !\r\n"
                   "%s\r\n!",
           localdb,logname,stmt);
   printf("cmd_str[%s]\n",cmd_str);
   rc = system(cmd_str);
   if (rc != 0) {
       sprintf_s(errbuf, sizeof errbuf, "load file error[%s]\n"
                      "���I���ɮפU���@�~�d��[Q],�T�{���~��]",
               logname);
       /*EWRITE(userid,rc,errbuf);
       return rc;*/
       return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
   } 
   /* ��J�����ɮ� */
   stmt_len = 0;
   if (itype==1)
   {
       stmt_len += sprintf_s(stmt+stmt_len, sizeof stmt, "delete from %s where 1=1;\r\n",
                   tbname);
   }
       
   stmt_len += sprintf_s(stmt+stmt_len, sizeof stmt,
              "select * from %s where 1=0 into temp temp1 with no log;\r\n",
               tbname);
   stmt_len += sprintf_s(stmt+stmt_len, sizeof stmt,
                      "load from %s delimiter '\t' insert into temp1; \r\n",
                       filename);
   stmt_len += sprintf_s(stmt+stmt_len, sizeof stmt,
                      "insert into %s select * from temp1;\r\n",
                       tbname);
   sprintf_s(cmd_str, sizeof cmd_str, "dbaccess %s > %s 2>&1 << !\r\n"
                   "%s\r\n!",
           localdb,logname,stmt);
   printf("cmd_str[%s]\n",cmd_str);
   rc = system(cmd_str);
   if (rc != 0) {
       sprintf_s(errbuf, sizeof errbuf, "load file error[%s]\n"
                      "���I���ɮפU���@�~�d��[Q],�T�{���~��]",
               logname);
       /*EWRITE(userid,rc,errbuf);
       return rc;*/
       return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;   /****need to correct error msg ****/
   } 

   $execute pre_cnt into $cnt;
   strcat(msgbuf,"  �{�����:");
   sprintf_s(msgbuf, sizeof msgbuf, "%s[%d]",msgbuf,cnt);

   /*rc=rptftpinsert(userid,"car143","car143_log.txt");*/
        /*if (rc!=0) {
                /*EWRITE(userid,rc,"�g�Jrptftplist���~\r\n");
                return rc;
                return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;  /****need to correct error msg
        }*/
   /*EWRITE(userid,3500,msgbuf);*/
   
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
    	
    if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    	{
    		$WHENEVER SQLERROR CONTINUE;
        	return apiRC;
    	}
    $WHENEVER SQLERROR GOTO errexit;
  
   return api_OKComplete;
   
errexit:
   	MsgCode = SQLCODE;
   	$WHENEVER SQLERROR CONTINUE;
   	$ROLLBACK WORK;
   	if( SQLCODE != 0) MsgCode = SQLCODE;
   	if(exitsub(reply,MsgCode) == True)
    	return MsgCode;
   	else
    	return apiRC;
  
}