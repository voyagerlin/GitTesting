/**********************************************************************/
/*   program id   : ca637q01s.ec                                    */
/*   program name : �O���k��                                          */
/*   date written : 2015/05/25 by 030344                              */
/*   files        : policy                                            */
/*                                                                    */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"

#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "cmnmsgs.h"
#include "cmprint.h"
#include "print.h"
#include "safeclib.h"
$include decimal;

int   count_db,k;

$char FormFile[N_FILE+1],OutFile[20];
$char FormTp[3];
$int  StartRow,TitleRow;
$int  PgLine, Width;
int   max_count;

$char chkComp[2];

char outputf[20];
$char userid[11];
$char DBName[05];
$char ibranch[3];
$char ipolicy_bgn[11],ipolicy_end[11];
$char msgbuf[128];
$char option[2];
$char falldb[2];
$char ipolicy[21],dpolicy[11],iofficer[11],nofficer[11];
$long number;
$char stmt[4096];

DBinfo *list;
/*--------------------------------------------------------------------*/

main(argc, argv)
int argc;
char **argv;
{
    int rc;

    batchinit();
    strcpy(DBName,      isNULLstr(argv[1]));
    strcpy(userid,      isNULLstr(argv[2]));
    strcpy(ipolicy_bgn, isNULLstr(argv[3]));
    strcpy(ipolicy_end, isNULLstr(argv[4]));
    strcpy(outputf,     isNULLstr(argv[5]));

printf("outputf[%s]\n",outputf);

    rc = car637_get_db();
    if (rc != M_CM_OK)
       return rc;

    /* Create table car346_tmp1 */
    rc = car637_create_temp();
    if (rc != M_CM_OK)
       return rc;

    /*prepare data for report*/
    rc = car637_prepare_data();
    if (rc != M_CM_OK)
    	return rc;

    rc = car637_body();
    if (rc != M_CM_OK)
    	return rc;

    if(rc=(save_form_info(F_FREE,"CA",637,userid,FormTp,max_count,outputf))<0)
       EWRITE(userid,rc,"save_form_info failed");

    return M_CM_OK;

}

/*--------------------------------------------------------------------*/
long car637_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }

   if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
      if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
         return M_CM_NOT_DBLIST;
   }

   return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/
long car637_prepare_data()
{
   int    rc;
   $char ply_bgn[11],ply_end[11];

   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == FALSE)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return FAIL;
   }

   number = 0;
/*
    for(k=0;k<count_db;k++)
    {
*/
	 sprintf_s(stmt, sizeof stmt,
		"SELECT a.ipolicy, b.dpolicy, b.iofficer, c.nname "
		"  FROM policy a,ply_relation b,officer c  "
		" WHERE a.ipolicy = b.ipolicy       "
		"   AND b.iofficer = c.iofficer     "
		"   AND a.ipolicy >= '%s'           "
		"   AND a.ipolicy <= '%s'           "
		"order by ipolicy;                  "
		,ipolicy_bgn,ipolicy_end);

printf("stmt[%s]\n", stmt);

          $PREPARE pre1 FROM $stmt;
          $DECLARE cur_pre1 CURSOR for pre1;
      	  $OPEN cur_pre1;

      		while(1)
      		{
         		$FETCH cur_pre1 INTO $ipolicy,$dpolicy,$iofficer,$nofficer;

         		if(SQLCODE == SQLNOTFOUND) break;

         		number = number + 1 ;

         		$INSERT INTO car637_tmp1
	          		     (number,ipolicy,dpolicy,iofficer,nofficer)
			      VALUES
	          		     ($number,$ipolicy,$dpolicy,$iofficer,$nofficer);
		}
          	$CLOSE cur_pre1;
          	$FREE cur_pre1;
/*
       	}
*/


     return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

long car637_create_temp()
{
   /* Create table car346_tmp1 */
   $create temp table car637_tmp1
	(
	 number    		int,
         ipolicy    		char(20),
	 dpolicy		char(10),
	 iofficer               char(10),
	 nofficer               char(10)
	)with no log;

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

long car637_body()
{
	$char number1[5],ipolicy1[21],dpolicy1[11],iofficer1[11],nofficer1[11];
	$char number2[5],ipolicy2[21],dpolicy2[11],iofficer2[11],nofficer2[11];
	$char number3[5],ipolicy3[21],dpolicy3[11];
	$char tmp_dpolicy[11],ch_dpolicy[10],yy[4],mm[3],dd[3];
	$char user_name[21];
	$long count1,num_bgn1,num_bgn2,num_bgn3;
	$char SysTm[11];

   	$SELECT kPgNum_Line, nForm_File, iForm_Tp
      	   INTO $PgLine, $FormFile, $FormTp
      	   FROM Form
          WHERE ksys_grp="CA" AND kPgmID = 637;

        if (SQLCODE == SQLNOTFOUND)
    	{
        printf("FormFile not found in Form!!\n");
        goto errexit;
    	}

   	strcpy( FormFile,rtrim(FormFile));
   	sprintf_s(OutFile, sizeof OutFile,"%s.tx",outputf);
   	rgu_init_report(FormFile,OutFile);

   	strcpy( SysTm, cm_get_sysd());

printf("systm=[%s]\n",cm_sysd_cdate_100(SysTm));

	$select nname
	   into $user_name
	   from officer
	  where iofficer = $userid;
	  
	if(SQLCODE == SQLNOTFOUND) strcpy(user_name ," ");

   	rgu_put_body(6);
   	rgu_put_body(6);
   	rgu_put_body(1);
   	rgu_put_body(6);
   	rgu_put_body_string( 2, cm_sysd_cdate_100(SysTm),1);
   	rgu_put_body_string( 2, trim(user_name),1);
   	rgu_put_body(2);
   	rgu_put_body(6);
   	rgu_put_body(3);

   	max_count += 7;
   	
	count1 = 0;
   	num_bgn1 = 0;
   	num_bgn2 = 0;
   	num_bgn3 = 0;

   	for(;;)
   	{
		count1++;
   		num_bgn1 = num_bgn1 + 1 ;
   		num_bgn2 = num_bgn1 + 50 ;
   		num_bgn3 = num_bgn1 + 100 ;

   		$select number,ipolicy,dpolicy,iofficer,nofficer
   		   into $number1,$ipolicy1,$tmp_dpolicy,$iofficer1,$nofficer1
   		   from car637_tmp1
   		  where number = $num_bgn1;

   		if(SQLCODE == SQLNOTFOUND) break;
   		
   		strcpy(ch_dpolicy,cm_from_infdate_100(tmp_dpolicy));
printf("ch_dpolicy[%s]\n",ch_dpolicy);
   		cm_split_ymd_100(ch_dpolicy,yy,mm,dd);
printf("yy[%s]mm[%s]dd[%s]\n",yy,mm,dd);
   		strcpy(dpolicy1,yy);
   		strcat(dpolicy1,mm);
   		strcat(dpolicy1,dd);
printf("dpolicy1[%s]\n",dpolicy1);
   		
   		if(count1 == 50)
   		{
   			/*num_bgn1 = num_bgn1 + 1;*/
   			count1 = 0;

printf("num_bgn1[%d]\n",num_bgn1);
   		}

   		if(count1 == 1 && num_bgn1 != 1)
   		{
   			rgu_put_body(5);
			max_count++;
			rgu_put_body(6);
			rgu_put_body(6);
			rgu_put_body(1);
			rgu_put_body(6);
   			rgu_put_body_string( 2, cm_sysd_cdate_100(SysTm),1);
   			rgu_put_body_string( 2, trim(user_name),1);
   			rgu_put_body(2);
   			rgu_put_body(6);
   			rgu_put_body(3);
   			max_count += 7;
   		}

/*
   		$select number,ipolicy,dpolicy,iofficer,nofficer
   		   into $number2,$ipolicy2,$tmp_dpolicy,$iofficer2,$nofficer2
   		   from car637_tmp1
   		  where number = $num_bgn2;

   		if(SQLCODE == SQLNOTFOUND)
   		{
   			strcpy(number2," ");
   			strcpy(ipolicy2," ");
         		strcpy(dpolicy2," ");
   		}
   		else
   		{
   			strcpy(ch_dpolicy,cm_from_infdate_100(tmp_dpolicy));
   			cm_split_ymd_100(ch_dpolicy,yy,mm,dd);
   			strcpy(dpolicy2,yy);
   			strcat(dpolicy2,mm);
   			strcat(dpolicy2,dd);
   		}
   		
 */  		
   		
   		/*$select number,ipolicy,dpolicy
   		   into $number3,$ipolicy3,$tmp_dpolicy
   		   from car637_tmp1
   		  where number = $num_bgn3;

   		if(SQLCODE == SQLNOTFOUND)
   		{
   			strcpy(number3," ");
   			strcpy(ipolicy3," ");
         		strcpy(dpolicy3," ");

         		/*rgu_put_body_string(4,trim(number1),1);
         		rgu_put_body_string(4,trim(ipolicy1),1);
      			rgu_put_body_string(4,trim(dpolicy1),1);
         		rgu_put_body_string(4,trim(iofficer1),1);
      			rgu_put_body_string(4,trim(nofficer1),1);

     			/*rgu_put_body_string(4,trim(number2),1);
     			rgu_put_body_string(4,trim(ipolicy2),1);
      			rgu_put_body_string(4,trim(dpolicy2),1);
      			
      			/*rgu_put_body_string(4,trim(number3),1);
     			rgu_put_body_string(4,trim(ipolicy3),1);
      			rgu_put_body_string(4,trim(dpolicy3),1);

      			rgu_put_body(4);

      			max_count++;

      			continue;
   		}*/
   		
   		strcpy(ch_dpolicy,cm_from_infdate_100(tmp_dpolicy));
   		cm_split_ymd_100(ch_dpolicy,yy,mm,dd);
   		strcpy(dpolicy3,yy);
   		strcat(dpolicy3,mm);
   		strcat(dpolicy3,dd);

   		/*rgu_put_body_string(4,trim(number1),1);*/
         	rgu_put_body_string(4,trim(ipolicy1),1);
      		rgu_put_body_string(4,trim(dpolicy1),1);
      		rgu_put_body_string(4,trim(iofficer1),1);
      		rgu_put_body_string(4,trim(nofficer1),1);

     		/*rgu_put_body_string(4,trim(number2),1);*/
     		/*rgu_put_body_string(4,trim(ipolicy2),1);
      		rgu_put_body_string(4,trim(dpolicy2),1);
      		rgu_put_body_string(4,trim(iofficer2),1);
      		rgu_put_body_string(4,trim(nofficer2),1);
      		
      		/*rgu_put_body_string(4,trim(number3),1);
     		rgu_put_body_string(4,trim(ipolicy3),1);
      		rgu_put_body_string(4,trim(dpolicy3),1);*/

      		rgu_put_body(4);

      		max_count++;

printf("number1[%s]ipolicy1[%s]dpolicy1[%s]\n",number1,ipolicy1,dpolicy1);
printf("number2[%s]ipolicy2[%s]dpolicy2[%s]\n",number2,ipolicy2,dpolicy2);
printf("number3[%s]ipolicy3[%s]dpolicy3[%s]\n",number3,ipolicy3,dpolicy3);
   	}
printf("max_count[%d]\n",max_count);
   rgu_finish_report();

   return M_CM_OK;


errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
