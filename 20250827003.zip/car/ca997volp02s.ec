/* Copyright (C) 2001 Intellisys Corporation               */
/* Program : ca997volp02s.ec                               */
/* �����T���ߥ��N�I�����      modify by sylvia 99.12.01 */
/***********************************************************/

#include <stdio.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"
#include "sqlfatal.h"

#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "car_common.h"
#include "safeclib.h"

#define ONLINE_DATE "04/29/2007"	/* �e���T��Ʊj����N���ɤW�u�� */

/*--------------------------------------------------------------------*/

DBinfo  *list;
int     i=0,count_db=0,rc=0;

char    userid[11],option[2],outputf[21];
$char   DBName[05];
$char   dbgn1[11],dend1[11],datebgn[11],dateend[11];
$char   sApHome[31];
char    errmsg[200];
FILE    *errfpt;
FILE    *fptr;

$char   errFile[30],strlog[500],errlog[300];

/* data from edr_relation */
$char ipolicy[21],fcard_class[2],ilast_ply[21],icard[21];
$char icar_type[3],iissue_ym[6],ibrand[10],ipro_year[5],fcomp_class[3];
$long dply_begin=0,dply_end=0,dendorse=0,dedr_begin=0;
$char iendorse[21],sFedr_class[2],sFcard_class[2];
$char ipolicy_chg[21];
$char terminate_rsn[2], dcreate[31];

/* data from endorsement */
$char ilicense[11],ibirth[9],fsex[2],fmarriage[2],fpt[2],iengine[CA_ENGINE_NUM];
$char ibody[CA_BODY_NUM],itag[CA_TAG_NUM],iassured[11],nassured[121],iply_area[3],fassured[2];
$int  qcylinder=0, ipdmg_align=0, iplia_align=0, ipbrg_align=0;
$double qpt;
$int id1=0;

/* data from edr_ins_type */
int iFetch,iTmpbuf;
$char iins_type[INSURANCE_TYPE],iins_type_rule[7],drate_ym[6],iedr_type[3];
$long  mdeduct=0,mprem=0;
$long  medrinj_cover=0, medrdea_cover=0, medrdmg_cover=0, medrins_prem=0;

/* others*/
$char prem_subtot_c[9],mins_premium_c[9];
$char objno[5],icode[2],drate[11];
$long prem_subtot=0,prem_subtot0=0,cntrlrec=0,birth_yyyy=0;
$char prtstr[1000],sTmpInsType[7], iply_type[3];
$char prtstr_9[1000];
char  tmp_yyyy[5];
$char  dply_yy[4],dply_mm[3],ibirth_yy[5],ibirth_mm[3],ibirth_dd[3],tmp_dd[3];
char  card_str[16],dply_begin_c[9],dply_end_c[9],endorse_c[9];
char  dply_begin_yy[4],dply_begin_mm[3],dply_begin_dd[3];
char  dply_end_yy[4],dply_end_mm[3],dply_end_dd[3];
$char  iissue_yy[5],iissue_mm[3],cntrlrec_c[9];
char  minjured_c[13],mdeath_c[13],mdamage_c[13],mdeduct_c[13],mprem_c[13];
char  dendorse_c[11],sTmpbuf[200];
char  sPrePolicy[21],sPrePolicy1[21],medrins_prem_c[13];
long  yy_long=0,iRtnCode=0;
$long  lTmpMdeduct=0, lTmpMins_premium=0, prem_total=0, sDendorse=0;
$date Today;
FILE  *fptr,efp;
$char  company_flag;
$int   count=0;
$char  CAR_COMPANY_E[3];
$char  CAR_COMPANY_P[3];
char  companyid[3];
int   rtn=0;

char  strtmp[31], strcol18[1000], strcol19[1000];     /* �t�X101/3/1�_���N�I���T�ǿ�W�沧�� add by sylvia 101.01.02 */

$int nassured_len = 0;
$char nassured_1[21];

long car9972_get_db();
long car9972_build_vol();
long car9972_build_vol2();       /* 101/03/01 �_�s�����N�I���T�ǿ�W�沧�� add by sylvia 101.01.02 */
long car9972_edr_relation();
extern char *sformat_trade();
extern long split_policy();
extern int rptftpinsert();
static char *get_car_full_db();  /*   �ǤJ�O�渹��X���O�檺�k�ݸ��*/
long check_if_exist();
long  today, online_date, online;

/*--------------------------------------------------------------------*/

main(argc,argv)
int   argc;
char  **argv;
{
   int   rc=0;

   long  t=0, date_1010301=0;

   batchinit();

   strcpy(DBName,isNULLstr(argv[1]));
   strcpy(userid,isNULLstr(argv[2]));
   strcpy(option,isNULLstr(argv[3]));    /* 2:���N�I���, 4:���N�I��歫�e, 5:���N�I���簣 X:�������v�ɶǰe */
   strcpy(datebgn,isNULLstr(argv[4]));
   strcpy(dateend,isNULLstr(argv[5]));
   strcpy(outputf,isNULLstr(argv[6]));

   if (datebgn[0]=='*' || datebgn[0] == '\0')
       strcpy(datebgn,  "80/01/01");
   if (dateend[0]=='*' || dateend[0] == '\0')
       strcpy(dateend,  "99/12/31");

   strcpy(dbgn1,cm_to_infdate(datebgn));
   strcpy(dend1,cm_to_infdate(dateend));

   printf("dbgn1[%s] dend1[%s]\n",dbgn1,dend1);

   $WHENEVER SQLERROR GOTO errexit;

   rstrdate( ONLINE_DATE, &online_date);
   rtoday( &today);

   online = today >=online_date ? TRUE:FALSE;

   errfpt = (FILE *) STARTLOG();

   rc=car9972_get_db();
   if (rc!=M_CM_OK)
        return rc;

   rc = getApHome(sApHome);
   if (rc < 0) {
        printf("read Config file error!!\n");
        return M_CM_READ_CONFIG_ERR;
   }

   $CREATE TEMP TABLE CAR9972
   (
      Tiendorse    char(20),
      Tipolicy     char(20),
      TsFedr_class   char(2),
      TsFcard_class  char(2),
      Ticard       char(21),
      Tdendorse    int,
      Ticar_type    char(3),
      Tiissue_ym    char(8),
      Tibrand       char(8),
      Tipro_year    char(5),
      Tdedr_begin   int,
      Tfcomp_class  char(3),
      Tterminate_rsn char(1),
      dcreate  datetime year to fraction(3)
   ) WITH NO LOG;

   $CREATE TEMP TABLE tmp_policy
   ( ipolicy char(20),
     icar_type  char(3)) WITH NO LOG;

   $CREATE TEMP TABLE del_50_policy
   ( ipolicy char(20) ) WITH NO LOG;


   rc=car9972_edr_relation();
   if (rc!=M_CM_OK)
      return rc;


   t = cm_today();
   rstrdate( "03/01/2012", &date_1010301);

   printf(" ********** t=[%ld] date_1010301=[%ld] ***********\n", t,date_1010301);
   if (t >= date_1010301)
      rc=car9972_build_vol2();
   else
      rc=car9972_build_vol();


   if( rc!= M_CM_OK )
   {
      rgetmsg(rc, errlog, sizeof(errlog));
      sprintf_s(strlog, sizeof strlog,"%s\n\t",errlog);

      if ( strcmp(option,"2") == 0 )
      {
         strcat(strlog," ISBH_���N���I���s�@���� ");
      }
      else if ( strcmp(option,"4") == 0 )
      {
         strcat(strlog," ���N���I��歫�e���� ");
      }
      else
      {
         strcat(strlog," ���N���I��歫�e�簣���� ");
      }

      EWRITE(userid,rc,strlog);
      exit(1);
   }

   exit(0);

errexit:
    printf("car9972vol-main:sqlcode=%d, sqlmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/

long car9972_edr_relation()
{
   int i=0;
   $char stmt_buf1[1024],stmt_buf2[1024];
   $char stmt_db[512],stmt_statement[1024];

   /* data from edr_relation */
   $char Eipolicy[21],Efcard_class[2],Eicard[21];
   $char Eicar_type[3],Eiissue_ym[6],Eibrand[10],Eipro_year[5],Efcomp_class[3];
   $long Edendorse=0,Ededr_begin=0;
   $char Eiendorse[21],EsFedr_class[2],EsFcard_class[2],Eterminate_rsn[2];
   $long tmp_cnt=0;
   $char stmt_drate_ym[128],Edrate_ym[5];

   for( i= 0;i<count_db;i++)
   {

   	/* if option = 5, it has to join with table [ca_tmp_no] */
      strcpy(stmt_statement,"");
      strcpy(stmt_db,"");
      if( strcmp(option,"5") == 0 )
   	{
         /*sprintf_s(stmt_db, sizeof stmt_db,", %s:ca_tmp_no b",list[i].dbname);*/
         strcpy(stmt_db,", ca_tmp_no b");
         strcpy(stmt_statement,"AND a.iendorse = b.ipolicy");
      }
      /* End of statement */
      printf("stmt_db=[%s]stmt_statement=[%s]\n",stmt_db,stmt_statement);
      /***** prepare cursor for select edr_relation *****/
      
      sprintf_s(stmt_drate_ym, sizeof stmt_drate_ym,"(select max(drate_ym) from %s:edr_ins_type where iendorse = a.iendorse)",list[i].dbname);
      
      /* �O�T�I(�O��[6,7]=VW)���W�����T add by sylvia 100.12.08 (1001206018_C1) */
      sprintf_s(stmt_buf1, sizeof stmt_buf1,"SELECT %s %s %s %s %s FROM %s:%s %s %s %s %s %s %s",
                        "iendorse, a.ipolicy, fedr_class, fcard_class,",
                        "icard, dendorse, icar_type, iissue_ym,",
                        "ibrand, ipro_year,",
                        "dedr_begin, fcomp_class, terminate_rsn, dcreate, ",
                        stmt_drate_ym,list[i].dbname,"edr_relation a",stmt_db,
                        "WHERE dendorse BETWEEN ? AND ?",
                        " AND fcard_class = '2' AND dedr_close is NOT NULL",
                        " AND fedr_class not in ('A','B','3') AND a.ipolicy[6,7] <> 'VW' AND a.ipolicy[6,7] <> 'EB' AND a.ipolicy[6,7] <> 'TV'",
                        stmt_statement,
                        " ORDER BY dcreate");      /*���g��H�������T*/

      printf("stmt_buf1=[%s]\n",stmt_buf1);

      $PREPARE CUR_STMT1 FROM $stmt_buf1;
      $DECLARE scur_edr1 CURSOR FOR CUR_STMT1;
      $OPEN scur_edr1 USING $dbgn1, $dend1;

      while(1)
      {
         $FETCH scur_edr1
           INTO $Eiendorse, $Eipolicy, $EsFedr_class, $EsFcard_class,
                $Eicard, $Edendorse, $Eicar_type,     $Eiissue_ym,
                $Eibrand, $Eipro_year, $Ededr_begin,  $Efcomp_class, $Eterminate_rsn, $dcreate,$Edrate_ym;

         if (SQLCODE == SQLNOTFOUND) break;

         strcpy( Eicar_type, TRANS_CAR_TYPE(Eicar_type,Edrate_ym));

         $INSERT INTO CAR9972
         (
            Tiendorse, Tipolicy,   TsFedr_class, TsFcard_class, Ticard,
            Tdendorse, Ticar_type, Tiissue_ym,   Tibrand,       Tipro_year,
            Tdedr_begin, Tfcomp_class, Tterminate_rsn, dcreate
         )
         VALUES
         (
            $Eiendorse, $Eipolicy, $EsFedr_class, $EsFcard_class,
            $Eicard,  $Edendorse,  $Eicar_type,   $Eiissue_ym,
            $Eibrand, $Eipro_year, $Ededr_begin,  $Efcomp_class, $Eterminate_rsn, $dcreate
         );

         /* �N���N�O���J�Ȧstable�� */
         if (EsFcard_class[0] == '2')
            $INSERT INTO tmp_policy (ipolicy, icar_type) VALUES ($Eipolicy,$Eicar_type);
      } /* end of while */
      $CLOSE scur_edr1;
      $FREE  scur_edr1;

      /* car9901111 �P�_�Y�O��l�O��ȩӫO50�I�خ�,�h�ӧ�椣�e���T */
      sprintf_s(stmt_buf2, sizeof stmt_buf2,"insert into del_50_policy "
   	                  "select ipolicy from %s:ori_ins_type a "
   	                  "where ipolicy in (select ipolicy from tmp_policy) "
   	                  "  and iins_type = '50' "
                        "  and not exists (select 1 from %s:ori_ins_type b where a.ipolicy = b.ipolicy "
                        "  and a.iins_type <> b.iins_type)",list[i].dbname,list[i].dbname);
      printf("stmt2[%s]\n",stmt_buf2);

      $PREPARE cur_tmp1 FROM  $stmt_buf2;
      $EXECUTE cur_tmp1;
      
      /* �P�_�Y�O����(01,02,32,34)�B���O(01,05,09,31,32,86)���@�I��,���e���T */
      /* 107.08.20 �W�[�ǰe149�I�� */
      sprintf_s(stmt_buf2, sizeof stmt_buf2,"insert into del_50_policy "
                        "select ipolicy from tmp_policy a "
                        " where icar_type in ('01','02','32','34') "
                        "   and ipolicy not in "
                        "       (select unique ipolicy from %s:ori_ins_type "
                        "          where ipolicy = a.ipolicy "
                        "            and iins_type in ('01','05','09','31','32','86','110','113','114','149', "
                        "                              '201','205','209','231','232','249','157','158','159','531','532'))",
                        list[i].dbname);
                        
      printf("����stmt2[%s]\n",stmt_buf2);
      $PREPARE cur_tmpx1 FROM  $stmt_buf2;
      $EXECUTE cur_tmpx1;
      
      $SELECT count(*) INTO $tmp_cnt FROM CAR9972;
      printf("delete before 9972 count = [%d]\n",tmp_cnt);

      $DELETE FROM CAR9972 WHERE Tipolicy in (select ipolicy from del_50_policy);

      $SELECT count(*) INTO $tmp_cnt FROM CAR9972;
      printf("delete after 9972 count = [%d]\n",tmp_cnt);

      $DELETE FROM del_50_policy WHERE 1=1;
      $DELETE FROM tmp_policy WHERE 1=1;

   } /*end of dblist */

   return M_CM_OK;

errexit:
    printf("car9972voledr_relation:code=%d, msg=%s\n",SQLCODE,sqlca.sqlerrm);
    $DROP TABLE CAR9972;
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
} /* end of get ori_ply_relation */

/* -------------------------------------------------------------------------- */

long car9972_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);

   return SQLCODE;
}

/* -------------------------------------------------------------------------- */
/* ��101/3/1�_�]���T�ǿ�榡�קﰱ��,��ϥ�car9971_build_vol2()  by sylvia 101.01.05 */
long car9972_build_vol()
{
   $char Tmp1[20],file0[51],tstmt[1024],stmt_buf2[1024],stmt_buf3[1024];
   $char stmt_buf4[600],stmt_buf5[500],stmt_bufa[500], stmt_bufb[500];
   $char drate_c[7], sIbrand_new[10],chk_dpolicy[2];
   char  tmp_dbname[20];
   char  day_yy[5],day_mm[3],day_dd[3];
   $date Today;
   $long ldpolicy=0, lchk_date=0;
   long  rtncode=0;
   int  cond=0,i=0;

   $long date_1000901;
   $char iins_type_rule[7], iins_type[7], sTmpInsType[7], iins_type_tradevan[7];
   $char mdamage_c[13], drate_yyyymm[7];

   rtoday(&Today);
   rstrdate( "09/01/2011", &date_1000901);

   /* If option = 1,2,3, loop is only running once; if option = 4, loop is running 4 times */
   /* �]�{���w���I��(�j��,���N)�Υ\��(���e,���e,�簣���e)����, �G�����j����榸�� modify by sylvia 99.12.03 */

      cntrlrec = 0;
      sprintf_s(tstmt, sizeof tstmt,"SELECT * FROM CAR9972");
   /* ���N�T���O�I���,car9901111�אּ�������N���e���T */

      strcat(tstmt," WHERE TsFcard_class = '2' ");
      /* 1000413004_C1 �����I�]�n�e���T�@mark by sylvia 100.05.02  */
      /*�@strcat(tstmt,"   AND Ticar_type not in ('01','02','32','34')"); */
      strcat(tstmt," ORDER BY dcreate, Tiendorse");

      printf("tstmt[%s]\n",tstmt);

      $PREPARE CUR_TSTMT FROM $tstmt;
      $DECLARE scur_car9972 CURSOR FOR CUR_TSTMT;

      $OPEN scur_car9972;

      iFetch = True;
      while(1)
      {
         $FETCH scur_car9972
           INTO $iendorse, $ipolicy,   $sFedr_class, $sFcard_class, $icard,
                $dendorse, $icar_type, $iissue_ym,   $ibrand,       $ipro_year,
                $dedr_begin, $fcomp_class, $terminate_rsn, $dcreate;

         if (SQLCODE == SQLNOTFOUND) break;

         strcpy(tmp_dbname,get_car_full_db(ipolicy));

         /***** prepare cursor for select endorsement *****/

         sprintf_s(stmt_buf2, sizeof stmt_buf2,"SELECT %s %s %s FROM %s:%s %s",
                           "ilicense,to_char(dbirth,'%Y'), to_char(dbirth,'%m'), to_char(dbirth,'%d'),fsex,fmarriage,qcylinder::int,qpt,fpt,iengine,ibody,",
                           "itag,iassured,nassured,dply_begin,dply_end,",
                           "pdmg_align,pbrg_align,plia_align, iply_area, fassured, to_char(dissue, '%Y'), to_char(dissue, '%m')",
                           tmp_dbname,"endorsement ",
                           "WHERE iendorse=? ");

         $PREPARE CUR_STMT2 FROM $stmt_buf2;
         $DECLARE scur_edr2 CURSOR FOR CUR_STMT2;

         /***** prepare cursor for select edr_ins_type *****/
         sprintf_s(stmt_buf3, sizeof stmt_buf3,"SELECT %s %s FROM %s:%s %s ",
                           "iedr_type,iins_type,medrinj_cover,medrdea_cover,medrdmg_cover,",
                           "mdeduct,medrins_prem,medr_prem,drate_ym",
                           tmp_dbname,"edr_ins_type",
                           "WHERE iendorse=? and iedr_type not in ('79','10') and iins_type not in ('171','172','173','174','175') order by iedr_type");
         $PREPARE CUR_STMT3 FROM $stmt_buf3;
         $DECLARE scur_edr3 CURSOR FOR CUR_STMT3;

         qpt = 0;

         $OPEN scur_edr2 USING $iendorse;
         $FETCH scur_edr2
           INTO $ilicense, $ibirth_yy, $ibirth_mm, $ibirth_dd, $fsex, $fmarriage, $qcylinder, $qpt:id1, $fpt,
                $iengine, $ibody, $itag, $iassured, $nassured, $dply_begin, $dply_end,
                $ipdmg_align, $ipbrg_align, $iplia_align, $iply_area, $fassured, $iissue_yy, $iissue_mm;

         if (SQLCODE == SQLNOTFOUND)
         {
            $CLOSE scur_edr2;
            continue;
         }
         $CLOSE scur_edr2;

         rtn = getCompanyId(companyid);

         printf(" ************************** companyid[%s]\n",companyid);

         if (iFetch)                 /*�Ĥ@�����W�@���O�ۤv*/
         {
            sDendorse = dendorse;
            iFetch = FALSE;
            prem_total = 0;

            strcpy( endorse_c , cm_cdate_str_100( dendorse ));

            cm_split_ymd_100(endorse_c,day_yy,day_mm,day_dd);

            if ( strcmp(option,"2") == 0 )
            {

               sprintf_s(Tmp1, sizeof Tmp1,"ISBH%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
               strcpy(iply_type,"bh");

               strcpy(fcard_class, "2");
            }
            else
            {
               if(online) sprintf_s(Tmp1, sizeof Tmp1,"ISBH%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
               else sprintf_s(Tmp1, sizeof Tmp1,"ISBH%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
            }
            sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);

            printf("[NOERROR]file0[%s] Tmp1[%s]\n",file0,Tmp1);
            fptr=fopen(file0,"w");


            if (strcmp(option,"4") != 0 || strcmp(option,"5") != 0)
            {
               rc = check_if_exist(iply_type,dendorse,fcard_class,0);
               if ( rc != M_CM_OK )
                  return rc;
            }
         }  /* End of If which is iFetch */

         /* �����ثefile , open a new file*/

         if ( sDendorse != dendorse )
         {
            if (cntrlrec > 0)
            {
               strcpy(prtstr,"CNTRLREC");
               rfmtlong(cntrlrec,"&&&&&&",cntrlrec_c);
               strcat(prtstr,cntrlrec_c);
               fprintf(fptr, "%s\n", prtstr);
            }

            printf("### cntrlrec=[%s]\n",cntrlrec_c);

            fclose(fptr);

            rtncode = rptftpinsert( userid , "car9972" , Tmp1 );

            if (strcmp(option,"4") != 0 && strcmp(option,"5") != 0)
            {
               $insert into ca_trade_exam
                  (iply_type,dpolicy,fcard_class,itrans_type,
                   qcount,mamount,minjure,mcripple,mdeath)
                values
                  ($iply_type,$sDendorse,$fcard_class,0,
                   $cntrlrec,$prem_total,0,0,0);
            }

            sprintf_s(strlog, sizeof strlog,"���ɧ���:%s ���:%d",file0,cntrlrec);

            WRITELOG(errfpt , strlog);

            printf("errfpt[%s]\n",strlog);

            strcpy( endorse_c , cm_cdate_str_100( dendorse ));

            cm_split_ymd_100(endorse_c,day_yy,day_mm,day_dd);

            if ( strcmp(option,"2") == 0 )
            {
               sprintf_s(Tmp1, sizeof Tmp1,"ISBH%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
               strcpy(iply_type,"bh");

               strcpy(fcard_class, "2");
            }
            else
            {

               if(online) sprintf_s(Tmp1, sizeof Tmp1,"ISBH%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
               else sprintf_s(Tmp1, sizeof Tmp1,"ISBH%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
            }

            sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);

            printf("[002]file0[%s] Tmp1[%s]\n",file0,Tmp1);
            fptr=fopen(file0,"w");

            rc = check_if_exist(iply_type,dendorse,fcard_class,0);
            if ( rc != M_CM_OK )
               return rc;

            cntrlrec = 0;
            prem_total = 0;
         }

         /* car9212111 ���o�O��ñ���dpolicy�A�P�_�ǰe���T�I�إN�� */
         sprintf_s(stmt_bufa, sizeof stmt_bufa,"SELECT dpolicy , CASE WHEN dpolicy < '07/01/2016' THEN 'Y' ELSE 'N' END \
                              FROM %s:ply_relation \
                            WHERE ipolicy = '%s' ", tmp_dbname, ipolicy );

         $PREPARE EXE_STMTa FROM $stmt_bufa;
         $EXECUTE EXE_STMTa INTO $ldpolicy,$chk_dpolicy;

         if(strcmp(companyid,"17")==0)
         {
            company_flag=ipolicy[7];

            printf(" ipolicy[%s]\n",ipolicy);
            printf(" company_flag[%c]\n",company_flag);
            strcpy(CAR_COMPANY_P,"17");

            if(company_flag > 65 )
            {
               printf(" *************************************\n");
               $select ipolicy_a
                  into $ipolicy_chg
                  from conv_ipolicy
                 where ipolicy_n = $ipolicy;

               printf(" ****************** ipolicy[%s]\n",ipolicy);
               strcpy(CAR_COMPANY_E,"16");
               printf(" ****************** CAR_COMPANY_E[%s]\n",CAR_COMPANY_E);
            }
            else
            {
               strcpy(ipolicy_chg, ipolicy );
               strcpy(CAR_COMPANY_E,"17");
               printf(" ****************** CAR_COMPANY_E[%s]\n",CAR_COMPANY_E);
            }
         }
         else
         {
            strcpy(ipolicy_chg, ipolicy );
            strcpy(CAR_COMPANY_P,"32");
            strcpy(CAR_COMPANY_E,"32");
         }

         sDendorse = dendorse;

         strcpy(prtstr,"9"); prtstr[1]='\0';             /*C1:���ʧO*/
         strcat(prtstr, CAR_COMPANY_E);

         if ((iRtnCode = split_policy(ipolicy_chg, sTmpbuf, objno)) != M_CM_OK)
         {
            printf("[%s][%s]\n", iendorse, ipolicy_chg);
            fprintf(errfpt, "[%s][%s]\n", iendorse, ipolicy_chg);
            continue;
         }
         strcat(prtstr, sformat_trade(sTmpbuf, 2, 15));

         rstrdate( "07/14/2003", &lchk_date);

         strcpy(icard, trim(icard));
         strcpy(iendorse, trim(iendorse));
         strcat(prtstr, CAR_COMPANY_P);
         strcat(prtstr, sformat_trade(iendorse, 2, 15)); /*C19-35:��渹�X*/

	/* �N�{��u�a�ϥN�����v���R���N��42�u�x�����v�B�N��63�u�x�n���v�B�N��65�u�������v�C*/
	if( strcmp( iply_area, "42") == 0)
		strcpy( iply_area, "41");
	else if( strcmp( iply_area, "63") == 0)
		strcpy( iply_area, "62");
	else if( strcmp( iply_area, "65") == 0)
		strcpy( iply_area, "64");

         strcat(prtstr, sformat_trade(iply_area, 2, 2)); /*C36-37:�ӫO�a�ϥN��*/

         strcpy(dply_begin_c, cm_cdate_str_100(dply_begin));
         cm_split_ymd_100(dply_begin_c,dply_begin_yy,dply_begin_mm,dply_begin_dd);
         strcpy(tmp_yyyy, itoa(1911+atoi(dply_begin_yy)));

         strcat(prtstr, sformat_trade(tmp_yyyy, 2, 4));
         strcat(prtstr, sformat_trade(dply_begin_mm, 2, 2));
         strcat(prtstr, sformat_trade(dply_begin_dd, 2, 2));
                                                       /*C38-45:�O��_��*/

         strcpy(dply_end_c,cm_cdate_str_100(dply_end));
         cm_split_ymd_100(dply_end_c,dply_end_yy,dply_end_mm,dply_end_dd);
         strcpy(tmp_yyyy,itoa(1911+atoi(dply_end_yy)));
         strcat(prtstr, sformat_trade(tmp_yyyy, 2, 4));
         strcat(prtstr, sformat_trade(dply_end_mm, 2, 2));
         strcat(prtstr, sformat_trade(dply_end_dd, 2, 2));
                                                       /*C46-53:�O�樴��*/

         if (strlen(trim(objno)) > 0) strcat(prtstr, sformat_trade(objno, 2, 4));
         else strcat(prtstr, "0001");                    /*C54-57:�O��Ъ���*/

         /*�o�Ӧ~���Τ�����,��iissue_ym�o������,�諾����original_ply.dissure�����쪺�~�� */
		 
		 if (strcmp(trim(iins_type), "157")==0 || strcmp(trim(iins_type), "158")==0 || strcmp(trim(iins_type), "159")==0)
		 {
		 	strcat(prtstr, sformat_trade("0000", 2, 4));
         	strcat(prtstr, sformat_trade("00", 2, 2));
         	strcat(prtstr, sformat_trade("0000", 2, 4));
		 }
		 else
		 {
         	strcat(prtstr, sformat_trade(iissue_yy, 2, 4));
         	strcat(prtstr, sformat_trade(iissue_mm, 2, 2));/*C58-63:�o�Ӧ~��*/
         	strcat(prtstr, sformat_trade(ipro_year, 2, 4));/*C64-67:�s�Ӧ~��*/                                 
         }

         
         /* �t�P�����N���ഫ modify by sylvia 100.09.30 (car9812112_C1) ----- */
           sIbrand_new[0] = '\0';
           $select first 1 ibrand_new into $sIbrand_new
              from ca_car_model
             where ibrand = $ibrand
               and ibrand_new <> ' '
             order by drate desc;
           
           if (sIbrand_new[0] != '\0')
               strcpy(ibrand, sIbrand_new);
         /* ----------------------------------------------------------------- */ 
         if (strcmp(trim(iins_type), "157")==0 || strcmp(trim(iins_type), "158")==0 || strcmp(trim(iins_type), "159")==0)
         	strcat(prtstr, sformat_trade("00000000", 2, 8));
                                                      
         else
         	strcat(prtstr, sformat_trade(ibrand, 2, 8)); /*C68-75:�t���N��*/
         
         strcat(prtstr, sformat_trade(iengine, 2, 25));
                                                       /*C76-95:�������X*/
         strcat(prtstr, sformat_trade(ibody, 2, 25));
                                                       /*C96-115:�������X*/
                                                       
         /* 1061102009_C1 �ק�ǰe���T27���ؾ��񨮵P�W�h
         if (strcmp(icar_type,"27") == 0 && strcmp(chk_dpolicy,"Y") == 0)
               strcpy(itag," ");   */                    /* ����27,���P���X�M�� modify by sylvia 101.02.24 (1001005007_C1) */
               
         strcat(prtstr, sformat_trade(itag, 2, 8));
                                                       /*C116-123:�P�Ӹ��X*/
		 /*1110216005_SC2_�t�X�N�ɫO�ӫ~�վ�CAR401�B�q�l�O���E�O���t��*/
         /*if (strcmp(trim(iins_type), "157")==0 || strcmp(trim(iins_type), "158")==0 || strcmp(trim(iins_type), "159")==0)
         	strcat(prtstr, sformat_trade("03", 2, 2));
         else*/
         strcat(prtstr, sformat_trade(icar_type, 2, 2));
                                                       /*C124-125:���إN��*/
         iTmpbuf = 10 * qcylinder;
         strcat(prtstr, sformat_trade(&iTmpbuf, 1, 6));
                                                      /*C126-131:�Ʈ�q*/
         if (id1 == -1)
         {
            $SELECT MAX(qpassenger)
               INTO $qpt
               FROM ca_car_model
              WHERE ibrand = $ibrand;
         }

         iTmpbuf =  10 * qpt;
         strcat(prtstr, sformat_trade(&iTmpbuf, 1, 4));
                                                          /*C132-135:�����ƶq*/
         if (strcmp(trim(iins_type), "157")==0 || strcmp(trim(iins_type), "158")==0 || strcmp(trim(iins_type), "159")==0)
         	strcat(prtstr, sformat_trade("0", 2, 1));
         else
         	strcat(prtstr, sformat_trade(fpt, 2, 1));
                                                          /*C136-136:�������*/
         strcat(prtstr, sformat_trade(iassured, 2, 10));

         /*nassured[20] = '\0';*/
         nassured_len = cc_split_chinese(nassured,nassured_1,20);
         strcpy(nassured_1, rtrim(nassured_1));
         strcat(prtstr, sformat_trade(nassured_1, 2, 20));

         /*��Q�O�I�H�ͤ�b��Ʈw�̬Ocahr(6),�ӫO���X�W�Q�O�I�H�ͤ������,�諾�����褸�~���,���ݦA�ഫ */
         strcat(prtstr, sformat_trade(ibirth_yy, 2, 4));
         strcat(prtstr, sformat_trade(ibirth_mm, 2, 2));
         strcat(prtstr, sformat_trade(ibirth_dd, 2, 2));
                                            /*C167-174:�X�ͦ~��-�褸*/

         strcat(prtstr, sformat_trade(fsex, 2, 1));
         strcat(prtstr, sformat_trade(fmarriage, 2, 1));

         if (fassured[0]=='1')
         {
            strcat(prtstr,"1");
         }
         else if(fassured[0]=='2')
         {
            strcat(prtstr,"3");
         }
         else if(fassured[0]=='3')
         {
            strcat(prtstr,"2");
         }
         else if(fassured[0]=='4')
         {
            strcat(prtstr,"9");
         }
         else if(fassured[0]=='5')
         {
            strcat(prtstr,"8");
         }
         else if(fassured[0]=='6')
         {
            strcat(prtstr,"9");
         }
         else
            strcat(prtstr, " ");
                                                       /*C177:�۵M�H/�k�H�O*/

         iTmpbuf = atoi(fcomp_class);
         strcat(prtstr, sformat_trade(&iTmpbuf, 1, 2));
                                                          /*C178-179:�����ż�*/
         strcat(prtstr,"    ");                          /*C180-183:blank*/

         if (strcmp(iins_type, "01")==0 ||
               strcmp(iins_type, "05")==0 ||
               strcmp(iins_type, "08")==0 ||
               strcmp(iins_type, "09")==0 ||
               strcmp(iins_type, "201")==0 ||
               strcmp(iins_type, "205")==0 ||
               strcmp(iins_type, "209")==0)
         {
            ipdmg_align=ipdmg_align*(-1);

            $SELECT icode INTO $icode FROM alignment
              WHERE fclass='4' AND palign=$ipdmg_align;

            if (SQLCODE==SQLNOTFOUND) strcat(prtstr, "0");
                                              /*C184:����h�����u��*/
            else strcat(prtstr,icode);
         } else strcat(prtstr, "0");

         if (strcmp(iins_type, "11")==0 || strcmp(trim(iins_type), "211")==0) /* fix:2025.06 */
         {
            ipbrg_align=ipbrg_align*(-1);
            $SELECT icode INTO $icode FROM alignment
              WHERE fclass='4' AND palign=$ipbrg_align;

            if (SQLCODE==SQLNOTFOUND) strcat(prtstr, "0");
                                                       /*C185:�ѵs�h�����u��*/
            else strcat(prtstr,icode);
         } else strcat(prtstr, "0");

         if (strcmp(iins_type, "31")==0 || strcmp(iins_type, "32")==0 || strcmp(iins_type, "231")==0 || strcmp(iins_type, "232")==0)
         {
            iplia_align=iplia_align*(-1);

            $SELECT icode INTO $icode FROM alignment
              WHERE fclass='4' AND palign=$iplia_align;

            if (SQLCODE==SQLNOTFOUND) strcat(prtstr, "0");
                                                   /*C186:�d���h�����u��*/
            else strcat(prtstr,icode);
         } else strcat(prtstr, "0");

         printf("Fedr_class[%s] iendorse[%s]\n",*sFedr_class,iendorse);

         sprintf_s(stmt_bufb, sizeof stmt_bufb,"SELECT first 1 drate_ym FROM %s:ply_ins_type"
                           " WHERE ipolicy = ? ", tmp_dbname);

         printf("stmt_bufb[%s] ipolicy=[%s]\n",stmt_bufb, ipolicy );

         $PREPARE cus_ins_cur1 from $stmt_bufb;
         $DECLARE PLY_INS_CUR1 CURSOR for cus_ins_cur1;

         $OPEN PLY_INS_CUR1 USING $ipolicy;
         $FETCH PLY_INS_CUR1 INTO $drate_ym;

         $SELECT to_char(drate,'%Y%m')
            INTO $drate_yyyymm
            FROM ca_rate_date
           WHERE icode=$drate_ym
             AND itable='cover_vs_premium';

         if (*sFedr_class == '5' || *sFedr_class == '7')    /*** ��r���, ���P��� ***/
         {
                strcat(prtstr, "AC");                             /*C187-C188*/
                strcat(prtstr, "      ");                    /*C189-C194:�����I�إN�X*/

                strcat(prtstr, sformat_trade(" ", 2, 1));         /*C195-C195*/
                iTmpbuf = 0;
                strcat(prtstr, sformat_trade(&iTmpbuf, 1, 43));   /*C196-C238*/
                strcat(prtstr, sformat_trade(" ", 2, 1));         /*C239-C239*/
                iTmpbuf = 0;
                strcat(prtstr, sformat_trade(&iTmpbuf, 1, 9));    /*C240-C248*/

                strcat(prtstr, sformat_trade(" ", 2, 17));        /*C249-C265�j�����*/

                strcat(prtstr, drate_yyyymm);                     /*C266-C271�O�v��I�~��*/

                strcpy(dendorse_c, cm_cdate_str_100(dedr_begin));
                cm_split_ymd_100(dendorse_c, dply_yy, dply_mm, tmp_dd);
                yy_long = 1911 + atoi(dply_yy);
                strcpy(tmp_yyyy, itoa(yy_long));
                strcat(prtstr, sformat_trade(tmp_yyyy, 2, 4));
                strcat(prtstr, sformat_trade(dply_mm, 2, 2));
                strcat(prtstr, sformat_trade(tmp_dd, 2, 2));
                                                                 /*C272-279:���ͮĤ�*/

                strcpy(dendorse_c, cm_cdate_str_100(dendorse));
                cm_split_ymd_100(dendorse_c, dply_yy, dply_mm, tmp_dd);
                yy_long = 1911 + atoi(dply_yy);
                strcpy(tmp_yyyy, itoa(yy_long));
                strcat(prtstr, sformat_trade(tmp_yyyy, 2, 4));
                strcat(prtstr, sformat_trade(dply_mm, 2, 2));
                strcat(prtstr, sformat_trade(tmp_dd, 2, 2));
                                                                 /*C280-287:�����*/
                strcat(prtstr, "  ");                            /*C288-289:�F�d�I�إN�X */

                cntrlrec++;
                fprintf(fptr, "%s\n", prtstr);
         } /* end ��� */
         else    /**** ����r��蠟�~����� ***/
         {
            /*���嶷���e�@�� AC */
            if (*sFedr_class == '9')
            {
                prtstr_9[0]='\0';
                strcpy(prtstr_9, prtstr);

                strcat(prtstr_9, "AC");                             /*C187-C188:���ʽ�N��*/
                strcat(prtstr_9, "      ");                         /*C189-C194:�����I�إN�X*/

                strcat(prtstr_9, sformat_trade(" ", 2, 1));         /*C195-C195:�W��O�B+/-�O��*/
                iTmpbuf = 0;
                strcat(prtstr_9, sformat_trade(&iTmpbuf, 1, 43));   /*C196-C238*/
                strcat(prtstr_9, sformat_trade(" ", 2, 1));         /*C239-C239:�[�h�O�O+��-�O��*/
                iTmpbuf = 0;
                strcat(prtstr_9, sformat_trade(&iTmpbuf, 1, 9));    /*C240-C248:�[�h�O�I�O */

                strcat(prtstr_9, sformat_trade(" ", 2, 17));        /*C249-265:�j�����*/

                strcat(prtstr_9, drate_yyyymm);                     /*C266-271:�O�v��I�~��*/

                strcpy(dendorse_c, cm_cdate_str_100(dedr_begin));
                cm_split_ymd_100(dendorse_c, dply_yy, dply_mm, tmp_dd);
                yy_long = 1911 + atoi(dply_yy);
                strcpy(tmp_yyyy, itoa(yy_long));
                strcat(prtstr_9, sformat_trade(tmp_yyyy, 2, 4));
                strcat(prtstr_9, sformat_trade(dply_mm, 2, 2));
                strcat(prtstr_9, sformat_trade(tmp_dd, 2, 2));
                                                                    /*C272-279:���ͮĤ�*/

                strcpy(dendorse_c, cm_cdate_str_100(dendorse));
                cm_split_ymd_100(dendorse_c, dply_yy, dply_mm, tmp_dd);
                yy_long = 1911 + atoi(dply_yy);
                strcpy(tmp_yyyy, itoa(yy_long));
                strcat(prtstr_9, sformat_trade(tmp_yyyy, 2, 4));
                strcat(prtstr_9, sformat_trade(dply_mm, 2, 2));
                strcat(prtstr_9, sformat_trade(tmp_dd, 2, 2));
                                                                    /*C280-287:�����*/
                strcat(prtstr_9, "  ");                            /*C288-289:�F�d�I�إN�X */

                cntrlrec++;
                fprintf(fptr, "%s\n", prtstr_9);
            } /* end ���� */

            /* �P�_�O�_���L�� */
            /* 2:�L�� */
            /* car9602053 ���s�W���N�I�L�����O */
            if (*sFedr_class == '2' || *sFedr_class == '8')
            {
               strcat(prtstr, "AB");                        /*C187-C188*/

              if ( ldpolicy < date_1000901) /* ñ���< 09/01/2011�A�ǰeinsurance_type.iins_type_rule */
                   sprintf_s(stmt_buf4, sizeof stmt_buf4,"SELECT distinct case when b.iins_type_rule in ('15','16') then a.iins_type "
                                     "            when b.iins_type_rule = '23' then '21' "
                                     "            else b.iins_type_rule end FROM %s:ply_ins_type a, insurance_type b"
                                     " WHERE a.ipolicy = ? "
                                     "   AND a.fedr_status NOT IN ('1', '2', '3') "
                                     "   AND a.iins_type = b.iins_type; ",
                                     tmp_dbname);
              else
                   sprintf_s(stmt_buf4, sizeof stmt_buf4,"SELECT iins_type FROM %s:ply_ins_type"
                                     " WHERE ipolicy = ? "
                                     "   AND fedr_status NOT IN ('1', '2', '3'); ",
                                     tmp_dbname);

               printf("stmt_buf4[%s] ipolicy=[%s]\n",stmt_buf4, ipolicy );

               $PREPARE cus_ins_cur from $stmt_buf4;
               $DECLARE PLY_INS_CUR CURSOR for cus_ins_cur;

               $OPEN PLY_INS_CUR USING $ipolicy;
               while (1)
               {
                  $FETCH PLY_INS_CUR INTO $sTmpInsType;

                  if (SQLCODE == SQLNOTFOUND) break;

                  prtstr[188] = '\0';

                  strcpy(iins_type_tradevan," ");
                  if ( ldpolicy < date_1000901 ) /* ñ���< 09/01/2011�A�ǰeinsurance_type.iins_type_rule */
                  {
                      puts("ñ���<09/01/2011");
                      strcat(prtstr, sTmpInsType);                     /*C189-194:�����I�إN�X*/
                      strcpy(iins_type_tradevan, sTmpInsType);
                  }
                  else
                  {
                      puts("ñ���>=09/01/2011");

                      strcat(prtstr, sTmpInsType);                     /*C189-194:�����I�إN�X*/

                      $SELECT iins_type_tradevan
                         INTO $iins_type_tradevan
                         FROM insurance_type
                        WHERE iins_type = $sTmpInsType;
                  }

                  strcat(prtstr, sformat_trade(" ", 2, 1));      /*C195-195:�W��O�B+/-�O��*/
                  iTmpbuf = 0;
                  strcat(prtstr, sformat_trade(&iTmpbuf, 1, 43));/*C196-C238*/
                  strcat(prtstr, sformat_trade("+", 2, 1));      /*C239-C239:�[�h�O�O+��-�O��*/
                  strcat(prtstr, sformat_trade(&iTmpbuf, 1, 9)); /*C232-C240:�[�h�O�I�O */
                  strcat(prtstr, sformat_trade(" ", 2, 17));     /*C249-C265:�j�����*/
                  strcat(prtstr, drate_yyyymm);                  /*C266-C271:�O�v��I�~��*/

                  strcpy(dendorse_c, cm_cdate_str_100(dedr_begin));
                  cm_split_ymd_100(dendorse_c, dply_yy, dply_mm, tmp_dd);
                  yy_long = 1911 + atoi(dply_yy);
                  strcpy(tmp_yyyy, itoa(yy_long));
                  strcat(prtstr, sformat_trade(tmp_yyyy, 2, 4));
                  strcat(prtstr, sformat_trade(dply_mm, 2, 2));
                  strcat(prtstr, sformat_trade(tmp_dd, 2, 2));
                                                          /*C272-279:���ͮĤ�*/

                  strcpy(dendorse_c, cm_cdate_str_100(dendorse));
                  cm_split_ymd_100(dendorse_c, dply_yy, dply_mm, tmp_dd);
                  yy_long = 1911 + atoi(dply_yy);
                  strcpy(tmp_yyyy, itoa(yy_long));
                  strcat(prtstr, sformat_trade(tmp_yyyy, 2, 4));
                  strcat(prtstr, sformat_trade(dply_mm, 2, 2));
                  strcat(prtstr, sformat_trade(tmp_dd, 2, 2));
                                                          /*C280-287:�����*/
                  iins_type_tradevan[2] = '\0';
                  strcat(prtstr, iins_type_tradevan);     /*C288-289:�F�d�I�إN�X */
                  cntrlrec++;
                  fprintf(fptr, "%s\n", prtstr);

               }
               $CLOSE PLY_INS_CUR;
               $FREE PLY_INS_CUR;
            } /* end �L�� */

            /* car9602053 ���s�W���N�I�L�����O */
            if (*sFedr_class != '2')
            {
               $OPEN scur_edr3 USING $iendorse;
               while(1)
               {
                  $FETCH scur_edr3
                    INTO $iedr_type, $iins_type, $medrinj_cover, $medrdea_cover,
                         $medrdmg_cover, $mdeduct, $medrins_prem, $mprem, $drate_ym;

                  printf(">>>fetch edr_ins_type,[%d] iedr_type[%s]\n",medrins_prem,iedr_type);
                  printf("iendorse[%s]  prem_total[%d]\n",iendorse, prem_total);

                  if (SQLCODE==SQLNOTFOUND)
                  {
                     $CLOSE scur_edr3;
                     break;
                  }

                        strcpy(iins_type_rule," ");
                        strcpy(iins_type_tradevan," ");
                        $SELECT iins_type_rule, iins_type_tradevan
                           INTO $iins_type_rule, $iins_type_tradevan
                           FROM insurance_type
                          WHERE iins_type = $iins_type;
                          if (strlen(trim(iins_type_rule)) == 0)
                          {
                              strcpy(iins_type_rule,iins_type);
                          }

                        if((strcmp(fcard_class,"2")==0) && (strcmp(trim(iins_type_rule),"21")==0))
                           {  strcpy(iins_type_rule,"23    ");  }

                        prem_total += medrins_prem;

                        prtstr[186] = '\0';

                   $SELECT to_char(drate,'%Y%m')
                      INTO $drate_yyyymm
                      FROM ca_rate_date
                     WHERE icode=$drate_ym
                       AND itable='cover_vs_premium';

                  if (strcmp(iedr_type, "01") == 0 ||    /*���P*/
                      strcmp(iedr_type, "02") == 0 ||    /*���~�h�O*/
                      strcmp(iedr_type, "03") == 0 ||    /*�j��h�O*/
                      strcmp(iedr_type, "60") == 0 )     /*�h���h�O*/
                  {
                     if (strcmp(iedr_type, "60") == 0)
                        strcat(prtstr , "02");
                     else if (strcmp(iedr_type,"01") == 0 || strcmp(iedr_type,"03") == 0)
                        strcat(prtstr, iedr_type);
	                  else
	                  {
                        /* car9810302 */
                        /* ���ʽ謰02���~�h�O��,�ݭn�h��terminate_rsn�h�P�_�ݭn�ǰe��ةʽ�����T */
                        if (strcmp(terminate_rsn,"1") == 0 || strcmp(terminate_rsn,"9") == 0)
                           strcat(prtstr,"03");
                        else if (strcmp(terminate_rsn,"4") == 0)
                           strcat(prtstr,"04");
                        else
                           strcat(prtstr,"02");
                     }

                      if ( ldpolicy < date_1000901) /* ñ���< 09/01/2011�A�ǰeinsurance_type.iins_type_rule */
                      {
                          puts("ñ���<09/01/2011");
                          if( strcmp( trim(iins_type_rule), "15") == 0 ||
                              strcmp( trim(iins_type_rule), "16") == 0)
                              strcat(prtstr, iins_type);                     /*C189-194:�����I�إN�X*/
                          else
                              strcat(prtstr, iins_type_rule);             /*C189-194:�����I�إN�X*/
                      }
                      else
                      {
                          puts("ñ���>=09/01/2011");
                          strcat(prtstr, iins_type);                     /*C189-194:�����I�إN�X*/
                      }

                     strcat(prtstr, " ");                                    /* C195-195:�W��O�B+/-�O�� */

                      iTmpbuf = 0;
                      strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));
                      strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));
                      strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));
                      strcat(prtstr, sformat_trade(&iTmpbuf, 1, 12));
                      strcat(prtstr, sformat_trade(&iTmpbuf, 1, 7));

                      strcat(prtstr, "-");                                /* C239-239:�[�h�O�O+��-�O�� */
                      rfmtlong(((-1) * medrins_prem), "&&&&&&&&&", medrins_prem_c);
                      strcat(prtstr, medrins_prem_c);                     /*C240-248:�[�h�O�O*/
                      strcat(prtstr, sformat_trade(" ", 2, 17));          /*C249-265:�j�����*/
                      strcat(prtstr, drate_yyyymm);                       /*C266-271:�O�v��I�~�� */

                  }
	               else if (strcmp(iedr_type, "04") == 0 ||    /*�O�B�ܰ�*/
	                        strcmp(iedr_type, "40") == 0 ||    /*�O�O�ܰ�*/
	                        strcmp(iedr_type, "85") == 0 ||    /*�j��ɮt�B*/
	                        strcmp(iedr_type, "76") == 0 ||
	                        strcmp(iedr_type, "78") == 0 ||
	                        strcmp(iedr_type, "75") == 0 )     /* �s�W��2010/04/21 */
	          {
	                        strcpy(prtstr, strcol18);
                             strcat(prtstr, "04"); /*C187-C188:���ʽ�N�� */

                             if ( ldpolicy < date_1000901) /* ñ���< 09/01/2011�A�ǰeinsurance_type.iins_type_rule */
                             {
                                 puts("ñ���<09/01/2011");
                                 if( strcmp( trim(iins_type_rule), "15") == 0 ||
                                     strcmp( trim(iins_type_rule), "16") == 0)
                                     strcat(prtstr, iins_type);                     /*C189-194:�����I�إN�X*/
                                 else
                                     strcat(prtstr, iins_type_rule);             /*C189-194:�����I�إN�X*/
                             }
                             else
                             {
                                 puts("ñ���>=09/01/2011");
                                 strcat(prtstr, iins_type);                     /*C189-194:�����I�إN�X*/
                             }

                             if ((medrinj_cover + medrdea_cover + medrdmg_cover) >= 0) /* C195-195:�W��O�B+/-�O�� */
                                  strcat(prtstr, "+");
                             else if ((medrinj_cover + medrdea_cover + medrdmg_cover) < 0)
                                  strcat(prtstr, "-");
                             else strcat(prtstr, " ");

                             if (medrinj_cover < 0) medrinj_cover *= -1;
                             if (medrdea_cover < 0) medrdea_cover *= -1;
                             if (medrdmg_cover < 0) medrdmg_cover *= -1;

                             rfmtlong(medrinj_cover, "&&&&&&&&", minjured_c);
                             strcat(prtstr,minjured_c);                    /*C196-203:��˫O�B*/
                             rfmtlong(medrdea_cover,"&&&&&&&&",mdeath_c);
                             strcat(prtstr,mdeath_c);                      /*C204-211:�ݼo�O�B*/
                             rfmtlong(medrdea_cover,"&&&&&&&&",mdeath_c);
                             strcat(prtstr,mdeath_c);                      /*C212-219:���`�O�B*/
                             rfmtlong(medrdmg_cover,"&&&&&&&&&&&&",mdamage_c);
                             strcat(prtstr, mdamage_c);                    /*C220-231:�O�B*/
                             strcat(prtstr, sformat_trade(&iTmpbuf, 1, 7));/*C232-238:�ۭt�B */

                             if (medrins_prem >= 0) strcat(prtstr, "+");   /*C239-239:�[�h�O�O+��-�O�� */
                             else if (medrins_prem <0) strcat(prtstr, "-");
                             else strcat(prtstr, " ");

                             if (medrins_prem < 0) medrins_prem *= -1;
                             rfmtlong(medrins_prem, "&&&&&&&&&", medrins_prem_c);
                             strcat(prtstr, medrins_prem_c);               /*C240-248:�[�h�O�O*/
                             strcat(prtstr, sformat_trade(" ", 2, 17));    /*C249-265:�j�����*/
                             strcat(prtstr, drate_yyyymm);     /*C266-271:�O�v��I�~��*/
                  }
	          else if (strcmp(iedr_type, "05") == 0)  /*�[�O�I��*/
	          {
                             strcat(prtstr, iedr_type);                          /*C187-C188:���ʽ�N�� */

                             if ( ldpolicy < date_1000901) /* ñ���< 09/01/2011�A�ǰeinsurance_type.iins_type_rule */
                             {
                                 puts("ñ���<09/01/2011");
                                 if( strcmp( trim(iins_type_rule), "15") == 0 ||
                                     strcmp( trim(iins_type_rule), "16") == 0)
                                     strcat(prtstr, iins_type);                     /*C189-194:�����I�إN�X*/
                                 else
                                     strcat(prtstr, iins_type_rule);             /*C189-194:�����I�إN�X*/
                             }
                             else
                             {
                                 puts("ñ���>=09/01/2011");
                                 strcat(prtstr, iins_type);                     /*C189-194:�����I�إN�X*/
                             }

                             strcat(prtstr, " ");                               /* C195-195:�W��O�B+/-�O�� */
                             rfmtlong(medrinj_cover, "&&&&&&&&", minjured_c);
                             strcat(prtstr,minjured_c);                         /*C196-203:��˫O�B*/
                             rfmtlong(medrdea_cover,"&&&&&&&&",mdeath_c);
                             strcat(prtstr,mdeath_c);                           /*C204-211:�ݼo�O�B*/
                             rfmtlong(medrdea_cover,"&&&&&&&&",mdeath_c);
                             strcat(prtstr,mdeath_c);                           /*C212-219:���`�O�B*/
                             rfmtlong(medrdmg_cover,"&&&&&&&&&&&&",mdamage_c);
                            strcat(prtstr, mdamage_c);                          /*C220-231:�O�B*/
                            strcat(prtstr, sformat_trade(&iTmpbuf, 1, 7));      /*C232-238:�ۭt�B */
                            if (medrins_prem >= 0) strcat(prtstr, "+");         /*C239-239:�[�h�O�O+��-�O�� */
                            else if (medrins_prem <0) strcat(prtstr, "-");
                            else strcat(prtstr, " ");
                            rfmtlong(medrins_prem, "&&&&&&&&&", medrins_prem_c);
                            strcat(prtstr, medrins_prem_c);                     /*C240-248:�[�h�O�O*/

                            strcat(prtstr, sformat_trade(" ", 2, 17));           /*C249-265:�j�����*/
                            strcat(prtstr, drate_yyyymm);                        /*C266-271:�O�v��I�~��*/
                  }
	          else if ( strcmp(iedr_type, "20") == 0 ||
	                    strcmp(iedr_type, "77") == 0 )      /*�ۭt�B�ܰ�*/
	          {
                            strcat(prtstr, "11");

                            if ( ldpolicy < date_1000901) /* ñ���< 09/01/2011�A�ǰeinsurance_type.iins_type_rule */
                            {
                                puts("ñ���<09/01/2011");
                                if( strcmp( trim(iins_type_rule), "15") == 0 ||
                                    strcmp( trim(iins_type_rule), "16") == 0)
                                    strcat(prtstr, iins_type);                     /*C189-194:�����I�إN�X*/
                                else
                                    strcat(prtstr, iins_type_rule);             /*C189-194:�����I�إN�X*/
                            }
                            else
                            {
                                puts("ñ���>=09/01/2011");
                                strcat(prtstr, iins_type);                     /*C189-194:�����I�إN�X*/
                            }

                            strcat(prtstr, " ");                               /* C195-195:�W��O�B+/-�O�� */
                            iTmpbuf = 0;
                            strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));     /*C196-203:��˫O�B*/
                            strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));     /*C204-211:�ݼo�O�B*/
                            strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));     /*C212-219:���`�O�B*/
                            strcat(prtstr, sformat_trade(&iTmpbuf, 1, 12));    /*C220-231:�O�B*/

                            sprintf_s(stmt_buf5, sizeof stmt_buf5,"SELECT mdeduct, mins_premium"
                                              "  FROM %s:ply_ins_type_bak"
                                              " WHERE iendorse = ? AND ipolicy = ? "
                                              "   AND iins_type = ? ; ",tmp_dbname);

                            $PREPARE CUS_PLY_BAK from $stmt_buf5;
                            $EXECUTE CUS_PLY_BAK INTO $lTmpMdeduct, $lTmpMins_premium
                               USING $iendorse, $ipolicy, $iins_type;

                            if (SQLCODE == SQLNOTFOUND) continue;

                            rfmtlong(lTmpMdeduct, "&&&&&&&", mdeduct_c);
                            strcat(prtstr, mdeduct_c);                         /*C232-238:�ۭt�B */

                            strcat(prtstr, "-");                               /*C239-239:�[�h�O�O+��-�O�� */
                            rfmtlong(lTmpMins_premium, "&&&&&&&&&", medrins_prem_c);
                            strcat(prtstr, medrins_prem_c);                    /*C240-248:�[�h�O�O*/

                            strcat(prtstr, sformat_trade(" ", 2, 17));         /*C249-265:�j�����*/

                            strcat(prtstr, drate_yyyymm);                      /*C266-271:�O�v��I�~��*/

                            strcpy(dendorse_c, cm_cdate_str_100(dedr_begin));
                            cm_split_ymd_100(dendorse_c, dply_yy, dply_mm, tmp_dd);
                            yy_long = 1911 + atoi(dply_yy);
                            strcpy(tmp_yyyy, itoa(yy_long));
                            strcat(prtstr, sformat_trade(tmp_yyyy, 2, 4));
                            strcat(prtstr, sformat_trade(dply_mm, 2, 2));
                            strcat(prtstr, sformat_trade(tmp_dd, 2, 2));
                                                                  /*C264-271:���ͮĤ�*/
                            strcpy(dendorse_c, cm_cdate_str_100(dendorse));
                            cm_split_ymd_100(dendorse_c, dply_yy, dply_mm, tmp_dd);
                            yy_long = 1911 + atoi(dply_yy);
                            strcpy(tmp_yyyy, itoa(yy_long));
                            strcat(prtstr, sformat_trade(tmp_yyyy, 2, 4));
                            strcat(prtstr, sformat_trade(dply_mm, 2, 2));
                            strcat(prtstr, sformat_trade(tmp_dd, 2, 2));
                                                                  /*C272-279:�����*/

                            cntrlrec++;
                            fprintf(fptr, "%s\n", prtstr);

                            prtstr[186] = '\0';

                            strcat(prtstr, "12");                               /*C187-C188:���ʽ�N�� */
                     
                            if ( ldpolicy < date_1000901) /* ñ���< 09/01/2011�A�ǰeinsurance_type.iins_type_rule */
                            {
                                puts("ñ���<09/01/2011");
                                if( strcmp( trim(iins_type_rule), "15") == 0 ||
                                    strcmp( trim(iins_type_rule), "16") == 0)
                                    strcat(prtstr, iins_type);                     /*C189-194:�����I�إN�X*/
                                else
                                    strcat(prtstr, iins_type_rule);             /*C189-194:�����I�إN�X*/
                            }
                            else
                            {
                                puts("ñ���>=09/01/2011");
                                strcat(prtstr, iins_type);                     /*C189-194:�����I�إN�X*/
                            }

                            strcat(prtstr, " ");                                 /* C195-195:�W��O�B+/-�O�� */
                            iTmpbuf = 0;
                            strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));       /*C196-203:��˫O�B*/
                            strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));       /*C204-211:�ݼo�O�B*/
                            strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));       /*C212-219:���`�O�B*/
                            strcat(prtstr, sformat_trade(&iTmpbuf, 1, 12));      /*C220-231:�O�B*/
                            rfmtlong(mdeduct, "&&&&&&&", mdeduct_c);
                            strcat(prtstr, mdeduct_c);                           /*C232-238:�ۭt�B */
                            strcat(prtstr, "+");                                 /*C239-239:�[�h�O�O+��-�O�� */
                            lTmpMins_premium += medrins_prem;
                            rfmtlong(lTmpMins_premium, "&&&&&&&&&", medrins_prem_c);
                            strcat(prtstr, medrins_prem_c);                      /*C240-248:�[�h�O�O*/
                            strcat(prtstr, sformat_trade(" ", 2, 17));           /*C249-265:�j�����*/
                            strcat(prtstr, drate_yyyymm);                        /*C266-271:�O�v��I�~��*/

                  }
	          else if (strcmp(iedr_type, "50") == 0)  /*�_��*/
	          {
                            strcat(prtstr, "08");                                /*C187-C188:���ʽ�N�� */

                            if ( ldpolicy < date_1000901) /* ñ���< 09/01/2011�A�ǰeinsurance_type.iins_type_rule */
                            {
                                puts("ñ���<09/01/2011");
                                if( strcmp( trim(iins_type_rule), "15") == 0 ||
                                    strcmp( trim(iins_type_rule), "16") == 0)
                                    strcat(prtstr, iins_type);                     /*C189-194:�����I�إN�X*/
                                else
                                    strcat(prtstr, iins_type_rule);             /*C189-194:�����I�إN�X*/
                            }
                            else
                            {
                                puts("ñ���>=09/01/2011");
                                strcat(prtstr, iins_type);                     /*C189-194:�����I�إN�X*/
                            }

                            strcat(prtstr, " ");                               /* C195-195:�W��O�B+/-�O�� */

                            iTmpbuf = 0;
                            strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));     /*C196-203:��˫O�B*/
                            strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));     /*C204-211:�ݼo�O�B*/
                            strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));     /*C212-219:���`�O�B*/
                            strcat(prtstr, sformat_trade(&iTmpbuf, 1, 12));    /*C220-231:�O�B*/
                            strcat(prtstr, sformat_trade(&iTmpbuf, 1, 7));     /*C232-238:�ۭt�B */
                            strcat(prtstr, "+");                               /*C239-239:�[�h�O�O+��-�O�� */
                            rfmtlong(medrins_prem, "&&&&&&&&&", medrins_prem_c);
                            strcat(prtstr, medrins_prem_c);                    /*C240-248:�[�h�O�O*/
                            strcat(prtstr, sformat_trade(" ", 2, 17));         /*C249-265:�j�����*/
                            strcat(prtstr, drate_yyyymm);                      /*C266-271:�O�v��I�~��*/

                  }
	          else if (strcmp(iedr_type, "79") == 0) /*** ���O�� ***/
	          {
                     /* �Y���O���ܰ�(79)�Ϊ̬O��L+�O���ܰ�(75),��h�W�u�eAC,�L�ݦA�e�@��99 */
                     /* 2010/04/21,�ȫO���ܰ�(79)�L�ݰe����,��75�]���|�����B�ܰ�,�ҥH
                     �N75����W���O�O�ܰʪ����ظ̧אּ�h�e�@��08 */
                     continue;
	               }
                  else if(strcmp(iedr_type, "07") == 0)  /**/
	          {
                            strcat(prtstr, "07");                              /*C187-C188:���ʽ�N�� */

                            if ( ldpolicy < date_1000901) /* ñ���< 09/01/2011�A�ǰeinsurance_type.iins_type_rule */
                            {
                                puts("ñ���<09/01/2011");
                                if( strcmp( trim(iins_type_rule), "15") == 0 ||
                                    strcmp( trim(iins_type_rule), "16") == 0)
                                    strcat(prtstr, iins_type);                     /*C189-194:�����I�إN�X*/
                                else
                                    strcat(prtstr, iins_type_rule);             /*C189-194:�����I�إN�X*/
                            }
                            else
                            {
                                puts("ñ���>=09/01/2011");
                                strcat(prtstr, iins_type);                     /*C189-194:�����I�إN�X*/
                            }

                            strcat(prtstr, " ");                               /* C195-195:�W��O�B+/-�O�� */
                            iTmpbuf = 0;
                            strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));     /*C196-203:��˫O�B*/
                            strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));     /*C204-211:�ݼo�O�B*/
                            strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));     /*C212-219:���`�O�B*/
                            strcat(prtstr, sformat_trade(&iTmpbuf, 1, 12));    /*C220-231:�O�B*/
                            strcat(prtstr, sformat_trade(&iTmpbuf, 1, 7));     /*C232-238:�ۭt�B */

                            if (medrins_prem >= 0) strcat(prtstr, "+");        /*C239-239:�[�h�O�O+��-�O�� */
                            else if (medrins_prem <0) strcat(prtstr, "-");
                            else strcat(prtstr, " ");

                            if (medrins_prem < 0) medrins_prem *= -1;
                            rfmtlong(medrins_prem, "&&&&&&&&&", medrins_prem_c);
                            strcat(prtstr, medrins_prem_c);                    /*C240-248:�[�h�O�O*/
                            strcat(prtstr, sformat_trade(" ", 2, 17));         /*C249-265:�j�����*/
                            strcat(prtstr, drate_yyyymm);                      /*C266-271:�O�v��I�~��*/

                  }

                        if ( strcmp ( iedr_type , "20" ) == 0 )
                           printf("len[%d] prtstr[%s]\n",strlen(prtstr),prtstr);

                        strcpy(dendorse_c, cm_cdate_str_100(dedr_begin));
                        cm_split_ymd_100(dendorse_c, dply_yy, dply_mm, tmp_dd);
                        yy_long = 1911 + atoi(dply_yy);
                        strcpy(tmp_yyyy, itoa(yy_long));
                        strcat(prtstr, sformat_trade(tmp_yyyy, 2, 4));
                        strcat(prtstr, sformat_trade(dply_mm, 2, 2));
                        strcat(prtstr, sformat_trade(tmp_dd, 2, 2));
                                                                           /*C272-279:���ͮĤ�*/
                        strcpy(dendorse_c, cm_cdate_str_100(dendorse));
                        cm_split_ymd_100(dendorse_c, dply_yy, dply_mm, tmp_dd);
                        yy_long = 1911 + atoi(dply_yy);
                        strcpy(tmp_yyyy, itoa(yy_long));
                        strcat(prtstr, sformat_trade(tmp_yyyy, 2, 4));
                        strcat(prtstr, sformat_trade(dply_mm, 2, 2));
                        strcat(prtstr, sformat_trade(tmp_dd, 2, 2));
                                                                           /*C280-287:�����*/
                        iins_type_tradevan[2] = '\0';
                        strcat(prtstr, iins_type_tradevan);     /*C288-289:�F�d�I�إN�X */

                        cntrlrec++;
                        fprintf(fptr, "%s\n", prtstr);
               }   /* End of while which is scur_edr3 */
               $CLOSE scur_edr3;
            }  /* �P�_�O�_���L�� */
         }  /****End of ����r��蠟�~����� ***/
      } /* end of while which is scur_car9972 */
      $CLOSE scur_car9972;
      $FREE  scur_car9972;

      if (cntrlrec > 0)
      {
         strcpy(prtstr,"CNTRLREC");
         rfmtlong(cntrlrec,"&&&&&&",cntrlrec_c);
         strcat(prtstr,cntrlrec_c);
         fprintf(fptr, "%s\n", prtstr);
      }
      else if ( cntrlrec == 0 )
      {
         rstrdate( dbgn1 , &dendorse );

         strcpy( endorse_c , cm_cdate_str_100( dendorse ));

         cm_split_ymd_100(endorse_c,day_yy,day_mm,day_dd);

         /*printf("endorse_c[%s] day_yy[%s]\n",endorse_c,day_yy);*/

         if ( strcmp(option,"2") == 0 )
         {
            sprintf_s(Tmp1, sizeof Tmp1,"ISBH%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
            strcpy(iply_type,"bh");

            strcpy(fcard_class, "2");
         }
         else
         {
            if(online) sprintf_s(Tmp1, sizeof Tmp1,"ISBH%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
            else sprintf_s(Tmp1, sizeof Tmp1,"ISBH%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
         }

         sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);

         printf("[NODATA] file0[%s] Tmp1[%s]\n",file0,Tmp1);
         fptr=fopen(file0,"w");

         strcpy(prtstr,"CNTRLREC");
         rfmtlong(0,"&&&&&&",cntrlrec_c);
         strcat(prtstr,cntrlrec_c);
         fprintf(fptr, "%s\n", prtstr);

         cntrlrec = prem_total = 0;
      }

      printf("### cntrlrec=[%s]\n",cntrlrec_c);

      fclose(fptr);

      rtncode = rptftpinsert( userid , "car9972" , Tmp1 );

      printf(" ******************************************* \n");

      if (strcmp(option,"4") != 0 && strcmp(option,"5") != 0)
      {
         $insert into ca_trade_exam
            (iply_type,dpolicy,fcard_class,itrans_type,
             qcount,mamount,minjure,mcripple,mdeath)
          values
            ($iply_type,$dendorse,$fcard_class,0,
             $cntrlrec,$prem_total,0,0,0);
      }

      sprintf_s(strlog, sizeof strlog,"���ɧ���:%s ���:%d",file0,cntrlrec);
      WRITELOG(errfpt , strlog);

      printf("errfpt[%s]\n",strlog);
   /* } */

   if (errfpt!=NULL) ENDLOG(errfpt);

   return M_CM_OK;

errexit:
    printf("car9972vol:sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    rc = SQLCODE;
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return rc;

}

/* ------------------------------------------------------------------------- */

char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
   char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
   char sTmp_db_name[21];

   sTmp_db_name[0]='\0';
   if (*sIpolicy != '\0' && *sIpolicy !=' ')
   {
      sTmp_db_name[0]='\0';
      strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
      strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
         USE_BRANCH_ID));
      strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
   }
   return sTmp_db_name;
}

/* ------------------------------------------------------------------------- */

long check_if_exist( iply_type, dpolicy, fcard_class, trans_type )
$char *iply_type;
$int dpolicy;
$char *fcard_class;
$int trans_type;
{

   $long trade_count, err_count, out_count;

   printf("iply_type[%s] dpolicy[%d]\n",iply_type,dpolicy);
   printf("fcard_class[%s] trans_type[%d]\n",fcard_class,trans_type);


   $SELECT qtradevan, qerr, qout
      INTO $trade_count, $err_count, $out_count
      FROM ca_trade_exam
     WHERE iply_type = $iply_type
       AND dpolicy = $dpolicy
       AND fcard_class = $fcard_class
       AND itrans_type = $trans_type;

   if ( SQLCODE == SQLNOTFOUND )  return M_CM_OK;

   printf("trade_count[%d] [%d] [%d]\n",trade_count,err_count,out_count);


   if ( trade_count==0 && err_count==0 && out_count==0 )
   {

      $DELETE FROM ca_trade_exam
        WHERE iply_type = $iply_type
          AND dpolicy = $dpolicy
          AND fcard_class = $fcard_class
          AND itrans_type = $trans_type;

      return M_CM_OK;

   }

   strcpy(sqlca.sqlerrm ,"�L�k���J�s�C - �b UNIQUE INDEX ��즳���Э�");

   return 239;

errexit:
    printf("check_if_exist:sqlcode=%d, sqlmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    rc = SQLCODE;
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return rc;

}

/* -------------------------------------------------------------------------- */
long car9972_build_vol2()
{
   $char Tmp1[20],file0[51],tstmt[1024],stmt_buf2[1024],stmt_buf3[1024];
   $char stmt_buf4[600],stmt_buf5[500],stmt_bufa[500], stmt_bufb[500], stmt_bufx[1024];
   $char drate_c[7], sIbrand_new[10],chk_dpolicy[2],chk_157[2];
   char  tmp_dbname[20];
   char  day_yy[5],day_mm[3],day_dd[3];
   $date Today;
   $long ldpolicy, lchk_date, iCount;
   long  rtncode;
   int  cond=0,i=0;

   $long date_1000901;
   $char iins_type_rule[7], iins_type[7], sTmpInsType[7], iins_type_tradevan[7], iins_type_tmp[7];
   $char mdamage_c[13], drate_yyyymm[7];
   $char table_name[21], col_name[21], using_key[21], iendorse_next[21], stmt1[512], sIins_type[7];


   rtoday(&Today);
   rstrdate( "09/01/2011", &date_1000901);

   /* If option = 1,2,3, loop is only running once; if option = 4, loop is running 4 times */
   /* �]�{���w���I��(�j��,���N)�Υ\��(���e,���e,�簣���e)����, �G�����j����榸�� modify by sylvia 99.12.03 */

      cntrlrec = 0;
      sprintf_s(tstmt, sizeof tstmt,"SELECT * FROM CAR9972");
   /* ���N�T���O�I���,car9901111�אּ�������N���e���T */

      strcat(tstmt," WHERE TsFcard_class = '2' ");
      /* 1000413004_C1 �����I�]�n�e���T�@mark by sylvia 100.05.02  */
      /*�@strcat(tstmt,"   AND Ticar_type not in ('01','02','32','34')"); */
      strcat(tstmt," ORDER BY dcreate, Tiendorse ");

      printf("tstmt[%s]\n",tstmt);

      $PREPARE CUR_TSTMT FROM $tstmt;
      $DECLARE scur_car9972A CURSOR FOR CUR_TSTMT;

      $OPEN scur_car9972A;

      iFetch = True;
      while(1)
      {
         $FETCH scur_car9972A
           INTO $iendorse, $ipolicy,   $sFedr_class, $sFcard_class, $icard,
                $dendorse, $icar_type, $iissue_ym,   $ibrand,       $ipro_year,
                $dedr_begin, $fcomp_class, $terminate_rsn, $dcreate;

         if (SQLCODE == SQLNOTFOUND) break;

         strcpy(tmp_dbname,get_car_full_db(ipolicy));

         /***** prepare cursor for select endorsement *****/

         sprintf_s(stmt_buf2, sizeof stmt_buf2,"SELECT %s %s %s FROM %s:%s %s",
                           "ilicense,to_char(dbirth,'%Y'), to_char(dbirth,'%m'), to_char(dbirth,'%d'),fsex,fmarriage,qcylinder::int,qpt,fpt,iengine,ibody,",
                           "itag,iassured,nassured,dply_begin,dply_end,",
                           "pdmg_align,pbrg_align,plia_align, iply_area, fassured, to_char(dissue, '%Y'), to_char(dissue, '%m')",
                           tmp_dbname,"endorsement ",
                           "WHERE iendorse=? ");

         $PREPARE CUR_STMT2 FROM $stmt_buf2;
         $DECLARE scur_edr2A CURSOR FOR CUR_STMT2;

         /***** prepare cursor for select edr_ins_type *****/
         sprintf_s(stmt_buf3, sizeof stmt_buf3,"SELECT %s %s FROM %s:%s %s ",
                           "iedr_type,iins_type,medrinj_cover,medrdea_cover,medrdmg_cover,",
                           "mdeduct,medrins_prem,medr_prem,drate_ym",
                           tmp_dbname,"edr_ins_type",
                           "WHERE iendorse=? and iedr_type not in ('79','10') and iins_type not in ('171','172','173','174','175') order by iedr_type");
         $PREPARE CUR_STMT3 FROM $stmt_buf3;
         $DECLARE scur_edr3A CURSOR FOR CUR_STMT3;

         qpt = 0;

         $OPEN scur_edr2A USING $iendorse;
         $FETCH scur_edr2A
           INTO $ilicense, $ibirth_yy, $ibirth_mm, $ibirth_dd, $fsex, $fmarriage, $qcylinder, $qpt:id1, $fpt,
                $iengine, $ibody, $itag, $iassured, $nassured, $dply_begin, $dply_end,
                $ipdmg_align, $ipbrg_align, $iplia_align, $iply_area, $fassured, $iissue_yy, $iissue_mm;

         if (SQLCODE == SQLNOTFOUND)
         {
            $CLOSE scur_edr2A;
            continue;
         }
         $CLOSE scur_edr2A;

         rtn = getCompanyId(companyid);

         printf(" ************************** companyid[%s]\n",companyid);

         if (iFetch)                 /*�Ĥ@�����W�@���O�ۤv*/
         {
            sDendorse = dendorse;
            iFetch = FALSE;
            prem_total = 0;

            strcpy( endorse_c , cm_cdate_str_100( dendorse ));

            cm_split_ymd_100(endorse_c,day_yy,day_mm,day_dd);

            if ( strcmp(option,"2") == 0 )
            {

               sprintf_s(Tmp1, sizeof Tmp1,"ISBH%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
               strcpy(iply_type,"bh");

               strcpy(fcard_class, "2");
            }
            else
            {
               if(online) sprintf_s(Tmp1, sizeof Tmp1,"ISBH%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
               else sprintf_s(Tmp1, sizeof Tmp1,"ISBH%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
            }
            sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);

            printf("[NOERROR]file0[%s] Tmp1[%s]\n",file0,Tmp1);
            fptr=fopen(file0,"w");


            if (strcmp(option,"4") != 0 || strcmp(option,"5") != 0)
            {
               rc = check_if_exist(iply_type,dendorse,fcard_class,0);
               if ( rc != M_CM_OK )
                  return rc;
            }
         }  /* End of If which is iFetch */

         /* �����ثefile , open a new file*/

         if ( sDendorse != dendorse )
         {
            if (cntrlrec > 0)
            {
               strcpy(prtstr, sformat_trade("CNTRLREC", 4, 8));
               sprintf_s(cntrlrec_c, sizeof cntrlrec_c, "%ld", cntrlrec);
               strcat(prtstr, sformat_trade(cntrlrec_c, 5, 6));
               fprintf(fptr, "%s\n", prtstr);
            }

            printf("### cntrlrec=[%s]\n",cntrlrec_c);

            fclose(fptr);

            rtncode = rptftpinsert( userid , "car9972" , Tmp1 );

            if (strcmp(option,"4") != 0 && strcmp(option,"5") != 0)
            {
               $insert into ca_trade_exam
                  (iply_type,dpolicy,fcard_class,itrans_type,
                   qcount,mamount,minjure,mcripple,mdeath)
                values
                  ($iply_type,$sDendorse,$fcard_class,0,
                   $cntrlrec,$prem_total,0,0,0);
            }

            sprintf_s(strlog, sizeof strlog,"���ɧ���:%s ���:%d",file0,cntrlrec);

            WRITELOG(errfpt , strlog);

            printf("errfpt[%s]\n",strlog);

            strcpy( endorse_c , cm_cdate_str_100( dendorse ));

            cm_split_ymd_100(endorse_c,day_yy,day_mm,day_dd);

            if ( strcmp(option,"2") == 0 )
            {
               sprintf_s(Tmp1, sizeof Tmp1,"ISBH%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
               strcpy(iply_type,"bh");

               strcpy(fcard_class, "2");
            }
            else
            {

               if(online) sprintf_s(Tmp1, sizeof Tmp1,"ISBH%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
               else sprintf_s(Tmp1, sizeof Tmp1,"ISBH%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
            }

            sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);

            printf("[002]file0[%s] Tmp1[%s]\n",file0,Tmp1);
            fptr=fopen(file0,"w");

            rc = check_if_exist(iply_type,dendorse,fcard_class,0);
            if ( rc != M_CM_OK )
               return rc;

            cntrlrec = 0;
            prem_total = 0;
         }

         /* car9212111 ���o�O��ñ���dpolicy�A�P�_�ǰe���T�I�إN�� */
         sprintf_s(stmt_bufa, sizeof stmt_bufa,"SELECT dpolicy , CASE WHEN dpolicy < '08/01/2016' THEN 'Y' ELSE 'N' END, \
                                   case when ipolicy[6,7] = 'V7' then 'Y' else 'N' end \
                              FROM %s:ply_relation \
                            WHERE ipolicy = '%s' ", tmp_dbname, ipolicy );

         $PREPARE EXE_STMTa FROM $stmt_bufa;
         $EXECUTE EXE_STMTa INTO $ldpolicy,$chk_dpolicy,$chk_157;

         if(strcmp(companyid,"17")==0)
         {
            company_flag=ipolicy[7];

            printf(" ipolicy[%s]\n",ipolicy);
            printf(" company_flag[%c]\n",company_flag);
            strcpy(CAR_COMPANY_P,"17");

            if(company_flag > 65 )
            {
               printf(" *************************************\n");
               $select ipolicy_a
                  into $ipolicy_chg
                  from conv_ipolicy
                 where ipolicy_n = $ipolicy;

               printf(" ****************** ipolicy[%s]\n",ipolicy);
               strcpy(CAR_COMPANY_E,"16");
               printf(" ****************** CAR_COMPANY_E[%s]\n",CAR_COMPANY_E);
            }
            else
            {
               strcpy(ipolicy_chg, ipolicy );
               strcpy(CAR_COMPANY_E,"17");
               printf(" ****************** CAR_COMPANY_E[%s]\n",CAR_COMPANY_E);
            }
         }
         else
         {
            strcpy(ipolicy_chg, ipolicy );
            strcpy(CAR_COMPANY_P,"32");
            strcpy(CAR_COMPANY_E,"32");
         }

         sDendorse = dendorse;

         strcpy(prtstr, sformat_trade("9", 4, 1));                /*C1:���ʧO*/
         strcpy(strtmp, CAR_COMPANY_E);

         if ((iRtnCode = split_policy(ipolicy_chg, sTmpbuf, objno)) != M_CM_OK)
         {
            printf("[%s][%s]\n", iendorse, ipolicy_chg);
            fprintf(errfpt, "[%s][%s]\n", iendorse, ipolicy_chg);
            continue;
         }
         strcat(strtmp, sformat_trade(sTmpbuf, 2, 15));
         strcat(prtstr, sformat_trade(strtmp, 4, 17));             /*C2-C18:�O�渹�X */

         rstrdate( "07/14/2003", &lchk_date);

         strcpy(icard, trim(icard));
         strcpy(iendorse, trim(iendorse));
         strcpy(strtmp, CAR_COMPANY_P);
         strcat(strtmp, sformat_trade(iendorse, 2, 15));
         strcat(prtstr, sformat_trade(strtmp, 4, 17));             /*C19-35:��渹�X*/

	/* �N�{��u�a�ϥN�����v���R���N��42�u�x�����v�B�N��63�u�x�n���v�B�N��65�u�������v�C*/
	if( strcmp( iply_area, "42") == 0)
		strcpy( iply_area, "41");
	else if( strcmp( iply_area, "63") == 0)
		strcpy( iply_area, "62");
	else if( strcmp( iply_area, "65") == 0)
		strcpy( iply_area, "64");

         strcat(prtstr, sformat_trade(iply_area, 4, 2)); /*C36-37:�ӫO�a�ϥN��*/

         strcpy(dply_begin_c, cm_cdate_str_100(dply_begin));
         cm_split_ymd_100(dply_begin_c,dply_begin_yy,dply_begin_mm,dply_begin_dd);
         strcpy(tmp_yyyy, itoa(1911+atoi(dply_begin_yy)));

         strcpy(strtmp, sformat_trade(tmp_yyyy, 2, 4));
         strcat(strtmp, sformat_trade(dply_begin_mm, 2, 2));
         strcat(strtmp, sformat_trade(dply_begin_dd, 2, 2));
         strcat(prtstr, sformat_trade(strtmp, 4, 8));  /*C38-45:�O��_��*/

         strcpy(dply_end_c,cm_cdate_str_100(dply_end));
         cm_split_ymd_100(dply_end_c,dply_end_yy,dply_end_mm,dply_end_dd);
         strcpy(tmp_yyyy,itoa(1911+atoi(dply_end_yy)));
         strcpy(strtmp, sformat_trade(tmp_yyyy, 2, 4));
         strcat(strtmp, sformat_trade(dply_end_mm, 2, 2));
         strcat(strtmp, sformat_trade(dply_end_dd, 2, 2));
         strcat(prtstr, sformat_trade(strtmp, 4, 8)); /*C46-53:�O�樴��*/

         if (strlen(trim(objno)) > 0) strcat(prtstr, sformat_trade(objno, 4, 4));
         else strcat(prtstr, sformat_trade("0001",4,4));  /*C54-57:�O��Ъ���*/
                
         /*�o�Ӧ~���Τ�����,��iissue_ym�o������,�諾����original_ply.dissure�����쪺�~�� */
		 if (strncmp(chk_157,"Y",1) == 0)
		 {
         	strcat(prtstr, sformat_trade("000000", 4, 6));
         	strcat(prtstr, sformat_trade("0000", 4, 4));
		 }
		 else
		 {
         	strcpy(strtmp, sformat_trade(iissue_yy, 2, 4));
         	strcat(strtmp, sformat_trade(iissue_mm, 2, 2));
         	strcat(prtstr, sformat_trade(strtmp, 4, 6));     /*C58-63:�o�Ӧ~��*/

         	strcat(prtstr, sformat_trade(ipro_year, 4, 4));
                                                       /*C64-67:�s�Ӧ~��*/
         }
         /* �t�P�����N���ഫ modify by sylvia 100.09.30 (car9812112_C1) ----- */
           sIbrand_new[0] = '\0';
           $select first 1 ibrand_new into $sIbrand_new
              from ca_car_model
             where ibrand = $ibrand
               and ibrand_new <> ' '
             order by drate desc;
           
           if (sIbrand_new[0] != '\0')
               strcpy(ibrand, sIbrand_new);
         /* ----------------------------------------------------------------- */ 
         if (strncmp(chk_157,"Y",1) == 0)
         	strcat(prtstr, sformat_trade("00000000", 4, 8));
         else
         	strcat(prtstr, sformat_trade(ibrand, 4, 8));
                                                      /*C68-75:�t���N��*/
         strcat(prtstr, sformat_trade(iengine, 4, 25));
                                                       /*C76-95:�������X*/
         strcat(prtstr, sformat_trade(ibody, 4, 25));
                                                       /*C96-115:�������X*/
         /* 1061102009_C1 �ק�ǰe���T27���ؾ��񨮵P�W�h
         if (strcmp(icar_type, "27") == 0 && strcmp(chk_dpolicy,"Y") == 0)
            strcpy(itag, " ");        */                 /* ����27,���P���X�M�� modify by sylvia 101.02.24 (1001005007_C1) */
            
         strcat(prtstr, sformat_trade(itag, 4, 8));
                                                       /*C116-123:�P�Ӹ��X*/
         /*1110216005_SC2_�t�X�N�ɫO�ӫ~�վ�CAR401�B�q�l�O���E�O���t��*/
         /*if (strncmp(chk_157,"Y",1) == 0)
         	strcat(prtstr, sformat_trade("03", 4, 2));
         else*/
         strcat(prtstr, sformat_trade(icar_type, 4, 2));
                                                       /*C124-125:���إN��*/
                                                       
         /* iTmpbuf = 10 * qcylinder;*/
         sprintf_s(strtmp, sizeof strtmp, "%.1f", (double)qcylinder);

         strcat(prtstr, sformat_trade(strtmp, 4, 7));    /*C126-131:�Ʈ�q*/
         
         if (id1 == -1)
         {
            $SELECT MAX(qpassenger)
               INTO $qpt
               FROM ca_car_model
              WHERE ibrand = $ibrand;
         }

         /* iTmpbuf =  10 * qpt; */
         sprintf_s(strtmp, sizeof strtmp, "%.1f", (double)qpt);
         strcat(prtstr, sformat_trade(strtmp, 4, 5));
                                                          /*C132-135:�����ƶq*/
         if (strncmp(chk_157,"Y",1) == 0)
         	strcat(prtstr, sformat_trade("0", 4, 1));
         else
         	strcat(prtstr, sformat_trade(fpt, 4, 1));
                                                          /*C136-136:�������*/
         strcat(prtstr, sformat_trade(iassured, 4, 10));  /*C137-146 */

         /* nassured[20] = '\0'; */
         nassured_len = cc_split_chinese(nassured,nassured_1,20);
         strcpy(nassured_1, rtrim(nassured_1));
         strcat(prtstr, sformat_trade(nassured_1, 4, 20));  /*C147-166 */

         /*��Q�O�I�H�ͤ�b��Ʈw�̬Ocahr(6),�ӫO���X�W�Q�O�I�H�ͤ������,�諾�����褸�~���,���ݦA�ഫ */
         strcpy(strtmp, sformat_trade(ibirth_yy, 2, 4));
         strcat(strtmp, sformat_trade(ibirth_mm, 2, 2));
         strcat(strtmp, sformat_trade(ibirth_dd, 2, 2));
         strcat(prtstr, sformat_trade(strtmp, 4, 8));
                                            /*C167-174:�X�ͦ~��-�褸*/

         strcat(prtstr, sformat_trade(fsex, 4, 1));   /* C175-C175 */
         strcat(prtstr, sformat_trade(fmarriage, 4, 1)); /* C176 */

         if (fassured[0]=='1')
         {
            strcpy(strtmp,"1");
         }
         else if(fassured[0]=='2')
         {
            strcpy(strtmp,"3");
         }
         else if(fassured[0]=='3')
         {
            strcpy(strtmp,"2");
         }
         else if(fassured[0]=='4')
         {
            strcpy(strtmp,"9");
         }
         else if(fassured[0]=='5')
         {
            strcpy(strtmp,"8");
         }
         else if(fassured[0]=='6')
         {
            strcpy(strtmp,"9");
         }
         else
            strcpy(strtmp, " ");
         strcat(prtstr, sformat_trade(strtmp, 4, 1));     /*C177:�۵M�H/�k�H�O*/

         iTmpbuf = atoi(fcomp_class);
         strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 2));
                                                          /*C178-179:�����ż�*/
         strcat(prtstr, sformat_trade("    ", 4,4));                          /*C180-183:blank*/

         if (strcmp(iins_type, "01")==0 ||
               strcmp(iins_type, "05")==0 ||
               strcmp(iins_type, "08")==0 ||
               strcmp(iins_type, "09")==0 ||
               strcmp(iins_type, "201")==0 ||
               strcmp(iins_type, "205")==0 ||
               strcmp(iins_type, "209")==0)
         {
            ipdmg_align=ipdmg_align*(-1);

            $SELECT icode INTO $icode FROM alignment
              WHERE fclass='4' AND palign=$ipdmg_align;

            if (SQLCODE==SQLNOTFOUND) strcat(prtstr, sformat_trade("0", 4, 1));
                                              /*C184:����h�����u��*/
            else strcat(prtstr, sformat_trade(icode, 4, 1));
         } else strcat(prtstr, sformat_trade("0", 4, 1));

         if (strcmp(iins_type, "11")==0 || strcmp(trim(iins_type), "211")==0) /* fix:2025.06 */
         {
            ipbrg_align=ipbrg_align*(-1);
            $SELECT icode INTO $icode FROM alignment
              WHERE fclass='4' AND palign=$ipbrg_align;

            if (SQLCODE==SQLNOTFOUND) strcat(prtstr, sformat_trade("0", 4, 1));
                                                       /*C185:�ѵs�h�����u��*/
            else strcat(prtstr, sformat_trade(icode,4,1));
         } else strcat(prtstr, sformat_trade("0", 4, 1));

         if (strcmp(iins_type, "31")==0 || strcmp(iins_type, "32")==0 || strcmp(iins_type, "231")==0 || strcmp(iins_type, "232")==0)
         {
            iplia_align=iplia_align*(-1);

            $SELECT icode INTO $icode FROM alignment
              WHERE fclass='4' AND palign=$iplia_align;

            if (SQLCODE==SQLNOTFOUND) strcat(prtstr, sformat_trade("0", 4, 1));
                                                   /*C186:�d���h�����u��*/
            else strcat(prtstr, sformat_trade(icode, 4, 1));
         } else strcat(prtstr, sformat_trade("0", 4, 1));

         strcpy(strcol18, prtstr);                                         /* �O�d1-186(1-18��)�᭱�|�Ψ� */


         printf("Fedr_class[%s] iendorse[%s]\n",*sFedr_class,iendorse);

		 /*�������ӧ���[�I�ءA�w�h�O�I���٥i�����ǰe*/
         sprintf_s(stmt_bufb, sizeof stmt_bufb,"SELECT first 1 a.drate_ym,a.iins_type "
                           "  FROM %s:ply_ins_type a "
                           " WHERE a.ipolicy = ? "
                           "   AND NOT EXISTS (SELECT 1 "
                           "                     FROM %s:edr_ins_type "
                           "                    WHERE iins_type = a.iins_type "
                           "                      AND iendorse IN (SELECT iendorse FROM %s:edr_relation WHERE ipolicy = ?) "
                           "                      AND iedr_type = '05')  "
                           " ORDER BY 1,2 ", tmp_dbname,tmp_dbname,tmp_dbname);

         printf("stmt_bufb[%s] ipolicy=[%s]\n",stmt_bufb, ipolicy );

         $PREPARE cus_ins_cur1 from $stmt_bufb;
         $DECLARE PLY_INS_CURA1 CURSOR for cus_ins_cur1;

         $OPEN PLY_INS_CURA1 USING $ipolicy,$ipolicy;
         $FETCH PLY_INS_CURA1 INTO $drate_ym, $sIins_type;
         
         if(strncmp(sIins_type,"171",3) == 0 || strncmp(sIins_type,"172",3) == 0 || 
            strncmp(sIins_type,"173",3) == 0 || strncmp(sIins_type,"174",3) == 0 || strncmp(sIins_type,"175",3) == 0) continue;
         
         printf("drate_ym[%s] sIins_type=[%s]\n",drate_ym, sIins_type );

         $SELECT to_char(drate,'%Y%m')
            INTO $drate_yyyymm
            FROM ca_rate_date
           WHERE icode=$drate_ym
             AND itable='cover_vs_premium';

         if (*sFedr_class == '5' || *sFedr_class == '7')    /*** ��r���, ���P��� ***/
         {
                strcat(prtstr, sformat_trade("AC", 4, 2));                             /*C187-C188*/
                /* ���ʫD�O������L��r���,�p�P��, �W�ǥ��@�I��,  */
                strcat(prtstr, sformat_trade(sIins_type, 4, 6));  /*C189-194:�����I�إN�X*/

                strcat(prtstr, sformat_trade(" ", 4, 1));         /*C195-C195*/
                iTmpbuf = 0;
                /* strcat(prtstr, sformat_trade(&iTmpbuf, 1, 43));*/   /*C196-C238*/
                strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));   /*C196-C203*/
                strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));   /*C204-C211*/
                strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));   /*C212-C219*/
                strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));   /*C220-C231*/
                strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));   /*C232-C238*/
                strcat(prtstr, sformat_trade(" ", 4, 1));         /*C239-C239*/
                iTmpbuf = 0;
                strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));    /*C240-C248*/

                /* strcat(prtstr, sformat_trade(" ", 2, 17)); */       /*C249-C265�j�����*//* ���A�ǰe�j���Ҹ� mark by sylvia 101.01.06*/

                strcat(prtstr, sformat_trade(drate_yyyymm, 4, 6));     /*C266-C271�O�v��I�~��*/

                strcpy(dendorse_c, cm_cdate_str_100(dedr_begin));
                cm_split_ymd_100(dendorse_c, dply_yy, dply_mm, tmp_dd);
                yy_long = 1911 + atoi(dply_yy);
                strcpy(tmp_yyyy, itoa(yy_long));
                strcpy(strtmp, sformat_trade(tmp_yyyy, 2, 4));
                strcat(strtmp, sformat_trade(dply_mm, 2, 2));
                strcat(strtmp, sformat_trade(tmp_dd, 2, 2));
                strcat(prtstr, sformat_trade(strtmp, 4, 8));     /*C272-279:���ͮĤ�*/

                strcpy(dendorse_c, cm_cdate_str_100(dendorse));
                cm_split_ymd_100(dendorse_c, dply_yy, dply_mm, tmp_dd);
                yy_long = 1911 + atoi(dply_yy);
                strcpy(tmp_yyyy, itoa(yy_long));
                strcpy(strtmp, sformat_trade(tmp_yyyy, 2, 4));
                strcat(strtmp, sformat_trade(dply_mm, 2, 2));
                strcat(strtmp, sformat_trade(tmp_dd, 2, 2));
                strcat(prtstr, sformat_trade(strtmp, 4, 8));    /*C280-287:�����*/
                strcat(prtstr, sformat_trade("  ",5,2));        /*C288-289:�F�d�I�إN�X */

                cntrlrec++;
                fprintf(fptr, "%s\n", prtstr);
         } /* end ��� */
         else    /**** ����r��蠟�~����� ***/
         {
            /*���嶷���e�@�� AC */
            if (*sFedr_class == '9')
            {
                prtstr_9[0]='\0';
                strcpy(prtstr_9, prtstr);
                strcpy(strcol18, prtstr);
                
                strcat(prtstr_9, sformat_trade("AC", 4, 2));                             /*C187-C188:���ʽ�N��*/

                sprintf_s(stmt_bufx, sizeof stmt_bufx,"SELECT count(*) FROM %s:endorsement a, %s:ply_relation_bak b"
                                  " WHERE a.iendorse = b.iendorse and a.iendorse = ? "
                                  "   AND (a.dply_begin != b.dply_begin or a.dply_end != b.dply_end )" , tmp_dbname, tmp_dbname);

                printf("stmt_bufx[%s] ipolicy=[%s]\n",stmt_bufx, ipolicy );

                $PREPARE prepx from $stmt_bufx;
                $EXECUTE prepx INTO $iCount USING $iendorse;

                if( iCount != 0)  /* ����ͮĤ� */
                    strcat(prtstr_9, sformat_trade("      ", 4, 6));                         /*C189-C194:�����I�إN�X*/
                else /* ���ʫD�O������L��r���,�p�P��, �W�ǥ��@�I��,  */
                    strcat(prtstr_9, sformat_trade(sIins_type, 4, 6));  /*C189-194:�����I�إN�X*/

                strcat(prtstr_9, sformat_trade(" ", 4, 1));         /*C195-C195:�W��O�B+/-�O��*/
                iTmpbuf = 0;
                /* strcat(prtstr_9, sformat_trade(&iTmpbuf, 1, 43));*/   /*C196-C238*/
                strcat(prtstr_9, sformat_trade(itoa(iTmpbuf), 4, 12));   /*C196-C203*/
                strcat(prtstr_9, sformat_trade(itoa(iTmpbuf), 4, 12));   /*C204-C211*/
                strcat(prtstr_9, sformat_trade(itoa(iTmpbuf), 4, 12));   /*C212-C219*/
                strcat(prtstr_9, sformat_trade(itoa(iTmpbuf), 4, 12));   /*C220-C231*/
                strcat(prtstr_9, sformat_trade(itoa(iTmpbuf), 4, 12));   /*C232-C238*/
                strcat(prtstr_9, sformat_trade(" ", 4, 1));         /*C239-C239:�[�h�O�O+��-�O��*/
                iTmpbuf = 0;
                strcat(prtstr_9, sformat_trade(itoa(iTmpbuf), 4, 12));    /*C240-C248:�[�h�O�I�O */

                /* strcat(prtstr_9, sformat_trade(" ", 2, 17)); */       /*C249-265:�j�����*/

                strcat(prtstr_9, sformat_trade(drate_yyyymm, 4, 6));     /*C266-271:�O�v��I�~��*/

                strcpy(dendorse_c, cm_cdate_str_100(dedr_begin));
                cm_split_ymd_100(dendorse_c, dply_yy, dply_mm, tmp_dd);
                yy_long = 1911 + atoi(dply_yy);
                strcpy(tmp_yyyy, itoa(yy_long));
                strcpy(strtmp, sformat_trade(tmp_yyyy, 2, 4));
                strcat(strtmp, sformat_trade(dply_mm, 2, 2));
                strcat(strtmp, sformat_trade(tmp_dd, 2, 2));
                strcat(prtstr_9, sformat_trade(strtmp, 4, 8));        /*C272-279:���ͮĤ�*/

                strcpy(dendorse_c, cm_cdate_str_100(dendorse));
                cm_split_ymd_100(dendorse_c, dply_yy, dply_mm, tmp_dd);
                yy_long = 1911 + atoi(dply_yy);
                strcpy(tmp_yyyy, itoa(yy_long));
                strcpy(strtmp, sformat_trade(tmp_yyyy, 2, 4));
                strcat(strtmp, sformat_trade(dply_mm, 2, 2));
                strcat(strtmp, sformat_trade(tmp_dd, 2, 2));
                strcat(prtstr_9, sformat_trade(strtmp, 4, 8));     /*C280-287:�����*/
                strcat(prtstr_9, sformat_trade("  ", 5, 2));       /*C288-289:�F�d�I�إN�X */

                cntrlrec++;
                fprintf(fptr, "%s\n", prtstr_9);
            } /* end ���� */

            /* �P�_�O�_���L�� */
            /* 2:�L�� */
            /* car9602053 ���s�W���N�I�L�����O */
            if (*sFedr_class == '2' || *sFedr_class == '8')
            {
               strcpy(prtstr, strcol18);
               strcat(prtstr, sformat_trade("AB", 4, 2));                        /*C187-C188*/
               strcpy(strcol19, prtstr);

              sprintf_s(stmt1, sizeof stmt1," SELECT first 1 iendorse FROM %s:edr_relation"
                             "  WHERE ipolicy = '%s' AND iendorse NOT LIKE '%%CVP%%'"
                             "    AND dcreate > (SELECT dcreate FROM %s:edr_relation"
                             "                    WHERE iendorse = '%s' )"
                             "    ORDER BY dcreate ", tmp_dbname, ipolicy, tmp_dbname, iendorse);
              printf("stmt1[%s]\n", stmt1);
              $PREPARE prep1 from $stmt1;
              $EXECUTE prep1 INTO $iendorse_next;

              if( SQLCODE == SQLNOTFOUND)  /* �ӧ��L�U�@������,�H�̷s�O���I�ضǰeAB�ʽ� */
              {
                  strcpy( table_name, "ply_ins_type");
                  strcpy( col_name, "ipolicy");
                  strcpy( using_key, ipolicy);
              }
              else   /* �ӧ�榳�U�@������,�H����I��(�U�@������e)�ǰeAB�ʽ� */
              {
                  strcpy( table_name, "ply_ins_type_bak");
                  strcpy( col_name, "iendorse");
                  strcpy( using_key, iendorse_next);
              }

              if ( ldpolicy < date_1000901) /* ñ���< 09/01/2011�A�ǰeinsurance_type.iins_type_rule */
                   sprintf_s(stmt_buf4, sizeof stmt_buf4,"SELECT distinct case when b.iins_type_rule in ('15','16') then a.iins_type "
                                     "            when b.iins_type_rule = '23' then '21' "
                                     "            else b.iins_type_rule end, a.iins_type FROM %s:%s a, insurance_type b"
                                     " WHERE a.%s = ? "
                                     "   AND a.fedr_status NOT IN ('1', '2', '3') "
                                     "   AND a.iins_type = b.iins_type and iins_type not in ('171','172','173','174','175') ",
                                     tmp_dbname, table_name, col_name);
              else
                   sprintf_s(stmt_buf4, sizeof stmt_buf4,"SELECT iins_type, iins_type FROM %s:%s"
                                     " WHERE %s = ? "
                                     "   AND fedr_status NOT IN ('1', '2', '3') and iins_type not in ('171','172','173','174','175') ",
                                     tmp_dbname, table_name, col_name);

               printf("stmt_buf4[%s] ipolicy=[%s]\n",stmt_buf4, ipolicy );

               $PREPARE cus_ins_cur from $stmt_buf4;
               $DECLARE PLY_INS_CURA2 CURSOR for cus_ins_cur;

               $OPEN PLY_INS_CURA2 USING $using_key;

               while (1)
               {
                  $FETCH PLY_INS_CURA2 INTO $sTmpInsType, $iins_type_tmp;

                  if (SQLCODE == SQLNOTFOUND) break;

                  /* prtstr[188] = '\0'; */
                  strcpy(prtstr, strcol19);
                  strcpy(iins_type_tradevan," ");
                  if ( ldpolicy < date_1000901 ) /* ñ���< 09/01/2011�A�ǰeinsurance_type.iins_type_rule */
                  {
                      puts("ñ���<09/01/2011");
                      strcat(prtstr, sformat_trade(sTmpInsType,4,6));   /*C189-194:�����I�إN�X*/

                      $SELECT iins_type_tradevan
                         INTO $iins_type_tradevan
                         FROM insurance_type
                        WHERE iins_type = $iins_type_tmp;
                  }
                  else
                  {
                      puts("ñ���>=09/01/2011");

                      strcat(prtstr, sformat_trade(sTmpInsType, 4, 6));  /*C189-194:�����I�إN�X*/

                      $SELECT iins_type_tradevan
                         INTO $iins_type_tradevan
                         FROM insurance_type
                        WHERE iins_type = $sTmpInsType;
                  }

                  strcat(prtstr, sformat_trade(" ", 4, 1));      /*C195-195:�W��O�B+/-�O��*/
                  iTmpbuf = 0;
                  /* strcat(prtstr, sformat_trade(&iTmpbuf, 1, 43)); *//*C196-C238*/
                  strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));/*C196-C203*/
                  strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));/*C204-C211*/
                  strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));/*C212-C219*/
                  strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));/*C220-C231*/
                  strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));/*C232-C238*/
                  strcat(prtstr, sformat_trade("+", 4, 1));      /*C239-C239:�[�h�O�O+��-�O��*/
                  strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12)); /*C240-C248:�[�h�O�I�O */
                  /* strcat(prtstr, sformat_trade(" ", 4, 17));    */ /*C249-C265:�j�����*//* ���A�ǰe mark by sylvia 101.01.06 */
                  strcat(prtstr, sformat_trade(drate_yyyymm, 4, 6));  /*C266-C271:�O�v��I�~��*/

                  strcpy(dendorse_c, cm_cdate_str_100(dedr_begin));
                  cm_split_ymd_100(dendorse_c, dply_yy, dply_mm, tmp_dd);
                  yy_long = 1911 + atoi(dply_yy);
                  strcpy(tmp_yyyy, itoa(yy_long));
                  strcpy(strtmp, sformat_trade(tmp_yyyy, 2, 4));
                  strcat(strtmp, sformat_trade(dply_mm, 2, 2));
                  strcat(strtmp, sformat_trade(tmp_dd, 2, 2));
                  strcat(prtstr, sformat_trade(strtmp, 4, 8)); /*C272-279:���ͮĤ�*/

                  strcpy(dendorse_c, cm_cdate_str_100(dendorse));
                  cm_split_ymd_100(dendorse_c, dply_yy, dply_mm, tmp_dd);
                  yy_long = 1911 + atoi(dply_yy);
                  strcpy(tmp_yyyy, itoa(yy_long));
                  strcpy(strtmp, sformat_trade(tmp_yyyy, 2, 4));
                  strcat(strtmp, sformat_trade(dply_mm, 2, 2));
                  strcat(strtmp, sformat_trade(tmp_dd, 2, 2));
                  strcat(prtstr, sformat_trade(strtmp, 4, 8)); /*C280-287:�����*/
                  
                  iins_type_tradevan[2] = '\0';
                  strcat(prtstr, sformat_trade(iins_type_tradevan, 5, 2));     /*C288-289:�F�d�I�إN�X */
                  cntrlrec++;
                  fprintf(fptr, "%s\n", prtstr);

               }
               $CLOSE PLY_INS_CURA2;
               $FREE PLY_INS_CURA2;
            } /* end �L�� */

            /* car9602053 ���s�W���N�I�L�����O */
            if (*sFedr_class != '2')
            {
               $OPEN scur_edr3A USING $iendorse;
               while(1)
               {
                  $FETCH scur_edr3A
                    INTO $iedr_type, $iins_type, $medrinj_cover, $medrdea_cover,
                         $medrdmg_cover, $mdeduct, $medrins_prem, $mprem, $drate_ym;

                  printf(">>>fetch edr_ins_type,[%d] iedr_type[%s]\n",medrins_prem,iedr_type);
                  printf("iendorse[%s]  prem_total[%d]\n",iendorse, prem_total);

                  if (SQLCODE==SQLNOTFOUND)
                  {
                     $CLOSE scur_edr3A;
                     break;
                  }

                        strcpy(iins_type_rule," ");
                        strcpy(iins_type_tradevan," ");
                        $SELECT iins_type_rule, iins_type_tradevan
                           INTO $iins_type_rule, $iins_type_tradevan
                           FROM insurance_type
                          WHERE iins_type = $iins_type;
                          if (strlen(trim(iins_type_rule)) == 0)
                          {
                              strcpy(iins_type_rule,iins_type);
                          }

                        if((strcmp(fcard_class,"2")==0) && (strcmp(trim(iins_type_rule),"21")==0))
                           {  strcpy(iins_type_rule,"23    ");  }

                        prem_total += medrins_prem;

                        /* prtstr[186] = '\0'; */

                  
                  
                   strcpy(prtstr, strcol18);
                   $SELECT to_char(drate,'%Y%m')
                      INTO $drate_yyyymm
                      FROM ca_rate_date
                     WHERE icode=$drate_ym
                       AND itable='cover_vs_premium';

                  if (strcmp(iedr_type, "01") == 0 ||    /*���P*/
                      strcmp(iedr_type, "02") == 0 ||    /*���~�h�O*/
                      strcmp(iedr_type, "03") == 0 ||    /*�j��h�O*/
                      strcmp(iedr_type, "60") == 0 )     /*�h���h�O*/
                  {
                     
                     if (strcmp(iedr_type, "60") == 0)
                        strcat(prtstr , sformat_trade("02", 4, 2));     /* C187-C188 */
                     else 
                        strcat(prtstr, sformat_trade(iedr_type, 4, 2));

                      if ( ldpolicy < date_1000901) /* ñ���< 09/01/2011�A�ǰeinsurance_type.iins_type_rule */
                      {
                          puts("ñ���<09/01/2011");
                          if( strcmp( trim(iins_type_rule), "15") == 0 ||
                              strcmp( trim(iins_type_rule), "16") == 0)
                              strcat(prtstr, sformat_trade(iins_type, 4, 6));                     /*C189-194:�����I�إN�X*/
                          else
                              strcat(prtstr, sformat_trade(iins_type_rule, 4, 6));             /*C189-194:�����I�إN�X*/
                      }
                      else
                      {
                          puts("ñ���>=09/01/2011");
                          strcat(prtstr, sformat_trade(iins_type, 4, 6));                     /*C189-194:�����I�إN�X*/
                      }

                     strcat(prtstr, sformat_trade(" ", 4, 1));                                    /* C195-195:�W��O�B+/-�O�� */

                      iTmpbuf = 0;
                      strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));
                      strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));
                      strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));
                      strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));
                      strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));

                      strcat(prtstr, sformat_trade("-", 4, 1));                                /* C239-239:�[�h�O�O+��-�O�� */
                      /* rfmtlong(((-1) * medrins_prem), "&&&&&&&&&", medrins_prem_c); */
                      sprintf_s(medrins_prem_c, sizeof medrins_prem_c, "%ld", ((-1) * medrins_prem));
                      strcat(prtstr, sformat_trade(medrins_prem_c, 4, 12));                     /*C240-248:�[�h�O�O*/
                      /* strcat(prtstr, sformat_trade(" ", 2, 17));*/    /*C249-265:�j�����*//* ���A�ǰe mark by sylvia 101.01.06*/
                      strcat(prtstr, sformat_trade(drate_yyyymm, 4, 6));                       /*C266-271:�O�v��I�~�� */

                  }
	               else if (strcmp(iedr_type, "04") == 0 ||    /*�O�B�ܰ�*/
	                        strcmp(iedr_type, "40") == 0 ||    /*�O�O�ܰ�*/
	                        strcmp(iedr_type, "85") == 0 ||    /*�j��ɮt�B*/
	                        strcmp(iedr_type, "76") == 0 ||
	                        strcmp(iedr_type, "78") == 0 ||
	                        strcmp(iedr_type, "75") == 0 )     /* �s�W��2010/04/21 */
	          {
	            strcpy(prtstr, strcol18);
                             strcat(prtstr, sformat_trade("04", 4, 2)); /*C187-C188:���ʽ�N�� */

                             if ( ldpolicy < date_1000901) /* ñ���< 09/01/2011�A�ǰeinsurance_type.iins_type_rule */
                             {
                                 puts("ñ���<09/01/2011");
                                 if( strcmp( trim(iins_type_rule), "15") == 0 ||
                                     strcmp( trim(iins_type_rule), "16") == 0)
                                     strcat(prtstr, sformat_trade(iins_type, 4, 6));                     /*C189-194:�����I�إN�X*/
                                 else
                                     strcat(prtstr, sformat_trade(iins_type_rule, 4, 6));             /*C189-194:�����I�إN�X*/
                             }
                             else
                             {
                                 puts("ñ���>=09/01/2011");
                                 strcat(prtstr, sformat_trade(iins_type, 4, 6));                     /*C189-194:�����I�إN�X*/
                             }

                             if ((medrinj_cover + medrdea_cover + medrdmg_cover) >= 0) /* C195-195:�W��O�B+/-�O�� */
                                  strcat(prtstr, sformat_trade("+", 4, 1));
                             else if ((medrinj_cover + medrdea_cover + medrdmg_cover) < 0)
                                  strcat(prtstr, sformat_trade("-", 4, 1));
                             else strcat(prtstr, sformat_trade(" ", 4, 1));

                             if (medrinj_cover < 0) medrinj_cover *= -1;
                             if (medrdea_cover < 0) medrdea_cover *= -1;
                             if (medrdmg_cover < 0) medrdmg_cover *= -1;

                             /* rfmtlong(medrinj_cover, "&&&&&&&&", minjured_c); */
                             sprintf_s(minjured_c, sizeof minjured_c, "%ld",medrinj_cover);
                             strcat(prtstr, sformat_trade(minjured_c, 4, 12));  /*C196-203:��˫O�B*/
                             
                             /* rfmtlong(medrdea_cover,"&&&&&&&&",mdeath_c); */
                             sprintf_s(mdeath_c, sizeof mdeath_c, "%ld",medrdea_cover);
                             strcat(prtstr, sformat_trade(mdeath_c, 4, 12));    /*C204-211:�ݼo�O�B*/
                             
                             /* rfmtlong(medrdea_cover,"&&&&&&&&",mdeath_c); */
                             sprintf_s(mdeath_c, sizeof mdeath_c, "%ld",medrdea_cover);
                             strcat(prtstr, sformat_trade(mdeath_c, 4, 12));    /*C212-219:���`�O�B*/
                             
                             /* rfmtlong(medrdmg_cover,"&&&&&&&&&&&&",mdamage_c); */
                             sprintf_s(mdamage_c, sizeof mdamage_c, "%ld", medrdmg_cover);
                             strcat(prtstr, sformat_trade(mdamage_c, 4, 12));   /*C220-231:�O�B*/
                             strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));/*C232-238:�ۭt�B */

                             if (medrins_prem >= 0) strcat(prtstr, sformat_trade("+", 4, 1));   /*C239-239:�[�h�O�O+��-�O�� */
                             else if (medrins_prem <0) strcat(prtstr, sformat_trade("-", 4, 1));
                             else strcat(prtstr, sformat_trade(" ", 4, 1));

                             if (medrins_prem < 0) medrins_prem *= -1;
                             /* rfmtlong(medrins_prem, "&&&&&&&&&", medrins_prem_c); */
                             sprintf_s(medrins_prem_c, sizeof medrins_prem_c, "%ld", medrins_prem);
                             strcat(prtstr, sformat_trade(medrins_prem_c, 4, 12));               /*C240-248:�[�h�O�O*/
                             /* strcat(prtstr, sformat_trade(" ", 2, 17));    *//*C249-265:�j�����*//* ���A�ǰe  mark by sylvia 101.01.06 */
                             strcat(prtstr, sformat_trade(drate_yyyymm, 4, 6));     /*C266-271:�O�v��I�~��*/
                  }
	          else if (strcmp(iedr_type, "05") == 0)  /*�[�O�I��*/
	          {
	            strcpy(prtstr, strcol18);
                             strcat(prtstr, sformat_trade(iedr_type, 4, 2));                          /*C187-C188:���ʽ�N�� */

                             if ( ldpolicy < date_1000901) /* ñ���< 09/01/2011�A�ǰeinsurance_type.iins_type_rule */
                             {
                                 puts("ñ���<09/01/2011");
                                 if( strcmp( trim(iins_type_rule), "15") == 0 ||
                                     strcmp( trim(iins_type_rule), "16") == 0)
                                     strcat(prtstr, sformat_trade(iins_type, 4, 6));                     /*C189-194:�����I�إN�X*/
                                 else
                                     strcat(prtstr, sformat_trade(iins_type_rule, 4, 6));             /*C189-194:�����I�إN�X*/
                             }
                             else
                             {
                                 puts("ñ���>=09/01/2011");
                                 strcat(prtstr, sformat_trade(iins_type, 4, 6));                     /*C189-194:�����I�إN�X*/
                             }

                             strcat(prtstr, sformat_trade(" ", 4, 1));                               /* C195-195:�W��O�B+/-�O�� */
                             /* rfmtlong(medrinj_cover, "&&&&&&&&", minjured_c); */
                             sprintf_s(minjured_c, sizeof minjured_c, "%ld",medrinj_cover);
                             strcat(prtstr,sformat_trade(minjured_c, 4, 12));                         /*C196-203:��˫O�B*/
                             
                             /* rfmtlong(medrdea_cover,"&&&&&&&&",mdeath_c); */
                             sprintf_s(mdeath_c, sizeof mdeath_c, "%ld",medrdea_cover);
                             strcat(prtstr,sformat_trade(mdeath_c, 4, 12));                           /*C204-211:�ݼo�O�B*/
                             
                             /* rfmtlong(medrdea_cover,"&&&&&&&&",mdeath_c); */
                             sprintf_s(mdeath_c, sizeof mdeath_c, "%ld",medrdea_cover);
                             strcat(prtstr, sformat_trade(mdeath_c, 4, 12));                           /*C212-219:���`�O�B*/
                             
                             /* rfmtlong(medrdmg_cover,"&&&&&&&&&&&&",mdamage_c); */
                             sprintf_s(mdamage_c, sizeof mdamage_c, "%ld",medrdmg_cover);
                             strcat(prtstr, sformat_trade(mdamage_c, 4, 12));                          /*C220-231:�O�B*/
                             
                             strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));      /*C232-238:�ۭt�B */
                             
                            if (medrins_prem >= 0) strcat(prtstr, sformat_trade("+", 4, 1));         /*C239-239:�[�h�O�O+��-�O�� */
                            else if (medrins_prem <0) strcat(prtstr, sformat_trade("-", 4, 1));
                            else strcat(prtstr, sformat_trade(" ", 4, 1));
                            
                            /* rfmtlong(medrins_prem, "&&&&&&&&&", medrins_prem_c); */
                            sprintf_s(medrins_prem_c, sizeof medrins_prem_c, "%ld",medrins_prem);
                            strcat(prtstr, sformat_trade(medrins_prem_c, 4, 12));                     /*C240-248:�[�h�O�O*/

                            /* strcat(prtstr, sformat_trade(" ", 2, 17));  */    /*C249-265:�j�����*//* ���A�ǰe mark by sylvia 101.01.06 */
                            strcat(prtstr, sformat_trade(drate_yyyymm, 4, 6));                        /*C266-271:�O�v��I�~��*/
                  }
	          else if ( strcmp(iedr_type, "20") == 0 ||
	                    strcmp(iedr_type, "77") == 0 )      /*�ۭt�B�ܰ�*/
	          {
	            strcpy(prtstr, strcol18);
                            strcat(prtstr, sformat_trade("11", 4, 2));

                            if ( ldpolicy < date_1000901) /* ñ���< 09/01/2011�A�ǰeinsurance_type.iins_type_rule */
                            {
                                puts("ñ���<09/01/2011");
                                if( strcmp( trim(iins_type_rule), "15") == 0 ||
                                    strcmp( trim(iins_type_rule), "16") == 0)
                                    strcat(prtstr, sformat_trade(iins_type, 4, 6));                     /*C189-194:�����I�إN�X*/
                                else
                                    strcat(prtstr, sformat_trade(iins_type_rule, 4, 6));             /*C189-194:�����I�إN�X*/
                            }
                            else
                            {
                                puts("ñ���>=09/01/2011");
                                strcat(prtstr, sformat_trade(iins_type, 4, 6));                     /*C189-194:�����I�إN�X*/
                            }

                            strcat(prtstr, sformat_trade(" ", 4, 1));                               /* C195-195:�W��O�B+/-�O�� */
                            iTmpbuf = 0;
                            strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));     /*C196-203:��˫O�B*/
                            strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));     /*C204-211:�ݼo�O�B*/
                            strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));     /*C212-219:���`�O�B*/
                            strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));    /*C220-231:�O�B*/

                            sprintf_s(stmt_buf5, sizeof stmt_buf5,"SELECT mdeduct, mins_premium"
                                              "  FROM %s:ply_ins_type_bak"
                                              " WHERE iendorse = ? AND ipolicy = ? "
                                              "   AND iins_type = ? ; ",tmp_dbname);

                            $PREPARE CUS_PLY_BAK from $stmt_buf5;
                            $EXECUTE CUS_PLY_BAK INTO $lTmpMdeduct, $lTmpMins_premium
                               USING $iendorse, $ipolicy, $iins_type;

                            if (SQLCODE == SQLNOTFOUND) continue;

                            /* rfmtlong(lTmpMdeduct, "&&&&&&&", mdeduct_c); */
                            sprintf_s(mdeduct_c, sizeof mdeduct_c, "%ld", lTmpMdeduct);
                            strcat(prtstr, sformat_trade(mdeduct_c, 4, 12));                         /*C232-238:�ۭt�B */

                            strcat(prtstr, sformat_trade("-", 4, 1));                               /*C239-239:�[�h�O�O+��-�O�� */
                            
                            /* rfmtlong(lTmpMins_premium, "&&&&&&&&&", medrins_prem_c);*/
                            sprintf_s(medrins_prem_c, sizeof medrins_prem_c, "%ld", lTmpMins_premium);
                            strcat(prtstr, sformat_trade(medrins_prem_c, 4, 12));                    /*C240-248:�[�h�O�O*/

                            /* strcat(prtstr, sformat_trade(" ", 2, 17));*/         /*C249-265:�j�����*//* ���A�ǰe mark by sylvia 101.01.06 */

                            strcat(prtstr, sformat_trade(drate_yyyymm, 4, 6));                      /*C266-271:�O�v��I�~��*/

                            strcpy(dendorse_c, cm_cdate_str_100(dedr_begin));
                            cm_split_ymd_100(dendorse_c, dply_yy, dply_mm, tmp_dd);
                            yy_long = 1911 + atoi(dply_yy);
                            strcpy(tmp_yyyy, itoa(yy_long));
                            strcpy(strtmp, sformat_trade(tmp_yyyy, 2, 4));
                            strcat(strtmp, sformat_trade(dply_mm, 2, 2));
                            strcat(strtmp, sformat_trade(tmp_dd, 2, 2));
                            strcat(prtstr, sformat_trade(strtmp, 4, 8));  /*C264-271:���ͮĤ�*/
                            
                            strcpy(dendorse_c, cm_cdate_str_100(dendorse));
                            cm_split_ymd_100(dendorse_c, dply_yy, dply_mm, tmp_dd);
                            yy_long = 1911 + atoi(dply_yy);
                            strcpy(tmp_yyyy, itoa(yy_long));
                            strcpy(strtmp, sformat_trade(tmp_yyyy, 2, 4));
                            strcat(strtmp, sformat_trade(dply_mm, 2, 2));
                            strcat(strtmp, sformat_trade(tmp_dd, 2, 2));
                            strcat(prtstr, sformat_trade(strtmp, 4, 8)); /*C272-279:�����*/

                            iins_type_tradevan[2] = '\0';
                            strcat(prtstr, sformat_trade(iins_type_tradevan, 5, 2));     /*C288-289:�F�d�I�إN�X */
                            cntrlrec++;
                            fprintf(fptr, "%s\n", prtstr);

                            /* prtstr[186] = '\0'; */
                            strcpy(prtstr, strcol18);
                            strcat(prtstr, sformat_trade("12", 4, 2));                               /*C187-C188:���ʽ�N�� */
                     
                            if ( ldpolicy < date_1000901) /* ñ���< 09/01/2011�A�ǰeinsurance_type.iins_type_rule */
                            {
                                puts("ñ���<09/01/2011");
                                if( strcmp( trim(iins_type_rule), "15") == 0 ||
                                    strcmp( trim(iins_type_rule), "16") == 0)
                                    strcat(prtstr, sformat_trade(iins_type, 4, 6));                     /*C189-194:�����I�إN�X*/
                                else
                                    strcat(prtstr, sformat_trade(iins_type_rule, 4, 6));             /*C189-194:�����I�إN�X*/
                            }
                            else
                            {
                                puts("ñ���>=09/01/2011");
                                strcat(prtstr, sformat_trade(iins_type, 4, 6));                     /*C189-194:�����I�إN�X*/
                            }

                            strcat(prtstr, sformat_trade(" ", 4, 1));                                 /* C195-195:�W��O�B+/-�O�� */
                            iTmpbuf = 0;
                            strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));       /*C196-203:��˫O�B*/
                            strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));       /*C204-211:�ݼo�O�B*/
                            strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));       /*C212-219:���`�O�B*/
                            strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));      /*C220-231:�O�B*/
                            
                            /* rfmtlong(mdeduct, "&&&&&&&", mdeduct_c); */
                            sprintf_s(mdeduct_c, sizeof mdeduct_c, "%ld", mdeduct);
                            strcat(prtstr, sformat_trade(mdeduct_c, 4, 12));                           /*C232-238:�ۭt�B */
                            
                            strcat(prtstr, sformat_trade("+", 4, 1));                                 /*C239-239:�[�h�O�O+��-�O�� */
                            
                            lTmpMins_premium += medrins_prem;
                            /* rfmtlong(lTmpMins_premium, "&&&&&&&&&", medrins_prem_c); */
                            sprintf_s(medrins_prem_c, sizeof medrins_prem_c, "%ld", lTmpMins_premium);
                            strcat(prtstr, sformat_trade(medrins_prem_c, 4, 12));                      /*C240-248:�[�h�O�O*/
                            /* strcat(prtstr, sformat_trade(" ", 2, 17)); */ /*C249-265:�j�����*//* ���A�ǰe mark by sylvia 101.01.06 */
                            strcat(prtstr, sformat_trade(drate_yyyymm, 4, 6));                        /*C266-271:�O�v��I�~��*/

                  }
	          else if (strcmp(iedr_type, "50") == 0)  /*�_��*/
	          {strcpy(prtstr, strcol18);
                            strcat(prtstr, sformat_trade("08", 4, 2));                                /*C187-C188:���ʽ�N�� */

                            if ( ldpolicy < date_1000901) /* ñ���< 09/01/2011�A�ǰeinsurance_type.iins_type_rule */
                            {
                                puts("ñ���<09/01/2011");
                                if( strcmp( trim(iins_type_rule), "15") == 0 ||
                                    strcmp( trim(iins_type_rule), "16") == 0)
                                    strcat(prtstr, sformat_trade(iins_type, 4, 6));                     /*C189-194:�����I�إN�X*/
                                else
                                    strcat(prtstr, sformat_trade(iins_type_rule, 4, 6));             /*C189-194:�����I�إN�X*/
                            }
                            else
                            {
                                puts("ñ���>=09/01/2011");
                                strcat(prtstr, sformat_trade(iins_type, 4, 6));                     /*C189-194:�����I�إN�X*/
                            }

                            strcat(prtstr, sformat_trade(" ", 4, 1));                               /* C195-195:�W��O�B+/-�O�� */

                            iTmpbuf = 0;
                            strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));     /*C196-203:��˫O�B*/
                            strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));     /*C204-211:�ݼo�O�B*/
                            strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));     /*C212-219:���`�O�B*/
                            strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));    /*C220-231:�O�B*/
                            strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));     /*C232-238:�ۭt�B */
                            strcat(prtstr, sformat_trade("+", 4, 1));                /*C239-239:�[�h�O�O+��-�O�� */
                            /* rfmtlong(medrins_prem, "&&&&&&&&&", medrins_prem_c); */
                            sprintf_s(medrins_prem_c, sizeof medrins_prem_c, "%ld",medrins_prem);
                            strcat(prtstr, sformat_trade(medrins_prem_c,4,12));                    /*C240-248:�[�h�O�O*/
                            /* strcat(prtstr, sformat_trade(" ", 4, 17));  *//*C249-265:�j�����*/ /* ���A�ǰe mark by sylvia 101.01.06 */
                            strcat(prtstr, sformat_trade(drate_yyyymm, 4, 6));                      /*C266-271:�O�v��I�~��*/

                  }
	          else if (strcmp(iedr_type, "79") == 0) /*** ���O�� ***/
	          {strcpy(prtstr, strcol18);
                     /* �Y���O���ܰ�(79)�Ϊ̬O��L+�O���ܰ�(75),��h�W�u�eAC,�L�ݦA�e�@��99 */
                     /* 2010/04/21,�ȫO���ܰ�(79)�L�ݰe����,��75�]���|�����B�ܰ�,�ҥH
                     �N75����W���O�O�ܰʪ����ظ̧אּ�h�e�@��08 */
                     continue;
	               }
                  else if(strcmp(iedr_type, "07") == 0)  /**/
	          {strcpy(prtstr, strcol18);
                            strcat(prtstr, sformat_trade("07", 4, 2));                              /*C187-C188:���ʽ�N�� */

                            if ( ldpolicy < date_1000901) /* ñ���< 09/01/2011�A�ǰeinsurance_type.iins_type_rule */
                            {
                                puts("ñ���<09/01/2011");
                                if( strcmp( trim(iins_type_rule), "15") == 0 ||
                                    strcmp( trim(iins_type_rule), "16") == 0)
                                    strcat(prtstr, sformat_trade(iins_type, 4, 6));                     /*C189-194:�����I�إN�X*/
                                else
                                    strcat(prtstr, sformat_trade(iins_type_rule, 4, 6));             /*C189-194:�����I�إN�X*/
                            }
                            else
                            {
                                puts("ñ���>=09/01/2011");
                                strcat(prtstr, sformat_trade(iins_type, 6));                     /*C189-194:�����I�إN�X*/
                            }

                            strcat(prtstr, sformat_trade(" ", 4, 1));                               /* C195-195:�W��O�B+/-�O�� */
                            iTmpbuf = 0;
                            strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));     /*C196-203:��˫O�B*/
                            strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));     /*C204-211:�ݼo�O�B*/
                            strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));     /*C212-219:���`�O�B*/
                            strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));    /*C220-231:�O�B*/
                            strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));     /*C232-238:�ۭt�B */

                            if (medrins_prem >= 0) strcat(prtstr, sformat_trade("+", 4, 1));        /*C239-239:�[�h�O�O+��-�O�� */
                            else if (medrins_prem <0) strcat(prtstr, sformat_trade("-", 4, 1));
                            else strcat(prtstr, sformat_trade(" ", 4, 1));

                            if (medrins_prem < 0) medrins_prem *= -1;
                            /* rfmtlong(medrins_prem, "&&&&&&&&&", medrins_prem_c); */
                            sprintf_s(medrins_prem_c, sizeof medrins_prem_c, "%ld", medrins_prem);
                            strcat(prtstr, sformat_trade(medrins_prem_c, 4, 12)); /*C240-248:�[�h�O�O*/
                            /* strcat(prtstr, sformat_trade(" ", 2, 17)); *//*C249-265:�j�����*//* ���A�ǰe mark by sylvia 101.01.06 */
                            strcat(prtstr, sformat_trade(drate_yyyymm, 4, 6));                      /*C266-271:�O�v��I�~��*/

                  }

                        if ( strcmp ( iedr_type , "20" ) == 0 )
                           printf("len[%d] prtstr[%s]\n",strlen(prtstr),prtstr);

                        strcpy(dendorse_c, cm_cdate_str_100(dedr_begin));
                        cm_split_ymd_100(dendorse_c, dply_yy, dply_mm, tmp_dd);
                        yy_long = 1911 + atoi(dply_yy);
                        strcpy(tmp_yyyy, itoa(yy_long));
                        strcpy(strtmp, sformat_trade(tmp_yyyy, 2, 4));
                        strcat(strtmp, sformat_trade(dply_mm, 2, 2));
                        strcat(strtmp, sformat_trade(tmp_dd, 2, 2));
                        strcat(prtstr, sformat_trade(strtmp, 4, 8));  /*C272-279:���ͮĤ�*/
                        
                        strcpy(dendorse_c, cm_cdate_str_100(dendorse));
                        cm_split_ymd_100(dendorse_c, dply_yy, dply_mm, tmp_dd);
                        yy_long = 1911 + atoi(dply_yy);
                        strcpy(tmp_yyyy, itoa(yy_long));
                        strcpy(strtmp, sformat_trade(tmp_yyyy, 2, 4));
                        strcat(strtmp, sformat_trade(dply_mm, 2, 2));
                        strcat(strtmp, sformat_trade(tmp_dd, 2, 2));
                        strcat(prtstr, sformat_trade(strtmp, 4, 8));    /*C280-287:�����*/
                        
                        iins_type_tradevan[2] = '\0';
                        strcat(prtstr, sformat_trade(iins_type_tradevan, 5, 2));     /*C288-289:�F�d�I�إN�X */

                        cntrlrec++;
                        fprintf(fptr, "%s\n", prtstr);
               }   /* End of while which is scur_edr3A */
               $CLOSE scur_edr3A;
            }  /* �P�_�O�_���L�� */
         }  /****End of ����r��蠟�~����� ***/
      } /* end of while which is scur_car9972A */
      $CLOSE scur_car9972A;
      $FREE  scur_car9972A;

      if (cntrlrec > 0)
      {
         strcpy(prtstr,sformat_trade("CNTRLREC", 4, 8));
         /* rfmtlong(cntrlrec,"&&&&&&",cntrlrec_c); */
         sprintf_s(cntrlrec_c, sizeof cntrlrec_c, "%ld",cntrlrec);
         strcat(prtstr, sformat_trade(cntrlrec_c, 5, 6));
         fprintf(fptr, "%s\n", prtstr);
      }
      else if ( cntrlrec == 0 )
      {
         rstrdate( dbgn1 , &dendorse );

         strcpy( endorse_c , cm_cdate_str_100( dendorse ));

         cm_split_ymd_100(endorse_c,day_yy,day_mm,day_dd);

         /*printf("endorse_c[%s] day_yy[%s]\n",endorse_c,day_yy);*/

         if ( strcmp(option,"2") == 0 )
         {
            sprintf_s(Tmp1, sizeof Tmp1,"ISBH%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
            strcpy(iply_type,"bh");

            strcpy(fcard_class, "2");
         }
         else
         {
            if(online) sprintf_s(Tmp1, sizeof Tmp1,"ISBH%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
            else sprintf_s(Tmp1, sizeof Tmp1,"ISBH%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
         }

         sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);

         printf("[NODATA] file0[%s] Tmp1[%s]\n",file0,Tmp1);
         fptr=fopen(file0,"w");

         strcpy(prtstr,sformat_trade("CNTRLREC", 4, 8));
         rfmtlong(0,"&&&&&&",cntrlrec_c);
         strcat(prtstr, sformat_trade(cntrlrec_c, 5, 6));
         fprintf(fptr, "%s\n", prtstr);

         cntrlrec = prem_total = 0;
      }

      printf("### cntrlrec=[%s]\n",cntrlrec_c);

      fclose(fptr);

      rtncode = rptftpinsert( userid , "car9972" , Tmp1 );

      printf(" ******************************************* \n");

      if (strcmp(option,"4") != 0 && strcmp(option,"5") != 0)
      {printf(" ************** 2651 ******************** \n");
         $insert into ca_trade_exam
            (iply_type,dpolicy,fcard_class,itrans_type,
             qcount,mamount,minjure,mcripple,mdeath)
          values
            ($iply_type,$dendorse,$fcard_class,0,
             $cntrlrec,$prem_total,0,0,0);
         printf(" ************** 2658 ******************** \n");
      }

      sprintf_s(strlog, sizeof strlog,"���ɧ���:%s ���:%ld",file0,cntrlrec);
      printf(" **** 2662 [%s]******************** \n",strlog);
      
      WRITELOG(errfpt , strlog);

      printf(" ************** 2664 ******************** \n");
      printf("errfpt[%s]\n",strlog);
   
printf(" **************-------------------------------- ******************** \n");
   if (errfpt!=NULL) ENDLOG(errfpt);

   return M_CM_OK;

errexit:
    printf("car9972vol:sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    rc = SQLCODE;
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return rc;

}
