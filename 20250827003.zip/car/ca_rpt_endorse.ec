/* ****************************************************************************
 * Program ID: ca_rpt_endorse.ec
 *
 * Description:
 *   ���C�L, �p�G�ק怜�ڲĤT�p�����O�a�},�q��,�g���H(��Ƨ���),
 *   �{�� Block endorse_item �]�n�ק�
 *
 * Author:   Tony96, S.Y.HWANG.870609
 *
 * ****************************************************************************/
#include <malloc.h>
#include <string.h>
#include <stdio.h>

#include <api_xsrv.h>
#include "comdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "globdata.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "gls_array.h"
#include "gls_const.h"
#include "print.h"
#include "car_common.h"
#include "safeclib.h"

$include datetime.h;
$include decimal.h;
$include "ply_ins_cover.h";
$include "var_length.h";
$include "string.h";

/* *** Global variables *** */
$static char g_sIendorse[ENDORSE_NUM],g_sIpolicy[POLICY_NUM_1];
$extern char g_sFedr_class[2], g_sIedr_field[9];
$extern long g_lMedrdmg_prem, g_lMedrlia_prem;
$static long g_lMprem_total;
$static char g_sNassured[124], g_sNuser[19], g_sNbenef[43], *g_pData[128];
$static char g_sIofficer[11];
$static char *g_pEedr_item[128], g_sDendorse[11], g_kpid[12];
$static varchar g_sNcontent[256];
$static int  g_iOrder=0,g_iOutFile=0;

/*$static char g_sFile[33]; */
$char g_sFile[33];
$static int g_iMax_count, g_iPgLine;
$int ibatch_no, iins_Pg;
$char batch_no[3];
$static long lMedr_total, lMedrdmg_disc, lMedrlia_disc, lMedr_sum;
$static char g_sDedr_begin[11];

$extern char sFullDBName[40];
char companyid[COMPANY_ID];

/* *** Message block *** */
#define _M860718
/* ********************* */

char *pwformat();
#define BASE_LINE 8 /* ���ʽ�Ĥ@�� */
#define MAX_ROW 34
#define MAX_COLUMN 20                /* �̪�����     */
#define TOTAL_LINE 19                /* fmt file �X�pline number */
#define EDR_BASE_LINE TOTAL_LINE + 1 /* ���Ĥ@��     */
#define MAX_EDR_ROW 19               /* ���ʽ���   */

/* *** Function prototype *** */
long ca_rpt_endorse();
long ca401_data1();
long ca401_data2();
long ca401_data3();
long drop_temp_table();
long insert_tmp_table();
long data_report();
long car401_body_receipt();
void DecToBin();

long ca_freeform_endorse();
long ca401_data1_free();
long ca401_data2_free();
long ca401_data3_free();
char* trim_xspace();

int iedr_row; /* �@�i��檺���,��TOTAL_LINE+MAX_EDR_ROW�[�`, ���ѵ�ca409q01s.ec�ϥ� */

$char fcar_class[2], sIcar_type_ori[3];

$char sDinstall_year[4], sDinstall_month[3],sDinstall_day[3]; /*1120927002_C02 �R�q�ΰӫ~�}�o*/
$char sIsequence[31],sAinstall_zip[7],sAinstall[91];

/************************************************************************/
long ca_rpt_endorse(p_sIendorse, p_lMprem_total, p_fmask)
char *p_sIendorse;
long *p_lMprem_total;
char *p_fmask;
{
    int iRtnCode;
    $char sTmt[5000], sTmpBuf[512];

    $WHENEVER SQLERROR GOTO errexit;

    sFullDBName[0] = '\0';
    strcpy(sFullDBName, get_car_full_db(p_sIendorse));
    printf("sFullDBName[%s]\n", sFullDBName);

    printf("--------------------- p_fmask[%s]\n", p_fmask);

    /*���X�˴��X�{�����I�T���GWeak_Randomness_Biased_Random_Sample*/
    /*sprintf_s(g_sFile, sizeof g_sFile, "%d", rand(0) % 100000);*/
     
    strcpy(g_sFile, trim(p_sIendorse));
    printf("--------------------- g_sFile[%s]\n", g_sFile);

    sprintf_s(sTmt, sizeof sTmt,"DROP TABLE IF EXISTS tmp%s" ,g_sFile);            
    printf("--------------------- stmt[%s]\n", sTmt);
    $EXECUTE immediate $sTmt;  

    sprintf_s(sTmt, sizeof sTmt,
            "CREATE TEMP TABLE tmp%s "
            " (rpt_pg int, rpt_row int, rpt_col int, str char(510)) "
            " WITH NO LOG",
            g_sFile);
    printf("--------------------- stmt[%s]\n", sTmt);
    $PREPARE c_temp FROM $sTmt;
    $EXECUTE c_temp;
    $FREE c_temp;

    /**************************************************************************
    sprintf_s(sTmt, sizeof sTmt,"CREATE UNIQUE INDEX tmpx%s ON tmp%s(rpt_pg,rpt_row,rpt_col)",
                 g_sFile,g_sFile);
    printf("--------------------- stmt[%s]\n", sTmt);
    $PREPARE create_i FROM $sTmt;
    $EXECUTE create_i;
    **************************************************************************/

    sprintf_s(sTmt, sizeof sTmt, "CREATE INDEX tmpx%s ON tmp%s(rpt_pg,rpt_row,rpt_col)",
            g_sFile, g_sFile);
    printf("--------------------- stmt[%s]\n", sTmt);
    $PREPARE create_i FROM $sTmt;
    $EXECUTE create_i;
    $FREE create_i;
    printf("{ca_rpt_endorse.0010}: call ca401_data1[%s]\n", p_sIendorse);
    /* Ū�����q�N�X */
    iRtnCode = getCompanyId(companyid);
    if (iRtnCode < 0)
        return M_CM_COMPANY_ID_ERR;

    /* �C�L�O���򥻸�� */
    if ((iRtnCode = ca401_data1(p_sIendorse, p_fmask)) != M_CM_OK)
    {
        printf("{ca_rpt_endorse.0010}: rtncode[%d]", iRtnCode);
        drop_temp_table();
        return iRtnCode;
    }

    printf("{ca_rpt_endorse.0020}: call ca401_data2[%s]\n", p_sIendorse);

    /* �C�L�I�ة��Ӹ�� */
    if ((iRtnCode = ca401_data2(p_sIendorse)) != M_CM_OK)
    {
        printf("{ca_rpt_endorse.0020}: rtncode[%d]", iRtnCode);
        drop_temp_table();
        return iRtnCode;
    }

    printf("{ca_rpt_endorse.0030}: call ca401_data3[%s]\n", p_sIendorse);

    /* �C�L��Ѹ�� */
    if ((iRtnCode = ca401_data3(p_sIendorse, p_fmask)) != M_CM_OK)
    {
        printf("{ca_rpt_endorse.0030}: rtncode[%d]", iRtnCode);
        drop_temp_table();
        return iRtnCode;
    }

    *p_lMprem_total = g_lMprem_total;
    iedr_row = MAX_ROW + TOTAL_LINE + MAX_EDR_ROW;
    return M_CM_OK;

errexit:
    printf("{ca_rpt_endorse}: SQLCODE=[%d] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
} /* ca_rpt_endorse */

/* for free form*/
long ca_freeform_endorse(p_sIendorse, p_lMprem_total, p_feedr, p_fmask, p_kpid)
char *p_sIendorse;
long *p_lMprem_total;
char *p_feedr;
char *p_fmask;
char *p_kpid;
{
    int iRtnCode;
    $char sTmt[5000], sTmpBuf[512], sTmt_1[1025];
    $int iline_last;

    $WHENEVER SQLERROR GOTO errexit;

    printf("--------------------- p_feedr[%s]\n"     , p_feedr);
    printf("--------------------- p_fmask[%s]\n"     , p_fmask);
    printf("--------------------- p_kpid [%s]\n"     , p_kpid);
    printf("--------------------- p_sIendorse[%s]\n" , p_sIendorse);

    g_iOrder = 0; /* ��춶�� */

    strcpy(g_sIendorse, trim(p_sIendorse));    

    sFullDBName[0] = '\0';
    strcpy(sFullDBName, get_car_full_db(p_sIendorse));
    printf("sFullDBName[%s]\n", sFullDBName);

    /*���X�˴��X�{�����I�T���GWeak_Randomness_Biased_Random_Sample*/
    /*sprintf_s(g_sFile, sizeof g_sFile, "%d", rand(0) % 100000);*/
    strcpy(g_sFile, trim(p_sIendorse));
    
    printf("--------------------- g_sFile[%s]\n", g_sFile);

    strcpy(g_kpid , trim(p_kpid));
    /*g_iOutFile = atoi(g_sOutFile);*/
    printf("--------------------- g_kpid[%s]\n"  , g_kpid);
    /*printf("--------------------- g_iOutFile[%d]\n"  , g_iOutFile);*/

    /*------------------------------------------------------------*/

    sprintf_s(sTmt, sizeof sTmt,"DROP TABLE IF EXISTS tmp%s" ,g_sFile);            
    printf("--------------------- stmt[%s]\n", sTmt);
    $EXECUTE immediate $sTmt;   

    sprintf_s(sTmt, sizeof sTmt,
            "CREATE TEMP TABLE tmp%s \
                (kpid char(11) , inumber char(20) , iline int, ncontent VARCHAR(255)) \
                WITH NO LOG",
            g_sFile);
    printf("--------------------- stmt[%s]\n", sTmt);
    $EXECUTE immediate $sTmt;    

    sprintf_s(sTmt_1, sizeof sTmt_1, "CREATE INDEX tmpx%s ON tmp%s(kpid,inumber,iline)",
            g_sFile, g_sFile);                 
    printf("--------------------- stmt_1[%s]\n", sTmt_1);
    $EXECUTE immediate $sTmt_1;    

    /*kpid char(11) , inumber char(20) , iline int, ncontent VARCHAR(255))  */
    sprintf_s(sTmt_1, sizeof sTmt_1, "INSERT INTO tmp%s VALUES('%s', '%s', ?, ?)", 
            g_sFile, g_kpid, g_sIendorse);
    printf("--trace preInsertTmp sTmt_1 =[%s]\n",sTmt_1);            
    $PREPARE preInsertTmp FROM $sTmt_1;  

    /*------------------------------------------------------------*/

    printf("{ca_freeform_endorse.0010}: call ca401_data1_free[%s]\n", p_sIendorse);

    /* �C�L�O���򥻸�� */
    if ((iRtnCode = ca401_data1_free(p_sIendorse, p_feedr, p_fmask)) != M_CM_OK)
    {
        printf("{ca_freeform_endorse.0010}: rtncode[%d]", iRtnCode);
        drop_temp_table();
        return iRtnCode;
    }

    /*------------------------------------------------------------*/

    printf("{ca_rpt_endorse.0020}: call ca401_data2_free[%s]\n", p_sIendorse);

    /* �C�L�I�ة��Ӹ�� */
    if ((iRtnCode = ca401_data2_free(p_sIendorse)) != M_CM_OK)
    {
        printf("{ca_freeform_endorse.0020}: rtncode[%d]", iRtnCode);
        drop_temp_table();
        return iRtnCode;
    }

    /*------------------------------------------------------------*/

    printf("{ca_freeform_endorse.0030}: call ca401_data3_free[%s]\n", p_sIendorse);

    /* �C�L��Ѹ�� */
    if ((iRtnCode = ca401_data3_free(p_sIendorse, p_fmask)) != M_CM_OK)
    {
        printf("{ca_freeform_endorse.0030}: rtncode[%d]", iRtnCode);
        drop_temp_table();
        return iRtnCode;
    }

    /*------------------------------------------------------------*/

    strcpy(g_sNcontent, "QEQ");
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent; 

    strcpy(g_sNcontent, "END"); /* �@����浲�� */
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent; 

    /*------------------------------------------------------------*/        

    /* ncontent ���inull*/ 
    sprintf_s(sTmt, sizeof sTmt, "INSERT INTO ca_freeform SELECT kpid, inumber, iline, nvl(ncontent,' ') FROM tmp%s", g_sFile);
    printf("--------------------- stmt[%s]\n", sTmt);
    $EXECUTE immediate $sTmt;   

    sprintf_s(sTmt, sizeof sTmt,"DROP TABLE IF EXISTS tmp%s" ,g_sFile);            
    printf("--------------------- stmt[%s]\n", sTmt);
    $EXECUTE immediate $sTmt;  

    *p_lMprem_total = g_lMprem_total;
    /*iedr_row = MAX_ROW + TOTAL_LINE + MAX_EDR_ROW;*/

    return M_CM_OK;

errexit:
    printf("{ca_freeform_endorse}: SQLCODE=[%d] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
} 

long ca401_data1_free(p_sIendorse, p_feedr, p_fmask)
$char *p_sIendorse;
char *p_feedr;
char *p_fmask;
{
    /* ------------------------ edr_relation ----------------------------- */
    $char sIpolicy[POLICY_NUM_1], sIcard[CARD_NUM], sIrelative_ply[POLICY_NUM_1];
    $char sFedr_class[2];
    $char sFpay[2], sIpay[20], sIedr_field[9], sIofficer[16],sNleader[11];
    $char sIedr_cashier[14], sIbroker[BROKER], sDendorse[11];
    $char sDedr_begin[11], sDedr_end[11],sDply_begin[11],sDply_end[11];
    $long lMedrdmg_prem=0, lMedrlia_prem=0;
    $char sFcard_class[2], sIbranch[4], sIbranch12[3];
    $long lDedr_begin=0;
    $char cDedr_begin[11];
    /* --------------------------------------------------------------------- */

    /* ------------------------ edr_relation ----------------------------- */
    $char sDvp_code[3], sDvp_abbr[11], sIbranch_abbr[2];
    $char sNbranch[41], sNpresident[41], sNtitle[21], sIedr_examiner[11];
    /* --------------------------------------------------------------------- */

    /* -------------------------- policy_bak ------------------------------- */
    $char sNassured[ASSURED_NAME], sNbenef[43], sAassured[92],sNapplicant[ASSURED_NAME];
    $char sIassured[13], sIlicense[11];
    $char sIbirth[11], sAassured_zip[CA_ZIP], sFassured[2];
    $char sFsex[2], sFmarriage[2], sItel[21], sIissue_ym[7], sIpro_year[5],sFsex_appl[2];
    $char sIcar_type[3];
    /*$long   lQcylinder;*/
    $char sIengine[CA_ENGINE_NUM], sIbody[CA_BODY_NUM], sItag[CA_TAG_NUM], sIbrand[9];
    $double dblPdmg_align=0.0, dblPbrg_align=0.0, dblPlia_align=0.0, dblQpt=0.0;
    $char sFpt[2];
    $double dblPsex_age=0.0, dblPlia_acc=0.0, dblPdmg_acc=0.0, psex_age_damage=0.0, dblQcylinder=0.0;
    $char sNbrand_abbr[20], sNcar_abbr[20],nbrand[31];
    /* --------------------------------------------------------------------- */

    /* ------------------------- endorsement ------------------------------- */
    $char sNuser[19];
    /* --------------------------------------------------------------------- */

    /********** endorsement_note ***********
    $char note1[81], note2[81], note3[81];
    ***************************************/

    $char sYEdrBgn[4], sMEdrBgn[3], sDEdrBgn[3];
    $char sYEdrEnd[4], sMEdrEnd[3], sDEdrEnd[3];
    $char sYPlyBgn[4], sMPlyBgn[3], sDPlyBgn[3];
    $char sYPlyEnd[4], sMPlyEnd[3], sDPlyEnd[3];    
    char birthyy[4], birthmm[3], birthdd[3];
    $char sIissue_year[4], sIissue_month[3],sIissue_day[3];
    $char sTmpBuf[254], sTmpBuf1[80], sTaxName[11], sTaxArea[11];
    $int check_910401 = 0;/*, iFlagProv1 = 0, iFlagProv2 = 0, iFlagProv3 = 0;*/
    $long lDpolicy;

    int iPg, i, iRtnCode;

    /* �W�B�d���I��h�ĤT�H�d���I�O�I���B 
    $char sIedrType[7];
    $long lQday, lEdrQday;
    $char sQday[5], sEdrQday[5];
    $char sPrnDeduct[20], sEdrPrnDeduct[20];
    $char sPrn29Cover[101], sIins_type[INSURANCE_TYPE], sPrnProv[81];
    int Flag29Edr;
    int Flag29EdrType02;*/
    int x;
    $char sDrate_ym[5], sTmp[31];

    /*-------------------------------------------------*/
    $char ply_8;
    $char sIpolicy_a[21], ply1[4], ply2[11];
    /*-------------------------------------------------*/

    $char stmt_buf[8000],sTmt[1024];
    $char sYY[4], sMM[3], sDD[3];
    $char sQcylinder[10],sQpt[10];

    $WHENEVER SQLERROR GOTO errexit;    

    printf("$$$$$$$$$$$$ into ca401_data1_free()\n");
    
    /*kpid int , inumber char(20) , iline int, ncontent VARCHAR(255))  */
    sTmt[0] = '\0';
    sprintf_s(sTmt, sizeof sTmt, "INSERT INTO tmp%s VALUES('%s', '%s', ?, ?)", 
            g_sFile, g_kpid, g_sIendorse);
    printf("--trace sTmt =[%s]\n",sTmt);            
    $PREPARE preInsertTmp FROM $sTmt;      

    /* Ū�����q�N�X */
    iRtnCode = getCompanyId(companyid);
    if (iRtnCode < 0)
        return M_CM_COMPANY_ID_ERR;

    iPg = 1;

    stmt_buf[0] = '\0';
    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s %s %s %s %s FROM %s:%s %s:%s %s:%s WHERE %s %s ",
            "a.ipolicy, a.icard, a.irelative_ply, a.fedr_class, a.fpay, a.ipay,",
            "a.iedr_field, a.dedr_begin, a.dedr_end, a.iofficer, a.iedr_cashier,",
            "a.ibroker, case when a.iendorse like '%CVP%' then null when a.dendorse is null then today else a.dendorse end, ",
            "a.medrdmg_prem, a.medrlia_prem, a.fcard_class, nvl(b.nuser,' '), nvl(b.nbenef,' '), ",
            "a.medrdmg_disc, a.medrlia_disc, c.dpolicy, a.dedr_begin,a.iedr_examiner,c.dply_begin,c.dply_end ",
            sFullDBName, "edr_relation a ,",
            sFullDBName, "endorsement b, ",
            sFullDBName, "ply_relation c ",            
            " a.iendorse = b.iendorse AND a.ipolicy = c.ipolicy ",
            " AND a.iendorse = ? ");

    printf("%s\n", stmt_buf);
    $PREPARE cur_A FROM $stmt_buf;    
    $EXECUTE cur_A INTO $sIpolicy, $sIcard, $sIrelative_ply, $sFedr_class, $sFpay, $sIpay,
        $sIedr_field, $sDedr_begin, $sDedr_end, $sIofficer, $sIedr_cashier,
        $sIbroker, $sDendorse, $lMedrdmg_prem, $lMedrlia_prem, $sFcard_class, $sNuser,$sNbenef,
        $lMedrdmg_disc, $lMedrlia_disc, $lDpolicy, $lDedr_begin, $sIedr_examiner,$sDply_begin,$sDply_end
    USING $p_sIendorse;       

    /* julia */
    for (x = 0; x < 8; x++)
    {
        printf("===================print 77777777777777[%X]\n", sIedr_field[x]);
    }

    $FREE cur_A; 
    if (SQLCODE == SQLNOTFOUND)
    {    
        return M_CA_NREL_EDR;
    }
    
    strcpy(g_sIofficer, trim(sIofficer));

    check_910401 = 0;

/*
    note1[0] = '\0';
    note2[0] = '\0';
    note3[0] = '\0';

    stmt_buf[0] = '\0';

    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s WHERE %s ",
            "note1, note2, note3 ",
            sFullDBName, "endorsement_note ",
            " iendorse = ? ");
    $PREPARE cur_B FROM $stmt_buf;
    printf("%s\n", stmt_buf);
    $EXECUTE cur_B INTO $note1, $note2, $note3 USING $p_sIendorse;
    
    if (SQLCODE == SQLNOTFOUND)
    {
        note1[0] = '\0';
        note2[0] = '\0';
        note3[0] = '\0';
    }
    $FREE cur_B;
    printf("endorsement_note===> note1[%s],note2[%s],note3[%s]!!\n", note1, note2, note3);    
*/    


    printf("{ca401_data1_free.0010}:policy[%s],icard[%s],relative_ply[%s],pay[%s],officer[%s],edr_cashier[%s],broker[%s]\n", sIpolicy, sIcard, sIrelative_ply, sIpay, sIofficer, sIedr_cashier, sIbroker);

    strcpy(sIpolicy      , rtrim(sIpolicy));
    strcpy(g_sIpolicy    , rtrim(sIpolicy));
    strcpy(sIcard        , rtrim(sIcard));
    strcpy(sIrelative_ply, rtrim(sIrelative_ply));
    strcpy(sIpay         , rtrim(sIpay));
    strcpy(sIofficer     , rtrim(sIofficer));
    strcpy(sIedr_cashier , rtrim(sIedr_cashier));
    strcpy(sIbroker      , rtrim(sIbroker));
    strcpy(cDedr_begin   , cm_cdate_str_100(lDedr_begin)); 
    strcpy(g_sDedr_begin , cm_cdate_str_100(lDedr_begin)); 
    strcpy(sNuser        , rtrim(sNuser));
    strcpy(g_sNuser      , sNuser);
    strcpy(sNbenef       , rtrim(sNbenef));
    strcpy(g_sNbenef     , sNbenef);    
    
    
    printf("{ca401_data1_free.0020}: medrdmg_prem[%d],medrlia_prem[%d]\n", lMedrdmg_prem, lMedrlia_prem);

    g_lMedrdmg_prem = lMedrdmg_prem;
    g_lMedrlia_prem = lMedrlia_prem;

    printf("{ca401_data1_free.0030}: dendorse[%s],fedr_class[%s]\n", sDendorse, sFedr_class);

    strcpy(g_sDendorse  , sDendorse);
    strcpy(g_sFedr_class, sFedr_class);
    strcpy(g_sIedr_field, sIedr_field);

    g_lMprem_total = lMedrdmg_prem + lMedrlia_prem;
    lMedr_total = lMedrdmg_disc + lMedrlia_disc;
    printf("lMedr_total------>[%d]\n", lMedr_total);

    if (check_910401 == 0) /** �s�O�v�p��O�O�ɤw�������� **/
    {
        lMedr_sum = g_lMprem_total;
    }
    else
    {
        lMedr_sum = g_lMprem_total - lMedr_total;
    }

    /*1120927002_C02 �R�q�ΰӫ~�}�o*/
    printf("{ca401_data1_free.0041}:before select policy_bak\n");
    stmt_buf[0] = '\0';
    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s %s %s %s %s %s %s %s %s %s %s FROM %s:%s WHERE %s ",
            "nassured, aassured_zip, aassured, iassured,",
            "ilicense, ",
            "to_char(dbirth,'%Y')::integer - 1911 || '/' || to_char(dbirth,'%m')|| '/' || to_char(dbirth,'%d'),",
            "fsex, fassured,",
            "fmarriage, itel, qcylinder, iengine, ibody,",
            "itag, pdmg_align, pbrg_align, plia_align,",
            "qpt, fpt, psex_age, psex_age_damage, plia_acc, pdmg_acc,",
            "nbrand_abbr, ",
            "to_char(dissue,'%Y')::integer - 1911, to_char(dissue,'%m'), to_char(dissue,'%d'),napplicant,fsex_appl,",
            "nvl(to_char(dinstall,'%Y')::integer - 1911,' '), nvl(to_char(dinstall,'%m'),' '), nvl(to_char(dinstall,'%d'),' '),",
            "isequence, ainstall_zip, ainstall ",
            sFullDBName, "policy_bak ",
            " iendorse = ? ");

    printf("%s\n", stmt_buf);
    $PREPARE cur_D FROM $stmt_buf;
    $EXECUTE cur_D INTO $sNassured,$sAassured_zip, $sAassured,
        $sIassured, $sIlicense, $sIbirth, $sFsex, $sFassured,
        $sFmarriage, $sItel, $dblQcylinder, $sIengine, $sIbody,
        $sItag, $dblPdmg_align, $dblPbrg_align, $dblPlia_align,
        $dblQpt, $sFpt, $dblPsex_age, $psex_age_damage, $dblPlia_acc, $dblPdmg_acc,
        $sNbrand_abbr, $sIissue_year, $sIissue_month, $sIissue_day ,$sNapplicant,$sFsex_appl,
        $sDinstall_year, $sDinstall_month,$sDinstall_day, $sIsequence, $sAinstall_zip, $sAinstall
    USING $p_sIendorse;
    
    printf("SQLCODE[%d]\n", SQLCODE);
    if (SQLCODE == SQLNOTFOUND)
    {        
        printf("{ca401_data1_free.0041}:select policy_bak not found!!\n");
        printf("{ca401_data1_free.0041}:select original_ply !!\n");

        stmt_buf[0] = '\0';
        sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s %s %s %s %s %s %s %s %s %s %s FROM %s:%s WHERE %s ",
                " nassured, aassured_zip, aassured, iassured,",
                " ilicense, ",
                "to_char(dbirth,'%Y')::integer - 1911 || '/' || to_char(dbirth,'%m')|| '/' || to_char(dbirth,'%d'),",
                " fsex, fassured,",
                " fmarriage, itel, qcylinder, iengine, ibody,",
                " itag, pdmg_align, pbrg_align, plia_align,",
                " qpt, fpt, psex_age, psex_age_damage, plia_acc, pdmg_acc,",
                " nbrand_abbr, ",
                " to_char(dissue,'%Y')::integer - 1911 , to_char(dissue,'%m'), to_char(dissue,'%d'),napplicant,fsex_appl",
                " nvl(to_char(dinstall,'%Y')::integer - 1911,' '), nvl(to_char(dinstall,'%m'),' '), nvl(to_char(dinstall,'%d'),' ' ),",
                " isequence, ainstall_zip, ainstall ",                
                sFullDBName, "original_ply ",
                " ipolicy=(SELECT ipolicy FROM edr_relation WHERE iendorse= ? )");

        $PREPARE cur_E FROM $stmt_buf;
        printf("%s\n", stmt_buf);
        $EXECUTE cur_E INTO $sNassured,$sAassured_zip, $sAassured,
            $sIassured, $sIlicense, $sIbirth, $sFsex, $sFassured,
            $sFmarriage, $sItel, $dblQcylinder, $sIengine, $sIbody,
            $sItag, $dblPdmg_align, $dblPbrg_align, $dblPlia_align,
            $dblQpt, $sFpt, $dblPsex_age, $psex_age_damage, $dblPlia_acc, $dblPdmg_acc,
            $sNbrand_abbr, $sIissue_year, $sIissue_month, $sIissue_day ,$sNapplicant,$sFsex_appl,
            $sDinstall_year, $sDinstall_month,$sDinstall_day, $sIsequence, $sAinstall_zip, $sAinstall
        USING $p_sIendorse;
        
        if (SQLCODE == SQLNOTFOUND)
        {
            $FREE cur_E;
            return M_CA_NENDORSE;
        }
        $FREE cur_E;
    }
    $FREE cur_D;

    printf("{ca401_data1_free.0041}:before select ply_relation_bak\n");
    stmt_buf[0] = '\0';
    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s, %s:%s WHERE %s ",
            "a.ipro_year, a.ibrand, a.icar_type, min(b.drate_ym) ",
            sFullDBName, "ply_relation_bak a ",
            sFullDBName, "ply_ins_type_bak b ",
            " a.iendorse = ? AND a.iendorse = b.iendorse GROUP BY a.ipro_year, a.ibrand, a.icar_type");
    $PREPARE cur_F FROM $stmt_buf;
    printf("%s\n", stmt_buf);
    $EXECUTE cur_F INTO $sIpro_year, $sIbrand, $sIcar_type, $sDrate_ym
    USING $p_sIendorse;
    
    if (SQLCODE == SQLNOTFOUND)
    {
        printf("{ca401_data1_free.0041}:select ply_relation_bak not found!!\n");
        printf("{ca401_data1_free.0041}:select ori_ply_relation !!\n");
        stmt_buf[0] = '\0';
        sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s, %s:%s WHERE %s %s ",
                "a.ipro_year, a.ibrand, a.icar_type, min(b.drate_ym) ",
                sFullDBName, "ori_ply_relation a ",
                sFullDBName, "ori_ins_type b ",
                " a.ipolicy=(SELECT ipolicy FROM edr_relation WHERE iendorse=?)",
                " AND a.ipolicy = b.ipolicy GROUP BY a.ipro_year, a.ibrand, a.icar_type");

        $PREPARE cur_G FROM $stmt_buf;
        printf("%s\n", stmt_buf);
        $EXECUTE cur_G INTO $sIpro_year, $sIbrand, $sIcar_type, $sDrate_ym USING $p_sIendorse;        
        if (SQLCODE == SQLNOTFOUND)
        {
            $FREE cur_G;
            return M_CA_NENDORSE;
        }
        $FREE cur_G;
    }
    $FREE cur_F;
    strcpy(sIcar_type, TRANS_CAR_TYPE(sIcar_type, sDrate_ym));

    /* ��������  */
    strcpy(sNcar_abbr, " ");
    $SELECT trim(icode)|| ' ' || trim(ncode), fcar_class 
       INTO $sNcar_abbr, $fcar_class 
       FROM car_type 
      WHERE icode  = $sIcar_type 
        AND fclass = '1';
    

    /* �ӿ�H�G�޲z�H�W�� */
    strcpy(sNleader," ");
    $select nname into $sNleader
       from officer 
      where iofficer in (select ileader from officer where iofficer = $sIofficer );


    printf("{ca401_data1_free.0050}: nassured[%s],nbenef[%s],aassured_zip[%s],assured[%s],licendse[%s],birth[%s],tel[%s],issue_ym[%s],pro_year[%s],car_type[%s],iengine[%s]\n", sNassured, sNbenef, sAassured_zip, sAassured, sIlicense, sIbirth, sItel, sIissue_ym, sIpro_year, sIcar_type, sIengine);
    printf("{ca401_data1_free.0050}: ibody[%s],itag[%s],ibrand[%s],nbrand_abbr[%s],ncar_abbr[%s]\n", sIbody, sItag, sIbrand, sNbrand_abbr, sNcar_abbr);

    strcpy(sNassured , rtrim(sNassured));
    strcpy(sAassured_zip, rtrim(sAassured_zip));
    strcpy(sAassured , rtrim(sAassured));
    strcpy(sIassured , rtrim(sIassured));
    strcpy(sIlicense , rtrim(sIlicense));
    strcpy(sIbirth   , rtrim(sIbirth));
    strcpy(sItel     , rtrim(sItel));
    strcpy(sIpro_year, rtrim(sIpro_year));
    strcpy(sIcar_type, rtrim(sIcar_type));
    strcpy(sIengine  , rtrim(sIengine));
    strcpy(sIbody    , rtrim(sIbody));
    strcpy(sItag     , rtrim(sItag));
    strcpy(sIbrand   , rtrim(sIbrand));
    strcpy(sNbrand_abbr, rtrim(sNbrand_abbr));
    strcpy(sNcar_abbr, rtrim(sNcar_abbr));
    strcpy(sNapplicant,rtrim(sNapplicant));
    strcpy(sIsequence , rtrim(sIsequence));
    strcpy(sAinstall_zip, rtrim(sAinstall_zip));
    strcpy(sAinstall , rtrim(sAinstall));

    cm_split_ymd_100(cm_from_infdate_100(sDply_begin), sYPlyBgn, sMPlyBgn, sDPlyBgn); /* *** �O��ͮĩl��(�~,��,��) *** */
    cm_split_ymd_100(cm_from_infdate_100(sDply_end), sYPlyEnd, sMPlyEnd, sDPlyEnd);   /* *** �O��ͮĲ״�(�~,��,��) *** */

    cm_split_ymd_100(cm_from_infdate_100(sDedr_begin), sYEdrBgn, sMEdrBgn, sDEdrBgn); /* *** ���ͮĩl��(�~,��,��) *** */
    cm_split_ymd_100(cm_from_infdate_100(sDedr_end), sYEdrEnd, sMEdrEnd, sDEdrEnd);   /* *** ���ͮĲ״�(�~,��,��) *** */


    /*1120927002_C02 �R�q�ΰӫ~�}�o*/
    if (strncmp(sIpolicy+5,"ES",2)==0)
    {
        strcpy(sIissue_year  ,"-");
        strcpy(sIissue_month ,"-");
        strcpy(sIissue_day   ,"-");
        strcpy(sIpro_year    ,"-");
        strcpy(sItag         ,"-");
        strcpy(sIbrand       ,"-");
        strcpy(sIcar_type    ,"-");
        strcpy(sIengine      ,"-");
        strcpy(sIbody        ,"-");
        strcpy(sQpt          ,"-");
        strcpy(sQcylinder    ,"-");
        strcpy(nbrand        ,"-");    
        strcpy(sNbrand_abbr  ,"-");    
        strcpy(sNcar_abbr    ,"-");    
           
    }
    else
    {
        if (*sFpt == 'P')
        {
            sprintf_s(sQpt, sizeof sQpt, "%ld �H", (long)dblQpt);
        }
        else
        {
            sprintf_s(sQpt, sizeof sQpt, "%.1f ��", dblQpt);
        }

        sprintf_s(sQcylinder, sizeof sQcylinder, "%.2f", dblQcylinder);        

        /* �t�P�����W�� */
        /* 1121002005_C02 �u��FreeForm�����B�@�~
        strcpy(nbrand," ");    
        $SELECT nbrand
        INTO $nbrand
        FROM ca_car_model
        WHERE ibrand  = $sIbrand
            AND ipro_year = $sIpro_year
            AND (dexpire is null or dexpire > today)
            AND drate = (SELECT drate 
                            FROM ca_rate_date 
                            WHERE icode = $sDrate_ym
                            AND itable = 'ca_car_model');
        printf("[=ipro_year] SQLCODE[%d] nbrand[%s]\n",SQLCODE,nbrand);
        if (SQLCODE==SQLNOTFOUND)
        {
            $SELECT nbrand
            INTO $nbrand
            FROM ca_car_model a
            WHERE ibrand    = $sIbrand
                AND ipro_year = (SELECT MAX(ipro_year)
                                FROM ca_car_model
                                WHERE ibrand    = $sIbrand
                                    AND ipro_year < $sIpro_year 
                                    AND drate     = a.drate
                                    AND (dexpire is null or dexpire > today))
                AND (dexpire is null or dexpire > today)
                AND drate = (SELECT drate 
                            FROM ca_rate_date 
                            WHERE icode  = $sDrate_ym
                                AND itable = 'ca_car_model');
                printf("[<ipro_year] SQLCODE[%d] nbrand[%s]\n",SQLCODE,nbrand);
                            
            if (SQLCODE==SQLNOTFOUND)
            {
                $SELECT nbrand
                INTO $nbrand
                FROM ca_car_model  a
                WHERE ibrand    = $sIbrand
                    AND ipro_year = (SELECT MAX(ipro_year)
                                    FROM ca_car_model
                                    WHERE ibrand    = $sIbrand
                                        AND ipro_year > $sIpro_year
                                        AND drate     = a.drate
                                        AND (dexpire is null or dexpire > today))
                    AND (dexpire is null or dexpire > today)
                    AND drate = (SELECT drate 
                                FROM ca_rate_date 
                                WHERE icode  = $sDrate_ym
                                    AND itable = 'ca_car_model');
                printf("[>ipro_year] SQLCODE[%d] nbrand[%s]\n",SQLCODE,nbrand);
                if (SQLCODE==SQLNOTFOUND)
                {            
                    printf("--�t�ΨS���]�w���t�P�����N��?? sIbrand[%s]\n",sIbrand);
                }
            }
        }  
        */      
    }

    /****************************  �򥻰Ѽ� (�O���@��) ****************************
    �s��	�^�廡��	���廡��	   ���A                 ����	�Ƶ�
    ----------------------------------------------------------------
    H00		          �򥻰Ѽ� 			                       ����
    ----------------------------------------------------------------
            DEFINE    �榡�w�q	              �^��	  3	  H00
               WM1	  ��B���L               �Ʀr    1   0:���L�B���L �F1:�[�L�צ��u���աv�B���L                                                  
              ESTM	  �q�l�O��	               �Ʀr	  1    0�ȥ��F1:�q�l�O��                                                    
         FCARCLASS    �ۥ���~�O               �Ʀr    1   1:�ۥΡF2:��~
          FREPRINT    �ɵo�O                  �Ʀr    1    0�G�ťաF1:�ɵo
               FEB    �ߴڬ����Y�ƤΦ~�֩ʧO�Y��  �Ʀr     1   0�G���C�L�F1:�C�L
           VERSION    �O��C�L�W�h              �Ʀr     2   V1:��i�O��FV2:����O��(�t����) 
               FVW	  �O�T�I�����r            �Ʀr	1    1:��b���ƥѻ�����
              FEB2	 �q�ʦۦ樮�����r��	         �Ʀr	1 	 0:���C�L  1:�C�L
          FRECEIPT	 ���ڤw�}��	                �Ʀr	   1	0:������  1:��ܦ��ڤw�}��
     FRECE_VERSION   ���ڪ����O (113.12.01)     �Ʀr	   1	0:���C�L(��椣�C�L����); 1.���t�j��� ; 2.�j��+���N����+QRCODE
             FCARD   �O�_��ܱj���Ҹ�(113.12.01) �Ʀr	    1 	 0:���C�L  1:�C�L���D�Τ��e
            FHONOR   �L�����      (113.12.01)  �Ʀr	   1    1:�g�v��  2:�v��    
           ISERIAL    �y����                   �^��    10
            ENDCOD	  �ݥ��ˬd	                �^��    1    Q
     -------------------------------------------------------------------------------------------------
     1130319005_C02 �n���q�H�c-�j���I+���N�I���ڡGH00�s�W FRECE_VERSION�BFCARD�BFHONOR�F
                                             EDR���� DISSUE_D
    */ 
    strcpy(g_sNcontent,"H00");
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;	 /* �榡�w�q */        
    /*insert_tmp_FreeForm();*/

    strcpy(g_sNcontent,"0");
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;	 /* ��B���L */     
    /*insert_tmp_FreeForm();*/

    strcpy(g_sNcontent,p_feedr);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;	 /* �q�l�O�� */       
    /*insert_tmp_FreeForm();*/

    strcpy(g_sNcontent,"0");
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;	 /* �ۥ���~�O (���L)*/

    strcpy(g_sNcontent,"0");
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;	 /* �ɵo�O (���L)*/    

    strcpy(g_sNcontent,"0");
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;	 /* �ߴڬ����Y�ƤΦ~�֩ʧO�Y�� (���L)*/  

    strcpy(g_sNcontent,"V1");
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;	 /* �O��C�L�W�h  (���L)*/  

    strcpy(g_sNcontent,"0");
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;	 /* �O�T�I�����r (���L)*/
    /*insert_tmp_FreeForm();*/

    if (strncmp(sIpolicy+5,"EB",2)==0)
    {
        strcpy(g_sNcontent,"1");
    }else{
        strcpy(g_sNcontent,"0");
    }    
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;	 /* �q�ʦۦ樮�����r��	*/

    strcpy(g_sNcontent,"0");
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;	 /* ���ڤw�}�� */

    strcpy(g_sNcontent,"0");
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;	 /* FRECE_VERSION  (���L)*/  

    strcpy(g_sNcontent,"0");
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;	 /* FCARD  (���L)*/  

    strcpy(g_sNcontent,"0");
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;	 /* FHONOR  (���L)*/  

    strcpy(g_sNcontent,"0");
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;	 /* �y����  (���L)*/  

    strcpy(g_sNcontent,"Q");
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;	 /* �ݥ��ˬd */       
    /*insert_tmp_FreeForm();*/


    /****************************  ���϶� ****************************/
    /*
    �榡�w�q	������O	�O�渹(����)	�O�渹(�Ǹ�)	��渹(����)	��渹(�Ǹ�)
    �Q�O�H	�n�O�H	����
    �O�I�ͮĴ����_(�~)	�O�I�ͮĴ����_(��)	�O�I�ͮĴ����_(��)
    �O�I�ͮĴ�����(�~)	�O�I�ͮĴ�����(��)	�O�I�ͮĴ�����(��)
    ���ͮĴ����_(�~)	���ͮĴ����_(��)	���ͮĴ����_(��)
    ���ͮĴ�����(�~)	���ͮĴ�����(��)	���ͮĴ�����(��)
    ��l�o�Ӧ~��(�~		��l�o�Ӧ~��(��		��l�o�Ӧ~��(��	
    �s�y�~��	�P�Ӹ��X	�t�P����	�t�P�����W��	��������	�Ʈ�q	����	��������
    �X�p	�ꦬ�O�O	
    �}�ߤ��(�~		�}�ߤ��(��		�}�ߤ��(��		�ӿ�H
    �ݥ��ˬd
    */

    g_iOrder++;
    strcpy(g_sNcontent,"EDR");
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �榡�w�q */

    if (strncmp(sIpolicy+5,"ES",2)!=0)
    {
        strcpy(g_sNcontent,"�T���O�I"); 
    }
    else
    {   /*1120927002_C02 �R�q�ΰӫ~�}�o*/ 
        strcpy(g_sNcontent,"�ۥΥR�q�κ�X�O�I");   
    }
    
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* ������O */


    if (strncmp(sFcard_class, "1", 1) == 0)
    {
        /* �ثe�S���w�q�����
        sprintf_s(sTmpBuf, sizeof sTmpBuf, "�O�I�Ҹ��G%s%s", companyid, sIcard);        
        trim_tail_white(sTmpBuf);   strcpy(g_sNcontent, sTmpBuf);            
        g_iOrder++;
        $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;
        */
    }
    else
    {
        strcpy(sTmpBuf, " ");
    }

    strncpy(sIbranch, sIpolicy, 3);
    sIbranch[3] = '\0';
    strncpy(sIbranch12, sIpolicy, 2);
    sIbranch12[2] = '\0';

    /*�ӫO�a�ϥN�X�B²��*/
    strcpy(sDvp_code, " "); strcpy(sDvp_abbr, " ");
    $SELECT iupcomp, nchi_abv
       INTO $sDvp_code, $sDvp_abbr
       FROM branch 
      WHERE ibranch = $sIbranch12;

    /* *** �O��e�T�X(���) *** */
    sprintf_s(sTmpBuf, sizeof sTmpBuf, "%s%s", companyid, sIbranch);      
    strcpy(g_sNcontent, sTmpBuf);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �O�渹(����) */

    /* *** �O��(�~��,�r�y,�Ǹ�) *** */
    if (strlen(sIpolicy) >= CAR_POLICY_LEN)
    {
        strncpy(sTmpBuf, sIpolicy, CAR_POLICY_LEN);
        sTmpBuf[CAR_POLICY_LEN] = '\0';            
    }
    else
    {
        strcpy(sTmpBuf, sIpolicy);
        sTmpBuf[CAR_POLICY_LEN] = '\0';            
    }
    strcpy(g_sNcontent, sTmpBuf + 3);  trim_tail_white(g_sNcontent);  
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �O�渹(�Ǹ�) */

    /* *** ���e��X(���), �P�O����ۦP *** */
    sprintf_s(sTmpBuf, sizeof sTmpBuf, "%s%s", companyid, sIbranch);
    strcpy(g_sNcontent, sTmpBuf);   trim_tail_white(g_sNcontent);  
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* ��渹(����) */

    strcpy(g_sNcontent, p_sIendorse + 3);  trim_tail_white(g_sNcontent);       
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* ��渹(�Ǹ�) */        

    /*1121002006_C06 FreeForm�t���u��
      1. �s�W �Q�O�I�HID�B�ͤ�
      2. �ק�B�n�W�h(��ӫO��)�G�Q�O�I�HID�G�B 5~8�X ; �ͤ�G�B �~�B��F
      3. �k�H(��ӫO��)�G�Q�O�I�HID�B�ͤ� �@�ߩ�ťաC
    */
      

    /* �Ӹ�B�n */
    if (p_fmask[0] == '1')
    {
        /* �Q�O�I�H�W�� */
        sTmpBuf[0] = '\0';
        i = cc_split_chinese(sNassured, sTmpBuf, 2);        
        strcat(sTmpBuf, "****"); 
        strcpy(sNassured, sTmpBuf);
        

        /* �Q�O�I�HID�B�ͤ� */  
        sTmpBuf[0] = '\0';
        strcpy(birthyy," ");    strcpy( birthmm," ");    strcpy(birthdd," ");        
        if( *sFassured == '1' || *sFassured == '3' || *sFassured == '5' )
    	{
            /* �Q�O�I�HID */  
    		strcpy(sTmpBuf,substring(sIassured,1,4));
    	    strcat(sTmpBuf,"****");
    	    strcat(sTmpBuf,substring(sIassured,9,2));
            strcpy(sIassured, sTmpBuf);

            /* �Q�O�I�H�ͤ� */
            cm_split_ymd_100(sIbirth, birthyy, birthmm, birthdd);
            strcpy( birthyy, "***");
            strcpy( birthdd, "**");    
            
            sTmpBuf[0] = '\0';
            strcpy(sTmpBuf, trim(birthyy));
            strcat(sTmpBuf, "/");
            strcat(sTmpBuf, trim(birthmm));
            strcat(sTmpBuf, "/");
            strcat(sTmpBuf, trim(birthdd));
            strcpy(sIbirth,sTmpBuf );
        }
        else /* �k�H��G��ӫO��A�Q�O�I�HID�B�Q�O�I�H�ͤ�@�ߩ�ť� */
        {            
            strcpy(sIassured, " ");
            strcpy(sIbirth  , " ");
        }

        /* �Q�O�I�H�a�} */
        i = cc_split_chinese(sAassured, sTmpBuf, 12);
        trim_tail_white(sTmpBuf);
        strcat(sTmpBuf, "****"); 
        strcpy(sAassured, sTmpBuf);
        
        /* �n�O�H�W�� */
        i = cc_split_chinese(sNapplicant, sTmpBuf, 2);
        trim_tail_white(sTmpBuf);
        strcat(sTmpBuf, "****"); 
        strcpy(sNapplicant, sTmpBuf);        
        
    }
    else
    {
        if( *sFassured == '1' || *sFassured == '3' || *sFassured == '5' )
    	{ 

        }
        else /* �k�H��G��ӫO��A�Q�O�I�HID�B�Q�O�I�H�ͤ�@�ߩ�ť� */
        {
            strcpy(sIassured, " ");
            strcpy(sIbirth  , " ");
        }    
    }

    /*1130129008_C02 �վ�C�L���t�����ͤp�j�A�אּ�u�g�v*/ 
    /*        
    if (*sFsex == '1')
    {
        strcat(sNassured, " ����");
    }
    else if (*sFsex == '2')
    {
        strcat(sNassured, " �p�j");
    }
    */

    /*1130627010_C01 ���n�B�Q�O�H���R���u�g�v*/
    /*if(*sFsex == '1' || *sFsex == '2')
    {            
        strcat(sNassured, " �g");
    }       
    else
    {
        *insert_tmp_table(iPg, 2, 1, sNassured);*
    }*/

    /*1120629002_C01�ק���n��ܨϥΤH*/    
    if (strlen(sNuser)>0)
    {
        strcat(sNassured, " �ϥΤH�G");
        strcat(sNassured, sNuser);
    }


    /*1130129008_C02 �վ�C�L���t�����ͤp�j�A�אּ�u�g�v*/ 
    /*        
    if (*sFsex_appl == '1')
    {
        strcat(sNapplicant, " ����");
    }
    else if (*sFsex_appl == '2')
    {
        strcat(sNapplicant, " �p�j");
    }
    */

    /*1130627010_C01 ���n�B�Q�O�H���R���u�g�v*/
    /*
    if(*sFsex_appl == '1' || *sFsex_appl == '2')
    {            
        strcat(sNapplicant, " �g");
    } 
    */      


    strcpy(g_sNcontent, sNassured); trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �Q�O�H */

    /*1121002006_C06 FreeForm�t���u�ơG �s�W �Q�O�I�HID�B�ͤ� */
    strcpy(g_sNcontent, sIassured); trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �Q�O�HID */

    strcpy(g_sNcontent, sIbirth); trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �Q�O�H�ͤ� */    

    strcpy(g_sNcontent, sNapplicant);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �n�O�H */

    sprintf_s(sTmpBuf, sizeof sTmpBuf, "%s%s", sAassured_zip, sAassured);
    strcpy(g_sNcontent, sTmpBuf);  trim_tail_white(g_sNcontent);  
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* ���� */


    strcpy(g_sNcontent, sYPlyBgn);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �O�I�ͮĴ����_(�~) */

    strcpy(g_sNcontent, sMPlyBgn);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �O�I�ͮĴ����_(��) */

    strcpy(g_sNcontent, sDPlyBgn);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �O�I�ͮĴ����_(��) */


    strcpy(g_sNcontent, sYPlyEnd);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �O�I�ͮĴ�����(�~) */

    strcpy(g_sNcontent, sMPlyEnd);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �O�I�ͮĴ�����(��) */

    strcpy(g_sNcontent, sDPlyEnd);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �O�I�ͮĴ�����(��) */    


    strcpy(g_sNcontent, sYEdrBgn);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* ���ͮĴ����_(�~) */

    strcpy(g_sNcontent, sMEdrBgn);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* ���ͮĴ����_(��) */

    strcpy(g_sNcontent, sDEdrBgn);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* ���ͮĴ����_(��) */


    strcpy(g_sNcontent, sYEdrEnd);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* ���ͮĴ�����(�~) */

    strcpy(g_sNcontent, sMEdrEnd);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* ���ͮĴ�����(��) */

    strcpy(g_sNcontent, sDEdrEnd);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* ���ͮĴ�����(��) */


    strcpy(g_sNcontent, sIissue_year);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* ��l�o�Ӧ~��(�~) */
    
    strcpy(g_sNcontent, sIissue_month);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* ��l�o�Ӧ~��(��) */

    
    /* 1130319005_C02 �n���q�H�c-�j���I+���N�I���� �G����  ��l�o�Ӧ~��(��) ���
    strcpy(g_sNcontent, sIissue_day);  trim_tail_white(g_sNcontent);*/
    /*strcpy(g_sNcontent," ");
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;      /*��l�o�Ӧ~��(��) */
    

    strcpy(g_sNcontent, sIpro_year);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �s�y�~�� */

    strcpy(g_sNcontent, sItag);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �P�Ӹ��X */

    /*1121002005_C02 �u��FreeForm�����B�@�~*/
    /*
    strcpy(g_sNcontent, sNbrand_abbr);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     * �t�P���� *

    strcpy(g_sNcontent, nbrand);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     * �t�P�����W�� *
    */

    strcpy(g_sNcontent, sIbrand);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �t�P���� */    

    strcpy(g_sNcontent, sNbrand_abbr);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �t�P�����W�� */

    strcpy(g_sNcontent, sNcar_abbr);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �������� */

    /*
    sprintf_s(sTmpBuf, sizeof sTmpBuf, "%7.2f", dblQcylinder);
    strcpy(g_sNcontent, sTmpBuf);  trim_tail_white(g_sNcontent);
    */
    strcpy(g_sNcontent, sQcylinder);  trim_tail_white(g_sNcontent);    
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �Ʈ�q */

    strcpy(g_sNcontent, sIengine);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* ���� */
    
    /*
    if (*sFpt == 'P')
    {
        sprintf_s(sTmpBuf, sizeof sTmpBuf, "%ld �H", (long)dblQpt);
    }
    else
    {
        sprintf_s(sTmpBuf, sizeof sTmpBuf, "%.1f ��", dblQpt);
    }
    strcpy(g_sNcontent, sTmpBuf);  trim_tail_white(g_sNcontent);
    */    
    strcpy(g_sNcontent, sQpt);  trim_tail_white(g_sNcontent);    
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /*��������*/
    
    
    if (lMedr_sum > 0)
        strcpy(sTmpBuf1, "+");
    else if (lMedr_sum < 0)
        strcpy(sTmpBuf1, "-");
    else
        strcpy(sTmpBuf1, " ");    

    lMedr_sum = labs(lMedr_sum);
    rfmtlong(lMedr_sum, "-,---,--&", sTmpBuf);
    trim_tail_white(sTmpBuf);
    sprintf_s(g_sNcontent, sizeof g_sNcontent, "%s%s", sTmpBuf1, sTmpBuf); 
    trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /*�X�p*/

    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /*�ꦬ�O�O*/

    cm_split_ymd_100(cm_from_infdate_100(sDendorse), sYY, sMM, sDD);
    strcpy(g_sNcontent, sYY);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �}�ߤ��(�~) */

    strcpy(g_sNcontent, sMM);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �}�ߤ��(��) */  

    strcpy(g_sNcontent, sDD);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �}�ߤ��(��) */  
    
    strcpy(g_sNcontent, sDvp_abbr);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �`�����q�O (�ߩ� "�x�_") */

    strcpy(g_sNcontent, sNleader);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �ӿ�H(�޲z�H�W��) */  

    strcpy(g_sNcontent, sIofficer);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �g��N�� */

    strcpy(g_sNcontent, sIedr_examiner);  trim_tail_white(g_sNcontent);
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* ���H���N�� */         

    strcpy(g_sNcontent,"Q");
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;	 /* �ݥ��ˬd */   	




    /* *** ??? nassured, nbenef selected by policy_bak *** */
    /***
    stmt_buf[0] = '\0';
    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s WHERE %s",
            " nassured, nuser, nbenef ",
            sFullDBName, " endorsement ",
            " iendorse = ? ");
    $PREPARE cur_C FROM $stmt_buf;
    printf("%s\n", stmt_buf);
    $EXECUTE cur_C INTO $sNassured, $sNuser, $sNbenef USING $p_sIendorse;    

    if (SQLCODE == SQLNOTFOUND)
    {
        $FREE cur_C;
        return M_CA_NENDORSE;
    }
    $FREE cur_C;


    strcpy(g_sNassured, rtrim(sNassured));
    strcpy(g_sNuser, rtrim(sNuser));
    strcpy(g_sNbenef, rtrim(sNbenef));

    * *** �ʧO�~�֫Y�� *** *
    if (sFcard_class[0] == '1')
        sprintf_s(sTmpBuf, sizeof sTmpBuf, "%6.2f", dblPsex_age);
    else
        strcpy(sTmpBuf, ""); * �O�v�ۥѤƤ��L *

    insert_tmp_table(iPg, 7, 1, sTmpBuf);

    * *** �ߴڬ����Y��(�d��) *** *
    sprintf_s(sTmpBuf, sizeof sTmpBuf, "%6.2f", dblPlia_acc);


    * *** �ߴڬ����Y��(����) *** *
    sprintf_s(sTmpBuf, sizeof sTmpBuf, "%6.2f", dblPdmg_acc);


    * *** �Q�O�I�H�����Ҹ� *** *

    if (*sFassured == '1')
    {
        * 1060406006_C1 CAR401�BCAR409���C�L�Ӹ�B�n *
        * 1060907002_C1 �C�L���ɷs�W�Ӹ�B�n�ﶵ *

        printf("--------------------- p_fmask[%s]\n", p_fmask);
        if (p_fmask[0] == '1')
        {
            puts("p_fmask is 11111111111111111111111111111");
            strcpy(sTmpBuf, substring(sIlicense, 1, 3));
            strcat(sTmpBuf, "****");
            strcat(sTmpBuf, substring(sIlicense, 8, 5));
            strcpy(sIlicense, sTmpBuf);
        }
        puts("p_fmask is 00000000000000000000000000000");

        insert_tmp_table(iPg, 6, 1, sIlicense);
    }
    else
    {
        * 1060406006_C1 CAR401�BCAR409���C�L�Ӹ�B�n *
        * 1060907002_C1 �C�L���ɷs�W�Ӹ�B�n�ﶵ *
        if (p_fmask[0] == '1')
        {
            strcpy(sTmpBuf, substring(sIassured, 1, 3));
            strcat(sTmpBuf, "****");
            strcat(sTmpBuf, substring(sIassured, 8, 5));
            strcpy(sIassured, sTmpBuf);
        }

        insert_tmp_table(iPg, 6, 1, sIassured);
    }

    * 1060406006_C1 CAR401�BCAR409���C�L�Ӹ�B�n *
    * 1060907002_C1 �C�L���ɷs�W�Ӹ�B�n�ﶵ *
    if (p_fmask[0] == '1')
    {
        i = cc_split_chinese(sNassured, sTmpBuf, 2);
        strcat(sTmpBuf, "****");
        strcpy(sNassured, sTmpBuf);

        * *** �X�ͦ~��� *** *
        cm_split_ymd_100(sIbirth, birthyy, birthmm, birthdd);
        insert_tmp_table(iPg, 6, 2, "***");
        insert_tmp_table(iPg, 6, 3, "**");
        insert_tmp_table(iPg, 6, 4, "**");

        i = cc_split_chinese(sAassured, sTmpBuf, 12);
        strcat(sTmpBuf, "****");
        strcpy(sAassured, sTmpBuf);
    }
    else
    {
        * *** �X�ͦ~��� *** *
        cm_split_ymd_100(sIbirth, birthyy, birthmm, birthdd);
        insert_tmp_table(iPg, 6, 2, birthyy);
        insert_tmp_table(iPg, 6, 3, birthmm);
        insert_tmp_table(iPg, 6, 4, birthdd);
    }

    * *** �ʧO *** *
    * 1060406006_C1 CAR401�BCAR409���C�L�Ӹ�B�n *
    * 1060907002_C1 �C�L���ɷs�W�Ӹ�B�n�ﶵ *
    if (p_fmask[0] == '1')
    {
        insert_tmp_table(iPg, 6, 5, "**");
    }
    else
    {
        if (*sFsex == '1')
            insert_tmp_table(iPg, 6, 5, "�k");
        else if (*sFsex == '2')
            insert_tmp_table(iPg, 6, 5, "�k");
        else
            insert_tmp_table(iPg, 6, 5, "  ");
    }

    ***/

  
    return M_CM_OK;

errexit:
    printf("{ca401_data1_free}: SQLCODE = %d sqlerrm=%s\n", SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
} /* ca401_data1_free */

long ca401_data2_free(p_sIendorse)
$char *p_sIendorse;
{
    $int iMedrdmg_cover=0, iMedrinj_cover=0, iMedrdea_cover=0, iMdeduct=0;
    $int iPcal=0, iQserial=0, iMedrins_prem=0;
    $int iMedr_discount=0, insurance_cover_count=0;
    $long iMdeduct_l=0;
    $char iMdeduct_c[11];

    $int iMedr_prem=0, iins=0;
    $char sIcar_type[3], sDeduct[11], tmpDeduct[8], tmp1Deduct[19];
    $long tot_Medr_prem=0;
    $int ins_cnt=0, lMdeduct=0;
    int iPg_init, iPg, iTmp, jTmp, kTmp, i, hTmp;

    $char sIins_type[INSURANCE_TYPE], sIedr_type[3], sFcal_way[2], sDrate_ym[5], f1000406[2];
    $char sFprint[2], sFins_grp[2], sNins_type[29], insurance_fcal_way[2];
    $int iQcoverage, iLineCount;
    $int iLineCount_tmp=0, AddLine=0,iEdrInsCount=0;
    $char sTmpBuf[255];
    $char sFcomp_24[2];

    $int check_910401, iCount, iedr_type05, iedr_type02;
    $long lDpolicy, qday;
    $char stmt_buf[8000];
    $char provision[21], sbus_source[21], fdeduct[2],s_sign[2];
    char v_sMsg[1512];
    long rtncode=0, lPremSum=0;
    char sColumn[21], sTable[21], sDbname[21], stmp[51];
    $long mcover_limit=0;
    $char sNins_type2[36],sTmt[1024]; /* �I�إN��+�W��*/

    printf("$$$$$$$$$$$$ into ca401_data2_free()\n");

    $WHENEVER SQLERROR GOTO errexit;

    sTmt[0]='\0';  
    sprintf_s(sTmt, sizeof sTmt, "INSERT INTO tmp%s VALUES('%s', '%s', ?, ?)", 
            g_sFile, g_kpid, g_sIendorse);
    $PREPARE preInsertTmp FROM $sTmt;  


    iPg_init = 1;
    iPg = 1;
    iLineCount = 0;
    iLineCount_tmp = 0;
    tot_Medr_prem = 0;
    

    strcpy(sNins_type2, " ");
    strcpy(provision, " ");    
    /*
    strcpy(sDbname, "");
    strcpy(sTable, "edr_ins_cover");
    strcpy(sColumn, "iendorse");

    IcurrPlyInsCover = IfirstPlyInsCover = IlastPlyInsCover = NULL; * set init pointer to NULL *
#ifdef CA_CONS
    IfirstPlyInsCover = get_ply_ins_cover(sDbname, sTable, sColumn, p_sIendorse, &rtncode, v_sMsg);
    if (rtncode != M_CM_OK)
        return rtncode;
#endif
    */ 

    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT a.mcover_limit-b.mcover_limit FROM %s:endorsement a, %s:policy_bak b WHERE a.iendorse = '%s'"
                      "   AND a.iendorse = b.iendorse ",
            sFullDBName, sFullDBName, p_sIendorse);
    $PREPARE prep4 FROM $stmt_buf;
    $EXECUTE prep4 INTO $mcover_limit;
    $FREE prep4;
    printf("%s\n", stmt_buf);

    iEdrInsCount = 0;
    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT count(*) FROM %s:edr_ins_type WHERE iendorse = '%s'",sFullDBName, p_sIendorse);
    $PREPARE prep4_1 FROM $stmt_buf;
    $EXECUTE prep4_1 INTO $iEdrInsCount;
    $FREE prep4_1;
    printf("--trace iEdrInsCount=[%d]\n",iEdrInsCount);
    

    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s %s %s %s FROM %s:%s %s:%s %s:%s %s:%s WHERE %s %s %s %s %s ",
            " a.iins_type, a.iedr_type, a.medrdmg_cover, a.medrinj_cover,",
            " a.medrdea_cover, a.mdeduct, a.medrins_prem, a.medr_discount,",
            " a.fcal_way, a.pcal, a.qserial, a.drate_ym,",
            " a.medr_prem, b.icar_type, c.dpolicy, d.fcomp_24, a.provision, a.qday ",
            sFullDBName, "edr_ins_type a, ",
            sFullDBName, "edr_relation b, ",
            sFullDBName, "ply_relation c, ",
            sFullDBName, "endorsement d   ",
            "      a.iendorse = ? ",
            "  AND a.iendorse = b.iendorse ",
            "  AND b.iendorse = d.iendorse ",
            "  AND b.ipolicy  = c.ipolicy ",
            "ORDER BY qserial");

    $PREPARE x3_tmp FROM $stmt_buf;
    $DECLARE x3_f CURSOR FOR x3_tmp;
    $FREE x3_tmp;
    $OPEN x3_f USING $p_sIendorse;
    printf("%s\n", stmt_buf);
    /* lMedr_sum = 0; */
    while (1)
    {
        $FETCH x3_f INTO $sIins_type, $sIedr_type, $iMedrdmg_cover, $iMedrinj_cover,
            $iMedrdea_cover, $iMdeduct, $iMedrins_prem, $iMedr_discount,
            $sFcal_way, $iPcal, $iQserial, $sDrate_ym,
            $iMedr_prem, $sIcar_type, $lDpolicy, $sFcomp_24, $provision, $qday;

        if (SQLCODE == SQLNOTFOUND)
            break;
        strcpy(sIcar_type_ori, sIcar_type);
        strcpy(sIcar_type, TRANS_CAR_TYPE(sIcar_type, sDrate_ym));

        strcpy(sIins_type, trim(sIins_type));
        iins = atoi(sIins_type);

       printf("--trace iMedrinj_cover=[%d]\n",iMedrinj_cover); 
       printf("--trace iMedrdea_cover=[%d]\n",iMedrdea_cover); 
       printf("--trace iMedrdmg_cover=[%d]\n",iMedrdmg_cover); 

        $SELECT trim(iins_type)||' '||trim(nins_type), nins_type, fprint, fins_grp, fcal_way, fdeduct ,qcoverage
           INTO $sNins_type2, $sNins_type, $sFprint, $sFins_grp, $insurance_fcal_way, $fdeduct ,$iQcoverage
           FROM insurance_type 
          WHERE iins_type = $sIins_type;       
          
        if (strcmp(trim(sIins_type), "52") == 0)  
        {        
            if (fcar_class[0] == '1') /* �ۥ� */
            {
                 strcpy(sNins_type2, "52 ���D�d�����[����");
                 strcpy(sNins_type , "���D�d�����[����"   );
            }
            else
            {
                 strcpy(sNins_type2, "52 �T�����D�d���O�I");
                 strcpy(sNins_type , "�T�����D�d���O�I"   );
            }
        }
        else if(strcmp(trim(sIins_type), "252") == 0)  
        {        
            if (fcar_class[0] == '1') /* �ۥ� */
            {
                 strcpy(sNins_type2, "252 ���D�d�����[����");
                 strcpy(sNins_type , "���D�d�����[����"   );
            }
            else
            {
                 strcpy(sNins_type2, "252 �T�����D�d���O�I");
                 strcpy(sNins_type , "�T�����D�d���O�I"   );
            }
        }        

        printf("--trace sNins_type2=[%s]\n",sNins_type2);

/*
        $SELECT COUNT(*)
           INTO $insurance_cover_count
           FROM insurance_cover
          WHERE iins_type = $sIins_type;
*/         

/*
        if (strcmp(trim(sIins_type), "31") == 0 || strcmp(trim(sIins_type), "36") == 0 ||
            strcmp(trim(sIins_type), "77") == 0 || strcmp(trim(sIins_type), "113") == 0 ||
            strcmp(trim(sIins_type), "131") == 0 || strcmp(trim(sIins_type), "133") == 0)
        {
            iQcoverage = 2;
        }
        else if (strcmp(trim(sIins_type), "145") == 0 || strcmp(trim(sIins_type), "146") == 0)
        {
            iQcoverage = 2;
        }    
        else if (strcmp(trim(sIins_type), "32") == 0 || strcmp(trim(sIins_type), "37") == 0 ||
                    strcmp(trim(sIins_type), "78") == 0 || strcmp(trim(sIins_type), "114") == 0 ||
                    strcmp(trim(sIins_type), "132") == 0 || strcmp(trim(sIins_type), "134") == 0) 
        {
            iQcoverage = 1;
        }
        else if (strcmp(trim(sIins_type), "51") == 0 || strcmp(trim(sIins_type), "52"|| strcmp(trim(sIins_type), "55") == 0))
        {
            iQcoverage = 2;
        }
        else if (strcmp(trim(sIins_type), "57") == 0 || strcmp(trim(sIins_type), "59") == 0 || strcmp(trim(sIins_type), "60") == 0)      
        {
            iQcoverage = 3;
        }
        else if (strcmp(trim(sIins_type), "238") == 0) 
        {
            iQcoverage = 3;
        }
        else if (strcmp(trim(sIins_type), "34") == 0 || strcmp(trim(sIins_type), "87") == 0 || strcmp(trim(sIins_type), "115") == 0) 
        {            
            iQcoverage = 4;
        }
        else
        {
            iQcoverage = 1;
        }    
*/ 
        /***
        if (iLineCount_tmp >= MAX_EDR_ROW)
        {
            iLineCount = 0;
            iLineCount_tmp = 0;

            iPg++;
            printf("-----------------------> data2() iPg[%d]\n", iPg);
        }
        ***/
  

        if (iins==147 || iins==47 || iins==50 || iins==301 || iins==56 || iins==136 || iins==166 || iins==266)
        {
            iQcoverage = 1;
        }
        else if (strcmp(sIins_type, "238") == 0) 
        {
            iQcoverage = 3;
        }
        else if (strcmp(sIins_type, "237") == 0 || strcmp(sIins_type, "561") == 0) /*1130229009_C03 �s�W�N�~�ƬG�୼�O�Ϊ��[����*/
        {
            iQcoverage = 2;
        }
        
        printf("--trace iins=[%d],iQcoverage=[%d]\n",iins,iQcoverage);
         
        /*************************************  ����I�ة���  *************************************/

        /* �榡�w�q  ���ʽ�  �O�I�����W��    �O�I���B���t��  �O�I���B    �ۭt�B���t��  �ۭt�B  �O�I�O���t��  �O�I�O  �ݥ��ˬd
            
            EDRINS      05     31 �ĤT�H�ˮ`�d���I                                        0               +    101      C 
            EDRINS                �C�@�ӤH�ˮ`            +    2000000                                                  C   
            EDRINS                �C�@�ƬG�ˮ`            +    4000000                                                  C  
            EDRINS      05     32 �ĤT�H�]�l�d���I        +     100000                    0               +    401      Q (�̫�@��)             
        */

        iLineCount ++; /* �I�ؼ� (�D���) */

        printf("1.############ data2_free() iLineCount[%d] \n", iLineCount);
 
        /*-------------- �Ҧ��I�ز�1�檺�e�T����� --------------*/
        strcpy(g_sNcontent,"EDRINS");   
        g_iOrder++;
        $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;             /* �榡�w�q */

        strcpy(g_sNcontent, sIedr_type);   trim_tail_white(g_sNcontent);
        g_iOrder++;
        $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;             /* ���ʽ� */

        strcpy(g_sNcontent, sNins_type2);  trim_tail_white(g_sNcontent);              
        g_iOrder++;
        $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;             /* �I�إN��+�W�� */

        
        /*-------------- ��1�檺��L��� (�O�B�Ӽ� > 1) --------------*/
        if (iQcoverage >1)
        {        
            strcpy(g_sNcontent," ");
            g_iOrder++;
            $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;         /* �O�I���B���t�� */
            
            g_iOrder++;
            $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;         /* �O�I���B */

            /*----------------------*/
            
            strcpy(s_sign, " ");
            if (iMdeduct > 0)
            {
                strcpy(s_sign, "+");                
            }
            else if (iMdeduct < 0)
            {
                strcpy(s_sign, "-");    
            }  
            /*strcpy(g_sNcontent, s_sign);*/
            strcpy(g_sNcontent, " "); /*1121201fix�G�ۭt�B�S�� "+/-" �����Y�A�����ϥΥ���"-"���Y�i�A�B���Ƥ��Υ["+"��" */
            g_iOrder++;
            $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;        /* �ۭt�B���t�� */          
            
            /*----------------------*/
            strcpy(sTmpBuf, " "); 
            if (iMdeduct != 0)
            {
            	/* 1130510009_C20_�s�W�q�ʨ��M�ݰӫ~(131.132.331.332�ۭt�B���) */
            	if (strcmp(sIins_type, "131")== 0 || strcmp(sIins_type, "331")== 0)
            	{
            		if (iMdeduct < 0)
            		{
            			stmt_buf[0] = '\0';
            			sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s, %s:%s WHERE %s ",
                                         " a.icar_type, min(b.drate_ym) ",
                                         sFullDBName, "ply_relation_bak a ",
                                         sFullDBName, "ply_ins_type_bak b ",
                                         " a.iendorse = ? AND a.iendorse = b.iendorse GROUP BY a.icar_type ");
                                printf("%s\n", stmt_buf);
                                $PREPARE cur_J FROM $stmt_buf;
                                $EXECUTE cur_J INTO $sIcar_type, $sDrate_ym USING $p_sIendorse;
                                
                                if (SQLCODE == SQLNOTFOUND)
                                {
                                	printf("{ca401_data2_free.0041}:select ply_relation_bak not found!!\n");
                                	printf("{ca401_data2_free.0041}:select ori_ply_relation !!\n");
                                	stmt_buf[0] = '\0';
                                	sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s, %s:%s WHERE %s %s %s %s ",
                                	         " a.icar_type, min(b.drate_ym) ",
                                	         sFullDBName, "ori_ply_relation a ",
                                	         sFullDBName, "ori_ins_type b ",
                                	         " a.ipolicy=(SELECT ipolicy FROM ",
                                	         sFullDBName,
                                	         ":edr_relation WHERE iendorse=?)",
                                	         " AND a.ipolicy = b.ipolicy GROUP BY a.icar_type ");
                                	
                                	printf("%s\n", stmt_buf);
                                	$PREPARE cur_K FROM $stmt_buf;
                                	$EXECUTE cur_K INTO $sIcar_type, $sDrate_ym USING $p_sIendorse;
                                	
                                	if (SQLCODE == SQLNOTFOUND)
                                	{
                                		$FREE cur_K;
                                		return M_CA_NENDORSE;
                                	}    
                                	$FREE cur_K;
                                }
                                $FREE cur_J;
                                strcpy(sIcar_type, TRANS_CAR_TYPE(sIcar_type, sDrate_ym));
                                memset(tmp1Deduct, 0, sizeof(tmp1Deduct));
                                iMdeduct = labs(iMdeduct);
                                sprintf_s(tmpDeduct, sizeof tmpDeduct, "%d", iMdeduct);
                                
                                printf("Iins_type 131/331 Deduct ==>[%s]\n", tmpDeduct);
                                
                                $SELECT prn_deduct INTO $tmp1Deduct
                                   FROM ca_dmg_mdeduct
                                  WHERE icar_type = $sIcar_type
                                    AND ideduct = $tmpDeduct;
                                
                                strcpy(sTmpBuf, "-");
                                strcat(sTmpBuf, tmp1Deduct);	
                        }
                        else
                        {
                        	stmt_buf[0] = '\0';
                        	sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s, %s:%s WHERE %s ",
                                         " a.icar_type, min(b.drate_ym) ",
                                         sFullDBName, "ply_relation_bak a ",
                                         sFullDBName, "ply_ins_type_bak b ",
                                         " a.iendorse = ? AND a.iendorse = b.iendorse GROUP BY a.icar_type ");
                                printf("%s\n", stmt_buf);
                                $PREPARE cur_L FROM $stmt_buf;
                                $EXECUTE cur_L INTO $sIcar_type, $sDrate_ym USING $p_sIendorse;
                                
                                if (SQLCODE == SQLNOTFOUND)
                                {
                                	printf("{ca401_data2_free.0041}:select ply_relation_bak not found!!\n");
                                	printf("{ca401_data2_free.0041}:select ori_ply_relation !!\n");
                                	stmt_buf[0] = '\0';
                                	sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s, %s:%s WHERE %s %s %s %s",
                                	         " a.icar_type, min(b.drate_ym) ",
                                	         sFullDBName, "ori_ply_relation a ",
                                	         sFullDBName, "ori_ins_type b ",
                                	         " a.ipolicy=(SELECT ipolicy FROM ",
                                	         sFullDBName,
                                	         ":edr_relation WHERE iendorse=?)",
                                	         " AND a.ipolicy = b.ipolicy GROUP BY a.icar_type ");
                                	$PREPARE cur_M FROM $stmt_buf;
                                	$EXECUTE cur_M INTO $sIcar_type, $sDrate_ym USING $p_sIendorse;
                                	
                                	if (SQLCODE == SQLNOTFOUND)
                                	{
                                		$FREE cur_M;
                                		return M_CA_NENDORSE;
                                	}    
                                	$FREE cur_M;
                                }
                                $FREE cur_L;
                                strcpy(sIcar_type, TRANS_CAR_TYPE(sIcar_type, sDrate_ym));
                                
                                memset(tmp1Deduct, 0, sizeof(tmp1Deduct));
                                iMdeduct = labs(iMdeduct); /* ����� */ 
                                sprintf_s(tmpDeduct, sizeof tmpDeduct, "%d", iMdeduct);
                                
                                printf("Iins_type 131/331 Deduct ==>[%s]\n", tmpDeduct);
                                
                                $SELECT prn_deduct INTO $tmp1Deduct
                                   FROM ca_dmg_mdeduct
                                  WHERE icar_type = $sIcar_type
                                    AND ideduct = $tmpDeduct;                           
                                
                                /*strcpy(sTmpBuf, "+");*/
                                strcat(sTmpBuf, tmp1Deduct);
                        }
            	}
            	else
            	{
            		strcpy(iMdeduct_c, itoa(iMdeduct));
            		iMdeduct_l = atol(iMdeduct_c);
            		rfmtlong(iMdeduct_l, "-,---,--&", sTmpBuf); 
            		strcpy(sTmpBuf, trim(sTmpBuf)); 
            		
            		/*1120927002_C02 �R�q�ΰӫ~�}�o*/  
            		if (strcmp(sIins_type, "174")== 0||strcmp(sIins_type, "178")== 0) 
            		{
            			strcpy(sTmpBuf,trim(sTmpBuf));
            			strcat(sTmpBuf, "%");                    
            		}
            	}
            }    

            strcpy(g_sNcontent, sTmpBuf);             
            g_iOrder++;
            $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;        /* �ۭt�B */

            /*----------------------*/
            strcpy(s_sign, " ");
            if (iMedrins_prem > 0)
            {
                strcpy(s_sign, "+");
            }
            else if (iMedrins_prem < 0)
            {
                strcpy(s_sign, "-");    
            }          
            strcpy(g_sNcontent, s_sign);      
            g_iOrder++;
            $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;        /* �O�I�O���t�� */

            /*----------------------*/  
            iMedrins_prem = labs(iMedrins_prem);
            rfmtlong(iMedrins_prem, "--,---,--&", sTmpBuf);
            
            strcpy(g_sNcontent, trim(sTmpBuf));
            g_iOrder++;
            $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;        /* �O�I�O */ 

            /*----------------------*/
            strcpy(g_sNcontent,"C");
            g_iOrder++;
            $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;         /* �ݥ��ˬd */ 
            /*----------------------*/
            
            if (strcmp(sIins_type, "561")== 0)
            {
            	iQcoverage = 1;
            }
        
            /*-------------- ��2(i= 0)�B3(i= 1)�B4(i= 2)�B5(i= 3)�檺�Ҧ���� --------------*/
 
            for (i= 0; i<iQcoverage; i++)
            {
                strcpy(g_sNcontent,"EDRINS");   
                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �榡�w�q */                

                strcpy(g_sNcontent, " ");
                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* ���ʽ� */

                /*----------------------*/
                if (i==0)
                {
                    if (strcmp(sIins_type, "31")   == 0 || strcmp(sIins_type, "231")  == 0 ||
                        strcmp(sIins_type, "331")  == 0 || strcmp(sIins_type, "113")  == 0 ||
                        strcmp(sIins_type, "131")  == 0 || strcmp(sIins_type, "133")  == 0 ||
                        strcmp(sIins_type, "531")  == 0)
                    {                    
                        strcpy(g_sNcontent,"�C�@�ӤH�ˮ`");
                    }
                    else if (strcmp(sIins_type, "52")  == 0 || strcmp(sIins_type, "53")  == 0 ||
                             strcmp(sIins_type, "55")  == 0 || strcmp(sIins_type, "117") == 0 ||
                             strcmp(sIins_type, "135") == 0 || strcmp(sIins_type, "555") == 0 ||
                             strcmp(sIins_type, "252") == 0 || strcmp(sIins_type, "253") == 0 )
                    {
                        strcpy(g_sNcontent,"�C�@�ӤH�ˮ`");
                    }
                    else if (strcmp(sIins_type, "145") == 0 || strcmp(sIins_type, "146") == 0)
                    {
                        strcpy(g_sNcontent,"�C�@�ӤH��˳d��");
                    }  
                    else if (strcmp(sIins_type, "49") == 0 || strcmp(sIins_type, "57") == 0 || strcmp(sIins_type, "59") == 0 || strcmp(sIins_type, "60") == 0)
                    {
                        strcpy(g_sNcontent,"�C�@�ӤH�ˮ`");
                    }
                    else if (strcmp(sIins_type, "238")== 0 || strcmp(sIins_type, "237")== 0)
                    {
                        strcpy(g_sNcontent,"�C�@�ƬG");
                    }
                    else if (strcmp(sIins_type, "34") == 0 || strcmp(sIins_type, "115") == 0)
                    {
                        strcpy(g_sNcontent,"�C�@�H���|");
                    }    
                    else if (strcmp(sIins_type, "174")== 0 || strcmp(sIins_type, "178")== 0)  /*1120927002_C02 �R�q�ΰӫ~�}�o*/
                    {
                        strcpy(g_sNcontent,"�C�@�N�~�ƬG���d��");
                    }
                    else if (strcmp(sIins_type, "561")== 0)
                    {
                    	strcpy(g_sNcontent,"����Φ��`");
                    }
                    else
                    {                        
                        strcpy(g_sNcontent,"�C�@�ӤH�ˮ`");
                    }

                }
                else if (i==1)
                {
                    if (strcmp(sIins_type, "31")   == 0 || strcmp(sIins_type, "231") == 0 ||
                        strcmp(sIins_type, "331")  == 0 || strcmp(sIins_type, "113") == 0 ||
                        strcmp(sIins_type, "131")  == 0 || strcmp(sIins_type, "133") == 0 ||
                        strcmp(sIins_type, "531")  == 0)
                    {                      
                        strcpy(g_sNcontent,"�C�@�N�~�ƬG���ˮ`");
                    } 
                    else if (strcmp(sIins_type, "52")  == 0 || strcmp(sIins_type, "53")  == 0 ||
                             strcmp(sIins_type, "55")  == 0 || strcmp(sIins_type, "117") == 0 ||
                             strcmp(sIins_type, "135") == 0 || strcmp(sIins_type, "555") == 0 ||
                             strcmp(sIins_type, "252") == 0 || strcmp(sIins_type, "253") == 0 )
                    {
                        strcpy(g_sNcontent,"�C�@�N�~�ƬG���ˮ`");
                    } 
                    else if (strcmp(sIins_type, "145") == 0 || strcmp(sIins_type, "146") == 0)
                    {
                        strcpy(g_sNcontent,"�C�@�N�~�ƬG��˳d��");
                    }
                    else if (strcmp(sIins_type, "49") == 0 || strcmp(sIins_type, "57") == 0 || 
                             strcmp(sIins_type, "59") == 0 || strcmp(sIins_type, "60") == 0)
                    {
                        strcpy(g_sNcontent,"�C�@�ӤH���`�Υ���");
                    }
                    else if (strcmp(sIins_type, "238")== 0 || strcmp(sIins_type, "237")== 0)
                    {
                        strcpy(g_sNcontent,"�O�I����");
                    }
                    else if (strcmp(sIins_type, "34") == 0 || strcmp(sIins_type, "115") == 0)
                    {
                        strcpy(g_sNcontent,"�C�@�ƬG���|");
                    }    
                    else if (strcmp(sIins_type, "174")== 0 || strcmp(sIins_type, "178")== 0)  /*1120927002_C02 �R�q�ΰӫ~�}�o*/
                    {
                        strcpy(g_sNcontent,"�ֿn�̰����v���B");
                    }
                    else
                    { 
                        if (iQcoverage > 2)
                        {
                            strcpy(g_sNcontent,"�C�@�ӤH���`�Υ���");   
                        }
                        else
                        {
                            strcpy(g_sNcontent,"�C�@�N�~�ƬG���`�B");
                        }
                    }
                }  
                else if (i==2)
                {
                    if (strcmp(sIins_type, "49") == 0 || strcmp(sIins_type, "57") == 0 || 
                        strcmp(sIins_type, "59") == 0 || strcmp(sIins_type, "60") == 0)
                    {
                        strcpy(g_sNcontent,"�C�@�N�~�ƬG���`�B");
                    }    
                    else if (strcmp(sIins_type, "238")== 0)
                    {
                        strcpy(g_sNcontent,"��Q���{");
                    }
                    else if (strcmp(sIins_type, "34") == 0 || strcmp(sIins_type, "115") == 0)
                    {
                        strcpy(g_sNcontent,"�C�@�H���G");
                    } 
                    else
                    {
                        strcpy(g_sNcontent,"�C�@�N�~�ƬG���`�B");
                    }                        
                }       
                else if (i==3)
                {
                    if (strcmp(sIins_type, "34") == 0 || strcmp(sIins_type, "115") == 0)
                    {
                        strcpy(g_sNcontent,"�C�@�ƬG���G");
                    }
                    else
                    {
                        strcpy(g_sNcontent," ");
                    }
                }
                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /*�O�I�����W��*/
                /*----------------------*/ 

                strcpy(s_sign, " ");  
                if (i==0)  /* �O�B1 */
                {
                    if (strcmp(sIins_type, "52")  == 0 || strcmp(sIins_type, "53")  == 0 ||
                        strcmp(sIins_type, "55")  == 0 || strcmp(sIins_type, "117") == 0 ||
                        strcmp(sIins_type, "135") == 0 || strcmp(sIins_type, "555") == 0 ||
                        strcmp(sIins_type, "252") == 0 || strcmp(sIins_type, "253") == 0 )
                    {
                        if (iMedrdea_cover > 0)
                        {
                            strcpy(s_sign, "+");
                        }
                        else if (iMedrdea_cover < 0)
                        {
                            strcpy(s_sign, "-");
                        }
                    }
                    else if (strcmp(sIins_type, "561")  == 0)
                    {
                        if (iMedrdmg_cover > 0)
                        {
                            strcpy(s_sign, "+");
                        }
                        else if (iMedrdmg_cover < 0)
                        {
                            strcpy(s_sign, "-");
                        }
                    }
                    else
                    {
                        if (iMedrinj_cover > 0)
                        {
                            strcpy(s_sign, "+");
                        }
                        else if (iMedrinj_cover < 0)
                        {
                            strcpy(s_sign, "-");
                        }
                    }    

                }
                else if (i==1) /* �O�B2 */
                {
                    if (strcmp(sIins_type, "34") == 0  || strcmp(sIins_type, "87") == 0 || 
                        strcmp(sIins_type, "115") == 0 || strcmp(sIins_type, "238")== 0)
                    {
                        if (iMedrdmg_cover > 0)
                        {
                            strcpy(s_sign, "+");
                        }
                        else if (iMedrdmg_cover < 0)
                        {
                            strcpy(s_sign, "-");
                        }
                    }                
                    else
                    {   
                        if (iQcoverage>2)
                        {
                            if (iMedrdea_cover > 0)
                            {
                                strcpy(s_sign, "+");
                            }
                            else if (iMedrdea_cover < 0)
                            {
                                strcpy(s_sign, "-");
                            }
                        }
                        else
                        {
                            if (iMedrdmg_cover > 0)
                            {
                                strcpy(s_sign, "+");
                            }
                            else if (iMedrdmg_cover < 0)
                            {
                                strcpy(s_sign, "-");
                            }
                        }
                    }
                }    
                else if (i==2) /* �O�B3 */
                {
                    if (strcmp(sIins_type, "34") == 0 || strcmp(sIins_type, "87") == 0 || strcmp(sIins_type, "115") == 0)
                    {
                        if (iMedrdea_cover > 0)
                        {
                            strcpy(s_sign, "+");
                        }
                        else if (iMedrdea_cover < 0)
                        {
                            strcpy(s_sign, "-");
                        }
                    }
                    else if (strcmp(sIins_type, "238")== 0)
                    {
                        if (qday > 0) /* ��Q���{ */
                        {
                            strcpy(s_sign, "+");
                        }
                        else if (qday < 0)
                        {
                            strcpy(s_sign, "-");
                        }
                    }                    
                    else
                    {
                        if (iMedrdmg_cover > 0)
                        {
                            strcpy(s_sign, "+");
                        }
                        else if (iMedrdmg_cover < 0)
                        {
                            strcpy(s_sign, "-");
                        }
                    }
                } 
                else if (i==3) /* �O�B4 */
                {
                    if (iMedrdmg_cover > 0)
                    {
                        strcpy(s_sign, "+");
                    }
                    else if (iMedrdmg_cover < 0)
                    {
                        strcpy(s_sign, "-");
                    }
                }
                
                strcpy(g_sNcontent, s_sign); 
                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �O�I���B���t�� */
                /*----------------------*/ 

                strcpy(sTmpBuf, " "); 
                if (i==0) /* �O�B1 */
                {
                    if (strcmp(sIins_type, "52")  == 0 || strcmp(sIins_type, "53")  == 0 ||
                        strcmp(sIins_type, "55")  == 0 || strcmp(sIins_type, "117") == 0 ||
                        strcmp(sIins_type, "135") == 0 || strcmp(sIins_type, "555") == 0 ||
                        strcmp(sIins_type, "252") == 0 || strcmp(sIins_type, "253") == 0 )
                    {
                        iMedrdea_cover = labs(iMedrdea_cover);
                        rfmtlong(iMedrdea_cover, "-,---,---,--&", sTmpBuf);                        
                    }
                    else if (strcmp(sIins_type, "561")  == 0 )
                    {
                        iMedrdmg_cover = labs(iMedrdmg_cover);
                        rfmtlong(iMedrdmg_cover, "-,---,---,--&", sTmpBuf);                        
                    }
                    else
                    {
                        iMedrinj_cover = labs(iMedrinj_cover);
                        rfmtlong(iMedrinj_cover, "-,---,---,--&", sTmpBuf);
                    }

                }
                else if (i==1) /* �O�B2 */
                {
                    if (strcmp(sIins_type, "34") == 0 || strcmp(sIins_type, "87") == 0 || strcmp(sIins_type, "115") == 0)
                    {
                        iMedrinj_cover = labs(iMedrinj_cover)*2;
                        rfmtlong(iMedrinj_cover, "-,---,---,--&", sTmpBuf);
                    }
                    else if (strcmp(sIins_type, "238")== 0)
                    {
                        iMedrdmg_cover = labs(iMedrdmg_cover);
                        rfmtlong(iMedrdmg_cover, "-,---,---,--&", sTmpBuf);
                    }
                    else
                    {
                        if (iQcoverage>2)
                        {
                            iMedrdea_cover = labs(iMedrdea_cover);
                            rfmtlong(iMedrdea_cover, "-,---,---,--&", sTmpBuf);                            
                        }
                        else
                        {
                            iMedrdmg_cover = labs(iMedrdmg_cover);
                            rfmtlong(iMedrdmg_cover, "-,---,---,--&", sTmpBuf);
                        }    
                    }
                }
                else if (i==2) /* �O�B3 */
                {  
                    if (strcmp(sIins_type, "34") == 0 || strcmp(sIins_type, "87") == 0 || strcmp(sIins_type, "115") == 0)
                    {
                        iMedrdea_cover = labs(iMedrdea_cover);
                        rfmtlong(iMedrdea_cover, "-,---,---,--&", sTmpBuf);                        
                    }
                    else if (strcmp(sIins_type, "238")== 0)
                    {
                        qday = labs(qday);
                        if (qday == 899 || qday == 999)
                        {
                            strcpy(sTmpBuf, "  ��������");
                        }
                        else
                        {
                            rfmtlong(qday, "---,--&", sTmpBuf);
                            strcat(sTmpBuf, "����");
                        }                        
                    }
                    else
                    {
                        iMedrdmg_cover = labs(iMedrdmg_cover);
                        rfmtlong(iMedrdmg_cover, "-,---,---,--&", sTmpBuf);
                    }                        
                }
                else if (i==3) /* �O�B4 */
                {      
                    iMedrdmg_cover = labs(iMedrdmg_cover);
                    rfmtlong(iMedrdmg_cover, "-,---,---,--&", sTmpBuf);                       
                }                         
                strcpy(g_sNcontent, trim(sTmpBuf));
                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �O�I���B */
                /*----------------------*/ 

                strcpy(g_sNcontent, " ");  
                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �ۭt�B���t�� */

                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �ۭt�B */

                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �O�I�O���t�� */

                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �O�I�O */ 

                
                if ((iLineCount == iEdrInsCount) && (i==(iQcoverage-1)))
                {
                    strcpy(g_sNcontent,"Q"); 
                }
                else
                {
                    strcpy(g_sNcontent,"C");
                }            
                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �ݥ��ˬd */ 
                /*----------------------*/ 
            }
        }
        else /*-------------- ��1�檺��L���  (�O�B�Ӽ� <= 1) --------------*/
        {
            strcpy(s_sign, " ");
            
            if (strcmp(sIins_type, "562") == 0)
            {
            	if (iMedrinj_cover > 0)
            	{
            		strcpy(s_sign, "+");
            	}
            	else if (iMedrinj_cover < 0)
            	{
            		strcpy(s_sign, "-");
            	}                        
            }
            else
            {
            	if (iMedrdmg_cover > 0)
            	{
            		strcpy(s_sign, "+");
            	}
            	else if (iMedrdmg_cover < 0)
            	{
            		strcpy(s_sign, "-");
            	}
            }         
            strcpy(g_sNcontent, s_sign);     
            g_iOrder++;
            $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;         /* �O�I���B���t�� */

            /*----------------------*/ 
            
            strcpy(sTmpBuf, " ");
            if (strcmp(sIins_type, "562") == 0)
            {
            	iMedrinj_cover = labs(iMedrinj_cover);
            	rfmtlong(iMedrinj_cover, "-,---,---,--&", sTmpBuf);
            }
            else
            {
            	iMedrdmg_cover = labs(iMedrdmg_cover);
            	rfmtlong(iMedrdmg_cover, "-,---,---,--&", sTmpBuf);
            }
            strcpy(g_sNcontent, trim(sTmpBuf));
            g_iOrder++;
            $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;         /* �O�I���B */
            
            /*strcpy(sTmpBuf, " "); 
            iMedrdmg_cover = labs(iMedrdmg_cover);
            rfmtlong(iMedrdmg_cover, "-,---,---,--&", sTmpBuf);
            strcpy(g_sNcontent, trim(sTmpBuf));
            g_iOrder++;
            $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;  */       /* �O�I���B */

            /*----------------------*/
                       
            strcpy(sTmpBuf, " "); strcpy(s_sign, " ");
            if (iMdeduct != 0 && fdeduct[0] != '0')
            {
                if (strcmp(sIins_type, "01")  == 0 || strcmp(sIins_type, "05")  == 0 ||
                    strcmp(sIins_type, "201") == 0 || strcmp(sIins_type, "205") == 0 ||
                    strcmp(sIins_type, "86")  == 0 || strcmp(sIins_type, "23")  == 0 || strcmp(sIins_type, "110") == 0 ||
                    strcmp(sIins_type, "132") == 0 || strcmp(sIins_type, "332") == 0 )
                {
                    if (iMdeduct < 0)
                    {
                        stmt_buf[0] = '\0';
                        sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s, %s:%s WHERE %s ",
                                " a.icar_type, min(b.drate_ym) ",
                                sFullDBName, "ply_relation_bak a ",
                                sFullDBName, "ply_ins_type_bak b ",
                                " a.iendorse = ? AND a.iendorse = b.iendorse GROUP BY a.icar_type ");
                        printf("%s\n", stmt_buf);
                        $PREPARE cur_J FROM $stmt_buf;
                        $EXECUTE cur_J INTO $sIcar_type, $sDrate_ym USING $p_sIendorse;
                        
                        if (SQLCODE == SQLNOTFOUND)
                        {
                            printf("{ca401_data2_free.0041}:select ply_relation_bak not found!!\n");
                            printf("{ca401_data2_free.0041}:select ori_ply_relation !!\n");
                            stmt_buf[0] = '\0';
                            sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s, %s:%s WHERE %s %s %s %s ",
                                    " a.icar_type, min(b.drate_ym) ",
                                    sFullDBName, "ori_ply_relation a ",
                                    sFullDBName, "ori_ins_type b ",
                                    " a.ipolicy=(SELECT ipolicy FROM ",
                                    sFullDBName,
                                    ":edr_relation WHERE iendorse=?)",
                                    " AND a.ipolicy = b.ipolicy GROUP BY a.icar_type ");

                            printf("%s\n", stmt_buf);
                            $PREPARE cur_K FROM $stmt_buf;
                            $EXECUTE cur_K INTO $sIcar_type, $sDrate_ym USING $p_sIendorse;
                            
                            if (SQLCODE == SQLNOTFOUND)
                            {
                                $FREE cur_K;
                                return M_CA_NENDORSE;
                            }    
                            $FREE cur_K;
                        }
                        $FREE cur_J;
                        strcpy(sIcar_type, TRANS_CAR_TYPE(sIcar_type, sDrate_ym));
                        memset(tmp1Deduct, 0, sizeof(tmp1Deduct));
                        iMdeduct = labs(iMdeduct);
                        sprintf_s(tmpDeduct, sizeof tmpDeduct, "%d", iMdeduct);

                        printf("Iins_type 01/05/08 Deduct ==>[%s]\n", tmpDeduct);

                        $SELECT prn_deduct INTO $tmp1Deduct
                           FROM ca_dmg_mdeduct
                          WHERE icar_type = $sIcar_type
                            AND ideduct = $tmpDeduct;
                        if (strcmp(tmpDeduct, "8") == 0)
                            strcpy(sDeduct, tmp1Deduct);
                        else
                        {
                            strcpy(s_sign, "-");
                            strcpy(sDeduct, tmp1Deduct);
                            /*
                            strcpy(sDeduct, "-");
                            strcat(sDeduct, tmp1Deduct);
                            */
                            
                        }
                    }
                    else
                    {
                        stmt_buf[0] = '\0';
                        sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s, %s:%s WHERE %s ",
                                " a.icar_type, min(b.drate_ym) ",
                                sFullDBName, "ply_relation_bak a ",
                                sFullDBName, "ply_ins_type_bak b ",
                                " a.iendorse = ? AND a.iendorse = b.iendorse GROUP BY a.icar_type ");
                        printf("%s\n", stmt_buf);
                        $PREPARE cur_L FROM $stmt_buf;
                        $EXECUTE cur_L INTO $sIcar_type, $sDrate_ym USING $p_sIendorse;
                        
                        if (SQLCODE == SQLNOTFOUND)
                        {
                            printf("{ca401_data2_free.0041}:select ply_relation_bak not found!!\n");
                            printf("{ca401_data2_free.0041}:select ori_ply_relation !!\n");
                            stmt_buf[0] = '\0';
                            sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s, %s:%s WHERE %s %s %s %s",
                                    " a.icar_type, min(b.drate_ym) ",
                                    sFullDBName, "ori_ply_relation a ",
                                    sFullDBName, "ori_ins_type b ",
                                    " a.ipolicy=(SELECT ipolicy FROM ",
                                    sFullDBName,
                                    ":edr_relation WHERE iendorse=?)",
                                    " AND a.ipolicy = b.ipolicy GROUP BY a.icar_type ");
                            $PREPARE cur_M FROM $stmt_buf;
                            $EXECUTE cur_M INTO $sIcar_type, $sDrate_ym USING $p_sIendorse;
                            
                            if (SQLCODE == SQLNOTFOUND)
                            {
                                $FREE cur_M;
                                return M_CA_NENDORSE;
                            }    
                            $FREE cur_M;
                        }
                        $FREE cur_L;
                        strcpy(sIcar_type, TRANS_CAR_TYPE(sIcar_type, sDrate_ym));

                        memset(tmp1Deduct, 0, sizeof(tmp1Deduct));
                        iMdeduct = labs(iMdeduct);
                        sprintf_s(tmpDeduct, sizeof tmpDeduct, "%d", iMdeduct);

                        printf("Iins_type 01/05/08 Deduct ==>[%s]\n", tmpDeduct);
                        
                        $SELECT prn_deduct INTO $tmp1Deduct
                           FROM ca_dmg_mdeduct
                          WHERE icar_type = $sIcar_type
                            AND ideduct = $tmpDeduct;
                                                        
                        if (strcmp(tmpDeduct, "8") == 0)
                            strcpy(sDeduct, tmp1Deduct);
                        else
                        {
                            strcpy(s_sign, "+");
                            strcpy(sDeduct, tmp1Deduct);
                            /*                            
                            strcpy(sDeduct, "+");
                            strcat(sDeduct, tmp1Deduct);
                            */
                        }
                    }
 
                    strcpy(sTmpBuf,sDeduct);                    
                }
                else
                {  
                    if (strcmp(sIins_type, "31")  == 0 || strcmp(sIins_type, "32")  == 0 ||
                        strcmp(sIins_type, "149") == 0 || strcmp(sIins_type, "113") == 0 ||
                        strcmp(sIins_type, "71")  == 0 || strcmp(sIins_type, "72")  == 0 ||
                        strcmp(sIins_type, "231") == 0 || strcmp(sIins_type, "232") == 0 ||
                        strcmp(sIins_type, "249") == 0 || strcmp(sIins_type, "531") == 0 ||
                        strcmp(sIins_type, "532") == 0)
                    {
                        if (iMdeduct < 0)
                        {
                            strcpy(s_sign, "-");
                        }else{
                            strcpy(s_sign, "+"); 
                        }

                    }
                    strcpy(iMdeduct_c, itoa(iMdeduct));          /**** peter 03.23.1999 ****/
                    iMdeduct_l = atol(iMdeduct_c);               /**** peter 03.23.1999 ****/
                    rfmtlong(iMdeduct_l, "--,---,--&", sTmpBuf); /**** peter 03.23.1999 ****/

                    
                    if (strcmp(sIins_type, "11")  == 0 || strcmp(sIins_type, "129") == 0 || 
                        strcmp(sIins_type, "211") == 0 || strcmp(sIins_type, "176") == 0 || strcmp(sIins_type, "177") == 0 )
                    {                        
                        strcat(sTmpBuf, "%");
                        
                    }
                }
            }    
              
            /*strcpy(g_sNcontent, s_sign);*/ 
            strcpy(g_sNcontent, " "); /*1121201fix�G�ۭt�B�S�� "+/-" �����Y�A�����ϥΥ���"-"���Y�i�A�B���Ƥ��Υ["+"��" */
            g_iOrder++;
            $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;         /* �ۭt�B���t�� */

            strcpy(g_sNcontent, trim(sTmpBuf));
            g_iOrder++;
            $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;         /* �ۭt�B */

            /*----------------------*/
            strcpy(s_sign, " ");
            if (iMedrins_prem > 0)
            {
                strcpy(s_sign, "+");
            }
            else if (iMedrins_prem < 0)
            {
                strcpy(s_sign, "-");
            }          
            strcpy(g_sNcontent, s_sign);          
            g_iOrder++;
            $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;         /* �O�I�O���t�� */

            /*----------------------*/  
            iMedrins_prem = labs(iMedrins_prem);
            rfmtlong(iMedrins_prem, "--,---,--&", sTmpBuf);
            strcpy(g_sNcontent, trim(sTmpBuf));
            g_iOrder++;
            $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;         /* �O�I�O */ 

            /*----------------------*/
            if (iLineCount == iEdrInsCount) 
            {
                strcpy(g_sNcontent,"Q"); 
            }
            else
            {
                strcpy(g_sNcontent,"C");
            }            
            g_iOrder++; 
            $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;         /* �ݥ��ˬd */ 
            /*----------------------*/

        } 

        if (IsProvExist("D", provision) == TRUE)
        {
                strcpy(g_sNcontent,"EDRINS");   
                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �榡�w�q */                

                strcpy(g_sNcontent, " ");
                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* ���ʽ� */            

                strcpy(g_sNcontent,"      ���w�r�p�H");
                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /*�O�I�����W��*/

                strcpy(g_sNcontent, " ");  
                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �O�I���B���t�� */

                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �O�I���B */                                

                strcpy(g_sNcontent, " ");  
                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �ۭt�B���t�� */

                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �ۭt�B */

                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �O�I�O���t�� */

                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �O�I�O */ 
                
                if (iLineCount == iEdrInsCount)
                {
                    strcpy(g_sNcontent,"Q"); 
                }
                else
                {
                    strcpy(g_sNcontent,"C");
                }            
                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �ݥ��ˬd */ 
        }

        if (IsProvExist("H", provision) == TRUE)
        {
                strcpy(g_sNcontent,"EDRINS");   
                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �榡�w�q */                

                strcpy(g_sNcontent, " ");
                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* ���ʽ� */            

                strcpy(g_sNcontent,"      �Ұ���O��");
                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /*�O�I�����W��*/

                strcpy(g_sNcontent, " ");  
                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �O�I���B���t�� */

                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �O�I���B */                                

                strcpy(g_sNcontent, " ");  
                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �ۭt�B���t�� */

                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �ۭt�B */

                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �O�I�O���t�� */

                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �O�I�O */ 
                
                if (iLineCount == iEdrInsCount)
                {
                    strcpy(g_sNcontent,"Q"); 
                }
                else
                {
                    strcpy(g_sNcontent,"C");
                }            
                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;     /* �ݥ��ˬd */ 
        }  

    }
    $CLOSE x3_f;
    $FREE x3_f;


    return M_CM_OK;

errexit:
    printf("{ca401_data2_free}: SQLCODE=[%d] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
} /* ca401_data2_free */

/**************************************************************************
 * Function: ca401_data3_free
 *
 * Description:
 *   �C�L��Ѹ��.
 *
 **************************************************************************/
long ca401_data3_free(p_sIendorse, p_fmask)
$char *p_sIendorse, *p_fmask;
{
    /* *** �����ܧ󪺰򥻸��, ���I�ة��� *** */
    $struct _icode
    {
        char icode[3];                  /* endorsement_code.icode */
        char iins_type[INSURANCE_TYPE]; /* ins_type */
        char fins_grp[2];               /* fins_grp */
        int fclass;                     /* 1: �I�ا��, 2: �򥻸�Ƨ�� */
    }
    recEdrChg[60];

    int idx = 0, i, j, iDeflag;
    char *psFieldStatus; /* �C�@�ܰʸ�Ƭ����b g_sIedr_field's bit */
    $int iQserial, iQcoverage;
    $char sIedr_type[3], sIins_type[INSURANCE_TYPE], sFins_grp[2], sFclass[2];
    short flag_02, flag_03, flag_05;
    $char sIedr_item[3];
    $long lQserial,iline_last,iCount;
    $char sEedr_item[69], sNtable[31], sNcolumn[31], sFdatatype[2];
    $char sTmt[5000], sTmpBuf[512];
    $char sTmpDate[11], sYY[4], sMM[3], sDD[3];
    $char sTmpData[512], sFcal_way[2], sTmpBuf1[512], sTmpBuf2[512], sStr[512];
    $int iTmp, iLine, lMdeduct;
    $long lMedrinj_cover, lMedrdea_cover, lMedrdmg_cover, lMedrins_prem;
    $long lMinjured_cover, lMdeath_cover, lMdamage_cover, lMins_premium;
    $long lTot_prem, lEdrItemCount;
    $char sIcar_type[3], ipolicy[21];
    char *s;
    $char sDrate_ym[5];

    int iPg_init, iPg;

    $char sDeduct[11], tmpDeduct[8], tmp1Deduct[19], tmpIins_type[INSURANCE_TYPE];

    $char stmt_buf[8000];
    $int  flag_dinstall=0,flag_isequence=0,flag_ainstall_zip=0,flag_ainstall=0;
    $char strDinstall[11],strIsequence[31],strAinstall_zip[7],strAinstall[91];

    $WHENEVER SQLERROR GOTO errexit;

    printf("$$$$$$$$$$$$ into ca401_data3_free() g_sFedr_class[%s];\n", g_sFedr_class);

    sTmt[0]='\0';  
    sprintf_s(sTmt, sizeof sTmt, "INSERT INTO tmp%s VALUES('%s', '%s', ?, ?)", 
            g_sFile, g_kpid, g_sIendorse);
    $PREPARE preInsertTmp FROM $sTmt;  

    /*1120927002_C02 �R�q�ΰӫ~�}�o*/
    /* �R�q�ά�������b"��Ѱ�" */ 
    if (strncmp(g_sIpolicy+5,"ES",2)==0)
    {        
        /*���Ъ����w�˦~��G���� xxx�~ xx��*/
        strcpy(g_sNcontent, "EDRNOTE");
        g_iOrder++;
        $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent; 

        sprintf_s(sTmpBuf, sizeof sTmpBuf,"���Ъ����w�˦~��G����%s�~%s��",sDinstall_year,sDinstall_month);
        strcpy(g_sNcontent,trim_xspace(sTmpBuf));
        g_iOrder++;
        $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;

        strcpy(g_sNcontent, "C");
        g_iOrder++;
        $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;  

        /*���~�Ǹ��G*/
        strcpy(g_sNcontent, "EDRNOTE");
        g_iOrder++;
        $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent; 

        sprintf_s(sTmpBuf, sizeof sTmpBuf,"���~�Ǹ��G%s",sIsequence);
        strcpy(g_sNcontent,trim_xspace(sTmpBuf));
        g_iOrder++;
        $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;

        strcpy(g_sNcontent, "C");
        g_iOrder++;
        $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;  

        /*�w�˦a�}�G*/
        strcpy(g_sNcontent, "EDRNOTE");
        g_iOrder++;
        $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent; 

        sprintf_s(sTmpBuf, sizeof sTmpBuf,"�w�˦a�}�G%s%s",sAinstall_zip, sAinstall);
        strcpy(g_sNcontent,trim_xspace(sTmpBuf));
        g_iOrder++;
        $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;        

        strcpy(g_sNcontent, "C");
        g_iOrder++;
        $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;  

        strcpy(g_sNcontent, "EDRNOTE");
        g_iOrder++;
        $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent; 

        strcpy(sTmpBuf," ");
        strcpy(g_sNcontent,sTmpBuf);
        g_iOrder++;
        $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;        

        strcpy(g_sNcontent, "C");
        g_iOrder++;
        $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;  

        /* check �R�q�ΥD�ɬ������O�_����� */
        sprintf_s(stmt_buf, sizeof stmt_buf, 
               "SELECT  "
               "     CASE when a.dinstall     <> b.dinstall  THEN 1 ELSE 0 END AS flag_dinstall, nvl(to_char(a.dinstall,'%%Y')::integer - 1911||to_char(a.dinstall,'%%m'),' '), \n"
               "     CASE when a.isequence    <> b.isequence THEN 1 ELSE 0 END AS flag_isequence, a.isequence, \n"
               "     CASE when a.ainstall_zip <> b.ainstall_zip THEN 1 ELSE 0 END AS flag_ainstall_zip, a.ainstall_zip, \n"
               "     CASE when a.ainstall     <> b.ainstall  THEN 1 ELSE 0 END AS flag_ainstall,  a.ainstall \n"
               "  FROM %s:endorsement a, %s:policy_bak b \n"
               " WHERE a.iendorse = b.iendorse  \n"
               "   AND a.iendorse= '%s'",
               sFullDBName,sFullDBName,p_sIendorse);
        printf("-- trace stmt_buf[%s]\n ", stmt_buf);
        $PREPARE pre_es_ply FROM $stmt_buf;
        $EXECUTE pre_es_ply INTO 
               $flag_dinstall    ,$strDinstall    ,$flag_isequence,$strIsequence,
               $flag_ainstall_zip,$strAinstall_zip,$flag_ainstall ,$strAinstall;
        $FREE pre_es_ply;
        if (flag_dinstall > 0)
        {
            strcpy(g_sNcontent, "EDRNOTE");
            g_iOrder++;
            $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;             

            sprintf_s(sTmpBuf, sizeof sTmpBuf, "���O�I��ҩӫO���������e�A�ۧY��_�ܧ�u�w�˦~��v�� %s", trim(strDinstall));
            strcpy(g_sNcontent,trim_xspace(sTmpBuf));            
            g_iOrder++;
            $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;  

            strcpy(g_sNcontent, "C");
            g_iOrder++;
            $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;              
        }
        if (flag_isequence > 0)
        {
            strcpy(g_sNcontent, "EDRNOTE");
            g_iOrder++;
            $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;              

            sprintf_s(sTmpBuf, sizeof sTmpBuf, "���O�I��ҩӫO���������e�A�ۧY��_�ܧ�u���~�Ǹ��v�� %s", strIsequence);            
            strcpy(g_sNcontent,trim_xspace(sTmpBuf));            
            g_iOrder++;
            $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent; 

            strcpy(g_sNcontent, "C");
            g_iOrder++;
            $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent; 
        }
        /*if (flag_ainstall_zip > 0)
        {
            sprintf_s(sTmpBuf, sizeof sTmpBuf, "���O�I��ҫO���������e�A�ۧY��_�ܧ�u�w�˦a�}�l���ϸ��v�� %s", strAinstall_zip);            
        }*/
        if (flag_ainstall > 0)
        {
            strcpy(g_sNcontent, "EDRNOTE");
            g_iOrder++;
            $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;              

            sprintf_s(sTmpBuf, sizeof sTmpBuf, "���O�I��ҩӫO���������e�A�ۧY��_�ܧ�u�w�˦a�}�v�� %s%s",trim(strAinstall_zip), strAinstall);            
            strcpy(g_sNcontent,trim_xspace(sTmpBuf));            
            g_iOrder++;
            $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent; 

            strcpy(g_sNcontent, "C");
            g_iOrder++;
            $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent; 
        }
    }

    iPg_init = 1; /* 861226-mag, keep initial value */
    iPg = 1;
    lEdrItemCount = 0; /* ��鷺�e���Ӽ� */

    switch (*g_sFedr_class)
    {
    case '1': /* ���P */
        strcpy(recEdrChg[idx].icode, "01");
        recEdrChg[idx].fclass = 1;
        idx++;
        break;
    case '2': /* �L�� */
        strcpy(recEdrChg[idx].icode, "30");
        recEdrChg[idx].fclass = 1;
        idx++;
        break;
    case '3': /* ��g��H */
        strcpy(recEdrChg[idx].icode, "80");
        recEdrChg[idx].fclass = 1;
        idx++;
        break;
    case '4': /* �h���h�O */
        strcpy(recEdrChg[idx].icode, "60");
        recEdrChg[idx].fclass = 1;
        idx++;
        break;
    } /* switch */

    /* car9602053 ���s�W���N�I�L�����O */
    if ((*g_sFedr_class == '2') || (*g_sFedr_class == '5') || (*g_sFedr_class == '7') ||
        (*g_sFedr_class == '9') || (*g_sFedr_class == '8'))
    {
        puts("test");
        for (i = 0; i < 7; i++)
        {
            iDeflag = 1;
            psFieldStatus = g_sIedr_field + i;
            printf("%X", *psFieldStatus);
            for (j = 0; j < 8; j++)
            { /* �w�� psFieldStatus 8 �� bits */

                if (*psFieldStatus & iDeflag)
                {
                    sprintf_s(recEdrChg[idx].icode, sizeof recEdrChg[idx].icode, "%02d", i * 8 + j);
                    recEdrChg[idx].fclass = 2;
                    idx++;
                    printf("recEdrChg[%d].icode=[%s]\n", idx, recEdrChg[idx].icode);
                }
                iDeflag <<= 1;
            }
        }
        puts("");
        puts("");
    }

    flag_02 = flag_03 = flag_05 = 0;
    /* car9602053 ���s�W���N�I�L�����O */
    if ((*g_sFedr_class == '4') || (*g_sFedr_class == '6') ||
        (*g_sFedr_class == '9') || (*g_sFedr_class == '8'))
    {
        printf("{ca401_data3_free.0001}:select iedr_type,iins_type,qserial from edr_ins_type\n");
        stmt_buf[0] = '\0';
        sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s WHERE %s %s ",
                " iedr_type, iins_type, qserial ",
                sFullDBName, "edr_ins_type ",
                " iendorse = ? ",
                " ORDER BY qserial");
        $PREPARE x1_tmp FROM $stmt_buf;
        $DECLARE x1_f CURSOR FOR x1_tmp;
        $FREE x1_tmp;
        $OPEN x1_f USING $p_sIendorse;
        while (1)
        {
            $FETCH x1_f INTO $sIedr_type, $sIins_type, $iQserial;
            if (SQLCODE == SQLNOTFOUND)
                break;

            strcpy(sIins_type, trim(sIins_type));

            if (strcmp(sIedr_type, "02") == 0)
            {
                if (flag_02 == 0)
                    flag_02 = 1;
                else
                    continue;
            }
            if (strcmp(sIedr_type, "03") == 0)
            {
                if (flag_03 == 0)
                    flag_03 = 1;
                else
                    continue;
            }
            if (strcmp(sIedr_type, "05") == 0)
            {
                if (flag_05 == 0)
                    flag_05 = 1;
                else
                    continue;
            }
            if (strcmp(sIedr_type, "10") == 0)
            {
                continue;
            }
            strcpy(sFins_grp, " ");
            if ((strcmp(sIedr_type, "04") == 0) || (strcmp(sIedr_type, "40") == 0)) /* 04:�O�B�ܰ� 40:�O�O�ܰ� */
            {
                printf("{ca401_data3_free.0002}:select fins_grp,qcoverage from insurance_type\n");
                $SELECT fins_grp, qcoverage INTO $sFins_grp, $iQcoverage FROM insurance_type WHERE iins_type = $sIins_type;
                strcpy(recEdrChg[idx].icode, sIedr_type);
                strcpy(recEdrChg[idx].iins_type, sIins_type);
                strcpy(recEdrChg[idx].fins_grp, sFins_grp);
                recEdrChg[idx].fclass = 1;
                idx++;
            }
            else
            {
                strcpy(recEdrChg[idx].icode, sIedr_type);
                strcpy(recEdrChg[idx].iins_type, sIins_type);
                strcpy(recEdrChg[idx].fins_grp, sFins_grp);
                recEdrChg[idx].fclass = 1;
                idx++;
            }
        }
        $CLOSE x1_f;
        $FREE x1_f;
    }

    /* car9602053 ���s�W���N�I�L�����O */
    if ((*g_sFedr_class == '4') || (*g_sFedr_class == '6') ||
        (*g_sFedr_class == '9') || (*g_sFedr_class == '8'))
    {
        if (g_lMedrdmg_prem + g_lMedrlia_prem > 0)
        {
            strcpy(recEdrChg[idx].icode, "98");
            recEdrChg[idx].fclass = 2;
            idx++;
        }
        else if (g_lMedrdmg_prem + g_lMedrlia_prem < 0)
        {
            strcpy(recEdrChg[idx].icode, "97");
            recEdrChg[idx].fclass = 2;
            idx++;
        }
    }
    /*strcpy(recEdrChg[idx].icode, "99"); * �S���[�� */
    recEdrChg[idx].fclass = 2;
    idx++;

    for (i = 0; i < idx; i++)
    {
        sprintf_s(sFclass, sizeof sFclass, "%d", recEdrChg[i].fclass);

        if (*g_sFedr_class == '2' && strcmp(sFclass, "2") == 0 && strcmp(recEdrChg[i].icode, "02") == 0)
            continue;
        if ((*g_sFedr_class == '5' || *g_sFedr_class == '2') && strcmp(sFclass, "2") == 0 && strcmp(recEdrChg[i].icode, "03") == 0)
            if (*g_sNuser == ' ' || *g_sNuser == '\0')
                strcpy(recEdrChg[i].icode, "70");

        if ((*g_sFedr_class == '5' || *g_sFedr_class == '2') && strcmp(sFclass, "2") == 0 && strcmp(recEdrChg[i].icode, "05") == 0)
            if (*g_sNbenef == ' ' || *g_sNbenef == '\0')
                strcpy(recEdrChg[i].icode, "71");

        printf("{ca401_data3_free.0003}:select iedr_item from endorsement_code\n");

        $SELECT iedr_item
           INTO $sIedr_item
           FROM endorsement_code
          WHERE icode  = $recEdrChg[i].icode
            AND fclass = $sFclass;
        if (SQLCODE == SQLNOTFOUND)
            continue;

        printf("{ca401_data3_free.0004}:select data from endorsement_item [%s]\n", sIedr_item);
        $DECLARE x2_f CURSOR FOR
            SELECT qserial,eedr_item, ntable, ncolumn, fdatatype
              INTO $lQserial, $sEedr_item, $sNtable, $sNcolumn, $sFdatatype 
              FROM endorsement_item 
             WHERE iedr_item = $sIedr_item 
          ORDER BY qserial;
        $OPEN x2_f;
        for (j = 0;; j++)
        {
            $FETCH x2_f;
            if (SQLCODE == SQLNOTFOUND)
                break;
            printf("{ca401_data3_free.0000}:INTO CURSOR x2\n");
            strcpy(sEedr_item, rtrim(sEedr_item));
            strcpy(sNtable, rtrim(sNtable));
            strcpy(sNcolumn, rtrim(sNcolumn));
            strcpy(sFdatatype, rtrim(sFdatatype));

            printf("--trace j=[%d]\n", j);
            printf("--trace lQserial=[%ld],sEedr_item=[%s],sFdatatype=[%s]\n", lQserial, sEedr_item, sFdatatype);
            printf("--trace sNtable =[%s] ,sNcolumn  =[%s]\n,", sNtable, sNcolumn);

            /* 1110602009_SC1 �����ç��C�L�{�������O��첧�ʤ��e
               (�ӥѷ��Yca401m02x.ec���n�P�_nequipment�O�_������)
            if (strncmp(sNcolumn, "nequipment", 10) == 0)
                continue;
            */   
            if ((g_pEedr_item[j] = calloc(1, strlen(sEedr_item) + 1)) == NULL)
            {
                int ii;
                for (ii = 0; ii < j; ii++)
                {
                    free(g_pEedr_item[ii]);
                    free(g_pData[ii]);
                }
                return M_CM_NOT_MALLOC;
            }
            if (strncmp(g_sIpolicy+5,"ES",2)==0) /*1120927002_C02 �R�q�ΰӫ~�}�o*/
            {
                /* ex. ���O�I��ҩӫO�T�������y��ơA�ۧY��_�ܧ󭫸m���Ȭ�*/  
                 strSearchReplace(sEedr_item, "�T��", "�R�q��");
                 strSearchReplace(sEedr_item, "���y", "���~");
            }
            strcpy(g_pEedr_item[j], sEedr_item);

            if (strncmp(sNtable, "edr_relation", 12) == 0)
            {
                if (strncmp(sNcolumn, "total", 5) == 0)
                {
                    printf("TEST!!!!!!!!\n");
                    sprintf_s(sTmt, sizeof sTmt, "SELECT %s FROM %s:%s %s:%s WHERE %s",
                                " Case "
                                "    WHEN b.dpolicy >= '04/01/2002' "
                                "    then a.medrdmg_prem + a.medrlia_prem "
                                " ELSE "
                                "    a.medrdmg_prem + a.medrlia_prem - a.medrdmg_disc - a.medrlia_disc "
                                " END ",
                            sFullDBName, "edr_relation a ,",
                            sFullDBName, "ply_relation b ",
                            "a.iendorse = ? AND a.ipolicy = b.ipolicy");
                    printf("sTmt[%s]\n", sTmt);
                    $PREPARE sel1 FROM $sTmt;
                    $DECLARE sel1_1f CURSOR FOR sel1;
                    $FREE sel1;
                    printf("sTmt[%s]\n", sTmt);
                    $OPEN sel1_1f USING $p_sIendorse;
                    $FETCH sel1_1f INTO $lTot_prem;
                    $CLOSE sel1_1f;
                    $FREE sel1_1f;

                    lTot_prem = labs(lTot_prem);
                    rfmtlong(lTot_prem, "****,***,**&", sTmpData);
                }
                else
                {
                    if (*sFdatatype == '4' || *sFdatatype == '1')
                    {
                        sprintf_s(sTmt, sizeof sTmt, "SELECT %s FROM %s:%s WHERE iendorse='%s'",
                                sNcolumn, sFullDBName, sNtable, p_sIendorse);
                        printf("{ca401_data3_free.0005}:stmt[%s]\n", sTmt);
                        $PREPARE q1 FROM $sTmt;
                        $DECLARE q1_1f CURSOR FOR q1;
                        $FREE q1;
                        $OPEN q1_1f;
                        $FETCH q1_1f INTO $sTmpBuf;
                        $CLOSE q1_1f;
                        $FREE q1_1f;

                        strcpy(sTmpBuf, rtrim(sTmpBuf));

                        if (*sFdatatype == '4')
                            strcpy(sTmpData, cm_from_infdate_100(sTmpBuf));
                        else
                        {
                            if (strncmp(sNcolumn, "itreaty", 7) == 0)
                            {
                                if (strncmp(sTmpBuf, "6", 1) == 0)
                                    strcpy(sTmpBuf, "�s�j��d���I�X��");
                            }
                            strcpy(sTmpData, sTmpBuf);
                        }
                    }
                    else
                    {
                        sprintf_s(sTmt, sizeof sTmt, "SELECT %s FROM %s:%s WHERE iendorse = '%s'",
                                sNcolumn, sFullDBName, sNtable, p_sIendorse);
                        $PREPARE q5 FROM $sTmt;
                        printf("ca401_data3_free.0006}:stmt[%s]\n", sTmt);
                        $DECLARE q5_1f CURSOR FOR q5;
                        $FREE q5;
                        $OPEN q5_1f;
                        $FETCH q5_1f INTO $iTmp;
                        $CLOSE q5_1f;
                        $FREE q5_1f;
                        rfmtlong(iTmp, "***&", sTmpData);
                    }
                }
            }
            else if (strncmp(sNtable, "endorsement", 11) == 0)
            {
                if (strncmp(sNcolumn, "nassured30", 10) == 0)
                {
                    sprintf_s(sTmt, sizeof sTmt, "SELECT nassured FROM %s:%s WHERE iendorse = '%s'",
                            sFullDBName, sNtable, p_sIendorse);

                    $PREPARE q8 FROM $sTmt;
                    printf("{ca401_data.0007}:stmt[%s]\n", sTmt);
                    $DECLARE q8_1f CURSOR FOR q8;
                    $FREE q8;
                    $OPEN q8_1f;
                    $FETCH q8_1f INTO $sTmpBuf;
                    $CLOSE q8_1f;
                    $FREE q8_1f;

                    if ((*g_sFedr_class == '2') || (*g_sFedr_class == '8'))
                    {
                        i = cc_split_chinese(sTmpBuf, sStr, 2);
                        strcat(sStr, "****");
                        strcpy(sTmpBuf, sStr);
                    }

                    strcpy(sTmpBuf, rtrim(sTmpBuf));

                    sprintf_s(sTmpData, sizeof sTmpData, "      %s", sTmpBuf);
                }
                else if (strncmp(sNcolumn, "total", 5) == 0)
                {
                    stmt_buf[0] = '\0';
                    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s WHERE %s ",
                            " medrdmg_prem + medrlia_prem ",
                            sFullDBName, " edr_relation ",
                            " iendorse = ?");
                    $PREPARE cur_O FROM $stmt_buf;
                    $EXECUTE cur_O INTO $lTot_prem USING $p_sIendorse;
                    $FREE cur_O;
                    lTot_prem = labs(lTot_prem);

                    rfmtlong(lTot_prem, "****,***,**&", sTmpData);
                }
                else
                {
                    sprintf_s(sTmt, sizeof sTmt, "SELECT %s FROM %s:%s WHERE iendorse='%s'",
                            sNcolumn, sFullDBName, sNtable, p_sIendorse);
                    $PREPARE q7 FROM $sTmt;
                    printf("{ca401_data.0007}:stmt[%s]\n", sTmt);
                    $DECLARE q7_1f CURSOR FOR q7;
                    $FREE q7;
                    $OPEN q7_1f;
                    $FETCH q7_1f INTO $sTmpBuf;
                    $CLOSE q7_1f;
                    $FREE q7_1f;

                    printf("==================================================================[%s]\n", sNcolumn);

                    strcpy(sTmpBuf, rtrim(sTmpBuf));
                    if (*sFdatatype == '4') /* data typ is 'date' */
                    {
                        strcpy(sTmpData, cm_from_infdate_100(sTmpBuf));
                        if (strncmp(sNcolumn, "dissue", 6) == 0)
                        {
                            /* strncpy(sTmpData,sTmpData,6);*/
                            sTmpData[6]='\0';
                            printf("--trace sTmpData=[%s]\n", sTmpData);
                        }
                    }    
                    else
                    {
                        if (strncmp(sNcolumn, "fassured", 8) == 0)
                        {
                            if (strncmp(sTmpBuf, "1", 1) == 0)
                                strcpy(sTmpBuf, "�۵M�H");
                            if (strncmp(sTmpBuf, "2", 1) == 0)
                                strcpy(sTmpBuf, "�k�H");
                            if (strncmp(sTmpBuf, "3", 1) == 0)
                                strcpy(sTmpBuf, "�~��H");
                        }
                        else if (strncmp(sNcolumn, "fsex", 4) == 0)
                        {
                            if (strncmp(sTmpBuf, "1", 1) == 0)
                                strcpy(sTmpBuf, "�k");
                            if (strncmp(sTmpBuf, "2", 1) == 0)
                                strcpy(sTmpBuf, "�k");
                        }
                        else if (strncmp(sNcolumn, "fmarriage", 9) == 0)
                        {
                            if (strncmp(sTmpBuf, "1", 1) == 0)
                                strcpy(sTmpBuf, "�w�B");
                            if (strncmp(sTmpBuf, "2", 1) == 0)
                                strcpy(sTmpBuf, "���B");
                        }
                        else if (strncmp(sNcolumn, "flimit", 6) == 0)
                        {
                            if (strncmp(sTmpBuf, "1", 1) == 0)
                                strcpy(sTmpBuf, "���w�r�p�H");
                            if (strncmp(sTmpBuf, "2", 1) == 0)
                                strcpy(sTmpBuf, "�����w�r�p�H");
                        }
                        else if (strncmp(sNcolumn, "fpt", 3) == 0)
                        {
                            if (strncmp(sTmpBuf, "P", 1) == 0)
                                strcpy(sTmpBuf, "���ȼ�");
                            if (strncmp(sTmpBuf, "T", 1) == 0)
                                strcpy(sTmpBuf, "����");
                        }
                        else if (strncmp(sNcolumn, "ibrand", 6) == 0)
                            sTmpBuf[8] = '\0';

                        /* 1060406006_C1 CAR401�BCAR409���C�L�Ӹ�B�n */

                        if ((*g_sFedr_class == '2') || (*g_sFedr_class == '8'))
                        {
                            if (p_fmask[0] == '1')
                            {
                                if (strncmp(sNcolumn, "iassured", 8) == 0)
                                {
                                    strcpy(sStr, substring(sTmpBuf, 1, 3));
                                    strcat(sStr, "****");
                                    strcat(sStr, substring(sTmpBuf, 8, 5));
                                    strcpy(sTmpBuf, sStr);
                                }
                                else if (strncmp(sNcolumn, "nassured", 8) == 0)
                                {
                                    strcpy(sStr, substring(sTmpBuf, 1, 2));
                                    strcat(sStr, "****");
                                    strcpy(sTmpBuf, sStr);
                                }
                                else if (strncmp(sNcolumn, "aassured", 8) == 0)
                                {
                                    strcpy(sStr, substring(sTmpBuf, 1, 12));
                                    strcat(sStr, "****");
                                    strcpy(sTmpBuf, sStr);
                                    printf("aassured[%s]\n", sTmpBuf);
                                }
                                else if (strncmp(sNcolumn, "ibirth", 6) == 0)
                                {
                                    strcpy(sTmpBuf, "*******");
                                }
                                else if (strncmp(sNcolumn, "fsex", 4) == 0 || strncmp(sNcolumn, "fmarriage", 9) == 0)
                                {
                                    strcpy(sTmpBuf, "**");
                                }
                            }
                        }

                        strcpy(sTmpData, sTmpBuf);
                    }
                }
            }
            else if (strncmp(sNtable, "edr_ins_type", 12) == 0)
            {
                strcpy(sIins_type, trim(recEdrChg[i].iins_type));

                if (strncmp(sNcolumn, "pcal", 4) == 0)
                {
                    if (strcmp(sIins_type, "21") == 0)
                        strcpy(sTmpData, "");
                    else
                    {
                        stmt_buf[0] = '\0';
                        sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s WHERE %s ",
                                " fcal_way, pcal ",
                                sFullDBName, "edr_ins_type ",
                                " iendorse = ? AND iins_type = ? ");
                        $PREPARE cur_P FROM $stmt_buf;
                        $EXECUTE cur_P INTO $sFcal_way, $iTmp USING $p_sIendorse, $sIins_type;
                        $FREE cur_P;

                        rfmtlong(iTmp, "***&", sTmpData);
                        if (*sFcal_way == 'M')
                            strcat(sTmpData, "% ");
                        else
                            strcat(sTmpData, "��");
                    }
                }
                else
                {
                    printf("{ca401_data3_free.0008}:select data from edr_ins_type\n");
                    stmt_buf[0] = '\0';
                    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s WHERE %s ",
                            " medrinj_cover, medrdea_cover, medrdmg_cover, mdeduct, medrins_prem ",
                            sFullDBName, "edr_ins_type ",
                            " iendorse = ? AND iins_type = ?");
                    $PREPARE cur_Q FROM $stmt_buf;
                    $EXECUTE cur_Q INTO $lMedrinj_cover, $lMedrdea_cover, $lMedrdmg_cover, $lMdeduct, $lMedrins_prem USING $p_sIendorse, $sIins_type;
                    $FREE cur_Q;

                    stmt_buf[0] = '\0';
                    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s WHERE %s ",
                            " minjured_cover, mdeath_cover, mdamage_cover, mins_premium ",
                            sFullDBName, "ply_ins_type_bak ",
                            " iendorse = ? AND iins_type = ?");
                    $PREPARE cur_R FROM $stmt_buf;
                    $EXECUTE cur_R INTO $lMinjured_cover, $lMdeath_cover, $lMdamage_cover, $lMins_premium USING $p_sIendorse, $sIins_type;                    
                    if (SQLCODE == SQLNOTFOUND)
                    {
                        lMins_premium = 0;
                    }
                    $FREE cur_R;

                    printf("sNcolumn[%s],iins_type[%s]\n", sNcolumn, sIins_type);
                    if (strncmp(sNcolumn, "coverage", 8) == 0)
                    {
                        if (lMedrdmg_cover != 0)
                            rfmtlong(lMdamage_cover + lMedrdmg_cover, "****,***,**&", sTmpData);
                        else if (lMedrinj_cover != 0)
                            rfmtlong(lMinjured_cover + lMedrinj_cover, "****,***,**&", sTmpData);
                    }
                    else if (strncmp(sNcolumn, "medrins_prem1", 13) == 0)
                        rfmtlong(lMins_premium + lMedrins_prem, "****,***,**&", sTmpData);
                    else if (strncmp(sNcolumn, "mdeduct1", 8) == 0)
                    {
                        if (strcmp(sIins_type, "11")  == 0 || strcmp(sIins_type, "129") == 0 || strcmp(sIins_type, "211") == 0 || 
                            strcmp(sIins_type, "176") == 0 || strcmp(sIins_type, "177") == 0 || strcmp(sIins_type, "178") == 0)
                        {
                            if (lMdeduct == 10)
                                strcpy(sTmpData, " �ʤ�����");
                            if (lMdeduct == 20)
                                strcpy(sTmpData, " �ʤ����G��");
                            if (lMdeduct == 0)
                                strcpy(sTmpData, " �L");
                        }
                        else
                        {
                            stmt_buf[0] = '\0';
                            sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s, %s:%s WHERE %s ",
                                    " a.icar_type , min(b.drate_ym) ",
                                    sFullDBName, "ply_relation_bak a ",
                                    sFullDBName, "ply_ins_type_bak b ",
                                    " a.iendorse = ? AND a.iendorse = b.iendorse GROUP BY a.icar_type ");
                            $PREPARE cur_S FROM $stmt_buf;
                            $EXECUTE cur_S INTO $sIcar_type, $sDrate_ym USING $p_sIendorse;
                            
                            if (SQLCODE == SQLNOTFOUND)
                            {
                                printf("{ca401_data2.0041}:select ply_relation_bak not found!!\n");
                                printf("{ca401_data2.0041}:select ori_ply_relation !!\n");

                                stmt_buf[0] = '\0';
                                sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s, %s:%s WHERE %s %s %s %s",
                                        " a.icar_type, min(b.drate_ym) ",
                                        sFullDBName, "ori_ply_relation a",
                                        sFullDBName, "ori_ins_type b",
                                        " a.ipolicy=(SELECT ipolicy FROM ", sFullDBName, ":edr_relation WHERE iendorse=?)",
                                        " AND a.ipolicy = b.ipolicy GROUP BY a.icar_type ");
                                $PREPARE cur_T FROM $stmt_buf;
                                $EXECUTE cur_T INTO $sIcar_type, $sDrate_ym USING $p_sIendorse;
                                
                                if (SQLCODE == SQLNOTFOUND)
                                {
                                    $FREE cur_T;
                                    return M_CA_NENDORSE;
                                }
                                $FREE cur_T;    
                            }
                            $FREE cur_S;
                            strcpy(sIcar_type, TRANS_CAR_TYPE(sIcar_type, sDrate_ym));

                            memset(tmp1Deduct, 0, sizeof(tmp1Deduct));
                            lMdeduct = labs(lMdeduct);
                            sprintf_s(tmpDeduct, sizeof tmpDeduct, "%d", lMdeduct);
                            strcpy(tmpDeduct, trim(tmpDeduct));
                            printf("A.Endorsement 01/05 Deduct ==>[%s]\n", tmpDeduct);
                            printf("tmpDeduct[%s]\n", tmpDeduct);
                            strcpy(tmp1Deduct, "");
                            if (strcmp(trim(sIins_type), "29") != 0 && strcmp(trim(sIins_type), "124") != 0)
                            {
                                if ((strcmp(trim(sIins_type), "30") == 0)  || (strcmp(trim(sIins_type), "530") == 0) ||
                                    (strcmp(trim(sIins_type), "301") == 0) || (strcmp(trim(sIins_type), "302") == 0))   /*1110308005_SC2 �w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h*/
                                {
                                    if (strstr(tmpDeduct, "24"))
                                        strcpy(tmp1Deduct, "�s�v�I");
                                    if (strstr(tmpDeduct, "55"))
                                    {
                                        if (strlen(trim(tmp1Deduct)) == 0)
                                        {
                                            strcpy(tmp1Deduct, "�����I");
                                        }
                                        else
                                        {
                                            strcat(tmp1Deduct, "�έ����I");
                                        }
                                    }

                                    if (strlen(trim(tmp1Deduct)) > 0)
                                    {
                                        sprintf_s(sTmpData, sizeof sTmpData, "%s%s", "�t", rtrim(tmp1Deduct));
                                    }
                                    else
                                    {
                                        if (strcmp(trim(sIins_type), "301") == 0 || strcmp(trim(sIins_type), "302") == 0)
                                        {
                                            strcpy(sTmpData, "���t�����I");
                                        }
                                        else
                                        {
                                            strcpy(sTmpData, "���t�s�v�I�έ����I");
                                        }
                                    }
                                }
                                else
                                {
                                    $SELECT prn_deduct
                                       INTO $tmp1Deduct
                                       FROM ca_dmg_mdeduct
                                      WHERE icar_type = $sIcar_type
                                        AND ideduct = $tmpDeduct;
                                    printf("tmp1Deduct==>[%s]\n", tmp1Deduct);
                                    strcpy(sTmpData, trim(tmp1Deduct));

                                    strcat(sTmpData, "����");
                                }
                            }
                            else
                            {
                                $SELECT prn_deduct INTO $tmp1Deduct
                                   FROM ca_dmg_mdeduct
                                  WHERE icar_type = 'I29' AND ideduct = $tmpDeduct;
                                printf("29--->prn_deduct[%s]\n", tmp1Deduct);
                                printf("tmp1Deduct==>[%s]\n", tmp1Deduct);
                                strcpy(sTmpData, trim(tmp1Deduct));

                                strcat(sTmpData, "����");
                            }
                        }
                    }
                    else if (strncmp(sNcolumn, "medrdmg_cover", 13) == 0)
                    {
                        cm_double_cstr((double)lMedrdmg_cover, sTmpData, 50);
                    }
                    else if (strncmp(sNcolumn, "iins_type", 9) == 0) /*1081129013_SC2 ����������O30�I�ئۭt�B���i�t55���ˮ�*/
                    {

                        if (strcmp(sIedr_item, "05") == 0)
                        {
                            if (*sFdatatype == '1') /* "1"�w�q�N��:30�I�� */ 
                            {
                                
                                stmt_buf[0] = '\0';
                                lMdeduct = 0;
                                strcpy(tmpIins_type, " ");

                                /*1110714002_SC1 �ץ����C�L�W�B�I�����P�_�W�h*/     
                                if ((strcmp(trim(sIins_type), "30") == 0)  || (strcmp(trim(sIins_type), "530") == 0) ||
                                    (strcmp(trim(sIins_type), "301") == 0) || (strcmp(trim(sIins_type), "302") == 0))
                                {
                                   sprintf_s(tmpDeduct, sizeof tmpDeduct, "%d", lMdeduct);
                                   strcpy(tmpDeduct, trim(tmpDeduct));
                                   printf("-- trace tmpDeduct[%s]\n ", tmpDeduct);
                                   if (strstr(tmpDeduct, "55"))
                                    {
                                        printf("-- trace has 55\n ");
                                        printf("-- trace g_pEedr_item[j][%s]\n ", g_pEedr_item[j]);

                                        /*1110308005_SC1_�w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h */
                                        if ((strcmp(trim(sIins_type), "301") == 0) || (strcmp(trim(sIins_type), "302") == 0))
                                        {
                                            strcpy(g_pEedr_item[j], "\n�@�@�ӫO���W�B�d���I-��D���W��(�ӫO�d��t�����I)");
                                        }
                                    }
                                    else
                                    {
                                        strcpy(g_pEedr_item[j], " ");
                                    }                                
                                }
                                else
                                {
                                    strcpy(g_pEedr_item[j], " ");
                                }
                            }
                        }
                    }
                }
            }
            else if (strncmp(sNtable, "ins_type", 8) == 0)
            {
                strcpy(sIins_type, trim(recEdrChg[i].iins_type));
                if (strcmp(sIins_type, "53") == 0||strcmp(sIins_type, "253") == 0)
                    strcpy(sTmpData, "(�t�����I) ");
                else
                    strcpy(sTmpData, " ");
            }
            else if (strncmp(sNtable, "insurance_type", 14) == 0)
            {
                strcpy(sIins_type, trim(recEdrChg[i].iins_type));
                strcpy(sFins_grp, recEdrChg[i].fins_grp);

                sprintf_s(sTmt, sizeof sTmt, "SELECT %s FROM %s:%s WHERE iins_type='%s'",
                        sNcolumn, sFullDBName, sNtable, sIins_type);

                $PREPARE q2 FROM $sTmt;
                $DECLARE q2_1f CURSOR FOR q2;
                $FREE q2;
                $OPEN q2_1f;
                $FETCH q2_1f INTO $sTmpBuf;
                $CLOSE q2_1f;
                $FREE q2_1f;

                strcpy(sTmpBuf, rtrim(sTmpBuf));
                if (strcmp(trim(sIins_type), "30") == 0)
                {
                    strcat(sTmpBuf, "-�O�٫�");
                }
                else if (strcmp(trim(sIins_type), "301") == 0 || strcmp(trim(sIins_type), "302") == 0) /*1110308005_SC2 �w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h*/
                {
                    strcat(sTmpBuf, "-��D���W��");
                }

                if (*sFins_grp != '\0' && *sFins_grp != ' ')
                {
                    lMedrinj_cover = lMedrdmg_cover = lMedrins_prem = 0;

                    stmt_buf[0] = '\0';
                    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s WHERE %s ",
                            " medrinj_cover, medrdmg_cover, medrins_prem ",
                            sFullDBName, "edr_ins_type ",
                            " iendorse = ? AND iins_type = ?");
                    $PREPARE cur_U FROM $stmt_buf;
                    $EXECUTE cur_U INTO $lMedrinj_cover, $lMedrdmg_cover, $lMedrins_prem USING $p_sIendorse, $sIins_type;
                    $FREE cur_U;

                    if (strcmp(sIedr_item, "04") == 0)
                    {
                    }
                    else if (strcmp(sIedr_item, "40") == 0)
                    {
                        if (lMedrins_prem >= 0)
                            strcat(sTmpBuf, "�W�[�O�O");
                        else
                            strcat(sTmpBuf, "��֫O�O");
                    }
                    strcpy(sTmpData, sTmpBuf);
                }
                else
                    strcpy(sTmpData, sTmpBuf);
            }
            else if (strncmp(sNtable, "ply_ins_type_bak", 16) == 0)
            {
                printf("--trace sNtable=ply_ins_type_bak");

                strcpy(sIins_type, trim(recEdrChg[i].iins_type));

                if (strncmp(sNcolumn, "coverage", 8) == 0)
                {
                    printf("--trace sNcolumn=coverage");
                    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT CASE WHEN medrdmg_cover != 0 THEN 'mdamage_cover'"
                                      "            WHEN medrinj_cover != 0 THEN 'minjured_cover'"
                                      "            ELSE 'mdeath_cover' END "
                                      "       FROM %s:edr_ins_type "
                                      "      WHERE iendorse = ? AND iins_type = ?",
                            sFullDBName);
                    $PREPARE prep4 FROM $stmt_buf;
                    $EXECUTE prep4 INTO $sNcolumn USING $p_sIendorse, $sIins_type;
                    $FREE prep4;

                    /* strcpy(sNcolumn, "minjured_cover"); */
                    /* strcpy(sNcolumn, "mdamage_cover"); */

                    /* ------------------------------------ */
                    sprintf_s(sTmt, sizeof sTmt, "SELECT %s FROM %s:%s WHERE %s",
                            sNcolumn, sFullDBName, sNtable, "iendorse=? AND iins_type=?");

                    $PREPARE q6 FROM $sTmt;
                    $DECLARE q6_1f CURSOR FOR q6;
                    $FREE q6;
                    $OPEN q6_1f USING $p_sIendorse, $sIins_type;
                    $FETCH q6_1f INTO $lTot_prem;
                    if (SQLCODE == SQLNOTFOUND)
                        lTot_prem = 0;
                    $CLOSE q6_1f;
                    $FREE q6_1f;

                    rfmtlong(lTot_prem, "****,***,**&", sTmpData);
                }
                else
                {
                    printf("--trace sNcolumn <> coverage");
                    sprintf_s(sTmt, sizeof sTmt, "SELECT %s FROM %s:%s WHERE %s", sNcolumn, sFullDBName, sNtable, "iendorse=? AND iins_type=?");

#ifdef _M860718
                    printf("{ca401_data3_free.0160}: ply_ins_type_bak.coverage stmt[%s]\n", sTmt);
#endif

                    $PREPARE q3 FROM $sTmt;
                    $DECLARE q3_1f CURSOR FOR q3;
                    $FREE q3;
                    $OPEN q3_1f USING $p_sIendorse, $sIins_type;
                    $FETCH q3_1f INTO $lTot_prem;
                    if (SQLCODE == SQLNOTFOUND)
                        lTot_prem = 0;
                    $CLOSE q3_1f;
                    $FREE q3_1f;

                    if (strcmp(sIedr_item, "20") == 0)
                    {
                        printf("--trace sIedr_item=20");
                        if (strcmp(sIins_type, "11")  == 0 || strcmp(sIins_type, "129") == 0 || strcmp(sIins_type, "211") == 0 || 
                            strcmp(sIins_type, "176") == 0 || strcmp(sIins_type, "177") == 0 || strcmp(sIins_type, "178") == 0)
                        {
                            strcpy(sTmpData, " ");
                            if (lTot_prem == 10)
                                strcpy(sTmpData, " �ʤ�����");
                            if (lTot_prem == 20)
                                strcpy(sTmpData, " �ʤ����G��");
                        }
                        else
                        {
                            printf("--trace sIins_type[%s]\n", sIins_type);
                            stmt_buf[0] = '\0';
                            sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s, %s:%s WHERE %s",
                                    " a.icar_type, min(b.drate_ym) ",
                                    sFullDBName, "ply_relation_bak a ",
                                    sFullDBName, "ply_ins_type_bak b ",
                                    " a.iendorse = ? AND a.iendorse = b.iendorse GROUP BY a.icar_type ");
                            $PREPARE cur_V FROM $stmt_buf;
                            $EXECUTE cur_V INTO $sIcar_type, $sDrate_ym USING $p_sIendorse;                            

                            if (SQLCODE == SQLNOTFOUND)
                            {
                                printf("{ca401_data2.0041}:select ply_relation_bak not found!!\n");
                                printf("{ca401_data2.0041}:select ori_ply_relation !!\n");

                                stmt_buf[0] = '\0';
                                sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s, %s:%s WHERE %s %s %s %s ",
                                        " a.icar_type, min(b.drate_ym) ",
                                        sFullDBName, "ori_ply_relation a ",
                                        sFullDBName, "ori_ins_type b ",
                                        " a.ipolicy=(SELECT ipolicy FROM ", sFullDBName, ":edr_relation WHERE iendorse=?)",
                                        " AND a.ipolicy = b.ipolicy GROUP BY a.icar_type");
                                printf("stmt_buf[%s]\n", stmt_buf);
                                $PREPARE cur_W FROM $stmt_buf;
                                $EXECUTE cur_W INTO $sIcar_type, $sDrate_ym USING $p_sIendorse;
                                
                                if (SQLCODE == SQLNOTFOUND)
                                {
                                    $FREE cur_W;
                                    return M_CA_NENDORSE;
                                }    
                                $FREE cur_W;
                            }
                            $FREE cur_V;
                            strcpy(sIcar_type, TRANS_CAR_TYPE(sIcar_type, sDrate_ym));

                            stmt_buf[0] = '\0';
                            sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s WHERE %s ",
                                    " mdeduct ",
                                    sFullDBName, "ply_ins_type_bak ",
                                    " iendorse = ? AND iins_type = ?");
                            $PREPARE cur_X FROM $stmt_buf;
                            printf("stmt_buf[%s]\n", stmt_buf);
                            $EXECUTE cur_X INTO $lMdeduct USING $p_sIendorse, $sIins_type;
                            $FREE cur_X;

                            memset(tmp1Deduct, 0, sizeof(tmp1Deduct));
                            lMdeduct = labs(lMdeduct);
                            sprintf_s(tmpDeduct, sizeof tmpDeduct, "%d", lMdeduct);
                            strcpy(tmpDeduct, trim(tmpDeduct));
                            printf("B.Endorsement 01/05 Deduct ==>[%s]\n", tmpDeduct);
                            strcpy(tmp1Deduct, "");
                            if (strcmp(trim(sIins_type), "29") == 0 || strcmp(trim(sIins_type), "124") == 0)
                            {
                                $SELECT prn_deduct INTO $tmp1Deduct
                                   FROM ca_dmg_mdeduct
                                  WHERE icar_type = 'I29' AND ideduct = $tmpDeduct;
                                printf("tmp1Deduct==>[%s]\n", tmp1Deduct);
                                strcpy(sTmpData, trim(tmp1Deduct));

                                /*  rfmtlong(lTot_prem, "****,***,**&", sTmpData);  */
                                strcat(sTmpData, "��");
                            }
                            else
                            {

                                if ((strcmp(trim(sIins_type), "30") == 0)  || (strcmp(trim(sIins_type), "530") == 0) ||
                                    (strcmp(trim(sIins_type), "301") == 0) || (strcmp(trim(sIins_type), "302") == 0)) /*1110308005_SC2 �w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h*/
                                {
                                    if (strstr(tmpDeduct, "24"))
                                        strcpy(tmp1Deduct, "�s�v�I");
                                    if (strstr(tmpDeduct, "55"))
                                    {
                                        if (strlen(trim(tmp1Deduct)) == 0)
                                        {
                                            strcpy(tmp1Deduct, "�����I");
                                        }
                                        else
                                        {
                                            strcat(tmp1Deduct, "�έ����I");
                                        }
                                    }
                                    printf("-- trace1 tmp1Deduct[%s]\n ", tmp1Deduct);
                                    if (strlen(trim(tmp1Deduct)) > 0)
                                        sprintf_s(sTmpData, sizeof sTmpData, "%s%s", "�t", rtrim(tmp1Deduct));
                                    else
                                        strcpy(sTmpData, "");
                                }
                                else
                                {

                                    $SELECT prn_deduct INTO $tmp1Deduct
                                       FROM ca_dmg_mdeduct
                                      WHERE icar_type = $sIcar_type
                                        AND ideduct = $tmpDeduct;
                                    printf("tmp1Deduct==>[%s]\n", tmp1Deduct);
                                    strcpy(sTmpData, trim(tmp1Deduct));

                                    /*  rfmtlong(lTot_prem, "****,***,**&", sTmpData);  */
                                    strcat(sTmpData, "��");
                                }
                            }
                            printf("--trace1 sTmpData[%s]\n", sTmpData);
                        }
                    }
                    else
                        rfmtlong(lTot_prem, "****,***,**&", sTmpData);
                }
            }
            else if (*sNtable == '\0' || *sNtable == ' ')
            {
                sTmpData[0] = '\0';
            }
            else
            {
                sprintf_s(sTmt, sizeof sTmt, "SELECT %s FROM %s:%s WHERE iendorse='%s'",
                        sNcolumn, sFullDBName, sNtable, p_sIendorse);
                $PREPARE q4 FROM $sTmt;
                $DECLARE x_f CURSOR FOR q4;
                $FREE q4;
                $OPEN x_f;
                $FETCH x_f INTO $sTmpBuf;
                $CLOSE x_f;
                $FREE x_f;

                strcpy(sTmpBuf, rtrim(sTmpBuf));
                if (*sFdatatype == '4')
                    strcpy(sTmpData, cm_from_infdate_100(sTmpBuf));
                else
                    strcpy(sTmpData, sTmpBuf);
            }

            printf("{ca401_data3_free.0009}\n");

            if ((g_pData[j] = calloc(1, strlen(sTmpData) + 1)) == NULL)
            {
                int ii;
                for (ii = 0; ii < j; ii++)
                {
                    printf("{ca401_data3_free.0012}\n");
                    free(g_pEedr_item[ii]);
                    free(g_pData[ii]);
                    printf("{ca401_data3_free.0013}\n");
                }
                return M_CM_NOT_MALLOC;
            }
            strcpy(g_pData[j], sTmpData);
        } /* end of for */
        $CLOSE x2_f;
        $FREE x2_f;

        printf("{ca401_data3_free.0010}\n");
        if (j != 0)
        {
            char *p;
            int xx;
            printf("--trace sTmpBuf[%s]\n", sTmpBuf);
            strcpy(sTmpBuf, pwformat(j, g_pEedr_item, g_pData, 4, &iLine));
            /*1060706003_SC1 �ק�W�B�d���I(30�B301)�C�L��r, "�ۭt�B" �אּ=> "�ӫO�d��"*/
            /* "�ۭt�B"�]�w�b endorsement_item,�A�ΩҦ��I�ءA�G�L�k��W����30,301�I�ت��ۭt�B��r */
            strSearchReplace(sTmpBuf, "�W�B�I-�O�٫��ۭt�B", "�W�B�I-�O�٫��ӫO�d��");
            strSearchReplace(sTmpBuf, "�W�B�I-��D���W���ۭt�B", "�W�B�I-��D���W���ӫO�d��");
#ifdef _M860718
            printf("{ca401_data3_free.0050}: iLine[%d] i[%d] sTmpBuf[%s]\n", iLine, i, sTmpBuf);
#endif

            if (lEdrItemCount >= 7) /* 861226-mag, ���@���̦h�L7�� */
            {
                lEdrItemCount = 0;
                iPg++;
                printf("-----------------------> data3() iPg[%d]\n", iPg);
            }

            /* 861226-mag, ��XsTmpBuf���Ĥ@�Ӵ���Ÿ�����}p */            
            strcpy(sTmpBuf, trim_xspace(sTmpBuf)); 
            p = strchr(sTmpBuf, '\n');            
            if (p == NULL)
            { /* 861226-mag, sTmpBuf���L����Ÿ� */
                /*insert_tmp_table(iPg, EDR_BASE_LINE + lEdrItemCount, 1, sTmpBuf);*/

                strcpy(g_sNcontent, "EDRNOTE");
                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;                 

                strcpy(g_sNcontent, trim_xspace(sTmpBuf));
                g_iOrder++;                
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;

                strcpy(g_sNcontent, "C");
                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;  

                lEdrItemCount++;
            }
            else
            {
                /* *** Block endorse_item *** */
                strncpy(sTmpBuf1, sTmpBuf, p - sTmpBuf);
                sTmpBuf1[p - sTmpBuf] = '\0';
                /*insert_tmp_table(iPg, EDR_BASE_LINE + lEdrItemCount, 1, sTmpBuf1);*/
                
                strcpy(g_sNcontent, "EDRNOTE");
                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;                   

                strcpy(g_sNcontent, trim_xspace(sTmpBuf1));
                g_iOrder++;
                printf("{ca401_data3_xxx2 } g_sNcontent[%s]\n", g_sNcontent);
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;                

                strcpy(g_sNcontent, "C");
                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;  

                lEdrItemCount++;

                if (lEdrItemCount >= 7) /* 861226-mag, ���@���̦h�L7�� */
                {
                    lEdrItemCount = 0;
                    iPg++;
                    printf("-----------------------> data3() iPg[%d]\n", iPg);
                }

                /*insert_tmp_table(iPg, EDR_BASE_LINE + lEdrItemCount, 1, p + 1);*/

                strcpy(g_sNcontent, "EDRNOTE");
                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;                   

                strcpy(g_sNcontent, p + 1);  strcpy(g_sNcontent,trim_xspace(g_sNcontent));
                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;                

                strcpy(g_sNcontent, "C");
                g_iOrder++;
                $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;  

                lEdrItemCount++;
            }
        }

        { /* *** Temporary block for free memory  - tony96.860825 - *** */
            short ii;
            for (ii = 0; ii < j; ii++)
            {
                free(g_pEedr_item[ii]);
                free(g_pData[ii]);
            }
        }
    } /* end of for */


    /*--------------------------------------------------------------------------------*/

    $char sIedrType[7];
    $long lQday, lEdrQday;
    $char sQday[5], sEdrQday[5], sTmp[31];
    $char sPrnDeduct[20], sEdrPrnDeduct[20];
    $char sPrn29Cover[101], sPrnProv[81],sNequipment[31];
    $int  iFlagProv1 = 0, iFlagProv2 = 0, iFlagProv3 = 0;
    int Flag29Edr;
    int Flag29EdrType02;
    $char note1[81],note2[81],note3[81];

    
    note1[0] = '\0';    note2[0] = '\0';    note3[0] = '\0';
    
    stmt_buf[0] = '\0';
    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s WHERE %s ",
            "note1, note2, note3 ",
            sFullDBName, "endorsement_note ",
            " iendorse = ? ");
    $PREPARE cur_B FROM $stmt_buf;
    printf("%s\n", stmt_buf);
    $EXECUTE cur_B INTO $note1, $note2, $note3 USING $p_sIendorse;    
    $FREE cur_B;
    

    /* �W�B�d���I��h�ĤT�H�d���I�O�I���B */
    lEdrQday  = 0;  Flag29Edr = 1;  Flag29EdrType02 = 0;
    strcpy(sIins_type," ");
    stmt_buf[0] = '\0';
    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s a, %s:%s b WHERE %s %s ",
            " iedr_type,abs(a.qday),a.iins_type ",
            sFullDBName, "edr_ins_type ",
            sFullDBName, "ply_ins_type ",
            " a.iendorse = ? ",
            " AND a.iins_type in ('29','124') AND a.iins_type = b.iins_type AND b.ipolicy = ? AND b.mdamage_cover <> 0");
    $PREPARE cur_H FROM $stmt_buf;
    $EXECUTE cur_H INTO $sIedrType, $lEdrQday, $sIins_type USING $p_sIendorse, $g_sIpolicy;
    if (SQLCODE == SQLNOTFOUND)
    {        
        Flag29Edr = 0;       
        printf("--trace not found\n");        
    }
    $FREE cur_H;

    printf("lEdrQday[%ld]\n", lEdrQday);

    if ((strcmp(trim(sIedrType), "01") == 0) ||
        (strcmp(trim(sIedrType), "02") == 0) ||
        (strcmp(trim(sIedrType), "03") == 0) ||
        (strcmp(trim(sIedrType), "60") == 0))
    {
        lEdrQday = 0;
        Flag29EdrType02 = 1;
    }
    strcpy(sEdrQday, ltoa(lEdrQday));

    stmt_buf[0] = '\0';
    lQday = 0;
    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s WHERE %s %s ",
            " qday ",
            sFullDBName, "ply_ins_type_bak ",
            " iendorse = ? ",
            " AND iins_type = ? ");
    $PREPARE cur_I FROM $stmt_buf;
    $EXECUTE cur_I INTO $lQday USING $p_sIendorse, $sIins_type;        
    $FREE cur_I;
    strcpy(sQday, ltoa(lQday));
    printf("lQday[%ld], iins_type[%s]\n", lQday, sIins_type);

    sPrn29Cover[0] = '\0';
    printf("Flag29Edr[%d],Flag29EdrType02[%d]\n", Flag29Edr, Flag29EdrType02);
    if ((lEdrQday != lQday) && (Flag29Edr == 1) && (Flag29EdrType02 != 1))
    {
        if (lEdrQday != 0)
        {
            $SELECT prn_deduct
               INTO :sEdrPrnDeduct
               FROM ca_dmg_mdeduct
              WHERE icar_type = 'I29' AND ideduct = :sEdrQday;
            if (SQLCODE == SQLNOTFOUND)
            {
                strcpy(sEdrPrnDeduct, "0 �U");
            }
            strcpy(sEdrPrnDeduct, trim(sEdrPrnDeduct));
            printf("sPrnEdrDeduct[%s]\n", sEdrPrnDeduct);
        }
        else
        {
            strcpy(sEdrPrnDeduct, "0 �U");
        }

        if (lQday != 0)
        {
            $SELECT prn_deduct
               INTO :sPrnDeduct
               FROM ca_dmg_mdeduct
              WHERE icar_type = 'I29' AND ideduct = :sQday;
            if (SQLCODE == SQLNOTFOUND)
            {
                strcpy(sPrnDeduct, "0 �U");
            }
            strcpy(sPrnDeduct, trim(sPrnDeduct));
            printf("sPrnDeduct[%s]\n", sPrnDeduct);
        }
        else
        {
            strcpy(sPrnDeduct, "0 �U");
        }
        if (strcmp(trim(sIins_type), "29") == 0)
            sprintf_s(sPrn29Cover, sizeof sPrn29Cover, "�W�B�d���I��h�ĤT�H�d���I�O�I���B�� %s ���ܧ� %s ���A�ۥ��� %s �_�ͮ�", sPrnDeduct, sEdrPrnDeduct, g_sDedr_begin);
        else
            sprintf_s(sPrn29Cover, sizeof sPrn29Cover, "��D�ƬG�W�B�O�ٰ�h�ĤT�H�d���I�O�I���B�� %s ���ܧ� %s ���A�ۥ��� %s �_�ͮ�", sPrnDeduct, sEdrPrnDeduct, g_sDedr_begin);
    }
    else
    {
        sPrn29Cover[0] = '\0';
    }
    printf("sEdrQday[%s],sQday[%s]\n", sEdrQday, sQday);
    printf("sPrn29Cover[%s]\n", sPrn29Cover);

    
    /*1070928002_SC2_�s�W�O�I�����ܧ�Τ��~�פ���[����(�N��X)(���)*/
    iFlagProv1 = 0;
    sPrnProv[0] = '\0';
    /* 1081225006_SC3 �X�R���[���ڥN�X */
    sprintf_s(stmt_buf, sizeof stmt_buf,
            "SELECT count(*) FROM %s:edr_ins_type "
            "  WHERE iendorse = '%s' "
            "   AND regex_match(provision,'(;| +|^)X(;| +|$)') "
            "   AND NOT EXISTS(SELECT '1' FROM %s:ply_ins_type_bak "
            "                   WHERE iendorse ='%s' "
            "                     AND regex_match(provision,'(;| +|^)X(;| +|$)') ) ",
            sFullDBName, p_sIendorse, sFullDBName, p_sIendorse);
    printf("-- trace stmt_buf[%s]\n ", stmt_buf);
    $PREPARE pre_provx FROM $stmt_buf;
    $EXECUTE pre_provx INTO $iFlagProv1;
    $FREE pre_provx;
    if (iFlagProv1 > 0)
    {
        sprintf_s(sPrnProv, sizeof sPrnProv, "���O��ۥ��� %s �_��[�u�O�I�����ܧ�Τ��~�פ���[���ڡv", g_sDedr_begin);

        if (strlen(note1) == 0)
        {
            strcpy(note1, rtrim(sPrnProv));
        }
        else if (strlen(note2) == 0)
        {
            strcpy(note2, rtrim(sPrnProv));
        }
        else if (strlen(note3) == 0)
        {
            strcpy(note3, rtrim(sPrnProv));
        }
        else if (strlen(sPrn29Cover) == 0)
        {
            strcpy(sPrn29Cover, rtrim(sPrnProv));
        }
    }

    /*1081105005_SC2 �ק���~���w���ƫ������²v�Φۭt�B*/
    /*1071226006_SC2_ �w���ƫ����վ�(���²v+�ĤT�H�d��)------------*/
    iFlagProv1 = 0;
    iFlagProv2 = 0;
    iFlagProv3 = 0;
    sPrnProv[0] = '\0';
    /* 1081225006_SC3 �X�R���[���ڥN�X */
    sprintf_s(stmt_buf, sizeof stmt_buf,
            " SELECT DISTINCT nvl(decode(regex_match(provision,'(;| +|^)P(;| +|$)'),'t',1,0), 0), "
            "        nvl(decode(regex_match(provision,'(;| +|^)Q(;| +|$)'),'t',1,0), 0), "
            "        nvl(decode(regex_match(provision,'(;| +|^)M(;| +|$)'),'t',1,0), 0)  "
            "   FROM %s:edr_ins_type X "
            "  WHERE iendorse = '%s' "
            "   AND regex_match(provision,'(;| +|^)(P|Q|M)(;| +|$)')  "
            "   AND iins_type IN ('01','05','09','11','181','201','205','209','211') "
            "   AND NOT EXISTS(SELECT '1' FROM %s:ply_ins_type_bak "
            "                   WHERE iendorse ='%s' "
            "                     AND regex_match(provision,'(;| +|^)(P|Q|M)(;| +|$)') "
            "                     AND iins_type = X.iins_type) ",
            sFullDBName, p_sIendorse, sFullDBName, p_sIendorse);

    printf("-- trace stmt_buf[%s]\n ", stmt_buf);
    $PREPARE pre_prov_pq FROM $stmt_buf;
    $EXECUTE pre_prov_pq INTO $iFlagProv1, $iFlagProv2, $iFlagProv3;    
    if (SQLCODE != SQLNOTFOUND)
    {
        if (iFlagProv1 > 0 || iFlagProv2 > 0 || iFlagProv3 > 0)
        {
            if (iFlagProv1 > 0)
                strcpy(sTmp, "A��(P)-���²v15%");
            else if (iFlagProv2 > 0)
                strcpy(sTmp, "B��(Q)-���²v20%");
            else
                strcpy(sTmp, "C��(M)-���²v25%");

            sprintf_s(sPrnProv, sizeof sPrnProv, "���O��ۥ��� %s �_��[�u���w���²v���[����%s�v", g_sDedr_begin, trim(sTmp));


            if (strlen(note1) == 0)
            {
                strcpy(note1, rtrim(sPrnProv));
            }
            else if (strlen(note2) == 0)
            {
                strcpy(note2, rtrim(sPrnProv));
            }
            else if (strlen(note3) == 0)
            {
                strcpy(note3, rtrim(sPrnProv));
            }
            else if (strlen(sPrn29Cover) == 0)
            {
                strcpy(sPrn29Cover, rtrim(sPrnProv));
            }
        }
    }
    $FREE pre_prov_pq;
    iFlagProv1 = 0;
    iFlagProv2 = 0;
    sPrnProv[0] = '\0';
    /* 1081225006_SC3 �X�R���[���ڥN�X */
    sprintf_s(stmt_buf, sizeof stmt_buf,
            " SELECT DISTINCT nvl(CASE WHEN iins_type in ('09','209') then nvl(decode(regex_match(provision,'(;| +|^)V(;| +|$)'),'t',1,0), 0) END,0) , "
            "        nvl(CASE WHEN iins_type IN ('31','32','231','232','531','532') then nvl(decode(regex_match(provision,'(;| +|^)V(;| +|$)'),'t',1,0), 0) END,0) "
            "   FROM %s:edr_ins_type X "
            "  WHERE iendorse = '%s' "
            "   AND regex_match(provision,'(;| +|^)V(;| +|$)') "
            "   AND iins_type IN ('09','31','32','209','231','232','531','532') "
            "   AND NOT EXISTS(SELECT '1' FROM %s:ply_ins_type_bak "
            "                   WHERE iendorse ='%s' "
            "                     AND regex_match(provision,'(;| +|^)V(;| +|$)') "
            "                     AND iins_type = X.iins_type ) ",
            sFullDBName, p_sIendorse, sFullDBName, p_sIendorse);

    printf("-- trace stmt_buf[%s]\n ", stmt_buf);
    $PREPARE pre_prov_pq FROM $stmt_buf;
    $EXECUTE pre_prov_pq INTO $iFlagProv1, $iFlagProv2;
    
    printf("-- trace iFlagProv1[%d]\n ", iFlagProv1);
    printf("-- trace iFlagProv2[%d]\n ", iFlagProv2);
    if (SQLCODE != SQLNOTFOUND)
    {
        if (iFlagProv1 > 0)
        {
            strcpy(sTmp, "�T������l���O�I����");
            sprintf_s(sPrnProv, sizeof sPrnProv, "���O��ۥ��� %s �_��[�u%s�ۭt�B���[���ڡv", g_sDedr_begin, trim(sTmp));

            if (strlen(note1) == 0)
            {
                strcpy(note1, rtrim(sPrnProv));
            }
            else if (strlen(note2) == 0)
            {
                strcpy(note2, rtrim(sPrnProv));
            }
            else if (strlen(note3) == 0)
            {
                strcpy(note3, rtrim(sPrnProv));
            }
            else if (strlen(sPrn29Cover) == 0)
            {
                strcpy(sPrn29Cover, rtrim(sPrnProv));
            }
        }
        if (iFlagProv2 > 0)
        {
            strcpy(sTmp, "�T���ĤT�H�d���O�I");
            sprintf_s(sPrnProv, sizeof sPrnProv, "���O��ۥ��� %s �_��[�u%s�ۭt�B���[���ڡv", g_sDedr_begin, trim(sTmp));

            if (strlen(note1) == 0)
            {
                strcpy(note1, rtrim(sPrnProv));
            }
            else if (strlen(note2) == 0)
            {
                strcpy(note2, rtrim(sPrnProv));
            }
            else if (strlen(note3) == 0)
            {
                strcpy(note3, rtrim(sPrnProv));
            }
            else if (strlen(sPrn29Cover) == 0)
            {
                strcpy(sPrn29Cover, rtrim(sPrnProv));
            }
        }
    }
    $FREE pre_prov_pq;

    /*1080408008_SC2 98�����ഫ�I�ج�09+K���� 
    iFlagProv1 = 0;
    sPrnProv[0] = '\0'; */
    /* 1081225006_SC3 �X�R���[���ڥN�X 
    sprintf_s(stmt_buf, sizeof stmt_buf,
            "SELECT count(*) FROM %s:edr_ins_type "
            "  WHERE iendorse = '%s' "
            "   AND regex_match(provision,'(;| +|^)K(;| +|$)') "
            "   AND NOT EXISTS(SELECT '1' FROM %s:ply_ins_type_bak "
            "                   WHERE iendorse ='%s' "
            "                     AND regex_match(provision,'(;| +|^)K(;| +|$)') ) ",
            sFullDBName, p_sIendorse, sFullDBName, p_sIendorse);

    printf("-- trace stmt_buf[%s]\n ", stmt_buf);
    $PREPARE pre_provx FROM $stmt_buf;
    $EXECUTE pre_provx INTO $iFlagProv1;
    $FREE pre_provx;
    if (iFlagProv1 > 0)
    {
        sprintf_s(sPrnProv, sizeof sPrnProv, "���O��ۥ��� %s �_��[�u�������B���[���ڡv", g_sDedr_begin);

        if (strlen(note1) == 0)
        {
            strcpy(note1, rtrim(sPrnProv));
        }
        else if (strlen(note2) == 0)
        {
            strcpy(note2, rtrim(sPrnProv));
        }
        else if (strlen(note3) == 0)
        {
            strcpy(note3, rtrim(sPrnProv));
        }
        else if (strlen(sPrn29Cover) == 0)
        {
            strcpy(sPrn29Cover, rtrim(sPrnProv));
        }
    }
    */

    /*1080708002_SC2 �s�W�����������(�N��L),�P�ɸɤW R����*/
    iFlagProv1 = 0;
    sPrnProv[0] = '\0';
    /* 1081225006_SC3 �X�R���[���ڥN�X */
    sprintf_s(stmt_buf, sizeof stmt_buf,
            "SELECT count(*) FROM %s:edr_ins_type "
            "  WHERE iendorse = '%s' "
            "   AND regex_match(provision,'(;| +|^)L(;| +|$)') "
            "   AND NOT EXISTS(SELECT '1' FROM %s:ply_ins_type_bak "
            "                   WHERE iendorse ='%s' "
            "                     AND regex_match(provision,'(;| +|^)L(;| +|$)') ) ",
            sFullDBName, p_sIendorse, sFullDBName, p_sIendorse);

    printf("-- trace stmt_buf[%s]\n ", stmt_buf);
    $PREPARE pre_provL FROM $stmt_buf;
    $EXECUTE pre_provL INTO $iFlagProv1;
    $FREE pre_provL;
    if (iFlagProv1 > 0)
    {
        sprintf_s(sPrnProv, sizeof sPrnProv, "���O��ۥ��� %s �_��[�u������~�γ~���[���ڡv", g_sDedr_begin);

        if (strlen(note1) == 0)
        {
            strcpy(note1, rtrim(sPrnProv));
        }
        else if (strlen(note2) == 0)
        {
            strcpy(note2, rtrim(sPrnProv));
        }
        else if (strlen(note3) == 0)
        {
            strcpy(note3, rtrim(sPrnProv));
        }
        else if (strlen(sPrn29Cover) == 0)
        {
            strcpy(sPrn29Cover, rtrim(sPrnProv));
        }
    }

    iFlagProv1 = 0;
    sPrnProv[0] = '\0';

    /* 1081225006_SC3 �X�R���[���ڥN�X */
    sprintf_s(stmt_buf, sizeof stmt_buf,
            "SELECT count(*) FROM %s:edr_ins_type "
            "  WHERE iendorse = '%s' "
            "   AND regex_match(provision,'(;| +|^)R(;| +|$)') "
            "   AND NOT EXISTS(SELECT '1' FROM %s:ply_ins_type_bak "
            "                   WHERE iendorse ='%s' "
            "                     AND regex_match(provision,'(;| +|^)R(;| +|$)') ) ",
            sFullDBName, p_sIendorse, sFullDBName, p_sIendorse);

    printf("-- trace stmt_buf[%s]\n ", stmt_buf);
    $PREPARE pre_provR FROM $stmt_buf;
    $EXECUTE pre_provR INTO $iFlagProv1;
    $FREE pre_provR;
    if (iFlagProv1 > 0)
    {
        sprintf_s(sPrnProv, sizeof sPrnProv, "���O��ۥ��� %s �_��[�u��������������w�ϥΪ��[���ڡv", g_sDedr_begin);

        if (strlen(note1) == 0)
        {
            strcpy(note1, rtrim(sPrnProv));
        }
        else if (strlen(note2) == 0)
        {
            strcpy(note2, rtrim(sPrnProv));
        }
        else if (strlen(note3) == 0)
        {
            strcpy(note3, rtrim(sPrnProv));
        }
        else if (strlen(sPrn29Cover) == 0)
        {
            strcpy(sPrn29Cover, rtrim(sPrnProv));
        }
    }

    /*1120316006_SC2 ���N�I���e�{�s�W�u���@���v�����������O�N��05�ή��s�X��t�ηs�W���@�����O
      ��115���O�B���ӫO�i�����I�j�A�B ���ݫO�椧ñ��� �� �u���@���v�W�u��ɡA���W���[��ĵ�y
    */
    stmt_buf[0] = '\0';
    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s WHERE %s",
            " nequipment ",
            sFullDBName, " endorsement ",
            " iendorse = ? ");
    $PREPARE cur_C FROM $stmt_buf;
    printf("%s\n", stmt_buf);
    $EXECUTE cur_C INTO $sNequipment USING $p_sIendorse;    
    $FREE cur_C;
    printf("--trace sNequipment=[%s]\n",sNequipment);   
    
    if (equip_cmp(sNequipment,"115") == TRUE)
    {
        printf("--trace 115\n");  
        /*��榳�[�O�����I*/
        stmt_buf[0] = '\0'; iFlagProv1 = 0;
        sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT count(*) FROM %s:edr_ins_type WHERE %s %s ",
                sFullDBName,   
                " iendorse = ? ",
                " AND iins_type in ('55') AND iedr_type in ('05') ");
        printf("-- trace stmt_buf[%s]\n ", stmt_buf);        
        $PREPARE cur_115 FROM $stmt_buf;
        $EXECUTE cur_115 INTO $iFlagProv1 USING $p_sIendorse;

        if (iFlagProv1==0) 
        {
            /*�L��B���ӫO�����I*/
            printf("--trace 55,255 not found\n");        

            stmt_buf[0] = '\0'; iFlagProv1 = 0;
            sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT count(*) FROM %s:edr_relation a,%s:ply_ins_type_bak b WHERE a.iendorse = b.iendorse %s %s ",
                    sFullDBName, sFullDBName,  
                    " AND a.fedr_class ='8' AND a.iendorse = ? ",
                    " AND b.iins_type in ('55') AND b.mdamage_cover > 0");
            printf("-- trace stmt_buf[%s]\n ", stmt_buf);        
            $PREPARE cur_115_1 FROM $stmt_buf;
            $EXECUTE cur_115_1 INTO $iFlagProv1 USING $p_sIendorse;            
            if (iFlagProv1==0)           
            {
                printf("--trace ply_ins_type_bak 55,255 not found\n");    
            }
            $FREE cur_115_1;         
            
        }
        $FREE cur_115;

        printf("--trace ���@�� iFlagProv1=[%d]\n",iFlagProv1);
        

        /*if ((iFlagProv1>0) && (lDpolicy>= cm_ymd_cdate("112/05/15")))*/
        if (iFlagProv1>0)
        {
            strcpy(sPrnProv, "�����I�ӫO�d�򤣧t�˱w");

            if (strlen(note1) == 0)
            {
                strcpy(note1, rtrim(sPrnProv));
            }
            else if (strlen(note2) == 0)
            {
                strcpy(note2, rtrim(sPrnProv));
            }
            else if (strlen(note3) == 0)
            {
                strcpy(note3, rtrim(sPrnProv));
            }
            else if (strlen(sPrn29Cover) == 0)
            {
                strcpy(sPrn29Cover, rtrim(sPrnProv));
            }
        }
    }

    /*1130827011_C01 �s�W�s�t��W�B���[����(Y)�A�Щ�1101�W�u*/
    /* 1120606010_C01 �s�W���������ӫ~���[���� => 1120724 ����մ����q���M�P���@�~*/    
    iFlagProv1 = 0;   sPrnProv[0] = '\0';    
    sprintf_s(stmt_buf, sizeof stmt_buf,
            "SELECT count(*) FROM %s:edr_ins_type X "
            " WHERE iendorse = '%s' "
            "   AND regex_match(provision,'(;| +|^)Y(;| +|$)') "
            "   AND iins_type IN ('01','05','09','201','205','209','198') "
            "   AND NOT EXISTS(SELECT '1' FROM %s:ply_ins_type_bak "
            "                   WHERE iendorse ='%s' "
            "                     AND regex_match(provision,'(;| +|^)Y(;| +|$)') "
            "                     AND iins_type = X.iins_type) ",
            sFullDBName, p_sIendorse, sFullDBName, p_sIendorse);

    printf("-- trace Y stmt_buf[%s]\n ", stmt_buf);
    $PREPARE pre_prov_Y FROM $stmt_buf;
    $EXECUTE pre_prov_Y INTO $iFlagProv1;
    $FREE pre_prov_Y;
    printf("--trace Y iFlagProv1=[%d]\n",iFlagProv1);
    
    if (iFlagProv1 > 0)
    {
        sprintf_s(sPrnProv, sizeof sPrnProv, "���O��ۥ��� %s �_��[�u�s�t��W�B���[���ڡv", g_sDedr_begin);

        if (strlen(note1) == 0)
        {
            strcpy(note1, rtrim(sPrnProv));
        }
        else if (strlen(note2) == 0)
        {
            strcpy(note2, rtrim(sPrnProv));
        }
        else if (strlen(note3) == 0)
        {
            strcpy(note3, rtrim(sPrnProv));
        }
        else if (strlen(sPrn29Cover) == 0)
        {
            strcpy(sPrn29Cover, rtrim(sPrnProv));
        }
    }

    /*--------------------------------------------------------------------------*/
    printf("-- trace sPrn29Cover[%s]\n ", sPrn29Cover);
    printf("-- trace note1[%s]\n ", note1);
    printf("-- trace note2[%s]\n ", note2);
    printf("-- trace note3[%s]\n ", note3);

    /*****  �Ƶ���� peter 89.11.23 *****/
    /*     
    insert_tmp_table(iPg, 32, 1, note1);
    insert_tmp_table(iPg, 32, 2, note2);
    insert_tmp_table(iPg, 32, 3, note3);
    */
    if (strlen(note1)>0)
    {
        strcpy(g_sNcontent, "EDRNOTE");
        g_iOrder++;
        $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;
    
    
        strcpy(g_sNcontent, note1);  strcpy(g_sNcontent,trim_xspace(g_sNcontent));
        g_iOrder++;
        $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent; 

        strcpy(g_sNcontent, "C");
        g_iOrder++;
        $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;  
    }

    if (strlen(note2)>0)
    {
        strcpy(g_sNcontent, "EDRNOTE");
        g_iOrder++;
        $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;                   
        
        strcpy(g_sNcontent, note2);  strcpy(g_sNcontent,trim_xspace(g_sNcontent));
        g_iOrder++;
        $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent; 
        
        strcpy(g_sNcontent, "C");
        g_iOrder++;
        $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent; 
    }

    if (strlen(note3)>0)
    {
        strcpy(g_sNcontent, "EDRNOTE");
        g_iOrder++;
        $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;                   
        
        strcpy(g_sNcontent, note3);  strcpy(g_sNcontent,trim_xspace(g_sNcontent));
        g_iOrder++;
        $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent; 
        
        strcpy(g_sNcontent, "C");
        g_iOrder++;
        $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent; 
    }

   

    if (strlen(trim(sPrn29Cover)) < 5) /* sPrn29Cover �������󦳤@��"����r�ýX"�A���βM���覡 */
    {
       strcpy(sPrn29Cover,"");    
    }    
    /*insert_tmp_table(iPg, 32, 4, sPrn29Cover);  */

    if (strlen(sPrn29Cover)>0)
    {
        strcpy(g_sNcontent, "EDRNOTE");
        g_iOrder++;
        $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;                   
        
        strcpy(g_sNcontent, sPrn29Cover);  strcpy(g_sNcontent,trim_xspace(g_sNcontent));
        g_iOrder++;
        $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;    
        
        strcpy(g_sNcontent, "C");
        g_iOrder++;
        $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent; 
    }
    /*
    if (strlen(sPrnProv)>0)
    {
        strcpy(g_sNcontent, "EDRNOTE");
        g_iOrder++;
        $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;                   
        
        strcpy(g_sNcontent, sPrnProv);  strcpy(g_sNcontent,trim_xspace(g_sNcontent));
        g_iOrder++;
        $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;    
        
        strcpy(g_sNcontent, "C");
        g_iOrder++;
        $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent; 
    } 
    */


    /******  �û���b�̫�@�ӧ�� **********/
    strcpy(g_sNcontent, "EDRNOTE");
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;                   
    
    strcpy(g_sNcontent, "�S���[��");
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent;    
    
    strcpy(g_sNcontent, "C");
    g_iOrder++;
    $EXECUTE preInsertTmp USING $g_iOrder, $g_sNcontent; 
    /******  �û���b�̫�@�ӧ�� **********/

    printf(" $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ \n");

    /*---------   ��X EDRNOTE �̫�@�� 'C'�A�� Update �� 'Q'   ---------*/
 
    iCount = 0; 
    sprintf_s(sTmt, sizeof sTmt, "SELECT nvl(max(iline),0) FROM tmp%s "
                     " WHERE kpid     = '%s'  "
                     "   AND inumber  = '%s'  "
                     "   AND ncontent = 'EDRNOTE'", g_sFile, g_kpid , g_sIendorse );

    printf("--trace preEdrNote sTmt =[%s]\n",sTmt);                        
    $PREPARE preEdrNote FROM $sTmt;  
    $EXECUTE preEdrNote INTO $iCount; 
    $FREE    preEdrNote;                        
     printf("--trace iCount =[%d]\n", iCount);

    if (iCount>0) /* �� EDRNOTE �� */
    {
        iline_last = 0; 
        sprintf_s(sTmt, sizeof sTmt, "SELECT iline FROM tmp%s   "
                          " WHERE kpid     = '%s'  "
                          "  AND inumber  = '%s'  "
                          "  AND ncontent = 'C'   "
                          "  AND iline    > %ld ", g_sFile, g_kpid , g_sIendorse, iCount );
        printf("--trace preLine sTmt =[%s]\n",sTmt);    
        $PREPARE preLine FROM $sTmt;  
        $EXECUTE preLine INTO $iline_last; 
        $FREE    preLine;
        printf("--trace iline_last =[%d]\n", iline_last);

        if (iline_last > 0)
        {
            sprintf_s(sTmt, sizeof sTmt, "UPDATE tmp%s SET ncontent = 'Q' "
                            " WHERE kpid = '%s' AND inumber = '%s' AND iline = %ld ", 
                    g_sFile, g_kpid, g_sIendorse, iline_last);
            printf("--trace UPDATE tmp sTmt =[%s]\n",sTmt);            
            $EXECUTE immediate $sTmt; 
        }
    }


    /*------------------------------------------------------------*/       
    return M_CM_OK;

errexit:
    printf("{ca401_data3_free}: SQLCODE=[%d] sqlerrm=[%s] sqlca.sqlerrd[1]=[%d]\n", SQLCODE, sqlca.sqlerrm, sqlca.sqlerrd[1]);
    return SQLCODE;
} /* ca401_data3_free */



/* ************************************************************************
 * Function: ca401_data1
 *
 * Description:
 *   �C�L�O���򥻸��.
 *
 * ************************************************************************/
$char fcar_class[2], sIcar_type_ori[3];

long ca401_data1(p_sIendorse, p_fmask)
$char *p_sIendorse;
char *p_fmask;
{
    /* ------------------------ edr_relation ----------------------------- */
    $char sIpolicy[POLICY_NUM_1], sIcard[CARD_NUM], sIrelative_ply[POLICY_NUM_1];
    $char sFedr_class[2];
    $char sFpay[2], sIpay[20], sIedr_field[9], sIofficer[16];
    $char sIedr_cashier[14], sIbroker[BROKER], sDendorse[11];
    $char sDedr_begin[11], sDedr_end[11];
    $long lMedrdmg_prem, lMedrlia_prem;
    $char sFcard_class[2], sIbranch[4], sIbranch12[3];
    $long lDedr_begin;
    $char cDedr_begin[11];
    /* --------------------------------------------------------------------- */

    /* ------------------------ edr_relation ----------------------------- */
    $char sDvp_code[3], sDvp_abbr[11], sIbranch_abbr[2];
    $char sNbranch[41], sNpresident[41], sNtitle[21], sIedr_examiner[11];
    /* --------------------------------------------------------------------- */

    /* -------------------------- policy_bak ------------------------------- */
    $char sNassured[ASSURED_NAME], sNbenef[43], sAassured[92];
    $char sIassured[13], sIlicense[11];
    $char sIbirth[11], sAassured_zip[CA_ZIP], sFassured[2];
    $char sFsex[2], sFmarriage[2], sItel[21], sIissue_ym[7], sIpro_year[5];
    $char sIcar_type[3];
    /*$long   lQcylinder;*/
    $char sIengine[CA_ENGINE_NUM], sIbody[CA_BODY_NUM], sItag[CA_TAG_NUM], sIbrand[9];
    $double dblPdmg_align, dblPbrg_align, dblPlia_align, dblQpt;
    $char sFpt[2];
    $double dblPsex_age, dblPlia_acc, dblPdmg_acc, psex_age_damage, dblQcylinder;
    $char sNbrand_abbr[20], sNcar_abbr[20];
    /* --------------------------------------------------------------------- */

    /* ------------------------- endorsement ------------------------------- */
    $char sNuser[19],sNequipment[31];
    /* --------------------------------------------------------------------- */

    /********** endorsement_note ***********/
    $char note1[81], note2[81], note3[81];
    /***************************************/

    $char sYEdrBgn[4], sMEdrBgn[3], sDEdrBgn[3];
    $char sYEdrEnd[4], sMEdrEnd[3], sDEdrEnd[3];
    char birthyy[4], birthmm[3], birthdd[3];
    $char sIissue_year[4], sIissue_month[3];
    $char sTmpBuf[254], sTmpBuf1[80], sTaxName[11], sTaxArea[11];
    $int check_910401 = 0, iFlagProv1 = 0, iFlagProv2 = 0, iFlagProv3 = 0;
    $long lDpolicy;

    int iPg, i;

    /* �W�B�d���I��h�ĤT�H�d���I�O�I���B */
    $char sIedrType[7];
    $long lQday, lEdrQday;
    $char sQday[5], sEdrQday[5];
    $char sPrnDeduct[20], sEdrPrnDeduct[20];
    $char sPrn29Cover[101], sIins_type[INSURANCE_TYPE], sPrnProv[81];
    int Flag29Edr;
    int Flag29EdrType02;
    int x;
    $char sDrate_ym[5], sTmp[31];

    /*-------------------------------------------------*/
    $char ply_8;
    $char sIpolicy_a[21], ply1[4], ply2[11];
    /*-------------------------------------------------*/

    $char stmt_buf[8000];

    $WHENEVER SQLERROR GOTO errexit;

    printf("$$$$$$$$$$$$ into ca401_data1()\n");

    iPg = 1;

    stmt_buf[0] = '\0';
    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s %s %s %s %s FROM %s:%s %s:%s WHERE %s %s ",
            "a.ipolicy, a.icard, a.irelative_ply, a.fedr_class, a.fpay, a.ipay,",
            "a.iedr_field, a.dedr_begin, a.dedr_end, a.iofficer, a.iedr_cashier,",
            "a.ibroker, case when a.iendorse like '%CVP%' then null when a.dendorse is null then today else a.dendorse end, ",
            "a.medrdmg_prem, a.medrlia_prem, a.fcard_class,",
            "a.medrdmg_disc, a.medrlia_disc, b.dpolicy, a.dedr_begin,a.iedr_examiner ",
            sFullDBName, "edr_relation a ,",
            sFullDBName, "ply_relation b  ",
            " a.iendorse = ? ",
            " AND a.ipolicy = b.ipolicy ");

    $PREPARE cur_A FROM $stmt_buf;
    printf("%s\n", stmt_buf);
    $EXECUTE cur_A INTO $sIpolicy, $sIcard, $sIrelative_ply, $sFedr_class, $sFpay, $sIpay,
        $sIedr_field, $sDedr_begin, $sDedr_end, $sIofficer, $sIedr_cashier,
        $sIbroker, $sDendorse, $lMedrdmg_prem, $lMedrlia_prem, $sFcard_class,
        $lMedrdmg_disc, $lMedrlia_disc, $lDpolicy, $lDedr_begin, $sIedr_examiner USING $p_sIendorse;       

    /* julia */
    for (x = 0; x < 8; x++)
    {
        printf("===================print 77777777777777[%X]\n", sIedr_field[x]);
    }

    if (SQLCODE == SQLNOTFOUND)
    {
        $FREE cur_A; 
        return M_CA_NREL_EDR;
    }
    $FREE cur_A; 
    strcpy(g_sIofficer, trim(sIofficer));

    if (lDpolicy >= cm_ymd_cdate("91/04/01")) /* ��91�~04��01��(�t)����ñ�o���O�I�� */
    {
        check_910401 = 0;
    }
    else /* lDpolicy < cm_ymd_cdate("91/04/01") */
    {
        check_910401 = 1;
    }

    note1[0] = '\0';
    note2[0] = '\0';
    note3[0] = '\0';

    stmt_buf[0] = '\0';

    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s WHERE %s ",
            "note1, note2, note3 ",
            sFullDBName, "endorsement_note ",
            " iendorse = ? ");
    $PREPARE cur_B FROM $stmt_buf;
    printf("%s\n", stmt_buf);
    $EXECUTE cur_B INTO $note1, $note2, $note3 USING $p_sIendorse;
    
    if (SQLCODE == SQLNOTFOUND)
    {
        note1[0] = '\0';
        note2[0] = '\0';
        note3[0] = '\0';
    }
    $FREE cur_B;

    printf("endorsement_note===> note1[%s],note2[%s],note3[%s]!!\n", note1, note2, note3);
    printf("{ca401_data1.0010}:policy[%s],icard[%s],relative_ply[%s],pay[%s],officer[%s],edr_cashier[%s],broker[%s]\n", sIpolicy, sIcard, sIrelative_ply, sIpay, sIofficer, sIedr_cashier, sIbroker);

    strcpy(sIpolicy, rtrim(sIpolicy));
    strcpy(sIcard, rtrim(sIcard));
    strcpy(sIrelative_ply, rtrim(sIrelative_ply));
    strcpy(sIpay, rtrim(sIpay));
    strcpy(sIofficer, rtrim(sIofficer));
    strcpy(sIedr_cashier, rtrim(sIedr_cashier));
    strcpy(sIbroker, rtrim(sIbroker));
    strcpy(cDedr_begin, cm_cdate_str_100(lDedr_begin));

    printf("{ca401_data1.0020}: medrdmg_prem[%d],medrlia_prem[%d]\n", lMedrdmg_prem, lMedrlia_prem);

    g_lMedrdmg_prem = lMedrdmg_prem;
    g_lMedrlia_prem = lMedrlia_prem;

    printf("{ca401_data1.0030}: dendorse[%s],fedr_class[%s]\n", sDendorse, sFedr_class);

    strcpy(g_sDendorse, sDendorse);
    strcpy(g_sFedr_class, sFedr_class);
    strcpy(g_sIedr_field, sIedr_field);

    g_lMprem_total = lMedrdmg_prem + lMedrlia_prem;
    lMedr_total = lMedrdmg_disc + lMedrlia_disc;
    printf("lMedr_total------>[%d]\n", lMedr_total);

    if (check_910401 == 0) /** �s�O�v�p��O�O�ɤw�������� **/
    {
        lMedr_sum = g_lMprem_total;
    }
    else
    {
        lMedr_sum = g_lMprem_total - lMedr_total;
    }

    if (strncmp(sFcard_class, "1", 1) == 0)
    {
        sprintf_s(sTmpBuf, sizeof sTmpBuf, "�O�I�Ҹ��G%s%s", companyid, sIcard);
        insert_tmp_table(iPg, 1, 1, sTmpBuf);
    }
    else
        insert_tmp_table(iPg, 1, 1, " ");

    strncpy(sIbranch, sIpolicy, 3);
    sIbranch[3] = '\0';
    strncpy(sIbranch12, sIpolicy, 2);
    sIbranch12[2] = '\0';

    ply_8 = sIpolicy[7];
    if (ply_8 > 65)
    {
        $select ipolicy_a
            into $sIpolicy_a
                from conv_ipolicy
                    where ipolicy_n = $sIpolicy;

        /* *** �O��e�T�X(���) *** */
        strncpy(ply1, sIpolicy_a, 3);
        ply1[3] = '\0';
        sprintf_s(sTmpBuf, sizeof sTmpBuf, "%s%s", "16", ply1);
        insert_tmp_table(iPg, 1, 2, sTmpBuf);

        strncpy(sTmpBuf, &sIpolicy_a[3], 10);
        sTmpBuf[10] = '\0';
        insert_tmp_table(iPg, 1, 3, sTmpBuf); /* peter 12.10 */
    }
    else
    {
        /* *** �O��e�T�X(���) *** */
        sprintf_s(sTmpBuf, sizeof sTmpBuf, "%s%s", companyid, sIbranch);
        insert_tmp_table(iPg, 1, 2, sTmpBuf);

        /* *** �O��(�~��,�r�y,�Ǹ�) *** */
        if (strlen(sIpolicy) >= CAR_POLICY_LEN)
        {
            strncpy(sTmpBuf, sIpolicy, CAR_POLICY_LEN);
            sTmpBuf[CAR_POLICY_LEN] = '\0';
            strcpy(sTmpBuf1, sIpolicy + CAR_POLICY_LEN);
        }
        else
        {
            strcpy(sTmpBuf, sIpolicy);
            sTmpBuf[CAR_POLICY_LEN] = '\0';
            strcpy(sTmpBuf1, "");
        }
        insert_tmp_table(iPg, 1, 3, sTmpBuf + 3); /* peter 12.10 */
    }

    /* *** ���e��X(���), �P�O����ۦP *** */
    sprintf_s(sTmpBuf, sizeof sTmpBuf, "%s%s", companyid, sIbranch);
    insert_tmp_table(iPg, 1, 4, sTmpBuf); /* peter 12.10 */

    /* *** ���(�~��,�r�y,�Ǹ�) *** */
    insert_tmp_table(iPg, 1, 5, p_sIendorse + 3); /*peter 12.10*/

    /* *** ���ͮĩl��(�~,��,��) *** */
    cm_split_ymd_100(cm_from_infdate_100(sDedr_begin), sYEdrBgn, sMEdrBgn, sDEdrBgn);
    insert_tmp_table(iPg, 3, 1, sYEdrBgn);
    insert_tmp_table(iPg, 3, 2, sMEdrBgn);
    insert_tmp_table(iPg, 3, 3, sDEdrBgn);

    /* *** ���ͮĲ״�(�~,��,��) *** */
    cm_split_ymd_100(cm_from_infdate_100(sDedr_end), sYEdrEnd, sMEdrEnd, sDEdrEnd);
    insert_tmp_table(iPg, 3, 4, sYEdrEnd);
    insert_tmp_table(iPg, 3, 5, sMEdrEnd);
    insert_tmp_table(iPg, 3, 6, sDEdrEnd);
    insert_tmp_table(iPg, 3, 7, sIofficer);
    insert_tmp_table(iPg, 34, 5, sIofficer);            /*** �C�L�ӿ�H ***/
    insert_tmp_table(iPg, 34, 6, trim(sIedr_examiner)); /*** �C�L���H��,1101115002_SC1 ���W�s�W�C�L���H�� (���s) ***/

    /* *** ??? nassured, nbenef selected by policy_bak *** */
    stmt_buf[0] = '\0';
    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s WHERE %s",
            " nassured, nuser, nbenef, nequipment ",
            sFullDBName, " endorsement ",
            " iendorse = ? ");
    $PREPARE cur_C FROM $stmt_buf;
    printf("%s\n", stmt_buf);
    $EXECUTE cur_C INTO $sNassured, $sNuser, $sNbenef, $sNequipment USING $p_sIendorse;    

    if (SQLCODE == SQLNOTFOUND)
    {
        $FREE cur_C;
        return M_CA_NENDORSE;
    }
    $FREE cur_C;
#ifdef _M860718
    printf("{ca401_data1.0040}: sNassured[%s],sNuser[%s],sNbenef[%s]\n", sNassured, sNuser, sNbenef);
#endif

    strcpy(g_sNassured, rtrim(sNassured));
    strcpy(g_sNuser, rtrim(sNuser));
    strcpy(g_sNbenef, rtrim(sNbenef));
    strcpy(sNuser, rtrim(sNuser));

    /* $sIissue_ym, $sIpro_year, $sIcar_type */

    printf("{ca401_data1.0041}:before select policy_bak\n");
    stmt_buf[0] = '\0';
    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s %s %s %s %s %s %s %s %s FROM %s:%s WHERE %s ",
            "nassured, nbenef, aassured_zip, aassured, iassured,",
            "ilicense, ",
            "to_char(dbirth,'%Y')::integer - 1911 || '/' || to_char(dbirth,'%m')|| '/' || to_char(dbirth,'%d'),",
            "fsex, fassured,",
            "fmarriage, itel, qcylinder, iengine, ibody,",
            "itag, pdmg_align, pbrg_align, plia_align,",
            "qpt, fpt, psex_age, psex_age_damage, plia_acc, pdmg_acc,",
            "nbrand_abbr,ncar_abbr, ",
            "to_char(dissue,'%Y')::integer - 1911, to_char(dissue,'%m')",
            sFullDBName, "policy_bak ",
            " iendorse = ? ");

    printf("%s\n", stmt_buf);
    $PREPARE cur_D FROM $stmt_buf;
    $EXECUTE cur_D INTO $sNassured, $sNbenef, $sAassured_zip, $sAassured,
        $sIassured, $sIlicense, $sIbirth, $sFsex, $sFassured,
        $sFmarriage, $sItel, $dblQcylinder, $sIengine, $sIbody,
        $sItag, $dblPdmg_align, $dblPbrg_align, $dblPlia_align,
        $dblQpt, $sFpt, $dblPsex_age, $psex_age_damage, $dblPlia_acc, $dblPdmg_acc,
        $sNbrand_abbr, $sNcar_abbr, $sIissue_year, $sIissue_month
    USING $p_sIendorse;
    
    printf("SQLCODE[%d]\n", SQLCODE);
    if (SQLCODE == SQLNOTFOUND)
    {        
        printf("{ca401_data1.0041}:select policy_bak not found!!\n");
        printf("{ca401_data1.0041}:select original_ply !!\n");

        stmt_buf[0] = '\0';
        sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s %s %s %s %s %s %s %s %s FROM %s:%s WHERE %s ",
                " nassured, nbenef, aassured_zip, aassured, iassured,",
                " ilicense, ",
                "to_char(dbirth,'%Y')::integer - 1911 || '/' || to_char(dbirth,'%m')|| '/' || to_char(dbirth,'%d'),",
                " fsex, fassured,",
                " fmarriage, itel, qcylinder, iengine, ibody,",
                " itag, pdmg_align, pbrg_align, plia_align,",
                " qpt, fpt, psex_age, psex_age_damage, plia_acc, pdmg_acc,",
                " nbrand_abbr, ",
                " to_char(dissue,'%Y')::integer - 1911 , to_char(dissue,'%m')",
                sFullDBName, "original_ply ",
                " ipolicy=(SELECT ipolicy FROM edr_relation WHERE iendorse= ? )");

        $PREPARE cur_E FROM $stmt_buf;
        printf("%s\n", stmt_buf);
        $EXECUTE cur_E INTO $sNassured, $sNbenef, $sAassured_zip, $sAassured,
            $sIassured, $sIlicense, $sIbirth, $sFsex, $sFassured,
            $sFmarriage, $sItel, $dblQcylinder, $sIengine, $sIbody,
            $sItag, $dblPdmg_align, $dblPbrg_align, $dblPlia_align,
            $dblQpt, $sFpt, $dblPsex_age, $psex_age_damage, $dblPlia_acc, $dblPdmg_acc,
            $sNbrand_abbr, $sIissue_year, $sIissue_month
        USING $p_sIendorse;
        
        if (SQLCODE == SQLNOTFOUND)
        {
            $FREE cur_E;
            return M_CA_NENDORSE;
        }
        $FREE cur_E;
    }
    $FREE cur_D;

    printf("{ca401_data1.0041}:before select ply_relation_bak\n");
    stmt_buf[0] = '\0';
    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s, %s:%s WHERE %s ",
            "a.ipro_year, a.ibrand, a.icar_type, min(b.drate_ym) ",
            sFullDBName, "ply_relation_bak a ",
            sFullDBName, "ply_ins_type_bak b ",
            " a.iendorse = ? AND a.iendorse = b.iendorse GROUP BY a.ipro_year, a.ibrand, a.icar_type");
    $PREPARE cur_F FROM $stmt_buf;
    printf("%s\n", stmt_buf);
    $EXECUTE cur_F INTO $sIpro_year, $sIbrand, $sIcar_type, $sDrate_ym USING $p_sIendorse;
    
    if (SQLCODE == SQLNOTFOUND)
    {
        printf("{ca401_data1.0041}:select ply_relation_bak not found!!\n");
        printf("{ca401_data1.0041}:select ori_ply_relation !!\n");
        stmt_buf[0] = '\0';
        sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s, %s:%s WHERE %s %s ",
                "a.ipro_year, a.ibrand, a.icar_type, min(b.drate_ym) ",
                sFullDBName, "ori_ply_relation a ",
                sFullDBName, "ori_ins_type b ",
                " a.ipolicy=(SELECT ipolicy FROM edr_relation WHERE iendorse=?)",
                " AND a.ipolicy = b.ipolicy GROUP BY a.ipro_year, a.ibrand, a.icar_type");

        $PREPARE cur_G FROM $stmt_buf;
        printf("%s\n", stmt_buf);
        $EXECUTE cur_G INTO $sIpro_year, $sIbrand, $sIcar_type, $sDrate_ym USING $p_sIendorse;        
        if (SQLCODE == SQLNOTFOUND)
        {
            $FREE cur_G;
            return M_CA_NENDORSE;
        }
        $FREE cur_G;
    }
    $FREE cur_F;
    strcpy(sIcar_type, TRANS_CAR_TYPE(sIcar_type, sDrate_ym));

    /* *** ���ئW�� *** */
    $SELECT ncode, fcar_class INTO $sNcar_abbr, $fcar_class FROM car_type WHERE icode = $sIcar_type AND fclass = '1';
    if (SQLCODE == SQLNOTFOUND)
        strcpy(sNcar_abbr, " ");

#ifdef _M860718
    printf("{ca401_data1.0050}: nassured[%s],nbenef[%s],aassured_zip[%s],assured[%s],licendse[%s],birth[%s],tel[%s],issue_ym[%s],pro_year[%s],car_type[%s],iengine[%s]\n", sNassured, sNbenef, sAassured_zip, sAassured, sIlicense, sIbirth, sItel, sIissue_ym, sIpro_year, sIcar_type, sIengine);
    printf("{ca401_data1.0050}: ibody[%s],itag[%s],ibrand[%s],nbrand_abbr[%s],ncar_abbr[%s]\n", sIbody, sItag, sIbrand, sNbrand_abbr, sNcar_abbr);
#endif
    strcpy(sNassured, rtrim(sNassured));
    strcpy(sNbenef, rtrim(sNbenef));
    strcpy(sAassured_zip, rtrim(sAassured_zip));
    strcpy(sAassured, rtrim(sAassured));
    strcpy(sIassured, rtrim(sIassured));
    strcpy(sIlicense, rtrim(sIlicense));
    strcpy(sIbirth, rtrim(sIbirth));
    strcpy(sItel, rtrim(sItel));
    strcpy(sIpro_year, rtrim(sIpro_year));
    strcpy(sIcar_type, rtrim(sIcar_type));
    strcpy(sIengine, rtrim(sIengine));
    strcpy(sIbody, rtrim(sIbody));
    strcpy(sItag, rtrim(sItag));
    strcpy(sIbrand, rtrim(sIbrand));
    strcpy(sNbrand_abbr, rtrim(sNbrand_abbr));
    strcpy(sNcar_abbr, rtrim(sNcar_abbr));

    /* *** �ʧO�~�֫Y�� *** */
    if (sFcard_class[0] == '1')
        sprintf_s(sTmpBuf, sizeof sTmpBuf, "%6.2f", dblPsex_age);
    else
        strcpy(sTmpBuf, ""); /* �O�v�ۥѤƤ��L */

    insert_tmp_table(iPg, 7, 1, sTmpBuf);

    /* *** �ߴڬ����Y��(�d��) *** */
    sprintf_s(sTmpBuf, sizeof sTmpBuf, "%6.2f", dblPlia_acc);
    insert_tmp_table(iPg, 7, 3, sTmpBuf); /* peter 12.10 */

    /* *** �ߴڬ����Y��(����) *** */
    sprintf_s(sTmpBuf, sizeof sTmpBuf, "%6.2f", dblPdmg_acc);
    insert_tmp_table(iPg, 7, 2, sTmpBuf); /* peter 12.10 */

    /* *** �h�����u��(����) *** */
    sprintf_s(sTmpBuf, sizeof sTmpBuf, "%4.1f", dblPdmg_align);
    strcat(sTmpBuf, " %");
    insert_tmp_table(iPg, 7, 4, sTmpBuf);

    /* *** �h�����u��(�ѵs) *** */
    sprintf_s(sTmpBuf, sizeof sTmpBuf, "%4.1f", dblPlia_align);
    strcat(sTmpBuf, " %");
    insert_tmp_table(iPg, 7, 5, sTmpBuf);

    /* *** �h�����u��(�d��) *** */
    sprintf_s(sTmpBuf, sizeof sTmpBuf, "%4.1f", dblPbrg_align);
    strcat(sTmpBuf, " %");
    insert_tmp_table(iPg, 7, 6, sTmpBuf);

    /* *** �o�Ӧ~�� *** */
    insert_tmp_table(iPg, 5, 1, sIissue_year);

    /* *** �o�Ӥ�� *** */
    insert_tmp_table(iPg, 5, 2, sIissue_month);

    /* *** �t�P�����W�� *** */
    i = cc_split_chinese(sNbrand_abbr, sTmpBuf, 4);
    insert_tmp_table(iPg, 4, 2, sTmpBuf);

    i = cc_split_chinese(sNcar_abbr, sTmpBuf, 7);
    insert_tmp_table(iPg, 4, 3, sTmpBuf);

    /* *** �p�G�������X > 14 �X, �L��� *** */
    if (strlen(sIengine) > 14)
    {
        insert_tmp_table(iPg, 5, 5, sIengine + 14);
    }

    /* *** ���ȸ��������� *** */
    insert_tmp_table(iPg, 5, 6, (*sFpt == 'P') ? "�H" : "��");

    /* *** �Q�O�I�H�����Ҹ� *** */

    if (*sFassured == '1')
    {
        /* 1060406006_C1 CAR401�BCAR409���C�L�Ӹ�B�n */
        /* 1060907002_C1 �C�L���ɷs�W�Ӹ�B�n�ﶵ */

        printf("--------------------- p_fmask[%s]\n", p_fmask);
        if (p_fmask[0] == '1')
        {
            puts("p_fmask is 11111111111111111111111111111");
            strcpy(sTmpBuf, substring(sIlicense, 1, 3));
            strcat(sTmpBuf, "****");
            strcat(sTmpBuf, substring(sIlicense, 8, 5));
            strcpy(sIlicense, sTmpBuf);
        }
        puts("p_fmask is 00000000000000000000000000000");

        insert_tmp_table(iPg, 6, 1, sIlicense);
    }
    else
    {
        /* 1060406006_C1 CAR401�BCAR409���C�L�Ӹ�B�n */
        /* 1060907002_C1 �C�L���ɷs�W�Ӹ�B�n�ﶵ */
        if (p_fmask[0] == '1')
        {
            strcpy(sTmpBuf, substring(sIassured, 1, 3));
            strcat(sTmpBuf, "****");
            strcat(sTmpBuf, substring(sIassured, 8, 5));
            strcpy(sIassured, sTmpBuf);
        }

        insert_tmp_table(iPg, 6, 1, sIassured);
    }

    /* 1060406006_C1 CAR401�BCAR409���C�L�Ӹ�B�n */
    /* 1060907002_C1 �C�L���ɷs�W�Ӹ�B�n�ﶵ */
    if (p_fmask[0] == '1')
    {
        i = cc_split_chinese(sNassured, sTmpBuf, 2);
        strcat(sTmpBuf, "****");
        strcpy(sNassured, sTmpBuf);

        /* *** �X�ͦ~��� *** */
        cm_split_ymd_100(sIbirth, birthyy, birthmm, birthdd);
        insert_tmp_table(iPg, 6, 2, "***");
        insert_tmp_table(iPg, 6, 3, "**");
        insert_tmp_table(iPg, 6, 4, "**");

        i = cc_split_chinese(sAassured, sTmpBuf, 12);
        strcat(sTmpBuf, "****");
        strcpy(sAassured, sTmpBuf);
    }
    else
    {
        /* *** �X�ͦ~��� *** */
        cm_split_ymd_100(sIbirth, birthyy, birthmm, birthdd);
        insert_tmp_table(iPg, 6, 2, birthyy);
        insert_tmp_table(iPg, 6, 3, birthmm);
        insert_tmp_table(iPg, 6, 4, birthdd);
    }

    /* *** �ʧO *** */
    /* 1060406006_C1 CAR401�BCAR409���C�L�Ӹ�B�n */
    /* 1060907002_C1 �C�L���ɷs�W�Ӹ�B�n�ﶵ */
    if (p_fmask[0] == '1')
    {
        insert_tmp_table(iPg, 6, 5, "**");
    }
    else
    {
        if (*sFsex == '1')
            insert_tmp_table(iPg, 6, 5, "�k");
        else if (*sFsex == '2')
            insert_tmp_table(iPg, 6, 5, "�k");
        else
            insert_tmp_table(iPg, 6, 5, "  ");
    }

    /* *** �B�� *** */
    /* 1060406006_C1 CAR401�BCAR409���C�L�Ӹ�B�n */
    /* 1060907002_C1 �C�L���ɷs�W�Ӹ�B�n�ﶵ */
    if (p_fmask[0] == '1')
    {
        insert_tmp_table(iPg, 6, 6, "**");
    }
    else
    {
        if (*g_sFedr_class == '2' || *g_sFedr_class == '8')
            insert_tmp_table(iPg, 6, 6, "**");
        else if (*sFmarriage == '1')
            insert_tmp_table(iPg, 6, 6, "�w�B");
        else if (*sFmarriage == '2')
            insert_tmp_table(iPg, 6, 6, "���B");
        else
            insert_tmp_table(iPg, 6, 6, "  ");
    }

    /* *** �Q�O�I�H�W�� *** */    
    if (strlen(sNassured) <= 70)
    {

        /*1130129008_C02 �վ�C�L���t�����ͤp�j�A�אּ�u�g�v*/ 
        /*        
        if (*sFsex == '1')
        {
            strcat(sNassured, " ����");
            *insert_tmp_table(iPg, 2, 1, sNassured);*
        }
        else if (*sFsex == '2')
        {
            strcat(sNassured, " �p�j");
            *insert_tmp_table(iPg, 2, 1, sNassured);*
        }
        */

        /*1130627010_C01 ���n�B�Q�O�H���R���u�g�v*/
        /*
        if(*sFsex == '1' || *sFsex == '2')
        {            
            strcat(sNassured, " �g");
        }       
        else
        {
            *insert_tmp_table(iPg, 2, 1, sNassured);*
        }
        */

        /*1120629002_C01�ק���n��ܨϥΤH*/        
        if (strlen(trim(sNuser))>0)
        {
            strcat(sNassured, " �ϥΤH�G");
            strcat(sNassured, sNuser);
        }

        insert_tmp_table(iPg, 2, 1, sNassured);          
    }
    else
    { /* *** temporary block add by tony96.861210 *** */
        int i;
        char buf[80];

        i = cc_split_chinese(sNassured, buf, 70);

        /*1120629002_C01�ק���n��ܨϥΤH*/
        if (strlen(sNuser)>0)
        {
            strcat(buf, " �ϥΤH�G");
            strcat(buf, sNuser);
        }

        insert_tmp_table(iPg, 2, 1, buf);
        /* cc_split_chinese(sNassured+i, buf, 70);
           insert_tmp_table(iPg, 2, 2, buf); */
    }
    /****�� �}**********/
    printf("sAassured_zip[%s]\n", sAassured_zip);
    insert_tmp_table(iPg, 2, 2, sAassured_zip);
    insert_tmp_table(iPg, 2, 3, sAassured);

    /* *** �s�y�~�� *** */
    insert_tmp_table(iPg, 4, 1, sIpro_year);

    /* *** �t�P�����N�� *** */
    insert_tmp_table(iPg, 5, 3, sIbrand);

    /* *** ���إN�� *** */

    insert_tmp_table(iPg, 5, 4, sIcar_type);

    /* *** �Ʈ�q *** */
    /*sprintf_s(sTmpBuf, sizeof sTmpBuf, "%d", dblQcylinder);*/
    sprintf_s(sTmpBuf, sizeof sTmpBuf, "%7.2f", dblQcylinder);
    insert_tmp_table(iPg, 4, 4, sTmpBuf);

    /* *** �������X *** */
    if (strlen(sIengine) > 14)
    {
        strncpy(sTmpBuf, sIengine, 14);
        sTmpBuf[14] = '\0';
    }
    else
        strcpy(sTmpBuf, sIengine);
    insert_tmp_table(iPg, 4, 5, sTmpBuf);

    /* *** �P�Ӹ� *** */
    insert_tmp_table(iPg, 4, 6, sItag);
    if (sItag[0] != '\0' && sItag[0] != ' ')
    { /* peter 12.10 */
        sprintf_s(sTmpBuf, sizeof sTmpBuf, "�P�Ӹ�:%s", sItag);
        sTmpBuf[25] = '\0';
    }
    else if (sIengine[0] != '\0' && sIengine[0] != ' ')
    {
        sprintf_s(sTmpBuf, sizeof sTmpBuf, "������:%s", sIengine);
        sTmpBuf[25] = '\0';
    }
    else
        sTmpBuf[0] = '\0';

    /* *** ���ȸ������� *** */
    sprintf_s(sTmpBuf, sizeof sTmpBuf, "%.1f", dblQpt);
    insert_tmp_table(iPg, 4, 7, sTmpBuf);

    /******** mark by Jessie 2005.03.03
    $SELECT dvp_code, dvp_abbr,nbranch,npresident,ntitle,tax_name,tax_area
       INTO $sDvp_code, $sDvp_abbr,$sNbranch,$sNpresident,$sNtitle,
            $sTaxName,$sTaxArea
       FROM ca_area_code
      WHERE sk_code = $sIbranch12;
    if(SQLCODE == SQLNOTFOUND){
      strcpy(sDvp_code,   "");
      strcpy(sDvp_abbr,   "");
      strcpy(sNbranch,    "");
      strcpy(sNpresident, "");
      strcpy(sNtitle,     "");
      strcpy(sTaxName,    "");
      strcpy(sTaxArea,    "");
    }
    strcpy(sDvp_code,   rtrim(sDvp_code));
    strcpy(sDvp_abbr,   rtrim(sDvp_abbr));
    strcpy(sNbranch,    rtrim(sNbranch));
    strcpy(sNpresident, rtrim(sNpresident));
    strcpy(sNtitle,     rtrim(sNtitle));
    strcpy(sTaxName,    rtrim(sTaxName));
    strcpy(sTaxArea,    rtrim(sTaxArea));
    ------------------------------------------------*/
    /*-- 2005.03.03  --*/
    $SELECT iupcomp, nchi_abv, npresident INTO $sDvp_code, $sDvp_abbr, $sNpresident FROM branch WHERE ibranch = $sIbranch12;

    /* *** �ӫO�a�ϥN�X *** */
    insert_tmp_table(iPg, 1, 13, sDvp_code); /* peter 12.10 */

    /* *** �ӫO�a��²�� *** */
    insert_tmp_table(iPg, 34, 4, sDvp_abbr);
    /******** mark by Jessie 2005.03.03
    if (p_sIendorse[2] == '0')
       insert_tmp_table(iPg, 34, 4, "�x�_");
    else if (p_sIendorse[2] == '1')
       insert_tmp_table(iPg, 34, 4, "�x��");
    else if (p_sIendorse[2] == '2')
       insert_tmp_table(iPg, 34, 4, "����");
    **********************/

    /* *** �����W�� *** */
    /* insert_tmp_table(iPg, 32, 3, sNbranch); */ /* peter 12.10 */

    /* *** �a�ϥD��¾�� *** */
    /* insert_tmp_table(iPg, 32, 4, sNtitle); */ /* peter 12.10 */

    /* *** �a�ϥD�ަW�r *** */
    /*sprintf_s(sTmpBuf, sizeof sTmpBuf, "%c%c%s%c%c", 27, 24, sNpresident, 27, 12);*/
    /* insert_tmp_table(iPg, 32, 5, sTmpBuf); */ /* peter 12.10 */

    /* �W�B�d���I��h�ĤT�H�d���I�O�I���B */
    Flag29Edr = 1;
    Flag29EdrType02 = 0;
    stmt_buf[0] = '\0';
    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s a, %s:%s b WHERE %s %s ",
            " iedr_type,abs(a.qday),a.iins_type ",
            sFullDBName, "edr_ins_type ",
            sFullDBName, "ply_ins_type ",
            " a.iendorse = ? ",
            " AND a.iins_type in ('29','124') AND a.iins_type = b.iins_type AND b.ipolicy = ? AND b.mdamage_cover <> 0");
    $PREPARE cur_H FROM $stmt_buf;
    $EXECUTE cur_H INTO $sIedrType, $lEdrQday, $sIins_type USING $p_sIendorse, $sIpolicy;
    if (SQLCODE == SQLNOTFOUND)
    {
        lEdrQday = 0;
        Flag29Edr = 0;
        strcpy(sIins_type," ");
        printf("--trace not found\n");        
    }
    $FREE cur_H;

    printf("lEdrQday[%ld]\n", lEdrQday);

    if ((strcmp(trim(sIedrType), "01") == 0) ||
        (strcmp(trim(sIedrType), "02") == 0) ||
        (strcmp(trim(sIedrType), "03") == 0) ||
        (strcmp(trim(sIedrType), "60") == 0))
    {
        lEdrQday = 0;
        Flag29EdrType02 = 1;
    }
    strcpy(sEdrQday, ltoa(lEdrQday));

    stmt_buf[0] = '\0';
    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s WHERE %s %s ",
            " qday ",
            sFullDBName, "ply_ins_type_bak ",
            " iendorse = ? ",
            " AND iins_type = ? ");
    $PREPARE cur_I FROM $stmt_buf;
    $EXECUTE cur_I INTO $lQday USING $p_sIendorse, $sIins_type;        
    if (SQLCODE == SQLNOTFOUND)
    {
        lQday = 0;
    }
    $FREE cur_I;
    strcpy(sQday, ltoa(lQday));
    printf("lQday[%ld], iins_type[%s]\n", lQday, sIins_type);

    sPrn29Cover[0] = '\0';
    printf("Flag29Edr[%d],Flag29EdrType02[%d]\n", Flag29Edr, Flag29EdrType02);
    if ((lEdrQday != lQday) && (Flag29Edr == 1) && (Flag29EdrType02 != 1))
    {
        if (lEdrQday != 0)
        {
            $SELECT prn_deduct
               INTO :sEdrPrnDeduct
               FROM ca_dmg_mdeduct
              WHERE icar_type = 'I29' AND ideduct = :sEdrQday;
            if (SQLCODE == SQLNOTFOUND)
            {
                strcpy(sEdrPrnDeduct, "0 �U");
            }
            strcpy(sEdrPrnDeduct, trim(sEdrPrnDeduct));
            printf("sPrnEdrDeduct[%s]\n", sEdrPrnDeduct);
        }
        else
        {
            strcpy(sEdrPrnDeduct, "0 �U");
        }

        if (lQday != 0)
        {
            $SELECT prn_deduct
               INTO :sPrnDeduct
               FROM ca_dmg_mdeduct
              WHERE icar_type = 'I29' AND ideduct = :sQday;
            if (SQLCODE == SQLNOTFOUND)
            {
                strcpy(sPrnDeduct, "0 �U");
            }
            strcpy(sPrnDeduct, trim(sPrnDeduct));
            printf("sPrnDeduct[%s]\n", sPrnDeduct);
        }
        else
        {
            strcpy(sPrnDeduct, "0 �U");
        }
        if (strcmp(trim(sIins_type), "29") == 0)
            sprintf_s(sPrn29Cover, sizeof sPrn29Cover, "�W�B�d���I��h�ĤT�H�d���I�O�I���B�� %s ���ܧ� %s ���A�ۥ��� %s �_�ͮ�", sPrnDeduct, sEdrPrnDeduct, cDedr_begin);
        else
            sprintf_s(sPrn29Cover, sizeof sPrn29Cover, "��D�ƬG�W�B�O�ٰ�h�ĤT�H�d���I�O�I���B�� %s ���ܧ� %s ���A�ۥ��� %s �_�ͮ�", sPrnDeduct, sEdrPrnDeduct, cDedr_begin);
    }
    else
    {
        sPrn29Cover[0] = '\0';
    }
    printf("sEdrQday[%s],sQday[%s]\n", sEdrQday, sQday);
    printf("sPrn29Cover[%s]\n", sPrn29Cover);

    
    /*1070928002_SC2_�s�W�O�I�����ܧ�Τ��~�פ���[����(�N��X)(���)*/
    iFlagProv1 = 0;
    sPrnProv[0] = '\0';

    /* 1081225006_SC3 �X�R���[���ڥN�X */
    sprintf_s(stmt_buf, sizeof stmt_buf,
            "SELECT count(*) FROM %s:edr_ins_type "
            "  WHERE iendorse = '%s' "
            "   AND regex_match(provision,'(;| +|^)X(;| +|$)') "
            "   AND NOT EXISTS(SELECT '1' FROM %s:ply_ins_type_bak "
            "                   WHERE iendorse ='%s' "
            "                     AND regex_match(provision,'(;| +|^)X(;| +|$)') ) ",
            sFullDBName, p_sIendorse, sFullDBName, p_sIendorse);
    printf("-- trace stmt_buf[%s]\n ", stmt_buf);
    $PREPARE pre_provx FROM $stmt_buf;
    $EXECUTE pre_provx INTO $iFlagProv1;
    $FREE pre_provx;
    if (iFlagProv1 > 0)
    {
        sprintf_s(sPrnProv, sizeof sPrnProv, "���O��ۥ��� %s �_��[�u�O�I�����ܧ�Τ��~�פ���[���ڡv", cDedr_begin);

        if (strlen(note1) == 0)
        {
            strcpy(note1, rtrim(sPrnProv));
        }
        else if (strlen(note2) == 0)
        {
            strcpy(note2, rtrim(sPrnProv));
        }
        else if (strlen(note3) == 0)
        {
            strcpy(note3, rtrim(sPrnProv));
        }
        else if (strlen(sPrn29Cover) == 0)
        {
            strcpy(sPrn29Cover, rtrim(sPrnProv));
        }
    }

    /*1081105005_SC2 �ק���~���w���ƫ������²v�Φۭt�B*/
    /*1071226006_SC2_ �w���ƫ����վ�(���²v+�ĤT�H�d��)------------*/
    iFlagProv1 = 0;
    iFlagProv2 = 0;
    iFlagProv3 = 0;
    sPrnProv[0] = '\0';

    /* 1081225006_SC3 �X�R���[���ڥN�X */
    sprintf_s(stmt_buf, sizeof stmt_buf,
            " SELECT DISTINCT nvl(decode(regex_match(provision,'(;| +|^)P(;| +|$)'),'t',1,0), 0), "
            "        nvl(decode(regex_match(provision,'(;| +|^)Q(;| +|$)'),'t',1,0), 0), "
            "        nvl(decode(regex_match(provision,'(;| +|^)M(;| +|$)'),'t',1,0), 0)  "
            "   FROM %s:edr_ins_type "
            "  WHERE iendorse = '%s' "
            "   AND regex_match(provision,'(;| +|^)(P|Q)(;| +|$)')  "
            "   AND iins_type IN ('01','05','09','11','181','201','205','209','211') "
            "   AND NOT EXISTS(SELECT '1' FROM %s:ply_ins_type_bak "
            "                   WHERE iendorse ='%s' "
            "                     AND regex_match(provision,'(;| +|^)(P|Q)(;| +|$)') "
            "                     AND iins_type IN ('01','05','09','11','181','201','205','209','211')) ",
            sFullDBName, p_sIendorse, sFullDBName, p_sIendorse);

    printf("-- trace stmt_buf[%s]\n ", stmt_buf);
    $PREPARE pre_prov_pq FROM $stmt_buf;
    $EXECUTE pre_prov_pq INTO $iFlagProv1, $iFlagProv2, $iFlagProv3;    
    if (SQLCODE != SQLNOTFOUND)
    {
        if (iFlagProv1 > 0 || iFlagProv2 > 0 || iFlagProv3 > 0)
        {
            if (iFlagProv1 > 0)
                strcpy(sTmp, "A��(P)-���²v15%");
            else if (iFlagProv2 > 0)
                strcpy(sTmp, "B��(Q)-���²v20%");
            else
                strcpy(sTmp, "C��(M)-���²v25%");

            sprintf_s(sPrnProv, sizeof sPrnProv, "���O��ۥ��� %s �_��[�u���w���²v���[����%s�v", cDedr_begin, trim(sTmp));


            if (strlen(note1) == 0)
            {
                strcpy(note1, rtrim(sPrnProv));
            }
            else if (strlen(note2) == 0)
            {
                strcpy(note2, rtrim(sPrnProv));
            }
            else if (strlen(note3) == 0)
            {
                strcpy(note3, rtrim(sPrnProv));
            }
            else if (strlen(sPrn29Cover) == 0)
            {
                strcpy(sPrn29Cover, rtrim(sPrnProv));
            }
        }
    }
    $FREE pre_prov_pq;
    iFlagProv1 = 0;
    iFlagProv2 = 0;
    sPrnProv[0] = '\0';
 
    /* 1081225006_SC3 �X�R���[���ڥN�X */
    sprintf_s(stmt_buf, sizeof stmt_buf,
            " SELECT DISTINCT nvl(CASE WHEN iins_type in('09','209') then nvl(decode(regex_match(provision,'(;| +|^)V(;| +|$)'),'t',1,0), 0) END,0) , "
            "        nvl(CASE WHEN iins_type IN('31','32','231','232','531','532') then nvl(decode(regex_match(provision,'(;| +|^)V(;| +|$)'),'t',1,0), 0) END,0) "
            "   FROM %s:edr_ins_type "
            "  WHERE iendorse = '%s' "
            "   AND regex_match(provision,'(;| +|^)V(;| +|$)') "
            "   AND iins_type IN ('09','31','32','209','231','232','531','532') "
            "   AND NOT EXISTS(SELECT '1' FROM %s:ply_ins_type_bak "
            "                   WHERE iendorse ='%s' "
            "                     AND regex_match(provision,'(;| +|^)V(;| +|$)') "
            "                     AND iins_type IN ('09','31','32','209','231','232','531','532')) ",
            sFullDBName, p_sIendorse, sFullDBName, p_sIendorse);

    printf("-- trace stmt_buf[%s]\n ", stmt_buf);
    $PREPARE pre_prov_pq FROM $stmt_buf;
    $EXECUTE pre_prov_pq INTO $iFlagProv1, $iFlagProv2;
    
    printf("-- trace iFlagProv1[%d]\n ", iFlagProv1);
    printf("-- trace iFlagProv2[%d]\n ", iFlagProv2);
    if (SQLCODE != SQLNOTFOUND)
    {
        if (iFlagProv1 > 0)
        {
            strcpy(sTmp, "�T������l���O�I����");
            sprintf_s(sPrnProv, sizeof sPrnProv, "���O��ۥ��� %s �_��[�u%s�ۭt�B���[���ڡv", cDedr_begin, trim(sTmp));

            if (strlen(note1) == 0)
            {
                strcpy(note1, rtrim(sPrnProv));
            }
            else if (strlen(note2) == 0)
            {
                strcpy(note2, rtrim(sPrnProv));
            }
            else if (strlen(note3) == 0)
            {
                strcpy(note3, rtrim(sPrnProv));
            }
            else if (strlen(sPrn29Cover) == 0)
            {
                strcpy(sPrn29Cover, rtrim(sPrnProv));
            }
        }
        if (iFlagProv2 > 0)
        {
            strcpy(sTmp, "�T���ĤT�H�d���O�I");
            sprintf_s(sPrnProv, sizeof sPrnProv, "���O��ۥ��� %s �_��[�u%s�ۭt�B���[���ڡv", cDedr_begin, trim(sTmp));

            if (strlen(note1) == 0)
            {
                strcpy(note1, rtrim(sPrnProv));
            }
            else if (strlen(note2) == 0)
            {
                strcpy(note2, rtrim(sPrnProv));
            }
            else if (strlen(note3) == 0)
            {
                strcpy(note3, rtrim(sPrnProv));
            }
            else if (strlen(sPrn29Cover) == 0)
            {
                strcpy(sPrn29Cover, rtrim(sPrnProv));
            }
        }
    }
    $FREE pre_prov_pq;
    /*1080408008_SC2 98�����ഫ�I�ج�09+K���� */
    iFlagProv1 = 0;
    sPrnProv[0] = '\0';

    /* 1081225006_SC3 �X�R���[���ڥN�X */
    sprintf_s(stmt_buf, sizeof stmt_buf,
            "SELECT count(*) FROM %s:edr_ins_type "
            "  WHERE iendorse = '%s' "
            "   AND regex_match(provision,'(;| +|^)K(;| +|$)') "
            "   AND NOT EXISTS(SELECT '1' FROM %s:ply_ins_type_bak "
            "                   WHERE iendorse ='%s' "
            "                     AND regex_match(provision,'(;| +|^)K(;| +|$)') ) ",
            sFullDBName, p_sIendorse, sFullDBName, p_sIendorse);

    printf("-- trace stmt_buf[%s]\n ", stmt_buf);
    $PREPARE pre_provx FROM $stmt_buf;
    $EXECUTE pre_provx INTO $iFlagProv1;
    $FREE pre_provx;
    if (iFlagProv1 > 0)
    {
        sprintf_s(sPrnProv, sizeof sPrnProv, "���O��ۥ��� %s �_��[�u�������B���[���ڡv", cDedr_begin);

        if (strlen(note1) == 0)
        {
            strcpy(note1, rtrim(sPrnProv));
        }
        else if (strlen(note2) == 0)
        {
            strcpy(note2, rtrim(sPrnProv));
        }
        else if (strlen(note3) == 0)
        {
            strcpy(note3, rtrim(sPrnProv));
        }
        else if (strlen(sPrn29Cover) == 0)
        {
            strcpy(sPrn29Cover, rtrim(sPrnProv));
        }
    }

    /*1080708002_SC2 �s�W�����������(�N��L),�P�ɸɤW R����*/
    iFlagProv1 = 0;
    sPrnProv[0] = '\0';

    /* 1081225006_SC3 �X�R���[���ڥN�X */
    sprintf_s(stmt_buf, sizeof stmt_buf,
            "SELECT count(*) FROM %s:edr_ins_type "
            "  WHERE iendorse = '%s' "
            "   AND regex_match(provision,'(;| +|^)L(;| +|$)') "
            "   AND NOT EXISTS(SELECT '1' FROM %s:ply_ins_type_bak "
            "                   WHERE iendorse ='%s' "
            "                     AND regex_match(provision,'(;| +|^)L(;| +|$)') ) ",
            sFullDBName, p_sIendorse, sFullDBName, p_sIendorse);

    printf("-- trace stmt_buf[%s]\n ", stmt_buf);
    $PREPARE pre_provL FROM $stmt_buf;
    $EXECUTE pre_provL INTO $iFlagProv1;
    $FREE pre_provL;
    if (iFlagProv1 > 0)
    {
        sprintf_s(sPrnProv, sizeof sPrnProv, "���O��ۥ��� %s �_��[�u������~�γ~���[���ڡv", cDedr_begin);

        if (strlen(note1) == 0)
        {
            strcpy(note1, rtrim(sPrnProv));
        }
        else if (strlen(note2) == 0)
        {
            strcpy(note2, rtrim(sPrnProv));
        }
        else if (strlen(note3) == 0)
        {
            strcpy(note3, rtrim(sPrnProv));
        }
        else if (strlen(sPrn29Cover) == 0)
        {
            strcpy(sPrn29Cover, rtrim(sPrnProv));
        }
    }

    iFlagProv1 = 0;
    sPrnProv[0] = '\0';

    /* 1081225006_SC3 �X�R���[���ڥN�X */
    sprintf_s(stmt_buf, sizeof stmt_buf,
            "SELECT count(*) FROM %s:edr_ins_type "
            "  WHERE iendorse = '%s' "
            "   AND regex_match(provision,'(;| +|^)R(;| +|$)') "
            "   AND NOT EXISTS(SELECT '1' FROM %s:ply_ins_type_bak "
            "                   WHERE iendorse ='%s' "
            "                     AND regex_match(provision,'(;| +|^)R(;| +|$)') ) ",
            sFullDBName, p_sIendorse, sFullDBName, p_sIendorse);

    printf("-- trace stmt_buf[%s]\n ", stmt_buf);
    $PREPARE pre_provR FROM $stmt_buf;
    $EXECUTE pre_provR INTO $iFlagProv1;
    $FREE pre_provR;
    if (iFlagProv1 > 0)
    {
        sprintf_s(sPrnProv, sizeof sPrnProv, "���O��ۥ��� %s �_��[�u��������������w�ϥΪ��[���ڡv", cDedr_begin);

        if (strlen(note1) == 0)
        {
            strcpy(note1, rtrim(sPrnProv));
        }
        else if (strlen(note2) == 0)
        {
            strcpy(note2, rtrim(sPrnProv));
        }
        else if (strlen(note3) == 0)
        {
            strcpy(note3, rtrim(sPrnProv));
        }
        else if (strlen(sPrn29Cover) == 0)
        {
            strcpy(sPrn29Cover, rtrim(sPrnProv));
        }
    }

    /*1120316006_SC2 ���N�I���e�{�s�W�u���@���v�����������O�N��05�ή��s�X��t�ηs�W���@�����O
      ��115���O�B���ӫO�i�����I�j�A�B ���ݫO�椧ñ��� �� �u���@���v�W�u��ɡA���W���[��ĵ�y
    */
    
    if (equip_cmp(sNequipment,"115") == TRUE)
    {
        printf("--trace 115\n");  
        /*��榳�[�O�����I*/
        stmt_buf[0] = '\0'; iFlagProv1 = 0;
        sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT count(*) FROM %s:edr_ins_type WHERE %s %s ",
                sFullDBName,   
                " iendorse = ? ",
                " AND iins_type in ('55') AND iedr_type in ('05') ");
        printf("-- trace stmt_buf[%s]\n ", stmt_buf);        
        $PREPARE cur_115 FROM $stmt_buf;
        $EXECUTE cur_115 INTO $iFlagProv1 USING $p_sIendorse;

        if (iFlagProv1==0) 
        {
            /*�L��B���ӫO�����I*/
            printf("--trace 55,255 not found\n");        

            stmt_buf[0] = '\0';
            sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT count(*) FROM %s:edr_relation a,%s:ply_ins_type_bak b WHERE a.iendorse = b.iendorse %s %s ",
                    sFullDBName, sFullDBName,  
                    " AND a.fedr_class ='8' AND a.iendorse = ? ",
                    " AND b.iins_type in ('55') AND b.mdamage_cover > 0");
            printf("-- trace stmt_buf[%s]\n ", stmt_buf);        
            $PREPARE cur_115_1 FROM $stmt_buf;
            $EXECUTE cur_115_1 INTO $iFlagProv1 USING $p_sIendorse;            
            if (iFlagProv1==0)           
            {
                printf("--trace ply_ins_type_bak 55,255 not found\n");    
            }
            $FREE cur_115_1;         
            
        }
        $FREE cur_115;

        printf("--trace ���@�� iFlagProv1=[%d]\n",iFlagProv1);
        

        /*if ((iFlagProv1>0) && (lDpolicy>= cm_ymd_cdate("112/05/15")))*/
        if (iFlagProv1>0)
        {
            strcpy(sPrnProv, "�����I�ӫO�d�򤣧t�˱w");

            if (strlen(note1) == 0)
            {
                strcpy(note1, rtrim(sPrnProv));
            }
            else if (strlen(note2) == 0)
            {
                strcpy(note2, rtrim(sPrnProv));
            }
            else if (strlen(note3) == 0)
            {
                strcpy(note3, rtrim(sPrnProv));
            }
            else if (strlen(sPrn29Cover) == 0)
            {
                strcpy(sPrn29Cover, rtrim(sPrnProv));
            }
        }
    }

    /*1130827011_C01 �s�W�s�t��W�B���[����(Y)�A�Щ�1101�W�u*/
    /* 1120606010_C01 �s�W���������ӫ~���[���� => 1120724 ����մ����q���M�P���@�~*/
    iFlagProv1 = 0;   sPrnProv[0] = '\0';    
    sprintf_s(stmt_buf, sizeof stmt_buf,
            "SELECT count(*) FROM %s:edr_ins_type X "
            " WHERE iendorse = '%s' "
            "   AND regex_match(provision,'(;| +|^)Y(;| +|$)') "
            "   AND iins_type IN ('01','05','09','201','205','209','198') "
            "   AND NOT EXISTS(SELECT '1' FROM %s:ply_ins_type_bak "
            "                   WHERE iendorse ='%s' "
            "                     AND regex_match(provision,'(;| +|^)Y(;| +|$)') "
            "                     AND iins_type = X.iins_type) ",            
            sFullDBName, p_sIendorse, sFullDBName, p_sIendorse);

    printf("-- trace Y stmt_buf[%s]\n ", stmt_buf);
    $PREPARE pre_prov_Y FROM $stmt_buf;
    $EXECUTE pre_prov_Y INTO $iFlagProv1;
    $FREE pre_prov_Y;
    printf("--trace Y iFlagProv1=[%d]\n",iFlagProv1);
    
    if (iFlagProv1 > 0)
    {
        sprintf_s(sPrnProv, sizeof sPrnProv, "���O��ۥ��� %s �_��[�u�s�t��W�B���[���ڡv", cDedr_begin);

        if (strlen(note1) == 0)
        {
            strcpy(note1, rtrim(sPrnProv));
        }
        else if (strlen(note2) == 0)
        {
            strcpy(note2, rtrim(sPrnProv));
        }
        else if (strlen(note3) == 0)
        {
            strcpy(note3, rtrim(sPrnProv));
        }
        else if (strlen(sPrn29Cover) == 0)
        {
            strcpy(sPrn29Cover, rtrim(sPrnProv));
        }
    }
     
    /*--------------------------------------------------------------------------*/
    printf("-- trace sPrn29Cover[%s]\n ", sPrn29Cover);
    printf("-- trace note1[%s]\n ", note1);
    printf("-- trace note2[%s]\n ", note2);
    printf("-- trace note3[%s]\n ", note3);

    /*****  �Ƶ���� peter 89.11.23 *****/
    insert_tmp_table(iPg, 32, 1, note1);
    insert_tmp_table(iPg, 32, 2, note2);
    insert_tmp_table(iPg, 32, 3, note3);

    if (strlen(trim(sPrn29Cover)) < 5) /* sPrn29Cover �������󦳤@��"����r�ýX"�A���βM���覡 */
    {
       strcpy(sPrn29Cover," ");    
    }
    insert_tmp_table(iPg, 32, 4, sPrn29Cover);    
    return M_CM_OK;

errexit:
    printf("{ca401_data1}: SQLCODE = %d sqlerrm=%s\n", SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
} /* ca401_data1 */

/* ************************************************************************
 * Function: ca401_data2
 *
 * Description:
 *   �C�L�I�ة��Ӹ��.
 *
 * ************************************************************************/
long ca401_data2(p_sIendorse)
$char *p_sIendorse;
{
    $int iMedrdmg_cover, iMedrinj_cover, iMedrdea_cover, iMdeduct;
    $int iPcal, iQserial, iMedrins_prem;
    $int iMedr_discount, insurance_cover_count;
    $long iMdeduct_l;
    $char iMdeduct_c[11];

    $int iMedr_prem, iins;
    $char sIcar_type[3], sDeduct[11], tmpDeduct[8], tmp1Deduct[19];
    $long tot_Medr_prem;
    $int ins_cnt, lMdeduct;
    int iPg_init, iPg, iTmp, jTmp, kTmp, i, hTmp;

    $char sIins_type[INSURANCE_TYPE], sIedr_type[3], sFcal_way[2], sDrate_ym[5], f1000406[2];
    $char sFprint[2], sFins_grp[2], sNins_type[21], insurance_fcal_way[2];
    $int iQcoverage, iLineCount;
    $int iLineCount_tmp, AddLine;
    $char sTmpBuf[512];
    $char sFcomp_24[2];

    $int check_910401, iCount, iedr_type05, iedr_type02;
    $long lDpolicy, qday;
    $char stmt_buf[8000];
    $char provision[21], sbus_source[21], fdeduct[2];
    char v_sMsg[1512];
    long rtncode, lPremSum;
    char sColumn[21], sTable[21], sDbname[21], stmp[51];
    $long mcover_limit;

    printf("$$$$$$$$$$$$ into ca401_data2()\n");

    $WHENEVER SQLERROR GOTO errexit;

    iPg_init = 1;
    iPg = 1;
    iLineCount = 0;
    iLineCount_tmp = 0;
    tot_Medr_prem = 0;

    strcpy(provision, " ");

    strcpy(sDbname, "");
    strcpy(sTable, "edr_ins_cover");
    strcpy(sColumn, "iendorse");
    strcpy(sDbname, trim(sFullDBName)); /* 131775 ���wsDbname����渹�Ҧb����Ʈw(1131009010_C02) */

    IcurrPlyInsCover = IfirstPlyInsCover = IlastPlyInsCover = NULL; /* set init pointer to NULL */
#ifdef CA_CONS
    IfirstPlyInsCover = get_ply_ins_cover(sDbname, sTable, sColumn, p_sIendorse, &rtncode, v_sMsg);
    if (rtncode != M_CM_OK)
        return rtncode;
#endif

    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT a.mcover_limit-b.mcover_limit FROM %s:endorsement a, %s:policy_bak b WHERE a.iendorse = '%s'"
                      "   AND a.iendorse = b.iendorse ",
            sFullDBName, sFullDBName, p_sIendorse);
    $PREPARE prep4 FROM $stmt_buf;
    $EXECUTE prep4 INTO $mcover_limit;
    $FREE prep4;
    printf("%s\n", stmt_buf);

    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s %s %s %s FROM %s:%s %s:%s %s:%s %s:%s WHERE %s %s %s %s %s ",
            " a.iins_type, a.iedr_type, a.medrdmg_cover, a.medrinj_cover,",
            " a.medrdea_cover, a.mdeduct, a.medrins_prem, a.medr_discount,",
            " a.fcal_way, a.pcal, a.qserial, a.drate_ym,",
            " a.medr_prem, b.icar_type, c.dpolicy, d.fcomp_24, a.provision, a.qday ",
            sFullDBName, "edr_ins_type a, ",
            sFullDBName, "edr_relation b, ",
            sFullDBName, "ply_relation c, ",
            sFullDBName, "endorsement d   ",
            "      a.iendorse = ? ",
            "  AND a.iendorse = b.iendorse ",
            "  AND b.iendorse = d.iendorse ",
            "  AND b.ipolicy  = c.ipolicy ",
            "ORDER BY qserial");

    $PREPARE x3_tmp FROM $stmt_buf;
    $DECLARE x3 CURSOR FOR x3_tmp;
    $FREE x3_tmp;
    $OPEN x3 USING $p_sIendorse;
    printf("%s\n", stmt_buf);
    /* lMedr_sum = 0; */
    while (1)
    {
        $FETCH x3 INTO $sIins_type, $sIedr_type, $iMedrdmg_cover, $iMedrinj_cover,
            $iMedrdea_cover, $iMdeduct, $iMedrins_prem, $iMedr_discount,
            $sFcal_way, $iPcal, $iQserial, $sDrate_ym,
            $iMedr_prem, $sIcar_type, $lDpolicy, $sFcomp_24, $provision, $qday;

        if (SQLCODE == SQLNOTFOUND)
            break;
        strcpy(sIcar_type_ori, sIcar_type);
        strcpy(sIcar_type, TRANS_CAR_TYPE(sIcar_type, sDrate_ym));

        strcpy(sIins_type, trim(sIins_type));
        iins = atoi(sIins_type);


        $SELECT nins_type[1, 20], qcoverage, fprint, fins_grp, fcal_way, fdeduct INTO $sNins_type, $iQcoverage, $sFprint, $sFins_grp, $insurance_fcal_way, $fdeduct FROM insurance_type WHERE iins_type = $sIins_type;

        $SELECT COUNT(*)
            INTO $insurance_cover_count
                FROM insurance_cover
                    WHERE iins_type = $sIins_type;

        printf("1.############ data2() iLineCount[%d] MAX_EDR_ROW[%d]\n",
               iLineCount, MAX_EDR_ROW);

        if (iLineCount_tmp != 0)
        {
            /* 1000310003_C1_�ۥΨT����X�d���I */
            if (strcmp(trim(sIins_type), "31")  == 0 || strcmp(trim(sIins_type), "231") == 0 ||
                strcmp(trim(sIins_type), "331") == 0 || strcmp(trim(sIins_type), "113") == 0 ||
                strcmp(trim(sIins_type), "131") == 0 || strcmp(trim(sIins_type), "178") == 0 ||
                strcmp(trim(sIins_type), "531") == 0)
            {
                iQcoverage = 2;
            }
            else if (strcmp(trim(sIins_type), "145") == 0 || strcmp(trim(sIins_type), "146") == 0) /*** 31,36,77�I�� ***/
                iQcoverage = 3;
            else if (strcmp(trim(sIins_type), "32")  == 0 || strcmp(trim(sIins_type), "232") == 0 ||
                     strcmp(trim(sIins_type), "332") == 0 || strcmp(trim(sIins_type), "114") == 0 ||
                     strcmp(trim(sIins_type), "132") == 0 || strcmp(trim(sIins_type), "134") == 0 ||
                     strcmp(trim(sIins_type), "532") == 0) /*** 32,37,78�I�� ***/
            {
                iQcoverage = 1;
            }
            else if (strcmp(trim(sIins_type), "51") == 0 || strcmp(trim(sIins_type), "52") == 0 || strcmp(trim(sIins_type), "238") == 0 ||
                     strcmp(trim(sIins_type), "252") == 0 )
            {
                iQcoverage = 2;
            }
            else if (strcmp(trim(sIins_type), "57") == 0 || strcmp(trim(sIins_type), "59") == 0 ||
                     strcmp(trim(sIins_type), "60") == 0)
            {
                iQcoverage = 3;
            }
            else if (strcmp(trim(sIins_type), "238") == 0) /*1100119001_SC2 �s�W-�s�ӫ~(238�I-�D���ϴ��O�Ϊ��[����)�������ˮ֤Ϊ���*/
            {
                iQcoverage = 3;
            }
            else if (strcmp(trim(sIins_type), "34") == 0 || strcmp(trim(sIins_type), "87") == 0 || strcmp(trim(sIins_type), "115") == 0) /*** 34,87�I�� ***/
                iQcoverage = 3;
            else if (strcmp(trim(sIins_type), "85") == 0 || strcmp(trim(sIins_type), "105") == 0 || strcmp(trim(sIins_type), "118") == 0) /*** 85�I�� ***/
                iQcoverage = 2;
            else if (iQcoverage > 2)
                iQcoverage = 2;
            else
                iQcoverage = 1;

            iLineCount_tmp += iQcoverage;
        }

        printf("2.############ data2() iLineCount[%d] MAX_EDR_ROW[%d]\n", iLineCount, MAX_EDR_ROW);
        if (iLineCount_tmp >= MAX_EDR_ROW)
        {
            iLineCount = 0;
            iLineCount_tmp = 0;

            iPg++;
            printf("-----------------------> data2() iPg[%d]\n", iPg);
        }
        /* strcpy( stmp, trim(sNins_type));
        strcat( stmp,"(���w�r�p�H)");

        i = cc_split_chinese( stmp, sNins_type, 20); */

        if (insurance_cover_count != 0)
        { /* CA_CONS */

            insert_tmp_table(iPg, BASE_LINE + iLineCount, 3, sNins_type);
            iTmp = jTmp = 0;
            kTmp = 10;
            IcurrPlyInsCover = IfirstPlyInsCover;
            while (IcurrPlyInsCover)
            {
                insert_tmp_table(iPg, BASE_LINE + iLineCount + jTmp, kTmp, IcurrPlyInsCover->print_name);

                if (IcurrPlyInsCover->mcover > 0)
                    strcpy(sTmpBuf, "+");
                else if (IcurrPlyInsCover->mcover == 0)
                    strcpy(sTmpBuf, " ");
                else
                    strcpy(sTmpBuf, "-");

                insert_tmp_table(iPg, BASE_LINE + iLineCount + jTmp, kTmp + 1, sTmpBuf);
                rfmtlong(IcurrPlyInsCover->mcover, "-,---,---,--&", sTmpBuf);
                insert_tmp_table(iPg, BASE_LINE + iLineCount + jTmp, kTmp + 2, sTmpBuf);

                if (iTmp % 2 == 0)
                {
                    jTmp++;
                    kTmp = 3;
                }
                else
                    kTmp = 10;

                iTmp++;

                IcurrPlyInsCover = IcurrPlyInsCover->next;
            }
            /*if (strstr(provision, "D"))*/
            if (IsProvExist("D", provision) == TRUE)
                insert_tmp_table(iPg, BASE_LINE + iLineCount + 2, 10, "      ���w�r�p�H");
        }

        printf("3.############ data2() iLineCount[%d] MAX_EDR_ROW[%d] iPg[%d]\n", iLineCount, MAX_EDR_ROW, iPg);

        /* *** ���ʽ� *** */
        insert_tmp_table(iPg, BASE_LINE + iLineCount, 1, sIedr_type);

        /* *** �O�I�����N�� *** */
        insert_tmp_table(iPg, BASE_LINE + iLineCount, 2, sIins_type);

        strcpy(f1000406, "");
        if (strcmp(sIins_type, "24")  == 0 || strcmp(sIins_type, "52")  == 0 ||
            strcmp(sIins_type, "53")  == 0 || strcmp(sIins_type, "55")  == 0 ||
            strcmp(sIins_type, "117") == 0 || strcmp(sIins_type, "135") == 0 ||
            strcmp(sIins_type, "252") == 0 || strcmp(sIins_type, "253") == 0 ||
            strcmp(sIins_type, "555") == 0)
        {
            if (insurance_fcal_way[0] == '1') /* �O�v�� */
            {
                $SELECT case when drate >= date('04/06/2011') then '1' else '0' end
                                               INTO $f1000406
                                                   FROM ca_rate_date
                                                       WHERE icode = $sDrate_ym
                    AND itable = 'ca_rate';
            }
            else if (insurance_fcal_way[0] == '2') /* �O�B�O�O�� */
            {
                $SELECT case when drate >= date('04/06/2011') then '1' else '0' end
                                               INTO $f1000406
                                                   FROM ca_rate_date
                                                       WHERE icode = $sDrate_ym
                    AND itable = 'cover_vs_premium';
            }
        }
        AddLine = 0;
        /* *** �O�I�����W�� *** */
        if (insurance_cover_count != 0)
        {
        }
        else if (strcmp(sIins_type, "31")  == 0 || strcmp(sIins_type, "231") == 0 ||
                 strcmp(sIins_type, "331") == 0 || strcmp(sIins_type, "113") == 0 ||
                 strcmp(sIins_type, "131") == 0 || strcmp(sIins_type, "531") == 0) /***  31,36,77�I��  ***/
        {
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 3, sNins_type);
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 10, "    �C�@�ӤH�ˮ`");
            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 3, "    �C�@�ƬG�ˮ`");
            /*if (strstr(provision, "H"))*/
            if (IsProvExist("H", provision) == TRUE)
            {
                insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 10, "      �Ұ���O��");
                hTmp++;
            }
            /*if (strstr(provision, "D"))*/
            if (IsProvExist("D", provision) == TRUE)
            {
                if (hTmp == 0)
                    insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 10, "      ���w�r�p�H");
                else
                    insert_tmp_table(iPg, BASE_LINE + iLineCount + 2, 3, "      ���w�r�p�H");
            }
            /*if (strstr(provision, "J"))*/
            if (IsProvExist("J", provision) == TRUE)
            {
                if (hTmp == 0)
                    insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 10, "�S�w�γ~�[�T�w�ϥΤH");
                else
                    insert_tmp_table(iPg, BASE_LINE + iLineCount + 2, 3, "�S�w�γ~�[�T�w�ϥΤH");
            }
        }
        else if (strcmp(sIins_type, "145") == 0)
        {
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 3, sNins_type);
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 10, "�C�@�ӤH��˳d��");
            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 3, "�C�@�N�~�ƬG��˳d��");
        }
        else if (strcmp(sIins_type, "146") == 0)
        {
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 3, sNins_type);
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 10, "�C�@�N�~�ƬG�]���l��");
            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 3, "���O�I�������̰����v");
        }
        else if (strcmp(sIins_type, "32")  == 0 || strcmp(sIins_type, "232") == 0 ||
                 strcmp(sIins_type, "332") == 0 || strcmp(sIins_type, "114") == 0 ||
                 strcmp(sIins_type, "132") == 0 || strcmp(sIins_type, "134") == 0 ||
                 strcmp(sIins_type, "532") == 0) /***  32,37,78�I��  ***/
        {
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 3, sNins_type);
            /*if (strstr(provision, "H"))*/
            if (IsProvExist("H", provision) == TRUE)
            {
                insert_tmp_table(iPg, BASE_LINE + iLineCount, 10, "      �Ұ���O��");
                hTmp++;
            }
            /*if (strstr(provision, "D"))*/
            if (IsProvExist("D", provision) == TRUE)
            {
                if (hTmp == 0)
                    insert_tmp_table(iPg, BASE_LINE + iLineCount, 10, "      ���w�r�p�H");
                else
                    insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 3, "      ���w�r�p�H");
            }
            /*if (strstr(provision, "J"))*/
            if (IsProvExist("J", provision) == TRUE)
            {
                if (hTmp == 0)
                    insert_tmp_table(iPg, BASE_LINE + iLineCount, 10, "�S�w�γ~�[�T�w�ϥΤH");
                else
                    insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 3, "�S�w�γ~�[�T�w�ϥΤH");
            }
        }
        else if (strcmp(sIins_type, "178") == 0)
        {
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 3, sNins_type);
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 10, "�C�@�N�~�ƬG�d��");
            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 3, "�ֿn�̰����v���B");
        }             
        else if (strcmp(sIins_type, "51") == 0)
        {
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 3, sNins_type);
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 10, "    �C�@�ӤH���");
            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 3, "    �C�@�ӤH���`");
            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 10, "    �C�@�ƬG�`�B");
        }
        else if (strcmp(sIins_type, "24") == 0 || strcmp(sIins_type, "88") == 0)
        {
            iQcoverage = 1;
            if (f1000406[0] == '0')
                insert_tmp_table(iPg, BASE_LINE + iLineCount, 3, "���s���v�T���ר��`");
            else
                insert_tmp_table(iPg, BASE_LINE + iLineCount, 3, sNins_type);
            /*if (strstr(provision, "D"))*/
            if (IsProvExist("D", provision) == TRUE)
                insert_tmp_table(iPg, BASE_LINE + iLineCount, 10, "      ���w�r�p�H");
        }
        else if (strcmp(sIins_type, "52")  == 0 || strcmp(sIins_type, "53")  == 0 ||
                 strcmp(sIins_type, "55")  == 0 || strcmp(sIins_type, "117") == 0 ||
                 strcmp(sIins_type, "135") == 0 || strcmp(sIins_type, "555") == 0 ||
                 strcmp(sIins_type, "252") == 0 || strcmp(sIins_type, "253") == 0)
        {

            iQcoverage = 2;
            if (strcmp(sIins_type, "52") == 0 || strcmp(sIins_type, "252") == 0)
            {
                if (fcar_class[0] == '1') /* �ۥ� */
                    insert_tmp_table(iPg, BASE_LINE + iLineCount, 3, "���D�d�����[����");
                else /* ��~ */
                    insert_tmp_table(iPg, BASE_LINE + iLineCount, 3, "�T�����D�d���O�I");
            }
            else
                insert_tmp_table(iPg, BASE_LINE + iLineCount, 3, sNins_type);
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 10, " �C�@�ӤH�ˮ`");
            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 3, " �C�@�N�~�ƬG���ˮ`");
            /*if (strstr(provision, "D"))*/
            if (IsProvExist("D", provision) == TRUE)
                insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 10, "      ���w�r�p�H");
            
        }
        else if (strcmp(sIins_type, "80") == 0 || strcmp(sIins_type, "89") == 0 ||
                 strcmp(sIins_type, "90") == 0)
        {
            iQcoverage = 2;
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 3, sNins_type);
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 10, " �ˮ`�����O�I��");
            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 3, " ���`�Υ���O�I��");
            /*if (strstr(provision, "D"))*/
            if (IsProvExist("D", provision) == TRUE)
                insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 10, "      ���w�r�p�H");
        }
        else if (strcmp(sIins_type, "57") == 0 || strcmp(sIins_type, "59") == 0 ||
                 strcmp(sIins_type, "60") == 0) /* car9801122 �T���ȹB�~�����I(57,59,60), add by Julia in 2009/01/20 */
        {

            insert_tmp_table(iPg, BASE_LINE + iLineCount, 3, sNins_type);
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 10, "    �C�@�ӤH�ˮ`");
            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 3, "    �C�@�ӤH���`����");
            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 10, "    �C�@�ƬG�`�B");
            /*if (strstr(provision, "D"))*/
            if (IsProvExist("D", provision) == TRUE)
                insert_tmp_table(iPg, BASE_LINE + iLineCount + 2, 3, "      ���w�r�p�H");
        }
        else if (strcmp(sIins_type, "85") == 0)
        {
            jTmp = 0;
            insert_tmp_table(iPg, BASE_LINE + iLineCount + (jTmp / 2), (jTmp % 2 == 0) ? 3 : 10, "�K�ۭt�B�T������I");
            jTmp++;
            insert_tmp_table(iPg, BASE_LINE + iLineCount + (jTmp / 2), (jTmp % 2 == 0) ? 3 : 10, "�������l��");
            jTmp++;

            insert_tmp_table(iPg, BASE_LINE + iLineCount + (jTmp / 2), (jTmp % 2 == 0) ? 3 : 10, "�@�먮�l");
            jTmp++;
            insert_tmp_table(iPg, BASE_LINE + iLineCount + (jTmp / 2), (jTmp % 2 == 0) ? 3 : 10, "�������l�֭p���v���B");
            jTmp++;

            if (IsProvExist("D", provision) == TRUE)
            {
                insert_tmp_table(iPg, BASE_LINE + iLineCount + (jTmp / 2), (jTmp % 2 == 0) ? 3 : 10, "      ���w�r�p�H");
                jTmp++;
            }

            if (IsProvExist("S", provision) == TRUE)
            {
                insert_tmp_table(iPg, BASE_LINE + iLineCount + (jTmp / 2), (jTmp % 2 == 0) ? 3 : 10, "      ���[����������");
                jTmp++;
            }
        }
        else if (strcmp(sIins_type, "105") == 0 || strcmp(sIins_type, "118") == 0)
        {
            jTmp = 0;
            if (strcmp(sIins_type, "105") == 0)
            {
                insert_tmp_table(iPg, BASE_LINE + iLineCount + (jTmp / 2), (jTmp % 2 == 0) ? 3 : 10, "�T���ߦw����l���O");
                jTmp++;
                insert_tmp_table(iPg, BASE_LINE + iLineCount + (jTmp / 2), (jTmp % 2 == 0) ? 3 : 10, "�I");
                jTmp++;
            }
            else if (strcmp(sIins_type, "118") == 0)
            {
                insert_tmp_table(iPg, BASE_LINE + iLineCount + (jTmp / 2), (jTmp % 2 == 0) ? 3 : 10, "�T���ߦw����l���O");
                jTmp++;
                insert_tmp_table(iPg, BASE_LINE + iLineCount + (jTmp / 2), (jTmp % 2 == 0) ? 3 : 10, "�I(A��)");
                jTmp++;
            }

            insert_tmp_table(iPg, BASE_LINE + iLineCount + (jTmp / 2), (jTmp % 2 == 0) ? 3 : 10, "�@�먮�l");
            jTmp++;
            insert_tmp_table(iPg, BASE_LINE + iLineCount + (jTmp / 2), (jTmp % 2 == 0) ? 3 : 10, "�������l�֭p���v���B");
            jTmp++;

            if (IsProvExist("D", provision) == TRUE)
            {
                insert_tmp_table(iPg, BASE_LINE + iLineCount + (jTmp / 2), (jTmp % 2 == 0) ? 3 : 10, "      ���w�r�p�H");
                jTmp++;
            }

            if (IsProvExist("S", provision) == TRUE)
            {
                insert_tmp_table(iPg, BASE_LINE + iLineCount + (jTmp / 2), (jTmp % 2 == 0) ? 3 : 10, "      ���[����������");
                jTmp++;
            }
        }
        else if (strcmp(sIins_type, "26") == 0)
        {
            jTmp = 0;
            insert_tmp_table(iPg, BASE_LINE + iLineCount + (jTmp / 2), (jTmp % 2 == 0) ? 3 : 10, "�нm���ϥγd���I");
            jTmp++;
            insert_tmp_table(iPg, BASE_LINE + iLineCount + (jTmp / 2), (jTmp % 2 == 0) ? 3 : 10, "(�]�l+���)");
            jTmp++;
        }
        /* 1000225003 �D���ϴ��O�θ��v�O�I�s�ӫ~�t�λݨD */
        else if (strcmp(sIins_type, "38") == 0 || strcmp(sIins_type, "39") == 0)
        {
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 3, sNins_type);
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 10, "    ��Q���{");

            if (IsProvExist("D", provision) == TRUE)
                insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 3, "      ���w�r�p�H");
        }
        else if (strcmp(sIins_type, "238") == 0 || strcmp(sIins_type, "237") == 0) /*1100119001_SC2 �s�W-�s�ӫ~(238�I-�D���ϴ��O�Ϊ��[����)�������ˮ֤Ϊ���*/
        {
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 3, sNins_type);
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 10, "    �C�@�ƬG");
            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 3, "    �O�I����");

            if (strcmp(sIins_type, "238") == 0)
            {
                insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 10, "    ��Q���{");
            }

            if (IsProvExist("D", provision) == TRUE)
                insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 3, "      ���w�r�p�H");
        }
        else if (strcmp(sIins_type, "164") == 0 || strcmp(sIins_type, "165") == 0) /* 1070813004_SC2 �s�W164�B165�d���O�I�ӫ~(�Щ�9�뤤�e�����A�tE�O���B���s�BB2B�BB2C�B��O�J�p)(���) */
        {
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 3, sNins_type);
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 10, " �C�@�N�~�ƬG���`�B");
        }   
        else if (iQcoverage == 3)
        {
            sprintf_s(sTmpBuf, sizeof sTmpBuf, "%s%s", sNins_type, "  ���");
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 3, sNins_type);
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 10, "        ���`");
            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 3, "        �`�B");

            if (IsProvExist("D", provision) == TRUE)
                insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 10, "      ���w�r�p�H");
        }
        else if (iQcoverage == 2)
        {
            /*1081205009_SC2 47�I�رq�D�I�אּ���[�I*/
            printf("-- trace sNins_type[%s]\n ", sNins_type);
            if (strcmp(sIins_type, "47") == 0)
            {
                printf("-- trace sDrate_ym[%s]\n ", sDrate_ym);
                if (atoi(sDrate_ym) >= 111)
                {
                    strcpy(sNins_type, "�����j���I�r�˪��[�I");
                }
                else
                {
                    strcpy(sNins_type, "�����r�p�H�ˮ`�O�I");
                }
            }
            sprintf_s(sTmpBuf, sizeof sTmpBuf, "%s%s", sNins_type, "  ���");
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 3, sNins_type);
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 10, "        �`�B");

            if (IsProvExist("D", provision) == TRUE)
                insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 3, "      ���w�r�p�H");
        }
        else if ((strcmp(sIins_type, "05")  == 0) || (strcmp(sIins_type, "09")  == 0) ||
                 (strcmp(sIins_type, "23")  == 0) ||
                 (strcmp(sIins_type, "205") == 0) || (strcmp(sIins_type, "209") == 0))

        {
            jTmp = 0;
            insert_tmp_table(iPg, BASE_LINE + iLineCount + (jTmp / 2), (jTmp % 2 == 0) ? 3 : 10, sNins_type);
            jTmp++;

            if (IsProvExist("H", provision) == TRUE)
            {
                insert_tmp_table(iPg, BASE_LINE + iLineCount + (jTmp / 2), (jTmp % 2 == 0) ? 3 : 10, "      �Ұ���O��");
                jTmp++;
            }

            if (IsProvExist("D", provision) == TRUE)
            {
                insert_tmp_table(iPg, BASE_LINE + iLineCount + (jTmp / 2), (jTmp % 2 == 0) ? 3 : 10, "      ���w�r�p�H");
                jTmp++;
            }

            if (IsProvExist("J", provision) == TRUE)
            {
                insert_tmp_table(iPg, BASE_LINE + iLineCount + (jTmp / 2), (jTmp % 2 == 0) ? 3 : 10, "�S�w�γ~�[�T�w�ϥΤH");
                jTmp++;
            }

            if (IsProvExist("S", provision) == TRUE)
            {
                insert_tmp_table(iPg, BASE_LINE + iLineCount + (jTmp / 2), (jTmp % 2 == 0) ? 3 : 10, "      ���[����������");
                jTmp++;
            }
            AddLine = jTmp / 2;
        }
        else
        {
            jTmp = 0;
            insert_tmp_table(iPg, BASE_LINE + iLineCount + (jTmp / 2), (jTmp % 2 == 0) ? 3 : 10, sNins_type);
            jTmp++;

            if (IsProvExist("D", provision) == TRUE)
            {
                insert_tmp_table(iPg, BASE_LINE + iLineCount + (jTmp / 2), (jTmp % 2 == 0) ? 3 : 10, "      ���w�r�p�H");
                jTmp++;
            }

            if (IsProvExist("J", provision) == TRUE)
            {
                insert_tmp_table(iPg, BASE_LINE + iLineCount + (jTmp / 2), (jTmp % 2 == 0) ? 3 : 10, "�S�w�γ~�[�T�w�ϥΤH");
                jTmp++;
            }

            if (IsProvExist("S", provision) == TRUE)
            {
                insert_tmp_table(iPg, BASE_LINE + iLineCount + (jTmp / 2), (jTmp % 2 == 0) ? 3 : 10, "      ���[����������");
                jTmp++;
            }
            AddLine = jTmp / 2;
        }

        /**** �O�B��[/����O ****/

        /* 1000225003 �D���ϴ��O�θ��v�O�I�s�ӫ~�t�λݨD */
        if (strcmp(sIins_type, "38") == 0 || strcmp(sIins_type, "39") == 0)
        {
            if (qday > 0) /* ��Q���{ */
                strcpy(sTmpBuf, "+");
            else if (qday == 0)
                strcpy(sTmpBuf, " ");
            else
                strcpy(sTmpBuf, "-");
        }
        else if (iMedrdmg_cover > 0)
            strcpy(sTmpBuf, "+");
        else if (iMedrdmg_cover == 0)
        {
            if (iMedrinj_cover > 0)
                strcpy(sTmpBuf, "+");
            else if (iMedrinj_cover == 0)
                strcpy(sTmpBuf, " ");
            else
                strcpy(sTmpBuf, "-");
        }
        else
            strcpy(sTmpBuf, "-");

        if (insurance_cover_count != 0)
        {
        }
        else if (strcmp(sIins_type, "31")  == 0 || strcmp(sIins_type, "231") == 0 ||
                 strcmp(sIins_type, "331") == 0 || strcmp(sIins_type, "113") == 0 ||
                 strcmp(sIins_type, "131") == 0 || strcmp(sIins_type, "133") == 0 ||
                 strcmp(sIins_type, "145") == 0 || strcmp(sIins_type, "531") == 0) /*** 31,36,77�I�� ***/
        {
            if (iMedrinj_cover > 0)
                strcpy(sTmpBuf, "+");
            else if (iMedrinj_cover < 0)
                strcpy(sTmpBuf, "-");
            else if (iMedrinj_cover == 0)
                strcpy(sTmpBuf, " ");            
               
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 11, sTmpBuf);

            if (iMedrdmg_cover > 0)
                strcpy(sTmpBuf, "+");
            else if (iMedrdmg_cover < 0)
                strcpy(sTmpBuf, "-");
            else if (iMedrdmg_cover == 0)
                strcpy(sTmpBuf, " ");

            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 4, sTmpBuf);
        }
        else if (strcmp(sIins_type, "178") == 0)
        {
            if (iMedrinj_cover > 0)
                strcpy(sTmpBuf, "+");
            else if (iMedrinj_cover < 0)
                strcpy(sTmpBuf, "-");
            else if (iMedrinj_cover == 0)
                strcpy(sTmpBuf, " ");            
               
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 11, sTmpBuf);

            if (iMedrdmg_cover > 0)
                strcpy(sTmpBuf, "+");
            else if (iMedrdmg_cover < 0)
                strcpy(sTmpBuf, "-");
            else if (iMedrdmg_cover == 0)
                strcpy(sTmpBuf, " ");

            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 4, sTmpBuf);
        }        
        else if (strcmp(sIins_type, "146") == 0)
        {
            if (iMedrdmg_cover > 0)
                strcpy(sTmpBuf, "+");
            else if (iMedrdmg_cover < 0)
                strcpy(sTmpBuf, "-");
            else if (iMedrdmg_cover == 0)
                strcpy(sTmpBuf, " ");

            insert_tmp_table(iPg, BASE_LINE + iLineCount, 11, sTmpBuf);

            if (mcover_limit > 0)
                strcpy(sTmpBuf, "+");
            else if (mcover_limit < 0)
                strcpy(sTmpBuf, "-");
            else if (mcover_limit == 0)
                strcpy(sTmpBuf, " ");

            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 4, sTmpBuf);
        }
        else if (strcmp(sIins_type, "32")  == 0 || strcmp(sIins_type, "232") == 0 ||
                 strcmp(sIins_type, "332") == 0 || strcmp(sIins_type, "114") == 0 ||
                 strcmp(sIins_type, "132") == 0 || strcmp(sIins_type, "134") == 0 ||
                 strcmp(sIins_type, "532") == 0) /*** 32,37,78�I�� ***/
        {
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 4, sTmpBuf);
        }
        else if (strcmp(sIins_type, "51") == 0)
        {
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 11, sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 4, sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 11, sTmpBuf);
        }
        else if (strcmp(sIins_type, "52")  == 0 ||
                 strcmp(sIins_type, "53")  == 0 ||
                 strcmp(sIins_type, "55")  == 0 ||
                 strcmp(sIins_type, "555") == 0 ||
                 strcmp(sIins_type, "117") == 0 ||
                 strcmp(sIins_type, "135") == 0 ||
                 strcmp(sIins_type, "252") == 0 ||
                 strcmp(sIins_type, "253") == 0)
        {
            if (f1000406[0] == '0')
            {
                insert_tmp_table(iPg, BASE_LINE + iLineCount, 11, sTmpBuf);
                insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 4, sTmpBuf);
                insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 11, sTmpBuf);
            }
            else
            {
                insert_tmp_table(iPg, BASE_LINE + iLineCount, 11, sTmpBuf);
                insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 4, sTmpBuf);
            }
        }
        else if (strcmp(sIins_type, "80") == 0 || strcmp(sIins_type, "89") == 0 ||
                 strcmp(sIins_type, "90") == 0)
        {
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 11, sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 4, sTmpBuf);
        }
        else if (strcmp(sIins_type, "57") == 0 || strcmp(sIins_type, "59") == 0 ||
                 strcmp(sIins_type, "60") == 0) /* car9801122 �T���ȹB�~�����I(57,59,60), add by Julia in 2009/01/20 */
        {
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 11, sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 4, sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 11, sTmpBuf);
        }
        else if (strcmp(sIins_type, "85") == 0 || strcmp(sIins_type, "105") == 0 || strcmp(sIins_type, "118") == 0) /* car9810133 �s�W85�I�� */
        {
            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 4, sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 11, sTmpBuf);
        }
        /* 1000225003 �D���ϴ��O�θ��v�O�I�s�ӫ~�t�λݨD */
        else if (strcmp(sIins_type, "38") == 0 || strcmp(sIins_type, "39") == 0)
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 11, sTmpBuf);
        else if (strcmp(sIins_type, "238") == 0||strcmp(sIins_type, "237") == 0) /*1100119001_SC2 �s�W-�s�ӫ~(238�I-�D���ϴ��O�Ϊ��[����)�������ˮ֤Ϊ���*/
        {
            if (iMedrinj_cover > 0)
                strcpy(sTmpBuf, "+");
            else if (iMedrinj_cover < 0)
                strcpy(sTmpBuf, "-");
            else if (iMedrinj_cover == 0)
                strcpy(sTmpBuf, " ");

            insert_tmp_table(iPg, BASE_LINE + iLineCount, 11, sTmpBuf);

            if (iMedrdmg_cover > 0)
                strcpy(sTmpBuf, "+");
            else if (iMedrdmg_cover < 0)
                strcpy(sTmpBuf, "-");
            else if (iMedrdmg_cover == 0)
                strcpy(sTmpBuf, " ");

            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 4, sTmpBuf);

            if (strcmp(sIins_type, "238") == 0)
            {
                if (qday > 0) /* ��Q���{ */
                    strcpy(sTmpBuf, "+");
                else if (qday == 0)
                    strcpy(sTmpBuf, " ");
                else
                    strcpy(sTmpBuf, "-");

                insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 11, sTmpBuf);
            }
        }
        else if (iQcoverage == 3)
        {
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 4, sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 11, sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 4, sTmpBuf);
        }
        else if (iQcoverage == 2)
        {
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 4, sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 11, sTmpBuf);
        }
        else
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 4, sTmpBuf);

        /* *** �O�I���B *** */
        if (insurance_cover_count != 0)
        {
        }
        else if (strcmp(sIins_type, "31")  == 0 || strcmp(sIins_type, "231") == 0 ||
                 strcmp(sIins_type, "331") == 0 || strcmp(sIins_type, "113") == 0 ||
                 strcmp(sIins_type, "131") == 0 || strcmp(sIins_type, "133") == 0 ||
                 strcmp(sIins_type, "145") == 0 || strcmp(sIins_type, "178") == 0 ||
                 strcmp(sIins_type, "531") == 0)
        {
            iMedrinj_cover = labs(iMedrinj_cover);
            rfmtlong(iMedrinj_cover, "-,---,---,--&", sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 12, sTmpBuf);
            iMedrdmg_cover = labs(iMedrdmg_cover);
            rfmtlong(iMedrdmg_cover, "-,---,---,--&", sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 5, sTmpBuf);
        }
        else if (strcmp(sIins_type, "146") == 0)
        {
            iMedrdmg_cover = labs(iMedrdmg_cover);
            rfmtlong(iMedrdmg_cover, "-,---,---,--&", sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 12, sTmpBuf);

            mcover_limit = labs(mcover_limit);
            rfmtlong(mcover_limit, "-,---,---,--&", sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 5, sTmpBuf);
        }
        else if (strcmp(sIins_type, "32")  == 0 || strcmp(sIins_type, "232") == 0 ||
                 strcmp(sIins_type, "332") == 0 || strcmp(sIins_type, "114") == 0 ||
                 strcmp(sIins_type, "132") == 0 || strcmp(sIins_type, "134") == 0 ||
                 strcmp(sIins_type, "532") == 0)
        {
            iMedrdmg_cover = labs(iMedrdmg_cover);
            rfmtlong(iMedrdmg_cover, "-,---,---,--&", sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 5, sTmpBuf);
        }
        else if (strcmp(sIins_type, "51") == 0)
        {
            iMedrinj_cover = labs(iMedrinj_cover);
            rfmtlong(iMedrinj_cover, "-,---,---,--&", sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 12, sTmpBuf);

            iMedrdea_cover = labs(iMedrdea_cover);
            rfmtlong(iMedrdea_cover, "-,---,---,--&", sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 5, sTmpBuf);

            iMedrdmg_cover = labs(iMedrdmg_cover);
            rfmtlong(iMedrdmg_cover, "-,---,---,--&", sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 12, sTmpBuf);
        }
        else if (strcmp(sIins_type, "52")  == 0 ||
                 strcmp(sIins_type, "53")  == 0 ||
                 strcmp(sIins_type, "55")  == 0 ||
                 strcmp(sIins_type, "555") == 0 ||
                 strcmp(sIins_type, "117") == 0 ||
                 strcmp(sIins_type, "135") == 0 ||
                 strcmp(sIins_type, "252") == 0 ||
                 strcmp(sIins_type, "253") == 0)
        {
            if (f1000406[0] == '0')
            {
                iMedrinj_cover = labs(iMedrinj_cover);
                rfmtlong(iMedrinj_cover, "-,---,---,--&", sTmpBuf);
                insert_tmp_table(iPg, BASE_LINE + iLineCount, 12, sTmpBuf);

                iMedrdea_cover = labs(iMedrdea_cover);
                rfmtlong(iMedrdea_cover, "-,---,---,--&", sTmpBuf);
                insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 5, sTmpBuf);

                iMedrdmg_cover = labs(iMedrdmg_cover);
                rfmtlong(iMedrdmg_cover, "-,---,---,--&", sTmpBuf);
                insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 12, sTmpBuf);
            }
            else
            {
                iMedrdea_cover = labs(iMedrdea_cover);
                rfmtlong(iMedrdea_cover, "-,---,---,--&", sTmpBuf);
                insert_tmp_table(iPg, BASE_LINE + iLineCount, 12, sTmpBuf);

                iMedrdmg_cover = labs(iMedrdmg_cover);
                rfmtlong(iMedrdmg_cover, "-,---,---,--&", sTmpBuf);
                insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 5, sTmpBuf);
            }
        }
        else if (strcmp(sIins_type, "80") == 0 || strcmp(sIins_type, "89") == 0 ||
                 strcmp(sIins_type, "90") == 0)
        {
            iMedrinj_cover = labs(iMedrinj_cover);
            rfmtlong(iMedrinj_cover, "-,---,---,--&", sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 12, sTmpBuf);

            iMedrdmg_cover = labs(iMedrdmg_cover);
            rfmtlong(iMedrdmg_cover, "-,---,---,--&", sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 5, sTmpBuf);
        }
        else if (strcmp(sIins_type, "57") == 0 || strcmp(sIins_type, "59") == 0 ||
                 strcmp(sIins_type, "60") == 0) /* car9801122 �T���ȹB�~�����I(57,59,60), add by Julia in 2009/01/20 */
        {

            iMedrinj_cover = labs(iMedrinj_cover);
            rfmtlong(iMedrinj_cover, "-,---,---,--&", sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 12, sTmpBuf);
            iMedrdea_cover = labs(iMedrdea_cover);
            rfmtlong(iMedrdea_cover, "-,---,---,--&", sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 5, sTmpBuf);
            iMedrdmg_cover = labs(iMedrdmg_cover);
            rfmtlong(iMedrdmg_cover, "-,---,---,--&", sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 12, sTmpBuf);
        }
        else if (strcmp(sIins_type, "85") == 0 || strcmp(sIins_type, "105") == 0 || strcmp(sIins_type, "118") == 0) /* car9810133 �s�W85�I�� */
        {
            iMedrdmg_cover = labs(iMedrdmg_cover);
            rfmtlong(iMedrdmg_cover, "-,---,---,--&", sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 5, sTmpBuf);
            iMedrinj_cover = labs(iMedrinj_cover);
            rfmtlong(iMedrinj_cover, "-,---,---,--&", sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 12, sTmpBuf);
        }
        /* 1000225003 �D���ϴ��O�θ��v�O�I�s�ӫ~�t�λݨD */
        else if (strcmp(sIins_type, "38") == 0 || strcmp(sIins_type, "39") == 0)
        {
            qday = labs(qday);
            rfmtlong(qday, "---,--&", sTmpBuf);
            strcat(sTmpBuf, "����");
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 12, sTmpBuf);
        }
        /*1100119001_SC2 �s�W-�s�ӫ~(238�I-�D���ϴ��O�Ϊ��[����)�������ˮ֤Ϊ���*/
        else if (strcmp(sIins_type, "238") == 0 || strcmp(sIins_type, "237") == 0)
        {
            iMedrinj_cover = labs(iMedrinj_cover);
            rfmtlong(iMedrinj_cover, "--,---,--&", sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 12, sTmpBuf);
            iMedrdmg_cover = labs(iMedrdmg_cover);
            rfmtlong(iMedrdmg_cover, "--,---,--&", sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 5, sTmpBuf);

            if (strcmp(sIins_type, "238") == 0)
            {
                qday = labs(qday);
                if (qday == 899 || qday == 999)
                { /*1101229013_SC2 �s�W238�I�ؤ������{�O�v*/
                    strcpy(sTmpBuf, "  ��������");
                }
                else
                {
                    rfmtlong(qday, "---,--&", sTmpBuf);
                    strcat(sTmpBuf, "����");
                }
                insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 12, sTmpBuf);
            }
        }
        else if (iQcoverage == 3)
        { /* ���,���`,�`�B */
            iMedrinj_cover = labs(iMedrinj_cover);
            rfmtlong(iMedrinj_cover, "-,---,---,--&", sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 5, sTmpBuf);
            iMedrdea_cover = labs(iMedrdea_cover);
            rfmtlong(iMedrdea_cover, "-,---,---,--&", sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 12, sTmpBuf);
            iMedrdmg_cover = labs(iMedrdmg_cover);
            rfmtlong(iMedrdmg_cover, "-,---,---,--&", sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount + 1, 5, sTmpBuf);
        }
        else if (iQcoverage == 2)
        { /* ���,�`�B */
            iMedrinj_cover = labs(iMedrinj_cover);
            rfmtlong(iMedrinj_cover, "-,---,---,--&", sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 5, sTmpBuf);
            iMedrdmg_cover = labs(iMedrdmg_cover);
            rfmtlong(iMedrdmg_cover, "-,---,---,--&", sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 12, sTmpBuf);
        }
        else if (iQcoverage == 1)
        { /* �`�B */
            iMedrdmg_cover = labs(iMedrdmg_cover);
            rfmtlong(iMedrdmg_cover, "-,---,---,--&", sTmpBuf);
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 5, sTmpBuf);
        }

        /* *** �ۭt�B *** */
        printf("{ca401_data2.0010}:iMdeduct[%d]\n", iMdeduct);
        if (insurance_cover_count != 0)
        {
        }
        else if (iMdeduct != 0 && fdeduct[0] != '0')
        {
            if (strcmp(sIins_type, "01")  == 0 || strcmp(sIins_type, "05")  == 0 ||
                strcmp(sIins_type, "201") == 0 || strcmp(sIins_type, "205") == 0 ||
                strcmp(sIins_type, "86")  == 0 || strcmp(sIins_type, "23")  == 0 || strcmp(sIins_type, "110") == 0 || 
                strcmp(sIins_type, "131") == 0 || strcmp(sIins_type, "132") == 0 ||
                strcmp(sIins_type, "331") == 0 || strcmp(sIins_type, "332") == 0 )   
            {	
                if (iMdeduct < 0)
                {
                    stmt_buf[0] = '\0';
                    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s, %s:%s WHERE %s ",
                            " a.icar_type, min(b.drate_ym) ",
                            sFullDBName, "ply_relation_bak a ",
                            sFullDBName, "ply_ins_type_bak b ",
                            " a.iendorse = ? AND a.iendorse = b.iendorse GROUP BY a.icar_type ");
                    printf("%s\n", stmt_buf);
                    $PREPARE cur_J FROM $stmt_buf;
                    $EXECUTE cur_J INTO $sIcar_type, $sDrate_ym USING $p_sIendorse;
                    
                    if (SQLCODE == SQLNOTFOUND)
                    {
                        printf("{ca401_data2.0041}:select ply_relation_bak not found!!\n");
                        printf("{ca401_data2.0041}:select ori_ply_relation !!\n");
                        stmt_buf[0] = '\0';
                        sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s, %s:%s WHERE %s %s %s %s ",
                                " a.icar_type, min(b.drate_ym) ",
                                sFullDBName, "ori_ply_relation a ",
                                sFullDBName, "ori_ins_type b ",
                                " a.ipolicy=(SELECT ipolicy FROM ",
                                sFullDBName,
                                ":edr_relation WHERE iendorse=?)",
                                " AND a.ipolicy = b.ipolicy GROUP BY a.icar_type ");

                        printf("%s\n", stmt_buf);
                        $PREPARE cur_K FROM $stmt_buf;
                        $EXECUTE cur_K INTO $sIcar_type, $sDrate_ym USING $p_sIendorse;
                        
                        if (SQLCODE == SQLNOTFOUND)
                        {
                            $FREE cur_K;
                            return M_CA_NENDORSE;
                        }    
                        $FREE cur_K;
                    }
                    $FREE cur_J;
                    strcpy(sIcar_type, TRANS_CAR_TYPE(sIcar_type, sDrate_ym));
                    memset(tmp1Deduct, 0, sizeof(tmp1Deduct));
                    iMdeduct = labs(iMdeduct);
                    sprintf_s(tmpDeduct, sizeof tmpDeduct, "%d", iMdeduct);

                    printf("Iins_type 01/05/08 Deduct ==>[%s]\n", tmpDeduct);

                    $SELECT prn_deduct INTO $tmp1Deduct
                       FROM ca_dmg_mdeduct
                      WHERE icar_type = $sIcar_type
                        AND ideduct = $tmpDeduct;
                    if (strcmp(tmpDeduct, "8") == 0)
                        strcpy(sDeduct, tmp1Deduct);
                    else
                    {
                        strcpy(sDeduct, "-");
                        strcat(sDeduct, tmp1Deduct);
                    }
                }
                else
                {
                    stmt_buf[0] = '\0';
                    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s, %s:%s WHERE %s ",
                            " a.icar_type, min(b.drate_ym) ",
                            sFullDBName, "ply_relation_bak a ",
                            sFullDBName, "ply_ins_type_bak b ",
                            " a.iendorse = ? AND a.iendorse = b.iendorse GROUP BY a.icar_type ");
                    printf("%s\n", stmt_buf);
                    $PREPARE cur_L FROM $stmt_buf;
                    $EXECUTE cur_L INTO $sIcar_type, $sDrate_ym USING $p_sIendorse;
                    
                    if (SQLCODE == SQLNOTFOUND)
                    {
                        printf("{ca401_data2.0041}:select ply_relation_bak not found!!\n");
                        printf("{ca401_data2.0041}:select ori_ply_relation !!\n");
                        stmt_buf[0] = '\0';
                        sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s, %s:%s WHERE %s %s %s %s",
                                " a.icar_type, min(b.drate_ym) ",
                                sFullDBName, "ori_ply_relation a ",
                                sFullDBName, "ori_ins_type b ",
                                " a.ipolicy=(SELECT ipolicy FROM ",
                                sFullDBName,
                                ":edr_relation WHERE iendorse=?)",
                                " AND a.ipolicy = b.ipolicy GROUP BY a.icar_type ");
                        $PREPARE cur_M FROM $stmt_buf;
                        $EXECUTE cur_M INTO $sIcar_type, $sDrate_ym USING $p_sIendorse;
                        
                        if (SQLCODE == SQLNOTFOUND)
                        {
                            $FREE cur_M;
                            return M_CA_NENDORSE;
                        }    
                        $FREE cur_M;
                    }
                    $FREE cur_L;
                    strcpy(sIcar_type, TRANS_CAR_TYPE(sIcar_type, sDrate_ym));

                    memset(tmp1Deduct, 0, sizeof(tmp1Deduct));
                    iMdeduct = labs(iMdeduct);
                    sprintf_s(tmpDeduct, sizeof tmpDeduct, "%d", iMdeduct);

                    printf("Iins_type 01/05/08 Deduct ==>[%s]\n", tmpDeduct);
                    
                    $SELECT prn_deduct INTO $tmp1Deduct
                       FROM ca_dmg_mdeduct
                      WHERE icar_type = $sIcar_type
                        AND ideduct = $tmpDeduct;                                       
                    if (strcmp(tmpDeduct, "8") == 0)
                        strcpy(sDeduct, tmp1Deduct);
                    else
                    {
                        strcpy(sDeduct, "+");
                        strcat(sDeduct, tmp1Deduct);
                    }
                }
            }
            else
            {
                strcpy(iMdeduct_c, itoa(iMdeduct));          /**** peter 03.23.1999 ****/
                iMdeduct_l = atol(iMdeduct_c);               /**** peter 03.23.1999 ****/
                rfmtlong(iMdeduct_l, "--,---,--&", sDeduct); /**** peter 03.23.1999 ****/             
            }

            printf("{ca401_data2.0030}:sIcar_type[%s],iMdeduct[%d],tmpDeduct[%s],sDeduct[%s]\n", sIcar_type, iMdeduct, tmpDeduct, sDeduct);

            insert_tmp_table(iPg, BASE_LINE + iLineCount, 6, sDeduct);
        }

        if ((strcmp(trim(sFcomp_24), "Y") == 0) && (strcmp(sIins_type, "24") == 0))
        {
            strcpy(sTmpBuf, "(�[�j)");
            insert_tmp_table(iPg, BASE_LINE + iLineCount, 6, sTmpBuf);
        }

        /* *** �O�O��[/����O *** */
        if (iMedrins_prem > 0)
            strcpy(sTmpBuf, "+");
        else if (iMedrins_prem == 0)
            strcpy(sTmpBuf, " ");
        else
            strcpy(sTmpBuf, "-");

        insert_tmp_table(iPg, BASE_LINE + iLineCount, 7, sTmpBuf);

        /* *** �O�O *** */
        iMedrins_prem = labs(iMedrins_prem);
        rfmtlong(iMedrins_prem, "--,---,--&", sTmpBuf);
        insert_tmp_table(iPg, BASE_LINE + iLineCount, 8, sTmpBuf);

        if (strcmp(trim(sIins_type), "31")  == 0 || strcmp(trim(sIins_type), "231") == 0 ||
            strcmp(trim(sIins_type), "331") == 0 || strcmp(trim(sIins_type), "113") == 0 ||
            strcmp(trim(sIins_type), "131") == 0 || strcmp(trim(sIins_type), "133") == 0 ||
            strcmp(trim(sIins_type), "178") == 0 || strcmp(trim(sIins_type), "531") == 0) /*** 31,36,77�I�� ***/
        {
            iQcoverage = 2;
        }
        else if (strcmp(trim(sIins_type), "32")  == 0 || strcmp(trim(sIins_type), "232") == 0 ||
                 strcmp(trim(sIins_type), "332") == 0 || strcmp(trim(sIins_type), "114") == 0 ||
                 strcmp(trim(sIins_type), "132") == 0 || strcmp(trim(sIins_type), "134") == 0 ||
                 strcmp(trim(sIins_type), "532") == 0) /*** 32,37,78�I�� ***/
        {
            iQcoverage = 1;
        }
        else if (strcmp(trim(sIins_type), "51") == 0 || strcmp(sIins_type, "237") == 0)
        {
            iQcoverage = 2;
        }
        else if (strcmp(trim(sIins_type), "52")  == 0 ||
                 strcmp(trim(sIins_type), "53")  == 0 ||
                 strcmp(trim(sIins_type), "55")  == 0 ||
                 strcmp(trim(sIins_type), "555") == 0 ||
                 strcmp(trim(sIins_type), "117") == 0 ||
                 strcmp(trim(sIins_type), "135") == 0 ||
                 strcmp(trim(sIins_type), "252") == 0 ||
                 strcmp(trim(sIins_type), "253") == 0 )
        {
            if (f1000406[0] == '0')
                iQcoverage = 3;
            else
                iQcoverage = 2;
        }
        else if (strcmp(sIins_type, "80") == 0 || strcmp(sIins_type, "89") == 0 ||
                 strcmp(sIins_type, "90") == 0)
            iQcoverage = 2;
        else if (strcmp(trim(sIins_type), "34") == 0 || strcmp(trim(sIins_type), "87") == 0 || strcmp(trim(sIins_type), "115") == 0) /*** 34�I�� ***/
            iQcoverage = 3;
        else if (strcmp(trim(sIins_type), "85") == 0 || strcmp(trim(sIins_type), "105") == 0 || strcmp(trim(sIins_type), "118") == 0) /*** 85�I�� ***/
            iQcoverage = 3;
        else if (strcmp(sIins_type, "238") == 0) /*1100119001_SC2 �s�W-�s�ӫ~(238�I-�D���ϴ��O�Ϊ��[����)�������ˮ֤Ϊ���*/
            iQcoverage = 3;
        else if (iQcoverage > 2)
            iQcoverage = 2;
        else
            iQcoverage = 1;

        iQcoverage += AddLine;

        iLineCount += iQcoverage;
        iLineCount_tmp += iQcoverage;

        /* �u�ݫe�O�O�[�`*/
        tot_Medr_prem += iMedr_prem;
        /* lMedr_sum += iMedrins_prem; */
    }
    $CLOSE x3;
    $FREE x3;

    /* g_lMprem_total = lMedr_sum; */

    if (g_lMprem_total > 0)
        strcpy(sTmpBuf, "+");
    else if (g_lMprem_total < 0)
        strcpy(sTmpBuf, "-");
    else
        strcpy(sTmpBuf, " ");
    insert_tmp_table(iPg_init, TOTAL_LINE, 2, sTmpBuf);

    if (lDpolicy >= cm_ymd_cdate("91/04/01")) /* ��91�~04��01��(�t)����ñ�o���O�I�� */
    {
        check_910401 = 0;
    }
    else /* lDpolicy < cm_ymd_cdate("91/04/01") */
    {
        check_910401 = 1;
    }

    /* *** �C�L�����O�O *** */
    if (check_910401 == 1)
    {
        if (lMedr_total == 0)
            strcpy(sTmpBuf, " ");
        else
            strcpy(sTmpBuf, "�����O�O:");
        insert_tmp_table(iPg_init, TOTAL_LINE, 4, sTmpBuf);

        if (lMedr_total < 0)
            strcpy(sTmpBuf, "+");
        else if (lMedr_total > 0)
            strcpy(sTmpBuf, "-");
        else
            strcpy(sTmpBuf, " ");
        insert_tmp_table(iPg_init, TOTAL_LINE, 5, sTmpBuf);

        lMedr_total = labs(lMedr_total);
        printf("labs(lMedr_total)---->[%d]\n", lMedr_total);
        if (lMedr_total == 0)
            strcpy(sTmpBuf, " ");
        else
            rfmtlong(lMedr_total, "---,---,--&", sTmpBuf);
        insert_tmp_table(iPg_init, TOTAL_LINE, 6, sTmpBuf);
    }
    else
    {
        strcpy(sTmpBuf, " ");
        insert_tmp_table(iPg_init, TOTAL_LINE, 4, sTmpBuf);
        insert_tmp_table(iPg_init, TOTAL_LINE, 5, sTmpBuf);
        insert_tmp_table(iPg_init, TOTAL_LINE, 6, sTmpBuf);
    }

    /* ******�C�L�ꦬ(�I)�O�O****** */
    if (lMedr_sum > 0)
        strcpy(sTmpBuf, "+");
    else if (lMedr_sum < 0)
        strcpy(sTmpBuf, "-");
    else
        strcpy(sTmpBuf, " ");
    insert_tmp_table(iPg_init, TOTAL_LINE, 7, sTmpBuf);

    lMedr_sum = labs(lMedr_sum);
    rfmtlong(lMedr_sum, "---,---,--&", sTmpBuf);
    insert_tmp_table(iPg_init, TOTAL_LINE, 8, sTmpBuf);

    insert_tmp_table(iPg_init, TOTAL_LINE, 9, sIcar_type_ori);

    /* *** �h�����u�ݫ��`�O�O *** */
    /* �C�i��檺�Ĥ@���~�ݦC�L */

    g_lMprem_total = labs(g_lMprem_total);
    rfmtlong(g_lMprem_total, "---,---,--&", sTmpBuf);
    insert_tmp_table(iPg_init, TOTAL_LINE, 3, sTmpBuf);

    /* *** �h�����u�ݫe�`�O�O *** */
    /* �C�i��檺�Ĥ@���~�ݦC�L */
    stmt_buf[0] = '\0';
    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s WHERE %s",
            " SUM(medr_prem) ",
            sFullDBName, "edr_ins_type ",
            " iendorse = ? ");
    $PREPARE cur_N FROM $stmt_buf;
    $EXECUTE cur_N INTO $tot_Medr_prem USING $p_sIendorse;
    $FREE cur_N;
    rfmtlong(tot_Medr_prem, "---,---,--&", sTmpBuf);

    iins_Pg = iPg;
    return M_CM_OK;

errexit:
    printf("{ca401_data2}: SQLCODE=[%d] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
} /* ca401_data2 */

/**************************************************************************
 * Function: ca401_data3
 *
 * Description:
 *   �C�L��Ѹ��.
 *
 **************************************************************************/
long ca401_data3(p_sIendorse, p_fmask)
$char *p_sIendorse, *p_fmask;
{
    /* *** �����ܧ󪺰򥻸��, ���I�ة��� *** */
    $struct _icode
    {
        char icode[3];                  /* endorsement_code.icode */
        char iins_type[INSURANCE_TYPE]; /* ins_type */
        char fins_grp[2];               /* fins_grp */
        int fclass;                     /* 1: �I�ا��, 2: �򥻸�Ƨ�� */
    }
    recEdrChg[60];

    int idx = 0, i, j, iDeflag;
    char *psFieldStatus; /* �C�@�ܰʸ�Ƭ����b g_sIedr_field's bit */
    $int iQserial, iQcoverage;
    $char sIedr_type[3], sIins_type[INSURANCE_TYPE], sFins_grp[2], sFclass[2];
    short flag_02, flag_03, flag_05;
    $char sIedr_item[3];
    $long lQserial;
    $char sEedr_item[69], sNtable[31], sNcolumn[31], sFdatatype[2];
    $char sTmt[5000], sTmpBuf[512];
    $char sTmpDate[11], sYY[4], sMM[3], sDD[3];
    $char sTmpData[512], sFcal_way[2], sTmpBuf1[512], sTmpBuf2[512], sStr[512];
    $int iTmp, iLine, lMdeduct;
    $long lMedrinj_cover, lMedrdea_cover, lMedrdmg_cover, lMedrins_prem;
    $long lMinjured_cover, lMdeath_cover, lMdamage_cover, lMins_premium;
    $long lTot_prem, lEdrItemCount;
    $char sIcar_type[3], ipolicy[21];
    char *s;
    $char sDrate_ym[5];

    int iPg_init, iPg;

    $char sDeduct[11], tmpDeduct[8], tmp1Deduct[19], tmpIins_type[INSURANCE_TYPE];

    $char stmt_buf[8000];

    $WHENEVER SQLERROR GOTO errexit;

    printf("$$$$$$$$$$$$ into ca401_data3() g_sFedr_class[%s];\n", g_sFedr_class);

    iPg_init = 1; /* 861226-mag, keep initial value */
    iPg = 1;
    lEdrItemCount = 0; /* ��鷺�e���Ӽ� */

    switch (*g_sFedr_class)
    {
    case '1': /* ���P */
        strcpy(recEdrChg[idx].icode, "01");
        recEdrChg[idx].fclass = 1;
        idx++;
        break;
    case '2': /* �L�� */
        strcpy(recEdrChg[idx].icode, "30");
        recEdrChg[idx].fclass = 1;
        idx++;
        break;
    case '3': /* ��g��H */
        strcpy(recEdrChg[idx].icode, "80");
        recEdrChg[idx].fclass = 1;
        idx++;
        break;
    case '4': /* �h���h�O */
        strcpy(recEdrChg[idx].icode, "60");
        recEdrChg[idx].fclass = 1;
        idx++;
        break;
    } /* switch */

    /* car9602053 ���s�W���N�I�L�����O */
    if ((*g_sFedr_class == '2') || (*g_sFedr_class == '5') || (*g_sFedr_class == '7') ||
        (*g_sFedr_class == '9') || (*g_sFedr_class == '8'))
    {
        puts("test");
        for (i = 0; i < 7; i++)
        {
            iDeflag = 1;
            psFieldStatus = g_sIedr_field + i;
            printf("%X", *psFieldStatus);
            for (j = 0; j < 8; j++)
            { /* �w�� psFieldStatus 8 �� bits */

                if (*psFieldStatus & iDeflag)
                {
                    sprintf_s(recEdrChg[idx].icode, sizeof recEdrChg[idx].icode, "%02d", i * 8 + j);
                    recEdrChg[idx].fclass = 2;
                    idx++;
                    printf("recEdrChg[%d].icode=[%s]\n", idx, recEdrChg[idx].icode);
                }
                iDeflag <<= 1;
            }
        }
        puts("");
        puts("");
    }

    flag_02 = flag_03 = flag_05 = 0;
    /* car9602053 ���s�W���N�I�L�����O */
    if ((*g_sFedr_class == '4') || (*g_sFedr_class == '6') ||
        (*g_sFedr_class == '9') || (*g_sFedr_class == '8'))
    {
        printf("{ca401_data3.0001}:select iedr_type,iins_type,qserial from edr_ins_type\n");
        stmt_buf[0] = '\0';
        sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s WHERE %s %s ",
                " iedr_type, iins_type, qserial ",
                sFullDBName, "edr_ins_type ",
                " iendorse = ? ",
                " ORDER BY qserial");
        $PREPARE x1_tmp FROM $stmt_buf;
        $DECLARE x1 CURSOR FOR x1_tmp;
        $FREE x1_tmp;
        $OPEN x1 USING $p_sIendorse;
        while (1)
        {
            $FETCH x1 INTO $sIedr_type, $sIins_type, $iQserial;
            if (SQLCODE == SQLNOTFOUND)
                break;

            strcpy(sIins_type, trim(sIins_type));

            if (strcmp(sIedr_type, "02") == 0)
            {
                if (flag_02 == 0)
                    flag_02 = 1;
                else
                    continue;
            }
            if (strcmp(sIedr_type, "03") == 0)
            {
                if (flag_03 == 0)
                    flag_03 = 1;
                else
                    continue;
            }
            if (strcmp(sIedr_type, "05") == 0)
            {
                if (flag_05 == 0)
                    flag_05 = 1;
                else
                    continue;
            }
            if (strcmp(sIedr_type, "10") == 0)
            {
                continue;
            }
            strcpy(sFins_grp, " ");
            if ((strcmp(sIedr_type, "04") == 0) || (strcmp(sIedr_type, "40") == 0)) /* 04:�O�B�ܰ� 40:�O�O�ܰ� */
            {
                printf("{ca401_data3.0002}:select fins_grp,qcoverage from insurance_type\n");
                $SELECT fins_grp, qcoverage INTO $sFins_grp, $iQcoverage FROM insurance_type WHERE iins_type = $sIins_type;
                strcpy(recEdrChg[idx].icode, sIedr_type);
                strcpy(recEdrChg[idx].iins_type, sIins_type);
                strcpy(recEdrChg[idx].fins_grp, sFins_grp);
                recEdrChg[idx].fclass = 1;
                idx++;
            }
            else
            {
                strcpy(recEdrChg[idx].icode, sIedr_type);
                strcpy(recEdrChg[idx].iins_type, sIins_type);
                strcpy(recEdrChg[idx].fins_grp, sFins_grp);
                recEdrChg[idx].fclass = 1;
                idx++;
            }
        }
        $CLOSE x1;
        $FREE x1;
    }

    /* car9602053 ���s�W���N�I�L�����O */
    if ((*g_sFedr_class == '4') || (*g_sFedr_class == '6') ||
        (*g_sFedr_class == '9') || (*g_sFedr_class == '8'))
    {
        if (g_lMedrdmg_prem + g_lMedrlia_prem > 0)
        {
            strcpy(recEdrChg[idx].icode, "98");
            recEdrChg[idx].fclass = 2;
            idx++;
        }
        else if (g_lMedrdmg_prem + g_lMedrlia_prem < 0)
        {
            strcpy(recEdrChg[idx].icode, "97");
            recEdrChg[idx].fclass = 2;
            idx++;
        }
    }
    strcpy(recEdrChg[idx].icode, "99"); /* �S���[�� */
    recEdrChg[idx].fclass = 2;
    idx++;

    for (i = 0; i < idx; i++)
    {
        sprintf_s(sFclass, sizeof sFclass, "%d", recEdrChg[i].fclass);

        if (*g_sFedr_class == '2' && strcmp(sFclass, "2") == 0 && strcmp(recEdrChg[i].icode, "02") == 0)
            continue;
        if ((*g_sFedr_class == '5' || *g_sFedr_class == '2') && strcmp(sFclass, "2") == 0 && strcmp(recEdrChg[i].icode, "03") == 0)
            if (*g_sNuser == ' ' || *g_sNuser == '\0')
                strcpy(recEdrChg[i].icode, "70");

        if ((*g_sFedr_class == '5' || *g_sFedr_class == '2') && strcmp(sFclass, "2") == 0 && strcmp(recEdrChg[i].icode, "05") == 0)
            if (*g_sNbenef == ' ' || *g_sNbenef == '\0')
                strcpy(recEdrChg[i].icode, "71");

        printf("{ca401_data3.0003}:select iedr_item from endorsement_code\n");

        $SELECT iedr_item
            INTO $sIedr_item
                FROM endorsement_code
                    WHERE icode = $recEdrChg[i].icode
                                      AND fclass = $sFclass;
        if (SQLCODE == SQLNOTFOUND)
            continue;

        printf("{ca401_data3.0004}:select data from endorsement_item [%s]\n", sIedr_item);
        $DECLARE x2 CURSOR FOR
            SELECT qserial,
            eedr_item, ntable, ncolumn, fdatatype INTO $lQserial, $sEedr_item, $sNtable, $sNcolumn, $sFdatatype FROM endorsement_item WHERE iedr_item = $sIedr_item ORDER BY qserial;
        $OPEN x2;
        for (j = 0;; j++)
        {
            $FETCH x2;
            if (SQLCODE == SQLNOTFOUND)
                break;
            printf("{ca401_data3.0000}:INTO CURSOR x2\n");
            strcpy(sEedr_item, rtrim(sEedr_item));
            strcpy(sNtable, rtrim(sNtable));
            strcpy(sNcolumn, rtrim(sNcolumn));
            strcpy(sFdatatype, rtrim(sFdatatype));

            printf("--trace j=[%d]\n", j);
            printf("--trace lQserial=[%ld],sEedr_item=[%s],sFdatatype=[%s]\n", lQserial, sEedr_item, sFdatatype);
            printf("--trace sNtable =[%s] ,sNcolumn  =[%s]\n,", sNtable, sNcolumn);

            /* 1110602009_SC1 �����ç��C�L�{�������O��첧�ʤ��e
               (�ӥѷ��Yca401m02x.ec���n�P�_nequipment�O�_������)
            if (strncmp(sNcolumn, "nequipment", 10) == 0)
                continue;
            */   
            if ((g_pEedr_item[j] = calloc(1, strlen(sEedr_item) + 1)) == NULL)
            {
                int ii;
                for (ii = 0; ii < j; ii++)
                {
                    free(g_pEedr_item[ii]);
                    free(g_pData[ii]);
                }
                return M_CM_NOT_MALLOC;
            }
            strcpy(g_pEedr_item[j], sEedr_item);

            if (strncmp(sNtable, "edr_relation", 12) == 0)
            {
                if (strncmp(sNcolumn, "total", 5) == 0)
                {
                    printf("TEST!!!!!!!!\n");
                    sprintf_s(sTmt, sizeof sTmt, "SELECT %s FROM %s:%s %s:%s WHERE %s",
                                    " Case "
                                    " WHEN b.dpolicy >= '04/01/2002' "
                                    "    then a.medrdmg_prem + a.medrlia_prem "
                                    " ELSE "
                                    "     a.medrdmg_prem + a.medrlia_prem - a.medrdmg_disc - a.medrlia_disc "
                                    " END ",
                            sFullDBName, "edr_relation a ,",
                            sFullDBName, "ply_relation b ",
                            "a.iendorse = ? AND a.ipolicy = b.ipolicy");
                    printf("sTmt[%s]\n", sTmt);
                    $PREPARE sel1 FROM $sTmt;
                    $DECLARE sel1_1 CURSOR FOR sel1;
                    $FREE sel1;
                    printf("sTmt[%s]\n", sTmt);
                    $OPEN sel1_1 USING $p_sIendorse;
                    $FETCH sel1_1 INTO $lTot_prem;
                    $CLOSE sel1_1;
                    $FREE sel1_1;

                    lTot_prem = labs(lTot_prem);
                    rfmtlong(lTot_prem, "****,***,**&", sTmpData);
                }
                else
                {
                    if (*sFdatatype == '4' || *sFdatatype == '1')
                    {
                        sprintf_s(sTmt, sizeof sTmt, "SELECT %s FROM %s:%s WHERE iendorse='%s'",
                                sNcolumn, sFullDBName, sNtable, p_sIendorse);
                        printf("{ca401_data3.0005}:stmt[%s]\n", sTmt);
                        $PREPARE q1 FROM $sTmt;
                        $DECLARE q1_1 CURSOR FOR q1;
                        $FREE q1;
                        $OPEN q1_1;
                        $FETCH q1_1 INTO $sTmpBuf;
                        $CLOSE q1_1;
                        $FREE q1_1;

                        strcpy(sTmpBuf, rtrim(sTmpBuf));

                        if (*sFdatatype == '4')
                            strcpy(sTmpData, cm_from_infdate_100(sTmpBuf));
                        else
                        {
                            if (strncmp(sNcolumn, "itreaty", 7) == 0)
                            {
                                if (strncmp(sTmpBuf, "6", 1) == 0)
                                    strcpy(sTmpBuf, "�s�j��d���I�X��");
                            }
                            strcpy(sTmpData, sTmpBuf);
                        }
                    }
                    else
                    {
                        sprintf_s(sTmt, sizeof sTmt, "SELECT %s FROM %s:%s WHERE iendorse = '%s'",
                                sNcolumn, sFullDBName, sNtable, p_sIendorse);
                        $PREPARE q5 FROM $sTmt;
                        printf("ca401_data3.0006}:stmt[%s]\n", sTmt);
                        $DECLARE q5_1 CURSOR FOR q5;
                        $FREE q5;
                        $OPEN q5_1;
                        $FETCH q5_1 INTO $iTmp;
                        $CLOSE q5_1;
                        $FREE q5_1;
                        rfmtlong(iTmp, "***&", sTmpData);
                    }
                }
            }
            else if (strncmp(sNtable, "endorsement", 11) == 0)
            {
                if (strncmp(sNcolumn, "nassured30", 10) == 0)
                {
                    sprintf_s(sTmt, sizeof sTmt, "SELECT nassured FROM %s:%s WHERE iendorse = '%s'",
                            sFullDBName, sNtable, p_sIendorse);

                    $PREPARE q8 FROM $sTmt;
                    printf("{ca401_data.0007}:stmt[%s]\n", sTmt);
                    $DECLARE q8_1 CURSOR FOR q8;
                    $FREE q8;
                    $OPEN q8_1;
                    $FETCH q8_1 INTO $sTmpBuf;
                    $CLOSE q8_1;
                    $FREE q8_1;

                    if ((*g_sFedr_class == '2') || (*g_sFedr_class == '8'))
                    {
                        i = cc_split_chinese(sTmpBuf, sStr, 2);
                        strcat(sStr, "****");
                        strcpy(sTmpBuf, sStr);
                    }

                    strcpy(sTmpBuf, rtrim(sTmpBuf));

                    sprintf_s(sTmpData, sizeof sTmpData, "      %s", sTmpBuf);
                }
                else if (strncmp(sNcolumn, "total", 5) == 0)
                {
                    stmt_buf[0] = '\0';
                    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s WHERE %s ",
                            " medrdmg_prem + medrlia_prem ",
                            sFullDBName, " edr_relation ",
                            " iendorse = ?");
                    $PREPARE cur_O FROM $stmt_buf;
                    $EXECUTE cur_O INTO $lTot_prem USING $p_sIendorse;
                    $FREE cur_O;
                    lTot_prem = labs(lTot_prem);

                    rfmtlong(lTot_prem, "****,***,**&", sTmpData);
                }
                else
                {
                    sprintf_s(sTmt, sizeof sTmt, "SELECT %s FROM %s:%s WHERE iendorse='%s'",
                            sNcolumn, sFullDBName, sNtable, p_sIendorse);
                    $PREPARE q7 FROM $sTmt;
                    printf("{ca401_data.0007}:stmt[%s]\n", sTmt);
                    $DECLARE q7_1 CURSOR FOR q7;
                    $FREE q7;
                    $OPEN q7_1;
                    $FETCH q7_1 INTO $sTmpBuf;
                    $CLOSE q7_1;
                    $FREE q7_1;

                    printf("==================================================================[%s]\n", sNcolumn);

                    strcpy(sTmpBuf, rtrim(sTmpBuf));
                    if (*sFdatatype == '4') /* data type is 'date' */
                        strcpy(sTmpData, cm_from_infdate_100(sTmpBuf));
                    else
                    {
                        if (strncmp(sNcolumn, "fassured", 8) == 0)
                        {
                            if (strncmp(sTmpBuf, "1", 1) == 0)
                                strcpy(sTmpBuf, "�۵M�H");
                            if (strncmp(sTmpBuf, "2", 1) == 0)
                                strcpy(sTmpBuf, "�k�H");
                            if (strncmp(sTmpBuf, "3", 1) == 0)
                                strcpy(sTmpBuf, "�~��H");
                        }
                        else if (strncmp(sNcolumn, "fsex", 4) == 0)
                        {
                            if (strncmp(sTmpBuf, "1", 1) == 0)
                                strcpy(sTmpBuf, "�k");
                            if (strncmp(sTmpBuf, "2", 1) == 0)
                                strcpy(sTmpBuf, "�k");
                        }
                        else if (strncmp(sNcolumn, "fmarriage", 9) == 0)
                        {
                            if (strncmp(sTmpBuf, "1", 1) == 0)
                                strcpy(sTmpBuf, "�w�B");
                            if (strncmp(sTmpBuf, "2", 1) == 0)
                                strcpy(sTmpBuf, "���B");
                        }
                        else if (strncmp(sNcolumn, "flimit", 6) == 0)
                        {
                            if (strncmp(sTmpBuf, "1", 1) == 0)
                                strcpy(sTmpBuf, "���w�r�p�H");
                            if (strncmp(sTmpBuf, "2", 1) == 0)
                                strcpy(sTmpBuf, "�����w�r�p�H");
                        }
                        else if (strncmp(sNcolumn, "fpt", 3) == 0)
                        {
                            if (strncmp(sTmpBuf, "P", 1) == 0)
                                strcpy(sTmpBuf, "���ȼ�");
                            if (strncmp(sTmpBuf, "T", 1) == 0)
                                strcpy(sTmpBuf, "����");
                        }
                        else if (strncmp(sNcolumn, "ibrand", 6) == 0)
                            sTmpBuf[8] = '\0';

                        /* 1060406006_C1 CAR401�BCAR409���C�L�Ӹ�B�n */

                        if ((*g_sFedr_class == '2') || (*g_sFedr_class == '8'))
                        {
                            if (p_fmask[0] == '1')
                            {
                                if (strncmp(sNcolumn, "iassured", 8) == 0)
                                {
                                    strcpy(sStr, substring(sTmpBuf, 1, 3));
                                    strcat(sStr, "****");
                                    strcat(sStr, substring(sTmpBuf, 8, 5));
                                    strcpy(sTmpBuf, sStr);
                                }
                                else if (strncmp(sNcolumn, "nassured", 8) == 0)
                                {
                                    strcpy(sStr, substring(sTmpBuf, 1, 2));
                                    strcat(sStr, "****");
                                    strcpy(sTmpBuf, sStr);
                                }
                                else if (strncmp(sNcolumn, "aassured", 8) == 0)
                                {
                                    strcpy(sStr, substring(sTmpBuf, 1, 12));
                                    strcat(sStr, "****");
                                    strcpy(sTmpBuf, sStr);
                                    printf("aassured[%s]\n", sTmpBuf);
                                }
                                else if (strncmp(sNcolumn, "ibirth", 6) == 0)
                                {
                                    strcpy(sTmpBuf, "*******");
                                }
                                else if (strncmp(sNcolumn, "fsex", 4) == 0 || strncmp(sNcolumn, "fmarriage", 9) == 0)
                                {
                                    strcpy(sTmpBuf, "**");
                                }
                            }
                        }

                        strcpy(sTmpData, sTmpBuf);
                    }
                }
            }
            else if (strncmp(sNtable, "edr_ins_type", 12) == 0)
            {
                strcpy(sIins_type, trim(recEdrChg[i].iins_type));

                if (strncmp(sNcolumn, "pcal", 4) == 0)
                {
                    if (strcmp(sIins_type, "21") == 0)
                        strcpy(sTmpData, "");
                    else
                    {
                        stmt_buf[0] = '\0';
                        sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s WHERE %s ",
                                " fcal_way, pcal ",
                                sFullDBName, "edr_ins_type ",
                                " iendorse = ? AND iins_type = ? ");
                        $PREPARE cur_P FROM $stmt_buf;
                        $EXECUTE cur_P INTO $sFcal_way, $iTmp USING $p_sIendorse, $sIins_type;
                        $FREE cur_P;

                        rfmtlong(iTmp, "***&", sTmpData);
                        if (*sFcal_way == 'M')
                            strcat(sTmpData, "% ");
                        else
                            strcat(sTmpData, "��");
                    }
                }
                else
                {
                    printf("{ca401_data3.0008}:select data from edr_ins_type\n");
                    stmt_buf[0] = '\0';
                    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s WHERE %s ",
                            " medrinj_cover, medrdea_cover, medrdmg_cover, mdeduct, medrins_prem ",
                            sFullDBName, "edr_ins_type ",
                            " iendorse = ? AND iins_type = ?");
                    $PREPARE cur_Q FROM $stmt_buf;
                    $EXECUTE cur_Q INTO $lMedrinj_cover, $lMedrdea_cover, $lMedrdmg_cover, $lMdeduct, $lMedrins_prem USING $p_sIendorse, $sIins_type;
                    $FREE cur_Q;

                    stmt_buf[0] = '\0';
                    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s WHERE %s ",
                            " minjured_cover, mdeath_cover, mdamage_cover, mins_premium ",
                            sFullDBName, "ply_ins_type_bak ",
                            " iendorse = ? AND iins_type = ?");
                    $PREPARE cur_R FROM $stmt_buf;
                    $EXECUTE cur_R INTO $lMinjured_cover, $lMdeath_cover, $lMdamage_cover, $lMins_premium USING $p_sIendorse, $sIins_type;                    
                    if (SQLCODE == SQLNOTFOUND)
                    {
                        lMins_premium = 0;
                    }
                    $FREE cur_R;

                    printf("sNcolumn[%s],iins_type[%s]\n", sNcolumn, sIins_type);
                    if (strncmp(sNcolumn, "coverage", 8) == 0)
                    {
                        if (lMedrdmg_cover != 0)
                            rfmtlong(lMdamage_cover + lMedrdmg_cover, "****,***,**&", sTmpData);
                        else if (lMedrinj_cover != 0)
                            rfmtlong(lMinjured_cover + lMedrinj_cover, "****,***,**&", sTmpData);
                    }
                    else if (strncmp(sNcolumn, "medrins_prem1", 13) == 0)
                        rfmtlong(lMins_premium + lMedrins_prem, "****,***,**&", sTmpData);
                    else if (strncmp(sNcolumn, "mdeduct1", 8) == 0)
                    {
                        if (strcmp(sIins_type, "11")  == 0 || strcmp(sIins_type, "129") == 0 || strcmp(sIins_type, "211") == 0 || 
                            strcmp(sIins_type, "176") == 0 || strcmp(sIins_type, "177") == 0 || strcmp(sIins_type, "178") == 0 )
                        {
                            if (lMdeduct == 10)
                                strcpy(sTmpData, " �ʤ�����");
                            if (lMdeduct == 20)
                                strcpy(sTmpData, " �ʤ����G��");
                            if (lMdeduct == 0)
                                strcpy(sTmpData, " �L");
                        }
                        else
                        {
                            stmt_buf[0] = '\0';
                            sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s, %s:%s WHERE %s ",
                                    " a.icar_type , min(b.drate_ym) ",
                                    sFullDBName, "ply_relation_bak a ",
                                    sFullDBName, "ply_ins_type_bak b ",
                                    " a.iendorse = ? AND a.iendorse = b.iendorse GROUP BY a.icar_type ");
                            $PREPARE cur_S FROM $stmt_buf;
                            $EXECUTE cur_S INTO $sIcar_type, $sDrate_ym USING $p_sIendorse;
                            
                            if (SQLCODE == SQLNOTFOUND)
                            {
                                printf("{ca401_data2.0041}:select ply_relation_bak not found!!\n");
                                printf("{ca401_data2.0041}:select ori_ply_relation !!\n");

                                stmt_buf[0] = '\0';
                                sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s, %s:%s WHERE %s %s %s %s",
                                        " a.icar_type, min(b.drate_ym) ",
                                        sFullDBName, "ori_ply_relation a",
                                        sFullDBName, "ori_ins_type b",
                                        " a.ipolicy=(SELECT ipolicy FROM ", sFullDBName, ":edr_relation WHERE iendorse=?)",
                                        " AND a.ipolicy = b.ipolicy GROUP BY a.icar_type ");
                                $PREPARE cur_T FROM $stmt_buf;
                                $EXECUTE cur_T INTO $sIcar_type, $sDrate_ym USING $p_sIendorse;
                                
                                if (SQLCODE == SQLNOTFOUND)
                                {
                                    $FREE cur_T;
                                    return M_CA_NENDORSE;
                                }
                                $FREE cur_T;    
                            }
                            $FREE cur_S;
                            strcpy(sIcar_type, TRANS_CAR_TYPE(sIcar_type, sDrate_ym));

                            memset(tmp1Deduct, 0, sizeof(tmp1Deduct));
                            lMdeduct = labs(lMdeduct);
                            sprintf_s(tmpDeduct, sizeof tmpDeduct, "%d", lMdeduct);
                            strcpy(tmpDeduct, trim(tmpDeduct));
                            printf("A.Endorsement 01/05 Deduct ==>[%s]\n", tmpDeduct);
                            printf("tmpDeduct[%s]\n", tmpDeduct);
                            strcpy(tmp1Deduct, "");
                            if (strcmp(trim(sIins_type), "29") != 0 && strcmp(trim(sIins_type), "124") != 0)
                            {
                                if ((strcmp(trim(sIins_type), "30") == 0)  || (strcmp(trim(sIins_type), "530") == 0) ||
                                    (strcmp(trim(sIins_type), "301") == 0) || (strcmp(trim(sIins_type), "302") == 0)) /*1110308005_SC2 �w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h*/
                                {
                                    if (strstr(tmpDeduct, "24"))
                                        strcpy(tmp1Deduct, "�s�v�I");
                                    if (strstr(tmpDeduct, "55"))
                                    {
                                        if (strlen(trim(tmp1Deduct)) == 0)
                                        {
                                            strcpy(tmp1Deduct, "�����I");
                                        }
                                        else
                                        {
                                            strcat(tmp1Deduct, "�έ����I");
                                        }
                                    }

                                    if (strlen(trim(tmp1Deduct)) > 0)
                                    {
                                        sprintf_s(sTmpData, sizeof sTmpData, "%s%s", "�t", rtrim(tmp1Deduct));
                                    }
                                    else
                                    {
                                        if (strcmp(trim(sIins_type), "301") == 0 || strcmp(trim(sIins_type), "302") == 0)
                                        {
                                            strcpy(sTmpData, "���t�����I");
                                        }
                                        else
                                        {
                                            strcpy(sTmpData, "���t�s�v�I�έ����I");
                                        }
                                    }
                                }
                                else
                                {
                                    $SELECT prn_deduct
                                       INTO $tmp1Deduct
                                       FROM ca_dmg_mdeduct
                                      WHERE icar_type = $sIcar_type
                                        AND ideduct = $tmpDeduct;
                                    printf("tmp1Deduct==>[%s]\n", tmp1Deduct);
                                    strcpy(sTmpData, trim(tmp1Deduct));

                                    strcat(sTmpData, "����");
                                }
                            }
                            else
                            {
                                $SELECT prn_deduct INTO $tmp1Deduct
                                   FROM ca_dmg_mdeduct
                                  WHERE icar_type = 'I29' AND ideduct = $tmpDeduct;
                                printf("29--->prn_deduct[%s]\n", tmp1Deduct);
                                printf("tmp1Deduct==>[%s]\n", tmp1Deduct);
                                strcpy(sTmpData, trim(tmp1Deduct));

                                strcat(sTmpData, "����");
                            }
                        }
                    }
                    else if (strncmp(sNcolumn, "medrdmg_cover", 13) == 0)
                    {
                        cm_double_cstr((double)lMedrdmg_cover, sTmpData, 50);
                    }
                    else if (strncmp(sNcolumn, "iins_type", 9) == 0) /*1081129013_SC2 ����������O30�I�ئۭt�B���i�t55���ˮ�*/
                    {

                        if (strcmp(sIedr_item, "05") == 0)
                        {
                            if (*sFdatatype == '1') /* "1"�w�q�N��:30�I�� */ 
                            {
                                
                                stmt_buf[0] = '\0';
                                lMdeduct = 0;
                                strcpy(tmpIins_type, " ");

                                /*1110714002_SC1 �ץ����C�L�W�B�I�����P�_�W�h*/     
                                if ((strcmp(trim(sIins_type), "30") == 0)  || (strcmp(trim(sIins_type), "530") == 0) ||
                                    (strcmp(trim(sIins_type), "301") == 0) || (strcmp(trim(sIins_type), "302") == 0))
                                {
                                   sprintf_s(tmpDeduct, sizeof tmpDeduct, "%d", lMdeduct);
                                   strcpy(tmpDeduct, trim(tmpDeduct));
                                   printf("-- trace tmpDeduct[%s]\n ", tmpDeduct);
                                   if (strstr(tmpDeduct, "55"))
                                    {
                                        printf("-- trace has 55\n ");
                                        printf("-- trace g_pEedr_item[j][%s]\n ", g_pEedr_item[j]);

                                        /*1110308005_SC1_�w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h */
                                        if ((strcmp(trim(sIins_type), "301") == 0) || (strcmp(trim(sIins_type), "302") == 0))
                                        {
                                            strcpy(g_pEedr_item[j], "\n�@�@�ӫO���W�B�d���I-��D���W��(�ӫO�d��t�����I)");
                                        }
                                    }
                                    else
                                    {
                                        strcpy(g_pEedr_item[j], " ");
                                    }                                
                                }
                                else
                                {
                                    strcpy(g_pEedr_item[j], " ");
                                }
                            }
                        }
                    }
                }
            }
            else if (strncmp(sNtable, "ins_type", 8) == 0)
            {
                strcpy(sIins_type, trim(recEdrChg[i].iins_type));
                if (strcmp(sIins_type, "53") == 0||strcmp(sIins_type, "253") == 0)
                    strcpy(sTmpData, "(�t�����I) ");
                else
                    strcpy(sTmpData, " ");
            }
            else if (strncmp(sNtable, "insurance_type", 14) == 0)
            {
                strcpy(sIins_type, trim(recEdrChg[i].iins_type));
                strcpy(sFins_grp, recEdrChg[i].fins_grp);

                sprintf_s(sTmt, sizeof sTmt, "SELECT %s FROM %s:%s WHERE iins_type='%s'",
                        sNcolumn, sFullDBName, sNtable, sIins_type);

                $PREPARE q2 FROM $sTmt;
                $DECLARE q2_1 CURSOR FOR q2;
                $FREE q2;
                $OPEN q2_1;
                $FETCH q2_1 INTO $sTmpBuf;
                $CLOSE q2_1;
                $FREE q2_1;

                strcpy(sTmpBuf, rtrim(sTmpBuf));
                if (strcmp(trim(sIins_type), "30") == 0)
                {
                    strcat(sTmpBuf, "-�O�٫�");
                }
                else if (strcmp(trim(sIins_type), "301") == 0 || strcmp(trim(sIins_type), "302") == 0) /*1110308005_SC2 �w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h*/
                {
                    strcat(sTmpBuf, "-��D���W��");
                }

                if (*sFins_grp != '\0' && *sFins_grp != ' ')
                {
                    lMedrinj_cover = lMedrdmg_cover = lMedrins_prem = 0;

                    stmt_buf[0] = '\0';
                    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s WHERE %s ",
                            " medrinj_cover, medrdmg_cover, medrins_prem ",
                            sFullDBName, "edr_ins_type ",
                            " iendorse = ? AND iins_type = ?");
                    $PREPARE cur_U FROM $stmt_buf;
                    $EXECUTE cur_U INTO $lMedrinj_cover, $lMedrdmg_cover, $lMedrins_prem USING $p_sIendorse, $sIins_type;
                    $FREE cur_U;

                    if (strcmp(sIedr_item, "04") == 0)
                    {
                    }
                    else if (strcmp(sIedr_item, "40") == 0)
                    {
                        if (lMedrins_prem >= 0)
                            strcat(sTmpBuf, "�W�[�O�O");
                        else
                            strcat(sTmpBuf, "��֫O�O");
                    }
                    strcpy(sTmpData, sTmpBuf);
                }
                else
                    strcpy(sTmpData, sTmpBuf);
            }
            else if (strncmp(sNtable, "ply_ins_type_bak", 16) == 0)
            {
                printf("--trace sNtable=ply_ins_type_bak");

                strcpy(sIins_type, trim(recEdrChg[i].iins_type));

                if (strncmp(sNcolumn, "coverage", 8) == 0)
                {
                    printf("--trace sNcolumn=coverage");
                    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT CASE WHEN medrdmg_cover != 0 THEN 'mdamage_cover'"
                                      "            WHEN medrinj_cover != 0 THEN 'minjured_cover'"
                                      "            ELSE 'mdeath_cover' END "
                                      "       FROM %s:edr_ins_type "
                                      "      WHERE iendorse = ? AND iins_type = ?",
                            sFullDBName);
                    $PREPARE prep4 FROM $stmt_buf;
                    $EXECUTE prep4 INTO $sNcolumn USING $p_sIendorse, $sIins_type;
                    $FREE prep4;

                    /* strcpy(sNcolumn, "minjured_cover"); */
                    /* strcpy(sNcolumn, "mdamage_cover"); */

                    /* ------------------------------------ */
                    sprintf_s(sTmt, sizeof sTmt, "SELECT %s FROM %s:%s WHERE %s",
                            sNcolumn, sFullDBName, sNtable, "iendorse=? AND iins_type=?");

                    $PREPARE q6 FROM $sTmt;
                    $DECLARE q6_1 CURSOR FOR q6;
                    $FREE q6;
                    $OPEN q6_1 USING $p_sIendorse, $sIins_type;
                    $FETCH q6_1 INTO $lTot_prem;
                    if (SQLCODE == SQLNOTFOUND)
                        lTot_prem = 0;
                    $CLOSE q6_1;
                    $FREE q6_1;

                    rfmtlong(lTot_prem, "****,***,**&", sTmpData);
                }
                else
                {
                    printf("--trace sNcolumn <> coverage");
                    sprintf_s(sTmt, sizeof sTmt, "SELECT %s FROM %s:%s WHERE %s", sNcolumn, sFullDBName, sNtable, "iendorse=? AND iins_type=?");

#ifdef _M860718
                    printf("{ca401_data3.0160}: ply_ins_type_bak.coverage stmt[%s]\n", sTmt);
#endif

                    $PREPARE q3 FROM $sTmt;
                    $DECLARE q3_1 CURSOR FOR q3;
                    $FREE q3;
                    $OPEN q3_1 USING $p_sIendorse, $sIins_type;
                    $FETCH q3_1 INTO $lTot_prem;
                    if (SQLCODE == SQLNOTFOUND)
                        lTot_prem = 0;
                    $CLOSE q3_1;
                    $FREE q3_1;

                    if (strcmp(sIedr_item, "20") == 0)
                    {
                        printf("--trace sIedr_item=20");
                        if (strcmp(sIins_type, "11")  == 0 || strcmp(sIins_type, "129") == 0 || strcmp(sIins_type, "211") == 0 || 
                            strcmp(sIins_type, "176") == 0 || strcmp(sIins_type, "177") == 0 || strcmp(sIins_type, "178") == 0)
                        {
                            strcpy(sTmpData, " ");
                            if (lTot_prem == 10)
                                strcpy(sTmpData, " �ʤ�����");
                            if (lTot_prem == 20)
                                strcpy(sTmpData, " �ʤ����G��");
                        }
                        else
                        {
                            printf("--trace sIins_type[%s]\n", sIins_type);
                            stmt_buf[0] = '\0';
                            sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s, %s:%s WHERE %s",
                                    " a.icar_type, min(b.drate_ym) ",
                                    sFullDBName, "ply_relation_bak a ",
                                    sFullDBName, "ply_ins_type_bak b ",
                                    " a.iendorse = ? AND a.iendorse = b.iendorse GROUP BY a.icar_type ");
                            $PREPARE cur_V FROM $stmt_buf;
                            $EXECUTE cur_V INTO $sIcar_type, $sDrate_ym USING $p_sIendorse;                            

                            if (SQLCODE == SQLNOTFOUND)
                            {
                                printf("{ca401_data2.0041}:select ply_relation_bak not found!!\n");
                                printf("{ca401_data2.0041}:select ori_ply_relation !!\n");

                                stmt_buf[0] = '\0';
                                sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s, %s:%s WHERE %s %s %s %s ",
                                        " a.icar_type, min(b.drate_ym) ",
                                        sFullDBName, "ori_ply_relation a ",
                                        sFullDBName, "ori_ins_type b ",
                                        " a.ipolicy=(SELECT ipolicy FROM ", sFullDBName, ":edr_relation WHERE iendorse=?)",
                                        " AND a.ipolicy = b.ipolicy GROUP BY a.icar_type");
                                printf("stmt_buf[%s]\n", stmt_buf);
                                $PREPARE cur_W FROM $stmt_buf;
                                $EXECUTE cur_W INTO $sIcar_type, $sDrate_ym USING $p_sIendorse;
                                
                                if (SQLCODE == SQLNOTFOUND)
                                {
                                    $FREE cur_W;
                                    return M_CA_NENDORSE;
                                }    
                                $FREE cur_W;
                            }
                            $FREE cur_V;
                            strcpy(sIcar_type, TRANS_CAR_TYPE(sIcar_type, sDrate_ym));

                            stmt_buf[0] = '\0';
                            sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s WHERE %s ",
                                    " mdeduct ",
                                    sFullDBName, "ply_ins_type_bak ",
                                    " iendorse = ? AND iins_type = ?");
                            $PREPARE cur_X FROM $stmt_buf;
                            printf("stmt_buf[%s]\n", stmt_buf);
                            $EXECUTE cur_X INTO $lMdeduct USING $p_sIendorse, $sIins_type;
                            $FREE cur_X;

                            memset(tmp1Deduct, 0, sizeof(tmp1Deduct));
                            lMdeduct = labs(lMdeduct);
                            sprintf_s(tmpDeduct, sizeof tmpDeduct, "%d", lMdeduct);
                            strcpy(tmpDeduct, trim(tmpDeduct));
                            printf("B.Endorsement 01/05 Deduct ==>[%s]\n", tmpDeduct);
                            strcpy(tmp1Deduct, "");
                            if (strcmp(trim(sIins_type), "29") == 0 || strcmp(trim(sIins_type), "124") == 0)
                            {
                                $SELECT prn_deduct INTO $tmp1Deduct
                                   FROM ca_dmg_mdeduct
                                  WHERE icar_type = 'I29' AND ideduct = $tmpDeduct;
                                printf("tmp1Deduct==>[%s]\n", tmp1Deduct);
                                strcpy(sTmpData, trim(tmp1Deduct));

                                /*  rfmtlong(lTot_prem, "****,***,**&", sTmpData);  */
                                strcat(sTmpData, "��");
                            }
                            else
                            {

                                if ((strcmp(trim(sIins_type), "30") == 0)  || (strcmp(trim(sIins_type), "530") == 0) ||
                                    (strcmp(trim(sIins_type), "301") == 0) || (strcmp(trim(sIins_type), "302") == 0)) /*1110308005_SC2 �w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h*/
                                {
                                    if (strstr(tmpDeduct, "24"))
                                        strcpy(tmp1Deduct, "�s�v�I");
                                    if (strstr(tmpDeduct, "55"))
                                    {
                                        if (strlen(trim(tmp1Deduct)) == 0)
                                        {
                                            strcpy(tmp1Deduct, "�����I");
                                        }
                                        else
                                        {
                                            strcat(tmp1Deduct, "�έ����I");
                                        }
                                    }
                                    printf("-- trace1 tmp1Deduct[%s]\n ", tmp1Deduct);
                                    if (strlen(trim(tmp1Deduct)) > 0)
                                        sprintf_s(sTmpData, sizeof sTmpData, "%s%s", "�t", rtrim(tmp1Deduct));
                                    else
                                        strcpy(sTmpData, "");
                                }
                                else
                                {

                                    $SELECT prn_deduct INTO $tmp1Deduct
                                       FROM ca_dmg_mdeduct
                                      WHERE icar_type = $sIcar_type
                                        AND ideduct = $tmpDeduct;
                                    printf("tmp1Deduct==>[%s]\n", tmp1Deduct);
                                    strcpy(sTmpData, trim(tmp1Deduct));

                                    /*  rfmtlong(lTot_prem, "****,***,**&", sTmpData);  */
                                    strcat(sTmpData, "��");
                                }
                            }
                            printf("--trace1 sTmpData[%s]\n", sTmpData);
                        }
                    }
                    else
                        rfmtlong(lTot_prem, "****,***,**&", sTmpData);
                }
            }
            else if (*sNtable == '\0' || *sNtable == ' ')
            {
                sTmpData[0] = '\0';
            }
            else
            {
                sprintf_s(sTmt, sizeof sTmt, "SELECT %s FROM %s:%s WHERE iendorse='%s'",
                        sNcolumn, sFullDBName, sNtable, p_sIendorse);
                $PREPARE q4 FROM $sTmt;
                $DECLARE x CURSOR FOR q4;
                $FREE q4;
                $OPEN x;
                $FETCH x INTO $sTmpBuf;
                $CLOSE x;
                $FREE x;

                strcpy(sTmpBuf, rtrim(sTmpBuf));
                if (*sFdatatype == '4')
                    strcpy(sTmpData, cm_from_infdate_100(sTmpBuf));
                else
                    strcpy(sTmpData, sTmpBuf);
            }

            printf("{ca401_data3.0009}\n");

            if ((g_pData[j] = calloc(1, strlen(sTmpData) + 1)) == NULL)
            {
                int ii;
                for (ii = 0; ii < j; ii++)
                {
                    printf("{ca401_data3.0012}\n");
                    free(g_pEedr_item[ii]);
                    free(g_pData[ii]);
                    printf("{ca401_data3.0013}\n");
                }
                return M_CM_NOT_MALLOC;
            }
            strcpy(g_pData[j], sTmpData);
        } /* end of for */
        $CLOSE x2;
        $FREE x2;

        printf("{ca401_data3.0010}\n");
        if (j != 0)
        {
            char *p;
            int xx;
            printf("--trace sTmpBuf[%s]\n", sTmpBuf);
            strcpy(sTmpBuf, pwformat(j, g_pEedr_item, g_pData, 4, &iLine));
            /*1060706003_SC1 �ק�W�B�d���I(30�B301)�C�L��r, "�ۭt�B" �אּ=> "�ӫO�d��"*/
            /* "�ۭt�B"�]�w�b endorsement_item,�A�ΩҦ��I�ءA�G�L�k��W����30,301�I�ت��ۭt�B��r */
            strSearchReplace(sTmpBuf, "�W�B�I-�O�٫��ۭt�B", "�W�B�I-�O�٫��ӫO�d��");
            strSearchReplace(sTmpBuf, "�W�B�I-��D���W���ۭt�B", "�W�B�I-��D���W���ӫO�d��");
#ifdef _M860718
            printf("{ca401_data3.0050}: iLine[%d] i[%d] sTmpBuf[%s]\n", iLine, i, sTmpBuf);
#endif

            if (lEdrItemCount >= 7) /* 861226-mag, ���@���̦h�L7�� */
            {
                lEdrItemCount = 0;
                iPg++;
                printf("-----------------------> data3() iPg[%d]\n", iPg);
            }

            /* 861226-mag, ��XsTmpBuf���Ĥ@�Ӵ���Ÿ�����}p */
            p = strchr(sTmpBuf, '\n');
            if (p == NULL)
            { /* 861226-mag, sTmpBuf���L����Ÿ� */
                insert_tmp_table(iPg, EDR_BASE_LINE + lEdrItemCount, 1, sTmpBuf);
                lEdrItemCount++;
            }
            else
            {
                /* *** Block endorse_item *** */
                strncpy(sTmpBuf1, sTmpBuf, p - sTmpBuf);
                sTmpBuf1[p - sTmpBuf] = '\0';
                insert_tmp_table(iPg, EDR_BASE_LINE + lEdrItemCount, 1, sTmpBuf1);
                lEdrItemCount++;

                if (lEdrItemCount >= 7) /* 861226-mag, ���@���̦h�L7�� */
                {
                    lEdrItemCount = 0;
                    iPg++;
                    printf("-----------------------> data3() iPg[%d]\n", iPg);
                }

                insert_tmp_table(iPg, EDR_BASE_LINE + lEdrItemCount, 1, p + 1);
                lEdrItemCount++;
            }
        }

        { /* *** Temporary block for free memory  - tony96.860825 - *** */
            short ii;
            for (ii = 0; ii < j; ii++)
            {
                free(g_pEedr_item[ii]);
                free(g_pData[ii]);
            }
        }
    } /* end of for */

    sprintf_s(sTmt, sizeof sTmt, "SELECT ipolicy FROM %s:edr_relation WHERE iendorse='%s'", sFullDBName, p_sIendorse);
    $PREPARE prep9 FROM $sTmt;
    $EXECUTE prep9 INTO $ipolicy;
    $FREE prep9;
    if (!strstr(ipolicy, "EB"))
    {
        int xTmp, yTmp;

        if (iins_Pg > iPg) /* �I�ح��� > ��ѭ��� */
            yTmp = iins_Pg;
        else
            yTmp = iPg;

        for (xTmp = 1; xTmp <= yTmp; xTmp++)
        {
            strcpy(sTmpDate, cm_from_infdate_100(g_sDendorse));
            cm_split_ymd_100(sTmpDate, sYY, sMM, sDD);
            insert_tmp_table(xTmp, 34, 1, sYY);
            insert_tmp_table(xTmp, 34, 2, sMM);
            insert_tmp_table(xTmp, 34, 3, sDD);
        }
    }

    printf(" $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ \n");
    return M_CM_OK;

errexit:
    printf("{ca401_data3}: SQLCODE=[%d] sqlerrm=[%s] sqlca.sqlerrd[1]=[%d]\n", SQLCODE, sqlca.sqlerrm, sqlca.sqlerrd[1]);
    return SQLCODE;
} /* ca401_data3 */

/************************************************************************/
long drop_temp_table()
{
    $char sTmt[1024];

    $WHENEVER SQLERROR GOTO errexit;

    printf("--------------------- g_sFile[%s]\n", g_sFile);
    sprintf_s(sTmt, sizeof sTmt,
            "DROP TABLE IF EXISTS tmp%s", g_sFile);
    printf("--------------------- stmt[%s]\n", sTmt);
    $PREPARE dtt_1 FROM $sTmt;
    $EXECUTE dtt_1;
    $FREE dtt_1;

    /************
      sprintf_s(sTmt, sizeof sTmt,
        "DROP INDEX tmpx%s", g_sFile);
      $PREPARE dtt_2 FROM $sTmt;
      $EXECUTE dtt_2;
    ************/

    return M_CM_OK;

errexit:
    printf("{drop_temp_table}: SQLCODE[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
} /* drop_temp_table */

/*************************************************************************/
long insert_tmp_table(p_pg, p_row, p_col, p_str)
$int p_pg; /* 861226-mag */
$int p_row, p_col;
$char *p_str;
{
    $char sTmt[1024];

    $WHENEVER SQLERROR GOTO errexit;

    sprintf_s(sTmt, sizeof sTmt, "INSERT INTO tmp%s VALUES(?, ?, ?, ?)", g_sFile);
    $PREPARE i_tmptbl FROM $sTmt;
    $EXECUTE i_tmptbl USING $p_pg, $p_row, $p_col, $p_str;
    $FREE i_tmptbl;

    printf("{insert_tmp_table}: insert row[%d],col[%d],str[%s]\n", p_row, p_col, p_str);

    return M_CM_OK;

errexit:
    printf("{insert_tmp_table}:SQLCODE[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
} /* insert_tmp_table */

/*************************************************************************/
long data_report(p_piMaxCount)
int *p_piMaxCount;
{
    $int i, j, k, tmp_pg, tmp_row, tmp_col;
    $int old_row, old_col;
    $char sTmt[1024], sBuf[511];
    $int p_Pg, n, m, printLine;

    $WHENEVER SQLERROR GOTO errexit;

    printf("==============================> into data_report()\n");
    printf("==g_sFile[%s] =======into data_report()\n", g_sFile);

    sprintf_s(sTmt, sizeof sTmt, "SELECT rpt_pg FROM tmp%s ORDER BY rpt_pg DESC", g_sFile);
    $PREPARE s_temp_1 FROM $sTmt;
    $DECLARE sel_t_cur1 CURSOR FOR s_temp_1;
    $FREE s_temp_1;
    $OPEN sel_t_cur1;
    $FETCH sel_t_cur1 INTO $p_Pg;
    $CLOSE sel_t_cur1;
    $FREE sel_t_cur1;

    if (p_Pg > 1)
    {
        for (n = 1; n < p_Pg; n++)
        {
            insert_tmp_table(n, TOTAL_LINE, 1, "(��U��)");
        }
        insert_tmp_table(p_Pg, 7, 7, "(��W��)");
    }

    printf("*--------------after FETCH !!\n");

    sprintf_s(sTmt, sizeof sTmt,
            "SELECT str,rpt_pg, rpt_row, rpt_col "
            "  FROM tmp%s %s ORDER BY rpt_pg,rpt_row,rpt_col",
            g_sFile,
            "WHERE rpt_pg= ? ");

    printf("@@@@ stmt[%s]\n", sTmt);

    $PREPARE s_temp FROM $sTmt;
    $DECLARE sel_t_cur CURSOR FOR s_temp;
    $FREE s_temp;

    printf("begin for loop\n");

    for (m = 1; m <= p_Pg; m++)
    {
        old_row = 1;
        old_col = 0;

        $OPEN sel_t_cur USING $m;
        while (1)
        {
            $FETCH sel_t_cur INTO $sBuf, $tmp_pg, $tmp_row, $tmp_col;
            if (SQLCODE == SQLNOTFOUND)
                break;
            strcpy(sBuf, rtrim(sBuf));
            old_col++;

            printf("{data_report}: page[%d] row[%d] col[%d] str[%s]\n", tmp_pg, tmp_row, tmp_col, sBuf);

            while (tmp_row > old_row)
            {
                /* ���C */
                for (n = old_col + 1; n <= MAX_COLUMN; n++)
                {
                    rgu_put_body_string(old_row, " ", LEFT);
                }

                rgu_put_body(old_row);
                (*p_piMaxCount)++;
                old_row++;
                old_col = 1;
            }

            while (tmp_col > old_col)
            {
                for (n = old_col; n < tmp_col; n++)
                {
                    rgu_put_body_string(tmp_row, " ", LEFT);
                }
                old_col = tmp_col;
            }

            rgu_put_body_string(tmp_row, rtrim(sBuf), LEFT);
        }
        rgu_put_body(tmp_row);
        (*p_piMaxCount)++;
    }
    $CLOSE sel_t_cur;
    $FREE sel_t_cur;

    printf("*--------------after loop !!\n");
    sprintf_s(sTmt, sizeof sTmt, "DELETE FROM tmp%s", g_sFile);
    $PREPARE s_temp FROM $sTmt;
    $EXECUTE s_temp;
    $FREE s_temp;

    printf("=after  delete=======> into data_report()\n");

    return M_CM_OK;

errexit:
    printf("{data_report}: SQLCODE[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
} /* data_report */

/***********************************************************************/
/*
 * ���ڦC�L
 *
 ***********************************************************************/
long car401_body_receipt(p_sIendorse)
$char *p_sIendorse;
{
    $char sIpolicy[POLICY_NUM_1], sIofficer[11], sIbroker[11], sDendorse[11];
    $long lMedrdmg_prem, lMedrlia_prem, lMedrdmg_commi, lMedrlia_commi;
    $long lMdiscount;
    $long lDedr_begin, lDedr_end;
    $char sNassured[122], sAassured[92], sIlicense[12], sItel[21], sNbenef[43];
    $char sIbranch[3], sSite[3], sNpresident[12], sToday[11];
    $date dToday;
    $char sYY[3], sMM[3], sDD[3], sIpolicy1[POLICY_NUM_1], sIpolicy2[POLICY_NUM_2];
    $char sPayResult[3], sPayStatus[32], sPayDate[9], sNoteDate[9];
    $long lMprem_total, lMdisc_total, lMcomm_total, lMreal_total;
    short fStatus;
    $char sTmpBuf[254], sTmpBuf1[81], sTmpBuf2[81], sTmpBuf3[81], sAddress[91];
    $char sTmpBuf1_tmp[81];
    $char sTaxName[11], sTaxArea[11];
    $char stmt_buf[8000];

    int iPg;

    iPg = 1;

    $WHENEVER SQLERROR GOTO errexit;
    printf("--trace 1 in car401_body_receipt()\n");
    

    stmt_buf[0] = '\0';
    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s %s %s %s %s FROM %s:%s WHERE %s ",
            " ipolicy, iofficer, ibroker, ",
            " case when iendorse like '%CVP%' then null when dendorse is null then today else dendorse end, ",
            " dedr_begin,",
            " dedr_end, medrdmg_prem, medrlia_prem, medrdmg_commi,",
            " medrlia_commi ",
            sFullDBName, "edr_relation ",
            " iendorse = ? ");
    $PREPARE cur_Y FROM $stmt_buf;
    $EXECUTE cur_Y INTO $sIpolicy, $sIofficer, $sIbroker, $sDendorse, $lDedr_begin,
        $lDedr_end, $lMedrdmg_prem, $lMedrlia_prem, $lMedrdmg_commi,
        $lMedrlia_commi
            USING $p_sIendorse;
       
    if (SQLCODE == SQLNOTFOUND)
    {
        $FREE cur_Y;  
        return M_CA_NREL_EDR;
    }
    $FREE cur_Y;  
    strcpy(sIpolicy, rtrim(sIpolicy));
    strcpy(sIofficer, rtrim(sIofficer));
    strcpy(sIbroker, rtrim(sIbroker));
    strcpy(sDendorse, rtrim(sDendorse));

    /* *** �O�渹�X *** */
    /* ***************************************************************************
     * sprintf_s(sTmpBuf, sizeof sTmpBuf, "02%s", sIpolicy);
     * if(strlen(sTmpBuf) > 14)
     *   sTmpBuf[14] = '\0';
     * ***************************************************************************/

    /*** FROM edr_ins_type OR FROM edr_raltion ***/
    lMdiscount = 0;

    stmt_buf[0] = '\0';
    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s WHERE %s ",
            " SUM(medr_discount) ",
            sFullDBName, "edr_ins_type ",
            " iendorse = ? ");
    $PREPARE cur_A1 FROM $stmt_buf;
    $EXECUTE cur_A1 INTO $lMdiscount USING $p_sIendorse;
    $FREE cur_A1;

    stmt_buf[0] = '\0';
    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s WHERE %s ",
            " nassured, aassured, ilicense, itel, nbenef ",
            sFullDBName, "endorsement ",
            " iendorse = ? ");
    $PREPARE cur_A2 FROM $stmt_buf;
    $EXECUTE cur_A2 INTO $sNassured, $sAassured, $sIlicense, $sItel, $sNbenef USING $p_sIendorse;
    
    if (SQLCODE == SQLNOTFOUND)
    {
        $FREE cur_A2;    
        return M_CA_NENDORSE;
    }    
    $FREE cur_A2;    
    strncpy(sIbranch, p_sIendorse, 2);
    sIbranch[2] = '\0';
    strcpy(sNassured, rtrim(sNassured));
    strcpy(sAassured, rtrim(sAassured));
    strcpy(sIlicense, rtrim(sIlicense));
    strcpy(sItel, rtrim(sItel));

    /* *** �O��W�� *** */
    insert_tmp_table(iPg, 3, 7, sNassured);

    /* *** ���O�a�} *** */
    if (strlen(sAassured) <= 72)
    {
        insert_tmp_table(iPg, 5, 9, sAassured);
        insert_tmp_table(iPg, 26, 2, sAassured);
    }
    else
    { /* *** temporary block add by mag-870209 *** */
        int i;
        char buf[80];

        i = cc_split_chinese(sAassured, buf, 72);
        insert_tmp_table(iPg, 5, 8, buf);
        insert_tmp_table(iPg, 25, 2, buf);
        cc_split_chinese(sAassured + i, buf, 72);
        insert_tmp_table(iPg, 5, 9, buf);
        insert_tmp_table(iPg, 26, 2, buf);
    }

    /* *** ��U�Ȧ� *** */
    insert_tmp_table(iPg, 7, 7, sNbenef);
    insert_tmp_table(iPg, 29, 2, sNbenef);

    /* *** �q�� *** */
    insert_tmp_table(iPg, 7, 11, sItel);
    /* insert_tmp_table(iPg, 32, 1, sItel); */

    if (strlen(sIpolicy) > CAR_POLICY_LEN)
    {
        strncpy(sIpolicy1, sIpolicy, CAR_POLICY_LEN);
        sIpolicy1[CAR_POLICY_LEN] = '\0';
        strcpy(sIpolicy2, sIpolicy + CAR_POLICY_LEN);
    }
    else
    {
        strcpy(sIpolicy1, sIpolicy);
        strcpy(sIpolicy2, "");
    }

    strncpy(sSite, sIpolicy, 2);
    sSite[2] = '\0';
    ao_chk_charge(sSite, '1', sIpolicy1, sIpolicy2, "",
                  sPayResult, sPayStatus,
                  sPayDate, sNoteDate);
    if (sPayResult[0] == 'X')
    {
        stmt_buf[0] = '\0';
        sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s WHERE %s ",
                " ibatch_no ",
                sFullDBName, "ply_relation ",
                "ipolicy=?");

        $PREPARE cur_A3 FROM $stmt_buf;
        $EXECUTE cur_A3 INTO $ibatch_no USING $sIpolicy;
        $FREE cur_A3;

        memset(batch_no, 0, sizeof(batch_no));
        sprintf_s(batch_no, sizeof batch_no, "%d", ibatch_no);

        printf("{ca_rpt_endorse.0010}:ibatch_no[%d]\n", ibatch_no);
        printf("{ca_rpt_endorse.0020}:batch_no[%s]\n", batch_no);

        ao_chk_charge(sSite, '1', sIpolicy1, sIpolicy2, "",
                      sPayResult, sPayStatus, sPayDate, sNoteDate);
        printf("payresult[%s]\n", sPayResult);

        if (sPayResult[0] == 'X')
            ao_chk_charge(sSite, '1', sIpolicy1, "", batch_no,
                          sPayResult, sPayStatus, sPayDate, sNoteDate);
    }
    printf("&&&& sPayStatus[%s]\n", sPayStatus);
    strcpy(sPayStatus, rtrim(sPayStatus));
    printf("&&&& sPayStatus[%s]\n", sPayStatus);
    lMprem_total = lMedrdmg_prem + lMedrlia_prem;
    lMdisc_total = lMdiscount;
    lMcomm_total = lMedrdmg_commi + lMedrlia_commi;
    lMreal_total = lMprem_total - lMdisc_total;

    /* fStatus=0 ���h�O, =1 �����O */
    fStatus = (lMprem_total < 0) ? 0 : 1;

    strncpy(sIbranch, sIpolicy, 2);
    sIbranch[2] = '\0';
    $SELECT tax_name, tax_area, address INTO $sTaxName, $sTaxArea, $sAddress FROM ca_area_code WHERE sk_code = $sIbranch;
    if (SQLCODE == SQLNOTFOUND)
    {
        strcpy(sTaxName, "");
        strcpy(sTaxArea, "");
        strcpy(sAddress, "");
    }
    else
    {
        strcpy(sTaxName, rtrim(sTaxName));
        strcpy(sTaxArea, rtrim(sTaxArea));
        strcpy(sAddress, rtrim(sAddress));
    }

    if (fStatus == 0)
    {
        insert_tmp_table(iPg, 14, 13, sTmpBuf);
        insert_tmp_table(iPg, 27, 2, "�����Ҹ� (�Ц۶�)");
        insert_tmp_table(iPg, 24, 3, "�g���H");

        /* *** �s���� *** */
        dToday = cm_today();
        strcpy(sToday, cm_cdate_str_100(dToday));
        cm_split_ymd_100(sToday, sYY, sMM, sDD);
        sprintf_s(sTmpBuf, sizeof sTmpBuf, " ");
        insert_tmp_table(iPg, BASE_LINE, 9, sTmpBuf);
        insert_tmp_table(iPg, 33, 1, sTmpBuf);

        /* *** �g���H *** */
        if (strncmp(sIbroker, "ZZZZZ", 5) == 0)
            sprintf_s(sTmpBuf, sizeof sTmpBuf, "��������%s", sIbroker);
        else
            strcpy(sTmpBuf, sIbroker);
        insert_tmp_table(iPg, 7, 10, sTmpBuf);
        /*insert_tmp_table(iPg, 32, 2, sTmpBuf);*/
    }
    else
    {
        insert_tmp_table(iPg, 14, 13, sTmpBuf);
        /* *** �ƥ���r���� *** */
        sprintf_s(sTmpBuf, sizeof sTmpBuf, "%c%c�ƥ�%c%c", 27, 24, 27, 12);
        insert_tmp_table(iPg, 13, 13, sTmpBuf);
        insert_tmp_table(iPg, 14, 14, "�������ڦL��w�`ú");

        insert_tmp_table(iPg, 16, 9, "    ��  �Q��󦬨쥻�O�I�O�b��ɧY�V");
        sprintf_s(sTmpBuf, sizeof sTmpBuf, "    %s", sAddress);
        insert_tmp_table(iPg, 16, 13, sTmpBuf);

        /* *** �g���H *** */
        if (strncmp(sIbroker, "ZZZZZ", 5) == 0)
            sprintf_s(sTmpBuf, sizeof sTmpBuf, "������O����%s", sIbroker);
        else
            strcpy(sTmpBuf, sIbroker);
        insert_tmp_table(iPg, 7, 10, sTmpBuf);
    }

    lMprem_total = labs(lMprem_total);
    lMdiscount = labs(lMdiscount);
    lMcomm_total = labs(lMcomm_total);
    lMreal_total = labs(lMreal_total);

    if (lMdiscount > 0 && fStatus == 1)
    {
        strcpy(sTmpBuf1, refmtamt(lMprem_total, MILLIONTH));
        strcpy(sTmpBuf2, refmtamt(lMdiscount, MILLIONTH));
        strcpy(sTmpBuf3, refmtamt(lMreal_total, MILLIONTH));
        sprintf_s(sTmpBuf, sizeof sTmpBuf, "�O�ONT$%s - ����NT$%s = �ꦬNT%s",
                sTmpBuf1, sTmpBuf2, sTmpBuf3);
    }
    else
    {
        num_to_chinese(sTmpBuf1, lMreal_total);
        strcpy(sTmpBuf1_tmp, rtrim(sTmpBuf1));
        strcpy(sTmpBuf2, refmtamt(lMreal_total, MILLIONTH));
        sprintf_s(sTmpBuf, sizeof sTmpBuf, "%s����       NT$%s", sTmpBuf1_tmp, sTmpBuf2);
    }

    /* *** ��ú(�h)�O�O *** */
    insert_tmp_table(iPg, 23, 2, sTmpBuf);

    printf("--trace 2 in car401_body_receipt()\n");
    return M_CM_OK;

errexit:
    printf("{car401_body_receipt}:SQLCODE=[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
} /* car401_body_receipt */

void DecToBin(int d, int n, char *s)
{

    if (d > (n - 1))
    {
        s = itoa(d % n) + s;
        DecToBin(floor(d / n), n, s);
    }
    else
        s = itoa(d) + s;
}

/* �Y searchString = replaceString      => �^�� searchString �b string�����Ӽ� */
/* �Y searchString != replaceString     => �N�b string����searchString ���N�� replaceString ,�æ^�Ǩ��N���Ӽ� */
/* �Y�j�M����εL����searchString�Q���N => �^�� 0 */
int strSearchReplace(char *string,char *searchString,char *replaceString)
 {
 char *currP, *baseStr;
 int  count = 0;
 $char tmp_currP[60001];
 currP = baseStr = NULL;

 while (*string)
      {
      currP = strstr (!currP ? string : baseStr, searchString);

      if (currP)
           {
           count++;
           baseStr = (currP + strlen (replaceString));
		   printf("currP=[%s]\n",currP);
           /* strcpy (currP, (currP + strlen (searchString))); */
		   
		   strcpy (tmp_currP, (currP + strlen (searchString)));
		   strcpy (currP, tmp_currP);

		   printf("currP111=[%s]\n",currP);
           memmove (currP + strlen (replaceString),
                      currP, strlen (currP) + 1);
           memcpy (currP, replaceString, strlen (replaceString));
           }
      else
           break;
      }

 return count;
 }

/* �b�M�� safe lib ��|�� strcpy( a , a+2 ) �^��ESOVRLP( 404 )�����~���D
int strSearchReplace(char *string, char *searchString, char *replaceString)
{
    char *currP, *baseStr;
    int count = 0;

    currP = baseStr = NULL;

    while (*string)
    {
        currP = strstr(!currP ? string : baseStr, searchString);

        if (currP)
        {
            count++;
            baseStr = (currP + strlen(replaceString));
            strcpy(currP, (currP + strlen(searchString)));
            memmove(currP + strlen(replaceString),
                    currP, strlen(currP) + 1);
            memcpy(currP, replaceString, strlen(replaceString));
        }
        else
            break;
    }

    return count;
}
*/

/* �q cmstrlib.ec �� char *trim(s1) �ƻs�A�é�j s2��513 (��s2�ŧi�Ȭ�200)*/
char *trim_xspace(s1)
   char *s1;
{
  static char s2[513];
  char *p1, *p2;
  int   i;

  s2[0]=0;
  p1 = s1;
  p2 = s2;
  for (i=0;i<strlen(s1);i++)
  {
     if (*p1 && *p1!= ' ')
	*p2++ = *p1++;
     else
	p1++;
  }	
  *p2 = '\0';
  return (s2);
}

/* �b�M�� safe lib ��|�����D
   strcpy(sTmpBuf, trim_xspace(sTmpBuf));  => �] strcpy ���D�AsTmpBuf �|�Q�M��

char *trim_xspace(char *str)
{
  char *end;

  * Trim leading space*
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0)  
    return str;

  * Trim trailing space*
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  * Write new null terminator character*
  end[1] = '\0';

  return str;

}*/