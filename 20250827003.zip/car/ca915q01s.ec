/************************************************/
/*                                              */
/*   PROGRAM   : ncar006.ec   BY Peter          */
/*   EDIT FROM : ncar004p.ec  BY jessie         */
/*   DATE      : 1999/05/12                     */
/*   ���M�ѤU�D���ϴ����                     */
/*   files     : ply_relation        i          */
/*               policy              i          */
/*               edr_relation        i          */
/*               endorsement         i          */
/*               ori_ply_relation    i          */
/*   output    : yymmdd_06.txt                  */
/*   data field: iassured,nassured,ipolicy,itag,*/
/*               iply_begin,iply_end,status     */
/************************************************/
#include <stdio.h>
#include <stdlib.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"

#include "api_xsrv.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"
#include "safeclib.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"

#define SUCCESS                 1

/*-----------------------------------------------------------------------*/

DBinfo  *list;
static  int  count_db;

char    DBName[5];
char    outputf[80];

char    sApHome[30];
char    filename[30];

char    edbgn[11] , edend[11];
long    policy_cnt,endorse_cnt;
long	cus_cnt = 0, fir_cnt = 0;
FILE    *fp;
int     flen;

EXEC SQL BEGIN DECLARE SECTION;
     char  eDbgn[11], eDend[11];
     long  lDbgn,     lDend;
     char  s[10],s1[10],s2[10],s3[10];
     char  userid[11];

     static char exec_time[20];     /*** �����s�@�ɶ� ***/

EXEC SQL END DECLARE SECTION;

long car915_car();
long car915_cus();
long car915_fir();

/*-----------------------------------------------------------------------*/
main(argc,argv)
int  argc;
char **argv;
{
     long  rtncode, rc;

     char  Message[1024];
     char  Message1[300];
     char  Message2[300];
     char  Message3[300];
     char  Message4[300];
     char  Message5[300];
     char  Message6[300];

     batchinit();
     strcpy(DBName,  isNULLstr(argv[1]));
     strcpy(userid,  isNULLstr(argv[2]));
     strcpy(edbgn,   isNULLstr(argv[3]));
     strcpy(edend,   isNULLstr(argv[4]));
     strcpy(outputf, isNULLstr(argv[5]));

     strcpy(eDbgn, cm_to_infdate(edbgn));
     lDbgn = cm_ymd_cdate(edbgn);

     strcpy(eDend, cm_to_infdate(edend));
     lDend = cm_ymd_cdate(edend);

     if (db_select(DBName) == False)
     {
          EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
          return M_CM_DB_NOTOPEN;
     }

     if ((list=get_db_list(&count_db,DBName)) == (char*)0 )
     {
          EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
          return M_CM_NOT_DBLIST;
     }

     s[0]  = '\0';
     s1[0] = '\0';
     s2[0] = '\0';
     s3[0] = '\0';

     strcpy(s,cm_from_infdate_100(eDbgn));
     strcpy(s1,substring(s,1,3));
     strcpy(s2,substring(s,5,2));
     strcpy(s3,substring(s,8,2));

     rtncode = getApHome(sApHome);
     if (rtncode < 0)
     {
         return rtncode;
     }
     printf("sApHome:[%s]\n",sApHome);

     /**** ����ɶ� exec_time [YYYY-MM-DD HH:MM] ****/
     strcpy(exec_time, cm_get_sysd());
     printf("{car915.0001}:EXECUTE TIME[%s]\n",exec_time);
     /***********************************************/

     strncpy(filename," ",30);
     sprintf_s(filename,30,"%s/rptftp/", sApHome);
     printf("{car915.0002}:filename[%s]\n",filename);

     rc = car915_car();
     if (rc != M_CM_OK)
         return rc;

     rc = car915_cus();
     if (rc != M_CM_OK)
         return rc;
         
     rc = car915_fir();
     if (rc != M_CM_OK)
         return rc;

     strcpy(Message,  "\n�Цܦ@�θ귽[N]/�d��[B]/�ɮפU���@�~[cmn202]�U���H�U�T�ɮ�!\n");

     sprintf_s(Message1,300,"�ɮפ@�Gcar915_car.%s%s%s\n",s1,s2,s3);
     sprintf_s(Message2,300,"�O���Ʀ@�G%ld��A����Ʀ@�G%ld��\n",policy_cnt,endorse_cnt);

     sprintf_s(Message3,300,"�ɮפG�Gcar915_cus.%s%s%s\n",s1,s2,s3);
     sprintf_s(Message4,300,"��Ʀ@�G%ld��\n",cus_cnt);
     
     sprintf_s(Message5,300,"�ɮפT�Gcar915_fir.%s%s%s\n",s1,s2,s3);
     sprintf_s(Message6,300,"��Ʀ@�G%ld��\n",fir_cnt);

     strcat(Message,Message1);
     strcat(Message,Message2);
     strcat(Message,Message3);
     strcat(Message,Message4);
     strcat(Message,Message5);
     strcat(Message,Message6);

     EWRITE(userid,M_CM_OK,Message);

     printf("END PROGRAM\n");
     return SUCCESS;

errexit:
     printf("SQLCODE=%d, sqlerrm=%s.\n",SQLCODE,sqlca.sqlerrm);
     flen=fprintf(fp,"SQLCODE=%d, sqlerrm=%s.\n",SQLCODE,sqlca.sqlerrm);
     fclose(fp);
}

long car915_car()
{
     EXEC SQL BEGIN DECLARE SECTION;
          char stmt[1024];
          char Iassured[11],Nassured[121],Itag[CA_TAG_NUM],Ipolicy[21],Dply_begin[11];
          char Dply_end[11],Status[2],Fassured[2];
          char Iassured1[11],Nassured1[121],Itag1[CA_TAG_NUM],Iendorse[21],Fassured1[2];
          char Dply_begin1[10];
          char Dply_end1[10];
          long Dply_end_long = 0 , Dply_begin_long = 0;
          long Dply_end_long1 = 0 , Dply_begin_long1 = 0;
          long Dply_end_long2 = 0 , Dply_begin_long2 = 0;
          int  id;
          int  edr_cnt = 0 , ply_cnt = 0;
          char iofficer[11],sIofficer[11],Nofficer[11];
          char Iengine[CA_ENGINE_NUM],Iengine1[CA_ENGINE_NUM];
          char sIins_type[7];
          char sIins_type_Tmp[6];
          int  ccnt38;
          int  ccnt39;
          int  ccnt238;
	  int  ccnt_edr = 0;
          int  qday;
          int  minjured_cover;
          int  medrinj_cover;
          char smedrinj[30];

          char Fedr_class[3];    /*** ��������O ***/

          char filename1[200];

     EXEC SQL END DECLARE SECTION;

     int   k;
     char  file_catalog[200];
     char  syscmd[256];
     long  rc;

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     filename1[0]    = '\0';
     file_catalog[0] = '\0';
     syscmd[0] = '\0';
     
     policy_cnt  = 0;
     endorse_cnt = 0;

     sprintf_s(filename1,200,"car915_car.%s%s%s",s1,s2,s3);
     strcpy(file_catalog, trim(filename));
     strcat(file_catalog, trim(filename1));
        
     sprintf_s(syscmd,256,"cp %s %scar915/%s",file_catalog,filename,filename1);
     printf("---- syscmd = [%s] \n  ",syscmd);

     fp=fopen(file_catalog,"w");

     EXEC SQL SET LOCK MODE TO WAIT;

     for(k=0 ; k<count_db ; k++)
     {
           /**** status:A-�s�W D-���P U-�ק� X-�h�O M-���Ħ�P ****/

           /*********************** �O�� **************************/
           stmt[0]='\0';
           sprintf_s(stmt,1024,
                  " select count(*), nvl(max(qday),0),  nvl(max(minjured_cover),0)    "
                  "   from %s:ply_ins_type                     			      "
                  "  where ipolicy   = ?  and iins_type = ?  ",list[k].dbname);
           $prepare get_ins from $stmt;

           stmt[0]='\0';
           sprintf_s(stmt,1024,
                  "SELECT %s %s %s FROM %s:%s %s:%s WHERE %s %s %s",
                  "b.iassured, a.ipolicy, b.itag,  b.nassured, ",
                  "a.dply_begin,a.dply_end,b.fassured, a.iofficer, b.iengine,",
                  "(select nname from officer where iofficer = a.iofficer)",
                   list[k].dbname,
                  "ori_ply_relation a,",
                   list[k].dbname,
                  "original_ply b",
                  "a.dpolicy between ? AND ? ",
                  "AND a.ipolicy = b.ipolicy ",
                  "AND a.fcard_class = '2' ");

           EXEC SQL PREPARE PLY_CUR1 FROM :stmt;
           EXEC SQL DECLARE curA CURSOR FOR PLY_CUR1;
           EXEC SQL OPEN    curA USING $lDbgn , $lDend;
           while(1)
           {
                $FETCH curA INTO $Iassured, $Ipolicy, $Itag, $Nassured, 
                                 $Dply_begin_long, $Dply_end_long, $Fassured,
                                 $iofficer, $Iengine, $Nofficer;

                if (SQLCODE==SQLNOTFOUND) break;

                policy_cnt += 1;

                if ((Itag[0]==' ') || (Itag[0]=='\0'))
                   strcpy(Itag,"        ");

                strcpy(Dply_begin,cm_sysd_edate(cm_cdate_str_100(Dply_begin_long)));
                strcpy(Dply_end,cm_sysd_edate(cm_cdate_str_100(Dply_end_long)));

                strcpy(iofficer, trim(iofficer));
                if (strcmp(iofficer,"Z03029")==0)   /*** ���Ħ�P ***/
                {
                    strcpy(Status,"M");
                }
                else
                {
                    strcpy(Status,"A");
                }

                /******* 950106 by Jessie clm_9501041
                if (strcmp(Fassured,"1")!=0 && strcmp(Fassured,"5")!=0)
                   strcpy(Iassured,"          ");
                ********/

                ccnt38 = 0;
                ccnt39 = 0;
                ccnt238 = 0;
                minjured_cover = 0;
                
                strcpy(sIins_type_Tmp,"     ");
                strcpy(smedrinj, "     ");
                
                strcpy(sIins_type,"38");
                $execute get_ins 
                    into $ccnt38, $qday
                   using $Ipolicy,$sIins_type;

                qday = 0;

                strcpy(sIins_type,"39");
                $execute get_ins
                    into $ccnt39, $qday
                   using $Ipolicy,$sIins_type;
                
                qday = 0;
                
                strcpy(sIins_type,"238");
                $execute get_ins 
                    into $ccnt238, $qday, $minjured_cover
                   using $Ipolicy,$sIins_type;

		
                if ((ccnt38 > 0) && (ccnt39 > 0))
                {
                   if (qday == 80)
                      strcpy(sIins_type_Tmp,"38,39B");
                   else
                      strcpy(sIins_type_Tmp,"38,39");
                }
                else if (ccnt38 > 0)
                {
                   strcpy(sIins_type_Tmp,"38   ");
                }
                else if (ccnt39 > 0)
                {
                   if (qday == 80)
                      strcpy(sIins_type_Tmp,"39B  ");
                   else
                      strcpy(sIins_type_Tmp,"39   ");
                }
                else if(ccnt238 > 0)
                {
                   /***********
                   if( minjured_cover <= 0)
                   {
                   	strcpy(smedrinj, "���p���s�w�ȪA�κ���p���H");
                   }
                   else
                   {
                   	sprintf_s(smedrinj,30 ,"�O�B%s",trim(minjured_cover))
                   }
                   ************/
                   
                   sprintf_s(smedrinj,30 ,"�O�B%d",minjured_cover);

                   printf("smedrinj:%s\n",trim(smedrinj));

                   if (qday == 30)
                      strcpy(sIins_type_Tmp,"238  ");
                   else if (qday == 100)
                      strcpy(sIins_type_Tmp,"238B   ");
                   else if (qday == 999)
                      strcpy(sIins_type_Tmp,"238D   ");
                  
                }
                else
                {
                   strcpy(sIins_type_Tmp,"     ");
                }
                
                flen=fprintf(fp,"%s|~%s|~%s|~%s|~%s|~%s|~%s|~%s|~%s|~%s|~%s|~%s\n",Iassured,Nassured,Itag,Ipolicy,
                             Dply_begin,Dply_end,Status,Iengine,iofficer,Nofficer,sIins_type_Tmp,smedrinj);
           }
           $CLOSE curA;
           $FREE  curA;

           /*********************** ��� **************************/
           stmt[0]='\0';
           sprintf_s(stmt,1024,
                  " select count(*), qday , medrinj_cover         "
                  "   from %s:edr_ins_type     "
                  "  where iendorse  = ? and iins_type = ? "
                  " GROUP BY qday , medrinj_cover ",list[k].dbname);
           $prepare get_edr_ins from $stmt;

           stmt[0]='\0';
           sprintf_s(stmt,1024,
                  "SELECT %s %s %s FROM %s:%s %s:%s WHERE %s %s %s %s %s ",
                  "a.fedr_class,b.iassured,a.ipolicy,b.itag,b.nassured,",
                  "a.dedr_begin,a.dedr_end,b.fassured,a.iendorse,b.iengine,a.iofficer,",
                  "(select nname from officer where iofficer = a.iofficer)",
                   list[k].dbname,
                  "edr_relation a,",
                   list[k].dbname,
                  "endorsement b",
                  "a.dendorse between ? AND ? ",
                  "AND a.dedr_close is not null ",
                  "AND a.iendorse = b.iendorse ",
                  "AND a.fedr_class not in ('A','B') ",                  
                  "AND a.fcard_class = '2' ");

           EXEC SQL PREPARE EDR_CUR1 FROM :stmt;
           EXEC SQL DECLARE curB CURSOR FOR EDR_CUR1;
           EXEC SQL OPEN    curB USING $lDbgn , $lDend;
           for(;;)
           {
                $FETCH curB INTO $Fedr_class,$Iassured,$Ipolicy,$Itag,$Nassured,
                                 $Dply_begin_long,$Dply_end_long,
                                 $Fassured,$Iendorse,$Iengine,$sIofficer,$Nofficer;

                if (SQLCODE==SQLNOTFOUND) break;

                if ((Itag[0]==' ') || (Itag[0]=='\0'))
                    strcpy(Itag,"        ");

                /***********
                if ((strcmp(Fassured,"1") != 0) && (strcmp(Fassured,"5") != 0))
                    strcpy(Iassured,"          ");
                ************/

                strcpy(Dply_begin , cm_sysd_edate(cm_cdate_str_100(Dply_begin_long)));
                strcpy(Dply_end   , cm_sysd_edate(cm_cdate_str_100(Dply_end_long)));

                strcpy(Fedr_class, trim(Fedr_class));

                /*** ���P ***/
                if (strcmp(Fedr_class,"1")==0)
                {
                    strcpy(Status,"D");
                }

                /*** �L�� : ���N�I�L�L�� ***/
                if (strcmp(Fedr_class,"2")==0 || strcmp(Fedr_class,"8")==0)
                {
                    strcpy(Status,"U");
                }

                /*** �h���h�O ***/
                if (strcmp(Fedr_class,"4")==0)
                {
                    strcpy(Status,"X");
                }

                /*** �@���� ***/
                if (strcmp(Fedr_class,"5")==0)
                {
                    Iassured1[0] = '\0';
                    Nassured1[0] = '\0';
                    Itag1[0]     = '\0';

                    stmt[0]      = '\0';
                    sprintf_s(stmt,1024,"SELECT %s FROM %s:%s WHERE %s ",
                                 "fassured , iassured , nassured , itag, iengine ",
                                 list[k].dbname,
                                 "original_ply ",
                                 "ipolicy = ? ");

                    EXEC SQL PREPARE EDR_CUR_TMP_5 FROM :stmt;
                    EXEC SQL DECLARE edr_cur_5 CURSOR FOR EDR_CUR_TMP_5;
                    EXEC SQL OPEN    edr_cur_5 USING  $Ipolicy;
                    EXEC SQL FETCH   edr_cur_5 INTO
                         $Fassured1, $Iassured1, $Nassured1, $Itag1, $Iengine1;
                    EXEC SQL CLOSE   edr_cur_5;

                    if ((Itag1[0]==' ') || (Itag1[0]=='\0'))
                        strcpy(Itag1,"        ");

                    /************
                    if ((strcmp(Fassured1,"1") != 0) && (strcmp(Fassured1,"5") != 0))
                        strcpy(Iassured1,"          ");
                    *************/

                    if ((strcmp(Iassured , Iassured1) != 0) ||
                        (strcmp(Nassured , Nassured1) != 0) ||
                        (strcmp(Itag     , Itag1)     != 0) ||
                        (strcmp(Iengine  , Iengine1)  != 0))
                    {
                        /*strcpy(Iassured , Iassured1);
                        strcpy(Nassured , Nassured1);
                        strcpy(Itag     , Itag1);
                        strcpy(Iengine  , Iengine1);*/

                        strcpy(Status,"U");
                    }
                    else
                    {
                        continue;
                    }
                }

                /*** ���h[�O] ***/
                if (strcmp(Fedr_class,"6")==0)
                {
                    stmt[0]='\0';
                    sprintf_s(stmt,1024,"SELECT %s FROM %s:%s WHERE %s %s ",
                                 "count(*) ",
                                 list[k].dbname,
                                 "edr_ins_type ",
                                 "iendorse = ? ",
                                 " AND iedr_type in ('02','03')");

                    EXEC SQL PREPARE EDR_CUR_TMP6 FROM :stmt;
                    EXEC SQL DECLARE edr_cur_cnt6 CURSOR FOR EDR_CUR_TMP6;
                    EXEC SQL OPEN    edr_cur_cnt6 USING  $Iendorse;
                    EXEC SQL FETCH   edr_cur_cnt6 INTO   $edr_cnt;
                    EXEC SQL CLOSE   edr_cur_cnt6;

                    stmt[0]='\0';
                    sprintf_s(stmt,1024,"SELECT %s FROM %s:%s WHERE %s ",
                                 "count(*) ",
                                 list[k].dbname,
                                 "ori_ins_type ",
                                 "ipolicy = ? ");

                    EXEC SQL PREPARE EDR_CUR_TMP2 FROM :stmt;
                    EXEC SQL DECLARE edr_cur_cnt2 CURSOR FOR EDR_CUR_TMP2;
                    EXEC SQL OPEN    edr_cur_cnt2 USING  $Ipolicy;
                    EXEC SQL FETCH   edr_cur_cnt2 INTO   $ply_cnt;
                    EXEC SQL CLOSE   edr_cur_cnt2;

                    if (edr_cnt==ply_cnt)
                    {
                         strcpy(Status,"X");
                    }
                    else
                    {
		         sprintf_s(stmt,1024,
			 " SELECT count(*)          "
			 "    FROM %s:edr_ins_type   "
			 "   WHERE iendorse = ?      "
			 "     AND iins_type IN ('38','39','238')"  
			  "    AND iedr_type = '05' ",list[k].dbname);
                         $PREPARE get_edr_id FROM $stmt;
			 $EXECUTE get_edr_id 
			     INTO $ccnt_edr
			    USING $Iendorse;
			 if (ccnt_edr == 0)
			 {
                         continue;
                         }
			 else
			 {
                            strcpy(Status,"U");
			 }
                    }
                }

                /*** ���� ***/
                if (strcmp(Fedr_class,"9")==0)
                {
                    stmt[0]      = '\0';
                    sprintf_s(stmt,1024,"SELECT %s %s FROM %s:%s %s:%s WHERE %s %s ",
                                 "b.fassured,b.iassured, b.itag, b.nassured,",
                                 "a.dply_begin, a.dply_end, b.iengine ",
                                 list[k].dbname,
                                 "ori_ply_relation a, ",
                                 list[k].dbname,
                                 "original_ply b ",
                                 "a.ipolicy = ? ",
                                 "AND a.ipolicy = b.ipolicy");

                    EXEC SQL PREPARE EDR_CUR_TMP_9 FROM :stmt;
                    EXEC SQL DECLARE edr_cur_9 CURSOR FOR EDR_CUR_TMP_9;
                    EXEC SQL OPEN    edr_cur_9 USING  $Ipolicy;
                    EXEC SQL FETCH   edr_cur_9 INTO   $Fassured1,$Iassured1,$Itag1,$Nassured1, 
                                                      $Dply_begin_long2,$Dply_end_long2,$Iengine1;
                    EXEC SQL CLOSE   edr_cur_9;

                    if ((Itag1[0]==' ') || (Itag1[0]=='\0'))
                         strcpy(Itag1,"        ");

                    /**********
                    if ((strcmp(Fassured1,"1") != 0) && (strcmp(Fassured1,"5") != 0))
                        strcpy(Iassured1,"          ");
                    **********/

                    stmt[0] = '\0';
                    sprintf_s(stmt,1024,"SELECT %s FROM %s:%s %s:%s WHERE %s %s ",
                                 "a.dply_begin, a.dply_end ",
                                 list[k].dbname,
                                 "ply_relation a, ",
                                 list[k].dbname,
                                 "policy b ",
                                 "a.ipolicy = ? ",
                                 "AND a.ipolicy = b.ipolicy");

                    EXEC SQL PREPARE EDR_CUR_TMP_9_1 FROM :stmt;
                    EXEC SQL DECLARE edr_cur_9_1 CURSOR FOR EDR_CUR_TMP_9_1;
                    EXEC SQL OPEN    edr_cur_9_1 USING  $Ipolicy;
                    EXEC SQL FETCH   edr_cur_9_1 INTO   $Dply_begin_long1, $Dply_end_long1;
                    EXEC SQL CLOSE   edr_cur_9_1;

                    if ((strcmp(Iassured , Iassured1) != 0) ||
                        (strcmp(Itag     , Itag1)     != 0) ||
                        (strcmp(Nassured , Nassured1) != 0) ||
                        (strcmp(Iengine  , Iengine1)  != 0))
                    {
                         strcpy(Status,"U");

                        /* strcpy(Iassured , Iassured1);
                         strcpy(Nassured , Nassured1);
                         strcpy(Itag     , Itag1);
                         strcpy(Iengine  , Iengine1);*/
                    }

                    if ((Dply_begin_long1 != Dply_begin_long2) ||
                        (Dply_end_long1   != Dply_end_long2))
                    {
                         strcpy(Status,"U");

                         strcpy(Dply_begin , cm_sysd_edate(cm_cdate_str_100(Dply_begin_long1)));
                         strcpy(Dply_end   , cm_sysd_edate(cm_cdate_str_100(Dply_end_long1)));
                    }

                    if ((strcmp(Iassured , Iassured1) == 0) &&
                        (strcmp(Itag     , Itag1)     == 0) &&
                        (strcmp(Iengine  , Iengine1)  == 0) &&
                        (strcmp(Nassured , Nassured1) == 0) &&
                        (Dply_begin_long1 == Dply_begin_long2) &&
                        (Dply_end_long1   == Dply_end_long2))
                    {
		         sprintf_s(stmt,1024,
			 " SELECT count(*)          "
			 "    FROM %s:edr_ins_type   "
			 "   WHERE iendorse = ?      "
			    "  AND iins_type IN ('38','39','238') " 
			    "  AND iedr_type = '05' ",list[k].dbname);
                         $PREPARE get_edr_ida FROM $stmt;
			 $EXECUTE get_edr_ida 
			     INTO $ccnt_edr
			    USING $Iendorse;
			 if (ccnt_edr == 0)
			 {
                         continue;
                         }
			 else
			 {
                            strcpy(Status,"U");
			 }
                    }
                }

                if ((Status[0]==' ') || (Status[0]=='\0')) 
                {
		    if ((strcmp(Iassured , Iassured1) != 0) ||
                        (strcmp(Nassured , Nassured1) != 0) ||
                        (strcmp(Itag     , Itag1)     != 0) ||
                        (strcmp(Iengine  , Iengine1)  != 0))
                    {
                       /* strcpy(Iassured , Iassured1);
                        strcpy(Nassured , Nassured1);
                        strcpy(Itag     , Itag1);
                        strcpy(Iengine  , Iengine1);*/

                        strcpy(Status,"U");
                    }
                    else
                    {
		         sprintf_s(stmt,1024,
			 " SELECT count(*)          "
			   "  FROM %s:edr_ins_type   "
			  "  WHERE iendorse = ?      "
			   "   AND iins_type IN ('38','39','238')  "
			   "   AND iedr_type = '05' ",list[k].dbname);
                         $PREPARE get_edr_idb FROM $stmt;
			 $EXECUTE get_edr_idb 
			     INTO $ccnt_edr
			    USING $Iendorse;
			 if (ccnt_edr == 0)
			 {
                        continue;
                         }
			 else
			 {
                            strcpy(Status,"U");
			 }
                    }
                }

                ccnt38 = 0;
                ccnt39 = 0;
                ccnt238 = 0;

                medrinj_cover = 0;
                strcpy(sIins_type_Tmp," ");
		strcpy(smedrinj, "     ");
		
                qday = 0;
                strcpy(sIins_type,"38");
                if (strcmp(Fedr_class,"2")==0 || strcmp(Fedr_class,"8")==0)
                {
                $execute get_ins 
                    into $ccnt38, $qday
                   using $Ipolicy,$sIins_type;
       	 	}
                else
                {
                $execute get_edr_ins
                    into $ccnt38, $qday
                   using $Iendorse,$sIins_type;
		}

                qday = 0;
                strcpy(sIins_type,"39");
                if (strcmp(Fedr_class,"2")==0 || strcmp(Fedr_class,"8")==0)
                {
                $execute get_ins 
                    into $ccnt39, $qday
                   using $Ipolicy,$sIins_type;
                }
                else
                {
                $execute get_edr_ins
                    into $ccnt39, $qday
                   using $Iendorse,$sIins_type;
		}
		
		qday = 0;
                strcpy(sIins_type,"238");
                if (strcmp(Fedr_class,"2")==0 || strcmp(Fedr_class,"8")==0)
                {
                $execute get_ins 
                    into $ccnt238, $qday, $medrinj_cover
                   using $Ipolicy,$sIins_type;
               
                }
                else
                {
                $execute get_edr_ins
                    into $ccnt238, $qday, $medrinj_cover
                   using $Iendorse,$sIins_type;
		
		}

                if ((ccnt38 > 0) && (ccnt39 > 0))
                {
                   if (qday == 80)
                      strcpy(sIins_type_Tmp,"38,39B");
                   else if (qday >=50)   /**��[������**/
                      strcpy(sIins_type_Tmp,"38,39B");
                   else
                      strcpy(sIins_type_Tmp,"38,39");
                }
                else if (ccnt38 > 0)
                {
                   strcpy(sIins_type_Tmp,"38   ");
                }
                else if (ccnt39 > 0)
                {
                   if (qday == 80)
                      strcpy(sIins_type_Tmp,"39B   ");
                   else if (qday >=50)   /**��[������**/
                      strcpy(sIins_type_Tmp,"39B   ");
                   else
                      strcpy(sIins_type_Tmp,"39   ");
                }
                else if (ccnt238 > 0)
                {
                   printf("medrinj_cover:%d\n",medrinj_cover);
                   if(medrinj_cover <= 0)
                   {
                   	sprintf_s(smedrinj,30,"%s","���p���s�w�ȪA�κ���p���H");
                   }
                   else
                   {
                   	
                   	sprintf_s(smedrinj,30,"�O�B%d",medrinj_cover);
                   }
                   printf("smedrinj:%s\n",smedrinj);
                   
                   if (qday == 30)
                      strcpy(sIins_type_Tmp,"238  ");
                   else if (qday == -30)
                      strcpy(sIins_type_Tmp,"238   ");
                   else if (qday == 100)
                      strcpy(sIins_type_Tmp,"238B  ");
                   else if (qday == -100)
                      strcpy(sIins_type_Tmp,"238B  ");
                   else if (qday == -899)
                      strcpy(sIins_type_Tmp,"238B  ");
                   else if (qday == 999)
                      strcpy(sIins_type_Tmp,"238D  ");
                   else if (qday == -999)
                      strcpy(sIins_type_Tmp,"238D  ");
                   else if (qday == 899)
                      strcpy(sIins_type_Tmp,"238D  ");
                }
                else
                {
                   strcpy(sIins_type_Tmp,"     ");
                }
                
                flen=fprintf(fp,"%s|~%s|~%s|~%s|~%s|~%s|~%s|~%s|~%s|~%s|~%s|~%s\n",Iassured,Nassured,Itag,Ipolicy,
                             Dply_begin,Dply_end,Status,Iengine,sIofficer,Nofficer,sIins_type_Tmp,smedrinj);
                endorse_cnt += 1;
                strcpy(Status," ");
           }
           $CLOSE curB;
           $FREE  curB;
     }

     fclose(fp);

     rc = system(syscmd);
     EXEC SQL SET LOCK MODE TO NOT WAIT;

     EXEC SQL INSERT INTO rptftplist (nuserid, ipgid,     noutfile,   dcreate)
                              VALUES ($userid, 'car915',  $filename1, $exec_time);

     return M_CM_OK;

errexit:
     printf("SQLCODE=%d, sqlerrm=%s.\n",SQLCODE,sqlca.sqlerrm);
     flen=fprintf(fp,"SQLCODE=%d, sqlerrm=%s.\n",SQLCODE,sqlca.sqlerrm);
     fclose(fp);
}

long car915_cus()
{
     EXEC SQL BEGIN DECLARE SECTION;
          char   stmt[1024];
          char   Ifpce_id[11],Nchi_full[101],Itag[CA_TAG_NUM],Dcofirm[10];
          long   Dcofirm_long;
          int    id;
          char   filename2[200];
          char   sys_dbname[20];
     EXEC SQL END   DECLARE SECTION;

     char  file_catalog[200];

     cus_cnt = 0;

     sprintf_s(filename2,200,"car915_cus.%s%s%s",s1,s2,s3);

     strcpy(file_catalog, trim(filename));
     strcat(file_catalog, trim(filename2));

     fp=fopen(file_catalog,"w");

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     EXEC SQL SELECT dbname 
                INTO :sys_dbname
                FROM servertbl
               WHERE branch = 'S1';

     strcpy(sys_dbname, trim(sys_dbname));

     stmt[0]='\0';
     sprintf_s(stmt,1024,"SELECT %s FROM %s:%s %s:%s WHERE %s %s %s %s %s %s",
                  "a.ifpce_id,b.nchi_full,a.itag,a.dcofirm  ",
                  sys_dbname,
                  "cu_cofirm_ply a, ",
                  sys_dbname,
                  "cu_customer b ",
                  " a.ifpce_id = b.ifpce_id ",
                  " AND a.ifpce_id_ext = b.ifpce_id_ext ",
                  " AND a.irescue is not null ",
                  " AND a.irescue != ' ' ",
                  " AND a.insure_type != 'F' ",
                  " AND ((a.dcreate between ? and ?) OR (a.dupdate between ? and ?))");

     $PREPARE cus_cur1 FROM :stmt;
     $DECLARE cusA CURSOR FOR cus_cur1;
     $OPEN    cusA USING $lDbgn , $lDend , $lDbgn , $lDend;
     for(;;)
     {
           $FETCH cusA INTO $Ifpce_id,$Nchi_full,$Itag,$Dcofirm_long;
           if (SQLCODE==SQLNOTFOUND) break;
           cus_cnt += 1;

           strcpy(Dcofirm,cm_cdate_str_100(Dcofirm_long));

           flen=fprintf(fp,"%s%s%s%s\n",Ifpce_id,Nchi_full,Itag,Dcofirm);

     }
     $CLOSE cusA;
     $FREE  cusA;

     fclose(fp);

     EXEC SQL INSERT INTO rptftplist (nuserid, ipgid,     noutfile,   dcreate)
                              VALUES ($userid, 'car915',  $filename2, $exec_time);

     return M_CM_OK;

errexit:
     printf("SQLCODE=%d, sqlerrm=%s.\n",SQLCODE,sqlca.sqlerrm);
     flen=fprintf(fp,"SQLCODE=%d, sqlerrm=%s.\n",SQLCODE,sqlca.sqlerrm);
     fclose(fp);
}

/*  �����I�Ȥ�W�� */
/*  Add by Julia Han in 2007/02/26 */
long car915_fir()
{
     EXEC SQL BEGIN DECLARE SECTION;
          char   stmt[1024];
          char   Ifpce_id[11],Nchi_full[101],Itag[CA_TAG_NUM],Dcofirm[10];
          long   Dcofirm_long;
          int    id;
          char   filename3[200];
          char   sys_dbname[20];
     EXEC SQL END   DECLARE SECTION;

     char  file_catalog[200];

     fir_cnt = 0;

     sprintf_s(filename3,200,"car915_fir.%s%s%s",s1,s2,s3);

     strcpy(file_catalog, trim(filename));
     strcat(file_catalog, trim(filename3));

     fp=fopen(file_catalog,"w");

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     EXEC SQL SELECT dbname 
                INTO :sys_dbname
                FROM servertbl
               WHERE branch = 'S1';

     strcpy(sys_dbname, trim(sys_dbname));

     stmt[0]='\0';
     sprintf_s(stmt,1024,"SELECT %s FROM %s:%s %s:%s WHERE %s %s %s %s %s %s",
                  "a.ifpce_id,b.nchi_full,a.itag,a.dcofirm  ",
                  sys_dbname,
                  "cu_cofirm_ply a, ",
                  sys_dbname,
                  "cu_customer b ",
                  " a.ifpce_id = b.ifpce_id ",
                  " AND a.ifpce_id_ext = b.ifpce_id_ext ",
                  " AND a.irescue is not null ",
                  " AND a.irescue != ' ' ",
                  " AND a.insure_type = 'F' ",
                  " AND ((a.dcreate between ? and ?) OR (a.dupdate between ? and ?))");

     $PREPARE fir_cur1 FROM :stmt;
     $DECLARE firA CURSOR FOR fir_cur1;
     $OPEN    firA USING $lDbgn , $lDend , $lDbgn , $lDend;
     for(;;)
     {
           $FETCH firA INTO $Ifpce_id,$Nchi_full,$Itag,$Dcofirm_long;
           if (SQLCODE==SQLNOTFOUND) break;
           fir_cnt += 1;

           strcpy(Dcofirm,cm_cdate_str_100(Dcofirm_long));

           flen=fprintf(fp,"%s%s%s%s\n",Ifpce_id,Nchi_full,Itag,Dcofirm);

     }
     $CLOSE firA;
     $FREE  firA;

     fclose(fp);

     EXEC SQL INSERT INTO rptftplist (nuserid, ipgid,     noutfile,   dcreate)
                              VALUES ($userid, 'car915',  $filename3, $exec_time);

     return M_CM_OK;

errexit:
     printf("SQLCODE=%d, sqlerrm=%s.\n",SQLCODE,sqlca.sqlerrm);
     flen=fprintf(fp,"SQLCODE=%d, sqlerrm=%s.\n",SQLCODE,sqlca.sqlerrm);
     fclose(fp);
}
/********************************************************end program*/
