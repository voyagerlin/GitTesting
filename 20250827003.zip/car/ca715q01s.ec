/**********************************************************************/
/*                                                                    */   
/*   program id   : ca715q01s.ec                                      */
/*   program name : �����I�ӫO��Ʃ��Ӫ���                            */
/*   date written : 2002/10/04                                        */
/*   Checked for ����100�~�M��                                        */
/**********************************************************************/
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include "car_equip.h"
#include <math.h>
#include "safeclib.h"
/*--------------------------------------------------------------------*/
DBinfo  *list;
int  count_db, i;
char  agent_str[512],dtype_str[1];
int   dtype;


$char DBName[05], iForm_Tp[03];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1]; 
char  outputf[N_FILE+1], userid[11];


char  msgbuf[100];
$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;
$int  dendorse_isnull = 0;
$char option1[2],option2[2];
$char ibranch[11];
$char dpolicy_beg[YYYYMMDD],dpolicy_end[YYYYMMDD],dpolicy[YYYYMMDD];
$char dbng[11],dend[11],p_bgn[11],p_end[11];
$char DBName[5];
$char iofficer[11],icorps[10],iquota[11],ileader[11];
$char ilast_ply[21],dply_begin[11],dply_end[11],dendorse[21];
$char dendorse1[21];
$char ipolicy[21],iclaim[21],dclaim[11];
$char nequipment[31],iassured[11];
$char itag[CA_TAG_NUM],iengine[30];
$double mcar_price = 0,last_mdeduct,mdeduct,pay;
$char edr_iendorse[21],C_iendorse[21],fedr_class[3],iedr_type[3];
char  nfedr_class[20],niedr_type[20];
int   fedr,iedr;
$double medr_amt = 0,mply_amt,ori_mply_amt;
$char last_iins_type[INSURANCE_TYPE],iins_type[INSURANCE_TYPE],edr_iins_type[INSURANCE_TYPE];
$char ori_iassured[11];
$char buf1[100],buf2[100];
$char stmt[1000];
$char full_dbname[20];
$char sFull[20];
$char nname[21];
$char iofficer_nname[21];
$char ileader_nname[21],iquota_14[7],nbranch[20];
$char dgree[2];
int db_count = 0;
int count;
int rc;
int i,n = 0,fetch;
$char icode[2];
$char ncode[20];
$char n_ncode[100];
int flag,fetch_flag;
extern struct sEquip *IfirstEquip, *IcurrEquip, *IlastEquip, *IEquip_ptr;
char equipdecode[201];

static int  max_cnt,num;
static char *get_car_full_db();  /*   �ǤJ�O�渹��X���O�檺�k�ݸ��*/
long car715_get_db();
long car715_build();
void car715_title();
long car715_body();
long car715_print();
long car715_print_1();
long car715_print_2();
long car715_ply_ins();
long car715_edr();
long car715_ori_ins();

/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{  

   int rc;
   batchinit();

     strcpy(DBName,       isNULLstr(argv[1]));
     strcpy(userid,       isNULLstr(argv[2]));
     strcpy(option1,      isNULLstr(argv[3]));
     strcpy(dpolicy_beg,  isNULLstr(argv[4]));
     strcpy(dpolicy_end,  isNULLstr(argv[5]));
     strcpy(option2,      isNULLstr(argv[6]));
     strcpy(ibranch,      isNULLstr(argv[7]));
     strcpy(outputf,      isNULLstr(argv[8]));

     strcpy(p_bgn,dpolicy_beg);
     strcpy(p_end,dpolicy_end);
     strcpy(dbng,cm_to_infdate(dpolicy_beg));
     strcpy(dend,cm_to_infdate(dpolicy_end));

     printf("DBName[%s]\n",DBName);

   rc = car715_get_db();
    if (rc != SUCCESS)
       return rc;

   max_cnt=0;
   rc = car715_build();
   printf(" END build\n");
   if ( rc != FAIL){
    if ((rc=save_form_info(F_BLK0, "CA", 715, userid, iForm_Tp, max_cnt, outputf))<0)
     {
        strcpy(msgbuf,"save_form_info failed");
        return rc;
   
     }

   
    }
}
/*--------------------------------------------------------------------*/

long car715_build()
{
   $char  TitleFmt[N_FILE+1],BodyFmt[N_FILE+1];
   int    rc;
   
   
   $WHENEVER SQLERROR GOTO errexit;
   
   if (db_select(DBName) == False)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 715;

   strcpy( TitleFmt,rtrim(TitleFmt));
   strcpy( BodyFmt,rtrim(BodyFmt));
   sprintf_s(TitleFile, sizeof TitleFile,"%s.ti",outputf);
   sprintf_s(BodyFile, sizeof BodyFile,"%s.bd",outputf);

printf("titlefmt = [%s]\n",TitleFile);

   rgu_init_report(TitleFmt,TitleFile);
   car715_title();
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);
   rc = car715_body();
   if (rc != M_CM_OK)
       return rc;



printf( " next is M_CM_OK \n");           
   return M_CM_OK;

errexit:
/*   sqlfatal();   */
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;  
}

   
long car715_get_db()
{

   if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }
    
   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   return SUCCESS;

errexit:
/*   sqlfatal();   */
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

void car715_title()
{
  rgu_put_head_string(1," ");
  rgu_put_head_string(1," "); 
  rgu_put_head();

}


long car715_body()
{
  int ins;


  $WHENEVER SQLERROR GOTO errexit;


 if (db_select(DBName) == False)
 {
    EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");   
    return M_CM_DB_NOTOPEN;
 } 

    
    rgu_put_body_string(1, dbng,1);
    rgu_put_body_string(1, dend,1);
    rgu_put_body_string(1, cm_get_sysd(), 1);
    rgu_put_body(1); max_cnt += 5;

     /*  �P�_���@���ΫO�N��  */
     if(strcmp(trim(option1),"1")==0)
     {sprintf_s(buf1, sizeof buf1,"AND  a.iofficer[1] BETWEEN 'A' AND 'P' " ); }
      if(strcmp(trim(option1),"2")==0)
     {sprintf_s(buf1, sizeof buf1,"AND  a.iofficer[1] NOT BETWEEN 'A' AND 'P' " ); }

     /*  �P�_ ibranch �����q�O�ҰϧO�γ��O  */
      if(strcmp(trim(option2),"1")==0)
     {   sprintf_s(buf2, sizeof buf2,"AND c.iupcomp ='%s'",ibranch );       }
      if(strcmp(trim(option2),"2")==0)
     {  sprintf_s(buf2, sizeof buf2,"AND c.iupbranch = '%s'",ibranch );     }
      if(strcmp(trim(option2),"3")==0)
     {  sprintf_s(buf2, sizeof buf2,"AND c.ibranch = '%s'",ibranch );       }

     /* �Q��ibranch ��X���ݤ���Ʈw */
      strcpy(sFull,get_full_dbname(ibranch));
      printf("sFull[%s]\n",sFull);

      sprintf_s(stmt, sizeof stmt,
      "  SELECT  a.iofficer,a.icorps,a.iquota,a.ileader,a.ipolicy,  "
      "          a.ilast_ply, a.dply_begin,a.dply_end,a.dendorse,   "
      "          b.nequipment,b.iassured,dpolicy,                   "
      "          b.itag,b.iengine,b.mcar_price             "
      "    FROM  %s:ply_relation a,%s:policy b,branch c    "
      "   WHERE  a.ipolicy = b.ipolicy                     "
      "     AND  a.ibranch = c.ibranch                     "
      "     AND  a.fcard_class = '2'                       "
      "     AND  a.dpolicy BETWEEN '%s' AND '%s' %s %s ",
               sFull,sFull,dbng,dend,buf1,buf2);

      printf(" stmt[%s]\n",stmt);

      $PREPARE a_id FROM $stmt;
      $DECLARE cur1 CURSOR for a_id;
      $OPEN cur1;

      for(;;)
      {
        $FETCH cur1 INTO $iofficer,$icorps,$iquota,$ileader,$ipolicy,
                         $ilast_ply,$dply_begin,$dply_end,$dendorse:dendorse_isnull,
                         $nequipment,$iassured,$dpolicy,
                         $itag,$iengine,$mcar_price;


        if(SQLCODE == SQLNOTFOUND) break;

        flag = 0;
        printf("ipolicy[%s]\n",ipolicy);

        strcpy(full_dbname,get_car_full_db(ipolicy));

         /* ���IC���P�_ :Ū�����  Ū�� ori_ply_relation     */

          sprintf_s(stmt, sizeof stmt,"select iassured from %s:original_ply  "
                        "  where  ipolicy = ? ",full_dbname);

          $PREPARE a_idD FROM $stmt;
          $DECLARE curD CURSOR for a_idD;
          $OPEN curD USING $ipolicy;
          while(1)
          {
             $FETCH curD INTO $ori_iassured;

             if(SQLCODE == SQLNOTFOUND)  break;

             if (strcmp(iassured,ori_iassured)!=0)
             {
               printf(" �i�J���IC ***************************\n");
               sprintf_s(stmt, sizeof stmt,"select  iendorse,fedr_class,dendorse from %s:edr_relation  "
                            "  where  ipolicy = ? AND iendorse[6,8] != 'CVP' ",full_dbname);

               $PREPARE a_idE FROM $stmt;
               $DECLARE curE CURSOR for a_idE;
               $OPEN curE USING $ipolicy;
               while(1)
               {
                  $FETCH curE INTO $edr_iendorse,$fedr_class,$dendorse1;
                  if(SQLCODE == SQLNOTFOUND)  break;
                  
                  printf("edr_iendorse[%s]\n",edr_iendorse);
                 sprintf_s(stmt, sizeof stmt,"select  iins_type,iedr_type from %s:edr_ins_type  "
                                "where  iendorse = ?                     "
                                "  and  iins_type in ('01','05','08','09','11')  "
                                "  and  medrdmg_cover > 0 ",full_dbname);
                 printf("stmt[%s]\n",stmt);
                $PREPARE a_idF FROM $stmt;
                $DECLARE curF CURSOR for a_idF;
                $OPEN curF USING $edr_iendorse;
                while(1)
                {
                    $FETCH curF INTO $iins_type,$iedr_type;
                    strcpy(dgree,"C");
                    if(SQLCODE == SQLNOTFOUND)  break;

                     printf("ipolicy[%s],iins_type[%s]\n",ipolicy,iins_type);

                     car715_ori_ins();
                     car715_ply_ins();
                     rc=car715_print();
                     flag = 1;

                }   /* end edr_iins_type     */
               }    /* end edr_relation      */
             }      /* end if                */
           }        /* end ori_ply_relation  */

              if(flag == 1)
              {   continue;   }


             /* ���IA���P�_ :Ū�������  */
             /* �bply_relation�u�O�������,�����餣���ťզA�h�P�_ */
             if(dendorse_isnull!=-1)
             {
                  printf(" �i�J���IA ***************************\n");
                  sprintf_s(stmt, sizeof stmt,"select a.iendorse,a.fedr_class,b.iedr_type,b.iins_type,  "
                         "   (b.medrinj_cover+b.medrdea_cover+b.medrdmg_cover) medr_amt, "
                         "      a.dendorse   "
                         " from %s:edr_relation a,%s:edr_ins_type b                      "
                         "where  ipolicy = ?                                             "
                         "  and  a.iendorse = b.iendorse                                 "
                         "  and  a.iendorse[6,8] != 'CVP'                                "
                         "  and  b.iedr_type in ('04','05')                                  "
                         "  and  b.iins_type in ('01','05','08','09','11','17','02','12','51','14','24') ",
                            full_dbname,full_dbname);


                  $PREPARE a_idA FROM $stmt;
                  $DECLARE curA CURSOR for a_idA;
                  $OPEN curA USING $ipolicy;
                  while(1)
                  {
                      $FETCH curA INTO $edr_iendorse,$fedr_class,$iedr_type,$iins_type,
                                       $medr_amt,$dendorse1;

                      strcpy(dgree,"A");

                      if(SQLCODE == SQLNOTFOUND)  break;


                            if(strcmp(iedr_type,"05")==0)
                              {
                                 car715_ori_ins();
                                 car715_ply_ins();
                                 rc=car715_print();
                                 flag = 1;
                              }
                            else
                              { if(medr_amt >  0)
                                {
                                    car715_ori_ins();
                                    car715_ply_ins();
                                    rc=car715_print();
                                    flag = 1;
                                }
                              }

                  }   /*  end A while */
              }       /*  end dendorse if */

             if(flag == 1)
             { continue;  }


            /*  ���IB  �P�_��O�渹�B���O��1  */
            if ((strlen(trim(ilast_ply))!=0 ) && (equip_cmp(nequipment,"01")==TRUE))
            {
                    strcpy(iedr_type," ");
                    strcpy(fedr_class," ");
                    strcpy(dendorse1,dpolicy);
                    printf(" �i�J���IB  *********************\n");
                    strcpy(full_dbname,get_car_full_db(ilast_ply));

                 /* ��ilast_ply ���I�ة��� */
                    sprintf_s(stmt, sizeof stmt,"select iins_type,mdeduct "
                                   "  from %s:ply_ins_type  "
                                   " where ipolicy = ?  "
                                   "   and iins_type in ('05','09','11') ",full_dbname);
                    $PREPARE a_idB FROM $stmt;
                    $DECLARE curB CURSOR for a_idB;
                    $OPEN curB USING $ilast_ply;
              while(1)
              {
                    $FETCH curB INTO $last_iins_type,$last_mdeduct;

                    if(SQLCODE == SQLNOTFOUND)  break;

                    strcpy(full_dbname,get_car_full_db(ipolicy));
                   /* ��ipolicy ���I�ة���  */
                   sprintf_s(stmt, sizeof stmt,"select iins_type,mdeduct,(minjured_cover+mdeath_cover+mdamage_cover) mply_amt  "
                                  "from %s:ply_ins_type  "
                                  "where  ipolicy = ?  "
                                  "  and  mdamage_cover !=0 ",full_dbname);

                   $PREPARE a_idC FROM $stmt;
                   $DECLARE curC CURSOR for a_idC;
                   $OPEN curC USING $ipolicy;
                   while(1)
                   {

                      $FETCH curC INTO $iins_type,$mdeduct,$mply_amt;

                      strcpy(dgree,"B");

                     if(SQLCODE == SQLNOTFOUND)  break;

                        if(strcmp(trim(last_iins_type),"09")==0)
                        {
                           if((strcmp(trim(iins_type),"01")==0) || (strcmp(trim(iins_type),"05")==0) || (strcmp(trim(iins_type),"08")==0))
                           {   car715_ori_ins();
                               car715_edr();
                               rc=car715_print();
                               flag = 1;
                           }
                        }

                        if(strcmp(trim(last_iins_type),"05")==0)
                        {
                           if((strcmp(trim(iins_type),"01")==0) || (strcmp(trim(iins_type),"08")==0))
                           {   car715_ori_ins();
                               car715_edr();
                               rc=car715_print();
                               flag = 1;
                           }


                        }
                       if((strcmp(trim(last_iins_type),"11")==0) && (last_mdeduct==10))
                        {
                           if((strcmp(trim(iins_type),"11")==0) && (mdeduct==20))
                           {   car715_ori_ins();
                               car715_edr();
                               rc=car715_print();
                               flag = 1;
                           }
                        }
                    }         /* end ipolicy iins_type   */
                }             /* end ilast_ply iins_type */
             }                /* end ilast_ply if        */
   �@   }         


          return M_CM_OK;

   errexit:
      printf("build:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
      EWRITE(userid, SQLCODE, sqlca.sqlerrm);
      exit(1);
   }

 /*----------------------------------------------------------------------------------------*/
   
long car715_print()
{
    
  char str[20];
  char tmp_buf[30];


  $WHENEVER SQLERROR GOTO errexit;

   fetch_flag = 0;

      $SELECT nname
         INTO $iofficer_nname
         FROM officer
        WHERE iofficer = $iofficer;

      strcpy(iquota_14,substring(iquota,1,4));
      strcat(iquota_14,"00");
   printf("INTO 1 \n");
      $SELECT nbranch
         INTO $nbranch
         FROM sa_branch_type
        WHERE ibranch = $iquota_14;

   printf("INTO 2 \n");
       $SELECT nname
          INTO $ileader_nname
          FROM officer
         WHERE iofficer = $ileader;


    printf(" 1 INTO car715_print ipolicy[%s]\n",ipolicy);
    printf(" edr_iendorse [%s]\n",edr_iendorse);
    printf(" nequipment[%s]\n",nequipment);

    strcpy(equipdecode,equip_get(nequipment));
    IEquip_ptr=IfirstEquip;
    while (IEquip_ptr)
    {
      strcpy(icode,IEquip_ptr->sequip);
      printf("into struct icode[%s]\n",icode);
              $SELECT ncode
                 INTO $ncode
                 FROM cu_code_data
                WHERE itype = '25'
                  AND icode = $icode;
                   if (SQLCODE == SQLNOTFOUND)
                      strcpy(ncode," ");

              strcat(n_ncode,ncode);

      IEquip_ptr=IEquip_ptr->next;
    }

/*******************************************************    
      for(i=0;i<=29;i++)
      {
          if(strncmp(nequipment + i,"0",1)!=0)
           {
              n = i+1;
              strcpy(icode,itoa(n));

   printf("INTO 3 \n");
              $SELECT ncode
                 INTO $ncode
                 FROM cu_code_data
                WHERE itype = '25'
                  AND icode = $icode;

              strcat(n_ncode,ncode);

           }

      }
******************************************************/


   printf(" 2 INTO car715_print ipolicy[%s]\n",ipolicy);
        fedr=atoi(fedr_class);
        switch(fedr){
                    case 1:
                         strcpy (nfedr_class,"���P");
                         break;
                    case 2:
                          strcpy (nfedr_class,"�L��");
                          break;
                    case 4:
                          strcpy (nfedr_class,"�h���h�O");
                          break;
                    case 5:
                         strcpy (nfedr_class,"�@����");
                          break;
                    case 6:
                         strcpy (nfedr_class,"���B���");
                          break;
                    case 9:
                         strcpy (nfedr_class,"����");
                          break;
                    default:
                         strcpy(nfedr_class," ");
                         break; 
                     }

        iedr=atoi(iedr_type);
        switch(iedr){
                    case 1:
                         strcpy (niedr_type,"���P");
                         break;
                    case 2:
                          strcpy (niedr_type,"���~�h�O");
                          break;
                    case 3:
                          strcpy (niedr_type,"�j��h�O");
                          break;
                    case 4:
                         strcpy (niedr_type,"�O�B�ܰ�");
                          break;
                    case 5:
                         strcpy (niedr_type,"�[�O�I��");
                          break;
                    case 20:
                         strcpy (niedr_type,"�ۭt�B�ܰ�");
                          break;
                    case 40:
                         strcpy (niedr_type,"�O�O�ܰ�");
                          break;
                    case 50:
                         strcpy (niedr_type,"�_��");
                          break;
                    default:
                         strcpy( niedr_type," ");
                          break;
                     }


         strcpy(full_dbname,get_car_full_db(ipolicy));
         sprintf_s(stmt, sizeof stmt,"select a.iclaim,DATE(a.dclaim),   "
                       "      SUM(DECODE(b.fstl,'1',mins_stl+mins_proc,mins_proc-mins_stl))  "
                       " from %s:appraisal a,%s:stl_ins_type b     "
                       "where ipolicy = ?                          "
                       "  and a.iclaim = b.iclaim                  "
                       "  and b.dgroup IS NOT NULL                 "
                       "  and b.iins_type = ?                      "
                       "group by 1,2                               "
                       "order by 1 ",full_dbname,full_dbname   );

         $PREPARE a_idL FROM $stmt;
         $DECLARE curL CURSOR for a_idL;
         $OPEN curL USING $ipolicy,$iins_type;
         fetch = 0;
         fetch_flag = 0;
         while(1)
         {
             $FETCH curL INTO $iclaim,$dclaim,$pay;

             if(SQLCODE == SQLNOTFOUND)
              {
                 if(fetch_flag == 1)
                 {  break;             }
                 else
                 {  car715_print_1();    break;       }
              }

              if(fetch == 0)
              {
                  car715_print_1();
                  fetch_flag = 1;
                  fetch ++;
              }
              else
              {   car715_print_2();     }


         }


     return M_CM_OK;
     errexit:
        printf("build:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
        EWRITE(userid, SQLCODE, sqlca.sqlerrm);
        exit(1);

}

/*-------------------------------------------------------------------*/
char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
   char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
   char sTmp_db_name[21];

   sTmp_db_name[0]='\0';
   if (*sIpolicy != '\0' && *sIpolicy !=' ')
   {
           sTmp_db_name[0]='\0';
           strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
           strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
                  USE_BRANCH_ID));
           strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
   }
  return sTmp_db_name;
}
/*-------------------------------------------------------------------*/

long car715_print_1()
{
      char tmp_buf[30];
     $WHENEVER SQLERROR GOTO errexit;

     rgu_put_body_string(2, trim(iofficer), 1);
     rgu_put_body_string(2, trim(iofficer_nname), 1);
     rgu_put_body_string(2, trim(icorps), 1);
     rgu_put_body_string(2, trim(nbranch), 1);
     rgu_put_body_string(2, trim(ileader_nname), 1);
     rgu_put_body_string(2, trim(ipolicy), 1);
     rgu_put_body_string(2, trim(edr_iendorse), 1);
     rgu_put_body_string(2, trim(itag), 1);
     rgu_put_body_string(2, trim(iengine), 1);

     rfmtdouble(mcar_price, "------&.#", tmp_buf);
     rgu_put_body_string(2, trim(tmp_buf), 2);

     rgu_put_body_string(2, trim(dgree), 2);
     rgu_put_body_string(2, trim(iins_type), 1);

     rfmtdouble(ori_mply_amt, "-----------&", tmp_buf);
     rgu_put_body_string(2, trim(tmp_buf), 2);

     rfmtdouble(mply_amt, "-----------&", tmp_buf);
     rgu_put_body_string(2, trim(tmp_buf), 2);

     rfmtdouble(mdeduct, "-----------&", tmp_buf);
     rgu_put_body_string(2, trim(tmp_buf), 2);

     rgu_put_body_string(2, trim(nfedr_class), 1);
     rgu_put_body_string(2, trim(niedr_type), 1);

     /***
     if(dendorse_isnull==-1)
     { rgu_put_body_string(2, trim(dpolicy), 1); }
     else
     { 
       rgu_put_body_string(2, trim(dendorse), 1); 
     }
     ***/

     rgu_put_body_string(2, trim(dendorse1), 1); 
     rgu_put_body_string(2, trim(dply_begin), 1);
     rgu_put_body_string(2, trim(dply_end), 1);
     rgu_put_body_string(2, trim(n_ncode), 1);

     rgu_put_body_string(2, trim(iclaim), 1);
     rgu_put_body_string(2, trim(dclaim), 1);

     rfmtdouble(pay, "-----------&", tmp_buf);
     rgu_put_body_string(2, trim(tmp_buf), 2);
     rgu_put_body(2);
     max_cnt++;

      /*  iofficer[0]='\0';
          iofficer_nname[0]='\0';
          icorps[0]='\0';
          nbranch[0]='\0';         */
          ileader_nname[0]='\0';
          edr_iendorse[0]='\0';
      /*  itag[0]='\0';
          iengine[0]='\0';         */
          dgree[0]='\0';
          iins_type[0]='\0';
      /*  mcar_price=0;            */
      /*  ori_mply_amt=0;          */
          mply_amt=0;
          mdeduct=0;
          fedr_class[0]='\0';
          nfedr_class[0]='\0';
          niedr_type[0]='\0';
          iedr_type[0]='\0';
      /*  dpolicy[0]='\0';
          dply_begin[0]='\0';
          dply_end[0]='\0';        */
          n_ncode[0]='\0';
          iclaim[0]='\0';
          dclaim[0]='\0';
          pay=0;
          fedr=0;
          iedr=0;


     return M_CM_OK;
     errexit:
        printf("build:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
        EWRITE(userid, SQLCODE, sqlca.sqlerrm);
        exit(1);

}
/*-------------------------------------------------------------------*/

long car715_print_2()
{
      char tmp_buf[30];
     $WHENEVER SQLERROR GOTO errexit;

     rgu_put_body_string(2, " ", 1);
     rgu_put_body_string(2, " ", 1);
     rgu_put_body_string(2, " ", 1);
     rgu_put_body_string(2, " ", 1);
     rgu_put_body_string(2, " ", 1);
     rgu_put_body_string(2, " ", 1);
     rgu_put_body_string(2, " ", 1);
     rgu_put_body_string(2, " ", 1);
     rgu_put_body_string(2, " ", 1);

     rfmtdouble(mcar_price, "------&.#", tmp_buf);
     rgu_put_body_string(2, " ", 2);

     rgu_put_body_string(2, " ", 2);
     rgu_put_body_string(2, " ", 1);

     rfmtdouble(ori_mply_amt, "-----------&", tmp_buf);
     rgu_put_body_string(2, " ", 2);

     rfmtdouble(mply_amt, "-----------&", tmp_buf);
     rgu_put_body_string(2, " ", 2);

     rfmtdouble(mdeduct, "-----------&", tmp_buf);
     rgu_put_body_string(2, " ", 2);

     rgu_put_body_string(2, " ", 1);
     rgu_put_body_string(2, " ", 1);
     if(dendorse_isnull==-1)
     { rgu_put_body_string(2, " ", 1); }
     else
     { rgu_put_body_string(2, " ", 1); }
     rgu_put_body_string(2, " ", 1);
     rgu_put_body_string(2, " ", 1);
     rgu_put_body_string(2, " ", 1);

     rgu_put_body_string(2, trim(iclaim), 1);
     rgu_put_body_string(2, trim(dclaim), 1);

     rfmtdouble(pay, "-----------&", tmp_buf);
     rgu_put_body_string(2, trim(tmp_buf), 2);
     rgu_put_body(2);
     max_cnt++;

      /*  iofficer[0]='\0';
          iofficer_nname[0]='\0';
          icorps[0]='\0';
          nbranch[0]='\0';         */
          ileader_nname[0]='\0';
          edr_iendorse[0]='\0';
      /*  itag[0]='\0';
          iengine[0]='\0';         */
          dgree[0]='\0';
          iins_type[0]='\0';
      /*  mcar_price=0;            */
      /*  ori_mply_amt=0;          */
          mply_amt=0;
          mdeduct=0;
          fedr_class[0]='\0';
          nfedr_class[0]='\0';
          niedr_type[0]='\0';
          iedr_type[0]='\0';
      /*  dpolicy[0]='\0';
          dply_begin[0]='\0';
          dply_end[0]='\0';        */
          n_ncode[0]='\0';
          iclaim[0]='\0';
          dclaim[0]='\0';
          pay=0;
          fedr=0;
          iedr=0;


     return M_CM_OK;
     errexit:
        printf("build:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
        EWRITE(userid, SQLCODE, sqlca.sqlerrm);
        exit(1);

}

long car715_ply_ins()
{

  $WHENEVER SQLERROR GOTO errexit;
   printf("INTO ply_ins ipolicy[%s]\n",ipolicy);
       sprintf_s(stmt, sizeof stmt,"select iins_type,mdeduct,(minjured_cover+mdeath_cover+mdamage_cover) mply_amt  "
                      "from %s:ply_ins_type  "
                      "where  ipolicy = ?  "
                      "  and  iins_type = ?   "
                      "  and  mdamage_cover !=0 ",full_dbname);

       $PREPARE a_idG FROM $stmt;
       $DECLARE curG CURSOR for a_idG;
       $OPEN curG USING $ipolicy,$iins_type;
       while(1)
       {

          $FETCH curG INTO $iins_type,$mdeduct,$mply_amt;

          if(SQLCODE == SQLNOTFOUND)  break;


       }


     return M_CM_OK;
     errexit:
        printf("build:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
        EWRITE(userid, SQLCODE, sqlca.sqlerrm);
        exit(1);

}
/*******************************************************************************************/
long car715_edr()
{

  $WHENEVER SQLERROR GOTO errexit;
   printf("INTO edr\n");

             sprintf_s(stmt, sizeof stmt,"select a.iendorse,a.fedr_class,b.iedr_type                      "
                           " from %s:edr_relation a,%s:edr_ins_type b                      "
                           "where  ipolicy = ?                                             "
                           "  and  a.iendorse = b.iendorse                                 "
                           "  and  b.iins_type = ? ", full_dbname,full_dbname);

            $PREPARE a_idI FROM $stmt;
            $DECLARE curI CURSOR for a_idI;
            $OPEN curI USING $ipolicy,$iins_type;
            while(1)
            {

               $FETCH curI INTO $edr_iendorse,$fedr_class,$iedr_type;
               if(SQLCODE == SQLNOTFOUND)  break;

            }



     return M_CM_OK;
     errexit:
        printf("build:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
        EWRITE(userid, SQLCODE, sqlca.sqlerrm);
        exit(1);

}
/*******************************************************************************************/
long car715_ori_ins()
{

  $WHENEVER SQLERROR GOTO errexit;

   printf("INTO ori ipolicy[%s],iins_type[%s]\n",ipolicy,iins_type);

      sprintf_s(stmt, sizeof stmt,"select mdamage_cover ori_mply_amt   "
                    " from %s:ori_ins_type  "
                    "where  ipolicy = ?  "
                    "  and  iins_type = ?   "
                    "  and  mdamage_cover !=0 ",full_dbname);
  printf("stmt[%s]\n",stmt);

      $PREPARE a_idK FROM $stmt;
      $DECLARE curK CURSOR for a_idK;
      $OPEN curK USING $ipolicy,$iins_type;
      ori_mply_amt = 0;
      while(1)
      {
          $FETCH curK INTO $ori_mply_amt;

         if (SQLCODE == SQLNOTFOUND){
             break;
         }

      }


     return M_CM_OK;
     errexit:
        printf("build:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
        EWRITE(userid, SQLCODE, sqlca.sqlerrm);
        exit(1);

}
