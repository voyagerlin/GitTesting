/*******************************************************************************
*                                                                              *
*   FILE         : ca344m01s.ec                                                *                                                                             *
*   DESCRIPTION  : �O��/�O�I�ҦC�L�d�ߧ@�~                                     *
*   date written : 2014/03/12                                                  *
*   date modify  : yyyy/mm/dd                                                  *
*   author       : Larry Liao                                                  *
*                                                                              *
*******************************************************************************/
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "carmsgs.h"
#include "othmsgs.h"
#include "glscom.h"
#include "ISvar.h"
$include decimal.h;
$include sqlca;
#include "safeclib.h"

DBinfo  *list;
int i, count_db;
FILE   *fp;
char errbuf[512];
$char getfile[300];
FILE   *fp;
static int   recLen=1024;
static char  *bp;
char delimiter;
int offset;
int  tmp_len;

/*----------------------------------------------------------------------------*/
long car344(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	long rtncode;

	long car344_single_query();
  long car344_multiple_query();
  long car334_update_exec();
  
  char option;
  cm_buf_init(command);
  cm_buf_get("%c",&option);
  switch(option)
  {
   
   case 'Q':
           rtncode=car344_single_query(reply);
	         break;
   case 'M':
           rtncode=car344_multiple_query(reply);
	         break;
   case 'E': /* ��ƾ��W�� */
           rtncode=car344_insert_batch(reply);

           cm_buf_init(ReplyBuf);
           cm_buf_put("%l %s" , rtncode, errbuf);

           tmp_len = cm_buf_len(ReplyBuf);
           if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
               return apiRC;
           else
               return api_OKComplete;
           break;
   /* case 'D':   ��ƾ��R��
           rtncode=car344_delete_batch(reply);

           cm_buf_init(ReplyBuf);
           cm_buf_put("%l %s" , rtncode, errbuf);

           tmp_len = cm_buf_len(ReplyBuf);
           if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
               return apiRC;
           else
               return api_OKComplete;
           break;
   */	    
   case 'U':
           rtncode=car334_update_exec(reply,command,com_len);
           break;
   default :
           if(exitsub(reply,M_CM_WRONG_OPTION) == True)
             return M_CM_WRONG_OPTION;
           return apiRC;
  }
   return(rtncode);
}
/*----------------------------------------------------------------------------*/
long car344_single_query(reply)
serverReply reply;
{  
	 $char DBName[DBNAME];
   $char ipolicy[21],Full_DBName[20];
   $char sIpolicy[21],sIrelative_ply[21],sIcard[21],sItag[CA_TAG_NUM];
   $char sDpolicy[11],sDply_begin[11],sDply_end[11];
   $char sIleader[11],sFout_print[2],sFcard_class[2];
   $char sDentry[8],sIquota[7],sIcomp_in[3],sDout_trans[11];
   $char sFeply[2],sAemail_eply[51];
   $char fmail_type[2],npost_recipient[121],apost_zip[CA_ZIP],apost_address[91];
   $char ori_fmail_type[2],ori_npost_recipient[121],ori_apost_zip[CA_ZIP],ori_apost_address[91];
   $varchar sNassured[121];
   $char    sStmt[1024],sStmt2[1024];
   $char close_yn[2];

   cm_buf_get("%s %s", DBName, ipolicy);
   
   printf("--single_query:ipolicy[%s]--\n",ipolicy);
   
   $WHENEVER SQLERROR GOTO errexit;
   if (db_select(DBName) == False) 
   {
      if(exitsub(reply,M_CM_DB_NOTOPEN) == True)  return M_CM_DB_NOTOPEN;
      else  return apiRC;
   }
   
   strcpy(Full_DBName,get_car_full_db(ipolicy));
   sprintf_s(sStmt, sizeof sStmt,"SELECT a.ipolicy, a.irelative_ply, a.dpolicy,      "
                 "       CASE WHEN a.fcard_class = '1' THEN a.icard  "
                 "       ELSE (SELECT icard FROM %s:ply_relation "
                 "              WHERE ipolicy = a.irelative_ply) END ,"
                 "       b.nassured, b.itag, a.dply_begin, a.dply_end,   "
                 "       a.ileader, "
                 "       CASE WHEN a.fout_print = '1' AND a.fmail_type != '0' "
                 "            THEN 'Y' ELSE ' ' END, "
                 "       a.fcard_class, a.iquota, a.icomp_in ,"
                 "       year(a.dentry)-1911||to_char(a.dentry,'%%m%%d'), "
                 "	     nvl(date(dout_trans),' '), "
                 "       CASE WHEN a.fcard_class = '2' THEN a.feply  "
                 "       ELSE (SELECT feply FROM %s:ply_relation "
                 "              WHERE ipolicy = a.irelative_ply) END , "
                 "       a.aemail_eply , "
                 "       a.fmail_type,b.npost_recipient,b.apost_zip,b.apost_address,"
                 "       case when (a.dply_close = '' OR a.dply_close IS NULL) then 'N' else 'Y' end"
                 "  FROM %s:ply_relation a, %s:policy b "
                 " WHERE a.ipolicy = b.ipolicy "
                 "   AND a.ipolicy = '%s' ",Full_DBName,Full_DBName,Full_DBName,Full_DBName,ipolicy);
   $PREPARE policy_cur FROM $sStmt;             
   $EXECUTE policy_cur INTO $sIpolicy, $sIrelative_ply, $sDpolicy, $sIcard, 
                            $sNassured, $sItag, $sDply_begin, $sDply_end,
                            $sIleader, $sFout_print, $sFcard_class, $sIquota,
                            $sIcomp_in,$sDentry,$sDout_trans,$sFeply,$sAemail_eply,
                            $fmail_type,$npost_recipient,$apost_zip,$apost_address,$close_yn;        
   if (SQLCODE == SQLNOTFOUND)
   {
       if(exitsub(reply,M_CM_NOT_FOUND) == True) return M_CM_NOT_FOUND;
       else return apiRC;
   }
   
   if(close_yn[0] == 'Y')
   {
	sprintf_s(sStmt2, sizeof sStmt2,"SELECT a.fmail_type,b.npost_recipient,b.apost_zip,b.apost_address"
                      "  FROM %s:ori_ply_relation a, %s:original_ply b "
                      " WHERE a.ipolicy = b.ipolicy "
                      "   AND a.ipolicy = '%s' ",Full_DBName,Full_DBName,ipolicy);
        $PREPARE policy_close FROM $sStmt2;
        $EXECUTE policy_close INTO $ori_fmail_type,$ori_npost_recipient,$ori_apost_zip,$ori_apost_address;
            
	if (SQLCODE == SQLNOTFOUND)
  	{
       		if(exitsub(reply,M_CM_NOT_FOUND) == True) return M_CM_NOT_FOUND;
      		else return apiRC;
  	}
   }
   
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   if (strncmp(sFcard_class,"1",1) == 0){
     cm_buf_put("%s %s %s", sIpolicy, sIcard, sIrelative_ply);
   }
   else {
   	 cm_buf_put("%s %s %s", sIrelative_ply, sIcard, sIpolicy);
   }
     cm_buf_put("%s %s %s", sDpolicy, sNassured, sItag);
     cm_buf_put("%s %s %s %s", sDply_begin, sDply_end, sIleader, sFout_print);
     cm_buf_put("%s %s %s %s",sDentry,sIquota,sIcomp_in,sDout_trans);
     cm_buf_put("%s %s",sFeply,sAemail_eply);
   if(close_yn[0] == 'Y'){
     cm_buf_put("%s %s %s %s %s",ori_fmail_type,ori_npost_recipient,ori_apost_zip,ori_apost_address,close_yn);
   }
   else{
     cm_buf_put("%s %s %s %s %s",fmail_type,npost_recipient,apost_zip,apost_address,close_yn);
   }
   
   tmp_len = cm_buf_len(ReplyBuf);
   if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)  return apiRC;
   else return api_OKComplete;

errexit:
printf("<car344_single_query> sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    if(exitsub(reply,SQLCODE) == True) return SQLCODE;
    else return apiRC;
}
/*----------------------------------------------------------------------------*/
long car344_multiple_query(reply)
serverReply reply;
{
	   $char DBName[DBNAME];
     $char     itag[CA_TAG_NUM], sItag[CA_TAG_NUM];
     $char     iassured[13], sIassured[13];
     $varchar  sNassured[41];
     $char     sIpolicy[21], sIrelative_ply[21], sDpolicy[11];      
     $char     stmt[1024];
     
     char tmpbuf[4000];
     int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
     int total_count=0;
     
     cm_buf_get("%s %s %s", DBName, iassured, itag);
     
     printf("--130 iassured[%s], itag[%s]--\n", iassured, itag);
     
     $WHENEVER SQLERROR GOTO errexit;
     
     if (db_select(DBName) == False)
     {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True) return M_CM_DB_NOTOPEN;
        else return apiRC;
     }
     
     if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
       if (EWRITE(reply, M_CM_NOT_DBLIST) == TRUE)
          return M_CM_NOT_DBLIST;
     }     
    
   for(i=0;i<count_db;i++) 
   {  	 
     sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy, a.irelative_ply, b.nassured, "
                  "       b.itag, a.dpolicy  "
                  "  FROM %s:ply_relation a, %s:policy b "
                  " WHERE a.ipolicy = b.ipolicy "
                  "   AND b.iassured matches '%s' "
                  "   AND b.itag matches '%s' "
                  "   AND a.dentry >= today - 14 "
                  " ORDER BY b.itag,a.dpolicy ",list[i].dbname,list[i].dbname,iassured,itag);
                     
     $PREPARE ply_data FROM $stmt;
     $DECLARE ply_cur CURSOR FOR ply_data;
     $OPEN    ply_cur;
     printf("stmt[%s]\n",stmt);
     
    for(;;) 
    {      	
      $FETCH ply_cur INTO $sIpolicy, $sIrelative_ply, $sNassured, $sItag, $sDpolicy;
    	if (SQLCODE == SQLNOTFOUND) break;
 
    	cm_buf_init(tmpbuf); 
    	if ( count == 0 )
     	{
      	  cm_buf_res_msg();             /* reserve for MsgCode and count */
      	  cm_buf_res_count();          
     	}
    	  cm_buf_put("%s %s %s", sIpolicy, sIrelative_ply, sNassured);
    	  cm_buf_put("%s %s", sItag, sDpolicy);
        tmp_len = cm_buf_len(tmpbuf);
    	if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
      {
      	  memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      	  repbuf_len += tmp_len;
      	  count++;
      }
   	  else                               /* more than 4K, send to client side */ 
     	{ 
      	  cm_buf_init(ReplyBuf);
      	  cm_buf_put_msg(M_CM_OK);
      	  cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
      {
	        $CLOSE ply_cur;
          return apiRC;
      }
      else               /* clear ReplyBuf and count to start all over again */
      {
          replycnt++;
          if (replycnt == 10)   /* more than 30K, client cannot display,error */
          {
	  	     cm_buf_init(ReplyBuf);
           cm_buf_put("%l",M_CM_OUT_SPACE);
           tmp_len = cm_buf_len(ReplyBuf);
           if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
              return apiRC;
              return M_CM_OUT_SPACE; 
          }
	    ReplyBuf[0] = '\0';
	    count = 0;
	    cm_buf_init(ReplyBuf);
      cm_buf_res_msg();           /* reserve for MsgCode and count */
      cm_buf_res_count();    
      cm_buf_put("%s %s %s", sIpolicy, sIrelative_ply, sNassured);
    	cm_buf_put("%s %s", sItag, sDpolicy);
	    repbuf_len = cm_buf_len(ReplyBuf);
	    count++;
      }
     } 
   } /* for loop */
   $CLOSE ply_cur;
   $FREE  ply_cur;
  }     
  
  if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
  else            /* break out, not any row is found */
  {
   if(exitsub(reply,M_CM_NOT_FOUND) == True) 
    return M_CM_NOT_FOUND;
   else  
    return apiRC;
  } 

errexit:
printf("<car344_multiple_query> sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
  if(exitsub(reply,SQLCODE) == True)  return SQLCODE;
  else return apiRC;
}

/* ��ƾ��W�� */
long car344_insert_batch(reply)
serverReply reply;
{

  $char DBName[5], userid[11] ,sFullName[21], stmt[2048], stmt1[2048], stmt_buf[300];
  char  sApHome[30], filename[101],logname[101], cmd_str[2048];
  $char itmp_policy[21],ipolicy[21],iofficer[11],itag[CA_TAG_NUM],dpolicy[11],fmail_type[2],iroute[21];
  $int  rc, cnt, rc1 ,irate,is_upd_fail=0;
  int   stmt_len;
  int i, j, is_add_fail=0, api_f;
  long MsgCode;
  $char type[2];
  int tmp_len;
  char *malloc();

  $int count2;

   rc = getApHome(sApHome);
   if (rc<0) {
      strcpy( errbuf,"read Config file error!!-->getApHome\n");
      return rc;
   }

   sprintf_s(filename, sizeof filename,"%s/dat/car/car344.txt", sApHome);
   sprintf_s(logname, sizeof logname,"%s/rptftp/car344_log.txt",sApHome);

  cm_buf_get("%s %s %s ",DBName, userid, type);

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
     sprintf_s(errbuf, sizeof errbuf,"��Ʈw�L�k�}��[%s]\n", DBName);
     return M_CM_DB_NOTOPEN;
  }

   /********************************************************************************************/

    sprintf_s(getfile, sizeof getfile,"%s/dat/car/car344.txt",sApHome);

    if ((fp=fopen(getfile,"rt"))==NULL)
    {
        return SQLCODE;
    }

    if ((bp=malloc(recLen))==NULL)
    {
        printf("System malloc failed  !\n");
        return SQLCODE;
    }

    /* ���j�Ÿ� */
    delimiter = '\t';

    $CREATE TEMP table tmp_car344
    (
     ipolicy	char(20)
    )with no log;

    while(fgets(bp,recLen,fp))
    {
       if (feof(fp)) break;
       offset = 0;

            /* ��ƨ��o���Ǥ��i�ܰ� */
            GetData(ipolicy,	sizeof(ipolicy),	delimiter);

printf("ipolicy[%s]\n",ipolicy);

            $insert into tmp_car344(ipolicy)
             values ($ipolicy);
     }

     fclose(fp);
	 free(bp);

$BEGIN WORK;

   sprintf_s(stmt1, sizeof stmt1,"select ipolicy from tmp_car344 ");

printf("stmt1=[%s]\n",stmt1);

   $PREPARE CUR_CAID_1 FROM $stmt1;
   $DECLARE IDcur_1 CURSOR FOR CUR_CAID_1;
   $OPEN IDcur_1;
   for(;;)
   {

   	$FETCH IDcur_1 INTO $ipolicy;

   	if (SQLCODE != 0) break;

   	if(strcmp(type,"2") == 0)
   	{
   		sprintf_s(stmt_buf, sizeof stmt_buf,"UPDATE ca_out_draw "
   		                  " SET fout_type = '1',iupdate = ?,dupdate = today "
   		                  " where ipolicy = ? " ); 
    		$PREPARE u_id FROM $stmt_buf;
    		$EXECUTE u_id using $userid,$ipolicy;

    		if(SQLCODE != 0)
     		{
      		is_upd_fail = 1;
     		}
     		if( is_upd_fail ) goto errexit;
     		
     		if(sqlca.sqlerrd[2] == 0)
     		{
     			return M_CM_NOT_FOUND;
     		}
   	}
   	else
   	{
   		strcpy(sFullName, get_car_full_db(ipolicy));

	   	sprintf_s(stmt1, sizeof stmt1,
	  		"select b.itmp_policy,a.itag,b.dpolicy,b.fmail_type,b.iofficer,a.iroute "
	        "          from %s:policy a ,%s:ply_relation b "
	        "         where a.ipolicy = b.ipolicy "
	        "           and a.ipolicy = '%s' ",sFullName,sFullName,ipolicy);

		$PREPARE outply FROM $stmt1;
		$EXECUTE outply INTO $itmp_policy,$itag,$dpolicy,$fmail_type,$iofficer,$iroute;

		sprintf_s(stmt1, sizeof stmt1,"INSERT INTO ca_out_draw "
        " (ipolicy,itmp_policy,itag,dpolicy,fmail_type,fout_type,iofficer,iroute,iupdate,dupdate) "
	 	" VALUES (?,?,?,?,?,'0',?,?,?,today)");
	 	
   		$PREPARE a_id FROM $stmt1;
   		$EXECUTE a_id USING $ipolicy,$itmp_policy,$itag,$dpolicy,$fmail_type,$iofficer,$iroute,$userid;

   		if(SQLCODE != 0)
         	{
         		return M_CM_ADD_FAIL;
         	}
   	}
   }
   $CLOSE IDcur_1;
   $FREE IDcur_1;
   
   $DROP TABLE tmp_car344;

   /********************************************************************************************/

   sprintf_s(errbuf, sizeof errbuf,"���槹��");
   $COMMIT WORK;
   return M_CM_OK;

errexit:
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     $DROP TABLE tmp_car344;
     sprintf_s(errbuf, sizeof errbuf,"SQLCODE[%d], sqlca.sqlerrm[%s]\n", SQLCODE, sqlca.sqlerrm);
     return SQLCODE;
}

long car334_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	 long MsgCode;
	 $char DBName[5],ipolicy[21],ipolicy_r[21],Full_DBName[20],sStmt[2048],sStmt2[1024],up_adr[1024],up_adr2[1024],ori_up_adr[1024],ori_up_adr2[1024],stmp[512];
	 $char cur_sIpolicy[21],cur_sIrelative_ply[21],cur_sIcard[21],cur_sItag[CA_TAG_NUM];
	 $char cur_sDpolicy[11],cur_sDply_begin[11],cur_sDply_end[11];
	 $char cur_sIleader[11],cur_sFout_print[2],cur_sFcard_class[2];
	 $char cur_sDentry[8],cur_sIquota[7],cur_sIcomp_in[3],cur_sDout_trans[11];
	 $char cur_sFeply[2],cur_sAemail_eply[51];
	 $char cur_fmail_type[2],cur_npost_recipient[121],cur_apost_zip[CA_ZIP],cur_apost_address[91];
	 $char cur_ori_fmail_type[2],cur_ori_npost_recipient[121],cur_ori_apost_zip[CA_ZIP],cur_ori_apost_address[91];
	 $char cur_close_yn[2];
	 $varchar cur_sNassured[121];
	  
	 $char u_fmail_type[2],u_npost_recipient[121],u_apost_zip[CA_ZIP],u_apost_address[91];
	 
	 $char q_sIpolicy[21],q_sIrelative_ply[21],q_sIcard[21],q_sItag[CA_TAG_NUM];
	 $char q_sDpolicy[11],q_sDply_begin[11],q_sDply_end[11];
	 $char q_sIleader[11],q_sFout_print[2],q_sFcard_class[2];
	 $char q_sDentry[8],q_sIquota[7],q_sIcomp_in[3],q_sDout_trans[11];
	 $char q_sFeply[2],q_sAemail_eply[51];
	 $char q_fmail_type[2],q_npost_recipient[121],q_apost_zip[CA_ZIP],q_apost_address[91];
	 $varchar q_sNassured[121];
	 $char q_close_yn[2];

	 char option,*pos,*raw_ptr,*malloc(),cur_buf[5000],*comm;
	 int tmp_len,raw_len; 
	 long dummy;
	 DBinfo *list;
	 int i, j, is_del_fail=0, is_upd_fail=0;
	 $char stmt_buf[300];
	
	 comm = (char *) command;
	 cm_buf_init(command);
	 cm_buf_get("%c %s %s %s",&option,DBName,ipolicy,ipolicy_r);
	
	 $WHENEVER SQLERROR GOTO errexit;
	
	 if (db_select(DBName) == False)
	 return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
	
	/*  if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
	     return exitsub(reply,M_CM_NOT_DBLIST) ? M_CM_NOT_DBLIST : apiRC;  */
	
	 memcpy(&raw_len,&comm[com_len],sizeof(int));
	 pos = &comm[com_len+sizeof(int)];
	 raw_ptr = malloc(raw_len);
	 if (raw_ptr != (char*)0)
	  memcpy(raw_ptr,pos,raw_len);
	 else
	  { 
	   return exitsub(reply,M_CM_NOT_MALLOC) ? M_CM_NOT_MALLOC : apiRC;
	  }
	
	 cm_buf_init(raw_ptr);        /* get index key from old record */
	 cm_buf_get("%l %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",      
	             &dummy,q_sIpolicy, q_sIcard, q_sIrelative_ply,
	                    q_sDpolicy, q_sNassured, q_sItag,
	                    q_sDply_begin, q_sDply_end, q_sIleader, q_sFout_print,
	                    q_sDentry,q_sIquota,q_sIcomp_in,q_sDout_trans,
	                    q_sFeply,q_sAemail_eply,q_fmail_type,q_npost_recipient,q_apost_zip,q_apost_address,q_close_yn);

	 $BEGIN WORK;
         strcpy(Full_DBName,get_car_full_db(ipolicy));
	   sprintf_s(sStmt, sizeof sStmt,"SELECT a.ipolicy, a.irelative_ply, a.dpolicy,      "
	                 "       CASE WHEN a.fcard_class = '1' THEN a.icard  "
	                 "       ELSE (SELECT icard FROM %s:ply_relation "
	                 "              WHERE ipolicy = a.irelative_ply) END ,"
	                 "       b.nassured, b.itag, a.dply_begin, a.dply_end,   "
	                 "       a.ileader, "
	                 "       CASE WHEN a.fout_print = '1' AND a.fmail_type != '0' "
	                 "            THEN 'Y' ELSE ' ' END, "
	                 "       a.fcard_class, a.iquota, a.icomp_in ,"
	                 "       year(a.dentry)-1911||to_char(a.dentry,'%%m%%d'), "
	                 "	     nvl(date(dout_trans),' '), "
	                 "       CASE WHEN a.fcard_class = '2' THEN a.feply  "
	                 "       ELSE (SELECT feply FROM %s:ply_relation "
	                 "              WHERE ipolicy = a.irelative_ply) END , "
	                 "       a.aemail_eply , "
	                 "       a.fmail_type,b.npost_recipient,b.apost_zip,b.apost_address,"
	                 "       case when (a.dply_close = '' OR a.dply_close IS NULL) then 'N' else 'Y' end"
	                 "  FROM %s:ply_relation a, %s:policy b "
	                 " WHERE a.ipolicy = b.ipolicy "
	                 "   AND a.ipolicy = '%s' ",Full_DBName,Full_DBName,Full_DBName,Full_DBName,ipolicy);
	   $PREPARE policy_cur FROM $sStmt;  
	   printf("sStmt[%s]\n",sStmt);           
	   $EXECUTE policy_cur INTO $cur_sIpolicy, $cur_sIrelative_ply, $cur_sDpolicy, $cur_sIcard, 
	                            $cur_sNassured, $cur_sItag, $cur_sDply_begin, $cur_sDply_end,
	                            $cur_sIleader, $cur_sFout_print, $cur_sFcard_class, $cur_sIquota,
	                            $cur_sIcomp_in,$cur_sDentry,$cur_sDout_trans,$cur_sFeply,$cur_sAemail_eply,
	                            $cur_fmail_type,$cur_npost_recipient,$cur_apost_zip,$cur_apost_address,$cur_close_yn; 
	                            
	 if (SQLCODE == SQLNOTFOUND)
	 {
	   MsgCode = M_CM_NOT_FOUND;
	   $WHENEVER SQLERROR CONTINUE;
	   $ROLLBACK WORK;
	   if(SQLCODE != 0) MsgCode = SQLCODE;
	   return exitsub(reply,MsgCode) ? MsgCode : apiRC;
	 }
	 
	if(cur_close_yn[0] == 'Y')
	{
		sprintf_s(sStmt2, sizeof sStmt2,"SELECT a.fmail_type,b.npost_recipient,b.apost_zip,b.apost_address"
		              "   FROM %s:ori_ply_relation a, %s:original_ply b "
		              "  WHERE a.ipolicy = b.ipolicy "
		              "    AND a.ipolicy = '%s' ",Full_DBName,Full_DBName,ipolicy);
		$PREPARE policy_close_cur FROM $sStmt2;
		$EXECUTE policy_close_cur INTO $cur_ori_fmail_type,$cur_ori_npost_recipient,$cur_ori_apost_zip,$cur_ori_apost_address;
	    
		if (SQLCODE == SQLNOTFOUND)
		{
			if(exitsub(reply,M_CM_NOT_FOUND) == True) return M_CM_NOT_FOUND;
			else return apiRC;
		}
	}
	 
	 cm_buf_init(cur_buf);
	 if (strncmp(cur_sFcard_class,"1",1) == 0){
	 	if(cur_close_yn[0] == 'Y'){
	             cm_buf_put("%l %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s", 
		                 dummy,cur_sIpolicy, cur_sIcard, cur_sIrelative_ply,
		                    cur_sDpolicy, cur_sNassured, cur_sItag,
		                    cur_sDply_begin, cur_sDply_end, cur_sIleader, cur_sFout_print,
		                    cur_sDentry,cur_sIquota,cur_sIcomp_in,cur_sDout_trans,
		                    cur_sFeply,cur_sAemail_eply,cur_ori_fmail_type,cur_ori_npost_recipient,cur_ori_apost_zip,cur_ori_apost_address,cur_close_yn);
	        }
	        else{
	             cm_buf_put("%l %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s", 
		                 dummy,cur_sIpolicy, cur_sIcard, cur_sIrelative_ply,
		                    cur_sDpolicy, cur_sNassured, cur_sItag,
		                    cur_sDply_begin, cur_sDply_end, cur_sIleader, cur_sFout_print,
		                    cur_sDentry,cur_sIquota,cur_sIcomp_in,cur_sDout_trans,
		                    cur_sFeply,cur_sAemail_eply,cur_fmail_type,cur_npost_recipient,cur_apost_zip,cur_apost_address,cur_close_yn);
	        }
         }
         else {
         	if(cur_close_yn[0] == 'Y'){
	   	     cm_buf_put("%l %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",      
		                 dummy,cur_sIrelative_ply, cur_sIcard, cur_sIpolicy,
		                    cur_sDpolicy, cur_sNassured, cur_sItag,
		                    cur_sDply_begin, cur_sDply_end, cur_sIleader, cur_sFout_print,
		                    cur_sDentry,cur_sIquota,cur_sIcomp_in,cur_sDout_trans,
		                    cur_sFeply,cur_sAemail_eply,cur_ori_fmail_type,cur_ori_npost_recipient,cur_ori_apost_zip,cur_ori_apost_address,cur_close_yn);
		}
		else{
	   	     cm_buf_put("%l %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",      
		                 dummy,cur_sIrelative_ply, cur_sIcard, cur_sIpolicy,
		                    cur_sDpolicy, cur_sNassured, cur_sItag,
		                    cur_sDply_begin, cur_sDply_end, cur_sIleader, cur_sFout_print,
		                    cur_sDentry,cur_sIquota,cur_sIcomp_in,cur_sDout_trans,
		                    cur_sFeply,cur_sAemail_eply,cur_fmail_type,cur_npost_recipient,cur_apost_zip,cur_apost_address,cur_close_yn);		
	        }
         }
	
	 write(1,raw_ptr,raw_len);
	 write(1,"\n",1);
	 write(1,cur_buf,raw_len);
	 write(1,"\n",1);

	 printf("raw_ptr[%s]\n",raw_ptr);
	 printf("cur_buf[%s]\n",cur_buf);
	 
	 if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
	 {
	   MsgCode = M_CM_NOT_EQUAL;
	   $WHENEVER SQLERROR CONTINUE;
	   $ROLLBACK WORK;
	   if(SQLCODE != 0) MsgCode = SQLCODE;
	   return exitsub(reply,MsgCode) ? MsgCode : apiRC;
	 }
	 
	 free(raw_ptr);
	 
	 if ( option == 'U' )
	 {
		cm_buf_init(command);
		cm_buf_get("%c %s",&option,DBName);
		cm_buf_get("%s %s %s %s %s %s",ipolicy,ipolicy_r,u_fmail_type,u_npost_recipient,u_apost_zip,u_apost_address);
		$WHENEVER SQLERROR go to errexit;
		strcpy(ipolicy,trim(ipolicy));
		strcpy(ipolicy_r,trim(ipolicy_r));
		up_adr[0] = '\0';
		up_adr2[0] = '\0';
	
		if(ipolicy_r[0] == '\0') sprintf_s(stmp, sizeof stmp," where ipolicy = '%s'",ipolicy);
		else sprintf_s(stmp, sizeof stmp," where ipolicy in ('%s','%s')",ipolicy,ipolicy_r);
			
		sprintf_s(up_adr, sizeof up_adr,"update %s:ply_relation "
		               "   set fmail_type = '%s' %s",Full_DBName,u_fmail_type,stmp);
		sprintf_s(up_adr2, sizeof up_adr2,"update %s:policy "
		                "   set npost_recipient = '%s',apost_zip = '%s',apost_address = '%s' "
		                " %s ",Full_DBName,u_npost_recipient,u_apost_zip,u_apost_address,stmp);
		sprintf_s(ori_up_adr, sizeof ori_up_adr,"update %s:ori_ply_relation "
		                   "   set fmail_type = '%s' %s",Full_DBName,u_fmail_type,stmp);               
		sprintf_s(ori_up_adr2, sizeof ori_up_adr2,"update %s:original_ply "
		                    "   set npost_recipient = '%s',apost_zip = '%s',apost_address = '%s' "
		                    " %s ",Full_DBName,u_npost_recipient,u_apost_zip,u_apost_address,stmp);

	 	$PREPARE upd1 FROM $up_adr;
	 	printf("up_adr[%s]\n",up_adr);
	 	$EXECUTE upd1;
		if(SQLCODE != 0) is_upd_fail = 1;
		
		$PREPARE upd2 FROM $up_adr2;
		printf("up_adr2[%s]\n",up_adr2);
		$EXECUTE upd2;
		if(SQLCODE != 0) is_upd_fail = 1;
		
		if(q_close_yn[0] == 'Y')
		{
			$PREPARE ori_upd1 FROM $ori_up_adr;
		 	printf("ori_up_adr[%s]\n",ori_up_adr);
		 	$EXECUTE ori_upd1;
			if(SQLCODE != 0) is_upd_fail = 1;
			
			$PREPARE ori_upd2 FROM $ori_up_adr2;
			printf("ori_up_adr2[%s]\n",ori_up_adr2);
			$EXECUTE ori_upd2;
			if(SQLCODE != 0) is_upd_fail = 1;		
		}
		
		if( is_upd_fail ) goto errexit;
		
		cm_buf_init(ReplyBuf);
		cm_buf_put("%l",M_CM_OK);
		tmp_len = cm_buf_len(ReplyBuf);
		if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
		{
			$WHENEVER SQLERROR CONTINUE;
			$ROLLBACK WORK;
			return apiRC;
		}
		$WHENEVER SQLERROR GOTO errexit;
		$COMMIT WORK;
		return api_OKComplete;
	 }
	 else
	 {
		MsgCode = M_CM_WRONG_OPTION;
		$WHENEVER SQLERROR CONTINUE;
		$ROLLBACK WORK;
		if(SQLCODE != 0) MsgCode = SQLCODE;
		if(exitsub(reply,MsgCode) == True)
			return MsgCode;
		else
			return apiRC;
	 }		

errexit:
  MsgCode = SQLCODE;
  cm_show_sql_err("ca344_update_exec", stmt_buf);
  $WHENEVER SQLERROR CONTINUE;
  $ROLLBACK WORK;
  if(SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True)
   return MsgCode;
  else
   return apiRC;	
}

long GetData(data, maxlen, delimiter)
char *data, delimiter;
int maxlen;
{
int fori, pre_offset, cnt=0;

    data[0]='\0';
    pre_offset = offset;

    for (fori=pre_offset; bp[fori]!=0x00&&bp[fori]!=0x0d&&bp[fori]!=0x0a&&bp[fori]!=delimiter; fori++)
    {
        offset++;
        if (cnt < maxlen-1)
        {
            data[cnt]=bp[fori];
            cnt++;
        }
    }

    offset++; /* ���ܤU�@�� */
    if (cnt==0) data[cnt++]=0x20; /* �L��Ƶ��ť� */
    data[cnt]=0x00;
    printf("pre_offset[%d]offset[%d]len[%d]data[%s]\n", pre_offset, offset, cnt, data);
}
/*------------------------------THE END---------------------------------------*/