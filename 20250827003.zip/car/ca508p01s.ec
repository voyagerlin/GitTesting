/*------------------------------------------------------------------
 * Program    : ca508p01s.ec
 *              ���I�鵲�@�~
 * Date       : 11/13/1996
 *-------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <decimal.h>

#include "is_def.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "glsstru.h"
#include "carmsgs.h"
#include "safeclib.h"
#include "ca_data.h"

#include "commsgs.h"
#include "cmnmsgs.h"
#include "comdata.h"
#include "rinmsgs.h"
#include "cm_ply_info.h"
#include "cm_plyins_info.h"

$include sqlca;
$include datetime;
$include sqltypes;
$include "ply_ins_cover.h";
$include "ply_ins_assured.h";
$include "var_length.h";

#define TRUE                    1
#define FALSE                   0
#define FOUND                   sqlca.sqlcode!=SQLNOTFOUND
#define NOT_FOUND               sqlca.sqlcode==SQLNOTFOUND
#define EQUAL(s1,s2)            !strcmp(s1,s2)
#define NOT_EQUAL(s1,s2)        strcmp(s1,s2)

#define IS2A(s) (strncmp(s,"2A",2)==0)
#define IS2B(s) (strncmp(s,"2B",2)==0)
#define IS2C(s) (strncmp(s,"2C",2)==0)
#define IS4A(s) (strncmp(s,"4A",2)==0)
#define IS8A(s) (strncmp(s,"8A",2)==0)
#define IS9A(s) (strncmp(s,"9A",2)==0)
#define IS9B(s) (strncmp(s,"9B",2)==0)

/**********************************************/
$char  err_buf[200];
$char  DBname[DBNAME], userid[11], outputf[21], creator[11];
char   dclosing_type[2], ch_dwritten[16], ch_next_dwritten[16];
$char  inf_dclose[15];
$date  Today, dwritten, next_dwritten;
$char  ivoucher[16];
$char  tmp_Ciest[21],tmp_Cipay[2];
$date  plydate;
$double tmp_mpure_prem;
$char  ipolicy_main[21];
$char  iinstall[11];
$int   install_num;

DBinfo *list;

int    flag_no_ply=0;

/*---------------------------------------*/
$char ptype_C[2]="C";
$char ptype_Z[2]="Z";
$char ptype_V[2]="V";
$char ptype_M[2]="M";
$char ptype_EB[3]="EB";
$char ptype_TV[3]="TV";
$char ptype_ES[3]="ES";
$char ptype_CXP[4]="CXP";

$char Cmaxp[POLICY_NUM_1];
$char Vmaxp[POLICY_NUM_1];
$char Mmaxp[POLICY_NUM_1];
$char Zmaxp[POLICY_NUM_1];
$char EBmaxp[POLICY_NUM_1];
$char CXPmaxp[POLICY_NUM_1];
/*--------------------------------------------*/

struct PLY_LIST {
    char ipolicy[POLICY_NUM_1];
    char irelative_ply[POLICY_NUM_1];
    char ilast_ply[POLICY_NUM_1];
    char assuredf[2];
    char assuredi[CUSTOMER_ID];
    char assuredi_ext[CUSTOMER_EXT_ID];
    char assuredn[121];
    char assureda[91];
    char paymenta[91];
    char tagnum[CA_TAG_NUM];
    char body[CA_BODY_NUM];
    char engine[CA_ENGINE_NUM];
    char treaty[2];
    char icard[CARD_NUM];
    char fcard_class[2];
    char iofficer[11];
    char ibroker[BROKER];
    char icorps[CORP_ID];
    char icomp_in[BRANCH_ID];
    char ibranch_in[BRANCH_ID];
    char iquota[CA_SA_QUOTA];
    char ileader[LEADER];
    char iresource[2];
    char ibig_comp[2];
    char icar_type[3];
    char icar_flag[2];
    char iarea[3];
    char icashier[EMPLOYEE_ID];
    char ibig_sales[EMPLOYEE_ID];
    char ireg_no[21];  /* 1080408005-SC1-��ã��-�j���һ{�ҷs�W�q����Ƥεn���Ҹ� */
    char ibig_office[10];
    char facf[2];
    char transno[21];
    int  seqno;
    long dpolicy;
    long ply_begin;
    long ply_end;
    char dtedr_bgn[17]; /* 1061108001-SC4-�s��*/
    char dtedr_end[17];
    long qply_period;
    long ply_mprem;
    long ply_magent;
    long ply_mcommi;
    long ply_mdisc;
    int  ibatch_no;
    char itmp_policy[21];
    char itmp_policy_ori[21];
    char ipay_way[2];
    char nequipment[31];
    char ibenef[11];
    char zip[CA_ZIP];/* 1090525004-SC1-�]�y��-�s���l���ϸ�3+3   ZIP_CODE 5+1->CA_ZIP 6+1*/
    char ibroker_top[BROKER];
    char iapplicant[IASSURED];
    char napplicant[101];
    char introducer[21];
    char iroute_prop[3];
    char iroute_accept[21];
    char iroute[21];
    char icomm_obj[11];
    int  qprovision;
    char icard_main[21];
    char iscan_no[26];/* 1060817004- C1 �q�lñ�p  1101018008-SC1-�d����-�q�lñ�ݱ��y�s������X�W��25�X��*/
    char isurvey_num[121];
    char ibound_num[121];
    char ixxcard[21];
    char nassured_deputy[51];
    char tassured_day[21];
    char tassured_night[21];
    char tassured_mobile[21];
    char aassured_email[51];
    char napplicant_deputy[51];
    char apayment_zip[CA_ZIP];/* 1090525004-SC1-�]�y��-�s���l���ϸ�3+3   ZIP_CODE 5+1->CA_ZIP 6+1*/
    char tapplicant_day[21];
    char napplicant_relation[41];
    char nuser[19];
    char qpro_month[3];
    char ipro_year[5];
    char ibrand[9];
    double qcylinder;
    double qpt;
    double mequipment;
    char feply[2];
    char feterms[2];/*1100419003-���I�O�����QR Code�q�l��-�ȥ��O��u�q�l���ڡvfeterms*/
    char aemail_eply[51];/* 1060817004- C1 �q�lñ�p  ��*/
    char tmobile_eply[21]; /*1080417001-SC1-���ά�-�s�W�q�l�O��H²�T�覡�o�e */
    char foccup[2];
    char applicant_foccup[2];
    char dbirth[11];
    char dbirth_appl[11];
    char tmobile_appl[21];
    char dissue[11]; 
    char aemail_appl[51]; /*1100913004-SC1-���I�q�lñ�p�s�W�n�O�Hemail���*/
    char ftrans_third[2];
    struct PLY_LIST *next;
};

struct PLY_LIST *PlyFirst, *PlyCurr, *PlyLast;
/*--------------------------------------------*/
long pre_chk_comp();
long Car508_1();
long rin_car_ply_prem();
long ao_gl_voucher();
extern void trim_cspace();
FILE   *sfp;
char    v_sMsg[1521], sErrMsg[5000];

/**********************************************************************/
main(argc, argv)
int argc;
char **argv;
{
    long    rc;
    $int    iCount;
    $char   sIpolicy[21], sIofficer[11], sIbroker[11], sIquota[11];

    batchinit();
    strcpy(DBname,           isNULLstr(argv[1]));
    strcpy(userid,           isNULLstr(argv[2]));
    strcpy(dclosing_type,    isNULLstr(argv[3]));  /*�鵲���A*/
    strcpy(ch_dwritten,      isNULLstr(argv[4]));  /*�鵲���*/
    strcpy(ch_next_dwritten, isNULLstr(argv[5]));  /*���鵲���*/
    strcpy(creator,          isNULLstr(argv[6]));  /*�鵲�H��*/
    strcpy(outputf,          isNULLstr(argv[7]));

    dwritten       = cm_ymd_cdate(ch_dwritten);
    next_dwritten  = cm_ymd_cdate(ch_next_dwritten);

    strcpy(inf_dclose, cm_to_infdate(ch_dwritten));

    printf("#### CAR5081:dclosing_type[%s],ch_dwritten[%s],ch_next_dwritten[%s]\n",
                         dclosing_type    ,ch_dwritten    ,ch_next_dwritten);

    rtoday(&Today);     /* get today's datetime */

    sfp =  (FILE *)STARTLOG();

    if (db_select(DBname) == False)
    {
        EWRITE(userid,M_CM_DB_NOTOPEN,"M_CM_DB_NOTOPEN");
        return M_CM_DB_NOTOPEN;
    }

    memset(err_buf,0,sizeof(err_buf));

    /* 1040416007_C1 �S�w�q��ñ��W�h�վ�
       �^���Ҧ��u�Lñ���v���u�j���I�v��ơA�ŦX����̡A�^��ñ���
    */
    rc=pre_chk_comp();
    if (rc!=M_CM_OK)
    {
    	printf("=============================> pre_chk_comp() error, �������_�鵲�@�~\n");
        /* �����_�鵲 */
    }
    /*printf("-- trace 1\n ");    exit(0);    printf("-- trace 2\n ");*/
    rc=Car508_1();
    if (rc != M_CM_OK)
    {
        EWRITE(userid,rc,err_buf);
        return rc;
    }
    else
    {
        printf("=============================> RETURN SUCCESS\n");
        WRITELOG( sfp, "ñ��鵲����,�W���Y���C�X [�j���I�Lñ���B�z], [�~�Z���N������],[�g��N���w����],�бN�T�����ѵ����I��T�H��");
        ENDLOG(sfp);
        /* EWRITE(userid,M_CM_OK,"ñ��鵲���\!"); */
    }
    
    /*** �u�d�@�Ӥ뤺����� ***/
    $DELETE FROM ca_close_log WHERE dcreate <= today - 31;

    FreePlyList(PlyFirst,PlyCurr);  /* free all allocated memory */

    return SUCCESS;
}

/*****************************************************************/
long Car508_1()
{
    $int    i=0, j=0, k=0, yr_cnt=0;
    $date   dpolicy, dbegin, dend, dlast_closing;
    $int    tmp_qply_begin;
    $long   tmp_qply_period;
    $char   curyear[3], lastyear[3];
    $char   ply1[POLICY_NUM_1], ply2[POLICY_NUM_2],tmp_abnormal[POLICY_NUM_1];
    $char   ply3[POLICY_NUM_1], ply4[POLICY_NUM_2], iestimate[21];
    $char   facf[2];
    char    previous_ply1[POLICY_NUM_1];
    $char   icard[CARD_NUM], ftype[2], isub[BRANCH_ID];
    $char   assuredn[121],assureda[91],assureda_a[91];
    $char   paymenta[91];
    $char   fcard_class[2],iofficer[EMPLOYEE_ID], ibig_sales[EMPLOYEE_ID];
    $char   ireg_no[21];/*1080408005-SC1-��ã��-�j���һ{�ҷs�W�q����Ƥεn���Ҹ�*/
    $char   ibroker[BROKER],iins_type[INSURANCE_TYPE], ibroker_top[BROKER];
    $char   ibig_office[10],iroute[21];
    $char   assuredi[CUSTOMER_ID], assuredi_ext[CUSTOMER_EXT_ID];
    $char   iquota[CA_SA_QUOTA];
    $char   icashier[EMPLOYEE_ID];
    $char   fcommit[3], fbig_rcv;
    $double mcompense;
    $long   mpremium,mcommit,mcommit1,magent1,mdeal1,mdeal;
    $char   datestr[10],yy1[3],mm1[3],dd1[3], yymm[5];
    $char   stmt_buf[400];
    $char   ipolicy[POLICY_NUM_1],tagnum[CA_TAG_NUM],body[CA_BODY_NUM],engine[CA_ENGINE_NUM],treaty[2];
    $char   irelative_ply[POLICY_NUM_1];
    $char   irelative_ply_1[POLICY_NUM_1];
    $char   transno[21],transno2[21], transno2_tmp[21], transno1[21];
    $int    seqno;
    $int    ibatch_no;
    $char   ibig_comp[2], icar_type[3];
    $char   icar_flag[2];
    long    rtncode;
    $long   minjured_cover,mdeath_cover,mdamage_cover,mdeduct,mins_premium;
    $char   iarea[3],tmp_area[5],tmp_policy[21],pay_way[2];
    $long   mdiscount, magent;
    $long   tmp_mprem, mprem;
    $double ptax, ptax_1;
    $char   tmp_ptax[12], rpt_type[2];
    dec_t   dec_ptax;
    $long   mprem1, mprem2, mprem33;
    $long   mdiscount1,mdiscount2,mdiscount33;
    $long   prem1, prem2;
    $long   mdmg_prem,mdmg_agent,mdmg_commi,mlia_prem,mlia_agent,mlia_commi;
    $long   mdmg_discount=0, mlia_discount=0;
    $char   cIinsurant[11];
    $char   cIins_scope[2], cIcareer[2];
    $long   lMins_amt;
    $long   lMins_premium;
    $long   qday;
    $long   mexpense;
    $long   lDaily_pay;
    $char   tmp_iproduct[3];
    $char   iproduct[13], provision[21];
    $char   kclsfyitem[5];
    $char   kreserve[6];
    $char   sToday[11],fIFRS[2],isubcode[3],icohort[5]; /* IFRS17 */
    $char   fapply[2],iportfolio[11],igroup[21]; /* IFRS17 */
    char    yy[4], mm[3], dd[3];

    $char   iresource[2];
    $char   icorps[11];
    $char   nequipment[31];
    $char   itag_number[CA_TAG_NUM];
    $char   ibenef[11], izip[CA_ZIP];/* 1090525004-SC1-�]�y��-�s���l���ϸ�3+3   ZIP_CODE 5+1->CA_ZIP 6+1*/
    $char   assuredf[2], tmp_assuredi[11];
    $char   ilast_ply[POLICY_NUM_1], ientry[11];
    $char   icomm_obj[11];          /* �I����H(�q���ĤG���q) */
    $int    qprovision;
    $struct Rec508 {
       char yr[3];
    };
    $struct Rec508 Year[5];

    $long qpolicy41,qpolicy32,qpolicy31;
    $long mpolicy41,mpolicy32,mpolicy31;
    $long magent41,magent32,magent31;
    $long mdeal41,mcommit32,mcommit31;
    $long qpolicy_dis31,qpolicy_dis32;
    $long mpolicy_dis31,mpolicy_dis32;

    $char stmt[400];
    $char taipei_db[40];
    $char dbname_tp[25];

    $char tmp_ibatch_no[3];
    $char insure_kind[11];
    $char fins_grp_rtmp[2];
    $char remark[200];

    /* ply_ins_cover */
    $char   icover_type[ICOVER_TYPE];             /* �O�B���� */
    $long   mcover;                               /* �O�B */
    $long   mcover_prem;                          /* ñ��O�O */
    $long   mdiscount_cover;                      /* ���� */
    $long   mprem_cover;                          /* �W���O�O */
    $double mpure_prem;                           /* �«O�O */

    /* ply_ins_assured */
    $char   sProvision[7];			  /* ����  1081225006-SC1-���ά�-�X�R���[���ڥN�X */
    $char   iassured  [IASSURED];                 /* �Q�O�I�Hid */
    $char   nassured  [NASSURED];                 /* �Q�O�I�H�m�W */
    $char   dbirth    [DATE];                     /* �X�ͤ�� */
    $char   nbenef    [NBENEF];                   /* ���q�H�m�W */
    $char   rel_benef [REL_BENEF];                /* ���q�H�P�Q�O�I�H���Y */
    $char   tbenef    [21];                       /* ���q�H�p���q�� (1110310005_SC1) */
    $char   abenef_zip[CA_ZIP];                   /* ���q�H�l���ϸ� */
    $char   abenef    [91];                       /* ���q�H�a�} */
    /* �n�O�H */
    $char   iapplicant[IASSURED];
    $char   napplicant[101];
    /* ��z�覡�O��]�ݭn,�z�L�O�Nfcommit=1,iedr_return=2,
                          �Ȥ�˿�fcommit=N,iedr_return=1 */
    $char   iedr_return[2], icard_main[21],frate[4];

    $char iscan_no[26];/* 1060817004- C1 �q�lñ�p  1101018008-SC1-�d����-�q�lñ�ݱ��y�s������X�W��25�X��*/
    $char ileader[11];
    $char isurvey_num[121];
    $char ibound_num[121];
    $char ixxcard[21];
    $char nassured_deputy[51];
    $char tassured_day[21];
    $char tassured_night[21];
    $char tassured_mobile[21];
    $char aassured_email[51];
    $char napplicant_deputy[51];
    $char apayment_zip[CA_ZIP];/* 1090525004-SC1-�]�y��-�s���l���ϸ�3+3   ZIP_CODE 5+1->CA_ZIP 6+1*/
    $char tapplicant_day[21];
    $char napplicant_relation[41];
    $char introducer[21];
    $char nuser[19];
    $char qpro_month[3];
    $char ibrand[9];
    $char ipro_year[5];
    $double qcylinder;
    $double qpt;
    $double mequipment;
    $char feply[2];
    $char feterms[2]; /*1100419003-���I�O�����QR Code�q�l��-�ȥ��O��u�q�l���ڡvfeterms*/
    $char iroute_accept[21];
    $char aemail_eply[51];/* 1060817004- C1 �q�lñ�p  ��*/
    $char tmobile_eply[21]; /*1080417001-SC1-���ά�-�s�W�q�l�O��H²�T�覡�o�e */
    $char aemail_appl[51];/*1100913004-SC1-���I�q�lñ�p�s�W�n�O�Hemail���*/
    $char ftrans_third[2];  /*1111003006_SC1_�q�lñ�p���x�s�W����[�~����Ʀ@��]�ﶵ���O*/
    /*------------------------------------------------------------*/
    $char dtbegin[17];  /* 1061108001 -SC4-�s��*/
    $char dtend[17];
    $char sIaccount_branch[3],tmp_ibranch_in[BRANCH_ID];/* 1070322011-SC1-�Q���줽�Ǥɮ欰�x�_�����q*/
    
    /* 1060817004_SC4_�s�W�q�lñ�p�����{��-�W�[���  */
    $char foccup[2],applicant_foccup[2];
    $char dbirth_esign[11],dbirth_appl[11];
    $char tmobile_appl[21],dissue[11];
    
    $WHENEVER SQLERROR GOTO optP_err;
    $SET LOCK MODE TO WAIT;

    /* get current chinese year */
    strcpy(curyear,cm_sysd_cyear_100(cm_get_sysd()));
    sprintf_s(lastyear,sizeof lastyear,"%d",atoi(curyear)-1);
    lastyear[2]='\0';
    
    /* �T�{IFRS17�O�_�ҥ� (1110303007_SC5) */
    strcpy(sToday,cm_edate_str(Today));
    rtncode = cm_get_IFRS_DATE(sToday,fIFRS);
    if (rtncode != M_CM_OK)
    {
    	if (rtncode<0) goto optP_err;
    	else goto optP_err1;
    }

    /* get Taipei dbname */
    rtncode = getHeadBranch(taipei_db);
    if (rtncode < 0)
    {
        return M_CM_READ_CONFIG_ERR;
    }
    strcpy(dbname_tp,get_full_dbname(taipei_db));

    plydate = dwritten;
    /**** STEP P.1--(1) *****************************************/
    printf("*********** into P.1--(1) CheckSerialPolicy()\n");

    $BEGIN WORK;
    $LOCK TABLE ply_relation IN SHARE MODE;

    $DECLARE cur_ply CURSOR FOR
      SELECT DISTINCT(ipolicy[4,5])
        FROM ply_relation
       WHERE dpolicy = $plydate
         AND dply_close IS NULL;

    $OPEN cur_ply;
    for (j=0;;j++)
    {

        $FETCH cur_ply INTO $Year[j].yr;
        if( SQLCODE == SQLNOTFOUND) break;
    }
    $CLOSE cur_ply;
    if (j == 0)
    {
        flag_no_ply==1;
        goto ply_no_record;
    }

    yr_cnt = j--;

    PlyFirst = PlyCurr = PlyLast = NULL;     /* clear list pointer first */

    for (k=0; k<yr_cnt; k++)
    {
        rtncode=CheckSerialPolicy1(ptype_C, Year[k].yr, &PlyFirst, &PlyCurr,
                                    &PlyLast, Cmaxp);

        if (rtncode != SUCCESS)
        {

            $WHENEVER SQLERROR CONTINUE;     /* reset error handling */
            $ROLLBACK WORK;
            return rtncode;
        }

        rtncode=CheckSerialPolicy1(ptype_Z, Year[k].yr, &PlyFirst, &PlyCurr,
                                    &PlyLast, Zmaxp);

        if (rtncode != SUCCESS)
        {
            $WHENEVER SQLERROR CONTINUE;     /* reset error handling */
            $ROLLBACK WORK;
            return rtncode;
        }

        rtncode=CheckSerialPolicy1(ptype_M, Year[k].yr, &PlyFirst, &PlyCurr,
                                    &PlyLast, Mmaxp);

        if (rtncode != SUCCESS)
        {
            $WHENEVER SQLERROR CONTINUE;     /* reset error handling */
            $ROLLBACK WORK;
            return rtncode;
        }
        rtncode=CheckSerialPolicy1(ptype_V, Year[k].yr, &PlyFirst, &PlyCurr,
                                    &PlyLast, Vmaxp);

        if (rtncode != SUCCESS)
        {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            return rtncode;
        }
         
        rtncode=CheckSerialPolicy1(ptype_CXP, Year[k].yr, &PlyFirst, &PlyCurr,
                                    &PlyLast, CXPmaxp);
        if (rtncode != SUCCESS)
        {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            return rtncode;
        }
        printf(" ---- ptype_EB ----\n");
        rtncode=CheckSerialPolicy1(ptype_EB, Year[k].yr, &PlyFirst, &PlyCurr,
                                    &PlyLast, EBmaxp);
        if (rtncode != SUCCESS)
        {
            $WHENEVER SQLERROR CONTINUE;     /* reset error handling */
            $ROLLBACK WORK;
            return rtncode;
        }
        /*1050105002_C1 �T���~���ը�����X�O�I*/
        printf(" ---- ptype_TV ----\n");
        rtncode=CheckSerialPolicy1(ptype_TV, Year[k].yr, &PlyFirst, &PlyCurr,
                                    &PlyLast, EBmaxp);
        if (rtncode != SUCCESS)
        {
            $WHENEVER SQLERROR CONTINUE;     /* reset error handling */
            $ROLLBACK WORK;
            return rtncode;
        }         
        /*1120927002_C01_�R�q�ΰӫ~�}�o*/
        printf(" ---- ptype_ES ----\n");
        rtncode=CheckSerialPolicy1(ptype_ES, Year[k].yr, &PlyFirst, &PlyCurr,
                                    &PlyLast, EBmaxp);
        if (rtncode != SUCCESS)
        {
            $WHENEVER SQLERROR CONTINUE;     /* reset error handling */
            $ROLLBACK WORK;
            return rtncode;
        }
    }
    printf("julia kkk[%d]\n",k);
    $WHENEVER SQLERROR GOTO optP_err;

    /**** STEP P.1--(3) *****************************************/
    printf("*********** into P.1--(3)\n");

    /**** STEP P.1--(4) *****************************************/
    printf("*********** into P.1--(4) InsertPlyPolicy()\n");
    rtncode=InsertPlyPolicy(PlyFirst,PlyCurr);
    if (rtncode != SUCCESS)
    {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        return rtncode;
    }

    $WHENEVER SQLERROR GOTO optP_err;    /* resume error handling */

    /**** STEP P.1--(5) *****************************************/
    /************************************/
    /************************************/
    /*   ao_plyedr_prem                 */
    /************************************/
    /************************************/
    printf("*********** into P.1--(5) insert ao_plyedr_prem\n");
    memset(err_buf,0,sizeof(err_buf));
    previous_ply1[0]='\0';
    PlyCurr=PlyFirst;
    sprintf_s(stmt,sizeof stmt," INSERT INTO reject_policy (ipolicy,fins_grp,remark)  VALUES (?,?,?) ");
    $PREPARE reject_pid FROM $stmt;
    while (PlyCurr)
    {
        strcpy(ipolicy,         PlyCurr->ipolicy);
        strcpy(irelative_ply,   PlyCurr->irelative_ply);
        strcpy(irelative_ply_1, PlyCurr->irelative_ply);
        strcpy(iofficer,        PlyCurr->iofficer);
        strcpy(ibig_office,     PlyCurr->ibig_office);
        strcpy(ibig_sales,      PlyCurr->ibig_sales);
	strcpy(ireg_no,         PlyCurr->ireg_no);   /*1080408005-SC1-��ã��-�j���һ{�ҷs�W�q����Ƥεn���Ҹ�*/
        strcpy(iroute,          PlyCurr->iroute);
        strcpy(ibroker,         PlyCurr->ibroker);
        strcpy(ibig_comp,       PlyCurr->ibig_comp);
        strcpy(icar_type,       PlyCurr->icar_type);
        strcpy(assuredn,        PlyCurr->assuredn);
        strcpy(assureda_a,      PlyCurr->paymenta);
        strcpy(assureda,        PlyCurr->assureda);
        strcpy(assuredi,        PlyCurr->assuredi);
        strcpy(assuredi_ext,    PlyCurr->assuredi_ext);
        strcpy(iquota,          PlyCurr->iquota);
        strcpy(fcard_class,     PlyCurr->fcard_class);
        strcpy(iarea,           PlyCurr->iarea);
        strcpy(tmp_policy,      PlyCurr->itmp_policy);
        strcpy(pay_way,         PlyCurr->ipay_way);
        strcpy(transno,         PlyCurr->transno);
        strcpy(transno1,        PlyCurr->transno);
        strcpy(iresource,       PlyCurr->iresource);
        strcpy(icorps,          PlyCurr->icorps);
        strcpy(nequipment,      PlyCurr->nequipment);
        strcpy(itag_number,     PlyCurr->tagnum);
        strcpy(ibenef,          PlyCurr->ibenef);
        strcpy(izip,            PlyCurr->zip);
        strcpy(ibroker_top,     PlyCurr->ibroker_top);
        strcpy(assuredf,        PlyCurr->assuredf);
        strcpy(iapplicant,      PlyCurr->iapplicant);
        strcpy(napplicant,      PlyCurr->napplicant);
        strcpy(ilast_ply,       PlyCurr->ilast_ply);
        strcpy(icomm_obj,       PlyCurr->icomm_obj);
        strcpy(tmp_ibranch_in,  PlyCurr->ibranch_in); /*1070322011-SC1-�Q���줽�Ǥɮ欰�x�_�����q*/

	strcpy(icard_main,      PlyCurr->icard_main);	/* A�����p�d�� */
	
        printf("-495---------icard_main=[%s]PlyCurr->icard_main=[%s]\n ",icard_main,PlyCurr->icard_main);

        seqno     = PlyCurr->seqno;
        ibatch_no = PlyCurr->ibatch_no;
        dbegin    = PlyCurr->ply_begin;
        dend      = PlyCurr->ply_end;
        strncpy(ply1, ipolicy, CAR_POLICY_LEN);
        ply1[CAR_POLICY_LEN]='\0';
        strncpy(ply2, ipolicy+CAR_POLICY_LEN, CAR_TARGET_LEN);
        ply2[CAR_TARGET_LEN]='\0';

        if (ply2[0]=='\0' || ply2[0]==' ') strcpy(ply2," ");

        /* ���N�I�j�O��H���Ӹ�Ƽg�J */
        if (*fcard_class == '2')
            strcpy(irelative_ply, PlyCurr->irelative_ply);
        else
            strcpy(irelative_ply, PlyCurr->ipolicy);

        strcpy(icard,PlyCurr->icard);

        /*-----------*/
        strncpy(isub, DBname, 2); isub[2]='\0';

        /*-----------*/
        if (assureda_a[0]==' ' || assureda_a[0]=='\0')
        {
            strcpy(assureda_a,assureda);
            assureda_a[50]='\0';
        }

        /*-----------*/
        mprem=mdiscount=0;
        mcompense=0.00;

        strcpy(iinstall," ");
        strcpy(ipolicy_main," ");
        printf("-531---------icard_main=[%s]PlyCurr->icard_main=[%s]\n ",icard_main,PlyCurr->icard_main);
        strcpy(ipolicy_main,icard_main);	/* A�����p�d�� */
        printf("-533---ipolicy_main=[%s]------icard_main=[%s]PlyCurr->icard_main=[%s]\n ",ipolicy_main,icard_main,PlyCurr->icard_main);

        install_num = 0;

        /* 920312 �w��Z03555A�ӫO���M�ץ�A�g�Jreject_policy */
        strcpy(remark,"Z03555A�ӫO���M�ץ�");
        if (*fcard_class=='1') /* �j���I */
        {
            $SELECT mlia_prem,mcompensation, ientry
               INTO $mprem,$mcompense, $ientry
               FROM ply_relation
              WHERE ipolicy = $ipolicy;

              strcpy(iinstall," ");
              strcpy(ipolicy_main," ");
              install_num = 0;

             /* car_9511301 */
             $SELECT mdamage_cover
                INTO $mdamage_cover
                FROM ply_ins_type
               WHERE ipolicy = $ipolicy
                 AND iins_type = '21';

             if( NOT_FOUND)
                 mdamage_cover = 0;
        }
        else if (*fcard_class=='2') /* ���N�I */
        {
            /* �����O�O = ñ��O�O ( ���ݦ����� ) */
            $SELECT mlia_prem+mdmg_prem,
                    mdmg_discount+mlia_discount,iinstall, ientry
               INTO $mprem,$mdiscount,$iinstall, $ientry
               FROM ply_relation
              WHERE ipolicy = $ipolicy
                AND dpolicy = $plydate;

             if (iinstall[0] != ' ' && iinstall[0] != '\0')
             {
                $SELECT install_num
                   INTO $install_num
                   FROM installment
                  WHERE iinstall = $iinstall;
                     if (SQLCODE == SQLNOTFOUND)
                     {
                        strcpy(iinstall," ");
                        strcpy(ipolicy_main," ");
                        printf("-----580  ipolicy_main=[%s]------------ \n",ipolicy_main);
                        install_num = 0;
                     }
                     else
                     {
                        strcpy(ipolicy_main,ipolicy);
                        printf("------586 ipolicy_main=[%s]------------ \n",ipolicy_main);
                     }
             }

             /* car_9511301 */
             $SELECT mdamage_cover
                INTO $mdamage_cover
                FROM ply_ins_type
               WHERE ipolicy = $ipolicy
                 AND iins_type = '31';

             if( NOT_FOUND)
                 mdamage_cover = 0;

        }
        printf("------601 ipolicy_main=[%s]------------ \n",ipolicy_main);
        /** �OCAR�[�M�סB�E�M�a�x�M2�M�סBTwo�O�O�M�� */
        if( (equip_cmp(nequipment,"49") == TRUE ||
             equip_cmp(nequipment,"34") == TRUE ||
             equip_cmp(nequipment,"63") == TRUE ||
             equip_cmp(nequipment,"64") == TRUE  ) && (iofficer[0] == 'A') && (*fcard_class=='2') )
        {
            strcpy(ipolicy_main,icard);
            printf("------609 ipolicy_main=[%s]------------ \n",ipolicy_main);
        }

        /** �OCAR�[�M�ױN�d���g�J **/
        if( (equip_cmp(nequipment,"49") == TRUE) && (iofficer[0] == 'A') && (*fcard_class=='2') )
        {
            strcpy(ipolicy_main,icard);
            printf("------616 ipolicy_main=[%s]------------ \n",ipolicy_main);
        }

        /*-----------*/
        strcpy(tmp_area,DBname);

        strcat(tmp_area,iarea);
        tmp_area[4]='\0';

        strcpy(icashier, PlyCurr->icashier);

        /*-----------*/
        /* �t�X�q���ĤG���q,�g�P�p�f�Q�׫�M�wmark */
        /* if (ibroker[0]==' ' || ibroker[0]=='\0')
        {
            fcommit[0]='N';
            fcommit[1]='\0';
            strcpy(iedr_return,"1");
        }
        else
        { */
            if (isalpha(ibig_comp[0]))
            {
                fcommit[0]='1'; fcommit[1]='\0';
                strcpy(iedr_return,"2");
            }
            else
            {
                fcommit[0]='N'; fcommit[1]='\0';
                strcpy(iedr_return,"1");
            }
        /* } */

        /*-----------*/
        memset(err_buf,0,sizeof(err_buf));
        strcpy(err_buf,"insert ao_plyedr_prem:");
        strcat(err_buf,ipolicy);

        if (ibatch_no == 0)
           strcpy(tmp_ibatch_no," ");
        else
           strcpy(tmp_ibatch_no,itoa(ibatch_no));

        strcpy( transno2, "");

        /* car9603121 �g���N����RD,RDA�h�N�Q�O�I�HID�g�Jao_plyedr_prem.transno */
        /* car9702221 �g���N����RE(�W�ȫO�N),�h�Q�O�I�HID�g�Jao_plyedr_prem.transno */
        /* �t�X�q���ĤG���q, ��H[�D�q���N��(iroute)]��[�D�q���N��(iroue)+�q���ۭq�~�ȥN��(iroute_prop)]�P�_
           RD�BRDA (�X�w) -- I006
           RE (�W��) -- I011            modify by sylvia 100.06.22 */
        /* if( strncmp( ibroker, "RD", 2) == 0 || strncmp( ibroker, "RDA", 3) == 0 ||
            strncmp( ibroker, "RE", 2) == 0) */
        if( strncmp( iroute, "I006", 4) == 0 || strncmp( iroute, "I011", 4) == 0 )
        {
            if( transno[0] != '9')
            {
                /* car9803042 �g���N��RD,RDA,RE�N�Q�O�I�HID��Jao_plyedr_prem.transno,������Jao_plyedr_prem.transno2 */
                strcpy( transno, assuredi);
        	strcpy( transno2, itag_number);
            }
        }

        /* car9803042 �g���N��RI01�N�Q�O�I�HID��Jao_plyedr_prem.transno,������Jao_plyedr_prem.transno2 */
        /* car9702221 �g���N����RE(�W�ȫO�N),�h�Q�O�I�HID�g�Jao_plyedr_prem.transno */
        /* �t�X�q���ĤG���q, ��H[�D�q���N��(iroute)]��[�D�q���N��(iroue)+�q���ۭq�~�ȥN��(iroute_prop)]�P�_
           RI01 (�x���ӻ�) -- I053   modify by sylvia 100.06.22 */
        /* if (strncmp( ibroker, "RI01", 4) == 0) */
        if (strncmp( iroute, "I053", 4) == 0)
        {
            if( transno[0] != '9')  /* 0990722001 �ץ��x���Ȩ��I��O�q������X�P�bKEY�� */
            {
                strcpy( transno, assuredi);
                strcpy( transno2, itag_number);
            }
        }

        /* car9810051 �x���ȸg���N��RP*�N�Q�O�I�HID��Jao_plyedr_prem.transno2,
                      transno����, ���O��C�L������s��(8193*) */
        /* �t�X�q���ĤG���q, ��H[�D�q���N��(iroute)]��[�D�q���N��(iroue)+�q���ۭq�~�ȥN��(iroute_prop)]�P�_
           RP (�x����) -- I050    modify by sylvia 100.06.22  */
        /* if (strncmp( ibroker, "RP", 2) == 0) */
        /*  1080926007-SC1-���έ�-�ʫ��Ȧ��{�d�N���P�b�@�~ -�ʫ��Ȧ�~�Ȩ��I�P�bKEY�ȭץ����Q�O�I�HID */
        if ( (strncmp( iroute, "I050", 4) == 0) ||  (strncmp( iroute, "I054", 4) == 0))
        {
            strcpy( transno2, assuredi);  
        }

        /* ���ȾP�b�@�~ -- transno:�Q�O�I�HID, transno2:�n�O�HID add by sylvia 102.06.17(1020508002_C1) */
        if (strncmp( iroute, "I009", 4) == 0)
        {
            strcpy( transno, assuredi);		/* �Q�O�I�HID */
            strcpy( transno2, iapplicant);	/* �n�O�HID */
        }

        #if 0  /* �P�q�ڽT�{�A�ثe�L�ϥ� */
        /* b2b9606252 �x�sb2b��,����s����5�X�Ȧ�X+9�X(�����X�G�۵M�H�����ԧB�Ʀr9�X�B
                      �k�H���νs8�X+"0") �A�g�J�]���� */
        /* TS_BANK_ID �w�q�b ca_data.h */
        /* �t�X�q���ĤG���q, ��H[�D�q���N��(iroute)]��[�D�q���N��(iroue)+�q���ۭq�~�ȥN��(iroute_prop)]�P�_
           YZC* (�x�s) -- I812 + 05
           R* (�x�s) -- I812 + 06 */
        if( strncmp( iroute, "I812", 4) == 0 )
        {
            /* if ( iofficer[0] == 'Y') */
            if (strcmp(iroute_prop,"05") == 0)
            {
                if( assuredf[0] == '1' || assuredf[0] == '3' || assuredf[0] == '5') 	/* �۵M�H */
                {
                    strncpy( tmp_assuredi, &assuredi[1], 9);
                    tmp_assuredi[9] = '\0';
                    sprintf_s( transno2,sizeof transno2, "%s%s", TS_BANK_ID, tmp_assuredi);
                }
                else
                {
                    sprintf_s( transno2,sizeof transno2 ,"%s%s0", TS_BANK_ID, trim(assuredi)); 			/* �k�H */
                }
            }

            /* aoi9809181 �x�s�O�gcar�ߦw�]�g��N���GR61025F007�^�H���������R�PKey */
            if ( iofficer[0] == 'R')
            {
       	        strcpy( transno2, itag_number);
            }
        }
        #endif

        {
        /* car9811203 �K�Q�ө�ú�ڥ�A��ñ��ɫD��Barcode��ƥX��̡A�t�Φ۰ʦ^��X���T(�@��) */
        $long mprem_rel;
        $char ilast_ply_rel[21], ientry_rel[11];
        $long lMprem;

        if( transno1[0] != '9' && strlen(trim(transno2)) == 0)
        {
            mprem_rel = 0;
            if( strlen(trim(irelative_ply_1)) > 0)
            {
                $SELECT mlia_prem+mdmg_prem, ilast_ply, ientry
                   INTO $mprem_rel, $ilast_ply_rel, $ientry_rel
                   FROM ply_relation
                  WHERE ipolicy = $irelative_ply_1
                    AND dpolicy = $plydate;
                if( SQLCODE == SQLNOTFOUND)
                   mprem_rel = 0;
            }

            strcpy( transno2_tmp, "");
            lMprem = mprem_rel + mprem;     /* �鵲�O��P�����p�O��X�p�O�O */
            if( strlen(trim(ilast_ply)) > 0 ) /* �鵲�O�榳�e�O�渹�� */
            {
                /* �鵲�O�榳���s���A�e�O�渹�O�_�s�b�O�O(�t���p)�ۦP��BarCdoe����s�� */
                if( strlen(trim(irelative_ply_1)) > 0)
                    $SELECT MAX(transno)
                       INTO $transno2_tmp
                       FROM ca_transno_302
                      WHERE ipolicy = $ilast_ply
                        AND mprem = $lMprem;
                else /* �鵲�O��L���s���A�e�O�渹�O�_�s�b�O�O(���t���p)�ۦP��BarCdoe����s�� */
                    $SELECT MAX(transno)
                       INTO $transno2_tmp
                       FROM ca_transno_302
                      WHERE ipolicy = $ilast_ply
                        AND mprem = $mprem;

                /* �p�G�����BarCode����s���A�g�J�]��transno2�A�P�ɧ�sBarCdoe�� */
                if( strlen(trim(transno2_tmp)) > 0)
                {
                    strcpy( transno2, transno2_tmp);
                    $UPDATE ca_transno_302
                        SET dpolicy = $plydate,
                            inext_ply = $ipolicy,
                            iupdate = $ientry,
                            dupdate = $plydate
                      WHERE transno = $transno2;
                }
            }
            if ( strlen(trim(ilast_ply_rel)) > 0  ) /* �鵲�O�榳���p�e�O�渹�� */
            {
                /* �鵲�O�����p�e�O�渹�O�_�s�b�O�O�ۦP��BarCdoe����s�� */
                if( strlen(trim(irelative_ply_1)) > 0)
                    $SELECT MAX(transno)
                       INTO $transno2_tmp
                       FROM ca_transno_302
                      WHERE ipolicy = $ilast_ply_rel
                        AND mprem = $lMprem;
                else
                    $SELECT MAX(transno)
                       INTO $transno2_tmp
                       FROM ca_transno_302
                      WHERE ipolicy = $ilast_ply_rel
                        AND mprem = $mprem;

                /* �p�G�����BarCode����s���A�g�J�]��transno2�A�P�ɧ�sBarCdoe�� */
                if( strlen(trim(transno2_tmp)) > 0)
                {
       	            strcpy( transno2, transno2_tmp);
                    $UPDATE ca_transno_302
                        SET dpolicy = $plydate,
                            inext_ply = $irelative_ply_1,
                            iupdate = $ientry_rel,
                            dupdate = $plydate
                      WHERE transno = $transno2;
                }
            }
        }
        }

        /* ���I���j�v���,�ƻs�I����H�N����ao_plyedr_prem.ibroker */
        if (isalpha(ibig_comp[0]))
        {
            printf(" ���I���j�v���,�ƻs�I����H�N����ao_plyedr_prem.ibroker \n");
            strcpy(ibroker, icomm_obj);

        }
        /*1070322011-SC1-�Q���줽�Ǥɮ欰�x�_�����q*/
        $SELECT iaccount_branch INTO $sIaccount_branch
           FROM branch 
          WHERE ibranch = $tmp_ibranch_in;
        printf("ao_plyedr_prem\n�Q���줽�Ǥɮ欰�x�_�����q\nsIaccount_branch[%s]\n",sIaccount_branch);

        if (mprem != 0)
        {
            /* �g��]�Ⱥݪ�ibroker����ONULL  add by sylvia 100.11.04 */
            if (ibroker[0]==' ' || ibroker[0]=='\0' || strlen(ibroker) == 0 )
                  strcpy(ibroker, " ");
            printf("------835 ipolicy_main=[%s]------------ \n",ipolicy_main);
            $INSERT INTO  ao_plyedr_prem
                          (ipolicy1,ipolicy2,iendorse,icard,dplyend,ftype,
                           isub,nassured,ibroker,icashier,
                           mprem,mdiscount,icur,aassured,aassured_a,
                           dbegin,dend,fcommit,frcvpay,fpay_cond,
                           iofficer,insure_type,puredplyend,
                           mprem_nt,mcompensation_nt,ibatch_no,mdiscount_nt,
                           sys_source, irelative, iwebserno,
                           transno, seqno,iaccount_branch,
                           ifpce_id,ifpce_id_ext,iquota,ibank,ipolicy_main,install_num,
                           icorps,iresource,nequipment,itag, iroute, ibig_sales,idetent_bank,
                           izip,ibroker_top,transno2,iapplicant,napplicant,mcover,iedr_return,icomm_obj)
                   VALUES ($ply1,$ply2," ",$icard,$plydate,"P",
                           $isub,$assuredn,$ibroker,$icashier,
                           $mprem,$mdiscount,"NT",$assureda,$assureda_a,
                           $dbegin,$dend,$fcommit,"N",$pay_way,
                           $iofficer,"C",$plydate,
                           $mprem,0,$ibatch_no,$mdiscount,"CA1",
                           $irelative_ply,$tmp_policy,
                           $transno, $seqno,$sIaccount_branch,
                           $assuredi, $assuredi_ext,$iquota,$ibig_office,$ipolicy_main,$install_num,
                           $icorps,$iresource,$nequipment,$itag_number,$iroute,$ibig_sales,$ibenef,
                           $izip,$ibroker_top,$transno2,$iapplicant,$napplicant,$mdamage_cover,$iedr_return,$icomm_obj);

            strncpy(ply3, irelative_ply, CAR_POLICY_LEN);
            ply3[CAR_POLICY_LEN]='\0';

            strncpy(ply4, irelative_ply+CAR_POLICY_LEN, CAR_TARGET_LEN);
            ply4[CAR_TARGET_LEN]='\0';

            if (ply4[0]=='\0' || ply4[0]==' ') strcpy(ply4," ");

            /* �t�X�q���ĤG���q,��H�D�q���N���P�_  modify by sylvia 100.06.22 */
            /* if( strncmp( ibroker, "RD", 2) != 0 && strncmp( ibroker, "RDA", 3) != 0 &&
                 strncmp( ibroker, "RE", 2) != 0 && strncmp( ibroker, "RI01", 4) != 0) */
            if( strncmp( iroute, "I006", 4) != 0 &&
                strncmp( iroute, "I011", 4) != 0 && strncmp( iroute, "I053", 4) != 0)
            {
                 $UPDATE ao_plyedr_prem
                     SET transno = $transno,
                         seqno = '2'
                   WHERE ipolicy1 = $ply3
                     AND ipolicy2 = $ply4;
            }

            /* 103.06.09 ���O�X��G�鵲�g�J�O���b����(ao_plyedr_prem)�ɡA���P�ɦ^�gcm_pre_receive �鵲��*/
            $UPDATE cm_pre_receive
                SET dclose = $plydate
              WHERE ipolicy1 = $ply1
                AND ipolicy2 = $ply2
                AND dclose IS NULL;

        }

        PlyCurr=PlyCurr->next;
    }

    $WHENEVER SQLERROR GOTO optP_err;    /* resume error handling */

    /**** STEP P.1--(6) *****************************************/
    /************************************/
    /************************************/
    /*   ao_plyedr_detail               */
    /************************************/
    /************************************/
    printf("*********** into P.1--(6) insert ao_plyedr_detail\n");
    previous_ply1[0]='\0';
    PlyCurr=PlyFirst;
    while (PlyCurr)
    {
        strcpy(ipolicy     , PlyCurr->ipolicy);
        strcpy(fcard_class , PlyCurr->fcard_class);
        strcpy(icar_type   , PlyCurr->icar_type);
        tmp_qply_period    = PlyCurr->qply_period;

        ibatch_no          = PlyCurr->ibatch_no;

        strncpy(ply1, ipolicy, CAR_POLICY_LEN);
        ply1[CAR_POLICY_LEN]='\0';

        strncpy(ply2, ipolicy+CAR_POLICY_LEN, CAR_TARGET_LEN);
        ply2[CAR_TARGET_LEN]='\0';

        if (ply2[0]=='\0' || ply2[0]==' ') strcpy(ply2," ");

        mins_premium = 0;
        mdiscount    = 0;

        if (ibatch_no==0)
           strcpy(tmp_ibatch_no, " ");
        else
           strcpy(tmp_ibatch_no, itoa(ibatch_no));

        strcpy(icar_type, trim(icar_type));

        $DECLARE q_detail_1 CURSOR WITH HOLD FOR
          SELECT b.iins_type , b.mins_premium, a.mcompensation, b.mdiscount, b.provision ,b.drate_ym
            INTO $iins_type,   $mins_premium,  $mcompense,      $mdiscount, $provision , $frate
            FROM ply_relation a, ply_ins_type b
           WHERE a.ipolicy = $ipolicy
             AND a.ipolicy = b.ipolicy;
        $OPEN q_detail_1;
        for(;;)
        {
             $FETCH q_detail_1;
             if (SQLCODE == SQLNOTFOUND) break;

             strcpy(iins_type, trim(iins_type));
             strcpy(frate    , trim(frate) );
             printf("##### 1.ao_plyedr_detail[%s][%s][%s][%ld]\n", ipolicy,iins_type,icar_type,tmp_qply_period);
                                        
             if (strcmp(fIFRS, "Y") == 0)
             {
                 strcpy(icohort,"");
                 cm_split_ymd(inf_dclose,mm,dd,yy);
                 strcpy(icohort,yy);
             	
                 if (strcmp(fcard_class, "1") == 0) 
                     strcpy(isubcode, trim(icar_type));  /* �s�դl�X-�j���I������ */
                 else
                     strcpy(isubcode, " ");             		
           	
                 /* ����|�p��l��(IFRS) */
                 rtncode = get_portfolio_group_car("C",iins_type,icar_type,tmp_qply_period,"D"," ","D",icohort,isubcode,
                                                  iproduct,kclsfyitem,kreserve,provision,frate,fapply,iportfolio,igroup);  
             	
                 if (rtncode != M_CM_OK)
                 {
                     if (rtncode < 0) goto optP_err;
             	     else goto optP_err1;
                 }
             }
             else
             {
                 /* ����|�p��l�� */
                 rtncode = get_product_code_car("C",iins_type,icar_type,tmp_qply_period,iproduct,kclsfyitem,kreserve,provision,frate);
             	 if (rtncode != M_CM_OK)
             	 {
             	     if (rtncode < 0) goto optP_err;
             	     else goto optP_err1;
             	 }
             }     
  

             strcpy(kclsfyitem, trim(kclsfyitem));
             printf("##### 2.ao_plyedr_detail[%s][%s][%s][%ld][%s]\n", ipolicy,iins_type,icar_type,tmp_qply_period,kclsfyitem);

             memset(err_buf,0,sizeof(err_buf));
             strcpy(err_buf,"insert ao_plyedr_detail:");
             strcat(err_buf,ipolicy);
             strcat(err_buf,":kclsfyitem:");
             strcat(err_buf,kclsfyitem);

             /* �j���I���v�����92�~7��1��_���L�ܰ]�| */
             $UPDATE ao_plyedr_detail
                 SET mprem        = mprem        + $mins_premium,
                     mprem_nt     = mprem_nt     + $mins_premium,
                     mdiscount    = mdiscount    + $mdiscount,
                     mdiscount_nt = mdiscount_nt + $mdiscount
               WHERE ipolicy1    = $ply1
                 AND ipolicy2    = $ply2
                 AND iendorse    = ''
                 AND insure_kind = $kclsfyitem;

             if (sqlca.sqlerrd[2]==0)
             {
                   $INSERT INTO  ao_plyedr_detail
                                (ipolicy1,ipolicy2,iendorse,
                                 insure_kind,
                                 icur,
                                 mprem,mprem_nt,
                                 mcompensation_nt,
                                 mdiscount, mdiscount_nt)
                         VALUES ($ply1,$ply2," ",
                                 $kclsfyitem,
                                 "NT",
                                 $mins_premium,$mins_premium,
                                 0,
                                 $mdiscount,$mdiscount);
             }
        }
        $CLOSE q_detail_1;

        PlyCurr=PlyCurr->next;
    }

    $WHENEVER SQLERROR GOTO optP_err;    /* resume error handling */

    /**** STEP P.1--(7) *****************************************/
    /************************************/
    /************************************/
    /*   cm_esign_data   cm_esign_data  */
    /************************************/
    /************************************/
    /* 1060817004-C1�q�lñ�p
    �O��鵲��^�g�q�lñ�p��ƥD�ɸ��I�q�lñ�p����ɡF�����y�Ǹ����n�^�g�C
      ���A����u�B�z1:�w�X���2:�w�鵲�A�p��s�����\���i�鵲�A�����ܡm����s�q�lñ�p����ɡn�A�C
      DM�� �h�^�g�����渹
    */


    printf("*********** into P.1--(7) update cm_esign_data   cm_esign_data\n");
    previous_ply1[0]='\0';
    PlyCurr=PlyFirst;
    while (PlyCurr)
    {
        
        strcpy(ipolicy,         PlyCurr->ipolicy);          
        strcpy(assuredi,        PlyCurr->assuredi);         /*�Q�O�HID*/
        strcpy(itag_number,     PlyCurr->tagnum);           if (itag_number[0]=='\0') strcpy(itag_number," ");
        strcpy(body,            PlyCurr->body);             if (body[0]=='\0') strcpy(body," ");
        strcpy(engine,          PlyCurr->engine);           if (engine[0]=='\0') strcpy(engine," ");
        strcpy(icard,           PlyCurr->icard);
        strcpy(assuredn,        PlyCurr->assuredn);         /*�Q�O�H�m�W*/
        strcpy(paymenta,        PlyCurr->paymenta);         /*�n�O�H�a�} */
        strcpy(assureda,        PlyCurr->assureda);         /*�Q�O�I�H�a�} */
        strcpy(fcard_class,     PlyCurr->fcard_class);
        strcpy(iofficer,        PlyCurr->iofficer);
        strcpy(ileader ,        PlyCurr->ileader);
        strcpy(ibig_sales,      PlyCurr->ibig_sales);       if (ibig_sales[0]=='\0') strcpy(ibig_sales," ");/*�q���~�ȭ�*/
        strcpy(ireg_no,         PlyCurr->ireg_no);          if (ireg_no[0]=='\0') strcpy(ireg_no," ");/*1080408005-SC1-��ã��-�j���һ{�ҷs�W�q����Ƥεn���Ҹ� */
        strcpy(ibig_office,     PlyCurr->ibig_office);      if (ibig_office[0]=='\0') strcpy(ibig_office," ");/*������~��*/
        dpolicy   = PlyCurr->dpolicy;
        dbegin    = PlyCurr->ply_begin;
        dend      = PlyCurr->ply_end;
        strcpy(tmp_policy,      PlyCurr->itmp_policy);      /*�����渹*/
        strcpy(nequipment,      PlyCurr->nequipment);
        strcpy(izip,            PlyCurr->zip);              /*�Q�O�I�H�l���ϸ�*/
        strcpy(iapplicant,      PlyCurr->iapplicant);
        strcpy(napplicant,      PlyCurr->napplicant);
        strcpy(introducer,      PlyCurr->introducer);      if (introducer[0]=='\0') strcpy(introducer," ");     /*�q�����u*/
        strcpy(iroute,          PlyCurr->iroute);
        strcpy(iscan_no,        PlyCurr->iscan_no);        
        strcpy(isurvey_num ,    PlyCurr->isurvey_num);     if (isurvey_num[0]=='\0') strcpy(isurvey_num," ");
        strcpy(ibound_num ,     PlyCurr->ibound_num);      if (ibound_num[0]=='\0') strcpy(ibound_num," ");
        strcpy(ixxcard ,        PlyCurr->ixxcard);         if (ixxcard[0]=='\0') strcpy(ixxcard," ");
        strcpy(iroute_accept ,  PlyCurr->iroute_accept);   if (iroute_accept[0]=='\0') strcpy(iroute_accept," "); /*�q�����z�s��*/
        strcpy(nassured_deputy, PlyCurr->nassured_deputy); if (nassured_deputy[0]=='\0') strcpy(nassured_deputy," "); /*�Q�O�I�H�k�H�N��*/
        strcpy(tassured_day ,   PlyCurr->tassured_day);    if (tassured_day[0]=='\0') strcpy(tassured_day," ");  /*�Q�O�I�H�q��(��)*/
        strcpy(tassured_night , PlyCurr->tassured_night);  if (tassured_night[0]=='\0') strcpy(tassured_night," ");     /*�Q�O�I�H�q��(�])*/
        strcpy(tassured_mobile, PlyCurr->tassured_mobile); if (tassured_mobile[0]=='\0') strcpy(tassured_mobile," "); /*�Q�O�I�H��ʹq��*/
        strcpy(aassured_email , PlyCurr->aassured_email);  if (aassured_email[0]=='\0') strcpy(aassured_email," "); /*�Q�O�I�H�q�l�H�c*/
        strcpy(napplicant_deputy ,PlyCurr->napplicant_deputy); if (napplicant_deputy[0]=='\0') strcpy(napplicant_deputy," ");/*�n�O�H�k�H�N��*/
        strcpy(apayment_zip ,     PlyCurr->apayment_zip);  if (apayment_zip[0]=='\0') strcpy(apayment_zip," ");         /*�n�O�H�l���ϸ�*/
        strcpy(tapplicant_day ,   PlyCurr->tapplicant_day);  if (tapplicant_day[0]=='\0') strcpy(tapplicant_day," "); /*�n�O�H�p���q��(��)*/
        strcpy(napplicant_relation,PlyCurr->napplicant_relation); if (napplicant_relation[0]=='\0') strcpy(napplicant_relation," ");/*�n�Q�O�I�H���Y*/
        strcpy(nuser ,     PlyCurr->nuser);                 if (nuser[0]=='\0') strcpy(nuser," ");
        strcpy(qpro_month ,     PlyCurr->qpro_month);       if (qpro_month[0]=='\0') strcpy(qpro_month," ");
        strcpy(ibrand ,     PlyCurr->ibrand);               if (ibrand[0]=='\0') strcpy(ibrand," ");
        strcpy(ipro_year ,     PlyCurr->ipro_year);         if (ipro_year[0]=='\0') strcpy(ipro_year," ");
        qcylinder = PlyCurr->qcylinder;                     
        qpt       = PlyCurr->qpt;
        mequipment= PlyCurr->mequipment;
        strcpy(feply  ,PlyCurr->feply);
        strcpy(feterms  ,PlyCurr->feterms);/*1100419003-���I�O�����QR Code�q�l��-�ȥ��O��u�q�l���ڡv feterms*/
        strcpy(aemail_eply ,PlyCurr->aemail_eply);          if (aemail_eply[0]=='\0') strcpy(aemail_eply," ");
        
        /* 1060817004_SC4_�s�W�q�lñ�p�����{��-�W�[���  */
        strcpy(tmobile_eply ,PlyCurr->tmobile_eply);          if (tmobile_eply[0]=='\0') strcpy(tmobile_eply," ");/*1080417001-SC1-���ά�-�s�W�q�l�O��H²�T�覡�o�e */
        strcpy(foccup ,PlyCurr->foccup);                        if (foccup[0]=='\0') strcpy(foccup," "); /*�Q�O�I�H¾/��~�O*/
        strcpy(applicant_foccup ,PlyCurr->applicant_foccup);    if (applicant_foccup[0]=='\0') strcpy(applicant_foccup," "); /*�n�O�H¾/��~�O*/
        strcpy(dbirth_esign ,PlyCurr->dbirth);                  if (dbirth_esign[0]=='\0') strcpy(dbirth_esign," "); /*�Q�O�I�H�ͤ�*/
        strcpy(dbirth_appl ,PlyCurr->dbirth_appl);              if (dbirth_appl[0]=='\0') strcpy(dbirth_appl," ");   /*�n�O�H�ͤ�*/
        strcpy(tmobile_appl ,PlyCurr->tmobile_appl);            if (tmobile_appl[0]=='\0') strcpy(tmobile_appl," "); /*�n�O�H������X*/
        strcpy(dissue ,PlyCurr->dissue);                        if (dissue[0]=='\0') strcpy(dissue," "); /*�o�Ӧ~��*/
        printf("--dbirth_esign[%s] \n",PlyCurr->dbirth);
        printf("--dbirth_appl[%s] \n",PlyCurr->dbirth_appl);
        printf("--dissue_ply[%s] \n",PlyCurr->dissue);
        strcpy(tmobile_eply ,PlyCurr->tmobile_eply);          if (tmobile_eply[0]=='\0') strcpy(tmobile_eply," "); /*�q�l�O�������X*/
        strcpy(aemail_appl ,PlyCurr->aemail_appl);          if (aemail_appl[0]=='\0') strcpy(aemail_appl," ");/*1100913004-SC1-���I�q�lñ�p�s�W�n�O�Hemail���*/
        strcpy(ftrans_third ,PlyCurr->ftrans_third);        if (ftrans_third[0]=='\0') strcpy(ftrans_third," ");/*1111003006_SC1_�q�lñ�p���x�s�W����[�~����Ʀ@��]�ﶵ���O*/
        printf("--ftrans_third[%s][%s] \n",PlyCurr->ftrans_third,ftrans_third);
        if (strlen(trim(iscan_no)) >0)
        {   
            
            if (*fcard_class == '1')
            {
                $UPDATE cm_esign_data 
                    SET fstatus  ='2',
                        iofficer = $iofficer,
                        ileader  = $ileader,
                        dins_bgn = $dbegin,
                        dins_end = $dend,
                        dply_edr = $plydate,
                        iroute      = $iroute  ,
                        isales      = $ibig_sales  ,
                        iapplicant  = $iapplicant  ,
                        napplicant  = $napplicant  ,
                        iassured    = $assuredi  ,
                        nassured    = $assuredn  ,
                        itag        = $itag_number  ,
                        iengine     = $engine,
                        iroute_accept = $iroute_accept,
                        iupdate     = 'CAR5081',
                        dupdate     = current  ,
                        foccup_assured   = $foccup  ,
                        foccup_applicant = $applicant_foccup ,
                        ftrans_third     = $ftrans_third
                  where iscan_no = $iscan_no
                    AND fstatus = '1';
                if (sqlca.sqlerrd[2]==0)
                {
                    sprintf_s( sErrMsg, sizeof sErrMsg,"�O�渹[%s]����s�q�lñ�p�����[%s]", ipolicy,iscan_no );
                    WRITELOG( sfp, sErrMsg);
                    strcpy(v_sMsg,"����s�q�lñ�p�����");
                    GetMsg(ipolicy,v_sMsg);                    
                }
                
                $update ca_esign_data
                    set icard    = $icard,
                        fecard   = $feply
                  WHERE iscan_no = $iscan_no;       
                if (sqlca.sqlerrd[2]==0)
                {
                    sprintf_s( sErrMsg, sizeof sErrMsg, "�O�渹[%s]����s�q�lñ�p�����[%s]", ipolicy,iscan_no );
                    WRITELOG( sfp, sErrMsg);
                    strcpy(v_sMsg,"����s�q�lñ�p�����");
                    GetMsg(ipolicy,v_sMsg);                    
                }
            }
            else
            {
                $UPDATE cm_esign_data 
                    SET fstatus2  ='2',
                        iofficer2 = $iofficer,
                        ileader2  = $ileader,
                        dins_bgn2 = $dbegin,
                        dins_end2 = $dend,
                        dply_edr2 = $plydate,
                        iroute      = $iroute  ,
                        isales      = $ibig_sales  ,
                        iapplicant  = $iapplicant  ,
                        napplicant  = $napplicant  ,
                        iassured    = $assuredi  ,
                        nassured    = $assuredn  ,
                        itag        = $itag_number  ,
                        iroute_accept = $iroute_accept,
                        iengine     = $engine ,
                        iupdate     = 'CAR5081',
                        dupdate     = current ,
                        foccup_assured   = $foccup ,
                        foccup_applicant = $applicant_foccup ,
                        ftrans_third     = $ftrans_third
                  where iscan_no  = $iscan_no
                    AND fstatus2 = '1';
                if (sqlca.sqlerrd[2]==0)
                {
                    sprintf_s( sErrMsg, sizeof sErrMsg, "�O�渹[%s]����s�q�lñ�p�����[%s]", ipolicy,iscan_no );
                    WRITELOG( sfp, sErrMsg);
                    strcpy(v_sMsg,"����s�q�lñ�p�����");
                    GetMsg(ipolicy,v_sMsg);                    
                }
                /* 1100419003-���I�O�����QR Code�q�l��-�ȥ��O��u�q�l���ڡvfeterms */
                $update ca_esign_data
                    set icard2    = $icard,
                        feply     = $feply,
                        feterms   = $feterms
                  WHERE iscan_no = $iscan_no;
                if (sqlca.sqlerrd[2]==0)
                {
                    sprintf_s( sErrMsg, sizeof sErrMsg, "�O�渹[%s]����s�q�lñ�p�����[%s]", ipolicy,iscan_no );
                    WRITELOG( sfp, sErrMsg);
                    strcpy(v_sMsg,"����s�q�lñ�p�����");
                    GetMsg(ipolicy,v_sMsg);                    
                }  
            }
            /*DM��h�^�g�����渹*/
            $UPDATE cm_esign_data 
                SET iquote = $tmp_policy
              where iscan_no = $iscan_no
                AND fcase = '2';    
            printf("--dissue[%s]\n",dissue);
			/* 1080417001-SC1-���ά�-�s�W�q�l�O��H²�T�覡�o�e  �p�T:�Ȥ��W�[ tmobile_eply*/
            /*1100913004-SC1-���I�q�lñ�p�s�W�n�O�Hemail���*/
            $update ca_esign_data
                set nequipment            = $nequipment    ,
                    isurvey_num           = $isurvey_num    ,
                    ibound_num            = $ibound_num    ,
                    ixxcard               = $ixxcard    ,
                    nassured_deputy       = $nassured_deputy    ,
                    aassured_zip          = $izip    ,
                    aassured              = $assureda    ,
                    tassured_day          = $tassured_day    ,
                    tassured_night        = $tassured_night    ,
                    tassured_mobile       = $tassured_mobile    ,
                    aassured_email        = $aassured_email    ,
                    napplicant_deputy     = $napplicant_deputy    ,
                    aapplicant_zip        = $apayment_zip    ,
                    aapplicant            = $paymenta    ,
                    tapplicant_day        = $tapplicant_day    ,
                    napplicant_relation   = $napplicant_relation    ,
                    nuser                 = $nuser    ,
                    ipro_year             = $ipro_year    ,
                    qpro_month            = $qpro_month    ,
                    ibrand                = $ibrand    ,
                    qcylinder             = $qcylinder    ,
                    ibody                 = $body    ,
                    qpt                   = $qpt    ,
                    mequipment            = $mequipment    ,
                    ibig_office           = $ibig_office    ,
                    introducer            = $introducer    ,
                    aemail_eply           = $aemail_eply  ,
                    dassured_dbirth       = $dbirth_esign ,
                    dapplicant_birth      = $dbirth_appl  ,
                    tapplicant_mobile     = $tmobile_appl  ,
                    dissue                = $dissue ,
                    tmobile_eply          = $tmobile_eply,
                    aapplicant_email      = $aemail_appl        
              where iscan_no  = $iscan_no;
                if (sqlca.sqlerrd[2]==0)
                {
                    sprintf_s( sErrMsg, sizeof sErrMsg, "�O�渹[%s]����s���I�q�lñ�p�����[%s]", ipolicy,iscan_no );
                    WRITELOG( sfp, sErrMsg);
                    strcpy(v_sMsg,"����s���I�q�lñ�p�����");
                    GetMsg(ipolicy,v_sMsg);                    
                }
        }    
        PlyCurr=PlyCurr->next;
    }

    $WHENEVER SQLERROR GOTO optP_err;    /* resume error handling */
    
    /**** STEP P.1--(8) *****************************************/
    /************************************/
    /************************************/
    /*   ao_officer_commit              */
    /************************************/
    /************************************/
    printf("*********** into P.1--(8) insert ao_officer_commit\n");

    previous_ply1[0]='\0';

    PlyCurr=PlyFirst;

    while (PlyCurr)
    {
        strcpy(ipolicy,         PlyCurr->ipolicy);
        strcpy(iofficer,        PlyCurr->iofficer);
        strcpy(ibig_office,     PlyCurr->ibig_office);
        strcpy(fcard_class,     PlyCurr->fcard_class);
        strcpy(ibroker,         PlyCurr->ibroker);
        strcpy(ibig_comp,       PlyCurr->ibig_comp);
        strcpy(icar_type,       PlyCurr->icar_type);
        strcpy(ibig_sales,      PlyCurr->ibig_sales);
        strcpy(ibroker_top,     PlyCurr->ibroker_top);
        strcpy(icomm_obj,       PlyCurr->icomm_obj);
        strcpy(tmp_ibranch_in,  PlyCurr->ibranch_in);/*1070322011-SC1-�Q���줽�Ǥɮ欰�x�_�����q*/
        ibatch_no = PlyCurr->ibatch_no;

        /* �t�X�q���ĤG���q,�g�Q�׫�M�wmark */
        /* if (ibroker[0]=='\0' || ibroker[0]==' ')
        {
            PlyCurr=PlyCurr->next;
            continue;
        } */

        /*------*/
        strncpy(ply1, ipolicy, CAR_POLICY_LEN);
        ply1[CAR_POLICY_LEN]='\0';

        strncpy(ply2, ipolicy+CAR_POLICY_LEN, CAR_TARGET_LEN);
        ply2[CAR_TARGET_LEN]='\0';

        if (ply2[0]=='\0' || ply2[0]==' ') strcpy(ply2," ");

        if(*fcard_class=='2')
           strcpy(irelative_ply, PlyCurr->irelative_ply);
        else
           strcpy(irelative_ply, PlyCurr->ipolicy);

        strcpy(icard,PlyCurr->icard);

        /*------*/
        mprem=mcommit=magent=mdeal=0;

        if (*fcard_class=='1')
        {
            $SELECT mlia_prem, mlia_commi
               INTO $mprem   , $mdeal
               FROM ply_relation
              WHERE ipolicy = $ipolicy;

            mcommit=0;
            magent=0;
        }
        else if (*fcard_class=='2')
        {
            $SELECT mdmg_prem+mlia_prem,
                    mdmg_commi+mlia_commi,
                    mdmg_agent+mlia_agent
               INTO $mprem,$mcommit,$magent
               FROM ply_relation
              WHERE ipolicy = $ipolicy
                AND dpolicy = $plydate;

            mdeal=0;
        }

        /*------*/
        /* $SELECT ptax
           INTO $ptax
           FROM broker_agent
          WHERE ibroker = $ibroker;

        if (NOT_FOUND) ptax=0; */
        /* �g��]�ȩT�w����0 , �Ѱ]�Ⱥݵ{���ۦ�p�� */
        ptax=0;
        sprintf_s(tmp_ptax,sizeof tmp_ptax,"%7.2f",ptax);
        deccvasc(tmp_ptax,strlen(tmp_ptax),&dec_ptax);
        dectodbl(&dec_ptax,&ptax_1);

        /*------*/
        if (isalpha(ibig_comp[0]))
            fbig_rcv = 'Y';
        else
            fbig_rcv = 'N';

        /*------*/
        memset(err_buf,0,sizeof(err_buf));
        strcpy(err_buf,"insert ao_officer_commit:");
        strcat(err_buf,ipolicy);

        /* ���I���j�v���,�ƻs�I����H�N���� ao_officer_commit.ibroker */
        if (isalpha(ibig_comp[0]))
        {
            printf("  ���I���j�v���,�ƻs�I����H�N���� ao_officer_commit.ibroker \n");
            strcpy(ibroker, icomm_obj);
        }

        if (ibatch_no==0)
           strcpy(tmp_ibatch_no," ");
        else
           strcpy(tmp_ibatch_no,itoa(ibatch_no));
        /*1070322011-SC1-�Q���줽�Ǥɮ欰�x�_�����q*/
        $SELECT iaccount_branch INTO $sIaccount_branch
           FROM branch 
          WHERE ibranch = $tmp_ibranch_in;
        printf("ao_plyedr_prem\n�Q���줽�Ǥɮ欰�x�_�����q\nsIaccount_branch[%s]\n",sIaccount_branch);
       
        if ((mcommit != 0) || (magent != 0) || (mdeal !=0))
        {
           /* �g��]�Ⱥݪ�ibroker����ONULL  add by sylvia 100.11.04 */
            if (ibroker[0]==' ' || ibroker[0]=='\0' || strlen(ibroker) == 0 )
                  strcpy(ibroker, " ");
         	 /* �t�X�]�|���پ�X�@�~,�s�W���isub    modify by sylvia (1001228004_C1) */
           $INSERT INTO  ao_officer_commit
                        (ipolicy1,ipolicy2,iendorse,iofficer,ibroker,icard,
                         insure_type,icur,iaccount_branch,
                         mpremium,mcommit,magent,mdeal,ptax,
                         fbig_rcv,dplyend,ftype, ibig_sales,
                         mcommit_nt,magent_nt,mdeal_nt,fstatus,sys_source,
                         irelative,ibank,ibroker_top, icomm_obj,isub)
                 VALUES ($ply1,$ply2," ",$iofficer,$ibroker,$icard,
                         "C","NT",$sIaccount_branch,
                         $mprem,$mcommit,$magent,$mdeal,$ptax_1,
                         $fbig_rcv,$plydate,"P", $ibig_sales,
                         $mcommit,$magent,$mdeal,"N","CA1",
                         $irelative_ply,$ibig_office,$ibroker_top, $icomm_obj,$isub);
        }

        PlyCurr=PlyCurr->next;
    }

    printf("before sqlerror SQLCODE[%d]\n",SQLCODE);
    $WHENEVER SQLERROR GOTO optP_err;    /* resume error handling */

    /**** STEP P.1--(9) *****************************************/
    /************************************/
    /************************************/
    /*   ao_commit_detail               */
    /************************************/
    /************************************/
    printf("*********** into P.1--(9) insert ao_commit_detail\n");

    previous_ply1[0]='\0';

    PlyCurr=PlyFirst;

    while (PlyCurr)
    {
        mcommit1=magent1=mdeal1=0;

        strcpy(ipolicy     , PlyCurr->ipolicy);
        strcpy(ibroker     , PlyCurr->ibroker);
        strcpy(iofficer    , PlyCurr->iofficer);
        strcpy(fcard_class , PlyCurr->fcard_class);
        strcpy(icar_type   , PlyCurr->icar_type);
        tmp_qply_period    = PlyCurr->qply_period;
        strcpy(ibroker_top , PlyCurr->ibroker_top);
        strcpy(icomm_obj   , PlyCurr->icomm_obj);

        ibatch_no=PlyCurr->ibatch_no;

        /* �t�X�q���ĤG���q,�g�Q�׫�M�wmark */
        /* if (ibroker[0]=='\0' || ibroker[0]==' ')
        {
            PlyCurr=PlyCurr->next;
            continue;
        } */

        /*------*/
        strncpy(ply1,ipolicy,CAR_POLICY_LEN);
        ply1[CAR_POLICY_LEN]='\0';

        strncpy(ply2,ipolicy+CAR_POLICY_LEN,CAR_TARGET_LEN);
        ply2[CAR_TARGET_LEN]='\0';

        if (ply2[0]=='\0' || ply2[0]==' ') strcpy(ply2," ");

        /*------*/
        /* $SELECT ptax
           INTO $ptax
           FROM broker_agent
          WHERE ibroker=$ibroker;
        if (NOT_FOUND) ptax=0; */

        /* �g��]�ȩT�w����0 , �Ѱ]�Ⱥݵ{���ۦ�p�� */
        ptax=0;
        sprintf_s(tmp_ptax,sizeof tmp_ptax,"%7.2f",ptax);
        deccvasc(tmp_ptax,strlen(tmp_ptax),&dec_ptax);
        dectodbl(&dec_ptax,&ptax_1);

        /*------*/
        mcommit1 = magent1 = mdeal1 = 0;

        if (ibatch_no==0)
           strcpy(tmp_ibatch_no," ");
        else
           strcpy(tmp_ibatch_no,itoa(ibatch_no));

        strcpy(icar_type, trim(icar_type));


        /* ���I���j�v���,�ƻs�I����H�N���� ao_commit_detail.ibroker */
        if (isalpha(ibig_comp[0]))
        {
            printf(" ���I���j�v���,�ƻs�I����H�N���� ao_commit_detail.ibroker \n");
            strcpy(ibroker, icomm_obj);

        }

        $DECLARE q_commi_1 CURSOR WITH HOLD FOR
          SELECT b.iins_type, b.mcommission, b.magent, b.mcommission, b.provision ,b.drate_ym
            INTO $iins_type,  $mcommit1,     $magent1, $mdeal1, $provision , $frate
            FROM ply_relation a , ply_ins_type b
           WHERE a.ipolicy = b.ipolicy
             AND a.ipolicy = $ipolicy;
        $OPEN q_commi_1;
        for(;;)
        {
             $FETCH q_commi_1;
             if (SQLCODE==SQLNOTFOUND) break;

             strcpy(iins_type, trim(iins_type));
             strcpy(frate    , trim(frate) );
             printf("#####ao_commit_detail[%s][%s][%s][%ld]\n", ipolicy,iins_type,icar_type,tmp_qply_period);
                          
             if (strcmp(fIFRS, "Y") == 0)
             {
             	strcpy(icohort,"");
             	cm_split_ymd(inf_dclose,mm,dd,yy);
             	strcpy(icohort,yy);
             	
             	if (strcmp(fcard_class, "1") == 0) 
             		strcpy(isubcode, trim(icar_type));  /* �s�դl�X-�j���I������ */
             	else
             		strcpy(isubcode, " ");             		
           	
             	/* ����|�p��l��(IFRS) */
             	rtncode = get_portfolio_group_car("C",iins_type,icar_type,tmp_qply_period,"D"," ","D",icohort,isubcode,
                                                  iproduct,kclsfyitem,kreserve,provision,frate,fapply,iportfolio,igroup); 
             	
             	if (rtncode != M_CM_OK)
             	{
             		if (rtncode < 0) goto optP_err;
             		else goto optP_err1;
             	}
             }
             else
             {
             	/* ����|�p��l�� */
             	rtncode = get_product_code_car("C",iins_type,icar_type,tmp_qply_period,iproduct,kclsfyitem,kreserve,provision,frate);
             	if (rtncode != M_CM_OK)
             	{
             		if (rtncode < 0) goto optP_err;
             		else goto optP_err1;
             	}
             }

             strcpy(kclsfyitem, trim(kclsfyitem));
             printf("#####ao_commit_detail[%s][%s][%s][%ld][%s]\n", ipolicy,iins_type,icar_type,tmp_qply_period,kclsfyitem);

             memset(err_buf,0,sizeof(err_buf));
             strcpy(err_buf,"insert ao_commit_detail:");
             strcat(err_buf,ipolicy);
             strcat(err_buf,":kclsfyitem:");
             strcat(err_buf,kclsfyitem);

             if ((mcommit1 != 0) || (magent1 != 0) || (mdeal1 != 0))
             {
                 /* �j���I������O mdeal */
                 if (fcard_class[0]=='1')
                 {
                      mcommit1 = 0;
                      magent1  = 0;
                 }
                 else
                 {
                      mdeal1   = 0;
                 }

                 $UPDATE ao_commit_detail
                     SET mcommit    = mcommit    + $mcommit1,
                         mcommit_nt = mcommit_nt + $mcommit1,
                         magent     = magent     + $magent1,
                         magent_nt  = magent_nt  + $magent1,
                         mdeal      = mdeal      + $mdeal1,
                         mdeal_nt   = mdeal_nt   + $mdeal1
                   WHERE ipolicy1    = $ply1
                     AND ipolicy2    = $ply2
                     AND iendorse    = ''
                     AND insure_kind = $kclsfyitem;

                 if (sqlca.sqlerrd[2]==0)
                 {
                       /* �g��]�Ⱥݪ�ibroker����ONULL  add by sylvia 100.11.04 */
                        if (ibroker[0]==' ' || ibroker[0]=='\0' || strlen(ibroker) == 0 )
                              strcpy(ibroker, " ");

                       $INSERT INTO  ao_commit_detail
                                    (ipolicy1,ipolicy2,iendorse,insure_kind,icur,
                                     mcommit,   magent,   mdeal,    ptax,
                                     mcommit_nt,magent_nt,mdeal_nt, iofficer, ibroker, ibroker_top)
                             VALUES ($ply1,   $ply2,   " ",     $kclsfyitem,"NT",
                                     $mcommit1, $magent1, $mdeal1, $ptax_1,
                                     $mcommit1, $magent1, $mdeal1, $iofficer, $ibroker, $icomm_obj);
                 }
             }
        }
        $CLOSE q_commi_1;

        PlyCurr=PlyCurr->next;
    }

    $WHENEVER SQLERROR GOTO optP_err;    /* resume error handling */

    /**** STEP P.1--(10) *****************************************/
    /************************************/
    /************************************/
    /*   cm_credit_pay_dailyupdate()    */
    /************************************/
    /************************************/
    printf("*********** into P.1--(10)\n");

    PlyCurr=PlyFirst;

    $CREATE TEMP TABLE TmpDeleteCmCreditPay
    (
        iestimate CHAR(20)

    ) WITH NO LOG;

    while (PlyCurr)
    {
       strcpy(ipolicy, PlyCurr->ipolicy);
       strcpy(iofficer,PlyCurr->iofficer);

       /****���H ibig_comp �ӧP�_�A�ثe ibig_comp �����D�A�令�Hiofficer�P�_**/

       if(iofficer[0] >= 'A' && iofficer[0] <= 'X')
       {
          strcpy(fcommit,"1");
          strcpy(iedr_return,"2");
       }
       else
       {
          strcpy(fcommit,"N");
          strcpy(iedr_return,"1");
       }

       memset(err_buf,0,sizeof(err_buf));
       strcpy(err_buf,  "insert ao_io_credit:");
       strcat(err_buf,  ipolicy);

       rtncode = split_policy(ipolicy, ply1, ply2);
       if (rtncode != M_CM_OK)
       {
          if (rtncode < 0) goto optP_err;
          else goto optP_err1;
       }
       /* cm_credit_pay_dailyupdate() �t�X�]�|��X���,�s�Wisub�Ѽ� modify by sylvia 101.07.23 (1001228004_C1) */
       rtncode = cm_credit_pay_dailyupdate(ply1, ply2, "",fcommit,iofficer,isub);
       if (rtncode != M_CM_OK)
       {
          if (rtncode < 0) goto optP_err;
          else goto optP_err1;
       }

       puts("INSERT INTO TmpDeleteCmCreditPay");

       $INSERT INTO TmpDeleteCmCreditPay
        SELECT iestimate
          FROM cm_credit_pay
         WHERE ipolicy1 = $ply1
           AND ipolicy2 = $ply2
           AND dclose is not null
           AND iestimate != '';

       printf("INSERT INTO TmpDeleteCmCreditPay SQLCODE[%d]\n", SQLCODE);

       PlyCurr=PlyCurr->next;
    }
    $FREE prep1;
    $FREE prep2;

    i=0;

    $declare curs1 CURSOR for
      select iestimate from TmpDeleteCmCreditPay;
    $open curs1;
    for(;;)
    {
        $fetch curs1 into $iestimate;
        if( SQLCODE == SQLNOTFOUND)
            break;
        i=i+1;
    }

    /* �N�w�X��鵲��B2C,�x�sB2B,��H�Υd���(�L�O�渹��)�R���AB2C�C�ѷ|��W�L10�ѥ��X�檺��Ƶ��ӫO */

    $delete from cm_credit_pay
      where ipolicy1 = ''
        and ipolicy2 = ''
        and iestimate in (select iestimate from TmpDeleteCmCreditPay)
        and dclose is null;

    printf("DELETE FROM cm_credit_pay SQLCODE[%d]\n", SQLCODE);

    $WHENEVER SQLERROR GOTO optP_err;    /* resume error handling */

    /**** STEP P.1--(11) *****************************************/
    printf("*********** into P.1--(11)\n");

    PlyCurr=PlyFirst;

    /************************************/
    /************************************/
    /*   ply_ins_type_hist              */
    /*   ca_pa_ply_hist                 */
    /************************************/
    /************************************/
    printf("********** insert into ply_ins_type_hist & ca_pa_ply_hist\n");
    while (PlyCurr)
    {
        strcpy(ipolicy,PlyCurr->ipolicy);

        dbegin=PlyCurr->ply_begin;
        dend=PlyCurr->ply_end;
        strcpy(dtbegin,PlyCurr->dtedr_bgn);  /* 1061108001-SC4-�s��*/
        strcpy(dtend,PlyCurr->dtedr_end);
        
        qprovision = PlyCurr->qprovision;
        $DECLARE cur_hist1 CURSOR FOR
          SELECT iins_type,
                 SUM(minjured_cover),SUM(mdeath_cover),SUM(mdamage_cover),SUM(mdeduct),
                 SUM(mins_premium),SUM(qday),SUM(mexpense),provision
            FROM ply_ins_type
           WHERE ipolicy=$ipolicy
           GROUP BY iins_type,provision;
        $OPEN cur_hist1;
        while (1)
        {
              $FETCH cur_hist1 INTO $iins_type,
                                    $minjured_cover,$mdeath_cover,$mdamage_cover,$mdeduct,
                                    $prem1,$qday,$mexpense,$provision;
              if( SQLCODE == SQLNOTFOUND) break;

              memset(err_buf,0,sizeof(err_buf));
              strcpy(err_buf,"insert ply_ins_type_hist:");
              strcat(err_buf,ipolicy);
              strcat(err_buf,",");
              strcat(err_buf,iins_type);

              $INSERT INTO ply_ins_type_hist
                           (ipolicy,iins_type,dedr_begin,dedr_end,dendorse,
                            minjured_cover,mdeath_cover,mdamage_cover,
                            mdeduct,mpremium,qday,mexpense,provision,
                            dtedr_begin,dtedr_end)
                    VALUES ($ipolicy,$iins_type,$dbegin,$dend,$plydate,
                            $minjured_cover,$mdeath_cover,$mdamage_cover,
                            $mdeduct,$prem1,$qday,$mexpense,$provision,
                            $dtbegin,$dtend);

              if( (strcmp(trim(iins_type),"33")==0)  || (strcmp(trim(iins_type),"35")==0) ||
                  (strcmp(trim(iins_type),"48")==0)  || (strcmp(trim(iins_type),"56")==0) || 
                  (strcmp(trim(iins_type),"136")==0) || (strcmp(trim(iins_type),"166")==0)||
                  (strcmp(trim(iins_type),"266")==0))
              {
                   memset(err_buf,0,sizeof(err_buf));
                   strcpy(err_buf,"insert ca_pa_ply_hist:");
                   strcat(err_buf,ipolicy);
                   strcat(err_buf,",");
                   strcat(err_buf,iins_type);

                   $DECLARE cur_hist2 CURSOR FOR
                     SELECT iinsurant, iins_scope, icareer,
                            mins_amt, mins_premium, daily_pay
                       FROM ca_pa_ply
                      WHERE ipolicy = $ipolicy AND iins_type = $iins_type;
                   $OPEN cur_hist2;
                   while (1)
                   {
                         $FETCH cur_hist2 INTO :cIinsurant, :cIins_scope , :cIcareer,
                                               :lMins_amt, :lMins_premium, :lDaily_pay;

                         if( SQLCODE == SQLNOTFOUND) break;

                         $INSERT INTO ca_pa_ply_hist
                                      (ipolicy , iins_type, iinsurant , iins_scope , icareer ,
                                       mins_amt , mins_premium , daily_pay,
                                       dendorse , dedr_begin , dedr_end)
                               VALUES (:ipolicy , :iins_type, :cIinsurant, :cIins_scope , :cIcareer,
                                       :lMins_amt, :lMins_premium, :lDaily_pay,
                                       :plydate,  :dbegin, :dend);

                   }
                   $CLOSE cur_hist2;
              }
              #ifdef CA_CONS

              memset(err_buf,0,sizeof(err_buf));
              strcpy(err_buf,"insert ply_ins_cover_hist:");
              strcat(err_buf,ipolicy);
              strcat(err_buf,",");
              strcat(err_buf,iins_type);

              $DECLARE cur_hist3 CURSOR FOR
                SELECT icover_type, mcover, mcover_prem, mdiscount, mprem, mpure_prem
                  FROM ply_ins_cover
                 WHERE ipolicy = $ipolicy AND iins_type = $iins_type;
              $OPEN cur_hist3;
              while (1)
              {
                    $FETCH cur_hist3 INTO $icover_type, $mcover, $mcover_prem, $mdiscount_cover, $mprem_cover, $mpure_prem;

                    if( SQLCODE == SQLNOTFOUND) break;

                    strcat(err_buf,",");
                    strcat(err_buf,icover_type);

                    $INSERT INTO ply_ins_cover_hist
                                 (ipolicy , iins_type, icover_type, mcover, mcover_prem, mdiscount, mprem, mpure_prem,
                                  dendorse , dedr_begin , dedr_end)
                          VALUES ($ipolicy , $iins_type, $icover_type, $mcover, $mcover_prem, $mdiscount_cover,
                                  $mprem_cover, $mpure_prem, $plydate,  $dbegin, $dend);
              }
              $CLOSE cur_hist3;

              #endif

              #ifdef CA_ONE

              memset(err_buf,0,sizeof(err_buf));
              strcpy(err_buf,"insert ply_ins_assured_hist:");
              strcat(err_buf,ipolicy);
              strcat(err_buf,",");
              strcat(err_buf,iins_type);

              $DECLARE cur_hist4 CURSOR FOR
                SELECT iassured, nassured, dbirth, nbenef, rel_benef, provision, 
                       tbenef, abenef_zip, abenef
                  FROM ply_ins_assured
                 WHERE ipolicy = $ipolicy AND iins_type = $iins_type;
              $OPEN cur_hist4;
              while (1)
              {
                    $FETCH cur_hist4 INTO $iassured, $nassured, $dbirth, $nbenef, $rel_benef, $sProvision,
                                          $tbenef, $abenef_zip, $abenef;

                    if( SQLCODE == SQLNOTFOUND) break;

                    strcat(err_buf,",");
                    strcat(err_buf,iassured);
                    printf("ipolicy=[%s],iins_type=[%s], sProvision=[%s]\n",ipolicy,iins_type,sProvision);
                    $INSERT INTO ply_ins_assured_hist
                                 (ipolicy , iins_type, provision, iassured, nassured, dbirth, nbenef, rel_benef,
                                  dendorse , dedr_begin , dedr_end, tbenef, abenef_zip, abenef)
                          VALUES ($ipolicy , $iins_type, $sProvision, $iassured, $nassured, $dbirth, $nbenef, $rel_benef,
                                  $plydate,  $dbegin, $dend, $tbenef, $abenef_zip, $abenef);
              }
              $CLOSE cur_hist4;

              #endif
        }
        $CLOSE cur_hist1;
        /* ���w�r�p�H����(D����)���W�U add by sylvia 101.06.22 */
        /* D���ڦW�U���I�تť� */
        /* 1081225006-SC1-���ά�-�X�R���[���ڥN�X */
        if (qprovision > 0)
        {
        	$DECLARE cur_hist5 CURSOR for
        	  SELECT iassured, nassured, dbirth, nbenef, rel_benef, provision,
        	         tbenef, abenef_zip, abenef
        	    FROM ply_ins_assured
        	   WHERE ipolicy = $ipolicy AND trim(provision)||';' like '%D;%';
        	$OPEN cur_hist5;
        	while (1)
        	{
        		$FETCH cur_hist5 INTO $iassured, $nassured, $dbirth, $nbenef, $rel_benef, $sProvision,
        		                      $tbenef, $abenef_zip, $abenef;
        		if( SQLCODE == SQLNOTFOUND) break;
        		
        		strcat(err_buf,",");
        		strcat(err_buf,iassured);
        		strcpy(iins_type, " ");
        		$INSERT INTO ply_ins_assured_hist
        		            (ipolicy , iins_type, provision, iassured, nassured, dbirth, nbenef, rel_benef,
                                     dendorse , dedr_begin , dedr_end, tbenef, abenef_zip, abenef)
                             VALUES ($ipolicy , $iins_type, $sProvision, $iassured, $nassured, $dbirth, $nbenef, $rel_benef,
                                     $plydate,  $dbegin, $dend, $tbenef, $abenef_zip, $abenef);
                }
                $CLOSE cur_hist5;
        }
        PlyCurr=PlyCurr->next;
    }

    $WHENEVER SQLERROR GOTO optP_err;    /* resume error handling */

    /**** STEP P.1--(13) *****************************************/
    printf("*********** into P.1--(13)\n");

    PlyCurr=PlyFirst;

    while (PlyCurr)
    {
        strcpy(ipolicy,PlyCurr->ipolicy);
        strcpy(fcard_class,PlyCurr->fcard_class);
        strcpy(icar_type,PlyCurr->icar_type);
        strcpy(facf,PlyCurr->facf);

        if(fcard_class[0]=='2' && *facf!=' ')
        {
              sprintf_s(stmt,sizeof stmt,"SELECT %s FROM %s:%s %s",
                                         "iabnormal,ffac",
                                         dbname_tp,"abnormal_ply",
                                         "WHERE ipolicy2= ? ");
              $PREPARE stmt_abn FROM $stmt;
              $DECLARE cur_abn CURSOR FOR stmt_abn;
              $OPEN cur_abn USING $ipolicy;
              $FETCH cur_abn INTO $tmp_abnormal,$facf;
              if (NOT_FOUND)
              {
                  memset(err_buf,0,sizeof(err_buf));
                  strcpy(err_buf,"select abnormal notfound ");
                  strcat(err_buf,ipolicy);
                  $CLOSE cur_abn;
                  $WHENEVER SQLERROR CONTINUE;
                  $ROLLBACK WORK;
                  return M_CA_NESTIMATE;
              }
              $CLOSE cur_abn;

              if(*facf=='P')
              {
                 rtncode=ca_fac_plyclose(tmp_abnormal,ipolicy);
                 if(rtncode != SUCCESS)
                 {
                    memset(err_buf,0,sizeof(err_buf));
                    strcpy(err_buf,"call ca_fac_plyclose error!! ");
                    strcat(err_buf,ipolicy);
                    strcat(err_buf,",");
                    strcat(err_buf,tmp_abnormal);
                    $WHENEVER SQLERROR CONTINUE;
                    $ROLLBACK WORK;
                    return rtncode;
                 }
              }
        }
        PlyCurr=PlyCurr->next;
    }
    $WHENEVER SQLERROR GOTO optP_err;    /* resume error handling */

    /**** STEP P.1--(14) *****************************************/
    /************************************/
    /************************************/
    /*   ao_gl_voucher()                */
    /************************************/
    /************************************/
    printf("*********** into P.1--(14) ao_gl_voucher()\n");

    memset(ivoucher,' ',sizeof(ivoucher));
    printf("-------->ch_dwritten[%s]\n",ch_dwritten);
    printf("ivoucher[%s]\n",ivoucher);
    rtncode=ao_gl_voucher(DBname,"CA1",ch_dwritten,ivoucher,"A","CA1");

    printf("====AFTER ao_gl_voucher(): rtncode[%d]\n",rtncode);
    if (rtncode!=api_OKComplete)
    {
       strcpy(err_buf,"�ۤ��ǲ����~");
       if (rtncode<0) goto optP_err;
       else goto optP_err1;
    }

    /**** STEP P.1--(14.5) *****************************************/
    printf("*********** into P.1--(14.5)\n");

    for (k=0; k<yr_cnt; k++)
    {
        memset(err_buf,0,sizeof(err_buf));
        strcpy(err_buf,"update last_daily_close:");
        strcat(err_buf,"CA1");
        strcat(err_buf,",");
        strcat(err_buf,Year[k].yr);
        printf("==== k=[%d]Year[k].yr=[%s]\n",k,Year[k].yr);

        $UPDATE last_daily_close
            SET dlast_closing=$plydate,
                ivoucher=$ivoucher,
                icreator=$creator,
                dcreate=$Today
          WHERE ibill_type='CA1'
            AND iyear=$Year[k].yr;

        if (sqlca.sqlerrd[2]==0)
        {
           $INSERT INTO last_daily_close
                        (iyear,ibill_type,dlast_closing,ivoucher,
                         icreator,dcreate)
                 VALUES ($Year[k].yr,"CA1",$plydate,$ivoucher,
                         $creator,$Today);
        }
    }
    /**** STEP P.1--(15) *****************************************/
    printf("*********** into P.1--(15)\n");

    /* �Ϳ��O�N�����X */
    /* �t�X�Ϳ��ݨD,��H��J�鬰����^�����,�Gmark���q�{�� modify by sylvia 105.12.14
       (1051122004_C2) */
    /* printf("Before ca_ply_to_ks[%s][%s]\n",DBname,inf_dclose);
    rtncode = ca_ply_to_ks(DBname,inf_dclose);
    printf("====AFTER ca_ply_to_ks(): rtncode[%ld]\n",rtncode);
    if (rtncode!=M_CM_OK)
    {
       strcpy(err_buf,"�Ϳ��O�N�����X��Ʀ��~");
       if (rtncode<0) goto optP_err;
       else goto optP_err1;
    } */

ply_no_record:

    memset(err_buf,0,sizeof(err_buf));
    strcpy(err_buf,"update daily_closing_ctl:C1");

    memset(err_buf,0,sizeof(err_buf));

    $COMMIT WORK;
    FreePlyList(PlyFirst,PlyCurr);  /* free all allocated memory */

    printf("------> finish \n");
    $SET LOCK MODE TO NOT WAIT;
    return M_CM_OK;

optP_err:
    printf("------> optP_err: \n");
    printf("ca508:err_buf[%s]\n",err_buf);
    rtncode = cm_show_sql_err("ca508", "");
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    $SET LOCK MODE TO NOT WAIT;
    return rtncode;

optP_err1:
    printf("------> optP_err1: \n");
    printf("ca508:err_buf[%s] rtncode[%d]\n",err_buf,rtncode);
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    $SET LOCK MODE TO NOT WAIT;
    return rtncode;
}

/*****************************************************************/
/*****************************************************************/

int CheckSerialPolicy1(ptype1, xyear1, dplistF, dplistC, dplistL, maxp1)
$char *ptype1,*xyear1,*maxp1;
struct PLY_LIST **dplistF, **dplistC, **dplistL;
{
    $char  matchyear[10], tmp_ilast_ply[POLICY_NUM_1];
    $char  tmp_irelative_ply[POLICY_NUM_1];
    $char  tmp_tagnum[CA_TAG_NUM],tmp_body[CA_BODY_NUM],tmp_engine[CA_ENGINE_NUM],tmp_treaty[2];
    $char  tmp_assuredf[2];
    $char  tmp_assuredn[121],tmp_assureda[91],tmp_paymenta[91];
    $char  tmp_iarea[3];
    $char  tmp_icard[CARD_NUM],tmp_fcard_class[2],tmp_iofficer[11],tmp_fprint[2];
    $char  tmp_ibroker[BROKER],tmp_ibig_comp[2], tmp_icar_type[3];
    $char  tmp_ibig_office[10];
    $char  tmp_fac[2];
    $char  tmp_icorps[CORP_ID], tmp_ileader[LEADER], tmp_iquota[CA_SA_QUOTA];
    $char  tmp_icomp_in[BRANCH_ID], tmp_ibranch_in[BRANCH_ID];
    $char  tmp_assuredi[CUSTOMER_ID], tmp_assuredi_ext[CUSTOMER_EXT_ID];
    $char  tmp_iresource[2], tmp_icashier[EMPLOYEE_ID], tmp_ibig_sales[EMPLOYEE_ID];
    $char  tmp_ireg_no[21];/* 1080408005-SC1-��ã��-�j���һ{�ҷs�W�q����Ƥεn���Ҹ�  */
    $char  tmp_icar_flag[2];
    $char  tmp_transno[21];
    $char  tmp_ibenef[11], tmp_zip[CA_ZIP], tmp_ibroker_top[BROKER];/* 1090525004-SC1-�]�y��-�s���l���ϸ�3+3   ZIP_CODE 5+1->CA_ZIP 6+1*/
    $char  tmp_iapplicant[IASSURED], tmp_napplicant[101];
    $int   tmp_seqno;
    $char  tmp_nequipment[31];
    $long  tmp_dply_begin, tmp_dply_end;
    $long  tmp_qply_period;
    $long  tmp_ply_mprem, tmp_ply_magent, tmp_ply_mcommi, tmp_ply_mdisc;
    $long  tmp_dpolicy;
    $int   tmp_ibatch_no;
    $char  tmp_icomm_obj[11]; /* �q���ĤG���q */
    $int tmp_qprovision;
    /* dws9807211 �q����� from policy */
    $char  tmp_introducer[21], tmp_iroute_prop[3], tmp_iroute[21], tmp_iroute_accept[21];
    $char  iofficer_prmt[11];
    char   chk_iofficer[11];
    $char IsPorject[2];	/* �O�_���M�ץ�:Y�M�ץ� N:�D�M�ץ� add by sylvia 102.12.11 (1021122001_C1) */
    $char  tmp_icard_main[21];
    int    I,iLnum,iSnum, rc;
    char   num[CAR_SERIAL_LEN],lostpolicy[POLICY_NUM_1];
    struct PLY_LIST *plistF=*dplistF;
    struct PLY_LIST *plistL=*dplistL;
    struct PLY_LIST *plistC=*dplistC;
    char fbusiness[2], ibroker_top[11], bzfrom[3];
    $short fDpolicy,fDplyBegin,tmpCount,fCurInsErr;
    $char  iins_type_ply[INSURANCE_TYPE],tmp_iabn_type[2],nequipment_302[31],sFullName[21],stmt[1024];
    $long  mdeduct_ply, mdamage_cover_ply;
    $char dmgflag_A[2],dmgflag_B[2],dmgflag_C[2],dmgflag_D[2],dmgflag_38[2],dmgflag_39[2],
          dmgflag_302_A[2],dmgflag_302_B[2],dmgflag_302_C[2],dmgflag_302_D[2],dmgflag_302_38[2],dmgflag_302_39[2];
    char fabn[2];
    $char sPassPrint[2] = " ",s_plydate[11]=" " ; 
    $char itmp_policy_ori[21];
    $char brandi[9] , pro_year[5], chk_dpolicy_2[2],tmp_ins_type[INSURANCE_TYPE],tmp_provision[21],fChk[2];
    int  fBreak; 
    /* 1061026002-�O�v�N��88->89*/
    $char sDrateymMax[4];
    $int iMaxDrate,iPlyYmChk;
    $char pol_67[3];
    /* 1060817004 �q�lñ�p*/
    $char tmp_feply[2],tmp_aemail_eply[51],tmp_qpro_month[3],tmp_iscan_no[26];/* 1101018008-SC1-�d����-�q�lñ�ݱ��y�s������X�W��25�X*/
    $char tmp_isurvey_num[121],tmp_ibound_num[121],tmp_ixxcard[21],tmp_nassured_deputy[51],tmp_tassured_day[21];
    $char tmp_tassured_night[21],tmp_tassured_mobile[21],tmp_aassured_email[51],tmp_napplicant_deputy[51],tmp_aapplicant_zip[CA_ZIP];/* 1090525004-SC1-�]�y��-�s���l���ϸ�3+3   ZIP_CODE 5+1->CA_ZIP 6+1*/
    $char tmp_tapplicant_day[21],tmp_napplicant_relation[41],tmp_nuser[19];
    $double tmp_mequipment,tmp_qpt,tmp_qcylinder;
    /* 1061108001-SC4 */
    $char tmp_tedr_bgn[17],tmp_tedr_end[17];
    /* 1060817004_SC4_�s�W�q�lñ�p�����{�� */
    $char tmp_foccup[2],tmp_applicant_foccup[2],tmp_dbirth[11],tmp_dbirth_appl[11],tmp_tmobile_appl[21],tmp_dissue[11];
    $char tmp_tmobile_eply[21]; /*1080417001-SC1-���ά�-�s�W�q�l�O��H²�T�覡�o�e*/
    $char ipass_policy[POLICY_NUM_1];
    $char tmp_feterms[2];/*1100419003-���I�O�����QR Code�q�l��-�ȥ��O��u�q�l���ڡvfeterms*/
    $char tmp_aemail_appl[51];/*1100913004-SC1-���I�q�lñ�p�s�W�n�O�Hemail���*/
    $char tmp_ftrans_third[2];
    $WHENEVER SQLERROR GOTO chkp_err;
    tmp_mequipment = 0;
    tmp_qcylinder = 0;
    tmp_qpt = 0;
    rfmtdate(plydate, "mm/dd/yyyy", s_plydate);
    printf("----------s_plydate[%s]\n",s_plydate);
		printf(" ---- 1742 ----\n");
    sprintf_s(matchyear,sizeof matchyear,"%2s%s*", xyear1, ptype1);

    printf("----------matchyear[%s]\n",matchyear);

    /*--------   1030728 �ѵs�I����ޱ� 1030724002 _C1   -------- */
    fDplyBegin = 0 ;   fDpolicy = 0;  strcpy(fabn,"N");

    /*----------------------------------------------------------*/
    /* �M�ץ�P�_: W�g���H�g��(H�g�춷�ư�H0-H2) modify by sylvia 102.12.11 (1021122001_C1)*/
    /* 1080408005-SC1-��ã��-�j���һ{�ҷs�W�q����Ƥεn���Ҹ� ireg_no*/
    /* 1100419003-���I�O�����QR Code�q�l��-�ȥ��O��u�q�l���ڡv feterms*/
    /* �ĤT��ǿ���O ftrans_third (1110303014_SC1) */
    $DECLARE CA508_1 CURSOR FOR
      SELECT ipolicy, nvl(ilast_ply,' '), irelative_ply,
             icard, fcard_class, iofficer, nvl(ibig_office,' '), fprint,
             ibroker, ibig_comp, icar_type, iarea, icashier, dpolicy,
             dply_begin, dply_end, qply_period,
             itreaty, ibatch_no, iresource,
             icomp_in, ibranch_in, icorps, iquota, nvl(ibig_sales,' '), nvl(ireg_no,' '), 
             ileader, (mdmg_prem+mlia_prem), (mdmg_agent+mlia_agent),
             (mdmg_commi+mlia_commi), (mdmg_discount+mlia_discount),
             itmp_policy, ipay_way, icar_flag, transno, seqno, iofficer_prmt,
             icomm_obj, qprovision,icard_main,
             CASE WHEN iofficer[1,1] = 'W' THEN 'Y'
                  WHEN iofficer[1,1] = 'H' AND iofficer[2,2] not in ('0','1','2') THEN 'Y'
                  WHEN iofficer[1,1] = 'N' THEN 'Y'
                  ELSE 'N' END ,
		     CASE WHEN ((dply_begin >= '08/15/2015') AND (dply_begin <= '11/15/2015')) THEN 1 ELSE 0 END,
		     CASE WHEN ((dpolicy >= '08/15/2015') AND (dpolicy <= '11/15/2014')) THEN 1
		          WHEN ( dpolicy >= '11/16/2015') THEN 2
		          ELSE 0 END,
		     CASE WHEN dpolicy >= '09/16/2017' THEN 'Y' ELSE 'N' END as chk_dpolicy_2,
		     ibrand, ipro_year ,
             CASE WHEN year(dply_begin)=2017 AND today > '01/08/2018' THEN 1 
                  WHEN year(dply_begin)=2018 AND today > '12/31/2017' THEN 2
             ELSE 0 END,
             iscan_no,feply,feterms,aemail_eply,tmobile_eply,ipolicy[6,7],
             dtply_begin,dtply_end,ftrans_third
        FROM ply_relation
       WHERE dpolicy=$plydate
         AND dply_close IS NULL
         AND ipolicy[4,20] MATCHES $matchyear
       ORDER BY ipolicy;

    $OPEN CA508_1;

    while (1)
    {
        $FETCH CA508_1 INTO $maxp1, $tmp_ilast_ply, $tmp_irelative_ply,
                            $tmp_icard,$tmp_fcard_class,
                            $tmp_iofficer, $tmp_ibig_office, $tmp_fprint,
                            $tmp_ibroker, $tmp_ibig_comp, $tmp_icar_type, $tmp_iarea,
                            $tmp_icashier, $tmp_dpolicy,
                            $tmp_dply_begin,$tmp_dply_end, $tmp_qply_period,
                            $tmp_treaty, $tmp_ibatch_no, $tmp_iresource,
                            $tmp_icomp_in, $tmp_ibranch_in, $tmp_icorps,
                            $tmp_iquota, $tmp_ibig_sales, $tmp_ireg_no,
                            $tmp_ileader, $tmp_ply_mprem,
                            $tmp_ply_magent, $tmp_ply_mcommi, $tmp_ply_mdisc,
                            $tmp_Ciest, $tmp_Cipay, $tmp_icar_flag,
                            $tmp_transno,$tmp_seqno, $iofficer_prmt,
                            $tmp_icomm_obj, $tmp_qprovision, $tmp_icard_main, $IsPorject,$fDplyBegin, $fDpolicy,
                            $chk_dpolicy_2 , $brandi , $pro_year,$iPlyYmChk,
                            $tmp_iscan_no, $tmp_feply,$tmp_feterms,$tmp_aemail_eply,$tmp_tmobile_eply,$pol_67,
                            $tmp_tedr_bgn,$tmp_tedr_end,$tmp_ftrans_third;

                            
        if (SQLCODE==SQLNOTFOUND) break;
        
        strcpy(ipass_policy,trim(maxp1));
        

	/* ��HIsPorject�P�_�O�_���M�ץ� modify by sylvia 102.12.11 (1021122001_C1) */
        /* if( tmp_iofficer[0] != 'W') */
        if (strcmp(IsPorject,"N") == 0)
        {
            if (strcmp(ipass_policy,"22507V9010855")==0 || strcmp(ipass_policy,"22507V9010856")==0 || strcmp(ipass_policy,"22507V9010857")==0 || strcmp(ipass_policy,"22507V9010858")==0)
	    {
	        printf("--1070807012_SC1_���N�I�O��w���O���]�޲z�H��¾�L�k�L����D�B�z \n");
	    }
	    else
	    {
	        /* �t�X�q���ĤG���q,��H�@��function�ˮ� */
	        /* rc = chk_iofficer_expire( tmp_iofficer, v_sMsg); */
	        rc = cm_chk_policy("1", tmp_iofficer, " ", " ", " ", " ", " ", " ");
	        if( rc != M_CM_OK)
	        {
	            strcpy(v_sMsg, cm_get_errmsg(rc));
	                
	            sprintf_s( sErrMsg, sizeof sErrMsg, "�O�渹[%s]���鵲, �]���G%s", maxp1, v_sMsg);
	            WRITELOG( sfp, sErrMsg);
	            GetMsg(maxp1,v_sMsg);
	
	            if (tmp_fcard_class[0] == '2') continue;
	        }
	    }
        }

        /* �t�X�q���ĤG���q,��H�@��function�ˮ� */
        /* rc = chk_iquota_expire( tmp_iquota, v_sMsg); */
        rc = cm_chk_policy("2", " ", " ", tmp_iquota, " ", " ", " ", " ");
        if( rc != M_CM_OK)
        {
            printf("ipolicy=[%s]tmp_iquota=[%s]\n",maxp1,tmp_iquota);
            strcpy(v_sMsg, cm_get_errmsg(rc));
            
            sprintf_s( sErrMsg, sizeof sErrMsg, "�O�渹[%s]���鵲, �]���G%s", maxp1, v_sMsg);
            WRITELOG( sfp, sErrMsg);
            GetMsg(maxp1,v_sMsg);
                
            if (tmp_fcard_class[0] == '2') continue;
        }


		
	if (strcmp(ipass_policy,"22507V9010855")==0 || strcmp(ipass_policy,"22507V9010856")==0 || strcmp(ipass_policy,"22507V9010857")==0 || strcmp(ipass_policy,"22507V9010858")==0)
        {
            printf("--1070807012_SC1_���N�I�O��w���O���]�޲z�H��¾�L�k�L����D�B�z \n");
        }
        else
        {
	    /* �I����H�O�_����X�� */
	    rc = cm_chk_policy("4", " ", " ", " ", tmp_icomm_obj, " ", " ", " ");
	    if( rc != M_CM_OK)
	    {
	        strcpy(v_sMsg, cm_get_errmsg(rc));
	
	    	sprintf_s( sErrMsg, sizeof sErrMsg, "�O�渹[%s]���鵲, �]���G%s", maxp1, v_sMsg);
	    	WRITELOG( sfp, sErrMsg);
	    	GetMsg(maxp1,v_sMsg);
	    			
	    	if (tmp_fcard_class[0] == '2') continue;
	
	    }
	}

	if (strcmp(ipass_policy,"22507V9010855")==0 || strcmp(ipass_policy,"22507V9010856")==0 || strcmp(ipass_policy,"22507V9010857")==0 || strcmp(ipass_policy,"22507V9010858")==0)
        {
            printf("--1070807012_SC1_���N�I�O��w���O���]�޲z�H��¾�L�k�L����D�B�z \n");
        }
        else
        {
	    /* �I����H���L�X���� */
	    rc = cm_chk_policy("6", " ", " ", " ", tmp_icomm_obj, "C", " ", " ");
	    if( rc != M_CM_OK)
	    {
	        strcpy(v_sMsg, cm_get_errmsg(rc));
	
	    	sprintf_s( sErrMsg, sizeof sErrMsg, "�O�渹[%s]���鵲, �]���G%s", maxp1, v_sMsg);
	    	WRITELOG( sfp, sErrMsg);
	    	GetMsg(maxp1,v_sMsg);
	    			
	    	if (tmp_fcard_class[0] == '2') continue;
	
	    }
	}

        /* �I����H��10000,������ add by sylvia 100.06.22 */
        if((strcmp(trim(tmp_icomm_obj),"10000") == 0)  && (tmp_ply_mcommi > 0))
        {

    	    sprintf_s( sErrMsg, sizeof sErrMsg, "�O�渹[%s]���鵲, �]���G%s", maxp1, "���I���~�Ȥ��i�H������");
    	    WRITELOG( sfp, sErrMsg);
    	    strcpy(v_sMsg,"���I���~�Ȥ��i�H������");
    	    GetMsg(maxp1,v_sMsg);
    			
    	    if (tmp_fcard_class[0] == '2') continue;

        }
         
        /*  1041013003_C1_car320.car301.car401��������(F)��J�ި�             */ 
        strcpy(sPassPrint," ");
        rfmtdate(plydate,"mm/dd/yyyy",s_plydate);
    	rc = check_ca_id_officer(maxp1,s_plydate,sPassPrint,v_sMsg);
	if( rc != M_CM_OK || sPassPrint[0] != 'Y' )
	{             
             strcpy(v_sMsg, trim(cm_get_errmsg(rc)));

             sprintf_s( sErrMsg, sizeof sErrMsg ,"�O�渹[%s]���鵲, �]���G[%s]", maxp1, v_sMsg);
             WRITELOG( sfp, sErrMsg);
             GetMsg(maxp1,v_sMsg);
             		
	     if (tmp_fcard_class[0] == '2') continue;
	}
		    
        $SELECT nassured,aassured,apayment,nvl(itag,' '),ibody,
                iengine,ffac, iassured, iassured_ext,
                fassured, nequipment, nvl(ibenef, ' '), nvl(aassured_zip, ' '),
                iapplicant, napplicant, nvl(introducer, ' '), iroute_prop, iroute, iroute_accept,nvl(iabn_type,' '),
                survey_num,bound_num,ixxcard,ndeputy_assured,
                itel,itel_night,mobil_phone,iemail,
                ndeputy_appl,apayment_zip,itel_appl,
                nrelation_appl,qpro_month,qcylinder,qpt,mequipment,
				foccup,applicant_foccup,dbirth,dbirth_appl,tmobile_appl,dissue,aemail_appl
           INTO $tmp_assuredn, $tmp_assureda, $tmp_paymenta,
                $tmp_tagnum, $tmp_body, $tmp_engine, $tmp_fac,
                $tmp_assuredi, $tmp_assuredi_ext, $tmp_assuredf,
                $tmp_nequipment, $tmp_ibenef, $tmp_zip,
                $tmp_iapplicant, $tmp_napplicant, $tmp_introducer,
                $tmp_iroute_prop, $tmp_iroute, $tmp_iroute_accept, $tmp_iabn_type,
                $tmp_isurvey_num,$tmp_ibound_num,
                $tmp_ixxcard,$tmp_nassured_deputy,
                $tmp_tassured_day,$tmp_tassured_night,$tmp_tassured_mobile,$tmp_aassured_email,
                $tmp_napplicant_deputy,$tmp_aapplicant_zip,$tmp_tapplicant_day,
                $tmp_napplicant_relation,$tmp_qpro_month,$tmp_qcylinder,$tmp_qpt,$tmp_mequipment,
                $tmp_foccup,$tmp_applicant_foccup,$tmp_dbirth,$tmp_dbirth_appl,$tmp_tmobile_appl,$tmp_dissue,$tmp_aemail_appl
           FROM policy
          WHERE ipolicy=$maxp1;


        /* 1060824008_C1 �ק�ӫ~����X���ˮ֧@�~ */
        /* J���ڰӫ~��09/16/2017�_(�t) ���i�J��/�L��/�鵲  */        
	     	    
    	if (tmp_fcard_class[0] == '2')
    	{ 	
    	    strcpy(tmp_ins_type , " "); strcpy(tmp_provision , " "); strcpy(fChk , " ");
    	    fBreak = 0 ; 
	    $DECLARE cur_ins CURSOR FOR
	     SELECT a.iins_type, a.provision , 
	            case WHEN b.dexpire IS NULL OR b.dexpire > $plydate THEN '0' ELSE '1' END
	       FROM ply_ins_type a , insurance_type b
	      WHERE a.ipolicy   = $maxp1
	        AND a.iins_type = b.iins_type ;	             
	    $OPEN cur_ins;
	    for(;;)
	    {
	        $FETCH cur_ins INTO $tmp_ins_type , $tmp_provision , $fChk;
		if(SQLCODE == SQLNOTFOUND) break;
		        
	        if (fChk[0] == '1')
	        {
	            fBreak = 1 ;
                    sprintf_s( sErrMsg, sizeof sErrMsg, "�O�渹[%s]���鵲, �]���G%s �I�ؤw����", maxp1, trim(tmp_ins_type));
	            break;
	        }	

	    }                  
	    $CLOSE  cur_ins;
	    $FREE   cur_ins;
            printf("-- trace maxp1[%s] \n ",maxp1);
            printf("-- trace fBreak[%d] \n ",fBreak);
	    if (fBreak == 1) 
	    {
                WRITELOG( sfp, sErrMsg);	
                GetMsg(maxp1,v_sMsg);	        		
	        continue;
	    }	

            
            /* 1061026002-�O�v�ܧ�88->89  �@�ߤ�����(iabn_type=''S") 
              2018/01/10  VW ��Y�X��A������
            */
            strcpy(sDrateymMax,"");
            $SELECT max(a.drate_ym) INTO $sDrateymMax
               FROM ply_ins_type a 
               WHERE a.ipolicy   = $maxp1;
            iMaxDrate = atoi(sDrateymMax);
            if ((iPlyYmChk==1) || (iPlyYmChk==2))
            {   /* 2018/01/10  �O�T�I(VW)�q�ʦۦ樮(EB) �~�Ȥ�����87.88�O�v(���`���OY��)  */
                if ((tmp_iabn_type[0] !='S') && (tmp_iabn_type[0] !='Y') && (strcmp(pol_67,"EB") != 0))
                {

                    printf("�O�v�ܧ�[%s][%d]iPlyYmChk[%d]",sDrateymMax,iMaxDrate,iPlyYmChk);
                
                    strcpy(sErrMsg,"");
                    if(iMaxDrate<=87)
                    {
                        sprintf_s(sErrMsg, sizeof sErrMsg, "�O�渹[%s]-�O�v[%s]��87�Añ��I��鬰1070108", maxp1,sDrateymMax);
                        strcpy(v_sMsg,"2017�ͮīO��A�O�v��87�Añ��I��鬰1070108");
                        WRITELOG( sfp, sErrMsg);
                        GetMsg(maxp1,v_sMsg);
                        continue;
                    }
                    else if(iMaxDrate==88)
                    {
                        sprintf_s(sErrMsg, sizeof sErrMsg, "�O�渹[%s]-�O�v[%s]=88�Añ��I��鬰1061231", maxp1,sDrateymMax);
                        strcpy(v_sMsg,"2018�ͮīO��A�O�v88�Añ��I���1061231");
                        WRITELOG( sfp, sErrMsg);
                        GetMsg(maxp1,v_sMsg);
                        continue;
                    } 
                }
            }
            
            if((strcmp(tmp_icar_type,"14")==0)||(strcmp(tmp_icar_type,"2A")==0))
            {   /* '1070123004-SC1-14+2A���ئ�1/24�_�u�����92�O�v or �O�v�ȯ�H�󥿳�β��`��X��(iabn_type=''S")�}�� */
                if (iMaxDrate < 92  && (tmp_iabn_type[0] !='S') && (tmp_iabn_type[0] !='Y') && (strcmp(pol_67,"EB") != 0))
                {
                    sprintf_s(sErrMsg, sizeof sErrMsg, "�O�渹[%s]�O�v�N�� [%s]< 92�A14.2A���ح��ζO�v92(�t)�H��", maxp1,sDrateymMax);
                    strcpy(v_sMsg,"14.2A���ح��ζO�v92(�t)�H��");
                    WRITELOG( sfp, sErrMsg);
                    GetMsg(maxp1,v_sMsg);
                    continue;
                }
            }
	} 
  
        
        /*--------   104.07.30 �����I����ޱ�   -------- */
        /*
	   �]�@�^����϶�:  8/15 �� ñ��� �� 11/14 ��
                        11/15�� ñ��� �B  8/15�إͮĤ��11/14

	   �]�G�^���ŦX�u��O��v����̡A���i�鵲

	      �� ���`��(S��Y) ���ˮ֬O�_�ŦX�u��O��v����

		  ���u��O��v����:
		      1.�L�ӫO�u�����I�v�̡C(���צ��L�u��O�渹�v)
		      2.���ӫO�u�����I�v�̡A�@�߭n�i��H�U�ˮ�((1)~(5)�ҭn�ŦX )�G
		    	(1)���a�X/��J�����q���u��O�渹�v�B�s�b��O�ɤ�
				(2)�u�������v���P��O��Ҹ��������ۦP
				(3)�u�Q�O�I�HID�v���P��O��Ҹ��Q�O�I�HID�ۦP
				(4)�u�ͮĤ���v���P��O��Ҹ��ͮĤ���ۦP
				(5) �ӫO�����I�I�ؤ��i�X�j�ӫO

				���G�u�����I��O�����v���]�t�H�U�����ܰʡA�G���ި�G
				  (1)�����I�ۭt�B�ܰ�
				  (2)�����I���[�I�ܰ�(�t38.39.16���D�I)
				  (3)���[�����ܰ�
				  (4)�������l�O�B
				  (5)�����I�O�B�P��O�����Y
        */

        if ( (fDpolicy==1) || ((fDpolicy==2)&&(fDplyBegin==1)) )
        {
	
	    if ( (tmp_iabn_type[0]=='S') || (tmp_iabn_type[0]=='Y'))
	    {
	        strcpy(fabn,"Y");
	    }

	    strcpy(tmp_ilast_ply , trim(tmp_ilast_ply));
	    printf("-- trace tmp_ilast_ply[%s]\n ",tmp_ilast_ply);

	    strcpy(dmgflag_A , " "); strcpy(dmgflag_B , " ");
	    strcpy(dmgflag_C , "N"); strcpy(dmgflag_D , "N"); strcpy(dmgflag_38 , "N"); strcpy(dmgflag_39 , "N");
	    $SELECT max(CASE WHEN iins_type IN ('09','98','126') THEN 'A'
			WHEN iins_type IN ('120')           THEN 'B'
			WHEN iins_type IN ('85')            THEN 'C'
			WHEN iins_type IN ('05','125')      THEN 'D'
			WHEN iins_type IN ('105')           THEN 'E'
			WHEN iins_type IN ('118')           THEN 'F'
			WHEN iins_type IN ('01')            THEN 'G'
			WHEN iins_type IN ('122')           THEN 'H'
			else ' ' END) AS dmgflag_A,
		    max(CASE WHEN iins_type IN ('15')            THEN 'A'
			WHEN iins_type IN ('67')            THEN 'B'
			WHEN iins_type IN ('106')           THEN 'C'
			WHEN iins_type IN ('66')            THEN 'D'
			else ' ' END) AS dmgflag_B,
		    max(CASE WHEN iins_type IN ('04','06','18','23','75','81','83','86','110') THEN 'Y' ELSE 'N' END) AS dmgflag_C,
		    max(CASE WHEN iins_type IN ('02','03','07','10','61','62','63','64','65','69','107','108','119','121','123','127') THEN 'Y' ELSE 'N' END) AS dmgflag_D,
		    max(CASE WHEN iins_type IN ('38') THEN 'Y' ELSE 'N' END) AS dmgflag_38,
		    max(CASE WHEN iins_type IN ('39') THEN 'Y' ELSE 'N' END) AS dmgflag_39
	       INTO $dmgflag_A ,$dmgflag_B ,$dmgflag_C ,$dmgflag_D ,$dmgflag_38 ,$dmgflag_39
	       FROM ply_ins_type
	      WHERE ipolicy = $maxp1 ;
	      
	    printf("-- trace dmgflag_A[%s] ,dmgflag_B [%s]\n ",dmgflag_A ,dmgflag_B);
	    printf("-- trace dmgflag_C[%s] ,dmgflag_D [%s]\n ",dmgflag_C ,dmgflag_D);
	    printf("-- trace dmgflag_38[%s],dmgflag_39[%s]\n ",dmgflag_38,dmgflag_39);

	    /* �S���ӫO�����I */
	    if ((dmgflag_A[0]==' ')&&(dmgflag_B[0]==' ')&&(dmgflag_C[0]=='N')&&(dmgflag_D[0]=='N')&&(dmgflag_38[0]=='N')&&(dmgflag_39[0]=='N'))
	    {
	        /* �ŦX�u�����I��O��v����*/
	    }
	    else/* ���ӫO�����I */
	    {
	        if (strlen(tmp_ilast_ply)==0)
		{   /* �S���e�O�渹 */
	            if (fabn[0]=='N')
	            {
		        sprintf_s( sErrMsg, sizeof sErrMsg, "�O�渹[%s]���鵲, �]���G%s", maxp1, "���ӫO�����I�A���L��O�渹");
			WRITELOG( sfp, sErrMsg);
			continue;
		    }
		}
		else
		{   /*  ���e�O�渹 */
		    /*  �����O�D�ɡG�Q�O�I�HID�B�������B�ͮĤ� */
		    strcpy(tmp_assuredi  , trim(tmp_assuredi));
		    strcpy(tmp_engine   , rtrim(tmp_engine)); /* ���������i��t�ť� */
		    printf("-- trace tmp_assuredi  [%s]\n ",tmp_assuredi);
		    printf("-- trace tmp_engine    [%s]\n ",tmp_engine);
		    printf("-- trace tmp_dply_begin[%s]\n ",tmp_dply_begin);

		    tmpCount = 0;
		    $select count(*) into $tmpCount
		       from policy_302
		      where ipolicy     = $tmp_ilast_ply
			and ilicense    = $tmp_assuredi
			and iengine     = $tmp_engine;
			/*and dply_begin >= $tmp_dply_begin; */

		    if (tmpCount==0) /* �S����O��� �� �Q�O�I�HID�B�������B�ͮĤ� ���@���ŦX */
		    {
		        if (fabn[0]=='N')
		        {
			    sprintf_s( sErrMsg, sizeof sErrMsg, "�O�渹[%s]���鵲, �]���G���ӫO�����I����O�ɧ䤣�즹��O�渹[%s]�A�γQ�O�I�HID�B�������P��O�椣�P�ΥͮĤ�ߩ���O��Ҹ�", maxp1, tmp_ilast_ply);
			    WRITELOG( sfp, sErrMsg);
			    continue;
			}
		    }
		    else /* ����O��� �B �Q�O�I�HID�B�������ҲŦX */
		    {
		        /*1040828005_C1 �Y�ϲ��`��A�_�O�������\�鵲 */
			tmpCount = 0;
			$select count(*) into $tmpCount
			   from policy_302
			  where ipolicy     = $tmp_ilast_ply
			    and dply_begin >= $tmp_dply_begin;
			if (tmpCount==0) 
			{
			    sprintf_s( sErrMsg, sizeof sErrMsg, "�O�渹[%s]���鵲, �]���G���ӫO�����I���ͮĤ�ߩ���O��[%s]�Ҹ��ͮĤ�", maxp1, tmp_ilast_ply);
			    WRITELOG( sfp, sErrMsg);
			    continue;
			}
		    }

	            /* 1040828005_C1 ���_�O�~�A��l���p�u���`��v���ˮ� */
	            if (fabn[0]=='N')
		    {
		        /* �P�_�O�_�X�j�ӫO�d�� => �����O������ */
		        strcpy(dmgflag_302_A , " "); strcpy(dmgflag_302_B , " ");
		        strcpy(dmgflag_302_C , "N"); strcpy(dmgflag_302_D , "N");strcpy(dmgflag_302_38 , "N");strcpy(dmgflag_302_39 , "N");
			$select max(CASE WHEN iins_type IN ('09','98','126') THEN 'A'
				    WHEN iins_type IN ('120')           THEN 'B'
				    WHEN iins_type IN ('85')            THEN 'C'
				    WHEN iins_type IN ('05','125')      THEN 'D'
				    WHEN iins_type IN ('105')           THEN 'E'
				    WHEN iins_type IN ('118')           THEN 'F'
				    WHEN iins_type IN ('01')            THEN 'G'
				    WHEN iins_type IN ('122')           THEN 'H'
				    ELSE ' ' END) AS dmgflag_302_A,
				max(CASE WHEN iins_type IN ('15')            THEN 'A'
				    WHEN iins_type IN ('67')            THEN 'B'
				    WHEN iins_type IN ('106')           THEN 'C'
				    WHEN iins_type IN ('66')            THEN 'D'
				    ELSE ' ' END) AS dmgflag_302_B,
				max(CASE WHEN iins_type IN ('04','06','18','23','75','81','83','86','110') THEN 'Y' ELSE 'N' END) AS dmgflag_302_C,
				max(CASE WHEN iins_type IN ('02','03','07','10','61','62','63','64','65','69','107','108','119','121','123','127') THEN 'Y' ELSE 'N' END) AS dmgflag_302_D,
				max(CASE WHEN iins_type IN ('38') THEN 'Y' ELSE 'N' END) AS dmgflag_302_38,
				max(CASE WHEN iins_type IN ('39') THEN 'Y' ELSE 'N' END) AS dmgflag_302_39
			  INTO $dmgflag_302_A ,$dmgflag_302_B ,$dmgflag_302_C ,$dmgflag_302_D ,$dmgflag_302_38, $dmgflag_302_39
			  from ply_ins_type_302
			 where ipolicy = $tmp_ilast_ply
			   and ori_premium >0 ;
			   
		  	printf("-- trace dmgflag_302_A [%s],dmgflag_302_B [%s]\n ",dmgflag_302_A ,dmgflag_302_B);
		  	printf("-- trace dmgflag_302_C [%s],dmgflag_302_D [%s]\n ",dmgflag_302_C ,dmgflag_302_D);
		  	printf("-- trace dmgflag_302_38[%s],dmgflag_302_39[%s]\n ",dmgflag_302_38,dmgflag_302_39);

		  	/* ��O�ɵL��� �� �S���������I */
		  	if ((dmgflag_302_A[0]==' ')&&(dmgflag_302_B[0]==' ')&&(dmgflag_302_C[0]=='N')&&(dmgflag_302_D[0]=='N')&&(dmgflag_302_38[0]=='N')&&(dmgflag_302_39[0]=='N'))
		  	{
			    sprintf_s( sErrMsg, sizeof sErrMsg, "�O�渹[%s]���鵲, �]���G���ӫO�����I�A����O��[%s]�u���O�զX�v�L����������I��", maxp1, tmp_ilast_ply);
			    WRITELOG( sfp, sErrMsg);
			    continue;
		  	}
		  	else /* ��O�ɡu���O�զX�v�������I */
		  	{
			    if (dmgflag_A[0]> dmgflag_302_A[0]) /* ����D�I�u�X�j�ӫO�d��v */
			    {
			        if (dmgflag_302_A[0]==' ')
				{
				    sprintf_s( sErrMsg, sizeof sErrMsg, "�O�渹[%s]���鵲, �]���G�ӫO������D�I���s�b��O��[%s]�u���O�զX�v��", maxp1, tmp_ilast_ply);
				}
				else
				{
				    sprintf_s( sErrMsg, sizeof sErrMsg, "�O�渹[%s]���鵲, �]���G[�X�j�ӫO�d��]�ӫO������D�I�P��O��[%s]�u���O�զX�v���P", maxp1, tmp_ilast_ply);
				}
				WRITELOG( sfp, sErrMsg);
				continue;
			    }
			    else if (dmgflag_A[0]==' ')
			    {
			        if (dmgflag_39[0]=='Y' &&  dmgflag_302_39[0]=='N')
			        {
			            if (dmgflag_38[0]=='Y')
			            {
			                sprintf_s( sErrMsg, sizeof sErrMsg, "�O�渹[%s]���鵲, �]���G[�X�j�ӫO�d��]�ӫO���D���ϴ��D�I(39)���s�b��O��[%s]�u���O�զX�v���]�Ȧ�38�I�ء^", maxp1, tmp_ilast_ply);
			            }
			            else
			            {
			                sprintf_s( sErrMsg, sizeof sErrMsg, "�O�渹[%s]���鵲, �]���G�ӫO���D���ϴ��D�I(39)���s�b��O��[%s]�u���O�զX�v��", maxp1, tmp_ilast_ply);
			            }
				    WRITELOG( sfp, sErrMsg);
				    continue;
			        }
			        
			        if (dmgflag_38[0]=='Y' && (dmgflag_302_38[0]=='N' && dmgflag_302_39[0]=='N'))   /* �D���ϴ��]�D�I�ʽ�^�u�X�j�ӫO�d��v */
			        {
				    sprintf_s( sErrMsg, sizeof sErrMsg, "�O�渹[%s]���鵲, �]���G�ӫO���D���ϴ��D�I(38)���s�b��O��[%s]�u���O�զX�v��(�L38�B39�I��)", maxp1, tmp_ilast_ply);
				    WRITELOG( sfp, sErrMsg);
				    continue;
			        }
			        
			        if(dmgflag_B[0] > dmgflag_302_B[0] )                                             /* �N�B��  �]�D�I�ʽ�^�u�X�j�ӫO�d��v */
			        {

				    if (dmgflag_302_B[0]==' ')
				    {
				        sprintf_s( sErrMsg, sizeof sErrMsg, "�O�渹[%s]���鵲, �]���G�ӫO������N�B���D�I���s�b��O��[%s]�u���O�զX�v��", maxp1, tmp_ilast_ply);
				    }
				    else
				    {
				        sprintf_s( sErrMsg, sizeof sErrMsg, "�O�渹[%s]���鵲, �]���G[�X�j�ӫO�d��]�ӫO������D�I�P��O��[%s]�u���O�զX�v���P", maxp1, tmp_ilast_ply);
				    }
				    WRITELOG( sfp, sErrMsg);
				    continue;
			        }
			    }
			    else if (dmgflag_C[0]=='Y')         /* ��L����D�I���: �ӫO�I�إ����s�b����O��u���O�զX�v�� */
			    {
			        if (dmgflag_302_C[0]=='Y')
			        {
			            tmpCount = 0;
			            $SELECT count(*) Into $tmpCount
			               FROM ply_ins_type a ,ply_ins_type_302 b
			              WHERE a.ipolicy   = $maxp1
			        	and b.ipolicy   = $tmp_ilast_ply
			        	and a.iins_type = b.iins_type
			        	and b.ori_premium >0
			        	and a.iins_type IN ('04','06','18','23','75','81','83','86','110');

			            if (tmpCount==0)
			            {
			                sprintf_s( sErrMsg, sizeof sErrMsg, "�O�渹[%s]���鵲, �]���G�ӫO����������D�I��(04,06,18,23,75,81,83,86,110)���s�b��O��[%s]�u���O�զX�v��", maxp1, tmp_ilast_ply);
					WRITELOG( sfp, sErrMsg);
					continue;
			            }
			        }
			        else
			        {
		        	    sprintf_s( sErrMsg, sizeof sErrMsg, "�O�渹[%s]���鵲, �]���G�ӫO����������D�I��(04,06,18,23,75,81,83,86,110)���s�b��O��[%s]�u���O�զX�v��", maxp1, tmp_ilast_ply);
				    WRITELOG( sfp, sErrMsg);
				    continue;
			        }
			    }
		        }
		    }
		}
	    }
        }

	/*************************************************************/    


       �@/* bis9901141 Check the Accuracy of iroute */
         /* W�}�Y���g��N���ݭn�Φ^�k�᪺�h�P�_�q�� */
         /* ��HIsPorject�P�_�O�_���M�ץ� modify by sylvia 102.12.11 (1021122001_C1) */
         /*if( tmp_iofficer[0] == 'W')         */
         if (strcmp(IsPorject,"Y") == 0)
         	strcpy(chk_iofficer,trim(iofficer_prmt));
         else
         	strcpy(chk_iofficer,trim(tmp_iofficer));

         strcpy(tmp_iroute,trim(tmp_iroute));
         if (strlen(trim(tmp_introducer)) > 0) strcpy(tmp_introducer,trim(tmp_introducer));
         if (strlen(trim(tmp_iroute_prop)) > 0) strcpy(tmp_iroute_prop,trim(tmp_iroute_prop));
         if (strlen(trim(tmp_iroute_accept)) > 0) strcpy(tmp_iroute_accept,trim(tmp_iroute_accept));

         rc = cm_check_route_sales("A",chk_iofficer,tmp_iroute,"C",tmp_ibig_sales,tmp_introducer,tmp_iroute_prop,tmp_iroute_accept,v_sMsg);
         if (rc != TRUE)
         {
              printf("err_msg[%s]\n",v_sMsg);

              sprintf_s( sErrMsg, sizeof sErrMsg, "�O�渹[%s]���鵲, �]���G%s", maxp1, v_sMsg);
              WRITELOG( sfp, sErrMsg);
              GetMsg(maxp1,v_sMsg);
              	
              if (tmp_fcard_class[0] == '2') continue;
         }
         /* end of bis9901141 */
         printf("after introducer[%s]\n", chk_iofficer);


        /* �q���N���P�q���ۭq�~�ȥN���������Y�O�_���T */
        rc = cm_chk_policy("7", " ", " ", " ", " ", " ", tmp_iroute, tmp_iroute_prop);
        if( rc != M_CM_OK)
        {
            strcpy(v_sMsg, cm_get_errmsg(rc));
            
            sprintf_s( sErrMsg, sizeof sErrMsg, "�O�渹[%s]���鵲, �]���G[%s]", maxp1, v_sMsg);
            WRITELOG( sfp, sErrMsg);
            GetMsg(maxp1,v_sMsg);
            	
            if (tmp_fcard_class[0] == '2') continue;
        }

        /* �������J�p�s�� */
        rc = cm_get_broker_top(tmp_icomm_obj,tmp_ibroker_top);
        if (rc != M_CM_OK)
        {
            strcpy(v_sMsg, cm_get_errmsg(rc));
          
            sprintf_s( sErrMsg, sizeof sErrMsg, "�O�渹[%s]���鵲, �]���G[%s]", maxp1, v_sMsg);
            WRITELOG( sfp, sErrMsg);
            GetMsg(maxp1,v_sMsg);
            	
            if (tmp_fcard_class[0] == '2') continue;
        }
        printf("tmp_Ciest[%s]\n", tmp_Ciest); 
        strcpy(itmp_policy_ori, tmp_Ciest); /* �O�d�쥻��itmp_policy */
        puts("111");

        /* ��O�O�_��������O�� */
        if (strncmp(tmp_Ciest,"YJ",2) == 0)
        {
           $UPDATE ot_estimate
               SET current_status = 240
             WHERE iestimate = $tmp_Ciest;
        }

        if (strncmp(tmp_Ciest,"17N",3) != 0)
        {
            strcpy(tmp_Cipay,"2");
            strcpy(tmp_Ciest," ");
        }
        else
        {
            strcpy(tmp_Ciest,trim(tmp_Ciest));
            if (tmp_fcard_class[0] == '1')
               strcat(tmp_Ciest,"-1");
            else
               strcat(tmp_Ciest,"-2");

            if (tmp_Cipay[0] == '1')
               strcpy(tmp_Cipay,"A");
            else if (tmp_Cipay[0] == '2')
               strcpy(tmp_Cipay,"B");
            else if (tmp_Cipay[0] == '3')
               strcpy(tmp_Cipay,"C");
            else if (tmp_Cipay[0] == '4')
               strcpy(tmp_Cipay,"D");
        }

        if (tmp_fprint[0]=='0' && tmp_fcard_class[0]=='2')
        {
            memset(err_buf,0,sizeof(err_buf));
            strcpy(err_buf,"�O�楼�C�L:");
            strcat(err_buf,maxp1);
            return M_CA_NPRINT_PLY;
        }

        *dplistC=(struct PLY_LIST *)malloc(sizeof(struct PLY_LIST));
        if (*dplistC==NULL)
        {
            printf("malloc fail in struct PLY_LIST allocation!\n");
            memset(err_buf,0,sizeof(err_buf));
            strcpy(err_buf,"malloc fail in struct PLY_LIST allocation");
            $CLOSE CA508_1;
            return M_CM_NOT_MALLOC;
        }

        /*** use a link list ***/
        if (*dplistF==NULL)
        {
            *dplistF=*dplistL=*dplistC;
        }
        else
        {
            (*dplistL)->next=*dplistC;
            *dplistL = *dplistC;
        }

        plistC = *dplistC;
        strcpy(plistC->ipolicy,         maxp1);
        strcpy(plistC->ilast_ply,       tmp_ilast_ply);
        strcpy(plistC->irelative_ply,   tmp_irelative_ply);
        strcpy(plistC->assuredf,        tmp_assuredf);
        strcpy(plistC->assuredi,        tmp_assuredi);
        strcpy(plistC->assuredi_ext,    tmp_assuredi_ext);
        strcpy(plistC->assuredn,        tmp_assuredn);
        strcpy(plistC->assureda,        tmp_assureda);
        strcpy(plistC->paymenta,        tmp_paymenta);
        strcpy(plistC->tagnum,          tmp_tagnum);
        strcpy(plistC->body,            tmp_body);
        strcpy(plistC->engine,          tmp_engine);
        strcpy(plistC->treaty,          tmp_treaty);
        strcpy(plistC->icard,           tmp_icard);
        strcpy(plistC->fcard_class,     tmp_fcard_class);
        strcpy(plistC->iofficer,        tmp_iofficer);
        strcpy(plistC->ibig_office,     tmp_ibig_office);
        strcpy(plistC->ibroker,         tmp_ibroker);
        strcpy(plistC->ibig_comp,       tmp_ibig_comp);
        strcpy(plistC->icar_type,       tmp_icar_type);
        strcpy(plistC->iarea,           tmp_iarea);
        strcpy(plistC->icashier,        tmp_icashier);
        strcpy(plistC->facf,            tmp_fac);
        strcpy(plistC->iresource,       tmp_iresource);
        strcpy(plistC->ibig_sales,      tmp_ibig_sales);
        strcpy(plistC->ireg_no,         tmp_ireg_no);/*1080408005-SC1-��ã��-�j���һ{�ҷs�W�q����Ƥεn���Ҹ�*/
        strcpy(plistC->iroute,          tmp_iroute);
        printf("bis9901141 �s�W�q���N��iroute[%s]\n",plistC->iroute);
        strcpy(plistC->icar_flag,       tmp_icar_flag);

        strcpy(plistC->icorps,          tmp_icorps);
        strcpy(plistC->ileader,         tmp_ileader);
        strcpy(plistC->iquota,          tmp_iquota);
        strcpy(plistC->icomp_in,        tmp_icomp_in);
        strcpy(plistC->ibranch_in,      tmp_ibranch_in);

        strcpy(plistC->transno,         tmp_transno);
        strcpy(plistC->nequipment,      tmp_nequipment);

        strcpy(plistC->icomm_obj,       tmp_icomm_obj);    /* �q���ĤG���q */
	plistC->qprovision      = tmp_qprovision;			/* ���w�r�p�H�� */
        plistC->seqno      = tmp_seqno;

        plistC->ibatch_no  = tmp_ibatch_no;
        plistC->dpolicy    = tmp_dpolicy;
        plistC->ply_begin  = tmp_dply_begin;
        plistC->ply_end    = tmp_dply_end;
        plistC->qply_period= tmp_qply_period;

        plistC->ply_mprem  = tmp_ply_mprem;
        plistC->ply_magent = tmp_ply_magent;
        plistC->ply_mcommi = tmp_ply_mcommi;
        plistC->ply_mdisc  = tmp_ply_mdisc;
        strcpy(plistC->itmp_policy,     tmp_Ciest);
        strcpy(plistC->ipay_way,        tmp_Cipay);
        strcpy(plistC->ibenef,          tmp_ibenef);
        strcpy(plistC->zip,             tmp_zip);
        strcpy(plistC->icard_main,      tmp_icard_main);	/* A�����p�� */

        /* �t�X�q���ĤG���q,�אּ�H�@��function������J�p�s�� */
        /* $SELECT ibroker_top
           INTO $tmp_ibroker_top
           FROM broker_agent
          WHERE ibroker = $tmp_ibroker;

        if (SQLCODE==SQLNOTFOUND)
           strcpy( tmp_ibroker_top,""); */



        strcpy(plistC->ibroker_top,   tmp_ibroker_top);
        strcpy(plistC->iapplicant,    tmp_iapplicant);
        strcpy(plistC->napplicant,    tmp_napplicant);
        strcpy(plistC->introducer,    tmp_introducer);
        strcpy(plistC->iroute_prop,   tmp_iroute_prop);
        strcpy(plistC->itmp_policy_ori,   itmp_policy_ori);

        /* 1060817004 -C1 �q�lñ�p*/
        strcpy(plistC->iscan_no, tmp_iscan_no );
        strcpy(plistC->isurvey_num, tmp_isurvey_num );
        strcpy(plistC->ibound_num,  tmp_ibound_num);
        strcpy(plistC->ixxcard,  tmp_ixxcard);
        strcpy(plistC->nassured_deputy, tmp_nassured_deputy );
        strcpy(plistC->tassured_day, tmp_tassured_day );
        strcpy(plistC->tassured_night,  tmp_tassured_night);
        strcpy(plistC->tassured_mobile, tmp_tassured_mobile );
        strcpy(plistC->aassured_email,  tmp_aassured_email);
        strcpy(plistC->napplicant_deputy,  tmp_napplicant_deputy);
        strcpy(plistC->apayment_zip, tmp_aapplicant_zip );
        strcpy(plistC->tapplicant_day, tmp_tapplicant_day );
        strcpy(plistC->napplicant_relation,  tmp_napplicant_relation);
        strcpy(plistC->nuser, tmp_nuser);
        strcpy(plistC->qpro_month,tmp_qpro_month);
        strcpy(plistC->ipro_year,pro_year);
        strcpy(plistC->ibrand,brandi);
        strcpy(plistC->dtedr_bgn,tmp_tedr_bgn); /* 1061108001-SC1 �s��*/
        strcpy(plistC->dtedr_end,tmp_tedr_end);
        
        plistC->qcylinder  = tmp_qcylinder;
        plistC->qpt  = tmp_qpt;
        plistC->mequipment  = tmp_mequipment;
        strcpy(plistC->feply,tmp_feply);
        strcpy(plistC->feterms,tmp_feterms);    /*1100419003-���I�O�����QR Code�q�l��-�ȥ��O��u�q�l���ڡvfeterms*/
        strcpy(plistC->aemail_eply,tmp_aemail_eply);
        strcpy(plistC->tmobile_eply,tmp_tmobile_eply); /*1080417001-SC1-���ά�-�s�W�q�l�O��H²�T�覡�o�e */
        strcpy(plistC->foccup,tmp_foccup);
        strcpy(plistC->applicant_foccup,tmp_applicant_foccup);
        strcpy(plistC->dbirth,tmp_dbirth);
        strcpy(plistC->dbirth_appl,tmp_dbirth_appl);
        strcpy(plistC->tmobile_appl,tmp_tmobile_appl);
        strcpy(plistC->dissue,tmp_dissue);
        strcpy(plistC->aemail_appl,tmp_aemail_appl);
        strcpy(plistC->ftrans_third,tmp_ftrans_third); /*�ĤT��ǿ���O (1110303014_SC1)*/
        plistC->next       = NULL;
    }
    $CLOSE CA508_1;

    return SUCCESS;

chkp_err:
    printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    memset(err_buf,0,sizeof(err_buf));
    strcpy(err_buf,maxp1);
    return SQLCODE;
}

/*****************************************************************/
int InsertPlyPolicy(plistF,plistC,fd)
struct PLY_LIST *plistF, *plistC;
int    fd;
{
    $char  tmp_ipolicy[POLICY_NUM_1],ins_type[INSURANCE_TYPE], buf[300];
    $char  tmp_tagnum[CA_TAG_NUM],tmp_body[CA_BODY_NUM],tmp_engine[CA_ENGINE_NUM];
    $char  tmp_assuredn[121],tmp_icard[CARD_NUM],tmp_fcard_class[2];
    $char  tmp_assuredi[CUSTOMER_ID];
    $char  nassured_10c[11];
    $char  tmp_str[CA_ENGINE_NUM], provision[21];
    $date  tmp_dbegin, tmp_dend;
    $int	 tmp_qprovision;
    $char  Full_DBName[31];
    $char  stmt[1000];
    $char  tmp_policy[21];
    $char  tmp_policy15[16];
    $char  iins_kind_ply[3];
    
    long  rtncode;

    printf("************************* into InsertPlyPolicy\n");

    $WHENEVER SQLERROR GOTO insp_err;

    plistC=plistF;

    
    while (plistC)
    {
        strcpy(tmp_ipolicy,plistC->ipolicy);
        strcpy(tmp_policy,plistC->itmp_policy_ori);
        strcpy(tmp_fcard_class,plistC->fcard_class);

        memset(err_buf,0,sizeof(err_buf));
        strcpy(err_buf,"update ply_relation:");

        printf("tmp_policy[%s]\n", tmp_policy);

        $UPDATE ply_relation
            SET dply_close = $plydate
          WHERE ipolicy = $tmp_ipolicy;

        memset(err_buf,0,sizeof(err_buf));
        strcpy(err_buf,"insert ori_ply_relation:");

        $INSERT INTO ori_ply_relation
         SELECT *
           FROM ply_relation
          WHERE ipolicy = $tmp_ipolicy;

        memset(err_buf,0,sizeof(err_buf));
        strcpy(err_buf,"insert original_ply:");
        $INSERT INTO original_ply
         SELECT *
           FROM policy
          WHERE ipolicy = $tmp_ipolicy;

        memset(err_buf,0,sizeof(err_buf));
        strcpy(err_buf,"insert ca_ori_bound:");

        $INSERT INTO ca_ori_bound
         SELECT *
           FROM ca_ply_bound
          WHERE ipolicy = $tmp_ipolicy;

        memset(err_buf,0,sizeof(err_buf));
        strcpy(err_buf,"insert ori_ins_type:");
        $DECLARE INS_P CURSOR FOR
          SELECT iins_type
            INTO $ins_type
            FROM ply_ins_type
           WHERE ipolicy=$tmp_ipolicy;
        $OPEN INS_P;
        while (1)
        {
            $FETCH INS_P;
            if (NOT_FOUND) break;

            $INSERT INTO ori_ins_type
             SELECT *
               FROM ply_ins_type
              WHERE ipolicy = $tmp_ipolicy
                AND iins_type = $ins_type;

            /* �ˮ`�I���Ӹ�� insert:ca_pa_ori , update:ca_pa_ply */
            if( (strcmp(trim(ins_type),"33")==0)  || (strcmp(trim(ins_type),"35")==0) ||
                (strcmp(trim(ins_type),"48")==0)  || (strcmp(trim(ins_type),"56")==0) || 
                (strcmp(trim(ins_type),"136")==0) || (strcmp(trim(ins_type),"166")==0)||
                (strcmp(trim(ins_type),"266")==0) )
            {
                memset(err_buf,0,sizeof(err_buf));
                strcpy(err_buf,"update ca_pa_ply:");
                $UPDATE ca_pa_ply
                    SET dpolicy = $plydate
                  WHERE ipolicy = $tmp_ipolicy
                    AND iins_type = $ins_type;

                memset(err_buf,0,sizeof(err_buf));
                strcpy(err_buf,"insert ca_pa_ori:");
                $INSERT INTO ca_pa_ori
                 SELECT *
                   FROM ca_pa_ply
                  WHERE ipolicy = $tmp_ipolicy
                    AND iins_type = $ins_type;
            }

            #ifdef CA_CONS
            memset(err_buf,0,sizeof(err_buf));
            strcpy(err_buf,"insert ori_ins_cover:");

            $INSERT INTO ori_ins_cover
             SELECT *
               FROM ply_ins_cover
              WHERE ipolicy = $tmp_ipolicy
                AND iins_type = $ins_type;
            #endif

            #ifdef CA_ONE
            memset(err_buf,0,sizeof(err_buf));
            strcpy(err_buf,"insert ori_ins_assured:");
			
			$INSERT INTO ori_ins_assured
             SELECT ipolicy, iins_type, provision, iassured, nassured, dbirth, nbenef, rel_benef, tbenef, abenef_zip, abenef, 0
               FROM ply_ins_assured
              WHERE ipolicy = $tmp_ipolicy
                AND iins_type = $ins_type;
            #endif

        }


        /* ���w�r�p�H�W�U(D����) add by sylvia 101.06.22 */
        /* 1081225006-SC1-���ά�-�X�R���[���ڥN�X */
        printf("----------------- 2168 --------------------\n");
        tmp_qprovision = plistC->qprovision;
        printf("tmp_qprovision=[%d]\n",tmp_qprovision);
        if (tmp_qprovision > 0 )
        {
        	printf("----- 2173 tmp_ipolicy=[%s]--------------------\n",tmp_ipolicy);
        	$INSERT INTO ori_ins_assured
        	SELECT  ipolicy, iins_type, provision, iassured, nassured, dbirth, nbenef, rel_benef, tbenef, abenef_zip, abenef, 0
        	  FROM ply_ins_assured
        	 WHERE ipolicy = $tmp_ipolicy
                   AND trim(provision)||';' like '%D;%'
                   and trim(iins_type) = '';
        }

        $CLOSE INS_P;
        tmp_qprovision = 0;

        printf("tmp_fcard_class[%s]\n", tmp_fcard_class);

        if (tmp_fcard_class[0] == '1')
            strcpy( iins_kind_ply, "C1");
        else
            strcpy( iins_kind_ply, "C2");

        printf("iins_kind_ply[%s]\n", iins_kind_ply);

        printf("tmp_policy[%s]\n", tmp_policy);

        $UPDATE newa00:quotation_master
            SET ipolicy = $tmp_ipolicy,
                dprint = current,
                dply_edr = current,
                icurrent_state = 799
          WHERE iquote = $tmp_policy 
            AND iins_kind_ply = $iins_kind_ply; 

        strncpy( tmp_policy15, tmp_policy, 15);
        tmp_policy15[15] = '\0';

        $UPDATE newa00:quotation_master
            SET ftrade = '99',
                ftrack  = '1',
                iupdate_remark ='SYS',
                dupdate_remark=current
          WHERE iquote[1,15]=$tmp_policy15
	    AND iins_kind_ply = $iins_kind_ply
            AND (ftrade = " " or ftrade is null)
            AND iquote like '%CVQ%';

        plistC=plistC->next;
    }
    

    /* once again, insert into all sites' database table:assured_vs_ply */
    $WHENEVER SQLERROR GOTO insp_err;

    memset(err_buf,0,sizeof(err_buf));
    strcpy(err_buf,"insert ca_ply_assured:");

    sprintf_s(buf,sizeof buf,"INSERT INTO ca_ply_assured %s %s",
                             "(nassured,itag,ibody,iengine,ipolicy,icard,",
                             "fcard_class,dpolicy,ftrans,iassured) VALUES (?,?,?,?,?,?,?,?,'A',?)");
    $PREPARE INS_P_ID FROM $buf;

    plistC=plistF;

    while (plistC)
    {
             strcpy(tmp_ipolicy,plistC->ipolicy);
             strcpy(tmp_assuredn,plistC->assuredn);
             strcpy(tmp_tagnum,plistC->tagnum);
             strcpy(tmp_body,plistC->body);
             strcpy(tmp_engine,plistC->engine);
             strcpy(tmp_icard,plistC->icard);
             strcpy(tmp_fcard_class,plistC->fcard_class);
             strcpy(tmp_assuredi, plistC->assuredi);

             strncpy(nassured_10c,&tmp_assuredn[0],10);
             nassured_10c[10]='\0';

             $EXECUTE INS_P_ID
                USING $nassured_10c,$tmp_tagnum,$tmp_body,$tmp_engine,
                      $tmp_ipolicy,$tmp_icard,$tmp_fcard_class,$plydate,
                      $tmp_assuredi;

             plistC=plistC->next;
    }

    $WHENEVER SQLERROR GOTO insp_err;

    memset(err_buf,0,sizeof(err_buf));
    strcpy(err_buf,"insert ca_ply_period:");

    $SET LOCK MODE TO WAIT;
    sprintf_s(buf,sizeof buf,"INSERT INTO ca_ply_period %s %s",
                             "(inumber,dply_bgn,dply_end,ipolicy,fcard_class,ftrans) ",
                             "VALUES (?,?,?,?,?,'A')");
    $PREPARE INS_P_ID_1 FROM $buf;

    plistC=plistF;

    while (plistC)
    {
         strcpy(tmp_ipolicy     , plistC->ipolicy);
         strcpy(tmp_tagnum      , plistC->tagnum);
         strcpy(tmp_engine      , plistC->engine);
         strcpy(tmp_fcard_class , plistC->fcard_class);
         tmp_dbegin             = plistC->ply_begin;
         tmp_dend               = plistC->ply_end;

         if(tmp_tagnum[0]==' ' || tmp_tagnum[0]=='\0')
              strcpy(tmp_str,tmp_engine);
         else
              strcpy(tmp_str,tmp_tagnum);

         $EXECUTE INS_P_ID_1
            USING $tmp_str,$tmp_dbegin,$tmp_dend,$tmp_ipolicy,
                  $tmp_fcard_class;

         plistC=plistC->next;
    }

    /**********************************/
    /*  cm_ply_info cm_plyins_info    */
    /*  car9807142 �����g�Jcm_ply_info
    /*                & cm_plyins_info */
    /**********************************/
    {    /* insert into cm_ply_info , cm_plyins_info*/
         /*POLICY_INFO stCmPlyInfo;
         POLICYINS_INFO stCmPlyInsInfo;
         $char tmp_fins_grp[2], tmp_iins_type[7], tmp_iproduct[3];
         $long tmp_mins_premium, tmp_mcommission, tmp_magent;
         $long tmp_mdiscount;
         $char tmp_icar_type[3];
         $long tmp_qply_period;
         $char iproduct[13];
         $char kclsfyitem[5];
         $char kreserve[6];*/

         plistC=plistF;
         while (plistC)
         {
              /*printf("*****insert into cm_ply_info********\n");
              cm_ply_info_init(&stCmPlyInfo);
              strcpy(tmp_ipolicy,                    plistC->ipolicy);
              strcpy(stCmPlyInfo.insure_type,        "C");
              strcpy(stCmPlyInfo.isys_source,        "CAR");

              strncpy(stCmPlyInfo.ipolicy1, plistC->ipolicy, CAR_POLICY_LEN);
              stCmPlyInfo.ipolicy1[CAR_POLICY_LEN] = '\0';
              strncpy(stCmPlyInfo.ipolicy2, plistC->ipolicy+CAR_POLICY_LEN,
                                                               CAR_TARGET_LEN);
              stCmPlyInfo.ipolicy2[CAR_TARGET_LEN] = '\0';
              if (stCmPlyInfo.ipolicy2[0]=='\0' || stCmPlyInfo.ipolicy2[0]==' ') strcpy(stCmPlyInfo.ipolicy2," ");

              strcpy(stCmPlyInfo.iendorse,           "");
              strcpy(stCmPlyInfo.iofficer,           plistC->iofficer);
              strcpy(stCmPlyInfo.ibroker,            plistC->ibroker);
              strcpy(stCmPlyInfo.ifpce_id,           plistC->assuredi);
              strcpy(stCmPlyInfo.ifpce_id_ext,       plistC->assuredi_ext);
              strcpy(stCmPlyInfo.icorps,             plistC->icorps);
              strcpy(stCmPlyInfo.dpolicy,            cm_edate_str(plistC->dpolicy));
              strcpy(stCmPlyInfo.icomp_in,           plistC->icomp_in);
              strcpy(stCmPlyInfo.ibranch_in,         plistC->ibranch_in);
              strcpy(stCmPlyInfo.iquota,             plistC->iquota);
              strcpy(stCmPlyInfo.itreaty,            plistC->treaty);
              strcpy(stCmPlyInfo.dply_begin, cm_edate_str(plistC->ply_begin));
              strcpy(stCmPlyInfo.dply_end,   cm_edate_str(plistC->ply_end));
              strcpy(stCmPlyInfo.iresource,          plistC->iresource);
              strcpy(stCmPlyInfo.icar_flag,          plistC->icar_flag);
              stCmPlyInfo.mply_prem =                (long) plistC->ply_mprem;

              tmp_qply_period       =                plistC->qply_period;
              strcpy(tmp_icar_type,                  plistC->icar_type);

              �j���I����O
              strcpy(tmp_fcard_class,                plistC->fcard_class);
              if (strcmp(tmp_fcard_class, "1")==0)
              {
                   stCmPlyInfo.mdeal       =         (long) plistC->ply_mcommi;
                   stCmPlyInfo.mcommission =         0;
              }
              else
              {
                   stCmPlyInfo.mdeal       =         0;
                   stCmPlyInfo.mcommission =         (long) plistC->ply_mcommi;
              }

              stCmPlyInfo.magent =                   (long) plistC->ply_magent;
              stCmPlyInfo.mdiscount =                (long) plistC->ply_mdisc;
              stCmPlyInfo.mreins_commission =        (long) 0;
              strcpy(stCmPlyInfo.ileader,            plistC->ileader);
              stCmPlyInfo.qcount = (int) 1;

              rtncode = cm_ply_info_insert(&stCmPlyInfo);
              if (rtncode != 0)
              {
                 sprintf(err_buf, "insert cm_ply_info error [%ld]:", rtncode);
                 goto insp_err;
              }

              $DECLARE PLY_INS CURSOR FOR
                SELECT iins_type, mins_premium, mcommission, magent, mdiscount,
                       mpure_prem, iproduct[4,5], provision
                  FROM ply_ins_type
                 WHERE ipolicy=$tmp_ipolicy;
              $OPEN PLY_INS;
              while (1)
              {
                   $FETCH PLY_INS INTO $tmp_iins_type, $tmp_mins_premium,
                                       $tmp_mcommission, $tmp_magent,
                                       $tmp_mdiscount, $tmp_mpure_prem,
                                       $tmp_iproduct, $provision;
                   if (SQLCODE==SQLNOTFOUND) break;

                   $SELECT fins_grp INTO $tmp_fins_grp
                      FROM insurance_type
                     WHERE iins_type=$tmp_iins_type;

                   cm_plyins_info_init(&stCmPlyInsInfo);
                   strcpy(stCmPlyInsInfo.insure_type, "C");
                   strcpy(stCmPlyInsInfo.isys_source, "CAR");

                   strncpy(stCmPlyInsInfo.ipolicy1, plistC->ipolicy, CAR_POLICY_LEN);
                   stCmPlyInsInfo.ipolicy1[CAR_POLICY_LEN] = '\0';
                   strncpy(stCmPlyInsInfo.ipolicy2, plistC->ipolicy+CAR_POLICY_LEN,
                                                                 CAR_TARGET_LEN);
                   stCmPlyInsInfo.ipolicy2[CAR_TARGET_LEN] = '\0';
                   if (stCmPlyInsInfo.ipolicy2[0]=='\0' || stCmPlyInsInfo.ipolicy2[0]==' ')
                       strcpy(stCmPlyInsInfo.ipolicy2," ");

                   strcpy(stCmPlyInsInfo.iendorse, "");


                    ����|�p��l��
                   rtncode = get_product_code("C",tmp_iins_type,tmp_icar_type,tmp_qply_period,iproduct,kclsfyitem,
                                              kreserve, provision);
                   if (rtncode != M_CM_OK)
                   {
                         sprintf(err_buf, "get_product_code error [%ld]:", rtncode);
                         goto insp_err;
                   }

                   strcpy(stCmPlyInsInfo.insure_kind,    trim(kclsfyitem));
                   strcpy(stCmPlyInsInfo.insure_instype, tmp_iins_type);
                   strcpy(stCmPlyInsInfo.iacc_instype,   tmp_iproduct);

                   /*********************************************************
                   switch(atoi(trim(tmp_iins_type)))
                   {
                      case 2:  case 3:  case 4:  case 12: case 13: case 14:
                      case 24: case 25: case 29: case 30: case 32:
                      case 52: case 53: case 71: case 72: case 82: case 83:
                               stCmPlyInsInfo.qcount = 0;
                               break;
                      default:
                               stCmPlyInsInfo.qcount = 1;
                   }
                   *********************************************************/

                   /*stCmPlyInsInfo.qcount = 1;
                   stCmPlyInsInfo.mply_prem = (long) tmp_mins_premium;

                   if (strcmp(tmp_fcard_class, "1")==0)
                   {
                        stCmPlyInsInfo.mcommission = 0;
                        stCmPlyInsInfo.mdeal       = (long) tmp_mcommission;
                   }
                   else
                   {
                        stCmPlyInsInfo.mcommission = (long) tmp_mcommission;
                        stCmPlyInsInfo.mdeal       = 0;
                   }

                   stCmPlyInsInfo.magent = (long) tmp_magent;
                   stCmPlyInsInfo.mdiscount = (long) tmp_mdiscount;
                   stCmPlyInsInfo.mpure_prem= (double)tmp_mpure_prem;

                   printf("**** call cm_plyins_info_insert(pure)\n");

                   rtncode = cm_plyins_info_insert(&stCmPlyInsInfo);
                   if (rtncode != 0)
                   {
                        sprintf(err_buf, "insert cm_plyins_info error [%ld]:", rtncode);
                        goto insp_err;
                   }
              }
              $FREE PLY_INS; */

              printf("**** call cu_upd_customer_plyflag\n");

              rtncode = cu_upd_customer_plyflag("C", plistC->assuredi,
                                                plistC->assuredi_ext);
              if (rtncode != M_CM_OK)
              {
                 sprintf_s(err_buf, sizeof err_buf,"cu_upd_customer_plyflag error [%ld]:", rtncode);
                 goto insp_err;
              }

              /* �t�X�ȪA��P�t�ε{���վ�A��function���Ѥ��A�ϥ� (1101112008_SC3) */
              /*if (strcmp(plistC->assuredf, "1") == 0 ||
                  strcmp(plistC->assuredf, "3") == 0 ||
                  strcmp(plistC->assuredf, "5") == 0)
              {
              printf("**** call cu_upd_customer_plyflag\n");

                 rtncode = cu_upd_customer_dfirst_ply(plistC->assuredi,
                                                      plistC->assuredi_ext,
                                                      plistC->dpolicy);
                 if (rtncode != M_CM_OK)
                 {
                    sprintf(err_buf, "cu_upd_customer_dfirst_ply error [%ld]:",
                            rtncode);
                   goto insp_err;
                 }
              }*/
              
              /* �t�X�ȪA��P�t�ε{���վ�A��function���Ѥ��A�ϥ� (1101112008_SC3) */
              /*
              printf("**** call cu_upd_miss_renew_ply\n");

              rtncode = cu_upd_miss_renew_ply("C", "CAR", plistC->assuredi,
                                              plistC->assuredi_ext,
                                              plistC->ilast_ply, " ",
                                              plistC->ipolicy, " ",
                                              plistC->ply_begin, plistC->ply_end,
                                              plistC->dpolicy,
                                              plistC->iofficer);
              if (rtncode != M_CM_OK)
              {
                 sprintf(err_buf, "cu_upd_miss_renew_ply error [%ld]:", rtncode);
                 goto insp_err;
              }*/

              plistC=plistC->next;
         }
    }

     /* �X�w�q��(iroute=I006)�~�ȷs�W�{��  dws9703121  */
     /* �Ҧ��O������q����Ƨ��g�Jcm_route_data dws9807211 */
     /* cm_route_data�W�[�ĤT��ǿ���O��� (1110303014_SC1) */
     {
     	$char tmp_ipolicy1[21],tmp_ipolicy2[21],last_iaccept[51],iaccept[51],ori_iaccept[51];
     	$long tmp_rel_dclose,tmp_dclose;
     	$char tmp_last_iply1[21],tmp_last_iply2[21],tmp_last_iply[POLICY_NUM_1];
     	$char tmp_irelative_ply[POLICY_NUM_1],tmp_rel_iply1[21],tmp_rel_iply2[21];
     	$long cnt_flag=0, tmp_cnt=0;
     	$char auto_paid[2];
     	$char rd_ipolicy[21],tmp_itag[CA_TAG_NUM];
     	$char tmp_iroute[21], tmp_intro[21];
     	$char tmp_iroute_prop[3],tmp_ftrans_third[2];
     	$char tmp_itmp_policy[21];
        $WHENEVER SQLERROR GOTO insp_err;

        printf("get into �q��\n");

        memset(err_buf,0,sizeof(err_buf));
        strcpy(err_buf,"insert cm_route_data:");

        sprintf_s(buf,sizeof buf,"INSERT INTO cm_route_data %s %s %s %s",
                                 "(ipolicy1,ipolicy2,column_1,column_2,column_3,column_4,column_5,",
                                 "column_6,column_7,column_8,column_9,column_10,ftrans_third,iupdate,dupdate) ",
                                 "VALUES (?,?,?,' ',?,' ',?,",
                                 "?,?,?,?,?,?,'CAR5081',current)");

        $PREPARE cur_cm_route FROM $buf;

        plistC=plistF;

        while (plistC)
        {
        
              printf("*****insert into cm_route_data********\n");
              strcpy(tmp_ipolicy,plistC->ipolicy);
              strcpy(tmp_fcard_class,plistC->fcard_class);
              strcpy(tmp_irelative_ply,plistC->irelative_ply);
              strcpy(tmp_last_iply,plistC->ilast_ply);
              strcpy(tmp_itag,plistC->tagnum);
              strcpy(tmp_intro,plistC->introducer);
              strcpy(tmp_iroute_prop,plistC->iroute_prop);
              strcpy(tmp_ftrans_third,plistC->ftrans_third);
              strcpy(tmp_itmp_policy,plistC->itmp_policy_ori);
              
              /* �B�z�O�渹(ipolicy) */
              strncpy(tmp_ipolicy1, plistC->ipolicy, CAR_POLICY_LEN);
              tmp_ipolicy1[CAR_POLICY_LEN] = '\0';
              strncpy(tmp_ipolicy2, plistC->ipolicy+CAR_POLICY_LEN,CAR_TARGET_LEN);
              tmp_ipolicy2[CAR_TARGET_LEN] = '\0';
              if (tmp_ipolicy2[0]=='\0' || tmp_ipolicy2[0]==' ') strcpy(tmp_ipolicy2," ");
              /* end of �B�z�O�渹 */
              
              strcpy(last_iaccept," ");     /* �e���z�s�� */ 
              strcpy(iaccept     ," ");     /* ���z�s��   */
              strcpy(ori_iaccept ," ");     /* ������z�� */                        	  
              strcpy(last_iaccept," ");
              strcpy(rd_ipolicy  ," ");
              strcpy(auto_paid   ," ");              
          	  
              $SELECT nvl(iroute_accept,' ') INTO $ori_iaccept FROM policy
                WHERE ipolicy = $tmp_ipolicy;
              if (SQLCODE == SQLNOTFOUND)
              {
                     plistC=plistC->next;
                     continue;
              }
              
              strcpy(iaccept,ori_iaccept);
          	  
              /* �X�w���z�s�� */
              if (strncmp(plistC->iroute,"I006",4) == 0)
              {
                     printf("I006\n\n\n");
                     
              	     /* �B�z�e�@�~�O�渹(ilast_ply) */
              	     strncpy(tmp_last_iply1, plistC->ilast_ply, CAR_POLICY_LEN);
                     tmp_last_iply1[CAR_POLICY_LEN] = '\0';
                     strncpy(tmp_last_iply2, plistC->ilast_ply+CAR_POLICY_LEN,CAR_TARGET_LEN);
                     tmp_last_iply2[CAR_TARGET_LEN] = '\0';
                     if (tmp_last_iply2[0] == '\0' || tmp_last_iply2[0] == ' ') strcpy(tmp_last_iply2," ");
                     strncpy(tmp_rel_iply1, plistC->irelative_ply, CAR_POLICY_LEN);
                     tmp_rel_iply1[CAR_POLICY_LEN] = '\0';
                     strncpy(tmp_rel_iply2, plistC->irelative_ply+CAR_POLICY_LEN,CAR_TARGET_LEN);
                     tmp_rel_iply2[CAR_TARGET_LEN] = '\0';
                     if (tmp_rel_iply2[0] == '\0' || tmp_rel_iply2[0] == ' ') strcpy(tmp_rel_iply2," ");
                     /* end of �B�z�e�@�~�O�渹 */

                     printf("ori_iaccept=[%s]\n",ori_iaccept);
                    
                     strcpy(rd_ipolicy,tmp_ipolicy);
                    
                                              
                     /* 1040909005_C1 �X�w���z�s���W�h�ק� */
                     /* �Y�g���N�����X�w���L���z�s��,��JCA000000,user�i��cmn503��J���T���z�s�� */
                     /* 1050107005_C2 �X�w���z�s���W�h�ק� 
                        �X�w�אּ��պ�ɨ����z�s���A�X��ɪ������θӨ��z�s���A���z�s���������ȡA�B��cmn121���z�s�����O�ˮ� */
                     /*if (iaccept[0] == '\0' || iaccept[0] == ' ')
                     {
                         strcpy(iaccept,"CA000000");*
	                     strcpy(auto_paid,"M");                         
                     }*/
                     
		     printf("iaccept=[%s]\n",iaccept);                     	
		     printf("tmp_last_iply[%s]\n",tmp_last_iply);
									
                     /* �P�_�s��O��,CA888888&CA999999����O,��L(�DCA000000)�h���s�O,CA000000���`�� */
                     if ( strlen(trim(tmp_last_iply)) > 0)  /*( strncmp(iaccept,"CA888888",8) == 0 || strncmp(iaccept,"CA999999",8) == 0 ) */
                     {
                            printf("step 3, ��O��\n");

                            /* ��O��column_1��O�渹; column_6��'A' */
                            strcpy(auto_paid,"A");

                            /* ��X�e�@�~�O�_���X�w�� */
                            strcpy(Full_DBName,get_car_full_db(tmp_last_iply));
                            
                            printf("Full_DBName[%s]\n",Full_DBName);
			    sprintf_s(stmt,sizeof stmt,"SELECT count(*) "
                                                       "  FROM %s:policy  "
                                                       " WHERE ipolicy = '%s' "
                                                       "   AND iroute matches 'I006*' ",Full_DBName,tmp_last_iply);
                            printf("stmt[%s]\n",stmt);
			    $PREPARE cur1 FROM $stmt;
    			    $EXECUTE cur1 INTO $cnt_flag;

                            printf("cnt_flag[%d]\n",cnt_flag);
                            
                            if (cnt_flag > 0)
                            {
                       	        /* �e�@�~�X�w��,�bcm_route_data��e�@�~���z�s��,�䤣��Φh��@���h�����` */
                       	         $SELECT column_1,count(*) INTO $last_iaccept,$tmp_cnt
                       	            FROM cm_route_data
                       	           WHERE ipolicy1 = $tmp_last_iply1
                       	             AND ipolicy2 = $tmp_last_iply2
                       	         GROUP BY 1;
                                 printf("tmp_cnt[%d]\n",tmp_cnt);
                             
                            }
                    }
                    else /*  if (strncmp(iaccept,"CA000000",8) != 0) �s�O�� */
                    {
                           printf("step4, �s�O��\n");
               	           /* �s�O��e�@�~���z�s������ */               	           
               	           strcpy(auto_paid,"M");
                    }
              } /* end of �X�w���z�s�� */
              else if (strncmp(plistC->iroute,"I009",4) == 0)
              {
              	  /*1121006006_C02_���Ȩ��I��O(CR)���z�s�� ����2��*/
              	  strcpy(ori_iaccept,trim(ori_iaccept));
              	  strcpy(iaccept,trim(iaccept));
              	  printf("ori_iaccept[%s],tmp_itmp_policy[%s],tmp_fcard_class[%s]\n",ori_iaccept,tmp_itmp_policy,tmp_fcard_class);
              	  if (strncmp(ori_iaccept,"217CAR",6) == 0 && strlen(ori_iaccept) == 16 )
              	  {
              	      if (strncmp(tmp_fcard_class,"1",1) == 0)
              	      {
              	          strcat(iaccept,"1");
                          strcat(ori_iaccept,"1");
              	      }
              	      else if (strncmp(tmp_fcard_class,"2",1) == 0)
              	      {
              	          strcat(iaccept,"2");
                          strcat(ori_iaccept,"2");
              	      }
              	  	
              	  }
              }
              
              
              printf("tmp_ipolicy1[%s],tmp_ipolicy2[%s]\n",tmp_ipolicy1,tmp_ipolicy2);
              printf("iaccept[%s],last_iaccept[%s],autopaid[%s]\n",iaccept,last_iaccept,auto_paid);
              printf("rd_ipolicy[%s],ori_iaccept[%s]\n",rd_ipolicy,ori_iaccept);
              printf("tmp_intro[%s],iroute_prop[%s]\n",tmp_intro,tmp_iroute_prop);
              printf("ftrans_third[%s]\n",tmp_ftrans_third);

              $EXECUTE cur_cm_route
                        USING $tmp_ipolicy1,$tmp_ipolicy2,
                              $iaccept,$last_iaccept,
                              $rd_ipolicy,$auto_paid,$ori_iaccept,$tmp_itag,
                              $tmp_intro,$tmp_iroute_prop,$tmp_ftrans_third;

              plistC=plistC->next;
              cnt_flag = 0;
              tmp_cnt = 0;
        } /* end of while */
     }
     /* end of �X�w�q�� */
     


    return SUCCESS;

insp_err:
    printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    strcat(err_buf,tmp_ipolicy);
    return SQLCODE;
}

/*****************************************************************/
FreePlyList(plistF,plistC)
struct PLY_LIST *plistF, *plistC;
{
    while (plistF != NULL)
    {
        plistC=plistF;
        plistF=plistC->next;
        free(plistC);
    }
}
/*****************************************************************/


/* 1040416007_C1 �S�w�q��ñ��W�h�վ�

  �^���Ҧ��u�Lñ���v���u�j���I�v��ơG
    (1)�Y�u�O�����O = SP-20�v�̡A�h
       (i )�Y[(�ͮĤ�-�t�Τ�) > 25��(�Y�uB2B���סB���q��v�h��10��)] �B[�����O]
          �̡A���L���B�z�C
       (ii)�Y[(�ͮĤ�-�t�Τ�) �� 25��(�Y�uB2B���סB���q��v�h��10��)]��[�w���O]
          �̡A�g�J��ñ���(=�t�Τ�)���A�ç�s�u�@�γ������ɡv�L��ɶ��Ϊ��A���p�U�G
            �]�̷s�O����  �Gply_relation.dpolicy (�L���)   = �t�Τ�
              �@�γ������ɡGcm_pre_receive.dprint  (�L��ɶ�) = �t�ήɶ�
          cm_pre_receive.fstatus (���A)   = 30 (�w�X��-�����O)
               ��
          cm_pre_receive.fstatus (���A)   = 60 (�w�X��-�w���O)
*/
long pre_chk_comp()
{
    $date plydate;
    $int  fstatus,v_fstatus;
    long  iCount,iCountTot;
    $char chk_ipolicy[POLICY_NUM_1]=" ",tmp_fcomp_daychk[2]=" ",ftype_pol[3]=" ",ftype_sp[3]=" ",ipre_rcv[21]=" ";
    $char stmt[1024]=" ";
    $double dblMntPre, dblMntPass;

    $WHENEVER SQLERROR GOTO pre_chk_err;
    printf("--- pre_chk_comp() �}�l ---\n ");

    plydate = dwritten;
    fstatus = 10;
    iCount  = 0 ;
    iCountTot = 0;
    dblMntPre = 0.0;
    dblMntPass= 0.0;
    strcpy(chk_ipolicy, " ");
    strcpy(tmp_fcomp_daychk, "N");
    v_fstatus = 0;

    $PREPARE preSelpre  FROM "select ipre_rcv, nvl(mprem,0),ftype_pol,ftype_sp,fstatus from cm_pre_receive where iins_cat = 'C' and iins_kind = '1' and ipolicy1 = ? and ipre_end= ' '";
    $PREPARE preSelpass FROM "select nvl(mnt,0) from ao_prercv_pass where iins_cat = 'C' and ipre_rcv = ? and iins_kind = '1' and ipre_end= ' '";
    $PREPARE preUpdply  FROM "update ply_relation set dpolicy = ? , fprint = '1' where ipolicy= ?";
    $PREPARE preUpdpre  FROM "update cm_pre_receive set dprint = EXTEND( ? ,year to second) + interval(1) second to second , fstatus = ? ,iupdate = 'CAR5081', dupdate=current \
                               where iins_cat = 'C' and iins_kind = '1' and ipolicy1 = ? and ipre_end= ' '";

    $BEGIN WORK;
    $WHENEVER SQLERROR CONTINUE;
    $LOCK TABLE ply_relation IN SHARE MODE;
    $LOCK TABLE cm_pre_receive IN SHARE MODE;
    $WHENEVER SQLERROR GOTO pre_chk_err;

    /* 1040828003_C1 �j���Iñ��ΦL�Һ޲z
       �ư��~��d�|���L�j���Ҫ�(�Ҹ�=�O�渹)(���i��ñ���B�鵲)

       �Ҹ�<>�O�渹�B�Lñ���i�઺���p���G
           �~��d:SP-20
           �D�~��d:SP-20 (SP-01�BPA��car203�L�ҫ�Y�|���Wñ���)
    */
    sprintf_s(stmt,sizeof stmt,"Select a.ipolicy, "
	                       "       case when nvl(c.qday_permit_c,0)>0 then "
	                       "            case when (a.dply_begin-%ld) <= nvl(c.qday_permit_c,0) then 'Y' else 'N' end "
	                       "       else 'Y' end "
                               "   From ply_relation a, policy b, outer ca_permit c "
	                       "  Where a.ipolicy = b.ipolicy "
	                       "    and a.dpolicy    is null  "
	                       "    and a.dply_close is null  "
	                       "    and a.fcard_class = '1'   "
	                       "    and a.icard <> a.ipolicy  "
	                       "    and (c.iclass = '05' and b.iroute LIKE trim(c.icode)||'%%' and c.ftype_sp='20') ", plydate, plydate);
    printf("pre_chk_comp() stmt=[%s]\n ",stmt);
    $PREPARE pre_comp FROM $stmt;
    $DECLARE cur_comp CURSOR FOR pre_comp;
    $OPEN cur_comp;
    while (1)
    {
        $FETCH cur_comp INTO $chk_ipolicy,$tmp_fcomp_daychk;
        if (SQLCODE == SQLNOTFOUND) break;
        printf("pre_chk_comp() chk_ipolicy[%s],tmp_fcomp_daychk[%s]\n ",chk_ipolicy, tmp_fcomp_daychk);

        /* �@�γ����� */
        dblMntPre = 0.0;
        strcpy(ipre_rcv," ");  strcpy(ftype_pol," ");  strcpy(ftype_sp," "); v_fstatus = 0;
        $EXECUTE preSelpre Into $ipre_rcv,$dblMntPre,$ftype_pol,$ftype_sp,$v_fstatus USING $chk_ipolicy;
        if (SQLCODE == SQLNOTFOUND){
            sprintf_s( sErrMsg, sizeof sErrMsg, "[�j���I�Lñ���B�z]:���D��-�O�渹[%s]�L�@�γ������", chk_ipolicy);
            WRITELOG( sfp, sErrMsg);
            GetMsg(chk_ipolicy,sErrMsg);
            continue;
        }
        iCountTot ++;
        printf("pre_chk_comp() ipre_rcv [%s], dblMntPre[%f]\n ", ipre_rcv , dblMntPre);
        printf("pre_chk_comp() ftype_pol[%s], ftype_sp [%s]\n ", ftype_pol, ftype_sp);

	if ((strcmp(ftype_pol,"SP")==0) && (strcmp(ftype_sp,"20")==0))
	{
	    /* 1060106005_C1 �ץ����s�t�ΥX��@�~(�p�P�N�����榬�O�@�o�ɻݦP�ɨ����i�X��@�~) */
	    if (v_fstatus==90)
	    {
	        sprintf_s( sErrMsg,sizeof sErrMsg, "[�j���I�Lñ���B�z]:������w�@�o(fstatus=90)�G�����渹[%s]�O�渹[%s]", ipre_rcv,chk_ipolicy);
	        WRITELOG( sfp, sErrMsg);
	        GetMsg(chk_ipolicy,sErrMsg);
	        continue;
	    }
			
	    /* ���O�X��O���� */
	    dblMntPass = 0.0;
	    $EXECUTE preSelpass Into $dblMntPass USING $ipre_rcv;
	    printf("pre_chk_comp() dblMntPass[%f]\n ", dblMntPass);

	    if ((dblMntPass >= dblMntPre) && (dblMntPass > 0))   /* �w���O */
	    {
                fstatus = 60;
	    }
	    else                                                 /* �����O */
	    {
	        printf("pre_chk_comp() �����O\n ");
		if (tmp_fcomp_daychk[0]=='Y')                    /* (�ͮĤ�-�t�Τ�) �� (car153�]�w�Ѽ�) �� ������ */
		{
		    fstatus = 30;
		}
		else                                             /* (�ͮĤ�-�t�Τ�) > (car153�]�w�Ѽ�) */
		{
		    printf("pre_chk_comp()���B�z,�@�]�����O�@�B (�ͮĤ�-�t�Τ�) > (car153�]�w�Ѽ�)\n ");
		    continue;	/* ���L���B�z(��ñ��B�鵲) */
		}
	    }
	    printf("pre_chk_comp() fstatus[%d]\n ", fstatus);

	    /* �^��ñ���(ply_relation) */
            $EXECUTE preUpdply USING $plydate , $chk_ipolicy;
            if (sqlca.sqlerrd[2]==0) 
            {
	        sprintf_s( sErrMsg,sizeof sErrMsg, "[�j���I�Lñ���B�z]:�^��ply_relation���ѡG�O�渹[%s]", chk_ipolicy);
	        WRITELOG( sfp, sErrMsg);
	        GetMsg(chk_ipolicy,sErrMsg);
	        continue;
            }

            /* �^���L��ɶ�(cm_pre_receive)�B���A */
            $EXECUTE preUpdpre USING $plydate, $fstatus, $chk_ipolicy;
            if (sqlca.sqlerrd[2]==0) 
            {
	        sprintf_s( sErrMsg,sizeof sErrMsg, "[�j���I�Lñ���B�z]:�^��cm_pre_receive���ѡG�O�渹[%s]", chk_ipolicy);
	        WRITELOG( sfp, sErrMsg);
	        GetMsg(chk_ipolicy,sErrMsg);
	        continue;
            }

 	    printf("pre_chk_comp() �w�^��ñ��� �O�渹[%s]\n ",chk_ipolicy);
	    iCount ++;
	}
	else
	{
            sprintf_s( sErrMsg, sizeof sErrMsg,"[�j���I�Lñ���B�z]:���D��-�j���I�O�渹[%s]�Lñ���", chk_ipolicy);
            WRITELOG( sfp, sErrMsg);
            GetMsg(chk_ipolicy,sErrMsg);
            continue;
	}

    }
    $CLOSE cur_comp;
    $FREE  cur_comp;
    $COMMIT WORK;

    printf("pre_chk_comp() �Lñ����`���= iCountTot[%d]\n ",iCountTot);
    printf("pre_chk_comp() �w�^��ñ����� = iCount[%d]\n ",iCount);
    printf("--- pre_chk_comp() ���� ---\n ");

    return M_CM_OK;

pre_chk_err:

    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    $WHENEVER SQLERROR CONTINUE;
    $FREE cur_comp;
    $COMMIT WORK;

    sprintf_s( sErrMsg,sizeof sErrMsg, "[�j���I�Lñ���B�z] Error�G�O�渹[%s] SQLCODE[%d] SQLERRMSG[%s],", chk_ipolicy,SQLCODE,sqlca.sqlerrm);
    WRITELOG( sfp, sErrMsg);
    return M_CM_OK;
}

long GetMsg(iply,v_sMsg1)
$char  iply[21],v_sMsg1[256];
{
	strcpy(iply,trim(iply));
	strcpy(v_sMsg1,trim(v_sMsg1));

	printf("iply[%s],v_sMsg1[%s]\n",iply,v_sMsg1);
	
	if(strlen(trim(iply)) == 0)
		strcpy(iply," ");
	else if (strlen(trim(iply)) > 20)
		iply[20]='\0';

	if(strlen(trim(v_sMsg1)) == 0)
		strcpy(v_sMsg1," ");
	else if (strlen(trim(v_sMsg1)) > 255)
		v_sMsg1[255]='\0';
	
	$INSERT INTO ca_close_log
		(ipolicy,nreason,dcreate)
	 VALUES ($iply,$v_sMsg1,today);

}