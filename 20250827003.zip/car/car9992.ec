/*********************************************/
/* Copyright (C) 1995 Intellisys Corporation */
/*                                           */
/* Program : car9992.ec                      */
/*           ��o�i���߸�ƳB�z�j����      */
/* Author  : Johnny Kuo                      */
/*           S.Y.HWANG                       */
/*********************************************/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "api_xsrv.h"
#include "sqlfatal.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"

#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "car_common.h"
#include "safeclib.h"

/* standard data declaration */
 char   FormTp[3];
 int    TotRows=0;

/* end of standard data */

$char   localdb[5],Taipei_FullName[20];
 int    i=0, flag_check=0;
/* end of standard defined data */

 $char userid[11], iquota[7];
 char   prtfile[80],outputf[80],outputf1[80],tmp_outputf[21];
 char   errmsg[200];
 char   option[2];
 long   car9992_build();

 char   expdate[6];
 char   bgndate[10],enddate[10];
 FILE   *fptr, *fptr_err;
$char   errFile[120];
$static char remotedb[DBNAME];
$char data_yyyymm[7];

int   count_db=0,k=0; 

$char DBName[05];
$char msgbuf[128];
DBinfo *list;
char  sApHome[30];
int   rtncode=0,rc=0;
char  filename[30];
FILE  *fp;
char  file_catalog[200];
$char filename1[200];

$char iproduct_tmp[3];
$long mprem_14 = 0,mprem_15 = 0,mprem_16 = 0,mprem_32 = 0;
$long mprem_pure_14 = 0,mprem_pure_15 = 0,mprem_pure_16 = 0,mprem_pure_32 = 0;

long car9992_get_db();
long car9992_build();
long car9992_final();
/*************************************************************/
main(argc,argv)
int argc;
char **argv;
{
   int rtncode,rc;

	strcpy(DBName, isNULLstr(argv[1]));
	strcpy(userid, isNULLstr(argv[2]));
	strcpy(expdate,isNULLstr(argv[3]));
	strcpy(outputf,isNULLstr(argv[4]));

	printf("DBName[%s],userid[%s],expdate[%s],outputf[%s] \n",DBName,userid,expdate,outputf);

	rc = car9992_get_db();
	if (rc != M_CM_OK)
	{
		return rc;
	}

	rc = car9992_build();
	if ( rc != SUCCESS ) {
	 	printf("error on car9991_build \n");
	 	EWRITE(userid, rc, errmsg);
		return rc;	
	}

	rc = car9992_final();
	if ( rc != SUCCESS ) {
	 	printf("error on car9991_show \n");
	 	EWRITE(userid, rc, errmsg);
		return rc;	
	}
}

long car9992_get_db()
{
	$whenever sqlerror goto errexit1;

	if (db_select(DBName) == DBName) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}
	
	rc = getApHome(sApHome);
	if (rc < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		EWRITE(userid,rc,msgbuf);
	 	return rc;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}	
	return M_CM_OK;

errexit1:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}

long car9992_build()
{
	$long  dwritten_l=0,dendorse=0;
	$long  dpolicy=0;
	$char  dpolicy_c[11];
	$char  ipolicy[POLICY_NUM_1],icard[CARD_NUM],iendorse[ENDORSE_NUM];
	char   iendorse_tmp1[2],iendorse_tmp2[7];
	$char  dpolicy_str[9];
	$char  dpolicy_eng[11];
	/*     $char  icode[11];*/
	$char  product_kind[3];
	$char  drate_yyyymm[7];
	$char  ilicense[11],fsex[2],fmarriage[2],icar_type[3],iply_area[3];
	$char  ibrand[9],ibrand_new[9],iedr_type[3],iengine[CA_ENGINE_NUM],ibody[CA_BODY_NUM],itag[CA_TAG_NUM],drate_ym[5];
	$char  iengine_tmp[CA_ENGINE_NUM],ibody_tmp[CA_BODY_NUM];
	$char  iissue_ym[6],ipro_year[5], qpt_tmp[6], fpt[2], iassured[11];
	$char  fcomp[3],fcomp_last[3], adjcom_tmp[11], business_tmp[11];
	$long  dedr_begin=0,dedr_end=0,medrdea_cover=0,medrdmg_cover=0,medrins_prem=0,medrpure_prem=0,dply_begin=0, dply_end=0;
	$char  sBgndate[YYYYMMDD], sEnddate[YYYYMMDD],iproduct[13],fcar_class[2];
	$double qpt=0, medr_adjcom=0, medr_business=0, medr_maintain=0;
	long   medr_adjcom_l=0;
	$int   qcylinder,qply_period,qperiod;
	$char  stmt_buf1[2048], stmt_buf2[2048], stmt_buf3[2048];
	char   dedr_begin_c[11],dedr_end_c[11],medrdea_cover_c[9],medrdmg_cver_c[9];
	char   qcylinder_c[6], tmpStr[10],dply_begin_c[11], dply_end_c[11];
	$char   qply_period_c[3],dendorse_c[11],iissue_yy[5];
	char   dedr_begin_yy[5],dedr_begin_mm[3],dedr_begin_dd[3],tmp_bgyy[4];
	char   dply_begin_yy[5],dply_begin_mm[3],dply_begin_dd[3];
	char   dply_end_yy[5], dply_end_mm[3], dply_end_dd[3];
	char   dedr_end_yy[5],dedr_end_mm[3],dedr_end_dd[3],tmp_edyy[4];
	$char   dedr_yy[5],dedr_mm[3],ibirth[9], tmp_yy[5];
	$char  ipolicy_no[14],ipolicy_br[3],iendorse_br[3],prtstr[309];
	char   icard_no[13], iendorse_no[14], imark[5];
	char   bgn_yy[5],bgn_mm[3],end_mm[3],tmp_dd[3];
	int    endyy=0,endmm=0,tmp_year=0;
	$long  prem_total=0, count1=0;
	$double pure_total;
	$char   prem_c[13],cmdbuf[100],buf1[100],stmt22[1024];
	long   iedr_type_l=0, iissue_yyyy=0;
	char   iedr_type_c[3];
	$char  drate[11],drate_c[11],ttday[20];
	char   drate_yy[5],drate_mm[3],drate_dd[3],ttday_yy[5],ttday_mm[3],ttday_dd[3];
	long   begin_yy_l=0,begin_mm_l=0,end_yy_l=0,end_mm_l=0;
	$char  chk_dpolicy[2];
	
	int    i=0, j=0, s_branch_cnt=0;
	int    res=0,business_flag=0;
	$char   aphome[40],stmt[1000];
	$static date   Today;
	char   sTmp_buf[21];
	$char  sFassured[2];
	$char  ibroker[11], fbusiness[2],ibroker_top[11],bzfrom[3];
	$char  ibrand6[7];
	$int   cnt=0;
	$double mcompensation, mstable;
	$double tot_mcompensation, tot_mstable;
	
	$int qdrunk_driving=0;
	$long mdrunk_prem=0;
	$double mdrunk_pure_prem=0;
	$long  mdrunk_pure_prem_l=0;
	$double tot_mdrunk_pure_prem,tot_mdrunk_pure_prem_tmp;
	
	$long medr_prem;
	
	$char terminate_rsn[2],fedr_class[2];
	
	$int f_bgn_10811 = 0,cnt_L = 0;
	$char fcar_kind[2],irelative_ply[21];
	$char PLY_DB[31],iply_db[31];
	$char stmtt[2048];
	$char stmp[512];
	
	/* ca_dev_ply_edr_comp */
	$char  t_data_yyyymm[7],t_idata[2],t_ipolicy[21],t_icard_company[3],t_icard_br[3],t_icard[16],t_icard_last_company[3],t_icard_last_br[3],t_icard_last[13];
	$char  t_iedr_company[3],t_iedr_br[3],t_iendorse[14],t_iarea[3],t_dedr_begin[9],t_dedr_end[9],t_dply_begin[9],t_dply_end[9],t_iobjno[5],t_iissue_year[5],t_ipro_year[5],t_ibrand[9];
	$char  t_icar_type[3],t_icar_type_no[3],t_iengine[26],t_itag[13],t_fpt[2],t_fassured[2],t_iassured[11],t_dbirth[9],t_fsex[2],t_fmarriage[2];
	$char  t_fcomp_class_last[3],t_fcomp_class[3],t_iedr_type[3];
	$char  t_iproduct[13],t_drate_ym[7],t_dpolicy_ym[7],t_bzfrom[3],t_dsend[9];
	$long  t_qcylinder=0,t_qpt=0,t_qdrunk_driving=0,t_mprem=0,t_mins_premium=0,t_mdrunk_prem=0;
	$double t_madjcom_prem,t_mbusiness,t_maintain,t_mcompensation,t_mstable,t_mdrunk_pure_prem;
	
	filename[0] = '\0';
	file_catalog[0] = '\0';
	sprintf_s(filename, sizeof filename,"%s/rptftp/", sApHome);
	sprintf_s(filename1, sizeof filename1,"AUTOE17_%d.txt",atoi(expdate)+191100);
	strcpy(file_catalog, trim(filename));
	strcat(file_catalog, trim(filename1));
	printf("file_catalog[%s] \n",file_catalog);

	if ((fptr=fopen(file_catalog,"w")) == NULL)
	{
		sprintf_s(errmsg, sizeof errmsg,"Cannot open print file:%s",outputf);
		return M_CM_OPEN_FILE_FAIL;
	}

	printf(">>>expdate=%s\n",expdate);
	
	strncpy(bgn_yy,&expdate[0],3); bgn_yy[3]='\0';
	strncpy(bgn_mm,&expdate[3],2); bgn_mm[2]='\0';
	
	if (strncmp(bgn_mm, "12",2) == 0)
	{
		endyy=atoi(bgn_yy)+1;
		endmm=1;
	}
	else
	{
		endyy=atoi(bgn_yy);
		endmm=atoi(bgn_mm)+1;
	}
	rfmtlong(endmm,"&&",end_mm);

	sprintf_s(bgndate, sizeof bgndate,"%s/%s/%s",bgn_yy,bgn_mm,"01");
	sprintf_s(enddate, sizeof enddate,"%d/%s/%s",endyy,end_mm,"01");
	sprintf_s(data_yyyymm, sizeof data_yyyymm,"%s%s",itoa(atoi(bgn_yy)+1911),bgn_mm);
	
	printf(">>>bgndate=[%s] enddate=[%s]\n", bgndate, enddate);
	
	EXEC SQL WHENEVER SQLERROR GOTO errexit;
	
	strcpy(sBgndate, cm_to_infdate(bgndate));
	strcpy(sEnddate, cm_to_infdate(enddate));
	
	printf(">>>sBgndate=[%s] sEnddate=[%s]\n", sBgndate, sEnddate);
	
	/* c295-296 ��ƻs�e��� */
	strcpy(ttday , cm_get_sysd());
	strncpy(ttday_yy,&ttday[0],4); ttday_yy[4] = '\0';
	strncpy(ttday_mm,&ttday[5],2); ttday_mm[2] = '\0';
	strncpy(ttday_dd,&ttday[8],2); ttday_dd[2] = '\0';

	prem_total=0; count1=0;  pure_total=0.0;
	tot_mcompensation=0;tot_mstable=0;
	tot_mdrunk_pure_prem = 0;
     
	for(k=0;k<count_db;k++)
	{
		
		sprintf_s(stmt, sizeof stmt,"DELETE FROM %s:ca_dev_ply_edr_comp WHERE data_yyyymm = '%s' AND idata = 'E'",list[k].dbname,data_yyyymm);
		$PREPARE DE_ca_dev_ply_edr_comp FROM $stmt;
		$EXECUTE DE_ca_dev_ply_edr_comp;
		
		/***** prepare cursor for select edr_relation *****/
		sprintf_s(stmt_buf1, sizeof stmt_buf1,"SELECT %s %s %s %s FROM %s:%s %s %s %s %s",
		                  "ipolicy,icard,iendorse,dedr_begin,dedr_end,dendorse,",
		                  "ipro_year,ibrand,icar_type,ibroker,",
		                  "medr_adjcom,medr_business,(medr_maintain + medr_research),fcomp_class,fcomp_class_last,",
		                  "medr_compensate,medr_stable,bzfrom,qdrunk_driving,terminate_rsn,fedr_class,nvl(irelative_ply,'') ",
		                  list[k].dbname,"edr_relation ",
		                  "WHERE ((fcard_class = '1' ",
		                  "AND dendorse >= ? AND dendorse < ? )",
		                  "OR (iendorse IN (SELECT iendorse FROM ca_develop_claim_policy WHERE dgroup >= ? AND dgroup < ?))) AND fedr_class not in ('3')",
		                  "ORDER BY iendorse");
		EXEC SQL PREPARE CUR_STMT1 FROM :stmt_buf1;
		EXEC SQL DECLARE scur_edr CURSOR FOR CUR_STMT1;
		printf("stmt1[%s]\n",stmt_buf1);
	
		/***** prepare cursor for select endorsement *****/
		/* 0991022002�]�����F�������X�֭p�� */
		/* 1.���a�ϥN����42�u�x�����v�A�h�վ㬰41�u�x�����v */
		/* 2.���a�ϥN����63�u�x�n���v�A�h�վ㬰62�u�x�n���v */
		/* 3.���a�ϥN����65�u�������v�A�h�վ㬰64�u�������v */
		sprintf_s(stmt_buf2, sizeof stmt_buf2,"SELECT %s %s %s FROM %s:%s %s",
		                  "iassured,ilicense,YEAR(dissue),to_char(dbirth,'%Y%m%d'),fsex,fmarriage,",
		                  "DECODE(iply_area,'42','41','63','62','65','64',iply_area),qcylinder,iengine,ibody,itag,qply_period,",
		                  "qpt, fpt, fassured, dply_begin, dply_end, (CASE WHEN dply_begin >= '11/01/2019' THEN 1 ELSE 0 END) ",
		                  list[k].dbname,"endorsement",
		                  "WHERE iendorse = ?");
		EXEC SQL PREPARE CUR_STMT2 FROM :stmt_buf2;
		EXEC SQL DECLARE scur_endorse CURSOR FOR CUR_STMT2;
		printf("stmt2[%s]\n",stmt_buf2);
		
		/***** prepare cursor for select edr_ins_type *****/
		sprintf_s(stmt_buf3, sizeof stmt_buf3,"SELECT %s %s FROM %s:%s %s",
		                  "iedr_type,medrdea_cover,medrdmg_cover,medrins_prem,medrpure_prem,",
		                  "drate_ym, iproduct,mdrunk_prem,mdrunk_pure_prem,medr_prem",
		                  list[k].dbname,"edr_ins_type",
		                  "WHERE iendorse=? ");
		EXEC SQL PREPARE CUR_STMT3 FROM :stmt_buf3;
		EXEC SQL DECLARE scur_edr_ins_a1 CURSOR FOR CUR_STMT3;
		printf("stmt[%s]\n",stmt_buf3);
		
		/***** prepare cursor for select ca_car_model *****/
		/* 1000530002�t�P�����N���H�ഫ�t�P�����N�����e */
		sprintf_s(stmt, sizeof stmt, "SELECT ibrand_new "
		              "  FROM ca_car_model "
		              " WHERE ibrand = ? "
		              "   AND ibrand_new != ' ' "
		              " ORDER BY drate DESC;");
		$PREPARE pr_ibrand FROM $stmt;
		$DECLARE cur_ibrand CURSOR FOR pr_ibrand;
		printf("stmt[%s]\n", stmt);
		
		EXEC SQL OPEN scur_edr USING :sBgndate , :sEnddate , :sBgndate , :sEnddate;

		while (1)
		{
			EXEC SQL FETCH scur_edr
			          INTO :ipolicy  , :icard      , :iendorse    , :dedr_begin ,
			               :dedr_end , :dendorse   , :ipro_year ,
			               :ibrand   , :icar_type  , :ibroker     , :medr_adjcom , :medr_business ,
			               :medr_maintain, :fcomp    , :fcomp_last,
			               :mcompensation, :mstable, :bzfrom, :qdrunk_driving, :terminate_rsn , :fedr_class,
			               :irelative_ply;
			if (SQLCODE == SQLNOTFOUND) break;
			
			strcpy(icar_type,TRANS_CAR_TYPE(icar_type));
			strcpy(icar_type,trim(icar_type));
			strcpy(iply_db,get_car_full_db(ipolicy));
			
			EXEC SQL OPEN scur_endorse USING :iendorse;
			EXEC SQL FETCH scur_endorse
			          INTO :iassured    , :ilicense  , :iissue_yy, :ibirth , :fsex  , :fmarriage,
			               :iply_area   , :qcylinder , :iengine   , :ibody , :itag,
			               :qply_period , :qpt, $fpt , :sFassured , :dply_begin, :dply_end, :f_bgn_10811;
			              
			if (SQLCODE == SQLNOTFOUND)
			{
			EXEC SQL CLOSE scur_endorse;
			continue;
			}
			EXEC SQL CLOSE scur_endorse;
			
			EXEC SQL OPEN  scur_edr_ins_a1 USING :iendorse;
			EXEC SQL FETCH scur_edr_ins_a1 INTO  :iedr_type , :medrdea_cover , :medrdmg_cover,
			                                     :medrins_prem ,:medrpure_prem, :drate_ym,
			                                     :iproduct , :mdrunk_prem , :mdrunk_pure_prem, :medr_prem;
			
			if (SQLCODE==SQLNOTFOUND)
			{
				EXEC SQL CLOSE scur_edr_ins_a1;
				/*continue;*/
				strcpy(iedr_type,"S");
				medrdea_cover = 0;
				medrins_prem = 0;
				medrpure_prem = 0;
				mdrunk_prem = 0;
				mdrunk_prem = 0;
				mdrunk_pure_prem = 0;
				medr_prem = 0;
				
				sprintf_s(stmt22, sizeof stmt22,"SELECT drate_ym FROM %s:ply_ins_type \
				                 WHERE ipolicy = '%s'",iply_db,ipolicy);
				$PREPARE ply_drate_ym FROM $stmt22;
				$EXECUTE ply_drate_ym INTO $drate_ym;
				
				rc = get_iproduct_car("21",icar_type,iproduct,"	",drate_ym);
				if (rc != M_CM_OK) strcpy(iproduct,"xxxxxxxxxxxx");
			}
			EXEC SQL CLOSE scur_edr_ins_a1;
			
			prem_total += medrins_prem;
			/* pure_total += medr_adjcom;  */
			tot_mcompensation += mcompensation;
			tot_mstable += mstable;
			
			strcpy(drate_ym, trim(drate_ym));
			strcpy(ipolicy, trim(ipolicy));
			
			/* �O�渹�X */
			/* c1-2 ���q�N�� �ݨ̤��q��� */
			strcpy(prtstr, CAR_COMPANY);
			strcpy(t_icard_company,CAR_COMPANY);
			
			/* c3-4 ������c�N�� */
			strncpy(ipolicy_br,&ipolicy[0],2); ipolicy_br[2]='\0';
			if (ipolicy_br[0]=='\0')
			{
				strcat(prtstr,"  ");
				strcpy(t_icard_br," ");
			}
			else
			{
				strcat(prtstr,ipolicy_br);
				strcpy(t_icard_br,ipolicy_br);
			}
			
			/* c5-19 �O�渹�X */
			strncat(prtstr, icard, 15);
			strncpy(t_icard, icard, 15);
			prtstr[19] = '\0';
			
			/* ��渹�X */
			/* c20-21 ���q�N�� �ݨ̤��q��� */
			strcat(prtstr,CAR_COMPANY);
			strcpy(t_iedr_company,CAR_COMPANY);
			
			/* c22-23 ������c�N�� */
			strncpy(iendorse_br,&iendorse[0],2); iendorse_br[2]='\0';
			if (iendorse_br[0]=='\0')
			{
				strcat(prtstr,"  ");
				strcpy(t_iedr_br," ");
			}
			else
			{
				strcat(prtstr,iendorse_br);
				strcpy(t_iedr_br,iendorse_br);
			}
			
			/* c24-36 ��渹 */
			strncpy(iendorse_no, iendorse, 13); iendorse_no[13]='\0';
			strcat(prtstr, iendorse_no);
			strcpy(t_iendorse,iendorse_no);
			
			/* c37-38 �ӫO�a�� */
			if (iply_area[0]=='\0')
			{
				strcat(prtstr,"  ");
				strcpy(t_iarea," ");
			}
			else
			{
				strcat(prtstr,iply_area);
				strcpy(t_iarea,iply_area);
			}
			
			/* c39-46 ���ͮĩl�� */
			strcpy(dedr_begin_c,cm_cdate_str_100(dedr_begin));
			cm_split_ymd_100(dedr_begin_c,dedr_begin_yy,dedr_begin_mm,dedr_begin_dd);
			
			if (dedr_begin_yy[0] == '\0' ) 
			{
				strcat(prtstr,"0000");
				strcpy(t_dedr_begin,"0000");
			}
			else 
			{
				strcat(prtstr,itoa(1911+(atoi(dedr_begin_yy))));
				strcpy(t_dedr_begin,itoa(1911+(atoi(dedr_begin_yy))));
			}
			
			if (dedr_begin_mm[0] == '\0')
			{
				strcat(prtstr,"00");
				strcat(t_dedr_begin,"00");
			}
			else
			{
				strcat(prtstr,dedr_begin_mm);
				strcat(t_dedr_begin,dedr_begin_mm);
			}
			
			if (dedr_begin_dd[0] == '\0')
			{
				strcat(prtstr,"00");
				strcat(t_dedr_begin,"00");
			}
			else
			{
				strcat(prtstr,dedr_begin_dd);
				strcat(t_dedr_begin,dedr_begin_dd);
			}
			
			/* c47-54 ���ͮĲ״� */
			strcpy(dedr_end_c,cm_cdate_str_100(dedr_end));
			cm_split_ymd_100(dedr_end_c,dedr_end_yy,dedr_end_mm,dedr_end_dd);
			
			if (dedr_end_yy[0] == '\0' ) 
			{
				strcat(prtstr,"0000");
				strcpy(t_dedr_end,"0000");
			}
			else 
			{
				strcat(prtstr,itoa(1911+(atoi(dedr_end_yy))));
				strcpy(t_dedr_end,itoa(1911+(atoi(dedr_end_yy))));
			}
			
			if (dedr_end_mm[0] == '\0')
			{
				strcat(prtstr,"00");
				strcat(t_dedr_end,"00");
			}
			else
			{
				strcat(prtstr,dedr_end_mm);
				strcat(t_dedr_end,dedr_end_mm);
			}
			
			if (dedr_end_dd[0] == '\0')
			{
				strcat(prtstr,"00");
				strcat(t_dedr_end,"00");
			}
			else
			{
				strcat(prtstr,dedr_end_dd);
				strcat(t_dedr_end,dedr_end_dd);
			}
			
			/* C55 - 62 �O�I�ͮĤ��   */
			/* C63 - 70 �O�I�ͮĨ��   */
			strcpy(dply_begin_c,cm_cdate_str_100(dply_begin));
			cm_split_ymd_100(dply_begin_c,dply_begin_yy,dply_begin_mm,dply_begin_dd);
			
			if(dply_begin_yy[0] == '\0') 
			{
				strcat(prtstr,"0000");
				strcpy(t_dply_begin,"0000");
			}
			else 
			{
				strcat(prtstr,itoa(1911+(atoi(dply_begin_yy))));
				strcpy(t_dply_begin,itoa(1911+(atoi(dply_begin_yy))));
			}
			
			if (dply_begin_mm[0] == '\0')
			{
				strcat(prtstr,"00");
				strcat(t_dply_begin,"00");
			}
			else
			{
				strcat(prtstr,dply_begin_mm);
				strcat(t_dply_begin,dply_begin_mm);
			}
			
			if (dply_begin_dd[0] == '\0')
			{
				strcat(prtstr,"00");
				strcat(t_dply_begin,"00");
			}
			else
			{
				strcat(prtstr,dply_begin_dd);
				strcat(t_dply_begin,dply_begin_dd);
			}
			
			strcpy(dply_end_c,cm_cdate_str_100(dply_end));
			cm_split_ymd_100(dply_end_c,dply_end_yy,dply_end_mm,dply_end_dd);
			
			if(dply_end_yy[0] == '\0')
			{
				strcat(prtstr,"0000");
				strcpy(t_dply_end,"0000");
			}
			else 
			{
				strcat(prtstr,itoa(1911+(atoi(dply_end_yy))));
				strcpy(t_dply_end,itoa(1911+(atoi(dply_end_yy))));
			}
			
			if (dply_end_mm[0] == '\0')
			{
				strcat(prtstr,"00");
				strcat(t_dply_end,"00");
			}
			else
			{
				strcat(prtstr,dply_end_mm);
				strcat(t_dply_end,dply_end_mm);
			}
			
			if (dply_end_dd[0] == '\0')
			{
				strcat(prtstr,"00");
				strcat(t_dply_end,"00");
			}
			else
			{
				strcat(prtstr,dply_end_dd);
				strcat(t_dply_end,dply_end_dd);
			}
			
			/* car950512 */
			/* c71-74 �O�I�Ъ��s��,�j�O�����17 */
			if (strlen(trim(ipolicy)) >= 17)
			{
				strncpy(imark, ipolicy+CAR_POLICY_LEN, CAR_TARGET_LEN);
				imark[CAR_TARGET_LEN]='\0';
				if (imark[0]=='\0')
				{
					strcat(prtstr,"0001");
					strcpy(t_iobjno,"0001");
				}
				else
				{
					strcat(prtstr,imark);
					strcpy(t_iobjno,imark);
				}
			}
			else
			{
				strcat(prtstr,"0001");
				strcpy(t_iobjno,"0001");
			}
			
			/* c75-78 ��l�o�Ӧ~(�褸) */
			if (iissue_yy[0] == '\0' ) 
			{
				strcat(prtstr,"0000");
				strcpy(t_iissue_year,"0000");
			}
			else 
			{
				iissue_yyyy = atoi(iissue_yy);
				rfmtlong(iissue_yyyy,"&&&&",tmp_yy);
				strcat(prtstr,tmp_yy);
				strcpy(t_iissue_year,tmp_yy);
			}
			printf("prtstr[%s]\n",prtstr);
			prtstr[78]='\0';    
			
			/* c79-82 �s�y�~��(�褸) */
			if (ipro_year[0] == '\0')
			{
				strcat(prtstr,"0000");
				strcpy(t_ipro_year,"0000");
			}
			else
			{
				strcat(prtstr,ipro_year);
				strcpy(t_ipro_year,ipro_year);
			}
			
			/* 1000530002�t�P�����N���H�ഫ�t�P�����N�����e */
			ibrand_new[0]='\0';
			$OPEN cur_ibrand USING $ibrand;
			$FETCH cur_ibrand INTO $ibrand_new;
			if (ibrand_new[0]!='\0') strcpy(ibrand, ibrand_new);
			$CLOSE cur_ibrand;
			printf("ibrand[%s]ibrand_new[%s]\n", ibrand, ibrand_new);
			
			/* c83-90 �t�P�����N�� */
			if(strncmp(ibrand,"151001",6)==0) strcpy(ibrand,"15010100");
			if(strncmp(ibrand,"090737",6)==0) strcpy(ibrand, "09013700");
			if(strncmp(ibrand,"561002",6)==0) strcpy(ibrand, "56081900");
			if(strncmp(ibrand,"561001",6)==0) strcpy(ibrand, "56080110");
			if(strncmp(ibrand,"MF0002",6)==0)  strcpy(ibrand, "ME000200");
			if( (strncmp(ibrand,"MR0001",6)==0) || (strncmp(ibrand,"MT0001",6)==0) ) strcpy(ibrand, "MM000100");
			
			/* �O�o�������t�P�����e6�X */
			strncpy(ibrand6, ibrand, 6);
			ibrand6[6]='\0';
			$SELECT COUNT(*)
			   INTO $cnt
			   FROM cu_code_data
			  WHERE itype='B9'
			    AND icode=$ibrand6;
			if (cnt>0)
			{
				/* 2010�X�� */
				sprintf_s(stmt, sizeof stmt,"SELECT count(*) FROM %s:ori_ply_relation WHERE ipolicy = '%s' AND dpolicy>='01/01/2010' ",iply_db,ipolicy);
				printf("stmt[%s]\n",stmt);
				$PREPARE ply_20100101 FROM $stmt;
				$EXECUTE ply_20100101 INTO $cnt;
				if (cnt>0) ibrand[4]=ibrand[5]='0';
			}
			
			if (ibrand[0] == '\0')
			{
				strcat(prtstr,"        ");
				strcpy(t_ibrand," ");
			}
			else 
			{
				strcat(prtstr,ibrand);
				strcpy(t_ibrand,ibrand);
			}
			
			prtstr[90]='\0';
			/* c91-92 �������� */
			if (icar_type[0] == '\0')
			{
				strcat(prtstr,"00");
				strcpy(t_icar_type,"00");
			}
			else if (strcmp(trim(icar_type),"51") == 0)
			{
				strcat(prtstr,"34");
				strcpy(t_icar_type,"34");
			}
			else
			{
				strcat(prtstr,icar_type);
				strcpy(t_icar_type,icar_type);
			}
			
			/* c93-94 �����������O */
			if (f_bgn_10811 > 0)
			{
				if((strcmp(icar_type,"01") == 0) || (strcmp(icar_type,"02") == 0) || (strcmp(icar_type,"32") == 0) || (strcmp(icar_type,"34") == 0))
				{	
					strcpy(irelative_ply,trim(irelative_ply));
					if (strcmp(irelative_ply,"") != 0)
					{
						strcpy(PLY_DB,get_car_full_db(irelative_ply));
						sprintf_s(stmtt, sizeof stmtt,"SELECT count(*) FROM %s:ply_ins_type WHERE ipolicy = '%s' AND (provision = 'L' OR provision matches '*;L*' OR provision matches '*L;*') ",PLY_DB,irelative_ply);
						printf("stmtt[%s]\n",stmtt);
						$PREPARE ply_L FROM $stmtt;
						$EXECUTE ply_L INTO $cnt_L;
					}
					else 
						cnt_L = 0;
						
					if (cnt_L > 0) 
					{
						strcat(prtstr,"02");
						strcpy(t_icar_type_no,"02");
					}
					else 
					{	
						strcat(prtstr,"01");
						strcpy(t_icar_type_no,"01");
					}
				}
				else if ((strcmp(icar_type,"07") == 0) || (strcmp(icar_type,"15") == 0))
				{
					$SELECT FIRST 1 nvl(fkind,'')
					   INTO $fcar_kind
					   FROM ca_taxi_type
					  WHERE icard = $icard
					  ORDER BY dupdate DESC;
					if (SQLCODE == SQLNOTFOUND) strcpy(fcar_kind,"N");
					
					if(strcmp(fcar_kind,"Y") == 0)
					{
						strcat(prtstr,"04");
						strcpy(t_icar_type_no,"04");
					}
					else 
					{
						strcat(prtstr,"03");
						strcpy(t_icar_type_no,"03");
					}
				}
				else 
				{
					strcat(prtstr,"00");
					strcpy(t_icar_type_no,"00");
				}
			}
			else 
			{
				strcat(prtstr,"00");
				strcpy(t_icar_type_no,"00");
			}
			prtstr[94]='\0';
			
			/* c95-99 �Ʈ�q */
			if( (strcmp(ibrand,"E8013601")==0) && (qcylinder < 40) )
			qcylinder = 40;
			if( (strcmp(ibrand,"E8020601")==0) && (qcylinder < 40) )
			qcylinder = 40;          
			rfmtlong(qcylinder,"&&&&&",qcylinder_c);
			strcat(prtstr,qcylinder_c);
			t_qcylinder = qcylinder;
			
			/* c100-124 ����or������ */
			strcpy(iengine_tmp,trim(iengine));
			strcpy(ibody_tmp,trim(ibody));
			if (iengine_tmp[0] == '\0'&& ibody_tmp[0]=='\0') 
			{
				strcat(prtstr,"                         ");
				strcpy(t_iengine," ");
			}
			else 
			{
				if(iengine_tmp[0] != '\0')
				{
					strcat(prtstr, iengine);
					strcpy(t_iengine,iengine);
				}
				else
				{
					strcat(prtstr, ibody);
					strcpy(t_iengine,ibody);
				}
			}
			
			prtstr[124]='\0';
			
			sprintf_s(stmp, sizeof stmp,"SELECT case when dpolicy < '08/01/2016' then 'Y' else 'N' end \
			                FROM %s:ori_ply_relation WHERE ipolicy = '%s' ",iply_db,ipolicy);
			$PREPARE ply_1070801 FROM $stmp;
			$EXECUTE ply_1070801 INTO $chk_dpolicy;
			
			/* c125-136 �W���P�Ӹ��X */
			if (itag[0] == '\0' || (strcmp(icar_type,"27") == 0 && strcmp(chk_dpolicy,"Y") == 0))
			{
				strcat(prtstr,"            ");
			}
			else
			{
				strcat(prtstr,itag);
			}
			prtstr[136]='\0';
			/* c137-148 �����P�Ӹ��X */
			if (itag[0] == '\0' || (strcmp(icar_type,"27") == 0 && strcmp(chk_dpolicy,"Y") == 0))
			{
				strcat(prtstr,"            ");
				strcpy(t_itag," ");
			}
			else
			{
				strcat(prtstr,itag);
				strcpy(t_itag,itag);
			}
			prtstr[148]='\0';
			
			/* �������� */
			rfmtdouble((qpt*10),"&&&&", qpt_tmp);
			/*C149-152:�����ƶq*/
			if ((strlen(rtrim(qpt_tmp))) == 0)
			{
				strcat(prtstr,"0050");
				t_qpt = 50;
			}
			else
			{
				strcat(prtstr,qpt_tmp);
				t_qpt = qpt;
			}
			
			/*C153-153:�������*/
			if (fpt[0]=='\0' || fpt[0] == ' ')
			{
				strcat(prtstr,"P");
				strcpy(t_fpt,"P");
			}
			else
			{
				strcat(prtstr,fpt);
				strcpy(t_fpt,fpt);
			}
			prtstr[153]='\0';           
			
			/* �Q�O�I�H��� */
			if (strcmp(sFassured, "1") == 0||strcmp(sFassured, "3") == 0||strcmp(sFassured, "5") == 0)
			{  
				 /* �۵M�H */
				/* car950512 */
				/* C154-154���� */
				if( sFassured[0] == '1' )
				{
					strcat(prtstr, "1");
					strcpy(t_fassured,"1");
				}
				else if( sFassured[0] == '3' )
				{
					strcat(prtstr, "2");
					strcpy(t_fassured,"2");
				}
				else if( sFassured[0] == '5' )
				{
					strcat(prtstr, "8");
					strcpy(t_fassured,"8");
				}
				else
				{
					strcat(prtstr, "1");
					strcpy(t_fassured,"1");
				}
				
				/* c155-164 �Q�O�I�H�����Ҹ��X */
				strcat(prtstr, rtrim(iassured));
				strcpy(t_iassured,iassured);
				for(i=0 ; i < (10-strlen(rtrim(iassured))); i++)
				strcat(prtstr, " ");
				/* c165-172 �Q�O�I�H�X�ͤ��:�褸�~ */
				if ((strlen(rtrim(ibirth))) == 0)
				{
					strcat(prtstr, "00000000");
					strcpy(t_dbirth,"00000000");
				}
				else
				{
					strcat(prtstr,rtrim(ibirth));
					strcpy(t_dbirth,ibirth);
					for(i=0 ; i < (8-strlen(rtrim(ibirth))); i++) strcat(prtstr, " ");
				}
				
				/* c173-173 �Q�O�I�H�ʧO */
				if (strlen(rtrim(fsex)) == 0)
				{
					strcat(prtstr, "0");
					strcpy(t_fsex,"0");
				}
				else
				{
					strcat(prtstr, rtrim(fsex));
					strcpy(t_fsex,fsex);
				}
				
				/* c174-174 �Q�O�I�H�B�çO */
				if (strlen(rtrim(fmarriage)) == 0)
				{
					strcat(prtstr, "0");
					strcpy(t_fmarriage,"0");
				}
				else
				{
					strcat(prtstr, rtrim(fmarriage));
					strcpy(t_fmarriage,fmarriage);
				}
			}
			else
			{   
				/* �k�H */
				/* car950512 */
				if (strlen(trim(iassured)) == 8)
				{
					strcat(prtstr, "3");
					strcpy(t_fassured,"3");
					strcat(prtstr, rtrim(iassured));
					for(i=0 ; i < (10-strlen(rtrim(iassured))); i++)
					strcat(prtstr, " ");
					strcat(prtstr, "00000000");
				}
				else
				{
					/* car950512 */
					strcat(prtstr,"9");
					strcpy(t_fassured,"9");
					strcat(prtstr, rtrim(iassured));
					for(i=0 ; i < (10-strlen(rtrim(iassured))); i++)
					strcat(prtstr, " ");
					/* c155-164 �Q�O�I�H�����Ҹ��X */
					/*strcat(prtstr, "AAAAAAAAAA");*/
					/* c165-172 �Q�O�I�H�X�ͤ��:�褸�~ */
					strcat(prtstr, "00000000");
				}
				/* c173-173 �Q�O�I�H�ʧO */
				strcat(prtstr, "0");
				/* c174-174 �Q�O�I�H�B�çO */
				strcat(prtstr, "0");

				strcpy(t_iassured,rtrim(iassured));
				strcpy(t_dbirth,"00000000");
				strcpy(t_fsex,"0");
				strcpy(t_fmarriage,"0");
			}
			
			/* c175-176 �W���H�W�F�Ʋz�߯ż�*/
			if ((strlen(rtrim(fcomp_last))) == 0)
			{
				strcat(prtstr,"00");
				strcpy(t_fcomp_class_last,"00");
			}
			else if ((strlen(rtrim(fcomp_last))) == 1)
			{
				sprintf_s(sTmp_buf, sizeof sTmp_buf, "0%d", atoi(fcomp_last));
				strcat(prtstr, sTmp_buf);
				strcpy(t_fcomp_class_last,sTmp_buf);
			} 
			else
			{
				strcat(prtstr, fcomp_last);
				strcpy(t_fcomp_class_last,fcomp_last);
			}
			
			/* c177-178 �����H�W�F�Ʋz�߯ż�*/
			if ((strlen(rtrim(fcomp))) == 0)
			{
				strcat(prtstr,"00");
				strcpy(t_fcomp_class,"00");
			}
			else if ((strlen(rtrim(fcomp))) == 1)
			{
				sprintf_s(sTmp_buf, sizeof sTmp_buf, "0%d", atoi(fcomp));
				strcat(prtstr, sTmp_buf);
				strcpy(t_fcomp_class,sTmp_buf);
			} 
			else
			{
				strcat(prtstr, fcomp);
				strcpy(t_fcomp_class,fcomp);
			}
			
			/* c179-180 ���ʽ�N�� */
			printf("iendorse[%s] fedr_class[%s] \n",iendorse,fedr_class);
			if(fedr_class[0] == '2' || fedr_class[0] == '8')
			{
				strcat(prtstr,"05");
				strcpy(t_iedr_type,"05");
			}
			else if(fedr_class[0] == '7')
			{
				strcat(prtstr,"PR");
				strcpy(t_iedr_type,"PR");
			}
			else if(iedr_type[0] == 'S' )
			{
				if(fedr_class[0] == '2' || fedr_class[0] == '8')
				{
					strcat(prtstr,"05");
					strcpy(t_iedr_type,"05");
				}
				else 
				{
					strcat(prtstr,"08");
					strcpy(t_iedr_type,"08");
				}
			}
			else if (iedr_type[0] == '\0' || iedr_type[0] == ' ')
			{
				strcat(prtstr,"30");
				strcpy(t_iedr_type,"30");
			}
			else
			{
				iedr_type_l=atoi(iedr_type);
				switch(iedr_type_l)
				{
					case 1:  /* ���P */
					strcpy(iedr_type_c,"01");
					break;
					case 2: /* ���~�h�O */
					if(terminate_rsn[0] == '4')  /*���Ƨ�O*/
					strcpy(iedr_type_c,"04");
					else if(terminate_rsn[0] == '8')  /*�������p*/
					strcpy(iedr_type_c,"02");
					else if(terminate_rsn[0] == '9')  /*�������o*/
					strcpy(iedr_type_c,"03");
					else
					strcpy(iedr_type_c,"08");
					break;     
					case 3: case 60: case 4: case 5:/*�j��h�O �h���h�O �O�B�ܰ� �[�O�I��*/
					strcpy(iedr_type_c,"08");
					case 7:  /*�ɰh�t�B*/
					strcpy(iedr_type_c,"07");
					break;
					case 10: case 20:  /*�@���� �ۭt�B�ܰ�*/
					strcpy(iedr_type_c,"30");
					break;
					case 30:  /*�L��*/
					strcpy(iedr_type_c,"05");
					break;        
					case 40: case 50: /*�O�O�ܰ� �_��*/
					strcpy(iedr_type_c,"08");
					break;
					case 75: case 77: /*��L&79 20&79*/
					strcpy(iedr_type_c,"30");
					break;
					case 76: case 78: /*04&79 40&79*/
					strcpy(iedr_type_c,"08");
					break;
					case 79: case 80: case 81: case 82: case 83: case 84: case 85:/*�O���ܰ� ��g�쥿�t�� ��������t�� �����t�B �j��h�t�B*/
					strcpy(iedr_type_c,"08");
					break;
					default:
					strcpy(iedr_type_c,"30");
					break;
				}
				strcat(prtstr,iedr_type_c);
				strcpy(t_iedr_type,iedr_type_c);
			}
			
			/* c181-182 �����s�r�H�W���� */
			rfmtlong(qdrunk_driving, "&&", sTmp_buf);
			strcat(prtstr, sTmp_buf);
			t_qdrunk_driving = qdrunk_driving;
			prtstr[182]='\0';
			
			/* c183-183 �[�h�k�w�`�O�O+/-�O�� */
			if (medr_prem < 0)
				strcat(prtstr,"-");
			else if(medr_prem >0 )
				strcat(prtstr,"+");
			else
				strcat(prtstr,"+");
			
			/* c184-192 �k�w�`�O�O */
			if (medr_prem !=0)
				rfmtlong(medr_prem, "&&&&&&&&&", sTmp_buf);
			else
				strcpy(sTmp_buf, "000000000");
			t_mprem = medr_prem;
			
			strcat(prtstr, sTmp_buf);
			prtstr[192]='\0';
			
			/* c193-193 �[�h�O�O+/-�O�� */
			if (medrins_prem < 0)
			strcat(prtstr,"-");
			else if(medrins_prem >0 )
			strcat(prtstr,"+");
			else
			strcat(prtstr,"+");
			
			/* c194-202 �[�h�`�O�O */
			if (medrins_prem !=0)
				rfmtlong(medrins_prem, "&&&&&&&&&", sTmp_buf);
			else
				strcpy(sTmp_buf, "000000000");
			strcat(prtstr, sTmp_buf);
			t_mins_premium = medrins_prem;
			prtstr[202]='\0';
			
			/* c203-216 �[�h�«O�O */
			/*medr_adjcom_l = medr_adjcom * 10000;*/
			t_madjcom_prem = medr_adjcom;
			medr_adjcom_l=dtol(medr_adjcom*10000);
			if (medr_adjcom < 0)
				strcat(prtstr,"-");
			else 
				strcat(prtstr,"+");
			
			if (medr_adjcom == 0)
				strcat(prtstr,"0000000000000");
			else if (medrins_prem == 0)
				strcat(prtstr,"0000000000000");
			else
			{
				rfmtdouble(medr_adjcom_l, "&&&&&&&&&&&&&", sTmp_buf);
				strcat(prtstr, sTmp_buf);
			}
			
			if (medrins_prem == 0)
				pure_total += 0;
			else
				pure_total += medr_adjcom;
			
			/*�P�_2005�~3�몺�O�v,�N�������O�I�O�[��~�޶O��--begin*/
			sprintf_s(stmp, sizeof stmp,"SELECT dply_begin \
			FROM %s:ori_ply_relation WHERE ipolicy = '%s' ",iply_db,ipolicy);
			$PREPARE ply_dpolicy_eng FROM $stmp;
			$EXECUTE ply_dpolicy_eng INTO $dpolicy_eng;
			
			strcpy(dpolicy_str,dpolicy_eng+6);
			strcat(dpolicy_str,substring(dpolicy_eng,1,2));
			strcat(dpolicy_str,substring(dpolicy_eng,4,2));
			printf("dpolicy_eng[%s]\n",dpolicy_eng);
			printf("dpolicy_str[%s]\n",dpolicy_str);
			
			printf("medr_business1==>[%f]\n",medr_business);
			printf("medr_maintain1==>[%f]\n",medr_maintain);
			
			sprintf_s(stmt, sizeof stmt, "SELECT to_char(drate, '%%Y%%m') FROM ca_rate_date \
			WHERE itable = 'compulsory_premium' AND icode = ? ");
			$PREPARE get_drate FROM $stmt;
			$EXECUTE get_drate
			INTO $drate_yyyymm
			USING $drate_ym;
			
			if (SQLCODE == SQLNOTFOUND) 
				business_flag = 0;
			else
			{
				business_flag = 1;
				if ((strcmp(trim(drate_yyyymm),"200503") == 0))
				{
					printf("medr_business2==>[%f]\n",medr_business);
					printf("medr_maintain2==>[%f]\n",medr_maintain);
					medr_business += medr_maintain;
					medr_maintain = 0;
				}
			}
			printf("drate_yyyymm==>[%s]\n",drate_yyyymm);
			printf("medr_business3==>[%f]\n",medr_business);
			printf("medr_maintain3==>[%f]\n",medr_maintain);
			/*�P�_2005�~3�몺�O�v,�N�������O�I�O�[��~�޶O��--end*/
			
			/* c217-226 �[�h�~�ȶO�� */
			/* car950512 */
			t_mbusiness = medr_business ;
			if (medr_business < 0)
				strcat(prtstr,"-");
			else strcat(prtstr,"+");
			
			if (medr_business==0)
				strcat(prtstr,"000000000");
			else
			{
				rfmtdouble(medr_business*100, "&&&&&&&&&", sTmp_buf);
				strcat(prtstr, sTmp_buf);
			}
			
			prtstr[226]='\0';
			
			/* c227-236 �[�h�������O�I�O�� */
			t_maintain = medr_maintain;
			if (medr_maintain < 0)
				strcat(prtstr,"-");
			else
				strcat(prtstr,"+");
			
			if (medr_maintain==0)
				strcat(prtstr,"000000000");
			else
			{
				rfmtdouble(medr_maintain*100, "&&&&&&&&&", sTmp_buf);
				strcat(prtstr, sTmp_buf);
			}
			prtstr[236]='\0';
			
			/* c237-246:�S�ɤ����B */
			t_mcompensation = mcompensation;
			mcompensation *= 10000;
			if(mcompensation >= 0)
				strcat(prtstr,"+");
			else 
				strcat(prtstr,"-");
			rfmtdouble(mcompensation, "&&&&&&&&&", sTmp_buf);
			strcat(prtstr,sTmp_buf);
			prtstr[246]='\0';
			
			/* c247-256:�w�w��� */
			t_mstable = mstable;
			mstable *= 10000;
			if(mstable >= 0)
				strcat(prtstr,"+");
			else 
				strcat(prtstr,"-");
			rfmtdouble(mstable, "&&&&&&&&&", sTmp_buf);
			strcat(prtstr,sTmp_buf);
			prtstr[256]='\0';
			
			/* c257-263:�s��r���[�O */
			t_mdrunk_prem = mdrunk_prem;
			if(mdrunk_prem >= 0)
				strcat(prtstr,"+");
			else 
				strcat(prtstr,"-");
			rfmtdouble(mdrunk_prem, "&&&&&&", sTmp_buf);
			strcat(prtstr,sTmp_buf);
			prtstr[263]='\0';
			
			/*C264-274:�s��r���«O�O*/
			/*mdrunk_pure_prem_l=mdrunk_pure_prem*10000;*/
			t_mdrunk_pure_prem = mdrunk_pure_prem;
			tot_mdrunk_pure_prem += mdrunk_pure_prem;
			mdrunk_pure_prem_l=dtol(mdrunk_pure_prem*10000);
			if(mdrunk_pure_prem_l >= 0)
				strcat(prtstr,"+");
			else 
				strcat(prtstr,"-");
			rfmtdouble(mdrunk_pure_prem_l, "&&&&&&&&&&", sTmp_buf);
			strcat(prtstr,sTmp_buf);
			prtstr[274]='\0';
		
			/* c275-286 �ӫ~�N�X */
			iproduct[10] = '\0';
			if ((strlen(rtrim(iproduct))) == 0) 
			{
				strcat(prtstr,"000000000000");
				strcpy(t_iproduct,"000000000000");
			}
			else 
			{
				strcat(prtstr,iproduct);
				strcat(prtstr,"11");
				strcpy(t_iproduct,iproduct);
				strcat(t_iproduct,"11");
			}
			prtstr[286]='\0';
			
			strncpy(iproduct_tmp,iproduct+3,2);
			iproduct_tmp[2] = '\0';
			printf("iproduct_tmp[%s] \n",iproduct_tmp);
			if (strcmp(iproduct_tmp,"14") == 0) 
			{
				mprem_14 += medrins_prem;
				mprem_pure_14 += medr_adjcom;
			}
			else if (strcmp(iproduct_tmp,"15") == 0) 
			{
				mprem_15 += medrins_prem;
				mprem_pure_15 += medr_adjcom;
			}
			else if (strcmp(iproduct_tmp,"16") == 0) 
			{
				mprem_16 += medrins_prem;
				mprem_pure_16 += medr_adjcom;
			}
			else if (strcmp(iproduct_tmp,"32") == 0) 
			{
				mprem_32 += medrins_prem;
				mprem_pure_32 += medr_adjcom;
			}
			
			/*c287-292 �O�v��I�~�� */
			if (business_flag == 0)
			{
				if ((strcmp(icar_type,"01")==0) || (strcmp(icar_type,"02")==0))
					strcpy(drate_c, "88/01/01");
				else
				{
					sprintf_s(stmp, sizeof stmp,"SELECT dpolicy FROM %s:ori_ply_relation WHERE ipolicy = '%s' ",iply_db,ipolicy);
					$PREPARE ply_dpolicy FROM $stmp;
					$EXECUTE ply_dpolicy INTO $dpolicy;
					if (SQLCODE == SQLNOTFOUND) strcpy(drate_c, "89/08/12");
					
					if (dpolicy < 36749)    /* 89/8/12�H�e�ҥX���O�� */
						strcpy(drate_c, "87/01/01");
					else
						strcpy(drate_c, "92/01/01");
				}
				
				cm_split_ymd_100(drate_c,drate_yy,drate_mm,drate_dd);
				
				if (drate_yy[0]=='\0') 
				{
					strcat(prtstr,"0000");
					strcpy(t_drate_ym,"0000");
				}
				else 
				{
					strcat(prtstr,itoa(1911+(atoi(drate_yy))));
					strcpy(t_drate_ym,itoa(1911+(atoi(drate_yy))));
				}
				
				if (drate_mm[0]=='\0') 
				{
					strcat(prtstr,"00");
					strcat(t_drate_ym,"00");
				}
				else 
				{
					strcat(prtstr,drate_mm);
					strcat(t_drate_ym,drate_mm);
				}
			} 
			else
			{
				strcat(prtstr,drate_yyyymm);
				strcpy(t_drate_ym,drate_yyyymm);
			}
			prtstr[292]='\0';
			
			/* c293-298 ���~�� */
			strcpy(dendorse_c,cm_cdate_str_100(dendorse));
			cm_split_ymd_100(dendorse_c,dedr_yy,dedr_mm,tmp_dd);
			
			if (dedr_yy[0] == '\0' ) 
			{
				strcat(prtstr,"0000");
				strcpy(t_dpolicy_ym,"0000");
			}
			else 
			{
				strcat(prtstr,itoa(1911+(atoi(dedr_yy))));
				strcpy(t_dpolicy_ym,itoa(1911+(atoi(dedr_yy))));
			}
			
			if (dedr_mm[0] == '\0')
			{
				strcat(prtstr,"00");
				strcat(t_dpolicy_ym,"00");
			}
			else
			{
				strcat(prtstr,dedr_mm);
				strcat(t_dpolicy_ym,dedr_mm);
			}
			
			/* c299-300 �q���O�N�� 2009.2�W�C�榡*/
			/* 1000311003�q���ĤG���q ������edr_relationŪ��*/
			strcat(prtstr,bzfrom);
			strcpy(t_bzfrom,bzfrom);
			prtstr[300] = '\0';
			
			/* c301-308 ��ƻs�e��� */
			strcat(prtstr,ttday_yy);
			strcat(prtstr,ttday_mm);
			strcat(prtstr,ttday_dd);        /* �������� */
			strcpy(t_dsend,ttday_yy);
			strcat(t_dsend,ttday_mm);
			strcat(t_dsend,ttday_dd);
			prtstr[308] = '\0';
			
			printf("prtstr[%s]\n", prtstr);        
			
			fprintf(fptr,"%s\n",prtstr);
			count1++;
			
			prtstr[178]='9'; prtstr[179]='9';
			fprintf(fptr,"%s\n",prtstr);
			count1++;
			
			strcpy(t_icard_last_company," ");
			strcpy(t_icard_last_br," ");
			strcpy(t_icard_last," ");
			printf("data_yyyymm[%s],ipolicy[%s],t_icard_company[%s],t_icard_br[%s],t_icard[%s],t_icard_last_company[%s],t_icard_last_br[%s],t_icard_last[%s] \n",
			        data_yyyymm,ipolicy,t_icard_company,t_icard_br,t_icard,t_icard_last_company,t_icard_last_br,t_icard_last);
			printf("t_iedr_company[%s],t_iedr_br[%s],t_iendorse[%s],t_iarea[%s],t_dedr_begin[%s],t_dedr_end[%s],t_dply_begin[%s],t_dply_end[%s],t_iobjno[%s],t_iissue_year[%s],t_ipro_year[%s] \n",
			        t_iedr_company,t_iedr_br,t_iendorse,t_iarea,t_dedr_begin,t_dedr_end,t_dply_begin,t_dply_end,t_iobjno,t_iissue_year,t_ipro_year);
			printf("t_ibrand[%s],t_icar_type[%s],t_icar_type_no[%s],t_qcylinder[%d],t_iengine[%s],t_itag[%s],t_qpt[%d],t_fpt[%s],t_fassured[%s],t_iassured[%s],t_dbirth[%s],t_fsex[%s],t_fmarriage[%s],t_fcomp_class_last[%s],t_fcomp_class[%s] \n",
			        t_ibrand,t_icar_type,t_icar_type_no,t_qcylinder,t_iengine,t_itag,t_qpt,t_fpt,t_fassured,t_iassured,t_dbirth,t_fsex,t_fmarriage,t_fcomp_class_last,t_fcomp_class);
			printf("t_iedr_type[%s],t_qdrunk_driving[%d],t_mprem[%d],t_mins_premium[%d],t_madjcom_prem[%f],t_mbusiness[%f],t_maintain[%f],t_mcompensation[%f],t_mstable[%f],t_mdrunk_prem[%d],t_mdrunk_pure_prem[%f] \n",
			        t_iedr_type,t_qdrunk_driving,t_mprem,t_mins_premium,t_madjcom_prem,t_mbusiness,t_maintain,t_mcompensation,t_mstable,t_mdrunk_prem,t_mdrunk_pure_prem);
			printf("t_iproduct[%s],t_drate_ym[%s],t_dpolicy_ym[%s],t_bzfrom[%s],t_dsend[%s] \n",
			        t_iproduct,t_drate_ym,t_dpolicy_ym,t_bzfrom,t_dsend);
	
			/* �d�s��� */
			sprintf_s(stmt, sizeof stmt,"INSERT INTO %s:ca_dev_ply_edr_comp \
			                     (data_yyyymm,idata,ipolicy,icard_company,icard_br,icard,icard_last_company,icard_last_br,icard_last, \
			                      iedr_company,iedr_br,iendorse,iarea,dedr_begin,dedr_end,dply_begin,dply_end,iobjno,iissue_year,ipro_year, \
			                      ibrand,icar_type,icar_type_no,qcylinder,iengine,itag,qpt,fpt,fassured,iassured,dbirth,fsex,fmarriage,fcomp_class_last,fcomp_class, \
			                      iedr_type,qdrunk_driving,mprem,mins_premium,madjcom_prem,mbusiness,maintain,mcompensation,mstable,mdrunk_prem,mdrunk_pure_prem, \
			                      iproduct,drate_ym,dpolicy_ym,bzfrom,dsend) \
			              VALUES(?,'E',?,?,?,?,?,?,?, \
			                     ?,?,?,?,?,?,?,?,?,?,?, \
			                     ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, \
			                     ?,?,?,?,?,?,?,?,?,?,?, \
			                     ?,?,?,?,?)",list[k].dbname);
			$PREPARE insert_ply_edr FROM $stmt;
			$EXECUTE insert_ply_edr using $data_yyyymm,$ipolicy,$t_icard_company,$t_icard_br,$t_icard,$t_icard_last_company,$t_icard_last_br,$t_icard_last,
			                              $t_iedr_company,$t_iedr_br,$t_iendorse,$t_iarea,$t_dedr_begin,$t_dedr_end,$t_dply_begin,$t_dply_end,$t_iobjno,$t_iissue_year,$t_ipro_year,
			                              $t_ibrand,$t_icar_type,$t_icar_type_no,$t_qcylinder,$t_iengine,$t_itag,$t_qpt,$t_fpt,$t_fassured,$t_iassured,$t_dbirth,$t_fsex,$t_fmarriage,$t_fcomp_class_last,$t_fcomp_class,
			                              $t_iedr_type,$t_qdrunk_driving,$t_mprem,$t_mins_premium,$t_madjcom_prem,$t_mbusiness,$t_maintain,$t_mcompensation,$t_mstable,$t_mdrunk_prem,$t_mdrunk_pure_prem,
			                              $t_iproduct,$t_drate_ym,$t_dpolicy_ym,$t_bzfrom,$t_dsend;
		}
		$CLOSE scur_edr;
	}
	fclose(fptr);

	if (prem_total >= 0)
		rfmtlong(prem_total,"&&&&&&&&&&&&",prem_c);
	else
		rfmtlong(prem_total,"-&&&&&&&&&&&",prem_c);
	
	res = getApHome(aphome);

     if (res<0)
     {
         printf("In sigalrmcatcher func==>read config file error!!\n");
         exit(1);
     }

     if (count1==0)
         fprintf(fptr_err,"%s\n","�L���!!");
     else
     {
     	$WHENEVER SQLERROR GOTO errexit;
        /* �s����� */
        $SELECT iquota INTO $iquota FROM officer WHERE iofficer=$userid;

        rtoday(&Today);     /* get today's datetime */
        printf("### Today[%d],ipolicy_br[%s],prem_total[%d],count1[%d]\n",
                    Today  ,  ipolicy_br  ,  prem_total  ,  count1);

        strcpy(Taipei_FullName,get_full_dbname("00"));

        sprintf_s(stmt, sizeof stmt,"DELETE FROM %s:ca_develop \
                WHERE iclass='9992' AND ibranch=? AND data_yyyymm = ? ",Taipei_FullName);
        printf("stmt[%s]\n",stmt);
        $PREPARE insert_cus1 FROM $stmt;
        $EXECUTE insert_cus1 USING $DBName,$data_yyyymm;

		sprintf_s(stmt, sizeof stmt,"INSERT INTO %s:ca_develop \
		              (iquota,data_yyyymm,iclass,dsend,ibranch, \
		               product_kind,iins_class,mprem,qcnt,pure_mprem,mdrunk_pure_prem) \
		              VALUES(?,?,'9992',?,?,'14','C',?,0,?,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus14 FROM $stmt;
		$EXECUTE insert_cus14 USING $iquota,$data_yyyymm,$Today,$DBName,$mprem_14,$mprem_pure_14;

		sprintf_s(stmt, sizeof stmt,"INSERT INTO %s:ca_develop \
		              (iquota,data_yyyymm,iclass,dsend,ibranch, \
		               product_kind,iins_class,mprem,qcnt,pure_mprem,mdrunk_pure_prem) \
		              VALUES(?,?,'9992',?,?,'15','C',?,0,?,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus15 FROM $stmt;
		$EXECUTE insert_cus15 USING $iquota,$data_yyyymm,$Today,$DBName,$mprem_15,$mprem_pure_15;

		sprintf_s(stmt, sizeof stmt,"INSERT INTO %s:ca_develop \
		              (iquota,data_yyyymm,iclass,dsend,ibranch, \
		               product_kind,iins_class,mprem,qcnt,pure_mprem,mdrunk_pure_prem) \
		              VALUES(?,?,'9992',?,?,'16','C',?,0,?,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus16 FROM $stmt;
		$EXECUTE insert_cus16 USING $iquota,$data_yyyymm,$Today,$DBName,$mprem_16,$mprem_pure_16;
		
		sprintf_s(stmt, sizeof stmt,"INSERT INTO %s:ca_develop \
		              (iquota,data_yyyymm,iclass,dsend,ibranch, \
		               product_kind,iins_class,mprem,qcnt,pure_mprem,mdrunk_pure_prem) \
		              VALUES(?,?,'9992',?,?,'32','C',?,0,?,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus32 FROM $stmt;
		$EXECUTE insert_cus32 USING $iquota,$data_yyyymm,$Today,$DBName,$mprem_32,$mprem_pure_32;

        sprintf_s(stmt, sizeof stmt,"INSERT INTO %s:ca_develop \
                      (iquota,data_yyyymm,iclass,dsend,ibranch,product_kind,iins_class,mprem,qcnt,pure_mprem,mcompensation,mstable,mdrunk_pure_prem) \
                VALUES(?,?,'9992',?,?,'99','C',?,?,?,?,?,?)",Taipei_FullName);
        printf("stmt[%s]\n",stmt);
			
        $PREPARE insert_cus2 FROM $stmt;
        $EXECUTE insert_cus2
           USING $iquota,$data_yyyymm,$Today,$DBName,$prem_total,$count1,$pure_total,$tot_mcompensation,$tot_mstable,$tot_mdrunk_pure_prem;
     }

     return SUCCESS;

errexit:
	printf("userid=%s SOLCODE=%d sqlca.sqlerrm=%s\n",userid,SQLCODE,sqlca.sqlerrm);
	printf(errmsg,"userid=%s SOLCODE=%d sqlca.sqlerrm=%s\n",userid,SQLCODE,sqlca.sqlerrm);
	fprintf(fptr_err,"%s\n",errmsg);
	return SQLCODE;
}

long car9992_final()
{
	char sTmpMsg[1024];
	$char sfilename[81],stitle[1024],stmt[1024];
	$char DBName1[5];
	$long mprem, pure_mprem, qcnt;
	$char product_kind[3];
	$double mdrunk_pure_prem;
    
	$WHENEVER SQLERROR GOTO errexit;
	
	strcpy(DBName1,"00");
	if (db_select(DBName1) == False)  return M_CM_DB_NOTOPEN;
	
	$SELECT sum(mprem), sum(qcnt), sum(pure_mprem), sum(mdrunk_pure_prem)
	   INTO $mprem, $qcnt, $pure_mprem, $mdrunk_pure_prem
	   FROM ca_develop
	  WHERE iclass = '9992' AND product_kind = '99'
	    AND data_yyyymm  = $data_yyyymm;

	sprintf_s(sTmpMsg, sizeof sTmpMsg, "%s%s\n", "���ɧ���:", file_catalog);
	sprintf_s(sTmpMsg, sizeof sTmpMsg, "%s�O�O=[%d] �«O�O=[%d] �s�r�«O�O[%.4f] ����=[%d]\n",sTmpMsg, mprem, pure_mprem, mdrunk_pure_prem, qcnt );
	
	/*29�I���p�p����*/
	sprintf_s(stmt, sizeof stmt,"SELECT product_kind, sum(mprem), sum(qcnt), sum(pure_mprem) \
	                FROM ca_develop \
	               WHERE iclass = '9992' AND product_kind <> '99' AND data_yyyymm = '%s' \
	               GROUP BY product_kind order by 1",data_yyyymm);
	$PREPARE pre_29_kind1 FROM $stmt;
	$DECLARE cur_29_kind2 CURSOR FOR pre_29_kind1;
	$OPEN cur_29_kind2;
	while (1)
	{
		$FETCH cur_29_kind2 INTO $product_kind ,$mprem, $qcnt, $pure_mprem;
		if (SQLCODE == SQLNOTFOUND) break;
		sprintf_s(sTmpMsg, sizeof sTmpMsg, "%s�I��=[%s] �O�O=[%d] �«O�O=[%d] ����=[%d]\n",sTmpMsg, product_kind, mprem, pure_mprem, qcnt );
	}

	EWRITE(userid, M_CM_OK, sTmpMsg);
	exit(SUCCESS);
	isfinish(rtncode);

errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}
