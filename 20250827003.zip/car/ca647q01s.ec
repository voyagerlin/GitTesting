/**********************************************************************/
/*   program id   : ca647q01s.ec                                      */
/*   program name : �wú��w���O���B�z���Ӫ�                          */
/*   date written : 2016/06/23                                        */
/*   date modify  : yyyy/mm/dd                                        */
/*   author       : Larry Liao                                        */                                       
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
#include "safeclib.h"
/****************************************************************************/
int   tmp_len,rc,ttlen;
$char DBName[05],userid[11];
$char ibranch_no[3],dentry_bgn[11], dentry_end[11], s_frenew_type[2] , s_iofficer[11], s_ileader[11], s_itag[13], s_iassured[11], s_iroute[21];
$char dentry_bgn[11], dentry_end[11];
char  msgbuf[2048], sApHome[30];
char  v_sMsg[1024], outputf[N_FILE+1];
char sTmp_db_name[21];
int   count_db,i;
DBinfo  *list;
/****************************************************************************/
char *get_car_full_db();

main(argc, argv)
int argc;
char **argv;
{  
	int rc;

	batchinit();
	strcpy(DBName, 	     isNULLstr(argv[1]));
	strcpy(userid, 	     isNULLstr(argv[2]));
	strcpy(ibranch_no,   isNULLstr(argv[3]));
	strcpy(dentry_bgn,   isNULLstr(argv[4]));                 
	strcpy(dentry_end,   isNULLstr(argv[5]));
	strcpy(s_frenew_type,  isNULLstr(argv[6]));
	strcpy(s_iofficer,   isNULLstr(argv[7]));
	strcpy(s_ileader,    isNULLstr(argv[8]));
	strcpy(s_itag,       isNULLstr(argv[9]));
	strcpy(s_iassured,   isNULLstr(argv[10]));
	strcpy(s_iroute,     isNULLstr(argv[11]));
	strcpy(outputf,      isNULLstr(argv[12]));	
	printf("DBName[%s],userid[%s],ibranch_no[%s],dentry_bgn[%s],dentry_end[%s],frenew_type[%s],s_iofficer[%s],s_ileader[%s],s_itag[%s],s_iassured[%s],s_iroute[%s]\n "
	        ,DBName,userid,ibranch_no,dentry_bgn,dentry_end,s_frenew_type,s_iofficer,s_ileader,s_itag,s_iassured,s_iroute);
		
	rc = car647_get_db();
	if (rc != M_CM_OK) {
		EWRITE(userid,rc,msgbuf);
		return rc;
	}
 
  rc = car647_init_data();
  if (rc != M_CM_OK) {
    printf("error on car647_init_data\n");
		EWRITE(userid,rc,"�إ� temp table ���~!");
		return rc;
  }
				
	rc = car647_query_detail();
  if (rc != M_CM_OK) {
    printf("error on car647_query_detail\n");
		/*EWRITE(userid, rc, "�d�߸�Ʀ��~");*/
		return rc;
	}
	  
  rc = car647_print_detail();
  printf("rc[%d]",rc);
  if (rc != M_CM_OK) {
     printf("error on car647_print_detail\n");
     EWRITE(userid, rc, "���s�������Ӧ��~!");
     return rc;
  }    
			
  return rc;
}
/******************************************************************************/
long car647_init_data()
{   
    $WHENEVER SQLERROR GOTO errexit;
         	  	   
	  $create temp table car647_tmp(
	        ipre_rcv       char(20),       /*�����渹*/
	  	transno        char(20),       /*����s��*/
	  	frenew_type    char(1),        /*��O����*/
	  	ipolicy        char(20),       /*��O�渹*/
	  	nassured       varchar(120),   /*�Q�O�I�H�W��*/
	  	itag           char(10),       /*�P��*/
	  	iofficer       char(10),       /*�g��H*/
	  	nofficer       char(10),       /*�g��W��*/
	  	nleader        char(10),       /*�޲z�H�W��*/
	        iroute         char(20),       /*�q���N��*/
	        nroute         varchar(40),    /*�q���W��*/
	        mprem          decimal(12,0),  /*�`�O�O*/
	        dacc           char(20),           /*ú�ڤ�*/
	        dacc_trans     char(20),  /*�J�b��*/
	        dply_bgn       char(20),           /*�O�I�_��*/
	        fedr_class     char(3)       /*�O�_�w�X��*/
	  )with no log;
	  
	  return M_CM_OK;

errexit:
    printf("--car647_init_data-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car647_query_detail()
{
    int   count = 0,count_all=0;
    $char stmt[6000];
    $char sTransno[22],transno[21], ipolicy[21], itag[11], iofficer[11], icont[2], iquota14[11];
    $char dacc[11], dacc_trans[11], iquota[11], duw_status[21];
    $char opt_type[2], nname[11], nbranch[31], aassured[91];
    /*$char aassured_zip[6];*/
    $char itel[21], ibrand[11], sFullName[20], dply_end1[11], ipre_rcv[21],iupcomp_user[3];
    $long macc = 0;
    /*$int  qcylinder; 1080902001-SC1-�Ʈ�q�X�W�p���I2�� �ˬd��{�����ϥΥ����*/
    char  strmacc[6], strseq[5], strqcy[11];
    $char cus_email[51], cus_tel_night[21], cus_mobil_phone[21];	/* �ȪA��P�ɪ�mail */
    $char sDply_bgn[11], nleader[11], iins_kind[2];
    $char sTpmonth[3];
    $int  iTpmonth,t_count;
    $char sInext_type[3],sInext_ply[21], s_nassured[11];
    $char stmt_dentry[301],iroute[21],nroute[41],frenew_type[2],stmt_frenew_type[300];
   
   printf("dentry_bgn[%s] dentry_end[%s]",dentry_bgn,dentry_end);   
   sprintf_s(stmt_dentry, sizeof stmt_dentry, " AND a.dentry between to_date('%s 00:00:01','%%m/%%d/%%Y %%H:%%M:%%S') AND to_date('%s 23:59:59','%%m/%%d/%%Y %%H:%%M:%%S') ", dentry_bgn, dentry_end);
   printf("-- trace stmt_dentry[%s]\n ",stmt_dentry);
   if(strcmp(s_frenew_type,"0")==0)
   sprintf_s(stmt_frenew_type, sizeof stmt_frenew_type," AND frenew_type in ('1','2')");
   else 
   sprintf_s(stmt_frenew_type, sizeof stmt_frenew_type," AND frenew_type matches '%s'",s_frenew_type);
      
   $WHENEVER ERROR CONTINUE;    
   $drop table tmp_prercv_pass;
   $drop table tmp_pre_receive;
   $drop table tmp_policy_302;
	$WHENEVER SQLERROR GOTO errexit;
	$SELECT b.iupcomp 
	   INTO $iupcomp_user
	   FROM officer a,sa_branch_type b
	  WHERE a.iquota = b.ibranch
	    AND a.iofficer = $userid;
	
	printf("-- 1. trace ���^��2�Ӥ뤺�w���O����O������\n ");
	sprintf_s(stmt, sizeof stmt,"SELECT a.ipre_rcv,a.iins_kind,a.ipre_end,a.dcoll_last, extend(max(a.dentry),year to day) AS dentry,  "
	              "       (SELECT sum(mnt) FROM ao_prercv_pass WHERE ipre_rcv = a.ipre_rcv AND ipre_end = a.ipre_end) as mnt_sum  "
	              "  FROM ao_prercv_pass a ,branch b "
	              " WHERE a.ipre_rcv[1,2] = b.ibranch  "
	              "   AND a.ipre_rcv[6,7] = 'CR'  "
	              "   AND b.ibranch = '%s' "
	              "   AND b.iupcomp = '%s' "
	              "  %s  "
	              " GROUP BY 1,2,3,4  "
	              "INTO temp tmp_prercv_pass WITH NO log ",ibranch_no, iupcomp_user, stmt_dentry);
	    printf("-- trace stmt[%s]\n ",stmt); 
	              
$execute immediate $stmt;
$CREATE INDEX idx_tmp_prercv_pass1 ON tmp_prercv_pass (ipre_rcv,iins_kind,ipre_end);    		           
$CREATE INDEX idx_tmp_prercv_pass2 ON tmp_prercv_pass (ipre_rcv);
$CREATE INDEX idx_tmp_prercv_pass3 ON tmp_prercv_pass (dcoll_last);
		
	printf("-- 2. trace �A�z��X���X��B2�Ӥ뤺�����̡A�P�ɨ̸g��N������z��\n ");
	sprintf_s(stmt, sizeof stmt, 
	            "SELECT a.ipre_rcv, a.iins_kind, a.ipre_end, a.itag, a.isys, a.iofficer,  "
	            "       substr(replace(replace(a.nassured,'�p�j',''),'����',''),1,5) as nassured,  "
	            "       a.deffect,  b.nname as nofficer , c.nname as nleader ,a.iroute ,(select nroute from cm_route where iroute = a.iroute) as nroute "
		 	    "  FROM cm_pre_receive a, officer b ,officer c  "
		 	    " WHERE a.ipre_rcv IN (SELECT ipre_rcv FROM tmp_prercv_pass)  "
		 	    "   AND a.iofficer = b.iofficer  "
		 	    "   AND b.ileader  = c.iofficer  "
		 	    "   AND (a.iofficer matches '%s' and a.iofficer[1] not in ('W','N') and not (a.iofficer[1] = 'H' and a.iofficer[2] not in ('0','1','2')) )  "
		 	    "   AND a.ileader matches '%s'  "
		 	    "   AND a.itag matches '%s'  "
		 	    "   AND a.iassured matches '%s'  "
		 	    "   AND a.iroute matches '%s'  "
		  	    "   AND a.ipre_end = ' '   "
		 	    "   AND a.fstatus  = 50   "
		 	    "   AND a.ftype    = 'P'  "
		 	    "   AND a.ipolicy1 = ' '  "
		 	    "   AND a.ipolicy2 = ' '  "
		 	    "   AND a.isub     = '%s'  "
		 	    "  INTO temp tmp_pre_receive WITH NO log  "
		 	    , s_iofficer, s_ileader, s_itag, s_iassured,s_iroute, DBName);
		printf("-- trace stmt[%s]\n ",stmt);  
			    
$execute immediate $stmt;	    	 	   
$CREATE INDEX idx_tmp_pre_receive1 ON tmp_pre_receive (ipre_rcv,iins_kind,ipre_end);    		   	 	
$CREATE INDEX idx_tmp_pre_receive2 ON tmp_pre_receive (ipre_rcv);
$CREATE INDEX idx_tmp_pre_receive3 ON tmp_pre_receive (deffect);

	printf("-- 3. trace �̫����O�J�p��ơ]2�Ӥ뤺�ͮĪ̡^\n ");
	sprintf_s(stmt, sizeof stmt, 
	            "SELECT iestimate_ori AS iestimate,ipolicy,itransno_ori AS itransno, fcard_class,frenew_type ,dupdate    "
		 	    "  FROM policy_302  "
		 	    " WHERE iestimate_ori IN ( SELECT ipre_rcv FROM tmp_pre_receive)  "
		 	    "   %s  "
		 	    "   AND fuw_status_ori >= 500  "
		 	    " UNION ALL  "
		 	    "SELECT  iestimate_sug AS iestimate,ipolicy,itransno_sug AS itransno,fcard_class,frenew_type ,dupdate  "
		 	    "  FROM policy_302  "
		 	    " WHERE iestimate_sug IN ( SELECT ipre_rcv FROM tmp_pre_receive)   "
		 	    "   %s  "
		  	    "   AND fuw_status_sug >= 500  "
		 	    "  INTO temp tmp_policy_302 WITH NO log ",stmt_frenew_type,stmt_frenew_type);
		printf("-- trace stmt[%s]\n ",stmt);  	    
$execute immediate $stmt;
$CREATE INDEX idx_tmp_policy_3021 ON tmp_policy_302 (iestimate,fcard_class) using btree;	   
$CREATE INDEX idx_tmp_policy_3022 ON tmp_policy_302 (iestimate) using btree;

	printf("-- 4. trace ���X�W�ztmp table \n ");
	
	$DECLARE cur_no_s CURSOR FOR 	 						
	SELECT a.ipre_rcv, c.itransno, c.ipolicy,  a.itag, a.isys,  a.iofficer, a.nassured, a.deffect, 
	       a.nofficer, c.dupdate,  a.iins_kind, b.dcoll_last, c.frenew_type , a.nleader,
	       b.dentry  , b.mnt_sum , a.iroute , a.nroute
	  FROM tmp_pre_receive a, tmp_prercv_pass b, tmp_policy_302 c
         WHERE a.ipre_rcv = b.ipre_rcv   and a.ipre_rcv = c.iestimate 
	   AND a.iins_kind = b.iins_kind and a.iins_kind = c.fcard_class 
	   AND a.ipre_end = b.ipre_end 
	ORDER BY 12 desc, a.deffect, a.ipre_rcv ;		
	printf("-----221 \n ");
	$OPEN  cur_no_s ;
        for(;;)
        {
            strcpy(transno," ");		
            $FETCH cur_no_s INTO $ipre_rcv,   $transno,     $ipolicy,   $itag,  $icont,
                                 $iofficer,   $s_nassured,  $sDply_bgn, $nname,
                                 $duw_status, $iins_kind,   $dacc,      $frenew_type , $nleader,
                                 $dacc_trans, $macc,        $iroute,    $nroute;
            if(SQLCODE == SQLNOTFOUND)
               break;
        printf("-----231 \n ");   	
            count++;
            count_all++;
            printf("---opt8 ipre_rcv[%s] count[%d]iroute[%s]\n", ipre_rcv,count,iroute);
 
            strcpy(dacc, cm_from_infdate_100(dacc));	/* �Ȥ�ú�ڤ� */
            strcpy(sInext_type," ");   
            strcpy(sFullName, get_car_full_db(ipolicy));
            strcpy(sFullName, trim(sFullName));
	        sprintf_s(stmt, sizeof stmt,"SELECT decode(trim(nvl(inext_ply,' ')),'','�_','�O') FROM %s:ply_relation  "
	                       "WHERE ipolicy = '%s'",sFullName,ipolicy );
	        $PREPARE pre_nextply FROM $stmt;                        
            $EXECUTE pre_nextply INTO $sInext_type ;

	     strcpy(dacc_trans, cm_sysd_cdate_100(dacc_trans));	/* �̫�J�b�� */
	     strcpy(sDply_bgn, cm_from_infdate_100(sDply_bgn));
	     
	     strcpy(sTransno, "�");
             strcat(sTransno,trim(transno));

              printf("-----247 \n "); 
             $INSERT INTO car647_tmp VALUES($ipre_rcv,$sTransno,$frenew_type,$ipolicy,$s_nassured,$itag,$iofficer,$nname,$nleader,$iroute,$nroute,$macc,$dacc,$dacc_trans,$sDply_bgn,$sInext_type);
             printf("-----249 \n "); 
        }
        $CLOSE cur_no_s;
        $FREE  cur_no_s;

        $drop table tmp_prercv_pass;
        $drop table tmp_pre_receive;
        $drop table tmp_policy_302;
        
        if(count_all!=0)
        {
            return M_CM_OK;
        }
        else
        {
            return M_CM_NOT_FOUND;
        }

errexit:
    printf("--car647_query_detail-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car647_print_detail()
{
    int     rc;
    char    sfilename[128],stitle[2048],stmtt[2048];

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(sfilename,"�wú��w���O���B�z���Ӫ�");
    strcpy(stitle,"�{���N��:CAR647\t");
    strcat(stitle,sfilename);
    strcat(stitle,"\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");

    strcat(stitle,"\t�����渹\t����s��\t��O����\t��O�渹\t�Q�O�I�H�W��\t�P��");
    strcat(stitle,"\t�g��H\t�g��W��\t�޲z�H�W��\t�q���N��\t�q���W��\t�`�O�O");
    strcat(stitle,"\tú�ڤ�\t�J�b��\t�O�I�_��\t�O�_�w�X��\t");

    strcpy(stmtt,"SELECT ipre_rcv,transno,frenew_type,ipolicy,nassured,itag,iofficer,nofficer,nleader,iroute,nroute,mprem,dacc,dacc_trans,dply_bgn,fedr_class   "
                "  FROM car647_tmp ");
printf("-----296 \n "); 
    rc = unload_file(outputf," ",sfilename,stitle,stmtt);
printf("-----298 \n "); 
    if (rc != SUCCESS) {
    	printf("-----300 \n ");
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;
    
errexit:
    printf("--car647_print_detail-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car647_get_db()
{
	int return_code;
	
	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == False) {
		strcpy(msgbuf,"��Ʈw�L�k�}��");
		return M_CM_DB_NOTOPEN;
	}
	
	return_code = getApHome(sApHome);
	if (return_code < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		return return_code;
  }
  
  if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
       if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
          return M_CM_NOT_DBLIST;
  }
  
  return M_CM_OK;

errexit:
   printf("--car647_get_db-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/******************************************************************************/
char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
        char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
        /*char sTmp_db_name[21]*/

        sTmp_db_name[0]='\0';
        if (*sIpolicy != '\0' && *sIpolicy !=' ')
        {
           sTmp_db_name[0]='\0';
           strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
           strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
                  USE_BRANCH_ID));
           strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
        }
  printf("sTmp_db_name[%s]",sTmp_db_name);      
  return sTmp_db_name;
}