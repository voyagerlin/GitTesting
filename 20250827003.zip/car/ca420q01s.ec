/*******************************************/
/*                                         */
/*   PROGRAM : ca420q01s.ec                */
/*                                         */
/*   DATE    : 950103                      */
/*   ��J�ɮ׼g�Jca_comm_balance           */
/*               ca_comm_balance_pa        */
/*   �̾�ca_comm_balance���,�����s�p����*/
/*   ipaid_base ���^��                     */
/*   �ק�鵲                              */
/*   ���P�ɭY�P�ɦ�2�i���h���P�ɩ�w���O */
/*                                         */
/*******************************************/

#include <stdio.h>
#include <math.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
#include "carmsgs.h"
#include "carmsg.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
$include "safeclib.h";

extern char RPTDIR[];

int  first,flag;


char  chk_pa[1];
$char DBName[5],FormTp[3];
$char outputf[N_FILE+1], userid[6];
static int max_cnt=0;
$char sDB[3];
$char processid[21];
$char sErrmsg[2048];
$char prep_stmt[4096];
$char icar_type[3];
$char iins_cat[2];
$char sDBa[3];
$int  qply_period=0;
$char iyear[2];
char  sApHome[30];
char  msgbuf[100];
char  sdata[10][21];


long car420_build();
long car420_accumulate();
long car417_report();
char *get_db();
FILE   *sfp;
$char    v_sMsg[1512], sErrMsg[1024];

#define fmt "---,---,---,---"

/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
   int rc;
   char afstatus[2];

   batchinit();
   strcpy(DBName,    isNULLstr(argv[1]));
   strcpy(userid,    isNULLstr(argv[2]));
   strcpy(chk_pa,    isNULLstr(argv[3]));
   strcpy(outputf,   isNULLstr(argv[4]));

   strcpy(processid, outputf);
   printf("processid[%s]\n",processid);

   rc = car420_get_db();
   if (rc != M_CM_OK)
   {
       EWRITE(userid, rc, "get db error");
       exit(1);
   }

   rc = car420_read_file();
   if (rc != M_CM_OK)
   {
       EWRITE(userid, rc, "�g�Jca_comm_balance���~");
       exit(1);
   }
   if (chk_pa[0]=='1') {
      rc = car420_read_pa();
      if (rc != M_CM_OK)
      {
          EWRITE(userid, rc, "�g�Jca_comm_balance_pa���~");
          exit(1);
      }
   }

   rc = car420_build();
   if (rc != M_CM_OK)
   {
       EWRITE(userid, rc, "car420 �g�J�ɮצ��~");
       exit(1);
   }

   strcpy(afstatus,"5");
   printf("afstatus[%s]\n",afstatus);
   rc = car417_report(DBName,userid,processid,afstatus,outputf);
   if (rc != M_CM_OK)
   {
       EWRITE(userid, rc, "car420 ���ͳ������~");
       exit(1);
   }


}

/*--------------------------------------------------------------------*/
long car420_get_db()
{
    int rc;
    $whenever sqlerror goto errexit;

    if (db_select(DBName) == FALSE)
    {
        EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
        return M_CM_DB_NOTOPEN;
    }
    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }

    return M_CM_OK;
errexit:
    printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car420_build()
{
   $char  FormFmt[N_FILE+1];
   $int   StartRow, TitleRow, TotColumn, PgLine, Width;
    long  rc;

   char   FormFile[N_FILE+1];

   $WHENEVER SQLERROR GOTO errexit;


   $SELECT nForm_File, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $FormFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width, $FormTp
      FROM Form
     WHERE ksys_grp = "CA" AND kPgmID = 419;
   strcpy(FormFmt, rtrim(FormFmt));
   sprintf_s(FormFile, sizeof FormFile, "%s.tx", outputf);

   /* create & insert data with temp table */
   rc = car420_accumulate();
   if (rc != M_CM_OK)
       goto errexit;

   return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return FAIL;
}


long car420_accumulate()
{
   $char   stmt[10000];
   $char   ipolicy[21];
   $char   ibroker[11], ileader[11];
   $char   iins_type[7];
   $char   dpolicy_bgn[11],dpolicy_end[11];
   $char   sFull[31];
   $char   sFulla[31];
   $long   existcnt;

   /*  ca_comm_balance */
   $long   mcomm_diff_old,magent_diff_old,mdeal_diff_old;
   $long   mcomm_diff,magent_diff,mdeal_diff;

   /*  ori_ins_type   edr_ins_type  */
   $long   mins_premium=0;
   $long   mdiscount=0;
   $long   mcommission=0,magent=0;
   $char   iendorse[21];
   $char   fcard_class[2];

   /*  commission_agent  */
   $double pcommission=0.0,pagent=0.0;
   $double pcommission_new=0.0,pagent_new=0.0, pbusiness_new=0.0, pdiscount_new=0.0, pextra_charge_new=0.0;
   $long   mcommission_new=0;
   $long   mservice=0;
   $char   ipaid_base[2];
   $char   fstatus[2], drate_ym[5];

   /*  ca_pa_ori   ca_pa_edr  */
   $long   mcomm_33=0,magent_33=0;
   $long   mcomm_new=0,magent_new=0;
   $long   mcomm_33_old=0,magent_33_old=0;
   $long   mcomm_33_diff=0,magent_33_diff=0;
   $char   iinsurant[11];
   $char   iins_scope[2];
   $char   icareer[2];

   /*  comm edr    */
   $char sIdir[9];
   $date dwritten;
   $char iedr_type[3];
   $char ori_fcard_class[2];
   $char ori_iofficer[11];
   $char ori_ibroker[11];
   $int  ibatch_no=0;
   $char ori_fedr_class[2];
   $char ibus_location[11];
    char sIbilling[3];
    char sIbranchIcomp[CA_POL_BRH_NUM];
    char sIcomp_in[BRANCH_ID], sIbranch_in[BRANCH_ID];
   $char ibranch_at[3],icomp_at[3];
   $long fRtnCode;
    char sIcomp_in_short[BRANCH_ID];
   $char temp[POLICY_NUM_1];
   $long stepi;
   $char policy_1[21],policy_2[21];
    char payresult[3], paystatus[32], paydate[9], notedate[9];
   $char fpay[2], iquota[11];
   $char batchno[4];
   $long mdmg_commi=0,mdmg_agent=0;
   $long mlia_commi=0,mlia_agent=0;
   $char fins_grp[2];
   $char branch[3];
   $double dMod=0, mbusiness=0;
   $char iendor68[4];
   $char iins_cat[3];
   $char icar_type[3];
    int  ihasdata;
   $date dply_begin,dply_end;
   $int  same=0;
   $long mservice_tmp;

   $long medr_commission=0,medr_agent=0, lMcommission=0;
   $char deffect[11], iabn_type[2], comp_frate[6], ipgid[11];
   long  rc;
   $char   sCCC1[101], sCCC2[101], sCCC3[101], f980401[2], opt[2], ori_icomm_obj[11];
   double rCCC1, rCCC2, rCCC3;
   $char dlock[31],iroute[21],iroute_accept_edr[21];

   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT;

    existcnt = 0;
    mcomm_diff_old = magent_diff_old = mdeal_diff_old = 0;
    mins_premium = mdiscount = mcommission = magent = 0;
    pcommission = pagent = 0;
    mservice = 0;
    mservice_tmp = 0;
    mcomm_33 = magent_33;
    mcomm_33_old = magent_33_old = 0;
    mcomm_33_diff = magent_33_diff = 0;
    pcommission_new = pagent_new = pbusiness_new = pdiscount_new = pextra_charge_new = 0; 
    dMod = 0;

    rtoday(&dwritten);
    strcpy(iedr_type,"84");

    $BEGIN WORK;

    $SELECT iquota
       INTO $sIdir
       FROM officer
      WHERE iofficer = $userid;
         if (SQLCODE == SQLNOTFOUND)
         {
             sprintf_s(sErrmsg, sizeof sErrmsg,"[%s]�ϥΪ̩|������",userid);
             printf("sErrmsg[%s]\n",sErrmsg);
             goto errexit;
         }

         strncpy(ibranch_at, sIdir, BRANCH_ID-1);
         ibranch_at[BRANCH_ID-1] = '\0';
         printf("userid[%s],sIdir[%s],ibranch_at[%s]\n",userid,sIdir,ibranch_at);

    $SELECT iupcomp
       INTO $icomp_at
       FROM sa_branch_type
      WHERE ibranch = $sIdir;
         if (SQLCODE == SQLNOTFOUND)
         {
             sprintf_s(sErrmsg, sizeof sErrmsg,"�L�k���ϥΪ�[%s]�W�h���[%s]",userid,ibranch_at);
             printf("sErrmsg[%s]\n",sErrmsg);
             goto errexit;
         }
             printf("icomp_at[%s]\n",icomp_at);

    sprintf_s(stmt, sizeof stmt,
     " UPDATE ca_comm_balance             "
     "     SET (fstatus,dadjust,iendorse, remark) "
     "       = (?,?,?,?)                  "
     "   WHERE ipolicy  = ?               "
     "     AND iprocess = ?  ");
     $PREPARE up_bal FROM $stmt; 

    sprintf_s(stmt, sizeof stmt,
     " UPDATE ca_comm_balance             "
     "     SET (fstatus,dadjust,iendorse) "
     "       = (?,?,?)                    "
     "   WHERE ipolicy  = ?               "
     "     AND iins_type = ?              "
     "     AND iprocess = ?  ");
     $PREPARE up_bal_a FROM $stmt; 

    sprintf_s(stmt, sizeof stmt,
     " SELECT fins_grp                    "
     "    FROM insurance_type             "
     "   WHERE iins_type = ? ");
     $PREPARE surid FROM $stmt;

     sprintf_s(stmt, sizeof stmt,
     " SELECT ibroker,dpolicy_bgn,dpolicy_end,iins_type,      "
     "         pcomm,pagent,mdeal,mcomm_diff,magent_diff,mdeal_diff,"
     "         deffect,ipaid_base                             "
     "    FROM ca_comm_balance                                "
     "   WHERE iprocess = ?                                   "
     "     AND ipolicy  = ?                                   "
     "     AND NVL(fstatus,' ') = ' '                         "
     "     AND dadjust IS NULL ");
     $PREPARE pro_id FROM $stmt;
     $DECLARE pro_cur CURSOR FOR pro_id;
    
    ihasdata = 0;
    sprintf_s(stmt, sizeof stmt,
    "  SELECT distinct ipolicy                        "
    "     FROM ca_comm_balance                        " 
    "    WHERE iprocess = ?                           "
    "      AND NVL(fstatus,' ') = ' '                 "
    "      AND dadjust IS NULL                        "
    "    ORDER BY ipolicy ");
     $PREPARE main_id FROM $stmt;
     $DECLARE main_cur CURSOR FOR main_id;
     $OPEN main_cur USING $processid;
     for(;;)
     {
         $FETCH main_cur INTO $ipolicy;
         if (SQLCODE == SQLNOTFOUND) break;
         ihasdata = 1;
         strcpy(sDB,get_db(ipolicy));
         strcpy(sFull,trim(get_full_dbname(sDB)));

          sprintf_s(stmt, sizeof stmt, "SELECT iquota "
                          "  FROM %s:ply_relation     "
                          " WHERE ipolicy = ? " ,sFull);
          $PREPARE get_new_ply FROM $stmt;
          $EXECUTE get_new_ply INTO $iquota USING $ipolicy;
          $FREE get_new_ply;

          /* �~�Z���O�_���� */
          strcpy( opt, "2");
          rc = cm_chk_policy( opt, "", "", iquota, "", "C", "", "");
          if( rc != M_CM_OK)
          {
              strcpy(fstatus, "F");
              strcpy( temp, "");
              strcpy( v_sMsg, cm_get_errmsg( rc));
              sprintf_s(sErrMsg, sizeof sErrMsg, "�O�渹[%s]�����, �]���G%s,����������N�z�O���", ipolicy, v_sMsg);
              $EXECUTE up_bal
                 USING $fstatus,$dwritten,$temp, $sErrMsg, $ipolicy, $processid;
              continue;
          }

         strcpy(fstatus,"S");

          /*  �妸�X��  */
          sprintf_s(stmt, sizeof stmt,
         " SELECT a.fcard_class, a.iofficer, a.ibroker, a.ibatch_no, a.fedr_class, a.ibig_office,  "
         "         a.dply_begin, a.dply_end, a.icomm_obj, a.dlock ,b.iroute "
         "    FROM %s:ply_relation a, %s:policy b "
         "   WHERE a.ipolicy = b.ipolicy and a.ipolicy = ? ",sFull,sFull);
         $PREPARE ply_id FROM $stmt;
         $EXECUTE ply_id 
             INTO $ori_fcard_class, $ori_iofficer, $ori_ibroker, $ibatch_no, $ori_fedr_class, $ibus_location, $dply_begin, $dply_end,
                  $ori_icomm_obj, $dlock, $iroute
            USING $ipolicy;
            if (SQLCODE == SQLNOTFOUND)
            {
               sprintf_s(sErrmsg, sizeof sErrmsg,"�L�k���[%s]�̷s�O�����ɸ��",ipolicy);
               printf("sErrmsg[%s]\n",sErrmsg);
               goto errexit;
            }

            if( strlen(trim(dlock)) != 0 ) /* ���O��B2C��襤�A�ȮɵL�k��� */
            {
               sprintf_s(sErrmsg, sizeof sErrmsg,"���O��[%s]B2C��襤�A�ȮɵL�k���",ipolicy);
               printf("sErrmsg[%s]\n",sErrmsg);
               goto errexit;
            }

            /* �I����H�O�_����O */
            strcpy( opt, "5");
            rc = cm_chk_policy( opt, "", "", "", ori_icomm_obj, "", "", "");
            if( rc != M_CM_OK)
            {
                strcpy( sErrmsg, cm_get_errmsg( rc));
                goto errexit;
            }

            /* get ���s�X���O*/
            strncpy(sIbilling, ipolicy+CAR_POL_CHR_POS-1, 2);
            sIbilling[2]='\0';
            printf("sIbilling[%s]\n",sIbilling);
              /* get ����k�ݤ�����c & �����q*/
            strncpy(sIbranchIcomp, ipolicy, CA_POL_BRH_NUM - 1);
            sIbranchIcomp[CA_POL_BRH_NUM - 1] = '\0';
            printf("sIbranchIcomp[%s]\n",sIbranchIcomp);
    
            fRtnCode = cm_get_unit_in("", sIbranchIcomp, userid,
                                          sIbranchIcomp, "C1", sIcomp_in, sIbranch_in);
            if (fRtnCode != M_CM_OK)
            {
               sprintf_s(sErrmsg, sizeof sErrmsg,"�L�k���o[%s]���N��",sIbranchIcomp);
               printf("sErrmsg[%s]\n",sErrmsg);
               goto errexit;
            }
            /* 00 40 70 */
            printf("sIcomp_in[%s]\n",sIcomp_in);
            /* 00 20 30 40 ...87 */
            printf("sIbranch_in[%s]\n",sIbranch_in);

            strcpy(sIcomp_in_short, get_upcomp(sIcomp_in, USE_BRANCH_ID, USE_SHORT_BRANCH_ID));
            stepi = cm_get_serial_num("C4", sIbilling,
                                            sIcomp_in_short, sIbranch_in,
                                            cm_cdate_str_100(cm_today()),
                                            temp);
            if (stepi != 0)
            {
                 if (stepi == 1 || stepi == 2)
                   stepi = M_CM_DB_NOTOPEN;
                 else if (stepi == 3)
                   stepi = M_CMN_NAUTONUMBERING;

                 sprintf_s(sErrmsg, sizeof sErrmsg,"�۰ʵ����ɦ��~[%ld]",stepi);
                 printf("sErrmsg[%s]\n",sErrmsg);
                 goto errexit;
            }

            policy_1[0]='\0';
            policy_2[0]='\0';
    
            strncpy(policy_1, ipolicy, CAR_POLICY_LEN);
            policy_1[CAR_POLICY_LEN]=0;
    
            printf("END ipolicy split \n");
    
            if (strlen(ipolicy)>CAR_POLICY_LEN)
                strcpy(policy_2,&ipolicy[CAR_POLICY_LEN]);
            else
                strcpy(policy_2," ");
    
            printf("policy_1[%s]\n",policy_1);
            printf("policy_2[%s]\n",policy_2);
            printf("ibatch_no[%d]\n",ibatch_no);
  
            strcpy(batchno,itoa(ibatch_no));
            printf("batchno[%s]\n",batchno);
            ao_chk_charge(sDB, '3', policy_1, policy_2, batchno,
                          payresult, paystatus, paydate, notedate);
    
            printf("ipolicy[%s],payresult[%s]\n",ipolicy,payresult);
    
            if (payresult[0] == 'R')
            {
                strcpy(fpay," ");
            }
            else
            {
                strcpy(fpay,"1");
            }
    
            /**** START �ƥ� ****/
            rc = bk_401(sDB, ipolicy, temp);
            if ( rc != M_CM_OK)
            {
                sprintf_s(sErrmsg, sizeof sErrmsg,"�ƥ��O��[%s]��Ʀ��~return code[%d]",ipolicy,rc);
                printf("sErrmsg[%s]\n",sErrmsg);
                goto errexit;
            }
            /**** END   �ƥ� ****/
           mdmg_commi = mdmg_agent = 0;
           mlia_commi = mlia_agent = 0;

           strcpy(sDBa,get_db(ipolicy));
           strcpy(sFulla,trim(get_full_dbname(sDBa)));

           $OPEN pro_cur USING $processid,$ipolicy ;
           for(;;)
           {
           $FETCH pro_cur
             INTO $ibroker,$dpolicy_bgn,$dpolicy_end,$iins_type,
                  $pcommission,$pagent,$mservice,$mcomm_diff_old,
                  $magent_diff_old,$mdeal_diff_old,$deffect,$ipaid_base;
               if (SQLCODE == SQLNOTFOUND) break;
               strcpy( iins_type, trim( iins_type));
               if( strcmp( iins_type, "21") != 0) /* ���N�I */
               {
                    sprintf_s(stmt, sizeof stmt,
                    " SELECT pbusiness, drate_ym, pdiscount, pextra_charge  "
                    "    FROM %s:ply_ins_type     "
                    "   WHERE ipolicy = ?         "
                    "     AND iins_type = ? ", sFull);
                    $PREPARE get_new_com FROM $stmt;

                   $EXECUTE get_new_com
                       INTO $pbusiness_new, $drate_ym, $pdiscount_new, $pextra_charge_new
                      USING $ipolicy, $iins_type;
                   if( SQLCODE == SQLNOTFOUND)
                   {   sprintf_s(sErrmsg, sizeof sErrmsg,"[%s]�̷s�O��[%s]�I�ؤ��s�b",ipolicy,iins_type);
                       printf("sErrmsg[%s]\n",sErrmsg);
                       goto errexit;
                   }
   
                   $SELECT case when drate >= date('04/01/2009') then '1' else '0' end
                      INTO $f980401
                      FROM ca_rate_date
                     WHERE icode  = $drate_ym
                       AND itable = 'cm_extra_charge';
   
                   if( SQLCODE == SQLNOTFOUND)
                   {
                       sprintf_s(sErrmsg, sizeof sErrmsg,"�O�v�N��[%s],���[�O�βv�O�v�ͮĤ�䤣��,�Ь��ӫO����car120�]�w", drate_ym);
                       printf("sErrmsg[%s]\n",sErrmsg);
                       goto errexit;
                   }
   
                   /* �O�v�ۥѤƤ��� */
                   if( f980401[0] == '1')
                   {
                       printf("pdiscount_new[%f]\n", pdiscount_new);
                       if( pdiscount_new != 0) /* �O�v�ۥѤƤ��ᤣ�i������ */
                       {
                           sprintf_s(sErrmsg, sizeof sErrmsg,"�O�渹[%s],�O�v�ۥѤƤ��ᤣ�i������", ipolicy);
                           printf("sErrmsg[%s]\n",sErrmsg);
                           goto errexit;
                       }
   
                       sprintf_s(sCCC1, sizeof sCCC1 ,"%f", (double)(pdiscount_new + pcommission + pagent));
                       sprintf_s(sCCC2, sizeof sCCC2 ,"%f", (double)( (pextra_charge_new - pbusiness_new) * 100.0));
                       rCCC1 = atof( sCCC1);
                       rCCC2 = atof( sCCC2);
   
                       printf("��+�N+�u[%-3.20f]\n", rCCC1);
                       printf("��-�~   [%-3.20f]\n", rCCC2);
   
                       if ( rCCC1 > rCCC2 )
                       {
                             sprintf_s(sErrmsg, sizeof sErrmsg,"�O�渹[%s],(�����v+�~�޶O�βv) ���i�j�� ���[�O�βv,�Ь��ӫO��", ipolicy);
                             printf("sErrmsg[%s]\n",sErrmsg);
                             goto errexit;
                       }
                   }
               }

               if( strcmp( iins_type, "21") == 0) /* �j���I */
               {
                   mcomm_diff_old = mdeal_diff_old;
               }

               if (strcmp(iins_type,"33") == 0 ||
                   strcmp(iins_type,"35") == 0 ||
                   strcmp(iins_type,"48") == 0 ||
                   strcmp(iins_type,"56") == 0 ||
                   strcmp(iins_type,"136") == 0 ||
                   strcmp(iins_type,"166") == 0 ||
                   strcmp(iins_type,"266") == 0 )
               {
                   sprintf_s(stmt, sizeof stmt,
                    "INSERT INTO %s:ca_pa_edr                                 "
                    "  (iendorse, iins_type, iinsurant, iedr_type, ninsurant, dbirth,      "
                    "   ainsurant, iins_scope, icareer, medrins_amt, fcal_way,  "
                    "   pcal, medrins_prem, medrpure_prem, pcommission,         "
                    "   medr_commission, pagent, medr_agent, pdiscount,         "
                    "   medr_discount, dendorse, napplicant, relation_appl,     "
                    "   nbeneficiary,relation_bene,medr_daily_pay,medr_mr_ins_prem,medr_mr_pure_prem,tbenef, abenef_zip, abenef)   "
                    "  SELECT '%s', a.iins_type, a.iinsurant, '%s', a.ninsurant, a.dbirth,   "
                    "         a.ainsurant, a.iins_scope, a.icareer, 0, 'M',     "
                    "         100, 0, 0, %.2f - a.pcommission,                  "
                    "         b.mcommission, %.2f - a.pagent, b.magent, 0,      "
                    "         0, %ld, a.napplicant, a.relation_appl,            "
                    "         a.nbeneficiary, a.relation_bene,0,0,0,a.tbenef, a.abenef_zip, a.abenef "
                    "    FROM %s:ca_pa_ply a,ca_comm_balance_pa b                          "
                    "   WHERE a.ipolicy    = '%s'                      "
                    "     AND a.iins_type  = '%s'                      "
                    "     AND a.ipolicy    = b.ipolicy                 "
                    "     AND b.iprocess   = '%s'                      "
                    "     AND a.iins_type  = b.iins_type               "
                    "     AND a.iinsurant  = b.iinsurant               "
                    "     AND a.iins_scope = b.iins_scope              "
                    "     AND a.icareer    = b.icareer ",
                        sFull ,temp ,iedr_type ,pcommission ,pagent ,dwritten ,sFull , ipolicy, iins_type, processid);
                      printf("stmt[%s]\n",stmt);
                   $PREPARE caedr FROM $stmt;
                   $EXECUTE caedr;
                   if (SQLCODE == SQLNOTFOUND) {
                      sprintf_s(sErrmsg, sizeof sErrmsg,"ca_comm_balance_pa[%s]��Ʀ��~",ipolicy);
                      printf("sErrmsg[%s]\n",sErrmsg);
                      goto errexit;
                   }

                   sprintf_s(stmt, sizeof stmt,
                    "UPDATE %s:ca_pa_ply                                                  "
                    " SET (pcommission, mcommission, pagent, magent, iendorse,             "
                    "      dendorse, dedr_begin, dedr_end)                                 "
                    "   = ((SELECT %.2f, %s:ca_pa_ply.mcommission + ca_comm_balance_pa.mcommission,   "
                    "              %.2f, %s:ca_pa_ply.magent      + ca_comm_balance_pa.magent, '%s',  "
                    "              %ld, %ld, %ld                                           "
                    "         FROM ca_comm_balance_pa                                      "
                    "        WHERE %s:ca_pa_ply.ipolicy    = ca_comm_balance_pa.ipolicy               "
                    "          AND %s:ca_pa_ply.iinsurant  = ca_comm_balance_pa.iinsurant             "
                    "          AND %s:ca_pa_ply.iins_type  = ca_comm_balance_pa.iins_type             "
                    "          AND %s:ca_pa_ply.iins_scope = ca_comm_balance_pa.iins_scope            "
                    "          AND %s:ca_pa_ply.icareer    = ca_comm_balance_pa.icareer               "
                    "          AND ca_comm_balance_pa.ipolicy = '%s'                                  "
                    "          AND ca_comm_balance_pa.iprocess= '%s'                                  "
                    "     ))                                                               "
                    " WHERE EXISTS (SELECT *                                               "
                    "               FROM ca_comm_balance_pa                                           "
                    "              WHERE %s:ca_pa_ply.ipolicy    = ca_comm_balance_pa.ipolicy         "
                    "                AND %s:ca_pa_ply.iins_type  = ca_comm_balance_pa.iins_type       "
                    "                AND %s:ca_pa_ply.iinsurant  = ca_comm_balance_pa.iinsurant       "
                    "                AND %s:ca_pa_ply.iins_scope = ca_comm_balance_pa.iins_scope      "
                    "                AND %s:ca_pa_ply.icareer    = ca_comm_balance_pa.icareer         "
                    "                AND ca_comm_balance_pa.ipolicy = '%s'                            "
                    "                AND ca_comm_balance_pa.iprocess= '%s')                           "
                    " AND ipolicy = '%s' ",
                      sFull,pcommission,sFull,pagent,sFull,temp,dwritten,dply_begin,dply_end,
                      sFull,sFull,sFull,sFull,sFull,ipolicy,processid,sFull,sFull,sFull,sFull,sFull,ipolicy,processid,ipolicy);
                      printf("stmt[%s]\n",stmt);
                   $PREPARE up_pa_edr FROM $stmt;
                   $EXECUTE up_pa_edr;
               }

                sprintf_s(stmt, sizeof stmt,
                "INSERT INTO %s:edr_ins_type "
                " (iendorse, iins_type, iedr_type, medrinj_cover,          "
                "  medrdea_cover, medrdmg_cover, mdeduct, medrins_prem,    "
                "  medrpure_prem, fcal_way, pcal, qserial, pcommission,    "
                "  medr_commission, pagent, medr_agent, pdiscount, medr_discount,     "
                "  drate_ym, medr_prem, iproduct, ipaid_base,qcount,provision, psex_age, "
                "  mdrunk_prem, mdrunk_pure_prem,mviolate_prem , mviolate_pure_prem) "
                "  SELECT '%s', iins_type, '%s', 0,  "
                "          0, 0, 0, 0,               "
                "          0, 'M', 100, qserial, %.2f - pcommission, %ld, "
                "          %.2f - pagent, %ld, 0, 0,                                  "
                "          drate_ym, 0, iproduct, '%s', 0, provision, psex_age,0,0 ,0,0 "
                "    FROM %s:ply_ins_type "
                "   WHERE ipolicy = '%s'  "
                "     AND iins_type = '%s' ", 
                     sFull, temp, iedr_type, pcommission, mcomm_diff_old,            
                     pagent, magent_diff_old, ipaid_base, sFull, ipolicy, iins_type);
                   printf("stmt[%s]\n",stmt);
                $PREPARE eins2 FROM $stmt;
                $EXECUTE eins2 ;

                sprintf_s(stmt, sizeof stmt,
                "UPDATE %s:ply_ins_type "
                "     SET (iendorse,dendorse,dedr_begin,dedr_end, "
                "          pcommission,mcommission, "
                "          pagent     ,magent     , "
                "          ipaid_base) "
                "       = (?,?,?,?,?,mcommission + ?,?,magent + ?,?) "
                "   WHERE ipolicy = ?    "
                "     AND iins_type = ? ",sFull);
                  printf("stmt[%s]\n",stmt);
                $PREPARE pins2 FROM $stmt;
                $EXECUTE pins2
                   USING $temp,$dwritten,$dply_begin,$dply_end,
                         $pcommission,$mcomm_diff_old,$pagent,$magent_diff_old,$ipaid_base,
                         $ipolicy,$iins_type;
                   if (sqlca.sqlerrd[2] == 0)
                   {
                       sprintf_s(sErrmsg, sizeof sErrmsg,"�L�k��s�̷s�O��[%s][%s]�I�ظ��",ipolicy,iins_type);
                       printf("sErrmsg[%s]\n",sErrmsg);
                       goto errexit;
                   }
                $EXECUTE surid
                    INTO $fins_grp
                   USING $iins_type;
                   if (SQLCODE == SQLNOTFOUND)
                   {
                       sprintf_s(sErrmsg, sizeof sErrmsg,"�L�k�P�_[%s]�O��[%s]�I�ؤ��I��",ipolicy,iins_type);
                       printf("sErrmsg[%s]\n",sErrmsg);
                       goto errexit;
                   }
                 printf("fins_grp[%s]\n",fins_grp);
                 switch(fins_grp[0])
                 {
                   case '1':
                            mdmg_commi += mcomm_diff_old;
                            mdmg_agent += magent_diff_old;
                            break;
                   case '2':
                            mlia_commi += mcomm_diff_old;
                            mlia_agent += magent_diff_old;
                            break;
                   case '3':
                            mlia_commi += mcomm_diff_old;
                            mlia_agent += magent_diff_old;
                            break;
                   default :
                            sprintf_s(sErrmsg, sizeof sErrmsg,"[%s]�O��[%s]�I���I���P�_���~->�I��[%s]",ipolicy,iins_type,fins_grp);
                            printf("sErrmsg[%s]\n",sErrmsg);
                            goto errexit;
                            break;
                 }

                $EXECUTE up_bal_a
                   USING $fstatus,$dwritten,$temp,$ipolicy,$iins_type,$processid;
                      if (sqlca.sqlerrd[2] != 1)
                      {
                          sprintf_s(sErrmsg, sizeof sErrmsg,"�󥿦��\���O���~[%s]�O��[%s]�I��",ipolicy,iins_type);
                          printf("sErrmsg[%s]\n",sErrmsg);
                          goto errexit;
                      }
           }
           $CLOSE pro_cur;

            sprintf_s(stmt, sizeof stmt,
            "INSERT INTO %s:edr_relation                                             "
            "  (iendorse, fcard_class, ipolicy, icard, irelative_ply, irelative_edr, "
            "   fedr_class, fpay, ipay, iedr_field, dedr_begin, dedr_end,            "
            "   ipro_year, ibrand, icar_type, medrdmg_agent, medrdmg_commi,          "
            "   medrdmg_prem, medrdmg_pure_prem, medrlia_agent, medrlia_commi,       "
            "   medrlia_prem, medrlia_pure_prem, ibig_comp, ibig_branch, ibig_office,"
            "   ibig_sales, iresource, ibroker, iofficer, ileader, icorps, iedr_area,"
            "   iedr_cashier, iedr_examiner, dedr_examine, dentry, dendorse,         "
            "   fprint, itreaty, ibranch, iquota, icomp_in, ibranch_in, icomp_at,    "
            "   ibranch_at, medr_ready, medr_stable, medr_compensate, medr_adjcom,   "
            "   medr_research, medr_invest, medr_bus_rule, medr_business,            "
            "   medr_capital, medr_maintain, fcomp_class, fcomp_class_last, fdiscount, medrdmg_disc,   "
            "   medrlia_disc, iedr_return, icar_flag, terminate_rsn, qcount,         "
            "   iofficer_prmt, iquota_prmt, ileader_prmt, irate_type, bzfrom, iroute_comm, icomm_obj, qprovision, isecond_hand, icard_main, qdrunk_driving, isign, "
            "   feply, feedr, aemail_eply,tmobile_eply ,isign_edr,dsign_edr,fsign_status_edr,funder_chk_edr,iprog,qviolate ) "
            "  SELECT '%s', fcard_class, ipolicy, icard, irelative_ply, ' ',         "
            "   '%s', '%s', ' ', ' ', dply_begin, dply_end,                          "
            "   ipro_year, ibrand, icar_type, %ld, %ld,                              "
            "   0, 0, %ld, %ld,                                                      "
            "   0, 0, ibig_comp, ibig_branch, ibig_office,                           "
            "   ibig_sales, iresource, ibroker, iofficer, ileader, icorps, iarea,    "
            "   '%s', '%s', %ld, %ld, %ld,                                           "
            "    '1', itreaty, ibranch, iquota, icomp_in, ibranch_in, '%s',          "
            "    '%s', 0, 0, 0, 0,                                                   "
            "    0, 0, 0, 0,                                                         "
            "    0, 0, fcomp_class, fcomp_class_last, fdiscount, 0,                  "
            "    0, '2', icar_flag, '0', 0,                                          "
            "    iofficer_prmt, iquota_prmt, ileader_prmt, irate_type, bzfrom, iroute_comm, icomm_obj,qprovision,isecond_hand, icard_main, qdrunk_driving, isign,  "
            "    feply, '0', aemail_eply, tmobile_eply,'system',today,40,'N','car420',qviolate "
            "    FROM %s:ply_relation "
            "   WHERE ipolicy = '%s' ",sFull, temp, "B", fpay, 
                                      mdmg_agent,mdmg_commi,mlia_agent,mlia_commi,
                                      userid, userid,
                                      dwritten, dwritten, dwritten,
                                      icomp_at, ibranch_at, sFull, ipolicy);
               printf("stmt[%s]\n",stmt);
             $PREPARE edr2 FROM $stmt;
             $EXECUTE edr2;

           /*1071105008_SC2_ �������Ȩ��z��(FS)�A�éw�ɦ۰ʤU���ɮ�*/
           strcpy(iroute_accept_edr," ");         
           if(strncmp(iroute,"I009",4)==0)
           {
               strcpy(temp, trim(temp));             
               sprintf_s(iroute_accept_edr, sizeof iroute_accept_edr, "CHB%s", temp);             
           }
           printf("-- trace iroute_accept_edr[%s]\n ", iroute_accept_edr); 
           
           sprintf_s(stmt, sizeof stmt,
           "INSERT INTO %s:endorsement                                                             "
           "  (iendorse, qply_period, dply_begin, dply_end, fassured, iassured,                     "
           "   iassured_ext, nassured, ilicense, fsex, fmarriage, nuser,                            "
           "   ibenef, nbenef, aassured, aassured_zip, itel, apayment, apayment_zip,                "
           "   iply_area, nbrand_abbr, ncar_abbr, fcar_note, qcylinder, iengine, ibody,             "
           "   itag, mcar_price, nequipment, flimit, pdmg_align, pbrg_align, plia_align,            "
           "   idmg_rate, pdmg_factor, ibrg_rate, pbrg_factor, qpt, fpt, psex_age, psex_age_damage, lia_class,       "
           "   plia_acc, dmg_acc_1st, dmg_acc_2nd, dmg_acc_3rd, pdmg_acc, fhuman, fcomp_24,         "
           "   payresult, iext_policy, qpro_month, mkilo_ply, mkilo_edr, irisk, irelative_ext,      "
           "   napplicant, dbirth, dissue, iextra_charge, gextra_charge, pextra_charge,             "
           "   iquery_num_damage, iquery_num, mequipment, survey_num, bound_num,        "
           "   abnormal_num, iapplicant, iroute, qlia_acc_sum, qdmg_acc_sum, "
           "   fapplicant,fsex_appl,dbirth_appl,itel_appl,ndeputy_appl,nrelation_appl,ndeputy_assured, "
           "   iassured_cntry, iapplicant_cntry, nassured_cntry, napplicant_cntry, "
           "   foccup, noccup, applicant_foccup, applicant_noccup, iroute_accept,tmobile_appl,aemail_appl, "
           "   dinstall, isequence, ainstall_zip, ainstall) "
           "   SELECT '%s', a.qply_period, a.dply_begin, a.dply_end,                                "
           "          b.fassured, b.iassured, b.iassured_ext, b.nassured,                           "
           "          b.ilicense, b.fsex, b.fmarriage, b.nuser,                                     "
           "          b.ibenef, b.nbenef, b.aassured, b.aassured_zip, b.itel,                       "
           "          b.apayment, b.apayment_zip, b.iply_area, b.nbrand_abbr,                       "
           "          b.ncar_abbr, b.fcar_note, b.qcylinder, b.iengine, b.ibody,                    "
           "          b.itag, b.mcar_price, b.nequipment, b.flimit, b.pdmg_align,                   "
           "          b.pbrg_align, b.plia_align, b.idmg_rate, b.pdmg_factor,                       "
           "          b.ibrg_rate, b.pbrg_factor, b.qpt, b.fpt, b.psex_age, b.psex_age_damage,      "
           "          b.lia_class, b.plia_acc, b.dmg_acc_1st, b.dmg_acc_2nd,                        "
           "          b.dmg_acc_3rd, b.pdmg_acc, b.fhuman, b.fcomp_24,                              "
           "          '%s', b.iext_policy, b.qpro_month, b.mkilo_ply, b.mkilo_edr, b.irisk, b.irelative_ext, "
           "          b.napplicant, b.dbirth, b.dissue, b.iextra_charge, b.gextra_charge, b.pextra_charge,   "
           "          b.iquery_num_damage, b.iquery_num, b.mequipment, b.survey_num, b.bound_num, "
           "          b.abnormal_num, b.iapplicant, b.iroute, b.qlia_acc_sum, b.qdmg_acc_sum, "
           "          b.fapplicant,b.fsex_appl,b.dbirth_appl,b.itel_appl,b.ndeputy_appl,b.nrelation_appl,b.ndeputy_assured, "
           "          CASE WHEN b.iassured_cntry='' THEN '8' ELSE b.iassured_cntry END, "
           "          CASE WHEN b.iapplicant_cntry='' THEN '8' ELSE b.iapplicant_cntry END, b.nassured_cntry, b.napplicant_cntry, "
           "          b.foccup, b.noccup, b.applicant_foccup, b.applicant_noccup,'%s',b.tmobile_appl,b.aemail_appl, "
           "          b.dinstall, b.isequence, b.ainstall_zip, b.ainstall "
           "     FROM %s:ply_relation a,%s:policy b                                                 "
           "    WHERE a.ipolicy = b.ipolicy                                                         "
           "      AND a.ipolicy = '%s' ",sFull ,temp ,payresult, iroute_accept_edr, sFull ,sFull ,ipolicy);
               printf("stmt[%s]\n",stmt);
            $PREPARE endor2 FROM $stmt;
            $EXECUTE endor2;

            sprintf_s(stmt, sizeof stmt,
            "UPDATE %s:ply_relation                                     "
            "      SET (mdmg_agent,mdmg_commi,mlia_agent,mlia_commi)      "
            "        = (mdmg_agent + %ld,mdmg_commi + %ld,                "
            "           mlia_agent + %ld,mlia_commi + %ld)                " 
            "    WHERE ipolicy = '%s' ",sFull,mdmg_agent,mdmg_commi,mlia_agent,mlia_commi,ipolicy);
               printf("stmt[%s]\n",stmt);
             $PREPARE up_new_ply FROM $stmt;
             $EXECUTE up_new_ply;

          strcpy( ipgid, "car420");
          rc = insert_cm_pre_receive_edr( temp, ipolicy, ipgid, v_sMsg);
          if( rc != M_CM_OK)
              goto errexit;

          /* �����妸�X�� */

          sprintf_s(stmt, sizeof stmt, "SELECT ibroker, ileader, mdmg_commi+mlia_commi, mbusiness "
                         "  FROM %s:ply_relation WHERE ipolicy=?", sFull);
          $PREPARE prep1 FROM $stmt;
          $EXECUTE prep1 INTO $ibroker, $ileader, $lMcommission, $mbusiness USING $ipolicy;

          /* car9811303 �j���I99.3.1�O�v */
          if (ori_fcard_class[0] == '1')
          {
              strcpy( iabn_type, "");

              sprintf_s(stmt, sizeof stmt, "SELECT drate_ym"
                             "  FROM %s:ply_ins_type WHERE ipolicy=? AND iins_type = '21'", sFull);
              printf ("[%s]\n", stmt);

              $PREPARE prep4 FROM $stmt;
              $EXECUTE prep4 INTO $comp_frate USING $ipolicy;

              rc = chk_commi_business( 1, iabn_type, comp_frate, lMcommission, mbusiness, v_sMsg);

              if( rc != M_CM_OK)
              {
                  sprintf_s(sErrmsg, sizeof sErrmsg,"�O�渹[%s],[%s]", ipolicy, v_sMsg);
                  printf("sErrmsg[%s]\n",sErrmsg);
                  goto errexit;
              }
          }

         medr_commission = 0;
         medr_agent      = 0;

     }
     $CLOSE main_cur;
     $FREE  main_cur;

      if (ihasdata == 0)
      {
          sprintf_s(sErrmsg, sizeof sErrmsg,"���B�z�Ǹ��L��ƥi�ѧ��");
          printf("sErrmsg[%s]\n",sErrmsg);
          goto errexit;
      }
     $COMMIT WORK;
     return M_CM_OK;
errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);

   rc = SQLCODE;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   EWRITE(userid, rc, sErrmsg);
   exit(1);
}

char *get_db(sIpolicy)
char *sIpolicy;
{
  $char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  static char sTmp_db_name[21];
  static char rtnd[11];

  $WHENEVER SQLERROR GOTO errexit;

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     printf("sTmpScomp = %s\n", sTmpScomp);
     $SELECT iupcomp 
        INTO $sTmpcomp
        FROM branch
       WHERE ibranch_abbr = $sTmpScomp;
      if (SQLCODE==SQLNOTFOUND)
      {
          strcpy(rtnd,itoa(SQLCODE));
          goto errexit;
      }
     /*
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     */
     printf("sTmpcomp = %s\n", sTmpcomp);
     strcpy(sTmp_db_name, sTmpcomp);
  }
  return sTmp_db_name;

errexit:
return rtnd;
}

/*--------------------------------------------------------------------*/
long car420_read_file()
{
    char   filename[50];
    FILE   *fp;
    $char  stmti[1024];
    char   *bp;
    int    rc,j,k,m,n,i,flen;

    sprintf_s(filename, sizeof filename,"%s/dat/car/car420_1.txt",sApHome);
    printf("filename[%s]\n",filename);

    $whenever sqlerror goto errexit;

    flen=1024;
    if ((fp=fopen(filename,"r"))==NULL) {
       sprintf_s(msgbuf, sizeof msgbuf,"%s �ɮ׶}�ҥ���",filename);
       EWRITE(userid,FALSE,msgbuf);
       return FALSE;
    }
    if ((bp=malloc(flen))==NULL) {
       sprintf_s(msgbuf, sizeof msgbuf,"System malloc failed !");
       EWRITE(userid,FALSE,msgbuf);
       return FALSE;
    }

    $begin work;

    $delete from ca_comm_balance
      where iprocess = $processid;

    strcpy(stmti,"insert into ca_comm_balance "
      " (iprocess,ipolicy,iins_type,pcomm,pagent,mdeal,mcomm_diff,"
      " magent_diff,mdeal_diff,ientry,dentry,ipaid_base,iroute,irate_type,iroute_comm) "
      " values (?,?,?,?,?,?,?,?,?,?,today,?,'','','')");
printf("stmt[%s]\n",stmti);
    $prepare ins_comm from $stmti;

    for (i=0;(feof(fp)==0);i++) {
        memset(bp,0x00,flen);
        fgets(bp,flen,fp);
        if (bp[0]==0x00)
           break;
        for(j=0;j<9;j++)
           memset(sdata[j],0x00,41);
        k=m=n=0;
        for (j=0;j<flen;j++) {
            if (bp[j]=='\t' || bp[j]=='\0' || bp[j]=='\n') {
                strncpy(sdata[k],bp+m,j-m);
                sdata[k][j-m]='\0';
                m=j+1;
                k++;
            }
            if (bp[j]=='\n')
                break;
            if (k > 8) break;
        }
        if (sdata[0][0]=='\0') continue;

        rc = car420_ins_comm();
        if (rc != M_CM_OK)
           return rc;
    }
    free(bp); /*1120207002_C02 ���I�֤ߨt�η��X�˴�*/
    $commit work;
    return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   EWRITE(userid, SQLCODE, sErrmsg);
   exit(1);
}
/*--------------------------------------------------------------------*/
long car420_ins_comm()
{
 int    x;
$char   iply[21],iins[7],ipaid[2];
$double pcom,pagt;
$int    mdal,mcom,magt,mdal_d;
char    *conv_str;

    $whenever sqlerror goto errexit;

    for(x=0;x<9;x++) {
       strcpy(sdata[x],rtrim(sdata[x]));
       if (strlen(sdata[x])>20)
          printf("[%d][%s]\n",strlen(sdata[x]),sdata[x]);
    }
    strcpy(iply,sdata[0]);
    strcpy(iins,sdata[1]);
    pcom=atof(sdata[2]);
    pagt=atof(sdata[3]);
    mdal=atoi(sdata[4]);
    mcom=atoi(sdata[5]);
    magt=atoi(sdata[6]);
    mdal_d=atoi(sdata[7]);
    strcpy(ipaid,sdata[8]);

    $execute ins_comm using $processid,$iply,$iins,$pcom,$pagt,
             $mdal,$mcom,$magt,$mdal_d,$userid,$ipaid;

    return M_CM_OK;
errexit:
   printf("[ins_comm]SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   EWRITE(userid, SQLCODE, sErrmsg);
   exit(1);
}
/*--------------------------------------------------------------------*/
long car420_read_pa()
{
    char   filename[50];
    FILE   *fp;
    $char  stmti[1024];
    char   *bp;
    int    rc,j,k,m,n,i,flen;

    sprintf_s(filename, sizeof filename,"%s/dat/car/car420_2.txt",sApHome);
    printf("filename[%s]\n",filename);

    $whenever sqlerror goto errexit;

    flen=1024;
    if ((fp=fopen(filename,"r"))==NULL) {
       sprintf_s(msgbuf, sizeof msgbuf,"%s �ɮ׶}�ҥ���",filename);
       EWRITE(userid,FALSE,msgbuf);
       return FALSE;
    }
    if ((bp=malloc(flen))==NULL) {
       sprintf_s(msgbuf, sizeof msgbuf,"System malloc failed !");
       EWRITE(userid,FALSE,msgbuf);
       return FALSE;
    }

    $begin work;

    $delete from ca_comm_balance_pa
      where iprocess = $processid;

    strcpy(stmti,"insert into ca_comm_balance_pa "
      " (iprocess,ipolicy,iins_type,iinsurant,iins_scope,icareer, "
      " mcommission,magent) "
      "values (?,?,?,?,?,?,?,?)");
    $prepare ins_pa from $stmti;

    for (i=0;(feof(fp)==0);i++) {
        memset(bp,0x00,flen);
        fgets(bp,flen,fp);
        if (bp[0]==0x00)
           break;
        for(j=0;j<7;j++)
           memset(sdata[j],0x00,41);
        k=m=n=0;
        for (j=0;j<flen;j++) {
            if (bp[j]=='\t' || bp[j]=='\0' || bp[j]=='\n') {
                strncpy(sdata[k],bp+m,j-m);
                sdata[k][j-m]='\0';
                m=j+1;
                k++;
            }
            if (bp[j]=='\n')
                break;
            if (k > 8) break;
        }
        if (sdata[0][0]=='\0') continue;

        rc = car420_ins_pa();
        if (rc != M_CM_OK)
           return rc;
    }
    free(bp); /*1120207002_C02 ���I�֤ߨt�η��X�˴�*/
    $commit work;
    return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   EWRITE(userid, SQLCODE, sErrmsg);
   exit(1);
}
/*--------------------------------------------------------------------*/
long car420_ins_pa()
{
 int    x;
$char   iply[21],iins[7],iinsru[11],iscope[2],icrer[2];
$int    mcom,magt;

    $whenever sqlerror goto errexit;

    for(x=0;x<7;x++) {
       strcpy(sdata[x],rtrim(sdata[x]));
       if (strlen(sdata[x])>20)
          printf("[%d][%s]\n",strlen(sdata[x]),sdata[x]);
    }
    strcpy(iply,sdata[0]);
    strcpy(iins,sdata[1]);
    strcpy(iinsru,sdata[2]);
    strcpy(iscope,sdata[3]);
    strcpy(icrer,sdata[4]);
    mcom=atof(sdata[5]);
    magt=atof(sdata[6]);
    $execute ins_pa using $processid,$iply,$iins,$iinsru,$iscope,
             $icrer,$mcom,$magt;

    return M_CM_OK;
errexit:
   printf("[ins_pa]SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   EWRITE(userid, SQLCODE, sErrmsg);
   exit(1);
}
/*--------------------------------------------------------------------*/
