/* ***********************************************
 * Copyright (C) 1993 Intellisys Corporation     *
 *                                               *
 * Program : ca309q01s.ec (Type Block 1)         *
 *                                               *
 * modify by Jessie - 2002.03.28 �[�~�ȥγ���    *
 *                                               *
 * ***********************************************/

#include <stdio.h>
#include "api_xsrv.h"
#include "sql.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"
$include datetime.h;
$include sqlca;
$include "gls_for_ins.h";

struct GLS_FOR_INS *get_gls_for_ins();  /* 1080912006-SC1-�f�ӿo-�s�Wñ��������ˮ�*/

$char  BodyFmt[N_FILE+1];
$char  TitleFmt[N_FILE+1];
char   BodyFile[N_FILE+1];
char   TitleFile[N_FILE+1];
char   outputf[N_FILE+1];

static int linenum=0;

$int   StartRow,TitleRow;
$int   ItemRow, TotColumn;
$int   PgLine=0, Width=0;
int    TotRows,count1=0;

$char  dptbgn[BRANCH_ID], dptend[BRANCH_ID], plydate[YYMMDD];
$char  sIbranchIcomp[CA_POL_BRH_NUM+1];
$char  dpolicy[YYYYMMDD],fdiscount[2];
char   ctype[1],addname[1];
$char  ipolicy[POLICY_NUM_1];
$char  iofficer[EMPLOYEE_ID];
$char  nassured[17],iquota[7],nbranch[13];
int    itype,iacc=0;
$char  pre_branch[3],iacc_type[3],iacc_name[4];
$char  nchi_abv[13];

$long  mply_prem,mpure_prem,mextra_charge;
$double pextra_charge;
$long  dtl_mply_prem[5],dtl_mpure_prem[5],dtl_mextra_charge[5];
$long  brk_mply_prem[5],brk_mpure_prem[5],brk_mextra_charge[5];
$long  tot_mply_prem[5],tot_mpure_prem[5],tot_mextra_charge[5];
$long  dtl_self_ply[2],dtl_self_pure[2],dtl_self_extra[2];
$long  dtl_busi_ply[2],dtl_busi_pure[2],dtl_busi_extra[2];
$long  brk_self_ply[2],brk_self_pure[2],brk_self_extra[2];
$long  brk_busi_ply[2],brk_busi_pure[2],brk_busi_extra[2];
$long  tot_self_ply[2],tot_self_pure[2],tot_self_extra[2];
$long  tot_busi_ply[2],tot_busi_pure[2],tot_busi_extra[2];
$long  dataline[12],pagesum[12],totalsum[12],tmpdata;

$char  DBName[DBNAME];
char   tmpTitle[N_TFILE+1],tmpBody[N_TFILE+1];
char   FullDBName[20];
int    flag_check=0;

char   userid[USER_ID];
$char   FormTp[3];
/* 1080912006-SC1-�f�ӿo-�s�Wñ��������ˮ� */
$long    lDiff_ca_gl=0;

#define NEXTPAGE  6

/*************************************************************/
main(argc,argv)
int argc;
char **argv;
{
   int rc;

   batchinit();
   strcpy(DBName,        isNULLstr(argv[1]));
   strcpy(userid,        isNULLstr(argv[2]));
   strcpy(plydate,       isNULLstr(argv[3]));
   strcpy(sIbranchIcomp, isNULLstr(argv[4]));
   strcpy(ctype,         isNULLstr(argv[5]));
   strcpy(outputf,       isNULLstr(argv[6]));
   strcpy(sIbranchIcomp, trim(sIbranchIcomp));
   strcat(sIbranchIcomp, "*");
   itype=atoi(ctype);
   strcpy(addname,"");

   strcpy(dpolicy,cm_to_infdate(plydate));

   rc=car309_get_db();
   if (rc!=M_CM_OK)
       return rc;

   if (itype==1) /* �]�ȥ� */
       car309_build();
   if (itype==2) /* �~�ȥ� */
       car309_build1();
   if (itype==0) /* ���� */
   {
       strcpy(addname,"A");
       car309_build();
       strcpy(addname,"B");
       car309_build1();
   }
} 

/**********************************************************************/
long car309_get_db()
{
   if(db_select(DBName) == False)
   {
       EWRITE(userid,M_CM_DB_NOTOPEN,"M_CM_DB_NOTOPEN");
       return 0;
   }

   strcpy(FullDBName,get_full_dbname(DBName));
   printf("FullDBName[%s]\n",FullDBName);
   return M_CM_OK;
}
/**********************************************************************/
long car309_build()
{
    int   rc;
    $char fname[101];
    $char yy[YYY], mm[MM], dd[DD];

    $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
            kTot_Col, kPgNum_Line, kWidth, iForm_Tp
       INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow, $ItemRow,
            $TotColumn, $PgLine, $Width, $FormTp
       FROM Form
      WHERE ksys_grp="CA" AND kPgmID = 309 AND iForm_Tp = "1";

    strcpy(TitleFmt,rtrim(TitleFmt));
    strcpy(BodyFmt,rtrim(BodyFmt));

    sprintf_s(TitleFile,sizeof TitleFile,"%s%s.ti",outputf,addname);
    sprintf_s(BodyFile,sizeof BodyFile,"%s%s.bd",outputf,addname);

    rgu_init_report(TitleFmt,TitleFile);
    car309_title();

    rgu_finish_report();

    rgu_init_report(BodyFmt,BodyFile);
    car309_body();
    rgu_finish_report();

    create_sign_form("car309",BodyFile,Width);
    TotRows+=3;
    if(rc=(save_form_info(F_BLK0,"CA",309,userid,FormTp,TotRows,outputf))<0)
       EWRITE(userid,rc,"save_form_info failed");

    printf("plydate[%s]\n",plydate);
    cm_split_ymd_100(plydate,yy,mm,dd);
    sprintf_s(fname,sizeof fname,"���N_�O��_%s%s%s",yy,mm,dd);
    printf("car309_build:fname[%s]\n",fname);
    gen_filename(outputf,addname,fname);
}

/**********************************************************************/
long car309_build1()
{
    int   rc;
    $char fname[101];
    $char yy[YYY], mm[MM], dd[DD];

    $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
            kTot_Col, kPgNum_Line, kWidth, iForm_Tp
       INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow, $ItemRow,
            $TotColumn, $PgLine, $Width, $FormTp
       FROM Form
      WHERE ksys_grp="CA" AND kPgmID = 309 AND iForm_Tp = "2";

    strcpy(TitleFmt,rtrim(TitleFmt));
    strcpy(BodyFmt,rtrim(BodyFmt));

    sprintf_s(TitleFile,sizeof TitleFile,"%s%s.ti",outputf,addname);
    sprintf_s(BodyFile,sizeof BodyFile,"%s%s.bd",outputf,addname);

    rgu_init_report(TitleFmt,TitleFile);
    car309_title1();
    rgu_finish_report();

    rgu_init_report(BodyFmt,BodyFile);
    car309_body1();
    rgu_finish_report();

    create_sign_form("car309",BodyFile,Width);
    TotRows+=3;
    if(rc=(save_form_info(F_BLK1,"CA",309,userid,FormTp,TotRows,outputf))<0)
       EWRITE(userid,rc,"save_form_info failed");

    printf("plydate[%s]\n",plydate);
    cm_split_ymd_100(plydate,yy,mm,dd);
    sprintf_s(fname,sizeof fname,"���N_�O��[�~�ȥ�]_%s%s%s",yy,mm,dd);
    printf("car309_build1:fname[%s]\n",fname);
    gen_filename(outputf,addname,fname);
}

/**********************************************************************/
car309_title()
{
    $long dclosing, plydate_l;
    $short id;
    /* $char ivoucher[ GL_VCHR_NO]; */
    $char ivoucher[13],ivouch_tot[13];
    $char  sub_title[30], datestr[YYYMMDD], yy[YYY], mm[MM], dd[DD];
    $char  tmp_yy[YYY];
    plydate_l=cm_ymd_cdate(plydate);

    strcpy(datestr,cm_cdate_str_100(plydate_l));
    cm_split_ymd_100(datestr,yy,mm,dd);

    printf(">>>> yy[%s] mm[%s] dd[%s]\n",yy,mm,dd);

    printf("yy[%s]\n", yy);

    strncpy( tmp_yy, &yy[1],2);
    tmp_yy[2] = '\0';
    strcpy( yy, tmp_yy);
    printf("yy[%s]\n", yy);
    
    ivouch_tot[0] = '\0';	/* �]�ȦX�᪺֫�J��s�����X */

    $SELECT dlast_closing,ivoucher
       INTO $dclosing:id, $ivoucher
       FROM last_daily_close
      WHERE ibill_type="CA1"
        AND iyear=$yy;

    if (SQLCODE == SQLNOTFOUND) dclosing= (long) 0;
    	
    /* ��J��s�����X, ���h�л\�즳���ǲ����X	modify by sylvia 101.07.23(1001228004_C1) */
   $select unique kcracc_num_tot into $ivouch_tot
      from gl_vchrxn_sub
     where kcracc_num = $ivoucher;
   if (SQLCODE == SQLNOTFOUND) ivouch_tot[0] = '\0';
   
   if (ivouch_tot[0] != '\0')
   		strcpy(ivoucher, ivouch_tot);

    if (dclosing< plydate_l) {
         flag_check=1;
         rgu_put_head_string(1,"(�ˮ֥�)") ;
    } else if (dclosing==plydate_l) {
         strcpy(sub_title,"(�s�����X:") ;
         strcat(sub_title, ivoucher);
         trim_tail_white(sub_title);
         strcat(sub_title, ")");
         rgu_put_head_string(1, sub_title);
    } else {
         rgu_put_head_string(1,"(�ɵo��)") ;
    }

    rgu_put_head_string(1,cm_sysd_cdatetime_100(cm_get_sysd())); /* get_currdt */
    $SELECT nchi_abv INTO $nchi_abv FROM branch
      WHERE ibranch = $DBName;

    rgu_put_head_string(1,DBName);
    rgu_put_head_string(1,nchi_abv);
    rgu_put_head_string(1,yy) ;
    rgu_put_head_string(1,mm) ;
    rgu_put_head_string(1,dd) ;
    rgu_put_head();
    printf("1.after car309_title\n");
}

/**********************************************************************/
car309_title1()
{
    $long dclosing, plydate_l;
    $short id;
    $char ivoucher[ GL_VCHR_NO];
    $char  sub_title[30], datestr[YYYMMDD], yy[YYY], mm[MM], dd[DD];
    $char  tmp_yy[YYY];

    plydate_l=cm_ymd_cdate(plydate);

    strcpy(datestr,cm_cdate_str_100(plydate_l));
    cm_split_ymd_100(datestr,yy,mm,dd);

    printf(">>>> yy[%s] mm[%s] dd[%s]\n",yy,mm,dd);

    strncpy( tmp_yy, &yy[1],2);
    tmp_yy[2] = '\0';
    strcpy( yy, tmp_yy);
    printf("yy[%s]\n", yy);

    $SELECT dlast_closing,ivoucher
       INTO $dclosing:id, $ivoucher
       FROM last_daily_close
      WHERE ibill_type="CA1"
        AND iyear=$yy;

    if (SQLCODE == SQLNOTFOUND) dclosing= (long) 0;

    if (dclosing< plydate_l) {
         flag_check=1;
         rgu_put_head_string(1,"(�~���ˮ֥�)") ;
    } else {
         rgu_put_head_string(1,"(�~�ȥ�)") ;
    }

    rgu_put_head_string(1,cm_sysd_cdatetime_100(cm_get_sysd())); /* get_currdt */
    rgu_put_head_string(1,yy) ;
    rgu_put_head_string(1,mm) ;
    rgu_put_head_string(1,dd) ;
    rgu_put_head();
}

/**********************************************************************/
car309_body()
{
     $char  ipolicy[POLICY_NUM_1],icard[CARD_NUM];
     $char  iofficer[EMPLOYEE_ID],ibroker[BROKER],icashier[EMPLOYEE_ID];
     $char  sIcomm_obj[11];
     $char  iresource[2];
     $long  mdmg_prem,mdmg_commi,mdmg_agent,mlia_prem,mlia_commi,mlia_agent;
     $long  mpa_prem;
     $char  nassured[41],icar_type[CA_CAR_TYPE_NUM];
     $long  dply_begin=0,dply_end=0;
     $int   qserial;
     $char  datestr[YYMMDD];
     $float coverage1,coverage2;
     char   buffer[21];
     $char  stmt_buf1[3000],stmt_file[20];
     $char  stmt_file1[20];
     $char  stmt_file2[20];

     $long  qply_period=0;
     $char  iins_type[7],drate_ym[5];
     $long  mins_premium=0,magent=0,mcommission=0;
     $long  total_prem=0,total_agent,total_commi;

     $char  iproduct[13];
     $char  kclsfyitem[5];
     $char  kreserve[6];
     long   rtncode;
     $char  ncode[15];
     $char  provision[21];
     long    tmpxxx;
     $char xmtppolicy[21];

     $long  tmp_tot_prem, tmp_tot_mcommi, tmp_tot_magent;

     int    i, j;
     $short fins1, fins2;
     
     /* Add variables by Julia Han in 2007/03/05 */
     $char inext_ply[POLICY_NUM_1];
     $char ileader_name[11],iofficer_name[11];
     char strinext_ply[5];
     
     $char buf1_00[500],buf1_22[500],buf1_33[500],buf1_40[500],buf1_66[500],
           buf1_70[500];

           
     /*1080912006-SC1-�f�ӿo-�s�Wñ��������ˮ�*/
    char  v_sMsg[3000];
    $char gl_kacctitem[5],gl_kclsfyitem[5],gl_eacc_title[41];
    $long gl_mdeal,tot_mdeal;
    $int  gl_iseq;
   
    $WHENEVER SQLERROR GOTO errexit;
    
    $EXECUTE IMMEDIATE "DROP TABLE IF EXISTS tmp_gl_list";
    $CREATE TEMP TABLE tmp_gl_list
    (
        iseq        INTEGER         default 0,
        kacctitem   CHAR(4),
        kclsfyitem  CHAR(4),
        eacc_title  CHAR(40),
        tot_mdeal   DECIMAL(15,0)    default 0,
        mdeal       DECIMAL(15,0)    default 0
    ) with no log;
    $CREATE INDEX tmp_gl_idx ON tmp_gl_list (kclsfyitem);
    gl_mdeal=0;gl_iseq = 0;tot_mdeal=0;
    strcpy(gl_kacctitem,"");
    strcpy(gl_kclsfyitem,"");
    strcpy(gl_eacc_title,"");
     printf("1080912006-SC1-�f�ӿo-�s�Wñ��������ˮ�\n");
    IfirstGlsForIns = get_gls_for_ins(dpolicy, "C", "P", &rtncode, v_sMsg);
    if( rtncode != M_CM_OK) return rtncode;
   
    IcurrGlsForIns = IfirstGlsForIns;
    
    while( IcurrGlsForIns)
    {
        printf("iseq[%d]kacctitem    [%s],"
               "kclsfyitem   [%s],"
               "eacc_title   [%s],"
               "mdeal        [%ld]\n",gl_iseq,
                IcurrGlsForIns->kacctitem,
                IcurrGlsForIns->kclsfyitem,
                IcurrGlsForIns->eacc_title,
                IcurrGlsForIns->mdeal);
                
        strcpy(gl_kacctitem,IcurrGlsForIns->kacctitem);
        strcpy(gl_kclsfyitem,IcurrGlsForIns->kclsfyitem);
        strcpy(gl_eacc_title,IcurrGlsForIns->eacc_title);
        gl_mdeal =IcurrGlsForIns->mdeal;
        
        
        $INSERT INTO tmp_gl_list (iseq,kacctitem,kclsfyitem,eacc_title,mdeal)
              VALUES ($gl_iseq,  $gl_kacctitem,  $gl_kclsfyitem,  $gl_eacc_title,  $gl_mdeal);
        gl_iseq++;             
        IcurrGlsForIns = IcurrGlsForIns->next;
    }
    
    
     TotRows=0;
     for (j=0; j<12; j++)
     {
          pagesum[j] = 0;
          totalsum[j] = 0;
          dataline[j]=0;  /** 860219-mag **/ 
     }

     /***** prepare cursor for select ori_ply_relation *****/
     if (flag_check==1)
         strcpy(stmt_file,"ply_relation");
     else
         strcpy(stmt_file,"ori_ply_relation");

     /* �t�X�q���ĤG���q�Ұ�,�H[�I����Hicomm_obj]���N[�g���Hibroker]��� modify by sylvia 100.06.03 */
     /* �t�X�]�|���پ�X,�u�b�x�_����,�����]6�Ӹ�Ʈw���,�����U�e����J���O�ݨD,��Hunion��s���Ӹ�Ʈw��� */
     /* sprintf(stmt_buf1,"SELECT %s %s %s %s %s %s %s FROM %s:%s a %s %s",
             "ipolicy,mdmg_prem,mdmg_commi,mdmg_agent,",
             "mlia_prem,mlia_commi,mlia_agent,",
             "fdiscount,",
             "iofficer,icomm_obj,icashier,iresource,",
             "dply_begin,dply_end,icar_type,",
             "ilast_ply,(select nname from officer where iofficer = a.iofficer),",
             "(select nname from officer where iofficer = a.ileader)",
             FullDBName,stmt_file,
             "WHERE fcard_class='2' AND dpolicy=? AND ipolicy MATCHES ? AND dply_close is not null",
             "ORDER BY ipolicy"); */
    sprintf_s(buf1_00,sizeof buf1_00,"SELECT %s %s %s %s %s %s %s FROM newa00:%s a %s ",
                      "ipolicy,mdmg_prem,mdmg_commi,mdmg_agent,",
                      "mlia_prem,mlia_commi,mlia_agent,", "fdiscount,",
                      "iofficer,icomm_obj,icashier,iresource,",
                      "dply_begin,dply_end,icar_type,",
                      "ilast_ply,(select nname from officer where iofficer = a.iofficer),",
                      "(select nname from officer where iofficer = a.ileader)",
             					stmt_file,
                      "WHERE fcard_class='2' AND dpolicy=? AND ipolicy MATCHES ? AND dply_close is not null");
    sprintf_s(buf1_22,sizeof buf1_22,"SELECT %s %s %s %s %s %s %s FROM newa22:%s a %s ",
                      "ipolicy,mdmg_prem,mdmg_commi,mdmg_agent,",
                      "mlia_prem,mlia_commi,mlia_agent,", "fdiscount,",
                      "iofficer,icomm_obj,icashier,iresource,",
                      "dply_begin,dply_end,icar_type,",
                      "ilast_ply,(select nname from officer where iofficer = a.iofficer),",
                      "(select nname from officer where iofficer = a.ileader)",
             					stmt_file,
                      "WHERE fcard_class='2' AND dpolicy=? AND ipolicy MATCHES ? AND dply_close is not null");
    sprintf_s(buf1_33,sizeof buf1_33,"SELECT %s %s %s %s %s %s %s FROM newa33:%s a %s ",
                      "ipolicy,mdmg_prem,mdmg_commi,mdmg_agent,",
                      "mlia_prem,mlia_commi,mlia_agent,", "fdiscount,",
                      "iofficer,icomm_obj,icashier,iresource,",
                      "dply_begin,dply_end,icar_type,",
                      "ilast_ply,(select nname from officer where iofficer = a.iofficer),",
                      "(select nname from officer where iofficer = a.ileader)",
             					stmt_file,
                      "WHERE fcard_class='2' AND dpolicy=? AND ipolicy MATCHES ? AND dply_close is not null");
    sprintf_s(buf1_40,sizeof buf1_40,"SELECT %s %s %s %s %s %s %s FROM newa40:%s a %s ",
                      "ipolicy,mdmg_prem,mdmg_commi,mdmg_agent,",
                      "mlia_prem,mlia_commi,mlia_agent,", "fdiscount,",
                      "iofficer,icomm_obj,icashier,iresource,",
                      "dply_begin,dply_end,icar_type,",
                      "ilast_ply,(select nname from officer where iofficer = a.iofficer),",
                      "(select nname from officer where iofficer = a.ileader)",
             					stmt_file,
                      "WHERE fcard_class='2' AND dpolicy=? AND ipolicy MATCHES ? AND dply_close is not null");
    sprintf_s(buf1_66,sizeof buf1_66,"SELECT %s %s %s %s %s %s %s FROM newa66:%s a %s ",
                      "ipolicy,mdmg_prem,mdmg_commi,mdmg_agent,",
                      "mlia_prem,mlia_commi,mlia_agent,", "fdiscount,",
                      "iofficer,icomm_obj,icashier,iresource,",
                      "dply_begin,dply_end,icar_type,",
                      "ilast_ply,(select nname from officer where iofficer = a.iofficer),",
                      "(select nname from officer where iofficer = a.ileader)",
             					stmt_file,
                      "WHERE fcard_class='2' AND dpolicy=? AND ipolicy MATCHES ? AND dply_close is not null");
    sprintf_s(buf1_70,sizeof buf1_70,"SELECT %s %s %s %s %s %s %s FROM newa70:%s a %s %s ",
                      "ipolicy,mdmg_prem,mdmg_commi,mdmg_agent,",
                      "mlia_prem,mlia_commi,mlia_agent,", "fdiscount,",
                      "iofficer,icomm_obj,icashier,iresource,",
                      "dply_begin,dply_end,icar_type,",
                      "ilast_ply,(select nname from officer where iofficer = a.iofficer),",
                      "(select nname from officer where iofficer = a.ileader)",
             					stmt_file,
                      "WHERE fcard_class='2' AND dpolicy=? AND ipolicy MATCHES ? AND dply_close is not null",
                      "ORDER BY ipolicy");
    sprintf_s(stmt_buf1,sizeof stmt_buf1, "%s union all %s union all %s union all %s union all %s union all %s",
		         buf1_00, buf1_22, buf1_33, buf1_40, buf1_66, buf1_70);
		         
    printf("stmt_buf1=[%s]\n",stmt_buf1);
     $PREPARE CUR_STMT1 FROM $stmt_buf1;
     $DECLARE scur_ply1 CURSOR FOR CUR_STMT1;

     /***** prepare cursor for select original_ply *****/
     if (flag_check==1)
         strcpy(stmt_file,"policy");
     else
         strcpy(stmt_file,"original_ply");
         
     /* sprintf(stmt_buf1,"SELECT %s FROM %s:%s %s",
                       "nassured",
                       FullDBName,stmt_file,
                       "WHERE ipolicy=?"); */
     sprintf_s(buf1_00,sizeof buf1_00,"SELECT nassured FROM newa00:%s WHERE ipolicy=? ", stmt_file);
     sprintf_s(buf1_22,sizeof buf1_22,"SELECT nassured FROM newa22:%s WHERE ipolicy=? ", stmt_file);
     sprintf_s(buf1_33,sizeof buf1_33,"SELECT nassured FROM newa33:%s WHERE ipolicy=? ", stmt_file);
     sprintf_s(buf1_40,sizeof buf1_40,"SELECT nassured FROM newa40:%s WHERE ipolicy=? ", stmt_file);
     sprintf_s(buf1_66,sizeof buf1_66,"SELECT nassured FROM newa66:%s WHERE ipolicy=? ", stmt_file);
     sprintf_s(buf1_70,sizeof buf1_70,"SELECT nassured FROM newa70:%s WHERE ipolicy=? ", stmt_file);
		 
     sprintf_s(stmt_buf1,sizeof stmt_buf1, "%s union all %s union all %s union all %s union all %s union all %s",
		         buf1_00, buf1_22, buf1_33, buf1_40, buf1_66, buf1_70);
		 
     $PREPARE CUR_STMT2 FROM $stmt_buf1;
     $DECLARE scur_policy1 CURSOR FOR CUR_STMT2;

     /***** prepare cursor for select ori_ins_type *****/
     if (flag_check==1)
         strcpy(stmt_file,"ply_ins_type");
     else
         strcpy(stmt_file,"ori_ins_type");

     /* sprintf(stmt_buf1,"SELECT %s FROM %s:%s %s",
                       "mins_premium,mcommission,magent",
                       FullDBName,stmt_file,
                       "WHERE ipolicy=? AND iins_type='33'"); */
     sprintf_s(buf1_00,sizeof buf1_00,"SELECT %s FROM newa00:%s WHERE ipolicy=? AND iins_type='33' ",
                     "mins_premium,mcommission,magent", stmt_file);
     sprintf_s(buf1_22,sizeof buf1_22,"SELECT %s FROM newa22:%s WHERE ipolicy=? AND iins_type='33' ",
                     "mins_premium,mcommission,magent", stmt_file);
     sprintf_s(buf1_33,sizeof buf1_33,"SELECT %s FROM newa33:%s WHERE ipolicy=? AND iins_type='33' ",
                     "mins_premium,mcommission,magent", stmt_file);
     sprintf_s(buf1_40,sizeof buf1_40,"SELECT %s FROM newa40:%s WHERE ipolicy=? AND iins_type='33' ",
                     "mins_premium,mcommission,magent", stmt_file);
     sprintf_s(buf1_66,sizeof buf1_66,"SELECT %s FROM newa66:%s WHERE ipolicy=? AND iins_type='33' ",
                     "mins_premium,mcommission,magent", stmt_file);
     sprintf_s(buf1_70,sizeof buf1_70,"SELECT %s FROM newa70:%s WHERE ipolicy=? AND iins_type='33' ",
                     "mins_premium,mcommission,magent", stmt_file);

     sprintf_s(stmt_buf1,sizeof stmt_buf1, "%s union all %s union all %s union all %s union all %s union all %s",
		         buf1_00, buf1_22, buf1_33, buf1_40, buf1_66, buf1_70);
                     
     $PREPARE CUR_STMT3 FROM $stmt_buf1;
     $DECLARE scur_ply_ins_a1 CURSOR FOR CUR_STMT3;

     /***** start process *****/
     $OPEN scur_ply1 USING $dpolicy, $sIbranchIcomp, 
                           $dpolicy, $sIbranchIcomp,
                           $dpolicy, $sIbranchIcomp,
                           $dpolicy, $sIbranchIcomp,
                           $dpolicy, $sIbranchIcomp,
                           $dpolicy, $sIbranchIcomp;
     printf("before fetch\n");
     $FETCH scur_ply1    /* fetch first data */
       INTO $ipolicy,$dataline[0],$dataline[1],$dataline[2],
            $dataline[3],$dataline[4],$dataline[5],
            $fdiscount,
            $iofficer,$sIcomm_obj,$icashier,$iresource,
            $dply_begin,$dply_end,$icar_type,$inext_ply,
            $iofficer_name,$ileader_name;

     if (SQLCODE == SQLNOTFOUND) {
         $CLOSE scur_ply1;
         return ;
     }

     while(sqlca.sqlcode==0)
     {
        count1++;
        linenum++;
        if (linenum > 50) {
            car309_page();
            rgu_put_body(NEXTPAGE);
            linenum++;
        }    

        $OPEN scur_policy1 USING $ipolicy, $ipolicy, $ipolicy, $ipolicy, 
                                 $ipolicy, $ipolicy;
        $FETCH scur_policy1
          INTO $nassured;
        if (SQLCODE == SQLNOTFOUND) {
            $CLOSE scur_policy1;
            break;
        }
        $CLOSE scur_policy1;

        $OPEN scur_ply_ins_a1 USING $ipolicy, $ipolicy, $ipolicy,
                                    $ipolicy, $ipolicy, $ipolicy;
        $FETCH scur_ply_ins_a1 INTO $dataline[6],$dataline[7],$dataline[8];
        if (SQLCODE==SQLNOTFOUND) {
            dataline[6]=dataline[7]=dataline[8]=0;
        }
        $CLOSE scur_ply_ins_a1;

        dataline[3]-=dataline[6];
        dataline[4]-=dataline[7];
        dataline[5]-=dataline[8];

        dataline[9]=dataline[0]+dataline[3]+dataline[6];
        dataline[10]=dataline[1]+dataline[4]+dataline[7];
        dataline[11]=dataline[2]+dataline[5]+dataline[8];

        strncpy(buffer,ipolicy, CAR_PLY_TAG_LEN);
        buffer[CAR_PLY_TAG_LEN]='\0';
        rgu_put_body_string(2,buffer,LEFT); /*1 �O�渹�X*/

        strncpy(buffer,nassured,20);
        buffer[20]='\0';
        rgu_put_body_string(2,buffer,LEFT); /*2 �O��W��*/

        rgu_put_body_string(2,rtrim(icar_type),LEFT); /*3 ����*/
        
        /* Decide for �s/��O */
        if (strncmp(inext_ply,"  ",2) == 0 || strcmp(inext_ply,NULL) == 0)
        {
        		strcpy(strinext_ply,"�s�O");
        	} else {
        		strcpy(strinext_ply,"��O");
        	}
 	
        	rgu_put_body_string(2,strinext_ply,LEFT);    /*4 �s/��O*/
        	
        rgu_put_body_string(2,rtrim(sIcomm_obj),LEFT);   /*5 �I����H(�g���H)*/

        strcpy(datestr,cm_cdate_str_100(dply_begin));     
        rgu_put_body_string(2,datestr,LEFT);          /*6 �O�I�_��*/
        
        strcpy(datestr,cm_cdate_str_100(dply_end));
        rgu_put_body_string(2,datestr,LEFT);          /*7 �O�I�״�*/
        /* prepare money data */
        for (j=0; j<9; j++)
        {
           if(j==0||j==3||j==6)
                rfmtlong(dataline[j],"<,<<<,<<&",buffer);
           else
                rfmtlong(dataline[j],"<<<,<<&",buffer);
           rgu_put_body_string(2,buffer,RIGHT);       /*8~16 �O�O,����,�N�z�O*/
           pagesum[j] += dataline[j];
        }

        rfmtlong(dataline[9],"<,<<<,<<&",buffer); 
        rgu_put_body_string(2,buffer,RIGHT);          /*17 �X�p�O�O*/
        rfmtlong(dataline[10],"<<<,<<&",buffer);
        rgu_put_body_string(2,buffer,RIGHT);          /*18 �X�p����*/
        rfmtlong(dataline[11],"<<<,<<&",buffer); 
        rgu_put_body_string(2,buffer,RIGHT);          /*19 �X�p�N�z�O*/
        
        rgu_put_body_string(2,iofficer,LEFT);         /*20 �g��H�N��*/
        rgu_put_body_string(2,iofficer_name,LEFT);    /*21 �g��H�W��*/
        
        rgu_put_body_string(2,ileader_name,LEFT);     /*22 �޲z�H�W��*/
        
        rgu_put_body_string(2,iresource,LEFT);        /*23 �ӷ�*/
        rgu_put_body(2);

        TotRows++;

        $FETCH scur_ply1
          INTO $ipolicy,$dataline[0],$dataline[1],$dataline[2],
               $dataline[3],$dataline[4],$dataline[5],
               $fdiscount,
               $iofficer,$sIcomm_obj,$icashier,$iresource,
               $dply_begin,$dply_end,$icar_type,$inext_ply,
               $iofficer_name,$ileader_name;
     } /* inner loop */

     if (linenum == 0) {
        $CLOSE scur_ply1;
        return ;
     }

     car309_page();
     for (j=0; j<9; j++)
     {
        rfmtlong(totalsum[j],"<<<,<<<,<<&",buffer);
        rgu_put_body_string(5,buffer,RIGHT);
     }

     tmpdata = totalsum[0] + totalsum[3] + totalsum[6];
     tmp_tot_prem = totalsum[0] + totalsum[3] + totalsum[6];
     rfmtlong(tmpdata, "<<<,<<<,<<&", buffer);
     rgu_put_body_string(5,buffer,RIGHT);

     tmpdata = totalsum[1] + totalsum[4] + totalsum[7];
     tmp_tot_mcommi = totalsum[1] + totalsum[4] + totalsum[7];
     rfmtlong(tmpdata, "<<<,<<<,<<&", buffer);
     rgu_put_body_string(5,buffer,RIGHT);

     tmpdata = totalsum[2] + totalsum[5] + totalsum[8];
     tmp_tot_magent = totalsum[2] + totalsum[5] + totalsum[8];
     rfmtlong(tmpdata, "<<<,<<<,<<&", buffer);
     rgu_put_body_string(5,buffer,RIGHT);

     rgu_put_body(5);
     TotRows += 1;

     /* ��ñ���C�L�`���� */
     rgu_put_body(3);
     rgu_put_body_string( 7,itoa(count1),RIGHT);
     rgu_put_body(7);
     rgu_put_body(3);
     TotRows += 3;

     /* �إ�temp table �H�O���U�I�ع����l�ؤ��O�O */
     printf("Begin create temp table CAR309_TMP1\n");
     $CREATE TEMP TABLE CAR309_TMP1
      (
          kclsfyitem   char(4) default ' ',
          total_prem   int  default 0,
          total_commi  int  default 0,
          total_agent  int  default 0
      ) WITH NO LOG;

     /* ���N���I���N�I�|�p��l�ؼg�Jtemp table */
     $INSERT INTO CAR309_TMP1
      SELECT distinct kclsfyitem,0,0,0
        FROM cm_product_code
       WHERE iins_class = 'C'
         AND iins_type <> '21';

     if (flag_check==1)
     {
         strcpy(stmt_file1,"ply_relation a,");
         strcpy(stmt_file2,"ply_ins_type b");
     }
     else
     {
         strcpy(stmt_file1,"ori_ply_relation a,");
         strcpy(stmt_file2,"ori_ins_type b");
     }
printf("-------------------- 685 ------------------------------------------ \n");
     /* sprintf(stmt_buf1,"SELECT %s FROM %s:%s %s:%s WHERE %s %s %s %s",
                       "iins_type,icar_type,qply_period,mins_premium,mcommission,magent,provision ",
                       FullDBName,stmt_file1,
                       FullDBName,stmt_file2,
                       "fcard_class = '2' ",
                       "AND dpolicy = ? ",
                       "AND a.ipolicy MATCHES ? ",
                       "AND a.ipolicy = b.ipolicy "); */
     sprintf_s(buf1_00,sizeof buf1_00,"SELECT %s FROM newa00:%s newa00:%s WHERE %s %s %s %s",
                     "iins_type,icar_type,qply_period,mins_premium,mcommission,magent,provision,drate_ym ",
                     stmt_file1, stmt_file2,
                     "fcard_class = '2' ", "AND dpolicy = ? ",
                     "AND a.ipolicy MATCHES ? ","AND a.ipolicy = b.ipolicy ");
     sprintf_s(buf1_22,sizeof buf1_22,"SELECT %s FROM newa22:%s newa22:%s WHERE %s %s %s %s",
                     "iins_type,icar_type,qply_period,mins_premium,mcommission,magent,provision,drate_ym ",
                     stmt_file1, stmt_file2,
                     "fcard_class = '2' ", "AND dpolicy = ? ",
                     "AND a.ipolicy MATCHES ? ","AND a.ipolicy = b.ipolicy ");
     sprintf_s(buf1_33,sizeof buf1_33,"SELECT %s FROM newa33:%s newa33:%s WHERE %s %s %s %s",
                     "iins_type,icar_type,qply_period,mins_premium,mcommission,magent,provision,drate_ym ",
                     stmt_file1, stmt_file2,
                     "fcard_class = '2' ", "AND dpolicy = ? ",
                     "AND a.ipolicy MATCHES ? ","AND a.ipolicy = b.ipolicy ");
     sprintf_s(buf1_40,sizeof buf1_40,"SELECT %s FROM newa40:%s newa40:%s WHERE %s %s %s %s",
                     "iins_type,icar_type,qply_period,mins_premium,mcommission,magent,provision,drate_ym ",
                     stmt_file1, stmt_file2,
                     "fcard_class = '2' ", "AND dpolicy = ? ",
                     "AND a.ipolicy MATCHES ? ","AND a.ipolicy = b.ipolicy ");
     sprintf_s(buf1_66,sizeof buf1_66,"SELECT %s FROM newa66:%s newa66:%s WHERE %s %s %s %s",
                     "iins_type,icar_type,qply_period,mins_premium,mcommission,magent,provision,drate_ym ",
                     stmt_file1, stmt_file2,
                     "fcard_class = '2' ", "AND dpolicy = ? ",
                     "AND a.ipolicy MATCHES ? ","AND a.ipolicy = b.ipolicy ");
     sprintf_s(buf1_70,sizeof buf1_70,"SELECT %s FROM newa70:%s newa70:%s WHERE %s %s %s %s",
                     "iins_type,icar_type,qply_period,mins_premium,mcommission,magent,provision,drate_ym ",
                     stmt_file1, stmt_file2,
                     "fcard_class = '2' ", "AND dpolicy = ? ",
                     "AND a.ipolicy MATCHES ? ","AND a.ipolicy = b.ipolicy ");
     sprintf_s(stmt_buf1,sizeof stmt_buf1, "%s union all %s union all %s union all %s union all %s union all %s ", 
		         buf1_00, buf1_22, buf1_33, buf1_40, buf1_66, buf1_70);
     printf("stmt_buf1=[%s]\n",stmt_buf1);
		 
     $PREPARE CUR_STMT9 FROM $stmt_buf1;
     $DECLARE scur_ply9 CURSOR FOR CUR_STMT9;
     $OPEN    scur_ply9 USING $dpolicy, $sIbranchIcomp,
                              $dpolicy, $sIbranchIcomp,
                              $dpolicy, $sIbranchIcomp,
                              $dpolicy, $sIbranchIcomp,
                              $dpolicy, $sIbranchIcomp,
                              $dpolicy, $sIbranchIcomp;
                              
     printf("stmt[%s]\n",stmt_buf1);
     tmpxxx = 0;
     for(;;)
     {
         $FETCH scur_ply9 INTO $iins_type,$icar_type,$qply_period,$mins_premium,$mcommission,$magent,$provision,$drate_ym;
         if (SQLCODE == SQLNOTFOUND) break;

         strcpy(iins_type,trim(iins_type));
         strcpy(icar_type,trim(icar_type));
         strcpy(drate_ym ,trim(drate_ym) );

         /* ����|�p��l�� */
         rtncode = get_product_code_car("C",iins_type,icar_type,qply_period,iproduct,kclsfyitem,kreserve, provision,drate_ym);
         if (rtncode != M_CM_OK)
         {
         			printf("+++++++++++++++++++ 751 ----------------------------- \n");
              return rtncode;
         }
         $UPDATE CAR309_TMP1
             SET total_prem  = total_prem  + $mins_premium,
                 total_commi = total_commi + $mcommission,
                 total_agent = total_agent + $magent
           WHERE kclsfyitem  = $kclsfyitem;

         if (sqlca.sqlerrd[2]==0)
         {
              $INSERT INTO CAR309_TMP1 (kclsfyitem, total_prem, total_commi, total_agent)
                                VALUES ($kclsfyitem, $mins_premium, $mcommission, $magent);
         }
     }
     $CLOSE   scur_ply9;

     kclsfyitem[0] = '\0';
     total_prem    = 0;
     total_commi   = 0;
     total_agent   = 0;

     /* �ťզC */
     rgu_put_body(8);
     rgu_put_body(8);
     TotRows += 2;

     /* �|�p��l�ؼ��D�C */
     rgu_put_body(9);
     TotRows += 2;

     printf("Begin out put data from CAR309_TMP1\n");
     $DECLARE ply1_cur CURSOR FOR
       SELECT kclsfyitem, total_prem, total_commi, total_agent
         INTO $kclsfyitem, $total_prem, $total_commi, $total_agent
         FROM CAR309_TMP1
        ORDER BY 1;
     $OPEN    ply1_cur;
     for(;;)
     {
         $FETCH ply1_cur;
         if (SQLCODE == SQLNOTFOUND) break;

         $SELECT ncode[1,14]
            INTO :ncode
            FROM cu_code_data
           WHERE itype = '30'
             AND icode = $kclsfyitem;

         if (SQLCODE == SQLNOTFOUND)
         {
              strcpy(ncode,kclsfyitem);
         }
         printf("[%s][%s][%ld][%ld][%ld]\n",kclsfyitem,ncode,total_prem,total_commi,total_agent);
        
         strcpy(ncode,trim(ncode));
         rgu_put_body_string(10, ncode, LEFT);         /* �|�p��l�ئW�� */

         rfmtlong(total_prem, "<<<,<<<,<<&", buffer);  /* 4100�O�I�O */
         rgu_put_body_string(10,buffer,RIGHT);

         $UPDATE tmp_gl_list
             set tot_mdeal = $total_prem
           WHERE kacctitem ='4100'
             AND kclsfyitem = $kclsfyitem;
         
         rfmtlong(total_commi, "<<<,<<<,<<&", buffer); /* 5101��  �� */
         rgu_put_body_string(10,buffer,RIGHT);

         $UPDATE tmp_gl_list
             set tot_mdeal = $total_commi
           WHERE kacctitem ='5101'
             AND kclsfyitem = $kclsfyitem;
             
         rfmtlong(total_agent, "<<<,<<<,<<&", buffer); /* 5102�N�z�O */
         rgu_put_body_string(10,buffer,RIGHT);

         $UPDATE tmp_gl_list
             set tot_mdeal = $total_agent
           WHERE kacctitem ='5102'
             AND kclsfyitem = $kclsfyitem;
             
         rgu_put_body_string(10,"0",RIGHT);            /* ����O */

         
         rgu_put_body(10);

         TotRows += 1;
     }
     $CLOSE ply1_cur;
     printf("End of Out put data\n");
     $CLOSE scur_ply1;

     /* �|�p��l���`�p���B */
     rfmtlong(tmp_tot_prem, "<<<,<<<,<<&", buffer); /* �O�I�O */
     rgu_put_body_string(11,buffer,RIGHT);

     rfmtlong(tmp_tot_mcommi, "<<<,<<<,<<&", buffer); /* ���� */
     rgu_put_body_string(11,buffer,RIGHT);

     rfmtlong(tmp_tot_magent, "<<<,<<<,<<&", buffer); /* �N�z�O */
     rgu_put_body_string(11,buffer,RIGHT);

     rgu_put_body_string(11,"0",RIGHT);  /* ����O */

     rgu_put_body(11);
     TotRows += 2;
     
    
    gl_mdeal=0;gl_iseq = 0;tot_mdeal=0;
    strcpy(gl_kacctitem,"");
    strcpy(gl_kclsfyitem,"");
    strcpy(gl_eacc_title,"");
    rgu_put_body(12);                TotRows+=3;
    printf("*****************************************************************\n");
    $DECLARE gls_cur CURSOR FOR
      SELECT trim(kacctitem),trim(kclsfyitem),trim(eacc_title),   mdeal ,tot_mdeal,   (tot_mdeal - mdeal)
        INTO $gl_kacctitem,   $gl_kclsfyitem,   $gl_eacc_title,$gl_mdeal,$tot_mdeal,$lDiff_ca_gl
        FROM tmp_gl_list
       WHERE kclsfyitem not in ('1400','1500','1600','1601','3210','3220','3230')
    ORDER BY iseq;
    $OPEN gls_cur;
    for(;;)
    {
         $FETCH gls_cur ;
         printf("kacctitem[%s]",gl_kacctitem);
         printf("kclsfyitem[%s]\n",gl_kclsfyitem);
         printf("gl_mdeal[%ld]\n",gl_mdeal);
         printf("tot_mdeal[%ld]\n",tot_mdeal);
         if (SQLCODE == SQLNOTFOUND) break;
    
        /*�|�p���4100�O�O���J/5103����O��X	�|�p�l��	��l�ئW��	�������B	�`�b���B	�t�B
         �]���^�Ǿ�i�ǲ����ӡA�ݱư��j���I���l��*/
         
         
        rgu_put_body_string(13,gl_kacctitem,1);
        rgu_put_body_string(13,gl_kclsfyitem,1);
        rgu_put_body_string(13,gl_eacc_title,1);
        strcpy(buffer, refmtamt(tot_mdeal,MILLIONTH));
        rgu_put_body_string(13,buffer,1);
        strcpy(buffer, refmtamt(gl_mdeal,MILLIONTH));
        rgu_put_body_string(13,buffer,1);
        strcpy(buffer, refmtamt(lDiff_ca_gl,MILLIONTH));
        rgu_put_body_string(13,buffer,1);
            
        rgu_put_body(13);                TotRows++;
    }
    $CLOSE gls_cur;
    $FREE  gls_cur;
    printf("=================gls================================\n");
     
     return;

errexit:
     EWRITE(userid,SQLCODE,sqlca.sqlerrm);
     return ;
}

/**********************************************************************/
car309_page()
{
     char   buffer[21];
     int    j;
     rgu_put_body(3);
     TotRows++;
     for (j=0; j<9; j++)
     {
        rfmtlong(pagesum[j],"<<<,<<<,<<&",buffer);
        rgu_put_body_string(4,buffer,RIGHT);
        totalsum[j] += pagesum[j];
     }

     tmpdata = pagesum[0] + pagesum[3] + pagesum[6];
     rfmtlong(tmpdata, "<<<,<<<,<<&", buffer);
     rgu_put_body_string(4,buffer,RIGHT);
 
     tmpdata = pagesum[1] + pagesum[4] + pagesum[7];
     rfmtlong(tmpdata, "<<<,<<<,<<&", buffer);
     rgu_put_body_string(4,buffer,RIGHT);

     tmpdata = pagesum[2] + pagesum[5] + pagesum[8];
     rfmtlong(tmpdata, "<<<,<<<,<<&", buffer);
     rgu_put_body_string(4,buffer,RIGHT);

     rgu_put_body(4);
     rgu_put_body(3);
     TotRows += 2;

     for(j=0;j<12;j++)
         pagesum[j]=0;
     linenum=0;
}
/**********************************************************************/
car309_body1()
{
  char   buffer[21];
  $char  stmt_buf1[4000];
  char   stm_ply1[20],stm_ply2[20],stm_ply3[20];
  int    i, j, first;
  $char buf1_00[500],buf1_22[500],buf1_33[500],buf1_40[500],buf1_66[500],
           buf1_70[500];

  $WHENEVER SQLERROR GOTO errexit;

  TotRows=linenum=0;
  for(i=0;i<5;i++) {
      dtl_mply_prem[i]=dtl_mpure_prem[i]=dtl_mextra_charge[i]=0;
      brk_mply_prem[i]=brk_mpure_prem[i]=brk_mextra_charge[i]=0;
      tot_mply_prem[i]=tot_mpure_prem[i]=tot_mextra_charge[i]=0;
     }
  for(i=0;i<2;i++) {
      dtl_self_ply[i]=dtl_self_pure[i]=dtl_self_extra[i]=0;
      dtl_busi_ply[i]=dtl_busi_pure[i]=dtl_busi_extra[i]=0;
      brk_self_ply[i]=brk_self_pure[i]=brk_self_extra[i]=0;
      brk_busi_ply[i]=brk_busi_pure[i]=brk_busi_extra[i]=0;
      tot_self_ply[i]=tot_self_pure[i]=tot_self_extra[i]=0;
      tot_busi_ply[i]=tot_busi_pure[i]=tot_busi_extra[i]=0;
  }

  if(flag_check==1){
     strcpy(stm_ply1,"ply_relation");
     strcpy(stm_ply2,"policy");
     strcpy(stm_ply3,"ply_ins_type");
  }
  else {
     strcpy(stm_ply1,"ori_ply_relation");
     strcpy(stm_ply2,"original_ply");
     strcpy(stm_ply3,"ori_ins_type");
  }
  strcpy(pre_branch,"  ");
     /***** prepare cursor for select ori_ply_relation *****/
     /* sprintf(stmt_buf1,"SELECT %s FROM %s:%s a,%s:%s b %s %s %s %s",
             "a.ipolicy,iofficer,iquota[1,4],nassured[1,16]",
             FullDBName,stm_ply1,
             FullDBName,stm_ply2,
             "WHERE fcard_class='2' AND dpolicy=? ",
             "AND a.ipolicy MATCHES ? ",
             "AND a.ipolicy = b.ipolicy ",
             "ORDER BY 1"); */
  sprintf_s(buf1_00,sizeof buf1_00,"SELECT %s FROM newa00:%s a, newa00:%s b %s %s %s ",
                     "a.ipolicy,iofficer,iquota[1,4],nassured[1,16]",
                     stm_ply1, stm_ply2,
                     "WHERE fcard_class='2' AND dpolicy=? ",
                     "AND a.ipolicy MATCHES ? ", "AND a.ipolicy = b.ipolicy ");
  sprintf_s(buf1_22,sizeof buf1_22,"SELECT %s FROM newa22:%s a, newa22:%s b %s %s %s ",
                     "a.ipolicy,iofficer,iquota[1,4],nassured[1,16]",
                     stm_ply1, stm_ply2,
                     "WHERE fcard_class='2' AND dpolicy=? ",
                     "AND a.ipolicy MATCHES ? ", "AND a.ipolicy = b.ipolicy ");
  sprintf_s(buf1_33,sizeof buf1_33,"SELECT %s FROM newa33:%s a, newa33:%s b %s %s %s ",
                     "a.ipolicy,iofficer,iquota[1,4],nassured[1,16]",
                     stm_ply1, stm_ply2,
                     "WHERE fcard_class='2' AND dpolicy=? ",
                     "AND a.ipolicy MATCHES ? ", "AND a.ipolicy = b.ipolicy ");
  sprintf_s(buf1_40,sizeof buf1_40,"SELECT %s FROM newa40:%s a, newa40:%s b %s %s %s ",
                     "a.ipolicy,iofficer,iquota[1,4],nassured[1,16]",
                     stm_ply1, stm_ply2,
                     "WHERE fcard_class='2' AND dpolicy=? ",
                     "AND a.ipolicy MATCHES ? ", "AND a.ipolicy = b.ipolicy ");
  sprintf_s(buf1_66,sizeof buf1_66,"SELECT %s FROM newa66:%s a, newa66:%s b %s %s %s ",
                     "a.ipolicy,iofficer,iquota[1,4],nassured[1,16]",
                     stm_ply1, stm_ply2,
                     "WHERE fcard_class='2' AND dpolicy=? ",
                     "AND a.ipolicy MATCHES ? ", "AND a.ipolicy = b.ipolicy ");
  sprintf_s(buf1_70,sizeof buf1_70,"SELECT %s FROM newa70:%s a, newa70:%s b %s %s %s %s ",
                     "a.ipolicy,iofficer,iquota[1,4],nassured[1,16]",
                     stm_ply1, stm_ply2, "WHERE fcard_class='2' AND dpolicy=? ",
                     "AND a.ipolicy MATCHES ? ", "AND a.ipolicy = b.ipolicy ",
                     "ORDER BY 1");
  sprintf_s(stmt_buf1,sizeof stmt_buf1, "%s union all %s union all %s union all %s union all %s union all %s ",
		         buf1_00, buf1_22, buf1_33, buf1_40, buf1_66, buf1_70 );
             
     printf(" -- 963 --- stmt_buf1 = [%s]\n",stmt_buf1);
     $PREPARE CUR_STMT11 FROM $stmt_buf1;
     $DECLARE scur_ply11 CURSOR FOR CUR_STMT11;

     /***** prepare cursor for select ori_ins_type *****/
     /* sprintf(stmt_buf1,"SELECT %s FROM %s:%s %s %s",
             "iproduct[4,5],sum(mins_premium),sum(mpure_prem) ",
             FullDBName,stm_ply3,
             "WHERE ipolicy=? ",
             "GROUP BY 1"); */
     sprintf_s(buf1_00,sizeof buf1_00,"SELECT %s FROM newa00:%s WHERE ipolicy=? group by 1 ",
                     "iproduct[4,5],sum(mins_premium),sum(mpure_prem) ", stm_ply3);
     sprintf_s(buf1_22,sizeof buf1_22,"SELECT %s FROM newa22:%s WHERE ipolicy=? group by 1 ",
                     "iproduct[4,5],sum(mins_premium),sum(mpure_prem) ", stm_ply3);
     sprintf_s(buf1_33,sizeof buf1_33,"SELECT %s FROM newa33:%s WHERE ipolicy=? group by 1 ",
                     "iproduct[4,5],sum(mins_premium),sum(mpure_prem) ", stm_ply3);
     sprintf_s(buf1_40,sizeof buf1_40,"SELECT %s FROM newa40:%s WHERE ipolicy=? group by 1 ",
                     "iproduct[4,5],sum(mins_premium),sum(mpure_prem) ", stm_ply3);
     sprintf_s(buf1_66,sizeof buf1_66,"SELECT %s FROM newa66:%s WHERE ipolicy=? group by 1 ",
                     "iproduct[4,5],sum(mins_premium),sum(mpure_prem) ", stm_ply3);
     sprintf_s(buf1_70,sizeof buf1_70,"SELECT %s FROM newa70:%s WHERE ipolicy=?  group by 1 ",
                     "iproduct[4,5],sum(mins_premium),sum(mpure_prem) ", stm_ply3);
                     
     sprintf_s(stmt_buf1,sizeof stmt_buf1, "%s union all %s union all %s union all %s union all %s union all %s ",
		         buf1_00, buf1_22, buf1_33, buf1_40, buf1_66, buf1_70 );
                     
     printf(" --- 989 -- stmt_buf1=[%s]\n",stmt_buf1);
     $PREPARE CUR_STMT31 FROM $stmt_buf1;
     $DECLARE scur_ply_ins_a11 CURSOR FOR CUR_STMT31;

     /***** start process *****/
     $OPEN scur_ply11 USING $dpolicy, $sIbranchIcomp,$dpolicy, $sIbranchIcomp,
                            $dpolicy, $sIbranchIcomp,$dpolicy, $sIbranchIcomp,
                            $dpolicy, $sIbranchIcomp,$dpolicy, $sIbranchIcomp;

     while(1) {
         $FETCH scur_ply11    /* fetch first data */
         INTO $ipolicy,$iofficer,$iquota,$nassured;
         if(SQLCODE == SQLNOTFOUND) break;
         
         if (strncmp(pre_branch,"  ",2)==0) {
             strncpy(pre_branch,ipolicy,2);
             $SELECT nchi_full INTO $nchi_abv FROM branch
               WHERE ibranch = $pre_branch;
             rgu_put_body_string(1,pre_branch,1);
             rgu_put_body_string(1,nchi_abv,1);
             rgu_put_body(1); TotRows++;
         }
         else if (strncmp(pre_branch,ipolicy,2)!=0) {
             car309_tot();
             rgu_put_body(NEXTPAGE); TotRows++;
             strncpy(pre_branch,ipolicy,2);
             $SELECT nchi_full INTO $nchi_abv FROM branch
               WHERE ibranch = $pre_branch;
             rgu_put_body_string(1,pre_branch,1);
             rgu_put_body_string(1,nchi_abv,1);
             rgu_put_body(1); TotRows++;
         } 
             
         iquota[4]='\0';
         strcat(iquota,"00");
         $select nbranch[1,12] into $nbranch
            from sa_branch_type
           where ibranch = $iquota; 
				 printf(" ------- 1027 ------ ipolicy=[%s]\n",ipolicy);
         $OPEN scur_ply_ins_a11 USING $ipolicy, $ipolicy, $ipolicy,
                                      $ipolicy, $ipolicy, $ipolicy;
         first=0;
         strcpy(iacc_name," ");
         while(1) {
             $FETCH scur_ply_ins_a11
               INTO $iacc_type,$mply_prem,$mpure_prem;
             if (SQLCODE==SQLNOTFOUND) {
                 if (first) car309_dtl();
                 break;
             }
             first=1;

             iacc=atoi(iacc_type);
             mextra_charge=mply_prem - mpure_prem;
             
             if (iacc==10) {
                 strcpy(iacc_name,"�ۥ�");
                 dtl_mply_prem[0]=dtl_self_ply[0]=mply_prem;
                 dtl_mpure_prem[0]=dtl_self_pure[0]=mpure_prem;
                 dtl_mextra_charge[0]=dtl_self_extra[0]=mextra_charge;
             }
             if (iacc==11) {
                 strcpy(iacc_name,"�ӷ~");
                 dtl_mply_prem[0]=dtl_busi_ply[0]=mply_prem;
                 dtl_mpure_prem[0]=dtl_busi_pure[0]=mpure_prem;
                 dtl_mextra_charge[0]=dtl_busi_extra[0]=mextra_charge;
             }
             if (iacc==12) {
                 strcpy(iacc_name,"�ۥ�");
                 dtl_mply_prem[1]=dtl_self_ply[1]=mply_prem;
                 dtl_mpure_prem[1]=dtl_self_pure[1]=mpure_prem;
                 dtl_mextra_charge[1]=dtl_self_extra[1]=mextra_charge;
             }
             if (iacc==13) {
                 strcpy(iacc_name,"�ӷ~");
                 dtl_mply_prem[1]=dtl_busi_ply[1]=mply_prem;
                 dtl_mpure_prem[1]=dtl_busi_pure[1]=mpure_prem;
                 dtl_mextra_charge[1]=dtl_busi_extra[1]=mextra_charge;
             }
             if (iacc==24) {
                 dtl_mply_prem[2]=mply_prem;
                 dtl_mpure_prem[2]=mpure_prem;
                 dtl_mextra_charge[2]=mextra_charge;
             }
             if (iacc==28) {
                 dtl_mply_prem[3]=mply_prem;
                 dtl_mpure_prem[3]=mpure_prem;
                 dtl_mextra_charge[3]=mextra_charge;
             }
        }
        $close scur_ply_ins_a11;
     }
     $close scur_ply11;
     $free  scur_ply11;
     $free  scur_ply_ins_a11;

     car309_tot();

  return;

errexit:
  EWRITE(userid,SQLCODE,sqlca.sqlerrm);
  return ;
}
/*--------------------------------------------------------------------*/
car309_dtl()
{
    int   i;
    char  buf1[20],buf2[20],buf3[20],buf4[20];

    linenum++;
    if (linenum > 50) {
        car309_brk();
        rgu_put_body(NEXTPAGE);
        rgu_put_body_string(1,pre_branch,1);
        rgu_put_body_string(1,nchi_abv,1);
        rgu_put_body(1); TotRows++;
        linenum++;
    }
    for(i=0;i<4;i++) {
        dtl_mply_prem[4]+=dtl_mply_prem[i];
        dtl_mpure_prem[4]+=dtl_mpure_prem[i];
        dtl_mextra_charge[4]+=dtl_mextra_charge[i];
    }
    for(i=0;i<5;i++) {
        brk_mply_prem[i]+=dtl_mply_prem[i];
        brk_mpure_prem[i]+=dtl_mpure_prem[i];
        brk_mextra_charge[i]+=dtl_mextra_charge[i];
    }
    for(i=0;i<2;i++) {
        brk_self_ply[i]+=dtl_self_ply[i];
        brk_self_pure[i]+=dtl_self_pure[i];
        brk_self_extra[i]+=dtl_self_extra[i];
        brk_busi_ply[i]+=dtl_busi_ply[i];
        brk_busi_pure[i]+=dtl_busi_pure[i];
        brk_busi_extra[i]+=dtl_busi_extra[i];
    }
    rgu_put_body_string(2,ipolicy,1);
    rgu_put_body_string(2,nassured,1);
    rgu_put_body_string(2,nbranch,1);
    rgu_put_body_string(2,iofficer,1);
    rgu_put_body_string(2,iacc_name,1);
    for(i=0;i<5;i++) {
        rfmtlong(dtl_mpure_prem[i], "-------&", buf1);
        rfmtlong(dtl_mextra_charge[i], "-------&", buf2);
        if (dtl_mply_prem[i]==0)
            pextra_charge=0;
        else
            pextra_charge=(double)dtl_mextra_charge[i]/dtl_mply_prem[i] * 100;
        rfmtdouble(pextra_charge, "---.--", buf3);
        rfmtlong(dtl_mply_prem[i], "-------&", buf4);
        rgu_put_body_string(2,buf1,1);
        rgu_put_body_string(2,buf2,1);
        rgu_put_body_string(2,buf3,1);
        rgu_put_body_string(2,buf4,1);
    }
    rgu_put_body(2); TotRows++;
    for(i=0;i<5;i++)
        dtl_mply_prem[i]=dtl_mpure_prem[i]=dtl_mextra_charge[i]=0;
    for(i=0;i<2;i++) {
        dtl_self_ply[i]=dtl_self_pure[i]=dtl_self_extra[i]=0;
        dtl_busi_ply[i]=dtl_busi_pure[i]=dtl_busi_extra[i]=0;
    }
}
/*--------------------------------------------------------------------*/
car309_brk()
{
    int   i;
    char  buf1[20],buf2[20],buf3[20],buf4[20];

    for(i=0;i<5;i++) {
        tot_mply_prem[i]+=brk_mply_prem[i];
        tot_mpure_prem[i]+=brk_mpure_prem[i];
        tot_mextra_charge[i]+=brk_mextra_charge[i];
    }
    for(i=0;i<2;i++) {
        tot_self_ply[i]+=brk_self_ply[i];
        tot_self_pure[i]+=brk_self_pure[i];
        tot_self_extra[i]+=brk_self_extra[i];
        tot_busi_ply[i]+=brk_busi_ply[i];
        tot_busi_pure[i]+=brk_busi_pure[i];
        tot_busi_extra[i]+=brk_busi_extra[i];
    }
    for(i=0;i<5;i++) {
        rfmtlong(brk_mpure_prem[i], "-------&", buf1);
        rfmtlong(brk_mextra_charge[i], "-------&", buf2);
        if (brk_mply_prem[i]==0)
            pextra_charge=0;
        else
            pextra_charge=(double)brk_mextra_charge[i]/brk_mply_prem[i] * 100;
        rfmtdouble(pextra_charge, "---.--", buf3);
        rfmtlong(brk_mply_prem[i], "-------&", buf4);
        rgu_put_body_string(4,buf1,1);
        rgu_put_body_string(4,buf2,1);
        rgu_put_body_string(4,buf3,1);
        rgu_put_body_string(4,buf4,1);
    }
    rgu_put_body(3); TotRows++;
    rgu_put_body(4); TotRows++;
/***
    rgu_put_body_string(7,"�ۥ�" ,1);
    for(i=0;i<2;i++) {
        rfmtlong(brk_self_pure[i], "-------&", buf1);
        rfmtlong(brk_self_extra[i], "-------&", buf2);
        if (brk_self_ply[i]==0)
            pextra_charge=0;
        else
            pextra_charge=(double)brk_self_extra[i]/brk_self_ply[i] * 100;
        rfmtdouble(pextra_charge, "---.--", buf3);
        rfmtlong(brk_self_ply[i], "-------&", buf4);
        rgu_put_body_string(7,buf1,1);
        rgu_put_body_string(7,buf2,1);
        rgu_put_body_string(7,buf3,1);
        rgu_put_body_string(7,buf4,1);
    }
    rgu_put_body(7); TotRows++;
    rgu_put_body_string(7,"��~" ,1);
    for(i=0;i<2;i++) {
        rfmtlong(brk_busi_pure[i], "-------&", buf1);
        rfmtlong(brk_busi_extra[i], "-------&", buf2);
        if (brk_busi_ply[i]==0)
            pextra_charge=0;
        else
            pextra_charge=(double)brk_busi_extra[i]/brk_busi_ply[i] * 100;
        rfmtdouble(pextra_charge, "---.--", buf3);
        rfmtlong(brk_busi_ply[i], "-------&", buf4);
        rgu_put_body_string(7,buf1,1);
        rgu_put_body_string(7,buf2,1);
        rgu_put_body_string(7,buf3,1);
        rgu_put_body_string(7,buf4,1);
    }
    rgu_put_body(7); TotRows++;
***/
    rgu_put_body(3); TotRows++;
    for(i=0;i<5;i++)
        brk_mply_prem[i]=brk_mpure_prem[i]=brk_mextra_charge[i]=0;
    for(i=0;i<2;i++) {
        brk_self_ply[i]=brk_self_pure[i]=brk_self_extra[i]=0;
        brk_busi_ply[i]=brk_busi_pure[i]=brk_busi_extra[i]=0;
    }
    linenum=0;
}
/*--------------------------------------------------------------------*/
car309_tot()
{
    int   i;
    char  buf1[20],buf2[20],buf3[20],buf4[20];

    car309_brk();

    for(i=0;i<5;i++) {
        rfmtlong(tot_mpure_prem[i], "-------&", buf1);
        rfmtlong(tot_mextra_charge[i], "-------&", buf2);
        if (tot_mply_prem[i]==0)
            pextra_charge=0;
        else
            pextra_charge=(double)tot_mextra_charge[i]/tot_mply_prem[i] * 100;
        rfmtdouble(pextra_charge, "---.--", buf3);
        rfmtlong(tot_mply_prem[i], "-------&", buf4);
        rgu_put_body_string(5,buf1,1);
        rgu_put_body_string(5,buf2,1);
        rgu_put_body_string(5,buf3,1);
        rgu_put_body_string(5,buf4,1);
    }
    rgu_put_body(5); TotRows++;

    rgu_put_body_string(7,"�ۥ�" ,1);
    for(i=0;i<2;i++) {
        rfmtlong(tot_self_pure[i], "-------&", buf1);
        rfmtlong(tot_self_extra[i], "-------&", buf2);
        if (tot_self_ply[i]==0)
            pextra_charge=0;
        else
            pextra_charge=(double)tot_self_extra[i]/tot_self_ply[i] * 100;
        rfmtdouble(pextra_charge, "---.--", buf3);
        rfmtlong(tot_self_ply[i], "-------&", buf4);
        rgu_put_body_string(7,buf1,1);
        rgu_put_body_string(7,buf2,1);
        rgu_put_body_string(7,buf3,1);
        rgu_put_body_string(7,buf4,1);
    }
    rgu_put_body(7); TotRows++;
    rgu_put_body_string(7,"��~" ,1);
    for(i=0;i<2;i++) {
        rfmtlong(tot_busi_pure[i], "-------&", buf1);
        rfmtlong(tot_busi_extra[i], "-------&", buf2);
        if (tot_busi_ply[i]==0)
            pextra_charge=0;
        else
            pextra_charge=(double)tot_busi_extra[i]/tot_busi_ply[i] * 100;
        rfmtdouble(pextra_charge, "---.--", buf3);
        rfmtlong(tot_busi_ply[i], "-------&", buf4);
        rgu_put_body_string(7,buf1,1);
        rgu_put_body_string(7,buf2,1);
        rgu_put_body_string(7,buf3,1);
        rgu_put_body_string(7,buf4,1);
    }
    rgu_put_body(7); TotRows++;
    rgu_put_body(3); TotRows++;
    for(i=0;i<5;i++)
        tot_mply_prem[i]=tot_mpure_prem[i]=tot_mextra_charge[i]=0;
    for(i=0;i<2;i++) {
        tot_self_ply[i]=tot_self_pure[i]=tot_self_extra[i]=0;
        tot_busi_ply[i]=tot_busi_pure[i]=tot_busi_extra[i]=0;
    }
}
/*--------------------------------------------------------------------*/
