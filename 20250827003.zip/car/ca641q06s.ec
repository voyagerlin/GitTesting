/**********************************************************************/
/*   program id   : ca641q06s.ec                                      */
/*   program name : �j���I�t����--�T���O�O���ŲM��q���H�o�@�~        */
/*   date written : 2016/11/28                                        */
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <time.h>
#include <math.h>
#include "api_xsrv.h"
$include datetime.h;

/*--------------------------------------------------------------------*/

DBinfo  *list;
int   count_db, sum_mail, mail_acept, i;
FILE    *fp;
char  outputf[N_FILE+1], ftitle[1024], filename[150],sApHome[30], 
      msgbuf[1000];
char  ddate1[11],  ddate2[11];
$loc_t 	ctxt, ctxt_M;
$char sContent[5000],sCont_M[5000],email[51], chinese_name[11], Porj_id[11];
$char DBName[5], userid[11], stmt[1000];
$char send_date[11], dtrans_bgn[6],dtrans_end[6], pre_ileader[12], nproject[255], 
      fname[100];
$int  mail_count;
int  rc;

/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
    time_t tstart, tstop;
    float tused=0;

    batchinit();
    strcpy(DBName,      isNULLstr(argv[1]));
    strcpy(userid,      isNULLstr(argv[2]));
    strcpy(dtrans_bgn,  isNULLstr(argv[3]));    /* ���ɦ~��(�_) */
    strcpy(dtrans_end,  isNULLstr(argv[4]));    /* ���ɦ~��(��) */
    strcpy(ddate1,      isNULLstr(argv[5]));    /* mail date */
    strcpy(nproject,    isNULLstr(argv[6]));    /* mail �D�� */
    strcpy(outputf,     isNULLstr(argv[7]));
    
    strcpy(send_date, cm_to_infdate(ddate1));

    /***********************************************/
    time(&tstart);  /* �p�ɶ}�l */

    /***********************************************/
    printf("1.car6416_get_db() \n");
    rc = car6416_get_db();
    if (rc != M_CM_OK) {
        printf("error on car6416_get_db\n");
        return rc;
    }
    
    printf("2.car6416_init_data() \n");
    rc = car6416_init_data();
    if (rc != M_CM_OK) {
        printf("error on car6416_init_data\n");
        return rc;
    }

    /* �^���n�o�email����� */
    printf("3.car6416_ply_data() \n");
    rc = car6416_ply_data();
    if (rc != M_CM_OK) {
    
        printf("error on car6416_ply_data()\n");
        return rc;
    }

    /* �o�email���޲z�H�B�֫O���f�B���ťD�� */
    printf("4.car6416_send_email() \n");
    strcpy(Porj_id,"CAR641");  /* �j��04:30am �H�o */
    rc=car6416_send_email();
    if (rc != M_CM_OK) {
        printf("error on car6416_send_email\n");
        return rc;
    }
        
    /* �o�e���浲�G��mail���ϥΪ� */
    printf("5.car6416_final_email() \n");
    rc=car6416_final_email();
    if (rc != M_CM_OK) {
        printf("error on car6416_final_email\n");
        return rc;
    }
        
    /* �^������ƥi��cmn202�U�� */
    printf("6.car6416_print() \n");
    rc=car6416_print();
    if (rc != M_CM_OK) {
        printf("error on car6416_print\n");
        return rc;
    }
    
    /***********************************************/
        time(&tstop);  /* �p�ɵ��� */
        tused=difftime(tstop, tstart);
        printf("������� = %f  ��\n", tused);
    /***********************************************/
}

/*--------------------------------------------------------------------*/
long car6416_get_db()
{
    long	rc;

    if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
    }

    if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
    {
        EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
        return M_CM_NOT_DBLIST;

    }

    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }

    return M_CM_OK;
}
/*--------------------------------------------------------------------*/
long car6416_init_data()
{
    $whenever sqlerror goto errexit;
    
    /* ��temp table */
    $create temp table ca6416_a1
    (
        ntype           char(30),   -- ���O�W��
        icard           char(20),   -- �O�I�Ҹ�
        nassured        char(20),   -- (�O�o)�Q�O�I�H
        iassured        char(15),   -- (�O�o)�����Ҹ�/�νs
        itag            char(15),   -- (�O�o)����, 
        ilevel2         char(3),    -- (�O�o)�ˮֵ��� 
        fsex2           char(2),    -- (�O�o)�ˮ֩ʧO  
        dbirth2         date,       -- (�O�o)�ˮ֥ͤ�  
        icar_type2      char(3),    -- (�O�o)�ˮ֨���  
        qpt2            int,        -- (�O�o)�ˮ֭����ƶq  
        fpt2            char(1),    -- (�O�o)�ˮ֭������  
        qdrunk2         int,        -- (�O�o)�ˮְs�r����  
        mprem2          int,        -- (�O�o)�ˮ��`�O�O
        ipolicy         char(20),   -- (�̷s�O��)�O�渹
        nassured_ply    char(40),   -- (�̷s�O��)�Q�O�I�H
        iassured_ply    char(15),   -- (�̷s�O��)�����Ҹ�/�νs
        itag_ply        char(15),   -- (�̷s�O��)���� 
        fcomp_class     char(3),    -- (�̷s�O��)���� 
        fsex_ply        char(2),    -- (�̷s�O��)�m�O 
        dbirth_ply      date,       -- (�̷s�O��)�ͤ�
        icar_type_ply   char(3),    -- (�̷s�O��)����
        qpt_ply         int,        -- (�̷s�O��)�����ƶq
        fpt             char(1),    -- (�̷s�O��)�������
        qdrunk_driving  int,        -- (�̷s�O��)�s�r����
        premium_ply     int,        -- (�̷s�O��)�`�O�O
        dpolicy         date,       -- (�̷s�O��)ñ���
        iofficer        char(11),   -- (�̷s�O��)�g��N��
        nleader         char(10),   -- (�̷s�O��)�޲z�H�W��
        nquota          char(40),   -- (�̷s�O��)�~�Z���W��
        nreason1        varchar(240,0),  -- (�̷s�O��)��Ƥ��ŭ�]_�s�w
        nfstatus        char(2),    -- ���B�z�`�G(�ť�)
        iquota          char(10),   -- (�̷s�O��)�~�Z���N��
        ileader         char(11),   -- (�̷s�O��)�޲z�H�N��
        ileader3        char(11)   -- (�̷s�O��)���ťD�ޥN��
     ) with no log;   
     
     
    /* ���Y */
    strcpy(ftitle, "���O�W��,�O�I�Ҹ�,(�O�o)�Q�O�I�H,(�O�o)������/�νs,");
    strcat(ftitle, "(�O�o)����,(�O�o)�ˮֵ���,(�O�o)�ˮ֩ʧO,(�O�o)�ˮ֥ͤ�,");
    strcat(ftitle, "(�O�o)�ˮ֨���,(�O�o)�ˮ֭����ƶq,(�O�o)�ˮ֭������,");
    strcat(ftitle, "(�O�o)�ˮְs�r����,(�O�o)�ˮ��`�O�O,(�̷s�O��)�O�渹,");
    strcat(ftitle, "(�̷s�O��)�Q�O�I�H,(�̷s�O��)�����Ҹ�/�νs,(�̷s�O��)����,");
    strcat(ftitle, "(�̷s�O��)����,(�̷s�O��)�ʧO,(�̷s�O��)�ͤ�,(�̷s�O��)����,");
    strcat(ftitle, "(�̷s�O��)�����ƶq,(�̷s�O��)�������,(�̷s�O��)�s�r����,(�̷s�O��)�`�O�O,");
    strcat(ftitle, "(�̷s�O��)ñ���,(�̷s�O��)�g��N��,(�̷s�O��)�޲z�H����W��,");
    strcat(ftitle, "(�̷s�O��)�~�Z��W��,��Ƥ��ŭ�]_�s�w,���B�z���G\n");

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/

long car6416_ply_data()
{
    $char   stmt1[5000];
    

    $whenever sqlerror goto errexit;

    /* ��X�������A=0���Ҧ���� */
    for (i=0; i<count_db; i++)
    {
        sprintf(stmt1,
            "insert into ca6416_a1 \
             select a.itype||trim(a.ntype), a.icard, a.nassured, ''||a.iassured, \
                    ''||a.itag, a.ilevel2, decode(a.fsex2,'1','�k','2','�k',' '), \
                    a.dbirth2, ''||a.icar_type2, a.qpt2, a.fpt2, a.qdrunk2, \
                    a.mprem2, a.ipolicy, c.nassured[1,40], ''||c.iassured, \
                    ''||c.itag, b.fcomp_class, decode(c.fsex,'1','�k','2','�k',' '), \
                    c.dbirth, ''||b.icar_type, c.qpt, c.fpt, b.qdrunk_driving, \
                    (select mins_premium from %s:ply_ins_type d  \
                      where d.ipolicy = a.ipolicy and d.iins_type = '21'), \
                    b.dpolicy, ''||b.iofficer, (select nname from officer f \
                    where f.iofficer = e.ileader), \
                    (select nbranch from sa_branch_type where ibranch = b.iquota), \
                    a.nreason1, ' ', b.iquota,  e.ileader, \
                    (select resp_name from sa_branch_type g, personal:unitid2ef h \
                      where g.ibranch = h.code_no and g.dexpire is null \
                        and g.ibranch not in ('110100','110200') \
                        and g.ibranch[1,4] = (select iquota[1,4] from officer f \
                        where iofficer = e.ileader) and g.fprop = '2') \
               from ca_trade_prem_diff a, %s:ply_relation b, %s:policy c, officer e \
              where a.ipolicy = b.ipolicy and a.ipolicy = c.ipolicy \
                and b.iofficer = e.iofficer \
                and a.dtrans_month between '%s' and '%s' \
                and a.fstatus = '0' and a.iaccept in ('1','3') ", 
                list[i].dbname, list[i].dbname, list[i].dbname, dtrans_bgn, dtrans_end);
                
        printf("259:[%d]stmt1=[%s]\n",strlen(stmt1),stmt1);

	    $PREPARE pre_ply FROM $stmt1;
        $EXECUTE pre_ply;
    }

    return M_CM_OK;

errexit:
    printf("---- errexit:254 ----- \n");
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* -------------------------------------------------------------------------------- */
long car6416_send_email()
{
	long	rc;
	$char   ileader[12],yy[4],mm[3],dd[3];
	
	$char   ntype[31], icard[21], nassured[21], iassured[16], itag[16], ilevel2[4],
            fsex2[3], dbirth2[11], icar_type2[4], fpt2[2], ipolicy[21], 
            nassured_ply[41], iassured_ply[16], itag_ply[16], fcomp_class[4], 
            fsex_ply[3], dbirth_ply[11], icar_type_ply[4], fpt_ply[2], dpolicy[11], 
            iofficer[12], nleader[11], nquota[41], nreason1[241], nfstatus[3],
            iquota[11], ileader3[12], ileader2[12];
	
	$int qpt2, qdrunk2, mprem2, qpt_ply, qdrunk_driving, premium_ply;

	$whenever sqlerror goto errexit;
	printf("--- car6416_send_email --- \n");
    
    mail_acept = 0;
    cm_char_split_3ymd(ddate1,yy,mm,dd);
    sprintf(ddate2,"%s%s%s",yy,mm,dd);
    
    /* mail���޲z�H */
    mail_acept = 1;
	sprintf(stmt, "select a.* from ca6416_a1 a where a.ileader = ? order by a.ipolicy;");
    printf("stmt[%s]\n",stmt);
    $prepare pre_a1 from $stmt;
    $declare cur_a1 cursor for pre_a1;
    
    strcpy(pre_ileader," ");
    strcpy(ileader," ");
    
    $declare cur_L1 cursor for
      select distinct ileader into $ileader  
        from ca6416_a1
       order by ileader;
    $open cur_L1;
    $fetch cur_L1;

    strcpy(pre_ileader,ileader);
    mail_count = 0; sum_mail= 0;
    while(1)
    {
	    if (SQLCODE==SQLNOTFOUND) break;
		
		if (strcmp(ileader,pre_ileader)!=0)
		{
	        rc = car6416_write_email();
	    	if (rc!=M_CM_OK) {
					printf("error on car6416_write_email\n");
					return rc;
	    	}
	    	mail_count=0;
	    	sum_mail++;
		}

		strcpy(pre_ileader,ileader);
        mail_count++;

		memset(fname,0x00,sizeof(fname));
		memset(filename,0x00,sizeof(filename));

		sprintf(fname,"%s_�j���I�t���ƫO�O���ũ���_%s",ddate2,trim(ileader));
		sprintf(filename,"%s/rptftp/car_email/%s.csv",sApHome,fname);
		
		fp=fopen(filename,"w");

		fprintf(fp,ftitle);
		$open cur_a1 using $ileader;

		while(1)
		{
		    $fetch cur_a1
		      into $ntype, $icard, $nassured, $iassured, $itag, 
		           $ilevel2, $fsex2, $dbirth2, $icar_type2, $qpt2, 
		           $fpt2, $qdrunk2, $mprem2, $ipolicy, $nassured_ply, 
		           $iassured_ply, $itag_ply, $fcomp_class, $fsex_ply, $dbirth_ply,
		           $icar_type_ply, $qpt_ply, $fpt_ply, $qdrunk_driving, $premium_ply,
		           $dpolicy, $iofficer, $nleader, $nquota, $nreason1,
                   $nfstatus, $iquota, $ileader, $ileader3;
		    if (SQLCODE==SQLNOTFOUND) break;
            
            strcpy(ntype, trim(ntype));
            strcpy(nassured, trim(nassured));
            strcpy(nassured_ply, trim(nassured_ply));
            strcpy(nreason1, trim(nreason1));
            
		    fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%s,%d,%d,%s,%s,%s,%s,%s,%s,%s,%s,%d,%s,%d,%d,%s,%s,%s,%s,%s,%s\n",
		            ntype, icard, nassured, iassured, itag, 
		            ilevel2,  fsex2,  dbirth2,  icar_type2, qpt2, 
		            fpt2, qdrunk2, mprem2, ipolicy, nassured_ply, 
		            iassured_ply, itag_ply, fcomp_class, fsex_ply, dbirth_ply,
		            icar_type_ply,  qpt_ply,  fpt_ply,  qdrunk_driving, premium_ply,
		            dpolicy, iofficer, nleader, nquota, nreason1, nfstatus);
        }
        $close cur_a1;
		fclose(fp);
		$fetch cur_L1;
    }
    $free  cur_a1;
    $close cur_L1;
    $free  cur_L1;

    if (mail_count!=0)
    {
        rc = car6416_write_email();
        if (rc!=M_CM_OK) {
		    printf("error on car6416_write_email\n");
			return rc;
		}
        sum_mail++;
    }
    
    
    /* mail���֫O�H�� */
    mail_acept = 2;
	sprintf(stmt,
	    "select a.* from ca6416_a1 a \
	      where a.ipolicy[1,3] in \
	            (select unique detail from car_code \
	              where kind = 'T4' and detail = a.ipolicy[1,3] and detail2 = ?)  \
	      order by a.ipolicy;");

    printf("stmt[%s]\n",stmt);
    $prepare pre_a2 from $stmt;
    $declare cur_a2 cursor for pre_a2;

    
    strcpy(pre_ileader," ");
    strcpy(ileader," ");
    
    $declare cur_L2 cursor for
      select distinct a.detail2 into $ileader
        from car_code a
       where a.kind = 'T4'
         and a.detail in (select distinct ipolicy[1,3] from ca6416_a1 where 1=1)
       order by a.detail2;
    $open cur_L2;
    $fetch cur_L2;

    strcpy(pre_ileader,ileader);
    mail_count= 0;
    while(1)
    {
	    if (SQLCODE==SQLNOTFOUND) break;

		if (strcmp(ileader,pre_ileader)!=0)
		{
	        rc = car6416_write_email();
	    	if (rc!=M_CM_OK) {
					printf("error on car6416_write_email\n");
					return rc;
	    	}
	    	mail_count=0;
	    	sum_mail++;
		}

		strcpy(pre_ileader,ileader);
        mail_count++;

		memset(fname,0x00,sizeof(fname));
		memset(filename,0x00,sizeof(filename));

		sprintf(fname,"%s_�j���I�t���ƫO�O���ũ���C_%s",ddate2,trim(ileader));
		sprintf(filename,"%s/rptftp/car_email/%s.csv",sApHome,fname);

		fp=fopen(filename,"w");

		fprintf(fp,ftitle);
		$open cur_a2 using $ileader;

		while(1)
		{
		    $fetch cur_a2
		      into $ntype, $icard, $nassured, $iassured, $itag, 
		           $ilevel2, $fsex2, $dbirth2, $icar_type2, $qpt2, 
		           $fpt2, $qdrunk2, $mprem2, $ipolicy, $nassured_ply, 
		           $iassured_ply, $itag_ply, $fcomp_class, $fsex_ply, $dbirth_ply,
		           $icar_type_ply, $qpt_ply, $fpt_ply, $qdrunk_driving, $premium_ply,
		           $dpolicy, $iofficer, $nleader, $nquota, $nreason1,
                   $nfstatus, $iquota, $ileader, $ileader3;
		    if (SQLCODE==SQLNOTFOUND) break;
		    
		    strcpy(ntype, trim(ntype));
            strcpy(nassured, trim(nassured));
            strcpy(nassured_ply, trim(nassured_ply));
            strcpy(nreason1, trim(nreason1));
            
		    fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%s,%d,%d,%s,%s,%s,%s,%s,%s,%s,%s,%d,%s,%d,%d,%s,%s,%s,%s,%s,%s\n",
		            ntype, icard, nassured, iassured, itag, 
		            ilevel2,  fsex2,  dbirth2,  icar_type2, qpt2, 
		            fpt2, qdrunk2, mprem2, ipolicy, nassured_ply, 
		            iassured_ply, itag_ply, fcomp_class, fsex_ply, dbirth_ply,
		            icar_type_ply,  qpt_ply,  fpt_ply,  qdrunk_driving, premium_ply,
		            dpolicy, iofficer, nleader, nquota, nreason1, nfstatus);
        }

        $close cur_a2;
		fclose(fp);
		$fetch cur_L2;
    }
    $free  cur_a2;
    $close cur_L2;
    $free  cur_L2;

    if (mail_count!=0)
    {
        rc = car6416_write_email();
        if (rc!=M_CM_OK) {
		    printf("error on car6416_write_email\n");
			return rc;
		}
        sum_mail++;
    }
    
    /* mail�����ťD�� */
    mail_acept = 3;
	sprintf(stmt, "select a.* from ca6416_a1 a where a.ileader3 = ? order by a.ipolicy;");

    printf("stmt[%s]\n",stmt);
    $prepare pre_a3 from $stmt;
    $declare cur_a3 cursor for pre_a3;

    strcpy(pre_ileader," ");
    strcpy(ileader," ");
    $declare cur_L3 cursor for
      select distinct ileader3 into $ileader  
        from ca6416_a1
       order by ileader3;
    $open cur_L3;
    $fetch cur_L3;

    strcpy(pre_ileader,ileader);
    mail_count = 0;
    while(1)
    {
	    if (SQLCODE==SQLNOTFOUND) break;

		if (strcmp(ileader,pre_ileader)!=0)
		{
	        rc = car6416_write_email();
	    	if (rc!=M_CM_OK) {
					printf("error on car6416_write_email\n");
					return rc;
	    	}
	    	mail_count=0;
	    	sum_mail++;
		}

		strcpy(pre_ileader,ileader);
        mail_count++;

		memset(fname,0x00,sizeof(fname));
		memset(filename,0x00,sizeof(filename));

		sprintf(fname,"%s_�j���I�t���ƫO�O���ũ���M_%s",ddate2,trim(ileader));
		sprintf(filename,"%s/rptftp/car_email/%s.csv",sApHome,fname);

		fp=fopen(filename,"w");

		fprintf(fp,ftitle);
		$open cur_a3 using $ileader;

		while(1)
		{
		    $fetch cur_a3
		      into $ntype, $icard, $nassured, $iassured, $itag, 
		           $ilevel2, $fsex2, $dbirth2, $icar_type2, $qpt2, 
		           $fpt2, $qdrunk2, $mprem2, $ipolicy, $nassured_ply, 
		           $iassured_ply, $itag_ply, $fcomp_class, $fsex_ply, $dbirth_ply,
		           $icar_type_ply, $qpt_ply, $fpt_ply, $qdrunk_driving, $premium_ply,
		           $dpolicy, $iofficer, $nleader, $nquota, $nreason1,
                   $nfstatus, $iquota, $ileader, $ileader3;
		    if (SQLCODE==SQLNOTFOUND) break;


		    strcpy(ntype, trim(ntype));
            strcpy(nassured, trim(nassured));
            strcpy(nassured_ply, trim(nassured_ply));
            strcpy(nreason1, trim(nreason1));
            
		    fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%s,%d,%d,%s,%s,%s,%s,%s,%s,%s,%s,%d,%s,%d,%d,%s,%s,%s,%s,%s,%s\n",
		            ntype, icard, nassured, iassured, itag, 
		            ilevel2,  fsex2,  dbirth2,  icar_type2, qpt2, 
		            fpt2, qdrunk2, mprem2, ipolicy, nassured_ply, 
		            iassured_ply, itag_ply, fcomp_class, fsex_ply, dbirth_ply,
		            icar_type_ply,  qpt_ply,  fpt_ply,  qdrunk_driving, premium_ply,
		            dpolicy, iofficer, nleader, nquota, nreason1, nfstatus);
        }

        $close cur_a3;
		fclose(fp);
		$fetch cur_L3;
    }
    $free  cur_a3;
    $close cur_L3;
    $free  cur_L3;

    if (mail_count!=0)
    {
        rc = car6416_write_email();
        if (rc!=M_CM_OK) {
		    printf("error on car6416_write_email\n");
			return rc;
		}
        sum_mail++;
    }

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/* ------------------------------------------------------------------------- */
long car6416_write_email()
{
    $whenever sqlerror goto errexit;
    $char sIleader[11];

    printf("--- car6416_write_email --- \n");
    $select email,chinese_name
       into $email,$chinese_name
       from personal:asempl
      where empl_no = $pre_ileader;

    strcpy(email,trim(email));
    strcat(email,"@tmnewa.com.tw");
    printf("email[%s]\n",email);

    /* ���קK���Ƶo�e */
    $delete from batchemail
      where project_id = $Porj_id
        and mail_date = $send_date
        and receiver_email = $email
        and key = $fname;
            

    if ((mail_acept == 1) || (mail_acept == 2))
    {
        /* mail���e_�O��޲z�H�ή֫O�H�� */
        sprintf(sContent ,
        "<html> \n" 
        "   <head> \n "
        "     <meta http-equiv=\"content-type\" content=\"text/html; charset=Big5\" > \n"
        "   </head>\n"
        "   <body>\n"
        "       <div style=\" width: 750px; text-align: left;\">\n"
        "           &nbsp;&nbsp;&nbsp;�˷R�� %s �z�n�G <br> \n"
        "           &nbsp;&nbsp;&nbsp;�q���z�A���󤤬��j��O�I���Ÿ�ƭץ����ӡC<br> \n"
        "           &nbsp;&nbsp;&nbsp;�Ш�U�d���ð���奿�@�~�C<br> \n"
        "           &nbsp;&nbsp;&nbsp;�p������ݽЬ��ӤH�O�I���~�Ȧ�F��C<br> \n" 
        "           &nbsp;&nbsp;&nbsp;���¡I<br><br><br> \n"
        "           &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�ӫO���~�Ȧ�F��&nbsp;&nbsp;�q��<br><br><br> \n"
        "       </div>\n"
        "   </body></html>	\n",chinese_name);
       
    }
    else if (mail_acept == 3)
    {
        /* mail���e_���ťD�� */
        sprintf(sContent ,
        "<html> \n" 
        "   <head> \n "
        "     <meta http-equiv=\"content-type\" content=\"text/html; charset=Big5\" > \n"
        "   </head>\n"
        "   <body>\n"
        "       <div style=\" width: 1000px; text-align: left;\">\n"
        "           &nbsp;&nbsp;&nbsp;�˷R�� %s �D�� �z�n�G <br> \n"
        "           &nbsp;&nbsp;&nbsp;�q���z�A���󤤬��@�Q���j��O�I���Ÿ�ƭץ����ӡA�ѰѾ\\�C  <br> \n"
        "           &nbsp;&nbsp;&nbsp;�w�P�ɳq�����ݺ޲z�H�ή֫O���f�C<br> \n"
        "           &nbsp;&nbsp;&nbsp;�p��������D�Ь��ӤH�O�I���~�Ȧ�F��C<br> \n" 
        "           &nbsp;&nbsp;&nbsp;���¡I<br><br> \n"
        "           &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�ӫO���~�Ȧ�F��&nbsp;&nbsp;�q��<br><br><br> \n"
        "       </div>\n"
        "   </body></html>	\n",chinese_name);
    }

    ctxt.loc_loctype = LOCMEMORY;
    ctxt.loc_buffer = sContent;
    ctxt.loc_bufsize = 9000;
    ctxt.loc_size =  strlen(sContent) + 1;
        
    $INSERT INTO batchemail
        (project_id, mail_date, receiver_email, receiver_name, cc,
    	 content, key, mail_count, nsubject)
     VALUES
        ($Porj_id, $send_date, $email, $chinese_name, " ",
    	 $ctxt, $fname, $mail_count, $nproject);
    		 
    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car6416_final_email()
{
    $char mmsg[1000];
    $int icount;

    $whenever sqlerror goto errexit;

    $select email,chinese_name
       into $email,$chinese_name
       from personal:asempl
      where empl_no = $userid;

    strcpy(email,trim(email));
    strcat(email,"@tmnewa.com.tw");
    printf("email[%s]\n",email);

    sprintf(mmsg,"�j���I�t���ƫO�O���ũ��Ӥw�妸email�q���޲z�H�B�֫O�H���γ��ťD��!!</P>\n");

    ctxt.loc_loctype = LOCMEMORY;
    ctxt.loc_buffer = mmsg;
    ctxt.loc_bufsize = 9000;
    ctxt.loc_size =  strlen(mmsg) + 1;

    /* ���R��batchemail�즳��mail,�A�s�W�@���s�� */
    $delete from batchemail
      where project_id = $Porj_id
        and mail_date = $send_date
        and receiver_email = $email
        and receiver_name = $chinese_name
        and nsubject = $nproject
        and mail_count = 0;

    $INSERT INTO batchemail
		(project_id, mail_date, receiver_email,	receiver_name, cc,
		 content, key, mail_count, nsubject)
     VALUES
		($Porj_id, $send_date, $email, $chinese_name, " ",
		 $ctxt, " ", 0, $nproject);


    $select count(*) into $icount from ca6416_a1 where 1=1 ;

    printf("�@ %d ��\n",icount);

    sprintf(mmsg,"\n\n  �j���I�t���ƫO�O���ũ���,\n\n"
                 "    ��Ʋ��s���� �@�e%d�f���A,�w�p�� %s �妸�o�email�q���޲z�H�B�֫O�H���γ��ťD��!!\n"
                 "    �o�e�����Ӹ�ơe�j���I�t���ƫO�O���ũ���.csv�f�i��cmn202�U��!!", icount, send_date);

    EWRITE(userid,M_CM_OK,mmsg);
    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car6416_print()
{
    $char   ntype[31], icard[21], nassured[21], iassured[16], itag[16], ilevel2[4],
            fsex2[3], dbirth2[11], icar_type2[4], fpt2[2], ipolicy[21], 
            nassured_ply[41], iassured_ply[16], itag_ply[16], fcomp_class[4], 
            fsex_ply[3], dbirth_ply[11], icar_type_ply[4], fpt_ply[2], dpolicy[11], 
            iofficer[12], nleader[11], nquota[41], nreason1[241], nfstatus[3],
            iquota[11], ileader[12], ileader3[12], ileader2[12], sMsg[200];
	
	$int qpt2, qdrunk2, mprem2, qpt_ply, qdrunk_driving, premium_ply;

    
    $WHENEVER SQLERROR GOTO errexit;

    sprintf(stmt, "select a.* from ca6416_a1 a order by iquota, ileader, iofficer, ipolicy;");
    
    printf("stmt[%s]\n",stmt);
    $prepare pre_dtl from $stmt;
    $declare cur_dtl cursor for pre_dtl;

    sprintf(fname,"%s_�j���I�t���ƫO�O���ũ���.csv",ddate2);
    sprintf(filename,"%s/rptftp/%s",sApHome,fname);

    fp=fopen(filename,"w");
    fprintf(fp,ftitle);
    $open cur_dtl;
    while(1)
    {
	    $fetch cur_dtl
		  into $ntype, $icard, $nassured, $iassured, $itag, 
		       $ilevel2, $fsex2, $dbirth2, $icar_type2, $qpt2, 
		       $fpt2, $qdrunk2, $mprem2, $ipolicy, $nassured_ply, 
		       $iassured_ply, $itag_ply, $fcomp_class, $fsex_ply, $dbirth_ply,
		       $icar_type_ply, $qpt_ply, $fpt_ply, $qdrunk_driving, $premium_ply,
		       $dpolicy, $iofficer, $nleader, $nquota, $nreason1,
               $nfstatus, $iquota, $ileader, $ileader3;
        if (SQLCODE==SQLNOTFOUND) break;

        strcpy(ntype, trim(ntype));
        strcpy(nassured, trim(nassured));
        strcpy(nassured_ply, trim(nassured_ply));
        strcpy(nreason1, trim(nreason1));
            
		fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%s,%d,%d,%s,%s,%s,%s,%s,%s,%s,%s,%d,%s,%d,%d,%s,%s,%s,%s,%s,%s\n",
		            ntype, icard, nassured, iassured, itag, 
		            ilevel2,  fsex2,  dbirth2,  icar_type2, qpt2, 
		            fpt2, qdrunk2, mprem2, ipolicy, nassured_ply, 
		            iassured_ply, itag_ply, fcomp_class, fsex_ply, dbirth_ply,
		            icar_type_ply,  qpt_ply,  fpt_ply,  qdrunk_driving, premium_ply,
		            dpolicy, iofficer, nleader, nquota, nreason1, nfstatus);
    }

    $close cur_dtl;
	fclose(fp);


    rc=rptftpinsert(userid,"car6416", fname );
    printf("rptftpinsert rc[%d]\n", rc);
    if (rc!=0)
    {
        sprintf( sMsg,"�g�Jrptftplist���~\r\n");
        return rc;
    }

    return M_CM_OK;
errexit:
    sqlfatal();
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}