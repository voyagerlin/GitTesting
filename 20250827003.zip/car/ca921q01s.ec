/*******************************************/
/*                                         */
/*   �z�ߨ��z��ƤΩ��Ӫ�                  */
/*                                         */
/*   PROGRAM : ca912q01s.ec                */
/*                                         */
/*   DATE    : 92.01.14                    */
/*******************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "safeclib.h"

DBinfo  *list;
int  count_db = 0;
int  i = 0;
extern char RPTDIR[];

char  MsgCode[50];
char  msgbuf[100];

$char tmp_fulldb[200], stmt[4000],stmt1[4000];
$char DBName[05], iForm_Tp[03];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1];
char  outputf[N_FILE+1];

$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;
$char sMonth[3];
$char sMonth1[3],sMonth2[3];
$char aaa[100];
 int fetch=0;
 
$char iadjust[11] = "";
$char nname[11],en_nname[11];
$char ibranch[3], nchi_abv[13],pre_ibranch[3];
char tmp_iadjuster[11];
int  cnt_iadjuster;
int  tot_iadjuster;
char yy[4], mm[3], dd[3];
char yy1[4], mm1[3], dd1[3];
char yy2[4], mm2[3], dd2[3];
$char client_str[10];

static int pagenum=1;
static int linecnt=0;

$char yymmbgn[17],yymmend[17], sTmpIbranch[3];
$char c_yymmbgn[17],c_yymmend[17];
$char dptbgn[3], dptend[3];
char userid[11];
char FormTp[N_FILE+1];
$int  iCnt, iCnt1, iCnt2, iTot, iTot1, iTot2;


int  max_count, errCode;
int  tmp_len;
int  copies;
int miy;

$int temp_count;
int  max_cnt;
$char iins_type[INSURANCE_TYPE],iemail[30],assign[2],fcard_class[2],iclaim[20];
$int int_email,int_add,int_assign,int_2_assign;
$int iemail_isnull = 0;
$int tot_iCnt1,tot_iCnt2,tot_iCnt,tot_int_email,tot_int_add,tot_int_assign;
$char Full_DBName[50];
$char option1[2],option3[2];
$char dclaim[17],ipolicy[20],iclm_entry[10],nassured[41],recipient[41];
$char buf1[100];
$char c_iadjuster[10];
$int icnt_fkind;

long car921_get_db();
long car921_build1();
long car921_build2();
long car921_body1();
long car921_body2();
long car921_accumulate();
void car921_title();  
long car921_ntot();
static char *get_car_full_db();  /*   �ǤJ�O�渹��X���O�檺�k�ݸ�Ʈw */

/*--------------------------------------------------------------------*/
main(argc, argv)
int argc; 
char **argv;
{
   int rc;
   batchinit();

   strcpy(DBName,isNULLstr(argv[1]));
   strcpy(userid,isNULLstr(argv[2]));
   strcpy(option1,isNULLstr(argv[3]));
   strcpy(client_str,isNULLstr(argv[4]));
   strcpy(option3,isNULLstr(argv[5]));
   strcpy(c_yymmbgn,isNULLstr(argv[6]));
   strcpy(c_yymmend,isNULLstr(argv[7]));
   strcpy(outputf,isNULLstr(argv[8]));

   if(c_yymmbgn[0]=='*')strcpy(c_yymmbgn,"80/01/01");
   if(c_yymmend[0]=='*')strcpy(c_yymmend,"99/12/31");
   if(c_yymmend[0]==' ')strcpy(c_yymmend,c_yymmbgn);
   printf("outputf[%s]\n",outputf);
   printf("yymmbgn[%s]\n",c_yymmbgn);
   printf("yymmend[%s]\n",c_yymmend);

   strcpy(yymmbgn, cm_to_infdate(c_yymmbgn));
   strcpy(yymmend, cm_to_infdate(c_yymmend));

      rc = car921_get_db();
       if (rc != SUCCESS)
          return rc;


      rc = car921_accumulate();
      
      if ( rc != M_CM_OK)  {
        EWRITE(userid, rc, " ");
        return rc;
   }

   if(strcmp(option3,"S")==0)
   {
   max_cnt=0;
   strcpy(MsgCode," ");
   rc = car921_build1();
   if (rc != M_CM_OK)
   {   
       if (MsgCode[0]==' ')
           EWRITE(userid, rc, " ");
       else
           EWRITE(userid, rc, MsgCode);
       return rc;
   }
   }

   if(strcmp(option3,"D")==0)
   {
   max_cnt=0;
   strcpy(MsgCode," ");
   rc = car921_build2();
   if (rc != M_CM_OK)
   {
       if (MsgCode[0]==' ')
           EWRITE(userid, rc, " ");
       else
           EWRITE(userid, rc, MsgCode);
       return rc;
   }
   }

}
/*--------------------------------------------------------------------*/

long car921_build1()
{
  $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];

   int    rc;

   $WHENEVER SQLERROR GOTO errexit;
 
   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt,  $StartRow,  $TitleRow,  $ItemRow,
           $TotColumn, $PgLine, $Width, $iForm_Tp
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 921 AND iform_tp = '1';
 
   printf(" TitleFmt[%s]\n",TitleFmt);
   printf(" BodyFmt[%s]\n",BodyFmt);
   strcpy(TitleFmt,rtrim(TitleFmt));
   sprintf_s(TitleFile, N_FILE+1,"%s.ti",outputf);
   strcpy(BodyFmt, rtrim(BodyFmt));
   sprintf_s(BodyFile, N_FILE+1, "%s.bd",outputf);
   

   rgu_init_report(TitleFmt,TitleFile);

   car921_title();

   rgu_finish_report();


   rgu_init_report(BodyFmt,BodyFile);
   rc = car921_body1();
   if (rc != M_CM_OK)
       return rc;
   rgu_finish_report();


   if ((rc=save_form_info(F_BLK0, "CA", 921, userid, iForm_Tp, max_cnt, outputf))<0) {
        strcpy(MsgCode,"save_form_info failed");
        return rc;
   }


   return M_CM_OK;
   

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}
/******************************************************************************************/

long car921_build2()
{
  $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];

   int    rc;

   $WHENEVER SQLERROR GOTO errexit;

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt,  $StartRow,  $TitleRow,  $ItemRow,
           $TotColumn, $PgLine, $Width, $iForm_Tp
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 921 AND iform_tp = '2';

   printf(" TitleFmt[%s]\n",TitleFmt);
   printf(" BodyFmt[%s]\n",BodyFmt);
   strcpy(TitleFmt,rtrim(TitleFmt));
   sprintf_s(TitleFile, N_FILE+1,"%s.ti",outputf);
   strcpy(BodyFmt, rtrim(BodyFmt));
   sprintf_s(BodyFile, N_FILE+1, "%s.bd",outputf);


   rgu_init_report(TitleFmt,TitleFile);

   car921_title();

   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);

   rc = car921_body2();
   if (rc != M_CM_OK)
       return rc;

   rgu_finish_report();

   if ((rc=save_form_info(F_BLK0, "CA", 921, userid, iForm_Tp, max_cnt, outputf))<0) {
        strcpy(MsgCode,"save_form_info failed");
        return rc;
   }


   return M_CM_OK;


errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}
/******************************************************************************************/

long car921_accumulate()
{
 $char iins_type[INSURANCE_TYPE];
 $long mply_prem, qcount;
 
 $char stmt_buf[4000];
 $int  id1,id2,id3,id4;
 int count;
 int Y;

   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False) {
       return M_CM_DB_NOTOPEN;
   }
    
       $CREATE TEMP TABLE CAR921
        (
          ibranch             char(3) not null,
          iadjuster           char(10) not null,
          iclaim              char(20) not null,
          iCnt1               integer default 0,
          iCnt2               integer default 0,
          int_email           integer default 0,
          int_add             integer default 0,
          int_assign          integer default 0,
          int_2_assign        integer default 0
        );


        $CREATE TEMP TABLE CAR9211
        (
          ibranch             char(3)  not null,
          dclaim              char(17) not null,
          iclaim              char(20) not null,
          ipolicy             char(20) not null,
          iadjuster           char(10) not null,
          iclm_entry          char(10),
          assign              char(2),
          nassured            char(11),
          recipient           char(11),
          iemail              char(50)
        );


   /**********************************/

    if(strcmp(option1,"1")==0)
    { sprintf_s(buf1,100,"AND b.ibranch matches '%s'",client_str); }
    else
    { sprintf_s(buf1,100,"AND a.iadjuster = '%s'",client_str); }

  printf(" it will to run before three database \n");
  for (i=0;i<count_db;i++)
  {
   
    sprintf_s(stmt_buf,4000,"select b.ibranch,a.ipolicy,a.iclaim,a.iadjuster   \
                        from %s:ca_local_clm a,v_branch b               \
                       where a.dclaim BETWEEN ? AND ?  %s               \
                         and a.iclaim[1,2]=b.ibranch                    \
                       order by 3,4                                     \
                            ",list[i].dbname,buf1);
    printf("stmt[%s]\n",stmt_buf);
    EXEC SQL PREPARE Acursor  FROM :stmt_buf;
    EXEC SQL DECLARE AcursorC CURSOR FOR Acursor;
    EXEC SQL OPEN AcursorC USING :yymmbgn,:yymmend;
    while (1)
    {
        printf(" fetch ca_local_clm \n");
        EXEC SQL FETCH AcursorC INTO :ibranch,:ipolicy,:iclaim,:iadjust;

        if (SQLCODE == SQLNOTFOUND)  break;
  
        printf(" 00000000000000000000000000000000ibranch[%s]\n",ibranch);

        strcpy(Full_DBName, get_car_full_db(ipolicy));
        printf(" Full_DBname[%s]\n",Full_DBName);
        printf(" ************************ \n");

        sprintf_s(stmt_buf,4000,"select a.fcard_class,a.dclaim,a.iclm_entry,                  \
                                 b.nassured[1,10],b.recipient[1,10],b.iemail,c.assign,c.adjustment  \
                            from %s:appraisal a,%s:adjustment_ply b,ca_clm_process c   \
                           where a.iclaim = '%s'     \
                             and a.iclaim = b.iclaim \
                             and b.iclaim = c.iclaim ",Full_DBName,Full_DBName,iclaim);
        printf("stmt_buf[%s]\n",stmt_buf);
        $prepare pre3 from $stmt_buf;
        $execute pre3 into $fcard_class,$dclaim,$iclm_entry,$nassured,$recipient,
                           $iemail,$assign,$iadjust;


        /*  insert int detail content */
        if(strcmp(trim(option3),"D")==0)
        {
        printf(" detail detail detail \n");
        printf("nassured[%s]\n",nassured);
        printf("recipient[%s]\n",recipient);
        printf("iemail[%s]\n",iemail);
        printf("000000000000000000000000000000 ibranch[%s]\n",ibranch);
        $INSERT INTO CAR9211
                (ibranch,dclaim,iclaim,ipolicy,iadjuster,iclm_entry,nassured,recipient,assign,iemail)
          VALUES($ibranch,$dclaim,$iclaim,$ipolicy,$iadjust,$iclm_entry,$nassured,$recipient,$assign,$iemail);
        }
        else
        {
        printf(" statictics staticitics staticitics \n");
        iCnt1=iCnt2=int_email=int_add=int_assign=int_2_assign=0;

        if(strcmp(fcard_class,"1")==0)
        {
            printf(" HERE IS fcard_class = 1 \n");
            iCnt1 = 1;
            $INSERT INTO CAR921
                    (ibranch,iadjuster,iclaim,iCnt1,iCnt2,int_email,int_add,int_assign,int_2_assign)
              VALUES($ibranch,$iadjust,$iclaim,$iCnt1,0,0,0,0,0);
            continue;
         }
         else
         {
            printf(" HERE IS fcard_class = 2\n");
            printf(" iclaim[%s]\n",iclaim);

            iCnt2 = 1;

            sprintf_s(stmt,4000,
	    " select a.assign, b.iemail                       \
               from ca_clm_process a, %s:adjustment_ply b     \
              where a.iclaim = '%s'                           \
                and a.iclaim = b.iclaim ", Full_DBName, iclaim);

             printf("stmt[%s]\n",stmt);
	    $PREPARE get_mail_id FROM $stmt;
	    $EXECUTE get_mail_id 
                INTO $assign,$iemail:iemail_isnull;

             printf(" iemal[%s]\n",iemail);
             printf(" iemail_isnull[%d]\n",iemail_isnull);
             if(iemail[0]!=' ')
             {   
                int_email = 1;   
	     }

             /* �s�[���N�I�����w���z���  */
             if(strcmp(assign,"Y")==0)
             {
                  int_2_assign = 1;
             }

             icnt_fkind = 0;
             sprintf_s(stmt,4000,
	      " select  max(case when               \
                                   (select count(*)         \
                                      from insurance_type   \
                                     where iins_type =  x.iins_type      \
                                       and fins_grp  =  '2'              \
                                       and fkind     <> '3') > 0 then 4  \
                                   when                     \
                                   (select count(*)         \
                                      from insurance_type   \
                                     where iins_type =  x.iins_type      \
                                       and fkind     = '3')  > 0 then 3  \
                                   when                     \
                                  (select count(*)          \
                                     from insurance_type    \
                                    where iins_type =  x.iins_type       \
                                      and fkind     = '2')  > 0 then 2   \
                             else 1             \
                         end)	                \
	          from %s:app_ins_type x        \
		 where iclaim = '%s' ", Full_DBName, iclaim);

             printf("stmt[%s]\n",stmt);
             $prepare get_ins_fkind from $stmt;
	     $execute get_ins_fkind into $icnt_fkind;
		
	     printf("iclaim=[%s],icnt_fkind=[%d]\n", iclaim, icnt_fkind);
             if (icnt_fkind >= 3)
	     {
                int_add = 1;

		if (assign[0] == 'Y')
		{
                   int_assign = 1;
		}
	     }

             $INSERT INTO CAR921
                    (ibranch,iadjuster,iclaim,iCnt1,iCnt2,int_email,int_add,int_assign,int_2_assign)
              VALUES($ibranch,$iadjust,$iclaim,0,$iCnt2,$int_email,$int_add,$int_assign,$int_2_assign);
          } /* end fcard_class = '2' */
        }
       } /* while */
     }   /* end for  */

     $SELECT count(*)
        INTO $temp_count
        FROM CAR9211;

   return M_CM_OK;  
  
   errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
 }
 
/*----------------------------------------------------------------------------*/
void car921_title()
{    

     rgu_put_head_string(1, " ");   /* get_currdt */
     rgu_put_head_string(1, " ");
     rgu_put_head();
}
/*----------------------------------------------------------------------------*/
long car921_body1()
{
 char  tmp_buf[16];
 int   rc,flag_first;
 char yy[4], mm[3];


   rgu_put_body_string(1, c_yymmbgn);
   rgu_put_body_string(1, c_yymmend);
   rgu_put_body_string(1, cm_get_sysd());   /* get_currdt */
   rgu_put_body(1);
   max_cnt=max_cnt+4;

 tot_iCnt1=tot_iCnt2=tot_iCnt=tot_int_email=tot_int_add=tot_int_assign=0;

 
       $declare cursorS cursor for
         select ibranch,iadjuster,sum(iCnt1),sum(iCnt2),
                sum(int_email),sum(int_add),sum(int_assign),sum(int_2_assign)
           into $ibranch,$iadjust,$iCnt1,$iCnt2,$int_email,$int_add,$int_assign,$int_2_assign
           from CAR921
          group by ibranch,iadjuster
          order by ibranch,iadjuster;
       $open cursorS;
     for(;;)
     {
        $fetch cursorS;
        if (SQLCODE == SQLNOTFOUND) {
                break;}

           printf("00000000000000000000000 ibranch[%s]\n",ibranch);

           $SELECT nchi_full
              INTO $nchi_abv
              FROM v_branch
             WHERE ibranch = $ibranch;
        printf("00000000000000000000  nchi_abv[%s]\n",nchi_abv);
           rgu_put_body_string(2, nchi_abv,1);
           



          $SELECT nname
             INTO $nname
             FROM officer
            WHERE iofficer = $iadjust;
            if(SQLCODE == SQLNOTFOUND) strcpy(nname, "");

            rgu_put_body_string(2, iadjust,1);
            rgu_put_body_string(2, nname,2);
            rgu_put_body_string(2, itos(iCnt1), 2);
            rgu_put_body_string(2, itos(iCnt2), 2);
            iCnt = iCnt1 + iCnt2;
            rgu_put_body_string(2, itos(iCnt), 2);
            rgu_put_body_string(2, itos(int_email), 2);
            rgu_put_body_string(2, itos(int_add), 2);
            rgu_put_body_string(2, itos(int_assign), 2);
            rgu_put_body_string(2, itos(int_2_assign), 2);
            rgu_put_body(2); 
            max_cnt++;
     }


   return M_CM_OK;
   errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

long car921_body2()
{
 int   rc,flag_first;
 char pre_ibranch[3];
 int fetch;
 char yy[4], mm[3];

   max_cnt=0;
   rgu_put_body_string(1, c_yymmbgn);
   rgu_put_body_string(1, c_yymmend);
   rgu_put_body_string(1, cm_get_sysd());   /* get_currdt */
   rgu_put_body(1);
   max_cnt=max_cnt+4;

   rgu_put_body(3);
   max_cnt++;

       $declare cursor cursor for
         select ibranch,dclaim,iclaim,ipolicy,iadjuster,iclm_entry,
                nassured,recipient,assign,iemail
           into $ibranch,$dclaim,$iclaim,$ipolicy,$iadjust,$iclm_entry,
                $nassured,$recipient,$assign,$iemail
           from CAR9211
          order by ibranch,iclaim;
       $open cursor;
     for(;;)
     {
        $fetch cursor;
        if (SQLCODE == SQLNOTFOUND) {
                break;}

        $SELECT nchi_full
           INTO $nchi_abv
           FROM v_branch
          WHERE ibranch = $ibranch;
     printf("00000000000000000000000 ibranch[%s]\n",ibranch);          

        $SELECT nname
           INTO $en_nname
           FROM officer
          WHERE iofficer = $iclm_entry;
          if(SQLCODE == SQLNOTFOUND) strcpy(en_nname, "");



         $SELECT nname
            INTO $nname
            FROM officer
           WHERE iofficer = $iadjust;
        if(SQLCODE == SQLNOTFOUND) strcpy(nname, "");

           printf("nassured[%s]\n",nassured);
           printf("recipient[%s]\n",recipient);
           printf("iemail[%s]\n",iemail);

          strcpy(dclaim,substring(dclaim,1,10));

          rgu_put_body_string(2,trim(nchi_abv),1);
          rgu_put_body_string(2,trim(dclaim),1);
          rgu_put_body_string(2,trim(iclaim),1);
          rgu_put_body_string(2,trim(ipolicy),1);
          rgu_put_body_string(2,trim(nname),1);
          rgu_put_body_string(2,trim(en_nname),1);
          rgu_put_body_string(2,trim(assign),1);
          rgu_put_body_string(2,trim(nassured),1);
          rgu_put_body_string(2,trim(recipient),1);
          rgu_put_body_string(2,trim(iemail),1);
          rgu_put_body(2);
          max_cnt++;
     }




   return M_CM_OK;
   errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  static char sTmp_db_name[21];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
  }
  return sTmp_db_name;
}

long car921_get_db()
{
   if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   return SUCCESS;

errexit:

   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
