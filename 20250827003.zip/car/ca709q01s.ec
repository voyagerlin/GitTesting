/************************************************/
/*                                              */
/*   PROGRAM : ca709q01s.ec by Pei Chow Chen    */
/*                                              */
/*   DATE    : 1993/09/24                       */
/*                                              */
/*   1080902001-SC1-�Ʈ�q�X�W�p���I2��--> ���������ơA�ק���o��*/                                       
/************************************************/
#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"

#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"
/*------------------------------------*/

$char iadjuster[11],nname[11];
$char ibranch[3], nchi_abv[13];
$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width = 0;

char tmp_iadjuster[11];
int  cnt_iadjuster;
int  tot_iadjuster;

char SysTm[ N_TM+1];
char BodyFile[ N_FILE+1];
char TitleFile[ N_FILE+1];
char outputf[ N_FILE+1];
char yy[3], mm[3], dd[3];
char yy1[3], mm1[3], dd1[3];
char yy2[3], mm2[3], dd2[3];

static int pagenum=1;
static int linecnt=0;

int max_count = 0, errCode;
int tmp_len;
int copies;
int miy;

long car709_build();
void car709_title();
void car709_body();
void car709_grp();
void car709_tot();

#define LINEOFPAGE 5

/*----------------------------------------------------------------------------*/
$char DBName[5];
$char c_yymmbgn[17],c_yymmend[17];
$char dptbgn[5],dptend[2],eno[2],type[2], carflag[2];
char userid[11];
char FormTp[N_FILE+1];
$int  iCnt, iCnt1, iCnt2, iTot;
$char sIadjuster[11];
$long iTot1, iTot2;
$char iofficer[11],iestimate[21],icard2[21],icard1[21],ilast_ply[21];
$char nassured[121],iissue_ym[7],nbrand_abbr[13],ibrand[9],icar_type[3],iengine[CA_ENGINE_NUM],dply2_begin[11],dply2_end[11];
$char dpolicy[11],iassured[13],ibirth[11],fsex[2],fmarriage[2],siTot1[11],siTot2[11];
$char smpremium[11],sqcylinder[9],itag[CA_TAG_NUM],iabn_type[2],ibig_office[10],sibig_office[10],siofficer[11];
$char old_big_ply[13],sqpt[6], icar_flag[2], ibig_sales[11];
$char iofficer_est[11],ipolicy2[21],ipolicy1[21];
$long mpremium;
$double  qcylinder;/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/
$double qpt;
main(argc,argv)
int argc;
char **argv;
{
   char dummy[20],option;
   char prnTitleFile[N_FILE+1], prnBodyFile[N_FILE+1], prnDev[N_NAME+1];
   char tmpcmd[255],hostname[N_NAME+1];
   long rtncode;
   int  loc;
   int  i;

   int rc;
   batchinit();

   strcpy(DBName,isNULLstr(argv[1]));
   strcpy(userid,isNULLstr(argv[2]));

   strcpy(c_yymmbgn,isNULLstr(argv[3]));
   strcpy(c_yymmend,isNULLstr(argv[4]));
   strcpy(dptbgn,isNULLstr(argv[5]));
   strcpy(dptend,isNULLstr(argv[6]));
   strcpy(eno,isNULLstr(argv[7]));
   strcpy(type,isNULLstr(argv[8]));
   strcpy(carflag,isNULLstr(argv[9]));
   
   strcpy(outputf,isNULLstr(argv[10]));

printf("type[%s]\n",type);

   if(c_yymmbgn[0]=='*')strcpy(c_yymmbgn,"080/01/01");
   if(c_yymmend[0]=='*')strcpy(c_yymmend,"199/12/31");
   if(c_yymmend[0]==' ')strcpy(c_yymmend,c_yymmbgn);
printf("outputf[%s]\n",outputf);
printf("yymmbgn[%s]\n",c_yymmbgn);
printf("yymmend[%s]\n",c_yymmend);
   iTot = 0;
   car709_build();

      rtncode=create_sign_form("car709",BodyFile,Width);
      if (rtncode != 0)
        {
          EWRITE(userid,rtncode,"Error on creating sign form");
          printf("Error on creating sign form, rtncode=%d\n",rtncode);
          return;
        }

  if((rc=save_form_info(F_BLK1,"CA",709,userid,FormTp,max_count,outputf))<0)
    EWRITE(userid,rc,"save form info failure!");

}

/*----------------------------------------------------------------------------*/
long car709_build()
{
   $char TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];

   $char cc_yymmbgn[17],cc_yymmend[17];
   $char yymmbgn[17],yymmend[17], sTmpIbranch[3];
   $char stmt[1024],wherest1[100],wherest2[100],wherest3[100],wherest4[100],wherest5[100];
   char tmpend[17],tmpbgn[17];
   int   first=1;
   int   x,y;
   int   i_yy,i_mm;

   if(db_select(DBName) == False)
   {
    EWRITE(userid,M_CM_DB_NOTOPEN,"M_CM_NOTOPEN");
    return;
   } 


   $WHENEVER SQLERROR GOTO errexit;
   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
           kTot_Col, kPgNum_Line, kWidth
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow, $ItemRow,
           $TotColumn, $PgLine, $Width
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 709;

   strcpy( TitleFmt,rtrim(TitleFmt));
   strcpy( BodyFmt,rtrim(BodyFmt));
   sprintf_s(TitleFile, sizeof TitleFile,"%s.ti",outputf);
   sprintf_s(BodyFile, sizeof BodyFile,"%s.bd",outputf);

   strcpy(yymmbgn, cm_to_infdate(c_yymmbgn));
   strcpy(yymmend, cm_to_infdate(c_yymmend));
printf("&&& yymmbgn:[%s] yymmend:[%s] &&&\n", yymmbgn, yymmend);

printf("&&& dpt:[%s], datebgn:[%s], dateend:[%s] &&&\n", dptbgn, yymmbgn, yymmend);
   /* ***** title file ***** */
   rgu_init_report( TitleFmt,TitleFile);
   car709_title();
   rgu_finish_report();

   /* ***** body file ***** */
   rgu_init_report( BodyFmt,BodyFile);

   if (dptbgn[0] == '*'){
     strcpy(wherest1," ");
   }else{
     sprintf_s(wherest1, sizeof wherest1,"ibranch = '%s' AND ",dptbgn);
   }

   if (dptend[0] == '*'){
     strcpy(wherest2,"iestimate[1] >= 'A' AND iestimate[1] <= 'Z' AND ");
   }else{
     sprintf_s(wherest2, sizeof wherest2,"iestimate[1] = '%s' AND ",dptend);
   }

   if (eno[0] == '*'){
     strcpy(wherest3," ");
   }else{
     sprintf_s(wherest3, sizeof wherest3,"iabn_type[1] = '%s' AND ",eno);
   }

   if (strcmp(type, "2")==0){
     strcpy(wherest4,"ipolicy2 = ' ' AND ");
   }else if (strcmp(type, "3")==0){
     strcpy(wherest4,"ipolicy2 != ' ' AND ");
   }else{
     strcpy(wherest4," ");
   }
   
   if (strcmp(carflag, "1")==0){
     strcpy(wherest5,"icar_flag2 = '1' AND ");
   }else if (strcmp(carflag, "2")==0){
     strcpy(wherest5,"icar_flag2 = '2' AND ");
   }else{
     strcpy(wherest5," ");
   }

   if ((strcmp(type, "1")==0) || (strcmp(type, "2")==0))
   {
     sprintf_s(stmt, sizeof stmt,
     "SELECT iofficer2,iestimate,icard2,irelative_card,ilast_ply,nassured[1,10], "
            " to_char(dissue,'%%Y')::integer - 1911 || '/' || to_char(dissue,'%%m'),  "
            " nbrand_abbr[1,4],ibrand,icar_type2,qcylinder,iengine,itag,dply2_begin,dply2_end,  "
            " dapply,mpremium2,iassured,  "
            " to_char(dbirth,'%%Y')::integer - 1911 || '/' || to_char(dbirth,'%%m/%%d'), "
            " fsex,fmarriage,iabn_type,ibig_office,qpt,old_big_ply,  "
            " ipolicy2,icar_flag2,ibig_sales  "
      "  FROM estimate  "
      " WHERE %s %s %s %s %s dapply BETWEEN '%s' AND '%s'  "
      "   AND qply2_period > 0  "
      " ORDER BY 1,2",wherest1,wherest2,wherest3,wherest4,wherest5,yymmbgn,yymmend);
printf("[%s]\n",stmt);
     $PREPARE cur_01 FROM $stmt;
     $DECLARE Tcursor CURSOR FOR cur_01;
     $OPEN Tcursor;
     while(1){
       $FETCH Tcursor INTO $iofficer,$iestimate,$icard2,$icard1,$ilast_ply,$nassured,$iissue_ym,
                           $nbrand_abbr,$ibrand,$icar_type,$qcylinder,$iengine,$itag,$dply2_begin,$dply2_end,
                           $dpolicy,$mpremium,$iassured,$ibirth,$fsex,$fmarriage,$iabn_type,$ibig_office,$qpt,$old_big_ply,
                           $ipolicy2,$icar_flag,$ibig_sales;
printf("&&&SQLCODE:[%d]\n",SQLCODE);
       if(SQLCODE == SQLNOTFOUND) break;
printf("&&& fetch ca_local_clm &&&\n");

       if(first){
         strcpy(siofficer, iofficer);
         strcpy(sibig_office, ibig_office);
         car709_grp(); 
         first = 0;
       }
printf("body1\n");
       if(strcmp(siofficer, iofficer) != 0){
printf("body2\n");
         car709_tot();
         rgu_put_body(6);
         max_count++;
         car709_grp(); 
         strcpy(sibig_office, ibig_office);
         strcpy(siofficer, iofficer);
       }
printf("body\n");
       car709_body();
     } /* while */
printf("120\n");
     $CLOSE Tcursor;
     $FREE Tcursor;
     if(max_count != 0)
     car709_tot();
     rgu_finish_report();
   }
   else if (strcmp(type, "3")==0)
   {
     sprintf_s(stmt, sizeof stmt,
     "SELECT iofficer2,ipolicy2  "
     "  FROM estimate  "
     " WHERE %s %s %s %s %s dapply BETWEEN '%s' AND '%s'  "
     "   AND qply2_period > 0  "
     " ORDER BY 1,2",wherest1,wherest2,wherest3,wherest4,wherest5,yymmbgn,yymmend);
printf("[%s]\n",stmt);
     $PREPARE cur_02 FROM $stmt;
     $DECLARE Ucursor CURSOR FOR cur_02;
     $OPEN Ucursor;
     while(1){
       $FETCH Ucursor INTO $iofficer_est,$ipolicy2;
       if(SQLCODE == SQLNOTFOUND) break;
printf("&&& fetch ca_local_clm &&&\n");

       $DECLARE Pcursor CURSOR FOR
         SELECT a.iofficer,a.itmp_policy,a.icard,a.irelative_ply,' ',a.ilast_ply,b.nassured[1,10],
                to_char(dissue,'%Y')::integer - 1911 || '/' || to_char(dissue,'%m'),
                b.nbrand_abbr[1,4],a.ibrand,a.icar_type,b.qcylinder,b.iengine,b.itag,a.dply_begin,a.dply_end,
                a.dapply,(a.mdmg_prem+a.mlia_prem),b.iassured,
                to_char(b.dbirth,'%Y')::integer - 1911 || '/' || to_char(b.dbirth,'%m/%d'),
                b.fsex,b.fmarriage,' ',a.ibig_office,b.qpt,' ',
                icar_flag,ibig_sales
           FROM ply_relation a, policy b
          WHERE a.ipolicy = $ipolicy2
            AND a.ipolicy = b.ipolicy;
       $OPEN Pcursor;
       $FETCH Pcursor INTO $iofficer,$iestimate,$icard2,$ipolicy1,$icard1,$ilast_ply,$nassured,$iissue_ym,
                           $nbrand_abbr,$ibrand,$icar_type,$qcylinder,$iengine,$itag,$dply2_begin,$dply2_end,
                           $dpolicy,$mpremium,$iassured,$ibirth,$fsex,$fmarriage,$iabn_type,$ibig_office,$qpt,$old_big_ply,
                           $icar_flag,$ibig_sales;
       if(SQLCODE == SQLNOTFOUND) continue;

       $SELECT icard
          INTO $icard1
          FROM ply_relation
         WHERE ipolicy = $ipolicy2;
       if(SQLCODE == SQLNOTFOUND) 
         strcpy( icard1, ' ');

       if(first){
         strcpy(siofficer, iofficer);
         strcpy(sibig_office, ibig_office);
         car709_grp(); 
         first = 0;
       }
printf("body1\n");
       if(strcmp(siofficer, iofficer) != 0){
printf("body2\n");
         car709_tot();
         rgu_put_body(6);
         max_count++;
         car709_grp(); 
         strcpy(sibig_office, ibig_office);
         strcpy(siofficer, iofficer);
       }
printf("body\n");
       car709_body();
       $CLOSE Pcursor;
       $FREE Pcursor;
     } /* while */
printf("120\n");
     $CLOSE Ucursor;
     $FREE Ucursor;
     if(max_count != 0)
     car709_tot();
     rgu_finish_report();
   }
   return 0;
errexit:
   EWRITE(userid,SQLCODE,"Error on SQL");
   return 0;
}

/*----------------------------------------------------------------------------*/
void car709_title()
{
   char yy[3], mm[3];
   char titlest[25];
   if (strcmp(type, "2")==0){
     strcpy(titlest,"���N�I�w�n�O���X����Ӫ�");
   }else if (strcmp(type, "3")==0){
     strcpy(titlest,"   ���N�I�w�X����Ӫ�   ");
   }else{
     strcpy(titlest,"���N�I�۰���J�պ���Ӫ�");
   }
   rgu_put_head_string(1, titlest);         /* get_title */
   rgu_put_head_string(1, cm_get_sysd());   /* get_currdt */
   rgu_put_head_string(1, c_yymmbgn);
   rgu_put_head_string(1, c_yymmend);
   rgu_put_head();
}

/*----------------------------------------------------------------------------*/
void car709_grp()
{
printf("iofficer[%s]\n",iofficer);
   rgu_put_body_string(1, iofficer,1);
   $SELECT nname
      INTO $nname
      FROM officer
     WHERE iofficer = $iofficer;
   rgu_put_body_string(1, nname,1);    
   rgu_put_body_string(1, ibig_office,1);
   rgu_put_body(1);
   max_count++;
   return;
errexit:
printf("&&& car709_grp: SQLCODE:[%ld], ERRSTR:[%s] &&&\n", SQLCODE, sqlca.sqlerrm);
  EWRITE(userid,SQLCODE, sqlca.sqlerrm);
  exit(1);
}

void car709_body()
{
   char buf1[20], buf2[20];
   char buf3[20];
   $char sales_name[20];
   
   $SELECT nname
      INTO $sales_name
      FROM ca_big_office
     WHERE fclass = '2' 
       AND ibig_comp = $ibig_sales;
   if(SQLCODE == SQLNOTFOUND)
      strcpy(sales_name," ");
   
   
   iTot1 += mpremium;
   iTot2 += 1;
   strcpy( dply2_begin, cm_from_infdate_100( dply2_begin));
   strcpy( dply2_end, cm_from_infdate_100(dply2_end));
   strcpy( dpolicy, cm_from_infdate_100(dpolicy));
/*   strcpy( ibirth cm_from_infdate_100(ibirth));*/
   rfmtdouble(qcylinder,"-----.--",sqcylinder);/* 1080902001-SC1-�Ʈ�q�X�W�p���I2�� */
   rfmtlong(mpremium,"---,--&",smpremium);
   rfmtdouble(qpt,"--&.&",sqpt);
   rgu_put_body_string(2,rtrim(iestimate) ,1);
   rgu_put_body_string(2, rtrim(icard2), 1);
   rgu_put_body_string(2, rtrim(icard1), 1);
   rgu_put_body_string(2, rtrim(ilast_ply), 1);
   rgu_put_body_string(2, rtrim(nassured), 1);
   rgu_put_body_string(2,rtrim(iissue_ym), 1);
   rgu_put_body_string(2, rtrim(nbrand_abbr), 1);
   rgu_put_body_string(2,rtrim(ibrand), 1);
   rgu_put_body_string(2,rtrim(icar_type), 1);
   rgu_put_body_string(2,rtrim(sqcylinder), 1);
   rgu_put_body_string(2, rtrim(iengine), 1);
   rgu_put_body_string(2, rtrim(itag), 1);
   rgu_put_body_string(2, rtrim(sqpt), 1);
   rgu_put_body_string(2, rtrim(dply2_begin), 1);
   rgu_put_body_string(2,rtrim(dply2_end), 1);
   rgu_put_body_string(2, rtrim(dpolicy), 1);
   rgu_put_body_string(2, smpremium, 2);
   rgu_put_body_string(2, iofficer,1);
   rgu_put_body_string(2, ibig_office,1);
   rgu_put_body_string(2, nname,1);
   rgu_put_body_string(2, ibig_sales,1);
   rgu_put_body_string(2, sales_name,1);
   rgu_put_body_string(2, icar_flag,1);
   rgu_put_body_string(2, rtrim(iassured), 1);
   rgu_put_body_string(2, rtrim(ibirth), 1);
   rgu_put_body_string(2, rtrim(fsex), 1);
   rgu_put_body_string(2, rtrim(fmarriage), 1);
/*   rgu_put_body_string(2, rtrim(iabn_type), 1); */
   rgu_put_body_string(2, rtrim(old_big_ply), 1);
   rgu_put_body_string(2, rtrim(ipolicy2), 1);
   rgu_put_body(2);
   max_count++;
   return;
errexit:
printf("&&& car709_body: SQLCODE:[%ld], ERRSTR:[%s] &&&\n", SQLCODE, sqlca.sqlerrm);
  EWRITE(userid,SQLCODE, sqlca.sqlerrm);
  exit(1);
}

void car709_tot()
{
   char buf1[20];
   iTot = iTot1 + iTot2;
   rgu_put_body( 3);
   max_count++;

   rfmtlong(iTot1,"---,---,--&",siTot1);
   rfmtlong(iTot2,"---,--&",siTot2);
   sprintf_s(buf1, sizeof buf1,"%d",iTot);
   rgu_put_body_string(4, siTot2, 2);
   rgu_put_body_string(4, siTot1, 2);
   rgu_put_body(4);
   max_count++;
/*
   rgu_put_body(6);
   max_count++;
*/
   iTot1 = iTot2 = 0;
}
