/************************************************/
/*                                              */
/*   PROGRAM : car111m01s.ec			*/
/*                                              */
/************************************************/
     
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;
#include "safeclib.h"

typedef struct{
  long serial;
  char descrip[69];
  char tblname[31];
  char colname[31];
  char datatype[2];
  } car111_t;

long car111(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car111_insert(),car111_multiple_query(),car111_update_exec();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'A':
	   rtncode=car111_insert(reply);
	   break;
  case 'Q':
	   rtncode=car111_multiple_query(reply);
	   break;
  case 'D':
  case 'U':
	   rtncode=car111_update_exec(reply,command,com_len);
	   break;
  default :
	   if(exitsub(reply,M_CM_WRONG_OPTION) == True)
	    return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}

long car111_insert(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table endorsement_item */
 $char item[3],descrip[69],tblname[31],colname[31];
 $long serial;
 $char datatype[2];
 /* end	of endorsement_item */

 /* standard defined data */
 int tmp_len;
 car111_t *alist;
   DBinfo *list;
   int  k, j, is_add_fail=0, api_f;
   $char stmt_buf[300];
 /* end of standard data */

 /* self defined data */
 int rows,tmplen,i;
 long MsgCode;
 /* end	of self	data */

 cm_buf_get("%s",DBName);
 cm_buf_get("%s	%l",item,&rows);

 if (db_select(DBName) == False) 
  { 
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }
  alist = (car111_t *) malloc (rows * sizeof (car111_t));
  for (k=0;k<rows;k++) {
     cm_buf_get("%l %s %s %s %s",&(alist[k].serial),alist[k].descrip,alist[k].tblname,alist[k].colname,alist[k].datatype);
/*    alist[k].datatype[1]='\0'; */
  }


 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
  {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
  }

 $BEGIN WORK;
 for(j=0;j<i;j++)
 {
  sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO %s:endorsement_item "
 	" (iedr_item,eedr_item,qserial, ntable,ncolumn,fdatatype) "
	" VALUES (?,?,?,?,?,?)" ,list[j].dbname);

  $PREPARE a_id FROM $stmt_buf;
  if(SQLCODE != 0)
   {
    is_add_fail = 1;
    break;
   }
   for (k = 0;k < rows; k++){
	serial = alist[k].serial;
	strcpy(descrip, alist[k].descrip);
	strcpy(tblname, alist[k].tblname);
	strcpy(colname, alist[k].colname);
	strcpy(datatype, alist[k].datatype);
  	$EXECUTE a_id USING $item,$descrip,$serial,$tblname,$colname,$datatype;
  	if(SQLCODE != 0) {
    	    is_add_fail = 3;
    	break;
   	}
   }
   if (is_add_fail == 3){
       is_add_fail = 1;
       break;
   }
  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);
  tmp_len = cm_buf_len(ReplyBuf);
  if( j == i-1 )
     api_f = api_OKComplete;
  else
     api_f = api_OK;

  if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
    {
     is_add_fail = 2;
     break;
    }  
#ifdef DEBUG 
printf("INSERT %d\n", j+1);
#endif
 } /* for loop */

  for(k=0;k<rows;k++)
	free(alist[k]);
  free(alist);
 if( is_add_fail == 1 ) goto errexit;

 if( is_add_fail == 2 ) 
  {
   $ROLLBACK WORK;
   return apiRC;
  }


 $WHENEVER SQLERROR GOTO errexit;
 $COMMIT WORK;
 return api_OKComplete;

 errexit:
  $WHENEVER SQLERROR CONTINUE;    
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True) 
   return MsgCode;
  else  
   return apiRC;
}

long car111_multiple_query(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table endorsement_item */
 $char item[3],descrip[69],tblname[31],colname[31];
 $long serial = 0;
 $char datatype[2];
 /* end	of endorsement_item */

 /* standard defined data */
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0; 
 /* end of standard data */

 /* self defined data */
 /* end of self data */

 cm_buf_get("%s",DBName);
 cm_buf_get("%s",item);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False) 
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

 $DECLARE q_cur CURSOR FOR
    SELECT eedr_item,qserial,ntable,ncolumn,fdatatype
    INTO  $descrip, $serial, $tblname, $colname, $datatype
    FROM endorsement_item
    WHERE iedr_item = $item  
    ORDER BY qserial;

 $OPEN q_cur;

 for(;;)
  {
    $FETCH q_cur;
    if (SQLCODE != 0) break;

    cm_buf_init(tmpbuf); 
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();          
      cm_buf_put("%s",item);
     }
    cm_buf_put("%l %s %s %c %s",serial,tblname,colname,datatype[0],descrip);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */ 
     { 
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
	$CLOSE q_cur;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
	 cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE; 
        }
	ReplyBuf[0] = '\0';
	count = 0;
	cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
	cm_buf_res_count();
        cm_buf_put("%s",item);
        cm_buf_put("%l %s %s %c %s",serial,tblname,colname,datatype[0],descrip);
	repbuf_len = cm_buf_len(ReplyBuf);
	count++;
       }
     } 
  } /* for loop */

 $CLOSE q_cur;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
   if(exitsub(reply,M_CA_NEDR_ITEM) == True)
    return M_CA_NEDR_ITEM;
   else  
    return apiRC;
  } 

 errexit:
  if(exitsub(reply,SQLCODE) == True) 
   return SQLCODE;
  else  
   return apiRC;
}

long car111_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table endorsement_item */
 $char item[3],old_item[3],descrip[69],tblname[31],colname[31];
 $long serial;
 $char datatype[2];
 /* end	of endorsement_item */

 /* standard defined data */
 char option,*pos,*raw_ptr,cur_buf[4000],*comm;
 int tmp_len,raw_len;
 long dummy=0,dum_cnt;
   car111_t *alist;
   DBinfo *list;
   int i, j, is_del_fail=0, is_upd_fail=0;
   $char stmt_buf[300];
 /* end of standard data */

 /* self defined data */
 long count=0;
 long rows,k;
 long MsgCode;
 /* end of self data */

 comm = (char *) command;
 cm_buf_init(command);
 cm_buf_get("%c %s",&option,DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }
 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
  {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
  }
 /* compare old record and current record, if the record has not been changed  
    since last request, update or delete the record, otherwise return errmsg
    to client side */

 /* get old record info from command buffer */ 

 memcpy(&raw_len,&comm[com_len],sizeof(int));   
 pos = &comm[com_len+sizeof(int)];
 raw_ptr = malloc(raw_len);
 if (raw_ptr != (char*)0)  
  memcpy(raw_ptr,pos,raw_len);
 else
  {
   if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */ 
    return M_CM_NOT_MALLOC;
   else  
    return apiRC;
  }
    
 cm_buf_init(raw_ptr);          /* get index key from old record */
 cm_buf_get("%l %l",&dummy,&dum_cnt);
 cm_buf_get("%s",old_item);

   $BEGIN WORK;

 $DECLARE q_cur1 CURSOR FOR
    SELECT eedr_item,qserial,ntable,ncolumn,fdatatype
    INTO  $descrip, $serial, $tblname, $colname, $datatype
    FROM endorsement_item
    WHERE iedr_item=$old_item;

 $OPEN q_cur1;

 cm_buf_init(cur_buf);
 cm_buf_res_msg();	       /* reserve for MsgCode and count	*/
 cm_buf_res_count();
 cm_buf_put("%s",old_item);

 for(;;)
  {
    $FETCH q_cur1;
    if (SQLCODE != 0) break;

    cm_buf_put("%l %s %s %c %s",serial,tblname,colname,datatype[0],descrip);
    count++;
  }
 $CLOSE q_cur1;
  /* if key value has been changed then SQLNOTFOUND,else put current value
     into cur_buf for comparison */ 
 if (count==0)
  {
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(exitsub(reply,M_CM_NOT_FOUND) == True) 
    return M_CM_NOT_FOUND;
   else  
    return apiRC;
  }
   $WHENEVER SQLERROR GOTO errexit;
 cm_buf_init(cur_buf);
 cm_buf_put_msg(dummy);
 cm_buf_put_count(count);

 if (memcmp(cur_buf,raw_ptr,raw_len) !=	0) /* compare 2	records, not equal */
  {
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(exitsub(reply,M_CM_NOT_EQUAL) == True) 
    return M_CM_NOT_EQUAL;
   else  
    return apiRC;
  }
   $WHENEVER SQLERROR GOTO errexit;
   
   free(raw_ptr);
  
 /* equal, then exec DB operation */

 if ( option == 'D' )
  {
   for(j=0;j<i;j++)
   {
    sprintf_s(stmt_buf, sizeof stmt_buf,"DELETE FROM %s:endorsement_item  WHERE iedr_item = ?"
		,list[j].dbname); 
    $PREPARE d_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      break;
     }
    $EXECUTE d_id USING $old_item;
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      break;
     }
#ifdef DEBUG 
printf("Delete %d\n", j+1);
#endif
   }/* for loop */

   if( is_del_fail ) goto errexit;
   
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }  

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else if (option == 'U')
  {
   cm_buf_init(command);
   cm_buf_get("%c %s",&option,DBName);
   cm_buf_get("%s %l",item,&rows);
  alist = (car111_t *) malloc (rows * sizeof (car111_t));
  for (k=0;k<rows;k++) {
     cm_buf_get("%l %s %s %s %s",&(alist[k].serial),alist[k].descrip,alist[k].tblname,alist[k].colname,alist[k].datatype);
/*    alist[k].datatype[1]='\0'; */
  }
   for (j=0;j<i;j++) {
   /* delete old data first */
    sprintf_s(stmt_buf, sizeof stmt_buf,"DELETE FROM %s:endorsement_item  WHERE iedr_item = ?"
		,list[j].dbname); 
    $PREPARE d1_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      break;
     }
    $EXECUTE d1_id USING $old_item;
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      break;
     }
     sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO %s:endorsement_item "
 	" (iedr_item,eedr_item,qserial, ntable,ncolumn,fdatatype) "
	" VALUES (?,?,?,?,?,?)" ,list[j].dbname);

  $PREPARE ua_id FROM $stmt_buf;
  if(SQLCODE != 0)
   {
    is_upd_fail = 1;
    break;
   }
   for (k = 0;k < rows; k++){
	serial = alist[k].serial;
	strcpy(descrip, alist[k].descrip);
	strcpy(tblname, alist[k].tblname);
	strcpy(colname, alist[k].colname);
	strcpy(datatype, alist[k].datatype);
       $EXECUTE ua_id USING $item,$descrip,$serial,$tblname,$colname,$datatype;
  	if(SQLCODE != 0) {
    	    is_upd_fail = 3;
    	break;
   	}
   }
   if (is_upd_fail == 3){
       is_upd_fail = 1;
       break;
   }
#ifdef DEBUG 
printf("Update %d\n", j+1);
#endif
 }
   for (k=0;k<rows;k++)
	free(alist[k]);
  free(alist);
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }  

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else
  {
   if(exitsub(reply,M_CM_WRONG_OPTION) == True) 
    return M_CM_WRONG_OPTION;
   else  
    return apiRC;
  } 

 errexit:
  $WHENEVER SQLERROR CONTINUE;
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True) 
   return MsgCode;
  else  
   return apiRC;
}
