/********************************************
 * Copyright (C) 1993 Intellisys Corporation
 *
 * Program : ca207q01s.ec 01/25/1994
 *
 * Modified: Johnny Kuo 04/01/1997 
 *
 * Background Report   (Type : Block 1)
 *********************************************/

#include <stdio.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "print.h"
#include "is_def.h"

#include "commsgs.h"
#include "carmsgs.h"
#include "gls_array.h"
#include "gls_const.h"
#include "safeclib.h"

/*---------------------------------------------------------------------*/
extern char RPTDIR[];

$struct dep_t {
    char ibranch[3];
    char nchi_abv[13];
 };
$struct dep_t dep[MAXROWITEMS]; 

$char deptbgn[6],deptend[6],officerbgn[11],officerend[11];
$char issdtbgn[25],issdtend[25];
$char cardclass;
char s_issdtbgn[20],s_issdtend[20],choice[2];

/* standard data declaration */
$char DBName[5],userid[11];
$char FormTp[3];
char outputf[N_FILE+1];
char yy[4],mm[3],dd[3];

int  bcount,ycount;
int  TotRows=0;

static int pagenum=1;

/* end of standard data */

long car207_build();
void car207_title();
void car207_body();

#define  NEXTPAGE   5

/*-------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
 int rc;

 
 batchinit();
 strcpy(DBName,isNULLstr(argv[1]));
 strcpy(userid,isNULLstr(argv[2]));

 strcpy(choice,    isNULLstr(argv[3]));
 strcpy(s_issdtbgn,isNULLstr(argv[4]));
 strcpy(s_issdtend,isNULLstr(argv[5]));
 strcpy(&cardclass,isNULLstr(argv[6]));
 strcpy(deptbgn,   isNULLstr(argv[7]));
 strcpy(deptend,   isNULLstr(argv[8]));
 strcpy(officerbgn,isNULLstr(argv[9]));
 strcpy(officerend,isNULLstr(argv[10]));

 strcpy(outputf,isNULLstr(argv[11]));

 if (s_issdtbgn[0] =='*')
     strcpy(s_issdtbgn, "080/01/01");
 if (s_issdtend[0] =='*')
     strcpy(s_issdtend, "199/12/31");
 if (s_issdtend[0]==' ')
     strcpy(s_issdtend, s_issdtbgn);

 if (choice[0]=='2') {
     if (officerbgn[0]=='*')
         strcpy(officerbgn,"          ");
     if (officerend[0]=='*')
         strcpy(officerend,"~~~~~~~~~~");
     if (officerend[0]==' ')
         strcpy(officerend, officerbgn);
     strcpy(deptbgn,"  ");
     strcpy(deptend,"~~");
 }

 if (choice[0]=='1') {
     if (deptbgn[0]=='*')
         strcpy(deptbgn,"  ");
     if (deptend[0]=='*')
         strcpy(deptend,"~~");
     if (deptend[0]==' ')
         strcpy(deptend, deptbgn);
     strcpy(officerbgn,"          ");
     strcpy(officerend,"~~~~~~~~~~");
 }

 strcpy(issdtbgn,cm_to_infdate(s_issdtbgn));
 strcpy(issdtend,cm_to_infdate(s_issdtend));

printf("%s %s %s %s %s %s %s %s\n",s_issdtbgn,s_issdtend,&cardclass,
         choice,deptbgn,deptend,officerbgn,officerend);

 car207_build();

/* create_sign_form("car207",BodyFile,Width);  */

 if ((rc=save_form_info(F_BLK1,"CA",207,userid,FormTp,TotRows,outputf))<0)
     EWRITE(userid,rc,"save_form_info failed");
}

/*-----------------------------------------------------------------*/
long car207_build()
{
   char BodyFile [N_FILE+1];
   char TitleFile[N_FILE+1];
  $char BodyFmt [N_FILE+1];
  $char TitleFmt[N_FILE+1];

  $int StartRow,TitleRow;
  $int ItemRow,TotColumn;
  $int PgLine,Width;
  int  i=0,j;

  if (db_select(DBName) == False)
  {
      EWRITE(userid,M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return 0;
  }

  $SELECT nTitle_Fmt, nBody_Fmt,   kStart_Row, kTitle_Row, kItem_Row,
          kTot_col,   kPgNum_Line, kWidth,     iForm_Tp
     INTO $TitleFmt,  $BodyFmt,    $StartRow,  $TitleRow,  $ItemRow,
          $TotColumn, $PgLine,     $Width,     $FormTp
     FROM Form
    WHERE ksys_grp="CA" AND kPgmID = 207;

  strcpy(TitleFmt,rtrim(TitleFmt));
  strcpy(BodyFmt,rtrim(BodyFmt));
  sprintf_s(TitleFile, sizeof TitleFile,"%s.ti",outputf);
  sprintf_s(BodyFile, sizeof BodyFile,"%s.bd",outputf);

  rgu_init_report(TitleFmt,TitleFile);
  car207_title();
  rgu_finish_report();

  rgu_init_report(BodyFmt,BodyFile);
  car207_body();
  rgu_finish_report();
}

/*-----------------------------------------------------------------------*/
void car207_title()
{
  rgu_put_head_string(1, cm_sysd_cdate_100(cm_get_sysd()));   /* get_currdt */

  cm_split_ymd_100(s_issdtbgn,yy,mm,dd);
  rgu_put_head_string(1, yy);
  rgu_put_head_string(1, mm);
  rgu_put_head_string(1, dd);

  cm_split_ymd_100(s_issdtend,yy,mm,dd);
  rgu_put_head_string(1, yy);
  rgu_put_head_string(1, mm);
  rgu_put_head_string(1, dd);
  rgu_put_head();
}

/*-------------------------------------------------------------------------*/
void car207_body()
{
 int   i,j,counter,total_qcard,get_already;
 $char fcard_class[2],icard_begin[CARD_NUM],icard_end[CARD_NUM];
 $char s_dissue[25],icar_type[3],iofficer[11],ioffice[7];
 $long qcard = 0,dissue = 0,qperiod = 0;
 $char ioff[11];
 $char yy[30][4],cyy[4], stmt_buf[400];
 char  s_qperiod[3], FullDBName[20];
 char  buf[10];

  $WHENEVER SQLERROR GOTO errexit;

  $DECLARE acur CURSOR FOR
    SELECT ibranch, nchi_abv
      FROM branch
     WHERE ibranch BETWEEN $deptbgn AND $deptend
     ORDER BY ibranch;
  $OPEN acur;
  for(i=0;i<100;i++) {
     $FETCH acur INTO $dep[i].ibranch, $dep[i].nchi_abv;
     if (SQLCODE == SQLNOTFOUND) break;
        printf("************ dept = %s\n",dep[i].ibranch);
  }
  $CLOSE acur;
  bcount = i;

 $DECLARE bcur CURSOR FOR
   SELECT DISTINCT icardyear
     FROM issued_card
    WHERE dissue BETWEEN $issdtbgn AND $issdtend
    ORDER BY icardyear;
 $OPEN bcur;
 for(i=0;i<30;i++) {
     $FETCH bcur INTO $yy[i];
     if (SQLCODE == SQLNOTFOUND) break;
        printf("************ yy = %s\n",yy[i]);
 }
 $CLOSE bcur;
 ycount = i;

 printf("************ bcount=%d ycount=%d\n",bcount,ycount);


TotRows=0;
for(i=0;i<bcount;i++) {

 strcpy(FullDBName,get_full_dbname(dep[i].ibranch));
 if (FullDBName[0]=='\0') continue;
 printf("******** dbname[%s]\n",FullDBName);

 for (j=0;j<ycount;j++) {

   strcpy(cyy,yy[j]);

   /******* prepare cursor for select issued_card where fcard_class='1' ******/
   sprintf_s(stmt_buf, sizeof stmt_buf,"SELECT %s %s FROM %s:%s %s %s %s %s %s %s %s",
                    "fcard_class,icard_begin,icard_end,qcard,dissue," ,
                    "icar_type,qperiod,iofficer,ioffice" ,
                    FullDBName,"issued_card ", 
                     "WHERE (iofficer BETWEEN ? AND ?) ", 
                       "AND (dissue BETWEEN ? AND ?) ", 
                       "AND fcard_class=\"1\" ", 
                       "AND icardyear=? ", 
                       "AND icard_begin != \" \" AND icard_begin IS NOT NULL ", 
                       "AND icard_end != \" \"   AND icard_end IS NOT NULL ", 
                     "ORDER BY icard_begin,icard_end");
   $PREPARE CUR_STMT1 FROM $stmt_buf;
   $DECLARE cur1 CURSOR FOR CUR_STMT1;

   /******* prepare cursor for select issued_card where fcard_class='2' ******/
   sprintf_s(stmt_buf, sizeof stmt_buf,"SELECT %s %s FROM %s:%s %s %s %s %s %s %s %s",
                    "fcard_class,icard_begin,icard_end,qcard,dissue, ",
                    "icar_type,qperiod,iofficer,ioffice", 
                    FullDBName,"issued_card ",
                     "WHERE (iofficer BETWEEN ? AND ?) ",
                       "AND (dissue BETWEEN ? AND ?) ",
                       "AND fcard_class=\"2\" ",
                       "AND icardyear=? ",
                       "AND icard_begin != \" \" AND icard_begin IS NOT NULL ",
                       "AND icard_end != \" \"   AND icard_end IS NOT NULL ", 
                     "ORDER BY icard_begin,icard_end");
   $PREPARE CUR_STMT2 FROM $stmt_buf;
   $DECLARE cur2 CURSOR FOR CUR_STMT2;

   get_already = 0;

   if (cardclass=='1'||cardclass=='9') 
   {
     $OPEN cur1 USING $officerbgn,$officerend,$issdtbgn,$issdtend,$cyy;
     total_qcard=0;
     counter=0;

     for (;;) {
       $FETCH cur1 INTO $fcard_class,$icard_begin,$icard_end,$qcard,$dissue,
                        $icar_type,$qperiod,$iofficer,$ioffice;
       if (SQLCODE == SQLNOTFOUND) break;

       if (get_already==0) {
           if (TotRows != 0) {
               rgu_put_body(NEXTPAGE);
               TotRows++;
           }
           rgu_put_body_string(1,dep[i].ibranch,1);
           rgu_put_body_string(1,dep[i].nchi_abv,1);
           rgu_put_body(1);
           get_already=1;
           TotRows ++;
       }
       counter++;
       TotRows++;
       strcpy(s_dissue,cm_cdate_str_100(dissue));
       total_qcard+=qcard;

       rgu_put_body_string(2,"�j��",1);
       rgu_put_body_string(2,icard_begin,1);
       rgu_put_body_string(2,icard_end,1);
       rfmtlong(qcard,"##&",buf);
printf("what's qcard[%s]\n",buf);       
       /*rgu_put_body_string(2,buf,RIGHT);*/
       rgu_put_body_string(2,buf,2);
       rgu_put_body_string(2,s_dissue,1);
       rgu_put_body_string(2,icar_type,1);
       rfmtlong(qperiod,"#&",buf);
       rgu_put_body_string(2,buf,RIGHT);
       rgu_put_body_string(2,iofficer,1);
       rgu_put_body_string(2,ioffice,1);
       rgu_put_body(2);
     } /* end of for loop of cur1 */
     $CLOSE cur1;
     if (counter>0) {
        rgu_put_body(4);
        rfmtlong(total_qcard,"#,##&",buf);
        rgu_put_body_string(3,buf,RIGHT);
        rgu_put_body(3);
        rgu_put_body(4);
        TotRows += 3;
     }
   } /* end of if ...==1 */


   if (cardclass=='2'||cardclass=='9') {
     $OPEN cur2 USING $officerbgn,$officerend,$issdtbgn,$issdtend,$cyy;
     total_qcard=0;
     counter=0;

     for (;;) {
       $FETCH cur2 INTO $fcard_class,$icard_begin,$icard_end,$qcard,$dissue,
                        $icar_type,$qperiod,$iofficer,$ioffice;
       if (SQLCODE == SQLNOTFOUND) break;

     /*  if (counter==0 && get_already==0) { */
         if (counter==0) {
             if (TotRows != 0) {
                 rgu_put_body(NEXTPAGE);
                 TotRows++;
             }
             rgu_put_body_string(1,dep[i].ibranch,1);
             rgu_put_body_string(1,dep[i].nchi_abv,1);
             rgu_put_body(1);
             TotRows += 1;
         }
        counter++;
        TotRows++;
        strcpy(s_dissue,cm_cdate_str_100(dissue));
        total_qcard+=qcard;

        rgu_put_body_string(2,"���N",1);
        rgu_put_body_string(2,icard_begin,1);
        rgu_put_body_string(2,icard_end,1);
	rfmtlong(qcard,"#&",buf);
        rgu_put_body_string(2,buf,RIGHT);
        rgu_put_body_string(2,s_dissue,1);
        rgu_put_body_string(2,icar_type,1);
        s_qperiod[0]=' ';
        s_qperiod[1]=' ';
        s_qperiod[2]='\0';
        rgu_put_body_string(2,s_qperiod,RIGHT);
        rgu_put_body_string(2,iofficer,1);
        rgu_put_body_string(2,ioffice,1);
        rgu_put_body(2);
     } /* end of loop of cur2 */
     $CLOSE cur2;
     if (counter>0) {
        rgu_put_body(4);
	rfmtlong(total_qcard,"#,##&",buf);
        rgu_put_body_string(3,buf,RIGHT);
        rgu_put_body(3);
        rgu_put_body(4);
        TotRows += 3;
     }
   } /* end of else if ...==2 */

  } /* end of for j */
 } /* end of for i */
return;

errexit:
  printf("Hello: SQLCODE=%ld errm=%s\n",SQLCODE,sqlca.sqlerrm);
}
