/********************************************************/
/*           �T���I���l���w�M���Ӫ�                     */
/* Program : car809.ec   (data producer)                */
/*                                                      */
/* Date    : 09/25/1995                                 */
/* Edit    : 10/07/1999      By Peter Sun               */
/********************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "carmsgs.h"
#include "gls_array.h"
#include "gls_const.h"
#include "safeclib.h"

#define SUCCESS                 1
#define FAIL                    0
#define YES                     1
#define NO                      0
#define NEXTPAGE                7
#define FOUND                   sqlca.sqlcode!=SQLNOTFOUND
#define NOT_FOUND               sqlca.sqlcode==SQLNOTFOUND

/*------------------------------------*/
extern char RPTDIR[];

$char  dptbgn[3], dptend[3];
$char  ibranch[4], nchi_abv[13];
$char  Tmp_ibranch[4], Tmp_iclaim[15];
$char  ibranch_1[4],sal[1];

$char  path_DataFile[80];
$char  outputf[ 21];

$long  Tot_cnt, Tot_paid, Tot_loss, Tot_trace,Tot_loss_count,Tot_trace_count ;
$long  Tot_Tot_loss_count , Tot_Tot_loss , Tot_Tot_trace_count , Tot_Tot_trace;

$char  DBName[5];
$char  FormTp[3];
char   BodyFile[ N_FILE+1];
char   TitleFile[ N_FILE+1];
char   userid[11];

float tused=0;
time_t tstart,tstop;

static int pagenum=1;

$int   ItemRow, TotColumn;
$int   StartRow,TitleRow;
$int   PgLine, Width = 0;
$int   iCnt;
int    max_count, errCode;
int    tmp_len;

$char  iinstype_key[3];
$char  datebgn[11], dateend[11], groupbgn[11], groupend[11];
$char  cDatebgn[20], cDateend[20], cGroupbgn[20], cGroupend[20];
$char  stmt[1024];
$char  nbrand_abbr[43],nbrand[30];
char   s_nbrand_abbr[43];

long   msg_code;

$struct Rec809 {
   char note[3];
   char iclaim[CLAIM_NUM];
   char ipolicy[POLICY_NUM_1];
   char fstl[2];
   int  iclose_type;
   int  mdamage_cover;
   char iins_type[INSURANCE_TYPE];
   char iadjuster[7];
   char iacc_reason[3];
   char nassured[21];
   char icar_type[3];
   char ibrand[9];
   char ipro_year[5];
   char itag[CA_TAG_NUM];
   char iengine[CA_ENGINE_NUM];
   char daccident[21];
   char iacc_area[3];
   long mapp_damage;
   char dgroup[15];
   long mdmg_stl;
   char fsal[2];
   long mmsal_done;
   long fstl_stl;
} r;

long car809_build();
void car809_title();
void car809_grp();
void car809_body();
void car809_tot();

/*--------------------------------------------------------------*/
/****************************************************************/
main(argc,argv)
int  argc;
char **argv;
{
  long rc=0;

  batchinit();
  /* Begin Grasp Data From Client ------------------------------*/
  strcpy(DBName,       isNULLstr(argv[1]));
  strcpy(userid,       isNULLstr(argv[2]));
  strcpy(ibranch,      isNULLstr(argv[3]));  /* ���z��� */
  strcpy(iinstype_key, isNULLstr(argv[4]));  /* �I�إN�� A.�ѵs B.���l C.���� */
  strcpy(datebgn,      isNULLstr(argv[5]));  /* ���z�_�� */
  strcpy(dateend,      isNULLstr(argv[6]));  /* ���z���� */
  strcpy(groupbgn,     isNULLstr(argv[7]));  /* �J�p�_�� */
  strcpy(groupend,     isNULLstr(argv[8]));  /* �J�p���� */
  strcpy(sal,          isNULLstr(argv[9]));  /* ��檬�A */
  strcpy(outputf,      isNULLstr(argv[10]));
  /*-----------------------------------------*/
  
  printf( "sal [%s] \n",sal);

  /*printf("******[car809_build]:Begin******\n"); */
  rc = car809_build();
  if (rc == api_OKComplete)
  {
       /* printf("******* car809_build SUCCESS !!!!! \n"); */
       create_sign_form("car809",BodyFile, Width);
       if ((rc=save_form_info(F_BLK1,"CA",809,userid,FormTp,max_count,outputf))<0)
            EWRITE(userid,rc,"save_form_info_failed");
  }
  /* printf("********* ok ********* \n"); */
} /*** main ***/


long car809_build()
{
   long rc=0;
   $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];
   $char  iclaim[CLAIM_NUM], ipolicy[POLICY_NUM_1], daccident[15];
   $long  dclose_ctype, dclose_rtype;
   int    i;
   $char  chk_iins_type[INSURANCE_TYPE];
   $char  buf2[16];

   $WHENEVER SQLERROR GOTO errexit;

   if(db_select(DBName) == False)
   {
       EWRITE(userid,M_CM_DB_NOTOPEN,"M_CM_DB_NOTOPEN");
       return FAIL;
   }

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width, $FormTp
      FROM Form
     WHERE ksys_grp = "CA" AND kPgmID = 809;

   strcpy(TitleFmt, rtrim(TitleFmt));
   strcpy(BodyFmt, rtrim(BodyFmt));
   sprintf_s(TitleFile,21, "%s.ti", outputf);
   sprintf_s(BodyFile,21, "%s.bd", outputf);

   $WHENEVER SQLERROR GOTO errexit;
   
Tot_Tot_loss_count = Tot_Tot_loss = Tot_Tot_trace_count = Tot_Tot_trace = 0;  
   $CREATE TEMP TABLE car809_temp
   (
        note           char(3),
        ibranch        char(3),
        iclaim         char(13),
        nassured       char(21),
        ipolicy        char(18),
        iins_type      char(6),
        mdamage_cover  integer DEFAULT 0,
        icar_type      char(3),
        ibrand         char(9),
        ipro_year      char(5),
        itag           char(12),
        iengine        char(25),
        iadjuster      char(7),
        iacc_reason    char(3),
        daccident      date,
        iacc_area      char(3),
        mapp_loss      integer DEFAULT 0,
        fstl           char(2),
        iclose_type    smallint,
        dgroup         date,
        mdmg_stl       integer DEFAULT 0,
        fsal           char(2),
        mmsal_done     integer DEFAULT 0,
        fstl_stl       integer default 0
   )WITH NO LOG;

   /* �B�z���Y */
   rgu_init_report(TitleFmt, TitleFile);
   car809_title();
   rgu_finish_report();

   /* �B�z���� */
   rgu_init_report(BodyFmt, BodyFile);

   /* �}�l������� */
   /* printf("Begin car809_p !!!\n");  */
   car809_p();
   /* printf("iinstype_key[%s]\n",iinstype_key);  */
   /*** A.�ѵs B.���l C.���� ***/

   if (iinstype_key[0] == 'A')
       strcpy(chk_iins_type,iinstype_key);
   else if (iinstype_key[0] == 'B')
       strcpy(chk_iins_type,iinstype_key);
   else if (iinstype_key[0] == 'C')
       strcpy(chk_iins_type,"*");

   printf("******iinstype_key[%s],chk_iins_type[%s]\n",iinstype_key,chk_iins_type);

   $DECLARE Acursor1 CURSOR FOR
     SELECT note, ibranch, iclaim, ipolicy, fstl, iclose_type, nassured,
            icar_type, ibrand, ipro_year, itag, iengine, daccident,
            iacc_area, mapp_loss, dgroup, mdmg_stl, iins_type, mdamage_cover,
            iadjuster,iacc_reason, fsal, mmsal_done, fstl_stl
       FROM car809_temp
      WHERE note matches $chk_iins_type
      ORDER BY ibranch, ipolicy, iclaim, fstl ,iclose_type;

   $OPEN Acursor1;

   for (i=0;; i++)
   {
      $FETCH Acursor1
        INTO $r.note, $ibranch, $r.iclaim, $r.ipolicy, $r.fstl, $r.iclose_type,
             $r.nassured, $r.icar_type, $r.ibrand, $r.ipro_year, $r.itag, $r.iengine,
             $r.daccident, $r.iacc_area, $r.mapp_damage, $r.dgroup, $r.mdmg_stl,
             $r.iins_type, $r.mdamage_cover, $r.iadjuster, $r.iacc_reason, $r.fsal,
             $r.mmsal_done, $r.fstl_stl;

      if (SQLCODE == SQLNOTFOUND)
      {
         /* no officer found */
         if (i == 0)
         {
            EWRITE(userid, SQLCODE, "�L�X�G���󪺸�� !");
            return 0;
         }
         break;
      }

         if ((r.fstl[0] != '1') || (r.iclose_type != 1)) r.mmsal_done = 0;

         printf("r.mmsal_done[%ld]\n",r.mmsal_done);


      /* printf("*** 1.*** Tmp_ibranch[%s],ibranch[%s]\n",Tmp_ibranch,ibranch);  */
      /* printf("******* i == [%d] \n",i); */
      if (i == 0)
      {
            /* printf("*** 2.*** Tmp_ibranch[%s],ibranch[%s]\n",Tmp_ibranch,ibranch);  */
            /* printf("���Ĥ@�����!!!!\n");   */
            strcpy (Tmp_ibranch, ibranch);
            /* printf("*** 2.1*** Tmp_ibranch[%s],ibranch[%s]\n",Tmp_ibranch,ibranch);  */
            $SELECT nchi_abv INTO $nchi_abv
               FROM branch
              WHERE ibranch = $ibranch;

            if (SQLCODE == SQLNOTFOUND) strcpy( nchi_abv, "  ");
            rgu_put_body_string(1, ibranch, 2);
            rgu_put_body_string(1, nchi_abv, 2);
            rgu_put_body(1);
            max_count++;
            Tot_cnt = Tot_paid = Tot_loss = Tot_trace = Tot_loss_count = Tot_trace_count = 0;
      }
      else if( strcmp( Tmp_ibranch, ibranch) != 0)
      {
         /* printf("���P���ɤ���!!! \n");  */
         /* printf("*** 3 ***Tmp_ibranch[%s],ibranch[%s]\n",Tmp_ibranch,ibranch);  */

         car809_tot();
         rgu_put_body(5);     /* npage */
         max_count++;

         car809_grp();
         strcpy (Tmp_ibranch, ibranch);
         /* printf("*** 3.1 ***Tmp_ibranch[%s],ibranch[%s]\n",Tmp_ibranch,ibranch);  */
         Tot_cnt = Tot_paid = Tot_loss = Tot_trace = Tot_loss_count = Tot_trace_count = 0;
      }

      printf("r.iclaim[%s]\n",r.iclaim);
      printf("r.fstl[%s]\n",r.fstl);
      
      sprintf_s(stmt,1024,
       " select first 1 nbrand_abbr[1,6],nbrand[1,10]   \
           from ca_car_model                            \
          where ibrand    = ?    \
            and ipro_year = ? ");
      $prepare get_nbrand from $stmt;
      $execute get_nbrand into $nbrand_abbr,$nbrand using $r.ibrand, $r.ipro_year;

      if (NOT_FOUND)
      {
         sprintf_s(stmt,1024,
          " select first 1 nbrand_abbr[1,6],nbrand[1,10]   \
              from ca_car_model                            \
             where ibrand    = ?  ");
         $prepare get_nbrand from $stmt;
         $execute get_nbrand into $nbrand_abbr,$nbrand using $r.ibrand;
      }
      
/*
       $select nbrand_abbr[1,6],nbrand[1,10]
         into $nbrand_abbr,$nbrand
         from ca_car_model
        where ibrand = $r.ibrand
          and ipro_year = $r.ipro_year
          and drate = '07/01/2001';
*/
        
        s_nbrand_abbr[0]='\0';
        strcpy(nbrand_abbr,trim(nbrand_abbr));
        strcpy(nbrand,trim(nbrand));
        strcat(s_nbrand_abbr,nbrand_abbr);
        strcat(s_nbrand_abbr,nbrand);
        
        printf(" s_nbraned_abbr[%s]\n",s_nbrand_abbr);
        
      if (NOT_FOUND)
      {
          strcpy(s_nbrand_abbr," ");
          
      }
      printf(" 00000000000000000000000000000000 \n");
      printf(" s_nbrand_abbr[%s]\n",s_nbrand_abbr);
      car809_body();
      
   }
   $CLOSE Acursor1;
   $FREE Acursor1;

   car809_tot();
   
   rfmtlong(Tot_Tot_loss_count, "###,###,##&", buf2);
   rgu_put_body_string(7, trim(buf2), RIGHT);
   rfmtlong(Tot_Tot_loss, "###,###,###,##&", buf2);
   rgu_put_body_string(7, trim(buf2), RIGHT);
   rgu_put_body(7);
    
   rfmtlong(Tot_Tot_trace_count, "###,###,##&", buf2);
   rgu_put_body_string(8, trim(buf2), RIGHT);
   rfmtlong(Tot_Tot_trace , "###,###,###,##&", buf2);
   rgu_put_body_string(8, trim(buf2), RIGHT);
   rgu_put_body(8);


   rgu_finish_report();

   return SUCCESS;
/* return M_CM_OK;  */

errexit:
   /* printf("Lai:err,%d",SQLCODE);  */
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return 0;
}

/***********************************************************************/
car809_p()
{
     $char sqlstr[1000];
     $char iclaim[CLAIM_NUM], nassured[21], ipolicy[POLICY_NUM_1], icar_type[13];
     $char iclaim_tmp[CLAIM_NUM],ipolicy_tmp[POLICY_NUM_1];
     $char ibrand[19], ipro_year[15], itag[CA_TAG_NUM], iengine[CA_ENGINE_NUM], iacc_area[13];
     $char ibranch_at[3];
     $char iacc_reason[3];
     $int  iclose_type = 0;
     $char fstl[2], ibranch_in[3];
     $char iins_type[INSURANCE_TYPE], iadjuster[7];
     $int  mdamage_cover = 0;
     $date daccident, dgroup;
     $int  mapp_damage, mdmg_stl = 0,fstl_stl;
     $char LocalName[50];
     $char note[3];
     $char fpart[3],fsal[2];
     $char sal_condition[30],ibranch_tmp[20];
     $int  mmsal_done = 0;
     $char sSouter[20];
     $char branch_temp[3];
     

     $WHENEVER SQLERROR goto errexit;

     /* Steven add 840920 --------------------------------------------------- */
     if (datebgn[0] == '*') strcpy(datebgn, "87/01/01"); /* 8 */
     if (dateend[0] == '*') strcpy(dateend, "99/12/31");
     if (dateend[0] == ' ') strcpy(dateend, datebgn);

     strcpy(cDatebgn, cm_to_infdate(datebgn));
     strcpy(cDateend, cm_to_infdate(dateend));
     strcpy(cGroupbgn, cm_to_infdate(groupbgn));
     strcpy(cGroupend, cm_to_infdate(groupend));

     /*** ���B�z ibranch ***/

     if (strcmp(trim(ibranch),"A") == 0)      /*** �_�� ***/
     {
         strcpy(ibranch_1,"**0");
     }
     else if (strcmp(trim(ibranch),"B") == 0) /*** ���� ***/
     {
         strcpy(ibranch_1,"**1");
     }
     else if (strcmp(trim(ibranch),"C") == 0) /*** �n�� ***/
     {
         strcpy(ibranch_1,"**2");
     }
     else                                     /*** ��J����@��� ***/
     {
         strcat(ibranch,"*");
         strcpy(ibranch_1,ibranch);
     }

     printf("ibranch_1[%s]\n",ibranch_1);             
     
     strcpy(sSouter," ");    
     /*  ��檬�A���� */
     
     if ( strcmp(trim(sal),"0") == 0)   /* ������� */
     {
        strcpy(sal_condition,"AND d.fsal = '0'");
     }
     else if ( strcmp(trim(sal),"1") == 0) /* ��椤 */
     {
        strcpy(sal_condition,"AND d.fsal = '1'");
     }
     else if ( strcmp(trim(sal),"2") == 0) /* ����� */
     {
        strcpy(sal_condition,"AND d.fsal = '2'");
     }
     else if ( strcmp(trim(sal),"3") == 0) /* ��槹�� */
     {
        strcpy(sal_condition,"AND d.fsal = '3'");
     }
     else if ( strcmp(trim(sal),"4") == 0) /* �M�^�ծ� */
     {
        strcpy(sal_condition,"AND d.fsal = '4'");
     }
     else 
     {
        strcpy(sal_condition , " "); /* ���� */
        strcpy(sSouter,"outer");
     }
     
     printf( "sal_condition [%s]\n",sal_condition);

     /* James  add 860813 ----------------------------------------- */
     /* printf("date bgn[%s], date end[%s]\n",cDatebgn, cDateend);  */

     /***** �d�߱�����������z�õ��ת��߮ץ� *****/
     
     /* sprintf_s(stmt,1024,"SELECT iclaim , ipolicy , ibranch_in \
                   FROM ca_clm_process \
                   WHERE dclaim >= '%s' AND dclaim <= '%s' \
                   AND iclaim[6,6] = 'V' %s \
                   ORDER BY 1; ",cDatebgn, cDateend, ibranch_tmp); */
                   
/*  $set explain on;    */
   time(&tstart);                   
     
     $CREATE TEMP TABLE iacc_temp
      (
          iclaim      char(20) default ' '
      );
     $CREATE index iacc_t_ix_11 ON iacc_temp (iclaim);
  
     $DECLARE ss_cur CURSOR FOR 
       SELECT branch
         INTO $branch_temp
         FROM servertbl
        WHERE branch != 'S1';
     $OPEN ss_cur;
     for(;;)
     {
     $FETCH ss_cur;
     if (SQLCODE == SQLNOTFOUND) break;

        sprintf_s(stmt,1024,
         " INSERT INTO iacc_temp             \
            SELECT iclaim                    \
              FROM %s:appraisal              \
             WHERE fpart IN ('1','2','3') ",get_full_dbname(branch_temp));
        $PREPARE get_iacc FROM $stmt;
        $EXECUTE get_iacc;
     }
     $CLOSE ss_cur;
     $FREE  ss_cur;

     $DECLARE clm_sel CURSOR FOR
       SELECT a.iclaim , a.ipolicy , a.ibranch_in
         FROM ca_clm_process a,iacc_temp b
        WHERE a.dclaim >= $cDatebgn AND a.dclaim <= $cDateend
          AND a.iclaim[6,6] = 'V'
          AND a.iclaim[1,3] matches $ibranch_1
          AND a.iclaim = b.iclaim
        ORDER BY 1; 
        
     $OPEN clm_sel;
     while(1)
     {
            $FETCH clm_sel INTO $iclaim_tmp,$ipolicy_tmp,$ibranch_in;
            if(SQLCODE == SQLNOTFOUND) break;

            /*** ���߮ש��k�ݪ���Ʈw ***/
            strcpy(LocalName,get_full_dbname(ibranch_in));
            printf("Ibranch_in[%s] , LocalName[%s] \n",ibranch_in,LocalName);


            /*** �� Local��Ʈw��w�M�߮� ***/
            /**  ��J�p�϶����w�M���߮סA�N���߮׾����ߥI�B�l�v���z���Ƨ�X
            **/
            sprintf_s(stmt,1024,"SELECT iclaim, fstl, iclose_type, dgroup, msettle \
                            FROM %s:settlement \
                           WHERE iclaim = '%s' \
                             AND dgroup BETWEEN '%s' AND '%s' \
                           ORDER BY iclaim, iclose_type",
                           LocalName,iclaim_tmp,cGroupbgn,cGroupend);

            $PREPARE cur_dgroup FROM $stmt;
            $DECLARE cur_dgroup1 CURSOR for cur_dgroup;
            $OPEN cur_dgroup1;
            $FETCH cur_dgroup1 INTO $iclaim, $fstl, $iclose_type, $dgroup, $mdmg_stl;
            if( SQLCODE == SQLNOTFOUND ) continue;
            $CLOSE cur_dgroup1;
            $FREE  cur_dgroup1;

            /*** �� Local��Ʈw��w�M�߮� ***/
            sprintf_s(stmt,1024,"SELECT iclaim, fstl, iclose_type, dgroup, msettle \
                            FROM %s:settlement \
                           WHERE iclaim = '%s' \
                             AND dgroup <= '%s' \
                           ORDER BY iclaim, iclose_type",
                           LocalName,iclaim_tmp,cGroupend);

            $PREPARE cur_tmp FROM $stmt;
            $DECLARE cur1 CURSOR FOR cur_tmp;
            $OPEN cur1;
            while(1)
            {
                $FETCH cur1 INTO $iclaim, $fstl, $iclose_type, $dgroup, $mdmg_stl;
                if (NOT_FOUND) break;

                printf("iclaim[%s]\n",iclaim);

                /*** fpart�i�����l�O�j ���l��1:���� 2:�N�� 3:���� ***/
                sprintf_s(stmt,1024,"SELECT a.fpart, b.nassured[1,20], a.ipolicy, b.icar_type, \
                                     b.ibrand, b.ipro_year, b.iengine, \
                                     b.daccident,b.iacc_area, c.mins_app, a.iacc_reason, a.fpart, \
                                     c.mdamage_cover, c.iins_type, a.iadjuster, a.iacc_reason, d.fsal,NVL(d.mmsal_done,0), \
                                     b.itag       \
                                FROM %s:appraisal a, %s:adjustment_ply b, %s:app_ins_type c, \
                                     %s %s:recovery d \
                               WHERE a.iclaim = '%s' \
                                 AND b.iclaim = a.iclaim \
                                 AND c.iclaim = a.iclaim \
                                 AND d.iclaim = a.iclaim \
                                 AND c.iins_type in ('01','02','05','08','09','11','201','205','209','211') \
                                 AND a.fpart in ('1','2','3') %s",
                        LocalName,LocalName,LocalName,sSouter,LocalName,iclaim,sal_condition);
                
                 printf("stmt[%s]\n",stmt);

                $PREPARE cur_tmp2 FROM $stmt;
                $DECLARE cur2 CURSOR FOR cur_tmp2;
                $OPEN cur2;
                while(1)
                {
                     $FETCH cur2 INTO $fpart, $nassured, $ipolicy, $icar_type, $ibrand, $ipro_year,
                                      $iengine, $daccident, $iacc_area, $mapp_damage,
                                      $iacc_reason, $fpart, $mdamage_cover, $iins_type, $iadjuster,
                                      $iacc_reason, $fsal, $mmsal_done,$itag;
                     
                     if (SQLCODE == SQLNOTFOUND) 
                        break;

                     /*** �N�X�I��]23:���Ѩ��M�^�״_���߮׽�X ***/
                     if (strncmp(iacc_reason,"23",2)==0)
                          continue;

                     /*** �Ϥ����ѵs:A ���l:B ***/
                     strcpy(fpart,trim(fpart));
                  /* printf("iclaim[%s],iacc_reason[%s],fpart[%s]\n",iclaim,iacc_reason,fpart); */

                     if (fpart[0] == '2' || fpart[0] == '3')  /** ���l **/
                     {
                         printf("fpart ==> 2,3 \n");
                         strcpy(note,"B");
                     }
                     else if (fpart[0] == '1')                /** �ѵs **/
                     {
                         printf("fpart ==> 1 \n");
                         strcpy(note,"A");
                     }

                     /*** �H���z�߮׳�쬰��¦�A�G�H�߮׸��e��X�g�Jibrach ***/
                     strncpy(ibranch_at,ipolicy,2);
                     ibranch_at[2] = '\0';

       /*              sprintf_s(stmt,1024, "SELECT itag FROM %s:policy WHERE ipolicy = '%s'",
                             LocalName, ipolicy );

                     printf("stmt[%s]\n",stmt);

                     $PREPARE curtag FROM $stmt;
                     $EXECUTE curtag INTO $itag;                  */
                     
                     /**   Ū�C�ӽ߮פ��l�v�`�B  **/
                     if( (strcmp(fstl,"1") == 0 ) && iclose_type == 1 )
                     {
                        
                        sprintf_s(stmt,1024,"SELECT SUM(mins_stl) FROM %s:stl_ins_type "
                                     " WHERE iclaim = ? AND iins_type = ? AND fstl = '2' "
                                     "   AND dgroup <=  ? ",LocalName);
                        
                        printf("stmt[%s]\n",stmt);
                        $PREPARE cur3 FROM $stmt;
                        $EXECUTE cur3 INTO $fstl_stl USING $iclaim, $iins_type,
                                           $cGroupend;
                        
                        if( fstl_stl <= 0 ) fstl_stl = 0;
                        
                     }
                     else fstl_stl = 0;
                     
                     
                     printf("insert into car809_temp -iclaim[%s]\n",iclaim);
                     $INSERT INTO car809_temp
                        (note, ibranch, iclaim, ipolicy, fstl, iclose_type, nassured,
                         icar_type, ibrand, ipro_year, itag, iengine, daccident,
                         iacc_area, mapp_loss, dgroup, mdmg_stl, mdamage_cover,
                         iins_type, iadjuster, iacc_reason, fsal, mmsal_done,
                         fstl_stl )
                     VALUES
                        ($note, $ibranch_at, $iclaim, $ipolicy, $fstl ,$iclose_type,$nassured,
                         $icar_type, $ibrand, $ipro_year, $itag, $iengine, $daccident,
                         $iacc_area, $mapp_damage, $dgroup, $mdmg_stl, $mdamage_cover,
                         $iins_type, $iadjuster, $iacc_reason, $fsal, $mmsal_done,
                         $fstl_stl );
                }
                $CLOSE cur2;
                $FREE  cur2;

            } /** end of while **/
            $CLOSE cur1;
            $FREE  cur1;
     }
     
 /*    $set explain off;   */
      time(&tstop);
      tused=difftime(tstop,tstart);
      printf("�������=%f��\n",tused);
     $CLOSE clm_sel;
     $FREE  clm_sel;
     /* Steven end 840920 ---------------------------------------------------- */
     return M_CM_OK;

errexit:
  if (SQLCODE != 0) msg_code = SQLCODE;
  printf("car809_p():SQLCODE=[%ld], sqlerrm=[%s]\n",msg_code, sqlca.sqlerrm);
  return SQLCODE;
}

/***********************************************************************/

/* ���Y -----------------------------------------------------------*/
void car809_title()
{
   char yy[4], mm[3], dd[3];

   if (iinstype_key[0] == 'A')
   {
       rgu_put_head_string(1,"(����)");
   }
   else if (iinstype_key[0] == 'B')
   {
       rgu_put_head_string(1,"(���l)");
   }
   else if (iinstype_key[0] == 'C')
   {
       rgu_put_head_string(1,"(���ѤΨ��l)");
   }

   rgu_put_head_string(1, cm_sysd_cdatetime_100(cm_get_sysd()));  /* get_currdt */

   cm_split_ymd_100(datebgn, yy, mm, dd);
   rgu_put_head_string(1, yy);
   rgu_put_head_string(1, mm);
   rgu_put_head_string(1, dd);
   cm_split_ymd_100(dateend, yy, mm, dd);
   rgu_put_head_string(1, yy);
   rgu_put_head_string(1, mm);
   rgu_put_head_string(1, dd);

   rgu_put_head();
}

/*----------------------------------------------------------------------------*/
void car809_grp()
{
   $SELECT nchi_abv INTO $nchi_abv
      FROM branch
     WHERE ibranch = $ibranch;

   if (SQLCODE == SQLNOTFOUND) strcpy( nchi_abv, "  ");
   rgu_put_body_string(1, ibranch, LEFT);
   rgu_put_body_string(1, nchi_abv, LEFT);
   rgu_put_body(1);     /* npage */
   max_count++;
   return;

errexit:
   printf("Jam:err,%d",SQLCODE);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return;
}

/*----------------------------------------------------------------------------*/
void car809_body()
{
   char buf1[16], buf2[9],buf3[31];
   
    printf(" s_nbranc_abbr[%s]\n",s_nbrand_abbr);

   Tot_cnt++;
   /** Tot_paid += r.paid_loss; **/
   if (r.fstl[0]=='1')
   {  
      if(r.iclose_type == 1)
      {
       Tot_loss_count = Tot_loss_count + 1;
       Tot_loss += r.mdmg_stl;
      }
   }
   else
   {  
      if(r.iclose_type == 1)
      { 
       Tot_trace_count = Tot_trace_count + 1;
       Tot_trace += r.mdmg_stl;  
      }
   }
   /* printf ("**************Tot_loss[%d] Tot_trace [%d]\n",Tot_loss,Tot_trace);  */
   /* printf("daccident[%s]\n", r.daccident);  */
   if (strcmp(Tmp_iclaim, r.iclaim) != 0)
   {
      strcpy(Tmp_iclaim, r.iclaim);
      rgu_put_body_string(2, r.iclaim, LEFT);            /*** �߮׸��X ***/
      rgu_put_body_string(2, r.nassured, LEFT);          /*** �Q�O�I�H ***/
      rgu_put_body_string(2, r.ipolicy, LEFT);           /*** �O�渹�X ***/
      /* rgu_put_body_string(2, r.icar_type, LEFT); */   /*** ��    �� ***/
 
      printf(" ******************************************************** \n");
      rgu_put_body_string(2, r.ibrand, LEFT);            /*** �t�P���� ***/
      
      printf(" s_nbranc_abbr[%s]\n",s_nbrand_abbr);
      rgu_put_body_string(2, trim(s_nbrand_abbr), LEFT);            /*** �t�P���� ***/
      rgu_put_body_string(2, r.ipro_year, LEFT);         /*** �s�y�~�� ***/
      rgu_put_body_string(2, r.itag, LEFT);              /*** �P�Ӹ��X ***/
      rgu_put_body_string(2, r.iengine, LEFT);           /*** �������X ***/
      rgu_put_body_string(2, r.iadjuster, LEFT);         /*** �z�ߤH�� ***/
      rgu_put_body_string(2, r.iacc_area, LEFT);         /*** �X�I�a�� ***/
      rgu_put_body_string(2, r.iacc_reason, LEFT);       /*** �X�I��] ***/
      /** strcpy(buf2,cm_from_infdate_100(r.daccident));
          yy/mm/dd = cm_from_infdate_100(mm/dd/yyyy) **/
      rgu_put_body_string(2, r.daccident , LEFT);                /*** �X�I�ɶ� ***/
      rgu_put_body_string(2, r.iins_type, LEFT);         /*** �I    �� ***/
      rfmtlong(r.mdamage_cover, "##,###,##&", buf1);
      rgu_put_body_string(2, buf1, RIGHT);               /*** �O�I���B ***/

      rfmtlong(r.mapp_damage, "##,###,##&", buf1);
      rgu_put_body_string(2, buf1, RIGHT);               /*** �w�����B ***/
   }
   else
   {
      rgu_put_body_string(2, " ", LEFT);
      rgu_put_body_string(2, " ", LEFT);
      rgu_put_body_string(2, " ", LEFT);
      rgu_put_body_string(2, " ", LEFT);
      rgu_put_body_string(2, " ", LEFT);
      rgu_put_body_string(2, " ", LEFT);
      rgu_put_body_string(2, " ", LEFT);
      rgu_put_body_string(2, " ", LEFT);
      rgu_put_body_string(2, " ", LEFT);
      rgu_put_body_string(2, " ", LEFT);
      rgu_put_body_string(2, " ", LEFT);
      rgu_put_body_string(2, " ", LEFT);
      rgu_put_body_string(2, " ", LEFT);
      rgu_put_body_string(2, " ", LEFT);
      rgu_put_body_string(2, " ", LEFT);
   }
 
   if (r.fstl[0]=='1')                                   /*** �߮שʽ� ***/
      rgu_put_body_string(2,"�ߥI" , LEFT);
   else
      rgu_put_body_string(2,"�l�v" , LEFT);
  
   sprintf_s(buf2,9,"%d",r.iclose_type);
   rgu_put_body_string(2, buf2, LEFT);                   /*** �߰l���� ***/
  
   /**strcpy(buf2,cm_from_infdate_100(r.dgroup));
      yy/mm/dd = cm_from_infdate_100(mm/dd/yyyy) **/
   rgu_put_body_string(2, r.dgroup, LEFT);                   /*** ���פ�� ***/

   rfmtlong(r.mdmg_stl, "##,###,##&", buf1);
   rgu_put_body_string(2, buf1, RIGHT);                  /*** �ߴڪ��B(�w�M���B) ***/

  
  printf( " fsal = [%s] \n",r.fsal);
  if (strcmp(trim(r.fsal),"0") == 0)      /*** ������� ***/
     {
         strcpy(buf3,"�������");
     }
  else if (strcmp(trim(r.fsal),"1") == 0)      /*** ��椤 ***/
     {
         strcpy(buf3,"��椤  ");
     }
  else if (strcmp(trim(r.fsal),"2") == 0)      /*** ����� ***/
     {
         strcpy(buf3,"�����");
     }
  else if (strcmp(trim(r.fsal),"3") == 0)      /*** ��槹�� ***/
     {
         strcpy(buf3,"��槹��");
     }
  else if (strcmp(trim(r.fsal),"4") == 0)      /*** �M�^�ծ� ***/
     {
         strcpy(buf3,"�M�^�ծ�");
     }
  else strcpy(buf3," ");

   rgu_put_body_string(2, trim(buf3), RIGHT);                  /*** ��檬�A ***/
   rfmtlong(r.mmsal_done,"---,---,---,--&",buf3);
   rgu_put_body_string(2, trim(buf3), 2);                      /*** �������B ***/
   
   rfmtlong(r.fstl_stl,"---,---,---,--&",buf3);                /*** �l�v�`�B   ***/
   rgu_put_body_string(2, trim(buf3), 2);
   
   rgu_put_body(2);
   max_count++;
   
     
   
   
}
/*----------------------------------------------------------------------------*/
void car809_tot()
{
   char buf1[12];

/**
   rgu_put_body(3);
   max_count++;
**/
   Tot_Tot_loss_count += Tot_loss_count;
   Tot_Tot_loss += Tot_loss;
   rfmtlong(Tot_loss_count, "###,###,##&", buf1);
   rgu_put_body_string(4, trim(buf1), RIGHT);
   rfmtlong(Tot_loss, "###,###,##&", buf1);
   rgu_put_body_string(4, trim(buf1), RIGHT);
   rgu_put_body(4);
   max_count++;
 
   Tot_Tot_trace_count += Tot_trace_count;
   Tot_Tot_trace += Tot_trace;
   rfmtlong(Tot_trace_count , "###,###,##&", buf1);
   rgu_put_body_string(6, trim(buf1), RIGHT);
   rfmtlong(Tot_trace , "###,###,##&", buf1);
   rgu_put_body_string(6, trim(buf1), RIGHT);
   rgu_put_body(6);
   max_count++;
}


