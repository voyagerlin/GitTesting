/************************************************/
/*                                              */
/*   PROGRAM : ca208q01s.ec by Dennis Chang     */
/*                                              */
/*   DATE    : 1993/09/25                       */
/*   modified: 1994/01/25                       */
/*   modified: Johnny 04/02/1997                */
/*   modified: RybackHsu 07/01/2003             */
/*   modified: 1060821005-C5 �O�I�ҽL�I���ӱƵ{�H*/
/*           ���p�G�n�A�W�[�Ѽ� shell�]�n�վ�    */
/*             1061017004-C1 �վ�ﶵ�t�o����w�q
/*            �אּ��l�t�o���  �����o��줴�O�t�o��*/
/*                                              */
/*   Background Report   (Type : Block 1)       */
/************************************************/
#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "print.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"

#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"
#define DATENULL               0x80000000L

/*------------------------------------*/
extern char RPTDIR[];

$char BrkIcardyear[4], BrkFstatus[2], BrkIofficer[11];
$char ZIofficer[11];
$char XIbranch[3];
$char YNchi_abv[7];
$char ZIcard[19];
$char ZDissue[17];
$char ZIcar_type[3];
$int  ZQperiod;
$char ZQperiod_char[3];
$int  ZMpremium;
$char ZMpremium_char[10];
$char ZFstatus[2];
$char zdalter[17];
$char ZFstatus_char[21];
$char ZIpolicy[19];
$char ZIdeliver[11];
$char ZDdeliver[17];
$char ZDreceive[17];
$int  ZQreprint;
$char ZQreprint_char[3];
$char ZIcardyear[4];
$char ZIoffice[7];
$char ZIiss_b[4];
$char ZIissue_bh[11];
$char ZDentry[11];
$char cardclass[5];
$char cartype[3];
$char ZIalter[11];
$char sIbranch[3];
$char sIissue_bh[11];

/*    */
$char Zddeliver_old[11],Zddeliver_old_100[11];
$char Zfin_out[2];
$char fin_out[2];
$char Zfin_out_char[9],cnt_lastday_char[6];
$char limit_date[11],sys[11],limit_date_100[11],zdalter_100[11];
$int sys_int,limit_date_int,zdalter_int,cnt_lastday;


$char FullDBName[20];

$char DBName[5],userid[11];
$char FormTp[3];
char outputf[N_FILE+1];
char yy1[4], mm1[3], dd1[3];
char yy2[4], mm2[3], dd2[3];
char strA[17];

$int ItemRow, TotColumn;
$int StartRow,TitleRow;
$int PgLine, Width;

$char officerbgn[ 11], officerend[ 11];
$char ideliverbgn[11], ideliverend[11];
$char dptbgn[ 3], dptend[ 3];
$char card1[19], card2[19];
$char issdtbgn_char[ 17], issdtend_char[17];
$char issdtbgn[ 17], issdtend[17];
$char cardstatus1[2];
$char iquota[11];
char  choice[2];
char  funopt[2];
char  choice1[2];

char  date_ch[2];
$char alterbgn[17],alterend[17];
$char alterbgn_char[17],alterend_char[17];
$char delivbgn[17],delivend[17];
$char delivbgn_char[17],delivend_char[17];
$char changbgn[17],changend[17];
$char changbgn_char[17],changend_char[17];
/**super**/
int f;
char ZIiss_ba[20];
char f_flag[5];
char m_fstatus_0[30],m_fstatus_2[30],m_fstatus_1[30],m_fstatus_3[30],m_fstatus_r[30];
char m_fstatus_4[30],m_fstatus_5[30],m_fstatus_6[30],m_fstatus_7[30],m_fstatus_t[30];
char m_fstatus_8[30],m_fstatus_A[30],m_fstatus_B[30],m_fstatus_C[30],m_fstatus_D[30],m_fstatus_E[30];
char sfrflag[2];
$char sApHome[30];
$char msgbuf[1024];
$char sKbill_code[5];
FILE  *fp;

/*�s�W���O��� add by larry 103.04.17 (1030408009_C1) */
$char iFstatus[2],sIend_type[5];

/*1060906003_C1_car208 �s�W�������*/
$char inventory_nbranch[41],ZIdeliver_nbranch[41];

/*1060821005-C5 */
$long lEndDay_car208b;
$char mail_type[3],userid_6[7];
$char inventory_ncode[3];
$char  stmt_list[2048],nproject[255], mail_text[2000],sContent[5000],email[51], chinese_name[15],cc[51];
$loc_t ctxt;
$char mail_inventory_nbranch[41],mail_inventory_ncode[3],mail_issue_bh[41],mail_icard[21],mail_dissue[10];
$char mail_nissue[11],mail_dreceive[10],mail_icar_type[3],mail_fstatus[21];
$char mail_ipolicy[21],mail_sIdeliver_nbranch[41],mail_ideliver[11],mail_ndeliver[11];
$char mail_nleader[11],mail_ileader[11],mail_ddeliver[10],mail_dalter[10];
$char mail_ialter[11],mail_nalter[11],mail_bh_ialter[41],mail_iend_type[5];
$char mail_reprint_char[3],mail_road_dentry[11],mail_sDdeliver_old_100[11];
$char mail_sFin_out_char[9],mail_limit_date_100[11],mail_cnt_lastday_char[6];
$char mail_mail_type[3],mail_car_code_mail[21],mail_resp_name_mail[21];
$char mail_top_unit_mail[21],resp_name_mail[21],top_unit_mail[21];
$char fname[100],ftitle[1024],filename[256],sFeedback[1024],nattachment[100];
int rc;

long errCode;
int  BrkCount, BrkSubTotal;
long  max_count[10];
int  FileCnt=1;
int  tmp_len;
long  miy = 0, first=1;
int  flag_brk,tmpfs;

long car208_build();
long car208_build1();
void car208_title();
void car208_brk();
void car208_body();
void car208_body1();
void car208_tot1();
void car208_grp();
long car208_branch();
long car208_data();
long car208_compulsory_list();
long car208_compulsory_ks();
char *get_car_full_db();

long car208_branch1();
long car208_data1();

long car208_mail();
void car208_list();
long car208_subject();
void car208_Summary();


int   fstatus_0,fstatus_1,fstatus_2,fstatus_3,fstatus_4,fstatus_5,fstatus_6,fstatus_7,fstatus_tot;
int   fstatus_0_tot,fstatus_1_tot,fstatus_2_tot,fstatus_3_tot,fstatus_4_tot,fstatus_5_tot,fstatus_6_tot,fstatus_7_tot,fstatus_tot2;
int   fstatus_8, fstatus_8_tot,fstatus_A,fstatus_A_tot,fstatus_B,fstatus_B_tot,fstatus_C,fstatus_C_tot,fstatus_D,fstatus_D_tot,fstatus_E,fstatus_E_tot;
double  fstatus_r;
double  fstatus_r2;
#define LINEOFPAGE      52
#define NEXTPAGE        7

#define COMP_M          1   /*�j��-����9  */
#define COMP_S          2   /*�j��-����0~6*/
#define CARD_M          3   /*���N-����9 */
#define CARD_S          4   /*���N-����0~6*/

#define CAR             1   /*�T��*/
#define MOT             2   /*����*/
#define COMP            1   /*�j��*/
#define CARD            2   /*���N*/

#define COMP_CARD_M     5
#define COMP_CARD_S     6

/*----------------------------------------------------------------------------*/
main(argc,argv)
int argc;
char **argv;
{
   int  rc,jj;
   $char g_sMsgBuf[100];

   batchinit();

   printf("==>%d\n",argc);
   strcpy(DBName,isNULLstr(argv[1]));
   strcpy(userid,isNULLstr(argv[2]));

   if(argc<23)
   {
        printf("end report\n");
        exit(1);
   }
   printf("continue1\n");
   strcpy(funopt,       isNULLstr(argv[3]));    /*1.���� 2.�J�` 3.�j��@�o�M�� 4.�Ϳ��@�o�M��*/
   strcpy(choice,       isNULLstr(argv[4]));
   strcpy(issdtbgn_char,isNULLstr(argv[5]));
   strcpy(issdtend_char,isNULLstr(argv[6]));
   strcpy(alterbgn_char,isNULLstr(argv[7]));
   strcpy(alterend_char,isNULLstr(argv[8]));
   strcpy(delivbgn_char,isNULLstr(argv[9]));
   strcpy(delivend_char,isNULLstr(argv[10]));
   strcpy(changbgn_char,isNULLstr(argv[11]));
   strcpy(changend_char,isNULLstr(argv[12]));
   strcpy(choice1,      isNULLstr(argv[13]));
   strcpy(dptbgn,       isNULLstr(argv[14]));
   strcpy(dptend,       isNULLstr(argv[15]));
   strcpy(iquota,       isNULLstr(argv[16]));
   strcpy(officerbgn,   isNULLstr(argv[17]));
   strcpy(officerend,   isNULLstr(argv[18]));
   strcpy(ideliverbgn,  isNULLstr(argv[19]));
   strcpy(ideliverend,  isNULLstr(argv[20]));
   strcpy(card1,        isNULLstr(argv[21]));
   strcpy(card2,        isNULLstr(argv[22]));
   strcpy(cardclass,    isNULLstr(argv[23]));
   strcpy(cartype,      isNULLstr(argv[24]));
   strcpy(cardstatus1,  isNULLstr(argv[25]));
  /*strcpy(cards2003/7/22 03:46PMtatus2,  isNULLstr(argv[22]));*/
   strcpy(sKbill_code,  isNULLstr(argv[26]));
   strcpy(sfrflag,      isNULLstr(argv[27]));
   /*1060821005_C3_�j���Һ޲z�{��(���s�Pe�O��)*/
   strcpy(fin_out,      isNULLstr(argv[28]));
   strcpy(outputf,      isNULLstr(argv[29]));
   printf("157 ==><%s>\n",outputf);
   printf("158 ==><%s>\n",sfrflag);

   if (choice[0]=='1') {
       cm_split_ymd_100(issdtbgn_char, yy1, mm1, dd1);
       cm_split_ymd_100(issdtend_char, yy2, mm2, dd2);
       strcpy(issdtbgn, cm_to_infdate(issdtbgn_char));
       strcpy(issdtend, cm_to_infdate(issdtend_char));
   }

   if (choice[0]=='2') {
       cm_split_ymd_100(alterbgn_char, yy1, mm1, dd1);
       cm_split_ymd_100(alterend_char, yy2, mm2, dd2);
       strcpy(alterbgn, cm_to_infdate(alterbgn_char));
       strcpy(alterend, cm_to_infdate(alterend_char));
   }

   if (choice[0]=='3') {
        cm_split_ymd_100(delivbgn_char, yy1, mm1, dd1);
        cm_split_ymd_100(delivend_char, yy2, mm2, dd2);
        strcpy(delivbgn, cm_to_infdate(delivbgn_char));
        strcpy(delivend, cm_to_infdate(delivend_char));

   }
   
   if (choice[0]=='4') {
       cm_split_ymd_100(changbgn_char, yy1, mm1, dd1);
       cm_split_ymd_100(changend_char, yy2, mm2, dd2);
       strcpy(changbgn, cm_to_infdate(changbgn_char));
       strcpy(changend, cm_to_infdate(changend_char));
   }
   
   if (choice[0]=='5') {
   	   cm_split_ymd_100(issdtbgn_char, yy1, mm1, dd1);
       cm_split_ymd_100(issdtend_char, yy2, mm2, dd2);
       strcpy(issdtbgn, cm_to_infdate(issdtbgn_char));
       strcpy(issdtend, cm_to_infdate(issdtend_char));
       strcpy(delivbgn, cm_to_infdate(delivbgn_char));
       strcpy(delivend, cm_to_infdate(delivend_char));
   }

   fstatus_0=fstatus_1=fstatus_2=fstatus_3=fstatus_4=0;
   fstatus_5=fstatus_6=fstatus_7=fstatus_8=fstatus_tot=0;
   fstatus_A=fstatus_B=fstatus_C=fstatus_D=fstatus_E=0;
   fstatus_0_tot=fstatus_1_tot=fstatus_2_tot=fstatus_3_tot=0;
   fstatus_4_tot=fstatus_5_tot=fstatus_6_tot=fstatus_7_tot=0;
   fstatus_8_tot=fstatus_A_tot=fstatus_B_tot=fstatus_C_tot=0;
   fstatus_D_tot=fstatus_E_tot=fstatus_tot2=0;
    strcpy(userid_6,substring(userid,1,6));
    
      
   /***
   printf("208 \n");
   ****/
   if (funopt[0]=='1')
   {
       if (rc=car208_build()==M_CM_OK)
       {
           for (jj=0;jj<FileCnt;jj++)
           {
               if ((rc=save_form_info(F_BLK1,"CA",208,userid,FormTp,max_count[jj],outputf))<0)
                  EWRITE(userid,rc,"save_form_info failed");
           }
       }
       else
       {
          EWRITE(userid,rc,"Proccess Failed !");
       }
   }
   else if (funopt[0]=='2')
   {
       if (rc=car208_build1()==M_CM_OK)
       {
           for (jj=0;jj<FileCnt;jj++)
           {
               if ((rc=save_form_info(F_BLK1,"CA",208,userid,FormTp,max_count[jj],outputf))<0)
                  EWRITE(userid,rc,"save_form_info failed");
           }
       }
       else
       {
          EWRITE(userid,rc,"Proccess Failed !");
       }
   }
   else if (funopt[0]=='3')
   {
   	  rc = car208_compulsory_list();
   	  if (rc != SUCCESS)
     {
       EWRITE(userid,rc,g_sMsgBuf);
  	   return rc;
     }
   }
   else if (funopt[0] == '4')
   {
   	  rc = car208_compulsory_ks(); /* �Ϳ��@�o�M�� */
   		if (rc != M_CM_OK) 
     {
       EWRITE(userid,rc,msgbuf);
       return rc;
	   }        
   }     
  
   printf("******************************************PROCCESS FINISHED !!\n");

}

/*----------------------------------------------------------------------------*/
long car208_build()
{
   char BodyFile [10][N_FILE+1];
   char TitleFile[10][N_FILE+1];
   $char TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];

   $int ItemRow, TotColumn;
   $int StartRow,TitleRow;
   $int PgLine, Width;

   if (db_select(DBName) == False) {
       EWRITE(userid,M_CM_DB_NOTOPEN,"M_CM_DB_NOTOPEN");
       return 0;
   }

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
           kTot_Col, kPgNum_Line, kWidth,     iForm_Tp
      INTO $TitleFmt,  $BodyFmt,  $StartRow,  $TitleRow,  $ItemRow,
           $TotColumn, $PgLine, $Width, $FormTp
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 208 AND iForm_Tp = '1';

   strcpy( TitleFmt, rtrim(TitleFmt));
   strcpy( BodyFmt, rtrim(BodyFmt));

    if (strcmp(userid_6,"car208") == 0)
    {   
    
        rc = getApHome(sApHome);
        if (rc < 0) {
            strcpy(msgbuf,"read Config file error!!-->getApHome\n");
            EWRITE(userid,rc,msgbuf);
            return rc;
        }
        
        $EXECUTE IMMEDIATE "DROP TABLE IF EXISTS car208_mail";
        
        $create temp table car208_mail(
        inventory_nbranch char(40),  /*�L�I���*/
        inventory_ncode char(2),
        issue_bh          char(40),  /*�ӻ���*/
        icard             char(20),  /*�O�I����*/
        dissue            char(9),   /*�ӻ��*/
        nissue            char(10),  /*�ӻ�H*/
        dreceive          char(9),   /*�������*/
        icar_type         char(2),   /*����*/
        fstatus           char(20),  /*���ʪ��A*/
        ipolicy           char(20),  /*�O�渹�X*/
        sIdeliver_nbranch char(40),  /*�t�o�g����*/
        ideliver          char(10),  /*�t�o�g��H*/
        ndeliver          char(10),  /*�g��H*/
        nleader           char(10),  /*�t�o�g��H�̷s�޲z�H*/
        ileader           char(10),  /*�t�o�g��H�̷s�޲z�H�N��*/
        ddeliver          char(9),   /*�t�o���*/
        dalter            char(9),   /*���ʤ��*/
        ialter            char(10),  /*���ʤH�N��*/
        nalter            char(10),  /*���ʤH��*/
        bh_ialter         char(40),  /*���ʤH�����*/
        iend_type         char(4),   /*���O*/
        reprint_char      char(2),   /*�ɦL����*/
        road_dentry       char(10),  /*�����ʲz��J���    */
        sDdeliver_old_100 char(10),  /*��l�t�o��  */
        sFin_out_char     char(8),   /*�q��    */
        limit_date_100    char(10),  /*���^����  */
        cnt_lastday_char  char(5),   /*�Y�N����Ѽ�*/
        mail_type         char(2),   /*�H�����*/
        car_code2         char(3),   /*car140���ɤ��d��²�X*/
        resp_name_mail    char(20),  /*�Ĥ@�h�D��*/
        top_unit_mail     char(20)   /*�Ĥ@�h�D��*/
        )with no log;
        $create index mail_x1 on car208_mail (inventory_ncode);
        $create index mail_x2 on car208_mail (nissue);
        $create index mail_x3 on car208_mail (ideliver);
        $create index mail_x4 on car208_mail (cnt_lastday_char);
        $create index mail_x5 on car208_mail (mail_type);
        $create index mail_x6 on car208_mail (car_code2);
        $create index mail_x7 on car208_mail (resp_name_mail);
        $create index mail_x8 on car208_mail (top_unit_mail);

    }  
   /*���ͤ@�ӳ���*/
   if (cardclass[0]!='9' && cartype[0]!='9')
   {
        FileCnt = 1;
        sprintf_s(TitleFile[0], sizeof TitleFile[0], "%s.ti", outputf);
        sprintf_s(BodyFile[0], sizeof BodyFile[0], "%s.bd", outputf);
        printf("258 TitleFile[0]=[%s] \n", TitleFile[0]);
        printf("258 BODYFile[0]=[%s] \n", BodyFile[0]);
        if(cardclass[0] == '1' && cartype[0] == '1')
        {
             rgu_init_report( TitleFmt,TitleFile[0]);
             car208_title(COMP,CAR);
             rgu_finish_report();

             rgu_init_report( BodyFmt,BodyFile[0]);
             car208_branch(COMP,CAR) ;
             rgu_finish_report();
        }

        if(cardclass[0] == '1' && cartype[0] == '2')
        {
             rgu_init_report( TitleFmt,TitleFile[0]);
             car208_title(COMP,MOT);
             rgu_finish_report();

             rgu_init_report( BodyFmt,BodyFile[0]);
             car208_branch(COMP,MOT) ;
             rgu_finish_report();
        }

        if(cardclass[0] == '2' && cartype[0] == '1')
        {
             rgu_init_report( TitleFmt,TitleFile[0]);
             car208_title(CARD,CAR);
             rgu_finish_report();

             rgu_init_report( BodyFmt,BodyFile[0]);
             car208_branch(CARD,CAR) ;
             rgu_finish_report();
        }

        if(cardclass[0] == '2' && cartype[0] == '2')
        {
             rgu_init_report( TitleFmt,TitleFile[0]);
             car208_title(CARD,MOT);
             rgu_finish_report();

             rgu_init_report( BodyFmt,BodyFile[0]);
             car208_branch(CARD,MOT) ;
             rgu_finish_report();
        }
        max_count[0] = miy;
   }

   /*���ͨ�ӳ���*/
   if (cardclass[0] =='9' && cartype[0]!='9')
   {   FileCnt = 2;
       sprintf_s(TitleFile[0], sizeof TitleFile[0], "%sA.ti", outputf);
       sprintf_s(BodyFile[0], sizeof BodyFile[0], "%sA.bd", outputf);
       sprintf_s(TitleFile[1], sizeof TitleFile[1], "%sB.ti", outputf);
       sprintf_s(BodyFile[1], sizeof BodyFile[1], "%sB.bd", outputf);

       printf("306 TitleFile[0]=[%s] \n", TitleFile[0]);
       printf("306 BODYFile[0]=[%s] \n", BodyFile[0]);
       printf("308 TitleFile[1]=[%s] \n", TitleFile[1]);
       printf("308 BODYFile[1]=[%s] \n", BodyFile[1]);

       if( cartype[0] == '1')
       {
            rgu_init_report( TitleFmt,TitleFile[0]);
            car208_title(COMP,CAR);
            rgu_finish_report();

            rgu_init_report( BodyFmt,BodyFile[0]);
            car208_branch(COMP,CAR) ;
            rgu_finish_report();
            max_count[0] = miy;

            rgu_init_report( TitleFmt,TitleFile[1]);
            car208_title(CARD,CAR);
            rgu_finish_report();

            rgu_init_report( BodyFmt,BodyFile[1]);
            car208_branch(CARD,CAR) ;
            rgu_finish_report();
            max_count[1] = miy;
       }

       if( cartype[0] == '2')
       {
            rgu_init_report( TitleFmt,TitleFile[0]);
            car208_title(COMP,MOT);
            rgu_finish_report();

            rgu_init_report( BodyFmt,BodyFile[0]);
            car208_branch(COMP,MOT) ;
            rgu_finish_report();
            max_count[0] = miy;

            rgu_init_report( TitleFmt,TitleFile[1]);
            car208_title(CARD,MOT);
            rgu_finish_report();

            rgu_init_report( BodyFmt,BodyFile[1]);
            car208_branch(CARD,MOT) ;
            rgu_finish_report();
            max_count[1] = miy;
       }
   }

   if (cardclass[0] !='9' && cartype[0]=='9')
   {
       FileCnt = 2;
       sprintf_s(TitleFile[0], sizeof TitleFile[0], "%sA.ti", outputf);
       sprintf_s(BodyFile[0], sizeof BodyFile[0], "%sA.bd", outputf);
       sprintf_s(TitleFile[1], sizeof TitleFile[1], "%sB.ti", outputf);
       sprintf_s(BodyFile[1], sizeof BodyFile[1], "%sB.bd", outputf);
	
       printf("358 TitleFile[0]=[%s] \n", TitleFile[0]);
       printf("358 BODYFile[0]=[%s] \n", BodyFile[0]);
       printf("359 TitleFile[1]=[%s] \n", TitleFile[1]);
       printf("359 BODYFile[1]=[%s] \n", BodyFile[1]);
        
        if (strncmp(userid,"car208a",7) == 0)
        {
            /*1060821005-C5
            car208a �C��8.18.28��-�t�Φ۰ʵo�email
            �ӻ���
            �β��ʤ�����϶��A01/01/2015~�t�Τ�
            */
            
            strcpy(changbgn, cm_to_infdate(changbgn_char));
            strcpy(changend, cm_to_infdate(changend_char));
            printf("�Ƶ{[%s]\n",userid);
            strcpy(mail_type,"A");
        }
        
        if (strncmp(userid,"car208b",7) == 0)
        {
            /*1060821005-C5
            car208b �C��
            ���t�o���
            01/01/2015~ (�g��t�o��)=�t�Τ�-24��
          */
            strcpy(changbgn, cm_to_infdate(changbgn_char));
            
            lEndDay_car208b = cm_today() - 24;
            strcpy(changend , cm_edate_str(lEndDay_car208b));
            strcpy(changend_char, cm_from_infdate_100(changend));
            strcpy(delivend , changend);
            strcpy(delivend_char ,changend_char);
            strcpy(mail_type,"B");
            printf("�Ƶ{[%s]changbgn[%s]changend[%s]\ndelivbgn[%s]delivend[%s]\n",userid,changbgn,changend,delivbgn,delivend);
            
        }
        
        if (strncmp(userid,"car208c",7) == 0)
        {   
            FileCnt = 10;
            
            sprintf_s(TitleFile[2], sizeof TitleFile[2], "%sC.ti", outputf);
            sprintf_s(BodyFile[2], sizeof BodyFile[2], "%sC.bd", outputf);
            sprintf_s(TitleFile[3], sizeof TitleFile[3], "%sD.ti", outputf);
            sprintf_s(BodyFile[3], sizeof BodyFile[3], "%sD.bd", outputf);
            
            sprintf_s(TitleFile[4], sizeof TitleFile[4], "%sE.ti", outputf);
            sprintf_s(BodyFile[4], sizeof BodyFile[4], "%sE.bd", outputf);
            sprintf_s(TitleFile[5], sizeof TitleFile[5], "%sF.ti", outputf);
            sprintf_s(BodyFile[5], sizeof BodyFile[5], "%sF.bd", outputf);
            
            sprintf_s(TitleFile[6], sizeof TitleFile[6], "%sG.ti", outputf);
            sprintf_s(BodyFile[6], sizeof BodyFile[6], "%sG.bd", outputf);
            sprintf_s(TitleFile[7], sizeof TitleFile[7], "%sH.ti", outputf);
            sprintf_s(BodyFile[7], sizeof BodyFile[7], "%sH.bd", outputf);
            
            sprintf_s(TitleFile[8], sizeof TitleFile[8], "%sI.ti", outputf);
            sprintf_s(BodyFile[8], sizeof BodyFile[8], "%sI.bd", outputf);
            sprintf_s(TitleFile[9], sizeof TitleFile[9], "%sJ.ti", outputf);
            sprintf_s(BodyFile[9], sizeof BodyFile[9], "%sJ.bd", outputf);

            printf("�Ƶ{�H-car208c\n");

            strcpy(changbgn, cm_to_infdate(changbgn_char));
            strcpy(changend, cm_to_infdate(changend_char));
            strcpy(delivbgn, cm_to_infdate(delivbgn_char));
            strcpy(delivend, cm_to_infdate(delivend_char));            
            
            strcpy(mail_type,"C1");
            
            rgu_init_report( TitleFmt,TitleFile[0]);
            car208_title(COMP,CAR);
            rgu_finish_report();

            rgu_init_report( BodyFmt,BodyFile[0]);
            car208_branch(COMP,CAR) ;
            rgu_finish_report();
            max_count[0] = miy;

            rgu_init_report( TitleFmt,TitleFile[1]);
            car208_title(COMP,MOT);
            rgu_finish_report();

            rgu_init_report( BodyFmt,BodyFile[1]);
            car208_branch(COMP,MOT) ;
            rgu_finish_report();
            max_count[1] = miy;
            
            /* �C��2��t�Φ۰ʱH�o�j��O�I�ҽL�I���Ӥ��e�ܧ� mark by 061476 (1100825022_SC1) */          
            /*strcpy(mail_type,"C2");
            rgu_init_report( TitleFmt,TitleFile[2]);
            car208_title(COMP,CAR);
            rgu_finish_report();

            rgu_init_report( BodyFmt,BodyFile[2]);
            car208_branch(COMP,CAR) ;
            rgu_finish_report();
            max_count[2] = miy;

            rgu_init_report( TitleFmt,TitleFile[3]);
            car208_title(COMP,MOT);
            rgu_finish_report();

            rgu_init_report( BodyFmt,BodyFile[3]);
            car208_branch(COMP,MOT) ;
            rgu_finish_report();
            max_count[3] = miy;*/
            
            strcpy(mail_type,"C3");
            rgu_init_report( TitleFmt,TitleFile[4]);
            car208_title(COMP,CAR);
            rgu_finish_report();

            rgu_init_report( BodyFmt,BodyFile[4]);
            car208_branch(COMP,CAR) ;
            rgu_finish_report();
            max_count[4] = miy;

            rgu_init_report( TitleFmt,TitleFile[5]);
            car208_title(COMP,MOT);
            rgu_finish_report();

            rgu_init_report( BodyFmt,BodyFile[5]);
            car208_branch(COMP,MOT) ;
            rgu_finish_report();
            max_count[5] = miy;
                       
            /* �C��2��t�Φ۰ʱH�o�j��O�I�ҽL�I���Ӥ��e�ܧ� mark by 061476 (1100825022_SC1) */
            /*strcpy(mail_type,"C4");
            rgu_init_report( TitleFmt,TitleFile[6]);
            car208_title(COMP,CAR);
            rgu_finish_report();

            rgu_init_report( BodyFmt,BodyFile[6]);
            car208_branch(COMP,CAR) ;
            rgu_finish_report();
            max_count[6] = miy;

            rgu_init_report( TitleFmt,TitleFile[7]);
            car208_title(COMP,MOT);
            rgu_finish_report();

            rgu_init_report( BodyFmt,BodyFile[7]);
            car208_branch(COMP,MOT) ;
            rgu_finish_report();
            max_count[7] = miy;*/
            
            /*1080118003_SC1_���t�Φ۰ʱH�o�U���j��L�I�~�����^���Ӫ��������`���W�٧אּ�i�����ӻ�O�T�Ӥ�I��xx/xx/xxx��j
              �����~�������^���ӱH�e by 071004 2019.02.19 */
            /*
            strcpy(mail_type,"C5");
                     
            rgu_init_report( TitleFmt,TitleFile[8]);
            car208_title(COMP,CAR);
            rgu_finish_report();

            rgu_init_report( BodyFmt,BodyFile[8]);
            car208_branch(COMP,CAR) ;
            rgu_finish_report();
            max_count[8] = miy;

            rgu_init_report( TitleFmt,TitleFile[9]);
            car208_title(COMP,MOT);
            rgu_finish_report();

            rgu_init_report( BodyFmt,BodyFile[9]);
            car208_branch(COMP,MOT) ;
            rgu_finish_report();
            max_count[9] = miy;
            */
       }
       else if( cardclass[0] == '1')
       {
            rgu_init_report( TitleFmt,TitleFile[0]);
            car208_title(COMP,CAR);
            rgu_finish_report();

            rgu_init_report( BodyFmt,BodyFile[0]);
            car208_branch(COMP,CAR) ;
            rgu_finish_report();
            max_count[0] = miy;

            rgu_init_report( TitleFmt,TitleFile[1]);
            car208_title(COMP,MOT);
            rgu_finish_report();

            rgu_init_report( BodyFmt,BodyFile[1]);
            car208_branch(COMP,MOT) ;
            rgu_finish_report();
            max_count[1] = miy;
       }
       if( cardclass[0] == '2')
       {
            rgu_init_report( TitleFmt,TitleFile[0]);
            car208_title(CARD,CAR);
            rgu_finish_report();

            rgu_init_report( BodyFmt,BodyFile[0]);
            car208_branch(CARD,CAR) ;
            rgu_finish_report();
            max_count[0] = miy;

            rgu_init_report( TitleFmt,TitleFile[1]);
            car208_title(CARD,MOT);
            rgu_finish_report();

            rgu_init_report( BodyFmt,BodyFile[1]);
            car208_branch(CARD,MOT) ;
            rgu_finish_report();
            max_count[1] = miy;
       }
       if (strcmp(userid_6,"car208") == 0)  car208_mail();
   }
   /*���ͥ|������*/
   if (cardclass[0] =='9' && cartype[0]=='9')
   {
       FileCnt = 4;
       sprintf_s(TitleFile[0], sizeof TitleFile[0], "%sA.ti", outputf);
       sprintf_s(BodyFile[0], sizeof BodyFile[0], "%sA.bd", outputf);
       sprintf_s(TitleFile[1], sizeof TitleFile[1], "%sB.ti", outputf);
       sprintf_s(BodyFile[1], sizeof BodyFile[1], "%sB.bd", outputf);
       sprintf_s(TitleFile[2], sizeof TitleFile[2], "%sC.ti", outputf);
       sprintf_s(BodyFile[2], sizeof BodyFile[2], "%sC.bd", outputf);
       sprintf_s(TitleFile[3], sizeof TitleFile[3], "%sD.ti", outputf);
       sprintf_s(BodyFile[3], sizeof BodyFile[3], "%sD.bd", outputf);
       printf("413 outputf=[%s] \n",outputf);
       printf("414 TitleFile[0]=[%s] \n", TitleFile[0]);
       printf("414 BODYFile[0]=[%s] \n", BodyFile[0]);
       printf("415 TitleFile[1]=[%s] \n", TitleFile[1]);
       printf("415 BODYFile[1]=[%s] \n", BodyFile[1]);
       printf("416 TitleFile[2]=[%s] \n", TitleFile[2]);
       printf("416 BODYFile[2]=[%s] \n", BodyFile[2]);
       printf("417 TitleFile[3]=[%s] \n", TitleFile[3]);
       printf("417 BODYFile[3]=[%s] \n", BodyFile[3]);

       rgu_init_report( TitleFmt,TitleFile[0]);
       car208_title(COMP,CAR);
       rgu_finish_report();

       rgu_init_report( BodyFmt,BodyFile[0]);
       car208_branch(COMP,CAR) ;
       rgu_finish_report();
       max_count[0] = miy;

       rgu_init_report( TitleFmt,TitleFile[1]);
       car208_title(CARD,CAR);
       rgu_finish_report();

       rgu_init_report( BodyFmt,BodyFile[1]);
       car208_branch(CARD,CAR) ;
       rgu_finish_report();
       max_count[1] = miy;

       rgu_init_report( TitleFmt,TitleFile[2]);
       car208_title(COMP,MOT);
       rgu_finish_report();

       rgu_init_report( BodyFmt,BodyFile[2]);
       car208_branch(COMP,MOT) ;
       rgu_finish_report();
       max_count[2] = miy;

       rgu_init_report( TitleFmt,TitleFile[3]);
       car208_title(CARD,MOT);
       rgu_finish_report();

       rgu_init_report( BodyFmt,BodyFile[3]);
       car208_branch(CARD,MOT) ;
       rgu_finish_report();
       max_count[3] = miy;
   }
   return M_CM_OK;
}

/*----------------------------------------------------------------------------*/
void car208_title(pFlag,qFlag)
int pFlag,qFlag;
{
   /***
   printf(" 465 pFlag=[%d],qFlag=[%d] \n",pFlag,qFlag);
   ****/
   if(pFlag == COMP)
   {
       if(qFlag == CAR)
           rgu_put_head_string(1, "�j��-�T��");
       if(qFlag == MOT)
           rgu_put_head_string(1, "�j��-����");
   }
    
   if(pFlag == CARD)
   {
       if(qFlag == CAR)
           rgu_put_head_string(1, "���N-�T��");
       if(qFlag == MOT)
           rgu_put_head_string(1, "���N-����");
   }

   if(choice[0]=='1')
       strcpy(strA,"ñ����");
   else if(choice[0]=='2')
       strcpy(strA,"���I��Τ��");
   else if(choice[0]=='3')
       strcpy(strA,"�}�ҥd���");
   else if(choice[0]=='4')
       strcpy(strA,"���ʤ��");
   else if(choice[0]=='5')
       strcpy(strA,"ñ��ζ}�ҥd���");

   rgu_put_head_string(1, cm_sysd_cdate_100(cm_get_sysd()));
   rgu_put_head_string(1, strA);
   rgu_put_head_string(1, yy1);
   rgu_put_head_string(1, mm1);
   rgu_put_head_string(1, dd1);
   rgu_put_head_string(1, yy2);
   rgu_put_head_string(1, mm2);
   rgu_put_head_string(1, dd2);
   rgu_put_head();
}

/*----------------------------------------------------------------------------*/
void car208_grp(cardyear)
char *cardyear;
{
   if( first != 1)
     { rgu_put_body(NEXTPAGE);   miy++; }
   else first = 0;

   rgu_put_body_string(1, cardyear,1);
   rgu_put_body(1);   miy++;

   strcpy( BrkIcardyear, "   ");
   strcpy( BrkIofficer,"          ");
}
/*----------------------------------------------------------------------------*/
void car208_grp1(cardyear)
char *cardyear;
{
   /*if( first != 1)
     { rgu_put_body(NEXTPAGE);   miy++; }
   else first = 0;*/

   rgu_put_body_string(1, cardyear,1);
   rgu_put_body(1);   miy++;

   strcpy( BrkIcardyear, "   ");
   strcpy( BrkIofficer,"          ");
}

/*----------------------------------------------------------------------------*/
void car208_body(pFlag,qFlag)
int pFlag,qFlag;
{
   $char buf1[10], buf2[10], buf3[10], buf4[10];
   $char nname[11], ileader[11], sIdeliver[11], sIalter[11];
   /***
   printf(" 521 pFlag=[%d],qFlag=[%d] \n",pFlag,qFlag);
   ****/
   strcpy(buf1, cm_from_infdate_100(ZDissue));
   strcpy(buf2, cm_from_infdate_100(ZDdeliver));
   strcpy(buf3, cm_from_infdate_100(ZDreceive));
   strcpy(buf4, cm_from_infdate_100(zdalter));
   $select a.nname, b.nname, a.ileader 
      into $sIdeliver, $nname, $ileader
      from officer a, officer b
     where a.ileader = b.iofficer
       and a.iofficer = $ZIdeliver; 

   if( SQLCODE == SQLNOTFOUND)
   {
       strcpy( nname, " ");
       strcpy( ileader, " ");
       strcpy( sIdeliver," ");
   }
   
   
   $select nname,ibranch
      into $sIalter,$sIbranch
      from officer
     where iofficer = $ZIalter;
   if( SQLCODE == SQLNOTFOUND) 
   {
   	 strcpy(sIalter," ");
   	 strcpy(sIbranch," ");
   }
   
   $SELECT nchi_full[1,10] INTO $sIissue_bh
      FROM branch
     WHERE ibranch = $sIbranch;
   if (SQLCODE == SQLNOTFOUND) strcpy(sIissue_bh," ");
   
   if (pFlag == COMP)
   {  
      
   	  rgu_put_body_string( 2,inventory_nbranch,1);   /*�L�I���*/
      rgu_put_body_string( 2,ZIissue_bh,1);         /*�ӻ���*/
      rgu_put_body_string( 2,ZIcard,1);             /*�O�I����*/
      rgu_put_body_string( 2,buf1,1);               /*�ӻ��*/
      rgu_put_body_string( 2,ZIofficer,1);          /*�ӻ�H*/
      rgu_put_body_string( 2,buf3,1);               /*�������*/
      rgu_put_body_string( 2,ZIcar_type,1);         /*����*/
      rgu_put_body_string( 2,ZFstatus_char,1);      /*���ʪ��A*/
      rgu_put_body_string( 2,ZIpolicy,1);           /*�O�渹�X*/
      rgu_put_body_string( 2,ZIdeliver_nbranch,1);   /*�t�o�g��H���*/
      rgu_put_body_string( 2,ZIdeliver,1);          /*�t�o�g��H*/
      rgu_put_body_string( 2,sIdeliver,1);          /*�g��H*/
      rgu_put_body_string( 2,nname,1);              /*�t�o�g��H�̷s�޲z�H*/
      rgu_put_body_string( 2,ileader,1);            /*�t�o�g��H�̷s�޲z�H�N��*/
      rgu_put_body_string( 2,buf2,1);               /*�t�o���*/
      rgu_put_body_string( 2,buf4,1);               /*���ʤ��*/
      rgu_put_body_string( 2,ZIalter,1);            /*���ʤH�N��*/
      rgu_put_body_string( 2,sIalter,1);            /*���ʤH��*/
      rgu_put_body_string( 2,sIissue_bh,1);         /*���ʤH�����*/
      rgu_put_body_string( 2,sIend_type,1);         /*���O*/
      rgu_put_body_string( 2,ZQreprint_char,2);     /*�ɦL����*/
      rgu_put_body_string( 2,ZDentry,2);            /*�����ʲz����J���*/
      rgu_put_body_string( 2,Zddeliver_old_100,1);
      rgu_put_body_string( 2,Zfin_out_char,1);
      rgu_put_body_string( 2,limit_date_100,1);
      rgu_put_body_string( 2,cnt_lastday_char,1);
      rgu_put_body( 2);   miy++;
        

    if (strcmp(userid_6,"car208") == 0)
    {   
   
   $INSERT INTO car208_mail 
       (inventory_nbranch , issue_bh     , icard             , dissue            , nissue            ,
        dreceive          , icar_type    , fstatus           , ipolicy           , sIdeliver_nbranch ,
        ideliver          , ndeliver     , nleader           , ileader           , ddeliver          ,
        dalter            , ialter       , nalter            , bh_ialter         , iend_type         ,
        reprint_char      , road_dentry  , sDdeliver_old_100 , sFin_out_char     , limit_date_100    ,
        cnt_lastday_char  , mail_type    , inventory_ncode)
        VALUES (
        $inventory_nbranch,$ZIissue_bh,   $ZIcard,            $buf1,              $ZIofficer,         
        $buf3,             $ZIcar_type,   $ZFstatus_char,     $ZIpolicy,          $ZIdeliver_nbranch, 
        $ZIdeliver,        $sIdeliver,    $nname,             $ileader,           $buf2,              
        $buf4,             $ZIalter,      $sIalter,           $sIissue_bh,        $sIend_type,        
        $ZQreprint_char,   $ZDentry,      $Zddeliver_old_100, $Zfin_out_char,     $limit_date_100,
        $cnt_lastday_char, $mail_type,    $inventory_ncode);
        
    }
    
       
   }else{
      rgu_put_body_string( 5,inventory_nbranch,1);
      rgu_put_body_string( 5,ZIissue_bh,1);
      rgu_put_body_string( 5,ZIcard,1);
      rgu_put_body_string( 5,buf1,1);
      rgu_put_body_string( 5,ZIofficer,1);
      rgu_put_body_string( 5,buf3,1);
      rgu_put_body_string( 5,ZIcar_type,1);
      rgu_put_body_string( 5,ZFstatus_char,1);
      rgu_put_body_string( 5,ZIpolicy,1);
      rgu_put_body_string( 5,ZIdeliver_nbranch,1);
      rgu_put_body_string( 5,ZIdeliver,1);
      rgu_put_body_string( 5,sIdeliver,1);          /*�g��H*/
      rgu_put_body_string( 5,nname,1);              /*�t�o�g��H�̷s�޲z�H*/
      rgu_put_body_string( 5,ileader,1);            /*�t�o�g��H�̷s�޲z�H�N��*/
      rgu_put_body_string( 5,buf2,1);
      rgu_put_body_string( 5,buf4,1);
      rgu_put_body_string( 5,ZIalter,1);            /*���ʤH�N��*/
      rgu_put_body_string( 5,sIalter,1);            /*���ʤH��*/
      rgu_put_body_string( 5,sIissue_bh,1);         /*���ʤH�����*/
      rgu_put_body_string( 5,sIend_type,1);         /*���O*/
      rgu_put_body( 5);   miy++;
   }
}

/*----------------------------------------------------------------------------*/
void car208_brk(pFlag,qFlag)
int pFlag,qFlag;
{
   char  BrkCount_char[11], BrkSubTotal_char[11];
   /****
   printf(" 558 pFlag=[%d],qFlag=[%d] \n",pFlag,qFlag);
   ****/
   if( BrkCount >0) {
      if( pFlag == COMP) {

         rgu_put_body( 4);   miy++;
         sprintf_s(BrkCount_char, sizeof BrkCount_char,"%d",BrkCount);
         rgu_put_body_string( 3,BrkCount_char,2);
         rgu_put_body( 3);   miy++;
         rgu_put_body( 4);   miy++;
      }else{
         rgu_put_body( 4);   miy++;
         sprintf_s(BrkCount_char, sizeof BrkCount_char,"%d",BrkCount);
          rgu_put_body_string( 6,BrkCount_char,2);
         rgu_put_body( 6);   miy++;
         rgu_put_body( 4);   miy++;
      }
      strcpy( BrkFstatus, " ");  BrkCount= BrkSubTotal= 0;
   }
}

/*-----------------------------------------------------------------------*/
long car208_branch(pFlag,qFlag)
int pFlag,qFlag;
{
      $char stmt_buf[5096], tmp_buf[512], table_name[15];

      miy= 0; first= 1;

      $WHENEVER SQLERROR GOTO errexit;
      strcpy(FullDBName,get_full_dbname(DBName));
      printf("*******614 fulldbname[%s]\n",FullDBName);

      strcpy( BrkIcardyear, "   ");
      strcpy( BrkIofficer,"          ");
      strcpy( BrkFstatus, " ");
      BrkCount= BrkSubTotal= 0;
      flag_brk = 1;

      /**** prepare cursor ****/
      if (dptbgn[0]!='*' && dptend[0]!='*')
      {
      	if (choice1[0] == '2' || choice1[0] == '3')
      		 strcpy(table_name,",officer b ");
      	else
      		 strcpy(table_name,"");
      }
      else
      {
      	   strcpy(table_name,"");
      }
      
      /***********************�j�� ******************************/     
       sprintf_s(stmt_buf, sizeof stmt_buf,
             "SELECT a.icard, a.dissue, a.icar_type, a.qperiod, fstatus, a.dalter, "
                    " a.ipolicy, a.ideliver, a.ddeliver, a.dreceive, a.qreprint,  "
                    " a.icardyear, a.ioffice, a.iofficer, a.iissue_branch, a.ialter, a.ddeliver_old, a.fin_out  "
                "FROM %s:compulsory_card a %s ",
                     FullDBName, table_name);
        /* car208c �C��2�� �O�I�ҽL�I����
           �j���ҽL�I�ӻ����(�O�T�Ӥ�)����
                C1�ӻ����϶��A01/01/2015~(�t�Τ餧���-4)���멳              9.����        ���A0�B5�B6�B7
        �i�����jC2�ӻ����϶��A(�t�Τ餧���-5)�����~(�t�Τ餧���-4)���멳  9.����        ���A7
            �j���ҽL�I�ӻ����(�O�@�~)����  
                C3�ӻ����϶��A01/01/2015~~(�t�Τ餧���-13)���멳            9.����        ���A0�B5�B6�B7
        �i�����jC4�ӻ����϶��A01/01/2015~~(�t�Τ餧���-6)���멳             1.�����q��    ���A0
            �~�����^-�w�t�o���P��
        �i�����jC5���t�o�β��ʤ������϶��A01/01/2015~(�t�Τ餧���)���멳  2.�~��        ���A0  
       */
       /* �վ��^������ modify by 061476 (1100825022_SC1) */
      if (strncmp(userid,"car208a",7) == 0)
         sprintf_s(tmp_buf, sizeof tmp_buf,"WHERE ((a.dissue BETWEEN '%s' AND '%s') or (a.dalter BETWEEN '%s' AND '%s')) ",
                         issdtbgn,issdtend,changbgn,changend);
      else if (strncmp(userid,"car208b",7) == 0)
         sprintf_s(tmp_buf, sizeof tmp_buf,"WHERE ((a.ddeliver_old BETWEEN '%s' AND '%s') ) ",
                         delivbgn,delivend,changbgn,changend);
      else if (strncmp(userid,"car208c",7) == 0)
      {
            printf("mail_type[%s]\n",mail_type);
            
            if (strncmp(mail_type,"C1",2) == 0)
            {
               /*sprintf_s(tmp_buf, sizeof tmp_buf,"WHERE ((a.dissue >= '%s' AND a.dissue < MDY(MONTH('%s'),1,YEAR('%s'))  -3 UNITS MONTH) "
                                  " or (a.dalter >= '%s' AND a.dalter < MDY(MONTH('%s'),1,YEAR('%s'))  -3 UNITS MONTH)) "
                               ,issdtbgn,issdtend,issdtend,changbgn,changend,changend);*/
               sprintf_s(tmp_buf, sizeof tmp_buf,"WHERE a.dissue >= '%s' AND a.dissue < MDY(MONTH('%s'),1,YEAR('%s'))  -3 UNITS MONTH "
                               ,issdtbgn,issdtend,issdtend);
            }
            else if (strncmp(mail_type,"C2",2) == 0)
            {
              sprintf_s(tmp_buf, sizeof tmp_buf,"WHERE a.dissue >= MDY(MONTH('%s'),1,YEAR('%s')) -5 UNITS MONTH "
                               " AND a.dissue  < MDY(MONTH('%s'),1,YEAR('%s')) -3 UNITS MONTH "
                                                ,issdtend,issdtend,issdtend,issdtend);
            }
            else if (strncmp(mail_type,"C3",2) == 0)
            {
              sprintf_s(tmp_buf, sizeof tmp_buf,"WHERE a.dissue >= '%s' "
                               " AND a.dissue  < MDY(MONTH('%s'),1,YEAR('%s')) -12 UNITS MONTH "
                                                ,issdtbgn,issdtend,issdtend);
            }
            else if (strncmp(mail_type,"C4",2) == 0)
            {
              sprintf_s(tmp_buf, sizeof tmp_buf,"WHERE a.dissue >= '%s' "
                               " AND a.dissue  < MDY(MONTH('%s'),1,YEAR('%s')) -5 UNITS MONTH "
                                                ,issdtbgn,issdtend,issdtend);
            }
            else if (strncmp(mail_type,"C5",2) == 0)
            {
              sprintf_s(tmp_buf, sizeof tmp_buf,"WHERE ((a.ddeliver_old >= '%s' "
                                  "AND a.ddeliver_old  < MDY(MONTH('%s'),1,YEAR('%s')) +1 UNITS MONTH) "
                                  "or (a.dalter >= '%s' "
                                  "AND a.dalter  < MDY(MONTH('%s'),1,YEAR('%s')) +1 UNITS MONTH)) ",
                               delivbgn,delivend,delivend,changbgn,changend,changend);
            }
      }
      else if (choice[0]=='1')
         sprintf_s(tmp_buf, sizeof tmp_buf,"WHERE a.dissue BETWEEN '%s' AND '%s' ",issdtbgn,issdtend);
      else if (choice[0]=='2')
         sprintf_s(tmp_buf, sizeof tmp_buf,"WHERE a.dreceive BETWEEN '%s' AND '%s' ",alterbgn,alterend);
      else if (choice[0]=='3')
         sprintf_s(tmp_buf, sizeof tmp_buf,"WHERE a.ddeliver_old BETWEEN '%s' AND '%s' ",delivbgn,delivend);
      else if (choice[0]=='4')
         sprintf_s(tmp_buf, sizeof tmp_buf,"WHERE a.dalter BETWEEN '%s' AND '%s' ",changbgn,changend);
      else if (choice[0]=='5')
         sprintf_s(tmp_buf, sizeof tmp_buf,"WHERE a.dissue BETWEEN '%s' AND '%s'  "
                            "AND (a.ddeliver_old BETWEEN '%s' AND '%s'  "
                            " OR a.ddeliver_old is null) ",issdtbgn,issdtend,delivbgn,delivend);
      strcat(stmt_buf,tmp_buf);
      
      strcpy(sKbill_code,trim(sKbill_code));
      if (strlen(sKbill_code) != 0)
      {
      	sprintf_s(tmp_buf, sizeof tmp_buf,"AND a.icard[3,4] = '%s' ",sKbill_code);
        strcat(stmt_buf,tmp_buf);
      }

      if (dptbgn[0]!='*' && dptend[0]!='*')
      {
      	if (choice1[0] == '1')      		
           sprintf_s(tmp_buf, sizeof tmp_buf,"AND a.iissue_branch BETWEEN '%s' AND '%s' ",dptbgn,dptend);
        else if (choice1[0] == '2')
        	 sprintf_s(tmp_buf, sizeof tmp_buf,"AND a.ideliver = b.iofficer  "
        	                "  AND b.ibranch BETWEEN '%s' AND '%s' ",dptbgn,dptend);
        else
        	 sprintf_s(tmp_buf, sizeof tmp_buf,"AND a.ialter = b.iofficer  "
        	                "  AND b.ibranch BETWEEN '%s' AND '%s' ",dptbgn,dptend);
        	                                    
        strcat(stmt_buf,tmp_buf);
      }

      sprintf_s(tmp_buf, sizeof tmp_buf,"AND a.iquota matches '%s' ",iquota);
      strcat(stmt_buf,tmp_buf);

      if (officerbgn[0]!='*' && officerend[0]!='*')
      {
        sprintf_s(tmp_buf, sizeof tmp_buf,"AND a.iofficer BETWEEN '%s' AND '%s' ",officerbgn,officerend);
        strcat(stmt_buf,tmp_buf);
      }

      if (ideliverbgn[0]!='*' && ideliverend[0]!='*')
      {
        sprintf_s(tmp_buf, sizeof tmp_buf,"AND a.ideliver BETWEEN '%s' AND '%s' ",ideliverbgn,ideliverend);
        strcat(stmt_buf,tmp_buf);
      }

      if (card1[0]!='*' && card2[0]!='*')
      {
        sprintf_s(tmp_buf, sizeof tmp_buf,"AND a.icard BETWEEN '%s' AND '%s' ",card1,card2);
        strcat(stmt_buf,tmp_buf);
      }
   
        if (strncmp(userid,"car208c",7) == 0)
        {
            if (strncmp(mail_type,"C1",2) == 0)
            {
                /*strcat(stmt_buf,"AND a.fin_out in ('1') ");*/
                strcat(stmt_buf," AND a.fstatus in ('0','5','6','7') ");
            }
            else if (strncmp(mail_type,"C2",2) == 0)
            {
                strcat(stmt_buf," AND a.fstatus in ('7') ");
            }
            else if (strncmp(mail_type,"C3",2) == 0)
            {
                strcat(stmt_buf," AND a.fstatus in ('0','5','6','7') ");
            }
            else if (strncmp(mail_type,"C4",2) == 0)
            {
                strcat(stmt_buf," AND a.fin_out in ('1') ");
                strcat(stmt_buf," AND a.fstatus in ('0','5','6') ");
            }
            else if (strncmp(mail_type,"C5",2) == 0)
            {
                strcat(stmt_buf," AND a.fin_out in ('2') ");
                strcat(stmt_buf," AND a.fstatus in ('0','5','6') ");
            }
        }
        else
        {
          if (fin_out[0] == '8')
          {
            strcat(tmp_buf,"AND a.fin_out in ('1','2') ");
          }
          else if(fin_out[0] == '9')
          {
            strcat(tmp_buf," ");
          }
          else 
          {
            sprintf_s(tmp_buf, sizeof tmp_buf,"AND a.fin_out = '%s' ",fin_out);
            strcat(stmt_buf,tmp_buf);
          }

          if (cardstatus1[0]!='9' )
          {
            if (cardstatus1[0] == '0') 
            {
                strcat(stmt_buf," AND a.fstatus in ('0','5','6') ");
            }
            else if (cardstatus1[0] == 'Y') 
            {
                strcat(stmt_buf," AND a.fstatus in ('0','5','6','7') ");
            }
            else if (cardstatus1[0] == 'Z')
            {
                strcat(stmt_buf," AND a.fstatus in ('A','B','C','D','E','8','3') ");
            }
            else
            {
              sprintf_s(tmp_buf, sizeof tmp_buf,"AND a.fstatus = '%s' ",cardstatus1);
              strcat(stmt_buf,tmp_buf);
            }
          }
          else
          {
          	strcat(stmt_buf," AND a.fstatus NOT in ('F') ");
          	
          }
        }
      if( sfrflag[0]=='Y')
        strcat(stmt_buf," ORDER BY a.iofficer,a.icard");
      else
        strcat(stmt_buf," ORDER BY a.icardyear,a.icard");

      printf("711SQL QUERY STATEMENT-->%s\n\n",stmt_buf);
      $PREPARE CUR_STMT1 FROM $stmt_buf;
      $DECLARE Acursor1 CURSOR FOR CUR_STMT1;
      
      /*************************���N***************************/
      sprintf_s(stmt_buf, sizeof stmt_buf,"SELECT %s %s FROM %s:%s %s",
                              "a.icard,a.dissue,a.icar_type,a.fstatus,a.dalter,a.ipolicy,a.ideliver, ",
                              "a.ddeliver,a.dreceive,a.icardyear,a.ioffice,a.iofficer,a.iissue_branch,a.ialter ",
                              FullDBName,"card a",table_name);

      if (choice[0]=='1')
         sprintf_s(tmp_buf, sizeof tmp_buf,"WHERE a.dissue BETWEEN '%s' AND '%s' ",issdtbgn,issdtend);
      else if (choice[0]=='2')
         sprintf_s(tmp_buf, sizeof tmp_buf,"WHERE a.dreceive BETWEEN '%s' AND '%s' ",alterbgn,alterend);
      else if (choice[0]=='3')
         sprintf_s(tmp_buf, sizeof tmp_buf,"WHERE a.ddeliver BETWEEN '%s' AND '%s' ",delivbgn,delivend);
      else if (choice[0]=='4')
         sprintf_s(tmp_buf, sizeof tmp_buf,"WHERE a.dalter BETWEEN '%s' AND '%s' ",changbgn,changend);
      else if (choice[0]=='5')
         sprintf_s(tmp_buf, sizeof tmp_buf,"WHERE a.dissue BETWEEN '%s' AND '%s'  "
                            "AND (a.ddeliver BETWEEN '%s' AND '%s'  "
                            " OR a.ddeliver is null) ",issdtbgn,issdtend,delivbgn,delivend);
      strcat(stmt_buf,tmp_buf);

      if (dptbgn[0]!='*' && dptend[0]!='*')
      {
        if (choice1[0] == '1')      		
           sprintf_s(tmp_buf, sizeof tmp_buf,"AND a.iissue_branch BETWEEN '%s' AND '%s' ",dptbgn,dptend);
        else if (choice1[0] == '2')
        	 sprintf_s(tmp_buf, sizeof tmp_buf,"AND a.ideliver = b.iofficer  "
        	                "  AND b.ibranch BETWEEN '%s' AND '%s' ",dptbgn,dptend);
        else
        	 sprintf_s(tmp_buf, sizeof tmp_buf,"AND a.ialter = b.iofficer   "
        	                "  AND b.ibranch BETWEEN '%s' AND '%s' ",dptbgn,dptend);
        	                                    
        strcat(stmt_buf,tmp_buf);
      }

      sprintf_s(tmp_buf, sizeof tmp_buf,"AND a.iquota matches '%s' ",iquota);
      strcat(stmt_buf,tmp_buf);

      if (officerbgn[0]!='*' && officerend[0]!='*')
      {
        sprintf_s(tmp_buf, sizeof tmp_buf,"AND a.iofficer BETWEEN '%s' AND '%s' ",officerbgn,officerend);
        strcat(stmt_buf,tmp_buf);
      }

      if (ideliverbgn[0]!='*' && ideliverend[0]!='*')
      {
        sprintf_s(tmp_buf, sizeof tmp_buf,"AND a.ideliver BETWEEN '%s' AND '%s' ",ideliverbgn,ideliverend);
        strcat(stmt_buf,tmp_buf);
      }

      if (card1[0]!='*' && card2[0]!='*')
      {
        sprintf_s(tmp_buf, sizeof tmp_buf,"AND a.icard BETWEEN '%s' AND '%s' ",card1,card2);
        strcat(stmt_buf,tmp_buf);
      }

      if (cardstatus1[0]!='9')
      {
       /*sprintf_s(tmp_buf, sizeof tmp_buf,"AND a.fstatus = '%s'",cardstatus1);
       strcat(stmt_buf,tmp_buf);*/
        if (cardstatus1[0] == '0') 
      	{
      		strcat(stmt_buf," AND a.fstatus in ('0','5','6') ");
      	}
        else if (cardstatus1[0] == 'Y') 
      	{
      		strcat(stmt_buf," AND a.fstatus in ('0','5','6','7') ");
      	}
      	else if (cardstatus1[0] == 'Z')
      	{
      		strcat(stmt_buf," AND a.fstatus in ('A','B','C','D','E','8','3') ");
      	}
      	else
      	{
          sprintf_s(tmp_buf, sizeof tmp_buf,"AND a.fstatus = '%s' ",cardstatus1);
          strcat(stmt_buf,tmp_buf);
        }
      }
      else
      {
          strcat(stmt_buf," AND a.fstatus NOT in ('F') ");
          	
      }

      if( sfrflag[0]=='Y')
        strcat(stmt_buf," ORDER BY a.iofficer,a.icard");
      else
        strcat(stmt_buf," ORDER BY a.icardyear,a.icard");

      printf("769-->%s\n\n",stmt_buf);
      $PREPARE CUR_STMT3 FROM $stmt_buf;
      $DECLARE Acursor3 CURSOR FOR CUR_STMT3;
      printf(" 707 pFlag=[%d],qFlag=[%d] \n",pFlag,qFlag);
      
      car208_data(pFlag,qFlag);
      $WHENEVER SQLERROR CONTINUE;
      return 0;
errexit:
   printf("ERROR:%d\n",SQLCODE);
   EWRITE(userid,0,"CURSOR ERROR !!");
   return;
}
/*----------------------------------------------------------------------------*/
long car208_data(pFlag,qFlag)
int pFlag,qFlag;
{
   int officer_int,int_bgn,int_end;
   $char Full_DBName[40],sStmt[512];
   $int  sCover;

   if(officerbgn[0]!='*')
   {
      int_bgn=atoi(officerbgn);
      int_end=atoi(officerend);
   }
   /****
   printf(" 729 pFlag=[%d],qFlag=[%d] \n",pFlag,qFlag);
   ****/
   $ WHENEVER SQLERROR GOTO errexit;
   if (pFlag == COMP)
          {printf("!!!! FETCH Acursor1 !!!!\n"); $OPEN Acursor1;}
   else if (pFlag == CARD)
          {printf("!!!! FETCH Acursor3 !!!!\n"); $OPEN Acursor3;}
   
   printf("!!! start FECTHING !!!!!\n");
   while( 1)
   {
      if (pFlag == COMP)
      {
         /****
         printf("->Cursor1\n");
         ****/
         $FETCH Acursor1
           INTO $ZIcard, $ZDissue, $ZIcar_type, $ZQperiod, $ZFstatus, $zdalter,
                $ZIpolicy, $ZIdeliver, $ZDdeliver, $ZDreceive, $ZQreprint,
                $ZIcardyear, $ZIoffice, $ZIofficer, $ZIiss_b, $ZIalter, $Zddeliver_old, $Zfin_out;
         if( SQLCODE == SQLNOTFOUND) break;

      }
      else if (pFlag == CARD)
      {
         $FETCH Acursor3
           INTO $ZIcard, $ZDissue, $ZIcar_type,  $ZFstatus, $zdalter, $ZIpolicy, $ZIdeliver,
                $ZDdeliver, $ZDreceive, $ZIcardyear, $ZIoffice, $ZIofficer, $ZIiss_b, $ZIalter;
         /******
         printf("SQLCODE:%d\n",SQLCODE);
         ******/
         if( SQLCODE == SQLNOTFOUND) break;
      }
      strcpy(ZIcardyear,trim(ZIcardyear));

      if(qFlag == CAR)
      {
         if(strncmp(ZIcar_type,"01",2)==0 || strncmp(ZIcar_type,"02",2)==0 ||
            strncmp(ZIcar_type,"32",2)==0 || strncmp(ZIcar_type,"34",2)==0 || strncmp(ZIcar_type,"35",2)==0)
            continue;
      }
      else if(qFlag == MOT)
      {
         if(strncmp(ZIcar_type,"01",2)!=0 && strncmp(ZIcar_type,"02",2)!=0 &&
            strncmp(ZIcar_type,"32",2)!=0 && strncmp(ZIcar_type,"34",2)!=0 && strncmp(ZIcar_type,"35",2)!=0)
            continue;
      }
      
      if(ZDdeliver[0] == '')
      {
	      $SELECT nchi_full,ibranch INTO $inventory_nbranch,$inventory_ncode
	         FROM branch 
            WHERE ibranch = (SELECT iply_branch 
                               FROM sa_branch_type 
                              WHERE ibranch = (SELECT iquota FROM officer WHERE iofficer = $ZIofficer));
            if (SQLCODE == SQLNOTFOUND)
            {          
                strcpy(inventory_nbranch," ");
                strcpy(inventory_ncode," ");
            }
	      
      }
      else
      {
	      $SELECT nchi_full,ibranch INTO $inventory_nbranch,$inventory_ncode
	         FROM branch 
            WHERE ibranch = (SELECT iply_branch 
                               FROM sa_branch_type 
                              WHERE ibranch = (SELECT iquota FROM officer WHERE iofficer = $ZIdeliver));
            if (SQLCODE == SQLNOTFOUND)
            {          
                strcpy(inventory_nbranch," ");
                strcpy(inventory_ncode," ");
            }
      }

      $SELECT nchi_full INTO $ZIissue_bh
         FROM branch
        WHERE ibranch = $ZIiss_b;
      if (SQLCODE == SQLNOTFOUND) strcpy(ZIissue_bh," ");
      
      /*�����ʲz����J���*/
      $SELECT first 1 dentry INTO $ZDentry
         FROM ca_card_road
        WHERE icard = $ZIcard;
      if (SQLCODE == SQLNOTFOUND) strcpy(ZDentry," ");

      if (pFlag == COMP)
      {
         if (ZQreprint < 0) ZQreprint=0;
      }
      else if (pFlag == CARD)
      {
          /*printf("*********card[%s] fstatus[%s]\n",ZIcard,ZFstatus); */
      }
      /*****
      printf("sfrflag:%c\n",sfrflag[0]);
      ******/
      if( sfrflag[0]=='Y')
      {
          if( strcmp( BrkIofficer, ZIofficer) != 0)
          { /* skip page group */
               car208_brk(pFlag,qFlag);
               car208_grp(ZIcardyear);
          }
      }
      else
      {
          if( strcmp( BrkIcardyear, ZIcardyear) != 0)
          { /* skip page group */
               car208_brk(pFlag,qFlag);
               car208_grp(ZIcardyear);
          }
      }

      strcpy( BrkIofficer,ZIofficer);
      strcpy( BrkIcardyear, ZIcardyear);

      if(pFlag == COMP) {
           sprintf_s(ZQreprint_char, sizeof ZQreprint_char,"%2d",ZQreprint);
      }
      strcpy(ZFstatus,trim(ZFstatus)); 
      if (ZFstatus[0]=='0')
          strcpy(ZFstatus_char,"���X");
      if (ZFstatus[0]=='1')
          strcpy(ZFstatus_char,"�P��");
      if (ZFstatus[0]=='2')
          strcpy(ZFstatus_char,"�L��");
      if (ZFstatus[0]=='3')
          strcpy(ZFstatus_char,"�@�o");
      if (ZFstatus[0]=='4')
          strcpy(ZFstatus_char,"��");
      if (ZFstatus[0]=='5')
          strcpy(ZFstatus_char,"�@�o�ܥ��X");
      if (ZFstatus[0]=='6')
          strcpy(ZFstatus_char,"���ܥ��X");
      if ((ZFstatus[0]=='7') && (ZDreceive[0]!='') && (ZDreceive[0]!= '\0'))
          strcpy(ZFstatus_char,"�t�o��");
      if ((ZFstatus[0]=='7') && ((ZDreceive[0]=='') || (ZDreceive[0]== '\0')))
                  strcpy(ZFstatus_char,"�����");
      if (ZFstatus[0]=='8')
          strcpy(ZFstatus_char,"������");
      if (ZFstatus[0]=='A')
          strcpy(ZFstatus_char,"µ�����~");
      if (ZFstatus[0]=='B')
          strcpy(ZFstatus_char,"���Ƨ�O");
      if (ZFstatus[0]=='C')
          strcpy(ZFstatus_char,"�ܺʲz����ӥ��L");
      if (ZFstatus[0]=='D')
          strcpy(ZFstatus_char,"���ϥΤ��@�o");
      if (ZFstatus[0]=='E')
          strcpy(ZFstatus_char,"���l");
      BrkCount += 1;
      
      $SELECT fstatus INTO $iFstatus
         FROM policy_new
        WHERE itarget2 = $ZIcard;
      if (SQLCODE == SQLNOTFOUND) strcpy(iFstatus," ");
      		
      if (strncmp(iFstatus,"C",1) == 0){
        strcpy(sIend_type,"���P");}
      else if (strncmp(iFstatus,"D",1) == 0){
        strcpy(sIend_type,"�h�O");}
      else{
      	/* �P�_�O�B�ۥ[��0 - �h�O */
      	strcpy(ZIpolicy,trim(ZIpolicy));
      	if (strlen(ZIpolicy) != 0) {	           	
        strcpy(Full_DBName,get_car_full_db(ZIpolicy));
        sprintf_s(sStmt, sizeof sStmt,"SELECT sum(minjured_cover+mdeath_cover+mdamage_cover)  "
            	          " FROM %s:ply_ins_type  "
            	          "WHERE ipolicy = '%s' ",Full_DBName,ZIpolicy);
        $PREPARE ply_ins FROM $sStmt;
	      $DECLARE total_cur CURSOR FOR ply_ins;
	      $OPEN    total_cur;
        $FETCH   total_cur INTO $sCover;
        $CLOSE   total_cur;
	      $FREE    total_cur;   
	      
        if (sCover > 0)            
           strcpy(sIend_type," ");
        else
           strcpy(sIend_type,"�h�O");
        }
        else{
        	 strcpy(sIend_type," ");
        }
      }     
       
      $SELECT nchi_full INTO $ZIdeliver_nbranch
	     FROM branch 
        WHERE ibranch = (SELECT iply_branch 
                           FROM sa_branch_type 
                          WHERE ibranch = (SELECT iquota FROM officer WHERE iofficer = $ZIdeliver));
	  if (SQLCODE == SQLNOTFOUND) strcpy(ZIdeliver_nbranch," ");
      
      strcpy(Zfin_out_char," ");
      strcpy(limit_date," "); 
      sys_int = limit_date_int = cnt_lastday = zdalter_int = 0;
      strcpy(limit_date_100," ");
      strcpy(zdalter_100," ");
      strcpy(cnt_lastday_char," "); 
      strcpy(Zddeliver_old_100," ");
      sys_int = cm_today();
      strcpy(sys,cm_edate_str(sys_int));
	  if (pFlag == COMP)
	  {
	      printf("Zddeliver_old[%s]\n",Zddeliver_old);
	      printf("Zfin_out[%s]\n",Zfin_out);
	      
	      if (strncmp(Zfin_out,"0",1) == 0) 
	      {
	      	  strcpy(Zfin_out_char," ");
	          if ((ZDissue[0] != '') && (ZDissue[0] != '\0'))
		  {
		  	$SELECT skip 179 first 1 dwork
			   INTO $limit_date
			   FROM cm_wrktbl
			  WHERE dwork > $ZDissue
			  ORDER BY 1;
			
			if ( ZFstatus[0]=='0'||ZFstatus[0]=='5'||ZFstatus[0]=='6'||ZFstatus[0]=='7' ) /* ���ʪ��A�G���X */
			{
			    strcpy(limit_date_100,cm_from_infdate_100(limit_date));
			    limit_date_int = cm_ymd_cdate(limit_date_100);	
			    printf("sys_int[%d]limit_date_int[%d]\n",sys_int,limit_date_int);
			    cnt_lastday = limit_date_int - sys_int;
			    strcpy(cnt_lastday_char,itoa(cnt_lastday));
			    printf("cnt_lastday_char[%s]cnt_lastday[%d]\n",cnt_lastday_char,cnt_lastday);
			    strcpy(Zddeliver_old_100,cm_from_infdate_100(Zddeliver_old));
			}
			else 
			{
			    strcpy(limit_date_100,cm_from_infdate_100(limit_date));
			    limit_date_int = cm_ymd_cdate(limit_date_100);
			    strcpy(zdalter_100,cm_from_infdate_100(zdalter));
			    zdalter_int = cm_ymd_cdate(zdalter_100);
			    printf("zdalter_int[%d]limit_date_int[%d]\n",zdalter_int,limit_date_int);
			    cnt_lastday = limit_date_int - zdalter_int;
			    strcpy(cnt_lastday_char,itoa(cnt_lastday));
			    printf("cnt_lastday_char[%s]cnt_lastday[%d]\n",cnt_lastday_char,cnt_lastday);
			    strcpy(Zddeliver_old_100,cm_from_infdate_100(Zddeliver_old));
			}	     	
	      	  }	
	      }
	      else if(strncmp(Zfin_out,"1",1) == 0) 
	      {
	      	  strcpy(Zfin_out_char,"�����q��");
		      
		  $SELECT skip 179 first 1 dwork
		     INTO $limit_date
		     FROM cm_wrktbl
		    WHERE dwork > $Zddeliver_old
		    ORDER BY 1;
		  
		  if ( ZFstatus[0]=='0'||ZFstatus[0]=='5'||ZFstatus[0]=='6'||ZFstatus[0]=='7' ) /* ���ʪ��A�G���X */
		  {
		  	strcpy(limit_date_100,cm_from_infdate_100(limit_date));
		  	limit_date_int = cm_ymd_cdate(limit_date_100);
		  	printf("sys_int[%d]limit_date_int[%d]\n",sys_int,limit_date_int);
		  	cnt_lastday = limit_date_int - sys_int;
		  	strcpy(cnt_lastday_char,itoa(cnt_lastday));
		  	printf("cnt_lastday_char[%s]cnt_lastday[%d]\n",cnt_lastday_char,cnt_lastday);
		  	strcpy(Zddeliver_old_100,cm_from_infdate_100(Zddeliver_old));
		  }
		  else 
		  {
		  	strcpy(limit_date_100,cm_from_infdate_100(limit_date));
		  	limit_date_int = cm_ymd_cdate(limit_date_100);
		  	strcpy(zdalter_100,cm_from_infdate_100(zdalter));
		  	zdalter_int = cm_ymd_cdate(zdalter_100);
			printf("zdalter_int[%d]limit_date_int[%d]\n",zdalter_int,limit_date_int);
		  	cnt_lastday = limit_date_int - zdalter_int;
		  	strcpy(cnt_lastday_char,itoa(cnt_lastday));
		  	printf("cnt_lastday_char[%s]cnt_lastday[%d]\n",cnt_lastday_char,cnt_lastday);
		  	strcpy(Zddeliver_old_100,cm_from_infdate_100(Zddeliver_old));
		  }    
	      }
	      else if(strncmp(Zfin_out,"2",1) == 0) 
	      {
		  strcpy(Zfin_out_char,"�~���q��");
		  $SELECT skip 29 first 1 dwork
		     INTO $limit_date
		     FROM cm_wrktbl
		    WHERE dwork > $Zddeliver_old
		    ORDER BY 1;
		    
		  if ( ZFstatus[0]=='0'||ZFstatus[0]=='5'||ZFstatus[0]=='6'||ZFstatus[0]=='7' ) /* ���ʪ��A�G���X */
		  {
		  	strcpy(limit_date_100,cm_from_infdate_100(limit_date));
		  	limit_date_int = cm_ymd_cdate(limit_date_100);
		  	printf("sys_int[%d]limit_date_int[%d]\n",sys_int,limit_date_int);
		  	cnt_lastday = limit_date_int - sys_int;
		  	strcpy(cnt_lastday_char,itoa(cnt_lastday));
		  	printf("cnt_lastday_char[%s]cnt_lastday[%d]\n",cnt_lastday_char,cnt_lastday);
		  	strcpy(Zddeliver_old_100,cm_from_infdate_100(Zddeliver_old));
		  }
		  else 
		  {
		  	strcpy(limit_date_100,cm_from_infdate_100(limit_date));
		  	limit_date_int = cm_ymd_cdate(limit_date_100);
		  	strcpy(zdalter_100,cm_from_infdate_100(zdalter));
			zdalter_int = cm_ymd_cdate(zdalter_100);
			printf("zdalter_int[%d]limit_date_int[%d]\n",zdalter_int,limit_date_int);
		  	cnt_lastday = limit_date_int - zdalter_int;
		  	strcpy(cnt_lastday_char,itoa(cnt_lastday));
		  	printf("cnt_lastday_char[%s]cnt_lastday[%d]\n",cnt_lastday_char,cnt_lastday);
		  	strcpy(Zddeliver_old_100,cm_from_infdate_100(Zddeliver_old));
		  } 
              }  
	  }
	  else 
	  {
	  	strcpy(Zddeliver_old_100," ");
	  	strcpy(Zfin_out_char," ");
	  	strcpy(limit_date_100," ");
	  	strcpy(cnt_lastday_char," "); 	
	  }    	   
      car208_body(pFlag,qFlag);
   } /* end while */
    
    
    
   if( BrkCount > 0) {
      car208_brk(pFlag,qFlag);
   }
   if (pFlag == COMP) {
       printf("**** close acursor1\n");
       $CLOSE Acursor1;
   }
   else if (pFlag == CARD) {
       printf("**** close acursor3\n");
       $CLOSE Acursor3;
   }
    
   $WHENEVER SQLERROR CONTINUE;
   return SUCCESS;
errexit:
   printf("ERROR:%d\n",SQLCODE);
   EWRITE(userid,0,"Proccess Failed !");
   return;
}
/************************************************/
long car208_build1()
{
   char BodyFile [4][N_FILE+1];
   char TitleFile[4][N_FILE+1];
   $char TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];

   $int ItemRow, TotColumn;
   $int StartRow,TitleRow;
   $int PgLine, Width;

   if (db_select(DBName) == False) {
       EWRITE(userid,M_CM_DB_NOTOPEN,"M_CM_DB_NOTOPEN");
       return 0;
   }

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
           kTot_Col, kPgNum_Line, kWidth,     iForm_Tp
      INTO $TitleFmt,  $BodyFmt,  $StartRow,  $TitleRow,  $ItemRow,
           $TotColumn, $PgLine, $Width, $FormTp
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 208 AND iForm_Tp = '2';

   strcpy( TitleFmt, rtrim(TitleFmt));
   strcpy( BodyFmt, rtrim(BodyFmt));

   /*���ͤ@�ӳ���*/
   if (cardclass[0]!='9' && cartype[0]!='9')
   {
        FileCnt = 1;
        sprintf_s(TitleFile[0], sizeof TitleFile[0], "%s.ti", outputf);
        sprintf_s(BodyFile[0], sizeof BodyFile[0], "%s.bd", outputf);
        printf("258 TitleFile[0]=[%s] \n", TitleFile[0]);
        printf("258 BODYFile[0]=[%s] \n", BodyFile[0]);
        if(cardclass[0] == '1' && cartype[0] == '1')
        {
             rgu_init_report( TitleFmt,TitleFile[0]);
             car208_title(COMP,CAR);
             rgu_finish_report();

             rgu_init_report( BodyFmt,BodyFile[0]);
             car208_branch1(COMP,CAR) ;
             rgu_finish_report();
        }

        if(cardclass[0] == '1' && cartype[0] == '2')
        {
             rgu_init_report( TitleFmt,TitleFile[0]);
             car208_title(COMP,MOT);
             rgu_finish_report();

             rgu_init_report( BodyFmt,BodyFile[0]);
             car208_branch1(COMP,MOT) ;
             rgu_finish_report();
        }

        if(cardclass[0] == '2' && cartype[0] == '1')
        {
             rgu_init_report( TitleFmt,TitleFile[0]);
             car208_title(CARD,CAR);
             rgu_finish_report();

             rgu_init_report( BodyFmt,BodyFile[0]);
             car208_branch1(CARD,CAR) ;
             rgu_finish_report();
        }

        if(cardclass[0] == '2' && cartype[0] == '2')
        {
             rgu_init_report( TitleFmt,TitleFile[0]);
             car208_title(CARD,MOT);
             rgu_finish_report();

             rgu_init_report( BodyFmt,BodyFile[0]);
             car208_branch1(CARD,MOT) ;
             rgu_finish_report();
        }
        max_count[0] = miy;
   }

   /*���ͨ�ӳ���*/
   if (cardclass[0] =='9' && cartype[0]!='9')
   {   FileCnt = 2;
       sprintf_s(TitleFile[0], sizeof TitleFile[0], "%sA.ti", outputf);
       sprintf_s(BodyFile[0], sizeof BodyFile[0], "%sA.bd", outputf);
       sprintf_s(TitleFile[1], sizeof TitleFile[1], "%sB.ti", outputf);
       sprintf_s(BodyFile[1], sizeof BodyFile[1], "%sB.bd", outputf);

       printf("306 TitleFile[0]=[%s] \n", TitleFile[0]);
       printf("306 BODYFile[0]=[%s] \n", BodyFile[0]);
       printf("308 TitleFile[1]=[%s] \n", TitleFile[1]);
       printf("308 BODYFile[1]=[%s] \n", BodyFile[1]);

       if( cartype[0] == '1')
       {
            rgu_init_report( TitleFmt,TitleFile[0]);
            car208_title(COMP,CAR);
            rgu_finish_report();

            rgu_init_report( BodyFmt,BodyFile[0]);
            car208_branch1(COMP,CAR) ;
            rgu_finish_report();
            max_count[0] = miy;

            rgu_init_report( TitleFmt,TitleFile[1]);
            car208_title(CARD,CAR);
            rgu_finish_report();

            rgu_init_report( BodyFmt,BodyFile[1]);
            car208_branch1(CARD,CAR) ;
            rgu_finish_report();
            max_count[1] = miy;
       }

       if( cartype[0] == '2')
       {
            rgu_init_report( TitleFmt,TitleFile[0]);
            car208_title(COMP,MOT);
            rgu_finish_report();

            rgu_init_report( BodyFmt,BodyFile[0]);
            car208_branch1(COMP,MOT) ;
            rgu_finish_report();
            max_count[0] = miy;

            rgu_init_report( TitleFmt,TitleFile[1]);
            car208_title(CARD,MOT);
            rgu_finish_report();

            rgu_init_report( BodyFmt,BodyFile[1]);
            car208_branch1(CARD,MOT) ;
            rgu_finish_report();
            max_count[1] = miy;
       }
   }

   if (cardclass[0] !='9' && cartype[0]=='9')
   {
       FileCnt = 2;
       sprintf_s(TitleFile[0], sizeof TitleFile[0], "%sA.ti", outputf);
       sprintf_s(BodyFile[0], sizeof BodyFile[0], "%sA.bd", outputf);
       sprintf_s(TitleFile[1], sizeof TitleFile[1], "%sB.ti", outputf);
       sprintf_s(BodyFile[1], sizeof BodyFile[1], "%sB.bd", outputf);

       printf("358 TitleFile[0]=[%s] \n", TitleFile[0]);
       printf("358 BODYFile[0]=[%s] \n", BodyFile[0]);
       printf("359 TitleFile[1]=[%s] \n", TitleFile[1]);
       printf("359 BODYFile[1]=[%s] \n", BodyFile[1]);

       if( cardclass[0] == '1')
       {
            rgu_init_report( TitleFmt,TitleFile[0]);
            car208_title(COMP,CAR);
            rgu_finish_report();

            rgu_init_report( BodyFmt,BodyFile[0]);
            car208_branch1(COMP,CAR) ;
            rgu_finish_report();
            max_count[0] = miy;

            rgu_init_report( TitleFmt,TitleFile[1]);
            car208_title(COMP,MOT);
            rgu_finish_report();

            rgu_init_report( BodyFmt,BodyFile[1]);
            car208_branch1(COMP,MOT) ;
            rgu_finish_report();
            max_count[1] = miy;
       }
       if( cardclass[0] == '2')
       {
            rgu_init_report( TitleFmt,TitleFile[0]);
            car208_title(CARD,CAR);
            rgu_finish_report();

            rgu_init_report( BodyFmt,BodyFile[0]);
            car208_branch1(CARD,CAR) ;
            rgu_finish_report();
            max_count[0] = miy;

            rgu_init_report( TitleFmt,TitleFile[1]);
            car208_title(CARD,MOT);
            rgu_finish_report();

            rgu_init_report( BodyFmt,BodyFile[1]);
            car208_branch1(CARD,MOT) ;
            rgu_finish_report();
            max_count[1] = miy;
       }
   }
   /*���ͥ|������*/
   if (cardclass[0] =='9' && cartype[0]=='9')
   {
       FileCnt = 4;
       sprintf_s(TitleFile[0], sizeof TitleFile[0], "%sA.ti", outputf);
       sprintf_s(BodyFile[0], sizeof BodyFile[0], "%sA.bd", outputf);
       sprintf_s(TitleFile[1], sizeof TitleFile[1], "%sB.ti", outputf);
       sprintf_s(BodyFile[1], sizeof BodyFile[1], "%sB.bd", outputf);
       sprintf_s(TitleFile[2], sizeof TitleFile[2], "%sC.ti", outputf);
       sprintf_s(BodyFile[2], sizeof BodyFile[2], "%sC.bd", outputf);
       sprintf_s(TitleFile[3], sizeof TitleFile[3], "%sD.ti", outputf);
       sprintf_s(BodyFile[3], sizeof BodyFile[3], "%sD.bd", outputf);
       printf("413 outputf=[%s] \n",outputf);
       printf("414 TitleFile[0]=[%s] \n", TitleFile[0]);
       printf("414 BODYFile[0]=[%s] \n", BodyFile[0]);
       printf("415 TitleFile[1]=[%s] \n", TitleFile[1]);
       printf("415 BODYFile[1]=[%s] \n", BodyFile[1]);
       printf("416 TitleFile[2]=[%s] \n", TitleFile[2]);
       printf("416 BODYFile[2]=[%s] \n", BodyFile[2]);
       printf("417 TitleFile[3]=[%s] \n", TitleFile[3]);
       printf("417 BODYFile[3]=[%s] \n", BodyFile[3]);

       rgu_init_report( TitleFmt,TitleFile[0]);
       car208_title(COMP,CAR);
       rgu_finish_report();

       rgu_init_report( BodyFmt,BodyFile[0]);
       car208_branch1(COMP,CAR) ;
       rgu_finish_report();
       max_count[0] = miy;

       rgu_init_report( TitleFmt,TitleFile[1]);
       car208_title(CARD,CAR);
       rgu_finish_report();

       rgu_init_report( BodyFmt,BodyFile[1]);
       car208_branch1(CARD,CAR) ;
       rgu_finish_report();
       max_count[1] = miy;

       rgu_init_report( TitleFmt,TitleFile[2]);
       car208_title(COMP,MOT);
       rgu_finish_report();

       rgu_init_report( BodyFmt,BodyFile[2]);
       car208_branch1(COMP,MOT) ;
       rgu_finish_report();
       max_count[2] = miy;

       rgu_init_report( TitleFmt,TitleFile[3]);
       car208_title(CARD,MOT);
       rgu_finish_report();

       rgu_init_report( BodyFmt,BodyFile[3]);
       car208_branch1(CARD,MOT) ;
       rgu_finish_report();
       max_count[3] = miy;
   }
   return M_CM_OK;
}
/**********************************************/

long car208_branch1(pFlag,qFlag)
int pFlag,qFlag;
{
      $char stmt_buf[2048], tmp_buf[201];

      miy= 0; first= 1;

      $WHENEVER SQLERROR GOTO errexit;
      strcpy(FullDBName,get_full_dbname(DBName));
      printf("*******614 fulldbname[%s]\n",FullDBName);

      strcpy( BrkIcardyear, "  ");
      strcpy( BrkIofficer,"          ");
      strcpy( BrkFstatus, " ");
      BrkCount= BrkSubTotal= 0;
      flag_brk = 1;

      /**** prepare cursor ****/
      /***********************�j�� ******************************/
      sprintf_s(stmt_buf, sizeof stmt_buf,
             "SELECT icard,icar_type,fstatus,iofficer,iissue_branch,icardyear   "
                " FROM %s:compulsory_card ",
                     FullDBName);

      if (choice[0]=='1')
         sprintf_s(tmp_buf, sizeof tmp_buf,"WHERE dissue BETWEEN '%s' AND '%s' ",issdtbgn,issdtend);
      else if (choice[0]=='2')
         sprintf_s(tmp_buf, sizeof tmp_buf,"WHERE dreceive BETWEEN '%s' AND '%s' ",alterbgn,alterend);
      else if (choice[0]=='3')
         sprintf_s(tmp_buf, sizeof tmp_buf,"WHERE ddeliver_old BETWEEN '%s' AND '%s' ",delivbgn,delivend);
      else if (choice[0]=='4')
         sprintf_s(tmp_buf, sizeof tmp_buf,"WHERE dalter BETWEEN '%s' AND '%s' ",changbgn,changend);
      else if (choice[0]=='5')
         sprintf_s(tmp_buf, sizeof tmp_buf,"WHERE dissue BETWEEN '%s' AND '%s'  "
                            "AND (ddeliver_old BETWEEN '%s' AND '%s'  "
                            " OR ddeliver_old is null) ",issdtbgn,issdtend,delivbgn,delivend);
      strcat(stmt_buf,tmp_buf);
      
      strcpy(sKbill_code,trim(sKbill_code));
      if (strlen(sKbill_code) != 0)
      {
      	sprintf_s(tmp_buf, sizeof tmp_buf,"AND icard[3,4] = '%s' ",sKbill_code);
        strcat(stmt_buf,tmp_buf);
      }

      if (dptbgn[0]!='*' && dptend[0]!='*')
      {
        if (choice1[0] == '1')      		
           sprintf_s(tmp_buf, sizeof tmp_buf,"AND iissue_branch BETWEEN '%s' AND '%s' ",dptbgn,dptend);
        else if (choice1[0] == '2')
        	 sprintf_s(tmp_buf, sizeof tmp_buf,"AND ideliver in (SELECT iofficer FROM officer  "
        	                                   " WHERE ibranch BETWEEN '%s' AND '%s') ",dptbgn,dptend);
        else
        	 sprintf_s(tmp_buf, sizeof tmp_buf,"AND ialter in (SELECT iofficer FROM officer  "
        	                                   " WHERE ibranch BETWEEN '%s' AND '%s') ",dptbgn,dptend);
        	                                    
        strcat(stmt_buf,tmp_buf);
      }

      sprintf_s(tmp_buf, sizeof tmp_buf,"AND iquota matches '%s' ",iquota);
      strcat(stmt_buf,tmp_buf);

      if (officerbgn[0]!='*' && officerend[0]!='*')
      {
        sprintf_s(tmp_buf, sizeof tmp_buf,"AND iofficer BETWEEN '%s' AND '%s' ",officerbgn,officerend);
        strcat(stmt_buf,tmp_buf);
      }

      if (ideliverbgn[0]!='*' && ideliverend[0]!='*')
      {
        sprintf_s(tmp_buf, sizeof tmp_buf,"AND ideliver BETWEEN '%s' AND '%s' ",ideliverbgn,ideliverend);
        strcat(stmt_buf,tmp_buf);
      }

      if (card1[0]!='*' && card2[0]!='*')
      {
        sprintf_s(tmp_buf, sizeof tmp_buf,"AND icard BETWEEN '%s' AND '%s' ",card1,card2);
        strcat(stmt_buf,tmp_buf);
      }

      if (cardstatus1[0]!='9' )
      {
      	if (cardstatus1[0] == '0') 
      	{
      		strcat(stmt_buf," AND a.fstatus in ('0','5','6') ");
      	}
        if (cardstatus1[0] == 'Y') 
      	{
      		strcat(stmt_buf," AND a.fstatus in ('0','5','6','7') ");
      	}
      	else if (cardstatus1[0] == 'Z')
      	{
      		strcat(stmt_buf," AND a.fstatus in ('A','B','C','D','E','8','3') ");
      	}
      	else
      	{
          sprintf_s(tmp_buf, sizeof tmp_buf,"AND a.fstatus = '%s' ",cardstatus1);
          strcat(stmt_buf,tmp_buf);
        }
      }

       strcat(stmt_buf,"ORDER BY iissue_branch,icard");
      /*if( sfrflag[0]=='Y')
        strcat(stmt_buf,"ORDER BY iofficer,icard");
      else
        strcat(stmt_buf,"ORDER BY icardyear,icard");*/

      printf("1247 SQL QUERY STATEMENT-->%s\n\n",stmt_buf);
      $PREPARE CUR_STMT1 FROM $stmt_buf;
      $DECLARE Acursor5 CURSOR FOR CUR_STMT1;

      /*************************���N***************************/
      sprintf_s(stmt_buf, sizeof stmt_buf,"SELECT %s FROM %s:%s ",
                              "icard,icar_type,fstatus,iofficer,iissue_branch,icardyear",FullDBName,"card ");

      if (choice[0]=='1')
         sprintf_s(tmp_buf, sizeof tmp_buf,"WHERE dissue BETWEEN '%s' AND '%s' ",issdtbgn,issdtend);
      else if (choice[0]=='2')
         sprintf_s(tmp_buf, sizeof tmp_buf,"WHERE dreceive BETWEEN '%s' AND '%s' ",alterbgn,alterend);
      else if (choice[0]=='3')
         sprintf_s(tmp_buf, sizeof tmp_buf,"WHERE ddeliver BETWEEN '%s' AND '%s' ",delivbgn,delivend);
      else if (choice[0]=='4')
         sprintf_s(tmp_buf, sizeof tmp_buf,"WHERE dalter BETWEEN '%s' AND '%s' ",changbgn,changend);
      else if (choice[0]=='5')
         sprintf_s(tmp_buf, sizeof tmp_buf,"WHERE dissue BETWEEN '%s' AND '%s'  "
                            "AND (ddeliver BETWEEN '%s' AND '%s'  "
                            " OR ddeliver is null) ",issdtbgn,issdtend,delivbgn,delivend);
      strcat(stmt_buf,tmp_buf);

      if (dptbgn[0]!='*' && dptend[0]!='*')
      {
        if (choice1[0] == '1')      		
           sprintf_s(tmp_buf, sizeof tmp_buf,"AND iissue_branch BETWEEN '%s' AND '%s' ",dptbgn,dptend);
        else if (choice1[0] == '2')
        	 sprintf_s(tmp_buf, sizeof tmp_buf,"AND ideliver in (SELECT iofficer FROM officer  "
        	                                    "WHERE ibranch BETWEEN '%s' AND '%s') ",dptbgn,dptend);
        else
        	 sprintf_s(tmp_buf, sizeof tmp_buf,"AND ialter in (SELECT iofficer FROM officer  "
        	                                    "WHERE ibranch BETWEEN '%s' AND '%s') ",dptbgn,dptend);
        	                                    
        strcat(stmt_buf,tmp_buf);
      }

      sprintf_s(tmp_buf, sizeof tmp_buf,"AND iquota matches '%s' ",iquota);
      strcat(stmt_buf,tmp_buf);

      if (officerbgn[0]!='*' && officerend[0]!='*')
      {
        sprintf_s(tmp_buf, sizeof tmp_buf,"AND iofficer BETWEEN '%s' AND '%s' ",officerbgn,officerend);
        strcat(stmt_buf,tmp_buf);
      }

      if (ideliverbgn[0]!='*' && ideliverend[0]!='*')
      {
        sprintf_s(tmp_buf, sizeof tmp_buf,"AND ideliver BETWEEN '%s' AND '%s' ",ideliverbgn,ideliverend);
        strcat(stmt_buf,tmp_buf);
      }

      if (card1[0]!='*' && card2[0]!='*')
      {
        sprintf_s(tmp_buf, sizeof tmp_buf,"AND icard BETWEEN '%s' AND '%s' ",card1,card2);
        strcat(stmt_buf,tmp_buf);
      }

      if (cardstatus1[0]!='9' )
      {
      	if (cardstatus1[0] == '0') 
      	{
      		strcat(stmt_buf," AND a.fstatus in ('0','5','6') ");
      	}
        if (cardstatus1[0] == 'Y') 
      	{
      		strcat(stmt_buf," AND a.fstatus in ('0','5','6','7') ");
      	}
      	else if (cardstatus1[0] == 'Z')
      	{
      		strcat(stmt_buf," AND a.fstatus in ('A','B','C','D','E','8','3') ");
      	}
      	else
      	{
          sprintf_s(tmp_buf, sizeof tmp_buf,"AND a.fstatus = '%s' ",cardstatus1);
          strcat(stmt_buf,tmp_buf);
        }
      }

      strcat(stmt_buf,"ORDER BY iissue_branch,icard");
      /* if( sfrflag[0]=='Y')
        strcat(stmt_buf,"ORDER BY iofficer,icard");
      else
        strcat(stmt_buf,"ORDER BY icardyear,icard");*/

      printf("703-->%s\n\n",stmt_buf);
      $PREPARE CUR_STMT3 FROM $stmt_buf;
      $DECLARE Acursor7 CURSOR FOR CUR_STMT3;
      printf(" 707 pFlag=[%d],qFlag=[%d] \n",pFlag,qFlag);

      car208_data1(pFlag,qFlag);
      $WHENEVER SQLERROR CONTINUE;
      return 0;
errexit:
   printf("ERROR:%d\n",SQLCODE);
   EWRITE(userid,0,"CURSOR ERROR !!");
   return;

}

/***************************************/

long car208_data1(pFlag,qFlag)
int pFlag,qFlag;
{
   int officer_int,int_bgn,int_end;

   if(officerbgn[0]!='*')
   {
      int_bgn=atoi(officerbgn);
      int_end=atoi(officerend);
   }
   printf(" 729 pFlag=[%d],qFlag=[%d] \n",pFlag,qFlag);
   $ WHENEVER SQLERROR GOTO errexit;
   if (pFlag == COMP)
          {printf("!!!! FETCH Acursor5 !!!!\n"); $OPEN Acursor5;}
   else if (pFlag == CARD)
          {printf("!!!! FETCH Acursor7 !!!!\n"); $OPEN Acursor7;}

   printf("!!! start FECTHING !!!!!\n");
   
   fstatus_0_tot=fstatus_1_tot=fstatus_2_tot=fstatus_3_tot=fstatus_4_tot=0;
   fstatus_5_tot=fstatus_6_tot=fstatus_7_tot=fstatus_8_tot=fstatus_tot2=0;
   fstatus_A_tot=fstatus_B_tot=fstatus_C_tot=fstatus_D_tot=fstatus_E_tot=0;
   f=0;
   strcpy(f_flag,"false");
   while( 1)
   {
      if (pFlag == COMP)
      {
         $FETCH Acursor5
           INTO $ZIcard, $ZIcar_type, $ZFstatus, $ZIofficer,$ZIiss_b,$ZIcardyear;

         if( SQLCODE == SQLNOTFOUND) break;

      }
      else if (pFlag == CARD)
      {
         $FETCH Acursor7
          INTO $ZIcard, $ZIcar_type, $ZFstatus, $ZIofficer,$ZIiss_b,$ZIcardyear;
         if( SQLCODE == SQLNOTFOUND) break;
      }

      if (f==0)
      {
          car208_grp1(ZIcardyear);
          strcpy(ZIiss_ba, ZIiss_b);
          /*fstatus_0=fstatus_1=fstatus_2=fstatus_3=fstatus_4=fstatus_5=fstatus_6=fstatus_7=fstatus_tot=fstatus_r=0;*/
      }

      if (ZIiss_ba[1] != ZIiss_b[1])
      {
          car208_body1(pFlag,qFlag);
          strcpy(ZIiss_ba, ZIiss_b);
          fstatus_0=fstatus_1=fstatus_2=fstatus_3=fstatus_4=fstatus_5=fstatus_6=fstatus_7=fstatus_8=fstatus_tot=fstatus_r=0;
          fstatus_A=fstatus_B=fstatus_C=fstatus_D=fstatus_E=0;
      }

      if(qFlag == CAR)
      {
         if(strncmp(ZIcar_type,"01",2)==0 || strncmp(ZIcar_type,"02",2)==0 ||
            strncmp(ZIcar_type,"32",2)==0 || strncmp(ZIcar_type,"34",2)==0 || strncmp(ZIcar_type,"35",2)==0)
            continue;
      }
      else if(qFlag == MOT)
      {
         if(strncmp(ZIcar_type,"01",2)!=0 && strncmp(ZIcar_type,"02",2)!=0 &&
            strncmp(ZIcar_type,"32",2)!=0 && strncmp(ZIcar_type,"34",2)!=0 && strncmp(ZIcar_type,"35",2)!=0)
            continue;
      }

      $SELECT nchi_full INTO $ZIissue_bh
         FROM branch
        WHERE ibranch = $ZIiss_b;
      if (SQLCODE == SQLNOTFOUND) strcpy(ZIissue_bh," ");

      if (pFlag == COMP)
      {
         if (ZQreprint < 0) ZQreprint=0;
      }
      else if (pFlag == CARD)
      {
          /*printf("*********card[%s] fstatus[%s]\n",ZIcard,ZFstatus); */
      }

      if( sfrflag[0]=='Y')
      {
          if( strcmp( BrkIofficer, ZIofficer) != 0)
          { /* skip page group 
               car208_brk(pFlag,qFlag);
               car208_grp1(ZIcardyear);*/
          }
      }
      else
      {
          if( strcmp( BrkIcardyear, ZIcardyear) != 0)
          { /* skip page group 
               car208_brk(pFlag,qFlag);
               car208_grp1(ZIcardyear);*/
          }
      }

      strcpy( BrkIofficer,ZIofficer);
      strcpy( BrkIcardyear, ZIcardyear);

      if(pFlag == COMP) {
           sprintf_s(ZQreprint_char, sizeof ZQreprint_char,"%2d",ZQreprint);
      }
      strcpy(ZFstatus,trim(ZFstatus));
      /*fstatus_0=fstatus_1=fstatus_2=fstatus_3=fstatus_4=fstatus_5=fstatus_6=fstatus_7=fstatus_tot=0;*/
      
      printf("===============> 1448 ZFstatus=[%s]\n", ZFstatus );
      
      if (ZFstatus[0]=='0')
      {
          /*strcpy(ZFstatus_char,"���X");*/
          fstatus_0 +=1;
      }
      else if (ZFstatus[0]=='1')
      {
          /*strcpy(ZFstatus_char,"�P��");*/
          fstatus_1 +=1;
      }
      else if (ZFstatus[0]=='2')
      {
          /*strcpy(ZFstatus_char,"�L��");*/
          fstatus_2 +=1;
      }
      else if (ZFstatus[0]=='3')
      {
         /* strcpy(ZFstatus_char,"�@�o");*/
         fstatus_3 +=1;
      }
      else if (ZFstatus[0]=='4')
      {
          /*strcpy(ZFstatus_char,"��");*/
          fstatus_4 +=1;
      }
      else if (ZFstatus[0]=='5')
      {
          /*strcpy(ZFstatus_char,"�@�o�ܥ��X");*/
          fstatus_5 +=1;
      }
      else if (ZFstatus[0]=='6')
      {
          /*strcpy(ZFstatus_char,"���ܥ��X");*/
          fstatus_6 +=1;
      }
      else if (ZFstatus[0]=='7')
      {
           fstatus_7 +=1;
      }
      else if (ZFstatus[0]=='8')
      {
           fstatus_8 +=1;
      }
      else if (ZFstatus[0]=='A') /*µ�����~�Φ��l*/
      {
           fstatus_A +=1;
      }
      else if (ZFstatus[0]=='B') /*���Ƨ�O*/
      {
           fstatus_B +=1;
      }
      else if (ZFstatus[0]=='C') /*�ܺʲz����ӥ��L*/
      {
           fstatus_C +=1;
      }
      else if (ZFstatus[0]=='D') /*���ϥΤ��@�o*/
      {
           fstatus_D +=1;
      }
      else if (ZFstatus[0]=='E') /*���l*/
      {
           fstatus_E +=1;
      }
      BrkCount += 1;
      
      printf("===============> 1448 fstatus_8=[%d]\n", fstatus_8 );

      fstatus_tot=fstatus_0+fstatus_1+fstatus_2+fstatus_3+fstatus_4+fstatus_5+fstatus_6+fstatus_7+fstatus_8+fstatus_A+fstatus_B+fstatus_C+fstatus_D+fstatus_E;
      fstatus_r = (double)100.00*(fstatus_0+fstatus_7)/fstatus_tot;

      strcpy(f_flag, "true");
      f+=1;
   } /* end while */

   if (strcmp(f_flag,"true") == 0)
   {
       car208_body1(pFlag,qFlag);
   }

   if( BrkCount > 0)
   {
      /*car208_brk(pFlag,qFlag);
      (car208_grp1(ZIcardyear);*/
       car208_tot1(pFlag,qFlag);
   }

   if (pFlag == COMP) {
       printf("**** close acursor5\n");
       $CLOSE Acursor5;
   }
   else if (pFlag == CARD) {
       printf("**** close acursor7\n");
       $CLOSE Acursor7;
   }

   $WHENEVER SQLERROR CONTINUE;
   return SUCCESS;
errexit:
   printf("ERROR:%d\n",SQLCODE);
   EWRITE(userid,0,"Proccess Failed !");
   return;
}

/*******************************************************/
void car208_body1(pFlag,qFlag)
int pFlag,qFlag;
{
      
      fstatus_0_tot += fstatus_0;
      fstatus_1_tot += fstatus_1;
      fstatus_2_tot += fstatus_2;
      fstatus_3_tot += fstatus_3;
      fstatus_4_tot += fstatus_4;
      fstatus_5_tot += fstatus_5;
      fstatus_6_tot += fstatus_6;
      fstatus_7_tot += fstatus_7;
      fstatus_8_tot += fstatus_8;
      fstatus_A_tot += fstatus_A;
      fstatus_B_tot += fstatus_B;
      fstatus_C_tot += fstatus_C;
      fstatus_D_tot += fstatus_D;
      fstatus_E_tot += fstatus_E;
      fstatus_tot2  += fstatus_tot;

      rfmtlong(fstatus_0,"-,---,---,--&",m_fstatus_0);
      rfmtlong(fstatus_1,"-,---,---,--&",m_fstatus_1);   
      rfmtlong(fstatus_2,"-,---,---,--&",m_fstatus_2);
      rfmtlong(fstatus_3,"-,---,---,--&",m_fstatus_3);
      rfmtlong(fstatus_4,"-,---,---,--&",m_fstatus_4);
      rfmtlong(fstatus_5,"-,---,---,--&",m_fstatus_5);
      rfmtlong(fstatus_6,"-,---,---,--&",m_fstatus_6);
      rfmtlong(fstatus_7,"-,---,---,--&",m_fstatus_7);
      rfmtlong(fstatus_8,"-,---,---,--&",m_fstatus_8);
      rfmtlong(fstatus_A,"-,---,---,--&",m_fstatus_A);
      rfmtlong(fstatus_B,"-,---,---,--&",m_fstatus_B);
      rfmtlong(fstatus_C,"-,---,---,--&",m_fstatus_C);
      rfmtlong(fstatus_D,"-,---,---,--&",m_fstatus_D);
      rfmtlong(fstatus_E,"-,---,---,--&",m_fstatus_E);
      rfmtlong(fstatus_tot,"-,---,---,--&",m_fstatus_t);
      rfmtdouble(fstatus_r,"-,---,---,--&.###",m_fstatus_r);

      /************
      printf("pFlag:%d\n",pFlag);
      printf("qFlag:%d\n",qFlag);
      printf("1504:%s\n",ZIissue_bh);
      printf("1505:%s\n",m_fstatus_0);
      printf("1506:%s\n",m_fstatus_1);
      printf("1507:%s\n",m_fstatus_2);
      printf("1508:%s\n",m_fstatus_3);
      printf("1509:%s\n",m_fstatus_4);
      printf("1510:%s\n",m_fstatus_5);
      printf("1511:%s\n",m_fstatus_6);
      printf("1512:%s\n",m_fstatus_t);
      printf("SSSSSSSSSSSSSSSS:%s\n",m_fstatus_r);
      **************/
      rgu_put_body_string(2, ZIissue_bh,        1);
      rgu_put_body_string(2, trim(m_fstatus_0), 2); 
      rgu_put_body_string(2, trim(m_fstatus_1), 2); 
      rgu_put_body_string(2, trim(m_fstatus_3), 2); 
      rgu_put_body_string(2, trim(m_fstatus_4), 2); 
      rgu_put_body_string(2, trim(m_fstatus_5), 2);                   
      rgu_put_body_string(2, trim(m_fstatus_6), 2); 
      rgu_put_body_string(2, trim(m_fstatus_7), 2); 
      rgu_put_body_string(2, trim(m_fstatus_8), 2);
      rgu_put_body_string(2, trim(m_fstatus_A), 2);
      rgu_put_body_string(2, trim(m_fstatus_B), 2);
      rgu_put_body_string(2, trim(m_fstatus_C), 2);
      rgu_put_body_string(2, trim(m_fstatus_D), 2);
      rgu_put_body_string(2, trim(m_fstatus_E), 2);
      rgu_put_body_string(2, trim(m_fstatus_t), 2); 
      rgu_put_body_string(2, trim(m_fstatus_r), 2);                        
      rgu_put_body( 2);   miy++;
}

/*******************************************************/
void car208_tot1(pFlag,qFlag)
int pFlag,qFlag;
{
      fstatus_r2 = (double)100.00*(fstatus_0_tot+fstatus_7_tot)/fstatus_tot2;

      printf("[%ld][%ld][%ld][%ld][%ld]\n",
             fstatus_0_tot, fstatus_1_tot, fstatus_2_tot, fstatus_3_tot, fstatus_4_tot);

      printf("[%ld][%ld][%ld][%ld][%ld][%ld]\n",
             fstatus_5_tot, fstatus_6_tot, fstatus_7_tot, fstatus_8_tot, fstatus_A_tot, fstatus_B_tot);
             
      printf("[%ld][%ld][%ld][%lf]\n",
             fstatus_C_tot, fstatus_D_tot, fstatus_tot2, fstatus_r2);

      rfmtlong(fstatus_0_tot,"-,---,---,--&",m_fstatus_0);
      rfmtlong(fstatus_1_tot,"-,---,---,--&",m_fstatus_1);
      rfmtlong(fstatus_2_tot,"-,---,---,--&",m_fstatus_2);
      rfmtlong(fstatus_3_tot,"-,---,---,--&",m_fstatus_3);
      rfmtlong(fstatus_4_tot,"-,---,---,--&",m_fstatus_4);
      rfmtlong(fstatus_5_tot,"-,---,---,--&",m_fstatus_5);
      rfmtlong(fstatus_6_tot,"-,---,---,--&",m_fstatus_6);
      rfmtlong(fstatus_7_tot,"-,---,---,--&",m_fstatus_7);
      rfmtlong(fstatus_8_tot,"-,---,---,--&",m_fstatus_8);
      rfmtlong(fstatus_A_tot,"-,---,---,--&",m_fstatus_A);
      rfmtlong(fstatus_B_tot,"-,---,---,--&",m_fstatus_B);
      rfmtlong(fstatus_C_tot,"-,---,---,--&",m_fstatus_C);
      rfmtlong(fstatus_D_tot,"-,---,---,--&",m_fstatus_D);
      rfmtlong(fstatus_E_tot,"-,---,---,--&",m_fstatus_E);
      rfmtlong(fstatus_tot2,"-,---,---,--&",m_fstatus_t);
      rfmtdouble(fstatus_r2,"-,---,---,--&.###",m_fstatus_r);

      rgu_put_body(4);   miy++;
      rgu_put_body_string(2, "�X�p",            1);
      rgu_put_body_string(2, trim(m_fstatus_0), 2);
      rgu_put_body_string(2, trim(m_fstatus_1), 2);
      rgu_put_body_string(2, trim(m_fstatus_3), 2);
      rgu_put_body_string(2, trim(m_fstatus_4), 2);
      rgu_put_body_string(2, trim(m_fstatus_5), 2);
      rgu_put_body_string(2, trim(m_fstatus_6), 2);
      rgu_put_body_string(2, trim(m_fstatus_7), 2);
      rgu_put_body_string(2, trim(m_fstatus_8), 2);
      rgu_put_body_string(2, trim(m_fstatus_A), 2);
      rgu_put_body_string(2, trim(m_fstatus_B), 2);
      rgu_put_body_string(2, trim(m_fstatus_C), 2);
      rgu_put_body_string(2, trim(m_fstatus_D), 2);
      rgu_put_body_string(2, trim(m_fstatus_E), 2);
      rgu_put_body_string(2, trim(m_fstatus_t), 2);
      rgu_put_body_string(2, trim(m_fstatus_r), 2);
      rgu_put_body(2);   miy++;
}
long car208_mail()
{
    $int mail_count;
    $char pre_Key[11],sKey[11];
    $char pre_car_code_mail[21],car_code_mail[21];
    $char errmsg[200];
       
    /*
        Car202�w�t�o�g�줧�޲z�H�F��car208�t�o�g��H���̷s�޲z�H�C
        Car202�w�t�o�g�줧�޲z�H�����D�ޥH�ΤW�h���D�ޡG��ñ�ֳ���ɬ����D�ޱH�o�C
    */       
    $UPDATE car208_mail 
        SET resp_name_mail = (SELECT a.resp_name   
                                FROM personal:unitid2ef a, officer b
                               WHERE a.code_no = b.iquota AND b.iofficer =car208_mail.ileader),
            top_unit_mail = (SELECT  nvl(c.resp_name,a.resp_name)
                                FROM personal:unitid2ef a, officer b,OUTER personal:unitid2ef c
                               WHERE a.code_no = b.iquota AND b.iofficer =car208_mail.ileader
                                 AND c.code_no = a.top_unit),
            car_code2 = (select unique e.detail2[1,3] 
                           from car_code e , sa_branch_type f
                          where e.kind ='55' and e.detail2[1,2] = f.iply_branch
                            and f.iply_branch =car208_mail.inventory_ncode)
                       
      WHERE 1=1 ;
    if (sqlca.sqlerrd[2] == 0)
    {
        EWRITE(userid,M_CM_OK,"�L���");
        return M_CM_OK;
    }
    /*  
        A-�j��O�I�Ҥw�t�o���P���M�d����(YYY/MM/DD)
        0.car140���ɤ��d�Һ޲z�H    YYYMMDD_�j���ҲM�d����_�L�I���
        1.�w�t�o�g��޲z�H          YYYMMDD_�j���ҲM�d����_�޲z�H���s

        B-�O25��j��O�I�Ҥw�t�o���P�����^����(YYY/MM/DD)
        0.car140���ɤ��d�Һ޲z�H    YYYMMDD_�j���ҹO25�����_�L�I���
        1.�w�t�o�g��޲z�H          YYYMMDD_�j���ҹO25�����_�޲z�H���s 
        2.�w�t�o�g��޲z�H�D��      YYYMMDD_�j���ҹO25�����(�D)_���N��
          �w�t�o�g��޲z�H�D�ު��D��YYYMMDD_�j���ҹO25�����(�D)_���N��
        
        C-YYY�~MM��j��O�I�ҽL�I����
        0.car140���ɤ��d�Һ޲z�H
            YYYMMDD_�L�I���_�j���ҽL�I�ӻ����(�O�T�Ӥ�)  C1+C2 (C2����)
            YYYMMDD_�L�I���_�j���ҽL�I�ӻ����(�O�@�~)    C3+C4 (C4����)
            YYYMMDD_�L�I���_�j���ҽL�I�~�����^����        C5    (�w����)
        3.�W�[�o�e�`���Ӹ�L�I�`�����ӫO�޲z�H��
            YYYMMDD_�j���ҽL�I�^���`��
   */
   
   /* ���Y */
    strcpy(ftitle,
        "�L�I���,�ӻ���,�O�I�Ҹ��X,�ӻ��,�ӻ�H,�������,����,���ʪ��A,�O�渹�X,�t�o�g����,"
        "�t�o�g��H,�g��H,�޲z�H,�޲z�H�N��,�t�o��,���ʤ��,���ʤH�N��,���ʤH��,���ʳ��,���O,"
        "�ɦL����,�����ʲz��J���,��l�t�o��,����/�~���q��,���^����,�Y�N����Ѽ�\n");
    
    /*���X�ɮ�*/
    
    strcpy(sKey,"");
    strcpy(pre_Key,"");
    strcpy(pre_car_code_mail,"");
    strcpy(car_code_mail,"");
    if (strncmp(userid,"car208a",7) == 0)
    {
        printf("car208a-car140���ɤ��d�Һ޲z�Hbgn\n");
        $DECLARE cur_temp_A0 cursor for
          SELECT distinct a.car_code2,b.detail
            INTO $sKey,$car_code_mail
            FROM car208_mail a, car_code b
           WHERE a.car_code2[1,3] = b.detail2[1,3]
             AND b.kind ='55'
           ORDER by 1,2;
        $open cur_temp_A0;
        $fetch cur_temp_A0;

        strcpy(pre_Key,sKey);
        strcpy(pre_car_code_mail,car_code_mail);
        mail_count=0;
        while(1)
        {
            if (SQLCODE==SQLNOTFOUND) break;
            printf("55:sKey[%s]pre_Key[%s]\ncar_code_mail[%s]pre_car_code_mail[%s]\n",
                    sKey,pre_Key,car_code_mail,pre_car_code_mail); 
            
            if (strcmp(car_code_mail,pre_car_code_mail)!=0)
            {
                rc = car208_subject(pre_car_code_mail,"0");
                if (rc!=M_CM_OK) {
                    printf("error on car208_subject\n");
                    EWRITE(userid,M_CM_DB_NOTOPEN,"�s�Wcar208a-car140���ɤ��d�Һ޲z�H�H�󥢱�");
                    return rc;
                }
                /*mail_count=0; sum_mail++;*/
            }
            mail_count++;
            if ((strcmp(pre_Key,sKey)!=0) || mail_count==1)
            {
                memset(fname,0x00,sizeof(fname));
                memset(filename,0x00,sizeof(filename));
                sprintf_s(fname, sizeof fname,"%s%s%s_�j���ҲM�d����_%s_",yy2,mm2,dd2,trim(sKey));
                sprintf_s(filename, sizeof filename,"%s/rptftp/car_email/%s.csv",sApHome,fname);
                sprintf_s(nattachment, sizeof nattachment,"%s.csv",fname);

                fp=fopen(filename,"w");

                fprintf(fp,ftitle);
                car208_list("0",sKey,"*","*");
            }    
            strcpy(pre_Key,sKey);
            strcpy(pre_car_code_mail,car_code_mail);
            $fetch cur_temp_A0;
        }
        if (mail_count > 0)
        {
            rc = car208_subject(pre_car_code_mail,"0");
            if (rc!=M_CM_OK) {
                printf("error on car208_subject\n");
                EWRITE(userid,M_CM_DB_NOTOPEN,"�s�Wcar208a-car140���ɤ��d�Һ޲z�H�H�󥢱�");
                return rc;
            }
        }
        $close cur_temp_A0;
        $free  cur_temp_A0;
        printf("car208a-car140���ɤ��d�Һ޲z�Hend\n");
        printf("car208a-�w�t�o�g��޲z�Hbgn\n");
        strcpy(sKey,"");
        strcpy(pre_Key,"");
        $DECLARE cur_temp_A1 cursor for
          SELECT distinct ileader
            INTO $sKey
            FROM car208_mail
           ORDER by ileader;
        $open cur_temp_A1;
        $fetch cur_temp_A1;

        strcpy(pre_Key,sKey);
        mail_count=0;
        while(1)
        {
            if (SQLCODE==SQLNOTFOUND) break;
            printf("sKey[%s]\npre_Key[%s]\n",sKey,pre_Key); 
            
            if (strcmp(sKey,pre_Key)!=0)
            {
                rc = car208_subject(pre_Key,"1");
                if (rc!=M_CM_OK) {
                    printf("error on car208_subject\n");
                    EWRITE(userid,M_CM_DB_NOTOPEN,"�s�Wcar208a-�t�o�g��޲z�H�H�󥢱�");
                    return rc;
                }
                /*mail_count=0; sum_mail++;*/
            }

            strcpy(pre_Key,sKey);
            mail_count++;
            memset(fname,0x00,sizeof(fname));
            memset(filename,0x00,sizeof(filename));
            sprintf_s(fname, sizeof fname,"%s%s%s_�j���ҲM�d����_%s",yy2,mm2,dd2,trim(sKey));
            sprintf_s(filename, sizeof filename,"%s/rptftp/car_email/%s.csv",sApHome,fname);
            sprintf_s(nattachment, sizeof nattachment,"%s.csv",fname);

            fp=fopen(filename,"w");

            fprintf(fp,ftitle);
            car208_list("1",sKey," "," ");
            $fetch cur_temp_A1;
        }
        if (mail_count > 0)
        {
            rc = car208_subject(pre_Key,"1");
            if (rc!=M_CM_OK) {
                printf("error on car208_subject\n");
                EWRITE(userid,M_CM_DB_NOTOPEN,"�s�Wcar208a-�t�o�g��޲z�H�H�󥢱�");
                return rc;
            }
        }
        $close cur_temp_A1;
        $free  cur_temp_A1;
        printf("car208a-�w�t�o�g��޲z�Hend\n");
    }
    else if (strncmp(userid,"car208b",7) == 0)
    {
        printf("car208b-car140���ɤ��d�Һ޲z�Hbgn\n");
        $DECLARE cur_temp_B0 cursor for
          SELECT distinct a.car_code2,b.detail
            INTO $sKey,$car_code_mail
            FROM car208_mail a, car_code b
           WHERE a.car_code2[1,3] = b.detail2[1,3]
             AND b.kind ='55'
           ORDER by 1,2;
        $open cur_temp_B0;
        $fetch cur_temp_B0;

        strcpy(pre_Key,sKey);
        strcpy(pre_car_code_mail,car_code_mail);
        mail_count=0;
        while(1)
        {
            if (SQLCODE==SQLNOTFOUND) break;
            printf("55:sKey[%s]pre_Key[%s]\ncar_code_mail[%s]pre_car_code_mail[%s]\n",
                    sKey,pre_Key,car_code_mail,pre_car_code_mail); 
            
            if (strcmp(car_code_mail,pre_car_code_mail)!=0)
            {
                rc = car208_subject(pre_car_code_mail,"0");
                if (rc!=M_CM_OK) {
                    printf("error on car208_subject\n");
                    EWRITE(userid,M_CM_DB_NOTOPEN,"�s�Wcar208b-car140���ɤ��d�Һ޲z�H�H�󥢱�");
                    return rc;
                }
                /*mail_count=0; sum_mail++;*/
            }
            mail_count++;
            if ((strcmp(pre_Key,sKey)!=0) || mail_count==1)
            {
                memset(fname,0x00,sizeof(fname));
                memset(filename,0x00,sizeof(filename));
                sprintf_s(fname, sizeof fname,"%s%s%s_�j���ҹO25�����_%s_",yy2,mm2,dd2,trim(sKey));
                sprintf_s(filename, sizeof filename,"%s/rptftp/car_email/%s.csv",sApHome,fname);
                sprintf_s(nattachment, sizeof nattachment,"%s.csv",fname);

                fp=fopen(filename,"w");

                fprintf(fp,ftitle);
                car208_list("0",sKey,"*","*");
            }    
            strcpy(pre_Key,sKey);
            strcpy(pre_car_code_mail,car_code_mail);
            $fetch cur_temp_B0;
        }
        if (mail_count > 0)
        {
            rc = car208_subject(pre_car_code_mail,"0");
            if (rc!=M_CM_OK) {
                printf("error on car208_subject\n");
                EWRITE(userid,M_CM_DB_NOTOPEN,"�s�Wcar208b-car140���ɤ��d�Һ޲z�H�H�󥢱�");
                return rc;
            }
        }
        $close cur_temp_B0;
        $free  cur_temp_B0;
        printf("car208b-car140���ɤ��d�Һ޲z�Hend\n");
        printf("car208b-�w�t�o�g��޲z�Hbgn\n");
        strcpy(sKey,"");
        strcpy(pre_Key,"");
        $DECLARE cur_temp_B1 cursor for
          SELECT distinct ileader
            INTO $sKey
            FROM car208_mail
           ORDER by ileader;
        $open cur_temp_B1;
        $fetch cur_temp_B1;

        strcpy(pre_Key,sKey);
        mail_count=0;
        while(1)
        {
            if (SQLCODE==SQLNOTFOUND) break;
            printf("sKey[%s]\npre_Key[%s]\n",sKey,pre_Key); 
            
            if (strcmp(sKey,pre_Key)!=0)
            {
                rc = car208_subject(pre_Key,"1");
                if (rc!=M_CM_OK) {
                    printf("error on car208_subject\n");
                    EWRITE(userid,M_CM_DB_NOTOPEN,"�s�Wcar208b-�t�o�g��޲z�H�H�󥢱�");
                    return rc;
                }
                /*mail_count=0; sum_mail++;*/
            }

            strcpy(pre_Key,sKey);
            mail_count++;
            memset(fname,0x00,sizeof(fname));
            memset(filename,0x00,sizeof(filename));
            sprintf_s(fname, sizeof fname,"%s%s%s_�j���ҹO25�����_%s",yy2,mm2,dd2,trim(sKey));
            sprintf_s(filename, sizeof filename,"%s/rptftp/car_email/%s.csv",sApHome,fname);
            sprintf_s(nattachment, sizeof nattachment,"%s.csv",fname);

            fp=fopen(filename,"w");

            fprintf(fp,ftitle);
            car208_list("1",sKey," "," ");
            $fetch cur_temp_B1;
        }
        if (mail_count > 0)
        {
            rc = car208_subject(pre_Key,"1");
            if (rc!=M_CM_OK) {
                printf("error on car208_subject\n");
                EWRITE(userid,M_CM_DB_NOTOPEN,"�s�Wcar208b-�t�o�g��޲z�H�H�󥢱�");
                return rc;
            }
        }
        $close cur_temp_B1;
        $free  cur_temp_B1;
        printf("car208b-�w�t�o�g��޲z�Hend\n");
        printf("car208b-�w�t�o�g��޲z�H�D�޸�W�hbgn\n");
        /* �D�޸�W�h�D�ޤ����еo�H  EX ���g�z�ݥ���D��  �u�ݵo�e���M�� ���A�o�e��M��*/
        strcpy(sKey,"");
        strcpy(pre_Key,"");
        $DECLARE cur_temp_B2 cursor for
          SELECT distinct resp_name_mail
            INTO $sKey
            FROM car208_mail
           union
          SELECT distinct top_unit_mail
            INTO $sKey
            FROM car208_mail
           ORDER by 1;
        $open cur_temp_B2;
        $fetch cur_temp_B2 ;

        strcpy(pre_Key,sKey);
        mail_count=0;
        while(1)
        {
            if (SQLCODE==SQLNOTFOUND) break;
            printf("sKey[%s]\npre_Key[%s]\n",sKey,pre_Key); 
            
            if (strcmp(sKey,pre_Key)!=0)
            {
                rc = car208_subject(pre_Key,"2");
                if (rc!=M_CM_OK) {
                    printf("error on car208_subject\n");
                    EWRITE(userid,M_CM_DB_NOTOPEN,"�s�Wcar208b-�t�o�g��޲z�H�D�ޫH�󥢱�");
                    return rc;
                }
                /*mail_count=0; sum_mail++;*/
            }

            strcpy(pre_Key,sKey);
            mail_count++;
            memset(fname,0x00,sizeof(fname));
            memset(filename,0x00,sizeof(filename));
            sprintf_s(fname, sizeof fname,"%s%s%s_�j���ҹO25�����-�D_%s",yy2,mm2,dd2,trim(sKey));
            sprintf_s(filename, sizeof filename,"%s/rptftp/car_email/%s.csv",sApHome,fname);
            sprintf_s(nattachment, sizeof nattachment,"%s.csv",fname);

            fp=fopen(filename,"w");

            fprintf(fp,ftitle);
            car208_list("2",sKey,sKey," ");
            $fetch cur_temp_B2;
        }
        if (mail_count > 0)
        {
            rc = car208_subject(pre_Key,"2");
            if (rc!=M_CM_OK) {
                printf("error on car208_subject\n");
                EWRITE(userid,M_CM_DB_NOTOPEN,"�s�Wcar208b-�t�o�g��޲z�H�D�ޫH�󥢱�");
                return rc;
            }
        }
        $close cur_temp_B2;
        $free  cur_temp_B2;
        printf("car208b-�w�t�o�g��޲z�H�D�޸�W�hend\n");
    }
    else if (strncmp(userid,"car208c",7) == 0)
    {
        
        printf("car208c-car140���ɤ��d�Һ޲z�Hbgn\n");
        $DECLARE cur_temp_C0 cursor for
          SELECT distinct a.car_code2,b.detail
            INTO $sKey,$car_code_mail
            FROM car208_mail a, car_code b
           WHERE a.car_code2[1,3] = b.detail2[1,3]
             AND b.kind ='55'
           ORDER by 1,2;
        $open cur_temp_C0;
        $fetch cur_temp_C0;

        strcpy(pre_Key,sKey);
        strcpy(pre_car_code_mail,car_code_mail);
        mail_count=0;
        while(1)
        {
            if (SQLCODE==SQLNOTFOUND) break;
            printf("55:sKey[%s]pre_Key[%s]\ncar_code_mail[%s]pre_car_code_mail[%s]\n",
                    sKey,pre_Key,car_code_mail,pre_car_code_mail); 
            
            if (strcmp(car_code_mail,pre_car_code_mail)!=0)
            {
                rc = car208_subject(pre_car_code_mail,"0");
                if (rc!=M_CM_OK) {
                    printf("error on car208_subject\n");
                    EWRITE(userid,M_CM_DB_NOTOPEN,"�s�Wcar208c-car140���ɤ��d�Һ޲z�H�H�󥢱�");
                    return rc;
                }
            }
            mail_count++;
            if ((strcmp(pre_Key,sKey)!=0) || mail_count==1)
            {
                memset(fname,0x00,sizeof(fname));
                memset(filename,0x00,sizeof(filename));
                sprintf_s(fname, sizeof fname,"%s%s%s_%s_�j���ҽL�I",yy2,mm2,dd2,trim(sKey));
                
                /* �j��O�I�ҽL�I���Ӥ��e�ܧ� modify by 061476 (1100825022_SC1) */
                sprintf_s(filename, sizeof filename,"%s/rptftp/car_email/%s�ӻ����(�O�T�Ӥ�).csv",sApHome,fname);
                fp=fopen(filename,"w");
                fprintf(fp,ftitle);
                car208_list("0",sKey,"C1","C2");
                
                sprintf_s(filename, sizeof filename,"%s/rptftp/car_email/%s�ӻ����(�O�@�~).csv",sApHome,fname);
                fp=fopen(filename,"w");
                fprintf(fp,ftitle);
                car208_list("0",sKey,"C3","C4");
                
                /*1080118003_SC1_���t�Φ۰ʱH�o�U���j��L�I�~�����^���Ӫ��������`���W�٧אּ�i�����ӻ�O�T�Ӥ�I��xx/xx/xxx��j
                  �����~�����^���ӱH�e by 071004 2019.02.19 */
                /*
                sprintf_s(filename, sizeof filename,"%s/rptftp/car_email/%s�~�����^����.csv",sApHome,fname);
                fp=fopen(filename,"w");
                fprintf(fp,ftitle);
                car208_list("0",sKey,"C5","C5");
                */
                
                /*�O�I�ҽL�I�^���`��*/
                sprintf_s(filename, sizeof filename,"%s/rptftp/car_email/%s�^���`��.csv",sApHome,fname);
                sprintf_s(nattachment, sizeof nattachment,"%s.csv",fname);
                fp=fopen(filename,"w");

                car208_Summary(sKey);
            }    
            strcpy(pre_Key,sKey);
            strcpy(pre_car_code_mail,car_code_mail);
            $fetch cur_temp_C0;
        }
        if (mail_count > 0)
        {
            rc = car208_subject(pre_car_code_mail,"0");
            if (rc!=M_CM_OK) {
                printf("error on car208_subject\n");
                EWRITE(userid,M_CM_DB_NOTOPEN,"�s�Wcar208c-car140���ɤ��d�Һ޲z�H�H�󥢱�");
                return rc;
            }
        }
        $close cur_temp_C0;
        $free  cur_temp_C0;
        printf("car208C-car140���ɤ��d�Һ޲z�Hend\n");
        
        /* �ק�car140-57���O�ɮ״��Ѥ覡 (1070827002_SC1) */
        printf("car208C-�ӫO�޲z�H��bgn\n");
        
        strcpy(sKey,"");
        strcpy(pre_Key,"");
        $DECLARE cur_temp_C3 cursor for
          SELECT distinct b.detail
            INTO $sKey
            FROM car_code b
           WHERE b.kind ='57'
           ORDER by 1;
        $open cur_temp_C3;
        $fetch cur_temp_C3;

        strcpy(pre_Key,sKey);
        mail_count=0;
        while(1)
        {
            if (SQLCODE==SQLNOTFOUND) break;
            printf("sKey[%s]\npre_Key[%s]\n",sKey,pre_Key); 
            
            if (strcmp(sKey,pre_Key)!=0)
            {
                rc = car208_subject(pre_Key,"4");
                if (rc!=M_CM_OK) {
                    printf("error on car208_subject\n");
                    EWRITE(userid,M_CM_DB_NOTOPEN,"�s�Wcar208c-car140���ɤ��ӫO�޲z�H���H�󥢱�");
                    return rc;
                }
               
            }

            strcpy(pre_Key,sKey);
            mail_count++;
            if (mail_count > 0)
            {
                /* �ӫO���ӳ��@��*/
                memset(fname,0x00,sizeof(fname));
                memset(filename,0x00,sizeof(filename));
                
                sprintf_s(fname, sizeof fname,"%s%s%s�j���ҽL�I�ӻ����(�O�T�Ӥ�).csv",yy2,mm2,dd2);
                sprintf_s(filename, sizeof filename,"%s/rptftp/%s",sApHome,fname);
                sprintf_s(nattachment, sizeof nattachment,"%s",fname);
                fp=fopen(filename,"w");
                fprintf(fp,ftitle); 
                car208_list("0","*","C1","C2");             
                rc=rptftpinsert(pre_Key,"car208",fname);
                if (rc!=0) 
                {
                	sprintf_s(errmsg, sizeof errmsg,"%s�g�Jrptftplist���~",fname);
                	EWRITE(userid,rc,errmsg);
                	return rc;
                }
                
                sprintf_s(fname, sizeof fname,"%s%s%s�j���ҽL�I�ӻ����(�O�@�~).csv",yy2,mm2,dd2);
                sprintf_s(filename, sizeof filename,"%s/rptftp/%s",sApHome,fname);
                sprintf_s(nattachment, sizeof nattachment,"%s",fname);
                fp=fopen(filename,"w");
                fprintf(fp,ftitle);
                car208_list("0","*","C3","C4");
                rc=rptftpinsert(pre_Key,"car208",fname);
                if (rc!=0) 
                {
                	sprintf_s(errmsg, sizeof errmsg,"%s�g�Jrptftplist���~",fname);
                	EWRITE(userid,rc,errmsg);
                	return rc;
                }

                /*1080118003_SC1_���t�Φ۰ʱH�o�U���j��L�I�~�����^���Ӫ��������`���W�٧אּ�i�����ӻ�O�T�Ӥ�I��xx/xx/xxx��j
                  �����~�����^���ӱH�e by 071004 2019.02.19 */
                /*
                sprintf_s(fname, sizeof fname,"%s%s%s_�ӫO_�j���ҽL�I�~�����^����.csv",yy2,mm2,dd2);
                sprintf_s(filename, sizeof filename,"%s/rptftp/%s",sApHome,fname);
                fp=fopen(filename,"w");
                fprintf(fp,ftitle);
                car208_list("0","*","C5","C5");
                rc=rptftpinsert(pre_Key,"car208",fname);
                if (rc!=0) 
                {
                	sprintf_s(errmsg, sizeof errmsg,"%s�g�Jrptftplist���~",fname);
                	EWRITE(userid,rc,errmsg);
                	return rc;
                }*/

                sprintf_s(fname, sizeof fname,"%s%s%s_�ӫO_�j���ҽL�I�^���`��.csv",yy2,mm2,dd2);
                sprintf_s(filename, sizeof filename,"%s/rptftp/%s",sApHome,fname);
                sprintf_s(nattachment, sizeof nattachment,"%s",fname);
                fp=fopen(filename,"w");
                car208_Summary("*");
                rc=rptftpinsert(pre_Key,"car208",fname);
                if (rc!=0) 
                {
                	sprintf_s(errmsg, sizeof errmsg,"%s�g�Jrptftplist���~",fname);
                	EWRITE(userid,rc,errmsg);
                	return rc;
                }
            }
            $fetch cur_temp_C3;
        }
        if (mail_count > 0)
        {
            rc = car208_subject(pre_Key,"4");
            if (rc!=M_CM_OK) {
                printf("error on car208_subject\n");
                EWRITE(userid,M_CM_DB_NOTOPEN,"�s�Wcar208c-car140���ɤ��ӫO�޲z�H���H�󥢱�");
                return rc;
            }
        }
        $close cur_temp_C3;
        $free  cur_temp_C3;
        
        printf("car208C-�ӫO�޲z�H��end\n");
        
    }


    return M_CM_OK;
errexit:
   printf("ERROR:%d\n",SQLCODE);
   EWRITE(userid,0,"Proccess Failed !");
   return;
    
}
void car208_Summary(inventory_ncode)
$char *inventory_ncode;
{
 $int iCntA,iCntB,iCntC,iSumA,iSumB,iSumC,itot;
 $char sDateEnd[11],sColumn[2];
 $char feed_inventory_nbranch[41],feed_ideliver[11],feed_ndeliver[11],feed_nleader[11];
 
 
    iCntA = 0;iCntB = 0;iCntC = 0;iSumA = 0;iSumB = 0;iSumC = 0;itot = 0;
   /*
    sprintf_s(stmt_list, sizeof stmt_list,
            " SELECT  distinct a.inventory_nbranch,"
                   " case when trim(ideliver)='' then nissue else ideliver end, \n"
                   " case when trim(ideliver)='' then 'A' else 'B' end ,\n"
                   " (select b.nname from officer b where b.iofficer =case when trim(ideliver)='' then nissue else ideliver end), \n"
                   " (select c.nname from officer b,officer c where b.iofficer = case when trim(ideliver)=''  \n"
                   " then nissue else ideliver end and b.ileader = c.iofficer),  \n"
                   " (MDY(MONTH(today),1,YEAR(today)) -1 -3 UNITS MONTH)::date \n"
              " FROM car208_mail a WHERE car_code2 matches '%s' \n"
             " ORDER BY 1,5,2,4 \n"
              ,inventory_ncode);
    printf("stmt_list[%s]\n",stmt_list);
    $prepare pre_feed from $stmt_list;
    $declare cur_feed cursor for pre_feed;
    $open cur_feed;
    while(1)
    {
        $fetch cur_feed into
         $feed_inventory_nbranch,$feed_ideliver,$sColumn,$feed_ndeliver,$feed_nleader,$sDateEnd;
        if (SQLCODE==SQLNOTFOUND) break;
        strcpy(sDateEnd,cm_from_infdate_100(sDateEnd));
        itot++;
         
        if(itot==1)
        {
            sprintf_s(sFeedback, sizeof sFeedback,"%s�~%s��j���ҽL�I�^���`��(�ӻ�O�T�Ӥ�I��%s��),,,,,,,,,,,,\n",yy2,mm2,sDateEnd);
            fprintf(fp,sFeedback);
            fprintf(fp,",,,,,,,,,,,,\n");
            sprintf_s(sFeedback, sizeof sFeedback,"���,�ӻ�/�t�o�g��N��,�t�o�g��W��,�޲z�H�W��,�w�P��,���,�@�o,(�~��)�O30���������^,(����)�O�b�~������t�o,(����)�O�b�~��������^,�����s,�w���s,\n");
            fprintf(fp,sFeedback);
        }
        
        
        if (strcmp(sColumn,"A")==0)
        {
            
            $SELECT count(*) INTO $iCntA FROM car208_mail 
              WHERE car_code2 matches $inventory_ncode and mail_type ='C5' and cnt_lastday_char<=0
                and nissue = $feed_ideliver and trim(ideliver)='';
              
            $SELECT count(*) INTO $iCntB FROM car208_mail 
              WHERE car_code2 matches $inventory_ncode and mail_type in ('C3','C4') and trim(sfin_out_char) = ''
                and nissue = $feed_ideliver and trim(ideliver)='';
              
            $SELECT count(*) INTO $iCntC FROM car208_mail 
              WHERE car_code2 matches $inventory_ncode and mail_type='C1'
                and nissue = $feed_ideliver and trim(ideliver)='';
        }
        else
        {
            $SELECT count(*) INTO $iCntA FROM car208_mail 
              WHERE car_code2 matches $inventory_ncode and mail_type ='C5' and cnt_lastday_char<=0
                and ideliver = $feed_ideliver;
              
            $SELECT count(*) INTO $iCntB FROM car208_mail 
              WHERE car_code2 matches $inventory_ncode and mail_type in ('C3','C4') and trim(sfin_out_char) = ''
                and ideliver = $feed_ideliver;
              
            $SELECT count(*) INTO $iCntC FROM car208_mail 
              WHERE car_code2 matches $inventory_ncode and mail_type='C1'
                and ideliver = $feed_ideliver;
        }
            
        sprintf_s(sFeedback, sizeof sFeedback,"%s,%s,%s,%s,,,,%d,%d,%d,,,\n"
                         ,feed_inventory_nbranch,feed_ideliver,feed_ndeliver,feed_nleader,iCntA,iCntB,iCntC);
        printf("sFeedback[%s]\n",sFeedback);
        fprintf(fp,sFeedback);

        iSumA=iCntA+iSumA;
        iSumB=iCntB+iSumB;
        iSumC=iCntC+iSumC;
        iCntA = 0;iCntB = 0;iCntC = 0;
    }*/
    /* ��a �^�д��Ѫť��`���Y�i*/
    $SELECT first 1 (MDY(MONTH(today),1,YEAR(today)) -3 UNITS MONTH)::date -1
       INTO $sDateEnd
       FROM car208_mail;
       
    sprintf_s(sFeedback, sizeof sFeedback,"%s�~%s��j���ҽL�I�^���`��(�����ӻ�O�T�Ӥ�I��%s��),,,,,,,,,,,,\n",yy2,mm2,sDateEnd);
    fprintf(fp,sFeedback);
    fprintf(fp,",,,,,,,,,,,,\n");
    sprintf_s(sFeedback, sizeof sFeedback,"���,�ӻ�/�t�o�g��N��,�t�o�g��W��,�޲z�H�W��,�w�P��,���,�@�o,�����s,�w���s,\n");
    fprintf(fp,sFeedback);
    fprintf(fp,",,,,,,,,,\n");
    fprintf(fp,",,,,,,,,,\n");
    fprintf(fp,",,,,,,,,,\n");
    fprintf(fp,",,,,,,,,,\n");
    fprintf(fp,",,,,,,,,,\n");
    fprintf(fp,",,,,,,,,,\n");
    fprintf(fp,",,,,,,,,,\n");
    fprintf(fp,",,,,,,,,,\n");
    fprintf(fp,",,,,,,,,,\n");
    sprintf_s(sFeedback, sizeof sFeedback,"�X�p,,,,,,,,,\n");
    fprintf(fp,sFeedback);
    fprintf(fp,"PS.�d�Ҥw���s�̽Ъ��W�򥢤����ѡB�״ڳ�εn���@�o�����!,,,,,,,,,\n");
    /*fprintf(fp,"(���t�o�d���G�X�p,�i  (�����ӧY�i),,,,,,,,");*/
    fprintf(fp,",,,,,,,,,\n");
    fprintf(fp,",,,,,,,,,\n");
    fprintf(fp,",,�D�ޡG,,,,�g��G,,,\n");
    
    $close cur_feed;
    $free  cur_feed;
    fclose(fp);
}
void car208_list(cond_colA,cond_colB,cond_colC,cond_colD)
$char *cond_colA;
$char *cond_colB;
$char *cond_colC;
$char *cond_colD;
{   
    long iC5_diffDay,iC5_diffDay_1,iC5_diffDay_2;
    char sC5_tmpDay[11];
    char fp_tmp[5000];
    /*cond_colB 0.�d�Һ޲z�H 1.ileader  2.�W�h�D��  3.�D�ު��W�h�D��*/
    printf("cond_colA[%s]cond_colB[%s]\n",cond_colA,cond_colB);
    printf("cond_colC[%s]cond_colD[%s]\n",cond_colC,cond_colD);
    
    if (strncmp(cond_colA,"0",1)== 0)
        strcpy(stmt_list," select * from car208_mail where car_code2 matches ? and (mail_type matches ? or mail_type matches ? ) order by car_code2,inventory_nbranch,ileader,icard ;");
    else if (strncmp(cond_colA,"1",1)== 0)
        strcpy(stmt_list," select * from car208_mail where ileader = ? order by ileader,inventory_nbranch,icard ;");
    else if (strncmp(cond_colA,"2",1)== 0)
        strcpy(stmt_list," select * from car208_mail where resp_name_mail = ? or top_unit_mail = ? order by resp_name_mail,ileader,inventory_nbranch,icard ;");
    
    printf("stmt_list[%s]\n",stmt_list);
    $prepare pre_dtl from $stmt_list;
    $declare cur_dtl cursor for pre_dtl;
    if (strncmp(cond_colA,"0",1)== 0)
        $open cur_dtl using $cond_colB,$cond_colC,$cond_colD;
    else if (strncmp(cond_colA,"1",1)== 0)
        $open cur_dtl using $cond_colB;
    else
        $open cur_dtl using $cond_colB,$cond_colC;
    
    while(1)
    {
        $fetch cur_dtl
          into $mail_inventory_nbranch,$mail_inventory_ncode,$mail_issue_bh,$mail_icard,$mail_dissue,
               $mail_nissue,$mail_dreceive,$mail_icar_type,$mail_fstatus,$mail_ipolicy,$mail_sIdeliver_nbranch,
               $mail_ideliver,$mail_ndeliver,$mail_nleader,$mail_ileader,$mail_ddeliver,$mail_dalter,
               $mail_ialter,$mail_nalter,$mail_bh_ialter,$mail_iend_type,$mail_reprint_char,
               $mail_road_dentry,$mail_sDdeliver_old_100,$mail_sFin_out_char,$mail_limit_date_100,
               $mail_cnt_lastday_char,$mail_mail_type,$mail_car_code_mail,$mail_resp_name_mail,
               $mail_top_unit_mail;
        if (SQLCODE==SQLNOTFOUND) break;
        /*
        C5:�~�����^-�w�t�o���P�� �ݦA�z��X���^���������<=�t�Τ餧����멳��� �~���
        */
        iC5_diffDay = 0 ;
        iC5_diffDay_1 = 0;
        iC5_diffDay_2 = 0;
        if (strncmp(cond_colC,"C5",2) == 0) 
        {
            printf("C5==>%s/%s",yy2,mm2);
            sprintf_s(sC5_tmpDay, sizeof sC5_tmpDay,"%s/%s",yy2,mm2);
            strcpy(sC5_tmpDay,cm_ending_day_100(sC5_tmpDay));
            strcpy(mail_limit_date_100,trim(mail_limit_date_100));
            
            printf("sC5_tmpDay[%s]\n", sC5_tmpDay);
            printf("mail_limit_date_100[%s]\n", mail_limit_date_100);
            
            iC5_diffDay_1  = cm_ymd_edate(sC5_tmpDay);
            printf("sC5_tmpDay------------iC5_diffDay_1[%d]\n",iC5_diffDay_1);
            
            iC5_diffDay_2  = cm_ymd_edate(mail_limit_date_100);
            printf("mail_limit_date_100---iC5_diffDay_2[%d]\n", iC5_diffDay_2);
            
            iC5_diffDay = iC5_diffDay_2 - iC5_diffDay_1;
            printf(" ---------------------iC5_diffDay[%d]\n", iC5_diffDay);
        }
        if (iC5_diffDay<=0)
        fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,"
               "%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,"
               "%s,%s,%s,%s,%s,%s\n",
                mail_inventory_nbranch, mail_issue_bh, mail_icard, mail_dissue, mail_nissue,
                mail_dreceive, mail_icar_type, mail_fstatus, mail_ipolicy, mail_sIdeliver_nbranch,
                mail_ideliver, mail_ndeliver, mail_nleader, mail_ileader, mail_ddeliver, mail_dalter,
                mail_ialter, mail_nalter, mail_bh_ialter, mail_iend_type, mail_reprint_char,
                mail_road_dentry, mail_sDdeliver_old_100, mail_sFin_out_char, mail_limit_date_100,
                mail_cnt_lastday_char);
        
    }

    $close cur_dtl;
    $free  cur_dtl;
    fclose(fp);

    
}
long car208_subject(mail_receiver,mail_item)
$char *mail_receiver;
char *mail_item;
{   /*mail_item 0.�d�Һ޲z�H 1.ileader  2.�W�h�D��  3.�D�ު��W�h�D�� 4.�ӫO�ۦ�U��*/
    $int mail_csv_cnt;
    printf("mail_receiver[%s]mail_item[%s]\n",mail_receiver,mail_item);
    strcpy(nproject,"");
    strcpy(sContent,"");
    strcpy(email,"");
    strcpy(cc,"");
    strcpy(chinese_name,"");
    if ((strncmp(mail_item,"0",1) == 0)||(strncmp(mail_item,"1",1) == 0))
    {
    	$select email,chinese_name
    	   into $email,$chinese_name
    	   from personal:asempl
    	  where empl_no = $mail_receiver;
    }
    else
    {
    	/*$select email,chinese_name
    	   into $email,$chinese_name
    	   from personal:asempl
    	  where empl_no = $mail_receiver
    	    and job_level < '130';*/
    	/* 1110428001_SC1_¾��¾�Žվ� */
    	/* 0.���ƪ�, 1.�`�g�z, 2.���`�g�z, 3.��z, 5.���ǥD��, 7.��ťD��, 9.�Dñ�֤H�� */    
    	$select email,chinese_name
    	   into $email,$chinese_name
    	   from personal:asempl
    	  where empl_no = $mail_receiver
    	    and job_type >= '5';
    }
    
    if (strlen(trim(email)) != 0)
    {
    	strcpy(email,trim(email));
    	strcat(email,"@tmnewa.com.tw");
    	printf("email[%s]chinese_name[%s]\n",email,chinese_name);
    }
    
    if (strncmp(userid,"car208a",7) == 0)
    {
        /* mail�D�� */
        strcpy(cc,"chun.ni.chu@tmnewa.com.tw");
        sprintf_s(nproject, sizeof nproject,"�j��O�I�Ҥw�t�o���P���M�d����(%s/%s/%s)",yy2,mm2,dd2);
        sprintf_s(sContent, sizeof sContent,
        "�˷R�� %s �z�n</P>\n"
        "       �q���z�A���󤤬��j��O�I�Ҥw�t�o���P�����ӡC</P>\n"
        "       �Ш�U�d���q���ϥΫO�I�ұ��p�i��M�d�@�~�C</P>\n"
        "       �p��������D�Ь��ӤH�O�I���~�Ȧ�F��C</P>\n"
        "       ����!</P>\n",chinese_name);
        ctxt.loc_loctype = LOCMEMORY;
        ctxt.loc_buffer = sContent;
        ctxt.loc_bufsize = 9000;
        ctxt.loc_size =  strlen(sContent) + 1;
        mail_csv_cnt = 1;
    }
    else if (strncmp(userid,"car208b",7) == 0)
    {
        /* mail�D�� */
        sprintf_s(nproject, sizeof nproject,"�O25��j��O�I�Ҥw�t�o���P�����^����(%s/%s/%s)",yy2,mm2,dd2);
        if ((strncmp(mail_item,"0",1) == 0)||(strncmp(mail_item,"1",1) == 0))
        sprintf_s(sContent, sizeof sContent,
        "�˷R�� %s �z�n</P>\n"
        "       �q���z�A���󤤬��j��O�I�Ҥw�t�o���P�����ӡC</P>\n"
        "       �Ш�U�d���q���ϥΫO�I�ұ��p�i�榬�^�@�~�C</P>\n"
        "       �p��������D�Ь��ӤH�O�I���~�Ȧ�F��C</P>\n"
        "       ����!</P>\n",chinese_name);
        else
        sprintf_s(sContent, sizeof sContent,
        "�˷R�� %s�D�� �z�n</P>\n"
        "       �q���z�A���󤤬��@�Q���j��O�I�Ҥw�t�o���P�����^���ӡA�ѰѾ\\�C </P>\n"
        "       �w�P�ɳq�����ݺ޲z�H�Υd�Һ޲z���f�C</P>\n"
        "       �p��������D�Ь��ӤH�O�I���~�Ȧ�F��C</P>\n"
        "       ����!</P>\n",chinese_name);
        
        ctxt.loc_loctype = LOCMEMORY;
        ctxt.loc_buffer = sContent;
        ctxt.loc_bufsize = 9000;
        ctxt.loc_size =  strlen(sContent) + 1;
        mail_csv_cnt = 1;
    }
    else if (strncmp(userid,"car208c",7) == 0)
    {
        /* mail�D�� */
        sprintf_s(nproject, sizeof nproject,"%s�~%s��j��O�I�ҽL�I����",yy2,mm2);       
        if (strncmp(mail_item,"4",1) == 0)
        {
        sprintf_s(sContent, sizeof sContent,
        "�˷R�� %s �z�n</P>\n"
        "       �t�ζȱH�o�l��q�����ӫO�����f�H���A</P>\n"
        "       %s�~%s��j���ҽL�I�`���ӡA���CMN202�ۦ�h�U���A�����H���ɡC</P>\n"
        "       ����!</P>\n",chinese_name,yy2,mm2);
        strcpy(fname," ");
        strcpy(nattachment," ");
        }
        else
        {
        sprintf_s(sContent, sizeof sContent,
        "�˷R�� %s �z�n</P>\n"
        "       �q���z�A���󤤬�%s�~%s��j��O�I�ҽL�I���ӡC</P>\n"
        "       �Ш�U�g��/�޲z/�֫O�H���i��L�I�@�~�A�é�15��e�J��q���ϥΫO�I�ҽL�I</P>\n"
        "       ���G�e�e ���D��ñ�֫��k�ɳƬd,�ǿ�ƥ��ܭӫO���~�Ȧ�F��C</P>\n"
        "       �p��������D�Ь��ӤH�O�I���~�Ȧ�F��C</P>\n"
        "       ����!</P>\n",chinese_name,yy2,mm2);
        mail_csv_cnt = 4;
        }
        ctxt.loc_loctype = LOCMEMORY;
        ctxt.loc_buffer = sContent;
        ctxt.loc_bufsize = 9000;
        ctxt.loc_size =  strlen(sContent) + 1;
        
    }

    if (strlen(trim(email)) != 0)
    {
    	
        /*=====����=====*/    	
    	$INSERT INTO batchemail
    	  (project_id, mail_date, receiver_email, receiver_name, cc,
    	   content, key, mail_count, nsubject ,nattachment)
    	VALUES
    	  ('CAR208', today, $email, $chinese_name, $cc,
           $ctxt, $fname, $mail_csv_cnt , $nproject, $nattachment);                     
           
        /*=====����=====*/           

        /*if(strcmp(email,"Ting.Hsuan.Lai@tmnewa.com.tw")==0)
        {
    	    $INSERT INTO batchemail
    	      (project_id, mail_date, receiver_email, receiver_name, cc,
    	       content, key, mail_count, nsubject)
    	    VALUES
    	      ('car208', today, $email, $chinese_name, " ",
               $ctxt, $fname, $mail_csv_cnt , $nproject); 
            $INSERT INTO batchemail
    	      (project_id, mail_date, receiver_email, receiver_name, cc,
    	       content, key, mail_count, nsubject)
    	    VALUES
    	      ('car208', today, 'brian.wang@tmnewa.com.tw', '������', " ",
               $ctxt, $fname, $mail_csv_cnt , $nproject);
        }    
        if(strcmp(email,"tzuhanhung@tmnewa.com.tw")==0)
        {
    	    $INSERT INTO batchemail
    	      (project_id, mail_date, receiver_email, receiver_name, cc,
    	       content, key, mail_count, nsubject)
    	    VALUES
    	      ('car208', today, 'Ting.Hsuan.Lai@tmnewa.com.tw', '��xޱ', " ",
               $ctxt, $fname, $mail_csv_cnt , $nproject); 
            $INSERT INTO batchemail
    	      (project_id, mail_date, receiver_email, receiver_name, cc,
    	       content, key, mail_count, nsubject)
    	    VALUES
    	      ('car208', today, 'brian.wang@tmnewa.com.tw', '������', " ",
               $ctxt, $fname, $mail_csv_cnt , $nproject);
        }      	   
         */     
    }


    if (sqlca.sqlerrd[2] == 0)
    {
        printf("batchemail err\n");
    }
    return M_CM_OK;    
              
errexit:
    printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}
/*----------------------�j��O�I�@�o�M��--------------------------*/
long car208_compulsory_list()
{
	 $char sIcard[21],sIcard_bgn[21],sIcard_end[21],sDalter[11];
	 $char sDalter1[11],sFstatus[2],sIcar_type[31],sRemark[21];
	 $varchar sNbranch[41];
	 $char sNname[11];
	 $char sfilename[101],stitle[1000],sErrmsg[200],sIcard_repeat[21];
	 $char stmt[1000],stmt1[1000],Fstatus[31],sFstatus1[2];
	 long rtn;

	 $WHENEVER SQLERROR GOTO errexit;
	 
	  if (db_select(DBName) == FALSE) {
        EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
        return M_CM_DB_NOTOPEN;
    }
	  
	  $create temp table car208T(
	     icard          char(20),   /* �j��O�Ҹ� */
	     dalter         date,       /* ���ʤ�� */
	     invalid_id     char(1),    /* �@�o��]�N�X */
	     icard_repeat   char(20),   /* �Ƶ� (��ƥ��T�έ��ƥd��)*/
	     nbranch        char(40),   /* ���ʳ�� */
	     nname          char(10)    /* ���ʤH�� */
	  )with no log;
	  
	  printf("changbgn[%s],changend[%s]\n",changbgn,changend);
	  printf("fstatus[%s]\n",cardstatus1);
	  
	  if(cartype[0] == '1'){
	  	strcpy(sIcar_type,"not in ('01','02','32','34','35')");
	  }
	  else if(cartype[0] == '2'){
	  	strcpy(sIcar_type,"in ('01','02','32','34','35')");
	  }
	  else{
	  strcpy(sIcar_type,"MATCHES '*'"); }
	  
	  printf("icar_type[%s]\n",sIcar_type);
	  
	  if (cardstatus1[0] == 'Z')
    {
    	 strcpy(Fstatus,"in ('8','A','B','C','D','E')");
    }
    else
    {
    	 strcpy(Fstatus,"MATCHES '");
    	 strcat(Fstatus,trim(cardstatus1));
    	 strcat(Fstatus,"'");
    }	
	  printf("Fstatus[%s]\n",Fstatus);
	  sprintf_s(stmt1, sizeof stmt1,"SELECT a.icard,a.dalter,a.fstatus,a.icard_repeat,"
	               " (SELECT CASE WHEN b.iply_branch = c.iapp_unit THEN b.nbranch ELSE (SELECT nchi_full FROM branch WHERE ibranch = c.iapp_unit) END FROM sa_branch_type b , officer c WHERE b.ibranch = c.iquota AND c.iofficer = a.ialter), "
	               " (SELECT nname FROM officer WHERE iofficer = a.ialter) "
	               "  FROM compulsory_card a"
	               " WHERE a.icar_type %s"
	               "   AND a.dalter >= '%s'"
	               "   AND a.dalter <= '%s'"
	               "   AND a.fstatus %s",sIcar_type,changbgn,changend,Fstatus);
	  printf("stmt[%s]\n",stmt1);             
	  $PREPARE  compulsory_data FROM $stmt1;
    $DECLARE  invalid_cur CURSOR FOR compulsory_data;   
    $OPEN     invalid_cur;             
	  
	  for(;;)
	  {
	    $FETCH invalid_cur INTO $sIcard,$sDalter,$sFstatus,$sIcard_repeat,
	                            $sNbranch,$sNname;
	    
	    if (SQLCODE == SQLNOTFOUND) break;
	     
	    strcpy(sFstatus,trim(sFstatus));
	    if(strcmp(sFstatus,"8") == 0)
	    {
	      strcpy(sFstatus1,"6");
	    }
	    else if(strcmp(sFstatus,"A") == 0)
	    {
	      strcpy(sFstatus1,"1");
	    }
	    else if(strcmp(sFstatus,"B") == 0)
	    {
	      strcpy(sFstatus1,"2");
	    }
	    else if(strcmp(sFstatus,"C") == 0)
	    {
	      strcpy(sFstatus1,"3");
	    }
	    else if(strcmp(sFstatus,"D") == 0)
	    {
	      strcpy(sFstatus1,"4");
	    }
	    else if(strcmp(sFstatus,"E") == 0)
	    {
	      strcpy(sFstatus1,"5");
	    }
	    
	    $INSERT INTO car208T VALUES($sIcard,$sDalter,$sFstatus1,$sIcard_repeat,$sNbranch,$sNname);  
	  }
	  
	  $CLOSE invalid_cur;
    $FREE  invalid_cur;   
	  
	     strcpy(sfilename,"�j��O�I�ҧ@�o�M��");
       strcpy(stitle,"�{���N��:CAR208\t");
       strcat(stitle,sfilename);
       strcat(stitle,"\n");
       strcat(stitle,"\t���q�O:�s�w�F�ʮ��W�����O�I���q");
       strcat(stitle,"\n");
       strcat(stitle,"\t�@�o����:");
       strcat(stitle,changbgn);
       strcat(stitle,"��");
       strcat(stitle,changend);
       strcat(stitle,"\n");
       strcat(stitle,"\t");
         
       strcat(stitle,"�j��O�I�Ҹ�\t�@�o���\t�@�o��]�N�X\t�Ƶ�(���T�O�d���έ��Ƨ�O�d��)\t�@�o���\t�@�o�H��\t");
       sprintf_s(stmt, sizeof stmt,"SELECT icard,to_char(dalter,'%%Y/%%m/%%d'),invalid_id,icard_repeat,nbranch,nname"
                    "  FROM car208T ");   
	   	 
	      rtn = unload_file(outputf, " ", sfilename, stitle, stmt);
	      printf("rtn[%ld]\n",rtn);   
        if (rtn != SUCCESS)
        { 
            sprintf_s(sErrmsg, sizeof sErrmsg, " %s �ɮ׵L�k���� ", sfilename);
            EWRITE(userid, rtn, sErrmsg);
            exit(1);
        }       
        return M_CM_OK;    
              
errexit:
    printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;      
}
/*-------------------------------�Ϳ��@�o�M��----------------------------------*/
long car208_compulsory_ks()
{
	  $char date[11],dToday[11],nyy[4],nmm[3],ndd[3],Fstatus[50],stmt[2048];
	  $char sDalter[8],sIbus_location[11],sIcard[21],sFstatus[3],sType[2];
	  $char sIcar_type[31];
	  $int return_code,qcnt,rc;
	  long t;
	  char  filename[50],fname[50],errmsg[81];
	   
	  $WHENEVER SQLERROR GOTO errexit;
	 
	  if (db_select(DBName) == FALSE) {
        EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
        return M_CM_DB_NOTOPEN;
    }
    
    rc = getApHome(sApHome);
	  if (rc < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		return rc;
    }
    
    t = cm_today();
    strcpy(date,cm_edate_str(t));  
    strcpy(dToday,cm_from_infdate_100(date));
    cm_split_ymd_100(dToday,nyy,nmm,ndd);
    printf("changbgn[%s],changend[%s]\n",changbgn,changend);
    
    if(cartype[0] == '1'){
	  	strcpy(sIcar_type,"not in ('01','02','32','34','35')");
	  }
	  else if(cartype[0] == '2'){
	  	strcpy(sIcar_type,"in ('01','02','32','34','35')");
	  }
	  else{
	  strcpy(sIcar_type,"MATCHES '*'"); }
	  printf("icar_type[%s]\n",sIcar_type);
    
    if (cardstatus1[0] == 'Z')
    {
    	 strcpy(Fstatus,"in ('A','B','C','D','E','8','3')");
    }
    else
    {
    	 strcpy(Fstatus,"MATCHES '");
    	 strcat(Fstatus,trim(cardstatus1));
    	 strcat(Fstatus,"'");
    }	
   
    /* �@�o���A 00 = 3,01 = A B C D, 02 = 8 */
    if (cardclass[0] == '1')
    {
       sprintf_s(stmt, sizeof stmt,"SELECT year(a.dalter)-1911||to_char(a.dalter,'%%m%%d'), "
                     "      (SELECT ibus_location FROM officer WHERE iofficer = a.ideliver), "
                     "      'G',a.icard,decode(a.fstatus,'3','00','A','01','B','01','C','01','D','01','E','01','8', "
                     "      '02',' ')  "
                     " FROM compulsory_card a  "
                     "WHERE a.dalter between '%s' and '%s'  "
                     "  AND a.icard[3,4] = 'CA'  "
                     "  AND a.icar_type %s  "
                     "  AND a.fstatus %s ",changbgn,changend,sIcar_type,Fstatus);
    }
    else if (cardclass[0] == '2')
    {
       sprintf_s(stmt, sizeof stmt,"SELECT year(a.dalter)-1911||to_char(a.dalter,'%%m%%d'), "
                     "      (SELECT ibus_location FROM officer WHERE iofficer = a.ideliver), "
                     "      'I',a.icard,decode(a.fstatus,'3','00','A','01','B','01','C','01','D','01','E','01','8', "
                     "      '02',' ')  "
                     " FROM card a  "
                     "WHERE a.dalter between '%s' and '%s'  "
                     "  AND a.icard[3,3] = 'A'  "
                     "  AND a.icar_type %s  "
                     "  AND a.fstatus %s ",changbgn,changend,sIcar_type,Fstatus);
    }
    else
    {
       sprintf_s(stmt, sizeof stmt,"SELECT year(a.dalter)-1911||to_char(a.dalter,'%%m%%d'), "
                    "       (SELECT ibus_location FROM officer WHERE iofficer = a.ideliver), "
                    "       'G',a.icard,decode(a.fstatus,'3','00','A','01','B','01','C','01','D','01','E','01','8', "
                    "       '02',' ')  "
                    "  FROM compulsory_card a  "
                    " WHERE a.dalter between '%s' and '%s'  "
                    "   AND a.icard[3,4] = 'CA'  "
                    "   AND a.icar_type %s  "
                    "   AND a.fstatus %s  "
                    " UNION  "
                    "SELECT year(a.dalter)-1911||to_char(a.dalter,'%%m%%d'), "
                    "       (SELECT ibus_location FROM officer WHERE iofficer = a.ideliver), "
                    "       'I',a.icard,decode(a.fstatus,'3','00','A','01','B','01','C','01','D','01','E','01','8', "
                    "       '02',' ')  "
                    "  FROM card a  "
                    " WHERE a.dalter between '%s' and '%s'  "
                    "   AND a.icard[3,3] = 'A'  "
                    "   AND a.icar_type %s  "
                    "   AND a.fstatus %s ",changbgn,changend,sIcar_type,Fstatus,changbgn,changend,sIcar_type,Fstatus);
     }
     printf("stmt[%s]\n",stmt);
     $PREPARE compulsory_ks FROM $stmt;
     $DECLARE ks_cur CURSOR FOR compulsory_ks;
     $OPEN ks_cur;
     qcnt = 0;
   
     strcpy(filename," ");
     sprintf_s(fname, sizeof fname,"car208_TO_KS_%s%s%s.txt",nyy,nmm,ndd);
     sprintf_s(filename, sizeof filename,"%s/rptftp/%s",sApHome,fname);
     sprintf_s(nattachment, sizeof nattachment,"%s",fname);
     printf("�Ϳ��@�o�M��[%s]\n",filename);
     fp=fopen(filename,"w");
   
     for(;;)
     {
       $FETCH ks_cur INTO $sDalter,$sIbus_location,$sType,$sIcard,$sFstatus;
       if (SQLCODE != 0) break;
       strcpy(sIbus_location,trim(sIbus_location));
       strcpy(sIcard,trim(sIcard));
       qcnt++;
       fprintf(fp,"%s,%s,%s,%s,%s,\n",sDalter,sIbus_location,sType,sIcard,sFstatus);      
     }
     $CLOSE ks_cur;
     $FREE  ks_cur;
     
     fclose(fp);

     rc=rptftpinsert(userid,"car208",fname);
     if (rc!=0) {
         sprintf_s(errmsg, sizeof errmsg,"%s�g�Jrptftplist���~",fname);
         EWRITE(userid,rc,errmsg);
         return rc;
     }

    sprintf_s(msgbuf, sizeof msgbuf,"�Ϳ��@�o�M��:%s[%d]\n",filename,qcnt);

    EWRITE(userid,M_CM_OK,msgbuf);

    return M_CM_OK;

errexit:
    printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;         
}
/*----------------------------------------------------------------------------*/
char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
        char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
        char sTmp_db_name[21];

        sTmp_db_name[0]='\0';
        if (*sIpolicy != '\0' && *sIpolicy !=' ')
        {
           sTmp_db_name[0]='\0';
           strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
           strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
                  USE_BRANCH_ID));
           strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
        }
  return sTmp_db_name;
}
/********************************************************************************************/	  	  
