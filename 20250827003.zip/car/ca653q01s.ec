/********************************************
 *           �F�d�ܰʲέp����
 ��
 * Program : ca653q01s.ec 
 *********************************************/

#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "print.h"
#include "is_def.h"

#include "commsgs.h"
#include "carmsgs.h"
#include "gls_array.h"
#include "gls_const.h"

#include "cmnmsgs.h"
#include "carmsgs.h"
#include "carmsg.h"
#include "safeclib.h"
/*---------------------------------------------------------------------*/
extern char RPTDIR[];

$struct dep_t {
    char ibranch[3];
    char nchi_abv[13];
 };
$struct dep_t dep[MAXROWITEMS]; 

$char issdtbgn[11],issdtend[11];
$char cardclass[2];

char s_issdtbgn[11],s_issdtend[11];

$char Iclaim[21], Daccident[21], Iacc_reason[4], Dcreate[11], Dcreate_show[20];
$char Ipolicy[21], Dpolicy[11], Dply_begin[11], Dply_end[11];
$char Iassured[13], Nassured[81], Itag[13], Iengine[26];
$char Pdmg_iins_type[21], Pdmg_comparison[2];
$char Plia_iins_type[21], Plia_comparison[2];
$char Punknown_iins_type[21], Punknown_comparison[2];
$char Iquota[7], Ncode[81], Nbranch[81], Iofficer[11], Nleader[11], Nname[11];
$char Ibranch_in[3], Fcard_class[2], Icar_type[3];
$char stmt_buf[2048], stmt[2048], Nstmt[2048], stmt1[1024], stmt2[1024],stmt3[1024];
$char tmp_fulldb[64], fulldb[64];
$char Y_or_N[2], stmt_bufXX[64], stmt_bufmot[64];
$char dply_end[11], dcreate[11], m_mstl[10], Iestimate[21], capture[3];
$char Pdmg_reason[21], Plia_reason[21], Punknown_reason[21];
$char Iquery_num_damage[21], Iquery_num[21], Iquery_num_unknown[21];
$char Dappraisal[11], Dentry[11], Ilast_ply[21], Nequipment[31];
$double Pdmg_acc_before, Pdmg_acc_after = 0, Plia_acc_before, Plia_acc_after = 0, Punknown_acc_before, Punknown_acc_after = 0;
$double Pfactor_min = 0, Pcomp_factor_min = 0;

void get_data();

/* standard data declaration */
$char DBName[5],userid[11],sApHome[30],msgbuf[1000];
$char FormTp[3];
char outputf[N_FILE+1];
char yy[4],mm[3],dd[3];
char fOpt[2], fTmpsTr[21];
int  bcount,ycount;
int  TotRows=0;
static int pagenum=1;
DBinfo  *list;
int   count_db;

/* end of standard data */
char *get_car_full_db();

long car653_build();
void car653_title();
void car653_body();
void put_body();

#define  NEXTPAGE   5

/*-------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
 int rc;

 
 batchinit();
 strcpy(DBName,isNULLstr(argv[1]));
 strcpy(userid,isNULLstr(argv[2]));
 
 strcpy(s_issdtbgn,isNULLstr(argv[3]));
 strcpy(s_issdtend,isNULLstr(argv[4]));
 strcpy(fTmpsTr,isNULLstr(argv[5]));
 strcpy(fOpt,isNULLstr(argv[6]));
 
 
 strcpy(outputf,isNULLstr(argv[7]));

 strcpy(issdtbgn,cm_to_infdate(s_issdtbgn));
 strcpy(issdtend,cm_to_infdate(s_issdtend));
 
 if (strcmp(fOpt,"B") == 0)
 		strcpy(Ipolicy,trim(fTmpsTr));		/* �H�O�渹�d�� */
 else
 		strcpy(cardclass,trim(fTmpsTr));	/* �H���O(�j��/���N/����)�d�� */
 		
 printf("%s %s %s\n",s_issdtbgn,s_issdtend,cardclass);
 printf("%s %s %s %s\n",issdtbgn,issdtend,fOpt,fTmpsTr);


 if (strcmp(fOpt,"B") == 0)
 {
 	rc = car653_QryByPolicy();
 	if (rc != M_CM_OK) 
 	return rc;
 }
 else
 {
 	car653_build();
 	if ((rc=save_form_info(F_BLK1,"CA",653,userid,FormTp,TotRows,outputf))<0)
 	EWRITE(userid,rc,"save_form_info failed");
 }
}

/*-----------------------------------------------------------------*/
long car653_build()
{
   char BodyFile [N_FILE+1];
   char TitleFile[N_FILE+1];
  $char BodyFmt [N_FILE+1];
  $char TitleFmt[N_FILE+1];

  $int StartRow,TitleRow;
  $int ItemRow,TotColumn;
  $int PgLine,Width;
  int  i=0,j;

  if (db_select(DBName) == False)
  {
      EWRITE(userid,M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return 0;
  }

  $SELECT nTitle_Fmt, nBody_Fmt,   kStart_Row, kTitle_Row, kItem_Row,
          kTot_col,   kPgNum_Line, kWidth,     iForm_Tp
     INTO $TitleFmt,  $BodyFmt,    $StartRow,  $TitleRow,  $ItemRow,
          $TotColumn, $PgLine,     $Width,     $FormTp
     FROM Form
    WHERE ksys_grp="CA" AND kPgmID = 653;

  strcpy(TitleFmt,rtrim(TitleFmt));
  strcpy(BodyFmt,rtrim(BodyFmt));
  sprintf_s(TitleFile, sizeof TitleFile,"%s.ti",outputf);
  sprintf_s(BodyFile, sizeof BodyFile,"%s.bd",outputf);

  rgu_init_report(TitleFmt,TitleFile);
  car653_title();
  rgu_finish_report();

  rgu_init_report(BodyFmt,BodyFile);
  car653_body();
  rgu_finish_report();
}

/*-----------------------------------------------------------------------*/
void car653_title()
{
  rgu_put_head_string(1, cm_sysd_cdate_100(cm_get_sysd()));   /* get_currdt */
  printf("151: %s\n",cm_sysd_cdate_100(cm_get_sysd()));

  cm_split_ymd_100(s_issdtbgn,yy,mm,dd);printf("%s %s %s\n",yy,mm,dd);
  rgu_put_head_string(1, yy);
  rgu_put_head_string(1, mm);
  rgu_put_head_string(1, dd);

  cm_split_ymd_100(s_issdtend,yy,mm,dd);printf("%s %s %s\n",yy,mm,dd);
  rgu_put_head_string(1, yy);
  rgu_put_head_string(1, mm);
  rgu_put_head_string(1, dd);
  rgu_put_head();
}

/*-------------------------------------------------------------------------*/
void car653_body()
{
  $WHENEVER SQLERROR GOTO errexit; 
  $SET LOCK MODE TO WAIT;
	  
  $DECLARE acur CURSOR FOR
    SELECT DISTINCT a.iclaim, a.dcreate::date as dcreate, b.ibranch_in
      FROM ca_clm_upd_log a, ca_clm_process b
     WHERE a.iclaim = b.iclaim
       AND(a.dcreate::date BETWEEN $issdtbgn AND $issdtend)
       AND (a.ndata_before = '1' AND a.ndata_after != '1')
     ORDER BY 1;

  $OPEN acur;
  while (1) {
     $FETCH acur INTO $Iclaim, $Dcreate, $Ibranch_in;
     
     if (SQLCODE == SQLNOTFOUND) break;
     printf("iclaim[%s],dcreate[%s],ibranch[%s]\n",Iclaim, Dcreate, Ibranch_in);
     
     /*�߮׸����O��*/
     sprintf_s(stmt_buf, sizeof stmt_buf,
       " SELECT first 1 dcreate "
       "   FROM ca_clm_upd_log "
       "  WHERE iclaim = '%s' "
       "    AND dcreate::date = '%s' "
       "  ORDER BY 1 DESC ", Iclaim, Dcreate);
     $PREPARE sid000 FROM $stmt_buf;
     $EXECUTE sid000 INTO $Dcreate_show;
     
     /* �ư�Z1205802�BZ12058�BZ1205805���s�иg��N��
        add by sylvia 109.09.03 ( 1090610013_SC1) */
     strcpy(fulldb, get_full_dbname(Ibranch_in)); 
     sprintf_s(stmt_buf, sizeof stmt_buf,
      " SELECT a.daccident, a.iacc_reason, a.ipolicy, a.fcard_class "
      "   FROM %s:appraisal a, %s:ply_relation b "
      "  WHERE a.iclaim = '%s' "
      "    AND a.ipolicy = b.ipolicy "
      "    AND a.fcard_class matches '%s' "
      "    AND a.ipolicy[6,7] NOT IN ('VW','EB','TV')"
      "    AND b.iofficer NOT IN (select iofficer FROM officer WHERE fprop = 'E') "
      "    AND b.iofficer not in ('Z1205802','Z12058','Z1205805') "
      "    AND NOT EXISTS (SELECT ipolicy FROM %s:ply_relation "
      "                     WHERE ipolicy = a.ipolicy "
      "    AND icar_type IN (SELECT icode FROM car_type WHERE fclass = '1'  AND icar_grp = '1') "
      "                         AND fcard_class = '1' ) "
     	,fulldb, fulldb, Iclaim, cardclass, fulldb);
     $PREPARE sid001 FROM $stmt_buf;
     $EXECUTE sid001 INTO $Daccident, $Iacc_reason, $Ipolicy,  $Fcard_class;     
     if (SQLCODE == SQLNOTFOUND) continue;
                     
     strcpy(tmp_fulldb, get_car_full_db(Ipolicy)); /*����*/
     sprintf_s(stmt_buf, sizeof stmt_buf,
     	" SELECT icar_type "
     	"   FROM %s:ply_relation "
     	"  WHERE ipolicy = '%s' " ,tmp_fulldb, Ipolicy);
       	$PREPARE sid3 FROM $stmt_buf;
     	$EXECUTE sid3 INTO $Icar_type;      
     if (SQLCODE == SQLNOTFOUND) break;
     
     strcpy(tmp_fulldb, get_car_full_db(Ipolicy));
     sprintf_s(stmt_buf, sizeof stmt_buf,
     	" SELECT a.dpolicy, decode(b.fassured,'2','Y','4','Y','6','Y','N') as y_or_n  "
     	"   FROM %s:ply_relation a, %s:policy  b   "
     	"  WHERE a.ipolicy = b.ipolicy  "
     	"    AND a.ipolicy = '%s' ",tmp_fulldb, tmp_fulldb, Ipolicy);
       	$PREPARE sid002 FROM $stmt_buf;
     	$EXECUTE sid002 INTO $Dpolicy, $Y_or_N;      
     if (SQLCODE == SQLNOTFOUND) break;
          
     strcpy(tmp_fulldb, get_car_full_db(Ipolicy));
     sprintf_s(stmt_buf, sizeof stmt_buf,
       " SELECT dply_begin, dply_end, iassured, nassured, itag, iengine  "
        "  FROM %s:adjustment_ply      "
        " WHERE iclaim = ? ",tmp_fulldb);  
     $PREPARE sid003 FROM $stmt_buf;
     $EXECUTE sid003 INTO $Dply_begin, $Dply_end, $Iassured, $Nassured, $Itag, $Iengine using $Iclaim;
     
     if (SQLCODE == SQLNOTFOUND) 
     {
     	strcpy(Dply_begin," ");
     	strcpy(Dply_end," ");
     	strcpy(Iassured," ");
     	strcpy(Nassured," ");
     	strcpy(Itag," ");
     	strcpy(Iengine," ");
     }
        
     strcpy(dply_end,cm_from_infdate_100(Dply_end));
     strcpy(dcreate,cm_from_infdate_100(Dcreate));
     
     if(strcmp(Fcard_class,"1") == 0)
     {
     	strcpy(tmp_fulldb, get_car_full_db(Ipolicy));
     	sprintf_s(stmt_buf, sizeof stmt_buf,
         " SELECT min(dappraisal) dappraisal"
         "   FROM %s:ca_app_victim_hist "
         "  WHERE iclaim = '%s' ", tmp_fulldb, Iclaim);
       $PREPARE sid200 FROM $stmt_buf;
       $EXECUTE sid200 INTO $Dappraisal;  	
     }
     else
     {
     	strcpy(tmp_fulldb, get_car_full_db(Ipolicy));
     	sprintf_s(stmt_buf, sizeof stmt_buf,
         " SELECT min(dappraisal) dappraisal"
         "   FROM %s:app_ins_type_hist "
         "  WHERE iclaim = '%s' ", tmp_fulldb, Iclaim);
       $PREPARE sid200 FROM $stmt_buf;
       $EXECUTE sid200 INTO $Dappraisal;
     }    
      
     if (strcmp(dply_end,dcreate) == 1 || strcmp(dply_end,dcreate) == 0)
     {
     	get_data();
     	if(strcmp(trim(Pdmg_reason),"") == 0 && strcmp(trim(Plia_reason),"") == 0 && strcmp(trim(Punknown_reason),"") == 0)
     	{
     		continue;
     	}	
     }

     /*�����O��*/
     printf("\n �����O�� \n");
     if (strcmp(Y_or_N,"Y") == 0)/*�k�H ID+����*/
     	sprintf_s(stmt_bufXX, sizeof stmt_bufXX," AND b.itag='%s' ",Itag);
     else	
     	sprintf_s(stmt_bufXX, sizeof stmt_bufXX,"");
     
     if (strcmp(trim(Icar_type),"01") == 0 || strcmp(trim(Icar_type),"02") == 0 ||
         strcmp(trim(Icar_type),"32") == 0 || strcmp(trim(Icar_type),"34") == 0 ||
         strcmp(trim(Icar_type),"51") == 0 )
     {
     	sprintf_s(stmt_bufmot, sizeof stmt_bufmot," AND a.icar_type in ('01','02','32','34','51')");
     }
     else
     {
     	sprintf_s(stmt_bufmot, sizeof stmt_bufmot," AND a.icar_type not in ('01','02','32','34','51')");
     }
         
     strcpy(tmp_fulldb, get_car_full_db(Ipolicy));
     
     /* �ư� Z1205802�BZ12058�BZ1205805���s�иg��N��
        add by sylvia 109.09.03 ( 1090610013_SC1) */
     
     sprintf_s(stmt_buf, sizeof stmt_buf,
     	" SELECT a.ipolicy, a.dpolicy, a.dply_begin, a.dply_end, a.fcard_class, b.iassured, "
     	"        b.nassured, b.itag, b.iengine, b.nequipment, a.ilast_ply "
     	"   FROM %s:ply_relation a, %s:policy b, cm_pre_receive c  "
     	"  WHERE a.ipolicy = b.ipolicy "
     	"    AND b.ipolicy[1,13] = c.ipolicy1 "
     	"    AND b.ipolicy[14,20] = c.ipolicy2 "
     	"    AND b.iassured = '%s' "
     	"    AND a.ipolicy <> '%s' "
     	"    AND c.ftype = 'P' "
     	"    AND dply_end >= '%s' "
     	"    AND fcard_class matches '%s' "
     	"    %s %s "
     	"    AND a.ipolicy[6,7] NOT IN ('VW','EB','TV') "
     	"    AND a.iofficer NOT IN (select iofficer FROM officer WHERE fprop = 'E') "
     	"    AND a.iofficer not in ('Z1205802','Z12058','Z1205805') "
     	"    AND NOT EXISTS (SELECT ipolicy FROM %s:ply_relation "
        "  WHERE ipolicy = a.ipolicy "
        "    AND icar_type IN (SELECT icode FROM car_type WHERE fclass = '1' AND icar_grp = '1') "
        "    AND fcard_class = '1' ) "
     	"  ORDER BY 1 "
     	   ,tmp_fulldb, tmp_fulldb, Iassured, Ipolicy, Dcreate, Fcard_class, stmt_bufmot, stmt_bufXX, tmp_fulldb);
     	$PREPARE Acursora  FROM :stmt_buf;
     	$DECLARE bcur CURSOR FOR Acursora;
     	$OPEN bcur ;
     	    	
     	while (1){
     		$FETCH bcur INTO $Ipolicy, $Dpolicy, $Dply_begin, $Dply_end, $Fcard_class, 
     		$Iassured, $Nassured, $Itag, $Iengine, $Nequipment, $Ilast_ply;
     		if(SQLCODE == SQLNOTFOUND) break;
     		
     		/*������*/
     		strcpy(tmp_fulldb, get_car_full_db(Ipolicy));
     		sprintf_s(stmt3, sizeof stmt3,
     		" SELECT a.ipre_rcv, b.itmp_policy[6,7] "
     		"   FROM cm_pre_receive a, %s:ply_relation b "
     		"  WHERE a.ipolicy1 = b.ipolicy[1,13] "
     		"    AND a.ipolicy2 = b.ipolicy[14,20] "
     		"    AND a.ipre_rcv = b.itmp_policy "
     		"    AND b.ipolicy = '%s' "
     		"    AND a.ftype = 'P' "
     		"    AND (a.ipre_end = '' OR a.ipre_end is NULL) "
     		,tmp_fulldb, Ipolicy);
     		$PREPARE sid006 FROM $stmt3;
     		$EXECUTE sid006 INTO $Iestimate, $capture;
     		
     		if(strcmp(capture,"CR") == 0) /*��O*/
     		{
     			sprintf_s(stmt3, sizeof stmt3,
     			" SELECT dupdate::date "
     			"   FROM policy_302 "
     			"  WHERE option IN ('1','9') "
     			"    AND (iestimate_ori = '%s' OR iestimate_sug = '%s') "
     			"    AND fcard_class matches '%s' " 
     			, Iestimate, Iestimate, Fcard_class);
     			$PREPARE sid007 FROM $stmt3;
     			$EXECUTE sid007 INTO $Dentry;
     			
     			if (SQLCODE == SQLNOTFOUND) strcpy(Dentry," ");
     		}
     		else
     		{
     			strcpy(tmp_fulldb, get_car_full_db(Ipolicy));
     			sprintf_s(stmt3, sizeof stmt3,
     			" SELECT dentry "
     			"   FROM %s:estimate "
     			"  WHERE iestimate = '%s' "
     			,tmp_fulldb, Iestimate);
     			$PREPARE sid007 FROM $stmt3;
     			$EXECUTE sid007 INTO $Dentry;
     			
     			if (SQLCODE == SQLNOTFOUND) strcpy(Dentry," ");
     		}
     		
     		/*����*/
     		strcpy(tmp_fulldb, get_car_full_db(Ipolicy)); 
     		sprintf_s(stmt_buf, sizeof stmt_buf,
     		" SELECT icar_type "
     		"   FROM %s:ply_relation "
     		"  WHERE ipolicy = '%s' " ,tmp_fulldb, Ipolicy);
     		$PREPARE sid4 FROM $stmt_buf;
     		$EXECUTE sid4 INTO $Icar_type;       
     		if (SQLCODE == SQLNOTFOUND) break;
     		
     		 /*���T�d�ߧǸ�*/
     		strcpy(tmp_fulldb, get_car_full_db(Ipolicy));
     		sprintf_s(stmt_buf, sizeof stmt_buf,
     		" SELECT iquery_num_damage[1,20],iquery_num[1,20],iquery_num_unknown[1,20] "
     		"   FROM %s:original_ply "
     		"  WHERE ipolicy = '%s' " ,tmp_fulldb, Ipolicy);
     		$PREPARE sid5 FROM $stmt_buf;
     		$EXECUTE sid5 INTO $Iquery_num_damage, $Iquery_num, $Iquery_num_unknown;      
     		if (SQLCODE == SQLNOTFOUND) break;
     		
     		if (equip_cmp(Nequipment,"110")) continue;   /* ���O110 �F�d�ܰ� */
     		get_data();   
     		
     		if((strcmp(trim(Pdmg_reason),"") != 0) && (Pdmg_acc_after == Pfactor_min))
     			continue;
     		if((strcmp(trim(Plia_reason),"") != 0) && (Plia_acc_after == Pcomp_factor_min))
     			continue;
     		if((strcmp(trim(Punknown_reason),"") != 0) && (Punknown_acc_after == Pfactor_min))
     			continue;
     		/* �s�W�ư����� add by 061476 (1100209009_SC1) */
     		if ((strcmp(trim(Pdmg_iins_type),"") != 0) && (Pdmg_acc_after == Pfactor_min))
     		{
     			if (strcmp(trim(Plia_iins_type),"") == 0) continue;
     		}
     		if ((strcmp(trim(Plia_iins_type),"") != 0) && (Plia_acc_after == Pcomp_factor_min))
     		{
     			if (strcmp(trim(Pdmg_iins_type),"") == 0) continue;
     		}
     		if ((strcmp(trim(Pdmg_iins_type),"") != 0) && (Pdmg_acc_after == Pfactor_min) &&
     		    (strcmp(trim(Plia_iins_type),"") != 0) && (Plia_acc_after == Pcomp_factor_min))
     		{
     			continue;
     		}

     		put_body();       
       }
       $CLOSE bcur;
       $FREE bcur;
  }
  $CLOSE acur;
  $FREE acur;
  return 0;

errexit:
    printf("SQLCODE=%ld errm=%s\n",SQLCODE,sqlca.sqlerrm);
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return;  
}
/*-------------------------------------------------------------------*/
void get_data()
{
	strcpy(fulldb, get_full_dbname(Ibranch_in));
		 
	if(strcmp(Fcard_class,"1") == 0)
	{
		sprintf_s(Nstmt, sizeof Nstmt,
		 " SELECT  replace(replace(replace(replace(replace( multiset "
		 " (select trim(c.iins_ply) from car_code b "
		 " where c.iins_ply = b.detail and b.kind = '56' "
		 " and b.engname = '1')::lvarchar, 'MULTISET{',''),'ROW(''',''),''')',''),'}',''),',',',') AS pdmg_reason, " 
		 " replace(replace(replace(replace(replace( multiset "
		 " (select trim(c.iins_ply) from car_code b "
		 " where c.iins_ply = b.detail and b.kind = '56' "
		 " and b.engname = '2')::lvarchar, 'MULTISET{',''),'ROW(''',''),''')',''),'}',''),',',',') AS plia_reason, "
		 " replace(replace(replace(replace(replace( multiset "
		 " (select trim(c.iins_ply) from car_code b "
		 " where c.iins_ply = b.detail and b.kind = '56' "
		 " and b.engname = '3')::lvarchar, 'MULTISET{',''),'ROW(''',''),''')',''),'}',''),',',',') AS punknown_reason "
		 " FROM %s:appraisal f, %s:ca_app_victim a, insurance_type c "
		 " WHERE a.iins_item = c.iins_type "
		 " AND a.iclaim = f.iclaim "
		 " AND f.iclaim = '%s' ", fulldb, fulldb, Iclaim);
	}
	else
	{
		sprintf_s(Nstmt, sizeof Nstmt,
		 " SELECT  replace(replace(replace(replace(replace( multiset "
         " (select trim(c.iins_ply) from car_code b, %s: app_ins_type a, insurance_type c  "
         " where a.iins_type = c.iins_type "
         " AND a.iclaim = f.iclaim  "
         " AND  c.iins_ply = b.detail and b.kind = '56'  "
         " and b.engname = '1')::lvarchar, 'MULTISET{',''),'ROW(''',''),''')',''),'}',''),',',',') AS pdmg_reason, "
         " replace(replace(replace(replace(replace( multiset "
         " (select trim(c.iins_ply) from car_code b, %s: app_ins_type a, insurance_type c "
         " where a.iins_type = c.iins_type "
         " AND a.iclaim = f.iclaim  "
         " AND  c.iins_ply = b.detail and b.kind = '56'  "
         " and b.engname = '2')::lvarchar, 'MULTISET{',''),'ROW(''',''),''')',''),'}',''),',',',') AS plia_reason, "
         " replace(replace(replace(replace(replace( multiset "
         " (select trim(c.iins_ply) from car_code b, %s: app_ins_type a, insurance_type c "
         " where a.iins_type = c.iins_type "
         " AND a.iclaim = f.iclaim  "
         " AND  c.iins_ply = b.detail and b.kind = '56'  "
         " and b.engname = '3')::lvarchar, 'MULTISET{',''),'ROW(''',''),''')',''),'}',''),',',',') AS punknown_reason "
         " FROM %s: appraisal f "
         " WHERE f.iclaim = '%s' ", fulldb, fulldb, fulldb, fulldb, Iclaim);
	}
	
	$PREPARE cursorA FROM :Nstmt;
     	$DECLARE cur CURSOR FOR cursorA;
     	$OPEN cur;
     	     	
     	while (1)
     	{
     		$FETCH cur INTO $Pdmg_reason, $Plia_reason, $Punknown_reason;
     		if(SQLCODE == SQLNOTFOUND) break;     
       }
       $CLOSE cur;
       $FREE cur;	

	/* �s�W�I�ت����[���� add by sylvia 109.09.03 ( 1090610013_SC1) */
	sprintf_s(stmt, sizeof stmt,
		" SELECT replace(replace(replace(replace(replace(replace( multiset \n"
		"        (select trim(a.iins_type)||'['||trim(nvl(a.provision,' '))||']' \n"
		"           from %s:ply_ins_type a,car_code b  \n"
		"          where a.ipolicy = f.ipolicy and a.iins_type = b.detail and b.kind = '56'  \n"
		"            and b.engname = '1')::lvarchar, 'MULTISET{',''),'ROW(''',''),''')',''),'}',''),',',','),'[]','') AS pdmg_iins_type,  \n"
		"        replace(replace(replace(replace(replace(replace( multiset \n"
		"        (select trim(a.iins_type)||'['||trim(nvl(a.provision,' '))||']' \n" 
		"           from %s:ply_ins_type a,car_code b  \n"
		"          where a.ipolicy = f.ipolicy and a.iins_type = b.detail and b.kind = '56'  \n"
		"            and b.engname = '2')::lvarchar, 'MULTISET{',''),'ROW(''',''),''')',''),'}',''),',',','),'[]','') AS plia_iins_type,  \n"
		"        replace(replace(replace(replace(replace(replace( multiset \n"
		"        (select trim(a.iins_type)||'['||trim(nvl(a.provision,' '))||']' \n" 
		"           from %s:ply_ins_type a,car_code b  \n"
		"          where a.ipolicy = f.ipolicy and a.iins_type = b.detail and b.kind = '56'  \n"
		"            and b.engname = '3')::lvarchar, 'MULTISET{',''),'ROW(''',''),''')',''),'}',''),',',','),'[]','') AS punknown_iins_type \n"
		"   FROM %s:ply_relation f"
		"  WHERE f.ipolicy = '%s' "
		"  ORDER BY f.ipolicy \n"
		,tmp_fulldb, tmp_fulldb, tmp_fulldb, tmp_fulldb, Ipolicy); 
	
	$PREPARE Acursora1  FROM :stmt;
	$DECLARE ccur CURSOR FOR Acursora1;
	$OPEN ccur ;       
	
	while (1) 
	{
		$FETCH ccur INTO $Pdmg_iins_type, $Plia_iins_type, $Punknown_iins_type;                    
		if (SQLCODE == SQLNOTFOUND) break;
	}    
    $CLOSE ccur;
    $FREE ccur;
    
    strcpy(tmp_fulldb, get_car_full_db(Ipolicy));
    sprintf_s(stmt_buf, sizeof stmt_buf,
       " SELECT a.pdmg_acc pdmg_before, b.pdmg_acc pdmg_after,  "
       "        a.plia_acc plia_before, b.plia_acc plia_after,   "
       "        a.punknown_acc punknown_before, b.punknown_acc punknown_after   "
       "   FROM %s:original_ply a, %s:policy b      "
       "  WHERE a.ipolicy = b.ipolicy   "
       "    AND a.ipolicy = '%s' ",tmp_fulldb,tmp_fulldb,Ipolicy);
     
    $PREPARE sid004 FROM $stmt_buf;
    $EXECUTE sid004 INTO $Pdmg_acc_before, $Pdmg_acc_after, $Plia_acc_before, $Plia_acc_after,$Punknown_acc_before, $Punknown_acc_after;
         
    /*if (SQLCODE == SQLNOTFOUND)
    {
    	strcpy(Pdmg_acc_before," ");
    	strcpy(Pdmg_acc_after," ");
    	strcpy(Plia_acc_before," ");
    	strcpy(Plia_acc_after," ");
    	strcpy(Punknown_acc_before," ");
    	strcpy(Punknown_acc_after," ");
    };*/

    if(Pdmg_acc_before == Pdmg_acc_after) 
    {
    	strcpy(Pdmg_comparison,"Y");
    }
    else
    {
          strcpy(Pdmg_comparison,"N");
    }
    if(Plia_acc_before == Plia_acc_after)
    {
    	strcpy(Plia_comparison,"Y");
    }
    else
    {
    	strcpy(Plia_comparison,"N");
    } 
    if(Punknown_acc_before == Punknown_acc_after)
    {
    	strcpy(Punknown_comparison,"Y");
    }
    else
    {
    	strcpy(Punknown_comparison,"N");
    } 
    
    /*��̤p�Y��*/
    strcpy(tmp_fulldb, get_car_full_db(Ipolicy));   
    sprintf_s(stmt1, sizeof stmt1,
        " SELECT min(pcomp_factor) pcomp_factor "
        "   FROM ca_comp_acc_factor " 
        "  WHERE drate IN "
        "        (SELECT drate FROM ca_rate_date WHERE icode IN " 
        "        (SELECT drate_ym FROM %s:ply_ins_type where ipolicy = '%s') "
        "            AND itable = 'ca_comp_acc_factor') " 
        "    AND fcard_class = '%s' "
        "    AND fcar_class IN (SELECT b.fcar_class FROM %s:ply_relation a, car_type b "
        "                     WHERE a.icar_type = b.icode AND b.fclass = 1 AND a.ipolicy = '%s') "
        ,tmp_fulldb, Ipolicy, Fcard_class, tmp_fulldb, Ipolicy);  
    $PREPARE sid100 FROM $stmt1;
    $EXECUTE sid100 INTO $Pcomp_factor_min;
    
    strcpy(tmp_fulldb, get_car_full_db(Ipolicy));
    sprintf_s(stmt2, sizeof stmt2,
       " SELECT min(pfactor) pfactor "
       "   FROM ca_acc_factor " 
       "  WHERE drate IN " 
       "       (SELECT drate FROM ca_rate_date WHERE icode IN "
       "       (SELECT drate_ym FROM %s:ply_ins_type where ipolicy = '%s') "
       "           AND itable = 'ca_acc_factor')" 
        ,tmp_fulldb, Ipolicy);  
       
    $PREPARE sid101 FROM $stmt2;
    $EXECUTE sid101 INTO $Pfactor_min;
           
    strcpy(tmp_fulldb, get_car_full_db(Ipolicy));
    sprintf_s(stmt_buf, sizeof stmt_buf,
          " SELECT a.iquota, c.ncode, b.nbranch, a.iofficer,  d.nname, "
          "       (select nname from officer where iofficer = a.ileader) as nname_leader "
          "   FROM %s:ply_relation a, sa_branch_type b, cu_code_data c,officer d   "
          "  WHERE c.itype =19 "
          "    AND a.iquota = b.ibranch "
          "    AND b.group2 = c.icode  "
          "    AND a.iofficer = d.iofficer  "
          "    AND a.ipolicy = '%s' ",tmp_fulldb,Ipolicy);
          $PREPARE sid005 FROM $stmt_buf;
          $EXECUTE sid005 INTO $Iquota, $Ncode, $Nbranch, $Iofficer, $Nleader, $Nname ;
          
          if (SQLCODE == SQLNOTFOUND)
          {
          	strcpy(Iquota," ");
          	strcpy(Ncode," ");
          	strcpy(Nbranch," ");
          	strcpy(Iofficer," ");
          	strcpy(Nname," ");
          	strcpy(Nleader," ");
          };
          return 0; 
          
errexit:
	printf("get_data: SQLCODE=%ld errm=%s\n",SQLCODE,sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
}
/*-------------------------------------------------------------------*/
void put_body()
{
	char tmp_date[10];
	rgu_put_body_string(2,Iclaim,1);
	rgu_put_body_string(2,Daccident,1);
	rgu_put_body_string(2,Iacc_reason,1);
	rgu_put_body_string(2,Dcreate_show,1);
	rgu_put_body_string(2,cm_from_infdate_100(Dappraisal),1);
	rgu_put_body_string(2,Ipolicy,1);
	rgu_put_body_string(2,Iquery_num_damage,1);
	rgu_put_body_string(2,Iquery_num,1);
	rgu_put_body_string(2,Iquery_num_unknown,1);
	rgu_put_body_string(2,Ilast_ply,1);
	strcpy(tmp_date,cm_from_infdate_100(Dpolicy));
	rgu_put_body_string(2,tmp_date,1);
	rgu_put_body_string(2,cm_from_infdate_100(Dply_begin),1);
	rgu_put_body_string(2,cm_from_infdate_100(Dply_end),1);
	rgu_put_body_string(2,cm_from_infdate_100(Dentry),1);
	rgu_put_body_string(2,Iassured,1);	
	rgu_put_body_string(2,Nassured,1);
	rgu_put_body_string(2,Icar_type,1);
	rgu_put_body_string(2,Itag,1);
	rgu_put_body_string(2,Iengine,1);
	rgu_put_body_string(2,Pdmg_reason,1);
	rgu_put_body_string(2,Pdmg_iins_type,1);
        rfmtdouble(Pdmg_acc_before,"-&.--",m_mstl);
	rgu_put_body_string(2,trim(m_mstl),1);
	rfmtdouble(Pdmg_acc_after,"-&.--",m_mstl);
	rgu_put_body_string(2,trim(m_mstl),1);
	rgu_put_body_string(2,Pdmg_comparison,1);
	rgu_put_body_string(2,Plia_reason,1);
	rgu_put_body_string(2,Plia_iins_type,1);
	rfmtdouble(Plia_acc_before,"-&.--",m_mstl);
	rgu_put_body_string(2,trim(m_mstl),1);
	rfmtdouble(Plia_acc_after,"-&.--",m_mstl);
	rgu_put_body_string(2,trim(m_mstl),1);
	rgu_put_body_string(2,Plia_comparison,1);
	rgu_put_body_string(2,Punknown_reason,1);
	rgu_put_body_string(2,Punknown_iins_type,1); 
        rfmtdouble(Punknown_acc_before,"-&.--",m_mstl);
	rgu_put_body_string(2, trim(m_mstl),1);
	rfmtdouble(Punknown_acc_after,"-&.--",m_mstl);
	rgu_put_body_string(2, trim(m_mstl),1);   
	rgu_put_body_string(2,Punknown_comparison,1);    
	rgu_put_body_string(2,Iquota,1);
	rgu_put_body_string(2,Ncode,1);
	rgu_put_body_string(2,Nbranch,1);    
	rgu_put_body_string(2,Iofficer,1);
	rgu_put_body_string(2,Nleader,1);
	rgu_put_body_string(2,Nname,1);
	rgu_put_body(2);    
}

/* -------------------------------------------------------------------------- */
int car653_QryByPolicy()
{
	long rc1;
	
	rc1 = car653_get_db();
	if (rc1 != M_CM_OK) {
		printf("error on car653_get_db\n");
		return rc1;
	}
	
	rc1 = car653_prepare_data();
	if (rc1 != M_CM_OK) {
		printf("error on car653_prepare_data\n");
		return rc1;
	}
    
	rc1 = car653_build2();
	if (rc1 != M_CM_OK) {
		printf("error on car653_prepare_data\n");
		return rc1;
	}
}
/* -------------------------------------------------------------------------- */
long car653_get_db()
{
    long	rc2;
    
    if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
    }

    rc2 = getApHome(sApHome);
    if (rc2 < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc2,msgbuf);
        return rc2;
    }
    
    $create temp table tb653_1
    (
    		iclaim				char(20),	--�߮׸�
    		ipolicy				char(20), 	--�O�渹
    		ifield				char(1),	--�I��(����1/���d2)
    		ndata_before	                char(1),	--�ק�e�F�d
    		ndata_after		        char(1),	--�ק��F�d
    		iupdate				char(10),	--�ק�H��
    		dupdate				datetime year to second, 	--�ק�ɶ�(�~���ɤ�)
    		daccident			char(20), 	--�X�I��
    		dpolicy				char(10), 	--ñ���
    		dply_begin		        char(10), 	--�O�I�_��
    		dply_end			char(10),	--�O�I����
    		iassured			char(12), 	--ID
    		nassured			varchar(120),	--�Q�O�H�W��
    		itag				char(12),	--����
    		iquota				char(10), 	--�~�Z���N��
    		iofficer			char(10), 	--�g��N��
    		iroute				char(20), 	--�q���N��
    		ileader				char(10),	--�޲z�H�N��
    		icount				int		--�F�d���ʵ���
    )with no log;
    
    $create temp table tb653_2
    (
    		iclaim				char(20),	--�߮׸�
    		ipolicy				char(20), 	--�O�渹
    		ifield				char(1),	--�I��(����1/���d2)
    		ndata_before	                char(1),	--�ק�e�F�d
    		ndata_after		        char(1),	--�ק��F�d
    		iupdate				char(10),	--�ק�H��
    		dupdate				char(30), 	--�ק�ɶ�(�~���ɤ�)
    		daccident			char(20), 	--�X�I��
    		dpolicy				char(10), 	--ñ���
    		dply_begin		        char(10), 	--�O�I�_��
    		dply_end			char(10),	--�O�I����
    		iassured			char(12), 	--ID
    		nassured			varchar(120),	--�Q�O�H�W��
    		itag				char(12),	--����
    		iquota				char(60), 	--�~�Z���W��
    		iofficer			char(10), 	--�g��N��
    		nofficer			char(20), 	--�g��W��
    		iroute				char(20), 	--�q���N��
    		nroute				char(60), 	--�q���W��
    		ileader				char(20)	--�޲z�H�W��
    )with no log;
    
    return M_CM_OK;
    
errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}

/* ------------------------------------------------------------------------- */
long car653_prepare_data()
{
    $WHENEVER SQLERROR GOTO errexit;

    $char		sTmp1[1000];
    $char		sFullName[25];
    $int		icnt;
    
    strcpy(Ipolicy, trim(Ipolicy));
    strcpy(sFullName, get_car_full_db(Ipolicy));
    
    /* ����F�d */
    sprintf_s(sTmp1, sizeof sTmp1, 
    		"insert into tb653_1  "
    	"	 select a.iclaim, a.ipolicy , '1', c.fdmg_duty, c.fdmg_duty,  "
    	"	        c.iapp_entry, c.dapp_entry, a.daccident, d.dpolicy, b.dply_begin,  "
    	"	        b.dply_end, a.iassured, a.nassured, a.itag, d.iquota,  "
        "       d.iofficer, e.iroute, d.ileader,  "
        "       (select count(*) from sysdb:ca_clm_upd_log  "
        "         where iclaim = a.iclaim and ifield = '1') as icount  "
        "  from ca_clm_process a, %s:adjustment_ply b, %s:appraisal c,  "
        "       %s:ply_relation d, %s:policy e  "
        " where a.iclaim = b.iclaim  "
        "   and a.iclaim = c.iclaim  "
        "   and a.ipolicy = d.ipolicy  "
        "   and a.ipolicy = e.ipolicy  "
        "   and a.ipolicy = '%s'", 
            sFullName, sFullName, sFullName, sFullName, Ipolicy);
    $prepare pre6531a from $sTmp1;
    $execute pre6531a;
        
    /* ���d�F�d */
    sprintf_s(sTmp1, sizeof sTmp1, 
    		"insert into tb653_1  "
    	"	 select a.iclaim, a.ipolicy , '2', c.facc_duty, c.facc_duty,  "
    	"	        c.iapp_entry, c.dapp_entry, a.daccident, d.dpolicy, b.dply_begin,  "
    	"	        b.dply_end, a.iassured, a.nassured, a.itag, d.iquota,  "
        "       d.iofficer, e.iroute, d.ileader,  "
        "       (select count(*) from sysdb:ca_clm_upd_log  "
        "         where iclaim = a.iclaim and ifield = '2') as icount  "
        "  from ca_clm_process a, %s:adjustment_ply b, %s:appraisal c,  "
        "       %s:ply_relation d, %s:policy e  "
        " where a.iclaim = b.iclaim  "
        "   and a.iclaim = c.iclaim  "
        "   and a.ipolicy = d.ipolicy  "
        "   and a.ipolicy = e.ipolicy  "
        "   and a.ipolicy = '%s'", 
            sFullName, sFullName, sFullName, sFullName, Ipolicy);
    
    $prepare pre6531b from $sTmp1;
    $execute pre6531b;
    
    
    icnt = 0;
    $select count(*) into $icnt
      from tb653_1
     where 1=1; 

		/* �Y�d�L���,�g�@���T����USER���D */
		if (icnt == 0)
		{
	    $insert into tb653_2 (iclaim) values ('�O��d�L�߮׽нT�{�I');
		}
		else
		{
			/* 1.�g�J�L�F�d���ʪ���� */
			$insert into tb653_2
			 select iclaim, ipolicy, ifield, ndata_before, ndata_after, 
    		      iupdate, dupdate, daccident, dpolicy, dply_begin, 
    		      dply_end, iassured, nassured, itag, 
    		      (select nbranch from sa_branch_type where ibranch = a.iquota), 
    		 			iofficer, (select nname from officer where iofficer = a.iofficer),
    		      iroute, (select nroute from cm_route where iroute = a.iroute),
    		      (select nname from officer where iofficer = a.ileader)
    		from tb653_1 a
    	 where icount = 0;
    	   
    	 /* 2.�g�J���F�d���ʪ���� */
    	 $insert into tb653_2
			 select a.iclaim, a.ipolicy, b.ifield, b.ndata_before, b.ndata_after, 
    		      b.icreate, b.dcreate, a.daccident, a.dpolicy, a.dply_begin, 
    		      a.dply_end, a.iassured, a.nassured, a.itag, 
    		      (select nbranch from sa_branch_type where ibranch = a.iquota), 
    		 			iofficer, (select nname from officer where iofficer = a.iofficer),
    		      iroute, (select nroute from cm_route where iroute = a.iroute),
    		      (select nname from officer where iofficer = a.ileader)
    		from tb653_1 a, ca_clm_upd_log b
    	 where a.iclaim = b.iclaim
    	   and a.ifield = b.ifield
    	   and a.icount > 0;
    	   
			icnt = 0;
    	$select count(*) into $icnt
       	 from tb653_2
     		where 1=1; 

     	if (icnt == 0)
			{
		    $insert into tb653_2 (iclaim) values ('�d�L�F�d���ʰ϶���ơI');
			}
			
		}

	return M_CM_OK;
	
errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
/*--------------------------------------------------------------------*/

long car653_build2()
{
	$char    sfilename[51], stitle[1000], stmt[1000];
  $int rc2;  
     memset(stitle, '\0', sizeof(stitle));
	$WHENEVER SQLERROR GOTO errexit;

	strcpy(sfilename,"�z�߻F�d�ܰʩ��Ӫ�");
	strcat(stitle,"�߮׸�\t�O�渹\t�I��(����1/���d2)\t�ק�e�F�d\t�ק��F�d\t");
	strcat(stitle,"�ק�H��\t�ק�ɶ�(�~���ɤ�)\t�X�I��\tñ���\t�O�I�_��\t");
	strcat(stitle,"�O�I����\t ID \t�Q�O�H�W��\t����\t�~�Z���W��\t");
	strcat(stitle,"�g��N��\t�g��W��\t�q���N��\t�q���W��\t�޲z�H�W��\t");
	
	sprintf_s(stmt, sizeof stmt,
	    "select * from tb653_2 order by iclaim,ifield,dupdate ");
	
	rc2 = unload_file(outputf," ",sfilename,stitle,stmt);
	
	if (rc2 != SUCCESS) 
	{
	    sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
	    EWRITE(userid, rc2 , msgbuf);
	    return rc2;
	}
	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	return SQLCODE;
}
