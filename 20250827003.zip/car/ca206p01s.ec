/************************************************/
/*   PROGRAM : ca206p01s.ec                     */
/*   �j���ҤΫO�I�d�����B���P���X               */
/*   MODIFIER: Johnny Kuo 04/01/1997            */
/*   MODIFY BY THOMAS 04/02/1999                */
/************************************************/
     
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"

EXEC SQL include sqlca;
EXEC SQL define PETER;
int IsNull(s)

char *s;
{
  return ((s[0]=='\0') ? 1:0);
}

char *get_car_full_db1();

long car206(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
    long car206_update(), car206_single_query();
    long car206_query_edr(), car206_update_re();
    long rtncode;
    char option;

    cm_buf_init(command);
    cm_buf_get("%c",&option);
    switch(option)
    {
        case 'P' : rtncode = car206_update(reply);          /*** �����O���� ***/
                   break;
        case 'Q' : rtncode = car206_single_query(reply);    /*** �����O�����e�d�߬O�_�w�X���check���O���p ***/
                   break;
        case 'K' : rtncode = car206_query_edr(reply);       /*** �d�ߵ��P���X��檬�p ***/
                   break;
        case 'S' : rtncode = car206_update_re(reply);       /*** ���P���X ***/
                   break;
        default  : if (exitsub(reply, M_CM_WRONG_OPTION)==True)
                       return M_CM_WRONG_OPTION;
                   return apiRC;
    }
    return(rtncode);
}

/************************************************************************/
long car206_single_query(reply)
serverReply reply;
{

    EXEC SQL BEGIN DECLARE SECTION;
         /* standard defined host variables */
         char  DBName[DBNAME];
	 char  DBName1[3];

         /* hosts variables */
         char  sCard[CARD_NUM], sIpolicy[POLICY_NUM_1], fstatus[2], nassured[20];
         char  sIpolicy1[POLICY_NUM_1], sIpolicy2[POLICY_NUM_2];
         int   ibatch_no;
         char  fcard_class[2];
    EXEC SQL END DECLARE SECTION;

    /* hosts variables */
    char  payresult[3], paystatus[31], paydate[YYYMMDD], notedate[YYYMMDD];
    char  sBatch_no[3];

    /* standard defined data */
    int   tab_sel, tmp_len;
    long  MsgCode, iOption, iRtnCode;
    $char sPolicy[21];
    $char sTmpBuf1[96],sTbname[16],sTmpBuf2[96];

    cm_buf_get("%s", DBName);
    cm_buf_get("%s", sCard);
    cm_buf_get("%d", &iOption);
    cm_buf_get("%s", sPolicy);

    strcpy(sCard, rtrim(sCard));

    
EXEC SQL ifdef PETER;
    printf("sCard=%s\n", sCard);
    printf("iOption=%d\n", iOption);
    printf("sPolicy=%s\n", sPolicy);
EXEC SQL endif;

    EXEC SQL WHENEVER SQLERROR GOTO errexit;



    if (db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    if (strlen(trim(sPolicy)) == 0)
    {
    	
       $SELECT ipolicy[1,2]
          INTO $DBName1
          FROM card
         WHERE icard = :sCard;
          printf("DBName1:[%s]\n",DBName1);
           if (SQLCODE == SQLNOTFOUND || strcmp(trim(DBName1),"")==0)
           {
           	printf("in\n");
                $SELECT ipolicy[1,2]
                   INTO $DBName1
                   FROM compulsory_card
                  WHERE icard = :sCard; 
                  if (SQLCODE == SQLNOTFOUND || strcmp(trim(DBName1),"")==0)          	
                     return exitsub(reply, M_CA_NPOLICY) ? M_CA_NPOLICY : apiRC;          	
           }

    }
    else
    {
        strncpy(DBName1,sPolicy,2);
        DBName1[2] = '\0';
    }

    printf("iissue_comp[%s]\n",DBName1);
    if (db_select(DBName1) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;


    /* ����(�d)�������w�X�洫���~���N�q */
    /* �s��(�d)�����o�X��B�����wñ�o   */
    /*�s�W�걵�X�Q�O�I�H�W�� by 071004 2019.02.26 (1070118005_SC3_CAR206����\���ܧ�)*/
    EXEC SQL SELECT  a.ipolicy  ,  a.ibatch_no ,  a.fcard_class, b.nassured
               INTO :sIpolicy , :ibatch_no , :fcard_class , :nassured
               FROM ply_relation a,policy b
              WHERE a.icard = :sCard AND a.ipolicy = b.ipolicy;

    if (iOption == 1)
        if (SQLCODE == SQLNOTFOUND)
           return exitsub(reply, M_CA_NPOLICY) ? M_CA_NPOLICY : apiRC;

    if (iOption == 2)
        if (SQLCODE != SQLNOTFOUND)
           return exitsub(reply, M_CA_ISSUED_POLICY) ? M_CA_ISSUED_POLICY : apiRC;

    if (SQLCODE == SQLNOTFOUND) strcpy(sIpolicy, " ");

    if (strlen(rtrim(sIpolicy)) > 0)
    {
       if ((iRtnCode = split_policy(sIpolicy, sIpolicy1, sIpolicy2)) != M_CM_OK)
          return exitsub(reply, M_CA_NLENGTH) ? M_CA_NLENGTH : apiRC;

       if (ibatch_no == 0)
           strcpy(sBatch_no, " ");
       else
           sprintf(sBatch_no, "%d", ibatch_no);

       iRtnCode = ao_chk_charge(DBName1, 'A', sIpolicy1, sIpolicy2, sBatch_no,
                                payresult, paystatus, paydate, notedate);
    }
    
EXEC SQL ifdef PETER;
    printf("0010: payresult[%s]\n", payresult);
    printf("0010: paystatus[%s]\n", paystatus);
    printf("0010: paydate[%s]\n", paydate);
    printf("0010: notedate[%s]\n", notedate);
EXEC SQL endif;    


    if (strcmp(fcard_class, "1") == 0)
        strcpy(sTbname, "compulsory_card");
    else
        strcpy(sTbname, "card");
        
    sprintf(sTmpBuf1, " SELECT fstatus FROM %s "
                      "  WHERE icard = ? ", sTbname );
    EXEC SQL PREPARE stmt FROM :sTmpBuf1;
    EXEC SQL Execute stmt INTO :fstatus USING :sCard;




    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    if (iOption == 1)
    {
    cm_buf_put("%s", trim(sIpolicy));
    cm_buf_put("%s", trim(payresult));
    cm_buf_put("%s", trim(paystatus));
    cm_buf_put("%s", trim(paydate));
    cm_buf_put("%s", trim(notedate));
    cm_buf_put("%s", trim(fcard_class));
    cm_buf_put("%s", trim(nassured));
    }
    else
    cm_buf_put("%s", trim(fstatus));
    tmp_len = cm_buf_len(ReplyBuf);

    if (db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
        return apiRC;
    else
        return api_OKComplete;
  
errexit:
    printf("sqlerrm=%s\n",sqlca.sqlerrm);
    return exitsub(reply, SQLCODE) ? SQLCODE : apiRC;
}


/************************************************************************/
long car206_query_edr(reply)
serverReply reply;
{

    EXEC SQL BEGIN DECLARE SECTION;
         /* standard defined host variables */
         char DBName[DBNAME];
	 char DBName1[DBNAME];

         /* hosts variables */
         char sCard[CARD_NUM], sIpolicy[POLICY_NUM_1];
         char sIendorse[20];
         char sDedr_close[20];
         long lDedr_close;
         int  id1;
    EXEC SQL END DECLARE SECTION;

    /* hosts variables */

    /* standard defined data */
    int   tmp_len;
    long  MsgCode, iRtnCode;

    cm_buf_get("%s", DBName);
    cm_buf_get("%s", sCard);

    strcpy(sCard, trim(sCard));

EXEC SQL ifdef PETER;
    printf("sCard=%s\n", sCard);
EXEC SQL endif;

    EXEC SQL WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    $SELECT ipolicy[1,2]
       INTO $DBName1
       FROM card
      WHERE icard = :sCard;
        if (SQLCODE == SQLNOTFOUND)
        {
           $SELECT ipolicy[1,2]
              INTO $DBName1
              FROM compulsory_card
             WHERE icard = :sCard;
	         if (SQLCODE == SQLNOTFOUND)
               return exitsub(reply, M_CA_NPOLICY) ? M_CA_NPOLICY : apiRC;
            else
               return exitsub(reply, M_CA_NOT_REUSE) ? M_CA_NOT_REUSE : apiRC;
        }

/****************************************************************************
    $SELECT iissue_comp
       INTO $DBName1
       FROM card
      WHERE icard = :sCard;
        if (SQLCODE == SQLNOTFOUND)
	{
           $SELECT iissue_comp
              INTO $DBName1
              FROM compulsory_card
             WHERE icard = :sCard;
	   if (SQLCODE == SQLNOTFOUND)
           return exitsub(reply, M_CA_NPOLICY) ? M_CA_NPOLICY : apiRC;
        }
*********************************************************************************/

    if (db_select(DBName1) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    sIendorse[0] = '\0';
    sDedr_close[0] = '\0';

    /* ��(�d)�������w���P�鵲 */
    EXEC SQL SELECT ipolicy
               INTO :sIpolicy
               FROM ply_relation
              WHERE icard = :sCard;

EXEC SQL ifdef PETER;
    printf("sIpolicy=%s\n", sIpolicy);
EXEC SQL endif;

    if (SQLCODE == SQLNOTFOUND)
        return exitsub(reply, M_CA_NPOLICY) ? M_CA_NPOLICY : apiRC;

    EXEC SQL SELECT iendorse  ,  dedr_close
               INTO :sIendorse, :lDedr_close:id1
               FROM edr_relation
              WHERE ipolicy = :sIpolicy
                AND fedr_class = '1';

    if (SQLCODE == SQLNOTFOUND)
    {
        strcpy(sIendorse,"�|�������P");
        strcpy(sDedr_close,"");
    }
    else
    {
        if (id1== -1)
            strcpy(sDedr_close,"���P���|���鵲");
        else
            strcpy(sDedr_close , cm_cdate_str_100(lDedr_close));
    }

EXEC SQL ifdef PETER;
    printf("sIendorse[%s],sDedr_close[%s]\n", sIendorse, sDedr_close);
EXEC SQL endif;

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l", M_CM_OK);
    cm_buf_put("%s", trim(sIendorse));
    cm_buf_put("%s", trim(sDedr_close));
    tmp_len = cm_buf_len(ReplyBuf);

    if (db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
        return apiRC;
    else
        return api_OKComplete;
  
errexit:
    printf("sqlerrm=%s\n",sqlca.sqlerrm);
    return exitsub(reply, SQLCODE) ? SQLCODE : apiRC;
}


/************************************************************************/
long car206_update(reply)
serverReply reply;
{
    EXEC SQL BEGIN DECLARE SECTION;
         /* standard defined host variables */
         char DBName[DBNAME];
	 char DBName1[3];
	 char sIpolicy1[21];

         /* hosts variables */
         char sCardb[CARD_NUM], sCarda[CARD_NUM];
         char ialter[11];
         char sReason[61];

         /* self defined data */
         char sIpolicyb[POLICY_NUM_1] , sIpolicya[POLICY_NUM_1];
         char sIpolicyb1[POLICY_NUM_1], sIpolicyb2[POLICY_NUM_2];
         char sIpolicya1[POLICY_NUM_1], sIpolicya2[POLICY_NUM_2];
         char sDummy[POLICY_NUM_1];
         char sFstatusb[2], sFstatusa[2];
         char sTmpCard[CARD_NUM], sTmpPolicy[POLICY_NUM_1];
         char sTmpStatus[2], sTmpBuf1[400];
         char buf[400], branch[3];
         char sFcard_classb[2], sFcard_classa[2];
         char sIbig_compb[2], sIbig_compa[2];

         /* self defined data */
         int  ibatch_no;
         date Today;
    EXEC SQL END DECLARE SECTION;

    /* standard defined data */
    int  tmp_len;
    long MsgCode;
    long iRtnCode;

    /* self defined data */
    char FullDBName[20], TpDBName[20];
    char taipei_db[DBNAME];
    char sDbname[21], sTbname[21];
    char dbname_tp[21];
    char payresult[3], paystatus[31], paydate[YYYMMDD], notedate[YYYMMDD];
    char sBatch_no[3];

    cm_buf_get("%s",DBName);
    cm_buf_get("%s %s %s %s %s", sCardb, sCarda, ialter, sIpolicy1, sReason);

    printf("sIpolicy1[%s]\n",sIpolicy1);
    strcpy(DBName1,get_car_full_db1(sIpolicy1));
    printf("DBName1[%s]\n",DBName1);

    strcpy(sCardb, rtrim(sCardb));
    strcpy(sCarda, rtrim(sCarda));
    rtoday(&Today);     /* get today's datetime */

    EXEC SQL WHENEVER SQLERROR GOTO errexit1;

    if (db_select(DBName1) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    /* Get Taipei's full DB name */
    iRtnCode = getHeadBranch(taipei_db);
    if (iRtnCode < 0)
       return exitsub(reply, M_CM_READ_CONFIG_ERR) ? M_CM_READ_CONFIG_ERR : apiRC;
    strcpy(dbname_tp, get_full_dbname(taipei_db));
    strcpy(dbname_tp, rtrim(dbname_tp));

    /*Check policy Before Change*/ /*�|���X�椣������*/
    /*************************************************/
    /****** �j���I���@�������ʧ@ 89.09.21 PETER ******/
    EXEC SQL SELECT ipolicy, fcard_class, ibig_comp, ibatch_no
               INTO :sIpolicyb, :sFcard_classb, :sIbig_compb, :ibatch_no
               FROM ply_relation
              WHERE icard = :sCardb
                AND fcard_class = '2';
    if (SQLCODE == SQLNOTFOUND)
       return exitsub(reply, M_CA_NPOLICY) ? M_CA_NPOLICY : apiRC;

    strcpy(sIpolicyb, rtrim(sIpolicyb));
    strcpy(sFcard_classb, rtrim(sFcard_classb));
    strcpy(sIbig_compb, rtrim(sIbig_compb));

    if ((iRtnCode = split_policy(sIpolicyb, sIpolicyb1, sIpolicyb2)) != M_CM_OK)
       return exitsub(reply, M_CA_NLENGTH) ? M_CA_NLENGTH : apiRC;

    if (isalpha(sIbig_compb[0]))
    {
        strcpy(sDbname, dbname_tp);
        strcat(sDbname, ":");
    }
    else
        strcpy(sDbname, " ");

    if (strcmp(sFcard_classb, "1") == 0)
        strcpy(sTbname, "compulsory_card");
    else
        strcpy(sTbname, "card");

    sprintf(sTmpBuf1, "SELECT ipolicy, fstatus FROM %s%s \
                        WHERE icard = ?", sDbname, sTbname);
    EXEC SQL PREPARE STMT1 FROM :sTmpBuf1;
    EXEC SQL DECLARE CUR1 CURSOR FOR STMT1;
    EXEC SQL OPEN CUR1 USING :sCarda;
    EXEC SQL FETCH CUR1 INTO :sIpolicya, :sFstatusa;
    if (SQLCODE == SQLNOTFOUND)
    {
       EXEC SQL CLOSE CUR1;
       EXEC SQL FREE CUR1;
       return exitsub(reply, M_CA_NOT_CARD) ? M_CA_NOT_CARD : apiRC;
    }
    EXEC SQL CLOSE CUR1;
    EXEC SQL OPEN CUR1 USING :sCardb;
    EXEC SQL FETCH CUR1 INTO :sDummy, :sFstatusb;
    if (SQLCODE == SQLNOTFOUND)
    {
       EXEC SQL CLOSE CUR1;
       EXEC SQL FREE CUR1;
       return exitsub(reply, M_CA_NOT_CARD) ? M_CA_NOT_CARD : apiRC;
    }
    EXEC SQL CLOSE CUR1;
    EXEC SQL FREE CUR1;

    /* ����T�d�����o�X��(�P��) */
    if (strlen(rtrim(sIpolicya)) > 0 || sFstatusa[0] == '1')
       return exitsub(reply, M_CA_NOT_CARD) ? M_CA_NOT_CARD : apiRC;

    /* '2':�L��  '3':�@�o */
    if (sFstatusa[0] == '2' || sFstatusa[0] == '3')
        return exitsub(reply, M_CA_STAT_CANCEL) ? M_CA_STAT_CANCEL : apiRC;

    /* Copy Branch & Company Code of Policy */
    strncpy(sIpolicya, sIpolicyb+CAR_POL_BRH_POS-1,
            CAR_POL_BRH_LEN+CAR_POL_COM_LEN);
    sIpolicya[CAR_POL_BRH_LEN+CAR_POL_COM_LEN] = '\0';

    if (strcmp(sFcard_classb, "1") == 0)    /*�j��*/
    {
       if (isalpha(sIbig_compb[0]))
       {      /*�O�N��*/ /*�L�j�O��*/
          strncpy(sIpolicya, sIpolicyb+CAR_POL_BRH_POS-1,
                  CAR_POL_BRH_LEN+CAR_POL_COM_LEN);
          sIpolicya[CAR_POL_BRH_LEN+CAR_POL_COM_LEN] = '\0';
          strcat(sIpolicya, sCarda);
          sIpolicya[CAR_POL_CHR_POS-1] = 'Z';
       }
       else
       {
          strcpy(sIpolicya, sCarda);
          strcat(sIpolicya, sIpolicyb2);
       }
    }
    else
       strcpy(sIpolicya, sIpolicyb);

    if ((iRtnCode = split_policy(sIpolicya, sIpolicya1, sIpolicya2)) != M_CM_OK)
       return exitsub(reply, M_CA_NLENGTH) ? M_CA_NLENGTH : apiRC;


    /* Check Payment Status */
    if (ibatch_no == 0) strcpy(sBatch_no, " ");
    else sprintf(sBatch_no, "%d", ibatch_no);

    iRtnCode = ao_chk_charge(DBName1, 'A', sIpolicyb1, sIpolicyb2, sBatch_no,
                             payresult, paystatus, paydate, notedate);
EXEC SQL ifdef PETER;
    printf("0020: payresult[%s]\n", payresult);
    printf("0020: paystatus[%s]\n", paystatus);
    printf("0020: paydate[%s]\n", paydate);
    printf("0020: notedate[%s]\n" , notedate);
EXEC SQL endif;

    /* Transaction Begin Here */
    EXEC SQL WHENEVER SQLERROR GOTO errexit2;
    EXEC SQL BEGIN WORK;


    /*-----------------------------------------------------*/
    /*             Update Card's Status                    */
    /*-----------------------------------------------------*/

    if (strcmp(sFcard_classb, "1") == 0)
    {
        sprintf(sTmpBuf1, " UPDATE %s%s SET (fstatus, ipolicy, ialter, dalter, dtrans) \
                            = (?, ?, ?, ?, null) \
                             WHERE icard = ?", sDbname, sTbname);
    }
    else
    {
        sprintf(sTmpBuf1, " UPDATE %s%s SET (fstatus, ipolicy, ialter, dalter) \
                            = (?, ?, ?, ?) \
                             WHERE icard = ?", sDbname, sTbname);
    }
    EXEC SQL PREPARE STMT2 FROM  :sTmpBuf1;

    EXEC SQL EXECUTE STMT2 USING :sFstatusb, :sIpolicya, :ialter, :Today, :sCarda;
    EXEC SQL EXECUTE STMT2 USING :sFstatusa, " "       , :ialter, :Today, :sCardb;
    /*-----------------------------------------------------*/

EXEC SQL ifdef PETER;
    printf("------STEP 1------>\n");

    printf("-----> sIpolicya[%s], sCardb[%s], sCarda[%s], sIpolicyb[%s]\n",
                   sIpolicya, sCardb, sCarda, sIpolicyb);
    printf("-----> sIpolicya1[%s], sIpolicya2[%s]\n",
                   sIpolicya1, sIpolicya2);
    printf("-----> sIpolicyb1[%s], sIpolicyb2[%s]\n",
                   sIpolicyb1, sIpolicyb2);
EXEC SQL endif;

    EXEC SQL UPDATE ply_relation
                SET ipolicy = :sIpolicya, icard = :sCarda
              WHERE ipolicy = :sIpolicyb;

    /******* ���N�I�𶷧�O�渹�X ************
    EXEC SQL UPDATE ply_relation
                SET irelative_ply = :sIpolicya
              WHERE irelative_ply = :sIpolicyb;
    *****************************************/

    EXEC SQL UPDATE policy
                SET ipolicy = :sIpolicya, icard = :sCarda
              WHERE ipolicy = :sIpolicyb;

    /******* ���N�I�𶷧�O�渹�X ************
    EXEC SQL UPDATE ply_ins_type
                SET ipolicy = :sIpolicya
              WHERE ipolicy = :sIpolicyb;
    *****************************************/

    EXEC SQL UPDATE ori_ply_relation
                SET ipolicy = :sIpolicya, icard = :sCarda
              WHERE ipolicy = :sIpolicyb;

    /******* ���N�I�𶷧�O�渹�X *************
    EXEC SQL UPDATE ori_ply_relation
                SET irelative_ply = :sIpolicya
              WHERE irelative_ply = :sIpolicyb;
    ******************************************/

    EXEC SQL UPDATE original_ply
                SET ipolicy = :sIpolicya, icard = :sCarda
              WHERE ipolicy = :sIpolicyb;

    /******* ���N�I�𶷧�O�渹�X ************
    EXEC SQL UPDATE ori_ins_type
                SET ipolicy = :sIpolicya
              WHERE ipolicy = :sIpolicyb;

    EXEC SQL UPDATE ply_ins_type_hist
                SET ipolicy = :sIpolicya
              WHERE ipolicy = :sIpolicyb;
    *****************************************/

    EXEC SQL UPDATE ply_relation_bak
                SET ipolicy = :sIpolicya, icard = :sCarda
              WHERE ipolicy = :sIpolicyb;

    /******* ���N�I�𶷧�O�渹�X *************
    EXEC SQL UPDATE ply_relation_bak
                SET irelative_ply = :sIpolicya
              WHERE irelative_ply = :sIpolicyb;
    ******************************************/

    EXEC SQL UPDATE policy_bak
                SET ipolicy = :sIpolicya, icard = :sCarda
              WHERE ipolicy = :sIpolicyb;

    /******* ���N�I�𶷧�O�渹�X ************
    EXEC SQL UPDATE ply_ins_type_bak
                SET ipolicy = :sIpolicya
              WHERE ipolicy = :sIpolicyb;
    *****************************************/

    EXEC SQL UPDATE ca_ply_assured
                SET ipolicy = :sIpolicya, icard = :sCarda
              WHERE ipolicy = :sIpolicyb;

    /******* ���N�I�𶷧�O�渹�X ************
    EXEC SQL UPDATE ca_ply_period
                SET ipolicy = :sIpolicya
              WHERE ipolicy = :sIpolicyb;
    *****************************************/

    EXEC SQL UPDATE edr_relation
                SET ipolicy = :sIpolicya, icard = :sCarda
              WHERE ipolicy = :sIpolicyb;

    /******* ���N�I�𶷧�O�渹�X *************
    EXEC SQL UPDATE edr_relation
                SET irelative_ply = :sIpolicya
              WHERE irelative_ply = :sIpolicyb;
    ******************************************/

    EXEC SQL UPDATE ca_edr_assured
                SET ipolicy = :sIpolicya, icard = :sCarda
              WHERE ipolicy = :sIpolicyb;

    EXEC SQL UPDATE appraisal
                SET ipolicy = :sIpolicya, icard = :sCarda
              WHERE ipolicy = :sIpolicyb;

    EXEC SQL UPDATE appraisal
                SET irelative_ply = :sIpolicya, irelative_card = :sCarda
              WHERE irelative_ply = :sIpolicyb;

    EXEC SQL UPDATE settlement
                SET ipolicy = :sIpolicya, icard = :sCarda
              WHERE ipolicy = :sIpolicyb;

    EXEC SQL UPDATE cm_credit_pay
                SET ipolicy1 = :sIpolicya1,
                    ipolicy2 = :sIpolicya2,
                    icard    = :sCarda
              WHERE ipolicy1 = :sIpolicyb1
                AND ipolicy2 = :sIpolicyb2;
                
    EXEC SQL UPDATE cm_pre_receive
                SET icard   = :sCarda
              WHERE ipolicy1 = :sIpolicyb1
                AND ipolicy2 = :sIpolicyb2
                AND icard   = :sCardb;

    EXEC SQL UPDATE policy_new
                SET itarget2=:sCarda,
                    iupdate='CAR206',
                    dupdate=today
              WHERE ipolicy1=:sIpolicyb1
                AND ipolicy2 = :sIpolicyb2;
            

   /*----------------------------------------------------------------------*/
   /*                         Update SYS DB                                */
   /*----------------------------------------------------------------------*/
   EXEC SQL DECLARE x CURSOR FOR
             SELECT branch FROM servertbl
              WHERE branch[1,1]='S'
              ORDER BY branch;
   EXEC SQL OPEN x;
   for (;;)
   {
          EXEC SQL FETCH x INTO $branch;
          if (SQLCODE == SQLNOTFOUND) break;
          strcpy(FullDBName, get_full_dbname(branch));
          if (FullDBName[0]=='\0') continue;

EXEC SQL ifdef PETER;
          printf("------STEP 20------>\n");
EXEC SQL  endif;

          sprintf(sTmpBuf1, "UPDATE %s:%s SET ipolicy=?, icard=? WHERE ipolicy=?",
                            FullDBName, "assured_vs_ply");
          EXEC SQL PREPARE STMT3 FROM  :sTmpBuf1;
          EXEC SQL EXECUTE STMT3 USING :sIpolicya, :sCarda, :sIpolicyb;


          /******* ���N�I�𶷧�O�渹�X ************
          sprintf(sTmpBuf1, "UPDATE %s:%s SET ipolicy1=?, ipolicy2=? \
                              WHERE ipolicy1=? AND ipolicy2=?",
                            FullDBName, "cm_ply_info");
          EXEC SQL PREPARE STMT4 FROM  :sTmpBuf1;
          EXEC SQL EXECUTE STMT4 USING :sIpolicya1, :sIpolicya2, :sIpolicyb1, :sIpolicyb2;

          sprintf(sTmpBuf1, "UPDATE %s:%s SET ipolicy1=?, ipolicy2=? \
                              WHERE ipolicy1=? AND ipolicy2=?",
                            FullDBName, "cm_plyins_info");
          EXEC SQL PREPARE STMT5 FROM  :sTmpBuf1;
          EXEC SQL EXECUTE STMT5 USING :sIpolicya1, :sIpolicya2, :sIpolicyb1, :sIpolicyb2;

          sprintf(sTmpBuf1, "UPDATE %s:%s SET ipolicy1=?, ipolicy2=? \
                              WHERE ipolicy1=? AND ipolicy2=?",
                            FullDBName, "cu_miss_renew_ply");
          EXEC SQL PREPARE STMT6 FROM  :sTmpBuf1;
          EXEC SQL EXECUTE STMT6 USING :sIpolicya1, :sIpolicya2, :sIpolicyb1, :sIpolicyb2;
          *****************************************/
   }
   EXEC SQL CLOSE x;
   EXEC SQL FREE x;

   /*----------------------------------------------------------------------*/
   /*                         Update AOI Table                             */
   /*----------------------------------------------------------------------*/
   strcpy(payresult, rtrim(payresult));

   /*-------- �O���b���ɪ� ipolicy2 �鵲�ɭY�����j�O��h�g�J' '----------*/
   /*-------- �ҥHupdate�ɤ@�w�ncheck ipolicy2�O�_�� NULL,�_�h   ----------*/
   /*-------- ao_chk_charge�|�䤣�촫���᪺���O���p              ----------*/

   if (strlen(sIpolicya2) == 0) strcpy(sIpolicya2, " ");
   if (strlen(sIpolicyb2) == 0) strcpy(sIpolicyb2, " ");

   /*if (payresult[0] == 'N'|| payresult[0] == 'R')  �אּ�����O�Φ��Oupdate*/
   
EXEC SQL ifdef PETER;
          printf("------STEP 24------>\n");
EXEC SQL endif;

/*---------�Y�����O�s�W�H�UTABLE------------------*/
	if( payresult[0] == 'R'){
  
	EXEC SQL UPDATE ao_prem_rcv
	            SET icard = :sCarda
	          WHERE ipolicy1 = :sIpolicyb1
                    AND ipolicy2 = :sIpolicyb2
	            AND icard = :sCardb;
  
	EXEC SQL UPDATE ao_prem_grp
   	            SET icard = :sCarda
	          WHERE icard = :sCardb;
  
	EXEC SQL UPDATE ao_temp_deduct
   	            SET icard = :sCarda
	          WHERE ipolicy1 = :sIpolicyb1
                    AND ipolicy2 = :sIpolicyb2
   	            AND icard = :sCardb;
  
	}
/*-----------------------------------------------*/

          EXEC SQL UPDATE ao_plyedr_prem
                      SET ipolicy1 = :sIpolicya1,
                          ipolicy2 = :sIpolicya2,
                          icard    = :sCarda
                    WHERE ipolicy1 = :sIpolicyb1
                      AND ipolicy2 = :sIpolicyb2;

          /******* ���N�I�𶷧�O�渹�X *************
          EXEC SQL UPDATE ao_plyedr_prem
                      SET irelative = :sIpolicya
                    WHERE irelative = :sIpolicyb;

          EXEC SQL UPDATE ao_plyedr_detail
                      SET ipolicy1 = :sIpolicya1,
                          ipolicy2 = :sIpolicya2
                    WHERE ipolicy1 = :sIpolicyb1
                      AND ipolicy2 = :sIpolicyb2;
          ******************************************/

          EXEC SQL UPDATE ao_officer_commit
                      SET ipolicy1 = :sIpolicya1,
                          ipolicy2 = :sIpolicya2,
                          icard    = :sCarda
                    WHERE ipolicy1 = :sIpolicyb1
                      AND ipolicy2 = :sIpolicyb2;

          /******* ���N�I�𶷧�O�渹�X *************
          EXEC SQL UPDATE ao_officer_commit
                      SET irelative = :sIpolicya
                    WHERE irelative = :sIpolicyb;

          EXEC SQL UPDATE ao_commit_detail
                      SET ipolicy1 = :sIpolicya1,
                          ipolicy2 = :sIpolicya2
                    WHERE ipolicy1 = :sIpolicyb1
                      AND ipolicy2 = :sIpolicyb2;
          ******************************************/

          EXEC SQL UPDATE ao_io_credit
                      SET ipolicy1 = :sIpolicya1,
                          ipolicy2 = :sIpolicya2,
                          icard    = :sCarda
                    WHERE ipolicy1 = :sIpolicyb1
                      AND ipolicy2 = :sIpolicyb2;

          /******* ���N�I�𶷧�O�渹�X *************
          EXEC SQL UPDATE ao_prem_return
                      SET ipolicy1 = :sIpolicya1,
                          ipolicy2 = :sIpolicya2
                    WHERE ipolicy1 = :sIpolicyb1
                      AND ipolicy2 = :sIpolicyb2;
          ******************************************/
          
          /* car9902021 ���d���ɭn�󥿫H�Υd�Ȧ������� */
          EXEC SQL UPDATE ao_prem_crd_detail
                      SET ipolicy1 = :sIpolicya1,
                          ipolicy2 = :sIpolicya2,
                          icard    = :sCarda
                    WHERE ipolicy1 = :sIpolicyb1
                      AND ipolicy2 = :sIpolicyb2
                      AND fstatus != 'R'
                      AND iserno in (select iserno from ao_prem_credit where ientry = '' or ientry is null);
                      
   /*---------INSERT INTO ca_icard_change---------*/  
   /*�g�J���N�d���������� by 071004 2019.02.27 (1070118005_SC3_CAR206����\���ܧ�)*/  
   
          EXEC SQL INSERT INTO sysdb:ca_icard_change
                         VALUES(:sCardb, :sCarda, :sIpolicy1, :ialter, CURRENT , :sReason );
   /*---------------------------------------------*/
   
            
   

   printf("FINISH \n\n");

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   cm_buf_put("%s", payresult);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
   {
      EXEC SQL WHENEVER SQLERROR CONTINUE;
      EXEC SQL ROLLBACK WORK;
      return apiRC;
   }

   EXEC SQL COMMIT WORK;

   printf("DBName[%s]\n",DBName);
   if (db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
   return api_OKComplete;

errexit1:
   printf(" sqlerrm = %s\n",sqlca.sqlerrm);
   return exitsub(reply, SQLCODE) ? SQLCODE : apiRC;

errexit2:
   printf(" sqlerrm = %s\n",sqlca.sqlerrm);
   EXEC SQL WHENEVER SQLERROR CONTINUE;
   MsgCode = SQLCODE;
   EXEC SQL ROLLBACK WORK;
   if (SQLCODE != 0) MsgCode = SQLCODE;
   return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
/************************************************************************/

long car206_update_re(reply)
serverReply reply;
{
    EXEC SQL BEGIN DECLARE SECTION;
         /* standard defined host variables */
         char DBName[DBNAME];
	 char DBName1[3];

         /* hosts variables */
         char sCard[CARD_NUM];
         char ialter[11];

         /* self defined data */
         char sIpolicy[POLICY_NUM_1];
         char sIpolicy1[POLICY_NUM_1], sIpolicy2[POLICY_NUM_2];
	 char sIendorse[21];
         char sIrelative_ply[POLICY_NUM_1];
         char sTmpCard[CARD_NUM+2], sTmpPolicy[POLICY_NUM_1+2];
         char buf[400];
         char sFcard_class[2];
         char sTmpBuf1[400];
         int  count_card;
         char branch[3];

         date Today;
    EXEC SQL END DECLARE SECTION;

    /* standard defined data */
    int  tmp_len;
    long MsgCode;
    long iRtnCode;

    /* self defined data */
    char taipei_db[DBNAME];
    char dbname_tp[21];
    char FullDBName[20];
    char sTbname[21];
 
    /*** EXEC SQL SET EXPLAIN ON; ***/

    cm_buf_get("%s",DBName);
    cm_buf_get("%s %s %s", sCard , ialter, sIendorse);

    strcpy(sCard, trim(sCard));
    rtoday(&Today);     /* get today's datetime */

    EXEC SQL WHENEVER SQLERROR GOTO errexit1;

    if (db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    strcpy(DBName1,get_car_full_db1(sIendorse));

    if (db_select(DBName1) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    /* Get Taipei's full DB name */
    iRtnCode = getHeadBranch(taipei_db);
    if (iRtnCode < 0)
       return exitsub(reply, M_CM_READ_CONFIG_ERR) ? M_CM_READ_CONFIG_ERR : apiRC;
    strcpy(dbname_tp, get_full_dbname(taipei_db));
    strcpy(dbname_tp, trim(dbname_tp));

    /* Check policy Before Change */
    EXEC SQL SELECT ipolicy , fcard_class , irelative_ply
               INTO :sIpolicy , :sFcard_class , :sIrelative_ply
               FROM ply_relation
              WHERE icard = :sCard;
    if (SQLCODE == SQLNOTFOUND)
        return exitsub(reply, M_CA_NPOLICY) ? M_CA_NPOLICY : apiRC;

    strcpy(sIpolicy, trim(sIpolicy));
    strcpy(sFcard_class, trim(sFcard_class));
    strcpy(sIrelative_ply, trim(sIrelative_ply));

    if (strcmp(sFcard_class, "1") == 0)
        strcpy(sTbname, "compulsory_card");
    else
        strcpy(sTbname, "card");

    /*** table:card & compulsory_card default �bSYSDB ***/
    sprintf(sTmpBuf1, "SELECT ipolicy FROM %s \
                        WHERE icard = ? AND fstatus = '1'", sTbname);
    EXEC SQL PREPARE STMT_CUR FROM :sTmpBuf1;
    EXEC SQL DECLARE CUR1_RE  CURSOR FOR STMT_CUR;
    EXEC SQL OPEN    CUR1_RE  USING :sCard;

    EXEC SQL FETCH CUR1_RE INTO :sIpolicy;
    if (SQLCODE == SQLNOTFOUND)
    {
       EXEC SQL CLOSE CUR1_RE;
       EXEC SQL FREE  CUR1_RE;
       return exitsub(reply, M_CA_NOT_CARD) ? M_CA_NOT_CARD : apiRC;
    }
    EXEC SQL CLOSE CUR1_RE;
    EXEC SQL FREE  CUR1_RE;

    EXEC SQL SELECT iendorse , dedr_close
               FROM edr_relation
              WHERE ipolicy = :sIpolicy
                AND fedr_class = '1';

    if (SQLCODE == SQLNOTFOUND)
    {
        return exitsub(reply, M_CA_NENDORSE) ? M_CA_NENDORSE : apiRC;
    }

    if ((iRtnCode = split_policy(sIpolicy, sIpolicy1, sIpolicy2)) != M_CM_OK)
       return exitsub(reply, M_CA_NLENGTH) ? M_CA_NLENGTH : apiRC;

    sTmpCard[0] = '\0';
    sTmpPolicy[0] = '\0';

    /*** ���קK�ϥΪ̦P�@�d�����P���X�h���A�]���ncheck�O�_�����L�h�����P ***/
    if (strcmp(sFcard_class, "1") == 0)
    {
        EXEC SQL SELECT count(*)
                   INTO :count_card
                   FROM ply_relation
                  WHERE icard[1,10] = :sCard;

        strcpy(sTmpCard   , trim(sCard));
        strcat(sTmpCard   , "-");
        strcat(sTmpCard   , itoa(count_card));

	strcpy(sTmpPolicy , trim(sIpolicy));
        /***************************************
	strcat(sTmpPolicy , "-");
	strcat(sTmpPolicy , itoa(count_card));
        ***************************************/
    }
    else
    {
        EXEC SQL SELECT count(*)
                   INTO :count_card
                   FROM ply_relation
                  WHERE icard[1,9] = :sCard;

        strcpy(sTmpCard   , trim(sCard));
        strcat(sTmpCard   , "-");
        strcat(sTmpCard   , itoa(count_card));
    }

    /* Transaction Begin Here */
    EXEC SQL WHENEVER SQLERROR GOTO errexit2;
    EXEC SQL BEGIN WORK;

    /*-----------------------------------------------------*/
    /*             Update Card's Status                    */
    /*-----------------------------------------------------*/

    if (strcmp(sFcard_class, "1") == 0)
    {
        sprintf(sTmpBuf1, " UPDATE %s SET (fstatus, ipolicy, ialter, dalter, dtrans) \
                            = ('0', ?, ?, ?, null) \
                             WHERE icard = ?", sTbname);
    }
    else
    {
        sprintf(sTmpBuf1, " UPDATE %s SET (fstatus, ipolicy, ialter, dalter) \
                            = ('0', ?, ?, ?) \
                             WHERE icard = ?", sTbname);
    }
    EXEC SQL PREPARE STMT2_RE FROM  :sTmpBuf1;
    EXEC SQL EXECUTE STMT2_RE USING " ", :ialter, :Today, :sCard;

    /*----------------------------------------------------------------------*/
    /*                         Update LOCAL DB                              */
    /*----------------------------------------------------------------------*/
    if (strcmp(sFcard_class, "1") == 0)
    {
        EXEC SQL UPDATE ply_relation
                    SET icard   = :sTmpCard,
                        irelative_ply = ""
                  WHERE ipolicy = :sIpolicy;

        EXEC SQL UPDATE ply_relation
                    SET irelative_ply = ""
                  WHERE ipolicy = :sIrelative_ply;

        EXEC SQL UPDATE policy
                    SET icard   = :sTmpCard
                  WHERE ipolicy = :sIpolicy;

        /*************************************
        EXEC SQL UPDATE ply_ins_type
                    SET ipolicy = :sTmpPolicy
                  WHERE ipolicy = :sIpolicy;
        *************************************/

        EXEC SQL UPDATE ori_ply_relation
                    SET icard   = :sTmpCard,
                        irelative_ply = ""
                  WHERE ipolicy = :sIpolicy;

        EXEC SQL UPDATE ori_ply_relation
                    SET irelative_ply = ""
                  WHERE ipolicy = :sIrelative_ply;

        EXEC SQL UPDATE original_ply
                    SET icard   = :sTmpCard
                  WHERE ipolicy = :sIpolicy;

        /*************************************
        EXEC SQL UPDATE ori_ins_type
                    SET ipolicy = :sTmpPolicy
                  WHERE ipolicy = :sIpolicy;

        EXEC SQL UPDATE ply_ins_type_hist
                    SET ipolicy = :sTmpPolicy
                  WHERE ipolicy = :sIpolicy;
        *************************************/

        EXEC SQL UPDATE ply_relation_bak
                    SET icard   = :sTmpCard
                  WHERE ipolicy = :sIpolicy;

        /************************************
        EXEC SQL UPDATE ply_ins_type_bak
                    SET ipolicy = :sTmpPolicy
                  WHERE ipolicy = :sIpolicy;
        ************************************/

        EXEC SQL UPDATE ca_ply_assured
                    SET icard   = :sTmpCard
                  WHERE ipolicy = :sIpolicy;

        EXEC SQL UPDATE edr_relation
                    SET icard   = :sTmpCard
                  WHERE ipolicy = :sIpolicy;

        EXEC SQL UPDATE cm_credit_pay
                    SET icard    = :sTmpCard
                  WHERE ipolicy1 = :sIpolicy;

        EXEC SQL UPDATE ca_edr_assured
                    SET icard   = :sTmpCard
                  WHERE ipolicy = :sIpolicy;

    }
    else
    {
        EXEC SQL UPDATE ply_relation
                    SET icard = :sTmpCard,
                        irelative_ply = ""
                  WHERE icard = :sCard;

        EXEC SQL UPDATE ply_relation
                    SET irelative_ply = ""
                  WHERE ipolicy = :sIrelative_ply;

        EXEC SQL UPDATE policy
                    SET icard = :sTmpCard
                  WHERE icard = :sCard;

        EXEC SQL UPDATE ori_ply_relation
                    SET icard = :sTmpCard,
                        irelative_ply = ""
                  WHERE icard = :sCard;

        EXEC SQL UPDATE ori_ply_relation
                    SET irelative_ply = ""
                  WHERE ipolicy = :sIrelative_ply;

        EXEC SQL UPDATE original_ply
                    SET icard = :sTmpCard
                  WHERE icard = :sCard;

        EXEC SQL UPDATE policy_bak
                    SET icard = :sTmpCard
                  WHERE icard = :sCard;

        EXEC SQL UPDATE ply_relation_bak
                    SET icard = :sTmpCard
                  WHERE icard = :sCard;

        EXEC SQL UPDATE cm_credit_pay
                    SET icard = :sTmpCard
                  WHERE icard = :sCard;

        EXEC SQL UPDATE ca_ply_assured
                    SET icard = :sTmpCard
                  WHERE icard = :sCard;

        EXEC SQL UPDATE edr_relation
                    SET icard = :sTmpCard
                  WHERE icard = :sCard;

        EXEC SQL UPDATE ca_edr_assured
                    SET icard = :sTmpCard
                  WHERE icard = :sCard;

    }

    /*----------------------------------------------------------------------*/
    /*                         Update SYS DB                                */
    /*----------------------------------------------------------------------*/

    if (strcmp(sFcard_class, "1") == 0)
    {
        EXEC SQL DECLARE y CURSOR FOR
                  SELECT branch FROM servertbl
                   WHERE branch[1,1]='S'
                   ORDER BY branch;
        EXEC SQL OPEN y;
        for (;;)
        {
              EXEC SQL FETCH y INTO :branch;
              if (SQLCODE == SQLNOTFOUND) break;

              strcpy(FullDBName, get_full_dbname(branch));
              if (FullDBName[0]=='\0') continue;

              sprintf(sTmpBuf1, "UPDATE %s:%s SET icard=? WHERE ipolicy=?",
                                FullDBName, "assured_vs_ply");
              EXEC SQL PREPARE STMT3_CUR FROM  :sTmpBuf1;
              EXEC SQL EXECUTE STMT3_CUR USING :sTmpCard, :sIpolicy;

              /********************************************************
              sprintf(sTmpBuf1, "UPDATE %s:%s SET ipolicy1=? \
                                  WHERE ipolicy1=? ",
                                FullDBName, "cm_ply_info");
              EXEC SQL PREPARE STMT4_CUR FROM  :sTmpBuf1;
              EXEC SQL EXECUTE STMT4_CUR USING :sTmpPolicy , :sIpolicy;

              sprintf(sTmpBuf1, "UPDATE %s:%s SET ipolicy1=? \
                                  WHERE ipolicy1=? ",
                                FullDBName, "cm_plyins_info");
              EXEC SQL PREPARE STMT5_CUR FROM  :sTmpBuf1;
              EXEC SQL EXECUTE STMT5_CUR USING :sTmpPolicy, :sIpolicy;

              sprintf(sTmpBuf1, "UPDATE %s:%s SET ipolicy1=? \
                                  WHERE ipolicy1=? ",
                                FullDBName, "cu_miss_renew_ply");
              EXEC SQL PREPARE STMT6_CUR FROM  :sTmpBuf1;
              EXEC SQL EXECUTE STMT6_CUR USING :sTmpPolicy , :sIpolicy;

              sprintf(sTmpBuf1, "UPDATE %s:%s SET ipolicy=? \
                                  WHERE ipolicy=? ",
                                FullDBName, "ca_ply_period");
              EXEC SQL PREPARE STMT7_CUR FROM  :sTmpBuf1;
              EXEC SQL EXECUTE STMT7_CUR USING :sTmpPolicy , :sIpolicy;
              ********************************************************/
        }
        EXEC SQL CLOSE y;
        EXEC SQL FREE  y;
    }
    else
    {
        EXEC SQL UPDATE  assured_vs_ply
                    SET icard = :sTmpCard
                  WHERE icard = :sCard;
    }

    /*----------------------------------------------------------------------*/
    /*                         Update AOI Table                             */
    /*----------------------------------------------------------------------*/
    if (strcmp(sFcard_class, "1") == 0)
    {
        EXEC SQL UPDATE ao_prem_rcv
                    SET icard    = :sTmpCard
                  WHERE ipolicy1 = :sIpolicy;

        EXEC SQL UPDATE ao_plyedr_prem
                    SET icard    = :sTmpCard
                  WHERE ipolicy1 = :sIpolicy;

        /**************************************
        EXEC SQL UPDATE ao_plyedr_detail
                    SET ipolicy1 = :sTmpPolicy
                  WHERE ipolicy1 = :sIpolicy;
        **************************************/

        EXEC SQL UPDATE ao_officer_commit
                    SET icard    = :sTmpCard
                  WHERE ipolicy1 = :sIpolicy;

        /**************************************
        EXEC SQL UPDATE ao_commit_detail
                    SET ipolicy1 = :sTmpPolicy
                  WHERE ipolicy1 = :sIpolicy;
        **************************************/
    }
    else
    {
        EXEC SQL UPDATE ao_plyedr_prem
                    SET icard = :sTmpCard
                  WHERE icard = :sCard;

        EXEC SQL UPDATE ao_officer_commit
                    SET icard = :sTmpCard
                  WHERE icard = :sCard;

        EXEC SQL UPDATE ao_io_credit
                    SET icard = :sTmpCard
                  WHERE icard = :sCard;
                  
        /* car9902021 ���d���ɭn�󥿫H�Υd�Ȧ������� */    
        EXEC SQL UPDATE ao_prem_crd_detail
                    SET icard = :sTmpCard
                  WHERE icard = :sCard
                    AND fstatus != 'R'
                    AND iserno in (select iserno from ao_prem_credit where ientry = '' or ientry is null);

    }

    /************************************************************************/

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    tmp_len = cm_buf_len(ReplyBuf);


    if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
       EXEC SQL WHENEVER SQLERROR CONTINUE;
       EXEC SQL ROLLBACK WORK;
       return apiRC;
    }

    EXEC SQL COMMIT WORK;

    if (db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    return api_OKComplete;

errexit1:
    printf(" sqlerrm = %s\n",sqlca.sqlerrm);
    return exitsub(reply, SQLCODE) ? SQLCODE : apiRC;

errexit2:
    printf(" sqlerrm = %s\n",sqlca.sqlerrm);
    EXEC SQL WHENEVER SQLERROR CONTINUE;
    MsgCode = SQLCODE;
    EXEC SQL ROLLBACK WORK;
    if (SQLCODE != 0) MsgCode = SQLCODE;
    return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

char *get_car_full_db1(sIpolicy)
char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  char sTmp_db_name[21];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, sTmpcomp);
  }
  return sTmp_db_name;
}
/******************************************************************************************/
