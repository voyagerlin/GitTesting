/**********************************************************************/
/*   program id   : ca658q01s.ec                                      */
/*   program name : �ӫO���������                                    */
/*   date written : 2021/05/17 by 041090                              */
/*   files        :                                                   */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <decimal.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "globdata.h"
#include "safeclib.h"
$char dbgn[11],dbgn2[21],dbgn_q[21];
$char dend[11],dend2[21],dend_q[21];
$char option1[2],option2[2],option3[2];
$char stmpx[128];

int   count_db,k; 
char  outputf[21];
$char userid[11];
$char DBName[05];
$char msgbuf[128];

DBinfo *list;

main(argc, argv)
int argc;
char **argv;
{
	int rc;

	batchinit();
	strcpy(DBName,         isNULLstr(argv[1]));
	strcpy(userid,         isNULLstr(argv[2]));
	strcpy(dbgn,           isNULLstr(argv[3]));  /*�e�~����϶�*/
	strcpy(dend,           isNULLstr(argv[4]));
	strcpy(option1,        isNULLstr(argv[5]));  /*��ƧO 1:�s��O��Ʋέp 2:�e�~��Ʋέp*/
	strcpy(option2,        isNULLstr(argv[6]));  /*����D���� 1:���� 2:�D����*/
	strcpy(option3,        isNULLstr(argv[7]));  /*�j���O 1:��j 2:��� 3:�j+��*/
	strcpy(outputf,        isNULLstr(argv[8]));
	
	rc = car658_get_db();
	if (rc != M_CM_OK)
		return rc;

	rc = car658_prepare_data();
	if (rc != M_CM_OK)
		return rc;

	rc = car658_build();
	if (rc != M_CM_OK) 
		return rc;
}

long car658_get_db()
{
	$whenever sqlerror goto errexit;

	if (db_select(DBName) == FALSE) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}

long car658_prepare_data()
{
	$char igroup[11],ngroup[21],fcard_class[2],imgr[2],iroute[21],iclass[2];
	$int qorder = 0,cnt = 0;
	$char stmt[8192];
	$char stmp1[128],stmp2[128],stmp3[128];
	$char sFullName[21];
	$char db_tmp[3];
	
	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == FALSE)
	{
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return FAIL;
	}
	
	sprintf_s(dbgn2, sizeof dbgn2,"%s/00:00:00",dbgn);
	sprintf_s(dend2, sizeof dend2,"%s/23:59:59",dend);
	
	strcpy(dbgn_q,cm_sysd_edatetime(dbgn2));
	strcpy(dend_q,cm_sysd_edatetime(dend2));
	
	if(strncmp(option2,"1",1) == 0) 
	{
		/*����*/
		strcpy(stmp1,"AND b.iroute[1,2] = 'JB'");
		strcpy(stmpx,"����");
	}
	else 
	{
		/*�D����*/
		strcpy(stmp1,"AND b.iroute[1,2] != 'JB'");
		strcpy(stmpx,"�D����");
	}
		
	if(strncmp(option1,"1",1) == 0) /*�s��O��Ʋέp*/
	{
		if(strncmp(option3,"1",1) == 0)
		{
			/*��j*/
			strcpy(stmp2,"AND a.fcard_class = '1' AND (a.irelative_ply IS NULL OR trim(a.irelative_ply) = '') ");
			strcat(stmpx,"��j");
			
		}
		else if(strncmp(option3,"2",1) == 0)
		{
			/*���*/
			strcpy(stmp2,"AND a.fcard_class = '2' AND (a.irelative_ply IS NULL OR trim(a.irelative_ply) = '') ");
			strcat(stmpx,"���");
		}
		else 
		{
			/*�j+��*/
			strcpy(stmp2,"AND a.fcard_class = '2' AND a.irelative_ply IS NOT NULL AND trim(a.irelative_ply) != '' ");
			strcat(stmpx,"�j+��");
		}
	
		$create temp table ply_tmp
		(
			iquota         char(6),
			ilast_ply      char(20),
			AAA            char(1),
			EB_AAA         char(1)
		) with no log;
		
		for(k=0;k<count_db;k++)
		{ 
			sprintf_s(stmt, sizeof stmt,"INSERT INTO ply_tmp  "
			             "SELECT a.iquota,(CASE WHEN length(trim(ilast_ply)) > 0 THEN 'Y' ELSE 'N' END ) AS ilast_ply,  "
			             "       CASE WHEN (SELECT count(*) FROM car_code   "
			             "                                 WHERE kind = 'SR'   "
			             "                                   AND detail = b.iroute AND detail2 = a.iofficer  "
			             "                                   AND a.ipolicy[6,7] <> 'EB'   "
			             "                                   AND b.nequipment[7] NOT in ('2','3','6','7','A','B','E','F','I','J','M','N','Q','R','U','V','Y','Z','c','d','g','h','k','l','o','p','s','t','w','x','-','.')) > 0 THEN 'Y' ELSE 'N' END AS AAA,  "
			             "       CASE WHEN (a.ipolicy[6,7] = 'EB' AND (a.itmp_policy [6,7] = 'CP' OR a.itmp_policy [5,7] = 'CVQ') AND   "
			             "                  ((a.iofficer = '000756' AND b.iroute = 'PC53402587') OR   "
			             "                   (a.iofficer = '05A0069002' AND b.iroute = 'KBI05A009') OR   "
			             "                   (a.iofficer = 'Y62032E022' AND b.iroute = 'BA29124748') OR  "
			             "                   (a.iofficer = 'Z6203926' AND b.iroute = 'PA54363788') OR   "
			             "                   (a.iofficer = '711690' AND b.iroute = 'PE29033682'))) THEN 'Y' ELSE 'N' END AS EB_AAA  "
			             "  FROM %s:ori_ply_relation a, %s:original_ply b  "
			             " WHERE a.ipolicy = b.ipolicy  "
			             "   AND a.dpolicy >= '01/11/2016'  "
		                 "   AND a.fout_print = '1'  "
		                 "   AND a.fmail_type != '0'  "
		                 "   %s  %s  "
		                 "   AND a.dout_trans between '%s' AND '%s'",list[k].dbname,list[k].dbname,stmp1,stmp2,dbgn_q,dend_q);
			$PREPARE ply_1 FROM $stmt;
			$EXECUTE ply_1;
		}
	}
	else if(strncmp(option1,"2",1) == 0) /*�e�~�Ʋέp*/
	{	
		if(strncmp(option3,"1",1) == 0)
		{
			strcat(stmpx,"��j");
			$create temp table ply_out_tmp1
			(
				iquota         char(6),
				dout_trans     date,
				count          int,
				nbranch        char(40),
				db_tmp         char(2)
			) with no log;
			
			for(k=0;k<count_db;k++)
			{ 
				strncpy(db_tmp,list[k].dbname+4,2);
				db_tmp[2] = '\0';
				printf("db_tmp[%s] \n",db_tmp);
				sprintf_s(stmt, sizeof stmt,"INSERT INTO ply_out_tmp1  "
				             "SELECT a.iquota,date(a.dout_trans),count(a.ipolicy),  "
				             "      (SELECT nbranch FROM sa_branch_type WHERE ibranch = a.iquota[1,4]||'00'),'%s'  "
				             "  FROM %s:ori_ply_relation a,%s:original_ply b  "
				             " WHERE a.ipolicy = b.ipolicy  "
				             "   AND a.dpolicy >= '01/11/2016'  "
				             "   AND a.fout_print = '1'  "
				             "   AND a.fmail_type != '0'  "
				             "   AND a.fcard_class = '1'  "
				             "   AND (trim(nvl(a.irelative_ply,'')) = '' OR (SELECT count(*) FROM %s:ori_ply_relation WHERE ipolicy = a.irelative_ply AND fout_print = '1' AND fmail_type <> '0') = 0)  "
				             "   %s  "
				             "   AND a.dout_trans between '%s' AND '%s'  "
				             "   GROUP BY 1,2",db_tmp,list[k].dbname,list[k].dbname,list[k].dbname,stmp1,dbgn_q,dend_q);
				printf("stmt[%s]",stmt);
				$PREPARE ply_out_1 FROM $stmt;
				$EXECUTE ply_out_1;
			}
		}
		else 
		{
			$create temp table ply_out_tmp2
			(
			    ipolicy        char(20),
				iquota         char(6),
				dout_trans     date,
				icar_type      char(2),
				drate_ym       int,
				fcar_class     char(4),
				count          int,
				iins_147       char(1),
				iins_47        char(1),
				iins_50        char(1),
				AAA            char(1),
				EB_AAA         char(1),
				db_tmp         char(2)
			) with no log;

			if(strncmp(option3,"2",1) == 0)
				strcat(stmpx,"���");
			else
				strcat(stmpx,"�j+��");
					
			for(k=0;k<count_db;k++)
			{ 
				strncpy(db_tmp,list[k].dbname+4,2);
				db_tmp[2] = '\0';
				printf("db_tmp[%s] \n",db_tmp);
				if(strncmp(option3,"2",1) == 0)
				{
					sprintf_s(stmt, sizeof stmt,"INSERT INTO ply_out_tmp2  "
					            " SELECT a.ipolicy,a.iquota,date(a.dout_trans) AS dout_trans,a.icar_type,CAST((SELECT max(drate_ym) FROM %s:ori_ins_type WHERE ipolicy = a.ipolicy) AS int) AS drate_ym,  "
					            "        (SELECT fcar_class FROM car_type WHERE icode = a.icar_type AND fclass = '1') AS fcar_class,  "
					            "        CASE WHEN (SELECT count(*) FROM insurance_type WHERE fins_grp='1' AND iins_type = iins_ply AND iins_type IN (SELECT iins_type FROM %s:ori_ins_type WHERE ipolicy = a.ipolicy)) > 0 THEN '1' ELSE '0' END AS count,  "
					            "        CASE WHEN (SELECT count(*) FROM %s:ori_ins_type WHERE ipolicy = a.ipolicy AND iins_type != '147' ) = 0 THEN 'Y' ELSE 'N' END AS iins_147,  "
					            "        CASE WHEN (SELECT count(*) FROM %s:ori_ins_type WHERE ipolicy = a.ipolicy AND iins_type != '47' ) = 0 THEN 'Y' ELSE 'N' END AS iins_47,  "
					            "        CASE WHEN (SELECT count(*) FROM %s:ori_ins_type WHERE ipolicy = a.ipolicy AND iins_type != '50' ) = 0 THEN 'Y' ELSE 'N' END AS iins_50,  "
					            "        CASE WHEN (SELECT count(*) FROM car_code   "
					            "                                  WHERE kind = 'SR'   "
					            "                                    AND detail = b.iroute AND detail2 = a.iofficer  "
					            "                                    AND a.ipolicy[6,7] <> 'EB'   "
					            "                                    AND b.nequipment[7] NOT in ('2','3','6','7','A','B','E','F','I','J','M','N','Q','R','U','V','Y','Z','c','d','g','h','k','l','o','p','s','t','w','x','-','.')) > 0 THEN 'Y' ELSE 'N' END AS AAA,  "
					            "        CASE WHEN (a.ipolicy[6,7] = 'EB' AND (a.itmp_policy [6,7] = 'CP' OR a.itmp_policy [5,7] = 'CVQ') AND   "
					            "                   ((a.iofficer = '000756' AND b.iroute = 'PC53402587') OR   "
					            "                    (a.iofficer = '05A0069002' AND b.iroute = 'KBI05A009') OR   "
					            "                    (a.iofficer = 'Y62032E022' AND b.iroute = 'BA29124748') OR  "
					            "                    (a.iofficer = 'Z6203926' AND b.iroute = 'PA54363788') OR   "
					            "                    (a.iofficer = '711690' AND b.iroute = 'PE29033682'))) THEN 'Y' ELSE 'N' END AS EB_AAA,'%s'  "
					            "   FROM %s:ori_ply_relation a, %s:original_ply b  "
					            "  WHERE a.ipolicy = b.ipolicy  "
					            "    AND a.fout_print = '1'  "
					            "    AND a.fmail_type != '0'  "
					            "    AND a.fcard_class = '2'  "
					            "    AND (trim(nvl(a.irelative_ply,'')) = '' OR (SELECT count(*) FROM %s:ori_ply_relation WHERE ipolicy = a.irelative_ply AND fout_print = '1' AND fmail_type <> '0') = 0)   "
					            "    %s  "
					            "    AND a.dout_trans between '%s' AND '%s' ",list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,db_tmp,list[k].dbname,list[k].dbname,list[k].dbname,stmp1,dbgn_q,dend_q);
					printf("stmt[%s] \n",stmt);
					$PREPARE ply_out_2 FROM $stmt;
					$EXECUTE ply_out_2;
				}
				else
				{
					sprintf_s(stmt, sizeof stmt,"INSERT INTO ply_out_tmp2  "
					             "SELECT a.ipolicy,a.iquota,date(a.dout_trans) AS dout_trans,a.icar_type,CAST((SELECT max(drate_ym) FROM %s:ori_ins_type WHERE ipolicy = a.irelative_ply) AS int) AS drate_ym,  "
					             "       (SELECT fcar_class FROM car_type WHERE icode = a.icar_type AND fclass = '1') AS fcar_class,  "
					             "       CASE WHEN (SELECT count(*) FROM insurance_type WHERE fins_grp='1' AND iins_type = iins_ply AND iins_type IN (SELECT iins_type FROM %s:ori_ins_type WHERE ipolicy = a.irelative_ply)) > 0 THEN '1' ELSE '0' END AS count,  "
					             "       CASE WHEN (SELECT count(*) FROM %s:ori_ins_type WHERE ipolicy = a.ipolicy AND iins_type != '147' ) = 0 THEN 'Y' ELSE 'N' END AS iins_147,  "
					             "       CASE WHEN (SELECT count(*) FROM %s:ori_ins_type WHERE ipolicy = a.ipolicy AND iins_type != '47' ) = 0 THEN 'Y' ELSE 'N' END AS iins_47,  "
					             "       CASE WHEN (SELECT count(*) FROM %s:ori_ins_type WHERE ipolicy = a.ipolicy AND iins_type != '50' ) = 0 THEN 'Y' ELSE 'N' END AS iins_50,  "
					             "       CASE WHEN (SELECT count(*) FROM car_code   "
					             "                                 WHERE kind = 'SR'   "
					             "                                   AND detail = b.iroute AND detail2 = a.iofficer  "
					             "                                   AND a.ipolicy[6,7] <> 'EB'   "
					             "                                   AND b.nequipment[7] NOT in ('2','3','6','7','A','B','E','F','I','J','M','N','Q','R','U','V','Y','Z','c','d','g','h','k','l','o','p','s','t','w','x','-','.')) > 0 THEN 'Y' ELSE 'N' END AS AAA,  "
					             "       CASE WHEN (a.ipolicy[6,7] = 'EB' AND (a.itmp_policy [6,7] = 'CP' OR a.itmp_policy [5,7] = 'CVQ') AND   "
					             "                  ((a.iofficer = '000756' AND b.iroute = 'PC53402587') OR   "
					             "                   (a.iofficer = '05A0069002' AND b.iroute = 'KBI05A009') OR   "
					             "                   (a.iofficer = 'Y62032E022' AND b.iroute = 'BA29124748') OR  "
					             "                   (a.iofficer = 'Z6203926' AND b.iroute = 'PA54363788') OR   "
					             "                   (a.iofficer = '711690' AND b.iroute = 'PE29033682'))) THEN 'Y' ELSE 'N' END AS EB_AAA,'%s'  "
					             "  FROM %s:ori_ply_relation a, %s:original_ply b  "
					             " WHERE a.ipolicy = b.ipolicy  "
					             "   AND a.fout_print = '1'  "
					             "   AND a.fmail_type != '0'  "
					             "   AND a.fcard_class = '1'  "
					             "   AND trim(nvl(a.irelative_ply,'')) != ''  "
                                 "   AND (SELECT count(*) FROM %s:ori_ply_relation WHERE ipolicy = a.irelative_ply AND fout_print = '1' AND fmail_type <> '0') > 0  "
                                 "   %s  "
					             "   AND a.dout_trans between '%s' AND '%s' ",list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,db_tmp,list[k].dbname,list[k].dbname,list[k].dbname,stmp1,dbgn_q,dend_q);
					printf("stmt[%s] \n",stmt);
					$PREPARE ply_out_2 FROM $stmt;
					$EXECUTE ply_out_2;
				}
			}
		}
	}
		
	return M_CM_OK;
	
errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
/*--------------------------------------------------------------------*/


long car658_build()
{
 int rc;
 $char sfilename[256],stitle[2048],stmt1[4096],stmt11[8192];

	$WHENEVER SQLERROR GOTO errexit;

	if(strncmp(option1,"1",1) == 0) /*�s��O��Ʋέp*/
	{
		$create temp table ply_cnt
		(
			iquota  char(10),
			ncode   char(40),
			c1      int,
			c2      int,
			c3      int
		) with no log;

		strcpy(stmt1,"INSERT INTO ply_cnt  "
		             "SELECT iquota,ncode,  "
		             "       (SELECT count(*) FROM ply_tmp i WHERE i.iquota = a.iquota AND i.ilast_ply = 'N') AS c1,  "
		             "       (SELECT count(*) FROM ply_tmp j WHERE j.iquota = a.iquota AND j.ilast_ply = 'Y') AS c2,  "
		             "       (SELECT count(*) FROM ply_tmp k WHERE k.iquota = a.iquota AND (k.AAA = 'Y' OR k.EB_AAA = 'Y')) AS c3  "
		             "  FROM ply_tmp a,sa_branch_type b,cu_code_data c  "
		             " WHERE a.iquota = b.ibranch  "
		             "   AND b.group2 = c.icode  "
		             "   AND c.itype = '19'   "
		             " GROUP BY 1,2");
		$PREPARE ply_cnt1 FROM $stmt1;
		$EXECUTE ply_cnt1;

		sprintf_s(sfilename, sizeof sfilename,"�e�~�s��O��Ʋέp[%s]\n",stmpx);
		sprintf_s(stitle, sizeof stitle,"�ҰϥN��\t�Ұ�\t�s�O\t��O\t��I�g��\t");
		strcpy(stmt11,"SELECT c.icode, c.ncode,nvl(sum(c1),0),nvl(sum(c2),0),nvl(sum(c3),0)  "
		              "  FROM cu_code_data c,outer(ply_cnt a,sa_branch_type b)   "
		              " WHERE a.iquota = b.ibranch  "
		              "   AND c.icode = b.group2  "
		              "   AND c.itype = '19'   "
		              "  GROUP BY 1,2  "
		              "  ORDER BY 1;");
		rc = unload_file(outputf," ",sfilename,stitle,stmt11);
		$DROP TABLE ply_tmp;
		$DROP TABLE ply_cnt;
	}
	else if(strncmp(option1,"2",1) == 0) /*�e�~��Ʋέp*/
	{
		
		if(strncmp(option3,"1",1) == 0)
		{
			sprintf_s(sfilename, sizeof sfilename,"�e�~��Ʋέp[%s]\n",stmpx);
			sprintf_s(stitle, sizeof stitle,"���\t�e�~���\t���\t���W��\t��Ʈw�O\t");
			strcpy(stmt11,"SELECT iquota,dout_trans,count,nbranch,db_tmp FROM ply_out_tmp1 ");
			rc = unload_file(outputf," ",sfilename,stitle,stmt11);
			$DROP TABLE ply_out_tmp1;
		}
		else
		{
			sprintf_s(sfilename, sizeof sfilename,"�e�~��Ʋέp[%s]\n",stmpx);
			sprintf_s(stitle, sizeof stitle,"���N��\t�e�~���\t���\t1\t2\t3\t4\t5\t6\t7\t8\t9\tA\tB\tC\t147\t47\t50\t��I�g��\t���W��\t��Ʈw�O\t");
			strcpy(stmt11,"SELECT a.iquota,date(a.dout_trans),count(a.ipolicy),  "
	                            " (SELECT count(*) FROM ply_out_tmp2 WHERE iquota = a.iquota AND dout_trans= a.dout_trans AND db_tmp = a.db_tmp AND icar_type NOT IN ('01','02','32','34','35','51') AND drate_ym = 79 AND fcar_class = '1' AND count = '1' AND iins_47 = 'N' AND iins_50 = 'N' AND iins_147 = 'N'),  "
	                            " (SELECT count(*) FROM ply_out_tmp2 WHERE iquota = a.iquota AND dout_trans= a.dout_trans AND db_tmp = a.db_tmp AND icar_type NOT IN ('01','02','32','34','35','51') AND drate_ym = 79 AND fcar_class = '1' AND count = '0' AND iins_47 = 'N' AND iins_50 = 'N' AND iins_147 = 'N'),  "
	                            " (SELECT count(*) FROM ply_out_tmp2 WHERE iquota = a.iquota AND dout_trans= a.dout_trans AND db_tmp = a.db_tmp AND icar_type IN ('01','02','32','34','35') AND drate_ym = 79 AND iins_47 = 'N' AND iins_50 = 'N' AND iins_147 = 'N'),  "
	                            " (SELECT count(*) FROM ply_out_tmp2 WHERE iquota = a.iquota AND dout_trans= a.dout_trans AND db_tmp = a.db_tmp AND icar_type NOT IN ('01','02','32','34','35','51') AND fcar_class = '2' AND iins_47 = 'N' AND iins_50 = 'N' AND iins_147 = 'N'),  "
	                            " (SELECT count(*) FROM ply_out_tmp2 WHERE iquota = a.iquota AND dout_trans= a.dout_trans AND db_tmp = a.db_tmp AND icar_type NOT IN ('01','02','32','34','35','51') AND drate_ym = 78 AND fcar_class = '1' AND count = '1' AND iins_47 = 'N' AND iins_50 = 'N' AND iins_147 = 'N'),  "
	                            " (SELECT count(*) FROM ply_out_tmp2 WHERE iquota = a.iquota AND dout_trans= a.dout_trans AND db_tmp = a.db_tmp AND icar_type NOT IN ('01','02','32','34','35','51') AND drate_ym = 78 AND fcar_class = '1' AND count = '0' AND iins_47 = 'N' AND iins_50 = 'N' AND iins_147 = 'N'),  "
	                            " (SELECT count(*) FROM ply_out_tmp2 WHERE iquota = a.iquota AND dout_trans= a.dout_trans AND db_tmp = a.db_tmp AND icar_type IN ('01','02','32','34','35') AND drate_ym = 78 AND iins_47 = 'N' AND iins_50 = 'N' AND iins_147 = 'N'),  "
	                            " (SELECT count(*) FROM ply_out_tmp2 WHERE iquota = a.iquota AND dout_trans= a.dout_trans AND db_tmp = a.db_tmp AND icar_type IN ('51') AND drate_ym >= 79),  "
	                            " (SELECT count(*) FROM ply_out_tmp2 WHERE iquota = a.iquota AND dout_trans= a.dout_trans AND db_tmp = a.db_tmp AND icar_type IN ('51') AND drate_ym = 78),  "
	                            " (SELECT count(*) FROM ply_out_tmp2 WHERE iquota = a.iquota AND dout_trans= a.dout_trans AND db_tmp = a.db_tmp AND icar_type NOT IN ('01','02','32','34','35','51') AND drate_ym >= 80 AND fcar_class = '1' AND count = '1' AND iins_47 = 'N' AND iins_50 = 'N' AND iins_147 = 'N'),  "
	                            " (SELECT count(*) FROM ply_out_tmp2 WHERE iquota = a.iquota AND dout_trans= a.dout_trans AND db_tmp = a.db_tmp AND icar_type NOT IN ('01','02','32','34','35','51') AND drate_ym >= 80 AND fcar_class = '1' AND count = '0' AND iins_47 = 'N' AND iins_50 = 'N' AND iins_147 = 'N'),  "
	                            " (SELECT count(*) FROM ply_out_tmp2 WHERE iquota = a.iquota AND dout_trans= a.dout_trans AND db_tmp = a.db_tmp AND icar_type IN ('01','02','32','34','35') AND drate_ym >= 80 AND iins_47 = 'N' AND iins_50 = 'N' AND iins_147 = 'N'),  "
	                            " (SELECT count(*) FROM ply_out_tmp2 WHERE iquota = a.iquota AND dout_trans= a.dout_trans AND db_tmp = a.db_tmp AND iins_147 = 'Y' AND iins_47 = 'N' AND iins_50 = 'N'),  "
	                            " (SELECT count(*) FROM ply_out_tmp2 WHERE iquota = a.iquota AND dout_trans= a.dout_trans AND db_tmp = a.db_tmp AND iins_47 = 'Y' AND iins_147 = 'N' AND iins_50 = 'N'),  "
	                            " (SELECT count(*) FROM ply_out_tmp2 WHERE iquota = a.iquota AND dout_trans= a.dout_trans AND db_tmp = a.db_tmp AND iins_50 = 'Y' AND iins_47 = 'N' AND iins_147 = 'N'),  "
	                            " (SELECT count(*) FROM ply_out_tmp2 WHERE iquota = a.iquota AND dout_trans= a.dout_trans AND db_tmp = a.db_tmp AND (AAA = 'Y' OR EB_AAA = 'Y')),  "
	                            " (SELECT nbranch FROM sa_branch_type WHERE ibranch = a.iquota[1,4]||'00'),db_tmp  "
	                      "  FROM ply_out_tmp2 a  "
	                      " GROUP BY 1,2,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21");
			rc = unload_file(outputf," ",sfilename,stitle,stmt11);
			$DROP TABLE ply_out_tmp2;	
		}
	}
	
	if (rc != SUCCESS) 
	{
	    sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
	    EWRITE(userid, rc , msgbuf);
	    return rc;
	}
	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	return SQLCODE;
}
