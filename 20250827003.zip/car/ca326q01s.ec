/****************************
 *  Program  : ca326        *
 *  Author  : cj.lee        *
 *  Date    : 2000.03.01    *
 *                          *
 ***************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
$include "cmnroute.h";
#include "sql.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"
#include "commsgs.h"
#include "carmsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"
#define  NEXTPAGE   7
#define fmt "--,---,---,--&"
#define  attach_deli   ","

double d45();

$char  DBName[DBNAME], DBNameFull[20], tbuf[13];
$char  UserID[11];
$char  BodyFile[21],TitleFile[21],BodyFmt[21],FormTp[3];;
$char  TitleFile[21],TitleFmt[21];
char   outputf[50],OutFile[21];
$int   ItemRow,TotColumn;
$int   StartRow,TitleRow;
$int   PgLine,Width;
int    max_count = 0;
long   rc, rtn;

$char cdbgn[YYYMMDD],cdend[YYYMMDD];
$char edbgn[11],edend[11],proc_type[2];
$char iquota[7],iofficer[EMPLOYEE_ID],ileader[11];
$char LHsIlicense[11],fcardclass[2],mail[2];
$char ipolicy_tmp[21],ireaply_tmp[21],nassure_tmp[27],zipcode_tmp[CA_ZIP];
$char sex_tmp[2],fassure_tmpr[2],address_tmp[91];
$char xIpolicy[21];
$char dyy[4],dmm[3];
$int  iyy,imm;

FILE  *sfp,*fp;
static char  *bp;
static int   recLen=1024;
$static int  kpid;
char  getfile[150], flgExec[2], txtfile[120];
char  flgOldNew[2],exedate[8],fname6days[8],fname20days[8];
int   iOldNew;
$char sMsg[256];
char  str[100];
FILE  *sfp;
long  read_count;
char  sReason[65];
$char d6DaysBgn[10],d6DaysEnd[10],d20DaysBgn[10],d20DaysEnd[10],dfname20days[10];
$char d6DaysBgn_e[11],d6DaysEnd_e[11],d20DaysBgn_e[11],d20DaysEnd_e[11];
$long ld6DaysBgn,ld6DaysEnd,ld20DaysBgn,ld20DaysEnd,lfname20days;
$char sNewAddr[121]=" ",v_sMsg[513];
$char dSendDate[10];
char sTmp_db_name[21];
$long lSendDate;

/* -------------------------------------------------------------------------- */
/* �����_�O��O�O�p����� */
$char  drate_ym[4],chgrate[2];
$char  dbegin[11], dend[11], dend2[11], sTmpChDate[11], sTmpChDate_pay[11], paydate[11],
       iestimate_ori[21], iestimate_sug[21], itransno_ori[21], itransno_sug[21],
       ori_Bcode1[12], ori_Bcode2[19], ori_Bcode3[18],
       sug_Bcode1[12], sug_Bcode2[19], sug_Bcode3[18],
       cmprem1[11], cmprem2[11],
       itransno_ori_007[21],itransno_ori_008[21],itransno_ori_009[21],itransno_ori_atm[21],
       itransno_ori_013[21],itransno_ori_MKT[21],
       itransno_sug_007[21],itransno_sug_008[21],itransno_sug_009[21],itransno_sug_atm[21],
       itransno_sug_013[21],itransno_sug_MKT[21],
       F_type[5];
$long  injured_cover_comp, death_cover_comp, damage_cover_comp;
$int   iyear=0, mprem1, mprem2;
/* -------------------------------------------------------------------------- */
/* �����_�O��n�Q�O�H����(�̷s�O���ɸ��) */
$char  ilicense[11],s_nassured[121],aassured_zip[CA_ZIP],aassured[91],dbirth[11],
       itel_night[21],mobil_phone[21],iassured_cntry[2],foccup[2],noccup[6],
       fsex[2],fmarriage[2],fassured[2],iemail[51],bitel[21],itag[CA_TAG_NUM], 
       ndeputy_assured[51],nuser[19],nbenef[43],tmobile_eply[21],aemail_eply[51],
       iapplicant[13],napplicant[121],apayment_zip[CA_ZIP],apayment[91],
       dbirth_appl[11],fsex_appl[2],fapplicant[2],aemail_appl[51],itel_appl[21],
       tmobile_appl[21],iapplicant_cntry[2],applicant_foccup[2],applicant_noccup[6],
       ndeputy_appl[51],nrelation_appl[41];
/* -------------------------------------------------------------------------- */
     
extern char *replace_str();
char *get_car_full_db();
long ca326_readfile();
int get_ipolicy();
int GetNo302Reason();


main(argc, argv)
int argc;
char **argv;
{
    int   rc;
    int   i;
    
    batchinit();
    strcpy(DBName, isNULLstr(argv[1]));
    strcpy(UserID, isNULLstr(argv[2]));
/*    
    strcpy(dyy,    isNULLstr(argv[3]));
    strcpy(dmm,    isNULLstr(argv[4]));    
    strcpy(txtfile,isNULLstr(argv[5]));
*/    
    
    strcpy(flgExec,    isNULLstr(argv[3]));   /* 1�G�j��G�T���q��; 2�G�Ȥ����hemail; 3�G�j���I�_�O�ĤT���޲zemail�q�� */
    strcpy(dSendDate,  isNULLstr(argv[4]));
    strcpy(txtfile,    isNULLstr(argv[5]));
    strcpy(flgOldNew,  isNULLstr(argv[6]));   /* 1�G�s��; 2�G�¦� */
    strcpy(exedate,    isNULLstr(argv[7]));
    strcpy(fname6days, isNULLstr(argv[8]));
    strcpy(fname20days,isNULLstr(argv[9]));
    strcpy(d6DaysBgn,  isNULLstr(argv[10]));
    strcpy(d6DaysEnd,  isNULLstr(argv[11]));
    strcpy(d20DaysBgn, isNULLstr(argv[12]));
    strcpy(d20DaysEnd, isNULLstr(argv[13]));
    strcpy(outputf,    isNULLstr(argv[14]));
    
    printf("DBName[%s],UserID[%s],txtfile[%s],flgOldNew[%s],exedate[%s],fname6days[%s],fname20days[%s],outputf[%s]\n",
            DBName,UserID,txtfile,flgOldNew,exedate,fname6days,fname20days,outputf);
    printf("Trace -- dSendDate = [%s] \n",  dSendDate);   
    
    strcpy(d6DaysBgn_e,  trim(cm_to_infdate(d6DaysBgn)));
    strcpy(d6DaysEnd_e,  trim(cm_to_infdate(d6DaysEnd)));
    strcpy(d20DaysBgn_e, trim(cm_to_infdate(d20DaysBgn)));
    strcpy(d20DaysEnd_e, trim(cm_to_infdate(d20DaysEnd)));

    ld6DaysBgn  = cm_ymd_cdate(d6DaysBgn);
    ld6DaysEnd  = cm_ymd_cdate(d6DaysEnd);
    ld20DaysBgn = cm_ymd_cdate(d20DaysBgn);
    ld20DaysEnd = cm_ymd_cdate(d20DaysEnd);  
    
    dfname20days[0]=fname20days[0];
    dfname20days[1]=fname20days[1];
    dfname20days[2]=fname20days[2];
    dfname20days[3]='/';
    dfname20days[4]=fname20days[3];
    dfname20days[5]=fname20days[4];
    dfname20days[6]='/';
    dfname20days[7]=fname20days[5];
    dfname20days[8]=fname20days[6];  
    dfname20days[9]='\0';    
    lfname20days = cm_ymd_cdate(dfname20days);

    printf("d6DaysBgn[%s],d6DaysEnd[%s],d20DaysBgn[%s],d20DaysEnd[%s]\n",
            d6DaysBgn,d6DaysEnd,d20DaysBgn,d20DaysEnd);

    printf("d6DaysBgn_e[%s],d6DaysEnd_e[%s],d20DaysBgn_e[%s],d20DaysEnd_e[%s]\n",
            d6DaysBgn_e,d6DaysEnd_e,d20DaysBgn_e,d20DaysEnd_e);

    printf("ld6DaysBgn[%ld],ld6DaysEnd[%ld],ld20DaysBgn[%ld],ld20DaysEnd[%ld],lfname20days[%ld]\n",
            ld6DaysBgn,ld6DaysEnd,ld20DaysBgn,ld20DaysEnd,lfname20days);

              
    iOldNew = atoi(flgOldNew);           
            
    strcpy(sMsg," ");
    sfp = (FILE *) STARTLOG();   
    
    rc = ca326_readfile(); 
    if ( rc != M_CM_OK) 
    {
    	EWRITE( UserID,rc,sMsg);
        return rc;
    }    
    printf("Trace -- ca326_readfile() OK  \n");
    
    if (flgExec[0]!='3')
    {
        rc = ChkRate();     /* �ˮֱj���I�O�v */
        if (rc != SUCCESS)
        {
            EWRITE( UserID,rc,sMsg);
            return rc;
        }    	
        printf("���������� ChkRate OK !!! \n");
    
        rc = Get_comp_prem();     /* �j���I�O�O�p�� */
        if (rc != SUCCESS)
        {
            EWRITE( UserID,rc,sMsg);
            return rc;
        }
        printf("���������� Get_comp_prem OK !!! \n");
        /* rc = upd302("70203M9004079","01");
        sleep(10);
        return FAIL; */
    
        rc = ca3261_build();
        if ( rc != M_CM_OK)
        {
            EWRITE( UserID,rc,sMsg);
            return rc;
        }
        printf("Trace -- ca3261_build() OK  \n");
    }
    else
    {
    	/* 3: �j���I�_�O�ĤT���޲zemail�q��*/
    	/*1100927007_SC1_�W�[car326�j��G���q����X�ɮק@�~���涵�ؿﶵ*/
        rc = ca3262_build();
        if ( rc != M_CM_OK)
        {
            EWRITE( UserID,rc,sMsg);
            return rc;
        }
        printf("Trace -- ca3262_build() OK  \n");
    }
    
    if((rc = save_form_info(F_FREE,"CA",302, UserID, FormTp,
        max_count, outputf)) < 0)
        EWRITE(UserID,rc,"save form info failed");
   
    if (sfp!=NULL) ENDLOG(sfp); 
}

long ca3261_build()
{
    int rc = 0;
    $char FormFile[N_FILE +1];
  
    $WHENEVER SQLERROR GOTO errexit;
 

    printf("197: DBName [%s]\n",DBName); 
     
    $SELECT kPgNum_Line, nForm_File, iForm_Tp
       INTO $PgLine, $FormFile, $FormTp
       FROM Form
      WHERE ksys_grp="CA" AND kPgmID = 302 ;

    strcpy( FormFile,rtrim(FormFile));
    sprintf_s(OutFile, sizeof OutFile,"%s.tx",outputf);

    /*----- build body -----*/

    rgu_init_report( FormFile,OutFile);

    if (flgExec[0]=='2')
    {   
        /* �Ȥ����hEmail */
        lSendDate   = cm_ymd_cdate(dSendDate);
        /* create temp table */
	$create temp table temp1
	(		  
	    project_id     char(7) not null,
	    mail_date      date,
	    receiver_email char(50),
	    receiver_name  varchar(16) default ' ',
	    cc             varchar(50) default ' ',
	    content        char(9000),
	    key            varchar(50) default ' ',
	    mail_count     smallint ,
	    subject        varchar(255)  default ' ',
	    nattachment    varchar(100) default ' '
        ) with no log ;   		   
    }	 
	          
    rc = ca3261();   
    
    printf("232:  ca3261()=[%d]  \n",rc);    
    if(rc != M_CM_OK) return rc;
    
    rgu_finish_report();
    return M_CM_OK;

errexit :
    printf("ca3261_build: SQLCODE:[%d]",SQLCODE);
    return SQLCODE;
}
 

long ca3261()
{
    $char   stmt[4096],sWhere[1024],sOrder[1024],stmt1[512];
    $char   ibig_branch[21],ibig_office[15],nname[41],itel[15],nassured[121];
    $char   ncar_type[17],ipro_year[5];
    $char   iissue_ym[7],nbrand_abbr[17],iengine[CA_ENGINE_NUM],fpt[2],iengine_x[CA_ENGINE_NUM],itag_x[CA_TAG_NUM];
    $long   minjured_cover,mdeath_cover,mdamage_cover;
    $long   fcomp_prem,tot_prem,v_prem;
    $double qcylinder = 0;  /* �Ʈ�q�X�ܤp���I2�� (1080902001_SC3) */
    $long   mdeduct,mins_premium;
    $double qpt = 0;
    $char   dply_begin[11],dply_end[11];
    $char   xiofficer[11],ipolicy[21],iins_type[5];
    $char   ibig_comp[2],ibig_sales[11],bibig_office[10],ofname[20];
    $char   bnname[11],icar_type[3],fcard_class[2],ch_deduct[21];
    $char   sTmp[200],sTmp1[200],file0[101],Tmp1[41];
    $char   irelative_ply[21];
    $char   sYY[4],sMM[4],sDD[4];
    $char   iquota_tmp[11],ileader_tmp[11];
    $int    t_count,rt;
    $char   sSDB[3],sFull[30],prtstr[5000],sApHome[31];
    char    sFilename[51], IsMoto2[2];
    $long   comp_prem;
    $char   tphone_con[21],imovephone[21],tmpEmail[51];
    char    ttday[21],ttday_yy[5],ttday_mm[3],ttday_dd[3],No_miss_str[121];
    FILE    *fp0;
    long    rc;
    int     i,xx,fLast;
    $char   xxy[21], nequipment[31],sequip_str30[201],No302_ipolicy[21],inext_ply[21];
    long    inext_count,tot_count,mot_count,car_count,no302_count,mot_count_2,car_count_2,mot_count_3,car_count_3,iaddr_err_count;
    $long   ldply_begin = 0,ldply_end;
    $int    chkAddrTrans = 0;
    $int    icount,n;
    $char   project_id[8], receiver_email[51], receiver_name[17],content[9000];
    $char   ileader_ext[5], ileader_email[51];
    $char   cc[51], key[51], subject[256],nofficer[11],pre_ileader_tmp[11],
            pre_sFilename[51],pre_nleader[11],nsend[11],isend[11],email_notify[51];        
    $int    mail_count,no_email_count,no_tag_count;
    $char   iroute[21], fcomp_24[2];
    long    tot_count_c   = 0;  /* �Ȥ�email���          */
    long    tot_count_m   = 0;  /* �޲z�Hemail���        */
     
    /* �Ӹ�B�n add by larry 103.02.19 (1030211003_C1) */
    $char   sNassured[121],sBitel[21],sTphone_con[21],sDbirth[11],sIemail[51];
    

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(ttday , cm_get_sysd2_100());
    printf("294:ttday[%s]\n",ttday);
     
    /* �̿� 6/30/2013����A���A�i��s�a�}�ഫ */
    $SELECT first 1 ( '06/30/2013'::date-today)  INTO $chkAddrTrans FROM systables;     	

    strncpy(ttday_yy,&ttday[0],3);  ttday_yy[3] = '\0';
    strncpy(ttday_mm,&ttday[4],2);  ttday_mm[2] = '\0';
    strncpy(ttday_dd,&ttday[7],2);  ttday_dd[2] = '\0';
     

    inext_count = 0; /* �w��O���    */
    tot_count   = 0; /* �`���        */
    mot_count   = 0; /* �������      */
    car_count   = 0; /* �T�����      */
    no302_count = 0; /* �L��O��ƥ��*/     
    
    mot_count_2  = 0; /* �����j��G�����   */
    mot_count_3  = 0; /* �����j��T�����   */
    car_count_2  = 0; /* �T���j��G�����   */
    car_count_3  = 0; /* �T���j��T�����   */
    iaddr_err_count = 0; /* ���ഫ�a�}���ഫ���Ѥ���� */	     
    no_tag_count = 0;
    tot_count_c = 0;
    tot_count_m = 0;
    
    rt = getApHome(sApHome);
    if (rt < 0) {
          printf("read Config file error!!\n");
          return M_CM_READ_CONFIG_ERR;
    }

    sprintf_s(sTmp, sizeof sTmp,"�� ��J��ơG%d\n",read_count);
    rgu_put_body_string(1,sTmp,1);max_count++;
    rgu_put_body(1); max_count++;
			 	     
    if (flgExec[0]=='1')
    {
	/* ���s�G�T���q���ɮ� */ 
        if (iOldNew==1){  /* �s�� */
	    sprintf_s(Tmp1, sizeof Tmp1,"�j��G�T_%s(%s_%s).txt",exedate,fname6days,fname20days);
	}else{
	    sprintf_s(Tmp1, sizeof Tmp1,"�j��G�T_%s.txt",exedate);
	}
	     	        
	sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);
	sprintf_s(sFilename, sizeof sFilename,Tmp1);
	printf("Tmp1[%s] file0[%s]\n",Tmp1,file0);
	fp0=fopen(file0,"w");
	     
    }else{
        /* �Ȥ����hEmail */ 
        no_email_count = 0;   	 
    }
     	
    strcpy(sequip_str30,equip_instr("30"));
     
    /* ����ĳ��O���j��O�� */
    sprintf_s(stmt, sizeof stmt,"SELECT count(*) FROM %s WHERE %s %s",
                 " reject_policy ",
                 " ipolicy = ? ",
                 " AND fins_grp = '4'");
    $PREPARE reject_ply FROM $stmt;

    sprintf_s(stmt, sizeof stmt, " SELECT nname,ileader   "
                    " FROM officer  "
                    "WHERE iofficer = (select ileader from officer where iofficer = ?)");
    $PREPARE prep1 FROM $stmt;

    /* �����b���אּŪ��ao_rcv_acct add by 061476 (1090220003_SC1) */
    sprintf_s(stmt, sizeof stmt, "SELECT iacc FROM ao_rcv_acct WHERE trcv = ? AND ibank = 'MKT'; ");
    $PREPARE pre_transno FROM $stmt;
    
    printf(" ------- test1 \n " );
     
    /* �k�H�����ťժ���O��,�O�o���|�q�� */
    $INSERT INTO comp_temp 
     SELECT ipolicy FROM policy_302f 
      WHERE fcard_class = '1'
        AND fassured in ('2','4','6')
        AND nvl(itag,' ') = ' '
        AND (dply_begin BETWEEN $d6DaysBgn_e AND $d6DaysEnd_e 
              OR
            dply_begin BETWEEN $d20DaysBgn_e AND $d20DaysEnd_e);      

    printf("=== start get_comp ===\n");
    $DECLARE get_comp CURSOR for
       SELECT ipolicy 
         FROM comp_temp;
    $OPEN  get_comp;
    while(1)
    {
         $FETCH get_comp INTO $xxy;
         if(SQLCODE == SQLNOTFOUND)                  
         break;
         no_tag_count++;
         printf("xxy [%s]\n", xxy );
    }
    $CLOSE get_comp;
    printf("=== end get_comp ===\n"); 
          
    no_tag_count = no_tag_count - read_count;
     
    sprintf_s(sTmp, sizeof sTmp,"�� �k�H�L���P��ơG%d\n",no_tag_count);
    rgu_put_body_string(1,sTmp,1);max_count++;
    rgu_put_body(1); max_count++;     

    rgu_put_body_string(1," ",1);
    rgu_put_body(1); max_count++;	   
 
    sprintf_s(stmt, sizeof stmt,"SELECT %s %s %s %s %s %s %s %s %s %s %s FROM %s WHERE %s %s %s %s %s %s ",
                  "UNIQUE a.ibig_branch, a.ibig_office, a.nname, a.itel,",
                  "trim(b.nassured), b.aassured_zip, b.aassured, trim(b.napplicant), b.apayment_zip, b.apayment, b.itel,",
                  "to_char(dbirth,'%Y')::integer - 1911 || '/' || to_char(dbirth,'%m')|| '/'||to_char(dbirth,'%d'),",
                  "b.fsex, b.fmarriage, b.ncar_type, b.ipro_year,",
                  "to_char(b.dissue,'%Y')::integer - 1911 || '/' || to_char(b.dissue,'%m'),",
                  "nvl(b.itag,' '), b.nbrand_abbr, b.qcylinder, b.iengine,",
                  "b.qpt, b.fpt, b.dply_begin, b.dply_end, e.nname ,b.irelative_ply,",
                  "b.iofficer, b.ipolicy, b.ibig_comp, b.ibig_office, b.ibig_sales,",
                  "b.icar_type ,b.fcard_class,",
                  "b.ilicense ,b.v_prem ,b.tot_prem  ,b.iquota ,e.ileader, b.comp_prem,",
                  "b.tphone_con,b.imovephone,b.iemail,b.fassured, b.dply_begin, b.dply_end,d.nname,b.iroute, b.fcomp_24 ",
                  " ca_big_office a,policy_302f b,officer d,officer e ",
                  " a.ibig_comp = b.iquota[1,4] || '00' ",
                  "AND a.fclass = '3' ",
                  "AND b.iofficer = d.iofficer ",
                  "AND d.ileader  = e.iofficer ", /* 1121121017_C01 ���g��H�̷s�޲z�H */
                  "AND b.ipolicy IN (SELECT c.ipolicy FROM comp_temp c) ",
                  "ORDER BY b.iquota,e.ileader,b.iofficer,b.ilicense");

    printf("422:stmt[%s]\n", stmt);

    if (flgExec[0]=='1'){
	     strcpy(prtstr,"�O�渹�X");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"���P���X");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"�Q�O�I�H�m�W");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"�l���ϸ�");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"�Q�O�I�H�a�}");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"�n�O�H�m�W");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"�l���ϸ�");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"�n�O�H�a�}");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"���q�q��");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"��������");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"�޲z�H");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"����~");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"�����");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"�����");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"�p���q��");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"��������");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"��l�o��");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"�t�P����");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"�Ʈ�q");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"�������X");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"��������");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"�s�a�}");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"���X�@");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"���X�G(�@�~)");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"���X�T(�@�~)");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"ú�ڴ���(�@�~)");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"ú�ڪ��B(�@�~)");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"�����渹(�@�~)");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"���X�G(�G�~)");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"���X�T(�G�~)");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"ú�ڴ���(�G�~)");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"ú�ڪ��B(�G�~)");
	     strcat(prtstr,"\t");
	     strcat(prtstr,"�����渹(�G�~)");
	     
	     fprintf(fp0,"%s\n",prtstr);
	     printf("504:prtstr[%s]\n",prtstr);
    }else{
     	     strcpy(project_id    ,"CAR326");
             strcpy(pre_ileader_tmp," ");    
             fLast = 0;	
    }

    $PREPARE vyid01 FROM $stmt;
    $DECLARE vy_cur CURSOR with hold FOR vyid01;
    $OPEN vy_cur;  /* USING $iyy,$imm; */
    for(;;)
    {
        $FETCH vy_cur
          INTO $ibig_branch, $ibig_office, $nname, $itel,
               $nassured, $aassured_zip, $aassured, $napplicant, $apayment_zip, $apayment, $bitel,
               $dbirth, $fsex, $fmarriage, $ncar_type, $ipro_year,
               $iissue_ym, $itag, $nbrand_abbr, $qcylinder, $iengine,
               $qpt, $fpt, $dply_begin, $dply_end, $bnname , $irelative_ply,
               $xiofficer, $ipolicy, $ibig_comp, $bibig_office, $ibig_sales,
               $icar_type, $fcard_class,
               $ilicense, $v_prem, $tot_prem, $iquota_tmp, $ileader_tmp, $comp_prem,
               $tphone_con,$imovephone,$iemail,$fassured,$ldply_begin,$ldply_end,$nofficer,$iroute,$fcomp_24;
        if (SQLCODE == SQLNOTFOUND){ 
            if (flgExec[0]=='1'){	
                break;
            }else{
          	fLast = 1; 
            	goto LAST_ILeader;                	
            }  
          	
        }
          
        
        /************************************/
        /*                                  */
        /*  �P�_email����޸��̡A�M��email  */
        /*                                  */
        /************************************/  
        /* �M��iemail������޸� */
        icount = 0;
        for (n=0;n<strlen(iemail); n++)
        {
            if (iemail[n] == 39)
            {
                icount = 1;
                break;
            }
        }
          
        if (icount > 0)
            strcpy(iemail," ");
         
        /*********************************************/
        /*                                           */
        /*  �P�_�]�bcmn152��ID �� car140-CZ��Email   */
        /*  �M��email                                */
        /*                                           */
        /*********************************************/       
        /* check �O�_�b�O��q���ư��M�椤(cmn152) */
        if (flgExec[0]=='2'){
            printf("Trace -- TEST project_id = [%s] \n",  project_id);
            printf("Trace -- TEST ilicense = [%s] \n",  ilicense);
          	  
            /* �s�WŪ��cu_code_data���S�wemail���ư��W��,�bmail�ư��W�椺�����Lemail
               add by sylvia 103.10.07 (1030930001_C2) */
              
            $DECLARE  chkmaila CURSOR for
              select  ncode 
         	from  cu_code_data
               where  itype = 'CZ';
         	$OPEN  chkmaila;
            while(1)
            {
                $FETCH chkmaila INTO $tmpEmail;
         	if(SQLCODE == SQLNOTFOUND)break;
         	     
         	strcpy(iemail,trim(iemail));
         	strcpy(tmpEmail,trim(tmpEmail));
         	printf("a:iemail=[%s]tmpEmail=[%s]\n",iemail,tmpEmail);
         	if(strcasecmp(iemail,tmpEmail)==0)
         	{
         	    strcpy(iemail," ");
         	    break;
         	}
            }
            $close chkmaila;
            $free chkmaila;
            printf("iemail=[%s]tmpEmail=[%s]\n",iemail,tmpEmail);
              
            rc = chk_no_notify("C", project_id, ilicense, v_sMsg);
            printf("Trace -- rc  = [%ld] \n",  rc );
            if (rc==1) continue;              
        }
        
        
  
        printf("INTO MAIN CUR\n");
        printf("fcard_class[%s]\n",fcard_class);
        printf("ipolicy[%s]\n",ipolicy);
        
        /***************************/
        /*                         */
        /*  ���s����̷s�O����   */
        /*                         */
        /***************************/  
        /* 1110307005_SC1_�վ�G�T���q���n�Q�O�I�H�a�}����*/ 
        /* �W�[�n�Q�O�H������� (1111011002_SC1) */       
        strcpy(sSDB,get_car_full_db(ipolicy));
        strcpy(sFull,get_full_dbname(sSDB));
        printf("sFull[%s]\n",sFull);
        
        sprintf_s(stmt, sizeof stmt,
                " SELECT NVL(a.inext_ply,' '),b.iassured,b.nassured,b.aassured_zip,b.aassured,b.dbirth, "
                "        b.fsex,b.fmarriage,b.fassured,b.iemail,b.itel,b.itel_night,b.mobil_phone,  "
                "        b.iassured_cntry,b.foccup,b.noccup,b.ndeputy_assured,  "
                "        b.nuser,b.nbenef,b.itag,a.tmobile_eply,a.aemail_eply,  "
                "        b.iapplicant,b.napplicant,b.apayment_zip,b.apayment,   "
                "        b.dbirth_appl,b.fsex_appl,b.fapplicant,b.aemail_appl,b.itel_appl, "
                "        b.tmobile_appl,b.iapplicant_cntry,b.applicant_foccup,b.applicant_noccup,  "
                "        b.ndeputy_appl,b.nrelation_appl "
                "   FROM %s:ply_relation a,%s:policy b  "
                "  WHERE a.ipolicy = b.ipolicy  "
                "    AND a.ipolicy = '%s' " ,sFull,sFull,ipolicy);
        printf("653:stmt[%s]\n",stmt);
        $PREPARE pre_ply FROM $stmt;
        $EXECUTE pre_ply 
            INTO $inext_ply,$ilicense,$nassured,$aassured_zip,$aassured,$dbirth,
                 $fsex,$fmarriage,$fassured,$iemail,$bitel,$itel_night,$mobil_phone,
                 $iassured_cntry,$foccup,$noccup,$ndeputy_assured,
                 $nuser,$nbenef,$itag,$tmobile_eply,$aemail_eply,
                 $iapplicant,$napplicant,$apayment_zip,$apayment,
                 $dbirth_appl,$fsex_appl,$fapplicant,$aemail_appl,$itel_appl,
                 $tmobile_appl,$iapplicant_cntry,$applicant_foccup,$applicant_noccup,
                 $ndeputy_appl,$nrelation_appl;            

        /* �Q�O�I�Hemail */          
        printf("Trace -- iemail1 = [%s] \n",  iemail);
        printf("Trace -- itag = [%s] \n",  itag);
        strcpy(iemail,trim(iemail));
        
        
        /************************************/
        /*                                  */
        /*  �P�_email����޸��̡A�M��email  */
        /*                                  */
        /************************************/   
        /* �M��iemail������޸� */
        icount = 0;
        for (n=0;n<strlen(iemail); n++)
        {
            if (iemail[n] == 39) 
            {
               icount = 1;
               break;
            }
        }
        if (icount > 0)
            strcpy(iemail," ");


        /*******************************/
        /*                             */
        /*  �P�_�]�bcar140-CZ��Email   */
        /*  �M��email                  */
        /*                             */
        /*******************************/     
        /* �s�WŪ��cu_code_data���S�wemail���ư��W��,�bmail�ư��W�椺�����Lemail
              add by sylvia 103.10.07 (1030930001_C2) */
        $DECLARE  chkmailb CURSOR for
          select  ncode 
            from  cu_code_data
           where  itype = 'CZ';
        $OPEN  chkmailb;
        while(1)
        {
            $FETCH chkmailb INTO $tmpEmail;
            if(SQLCODE == SQLNOTFOUND)break;
         	     
            strcpy(iemail,trim(iemail));
            strcpy(tmpEmail,trim(tmpEmail));
         	
            printf("b:iemail=[%s]tmpEmail=[%s]\n",iemail,tmpEmail);
            if(strcasecmp(iemail,tmpEmail)==0)
            {
         	strcpy(iemail," ");
         	break;
            }
        }
        $close chkmailb;
        $free chkmailb;



        /**********************************************************************/
        /*                                                                    */
        /*  Email�L�ĩΪťժ�: ���H�G�T���q��Email                            */
        /*  ��Email��: �DJA�BJC�BJD�BKA�BPA�BPE�BPF�q���A���H�G�T���q��Email  */
        /*                                                                    */
        /**********************************************************************/        
        printf("b:iemail=[%s]tmpEmail=[%s]\n",iemail,tmpEmail);
        if ((strchr(iemail,'@')==NULL)||(strchr(iemail,'.')==NULL)||(strlen(iemail)<5))
        {
            strcpy(iemail," "); 
          	   
            /* 100.07.13  email �q���A�S��email�άOemail�����T�ۤ�(�L�k)�H�o */	
	    if (flgExec[0]=='2'){		      	  		      	  
	        no_email_count ++;
		printf("531==>Trace -- no_email_count = [%d] \n",  no_email_count);
		$DELETE FROM comp_temp WHERE ipolicy= $ipolicy ;     
		continue;		      	
            }          	   
        }
        else
        {
            if (flgExec[0]=='2')
            {
                  /* 101.06.26 , ���w�H�U�q�� 
                     JA�G��t�~��    JC�G���}�ۼ�    JD�G�ө�(�q)��   KA�G���u�ۦ���� 
                     PA�G����q    PE�G���~¾��    PF�G�f�B�� 
                  */             	  	  
                  /* B2C�B�M�ץ󰣥~(�j��G�T�����|���M�ץ�)*/
                  /*if (strncmp(iroute,"JB",2)==0) {*/
                  if( (strncmp(iroute,"JA",2)!=0)&&(strncmp(iroute,"JC",2)!=0)&&(strncmp(iroute,"JD",2)!=0)&&
                    (strncmp(iroute,"KA",2)!=0)&&(strncmp(iroute,"PA",2)!=0)&&(strncmp(iroute,"PE",2)!=0)&&
                    (strncmp(iroute,"PF",2)!=0) ) 
                  {
                     no_email_count ++;
                     printf("T551==>race -- no_email_count = [%d] \n",  no_email_count);
                     $DELETE FROM comp_temp WHERE ipolicy= $ipolicy ;     
                     continue;		          	  	  	
                  }
          	  	  
            }
            else
            {	
          	    strcpy(iemail, replace_str(iemail, 1, strlen(iemail)));
            }    
        }          

        printf("Trace -- iemail2 = [%s] \n",  iemail);     
        
        /******************************************************/
        /*                                                    */
        /*  �w��O: ���H�G�T���q��Email�B�����s�G�T���q����   */
        /*                                                    */
        /******************************************************/          
        if (strlen(trim(inext_ply)) > 0) {
	    sprintf_s(sTmp, sizeof sTmp," �E�O�渹�G[%s] �w��O\n",ipolicy);
	    rgu_put_body_string(1,sTmp,1);
	    rgu_put_body(1); max_count++;
	    inext_count++;
	    $DELETE FROM comp_temp WHERE ipolicy= $ipolicy ;             					   
	    continue;
        }


        /******************************************************/
        /*                                                    */
        /*  ���O30: ���H�G�T���q��Email�B�����s�G�T���q����   */
        /*                                                    */
        /******************************************************/ 
        /*1110615006_SC1_���O30�l�h�A�ɭP�L���s�q����M�G�D�T���q����*/
        /* ���O30�l�h�Ȥ��ˮ� */
        /*sprintf_s(stmt, sizeof stmt,
            " SELECT nequipment                    "
              " FROM %s:policy                      "
              "WHERE ipolicy = '%s'                 "
              "  AND nequipment[30] not in %s ",sFull,ipolicy, sequip_str30 );
        printf("700:stmt[%s]\n",stmt);
        $PREPARE get_n1 FROM $stmt;
        $EXECUTE get_n1 INTO $nequipment;
        if(SQLCODE == SQLNOTFOUND){ 
             $DELETE FROM comp_temp WHERE ipolicy= $ipolicy ;	
             continue; 
        }*/


        /************************/
        /*                      */
        /*  �a�}�ഫ(�w���ഫ)  */
        /*                      */
        /************************/              
        strcpy(sNewAddr," ");
        strcpy(aassured_zip,rtrim(aassured_zip));
        strcpy(aassured,rtrim(aassured));
          
        if (chkAddrTrans >=0){
	    rc = cm_2new_city( trim(aassured_zip), aassured, sNewAddr);
	    printf("Trace --cm_2new_city rc = [%ld] \n",  rc);
	    if( rc == M_CM_CITY_FAIL)
	    {
	        sprintf_s(sTmp, sizeof sTmp," �E�O�渹�G[%s]���a�}[%s %s]�ഫ����\n",ipolicy,aassured_zip,aassured);
		rgu_put_body_string(1,sTmp,1);
		rgu_put_body(1); max_count++;
		iaddr_err_count++;				   
		printf("Trace -- sTmp = [%s] \n",  sTmp);
            }else{
		strcpy(sNewAddr,rtrim(sNewAddr));
		printf("Trace -- sNewAddr = [%s] \n",  sNewAddr);
            }		       
        }

        /******************/
        /*                */
        /*  �Q�O�H�[�ٿ�  */
        /*                */
        /******************/ 
        strcpy(nassured, rtrim(nassured));
        strcpy(s_nassured, rtrim(nassured));
        /* 1130308006_C01 �����Q�O�I�H�ٿ� */
        /*if ((strncmp(fassured,"1",1)==0)||(strncmp(fassured,"3",1)==0)||(strncmp(fassured,"5",1)==0)){
            if (fsex[0] == '1')	
                strcat(nassured,"�@����");
            else if (fsex[0] == '2')
                strcat(nassured,"�@�p�j");
        }  	      	   */
        printf("nassured[%s]\n",nassured);
        
        strcpy(bitel,trim(bitel));           /* �Q�O�I�H�q�� => �p���q�� */
        strcpy(dbirth,trim(dbirth));         /* �Q�O�I�H�X�ͦ~��� */
        strcpy(iengine,rtrim(iengine));      /* �������X */ 
        strcpy(tphone_con,trim(tphone_con)); /* �Q�O�I�H�q��(�]) */
        
        /*          
        * �N�۵M�H�������Ҧr���Ĥ��X�̫ܳ�@�X�H[*]���N *
        if (((strncmp(fsex,"1",1)==0) || (strncmp(fsex,"2",1)==0)) && (strlen(ilicense)>4)){
              strcpy(ilicense, replace_str(ilicense, 5, strlen(ilicense)));
        }    
        printf("ilicense[%s]\n",ilicense);
        */
        
        /*
        * �Q�O�I�H�q�� => �p���q�� *
        strcpy(bitel,trim(bitel));
        if (strlen(bitel)>0){
            if (flgExec[0]=='1'){ 
                strcpy(bitel, replace_str(bitel, 1, strlen(bitel)));
            }
        }        
        
        * �Q�O�I�H�X�ͦ~��� *
        strcpy(dbirth,trim(dbirth));
        if (strlen(dbirth)>0){
            if (flgExec[0]=='1'){
                strcpy(dbirth, replace_str(dbirth, 1, strlen(dbirth)));          	  	  
            }else{ 	* email �q��*
              	
            }	
        }

        
        * �Q�O�I�H�ʧO *
        strcpy(fsex,trim(fsex));
        if (strlen(fsex)>0)
              strcpy(fsex, replace_str(fsex, 1, strlen(fsex)));

        * �Q�O�I�H�B�ê��p *
          strcpy(fmarriage,trim(fmarriage));
          if (strlen(fmarriage)>0)
              strcpy(fmarriage, replace_str(fmarriage, 1, strlen(fmarriage)));
        */
        
        /******************/
        /*                */
        /*  �������X�B�n  */
        /*                */
        /******************/
        /* �������X */
        strcpy(iengine,rtrim(iengine));    
        strcpy(itag_x,"");  
        strcpy(iengine_x,"");                                                  
        if (flgExec[0]=='1')
        {
	    /* 980213,�k�H�L���P�����ä����� */
	    if (((strncmp(fassured,"2",1)==0)||(strncmp(fassured,"4",1)==0)||(strncmp(fassured,"6",1)==0))&&(strlen(trim(itag))==0))
	    {
	          
	    }
	    else
	    {
	        if (strlen(iengine)>0)
	        {              	 
	            strcpy(iengine, replace_str(iengine, 1, strlen(iengine)));          	                  
                }
            }
        }
        else if (flgExec[0]=='2')
        {
	    strcpy(iengine_x, iengine); iengine_x[0] = '*'; iengine_x[1] = '*'; /* email���O�᪺�������n���� */        	
        }
        
	if (flgExec[0]=='2'){	
            if (strlen(trim(itag))>0){
	        strcpy(itag_x, itag); itag_x[0] = '*'; itag_x[1] = '*';   /* email���O�᪺�����n���� */
            }
        } 


        /* �Q�O�I�H�q��(�]) */
        strcpy(tphone_con,trim(tphone_con));
        /*
        * �Q�O�I�H��ʹq�� *
        strcpy(imovephone,trim(imovephone));
        */
        cm_split_ymd_100(cm_from_infdate_100(dply_begin),sYY,sMM,sDD);


        /*************************/
        /*                       */
        /*  �B�z�G�T���q��Email  */
        /*                       */
        /*************************/
        /* 100.07.13*/
	if (flgExec[0]=='2')
	{       
	        /* email �q��*/		  	  
	        /* �A�ȤH��(�޲z�H) */
		/*if( ileader_tmp[0] == '6')  �����޲z�H 
	        {*/
	        	$EXECUTE prep1 INTO $bnname,$ileader_tmp USING $ileader_tmp;
	        /*}*/
	        
	        mail_count = 1;
	        strcpy(cc ,' ');
	        
	        /********* email ���O�� *******/
	        strcpy(receiver_email, iemail);     /*�O��email*/
	        strcpy(receiver_name , nassured);   /*�O��W�� */
	        
	        /* mail���e�W�[�޲z�H������EMAIL add by 061476 110.04.26 (1100310012_SC1) */
	        $select ext_tel into $ileader_ext 
	           from cm_emp_ext
	          where empl_no = $ileader_tmp;
	        if (SQLCODE == SQLNOTFOUND) strcpy(ileader_ext, " ");
	        
	        $select trim(email)||'@tmnewa.com.tw' into $ileader_email 
	           from sysdb:v_asempl
	          where empl_no = $ileader_tmp;
	        if (SQLCODE == SQLNOTFOUND) strcpy(ileader_email, " ");

	        /* ��106/12/22 �������z�n�D,�������q���}�s��, �ݨD���� modify by sylvia 106.12.22  */
	        /*112/10/23 1121002008_C01_CAR326 �j��G�T���q���Ȥ����h�����ק� */
	        sprintf_s(content, sizeof content ,
	        "<html>\n"
		"<head>\n"
		"    <meta http-equiv=\"content-type\" content=\"text/html; charset=Big5\">\n"
		"</head>\n"
		"<body>\n"
		"    <table style=\"text-align: left; width: 700px; background-color: white; height: 545px;\" border=\"0\" cellpadding=\"1\" cellspacing=\"20\">\n"
		"        <tr>\n"
		"            <td style=\"vertical-align: top; text-align: center\">\n"
		"                <a href=\"\"><img width=\"500\" height=\"80\" alt=\"\" src=\"https://www.tmnewa.com.tw/img/logo.677af7dd.png\"></a><br>\n"
		"            </td>\n"
		"        </tr>\n"
		"        <tr>\n"
		"            <td style=\"vertical-align: top;text-align:center;\">\n"
		"                <div style=\" font-size: 10pt; color: red; background-color: gainsboro; text-align: center;\">�����z�A�ФŪ����^�Ц��ʫH��A���ʫH�󬰨t�Φ۰ʵo�e�H��C</div>\n"
		"            </td>\n"
		"        </tr>\n"
		"        <tr>\n"
		"            <td style=\"vertical-align: top; font-size: 14pt; line-height: 2;\">\n"
		"                �˷R���U�� �z�n�G<br>\n"
		"                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n"
		"                �P�±z�糧���q������P�R�@�A�z�V�����q��O���T�����O�I����<b>�|��������O����</b>�A���קK�z�]������z�ӾD�����@�A�����q�A�������z�A�о��t��<b>�A�ȤH��</b>�μ��������q<b>�K�O�ȪA�M�u</b>���ߡA�H�K��z�O�I��O�Ʃy�C\n"
		"                <br>\n"
		"                �p�z�w�g������O�A�h�Щ�����MAIL�C\n"
		"                <br>\n"
		"\n"
		"                <span style=\"font-size: 16pt; font-weight: bold; color: royalblue; background-color: powderblue; \">�O���T</span>\n"
		"                <br>\n"
		"                <span style=\"letter-spacing: 14px; \">���P���X</span>�G <font color=\"royalblue\"><b> %s (�������X %s )</b></font>\n"
		"                <br>\n"
		"                <span style=\"letter-spacing: 7.5px; \">�O������</span>�G<font color=\"royalblue\"><b> %s �~  %s  ��  %s  �� </b></font>\n"
		"                <br>\n"
		"                <span>�j���I�O�渹�X</span>�G<font color=\"royalblue\"><b> %s </b></font>\n"
		"                <br>\n"
		"\n"
		"                <span style=\"font-size: 16pt; font-weight: bold; color: royalblue; background-color: powderblue; \">�A�ȤH����T</span>\n"
		"                <br>\n"
		"                <span style=\"letter-spacing: 9.5px;\">�A�ȤH��</span>�G<font color=\"royalblue\"><b> %s </b></font>\n"
		"                <br>\n"
		"                <span style=\"letter-spacing: 37.5px;\">�q��</span>�G<font color=\"royalblue\"><b> %s </b></font> �����G<font color=\"royalblue\"><b> %s </b></font>\n"
		"                <br>\n"
		"                <span style=\"letter-spacing: 11.4px;\">EMAIL</span>�G<font color=\"royalblue\"><b> %s </b></font>\n"
		"                <br>\n"
		"                <span>�K�O�ȪA�M�u</span>�G<font color=\"royalblue\"><b> 0800 - 050 - 119 </b></font>\n"
		"                <br><br>\n"
		"                �A�@���`�`�a�P�±z�A�ï��ֱz�αz���a�H\n"
		"                <br>\n"
		"                ���d �ּ�\n"
		"                <br><br>\n"
		"                    <div style=\" width: 700px; font-size: 16pt; font-weight: bold;\"align=\"right\">\n"
		"                        �s�w�F�ʮ��W�����O�I &nbsp; �q��\n"
		"                    </div>\n"
		"                    <br>\n"
		"                    <div style=\"width: 700px; background-color: lightskyblue; text-align: center; font-size: 11pt; line-height: 1.5; \">\n"
		"                        �K�O�ȪA�M�u�G0800 - 050 - 119 &nbsp;�q�ܡG(02)8772 - 7777 &nbsp;�`���q�G104 �x�_���n�ʪF���T�q 130 �� 8-13��\n"
		"                    </div>\n"
		"            </td>\n"
		"        </tr>\n"
		"    </table>\n"
		"</body>\n"
		"</html>\n",itag_x,iengine_x,sYY,sMM,sDD,ipolicy,bnname,itel,ileader_ext,ileader_email);
	                
	                strcpy(key ," ");		  	
	                strcpy(subject ,"�T�����j��d���O�I�w�L���q��");	
	                
	                $insert into temp1 values(			    			  
	                $project_id, $lSendDate, $receiver_email, $receiver_name, $cc,		      
	                $content, $key, $mail_count, $subject, $key );		      
	                tot_count_c++;   
	                
	                /********* email ���޲z�H *******/
	                strcpy(pre_ileader_tmp,rtrim(pre_ileader_tmp));
	                strcpy(ileader_tmp,rtrim(ileader_tmp));
	                
	                /* �@�Ӻ޲z�H�u�n�@��email�A"�����ɮ�"�t����Ҧ��O����(��email��) */
	                if((strcmp(pre_ileader_tmp,ileader_tmp)!=0))
	                {
LAST_ILeader:			      	
	                	if (strlen(trim(pre_ileader_tmp))>0){ 
	                		/* ���U�@�Ӻ޲z�H���e�A�������e�@�Ӻ޲z�H�nemail�����*/
	                		/* LAST_ILeader: �Y���̫�@����ơA�������ܦ������Ӻ޲z�H�nemail����� */
	                		printf("Trace -- pre_ileader_tmp = [%s] \n",  pre_ileader_tmp);
	                		printf("Trace -- ileader_tmp = [%s] \n",  ileader_tmp);
	                		printf("Trace -- ���U�@�Ӻ޲z�H  \n");
	                		
	                		$SELECT trim(email)||'@tmnewa.com.tw' into $receiver_email FROM sysdb:v_asempl
	                		  WHERE empl_no = $pre_ileader_tmp;       /*�޲z�Hemail*/
	                		
	                		if (SQLCODE == SQLNOTFOUND){
	                			printf("Trace -- v_asempl SQLNOTFOUND  \n");
	                			printf("Trace -- ileader_tmp = [%s] \n",  ileader_tmp);
	                			if (fLast)
	                			    break;
	                			else	  
	                			    continue; 
	                		}else{			  	  
	                			strcpy(pre_nleader , rtrim(pre_nleader));  
	                			strcpy(key , rtrim(pre_sFilename));               /*���[�ɮצW��*/
	                			strcpy(content ,
	                			       "<html><body> \n"
	                			       "�z�n\n"
	                			       "<p>���󬰩��ݨ��I�Ȥ�]�����I�t�Φ��n���Ȥ�E-MAIL�H�c�^����������s<br>\n"
	                			       "��O�����ӡA�ӰT���äwMAIL�q���O��A�Ш�U�i��Ȥ����h�@�~�A�q��<br>\n"
	                			       "�Ȥᾨ�t�������s��O�C�Y�Ȥ�w��z��O�Ψ����w�����A�h�L�ݲz�|�C<br>\n"
	                			       "�Y���������D�A�Ь��ӤH�O�I���~�Ȧ�F��C<br>\n"
	                			       "<p> ����</p>\n"
	                			       "</body></html>\n"
	                			);
	                			strcpy(subject ,"�Ȥ����h�@�~-�T�����j��O�I���s��O�q��");				  	  	              
	                			$insert into temp1 values(			    			  
	                			$project_id, $lSendDate, $receiver_email, $pre_nleader, $cc,
	                			$content, $key, $mail_count, $subject, $key );			      
	                			tot_count_m++;   
	                		}  
	                		
	                		fclose(fp0);
	                	}
	                	if (fLast) break;
	                	
	                	sprintf_s(Tmp1, sizeof Tmp1,"�j��G�T��_%s_%s.csv",exedate,ileader_tmp);		         
	                	sprintf_s(file0, sizeof file0,"%s/rptftp/car_email/%s",sApHome,Tmp1);
	                	sprintf_s(sFilename, sizeof sFilename,Tmp1);
	                	printf("Tmp1[%s] file0[%s]\n",Tmp1,file0);		          
	                	fp0=fopen(file0,"w"); 		          
	                	
	                	strcpy(prtstr,"�j��O�渹");
	                	strcat(prtstr,attach_deli);		 
				strcat(prtstr,"���N�O�渹");
				strcat(prtstr,attach_deli);		 
				strcat(prtstr,"���P");
				strcat(prtstr,attach_deli);		 
				strcat(prtstr,"�O�I�����");
				strcat(prtstr,attach_deli);		 
				strcat(prtstr,"�Q�O�I�H�m�W");
				strcat(prtstr,attach_deli);		 
				strcat(prtstr,"�X�ͦ~���");
				strcat(prtstr,attach_deli);		 
				strcat(prtstr,"E-MAIL");
				strcat(prtstr,attach_deli);		 
				strcat(prtstr,"�q�ܡ]��^");
				strcat(prtstr,attach_deli);		 
				strcat(prtstr,"�q�ܡ]�]�^");
				strcat(prtstr,attach_deli);		 
				strcat(prtstr,"�g��N��");
				strcat(prtstr,attach_deli);		 
				strcat(prtstr,"�g��W��");         
				
				fprintf(fp0,"%s\n",prtstr);
				printf("prtstr[%s]\n",prtstr);    		          
		        }
		        
		        /* �Ӹ�B�n (nassured,dbirth,bitel,tphone_con) add by larry 103.02.19 (1030211003_C1) */
		        if ((strncmp(fassured,"1",1)==0)||(strncmp(fassured,"3",1)==0)||(strncmp(fassured,"5",1)==0))
		        {	
		        	strcpy(sNassured,substring(nassured,1,2));
		          	strcat(sNassured,"�ݢ�");
		          	strcpy(sDbirth,substring(dbirth,1,3));
		          	strcat(sDbirth,"**");
		          	strcat(sDbirth,substring(dbirth,6,5));
		          	strcpy(sIemail,substring(iemail,1,3));
		          	strcat(sIemail,"@@@@");
		          	strcat(sIemail,substring(iemail,8,43));
		          	strcpy(sBitel,substring(bitel,1,3));
		          	strcat(sBitel,"XXXX");
		          	strcat(sBitel,substring(bitel,8,13));
		          	strcpy(sTphone_con,substring(tphone_con,1,3));
		          	strcat(sTphone_con,"XXXX");
		          	strcat(sTphone_con,substring(tphone_con,8,13));	                 		               
		        }
		        else
		        {
		          	strcpy(sNassured,nassured);
		          	strcpy(sDbirth,dbirth);
		          	strcpy(sIemail,iemail);
		          	strcpy(sBitel,bitel);
		          	strcpy(sTphone_con,tphone_con);
		        }
		        
		        strcpy(prtstr,ipolicy);            /* �j��O�渹 */
		        strcat(prtstr,attach_deli);
		        if (strlen(rtrim(irelative_ply))>0){
		        	strcat(prtstr,rtrim(irelative_ply));     
		        }else{
		          	strcat(prtstr," ");          /* ���N�O�渹 */
		        }	             
		        strcat(prtstr,attach_deli);	          
		        strcat(prtstr,trim(itag));         /* ���P       */
		        strcat(prtstr,attach_deli);
		        strcat(prtstr,rtrim(sYY));         /* �O�I����� */
		        strcat(prtstr,"/");
		        strcat(prtstr,rtrim(sMM));
		        strcat(prtstr,"/");
		        strcat(prtstr,rtrim(sDD));
		        strcat(prtstr,attach_deli);
		        strcat(prtstr,sNassured);          /* �Q�O�I�H�m�W*/ 
		        strcat(prtstr,attach_deli);	
		        strcat(prtstr,trim(sDbirth));      /* �X�ͦ~���  */
		        strcat(prtstr,attach_deli);	
		        strcat(prtstr,sIemail);            /* E-MAIL      */
		        strcat(prtstr,attach_deli);
		        strcat(prtstr,trim(sBitel));       /* �q�ܡ]��^  */
		        strcat(prtstr,attach_deli);                
		        strcat(prtstr,trim(sTphone_con));  /* �q�ܡ]�]�^  */
		        strcat(prtstr,attach_deli);     
		        strcat(prtstr,xiofficer);          /* �g��N��    */    
		        strcat(prtstr,attach_deli);		 
		        strcat(prtstr,nofficer);           /* �g��W��    */  	
		        
		        printf("Trace -- prtstr = [%s] \n",  prtstr); 
		        fprintf(fp0,"%s\n",prtstr);
		        
		        strcpy(pre_ileader_tmp,ileader_tmp);	
		        strcpy(pre_sFilename,sFilename);	 
		        strcpy(pre_nleader,bnname);	       	          
		        $DELETE FROM comp_temp WHERE ipolicy= $ipolicy ;     
		        continue;
	}


        /**************************/
        /*                        */
        /*  �B�z�G�T���q�����ɮ�  */
        /*                        */
        /**************************/
        strcpy(prtstr,ipolicy);
        strcat(prtstr,"\t");

        strcat(prtstr,trim(itag));
        strcat(prtstr,"\t");                 
        strcat(prtstr,nassured);
        strcat(prtstr,"\t");
        strcat(prtstr,trim(aassured_zip));
        strcat(prtstr,"\t");
        strcat(prtstr,rtrim(aassured));
        strcat(prtstr,"\t");
        strcat(prtstr,napplicant);
        strcat(prtstr,"\t");
        strcat(prtstr,trim(apayment_zip));
        strcat(prtstr,"\t");
        strcat(prtstr,rtrim(apayment));
        strcat(prtstr,"\t");

        strcat(prtstr,trim(itel));
        strcat(prtstr,"\t");
        strcat(prtstr,trim(ibig_branch));
        strcat(prtstr,"\t");

        /*if( ileader_tmp[0] != '6')
        {
            /* dummy 
        }
        else /* �����޲z�H 
        {*/
            $EXECUTE prep1 INTO $bnname USING $ileader_tmp;
        /*}*/

        strcat(prtstr,rtrim(bnname));
        strcat(prtstr,"\t");
        
        strcat(prtstr,trim(sYY));
        strcat(prtstr,"\t");
        strcat(prtstr,trim(sMM));
        strcat(prtstr,"\t");
        strcat(prtstr,trim(sDD));
        strcat(prtstr,"\t");
        strcat(prtstr,trim(bitel));
        strcat(prtstr,"\t");

        strcat(prtstr,rtrim(ncar_type));
        strcat(prtstr,"\t");

        strcat(prtstr,trim(iissue_ym));
        strcat(prtstr,"\t");
        strcat(prtstr,trim(nbrand_abbr));
        strcat(prtstr,"\t");
        rfmtdouble(qcylinder,"####&.##",sTmp);  /* �Ʈ�q�X�ܤp���I2�� (1080902001_SC3) */
        strcat(prtstr,trim(sTmp));

        strcat(prtstr,"\t");
        strcat(prtstr,rtrim(iengine));

        rfmtdouble(qpt,"--&.&",sTmp);
        if (fpt[0] == 'P')
            strcat(sTmp," �H");
        else
            strcat(sTmp," ��");

        strcat(prtstr,"\t");
        strcat(prtstr,sTmp);         
        strcat(prtstr,"\t");

                  
        strcat(prtstr,sNewAddr);   /* 991224,�s�a�}*/    
        strcat(prtstr,"\t");
        
        
        strcpy(IsMoto2, "N");   /* �O�_�������G���q���]Y:�O N:���O(�w�])) */
        printf("���� 1108 ipolicy=[%s]icar_type=[%s]fcomp_24=[%s]iroute=[%s]iofficer=[%s] ���������� \n",ipolicy,icar_type,fcomp_24,iroute,xiofficer);
        
        
        /******************************/
        /*                            */
        /*  �����G���q����|��ú�ڳ�  */
        /*                            */
        /******************************/
        if( strncmp(icar_type,"01",2)==0 || strncmp(icar_type,"02",2)==0 || 
            strncmp(icar_type,"32",2)==0 || strncmp(icar_type,"34",2)==0 || strncmp(icar_type,"35",2)==0)
        {
            printf("���� 1112 ipolicy=[%s]icar_type=[%s]fcomp_24=[%s]iroute=[%s]iofficer=[%s] ���������� \n",ipolicy,icar_type,fcomp_24,iroute,xiofficer);
            mot_count++;
            if ((ldply_begin>=ld6DaysBgn)&&(ldply_begin<=ld6DaysEnd))
            {
                printf("���� 1116 ipolicy=[%s]icar_type=[%s]fcomp_24=[%s]iroute=[%s]iofficer=[%s] ���������� \n",ipolicy,icar_type,fcomp_24,iroute,xiofficer);
                strcpy(IsMoto2, "Y");
                strcpy(xiofficer,trim(xiofficer));
                
                /* �j���I���J�p, ��ú�ڳ��� modify  by sylvia 105.09.10 (1050831007_C1) */
                /* �ȪA���ߤ��N��(�g��N��Z03445)����ú�ڳ��T modify by 061476 107.10.04(1070903005_SC1) */
                if ((strcmp(fcomp_24,"N") == 0) && (strcmp(xiofficer,"Z03445") != 0))    
                {
                    if (strncmp(iroute,"JB",2) == 0)
                    	rc = upd302_JB(ipolicy,icar_type,iroute);  /* JB�q���H��g����� */
                    else
                        rc = upd302(ipolicy,icar_type);            /* �DJB�q���HKA�g����� */
                        
                    if (rc != SUCCESS)
                    {
                        return FAIL;
                    }
                    else
                    {                        
                        $EXECUTE pre_transno INTO $itransno_ori_MKT using $itransno_ori;
                        ao_crd_bcode(itransno_ori_MKT, sTmpChDate_pay, &mprem1, ori_Bcode1, ori_Bcode2, ori_Bcode3);
                        
                        strcpy(itransno_sug_MKT,"");
                        strcpy(sug_Bcode1,"");
                        strcpy(sug_Bcode2,"");
                        strcpy(sug_Bcode3,"");
                        
                        if (strlen(trim(itransno_sug))>0)
                        {
                            $EXECUTE pre_transno INTO $itransno_sug_MKT using $itransno_sug;
                            ao_crd_bcode(itransno_sug_MKT, sTmpChDate_pay, &mprem2, sug_Bcode1, sug_Bcode2, sug_Bcode3);                        	
                        }

                    }
                    mot_count_2++;
                    
                    /* �t�X�����_�O��H�eú�ڳ�s�W add by sylvia 105.06.24  */

                    strcat(prtstr,ori_Bcode1);      /* ���X�@    (���O�P��ĳ��O�@��) */    
                    strcat(prtstr,"\t");
                    strcat(prtstr,ori_Bcode2);      /* ���X�G    (���O: �@�~��) */    
                    strcat(prtstr,"\t");
                    strcat(prtstr,ori_Bcode3);      /* ���X�T    (���O: �@�~��) */    
                    strcat(prtstr,"\t");
                    strcat(prtstr,sTmpChDate_pay);  /* ú�ڴ���  (���O: �@�~��) */    
                    strcat(prtstr,"\t");
                    strcat(prtstr,cmprem1);         /* ú�ڪ��B  (���O: �@�~��) */    
                    strcat(prtstr,"\t");
                    strcat(prtstr,iestimate_ori);   /* �����渹  (���O: �@�~��) */    
                    strcat(prtstr,"\t");
                    /*35���ؤ����G�~�����X*/
                    if (strcmp(icar_type,"35") == 0)
                    {
                    	strcat(prtstr," ");         /* ���X�G    (��ĳ��O: �G�~��) */    
                        strcat(prtstr,"\t");
                        strcat(prtstr," ");         /* ���X�T    (��ĳ��O: �G�~��) */    
                        strcat(prtstr,"\t");
                        strcat(prtstr," ");         /* ú�ڴ���  (��ĳ��O: �G�~��) */    
                        strcat(prtstr,"\t"); 
                        strcat(prtstr," ");         /* ú�ڪ��B  (��ĳ��O: �G�~��) */    
                        strcat(prtstr,"\t");
                        strcat(prtstr," ");         /* �����渹  (��ĳ��O: �G�~��) */                   	
                    }
                    else
                    {
                    	strcat(prtstr,sug_Bcode2);      /* ���X�G    (��ĳ��O: �G�~��) */    
                        strcat(prtstr,"\t");
                        strcat(prtstr,sug_Bcode3);      /* ���X�T    (��ĳ��O: �G�~��) */    
                        strcat(prtstr,"\t");
                        strcat(prtstr,sTmpChDate_pay);  /* ú�ڴ���  (��ĳ��O: �G�~��) */    
                        strcat(prtstr,"\t");   	
                        strcat(prtstr,cmprem2);         /* ú�ڪ��B  (��ĳ��O: �G�~��) */    
                        strcat(prtstr,"\t");
                        strcat(prtstr,iestimate_sug);   /* �����渹  (��ĳ��O: �G�~��) */
                    }

   
                }
                else
                {
                    printf("���������� 1166 ���������� \n");
                    /* �j���I���J�p, ��ú�ڳ��� modify  by sylvia 105.09.10 (1050831007_C1) */
                    mot_count_2++;
                    /* �t�X�����_�O��H�eú�ڳ�s�W add by sylvia 105.06.24  */
                    strcat(prtstr," ");             /* ���X�@    (���O�P��ĳ��O�@��) */    
                    strcat(prtstr,"\t");
                    strcat(prtstr," ");             /* ���X�G    (���O: �@�~��) */    
                    strcat(prtstr,"\t");
                    strcat(prtstr," ");             /* ���X�T    (���O: �@�~��) */    
                    strcat(prtstr,"\t");
                    strcat(prtstr," ");             /* ú�ڴ���  (���O: �@�~��) */    
                    strcat(prtstr,"\t");
                    strcat(prtstr," ");             /* ú�ڪ��B  (���O: �@�~��) */    
                    strcat(prtstr,"\t");
                    strcat(prtstr," ");             /* �����渹  (���O: �@�~��) */    
                    strcat(prtstr,"\t");
                    strcat(prtstr," ");             /* ���X�G    (��ĳ��O: �G�~��) */    
                    strcat(prtstr,"\t");
                    strcat(prtstr," ");             /* ���X�T    (��ĳ��O: �G�~��) */    
                    strcat(prtstr,"\t");
                    strcat(prtstr," ");             /* ú�ڴ���  (��ĳ��O: �G�~��) */    
                    strcat(prtstr,"\t");
                    strcat(prtstr," ");             /* ú�ڪ��B  (��ĳ��O: �G�~��) */    
                    strcat(prtstr,"\t");
                    strcat(prtstr," ");             /* �����渹  (��ĳ��O: �G�~��) */    
                }
            }
            else if ((ldply_begin>=ld20DaysBgn)&&(ldply_begin<=ld20DaysEnd))
            {
                mot_count_3++;
                /* �t�X�����_�O��H�eú�ڳ�s�W add by sylvia 105.06.24  */
                strcat(prtstr," ");                 /* ���X�@    (���O�P��ĳ��O�@��) */    
                strcat(prtstr,"\t");
                strcat(prtstr," ");                 /* ���X�G    (���O: �@�~��) */    
                strcat(prtstr,"\t");
                strcat(prtstr," ");                 /* ���X�T    (���O: �@�~��) */    
                strcat(prtstr,"\t");
                strcat(prtstr," ");                 /* ú�ڴ���  (���O: �@�~��) */    
                strcat(prtstr,"\t");
                strcat(prtstr," ");                 /* ú�ڪ��B  (���O: �@�~��) */    
                strcat(prtstr,"\t");
                strcat(prtstr," ");                 /* �����渹  (���O: �@�~��) */    
                strcat(prtstr,"\t");
                strcat(prtstr," ");                 /* ���X�G    (��ĳ��O: �G�~��) */    
                strcat(prtstr,"\t");
                strcat(prtstr," ");                 /* ���X�T    (��ĳ��O: �G�~��) */    
                strcat(prtstr,"\t");
                strcat(prtstr," ");                 /* ú�ڴ���  (��ĳ��O: �G�~��) */    
                strcat(prtstr,"\t");
                strcat(prtstr," ");                 /* ú�ڪ��B  (��ĳ��O: �G�~��) */    
                strcat(prtstr,"\t");
                strcat(prtstr," ");                 /* �����渹  (��ĳ��O: �G�~��) */    
            }              
        }
        else
        {
            car_count++;
            /* �t�X�����_�O��H�eú�ڳ�s�W add by sylvia 105.06.24  */
            strcat(prtstr," ");      /* ���X�@    (���O�P��ĳ��O�@��) */    
            strcat(prtstr,"\t");
            strcat(prtstr," ");      /* ���X�G    (���O: �@�~��) */    
            strcat(prtstr,"\t");
            strcat(prtstr," ");      /* ���X�T    (���O: �@�~��) */    
            strcat(prtstr,"\t");
            strcat(prtstr," ");      /* ú�ڴ���  (���O: �@�~��) */    
            strcat(prtstr,"\t");
            strcat(prtstr," ");      /* ú�ڪ��B  (���O: �@�~��) */    
            strcat(prtstr,"\t");
            strcat(prtstr," ");      /* �����渹  (���O: �@�~��) */    
            strcat(prtstr,"\t");
            strcat(prtstr," ");      /* ���X�G    (��ĳ��O: �G�~��) */    
            strcat(prtstr,"\t");
            strcat(prtstr," ");      /* ���X�T    (��ĳ��O: �G�~��) */    
            strcat(prtstr,"\t");
            strcat(prtstr," ");      /* ú�ڴ���  (��ĳ��O: �G�~��) */    
            strcat(prtstr,"\t");
            strcat(prtstr," ");      /* ú�ڪ��B  (��ĳ��O: �G�~��) */    
            strcat(prtstr,"\t");
            strcat(prtstr," ");      /* �����渹  (��ĳ��O: �G�~��) */    
            if ((ldply_begin>=ld6DaysBgn)&&(ldply_begin<=ld6DaysEnd)){
                car_count_2++;
            }else if ((ldply_begin>=ld20DaysBgn)&&(ldply_begin<=ld20DaysEnd)){
                car_count_3++;
            }
        }	  
                
        fprintf(fp0,"%s\n",prtstr);
        $DELETE FROM comp_temp WHERE ipolicy= $ipolicy ;
        tot_count++;
    }
    $CLOSE vy_cur;
    $FREE  vy_cur;


    /******************/
    /*                */
    /*  �������浲�G  */
    /*                */
    /******************/
    if (inext_count>0){
        rgu_put_body_string(1,"- - - - - - - - - - - - - - - - - - - - -",1);
	rgu_put_body(1); max_count++;
	rgu_put_body_string(1," ",1);
	rgu_put_body(1); max_count++;	      
	     	     	
	sprintf_s(sTmp, sizeof sTmp,"�� �w��O��ơG%d\n",inext_count);
	rgu_put_body_string(1,sTmp,1);max_count++;
	rgu_put_body(1); max_count++;	
	  
	rgu_put_body_string(1," ",1);
	rgu_put_body(1); max_count++;	      
    }
    $DECLARE  cur_No_ply302 CURSOR for
      SELECT ipolicy 
	FROM comp_temp;
    $OPEN  cur_No_ply302;
    while(1)
    {
        $FETCH cur_No_ply302 INTO $No302_ipolicy;
	if(SQLCODE == SQLNOTFOUND)
	{
	    break;
        }
        else
        {
	    sReason[0] = '\0';
	    printf("-------No302_ipolicy[%s]\n",No302_ipolicy);  
	    GetNo302Reason(No302_ipolicy);

	    /*******************************************************************/         	 
	    printf("sReason[%s]\n",sReason);  
	    sprintf_s(sTmp, sizeof sTmp," �E�O�渹�G[%s] �L��O���( ��]�G%s )\n",No302_ipolicy,sReason);
	    printf("sTmp[%s]\n",sTmp);  
	    rgu_put_body_string(1,sTmp,1);
	    rgu_put_body(1); max_count++;         	 
	    no302_count++;
        }
    }
    $CLOSE cur_No_ply302;
    printf("=== end cur_No_ply302 ===\n");   
	
    if (no302_count>0)
    {     
        rgu_put_body_string(1,"- - - - - - - - - - - - - - - - - - - - -",1);
        rgu_put_body(1); max_count++;
		     	
        printf("No302_ipolicy [%s]\n", No302_ipolicy );
        sprintf_s(sTmp, sizeof sTmp,"�� �L��O��ƥ�ơG%d\n",no302_count);
        rgu_put_body_string(1,sTmp,1);max_count++;
        rgu_put_body(1); max_count++;	      
		
        rgu_put_body_string(1," ",1);
        rgu_put_body(1); max_count++;		   
    }
	 
    /* 100.07.13*/
    printf("Trace -- flgExec = [%s] \n",  flgExec);
    if (flgExec[0]=='2')
    {
    	
        /* �W�[�q���ӫO���H�� (1110127007_SC1_�s�W����{��car326�H�o�j���I�_�O�ĤT���޲z�q��E-MAIL�H�o�q���H) */
     
        $declare cur_notify cursor for
          select DISTINCT detail2 INTO $isend 
            from car_code
           where kind = 'RC' and detail = '0001'
           order by detail2;
        $open  cur_notify;  
     
        while (1)
        {
     	   $fetch cur_notify;
     	
     	   if (SQLCODE==SQLNOTFOUND) break;
     	
     	   $SELECT nname[1,10] INTO $nsend
     	      FROM officer
     	     WHERE iofficer = $isend;
     	     
     	   $SELECT trim(email)||'@tmnewa.com.tw' INTO $email_notify
              FROM asempl
             WHERE empl_no = $isend;


     	   if (strlen(trim(isend))>0)
     	   {
     			
     	       strcpy(subject ,"car326�j��G�T��Email�q���@�~�w�󤵤�H�o");
     	       sprintf_s(content, sizeof content ,"<html><body><p>\n"
         			"�� �H�e�Ȥ�email��ơG%d<br>\n"
         			"�� �H�e�޲z�Hemail��ơG%d<br>\n"
         			"</body></html>\n", tot_count_c, tot_count_m );
               strcpy(key," "); strcpy(cc ," ");  
               
               $insert into temp1 values(
         	$project_id, $lSendDate, $email_notify, $nsend, $cc,
         	$content, $key, 0, $subject, $key);

           }
        } 
        $CLOSE cur_notify;
        $FREE  cur_notify;
    	

    	
        printf("Trace -- insert_to_batchemail()\n");
        rc = insert_to_batchemail("temp1", 0 , v_sMsg);
        printf("Trace -- insert_to_batchemail rc = [%ld] \n",  rc);
        /*		 
	printf("Trace -- no_email_count = [%d] \n",  no_email_count);     			    
	sprintf_s(sTmp, sizeof sTmp,"�� ���~�εL(��)email��ơG%d\n",no_email_count);
	rgu_put_body_string(1,sTmp,1);
	rgu_put_body(1); max_count++;  	 
        */     	 
     	printf("Trace -- tot_count_c = [%ld] \n", tot_count_c);
	sprintf_s(sTmp, sizeof sTmp,"�� �H�e�Ȥ�email��ơG%d\n", tot_count_c);
	rgu_put_body_string(1,sTmp,1);
	rgu_put_body(1); max_count++;  	
		 
     	printf("Trace -- tot_count_m = [%ld] \n", tot_count_m);
	sprintf_s(sTmp, sizeof sTmp,"�� �H�e�޲z�Hemail��ơG%d\n", tot_count_m);
	rgu_put_body_string(1,sTmp,1);
	rgu_put_body(1); max_count++;  	


    }
    else
    {	
	sprintf_s(sTmp, sizeof sTmp,"�� ���s��ơG%d\n",tot_count);
	rgu_put_body_string(1,sTmp,1);max_count++;
	rgu_put_body(1); max_count++;
		      
	sprintf_s(sTmp, sizeof sTmp,"  �E������ơG%d\n",mot_count);
	rgu_put_body_string(1,sTmp,1);max_count++;
	rgu_put_body(1); max_count++;    
		
	sprintf_s(sTmp, sizeof sTmp,"�@�@�@�j��G���G%d\n",mot_count_2);
	rgu_put_body_string(1,sTmp,1);max_count++;
	rgu_put_body(1); max_count++;    
		
	sprintf_s(sTmp, sizeof sTmp,"�@�@�@�j��T���G%d\n",mot_count_3);
	rgu_put_body_string(1,sTmp,1);max_count++;
	rgu_put_body(1); max_count++;    
		 
	sprintf_s(sTmp, sizeof sTmp,"  �E�T����ơG%d\n",car_count);
	rgu_put_body_string(1,sTmp,1);max_count++;
	rgu_put_body(1); max_count++;
		
	sprintf_s(sTmp, sizeof sTmp,"�@�@�@�j��G���G%d\n",car_count_2);
	rgu_put_body_string(1,sTmp,1);max_count++;
	rgu_put_body(1); max_count++;    
		
	sprintf_s(sTmp, sizeof sTmp,"�@�@�@�j��T���G%d\n",car_count_3);
	rgu_put_body_string(1,sTmp,1);max_count++;
	rgu_put_body(1); max_count++;    
		          
	rgu_put_body_string(1," ",1);
	rgu_put_body(1); max_count++;
		       
	sprintf_s(sTmp, sizeof sTmp,"��X�ɮ�OK -> %s \n",Tmp1);
	rgu_put_body_string(1,sTmp,1);
	rgu_put_body(1); max_count++;
		 
	fclose(fp0);
	rt = rptftpinsert(UserID,"car326",sFilename);
	if (rt != 0){
	    printf("rptftpinsert error\n");
	    goto errexit;
	}		 
    }		 

     
    return M_CM_OK;

errexit:
    printf("car326_1:sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    $WHENEVER SQLERROR CONTINUE;     /* reset error handling */
    EWRITE(UserID,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}



char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  /*char sTmp_db_name[21];*/

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     printf("sTmpScomp = %s\n", sTmpScomp);
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     printf("sTmpcomp = %s\n", sTmpcomp);
     strcpy(sTmp_db_name, sTmpcomp);
  }
  return sTmp_db_name;
}

int get_ipolicy(sPolicy,sICard)
$char *sPolicy;
$char *sICard;
{
	$SELECT ipolicy  
	   INTO $sPolicy 
	   FROM compulsory_card
	  WHERE icard = $sICard;
    if (SQLCODE == SQLNOTFOUND)
    {
        strcpy(sPolicy," ");
        return FAIL;
    }
    if (sPolicy[0]=='\0' || sPolicy[0]==' ')
    	return FAIL;
    else	
	return SUCCESS;
}

long ca326_readfile()
{
    char  syy[4], smm[3], sdd[3];
    $int  count=0;
    int   rtncode;
    char  sApHome[20];
    $char sf_ipolicy[21];
    $char sf_ipolicy1[21];
    $char sf_icard[13];
    $char sf_icard1[13];
    int i;
    char  flgErr;
   
    flgErr = 'N';
    read_count = 0;
   
    $WHENEVER SQLERROR GOTO errexit;

    if ( db_select(DBName) == False)
        return M_CM_DB_NOTOPEN;

    rtncode = getApHome(sApHome);
    if (rtncode < 0) {
        printf("read Config file error!!\n");
        return M_CM_READ_CONFIG_ERR;
    }
    sprintf_s(getfile, sizeof getfile, "%s/tmp/%s", sApHome, txtfile);

    printf("getfile[%s]\n",getfile);
    if ((fp=fopen(getfile,"rt"))==NULL) return FALSE;
    if ((bp=malloc(recLen))==NULL) {
        printf("System malloc failed  !\n");
        free(bp);
        return FAIL;
    }   
   
    printf("create temp table \n");
    $CREATE TEMP TABLE comp_temp
    (
        ipolicy  char(20) default ' ' 
    )WITH NO LOG;

    $CREATE INDEX cmpid1 ON comp_temp(ipolicy);

    while(fgets(bp,recLen,fp) != NULL )
    {
        /*if (feof(fp)) break;*/

        if (iOldNew==1){  /* �s�� => �Ĥ@�欰���d���G1794C9821611�A�e�G�X�����q�N�X */

            printf("###### bp length[%d]\n",strlen(bp));
	    printf("###### bp[%s]\n",bp);	      	      
	    if (strlen(bp)<=2) continue;  /* �ɮפ������ɧ��Y���h��Ŧ�]����^�h�����A�_�hget_ipolicy()�N�|error */
                	
	    GetData(sf_icard , bp    , 12);
	    printf("###### sf_icard length[%d]\n",strlen(sf_icard));
	    printf("###### sf_icard[%s]\n",sf_icard);	      	      	                
	      	
	    sf_icard1[0]='\0';
	    if (strncmp(sf_icard,"17",2)==0){ /* �s�w�� */
		for(i = 2; i< 12; i++){	     		     	
	            sf_icard1[i-2] = sf_icard[i];	            
                }
                sf_icard1[i-2] = '\0';     	    
	    }else{	
	      	strcpy(sf_icard1,sf_icard);
	    }
	    printf("###### sf_icard1[%s]\n",sf_icard1);
	    rtncode = get_ipolicy(sf_ipolicy1,sf_icard1);
	      
	    if (rtncode!=SUCCESS){
	        printf("get_ipolicy() error!! sf_icard1=[%s]\n",sf_icard1);

                flgErr = 'Y';
		sprintf_s(str, sizeof str,"\t���d���G[%s]",sf_icard1);
		WRITELOG(sfp, str);		      	      	
		continue;
            }	      	          
      
        }else{ /* �¦� */
      	
	    GetData(sf_ipolicy , bp    , 20);      
	    for(i=0;i<20;i++){
	        if (sf_ipolicy[i] == '\t' ) break;
	    }
	    sf_ipolicy[i] = '\0';
	    printf("###### sf_ipolicy[%s]\n",sf_ipolicy);
        }
            

        /* �ѩ��¦��Ĥ@�欰�O�渹�A�G�e�G�X�����q�N�X */
        if (!strncmp(sf_ipolicy,"17",2))
        {
      	    printf("�e�G�X17\n");
            strncpy(sf_ipolicy1,sf_ipolicy+2,20);
            sf_ipolicy1[20] = 0;
        }
        else if (!strncmp(sf_ipolicy,"16",2))
        {
      	    printf("�e�G�X16\n");
            strncpy(sf_ipolicy1,sf_ipolicy+2,15);
            sf_ipolicy1[15] = 0;
 
            $SELECT ipolicy_n
               INTO $sf_ipolicy1
               FROM conv_ipolicy
              WHERE ipolicy_a = $sf_ipolicy1;
            if (SQLCODE == SQLNOTFOUND)
            {
                continue;
            }
        }
      
        strcpy(sf_ipolicy1,trim(sf_ipolicy1));

        printf("sf_ipolicy1[%s]\n",sf_ipolicy1);
        $INSERT INTO comp_temp VALUES ($sf_ipolicy1);
        read_count++;
    }
    fclose(fp);
            
    if (flgErr == 'Y'){
        sprintf_s(sMsg, sizeof sMsg,"%s","���d���L�������O�渹�s�b [�j����d��]  ");
        /*EWRITE(UserID, M_CA_NOT_IPOLICY,sMsg);*/
        return M_CA_NOT_IPOLICY;
    }
   	
    return M_CM_OK;

errexit:
   printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
   fclose(fp);
   return SQLCODE;
}


int GetData(data,offset,length)
char *data;
int offset,length;
{
    data[0]='\0';
    memcpy(data,offset,length);
    data[length] = 0x00;
printf("data[%s]\n",data);
}


int GetNo302Reason(sCompPly)
$char *sCompPly;
{
     $WHENEVER SQLERROR GOTO errexit;
     
     char  tmp_rsn[65];
     $char stmt_buf[256];
     $char clmply[21],ply_db[3],clm_db[3],FullDBName[20];
     $char sCompPolicy[21],tmp_relative_ply[21],last_ply[21];
     $int  rejct_count;
     $char sfpart[2],siacc_reason[3];
         
    printf("sCompPly[%s]\n",sCompPly);
     strcpy(sCompPly,trim(sCompPly));     
     rejct_count = 0;
     strcpy(sReason," "); 
                  
     $EXECUTE reject_ply INTO $rejct_count USING $sCompPly;

     printf("rejct_count[%d]\n",rejct_count);
      
     /* check �O�_������ĳ��O���O�� */
     if (rejct_count>0){     	 
     	  strcpy(tmp_rsn,"����ĳ��O���O��(Car137)");    
     	  printf("tmp_rsn[%s]\n",tmp_rsn);
     	   	  
     }else{	  /* check �O�_�� 1:���ѡ]�㨮���ѡ^ 2:�N��  3:���� ,
     	         ( 96.11����H�ᤧ��O��w�קאּ�j���Y�� 1:���ѡ]�㨮���ѡ^�綷�X��O��) */ 
     	              
	 	 strcpy(tmp_rsn,"��L"); /* ���w�]��"��L" */	 	 
	 	 strcpy(ply_db,get_car_full_db(sCompPly));
	 	 strcpy(FullDBName,get_full_dbname(ply_db));

	 	 printf("FullDBName[%s]\n",FullDBName);
	 	        
	     sprintf_s(stmt_buf, sizeof stmt_buf,"SELECT %s FROM %s:%s WHERE %s ",
	                      "ipolicy, irelative_ply ",
	                      FullDBName,"ply_relation ",
	                      " ipolicy = ? ");
	
	     printf("stmt ply_relation:[%s]\n",stmt_buf);
	
	     $PREPARE Get_RSN FROM $stmt_buf;
	     $EXECUTE Get_RSN INTO $last_ply,$tmp_relative_ply USING $sCompPly;
	     
	     printf("last_ply[%s]\n",last_ply);
	     printf("tmp_relative_ply[%s]\n",tmp_relative_ply);
	     if (SQLCODE != SQLNOTFOUND) {
	        
	           /* �����q���N��h�˵� */	
	           if (strlen(trim(tmp_relative_ply)) < 13)
	           {
	          	    strcpy(tmp_relative_ply,sCompPly);   /* �Y�O��O�j��A�h�˵��j��� */
	           }	
	          
               printf("tmp_relative_ply[%s]\n",tmp_relative_ply);

               strcpy(clm_db,get_car_full_db(tmp_relative_ply));

               printf("clm_db [%s]\n",clm_db);
                                                    
               /* 960315,  fpart = 1:����  2:�N��  3:���� ����O
                           �Y��1:���ѡA�����Acheck �X�I��]��"21�G�㨮����" �~����O */
               sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT %s FROM %s:%s WHERE %s %s",
                             " fpart ,iacc_reason ",
                             get_full_dbname(clm_db),
                             "appraisal ",
                             " ipolicy = ? ",
                             " AND fpart IN ('1','2','3') ");                                     

               $PREPARE clmid FROM $stmt_buf;
               $EXECUTE clmid INTO $sfpart,$siacc_reason USING $tmp_relative_ply;

               printf("appraisal_stmt[%s]\n",stmt_buf);


               if (SQLCODE != SQLNOTFOUND) { 
               	   if (sfpart[0]=='1'){
               	   	
               	   	   if(strncmp(siacc_reason,"21",2)==0){	               	   	   	
               	   	   	    strcpy(tmp_rsn,"�����l�O�����l�y���ѡz�G�㨮����"); 
               	   	   	}else{
               	   	   		strcpy(tmp_rsn,"�����l�O�����l�y���ѡz�G���D�㨮����"); 
               	   	   	}               	   	                                 	               	   	   
               	   	   	
               	   }else if (sfpart[0]=='2'){ 
               	   	
               	   	   strcpy(tmp_rsn,"�����l�O�����l�y�N��z"); 
               	   	   
               	   }else if (sfpart[0]=='3'){ 
               	   	
               	   	   strcpy(tmp_rsn,"�����l�O�����l�y�����z"); 
               	   }                 

               }	          
	     } 
 	 }
 	 
 	 strcpy(sReason,tmp_rsn); 
 	 return  SUCCESS;
 	    
errexit:
   printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
   return  SQLCODE; 
}





/*
long insert_to_batchemail(v_email_table,v_project_id, v_mail_date, v_receiver_email, v_receiver_name, v_cc, v_content, v_key, v_mail_count, v_subject, v_sMsg)
  $char   *v_email_table;
  $char   *v_project_id, *v_receiver_email, *v_receiver_name, *v_cc, *v_content, *v_key, *v_subject, *v_sMsg;    
  $int     v_mail_count;
  $date    v_mail_date ;    */
  
long insert_to_batchemail(v_email_table,v_fProc, v_sMsg)
  $char   *v_email_table,*v_sMsg;  
{
    

    $char   s_mbuf[9000],stmt[513] ;
    $char   s_email_table[129] ;    
    $char   s_project_id[8], s_receiver_email[51], s_receiver_name[17];
    $char   s_cc[51], s_key[51], s_subject[256], s_nattachment[101];    
    $loc_t  t_txtContent;
    $int    mail_count = 0;
    $long   mail_date = 0 ;    
    long   ins_count = 0,del_count = 0,tot_count = 0;
         
    $SET LOCK MODE TO WAIT;
    $WHENEVER SQLERROR GOTO errexit;
      
    strcpy(s_email_table     , trim(v_email_table));
/*    
    strcpy(s_project_id    , trim(v_project_id));
    strcpy(s_receiver_email, trim(v_receiver_email));
    strcpy(s_receiver_name , trim(v_receiver_name));
    strcpy(s_cc            , trim(v_cc));
    strcpy(s_mbuf          , trim(v_content));
    strcpy(s_key           , trim(v_key));
    strcpy(s_subject       , trim(v_subject));
    
    mail_count = v_mail_count ;
    mail_date  = v_mail_date  ;
*/    
    /*strcat(email, "@tmnewa.com.tw");*/


    t_txtContent.loc_loctype = LOCMEMORY;
    t_txtContent.loc_bufsize = 9000;     
	     
    sprintf_s(stmt, sizeof stmt,"select project_id, mail_date, receiver_email, receiver_name,   "
                "cc, content, key, mail_count, subject, nattachment from %s", s_email_table);                        
    $PREPARE pre_mail FROM $stmt;
    
    $BEGIN WORK;
    $DECLARE cur_mail CURSOR WITH HOLD FOR pre_mail;     
    $OPEN    cur_mail ;
    while(1)
    {
         $FETCH cur_mail INTO $s_project_id, $mail_date, $s_receiver_email, $s_receiver_name, 
	                      $s_cc, $s_mbuf,  $s_key, $mail_count, $s_subject, $s_nattachment;
         if(SQLCODE == SQLNOTFOUND) break;

         tot_count++;
	 t_txtContent.loc_buffer  = s_mbuf;    
	 t_txtContent.loc_size    = strlen(s_mbuf) + 1;
	     
	 /* project_id�Bmail_date�Breceiver_email �ۦP�ۡA�O�_���R�� */
    	 if (v_fProc!=0)
    	 {
    	     $DELETE FROM batchemail 
    	       WHERE project_id = $s_project_id
    	         AND mail_date  = $mail_date
    	         AND receiver_email = $s_receiver_email;
    	     if (sqlca.sqlerrd[2] > 0)
    	     {
    	         del_count ++;
    	     }    	                               
    	 }
    	 
	 $INSERT INTO batchemail
	  (project_id, mail_date, receiver_email, receiver_name, cc,
	   content, key, mail_count, nsubject, nattachment)
	  VALUES
	  ($s_project_id, $mail_date, $s_receiver_email, $s_receiver_name, 
	   $s_cc, $t_txtContent,  $s_key, $mail_count, $s_subject, $s_nattachment);		        
	
	 if (sqlca.sqlerrd[2] == 0 )
	 {
	     sprintf_s(v_sMsg, sizeof v_sMsg, "�s�W��batchemail���ѡGproject_id[%S],mail_date[%ld],receiver_email[%s],receiver_name[%s],subject[%s] \n", 
		      s_project_id, mail_date, s_receiver_email, s_receiver_name, s_subject );
		             
	     $ROLLBACK WORK;        
	     return -1;
	 }
	 ins_count ++;
    }
    $CLOSE cur_mail;	
    $FREE  cur_mail; 	
    $COMMIT WORK;
    printf("Trace -- tot_count = [%ld] \n",  tot_count);
    printf("Trace -- del_count = [%ld] \n",  del_count);
    printf("Trace -- ins_count = [%ld] \n",  ins_count);
    
    return M_CM_OK;

errexit:

    sprintf_s(v_sMsg, sizeof v_sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    return SQLCODE;
}


long chk_no_notify(v_insure_type,v_project_id,v_cus_id, v_sMsg)
  $char   *v_insure_type,*v_project_id,*v_cus_id, *v_sMsg;  
{    
    $char   stmt[513] ;    
    $char   s_insure_type[3],s_project_id[11], s_cus_id[21], s_cus_email[51];        
    $int    chkCount = 0;     
    $int    icount;
    
    
    strcpy(s_insure_type , trim(v_insure_type)); 
    strcpy(s_project_id  , trim(v_project_id)); 
    strcpy(s_cus_id      , trim(v_cus_id)); 
          
    $WHENEVER SQLERROR GOTO errexit;
    
    chkCount = 0;
    icount = 0;
    
    sprintf_s(stmt, sizeof stmt, "SELECT count(*)  "
                   " FROM sysdb:cm_cus_no_notify     "
                   "WHERE insure_type IN (UPPER('%s'),'*')  "
                   "  AND project_id = UPPER('%s')   "
                   "  AND itype_no   = UPPER('%s')   "
                   "  AND fclass    in ('1','3') ",
    s_insure_type, s_project_id, s_cus_id );
    
    $PREPARE preChkcus FROM $stmt;               
    $Execute preChkcus INTO $chkCount ;
    
    if (chkCount > 0) 
    	return 1;
    else	
    	return 0; 

errexit:

  sprintf_s(v_sMsg, sizeof v_sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  return 0;
}
    
/* ---------------------------------------------------------------------- */    
/* �ˮ֨è��o�j���I��O�O�v�N�� */
int ChkRate()
{
    $char icode1[4], icode2[4];
    $int date1, date2;
    
    $SELECT icode
       INTO $icode1
       FROM ca_rate_renew
      WHERE deffect_bgn <= today
        AND deffect_end >= today
        AND fcard_class = '1';
    if (SQLCODE == SQLNOTFOUND)
    {
       sprintf_s(sMsg, sizeof sMsg, "�j���I��O�O�v�ͮĦ~��e�t�Τ�f���]�w");
       EWRITE(UserID,M_CA_NRATE_DATE, sMsg);
       return M_CA_NRATE_DATE;
    }
    
    $SELECT icode
       INTO $icode2
       FROM ca_rate_renew
      WHERE deffect_bgn <= today+30
        AND deffect_end >= today+30
        AND fcard_class = '1';
    if (SQLCODE == SQLNOTFOUND)
    {
       sprintf_s(sMsg, sizeof sMsg, "�j���I��O�O�v�ͮĦ~��e�t�Τ�+30�ѡf���]�w");
       EWRITE(UserID,M_CA_NRATE_DATE, sMsg);
       return M_CA_NRATE_DATE;
    }
    
    printf("== 1739: icode1=[%s] icode2=[%s]\n",icode1,icode2);
    
    if (strcmp(icode1,icode2) == 0)
    {
        strcpy(chgrate,"N");        /* �j���I�O�v�L���� */
        strcpy(drate_ym, icode2);   /* �j���I�O�v�N�� */
        
        $select first 1 today+31, add_months((today+31),12), add_months((today+31),24), today+30, year(today+30)
           into $dbegin, $dend, $dend2, $paydate, $iyear
           from car_code;
        
        printf("== 1750: dbegin=[%s] dend=[%s] paydate=[%s] iyear=[%d]\n",dbegin,dend,paydate,iyear);
    }
    else
    {
        strcpy(chgrate,"Y");    /* �j���I�O�v�N�������� */
        $select drate into $date1
           from ca_rate_date 
          where icode = $icode1 and itable = 'compulsory_premium';
          
        $select drate into $date2
           from ca_rate_date 
          where icode = $icode2 and itable = 'compulsory_premium';
       
       printf("== 1763: date1=[%d] date2=[%d] \n",date1, date2);
       
        if (date1 == date2)
        {
            /* �O�v�N�����P, �O�v�ͮĤ�ۦP */
            strcpy(drate_ym, icode2);   /* �j���I�O�v�N�� */
            
            $select first 1 today+31, add_months((today+31),12), add_months((today+31),24), today+30, year(today+30)
               into $dbegin, $dend, $dend2, $paydate, $iyear
               from car_code;
               
            printf("== 1774: dbegin=[%s] dend=[%s] paydate=[%s] iyear=[%d]\n",dbegin,dend,paydate,iyear);
        }
        else
        {
            /* �O�v�N�����P, �O�v�ͮĤ餣�P */
            strcpy(drate_ym, icode1);   /* �j���I�O�v�N�� */
            
            $select drate-1, add_months(drate-1,12), add_months(drate-1,24), drate-2, year(drate-1)
               into $dbegin, $dend, $dend2, $paydate, $iyear
               from ca_rate_date 
              where icode = $icode2 and itable = 'compulsory_premium';
              
            printf("== 1787: dbegin=[%s] dend=[%s] paydate=[%s] iyear=[%d]\n",dbegin,dend,paydate,iyear);
        }
    }    
    strcpy(sTmpChDate,cm_from_infdate_100(dbegin));    /* �ͮĤ� */
    strcpy(sTmpChDate_pay,cm_from_infdate_100(paydate));   /* ú�ںI���*/
    
    printf("== 1792: dbegin=[%s] dend=[%s] paydate=[%s] iyear=[%d]\n",dbegin,dend,paydate,iyear);
    printf("== 1793: sTmpChDate=[%s] sTmpChDate_pay=[%s] \n",sTmpChDate,sTmpChDate_pay);
    
    return SUCCESS;

errexit :
    printf("ChkRate: SQLCODE:[%d]",SQLCODE);
    return SQLCODE;
    
}    
/* ---------------------------------------------------------------------- */    
/* �ˮ֨è��o�j���I��O�O�v�N�� */
int ChkRate_test()
{
    $char icode1[4], icode2[4];
    $int date1, date2;
    
    $SELECT icode
       INTO $icode1
       FROM ca_rate_renew
      WHERE deffect_bgn <= '10/15/2022'
        AND deffect_end >= '10/15/2022'
        AND fcard_class = '1';
    if (SQLCODE == SQLNOTFOUND)
    {
       sprintf_s(sMsg, sizeof sMsg, "�j���I��O�O�v�ͮĦ~��e�t�Τ�f���]�w");
       EWRITE(UserID,M_CA_NRATE_DATE, sMsg);
       return M_CA_NRATE_DATE;
    }
    
    $SELECT icode
       INTO $icode2
       FROM ca_rate_renew
      WHERE deffect_bgn <= date('10/15/2022')+30
        AND deffect_end >= date('10/15/2022')+30
        AND fcard_class = '1';
    if (SQLCODE == SQLNOTFOUND)
    {
       sprintf_s(sMsg, sizeof sMsg, "�j���I��O�O�v�ͮĦ~��e�t�Τ�+30�ѡf���]�w");
       EWRITE(UserID,M_CA_NRATE_DATE, sMsg);
       return M_CA_NRATE_DATE;
    }
    
    printf("== 1739: icode1=[%s] icode2=[%s]\n",icode1,icode2);
    
    if (strcmp(icode1,icode2) == 0)
    {
        strcpy(chgrate,"N");        /* �j���I�O�v�L���� */
        strcpy(drate_ym, icode2);   /* �j���I�O�v�N�� */
        
        $select first 1 date('10/15/2022')+31, add_months((date('10/15/2022')+31),12), add_months((date('10/15/2022')+31),24), date('10/15/2022')+30, year(date('10/15/2022')+30)
           into $dbegin, $dend, $dend2, $paydate, $iyear
           from car_code;
        
        printf("== 1750: dbegin=[%s] dend=[%s] paydate=[%s] iyear=[%d]\n",dbegin,dend,paydate,iyear);
    }
    else
    {
        strcpy(chgrate,"Y");    /* �j���I�O�v�N�������� */
        $select drate into $date1
           from ca_rate_date 
          where icode = $icode1 and itable = 'compulsory_premium';
          
        $select drate into $date2
           from ca_rate_date 
          where icode = $icode2 and itable = 'compulsory_premium';
       
       printf("== 1763: date1=[%d] date2=[%d] \n",date1, date2);
       
        if (date1 == date2)
        {
            /* �O�v�N�����P, �O�v�ͮĤ�ۦP */
            strcpy(drate_ym, icode2);   /* �j���I�O�v�N�� */
            
            $select first 1 date('10/15/2022')+31, add_months((date('10/15/2022')+31),12), add_months((date('10/15/2022')+31),24), date('10/15/2022')+30, year(date('10/15/2022')+30)
               into $dbegin, $dend, $dend2, $paydate, $iyear
               from car_code;
               
            printf("== 1774: dbegin=[%s] dend=[%s] paydate=[%s] iyear=[%d]\n",dbegin,dend,paydate,iyear);
        }
        else
        {
            /* �O�v�N�����P, �O�v�ͮĤ餣�P */
            strcpy(drate_ym, icode1);   /* �j���I�O�v�N�� */
            
            $select drate-1, add_months(drate-1,12), add_months(drate-1,24), drate-2, year(drate-1)
               into $dbegin, $dend, $dend2, $paydate, $iyear
               from ca_rate_date 
              where icode = $icode2 and itable = 'compulsory_premium';
              
            printf("== 1787: dbegin=[%s] dend=[%s] paydate=[%s] iyear=[%d]\n",dbegin,dend,paydate,iyear);
        }
    }    
    strcpy(sTmpChDate,cm_from_infdate_100(dbegin));    /* �ͮĤ� */
    strcpy(sTmpChDate_pay,cm_from_infdate_100(paydate));   /* ú�ںI���*/
    
    printf("== 1792: dbegin=[%s] dend=[%s] paydate=[%s] iyear=[%d]\n",dbegin,dend,paydate,iyear);
    printf("== 1793: sTmpChDate=[%s] sTmpChDate_pay=[%s] \n",sTmpChDate,sTmpChDate_pay);
    
    return SUCCESS;

errexit :
    printf("ChkRate: SQLCODE:[%d]",SQLCODE);
    return SQLCODE;
    
}    
/*-------------------------------------------------------------------------- */
int Get_comp_prem()
{

    $double mpremium, mbusiness, mresearch, pready_rate, pcomprate, 
            pstablerate, pinvestrate, pinterest, pcapital, maintain,
            dprem12, dprem_se, dprem24, mbus_rule;
    $char   icar_type[3];    
    $char   tmpsql[1000];
    $long   premium1, premium2;
    
    $create temp table comp_prem(
        icar_type   char(2),        -- ����
        prem1       int,            -- �j���I�O�O1�~��
        prem2       int,            -- �j���I�O�O2�~��
        mbusiness   decimal(10,5)   -- �j���I�~�ȶO��1�~��
    ) with no log;
    
    /* ���j���I�O�B */
    injured_cover_comp = death_cover_comp = damage_cover_comp = 0;
    
    sprintf_s(tmpsql, sizeof tmpsql, 
        " SELECT icar_type, mcoverage1, mcoverage2, mcoverage3, mpremium, mbusiness,  "
        "        mresearch, pready_rate, pcomprate, pstablerate, pinvestrate,  "
        "        pinterest, pcapital, maintain  "
	"   FROM compulsory_premium  "
        "  WHERE mcoverage1> 0  "
        "    AND icar_type in ('01', '02','32', '34', '35')  "
        "    AND qperiod = 12  "
        "    AND drate = (select drate from ca_rate_date  "
        "                  where icode = '%s'  "
        "                    and itable = 'compulsory_premium')", drate_ym);
                            


    $PREPARE pre_calcomp FROM $tmpsql;
    $DECLARE cur_calcomp CURSOR for pre_calcomp;
    $OPEN cur_calcomp;
    while(1)
    {
        $FETCH cur_calcomp 
          INTO $icar_type, $injured_cover_comp,$death_cover_comp,$damage_cover_comp, 
               $mpremium, $mbusiness, $mresearch, $pready_rate, $pcomprate, 
               $pstablerate, $pinvestrate, $pinterest, $pcapital, $maintain;
        if(SQLCODE == SQLNOTFOUND) break;
        
        
        pready_rate/=100.0;
        pcomprate/=100.0;
        pstablerate/=100.0;
        pinvestrate/=100.0;
        pcapital/=100.0;
        mbus_rule = mbusiness;

        
        if(strcmp(icar_type,"35") != 0)
        {
            /*�D35����*/
            dprem12 = d45(((d45(mpremium,2)+mbusiness+mresearch+maintain) /
                          (1-pready_rate-pcomprate-pstablerate-pcapital+pinvestrate)),0);  /* 1�~���O�O */        	
        }
        else
        {
            /*35����*/
            dprem12 = d45(((d45(mpremium,2)+mbusiness+mresearch+maintain) /
                          (1-pcomprate-pstablerate)),0);  /* 1�~���O�O */ 
        }
        

                       
        premium1 = dprem12;
        

        /*�p��ĤG�~�j������O�O*/
        $SELECT mpremium,pready_rate,pcomprate,pstablerate,
                pinvestrate,mbusiness,pinterest,maintain
           INTO $mpremium, $pready_rate, $pcomprate, $pstablerate,
                $pinvestrate, $mbusiness, $pinterest, $maintain
           FROM compulsory_premium
          WHERE icar_type= $icar_type
            AND qperiod=24
            AND drate=(select drate from ca_rate_date  where icode = $drate_ym
                          and itable = 'compulsory_premium');
                          
        pready_rate/=100.0;
        pcomprate/=100.0;
        pstablerate/=100.0;
        pinvestrate/=100.0;
        pinterest/=100.0; 

        if(strcmp(icar_type,"35") != 0)
        {
            /*�D35����*/
            dprem_se = (d45(mpremium,2)+mbusiness+maintain)/
                        (1-pready_rate-pcomprate-pstablerate-pcapital+pinvestrate)*d45(1/(1+pinterest),5);   /* ��2�~�O�O */
        }
        else
        {
            /*35����*/
            dprem_se = (d45(mpremium,2)+mbusiness+maintain)/
                        (1-pcomprate-pstablerate);   /* ��2�~�O�O */
        }
                        
        premium2 = (long) d45((dprem12 + dprem_se), 0); /* 2�~���O�O */
        

        
        $insert into comp_prem
            (icar_type, prem1, prem2, mbusiness)
         values
            ($icar_type, $premium1, $premium2, $mbus_rule);
            
        printf("icar_type=[%s]premium1=[%d]premium2=[%d]mbus_rule=[%f]\n", icar_type,premium1,premium2,mbus_rule);
    }
    $CLOSE cur_calcomp;
    $FREE cur_calcomp;
    return SUCCESS;
    
errexit :
    printf("Get_comp_prem: SQLCODE:[%d]",SQLCODE);
    strcpy(sMsg,"�j����O�O�p�⦳�~ (Get_comp_prem) !!");
    return SQLCODE;
}
/* -------------------------------------------------------------------------- */
double d45(num,num1)
double num;
int num1;
{
    long tmplong;
    double var1;
    double ten;
    int i;

    ten = 1;
    for(i = 1 ;i<=num1;i++)
    ten *= 10;

    num *= ten;
    if (num >= 0) var1 = 0.5;
    else var1 = (-0.5);

    num = num + var1;
    tmplong = num;

    num = tmplong/ten;
    return(num);
}
/* -------------------------------------------------------------------------- */
int upd302(ipolicy,icar_type)
char ipolicy[21],icar_type[3];
{
    
    $char   sIpolicy[21], sIcar_type[3], sIleader[11], sNleader[11], 
            ibranch[3], icomm_obj[11], sTmpIcomp[2], isub[3],
            sIengine[CA_ENGINE_NUM], sIquota[7], fsend_msg[2], mobile_phone[11],
            sIofficer[11];
    $double mbusiness1;
    $char   stp_sql[5000];
    $int    fuw_status_sug=500;
    
    strcpy(sIpolicy, trim(ipolicy));        /* �O�渹 */
    strcpy(sIcar_type, trim(icar_type));    /* ���� */
    strcpy(s_nassured, rtrim(s_nassured));  /* �Q�O�I�H�m�W(�L�B�n) */
    strcpy(napplicant, rtrim(napplicant));
    
    $WHENEVER SQLERROR GOTO errexit;
    
    /* ���u�̷s�O���ɡv��ơGilicense�Bnassured�Biapplicant�Bnapplicant�Bitag�Bimovephone (1111011002_SC1) */    
    $select a.iofficer, b.ileader, c.nname, c.ibranch, c.icomm_obj, c.iupcomp, 
            c.iquota, replace(a.imovephone,'-'), nvl(a.iengine,' ')
       into $sIofficer, $sIleader, $sNleader, $ibranch, $icomm_obj, $sTmpIcomp,
            $sIquota, $mobile_phone, $sIengine
       from policy_302 a, officer b, officer c
      where a.iofficer = b.iofficer 
        and b.ileader = c.iofficer
        and a.ipolicy = $sIpolicy;


    $SELECT iupcomp INTO $isub FROM branch WHERE ibranch = $ibranch ;    /* �����q   */ 
    
    /* ��ʹq�� -- ��������²�T    */
    strcpy(mobile_phone, trim(mobile_phone));
    strcpy(fsend_msg,"N");
    strcpy(mobile_phone," ");
    

    /* �O�O */        
    $select prem1, prem2, mbusiness
       into $mprem1, $mprem2, $mbusiness1
       from comp_prem
      where icar_type = $sIcar_type;
    
    strcpy( cmprem1, itoa(mprem1));
    strcpy( cmprem2, itoa(mprem2));
    
    /* �g��N�� ==> ��car302�g�쪺�޲z�H(��Z32018N���ഫ) (1120721006_C04) */
    if(strcmp(trim(sIofficer),"Z32018N") != 0)
    {
    	strcpy(sIofficer, trim(sIleader));
    } 
    
    printf("sTmpIcomp=[%s]ibranch=[%s]sTmpChDate=[%s]sTmpChDate_pay=[%s]\n",sTmpIcomp,ibranch,sTmpChDate,sTmpChDate_pay);
    
    $begin work;
    
    
    /**********************/
    /**    �������渹    **/
    /**********************/
            
    /* �����渹-1�~�� */
    rc = cm_get_serial_num("C1", "RN", sTmpIcomp, ibranch, sTmpChDate, iestimate_ori); 
    printf("rc=[%d] iestimate_ori=[%s]\n",rc, iestimate_ori);
    
    /* �����渹-2�~�� */
    rc = cm_get_serial_num("C1", "RN", sTmpIcomp, ibranch, sTmpChDate, iestimate_sug); 
    printf("rc=[%d] iestimate_sug=[%s]\n",rc, iestimate_ori);    	


    
    /**********************/
    /**    ��ú�ڳ渹    **/
    /**********************/ 
    
    /* �t�X�Ȧ�����b��, ��I�s cm_get_va_num()  modify by sylvia 106.12.19 (1060831012_C3) */
    /* �t�X�|�X�@ú�O��睊�A�s�W����@�ص����b�� modify by 061476 108.11.19 (1070518005_SC1) */
    
    /* ú�ڳ渹-- 1�~���K�Q�ө� */
    strcpy(F_type,"6075");
    rc = cm_get_va_num(F_type, "0", "0", sTmpChDate_pay, mprem1, itransno_ori, itransno_ori_007, itransno_ori_008, itransno_ori_009, itransno_ori_atm, itransno_ori_013);
    printf("rc=[%d]sTmpChDate_pay=[%s] itransno_ori=[%s]\n",rc, sTmpChDate_pay,itransno_ori);
    
    /* ú�ڳ渹-- 2�~���K�Q�ө��A35���ؤ�����2�~��ú�ڳ渹 */	
    if(strcmp(icar_type,"35") != 0)
    {
        strcpy(F_type,"6075");
        rc = cm_get_va_num(F_type, "0", "0", sTmpChDate_pay, mprem2, itransno_sug, itransno_sug_007, itransno_sug_008, itransno_sug_009, itransno_sug_atm, itransno_sug_013);
        printf("rc=[%d]sTmpChDate_pay=[%s] itransno_sug=[%s]\n",rc,sTmpChDate_pay, itransno_sug);
    }
    else
    {
    	mprem2 = mprem1;
    	strcpy(itransno_sug," ");
    	strcpy(itransno_sug_007," ");
    	strcpy(itransno_sug_008," ");
    	strcpy(itransno_sug_009," ");
    	strcpy(itransno_sug_atm," ");
    	strcpy(itransno_sug_013," ");
    	strcpy(dend2,dend);
    	fuw_status_sug=505;         /*35���ث�ĳ��O�զX�f�֥N�X��505*/
    }
    
    
    printf("========================================\n");        
    printf("sIengine=[%s]itag=[%s]sIpolicy=[%s]\n",sIengine,itag,sIpolicy);
    
    /*******************************/
    /**    �g�J cm_pre_receive    **/
    /*******************************/
    
    printf("== start insert cm_pre_receive  �@�~��(���O�զX) \n");
    /* �@�~��(���O�զX) */
    $insert into cm_pre_receive
        (iins_cat, ipre_rcv, iins_kind, iins_kind_ply, ftype, 
         ipre_end, iassured, nassured, iapplicant, napplicant,
         itag, iengine, deffect, paydate, mprem,
         isub, iofficer, ileader, iquota, icomm_obj,
         iroute, fcommit, ientry, dentry, isys,
         igroup, fstatus, iupdate, dupdate, ipolicy1,
         ipolicy2, iendorse, icard, dprint, dprint_rcv,
         iedr_return, ftype_pol, ftype_sp, dbegin, dend, fsend_msg, 
         mobile_phone, ilast_policy) 
     values
        ('C', $iestimate_ori, '1', 'C1', 'P',  
         ' ', $ilicense, $s_nassured, $iapplicant, $napplicant,  
         $itag, $sIengine, $dbegin, $paydate, $mprem1,  
         $isub, $sIofficer, $sIleader, $sIquota, $icomm_obj,   
         'KA', 'N', $UserID, current, '4', 
         ' ', 10, 'car326', current, ' ',  
         ' ', ' ', ' ', '', current,   
         '9', 'SP', '01', $dbegin, $dend, 'N', 
         ' ', $sIpolicy);

     
    /* �G�~��(��ĳ��O�զX) */

    printf("== start insert cm_pre_receive   �G�~��(��ĳ��O�զX) \n");     
       
    $insert into cm_pre_receive
        (iins_cat, ipre_rcv, iins_kind, iins_kind_ply, ftype, 
         ipre_end, iassured, nassured, iapplicant, napplicant,
         itag, iengine, deffect, paydate, mprem,
         isub, iofficer, ileader, iquota, icomm_obj,
         iroute, fcommit, ientry, dentry, isys,
         igroup, fstatus, iupdate, dupdate, ipolicy1,
         ipolicy2, iendorse, icard, dprint, dprint_rcv,
         iedr_return, ftype_pol, ftype_sp, dbegin, dend, fsend_msg, 
         mobile_phone, ilast_policy) 
     values
        ('C', $iestimate_sug, '1', 'C1', 'P',  
         ' ', $ilicense, $s_nassured, $iapplicant, $napplicant,  
         $itag, $sIengine, $dbegin, $paydate, $mprem2,  
         $isub, $sIofficer, $sIleader, $sIquota, $icomm_obj,   
         'KA', 'N', $UserID, current, '5', 
         ' ', 10, 'car326', current, ' ',  
         ' ', ' ', ' ', '', current,   
         '9', 'SP', '01', $dbegin, $dend2, 'N', 
         ' ', $sIpolicy);
 
         
    /****************************/
    /**    �g�J ao_rcv_type    **/
    /****************************/
   
    /* �@�~�� */
    printf("== start insert ao_rcv_type  �@�~��(���O�զX) \n");
    printf("iyear[%s], itransno_ori[%s],iestimate_ori[%s], mprem1[%d], ilicense[%s],s_nassured[%s]\n",iyear, itransno_ori,iestimate_ori, mprem1, ilicense, s_nassured);
    printf("UserID[%s], paydate[%s], dbegin[%s], isub[%s],icomm_obj[%s],sIofficer[%s],sIleader[%s]\n", UserID, paydate, dbegin, isub, icomm_obj, sIofficer, sIleader);
        
    
    
    $INSERT INTO ao_rcv_type 
        (data_type, iyear, trcv, trcv_main, tseq, 
         ipolicy1, ipolicy2, iendorse, ipre_end, times, 
         icard, ipre_rcv, mprem, iassured, iassured_ext, 
         nassured, userid, paydate, paydate_ext, isub, 
         ibroker, iofficer, insure_type, iins_kind, dpay) 
     VALUES 
        ('3', $iyear, $itransno_ori, $itransno_ori, '1',
         ' ', ' ', ' ', ' ', 0,  
         ' ', $iestimate_ori, $mprem1, $ilicense, ' ',
         $s_nassured, $UserID, $paydate, $dbegin, $isub,
         $icomm_obj, $sIofficer, 'C', '1', '');
    
    /* �G�~���A35���ؤ�����2�~��ú�ڳ渹*/
    if(strcmp(icar_type,"35") != 0)
    { 
        printf("== start insert ao_rcv_type  �G�~��\n");
        printf("iyear[%s],itransno_ori[%s],iestimate_ori[%s], mprem1[%d], ilicense[%s],s_nassured[%s]\n",iyear, itransno_ori,iestimate_ori, mprem1, ilicense, s_nassured);
        printf("UserID[%s],paydate[%s], dbegin[%s], isub[%s],icomm_obj[%s],sIofficer[%s],sIleader[%s]\n", UserID, paydate, dbegin, isub, icomm_obj, sIofficer, sIleader);
       
        
        $INSERT INTO ao_rcv_type 
            (data_type, iyear, trcv, trcv_main, tseq, 
             ipolicy1, ipolicy2, iendorse, ipre_end, times, 
             icard, ipre_rcv, mprem, iassured, iassured_ext, 
             nassured, userid, paydate, paydate_ext, isub, 
             ibroker, iofficer, insure_type, iins_kind, dpay) 
         VALUES 
            ('3', $iyear, $itransno_sug, $itransno_sug, '1',
             ' ', ' ', ' ', ' ', 0,  
             ' ', $iestimate_sug, $mprem2, $ilicense, ' ',
             $s_nassured, $UserID, $paydate, $dbegin, $isub,
             $icomm_obj,$sIofficer, 'C', '1', '');
    }
    printf("== success insert ao_rcv_type \n");
    
    /*****************************/
    /**    update policy_302    **/
    /*****************************/
     
    printf("== update policy_302\n"); 

    $update policy_302
        set option = '5', dply_bgn_comp = $dbegin, dply_end_comp = $dend, 
            comp_prem = $mprem1, 
            iofficer = $sIofficer, nname = $sNleader, mbusiness = $mbusiness1,
            v_prem = 0, v_ori_prem = 0, tot_prem = 0, mdiscount = 0, 
            iroute = 'KA', bzfrom = '10', irate_type = 'C', iroute_comm = 'G01',
            iroute_prop = ' ', iupdate = $UserID, dupdate = current, 
            iestimate_ori = $iestimate_ori, iestimate_sug = $iestimate_sug,
            itransno_ori = $itransno_ori,  itransno_sug = $itransno_sug,
            fuw_status_ori = 500, fuw_status_sug = $fuw_status_sug, 
            mcomp_prem_sug = $mprem2, 
            frenew_type = '4', itransno_sug_atm = $itransno_sug_atm, 
            itransno_ori_atm = $itransno_ori_atm, 
            itransno_sug_post = ' ', itransno_ori_post = ' ',
            itransno_ori_007 = $itransno_ori_007, itransno_ori_008 = $itransno_ori_008,
            itransno_ori_009 = $itransno_ori_009, itransno_sug_007 = $itransno_sug_007,
            itransno_sug_008 = $itransno_sug_008, itransno_sug_009 = $itransno_sug_009,
            itransno_ori_013 = $itransno_ori_013, itransno_sug_013 = $itransno_sug_013,
            ilicense = $ilicense, nassured = $s_nassured, aassured_zip = $aassured_zip,
            aassured = $aassured, dbirth = $dbirth, fsex = $fsex, fmarriage = $fmarriage,
            fassured = $fassured, iemail = $iemail, itel = $bitel, tphone_con = $itel_night,
            imovephone = $mobil_phone, iassured_cntry = $iassured_cntry, 
            foccup = $foccup, noccup = $noccup, ndeputy_assured = $ndeputy_assured,
            nuser = $nuser, nbenef = $nbenef, itag = $itag, 
            tmobile_eply = $tmobile_eply, aemail_eply = $aemail_eply,
            iapplicant = $iapplicant, napplicant = $napplicant, apayment_zip = $apayment_zip,
            apayment = $apayment, dbirth_appl = $dbirth_appl, fsex_appl = $fsex_appl,
            fapplicant = $fapplicant, aemail_appl = $aemail_appl, itel_appl = $itel_appl, 
            tmobile_appl = $tmobile_appl, iapplicant_cntry = $iapplicant_cntry,
            applicant_foccup = $applicant_foccup, applicant_noccup = $applicant_noccup,
            ndeputy_appl = $ndeputy_appl, nrelation_appl = $nrelation_appl       
      where ipolicy = $sIpolicy;    	


    /*********************************/
    /**    delete �D�j���I���I��    **/
    /*********************************/
    
    printf("== delete ply_ins_type_302  iins_type <> '21' \n"); 	
    $delete from ply_ins_type_302 where ipolicy = $sIpolicy and iins_type <> '21';

    /***********************************/
    /**    update ply_ins_type_302    **/
    /***********************************/
    
    printf("== update ply_ins_type_302  iins_type ='21' \n"); 
    
	
    $update ply_ins_type_302
        set minjured_cover = $injured_cover_comp,
            mdeath_cover = $death_cover_comp,
            mdamage_cover = $damage_cover_comp,
            mprem = $mprem2,
            mins_premium = $mprem2,
            drate_ym = $drate_ym,
            ori_inj_cover = $injured_cover_comp,
            ori_dea_cover = $death_cover_comp,
            ori_dam_cover = $damage_cover_comp,
            ori_premium = $mprem1
      where ipolicy = $sIpolicy and iins_type = '21';  

    printf("== upd302 OK! \n"); 
    
    
    	
    $commit work;
    
    return SUCCESS;
     
errexit :
    printf("upd302: SQLCODE:[%d]\n",SQLCODE);
    strcpy(sMsg,"�^�gpolicy_302, cm_pre_receive���� (upd302) !!");
    $ROLLBACK WORK;
    return SQLCODE;  

}


/* sOpt==> O:���O�զX N:��ĳ��O�զX */
/* sOpt2==> A:ATM    B:�K�Q�ө� */
int GetTransNo(sOpt,TmpMprem,sOpt2)
char sOpt[2],sOpt2[2];
int TmpMprem;
{
   int n1, chk1, chk2, sum1, x;
   char sTrans1[21], sMprem[9],sTrans2[21];
   char itransno_ori_atm[21],itransno_sug_atm[21];


   strcpy(sTrans1," ");strcpy(sTrans2," ");
   if (strcmp(sOpt,"O") == 0)
   {
      if (strcmp(sOpt2,"B") == 0)
        strcpy(sTrans1,trim(itransno_ori)); /* ���O�զX_�K�Q�ө�ú�ڽs��(ORI) */
      else
        strcpy(sTrans1,trim(itransno_ori_atm)); /* ���O�զX_ATMú�ڽs��(ORI) */
   }
   else if(strcmp(sOpt,"N") == 0)
   {
      if (strcmp(sOpt2,"B") == 0)
        strcpy(sTrans1,trim(itransno_sug)); /* ��ĳ��O�զX_�K�Q�ө�ú�ڽs��(SUG) */
      else
        strcpy(sTrans1,trim(itransno_sug_atm)); /* ��ĳ��O�զX_ATMú�ڽs��(SUG) */
   }
   sprintf_s(sMprem, sizeof sMprem,"%08d",TmpMprem);   /* �O�O */

   /* �Ĥ@�h */
   chk1 = sum1 = 0;
   for(n1=0;n1<13;n1++)
   {
      if (n1<6)
     {
        x = (sTrans1[n1]-48)*(n1+4);
     }
      else
     {
         x = (sTrans1[n1]-48)*(n1-5);
     }
     sum1 = sum1+(x%10); /* ���Ӧ�ƥ[�` */

   }
   chk1 = 10-(sum1%10) ; /* �Ĥ@���ˬd�X (10-(sum1���Ӧ��)) */
   /* printf("�Ĥ@�h:chk1[%d]sum1=[%d]\n",chk1,sum1); */

   /* �ĤG�h:���B�ˮ� */
   chk2 = sum1 = 0;
   for(n1=0;n1<8;n1++)
   {
     x = (sMprem[n1]-48)*(8-n1);
     sum1 = sum1+(x%10);  /* ���Ӧ�ƥ[�` */

   }
   chk2 = 10-(sum1%10); /* �ĤG���ˬd�X (10-(sum1���Ӧ��)) */
   /* printf("�ĤG�h:chk2[%d]sum1=[%d]\n",chk2,sum1); */


   sprintf_s(sTrans2, sizeof sTrans2,"%.13s%d",sTrans1,(chk1+chk2)%10);   /* ����ú��ú�� */

   if (strcmp(sOpt,"O") == 0)
   {
        if (strcmp(sOpt2,"B") == 0)
        {
            strcpy(itransno_ori,sTrans2); /* ���O�զX_�K�Q�ө�ú�ڽs��(ORI) */
        }
        else
        {
            strcpy(itransno_ori_atm,sTrans2); /* ���O�զX_ATMú�ڽs��(ORI) */
        }
   }
   else if(strcmp(sOpt,"N") == 0)
   {
      if (strcmp(sOpt2,"B") == 0)
      {
        strcpy(itransno_sug,sTrans2); /* ��ĳ��O�զX_�K�Q�ө�ú�ڽs��(SUG) */
       }
      else
      {
        strcpy(itransno_sug_atm,sTrans2); /* ��ĳ��O�զX_ATMú�ڽs��(SUG) */
       }
   }
   return SUCCESS;
}

/* ------------------------------------------------------------------------- */
int upd302_JB(ipolicy,icar_type,iroute)
char ipolicy[21],icar_type[3],iroute[21];
{

    $char   sIpolicy[21], sIcar_type[3], sIroute[21], sIleader[11], sNleader[11], 
            ibranch[3],icomm_obj[11], sTmpIcomp[2], isub[3],
            sIengine[CA_ENGINE_NUM], sIquota[7],fsend_msg[2], mobile_phone[11], 
            sIofficer[11];
    $double mbusiness1;
    $char   stp_sql[5000];
    $int    fuw_status_sug=500;
    $int    cdiscount1 = 0,cdiscount2 = 0;  /* �j������B */
    $char   iroute_comm[4], irate_type[2], iins_cat[2];
    
    /* cmn144 */
    $int    o_qrec = 0;  
    $struct cm_route_comm o_stcomm;
    $char   icheck_busi[2];                 /* �~�ȶO���ˮֽX  */
    $double mservice;                       /* ����O */
    $int    mother_busi;                    /* ��L�~�ȶO�� */
    
    int     rtncode;
    
    strcpy(sIpolicy, trim(ipolicy));        /* �O�渹 */
    strcpy(sIcar_type, trim(icar_type));    /* ���� */
    strcpy(sIroute, trim(iroute));          /* �q���N�� */
    strcpy(s_nassured, rtrim(s_nassured));  /* �Q�O�I�H�m�W(�L�B�n) */
    strcpy(napplicant, rtrim(napplicant));
    strcpy(sIofficer, rtrim(sIofficer));
    
    $WHENEVER SQLERROR GOTO errexit;
    
    printf("------ 2406 start upd302_JB ------------ \n");
    
    $select a.iofficer, b.ileader, c.nname, b.ibranch, b.icomm_obj, b.iupcomp, 
            b.iquota, replace(a.imovephone,'-'), nvl(a.iengine,' ')
       into $sIofficer, $sIleader, $sNleader, $ibranch, $icomm_obj, $sTmpIcomp, 
            $sIquota, $mobile_phone, $sIengine
       from policy_302 a, officer b, officer c
      where a.iofficer = b.iofficer 
        and b.ileader = c.iofficer
        and c.iofficer =c.ileader
        and a.ipolicy = $sIpolicy;
    
    
    $SELECT iupcomp INTO $isub FROM branch WHERE ibranch = $ibranch ;    /* �����q   */ 
    
    /* ��ʹq�� -- ��������²�T    */
    strcpy(mobile_phone, trim(mobile_phone));
    strcpy(fsend_msg,"N");
    strcpy(mobile_phone," ");
    

    /* �O�O */        
    $select prem1, prem2, mbusiness
       into $mprem1, $mprem2, $mbusiness1
       from comp_prem
      where icar_type = $sIcar_type;
     
    
    /* Ū��cmn144�]�w���o�j���I�����B (1131029001_C01) */  
    $select iroute_comm, irate_type
       into $iroute_comm, $irate_type
       from officer
      where iofficer = $sIofficer;
      
    $select ncode 
       into $iins_cat
       from cu_code_data 
      where itype = '97' 
        and icode = $sIcar_type;

    /* �ǤJ�Ѽ�:
    1. �q���N��    2. �O�v�O           3. �~�ȱ���N��     4. �X�@�j�I�O
    5. �����I�O    6. �I��(���I��)     7. �~��         */
    
    /***** �@�~�� *****/
    mservice = 0; mother_busi = 0; o_qrec = 0;  
    memset(&o_stcomm, 0x00, sizeof(o_stcomm));
    rtncode = cm_get_insure_comm(sIroute, irate_type, iroute_comm, "C", iins_cat ,
                                 "21", "1", &o_qrec, &o_stcomm, " ");
    
    /*printf("Trace -- sIroute = [%s] \n",  sIroute);
    printf("Trace -- cm_get_insure_comm()  rtncode = [%ld],o_qrec=[%d] \n", rtncode,o_qrec);*/
    
    if( rtncode != M_CM_OK )
    {
    	sprintf_s(sMsg, sizeof sMsg,"���o�~�ȱ�����~:�q��[%s]�O�v�O[%s]�~�ȱ���[%s]�I�O[%s]�~��[1]",
    	                            rtrim(sIroute),irate_type,iroute_comm,iins_cat);    	
    	                            
    	return -1000;
    }
    else if ( o_qrec==0 )
    {
    	sprintf_s(sMsg, sizeof sMsg,"���o�~�ȱ�����~:�q��[%s]�O�v�O[%s]�~�ȱ���[%s]�I�O[%s]�~��[1]",
    	                            rtrim(iroute),irate_type,iroute_comm,iins_cat);    		

    	return -1000;
    }
    
    /* icheck_busi => 0.�T�w 1.�W�� 2.�X�֩T�w 3.�X�֤W��2�P3���P����O�X���ˮ� */
    /* mservice    => ����O            */
    /* mother_busi => ��L�~�ȶO��      */
    strcpy(icheck_busi, o_stcomm.icheck_busi);
    mother_busi = o_stcomm.mother_busi;
    mservice = o_stcomm.mservice;
    
    if (icheck_busi[0]=='0')
    {
    	cdiscount1 = (long)mother_busi;
    }	
    else if ((icheck_busi[0]=='1')||(icheck_busi[0]=='3'))
    {
    	if (icheck_busi[0]=='1'){
    		cdiscount1 = (long)mother_busi ;
    	}else{
    		cdiscount1 = (long)mother_busi + (long)mservice;
    	}	
    }
    else if (icheck_busi[0]=='2')
    {
    	cdiscount1 = (long)mother_busi + (long)mservice;
    }
    /* Ū��cmn144(�@�~��) end */
    
    /***** �G�~�� *****/
    mservice = 0; mother_busi = 0; o_qrec = 0;
    memset(&o_stcomm, 0x00, sizeof(o_stcomm)); 
    rtncode = cm_get_insure_comm(sIroute, irate_type, iroute_comm, "C", iins_cat ,
                                 "21", "2", &o_qrec, &o_stcomm, " ");
    
    if( rtncode != M_CM_OK )
    {
    	sprintf_s(sMsg, sizeof sMsg,"���o�~�ȱ�����~:�q��[%s]�O�v�O[%s]�~�ȱ���[%s]�I�O[%s]�~��[2]",
    	                            rtrim(sIroute),irate_type,iroute_comm,iins_cat);   	
    	
    	return -1000;
    }
    else if ( o_qrec==0 )
    {
    	sprintf_s(sMsg, sizeof sMsg,"���o�~�ȱ�����~:�q��[%s]�O�v�O[%s]�~�ȱ���[%s]�I�O[%s]�~��[2]",
    	                             rtrim(iroute),irate_type,iroute_comm,iins_cat);
    	
    	return -1000;
    }
      
    /* icheck_busi => 0.�T�w 1.�W�� 2.�X�֩T�w 3.�X�֤W��2�P3���P����O�X���ˮ� */
    /* mservice    => ����O            */
    /* mother_busi => ��L�~�ȶO��      */
    strcpy(icheck_busi, o_stcomm.icheck_busi);
    mother_busi = o_stcomm.mother_busi;
    mservice = o_stcomm.mservice;
    
    if (icheck_busi[0]=='0')
    {
    	cdiscount2 = (long)mother_busi;
    }	
    else if ((icheck_busi[0]=='1')||(icheck_busi[0]=='3'))
    {
    	if (icheck_busi[0]=='1'){
    		cdiscount2 = (long)mother_busi ;
    	}else{
    		cdiscount2 = (long)mother_busi + (long)mservice;
    	}	
    }
    else if (icheck_busi[0]=='2')
    {
    	cdiscount2 = (long)mother_busi + (long)mservice;
    }
    /* Ū��cmn144(�G�~��) end */
    

    
    mprem1 = mprem1-cdiscount1;           /* �@�~�� */
    mprem2 = mprem2-cdiscount2;           /* �G�~�� */
    mbusiness1 = mbusiness1-cdiscount1;   /* �H�@�~���p��*/
     
    strcpy( cmprem1, itoa(mprem1));
    strcpy( cmprem2, itoa(mprem2));
    
    printf("2444---- sTmpIcomp=[%s]ibranch=[%s]sTmpChDate=[%s]sTmpChDate_pay=[%s]\n",sTmpIcomp,ibranch,sTmpChDate,sTmpChDate_pay);
    
    $begin work;
    
    /**********************/
    /**    �������渹    **/
    /**********************/     
    /* �����渹-1�~�� */
    rc = cm_get_serial_num("C1", "RN", sTmpIcomp, ibranch, sTmpChDate, iestimate_ori); 
    /* �����渹-2�~�� */
    rc = cm_get_serial_num("C1", "RN", sTmpIcomp, ibranch, sTmpChDate, iestimate_sug); 
    
    
    /**********************/
    /**    ��ú�ڳ渹    **/
    /**********************/ 

    /* �t�X�|�X�@ú�O��睊�A�s�W����@�ص����b�� modify by 061476 108.11.19 (1070518005_SC1) */
    /* ú�ڳ渹-- 1�~���K�Q�ө� */
    strcpy(F_type,"6075");
    rc = cm_get_va_num(F_type, "0", "0", sTmpChDate_pay, mprem1, itransno_ori, itransno_ori_007, itransno_ori_008, itransno_ori_009, itransno_ori_atm, itransno_ori_013);
    
    
    /* ú�ڳ渹-- 2�~���K�Q�ө��A35���ؤ�����2�~��ú�ڳ渹 */    
    if(strcmp(icar_type,"35") != 0)
    {
        strcpy(F_type,"6075");
        rc = cm_get_va_num(F_type, "0", "0", sTmpChDate_pay, mprem2, itransno_sug, itransno_sug_007, itransno_sug_008, itransno_sug_009, itransno_sug_atm, itransno_sug_013);	
    }
    else
    {
    	mprem2 = mprem1;
    	strcpy(itransno_sug," ");
    	strcpy(itransno_sug_007," ");
    	strcpy(itransno_sug_008," ");
    	strcpy(itransno_sug_009," ");
    	strcpy(itransno_sug_atm," ");
    	strcpy(itransno_sug_013," ");
    	strcpy(dend2,dend);
    	fuw_status_sug=505;          /*35���ث�ĳ��O�զX�f�֥N�X��505*/

    }

    /*******************************/
    /**    �g�J cm_pre_receive    **/
    /*******************************/
    
    printf("2465--rc=[%d] mprem2 = [%d], iestimate_sug=[%s] itransno_sug=[%s]\n",rc, mprem2, iestimate_sug,itransno_sug);
    /* --------------------------------------------------------------------- */
    printf("sIengine=[%s]\n",sIengine);
    printf("== 2468: start insert cm_pre_receive  �@�~��(���O�զX) \n");
    /* �@�~��(���O�զX) */
    /* ��������²�T */
    $insert into cm_pre_receive
        (iins_cat, ipre_rcv, iins_kind, iins_kind_ply, ftype, 
         ipre_end, iassured, nassured, iapplicant, napplicant,
         itag, iengine, deffect, paydate, mprem,
         isub, iofficer, ileader, iquota, icomm_obj,
         iroute, fcommit, ientry, dentry, isys,
         igroup, fstatus, iupdate, dupdate, ipolicy1,
         ipolicy2, iendorse, icard, dprint, dprint_rcv,
         iedr_return, ftype_pol, ftype_sp, dbegin, dend, fsend_msg, 
         mobile_phone, ilast_policy) 
     values
        ('C', $iestimate_ori, '1', 'C1', 'P',  
         ' ', $ilicense, $s_nassured, $iapplicant, $napplicant,  
         $itag, $sIengine, $dbegin, $paydate, $mprem1,  
         $isub, $sIofficer, $sIleader, $sIquota, $icomm_obj,   
         $sIroute, 'N', $UserID, current, '4', 
         ' ', 10, 'car326', current, ' ',  
         ' ', ' ', ' ', '', current,   
         '9', 'SP', '01', $dbegin, $dend, 'N', 
         ' ', $sIpolicy);
    
    printf("== 2490: start insert cm_pre_receive   �G�~��(��ĳ��O�զX) \n");     
    /* �G�~��(��ĳ��O�զX) */
    $insert into cm_pre_receive
        (iins_cat, ipre_rcv, iins_kind, iins_kind_ply, ftype, 
         ipre_end, iassured, nassured, iapplicant, napplicant,
         itag, iengine, deffect, paydate, mprem,
         isub, iofficer, ileader, iquota, icomm_obj,
         iroute, fcommit, ientry, dentry, isys,
         igroup, fstatus, iupdate, dupdate, ipolicy1,
         ipolicy2, iendorse, icard, dprint, dprint_rcv,
         iedr_return, ftype_pol, ftype_sp, dbegin, dend, fsend_msg, 
         mobile_phone, ilast_policy) 
     values
        ('C', $iestimate_sug, '1', 'C1', 'P',  
         ' ', $ilicense, $s_nassured, $iapplicant, $napplicant,  
         $itag, $sIengine, $dbegin, $paydate, $mprem2,  
         $isub, $sIofficer, $sIleader, $sIquota, $icomm_obj,   
         $sIroute, 'N', $UserID, current, '5', 
         ' ', 10, 'car326', current, ' ',  
         ' ', ' ', ' ', '', current,   
         '9', 'SP', '01', $dbegin, $dend2, 'N', 
         ' ', $sIpolicy);
         
         
    /****************************/
    /**    �g�J ao_rcv_type    **/
    /****************************/
   
    /* �@�~�� */
    printf("== 2514: start insert ao_rcv_type  �@�~��(���O�զX) \n");
    $INSERT INTO ao_rcv_type 
        (data_type, iyear, trcv, trcv_main, tseq, 
         ipolicy1, ipolicy2, iendorse, ipre_end, times, 
         icard, ipre_rcv, mprem, iassured, iassured_ext, 
         nassured, userid, paydate, paydate_ext, isub, 
         ibroker, iofficer, insure_type, iins_kind, dpay) 
     VALUES 
        ('3', $iyear, $itransno_ori, $itransno_ori, '1',
         ' ', ' ', ' ', ' ', 0,  
         ' ', $iestimate_ori, $mprem1, $ilicense, ' ',
         $s_nassured, $UserID, $paydate, $dbegin, $isub,
         $icomm_obj, $sIofficer, 'C', '1', '');
    
    /* �G�~�� */
    if(strcmp(icar_type,"35") != 0)
    {
        printf("== 2528: start insert ao_rcv_type  �G�~��\n");
        $INSERT INTO ao_rcv_type 
            (data_type, iyear, trcv, trcv_main, tseq, 
             ipolicy1, ipolicy2, iendorse, ipre_end, times, 
             icard, ipre_rcv, mprem, iassured, iassured_ext, 
             nassured, userid, paydate, paydate_ext, isub, 
             ibroker, iofficer, insure_type, iins_kind, dpay) 
         VALUES 
            ('3', $iyear, $itransno_sug, $itransno_sug, '1',
             ' ', ' ', ' ', ' ', 0,  
             ' ', $iestimate_sug, $mprem2, $ilicense, ' ',
             $s_nassured, $UserID, $paydate, $dbegin, $isub,
             $icomm_obj, $sIofficer, 'C', '1', '');
    }
    
    /*****************************/
    /**    update policy_302    **/
    /*****************************/
  
    printf("== 2542: update policy_302\n"); 
    
    $update policy_302
        set option = '5', dply_bgn_comp = $dbegin, dply_end_comp = $dend, 
            comp_prem = $mprem1, 
            iofficer = $sIofficer, nname = $sNleader, mbusiness = $mbusiness1,
            v_prem = 0, v_ori_prem = 0, tot_prem = 0, mdiscount = 0, 
            iupdate = $UserID, dupdate = current, 
            iestimate_ori = $iestimate_ori, iestimate_sug = $iestimate_sug,
            itransno_ori = $itransno_ori,  itransno_sug = $itransno_sug,
            fuw_status_ori = 500, fuw_status_sug = $fuw_status_sug, 
            mcomp_prem_sug = $mprem2, 
            frenew_type = '4', itransno_sug_atm = $itransno_sug_atm, 
            itransno_ori_atm = $itransno_ori_atm, 
            itransno_sug_post = ' ',  itransno_ori_post = ' ',
            itransno_ori_007 = $itransno_ori_007, itransno_ori_008 = $itransno_ori_008,
            itransno_ori_009 = $itransno_ori_009, itransno_sug_007 = $itransno_sug_007,
            itransno_sug_008 = $itransno_sug_008, itransno_sug_009 = $itransno_sug_009,
            itransno_ori_013 = $itransno_ori_013, itransno_sug_013 = $itransno_sug_013,
            ilicense = $ilicense, nassured = $s_nassured, aassured_zip = $aassured_zip,
            aassured = $aassured, dbirth = $dbirth, fsex = $fsex, fmarriage = $fmarriage,
            fassured = $fassured, iemail = $iemail, itel = $bitel, tphone_con = $itel_night,
            imovephone = $mobil_phone, iassured_cntry = $iassured_cntry, 
            foccup = $foccup, noccup = $noccup, ndeputy_assured = $ndeputy_assured,
            nuser = $nuser, nbenef = $nbenef, itag = $itag, 
            tmobile_eply = $tmobile_eply, aemail_eply = $aemail_eply,
            iapplicant = $iapplicant, napplicant = $napplicant, apayment_zip = $apayment_zip,
            apayment = $apayment, dbirth_appl = $dbirth_appl, fsex_appl = $fsex_appl,
            fapplicant = $fapplicant, aemail_appl = $aemail_appl, itel_appl = $itel_appl, 
            tmobile_appl = $tmobile_appl, iapplicant_cntry = $iapplicant_cntry,
            applicant_foccup = $applicant_foccup, applicant_noccup = $applicant_noccup,
            ndeputy_appl = $ndeputy_appl, nrelation_appl = $nrelation_appl
      where ipolicy = $sIpolicy;    	

    
    /*********************************/
    /**    delete �D�j���I���I��    **/
    /*********************************/
    
    $delete from ply_ins_type_302 where ipolicy = $sIpolicy and iins_type <> '21';
    
    
    /***********************************/
    /**    update ply_ins_type_302    **/
    /***********************************/
    
    $update ply_ins_type_302
        set minjured_cover = $injured_cover_comp,
            mdeath_cover = $death_cover_comp,
            mdamage_cover = $damage_cover_comp,
            mprem = $mprem2 + $cdiscount2,
            mins_premium = $mprem2,
            drate_ym = $drate_ym,
            ori_inj_cover = $injured_cover_comp,
            ori_dea_cover = $death_cover_comp,
            ori_dam_cover = $damage_cover_comp,
            ori_premium = $mprem1
     where ipolicy = $sIpolicy and iins_type = '21';    
    $commit work;
    
    return SUCCESS;
     
errexit :
    printf("upd302_JB: SQLCODE:[%d]\n",SQLCODE);
    strcpy(sMsg,"�^�gpolicy_302, cm_pre_receive���� (upd302_JB) !!");
    $ROLLBACK WORK;
    return SQLCODE;  

}
long ca3262_build()
{
    $char   stmt[4096];
    $char   ibig_branch[21],ibig_office[15],nname[41],itel[15],nassured[121];
    $char   ncar_type[17],ipro_year[5];
    $char   iissue_ym[7],itag[CA_TAG_NUM],nbrand_abbr[17],iengine[CA_ENGINE_NUM],fpt[2];
    $long   tot_prem,v_prem;
    $double qcylinder;  /* �Ʈ�q�X�ܤp���I2�� (1080902001_SC3) */
    $double qpt;
    $char   dply_begin[11],dply_end[11];
    $char   xiofficer[11],ipolicy[21];
    $char   ibig_comp[2],ibig_sales[11],bibig_office[10];
    $char   bnname[11],icar_type[3],fcard_class[2];
    $char   sTmp[200],sTmp1[200],file0[101],Tmp1[41];
    $char   irelative_ply[21];
    $char   sYY[4],sMM[4],sDD[4];
    $char   iquota_tmp[11],ileader_tmp[11];
    $int    rt;
    $char   sSDB[3],sFull[30],prtstr[5000],sApHome[31];
    char    sFilename[51];
    $long   comp_prem;
    $char   tphone_con[21],imovephone[21],iemail[51];
    FILE    *fp0;
    long    rc;
    int     i,fLast;
    $char   xxy[21],No302_ipolicy[21],inext_ply[21];
    long    inext_count,no302_count,icar_count,iIn20days;
    $long   ldply_begin,ldply_end;
    $int    n;
    $char   project_id[8], receiver_email[51], receiver_name[17],content[9000];
    $char   ileader_email[51];
    $char   cc[51], key[51], subject[256],nofficer[11],pre_ileader_tmp[11],
            pre_sFilename[51],pre_nleader[11],nsend[11],isend[11],email_notify[51];        
    $int    mail_count,no_email_count,no_tag_count;
    $char   iroute[21], fcomp_24[2];
    long    tot_count_m   = 0;  /* �޲z�Hemail���        */
    $char   FormFile[N_FILE +1];
     
    /* �Ӹ�B�n add by larry 103.02.19 (1030211003_C1) */
    $char   sNassured[121],sBitel[21],sTphone_con[21],sDbirth[11],sIemail[51];
    
    $WHENEVER SQLERROR GOTO errexit;

    inext_count  = 0; /* �w��O���    */
    no302_count  = 0; /* �L��O��ƥ��*/     
    no_tag_count = 0;
    tot_count_m  = 0; 
    icar_count   = 0;  
    iIn20days    = 0; /*�����_�O20��H�����*/
    
    rt = getApHome(sApHome);
    if (rt < 0) {
          printf("read Config file error!!\n");
          return M_CM_READ_CONFIG_ERR;
    }

    $SELECT kPgNum_Line, nForm_File, iForm_Tp
       INTO $PgLine, $FormFile, $FormTp
       FROM Form
      WHERE ksys_grp="CA" AND kPgmID = 302 ;

    strcpy( FormFile,rtrim(FormFile));
    sprintf_s(OutFile, sizeof OutFile,"%s.tx",outputf);

    /*----- build body -----*/

    rgu_init_report( FormFile,OutFile);

    /* Email */
    lSendDate   = cm_ymd_cdate(dSendDate);
    /* create temp table */
    $create temp table temp1
    (		  
        project_id     char(7) not null,
        mail_date      date,
        receiver_email char(50),
        receiver_name  varchar(16) default ' ',
        cc             varchar(50) default ' ',
        content        char(9000),
        key            varchar(50) default ' ',
        mail_count     smallint ,
        subject        varchar(255)  default ' ',
        nattachment    varchar(100) default ' '
    ) with no log ;  


    sprintf_s(sTmp, sizeof sTmp,"�� ��J��ơG%d ��\n",read_count);
    rgu_put_body_string(1,sTmp,1);max_count++;
    rgu_put_body(1); max_count++;
			 	     
     
    /* ����ĳ��O���j��O�� */
    sprintf_s(stmt, sizeof stmt,"SELECT count(*) FROM %s WHERE %s %s",
                 " reject_policy ",
                 " ipolicy = ? ",
                 " AND fins_grp = '4'");
    $PREPARE reject_ply FROM $stmt;

    sprintf_s(stmt, sizeof stmt, " SELECT nname,ileader   "
                    " FROM officer  "
                    "WHERE iofficer = (select ileader from officer where iofficer = ?)");
    $PREPARE prep2 FROM $stmt;


    rgu_put_body_string(1," ",1);
    rgu_put_body(1); max_count++;
                
 
    sprintf_s(stmt, sizeof stmt," SELECT %s %s %s %s %s %s %s %s %s %s %s FROM %s WHERE %s %s %s %s %s %s ",
                 " UNIQUE a.ibig_branch, a.ibig_office, a.nname, a.itel,",
                 " trim(b.nassured), b.aassured_zip, b.aassured, trim(b.napplicant), b.apayment_zip, b.apayment, b.itel,",
                 " to_char(dbirth,'%Y')::integer - 1911 || '/' || to_char(dbirth,'%m')|| '/'||to_char(dbirth,'%d'),",
                 " b.fsex, b.fmarriage, b.ncar_type, b.ipro_year,",
                 " to_char(b.dissue,'%Y')::integer - 1911 || '/' || to_char(b.dissue,'%m'),",
                 " nvl(b.itag,' '), b.nbrand_abbr, b.qcylinder, b.iengine,",
                 " b.qpt, b.fpt, b.dply_begin, b.dply_end, e.nname ,b.irelative_ply,",
                 " b.iofficer, b.ipolicy, b.ibig_comp, b.ibig_office, b.ibig_sales,",
                 " b.icar_type ,b.fcard_class,",
                 " b.ilicense ,b.v_prem ,b.tot_prem  ,b.iquota ,e.ileader, b.comp_prem,",
                 " b.tphone_con,b.imovephone,b.iemail,b.fassured, b.dply_begin, b.dply_end,d.nname,b.iroute, b.fcomp_24 ",
                 " ca_big_office a,policy_302f b,officer d,officer e ",
                 " a.ibig_comp = b.iquota[1,4] || '00' ",
                 " AND a.fclass = '3' ",
                 " AND b.iofficer = d.iofficer ",
                 " AND b.ileader  = e.iofficer ",
                 " AND b.ipolicy IN (SELECT c.ipolicy FROM comp_temp c) ",
                 " ORDER BY b.iquota,e.ileader,b.iofficer,b.ilicense ");

    printf("2773:stmt[%s]\n", stmt);


    strcpy(project_id    ,"CAR326");
    strcpy(pre_ileader_tmp," ");    
    fLast = 0;	
    

    $PREPARE vyid02 FROM $stmt;
    $DECLARE vy_cur2 CURSOR with hold FOR vyid02;
    $OPEN vy_cur2;  /* USING $iyy,$imm; */
    for(;;)
    {
        $FETCH vy_cur2
          INTO $ibig_branch, $ibig_office, $nname, $itel,
               $nassured, $aassured_zip, $aassured, $napplicant, $apayment_zip, $apayment, $bitel,
               $dbirth, $fsex, $fmarriage, $ncar_type, $ipro_year,
               $iissue_ym, $itag, $nbrand_abbr, $qcylinder, $iengine,
               $qpt, $fpt, $dply_begin, $dply_end, $bnname , $irelative_ply,
               $xiofficer, $ipolicy, $ibig_comp, $bibig_office, $ibig_sales,
               $icar_type, $fcard_class,
               $ilicense, $v_prem, $tot_prem, $iquota_tmp, $ileader_tmp, $comp_prem,
               $tphone_con,$imovephone,$iemail,$fassured,$ldply_begin,$ldply_end,$nofficer,$iroute,$fcomp_24;
        if (SQLCODE == SQLNOTFOUND){ 

            fLast = 1; 
            goto LAST_ILeader2;                	 
          	
        }
          

        printf("INTO MAIN CUR\n");
        printf("fcard_class[%s]\n",fcard_class);
        printf("ipolicy[%s]\n",ipolicy);

        /* Step1:�ư��D���� */ 
        /* �W�[�H�o�T�����ӡA�G���ư� (1111130009_SC1) */      
        /*if (strcmp(trim(icar_type),"01") != 0 && strcmp(trim(icar_type),"02") != 0 &&
            strcmp(trim(icar_type),"32") != 0 && strcmp(trim(icar_type),"34") != 0 && strcmp(trim(icar_type),"35") != 0) 
        {
	    icar_count++;
	    $DELETE FROM comp_temp WHERE ipolicy= $ipolicy ;
	    printf("�D����[%s]\n",ipolicy);             					   
	    continue;
        }*/

        /* Step2:�ư��D�_�O�W�L20�� */
        if (ldply_begin>lfname20days)
        {
            iIn20days++;
	    $DELETE FROM comp_temp WHERE ipolicy= $ipolicy ; 
	    printf("�D�_�O�W�L20��[%s]\n",ipolicy);            					   
	    continue; 
        }
        
        /***************************/
        /*                         */
        /*  ���s����̷s�O����   */
        /*                         */
        /***************************/  
        /* �W�[�n�Q�O�H������� (1111011002_SC1) */
        strcpy(sSDB,get_car_full_db(ipolicy));
        strcpy(sFull,get_full_dbname(sSDB));
        printf("sFull[%s]\n",sFull);
        
        sprintf_s(stmt, sizeof stmt,
                " SELECT NVL(a.inext_ply,' '),b.iassured,b.nassured,b.aassured_zip,b.aassured,b.dbirth, "
                "        b.fsex,b.fmarriage,b.fassured,b.iemail,b.itel,b.itel_night,b.mobil_phone,  "
                "        b.iassured_cntry,b.foccup,b.noccup,b.ndeputy_assured,  "
                "        b.nuser,b.nbenef,b.itag,a.tmobile_eply,a.aemail_eply,  "
                "        b.iapplicant,b.napplicant,b.apayment_zip,b.apayment,   "
                "        b.dbirth_appl,b.fsex_appl,b.fapplicant,b.aemail_appl,b.itel_appl, "
                "        b.tmobile_appl,b.iapplicant_cntry,b.applicant_foccup,b.applicant_noccup,  "
                "        b.ndeputy_appl,b.nrelation_appl "
                "   FROM %s:ply_relation a,%s:policy b  "
                "  WHERE a.ipolicy = b.ipolicy  "
                "    AND a.ipolicy = '%s' " ,sFull,sFull,ipolicy);
        printf("3271:stmt[%s]\n",stmt);
        $PREPARE pre_ply FROM $stmt;
        $EXECUTE pre_ply 
            INTO $inext_ply,$ilicense,$nassured,$aassured_zip,$aassured,$dbirth,
                 $fsex,$fmarriage,$fassured,$iemail,$bitel,$itel_night,$mobil_phone,
                 $iassured_cntry,$foccup,$noccup,$ndeputy_assured,
                 $nuser,$nbenef,$itag,$tmobile_eply,$aemail_eply,
                 $iapplicant,$napplicant,$apayment_zip,$apayment,
                 $dbirth_appl,$fsex_appl,$fapplicant,$aemail_appl,$itel_appl,
                 $tmobile_appl,$iapplicant_cntry,$applicant_foccup,$applicant_noccup,
                 $ndeputy_appl,$nrelation_appl;            

        /* �Q�O�I�Hemail */          
        strcpy(iemail,trim(iemail));

        
        if (strlen(trim(inext_ply)) > 0) {
	    inext_count++;
	    $DELETE FROM comp_temp WHERE ipolicy= $ipolicy ;             					   
	    continue;
        }

        strcpy(nassured, rtrim(nassured));
        /* 1130308006_C01 �����Q�O�I�H�ٿ� */
        /*if ((strncmp(fassured,"1",1)==0)||(strncmp(fassured,"3",1)==0)||(strncmp(fassured,"5",1)==0)){
            if (fsex[0] == '1')	
                strcat(nassured,"�@����");
            else if (fsex[0] == '2')
                strcat(nassured,"�@�p�j");
        }  	      	   */
        printf("nassured[%s]\n",nassured);

        
        strcpy(bitel,trim(bitel));           /* �Q�O�I�H�q�� => �p���q�� */
        strcpy(dbirth,trim(dbirth));         /* �Q�O�I�H�X�ͦ~��� */
        strcpy(iengine,rtrim(iengine));      /* �������X */ 
        strcpy(tphone_con,trim(tphone_con)); /* �Q�O�I�H�q��(�]) */

        cm_split_ymd_100(cm_from_infdate_100(dply_begin),sYY,sMM,sDD);
          


	/* email �q��*/		  	  
	/* �A�ȤH��(�޲z�H) */
	/*if( ileader_tmp[0] == '6') /* �����޲z�H 
	{*/
	    $EXECUTE prep2 INTO $bnname,$ileader_tmp USING $ileader_tmp;
	/*}*/
	        
	mail_count = 1;
	strcpy(cc ,' ');

	        
	$select trim(email)||'@tmnewa.com.tw' into $ileader_email 
	   from sysdb:v_asempl
	  where empl_no = $ileader_tmp;
	if (SQLCODE == SQLNOTFOUND) strcpy(ileader_email, " ");


	                
	/********* email ���޲z�H *******/
	strcpy(pre_ileader_tmp,rtrim(pre_ileader_tmp));
	strcpy(ileader_tmp,rtrim(ileader_tmp));
	                
	/* �@�Ӻ޲z�H�u�n�@��email�A"�����ɮ�"�t����Ҧ��O����(��email��) */
	if((strcmp(pre_ileader_tmp,ileader_tmp)!=0))
	{
LAST_ILeader2:			      	
	    if (strlen(trim(pre_ileader_tmp))>0){ 
	        /* ���U�@�Ӻ޲z�H���e�A�������e�@�Ӻ޲z�H�nemail�����*/
	        /* LAST_ILeader: �Y���̫�@����ơA�������ܦ������Ӻ޲z�H�nemail����� */
	        printf("Trace -- pre_ileader_tmp = [%s] \n",  pre_ileader_tmp);
	        printf("Trace -- ileader_tmp = [%s] \n",  ileader_tmp);
	        printf("Trace -- ���U�@�Ӻ޲z�H  \n");
	                		
	        $SELECT trim(email)||'@tmnewa.com.tw' into $receiver_email FROM sysdb:v_asempl
	          WHERE empl_no = $pre_ileader_tmp;       /*�޲z�Hemail*/
	                		
	        if (SQLCODE == SQLNOTFOUND){
	            printf("Trace -- v_asempl SQLNOTFOUND  \n");
	            printf("Trace -- ileader_tmp = [%s] \n",  ileader_tmp);
	            if (fLast)
	                break;
	            else	  
	                continue; 
	        }else{			  	  
	            strcpy(pre_nleader , rtrim(pre_nleader));  
	            strcpy(key , rtrim(pre_sFilename));               /*���[�ɮצW��*/
	            strcpy(content , 
	                "<html><body> \n"
	                "�z�n\n"
	                "<p>�˪������H�o�j���I�_�O�ĤT����O�q������(�O���_�O�W�L20��)�C<br>\n"
	                "�q�о��t�q���Ȥ��z��O�A�խY���D����O2�Ӥ뤴����O�ɡA�D�޾����N�t<br>\n"
	                "��H�e�q���A���Ѥ��q��O�����s���A���קK�l�ͧx�Z�A�Чⴤ�Ȥ��pô�ɮġA<br>\n"
	                "���¡I<br>\n"
	                "<p>���p�Ȥᨮ���w���o�A�q�д����Ȥ��z�h�O�@�~�C<br>\n"
	                " ���D�޾����e�U�j��I��T�@�~���߱H�e�q���A�H�e���I��T+2��H�eT��<br>\n"
	                "&nbsp;&nbsp;&nbsp;&nbsp;����O���Ӹ�ơA��T�@�~���ߦ]�ɶ��t�]���A�N�ư��w���o���ӡC</p>\n"
	                "<p>�ӫO���~�Ȧ�F��   �q��</p>\n"
	                "</body></html>  \n"    
	            );
	            strcpy(subject ,"�j���I�_�O�ĤT����O�q������");				  	  	              
	            $insert into temp1 values(			    			  
	            $project_id, $lSendDate, $receiver_email, $pre_nleader, $cc,
	            $content, $key, $mail_count, $subject, $key );			      
	            tot_count_m++;   
	        }  
	                		
	        fclose(fp0);
	    }
	    if (fLast) break;
	                	
	    sprintf_s(Tmp1, sizeof Tmp1,"�j��T��_%s_%s.csv",exedate,ileader_tmp);		         
	    sprintf_s(file0, sizeof file0,"%s/rptftp/car_email/%s",sApHome,Tmp1);
	    sprintf_s(sFilename, sizeof sFilename,Tmp1);
	    printf("Tmp1[%s] file0[%s]\n",Tmp1,file0);
	    fp0=fopen(file0,"w");
	                	
	    strcpy(prtstr,"�j��O�渹");
	    strcat(prtstr,attach_deli);		 
	    strcat(prtstr,"���N�O�渹");
	    strcat(prtstr,attach_deli);		 
	    strcat(prtstr,"���P");
	    strcat(prtstr,attach_deli);		 
	    strcat(prtstr,"�O�I�����");
	    strcat(prtstr,attach_deli);		 
	    strcat(prtstr,"�Q�O�I�H�m�W");
	    strcat(prtstr,attach_deli);		 
	    strcat(prtstr,"�X�ͦ~���");
	    strcat(prtstr,attach_deli);		 
	    strcat(prtstr,"E-MAIL");
	    strcat(prtstr,attach_deli);		 
	    strcat(prtstr,"�q�ܡ]��^");
	    strcat(prtstr,attach_deli);		 
	    strcat(prtstr,"�q�ܡ]�]�^");
	    strcat(prtstr,attach_deli);		 
	    strcat(prtstr,"�g��N��");
	    strcat(prtstr,attach_deli);		 
	    strcat(prtstr,"�g��W��");         
				
	    fprintf(fp0,"%s\n",prtstr);
	    printf("prtstr[%s]\n",prtstr);    		          
	}
		        
	/* �Ӹ�B�n (nassured,dbirth,bitel,tphone_con) add by larry 103.02.19 (1030211003_C1) */
	if ((strncmp(fassured,"1",1)==0)||(strncmp(fassured,"3",1)==0)||(strncmp(fassured,"5",1)==0))
	{	
	    strcpy(sNassured,substring(nassured,1,2));
	    strcat(sNassured,"�ݢ�");
	    strcpy(sDbirth,substring(dbirth,1,3));
	    strcat(sDbirth,"**");
	    strcat(sDbirth,substring(dbirth,6,5));
	    strcpy(sIemail,substring(iemail,1,3));
	    strcat(sIemail,"@@@@");
	    strcat(sIemail,substring(iemail,8,43));
	    strcpy(sBitel,substring(bitel,1,3));
	    strcat(sBitel,"XXXX");
	    strcat(sBitel,substring(bitel,8,13));
	    strcpy(sTphone_con,substring(tphone_con,1,3));
	    strcat(sTphone_con,"XXXX");
	    strcat(sTphone_con,substring(tphone_con,8,13));	                 		               
	}
	else
	{
	    strcpy(sNassured,nassured);
	    strcpy(sDbirth,dbirth);
	    strcpy(sIemail,iemail);
	    strcpy(sBitel,bitel);
	    strcpy(sTphone_con,tphone_con);
	}
		        
	strcpy(prtstr,ipolicy);            /* �j��O�渹 */
	strcat(prtstr,attach_deli);
	if (strlen(rtrim(irelative_ply))>0){
	    strcat(prtstr,rtrim(irelative_ply));     
	}else{
	    strcat(prtstr," ");          /* ���N�O�渹 */
	}	             
	strcat(prtstr,attach_deli);	          
	strcat(prtstr,trim(itag));         /* ���P       */
	strcat(prtstr,attach_deli);
	strcat(prtstr,rtrim(sYY));         /* �O�I����� */
	strcat(prtstr,"/");
	strcat(prtstr,rtrim(sMM));
	strcat(prtstr,"/");
	strcat(prtstr,rtrim(sDD));
	strcat(prtstr,attach_deli);
	strcat(prtstr,sNassured);          /* �Q�O�I�H�m�W*/ 
	strcat(prtstr,attach_deli);	
	strcat(prtstr,trim(sDbirth));      /* �X�ͦ~���  */
	strcat(prtstr,attach_deli);	
	strcat(prtstr,sIemail);            /* E-MAIL      */
	strcat(prtstr,attach_deli);
	strcat(prtstr,trim(sBitel));       /* �q�ܡ]��^  */
	strcat(prtstr,attach_deli);                
	strcat(prtstr,trim(sTphone_con));  /* �q�ܡ]�]�^  */
	strcat(prtstr,attach_deli);     
	strcat(prtstr,xiofficer);          /* �g��N��    */    
	strcat(prtstr,attach_deli);		 
	strcat(prtstr,nofficer);           /* �g��W��    */  	
		        
	printf("Trace -- prtstr = [%s] \n",  prtstr); 
	fprintf(fp0,"%s\n",prtstr);
		        
	strcpy(pre_ileader_tmp,ileader_tmp);	
	strcpy(pre_sFilename,sFilename);	 
	strcpy(pre_nleader,bnname);	       	          
	$DELETE FROM comp_temp WHERE ipolicy= $ipolicy ;     
	continue;
	
		    

     }
     $CLOSE vy_cur2;
     $FREE  vy_cur2;
     
    /*sprintf_s(sTmp, sizeof sTmp,"--- �ư��D�����A�@%d��\n",icar_count);
    rgu_put_body_string(1,sTmp,1);max_count++;
    rgu_put_body(1); max_count++;*/	

    sprintf_s(sTmp, sizeof sTmp,"�ư��_�O20��H���A�@%d��\n",iIn20days);
    rgu_put_body_string(1,sTmp,1);max_count++;
    rgu_put_body(1); max_count++;
    	 

    if (inext_count>0){     	     	
	sprintf_s(sTmp, sizeof sTmp,"�ư��w��O�A�@%d��\n",inext_count);
	rgu_put_body_string(1,sTmp,1);max_count++;
	rgu_put_body(1); max_count++;	      
    }

    $DECLARE  cur_No_ply302_2 CURSOR for
      SELECT ipolicy 
	FROM comp_temp;
    $OPEN  cur_No_ply302_2;
    while(1)
    {
        $FETCH cur_No_ply302_2 INTO $No302_ipolicy;
	if(SQLCODE == SQLNOTFOUND){
	    break;
        }else{
	    /*sReason[0] = '\0';
	    printf("-------No302_ipolicy[%s]\n",No302_ipolicy);  
	    GetNo302Reason(No302_ipolicy);
       	 
	    printf("sReason[%s]\n",sReason);  
	    sprintf_s(sTmp, sizeof sTmp," �O�渹�G[%s] �L��O���( ��]�G%s )\n",No302_ipolicy,sReason);
	    printf("sTmp[%s]\n",sTmp);  
	    rgu_put_body_string(1,sTmp,1);
	    rgu_put_body(1); max_count++; */        	 
	    no302_count++;
        }
    }
    $CLOSE cur_No_ply302_2;
    printf("=== end cur_No_ply302_2 ===\n");   
	
    if (no302_count>0){     
		     	
	printf("No302_ipolicy [%s]\n", No302_ipolicy );
	sprintf_s(sTmp, sizeof sTmp,"�ư��L��O��ơA�@%d��\n",no302_count);
	rgu_put_body_string(1,sTmp,1);max_count++;
	rgu_put_body(1); max_count++;	      
		
		   
    }
	 
    rgu_put_body_string(1," ",1);
    rgu_put_body(1); max_count++;

    sprintf_s(sTmp, sizeof sTmp,"�� �ݳq���޲z�H��ơG%d ��\n",read_count-icar_count-iIn20days-inext_count-no302_count );
    rgu_put_body_string(1,sTmp,1);
    rgu_put_body(1); max_count++; 


    /* �W�[�q���ӫO���H�� (1110127007_SC1_�s�W����{��car326�H�o�����_�O�ĤT���޲z�q��E-MAIL�H�o�q���H) */
     
    $declare cur_notify2 cursor for
      select DISTINCT detail2 INTO $isend 
        from car_code
       where kind = 'RC' and detail = '0001'
       order by detail2;
    $open  cur_notify2;  
     
    while (1)
    {
        $fetch cur_notify2;
     	
     	if (SQLCODE==SQLNOTFOUND) break;
     	
     	$SELECT nname[1,10] INTO $nsend
     	   FROM officer
     	  WHERE iofficer = $isend;
     	     
     	$SELECT trim(email)||'@tmnewa.com.tw' INTO $email_notify
           FROM asempl
          WHERE empl_no = $isend;


     	if (strlen(trim(isend))>0)
     	{
     			
     	       strcpy(subject ,"car326�j���I�_�O�ĤT���޲z�q��E-MAIL�w�󤵤�H�o");
     	       sprintf_s(content, sizeof content ,"<html><body><p>\n"
         			"�� �H�eemail�G%d ��<br>\n"
         			"</body></html>\n",tot_count_m );
               strcpy(key," "); strcpy(cc ," "); 
               
               $insert into temp1 values(
         	$project_id, $lSendDate, $email_notify, $nsend, $cc,
         	$content, $key, 0, $subject, $key );

        }
    } 
    $CLOSE cur_notify2;
    $FREE  cur_notify2;



    printf("Trace -- insert_to_batchemail()\n");
    rc = insert_to_batchemail("temp1", 0 , v_sMsg);	 	
    printf("Trace -- tot_count_m = [%ld] \n", tot_count_m);
    sprintf_s(sTmp, sizeof sTmp,"�� �H�eemail�G%d ��\n", tot_count_m);
    rgu_put_body_string(1,sTmp,1);
    rgu_put_body(1); max_count++;  	

     
    return M_CM_OK;

errexit:
    printf("car326_2:sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    $WHENEVER SQLERROR CONTINUE;     /* reset error handling */
    EWRITE(UserID,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}