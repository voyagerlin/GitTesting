/***********************************************************************
 *   PROGRAM ID    : ca102q02s.ec                                      *
 *   PROGRAM NAME  : �Ȥ��ƺ޲z��J�ζץX�@�~                        *
 *   AUTHOR        : Jessie                                            *
 *   DATE WRITTEN  : 2011/06/30                                        *
 ***********************************************************************
 *                             MODIFICATION LOG                        *
 *                                                                     *
 *   DATE         SE                         DESCRIPTION               *
 * --------  -------------  ----------------------------------------   *
 *                                                                     *
 **********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
#include <string.h>
#include "api_xsrv.h"
#include "sql.h"
#include "print.h"
#include "sqlfatal.h"
#include "globdata.h"
#include "safeclib.h"
/*--------------------------------------------------------------------*/
char	opt[1];
$char	h_freason[2];
$char	h_dbgn[11],h_dend[11];
$char	h_itag[13],h_iengine[26],h_ibody[26],h_ilicense[11],h_nassured[121];
DBinfo  *list;
int     count_db,i,rc;
char    msgbuf[1024];
char	sdata[8][255];
$char	DBName[5];

int     flen,cnt,cnt1;
FILE    *fp,*fp1;
char    sApHome[30];
char	filename[50],filename1[50];
char	outputf[N_FILE+1];
$char	userid[11];
$char   stmt_tmp1[1024],stmt_tmp2[1024];
/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{    
    batchinit();
    strcpy(DBName,   isNULLstr(argv[1]));
    strcpy(userid,   isNULLstr(argv[2]));
    strcpy(opt,	     isNULLstr(argv[3])); /* I:�פJ E:�ץX */
    strcpy(h_freason,isNULLstr(argv[4]));
    strcpy(h_itag,   isNULLstr(argv[5]));
    strcpy(h_iengine,isNULLstr(argv[6]));
    strcpy(h_ibody,  isNULLstr(argv[7]));
    strcpy(h_ilicense,isNULLstr(argv[8]));
    strcpy(h_nassured,isNULLstr(argv[9]));
    strcpy(h_dbgn,   isNULLstr(argv[10]));
    strcpy(h_dend,   isNULLstr(argv[11]));
    strcpy(outputf,  isNULLstr(argv[12]));

    rc=car102_get_db();
    if ( rc != M_CM_OK) return rc;

    if (opt[0]=='I') {		/* �פJ */
	rc=car102_prepare();
	if ( rc != M_CM_OK) return rc;

	rc=car102_read_file();
	if (rc != M_CM_OK) { 
	    EWRITE(userid, rc, msgbuf);
            return rc;
	}

	rc=car102_import();
	if (rc != M_CM_OK) { 
	    EWRITE(userid, rc, msgbuf);
            return rc;
	}
    }
    else { 			/* �ץX */
	strcpy(h_dbgn,cm_to_infdate(h_dbgn));
	strcpy(h_dend,cm_to_infdate(h_dend));
	rc=car102_export();
	if (rc != M_CM_OK) { 
	    EWRITE(userid, rc, msgbuf);
            return rc;
	}
    }

    return rc;
}
/*--------------------------------------------------------------------*/
long car102_get_db()
{
int rc;

    if (db_select(DBName) == FALSE)
    {
        EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
        return M_CM_DB_NOTOPEN;
    }
    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }

    return M_CM_OK;
}
/*--------------------------------------------------------------------*/
long car102_prepare()
{
    $whenever sqlerror goto errexit;
    
    sprintf_s(stmt_tmp1, sizeof stmt_tmp1, "create temp table car102 "
		"(nassured 	varchar(120), "
    	"ilicense 	char(10), "
    	"itag 		char(%d), "
    	"iengine 	varchar(%d), "
    	"ibody 		varchar(%d), "
    	"freason 	char(1), "
    	"remark 	varchar(254), "
    	"dexpire 	date) "
	 "with no log; ",CA_TAG_NUM-1,CA_ENGINE_NUM-1,CA_BODY_NUM-1);
    $PREPARE stmp1 FROM $stmt_tmp1;
    $EXECUTE stmp1;
    
    sprintf_s(stmt_tmp2, sizeof stmt_tmp2, "create temp table car102_err"
		"(errmsg		char(20),"
		"nassured 	varchar(120),"
    	"ilicense 	char(10),"
    	"itag 		char(%d),"
    	"iengine 	varchar(%d),"
    	"ibody 		varchar(%d),"
    	"freason 	char(1),"
    	"remark 	varchar(254),"
    	"dexpire 	char(10))"
	 "with no log;",CA_TAG_NUM-1,CA_ENGINE_NUM-1,CA_BODY_NUM-1);
    $PREPARE stmp2 FROM $stmt_tmp2;
    $EXECUTE stmp2;

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car102_read_file()
{
char   *bp;
int    rc,j,k,m,n;

    /* Ū���ɮ� */
    sprintf_s(filename, sizeof filename, "%s/dat/car/car102_%s.txt",sApHome,userid);
    flen=1024;
    if ((fp=fopen(filename,"r"))==NULL) {
       sprintf_s(msgbuf, sizeof msgbuf, "%s �ɮ׶}�ҥ���",filename);
       EWRITE(userid,FALSE,msgbuf);
       return FALSE;
    }
    if ((bp=malloc(flen))==NULL) {
       sprintf_s(msgbuf, sizeof msgbuf, "System malloc failed !");
       EWRITE(userid,FALSE,msgbuf);
	   free(bp);
       return FALSE;
    }

    cnt=cnt1=0;
    for (i=0;(feof(fp)==0);i++) {
        memset(bp,0x00,flen);
        fgets(bp,flen,fp);
        if (bp[0]==0x00)
           break;
        if (strlen(trim(bp))<10)
           break;
        for(j=0;j<8;j++)
            sdata[j][0]='\0';
        k=m=n=0;
        for (j=0;j<flen;j++) {
            if (bp[j]=='\t' || bp[j]=='\0' || bp[j]=='\n') {
                strncpy(sdata[k],bp+m,j-m);
                sdata[k][j-m]='\0';
                m=j+1;
                k++;
            }
            if (bp[j]=='\n')
                break;
            if (k > 8) break;
        }      
        printf("sdata[%s][%s][%s]\n",sdata[0],sdata[3],sdata[5]);
        cnt++;
        
        rc = car102_insert_tmp();
        if (rc != M_CM_OK)
            return rc; 
    }
    fclose(fp);

    return M_CM_OK;
}
/*--------------------------------------------------------------------*/
long car102_import()
{
$int	qcnt = 0,sql_code;
$char	stmt[1024];

    $whenever sqlerror goto errexit;

    /* �ˮָ�� */

    $insert into car102_err
     select 'Key�ȭ���',a.*
       from car102 a,reject_client b
      where a.itag     = b.itag
	and a.iengine  = b.iengine
	and a.ibody    = b.ibody
	and a.ilicense = b.ilicense
        and a.nassured = b.nassured
	and a.freason  = b.freason;

    $insert into car102_err
	(errmsg,nassured,ilicense,itag,iengine,ibody,freason)
     select '�פJ��ƭ���',nassured,ilicense,
	    itag,iengine,ibody,freason
       from car102
      group by 2,3,4,5,6,7
      having count(*) > 1;

    $insert into car102_err
     select '���O���~',*
       from car102
      where freason < '1' or freason > '9';

    $select count(*) 
       into $qcnt
       from car102_err;

    if (qcnt > 0) {
	rc = car102_err_rpt();
	return rc;
    }

    $begin work;

    sprintf_s(stmt, sizeof stmt, "insert into reject_client "
	"(nassured,ilicense,itag,iengine,ibody,freason,remark,dexpire, "
	"icreate,dcreate,iupdate,dupdate) "
     	"select *,'%s',today,'%s',current from car102 ",userid,userid);
printf("stmt[%s]\n",stmt);
    $prepare pre_ins from $stmt;
    $execute pre_ins;
    printf("SQLCODE[%d]\n",SQLCODE);
    $commit work;

    rc = car102_imp_rpt();
    if (rc != M_CM_OK) return rc;

    return M_CM_OK;

errexit:
    sql_code = SQLCODE;
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    $whenever sqlerror continue;
    $rollback work; 
    return sql_code;
}
/*--------------------------------------------------------------------*/
long car102_insert_tmp()
{
$char 	itag[CA_TAG_NUM],iengine[CA_ENGINE_NUM],ibody[CA_BODY_NUM],ilicense[11],nassured[121];
$char	freason[2],remark[255],dexpire[11],sql_str[11];
$int	qcnt,fspace;
   
    strcpy(itag         ,trim(sdata[0]));
    strcpy(iengine      ,trim(sdata[1]));
    strcpy(ibody        ,trim(sdata[2]));
    strcpy(ilicense     ,trim(sdata[3]));
    strcpy(nassured     ,trim(sdata[4]));
    strcpy(freason      ,trim(sdata[5]));
    strcpy(remark       ,trim(sdata[6]));
    strcpy(dexpire      ,trim(sdata[7]));
    fspace=1;
    if (itag[0]=='\0') 	   strcpy(itag," ");
    else fspace = 0;
    if (iengine[0]=='\0')  strcpy(iengine," ");
    else fspace = 0;
    if (ibody[0]=='\0')	   strcpy(ibody," ");
    else fspace = 0;
    if (ilicense[0]=='\0') strcpy(ilicense," ");
    else fspace = 0;
    if (nassured[0]=='\0') strcpy(nassured," ");
    else fspace = 0;
    if (freason[0]=='\0')  strcpy(freason," ");
    if (remark[0]=='\0')   strcpy(remark," ");
    
    if (fspace) {
	$insert into car102_err
     	values ('Key�ȬҬ��ť�',$nassured,$ilicense,$itag,$iengine,$ibody,
	        $freason,$remark,$dexpire);
    }
    else {
    	$insert into car102
     	values ($nassured,$ilicense,$itag,$iengine,$ibody,
	        $freason,$remark,$dexpire);
    	if (SQLCODE==-1206 ||SQLCODE==-1204) {
	    $insert into car102_err
     	    values ('����榡���~',$nassured,$ilicense,$itag,$iengine,
		$ibody,$freason,$remark,$dexpire);
    	}
	else if (SQLCODE!=0) {
	    strcpy(sql_str,itoa(SQLCODE));
	    $insert into car102_err
     	    values ($sql_str,$nassured,$ilicense,$itag,$iengine,
		$ibody,$freason,$remark,$dexpire);
    	}
    }

    return M_CM_OK;

}
/*--------------------------------------------------------------------*/
long car102_err_rpt()
{
int     rc;
char    sfilename[81],stitle[1024],stmt[1024];

    $whenever sqlerror goto errexit;

    strcpy(sfilename,"�Ȥ��ƺ޲z�פJ���~�M��");
    strcpy(stitle,"�{���N��:CAR102\t");
    strcat(stitle,sfilename);
    strcat(stitle,"\t\t\t\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");
    strcat(sfilename,"[CAR102]");

    strcat(stitle,"\t���~��]");
    strcat(stitle,"\t���P���X\t�������X\t�������X\t�r�Ӹ��X\t");
    strcat(stitle,"�m�W\t���O\t��]\t�ˮִ���\t");

    strcpy(stmt,"select errmsg,itag,iengine,ibody,ilicense,"
		"       nassured,freason,remark,dexpire"
		"  from car102_err order by 1,2,3");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);

    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf, " %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car102_imp_rpt()
{
int     rc;
char    sfilename[81],stitle[1024],stmt[1024];

    $whenever sqlerror goto errexit;

    strcpy(sfilename,"�Ȥ��ƺ޲z�פJ���ӲM��");
    strcpy(stitle,"�{���N��:CAR102\t");
    strcat(stitle,sfilename);
    strcat(stitle,"\t\t\t\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");
    strcat(sfilename,"[CAR102]");

    strcat(stitle,"\t���P���X\t�������X\t�������X\t�r�Ӹ��X\t");
    strcat(stitle,"�m�W\t���O\t��]\t�ˮִ���\t");
    strcat(stitle,"���ɤH��\t���ɤ��\t���ʤH��\t���ʤ��\t");

    strcpy(stmt,"select a.itag,a.iengine,a.ibody,a.ilicense,"
		"       a.nassured,a.freason,a.remark,a.dexpire,"
		"	a.icreate,a.dcreate,a.iupdate,"
		"	to_char(a.dupdate,'%Y-%m-%d %H:%M')"
		"  from reject_client a,car102 b "
		" where a.itag = b.itag and a.iengine= b.iengine"
		"   and a.ibody = b.ibody and a.ilicense = b.ilicense"
		"   and a.nassured = b.nassured and a.freason = b.freason");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);

    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf, " %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car102_export()
{
int     rc;
char    sfilename[81],stitle[1024],stmt[1024];

    $whenever sqlerror goto errexit;

    strcpy(sfilename,"�Ȥ��ƺ޲z�ץX���Ӫ�");
    strcpy(stitle,"�{���N��:CAR1022\t");
    strcat(stitle,sfilename);
    strcat(stitle,"\t���O:");
    strcat(stitle,h_freason);
    strcat(stitle,"\t���ʤ��:");
    strcat(stitle,h_dbgn);
    strcat(stitle,"��");
    strcat(stitle,h_dend);
    strcat(stitle,"\t\t\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");
    strcat(sfilename,"[CAR102]");

    strcat(stitle,"\t���P���X\t�������X\t�������X\t�r�Ӹ��X\t");
    strcat(stitle,"�m�W\t���O\t��]\t�ˮִ���\t");
    strcat(stitle,"���ɤH��\t���ɤ��\t���ʤH��\t���ʤ��\t");

    sprintf_s(stmt, sizeof stmt, "select a.itag,a.iengine,a.ibody,a.ilicense, "
		"       a.nassured,a.freason,a.remark,a.dexpire, "
		"	(select nname from officer where iofficer "
		"	= a.icreate),a.dcreate, "
		"	(select nname from officer where iofficer "
		"	= a.iupdate),to_char(a.dupdate,'%%Y-%%m-%%d %%H:%%M') "
		"  from reject_client a "
		" where freason matches '%s' "
		"   and date(dupdate) between '%s' and '%s' "
		"   AND itag matches '%s' "
		"   AND iengine matches '%s' "
		"   AND ibody matches '%s' "
		"   AND ilicense matches '%s' "
		"   AND nassured matches '%s' ",
		h_freason,h_dbgn,h_dend,h_itag,h_iengine,h_ibody,h_ilicense,h_nassured);

    rc = unload_file(outputf," ",sfilename,stitle,stmt);

    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf, " %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*---------------------------------------------------------end program*/
