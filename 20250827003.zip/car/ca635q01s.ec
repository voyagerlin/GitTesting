/**********************************************************************/
/*   program id   : ca635q01s.ec                                      */
/*   program name : �O�N�~�ȫȤ�˿�����Ӫ�                        */
/*   date written : 2015/05/06                                        */
/*   date modify  : yyyy/mm/dd                                        */
/*   author       : Larry Liao                                        */                                       
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include "safeclib.h"
#include <math.h>

/****************************************************************************/
$char DBName[05],userid[11],sOption[2];
$char iofficer[11], dendorse_bgn[11], dendorse_end[11];
$char sDendorse_bgn[11], sDendorse_end[11];
$char fcard_class_chk[2],dgroup_chk[2];
char  msgbuf[2048], sApHome[30];
char  v_sMsg[1024], outputf[N_FILE+1];
int   count_db = 0,i;
DBinfo  *list = NULL;
$char stmt_tmp[2048];
/****************************************************************************/
main(argc, argv)
int argc;
char **argv;
{  
	int rc;

	batchinit();
	strcpy(DBName,          isNULLstr(argv[1]));
	strcpy(userid,          isNULLstr(argv[2]));
	strcpy(sOption,         isNULLstr(argv[3]));
	strcpy(iofficer,        isNULLstr(argv[4]));                 
	strcpy(dendorse_bgn,    isNULLstr(argv[5]));
	strcpy(dendorse_end,    isNULLstr(argv[6]));
	strcpy(fcard_class_chk, isNULLstr(argv[7]));
	strcpy(dgroup_chk,      isNULLstr(argv[8]));
	strcpy(outputf,         isNULLstr(argv[9]));
	
	printf("--�g��N��--:[%s] \n", iofficer);
	printf("--�����--:[%s] ~ [%s]\n", dendorse_bgn, dendorse_end);
		
	rc = car635_get_db();
	if (rc != M_CM_OK) {
		EWRITE(userid,rc,msgbuf);
		return rc;
	}
 
  rc = car635_init_data();
  if (rc != M_CM_OK) {
    printf("error on car635_init_data\n");
		EWRITE(userid,rc,"�إ� temp table ���~!");
		return rc;
  }
				
	rc = car635_query_detail();
  if (rc != M_CM_OK) {
    printf("error on car635_query_detail\n");
		EWRITE(userid, rc, "�d�ߧ����Ӹ�Ʀ��~");
		return rc;
	}
	  
  rc = car635_print_detail();
  if (rc != M_CM_OK) {
     printf("error on car635_print_detail\n");
     EWRITE(userid, rc, "���s�������Ӧ��~!");
     return rc;
  }    
			
  return rc;
}
/******************************************************************************/
long car635_init_data()
{   
    $WHENEVER SQLERROR GOTO errexit;
         	  	
         	/*ncode           char(40),      /*�Ұ�
	  	  iendorse        char(20),      /*��渹�X*
	  	  icard           char(20),      /*�O�I��/�d��*
	  	  iassured        char(10),      /*������/�νs*
	  	  nassured        varchar(120),  /*�Q�O�I�H*
	  	  itag            char(8),       /*�P�Ӹ��X*
	  	  iengine         char(20),      /*�������X*
	  	  dendorse        date,          /*�����*
	  	  dedr_begin      date,          /*���ͮİ_��*
                  dedr_end        date,          /*���ͮĨ���*
                  iofficer        char(10),      /*�g��N��*
                  nofficer        char(10),      /*�g��W��*
                  nofficer_2      char(4),       /*�g�P�ӧO*
                  nleader         char(10),      /*�޲z�H*
       		  ibus_location   char(10),      /*��~���I�N��*
        	  fedr_class      char(20),      /*������*
        	  dpay            date,          /*���O���*
        	  icomm_obj       char(2),       /*�O�N�O*
        	  nbranch         char(40),      /*�����*
        	  nedr_examiner   char(10),      /*���H��*
	  	  iins_type       char(6),       /*����I�إN�X*
	  	  nins_type       char(28),      /*����I�ئW��*
	  	  medrins_prem    integer,       /*����I�ثO�O*
	  	  medr_prem       integer,        /*����`�O�O*
	  	  medr_agent      integer         /*�N�z�O*/	  	
         	  	
         	  	
         	  	   
	  sprintf_s(stmt_tmp, sizeof stmt_tmp,"create temp table car635_tmp( "
	     "    ncode           char(40),       "
	  	 "iendorse        char(20),       "
	  	 "icard           char(20),       "
	  	 "iassured        char(10),       "
	  	 "nassured        varchar(120),   "
	  	 "itag            char(%d),       "
	  	 "iengine         char(%d),       "
	  	 "dendorse        date,           "
	  	 "dedr_begin      date,           "
	  	 "dedr_end        date,           "
	  	 "iofficer        char(10),       "
	  	 "nofficer        char(10),       "
	  	 "nofficer_2      char(4),        "
	  	 "nleader         char(10),       "
	  	 "ibus_location   char(10),       "
	  	 "fedr_class      char(20),       "
	  	 "dpay            date,           "
	  	 "icomm_obj       char(2),        "
	  	 "nbranch         char(40),       "
	  	 "nedr_examiner   char(10),       "
	  	 "iins_type       char(6),        "
	  	 "nins_type       char(28),       "
	  	 "medrins_prem    integer,        "
	  	 "medr_prem       integer,        "
	  	 "medr_commission integer,        "
	  	 "dgroup          char(10),       "
	  	 "magent          integer,        "
	  	 "nleader_2       char(10),       "
	  	 "ibig_sales	  char(10),       "
	  	 "nbig_sales      char(10),       "
	  	 "dresign         char(10),        "
	  	 "drcv            date,           "
	  	 "dply_begin      date,           "
	  	 "dply_end        date            "
	 ")with no log;",CA_TAG_NUM-1,CA_ENGINE_NUM-1);
     $PREPARE stmp FROM $stmt_tmp;
     $EXECUTE stmp;
	  
	  return M_CM_OK;

errexit:
    printf("--car635_init_data-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car635_query_detail()
{
   int	rc;
   $char sStmt[8192],sStmt2[1024];
   $varchar nassured[121];
   $char ncode[41],iendorse[21], icard[21], iassured[11], itag[CA_TAG_NUM], iengine[CA_ENGINE_NUM];
   $char dendorse[11], dedr_begin[11], dedr_end[11], sIofficer[11], nofficer[11] ,nofficer_2[5];
   $char nleader[11], ibus_location[11], fedr_class[21], dpay[11], icomm_obj[3];
   $char nbranch[41], nedr_examiner[11], iins_type[7], nins_type[29], iquota[7];
   $int  medrins_prem, medr_prem ,medr_commission, magent;
   $char stmp[1024],stmp1[512],stmp2[512],stmp3[512],iquota_c[7],iquota_c1[7]="",iupbranch[3];
   $char flevel[3], dgroup[11], nleader_2[11], nbig_sales[11], drcv[11], dply_begin[11], dply_end[11];
   $char cdendorse[10], cdrcv[10];
   $char ibig_sales[11], dresign[12];
   $long ldendorse, ldrcv;
   
   $WHENEVER SQLERROR GOTO errexit;
   
   strcpy(sDendorse_bgn, cm_to_infdate(dendorse_bgn));
   strcpy(sDendorse_end, cm_to_infdate(dendorse_end));
   
   
   $SELECT iquota
      INTO $iquota_c
      FROM officer
     WHERE iofficer = $userid;  
   printf("iquota[%s]\n",iquota_c);
   
   $SELECT flevel 
      INTO $flevel
      FROM privilege 
     WHERE iemp = $userid 
       AND ipgid = 'car635';           

   printf("flevel[%s]\n",flevel); 
   
   $SELECT iupbranch
      INTO $iupbranch
      FROM sa_branch_type
     WHERE ibranch= $iquota_c;  
     
   printf("iupbranch[%s]",iupbranch);  
   printf("sOption = [%s]iofficer=[%s]\n",sOption,iofficer);
   /*�O�N�~�ȫȤ�˿�����Ӫ��v���s�W*/
   /*�ӤH�O�I���P���L���v������*/
   /* sOption = '1' �O�S�w�g�P�Ӫ��~�ȥD��, �d�߸ӯS�w�g�P�Ӥ������� 
      add by sylvia 105.11.22 (1050802003_C1) */
   if (strncmp(trim(iquota_c),"3201",4)==0)
   strcpy(stmp1," "); 
   else if (strcmp(sOption,"1") == 0)
    strcpy(stmp1," "); 
   /*�ȯ�d�ߦۤv�g���������(���H��or�޲z�H���P�w)*/
   else if(strcmp(trim(flevel),"0")==0 && strncmp(trim(iquota_c),"3201",4)!=0) 
   sprintf_s(stmp1, sizeof stmp1,"AND (b.ileader = '%s' OR b.iedr_examiner = '%s') ",userid,userid);    
   /*��ťD�ޥi�d�߸ӳ��P���g�⤧��������*/
   else if(strcmp(trim(flevel),"1")==0 )
   sprintf_s(stmp1, sizeof stmp1,"AND ((SELECT iquota FROM officer WHERE iofficer = b.iedr_examiner) = '%s' OR (SELECT iquota FROM officer WHERE iofficer = b.ileader )= '%s')",iquota_c,iquota_c);
   /*���ťD�ޥi�d�߸ӳ��P���g�⤧��������*/
   else if(strcmp(trim(flevel),"2")==0 )
   {
   strncpy(iquota_c1,iquota_c,4);	
   printf("iquota_c1[%s]",iquota_c1);
   strcat(iquota_c1,"*");
   sprintf_s(stmp1, sizeof stmp1,"AND ((SELECT iquota FROM officer WHERE iofficer = b.iedr_examiner) matches '%s*' OR (SELECT iquota FROM officer WHERE iofficer = b.ileader ) matches '%s*')",trim(iquota_c1),trim(iquota_c1));
   }
   /*�ҰϥD�ޥi�d�߸��ҰϦP���g�⤧��������*/
   else if(strcmp(trim(flevel),"3")==0 )
   {
   sprintf_s(stmp1, sizeof stmp1,"AND ((SELECT x.iupbranch FROM officer z ,sa_branch_type x WHERE z.iofficer = b.iedr_examiner AND z.iquota = x.ibranch) = '%s' OR (SELECT x.iupbranch FROM officer z ,sa_branch_type x WHERE z.iofficer = b.ileader AND z.iquota = x.ibranch) = '%s')",trim(iupbranch),trim(iupbranch));
   }
   
   printf("stmp1[%s]\n",stmp1);
   
   /*�I�O*/
   if(strcmp(trim(fcard_class_chk),"0") == 0)
   {
   	strcpy(stmp2,"");
   }
   else if(strcmp(trim(fcard_class_chk),"1") == 0)
   {
   	sprintf_s(stmp2,sizeof stmp2,
   	"AND b.fcard_class = '1' ");
   }
   else if(strcmp(trim(fcard_class_chk),"2") == 0)
   {
   	sprintf_s(stmp2,sizeof stmp2,
   	"AND b.fcard_class = '2' ");
   }
   printf("fcard_class_chk=[%s] stmp2=[%s]\n",fcard_class_chk,stmp2);
   
   /*�R�P��*/
   if(strcmp(trim(dgroup_chk),"0") == 0)
   {
   	strcpy(stmp3,"");
   }
   else if(strcmp(trim(dgroup_chk),"1") == 0)
   {
   	sprintf_s(stmp3,sizeof stmp3,
   	"AND (select dgroup from ao_officer_commit where iendorse = a.iendorse) IS NULL ");
   }
   else if(strcmp(trim(dgroup_chk),"2") == 0)
   {
   	sprintf_s(stmp3,sizeof stmp3,
   	"AND (select dgroup from ao_officer_commit where iendorse = a.iendorse) IS NOT NULL ");
   }
   printf("dgroup_chk=[%s] stmp3=[%s]\n",fcard_class_chk,stmp3);
   
   for(i=0;i<count_db;i++) 
   {	   	  		
   	 /* ����G���ӥ�(imgr = 1 ), �Ȥ�˿�(iedr_return = 1) */
     sprintf_s(sStmt, sizeof sStmt,"SELECT (SELECT ncode FROM cu_code_data e , sa_branch_type f WHERE itype = '19' AND e.icode = f.group2 AND f.ibranch = b.iquota ),  "
                  "a.iendorse, b.icard, a.iassured, a.nassured, a.itag, "
                  "a.iengine, b.dendorse, b.dedr_begin, b.dedr_end, b.iofficer, "
                  "d.nname,d.nname[1,4],(SELECT nname FROM officer WHERE iofficer = b.ileader), "
                  "d.ibus_location,  "
                  "CASE WHEN b.fedr_class = '1' THEN '���P'  "
                  "     WHEN b.fedr_class = '2' THEN '�L��(�����ʫO�O)'  "
                  "     WHEN b.fedr_class = '4' THEN '�h���h�O'  "
                  "     WHEN b.fedr_class = '5' THEN '�@����'  "
                  "     WHEN b.fedr_class = '6' THEN '���B���'  "
                  "     WHEN b.fedr_class = '7' THEN '���P���'  "
                  "     WHEN b.fedr_class = '8' THEN '�L��(���ʫO�O)'  "
                  "     WHEN b.fedr_class = '9' THEN '����'  "
                  "     WHEN b.fedr_class = 'A' THEN '�g����'  "
                  "     WHEN b.fedr_class = 'B' THEN '�������'  "
                  "     ELSE ' ' END AS fedr_class,  "
                  "(SELECT dpay FROM ao_plyedr_prem  "
                  "  WHERE ipolicy1 = b.ipolicy[1,13]  "
                  "    AND ipolicy2 = b.ipolicy[14,17]  "
                  "    AND iendorse = a.iendorse) AS dpay, "
                  "b.icomm_obj[1,2],  "
                  "(SELECT iquota FROM officer WHERE iofficer = b.iedr_examiner), "
                  "(SELECT nname FROM officer WHERE iofficer = b.iedr_examiner),  "
                  "c.iins_type,  "
                  "(SELECT nins_type FROM insurance_type WHERE iins_type = c.iins_type), "
                  "c.medrins_prem, (b.medrdmg_prem+medrlia_prem) AS medr_prem,c.medr_commission,  "
                  "nvl((select dgroup from ao_officer_commit where iendorse = a.iendorse),'') as dgroup,  "
                  "nvl((select case when ftype  in ('P','E','4') then magent  else magent * -1 end   "
                  "   from ao_officer_commit where iendorse = a.iendorse and dgroup is not null),0) as magent,  "
                  "(SELECT nname FROM officer WHERE iofficer = d.ileader),  "
                  "b.ibig_sales, "
                  "(SELECT nname[1,10] FROM ca_big_office WHERE fclass = '2' AND ibig_comp = b.ibig_sales),  "
                  "nvl((SELECT dresign FROM ca_big_office WHERE fclass = '2' AND ibig_comp = b.ibig_sales),'') as dresign, "
                  "nvl((SELECT max(drcv) from ao_prem_grp WHERE icard = b.icard AND iendorse <> ''),'') as drcv,  "
                  "a.dply_begin, a.dply_end  "
                  " FROM %s:endorsement a, %s:edr_relation b, %s:edr_ins_type c, officer d  "
                  "WHERE a.iendorse = b.iendorse AND b.iendorse = c.iendorse  "
                  "  AND b.iofficer = d.iofficer  "
                  "  AND b.iedr_return = '1'  "
                  "  AND d.imgr = '1'  "
                  "  AND b.dedr_close IS NOT NULL  "
                  "  AND b.iofficer matches '%s'  "
                  "  AND b.dendorse >= '%s'  "
                  "  AND b.dendorse <= '%s' %s %s %s;", list[i].dbname, list[i].dbname, list[i].dbname, iofficer, sDendorse_bgn, sDendorse_end ,stmp1,stmp2,stmp3);

      printf("sStmt[%s]\n",sStmt);             
      $PREPARE stmt_cur FROM $sStmt;
      $DECLARE edr_cur CURSOR FOR stmt_cur;
      $OPEN    edr_cur;
      
      for(;;)
      {
      	$FETCH edr_cur INTO $ncode, $iendorse, $icard, $iassured, $nassured, $itag,
                            $iengine,  $dendorse, $dedr_begin, $dedr_end, 
                            $sIofficer, $nofficer, $nofficer_2, $nleader, $ibus_location,
                            $fedr_class, $dpay, $icomm_obj, $iquota,
                            $nedr_examiner, $iins_type, $nins_type, 
                            $medrins_prem, $medr_prem, $medr_commission, $dgroup, $magent,
                            $nleader_2, $ibig_sales, $nbig_sales, $dresign, $drcv, $dply_begin, $dply_end;

        if (SQLCODE==SQLNOTFOUND) break;

        /* ����� */
        $SELECT nbranch
           INTO $nbranch
           FROM sa_branch_type
          WHERE ibranch = $iquota;
        
        /* ���J�b��B�J�b��p�����h��ť� add by 061476 (1100505001_SC1) */
        if (strlen(trim(drcv)) > 0){
        	strcpy(cdendorse,cm_from_infdate_100(dendorse));
        	ldendorse = cm_ymd_cdate(cdendorse);
        	strcpy(cdrcv,cm_from_infdate_100(drcv));
        	ldrcv = cm_ymd_cdate(cdrcv);
        	        
        	if (ldrcv < ldendorse)  strcpy(drcv," ");  
        }          
        
        $INSERT INTO car635_tmp
         VALUES($ncode, $iendorse, $icard, $iassured, $nassured, $itag, $iengine,
                $dendorse, $dedr_begin, $dedr_end, $sIofficer, $nofficer, $nofficer_2,
                $nleader, $ibus_location, $fedr_class, $dpay, $icomm_obj, 
                $nbranch, $nedr_examiner, $iins_type, $nins_type, 
                $medrins_prem, $medr_prem, $medr_commission, $dgroup, $magent,
                $nleader_2,  $ibig_sales, $nbig_sales, $dresign, $drcv, $dply_begin, $dply_end);        
      }
   	  $CLOSE edr_cur;
      $FREE  edr_cur; 
   }
    
    return M_CM_OK;
  
errexit:
    printf("--car635_query_detail-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car635_print_detail()
{
    int     rc;
    char    sfilename[128],stitle[2048],stmt[2048];
    $int    icnt;

    $WHENEVER SQLERROR GOTO errexit;
    
    /* �`�� add by sylvia 105.11.22 (1050802003_C1) */ 
    strcpy(sfilename,"�O�N�~�ȫȤ�˿����`��");
    strcpy(stitle,"�{���N��:CAR635\t");
    strcat(stitle,sfilename);
    strcat(stitle,"\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");

    $SELECT ncode,iendorse,icard,iassured,nassured,itag,iengine,dendorse,
            dedr_begin,dedr_end,iofficer,nofficer,nofficer_2,nleader_2, 
            ibus_location,ibig_sales,nbig_sales,dresign,fedr_class,dpay,icomm_obj,nbranch,
            nedr_examiner,medr_prem,sum(medr_commission) as medr_commission,drcv,
            dgroup,magent,dply_begin,dply_end
       FROM car635_tmp 
       group by 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 
                19, 20, 21, 22, 23, 24, 26, 27, 28, 29, 30
      into temp car635_main with no log;

    icnt = 0;
    $select count(iendorse) into $icnt
      from car635_tmp;
      
    if (icnt == 0) 
    {
        sprintf_s(msgbuf, sizeof msgbuf," %s �d�L���, �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return  M_CM_NOT_FOUND;
    }
    
    strcat(stitle,"\t�Ұ�\t��渹�X\t�O�I��/�d��\t������/�νs\t�Q�O�I�H\t�P�Ӹ��X");
    strcat(stitle,"\t�������X\t�����\t���ͮİ_��\t���ͮĨ���");
    strcat(stitle,"\t�g��N��\t�g��W��\t�g�P�ӧO\t�޲z�H�m�W\t���I�N��\t�~�N�N��\t�~�N�m�W\t�~�N�N����藍�ߦ��_��\t������");
    strcat(stitle,"\t���O���\t�O�N�O\t�����\t���H��\t����`�O�O");
    strcat(stitle,"\t����\t�J�b���\t�R�P���");
    strcat(stitle,"\t�O��ͮİ_��\t�O��ͮĨ���\t");

    strcpy(stmt,"SELECT ncode,iendorse,icard,iassured,nassured,itag,iengine,dendorse, "
                "       dedr_begin,dedr_end,iofficer,nofficer,nofficer_2,nleader_2,  "
                "       ibus_location,ibig_sales,nbig_sales,dresign,fedr_class,dpay,icomm_obj,nbranch, "
                "       nedr_examiner,medr_prem,medr_commission,drcv," 
                "       dgroup,dply_begin,dply_end  "
                "   FROM car635_main  "
                "  ORDER BY iendorse ");

    rc = unload_file(outputf,"A",sfilename,stitle,stmt);

    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }
    
    
    
    strcpy(sfilename,"�O�N�~�ȫȤ�˿�����Ӫ�");
    strcpy(stitle,"�{���N��:CAR635\t");
    strcat(stitle,sfilename);
    strcat(stitle,"\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");

    strcat(stitle,"\t�Ұ�\t��渹�X\t�O�I��/�d��\t������/�νs\t�Q�O�I�H\t�P�Ӹ��X");
    strcat(stitle,"\t�������X\t�����\t���ͮİ_��\t���ͮĨ���");
    strcat(stitle,"\t�g��N��\t�g��W��\t�g�P�ӧO\t�޲z�H�m�W\t���I�N��\t������");
    strcat(stitle,"\t���O���\t�O�N�O\t�����\t���H��\t����I�إN��");
    strcat(stitle,"\t����I�ئW��\t����I�ثO�O\t����`�O�O\t����\t");

    strcpy(stmt,"SELECT ncode,iendorse,icard,iassured,nassured,itag,iengine,dendorse, "
                "       dedr_begin,dedr_end,iofficer,nofficer,nofficer_2,nleader,  "
                "       ibus_location,fedr_class,dpay,icomm_obj,nbranch, "
                "       nedr_examiner,iins_type,nins_type,medrins_prem,medr_prem,medr_commission" 
                "   FROM car635_tmp  "
                "  ORDER BY iendorse ");

    rc = unload_file(outputf,"B",sfilename,stitle,stmt);

    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;
    
errexit:
    printf("--car635_print_detail-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car635_get_db()
{
	int return_code;
	
	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == False) {
		strcpy(msgbuf,"��Ʈw�L�k�}��");
		return M_CM_DB_NOTOPEN;
	}
	
	return_code = getApHome(sApHome);
	if (return_code < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		return return_code;
  }
  
  if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
       if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
          return M_CM_NOT_DBLIST;
  }
  
  return M_CM_OK;

errexit:
   printf("--car635_get_db-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/******************************************************************************/