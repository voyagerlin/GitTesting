/**********************************************************************/
/*   program id   : ca1204q01s.ec                                     */
/*   program name : �Ǩ��@�~�^������                                  */
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <time.h>
#include <math.h>
#include "api_xsrv.h"
$include datetime.h;

/*--------------------------------------------------------------------*/
$char   userid[11];
char    msgbuf[1000],sApHome[30];
$char   DBName[5],stmt[7000];
char    outputf[N_FILE+1] ;
DBinfo  *list;
int     count_db;
char    opt1[2], opt2[2],opt3[2], date1[11], date2[11], opt_str[1000];
$char   dbegin[11], dend[11];
$int    icnt1;
char    sfilename[128],stitle[2048];
/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
    int rc;
    batchinit();
    strcpy(DBName,  isNULLstr(argv[1]));
    strcpy(userid,  isNULLstr(argv[2]));
    strcpy(opt1,    isNULLstr(argv[3]));    /* �I��:1�j�� 2���N 3�j+�� */
    strcpy(opt2,    isNULLstr(argv[4]));    /* �O��/�߮�:1��O�� 2�߮פΩ��ݫO�� 3��O��+�߮פΩ��ݽ߮� */
    strcpy(date1,   isNULLstr(argv[5]));    /* ����϶�:�_�� */
    strcpy(date2,   isNULLstr(argv[6]));    /* ����϶�:���� */
    strcpy(opt3,    isNULLstr(argv[7]));    /* �z�����:1.ID 2.�W�� 3.���P */
    strcpy(opt_str, isNULLstr(argv[8]));    /* �z����󤺮e(�H;���j) */
    strcpy(outputf, isNULLstr(argv[9]));

    strcpy(dbegin, cm_to_infdate(date1));
    strcpy(dend, cm_to_infdate(date2));
    strcpy(opt_str, trim(opt_str));

    printf("1.car1204_get_db() \n");
    rc = car1204_get_db();
    if (rc != M_CM_OK) {
        printf("error on car1204_get_db\n");
        EWRITE(userid, rc, "error on car1204_get_db");
        return rc;
    }

    printf("2.car1204_init_data() \n");
    rc = car1204_init_data();
    if (rc != M_CM_OK) {
        EWRITE(userid, rc, "error on car1204_init_data");
        return rc;
    }

    /* �ˮ֬O�_����� */
    rc = chk_data();
    if (rc != M_CM_OK) {
        EWRITE(userid, rc, "error on chk_data");
        return rc;
    }
    if (icnt1 == 0) {
        rc=car1204_print();
        if (rc != M_CM_OK) {
            printf("error on car1204_print\n");
            return rc;
        }
    }
    else
    {
        printf("------ 83 ----------- \n");
        rc=car1204_get_more_data();
        if (rc != M_CM_OK) {
            printf("error on car1204_print\n");
            return rc;
        }
        
        rc=car1204_print();
        if (rc != M_CM_OK) {
            printf("error on car1204_print\n");
            return rc;
        }
    }
    
    return rc;
}

/*--------------------------------------------------------------------*/
long car1204_get_db()
{
    int	rc;

    if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
    }

    if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
    {
        EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
        return M_CM_NOT_DBLIST;
    }

    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }

    return M_CM_OK;
}
/*--------------------------------------------------------------------*/
long car1204_init_data()
{
    int i,m,x,slen;
    $char    sdata1[41];
    
    $whenever sqlerror goto errexit;
    
    printf("-------- 133 --------------\n");
    /* create temp table */
    /* $delete from tb12041a where 1=1;
    $delete from tb12041b where 1=1;
    $delete from tb12041 where 1=1; */
   $create temp table tb12041a
     (sopt1  char(40)) with no log;
     
    $create temp table tb12041b
     (iclaim  char(20)) with no log;
    
    $create temp table tb12041
    (
        icompany        char(2),    -- 1 �q�����q
        iclaim          char(20),   -- 2 �߮׸��X
        iins_type       char(7),    -- 3 �X�I�I��
        mpayment        int,        -- 4 �z�ߪ��B
        daccident       date,       -- 5 �ƬG���
        iarea           char(20),   -- 6 �ƬG�a�I
        itag            char(13),   -- 7 �O������ 
        iengine         char(26),   -- 8 �O������/�������X
        nassured        char(120),  -- 9 �Q�O�I�H�m�W 
        iassured        char(13),   -- 10 �Q�O�I�HID/�Τ@�s��
        itel            char(21),   -- 11 �Q�O�I�H�q��(1) 
        mobil_phone     char(21),   -- 12 �Q�O�I�H�q��(2) 
        aassured        char(250),  -- 13 �Q�O�I�H�a�} 
        nacc_driver     char(20),   -- 14 �O���r�p�m�W 
        iacc_license    char(12),   -- 15 �O���r�pID 
        iacc_tel        char(21),   -- 16 �O���r�p�q��(1)
        iacc_movephone  char(21),   -- 17 �O���r�p�q��(2) 
        avicassured     char(120),  -- 18 �O���r�p�a�} 
        i32tag          char(13),   -- 19 �]������ 
        i32npro         char(120),  -- 20 �D�����]�l 
        i32engine       char(26),   -- 21 �]������/�������X 
        i32nname        char(120),  -- 22 �]�����D 
        i32ndriver      char(20),   -- 23 �]���r�p�m�W 
        i32idriver      char(12),   -- 24 �]���r�pID 
        i32idritel      char(21),   -- 25 �]���r�p�q��(1) 
        i32idritel2     char(21),   -- 26 �]���r�p�q��(2) 
        i32avictim      char(250),  -- 27 �]���r�p�a�} 
        nvictim         char(120),  -- 28 ���`�H�m�W 
        ivictim         char(13),   -- 29 ���`�HID 
        ivictim_tel1    char(21),   -- 30 ���`�H�q��(1) 
        ivictim_tel2    char(21),   -- 31 ���`�H�q��(2) 
        nforce_name     char(30),   -- 32 ĵ���� 
        npolice         char(30),   -- 33 ĵ���m�W 
        noffice_name    char(30),   -- 34 �a�˸p 
        nprocurator     char(30),   -- 35 �˹�x�m�W 
        ninspector      char(30),   -- 36 �k��v/������m�W 
        nhospital       char(30),   -- 37 ��|�W�� 
        ndoctor         char(30),   -- 38 ��v�m�W 
        icar_factory    char(13),   -- 39 �ר��t�Τ@�s�� 
        nowner          char(120),  -- 40 �ר��t�t�d�H�m�W 
        npayment        char(120),  -- 41 ���ڤH�W�� 
        ipaymenta       char(13),   -- 42 ���ڤHID/�Τ@�s�� 
        ipay_tphone     char(21),   -- 43 ���ڤH�q��
        xiaccount       char(31),   -- 44 ���ڤH�Ȧ�b��
        xfpay_cond      char(10),   -- 45 ���I�覡 
        dpay            char(10),   -- 46 ���I��� 
        ideliver        char(120),  -- 47 �e��H/�e�U�H�m�W 
        nname           char(30),   -- 48 �~�ȭ��m�W 
        nadjust         char(30),   -- 49 �z�߭��m�W 
        fcard_class     char(10),   -- 50 ��O�I�رj��/���N 
        dply_begin      char(10)    -- 51 �����ͮĤ�
    )with no log;
    
    strcpy(sfilename,"�Ǩ�����");
    strcpy(stitle,"�q�����q\t�߮׸��X\t�X�I�I��\t�z�ߪ��B\t�ƬG���\t�ƬG�a�I\t");
    strcat(stitle,"�O������\t�O������/�������X\t�Q�O�I�H�m�W\t�Q�O�I�HID/�Τ@�s��\t");
    strcat(stitle,"�Q�O�I�H�q��(1)\t�Q�O�I�H�q��(2)\t�Q�O�I�H�a�}\t�O���r�p�m�W\t");
    strcat(stitle,"�O���r�pID\t�O���r�p�q��(1)\t�O���r�p�q��(2)\t�O���r�p�a�}\t");
    strcat(stitle,"�]������\t�D�����]�l\t�]������/�������X\t�]�����D\t");
    strcat(stitle,"�]���r�p�m�W\t�]���r�pID\t�]���r�p�q��(1)\t�]���r�p�q��(2)\t");
    strcat(stitle,"�]���r�p�a�}\t���`�H�m�W\t���`�HID\t���`�H�q��(1)\t���`�H�q��(2)\t");
    strcat(stitle,"ĵ����\tĵ���m�W\t�a�˸p\t�˹�x�m�W\t�k��v/������m�W\t");
    strcat(stitle,"��|�W��\t��v�m�W\t�ר��t�Τ@�s��\t�ר��t�t�d�H�m�W\t");
    strcat(stitle,"���ڤH�W��\t���ڤHID/�Τ@�s��\t���ڤH�q��\t���ڤH�Ȧ�b��\t");
    strcat(stitle,"���I�覡\t���I���\t�e��H/�e�U�H�m�W\t�~�ȭ��m�W\t�z�߭��m�W\t");
    strcat(stitle,"��O�I�� �j��/���N\t�����ͮĤ�\t");
    
    
    m=0;x=0;
    slen = strlen(opt_str);
    printf("opt_str=[%s]strlen(opt_str)=[%d] slen=[%d]\n",opt_str,strlen(opt_str),slen);
    for (i=0;i<=slen;i++)
    {
        if (opt_str[i]==';' || opt_str[i]=='\0')
        {
            strncpy(sdata1,opt_str+m,i-m);
            sdata1[i-m]='\0';
            m=i+1;
            
            $insert into tb12041a (sopt1) values ($sdata1);
            x=x+1;
            printf("�d�߱���=[%d][%s]\n",x,sdata1);
            memset(sdata1,0x00,sizeof(sdata1));
        }
    }

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
/* �ˮ֬O�_����� */
long chk_data()
{
    $char stmp1[50], stmt1[5000], stmt2[5000], stmt3[5000], stmt4[5000], stmt5[5000];
    $char tmp_date[500],tmp_datep[500];
    int i;
    
    $whenever sqlerror goto errexit;
    
    icnt1 = 0;
    
    /* �I�� */
    if (opt1[0] == '1')
        strcpy(stmp1,"and b.fcard_class = '1'");
    else if(opt1[0] == '2')
        strcpy(stmp1,"and b.fcard_class = '2'");
    else
        strcpy(stmp1," ");
        
    /* ����϶� */    
    if((strcmp(date1,"*") == 0) && (strcmp(date2,"*") == 0))
    {
        strcpy(tmp_date," ");
        strcpy(tmp_datep," ");
    }
    else
    {
        sprintf(tmp_date,"AND ((a.dclaim between '%s' and '%s') or "
                        "     (a.dappraisal between '%s' and '%s')) ",
                dbegin, dend, dbegin, dend);
                
        sprintf(tmp_datep," and b.dpolicy between '%s' and '%s' "
                          " and b.dply_close is not null ",dbegin, dend);
        
    }
    
    for (i=0; i<count_db; i++)
    {
        /* �߮�:�Q�O�I�H */
        /* sprintf(stmt1,
            "insert into tb12041b "
            "SELECT a.iclaim FROM ca_clm_process a, %s:appraisal b "
            " WHERE a.iclaim = b.iclaim  %s "
            "   AND ((a.dclaim between '%s' and '%s') or "
            "        (a.dappraisal between '%s' and '%s')) "
            "   AND (a.iassured IN (select sopt1 from tb12041a where 1=1) or "
            "        a.nassured IN (select sopt1 from tb12041a where 1=1) or "
            "        a.itag IN (select sopt1 from tb12041a where 1=1)) ",
            list[i].dbname, stmp1, dbegin, dend, dbegin, dend); */
        sprintf(stmt1,
            "insert into tb12041b "
            "SELECT a.iclaim FROM ca_clm_process a, %s:appraisal b "
            " WHERE a.iclaim = b.iclaim  %s %s "
            "   AND (a.iassured IN (select sopt1 from tb12041a where 1=1) or "
            "        a.nassured IN (select sopt1 from tb12041a where 1=1) or "
            "        a.itag IN (select sopt1 from tb12041a where 1=1)) ",
            list[i].dbname, stmp1, tmp_date);
               
        printf("stmt1=[%s]\n",stmt1);
        $prepare pre_ck1 from $stmt1;
        $execute pre_ck1;
             
        /* �߮�:���`�H */
        /* sprintf(stmt2,
            "insert into tb12041b "
            "select a.iclaim "
            "  from ca_clm_process a, ca_clm_victim_data b, %s:appraisal c "
            " where a.iclaim = b.iclaim and a.iclaim = c.iclaim  %s "
            "   AND ((a.dclaim between '%s' and '%s') or "
            "        (a.dappraisal between '%s' and '%s')) "
            "   AND (b.ivictim IN (select sopt1 from tb12041a where 1=1) or "
            "        b.itag IN (select sopt1 from tb12041a where 1=1))",
            list[i].dbname, stmp1, dbegin, dend, dbegin, dend); */
        sprintf(stmt2,
            "insert into tb12041b "
            "select a.iclaim "
            "  from ca_clm_process a, ca_clm_victim_data c, %s:appraisal b "
            " where a.iclaim = b.iclaim and a.iclaim = c.iclaim  %s %s "
            "   AND (c.ivictim IN (select sopt1 from tb12041a where 1=1) or "
            "        c.itag IN (select sopt1 from tb12041a where 1=1))",
            list[i].dbname, stmp1, tmp_date);
        
        printf("stmt2=[%s]\n",stmt2);              
        $prepare pre_ck2 from $stmt2;
        $execute pre_ck2;              
        
             
        /* �߮�:�ĤT�H */
        /* sprintf(stmt3,
            "insert into tb12041b "
            "select a.iclaim "
            "  from ca_clm_process a, ca_ver_relation b, ca_property c, %s:appraisal d "
            " WHERE a.iclaim = b.iclaim and b.iverify = c.iverify and a.iclaim = d.iclaim %s "
            "   And ((a.dclaim between '%s' and '%s') or "
            "        (a.dappraisal between '%s' and '%s')) "
            "   And (c.ivictim IN (select sopt1 from tb12041a where 1=1) or "
            "        c.itag IN (select sopt1 from tb12041a where 1=1)) ",
            list[i].dbname, stmp1, dbegin, dend, dbegin, dend); */
        sprintf(stmt3,
            "insert into tb12041b "
            "select a.iclaim "
            "  from ca_clm_process a, ca_ver_relation d, ca_property c, %s:appraisal b "
            " WHERE a.iclaim = d.iclaim and d.iverify = c.iverify and a.iclaim = b.iclaim %s %s "
            "   And (c.ivictim IN (select sopt1 from tb12041a where 1=1) or "
            "        c.itag IN (select sopt1 from tb12041a where 1=1)) ",
            list[i].dbname, stmp1,tmp_date);
            
        printf("stmt3=[%s]\n",stmt3);              
        $prepare pre_ck3 from $stmt3;
        $execute pre_ck3;            
        
        
        /* �߮�:�ߥI��H */
        /* sprintf(stmt4,
            "insert into tb12041b "
            "select a.iclaim "
            "  from ca_clm_process a, %s:appraisal b, %s:payment c "
            " WHERE a.iclaim = b.iclaim and b.iclaim = c.iclaim  %s "
            "   And ((a.dclaim between '%s' and '%s') or "
            "        (a.dappraisal between '%s' and '%s')) "
            "   And (c.ipayment IN (select sopt1 from tb12041a where 1=1) or "
            "        c.npayment IN (select sopt1 from tb12041a where 1=1)) ",
            list[i].dbname, list[i].dbname, stmp1, dbegin, dend, dbegin, dend); */
        
        sprintf(stmt4,
            "insert into tb12041b "
            "select a.iclaim "
            "  from ca_clm_process a, %s:appraisal b, %s:payment c "
            " WHERE a.iclaim = b.iclaim and b.iclaim = c.iclaim  %s %s "
            "   And (c.ipayment IN (select sopt1 from tb12041a where 1=1) or "
            "        c.npayment IN (select sopt1 from tb12041a where 1=1)) ",
            list[i].dbname, list[i].dbname, stmp1, tmp_date);
    
        printf("stmt4=[%s]\n",stmt4);              
        $prepare pre_ck4 from $stmt4;
        $execute pre_ck4;            
        
        /* �L�߮ת��O�� */
        printf("===== 379:opt2=[%s] ------ \n",opt2);
        if ((opt2[0] == '1') || (opt2[0] == '3'))
        {
            printf("======= 382 ======= \n");
            /* sprintf(stmt5,
            "insert into tb12041b "
            "select a.ipolicy from %s:policy a, %s:ply_relation b "
            " where a.ipolicy = b.ipolicy %s "
            "   and b.dpolicy between '%s' and '%s' and b.dply_close is not null "
            "   and (a.iassured in (select sopt1 from tb12041a where 1=1) or "
            "        a.nassured in (select sopt1 from tb12041a where 1=1) or "
            "        a.itag in (select sopt1 from tb12041a where 1=1))",
            list[i].dbname, list[i].dbname, stmp1, dbegin, dend); */
            
            sprintf(stmt5,
            "insert into tb12041b "
            "select a.ipolicy from %s:policy a, %s:ply_relation b "
            " where a.ipolicy = b.ipolicy %s %s "
            "   and (a.iassured in (select sopt1 from tb12041a where 1=1) or "
            "        a.nassured in (select sopt1 from tb12041a where 1=1) or "
            "        a.itag in (select sopt1 from tb12041a where 1=1))",
            list[i].dbname, list[i].dbname, stmp1, tmp_datep);
            
            printf("stmt5=[%s]\n",stmt5); 
            $prepare pre_ck5 from $stmt5;
            $execute pre_ck5;
        }
    }
    
    $select count(*) into $icnt1
       from tb12041b
      where 1=1;
      
    if (icnt1 == 0)
        $insert into tb12041 (iclaim) values ("�d�L���");
    
	return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* ------------------------------------------------------------------------- */
long car1204_get_more_data()
{
    int     rc, i;
    $char   stmt1[6000], stmt11[6000], stmt21[6000], stmt31[6000], stmt32[6000],
            stmt17[6000];
    

    $WHENEVER SQLERROR GOTO errexit;
    
    printf("------ 365 ----------- \n");
    /* �� SQL���� '' ��ASCII127, �i�H�b��EXCEL����0�������,���|���@�Ů�,�p���s
       �ɻݨD, ���V�ΡC add by sylvia 106.10.13)
     */
    for (i=0; i<count_db; i++)
    {
        /* �����I */
        sprintf(stmt1,"insert into tb12041 select '17' as icompany, a.iclaim, "
        "       ''||(select min(iins_type) from %s:app_ins_type where iclaim = a.iclaim "
        "       and iins_type in (select icode from cu_code_data where itype = 'CT')) as iins_type, "
        "       decode(e.fstl,'2',e.mpayment*(-1),e.mpayment) as mpayment, "
        "       date(b.daccident) daccident, (select dvp_abbr from sysdb:ca_dvp_ply_area "
        "       where b.iacc_area = dvp_code) as iarea, ''||c.itag, ''||c.iengine, "
        "       c.nassured, ''||c.iassured, ''||f.itel, ''||f.mobil_phone, "
        "       f.aassured, b.nacc_driver, b.iacc_license, "
        "       ''||(select max(y.itel) from ca_ver_relation x,ca_clm_victim_data y "
        "       where x.iverify = y.iclaim and x.iclaim = a.iclaim "
        "       and y.ivictim = b.iacc_license) as iacc_tel, "
        "       ''||(select max(imovephone) from cu_customer "
        "       where ifpce_id = b.iacc_license) as iacc_movephone, "
        "       case when (nvl((select max(y.avictim) from ca_ver_relation x,ca_clm_victim_data y "
        "            where x.iverify = y.iclaim and x.iclaim = a.iclaim "
        "            and y.ivictim = b.iacc_license),' ') = ' ') then "
        "            (select max(aperm_con) from cu_customer where ifpce_id = b.iacc_license) "
        "            else ' ' end as avicassured, "
        "       ''||(select max(mm.itag) from ca_property mm,ca_ver_relation nn "
        "       where mm.iverify = nn.iverify and nn.iclaim  = a.iclaim "
        "       and mm.ipro_no = (select min(ipro_no) from ca_pro_ins "
        "       where iclaim = a.iclaim and iins_type = '32')) as i32tag, "
        "       (select max(mm.npro) from ca_property mm,ca_ver_relation nn "
        "       where mm.iverify = nn.iverify and nn.iclaim  = a.iclaim "
        "       and mm.ipro_no = (select min(ipro_no) from ca_pro_ins "
        "       where iclaim = a.iclaim and iins_type = '32')) as i32npro, "
        "       ''||(select max(mm.iengine) from ca_property mm,ca_ver_relation nn "
        "       where mm.iverify = nn.iverify and nn.iclaim  = a.iclaim "
        "       and mm.ipro_no = (select min(ipro_no) from ca_pro_ins "
        "       where iclaim = a.iclaim and iins_type = '32')) as i32engine, "
        "       (select max(nchi_full) from cu_customer where ifpce_id = "
        "         (select max(mm.ivictim) from ca_property mm,ca_ver_relation nn "
        "          where mm.iverify = nn.iverify and nn.iclaim  = a.iclaim "
        "          and mm.ipro_no = (select min(ipro_no) from ca_pro_ins "
        "              where iclaim = a.iclaim and iins_type = '32'))) as i32nname, "
        "       (select max(pp.nassured) from ca_clm_victim_data pp,ca_ver_relation qq "
        "        where pp.iclaim = qq.iverify and qq.iclaim = a.iclaim "
        "        and pp.fvictim_car = 'E' and pp.itag = (select max(mm.itag) "
        "        from ca_property mm,ca_ver_relation nn where mm.iverify = nn.iverify "
        "        and nn.iclaim  = a.iclaim and mm.ipro_no = (select min(ipro_no) "
        "        from ca_pro_ins where iclaim = a.iclaim and iins_type = '32'))) as i32ndriver, "
        "       ''||(select replace(max(pp.ivictim),'*','') "
        "          from ca_clm_victim_data pp,ca_ver_relation qq "
        "          where pp.iclaim = qq.iverify and qq.iclaim = a.iclaim "
        "          and pp.fvictim_car = 'E' and pp.itag = (select max(mm.itag) "
        "          from ca_property mm,ca_ver_relation nn where mm.iverify = nn.iverify "
        "          and nn.iclaim  = a.iclaim and mm.ipro_no = (select min(ipro_no) "
        "          from ca_pro_ins where iclaim = a.iclaim and iins_type = '32'))) as i32idriver, "
        "        ''||(select replace(max(pp.itel),'*','') from ca_clm_victim_data pp,ca_ver_relation qq "
        "          where pp.iclaim = qq.iverify and qq.iclaim = a.iclaim "
        "          and pp.fvictim_car = 'E' and pp.itag = (select max(mm.itag) "
        "          from ca_property mm,ca_ver_relation nn where mm.iverify = nn.iverify "
        "          and nn.iclaim  = a.iclaim and mm.ipro_no = (select min(ipro_no) "
        "          from ca_pro_ins where iclaim = a.iclaim and iins_type = '32'))) as i32idritel, "
        "       ' ' as i32idritel2, "
        "       (select max(pp.avictim) from ca_clm_victim_data pp,ca_ver_relation qq "
        "        where pp.iclaim = qq.iverify and qq.iclaim = a.iclaim "
        "        and pp.fvictim_car = 'E' and pp.itag = (select max(mm.itag) "
        "        from ca_property mm,ca_ver_relation nn where mm.iverify = nn.iverify "
        "        and nn.iclaim  = a.iclaim and mm.ipro_no = (select min(ipro_no) "
        "        from ca_pro_ins where iclaim = a.iclaim and iins_type = '32'))) as i32avictim, "
        "       (select ff.nassured from ca_clm_victim_data ff, ca_ver_relation gg "
        "        where ff.iclaim = gg.iverify and gg.iclaim = a.iclaim "
        "        and ff.ivictim = (select max(ivictim) from ca_human_est "
        "        where iclaim = a.iclaim and fhuman = '2')) as nvictim, "
        "       (select max(ivictim) from ca_human_est where iclaim = a.iclaim "
        "        and fhuman = '2') as ivictim, ''||(select ff.itel "
        "        from ca_clm_victim_data ff, ca_ver_relation gg "
        "        where ff.iclaim = gg.iverify and gg.iclaim = a.iclaim "
        "        and ff.ivictim = (select max(ivictim) from ca_human_est "
        "        where iclaim = a.iclaim and fhuman = '2')) as ivictim_tel1, "
        "       ' ' as ivictim_tel2, (select replace(y.nforce_name,'*','') "
        "        from ca_ver_relation x,ca_verify y where x.iverify = y.iverify "
        "        and x.iclaim = a.iclaim) as nforce_name, "
        "       (select replace(y.npolice,'*','') from ca_ver_relation x,ca_verify y "
        "        where x.iverify = y.iverify and x.iclaim = a.iclaim) as npolice, "
        "       (select max(ncode) from cu_code_data ccd,ca_human_est che "
        "        where ccd.itype  = 'BV' and ccd.icode  = che.ioffice "
        "        and che.iclaim = a.iclaim) as noffice_name, "
        "       (select replace(max(nprocurator),'*','') from ca_human_est "
        "        where iclaim = a.iclaim and fhuman = '2') as nprocurator, "
        "       (select replace(max(ninspector),'*','')  from ca_human_est "
        "        where iclaim = a.iclaim and fhuman = '2') as ninspector, "
        "       (select replace(max(nhospital),'*','')   from ca_human_est "
        "        where iclaim = a.iclaim and fhuman = '2') as nhospital, "
        "       (select replace(max(ndoctor),'*','')     from ca_human_est "
        "        where iclaim = a.iclaim and fhuman = '2') as ndoctor, "
        "       case when e.xsettle_type = '6' then "
        "            ''||replace(nvl((select ifpce_id from ca_factory "
        "             where ifactory = e.ipayment and ifactory_ext = ''),e.ipayment),'*','') "
        "       else ' ' end as icar_factory, ' ' nowner, e.npayment, "
        "       case when e.xsettle_type = '6' then "
        "            ''||replace(nvl((select ifpce_id from ca_factory "
        "            where ifactory = e.ipayment and ifactory_ext = ''), "
        "            case when length(trim(e.ipayment)) < 8 then ' ' else e.ipayment end),'*','')"
        "                 else case when length(trim(e.ipayment)) < 8 then ' ' else e.ipayment end "
        "       end as ipaymenta, ''||(select max(tphone_ext_con) from cu_customer "
        "       where ifpce_id = e.ipayment) as ipay_tphone, "
        "       ''||rtrim(e.xibank) || rtrim(e.xiaccount) as xiaccount, "
        "       decode(e.xfpay_cond,'1','�{��','2','�䲼','3','�״�','') as xfpay_cond, "
        "       (select max(k.dpay) from ao_stl_obj_close k where k.iclose = e.iclaim "
        "        and k.fstl = e.fstl and k.iclose_type = cast(e.iclose_type as char(5)) "
        "        and k.istl_obj = e.ipayment and k.istl_obj_ext = e.ifpce_id_ext) as dpay, "
        "       (select max(p.ideliver) from ca_sign_receipt p where p.iclaim = e.iclaim "
        "        and p.ifpce_id = e.ipayment and p.ifpce_id_ext = e.ifpce_id_ext) as ideliver, "
        "       (select nname from officer r where r.iofficer = c.iofficer) as nname, "
        "       (select nname from officer s where s.iofficer = a.adjustment) as nadjust, "
        "       decode(g.fcard_class,'1','�j��','2','���N','') as fcard_class, "
        "       g.dply_begin "
        "  from ca_clm_process a, %s:appraisal b, %s:adjustment_ply c, "
        "       %s:settlement d, %s:payment e, %s:policy f, %s:ply_relation g "
        " where a.iclaim = b.iclaim  and  a.iclaim = c.iclaim "
        "   and a.iclaim = d.iclaim  and  d.iclaim = e.iclaim "
        "   and d.fstl = e.fstl and d.iclose_type = e.iclose_type "
        "   and a.ipolicy = f.ipolicy  and  a.ipolicy = g.ipolicy "
        "   and e.pay_kind in ('1') and exists "
        "       (select * from %s:stl_ins_type  where iclaim = e.iclaim "
        "           and fstl = e.fstl and iclose_type = e.iclose_type "
        "           and iins_type in (select icode from cu_code_data where itype = 'CT') "
		"           and dgroup is not null) "
		"   and a.iclaim in (select unique iclaim from tb12041b where 1=1) "
        "   and (e.ipayment in (select sopt1 from tb12041a where 1=1) or "
        "        e.npayment in (select sopt1 from tb12041a where 1=1) or "
        "        a.iassured in (select sopt1 from tb12041a where 1=1) or "
        "        a.nassured in (select sopt1 from tb12041a where 1=1) or "
        "        a.itag in (select sopt1 from tb12041a where 1=1)) ",
        list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,
        list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname);  
        printf("stmt1=[%s]\n",stmt1);
        $prepare pre_get1 from $stmt1;
        $execute pre_get1;
        
        /* �ѵs�I */
        sprintf(stmt11,"insert into tb12041 "
        "select '17' as icompany, a.iclaim, '11' as iins_type, "
        "       decode(e.fstl,'2',e.mpayment*(-1),e.mpayment) as mpayment, "
        "       date(b.daccident) as daccident, (select dvp_abbr from sysdb:ca_dvp_ply_area "
        "       where b.iacc_area = dvp_code) as iarea, ''||c.itag, ''||c.iengine, "
        "       c.nassured, ''||c.iassured, ''||f.itel, ''||f.mobil_phone, "
        "       f.aassured, b.nacc_driver, b.iacc_license, "
        "       ''||(select max(y.itel) from ca_ver_relation x,ca_clm_victim_data y "
        "       where x.iverify = y.iclaim and x.iclaim = a.iclaim "
        "       and y.ivictim = b.iacc_license) as iacc_tel, "
        "       ''||(select max(imovephone) from cu_customer "
        "       where ifpce_id = b.iacc_license) as iacc_movephone, "
        "       (select max(y.avictim) from ca_ver_relation x,ca_clm_victim_data y "
        "        where x.iverify = y.iclaim and x.iclaim = a.iclaim "
        "        and y.ivictim = b.iacc_license) as avicassured, "
        "       ''||(select max(mm.itag) from ca_property mm,ca_ver_relation nn "
        "        where mm.iverify = nn.iverify and nn.iclaim  = a.iclaim "
        "        and mm.ipro_no = (select min(ipro_no) from ca_pro_ins "
        "         where iclaim = a.iclaim and iins_type = '32')) as i32tag, "
        "       (select max(mm.npro) from ca_property mm,ca_ver_relation nn "
        "        where mm.iverify = nn.iverify and nn.iclaim  = a.iclaim "
        "        and mm.ipro_no = (select min(ipro_no) from ca_pro_ins "
        "        where iclaim = a.iclaim and iins_type = '32')) as i32npro, "
        "       ''||(select max(mm.iengine) from ca_property mm,ca_ver_relation nn "
        "        where mm.iverify = nn.iverify and nn.iclaim  = a.iclaim "
        "        and mm.ipro_no = (select min(ipro_no) from ca_pro_ins "
        "        where iclaim = a.iclaim and iins_type = '32')) as i32engine, "
        "       (select max(nchi_full) from cu_customer where ifpce_id =  "
        "         (select max(mm.ivictim) from ca_property mm,ca_ver_relation nn "
        "          where mm.iverify = nn.iverify and nn.iclaim  = a.iclaim "
        "          and mm.ipro_no = (select min(ipro_no) from ca_pro_ins "
        "          where iclaim = a.iclaim and iins_type = '32'))) as i32nname,"
        "       (select max(pp.nassured) from ca_clm_victim_data pp,ca_ver_relation qq "
        "        where pp.iclaim = qq.iverify and qq.iclaim = a.iclaim "
        "        and pp.fvictim_car = 'E' and pp.itag = (select max(mm.itag) "
        "        from ca_property mm,ca_ver_relation nn where mm.iverify = nn.iverify "
        "        and nn.iclaim  = a.iclaim and mm.ipro_no = "
        "         (select min(ipro_no) from ca_pro_ins where iclaim = a.iclaim "
        "          and iins_type = '32'))) as i32ndriver, "
        "       (select replace(max(pp.ivictim),'*','') from ca_clm_victim_data pp,ca_ver_relation qq "
        "        where pp.iclaim = qq.iverify and qq.iclaim = a.iclaim "
        "        and pp.fvictim_car = 'E' and pp.itag = (select max(mm.itag) "
        "        from ca_property mm,ca_ver_relation nn where mm.iverify = nn.iverify "
        "         and nn.iclaim  = a.iclaim and mm.ipro_no = (select min(ipro_no) "
        "         from ca_pro_ins where iclaim = a.iclaim and iins_type = '32'))) as i32idriver, "
        "       ''||(select replace(max(pp.itel),'*','') from ca_clm_victim_data pp,ca_ver_relation qq "
        "        where pp.iclaim = qq.iverify and qq.iclaim = a.iclaim "
        "        and pp.fvictim_car = 'E' and pp.itag = (select max(mm.itag) "
        "        from ca_property mm,ca_ver_relation nn where mm.iverify = nn.iverify "
        "        and nn.iclaim  = a.iclaim and mm.ipro_no = "
        "        (select min(ipro_no) from ca_pro_ins where iclaim = a.iclaim "
        "         and iins_type = '32'))) as i32idritel, ' ' as i32idritel2, "
        "       (select max(pp.avictim) from ca_clm_victim_data pp,ca_ver_relation qq "
        "        where pp.iclaim = qq.iverify and qq.iclaim = a.iclaim "
        "        and pp.fvictim_car = 'E' and pp.itag = (select max(mm.itag) "
        "        from ca_property mm,ca_ver_relation nn where mm.iverify = nn.iverify "
        "        and nn.iclaim  = a.iclaim and mm.ipro_no = (select min(ipro_no) "
        "        from ca_pro_ins where iclaim = a.iclaim and iins_type = '32'))) as i32avictim, "
        "       (select ff.nassured from ca_clm_victim_data ff, ca_ver_relation gg "
        "        where ff.iclaim = gg.iverify and gg.iclaim = a.iclaim "
        "        and ff.ivictim = (select max(ivictim) from ca_human_est "
        "        where iclaim = a.iclaim and fhuman = '2')) as nvictim, "
        "       (select max(ivictim) from ca_human_est where iclaim = a.iclaim "
        "        and fhuman = '2') as ivictim, "
        "       ''||(select ff.itel from ca_clm_victim_data ff, ca_ver_relation gg "
        "       where ff.iclaim = gg.iverify and gg.iclaim = a.iclaim "
        "       and ff.ivictim = (select max(ivictim) from ca_human_est "
        "       where iclaim = a.iclaim and fhuman = '2')) as ivictim_tel1, "
        "       ' ' as ivictim_tel2, (select replace(y.nforce_name,'*','') "
        "       from ca_ver_relation x,ca_verify y where x.iverify = y.iverify "
        "       and x.iclaim = a.iclaim) as nforce_name, "
        "       (select replace(y.npolice,'*','') from ca_ver_relation x,ca_verify y "
        "        where x.iverify = y.iverify and x.iclaim = a.iclaim) as npolice, "
        "       (select max(ncode) from cu_code_data ccd,ca_human_est che "
        "        where ccd.itype  = 'BV' and ccd.icode  = che.ioffice "
        "        and che.iclaim = a.iclaim) as noffice_name, "
        "       (select replace(max(nprocurator),'*','') from ca_human_est "
        "         where iclaim = a.iclaim and fhuman = '2') as nprocurator, "
        "       (select replace(max(ninspector),'*','')  from ca_human_est "
        "        where iclaim = a.iclaim and fhuman = '2') as ninspector, "
        "       (select replace(max(nhospital),'*','')   from ca_human_est "
        "        where iclaim = a.iclaim and fhuman = '2') as nhospital, "
        "       (select replace(max(ndoctor),'*','')     from ca_human_est "
        "        where iclaim = a.iclaim and fhuman = '2') as ndoctor, "
        "       case when e.xsettle_type = '6' then "
        "            ''||replace(nvl((select ifpce_id from ca_factory "
        "            where ifactory = e.ipayment and ifactory_ext = ''),e.ipayment),'*','') "
        "       else ' ' end as icar_factory, ' ' nowner, e.npayment, "
        "       case when e.xsettle_type = '6' then "
        "            ''||replace(nvl((select ifpce_id from ca_factory "
        "              where ifactory = e.ipayment and ifactory_ext = ''), "
        "               case when length(trim(e.ipayment)) < 8 then ' ' "
        "                    else e.ipayment end),'*','') "
        "       else case when length(trim(e.ipayment)) < 8 then ' ' "
        "            else e.ipayment end end as ipaymenta, "
        "       ''||(select max(tphone_ext_con) from cu_customer "
        "       where ifpce_id = e.ipayment) as ipay_tphone, "
        "       ''||rtrim(e.xibank) || rtrim(e.xiaccount) as xiaccount, "
        "       decode(e.xfpay_cond,'1','�{��','2','�䲼','3','�״�','') as xfpay_cond, "
        "       (select max(k.dpay) from ao_stl_obj_close k "
        "        where k.iclose = e.iclaim and k.fstl = e.fstl "
        "       and k.iclose_type = cast(e.iclose_type as char(5)) "
        "       and k.istl_obj = e.ipayment and k.istl_obj_ext = e.ifpce_id_ext) as dpay, "
        "       (select max(p.ideliver) from ca_sign_receipt p "
        "        where p.iclaim = e.iclaim and p.ifpce_id = e.ipayment "
        "        and p.ifpce_id_ext = e.ifpce_id_ext) as ideliver, "
        "       (select nname from officer r where r.iofficer = c.iofficer) as nname, "
        "       (select nname from officer s where s.iofficer = a.adjustment) as nadjust, "
        "       decode(g.fcard_class,'1','�j��','2','���N','') as fcard_class, "
        "       g.dply_begin "
        "  from ca_clm_process a, %s:appraisal b, %s:adjustment_ply c, "
        "       %s:settlement d, %s:payment e, %s:policy f, %s:ply_relation g "
        " where a.iclaim = b.iclaim  and  a.iclaim = c.iclaim "
        "   and a.iclaim = d.iclaim  and  d.iclaim = e.iclaim "
        "   and d.fstl = e.fstl and d.iclose_type = e.iclose_type "
        "   and a.ipolicy = f.ipolicy and a.ipolicy = g.ipolicy "
        "   and b.iacc_reason in ('21','22','23') and e.pay_kind in ('2','1') "
        "   and a.iclaim in (select unique iclaim from tb12041b where 1=1) "
        "   and exists (select * from %s:stl_ins_type where iclaim = e.iclaim "
        "               and fstl = e.fstl and iclose_type = e.iclose_type "
        "               and iins_type in ('11','18','76','82','96') "
        "               and dgroup is not null) "
        "   and (e.ipayment in (select sopt1 from tb12041a where 1=1) or "
        "        e.npayment in (select sopt1 from tb12041a where 1=1) or "
        "        a.iassured in (select sopt1 from tb12041a where 1=1) or "
        "        a.nassured in (select sopt1 from tb12041a where 1=1) or "
        "        a.itag in (select sopt1 from tb12041a where 1=1)) ",
        list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,
        list[i].dbname,list[i].dbname,list[i].dbname);
        
        printf("stmt11=[%s]\n",stmt11);
        $prepare pre_get11 from $stmt11;
        $execute pre_get11;
        
        /* �j���I */
        sprintf(stmt21,
        "insert into tb12041 "
        "select '17' as icompany, a.iclaim, '21' as iins_item, "
        "       decode(e.fstl,'2',e.mpayment*(-1),e.mpayment) as mpayment, "
        "       date(b.daccident) daccident, "
        "       (select dvp_abbr from sysdb:ca_dvp_ply_area "
        "        where b.iacc_area = dvp_code) as iarea, ''||c.itag, "
        "       ''||c.iengine, c.nassured, ''||c.iassured, ''||f.itel, "
        "       ''||f.mobil_phone, f.aassured, b.nacc_driver, b.iacc_license, "
        "       ''||(select max(y.itel) from ca_ver_relation x,ca_clm_victim_data y "
        "       where x.iverify = y.iclaim and x.iclaim = a.iclaim "
        "       and y.ivictim = b.iacc_license) as iacc_tel, "
        "       ''||(select max(imovephone) from cu_customer "
        "       where ifpce_id = b.iacc_license) as iacc_movephone, "
        "       case when (nvl((select max(y.avictim) from ca_ver_relation x,ca_clm_victim_data y "
        "            where x.iverify = y.iclaim and x.iclaim = a.iclaim "
        "            and y.ivictim = b.iacc_license),' ') = ' ') then "
        "            (select max(aperm_con) from cu_customer "
        "             where ifpce_id = b.iacc_license) else ' ' end as avicassured, "
        "       ''||(select max(mm.itag) from ca_property mm,ca_ver_relation nn "
        "       where mm.iverify = nn.iverify and nn.iclaim  = a.iclaim "
        "       and mm.ipro_no = (select min(ipro_no) from ca_pro_ins "
        "       where iclaim = a.iclaim and iins_type = '32')) as i32tag, "
        "       (select max(mm.npro) from ca_property mm,ca_ver_relation nn "
        "        where mm.iverify = nn.iverify and nn.iclaim  = a.iclaim "
        "        and mm.ipro_no = (select min(ipro_no) from ca_pro_ins "
        "        where iclaim = a.iclaim and iins_type = '32')) as i32npro, "
        "       ''||(select max(mm.iengine) from ca_property mm,ca_ver_relation nn "
        "       where mm.iverify = nn.iverify and nn.iclaim  = a.iclaim "
        "       and mm.ipro_no = (select min(ipro_no) from ca_pro_ins "
        "       where iclaim = a.iclaim and iins_type = '32')) as i32engine, "
        "       (select max(nchi_full) from cu_customer where ifpce_id =  "
        "        (select max(mm.ivictim) from ca_property mm,ca_ver_relation nn "
        "         where mm.iverify = nn.iverify and nn.iclaim  = a.iclaim "
        "         and mm.ipro_no = (select min(ipro_no) from ca_pro_ins "
        "          where iclaim = a.iclaim and iins_type = '32'))) as i32nname, "
        "       (select max(pp.nassured) from ca_clm_victim_data pp,ca_ver_relation qq "
        "        where pp.iclaim = qq.iverify and qq.iclaim = a.iclaim "
        "        and pp.fvictim_car = 'E' and pp.itag = (select max(mm.itag) "
        "        from ca_property mm,ca_ver_relation nn "
        "          where mm.iverify = nn.iverify and nn.iclaim  = a.iclaim "
        "           and mm.ipro_no = (select min(ipro_no) from ca_pro_ins "
        "            where iclaim = a.iclaim and iins_type = '32'))) as i32ndriver, "
        "       (select replace(max(pp.ivictim),'*','') "
        "        from ca_clm_victim_data pp,ca_ver_relation qq "
        "        where pp.iclaim = qq.iverify and qq.iclaim = a.iclaim "
        "        and pp.fvictim_car = 'E' and pp.itag = (select max(mm.itag) "
        "        from ca_property mm,ca_ver_relation nn "
        "        where mm.iverify = nn.iverify and nn.iclaim  = a.iclaim "
        "         and mm.ipro_no = (select min(ipro_no) from ca_pro_ins "
        "         where iclaim = a.iclaim and iins_type = '32'))) as i32idriver,"
        "       ''||(select replace(max(pp.itel),'*','') "
        "       from ca_clm_victim_data pp,ca_ver_relation qq "
        "       where pp.iclaim = qq.iverify  and qq.iclaim = a.iclaim "
        "       and pp.fvictim_car = 'E' and pp.itag = (select max(mm.itag) "
        "       from ca_property mm,ca_ver_relation nn "
        "       where mm.iverify = nn.iverify and nn.iclaim  = a.iclaim "
        "        and mm.ipro_no = (select min(ipro_no) from ca_pro_ins "
        "        where iclaim = a.iclaim and iins_type = '32'))) as i32idritel,"
        "       ' ' as i32idritel2, (select max(pp.avictim) "
        "       from ca_clm_victim_data pp,ca_ver_relation qq "
        "       where pp.iclaim = qq.iverify  and qq.iclaim = a.iclaim "
        "       and pp.fvictim_car = 'E' and pp.itag = (select max(mm.itag) "
        "       from ca_property mm,ca_ver_relation nn where mm.iverify = nn.iverify "
        "       and nn.iclaim  = a.iclaim and mm.ipro_no = "
        "       (select min(ipro_no) from ca_pro_ins where iclaim = a.iclaim "
        "        and iins_type = '32'))) as i32avictim, "
        "       (select ff.nassured from ca_clm_victim_data ff, ca_ver_relation gg "
        "        where ff.iclaim = gg.iverify and gg.iclaim = a.iclaim "
        "        and ff.ivictim = (select max(ivictim) from ca_human_est "
        "        where iclaim = a.iclaim and fhuman = '0')) as nvictim, "
        "       (select max(ivictim) from ca_human_est where iclaim = a.iclaim "
        "        and fhuman = '0') as ivictim, "
        "       ''||(select ff.itel from ca_clm_victim_data ff, ca_ver_relation gg "
        "        where ff.iclaim = gg.iverify and gg.iclaim = a.iclaim "
        "        and ff.ivictim = (select max(ivictim) from ca_human_est "
        "        where iclaim = a.iclaim and fhuman = '0')) as ivictim_tel1,"
        "       ' ' as ivictim_tel2, "
        "       (select replace(y.nforce_name,'*','') from ca_ver_relation x,ca_verify y "
        "        where x.iverify = y.iverify and x.iclaim = a.iclaim) as nforce_name, "
        "       (select replace(y.npolice,'*','') from ca_ver_relation x,ca_verify y "
        "        where x.iverify = y.iverify and x.iclaim = a.iclaim) as npolice, "
        "       (select max(ncode) from cu_code_data ccd,ca_human_est che "
        "        where ccd.itype  = 'BV' and ccd.icode  = che.ioffice "
        "        and che.iclaim = a.iclaim) as noffice_name, "
        "       (select replace(max(nprocurator),'*','') from ca_human_est "
        "        where iclaim = a.iclaim and fhuman = '0') as nprocurator, "
        "       (select replace(max(ninspector),'*','')  from ca_human_est "
        "        where iclaim = a.iclaim and fhuman = '0') as ninspector, "
        "       (select replace(max(nhospital),'*','')   from ca_human_est "
        "        where iclaim = a.iclaim and fhuman = '0') as nhospital, "
        "       (select replace(max(ndoctor),'*','')     from ca_human_est "
        "        where iclaim = a.iclaim and fhuman = '0') as ndoctor, "
        "       case when e.xsettle_type = '6' then "
        "           ''||replace(nvl((select ifpce_id from ca_factory "
        "           where ifactory = e.ipayment and ifactory_ext = ''),e.ipayment),'*','') "
        "       else ' ' end as icar_factory, ' ' nowner, e.npayment, "
        "       case when e.xsettle_type = '6' then "
        "            ''||replace(nvl((select ifpce_id from ca_factory "
        "            where ifactory = e.ipayment and ifactory_ext = ''), "
        "            case when length(trim(e.ipayment)) < 8 then ' ' else "
        "            e.ipayment end), '*','') else "
        "            case when length(trim(e.ipayment)) < 8 then ' ' "
        "            else e.ipayment end  end as ipaymenta, "
        "       ''||(select max(tphone_ext_con) from cu_customer "
        "       where ifpce_id = e.ipayment) as ipay_tphone, "
        "       ''||rtrim(e.xibank) || rtrim(e.xiaccount) as xiaccount, "
        "       decode(e.xfpay_cond,'1','�{��','2','�䲼','3','�״�','') as xfpay_cond, "
        "       (select max(k.dpay) from ao_stl_obj_close k "
        "        where k.iclose = e.iclaim and k.fstl = e.fstl "
        "        and k.iclose_type = cast(e.iclose_type as char(5)) "
        "        and k.istl_obj = e.ipayment and k.istl_obj_ext = e.ifpce_id_ext) as dpay, "
        "       (select max(p.ideliver) from ca_sign_receipt p "
        "        where p.iclaim = e.iclaim and p.ifpce_id = e.ipayment "
        "        and p.ifpce_id_ext = e.ifpce_id_ext) as ideliver, "
        "       (select nname from officer r where r.iofficer = c.iofficer) as nname, "
        "       (select nname from officer s where s.iofficer = a.adjustment) as nadjust, "
        "       decode(h.fcard_class,'1','�j��','2','���N','') as fcard_class, "
        "       h.dply_begin "
        "  from ca_clm_process a, %s:appraisal b, %s:adjustment_ply c, "
        "       %s:settlement d, %s:payment e, %s:policy f, %s:ca_stl_victim g, "
        "       %s:ply_relation h "
        " where a.iclaim = b.iclaim  and  a.iclaim = c.iclaim "
        "   and a.iclaim = d.iclaim  and  d.iclaim = e.iclaim "
        "   and d.fstl   =  e.fstl   and  d.iclose_type =  e.iclose_type "
        "   and d.iclaim =  g.iclaim and  d.fstl = g.fstl "
        "   and d.iclose_type = g.iclose_type and g.iins_item[1] in ('C') "
        "   and g.dgroup is not null  and a.ipolicy = f.ipolicy "
        "   and a.ipolicy = h.ipolicy and b.fcard_class =  '1' "
        "   and e.pay_kind    in ('5') "
        "   and a.iclaim in (select unique iclaim from tb12041b where 1=1) "
        "   and (e.ipayment in (select sopt1 from tb12041a where 1=1) or "
        "        e.npayment in (select sopt1 from tb12041a where 1=1) or "
        "        a.iassured in (select sopt1 from tb12041a where 1=1) or "
        "        a.nassured in (select sopt1 from tb12041a where 1=1) or "
        "        a.itag in (select sopt1 from tb12041a where 1=1)) ",
        list[i].dbname, list[i].dbname, list[i].dbname, list[i].dbname,
        list[i].dbname, list[i].dbname, list[i].dbname);
        
        printf("stmt21=[%s]\n",stmt21);
        $prepare pre_get21 from $stmt21;
        $execute pre_get21;
        
        
        /* �ĤT�H�d��:�ˮ` */
        sprintf(stmt31,"insert into tb12041 "
        "select '17' as icompany, a.iclaim, (select min(x.iins_type_rule) from %s:stl_ins_type y, insurance_type x "
        "                where y.iins_type = x.iins_type and iclaim = e.iclaim  and  fstl = e.fstl "
        "                  and iclose_type  = e.iclose_type and iins_type_rule in ('31','47','62') "
        "                  and dgroup is not null) as iins_type, "
        "       decode(e.fstl,'2',e.mpayment*(-1),e.mpayment) as mpayment, "
        "       date(b.daccident) daccident, (select dvp_abbr from sysdb:ca_dvp_ply_area "
        "       where b.iacc_area = dvp_code) as iarea, ''||c.itag, ''||c.iengine, "
        "       c.nassured, ''||c.iassured, ''||f.itel, ''||f.mobil_phone, "
        "       f.aassured, b.nacc_driver, b.iacc_license, ''||(select max(y.itel) "
        "       from ca_ver_relation x,ca_clm_victim_data y where x.iverify = y.iclaim "
        "       and x.iclaim = a.iclaim and y.ivictim = b.iacc_license) as iacc_tel, "
        "       ''||(select max(imovephone) from cu_customer "
        "       where ifpce_id = b.iacc_license) as iacc_movephone, "
        "       case when (nvl((select max(y.avictim) from ca_ver_relation x,ca_clm_victim_data y "
        "            where x.iverify = y.iclaim and x.iclaim = a.iclaim "
        "            and y.ivictim = b.iacc_license),' ') = ' ') then "
        "            (select max(aperm_con) from cu_customer "
        "             where ifpce_id = b.iacc_license) else ' ' end as avicassured, "
        "       ''||(select max(mm.itag) from ca_property mm,ca_ver_relation nn "
        "       where mm.iverify = nn.iverify and nn.iclaim  = a.iclaim "
        "       and mm.ipro_no = (select min(ipro_no) from ca_pro_ins "
        "       where iclaim = a.iclaim and iins_type = '32')) as i32tag, "
        "       (select max(mm.npro) from ca_property mm,ca_ver_relation nn "
        "       where mm.iverify = nn.iverify  and nn.iclaim  = a.iclaim "
        "       and mm.ipro_no = (select min(ipro_no) from ca_pro_ins "
        "       where iclaim = a.iclaim and iins_type = '32')) as i32npro, "
        "       ''||(select max(mm.iengine) from ca_property mm,ca_ver_relation nn "
        "       where mm.iverify = nn.iverify and nn.iclaim  = a.iclaim "
        "       and mm.ipro_no = (select min(ipro_no) from ca_pro_ins "
        "       where iclaim = a.iclaim and iins_type = '32')) as i32engine, "
        "       (select max(nchi_full) from cu_customer  where ifpce_id =  "
        "       (select max(mm.ivictim) from ca_property mm,ca_ver_relation nn "
        "       where mm.iverify = nn.iverify and nn.iclaim  = a.iclaim "
        "       and mm.ipro_no = (select min(ipro_no) from ca_pro_ins "
        "       where iclaim = a.iclaim and iins_type = '32'))) as i32nname, "
        "       (select max(pp.nassured) from ca_clm_victim_data pp,ca_ver_relation qq "
        "        where pp.iclaim = qq.iverify  and qq.iclaim = a.iclaim "
        "        and pp.fvictim_car = 'E' and pp.itag = (select max(mm.itag) "
        "        from ca_property mm,ca_ver_relation nn where mm.iverify = nn.iverify "
        "        and nn.iclaim  = a.iclaim and mm.ipro_no = (select min(ipro_no) "
        "        from ca_pro_ins where iclaim = a.iclaim and iins_type = '32'))) as i32ndriver, "
        "       (select replace(max(pp.ivictim),'*','') "
        "        from ca_clm_victim_data pp,ca_ver_relation qq "
        "        where pp.iclaim = qq.iverify  and qq.iclaim = a.iclaim "
        "        and pp.fvictim_car = 'E' and pp.itag = (select max(mm.itag) "
        "        from ca_property mm,ca_ver_relation nn where mm.iverify = nn.iverify "
        "        and nn.iclaim  = a.iclaim and mm.ipro_no = (select min(ipro_no) "
        "        from ca_pro_ins where iclaim = a.iclaim and iins_type = '32'))) as i32idriver, "
        "       ''||(select replace(max(pp.itel),'*','') "
        "        from ca_clm_victim_data pp,ca_ver_relation qq "
        "        where pp.iclaim = qq.iverify and qq.iclaim = a.iclaim "
        "        and pp.fvictim_car = 'E' and pp.itag = (select max(mm.itag) "
        "        from ca_property mm,ca_ver_relation nn where mm.iverify = nn.iverify "
        "        and nn.iclaim  = a.iclaim and mm.ipro_no = (select min(ipro_no) "
        "        from ca_pro_ins where iclaim = a.iclaim and iins_type = '32'))) as i32idritel, "
        "       ' ' as i32idritel2, (select max(pp.avictim) "
        "        from ca_clm_victim_data pp,ca_ver_relation qq "
        "        where pp.iclaim = qq.iverify  and qq.iclaim = a.iclaim "
        "        and pp.fvictim_car = 'E' and pp.itag =  (select max(mm.itag) "
        "        from ca_property mm,ca_ver_relation nn where mm.iverify = nn.iverify "
        "        and nn.iclaim  = a.iclaim and mm.ipro_no = (select min(ipro_no) "
        "        from ca_pro_ins where iclaim = a.iclaim and iins_type = '32'))) as i32avictim, "
        "       (select ff.nassured from ca_clm_victim_data ff, ca_ver_relation gg "
        "        where ff.iclaim = gg.iverify and gg.iclaim = a.iclaim "
        "        and ff.ivictim = (select max(ivictim) from ca_human_est "
        "        where iclaim = a.iclaim and fhuman = '2')) as nvictim, "
        "        (select max(ivictim) from ca_human_est where iclaim = a.iclaim "
        "        and fhuman = '2') as ivictim, "
        "       ''||(select ff.itel from ca_clm_victim_data ff, ca_ver_relation gg "
        "       where ff.iclaim = gg.iverify and gg.iclaim = a.iclaim "
        "       and ff.ivictim = (select max(ivictim) from ca_human_est "
        "       where iclaim = a.iclaim and fhuman = '2')) as ivictim_tel1, "
        "       ' ' as ivictim_tel2, (select replace(y.nforce_name,'*','') "
        "       from ca_ver_relation x,ca_verify y where x.iverify = y.iverify "
        "       and x.iclaim = a.iclaim) as nforce_name, "
        "       (select replace(y.npolice,'*','') from ca_ver_relation x,ca_verify y "
        "        where x.iverify = y.iverify and x.iclaim = a.iclaim) as npolice, "
        "       (select max(ncode) from cu_code_data ccd,ca_human_est che "
        "        where ccd.itype  = 'BV' and ccd.icode  = che.ioffice "
        "       and che.iclaim = a.iclaim) as noffice_name, "
        "       (select replace(max(nprocurator),'*','') from ca_human_est "
        "        where iclaim = a.iclaim and fhuman = '2') as nprocurator, "
        "       (select replace(max(ninspector),'*','')  from ca_human_est "
        "        where iclaim = a.iclaim and fhuman = '2') as ninspector, "
        "       (select replace(max(nhospital),'*','')   from ca_human_est "
        "        where iclaim = a.iclaim and fhuman = '2') as nhospital, "
        "       (select replace(max(ndoctor),'*','') from ca_human_est "
        "        where iclaim = a.iclaim and fhuman = '2') as ndoctor, "
        "       case when e.xsettle_type = '6' then "
        "            ''||replace(nvl((select ifpce_id from ca_factory "
        "            where ifactory = e.ipayment and ifactory_ext = ''),e.ipayment),'*','') "
        "       else ' ' end as icar_factory, ' ' nowner, e.npayment, "
        "       case when e.xsettle_type = '6' then "
        "            ''||replace(nvl((select ifpce_id from ca_factory "
        "            where ifactory = e.ipayment and ifactory_ext = ''), "
        "            case when length(trim(e.ipayment)) < 8 then ' ' else e.ipayment end),'*','') "
        "            else case when length(trim(e.ipayment)) < 8 then ' ' else e.ipayment end "
        "       end as ipaymenta, ''||(select max(tphone_ext_con) from cu_customer "
        "       where ifpce_id = e.ipayment) as ipay_tphone, "
        "       ''||rtrim(e.xibank) || rtrim(e.xiaccount) as xiaccount, "
        "       decode(e.xfpay_cond,'1','�{��','2','�䲼','3','�״�','') as xfpay_cond, "
        "       (select max(k.dpay) from ao_stl_obj_close k where k.iclose = e.iclaim "
        "        and k.fstl = e.fstl and k.iclose_type = cast(e.iclose_type as char(5)) "
        "        and k.istl_obj = e.ipayment and k.istl_obj_ext = e.ifpce_id_ext) as dpay, "
        "       (select max(p.ideliver) from ca_sign_receipt p where p.iclaim = e.iclaim "
        "       and p.ifpce_id = e.ipayment and p.ifpce_id_ext = e.ifpce_id_ext) as ideliver, "
        "       (select nname from officer r where r.iofficer = c.iofficer) as nname, "
        "       (select nname from officer s where s.iofficer = a.adjustment) as nadjust, "
        "       decode(g.fcard_class,'1','�j��','2','���N','') as fcard_class, "
        "       g.dply_begin "
        "  from ca_clm_process a, %s:appraisal b, %s:adjustment_ply c, "
        "       %s:settlement d, %s:payment e, %s:policy f, %s:ply_relation g "
        " where a.iclaim = b.iclaim and a.iclaim = c.iclaim "
        "   and a.iclaim = d.iclaim and d.iclaim = e.iclaim "
        "   and d.fstl =  e.fstl and d.iclose_type =  e.iclose_type "
        "   and a.ipolicy = f.ipolicy and a.ipolicy =  g.ipolicy "
        "   and e.pay_kind in ('5') "
        "   and exists (select * from %s:stl_ins_type m, sysdb:insurance_type n "
        "                where m.iins_type = n.iins_type "
        "                  and m.iclaim = e.iclaim  and  m.fstl = e.fstl "
        "                  and m.iclose_type  = e.iclose_type "
        "                  and m.dgroup is not null "
        "                  and n.iins_type_rule in ('31','47','62')) "
        "   and a.iclaim in (select unique iclaim from tb12041b where 1=1) "
        "   and (e.ipayment in (select sopt1 from tb12041a where 1=1) or "
        "        e.npayment in (select sopt1 from tb12041a where 1=1) or "
        "        a.iassured in (select sopt1 from tb12041a where 1=1) or "
        "        a.nassured in (select sopt1 from tb12041a where 1=1) or "
        "        a.itag in (select sopt1 from tb12041a where 1=1)) ",
        list[i].dbname, list[i].dbname, list[i].dbname, list[i].dbname,
        list[i].dbname, list[i].dbname, list[i].dbname);
        printf("stmt31=[%s]\n",stmt31);
        $prepare pre_get31 from $stmt31;
        $execute pre_get31;
        
        
        /* �ĤT�H�d��:�]�l */
        sprintf(stmt32,"insert into tb12041 "
        "select '17' as icompany, a.iclaim, '32' as iins_type, "
        "       decode(e.fstl,'2',e.mpayment*(-1),e.mpayment) as mpayment, "
        "       date(b.daccident) daccident, (select dvp_abbr from sysdb:ca_dvp_ply_area "
        "       where b.iacc_area = dvp_code) as iarea, ''||c.itag, ''||c.iengine, "
        "       c.nassured, ''||c.iassured, ''||f.itel, ''||f.mobil_phone, "
        "       f.aassured, b.nacc_driver, b.iacc_license, "
        "       ''||(select max(y.itel) from ca_ver_relation x,ca_clm_victim_data y "
        "       where x.iverify = y.iclaim and x.iclaim = a.iclaim "
        "       and y.ivictim = b.iacc_license) as iacc_tel, "
        "       ''||(select max(imovephone) from cu_customer "
        "       where ifpce_id = b.iacc_license) as iacc_movephone, "
        "       case when (nvl((select max(y.avictim) from ca_ver_relation x,ca_clm_victim_data y "
        "            where x.iverify = y.iclaim and x.iclaim = a.iclaim "
        "            and y.ivictim = b.iacc_license),' ') = ' ') then "
        "            (select max(aperm_con) from cu_customer "
        "            where ifpce_id = b.iacc_license) else ' ' end as avicassured, "
        "       ''||(select max(mm.itag) from ca_property mm,ca_ver_relation nn "
        "       where mm.iverify = nn.iverify and nn.iclaim  = a.iclaim "
        "       and mm.ipro_no = (select min(ipro_no) from ca_pro_ins "
        "       where iclaim = a.iclaim and iins_type = '32')) as i32tag, "
        "       (select max(mm.npro) from ca_property mm,ca_ver_relation nn "
        "        where mm.iverify = nn.iverify and nn.iclaim  = a.iclaim "
        "        and mm.ipro_no = (select min(ipro_no) from ca_pro_ins "
        "        where iclaim = a.iclaim and iins_type = '32')) as i32npro, "
        "       ''||(select max(mm.iengine) from ca_property mm,ca_ver_relation nn "
        "        where mm.iverify = nn.iverify  and nn.iclaim  = a.iclaim "
        "        and mm.ipro_no = (select min(ipro_no) from ca_pro_ins "
        "        where iclaim = a.iclaim and iins_type = '32')) as i32engine, "
        "       (select max(nchi_full) from cu_customer where ifpce_id =  "
        "        (select max(mm.ivictim) from ca_property mm,ca_ver_relation nn "
        "         where mm.iverify = nn.iverify and nn.iclaim  = a.iclaim "
        "         and mm.ipro_no = (select min(ipro_no) from ca_pro_ins "
        "         where iclaim = a.iclaim and iins_type = '32'))) as i32nname, "
        "       (select max(pp.nassured) from ca_clm_victim_data pp,ca_ver_relation qq "
        "        where pp.iclaim = qq.iverify and qq.iclaim = a.iclaim "
        "        and pp.fvictim_car = 'E' and pp.itag =  (select max(mm.itag) "
        "        from ca_property mm,ca_ver_relation nn where mm.iverify = nn.iverify "
        "        and nn.iclaim  = a.iclaim and mm.ipro_no = (select min(ipro_no) "
        "        from ca_pro_ins where iclaim = a.iclaim and iins_type = '32'))) as i32ndriver, "
        "       (select replace(max(pp.ivictim),'*','') "
        "        from ca_clm_victim_data pp,ca_ver_relation qq "
        "        where pp.iclaim = qq.iverify and qq.iclaim = a.iclaim "
        "        and pp.fvictim_car = 'E' and pp.itag = (select max(mm.itag) "
        "        from ca_property mm,ca_ver_relation nn "
        "        where mm.iverify = nn.iverify and nn.iclaim  = a.iclaim "
        "        and mm.ipro_no = (select min(ipro_no) from ca_pro_ins   "
        "        where iclaim = a.iclaim and iins_type = '32'))) as i32idriver, "
        "       ''||(select replace(max(pp.itel),'*','') "
        "        from ca_clm_victim_data pp,ca_ver_relation qq "
        "        where pp.iclaim = qq.iverify and qq.iclaim = a.iclaim "
        "        and pp.fvictim_car = 'E' and pp.itag = (select max(mm.itag) "
        "        from ca_property mm,ca_ver_relation nn where mm.iverify = nn.iverify "
        "        and nn.iclaim  = a.iclaim and mm.ipro_no = (select min(ipro_no) "
        "        from ca_pro_ins where iclaim = a.iclaim and iins_type = '32'))) as i32idritel, "
        "       ' ' as i32idritel2, (select max(pp.avictim) "
        "        from ca_clm_victim_data pp,ca_ver_relation qq "
        "        where pp.iclaim = qq.iverify  and qq.iclaim = a.iclaim "
        "        and pp.fvictim_car = 'E' and pp.itag = (select max(mm.itag) "
        "        from ca_property mm,ca_ver_relation nn where mm.iverify = nn.iverify "
        "        and nn.iclaim  = a.iclaim and mm.ipro_no = (select min(ipro_no) "
        "        from ca_pro_ins where iclaim = a.iclaim and iins_type = '32'))) as i32avictim, "
        "       (select ff.nassured from ca_clm_victim_data ff, ca_ver_relation gg "
        "        where ff.iclaim = gg.iverify and gg.iclaim = a.iclaim "
        "        and ff.ivictim = (select max(ivictim) from ca_human_est "
        "        where iclaim = a.iclaim and fhuman = '2')) as nvictim, "
        "       (select max(ivictim) from ca_human_est where iclaim = a.iclaim "
        "        and fhuman = '2') as ivictim, ''||(select ff.itel "
        "       from ca_clm_victim_data ff, ca_ver_relation gg "
        "       where ff.iclaim = gg.iverify and gg.iclaim = a.iclaim "
        "       and ff.ivictim = (select max(ivictim) from ca_human_est "
        "       where iclaim = a.iclaim and fhuman = '2')) as ivictim_tel1, "
        "      ' ' as ivictim_tel2, (select replace(y.nforce_name,'*','') "
        "       from ca_ver_relation x,ca_verify y where x.iverify = y.iverify "
        "       and x.iclaim = a.iclaim) as nforce_name, "
        "      (select replace(y.npolice,'*','') from ca_ver_relation x,ca_verify y "
        "        where x.iverify = y.iverify and x.iclaim = a.iclaim) as npolice, "
        "      (select max(ncode) from cu_code_data ccd,ca_human_est che "
        "       where ccd.itype  = 'BV' and ccd.icode  = che.ioffice "
        "       and che.iclaim = a.iclaim) as noffice_name, "
        "      (select replace(max(nprocurator),'*','') from ca_human_est "
        "       where iclaim = a.iclaim and fhuman = '2') as nprocurator, "
        "      (select replace(max(ninspector),'*','')  from ca_human_est "
        "       where iclaim = a.iclaim and fhuman = '2') as ninspector, "
        "      (select replace(max(nhospital),'*','')   from ca_human_est "
        "       where iclaim = a.iclaim and fhuman = '2') as nhospital, "
        "      (select replace(max(ndoctor),'*','')     from ca_human_est "
        "       where iclaim = a.iclaim and fhuman = '2') as ndoctor, "
        "      case when e.xsettle_type = '6' then "
        "           ''||replace(nvl((select ifpce_id from ca_factory "
        "           where ifactory = e.ipayment and ifactory_ext = ''),e.ipayment),'*','') "
        "      else ' ' end as icar_factory, ' ' nowner,  e.npayment, "
        "      case when e.xsettle_type = '6' then "
        "           ''||replace(nvl((select ifpce_id from ca_factory "
        "           where ifactory = e.ipayment and ifactory_ext = ''), "
        "           case when length(trim(e.ipayment)) < 8 then ' ' else e.ipayment end),'*','') "
        "           else case when length(trim(e.ipayment)) < 8 then ' ' else e.ipayment end "
        "      end as ipaymenta, ''||(select max(tphone_ext_con) from cu_customer "
        "      where ifpce_id = e.ipayment) as ipay_tphone, "
        "      ''||rtrim(e.xibank) || rtrim(e.xiaccount) as xiaccount, "
        "      decode(e.xfpay_cond,'1','�{��','2','�䲼','3','�״�','') as xfpay_cond, "
        "      (select max(k.dpay) from ao_stl_obj_close k "
        "       where k.iclose = e.iclaim and k.fstl = e.fstl  "
        "       and k.iclose_type = cast(e.iclose_type as char(5)) "
        "       and k.istl_obj = e.ipayment and k.istl_obj_ext = e.ifpce_id_ext) as dpay, "
        "      (select max(p.ideliver) from ca_sign_receipt p "
        "       where p.iclaim = e.iclaim and p.ifpce_id = e.ipayment "
        "       and p.ifpce_id_ext = e.ifpce_id_ext) as ideliver, "
        "      (select nname from officer r where r.iofficer = c.iofficer) as nname, "
        "      (select nname from officer s where s.iofficer = a.adjustment) as nadjust, "
        "      decode(g.fcard_class,'1','�j��','2','���N','') as fcard_class, "
        "      g.dply_begin "
        " from ca_clm_process a, %s:appraisal b, %s:adjustment_ply c, %s:settlement d, "
        "      %s:payment e, %s:policy f, %s:ply_relation g "
        "where a.iclaim = b.iclaim  and a.iclaim = c.iclaim "
        "  and a.iclaim = d.iclaim  and d.iclaim = e.iclaim "
        "  and d.fstl = e.fstl and d.iclose_type =  e.iclose_type "
        "  and a.ipolicy = f.ipolicy  and a.ipolicy = g.ipolicy "
        "  and e.pay_kind    in ('3') "
        "  and exists (select * from %s:stl_ins_type where iclaim = e.iclaim "
        "              and fstl = e.fstl and iclose_type = e.iclose_type "
        "              and iins_type = '32' and dgroup is not null) "
        "   and a.iclaim in (select unique iclaim from tb12041b where 1=1) "
        "   and (e.ipayment in (select sopt1 from tb12041a where 1=1) or "
        "        e.npayment in (select sopt1 from tb12041a where 1=1) or "
        "        a.iassured in (select sopt1 from tb12041a where 1=1) or "
        "        a.nassured in (select sopt1 from tb12041a where 1=1) or "
        "        a.itag in (select sopt1 from tb12041a where 1=1)) ",
        list[i].dbname, list[i].dbname, list[i].dbname, list[i].dbname,
        list[i].dbname, list[i].dbname, list[i].dbname);
        printf("stmt32=[%s]\n",stmt32);
        $prepare pre_get32 from $stmt32;
        $execute pre_get32;
        
        /* ��O���� */
        /* "   and a.dpolicy between '%s' and '%s'  and a.dply_close is not null " 
               , dbegin, dend*/
        sprintf(stmt17,"insert into tb12041 "
            "select '17' as icompany, ' ' as iclaim,  ' ' as iins_type,"
            "       0 as mpayment, ' ' as daccident, ' ' as iarea, ''||b.itag, "
            "       ''||b.iengine, b.nassured, ''||b.iassured, ''||b.itel, ''||b.mobil_phone, "
            "       b.aassured, ' ' as nacc_driver, ' ' as iacc_license, "
            "       ' ' as iacc_tel,  ' ' as iacc_movephone, ' ' as avicassured, "
            "       ' ' as i32tag, ' ' as i32npro, ' ' as i32engine, ' ' as i32nnamem, "
            "       ' ' as i32ndriver, ' ' as i32idriver, ' ' as i32idritel, "
            "       ' ' as i32idritel2, ' ' as i32avictim, ' ' as nvictim, "
            "       ' ' as ivictim, ' ' as ivictim_tel1, ' ' as ivictim_tel2, "
            "       ' ' as nforce_name, ' ' as npolice, ' ' as noffice_name, "
            "       ' ' as nprocurator, ' ' as ninspector, ' ' as nhospital, "
            "       ' ' as ndoctor, ' ' as icar_factory, ' ' as nowner, "
            "       ' ' as npayment, ' ' as ipaymenta, ' ' as ipay_tphone, "
            "       ' ' as xiaccount, ' ' as xfpay_cond, ' ' as dpay, ' ' as ideliver, "
            "       (select nname from officer where iofficer = a.iofficer) as nname, "
            "       ' ' as nadjust, a.fcard_class, a.dply_begin "
            "  from %s:ply_relation a, %s:policy b "
            " where a.ipolicy = b.ipolicy "
            "   and a.ipolicy in (select unique iclaim from tb12041b where 1=1)  "
            "   and (b.iassured in (select sopt1 from tb12041a where 1=1) or "
            "        b.nassured in (select sopt1 from tb12041a where 1=1) or "
            "        b.itag in (select sopt1 from tb12041a where 1=1)) ",
            list[i].dbname, list[i].dbname);
            
            printf("stmt17=[%s]\n",stmt17); 
            $prepare pre_get17 from $stmt17;
            $execute pre_get17;
    }
    
    $select count(*) into $icnt1
       from tb12041
      where 1=1;
      
    if (icnt1 == 0)
    $insert into tb12041 (iclaim) values ("�d�L���");
    printf("�X�p [%d] ����� \n",icnt1);
    
    return M_CM_OK;
    
errexit:
    sqlfatal();
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}

/* ------------------------------------------------------------------------- */
long car1204_print()
{
    int     rc;
    char    stmt[200];
    

    $WHENEVER SQLERROR GOTO errexit;
    
    strcpy(stmt,"select * from tb12041 where 1=1 ORDER BY 2 ");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);

    if (rc != SUCCESS) {
        sprintf(msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }
    
    return M_CM_OK;
    
errexit:
    sqlfatal();
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}

