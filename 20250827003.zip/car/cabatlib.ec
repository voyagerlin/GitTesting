/***********************************************************************
 *                                                                     *
 *   program id   : cabatlib.ec                                        *
 *   program name : ���I�妸�@��function                               *
 *   date written : 2011/02/09                                         *
 *   author       : Jessie                                             *
 ********************************************************************* *
 *                             MODIFICATION LOG                        *
 *                                                                     *
 *   DATE         SE                     DESCRIPTION                   *
 * --------  -------------  ----------------------------------------   *
 *                                                                     *
 **********************************************************************/
#include <stdio.h>
#include <api_xsrv.h>
#include <comdata.h>
#include <globdata.h>
#include <commsgs.h>
#include <carmsgs.h>
#include <cmnmsgs.h>
#include <decimal.h>
#include <math.h>
#include <stdlib.h>;
#include <string.h>;
#include <ctype.h>
#include "globdata.h"
#include "is_def.h"
#include "print.h"
#include "safeclib.h"

#define TRUE                  1
#define FALSE                 0
#define DATENULL              0x80000000L
#define FOUND                 sqlca.sqlcode!=SQLNOTFOUND
#define NOT_FOUND             sqlca.sqlcode==SQLNOTFOUND

char   v_sMsg[512];
int *iGetChinesePos();
int *iGetPartStr();

/**********************************************************************/
/*   �ǤJ�O�渹��X���O�檺�k�ݸ�Ʈw                                 */
/**********************************************************************/
char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
     char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
     static char sTmp_db_name[31];
printf("--- sIpolicy=[%s]\n",sIpolicy);
     sTmp_db_name[0]='\0';
     if (*sIpolicy != '\0' && *sIpolicy !=' ')
     {
        sTmp_db_name[0]='\0';
        strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
        printf("sTmpScomp[%s]\n", sTmpScomp);
        strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
               USE_BRANCH_ID));
        strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
     }
     printf("sTmp_db_name[%s]\n", sTmp_db_name);
     return sTmp_db_name;
}

/**********************************************************************/
/*      �ǤJ�d���P�_�O�_���O�N��                                      */
/**********************************************************************/
long Isbigcomp(sIcard, sFcard_class)
char *sIcard, *sFcard_class;
{
     char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
     char sTmp_db_name[21];

     if (sFcard_class[0] == '1')
     {
         if (sIcard[2] == 'C' && isalpha(sIcard[3]))
              return TRUE;
         else
              return FALSE;
     }
     else if (sFcard_class[0] == '2')
     {
         if (isalpha(sIcard[2]))
              return TRUE;
         else
              return FALSE;
     }
     else
         return FALSE;
}

/**********************************************************************/
/*      �ǤJ�O�渹���O��@,�O��G                                     */
/**********************************************************************/
long split_policy(sIpolicy, sIpolicy1, sIpolicy2)
char *sIpolicy, *sIpolicy1, *sIpolicy2;
{
     strcpy(sIpolicy, trim(sIpolicy));
     printf("begin split_policy\n");

     if (strlen(sIpolicy) > CAR_POLICY_LEN)
     {
        strncpy(sIpolicy1, sIpolicy, CAR_POLICY_LEN);
        sIpolicy1[CAR_POLICY_LEN] = '\0';
        strncpy(sIpolicy2, sIpolicy+CAR_POLICY_LEN, CAR_TARGET_LEN);
        sIpolicy2[CAR_TARGET_LEN] = '\0';
        if (sIpolicy2[0]=='\0' || sIpolicy2[0]==' ') strcpy(sIpolicy2," ");
     }
     else
     {
        strcpy(sIpolicy1,sIpolicy);
        strcpy(sIpolicy2," ");
     }

     printf("---after split_policy -> sIpolicy[%s]\n", sIpolicy);
     printf("---after split_policy -> sIpolicy1[%s]\n", sIpolicy1);
     printf("---after split_policy -> sIpolicy2[%s]\n", sIpolicy2);

     return M_CM_OK;
}
/**********************************************************************/
/*  sTmpStr:   the string you want to format			      */
/*  iDatatype: the data type of the unformated string		      */
/*             1: integer    2: string                                */
/*             1: �Ʀr�e����0 2:��r�᭱�ɪť� 3:��r�e���ɪť�       */
/*             4: ��r�e������޸�(")�å[�W(||)���O, �Ҧp: "AAA"||   add by sylvia 100.12.28 for ���T�ǿ��ഫ */
/*             5: ��r�e������޸�(")���O, �Ҧp: "AAA"               add by sylvia 100.12.28 for ���T�ǿ��ഫ */
/*  iLength:   the string length after formated                       */
/**********************************************************************/
char *sformat_trade(pUnformat, iDatatype, iLength)
void *pUnformat;
int  iDatatype, iLength;
{
     static char sFormat[200], sTmpbuf[200], sTmpbuf1[200];
     int i=0, *iTmp, iTmp1=0;

     *sFormat = '\0';

     switch (iDatatype)
     {
          case 1:
                  iTmp = pUnformat;
                  strcpy(sTmpbuf, itoa(*iTmp));
                  for (i = 0 ; i < (iLength - strlen(sTmpbuf)) ; i++)
                        strcat(sFormat, "0");
                  strcat(sFormat, sTmpbuf);
                  break;
          case 2:
                  strcpy(sTmpbuf, trim(pUnformat));
                  strcpy(sFormat, sTmpbuf);
                  for (i = 0 ; i < (iLength - strlen(sTmpbuf)) ; i++)
                        strcat(sFormat, " ");
                  break;
          case 3:
                  strcpy(sTmpbuf, trim(pUnformat));
                  for (i = 0 ; i < (iLength - strlen(sTmpbuf)) ; i++)
                        strcat(sFormat, " ");
                  strcat(sFormat, sTmpbuf);
                  break;
          case 4:
                  strcpy(sTmpbuf1, rtrim(pUnformat));
                  printf("sTmpbuf1=[%s]iLength=[%d]pUnformat=[%s]\n",sTmpbuf1, iLength,pUnformat);
                  
                  iTmp1 = iGetPartStr(sTmpbuf1,iLength); /* ���r����� */
                  
               	strncpy(sTmpbuf,&sTmpbuf1[0],iTmp1);
               	sTmpbuf[iTmp1] = '\0';
               	/* if (strlen(sTmpbuf1) <= iLength)
               	{
               	   strcpy(sTmpbuf, sTmpbuf1);
               	   printf("1:sTmpbuf[[%s]\n",sTmpbuf);
               	   printf("1:sTmpbuf1[[%s]\n",sTmpbuf1);
               	}
               	else
               	{
                  	if ((sTmpbuf1[iLength-1] >= 0x81) && (sTmpbuf1[iLength-1] <= 0xFE))
                  	{
                  	   strncpy(sTmpbuf,&sTmpbuf1[0],iLength-1);
                  	   sTmpbuf[iLength-1] = '\0';
                  	   printf("2:sTmpbuf=[%s]\n",sTmpbuf);
                  	}
                  	else
                  	{
                  	   strncpy(sTmpbuf,&sTmpbuf1[0],iLength);
                  	   sTmpbuf[iLength] = '\0';
                  	   printf("3:sTmpbuf=[%s]\n",sTmpbuf);
                  	}
                  }*/
                  sprintf_s(sFormat, sizeof sFormat, "\"%1.*s\"||",iLength, sTmpbuf);
                  printf("******* sTmpbuf=[%s]  sFormat=[%s] iLength=[%d]\n",sTmpbuf,sFormat,iLength);
                  break;
                  
          case 5:
                  strcpy(sTmpbuf, trim(pUnformat));
                  printf("sTmpbuf=[%s]iLength=[%d]\n",sTmpbuf,iLength);
                  sprintf_s(sFormat, sizeof sFormat, "\"%1.*s\"",iLength,sTmpbuf);
                  break;
           default:
                  break;
     }
     printf(" line 190: sFormat[%s]\n",sFormat);
     return sFormat;
}
/*--------------------------------------------------------------------*/
long lGetNextMonth(pDate, iMonth)
char *pDate;
long iMonth;
{
     char sMM[3], sDD[3], sYYYY[5];
     long iMM=0, iDD=0, iYY=0;

     printf("->debug lGetNextMonth[%s]\n", pDate);

     strncpy(sMM, pDate, 2);
     sMM[2] = '\0';
     iMM = (atoi(sMM)+iMonth) % 12;
     if (iMM == 0)
         iMM = 12;
     printf("->debug iMM[%d]\n", iMM);

     return iMM;
}
/*--------------------------------------------------------------------*/
long lGetOneYearDays(lDate)
long lDate;
{
     short mdy[3];
     long  lLastYearDate=0, lOneYearDays=0, lRtnCode=0;

     printf("---lGetOneYearDays-----This Year [%s]\n", cm_edate_str(lDate));

     if (rjulmdy(lDate, mdy) != 0) return 365;

     mdy[2]--;

     if (mdy[0] == 2 && mdy[1] == 29) mdy[1] = 28;

     if (rmdyjul(mdy, &lLastYearDate) != 0) return 365;
     lOneYearDays = lDate - lLastYearDate;

     printf("---lGetOneYearDays-----Last Year [%s]\n", cm_edate_str(lLastYearDate));
     printf("---lGetOneYearDays-----Days [%d]\n", lOneYearDays);

     return lOneYearDays;
}
/*--------------------------------------------------------------------*/
double dbl_len8(fulldbl)
double fulldbl;
{
     int chk_flag=0;

     if (fulldbl < 0)
          chk_flag = 1;
     else
          chk_flag = 0;

     fulldbl = fabs(fulldbl);

     fulldbl = (floor(fulldbl*pow(10,8)))/pow(10,8);

     if (chk_flag == 1)
         return -1 * fulldbl;
     else
         return fulldbl;
}
/*--------------------------------------------------------------------*/
double dbl_len2(fulldbl)
$double fulldbl;
{
     /* �p���I�ĤT��L����i�� */
     int  chk_flag=0;
     long get_long=0;

     if (fulldbl < 0)
          chk_flag = 1;
     else
          chk_flag = 0;

     fulldbl = fabs(fulldbl);

     get_long = (long)((double)(fulldbl + 0.009) * 100.00);
     fulldbl  = (double)get_long / 100.00;

     if (chk_flag == 1)
         return -1 * fulldbl;
     else
         return fulldbl;
}
/*--------------------------------------------------------------------*/
double d45(num,num1)
double num;
int num1;
{
    long tmplong=0;
    double var1=0;
    double ten=0;
    int i=0;

    ten = 1;
    for(i = 1 ;i<=num1;i++)
    ten *= 10;

    num *= ten;
    if (num >= 0) var1 = 0.5;
    else var1 = (-0.5);

    num = num + var1;
    tmplong = num;

    num = tmplong/ten;
    return(num);
}
/*--------------------------------------------------------------------*/
/* �Ѳ�bgn_pos��ܲ�end_pos���J[*] */
char *replace_str(pUpString, bgn_pos, end_pos)
void *pUpString;
long bgn_pos, end_pos;
{
     static char sFormat[200];
     char sTmpBuf[200];
     int  i=0;

     *sFormat = '\0';

     printf("[replace_str]:pUpstring[%s]\n",pUpString);
     strncpy(sTmpBuf,pUpString,bgn_pos-1);
     sTmpBuf[bgn_pos-1]='\0';
     printf("[replace_str]:sTmpBuf[%s]\n",sTmpBuf);

     for (i = 0 ; i < (end_pos-(bgn_pos-1)) ; i++)
          strcat(sTmpBuf, "*");

     strcpy(sFormat, trim(sTmpBuf));
     printf("[replace_str]:sFormat[%s]\n",sFormat);

     return sFormat;
}
/*--------------------------------------------------------------------*/
/** ���o���^���q�������T���嵲����m **/
int *iGetChinesePos(sStrTmp,iPos)
char *sStrTmp;
int  iPos;
{
int  iTrueLen=0;
int  i=0,x=0;

     for(i = 0; i<= iPos; i++){
         if ((int)(sStrTmp[i]) >= 128){
                i++;
         }
     }
     return (i-1);
}

/* ------------------------------------------------------------------ */
/* ���o�r�꥿�T���_��m */
int *iGetPartStr(sInString,iGetlen)
char *sInString;
int  iGetlen;
{
   int i=0, j=0;
   i = 0; j = 0;
   
   if (strlen(sInString) <= iGetlen)
      i = strlen(sInString);
   else
   {
      for (i = 0 ; i < iGetlen ; i++)
      {
         if ((sInString[i] >= 0x81) && (sInString[i] <= 0xFE))
         {  /* ����Ĥ@�X */
            j++;
         }
         else if (((sInString[i] >= 0x40) && (sInString[i] <= 0x7E)) ||
                  ((sInString[i] >= 0xA1 ) && (sInString[i] <= 0xFE)))
         {  /* ����ĤG�X */
            j++;
         }
         else
         {
            /* �D���� */
            j = 0;
         }         
      }
   }
   
   if ((j == 0) || ((j % 2) == 0))
   {
      return i;
   }
   else
      return (i-1) ;
}

/*******************************************************************************************/
/* 1081225006_SC3 �X�R���[���ڥN�X                                                           */
/*******************************************************************************************/
/* str_split()�\��G����VB6�� Split()�A�D�n�ϥ�strtok_r() ��{�\��                             */ 
/*******************************************************************************************/
/* �i�禡�쫬�Gchar *strtok_r(char *str, const char *delim, char **saveptr);   �j            */
/* ����strtok���u�h������w���v�����J�����A�s�W�Ѽ�saveptr�A�Ω�s����ܤU�����y��m�����СB��Ȥ��ର�šF*/
/* strtok_r�b�Ĥ@���I�s�ɷ|���������ȡ]�o�N���ۨ��l�ȥi��NULL�^                                 */  
/* https://www.ibm.com/docs/en/aix/7.1?topic=programming-writing-reentrant-threadsafe-code */
/* ----------------------------------------------------------------------------------------*/
/* ==> strtok_r()�Bstrtok()�P str_split() �ϥΪ`�N�ƶ�                                       */
/*  1.�u�ӷ��r��Ѽơv �|�Q�ק�G�ӷ��r��ѼƤ����u���j�r���v�A�|�Q���N����\0���r���C                  */
/*    �A�ҥH�p�G�ӷ��r���٭n(�q�`�O�n)�~��ϥΡA���ӥ��ƻs��t�@���ܼƦA�ǤJfunction�C               */
/*  2.�s�򪺤��j�r���Q�����@�Ӥ��j�r���B�z�C Ex. "A01;B01;;C01"  => �B�z���G���P "A01;B01;C01"    */
/*  3.�r�ꭺ�������j�r���|�Q�����C Ex. ";A01;B01;C01;;"  => �B�z���G���P "A01;B01;C01"          */
/* ---------------------------------------------------------------------------------------*/

char** str_split(char* a_str, const char a_delim)
{
    char** result    = 0;
    char** result_re = 0;
    size_t count     = 0;
    char* tmp        = a_str;
    char* last_comma = 0;
    char* saveptr = NULL;
    char delim[2];
    delim[0] = a_delim;
    delim[1] = 0;

    /* Count how many elements will be extracted. */
    while (*tmp)
    {
        if (a_delim == *tmp)
        {
            count++;
            last_comma = tmp;
        }
        tmp++;
    }

    /* Add space for trailing token. */
    count += last_comma < (a_str + strlen(a_str) - 1);

    /* Add space for terminating null string so caller
       knows where the list of returned strings ends. */
    count++;

    result = malloc(sizeof(char*) * count);

	
    if (result)
    {
    	size_t idx  = 0;
        char* token = strtok_r(a_str, delim, &saveptr);

        while (token)
        {
            /*assert(idx < count);*/
            *(result + idx++) = strdup(token);
            token = strtok_r(0, delim, &saveptr);
        }
        /*assert(idx == count - 1);*/
        *(result + idx) = 0;
        idx = 0;
    }
    
    result_re = result;
	free(result);
    return result_re;
}
/* 
[str_split() �ϥνd��]
int main()
{
    char months[] = "JAN,FEB,MAR,APR,MAY,JUN,JUL,AUG,SEP,OCT,NOV,DEC";
    char** tokens;
    printf("months=[%s]\n\n", months);
    tokens = str_split(months, ',');
    if (tokens)
    {
        int i;
        for (i = 0; *(tokens + i); i++)
        {
            printf("month=[%s]\n", *(tokens + i));
            free(*(tokens + i));
        }
        printf("\n");
        free(tokens);
    }

    return 0;
}

[��X]

months=[JAN,FEB,MAR,APR,MAY,JUN,JUL,AUG,SEP,OCT,NOV,DEC]

month=[JAN]
month=[FEB]
month=[MAR]
month=[APR]
month=[MAY]
month=[JUN]
month=[JUL]
month=[AUG]
month=[SEP]
month=[OCT]
month=[NOV]
month=[DEC]
*/

/*1081225006_SC3 �X�R���[���ڥN�X                                          */
/************************************************************************/
/* �\��GCheck�u�Y���[���ڡv(sProv) �O�_�s�b �u���[���ڦC���v(sProvList) ��    */
/*     ( �s/�¡u���[���ڦC���v�榡(����sProvList���L";"��" ) )���A��          */
/************************************************************************/
long IsProvExist(sProv, sProvList)
char *sProv, *sProvList;
{
    /*char** tokens;*/
    char   v_sProv[7+1];
    char   v_sProvList[21+1];
    long   rc=0,bChk=0;

    printf(" ===========IsProvExist ============= \n");
    rc = FALSE;    
    strcpy(v_sProv    , trim(sProv));
    strcpy(v_sProvList, trim(sProvList));            
    printf("v_sProv=[%s]\n"    , v_sProv);
    printf("v_sProvList=[%s]\n", v_sProvList);

    if (strlen(v_sProv)==0 || strlen(v_sProvList)==0) return rc;

    if ( strstr( v_sProvList, ";") )
    {
         printf("v_sProvList �t���� \n");
         rc = ( strstr( strcat(v_sProvList,";"), strcat(v_sProv,";") ) ? TRUE : FALSE );

         /* �ΥΩ�ѦU�ӱ��ڥX�Ӥ�諸�覡
         tokens = str_split(v_sProvList, ';');         
         if (tokens)
         {
              for (int i = 0; *(tokens + i); i++)
              {
                   printf("provision[%i]=[%s]\n",i, trim(*(tokens + i)));
                   rc = (strcmp( v_sProv, trim(*(tokens + i)) )==0 ? TRUE : FALSE);
                   free(*(tokens + i));
                   if (rc == TRUE) break;
              }
              printf("\n");
              free(tokens);
         }
         */
    }
    else
    {
         printf("v_sProvList ���t���� \n");  
         bChk = FALSE;
         for (int i = 0; i<strlen(v_sProvList); i++)
         {              
              bChk = (isdigit(v_sProvList[i])!=0 ? TRUE : FALSE);
              if (bChk==TRUE) break;
         }  

         printf("v_sProvList �O�_�t���Ʀr bChk = [%s]\n", ( bChk==TRUE ? "TRUE" : "FALSE") );         
         if (bChk==TRUE) /* v_sProvList ���Ʀr,�N���u��O�Y�@�� "�s�榡"���ڥN�� ex. A1�BA01 */
         {
             rc = ( (strcmp(v_sProv, trim(v_sProvList)) == 0) ? TRUE : FALSE );
         }
         else
         {
             rc = ( strstr( v_sProvList, v_sProv) ? TRUE : FALSE );
         }
    }
    printf(" ========== IsProvExist = [%s] ===========\n", ( rc==TRUE ? "TRUE" : "FALSE" )  );
    return rc;
}

char *replace_string(const char *str, const char *from, const char *to) {
    char *result = 0;
    int i = 0, count = 0;
    int from_len = strlen(from);
    int to_len = strlen(to);

    /*Counting the number of times the substring occurs in the string*/
    for (i = 0; str[i] != '\0'; i++) {
        if (strstr(&str[i], from) == &str[i]) {
            count++;
            i += from_len - 1;
        }
    }

    /* Allocating memory for the new string*/
    result = (char *)malloc(i + count * (to_len - from_len) + 1);
    if (result == NULL) {
        printf("Memory allocation failed\n");
        exit(1);
    }

    i = 0;
    while (*str) {
        /* Compare the substring with the result*/
        if (strstr(str, from) == str) {
            strcpy(&result[i], to);
            i += to_len;
            str += from_len;
        } else {
            result[i++] = *str++;
        }
    }
    result[i] = '\0';
    return result;
}

/*1081225006_SC3 �X�R���[���ڥN�X
  �\��G�����u���[���ڦC���v(prov_list)�����u�Y���[���ڡv(prov) ( �s/�¡u���[���ڦC���v�榡���A�� )
*/
void TrimProv(prov,prov_list)
char *prov, *prov_list;
{    
    char v_prov[7+1];
    char v_prov_list[21+1],tmp_prov_list[21+1]="";
    int  rc=0;                 

    strcpy(v_prov     , trim(prov)); 
    strcpy(v_prov_list, trim(prov_list)) ;    

    if (strstr(v_prov_list,";"))  /*������*/
    {  	
         strcat(v_prov,";");     
         strcat(v_prov_list,";");		

         printf("1v_prov[%s]\n",v_prov);
         printf("1v_prov_list[%s]\n",v_prov_list);			
         /*rc = strSearchReplace(v_prov_list, v_prov, ""); */
         
         /*strcpy(tmp_prov_list, replace_string(v_prov_list, v_prov, ""));*/

        char *tmp = replace_string(v_prov_list, v_prov, "");
        if (tmp) {
            strncpy(tmp_prov_list, tmp, sizeof(tmp_prov_list)-1);
            tmp_prov_list[sizeof(tmp_prov_list)-1] = '\0';
            free(tmp);
        }

         printf("tmp_prov_list[%s]\n",tmp_prov_list);	
         strcpy(v_prov_list, tmp_prov_list);
         printf("rc[%d]\n", rc); 
         printf("2v_prov[%s]\n",v_prov);
         printf("3v_prov_list[%s]\n",v_prov_list);			         
         printf("strlen(v_prov_list)[%d]\n", strlen(v_prov_list)); 
         v_prov_list[strlen(v_prov_list)-1] = '\0' ;
         printf("4v_prov_list[%s]\n",v_prov_list);
     }
     else
     {
         rc = strSearchReplace(v_prov_list, v_prov, ""); 
     }

     if (v_prov_list[0]=='\0') 
     {
         v_prov_list[0] = ' ' ;  v_prov_list[1] = '\0';
     }
     strcpy(prov_list ,v_prov_list);  
}

/* �Y searchString = replaceString      => �^�� searchString �b string�����Ӽ� */
/* �Y searchString != replaceString     => �N�b string����searchString ���N�� replaceString ,�æ^�Ǩ��N���Ӽ� */
/* �Y�j�M����εL����searchString�Q���N => �^�� 0 */
int strSearchReplace(char *string,char *searchString,char *replaceString)
 {
 char *currP, *baseStr;
 int  count = 0;
 char currP_tmp[60000];
 currP = baseStr = NULL;

 while (*string)
      {
      currP = strstr (!currP ? string : baseStr, searchString);

      if (currP)
           {
           count++;
           baseStr = (currP + strlen (replaceString));
           strcpy (currP_tmp, (currP + strlen (searchString)));
           strcpy (currP,currP_tmp);
           memmove (currP + strlen (replaceString),
                      currP, strlen (currP) + 1);
           memcpy (currP, replaceString, strlen (replaceString));
           }
      else
           break;
      }

 return count;
 }

 