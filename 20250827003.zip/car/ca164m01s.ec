/************************************************/
/*                                              */
/*   PROGRAM : _RRxxxx.ec                       */
/*                                              */
/************************************************/
     
#include <stdio.h>
#include <decimal.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;
#include "safeclib.h"


long car164(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car164_insert(),car164_single_query(),car164_multiple_query(),car164_update_exec();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 
 switch(option)
 {
  case 'A':
           rtncode=car164_insert(reply);
           break;
  case 'Q':
           rtncode=car164_single_query(reply);
           break;
  case 'M':
           rtncode=car164_multiple_query(reply);
           break;
  case 'D':
  case 'U':
           rtncode=car164_update_exec(reply,command,com_len);
           break;
  default :
           if(exitsub(reply,M_CM_WRONG_OPTION) == True)
            return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}

long car164_insert(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 $char iassured[13],iroute[21],aemail[31], nftp_memo[51],ftp_location[50],freceipt[2],femail[2],fftp[2],dexpire[11],userid[11];
 
 dec_t dec_psex_age;

 /* standard defined data */
 int tmp_len;
 long MsgCode;
   DBinfo *list;
   int i, j, is_add_fail=0, api_f;
   $char stmt_buf[300];
 /* end of standard data */



 cm_buf_get("%s",DBName);
 cm_buf_get("%s %s %s %s %s %s %s %s %s %s ",iassured,iroute,aemail,nftp_memo,ftp_location,freceipt,femail,fftp,dexpire,userid);

 printf("%s %s %s %s %s %s %s %s %s %s",iassured,iroute,aemail,nftp_memo,ftp_location,freceipt,femail,fftp,dexpire,userid);
  
 $WHENEVER SQLERROR GOTO errexit;
 
 if (db_select(DBName) == False) 
 { 
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
 }
 
 $BEGIN WORK;
  
 $INSERT INTO ca_eply_mail (iassured,iroute,aemail,nftp_memo,ftp_location,freceipt,femail,fftp,dexpire,icreate,dcreate,iupdate,dupdate) 
 		     VALUES($iassured,$iroute,$aemail,$nftp_memo,$ftp_location,$freceipt,$femail,$fftp,$dexpire,$userid,current,$userid,current);
 /*sprintf(stmt_buf,"INSERT INTO ca_eply_mail (iassured,aemail,nftp_memo,freceipt,femail,fftp,dexpire,icreate,iupdate) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,)",iassured,aemail,nftp_memo,freceipt,femail,fftp,dexpire,userid,userid);*/
      
 cm_buf_init(ReplyBuf); 		     
 cm_buf_put("%l",M_CM_OK);
 tmp_len=cm_buf_len(ReplyBuf);
 
 if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)== False)
 {
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    return apiRC;
    	
 }
 
 $WHENEVER SQLERROR  GOTO errexit;
 $COMMIT WORK;
 
 return api_OKComplete;

 errexit:
  MsgCode = SQLCODE;
  $WHENEVER SQLERROR CONTINUE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True) 
   return MsgCode;
  else  
   return apiRC;
}


long car164_single_query(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 $char Ciassured[13],Ciroute[21]; /*�Q�I�HID & �q���N��*/
 $char iassured[13],iroute[21],aemail[31],nftp_memo[51],ftp_location[50],freceipt[2],femail[2],fftp[2],dexpire[11],icreate[11],dcreate[21],iupdate[11],dupdate[21];
 $char ncreate[9],nupdate[9];
 /* standard defined data */
 int tmp_len;
 /* end of standard data */

 /* self defined data */
 /* end of self data */
 cm_buf_get("%s",DBName);
 cm_buf_get("%s",Ciassured);
 cm_buf_get("%s",Ciroute);
 
 printf("single query - iassured = %s \n ",Ciassured);
 
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False) 
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

 $SELECT iassured,iroute,aemail,nftp_memo,ftp_location,freceipt,femail,fftp,dexpire,icreate,dcreate,iupdate,dupdate 
  INTO $iassured,$iroute,$aemail,$nftp_memo,$ftp_location,$freceipt,$femail,$fftp,$dexpire,$icreate,$dcreate,$iupdate,$dupdate
  FROM ca_eply_mail 
  WHERE iassured =$Ciassured
  AND iroute = $Ciroute;
 

 if(SQLCODE==SQLNOTFOUND) 
 {
   if(exitsub(reply,M_CM_NOT_FOUND) == True) 
   return M_CM_NOT_FOUND; 
   else  
    return apiRC;
 }
 
 $SELECT nname
  INTO $ncreate
  FROM officer
  WHERE iofficer = $icreate;
 
 printf("single query _  icreate = %s  ncreate = %s \n ",icreate,ncreate);
 
 $SELECT nname
  INTO $nupdate
  FROM officer
  WHERE iofficer = $iupdate;  
  
 printf("single query _  iupdate = %s  nupdate = %s \n ",iupdate,nupdate);
  
 cm_buf_init(ReplyBuf); 
 cm_buf_put("%l",M_CM_OK);
 cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",iassured,iroute,aemail,nftp_memo,ftp_location,freceipt,femail,fftp,dexpire,icreate,ncreate,dcreate,iupdate,nupdate,dupdate);
 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
  return apiRC;
 else
  return api_OKComplete;

 errexit:
  if(exitsub(reply,SQLCODE) == True) 
   return SQLCODE;
  else  
   return apiRC;
}


long car164_multiple_query(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char stmt[512];
 $char DBName[5];
 /* end of standard host var */

 /* table _RR */
 $char Ciassured[13],Ciroute[21];/*���d�ߤ��Q�O�I�HID &�q���N��*/
 $char iassured[13],iroute[21],freceipt[2],femail[2],fftp[2];

 /* end of _RR */

 /* standard defined data */
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0; 
 /* end of standard data */

 /* self defined data */
 /* end of self data */

 cm_buf_get("%s",DBName);
 cm_buf_get("%s",Ciassured);
 cm_buf_get("%s",Ciroute);
 printf("Ciassured =  %s\n",Ciassured);
 printf("Ciroute = %s\n",Ciroute);
 printf("1\n");
 $WHENEVER SQLERROR GOTO errexit;

 printf("1\n");
 if (db_select(DBName) == False) 
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }
  printf("12\n");
  sprintf_s(stmt, sizeof stmt, "SELECT iassured,iroute,freceipt,femail,fftp "
  	       "FROM ca_eply_mail "
  	       "WHERE iassured MATCHES '%s' "
  	       "ANd iroute MATCHES '%s' "
  	       "ORDER BY iassured,iroute ",Ciassured,Ciroute);
  printf("stmt = %s\n",stmt);
  printf("123\n");
  $PREPARE pre_1 FROM $stmt;
  $DECLARE q_cur CURSOR for pre_1;
  $OPEN q_cur;

 for(;;)
  {
    $FETCH q_cur INTO $iassured,$iroute,$freceipt,$femail,$fftp;
    if (SQLCODE != 0) break;
    
    cm_buf_init(tmpbuf); 
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();          
     }
        
    cm_buf_put("%s %s %s %s %s",iassured,iroute,freceipt,femail,fftp);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */ 
     { 
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
        $CLOSE q_cur;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE; 
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
            
        cm_buf_put("%s %s %s %s %s",iassured,iroute,freceipt,femail,fftp);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     } 
  } /* for loop */

 $CLOSE q_cur;
 
 
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
   if(exitsub(reply,M_CM_NOT_FOUND) == True) 
    return M_CM_NOT_FOUND;
   else  
    return apiRC;
  } 

 errexit:
  if(exitsub(reply,SQLCODE) == True) 
   return SQLCODE;
  else  
   return apiRC;
}


long car164_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table _RR */
 $char iassured[13],iroute[21],aemail[31],nftp_memo[51],ftp_location[50],freceipt[2],femail[2],fftp[2],dexpire[11],userid[11],old_dupdate[21],temp_iassured[9];
 /* end of _RR */

 /* standard defined data */
 char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
 int tmp_len,raw_len;
 long dummy;
   DBinfo *list;
   int i, j, is_del_fail=0, is_upd_fail=0;
   $char stmt_buf[300];
 /* end of standard data */

 /* self defined data */
 long MsgCode;
 /* end of self data */

 comm = (char *) command;
 cm_buf_init(command);
 cm_buf_get("%c %s",&option,DBName);
 
 printf("option=%c DBname=%s \n",option,DBName);
 cm_buf_get("%s %s %s %s %s %s %s %s %s %s %s",iassured,iroute,old_dupdate,aemail,nftp_memo,ftp_location,freceipt,femail,fftp,dexpire,userid);

 

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

 /* compare old record and current record, if the record has not been changed  
    since last request, update or delete the record, otherwise return errmsg
    to client side */


 $BEGIN WORK;                
 $SELECT iassured
    INTO $temp_iassured
    FROM ca_eply_mail 
    WHERE iassured = $iassured and iroute=$iroute and dupdate = $old_dupdate;

  /* if key value has been changed then SQLNOTFOUND,else put current value
     into cur_buf for comparison */ 

 if (SQLCODE == SQLNOTFOUND)
 {
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(exitsub(reply,M_CM_NOT_FOUND) == True) 
    return M_CM_NOT_FOUND;
   else  
    return apiRC;
 }
 $WHENEVER SQLERROR GOTO errexit;

 if ( option == 'D' )
 {
   $DELETE FROM ca_eply_mail 
   WHERE iassured = $iassured and iroute=$iroute and dupdate = $old_dupdate;	
   
   if(SQLCODE !=0)
   {
     is_del_fail=1;
   } 
   
   if( is_del_fail ) goto errexit;
   
   
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
   {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
   }  

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
  
 else if (option == 'U')
  {
   $WHENEVER SQLERROR GOTO errexit;
   
   $UPDATE ca_eply_mail
   	SET (aemail,iroute,nftp_memo,ftp_location,freceipt,femail,fftp,dexpire,iupdate,dupdate)
      	   =($aemail,$iroute,$nftp_memo,$ftp_location,$freceipt,$femail,$fftp,$dexpire,$userid,current)
        WHERE dupdate = $old_dupdate and iassured = $iassured and iroute=$iroute;  
   
   if(SQLCODE != 0) goto errexit;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }  

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else
  {
   if(exitsub(reply,M_CM_WRONG_OPTION) == True) 
    return M_CM_WRONG_OPTION;
   else  
    return apiRC;
  } 

 errexit:
  $WHENEVER SQLERROR CONTINUE;
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True) 
   return MsgCode;
  else  
   return apiRC;
}