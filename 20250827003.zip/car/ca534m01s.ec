/*******************************************/
/*          ����¾�z�ߧ��g��             */
/*   PROGRAM : car534m01s.ec               */
/*                                         */
/*   DATE    : 921209                      */
/*                                         */
/*******************************************/
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "rinmsgs.h"
#include "rinmsg.h"
#include <stdlib.h>
$include datetime.h;
$include sqlca;
$include "rindata.h";
#include <decimal.h>
#include "safeclib.h"

$char DBName[5];
long GetLastYearDate();
long GetNextYearDate();

/***************************************************************************/

long car534(reply, command, com_len)
serverReply reply;
voidP command;
int com_len;
{
   static long rtncode;
   long car534_M(),car534_get_irisk_no(),car534_E();
   long car534_C(), car534_D();
   char option;

   cm_buf_init(command);
   cm_buf_get("%c", &option);

	switch(option) {
		case 'S' :    /* �z�ߤH������W�� */
			rtncode = car534_squery(reply);
			break;
		
		case 'T' :	  /* �ץ�z�ߤH���Τ���W�� */
			rtncode = car534_case_info(reply);
			break;

		case 'M':     /* �βz�߭��d�ߥ����� */
			rtncode = car534_M(reply);
			break;

		case 'A':    /* �����׷s�W�� adj_transfer */
			rtncode = car534_A(reply);
			break;

		case 'R':    /* ��@�ץ�d��   */
			rtncode = car534_R(reply);
			break;

		case 'Q':   /* �έ�z�ߤή׸��d�ߥX�w�@�汵������ */
			rtncode = car534_Q(reply);
			break;

		case 'U':   /* �󥿤w�汵������   */
			rtncode = car534_U(reply);
			break;

		default :
			if (exitsub(reply, M_CM_WRONG_OPTION) == True)
			{
				return M_CM_WRONG_OPTION;
			}
			else
			{
				return apiRC;
			}
	}
	return(rtncode);
}

/************************************************************************/

long car534_squery(reply)
serverReply reply;
{
	$char DBName[5],D_dbsite[5];
	$char LHsBuffer[1024],sFullName[20];
	$char iadjuster[11],iadjuster1[11];
	$char nname[41],iquota[7],nbranch[41];
	$int option_type;


	$char stmt[1024];
     
	int LHiBufLen;
	long MsgCode;

	cm_buf_get("%s",DBName);
	cm_buf_get("%d",&option_type);
	cm_buf_get("%s",iadjuster1);
	cm_buf_get("%s",iadjuster);
  
	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == False)
	{ return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;}
    
	printf("iadjuster[%s]\n",iadjuster);        
	printf("iadjuster1[%s]\n",iadjuster1);
	printf("option_type==>[%d]\n",option_type);
	if (option_type == 1)
	{
                $select b.nname, a.ncode, c.nbranch
		   into $nname, $iquota, $nbranch
                   from cu_code_data a, officer b, sa_branch_type c
                  where a.itype    = 'DP'
                    and a.icode    = b.iofficer
                    and b.iofficer = $iadjuster1
                    and a.ncode    = c.ibranch;
                if (SQLCODE == SQLNOTFOUND)
                {
		   $select nname, iquota, nbranch
		      into $nname, $iquota, $nbranch
		      from officer a inner join sa_branch_type b
		        on a.iquota = b.ibranch
		     where iofficer = $iadjuster1;
                }
	}
	else
	{
		/*�u�ק����,�N�ܼ�nname���ȥN�J���W��*/
		$select nbranch
			into $nname
			from sa_branch_type
			where ibranch = $iadjuster1;
		if (SQLCODE == SQLNOTFOUND)
		{
			if(exitsub(reply,M_CM_NOT_FOUND) == True)
				return M_CM_NOT_FOUND;
			else
				return apiRC;
		}
		$select iquota, nbranch
			into $iquota, $nbranch
			from officer a inner join sa_branch_type b
			on a.iquota = b.ibranch
			where iofficer = $iadjuster;
	}
     if (SQLCODE == SQLNOTFOUND)
     {
         if(exitsub(reply,M_CM_NOT_FOUND) == True)
             return M_CM_NOT_FOUND;
         else
             return apiRC;
     }
     

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);
     cm_buf_put("%s %s %s",nname,iquota,nbranch);

     LHiBufLen = cm_buf_len(ReplyBuf);

     if(SendSyncReply(reply,ReplyBuf,LHiBufLen,api_OKComplete) == False)
     {
         $WHENEVER SQLERROR CONTINUE;
         $ROLLBACK WORK;
         return apiRC;
     }

     $WHENEVER SQLERROR GOTO errexit;
     return api_OKComplete;

     errexit:
        printf("sqlerrm:%s\n",sqlca.sqlerrm);
        $WHENEVER SQLERROR CONTINUE;
        MsgCode = SQLCODE;
        if (SQLCODE != 0) MsgCode = SQLCODE;
        return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

long car534_case_info(reply)
serverReply reply;
{
	$char DBName[5],D_dbsite[5];
	$char LHsBuffer[1024],sFullName[20];
	$char iadjuster[11],iadjuster1[11];
	$char iclaim[21];
	$char nname[41],iquota[7],nbranch[41];
	$int option_type;


	$char stmt[1024];
     
	int LHiBufLen;
	long MsgCode;

	cm_buf_get("%s",DBName);
/*	cm_buf_get("%d",&option_type);
	cm_buf_get("%s",iadjuster1);
	cm_buf_get("%s",iadjuster);*/
	cm_buf_get("%s",iclaim);
  
	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == False)
	{ return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;}
    
	/*printf("iadjuster[%s]\n",iadjuster);        
	printf("iadjuster1[%s]\n",iadjuster1);
	printf("option_type==>[%d]\n",option_type);*/
	printf("iclaim[%s]\n",iclaim);

	sprintf_s(stmt,1024,
		" SELECT adjustment        \
			FROM ca_clm_process                   \
			WHERE iclaim = '%s'                 \
			ORDER BY iclaim  ",iclaim);
	$PREPARE CI1 FROM $stmt;
	$EXECUTE CI1 INTO $iadjuster1;
	if (SQLCODE == SQLNOTFOUND)
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True)
			return M_CM_NOT_FOUND;
		else
			return apiRC;
	}

	$select nname, iquota, nbranch
	into $nname, $iquota, $nbranch
	from officer a inner join sa_branch_type b
	on a.iquota = b.ibranch
	where iofficer = $iadjuster1;
	if (SQLCODE == SQLNOTFOUND)
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True)
			return M_CM_NOT_FOUND;
		else
			return apiRC;
	}

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);
     cm_buf_put("%s %s",nname,iadjuster1);

     LHiBufLen = cm_buf_len(ReplyBuf);

     if(SendSyncReply(reply,ReplyBuf,LHiBufLen,api_OKComplete) == False)
     {
         $WHENEVER SQLERROR CONTINUE;
         $ROLLBACK WORK;
         return apiRC;
     }

     $WHENEVER SQLERROR GOTO errexit;
     return api_OKComplete;

     errexit:
        printf("sqlerrm:%s\n",sqlca.sqlerrm);
        $WHENEVER SQLERROR CONTINUE;
        MsgCode = SQLCODE;
        if (SQLCODE != 0) MsgCode = SQLCODE;
        return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

/****  �d�ߥX������ *****/
long car534_M(reply)
serverReply reply;
{
	/* standard defined host variables */
	$char DBName[5];
	/* end of standard host var */


	/*----declare------*/ 
	$char dtransfer[11], ftransit[2];
	$char dtransfer_bgn[11],dtransfer_end[11]; /*�褸�~*/ 
	$char nvessel[41],nvoyage[16],dsail_date[11],dsail_cdate[11],dsail_edate[11];
	$char irisk_no[21],ito[6],fin_out[2];  


	$char ipolicy[21],ipolicy_ext[4],iendorsement[21];
	$char ifrom[6],fins_type[3];

	$char opt[2],argv1[50],argv2[50];
	$char wherestr[150], stmt[1024]; 
	$double mins_amount,mprem_cur;
	$char mins_amount_s[18],mprem_cur_s[18]; 
	$char dclaim[11],ibranch_in[3];

	double sum_mins_amount,sum_mprem_cur;

	char sum_mins_amount_s[18],sum_mprem_cur_s[18];

	/* standard defined data */
	char tmpbuf[4000];
	int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
	int i,total_count=0;
	char userid[11];
	/* end of standard data */

	$long total_len;
	$long total_cnt;

	/* claim */
	$char iadjuster[11];
	$char affiliated[7];
	$char iclaim[21];
	$char fcard_class[2];
	$char fclose[2];
	$char pre_close[2];
	char fullname[51];
        $char ileader[11];

	total_len = 0;
	total_cnt = 0;

	cm_buf_get("%s",DBName);
	cm_buf_get("%s",userid);
	cm_buf_get("%s",iadjuster);

	printf("DBName[%s]\n",DBName);
	printf("userid[%s]\n",userid);
	printf("iadjuster[%s]\n",iadjuster);


	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}


	sprintf_s(stmt,1024,
		" SELECT iclaim,adjustment,dclaim,ibranch_in,ipolicy        \
			FROM ca_clm_process                   \
			WHERE adjustment = '%s'                 \
			AND (SELECT ddecide FROM dwsdb:claim_app_main WHERE iclaim1 = ca_clm_process.iclaim) is null    \
			ORDER BY iclaim  ",iadjuster);

	printf("stmt[%s]\n",stmt);
	$PREPARE m_1 FROM $stmt;
	$DECLARE M_CUR CURSOR FOR m_1;
	$OPEN M_CUR;
	for(;;)
	{
		start:
		$FETCH M_CUR INTO $iclaim,$iadjuster,$dclaim,$ibranch_in,$ipolicy;

		if (SQLCODE == SQLNOTFOUND) break;
        
		strcpy(fullname,get_full_dbname(ibranch_in));
    
                sprintf_s(stmt,1024,"select ileader            \
                                from %s:ply_relation    \
                               where ipolicy = '%s'",fullname,ipolicy);

                $prepare getled from $stmt;
                $execute getled into $ileader;
                if (SQLCODE == SQLNOTFOUND)
                {
                   strcpy(ileader," ");
                }

		strcpy(pre_close,"0");
		
		/*���o�ץ���ݳ��N�X*/
		sprintf_s(stmt,1024,
			" SELECT affiliated                \
				FROM %s:appraisal      \
				WHERE iclaim = '%s'     ",fullname,iclaim);
		$PREPARE aff_1 FROM $stmt;
		$EXECUTE aff_1 INTO $affiliated;

		/* �P�_�j��O�_�w����  */
		strcpy(fcard_class,substring(iclaim,6,1));
   
		if(strcmp(fcard_class,"C")==0)
		{
			sprintf_s(stmt,1024,
				" SELECT fclose                \
					FROM %s:ca_app_victim      \
					WHERE iclaim = '%s'    ",fullname,iclaim);

			/* printf("stmt[%s]\n",stmt);*/
			$PREPARE m_1 FROM $stmt;
			$DECLARE M_CUR11 CURSOR FOR m_1;
			$OPEN M_CUR11;
			for(;;)
			{   
				$FETCH M_CUR11 INTO $fclose;
	
				if (SQLCODE == SQLNOTFOUND)
				{  
					printf("[%s]pre_close[%s]\n",iclaim,pre_close);
					if (strcmp(pre_close,"1")==0)
					{   goto start;   }
					else
					{   break;     }
				}
        
				/* �p�G�w���׫h��show , ���ݩҦ��I�ا��w���פ~��show  */
				if (strcmp(fclose,"1")==0)  
				{ 
					strcpy(pre_close,"1"); 
					continue;
				}
				else
				{  
					strcpy(pre_close,"0");
					break;
				}
			}
		}   /* end �j���I */
		else
		{  
			sprintf_s(stmt,1024,
				" SELECT fclose                \
					FROM %s:app_ins_type      \
					WHERE iclaim = '%s'     ",fullname,iclaim);

			/*printf("stmt[%s]\n",stmt); */
			$PREPARE m_1 FROM $stmt;
			$DECLARE M_CUR12 CURSOR FOR m_1;
			$OPEN M_CUR12;
			for(;;)
			{
				$FETCH M_CUR12 INTO $fclose;
 
				if (SQLCODE == SQLNOTFOUND)
				{  
					printf("[%s]pre_close[%s]\n",iclaim,pre_close);
					if (strcmp(pre_close,"1")==0)
					{   goto start;   }
					else
					{   break;        }
				}
        
				/* �p�G�w���׫h��show , ���ݩҦ��I�ا��w���פ~��show  */
        
				strcpy(fclose,trim(fclose));
				if (strcmp(fclose,"1")==0)  
				{ 
					strcpy(pre_close,"1"); 
					continue;
				}
				else
				{  
					strcpy(pre_close,"0");
					break;
				}
			}
		}   /* end ���N�I */
  
		total_cnt++;

		cm_buf_init(tmpbuf);
		if (count == 0 )
		{
			cm_buf_res_msg();             /* reserve for MsgCode and count */
			cm_buf_res_count();
		}

		cm_buf_put("%s %s %s %s", iclaim,iadjuster,affiliated,ileader);

		tmp_len = cm_buf_len(tmpbuf);
		if (tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
		{
			memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
			repbuf_len += tmp_len;
			count++;
		}
		else                        /* more than 4K, send to client side */
		{
			cm_buf_init(ReplyBuf);
			cm_buf_put_msg(M_CM_OK);
			cm_buf_put_count(count);/*�`�@���X��data*/
			if(SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
			{
				$CLOSE M_CUR;
				$FREE M_CUR;
				return apiRC;
			}
			else      /* clear ReplyBuf and count to start all over again */
			{
				replycnt++;
				if(replycnt > 1) sleep(1);  
                
				if(replycnt == 500)
				{
					/* more than 30K, client cannot display,error */
					cm_buf_init(ReplyBuf);
					cm_buf_put("%l",M_CM_OUT_SPACE);
					tmp_len = cm_buf_len(ReplyBuf);
					if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
						return apiRC;
					return M_CM_OUT_SPACE;
				}

				ReplyBuf[0] = '\0';
				count = 0;
				cm_buf_init(ReplyBuf);
				cm_buf_res_msg();           /* reserve for MsgCode and count */
				cm_buf_res_count();

				cm_buf_put("%s %s %s %s", iclaim,iadjuster,affiliated,ileader);

				printf(" ************************************** \n");

				repbuf_len = cm_buf_len(ReplyBuf);
				count++;
			}
		}
	} /* for loop */

	$CLOSE M_CUR;
	$FREE M_CUR;

	if (count > 0)   /* break out, at least one record is selected */
	{
		cm_buf_init(ReplyBuf);
		cm_buf_put_msg(M_CM_OK);
		cm_buf_put_count(count);
		if(SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
			return apiRC;
		return api_OKComplete;
	}
	else         /* break out, not any row is found */
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True) return M_CM_NOT_FOUND;
		else   
			return apiRC;
	}

errexit:
	if (exitsub(reply,SQLCODE) == True)
		return SQLCODE;
	else
		return apiRC;
}

/*----�d�ߥX adj_transfer ftrans = 'N' �����  --------*/
long car534_Q(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 
 $char aassured[121];

 /* self defined variable */
 $short id1, id2 ;
 $char ipolicy[21];
 $char nname[11];
$char iclaim[21],iadjuster_old[11],iadjuster[11];
$char affiliated_old[7],affiliated[7];
$char dtrans_1[11];
char userid[11];
$char dtrans[11];
$char dentry_sys[11],dentry[11];

$char ientry[11],tot_rows[3];
$char stmt[500];
$long total_cnt;
 char tmpbuf[4000];
$char fullname[51];
$char ileader[11];
$char ibranch_in[3];

 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
total_cnt = 0;

    cm_buf_get("%s",DBName);
    cm_buf_get("%s",userid);
    cm_buf_get("%s",iadjuster);
    cm_buf_get("%s",iclaim);
    
    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
           return M_CM_DB_NOTOPEN;
        else
           return apiRC;
    }


    sprintf_s(stmt,500,
     " SELECT iclaim,iadjuster_old,iadjuster,affiliated_old,affiliated,  \
              dtrans, ientry, dentry           \
         FROM adj_transfer                     \
        WHERE iadjuster_old = '%s'             \
          AND iclaim matches '%s'              \
          AND ftrans = 'N'                     \
        ORDER BY iclaim  ",iadjuster,iclaim);

    printf("stmt[%s]\n",stmt);
    $PREPARE m_1 FROM $stmt;
    $DECLARE M_CUR1 CURSOR FOR m_1;
    $OPEN M_CUR1;
    for(;;)
    {
        $FETCH M_CUR1 INTO $iclaim,$iadjuster_old,$iadjuster,$affiliated_old,$affiliated,
                           $dtrans,$ientry,$dentry;
  
        if (SQLCODE == SQLNOTFOUND) break;

        sprintf_s(stmt,500,"select ipolicy, ibranch_in \
                        from ca_clm_process      \
                       where iclaim = '%s' ",iclaim);
        $prepare gid from $stmt;
        $execute gid into $ipolicy, $ibranch_in;

        strcpy(fullname,get_full_dbname(ibranch_in));

        sprintf_s(stmt,500,"select ileader           \
                        from %s:ply_relation   \
                       where ipolicy = '%s' ",fullname,ipolicy); 
        $prepare gedledv from $stmt;
        $execute gedledv into $ileader;
        if (SQLCODE == SQLNOTFOUND)
        {
           strcpy(ileader," ");
        }

        total_cnt++;

        cm_buf_init(tmpbuf);

        if (count == 0 )
        {
            cm_buf_res_msg();             /* reserve for MsgCode and count */
            cm_buf_res_count();
        }
		printf("1 before infdate_100 dtrans==>[%s]\n",dtrans);
		strcpy(dtrans,cm_from_infdate_100(dtrans));
		printf("2 before infdate_100 dtrans==>[%s]\n",dtrans);

         cm_buf_put("%s %s %s %s %s %s %s", 
                   iclaim,iadjuster_old,iadjuster,affiliated_old,affiliated,
                   dtrans,ileader);


         printf(" ************************************** \n");

    
        tmp_len = cm_buf_len(tmpbuf);
        if (tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
        {
            memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
            repbuf_len += tmp_len;
            count++;
        }
        else                        /* more than 4K, send to client side */
        {
            cm_buf_init(ReplyBuf);
            cm_buf_put_msg(M_CM_OK);
            cm_buf_put_count(count);/*�`�@���X��data*/
            if(SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
             {
              $CLOSE M_CUR;
              $FREE M_CUR;
              return apiRC;
             }
            else      /* clear ReplyBuf and count to start all over again */
             {
              replycnt++;
              if(replycnt > 1) sleep(1);    
              if(replycnt == 500)
               {
                /* more than 30K, client cannot display,error */
                cm_buf_init(ReplyBuf);
                cm_buf_put("%l",M_CM_OUT_SPACE);
                tmp_len = cm_buf_len(ReplyBuf);
                if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
                  return apiRC;
                return M_CM_OUT_SPACE;
             }

			ReplyBuf[0] = '\0';
			count = 0;
			cm_buf_init(ReplyBuf);
			cm_buf_res_msg();           /* reserve for MsgCode and count */
			cm_buf_res_count();


          cm_buf_put("%s %s %s %s %s %s %s", 
                   iclaim,iadjuster_old,iadjuster,affiliated_old,affiliated,
                   dtrans,ileader);
              

          printf(" ************************************** \n");

        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
        }
       }

    } /* for loop */

    $CLOSE M_CUR1;
    $FREE M_CUR1;

    if (count > 0)   /* break out, at least one record is selected */
    {
        cm_buf_init(ReplyBuf);
        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(count);
        if(SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
           return apiRC;
         
        return api_OKComplete;
    }
    else         /* break out, not any row is found */
    {
        if(exitsub(reply,M_CM_NOT_FOUND) == True) return M_CM_NOT_FOUND;
        else   
           return apiRC;
    }
    




errexit:
   if (exitsub(reply,SQLCODE) == True)
     return SQLCODE;
   else
     return apiRC;
}
    
/*------������insert �� adj_transfer  -----*/
long car534_A(reply)
serverReply reply;
{
	$char DBName[5];
	$char count1[7];
	int count2,i;  /* irisk_no have changed data's count*/
	int tmp_len;
	long MsgCode;


	$char stmt[2000];

	$char userid[10];
	$char option[2];
	$char iclaim[21],iadjuster_old[11],iadjuster[11];
	$char affiliated_old[7],affiliated[7];
	$char dtrans_1[11];
	$char dtrans[11];
	$char dentry_sys[11],dentry[11];
	$int qserial,count;
	$char ientry[11],tot_rows[3];
	$char dclaim[11];
        $char ireason[2];

	/* self definded variable */

	$WHENEVER SQLERROR GOTO errexit;
    
	cm_buf_get("%s %s ",DBName,userid);

	if(db_select(DBName) == False)
	{ 
		return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN: apiRC; 
    }
 
   
	$BEGIN WORK;
	
	cm_buf_get("%s ",tot_rows);
	sscanf_s(tot_rows,"%d",&count); 
   
	for(i=0;i<count;i++)
	{
		printf("\n tot_rows[%d] i = [%d]\n",count, i);
      
        
                 
		cm_buf_get(" %s %s %s %s %s %s %s %s",
			option,iclaim,iadjuster_old,iadjuster,affiliated_old,affiliated,dtrans_1,ireason);

		strcpy(dtrans,cm_to_infdate(dtrans_1));
       
		strcpy(dentry_sys,cm_sysd_cdate_100(cm_get_sysd()));
		strcpy(dentry,cm_to_infdate(dentry_sys));
       

		if (option[0] == 'A')
		{
			$select nvl(max(qserial),0)
			into $qserial
			from adj_transfer
			where iclaim = $iclaim;
			printf(" 00000000000000000000000 qserial[%d]\n",qserial); 
       
			$select dclaim
			into $dclaim
			from ca_clm_process
			where iclaim = $iclaim;
          
			if(qserial == 0)
			{
				printf(" ************************************** \n");      
				sprintf_s(stmt,2000,"INSERT INTO adj_transfer       \
							(qserial,iclaim,iadjuster_old,iadjuster,affiliated_old,affiliated, \
							ientry,dentry,dtrans,ftrans,ireason)       \
					VALUES (%d,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')", \
							1,iclaim,iadjuster_old,iadjuster_old,affiliated_old,affiliated_old, \
							userid,dentry,dclaim,"Y"," ");

				printf("stmt[%s]\n",stmt);
				$PREPARE id3 FROM $stmt;
				$EXECUTE id3;

				sprintf_s(stmt,2000,"INSERT INTO adj_transfer       \
							(qserial,iclaim,iadjuster_old,iadjuster,affiliated_old,affiliated, \
							ientry,dentry,dtrans,ftrans,ireason)          \
					VALUES (%d,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')", \
							2,iclaim,iadjuster_old,iadjuster,affiliated_old,affiliated, \
							userid,dentry,dtrans,"N",ireason);

				printf("stmt[%s]\n",stmt);
				$PREPARE id4 FROM $stmt;
				$EXECUTE id4;
         
			}
			else 
			{
				printf(" 1111111111111111111111111111111111 \n");
				qserial = qserial + 1;  
				sprintf_s(stmt,2000,"INSERT INTO adj_transfer       \
							(qserial,iclaim,iadjuster_old,iadjuster,affiliated_old,affiliated, \
							ientry,dentry,dtrans,ftrans,ireason)          \
					VALUES (%d,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')", \
							qserial,iclaim,iadjuster_old,iadjuster,affiliated_old,affiliated, \
							userid,dentry,dtrans,"N",ireason);

				printf("stmt[%s]\n",stmt);
				$PREPARE id5 FROM $stmt;
				$EXECUTE id5;  

			}
		} 
		else
		{ 
			continue; 
		}
  
	}     /* end for */
 
	$COMMIT WORK;
	tmp_len = cm_buf_len(ReplyBuf);
	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
		return apiRC;
	else
		return api_OKComplete;
        
   

errexit:
	MsgCode = SQLCODE;
	$WHENEVER SQLERROR CONTINUE;
	$ROLLBACK WORK;
	if( SQLCODE != 0) MsgCode = SQLCODE;
	return exitsub(reply, MsgCode) ? MsgCode: apiRC;
}


long car534_R(reply)
serverReply reply;
{
	/* standard defined host variables */
	$char DBName[5];

	/* standard defined data */
	char tmpbuf[4000];
	int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
	int i,total_count=0;
	char userid[11];
	/* end of standard data */

	$long total_len;
	$long total_cnt;

	/* claim */
	$char iclaim[21],iadjuster_old[11],iadjuster[11];
	$char affiliated_old[7],affiliated[7];
	char fullname[51];
	$char ibranch_in[3];
	$char fclose[2];
	$char dclaim[11];
	$char stmt[2000];
        $char ileader[11];
        $char ipolicy[21];

	total_len = 0;
	total_cnt = 0;

	cm_buf_get("%s",DBName);
	cm_buf_get("%s",userid);
	cm_buf_get("%s",iclaim);

	printf("DBName[%s]\n",DBName);
	printf("userid[%s]\n",userid);
	printf("iclaim[%s]\n",iclaim);
   

	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}

	sprintf_s(stmt,2000,
		" SELECT ibranch_in,dclaim,adjustment,ipolicy  \
			FROM ca_clm_process        \
			WHERE iclaim = '%s'  ",iclaim);

	printf("stmt[%s]\n",stmt);
	$PREPARE m_1 FROM $stmt;
	$DECLARE M_CUR2 CURSOR FOR m_1;
	$OPEN M_CUR2;
	for(;;)
	{
		$FETCH M_CUR2 INTO $ibranch_in,$dclaim,$iadjuster,$ipolicy;

		if (SQLCODE == SQLNOTFOUND) break;

		strcpy(fullname,get_full_dbname(ibranch_in));
        
                sprintf_s(stmt,2000,"select ileader            \
                                from %s:ply_relation    \
                               where ipolicy = '%s'",fullname,ipolicy);

                $prepare getleda from $stmt;
                $execute getleda into $ileader;
                if (SQLCODE == SQLNOTFOUND)
                {
                   strcpy(ileader," ");
                }

		/*���o�ץ���ݳ��N�X*/
		sprintf_s(stmt,2000,
			" SELECT affiliated                \
				FROM %s:appraisal      \
				WHERE iclaim = '%s'     ",fullname,iclaim);
		printf("stmt[%s]\n",stmt);
		$PREPARE aff_1 FROM $stmt;
		$EXECUTE aff_1 INTO $affiliated;

/*		sprintf_s(stmt,2000,
			" SELECT fclose                \
			FROM %s:ca_local_stl       \
			WHERE iclaim = '%s'  ",fullname,iclaim);

		printf("stmt[%s]\n",stmt);
		$prepare pre7 from $stmt;
		$execute pre7 into $fclose;

		printf(" fclose[%s]\n",fclose);*/

		total_cnt++;
			
		cm_buf_init(tmpbuf);
		if (count == 0 )
		{
			cm_buf_res_msg();             /* reserve for MsgCode and count */
			cm_buf_res_count();
		}
		cm_buf_put("%s %s %s %s", iclaim,iadjuster,affiliated,ileader);
			
		printf(" ************************************** \n");

    
		tmp_len = cm_buf_len(tmpbuf);
		if (tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
		{
			memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
			repbuf_len += tmp_len;
			count++;
		}
		else                        /* more than 4K, send to client side */
		{
			cm_buf_init(ReplyBuf);
			cm_buf_put_msg(M_CM_OK);
			cm_buf_put_count(count);/*�`�@���X��data*/
			if(SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
			{
				$CLOSE M_CUR;
				$FREE M_CUR;
				return apiRC;
			}
			else      /* clear ReplyBuf and count to start all over again */
			{
				replycnt++;
				if(replycnt > 1) sleep(1);    
				if(replycnt == 500)
				{
				/* more than 30K, client cannot display,error */
				cm_buf_init(ReplyBuf);
				cm_buf_put("%l",M_CM_OUT_SPACE);
				tmp_len = cm_buf_len(ReplyBuf);
				if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
				return apiRC;
				return M_CM_OUT_SPACE;
				}

				ReplyBuf[0] = '\0';
				count = 0;
				cm_buf_init(ReplyBuf);
				cm_buf_res_msg();           /* reserve for MsgCode and count */
				cm_buf_res_count();

         
				cm_buf_put("%s %s %s %s", iclaim,iadjuster,affiliated,ileader);

				printf(" ************************************** \n");

				repbuf_len = cm_buf_len(ReplyBuf);
				count++;
			}
		}
    } /* for loop */
	$CLOSE M_CUR2;
	$FREE M_CUR2;
    
	if (count > 0)   /* break out, at least one record is selected */
	{
		cm_buf_init(ReplyBuf);
		cm_buf_put_msg(M_CM_OK);

		cm_buf_put_count(count);
		if(SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
		return apiRC;
		return api_OKComplete;
	}
	else         /* break out, not any row is found */
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True) return M_CM_NOT_FOUND;
		else   
		return apiRC;
	}

errexit:
	if (exitsub(reply,SQLCODE) == True)
		return SQLCODE;
	else
		return apiRC;
}

/*    update adj_transfer */
long car534_U(reply)
serverReply reply;
{
 $char DBName[5];
 $char count1[7];
 int count2,i;  /* irisk_no have changed data's count*/
 int tmp_len;
 long MsgCode;

$char stmt[2000];
$char userid[10];
$char option[2];
$char iclaim[21],iadjuster_old[11],iadjuster[11];
$char affiliated_old[7],affiliated[7];
$char dtrans_1[11];
$char dtrans[11];
$char dentry_sys[11],dentry[11];
$int qserial,count;
$char ientry[11],tot_rows[3];

 /* self definded variable */

    $WHENEVER SQLERROR GOTO errexit;
    
    cm_buf_get("%s %s ",DBName,userid);
    
    if(db_select(DBName) == False)
    { 
       return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN: apiRC; 
    }
 
    $BEGIN WORK;

    cm_buf_get("%s ",tot_rows);
    sscanf_s(tot_rows,"%d",&count); 
   
    for(i=0;i<count;i++)
    {
        printf("\n tot_rows[%d] i = [%d]\n",count, i);
        
                 
        cm_buf_get(" %s %s %s %s %s %s %s",
          option,iclaim,iadjuster_old,iadjuster,affiliated_old,affiliated,dtrans_1);

        strcpy(dtrans,cm_to_infdate(dtrans_1));
       
        strcpy(dentry_sys,cm_sysd_cdate_100(cm_get_sysd()));
        strcpy(dentry,cm_to_infdate(dentry_sys));

     if (option[0] == 'U')
     {
        printf(" dtrans [%s]\n",dtrans );
        $update adj_transfer
            set (iadjuster,affiliated,dtrans,ientry,dentry) = 
                ($iadjuster,$affiliated,$dtrans,$userid,$dentry)
         where iclaim = $iclaim
           and iadjuster_old = $iadjuster_old
           and ftrans = 'N';
        
     }
     else
     { 
       	  continue; 
     }
  
 }     /* end for */
 
 $COMMIT WORK;
  tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

 errexit:
   MsgCode = SQLCODE;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if( SQLCODE != 0) MsgCode = SQLCODE;
   return exitsub(reply, MsgCode) ? MsgCode: apiRC;
}

long GetLastYearDate(pdate)
long pdate;
{
long ndate;
short mdy[3];

    rjulmdy(pdate,mdy);
    mdy[2]--;   /* mdy[2] is the year data */
    rmdyjul(mdy,&ndate);
    return ndate;
}

long GetNextYearDate(pdate)
long pdate;
{
long ndate;
short mdy[3];

    rjulmdy(pdate,mdy);
    mdy[2]++;   /* mdy[2] is the year data */
    rmdyjul(mdy,&ndate);
    return ndate;
}

