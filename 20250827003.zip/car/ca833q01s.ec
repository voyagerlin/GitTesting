/*-------------------------------------------------------------------
 *  CAR833���I�z�߷J�`���Ӫ�
 *  Program: ca833q01s.ec
 *-------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#include "is_def.h"
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "sql.h"
$include sqlca;
#include "safeclib.h"

char DBName[BRANCH_ID], userid[USER_ID];
$char FormTp[3], TitleFmt[21], BodyFmt[21];
$int Width = 0, ItemRow, TotColumn, StartRow, TitleRow, PgLine;
char outputf[21], BodyFile[21], TitleFile[21];
int max_count=0;

$char dgroup[YYYMMDD], edgroup[YYYYMMDD];
$char igroup_c[13], igroup[13], igroup_tmp[13];

char FullClmDBName[21];
$char iclaim[21], fstl[2];
$int iclose_type = 0;
$long dply_begin = 0, dply_end = 0;
$char ipolicy[21], icar_type[3], iins_type[7];
$long iMonth;
$int cartype27 = 0; /* 27���دS���B�z */
$char ireceive[13], provision[7];
$long mins_stl = 0, mins_proc = 0, mins_rec = 0;
$long mins_place = 0;
$long tot_mins_stl, tot_mins_proc, tot_mins_rec;
$long tot_mins_place;
$char clmdb[6], nassured[41];
$char iproduct[13];
$char kclsfyitem[5];
$char kreserve[6];
$char npayment[17], xibank[8], nbank[21], xiaccbank[15];
$char xfpay_cond[2], fspeed[2], ipay_area[3],ipayment[11],ifpce_id_ext[3];
$double mtax;
$long mpayment, tot_mpayment, tot_mtax;
$double xptax = 0.0;
$char nname_close[11];
$char icls_dept[3];
$char ibatch[11];
$char Isettle_type[2],Nsettle_type[5];
$char drate_ym[5];

$char stmt[1024];
long rtncode;
char buf[16];
char fbody;

extern char RPTDIR[];
#define fmt1 "---,---,---,--&"
#define fmt2 "--&.&&"

/***************************************************************************/
main(argc,argv)
int argc;
char *argv[];
{
    long ca833_Q();
    int DiffMonth();
    void Put_Total();
    void Put_Head_File(), Put_Igroup(), Put_Igroup_Tmp();
    void Put_Body_File1(), Put_Body_File1_1(), Put_Body_File2(), Put_Body_File3(), Put_Body_File4();
    void Put_Line(), Put_Blank_Line(), Put_Next_Page();
    double d45();

    batchinit();

    strcpy(DBName, isNULLstr(argv[1]));
    strcpy(userid, isNULLstr(argv[2]));

    strcpy(dgroup, isNULLstr(argv[3]));
    strcpy(igroup_c, isNULLstr(argv[4]));
    strcpy(outputf, isNULLstr(argv[5]));

    strcpy(edgroup, cm_to_infdate(dgroup));

    if ((rtncode=ca833_Q()) != api_OKComplete) {
        EWRITE(userid, rtncode, "build function fail!") ;
        exit(1);
    }

    create_sign_form("car833",BodyFile,Width) ;

    if ((rtncode = save_form_info(F_BLK1,"CA",833,userid,FormTp,max_count,outputf)) < 0)
        EWRITE(userid,rtncode,"save_form_info failed") ;
}

/***************************************************************************/
long ca833_Q()
{

    if (db_select(DBName) == False)
    {
        EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
        exit(1);
    }

    $WHENEVER SQLERROR GOTO errexit;

    /* �s�@���� */
    $SELECT nTitle_Fmt,nBody_Fmt,kStart_Row,kTitle_Row,kTot_Col,
            kPgNum_Line,kWidth,iForm_Tp
       INTO $TitleFmt,$BodyFmt,$StartRow,$TitleRow,$TotColumn,
            $PgLine,$Width,$FormTp
       FROM form
      WHERE ksys_grp = 'CA' AND kPgmID = 833;

    Put_Head_File();

    strcpy(BodyFmt,rtrim(BodyFmt)) ;
    sprintf_s(BodyFile,21,"%s.bd",outputf);

    rgu_init_report(BodyFmt,BodyFile);

    /* TEMP TABLE */
    $CREATE TEMP TABLE car833_tbl_1
    (
        kclsfyitem CHAR(4),
        mins_stl DECIMAL(10,0),
        mins_proc DECIMAL(10,0),
        mins_rec DECIMAL(10,0),
        mins_place DECIMAL(10,0)
    ) WITH NO LOG;

    $CREATE TEMP TABLE car833_tbl_2
    (
        fspeed CHAR(1),
        mtax DECIMAL(10,0),
        mpayment DECIMAL(10,0)
    ) WITH NO LOG;


    strcpy(igroup_tmp, "#");
    $DECLARE ca833_q1 CURSOR FOR
      SELECT igroup, iclose, fstl, iclose_type, icls_dept, ibatch
        FROM ao_stl_close
       WHERE insure_type='C'
         AND dgroup = $edgroup
         AND igroup MATCHES $igroup_c
    ORDER BY igroup, icls_dept, iclose;
    $OPEN ca833_q1;
    while(1)
    {
        $FETCH ca833_q1
          INTO $igroup, $iclaim, $fstl, $iclose_type, $icls_dept, $ibatch;
        if (SQLCODE == SQLNOTFOUND) break;
        printf("iclaim[%s]fstl[%s]iclose_type[%d]\n", iclaim, fstl, iclose_type);

        if (strcmp(igroup, igroup_tmp)!=0)
        {
            if (max_count==0) Put_Igroup();
            else
            {
                Put_Line();
                Put_Next_Page();
                Put_Igroup_Tmp();
                Put_Total();
                Put_Next_Page();
                Put_Igroup();
            }
        }

        /* �߮׸�Ʈw�B�O��W�١B�O�渹 */
        $SELECT ibranch_in, nassured[1,20], ipolicy
           INTO $clmdb, $nassured, $ipolicy
           FROM ca_clm_process
          WHERE iclaim = $iclaim;
        printf("clmdb[%s]\n", clmdb);
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(stmt,1024, "[%s]�߮׸�Ƨ䤣��!!", iclaim);
            EWRITE(userid, M_CM_NOT_FOUND, stmt);
            exit(1);
        }
        strcpy(FullClmDBName, get_full_dbname(clmdb));

        sprintf_s(stmt,1024,
          "SELECT dply_begin, dply_end, icar_type "
            "FROM %s:adjustment_ply "
           "WHERE iclaim = '%s' ", FullClmDBName, iclaim);
        $PREPARE pr_ply_data FROM $stmt;
        $EXECUTE pr_ply_data INTO $dply_begin, $dply_end, $icar_type;

        iMonth = DiffMonth(dply_end,dply_begin);
        printf("iMonth[%d]icar_type[%s]\n", iMonth, icar_type);

        /* 27����2008.7.22�ۥΧ���~ */
        if (strcmp(icar_type, "27")==0)
        {
            sprintf_s(stmt,1024, "SELECT COUNT(*) FROM %s:ply_relation "
                           "WHERE ipolicy = '%s' AND dpolicy < '07/22/2008'", FullClmDBName, ipolicy);
            $PREPARE cartype_27 FROM $stmt;
            $EXECUTE cartype_27 INTO $cartype27;
            if (cartype27 > 0)
                strcpy(icar_type, "03");
        }
        printf("iMonth[%d]icar_type[%s]\n", iMonth, icar_type);

        fbody = 0;
        /* �j���I */
        if (iclaim[5]=='C')
        {
            sprintf_s(stmt,1024,
              "SELECT '21', a.ireceive, NVL(SUM(b.mins_stl+b.mstl_health), 0), NVL(SUM(b.mins_proc), 0), 0 as mins_place "
                "FROM %s:settlement a, %s:ca_stl_victim b "
               "WHERE a.iclaim = b.iclaim "
                 "AND a.fstl = b.fstl "
                 "AND a.iclose_type = b.iclose_type "
                 "AND a.iclaim = '%s' AND a.fstl = '%s' AND a.iclose_type = %d AND b.dgroup = '%s' "
            "GROUP BY 1,2", FullClmDBName, FullClmDBName, iclaim, fstl, iclose_type, edgroup);
        }
        else
        {
            sprintf_s(stmt,1024,
              "SELECT b.iins_type, a.ireceive, NVL(SUM(b.mins_stl), 0), NVL(SUM(b.mins_proc), 0), NVL(SUM(b.mins_place), 0) "
                "FROM %s:settlement a, %s:stl_ins_type b "
               "WHERE a.iclaim = b.iclaim "
                 "AND a.fstl = b.fstl "
                 "AND a.iclose_type = b.iclose_type "
                 "AND a.iclaim = '%s' AND a.fstl = '%s' AND a.iclose_type = %d AND b.dgroup = '%s' "
            "GROUP BY 1,2", FullClmDBName, FullClmDBName, iclaim, fstl, iclose_type, edgroup);
        }
        printf("stmt[%s]\n", stmt);

        $PREPARE pr_2 FROM $stmt;
        $DECLARE ca833_q2 CURSOR FOR pr_2;
        $OPEN ca833_q2;
        while(1)
        {
            $FETCH ca833_q2
              INTO $iins_type, $ireceive, $mins_stl, $mins_proc, $mins_place;
            if (SQLCODE == SQLNOTFOUND) break;
            printf("iins_type[%s]ireceive[%s]mins_stl[%ld]mins_proc[%ld]\n", iins_type, ireceive, mins_stl, mins_proc);

            strcpy(provision, " ");
            if (iclaim[5]!='C')
            {
                /* �D�j���I */
                sprintf_s(stmt,1024,
                  "SELECT provision, drate_ym "
                    "FROM %s:ply_ins_type "
                   "WHERE ipolicy = '%s' "
                     "AND iins_type = (SELECT iins_ply FROM insurance_type WHERE iins_type = '%s') ",
                  FullClmDBName, ipolicy, iins_type);
                $PREPARE get_provision FROM $stmt;
                $EXECUTE get_provision INTO $provision, $drate_ym;
                printf("provision[%s], drate_ym[%s]\n", provision, drate_ym);
            }
            else
            {
                sprintf_s(stmt,1024,
                  "SELECT drate_ym "
                    "FROM %s:ply_ins_type "
                   "WHERE ipolicy = '%s' "
                     "AND iins_type = '21' ",
                  FullClmDBName, ipolicy);
                $PREPARE get_provision21 FROM $stmt;
                $EXECUTE get_provision21 INTO $drate_ym;
                printf("provision[%s], drate_ym[%s]\n", provision, drate_ym);
            }

            rtncode = get_product_code_car("C", iins_type, icar_type, iMonth, iproduct, kclsfyitem, kreserve, provision, drate_ym);
            if (rtncode!=M_CM_OK)
            {
                EWRITE(userid, M_CM_NOT_FOUND, "get_product_code_car err");
                exit(1);
            }
            printf("kclsfyitem[%s]\n", kclsfyitem);

            if (fbody==0) Put_Body_File1();
            else Put_Body_File1_1();

            if (fstl[0]=='1') $INSERT INTO car833_tbl_1 VALUES ($kclsfyitem, $mins_stl, $mins_proc, 0, 0);
            else $INSERT INTO car833_tbl_1 VALUES ($kclsfyitem, 0, $mins_proc, $mins_stl, 0);
 
            if (mins_place != 0)
            {
               $INSERT INTO car833_tbl_1 VALUES ('5650', 0, 0, 0, $mins_place);
            }
        }
        $CLOSE ca833_q2;
        $FREE ca833_q2;

        /* �I�ڸ�� */
        /* 1000117001��I�覡���}���A�״ڦ�w�P�b���g�J�ť� */
        sprintf_s(stmt,1024,
          "SELECT npayment[1,16], DECODE(xfpay_cond,'2',' ',xibank), DECODE(xfpay_cond,'2',' ',xiaccount), "
                 "xfpay_cond, fspeed, mpayment, xptax, ipay_area,ipayment,ifpce_id_ext "
            "FROM %s:payment "
           "WHERE iclaim = '%s' AND fstl = '%s' AND iclose_type = %d ", FullClmDBName, iclaim, fstl, iclose_type);
        printf("stmt[%s]\n", stmt);

        $PREPARE pr_3 FROM $stmt;
        $DECLARE ca833_q3 CURSOR FOR pr_3;
        $OPEN ca833_q3;
        while(1)
        {
            $FETCH ca833_q3
              INTO $npayment, $xibank, $xiaccbank, $xfpay_cond, $fspeed, $mpayment, $xptax, $ipay_area, $ipayment, $ifpce_id_ext;
            if (SQLCODE == SQLNOTFOUND) break;
            printf("npayment[%s]xibank[%s]xiaccbank[%s]\n", npayment, xibank, xiaccbank);
            printf("xfpay_cond[%s]fspeed[%s]mpayment[%ld]xptax[%lf]ipay_area[%s]\n", xfpay_cond, fspeed, mpayment, xptax, ipay_area);

            $SELECT nchi_abv[1,20]
               INTO $nbank
               FROM bf_bank
              WHERE ibank=$xibank;
            if (SQLCODE == SQLNOTFOUND) strcpy(nbank, xibank);

            if (fstl[0]=='2') mpayment = -mpayment;

            strcpy(nname_close, " ");
            if ((xfpay_cond[0]=='2') || (xfpay_cond[0]=='1'))
            {
                /* 0991029005�I�ڤ覡{�}����,�ЦC�X�鵲�H�� */

                sprintf_s(stmt,1024,
                 " SELECT b.nname                       \
                     FROM %s:ca_local_stl a,officer b   \
                    WHERE a.userid = b.iofficer         \
                      AND a.iclaim      = ?      \
                      AND a.fstl        = ?      \
                      AND a.iclose_type = ? ",get_full_dbname(icls_dept));
                 $PREPARE get_nname_1 FROM $stmt;
                 $EXECUTE get_nname_1
                     INTO $nname_close
                    USING $iclaim,$fstl,$iclose_type;
                 if (SQLCODE == SQLNOTFOUND)
                 {
                    strcpy(nname_close," ");
                 }
            }

			strcpy(Isettle_type,"");         
			strcpy(Nsettle_type,"");   
			$SELECT isettle_type
               INTO $Isettle_type
               FROM cu_stl_obj
              WHERE ifpce_id =$ipayment AND ifpce_id_ext = $ifpce_id_ext;
			
			if (SQLCODE == SQLNOTFOUND)
			{             
				strcpy(Nsettle_type, "");
			}
			else   
			{
				if (Isettle_type[0] == '3') 
				{
					strcpy(Nsettle_type, "�߮v");
				}
				else 
				{
					strcpy(Nsettle_type, "");
				}
			}
			  
			

            Put_Body_File2();

            if (mpayment>0)
            {
                if (xptax>0)
                {
                    /* �N���|�� */
                    mtax = d45(((double)mpayment*xptax/100.00),0);
                    mpayment -= mtax;
                }
                else mtax = 0;

                $INSERT INTO car833_tbl_2 VALUES ($fspeed, $mtax, $mpayment);
            }
        }
        $CLOSE ca833_q3;
        $FREE ca833_q3;

        strcpy(igroup_tmp, igroup);
    }
    $CLOSE ca833_q1;
    $FREE ca833_q1;

    if (max_count==0)
    {
        EWRITE(userid, M_CM_NOT_FOUND, "��Ƨ䤣��!!");
        exit(1);
    }

    Put_Line();
    Put_Next_Page();
    Put_Igroup();
    Put_Total();

    rgu_finish_report();

    return api_OKComplete;

errexit:
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    cm_show_sql_err("ca833_Q", "");
    exit(1);
}

/***************************************************************************/
void Put_Total()
{
    $WHENEVER SQLERROR GOTO errexit;

    rgu_put_body(4); max_count++;
    rgu_put_body(5); max_count++;
    rgu_put_body(4); max_count++;

    /* �J�`��� */
    tot_mins_stl=tot_mins_proc=tot_mins_rec=0;
    tot_mins_place=0;
    $DECLARE ca833_q4 CURSOR FOR
      SELECT kclsfyitem, SUM(mins_stl), SUM(mins_proc), SUM(mins_rec), SUM(mins_place)
        FROM car833_tbl_1
    GROUP BY kclsfyitem
    ORDER BY kclsfyitem;
    $OPEN ca833_q4;
    while(1)
    {
        $FETCH ca833_q4
          INTO $kclsfyitem, $mins_stl, $mins_proc, $mins_rec, $mins_place;
        if (SQLCODE == SQLNOTFOUND) break;

        Put_Body_File3();

        tot_mins_stl += mins_stl;
        tot_mins_proc += mins_proc;
        tot_mins_rec += mins_rec;
        tot_mins_place += mins_place;
    }
    $CLOSE ca833_q4;
    $FREE ca833_q4;

    rgu_put_body(4); max_count++;

    rgu_put_body_string(6, "�X    �p", LEFT);
    rfmtlong(tot_mins_stl, fmt1, buf);
    rgu_put_body_string(6, trim(buf), RIGHT);
    rfmtlong(tot_mins_proc, fmt1, buf);
    rgu_put_body_string(6, trim(buf), RIGHT);
    rfmtlong(tot_mins_rec, fmt1, buf);
    rgu_put_body_string(6, trim(buf), RIGHT);
    rfmtlong(tot_mins_place, fmt1, buf);
    rgu_put_body_string(6, trim(buf), RIGHT);

    rgu_put_body(6); max_count++;
    rgu_put_body(4); max_count++;

    Put_Blank_Line();
    Put_Blank_Line();

    rgu_put_body(7); max_count++;
    rgu_put_body(8); max_count++;
    rgu_put_body(7); max_count++;

    tot_mtax=tot_mpayment=0;
    $DECLARE ca833_q5 CURSOR FOR
      SELECT fspeed, SUM(mtax), SUM(mpayment)
        FROM car833_tbl_2
    GROUP BY fspeed
    ORDER BY fspeed;
    $OPEN ca833_q5;
    while(1)
    {
        $FETCH ca833_q5
          INTO $fspeed, $mtax, $mpayment;
        if (SQLCODE == SQLNOTFOUND) break;

        Put_Body_File4();

        tot_mtax += mtax;
        tot_mpayment += mpayment;
    }
    $CLOSE ca833_q5;
    $FREE ca833_q5;

    rgu_put_body(7); max_count++;

    rgu_put_body_string(9, "�X    �p", LEFT);
    rfmtlong(tot_mtax, fmt1, buf);
    rgu_put_body_string(9, trim(buf), RIGHT);
    rfmtlong(tot_mpayment, fmt1, buf);
    rgu_put_body_string(9, trim(buf), RIGHT);

    rgu_put_body(9); max_count++;
    rgu_put_body(7); max_count++;

    $DELETE FROM car833_tbl_1 WHERE 1=1;
    $DELETE FROM car833_tbl_2 WHERE 1=1;
    return;

errexit:
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    cm_show_sql_err("ca833_Put_Total", "");
    exit(1);
}

/***************************************************************************/
int DiffMonth(d1,d2)    /* input data should be date format */
long d1, d2;
{
short mdy1[3], mdy2[3];
int datediff=0;

    rjulmdy(d1,mdy1);
    rjulmdy(d2,mdy2);
    datediff=(mdy1[2]*12+mdy1[0])-(mdy2[2]*12+mdy2[0]);
    if (datediff<0) datediff=0;
    return datediff;
}

/***************************************************************************/
void Put_Head_File()
{
    strcpy(TitleFmt,rtrim(TitleFmt));
    sprintf_s(TitleFile,21,"%s.ti",outputf);

    rgu_init_report(TitleFmt,TitleFile);

    rgu_put_head_string(LEFT, cm_sysd_cdatetime_100(cm_get_sysd()));
    rgu_put_head_string(LEFT, dgroup);
    rgu_put_head_string(LEFT, DBName);

    rgu_put_head();
    rgu_finish_report();
}

/***************************************************************************/
void Put_Igroup()
{
    rgu_put_body_string(11, igroup, LEFT);
    rgu_put_body(11); max_count++;
}

/***************************************************************************/
void Put_Igroup_Tmp()
{
    rgu_put_body_string(11, igroup_tmp, LEFT);
    rgu_put_body(11); max_count++;
}

/***************************************************************************/
void Put_Body_File1()
{
    rgu_put_body_string(1, iclaim, LEFT);
    rgu_put_body_string(1, ipolicy, LEFT);
    rgu_put_body_string(1, nassured, LEFT);

    if (fstl[0]=='1') strcpy(buf, "�ߥI");
    else if (fstl[0]=='2') strcpy(buf, "�l�v");
    else strcpy(buf, fstl);
    rgu_put_body_string(1, buf, LEFT);

    sprintf_s(buf,16, "%d", iclose_type);
    rgu_put_body_string(1, buf, LEFT);

    rgu_put_body_string(1, ireceive, LEFT);
    rgu_put_body_string(1, kclsfyitem, LEFT);

    rfmtlong(mins_stl, fmt1, buf);
    rgu_put_body_string(1, trim(buf), RIGHT);
    rfmtlong(mins_proc, fmt1, buf);
    rgu_put_body_string(1, trim(buf), RIGHT);

    rgu_put_body(1); max_count++;
    fbody = 1;
}

/***************************************************************************/
void Put_Body_File1_1()
{
    rgu_put_body_string(2, kclsfyitem, LEFT);

    rfmtlong(mins_stl, fmt1, buf);
    rgu_put_body_string(2, trim(buf), RIGHT);
    rfmtlong(mins_proc, fmt1, buf);
    rgu_put_body_string(2, trim(buf), RIGHT);

    rgu_put_body(2); max_count++;
}
/***************************************************************************/
void Put_Body_File2()
{
    rgu_put_body_string(3, npayment, LEFT);
    rgu_put_body_string(3, nbank, LEFT);
    rgu_put_body_string(3, xiaccbank, LEFT);

    if (xfpay_cond[0]=='1') strcpy(buf, "�{��");
    else if (xfpay_cond[0]=='2') strcpy(buf, "�}��");
    else if (xfpay_cond[0]=='3') strcpy(buf, "�״�");
    else strcpy(buf, xfpay_cond);
    rgu_put_body_string(3, buf, LEFT);

    rgu_put_body_string(3, fspeed, LEFT);
    rfmtlong(mpayment, fmt1, buf);
    rgu_put_body_string(3, trim(buf), RIGHT);
    rfmtdouble(xptax, fmt2, buf);
    rgu_put_body_string(3, trim(buf), RIGHT);
    rgu_put_body_string(3, nname_close, LEFT);

    if (strcmp(icls_dept, "00")==0) strcpy(buf, "00 �x�_");
    else if (strcmp(icls_dept, "22")==0) strcpy(buf, "22 �O��");
    else if (strcmp(icls_dept, "33")==0) strcpy(buf, "33 ���");
    else if (strcmp(icls_dept, "40")==0) strcpy(buf, "40 �x��");
    else if (strcmp(icls_dept, "66")==0) strcpy(buf, "66 �x�n");
    else if (strcmp(icls_dept, "70")==0) strcpy(buf, "70 ����");
    else strcpy(buf, icls_dept);
    rgu_put_body_string(3, buf, LEFT);

    strcpy(buf,trim(ibatch));
    rgu_put_body_string(3, buf, LEFT);	

    strcpy(buf,trim(Nsettle_type));
    rgu_put_body_string(3, buf, LEFT);		

    rgu_put_body(3); max_count++;
}

/***************************************************************************/
void Put_Body_File3()
{
    rgu_put_body_string(6, kclsfyitem, LEFT);
    rfmtlong(mins_stl, fmt1, buf);
    rgu_put_body_string(6, trim(buf), RIGHT);
    rfmtlong(mins_proc, fmt1, buf);
    rgu_put_body_string(6, trim(buf), RIGHT);
    rfmtlong(mins_rec, fmt1, buf);
    rgu_put_body_string(6, trim(buf), RIGHT);
    rfmtlong(mins_place, fmt1, buf);
    rgu_put_body_string(6, trim(buf), RIGHT);

    rgu_put_body(6); max_count++;
}

/***************************************************************************/
void Put_Body_File4()
{
    rgu_put_body_string(9, fspeed, LEFT);
    rfmtdouble(mtax, fmt1, buf);
    rgu_put_body_string(9, trim(buf), RIGHT);
    rfmtlong(mpayment, fmt1, buf);
    rgu_put_body_string(9, trim(buf), RIGHT);

    rgu_put_body(9); max_count++;
}

/***************************************************************************/
void Put_Line()
{
    rgu_put_body(10); max_count++;
}

/***************************************************************************/
void Put_Blank_Line()
{
    rgu_put_body(98); max_count++;
}

/***************************************************************************/
void Put_Next_Page()
{
    rgu_put_body(99); max_count++;
}

/***************************************************************************/
double d45(num,num1)
double num;
int num1;
{
long tmplong, tmplongd;
double var1;
double ten;
int i;
 
 puts("=== d45 ====================");
 printf("num[%lf]\n", num);
 tmplong = num;
 var1 = num - tmplong;
 printf("tmplong[%ld]var1[%lf]\n", tmplong, var1);
 
 ten = 1;
 
 for(i=1;i<=num1;i++) ten *= 10;
 
 var1 *= ten;
 
 if (num >= 0) var1 += 0.5;
 else var1 -= 0.5;
 
 tmplongd = var1;
 printf("var1[%lf]tmplongd[%ld]\n", var1, tmplongd);
 if(ten > 0) var1 = tmplongd/ten;
 printf("var1[%lf]\n", var1);
 
 num = tmplong + var1;
 printf("num[%lf]\n", num);
 puts("=== d45 ====================");
 return(num);
}
