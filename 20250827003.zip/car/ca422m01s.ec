/******************************/
/*   Program : ca422m01s.ec   */
/*   Author  : Peter Sun      */
/*   Date    : 07.15.2003     */
/*   ����z�覡�󥿧@�~     */
/******************************/

#include <stdio.h>
#include <math.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "marmsgs.h"
#include <cmnmsgs.h>
#include "commsgs.h"
#include "carmsgs.h"
#include "carmsg.h"
$include sqlca;
$include datetime.h;
$include "ca401lib.h";
$include cmnroute.h;
#include "safeclib.h"

#define MAXSIZE 40

$char cDbName[5];
char *get_db(), v_sMsg[1512];
int iRtnLen;
char ipgid[11];

long car422(reply, command, com_len)
serverReply reply;
voidP command;
int com_len;
{
    long rtncode;
    long car422_query_ori_endorse(); /* �����Ƭd�� */
    char option;

    cm_buf_init(command);
    cm_buf_get("%c", &option);

    strcpy(ipgid, "car422");

    switch (option)
    {
    /* �����Ƭd�� */
    case '1':
        rtncode = car422_query_ori_endorse(reply, option, command, com_len);
        break;

    /* �s�W����       */
    case 'A':
        rtncode = car422_insert(reply, option, command, com_len);
        break;

    /* Multiply Query */
    case 'M':
        rtncode = car422_multiple_query(reply);
        break;

    /* ���d��       */
    case 'Q':
        rtncode = car422_single_query(reply);
        break;

    default:
        return exitsub(reply, M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
    }
    return (rtncode);
}

/* �����Ƭd�� */
long car422_query_ori_endorse(reply)
serverReply reply;
{
    $char iendorse[ENDORSE_NUM];
    $char sDB[3];

    $char ipolicy[POLICY_NUM_1];
    $char policy_1[POLICY_NUM_1], policy_2[POLICY_NUM_2];

    $char dendorse[11];
    $char dpolicy[11];
    $long t_dpolicy=0;
    $char nassured[31];
    $char ibroker[BROKER];
    $char off_nname[11];
    $char brk_nname[11];
    $date dwritten;

    $char iedr_return[3];
    $char payresult[5], paystatus[100], paydate[100], notedate[100];
    $int ins_cnt;

    $char iins_type[INSURANCE_TYPE];
    $char iedr_type[6];
    $char iedr_type_33[6];
    $long medrins_prem=0;
    $float medrpure_prem=0.0;
    $long medr_prem=0;
    $long medrins_prem_33=0;
    $long medr_discount_33=0;
    $double pcommission=0.0, pagent=0.0, pdiscount=0.0;
    $long medr_commission=0, medr_agent=0, medr_discount=0;
    $char ipaid_base[2];
    $double pfix_agent=0.0;
    $char icheck_disc[3];
    $char icheck_agent[3];
    $char icheck_commi[3];
    $double tbl_pcommission=0.0, tbl_pagent=0.0, tbl_pdiscount=0.0, mnt_pass=0.0;
    char tmp_buf[12];
    int ins33_flag = 0;
    $int ins33_cnt = 0, cnt_rec = 0;

    $char iinsurant[11];
    $char iins_scope[2];
    $char icareer[2];
    $int exist_cnt = 0;
    $char fcard_class[2], imgr[2];

    /* 1000311003 �q��2 */
    $char insure_type[2], iofficer[11], fstart[2], fauth[2];
    $char irate_type[2], iroute_comm[4];
    $char ileader[11], iquota[11], icomm_obj[11], iroute[21], iroute_prop[3];
    $char opt[2];
    int *o_qrec;
    $struct cm_route_comm o_stcomm;
    $char icar_type[3];
    $char iins_cat[2];
    $char iyear[3], deffect[11];
    $int qply_period=0, rc=0;
    $char dcreate_max[31];

    cm_buf_get("%s", cDbName);
    cm_buf_get("%s", iendorse);

    $WHENEVER SQLERROR GOTO errexit;

    ins_cnt = 0;
    ins33_flag = 0;
    exist_cnt = 0;
    ins33_cnt = 0;
    iedr_type[0] = '\0';
    iedr_type_33[0] = '\0';
    iedr_return[0] = '\0';

    memset(&o_stcomm, 0, sizeof(o_stcomm));
    o_qrec = 0;
    iofficer[0] = fstart[0] = fauth[0] = '\0';
    strcpy(insure_type, "C");
    strcpy(deffect, "");

    if (db_select(cDbName) == False)
        return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    /* �]�w�����ݸ�Ʈw */
    strcpy(sDB, get_db(iendorse));
    if (strncmp(sDB, "100", 3) == 0)
    {
        if (exitsub(reply, M_CM_NOT_FOUND) == True)
            return M_CM_NOT_FOUND;
        else
            return apiRC;
    }

    if (db_select(sDB) == False)
        return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    rtoday(&dwritten);
    printf("car422_query_ori_endorse�G[%s]iendorse[%s] \n", sDB, iendorse);

    /* TABLE:edr_relation, endorsement */
    $SELECT a.ipolicy, a.dendorse, b.nassured[1, 30], a.iofficer, a.ibroker, a.iedr_return,
        c.dpolicy, c.dpolicy, a.fcard_class, b.iroute, a.irate_type, a.iroute_comm,
        c.icar_type, c.qply_period INTO $ipolicy, $dendorse, $nassured, $iofficer, $ibroker, $iedr_return,
        $dpolicy, $t_dpolicy, $fcard_class, $iroute, $irate_type, $iroute_comm,
        $icar_type, $qply_period FROM edr_relation a, endorsement b, ply_relation c WHERE a.iendorse = $iendorse AND a.iendorse = b.iendorse AND a.ipolicy = c.ipolicy AND a.dendorse is not null AND a.dedr_close is not null AND a.fedr_class not in('1', '2', '5');

    printf("car422_query_data�G[%s]iendorse[%s] \n", sDB, iendorse);
    if (SQLCODE == SQLNOTFOUND)
    {
        if (exitsub(reply, M_CM_NOT_FOUND) == True)
            return M_CM_NOT_FOUND;
        else
            return apiRC;
    }

    /* �Y�����N�I�n�h�P�_�g��N�� */
    if (strncmp(fcard_class, "2", 1) == 0)
    {
        /*$SELECT count(*) INTO $cnt_rec FROM edr_relation a
          WHERE iendorse = $iendorse
            AND (a.iofficer[1] in ('A','B','J','K','N') OR a.iofficer[1,3] in ('F05','G05'));*/
        /* car9802233,�אּŪ���g��H�ɪ����Ӥ@���O */
        $SELECT count(*) INTO $cnt_rec FROM edr_relation a, officer b
                                                                WHERE iendorse = $iendorse
                                                                                     AND a.iofficer = b.iofficer
                                                                                                          AND b.imgr = '1';

        if (cnt_rec = 0)
        {
            if (exitsub(reply, M_CM_NOT_FOUND) == True)
                return M_CM_NOT_FOUND;
            else
                return apiRC;
        }
    }

    printf("julia step2\n");

    strcpy(dendorse, cm_from_infdate_100(dendorse));
    strcpy(dpolicy, cm_from_infdate_100(dpolicy));

    /* ����󥻤�w�����A�BB���O�A�Х��R����A���� */

    exist_cnt = 0;
    $SELECT count(*)
        INTO $exist_cnt
            FROM edr_relation
                WHERE ipolicy = $ipolicy
                    AND fedr_class in('A', 'B')
                        AND dendorse = $dwritten;
    if (exist_cnt != 0)
    {
        if (exitsub(reply, M_CA_EXIST_ENDOR) == True)
            return M_CA_EXIST_ENDOR;
        else
            return apiRC;
    }

    /* �d�߸g��H�W�٥H�Ψ��Ӥ@���O */
    $SELECT nname[1, 10], imgr INTO $off_nname, $imgr FROM officer WHERE iofficer = $iofficer;
    if (SQLCODE == SQLNOTFOUND)
    {
        if (exitsub(reply, M_CA_NOT_IOFFICER) == True)
            return M_CA_NOT_IOFFICER;
        else
            return apiRC;
    }

    strcpy(brk_nname, "");
    if (strlen(trim(ibroker)) != 0)
    {
        /* �d�߸g���H�W�� */
        $SELECT nchi_abv[1, 10] INTO $brk_nname
            FROM broker_agent
                WHERE ibroker = $ibroker;
        if (SQLCODE == SQLNOTFOUND)
        {
            if (exitsub(reply, M_CA_NBROKER) == True)
                return M_CA_NBROKER;
            else
                return apiRC;
        }
    }

    /* ��榬�O���A�ˮ� */
    policy_1[0] = '\0';
    policy_2[0] = '\0';

    strncpy(policy_1, ipolicy, CAR_POLICY_LEN);
    policy_1[CAR_POLICY_LEN] = 0;

    if (strlen(ipolicy) > CAR_POLICY_LEN)
    {
        strncpy(policy_2, ipolicy + CAR_POLICY_LEN, 4);
        policy_2[4] = '\0';
    }
    else
        strcpy(policy_2, " ");

    payresult[0] = '\0';
    paystatus[0] = '\0';
    paydate[0] = '\0';
    notedate[0] = '\0';

    /*1090108009_SC1 car422��z�覡���@�~-�վ�O�_�w���O�P�_�޿�*/
    /* => ��̾� ao_prercv_pass �P�_�O�_�w���O*/
    /*
    ao_chk_charge(sDB, '2', policy_1, policy_2, iendorse,
                  payresult, paystatus, paydate, notedate);
    */
    mnt_pass = 0.0;
    strcpy(paydate, " ");
    strcpy(payresult, "N");
    strcpy(paystatus, "�����O");
    strcpy(notedate, " ");
    $select dacc_last, mnt into $paydate, $mnt_pass from ao_prercv_pass where iins_cat = 'C' and ipre_rcv = $iendorse and iins_kind = $fcard_class and ipre_end = ' ';

    if ((strlen(trim(paydate)) > 0) && (mnt_pass != 0))
    {
        strcpy(payresult, "Y");
        if (mnt_pass > 0)
            strcpy(paystatus, "�w���O");
        else
            strcpy(paystatus, "�w�h�O");
    }

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l", M_CM_OK);

    cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %s %s ",
               iendorse, ipolicy, nassured, iofficer, off_nname, brk_nname,
               payresult, paystatus, paydate, notedate,
               dendorse, dpolicy, iedr_return);

    $select max(dcreate)
        into $dcreate_max
            from edr_relation
                where ipolicy = $ipolicy and iendorse not like '%CVP%';

    cm_buf_put("%s ", dcreate_max);

    ins_cnt = 0;
    ins33_cnt = 0;
    ins33_flag = 0;

    printf("julia step3,iofficer[%s]\n", iofficer);

    /* �g��H��[A][B][C][D][J][K]�ɡA�~���վ��I�ؤ������N�z�O */
    /*if ((strncmp(iofficer,"A",1)!=0) &&
        (strncmp(iofficer,"B",1)!=0) &&
        (strncmp(iofficer,"J",1)!=0) &&
        (strncmp(iofficer,"K",1)!=0) &&
        (strncmp(iofficer,"N",1)!=0) &&
        (strncmp(iofficer,"F05",3)!=0) &&
        (strncmp(iofficer,"G05",3)!=0) &&*/
    /* car9802233,�אּŪ���g��H�ɪ����Ӥ@���O�P�_ */
    if (strncmp(imgr, "1", 1) != 0 &&
        (strncmp(fcard_class, "1", 1) != 0))
    {
        cm_buf_put("%d", 0); /* �@���I�ة��ӥ�� */
        cm_buf_put("%d", 0); /* �ˮ`�I���ӥ��   */
    }
    else
    {
        /* �d���I�ة��Ӹ�� */
        /* ���O�O����0�~���վ�����ΥN�z�O */
        $SELECT count(*)
            INTO $ins_cnt
                FROM edr_ins_type
                    WHERE iendorse = $iendorse
                        AND medrins_prem<> 0;
        if (ins_cnt == 0)
        {
            if (exitsub(reply, M_CM_NOT_FOUND) == True)
                return M_CM_NOT_FOUND;
            else
                return apiRC;
        }
        printf("iedr_return[%s]\n", iedr_return);
        printf("ins_cnt[%d]\n", ins_cnt);

        printf("julia 1 \n");

        cm_buf_put("%d", ins_cnt);

        strcpy(fstart, "Y");

        rc = get_iins_cat(icar_type, 1, qply_period, iins_cat, iyear, v_sMsg);
        if (rc != M_CM_OK)
        {
            if (exitsub(reply, rc) == True)
                return rc;
            else
                return apiRC;
        }

        $DECLARE ins_edr CURSOR FOR
            SELECT iins_type,
            iedr_type, medrins_prem,
            medrpure_prem, medr_prem,
            pcommission, medr_commission,
            pagent, medr_agent,
            pdiscount, medr_discount FROM edr_ins_type WHERE iendorse = $iendorse AND iedr_type<> '10' AND medrins_prem<> 0;
        $OPEN ins_edr;
        for (;;)
        {
            $FETCH ins_edr INTO $iins_type, $iedr_type,
                $medrins_prem,
                $medrpure_prem, $medr_prem,
                $pcommission, $medr_commission,
                $pagent, $medr_agent,
                $pdiscount, $medr_discount;

            if (SQLCODE == SQLNOTFOUND)
                break;
            strcpy(iins_type, trim(iins_type));
            printf("iins_type[%s]\n", iins_type);
            /* check �ˮ`�I�O�_�s�b 1.�s�b */
            if (strcmp(iins_type, "33") == 0)
                ins33_flag = 1;

            /* �I�ا��ʽ�    */
            /* 82:������(�t) */
            /* 83:������(��) */
            /* �Y��z�覡�쬰2.�z�L�O�N�A�N�����N�H�t�����覡�N�����N�z�O�k0�A�𶷿���]�w�������N�z�v�έ��s�p�� */
            if (strncmp(iedr_return, "1", 1) != 0)
            { /* [2.�z�L�O�N]�אּ[1.�Ȥ�˿�] */

                printf("julia 2 \n");
                if (medrins_prem > 0)
                {
                    cm_buf_put("%s", "82");

                    if (strcmp(iins_type, "33") == 0)
                    {
                        strcpy(iedr_type_33, "82");
                    }
                }
                else
                {
                    cm_buf_put("%s", "83");

                    if (strcmp(iins_type, "33") == 0)
                    {
                        strcpy(iedr_type_33, "83");
                    }
                }
            }
            else
            { /* [1.�Ȥ�˿�]�אּ[2.�z�L�O�N] */

                printf("julia 3 \n");
                if (medrins_prem > 0)
                {
                    cm_buf_put("%s", "83");

                    if (strcmp(iins_type, "33") == 0)
                    {
                        strcpy(iedr_type_33, "83");
                    }
                }
                else
                {
                    cm_buf_put("%s", "82");

                    if (strcmp(iins_type, "33") == 0)
                    {
                        strcpy(iedr_type_33, "82");
                    }
                }
            }
#if 0  /* --------------------------�Ȥ�˿��ߦ��� */
                   if (pdiscount < 0)   pdiscount   *= (-1);
                   if (pcommission < 0) pcommission *= (-1);
                   if (pagent < 0)      pagent      *= (-1);

                   cm_buf_put ("%s ",iins_type);
                   cm_buf_put ("%l ",medrins_prem);
                   sprintf_s(tmp_buf, sizeof tmp_buf,"%10.0f", medrpure_prem);
                   cm_buf_put ("%s ",tmp_buf);
                   cm_buf_put ("%l ",medr_prem);

                   sprintf_s(tmp_buf, sizeof tmp_buf,"%4.2f",pdiscount);
                   cm_buf_put ("%s ", tmp_buf);
                   cm_buf_put ("%l ", medr_discount);

                   /* ��l��v�Ϊ��B */
                   sprintf_s(tmp_buf, sizeof tmp_buf,"%4.2f",pcommission);
                   cm_buf_put ("%s ", tmp_buf);
                   cm_buf_put ("%l ", medr_commission);
                   
printf("����l���B,prem[%l],mcommission[%l]\n",medr_prem,medr_commission);                   

                   sprintf_s(tmp_buf, sizeof tmp_buf,"%4.2f",pagent);
                   cm_buf_put ("%s ", tmp_buf);
                   cm_buf_put ("%l ", medr_agent);

                   medr_commission *= (-1);
                   medr_agent      *= (-1);

                   /* �վ����B */
                   sprintf_s(tmp_buf, sizeof tmp_buf,"%4.2f",pcommission);
                   cm_buf_put ("%s ", tmp_buf);
                   
printf("���վ����B,prem[%l],mcommission[%l]\n",medr_prem,medr_commission);                    
                   cm_buf_put ("%l ", medr_commission);                   

                   sprintf_s(tmp_buf, sizeof tmp_buf,"%4.2f",pagent);
                   cm_buf_put ("%s ", tmp_buf);
                   cm_buf_put ("%l ", medr_agent);

                   /* �����N�z�]�w�� */
                   cm_buf_put ("%s" , " ");
                   cm_buf_put ("%s" , "0");
                   cm_buf_put ("%s" , "0");
                   cm_buf_put ("%s" , "0");
                   cm_buf_put ("%s" , "0");
                   cm_buf_put ("%s" , "0");
                   cm_buf_put ("%s" , "0");
                   cm_buf_put ("%s" , "0");
#endif /* --------------------------�Ȥ�˿��ߦ��� */

            if (pdiscount < 0)
                pdiscount *= (-1);
            if (pcommission < 0)
                pcommission *= (-1);
            if (pagent < 0)
                pagent *= (-1);

            cm_buf_put("%s ", iins_type);
            cm_buf_put("%l ", medrins_prem);

            sprintf_s(tmp_buf, sizeof tmp_buf, "%10.0f", medrpure_prem);
            cm_buf_put("%s ", tmp_buf);
            cm_buf_put("%l ", medr_prem);

            sprintf_s(tmp_buf, sizeof tmp_buf, "%4.2f", pdiscount);
            cm_buf_put("%s ", tmp_buf);
            cm_buf_put("%l ", medr_discount);

            /* ��l��v�Ϊ��B===>���Ҭ�0 */
            sprintf_s(tmp_buf, sizeof tmp_buf, "%4.2f", pcommission);
            cm_buf_put("%s ", tmp_buf);
            cm_buf_put("%l ", medr_commission);

            printf("����l���B,prem[%ld],mcommission[%ld]\n", medr_prem, medr_commission);

            sprintf_s(tmp_buf, sizeof tmp_buf, "%4.2f", pagent);
            cm_buf_put("%s ", tmp_buf);
            cm_buf_put("%l ", medr_agent);

            /* �Y������ʽ謰05�[�O�ɡA�h�������g���H�������N�z�v */
            /* 2008/11/17 �Y�j���I�h���|�i�J�o�@�q */
            if (strncmp(iedr_type, "05", 2) == 0 && strncmp(fcard_class, "2", 1) == 0)
            {
                if (fstart[0] == 'Y')
                {
                    rc = cm_get_insure_comm(iroute, irate_type, iroute_comm, insure_type, iins_cat, iins_type, iyear, &o_qrec, &o_stcomm, deffect);
                    if (rc != M_CM_OK)
                    {
                        if (exitsub(reply, rc) == True)
                            return rc;
                        else
                            return apiRC;
                    }
                    else if (o_qrec == 0)
                    {
                        if (iins_cat[0] == 'C' || iins_cat[0] == 'X' || iins_cat[0] == 'Z')
                        {
                            memset(&o_stcomm, 0x00, sizeof(o_stcomm));
                            o_qrec = 0;
                            strcpy(iins_cat, "C");
                            strcpy(iyear, "0");
                            rc = cm_get_insure_comm(iroute, irate_type, iroute_comm, insure_type, iins_cat, iins_type, iyear, &o_qrec, &o_stcomm, deffect);

                            if (rc != M_CM_OK)
                            {
                                if (exitsub(reply, rc) == True)
                                    return rc;
                                else
                                    return apiRC;
                            }
                        }
                        if (o_qrec == 0)
                        {
                            if (exitsub(reply, M_CA_NCOMMISSION_AGENT) == True)
                                return M_CA_NCOMMISSION_AGENT;
                            else
                                return apiRC;
                        }
                    }

                    tbl_pagent = o_stcomm.pagent * 100;
                    tbl_pcommission = o_stcomm.pcommiss * 100;
                    tbl_pdiscount = o_stcomm.pdiscount * 100;
                    pfix_agent = o_stcomm.pfix_agent;
                    strcpy(icheck_agent, o_stcomm.icheck_agent);
                    strcpy(icheck_commi, o_stcomm.icheck_commi);
                    strcpy(icheck_disc, o_stcomm.icheck_disc);
                    strcpy(ipaid_base, o_stcomm.ipaid_base);
                }
                else
                {
                    $SELECT pagent * 100, icheck_agent,
                        pcommiss * 100, icheck_commi,
                        pdiscount * 100, icheck_disc,
                        pfix_agent,
                        ipaid_base
                            INTO $tbl_pagent,
                        $icheck_agent,
                        $tbl_pcommission, $icheck_commi,
                        $tbl_pdiscount, $icheck_disc,
                        $pfix_agent,
                        $ipaid_base
                            FROM commission_agent
                                WHERE iins_cat = 'C' AND ibroker = $ibroker
                                    AND iins_type = $iins_type;
                    if (SQLCODE == SQLNOTFOUND)
                    {
                        if (exitsub(reply, M_CA_NCOMMISSION_AGENT) == True)
                            return M_CA_NCOMMISSION_AGENT;
                        else
                            return apiRC;
                    }
                }

                if (strncmp(icheck_agent, "4", 1) == 0) /* �B��--�̦����v */
                {                                       /* �p���I�ĤT��L����i�� */
                    tbl_pagent = (double)tbl_pcommission * (double)(pfix_agent / 100.00);
                    tbl_pagent = tbl_pagent + 0.009;
                    tbl_pagent = (long)(tbl_pagent * 100);
                    tbl_pagent = (double)((double)tbl_pagent / 100.00);
                }

                if (strcmp(iins_type, "33") != 0)
                {
                    if (t_dpolicy <= cm_ymd_cdate("91/04/01"))
                    {
                        medr_commission = (long)(((double)medrins_prem * (double)(tbl_pcommission / 100.00)) + 0.5);
                        medr_agent = (long)(((double)medrins_prem * (double)(tbl_pagent / 100.00)) + 0.5);
                    }
                    else
                    {
                        if (strncmp(ipaid_base, "A", 1) == 0) /* �u�f��I�� */
                        {
                            medr_commission = (long)(((double)medrins_prem * (double)(tbl_pcommission / 100.00)) + 0.5);
                            medr_agent = (long)(((double)medrins_prem * (double)(tbl_pagent / 100.00)) + 0.5);
                        }
                        else /* �u�f�e�I�� */
                        {
                            medr_commission = (long)(((double)(medrins_prem + medr_discount) * (double)(tbl_pcommission / 100.00)) + 0.5);
                            medr_agent = (long)(((double)(medrins_prem + medr_discount) * (double)(tbl_pagent / 100.00)) + 0.5);
                        }
                    }
                }
                else
                {
                    $DECLARE ins_33_cur CURSOR FOR
                        SELECT medrins_prem,
                        medr_discount
                            INTO $medrins_prem_33,
                        $medr_discount_33
                            FROM ca_pa_edr
                                WHERE iendorse = $iendorse
                                    AND iedr_type<> '10' AND medrins_prem<> 0;
                    $OPEN ins_33_cur;
                    for (;;)
                    {
                        $FETCH ins_33_cur;
                        if (SQLCODE == SQLNOTFOUND)
                            break;

                        if (strncmp(ipaid_base, "A", 1) == 0) /* �u�f��I�� */
                        {
                            medr_commission += (long)(((double)medrins_prem_33 * (double)(tbl_pcommission / 100.00)) + 0.5);
                            medr_agent += (long)(((double)medrins_prem_33 * (double)(tbl_pagent / 100.00)) + 0.5);
                        }
                        else /* �u�f�e�I�� */
                        {
                            medr_commission += (long)(((double)(medrins_prem_33 + medr_discount_33) * (double)(tbl_pcommission / 100.00)) + 0.5);
                            medr_agent += (long)(((double)(medrins_prem_33 + medr_discount_33) * (double)(tbl_pagent / 100.00)) + 0.5);
                        }
                    }
                    $CLOSE ins_33_cur;
                    $FREE ins_33_cur;
                }

                /* �վ����B */
                sprintf_s(tmp_buf, sizeof tmp_buf, "%4.2f", tbl_pcommission);
                cm_buf_put("%s ", tmp_buf);
                cm_buf_put("%l ", medr_commission);

                sprintf_s(tmp_buf, sizeof tmp_buf, "%4.2f", tbl_pagent);
                cm_buf_put("%s ", tmp_buf);
                cm_buf_put("%l ", medr_agent);

                /* �����N�z�]�w�� */
                cm_buf_put("%s", ipaid_base);

                sprintf_s(tmp_buf, sizeof tmp_buf, "%4.2f", pfix_agent);
                cm_buf_put("%s", tmp_buf);

                sprintf_s(tmp_buf, sizeof tmp_buf, "%4.2f", tbl_pdiscount);
                cm_buf_put("%s", tmp_buf);

                cm_buf_put("%s", icheck_disc);

                sprintf_s(tmp_buf, sizeof tmp_buf, "%4.2f", tbl_pcommission);
                cm_buf_put("%s", tmp_buf);

                cm_buf_put("%s", icheck_commi);

                sprintf_s(tmp_buf, sizeof tmp_buf, "%4.2f", tbl_pagent);
                cm_buf_put("%s", tmp_buf);

                cm_buf_put("%s", icheck_agent);
            }    /* end of if (strncmp(iedr_type,"05",2)==0) */
            else /* �Y������ʽ褣��05�[�O�ɡA�h�ܫO���I�ة����ɿ��������N�z�v */
            {
                /* ���N�I�h�ӳ̷s�I���ɥߦ���,���j���I�h�O�̷ӧ��ߥ��t�� */
                if (strncmp(fcard_class, "1", 1) != 0)
                {
                    $SELECT pcommission, pagent, ipaid_base INTO $pcommission, $pagent, $ipaid_base FROM ply_ins_type WHERE ipolicy = $ipolicy AND iins_type = $iins_type;

                    if (SQLCODE == SQLNOTFOUND)
                    {
                        if (exitsub(reply, M_CA_NINSTYPE) == True)
                            return M_CA_NINSTYPE;
                        else
                            return apiRC;
                    }

                    if (strcmp(iins_type, "33") != 0)
                    {
                        if (t_dpolicy <= cm_ymd_cdate("91/04/01"))
                        {
                            medr_commission = (long)(((double)medrins_prem * (double)(tbl_pcommission / 100.00)) + 0.5);
                            medr_agent = (long)(((double)medrins_prem * (double)(tbl_pagent / 100.00)) + 0.5);
                        }
                        else
                        {
                            if (strncmp(ipaid_base, "A", 1) == 0) /* �u�f��I�� */
                            {
                                medr_commission = (long)(((double)medrins_prem * (double)(pcommission / 100.00)) + 0.5);
                                medr_agent = (long)(((double)medrins_prem * (double)(pagent / 100.00)) + 0.5);
                            }
                            else /* �u�f�e�I�� */
                            {
                                medr_commission = (long)(((double)(medrins_prem + medr_discount) * (double)(pcommission / 100.00)) + 0.5);
                                medr_agent = (long)(((double)(medrins_prem + medr_discount) * (double)(pagent / 100.00)) + 0.5);
                            }
                        }
                        printf("julia 4, medr_commission[%ld],medr_agent[%ld]\n", medr_commission, medr_agent);
                    }
                    else
                    {
                        $DECLARE ins_33_cur_2 CURSOR FOR
                            SELECT medrins_prem,
                            medr_discount
                                INTO $medrins_prem_33,
                            $medr_discount_33
                                FROM ca_pa_edr
                                    WHERE iendorse = $iendorse
                                        AND iedr_type<> '10' AND medrins_prem<> 0;
                        $OPEN ins_33_cur_2;
                        for (;;)
                        {
                            $FETCH ins_33_cur_2;
                            if (SQLCODE == SQLNOTFOUND)
                                break;

                            if (strncmp(ipaid_base, "A", 1) == 0) /* �u�f��I�� */
                            {
                                medr_commission += (long)(((double)medrins_prem_33 * (double)(tbl_pcommission / 100.00)) + 0.5);
                                medr_agent += (long)(((double)medrins_prem_33 * (double)(tbl_pagent / 100.00)) + 0.5);
                            }
                            else /* �u�f�e�I�� */
                            {
                                medr_commission += (long)(((double)(medrins_prem_33 + medr_discount_33) * (double)(tbl_pcommission / 100.00)) + 0.5);
                                medr_agent += (long)(((double)(medrins_prem_33 + medr_discount_33) * (double)(tbl_pagent / 100.00)) + 0.5);
                            }
                        }
                        $CLOSE ins_33_cur_2;
                        $FREE ins_33_cur_2;
                    } /* end of strcmp(iins_type,"33") != 0 */
                }     /* end of  strncmp(fcard_class,"1",1)!=0 */

                /* �վ����B */
                sprintf_s(tmp_buf, sizeof tmp_buf, "%4.2f", pcommission);
                cm_buf_put("%s ", tmp_buf);

                printf("���վ����B,prem[%ld],mcommission[%ld],pcommission[%s]\n", medr_prem, medr_commission, tmp_buf);
                cm_buf_put("%l ", medr_commission);

                sprintf_s(tmp_buf, sizeof tmp_buf, "%4.2f", pagent);
                cm_buf_put("%s ", tmp_buf);
                cm_buf_put("%l ", medr_agent);

                /* �����N�z�]�w�� */
                cm_buf_put("%s", " ");
                cm_buf_put("%s", "0");
                cm_buf_put("%s", "0");
                cm_buf_put("%s", "0");
                cm_buf_put("%s", "0");
                cm_buf_put("%s", "0");
                cm_buf_put("%s", "0");
                cm_buf_put("%s", "0");
            } /* end of if (strncmp(iedr_type,"05",2)==0) */
        }
        $CLOSE ins_edr;
        $FREE ins_edr;

        printf("�ˮ`�I�����O[%d]\n", ins33_flag);
        if (ins33_flag == 0)
        {
            cm_buf_put("%d", 0);
        }
        else
        {
            $SELECT count(*)
                INTO $ins33_cnt
                    FROM ca_pa_edr
                        WHERE iendorse = $iendorse
                            AND iedr_type<> '10' AND medrins_prem<> 0;
            if (ins33_cnt == 0)
            {
                if (exitsub(reply, M_CM_NOT_FOUND) == True)
                    return M_CM_NOT_FOUND;
                else
                    return apiRC;
            }

            cm_buf_put("%d", ins33_cnt);

            $SELECT iedr_type
                INTO : iedr_type
                           FROM edr_ins_type
                               WHERE iendorse = $iendorse
                                   AND iins_type = '33';
            if (SQLCODE == SQLNOTFOUND)
            {
                if (exitsub(reply, M_CM_NOT_FOUND) == True)
                    return M_CM_NOT_FOUND;
                else
                    return apiRC;
            }

            printf("�I��33�����ʽ�[%s]\n", iedr_type);

            $DECLARE pa_edr_cur CURSOR FOR
                SELECT iinsurant,
                iins_scope, icareer,
                medrins_prem,
                pcommission, medr_commission,
                pagent, medr_agent,
                pdiscount, medr_discount FROM ca_pa_edr WHERE iendorse = $iendorse AND iedr_type<> '10' AND medrins_prem<> 0;
            $OPEN pa_edr_cur;
            for (;;)
            {
                $FETCH pa_edr_cur
                    INTO $iinsurant,
                    $iins_scope, $icareer,
                    $medrins_prem,
                    $pcommission, $medr_commission,
                    $pagent, $medr_agent,
                    $pdiscount, $medr_discount;

                if (SQLCODE == SQLNOTFOUND)
                    break;

                printf("iedr_type_33[%s]\n", iedr_type_33);

                /* �ھ��I��33�����ʽ� */
                cm_buf_put("%s", iedr_type_33);

                if (pdiscount < 0)
                    pdiscount *= (-1);
                if (pcommission < 0)
                    pcommission *= (-1);
                if (pagent < 0)
                    pagent *= (-1);

                cm_buf_put("%s ", iinsurant);
                cm_buf_put("%s ", iins_scope);
                cm_buf_put("%s ", icareer);
                cm_buf_put("%l ", medrins_prem);

                sprintf_s(tmp_buf, sizeof tmp_buf, "%4.2f", pdiscount);
                cm_buf_put("%s ", tmp_buf);
                cm_buf_put("%l ", medr_discount);

                /* ��l��v�Ϊ��B */
                sprintf_s(tmp_buf, sizeof tmp_buf, "%4.2f", pcommission);
                cm_buf_put("%s ", tmp_buf);
                cm_buf_put("%l ", medr_commission);

                sprintf_s(tmp_buf, sizeof tmp_buf, "%4.2f", pagent);
                cm_buf_put("%s ", tmp_buf);
                cm_buf_put("%l ", medr_agent);

                /* �Y��z�覡�쬰2.�z�L�O�N�A�N�����N�H�t�����覡�N�����N�z�O�k0�A�𶷿���]�w�������N�z�v�έ��s�p�� */
                if (strncmp(iedr_return, "1", 1) != 0)
                { /* [2.�z�L�O�N]�אּ[1.�Ȥ�˿�] */
                    medr_commission *= (-1);
                    medr_agent *= (-1);

                    /* �վ����B */
                    sprintf_s(tmp_buf, sizeof tmp_buf, "%4.2f", pcommission);
                    cm_buf_put("%s ", tmp_buf);
                    cm_buf_put("%l ", medr_commission);

                    sprintf_s(tmp_buf, sizeof tmp_buf, "%4.2f", pagent);
                    cm_buf_put("%s ", tmp_buf);
                    cm_buf_put("%l ", medr_agent);
                }
                else
                { /* [1.�Ȥ�˿�]�אּ[2.�z�L�O�N] */
                    /* �Y������ʽ謰05�[�O�ɡA�h�������g���H�������N�z�v */
                    if (strncmp(iedr_type, "05", 2) == 0)
                    {
                        if (fstart[0] == 'Y')
                        {
                            rc = cm_get_insure_comm(iroute, irate_type, iroute_comm, insure_type, iins_cat, iins_type, iyear, &o_qrec, &o_stcomm, deffect);
                            if (rc != M_CM_OK)
                            {
                                if (exitsub(reply, rc) == True)
                                    return rc;
                                else
                                    return apiRC;
                            }
                            else if (o_qrec == 0)
                            {
                                if (iins_cat[0] == 'C' || iins_cat[0] == 'X' || iins_cat[0] == 'Z')
                                {
                                    memset(&o_stcomm, 0x00, sizeof(o_stcomm));
                                    o_qrec = 0;
                                    strcpy(iins_cat, "C");
                                    strcpy(iyear, "0");
                                    rc = cm_get_insure_comm(iroute, irate_type, iroute_comm, insure_type, iins_cat, iins_type, iyear, &o_qrec, &o_stcomm, deffect);

                                    if (rc != M_CM_OK)
                                    {
                                        if (exitsub(reply, rc) == True)
                                            return rc;
                                        else
                                            return apiRC;
                                    }
                                }
                                if (o_qrec == 0)
                                {
                                    if (exitsub(reply, M_CA_NCOMMISSION_AGENT) == True)
                                        return M_CA_NCOMMISSION_AGENT;
                                    else
                                        return apiRC;
                                }
                            }

                            tbl_pagent = o_stcomm.pagent * 100;
                            tbl_pcommission = o_stcomm.pcommiss * 100;
                            tbl_pdiscount = o_stcomm.pdiscount * 100;
                            pfix_agent = o_stcomm.pfix_agent;
                            strcpy(icheck_agent, o_stcomm.icheck_agent);
                            strcpy(icheck_commi, o_stcomm.icheck_commi);
                            strcpy(icheck_disc, o_stcomm.icheck_disc);
                            strcpy(ipaid_base, o_stcomm.ipaid_base);
                        }
                        else
                        {
                            $SELECT pagent * 100, icheck_agent,
                                pcommiss * 100, icheck_commi,
                                pdiscount * 100, icheck_disc,
                                pfix_agent, ipaid_base INTO $tbl_pagent, $icheck_agent,
                                $tbl_pcommission, $icheck_commi,
                                $tbl_pdiscount, $icheck_disc,
                                $pfix_agent, $ipaid_base FROM commission_agent WHERE iins_cat = 'C' AND ibroker = $ibroker AND iins_type = '33';
                            if (SQLCODE == SQLNOTFOUND)
                            {
                                if (exitsub(reply, M_CA_NCOMMISSION_AGENT) == True)
                                    return M_CA_NCOMMISSION_AGENT;
                                else
                                    return apiRC;
                            }
                        }

                        if (strncmp(icheck_agent, "4", 1) == 0) /* �B��--�̦����v */
                        {                                       /* �p���I�ĤT��L����i�� */
                            tbl_pagent = (double)tbl_pcommission * (double)(pfix_agent / 100.00);
                            tbl_pagent = tbl_pagent + 0.009;
                            tbl_pagent = (long)(tbl_pagent * 100);
                            tbl_pagent = (double)((double)tbl_pagent / 100.00);
                        }

                        if (strncmp(ipaid_base, "A", 1) == 0) /* �u�f��I�� */
                        {
                            medr_commission = (long)(((double)medrins_prem * (double)(tbl_pcommission / 100.00)) + 0.5);
                            medr_agent = (long)(((double)medrins_prem * (double)(tbl_pagent / 100.00)) + 0.5);
                        }
                        else /* �u�f�e�I�� */
                        {
                            medr_commission = (long)(((double)(medrins_prem + medr_discount) * (double)(tbl_pcommission / 100.00)) + 0.5);
                            medr_agent = (long)(((double)(medrins_prem + medr_discount) * (double)(tbl_pagent / 100.00)) + 0.5);
                        }

                        /* �վ����B */
                        sprintf_s(tmp_buf, sizeof tmp_buf, "%4.2f", tbl_pcommission);
                        cm_buf_put("%s ", tmp_buf);
                        cm_buf_put("%l ", medr_commission);

                        sprintf_s(tmp_buf, sizeof tmp_buf, "%4.2f", tbl_pagent);
                        cm_buf_put("%s ", tmp_buf);
                        cm_buf_put("%l ", medr_agent);
                    }
                    else /* �Y������ʽ褣��05�[�O�ɡA�h�ܫO���I�ة����ɿ��������N�z�v */
                    {
                        $SELECT pcommission, pagent, ipaid_base INTO $pcommission, $pagent, $ipaid_base FROM ply_ins_type WHERE ipolicy = $ipolicy AND iins_type = '33';
                        if (SQLCODE == SQLNOTFOUND)
                        {
                            if (exitsub(reply, M_CA_NINSTYPE) == True)
                                return M_CA_NINSTYPE;
                            else
                                return apiRC;
                        }

                        if (strncmp(ipaid_base, "A", 1) == 0) /* �u�f��I�� */
                        {
                            medr_commission = (long)(((double)medrins_prem * (double)(pcommission / 100.00)) + 0.5);
                            medr_agent = (long)(((double)medrins_prem * (double)(pagent / 100.00)) + 0.5);
                        }
                        else /* �u�f�e�I�� */
                        {
                            medr_commission = (long)(((double)(medrins_prem + medr_discount) * (double)(pcommission / 100.00)) + 0.5);
                            medr_agent = (long)(((double)(medrins_prem + medr_discount) * (double)(pagent / 100.00)) + 0.5);
                        }

                        /* �վ����B */
                        sprintf_s(tmp_buf, sizeof tmp_buf, "%4.2f", pcommission);
                        cm_buf_put("%s ", tmp_buf);
                        cm_buf_put("%l ", medr_commission);

                        sprintf_s(tmp_buf, sizeof tmp_buf, "%4.2f", pagent);
                        cm_buf_put("%s ", tmp_buf);
                        cm_buf_put("%l ", medr_agent);
                    }
                }
            }
            $CLOSE pa_edr_cur;
            $FREE pa_edr_cur;
        }
    }

    iRtnLen = cm_buf_len(ReplyBuf);

    if (SendSyncReply(reply, ReplyBuf, iRtnLen, api_OKComplete) == False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    if (exitsub(reply, SQLCODE) == True)
        return SQLCODE;
    else
        return apiRC;
}

/****************************************************************************/
/**** ���d�� *************************************************************/
/***************************************************************************/
long car422_single_query(reply)
serverReply reply;
{
    long MsgCode;
    $char stmt[8000];
    $char cBuf[10];
    $char ipolicy[21];
    $char dendorse[11];
    $char iendorse1[21], iendorse2[21];
    $char dpolicy[11];
    $char iofficer[11];
    $char icorps[11];
    $char iquota[7];
    $char ileader[11];
    $char ibroker[11];
    $char iresource[2];
    $char iedr_return[3];
    $char nedr_return[20];
    $char nassured[121];
    $char off_nname[21];
    $char cor_nname[21];
    $char quo_nname[41];
    $char lead_nname[11];
    $char nchi_abv[13];
    $char nresource[21];
    $char iins_type[INSURANCE_TYPE];
    $long mdiscount;
    $long mins_premium;
    $double pcommission, pagent;
    $double pdiscount;
    $long mcommission, magent;
    $int ins_cnt;
    $char tmp_pdiscount[8];
    $char tmp_pcommission[8];
    $char tmp_pagent[8];
    $char sDB[3];
    $char fedr_class[2];
    $char iedr_type[3];
    $char iendorse_tmp[21];
    int iiedr;

    $double new_pcommission, new_pagent;
    $long new_mcommission, new_magent;
    $char new_tmp_pcommission[8], new_tmp_pagent[8];

    pdiscount = 0;
    mdiscount = 0;
    mins_premium = 0;
    pcommission = 0;
    pagent = 0;
    mcommission = 0;
    magent = 0;

    cm_buf_get("%s", cDbName);
    cm_buf_get("%s %s %s %s", ipolicy, dendorse, iendorse1, iendorse2);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(cDbName) == False)
        return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    strcpy(sDB, get_db(ipolicy));
    if (strncmp(sDB, "100", 3) == 0)
    {
        if (exitsub(reply, M_CM_NOT_FOUND) == True)
            return M_CM_NOT_FOUND;
        else
            return apiRC;
    }

    if (db_select(sDB) == False)
        return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    printf("iendorse1[%s] flag1\n", iendorse1);
    $SELECT dpolicy, iofficer, icorps, iquota, ileader, ibroker, iresource INTO $dpolicy, $iofficer, $icorps, $iquota, $ileader, $ibroker, $iresource FROM ply_relation_bak WHERE ipolicy = $ipolicy AND iendorse = $iendorse1;
    if (SQLCODE == SQLNOTFOUND)
    {
        if (exitsub(reply, M_CM_NOT_FOUND) == True)
            return M_CM_NOT_FOUND;
        else
            return apiRC;
    }
    strcpy(dpolicy, cm_from_infdate_100(dpolicy));

    printf("iendorse1[%s] flag1\n", iendorse1);

    /*
    $SELECT UNIQUE iedr_type
       INTO $iedr_type
       FROM edr_ins_type
      WHERE iendorse = $iendorse1;
    if (SQLCODE == SQLNOTFOUND)
    {
     if( exitsub(reply,M_CM_NOT_FOUND) == True )
         return M_CM_NOT_FOUND;
     else
         return apiRC;
    }
    iiedr = atoi(iedr_type);
    */
    /* 109.01.08 fix -284���D */
    iiedr = 0;
    ins_cnt = 0;
    $DECLARE chk_iedr_type CURSOR FOR
        SELECT UNIQUE iedr_type
            FROM edr_ins_type
                WHERE iendorse = $iendorse1;
    $OPEN chk_iedr_type;
    for (;;)
    {
        $FETCH chk_iedr_type INTO $iedr_type;
        if (SQLCODE == SQLNOTFOUND)
            break;

        ins_cnt++;
        if (strncmp(iedr_type, "84", 2) == 0)
            iiedr = 84;
    }
    $CLOSE chk_iedr_type;
    $FREE chk_iedr_type;

    if (ins_cnt == 0)
    {
        if (exitsub(reply, M_CM_NOT_FOUND) == True)
            return M_CM_NOT_FOUND;
        else
            return apiRC;
    }

    printf("iiedr[%d]\n", iiedr);
    $SELECT nassured
        INTO $nassured
            FROM policy_bak
                WHERE ipolicy = $ipolicy
                    AND iendorse = $iendorse1;
    if (SQLCODE == SQLNOTFOUND)
    {
        if (exitsub(reply, M_CM_NOT_FOUND) == True)
            return M_CM_NOT_FOUND;
        else
            return apiRC;
    }

    strcpy(off_nname, " ");
    $SELECT nname
        INTO $off_nname
            FROM officer
                WHERE iofficer = $iofficer;
    if (SQLCODE == SQLNOTFOUND)
    {
        if (exitsub(reply, M_CA_NOT_IOFFICER) == True)
            return M_CA_NOT_IOFFICER;
        else
            return apiRC;
    }

    strcpy(cor_nname, " ");
    if (strlen(trim(icorps)) != 0)
    {
        $SELECT nname
            INTO $cor_nname
                FROM officer
                    WHERE iofficer = $icorps;
        if (SQLCODE == SQLNOTFOUND)
        {
            if (exitsub(reply, M_CA_NOT_ICORPS) == True)
                return M_CA_NOT_ICORPS;
            else
                return apiRC;
        }
    }

    $SELECT nbranch
        INTO $quo_nname
            FROM sa_branch_type
                WHERE ibranch = $iquota;
    if (SQLCODE == SQLNOTFOUND)
    {
        if (exitsub(reply, M_CA_NOT_IQUOTA) == True)
            return M_CA_NOT_IQUOTA;
        else
            return apiRC;
    }

    $SELECT nname
        INTO $lead_nname
            FROM officer
                WHERE iofficer = $ileader;
    if (SQLCODE == SQLNOTFOUND)
    {
        if (exitsub(reply, M_CA_NOT_ILEADER) == True)
            return M_CA_NOT_ILEADER;
        else
            return apiRC;
    }
    strcpy(nchi_abv, " ");

    $SELECT ncode
        INTO $nresource
            FROM cu_code_data
                WHERE itype = '10' AND icode = $iresource;
    if (SQLCODE == SQLNOTFOUND)
    {
        if (exitsub(reply, M_CA_NOT_IRESOURCE) == True)
            return M_CA_NOT_IRESOURCE;
        else
            return apiRC;
    }

    $SELECT dendorse, iedr_return INTO $dendorse, $iedr_return FROM edr_relation WHERE iendorse = $iendorse1;
    if (SQLCODE == SQLNOTFOUND)
    {
        if (exitsub(reply, M_CM_NOT_FOUND) == True)
            return M_CM_NOT_FOUND;
        else
            return apiRC;
    }
    strcpy(dendorse, cm_from_infdate_100(dendorse));

    if (strncmp(iedr_return, "1", 1) == 0)
    {
        strcpy(nedr_return, "1.�Ȥ�˿�");
    }
    else
    {
        strcpy(nedr_return, "2.�z�L�O�N");
    }

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l", M_CM_OK);

    cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
               ipolicy, iendorse1, iendorse2, dpolicy, nassured, iofficer, icorps,
               iquota, ileader, ibroker, iedr_return,
               off_nname, cor_nname, quo_nname, lead_nname, nchi_abv, nedr_return, dendorse);

    if (iiedr != 84)
    {
        $SELECT fedr_class, dendorse, iofficer, icorps, iquota, ileader, ibroker, iresource, iedr_return INTO $fedr_class, $dendorse, $iofficer, $icorps, $iquota, $ileader, $ibroker, $iresource, $iedr_return FROM edr_relation WHERE iendorse = $iendorse2;
        if (SQLCODE == SQLNOTFOUND)
        {
            if (exitsub(reply, M_CM_NOT_FOUND) == True)
                return M_CM_NOT_FOUND;
            else
                return apiRC;
        }
        strcpy(dendorse, cm_from_infdate_100(dendorse));

        if (strncmp(iedr_return, "1", 1) == 0)
        {
            strcpy(nedr_return, "1.�Ȥ�˿�");
        }
        else
        {
            strcpy(nedr_return, "2.�z�L�O�N");
        }

        strcpy(off_nname, " ");
        $SELECT nname
            INTO $off_nname
                FROM officer
                    WHERE iofficer = $iofficer;
        if (SQLCODE == SQLNOTFOUND)
        {
            if (exitsub(reply, M_CA_NOT_IOFFICER) == True)
                return M_CA_NOT_IOFFICER;
            else
                return apiRC;
        }

        strcpy(cor_nname, " ");
        if (strlen(trim(icorps)) != 0)
        {
            $SELECT nname
                INTO $cor_nname
                    FROM officer
                        WHERE iofficer = $icorps;
            if (SQLCODE == SQLNOTFOUND)
            {
                if (exitsub(reply, M_CA_NOT_ICORPS) == True)
                    return M_CA_NOT_ICORPS;
                else
                    return apiRC;
            }
        }

        $SELECT nbranch
            INTO $quo_nname
                FROM sa_branch_type
                    WHERE ibranch = $iquota;
        if (SQLCODE == SQLNOTFOUND)
        {
            if (exitsub(reply, M_CA_NOT_IQUOTA) == True)
                return M_CA_NOT_IQUOTA;
            else
                return apiRC;
        }

        $SELECT nname
            INTO $lead_nname
                FROM officer
                    WHERE iofficer = $ileader;
        if (SQLCODE == SQLNOTFOUND)
        {
            if (exitsub(reply, M_CA_NOT_ILEADER) == True)
                return M_CA_NOT_ILEADER;
            else
                return apiRC;
        }

        strcpy(nchi_abv, " ");

        $SELECT ncode
            INTO $nresource
                FROM cu_code_data
                    WHERE itype = '10' AND icode = $iresource;
        if (SQLCODE == SQLNOTFOUND)
        {
            if (exitsub(reply, M_CA_NOT_IRESOURCE) == True)
                return M_CA_NOT_IRESOURCE;
            else
                return apiRC;
        }
    }
    else
    {
        strcpy(fedr_class, " ");
        strcpy(dendorse, " ");
        strcpy(iofficer, " ");
        strcpy(icorps, " ");
        strcpy(iquota, " ");
        strcpy(ileader, " ");
        strcpy(ibroker, " ");
        strcpy(iresource, " ");
        strcpy(off_nname, " ");
        strcpy(cor_nname, " ");
        strcpy(quo_nname, " ");
        strcpy(lead_nname, " ");
        strcpy(nchi_abv, " ");
        strcpy(nresource, " ");
    }
    cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %s %s %s",
               fedr_class, dendorse, iofficer, icorps,
               iquota, ileader, ibroker, iedr_return,
               off_nname, cor_nname, quo_nname, lead_nname, nchi_abv, nedr_return);

    $SELECT count(*)
        INTO $ins_cnt
            FROM edr_ins_type
                WHERE iendorse = $iendorse1;
    if (ins_cnt == 0)
    {
        if (exitsub(reply, M_CM_NOT_FOUND) == True)
            return M_CM_NOT_FOUND;
        else
            return apiRC;
    }

    printf("ins_cnt[%d]\n", ins_cnt);
    cm_buf_put("%l", ins_cnt);

    sprintf_s(stmt, sizeof stmt,
            " SELECT pcommission, medr_commission, pagent, medr_agent  "
            " FROM edr_ins_type                                       "
            " WHERE iendorse = ?                                      "
            "  AND iins_type = ? ");
    $PREPARE new_ins FROM $stmt;

    $DECLARE ins_bak CURSOR FOR
        SELECT a.iins_type,
        a.pdiscount, a.mdiscount, a.mins_premium,
        a.pcommission, a.mcommission, a.pagent, a.magent FROM ply_ins_type_bak a, edr_ins_type b WHERE a.ipolicy = $ipolicy AND a.iendorse = $iendorse1 AND a.iins_type = b.iins_type AND a.iendorse = b.iendorse;
    $OPEN ins_bak;
    for (;;)
    {
        $FETCH ins_bak
            INTO $iins_type,
            $pdiscount, $mdiscount, $mins_premium,
            $pcommission, $mcommission, $pagent, $magent;
        if (SQLCODE == SQLNOTFOUND)
            break;
        strcpy(iins_type, trim(iins_type));
        printf(" end ins_bak \n");
        printf(" iins_type[%s]\n", iins_type);

        if (iiedr != 84)
        {
            strcpy(iendorse_tmp, iendorse2);
        }
        else
        {
            strcpy(iendorse_tmp, iendorse1);
        }
        $EXECUTE new_ins
            INTO $new_pcommission,
            $new_mcommission, $new_pagent, $new_magent USING $iendorse_tmp, $iins_type;
        printf(" end new_ins \n");
        if (SQLCODE == SQLNOTFOUND)
        {
            if (exitsub(reply, M_CM_NOT_FOUND) == True)
                return M_CM_NOT_FOUND;
            else
                return apiRC;
        }

        printf("INTO cursor \n");
        sprintf_s(tmp_pcommission, sizeof tmp_pcommission, "%4.2f", pcommission);
        sprintf_s(tmp_pagent, sizeof tmp_pagent, "%4.2f", pagent);
        sprintf_s(tmp_pdiscount, sizeof tmp_pdiscount, "%4.2f", pdiscount);
        sprintf_s(new_tmp_pcommission, sizeof new_tmp_pcommission, "%4.2f", new_pcommission);
        sprintf_s(new_tmp_pagent, sizeof new_tmp_pagent, "%4.2f", new_pagent);

        cm_buf_put("%s %s %l %l %s %l %s %l",
                   iins_type, tmp_pdiscount, mdiscount, mins_premium,
                   tmp_pcommission, mcommission, tmp_pagent, magent);
        cm_buf_put("%s %l %s %l",
                   new_tmp_pcommission, new_mcommission, new_tmp_pagent, new_magent);
    }
    $CLOSE ins_bak;
    $FREE ins_bak;

    iRtnLen = cm_buf_len(ReplyBuf);

    if (SendSyncReply(reply, ReplyBuf, iRtnLen, api_OKComplete) == False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    return SQLCODE;
} /* car422_single_query */

long car422_insert(reply, option, command, com_len)
serverReply reply;
char option;
voidP command;
int com_len;
{
    long MsgCode;
    $char userid[11];
    $char ipolicy[POLICY_NUM_1];
    $char oriIendorse[ENDORSE_NUM];
    $char oriIedrReturn[2];
    $char newIedrReturn[2];
    $char sDB[3];
    $char sIdir[9];
    $char ibranch_at[3], icomp_at[3];
    $date dwritten;

    $char fedr_class[2];
    int iins_33_flag;
    $int ins_count;
    $int ins_count_33;
    $int i, j_33;

    $int ibatch_no;
    $char batchno[4];
    char payresult[5], paystatus[100], paydate[100], notedate[100];

    $char policy_1[21], policy_2[21];
    $char fpay[2];

    char sIbilling[3];
    char sIbranchIcomp[CA_POL_BRH_NUM];
    char sIcomp_in[BRANCH_ID], sIbranch_in[BRANCH_ID];
    $long fRtnCode;
    char sIcomp_in_short[BRANCH_ID];
    $char temp_1[POLICY_NUM_1];
    $char temp[POLICY_NUM_1];
    $long stepi;
    $char stmt[20000];
    $char fins_grp[2], ibroker[BROKER], iquota[11], ileader[11];

    $long mdmg_prem, mdmg_commi, mdmg_agent, mdmg_disc;
    $long mlia_prem, mlia_commi, mlia_agent, mlia_disc;

    $float mdmg_pure_prem, mlia_pure_prem;

    $char iedr_type[3];
    $char iedr_type_33[3];
    $long medrins_prem;
    $float medrpure_prem;
    $long medr_prem;
    $long medr_commission;
    $long medr_agent;
    $long medr_discount;
    $long dedr_begin;
    $long dedr_end;
    $char ipaid_base[3];

    $float medrpure_prem_33;
    $long medrins_prem_33;
    $long medr_discount_33;
    $long medr_commission_33;
    $long medr_agent_33, lMcommission;
    long rc;
    $char fcard_class[2];
    $char sCCC1[101], sCCC2[101], sCCC3[101], f980401[2], drate_ym[5], comp_frate[6], iabn_type[2];
    double rCCC1, rCCC2, rCCC3;
    $double pbusiness_new, pdiscount_new, pextra_charge_new, mbusiness;
    $char icomm_obj[11], opt[2];
    $long mdrunk_prem, mviolate_prem;
    $double mdrunk_pure_prem, mviolate_pure_prem;

    $struct get_edr_tp
    {
        char iedr_type[3];
        char iins_type[INSURANCE_TYPE];
        long medrins_prem;
        double medrpure_prem;
        long medr_prem;
        double ori_pdiscount;
        long ori_mdiscount;
        double ori_pcommission;
        long ori_mcommission;
        double ori_pagent;
        long ori_magent;
        double new_pcommission;
        long new_mcommission;
        double new_pagent;
        long new_magent;
    };
    $struct get_edr_tp GetCltEdrInsTp[MAXSIZE];

    $struct get_edr_tp33
    {
        char iedr_type[3];
        char iinsurant[11];
        char iins_scope[2];
        char icareer[2];
        long medrins_prem;
        double ori_pdiscount;
        long ori_mdiscount;
        double ori_pcommission;
        long ori_mcommission;
        double ori_pagent;
        long ori_magent;
        double new_pcommission;
        long new_mcommission;
        double new_pagent;
        long new_magent;
    };
    $struct get_edr_tp33 GetCltEdrInsTp33[MAXSIZE];
    $char dcreate_max[31], dcreate_max_new[31];
    $char dlock[31];

    $WHENEVER SQLERROR GOTO errexit;

    cm_buf_get("%s", cDbName);
    cm_buf_get("%s", userid);
    cm_buf_get("%s", ipolicy);
    cm_buf_get("%s", oriIendorse);
    cm_buf_get("%s", oriIedrReturn);
    cm_buf_get("%s", newIedrReturn);

    cm_buf_get("%s ", dcreate_max);

    /* get ���B�z������c & �����q*/
    if (db_select(cDbName) == False)
        return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    $SELECT idir
        INTO $sIdir
            FROM user
                WHERE iemp = $userid;
    if (SQLCODE == SQLNOTFOUND)
    {
        if (exitsub(reply, M_CM_NOT_FOUND) == True)
            return M_CM_NOT_FOUND;
        else
            return apiRC;
    }

    printf("car422_insert.0001:cm_get_unit_at: idir[%s]\n", sIdir);

    strncpy(ibranch_at, sIdir, BRANCH_ID - 1);
    ibranch_at[BRANCH_ID - 1] = '\0';
    printf("car422_insert.0002:ibranch_at[%s]\n", ibranch_at);

    $SELECT iupcomp
        INTO $icomp_at
            FROM sa_branch_type
                WHERE ibranch = $sIdir;
    if (SQLCODE == SQLNOTFOUND)
    {
        if (exitsub(reply, M_CM_NOT_FOUND) == True)
            return M_CM_NOT_FOUND;
        else
            return apiRC;
    }
    printf("car422_insert.0003:icomp_at[%s]\n", icomp_at);

    /* ���o�O����ݸ�Ʈw */
    printf("car422_insert.0004:ipolicy[%s]\n", ipolicy);
    strcpy(sDB, get_db(ipolicy));

    if (strncmp(sDB, "100", 3) == 0)
    {
        if (exitsub(reply, M_CM_NOT_FOUND) == True)
            return M_CM_NOT_FOUND;
        else
            return apiRC;
    }

    if (db_select(sDB) == False)
        return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    $select max(dcreate)
        into $dcreate_max_new
            from edr_relation
                where ipolicy = $ipolicy and iendorse not like '%CVP%';

    strcpy(dcreate_max, trim(dcreate_max));
    strcpy(dcreate_max_new, trim(dcreate_max_new));

    printf("[%s] dcreate_max\n", dcreate_max);
    printf("[%s] dcreate_max_new\n", dcreate_max_new);

    if (strcmp(dcreate_max, dcreate_max_new) != 0)
    {
        if (exitsub(reply, M_CA_CHANGE_PLY) == True)
            return M_CA_CHANGE_PLY;
        else
            return apiRC;
    }

    $SELECT ibroker, iquota, icomm_obj, dlock INTO $ibroker, $iquota, $icomm_obj, $dlock FROM ply_relation WHERE ipolicy = $ipolicy;

    if (strlen(trim(dlock)) != 0) /* ���O��B2C��襤�A�ȮɵL�k��� */
    {
        if (exitsub(reply, M_CA_PLY_LOCK) == True)
            return M_CA_PLY_LOCK;
        else
            return apiRC;
    }

    /* �I����H�O�_����O */
    strcpy(opt, "5");
    rc = cm_chk_policy(opt, "", "", "", icomm_obj, "", "", "");
    if (rc != M_CM_OK)
    {
        if (exitsub(reply, rc) == True)
            return rc;
        else
            return apiRC;
    }

    /* �~�Z���O�_���� */
    strcpy(opt, "2");
    rc = cm_chk_policy(opt, "", "", iquota, "", "C", "", "");
    if (rc != M_CM_OK)
    {
        if (exitsub(reply, rc) == True)
            return rc;
        else
            return apiRC;
    }

    /* ���o���椧�t�Τ�� */
    rtoday(&dwritten);

    iins_33_flag = 0;
    ins_count = 0;
    ins_count_33 = 0;
    fpay[0] = '\0';
    iedr_type[0] = '\0';
    iedr_type_33[0] = '\0';

    cm_buf_get("%d", &ins_count); /* ���o�I�ص��� */

    for (i = 0; i < ins_count; i++)
    {
        memset(&(GetCltEdrInsTp[i]), 0, sizeof(struct get_edr_tp));

        cm_buf_get("%s %s %l %e %l ",
                   GetCltEdrInsTp[i].iedr_type, GetCltEdrInsTp[i].iins_type,
                   &(GetCltEdrInsTp[i].medrins_prem), &(GetCltEdrInsTp[i].medrpure_prem), &(GetCltEdrInsTp[i].medr_prem));
        /* �u�f�v */
        cm_buf_get("%e %l ",
                   &(GetCltEdrInsTp[i].ori_pdiscount), &(GetCltEdrInsTp[i].ori_mdiscount));

        /* �����v */
        cm_buf_get("%e %l ",
                   &(GetCltEdrInsTp[i].ori_pcommission), &(GetCltEdrInsTp[i].ori_mcommission));

        /* �N�z�v */
        cm_buf_get("%e %l ",
                   &(GetCltEdrInsTp[i].ori_pagent), &(GetCltEdrInsTp[i].ori_magent));

        /* �s�����v */
        cm_buf_get("%e %l ",
                   &(GetCltEdrInsTp[i].new_pcommission), &(GetCltEdrInsTp[i].new_mcommission));

        /* �s�N�z�v */
        cm_buf_get("%e %l ",
                   &(GetCltEdrInsTp[i].new_pagent), &(GetCltEdrInsTp[i].new_magent));

        printf("iins[%s]pcomm[%lf]pagent[%lf]pdisc[%lf]\n",
               GetCltEdrInsTp[i].iins_type, GetCltEdrInsTp[i].new_pcommission,
               GetCltEdrInsTp[i].new_pagent, GetCltEdrInsTp[i].ori_pdiscount);

        if (strcmp(trim(GetCltEdrInsTp[i].iins_type), "21") != 0) /* ���N�I */
        {
            $SELECT pbusiness, drate_ym, pdiscount, pextra_charge INTO $pbusiness_new, $drate_ym, $pdiscount_new, $pextra_charge_new FROM ply_ins_type WHERE ipolicy = $ipolicy AND iins_type = $GetCltEdrInsTp[i].iins_type;

            if (SQLCODE == SQLNOTFOUND)
                return exitsub(reply, M_CA_NINSTYPE) ? M_CA_NINSTYPE : apiRC;

            $SELECT case when drate >= date('04/01/2009') then '1' else '0' end
                                           INTO $f980401
                                               FROM ca_rate_date
                                                   WHERE icode = $drate_ym
                AND itable = 'cm_extra_charge';

            if (SQLCODE == SQLNOTFOUND)
                return exitsub(reply, M_CA_EXTRA_CHARGE_DRATE) ? M_CA_EXTRA_CHARGE_DRATE : apiRC;

            /* �O�v�ۥѤƤ��� */
            if (f980401[0] == '1')
            {
                printf("pdiscount_new[%f]\n", pdiscount_new);
                if (pdiscount_new != 0) /* �O�v�ۥѤƤ��ᤣ�i������ */
                    return exitsub(reply, M_CA_PDISCOUNT_ERR) ? M_CA_PDISCOUNT_ERR : apiRC;

                sprintf_s(sCCC1, sizeof sCCC1, "%f", (double)(pdiscount_new + GetCltEdrInsTp[i].new_pcommission + GetCltEdrInsTp[i].new_pagent));
                sprintf_s(sCCC2, sizeof sCCC2, "%f", (double)((pextra_charge_new - pbusiness_new) * 100.0));
                rCCC1 = atof(sCCC1);
                rCCC2 = atof(sCCC2);

                printf("��+�N+�u[%-3.20f]\n", rCCC1);
                printf("��-�~   [%-3.20f]\n", rCCC2);

                if (pextra_charge_new != 0 && rCCC1 > rCCC2)
                    return exitsub(reply, M_CA_COMMI_ERR) ? M_CA_COMMI_ERR : apiRC;
            }
        }
    }

    cm_buf_get("%d", &ins_count_33); /* ���o�ˮ`�I�I�ص��� */

    for (i = 0; i < ins_count_33; i++)
    {
        memset(&(GetCltEdrInsTp33[i]), 0, sizeof(struct get_edr_tp33));

        cm_buf_get("%s %s %s %s %l",
                   GetCltEdrInsTp33[i].iedr_type, GetCltEdrInsTp33[i].iinsurant, GetCltEdrInsTp33[i].iins_scope, GetCltEdrInsTp33[i].icareer,
                   &(GetCltEdrInsTp33[i].medrins_prem));

        if (GetCltEdrInsTp33[i].medrins_prem != 0)
        {
            iins_33_flag = 1;
        }

        /* �u�f�v */
        cm_buf_get("%e %l",
                   &(GetCltEdrInsTp33[i].ori_pdiscount), &(GetCltEdrInsTp33[i].ori_mdiscount));

        /* �����v */
        cm_buf_get("%e %l",
                   &(GetCltEdrInsTp33[i].ori_pcommission), &(GetCltEdrInsTp33[i].ori_mcommission));

        /* �N�z�v */
        cm_buf_get("%e %l",
                   &(GetCltEdrInsTp33[i].ori_pagent), &(GetCltEdrInsTp33[i].ori_magent));

        /* �s�����v */
        cm_buf_get("%e %l",
                   &(GetCltEdrInsTp33[i].new_pcommission), &(GetCltEdrInsTp33[i].new_mcommission));

        /* �s�N�z�v */
        cm_buf_get("%e %l",
                   &(GetCltEdrInsTp33[i].new_pagent), &(GetCltEdrInsTp33[i].new_magent));
    }

    /* ��������O��[B:������] */
    strcpy(fedr_class, "B");

    /* get ���s�X���O*/
    strncpy(sIbilling, ipolicy + CAR_POL_CHR_POS - 1, 2);
    sIbilling[2] = '\0';
    printf("car422_insert.0005:sIbilling[%s]\n", sIbilling);
    /* get ����k�ݤ�����c & �����q*/
    strncpy(sIbranchIcomp, ipolicy, CA_POL_BRH_NUM - 1);
    sIbranchIcomp[CA_POL_BRH_NUM - 1] = '\0';
    printf("car422_insert.0006:sIbranchIcomp[%s]\n", sIbranchIcomp);

    fRtnCode = cm_get_unit_in("", sIbranchIcomp, userid,
                              sIbranchIcomp, "C1", sIcomp_in, sIbranch_in);
    if (fRtnCode != M_CM_OK)
        return exitsub(reply, fRtnCode) ? fRtnCode : apiRC;

    /* 00 40 70 */
    printf("car422_insert.0006:sIcomp_in[%s]\n", sIcomp_in);
    /* 00 20 30 40 ...87 */
    printf("car422_insert.0007:sIbranch_in[%s]\n", sIbranch_in);

    /* 1 2 3 */
    strcpy(sIcomp_in_short, get_upcomp(sIcomp_in, USE_BRANCH_ID, USE_SHORT_BRANCH_ID));
    printf("car422_insert.0008:sIcomp_in_short[%s]\n", sIcomp_in_short);

    /* ���O���A�ˮ� */
    $SELECT ibatch_no
        INTO $ibatch_no
            FROM ply_relation
                WHERE ipolicy = $ipolicy;
    if (SQLCODE == SQLNOTFOUND)
    {
        $WHENEVER SQLERROR CONTINUE;
        if (exitsub(reply, M_CM_NOT_FOUND) == True)
            return M_CM_NOT_FOUND;
        else
            return apiRC;
    }
    strcpy(batchno, itoa(ibatch_no));

    policy_1[0] = '\0';
    policy_2[0] = '\0';
    strncpy(policy_1, ipolicy, CAR_POLICY_LEN);
    policy_1[CAR_POLICY_LEN] = 0;

    if (strlen(ipolicy) > CAR_POLICY_LEN)
        strcpy(policy_2, &ipolicy[CAR_POLICY_LEN]);
    else
        strcpy(policy_2, " ");

    payresult[0] = '\0';
    paystatus[0] = '\0';
    paydate[0] = '\0';
    notedate[0] = '\0';

    ao_chk_charge(sDB, '3', policy_1, policy_2, batchno,
                  payresult, paystatus, paydate, notedate);

    $SELECT dedr_begin, dedr_end, fcard_class INTO $dedr_begin, $dedr_end, $fcard_class FROM edr_relation WHERE iendorse = $oriIendorse;
    if (SQLCODE == SQLNOTFOUND)
    {
        $WHENEVER SQLERROR CONTINUE;
        if (exitsub(reply, M_CM_NOT_FOUND) == True)
            return M_CM_NOT_FOUND;
        else
            return apiRC;
    }

    $BEGIN WORK;

    mdmg_prem = 0;
    mdmg_commi = 0;
    mdmg_agent = 0;
    mdmg_disc = 0;
    mlia_prem = 0;
    mlia_commi = 0;
    mlia_agent = 0;
    mlia_disc = 0;
    medrins_prem = 0;
    medrpure_prem = 0;
    medr_prem = 0;
    medr_commission = 0;
    medr_agent = 0;
    medr_discount = 0;
    medrpure_prem_33 = 0;
    medrins_prem_33 = 0;
    medr_discount_33 = 0;
    medr_commission_33 = 0;
    medr_agent_33 = 0;

    /*******************************************************************************/
    /*******************************************************************************/
    /*******************************************************************************/
    /*******************************************************************************/
    /* First Step:���N����t���B�z */
    printf("############## FIRST STEP \n");
    {
        stepi = cm_get_serial_num("C4", sIbilling,
                                  sIcomp_in_short, sIbranch_in,
                                  cm_cdate_str_100(cm_today()),
                                  temp_1);
        if (stepi != 0)
        {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            if (stepi == 1 || stepi == 2)
                stepi = M_CM_DB_NOTOPEN;
            else if (stepi == 3)
                stepi = M_CMN_NAUTONUMBERING;
            exitsub(reply, stepi);
            return stepi;
        }

        $WHENEVER SQLERROR goto errexit;

        printf("GET iendorse:[%s]\n", temp_1);

        rc = bk_401(sDB, ipolicy, temp_1);
        if (rc != M_CM_OK)
        {
            SQLCODE = rc;
            goto errexit;
        }

        mdmg_prem = 0;
        mdmg_pure_prem = 0;
        mdmg_commi = 0;
        mdmg_agent = 0;
        mdmg_disc = 0;

        mlia_prem = 0;
        mlia_pure_prem = 0;
        mlia_commi = 0;
        mlia_agent = 0;
        mlia_disc = 0;

        /* �U�I�ة��Ӹ�� */
        for (i = 0; i < ins_count; i++)
        {
            $SELECT medrins_prem, medrpure_prem, medr_prem, medr_commission, medr_agent, medr_discount, mdrunk_prem, mdrunk_pure_prem, mviolate_prem, mviolate_pure_prem INTO $medrins_prem, $medrpure_prem, $medr_prem, $medr_commission, $medr_agent, $medr_discount, $mdrunk_prem, $mdrunk_pure_prem, $mviolate_prem, $mviolate_pure_prem FROM edr_ins_type WHERE iendorse = $oriIendorse AND iins_type = $GetCltEdrInsTp[i].iins_type;
            if (SQLCODE == SQLNOTFOUND)
            {
                $WHENEVER SQLERROR CONTINUE;
                $ROLLBACK WORK;
                if (exitsub(reply, M_CA_NINSTYPE) == True)
                    return M_CA_NINSTYPE;
                else
                    return apiRC;
            }

            medrins_prem = (-1) * medrins_prem;
            medrpure_prem = (-1) * medrpure_prem;
            medr_prem = (-1) * medr_prem;

            medr_commission = (-1) * medr_commission;
            medr_agent = (-1) * medr_agent;
            medr_discount = (-1) * medr_discount;
            mdrunk_prem = (-1) * mdrunk_prem;
            mdrunk_pure_prem = (-1) * mdrunk_pure_prem;

            mviolate_prem = (-1) * mviolate_prem;
            mviolate_pure_prem = (-1) * mviolate_pure_prem;

            if (medrins_prem < 0)
            {
                strcpy(iedr_type, "82"); /* ������(�t) */
                if (strcmp(trim(GetCltEdrInsTp[i].iins_type), "33") == 0)
                {
                    strcpy(iedr_type_33, "82"); /* ������(�t) */
                }
            }
            else
            {
                strcpy(iedr_type, "83"); /* ������(��) */
                if (strcmp(trim(GetCltEdrInsTp[i].iins_type), "33") == 0)
                {
                    strcpy(iedr_type_33, "83"); /* ������(��) */
                }
            }

            stmt[0] = '\0';
            sprintf_s(stmt, sizeof stmt,
                    "INSERT INTO edr_ins_type "
                    "              (iendorse, iins_type, iedr_type,"
                    "               medrinj_cover, medrdea_cover, medrdmg_cover, mdeduct,"
                    "               medrins_prem, medrpure_prem,"
                    "               fcal_way, pcal, qserial,"
                    "               pcommission, medr_commission, pagent, medr_agent, pdiscount, medr_discount,"
                    "               drate_ym, medr_prem, iproduct, ipaid_base,"
                    "               qday, medr_expense, medr_exp_disc,qcount,provision, psex_age, mdrunk_prem, mdrunk_pure_prem, "
                    "               mviolate_prem , mviolate_pure_prem) "
                    "        SELECT '%s', iins_type, '%s',"
                    "               0,0,0,0,"
                    "               %ld, %.4f,"
                    "               'M',100, qserial,"
                    "               0, %ld, 0, %ld, 0, %ld,"
                    "               drate_ym, %ld, iproduct, ipaid_base,"
                    "               0, 0, 0, 0, provision, psex_age, %ld, %f, %ld, %f "
                    "          FROM ply_ins_type "
                    "         WHERE ipolicy   = '%s' "
                    "           AND iins_type = '%s'",
                    temp_1, iedr_type,
                    medrins_prem, medrpure_prem,
                    medr_commission, medr_agent, medr_discount,
                    medr_prem, mdrunk_prem, mdrunk_pure_prem, mviolate_prem, mviolate_pure_prem,
                    ipolicy, GetCltEdrInsTp[i].iins_type);

            printf("car422_insert.0010:[%s]\n", stmt);

            $PREPARE edr_ins_1 FROM $stmt;
            $EXECUTE edr_ins_1;

            fins_grp[0] = '\0';
            $SELECT fins_grp
                INTO : fins_grp
                           FROM insurance_type
                               WHERE iins_type = $GetCltEdrInsTp[i].iins_type;
            if (SQLCODE == SQLNOTFOUND)
            {
                $WHENEVER SQLERROR CONTINUE;
                $ROLLBACK WORK;
                if (exitsub(reply, M_CA_NINS_TYPE) == True)
                    return M_CA_NINS_TYPE;
                else
                    return apiRC;
            }

            if (strncmp(fins_grp, "1", 1) == 0) /* ���l�I */
            {
                mdmg_prem += medrins_prem;
                mdmg_pure_prem += medrpure_prem;
                mdmg_commi += medr_commission;
                mdmg_agent += medr_agent;
                mdmg_disc += medr_discount;
            }
            else if ((strncmp(fins_grp, "2", 1) == 0) || (strncmp(fins_grp, "3", 1) == 0)) /* ���d�I�αj���I */
            {
                mlia_prem += medrins_prem;
                mlia_pure_prem += medrpure_prem;
                mlia_commi += medr_commission;
                mlia_agent += medr_agent;
                mlia_disc += medr_discount;
            }

            stmt[0] = '\0';
            sprintf_s(stmt, sizeof stmt, "UPDATE ply_ins_type SET (%s %s) = (%s %s %s) WHERE %s %s ",
                    "mins_premium, mpure_prem, mprem,",
                    "mcommission, magent, mdiscount, iendorse ",
                    "mins_premium + ?, mpure_prem + ?, mprem + ?, ",
                    "mcommission + ?, magent + ?, mdiscount + ?, ?, mdrunk_prem+?, mdrunk_pure_prem+?, ",
                    "mviolate_prem+?, mviolate_pure_prem+?",
                    "ipolicy = ? ",
                    "AND iins_type = ? ");
            $PREPARE ply_ins1_1 FROM $stmt;
            printf("car422_insert.0010-1[%s]\n", stmt);
            $EXECUTE ply_ins1_1 USING $medrins_prem, $medrpure_prem, $medr_prem,
                $medr_commission, $medr_agent, $medr_discount, $temp_1, $mdrunk_prem, $mdrunk_pure_prem,
                $mviolate_prem, $mviolate_pure_prem $ipolicy, $GetCltEdrInsTp[i].iins_type;
        }

        if ((mdmg_prem + mlia_prem) < 0)
        {
            if (payresult[0] == 'R')
            {
                strcpy(fpay, " "); /* ��ú */
            }
            else
            {
                strcpy(fpay, "1"); /* ��ú */
            }
        }

        /* �ˮ`�I���Ӹ�� */
        if (iins_33_flag == 1)
        {
            for (i = 0; i < ins_count_33; i++)
            {
                $SELECT medrins_prem, medrpure_prem, medr_commission, medr_agent, medr_discount INTO $medrins_prem, $medrpure_prem, $medr_commission, $medr_agent, $medr_discount FROM ca_pa_edr WHERE iendorse = $oriIendorse AND iinsurant = $GetCltEdrInsTp33[i].iinsurant AND iins_scope = $GetCltEdrInsTp33[i].iins_scope AND icareer = $GetCltEdrInsTp33[i].icareer;

                medrins_prem = (-1) * medrins_prem;
                medrpure_prem = (-1) * medrpure_prem;
                medr_commission = (-1) * medr_commission;
                medr_agent = (-1) * medr_agent;
                medr_discount = (-1) * medr_discount;

                stmt[0] = '\0';
                sprintf_s(stmt, sizeof stmt, "INSERT INTO ca_pa_edr "
                              "             (iendorse, iinsurant, iedr_type, ninsurant, dbirth,"
                              "              ainsurant, iins_scope, icareer,"
                              "              medrins_amt, fcal_way, pcal, medrins_prem, medrpure_prem,"
                              "              pcommission, medr_commission, pagent, medr_agent, pdiscount, medr_discount,"
                              "              dendorse, napplicant, relation_appl, nbeneficiary, relation_bene,tbenef, abenef_zip, abenef) "
                              "       SELECT '%s' , iinsurant,'%s' ,ninsurant, dbirth,"
                              "              ainsurant, iins_scope, icareer,"
                              "              0, 'M', 100, %ld, %.4f,"
                              "              0, %ld, 0, %ld, 0, %ld,"
                              "              %ld, napplicant, relation_appl, nbeneficiary, relation_bene,tbenef, abenef_zip, abenef "
                              "         FROM ca_pa_ply "
                              "        WHERE ipolicy    = '%s' "
                              "          AND iinsurant  = '%s' "
                              "          AND iins_scope = '%s' "
                              "          AND icareer    = '%s' ",
                        temp_1, iedr_type_33,
                        medrins_prem, medrpure_prem,
                        medr_commission, medr_agent, medr_discount,
                        dwritten,
                        ipolicy,
                        GetCltEdrInsTp33[i].iinsurant,
                        GetCltEdrInsTp33[i].iins_scope,
                        GetCltEdrInsTp33[i].icareer);

                printf("car422_insert.0011:[%s]\n", stmt);
                $PREPARE caedrtp_1 FROM $stmt;
                $EXECUTE caedrtp_1;

                sprintf_s(stmt, sizeof stmt, "UPDATE ca_pa_ply SET (%s) = (%s) WHERE %s %s %s %s ",
                        "mins_premium, mpure_prem, mcommission, magent, mdiscount, iendorse ",
                        "mins_premium + ?, mpure_prem + ? , mcommission + ?, magent + ?, mdiscount + ?, ? ",
                        "ipolicy        = ? ",
                        "AND iinsurant  = ? ",
                        "AND iins_scope = ? ",
                        "AND icareer    = ? ");
                printf("car422_insert.0011-1[%s]\n", stmt);
                $PREPARE ca_pa_ins1_1 FROM $stmt;
                $EXECUTE ca_pa_ins1_1 USING $medrins_prem, $medrpure_prem,
                    $medr_commission, $medr_agent, $medr_discount, $temp_1,
                    $ipolicy,
                    $GetCltEdrInsTp33[i].iinsurant,
                    $GetCltEdrInsTp33[i].iins_scope,
                    $GetCltEdrInsTp33[i].icareer;
            } /* end of for */
        }     /* end of �ˮ`�I���Ӹ�� */

        $WHENEVER SQLERROR goto errexit;
        stmt[0] = '\0';
        sprintf_s(stmt, sizeof stmt, "INSERT INTO edr_relation "
                             "      (iendorse, fcard_class, ipolicy, icard, irelative_ply, irelative_edr,"
                             "       fedr_class, fpay, ipay, iedr_field, dedr_begin, dedr_end, "
                             "       ipro_year, ibrand, icar_type,"
                             "       medrdmg_agent, medrdmg_commi, medrdmg_prem, medrdmg_pure_prem,"
                             "       medrlia_agent, medrlia_commi, medrlia_prem, medrlia_pure_prem,"
                             "       ibig_comp, ibig_branch, ibig_office, ibig_sales, iresource,"
                             "       ibroker, iofficer, ileader, icorps, iedr_area,"
                             "       iedr_cashier, iedr_examiner, dedr_examine, dentry, dendorse,"
                             "       fprint, itreaty, ibranch, iquota, icomp_in, ibranch_in, icomp_at, ibranch_at,"
                             "       medr_ready, medr_stable, medr_compensate, medr_adjcom, medr_research, medr_invest,"
                             "       medr_bus_rule, medr_business, medr_capital,"
                             "       fcomp_class, fcomp_class_last, fdiscount, medrdmg_disc, medrlia_disc,"
                             "       iedr_return, icar_flag, terminate_rsn, qcount, "
                             "       iofficer_prmt, iquota_prmt, ileader_prmt,irate_type,bzfrom,iroute_comm,icomm_obj,qprovision,isecond_hand,icard_main, "
                             "       qdrunk_driving, isign, feply, feedr, aemail_eply, tmobile_eply,isign_edr,dsign_edr,fsign_status_edr,funder_chk_edr,iprog,qviolate) "
                             " SELECT '%s', fcard_class, ipolicy, icard, irelative_ply, '%s',"
                             "       '%s', '%s', ' ', ' ', %ld, %ld, "
                             "       ipro_year, ibrand, icar_type,"
                             "       %ld, %ld, %ld, %.4f, %ld, %ld, %ld, %.4f,"
                             "       ibig_comp, ibig_branch, ibig_office, ibig_sales, iresource,"
                             "       ibroker, iofficer, ileader, icorps, iarea,"
                             "       '%s', '%s', %ld, %ld, %ld ,"
                             "       1, itreaty, ibranch, iquota, icomp_in, ibranch_in, '%s', '%s',"
                             "       0, 0, 0, 0, 0, 0, 0, 0, 0,"
                             "       fcomp_class, fcomp_class_last, fdiscount, %ld, %ld, '%s', icar_flag, '0', 0, "
                             "       iofficer_prmt, iquota_prmt, ileader_prmt, irate_type,bzfrom,iroute_comm,icomm_obj,qprovision,isecond_hand,icard_main, "
                             "       qdrunk_driving, isign, feply, '0', aemail_eply, tmobile_eply,'system',today,40,'N','car422',qviolate  "
                             "  FROM ply_relation "
                             " WHERE ipolicy = '%s'",
                temp_1, oriIendorse,
                fedr_class, fpay, dedr_begin, dedr_end,
                mdmg_agent, mdmg_commi, mdmg_prem, mdmg_pure_prem,
                mlia_agent, mlia_commi, mlia_prem, mlia_pure_prem,
                userid, userid, dwritten, dwritten, dwritten,
                icomp_at, ibranch_at,
                mdmg_disc, mlia_disc, oriIedrReturn,
                ipolicy);
        printf("Insert edr_relation[%s] \n", stmt);
        $PREPARE edr1_1 FROM $stmt;
        $EXECUTE edr1_1;

        $WHENEVER SQLERROR goto errexit;
        stmt[0] = '\0';
        sprintf_s(stmt, sizeof stmt, "INSERT INTO endorsement "
                           "       (iendorse, qply_period, dply_begin, dply_end, fassured, iassured,"
                           "        iassured_ext, nassured, ilicense, fsex, fmarriage, nuser,"
                           "        ibenef, nbenef, aassured, aassured_zip, itel, apayment, apayment_zip,"
                           "        iply_area, nbrand_abbr, ncar_abbr, fcar_note, qcylinder, iengine, ibody,"
                           "        itag, mcar_price, nequipment, flimit, pdmg_align, pbrg_align, plia_align,"
                           "        idmg_rate, pdmg_factor, ibrg_rate, pbrg_factor, qpt, fpt, psex_age, psex_age_damage, "
                           "        lia_class,"
                           "        plia_acc, dmg_acc_1st, dmg_acc_2nd, dmg_acc_3rd, pdmg_acc, fhuman, fcomp_24,payresult, "
                           "        iext_policy, qpro_month, mkilo_ply, mkilo_edr, irisk, irelative_ext, "
                           "        napplicant, dbirth, dissue, "
                           "        iextra_charge, gextra_charge, pextra_charge, "
                           "        iquery_num_damage, iquery_num, mequipment, "
                           "        survey_num, bound_num, abnormal_num, iapplicant, iroute, qlia_acc_sum, qdmg_acc_sum, "
                           "        fapplicant,fsex_appl,dbirth_appl,itel_appl,ndeputy_appl,nrelation_appl,ndeputy_assured, "
                           "        iassured_cntry, iapplicant_cntry, nassured_cntry, napplicant_cntry, "
                           "        foccup, noccup, applicant_foccup, applicant_noccup,tmobile_appl,aemail_appl, "
                           "        dinstall, isequence, ainstall_zip, ainstall) "
                           " SELECT '%s', a.qply_period, a.dply_begin, a.dply_end, b.fassured, b.iassured,"
                           "        b.iassured_ext, b.nassured, b.ilicense, b.fsex, b.fmarriage, b.nuser,"
                           "        b.ibenef, b.nbenef, b.aassured, b.aassured_zip, b.itel, b.apayment, b.apayment_zip,"
                           "        b.iply_area, b.nbrand_abbr, b.ncar_abbr, b.fcar_note, b.qcylinder, b.iengine, b.ibody,"
                           "        b.itag, b.mcar_price, b.nequipment, b.flimit, b.pdmg_align, b.pbrg_align, b.plia_align,"
                           "        b.idmg_rate, b.pdmg_factor, b.ibrg_rate, b.pbrg_factor, b.qpt, b.fpt, b.psex_age, "
                           "        b.psex_age_damage, b.lia_class,"
                           "        b.plia_acc, b.dmg_acc_1st, b.dmg_acc_2nd, b.dmg_acc_3rd, b.pdmg_acc, b.fhuman, b.fcomp_24, '%s', "
                           "        b.iext_policy, b.qpro_month, b.mkilo_ply, b.mkilo_edr, b.irisk, b.irelative_ext, "
                           "        b.napplicant, b.dbirth, b.dissue, "
                           "        b.iextra_charge, b.gextra_charge, b.pextra_charge, "
                           "        b.iquery_num_damage, b.iquery_num, b.mequipment, "
                           "        b.survey_num, b.bound_num, b.abnormal_num, b.iapplicant, b.iroute, b.qlia_acc_sum, b.qdmg_acc_sum, "
                           "        b.fapplicant,b.fsex_appl,b.dbirth_appl,b.itel_appl,b.ndeputy_appl,b.nrelation_appl,b.ndeputy_assured, "
                           "        CASE WHEN b.iassured_cntry='' THEN '8' ELSE b.iassured_cntry END, "
                           "        CASE WHEN b.iapplicant_cntry='' THEN '8' ELSE b.iapplicant_cntry END, b.nassured_cntry, b.napplicant_cntry, "
                           "        b.foccup, b.noccup, b.applicant_foccup, b.applicant_noccup,b.tmobile_appl,b.aemail_appl, "
                           "        b.dinstall, b.isequence, b.ainstall_zip, b.ainstall "
                           "   FROM ply_relation a,policy b "
                           "  WHERE a.ipolicy = b.ipolicy "
                           "    AND a.ipolicy = '%s' ",
                temp_1, payresult, ipolicy);
        printf("car422_insert.0012:[%s]\n", stmt);
        $PREPARE endor_1 FROM $stmt;
        $EXECUTE endor_1;

        stmt[0] = '\0';
        sprintf_s(stmt, sizeof stmt, "UPDATE ply_relation SET (%s %s) = (%s %s) WHERE %s ",
                "mdmg_prem, mdmg_pure_prem, mdmg_agent, mdmg_commi, mdmg_discount,",
                "mlia_prem, mlia_pure_prem, mlia_agent, mlia_commi, mlia_discount ",
                "mdmg_prem + ?, mdmg_pure_prem + ?, mdmg_agent + ?, mdmg_commi + ?, mdmg_discount + ?,",
                "mlia_prem + ?, mlia_pure_prem + ?, mlia_agent + ?, mlia_commi + ?, mlia_discount + ? ",
                "ipolicy = ?");
        printf("car422_insert.0014:[%s]\n", stmt);
        $PREPARE ply1_1 FROM $stmt;
        $EXECUTE ply1_1 USING $mdmg_prem, $mdmg_pure_prem, $mdmg_agent, $mdmg_commi, $mdmg_disc,
            $mlia_prem, $mlia_pure_prem, $mlia_agent, $mlia_commi, $mlia_disc,
            $ipolicy;

        rc = insert_cm_pre_receive_edr(temp_1, ipolicy, ipgid, v_sMsg);
        if (rc != M_CM_OK)
        {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            if (exitsub(reply, rc) == True)
                return rc;
            else
                return apiRC;
        }
    }

    mdmg_prem = 0;
    mdmg_commi = 0;
    mdmg_agent = 0;
    mdmg_disc = 0;
    mlia_prem = 0;
    mlia_commi = 0;
    mlia_agent = 0;
    mlia_disc = 0;
    medrins_prem = 0;
    medrpure_prem = 0;
    medr_prem = 0;
    medr_commission = 0;
    medr_agent = 0;
    medr_discount = 0;
    medrpure_prem_33 = 0;
    medrins_prem_33 = 0;
    medr_discount_33 = 0;
    medr_commission_33 = 0;
    medr_agent_33 = 0;

    /*******************************************************************************/
    /*******************************************************************************/
    /*******************************************************************************/
    /*******************************************************************************/
    /* SECOND STEP : �N��楿���B�z */
    fpay[0] = '\0';

    printf("############## SECOND STEP \n");
    {
        stepi = cm_get_serial_num("C4", sIbilling,
                                  sIcomp_in_short, sIbranch_in,
                                  cm_cdate_str_100(cm_today()),
                                  temp);
        if (stepi != 0)
        {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            if (stepi == 1 || stepi == 2)
                stepi = M_CM_DB_NOTOPEN;
            else if (stepi == 3)
                stepi = M_CMN_NAUTONUMBERING;
            exitsub(reply, stepi);
            return stepi;
        }

        $WHENEVER SQLERROR goto errexit;

        printf("get number:[%s]\n", temp);

        rc = bk_401(sDB, ipolicy, temp);
        if (rc != M_CM_OK)
        {
            SQLCODE = rc;
            goto errexit;
        }

        mdmg_prem = 0;
        mdmg_pure_prem = 0;
        mdmg_commi = 0;
        mdmg_agent = 0;
        mdmg_disc = 0;

        mlia_prem = 0;
        mlia_pure_prem = 0;
        mlia_commi = 0;
        mlia_agent = 0;
        mlia_disc = 0;

        /* �U�I�ة��Ӹ�� */
        for (i = 0; i < ins_count; i++)
        {
            printf("1.iins[%s],pcomm[%lf],pagent[%lf],pdisc[%lf]\n",
                   GetCltEdrInsTp[i].iins_type, GetCltEdrInsTp[i].new_pcommission,
                   GetCltEdrInsTp[i].new_pagent, GetCltEdrInsTp[i].ori_pdiscount);

            $SELECT medrins_prem, medrpure_prem, medr_prem, ipaid_base, mdrunk_prem, mdrunk_pure_prem, mviolate_prem, mviolate_pure_prem INTO $medrins_prem, $medrpure_prem, $medr_prem, $ipaid_base, $mdrunk_prem, $mdrunk_pure_prem, $mviolate_prem, $mviolate_pure_prem FROM edr_ins_type WHERE iendorse = $oriIendorse AND iins_type = $GetCltEdrInsTp[i].iins_type;
            if (SQLCODE == SQLNOTFOUND)
            {
                $WHENEVER SQLERROR CONTINUE;
                $ROLLBACK WORK;
                if (exitsub(reply, M_CA_NINSTYPE) == True)
                    return M_CA_NINSTYPE;
                else
                    return apiRC;
            }

            if (medrins_prem < 0)
            {
                strcpy(iedr_type, "82"); /* ������(�t) */
                if (strcmp(trim(GetCltEdrInsTp[i].iins_type), "33") == 0)
                {
                    strcpy(iedr_type_33, "82"); /* ������(�t) */
                }
            }
            else
            {
                strcpy(iedr_type, "83"); /* ������(��) */
                if (strcmp(trim(GetCltEdrInsTp[i].iins_type), "33") == 0)
                {
                    strcpy(iedr_type_33, "83"); /* ������(��) */
                }
            }

            /* �ˮ`�I���Ӹ�ƭp��D�I�����N�z�O */
            if (strcmp(trim(GetCltEdrInsTp[i].iins_type), "33") == 0)
            {
                for (j_33 = 0; j_33 < ins_count_33; j_33++)
                {
                    $SELECT medrins_prem, medrpure_prem, medr_discount INTO $medrins_prem_33, $medrpure_prem_33, $medr_discount_33 FROM ca_pa_edr WHERE iendorse = $oriIendorse AND iinsurant = $GetCltEdrInsTp33[j_33].iinsurant AND iins_scope = $GetCltEdrInsTp33[j_33].iins_scope AND icareer = $GetCltEdrInsTp33[j_33].icareer;
                    if (SQLCODE == SQLNOTFOUND)
                    {
                        printf("ca_pa_edr not found\n");
                        $WHENEVER SQLERROR CONTINUE;
                        $ROLLBACK WORK;
                        if (exitsub(reply, M_CA_NINSTYPE) == True)
                            return M_CA_NINSTYPE;
                        else
                            return apiRC;
                    }

                    /* 1.�Ȥ�˿� �אּ 2.�z�L�O�N */
                    if (strncmp(newIedrReturn, "2", 1) == 0)
                    {
                        if (strncmp(ipaid_base, "A", 1) == 0)
                        {
                            if (medrins_prem >= 0)
                            {
                                medr_commission_33 = (long)(GetCltEdrInsTp[i].new_pcommission / 100.0 * (float)medrins_prem_33 + 0.5);
                                medr_agent_33 = (long)(GetCltEdrInsTp[i].new_pagent / 100.0 * (float)medrins_prem_33 + 0.5);
                            }
                            else
                            {
                                medr_commission_33 = (long)(GetCltEdrInsTp[i].new_pcommission / 100.0 * (float)medrins_prem_33 - 0.5);
                                medr_agent_33 = (long)(GetCltEdrInsTp[i].new_pagent / 100.0 * (float)medrins_prem_33 - 0.5);
                            }
                        }
                        else if (strncmp(ipaid_base, "B", 1) == 0)
                        {
                            if (medrins_prem >= 0)
                            {
                                medr_commission_33 = (long)(GetCltEdrInsTp[i].new_pcommission / 100.0 * (float)(medrins_prem_33 + medr_discount_33) + 0.5);
                                medr_agent_33 = (long)(GetCltEdrInsTp[i].new_pagent / 100.0 * (float)(medrins_prem_33 + medr_discount_33) + 0.5);
                            }
                            else
                            {
                                medr_commission_33 = (long)(GetCltEdrInsTp[i].new_pcommission / 100.0 * (float)(medrins_prem_33 + medr_discount_33) - 0.5);
                                medr_agent_33 = (long)(GetCltEdrInsTp[i].new_pagent / 100.0 * (float)(medrins_prem_33 + medr_discount_33) - 0.5);
                            }
                        }
                        else
                        {
                            if (medrins_prem >= 0)
                            {
                                medr_commission_33 = (long)(GetCltEdrInsTp[i].new_pcommission / 100.0 * (float)medrins_prem_33 + 0.5);
                                medr_agent_33 = (long)(GetCltEdrInsTp[i].new_pagent / 100.0 * (float)medrins_prem_33 + 0.5);
                            }
                            else
                            {
                                medr_commission_33 = (long)(GetCltEdrInsTp[i].new_pcommission / 100.0 * (float)medrins_prem_33 - 0.5);
                                medr_agent_33 = (long)(GetCltEdrInsTp[i].new_pagent / 100.0 * (float)medrins_prem_33 - 0.5);
                            }
                        }
                    }

                    /* 2.�z�L�O�N �אּ 1.�Ȥ�˿� */
                    if (strncmp(newIedrReturn, "1", 1) == 0)
                    {
                        medr_commission_33 = 0;
                        medr_agent_33 = 0;
                    }

                    medr_commission += medr_commission_33;
                    medr_agent += medr_agent_33;

                    stmt[0] = '\0';
                    sprintf_s(stmt, sizeof stmt, "INSERT INTO ca_pa_edr "
                                         "       (iendorse, iinsurant, iedr_type, ninsurant, dbirth,"
                                         "        ainsurant, iins_scope, icareer,"
                                         "        medrins_amt, fcal_way, pcal, medrins_prem, medrpure_prem,"
                                         "        pcommission, medr_commission, pagent, medr_agent, pdiscount, medr_discount,"
                                         "        dendorse, napplicant, relation_appl, nbeneficiary, relation_bene,tbenef, abenef_zip, abenef) "
                                         " SELECT '%s' , iinsurant,'%s' ,ninsurant, dbirth,"
                                         "        ainsurant, iins_scope, icareer,"
                                         "        0, 'M', 100, %ld, %.4f,"
                                         "        %.4f,%ld,%.4f,%ld,%.4f,%ld,"
                                         "        %ld, napplicant, relation_appl, nbeneficiary, relation_bene,tbenef, abenef_zip, abenef "
                                         "   FROM ca_pa_ply "
                                         "  WHERE ipolicy    = '%s' "
                                         "    AND iinsurant  = '%s' "
                                         "    AND iins_scope = '%s' "
                                         "    AND icareer    = '%s'",
                            temp, iedr_type_33,
                            medrins_prem_33, medrpure_prem_33,
                            GetCltEdrInsTp[i].new_pcommission, medr_commission_33,
                            GetCltEdrInsTp[i].new_pagent, medr_agent_33,
                            GetCltEdrInsTp[i].ori_pdiscount, medr_discount_33,
                            dwritten,
                            ipolicy,
                            GetCltEdrInsTp33[j_33].iinsurant,
                            GetCltEdrInsTp33[j_33].iins_scope,
                            GetCltEdrInsTp33[j_33].icareer);
                    printf("car422_insert.0011:[%s]\n", stmt);
                    $PREPARE caedrtp FROM $stmt;
                    $EXECUTE caedrtp;

                    if ((GetCltEdrInsTp[i].ori_pcommission == 0) && (GetCltEdrInsTp[i].ori_pagent == 0) && (strncmp(newIedrReturn, "2", 1) == 0))
                    {
                        sprintf_s(stmt, sizeof stmt, "UPDATE ca_pa_ply SET (%s) = (%s) WHERE %s %s %s %s ",
                                "mins_premium, mpure_prem, pcommission, mcommission, pagent, magent, pdiscount, mdiscount, iendorse ",
                                "mins_premium + ?, mpure_prem + ?,? , mcommission + ?, ?, magent + ?, ?, mdiscount + ?, ? ",
                                "ipolicy        = ? ",
                                "AND iinsurant  = ? ",
                                "AND iins_scope = ? ",
                                "AND icareer    = ? ");
                        printf("car422_insert.0011-1[%s]\n", stmt);
                        $PREPARE ca_pa_ins1 FROM $stmt;
                        $EXECUTE ca_pa_ins1 USING $medrins_prem_33, $medrpure_prem_33,
                            $GetCltEdrInsTp[i].new_pcommission, $medr_commission_33,
                            $GetCltEdrInsTp[i].new_pagent, $medr_agent_33,
                            $GetCltEdrInsTp[i].ori_pdiscount, $medr_discount_33,
                            $temp,
                            $ipolicy,
                            $GetCltEdrInsTp33[j_33].iinsurant,
                            $GetCltEdrInsTp33[j_33].iins_scope,
                            $GetCltEdrInsTp33[j_33].icareer;
                    }
                    else
                    {
                        sprintf_s(stmt, sizeof stmt, "UPDATE ca_pa_ply SET (%s) = (%s) WHERE %s %s %s %s ",
                                "mins_premium, mpure_prem, mcommission, magent, mdiscount, iendorse ",
                                "mins_premium + ?, mpure_prem + ?, mcommission + ?, magent + ?, mdiscount + ?, ? ",
                                "ipolicy        = ? ",
                                "AND iinsurant  = ? ",
                                "AND iins_scope = ? ",
                                "AND icareer    = ? ");
                        printf("car422_insert.0011-1[%s]\n", stmt);
                        $PREPARE ca_pa_ins2 FROM $stmt;
                        $EXECUTE ca_pa_ins2 USING $medrins_prem_33, $medrpure_prem_33,
                            $medr_commission_33,
                            $medr_agent_33,
                            $medr_discount_33,
                            $temp,
                            $ipolicy,
                            $GetCltEdrInsTp33[j_33].iinsurant,
                            $GetCltEdrInsTp33[j_33].iins_scope,
                            $GetCltEdrInsTp33[j_33].icareer;
                    }
                } /* end of for */
            }     /* end of strcmp( trim( GetCltEdrInsTp[i].iins_type),"33")==0 */
            else
            {
                /* �j���I����z�覡���t�~�p�����,����檺�����N�z�O�ۦP */
                if (strncmp(fcard_class, "1", 1) == 0)
                {
                    $SELECT nvl(medr_commission, 0), nvl(medr_agent, 0) INTO $medr_commission, $medr_agent FROM edr_ins_type WHERE iendorse = $oriIendorse AND iins_type = '21';

                    if (SQLCODE == SQLNOTFOUND)
                    {
                        $WHENEVER SQLERROR CONTINUE;
                        $ROLLBACK WORK;
                        if (exitsub(reply, M_CA_NINSTYPE) == True)
                            return M_CA_NINSTYPE;
                        else
                            return apiRC;
                    }
                }
                else
                {
                    /* 1.�Ȥ�˿� �אּ 2.�z�L�O�N */
                    /* if (strncmp(newIedrReturn,"2",1)==0) */
                    {
                        if (strncmp(ipaid_base, "A", 1) == 0)
                        {
                            if (medrins_prem >= 0)
                            {
                                medr_commission = (long)(GetCltEdrInsTp[i].new_pcommission / 100.00 * (float)medrins_prem + 0.5);
                                medr_agent = (long)(GetCltEdrInsTp[i].new_pagent / 100.00 * (float)medrins_prem + 0.5);
                            }
                            else
                            {
                                medr_commission = (long)(GetCltEdrInsTp[i].new_pcommission / 100.00 * (float)medrins_prem - 0.5);
                                medr_agent = (long)(GetCltEdrInsTp[i].new_pagent / 100.00 * (float)medrins_prem - 0.5);
                            }
                        }
                        else if (strncmp(ipaid_base, "B", 1) == 0)
                        {
                            if (medrins_prem >= 0)
                            {
                                medr_commission = (long)(GetCltEdrInsTp[i].new_pcommission / 100.00 * (float)(medrins_prem + medr_discount) + 0.5);
                                medr_agent = (long)(GetCltEdrInsTp[i].new_pagent / 100.00 * (float)(medrins_prem + medr_discount) + 0.5);
                            }
                            else
                            {
                                medr_commission = (long)(GetCltEdrInsTp[i].new_pcommission / 100.00 * (float)(medrins_prem + medr_discount) - 0.5);
                                medr_agent = (long)(GetCltEdrInsTp[i].new_pagent / 100.00 * (float)(medrins_prem + medr_discount) - 0.5);
                            }
                        }
                        else
                        {
                            if (medrins_prem >= 0)
                            {
                                medr_commission = (long)(GetCltEdrInsTp[i].new_pcommission / 100.00 * (float)medrins_prem + 0.5);
                                medr_agent = (long)(GetCltEdrInsTp[i].new_pagent / 100.00 * (float)medrins_prem + 0.5);
                            }
                            else
                            {
                                medr_commission = (long)(GetCltEdrInsTp[i].new_pcommission / 100.00 * (float)medrins_prem - 0.5);
                                medr_agent = (long)(GetCltEdrInsTp[i].new_pagent / 100.00 * (float)medrins_prem - 0.5);
                            }
                        }
                    } /* end of 1.�Ȥ�˿� �אּ 2.�z�L�O�N */

                    /* 2.�z�L�O�N �אּ 1.�Ȥ�˿� */
                    /* if (strncmp(newIedrReturn,"1",1)==0)
                    {
                        medr_commission = 0;
                        medr_agent      = 0;
                    } */
                } /* end of fcard_class */
            }     /* end else of strcmp( trim( GetCltEdrInsTp[i].iins_type),"33")==0 */

            printf("2.iins[%s]pcomm[%lf]pagent[%lf]pdisc[%lf]\n", GetCltEdrInsTp[i].iins_type, GetCltEdrInsTp[i].new_pcommission, GetCltEdrInsTp[i].new_pagent, GetCltEdrInsTp[i].ori_pdiscount);

            printf("before insert edr_ins_type medr_commission[%ld],medr_agent[%ld]\n", medr_commission, medr_agent);

            stmt[0] = '\0';
            sprintf_s(stmt, sizeof stmt,
                    "INSERT INTO edr_ins_type "
                    "              (iendorse, iins_type, iedr_type,"
                    "               medrinj_cover,medrdea_cover,medrdmg_cover,mdeduct,"
                    "               medrins_prem,medrpure_prem,"
                    "               fcal_way,pcal,qserial,"
                    "               pcommission,medr_commission,pagent,medr_agent,"
                    "               pdiscount,medr_discount,"
                    "               drate_ym, medr_prem,iproduct,ipaid_base,"
                    "               qday,medr_expense,medr_exp_disc,qcount,provision, psex_age,mdrunk_prem, mdrunk_pure_prem, "
                    "               mviolate_prem , mviolate_pure_prem) "
                    "        SELECT '%s', iins_type, '%s',"
                    "               0,0,0,0,"
                    "               %ld,%.4f,"
                    "               'M',100, qserial,"
                    "               %.4f,%ld,%.4f,%ld,%.4f,%ld,"
                    "               drate_ym,%ld,iproduct,ipaid_base,"
                    "               0,0,0,0,provision, psex_age,%ld,%f,%ld,%f "
                    "          FROM ply_ins_type "
                    "         WHERE ipolicy   = '%s' "
                    "           AND iins_type = '%s'",
                    temp, iedr_type,
                    medrins_prem, medrpure_prem,
                    GetCltEdrInsTp[i].new_pcommission, medr_commission,
                    GetCltEdrInsTp[i].new_pagent, medr_agent,
                    GetCltEdrInsTp[i].ori_pdiscount, medr_discount,
                    medr_prem, mdrunk_prem, mdrunk_pure_prem, mviolate_prem, mviolate_pure_prem,
                    ipolicy, GetCltEdrInsTp[i].iins_type);

            printf("car422_insert.0010:[%s]\n", stmt);
            $PREPARE edr_ins FROM $stmt;
            $EXECUTE edr_ins;

            fins_grp[0] = '\0';
            $SELECT fins_grp
                INTO : fins_grp
                           FROM insurance_type
                               WHERE iins_type = $GetCltEdrInsTp[i].iins_type;
            if (SQLCODE == SQLNOTFOUND)
            {
                $WHENEVER SQLERROR CONTINUE;
                $ROLLBACK WORK;
                if (exitsub(reply, M_CA_NINS_TYPE) == True)
                    return M_CA_NINS_TYPE;
                else
                    return apiRC;
            }

            if (strncmp(fins_grp, "1", 1) == 0) /* ���l�I */
            {
                mdmg_prem += medrins_prem;
                mdmg_pure_prem += medrpure_prem;
                mdmg_commi += medr_commission;
                mdmg_agent += medr_agent;
                mdmg_disc += medr_discount;
            }
            else if ((strncmp(fins_grp, "2", 1) == 0) || (strncmp(fins_grp, "3", 1) == 0)) /* ���d�I�αj��d���I */
            {
                mlia_prem += medrins_prem;
                mlia_pure_prem += medrpure_prem;
                mlia_commi += medr_commission;
                mlia_agent += medr_agent;
                mlia_disc += medr_discount;
            }

            printf("before update ply_ins_type medr_commission[%ld],medr_agent[%ld]\n", medr_commission, medr_agent);

            if ((GetCltEdrInsTp[i].ori_pcommission == 0) && (GetCltEdrInsTp[i].ori_pagent == 0) && (strncmp(newIedrReturn, "2", 1) == 0))
            {
                stmt[0] = '\0';
                sprintf_s(stmt, sizeof stmt, "UPDATE ply_ins_type SET (%s) = (%s) WHERE %s %s ",
                        "mins_premium, mpure_prem, mprem, pcommission, mcommission, pagent, magent, mdiscount, iendorse",
                        "mins_premium + ?, mpure_prem + ?, mprem + ?, ?, mcommission + ?, ?, magent + ?, mdiscount + ?, ?, mdrunk_prem+?, mdrunk_pure_prem+?, mviolate_prem+?, mviolate_pure_prem+? ",
                        "ipolicy = ? ",
                        "AND iins_type = ? ");
                $PREPARE ply_ins1 FROM $stmt;
                printf("car422_insert.0010-1[%s]\n", stmt);
                $EXECUTE ply_ins1 USING $medrins_prem, $medrpure_prem, $medr_prem,
                    $GetCltEdrInsTp[i].new_pcommission, $medr_commission,
                    $GetCltEdrInsTp[i].new_pagent, $medr_agent, $medr_discount,
                    $temp,
                    $mdrunk_prem, $mdrunk_pure_prem, $mviolate_prem, $mviolate_pure_prem,
                    $ipolicy, $GetCltEdrInsTp[i].iins_type;
            }
            else
            {
                stmt[0] = '\0';
                sprintf_s(stmt, sizeof stmt, "UPDATE ply_ins_type SET (%s) = (%s) WHERE %s %s ",
                        "mins_premium, mpure_prem, mprem, mcommission, magent, mdiscount, iendorse",
                        "mins_premium + ?, mpure_prem + ?, mprem + ?, mcommission + ?, magent + ?, mdiscount + ?, ?,mdrunk_prem+?, mdrunk_pure_prem+?,mviolate_prem+?, mviolate_pure_prem+? ",
                        "ipolicy = ? ",
                        "AND iins_type = ? ");
                $PREPARE ply_ins2 FROM $stmt;
                printf("car422_insert.0010-2[%s]\n", stmt);
                $EXECUTE ply_ins2 USING $medrins_prem, $medrpure_prem, $medr_prem,
                    $medr_commission, $medr_agent, $medr_discount, $temp,
                    $mdrunk_prem, $mdrunk_pure_prem, $mviolate_prem, $mviolate_pure_prem,
                    $ipolicy, $GetCltEdrInsTp[i].iins_type;
            }
        } /* end of for => �I�ة��� */

        if ((mdmg_prem + mlia_prem) < 0)
        {
            if (payresult[0] == 'R')
            {
                strcpy(fpay, "2"); /* ��ú */
            }
            else
            {
                strcpy(fpay, "1"); /* ��ú */
            }
        }

        $WHENEVER SQLERROR goto errexit;
        stmt[0] = '\0';
        sprintf_s(stmt, sizeof stmt, "INSERT INTO edr_relation "
                            "       (iendorse, fcard_class, ipolicy, icard, irelative_ply, irelative_edr,"
                            "        fedr_class, fpay, ipay, iedr_field, dedr_begin, dedr_end, "
                            "        ipro_year, ibrand, icar_type,"
                            "        medrdmg_agent, medrdmg_commi, medrdmg_prem, medrdmg_pure_prem,"
                            "        medrlia_agent, medrlia_commi, medrlia_prem, medrlia_pure_prem,"
                            "        ibig_comp, ibig_branch, ibig_office, ibig_sales, iresource,"
                            "        ibroker, iofficer, ileader, icorps, iedr_area,"
                            "        iedr_cashier, iedr_examiner, dedr_examine, dentry, dendorse,"
                            "        fprint, itreaty, ibranch, iquota, icomp_in, ibranch_in, icomp_at, ibranch_at,"
                            "        medr_ready, medr_stable, medr_compensate, medr_adjcom, medr_research, medr_invest,"
                            "        medr_bus_rule, medr_business, medr_capital,"
                            "        fcomp_class, fcomp_class_last, fdiscount,"
                            "        medrdmg_disc, medrlia_disc,"
                            "        iedr_return, icar_flag, terminate_rsn, qcount, "
                            "        iofficer_prmt, iquota_prmt, ileader_prmt, irate_type,bzfrom,iroute_comm,icomm_obj,qprovision,isecond_hand,icard_main, "
                            "        qdrunk_driving, isign, feply, feedr, aemail_eply, tmobile_eply,isign_edr,dsign_edr,fsign_status_edr,funder_chk_edr,iprog,qviolate) "
                            " SELECT '%s', fcard_class, ipolicy, icard, irelative_ply, '%s',"
                            "        '%s', '%s', ' ', ' ', %ld, %ld, "
                            "        ipro_year, ibrand, icar_type,"
                            "        %ld, %ld, %ld, %.4f,"
                            "        %ld, %ld, %ld, %.4f,"
                            "        ibig_comp, ibig_branch, ibig_office, ibig_sales, iresource,"
                            "        ibroker, iofficer, ileader, icorps, iarea,"
                            "        '%s', '%s', %ld, %ld, %ld ,"
                            "        1, itreaty, ibranch, iquota, icomp_in, ibranch_in,'%s' , '%s',"
                            "        0, 0, 0, 0, 0, 0,"
                            "        0, 0, 0,"
                            "        fcomp_class, fcomp_class_last, fdiscount,"
                            "        %ld, %ld,"
                            "        '%s', icar_flag, '0', 0, "
                            "        iofficer_prmt, iquota_prmt, ileader_prmt, irate_type,bzfrom,iroute_comm,icomm_obj,qprovision,isecond_hand,icard_main, "
                            "        qdrunk_driving, isign, feply, '0', aemail_eply, tmobile_eply,'system',today,40,'N','car422',qviolate "
                            "   FROM ply_relation "
                            "  WHERE ipolicy = '%s'",
                temp, oriIendorse,
                fedr_class, fpay, dedr_begin, dedr_end,
                mdmg_agent, mdmg_commi, mdmg_prem, mdmg_pure_prem,
                mlia_agent, mlia_commi, mlia_prem, mlia_pure_prem,
                userid, userid, dwritten, dwritten, dwritten,
                icomp_at, ibranch_at,
                mdmg_disc, mlia_disc,
                newIedrReturn,
                ipolicy);
        printf("car422_insert.0013[%s]\n", stmt);
        $PREPARE edr1 FROM $stmt;
        $EXECUTE edr1;

        $WHENEVER SQLERROR goto errexit;
        stmt[0] = '\0';
        sprintf_s(stmt, sizeof stmt, "INSERT INTO endorsement "
                           "       (iendorse, qply_period, dply_begin, dply_end, fassured, iassured,"
                           "        iassured_ext, nassured, ilicense, fsex, fmarriage, nuser,"
                           "        ibenef, nbenef, aassured, aassured_zip, itel, apayment, apayment_zip,"
                           "        iply_area, nbrand_abbr, ncar_abbr, fcar_note, qcylinder, iengine, ibody,"
                           "        itag, mcar_price, nequipment, flimit, pdmg_align, pbrg_align, plia_align,"
                           "        idmg_rate, pdmg_factor, ibrg_rate, pbrg_factor, qpt, fpt, psex_age, psex_age_damage,"
                           "        lia_class,"
                           "        plia_acc, dmg_acc_1st, dmg_acc_2nd, dmg_acc_3rd, pdmg_acc, fhuman, fcomp_24, payresult, "
                           "        iext_policy, qpro_month, mkilo_ply, mkilo_edr, irisk, irelative_ext, "
                           "        napplicant, dbirth, dissue, "
                           "        iextra_charge, gextra_charge, pextra_charge, "
                           "        iquery_num_damage, iquery_num, mequipment, "
                           "        survey_num, bound_num, abnormal_num, iapplicant, iroute, qlia_acc_sum, qdmg_acc_sum, "
                           "        fapplicant,fsex_appl,dbirth_appl,itel_appl,ndeputy_appl,nrelation_appl,ndeputy_assured, "
                           "        iassured_cntry, iapplicant_cntry, nassured_cntry, napplicant_cntry,"
                           "        foccup, noccup, applicant_foccup, applicant_noccup,tmobile_appl,aemail_appl, "
                           "        dinstall, isequence, ainstall_zip, ainstall) "
                           " SELECT '%s', a.qply_period, a.dply_begin, a.dply_end, b.fassured, b.iassured,"
                           "        b.iassured_ext, b.nassured, b.ilicense, b.fsex, b.fmarriage, b.nuser,"
                           "        b.ibenef, b.nbenef, b.aassured, b.aassured_zip, b.itel, b.apayment, b.apayment_zip,"
                           "        b.iply_area, b.nbrand_abbr, b.ncar_abbr, b.fcar_note, b.qcylinder, b.iengine, b.ibody,"
                           "        b.itag, b.mcar_price, b.nequipment, b.flimit, b.pdmg_align, b.pbrg_align, b.plia_align,"
                           "        b.idmg_rate, b.pdmg_factor, b.ibrg_rate, b.pbrg_factor, b.qpt, b.fpt, b.psex_age, "
                           "        b.psex_age_damage, b.lia_class,"
                           "        b.plia_acc, b.dmg_acc_1st, b.dmg_acc_2nd, b.dmg_acc_3rd, b.pdmg_acc, b.fhuman, b.fcomp_24, '%s', "
                           "        b.iext_policy, b.qpro_month, b.mkilo_ply, b.mkilo_edr, b.irisk, b.irelative_ext, "
                           "        b.napplicant, b.dbirth, b.dissue, "
                           "        b.iextra_charge, b.gextra_charge, b.pextra_charge, "
                           "        b.iquery_num_damage, b.iquery_num, b.mequipment, "
                           "        b.survey_num, b.bound_num, b.abnormal_num, b.iapplicant, b.iroute, b.qlia_acc_sum, b.qdmg_acc_sum, "
                           "        b.fapplicant,b.fsex_appl,b.dbirth_appl,b.itel_appl,b.ndeputy_appl,b.nrelation_appl,b.ndeputy_assured, "
                           "        CASE WHEN b.iassured_cntry='' THEN '8' ELSE b.iassured_cntry END, "
                           "        CASE WHEN b.iapplicant_cntry='' THEN '8' ELSE b.iapplicant_cntry END, b.nassured_cntry, b.napplicant_cntry, "
                           "        b.foccup, b.noccup, b.applicant_foccup, b.applicant_noccup,b.tmobile_appl,b.aemail_appl, "
                           "        b.dinstall, b.isequence, b.ainstall_zip, b.ainstall "
                           "   FROM ply_relation a,policy b "
                           "  WHERE a.ipolicy = b.ipolicy "
                           "    AND a.ipolicy = '%s' ",
                temp, payresult, ipolicy);
        printf("car422_insert.0012:[%s]\n", stmt);
        $PREPARE endor FROM $stmt;
        $EXECUTE endor;

        printf("car422_insert.0014:Update edr_relation set iedr_return = [%s] where iendorse = [%s]\n",
               newIedrReturn, oriIendorse);
        stmt[0] = '\0';
        sprintf_s(stmt, sizeof stmt, "UPDATE ply_relation SET (%s %s) = (%s %s) WHERE %s ",
                "mdmg_prem, mdmg_pure_prem, mdmg_agent, mdmg_commi, mdmg_discount,",
                "mlia_prem, mlia_pure_prem, mlia_agent, mlia_commi, mlia_discount",
                "mdmg_prem + ?, mdmg_pure_prem + ?, mdmg_agent + ?, mdmg_commi + ?, mdmg_discount + ?,",
                "mlia_prem + ?, mlia_pure_prem + ?, mlia_agent + ?, mlia_commi + ?, mlia_discount + ? ",
                "ipolicy = ?");
        printf("car422_insert.0014:[%s]\n", stmt);
        $PREPARE ply1 FROM $stmt;
        $EXECUTE ply1 USING $mdmg_prem, $mdmg_pure_prem, $mdmg_agent, $mdmg_commi, $mdmg_disc,
            $mlia_prem, $mlia_pure_prem, $mlia_agent, $mlia_commi, $mlia_disc,
            $ipolicy;

        rc = insert_cm_pre_receive_edr(temp, ipolicy, ipgid, v_sMsg);
        if (rc != M_CM_OK)
        {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            if (exitsub(reply, rc) == True)
                return rc;
            else
                return apiRC;
        }

        sprintf_s(stmt, sizeof stmt, "SELECT mdmg_commi+mlia_commi, ibroker, ileader, mbusiness FROM ply_relation WHERE ipolicy=?");
        printf("[%s]\n", stmt);

        $PREPARE prep1 FROM $stmt;
        $EXECUTE prep1 INTO $lMcommission, $ibroker, $ileader, $mbusiness USING $ipolicy;

        /* car9811303 �j���I99.3.1�O�v */
        if (fcard_class[0] == '1')
        {
            strcpy(iabn_type, "");

            sprintf_s(stmt, sizeof stmt, "SELECT drate_ym"
                          "  FROM ply_ins_type WHERE ipolicy=? AND iins_type = '21'");
            printf("[%s]\n", stmt);

            $PREPARE prep4 FROM $stmt;
            $EXECUTE prep4 INTO $comp_frate USING $ipolicy;

            rc = chk_commi_business(1, iabn_type, comp_frate, lMcommission, mbusiness, v_sMsg);

            if (rc != M_CM_OK)
            {
                $WHENEVER SQLERROR CONTINUE;
                $ROLLBACK WORK;
                if (exitsub(reply, rc) == True)
                    return rc;
                else
                    return apiRC;
            }
        }

    } /* end of ������� */
    $FREE prep4;

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %s ", M_CM_OK, temp_1, temp);
    iRtnLen = cm_buf_len(ReplyBuf);

    if (SendSyncReply(reply, ReplyBuf, iRtnLen, api_OKComplete) == False)
    {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        return apiRC;
    }

    $COMMIT WORK;

    return api_OKComplete;

errexit:
    MsgCode = SQLCODE;
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if (SQLCODE != 0)
        MsgCode = SQLCODE;
    return exitsub(reply, MsgCode) ? MsgCode : apiRC;
} /* car422_insert */

/****************************************************************************/
long car422_multiple_query(reply)
serverReply reply;
{
    char tmpbuf[4000];
    $char termWhere[80];
    int count = 0, iTmpLen = 0, iRtnLen = 0, replycnt = 0;
    $char cBuf[10];
    $char ipolicy[21], iendorse1[21], iendorse2[21];
    $char dendorse[11];
    $char sDB[3];
    $char iendorse1_A[21], iendorse1_B[21], iendorse2_A[21], iendorse2_B[21];
    int iedr;
    $char sWhere[1024], stmt[2048];

    cm_buf_get("%s", cDbName);
    cm_buf_get("%s %s %s %s", ipolicy, dendorse, iendorse1, iendorse2);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(cDbName) == False)
        return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    strcpy(sDB, get_db(ipolicy));
    if (strncmp(sDB, "100", 3) == 0)
    {
        if (exitsub(reply, M_CM_NOT_FOUND) == True)
            return M_CM_NOT_FOUND;
        else
            return apiRC;
    }

    if (db_select(sDB) == False)
        return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    strcpy(iendorse1, trim(iendorse1));
    iedr = strlen(iendorse1) - 1;
    if (iendorse1[iedr] == '*')
    {
        iendorse1[iedr] = ' ';
        strcpy(iendorse1_A, iendorse1);
        iendorse1[iedr] = '~';
        strcpy(iendorse1_B, iendorse1);
    }
    else
    {
        strcpy(iendorse1_A, iendorse1);
        strcpy(iendorse1_B, iendorse1);
    }

    strcpy(iendorse2, trim(iendorse2));
    iedr = strlen(iendorse2) - 1;
    if (iendorse2[iedr] == '*')
    {
        iendorse2[iedr] = ' ';
        strcpy(iendorse2_A, iendorse2);
        iendorse2[iedr] = '~';
        strcpy(iendorse2_B, iendorse2);
    }
    else
    {
        strcpy(iendorse2_A, iendorse2);
        strcpy(iendorse2_B, iendorse2);
    }

    if (dendorse[0] == '*')
    {
        strcpy(sWhere, " ");
    }
    else
    {
        strcpy(dendorse, cm_to_infdate(dendorse));
        strcpy(sWhere, " AND a.dendorse = '%s' ", dendorse);
    }

    sprintf_s(stmt, sizeof stmt,
      "SELECT UNIQUE a.ipolicy, a.iendorse, b.iendorse, a.dendorse "
      "   FROM edr_relation a,edr_relation b,edr_ins_type c    "
      "  WHERE a.ipolicy = b.ipolicy                           "
      "    AND a.iendorse between '%s' and '%s'                "
      "    AND b.iendorse between '%s' and '%s'                "
      "    AND a.dendorse = b.dendorse                         "
      "    AND a.fedr_class IN ('A','B')                       "
      "    AND b.fedr_class IN ('A','B')                       "
      "    AND b.iendorse = c.iendorse                         "
      "    AND c.iedr_type != '84'                             "
      "    AND a.iendorse < b.iendorse                         "
      "    AND a.ipolicy = '%s' %s                             "
      "  UNION                                                 "
      " SELECT UNIQUE a.ipolicy, a.iendorse, ' ', a.dendorse   "
      "   FROM edr_relation a,edr_ins_type b                   "
      "  WHERE a.iendorse = b.iendorse                         "
      "    AND b.iedr_type = '84'                              "
      "    AND a.fedr_class = 'B'                              "
      "    AND a.ipolicy = '%s' %s  ",
            iendorse1_A, iendorse1_B, iendorse2_A, iendorse2_B, ipolicy, sWhere, ipolicy, sWhere);
    printf("stmt[%s]\n", stmt);
    $PREPARE muid1 FROM $stmt;
    $DECLARE muid_cur CURSOR FOR muid1;
    $OPEN muid_cur;
    for (;;)
    {
        $FETCH muid_cur
            INTO $ipolicy,
            $iendorse1, $iendorse2, $dendorse;
        if (SQLCODE == SQLNOTFOUND)
            break;
        strcpy(dendorse, cm_from_infdate_100(dendorse));
        cm_buf_init(tmpbuf);

        if (count == 0)
        {
            cm_buf_res_msg(); /* reserve for MsgCode and count */
            cm_buf_res_count();
        }
        cm_buf_put("%s %s %s %s", ipolicy, dendorse, iendorse1, iendorse2);
        iTmpLen = cm_buf_len(tmpbuf);

        if (iTmpLen + iRtnLen < 3000)
        {
            memcpy(&ReplyBuf[iRtnLen], tmpbuf, iTmpLen);
            iRtnLen += iTmpLen;
            count++;
        }
        else
        {
            cm_buf_init(ReplyBuf); /* more than 4K, send to client side */
            cm_buf_put_msg(M_CM_OK);
            cm_buf_put_count(count);
            if (SendSyncReply(reply, ReplyBuf, iRtnLen, api_OK) == False)
            {
                $CLOSE muid_cur;
                return apiRC;
            }
            else
            {

                replycnt++; /* clear ReplyBuf and count to start all over again */
                if (replycnt == 10)
                {
                    cm_buf_init(ReplyBuf); /* more than 30K, client cannot display */
                    cm_buf_put("%l", M_CM_OUT_SPACE);
                    iTmpLen = cm_buf_len(ReplyBuf);
                    if (SendSyncReply(reply, ReplyBuf, iTmpLen, api_OKComplete) == False)
                        return apiRC;
                    return M_CM_OUT_SPACE;
                }
                ReplyBuf[0] = '\0';
                count = 0;
                cm_buf_init(ReplyBuf);
                cm_buf_res_msg(); /* reserve for MsgCode and count */
                cm_buf_res_count();
                cm_buf_put("%s %s %s %s", ipolicy, dendorse, iendorse1, iendorse2);
                iRtnLen = cm_buf_len(ReplyBuf);
                count++;
            }
        }
    }
    $CLOSE muid_cur;
    $FREE muid_cur;

    if (count > 0)
    {
        cm_buf_init(ReplyBuf);
        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(count);
        if (SendSyncReply(reply, ReplyBuf, iRtnLen, api_OKComplete) == False)
            return apiRC;
        return api_OKComplete;
    }
    else
    {
        if (exitsub(reply, M_CM_NOT_FOUND) == True) /*?*/
            return M_CM_NOT_FOUND;                  /*?*/
        else
            return apiRC;
    }

errexit:
    if (exitsub(reply, SQLCODE) == True)
        return SQLCODE;
    else
        return apiRC;
} /* car422_multiple_query */

/* ���������ݸ�Ʈw */
char *get_db(sIendorse)
char *sIendorse;
{
    $char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
    $char sTmp_db_name[21];
    char rtnd[11];

    $WHENEVER SQLERROR GOTO errexit;

    sTmp_db_name[0] = '\0';
    if (*sIendorse != '\0' && *sIendorse != ' ')
    {
        sTmp_db_name[0] = '\0';
        strncpy(sTmpScomp, sIendorse + 2, 1);
        sTmpScomp[1] = '\0';
        printf("sTmpScomp = %s\n", sTmpScomp);

        $SELECT iupcomp
            INTO $sTmpcomp
                FROM branch
                    WHERE ibranch_abbr = $sTmpScomp;
        if (SQLCODE == SQLNOTFOUND)
        {
            strcpy(rtnd, itoa(SQLCODE));
            goto errexit;
        }

        printf("sTmpcomp = %s\n", sTmpcomp);
        strcpy(sTmp_db_name, sTmpcomp);
    }
    return sTmp_db_name;

errexit:
    return rtnd;
}
