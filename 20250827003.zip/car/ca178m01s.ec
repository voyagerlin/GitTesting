/*--------------------------------------------------*/
/*   PROGRAM : ca178m01s.ec by 101314          */
/*   MODIFIER:                                      */
/*                                                  */
/*   DATE    : 2021/09/02                           */
/*--------------------------------------------------*/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;
#include <decimal.h>

#include <stdlib.h>
#include "cmprint.h"
#include "print.h"
#include "is_def.h"
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "safeclib.h"



char errbuf[512];
$int count1;
$char getfile[300];
FILE   *fp;
static int   recLen=1024;
static char  *bp;
char delimiter;
int  offset;
int  tmp_len;
/*--------------------------------------------------*/
long car178(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	long rtncode;
	long car178_insert(),car178_single_query(),car178_multiple_query(),car178_update_exec();
	char option;

	cm_buf_init(command);
 	cm_buf_get("%c",&option);
        printf("38:option\n");
 	switch(option)
 	{
	  	case 'A':
    		rtncode=car178_insert(reply);
        	break;
  		case 'Q':
    		rtncode=car178_single_query(reply);
        	break;
  		case 'M':
        	rtncode=car178_multiple_query(reply);
        	break;
  		case 'D':
  		case 'U':
        	rtncode=car178_update_exec(reply,command,com_len);
        	break;
  		default :
    		if(exitsub(reply,M_CM_WRONG_OPTION) == True)
        		return M_CM_WRONG_OPTION;
           	return apiRC;
 	}
 	return(rtncode);
}

/*--------------------------------------------------*/
long car178_insert(reply)
serverReply reply;
{
	$char    DBName[3],icode[11],ncode[41],level1[11],level2[11],level3[11];
   	$long    ilevel,qorder;
   	int      rows,tmp_len,i;
   	long     MsgCode;
   	DBinfo   *list;
   	int      k,j,is_add_fail=0, api_f;
   	$char    stmt_buf[2048];
   	$int     chk_code;

   	cm_buf_get("%s %d %s %s %d %s %s %s ",DBName,&ilevel,icode,ncode,&qorder,level1,level2,level3);

	$WHENEVER SQLERROR goto errexit;
	
   	if(db_select(DBName) == False)
   	{
    	if( exitsub(reply,M_CM_DB_NOTOPEN) == True )
        	return M_CM_DB_NOTOPEN;
      	return apiRC;
   	}
	
	printf("ilevel = [%d], icode = [%s], ncode = [%s], qorder = [%d], level1 = [%s]\n", ilevel, icode, ncode, qorder, level1);
	
	$BEGIN WORK;
	chk_code = 0;
	if(ilevel == 1 || ilevel == 3)  /*�h��1�B3�G�ۦP�h�Ŷ��Ǥ��i����*/
	{
		$SELECT count(*)
		   INTO $chk_code
		   FROM cm_group
		  WHERE igroup  = '04'
		    AND ilevel  = $ilevel
		    AND qorder  = $qorder;
	}
	else if(ilevel == 4)           /*�h��4�G�ۦP�h�Ťμh��1���䶶�Ǥ��i����*/
	{
		$SELECT count(*)
		   INTO $chk_code
		   FROM cm_group
		  WHERE igroup = '04'
		    AND ilevel = $ilevel
		    AND level1 = $level1
		    AND qorder = $qorder;
	}
	
	$COMMIT WORK;
	
	if (chk_code > 0)
	{
		return exitsub(reply,M_CM_DUPDATA) ? M_CM_DUPDATA :apiRC;
	}
	
	$BEGIN WORK;
	chk_code = 0;
	$SELECT count(*)
		   INTO $chk_code
		   FROM cm_group
		  WHERE igroup = '04'
		    AND ilevel = $ilevel
		    AND icode  = $icode;
			
	
	if (chk_code > 0) /*1121018009_C01 �P�h�� �N�X���o����*/
	{
		$COMMIT WORK;
		return exitsub(reply,M_CM_DUPDATA) ? M_CM_DUPDATA :apiRC;
	}
	
	sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO cm_group "
  		                   " (igroup, ilevel, icode, ncode, qorder, level1, level2, level3) "
  	                  " VALUES ('04',?,?,?,?,?,?,?)");
	$PREPARE b_id FROM $stmt_buf;
	$EXECUTE b_id USING $ilevel,$icode,$ncode,$qorder,$level1,$level2,$level3;

	if(is_add_fail == 3)
	{
		is_add_fail = 1;
	}

	cm_buf_init(ReplyBuf);
	cm_buf_put("%l ",M_CM_OK);
	tmp_len = cm_buf_len(ReplyBuf);

	api_f = api_OKComplete;
	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
	{
		is_add_fail = 2;
	}

	if( is_add_fail == 1 ) goto errexit;
	if( is_add_fail == 2 )
	{
   		$ROLLBACK WORK;
   		return apiRC;
  	}
  	
   	$WHENEVER SQLERROR GOTO errexit;
   	$COMMIT WORK;
   	return api_OKComplete;

 errexit:
   	MsgCode = SQLCODE;
   	$WHENEVER SQLERROR CONTINUE;
   	$ROLLBACK WORK;
   	if( SQLCODE != 0) MsgCode = SQLCODE;
   	if(exitsub(reply,MsgCode) == True)
    	return MsgCode;
   	else
    	return apiRC;
}

/*--------------------------------------------------*/
long car178_single_query(reply)
serverReply reply;
{
        
	$char   DBName[3],icode_in[11],icode[11],ncode[41],level1[11],level2[11],level3[11];
	$long   ilevel_in=0,ilevel=0,qorder=0;
	int     rows=0,tmp_len,first;

	cm_buf_get("%s %d %s ",DBName,&ilevel_in,icode_in);
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
		return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
	
	$SELECT ilevel, icode, ncode, qorder, level1, level2, level3
	   INTO $ilevel, $icode, $ncode, $qorder, $level1, $level2, $level3
	   FROM cm_group
	  WHERE igroup = '04' 
	    AND ilevel = $ilevel_in
	    AND icode  = $icode_in; 

	if(SQLCODE==SQLNOTFOUND)
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True) 
			return M_CM_NOT_FOUND;
		else
			return apiRC;
	}
	
	cm_buf_init(ReplyBuf);
	cm_buf_put("%l %d %s %s %d %s %s %s",M_CM_OK,ilevel,icode,ncode,qorder,level1,level2,level3);

	tmp_len = cm_buf_len(ReplyBuf);
	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
		return apiRC;
	else
		return api_OKComplete;
	
errexit:
	if ( exitsub(reply,SQLCODE) == True )
		return SQLCODE;
	return apiRC;
}

/*--------------------------------------------------*/
long car178_multiple_query(reply)
serverReply reply;
{

	$char   stmt[1024];
	$char   DBName[3],ilevel_in[5],icode_in[11],icode[11],ncode[41],level1[11],level2[11];
	$decimal qorder[15,0];
	$long   ilevel=0;
    $char   stmp_ilevel[128],stmp_icode[128];
   	char    tmpbuf[4000];
   	int     count=0,repbuf_len=0,tmp_len=0,replycnt=0;
   	int     i,total_count=0,flag;

    cm_buf_get("%s %s %s ",DBName,ilevel_in,icode_in);

   	$WHENEVER SQLERROR GOTO errexit;

   	if (db_select(DBName) == False)
   	{
    	if( exitsub(reply,M_CM_DB_NOTOPEN) == True )
			return M_CM_DB_NOTOPEN;
      	return apiRC;
   	}
	
	if(ilevel_in[0] == '*')
    {
    	strcpy(stmp_ilevel," ");
	}
   	else
    {
    	sprintf_s(stmp_ilevel, sizeof stmp_ilevel,"AND ilevel = %s ",ilevel_in);
	}
	
	if(icode_in[0] == '*')
    {
    	strcpy(stmp_icode," ");
	}
   	else
    {
    	sprintf_s(stmp_icode, sizeof stmp_icode,"AND icode MATCHES '%s' ",icode_in);
	}

	sprintf_s(stmt, sizeof stmt,"SELECT ilevel, icode, ncode, qorder, level1, level2, level3 "
                  "  FROM cm_group "
                  " WHERE igroup = '04' %s %s  "
                  " ORDER BY 1",stmp_ilevel,stmp_icode);

	$PREPARE m_cur1 FROM $stmt;
	$DECLARE m_cur CURSOR FOR m_cur1;
	printf("242:stmt[%s]\n",stmt);
	$OPEN m_cur;
   	for(;;)
   	{
    	$FETCH m_cur INTO $ilevel,$icode,$ncode,$level1,$level2;
     	if (SQLCODE != 0) break;

      	cm_buf_init(tmpbuf);

      	if ( count == 0 )
      	{
        	cm_buf_res_msg();               /* reserve for MsgCode and count */
         	cm_buf_res_count();
      	}
		
      	cm_buf_put("%d %s %s %s %s ",ilevel,icode,ncode,level1,level2);

      	tmp_len = cm_buf_len(tmpbuf);
      	
    	printf("261:tmpbuf[%s]\n",tmpbuf);
    	
      	if ( tmp_len + repbuf_len < 3000 )  /* buffer size less than 4K */
      	{
        	memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
         	repbuf_len += tmp_len;
         	count++;
     	}
      	else                               /* more than 4K, send to client side */
      	{
        	cm_buf_init(ReplyBuf);
         	cm_buf_put_msg(M_CM_OK);
         	cm_buf_put_count(count);
         	if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
         	{
            	$CLOSE m_cur;
	    		$FREE m_cur;
            	return apiRC;
			}
        	else                      /* clear ReplyBuf and count to start all over again */
        	{
            	replycnt++;
	            if (replycnt == 10)   /* more than 30K, client cannot display,error */
    	        {
        	       	cm_buf_init(ReplyBuf);
            	   	cm_buf_put("%l",M_CM_OUT_SPACE);
	               	tmp_len = cm_buf_len(ReplyBuf);
               		if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
                  	return apiRC;
               		return M_CM_OUT_SPACE;
            	}
            	ReplyBuf[0] = '\0';
            	count = 0;
            	cm_buf_init(ReplyBuf);
            	cm_buf_res_msg();     /* reserve for MsgCode and count */
            	cm_buf_res_count();

      			cm_buf_put("%d %s %s %s %s ",ilevel,icode,ncode,level1,level2);
            	repbuf_len = cm_buf_len(ReplyBuf);
            	count++;
			}
		}
	}  /* for loop */
   	$CLOSE m_cur;
   	$FREE m_cur;

	if (count > 0)  /* break out, at least one record is selected */
   	{
      	cm_buf_init(ReplyBuf);
      	cm_buf_put_msg(M_CM_OK);
      	cm_buf_put_count(count);
      	if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
        	return apiRC;
      	return api_OKComplete;
   	}
   	else  /* break out, not any raw is found */
   	{
    	if( exitsub(reply,M_CM_NOT_FOUND) == True )
        	return M_CA_NRATE;
      	return apiRC;
   	}

errexit:
   	if ( exitsub(reply,SQLCODE) == True )
    	return SQLCODE;
   	return apiRC;
}

long car178_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	$char   DBName[3],icode[11],ncode[41],level1[11],level2[11],level3[11];
	$long   ilevel,qorder;
	int     tmp_len,raw_len,count,rows=0,i,flag,count1,y;
	$char   cur_icode[11],cur_ncode[41],cur_level1[11],cur_level2[11],cur_level3[11];
	$long   cur_ilevel = 0,cur_qorder = 0;

	char  option,*pos,*raw_ptr,cur_buf[10000],*comm,type;
	long  dummy;
	long  MsgCode;
	int   first;
	int   k, j=0, is_del_fail=0, is_upd_fail=0;
	$char  stmt_buf[1024];
	$int     chk_code = 0;
	comm = (char *) command;
	cm_buf_init(command);
	cm_buf_get("%c %s",&option,DBName);

	$WHENEVER SQLERROR GOTO errexit;

   	if (db_select(DBName) == False)
		return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

	memcpy(&raw_len,&comm[com_len],sizeof(int));
	pos = &comm[com_len+sizeof(int)];
	raw_ptr = malloc(raw_len);

	if (raw_ptr != (char*)0)
		memcpy(raw_ptr,pos,raw_len);
	else
	{
		return exitsub(reply,M_CM_NOT_MALLOC) ? M_CM_NOT_MALLOC : apiRC;
	}

   	cm_buf_init(raw_ptr);
   	cm_buf_get("%l ",&dummy);
   	cm_buf_get("%d %s %s %d %s %s %s ",&ilevel,icode,ncode,&qorder,level1,level2,level3);
	printf("385:ilevel[%d],icode[%s],ncode[%s],qorder[%d],level1[%s],level2[%s],level3[%s] \n",ilevel,icode,ncode,qorder,level1,level2,level3);
   	$BEGIN WORK;

	$SELECT ilevel, icode, ncode, qorder, level1, level2, level3
	   INTO $cur_ilevel, $cur_icode, $cur_ncode, $cur_qorder, $cur_level1, $cur_level2, $cur_level3
	   FROM cm_group 
	  WHERE igroup = '04'
	    AND ilevel = $ilevel
	    AND icode  = $icode;
	printf("394:cur_ilevel[%d],cur_icode[%s],cur_ncode[%s],cur_qorder[%d],cur_level1[%s],cur_level2[%s],cur_level3[%s] \n",cur_ilevel,cur_icode,cur_ncode,cur_qorder,cur_level1,cur_level2,cur_level3);
	
	if (SQLCODE == SQLNOTFOUND)
	{
		MsgCode = M_CM_NOT_FOUND;
		$WHENEVER SQLERROR CONTINUE;
		$ROLLBACK WORK;
		if(SQLCODE != 0) MsgCode = SQLCODE;
		return exitsub(reply,MsgCode) ? MsgCode : apiRC;
	}
	
	cm_buf_init(cur_buf);
	cm_buf_put("%l %d %s %s %d %s %s  %s ",M_CM_OK,cur_ilevel,cur_icode,cur_ncode,cur_qorder,cur_level1,cur_level2,cur_level3);
	
   	$WHENEVER SQLERROR GOTO errexit;
	write(1, cur_buf, raw_len); 
	printf("\n");
	write(1, raw_ptr, raw_len);
	printf("\n");
	if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
	{
		MsgCode = M_CM_NOT_EQUAL;
		$WHENEVER SQLERROR CONTINUE;
		$ROLLBACK WORK;
		if(SQLCODE != 0) MsgCode = SQLCODE;
		return exitsub(reply,MsgCode) ? MsgCode : apiRC;
	}
 
   	$WHENEVER SQLERROR GOTO errexit;
	
	free(raw_ptr);

   	if( option == 'D' )
   	{
  		strcpy(stmt_buf, "DELETE FROM cm_group \
	                       WHERE igroup = '04' \
	                         AND ilevel = ?    \
	                         AND icode  = ? ");

   		$PREPARE d_id FROM $stmt_buf;
   		$EXECUTE d_id USING $cur_ilevel,$cur_icode;

     	cm_buf_init(ReplyBuf);
     	cm_buf_put("%l", M_CM_OK);
     	tmp_len = cm_buf_len(ReplyBuf);
     	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
     	{
        	$WHENEVER SQLERROR CONTINUE;
         	$ROLLBACK WORK;
         	return apiRC;
     	}
     	$WHENEVER SQLERROR GOTO errexit;
     	$COMMIT WORK;
     	return api_OKComplete;
   	}
   	else if(option == 'U')
   	{
    	cm_buf_init(command);
      	cm_buf_get("%c %s %d %s %s &d %s %s %s ",&option,DBName,&ilevel,icode,ncode,&qorder,level1,level2,level3);
		
		strcpy(icode, trim(icode));
		strcpy(cur_icode, trim(cur_icode));
		
		printf("ilevel = [%d], cur_ilevel = [%d]\n", ilevel, cur_ilevel);
		printf("icode = [%s], cur_icode = [%s]\n", icode, cur_icode);
		
		chk_code = 0;
		if(ilevel != cur_ilevel || strcmp(icode, cur_icode) != 0)
		{
			$SELECT count(*)
			   INTO $chk_code
			   FROM cm_group
			  WHERE igroup = '04'
				AND ilevel = $ilevel
				AND icode  = $icode;
		}
		

		if (chk_code > 0) /*1121018009_C01 �P�h�� �N�X���o����*/
		{
			$COMMIT WORK;
			return exitsub(reply,M_CM_DUPDATA) ? M_CM_DUPDATA :apiRC;
		}
		
		sprintf_s(stmt_buf, sizeof stmt_buf,"UPDATE cm_group "
   		                    " SET (ilevel, icode, ncode, level1, level2, level3) "
   		                    "   = (?,?,?,?,?,?)   "
   		                    " WHERE igroup = '04' "
   		                    " AND ilevel = ?   "
   		                    " AND icode  = ?");
                    printf("458:stmt[%s]\n",stmt_buf);
		$PREPARE u_id FROM $stmt_buf;
		$EXECUTE u_id USING $ilevel, $icode, $ncode, $level1, $level2,$level3, $cur_ilevel, $cur_icode;
		
		if(SQLCODE != 0)
		{
			is_upd_fail = 1;
		}
		
		if(sqlca.sqlerrd[2] == 0)
		{
			sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO cm_group "
			                           "  (ilevel, icode, ncode, qoredr, level1, level2, level3) "
			                      " VALUES (?,?,?,?,?,?,?)" );
			$PREPARE ua_id FROM $stmt_buf;
			$EXECUTE ua_id USING $ilevel, $icode, $ncode , $qorder, $ilevel, $level1, $level2, $level3;
			printf("475:-----stmt_buf[%s]\n",stmt_buf);
			if(SQLCODE != 0)
			{
				is_upd_fail = 1;
			}
		}
		#ifdef DEBUG
		printf("482:Update %d\n", j+1);
		#endif
		/*} for loop */
		
		if( is_upd_fail ) goto errexit;
    	cm_buf_init(ReplyBuf);
    	cm_buf_put("%l",M_CM_OK);
    	tmp_len = cm_buf_len(ReplyBuf);
    	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    	{
    		$WHENEVER SQLERROR CONTINUE;
        	$ROLLBACK WORK;
        	return apiRC;
    	}
	    $WHENEVER SQLERROR GOTO errexit;
    	$COMMIT WORK;
    	return api_OKComplete;
   	}
   	else
   	{
		return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
   	}

errexit:
	MsgCode = SQLCODE;
	$WHENEVER SQLERROR CONTINUE;
   	$ROLLBACK WORK;
   	if( SQLCODE != 0) MsgCode = SQLCODE;
   	return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
