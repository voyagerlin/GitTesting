/**********************************************************************/
/*   program id   : ca180q01s.ec                                      */
/*   program name : �n�O�H�ΫO���󥿧@�~                                */
/*   date written : 2021/09/08 by 101314                              */
/*   files        :                                                   */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <decimal.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "globdata.h"
#include "safeclib.h"

$char itype[15];  /*�����O(�ƿ�)*/
$char txb_query[40];
$char ileader[11],iquota[11];
$char dbgn[11],dbgn_q[21];
$char dend[11],dend_q[21];

$char stmpx[128];

int   count_db,k; 
char  outputf[21];
$char userid[11];
$char DBName[05];
$char msgbuf[128];

DBinfo *list;

main(argc, argv)
int argc;
char **argv;
{
	int rc;
         printf("46:init\n");
	batchinit();
	strcpy(DBName,         isNULLstr(argv[1]));
	strcpy(userid,         isNULLstr(argv[2]));
	strcpy(itype,         isNULLstr(argv[3]));  /*�����O(�ƿ�)*/
	strcpy(txb_query,           isNULLstr(argv[4]));  /*�d�ߤ��e(�渹)*/
	strcpy(ileader,           isNULLstr(argv[5])); /*�޲z�H*/
	strcpy(iquota,       isNULLstr(argv[6]));  /*�~�Z���*/
	strcpy(dbgn,        isNULLstr(argv[7])); /*�d�ߤ���϶�*/
	strcpy(dend,        isNULLstr(argv[8]));
	/*outputf*/
	strcpy(outputf,        isNULLstr(argv[9]));
	
	rc = car180_get_db();
	if (rc != M_CM_OK)
		return rc;

	rc = car180_prepare_data();
	if (rc != M_CM_OK)
		return rc;

	rc = car180_build();
	if (rc != M_CM_OK) 
		return rc;
}

long car180_get_db()
{
	$whenever sqlerror goto errexit;

	if (db_select(DBName) == FALSE) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}

long car180_prepare_data()
{
	$int qorder = 0,cnt = 0;
	$char stmt[8192];
	$char stmp1[128],stmp2[128],stmp3[128];
	$char sFullName[21];
	$char db_tmp[3];
	
	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == FALSE)
	{
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return FAIL;
	}
         /*����~�ର�褸�~(�t�ɶ�)*/
		 
	printf("dbgn_before = [%s]\n", dbgn);
	printf("dend_before = [%s]\n", dend);
	
	sprintf_s(dbgn, 20, "%s/00:00",dbgn);
         sprintf_s(dend, 20, "%s/23:59",dend);
         
  	strcpy(dbgn_q,cm_sysd_edatetime(dbgn));
  	strcpy(dend_q,cm_sysd_edatetime(dend));
	
  	sprintf_s(dbgn_q, sizeof dbgn_q, "%s:00",dbgn_q);
  	sprintf_s(dend_q, sizeof dend_q, "%s:59",dend_q);
	
	printf("dbgn=[%s]\n",dbgn);
	printf("dend=[%s]\n",dend);
	printf("dbgn_q=[%s]\n",dbgn_q);
	printf("dend_q=[%s]\n",dend_q);
				
	$char tmpType[15];
	strcpy(tmpType,itype);
	strcpy(itype,"");
	printf("tmpType=[%s]\n",tmpType);
	
	char *p = strtok(tmpType, ",");
		
         printf("%s\n", p);
         sprintf_s(itype, sizeof itype, "%s '%s',",itype,p);
         while(p != NULL){
             p = strtok(NULL, ",");
             if(p != NULL){
                printf("%s\n",p);
                sprintf_s(itype, sizeof itype, "%s '%s',",itype,p);
                printf("135:itype=[%s]\n",itype);
            }
         }
         
         itype[strlen(itype)-1] = '\0';
         
	printf("139:itype=[%s]\n",itype);
				
	$create temp table ply_out_tmp
	(			
	        ipgid CHAR (8),
                 itype CHAR (30),
                 ilog_number1 CHAR (21),
                 ilog_number2 CHAR (21),
                 nleader CHAR (20),
                 ncontent VARCHAR (51),
                 nquota VARCHAR (41),
                 iupdate CHAR (11),
                 nupdate CHAR (20),
                 dupdate CHAR (40)
	) with no log;
			
	sprintf_s(stmt, sizeof stmt, "INSERT INTO ply_out_tmp "
		"SELECT ipgid, case "
        "                	WHEN itype='I' THEN '�����渹�󥿭n�O�H' "
        "                	WHEN itype='J' THEN '�O�渹�󥿭n�O�H' "
        "                	WHEN itype='E' THEN '�����渹�󥿥ͮĤ�' "
        "                	WHEN itype='K' THEN '�O�渹�󥿥ͮĤ�' "
        "               END AS itype, "
		"      chr(127)||ilog_number1 AS ilog_number1, "
        "               chr(127)||ilog_number2 AS ilog_number2,(SELECT nname FROM officer WHERE iofficer = a.ilog_number2) AS nleader, "
        "               chr(127)||ncontent AS ncontent,(SELECT nbranch FROM sa_branch_type WHERE ibranch = a.ncontent) AS nquota, "
        "               chr(127)||iupdate AS iupdate,(SELECT nname FROM officer WHERE iofficer = a.iupdate) AS nupdate, "
        "               chr(127)||dupdate AS dupdate "
		"FROM ca_log  a "
		"WHERE ipgid='car180' "
		"AND itype IN (%s) "
		"AND ilog_number1 MATCHES '%s' "
		"AND ilog_number2 MATCHES '%s' "
        "          AND ncontent MATCHES '%s' "
		"AND dupdate BETWEEN '%s' AND '%s' "
		"ORDER BY dupdate",itype,txb_query,ileader,iquota,dbgn_q,dend_q);
		
	/* SQL���� chr(127), �i�H�b��EXCEL����0�������,���|���@�Ů�,�p���s�ɻݨD, ���V�ΡC*/	
		
	printf("stmt[%s]\n",stmt);

	$PREPARE ply_out_1 FROM $stmt;
	$EXECUTE ply_out_1;
	

	return M_CM_OK;
	
errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
/*--------------------------------------------------------------------*/


long car180_build()
{
	int rc;
	$char sfilename[256],stitle[2048],stmt1[4096],stmt11[8192];

	$WHENEVER SQLERROR GOTO errexit;
	
	sprintf_s(sfilename, sizeof sfilename, "�n�O�H�ΫO���󥿧@�~[%s]\n",stmpx);
	
	/*stitle�ɶq�@��d�w�A�קK���D����*/
	sprintf_s(stitle, sizeof stitle, "�󥿶���\t�󥿤��\t�O�渹\t����H��\t����H���m�W\t�޲z�H\t�޲z�H�m�W\t�~�Z���\t�~�Z���W��\t");
	
	strcpy(stmt1,"SELECT itype,dupdate,ilog_number1,iupdate,nupdate,ilog_number2,nleader,ncontent,nquota \
		FROM ply_out_tmp");
	
	rc = unload_file(outputf," ",sfilename,stitle,stmt1);
	$DROP TABLE ply_out_tmp;	
	
	if (rc != SUCCESS) 
	{
	    sprintf_s(msgbuf, sizeof msgbuf, " %s �ɮ׵L�k���� ",sfilename);
	    EWRITE(userid, rc , msgbuf);
	    return rc;
	}
	
	printf("done. return M_CM_OK\n");	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	return SQLCODE;
}
