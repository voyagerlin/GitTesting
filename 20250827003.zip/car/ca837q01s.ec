/************************************************/
/*   PROGRAM : ca837q01s.ec                     */
/*   MODIFY  : cyrus                            */
/*   DATE    : 103.06.16                        */
/*   NOTE    : �ۦ�l�v�F���v�έp��             */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
$include datetime.h;
#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"

$char DBName[05], iForm_Tp[03], outputf[N_FILE+1];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1];
char  userid[11];

char  msgbuf[100];
$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;
$int  PERIOD;

static int  max_count;

DBinfo  *list;
int     count_db;

$char sIbranch[BRANCH_ID], sIofficer[EMPLOYEE_ID];
$char sNname[EMPLOYEE_NAME];
$char sIclaim[CLAIM_NUM], sFcard_class[2], sDclaim[YYYYMMDD];
$char sYearMonth[7];
$char sIadjuster[EMPLOYEE_ID], sFclose[2], sIins_type[INSURANCE_TYPE];
$char sDclose[13], victim[11], flast[2];
$char sDgroup[11];
$char sNgroup[5],sNadjuster[11];
$char sIupbranch[3], sNupgroup[11];
$char sFins_grp[2];
$char sBgnDate_e[11], sEndDate_e[11], sBgnDate[11], sEndDate[11];
$long lBgnDate, lEndDate;
$long iQorder, i, qmonth, lMins_stl;
$long qdmg_claim, qdmg_close, qdmg_nopay;       /** ���l **/
$long qlia_claim, qlia_close, qlia_nopay;       /** �d�� **/
$long qburg_claim, qburg_close, qburg_nopay;    /** �W�[�ѵs�����Ѩ��l�������X **/
$long qcomp_claim, qcomp_close, qcomp_nopay;    /** �j�� **/
$long qwea_claim, qwea_close, qwea_nopay;       /** �]�� **/
$date lDclaim;
$int  iclose_type = 0;
$char stmt[2000];

$char iins_item[INSURANCE_TYPE];

int qlia, qburg, qdmg, qwea;
$int iTmp;
$int iMaxCnt;
$int id1;
$int iMonthDiff;

long car837_build();
void car837_title();
long car837_body();
long car837_print();
void car837_print2();
int DiffMonth();

/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
   int rc;
   
   batchinit();
   strcpy(DBName  , isNULLstr(argv[1]));
   strcpy(userid  , isNULLstr(argv[2]));
   strcpy(sBgnDate, isNULLstr(argv[3]));
   strcpy(sEndDate, isNULLstr(argv[4]));
   strcpy(outputf , isNULLstr(argv[5]));

   strcpy(sBgnDate_e, cm_to_infdate(sBgnDate));
   strcpy(sEndDate_e, cm_to_infdate(sEndDate));

   rstrdate(sBgnDate_e, &lBgnDate);
   rstrdate(sEndDate_e, &lEndDate);

   printf("sBgnDate_e[%s] sEndDate_e[%s]\n",sBgnDate_e , sEndDate_e);
 
   rc=car837_get_db();
   if (rc!=M_CM_OK)
      return rc;
   
   rc = car837_build();
   if (rc != M_CM_OK)
       return rc;

   return M_CM_OK;
   
errexit:
   printf("main :SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/

long car837_build()
{
   $char  TitleFmt[N_FILE+1],BodyFmt[N_FILE+1];
   int    rc;
   
   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT;
   
   if (db_select(DBName) == False)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   rc = car837_body();
   if (rc != M_CM_OK)
       return rc;
           
   rc = car837_print();
   if (rc != M_CM_OK)
       return rc;
 
   return M_CM_OK;

errexit:
   EWRITE(userid,rc,sqlca.sqlerrm);
   return SQLCODE;  
}

long car837_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

long car837_body()
{
    int i;
    long rc;
    $char sStmt[4096],sStmt1[1024],sStmt2[1024],sStmt3[1024],sStmt4[1024];
    $char  stmt[1024];

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;

    $CREATE TEMP TABLE car837
    (
        iupbranch      char(10),
        iclaim         char(20),
        iser_rec       int,
        lawgiver      char(10),
        qshallcnt      int default 0,        /** �������ۦ�l�v���             **/
        qmidalcnt      int default 0,        /** �����w�ۦ�l�v�������         **/
        qshallmidcnt   int default 0,        /** �������ۦ�l�v���(�����w����) **/
        qmidficnt      int default 0         /** �������ۦ�l�v���(�����w����) **/
    )
    WITH NO LOG;

    $CREATE INDEX car837_tmp_id1 ON car837(lawgiver);
    $CREATE INDEX car837_tmp_id2 ON car837(iclaim, iser_rec);

    $CREATE TEMP TABLE car837_detail
    (
        iclaim              char(20),
        iser_rec            int,
        nadjuster           char(10),
        lawgiver            char(10),
        daccident           date,
        dclose              date,
        iins_type           char(7),
        mins_stl            int,
        mmrecov             int,
        really_recovery     int,
        drecov              date,
        frecover            char(1),
        frecov              char(1),
        qshallcnt           int default 0,        /** �������ۦ�l�v���             **/
        qmidalcnt           int default 0,        /** �����w�ۦ�l�v�������         **/
        qshallmidcnt        int default 0,        /** �������ۦ�l�v���(�����w����) **/
        qmidficnt           int default 0         /** �������ۦ�l�v���(�����w����) **/
    )
    WITH NO LOG;

    for (i=0;i<count_db;i++)
    {
        /** �������ۦ�l�v��� **/
        sprintf_s(sStmt,4096,
         " insert into car837 \
           select '%s', a.iclaim, a.iser_rec, a.lawgiver, 1 as cnt, 0, 0, 0   \
             from %s:recovery a                             \
            where (a.dentry is null or date(a.dentry) < ?)  \
              and (a.drecov is null or drecov >= ? )        \
              and a.irec_kind = '1'                         \
              and a.frecover  = '1'                         \
              and a.lawgiver != ''                          \
              and a.frecov   != '2'                         \
              and a.iclaim in (select b.iclaim              \
                                 from %s:stl_ins_type b     \
                                where a.iclaim = b.iclaim   \
                                  and b.dclose is not null  \
                                  and b.iins_type in (select icode           \
                                                        from cu_code_data    \
                                                       where itype = 'CT'))  \
                ", list[i].dbbranch, list[i].dbname, list[i].dbname);
        printf("sStmt[%s]\n",sStmt);
        $prepare main_cur1 from $sStmt;
        $execute main_cur1 using $sBgnDate_e, $sBgnDate_e;

        /** �����w�ۦ�l�v������� **/
        sprintf_s(sStmt,4096,
         " insert into car837 \
           select '%s', a.iclaim, a.iser_rec, a.lawgiver, 0, 1 as cnt, 0, 0   \
             from %s:recovery a                             \
            where (a.drecov between ? and ?)                \
              and a.irec_kind = '1'                         \
              and a.frecover  = '2'                         \
              and a.frecov    = '3'                         \
              and a.lawgiver != ''                          \
              and a.frecov   != '2'                         \
              and a.iclaim in (select b.iclaim              \
                                 from %s:stl_ins_type b     \
                                where a.iclaim = b.iclaim   \
                                  and b.dclose is not null  \
                                  and b.iins_type in (select icode           \
                                                        from cu_code_data    \
                                                       where itype = 'CT'))  \
                ", list[i].dbbranch, list[i].dbname, list[i].dbname);
        printf("sStmt[%s]\n",sStmt);
        $prepare main_cur2 from $sStmt;
        $execute main_cur2 using $sBgnDate_e, $sEndDate_e;

        /** �������ۦ�l�v���(�����w����) **/
        sprintf_s(sStmt,4096,
         " insert into car837 \
           select '%s', a.iclaim, a.iser_rec, a.lawgiver, 0, 0, 1 as cnt, 0   \
             from %s:recovery a                             \
            where (a.dentry is null or date(a.dentry) < ?)        \
              and (a.drecov between ? and ?)                \
              and a.irec_kind = '1'                         \
              and a.frecover  = '1'                         \
              and a.frecov    = '3'                         \
              and a.lawgiver != ''                          \
              and a.frecov   != '2'                         \
              and a.iclaim in (select b.iclaim              \
                                 from %s:stl_ins_type b     \
                                where a.iclaim = b.iclaim   \
                                  and b.dclose is not null  \
                                  and b.iins_type in (select icode           \
                                                        from cu_code_data    \
                                                       where itype = 'CT'))  \
                ", list[i].dbbranch, list[i].dbname, list[i].dbname);
        printf("sStmt[%s]\n",sStmt);
        $prepare main_cur3 from $sStmt;
        $execute main_cur3 using $sBgnDate_e, $sBgnDate_e, $sEndDate_e;

        /** �������ۦ�l�v���(�����w����) **/
        sprintf_s(sStmt,4096,
         " insert into car837 \
           select '%s', a.iclaim, a.iser_rec, a.lawgiver, 0, 0, 0, 1 as cnt   \
             from %s:recovery a                             \
            where (date(a.dentry) between ? and ?)          \
              and (a.drecov between ? and ?)                \
              and a.irec_kind = '1'                         \
              and a.frecover  = '1'                         \
              and a.frecov    = '3'                         \
              and a.lawgiver != ''                          \
              and a.frecov   != '2'                         \
              and a.iclaim in (select b.iclaim              \
                                 from %s:stl_ins_type b     \
                                where a.iclaim = b.iclaim   \
                                  and b.dclose is not null  \
                                  and b.iins_type in (select icode           \
                                                        from cu_code_data    \
                                                       where itype = 'CT'))  \
                ", list[i].dbbranch, list[i].dbname, list[i].dbname);
        printf("sStmt[%s]\n",sStmt);
        $prepare main_cur4 from $sStmt;
        $execute main_cur4 using $sBgnDate_e, $sEndDate_e, $sBgnDate_e, $sEndDate_e;

        /** ���Ӹ�� **/
        sprintf_s(sStmt,4096,
        "insert into car837_detail           \
          select a.iclaim, a.iser_rec,       \
                 (select nname from officer where iofficer = b.adjustment) as nadjuster,   \
                 a.lawgiver,                 \
                 date(b.daccident) as daccident, \
                 a.dclose, \
                 (select min(iins_type) from %s:stl_ins_type  \
                   where iclaim = a.iclaim and dclose is not null   \
                     and iins_type in (select icode  \
                                         from cu_code_data  \
                                        where itype = 'CT')) as iins_type,  \
                 nvl(((select sum(mins_stl) from %s:stl_ins_type   \
                        where iclaim = a.iclaim and dclose is not null \
                          and iins_type in (select icode  \
                                              from cu_code_data  \
                                             where itype = 'CT'))),0) as mins_stl,  \
                 a.mmrecov, a.really_recovery, a.drecov, a.frecover, a.frecov,   \
                 c.qshallcnt, c.qmidalcnt, c.qshallmidcnt, c.qmidficnt  \
            from %s:recovery a, ca_clm_process b, car837 c  \
           where a.iclaim   =  b.iclaim                    \
             and a.iclaim   =  c.iclaim                    \
             and a.iser_rec =  c.iser_rec                  \
             and c.iupbranch = '%s' ",list[i].dbname ,list[i].dbname, list[i].dbname, list[i].dbbranch);
        printf("sStmt[%s]\n",sStmt);
        $prepare main_cur5 from $sStmt;
        $execute main_cur5;

    } /* end for three database */
    
    return M_CM_OK;
        
errexit:
   printf("car837_body ==> SQLCODE:[%ld][%s] \n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   printf("   end EWRITE \n");
   return SQLCODE;
}

long car837_print()
{
   $char stmt[4096], stmt1[1024], stmt2[1024];
   $long qorder;
   int i,x,j,k;
   $int COUNT;
   $char sfilename[31];
   $char stitle[10000];
   $char ssql[10000];
   $char dyearmonth_tmp[7];
   $char title_tmp[101];
   $char title_tmp0[101];
   $char title_tmp1[101];
   $char title_tmp2[101];
   $char filed[20][15];
   $char sqltmp[1024];
   $char filed_tmp[200];
   $char sErrmsg[100];
   $int  rc;

   $WHENEVER ERROR goto errexit;
   $SET LOCK MODE TO WAIT;

   /******************************************
    $CREATE TEMP TABLE car837
    (
        iupbranch      char(10),
        iclaim         char(20),
        iadjuster      char(10),
        qshallcnt      int default 0,            �������ۦ�l�v���
        qmidalcnt      int default 0,            �����w�ۦ�l�v�������
        qshallmidcnt   int default 0,            �������ۦ�l�v���(�����w����)
        qmidficnt      int default 0             �������ۦ�l�v���(�����w����)
    )
    WITH NO LOG;
    ******************************************/

   strcpy(sfilename,"�ۦ�l�v�F���v�έp��");

   strcpy(stitle,"�έp����G");
   strcat(stitle, sBgnDate_e);
   strcat(stitle, " ~ ");
   strcat(stitle, sEndDate_e);
   strcat(stitle,"\n\t�`�����q�O\t���\t�Ҧb�a\t�l�v�H��\t�������ۦ�l�v���\t�����w�ۦ�l�v�������\t�������ۦ�l�v���(�����w����)\t�������ۦ�l�v���(�����w����)\t�F���v\t");

   strcpy(ssql, "  select decode(b.iupcomp,'0','00','1','40','2','70','5','22','6','33','7','66') as iupcomp, ");
   strcat(ssql, "         (select xx.nbranch from sa_branch_type xx where xx.ibranch = b.iquota) as nquota,   ");
   strcat(ssql, "         (select yy.nchi_full from branch yy, cm_clm_adjuster zz where zz.iapp_unit = yy.ibranch and zz.empl_no = a.lawgiver) as nlocal, ");
   strcat(ssql, "  b.nname,   ");
   strcat(ssql, "  sum(qshallcnt) as qshallcnt, sum(qmidalcnt) as qmidalcnt, sum(qshallmidcnt) as qshallmidcnt, sum(qmidficnt) as qmidficnt, ");
   strcat(ssql, "  case when sum(qshallcnt)+sum(qmidalcnt)+sum(qmidficnt) = 0 then 0 else ");
   strcat(ssql, " round(((sum(qshallmidcnt)+sum(qmidalcnt)+sum(qmidficnt)) * 100 / (sum(qshallcnt)+sum(qmidalcnt)+sum(qmidficnt))) ,2) end as iprate ");
   strcat(ssql, "    from car837 a, officer b where a.lawgiver =  b.iofficer "); 
   strcat(ssql, "     and a.lawgiver in (select empl_no from cm_clm_adjuster) group by 1,2,3,4 into temp car837_temp with no log ");

   printf(" ssql [%s]\n",ssql);
 
   $prepare exe1 from $ssql;
   $execute exe1;

   strcpy(ssql," select * from car837_temp order by 1,2,3,4 ");

   rc = unload_file(outputf,"A",sfilename,stitle,ssql);

   if (rc != SUCCESS)
   {
       if (rc == 3501)
       {
          sprintf_s(sErrmsg,100," ��J���^������䤣���� ",sfilename);
       }
       else
       {
          sprintf_s(sErrmsg,100," %s �ɮ׵L�k���� ",sfilename);
       }

       EWRITE(userid, rc , sErrmsg);
       exit(1);
   }

   strcpy(sfilename,"�ۦ�l�v�F���v���Ӫ�");

   strcpy(stitle,"�έp����G");
   strcat(stitle, sBgnDate_e);
   strcat(stitle, " ~ ");
   strcat(stitle, sEndDate_e);
   strcat(stitle,"\n\t�`�����q�O\t���\t�Ҧb�a\t�l�v�H��\t�������ۦ�l�v���\t�����w�ۦ�l�v�������\t�������ۦ�l�v���(�����w����)\t�������ۦ�l�v���(�����w����)\t");
   strcat(stitle,"�߮׸��X\t�l�v�Ǹ�\t�z�ߤH��\t�X�I���\t���פ��\t�I�إN��\t�ߥI���B\t���l�v���B\t��l�`�B\t�l�v���\t�l�v�O\t�l�v���A");

   strcpy(ssql, "  select decode(b.iupcomp,'0','00','1','40','2','70','5','22','6','33','7','66') as iupcomp, ");
   strcat(ssql, "         (select xx.nbranch from sa_branch_type xx where xx.ibranch = b.iquota) as nquota,   ");
   strcat(ssql, "         (select yy.nchi_full from branch yy, cm_clm_adjuster zz where zz.iapp_unit = yy.ibranch and zz.empl_no = a.lawgiver) as nlocal, ");
   strcat(ssql, "  b.nname,   ");
   strcat(ssql, "  qshallcnt, qmidalcnt, qshallmidcnt, qmidficnt, ");
   strcat(ssql, "  a.iclaim, a.iser_rec, a.nadjuster, a.daccident, a.dclose, ");
   strcat(ssql, "  a.iins_type, a.mins_stl, a.mmrecov, a.really_recovery, a.drecov, ");
   strcat(ssql, "  decode(a.frecover,'0','0:�����l�v','1','1:�ۦ�l�v','2','2:�w�ۦ�l�v','3','3:�k�Ȱl�v','4','4:�ۦ�l�v��k�Ȱl�v', ");
   strcat(ssql, "                    '5','5:�j���I�u��','6','6:�j���I�N���u�^','7','7:�\�i�K�l�v',''), ");
   strcat(ssql, "  decode(a.frecov, '0','0:�����l�v','1','1:�l�v��','2','2:���l�v','3','3:�����l�v','4','4:�l�v�����l�v�z��','') ");
   strcat(ssql, "    from car837_detail a, officer b ");
   strcat(ssql, "   where a.lawgiver = b.iofficer ");
   strcat(ssql, "     and a.lawgiver in (select empl_no from cm_clm_adjuster) ");
   strcat(ssql, "   order by 1,2,3,4,5 ");

   rc = unload_file(outputf,"B",sfilename,stitle,ssql);

   if (rc != SUCCESS)
   {
       if (rc == 3501)
       {
          sprintf_s(sErrmsg,100," ��J���^������䤣���� ",sfilename);
       }
       else
       {
          sprintf_s(sErrmsg,100," %s �ɮ׵L�k���� ",sfilename);
       }

       EWRITE(userid, rc , sErrmsg);
       exit(1);
   }

   return M_CM_OK;

errexit:
  printf("SQL=[%d], sqlca.sqlerrm[%s]\n", SQLCODE, sqlca.sqlerrm);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  exit(1);
    
}

int DiffMonth(d1,d2)    /* input data should be date format */
long d1, d2;
{
short mdy1[3], mdy2[3];
int datediff=0;

    rjulmdy(d1,mdy1);
    rjulmdy(d2,mdy2);
    datediff=(mdy1[2]*12+mdy1[0])-(mdy2[2]*12+mdy2[0]);
    if (datediff<0) datediff=0;
    return datediff;
}

