/*********************************************
 * Copyright (C) 1995 Intellisys Corporation
 * Program : ca997volp01s.ec
 * ���N�I��ƶǿ�   modify by sylvia 99.12.01 
 *********************************************/
 
#include <stdio.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"
#include "sqlfatal.h"
#include <time.h>

#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "car_common.h"
#include "safeclib.h"

#define ONLINE_DATE "04/29/2007"	/* �e���T��Ʊj����N���ɤW�u�� */

 time_t tstart,tend;   
 float tused=0;

/*--------------------------------------------------------------------*/
DBinfo  *list;
int     i=0,count_db=0,rc=0;

char userid[11],option[2],outputf[21];
$char DBName[05];
$char dbgn1[11],dend1[11],datebgn[11],dateend[11];
$char sApHome[31];
char errmsg[200];
FILE *errfpt;
FILE *fptr;

$char  errFile[30],strlog[500],errlog[300];

/* data from ori_ply_relation */

$char ipolicy[21],fcard_class[2],sIpolicy1[15],ilast_ply[21],icard[21];
$char icar_type[3],iissue_ym[6],ibrand[10],ipro_year[5],fcomp_class[3];
$char fcomp_class_last[3],ibig_comp[2],chk_dpolicy[2];
$long dpolicy=0,dply_begin=0,dply_end=0,madjcom_prem=0,mbusiness=0;
$int qply_period=0, ibatch_no=0;

/* data from original_ply*/
$char ilicense[11],ibirth[9],fsex[2],fmarriage[2],fpt[2],iengine[CA_ENGINE_NUM];
$char ibody[CA_BODY_NUM],itag[CA_TAG_NUM],iassured[11],nassured[121],iply_area[3],fassured[2];
$int qcylinder=0;
$double qpt;
$int id1=0;
   
/* data from ori_ins_type */
$int ipdmg_align=0, iplia_align=0,ipbrg_align=0;
int iTmpbuf=0;
$char iins_type[INSURANCE_TYPE],iins_type_rule[3],drate_ym[6];
$long  mdamage_cover=0,minjured_cover=0,mdeath_cover=0;
$long  mdeduct=0,mins_premium=0,mprem=0;

/* others data */
int iFetch=0;
char  sPrePolicy[21],sPrePolicy1[21];
$long  sDpolicy=0;
$char prem_subtot_c[9],mins_premium_c[9];
$char objno[5],icode[2],drate[11];
$long prem_subtot=0,prem_subtot0=0,mdeduct01=0,cntrlrec=0,birth_yyyy=0;
$long prem_total=0,qcount=0;
$char prtstr[1000];
char  drate_yy[4],drate_mm[3],drate_dd[3],tmp_yyy[4],tmp_yyyy[5];
$char  dply_yy[4],dply_mm[3],ibirth_yy[5],ibirth_mm[3],ibirth_dd[3],tmp_dd[3];
char  card_str[16],dply_begin_c[9],dply_end_c[9];
char  dply_begin_yy[4],dply_begin_mm[3],dply_begin_dd[3];
char  dply_end_yy[4],dply_end_mm[3],dply_end_dd[3];
$char  iissue_yy[5],iissue_mm[3],cntrlrec_c[7];
char  minjured_c[13],mdeath_c[13],mdamage_c[13],mdeduct_c[13],mprem_c[13];
char  drate_c[9],dpolicy_c[9],sTmpbuf[200];
char  day_yy[4],day_mm[3],day_dd[3];
long  yy_long=0,iRtnCode=0;
char  companyid[3];
int   rtn=0;
char  strtmp[31], strcol6[101];     /* �t�X101/3/1�_���N�I���T�ǿ�W�沧�� add by sylvia 101.01.02 */

$int nassured_len = 0;
$char nassured_1[21];

long car9971_get_db();
/*long car9971_build_vol();*/
long car9971_build_vol2();          /* 101/03/01 �_�s�����N�I���T�ǿ�W�沧�� add by sylvia 101.01.02 */
long car9971_ori_relation();
long car9971_ply_relation();
extern char *sformat_trade();
extern long split_policy();
extern int rptftpinsert();
static char *get_car_full_db();  /*   �ǤJ�O�渹��X���O�檺�k�ݸ��*/
long check_if_exist();
long  today, online_date, online;

/*--------------------------------------------------------------------*/
main(argc,argv)
int   argc;
char  **argv;
{
   int   rc=0,rt=0;
   long  t=0, date_1010301=0;

   batchinit();

   strcpy(DBName,isNULLstr(argv[1]));
   strcpy(userid,isNULLstr(argv[2]));
   strcpy(option,isNULLstr(argv[3]));  /* 2:���N�I�O��, 4:���N�I�O�歫�e, 5:���N�I�O��簣 X:�������v��� */
   strcpy(datebgn,isNULLstr(argv[4]));
   strcpy(dateend,isNULLstr(argv[5]));
   strcpy(outputf,isNULLstr(argv[6]));
   
   if (datebgn[0]=='*' || datebgn[0] == '\0') 
      strcpy(datebgn,  "80/01/01");
   if (dateend[0]=='*' || dateend[0] == '\0') 
      strcpy(dateend,  "99/12/31");
     
   strcpy(dbgn1,cm_to_infdate(datebgn));
   strcpy(dend1,cm_to_infdate(dateend));

   printf("dbgn1[%s] dend1[%s]\n",dbgn1,dend1);
   
   $WHENEVER SQLERROR GOTO errexit;
   
   rstrdate( ONLINE_DATE, &online_date);
   rtoday( &today);

   online = today >=online_date ? TRUE:FALSE;

   errfpt = (FILE *) STARTLOG();   time(&tstart);

   rc=car9971_get_db();
   if (rc!=M_CM_OK)
      return rc;
    
   rt = getApHome(sApHome);
   if (rt < 0) {
        printf("read Config file error!!\n");
        return M_CM_READ_CONFIG_ERR;
   }   
   
   $CREATE TEMP TABLE CAR9971
   (
      Tipolicy	   char(20),
      Tfcard_class char(2),
      Tipolicy1	   char(14),
      Tilast_ply   char(14),
      Ticard	   char(21),
      Tdpolicy	   int,
      Ticar_type    char(3),
      Tiissue_ym    char(8),
      Tibrand	    char(8),
      Tipro_year    char(5),
      Tdply_begin   int,
      Tdply_end	    int,
      Tqply_period  int,
      Tmadjcom_prem int,
      Tmbusiness    int,
      Tfcomp_class  char(3),
      Tfcomp_class_last char(3), 
      Tibatch_no    int,
      Tibig_comp    char(2),
      Tchk_dpolicy  char(1)
   ) WITH NO LOG;
   
   $CREATE TEMP TABLE tmp_policy
   ( ipolicy char(20),
     icar_type char(3) ) WITH NO LOG;
   
   $CREATE TEMP TABLE del_50_policy
   ( ipolicy char(20) ) WITH NO LOG;
   
   if ( strcmp(option,"X") == 0 )
   {
      /* 1000413004_C1 �������v�� add by sylvia 1000502 */
      rc=car9971_ply_relation();
      EWRITE(userid,rc,strlog);
   }   
   else
      rc=car9971_ori_relation();
      
   if (rc!=M_CM_OK)
      return rc;

   
   t = cm_today();
   rstrdate( "03/01/2012", &date_1010301);

   printf(" ********** t=[%ld] date_1010301=[%ld] ***********\n", t,date_1010301);
   /*if (t >= date_1010301)*/
      rc=car9971_build_vol2();
   /*else
      rc=car9971_build_vol();*/
      
   /* rc=car9971_build_vol();   */
   if (rc!=M_CM_OK)
   {
      rgetmsg(rc, errlog, sizeof(errlog));
        
      sprintf_s(strlog, sizeof strlog,"%s\n\n\t\t     ",errlog);
        
      printf("option [%s]\n",option);
        
      if ( strcmp(option,"2") == 0 )
      {
   	   strcat(strlog," ISBP17_���N���I�O��s�@���� ");
      }
      else if (strcmp(option,"X") == 0)
      {
         strcat(strlog," �����O����v��ƭ��e���� ");
      }
      else if (strcmp(option,"4") == 0)
      {
         strcat(strlog," ���N���I�O�歫�e���� ");
      }
      else 
      {
         strcat(strlog,"���N���I�O��𰣭��e���� ");
      }
        
      printf("strlog[%s]\n",strlog); 
   	
   	EWRITE(userid,rc,strlog);
   	
   	exit(1);
   }
   
   time(&tend); 
   tused = difftime( tend, tstart);
   printf(" used time is [%f]\n",tused);
   
   exit(0);
   
errexit:
    printf("car9971vol-main:sqlcode=%d, sqlmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;   
   
}
/*--------------------------------------------------------------------*/

long car9971_get_db()
{
   $whenever sqlerror goto errexit;

   printf("userid[%s] DBName[%s]\n",userid,DBName);

   if (db_select(DBName) == FALSE) {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);

   return SQLCODE;
}

/*------------------------------------------------------------------*/

long car9971_ori_relation()
{
	
   int i=0;
   $char stmt_buf1[5000],stmt_buf2[3000];
   $char stmt_db[512],stmt_statement[1024];
      
   /* data from ori_ply_relation */
   $char Oipolicy[21],Ofcard_class[2],OsIpolicy1[15],Oilast_ply[21],Oicard[21];
   $char Oicar_type[3],Oiissue_ym[6],Oibrand[10],Oipro_year[5],Ofcomp_class[3];
   $char Ofcomp_class_last[3],Oibig_comp[2],Ochk_dpolicy[2],Odrate_ym[5];
   $long Odpolicy=0,Odply_begin=0,Odply_end=0,Omadjcom_prem=0,Ombusiness=0;
   $int Oqply_period=0, Oibatch_no=0;
   
   $long tmp_cnt=0;
   
   rtn = getCompanyId(companyid);
   
   for (i=0;i<count_db;i++)
   {
       	
      /* if option = 5, it has to join with table [ca_tmp_no] */
      strcpy(stmt_statement,"");
      strcpy(stmt_db,"");
      if( strcmp(option,"5") == 0 )
      {
         /*sprintf_s(stmt_db, sizeof stmt_db,", %s:ca_tmp_no b",list[i].dbname);*/
         strcpy(stmt_db,", ca_tmp_no b");
         strcpy(stmt_statement,"AND a.ipolicy = b.ipolicy");
      }
      /* End of statement */

      /* �O�T�I(�O��[6,7]=VW)���W�����T add by sylvia 100.12.08 (1001206018_C1) */
      sprintf_s(stmt_buf1, sizeof stmt_buf1,"SELECT a.ipolicy,fcard_class,a.ipolicy[1,13],ilast_ply[1,13],icard, "
                        "       dpolicy,icar_type,iissue_ym,ibrand,ipro_year,dply_begin, "
                        "       dply_end,qply_period,madjcom_prem,mbusiness,fcomp_class, "
                        "       fcomp_class_last, ibatch_no,ibig_comp ,"
                        "       CASE WHEN dpolicy < '08/01/2016' THEN 'Y' ELSE 'N' END,"
                        "       (select max(drate_ym) from %s:ori_ins_type where ipolicy = a.ipolicy)"
                        "  FROM %s:ori_ply_relation a %s"
                        " WHERE fcard_class = '2' and dpolicy >= '%s' AND dpolicy <= '%s' "
                        "   AND a.ipolicy[6,7] not in ('VW','EB','TV') %s",
                        list[i].dbname, list[i].dbname, stmt_db, dbgn1, dend1, stmt_statement);
                         
        
      printf("stmt_buf1[%s]\n",stmt_buf1);
        
      $PREPARE CUR_STMT1 FROM $stmt_buf1;
      $DECLARE scur_ply1 CURSOR FOR CUR_STMT1;
   	
   	$OPEN scur_ply1;
   	
   	while(1)
   	{
   		
         $FETCH scur_ply1 
   	     INTO $Oipolicy, $Ofcard_class, $OsIpolicy1, $Oilast_ply,$Oicard,
                $Odpolicy, $Oicar_type,   $Oiissue_ym, $Oibrand,   $Oipro_year,
                $Odply_begin,$Odply_end,  $Oqply_period,$Omadjcom_prem,$Ombusiness,
                $Ofcomp_class,$Ofcomp_class_last, $Oibatch_no,$Oibig_comp,$Ochk_dpolicy,$Odrate_ym;

         if (SQLCODE == SQLNOTFOUND) break;
   	     
   	     /*1040202006_C1 �s�W���ؤ���~�����²v�վ� */
   	     strcpy(Oicar_type,TRANS_CAR_TYPE(Oicar_type,Odrate_ym));
         printf("-- trace Oicar_type[%s]\n ",Oicar_type);
         
         $INSERT INTO CAR9971
         (
            Tipolicy, Tfcard_class, Tipolicy1, Tilast_ply, Ticard, Tdpolicy ,
            Ticar_type, Tiissue_ym, Tibrand, Tipro_year, Tdply_begin, Tdply_end ,
            Tqply_period, Tmadjcom_prem, Tmbusiness, Tfcomp_class, Tfcomp_class_last,
            Tibatch_no, Tibig_comp ,Tchk_dpolicy
         )
         VALUES
         (
            $Oipolicy, $Ofcard_class, $OsIpolicy1, $Oilast_ply,$Oicard,
            $Odpolicy, $Oicar_type,   $Oiissue_ym, $Oibrand,   $Oipro_year,
            $Odply_begin,$Odply_end,  $Oqply_period,$Omadjcom_prem,$Ombusiness,
            $Ofcomp_class,$Ofcomp_class_last, $Oibatch_no,$Oibig_comp ,$Ochk_dpolicy
         );
        
         /* �N���N�O���J�Ȧstable�� */
         if (Ofcard_class[0] == '2')
            $INSERT INTO tmp_policy (ipolicy, icar_type) VALUES ($Oipolicy,$Oicar_type);
      } /* end of while */                
        
      /* car9901111 �P�_�Y�O��l�O��ȩӫO50�I�خ�,�h�ӫO�椣�e���T */
      /* �N�ŦX��ӫO50�O���Jtemp table, �ñqTABLE CAR9971�R�� */
      sprintf_s(stmt_buf2, sizeof stmt_buf2,"insert into del_50_policy "
                        "select ipolicy from %s:ori_ins_type a "
                        "where ipolicy in (select ipolicy from tmp_policy) "
                        "  and iins_type = '50' "
                        "  and not exists (select 1 from %s:ori_ins_type b where a.ipolicy = b.ipolicy "
                        "  and a.iins_type <> b.iins_type)",list[i].dbname,list[i].dbname);
      printf("stmt2[%s]\n",stmt_buf2);                                               
                                             
      $PREPARE cur_tmp1 FROM  $stmt_buf2;
      $EXECUTE cur_tmp1;
      
      /* �P�_�Y�O����(01,02,32,34)�B���O(01,05,09,31,32,86,110,113,114)���@�I��,���e���T */
      /* �N�ŦX���O���Jtemp table, �ñqTABLE CAR9971�R�� */
      /* 107.08.20 �W�[�ǰe149�I�� */
      sprintf_s(stmt_buf2, sizeof stmt_buf2,"insert into del_50_policy "
                        "select ipolicy  from tmp_policy a "
                        " where icar_type in ('01','02','32','34') "
                        "   and ipolicy not in "
                        "        (select unique ipolicy from %s:ori_ins_type "
                        "          where ipolicy = a.ipolicy "
                        "            and iins_type in ('01','05','09','31','32','86','110','113','114','149', "
                        "                             '201','205','209','231','232','249','157','158','159','531','532'))",
                        list[i].dbname);
                        
      printf("stmt2����[%s]\n",stmt_buf2);                                               
                                             
      $PREPARE cur_tmp1 FROM  $stmt_buf2;
      $EXECUTE cur_tmp1;
        
      $SELECT count(*) INTO $tmp_cnt FROM CAR9971;
      printf("delete before 9971 count = [%d]\n",tmp_cnt);

      $DELETE FROM CAR9971 WHERE Tipolicy in (select ipolicy from del_50_policy);
               
      $SELECT count(*) INTO $tmp_cnt FROM CAR9971;
      printf("delete after 9971 count = [%d]\n",tmp_cnt); 

      $DELETE FROM del_50_policy WHERE 1=1;
      $DELETE FROM tmp_policy WHERE 1=1;                                         
   } /* end for loop */

   $CLOSE scur_ply1;
   $FREE  scur_ply1;                                	 
   
   return M_CM_OK;	
	
errexit:
    printf("car9971vol_ori_relation:code=%d, msg=%s\n",SQLCODE,sqlca.sqlerrm);
    $DROP TABLE CAR9971;
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;	
} /* end of get ori_ply_relation */

/*--------------------------------------------------------------------------*/
/* ��101/3/1�_�]���T�ǿ�榡�קﰱ��,��ϥ�car9971_build_vol2()  by sylvia 101.01.05
long car9971_build_vol() */


char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
   char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
   char sTmp_db_name[21];
   
   sTmp_db_name[0]='\0';

   if (*sIpolicy != '\0' && *sIpolicy !=' ')
   {
      sTmp_db_name[0]='\0';
      strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
      strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
               USE_BRANCH_ID));
      strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
   }
   return sTmp_db_name;
}

long check_if_exist( iply_type, dpolicy, fcard_class, trans_type )
$char *iply_type;
$int dpolicy;
$char *fcard_class;
$int trans_type;
{
   
   $long trade_count=0, err_count=0, out_count=0;
   
   printf("iply_type[%s] dpolicy[%d]\n",iply_type,dpolicy);
   printf("fcard_class[%s] trans_type[%d]\n",fcard_class,trans_type);
   
   
   $SELECT qtradevan, qerr, qout
      INTO $trade_count, $err_count, $out_count
      FROM ca_trade_exam 
     WHERE iply_type = $iply_type
       AND dpolicy = $dpolicy
       AND fcard_class = $fcard_class 
       AND itrans_type = $trans_type;
  
   if ( SQLCODE == SQLNOTFOUND )  return M_CM_OK;	
   
   printf("trade_count[%d] [%d] [%d]\n",trade_count,err_count,out_count);
   
   if ( trade_count==0 && err_count==0 && out_count==0 )
   {
       
       $DELETE FROM ca_trade_exam 
         WHERE iply_type = $iply_type
           AND dpolicy = $dpolicy
           AND fcard_class = $fcard_class 
           AND itrans_type = $trans_type;
           
        return M_CM_OK;	
   
   }
   
   strcpy(sqlca.sqlerrm ,"�L�k���J�s�C - �b UNIQUE INDEX ��즳���Э�");
   
   return 239;
   
errexit:
    printf("check_if_exist:sqlcode=%d, sqlmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    rc = SQLCODE;
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return rc;	
   
}

/* ------------------------------------------------------------------------- */
long car9971_ply_relation()
{
	
   int i;
   $char stmt_buf1[5000],stmt_buf2[3000];
   $char stmt_db[512],stmt_statement[1024];
      
   /* data from ori_ply_relation */
   $char Oipolicy[21],Ofcard_class[2],OsIpolicy1[15],Oilast_ply[21],Oicard[21];
   $char Oicar_type[3],Oiissue_ym[6],Oibrand[10],Oipro_year[5],Ofcomp_class[3];
   $char Ofcomp_class_last[3],Oibig_comp[2],Ochk_dpolicy[2],Odrate_ym[5];
   $long Odpolicy=0,Odply_begin=0,Odply_end=0,Omadjcom_prem=0,Ombusiness=0;
   $int Oqply_period=0, Oibatch_no=0;
   $long lDbgn_u=0, lDbgn_s=0, lDend_u=0, lDend_s=0;
   $char sDbgn_s[11], sDend_s[11];
   
   $long tmp_cnt=0;
   
   $WHENEVER SQLERROR GOTO errexit;
   
   /* �ˮ֩ҤU���_����O�_�W�L���� */
   
   lDbgn_u = cm_ymd_edate(datebgn);    /* �ϥΪ̿�J�_�� */
   lDend_u = cm_ymd_edate(dateend);    /* �ϥΪ̿�J�_�� */
   
   $select date(mdy(tcode_remark[1,2],tcode_remark[4,5],tcode_remark[7,10])),
           date(mdy(tcode_remark[1,2],tcode_remark[4,5],tcode_remark[7,10]))
      into $lDbgn_s, $sDbgn_s
      from cu_code_data
     where itype = 'CA' and icode = '01';
  
   
   $select date(mdy(tcode_remark[1,2],tcode_remark[4,5],tcode_remark[7,10])),
           date(mdy(tcode_remark[1,2],tcode_remark[4,5],tcode_remark[7,10]))  
      into $lDend_s, $sDend_s
      from cu_code_data
     where itype = 'CA' and icode = '03';
  
   printf("datebgn=[%s]lDbgn_u=[%ld]\n",datebgn,lDbgn_u);
   printf("dateend=[%s]lDend_u=[%ld]\n",dateend,lDend_u);
   printf("sDbgn_s=[%s]lDbgn_s=[%ld]\n",sDbgn_s,lDbgn_s);
   printf("sDend_s=[%s]lDend_s=[%ld]\n",sDend_s,lDend_s);
   
   if ((lDbgn_u < lDbgn_s) || (lDbgn_u > lDend_s))
   {
      sprintf_s(strlog, sizeof strlog,"���v�ɰ_�鶷���� %s ~ %s ����,�нT�{!", sDbgn_s, sDend_s);
      return 100;
   }
   
   if ((lDend_u > lDend_s) || (lDend_u < lDbgn_s))
   {
      sprintf_s(strlog, sizeof strlog,"���v�ɨ��鶷���� %s ~ %s ����,�нT�{!", sDbgn_s, sDend_s);
      return 100;
   }
     
   
   rtn = getCompanyId(companyid);
   
   for (i=0;i<count_db;i++)
   {
      sprintf_s(stmt_buf1, sizeof stmt_buf1,"SELECT a.ipolicy,fcard_class,a.ipolicy[1,13],ilast_ply[1,13],icard, "
                        "       dpolicy,icar_type,iissue_ym,ibrand,ipro_year,dply_begin, "
                        "       dply_end,qply_period,madjcom_prem,mbusiness,fcomp_class, "
                        "       fcomp_class_last, ibatch_no,ibig_comp ,"
                        "       CASE WHEN dpolicy < '08/01/2016' THEN 'Y' ELSE 'N' END,"
                        "       (select max(drate_ym) from %s:ply_ins_type where ipolicy = a.ipolicy)"
                        "  FROM %s:ply_relation a "
                        " WHERE fcard_class = '2' "
                        "   and icar_type in ('01','02','32','34') "
                        "   and dpolicy >= '%s' AND dpolicy <= '%s' "
                        "   and dply_close is not null "
                        "   and a.ipolicy[6,7] not in ('VW','EB','TV') "
                        "   and (select count(ipolicy) from %s:ply_ins_type "
                        "         where ipolicy = a.ipolicy "
                        "           and iins_type in ('01','05','09','31','32','86','110','113','114', "
                        "                             '201','205','209','231','232','157','158','159','531','532')) > 0 ",
                        list[i].dbname, list[i].dbname, dbgn1, dend1,list[i].dbname);
                         
        
      printf("stmt_buf1[%s]\n",stmt_buf1);
        
      $PREPARE CUR_STMT1 FROM $stmt_buf1;
      $DECLARE scur_plyx1 CURSOR FOR CUR_STMT1;
   	
   	$OPEN scur_plyx1;
   	
   	while(1)
   	{
   		
         $FETCH scur_plyx1 
   	     INTO $Oipolicy, $Ofcard_class, $OsIpolicy1, $Oilast_ply,$Oicard,
                $Odpolicy, $Oicar_type,   $Oiissue_ym, $Oibrand,   $Oipro_year,
                $Odply_begin,$Odply_end,  $Oqply_period,$Omadjcom_prem,$Ombusiness,
                $Ofcomp_class,$Ofcomp_class_last, $Oibatch_no,$Oibig_comp,$Ochk_dpolicy,$Odrate_ym;

         if (SQLCODE == SQLNOTFOUND) break;

   	     /*1040202006_C1 �s�W���ؤ���~�����²v�վ� */
   	     strcpy(Oicar_type,TRANS_CAR_TYPE(Oicar_type,Odrate_ym));
         printf("-- trace Oicar_type[%s]\n ",Oicar_type);
            	
         $INSERT INTO CAR9971
         (
            Tipolicy, Tfcard_class, Tipolicy1, Tilast_ply, Ticard, Tdpolicy ,
            Ticar_type, Tiissue_ym, Tibrand, Tipro_year, Tdply_begin, Tdply_end ,
            Tqply_period, Tmadjcom_prem, Tmbusiness, Tfcomp_class, Tfcomp_class_last,
            Tibatch_no, Tibig_comp, Tchk_dpolicy
         )
         VALUES
         (
            $Oipolicy, $Ofcard_class, $OsIpolicy1, $Oilast_ply,$Oicard,
            $Odpolicy, $Oicar_type,   $Oiissue_ym, $Oibrand,   $Oipro_year,
            $Odply_begin,$Odply_end,  $Oqply_period,$Omadjcom_prem,$Ombusiness,
            $Ofcomp_class,$Ofcomp_class_last, $Oibatch_no,$Oibig_comp,$Ochk_dpolicy
         );
        
         /* �N���N�O���J�Ȧstable�� */
         if (Ofcard_class[0] == '2')
            $INSERT INTO tmp_policy (ipolicy, icar_type) VALUES ($Oipolicy,$Oicar_type);
      } /* end of while */                
        
      
        
      $SELECT count(*) INTO $tmp_cnt FROM CAR9971;
      printf("delete before 9971 count = [%d]\n",tmp_cnt);

      $DELETE FROM CAR9971 WHERE Tipolicy in (select ipolicy from del_50_policy);
               
      $SELECT count(*) INTO $tmp_cnt FROM CAR9971;
      printf("delete after 9971 count = [%d]\n",tmp_cnt); 

      $DELETE FROM del_50_policy WHERE 1=1;
      $DELETE FROM tmp_policy WHERE 1=1;                                         
   } /* end for loop */

   $CLOSE scur_plyx1;
   $FREE  scur_plyx1;                                	 
   
   return M_CM_OK;	
	
errexit:
    printf("car9971vol_ply_relation:code=%d, msg=%s\n",SQLCODE,sqlca.sqlerrm);
    $DROP TABLE CAR9971;
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;	
} /* end of get ori_ply_relation */

/* ------------------------------------------------------------------------ */
long car9971_build_vol2()
{
	
   $char tstmt[500],stmt1[500],stmt_buf2[1024],stmt_buf3[1024],stmt[300];
   char  tmp_dbname[20], data_db1[21], data_db2[21];
   $char Tmp1[20],file0[51],iply_type[3],fcard_class[2];
   $char sIbrand_new[10];
   $date Today;
   int  rtncode,aa=0,b=0;
   long rc=0, year1=0,year2=0;
   int  cond=0,i=0;
   
   $char prem_subtot_c[13], iins_type_tradevan[7], iins_type[7], iins_type_rule[7];
   $char mdamage_c[13];
   $long date_1000901=0;

   rtoday(&Today);
   rstrdate( "09/01/2011", &date_1000901);
  
   rtn = getCompanyId(companyid);
         
   printf(" ************************** companyid[%s]\n",companyid);
   
   if (strcmp(option,"X") == 0 )
   {
      /* �ɾ��v���,�H�̷s�O�欰�� */
      strcpy(data_db1,"policy");
      strcpy(data_db2,"ply_ins_type");
   }
   else
   {
      /* ���`��ƶǰe,�H��l�O�欰�� */
      strcpy(data_db1,"original_ply");
      strcpy(data_db2,"ori_ins_type");
   }
   
   /* If option = 1,2,3, loop is only running once; if option = 4, loop is running 4 times */
   /* �]�{���w���I��(�j��,���N)�Υ\��(���e,���e,�簣���e)����, �G�����j����榸�� modify by sylvia 99.12.03 */
  
      cntrlrec = 0;
      sprintf_s(tstmt, sizeof tstmt,"SELECT * FROM CAR9971");
      
      strcat(tstmt," WHERE Tfcard_class = '2' ");
      
      /* 1000413004_C1 �����I�]�n�e���T�@mark by sylvia 100.05.02  */
      /* strcat(tstmt,"   AND Ticar_type not in ('01' , '02' , '32', '34') "); */
      
      strcat(tstmt," ORDER BY Tdpolicy, Tipolicy ");
   
      /*printf("tstmt[%s]\n",tstmt);*/
   
      $PREPARE CUR_TSTMT FROM $tstmt;
      $DECLARE scur_car997a CURSOR FOR CUR_TSTMT;
                    
      $OPEN scur_car997a;
      
      iFetch = TRUE;
      while(1)
      {  
         $FETCH scur_car997a 
           INTO $ipolicy, $fcard_class, $sIpolicy1, $ilast_ply,$icard,
                $dpolicy, $icar_type,   $iissue_ym, $ibrand,   $ipro_year,
                $dply_begin,$dply_end,  $qply_period,$madjcom_prem,$mbusiness,
                $fcomp_class,$fcomp_class_last, $ibatch_no,$ibig_comp,$chk_dpolicy;
            
         if (SQLCODE == SQLNOTFOUND) break;
     
         strcpy(tmp_dbname,get_car_full_db(ipolicy));
     
         /***** prepare cursor for select original_ply *****/
         sprintf_s(stmt_buf2, sizeof stmt_buf2,"SELECT %s %s FROM %s:%s %s",
                           "ilicense,to_char(dbirth,'%Y'), to_char(dbirth,'%m'), to_char(dbirth,'%d'),fsex,fmarriage,qcylinder::int,qpt,fpt,iengine,ibody,",
                           "itag,iassured,nassured,iply_area,fassured, to_char(dissue, '%Y'), to_char(dissue, '%m')",
                           tmp_dbname, data_db1,
                           "WHERE ipolicy=? ");

         $PREPARE CUR_STMT2 FROM $stmt_buf2;
         $DECLARE scur_policya CURSOR FOR CUR_STMT2;

         /***** prepare cursor for select ori_ins_type *****/
         sprintf_s(stmt_buf3, sizeof stmt_buf3,"SELECT %s %s FROM %s:%s %s ",
                           "iins_type,minjured_cover,mdeath_cover,",
                           "mdamage_cover,mdeduct,mins_premium,mprem,drate_ym",
                           tmp_dbname, data_db2, "WHERE ipolicy=? AND iins_type NOT IN ('171','172','173','174','175') ");
                          
         $PREPARE CUR_STMT3 FROM $stmt_buf3;
         $DECLARE scur_ply_ins_ax CURSOR FOR CUR_STMT3;
     
         $OPEN scur_policya USING $ipolicy;
         $FETCH scur_policya
           INTO $ilicense,$ibirth_yy,$ibirth_mm,$ibirth_dd,$fsex,$fmarriage,$qcylinder,$qpt:id1,$fpt,
                $iengine,$ibody,$itag,$iassured,$nassured,$iply_area,$fassured,$iissue_yy,$iissue_mm ;

         if (SQLCODE == SQLNOTFOUND)
         {
            $CLOSE scur_policya;
            continue;
         }
         
         $CLOSE scur_policya;
     
         if(id1 == -1)
            qpt = 0;

         if (strcmp(option,"4") == 0 || strcmp(option,"5") == 0)
         {
            sprintf_s(stmt_buf2, sizeof stmt_buf2,"SELECT itag FROM %s:policy WHERE ipolicy = '%s'", tmp_dbname, ipolicy);
         
            $PREPARE prep1 FROM $stmt_buf2;
            $EXECUTE prep1 INTO $itag;
            $FREE prep1;
         }

         if (iFetch)                 /*�Ĥ@�����W�@���O�ۤv*/
         {   
            strcpy(sPrePolicy,   ipolicy);
            strcpy(sPrePolicy1,  sIpolicy1);
            sDpolicy = dpolicy;
            iFetch = FALSE;
            prem_subtot = prem_subtot0 = mdeduct01 = prem_total = 0;          
            
            strcpy( dpolicy_c , cm_cdate_str_100( dpolicy ));         
            cm_split_ymd_100(dpolicy_c,day_yy,day_mm,day_dd);
          
            if ( strcmp(option,"2") == 0 )
            {
 
               sprintf_s(Tmp1, sizeof Tmp1,"ISBP%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
               strcpy(iply_type,"bp");
 
   	         strcpy(fcard_class, "2");
            }
            else if ( strcmp(option,"X") == 0 )
            {  printf("�������������������� option = X ���������������������� \n");

               /* ���v�ɥH�פ�鬰�ɦW */
               /*cm_char_split_3ymd(dateend,day_yy,day_mm,day_dd);

               sprintf_s(Tmp1, sizeof Tmp1,"ISBP%s_%s%s%sh",companyid,day_yy,day_mm,day_dd); */
               sprintf_s(Tmp1, sizeof Tmp1,"ISBP%s_%sh",companyid,day_yy);
               strcpy(iply_type,"bp");
 
   	         strcpy(fcard_class, "2");
   	         printf("-------------  Tmp1=[%s]\n",Tmp1);
            }
            else
            {
               if(online) sprintf_s(Tmp1, sizeof Tmp1,"ISBP%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
               else sprintf_s(Tmp1, sizeof Tmp1,"ISBP%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
            }
        
            sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);
            
            printf("[NOERROR] file0[%s] Tmp1[%s]\n",file0,Tmp1);
            fptr=fopen(file0,"w");
          
            if (strcmp(option,"4") != 0 || strcmp(option,"5") != 0 ) 
            {
               if (strcmp(option,"X") != 0) 
               {
                  rc = check_if_exist(iply_type,dpolicy,fcard_class,0);
                  printf("������������������������������������������������������������ \n");
                  printf("������������������������������������������������������������ \n");
                  printf("������������������������������������������������������������ \n");
                  printf("rc=[%ld]\n",rc);
                  if ( rc != M_CM_OK )
                  return rc;
               }
            }
         }
     
         /* ���v�ɥu���ͤ@���ɮ� */
         if ( strcmp(option,"X") == 0 )
         {
            printf("���������� sDpolicy=[%ld]year=[%s]\n",sDpolicy,cm_eyear_str(sDpolicy));
            printf("���������� dpolicy=[%ld]year=[%s]\n",dpolicy,cm_eyear_str(dpolicy));
            year1 = atol(cm_eyear_str(sDpolicy));
            year2 = atol(cm_eyear_str(dpolicy));
            printf("���������� year1 = [%ld]year2=[%ld]\n",year1,year2);
            if ( year1 != year2) /* �����ثefile , open a new file*/
            {    	printf("������������������������������������������������������������ \n");
               if (cntrlrec > 0)
               {
                  strcpy(prtstr, sformat_trade("CNTRLREC", 4, 8));
                  sprintf_s(cntrlrec_c, sizeof cntrlrec_c, "%ld", cntrlrec);
                  strcat(prtstr, sformat_trade(cntrlrec_c, 5, 6));
                  fprintf(fptr, "%s\n", prtstr);
               }
   
               printf("### cntrlrec=[%s]\n",cntrlrec_c);
       	
               fclose(fptr);         
               rtncode = rptftpinsert( userid , "car9971" , Tmp1 );
            
               sprintf_s(strlog, sizeof strlog,"���ɧ���:%s ���:%d",file0,cntrlrec);
               WRITELOG(errfpt , strlog);
               
               printf("errfpt[%s]\n",strlog);
               
               strcpy( dpolicy_c , cm_cdate_str_100( dpolicy ));
               
               cm_split_ymd_100(dpolicy_c,day_yy,day_mm,day_dd);
             
               
                  /* sprintf_s(Tmp1, sizeof Tmp1,"ISBP%s_%s%s%sh",companyid,day_yy,day_mm,day_dd); */
                  sprintf_s(Tmp1, sizeof Tmp1,"ISBP%s_%sh",companyid,day_yy);
                  strcpy(iply_type,"bp");
   
                  strcpy(fcard_class, "2");

           
               sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);
   
               printf("[002]file0[%s] Tmp1[%s]\n",file0,Tmp1);
               fptr=fopen(file0,"w");
            
               cntrlrec = 0;
               prem_total = 0;
            }
         }
         else
         {
            if ( sDpolicy != dpolicy ) /* �����ثefile , open a new file*/
            {    	
               if (cntrlrec > 0)
               {
                  strcpy(prtstr, sformat_trade("CNTRLREC", 4, 8));
                  
                  sprintf_s(cntrlrec_c, sizeof cntrlrec_c, "%ld", cntrlrec);
                  strcat(prtstr, sformat_trade(cntrlrec_c, 5, 6));
                  fprintf(fptr, "%s\n", prtstr);
               }
   
               printf("### cntrlrec=[%s]\n",cntrlrec_c);
       	
               fclose(fptr);         
               rtncode = rptftpinsert( userid , "car9971" , Tmp1 );
            
               if (strcmp(option,"4") != 0 && strcmp(option,"5") != 0)
               {
                  $insert into ca_trade_exam
                     (iply_type,dpolicy,fcard_class,itrans_type,
                      qcount,mamount,minjure,mcripple,mdeath)
                   values
                     ($iply_type,$sDpolicy,$fcard_class,0,
                      $cntrlrec,$prem_total,0,0,0);
               }
            
               sprintf_s(strlog, sizeof strlog,"���ɧ���:%s ���:%d",file0,cntrlrec);
               WRITELOG(errfpt , strlog);
               
               printf("errfpt[%s]\n",strlog);
               
               strcpy( dpolicy_c , cm_cdate_str_100( dpolicy ));
               
               cm_split_ymd_100(dpolicy_c,day_yy,day_mm,day_dd);
             
               if ( strcmp(option,"2") == 0 )
               {
                  sprintf_s(Tmp1, sizeof Tmp1,"ISBP%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
                  strcpy(iply_type,"bp");
   
                  strcpy(fcard_class, "2");
               }
               else 
               {
                  if(online) sprintf_s(Tmp1, sizeof Tmp1,"ISBP%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);            	    
                  else sprintf_s(Tmp1, sizeof Tmp1,"ISBP%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
               }
           
               sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);
   
               printf("[002]file0[%s] Tmp1[%s]\n",file0,Tmp1);
               fptr=fopen(file0,"w");
            
               if (strcmp(option,"4") != 0 && strcmp(option,"5") != 0)
               {
                  rc = check_if_exist(iply_type,dpolicy,fcard_class,0);
                  if ( rc != M_CM_OK )
                     return rc;
               }
               cntrlrec = 0;
               prem_total = 0;
            }
         }

         if (strcmp(sPrePolicy1, sIpolicy1) != 0 &&
            strlen(trim(sPrePolicy)) == CAR_PLY_TAG_LEN) /*�W�@���O�j�O��*/
         {     	
            
            /*�`�O�O��ƿ�*/
            /* ���N�I�����A�e�j�O���`�O�O��� mark by sylvia 101.03.14 (1010229003_C1) */
            /* strcpy(prtstr, trim(strcol6)); */                 /* �ƻs1-6����(C1-C70) */
            /* iTmpbuf = 0; */
            /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 4));  */  /* C71-74 */
            /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 6));  */  /* C75-80 */
            /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 4));  */  /* C81-84 */
            /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 8));  */  /* C85-92 */
            /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 20)); */  /* C93-112 */
            /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 20)); */  /* C113-132 */
            /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12)); */  /* C133-140 */
            /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 2));  */  /* C141-142 */
            /* strcat(prtstr, sformat_trade("0.0", 4, 7));          */  /* C143-148 */
            /* strcat(prtstr, sformat_trade("0.0", 4, 5));          */  /* C149-152 */
            /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 1));  */  /* C153-153 */
            /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 10)); */  /* C154-163 */
            /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 20)); */  /* C164-183 */
            /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 8));  */  /* C184-191 */
            /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 1));  */  /* C192-192 */
            /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 1));  */  /* C193-193 */
            /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 1));  */  /* C194-194 */
            /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 2));  */  /* C195-196 */
            /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 4));  */  /* C197-200 */
            /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 1));  */  /* C197-201 */
            /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 1));  */  /* C197-202 */
            /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 1));  */  /* C197-203 */
         
            /* 99�I�ظ�ƤΫO�O*/
            /* strcat(prtstr, sformat_trade("99      ",4, 6));       */  /*C204-209:�I��*/
            /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));  */  /* C210-217 */
            /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));  */  /* C218-225 */
            /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));  */  /* C226-233 */
   
            /* sprintf_s(prem_subtot_c, sizeof prem_subtot_c, "%ld", prem_subtot0);           */
            /* strcat(prtstr, sformat_trade(prem_subtot_c, 4, 12));   */  /*C234-245:�u�ݫ��`�O�O*/
            /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12));   */  /*C246-252:�ۭt�B */
            
            /* sprintf_s(mins_premium_c, sizeof mins_premium_c, "%ld", prem_subtot);           */
            /* strcat(prtstr, sformat_trade(mins_premium_c, 4, 12));  */  /*C253-261:�u�ݫe�`�O�O*/
            
            /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 6));    */  /*C262-267:�O�v��I�~�� */
            
            /* strcpy(strtmp, sformat_trade(tmp_yyyy, 2, 4));         */
            /* strcat(strtmp, sformat_trade(dply_mm, 2, 2));          */
            /* strcat(strtmp, sformat_trade(tmp_dd, 2, 2));           */
            /* strcat(prtstr, sformat_trade(strtmp, 4, 8));           */     /*C268-275:ñ��~���*/
   
            /* strcat(prtstr, sformat_trade("99", 5, 2));     */  /*C276-277:�F�d�I�إN�X*/
            
            /* cntrlrec++;                                    */
            /* fprintf(fptr, "%s\n", prtstr);                 */
         }
     
         if (strcmp(sPrePolicy1, sIpolicy1) != 0) 
            prem_subtot = prem_subtot0 = mdeduct01 = 0; 

         strcpy(sPrePolicy,      ipolicy);
         strcpy(sPrePolicy1,     sIpolicy1);
         sDpolicy = dpolicy;
         
         $OPEN scur_ply_ins_ax USING $ipolicy;

         if ((iRtnCode =
               split_policy(ipolicy, sTmpbuf, objno)) != M_CM_OK) break;
         printf("after split[%d]\n",iRtnCode);          

         while(1)
         {
            $FETCH scur_ply_ins_ax
              INTO $iins_type,$minjured_cover,$mdeath_cover,$mdamage_cover,
                   $mdeduct,$mins_premium,$mprem,$drate_ym;

            if (SQLCODE==SQLNOTFOUND) break;

            strcpy(prtstr, sformat_trade("9", 4, 1));           /*C1:���ʧO*/
            
            strcpy(strtmp, companyid);
            strcat(strtmp, sformat_trade(sTmpbuf, 2, 15));
            strcat(prtstr, sformat_trade(strtmp, 4, 17));      /*C2-C18*/
            
            /* if (fcard_class[0] == '1')
            {
               strcpy(card_str,companyid);
               strcat(card_str,icard);
               strcat(prtstr, sformat_trade(card_str, 2, 17));
            } 
            else 
            {
               card_str[0] = '\0';
               strcat(prtstr, sformat_trade(card_str, 2, 17));
            } */                                               /*C19-35:�O�I�����X(���e)*/

            if (strcmp(trim(ilast_ply),"" ) != 0)
            {
               /* strcat(prtstr, companyid);
               strcat(prtstr, sformat_trade(ilast_ply, 2, 15)); */
               strcpy(strtmp, companyid);
               strcat(strtmp, trim(ilast_ply));
               strcat(prtstr, sformat_trade(strtmp, 4, 17));  /* C36 - C52 */
            }
            else
               strcat(prtstr, sformat_trade(" ", 4, 17)); /* C36 - C52 */

            /* �N�{��u�a�ϥN�����v���R���N��42�u�x�����v�B�N��63�u�x�n���v�B�N��65�u�������v�C*/
            if( strcmp( iply_area, "42") == 0)
               strcpy( iply_area, "41");
            else if( strcmp( iply_area, "63") == 0)
               strcpy( iply_area, "62");
            else if( strcmp( iply_area, "65") == 0)
               strcpy( iply_area, "64");

            strcat(prtstr, sformat_trade(iply_area, 4, 2));  /* C53 - C54 */

            strcpy(dply_begin_c, cm_cdate_str_100(dply_begin));
            cm_split_ymd_100(dply_begin_c,dply_begin_yy,dply_begin_mm,dply_begin_dd);
            strcpy(tmp_yyyy, itoa(1911+atoi(dply_begin_yy)));
            
            strcpy(strtmp, sformat_trade(tmp_yyyy, 2, 4));
            strcat(strtmp, sformat_trade(dply_begin_mm, 2, 2));
            strcat(strtmp, sformat_trade(dply_begin_dd, 2, 2));
            strcat(prtstr, sformat_trade(strtmp, 4, 8));    /*C55-62:�O��_��*/

            strcpy(dply_end_c,cm_cdate_str_100(dply_end));
            cm_split_ymd_100(dply_end_c,dply_end_yy,dply_end_mm,dply_end_dd);
            strcpy(tmp_yyyy,itoa(1911+atoi(dply_end_yy)));
            strcpy(strtmp, sformat_trade(tmp_yyyy, 2, 4));
            strcat(strtmp, sformat_trade(dply_end_mm, 2, 2));
            strcat(strtmp, sformat_trade(dply_end_dd, 2, 2));
            strcat(prtstr, sformat_trade(strtmp, 4, 8));    /*C63-70:�O�樴��*/
            
            strcpy(strcol6, prtstr);            /* �ƥ�1-6��(C1-70)�Ѥj�O��ϥ� */

            if (strlen(trim(objno)) > 0) 
            {
               strcpy(strtmp, sformat_trade(objno, 2, 4));
               strcat(prtstr, sformat_trade(strtmp, 4, 4));    /*C71-74:�O��Ъ���*/
            }
            else strcat(prtstr, sformat_trade("0001", 4, 4));  /*C71-74:�O��Ъ���*/


            /*�o�Ӧ~���Τ�����,��iissue_ym�o������,�諾����original_ply.dissure�����쪺�~�� */
            strcpy(strtmp, sformat_trade(iissue_yy, 2, 4));
            strcat(strtmp, sformat_trade(iissue_mm, 2, 2));
            if (strcmp(trim(iins_type), "157")==0 || strcmp(trim(iins_type), "158")==0 || strcmp(trim(iins_type), "159")==0)
            strcat(prtstr, sformat_trade("000000", 4, 6));
            else
            strcat(prtstr, sformat_trade(strtmp, 4, 6));       /*C75-80:�o�Ӧ~��*/
            
            
            if (strcmp(trim(iins_type), "157")==0 || strcmp(trim(iins_type), "158")==0 || strcmp(trim(iins_type), "159")==0)
            strcat(prtstr, sformat_trade("0000", 4, 4));
            else
            strcat(prtstr, sformat_trade(ipro_year, 4, 4));    /*C81-84:�o�Ӧ~��*/
            
            
            /* �t�P�����N���ഫ modify by sylvia 100.09.30 (car9812112_C1) ----- */
           sIbrand_new[0] = '\0';
           $select first 1 ibrand_new into $sIbrand_new
              from ca_car_model
             where ibrand = $ibrand
               and ibrand_new <> ' '
             order by drate desc;
           
           if (sIbrand_new[0] != '\0')
               strcpy(ibrand, sIbrand_new);
         /* ------------------------------------------------------------------ */ 
         	if (strcmp(trim(iins_type), "157")==0 || strcmp(trim(iins_type), "158")==0 || strcmp(trim(iins_type), "159")==0)
         		strcat(prtstr, sformat_trade("00000000", 4, 8));
         	else 
            	strcat(prtstr, sformat_trade(ibrand, 4, 8));    /* C85-92 */
            
            strcat(prtstr, sformat_trade(iengine, 4, 25));  /* C93-112 */
            strcat(prtstr, sformat_trade(ibody, 4, 25));    /* C113-132 */
            
            /* 1061102009_C1 �ק�ǰe���T27���ؾ��񨮵P�W�h
            if (strcmp(icar_type,"27") == 0 && strcmp(chk_dpolicy,"Y") == 0)
                  strcpy(itag, " ");  */                      /* ����27,���P���X�M�� modify by sylvia 101.02.24 (1001005007_C1) */
                  
            strcat(prtstr, sformat_trade(itag, 4, 12));     /* C133-140 */

			/*1110216005_SC2_�t�X�N�ɫO�ӫ~�վ�CAR401�B�q�l�O���E�O���t��*/
			/*if (strcmp(trim(iins_type), "157")==0 || strcmp(trim(iins_type), "158")==0 || strcmp(trim(iins_type), "159")==0)
				strcat(prtstr, sformat_trade("03", 4, 2));
			else*/
            strcat(prtstr, sformat_trade(icar_type, 4, 2)); /*C141-142:���إN��*/
            
            /* iTmpbuf = 10 * qcylinder;*/
            sprintf_s(strtmp, sizeof strtmp, "%.1f", (double)qcylinder);
            strcat(prtstr, sformat_trade(strtmp, 4, 7));    /*C143-148:�Ʈ�q*/
            
            /* iTmpbuf =  10 * qpt; */
            sprintf_s(strtmp, sizeof strtmp, "%.1f", qpt);
            strcat(prtstr, sformat_trade(strtmp, 4, 5));    /*C149-152:�����ƶq*/
            
            if (strcmp(trim(iins_type), "157")==0 || strcmp(trim(iins_type), "158")==0 || strcmp(trim(iins_type), "159")==0)
            	strcat(prtstr, sformat_trade("0", 4, 1));
            else
            	strcat(prtstr, sformat_trade(fpt, 4, 1));       /*C153-153:�������*/

            strcat(prtstr, sformat_trade(iassured, 4, 10)); /*C154-163:������*/
            
            nassured_len = cc_split_chinese(nassured,nassured_1,20);
            strcpy(nassured_1, rtrim(nassured_1));
            /* nassured[20] = '\0'; */
            strcat(prtstr, sformat_trade(nassured_1, 4, 20)); /*C164-183*/

            /*��Q�O�I�H�ͤ�b��Ʈw�̬Ocahr(6),�ӫO���X�W�Q�O�I�H�ͤ������,�諾�����褸�~���,���ݦA�ഫ */
            strcpy(strtmp, sformat_trade(ibirth_yy, 2, 4));
            strcat(strtmp, sformat_trade(ibirth_mm, 2, 2));
            strcat(strtmp, sformat_trade(ibirth_dd, 2, 2));
            strcat(prtstr, sformat_trade(strtmp, 4, 8));    /*C184-191*/
            
            strcat(prtstr, sformat_trade(fsex, 4, 1));      /*C192-192*/
            strcat(prtstr, sformat_trade(fmarriage, 4, 1)); /*C193-193*/

            if (fassured[0]=='1')
            {
               strcpy(strtmp,"1");
            }  
            else if(fassured[0]=='2')
            {
               strcpy(strtmp,"3");
            }  
            else if(fassured[0]=='3')
            {
               strcpy(strtmp,"2");
            }  
            else if(fassured[0]=='4')
            {
               strcpy(strtmp,"9");
            }  
            else if(fassured[0]=='5')
            {
               strcpy(strtmp,"8");
            }  
            else if(fassured[0]=='6')
            {
               strcpy(strtmp,"9");
            } 
            else strcpy(strtmp, " ");
            strcat(prtstr, sformat_trade(strtmp, 4, 1)); /*C194-194:�۵M�H/�k�H�O*/

            iTmpbuf = atoi(fcomp_class);
            strcpy(strtmp, sformat_trade(&iTmpbuf, 1, 2));
            strcat(prtstr, sformat_trade(strtmp, 4, 2)); /*C195-196:�����ż�*/
            
            strcat(prtstr, sformat_trade("    ", 4, 4)); /*C197-200:blank*/

            if (strcmp(trim(iins_type), "01")==0 ||
                strcmp(trim(iins_type), "05")==0 ||
                strcmp(trim(iins_type), "08")==0 ||
                strcmp(trim(iins_type), "09")==0 ||
                strcmp(trim(iins_type), "201")==0 ||
                strcmp(trim(iins_type), "205")==0 ||
                strcmp(trim(iins_type), "209")==0)
            {
               ipdmg_align=ipdmg_align*(-1);

               $SELECT icode INTO $icode FROM alignment
                 WHERE fclass='4' AND palign=$ipdmg_align;
               
               if (SQLCODE==SQLNOTFOUND) strcat(prtstr, sformat_trade("0", 4, 1));   /*C201:����h�����u��*/
               else strcat(prtstr, sformat_trade(icode,4,1));
            } 
            else strcat(prtstr, sformat_trade("0",4,1));

            if (strcmp(trim(iins_type), "11")==0 || strcmp(trim(iins_type), "211")==0) /* fix:2025.06 */
            {
               ipbrg_align=ipbrg_align*(-1);

               $SELECT icode INTO $icode FROM alignment
                 WHERE fclass='4' AND palign=$ipbrg_align;
  
               if (SQLCODE==SQLNOTFOUND) strcat(prtstr, sformat_trade("0", 4, 1));  /*C202:�ѵs�h�����u��*/
               else strcat(prtstr, sformat_trade(icode, 4, 1));
            } else strcat(prtstr, sformat_trade("0", 4, 1));

            if (strcmp(trim(iins_type), "31")==0 || strcmp(trim(iins_type), "32")==0 || strcmp(trim(iins_type), "231")==0 || strcmp(trim(iins_type), "232")==0)
            {
               iplia_align=iplia_align*(-1);
               
               $SELECT icode INTO $icode FROM alignment
                 WHERE fclass='4' AND palign=$iplia_align;
               
               if (SQLCODE==SQLNOTFOUND) strcat(prtstr, sformat_trade("0", 4, 1));  /*C203:�d���h�����u��*/
               else strcat(prtstr, sformat_trade(icode, 4, 1));
            } else strcat(prtstr, sformat_trade("0",4,1));


            /*�C���I�ظ�ƤΫO�O*/
               
            if (iins_type[0] == '\0')
            {  
                strcat(prtstr, sformat_trade("000000",4,6));   /* C204-209 */
            }
            else
            { 
             strcpy(iins_type_rule," ");
             strcpy(iins_type_tradevan," ");
             $SELECT iins_type_rule, iins_type_tradevan
               INTO $iins_type_rule, $iins_type_tradevan
               FROM insurance_type
              WHERE iins_type = $iins_type;

              if (SQLCODE == SQLNOTFOUND)
              {
                  strcpy(iins_type_rule,iins_type);
              }
              else
              {
                  if (strlen(trim(iins_type_rule)) == 0)
                      strcpy(iins_type_rule,iins_type);
              }
              if((strcmp(fcard_class,"2")==0) && (strcmp(trim(iins_type_rule),"21")==0))
                {  strcpy(iins_type_rule,"23    ");  }

             if ( dpolicy < date_1000901) /* ñ���< 09/01/2011�A�ǰeinsurance_type.iins_type_rule */
             {
                 puts("ñ���<09/01/2011");
                 if( strcmp( trim(iins_type_rule), "15") == 0 ||
                     strcmp( trim(iins_type_rule), "16") == 0)
                     strcat(prtstr, sformat_trade(iins_type, 4,6));                     /*C204-209:�����I�إN�X*/
                 else
                     strcat(prtstr, sformat_trade(iins_type_rule, 4, 6));  /*C204-209:�����I�إN�X*/
             }
             else
             {
                 puts("ñ���>=09/01/2011");
                 strcat(prtstr, sformat_trade(iins_type, 4, 6));  /*C204-209:�����I�إN�X*/
             }

            }

         /* rfmtlong(minjured_cover,"&&&&&&&&",minjured_c); */
         sprintf_s(minjured_c, sizeof minjured_c, "%ld", minjured_cover);
         strcat(prtstr, sformat_trade(minjured_c, 4, 12));   /*C210-217:��˫O�B*/

         /* rfmtlong(mdeath_cover,"&&&&&&&&",mdeath_c); */
         sprintf_s(mdeath_c, sizeof mdeath_c, "%ld", mdeath_cover);
         strcat(prtstr, sformat_trade(mdeath_c, 4, 12));    /*C218-225:�ݼo�O�B*/

         /* rfmtlong(mdeath_cover,"&&&&&&&&",mdeath_c); */
         sprintf_s(mdeath_c, sizeof mdeath_c, "%ld", mdeath_cover);
         strcat(prtstr,sformat_trade(mdeath_c, 4, 12));     /*C226-233:���`�O�B*/

         /* rfmtlong(mdamage_cover,"&&&&&&&&&&&&",mdamage_c); */
         sprintf_s(mdamage_c, sizeof mdamage_c, "%ld", mdamage_cover);
         strcat(prtstr, sformat_trade(mdamage_c, 4, 12));   /*C234-245:�O�B*/

         if(strcmp(trim(iins_type), "71")==0 || strcmp(trim(iins_type), "72")==0)
               mdeduct = 10000;
         else if(strcmp(trim(iins_type), "02") == 0)
               mdeduct = 0;
         else if(strcmp(trim(iins_type), "01")==0 ||
                 strcmp(trim(iins_type), "05")==0 ||
                 strcmp(trim(iins_type), "08")==0 ||
                 strcmp(trim(iins_type), "201")==0 ||
                 strcmp(trim(iins_type), "205")==0 )
               mdeduct01 = mdeduct;
         else if(strcmp(trim(iins_type), "13")==0)
               mdeduct = mdeduct01;
         else if(strcmp(trim(iins_type), "21")==0)
               mdeduct = 0;

         /* rfmtlong(mdeduct,"&&&&&&&",mdeduct_c); */
         sprintf_s(mdeduct_c, sizeof mdeduct_c, "%ld", mdeduct);
         strcat(prtstr, sformat_trade(mdeduct_c, 4, 12));         /*C246-252:�ۭt�B*/

         /* rfmtlong(mins_premium,"&&&&&&&&&",mins_premium_c); */
         sprintf_s(mins_premium_c, sizeof mins_premium_c, "%ld", mins_premium);
         strcat(prtstr, sformat_trade(mins_premium_c, 4, 12));    /*C253-261:�u�ݫ�O�O*/

            prem_subtot0 += mins_premium;              /*�u�ݫ�O�O*/
            prem_total += mins_premium;              /*�`�O�O*/
            
            prem_subtot += mprem;                      /*�u�ݫe�O�O*/

            $SELECT drate INTO $drate
               FROM ca_rate_date
              WHERE icode=$drate_ym
                AND itable='cover_vs_premium';

            if (SQLCODE == SQLNOTFOUND || drate[0] == '\0')
            {
               sprintf_s(errmsg, sizeof errmsg,"drate_ym[%s] not found in rate\n",drate_ym);
               fprintf(errfpt,"%s\n",errmsg);
               continue;
            }

            strcpy(drate_c,cm_from_infdate(drate));
            cm_split_ymd_100(drate_c,drate_yy,drate_mm,drate_dd);
            
            if (drate_yy[0] == '\0') strcpy(strtmp,"0000");
            else 
            {
               yy_long=1911+atoi(drate_yy);
               strcpy(tmp_yyyy,itoa(yy_long));
               strcpy(strtmp,tmp_yyyy);  /*�褸�~*/
            }

            if (drate_mm[0] == '\0') strcat(strtmp,"00");
            else strcat(strtmp,drate_mm);           
            
            strcat(prtstr, sformat_trade(strtmp, 4, 6)); /*C262-267:�O�v�~��*/ 

            strcpy(dpolicy_c,cm_cdate_str_100(dpolicy));
            cm_split_ymd_100(dpolicy_c,dply_yy,dply_mm,tmp_dd);

            if(dply_yy[0] == '\0') strcpy(strtmp,"0000");
            else
            {
               yy_long=1911+atoi(dply_yy);
               strcpy(tmp_yyyy,itoa(yy_long));
               strcpy(strtmp,tmp_yyyy);  /*�褸�~*/
            }
            
            if(dply_mm[0] == '\0') strcat(strtmp,"00");
            else strcat(strtmp,dply_mm);

            if(tmp_dd[0] == '\0') strcat(strtmp,"00");
            else strcat(strtmp,tmp_dd);             
            strcat(prtstr, sformat_trade(strtmp, 4, 8)); /*C268-275:ñ��~���*/ 
            
            iins_type_tradevan[2] = '\0';
            strcat(prtstr, sformat_trade(iins_type_tradevan, 5, 2));      /*C276-277:�F�d�I�إN�X2�X */
            fprintf(fptr, "%s\n", prtstr);
            cntrlrec++;

         }/* end of while that FETCH scur_ply_ins_ax */	
    
         sprintf_s(stmt, sizeof stmt,"%s %s %s" ,
                      "UPDATE compulsory_card ",
                      "   SET dtrans = ? ",
                      " WHERE icard  = ?");
         printf("SQL stmt----->[%s]\n",stmt);
         $PREPARE stmt1 FROM  $stmt;
         $EXECUTE stmt1 USING $Today,$icard; 
   	
      }  /* end of while that FETCH scur_car997a */
   
   
      if (cntrlrec > 0 && strlen(trim(sPrePolicy)) == CAR_PLY_TAG_LEN) 
                                                        /*DB���̫�@���O�j�O��*/
      {    
        /*�`�O�O��ƿ�*/
        /* ���N�I�����A�e�j�O���`�O�O��� mark by sylvia 101.03.14 (1010229003_C1) */   
        /* strcpy(prtstr, trim(strcol6));  */                /* �ƻs1-6����(C1-C70) */
        /* iTmpbuf = 0; */

        /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 4));  */    /* C71-74 */
        /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 6));  */    /* C75-80 */
        /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 4));  */    /* C81-84 */
        /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 8));  */    /* C85-92 */
        /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 20)); */    /* C93-112 */
        /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 20)); */    /* C113-132 */
        /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12)); */    /* C133-140 */
        /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 2));  */    /* C141-142 */
        /* strcat(prtstr, sformat_trade("0.0", 4, 7));          */    /* C143-148 */
        /* strcat(prtstr, sformat_trade("0.0", 4, 5));          */    /* C149-152 */
        /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 1));  */    /* C153-153 */
        /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 10)); */    /* C154-163 */
        /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 20)); */    /* C164-183 */
        /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 8));  */    /* C184-191 */
        /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 1));  */    /* C192-192 */
        /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 1));  */    /* C193-193 */
        /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 1));  */    /* C194-194 */
        /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 2));  */    /* C195-196 */
        /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 4));  */    /* C197-200 */
        /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 1));  */    /* C197-201 */
        /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 1));  */    /* C197-202 */
        /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 1));  */    /* C197-203 */

        /*99�I�ظ�ƤΫO�O*/
        /* strcat(prtstr, sformat_trade("99    ", 4, 6));       */    /*C204-209:�I��*/
        
        /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12)); */    /* C210-217 */
        /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12)); */    /* C218-225 */
        /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12)); */    /* C226-233 */
        
        /* sprintf_s(prem_subtot_c, sizeof prem_subtot_c, "%ld", prem_subtot0);         */
        /* strcat(prtstr, sformat_trade(prem_subtot_c, 4, 12)); */    /*C234-245:�u�ݫ��`�O�O*/
        /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 12)); */    /*C246-252:�ۭt�B */
        
        /* sprintf_s(mins_premium_c, sizeof mins_premium_c, "%ld", prem_subtot);         */
        /* strcat(prtstr, sformat_trade(mins_premium_c, 4, 12));*/    /*C253-261:�u�ݫe�`�O�O*/
        
        /* strcat(prtstr, sformat_trade(itoa(iTmpbuf), 4, 6));  */    /*C262-267:�O�v��I�~�� */
        
        /* strcpy(strtmp, sformat_trade(tmp_yyyy, 2, 4));       */
        /* strcat(strtmp, sformat_trade(dply_mm, 2, 2));        */
        /* strcat(strtmp, sformat_trade(tmp_dd, 2, 2));         */
        /* strcat(prtstr, sformat_trade(strtmp, 4, 8));         */    /*C268-275:ñ��~���*/
        /* strcat(prtstr, sformat_trade("99", 5, 2));           */    /*C276-277:�F�d�I�إN�X*/
        
        /* cntrlrec++;                                          */
        /* fprintf(fptr, "%s\n", prtstr);                       */
         
         prem_subtot = prem_subtot0 = mdeduct01 = 0;

      }
 
      $CLOSE scur_car997a;
      $FREE  scur_car997a;
   
      if (cntrlrec > 0)
      {
         strcpy(prtstr, sformat_trade("CNTRLREC", 4, 8));
         sprintf_s(cntrlrec_c, sizeof cntrlrec_c, "%ld", cntrlrec);
         strcat(prtstr, sformat_trade(cntrlrec_c, 5, 6));
         fprintf(fptr, "%s\n", prtstr);
      }
      else if ( cntrlrec == 0 )
      {
         rstrdate( dbgn1 , &dpolicy);
         
         strcpy( dpolicy_c , cm_cdate_str_100( dpolicy ));
         
         cm_split_ymd_100(dpolicy_c,day_yy,day_mm,day_dd);
          
         if ( strcmp(option,"2") == 0 )
         {
            sprintf_s(Tmp1, sizeof Tmp1,"ISBP%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
            strcpy(iply_type,"bp");

            strcpy(fcard_class, "2");
         }
         else if ( strcmp(option,"X") == 0 )
         {
            printf("##############################################\n");
            
            /* ���v�ɥH�פ�鬰�ɦW */
            /* cm_char_split_3ymd(dateend,day_yy,day_mm,day_dd);

            sprintf_s(Tmp1, sizeof Tmp1,"ISBP%s_%s%s%sh",companyid,day_yy,day_mm,day_dd); */
            sprintf_s(Tmp1, sizeof Tmp1,"ISBP%s_%sh",companyid,day_yy);
            strcpy(iply_type,"bp");

            strcpy(fcard_class, "2");
         }
         else
         {
            if(online) sprintf_s(Tmp1, sizeof Tmp1,"ISBP%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
            else sprintf_s(Tmp1, sizeof Tmp1,"ISBP%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
         }
        
         sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);
         
         printf("[NODATA] file0[%s] Tmp1[%s]\n",file0,Tmp1);
         fptr=fopen(file0,"w");
         
         strcpy(prtstr, sformat_trade("CNTRLREC", 4, 8));
         
         strcat(prtstr, sformat_trade("0", 5, 6));
         fprintf(fptr, "%s\n", prtstr);
         
         cntrlrec = prem_total = 0;
   	 	
      }

      printf("### cntrlrec=[%s]\n",cntrlrec_c);  	
      
      fclose(fptr);
      
      rtncode = rptftpinsert( userid , "car9971" , Tmp1 );
      
      printf("qcount[%d] dpolicy[%d]\n",qcount,dpolicy);
     
      if (strcmp(option,"4") != 0 && strcmp(option,"5") != 0 )
      {
         if ( strcmp(option,"X") != 0 )
         {
            $insert into ca_trade_exam
               (iply_type,dpolicy,fcard_class,itrans_type,
                qcount,mamount,minjure,mcripple,mdeath)
             values
               ($iply_type,$dpolicy,$fcard_class,0,
                $cntrlrec,$prem_total,0,0,0);
         }
      }
     
      sprintf_s(strlog, sizeof strlog,"���ɧ���:%s ���:%d",file0,cntrlrec);
      WRITELOG(errfpt , strlog);
      
      printf("errfpt[%s]\n",strlog);

   if (errfpt!=NULL) ENDLOG(errfpt); 
   
   return M_CM_OK;	
	
errexit:
    printf("car9971vol:sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    rc = SQLCODE;
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return rc;	
	
}
