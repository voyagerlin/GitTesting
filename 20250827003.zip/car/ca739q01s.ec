/**********************************************************************/
/*   program id   : ca739q01s.ec                                      */
/*   program name : �q�l�O��έp��                   		          */
/*   date written : 2018/08/30 by 071004                              */
/*   files        :                                                   */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <decimal.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "globdata.h"
#include "safeclib.h"

$char dbgn[11],dbgn2[11];
$char dend[11],dend2[11];
$char iquota_in[4];


int   count_db,k; 
char  outputf[21];
$char userid[11];
$char DBName[05];
$char FormTp[03];
$char msgbuf[128];
int   max_count;
$char    v_sIpolicy[20],v_icreate[10],  v_sMsg[100];


DBinfo *list;

char *get_car_full_db();
/*********************************************************************/
main(argc, argv)
int argc;
char **argv;
{
 	int rc;

	batchinit();
	strcpy(DBName,         isNULLstr(argv[1]));
	strcpy(userid,         isNULLstr(argv[2]));
	strcpy(dbgn,           isNULLstr(argv[3]));
	strcpy(dend,           isNULLstr(argv[4]));
	strcpy(iquota_in,      isNULLstr(argv[5]));
	strcpy(outputf,        isNULLstr(argv[6]));
	
	strcpy(dbgn2, cm_to_infdate(dbgn));
   	strcpy(dend2, cm_to_infdate(dend));

	rc = car739_get_db();
	if (rc != M_CM_OK)
		return rc;

	rc = car739_prepare_data();
	if (rc != M_CM_OK)
		return rc;
 
	rc = car739_build();
	if (rc != M_CM_OK) 
		return rc;

}
/*----------------------------------------------------------------------------*/
long car739_get_db()
{
	$whenever sqlerror goto errexit;

	if (db_select(DBName) == FALSE) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car739_build()
{ 
	int rc;
	char sfilename[256],stitle[2048],stmt[6000];
	$WHENEVER SQLERROR GOTO errexit;

	strcpy(sfilename,"�q�l�O��έp��[car739]");	
	sprintf_s(stitle, sizeof stitle,"�C�L�϶�:%s~%s\t",dbgn,dend);
	strcat(stitle,"\n");
	strcat(stitle,"\t�X����\t�O�渹\t�q�l�O��email\t�q�l�O�������X\t�g��N��\t�g��W��\t�q���N��\t�q���W��\t");
	strcat(stitle,"�޲z�H�W��\t�޲z�H�N��\t���\t���W��\tñ���\t�H�e�ɶ�\tñ��~��\t�g����ݤ�����\t�Ұ�\t�q�lñ�p\t�q�lñ�p���y�Ǹ�\t");
	strcat(stitle,"��O�渹\t��O�渹�̷s�O�檺�q�l�O����O\t�O�_���ɵo����\t�O�_��������\t");
	
	strcpy(stmt,"SELECT ''''||a.ipolicy_1_3, a.ipolicy, a.femail_eply, a.fmobile_eply, ''''||a.iofficer, a.nofficer, a.iroute, a.nroute, a.nleader, ''''||a.ileader, "
	            "       a.iquota, a.nbranch, a.dpolicy, a.demail, a.dpolicy_ym, a.nchi_abv, "
	            "       DECODE(b.ncode,'�q��','�q�ӳ�', "
	            "                      '�`��','�x�_�`���q', "
	            "                      '��˭]��','�������q', "
	            "                      '��o��','��o��', "
	            "                      '�_�G��','�s�_�����q', "
	            "                      '����','�x�_�`���q', "
	            "                      '�_�@��','�_�@��', "
	            "                      '�������','�x�������q', "
	            "                      '���ūn��','�x�n�����q', "
	            "                      '����̰�','���������q'), "
	            "       a.fesign, a.iscan_no, "
	            "       a.ilast_ply, a.flast_eply, "
	            "       CASE WHEN a.cnt_307 > 0 THEN 'Y' ELSE ' ' END, "
	            "       CASE WHEN a.cnt_iedr > 0 THEN 'Y' ELSE ' ' END "
	   	        "  FROM CAR739 a,cu_code_data b "
	   	        " WHERE a.icode = b.icode AND b.itype = '19' ");
	printf("stmt[%s] \n",stmt);
	rc = unload_file(outputf," ",sfilename,stitle,stmt);
	
	if (rc != SUCCESS) 
	{
	    sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
	    EWRITE(userid, rc , msgbuf);
	    return rc;
	}
	
	$DROP TABLE CAR739;

	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	return SQLCODE;   
   
}
/*----------------------------------------------------------------------------*/
long car739_prepare_data()
{
   
	$char stmt1[6000],stmt2[1024];
	$char swhere[100];
	$char sFullName[21];
   
	$char ipolicy_1_3[4],ipolicy[21],femail_send[2],fsms_mobile[2],iofficer[11],nofficer[11],iruote[21],nroute[41],nleader[11],ileader[11],iquota[21],nbranch[41],dpolicy[11];
	$char dpolicy_ym[8],demail[11],fesign[1],iscan_no[26],nchi_abv[13],icode[4],ilast_ply[21],flast_eply[2];
	$int  cnt_307,cnt_iedr;
	$WHENEVER SQLERROR GOTO errexit;

	$CREATE TEMP TABLE CAR739
    ( 
		ipolicy_1_3      char(3), 
		ipolicy          char(20),
		femail_eply      char(1),
		fmobile_eply     char(1),      
		iofficer         char(10),
		nofficer         char(10),
		iroute           char(20),
		nroute           char(40),
		nleader          char(10),
		ileader          char(10),
		iquota           char(20),
		nbranch          char(40),
		dpolicy          char(10),
		dpolicy_ym       char(7), 
		demail           char(10),
		fesign           char(1),
		iscan_no         char(25),
		nchi_abv         char(12),
		icode            char(3),
		ilast_ply        char(20),
		flast_eply       char(1),
		cnt_307          int,
		cnt_iedr         int
    ) WITH NO LOG;
    
    $CREATE INDEX CAR739_IND1 ON CAR739(icode);

	if(iquota_in[0]!='*')
	{
		sprintf_s(swhere, sizeof swhere, " AND a.ipolicy[1,3] = '%s' ",trim(iquota_in));
	}  
	else
	{
		sprintf_s(swhere, sizeof swhere, "  ");
	}
	
	for(k=0;k<count_db;k++)
	{
	    sprintf_s(stmt1, sizeof stmt1,"SELECT a.ipolicy[1,3] ,a.ipolicy ,"
	                  "       CASE WHEN a.nemai_send IS NULL OR a.nemai_send='' THEN 'N' ELSE 'Y' END , "
	                  "       CASE WHEN a.tsms_mobile IS NULL OR a.tsms_mobile='' THEN 'N' ELSE 'Y' END, "
	                  "       g.iofficer ," 
	                  "       (SELECT nname FROM officer WHERE iofficer = g.iofficer) , "
	                  "       b.iroute, "
	                  "       (SELECT nroute FROM cm_route WHERE iroute = b.iroute) , "
	                  "       (SELECT nname FROM officer WHERE iofficer = g.ileader), g.ileader, "
	                  "       g.iquota,c.nbranch ,g.dpolicy::date,  "                     
	                  "       to_char(YEAR(g.dpolicy)-1911)||'/'||to_char(MONTH(g.dpolicy)), "
	                  "       date(a.demail), "
	                  "       CASE WHEN g.iscan_no is null or g.iscan_no = '' THEN 'N' ELSE 'Y' END,"
	                  "       g.iscan_no,"
	                  "       d.nchi_abv , "
	                  "       CASE  (SELECT group2 FROM sa_branch_type WHERE ibranch = (SELECT iquota_grp FROM branch WHERE ibranch = (SELECT ibranch FROM officer WHERE iofficer = g.ileader))) "
	                  "       WHEN '100' THEN (SELECT group2 FROM sa_branch_type WHERE ibranch = g.iquota)  "
	                  "       ELSE (SELECT group2 FROM sa_branch_type WHERE ibranch=(SELECT iquota_grp FROM branch WHERE ibranch = (SELECT ibranch FROM officer WHERE iofficer = g.ileader))) END, "
	                  "       g.ilast_ply "
	                  "  FROM cm_e_policy a ,%s:original_ply b , %s:ori_ply_relation g ,sa_branch_type c, branch d, cu_code_data e "
	                  " WHERE a.iins_cat = 'C' "
	                  "   AND a.ipolicy = b.ipolicy "
	                  "   AND a.iendorse = '' "
	                  "   AND a.ipolicy = g.ipolicy "
	                  "   AND g.iquota = c.ibranch "
	                  "   AND c.group2 = e.icode "
	                  "   AND e.itype = '19' "
	                  "   AND c.iupbranch = d.ibranch "
	                  "   AND g.dpolicy BETWEEN '%s' AND '%s' %s ",list[k].dbname,list[k].dbname,dbgn2,dend2,swhere);
		
		$PREPARE ply_data1 FROM $stmt1;
		$DECLARE ply_data CURSOR for ply_data1;
		$OPEN ply_data;
		printf("stmt1[%s] \n",stmt1);
		
		while(1)
		{
			$FETCH ply_data INTO $ipolicy_1_3,$ipolicy,$femail_send,$fsms_mobile,$iofficer,$nofficer,$iruote,$nroute,$nleader,$ileader,$iquota,$nbranch,$dpolicy,
			                     $dpolicy_ym,$demail,$fesign,$iscan_no,$nchi_abv,$icode,$ilast_ply;

			if(SQLCODE == SQLNOTFOUND) break;
			
			printf("ipolicy[%s] \n",ipolicy);
			
			printf("��O��O�_�q�l\n");
			strcpy(ilast_ply,trim(ilast_ply));
			if (strcmp(ilast_ply,"")==0)
			{
				strcpy(flast_eply," ");
			}
			else
			{
				strcpy(sFullName, get_car_full_db(ilast_ply));
				printf("sFullName[%s]\n",sFullName);
				sprintf_s(stmt2, sizeof stmt2,"SELECT feply FROM %s:ply_relation WHERE ipolicy = '%s' ",sFullName,ilast_ply);
				$PREPARE last_eply FROM $stmt2;
				$EXECUTE last_eply INTO $flast_eply;
			}
			
			printf("307�ɵo����\n");
			/* CAR307 �ɵo���� */
			$SELECT count(*)
			   INTO $cnt_307
			   FROM ca_log
			  WHERE ilog_number1 = $ipolicy
			    AND ipgid = 'car307';
			    
			printf("������\n");
			/* ������ */
			$SELECT count(iendorsement)
			   INTO $cnt_iedr
			   FROM policy_main b
			  WHERE ipolicy1 = $ipolicy
			    AND ipolicy2 = ''
			    AND iendorsement <> '';
			
			$INSERT INTO CAR739 VALUES ($ipolicy_1_3,$ipolicy,$femail_send,$fsms_mobile,$iofficer,$nofficer,$iruote,$nroute,$nleader,$ileader,$iquota,$nbranch,$dpolicy,
			                            $dpolicy_ym,$demail,$fesign,$iscan_no,$nchi_abv,$icode,$ilast_ply,$flast_eply,$cnt_307,$cnt_iedr);
		}
	}
 
	return M_CM_OK;

errexit:
	printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	exit(1);
}

char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
	char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
	char sTmp_db_name[21];
	
	sTmp_db_name[0]='\0';
	if (*sIpolicy != '\0' && *sIpolicy !=' ')
	{
		sTmp_db_name[0]='\0';
		strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
		strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,USE_BRANCH_ID));
		strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
	}
	/*printf("sTmp_db_name[%s]",sTmp_db_name);*/
	return sTmp_db_name;
}