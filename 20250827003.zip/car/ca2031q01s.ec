/****************************************************
 * Copyright (C) 1993 Intellisys Corporation
 *
 * Program : ca203q01s.ec 
 *
 * revised : Johnny 1997/07/11
 *
 * Background Report   (Type : Free Style)
 ****************************************************/

#include <stdio.h>
#include <math.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"

#include "carmsgs.h" 
#include "commsgs.h" 
#include "cmnmsgs.h" 
#include "gls_array.h" 
#include "gls_const.h"
#include "sqlfatal.h"
#include "safeclib.h"
$char what_type[8],sitename[20];;

$char ipolicy[20],icard[20],nassured[122],aassured[92],apayment[92],ilicense[12],ibirth[10];
$char iassured[11];
$char fsex[2],ncar_abbr[14],iissue_ym[8],itag[21],dply_begin[14],dply_end[14];
$char icar_type[4],ibrand[10],nbrand_abbr[14],ibody[22],itel[21],iengine[24];
 char iengine_ext[6];
$char irelative_ply[20],qcylinder_buf[20],qperiod_buf[20],mpremium_buf[20];
$char bcard1[20],bcard2[20],bcard3[20],mY[4],mN[4],rel_ins_type[24],pdate[16];
$char bak_ins[8],fmarriage[4],irelative_card[20];
$int qcylinder = 0,qperiod,mpremium;
int tmp_prem,other_prem,flag1=0;
$double qpt = 0;
char  ch_amt[40],policy_y;
char  s_dpolicy[14];
static char yy1[4], mm1[3], dd1[3];
$char allins1[100],allins2[100],ins1[24],ins12[24],ins2[24],ins22[24],ins3[24];
$char ins32[24],irelative_ply1[20],rel_card1[20],rel_card2[20];
$char fcomp_class[3],fcomp_class_last[3],fpt[2],cqpt[6];
$char icard1[20],ipolicy1[20],nassured1[122],ncar_abbr1[14],nbrand_abbr1[14];
$char iengine1[24],itag1[9],ilicense1[12],dply_begin1[14],dply_end1[14],ibody1[22];

$char Ipolicy[20],Iofficer[11],Iofficer_tmp[13],Nofficer[21];

/*ca_accident*/
  $char Inumber[21];

/*----------------------------------------------------------------------*/
extern char RPTDIR[];

$char print_type[10],cardbegin[20], cardend[20], mark[20],check_card[20];
$char print_frm[2],print_card[2];

int max_count;

$char DBName[5];
$char FormTp[3];
char  outputf[20];
char  userid[11];
static Today;

long car203_build();
long car203_body();
void put_body1(); /* �j���ҷs�� car203.fmt */
void put_body2(); /* ���N�d */
void put_body3(); /* �j�����ª� car2031.fmt */
void put_body4(); /* �O�N���ª� car2032.fmt */
void put_body5(); /* �@��� car2033.fmt */
void put_body6(); /* �O�N��s�� car2034.fmt */
/*---------------------------------------------------------------------*/
char s_qlia[3][10], fyear[3];
$date rate_date;
long qdmg[3],qlia[3];
long mdmg[3],mlia[3];
long qlia_acc,qdmg_acc;
double pdmg_acc,plia_acc;


main(argc, argv)
int argc;
char **argv;
{
 long rc;
 batchinit();
 strcpy(DBName,     isNULLstr(argv[1]));
 strcpy(userid,     isNULLstr(argv[2]));

 strcpy(print_type, isNULLstr(argv[3])); /** 1:���N 2:�j�� **/
 strcpy(what_type,  isNULLstr(argv[4])); /** 1:�O�渹 2:�j����/���N�d **/
 strcpy(cardbegin,  isNULLstr(argv[5]));
 strcpy(cardend,    isNULLstr(argv[6]));
 strcpy(mark,       isNULLstr(argv[7])); /** '0' **/
 strcpy(print_frm,  isNULLstr(argv[8])); /** 3:���O�N��,4:���@����ª�,5:���@���s�� **/
 strcpy(print_card, isNULLstr(argv[9])); /*  �C�L�Ҹ� */  
 strcpy(outputf,    isNULLstr(argv[10]));
 printf("client send %s %s %s %c %s\n",print_type,cardbegin,cardend,mark[0],
         print_frm);
 rc=car203_build();
 if (rc != M_CM_OK) return rc;
       
 if ((rc=save_form_info(F_FREE,"CA",203,userid,FormTp,max_count,outputf))<0)
 {
     EWRITE(userid,rc,"save_form_info failed");
     exit(FAIL);
 }
}

void clear_data()
{
  ipolicy[0]=icard[0]=irelative_ply[0]=0;
  fcomp_class[0]=fcomp_class_last[0]=0;
  cqpt[0]=0;
  nassured[0]=aassured[0]=0;
  apayment[0]=0;
  ncar_abbr[0]=0;
  iissue_ym[0]=0;
  itag[0]=0;
  iengine[0]=0;
  icar_type[0]=0;
  nbrand_abbr[0]=0;
  ibrand[0]=0;
  qcylinder_buf[0]=0;
  ibody[0]=0;
  dply_begin[0]=dply_end[0]=0;
  qperiod_buf[0]=0;
  mpremium_buf[0]=0;
  ilicense[0]=0;
  ibirth[0]=0;
  fsex[0]=0;
  itel[0]=0;
  bcard1[0]=0;
  irelative_card[0]=0;
  mY[0]=mN[0]=0;
  rel_ins_type[0]=0;
  pdate[0]=0;
  fmarriage[0]=0;
}

void clear_data3()
{
  ipolicy1[0]=icard1[0]=0;
  nassured1[0]=0;
  iassured[0]=0;
  ncar_abbr1[0]=nbrand_abbr1[0]=0;
  itag1[0]=0;
  iengine1[0]=ibody1[0]=0;
  ilicense1[0]=0;
  dply_begin1[0]=dply_end1[0]=0;
  allins2[0]=0;
  rel_card2[0]=0;
  ins12[0]=ins22[0]=ins32[0]=0;
}
void clear_data2()
{
  ipolicy[0]=icard[0]=0;
  nassured[0]=0;
  iassured[0]=0;
  ncar_abbr[0]=nbrand_abbr[0]=0;
  itag[0]=iengine[0]=ibody[0]=0;
  ilicense[0]=0;
  dply_begin[0]=dply_end[0]=0;
  irelative_ply[0]=0;

  ipolicy1[0]=icard1[0]=0;
  nassured1[0]=0;
  ncar_abbr1[0]=nbrand_abbr1[0]=0;
  iengine1[0]=0;
  ilicense1[0]=0;
  dply_begin1[0]=dply_end1[0]=0;
  allins1[0]=0;
  rel_card1[0]=0;
  ins1[0]=ins2[0]=ins3[0]=0;
}
/*---------------------------------------------------------------------*/   
long car203_build()
{
  $char FormFile[N_FILE+1];
  char  OutFile[N_FILE];
  long  rtncode;

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      exit(FAIL);
  }

  $SELECT nForm_File, iForm_Tp
     INTO $FormFile, $FormTp
     FROM Form
    WHERE ksys_grp="CA" AND kPgmID = 203
      AND iform_tp = $print_frm;

  strcpy(FormFile,rtrim(FormFile));  /* FormFile=car203.fmt */
  sprintf_s(OutFile, sizeof OutFile,"%s.tx",outputf);
  rgu_init_report(FormFile,OutFile);
  rtoday(&Today);
  strcpy(s_dpolicy,cm_cdate_str_100(Today));
  cm_split_ymd_100(s_dpolicy,yy1,mm1,dd1);
  rtncode=car203_body();
  if (rtncode != M_CM_OK) {
      EWRITE(userid,rtncode,sqlca.sqlerrm);
      printf("exit_rtncode----->%d\n",rtncode);
      exit (FAIL);
  }
  rgu_finish_report();
  printf("finish_code------>%d\n",rtncode);
  return M_CM_OK;
  
errexit:
  sqlfatal();
  EWRITE(userid,SQLCODE,sqlca.sqlerrm);
  exit (FAIL);
} 

/*---------------------------------------------------------------------*/   
long car203_body()
{
  $char stmt[400],stmt1[400],stmt2[400];
  char which_card[100],taipei_db[40];
  int i, j; 
  $WHENEVER SQLERROR GOTO errexit;
  max_count=0;
 
 if (print_type[0]=='2') /* �L�j��� */
  {
     if (what_type[0]=='1') /* ����:�O�渹 */
     {
        sprintf_s(which_card, sizeof which_card,"ipolicy >= '%s' AND ipolicy <= '%s' order by ipolicy",
                           cardbegin,cardend);
        $SELECT icard INTO $check_card 
           FROM policy 
          WHERE ipolicy = $cardbegin;
        if (SQLCODE==SQLNOTFOUND) strcpy(check_card," ");
     } else { /* ����:�j��� */
        sprintf_s(which_card, sizeof which_card,"icard >= '%s' AND icard <= '%s' order by icard",
                           cardbegin,cardend);
        strcpy(check_card,cardbegin);
        printf("check_card----->%s",check_card);
     }

     if (check_card[3] >='A' && check_card[3] <= 'Z')  /*�O�N��*/
     {
        if (getHeadBranch(taipei_db)<0) {
           printf("read Config file error!!\n");
           return M_CM_READ_CONFIG_ERR;
        }
        printf("taipei_db----->[%s]\n",taipei_db);
        strcpy(sitename,get_full_dbname(taipei_db));
        strcat(sitename,":");
     } else strcpy(sitename," ");

printf("      ### sitename=[%s] \n",sitename);

                         /* �j��d���B�O�渹�B�O�I�����Bñ���� �A�q�j��d�� */
 
    if(what_type[0]=='2')
   {    
     printf(" what_type = 2 \n");  /* �j��d�� */     
     sprintf_s(stmt1, sizeof stmt1, "SELECT icard, ipolicy, qperiod, dissue  "
                      " FROM %scompulsory_card c, car_type t  "
                      "WHERE fclass='1' AND t.icode=c.icar_type AND %s",
                     sitename,which_card);
   } else {
       printf(" what_type = 1 \n"); /* �O�渹 */
       sprintf_s(stmt1, sizeof stmt1, "SELECT icard, ipolicy  "
                       " FROM %spolicy   "
                       "WHERE %s",sitename,which_card);
   }
     printf("stmt1 [%s]\n",stmt1);
     $PREPARE cur_stmt1 from $stmt1;
     $DECLARE cur_com1 CURSOR for cur_stmt1; 
     $OPEN cur_com1; 
    for(;;)
    {
      clear_data();
      policy_y = 'Y';
      $FETCH cur_com1 INTO $icard,$ipolicy,$qperiod,$pdate;
      printf("icard [%s] ipolicy [%s] \n",icard,ipolicy);
      if (SQLCODE == SQLNOTFOUND) {      
        printf(" SQLCODE = [%d]\n",SQLCODE);
        break;
      }
      strcpy(Ipolicy, ipolicy); /*Ipolicy�j��O��*/

      printf("[%s][%s][%s]\n",icard,ipolicy,pdate);

      $SELECT p.ipolicy, p.nassured, p.aassured, p.apayment, r.icar_type,
              p.ncar_abbr, 
              to_char(p.dissue,'%Y')::integer - 1911 || '/' || to_char(p.dissue,'%m'),
              p.itag, p.iengine, p.nbrand_abbr, 
              r.ibrand, p.qcylinder, p.ibody, r.dply_begin, r.dply_end, 
              r.qply_period, p.ilicense, 
              to_char(p.dbirth,'%Y')::integer - 1911 || '/' || to_char(p.dbirth,'%m/%d'), 
              p.fsex, p.itel, 
              r.dpolicy, r.ilast_card, p.fmarriage, r.mlia_prem, r.iofficer
              , p.fpt, p.qpt , p.iassured
         INTO $ipolicy, $nassured, $aassured, $apayment, $icar_type,
              $ncar_abbr, 
              $iissue_ym, 
              $itag, $iengine, $nbrand_abbr, 
              $ibrand, $qcylinder, $ibody, $dply_begin, $dply_end, 
              $qperiod, $ilicense, 
              $ibirth, 
              $fsex, $itel,
              $pdate, $bcard1, $fmarriage, $mpremium, $Iofficer 
              , $fpt, $qpt, $iassured 
         FROM policy p, ply_relation r 
        WHERE p.ipolicy = r.ipolicy AND r.ipolicy=$ipolicy;
     
      printf("SQLCODE == [%d]\n",SQLCODE);
      if (SQLCODE== SQLNOTFOUND) 
      
      {  qperiod=0; pdate[0]=0; mpremium=0;policy_y = 'N'; 
         printf("not found\n");
      }

      else { 
         $SELECT  nname
            INTO  $Nofficer
            FROM  officer
           WHERE  iofficer = $Iofficer;

         $SELECT  ncode
              INTO  $ncar_abbr
              FROM  car_type
              WHERE  icode = $icar_type AND fclass = '1';
              ncar_abbr[8] = '\0';
              printf("---------------->%s",ncar_abbr);  

         $SELECT irelative_ply,fcomp_class,fcomp_class_last INTO $irelative_ply
                 ,$fcomp_class,$fcomp_class_last  FROM ply_relation
           WHERE ipolicy=$ipolicy;
         if (SQLCODE != SQLNOTFOUND) 
         {
            /* select �I�إN�X from �O���I�ة��� */ 
            $DECLARE cur_ins CURSOR for
              SELECT iins_type
                FROM ply_ins_type  
               WHERE ipolicy=$irelative_ply;
            $OPEN cur_ins;
            for(;;)
            {
              $FETCH cur_ins into $bak_ins;
              if (SQLCODE == SQLNOTFOUND) break;

              strcat(rel_ins_type,rtrim(bak_ins)); 
            }
         }

	 $SELECT icard into $irelative_card
	    FROM ply_relation
	   WHERE ipolicy = $irelative_ply;
  printf( " irelative_card [%s] \n",irelative_card);

         $SELECT ilast_card into $bcard2
            FROM ply_relation
           WHERE icard=$bcard1;
         if (SQLCODE != SQLNOTFOUND)
         { 
            $SELECT ilast_card INTO $bcard3
               FROM ply_relation
              WHERE icard=$bcard2;
         }
      }
      
      /* car9711072 �Y���������ŭ�,�h�L�X������ */
       if(strlen(trim(iengine)) == 0) strcpy(iengine,ibody);
     
      if (strncmp(print_frm,"1",1)==0)
          put_body1(); /* �s�� */
      else if (strncmp(print_frm,"2",1)==0)
          put_body3(); /* �ª� */
      else if (strncmp(print_frm,"3",1)==0)
          put_body6(); /* �O�N��s�� */
          /* put_body4(); �O�N���ª� */
      else 
          put_body5(); /* �@��� */
 
    }
    $CLOSE cur_com1;
    $FREE cur_com1;
    printf("print_type2 end\n");
  } 
     else if (print_type[0]=='1') {
     if(what_type[0]=='1')  /*����:�O�渹*/
       sprintf_s(which_card, sizeof which_card,"c.ipolicy >= '%s' AND c.ipolicy <= '%s' order by p.ipolicy", cardbegin,cardend);
     else /* ����:���N�d */
       sprintf_s(which_card, sizeof which_card,"c.icard >= '%s' AND c.icard <= '%s' order by c.icard", cardbegin,cardend);

     sprintf_s(stmt, sizeof stmt,"SELECT i.nins_abbr  "
                    " FROM insurance_type i, ply_ins_type t  "
                    "WHERE t.ipolicy=? AND t.iins_type=i.iins_type ");
     printf("%s\n",stmt); 
     $PREPARE cur_insp from $stmt;
     $DECLARE cur_sel_ins CURSOR for cur_insp;
     
     sprintf_s(stmt, sizeof stmt,"SELECT c.icard, p.ipolicy, nassured, ncar_abbr,  "
                           "nbrand_abbr, iengine, ilicense, itag, ibody, "
                           "dply_begin, dply_end, r.irelative_ply  "
                    " FROM policy p, card c, ply_relation r  "
                    "WHERE c.icard=p.icard AND r.icard=c.icard  "
                    "  AND %s ", which_card);
printf("%s\n",stmt); 

    $PREPARE cur_stmt from $stmt;
    $DECLARE cur_card CURSOR for cur_stmt;
    $OPEN cur_card;
    for (i=0;i<9;i++) rgu_put_body(1);
    for(;;)
    {
      clear_data2();
      $FETCH cur_card INTO
        $icard, $ipolicy, $nassured, $ncar_abbr, $nbrand_abbr,
        $iengine, $ilicense, $itag, $ibody, $dply_begin, $dply_end, $irelative_ply;
      if (SQLCODE == SQLNOTFOUND) break;

      if (icard[1] <= 'Z' && icard[1] >='A') continue; /*�D�O�N��*/

      $SELECT a.icard INTO $rel_card1
         FROM ply_relation a,ply_relation b
        WHERE a.ipolicy=b.irelative_ply 
          AND b.icard=$icard;
      $OPEN cur_sel_ins using $ipolicy;
      for(;;)
      {
        $FETCH cur_sel_ins INTO $bak_ins;
        if (SQLCODE == SQLNOTFOUND) break;
        bak_ins[6]=0;

        /*** midify �T�d�ˤT�d�]=>�ĤT�H�d���I ***/
        if (strcmp(bak_ins,"�T�d��")==0) strcpy(bak_ins,"�ĤT�H");
        if (strcmp(bak_ins,"�T�d�]")==0) strcpy(bak_ins,"�d���I");

        strcat(allins1,bak_ins);
      } 
      $CLOSE cur_sel_ins;
   
again:
      clear_data3();
      $FETCH cur_card INTO
        $icard1,$ipolicy1,$nassured1,$ncar_abbr1,$nbrand_abbr1,
        $iengine1,$ilicense1,$itag1,$ibody1,$dply_begin1,$dply_end1,$irelative_ply1;
      if (SQLCODE == SQLNOTFOUND)
      {
        put_body2();     
        break;
      }
      if (icard1[1] <= 'Z' && icard1[1] >='A')
        goto again;
      $SELECT a.icard INTO $rel_card2
         FROM ply_relation a,ply_relation b
        WHERE a.ipolicy=b.irelative_ply 
          AND b.icard=$icard1;
      $OPEN cur_sel_ins using $ipolicy1;
      for(;;)
      {
        $FETCH cur_sel_ins into $bak_ins;
        if (SQLCODE == SQLNOTFOUND) break;
        bak_ins[6]=0;

        /*** midify �T�d�ˤT�d�]=>�ĤT�H�d���I ***/
        if (strcmp(bak_ins,"�T�d��")==0) strcpy(bak_ins,"�ĤT�H");
        if (strcmp(bak_ins,"�T�d�]")==0) strcpy(bak_ins,"�d���I");

        strcat(allins2,bak_ins);
      } 
      $CLOSE cur_sel_ins;

      put_body2();
    }
    $CLOSE cur_card;
    $FREE cur_card;
  }
  if (max_count==0)
      return M_CM_NOT_FOUND;

  return M_CM_OK;

errexit:
  sqlfatal();
  EWRITE(userid,SQLCODE,sqlca.sqlerrm);
  exit(FAIL);
}

int cc_split(s_buf,t_buf,len)
char *s_buf;
char *t_buf;
int len;
{
  int i,flag;

  for(i=0;i<len;) {
    if((unsigned) s_buf[i]>128)  /* �ˬd�O�_������r�A�Y s_buf[i] > 128 ���ܬ�����r */
    {                                    /* �h�@������Ӧr���A�_�@��catch�@�Ӧr�� */
      strncpy(&t_buf[i],&s_buf[i],2);
      t_buf[i+2]='\0';
      i+=2;
    } else {
      strncpy(&t_buf[i],&s_buf[i],1);
      t_buf[i+1]='\0';
      i++;
    }
    if(i>len ) {
      t_buf[i-2]='\0';
      return i-2;
    } else if(i==len ) {
      return i;
    }
  }
}

split_ch(source,s1,s2,l)
char source[],s1[],s2[];
int l;
{
  char oo[200];
  int i;
  strcpy(oo,rtrim(source));
  if (strlen(oo)> l)
  {
    i=cc_split(oo,s1,l);
    strcpy(s2,&oo[i]);
  }else{
    strcpy(s1,oo);
    s2[0]=0;
  }
}
    
void put_body1()
{
  char tmpbuf[150],tmpbuf1[150];
  char yy[10],mm[10],dd[10];
  char tmpcard[21];
  int i;


rate_date=cm_ymd_cdate(cm_from_infdate_100(dply_begin));


  if ((ipolicy[0]!='\0')&&(ipolicy[0]!=' ')){
     if ((itag[0]!='\0')&&(itag[0]!=' '))
       { strcpy(Inumber, itag); }
     else
       { strcpy(Inumber, iengine); }
/**  crystal-removed at 87/01/19 
     ca_accident_record(DBName,Inumber ,rate_date,"1", qdmg,qlia, mdmg,mlia,
                        &qdmg_acc,&qlia_acc, &pdmg_acc,&plia_acc,fyear);
**/
  }else{
     strcpy(fyear,"NNN");
  }

  for(i=0;i<3;i++){
    printf("ca_accident[%d]:[%c]%ld\n",i,fyear[i],qlia[i]);
    if (fyear[i]=='Y')
       strcpy(s_qlia[i],itoa(qlia[i]));
    else
       strcpy(s_qlia[i]," ");
  }
/*
* for(i=0;i<6;i++)
*   rgu_put_body(1);
*/
  if (icard[1] <= 'Z' && icard[1] >='A')
  {
    tmpbuf[0]=0;
    strcpy(tmpbuf1,icard);
  }else{
    strncpy(tmpbuf,icard,2); tmpbuf[2]=0;
    strcpy(tmpbuf1,"17");
    strcat(tmpbuf1,&icard);
  }
    /*     rgu_put_body_string(10,tmpbuf,RIGHT); */
  strcpy(tmpcard,trim(tmpbuf1));
  rgu_put_body_string(10,tmpbuf1,LEFT);
  rgu_put_body_string(28,tmpbuf1,LEFT);
  rgu_put_body(10);
/*rgu_put_body(1);*/
  split_ch(nassured,tmpbuf,tmpbuf1,38);
  if (*fsex == '1')
       strcat(tmpbuf," ����");
  else if (*fsex == '2')
       strcat(tmpbuf," �p�j");
  tmpbuf[30]=0;
  tmpbuf1[30]=0;
  rgu_put_body_string(12,tmpbuf,LEFT);
  rgu_put_body_string(30,tmpbuf,LEFT);

  rgu_put_body(12);
  split_ch(aassured,tmpbuf,tmpbuf1,38);
  if (strlen(tmpbuf1)==0) {
      rgu_put_body_string(13," ",LEFT);
      rgu_put_body_string(13,bcard1,LEFT);
      rgu_put_body_string(14,tmpbuf,LEFT);
  }
  else {
      rgu_put_body_string(13,tmpbuf,LEFT);
      rgu_put_body_string(13,bcard1,LEFT);
      tmpbuf1[38]=0;
      rgu_put_body_string(14,tmpbuf1,LEFT);
  }
  rgu_put_body(13);
  rgu_put_body(14);
  if (strncmp(ilicense," ",1)==0)
      if (strncmp(iassured,"AAAAAAAAAA",10)!=0)
          strcpy(ilicense,iassured);
  for(i=0;i<10;i++) 
  {
   strncpy(tmpbuf,ilicense+i,1);
   tmpbuf[1]='\0';
   rgu_put_body_string(15,tmpbuf,LEFT);
  }
  rgu_put_body(15);
  rgu_put_body(1);
  rgu_put_body_string(16,nbrand_abbr,LEFT);
  rgu_put_body_string(36,nbrand_abbr,LEFT);
  ncar_abbr[8]=0;
  rgu_put_body_string(16,ncar_abbr,LEFT);
  rgu_put_body_string(34,ncar_abbr,LEFT);

  strcpy(yy,iissue_ym);
  yy[3]=0;
  rgu_put_body_string(16,yy,LEFT);
  rgu_put_body_string(34,yy,LEFT);
  if ((itag[0]!='\0')&&(itag[0]!=' '))
     {
       itag[20]=0;
       rgu_put_body_string(16,itag,LEFT);
       rgu_put_body_string(34,itag,LEFT);
     }
  else
     {
       rgu_put_body_string(16," ",LEFT);
       rgu_put_body_string(34," ",LEFT);
     }
  if ((iengine[0]!='\0')&&(iengine[0]!=' '))
     {
       iengine[20]=0;
       rgu_put_body_string(16,iengine,LEFT);
       rgu_put_body_string(34,iengine,LEFT);
     }
  else
     {
       rgu_put_body_string(16," ",LEFT);
     }
  rgu_put_body(16);
  if(dply_begin[0]==0)
  {
       rgu_put_body_string(17,"",LEFT);
       rgu_put_body_string(17,"",LEFT);
       rgu_put_body_string(17,"",LEFT);
  }else{
       strcpy(tmpbuf,cm_from_infdate_100(dply_begin));
       cm_split_ymd_100(tmpbuf,yy,mm,dd);
       rgu_put_body_string(17,yy,LEFT);
       rgu_put_body_string(31,yy,LEFT);
       rgu_put_body_string(17,mm,LEFT);
       rgu_put_body_string(31,mm,LEFT);
       rgu_put_body_string(17,dd,LEFT);
       rgu_put_body_string(31,dd,LEFT);
  }
  if(qperiod==0)
   {
       rgu_put_body_string(17,qperiod,LEFT);
       rgu_put_body_string(31,qperiod,LEFT);
   } else
   {
       strcpy(tmpbuf,itoa(qperiod));
       rgu_put_body_string(17,tmpbuf,LEFT);
       rgu_put_body_string(31,tmpbuf,LEFT);
   }
  rgu_put_body(17);

  if(dply_end[0]==0)
    {
        rgu_put_body_string(18,"",LEFT);
        rgu_put_body_string(18,"",LEFT);
        rgu_put_body_string(18,"",LEFT);
    } else
    {
        strcpy(tmpbuf,cm_from_infdate_100(dply_end));
        cm_split_ymd_100(tmpbuf,yy,mm,dd);
        rgu_put_body_string(18,yy,LEFT);
        rgu_put_body_string(18,mm,LEFT);
        rgu_put_body_string(18,dd,LEFT);
        rgu_put_body_string(32,yy,LEFT);
        rgu_put_body_string(32,mm,LEFT);
        rgu_put_body_string(32,dd,LEFT);
    }

  if (ibirth[0]==0) {
         rgu_put_body_string(18,"",LEFT);
         rgu_put_body_string(18,"",LEFT);
         rgu_put_body_string(18,"",LEFT);
  }else{
         cm_split_ymd_100(ibirth,yy,mm,dd);
         rgu_put_body_string(18,yy,LEFT);
         rgu_put_body_string(18,mm,LEFT);
         rgu_put_body_string(18,dd,LEFT);
  }

  if(fsex[0]=='1'){
         rgu_put_body_string(18,"v",LEFT);
         rgu_put_body_string(18,"",LEFT);
  }else if(fsex[0]=='2'){
         rgu_put_body_string(18,"",LEFT);
         rgu_put_body_string(18,"v",LEFT);
  }else{
         rgu_put_body_string(18,"",LEFT);
         rgu_put_body_string(18,"",LEFT);
  }
  if (fmarriage[0]=='1'){
         rgu_put_body_string(18,"v",LEFT);
         rgu_put_body_string(18,"",LEFT);
                         }
  else if (fmarriage[0]=='2')
  {
         rgu_put_body_string(18,"",LEFT);
         rgu_put_body_string(18,"v",LEFT);
  }else{
         rgu_put_body_string(18,"",LEFT); 
         rgu_put_body_string(18,"",LEFT);
  }
  rgu_put_body_string(18,fcomp_class_last,LEFT);
  rgu_put_body(18);

    if(mpremium==0)
    {
          rgu_put_body_string(19,"",RIGHT);
          rgu_put_body_string(19,"",RIGHT);
          rgu_put_body_string(19,"",RIGHT);
          rgu_put_body_string(19,"",RIGHT);
          rgu_put_body_string(19,"",RIGHT);
    }else{
       strcpy(mpremium_buf,refmtamt(mpremium,MILLIONTH));
       rgu_put_body_string(26,rtrim(mpremium_buf),LEFT);
       tmp_prem=mpremium/10000;
       other_prem=mpremium%10000;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(19,ch_amt,RIGHT);

       tmp_prem=other_prem/1000;
       other_prem=other_prem%1000;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(19,ch_amt,RIGHT);

       tmp_prem=other_prem/100;
       other_prem=other_prem%100;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(19,ch_amt,RIGHT);

       tmp_prem=other_prem/10;
       other_prem=other_prem%10;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(19,ch_amt,RIGHT);

       num_to_chinese(ch_amt,other_prem);
       if (other_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(19,ch_amt,RIGHT);
    }
    if (strlen(irelative_ply)==0)
        rgu_put_body_string(19," ",LEFT);
    else {
        sprintf_s(tmpbuf, sizeof tmpbuf,"17%s",trim(irelative_ply));
        rgu_put_body_string(19,tmpbuf,LEFT);
    }
    rgu_put_body_string(19,tmpcard,LEFT);
    rgu_put_body(19);
   if (fpt == 'P')
     {
          sprintf_s(cqpt, sizeof cqpt,"%5.0f",qpt); 
          printf("cqpt---->%s\n",cqpt);
          rgu_put_body_string(20, cqpt, LEFT);    
     }
   else if ( fpt == 'T')
     {
          rgu_put_body_string(20,"",RIGHT);
          sprintf_s(cqpt, sizeof cqpt,"%5.1f", qpt);
          rgu_put_body_string(20,cqpt,LEFT);
     } 
   else
      {
          rgu_put_body_string(20,"",RIGHT);
          rgu_put_body_string(20,"",LEFT);
      }
   rgu_put_body(20);
    rgu_put_body(1);
    rgu_put_body(1);
    if  (policy_y == 'Y')
    {
       rgu_put_body_string(23,yy1,RIGHT);
       rgu_put_body_string(23,mm1,RIGHT);
       rgu_put_body_string(23,dd1,RIGHT);
    }else {
       rgu_put_body_string(23," ",RIGHT);
       rgu_put_body_string(23," ",RIGHT);
       rgu_put_body_string(23," ",RIGHT);}

    rgu_put_body(23);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(26);
    rgu_put_body(28);
    rgu_put_body(1);
    rgu_put_body(30);
    rgu_put_body(31);
    rgu_put_body(32);
    rgu_put_body(1);
    rgu_put_body(34);
    rgu_put_body(1);
    if (qcylinder == 0)
    { rgu_put_body_string(36,"",LEFT);}
    else
    { strcpy(tmpbuf,itoa(qcylinder));
      rgu_put_body_string(36,tmpbuf,RIGHT);
    }
    strncpy(tmpbuf,iengine,15);
    if(strlen(trim(iengine)) >15) 
     {
      strncpy(iengine_ext,iengine+15,5);
      iengine_ext[5]= '\0';
     }
    else
      iengine_ext[0] = '\0';
    tmpbuf[15] = '\0'; 
    printf ("iaaa[%s]\n",tmpbuf);
    rgu_put_body_string(36,tmpbuf,LEFT);
    rgu_put_body_string(36,fcomp_class,RIGHT);
    rgu_put_body(36);
    rgu_put_body_string(37,iengine_ext,LEFT);
    rgu_put_body(37);
    rgu_put_body(1);
 /* rgu_put_body(1);*/
    if  (policy_y == 'Y')
    {
       rgu_put_body_string(39,yy1,RIGHT);
       rgu_put_body_string(39,mm1,RIGHT);
       rgu_put_body_string(39,dd1,RIGHT);
    }else {
       rgu_put_body_string(39," ",RIGHT);
       rgu_put_body_string(39," ",RIGHT);
       rgu_put_body_string(39," ",RIGHT);}
    rgu_put_body_string(39,Iofficer,LEFT); 
    rgu_put_body(39);
    rgu_put_body_string(40,Nofficer,LEFT); 
    rgu_put_body(40);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1);
 /* ibody[20]=0;
  * rgu_put_body_string(21,ibody,LEFT);
  * rgu_put_body(21);
  * ibrand[8]=0;
  * rgu_put_body_string(22,ibrand,LEFT);
  * rgu_put_body(22);
  * rgu_put_body(23);
  *if(apayment[0]==0 || apayment[0]==' ')
  *  split_ch(aassured,tmpbuf,tmpbuf1,28);
  *else 
  *  split_ch(apayment,tmpbuf,tmpbuf1,28);
  *tmpbuf1[28]=0;
  *       rgu_put_body_string(26,tmpbuf,LEFT);
  *       rgu_put_body(26);
  *       rgu_put_body_string(27,tmpbuf1,LEFT);
  *       rgu_put_body(27);
  *       itel[11]=0;
  *       rgu_put_body_string(28,itel,LEFT);
  *       rgu_put_body(28);
  *       rgu_put_body_string(29,irelative_ply,LEFT);
  *       rgu_put_body_string(29,rel_ins_type ,LEFT);
  *       rgu_put_body(29);


  * printf("===mpremium[%d]\n",mpremium);  
  * sprintf_s(Iofficer_tmp, sizeof Iofficer_tmp,"%s%s%s","(",rtrim(Iofficer),")");
  * rgu_put_body_string(31,Iofficer_tmp,RIGHT);
  * rgu_put_body(31);

  * for(i=32;i<35;i++) rgu_put_body(1);  

  * strcpy(tmpbuf,cm_from_infdate_100(pdate));
  * cm_split_ymd_100(tmpbuf,yy,mm,dd);
  * rgu_put_body_string(34,yy,LEFT);
  * rgu_put_body_string(34,mm,LEFT);
  * rgu_put_body_string(34,dd,LEFT);
  * rgu_put_body(34);
  *for(i=0 ; i < 6 ; i++)
    rgu_put_body(1);*/

   max_count+=32;
 

}

void put_body2()
{
  char n1[140],n2[140],n3[140],n4[140];
  char yy[10],mm[10],dd[10];
  int i;
  n1[0]=0;n2[0]=0;n3[0]=0;n4[0]=0;
  split_ch(allins1,ins1,n2,18);
  split_ch(n2,ins2,ins3,19);
  split_ch(allins2,ins12,n2,18);
  split_ch(n2,ins22,ins32,18);

    rgu_put_body(1);
    rgu_put_body(1);
  split_ch(nassured,n1,n2,36);
  n2[36]=0;
  split_ch(nassured1,n3,n4,36);
  n4[36]=0;
         rgu_put_body_string(53,n1,LEFT);
         rgu_put_body_string(53,n3,LEFT);
         rgu_put_body(53);
         rgu_put_body_string(54,n2,LEFT);
         rgu_put_body_string(54,n4,LEFT);
         rgu_put_body(54);

         rgu_put_body_string(55,ncar_abbr,LEFT);
         rgu_put_body_string(55,nbrand_abbr,LEFT);
         rgu_put_body_string(55,ncar_abbr1,LEFT);
         rgu_put_body_string(55,nbrand_abbr1,LEFT);
         rgu_put_body(55);
    rgu_put_body(1);
iengine[18]=ibody[18]=0;
ilicense[10]=0;
itag[8]=0;
iengine1[18]=ibody1[18]=0;
ilicense1[10]=0;
itag1[8]=0;
         if(strlen(trim(iengine)) == 0) strcpy(iengine,ibody);
         rgu_put_body_string(57,iengine,LEFT);
         
         /**rgu_put_body_string(57,ilicense,LEFT); **/
         rgu_put_body_string(57,itag,LEFT);
         
         if(strlen(trim(iengine1)) == 0) strcpy(iengine1,ibody1);
         rgu_put_body_string(57,iengine1,LEFT);
         /**rgu_put_body_string(57,ilicense1,LEFT);**/
         rgu_put_body_string(57,itag1,LEFT);
         rgu_put_body(57);


         rgu_put_body_string(58,ins1,LEFT);
         rgu_put_body_string(58,ins12,LEFT);
         rgu_put_body(58);
  
         rgu_put_body_string(59,ipolicy,LEFT);
         rgu_put_body_string(59,ins2,LEFT);
         rgu_put_body_string(59,ipolicy1,LEFT);
         rgu_put_body_string(59,ins22,LEFT);
         rgu_put_body(59);
         rgu_put_body_string(60,rel_card1,LEFT);
         rgu_put_body_string(60,ins3,LEFT);
         rgu_put_body_string(60,rel_card2,LEFT);
         rgu_put_body_string(60,ins32,LEFT);
    rgu_put_body(60);

     strcpy(n1,cm_from_infdate_100(dply_begin));
     cm_split_ymd_100(n1,yy,mm,dd);
         rgu_put_body_string(61,yy,LEFT);
         rgu_put_body_string(61,mm,LEFT);
         rgu_put_body_string(61,dd,LEFT);
     strcpy(n1,cm_from_infdate_100(dply_begin1));
     cm_split_ymd_100(n1,yy,mm,dd);
         rgu_put_body_string(61,yy,LEFT);
         rgu_put_body_string(61,mm,LEFT);
         rgu_put_body_string(61,dd,LEFT);
         rgu_put_body(61);
  
  
     strcpy(n1,cm_from_infdate_100(dply_end));
     cm_split_ymd_100(n1,yy,mm,dd);
         rgu_put_body_string(62,yy,LEFT);
         rgu_put_body_string(62,mm,LEFT);
         rgu_put_body_string(62,dd,LEFT);
     strcpy(n1,cm_from_infdate_100(dply_end1));
     cm_split_ymd_100(n1,yy,mm,dd);
         rgu_put_body_string(62,yy,LEFT);
         rgu_put_body_string(62,mm,LEFT);
         rgu_put_body_string(62,dd,LEFT);
         rgu_put_body(62);
  for(i=63;i<65;i++)
    rgu_put_body(1);
         rgu_put_body_string(65,icard,LEFT);
         icard1[18]=0;
         rgu_put_body_string(65,icard1,LEFT);
         rgu_put_body(65);
max_count+=19;
}

void put_body3()
{
  char tmpbuf[150],tmpbuf1[150];
  char yy[10],mm[10],dd[10];
  int i;

rate_date=cm_ymd_cdate(cm_from_infdate_100(dply_begin));

  if ((ipolicy[0]!='\0')&&(ipolicy[0]!=' ')){
     if ((itag[0]!='\0')&&(itag[0]!=' '))
       { strcpy(Inumber, itag); }
     else
       { strcpy(Inumber, iengine); }
/**  crystal-removed at 87/01/19 
     ca_accident_record(DBName,Inumber ,rate_date,"1", qdmg,qlia, mdmg,mlia,
                        &qdmg_acc,&qlia_acc, &pdmg_acc,&plia_acc,fyear);
**/
  }else{
     strcpy(fyear,"NNN");
  }

  for(i=0;i<3;i++){
    printf("ca_accident[%d]:[%c]%ld\n",i,fyear[i],qlia[i]);
    if (fyear[i]=='Y')
       strcpy(s_qlia[i],itoa(qlia[i]));
    else
       strcpy(s_qlia[i]," ");
  }
/*
* for(i=0;i<6;i++)
*   rgu_put_body(1);
*/
  if (icard[1] <= 'Z' && icard[1] >='A')   /* �O�N�� */
  {
    tmpbuf[0]=0;
    strcpy(tmpbuf1,icard);
  }else{
    strncpy(tmpbuf,icard,2); tmpbuf[2]=0;
    strcpy(tmpbuf1,"17");
    strcat(tmpbuf1,&icard);
  }
    /*     rgu_put_body_string(10,tmpbuf,RIGHT); */
  rgu_put_body_string(10,tmpbuf1,RIGHT);
  rgu_put_body_string(22,tmpbuf1,RIGHT);
  rgu_put_body_string(28,tmpbuf1,RIGHT);
  rgu_put_body(10);
  rgu_put_body(1);
  split_ch(nassured,tmpbuf,tmpbuf1,30);
  if (*fsex == '1')
       strcat(tmpbuf," ����");
  else if (*fsex == '2')
       strcat(tmpbuf," �p�j");
  tmpbuf[30]=0;
  tmpbuf1[30]=0;
  rgu_put_body_string(12,tmpbuf,LEFT);
  rgu_put_body_string(30,tmpbuf,LEFT);

  rgu_put_body(12);

  split_ch(aassured,tmpbuf,tmpbuf1,30);
  if (strlen(tmpbuf1)==0) {
      rgu_put_body_string(13," ",LEFT);
   /*   rgu_put_body_string(13,mY,LEFT);  */
      rgu_put_body_string(14,tmpbuf,LEFT);
  }
  else {
      rgu_put_body_string(13,tmpbuf,LEFT);
    /*  rgu_put_body_string(13,mY,LEFT);  */
      rgu_put_body_string(14,tmpbuf1,LEFT);
  }
  if (strncmp(ilicense," ",1)==0)
      if (strncmp(iassured,"AAAAAAAAAA",10)!=0)
          strcpy(ilicense,iassured);
  for(i=0;i<10;i++) 
  {
   strncpy(tmpbuf,ilicense+i,1);
   tmpbuf[1]='\0';
   rgu_put_body_string(14,tmpbuf,LEFT);
  }
  rgu_put_body_string(14,bcard1,LEFT);
  rgu_put_body(13);
  rgu_put_body(14);
  rgu_put_body(1);
  rgu_put_body_string(16,ncar_abbr,LEFT);
  rgu_put_body_string(16,nbrand_abbr,LEFT);
  ncar_abbr[8]=0;
  rgu_put_body_string(34,ncar_abbr,LEFT);

  strcpy(yy,iissue_ym);
  yy[3]=0;
  rgu_put_body_string(16,yy,LEFT);
  rgu_put_body_string(34,yy,LEFT);
  if ((itag[0]!='\0')&&(itag[0]!=' '))
     {
       itag[20]=0;
       rgu_put_body_string(16,itag,LEFT);
       rgu_put_body_string(34,itag,LEFT);
     }
  else
     {
       iengine[20]=0;
       printf("iengine[%s]\n",iengine);
       rgu_put_body_string(16,iengine,LEFT);
       rgu_put_body_string(34," ",LEFT);
     }
  rgu_put_body(16);
  if(dply_begin[0]==0)
  {
       rgu_put_body_string(17,"",LEFT);
       rgu_put_body_string(17,"",LEFT);
       rgu_put_body_string(17,"",LEFT);
  }else{
       strcpy(tmpbuf,cm_from_infdate_100(dply_begin));
       cm_split_ymd_100(tmpbuf,yy,mm,dd);
       rgu_put_body_string(17,yy,LEFT);
       rgu_put_body_string(31,yy,LEFT);
       rgu_put_body_string(17,mm,LEFT);
       rgu_put_body_string(31,mm,LEFT);
       rgu_put_body_string(17,dd,LEFT);
       rgu_put_body_string(31,dd,LEFT);
  }
  if(qperiod==0)
   {
       rgu_put_body_string(17,qperiod,LEFT);
       rgu_put_body_string(31,qperiod,LEFT);
   } else
   {
       strcpy(tmpbuf,itoa(qperiod));
       rgu_put_body_string(17,tmpbuf,LEFT);
       rgu_put_body_string(31,tmpbuf,LEFT);
   }

  if (ibirth[0]==0) {
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"",LEFT);
  }else{
         cm_split_ymd_100(ibirth,yy,mm,dd);
         rgu_put_body_string(17,yy,LEFT);
         rgu_put_body_string(17,mm,LEFT);
         rgu_put_body_string(17,dd,LEFT);
  }

  if(fsex[0]=='1'){
         rgu_put_body_string(17,"v",LEFT);
         rgu_put_body_string(17,"",LEFT);
  }else if(fsex[0]=='2'){
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"v",LEFT);
  }else{
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"",LEFT);
  }
  if (fmarriage[0]=='1'){
         rgu_put_body_string(17,"v",LEFT);
         rgu_put_body_string(17,"",LEFT);
  } else if (fmarriage[0]=='2') {
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"v",LEFT);
  }else{
         rgu_put_body_string(17,"",LEFT); 
         rgu_put_body_string(17,"",LEFT);
  }
  rgu_put_body_string(17,fcomp_class_last,LEFT);
  rgu_put_body(17);
  if(dply_end[0]==0)
    {
        rgu_put_body_string(18,"",LEFT);
        rgu_put_body_string(18,"",LEFT);
        rgu_put_body_string(18,"",LEFT);
    } else
    {
        strcpy(tmpbuf,cm_from_infdate_100(dply_end));
        cm_split_ymd_100(tmpbuf,yy,mm,dd);
        rgu_put_body_string(18,yy,LEFT);
        rgu_put_body_string(18,mm,LEFT);
        rgu_put_body_string(18,dd,LEFT);
        rgu_put_body_string(32,yy,LEFT);
        rgu_put_body_string(32,mm,LEFT);
        rgu_put_body_string(32,dd,LEFT);
    }
   if (fpt == 'P')
     {
          sprintf_s(cqpt, sizeof cqpt,"%5.0f",qpt); 
          printf("cqpt---->%s\n",cqpt);
          rgu_put_body_string(18, cqpt, LEFT);    
     }
   else if ( fpt == 'T')
     {
          rgu_put_body_string(18,"",RIGHT);
          sprintf_s(cqpt, sizeof cqpt,"%5.1f", qpt);
          rgu_put_body_string(18,cqpt,LEFT);
     } 
   else
      {
          rgu_put_body_string(18,"",RIGHT);
          rgu_put_body_string(18,"",LEFT);
      }
   rgu_put_body(18);
    if(mpremium==0)
    {
          rgu_put_body_string(19,"",RIGHT);
          rgu_put_body_string(19,"",RIGHT);
          rgu_put_body_string(19,"",RIGHT);
          rgu_put_body_string(19,"",RIGHT);
          rgu_put_body_string(19,"",RIGHT);
    }else{
       /* refmtamt => convert a money representation from long to currency format */
       strcpy(mpremium_buf,refmtamt(mpremium,MILLIONTH));
       rgu_put_body_string(26,rtrim(mpremium_buf),LEFT);
       tmp_prem=mpremium/10000;
       other_prem=mpremium%10000;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(19,ch_amt,RIGHT);

       tmp_prem=other_prem/1000;
       other_prem=other_prem%1000;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(19,ch_amt,RIGHT);

       tmp_prem=other_prem/100;
       other_prem=other_prem%100;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(19,ch_amt,RIGHT);

       tmp_prem=other_prem/10;
       other_prem=other_prem%10;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(19,ch_amt,RIGHT);

       num_to_chinese(ch_amt,other_prem);
       if (other_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(19,ch_amt,RIGHT);
    }
    rgu_put_body(19);
    rgu_put_body(1);
    rgu_put_body(1);
    if (strlen(irelative_ply)==0)
        rgu_put_body_string(22," ",LEFT);
    else {
        sprintf_s(tmpbuf, sizeof tmpbuf,"17%s",trim(irelative_ply));
        rgu_put_body_string(22,tmpbuf,LEFT);
    }
    rgu_put_body(22);
    if  (policy_y == 'Y')
    {
       rgu_put_body_string(23,yy1,RIGHT);
       rgu_put_body_string(23,mm1,RIGHT);
       rgu_put_body_string(23,dd1,RIGHT);
    }else {
       rgu_put_body_string(23," ",RIGHT);
       rgu_put_body_string(23," ",RIGHT);
       rgu_put_body_string(23," ",RIGHT);}

    rgu_put_body(23);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(26);
    rgu_put_body(1);
    rgu_put_body(28);
    rgu_put_body(1);
    rgu_put_body(30);
    rgu_put_body(31);
    rgu_put_body(32);
    rgu_put_body(1);
    rgu_put_body(34);
    rgu_put_body(1);
    rgu_put_body_string(36,nbrand_abbr,LEFT);
    if (qcylinder == 0)
    { rgu_put_body_string(36,"",LEFT);}
    else
    { strcpy(tmpbuf,itoa(qcylinder));
      rgu_put_body_string(36,tmpbuf,LEFT);
    }
    strncpy(tmpbuf,iengine,15);
    if(strlen(trim(iengine)) >15) 
     {
      strncpy(iengine_ext,iengine+15,5);
      iengine_ext[5]= '\0';
     }
    else
      iengine_ext[0] = '\0';
    tmpbuf[15] = '\0'; 
    printf ("iaaa[%s]\n",tmpbuf);
    rgu_put_body_string(36,tmpbuf,LEFT);
    rgu_put_body_string(36,fcomp_class,LEFT);
    rgu_put_body(36);
    rgu_put_body_string(37,iengine_ext,LEFT);
    rgu_put_body(37);
    rgu_put_body(1);
    if  (policy_y == 'Y')
    {
       rgu_put_body_string(39,yy1,RIGHT);
       rgu_put_body_string(39,mm1,RIGHT);
       rgu_put_body_string(39,dd1,RIGHT);
    }else {
       rgu_put_body_string(39," ",RIGHT);
       rgu_put_body_string(39," ",RIGHT);
       rgu_put_body_string(39," ",RIGHT);}
    rgu_put_body(39);
    rgu_put_body_string(40,Iofficer,LEFT); 
    rgu_put_body(40);
    rgu_put_body_string(41,Nofficer,LEFT); 
    rgu_put_body(41);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1);
 /* ibody[20]=0;
  * rgu_put_body_string(21,ibody,LEFT);
  * rgu_put_body(21);
  * ibrand[8]=0;
  * rgu_put_body_string(22,ibrand,LEFT);
  * rgu_put_body(22);
  * rgu_put_body(23);
  *if(apayment[0]==0 || apayment[0]==' ')
  *  split_ch(aassured,tmpbuf,tmpbuf1,28);
  *else 
  *  split_ch(apayment,tmpbuf,tmpbuf1,28);
  *tmpbuf1[28]=0;
  *       rgu_put_body_string(26,tmpbuf,LEFT);
  *       rgu_put_body(26);
  *       rgu_put_body_string(27,tmpbuf1,LEFT);
  *       rgu_put_body(27);
  *       itel[11]=0;
  *       rgu_put_body_string(28,itel,LEFT);
  *       rgu_put_body(28);
  *       rgu_put_body_string(29,irelative_ply,LEFT);
  *       rgu_put_body_string(29,rel_ins_type ,LEFT);
  *       rgu_put_body(29);


  * printf("===mpremium[%d]\n",mpremium);  
  * sprintf_s(Iofficer_tmp, sizeof Iofficer_tmp,"%s%s%s","(",rtrim(Iofficer),")");
  * rgu_put_body_string(31,Iofficer_tmp,RIGHT);
  * rgu_put_body(31);

  * for(i=32;i<35;i++) rgu_put_body(1);  

  * strcpy(tmpbuf,cm_from_infdate_100(pdate));
  * cm_split_ymd_100(tmpbuf,yy,mm,dd);
  * rgu_put_body_string(34,yy,LEFT);
  * rgu_put_body_string(34,mm,LEFT);
  * rgu_put_body_string(34,dd,LEFT);
  * rgu_put_body(34);
  *for(i=0 ; i < 6 ; i++)
    rgu_put_body(1);*/

   max_count+=32;
}


void put_body4()
{
  char tmpbuf[150],tmpbuf1[150];
  char yy[10],mm[10],dd[10];
  int i;

rate_date=cm_ymd_cdate(cm_from_infdate_100(dply_begin));


  if ((ipolicy[0]!='\0')&&(ipolicy[0]!=' ')){
     if ((itag[0]!='\0')&&(itag[0]!=' '))
       { strcpy(Inumber, itag); }
     else
       { strcpy(Inumber, iengine); }
/**  crystal-removed at 87/01/19 
     ca_accident_record(DBName,Inumber ,rate_date,"1", qdmg,qlia, mdmg,mlia,
                        &qdmg_acc,&qlia_acc, &pdmg_acc,&plia_acc,fyear);
**/
  }else{
     strcpy(fyear,"NNN");
  }

  for(i=0;i<3;i++){
    printf("ca_accident[%d]:[%c]%ld\n",i,fyear[i],qlia[i]);
    if (fyear[i]=='Y')
       strcpy(s_qlia[i],itoa(qlia[i]));
    else
       strcpy(s_qlia[i]," ");
  }
   if(mpremium==0)  /* �O�O */
    {
          rgu_put_body_string(22,"",RIGHT);
          rgu_put_body_string(22,"",RIGHT);
          rgu_put_body_string(22,"",RIGHT);
          rgu_put_body_string(22,"",RIGHT);
          rgu_put_body_string(22,"",RIGHT);
    }else{
       /* refmtamt() convert a money representation from long to currency format */
       /* MILLIONTH  means  $###,###,### */
       strcpy(mpremium_buf,refmtamt(mpremium,MILLIONTH));
       rgu_put_body_string(26,rtrim(mpremium_buf),LEFT);
       tmp_prem=mpremium/10000;
       other_prem=mpremium%10000;
       num_to_chinese(ch_amt,tmp_prem); /* �N���ԧB�Ʀr �ন ����j�g�Ʀr */
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(22,ch_amt,RIGHT);

       tmp_prem=other_prem/1000;
       other_prem=other_prem%1000;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(22,ch_amt,RIGHT);

       tmp_prem=other_prem/100;
       other_prem=other_prem%100;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(22,ch_amt,RIGHT);

       tmp_prem=other_prem/10;
       other_prem=other_prem%10;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(22,ch_amt,RIGHT);

       num_to_chinese(ch_amt,other_prem);
       if (other_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(22,ch_amt,RIGHT);
    }


/* ���q�{�������D�A�� icard[1] �i��P�_���N�q
    �B�e���T�A�̫e���@�w�n�����q�N�X '17'
   if (icard[1] <= 'Z' && icard[1] >='A')   
    {
    tmpbuf[0]=0;
    strcpy(tmpbuf1,icard);
  }else{
    strncpy(tmpbuf,icard,2); tmpbuf[2]=0;
    strcpy(tmpbuf1,"17");
    strcat(tmpbuf1,&icard);
  }  */
  
  strcpy(tmpbuf1,"17");
  strcat(tmpbuf1,&icard);
  rgu_put_body_string(22,tmpbuf1,RIGHT); 
  
  if ( strncmp ( print_card ,"1",1) == 0 )
  {
    rgu_put_body_string(10,tmpbuf1,RIGHT);
    rgu_put_body_string(28,tmpbuf1,RIGHT);
  }
  rgu_put_body(10);
  rgu_put_body(1);
  split_ch(nassured,tmpbuf,tmpbuf1,30);
  if (*fsex == '1')
       strcat(tmpbuf," ����");
  else if (*fsex == '2')
       strcat(tmpbuf," �p�j");
  tmpbuf[30]=0;
  tmpbuf1[30]=0;
  rgu_put_body_string(12,tmpbuf,LEFT);
  rgu_put_body_string(30,tmpbuf,LEFT);

  rgu_put_body(12);

  split_ch(aassured,tmpbuf,tmpbuf1,30);
  if (strlen(tmpbuf1)==0) {
      rgu_put_body_string(13," ",LEFT);

      rgu_put_body_string(14,tmpbuf,LEFT);
  }
  else {
      rgu_put_body_string(13,tmpbuf,LEFT);

      rgu_put_body_string(14,tmpbuf1,LEFT);
  }
  if (strncmp(ilicense," ",1)==0)
      if (strncmp(iassured,"AAAAAAAAAA",10)!=0)
          strcpy(ilicense,iassured);
  for(i=0;i<10;i++) 
  {
   strncpy(tmpbuf,ilicense+i,1);
   tmpbuf[1]='\0';
   rgu_put_body_string(14,tmpbuf,LEFT);
  }
  rgu_put_body_string(14,bcard1,LEFT);
  rgu_put_body(13);
  rgu_put_body(14);
  rgu_put_body(1);
  rgu_put_body_string(16,ncar_abbr,LEFT);
  rgu_put_body_string(16,nbrand_abbr,LEFT);
  ncar_abbr[8]=0;
  rgu_put_body_string(34,ncar_abbr,LEFT);

  strcpy(yy,iissue_ym);
  yy[3]=0;
  rgu_put_body_string(16,yy,LEFT);
  rgu_put_body_string(34,yy,LEFT);
  printf(" ---- itag = [%s]\n",itag);
  if ((itag[0]!='\0')&&(itag[0]!=' '))
     {
       itag[20]=0;
       rgu_put_body_string(16,itag,LEFT);
       rgu_put_body_string(34,itag,LEFT);
     }
  else
     {
       iengine[20]=0;
       printf("iengine[%s]\n",iengine);
       rgu_put_body_string(16,iengine,LEFT);
       rgu_put_body_string(34," ",LEFT);
     }
  rgu_put_body(16);
  if(dply_begin[0]==0)
  {
       rgu_put_body_string(17,"",LEFT);
       rgu_put_body_string(17,"",LEFT);
       rgu_put_body_string(17,"",LEFT);
  }else{
       strcpy(tmpbuf,cm_from_infdate_100(dply_begin));
       cm_split_ymd_100(tmpbuf,yy,mm,dd);
       rgu_put_body_string(17,yy,LEFT);
       rgu_put_body_string(31,yy,LEFT);
       rgu_put_body_string(17,mm,LEFT);
       rgu_put_body_string(31,mm,LEFT);
       rgu_put_body_string(17,dd,LEFT);
       rgu_put_body_string(31,dd,LEFT);
  }
  if(qperiod==0)
   {
       rgu_put_body_string(17,qperiod,LEFT);
       rgu_put_body_string(31,qperiod,LEFT);
   } else
   {
       strcpy(tmpbuf,itoa(qperiod));
       rgu_put_body_string(17,tmpbuf,LEFT);
       rgu_put_body_string(31,tmpbuf,LEFT);
   }

  if (ibirth[0]==0) {
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"",LEFT);
  }else{
         cm_split_ymd_100(ibirth,yy,mm,dd);
         rgu_put_body_string(17,yy,LEFT);
         rgu_put_body_string(17,mm,LEFT);
         rgu_put_body_string(17,dd,LEFT);
  }

  if(fsex[0]=='1'){
         rgu_put_body_string(17,"v",LEFT);
         rgu_put_body_string(17,"",LEFT);
  }else if(fsex[0]=='2'){
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"v",LEFT);
  }else{
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"",LEFT);
  }
  if (fmarriage[0]=='1'){
         rgu_put_body_string(17,"v",LEFT);
         rgu_put_body_string(17,"",LEFT);
  } else if (fmarriage[0]=='2') {
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"v",LEFT);
  }else{
         rgu_put_body_string(17,"",LEFT); 
         rgu_put_body_string(17,"",LEFT);
  }
  rgu_put_body_string(17,fcomp_class_last,LEFT);
  rgu_put_body(17);
  if(dply_end[0]==0)
    {
        rgu_put_body_string(18,"",LEFT);
        rgu_put_body_string(18,"",LEFT);
        rgu_put_body_string(18,"",LEFT);
    } else
    {
      strcpy(tmpbuf,cm_from_infdate_100(dply_end));
      cm_split_ymd_100(tmpbuf,yy,mm,dd);
         rgu_put_body_string(18,yy,LEFT);
         rgu_put_body_string(18,mm,LEFT);
         rgu_put_body_string(18,dd,LEFT);
         rgu_put_body_string(32,yy,LEFT);
         rgu_put_body_string(32,mm,LEFT);
         rgu_put_body_string(32,dd,LEFT);
    }
   if (fpt == 'P')
     {
          sprintf_s(cqpt, sizeof cqpt,"%5.0f",qpt); 
          printf("cqpt---->%s\n",cqpt);
          rgu_put_body_string(18, cqpt, LEFT);    
     }
   else if ( fpt == 'T')
     {
          rgu_put_body_string(18,"",RIGHT);
          sprintf_s(cqpt, sizeof cqpt,"%5.1f", qpt);
          rgu_put_body_string(18,cqpt,LEFT);
     } 
   else
      {
          rgu_put_body_string(18,"",RIGHT);
          rgu_put_body_string(18,"",LEFT);
      }
    rgu_put_body(18);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1);
    if (strlen(irelative_ply)==0)
        rgu_put_body_string(22," ",LEFT);
    else {
        sprintf_s(tmpbuf, sizeof tmpbuf,"17%s",trim(irelative_ply));
        rgu_put_body_string(22,tmpbuf,LEFT);
    }
    rgu_put_body(22);
    if  (policy_y == 'Y')
    {
       rgu_put_body_string(23,yy1,RIGHT);
       rgu_put_body_string(23,mm1,RIGHT);
       rgu_put_body_string(23,dd1,RIGHT);
    }else {
       rgu_put_body_string(23," ",RIGHT);
       rgu_put_body_string(23," ",RIGHT);
       rgu_put_body_string(23," ",RIGHT);}

    rgu_put_body(23);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(26);
    rgu_put_body(1);
    rgu_put_body(28);
    rgu_put_body(1);
    rgu_put_body(30);
    rgu_put_body(31);
    rgu_put_body(32);
    rgu_put_body(1);
    rgu_put_body(34);
    rgu_put_body(1);
    rgu_put_body_string(36,nbrand_abbr,LEFT);
    if (qcylinder == 0)
    { rgu_put_body_string(36,"",LEFT);}
    else
    { strcpy(tmpbuf,itoa(qcylinder));
      rgu_put_body_string(36,tmpbuf,LEFT);
    }
    strncpy(tmpbuf,iengine,15);
    if(strlen(trim(iengine)) >15) 
     {
      strncpy(iengine_ext,iengine+15,5);
      iengine_ext[5]= '\0';
     }
    else
      iengine_ext[0] = '\0';
    tmpbuf[15] = '\0'; 
    printf ("iaaa[%s]\n",tmpbuf);
    rgu_put_body_string(36,tmpbuf,LEFT);
    rgu_put_body_string(36,fcomp_class,LEFT);
    rgu_put_body(36);
    rgu_put_body_string(37,iengine_ext,LEFT);
    rgu_put_body(37);
    rgu_put_body(1);
    
    if  (policy_y == 'Y')
    {
       rgu_put_body_string(39,yy1,RIGHT);
       rgu_put_body_string(39,mm1,RIGHT);
       rgu_put_body_string(39,dd1,RIGHT);
    }else {
       rgu_put_body_string(39," ",RIGHT);
       rgu_put_body_string(39," ",RIGHT);
       rgu_put_body_string(39," ",RIGHT);}
    rgu_put_body(39);

    rgu_put_body_string(40,Iofficer,LEFT); 
    rgu_put_body(40);
    rgu_put_body_string(41,Nofficer,LEFT); 
    rgu_put_body(41);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1); 
    rgu_put_body(1);

   max_count+=32;
}

void put_body5()
{
  char tmpbuf[150],tmpbuf1[150];
  char yy[10],mm[10],dd[10];
  int i;

rate_date=cm_ymd_cdate(cm_from_infdate_100(dply_begin));

  if ((ipolicy[0]!='\0')&&(ipolicy[0]!=' ')){
     if ((itag[0]!='\0')&&(itag[0]!=' '))
       { strcpy(Inumber, itag); }
     else
       { strcpy(Inumber, iengine); }

  }else{
     strcpy(fyear,"NNN");
  }

  for(i=0;i<3;i++){
    printf("ca_accident[%d]:[%c]%ld\n",i,fyear[i],qlia[i]);
    if (fyear[i]=='Y')
       strcpy(s_qlia[i],itoa(qlia[i]));
    else
       strcpy(s_qlia[i]," ");
  }
   if(mpremium==0)  /* �O�O */
    {
          rgu_put_body_string(21,"",RIGHT);
          rgu_put_body_string(21,"",RIGHT);
          rgu_put_body_string(21,"",RIGHT);
          rgu_put_body_string(21,"",RIGHT);
          rgu_put_body_string(21,"",RIGHT);
          rgu_put_body_string(58,"",RIGHT);
          rgu_put_body_string(58,"",RIGHT);
          rgu_put_body_string(58,"",RIGHT);
          rgu_put_body_string(58,"",RIGHT);
          rgu_put_body_string(58,"",RIGHT);
    }else{
       /* refmtamt() convert a money representation from long to currency format */
       /* MILLIONTH  means  $###,###,### */
       strcpy(mpremium_buf,refmtamt(mpremium,MILLIONTH));
       rgu_put_body_string(26,rtrim(mpremium_buf),LEFT);
       tmp_prem=mpremium/10000;
       other_prem=mpremium%10000;
       num_to_chinese(ch_amt,tmp_prem); /* �N���ԧB�Ʀr �ন ����j�g�Ʀr */
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(21,ch_amt,RIGHT);
       rgu_put_body_string(58,ch_amt,RIGHT);
       
       tmp_prem=other_prem/1000;
       other_prem=other_prem%1000;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(21,ch_amt,RIGHT);
       rgu_put_body_string(58,ch_amt,RIGHT);
       
       tmp_prem=other_prem/100;
       other_prem=other_prem%100;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(21,ch_amt,RIGHT);
       rgu_put_body_string(58,ch_amt,RIGHT);
       
       tmp_prem=other_prem/10;
       other_prem=other_prem%10;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(21,ch_amt,RIGHT);
       rgu_put_body_string(58,ch_amt,RIGHT);
       
       num_to_chinese(ch_amt,other_prem);
       if (other_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(21,ch_amt,RIGHT);
       rgu_put_body_string(58,ch_amt,RIGHT);
    }


/* ���q�{�������D�A�� icard[1] �i��P�_���N�q
    �B�e���T�A�̫e���@�w�n�����q�N�X '17'
   if (icard[1] <= 'Z' && icard[1] >='A')   
    {
    tmpbuf[0]=0;
    strcpy(tmpbuf1,icard);
  }else{
    strncpy(tmpbuf,icard,2); tmpbuf[2]=0;
    strcpy(tmpbuf1,"17");
    strcat(tmpbuf1,&icard);
  }  */
  
  strcpy(tmpbuf1,"17");
  strcat(tmpbuf1,&icard);
/*  rgu_put_body_string(22,tmpbuf1,RIGHT);  */
  
  if ( strncmp ( print_card ,"1",1) == 0 )
  {
    rgu_put_body_string(10,tmpbuf1,RIGHT);
    rgu_put_body_string(28,tmpbuf1,RIGHT);
    rgu_put_body_string(47,tmpbuf1,RIGHT);
    rgu_put_body_string(67,tmpbuf1,RIGHT);    
  }
  rgu_put_body(10);
  rgu_put_body(1);
  split_ch(nassured,tmpbuf,tmpbuf1,30);
  if (*fsex == '1')
       strcat(tmpbuf," ����");
  else if (*fsex == '2')
       strcat(tmpbuf," �p�j");
  tmpbuf[30]=0;
  tmpbuf1[30]=0;
  rgu_put_body_string(12,tmpbuf,LEFT);
  rgu_put_body_string(12,bcard1,LEFT);
  rgu_put_body_string(30,tmpbuf,LEFT);
  rgu_put_body_string(48,tmpbuf,LEFT);
  rgu_put_body_string(68,tmpbuf,LEFT);
  rgu_put_body(12);

  split_ch(aassured,tmpbuf,tmpbuf1,30);
  if (strlen(tmpbuf1)==0) {
      rgu_put_body_string(13," ",LEFT);
      rgu_put_body_string(49," ",LEFT);
      
      rgu_put_body_string(14,tmpbuf,LEFT);
      rgu_put_body_string(50,tmpbuf,LEFT);
  }
  else {
      rgu_put_body_string(13,tmpbuf,LEFT);
      rgu_put_body_string(49,tmpbuf,LEFT);
      
      rgu_put_body_string(14,tmpbuf1,LEFT);
      rgu_put_body_string(50,tmpbuf1,LEFT);
  }
  if (strncmp(ilicense," ",1)==0)
      if (strncmp(iassured,"AAAAAAAAAA",10)!=0)
          strcpy(ilicense,iassured);
  for(i=0;i<10;i++) 
  {
   strncpy(tmpbuf,ilicense+i,1);
   tmpbuf[1]='\0';
   rgu_put_body_string(14,tmpbuf,LEFT);
  }
  rgu_put_body_string(14,irelative_ply,LEFT);
  rgu_put_body(13);
  rgu_put_body(14);
  rgu_put_body(1);  
  rgu_put_body_string(36,nbrand_abbr,LEFT);
  rgu_put_body_string(74,nbrand_abbr,LEFT);
  rgu_put_body_string(34,ncar_abbr,LEFT);
  rgu_put_body_string(72,ncar_abbr,LEFT);
  nbrand_abbr[8]=0;
  ncar_abbr[6]=0;
  rgu_put_body_string(16,ncar_abbr,LEFT);
  rgu_put_body_string(16,nbrand_abbr,LEFT);
  rgu_put_body_string(52,ncar_abbr,LEFT);
  rgu_put_body_string(52,nbrand_abbr,LEFT);
  
  strcpy(yy,iissue_ym);
  yy[3]=0;
  rgu_put_body_string(16,yy,LEFT);
  rgu_put_body_string(34,yy,LEFT);
  rgu_put_body_string(52,yy,LEFT);
  rgu_put_body_string(72,yy,LEFT);
  printf(" ---- itag = [%s]\n",itag);
  if ((itag[0]!='\0')&&(itag[0]!=' '))
     {
       itag[20]=0;
       rgu_put_body_string(16,itag,LEFT);
       rgu_put_body_string(34,itag,LEFT);
       rgu_put_body_string(52,itag,LEFT);
       rgu_put_body_string(72,itag,LEFT);
     }
  else
     {
       iengine[20]=0;
       printf("iengine[%s]\n",iengine);
       rgu_put_body_string(16,iengine,LEFT);
       rgu_put_body_string(34," ",LEFT);
       rgu_put_body_string(52,iengine,LEFT);
       rgu_put_body_string(72," ",LEFT);
     }
  rgu_put_body(16);
  if(dply_begin[0]==0)
  {
       rgu_put_body_string(17,"",LEFT);
       rgu_put_body_string(17,"",LEFT);
       rgu_put_body_string(17,"",LEFT);
  }else{
       strcpy(tmpbuf,cm_from_infdate_100(dply_begin));
       cm_split_ymd_100(tmpbuf,yy,mm,dd);
       rgu_put_body_string(17,yy,LEFT);
       rgu_put_body_string(31,yy,LEFT);
       rgu_put_body_string(53,yy,LEFT);
       rgu_put_body_string(69,yy,LEFT);
       rgu_put_body_string(17,mm,LEFT);
       rgu_put_body_string(31,mm,LEFT);
       rgu_put_body_string(53,mm,LEFT);
       rgu_put_body_string(69,mm,LEFT);
       rgu_put_body_string(17,dd,LEFT);
       rgu_put_body_string(31,dd,LEFT);
       rgu_put_body_string(53,dd,LEFT);
       rgu_put_body_string(69,dd,LEFT);
  }
  if(qperiod==0)
   {
       rgu_put_body_string(17,qperiod,LEFT);
       rgu_put_body_string(31,qperiod,LEFT);
       rgu_put_body_string(53,qperiod,LEFT);
       rgu_put_body_string(69,qperiod,LEFT);
   } else
   {
       strcpy(tmpbuf,itoa(qperiod));
       rgu_put_body_string(17,tmpbuf,LEFT);
       rgu_put_body_string(31,tmpbuf,LEFT);
       rgu_put_body_string(53,tmpbuf,LEFT);
       rgu_put_body_string(69,tmpbuf,LEFT);
   }

  if (ibirth[0]==0) {
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"",LEFT);
  }else{
         cm_split_ymd_100(ibirth,yy,mm,dd);
         rgu_put_body_string(17,yy,LEFT);
         rgu_put_body_string(17,mm,LEFT);
         rgu_put_body_string(17,dd,LEFT);
  }

  if(fsex[0]=='1'){
         rgu_put_body_string(17,"v",LEFT);
         rgu_put_body_string(17,"",LEFT);
  }else if(fsex[0]=='2'){
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"v",LEFT);
  }else{
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"",LEFT);
  }
  if (fmarriage[0]=='1'){
         rgu_put_body_string(17,"v",LEFT);
         rgu_put_body_string(17,"",LEFT);
  } else if (fmarriage[0]=='2') {
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"v",LEFT);
  }else{
         rgu_put_body_string(17,"",LEFT); 
         rgu_put_body_string(17,"",LEFT);
  }
  rgu_put_body_string(17,fcomp_class_last,LEFT);
  rgu_put_body(17);
  if(dply_end[0]==0)
    {
        rgu_put_body_string(18,"",LEFT);
        rgu_put_body_string(18,"",LEFT);
        rgu_put_body_string(18,"",LEFT);
    } else
    {
        strcpy(tmpbuf,cm_from_infdate_100(dply_end));
        cm_split_ymd_100(tmpbuf,yy,mm,dd);
        rgu_put_body_string(18,yy,LEFT);
        rgu_put_body_string(18,mm,LEFT);
        rgu_put_body_string(18,dd,LEFT);
        rgu_put_body_string(32,yy,LEFT);
        rgu_put_body_string(32,mm,LEFT);
        rgu_put_body_string(32,dd,LEFT);
        rgu_put_body_string(54,yy,LEFT);
        rgu_put_body_string(54,mm,LEFT);
        rgu_put_body_string(54,dd,LEFT);
        rgu_put_body_string(70,yy,LEFT);
        rgu_put_body_string(70,mm,LEFT);
        rgu_put_body_string(70,dd,LEFT);
    }
   if (fpt == 'P')
     {
          sprintf_s(cqpt, sizeof cqpt,"%5.0f",qpt); 
          printf("cqpt---->%s\n",cqpt);
          rgu_put_body_string(18, cqpt, LEFT);    
     }
   else if ( fpt == 'T')
     {
          rgu_put_body_string(18,"",RIGHT);
          sprintf_s(cqpt, sizeof cqpt,"%5.1f", qpt);
          rgu_put_body_string(18,cqpt,LEFT);
     } 
   else
      {
          rgu_put_body_string(18,"",RIGHT);
          rgu_put_body_string(18,"",LEFT);
      }
    rgu_put_body(18);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(21);
/*    if (strlen(irelative_ply)==0)
        rgu_put_body_string(22," ",LEFT);
    else {
        sprintf_s(tmpbuf, sizeof tmpbuf,"17%s",trim(irelative_ply));
        rgu_put_body_string(22,tmpbuf,LEFT);
    }  */
    rgu_put_body_string(22,irelative_card,LEFT);
    rgu_put_body(22);
    if  (policy_y == 'Y')
    {
       rgu_put_body_string(23,yy1,RIGHT);
       rgu_put_body_string(23,mm1,RIGHT);
       rgu_put_body_string(23,dd1,RIGHT);
       rgu_put_body_string(59,yy1,RIGHT);
       rgu_put_body_string(59,mm1,RIGHT);
       rgu_put_body_string(59,dd1,RIGHT);
    }else {
       rgu_put_body_string(23," ",RIGHT);
       rgu_put_body_string(23," ",RIGHT);
       rgu_put_body_string(23," ",RIGHT);
       rgu_put_body_string(59," ",RIGHT);
       rgu_put_body_string(59," ",RIGHT);
       rgu_put_body_string(59," ",RIGHT);}

    rgu_put_body(23);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(26);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(28);
    rgu_put_body(30);
    rgu_put_body(31);
    rgu_put_body(32);
    rgu_put_body(1);
    rgu_put_body(34);
    rgu_put_body(1);
    if (qcylinder == 0)
    { rgu_put_body_string(36,"",LEFT);
       rgu_put_body_string(74,"",LEFT); }
    else
    { strcpy(tmpbuf,itoa(qcylinder));
      rgu_put_body_string(36,tmpbuf,LEFT);
      rgu_put_body_string(74,tmpbuf,LEFT);
    }
    strncpy(tmpbuf,iengine,15);
    if(strlen(trim(iengine)) >15) 
     {
      strncpy(iengine_ext,iengine+15,5);
      iengine_ext[5]= '\0';
     }
    else
      iengine_ext[0] = '\0';
    tmpbuf[15] = '\0'; 
    printf ("iaaa[%s]\n",tmpbuf);
    rgu_put_body_string(36,tmpbuf,LEFT);
    rgu_put_body_string(74,tmpbuf,LEFT);
    rgu_put_body_string(36,fcomp_class,LEFT);
    rgu_put_body_string(74,fcomp_class,LEFT);
    rgu_put_body(36);
    rgu_put_body(1);
    rgu_put_body_string(37,iengine_ext,LEFT);
    rgu_put_body(37);
    
    if  (policy_y == 'Y')
    {
       rgu_put_body_string(39,yy1,RIGHT);
       rgu_put_body_string(39,mm1,RIGHT);
       rgu_put_body_string(39,dd1,RIGHT);
       rgu_put_body_string(77,yy1,RIGHT);
       rgu_put_body_string(77,mm1,RIGHT);
       rgu_put_body_string(77,dd1,RIGHT);
    }else {
       rgu_put_body_string(39," ",RIGHT);
       rgu_put_body_string(39," ",RIGHT);
       rgu_put_body_string(39," ",RIGHT);
       rgu_put_body_string(77," ",RIGHT);
       rgu_put_body_string(77," ",RIGHT);
       rgu_put_body_string(77," ",RIGHT);}
    rgu_put_body(39);

    rgu_put_body_string(40,Iofficer,LEFT); 
    rgu_put_body(40);
    rgu_put_body_string(41,Nofficer,LEFT); 
    rgu_put_body(41);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1); 
    rgu_put_body(47);
    rgu_put_body(1);
    rgu_put_body(48);
    rgu_put_body(49);
    rgu_put_body(50);
    rgu_put_body(1);
    rgu_put_body(52);
    rgu_put_body(53);
    rgu_put_body(54);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(58);
    rgu_put_body(1);
    rgu_put_body(59);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(67);
    rgu_put_body(68);
    rgu_put_body(69);
    rgu_put_body(70);
    rgu_put_body(1);
    rgu_put_body(72);
    rgu_put_body(1);
    rgu_put_body(74);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(77);   
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1);
    
   max_count+=64;
}

void put_body6() /* �O�N��print_frm=3, car2z34.fmt          */
{
  char tmpbuf[150],tmpbuf1[150];
  char yy[10],mm[10],dd[10];
  int i;

rate_date=cm_ymd_cdate(cm_from_infdate_100(dply_begin));


  if ((ipolicy[0]!='\0')&&(ipolicy[0]!=' ')){
     if ((itag[0]!='\0')&&(itag[0]!=' '))
       { strcpy(Inumber, itag); }
     else
       { strcpy(Inumber, iengine); }
/**  crystal-removed at 87/01/19 
     ca_accident_record(DBName,Inumber ,rate_date,"1", qdmg,qlia, mdmg,mlia,
                        &qdmg_acc,&qlia_acc, &pdmg_acc,&plia_acc,fyear);
**/
  }else{
     strcpy(fyear,"NNN");
  }

  for(i=0;i<3;i++){
    printf("ca_accident[%d]:[%c]%ld\n",i,fyear[i],qlia[i]);
    if (fyear[i]=='Y')
       strcpy(s_qlia[i],itoa(qlia[i]));
    else
       strcpy(s_qlia[i]," ");
  }
   if(mpremium==0)  /* �O�O */
    {
          rgu_put_body_string(19,"",RIGHT);
          rgu_put_body_string(19,"",RIGHT);
          rgu_put_body_string(19,"",RIGHT);
          rgu_put_body_string(19,"",RIGHT);
          rgu_put_body_string(19,"",RIGHT);
    }else{
       /* refmtamt() convert a money representation from long to currency format */
       /* MILLIONTH  means  $###,###,### */
       strcpy(mpremium_buf,refmtamt(mpremium,MILLIONTH));
       rgu_put_body_string(27,rtrim(mpremium_buf),LEFT);
       tmp_prem=mpremium/10000;
       other_prem=mpremium%10000;
       num_to_chinese(ch_amt,tmp_prem); /* �N���ԧB�Ʀr �ন ����j�g�Ʀr */
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(19,ch_amt,RIGHT);

       tmp_prem=other_prem/1000;
       other_prem=other_prem%1000;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(19,ch_amt,RIGHT);

       tmp_prem=other_prem/100;
       other_prem=other_prem%100;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(19,ch_amt,RIGHT);

       tmp_prem=other_prem/10;
       other_prem=other_prem%10;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(19,ch_amt,RIGHT);

       num_to_chinese(ch_amt,other_prem);
       if (other_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(19,ch_amt,RIGHT);
    }


/* ���q�{�������D�A�� icard[1] �i��P�_���N�q
    �B�e���T�A�̫e���@�w�n�����q�N�X '17'
   if (icard[1] <= 'Z' && icard[1] >='A')   
    {
    tmpbuf[0]=0;
    strcpy(tmpbuf1,icard);
  }else{
    strncpy(tmpbuf,icard,2); tmpbuf[2]=0;
    strcpy(tmpbuf1,"17");
    strcat(tmpbuf1,&icard);
  }  */
  
  strcpy(tmpbuf1,"17");
  strcat(tmpbuf1,&icard);
/*  rgu_put_body_string(19,tmpbuf1,RIGHT);  */
  
  if ( strncmp ( print_card ,"1",1) == 0 )
  {
    rgu_put_body_string(10,tmpbuf1,RIGHT);
    rgu_put_body_string(28,tmpbuf1,RIGHT);
  }
  rgu_put_body(10);
  rgu_put_body(1);
  split_ch(nassured,tmpbuf,tmpbuf1,30);
  if (*fsex == '1')
       strcat(tmpbuf," ����");
  else if (*fsex == '2')
       strcat(tmpbuf," �p�j");
  tmpbuf[30]=0;
  tmpbuf1[30]=0;
  rgu_put_body_string(12,tmpbuf,LEFT);
  rgu_put_body_string(30,tmpbuf,LEFT);

  rgu_put_body(12);

  split_ch(aassured,tmpbuf,tmpbuf1,36);
  if (strlen(tmpbuf1)==0) {
      rgu_put_body_string(13," ",LEFT);

      rgu_put_body_string(14,tmpbuf,LEFT);
  }
  else {
      rgu_put_body_string(13,tmpbuf,LEFT);

      rgu_put_body_string(14,tmpbuf1,LEFT);
  }

  if (strncmp(ilicense," ",1)==0)
      if (strncmp(iassured,"AAAAAAAAAA",10)!=0)
          strcpy(ilicense,iassured);
  for(i=0;i<10;i++) 
  {
   strncpy(tmpbuf,ilicense+i,1);
   tmpbuf[1]='\0';
   rgu_put_body_string(15,tmpbuf,LEFT);
  }
  rgu_put_body_string(13,bcard1,LEFT);
  rgu_put_body(13);
  rgu_put_body(14);
  rgu_put_body(15);
  rgu_put_body_string(34,ncar_abbr,LEFT);
  rgu_put_body_string(36,nbrand_abbr,LEFT);
  ncar_abbr[6]=0;
  nbrand_abbr[6]=0;
  rgu_put_body_string(16,nbrand_abbr,LEFT);
  rgu_put_body_string(16,ncar_abbr,LEFT);

  strcpy(yy,iissue_ym);
  yy[3]=0;
  rgu_put_body_string(16,yy,LEFT);
  rgu_put_body_string(34,yy,LEFT);
  printf(" ---- itag = [%s]\n",itag);
  if ((itag[0]!='\0')&&(itag[0]!=' '))
     {
       itag[20]=0;
       rgu_put_body_string(16,itag,LEFT);
       rgu_put_body_string(34,itag,LEFT);
     }
  else
     {
       rgu_put_body_string(16," ",LEFT);
       rgu_put_body_string(34," ",LEFT);
     }

  iengine[20]=0;
  printf("iengine[%s]\n",iengine);
  rgu_put_body_string(16,iengine,LEFT);
  rgu_put_body(16);
  if(dply_begin[0]==0)
  {
       rgu_put_body_string(17,"",LEFT);
       rgu_put_body_string(17,"",LEFT);
       rgu_put_body_string(17,"",LEFT);
       rgu_put_body_string(31,"",LEFT);
       rgu_put_body_string(31,"",LEFT);
       rgu_put_body_string(31,"",LEFT);
  }else{
       strcpy(tmpbuf,cm_from_infdate_100(dply_begin));
       cm_split_ymd_100(tmpbuf,yy,mm,dd);
       rgu_put_body_string(17,yy,LEFT);
       rgu_put_body_string(31,yy,LEFT);
       rgu_put_body_string(17,mm,LEFT);
       rgu_put_body_string(31,mm,LEFT);
       rgu_put_body_string(17,dd,LEFT);
       rgu_put_body_string(31,dd,LEFT);
  }
  if(qperiod==0)
   {
       rgu_put_body_string(17,qperiod,LEFT);
       rgu_put_body_string(31,qperiod,LEFT);
   } else
   {
       strcpy(tmpbuf,itoa(qperiod));
       rgu_put_body_string(17,tmpbuf,LEFT);
       rgu_put_body_string(31,tmpbuf,LEFT);
   }
 if(dply_end[0]==0)
   {
       rgu_put_body_string(18,"",LEFT);
       rgu_put_body_string(18,"",LEFT);
       rgu_put_body_string(18,"",LEFT);
       rgu_put_body_string(32,"",LEFT);
       rgu_put_body_string(32,"",LEFT);
       rgu_put_body_string(32,"",LEFT);
   } else
   {
       strcpy(tmpbuf,cm_from_infdate_100(dply_end));
       cm_split_ymd_100(tmpbuf,yy,mm,dd);
       rgu_put_body_string(18,yy,LEFT);
       rgu_put_body_string(18,mm,LEFT);
       rgu_put_body_string(18,dd,LEFT);
       rgu_put_body_string(32,yy,LEFT);
       rgu_put_body_string(32,mm,LEFT);
       rgu_put_body_string(32,dd,LEFT);
   }
  if (ibirth[0]==0) {
         rgu_put_body_string(18,"",LEFT);
         rgu_put_body_string(18,"",LEFT);
         rgu_put_body_string(18,"",LEFT);
  }else{
         cm_split_ymd_100(ibirth,yy,mm,dd);
         rgu_put_body_string(18,yy,LEFT);
         rgu_put_body_string(18,mm,LEFT);
         rgu_put_body_string(18,dd,LEFT);
  }

  if(fsex[0]=='1'){
         rgu_put_body_string(18,"v",LEFT);
         rgu_put_body_string(18,"",LEFT);
  }else if(fsex[0]=='2'){
         rgu_put_body_string(18,"",LEFT);
         rgu_put_body_string(18,"v",LEFT);
  }else{
         rgu_put_body_string(18,"",LEFT);
         rgu_put_body_string(18,"",LEFT);
  }
  if (fmarriage[0]=='1'){
         rgu_put_body_string(18,"v",LEFT);
         rgu_put_body_string(18,"",LEFT);
  } else if (fmarriage[0]=='2') {
         rgu_put_body_string(18,"",LEFT);
         rgu_put_body_string(18,"v",LEFT);
  }else{
         rgu_put_body_string(18,"",LEFT); 
         rgu_put_body_string(18,"",LEFT);
  }
  rgu_put_body_string(18,fcomp_class_last,LEFT);
  rgu_put_body(17);

   if (fpt == 'P')
     {
          sprintf_s(cqpt, sizeof cqpt,"%5.0f",qpt); 
          printf("cqpt---->%s\n",cqpt);
          rgu_put_body_string(20, cqpt, LEFT);    
     }
   else if ( fpt == 'T')
     {
          rgu_put_body_string(20,"",RIGHT);
          sprintf_s(cqpt, sizeof cqpt,"%5.1f", qpt);
          rgu_put_body_string(20,cqpt,LEFT);
     } 
   else
      {
          rgu_put_body_string(20,"",RIGHT);
          rgu_put_body_string(20,"",LEFT);
      }
    if (strlen(irelative_ply)==0)
        rgu_put_body_string(19," ",LEFT);
    else {
        sprintf_s(tmpbuf, sizeof tmpbuf,"17%s",trim(irelative_ply));
        rgu_put_body_string(19,tmpbuf,LEFT);
    } 
    if (strlen(irelative_card)==0)
        rgu_put_body_string(19," ",LEFT);
    else {
        rgu_put_body_string(19,irelative_card,LEFT);
    }
    rgu_put_body(18);
    rgu_put_body(19);
    rgu_put_body(20);
    rgu_put_body(1);

    rgu_put_body(1);
    if  (policy_y == 'Y')
    {
       rgu_put_body_string(24,yy1,RIGHT);
       rgu_put_body_string(24,mm1,RIGHT);
       rgu_put_body_string(24,dd1,RIGHT);
    }else {
       rgu_put_body_string(24," ",RIGHT);
       rgu_put_body_string(24," ",RIGHT);
       rgu_put_body_string(24," ",RIGHT);}

    rgu_put_body(1);
    rgu_put_body(24);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(27);
    rgu_put_body(28);
    rgu_put_body(1);
    rgu_put_body(30);
    rgu_put_body(31);
    rgu_put_body(32);
    rgu_put_body(1);
    rgu_put_body(34);
    rgu_put_body(1);
    if (qcylinder == 0)
    { rgu_put_body_string(36,"",LEFT);}
    else
    { strcpy(tmpbuf,itoa(qcylinder));
      rgu_put_body_string(36,tmpbuf,LEFT);
    }
    strncpy(tmpbuf,iengine,15);
    if(strlen(trim(iengine)) >15) 
     {
      strncpy(iengine_ext,iengine+15,5);
      iengine_ext[5]= '\0';
     }
    else
      iengine_ext[0] = '\0';
    tmpbuf[15] = '\0'; 
    printf ("iaaa[%s]\n",tmpbuf);
    rgu_put_body_string(36,tmpbuf,LEFT);
    rgu_put_body_string(36,fcomp_class,LEFT);
    rgu_put_body(36);
    rgu_put_body_string(37,iengine_ext,LEFT);
    rgu_put_body(37);
    rgu_put_body(1);
    
    if  (policy_y == 'Y')
    {
       rgu_put_body_string(39,yy1,RIGHT);
       rgu_put_body_string(39,mm1,RIGHT);
       rgu_put_body_string(39,dd1,RIGHT);
    }else {
       rgu_put_body_string(39," ",RIGHT);
       rgu_put_body_string(39," ",RIGHT);
       rgu_put_body_string(39," ",RIGHT);}
    rgu_put_body(39);

    rgu_put_body_string(40,Iofficer,LEFT); 
    rgu_put_body(40);
    rgu_put_body_string(41,Nofficer,LEFT); 
    rgu_put_body(41);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1); 
    rgu_put_body(1);

   max_count+=32;
}
/*------------------------------------------------------end program*/
