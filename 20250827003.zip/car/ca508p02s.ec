/*-------------------------------------------------------------------
 * Program    : ca508p02s.ec      (background process)
 * Date       : 12/19/1994
 * edit by tony, S.Y.HWANG.870601
 *-------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <decimal.h>

#include "is_def.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "glsstru.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "comdata.h"
#include "cm_ply_info.h"
#include "cm_plyins_info.h"
#include "ca_data.h"

$include sqlca;
$include datetime;
$include sqltypes;
$include "ply_ins_cover.h";
$include "ply_ins_assured.h";
$include "var_length.h";

#define TRUE                    1
#define FALSE                   0
#define FOUND                   sqlca.sqlcode!=SQLNOTFOUND
#define NOT_FOUND               sqlca.sqlcode==SQLNOTFOUND
#define EQUAL(s1,s2)            !strcmp(s1,s2)
#define NOT_EQUAL(s1,s2)        strcmp(s1,s2)

/**********************************************/
$char  err_buf[1200];
$char  DBname[3], userid[11], outputf[21], creator[11], ivoucher[VOUCHER_NUM];
char   ch_dwritten[16], ch_next_dwritten[16];
$char  provision[21], drate_ym[5];
$date  Today, dwritten, next_dwritten;
$char  inf_dclose[15];

$date  edrdate;
char   fIFRS17 = ''; 

long   db_num;
DBinfo *list;

int    flag_no_edr=0;

$double tmp_mpure_prem;

/*-----------------------------------------------------------*/
long    tot_pos_41_prem,tot_pos_31_prem,tot_pos_32_prem;
long    tot_pos_41_agent,tot_pos_31_agent,tot_pos_32_agent;
long    tot_pos_41_service,tot_pos_31_cms,tot_pos_32_cms;
long    tot_pos_agent,tot_pos_cms;
long    tot_pos_dmg_discount,tot_pos_lia_discount;

long    tot_neg_41_prem,tot_neg_31_prem,tot_neg_32_prem;
long    tot_neg_31_prem_1,tot_neg_32_prem_1;
long    tot_pos_31_prem_1,tot_pos_32_prem_1;
long    tot_neg_41_agent,tot_neg_31_agent,tot_neg_32_agent;
long    tot_neg_41_service,tot_neg_31_cms,tot_neg_32_cms;
long    tot_neg_agent,tot_neg_cms;
long    tot_neg_dmg_discount,tot_neg_lia_discount;
/*-------------------------------------------------------------*/

$char ptype_CAE[5]="CAE";
$char ptype_CBE[5]="CBE";
$char ptype_CAN[5]="CAN";
$char ptype_CBN[5]="CBN";
$char ptype_CXE[4]="CXE";

$char ptype_C[2]="C";
$char ptype_Z[2]="Z";
$char ptype_M[2]="M";
$char ptype_V[2]="V";

$char CAEmaxp[ENDORSE_NUM];
$char CBEmaxp[ENDORSE_NUM];
$char CANmaxp[ENDORSE_NUM];
$char CBNmaxp[ENDORSE_NUM];
$char CXEmaxp[ENDORSE_NUM];

$char Cmaxp[ENDORSE_NUM];
$char Zmaxp[ENDORSE_NUM];
$char Mmaxp[ENDORSE_NUM];
$char Vmaxp[ENDORSE_NUM];

/*--------------------------------------------*/
struct EDR_LIST {
    char iendorse[ENDORSE_NUM];
    char assuredn[121];
    char assureda[65];
    char assuredi[13];
    char assuredi_ext[3];
    char car_type[3];
    char brand[9];
    char tagnum[CA_TAG_NUM];
    char body[CA_BODY_NUM];
    char engine[CA_ENGINE_NUM];
    char treaty[2];
    char icard[CARD_NUM];
    char fcard_class[2];
    char fedr_class[2];
    char iofficer[11];
    char ibig_office[10];
    char ibroker[BROKER];
    char ipolicy[POLICY_NUM_1];
    char irelative_ply[POLICY_NUM_1];
    char fpay[2];
    char ipay[POLICY_NUM_1];
    char irecover_num[ENDORSE_NUM];
    char iresource[2];
    char iedr_area[11];
    char iedr_cashier[EMPLOYEE_ID];
    char ibig_sales[EMPLOYEE_ID];
    long dendorse;
    long ply_begin;
    long ply_end;
    long qply_period;
    long edr_begin;
    long edr_end;
    long edr_mprem;
    long edr_magent;
    long edr_mcommi;
    long edr_mdisc;
    char ffac[3];
    double mcompensate;
    char fdiscount[2];
    char ibig_comp[2];
    char icorps[CORP_ID];
    char icomp_in[BRANCH_ID];
    char ibranch_in[BRANCH_ID];
    char iquota[CA_SA_QUOTA];
    char ileader[LEADER];
    char icar_flag[2];
    int  check_910401;
    char iedr_type[2];
    char payresult[4];
    int  qcount;
    char nequipment[31];
    char ibenef[11];
    char zip[CA_ZIP];
    char ibroker_top[BROKER];
    char assuredf[2];
    char iapplicant[IASSURED];
    char napplicant[101];
    char apayment[91];
    char iedr_return[2];
    char iroute[21];
    char icomm_obj[11];
    char dcreate[31];
    char icard_main[21];
    char dtedr_begin[17];  /* 1061108001_SC6_�t�X�s�еo�i���ߨt�λݨD���Ѭ����t�Υ\�� yyyy-mm-dd HH:MM */
    char dtedr_end[17];   
    char dtply_begin[17];
    char dtply_end[17];
    char iroute_accept[21];  /* 1071225004_SC1_ ����_���I�W��ѽվ�*/
    char iscan_no[26];       /* 1080730005_SC2 �q�lñ�p���ظm�@�~*//* 1101018008_SC2 �q�lñ�ݱ��y�s������X�W��25�X */
    char iquote[21];         /* 1110607001_SC1 �ظmE�O�����t�� */
    struct EDR_LIST *next;
};
struct EDR_LIST *EdrFirst, *EdrCurr, *EdrLast;

/*--------------------------------------------*/
long Car508_P();
long sa_customer_quota();
long glAutoVochLong();
long UpdateAssured_ply();
long ca_up_frcvpay();
extern void trim_cspace();
static int   DiffMonth();    /* input data should be date format */
FILE   *sfp;
char    v_sMsg[1512], sErrMsg[1024];

$char   v_iendorse[21], v_ipolicy[21], fclose_type[2], fwork[2];
$char   ipgid[11];
char  aphome[40];
int   res;
char cmd_stmt[1024];
/**********************************************************************/
main(argc, argv)
int argc;
char **argv;
{
    long rc;

    batchinit();
    strcpy(DBname,isNULLstr(argv[1]));
    strcpy(userid,isNULLstr(argv[2]));
    strcpy(fclose_type,isNULLstr(argv[3]));  /* S:�浧, B:��� */
    strcpy(ch_dwritten,isNULLstr(argv[4]));  /* �鵲���,�鵲���� */
    strcpy(ch_next_dwritten,isNULLstr(argv[5]));  /* ���鵲��,�D�鵲���� */
    strcpy(v_iendorse,isNULLstr(argv[6]));  /* ��渹(car426�浧�鵲�ϥ�) */ 
    strcpy(v_ipolicy,isNULLstr(argv[7]));  /* �O�渹(car426�浧�鵲�ϥ�)  */
    strcpy(creator,isNULLstr(argv[8]));
    strcpy(outputf,isNULLstr(argv[9]));

    strcpy( ipgid, "car5082");
    dwritten=cm_ymd_cdate(ch_dwritten);
    next_dwritten=cm_ymd_cdate(ch_next_dwritten);

    strcpy(inf_dclose, cm_to_infdate(ch_dwritten));

    printf("*tp[%s] d[%s] n_d[%s] inf_dclose[%s]\n",fclose_type,ch_dwritten,ch_next_dwritten,inf_dclose);

    rtoday(&Today);                             /* get today's datetime */

    sfp =  (FILE *)STARTLOG();

    if (db_select(DBname) == False)
    {
        EWRITE(userid,M_CM_DB_NOTOPEN,"M_CM_DB_NOTOPEN");
        return 0;
    }
    memset(err_buf,0,sizeof(err_buf));
    rc=Car508_P();

    if (rc != M_CM_OK)
    {
        EWRITE(userid,rc,err_buf);
        return rc;
    }
    FreeEdrList(EdrFirst,EdrCurr);

    /**** else return code == M_CM_OK ****/
    printf("return success\n");

    WRITELOG( sfp, "���鵲����");
    ENDLOG(sfp);

    return SUCCESS;
}

/*****************************************************************/
long Car508_P()
{
    $int    i=0, j=0, k=0, yr_cnt=0;
    long    rc;
    $date   dlast_closing;
    $long   edr_begin, edr_end;
    $long   ori_begin, ori_end;
    $long   ply_begin, ply_end;
    $long   qply_period;

    $char   dtedr_begin[17],dtedr_end[17];  /* 1061108001_SC6_�t�X�s�еo�i���ߨt�λݨD���Ѭ����t�Υ\�� yyyy-mm-dd HH:MM */    
    $char   dtply_begin[17],dtply_end[17];
    $char   ori_dtply_begin[17],ori_dtply_end[17];

    $char   qw_num[ENDORSE_NUM],icashier[EMPLOYEE_ID],isub[3],insure_type[2];
    $char   fpay[2], ipay[POLICY_NUM_1], recover_num[ENDORSE_NUM], ftype[2];
    $char   iunit[BRANCH_ID];
    $char   datestr[10],yy1[3],mm1[3],dd1[3], yymm[5];

    $char   ply1[POLICY_NUM_1],ply2[POLICY_NUM_2],fins_grp[2];
    $char   iedr_area[11],iresource[2];

    $long   tmp_mprem,mprem,mpremium,mdeal,mprem1,mprem2,mprem33;
    $long   medrins_prem,qaddedr_dis31,maddedr_dis31,qaddedr_dis32,maddedr_dis32;
    $long   mdiscount1,mdiscount2,medr_commission,medr_discount;

    $long   qwdraw_dis31,mwdraw_dis31,qwdraw_dis32,mwdraw_dis32;

    $long   medrins_prem31,medr_commission31,medr_agent31,medr_discount31;
    $long   medrins_prem32,medr_commission32,medr_agent32,medr_discount32;
    $long   qedrins_prem31,qedr_discount31;
    $long   qedrins_prem32,qedr_discount32;

    $long   tmp_commi, tmp_agent;

    $long   tmp_prem1, tmp_prem2, tmp_prem33;
    $long   total_mprem;
    $long   total_magent;
    $long   total_mcommission;

    $long   tmp_commission1, tmp_commission2, tmp_commission33;
    $long   tmp_agent1, tmp_agent2, tmp_agent33;
    $long   tmp_disc1, tmp_disc2, tmp_disc33;
    $long   tmp_discount1, tmp_discount2, tmp_discount33;

    $long   mcommission1, mcommission2, magent1, magent2;
    $long   mcommission33 , magent33;
    $long   mprem12, mcommission12, magent12, mdiscount12;
    $long   mdisc12, mdisc1, mdisc2, medr_disc;

    $char   stmt_buf[1024], stmt1[512], stmt2[512], stmt3[512], stmt4[512];
    $char   ipolicy[POLICY_NUM_1],tagnum[CA_TAG_NUM],body[CA_BODY_NUM],engine[CA_ENGINE_NUM],treaty[2];
    $char   irelative_ply[POLICY_NUM_1];
    $char   assuredi[13],assuredn[121],assureda[65],assureda_a[65],apayment[91];
    $char   assuredi_ext[3];
    $char   iquota[11];
    $char   icard[CARD_NUM],fcard_class[2],iofficer[11];
    $char   icar_type[3], ibig_sales[EMPLOYEE_ID];
    $char   ibroker[BROKER],ins_type[7], ibroker_top[BROKER];
    $char   ibig_office[10], iins_type[7], fdiscount[2], iins_typeTmp[7];
    $char   iendorse[21],fedr_class[2],iedr_type[3], dcreate[31], icard_main[21];
    $char   fcommit[3],ffac[3];
    $double mcompensate, tmp_mcompensate;
    $long   mcompensate_l;
    $int    ibatch_no, iHave_amt;
    $char   iroute[21];  /* bis9901141 �s�W�q���N�� */

    $char   icomm_obj[11]; /* 1000311003 �q��2 */ 
    long    rtncode;

    $long   minjured_cover,mdeath_cover,mdamage_cover,mdeduct,mins_premium;
    $long   qday,mexpense,daily_pay;
    $long   magent,mcommission,mdiscount;
    
    $char   ibig_comp[2];
    $char   ibenef[11], zip[CA_ZIP];
    $double ptax, ptax_1;
    
    $char   tmp_ptax[12], rpt_type[2];
    dec_t   dec_ptax;

    $long   prem1, prem2;
    $long   medr_prem, medr_agent;
    $long   mdmg_prem,mdmg_agent,mdmg_commi,mlia_prem,mlia_agent,mlia_commi;
    $long   medrdmg_prem,medrdmg_agent,medrdmg_commi, medrdmg_disc;
    $long   medrlia_prem,medrlia_agent,medrlia_commi, medrlia_disc;
    $long   medrlia_prem_33,medrlia_agent_33,medrlia_commi_33, medrlia_disc_33;
    $char   transno[21],transno2[21];

    int     flag_ins;
    int     edr_cnt=0;
    int     fInsert_ao=FALSE;

    $struct Rec508 {
            char yr[3];
    };
    $struct Rec508 Year[5];

    $char sStmt[1024];

    $long magent41,magent32,magent31;
    $long mdeal41,mcommit32,mcommit31;

    $long qaddedr41,qaddedr32,qaddedr31;
    $long maddedr41,maddedr32,maddedr31;
    $long qwdraw41,qwdraw32,qwdraw31;
    $long mwdraw41,mwdraw32,mwdraw31;
    $char fbig_rcv;
    char  tmp_str[10];
    int   tmp_int;
    long  rtn_code;
    double dTmpPrem;

    int    check_910401;

    $char  iinsurant[11], iins_scope[2], icareer[2];
    $long  mins_amt;
    $char  payresult[4];

    $char tmp_iproduct[3];
    $long tmp_qply_period, iCount, iLatest;

    $char iproduct[13], iendorse_next[21];
    $char kclsfyitem[5];
    $char kreserve[6];
    $char icorps[11];
    $char nequipment[31];
    $char itag_number[CA_TAG_NUM], itag_last[CA_TAG_NUM], itag_next[CA_TAG_NUM];
    $char card_YTA[21], assuredf[2], tmp_assuredi[13];
    $long mcommitMain, magentMain, mdealMain;
    $long mcommitDetail, magentDetail, mdealDetail;

    /* ply_ins_cover */
    $char   icover_type[ICOVER_TYPE];             /* �O�B���� */
    $long   mcover;                               /* �O�B */
    $long   mcover_prem;                          /* ñ��O�O */
    $long   mdiscount_cover;                      /* ���� */
    $long   mprem_cover;                          /* �W���O�O */
    $double mpure_prem;                           /* �«O�O */

    /* ply_ins_assured */
    $char   iassured [IASSURED];                 /* �Q�O�I�Hid */
    $char   nassured [NASSURED];                 /* �Q�O�I�H�m�W */
    $char   dbirth   [DATE];                     /* �X�ͤ�� */
    $char   nbenef   [NBENEF];                   /* ���q�H�m�W */
    $char   rel_benef[REL_BENEF];                /* ���q�H�P�Q�O�I�H���Y */
    $char   tbenef   [21];                       /* ���q�H�p���q�� 1110310005_SC2 �s�W147�Q�O�H�W�U */
    $char   abenef_zip[CA_ZIP];                  /* ���q�H�l���ϸ� */
    $char   abenef   [91];                       /* ���q�H�a�} */    
    
    /* �n�O�H */
    $char   iapplicant[IASSURED];
    $char   napplicant[101];

    $char   iedr_return[2];
    $char   fbalance[2];
    $char   sIaccount_branch[3],tmp_ibranch_in[BRANCH_ID];/* 1070322011-SC1-�Q���줽�Ǥɮ欰�x�_�����q*/
    $char    tmp_sql[101] = " ",fIFRS_Go[2],sToday[11],iendorse1_out[21],iendorse2_out[21];
    $char   isubcode[3],icohort[5]; 
    $char   fapply[2],iportfolio[11],igroup[21]; /* IFRS17 */
    char    yy[5], mm[3], dd[3];    
    /*------------------------------------------------------------*/

    $WHENEVER SQLERROR GOTO optP_err;
    $SET LOCK MODE TO WAIT;

    if ((list=get_db_list(&db_num,DBname))==(char *)0)
        return M_CM_NOT_DBLIST;

    edrdate=dwritten;

    strncpy(iunit, DBname, 2);
    iunit[2]='\0';
    printf("1:%d\n", edrdate);
    /************************************************************/
    $WHENEVER SQLERROR GOTO optP_err;

    printf("*********** CheckSerialEndorse()\n");

    /*1111101004_SC1 ��氣�C���t�λݨD��*/
    strcpy(fIFRS_Go,"N");
    strcpy(sToday,cm_edate_str(Today));
    rc = cm_get_IFRS_DATE(sToday,fIFRS_Go); /* cm_get_IFRS_DATE => cm_code_data,itype=73, icode1=01 */
    printf("cm_get_IFRS_DATE rc[%ld]\n",rc);
    if (rc != M_CM_OK)
    {
        if (rc < 0)
        {
            goto optP_err;    
        }
        else
        {
            goto optP_err1;                    
        } 
    }
    printf("fIFRS_Go[%s]\n",fIFRS_Go);

    $BEGIN WORK;
    $LOCK TABLE edr_relation IN SHARE MODE;

    /* �Y���u�@��(cm_wrktbl.fwork=0)���鵲�ᤣ�i�浧�鵲�B����(cm_wrktbl.fwork=1)���i�浧�鵲 */
    iCount = 0;  
    $SELECT fwork
       INTO $fwork
       FROM cm_wrktbl
      WHERE dwork = today;

    if( fwork[0] == '0')  /* �u�@�� */
    {
        $SELECT count(*)
           INTO $iCount
           FROM edr_relation
          WHERE dedr_close = today
            AND fclose_type = 'B';

        if( iCount != 0 && fclose_type[0] == 'S')
        {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            strcpy( err_buf, "�u�@����鵲�ᤣ�i�浧�鵲");
            return FAIL;
        }
    }
    else  /* ���� */
    {
        if( fclose_type[0] == 'S')
        {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            strcpy( err_buf, "���餣�i�浧�鵲");
            return FAIL;
        }
    }
    /* 1020111001_C2 ���O�X����@�~ */

    printf("2:%d\n", edrdate);

    fIFRS17 = 'N';    


IFRS17_EDR:  
    /* 1111101004_SC1 ��氣�C���t�λݨD��G �w�ﲣ�ͪ��@�t�@��(IFRS17���C)���(fIFRS17 = Y)�A�]�@���鵲 
       �t�V���G�|�����鵲�F
       ���V���G�Y[�O��]�����O�A�h���|�鵲 => chk_iendorse_status()
    */
   
    strcpy(tmp_sql," ");
    if (fIFRS17=='Y')
    {
        /* �u��@�t�@�������C���i��鵲 */
        printf("fIFRS17 = Y \n");
        strcpy(tmp_sql," AND a.fedr_class = 'A' AND a.iendorse_dere <> '' "); /* ���C���(��"���C���p��渹"��) */
    }

    if( fclose_type[0] == 'B')
    {
        sprintf( stmt_buf, "SELECT iendorse, a.iofficer, a.fcard_class FROM edr_relation a, ply_relation b "
                    " WHERE a.ipolicy = b.ipolicy"
                      " AND a.dendorse is null "
                      " AND dedr_close is null"
                      " AND iendorse not like '%%CVP%%' %s",tmp_sql);
    }
    else
    {
        if (fIFRS17=='Y')
        {
            /*���� " AND a.iendorse = '%s'"   */ 
            sprintf( stmt_buf, "SELECT iendorse, a.iofficer, a.fcard_class FROM edr_relation a, ply_relation b "
                        " WHERE a.ipolicy = b.ipolicy"
                        "   AND a.ipolicy = '%s'"
                        "   AND dedr_close is null"
                        "   AND iendorse not like '%%CVP%%' %s", v_ipolicy, tmp_sql);
            
        }
        else
        {
            sprintf( stmt_buf, "SELECT iendorse, a.iofficer, a.fcard_class FROM edr_relation a, ply_relation b "
                        " WHERE a.ipolicy  = b.ipolicy"
                        "   AND a.iendorse = '%s'"
                        "   AND a.ipolicy  = '%s'"
                        "   AND dedr_close is null"
                        "   AND iendorse not like '%%CVP%%' %s", v_iendorse, v_ipolicy, tmp_sql);
        }            
    } 
    printf("stmt_buf[%s]\n", stmt_buf);

    printf("3:%d\n", edrdate);
    iCount=0;
    $PREPARE prep1 FROM $stmt_buf;
    $DECLARE a_cur CURSOR FOR prep1;
    $OPEN a_cur;
    while(1)
    {
        $FETCH a_cur INTO $iendorse,$iofficer,$fcard_class;
        if(SQLCODE == SQLNOTFOUND) break;
        iCount++;
        printf("iendorse[%s]\n", iendorse);
  
        if( fclose_type[0] == 'B')
        {
            if (fIFRS17!='Y') /* 1111101004_SC1 ��氣�C���t�λݨD��G �@�t�@�����C��椣�ˮ�*/
            {
                rc = chk_iendorse_status( iendorse, v_sMsg);
                if( rc == M_CM_OK)
                {
                    $UPDATE edr_relation
                        SET dendorse = $edrdate
                    WHERE iendorse = $iendorse; 
                        $UPDATE ca_pa_edr
                        SET dendorse = $edrdate
                    WHERE iendorse = $iendorse; 
                }
            }
            else
            {
                    $UPDATE edr_relation
                        SET dendorse = $edrdate
                    WHERE iendorse = $iendorse; 
                        $UPDATE ca_pa_edr
                        SET dendorse = $edrdate
                    WHERE iendorse = $iendorse;                 
            }

            if( fcard_class[0] == '2' && (iofficer[0] == 'B' || iofficer[0] == 'J'))
            {
                $UPDATE edr_relation
                    SET dlock = current year to fraction(3)
                  WHERE iendorse = $iendorse
                    AND dlock is null;
            }

            if (fIFRS17!='Y')
            {
                if( rc != M_CM_OK)
                {
                    strcpy( v_sMsg, trim( v_sMsg));
                    sprintf( sErrMsg, "��渹[%s]���鵲, �]���G%s", iendorse, v_sMsg);
                    WRITELOG( sfp, sErrMsg);
                    continue;
                }
            }
        }
        else
        {
            $UPDATE edr_relation
                SET dendorse = $edrdate
              WHERE iendorse = $iendorse; 
        }      
    }
    $CLOSE a_cur;
    $FREE a_cur;
     
    printf("4:%d\n", edrdate);
    printf("iCount[%d]\n", iCount);
    if( fclose_type[0] == 'S' && iCount == 0)
    {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        strcpy( err_buf, "����Ƨ䤣��Τw�鵲");
        return SQLNOTFOUND;
    }
    printf("[%s], [%s]\n", v_iendorse, v_ipolicy);
  
    printf("5:%d\n", edrdate);
    if( fclose_type[0] == 'B')
    {
        if (fIFRS17=='Y') /* �u��@�t�@�������C���i��鵲 */
        {
            sprintf ( stmt_buf, "SELECT DISTINCT(substr(iendorse,4,2))"
                                 "  FROM edr_relation"
                                 " WHERE dendorse= %d "
                                 "   AND dedr_close IS NULL"
                                 "   AND fedr_class = 'A'"
                                 "   AND iendorse_dere <> ''" , edrdate);
        }
        else
        { 
            sprintf ( stmt_buf, "SELECT DISTINCT(substr(iendorse,4,2))"
                                 "  FROM edr_relation"
                                 " WHERE dendorse= %d "
                                 "   AND dedr_close IS NULL", edrdate);
        }
    }
    else
    {
        if (fIFRS17=='Y') /* �u��@�t�@�������C���i��鵲�A�ò��� " AND iendorse = '%s'"  */
        {    
            sprintf ( stmt_buf, "SELECT DISTINCT(substr(iendorse,4,2))"
                                "  FROM edr_relation"
                                " WHERE dendorse= %d "
                                "   AND dedr_close IS NULL"
                                "   AND ipolicy = '%s'"
                                "   AND fedr_class = 'A'"
                                "   AND iendorse_dere <> ''" , edrdate, v_ipolicy);        
        }
        else
        {
            sprintf ( stmt_buf, "SELECT DISTINCT(substr(iendorse,4,2))"
                                "  FROM edr_relation"
                                " WHERE dendorse= %d "
                                "   AND dedr_close IS NULL"
                                "   AND iendorse = '%s'"
                                "   AND ipolicy = '%s'" , edrdate, v_iendorse, v_ipolicy);
        } 

    }
    printf("6:%d\n", edrdate);
    printf("stmt_buf[%s]\n", stmt_buf);
    printf("[%s], [%s]\n", v_iendorse, v_ipolicy);

    printf("7:%d\n", edrdate);
    $PREPARE prep2 FROM $stmt_buf;
    $DECLARE cur_edr CURSOR FOR prep2;
    $OPEN cur_edr;

    for (j=0;;j++)
    {
         $FETCH cur_edr INTO $Year[j].yr;
         if( SQLCODE == SQLNOTFOUND) break;
    }
    $CLOSE cur_edr;

    if (j == 0)
    {
         flag_no_edr==1;
         goto edr_no_record;
    }
    yr_cnt = j--;

    EdrFirst=EdrCurr=EdrLast=NULL;

    for (k=0; k<yr_cnt; k++)
    {
        rc=CheckSerialEndorse(ptype_C,Year[k].yr,&EdrFirst,&EdrCurr,
                              &EdrLast,Cmaxp);
        if (rc != SUCCESS)
        {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            return rc;
        }
        rc=CheckSerialEndorse(ptype_Z,Year[k].yr,&EdrFirst,&EdrCurr,
                              &EdrLast,Zmaxp);
        if (rc != SUCCESS)
        {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            return rc;
        }
        rc=CheckSerialEndorse(ptype_M,Year[k].yr,&EdrFirst,&EdrCurr,
                              &EdrLast,Mmaxp);
        if (rc != SUCCESS)
        {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            return rc;
        }
        rc=CheckSerialEndorse(ptype_V,Year[k].yr,&EdrFirst,&EdrCurr,
                              &EdrLast,Vmaxp);
        if (rc != SUCCESS)
        {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            return rc;
        }
    }

    /*$WHENEVER SQLERROR GOTO optP_err;*/

    /**************************************/
    /*  cm_ply_info                       */
    /*  car9807141 �����g�J               */
    /**************************************/    
    /*{
         POLICY_INFO     stCmPlyInfo;
         POLICYINS_INFO  stCmPlyInsInfo;
         $char tmp_iendorse[ENDORSE_NUM], tmp_fins_grp[2], tmp_iins_type[7];
         $char tmp_iedr_type[3];
         $long tmp_mins_premium, tmp_mcommission, tmp_magent;
         $long tmp_mdiscount;
         $char tmp_icar_type[3];
         $int  tmp_qcount;

         EdrCurr=EdrFirst;
         while (EdrCurr)
         {
              memset(err_buf,0,sizeof(err_buf));

              cm_ply_info_init(&stCmPlyInfo);
              strcpy(stCmPlyInfo.insure_type,  "C");
              strcpy(stCmPlyInfo.isys_source,  "CAR");

              strncpy(stCmPlyInfo.ipolicy1, EdrCurr->ipolicy, CAR_POLICY_LEN);
              stCmPlyInfo.ipolicy1[CAR_POLICY_LEN] = '\0';
              strncpy(stCmPlyInfo.ipolicy2, EdrCurr->ipolicy+CAR_POLICY_LEN, CAR_TARGET_LEN);
              stCmPlyInfo.ipolicy2[CAR_TARGET_LEN] = '\0';
              if (stCmPlyInfo.ipolicy2[0]=='\0' || stCmPlyInfo.ipolicy2[0]==' ') strcpy(stCmPlyInfo.ipolicy2," ");

              strcpy(stCmPlyInfo.iendorse,           EdrCurr->iendorse);
              strcpy(stCmPlyInfo.iofficer,           EdrCurr->iofficer);
              strcpy(stCmPlyInfo.ibroker,            EdrCurr->ibroker);
              strcpy(stCmPlyInfo.ifpce_id,           EdrCurr->assuredi);
              strcpy(stCmPlyInfo.ifpce_id_ext,       EdrCurr->assuredi_ext);
              strcpy(stCmPlyInfo.icorps,             EdrCurr->icorps);
              strcpy(stCmPlyInfo.dpolicy,            cm_edate_str(EdrCurr->dendorse));
              strcpy(stCmPlyInfo.icomp_in,           EdrCurr->icomp_in);
              strcpy(stCmPlyInfo.ibranch_in,         EdrCurr->ibranch_in);
              strcpy(stCmPlyInfo.iquota,             EdrCurr->iquota);
              strcpy(stCmPlyInfo.itreaty,            EdrCurr->treaty);
              strcpy(stCmPlyInfo.icar_flag,          EdrCurr->icar_flag);
              strcpy(stCmPlyInfo.dply_begin,         cm_edate_str(EdrCurr->edr_begin));
              strcpy(stCmPlyInfo.dply_end,           cm_edate_str(EdrCurr->edr_end));
              strcpy(stCmPlyInfo.iresource,          EdrCurr->iresource);

              strcpy(tmp_icar_type,                  EdrCurr->car_type);
              stCmPlyInfo.mply_prem =                (long) EdrCurr->edr_mprem;
              tmp_qply_period=                       EdrCurr->qply_period;

              strcpy(fcard_class,                    EdrCurr->fcard_class);
              if (strcmp(fcard_class,"1")==0)
              {
                   stCmPlyInfo.mcommission =         0;
                   stCmPlyInfo.mdeal       =         (long) EdrCurr->edr_mcommi;
              }
              else
              {
                   stCmPlyInfo.mcommission =         (long) EdrCurr->edr_mcommi;
                   stCmPlyInfo.mdeal       =         0;
              }

              stCmPlyInfo.magent =                   (long) EdrCurr->edr_magent;
              stCmPlyInfo.mdiscount =                (long) EdrCurr->edr_mdisc;
              stCmPlyInfo.mreins_commission =        (long) 0;

              strcpy(stCmPlyInfo.ileader,            EdrCurr->ileader);

              stCmPlyInfo.qcount = (int) EdrCurr->qcount;*/

              /**********************************************
              if (strcmp(EdrCurr->fedr_class, "1") == 0)
              {
                  stCmPlyInfo.qcount = (int) -1;
              }
              else if (strncmp(EdrCurr->iedr_type,"80",2) == 0)
              {
                  stCmPlyInfo.qcount = (int) -1;
              }
              else if (strncmp(EdrCurr->iedr_type,"81",2) == 0)
              {
                  stCmPlyInfo.qcount = (int) 1;
              }
              else
              {
                  stCmPlyInfo.qcount = (int) 0;
              }
              **********************************************/

              /*rtncode = cm_ply_info_insert(&stCmPlyInfo);
              if (rtncode != 0)
              {
                 sprintf(err_buf, "insert cm_ply_info error [%ld]:", rtncode);
                 strcat(err_buf, EdrCurr->iendorse);
                 goto optP_err1;
              }
              strcpy(tmp_iendorse, EdrCurr->iendorse);*/

              /*********************************/
              /*   cm_plyins_info              */
              /*  car9807141 �����g�J          */
              /*********************************/
              /*$DECLARE EDR_INS CURSOR FOR
                SELECT iins_type, iedr_type,
                       medrins_prem, medr_commission, medr_agent, medr_discount,
                       medrpure_prem, substr(iproduct,4,2), qcount, provision, drate_ym
                  FROM edr_ins_type
                 WHERE iendorse = $tmp_iendorse;
              $OPEN EDR_INS;
              while (1)
              {
                   $FETCH EDR_INS INTO $tmp_iins_type, $tmp_iedr_type,
                                       $tmp_mins_premium, $tmp_mcommission, $tmp_magent, $tmp_mdiscount,
                                       $tmp_mpure_prem, $tmp_iproduct, $tmp_qcount, $provision, $drate_ym;
                   if (SQLCODE==SQLNOTFOUND) break;

                   strcpy(tmp_iins_type,trim(tmp_iins_type));

                   $SELECT fins_grp
                      INTO $tmp_fins_grp
                      FROM insurance_type
                     WHERE iins_type=$tmp_iins_type;

                   cm_plyins_info_init(&stCmPlyInsInfo);
                   strcpy(stCmPlyInsInfo.insure_type, "C");
                   strcpy(stCmPlyInsInfo.isys_source, "CAR");

                   strncpy(stCmPlyInsInfo.ipolicy1, EdrCurr->ipolicy, CAR_POLICY_LEN);
                   stCmPlyInsInfo.ipolicy1[CAR_POLICY_LEN] = '\0';

                   strncpy(stCmPlyInsInfo.ipolicy2, EdrCurr->ipolicy+CAR_POLICY_LEN, CAR_TARGET_LEN);
                   stCmPlyInsInfo.ipolicy2[CAR_TARGET_LEN] = '\0';
                   if (stCmPlyInsInfo.ipolicy2[0]=='\0' || stCmPlyInsInfo.ipolicy2[0]==' ') 
                       strcpy(stCmPlyInsInfo.ipolicy2," ");

                   strcpy(stCmPlyInsInfo.iendorse, EdrCurr->iendorse);

                    ����|�p��l�� 
                   rtncode = get_product_code_car("C",tmp_iins_type,tmp_icar_type,tmp_qply_period,iproduct,
                                              kclsfyitem,kreserve, provision, drate_ym);
                   if (rtncode != M_CM_OK)
                   {
                        sprintf(err_buf, "get_product_code error [%ld]:", rtncode);
                        strcat(err_buf, EdrCurr->iendorse);
                        goto optP_err1;
                   }

                   strcpy(stCmPlyInsInfo.insure_kind,    trim(kclsfyitem));
                   strcpy(stCmPlyInsInfo.insure_instype, tmp_iins_type);
                   strcpy(stCmPlyInsInfo.iacc_instype,   tmp_iproduct);

                   stCmPlyInsInfo.qcount = tmp_qcount; */

                   /*****************************************************
                   if (strcmp(tmp_iedr_type, "01") == 0)
                   {
                        switch(atoi(trim(tmp_iins_type)))
                        {
                             case 2: case 3: case 4: case 12: case 13: case 14:
                             case 24: case 25: case 29: case 30: case 32:
                             case 52: case 53: case 71: case 72: case 82: case 83:
                                      stCmPlyInsInfo.qcount = 0;
                                      break;
                             default:
                                      stCmPlyInsInfo.qcount = -1;
                        }
                   }
                   else if (strcmp(tmp_iedr_type, "05") == 0)
                   {
                        switch(atoi(trim(tmp_iins_type)))
                        {
                             case 2: case 3: case 4: case 12: case 13: case 14:
                             case 24: case 25: case 29: case 30: case 32:
                             case 52: case 53: case 71: case 72: case 82: case 83:
                                      stCmPlyInsInfo.qcount = 0;
                                      break;
                             default:
                                      stCmPlyInsInfo.qcount = 1;
                        }
                   }
                   else if (strcmp(tmp_iedr_type, "80") == 0)
                   {
                        stCmPlyInsInfo.qcount = -1;
                   }
                   else if (strcmp(tmp_iedr_type, "81") == 0)
                   {
                        stCmPlyInsInfo.qcount = 1;
                   }
                   else
                   {
                        stCmPlyInsInfo.qcount = 0;
                   }
                   *****************************************************/

                   /*stCmPlyInsInfo.mply_prem   = (long) tmp_mins_premium;

                   if (strcmp(fcard_class,"1")==0)
                   {
                        stCmPlyInsInfo.mcommission = 0;
                        stCmPlyInsInfo.mdeal       = (long) tmp_mcommission;
                   }
                   else
                   {
                        stCmPlyInsInfo.mcommission = (long) tmp_mcommission;
                        stCmPlyInsInfo.mdeal       = 0;
                   }

                   stCmPlyInsInfo.magent      = (long) tmp_magent;
                   stCmPlyInsInfo.mdiscount   = (long) tmp_mdiscount;
                   stCmPlyInsInfo.mpure_prem  = (double) tmp_mpure_prem;

                   printf("**** call cm_plyins_info_insert\n");
                   rtncode = cm_plyins_info_insert(&stCmPlyInsInfo);
                   if (rtncode != 0)
                   {
                        sprintf(err_buf, "insert cm_plyins_info error [%ld]:", rtncode);
                        strcat(err_buf, EdrCurr->iendorse);
                        goto optP_err1;
                   }
              }*/
              /*$FREE EDR_INS;
              EdrCurr=EdrCurr->next;
         }
    }*/


    if (fIFRS17!='Y')
    {  
        /*-------- �� 1071225004_SC1_ ����_���I�W��ѽվ� �� ------------*/
        printf("***********  INSERT INTO endorsement_apply\n");
        /*$WHENEVER SQLERROR GOTO optP_err;*/  /* resume error handling */
        $WHENEVER SQLERROR CONTINUE;
        {
            $char  buf[1024], tmp_ipolicy[POLICY_NUM_1], tmp_iendorse[ENDORSE_NUM];
            $char  tmp_iroute_accept[21],tmp_iroute_main[13],tmp_edr_class[2],tmp_iroute[21];
            $char  tmp_ipolicy1[POLICY_NUM_1], tmp_ipolicy2[POLICY_NUM_1];
            $long  tmp_cover,tmp_dendorse;

            sprintf(buf,"INSERT INTO endorsement_apply %s %s %s",
                        "(iroute_accept , ipolicy1 , ipolicy2 , iendorsement , iroute_main , ",
                        " iins_newtype ,itype , dply_edr , dapply , dsign , ddate , icreate) ",
                        " VALUES (?, ?, ?, ?, ? ,'C' ,? ,? ,? , '', current,'CAR5082')");

            $PREPARE prep_apply FROM $buf;

            EdrCurr=EdrFirst;
            while (EdrCurr)
            {
                strcpy(tmp_iroute_accept  ,EdrCurr->iroute_accept);
                if (strlen(trim(tmp_iroute_accept))==0) /*�����z�s��*/
                {
                    EdrCurr=EdrCurr->next;
                    continue;
                }

                strcpy(tmp_iendorse       ,EdrCurr->iendorse);
                strcpy(tmp_ipolicy        ,EdrCurr->ipolicy);
                strcpy(tmp_iroute         ,EdrCurr->iroute);
                tmp_dendorse = EdrCurr->dendorse;
                
                strncpy(tmp_ipolicy1, tmp_ipolicy, CAR_POLICY_LEN);
                tmp_ipolicy1[CAR_POLICY_LEN] = '\0';
                strncpy(tmp_ipolicy2, tmp_ipolicy+CAR_POLICY_LEN,CAR_TARGET_LEN);
                tmp_ipolicy2[CAR_TARGET_LEN] = '\0';
                if (strlen(trim(tmp_ipolicy2))==0) strcpy(tmp_ipolicy2," ");             

                strcpy(tmp_edr_class,"1");  /* endorsement_apply.itype: 1.�@����B2.���P�B3.�h�O */
                if (*(EdrCurr->fedr_class)=='1') 
                {
                    strcpy(tmp_edr_class,"2");  
                }
                else if (*(EdrCurr->fedr_class)=='4') 
                {
                    strcpy(tmp_edr_class,"3");  
                }
                else if (*(EdrCurr->fedr_class)=='6' || *(EdrCurr->fedr_class)=='9') 
                {
                    tmp_cover = 0; 
                    $select sum(mdamage_cover) into $tmp_cover from ply_ins_type
                    where ipolicy = $tmp_ipolicy;  
                    if (tmp_cover==0) strcpy(tmp_edr_class,"3");
                }             

                strcpy(tmp_iroute_main," ");  
                $Select iroute_main into $tmp_iroute_main FROM cm_route
                Where iroute = $tmp_iroute;
                
                $EXECUTE prep_apply
                            USING $tmp_iroute_accept,$tmp_ipolicy1 , $tmp_ipolicy2, $tmp_iendorse,
                                $tmp_iroute_main  ,$tmp_edr_class, $tmp_dendorse, $tmp_dendorse;

                if (SQLCODE == -239){
                    sprintf( sErrMsg, "��渹[%s],���z�s��[%s]���鵲, �]���g�J endorsement_apply �ɭ���", tmp_iendorse,tmp_iroute_accept);
                    WRITELOG( sfp, sErrMsg);
                    EdrCurr=EdrCurr->next;
                    continue;
                }else{

                    if (SQLCODE!=0) goto optP_err;
                }
                EdrCurr=EdrCurr->next; 
            } 
        }
    }  
    /*-------- �� 1071225004_SC1_ ����_���I�W��ѽվ� �� ------------*/


    /**** STEP P.2--(4) *****************************************/
    /************************************/
    /************************************/
    /* ca_edr_assured                   */
    /* ca_ply_period                    */
    /* ca_accident                      */
    /************************************/
    /************************************/
    printf("*********** into P.2--(4) UpdateAssured_Ply()\n");
    $WHENEVER SQLERROR GOTO optP_err;
    {
         $char  buf[2048], tmp_ipolicy[POLICY_NUM_1], tmp_iendorse[ENDORSE_NUM];
         $char  tmp_icard[CARD_NUM],tmp_fcard_class[2];
         $char  tmp_tagnum[CA_TAG_NUM],tmp_body[CA_BODY_NUM],tmp_engine[CA_ENGINE_NUM], tmp_assuredn[41];
         $char  tmp_assuredi[13], tmp_tagnum_bak[CA_TAG_NUM], tmp_engine_bak[CA_ENGINE_NUM], tmp_dcreate[31];
         $char  nassured_10c[11];
         $char  branch[BRANCH_ID], tmp_fedr_class[2];
          char  FullDBName[DB_FULL_NAME];
         $long  tmp_dply_bgn,tmp_dply_end;
         $char  fcard_class[4], fstatus[2],tmp_iscan_no[26];  /* 1101018008_SC2 �q�lñ�ݱ��y�s������X�W��25�X */
         $char  tmp_iquote[21];

         sprintf(buf,"INSERT INTO ca_edr_assured %s %s",
                     "(nassured,itag,ibody,iengine,ipolicy,icard,fcard_class,",
                     "dendorse,iassured,ftrans) VALUES (?,?,?,?,?,?,?,?,?,'A')");
         $PREPARE INS_E_ID FROM $buf;

         sprintf(buf,"UPDATE ca_edr_assured SET (%s)=(%s) WHERE %s",
                     "nassured,itag,ibody,iengine,iassured,ftrans,icard",
                     "?,?,?,?,?,'U',?",
                     "ipolicy=? AND dendorse=?");
         $PREPARE UPD_E_ID FROM $buf;

         EdrCurr=EdrFirst;

         while (EdrCurr)
         {
             strcpy(tmp_iendorse,EdrCurr->iendorse);
             strcpy(tmp_ipolicy,EdrCurr->ipolicy);
             strcpy(tmp_dcreate,EdrCurr->dcreate);

             memset(err_buf,0,sizeof(err_buf));
             strcpy(err_buf,"update edr_relation:");
             strcat(err_buf,tmp_iendorse);

             rc = check_dedr_close( tmp_ipolicy, tmp_iendorse, tmp_dcreate);

             if( rc != M_CM_OK) 
             {
                  sprintf( sErrMsg, "��渹[%s]���鵲, �]���e��楼�鵲", tmp_iendorse);
                  WRITELOG( sfp, sErrMsg);
                  EdrCurr=EdrCurr->next;
                  continue;
             }

             $UPDATE edr_relation
                 SET dedr_close = $edrdate,
                     dedr_close_dt = current year to fraction(3),
                     iclose =  $creator,
                     fclose_type = $fclose_type
               WHERE iendorse = $tmp_iendorse;

             $UPDATE edr_relation
                 SET dlock = current year to fraction(3)
               WHERE iendorse = $tmp_iendorse
                 AND dlock is null;

             /*
             if (*(EdrCurr->fedr_class)!='2' && *(EdrCurr->fedr_class)!='5' &&
                 *(EdrCurr->fedr_class)!='7' && *(EdrCurr->fedr_class)!='9')
             {
                 EdrCurr=EdrCurr->next;
                 continue;
             }
             */

             strcpy(tmp_assuredn,       EdrCurr->assuredn);
             strcpy(tmp_assuredi,       EdrCurr->assuredi);
             strcpy(tmp_tagnum,         EdrCurr->tagnum);
             strcpy(tmp_body,           EdrCurr->body);
             strcpy(tmp_engine,         EdrCurr->engine);
             strcpy(tmp_ipolicy,        EdrCurr->ipolicy);
             strcpy(tmp_icard,          EdrCurr->icard);
             strcpy(tmp_fcard_class,    EdrCurr->fcard_class);
             strcpy(tmp_fedr_class,     EdrCurr->fedr_class);
             strcpy(tmp_iscan_no,       EdrCurr->iscan_no);
             strcpy(tmp_iquote,         EdrCurr->iquote);
             
             edr_begin = EdrCurr->edr_begin;

             tmp_dply_bgn=EdrCurr->ply_begin;
             tmp_dply_end=EdrCurr->ply_end;

             strncpy(nassured_10c,&tmp_assuredn[0],10);
             nassured_10c[10]='\0';

             memset(err_buf,0,sizeof(err_buf));
             strcpy(err_buf,"update ca_edr_assured:");
             strcat(err_buf,tmp_iendorse);
             strcat(err_buf,",");
             strcat(err_buf,tmp_ipolicy);
             $EXECUTE UPD_E_ID
                USING $nassured_10c,$tmp_tagnum,$tmp_body,
                      $tmp_engine,$tmp_assuredi,$tmp_icard,
                      $tmp_ipolicy,$edrdate;
             if (sqlca.sqlerrd[2]==0)
             {
                 $EXECUTE INS_E_ID
                    USING $nassured_10c,$tmp_tagnum,$tmp_body,
                          $tmp_engine,$tmp_ipolicy,$tmp_icard,$tmp_fcard_class,
                          $edrdate,$tmp_assuredi;
             }

             /* 1020111001_C2 ���O�X����@�~ */
             /* 1.���A50��X��,�אּ60�w�X��w��,
                2.10.����, 40.���O�� �אּ30�w�X��-����,
                3.��l���A���� */
             /* 1101020002_SC2 �@�γ����ɼW�[���A�y�{ add�Gfstatus 45=>46 (�]�|�ݷ|�N 46 => 60)
                 (45�G���X��-���O�дڤ� ;46�G�w�X��-���O�дڤ�)*/
             $UPDATE cm_pre_receive
                 SET fstatus = (case when fstatus = '50' then '60'
                                     when fstatus = '45' then '46'
                                     when fstatus in ('10','40') then '30' end)
               WHERE ipre_rcv = $tmp_iendorse
                 AND iins_kind = $tmp_fcard_class
                 AND ipre_end = ' '
                 AND fstatus in ('10','40','50','45');

             $UPDATE cm_pre_receive
                 SET dprint = current year to second,
                     iupdate = $ipgid,
                     dupdate = current year to second,
                     dclose = current year to second
               WHERE ipre_rcv = $tmp_iendorse
                 AND iins_kind = $tmp_fcard_class
                 AND ipre_end = ' ';

             /* �浧�鵲, �g����B�������B��z�覡�ܧ�������q�ĳq */
             if( fclose_type[0] == 'S' || tmp_fedr_class[0] == 'A' || tmp_fedr_class[0] == 'B') 
                 $UPDATE cm_pre_receive
                     SET ftype_pol = 'SP',
                         ftype_sp = '10',
                         paydate = ''
                   WHERE ipre_rcv = $tmp_iendorse
                     AND iins_kind = $tmp_fcard_class
                     AND ipre_end = ''
                     AND ftype_pol = ''
                     AND ftype_sp = 'PA';

             if (tmp_tagnum[0]!=0 && tmp_tagnum[0]!=' ')
             {
                 memset(err_buf,0,sizeof(err_buf));
                 strcpy(err_buf,"update ca_ply_period:");
                 strcat(err_buf,tmp_iendorse);
                 strcat(err_buf,",");
                 strcat(err_buf,tmp_ipolicy);

                 $UPDATE ca_ply_period
                     SET dply_bgn=$tmp_dply_bgn,
                         dply_end=$tmp_dply_end,
                         inumber=$tmp_tagnum,
                         ftrans='U'
                   WHERE ipolicy=$tmp_ipolicy
                     AND fcard_class=$tmp_fcard_class;

                 memset(err_buf,0,sizeof(err_buf));
                 strcpy(err_buf,"update ca_accident:");
                 strcat(err_buf,tmp_iendorse);
                 strcat(err_buf,",");
                 strcat(err_buf,tmp_ipolicy);

                 $SELECT itag
                    INTO $tmp_tagnum_bak
                    FROM policy_bak
                   WHERE iendorse = $tmp_iendorse;

                 if( strcmp( tmp_tagnum_bak, tmp_tagnum) != 0) /* �����ʨ����~update */
                 {
                     printf("tmp_tagnum_bak[%s], tmp_tagnum[%s]\n", tmp_tagnum_bak, tmp_tagnum);
                     sprintf(buf,"UPDATE ca_accident \
                                     SET inumber= ? , ftrans='U' \
                                   WHERE ipolicy='%s' \
                                     AND fcard_class='%s' ",
                                   tmp_ipolicy , tmp_fcard_class);

                     printf("buf[%s]\n", buf);
                     printf("tmp_tagnum_bak[%s], tmp_tagnum[%s]\n", tmp_tagnum_bak, tmp_tagnum);
                     $PREPARE u1_acc FROM $buf;
                     $EXECUTE u1_acc USING $tmp_tagnum;
                 }
             }
             else
             {
                 memset(err_buf,0,sizeof(err_buf));
                 strcpy(err_buf,"update ca_ply_period:");
                 strcat(err_buf,tmp_iendorse);
                 strcat(err_buf,",");
                 strcat(err_buf,tmp_ipolicy);

                 $UPDATE ca_ply_period
                     SET dply_bgn=$tmp_dply_bgn,
                         dply_end=$tmp_dply_end,
                         inumber=$tmp_engine,
                         ftrans='U'
                WHERE ipolicy=$tmp_ipolicy
                     AND fcard_class=$tmp_fcard_class;

                 memset(err_buf,0,sizeof(err_buf));
                 strcpy(err_buf,"update ca_accident:");
                 strcat(err_buf,tmp_iendorse);
                 strcat(err_buf,",");
                 strcat(err_buf,tmp_ipolicy);

                 $SELECT iengine
                    INTO $tmp_engine_bak
                    FROM policy_bak
                   WHERE iendorse = $tmp_iendorse;

                 if( strcmp( tmp_engine_bak, tmp_engine) != 0) /* �����ʤ������~update */
                 {
                     sprintf(buf,"UPDATE ca_accident \
                                     SET inumber= ? , ftrans='U' \
                                   WHERE ipolicy='%s' \
                                     AND fcard_class='%s'",
                                   tmp_ipolicy , tmp_fcard_class);

                     printf("buf[%s]\n", buf);
                     $PREPARE u2_acc FROM $buf;
                     $EXECUTE u2_acc USING $tmp_engine;
                 }
             }
             
             /*1080730005_SC2 �q�lñ�p���ظm�@�~*/
             if (strlen(trim(tmp_iscan_no)) >0)
             {	
	             $UPDATE cm_esign_data
	                 SET dply_edr = $edrdate,
	                     dins_bgn = $tmp_dply_bgn,
	                     dins_end = $tmp_dply_end,
	                     fstatus  = '2',
	                     iupdate  = $ipgid ,
	                     dupdate  = current
	               WHERE iscan_no = $tmp_iscan_no 
	                 AND iendorse = $tmp_iendorse;
             }    

             /* 1110607001_SC1 �ظmE�O�����t�� */
             if (strlen(trim(tmp_iquote)) >0)
             {	
                $Update newa00:endorse_master
                    Set icurrent_state = 799 ,
                        dprint         = current, 
                        dply_edr       = current
                  Where iquote = $tmp_iquote;
             }  

             EdrCurr=EdrCurr->next;
         }
    }

    /**** STEP P.2--(5) *****************************************/
    $WHENEVER SQLERROR GOTO optP_err;

    printf("*********** ao_plyedr_prem , ao_plyedr_detail\n");

    EdrCurr=EdrFirst;
    while (EdrCurr)
    {
        $long  tmp_dply_bgn,tmp_dply_end;
        $char  tmp_fpay_cond[3];

        printf("**** Insert into ao_plyedr_prem , ao_plyedr_detail iendorse[%s]\n", EdrCurr->iendorse);

        strcpy(iendorse,        EdrCurr->iendorse);
        strcpy(ipolicy,         EdrCurr->ipolicy);
        strcpy(iofficer,        EdrCurr->iofficer);
        strcpy(ibig_office,     EdrCurr->ibig_office);
        strcpy(ibig_sales,      EdrCurr->ibig_sales);
        strcpy(iroute,          EdrCurr->iroute);
        strcpy(ibroker,         EdrCurr->ibroker);
        strcpy(assuredn,        EdrCurr->assuredn);
        strcpy(assureda,        EdrCurr->assureda);
        strcpy(assuredi,        EdrCurr->assuredi);
        strcpy(assuredi_ext,    EdrCurr->assuredi_ext);
        strcpy(iquota,          EdrCurr->iquota);
        strcpy(icard,           EdrCurr->icard);
        strcpy(fcard_class,     EdrCurr->fcard_class);
        strcpy(fedr_class,      EdrCurr->fedr_class);
        strcpy(fpay,            EdrCurr->fpay);
        strcpy(ipay,            EdrCurr->ipay);
        strcpy(recover_num,     EdrCurr->irecover_num);
        strcpy(iresource,       EdrCurr->iresource);
        strcpy(iedr_area,       EdrCurr->iedr_area);
        strcpy(ffac,            EdrCurr->ffac);
        strcpy(fdiscount,       EdrCurr->fdiscount);
        strcpy(ibig_comp,       EdrCurr->ibig_comp);
        strcpy(icar_type,       EdrCurr->car_type);
        strcpy(payresult,       EdrCurr->payresult);
        strcpy(icar_type,       EdrCurr->car_type);
        strcpy(icorps,          EdrCurr->icorps);
        strcpy(nequipment,      EdrCurr->nequipment);
        strcpy(itag_number,     EdrCurr->tagnum);
        strcpy(ibenef,          EdrCurr->ibenef);
        strcpy(zip,             EdrCurr->zip);
        strcpy(ibroker_top,     EdrCurr->ibroker_top);
        strcpy(assuredf,        EdrCurr->assuredf);
        strcpy(iapplicant,      EdrCurr->iapplicant);
        strcpy(napplicant,      EdrCurr->napplicant);
        strcpy(apayment,        EdrCurr->apayment);
        strcpy(iedr_return,     EdrCurr->iedr_return);
        /* 1000311003 �q��2 */
        strcpy(icomm_obj,       EdrCurr->icomm_obj);
        strcpy(dcreate,         EdrCurr->dcreate);
        strcpy(icard_main,      EdrCurr->icard_main);
        strcpy(tmp_ibranch_in,  EdrCurr->ibranch_in);/*1070322011-SC1-�Q���줽�Ǥɮ欰�x�_�����q*/

        edr_begin         = EdrCurr->edr_begin;
        edr_end           = EdrCurr->edr_end;
        tmp_dply_bgn      = EdrCurr->ply_begin;
        tmp_dply_end      = EdrCurr->ply_end;
        tmp_qply_period   = EdrCurr->qply_period;

        mcompensate  = EdrCurr->mcompensate;
        check_910401 = EdrCurr->check_910401;

        if (strcmp(fcard_class, "1") == 0)
            strcpy(irelative_ply, EdrCurr->ipolicy);
        else strcpy(irelative_ply, EdrCurr->irelative_ply);
         
        printf("\n\n----------------\n");
        printf("ibig_sales=[%s]\n", ibig_sales );
        printf("=====================\n");
        
        rc = check_dedr_close( ipolicy, iendorse, dcreate);

        if( rc != M_CM_OK)
        {
             EdrCurr=EdrCurr->next;
             continue;
        }

        /* car9610293
           ���鵲(car5082)�N�ɯūO�N�O�d��(edr_relation.ipay)�g�Jao_plyedr_prem.ipolicy_main */

        if((iofficer[0] == 'W') && (
            (strncmp(iofficer+6,"YTA",3) == 0)||
            (strncmp(iofficer+6,"LCA",3) == 0)||
            (strncmp(iofficer+6,"YCF",3) == 0)||
            (strncmp(iofficer+6,"YCL",3) == 0)||
            (strncmp(iofficer+6,"YFL",3) == 0)))
            strcpy(card_YTA, ipay);
        else
            strcpy( card_YTA, icard_main); 

        if (ffac[0]!=' ' && ffac[0]!=0)
        {
            rtn_code=ca_fac_edrclose(iendorse);
            if (rtn_code!=1)
            {
                memset(err_buf,0,sizeof(err_buf));
                strcpy(err_buf,"call ca_fac_edrclose() error! ");
                strcat(err_buf,iendorse);
                $WHENEVER SQLERROR CONTINUE;
                $ROLLBACK WORK;
                return rtn_code;
            }
            $WHENEVER SQLERROR GOTO optP_err;
        }

        strncpy(ply1,ipolicy,CAR_POLICY_LEN); ply1[CAR_POLICY_LEN]='\0';

        if(strlen(ipolicy)>CAR_POLICY_LEN)
             strcpy(ply2,ipolicy+CAR_POLICY_LEN);
        else
             strcpy(ply2," ");


        /********************************/
        /********************************/
        /* ao_plyedr_prem               */
        /********************************/
        /********************************/
        printf("fedr_class[%s]\n",fedr_class);
        printf("Insert into ao_plyedr_prem==>iendorse[%s]\n",iendorse);


        /***** ������һݧ�s nequipment �������O����� *****/
  
        $UPDATE ao_plyedr_prem
            SET nequipment = $nequipment,
                itag       = $itag_number
          WHERE ipolicy1 = $ply1
            AND ipolicy2 = $ply2;

        strcpy( transno, "");
        strcpy( transno2, "");

        /* car9803042 �g���N��RD,RDA,RE,RI01�N�Q�O�I�HID��Jao_plyedr_prem.transno,������Jao_plyedr_prem.transno2 */
        if( strncmp( iroute, "I006", 4) == 0 ||
            strncmp( iroute, "I011", 4) == 0 || strncmp( iroute, "I053", 4) == 0)
        {
            strcpy( transno, assuredi);
            strcpy( transno2, itag_number);
        }

        if( strncmp( iroute, "I009", 4) == 0 )
        {
            strcpy( transno, assuredi);
            strcpy( transno2, iapplicant);
        }

        if (*fedr_class == '5') /* ��� */
        {
            memset(err_buf,0,sizeof(err_buf));
            strcpy(err_buf,"update ao_plyedr_prem:");
            strcat(err_buf,ply1);
            strcat(err_buf,",");
            strcat(err_buf,ply2);
            strcat(err_buf,",");
            strcat(err_buf,iendorse);

            $UPDATE ao_plyedr_prem
                SET nassured     = $assuredn,
                    aassured     = $assureda,
                    aassured_a   = $apayment,
                    ifpce_id     = $assuredi,
                    ifpce_id_ext = $assuredi_ext,
                    iapplicant   = $iapplicant,
                    napplicant   = $napplicant
              WHERE ipolicy1   = $ply1
                AND ipolicy2   = $ply2
                AND iendorse   = ' ';

            EdrCurr=EdrCurr->next;
            continue;
        }
        else if(*fedr_class == '2')   /** �L��:������� **/
        {
            memset(err_buf,0,sizeof(err_buf));
            strcpy(err_buf,"update ao_plyedr_prem:");
            strcat(err_buf,ply1);
            strcat(err_buf,",");
            strcat(err_buf,ply2);
            strcat(err_buf,",");
            strcat(err_buf,iendorse);

            $UPDATE ao_plyedr_prem
                SET nassured   = $assuredn,
                    aassured   = $assureda,
                    aassured_a = $apayment,
                    ifpce_id     = $assuredi,
                    ifpce_id_ext = $assuredi_ext,
                    iapplicant   = $iapplicant,
                    napplicant   = $napplicant
              WHERE ipolicy1   = $ply1 ;
        }
        else  /** *fedr_class != '2' �D�L�ᤧ������O **/
        {
            mprem1          = mprem2        = 0;
            mdiscount1      = mdiscount2    = 0;
            tmp_prem1       = tmp_prem2     = 0;
            tmp_discount1   = tmp_discount2 = 0;
            mprem12         = mdiscount12   = 0;

            $SELECT medrdmg_prem,  medrlia_prem,
                    medrdmg_disc,  medrlia_disc,
                    medrdmg_agent, medrdmg_commi,
                    medrlia_agent, medrlia_commi
               INTO $medrdmg_prem, $medrlia_prem,
                    $medrdmg_disc, $medrlia_disc,
                    $tmp_agent1,   $tmp_commission1,
                    $tmp_agent2,   $tmp_commission2
               FROM edr_relation
              WHERE iendorse = $iendorse;
          
            if (strcmp(fcard_class, "1") == 0)
            {
                /* �d�߱j���I�t�B���� */
                $SELECT *
                   FROM edr_ins_type
                  WHERE iendorse = :iendorse
                    AND iins_type = '21'
                    AND iedr_type = '85';
                if (SQLCODE==SQLNOTFOUND)
                {
                     strcpy(tmp_fpay_cond,"2");
                }
                else
                {
                     strcpy(tmp_fpay_cond,"9");
                }

                /* car_9511301 */
                $SELECT medrdmg_cover
                   INTO $mdamage_cover
                   FROM edr_ins_type
                  WHERE iendorse = $iendorse
                    AND iins_type = '21';

                if( NOT_FOUND)
                    mdamage_cover = 0;
            }
            else
            {
                 strcpy(tmp_fpay_cond,"2");
               
                /* car_9511301 */
                $SELECT medrdmg_cover
                   INTO $mdamage_cover
                   FROM edr_ins_type
                  WHERE iendorse = $iendorse
                    AND iins_type = '31';

                if( NOT_FOUND)
                    mdamage_cover = 0;
            }

            if (check_910401 == 1)  /* �¶O�v */
            {
                 mprem1 = medrdmg_prem - medrdmg_disc;
                 mprem2 = medrlia_prem - medrlia_disc;
            }
            else
            {    /* �s��O�v�O�O�w���t���� */
                 mprem1 = medrdmg_prem;
                 mprem2 = medrlia_prem;
            }

            if (mprem1+mprem2 > 0)
            {
                 tmp_prem1 = mprem1;
                 tmp_prem2 = mprem2;

                 tmp_discount1 = medrdmg_disc;
                 tmp_discount2 = medrlia_disc;

                 tmp_mcompensate = mcompensate;
            }
            else if (mprem1+mprem2 < 0)
            {
                 tmp_prem1 = (-1)*(mprem1);
                 tmp_prem2 = (-1)*(mprem2);

                 tmp_discount1 = (-1)*(medrdmg_disc);
                 tmp_discount2 = (-1)*(medrlia_disc);

                 tmp_mcompensate = (-1)*mcompensate;
            }
            else if (((mprem1+mprem2)==0) && (mprem1 != 0) && (mprem2 != 0))
            {
                 tmp_prem1 = mprem1;
                 tmp_prem2 = mprem2;

                 tmp_discount1 = medrdmg_disc;
                 tmp_discount2 = medrlia_disc;

                 tmp_mcompensate = mcompensate;
            }
            else
            {
                 tmp_prem1 = mprem1;
                 tmp_prem2 = mprem2;

                 tmp_discount1 = medrdmg_disc;
                 tmp_discount2 = medrlia_disc;

                 tmp_mcompensate = mcompensate;
            }

            mprem12     = tmp_prem1+tmp_prem2;
            mdiscount12 = tmp_discount1+tmp_discount2;
            mcompensate = tmp_mcompensate;

            if (mcompensate < 0)
                mcompensate_l = (long)(mcompensate - 0.5);
            else
                mcompensate_l = (long)(mcompensate + 0.5);

            /*----------*/
            if (mprem1+mprem2 > 0) 
            {
                trim_cspace(recover_num);
                if (recover_num[0] =='\0' || recover_num[0] ==' ')
                    *ftype='E'; /*��[*/
                else if (recover_num[0] !='\0' && recover_num[0] !=' ')
                    *ftype='4'; /*�_��*/
            }
            else if (mprem1+mprem2 < 0) 
            {
                if (strcmp(trim(payresult),"N2")==0)  /* ���O���A���h�� */
                {
                    *ftype='6';
                }
                else if (strcmp(trim(payresult),"NC")==0)  /* ���O���A���M�� */
                {
                    *ftype='6';
                }
                else if (*fedr_class=='4')      /*�h��*/
                {
                    *ftype='6';
                }
                else if (*fedr_class=='1') /*���P*/
                {
                    *ftype='5';
                }
                else if (*fedr_class=='3') /*�g��H�ܧ�*/
                {
                    *ftype='N';
                }
                else if (*fpay=='1')       /*��ú*/
                {
                    *ftype='3';
                }
                else if (*fpay=='2')       /*��ú*/
                {
                    *ftype='2';
                }
                else
                {                          /*��ú*/
                    *ftype='1';
                }
            }
            else if (((mprem1+mprem2)==0) && (mprem1 != 0) && (mprem2 != 0))
            {
                 *ftype='E'; /*��[*/
            }
            else if (fedr_class[0] == 'B')
            {
                 if ((tmp_commission1 + tmp_commission2) < 0)
                 {
                      if (*fpay=='1')       /*��ú*/
                      {
                          *ftype='3';
                      }
                      else if (*fpay==' ')       /*��ú*/
                      {
                          *ftype='1';
                      }
                      else
                      {
                          *ftype='3';
                      }
                 }
                 else if ((tmp_commission1 + tmp_commission2) > 0)
                 {
                      *ftype='E'; /*��[*/
                 }
                 else if ((tmp_agent1 + tmp_agent2) < 0)
                 {
                      if (*fpay=='1')       /*��ú*/
                      {
                          *ftype='3';
                      }
                      else if (*fpay==' ')       /*��ú*/
                      {
                          *ftype='1';
                      }
                      else
                      {
                          *ftype='3';
                      }
                 }
                 else if ((tmp_agent1 + tmp_agent2) > 0)
                 {
                      *ftype='E'; /*��[*/
                 }
                 else
                 {
                      *ftype='E'; /*��[*/
                 }
            }
            else
            {
                 *ftype='E'; /*��[*/
            }

            /*----------*/

            /*----------*/
            strcpy(icashier, EdrCurr->iedr_cashier);

            $WHENEVER SQLERROR GOTO optP_err;

            /*----------*/
            if (isalpha(ibig_comp[0]))
            {
                fcommit[0]='1';
                fcommit[1]='\0';
            }
            else
            {
                fcommit[0]='N';
                fcommit[1]='\0';
            }

            /* 1000311003 �q��2 */
            /* ���I��鵲�Y�P�_���j�v��ɡA�бN�y�I����H�N���z�ƻs�ܭ�]�|ao_plyedr_prem.ibroker�Pao_officer_commit.ibroker */
            if (isalpha(ibig_comp[0]))
                strcpy( ibroker, icomm_obj);

            /*--------------*/
            $SELECT ibatch_no
               INTO $ibatch_no
               FROM ply_relation
              WHERE ipolicy=$ipolicy;
            if (NOT_FOUND)
            {
                memset(err_buf,0,sizeof(err_buf));

                strcpy(err_buf,"select ply_relation notfound ");
                strcat(err_buf,ipolicy);
                $WHENEVER SQLERROR CONTINUE;
                $ROLLBACK WORK;
                return M_CA_NREL_PLY;
            }
            $WHENEVER SQLERROR GOTO optP_err;

            /* �D�ɥ[�`���s�A�����Ӧ����B�A�٬O�n�J�]���ɥD�� */

            $SELECT COUNT(*)
               INTO $iHave_amt
               FROM edr_ins_type
              WHERE iendorse = $iendorse
                AND (medrins_prem != 0 OR medr_commission != 0 OR medr_agent != 0);

            iCount = 0;
            if (fedr_class[0] == 'A') /* �g����-+�O�O�۩� */
                strcpy(fbalance, "Y");
            else if( fedr_class[0] == 'B')
            {
                $SELECT COUNT(*)
                   INTO $iCount
                   FROM edr_ins_type
                  WHERE iendorse = $iendorse
                    AND iedr_type in ('82','83'); /* �������-+�O�O�۩� */

                if( iCount != 0)
                    strcpy(fbalance, "Y");
                else
                    strcpy(fbalance, " ");
            }
            else 
                strcpy(fbalance, " ");
            printf("iendorse[%s], fedr_class[%s], iCount[%d], fbalance[%s]\n", iendorse, fedr_class, iCount, fbalance);
            /*--------------*/
            memset(err_buf,0,sizeof(err_buf));
            strcpy(err_buf,"insert ao_plyedr_prem:");
            strcat(err_buf,ipolicy);
            strcat(err_buf,",");
            strcat(err_buf,iendorse);

            if ((mprem12         != 0) ||
                (mprem1          != 0) ||
                (mprem2          != 0) ||
                (tmp_commission1 != 0) ||
                (tmp_agent1      != 0) ||
                (tmp_commission2 != 0) ||
                (tmp_agent2      != 0) ||
                (iHave_amt       != 0))
            {

		        /*1070322011_SC2-�Q���줽�Ǥɮ欰�x�_�����q*/
                strcpy(sIaccount_branch," ");
		        $SELECT iaccount_branch INTO $sIaccount_branch
		           FROM branch 
		          WHERE ibranch = $tmp_ibranch_in;
		        printf("sIaccount_branch 1[%s]\n",sIaccount_branch);

                printf("-insert into ao_plyedr_prem---:edr[%s] prem[%d] mcomp[%ld]\n",
                                                       iendorse,mprem12,mcompensate_l);
                printf("-insert into ao_plyedr_prem---:mdiscount[%d]\n",mdiscount12);

                if (ibig_office[0] == '\0') strcpy(ibig_office," ");

                if (ibig_sales[0] == '\0') strcpy(ibig_sales," ");                                

                if (check_910401 == 1)
                {
                     $INSERT INTO  ao_plyedr_prem
                                  (ipolicy1, ipolicy2, iendorse, icard, dplyend, ftype,
                                   isub, nassured, ibroker, icashier,
                                   mprem, mdiscount, icur,
                                   aassured, aassured_a, dbegin, dend, fcommit,
                                   ireplace, frcvpay, fpay_cond,
                                   iofficer, insure_type,
                                   puredplyend,
                                   mprem_nt, mcompensation_nt,
                                   mdiscount_nt, mdiscount_gl,
                                   ibatch_no, sys_source, irelative,
                                   ifpce_id,ifpce_id_ext,iquota,ibank,
                                   icorps,iresource,nequipment,itag,iroute,ibig_sales,
                                   idetent_bank,izip,ibroker_top,mcover, transno, transno2,
                                   iapplicant,napplicant,iedr_return, icomm_obj, ipolicy_main,iaccount_branch)
                           VALUES ($ply1, $ply2, $iendorse, $icard, $edrdate, $ftype,
                                   $iunit, $assuredn, $ibroker, $icashier,
                                   $mprem12, $mdiscount12, "NT",
                                   $assureda, $apayment, $edr_begin, $edr_end, $fcommit,
                                   $ipay, "N", $tmp_fpay_cond, $iofficer, "C",
                                   $edrdate,
                                   $mprem12, 0,
                                   $mdiscount12, $mdiscount12 ,
                                   $ibatch_no, "CA2", $irelative_ply,
                                   $assuredi,$assuredi_ext,$iquota,$ibig_office,
                                   $icorps,$iresource,$nequipment,$itag_number,$iroute,$ibig_sales,
                                   $ibenef, $zip, $ibroker_top,$mdamage_cover, $transno, $transno2,
                                   $iapplicant, $napplicant, $iedr_return, $icomm_obj, $icard_main,$sIaccount_branch);
                }
                else
                {    /* �s�� */
                     $INSERT INTO  ao_plyedr_prem
                                  (ipolicy1,ipolicy2,iendorse,icard,dplyend,ftype,
                                   isub,nassured,ibroker,icashier,
                                   mprem,mdiscount,icur,
                                   aassured,aassured_a,dbegin,dend,fcommit,
                                   ireplace,frcvpay,fpay_cond,
                                   iofficer, insure_type,
                                   puredplyend,
                                   mprem_nt,mcompensation_nt,
                                   mdiscount_nt, mdiscount_gl ,
                                   ibatch_no,sys_source, irelative,
                                   ifpce_id,ifpce_id_ext,iquota,ibank,
                                   icorps,iresource,nequipment,itag,iroute,ibig_sales,ipolicy_main,
                                   idetent_bank,izip, ibroker_top,mcover, transno, transno2,
                                   iapplicant, napplicant, iedr_return, icomm_obj, fbalance,iaccount_branch)
                           VALUES ($ply1,$ply2,$iendorse,$icard,$edrdate,$ftype,
                                   $iunit,$assuredn,$ibroker,$icashier,
                                   $mprem12,$mdiscount12,"NT",
                                   $assureda,$apayment,$edr_begin,$edr_end,$fcommit,
                                   $ipay,"N",$tmp_fpay_cond, $iofficer,"C",
                                   $edrdate,
                                   $mprem12,0,
                                   $mdiscount12, 0,
                                   $ibatch_no,"CA2", $irelative_ply,
                                   $assuredi,$assuredi_ext,$iquota,$ibig_office,
                                   $icorps,$iresource,$nequipment,$itag_number,$iroute,$ibig_sales, $card_YTA,
                                   $ibenef, $zip, $ibroker_top,$mdamage_cover, $transno, $transno2,
                                   $iapplicant,$napplicant,$iedr_return, $icomm_obj, $fbalance,$sIaccount_branch);
                }

                fInsert_ao=TRUE;
            } 
            else 
            {
                if (*fedr_class == '3')   /*���g��H*/
                    $UPDATE ao_plyedr_prem 
                        SET iofficer = $iofficer,
                            ibroker  = $ibroker,
                            ibroker_top  = $ibroker_top
                      WHERE ipolicy1 = $ply1
                        AND ipolicy2 = $ply2;
            }

            /* ����ݧ��Q�O�H��ơA���׬O�_�������B */
            /* car9602053 ���s�W���N�I�L�����O */
            if( *fedr_class == '9' || *fedr_class == '8')
            {
                $UPDATE ao_plyedr_prem
                    SET nassured     = $assuredn,
                        aassured     = $assureda,
                        aassured_a   = $apayment,
                        dbegin       = $tmp_dply_bgn,
                        dend         = $tmp_dply_end,
                        ifpce_id     = $assuredi,
                        ifpce_id_ext = $assuredi_ext,
                        iapplicant   = $iapplicant,
                        napplicant   = $napplicant
                  WHERE ipolicy1   = $ply1
                    AND ipolicy2   = $ply2
                    AND iendorse   = ' ';
            }
        }

        /***********************************/
        /***********************************/
        /*   ao_plyedr_detail              */
        /***********************************/
        /***********************************/
        printf("Insert into <<<<<<< ao_plyedr_detail >>>>>>>>>==>iendorse[%s]\n",iendorse);
        if ( *fedr_class != '2' )  /*������L�� */
        {
            printf("begin create temp table ao_detail_tmp\n");
            $CREATE TEMP TABLE ao_detail_tmp
             (
                 ipolicy1         char(20)      default ' ' not null ,
                 ipolicy2         char(20)      default ' ' not null ,
                 iendorse         char(20)      default ' ' not null ,
                 insure_kind      char(10)      default ' ' not null ,
                 icur             char(2)       default ' ',
                 mprem            decimal(17,4) default 0,
                 mprem_nt         decimal(17,0) default 0,
                 mcompensation_nt decimal(17,0) default 0,
                 mdiscount        decimal(17,4) default 0,
                 mdiscount_nt     decimal(17,0) default 0,
                 mdiscount_gl     decimal(8,0)  default 0 not null
             )with no log;
            $CREATE unique index ao_detail_ix on ao_detail_tmp
             (ipolicy1,ipolicy2,iendorse,insure_kind);
            printf("end   create temp table ao_detail_tmp\n");

            total_mprem     = 0;
            medrins_prem    = 0;
            medr_commission = 0;
            medr_agent      = 0;
            medr_discount   = 0;
            tmp_disc1       = 0;

            $DECLARE q_commi_1 CURSOR WITH HOLD FOR
              SELECT iins_type,
                     medrins_prem,
                     medr_commission,
                     medr_agent,
                     medr_discount, provision, drate_ym
                INTO $iins_type,
                     $medrins_prem,
                     $medr_commission,
                     $medr_agent,
                     $medr_discount, $provision, $drate_ym
                FROM edr_relation a , edr_ins_type b
               WHERE a.iendorse = b.iendorse
                 AND a.iendorse = $iendorse;
            $OPEN q_commi_1;
            for(;;)
            {
                 $FETCH q_commi_1;
                 if (SQLCODE == SQLNOTFOUND) break;

                 strcpy(iins_type , trim(iins_type));


                /*1111101004_SC2 ��氣�C���t�λݨD��*/
                /* �h���קKDWS����ɤ~�o�{�����D�A���鵲�{����ϥΧtIFRS��
                   function  get_portfolio_group_car() ���o�|�p��l��*/
                
                printf("fIFRS_Go[%s]\n",fIFRS_Go);
                if (strcmp(fIFRS_Go, "Y") == 0) /* IFRS17 �w�Ұ� */
                {
                    strcpy(icohort," ");
                    cm_split_ymd(inf_dclose,mm,dd,yy);
                    strcpy(icohort,yy);
                    
                    if (strcmp(fcard_class, "1") == 0) 
                        strcpy(isubcode, trim(icar_type));  /* �s�դl�X-�j���I������ */
                    else
                        strcpy(isubcode, " ");             		


                    /* ����|�p��l��(IFRS) */
                    rtncode = get_portfolio_group_car("C",iins_type,icar_type,tmp_qply_period,"D"," ","D",icohort,isubcode,
                                                    iproduct,kclsfyitem,kreserve,provision,drate_ym,fapply,iportfolio,igroup);  
                    
                    if (rtncode != M_CM_OK)
                    {
                        sprintf(err_buf, "ao_plyedr_detail:get_portfolio_group_car error [%ld]:", rtncode);
                        strcat(err_buf, EdrCurr->iendorse);
                        goto optP_err1;
                    }
                }
                else
                {
                    /* ����I�ط|�p��l�� */
                    printf("##### 1. ao_plyedr_detail [%s][%s][%s][%ld]\n", iendorse,iins_type,icar_type,tmp_qply_period);
                    rtncode = get_product_code_car("C",iins_type,icar_type,tmp_qply_period,iproduct,
                                                kclsfyitem,kreserve, provision, drate_ym);
                    if (rtncode != M_CM_OK)
                    {
                        sprintf(err_buf, "ao_plyedr_detail:get_product_code_car error [%ld]:", rtncode);
                        strcat(err_buf, EdrCurr->iendorse);
                        goto optP_err1;
                    }
                }    

                 strcpy(kclsfyitem,trim(kclsfyitem));
                 printf("****** 2. ao_plyedr_detail[%s][%s][%s][%s][%ld][%s]\n", ipolicy,iendorse,iins_type,icar_type,tmp_qply_period,kclsfyitem);

                 if (fcard_class[0]=='1')
                 {
                      tmp_disc1 = 0;
                 }
                 else
                 {
                      if (check_910401 == 1)  /* �¶O�v */
                      {
                           tmp_disc1    = medr_discount; /* �¶O�v�u�f�v���߱b */
                           medrins_prem = medrins_prem - medr_discount;
                      }
                      else
                      {
                           tmp_disc1    = 0;
                      }
                 }

                 total_mprem += medrins_prem;

                 if ((medrins_prem != 0) || (medr_commission != 0) || (medr_agent != 0))
                 {
                      memset(err_buf,0,sizeof(err_buf));
                      strcpy(err_buf,"insert ao_plyedr_detail:");
                      strcat(err_buf,iendorse);
                      strcat(err_buf,"kclsfyitem:");
                      strcat(err_buf, kclsfyitem);

                      $UPDATE ao_detail_tmp
                          SET mprem        = mprem        + $medrins_prem,
                              mprem_nt     = mprem_nt     + $medrins_prem,
                              mdiscount    = mdiscount    + $medr_discount,
                              mdiscount_nt = mdiscount_nt + $medr_discount,
                              mdiscount_gl = mdiscount_gl + $tmp_disc1
                        WHERE ipolicy1    = $ply1
                          AND ipolicy2    = $ply2
                          AND iendorse    = $iendorse
                          AND insure_kind = $kclsfyitem;

                      if (sqlca.sqlerrd[2]==0)
                      {
                         $INSERT INTO  ao_detail_tmp
                                      (ipolicy1, ipolicy2, iendorse, insure_kind, icur,
                                       mprem, mprem_nt, mcompensation_nt,
                                       mdiscount, mdiscount_nt, mdiscount_gl)
                               VALUES ($ply1, $ply2, $iendorse, $kclsfyitem, "NT",
                                       $medrins_prem, $medrins_prem, 0,
                                       $medr_discount, $medr_discount, $tmp_disc1);
                      }
                 }
            }
            $CLOSE q_commi_1;

            if (total_mprem < 0)  /* �X�p�O�I�O�p��0�ɡA�O�O���u�f���B�� *(-1) */
            {
                 $UPDATE ao_detail_tmp
                     SET mprem        = (-1) * mprem,
                         mprem_nt     = (-1) * mprem_nt,
                         mdiscount    = (-1) * mdiscount,
                         mdiscount_nt = (-1) * mdiscount_nt,
                         mdiscount_gl = (-1) * mdiscount_gl
                   WHERE ipolicy1    = $ply1
                     AND ipolicy2    = $ply2
                     AND iendorse    = $iendorse;
            }

            $INSERT INTO ao_plyedr_detail
               (ipolicy1, ipolicy2, iendorse, insure_kind, icur, mprem, mprem_nt,
                mcompensation_nt, mdiscount, mdiscount_nt, mdiscount_gl)
             SELECT *
               FROM ao_detail_tmp;

            $DROP TABLE ao_detail_tmp;
        }

        EdrCurr=EdrCurr->next;
    }

    /**** STEP P.2--(8) *****************************************/
    printf("*********** ao_officer_commit, ao_commit_detail\n");

    EdrCurr=EdrFirst;

    while (EdrCurr)
    {
        printf("***** INSERT into ao_officer_commit,ao_commit_detail iendorse[%s]\n", EdrCurr->iendorse);

        mpremium=magent=0;

        strcpy(iendorse,        EdrCurr->iendorse);
        strcpy(ipolicy,         EdrCurr->ipolicy);
        strcpy(iofficer,        EdrCurr->iofficer);
        strcpy(ibroker,         EdrCurr->ibroker);
        strcpy(ibig_office,     EdrCurr->ibig_office);        
        strcpy(icard,           EdrCurr->icard);
        strcpy(fcard_class,     EdrCurr->fcard_class);
        strcpy(fedr_class,      EdrCurr->fedr_class);
        strcpy(fpay,            EdrCurr->fpay);
        strcpy(recover_num,     EdrCurr->irecover_num);
        strcpy(iresource,       EdrCurr->iresource);
        strcpy(fdiscount,       EdrCurr->fdiscount);
        strcpy(icar_type,       EdrCurr->car_type);
        strcpy(ibig_comp,       EdrCurr->ibig_comp);
        strcpy(ibig_sales,      EdrCurr->ibig_sales);
        strcpy(payresult,       EdrCurr->payresult);
        strcpy(icar_type,       EdrCurr->car_type);
        tmp_qply_period       = EdrCurr->qply_period;
        strcpy(ibroker_top,     EdrCurr->ibroker_top);
        /* 1000311003 �q��2 */
        strcpy(icomm_obj,       EdrCurr->icomm_obj);
        strcpy(dcreate,         EdrCurr->dcreate);
        strcpy(tmp_ibranch_in,  EdrCurr->ibranch_in);/*1070322011-SC1-�Q���줽�Ǥɮ欰�x�_�����q*/

        check_910401 = EdrCurr->check_910401;

        if (strcmp(fcard_class, "1") == 0)
            strcpy(irelative_ply, EdrCurr->ipolicy);
        else strcpy(irelative_ply, EdrCurr->irelative_ply);

        if (*fedr_class == '2' || *fedr_class == '5')
        {
             EdrCurr=EdrCurr->next;
             continue;
        }

        rc = check_dedr_close( ipolicy, iendorse, dcreate);

        if( rc != M_CM_OK)
        {
             EdrCurr=EdrCurr->next;
             continue;
        }

        strncpy(ply1,ipolicy,CAR_POLICY_LEN); ply1[CAR_POLICY_LEN]='\0';
        if(strlen(ipolicy)>CAR_POLICY_LEN)
             strcpy(ply2,ipolicy+CAR_POLICY_LEN);
        else
             strcpy(ply2," ");

        /*----------*/
        medrdmg_prem=medrdmg_commi=medrdmg_agent=0;
        medrlia_prem=medrlia_commi=medrlia_agent=0;
        mprem1=mprem2=0;
        mcommission1=mcommission2=0;
        magent1=magent2=0;

        tmp_prem1=tmp_prem2=0;
        tmp_commission1=tmp_commission2=tmp_commission33=0;
        tmp_agent1=tmp_agent2=tmp_agent33=0;
        mprem12=magent12=mdeal=0;

        $SELECT medrdmg_prem, medrdmg_commi, medrdmg_agent,
                medrlia_prem, medrlia_commi, medrlia_agent
           INTO $medrdmg_prem, $medrdmg_commi, $medrdmg_agent,
                $medrlia_prem, $medrlia_commi, $medrlia_agent
           FROM edr_relation 
          WHERE iendorse=$iendorse;
          
        mprem1       = medrdmg_prem;
        mcommission1 = medrdmg_commi;
        magent1      = medrdmg_agent;

        mprem2       = medrlia_prem;
        mcommission2 = medrlia_commi;
        magent2      = medrlia_agent;

        if (mprem1+mprem2 > 0)
        {
            tmp_prem1=mprem1;
            tmp_prem2=mprem2;

            tmp_commission1=mcommission1;
            tmp_commission2=mcommission2;

            tmp_agent1=magent1;
            tmp_agent2=magent2;
        }
        else if (mprem1+mprem2 < 0)
        {
            tmp_prem1=(-1)*(mprem1);
            tmp_prem2=(-1)*(mprem2);

            tmp_commission1=(-1)*(mcommission1);
            tmp_commission2=(-1)*(mcommission2);

            tmp_agent1=(-1)*(magent1);
            tmp_agent2=(-1)*(magent2);
        }
        else if (((mprem1+mprem2)==0) && (mprem1 != 0) && (mprem2 != 0))
        {
            tmp_prem1=mprem1;
            tmp_prem2=mprem2;

            tmp_commission1=mcommission1;
            tmp_commission2=mcommission2;

            tmp_agent1=magent1;
            tmp_agent2=magent2;
        }
        else if (fedr_class[0] == 'B')   /* ������ */
        {
             if ((mcommission1 + mcommission2) < 0)
             {
                  tmp_commission1=(-1)*(mcommission1);
                  tmp_commission2=(-1)*(mcommission2);

                  tmp_agent1=(-1)*(magent1);
                  tmp_agent2=(-1)*(magent2);
             }
             else if ((mcommission1 + mcommission2) > 0)
             {
                  tmp_commission1=mcommission1;
                  tmp_commission2=mcommission2;

                  tmp_agent1=magent1;
                  tmp_agent2=magent2;
             }
             else if ((magent1 + magent2) < 0)
             {
                  tmp_commission1=(-1)*(mcommission1);
                  tmp_commission2=(-1)*(mcommission2);

                  tmp_agent1=(-1)*(magent1);
                  tmp_agent2=(-1)*(magent2);
             }
             else if ((magent1 + magent2) > 0)
             {
                  tmp_commission1=mcommission1;
                  tmp_commission2=mcommission2;

                  tmp_agent1=magent1;
                  tmp_agent2=magent2;
             }
             else
             {
                  tmp_commission1=mcommission1;
                  tmp_commission2=mcommission2;

                  tmp_agent1=magent1;
                  tmp_agent2=magent2;
             }
        }
        else if ((mcommission1 != 0) || (mcommission2 != 0) ||
                 (magent1 != 0)      || (magent2 != 0))
        {
            tmp_prem1=mprem1;
            tmp_prem2=mprem2;

            tmp_commission1=mcommission1;
            tmp_commission2=mcommission2;

            tmp_agent1=magent1;
            tmp_agent2=magent2;
        }

        if (fcard_class[0]=='1')
        {
            mprem12=tmp_prem1+tmp_prem2;
            mcommission12=0;
            magent12=0;
            mdeal=tmp_commission1+tmp_commission2;
        }
        else
        {
            mprem12=tmp_prem1+tmp_prem2;
            mcommission12=tmp_commission1+tmp_commission2;
            magent12=tmp_agent1+tmp_agent2;
            mdeal=0;
        }

        /*----------*/
        if (mprem1+mprem2 > 0)
        {
            trim_cspace(recover_num);
            if (recover_num[0] =='\0' || recover_num[0] ==' ')
                *ftype='E';
            else if (recover_num[0] !='\0' && recover_num[0] !=' ')
                *ftype='4';
        } 
        else if (mprem1+mprem2 < 0)
        {
            if (strcmp(trim(payresult),"N2")==0)  /* ���O���A���h�� */
            {
                *ftype='6';
            }
            else if (strcmp(trim(payresult),"NC")==0)  /* ���O���A���M�� */
            {
                *ftype='6';
            }
            else if (*fedr_class=='4')
            {
                *ftype='6';
            }
            else if (*fedr_class=='1')
            {
                *ftype='5';
            }
            else if (*fedr_class=='3')
            {
                *ftype='N';
            }
            else if (*fpay=='1')
            {
                *ftype='3';
            }
            else if (*fpay=='2')
            {
                *ftype='2';
            }
            else
            {
                *ftype='1';
            }
        }
        else if (((mprem1+mprem2)==0) && (mprem1 != 0) && (mprem2 != 0))
        {
            *ftype='E';
        }
        else if (fedr_class[0] == 'B')
        {
             if ((mcommission1 + mcommission2) < 0)
             {
                  if (*fpay=='1')
                  {
                      *ftype='3';
                  }
                  else if (*fpay==' ')
                  {
                      *ftype='1';
                  }
                  else
                  {
                      *ftype='3';
                  }
             }
             else if ((mcommission1 + mcommission2) > 0)
             {
                  *ftype='E';
             }
             else if ((magent1 + magent2) < 0)
             {
                  if (*fpay=='1')
                  {
                      *ftype='3';
                  }
                  else if (*fpay==' ')
                  {
                      *ftype='1';
                  }
                  else
                  {
                      *ftype='3';
                  }
             }
             else if ((magent1 + magent2) > 0)
             {
                  *ftype='E';
             }
             else
             {
                  *ftype='E';
             }
        }
        else
        {
            *ftype='E';
        }

        printf("before insert ao_officer_commit ibig_comp[%s],fcommit[%s]\n",ibig_comp,fcommit);
        if (isalpha(ibig_comp[0]))
        {
            fbig_rcv = 'Y';
            /* 1000311003 �q��2 */
            /* ���I��鵲�Y�P�_���j�v��ɡA�бN�y�I����H�N���z�ƻs�ܭ�]�|ao_plyedr_prem.ibroker�Pao_officer_commit.ibroker */
            strcpy( ibroker, icomm_obj);
        }
        else
            fbig_rcv = 'N';

        /* �]�ȷ|����@�߼g0*/
        ptax_1 = 0;

        /*----------*/
        memset(err_buf,0,sizeof(err_buf));
        strcpy(err_buf,"insert ao_officer_commit:");
        strcat(err_buf,ply1); strcat(err_buf,"-");
        strcat(err_buf,ply2); strcat(err_buf,"-");
        strcat(err_buf,iendorse);

        /* �D�ɥ[�`���s�A�����Ӧ����B�A�٬O�n�J�]���ɥD�� */

        $SELECT COUNT(*)
           INTO $iHave_amt
           FROM edr_ins_type
          WHERE iendorse = $iendorse
            AND (medr_commission != 0 OR medr_agent != 0);

        if ((tmp_commission1 != 0) || (tmp_agent1 != 0) ||
            (tmp_commission2 != 0) || (tmp_agent2 != 0) ||
            (iHave_amt       != 0) )
        {

	         /*1070322011_SC2-�Q���줽�Ǥɮ欰�x�_�����q*/
             strcpy(sIaccount_branch," ");
	         $SELECT iaccount_branch INTO $sIaccount_branch
	            FROM branch 
	           WHERE ibranch = $tmp_ibranch_in;
	         printf("sIaccount_branch 2[%s]\n",sIaccount_branch);

             printf("-insert into ao_officer_commit-----:edr[%s] comm[%d]\n",
                                     iendorse, mcommission12);
             printf("-insert into ao_officer_commit-----:agent[%d] deal[%d]\n",
                                     magent12,mdeal);

             $INSERT INTO  ao_officer_commit
                          (ipolicy1,ipolicy2,iendorse,ibroker,icard,
                           insure_type,iofficer,icur,
                           mpremium,mcommit,magent,mdeal,ptax,
                           fbig_rcv,dplyend,ftype,mcommit_nt,magent_nt,
                           mdeal_nt,fstatus,sys_source, ibig_sales, irelative, ibank, ibroker_top, icomm_obj,isub,iaccount_branch)
                   VALUES ($ply1,$ply2,$iendorse,$ibroker,$icard,
                           "C",$iofficer,"NT",
                           $mprem12,$mcommission12,$magent12,$mdeal,$ptax_1,
                           $fbig_rcv,$edrdate,$ftype,$mcommission12,$magent12,
                           $mdeal,"N","CA2", $ibig_sales, $irelative_ply, $ibig_office, $ibroker_top, $icomm_obj, $iunit,$sIaccount_branch);
        }
        else
        {
             if (*fedr_class == '3') /*���g��H*/
             $UPDATE ao_officer_commit
                 SET iofficer = $iofficer,
                     ibroker = $ibroker,
                     ibroker_top = $ibroker_top
               WHERE ipolicy1 = $ply1
                 AND ipolicy2 = $ply2;
        }

        /****************************************************/
        /**************** ao_commit_detail ******************/
        /****************************************************/
        printf("Insert into ao_commit_detail[%s]\n",iendorse);

        total_mprem       = 0;
        total_mcommission = 0;
        total_magent      = 0;
        mdeal             = 0;

        $CREATE TEMP TABLE ao_cmt_dtl_tmp
         (
             ipolicy1       char(20)      default ' ' not null ,
             ipolicy2       char(20)      default ' ' not null ,
             iendorse       char(20)      default ' ' not null ,
             insure_kind    char(10)      default ' ' not null ,
             icur           char(2)       default ' ',
             mcommit        decimal(17,4) default 0,
             magent         decimal(17,4) default 0,
             mdeal          decimal(17,4) default 0,
             ptax           decimal(11,4) default 0,
             mcommit_nt     integer       default 0,
             magent_nt      integer       default 0,
             mdeal_nt       integer       default 0,
             pagent         decimal(11,4) default 0,
             iofficer       char(10)      default ' ',
             ibroker        char(10)      default ' ',
             ori_magent_nt  integer,
             ori_mcommit_nt integer,
             ibroker_top    char(10)      default ' '
         )with no log;

        $CREATE unique index ao_cdetail_ix on ao_cmt_dtl_tmp
         (ipolicy1,ipolicy2,iendorse,insure_kind,iofficer,ibroker);

        $DECLARE q_commi_2 CURSOR WITH HOLD FOR
          SELECT iins_type,
                 medrins_prem,
                 medr_commission,
                 medr_agent,
                 medr_discount, provision, drate_ym
            INTO $iins_type,
                 $medrins_prem,
                 $medr_commission,
                 $medr_agent,
                 $medr_discount, $provision, $drate_ym
            FROM edr_relation a , edr_ins_type b
           WHERE a.iendorse = b.iendorse
             AND a.iendorse = $iendorse;
        $OPEN q_commi_2;
        for(;;)
        {
             $FETCH q_commi_2;
             if (SQLCODE == SQLNOTFOUND) break;

             total_mprem       += medrins_prem;
             total_magent      += medr_agent;
             total_mcommission += medr_commission;

             printf("****** 1. ao_commit_detail[%s][%s][%s][%s][%ld]\n", ipolicy,iendorse,iins_type,icar_type,tmp_qply_period);


            /*1111101004_SC2 ��氣�C���t�λݨD��*/
            /* �h���קKDWS����ɤ~�o�{�����D�A���鵲�{����ϥΧtIFRS��
               function get_portfolio_group_car() ���o�|�p��l��*/
            
            printf("fIFRS_Go[%s]\n",fIFRS_Go);
            if (strcmp(fIFRS_Go, "Y") == 0) /* IFRS17 �w�Ұ� */
            {
                strcpy(icohort," ");
                cm_split_ymd(inf_dclose,mm,dd,yy);
                strcpy(icohort,yy);
                
                if (strcmp(fcard_class, "1") == 0) 
                    strcpy(isubcode, trim(icar_type));  /* �s�դl�X-�j���I������ */
                else
                    strcpy(isubcode, " ");             		


                /* ����|�p��l��(IFRS) */
                rtncode = get_portfolio_group_car("C",iins_type,icar_type,tmp_qply_period,"D"," ","D",icohort,isubcode,
                                                iproduct,kclsfyitem,kreserve,provision,drate_ym,fapply,iportfolio,igroup);  
                
                if (rtncode != M_CM_OK)
                {
                    sprintf(err_buf, "ao_commit_detail:get_portfolio_group_car error [%ld]:", rtncode);
                    strcat(err_buf, EdrCurr->iendorse);
                    goto optP_err1;
                }
            }
            else
            {
                /* ����I�ط|�p��l�� */
                rtncode = get_product_code_car("C",iins_type,icar_type,tmp_qply_period,iproduct,kclsfyitem,kreserve, provision, drate_ym);
                if (rtncode != M_CM_OK)
                {
                    sprintf(err_buf, "ao_commit_detail:get_product_code_car error [%ld]:", rtncode);
                    strcat(err_buf, EdrCurr->iendorse);
                    goto optP_err1;
                }
            }    

             strcpy(kclsfyitem,trim(kclsfyitem));
             printf("****** 2. ao_commit_detail[%s][%s][%s][%s][%ld][%s]\n", ipolicy,iendorse,iins_type,icar_type,tmp_qply_period,kclsfyitem);

             /* �j���I������O */
             if (fcard_class[0]=='1')
             {
                  mdeal           = medr_commission;
                  medr_commission = 0;
             }
             else
             {
                  mdeal = 0;
             }

             if ((medr_commission != 0) || (medr_agent != 0) || (mdeal != 0))
             {
                  memset(err_buf,0,sizeof(err_buf));
                  strcpy(err_buf,"insert ao_commit_detail:");
                  strcat(err_buf,iendorse);
                  strcat(err_buf,":kclsfyitem:");
                  strcat(err_buf,kclsfyitem);

                  $UPDATE ao_cmt_dtl_tmp
                      SET mcommit    = mcommit    + $medr_commission,
                          mcommit_nt = mcommit_nt + $medr_commission,
                          magent     = magent     + $medr_agent,
                          magent_nt  = magent_nt  + $medr_agent,
                          mdeal      = mdeal      + $mdeal,
                          mdeal_nt   = mdeal_nt   + $mdeal
                    WHERE ipolicy1    = $ply1
                      AND ipolicy2    = $ply2
                      AND iendorse    = $iendorse
                      AND insure_kind = $kclsfyitem;

                  if (sqlca.sqlerrd[2]==0)
                  {
                       $INSERT INTO ao_cmt_dtl_tmp
                                (ipolicy1,ipolicy2,iendorse,insure_kind,icur,
                                 mcommit,   magent,   mdeal,          ptax,
                                 mcommit_nt,magent_nt,mdeal_nt, iofficer, ibroker, ibroker_top)
                         VALUES ($ply1,$ply2,$iendorse,$kclsfyitem,"NT",
                                 $medr_commission,$medr_agent,$mdeal, $ptax_1,
                                 $medr_commission,$medr_agent,$mdeal, $iofficer, $ibroker, $ibroker_top);
                  }
             }
        }
        $CLOSE q_commi_2;

        if (fcard_class[0]=='2')
        {
             if (total_mprem < 0)
             {
                 $UPDATE ao_cmt_dtl_tmp
                     SET mcommit    = (-1) * mcommit,
                         mcommit_nt = (-1) * mcommit_nt,
                         magent     = (-1) * magent,
                         magent_nt  = (-1) * magent_nt,
                         mdeal      = (-1) * mdeal,
                         mdeal_nt   = (-1) * mdeal_nt
                   WHERE ipolicy1    = $ply1
                     AND ipolicy2    = $ply2
                     AND iendorse    = $iendorse;
             }
             else if (fedr_class[0] == 'B')
             {
                 if (total_mcommission < 0)
                 {
                      $UPDATE ao_cmt_dtl_tmp
                          SET mcommit    = (-1) * mcommit,
                              mcommit_nt = (-1) * mcommit_nt,
                              magent     = (-1) * magent,
                              magent_nt  = (-1) * magent_nt,
                              mdeal      = (-1) * mdeal,
                              mdeal_nt   = (-1) * mdeal_nt
                        WHERE ipolicy1    = $ply1
                          AND ipolicy2    = $ply2
                          AND iendorse    = $iendorse;
                 }
                 else if ((total_magent < 0) ) /* && (total_mcommission == 0)) */
                 {
                      $UPDATE ao_cmt_dtl_tmp
                          SET mcommit    = (-1) * mcommit,
                              mcommit_nt = (-1) * mcommit_nt,
                              magent     = (-1) * magent,
                              magent_nt  = (-1) * magent_nt,
                              mdeal      = (-1) * mdeal,
                              mdeal_nt   = (-1) * mdeal_nt
                        WHERE ipolicy1    = $ply1
                          AND ipolicy2    = $ply2
                          AND iendorse    = $iendorse;
                 }
             }
        }
        else
        {
             if (total_mprem < 0)
             {
                 $UPDATE ao_cmt_dtl_tmp
                     SET mcommit    = (-1) * mcommit,
                         mcommit_nt = (-1) * mcommit_nt,
                         magent     = (-1) * magent,
                         magent_nt  = (-1) * magent_nt,
                         mdeal      = (-1) * mdeal,
                         mdeal_nt   = (-1) * mdeal_nt
                   WHERE ipolicy1    = $ply1
                     AND ipolicy2    = $ply2
                     AND iendorse    = $iendorse;
             }
             else if (fedr_class[0] == 'B')
             {
                 if (total_mcommission < 0)
                 {
                      $UPDATE ao_cmt_dtl_tmp
                          SET mcommit    = (-1) * mcommit,
                              mcommit_nt = (-1) * mcommit_nt,
                              magent     = (-1) * magent,
                              magent_nt  = (-1) * magent_nt,
                              mdeal      = (-1) * mdeal,
                              mdeal_nt   = (-1) * mdeal_nt
                        WHERE ipolicy1    = $ply1
                          AND ipolicy2    = $ply2
                          AND iendorse    = $iendorse;
                 }
 
             }
        }

        $INSERT INTO ao_commit_detail
           (ipolicy1, ipolicy2, iendorse, insure_kind, icur, mcommit, magent, mdeal,
            ptax, mcommit_nt, magent_nt, mdeal_nt, pagent, iofficer, ibroker, ori_magent_nt,
            ori_mcommit_nt, ibroker_top)
         SELECT *
           FROM ao_cmt_dtl_tmp;

        $DROP TABLE ao_cmt_dtl_tmp;

        if (*fedr_class == '3') /*���g��H*/
        {
           $UPDATE ao_commit_detail
               SET iofficer = $iofficer,
                   ibroker  = $ibroker,
                   ibroker_top  = $ibroker_top
             WHERE ipolicy1 = $ply1
               AND ipolicy2 = $ply2;
        }


        $SELECT sum( a.mcommit), sum( a.magent), sum( a.mdeal),
                (select sum(mcommit) from ao_commit_detail c
                  where a.ipolicy1 = c.ipolicy1
                    and a.ipolicy2 = c.ipolicy2
                    and a.iendorse = c.iendorse),
                (select sum(magent) from ao_commit_detail c
                  where a.ipolicy1 = c.ipolicy1
                    and a.ipolicy2 = c.ipolicy2
                    and a.iendorse = c.iendorse),
                (select sum(mdeal) from ao_commit_detail c
                  where a.ipolicy1 = c.ipolicy1
                    and a.ipolicy2 = c.ipolicy2
                    and a.iendorse = c.iendorse)
           into $mcommitMain, $magentMain, $mdealMain,
                $mcommitDetail, $magentDetail, $mdealDetail
           from ao_officer_commit a
          where a.ipolicy1 = $ply1 
            and a.ipolicy2 = $ply2 
            and a.iendorse = $iendorse 
         group by a.ipolicy1, a.ipolicy2, a.iendorse
         having ( sum(a.mcommit) <> (select sum(mcommit) from ao_commit_detail b
                                      where a.ipolicy1 = b.ipolicy1
                                        and a.ipolicy2 = b.ipolicy2
                                        and a.iendorse = b.iendorse ) or
                   sum(a.magent) <> (select sum(magent) from ao_commit_detail b
                                      where a.ipolicy1 = b.ipolicy1
                                        and a.ipolicy2 = b.ipolicy2
                                        and a.iendorse = b.iendorse) or
                    sum(a.mdeal) <> (select sum(mdeal) from ao_commit_detail b
                                      where a.ipolicy1 = b.ipolicy1
                                        and a.ipolicy2 = b.ipolicy2
                                        and a.iendorse = b.iendorse) );
        printf("iendorse[%s]=========================================[%d]\n", iendorse,SQLCODE);
        if( SQLCODE == 0)
        {
            memset(err_buf,0,sizeof(err_buf));

            sprintf( err_buf,"�O��1[%s],�O��2[%s],���[%s],\n����[%d][%d],�N�z�O[%d][%d],����O[%d][%d]�D�ɩ��Ӥ��X\n", 
                              ply1, ply2, iendorse, mcommitMain, mcommitDetail,
                              magentMain, magentDetail, mdealMain, mdealDetail);
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            return FAIL;
        }

        EdrCurr=EdrCurr->next;
    }

    /**** STEP P.2--(9) *****************************************/
    printf("*********** into P.2--(9),ao_io_credit,ao_prem_return\n");

    strncpy(iunit, DBname, 2);
    iunit[2]='\0';

    EdrCurr=EdrFirst;
    while (EdrCurr)
    {
        printf("***** into ao_io_credit, ao_prem_return iendorse[%s]\n",
                            EdrCurr->iendorse);

        strcpy(iendorse,        EdrCurr->iendorse);
        strcpy(ipolicy,         EdrCurr->ipolicy);
        strcpy(fedr_class,      EdrCurr->fedr_class);
        strcpy(dcreate,         EdrCurr->dcreate);

        check_910401 = EdrCurr->check_910401;

        if (check_910401 == 1)
        {
             dTmpPrem = (float) (EdrCurr->edr_mprem - EdrCurr->edr_mdisc);
        }
        else
        {
             dTmpPrem = (float) (EdrCurr->edr_mprem);
        }

        if (*fedr_class == '1' || *fedr_class == '2' || *fedr_class == '3' || 
            *fedr_class == '4' || *fedr_class == '5')
        {
            EdrCurr=EdrCurr->next;
            continue;
        }

        rc = check_dedr_close( ipolicy, iendorse, dcreate);

        if( rc != M_CM_OK)
        {
             EdrCurr=EdrCurr->next;
             continue;
        }

        /*----------*/
        memset(err_buf, 0, sizeof(err_buf));
        strcpy(err_buf, iendorse);
        rtncode = split_policy(ipolicy, ply1, ply2);
        if (rtncode != M_CM_OK)
        {
            strcat(err_buf, ":split_policy error:");
            strcat(err_buf, itoa(rtncode));
            goto optP_err1;
        }
        if (dTmpPrem > 0) /*��[*/
        {
            rtncode = cm_credit_pay_dailyupdate(ply1, ply2, iendorse,fcommit,
                                                iofficer, iunit);
            if (rtncode != M_CM_OK)
            {
               strcat(err_buf, ":insert into ao_io_credit error:");
               strcat(err_buf, itoa(rtncode));
               goto optP_err1;
            }
        }

        EdrCurr=EdrCurr->next;
    }

    /**** STEP P.2--(11) *****************************************/
    printf("*********** into P.2--(11) insert ply_ins_type_hist\n");

    EdrCurr=EdrFirst;

    while (EdrCurr)
    {
        strcpy(iendorse,EdrCurr->iendorse);
        strcpy(ipolicy,EdrCurr->ipolicy);
        strcpy(fedr_class,EdrCurr->fedr_class);
        strcpy(dcreate,EdrCurr->dcreate);

        ply_begin = EdrCurr->ply_begin;
        ply_end   = EdrCurr->ply_end;
        edr_begin = EdrCurr->edr_begin;
        edr_end   = EdrCurr->edr_end;
        
        strcpy(dtply_begin,EdrCurr->dtply_begin); /* 1061108001_SC6_�t�X�s�еo�i���ߨt�λݨD���Ѭ����t�Υ\�� yyyy-mm-dd HH:MM */    
        strcpy(dtply_end  ,EdrCurr->dtply_end);
        strcpy(dtedr_begin,EdrCurr->dtedr_begin);
        strcpy(dtedr_end  ,EdrCurr->dtedr_end);

        check_910401 = EdrCurr->check_910401;

        if (fedr_class[0]=='2' || fedr_class[0]=='3')
        {
            EdrCurr=EdrCurr->next;
            continue;
        }

        rc = check_dedr_close( ipolicy, iendorse, dcreate);

        if( rc != M_CM_OK)
        {
             EdrCurr=EdrCurr->next;
             continue;
        }

        /*----------------------------------*/
        $SELECT dply_begin,dply_end,dtply_begin,dtply_end
           INTO $ori_begin,$ori_end,$ori_dtply_begin,$ori_dtply_end
           FROM ori_ply_relation
          WHERE ipolicy=$ipolicy;
        
        if ( (strlen(trim(ori_dtply_begin))>0) && (strlen(trim(dtply_begin))>0) ) /* 1061108001_SC6_�t�X�s�еo�i���ߨt�λݨD���Ѭ����t�Υ\�� yyyy-mm-dd HH:MM */    
        {
	        if (strcmp(ori_dtply_begin,dtply_begin) != 0)
	        {
	            $UPDATE ply_ins_type_hist
	                SET dedr_begin = $ply_begin,
	                    dedr_end   = $ply_end,
	                    dtedr_begin = $dtply_begin,
	                    dtedr_end   = $dtply_end
	              WHERE ipolicy    = $ipolicy
	                AND dendorse IS NULL
	                AND (fedr_status IS NULL OR fedr_status =" ");
	        }        	
        }	
        else
        {	
	        if (ori_begin != ply_begin)
	        {
	            $UPDATE ply_ins_type_hist
	                SET dedr_begin = $ply_begin,
	                    dedr_end   = $ply_end
	              WHERE ipolicy    = $ipolicy
	                AND dendorse IS NULL
	                AND (fedr_status IS NULL OR fedr_status =" ");
	        }
        }
/*
        if (fedr_class[0]=='5')
        {
            EdrCurr=EdrCurr->next;
            continue;
        }
*/
        strcpy(iendorse_next,"");

        printf("before get iendorse_next ipolicy[%s], dcreate[%s]\n", ipolicy, dcreate);
        $select first 1 a.iendorse
           into $iendorse_next
           from edr_relation a
          where a.ipolicy = $ipolicy
            and a.iendorse not like '%CVP%'
            and a.dcreate > $dcreate order by a.dcreate, a.iendorse;

        printf("SQLCODE[%d]\n", SQLCODE);

        printf("end get iendorse_next ipolicy[%s], dcreate[%s]\n", ipolicy, dcreate);

        if (risnull(SQLCHAR, iendorse_next) == 1) iLatest = 1; 

        printf("iendorse[%s],iLatest[%d], iendorse_next[%s]\n", iendorse,iLatest,iendorse_next);

        printf("fedr_class[%s]\n", fedr_class);
        /*----------------------------------*/
        if (fedr_class[0]=='1')  /* ���P */
        {

            if( iLatest == 1) /* ���̫�@�i���, �H�̷s�O���I������J���v�� */
                sprintf( stmt1, "SELECT iins_type ,provision"
                                "  FROM ply_ins_type "
                                " WHERE ipolicy='%s' ", ipolicy);
            else /* ���O�̫�@�i���, �H�᣸�i����e�̷s�O���I������J���v�� */
                sprintf( stmt1, "SELECT iins_type ,provision"
                                "  FROM ply_ins_type_bak "
                                " WHERE iendorse='%s' ", iendorse_next);

            printf("stmt1[%s]\n", stmt1);

            $PREPARE prep_a FROM $stmt1;
            $DECLARE cur_hist2 CURSOR FOR prep_a;
            printf("SQLCODE[%d]\n", SQLCODE);

            $OPEN cur_hist2;
            while (1)
            {
                  $FETCH cur_hist2 INTO $iins_type,$provision;
                  if( SQLCODE == SQLNOTFOUND) break;
   
                  memset(err_buf,0,sizeof(err_buf));
                  strcpy(err_buf,"insert ply_ins_type_hist ");
                  strcat(err_buf,"when fedr_class=1:");
                  strcat(err_buf,ipolicy);
                  strcat(err_buf,",");
                  strcat(err_buf,iins_type);
                  
                  iCount = 0;
                  if (strlen(trim(dtedr_begin))>0) /* 1061108001_SC6_�t�X�s�еo�i���ߨt�λݨD���Ѭ����t�Υ\�� yyyy-mm-dd HH:MM */    
                  {
	                  $SELECT COUNT(*)
	                     INTO $iCount
	                     FROM ply_ins_type_hist
	                    WHERE ipolicy      = $ipolicy
	                      AND iins_type    = $iins_type
	                      AND dtedr_begin  = $dtedr_begin
	                      AND fedr_status  = '01'
	                      AND dendorse     = $edrdate;
	
	                  if( iCount != 0)
	                  {
	                      $DELETE FROM ply_ins_type_hist
	                        WHERE ipolicy      = $ipolicy
	                          AND iins_type    = $iins_type
	                          AND dtedr_begin  = $dtedr_begin
	                          AND fedr_status  = '01'
	                          AND dendorse     = $edrdate;
	                  }                  	
                  }	
                  else
                  {                                    
	                  $SELECT COUNT(*)
	                     INTO $iCount
	                     FROM ply_ins_type_hist
	                    WHERE ipolicy     = $ipolicy
	                      AND iins_type   = $iins_type
	                      AND dedr_begin  = $edr_begin
	                      AND fedr_status = '01'
	                      AND dendorse    = $edrdate;
	
	                  if( iCount != 0)
	                  {
	                      $DELETE FROM ply_ins_type_hist
	                        WHERE ipolicy     = $ipolicy
	                          AND iins_type   = $iins_type
	                          AND dedr_begin  = $edr_begin
	                          AND fedr_status = '01'
	                          AND dendorse    = $edrdate;
	                  }
                  }
                  $INSERT INTO ply_ins_type_hist
                               (ipolicy,iins_type,
                                dedr_begin,dedr_end, fedr_status,dendorse,
                                minjured_cover,mdeath_cover, mdamage_cover,mdeduct,mpremium,
                                qday,mexpense,provision,dtedr_begin,dtedr_end)
                        VALUES ($ipolicy,$iins_type,
                                $edr_begin,$edr_end,"01", $edrdate,
                                0,0,0,0,0,
                                0,0,$provision,$dtedr_begin,$dtedr_end);

                  #ifdef CA_CONS
                  memset(err_buf,0,sizeof(err_buf));
                  strcpy(err_buf,"insert ply_ins_cover_hist ");
                  strcat(err_buf,"when fedr_class=1:");
                  strcat(err_buf,ipolicy);
                  strcat(err_buf,",");
                  strcat(err_buf,iins_type);

                  if( iLatest == 1) /* ���̫�@�i���, �H�̷s�O���I������J���v�� */
                      sprintf( stmt2, " SELECT icover_type, mcover, mcover_prem, mdiscount, mprem, mpure_prem "
                                      "   FROM ply_ins_cover "
                                      "  WHERE ipolicy = '%s' AND iins_type = '%s' ", ipolicy, iins_type);
                  else /* ���O�̫�@�i���, �H�᣸�i����e�̷s�O���I������J���v�� */
                      sprintf( stmt2, " SELECT icover_type, mcover, mcover_prem, mdiscount, mprem, mpure_prem "
                                      "   FROM ply_ins_cover_bak "
                                      "  WHERE iendorse = '%s' AND iins_type = '%s' ", iendorse_next, iins_type);

                  printf("stmt2[%s]\n", stmt2);
                  $PREPARE prep_b FROM $stmt2;
                  $DECLARE cur_hist4 CURSOR FOR prep_b;
                  $OPEN cur_hist4;
                  while (1)
                  {
                      $FETCH cur_hist4 INTO $icover_type, $mcover, $mcover_prem, $mdiscount_cover, $mprem_cover, $mpure_prem;

                      if( SQLCODE == SQLNOTFOUND) break;

                      $SELECT COUNT(*)
                         INTO $iCount
                         FROM ply_ins_cover_hist
                        WHERE ipolicy     = $ipolicy
                          AND iins_type   = $iins_type
                          AND icover_type = $icover_type
                          AND dedr_begin  = $edr_begin
                          AND dendorse    = $edrdate;

                      if( iCount != 0)
                      {
                          $DELETE FROM ply_ins_cover_hist
                            WHERE ipolicy     = $ipolicy
                              AND iins_type   = $iins_type
                              AND icover_type = $icover_type
                              AND dedr_begin  = $edr_begin
                              AND dendorse    = $edrdate;
                      }

                      $INSERT INTO ply_ins_cover_hist
                                   (ipolicy, iins_type, icover_type,
                                    dedr_begin, dedr_end, dendorse,
                                    mcover, mcover_prem, mdiscount, mprem, mpure_prem)
                            VALUES ($ipolicy, $iins_type, $icover_type,
                                    $edr_begin, $edr_end, $edrdate, 0,0,0,0,0 );
                  }
                  #endif

                  puts("begin �ˮ`�I");
 
                  if( (strcmp(trim(iins_type),"33")==0) || (strcmp(trim(iins_type),"35")==0) ||
                      (strcmp(trim(iins_type),"48")==0) || (strcmp(trim(iins_type),"56")==0) ||
                      (strcmp(trim(iins_type),"136")==0) || (strcmp(trim(iins_type),"166")==0)||
                      (strcmp(trim(iins_type),"266")==0) )
                  {
                        if( iLatest == 1) /* ���̫�@�i���, �H�̷s�O���I������J���v�� */
                          sprintf( stmt3, " SELECT nvl(iinsurant,''), nvl(iins_scope,''), nvl(icareer,'') "
                                          "   FROM ca_pa_ply "
                                          "  WHERE ipolicy = '%s' "
                                          "    AND iins_type = '%s' ", ipolicy, iins_type);
                        else /* ���O�̫�@�i���, �H�᣸�i����e�̷s�O���I������J���v�� */
                          sprintf( stmt3, " SELECT nvl(iinsurant,''), nvl(iins_scope,''), nvl(icareer,'') "
                                          "   FROM ca_pa_ply_bak "
                                          "  WHERE iendorse = '%s' "
                                          "    AND iins_type = '%s' ", iendorse_next, iins_type);

                        printf("stmt3[%s]\n", stmt3);
                        $PREPARE prep_c FROM $stmt3;
                        $DECLARE pa_hist CURSOR FOR prep_c;
                        $OPEN pa_hist;

                        while (1)
                        {
                              $FETCH pa_hist INTO $iinsurant, $iins_scope, $icareer;
                              if( SQLCODE == SQLNOTFOUND) break;

                              memset(err_buf,0,sizeof(err_buf));
                              strcpy(err_buf,"insert ca_pa_ply_hist ");
                              strcat(err_buf,"when fedr_class=1:");
                              strcat(err_buf,ipolicy);
                              strcat(err_buf,",");
                              strcat(err_buf,iinsurant);

                              $SELECT COUNT(*)
                                 INTO $iCount
                                 FROM ca_pa_ply_hist
                                WHERE ipolicy = $ipolicy
                                  AND iins_type = $iins_type
                                  AND nvl(iinsurant,'') = $iinsurant
                                  AND nvl(iins_scope,'') = $iins_scope
                                  AND nvl(icareer,'') = $icareer
                                  AND dedr_begin = $edr_begin
                                  AND fedr_status = '01'
                                  AND dendorse = $edrdate;
                              if( iCount != 0)
                              {
                                  $DELETE FROM ca_pa_ply_hist
                                    WHERE ipolicy = $ipolicy
                                      AND iins_type = $iins_type
                                      AND nvl(iinsurant,'') = $iinsurant
                                      AND nvl(iins_scope,'') = $iins_scope
                                      AND nvl(icareer,'') = $icareer
                                      AND dedr_begin = $edr_begin
                                      AND fedr_status = '01'
                                      AND dendorse = $edrdate;
                              }  
                              $INSERT INTO ca_pa_ply_hist
                                           (ipolicy,iins_type,iinsurant,iins_scope,
                                            icareer,dedr_begin,dedr_end,
                                            fedr_status,dendorse,
                                            mins_amt,mins_premium)
                                    VALUES ($ipolicy,$iins_type,$iinsurant,$iins_scope,
                                            $icareer,$edr_begin,$edr_end,
                                            "01", $edrdate,
                                            0,0);
                        }
                        $CLOSE pa_hist;
                  }
            }
            $CLOSE cur_hist2;
        }
        else
        {
            if( iLatest == 1) /* ���̫�@�i���, �H�̷s�O���I������J���v�� */
              sprintf( stmt1, " SELECT A.iins_type,B.iedr_type, "
                              "        A.minjured_cover,A.mdeath_cover,A.mdamage_cover, "
                              "        A.mdeduct,A.mins_premium,A.qday,A.mexpense,A.provision "
                              "   FROM ply_ins_type A, edr_ins_type B "
                              "  WHERE A.ipolicy   = '%s' "
                              "    AND A.iendorse  = '%s' "
                              "    AND B.iendorse  = '%s' "
                              "    AND A.iins_type = B.iins_type ", ipolicy, iendorse, iendorse);
            else /* ���O�̫�@�i���, �H�᣸�i����e�̷s�O���I������J���v�� */
              sprintf( stmt1, " SELECT A.iins_type,B.iedr_type, "
                              "        A.minjured_cover,A.mdeath_cover,A.mdamage_cover, "
                              "        A.mdeduct,A.mins_premium,A.qday,A.mexpense,A.provision "
                              "   FROM ply_ins_type_bak A, edr_ins_type B "
                              "  WHERE A.iendorse  = '%s' "
                              "    AND B.iendorse  = '%s' "
                              "    AND A.iins_type = B.iins_type ", iendorse_next, iendorse);

            printf("stmt1[%s]\n", stmt1);
            $PREPARE prep_d FROM $stmt1;
            $DECLARE cur_hist3 CURSOR FOR prep_d;

            $OPEN cur_hist3;

            while (1)
            {
                  $FETCH cur_hist3
                    INTO $iins_type,$iedr_type,
                         $minjured_cover,$mdeath_cover,$mdamage_cover,
                         $mdeduct,$prem1,$qday,$mexpense,$provision;
                  if( SQLCODE == SQLNOTFOUND) break;

                  memset(err_buf,0,sizeof(err_buf));
                  strcpy(err_buf,"insert ply_ins_type_hist ");
                  strcat(err_buf,"when fedr_class!=1:");
                  strcat(err_buf,ipolicy);
                  strcat(err_buf,",");
                  strcat(err_buf,iendorse);
                  strcat(err_buf,",");
                  strcat(err_buf,iins_type);
                  strcat(err_buf,",");
                  strcat(err_buf,iedr_type);

                  iCount = 0;
                  if (strlen(trim(dtedr_begin))>0) /* 1061108001_SC6_�t�X�s�еo�i���ߨt�λݨD���Ѭ����t�Υ\�� yyyy-mm-dd HH:MM */    
                  {
	                  $SELECT COUNT(*)
	                     INTO $iCount
	                     FROM ply_ins_type_hist
	                    WHERE ipolicy      = $ipolicy
	                      AND iins_type    = $iins_type
	                      AND dtedr_begin  = $dtedr_begin
	                      AND fedr_status  = $iedr_type
	                      AND dendorse     = $edrdate;
	
	                  if( iCount != 0)
	                  {
	                      $DELETE FROM ply_ins_type_hist
	                        WHERE ipolicy      = $ipolicy
	                          AND iins_type    = $iins_type
	                          AND dtedr_begin  = $dtedr_begin
	                          AND fedr_status  = $iedr_type
	                          AND dendorse     = $edrdate;
	                  }                  	
                  }	
                  else
                  {                                    
	                  $SELECT COUNT(*)
	                     INTO $iCount
	                     FROM ply_ins_type_hist
	                    WHERE ipolicy     = $ipolicy
	                      AND iins_type   = $iins_type
	                      AND dedr_begin  = $edr_begin
	                      AND fedr_status = $iedr_type
	                      AND dendorse    = $edrdate;
	
	                  if( iCount != 0)
	                  {
	                      $DELETE FROM ply_ins_type_hist
	                        WHERE ipolicy     = $ipolicy
	                          AND iins_type   = $iins_type
	                          AND dedr_begin  = $edr_begin
	                          AND fedr_status = $iedr_type
	                          AND dendorse    = $edrdate;
	                  }
                  }                

                  $INSERT INTO ply_ins_type_hist
                               (ipolicy,iins_type,dedr_begin,dedr_end,
                                fedr_status,dendorse,
                                minjured_cover,mdeath_cover,
                                mdamage_cover,mdeduct,mpremium,qday,mexpense,provision,dtedr_begin,dtedr_end)
                        VALUES ($ipolicy,$iins_type,$edr_begin,$edr_end,
                                $iedr_type,$edrdate,
                                $minjured_cover,$mdeath_cover,
                                $mdamage_cover,$mdeduct,$prem1,$qday,$mexpense,$provision,$dtedr_begin,$dtedr_end);

                  #ifdef CA_CONS
                  memset(err_buf,0,sizeof(err_buf));
                  strcpy(err_buf,"insert ply_ins_cover_hist ");
                  strcat(err_buf,"when fedr_class!=1:");
                  strcat(err_buf,ipolicy);
                  strcat(err_buf,",");
                  strcat(err_buf,iins_type);

                  if( iLatest == 1) /* ���̫�@�i���, �H�̷s�O���I������J���v�� */
                      sprintf( stmt2, " SELECT icover_type, mcover, mcover_prem, mdiscount, mprem, mpure_prem "
                                      "   FROM ply_ins_cover "
                                      "  WHERE ipolicy = '%s' AND iins_type = '%s' ", ipolicy, iins_type);
                  else /* ���O�̫�@�i���, �H�᣸�i����e�̷s�O���I������J���v�� */
                      sprintf( stmt2, " SELECT icover_type, mcover, mcover_prem, mdiscount, mprem, mpure_prem "
                                      "   FROM ply_ins_cover_bak "
                                      "  WHERE iendorse = '%s' AND iins_type = '%s' ", iendorse_next, iins_type);

                  printf("stmt2[%s]\n", stmt2);
                  $PREPARE prep_e FROM $stmt2;
                  $DECLARE cur_hist5 CURSOR FOR prep_e;
                  printf("SQLCODE[%d]\n", SQLCODE);
                  $OPEN cur_hist5;
                  while (1)
                  {
                      $FETCH cur_hist5 INTO $icover_type, $mcover, $mcover_prem, $mdiscount_cover, $mprem_cover, $mpure_prem;

                      if( SQLCODE == SQLNOTFOUND) break;

                      $SELECT COUNT(*)
                         INTO $iCount
                         FROM ply_ins_cover_hist
                        WHERE ipolicy     = $ipolicy
                          AND iins_type   = $iins_type
                          AND icover_type = $icover_type
                          AND dedr_begin  = $edr_begin
                          AND dendorse    = $edrdate;

                      if( iCount != 0)
                      {
                          $DELETE FROM ply_ins_cover_hist
                            WHERE ipolicy     = $ipolicy
                              AND iins_type   = $iins_type
                              AND icover_type = $icover_type
                              AND dedr_begin  = $edr_begin
                              AND dendorse    = $edrdate;
                      }

                      $INSERT INTO ply_ins_cover_hist
                                   (ipolicy, iins_type, icover_type,
                                    dedr_begin, dedr_end, dendorse,
                                    mcover, mcover_prem, mdiscount, mprem, mpure_prem)
                            VALUES ($ipolicy, $iins_type, $icover_type,
                                    $edr_begin, $edr_end, $edrdate, 
                                    $mcover, $mcover_prem, $mdiscount_cover, $mprem_cover, $mpure_prem);
                  }
                  #endif

                  puts("begin �ˮ`�I");
                  if( (strcmp(trim(iins_type),"33")==0) || (strcmp(trim(iins_type),"35")==0) ||
                      (strcmp(trim(iins_type),"48")==0) || (strcmp(trim(iins_type),"56")==0) ||
                      (strcmp(trim(iins_type),"136")==0) || (strcmp(trim(iins_type),"166")==0)|| 
                      (strcmp(trim(iins_type),"266")==0) )
                  {
                        if( iLatest == 1) /* ���̫�@�i���, �H�̷s�O���I������J���v�� */
                          sprintf( stmt3, " SELECT nvl(A.iinsurant,''), nvl(A.iins_scope,''), nvl(A.icareer,''), "
                                          "        B.iedr_type, A.mins_amt, A.mins_premium, A.daily_pay "
                                          "   FROM ca_pa_ply A, ca_pa_edr B "
                                          "  WHERE A.ipolicy   = '%s' "
                                          "    AND A.iendorse  = '%s' "
                                          "    AND B.iendorse  = '%s' "
                                          "    AND nvl(A.iinsurant,'')  = nvl(B.iinsurant,'') "
                                          "    AND nvl(A.iins_scope,'') = nvl(B.iins_scope,'') "
                                          "    AND nvl(A.icareer,'')    = nvl(B.icareer,'') "
                                          "    AND A.iins_type  = '%s' "
                                          "    AND B.iins_type  = '%s' ", ipolicy, iendorse, iendorse, iins_type, iins_type);
                        else /* ���O�̫�@�i���, �H�᣸�i����e�̷s�O���I������J���v�� */
                          sprintf( stmt3, " SELECT nvl(A.iinsurant,''), nvl(A.iins_scope,''), nvl(A.icareer,''), "
                                          "        B.iedr_type, A.mins_amt, A.mins_premium, A.daily_pay "
                                          "   FROM ca_pa_ply_bak A, ca_pa_edr B "
                                          "  WHERE A.iendorse  = '%s' "
                                          "    AND B.iendorse  = '%s' "
                                          "    AND nvl(A.iinsurant,'')  = nvl(B.iinsurant,'') "
                                          "    AND nvl(A.iins_scope,'') = nvl(B.iins_scope,'') "
                                          "    AND nvl(A.icareer,'')    = nvl(B.icareer,'') "
                                          "    AND A.iins_type  = '%s' "
                                          "    AND B.iins_type  = '%s' ", iendorse_next, iendorse, iins_type, iins_type);

                        printf("stmt3[%s]\n", stmt3);
                        $PREPARE prep_f FROM $stmt3;
                        $DECLARE pa_hist2 CURSOR FOR prep_f;

                        $OPEN pa_hist2;

                        while (1)
                        {
                              $FETCH pa_hist2
                                INTO $iinsurant,$iins_scope,$icareer,
                                     $iedr_type,
                                     $mins_amt,
                                     $mins_premium,
                                     $daily_pay;
                              if( SQLCODE == SQLNOTFOUND) break;

                              memset(err_buf,0,sizeof(err_buf));
                              strcpy(err_buf,"insert ca_pa_ply_hist ");
                              strcat(err_buf,"when fedr_class!=1:");
                              strcat(err_buf,ipolicy);
                              strcat(err_buf,",");
                              strcat(err_buf,iendorse);
                              strcat(err_buf,",");
                              strcat(err_buf,iinsurant);
                              strcat(err_buf,",");
                              strcat(err_buf,iedr_type);

                              $SELECT COUNT(*)
                                 INTO $iCount
                                 FROM ca_pa_ply_hist
                                WHERE ipolicy = $ipolicy
                                  AND iins_type = $iins_type
                                  AND nvl(iinsurant,'') = $iinsurant
                                  AND nvl(iins_scope,'') = $iins_scope
                                  AND nvl(icareer,'') = $icareer
                                  AND dedr_begin = $edr_begin
                                  AND fedr_status = $iedr_type
                                  AND dendorse = $edrdate;
                              if( iCount != 0)
                              {
                                  $DELETE FROM ca_pa_ply_hist
                                    WHERE ipolicy = $ipolicy
                                      AND iins_type = $iins_type
                                      AND nvl(iinsurant,'') = $iinsurant
                                      AND nvl(iins_scope,'') = $iins_scope
                                      AND nvl(icareer,'') = $icareer
                                      AND dedr_begin = $edr_begin
                                      AND fedr_status = $iedr_type
                                      AND dendorse = $edrdate;
                              }  
                              $INSERT INTO ca_pa_ply_hist
                                           (ipolicy,iins_type,iinsurant,iins_scope,icareer,
                                            dedr_begin,dedr_end,
                                            fedr_status,dendorse,
                                            mins_amt,mins_premium,
                                            daily_pay)
                                    VALUES ($ipolicy,$iins_type,$iinsurant,$iins_scope,$icareer,
                                            $edr_begin,$edr_end,
                                            $iedr_type,$edrdate,
                                            $mins_amt,$mins_premium,
                                            $daily_pay);
                        }
                        $CLOSE pa_hist2;
                  }

                  #ifdef CA_ONE

                  memset(err_buf,0,sizeof(err_buf));
                  strcpy(err_buf,"insert ply_ins_assured_hist:");
                  strcat(err_buf,"when fedr_class=1:");
                  strcat(err_buf,ipolicy);
                  strcat(err_buf,",");
                  strcat(err_buf,iins_type);

                  /*if( strstr( provision, "D"))*/
                  if ( IsProvExist( "D", provision) == TRUE )  /* 1081225006_SC3 �X�R���[���ڥN�X */
                  {
                      puts("DDDD");
                      strcpy( iins_typeTmp, " ");
                      strcpy( provision, "D");
                  }
                  /*else if( strstr( provision, "J"))*/
                  else if ( IsProvExist( "J", provision) == TRUE )  /* 1081225006_SC3 �X�R���[���ڥN�X */
                  {
                      puts("JJJJ");
                      strcpy( iins_typeTmp, " ");
                      strcpy( provision, "J");
                  }
                  else
                  {
                      puts("not D, J");
                      strcpy( iins_typeTmp, iins_type);
                      strcpy( provision, " ");
                  }
                  printf("iins_typeTmp[%s]\n", iins_typeTmp);
                  printf("provision[%s]\n", provision);

                  if( iLatest == 1) /* ���̫�@�i���, �H�̷s�O���I������J���v�� */
                    sprintf( stmt4, "SELECT iassured, nassured, dbirth, nbenef, rel_benef, tbenef, abenef_zip, abenef "
                                    "  FROM ply_ins_assured "
                                    " WHERE ipolicy = '%s' AND iins_type = '%s' AND provision = '%s' ", ipolicy, iins_typeTmp, provision);
                  else /* ���O�̫�@�i���, �H�᣸�i����e�̷s�O���I������J���v�� */
                    sprintf( stmt4, "SELECT iassured, nassured, dbirth, nbenef, rel_benef, tbenef, abenef_zip, abenef "
                                    "  FROM ply_ins_assured_bak "
                                    " WHERE iendorse = '%s' AND iins_type = '%s' AND provision = '%s' ", iendorse_next, iins_typeTmp, provision);
                  printf("stmt4[%s]\n", stmt4);
                  $PREPARE prep_g FROM $stmt4;
                  $DECLARE cur_hist7 CURSOR FOR prep_g;
                  $OPEN cur_hist7;
                  while (1)
                  {
                        $FETCH cur_hist7 INTO $iassured, $nassured, $dbirth, $nbenef, $rel_benef, $tbenef, $abenef_zip, $abenef;
    
                        if( SQLCODE == SQLNOTFOUND) break;
    
                        strcat(err_buf,",");
                        strcat(err_buf,iassured);

                        $SELECT COUNT(*)
                           INTO $iCount
                           FROM ply_ins_assured_hist
                          WHERE ipolicy     = $ipolicy
                            AND iins_type   = $iins_typeTmp
                            AND iassured    = $iassured
                            AND dedr_begin  = $edr_begin
                            AND dendorse    = $edrdate
                            AND provision   = $provision;
printf("iCount[%d]\n", iCount);
                        if( iCount != 0)
                        {
                            $DELETE FROM ply_ins_assured_hist
                              WHERE ipolicy     = $ipolicy
                                AND iins_type   = $iins_typeTmp
                                AND iassured    = $iassured
                                AND dedr_begin  = $edr_begin
                                AND dendorse    = $edrdate
                                AND provision   = $provision;
                        }

                        $INSERT INTO ply_ins_assured_hist
                                     (ipolicy , iins_type, iassured, nassured, dbirth, nbenef, rel_benef,
                                      dendorse , dedr_begin , dedr_end, provision, tbenef, abenef_zip, abenef)
                              VALUES ($ipolicy , $iins_typeTmp, $iassured, $nassured, $dbirth, $nbenef, $rel_benef,
                                      $edrdate,  $edr_begin, $edr_end, $provision, $tbenef, $abenef_zip, $abenef);
                  }
                  $CLOSE cur_hist7;
    
                  #endif
            }
            $CLOSE cur_hist3;
        }
        EdrCurr=EdrCurr->next;
    }


        
    /****************     IFRS17   *********************/
    /*1111101004_SC1 ��氣�C���t�λݨD�� */

    /*1111101004_SC2 ��氣�C���t�λݨD��*/
    /* �����ҥΦ۰ʲ��ͤ@���@�t���\��A�L���P�_IFRS17 �ҥΤ�*/

    /*printf("fIFRS_Go[%s]\n",fIFRS_Go);
    if (strcmp(fIFRS_Go, "Y") == 0) *  IFRS17 �w�Ұ� *
    {*/
        /* check �O�_���u���C�ӷ����v(idere_type <>'')�G
        1. �Y���u���C�ӷ����v�åB�w�鵲 => ���͡u�@�t�@�����C���v�C
        2. �鵲�u�@�t�@�����C���v�C
        */
        printf("fIFRS17[%c]\n",fIFRS17);
        if (fIFRS17 != 'Y')
        {
            $int cnt = 0, cnt_err = 0;
            iCount = 0;
            strcpy(iendorse,"");
            strcpy(ipolicy ,""); 

            /* ��������鵲���u���C�ӷ����v*/   
            $DECLARE get_ifrs17 CURSOR WITH HOLD FOR
              SELECT a.iendorse, a.ipolicy         
                FROM edr_relation a, ply_relation b 
               WHERE a.ipolicy    = b.ipolicy
                 AND a.dendorse   = $edrdate
                 AND a.dedr_close = $edrdate
                 AND a.idere_type <>'';
            $OPEN get_ifrs17;
            for(;;)
            {
                $FETCH get_ifrs17 INTO $iendorse, $ipolicy;
                if (SQLCODE == SQLNOTFOUND) break;    
                
                printf("iendorse[%s], ipolicy[%s]\n",iendorse, ipolicy);


                /* �T�{���iendorse �O�_�w�s�b�P�����p���u�@�t�@�����C���v(�u���C���p��渹�v�� iendorse����� )*/                
                cnt = 0; cnt_err = 0;
                $select count(*) Into $cnt
                   from edr_relation
                  where ipolicy       = $ipolicy
                    and fedr_class    = 'A'
                    and iendorse_dere = $iendorse;
                printf("check �u���C���p��渹�v�� iendorse[%s]��cnt[%d]\n",iendorse, cnt);    
                if (cnt == 0) 
                {
                    /* ���ͤ@�t�@�����C��� */ 
                    strcpy( v_sMsg, " ");
                    strcpy( iendorse1_out, " ");  strcpy( iendorse2_out, " ");
                    printf("begin insert_edr_ifrs()\n"); 
                    rtncode = insert_edr_ifrs(iendorse,ipgid,iendorse1_out,iendorse2_out,v_sMsg);   
                    printf("rtncode[%d]\n", rtncode);
                    if( rtncode == M_CM_OK)
                    {
                        iCount++;

                        printf("IFRS17: iCount�G[%d]\n" ,iCount);
                        printf("iendorse1_out[%s]\n   " ,iendorse1_out);
                        printf("iendorse2_out[%s]\n\n " ,iendorse2_out);
                    }
                    else
                    {
                        memset(err_buf,0,sizeof(err_buf));
                        cnt_err++;
                        printf("IFRS17: cnt_err[%s]\n " ,cnt_err);                                                  
                        sprintf( err_buf, "���C�ӷ���渹[%s]���ͤ@�t�@�����C��楢��(%ld)�G[%s]",iendorse,rtncode,v_sMsg);
                         
                        if (rtncode == -99999)
                        {  
                            strcat(err_buf,v_sMsg);
                        }
                        else
                        {                                                       
                            if (rtncode<0)
                            {                                
                                goto optP_err;

                            }else{
                                goto optP_err1;
                            }
                        }     

                        /* ���ͤ@�t�@�����ѡA���������鵲���\
                        if (rtncode != -99999){                        
                            strcpy( v_sMsg, cm_get_errmsg(rtncode));
                        }
                        sprintf( sErrMsg, "���C�ӷ���渹[%s](�w�鵲)���ͤ@�t�@�����C��楢��(%ld)�G[%s]",iendorse,rc,v_sMsg);
                        WRITELOG( sfp, sErrMsg);
                        continue;                      
                        */                        
                    }
                }
            }
            $CLOSE get_ifrs17;
            $FREE  get_ifrs17;  

            printf("iCount[%d]\n", iCount); 
            if (iCount > 0 )
            {
                printf("before goto IFRS17_EDR: iCount[%d]\n",iCount);
                fIFRS17 = 'Y'; 
                FreeEdrList(EdrFirst,EdrCurr);      /* free all allocated memory */
                goto IFRS17_EDR;                    /* �@�t�@��(���C)���鵲*/  
            }

            printf("IFRS17: cnt_err[%s]\n " ,cnt_err);  
        }

        /* car426�浧�鵲(fclose_type[0] == 'S')���|����ao_up_frcvpay()�A�]���i���� ao_up_frcvpay()�A
           �_�h�ߤW�鵲�ɡA����� ao_up_frcvpay()�i��|�o�͸�ƭ��� (INSERT INTO ao_prercv_detail .....)         
        else   
        {            
            if( fclose_type[0] == 'S' && fInsert_ao == TRUE)
            {
                rtncode=ao_up_frcvpay(DBname,ch_dwritten,ipgid);
                printf("AFTER ao_up_frcvpay\n");
                if (rtncode != api_OKComplete)
                {
                    memset(err_buf,0,sizeof(err_buf));
                    strcpy(err_buf,"IFRS17 �@�t�@�����C��� call ao_up_frcvpay() return ");
                    strcpy(tmp_str,itoa(rtncode));
                    strcat(err_buf,tmp_str);
                    goto optP_err1;
                }
            }
        }*/
    /*}*/


    /**** STEP P.2--(12) *****************************************/
    
    printf("*********** into P.2--(12) call ao_gl_voucher()\n");

    if( fclose_type[0] == 'B') /* �b�妸�鵲(ca5082)�ɡA��̫�i�� "���ǲ�" �Bca_edr_to_yl()�Bca_edr_mail() */ 
    {
   
        if (fInsert_ao == TRUE)
        {
       
           rtncode=ao_up_frcvpay(DBname,ch_dwritten,ipgid);
           printf("AFTER ao_up_frcvpay\n");
           if (rtncode != api_OKComplete)
           {
               memset(err_buf,0,sizeof(err_buf));
               strcpy(err_buf,"�󥿫O����ɩΦ����ɧ��g�����~:call ao_up_frcvpay() return ");
               strcpy(tmp_str,itoa(rtncode));
               strcat(err_buf,tmp_str);
               goto optP_err1;
           }

           rtncode=ao_gl_voucher(DBname,"CA2",ch_dwritten,ivoucher,"A","CA2");
           printf("\n====AFTER ao_gl_voucher(): rtncode[%d]\n",rtncode);
           if (rtncode != api_OKComplete)
           {
              memset(err_buf,0,sizeof(err_buf));
              strcpy(err_buf,"�ۤ��ǲ����~:call ao_gl_voucher() return ");
              strcpy(tmp_str,itoa(rtncode));    
              strcat(err_buf,tmp_str);
              goto optP_err1;
           }

           rtncode=ao_upd_cancel(DBname,ch_dwritten,"CA2");
           printf("\n====AFTER ao_upd_cancel(): rtncode[%d]\n",rtncode);
           if (rtncode != api_OKComplete)
           {
               memset(err_buf,0,sizeof(err_buf));
               strcpy(err_buf,"�󥿫O����ɩΦ����ɵ��P����~:call ao_upd_cancel() return ");
               strcpy(tmp_str,itoa(rtncode));
               strcat(err_buf,tmp_str);
               goto optP_err1;
           }

        }

        /**** STEP P.2--(13) *****************************************/
        printf("*********** into P.2--(13) update last_daily_close\n");

        for (k=0; k<yr_cnt; k++)
        {
            
            if (ivoucher[0] != ' ' && ivoucher[0] != '\0')
            {
                memset(err_buf,0,sizeof(err_buf));
                strcpy(err_buf,"update last_daily_close:");
                strcat(err_buf,"CA2");
                strcat(err_buf,",");
                strcat(err_buf,Year[k].yr);
                
                $UPDATE last_daily_close
                SET dlast_closing=$edrdate,
                ivoucher=$ivoucher,
                icreator=$creator,
                dcreate=$Today
                WHERE ibill_type='CA2' 
                AND iyear=$Year[k].yr;
                
                if (sqlca.sqlerrd[2]==0)
                {
                    $INSERT INTO last_daily_close
                       (iyear,ibill_type,dlast_closing,ivoucher,
                        icreator,dcreate)
                    VALUES 
                       ($Year[k].yr,"CA2",$edrdate,$ivoucher,
                        $creator,$Today);
                }
            }  
        }

        /**** STEP P.2--(14) *****************************************/
        printf("*********** into P.2--(14) update daily_closing_ctl\n");

        /* �ζ��O�N�����X car9302122 */
        printf("Before ca_edr_to_yl[%s][%s]\n",DBname,inf_dclose);
        rtncode = ca_edr_to_yl(DBname,inf_dclose);
        printf("====AFTER ca_edr_to_yl(): rtncode[%ld]\n",rtncode);
        if (rtncode!=M_CM_OK)
        {
           strcpy(err_buf,"ca_edr_to_yl��X��Ʀ��~");
           if (rtncode<0) goto optP_err;
           else goto optP_err1;
        }
        /* �H�Υd����P�q�� car9509124 */
        printf("Before ca_edr_mail[%s][%s]\n",DBname,inf_dclose);
        rtncode = ca_edr_mail(DBname,inf_dclose);
        if (rtncode!=M_CM_OK)
        {
           strcpy(err_buf,"ca_edr_mail�B�z��Ʀ��~");
           if (rtncode<0) goto optP_err;
           else goto optP_err1;
        }

        if (strncmp(DBname,"00",2) == 0)
        {
           $UPDATE ply_next_year
               SET dclose = $Today
             WHERE dclose is null; 
        }
    }


edr_no_record:

    $COMMIT WORK;
    FreeEdrList(EdrFirst,EdrCurr);      /* free all allocated memory */

    printf("------> finish \n");
    $SET LOCK MODE TO NOT WAIT;
    return M_CM_OK;

optP_err:
    printf("------> optP_err: \n");
    rc = cm_show_sql_err("ca5082", "");
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    $SET LOCK MODE TO NOT WAIT;
    return rc;

optP_err1:
    printf("------> optP_err1: \n");
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    $SET LOCK MODE TO NOT WAIT;
    return rtncode;

temp_err: 
   printf("temp    error \n");
}

/*****************************************************************/
/*****************************************************************/
/*****************************************************************/
/*****************************************************************/
/*****************************************************************/
/*****************************************************************/

int CheckSerialEndorse(ptype2,xyear2,delistF,delistC,delistL,maxp2)
$char *ptype2, *xyear2;
struct EDR_LIST **delistF, **delistC, **delistL;
$char *maxp2;
{
    $char  stmt[2048];
    char   num[7], lostedr[ENDORSE_NUM];
    int    i, lnum, snum;
    $char  matchyear[10];

    $char  tmp_ipolicy[POLICY_NUM_1],tmp_treaty[2];
    $char  tmp_irelative_ply[POLICY_NUM_1];
    $char  tmp_tagnum[CA_TAG_NUM],tmp_body[CA_BODY_NUM],tmp_engine[CA_ENGINE_NUM], tmp_itag_last[CA_TAG_NUM], tmp_itag_next[CA_TAG_NUM];
    $char  itag_last[CA_TAG_NUM], itag_next[CA_TAG_NUM], icreate[11];
    $char  tmp_assuredi[13],tmp_assuredn[121],tmp_assureda[65],tmp_apayment[91];
    $char  tmp_iassured_ext[3], tmp_ibig_sales[EMPLOYEE_ID];
    $char  tmp_icar_type[3],tmp_ibrand[9];
    $char  tmp_icard[CARD_NUM],tmp_fcard_class[2],tmp_iofficer[EMPLOYEE_ID];
    $char  tmp_ibig_office[10],tmp_ibroker[BROKER], tmp_fedr_class[2],tmp_fprint[2], tmp_ibroker_top[BROKER];
    $char  sibroker[BROKER], sileader[LEADER];
    $long  tmp_dendorse;
    $long  tmp_dedr_begin, tmp_dedr_end, tmp_dply_begin,tmp_dply_end;
    $long  tmp_qply_period;
    $char  tmp_fpay[2], tmp_ipay[POLICY_NUM_1];
    $char  tmp_ffac[3],tmp_fdiscount[2];
    $char  tmp_ibig_comp[2];
    $char  tmp_irecover_num[ENDORSE_NUM], tmp_iresource[2], tmp_iedr_area[11];
    $char  tmp_iedr_cashier[EMPLOYEE_ID];
    $double tmp_mcompensate;
    $char  tmp_assuredi_ext[3], tmp_icorps[CORP_ID], tmp_icomp_in[BRANCH_ID];
    $char  tmp_ibranch_in[BRANCH_ID], tmp_iquota[CA_SA_QUOTA];
    $char  tmp_ileader[LEADER];
    $long  tmp_medr_agent, tmp_medr_commi, tmp_medr_disc, tmp_ply_mcommi;
    $long  tmp_medr_prem;
    $char  tmp_icar_flag[2];
    $int   tmp_check_910401;
    $char  tmp_iedr_type[3];
    $char  tmp_payresult[4];
    $int   tmp_qcount, rc;
    $char  tmp_nequipment[31];
    $char  tmp_ibenef[11], tmp_zip[CA_ZIP], tmp_assuredf[2], tmp_dcreate[31];
    $char  tmp_iapplicant[IASSURED],tmp_napplicant[101], tmp_iedr_return[2], tmp_icreate[11];
    /* bis9901141 �s�W�q���M�θ�� */
    $char  tmp_iroute[21];      
    $char  iofficer_prmt[11],iedr_type_route[3];
    char   chk_iofficer[11]; 
    $int   tmp_cnt = 0;
    $long  iCountTagLast, iCountTagNext, sqlcode1, sqlcode2, iCount;
    $char  tmp_itype[2], tmp_icard_main[21], sWhere[256];
    $char  iabn_type[2], iins_type[7];
    $char  tmp_dtedr_begin[17],tmp_dtedr_end[17],tmp_dtply_begin[17],tmp_dtply_end[17]; /* 1061108001_SC6_�t�X�s�еo�i���ߨt�λݨD���Ѭ����t�Υ\�� yyyy-mm-dd HH:MM */    
    $char  tmp_iroute_accept[21],tmp_iscan_no[26]; /* 1101018008_SC2 �q�lñ�ݱ��y�s������X�W��25�X */
    $char  tmp_iquote[21]; /* 1110607001_SC1 �ظmE�O�����t�� */

    /* 1000311003 �q��2 */
    $char  tmp_icomm_obj[11], insure_type[2], opt[2];
    struct EDR_LIST *elistF=*delistF;
    struct EDR_LIST *elistL=*delistL;
    struct EDR_LIST *elistC=*delistC;

    $WHENEVER SQLERROR GOTO chke_err;

    sprintf(matchyear,"%2s%s*", xyear2, ptype2);

    stmt[0] = '\0';
    strcpy( insure_type, "C");
    sprintf(stmt,"SELECT UNIQUE iedr_type   \
                    FROM edr_ins_type       \
                   WHERE iendorse = ? ");
    $PREPARE iedr_type_id FROM $stmt;

    strcpy( sWhere, " ");
    if( fclose_type[0] == 'B')  
    {          
        if (fIFRS17=='Y')  /* �u��@�t�@�������C���i��鵲 */
        {        
            strcpy(sWhere," AND a.fedr_class = 'A' AND a.iendorse_dere <> '' ");         
        }        
    }    
    else
    {
        if (fIFRS17=='Y')  /* �u��@�t�@�������C���i��鵲 */
        {           
            sprintf(sWhere," AND a.ipolicy = '%s' AND a.fedr_class = 'A' AND a.iendorse_dere <> '' ", v_ipolicy);         
        }
        else
        {
            sprintf( sWhere, " AND a.iendorse = '%s' AND a.ipolicy = '%s' ", v_iendorse, v_ipolicy);
        }
    }    

    /*1091021005_SC2�s�W�A�Ȥ��ߩ�����*/
    /* �[�W fsign_status_edr >=30 �z����� */
    sprintf(stmt,"SELECT %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s FROM %s WHERE %s %s %s %s %s %s ORDER BY %s",
                 "a.iendorse, a.icard, a.fcard_class,",
                 "a.iofficer, a.ibroker, nvl(a.ibig_office,' ') ,",
                 "a.fedr_class, a.fprint, a.ipolicy, a.itreaty,",
                 "a.dedr_begin, a.dedr_end,",
                 "a.ibrand, a.icar_type, a.fpay, a.ipay, a.irecover_num,",
                 "a.iresource, a.iedr_area, a.iedr_cashier, a.dendorse,",
                 "a.ffac, a.medr_compensate, a.fdiscount,",
                 "a.ibig_comp, a.icorps, a.icomp_in, a.ibranch_in, a.iquota, a.ileader,a.qcount,",
                 "(a.medrdmg_prem  + a.medrlia_prem),",
                 "(a.medrdmg_agent + a.medrlia_agent),",
                 "(a.medrdmg_commi + a.medrlia_commi),",
                 "(a.medrdmg_disc  + a.medrlia_disc),",
                 "nvl(a.ibig_sales,' '), a.irelative_ply, a.icar_flag,",
                 "Case ",
                 "   WHEN b.dpolicy >= '04/01/2002' ",
                 "       then 0 ",
                 "   ELSE ",
                 "       1 ",
                 "End check_910401, a.iedr_return, a.iofficer_prmt, a.icomm_obj, a.dcreate, a.icard_main, a.iabn_type, a.dtedr_begin, a.dtedr_end,a.iscan_no,a.iquote ",
                 "edr_relation a , ori_ply_relation b ",
                 "a.dendorse = ?",
                 " AND substr(iendorse,4,17) MATCHES ? ",
                 " AND dedr_close IS NULL ",
                 " AND a.ipolicy = b.ipolicy ",
                 " AND a.fsign_status_edr >=30 ",
                 sWhere,
                 " a.dcreate");

    $PREPARE CA508_2_TMP FROM $stmt;
    $DECLARE CA508_2 CURSOR FOR CA508_2_TMP;
    $OPEN    CA508_2 USING $edrdate , $matchyear;
    printf("[%s]\n",stmt);
    while (1)
    {
        $FETCH CA508_2 INTO $maxp2, $tmp_icard, $tmp_fcard_class,
                            $tmp_iofficer, $tmp_ibroker, $tmp_ibig_office,
                            $tmp_fedr_class, $tmp_fprint, $tmp_ipolicy, $tmp_treaty,
                            $tmp_dedr_begin,$tmp_dedr_end,
                            $tmp_ibrand, $tmp_icar_type, $tmp_fpay, $tmp_ipay, $tmp_irecover_num,
                            $tmp_iresource, $tmp_iedr_area, $tmp_iedr_cashier, $tmp_dendorse,
                            $tmp_ffac, $tmp_mcompensate, $tmp_fdiscount,
                            $tmp_ibig_comp, $tmp_icorps, $tmp_icomp_in, $tmp_ibranch_in, $tmp_iquota, $tmp_ileader, $tmp_qcount,
                            $tmp_medr_prem,
                            $tmp_medr_agent,
                            $tmp_medr_commi,
                            $tmp_medr_disc,
                            $tmp_ibig_sales,
                            $tmp_irelative_ply,
                            $tmp_icar_flag,
                            $tmp_check_910401, $tmp_iedr_return, $iofficer_prmt, $tmp_icomm_obj, $tmp_dcreate, $tmp_icard_main,
                            $iabn_type,$tmp_dtedr_begin,$tmp_dtedr_end,$tmp_iscan_no,$tmp_iquote;
        if (SQLCODE==SQLNOTFOUND) break;

        $SELECT dply_begin, dply_end, qply_period,
                iassured, iassured_ext,
                nassured, aassured,
                nvl(itag,' '), nvl(ibody,' '), nvl(iengine,' '), iassured_ext, payresult,
                nequipment, nvl(ibenef,' '), nvl(aassured_zip,' '), fassured,
                iapplicant, napplicant, iroute, apayment,dtply_begin,dtply_end,iroute_accept
           INTO $tmp_dply_begin,$tmp_dply_end,$tmp_qply_period,
                $tmp_assuredi, $tmp_assuredi_ext,
                $tmp_assuredn, $tmp_assureda,
                $tmp_tagnum, $tmp_body, $tmp_engine, $tmp_iassured_ext, $tmp_payresult,
                $tmp_nequipment, $tmp_ibenef, $tmp_zip, $tmp_assuredf,
                $tmp_iapplicant, $tmp_napplicant, $tmp_iroute, $tmp_apayment,$tmp_dtply_begin,$tmp_dtply_end,$tmp_iroute_accept
           FROM endorsement
          WHERE iendorse=$maxp2;
        if (SQLCODE==SQLNOTFOUND)
        {
            printf("111:iendorse[%s],[%d]\n", maxp2, M_CA_NENDORSE);
            $CLOSE CA508_2;
            return M_CA_NENDORSE;
        }

        if (tmp_fedr_class[0] == 'A')
        {
            $EXECUTE iedr_type_id
                INTO $tmp_iedr_type
               USING $maxp2;
             if (SQLCODE==SQLNOTFOUND)
             {
                 printf("222:iendorse[%s],[%d]\n", maxp2, M_CA_NENDORSE);
                 return M_CA_NENDORSE;
             }
        }
        else
        {
             strcpy(tmp_iedr_type,"00");
        }

        if (fIFRS17!='Y')
        {
            /* 1000311003 �q��2 */
            /* �~�Z���O�_���� */        
            strcpy( opt, "2");
            rc = cm_chk_policy( opt, tmp_iofficer, tmp_ileader, tmp_iquota, tmp_icomm_obj, insure_type, tmp_iroute, "");
            if( rc != M_CM_OK)
            {
                strcpy( v_sMsg, cm_get_errmsg( rc));
                sprintf( sErrMsg, "��渹[%s]���鵲, �]���G%s", maxp2, v_sMsg);
                WRITELOG( sfp, sErrMsg);
                continue;
            }
        }

        if (fIFRS17!='Y')
        {
            /* bis9901141 �ˬd�q���N���O�_�s�b��q���ɤ� */
            strcpy(tmp_iroute,trim(tmp_iroute));
            if (tmp_iroute[0] == ' ' || tmp_iroute[0] == '\0')
            {
                /* �q�����ťթάONULL�N����鵲 */
                sprintf( sErrMsg, "��渹[%s]���鵲, �]���q���N�����ťթ�NULL", maxp2);
                WRITELOG( sfp, sErrMsg);
                continue;
            } 
            else
            {
                /* �ˬd�q���N���O�_�s�b��q����(cm_route) */
                /* W*���g��N���ݭn�Φ^�k�᪺�h�P�_�q�� */
                if( tmp_iofficer[0] == 'W')         
                    strcpy(chk_iofficer,trim(iofficer_prmt));
                else
                    strcpy(chk_iofficer,trim(tmp_iofficer));

            /* �ˬd�q���N���O�_�s�b��q���ɤ� */
                $SELECT count(*) INTO $tmp_cnt FROM cm_route
                WHERE iroute = $tmp_iroute;
            if (tmp_cnt == 0)
                {
                    sprintf( sErrMsg, "��渹[%s]���鵲, �]��cmn121�q�����(�D/����)���s�b�Τw����", maxp2);
                    WRITELOG( sfp, sErrMsg);
                    continue;   
                }   
                        
                /*rc = cm_check_route_sales("0",chk_iofficer,tmp_iroute,"C","","","","",v_sMsg);        	  
                if (rc != TRUE)
            {                  
                    sprintf( sErrMsg, "��渹[%s]���鵲, �]��cmn121�q�����(�D/����)���s�b�Τw����", maxp2);
                WRITELOG( sfp, sErrMsg);
                continue;                  
            }*/                    	  
            }
            /* end of bis9901141 */
        }
       
        printf("fedr_class[%s]\n", tmp_fedr_class);

        if (tmp_fedr_class[0] == '7') /* ���P��� */
        {
            printf("iendorse[%s]\n", maxp2);
            $SELECT itag_last, itag_next, icreate, itype
               INTO $tmp_itag_last, $tmp_itag_next, $tmp_icreate, $tmp_itype
               FROM ca_change_tag_ori
              WHERE iendorse=$maxp2 AND fstatus = 'Y';

            printf("itype[%s]\n", tmp_itype);
            if( tmp_itype[0] == '9')
            {
            printf("sqlcode[%d]\n", SQLCODE);

            $SELECT itag_next 
               INTO $itag_next
               FROM ca_change_tag
              WHERE itag_last = $tmp_itag_last;
            sqlcode1 = SQLCODE;
            printf("sqlcode1[%d]\n", sqlcode1);
            if( SQLCODE == 0 && strcmp( tmp_itag_next, itag_next) != 0)
            {
                sprintf( sErrMsg, "��渹[%s]���鵲:�]���W������[%s]�w����������������[%s],�P������檺��������[%s]���@�P",
                         maxp2, tmp_itag_next, itag_next, tmp_itag_next);
                WRITELOG( sfp, sErrMsg);
                continue;
            }
            $SELECT itag_last 
               INTO $itag_last
               FROM ca_change_tag
              WHERE itag_next = $tmp_itag_next;
            sqlcode2 = SQLCODE;
            printf("sqlcode2[%d]\n", sqlcode2);
            if( SQLCODE == 0 && strcmp( tmp_itag_last, itag_last) != 0)
            {
                sprintf( sErrMsg, "��渹[%s]���鵲:�]����������[%s]�w���������W������[%s],�P������檺�W������[%s]���@�P",
                         maxp2, tmp_itag_last, itag_last, tmp_itag_last);
                WRITELOG( sfp, sErrMsg);
                continue;
            }
            if( sqlcode1 == SQLNOTFOUND && sqlcode2 == SQLNOTFOUND)
            {
                $INSERT INTO ca_change_tag (itag_last, itag_next, icreate)
                                    VALUES ( $tmp_itag_last, $tmp_itag_next, $tmp_icreate);
                printf("SQLCODE[%d]\n", SQLCODE);
            }
            }
        }

        /* 1000311003 �q��2 */
        strcpy(tmp_ibroker_top," ");
        rc = cm_get_broker_top( tmp_icomm_obj, tmp_ibroker_top);
        if( rc != M_CM_OK)
        {
            strcpy( v_sMsg, cm_get_errmsg( rc));
            sprintf( sErrMsg, "��渹[%s]���鵲:%s", maxp2, v_sMsg);
            WRITELOG( sfp, sErrMsg);
            continue;
        }

        /*
        rc = chk_edr_dmg( tmp_ipolicy, maxp2, v_sMsg);
        printf("rc[%d]\n", rc);
        printf("M_CA_01_ERROR[%d]\n", M_CA_01_ERROR);
        if( rc != M_CM_OK)
        {
            strcpy( v_sMsg, cm_get_errmsg( rc));
            if( rc == M_CA_01_ERROR)
                sprintf( sErrMsg, "��渹[%s]���鵲:%s", maxp2, "2015/8/15~11/14�������i�i�樮���I�s�ץ�ӱ��P���");
            else
                sprintf( sErrMsg, "��渹[%s]���鵲:%s", maxp2, v_sMsg);

            WRITELOG( sfp, sErrMsg);
            continue;
        }
        

        $select count(*)
           into $iCount
           from edr_relation a, edr_ins_type b
          where a.iendorse = b.iendorse
            and a.iendorse = $maxp2
            and b.iedr_type = '05'
            and ((drate_ym::integer<=87 and today>'01/08/2018') or (drate_ym::integer=88 and today>'12/31/2017'))
            and iabn_type not in ('S','Y');

        if( iCount != 0)
        {
            sprintf(sErrMsg, "���[%s]�O�v��87�A���I��20180108,�O�v88�A���I���20171231", maxp2);
            WRITELOG( sfp, sErrMsg);
            continue;
        }
        */

        if( tmp_fcard_class[0] == '2' && iabn_type[0] != 'S' && iabn_type[0] != 'Y')
        {
            $DECLARE a_curs CURSOR FOR
              select iins_type
                from edr_ins_type
               where iendorse = $maxp2
                 and iedr_type in ('05','04')
                 and medrdmg_cover > 0;

            $open a_curs;
            for(;;)
            {
                $FETCH a_curs INTO $iins_type;
                if (SQLCODE==SQLNOTFOUND) break;
                rc = chk_insurance_expire( iins_type, v_sMsg);
                if( rc != M_CM_OK)
                {
                    sprintf( sErrMsg, "��渹[%s]���鵲:%s", maxp2, v_sMsg);
                    WRITELOG( sfp, sErrMsg);
                    continue;
		        }
	        }
        }

        *delistC=(struct EDR_LIST *)malloc(sizeof(struct EDR_LIST));
        if (*delistC==NULL)
        {
            printf("malloc fail in struct EDR_LIST allocation!\n");
            memset(err_buf,0,sizeof(err_buf));
            strcpy(err_buf,"malloc fail in struct EDR_LIST allocation");
            $CLOSE CA508_2;
            return M_CM_NOT_MALLOC;
        }
        /*** use a link list ***/
        if (*delistF==NULL) {    /* if it's first element?! */
            *delistF=*delistL=*delistC;
        } else {
            (*delistL)->next=*delistC;
            *delistL = *delistC;
        }
        elistC = *delistC;
        if (risnull(SQLCHAR, tmp_ibroker) == 1) strcpy(tmp_ibroker, " ");
        strcpy(elistC->iendorse         ,maxp2);
        strcpy(elistC->assuredn         ,tmp_assuredn);
        strcpy(elistC->assureda         ,tmp_assureda);
        strcpy(elistC->assuredi         ,tmp_assuredi);
        strcpy(elistC->car_type         ,tmp_icar_type);
        strcpy(elistC->brand            ,tmp_ibrand);
        strcpy(elistC->tagnum           ,tmp_tagnum);
        strcpy(elistC->body             ,tmp_body);
        strcpy(elistC->engine           ,tmp_engine);
        strcpy(elistC->treaty           ,tmp_treaty);
        strcpy(elistC->icard            ,tmp_icard);
        strcpy(elistC->fcard_class      ,tmp_fcard_class);
        strcpy(elistC->iofficer         ,tmp_iofficer);
        strcpy(elistC->ibroker          ,tmp_ibroker);
        strcpy(elistC->ibig_office      ,tmp_ibig_office);
        strcpy(elistC->iedr_cashier     ,tmp_iedr_cashier);
        strcpy(elistC->fedr_class       ,tmp_fedr_class);
        strcpy(elistC->ipolicy          ,tmp_ipolicy);
        strcpy(elistC->irelative_ply    ,tmp_irelative_ply);
        strcpy(elistC->fpay             ,tmp_fpay);
        strcpy(elistC->ipay             ,tmp_ipay);
        strcpy(elistC->irecover_num     ,tmp_irecover_num);
        strcpy(elistC->iresource        ,tmp_iresource);
        strcpy(elistC->iedr_area        ,tmp_iedr_area);
        strcpy(elistC->ffac             ,tmp_ffac);
        strcpy(elistC->fdiscount        ,tmp_fdiscount);
        strcpy(elistC->ibig_comp        ,tmp_ibig_comp);
        strcpy(elistC->icorps           ,tmp_icorps);
        strcpy(elistC->icomp_in         ,tmp_icomp_in);
        strcpy(elistC->ibranch_in       ,tmp_ibranch_in);
        strcpy(elistC->iquota           ,tmp_iquota);
        strcpy(elistC->ileader          ,tmp_ileader);
        strcpy(elistC->assuredi_ext     ,tmp_assuredi_ext);
        strcpy(elistC->ibig_sales       ,tmp_ibig_sales);
        strcpy(elistC->icar_flag        ,tmp_icar_flag);
        strcpy(elistC->iedr_type        ,tmp_iedr_type);
        strcpy(elistC->payresult        ,tmp_payresult);
        strcpy(elistC->nequipment       ,tmp_nequipment);
        strcpy(elistC->ibenef           ,tmp_ibenef);
        strcpy(elistC->zip              ,tmp_zip);
        strcpy(elistC->assuredf         ,tmp_assuredf);
        strcpy(elistC->iapplicant       ,tmp_iapplicant);
        strcpy(elistC->napplicant       ,tmp_napplicant);
        strcpy(elistC->iedr_return      ,tmp_iedr_return);
        strcpy(elistC->iroute           ,tmp_iroute);
        strcpy(elistC->icomm_obj        ,tmp_icomm_obj);
        strcpy(elistC->ibroker_top      ,tmp_ibroker_top);
        strcpy(elistC->dcreate          ,tmp_dcreate);
        strcpy(elistC->icard_main       ,tmp_icard_main);
        strcpy(elistC->apayment         ,tmp_apayment);
        strcpy(elistC->dtedr_begin      ,tmp_dtedr_begin); /* 1061108001_SC6_�t�X�s�еo�i���ߨt�λݨD���Ѭ����t�Υ\�� yyyy-mm-dd HH:MM */    
        strcpy(elistC->dtedr_end        ,tmp_dtedr_end);
        strcpy(elistC->dtply_begin      ,tmp_dtply_begin);
        strcpy(elistC->dtply_end        ,tmp_dtply_end);
        strcpy(elistC->iroute_accept    ,tmp_iroute_accept);
        strcpy(elistC->iscan_no         ,tmp_iscan_no);
        strcpy(elistC->iquote           ,tmp_iquote);
                        
        elistC->dendorse        =tmp_dendorse;
        elistC->ply_begin       =tmp_dply_begin;
        elistC->ply_end         =tmp_dply_end;
        elistC->qply_period     =tmp_qply_period;

        elistC->edr_begin       =tmp_dedr_begin;
        elistC->edr_end         =tmp_dedr_end;

        elistC->mcompensate     =tmp_mcompensate;

        elistC->edr_mprem       =tmp_medr_prem;
        elistC->edr_magent      =tmp_medr_agent;
        elistC->edr_mcommi      =tmp_medr_commi;
        elistC->edr_mdisc       =tmp_medr_disc;
        elistC->check_910401    =tmp_check_910401;
        elistC->qcount          =tmp_qcount;
             
        elistC->next=NULL;
    }
    $CLOSE CA508_2;

    return SUCCESS;

chke_err:
    printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    memset(err_buf,0,sizeof(err_buf));
    strcpy(err_buf,maxp2);
    return SQLCODE;
}

/*****************************************************************/
FreeEdrList(elistF,elistC)
struct EDR_LIST *elistF, *elistC;
{
    while (elistF != NULL) {
        elistC=elistF;
        elistF=elistC->next;
        free(elistC);
    }
}

static int DiffMonth(d1,d2)    /* input data should be date format */
long d1, d2;
{
    short mdy1[3], mdy2[3];
    int datediff=0;

    rjulmdy(d1,mdy1);
    rjulmdy(d2,mdy2);
    datediff=(mdy1[2]*12+mdy1[0])-(mdy2[2]*12+mdy2[0]);
    if (datediff<0) datediff=0;
    return datediff;
}
long check_dedr_close( ipolicy, iendorse, dcreate)
$char *ipolicy, *iendorse, *dcreate;
{
$long iCount;

    $WHENEVER SQLERROR GOTO ca_up_err;
     printf("check_dedr_close[%s],[%s],[%s]\n", ipolicy, iendorse, dcreate);
     $SELECT COUNT(*)
        INTO $iCount
        FROM edr_relation
       WHERE ipolicy = $ipolicy
         AND iendorse not like '%CVP%'
         AND dcreate <= $dcreate
         AND iendorse != $iendorse
         AND dedr_close IS NULL;
     if( iCount != 0) return -1;
    return M_CM_OK;

ca_up_err:
    printf("check_dedr_close sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/*****************************************************************/
