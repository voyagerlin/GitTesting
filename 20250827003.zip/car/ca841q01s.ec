/************************************************/
/*   PROGRAM : ca841q01s.ec                     */
/*   MODIFY  : cyrus                            */
/*   DATE    : 104.05.05                        */
/*   NOTE    : ���X�Ixx�I�إ��X�Iyy�I�ة��Ӫ�   */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
$include datetime.h;
#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"

$char DBName[05], iForm_Tp[03], outputf[N_FILE+1];
char  BodyFile[N_FILE+1];
char  TitleFile[N_FILE+1];
char  userid[11];

char  msgbuf[100];
$int  ItemRow, TotColumn;
$int  StartRow, TitleRow;
$int  PgLine, Width;
$int  PERIOD;

static int max_count;

DBinfo *list;
int count_db;

$char sIbranch[BRANCH_ID], sIofficer[EMPLOYEE_ID];
$char sNname[EMPLOYEE_NAME];
$char sIclaim[CLAIM_NUM], sFcard_class[2], sDclaim[YYYYMMDD];
$char sYearMonth[7];
$char sIadjuster[EMPLOYEE_ID], sFclose[2], sIins_type[INSURANCE_TYPE];
$char sDclose[13], victim[11], flast[2];
$char sDgroup[11];
$char dgroup[11];
$long ldgroup;
$char sNgroup[5], sNadjuster[11];
$char sIupbranch[3], sNupgroup[11];
$char sFins_grp[2];
$char sBgnDate_e[11], sEndDate_e[11], sBgnDate[11], sEndDate[11];
$long lBgnDate, lEndDate;
$long iQorder, qmonth, lMins_stl;
$char ivictim[11];
$long qdmg_claim, qdmg_close, qdmg_nopay;       /** ���l **/
$long qlia_claim, qlia_close, qlia_nopay;       /** �d�� **/
$long qburg_claim, qburg_close, qburg_nopay;    /** �W�[�ѵs�����Ѩ��l�������X **/
$long qcomp_claim, qcomp_close, qcomp_nopay;    /** �j�� **/
$long qwea_claim, qwea_close, qwea_nopay;       /** �]�� **/
$long mins_stl;
$date lDclaim;
$char iclaim[21];
$int  iclose_type;
$int  icnt;
$char stmt[2000];
$char stmt3[9500];
$char sIinsType[INSURANCE_TYPE];
$char sIinsTypeB[INSURANCE_TYPE];

$char iins_item[INSURANCE_TYPE];

int qlia, qburg, qdmg, qwea;
$int iTmp;
$int iMaxCnt;
$int id1;
$int iMonthDiff;

$char m_bgn[11], m_end[11], r_bgn[11], r_end[11];
$char server[3];
$char iofficer[11];

long car841_build();
void car841_title();
long car841_body();
long car841_print();
void car841_print2();
int DiffMonth();

/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
   int rc;
   
   batchinit();
   strcpy(DBName    , isNULLstr(argv[1]));
   strcpy(userid    , isNULLstr(argv[2]));
   strcpy(sBgnDate  , isNULLstr(argv[3]));
   strcpy(sEndDate  , isNULLstr(argv[4]));
   strcpy(sIinsType , isNULLstr(argv[5]));   
   strcpy(sIinsTypeB, isNULLstr(argv[6]));  

   strcpy(outputf   , isNULLstr(argv[7]));

   strcpy(sBgnDate_e, cm_to_infdate(sBgnDate));
   strcpy(sEndDate_e, cm_to_infdate(sEndDate));

   rstrdate(sBgnDate_e, &lBgnDate);
   rstrdate(sEndDate_e, &lEndDate);

   printf("sBgnDate_e[%s] sEndDate_e[%s]\n", sBgnDate_e, sEndDate_e);
 
   rc = car841_get_db();
   if (rc != M_CM_OK)
      return rc;
   
   rc = car841_build();
   if (rc != M_CM_OK)
       return rc;

   return M_CM_OK;
   
errexit:
   printf("main :SQLCODE[%d], errstr:[%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/

long car841_build()
{
   $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];
   int    rc;
   
   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT;
   
   if (db_select(DBName) == False)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   rc = car841_body();
   if (rc != M_CM_OK)
       return rc;
           
   rc = car841_print();
   if (rc != M_CM_OK)
       return rc;
 
   return M_CM_OK;

errexit:
   EWRITE(userid, rc, sqlca.sqlerrm);
   return SQLCODE;  
}

long car841_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   if ((list = get_db_list(&count_db, DBName)) == (char*)0)
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

long car841_body()
{
    int i;
    long rc;
    $char sStmt[9500], sStmt1[9500], sStmt2[9500], sStmt3[9500], sStmt4[9500];
    $char stmt[9500];
    $char tmp[4096], tmp1[4096], tmp2[4096];
    $char stepcar[4096];

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;
    
    if (strncmp(sIinsTypeB,"119",3) == 0 ||
        strncmp(sIinsTypeB,"121",3) == 0 ||
        strncmp(sIinsTypeB,"123",3) == 0)
    {
        $create temp table car841tbl
        (
            iclmupcomp       char(2),
            iclaim           char(20),
            nclmquota        char(60),
            nadjuster        char(10),
            nmgr             char(10),
            dwritten         date,
            dinsend          date,
            daccident        date,
            dclaim           date,
            iplyupcomp       char(2),
            ipolicy          char(20),
            nassured         char(120),
            nins_type        char(100),
            mstl             integer,
            app              integer,
            mdamage_cover    integer,
            qlia             integer
        )with no log;
    }
    else
    {
        $create temp table car841tbl
        (
            iclmupcomp       char(2),
	        iclaim           char(20),
       	    nclmquota        char(60),
            nadjuster        char(10),
	        nmgr             char(10),
	        dwritten         date,
            dinsend          date,
	        daccident        date,
            dclaim           date,
	        iplyupcomp       char(2),
	        ipolicy          char(20),
            nassured         char(120),
	        nins_type        char(100),
	        mstl             integer,
            app              integer,
	        mdamage_cover    integer
        )with no log;
    }

    for (i = 0; i < count_db; i++)
    {
        strcpy(stepcar, " ");
        if (strncmp(sIinsTypeB, "119", 3) == 0 ||
            strncmp(sIinsTypeB, "121", 3) == 0 ||
            strncmp(sIinsTypeB, "123", 3) == 0)
        {
            sprintf_s(stepcar, 4096,
             "     ,(select sum(y.qlia)                                 \
                       from %s:settlement x, %s:stl_ins_type y          \
                      where x.iclaim       = y.iclaim                   \
                        and x.fstl         = y.fstl                     \
                        and x.iclose_type  = y.iclose_type              \
                        and x.ipolicy      = a.ipolicy                  \
                        and y.iins_type[1,3] = '%s'                     \
                        and y.dclose is not null) as qlia  ", list[i].dbname, list[i].dbname, sIinsTypeB);
        }

        sprintf_s(stmt, 9500,
	   " insert into car841tbl     \
               select (select iupcomp from branch where ibranch = decode(a.iclaim[1,2],'0A','00','4A','40','7A','70',a.iclaim[1,2])) as iupcomp,        \
                      a.iclaim,        \
                      (select nchi_full from branch where ibranch = decode(a.iclaim[1,2],'0A','00','4A','40','7A','70',a.iclaim[1,2])) as nbranch,      \
                      (select nname from officer where iofficer = a.adjustment) as nname,    \
                      (select x.nname from personal:asempl w,officer x where a.adjustment = w.empl_no and w.administrator = x.iofficer) as nmgr,        \
                      (select dwritten from policy_new where ipolicy1 = a.ipolicy[1,13] and ipolicy2 = a.ipolicy[14,20]) as dwritten,      \
                      (select dins_end from policy_new where ipolicy1 = a.ipolicy[1,13] and ipolicy2 = a.ipolicy[14,20]) as dins_end,      \
                      date(a.daccident) as daccident,     \
                      a.dclaim,        \
                      (select iupcomp from sa_branch_type where ibranch = c.iquota) as iupcomp1,   \
                      a.ipolicy,       \
                      a.nassured,      \
                      (select trim(iins_type) || '.' || nins_type from insurance_type where iins_type = b.iins_type) as nins_type,     \
                      (select sum(decode(fstl,'2',mins_stl*(-1),mins_stl)) from %s:stl_ins_type where iclaim = b.iclaim and iins_type = b.iins_type) as mins_stl,    \
                      (select sum(mins_app) from %s:app_ins_type where iclaim = b.iclaim and iins_type = b.iins_type) as mins_app,    \
                      (select max(r.mdamage_cover) from %s:ply_ins_type_hist r where r.ipolicy = a.ipolicy                      \
	                                                                         and r.mdamage_cover > 0                        \
	                                                                         and r.fedr_status   < 80                       \
	                                                                         and r.dedr_begin    <= date(a.daccident)       \
			  					                                             and r.dedr_end      >= date(a.daccident)       \
								                                             and r.iins_type      = '%s') mm   %s           \
                 from ca_clm_process a, %s:app_ins_type b, %s:adjustment_ply c   \
                where a.iclaim  =  b.iclaim                  \
                  and a.iclaim  =  c.iclaim                  \
                  and date(a.daccident) between ? and ?      \
                  and b.iins_type in (select iins_type from insurance_type where iins_ply = ?)     \
                  and a.iclaim not in (select iclaim from %s:app_ins_type where iins_type in (select iins_type from insurance_type where iins_ply = ? ))       \
                  and a.ipolicy in (select ipolicy           \
                                      from %s:ply_ins_type_hist     \
                                     where mdamage_cover > 0        \
                                       and fedr_status   < 80       \
                                       and dedr_begin    <= date(a.daccident)       \
                                       and dedr_end      >= date(a.daccident)       \
                                       and iins_type      = ?)  ", list[i].dbname, list[i].dbname, list[i].dbname, sIinsTypeB, stepcar, list[i].dbname, list[i].dbname, list[i].dbname, list[i].dbname);

            printf("stmt[%s]\n", stmt);		
    
            $prepare ins_tbl from $stmt;
            $execute ins_tbl
               using $lBgnDate, $lEndDate, $sIinsType, $sIinsTypeB, $sIinsTypeB;
   }

  return M_CM_OK;
        
errexit:
   printf("car841_body ==> SQLCODE:[%ld][%s] \n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   printf("   end EWRITE \n");
   return SQLCODE;
}

long car841_print()
{
   $char stmt[4096], stmt1[1024], stmt2[1024];
   $long qorder;
   int i, x, j, k;
   $int COUNT;
   $char sfilename[200];
   $char stitle[1000];
   $char ssql[1000];
   $char dyearmonth_tmp[7];
   $char title_tmp[101];
   $char title_tmp0[101];
   $char title_tmp1[101];
   $char title_tmp2[101];
   $char filed[20][15];
   $char sqltmp[1024];
   $char filed_tmp[200];
   $char sErrmsg[100];
   $char stitletmp[512];
   $int  rc;
 
   $char sWhere1[1024];
   $char sWhere2[1024];
   $char sWhere3[1024];
   $char sWhere4[1024];

   $WHENEVER ERROR goto errexit;
   $SET LOCK MODE TO WAIT;

   sprintf_s(sfilename, 200, "���w��%s�I�ئ����w��%s�I�ة��Ӫ�", sIinsType, sIinsTypeB);
  
   printf("sfilename[%s]\n", sfilename);

   sprintf_s(stitletmp,512, "%s�I�ةӫO�O�B\t", sIinsTypeB);

   printf("stitletmp[%s]\n", stitletmp);

   strcpy(stitle, sfilename);
   printf("stitle[%s]\n", stitle);
   strcat(stitle, "\n\t");
   strcat(stitle, "�X�I����G");
   strcat(stitle, sBgnDate_e);
   strcat(stitle, " ~ ");
   strcat(stitle, sEndDate_e);
  strcat(stitle, "\n\t�߮��Ұ�\t�߮׸��X\t�߮׳��\t�z�ߩm�W\t���D��\t�X����\t�O�������\t�X�I���\t���z���\t�~�Z�Ұ�\t�O�渹�X\t�Q�O�I�H\t�D�I�ئW��\t�D�I�ؤw�M���B\t�D�I�ؤw�w�����B\t");
   strcat(stitle, stitletmp);
   if (strncmp(sIinsTypeB, "119", 3) == 0 ||
       strncmp(sIinsTypeB, "121", 3) == 0 ||
       strncmp(sIinsTypeB, "123", 3) == 0)
   {
       strcat(stitle,"�O�����w�ϥΥN�B���Υ�q���v�O�ѼƦX�p\t");
   }

   printf("stitle[%s]\n", stitle);

   sprintf_s(ssql, 1000,
    " select * from car841tbl ");

   printf("ssql[%s]\n", ssql);

   rc = unload_file(outputf, " ", sfilename, stitle, ssql);

   if (rc != SUCCESS)
   {
       if (rc == 3501)
       {
          sprintf_s(sErrmsg, 100, " ��J���^������䤣���� ", sfilename);
       }
       else
       {
          sprintf_s(sErrmsg, 100, " %s �ɮ׵L�k���� ", sfilename);
       }

       EWRITE(userid, rc, sErrmsg);
       exit(1);
   }

   return M_CM_OK;

errexit:
  printf("SQL=[%d], sqlca.sqlerrm[%s]\n", SQLCODE, sqlca.sqlerrm);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  exit(1);
    
}

int DiffMonth(d1, d2)    /* input data should be date format */
long d1, d2;
{
short mdy1[3], mdy2[3];
int datediff = 0;

    rjulmdy(d1, mdy1);
    rjulmdy(d2, mdy2);
    datediff = (mdy1[2] * 12 + mdy1[0]) - (mdy2[2] * 12 + mdy2[0]);
    if (datediff < 0) datediff = 0;
    return datediff;
}

