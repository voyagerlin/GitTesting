/**********************************************************************/
/*   program id   : ca634q01s.ec                                      */
/*   program name : �O��ú�O�ޱ�����                                  */
/*   date written : 2013/04/09 by 020091                              */
/*   files        :                                                   */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <decimal.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "globdata.h"

$char iquota_in[7];
$char opt[2];
$char dbgn[11];
$char dend[11];
$char option[2];
$char imgrcheck[2];
$char ftypecheck[2];
$char ftypeclass[2];

int   count_db;
char  outputf[21];
$char userid[11];
$char DBName[05];
$char msgbuf[128];

DBinfo *list;

char *get_car_full_db();
/*--------------------------------------------------------------------*/

main(argc, argv)
int argc;
char **argv;
{
    int rc;

    batchinit();
    strcpy(DBName,    isNULLstr(argv[1]));
    strcpy(userid,    isNULLstr(argv[2]));
    strcpy(iquota_in, isNULLstr(argv[3]));
    strcpy(opt,       isNULLstr(argv[4]));/*ñ���Τ鵲��*/
    strcpy(dbgn,      isNULLstr(argv[5]));
    strcpy(dend,      isNULLstr(argv[6]));
    strcpy(option,    isNULLstr(argv[7]));/*���O���A*/
    strcpy(imgrcheck, isNULLstr(argv[8]));/*���ӫO�N*/
    strcpy(ftypecheck,isNULLstr(argv[9]));/*�H�u�֭�d��*/
    strcpy(ftypeclass,isNULLstr(argv[10]));/*�H�u�֭����O*/
    strcpy(outputf,   isNULLstr(argv[11]));

    rc = car634_prepare_data();

    if (rc != M_CM_OK)
       return rc;


    /*build report - ����*/
    rc = car634_build();

    if (rc != M_CM_OK) {
       return rc;
    }

}
/*--------------------------------------------------------------------*/
long car634_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }

   if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
      if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
         return M_CM_NOT_DBLIST;
   }

   return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/
long car634_prepare_data()
{
   $char iupcomp[3],iquota[7],ileader[11],iofficer[11],iofficer_name[21];
   $char ipolicy1[21],ipolicy2[8],iendorse[21],iendorse1[21],iclose[11],nclose[21],ipre_rcv[21],iins_kind[2],ipre_end[21];
   $char nassured[81],itarget1[21],ntarget1[81];
   $char dins_bgn[11],dins_end[11],dwritten[11],dentry[20],nchi_abv[13];
   $char nbranch[40],fdelay[2];
   $char ftype_pol[3],ftype_sp[3],cftype_sp[21], imgr[2], sImgr_1[7],ftype[2];
   $long macct_prem;
   $long  detail,pass,receive;
   $char  dbgn_cond[11],dend_cond[11],dins_bgn_last[11],dwork[5];
   long dins_bgn_four_long,dentry_long;
   $char stmt[2048],stmt1[5120],stmp[5120],stmp2[500],stmt2[2048],stmt6[512],stmp4[512],stmp3[512];
   $char sys[20];
   $int diff,diff_dwork,h_count = 0,dwork_int=0;
   $char pay[10],dentry_data[11],dentry_sql[11];
   $char dwritten_bg[11],dwritten_ed[11],dwritten_ed2[11];
   $char dins_bgn_bg[11],dins_bgn_ed[11],dins_bgn_ed2[11];
   $char iroute[21],iroute_main[13],pay_type[2],dwn_dbgn[2];
   $char dupdate[22],iupdate[20],nupdate[21],fcommit[2],dpay[11],new_dwritten[2];
   $char sFullName[21];
   $char d_close[11];
   $char v_sMsg[1024];
   int rc,i=0;
   $char dins_bgn_last_100[11],dentry_sql_100[11],sys_100[11],dins_bgn_last_100_2[11];
   $long idins_bgn_last,identry_sql,isys,sLdeffect;
   $char after_date[11],before_date[11],before_date_1[11];
   
   strcpy(dbgn_cond,cm_to_infdate(dbgn));
   strcpy(dend_cond,cm_to_infdate(dend));

   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == FALSE)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return FAIL;
   }

   /* Create table car634_tmp1 */
   $create temp table car634_tmp1
	 (
      nchi_abv       char(13),
      nbranch        char(40),
      ileader        char(10),
      iofficer       char(10),
      iofficer_name  char(20),
      iroute_main    char(12),
      iroute         char(20),
      ipolicy1       char(20),
      dins_bgn       date,
      dins_end       date,
      ipre_rcv       char(20),
      ipre_end       char(20),
      dwritten       date,
      nassured       varchar(80),
      itarget1       char(20),
      ntarget1       varchar(80),
      macct_prem     decimal(10,0),
      payment        varchar(80),
      dentry      date,
      overdue        int ,
      ftype_pol      char(2),
      ftype_sp       char(20),
      dupdate         char(21),
      iupdate         char(20),
      nupdate         char(20),
      imgr           char(6),
      fdelay         char(1)
    ) with no log;

      strcpy(opt, trim(opt));
      if (strcmp(opt,"P")==0)
          strcpy( stmp, "b.dins_bgn");
      else
          strcpy( stmp, "b.dwritten");
      
      strcpy(imgrcheck, trim(imgrcheck));
      if(strncmp(imgrcheck,"0",1)==0)
      	strcpy( stmp2, "and (select imgr from officer where iofficer = d.iofficer )!='1'");
      else
      	strcpy( stmp2, " ");
      	
      printf("stmp2[%s] imgrcheck = %s\n\n", stmp2, imgrcheck);	
      
      if(strncmp(ftypecheck,"0",1)==0)
      	strcpy( stmp3, "and c.ftype_sp in ('01','10','20','AP','PA')");
      else
      {
        if(strncmp(ftypeclass,"1",1)==0)
          strcpy( stmp3, "and ftype_pol = 'SP' and c.ftype_sp = '10'");
        else if(strncmp(ftypeclass,"2",1)==0)
          strcpy( stmp3, "and ftype_pol = 'NA' and c.ftype_sp = 'AP'");
        else if(strncmp(ftypeclass,"3",1)==0)
          strcpy( stmp3, "and ftype_pol = 'SP' and c.ftype_sp = '01'");
        else
          strcpy( stmp3, "and ((ftype_pol = 'SP' and c.ftype_sp = '10') or (ftype_pol = 'NA' and c.ftype_sp = 'AP') or (ftype_pol = 'SP' and c.ftype_sp = '01'))");
      }
     
     /* optipn 1:�w��, 2:���� */
     strcpy(stmp4, " ");
          
     if(strncmp(option,"1",1)==0)
      	strcpy(stmp4, " and exists (select 'A' from ao_prercv_pass x where x.ipre_rcv = c.ipre_rcv and x.iins_kind = c.iins_kind and x.ipre_end = c.ipre_end)");
     if(strncmp(option,"2",1)==0)
      	strcpy(stmp4, " and not exists (select 'A' from ao_prercv_pass x where x.ipre_rcv = c.ipre_rcv and x.iins_kind = c.iins_kind and x.ipre_end = c.ipre_end) ");
     
     
      	 
    sprintf(stmt1,
    "select (select g.nchi_abv from branch g where a.iupcomp=g.ibranch ), "
    "       a.nbranch,(select nname from officer where iofficer = b.ileader), "
    "       b.iofficer,(select nname from officer where iofficer = b.iofficer),"
    "       b.ipolicy1, b.iendorsement, b.dins_bgn, b.dins_end, c.ipre_rcv, c.iins_kind, c.ipre_end, b.dwritten, "
    "       b.nassured, d.itarget1, d.ntarget1, b.macct_prem, "
    "       NVL((select e.dentry from ao_prercv_pass e "
    "             where c.ipre_rcv= e.ipre_rcv "
    "               and c.iins_kind= e.iins_kind "
    "               and c.ipre_end= e.ipre_end) ,''), b.ipolicy2 , c.ftype_pol , c.ftype_sp, "
    "       (select imgr from officer where iofficer = d.iofficer ) , "
    "       b.ichannel,(select iroute_main from cm_route where iroute = b.ichannel), "
    "       (select h.dupdate from ca_permit_after_log h where h.ipre_rcv=c.ipre_rcv and h.iins_kind=c.iins_kind and h.ipre_end=c.ipre_end),"
    "       (select h.iupdate from ca_permit_after_log h where h.ipre_rcv=c.ipre_rcv and h.iins_kind=c.iins_kind and h.ipre_end=c.ipre_end),"
    "       (select nname from officer ,ca_permit_after_log h where iofficer=h.iupdate and h.ipre_rcv=c.ipre_rcv and h.iins_kind=c.iins_kind and h.ipre_end=c.ipre_end),"
    "       c.fcommit,b.dpay,case when b.dwritten <= b.dins_bgn then '1' else '0' end ,"
    "       case when b.dwritten >= '01/12/2016' then '1' else '0' end"
    "  from sa_branch_type a,policy_main b,cm_pre_receive c,policy_new d,sa_insurance f"
    " where b.iquota matches '%s' "
    "   and %s between'%s'and '%s' "
    "   and b.ipolicy1= c.ipolicy1 "
    "   and b.ipolicy1= d.ipolicy1 "
    "   and b.ipolicy2= c.ipolicy2 "
    "   and b.ipolicy2= d.ipolicy2 "
    "   and b.iendorsement = c.iendorse "
    "   and a.ibranch= b.iquota "
    "   and b.ipolicy1[6,7]=f.iins_kind "
    "   and b.insure_type = f.insure_type "
    "   and b.insure_type = 'C' "
    "   and (f.iins_level = 'C1' or f.iins_level = 'C2') "
    "    %s" 
    "    %s %s ", iquota_in, stmp, dbgn_cond, dend_cond ,stmp2 ,stmp4, stmp3); 

      printf("stmt1[%s]\n\n", stmt1);
      $PREPARE pre1 FROM $stmt1;
      $DECLARE cur_pre1 CURSOR for pre1;
      $OPEN cur_pre1;

     	while(1)
      {	
         	$FETCH cur_pre1 INTO $nchi_abv,$nbranch,$ileader,$iofficer,
         	                     $iofficer_name, $ipolicy1, $iendorse, $dins_bgn, $dins_end,
         	                     $ipre_rcv, $iins_kind, $ipre_end, $dwritten, $nassured, $itarget1,
         	                     $ntarget1, $macct_prem, $dentry, $ipolicy2 , $ftype_pol ,
         	                     $ftype_sp, $imgr, $iroute, $iroute_main,
         	                     $dupdate,$iupdate,$nupdate,$fcommit,$dpay,$dwn_dbgn,$new_dwritten;

         	
printf("ipre_rcv[%s]\n",ipre_rcv);
printf("ipolicy1=[%s]ipolicy2=[%s]\n",ipolicy1,ipolicy2);
printf("ipre_end=[%s]\n",ipre_end);
printf("imgr[%s]\n",imgr);
                if(SQLCODE == SQLNOTFOUND) break;
	
		if(macct_prem <= 0)
		continue;

	

		$SELECT count(*), NVL((select count(*) from ao_prercv_detail x
                                  where x.ipre_rcv = a.ipre_rcv
                                    and x.iins_kind = a.iins_kind
                                    and x.ipre_end = a.ipre_end),0),
                  NVL((select count(*) from ao_prercv_pass x
                        where x.ipre_rcv = a.ipre_rcv
			                    and x.iins_kind = a.iins_kind
			                    and x.ipre_end = a.ipre_end),0)
		         INTO $receive, $detail, $pass
		         FROM cm_pre_receive a
		        WHERE a.fstatus<>90
		          AND a.ipre_rcv=$ipre_rcv
		          AND a.iins_kind=$iins_kind
		          AND a.ipre_end=$ipre_end
		          AND a.fcommit=$fcommit
		          group by 2,3;
		                   
	
/* 1060804:����P�_�w�����O*/

              /*���O���A*****�O���Ѽ�*/
              
	      if (receive=1&&detail>0&&pass>0)
	      {
         	/*diff=cm_cdays_between(dins_bgn_last,dentry_data);*/
	        strcpy(pay,"�w���O");
	        strcpy(pay_type,"1");
	      }
	      else if (receive=1&&detail>0&&pass==0)
	      {
	        /*diff=cm_cdays_between(dins_bgn_last,sys);*/
	        strcpy(pay,"���O������");
	        strcpy(pay_type,"2");
	      }
	      else if ((receive=1&&detail==0&&pass==0)||receive==0)
	      {
	        /*diff=cm_cdays_between(dins_bgn_last,sys);*/
	  	strcpy(pay,"�����O");
	  	strcpy(pay_type,"2");
	      }
	      printf("option=[%s]pay_type=[%s]\n",option,pay_type);

	      /*** ���O���A�P�_ ***/
	      if(strcmp(option,"1")==0 && strcmp(pay_type,"1")!= 0)
	      	continue;
	      if(strcmp(option,"2")==0 && strcmp(pay_type,"2")!= 0)
		continue;


/* 1060804:����P�_�w�����O*/	
	
	
		

              /*01 �j�� 10�H�u�֭� 20�O�g�N */
               if(strcmp(trim(ftype_sp),"20")==0)
               {
               	/* ñ���+�T�Q�@�Ӿ�� modify by larry 104.05.21 (1040507001_C1)*/
               	/*fwork =1 �O����*/
printf("ftype_sp=20\n");
printf("dwritten=[%s]\tdins_bgn=[%s]\n",dwritten,dins_bgn);

		if(strcmp(dwn_dbgn,"1")==0)
		{
printf("dwritten\n");
			$SELECT skip 29 first 1 dwork
               	           INTO $dins_bgn_last
               	           FROM cm_wrktbl
               	          WHERE dwork > $dwritten
               	        ORDER BY 1;

	 	     if(SQLCODE == SQLNOTFOUND) break;
		}		
		else
		{
printf("dins_bgn\n");
                 
			$SELECT skip 29 first 1 dwork
               	           INTO $dins_bgn_last
               	           FROM cm_wrktbl
               	          WHERE dwork > $dins_bgn
               	        ORDER BY 1;

	 	     if(SQLCODE == SQLNOTFOUND) break;
		}
		       
printf("dpay[%s] dentry[%s] \n",dpay,dentry);  

                       strcpy(dentry_data,cm_sysd_cdate(dentry)); 
                       strcpy(dentry_sql,cm_to_infdate(dentry_data));

                       printf("dentry_sql[%s]",dentry_sql);
                       strcpy(sys,cm_get_sysd());
	               strcpy(sys,cm_sysd_cdate(sys));
	               strcpy(sys,cm_to_infdate(sys));
		       
                       /*strcpy(dins_bgn_last,cm_from_infdate_100(dins_bgn_last));*/
               }
                else if(strcmp(trim(ftype_sp),"AP")==0)
		{
		/* �鵲��+6�Ӥu�@��  cm_wrktbl.fwork =1 �O���� */
		$SELECT tcode_remark
		INTO $dwork
		FROM cu_code_data
		WHERE itype = 'WK'
		AND icode = '2';

		if(SQLCODE == SQLNOTFOUND) break;
		
		strcpy(dwork,trim(dwork));
		dwork_int = atoi(dwork)+1;
	
	        /*1050112�_ñ�欰�s�W�h */
                /*if(strcmp(new_dwritten,"1")==0){	
		sprintf(stmt2,
		"SELECT skip %s first 1 dwork " 
		"FROM cm_wrktbl "
		"WHERE dwork > '%s' "
		"AND fwork = '0' "
		"ORDER BY 1 ",dwork,dwritten);
		}
		else{
		sprintf(stmt2,
		"SELECT skip 2 first 1 dwork " 
		"FROM cm_wrktbl "
		"WHERE dwork > '%s' "
		"AND fwork = '0' "
		"ORDER BY 1 ",dwritten);
	        }
	        
	        $PREPARE pre3 FROM $stmt2;
		$DECLARE cur_pre3 CURSOR for pre3;
		$OPEN cur_pre3;
		$FETCH cur_pre3 INTO $dins_bgn_last;  �O���Ѽư�Ǥ�*
		printf("stmt2[%s]\n", stmt2);
                
		if(SQLCODE == SQLNOTFOUND) break;
		*/
		/*
		strcpy(dwritten_bg,cm_from_infdate_100(dwritten));  
		if(strcmp(new_dwritten,"1")==0){
		cm_cdate_add_100(dwritten_bg, (1), dwritten_bg);
		rc = chk_working_date(dwritten_bg, dwork_int, &dwritten_ed, v_sMsg);
		}
		else{
		rc = chk_working_date(dwritten_bg, 2+1, &dwritten_ed, v_sMsg);
	        }	
	        
	        cm_cdate_add_100(dwritten_ed, (-1), dwritten_ed2);
		strcpy(dins_bgn_last,cm_to_infdate(dwritten_ed2));
	        
                */
                /*strcpy(dwritten_bg,cm_from_infdate_100(dwritten));  */
                i=0;
                h_count=0;
                strcpy(dwritten_bg,dwritten);
                strcpy(dwritten_bg,cm_edate2_add( dwritten_bg, 1, dwritten_bg));  
                while(1)
		{   	
	
			if(strcmp(new_dwritten,"1")==0 && i == atoi(dwork)) break;
			if(strcmp(new_dwritten,"1")!=0 && i == 2) break;
			$SELECT count(*)
			   INTO $h_count
			   FROM ca_holiday
			  WHERE holiday_bgn <= $dwritten_bg
			    AND holiday_end >= $dwritten_bg;
		printf("h_count[%d],before_date[%s]\n",h_count,dwritten_bg);                      
		      
			if(h_count == 0)
		      	/* �D���� */              	                   	
		      	{
		      		strcpy(dwritten_bg,cm_edate2_add( dwritten_bg, 1, dwritten_bg));  
		      		i++;
			}
			else
		 	{
		      	/* ���� */
		      		$SELECT max(holiday_end)    	
		           	   INTO $dwritten_ed
		           	   FROM ca_holiday
		          	  WHERE holiday_bgn <= $dwritten_bg
		            	    AND holiday_end >= $dwritten_bg;
		         if(SQLCODE == 0) strcpy(dwritten_bg, dwritten_ed); 
		         strcpy(dwritten_bg, cm_edate2_add( dwritten_bg, 1, dwritten_bg));             
			}      
		}
		strcpy(dins_bgn_last,dwritten_bg);
		
		
		strcpy(dentry_data,cm_sysd_cdate(dentry));
                strcpy(dentry_sql,cm_to_infdate(dentry_data));
                     
printf("dins_bgn_last=[%s]\n",dins_bgn_last);
printf("dentry_data=[%s]\n",dentry_data);
		 /*mm-dd-yyyy*/
			
printf("dentry_sql=[%s]\n",dentry_sql);
		strcpy(sys,cm_get_sysd());               /*yyyy-mm-dd  �t�Τ�*/
		strcpy(sys,cm_sysd_cdate(sys));          /*yy-mm-dd*/
		strcpy(sys,cm_to_infdate(sys));          /*mm-dd-yyyy*/
	
		/*$CLOSE cur_pre3;
		$FREE cur_pre3;*/
		}

               else
               {
               	     /*�ͮĤ�+6�Ӥu�@��*/   /*fwork =1 �O����*/

               	         /*�~�ȭ��Ѽ�*/
                       $SELECT tcode_remark
                          INTO $dwork
                          FROM cu_code_data
                         WHERE itype = 'WK'
                           AND icode = '2';

                 if(SQLCODE == SQLNOTFOUND) break;
                 strcpy(dwork,trim(dwork));
                 /*1050112�_ñ�欰�s�W�h */
                 /*      if(strcmp(new_dwritten,"1")==0){
                       sprintf(stmt,
		                   "SELECT skip %s first 1 dwork "
		                   "FROM cm_wrktbl "
		                   "WHERE dwork > '%s' "
		                   "AND fwork = '0' "
		                   "ORDER BY 1 ",dwork,dins_bgn);
		       } 
		       else{
                       sprintf(stmt,
		                   "SELECT skip 2 first 1 dwork "
		                   "FROM cm_wrktbl "
		                   "WHERE dwork > '%s' "
		                   "AND fwork = '0' "
		                   "ORDER BY 1 ",dins_bgn);
		       }             
printf("stmt[%s]\n", stmt);

                       $PREPARE pre2 FROM $stmt;
                       $DECLARE cur_pre2 CURSOR for pre2;
                       $OPEN cur_pre2;
                       $FETCH cur_pre2 INTO $dins_bgn_last;

	        if(SQLCODE == SQLNOTFOUND) break;*/
	        /*
	        strcpy(dins_bgn_bg,cm_from_infdate_100(dins_bgn));  
		if(strcmp(new_dwritten,"1")==0){
		cm_cdate_add_100(dins_bgn_bg, (1), dins_bgn_bg);
		rc = chk_working_date(dins_bgn_bg, dwork_int , &dins_bgn_ed, v_sMsg);
		}
		else{
		rc = chk_working_date(dins_bgn_bg, 2+1 ,&dins_bgn_ed, v_sMsg);
	        }
	        
	        cm_cdate_add_100(dins_bgn_ed, (-1), dins_bgn_ed2);
		strcpy(dins_bgn_last,cm_to_infdate(dins_bgn_ed2));
		
                strcpy(dentry_data,cm_sysd_cdate(dentry));
                strcpy(dentry_sql,cm_to_infdate(dentry_data));*/
                /*strcpy(dins_bgn_bg,cm_from_infdate_100(dins_bgn));  */
                i=0;
                h_count=0;
                strcpy(dins_bgn_bg,dins_bgn);
                strcpy(dins_bgn_bg,cm_edate2_add( dins_bgn_bg, 1, dins_bgn_bg));
                
                while(1)
		{   	
	
			if(strcmp(new_dwritten,"1")==0 && i == atoi(dwork)) break;
			if(strcmp(new_dwritten,"1")!=0 && i == 2) break;
			$SELECT count(*)
			   INTO $h_count
			   FROM ca_holiday
			  WHERE holiday_bgn <= $dins_bgn_bg
			    AND holiday_end >= $dins_bgn_bg;
		printf("h_count[%d],dins_bgn_bg[%s]\n",h_count,dins_bgn_bg);                      
		      
			if(h_count == 0)
		      	/* �D���� */              	                   	
		      	{
		      		strcpy(dins_bgn_bg,cm_edate2_add( dins_bgn_bg, 1, dins_bgn_bg));  
		      		i++;
			}
			else
		 	{
		      	/* ���� */
		      		$SELECT max(holiday_end)    	
		           	   INTO $dins_bgn_ed
		           	   FROM ca_holiday
		          	  WHERE holiday_bgn <= $dins_bgn_bg
		            	    AND holiday_end >= $dins_bgn_bg;
		         if(SQLCODE == 0) strcpy(dins_bgn_bg, dins_bgn_ed); 
		         strcpy(dins_bgn_bg, cm_edate2_add( dins_bgn_bg, 1, dins_bgn_bg));             
			}      
		}
		strcpy(dins_bgn_last,dins_bgn_bg);
		
		strcpy(dentry_data,cm_sysd_cdate(dentry));
                strcpy(dentry_sql,cm_to_infdate(dentry_data));
	
                
printf("dins_bgn_last=[%s]\n",dins_bgn_last);
printf("dentry_data=[%s]\n",dentry_data);

printf("dentry_sql=[%s]\n",dentry_sql);

                    strcpy(sys,cm_get_sysd());               /*yyyy-mm-dd*/
	            strcpy(sys,cm_sysd_cdate(sys));          /*yy-mm-dd*/
                    strcpy(sys,cm_to_infdate(sys));          /*mm-dd-yyyy*/
                    /*strcpy(dins_bgn_last,cm_from_infdate_100(dins_bgn_last));*/
               }

printf("dwork off\n");

/*1060804:���q���W���A����P�_*/
/*���O���A*****�O���Ѽ�*/
/*
	      if (receive=1&&detail>0&&pass>0)
	      {
         	
	        strcpy(pay,"�w���O");
	        strcpy(pay_type,"1");
	      }
	      else if (receive=1&&detail>0&&pass==0)
	      {
	        
	        strcpy(pay,"���O������");
	        strcpy(pay_type,"2");
	      }
	      else if ((receive=1&&detail==0&&pass==0)||receive==0)
	      {
	        
	  	strcpy(pay,"�����O");
	  	strcpy(pay_type,"2");
	      }
	      printf("option=[%s]pay_type=[%s]\n",option,pay_type);

	      
	      if(strcmp(option,"1")==0 && strcmp(pay_type,"1")!= 0)
	      	continue;
	      if(strcmp(option,"2")==0 && strcmp(pay_type,"2")!= 0)
		continue;
*/		
/*1060804:���q���W���A����P�_*/

	      /*if(diff<=0)
	      {
	        continue;
	      }*/
	      
	      /*strcpy(dins_bgn_last_100,cm_from_infdate_100(dins_bgn_last));*/
	      strcpy(dentry_sql_100,cm_from_infdate_100(dentry_sql));
	      strcpy(sys_100,cm_from_infdate_100(sys));
	      idins_bgn_last = cm_ymd_cdate(dins_bgn_last_100);
	      identry_sql = cm_ymd_cdate(dentry_sql_100);
	      isys = cm_ymd_cdate(sys_100);

	      	/*�O���Ѽ�*/
	     if (receive>=1&&detail>0&&pass>0)
	     {
	     	 printf("dins_bgn_last[%s]  dentry_sql[%s]\n",dins_bgn_last,dentry_sql);
	        if(strcmp(trim(ftype_sp),"20")==0)
	      	{	     		      		
               $SELECT count(dwork)
                  INTO $diff_dwork
                  FROM cm_wrktbl
                 WHERE dwork > $dins_bgn_last
                   AND dwork <= $dentry_sql
                 ORDER BY 1;        
                         
                }
                 else
		{
			/*idins_bgn_last++;*/
			h_count = 0;
			diff_dwork = 0;
			/*while(idins_bgn_last < identry_sql)
			{
				if(idins_bgn_last >= identry_sql) break;
				diff_dwork++;
				chk_working_date( dins_bgn_last_100, diff_dwork, &dins_bgn_last_100_2, v_sMsg);
				idins_bgn_last = cm_ymd_cdate(dins_bgn_last_100_2)-1;
			}*/
			strcpy(before_date,dins_bgn_last);
			/*strcpy(before_date,cm_edate2_add( before_date, 1, before_date));*/
			while(1)
			{   	
				 strcpy(before_date_1,cm_from_infdate_100(before_date));
				 sLdeffect = cm_ymd_cdate(before_date_1);		
				 printf("identry_sql[%d],sLdeffect[%d]\n",identry_sql,sLdeffect);
				 if(identry_sql == sLdeffect) break;	
					$SELECT count(*)
					   INTO $h_count
					   FROM ca_holiday
					  WHERE holiday_bgn <= $before_date
					    AND holiday_end >= $before_date;
				printf("h_count[%d],before_date[%s]\n",h_count,before_date);                      
				      
					if(h_count == 0)
				      	/* �D���� */              	                   	
				      	{
				      		strcpy(before_date,cm_edate2_add( before_date, 1, before_date));  
				      		diff_dwork++;
					}
					else
				 	{
				      	/* ���� */
				      		$SELECT max(holiday_end)    	
				           	   INTO $after_date
				           	   FROM ca_holiday
				          	  WHERE holiday_bgn <= $before_date
				            	    AND holiday_end >= $before_date;
				          
				         if(SQLCODE == 0) strcpy(before_date, after_date); 
				         
				         strcpy(before_date, cm_edate2_add( before_date, 1, before_date));             
					} 
				 
				 if(identry_sql < sLdeffect) 
				 {
				 	diff_dwork = 0;
				 	break; 
				 }    
			}

		}
	    }
	    else
            {
	      	if(strcmp(trim(ftype_sp),"20")==0)
	      	{
	      	  $SELECT count(dwork)
                  INTO $diff_dwork
                  FROM cm_wrktbl
                 WHERE dwork > $dins_bgn_last
                   AND dwork <= $sys
                 ORDER BY 1;
                }
                else
		{	
			diff_dwork = 0;
			h_count = 0;
			strcpy(before_date,dins_bgn_last); 
			while(1)
			{   	
				 strcpy(before_date_1,cm_from_infdate_100(before_date));
				 sLdeffect = cm_ymd_cdate(before_date_1);		
				 printf("isys[%d],sLdeffect[%d]\n",identry_sql,sLdeffect);	
	   	   	   	if(isys == sLdeffect) break;
					$SELECT count(*)
					   INTO $h_count
					   FROM ca_holiday
					  WHERE holiday_bgn <= $before_date
					    AND holiday_end >= $before_date;
				printf("h_count[%d],before_date[%s]\n",h_count,before_date);                      

					if(h_count == 0)
				      	/* �D���� */              	                   	
				      	{
				      		strcpy(before_date,cm_edate2_add( before_date, 1, before_date));  
				      		diff_dwork++;
					}
					else
				 	{
				      	/* ���� */
				      		$SELECT max(holiday_end)    	
				           	   INTO $after_date
				           	   FROM ca_holiday
				          	  WHERE holiday_bgn <= $before_date
				            	    AND holiday_end >= $before_date;
				          
				         if(SQLCODE == 0) strcpy(before_date, after_date); 
				         
				         strcpy(before_date, cm_edate2_add( before_date, 1, before_date));             
					}
				 
				 if(isys < sLdeffect) 
				 {
				 	diff_dwork = 0;
				 	break; 
				 } 
			}
			
                }
	    }

	      if(diff_dwork<=0)
	      {
	        continue;
	      }


	      if(strcmp(trim(ftype_sp),"20")==0)
	      {
	      	strcpy(cftype_sp,"20�O�g�N");
	      }
	      else if(strcmp(trim(ftype_sp),"01")==0)
	      {
	      	strcpy(cftype_sp,"01�j���I");
	      }
	      else if(strcmp(trim(ftype_sp),"10")==0)
	      {
	      	strcpy(cftype_sp,"10�H�u�֭�L��");
	      }
	      else if(strcmp(trim(ftype_sp),"AP")==0)
	      {
	      	strcpy(cftype_sp,"AP�H�u�֭�");
	      }
	      else
	      {
	      	strcpy(cftype_sp,"�@��");
	      }

	      if (strcmp(trim(imgr),"1") == 0)
	      {
	          strcpy(sImgr_1,"���ӥ�");
	      }
	      else
	      {
	      	  strcpy(sImgr_1," ");
	      }
	      
	     strcpy(dupdate,cm_sysd_cdate(dupdate));  /*yy-mm-dd*/
	     printf("-----dupdate[%s] \n",dupdate);
             strcpy(dupdate,cm_to_infdate(dupdate));	     
	     printf("-----dupdate[%s] \n",dupdate);
	      	      
	      /*�浧�鵲�G�bca_permit_after_log�L��� AND �bcm_pre_receive ������渹������*/
	      if ((strcmp(trim(nupdate),"")==0 )&& (strcmp(trim(iendorse),"")!=0) && strcmp(trim(ftype_sp),"10")==0)
	      {      
	      	strcpy(sFullName, get_car_full_db(ipolicy1));        
	          sprintf(stmt6,"select dedr_close,iclose \
	      	                  from %s:edr_relation \
	      	                 where iendorse = '%s'",sFullName,iendorse); 
	      	   $PREPARE prep6 FROM $stmt6;
                   $EXECUTE prep6 INTO $d_close,$iclose;             
	      	 printf("-----stmt6[%s]  \n",stmt6);
                  $select nname 
                     into $nclose 
                     from officer                     
                    where iofficer = $iclose;
                  printf("-----d_close[%s] \n",d_close);
	      	  strcpy(dupdate,d_close);
	          strcpy(iupdate,iclose);
	          strcpy(nupdate,nclose);
             strcpy(dupdate,cm_from_infdate_100(dupdate));
             strcpy(dupdate,cm_sysd_edate(dupdate));	     
	     printf("-----dupdate[%s] \n",dupdate);	          	          
	      }
	      
printf("-----nupdate[%s]  iendorse[%s]\n",nupdate,iendorse);

	      if(strcmp(trim(iendorse)," ")==0)
	      	strcpy(iendorse1,ipre_end);
	      else
		strcpy(iendorse1,iendorse);
		
	      /* ���L�g�쩵�~���i�� */
	      ao_ca_prercv_illegal(ipre_rcv,iins_kind,fdelay);
	
              $INSERT INTO car634_tmp1
               (nchi_abv,nbranch,ileader,iofficer,iofficer_name,iroute_main,iroute,ipolicy1,
                dins_bgn,dins_end,ipre_rcv,ipre_end,dwritten,nassured,itarget1,ntarget1,
		macct_prem,payment,dentry,overdue,ftype_pol,ftype_sp,dupdate,iupdate,nupdate,imgr,fdelay)
               VALUES($nchi_abv,$nbranch,$ileader,$iofficer,$iofficer_name,$iroute_main,$iroute,
         			  $ipolicy1,$dins_bgn,$dins_end,$ipre_rcv,$iendorse1,
         			  $dwritten,$nassured,$itarget1,$ntarget1,
         			  $macct_prem,$pay,$dentry_sql,$diff_dwork,$ftype_pol,
         			  $cftype_sp,$dupdate,$iupdate,$nupdate,$sImgr_1,$fdelay);    
         			  		       			  
	   }
printf("stmt1[%s]\n\n", stmt1);	    
      $CLOSE cur_pre1;
      $FREE cur_pre1;

      return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/


long car634_build()
{
   int rc;
    char    sfilename[81],stitle[1024],stmt[1024];

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(sfilename,"�O��ú�O�ޱ�����[CAR634]");
    strcpy(stitle,"\t�{���N��:car634\�O��ú�O�ޱ�����\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");


    strcat(stitle,"\t�Ұ�\t���O\t�޲z�H\t�g��N��\t�g��W��\t�D�q���N��\t�q���N��\t�O�渹\t�O��_��\t�O��W��\t�����渹\t�t�B���\t");
    strcat(stitle,"�O��鵲��\t�Q�O�I�H�W��\t����\t�������X\t�O�O\t���O���A\tú�O��T��F��\t�O���Ѽ�\t�O�����O\t�O�����O�Ӷ�\t");
    strcat(stitle,"�f�֤��\t�f�֤H���N��\t�f�֤H���W��\t���ӥ����\t�g�쩵�~���i��\t");  
    strcpy(stmt,"select nchi_abv,nbranch,ileader,iofficer,iofficer_name,iroute_main,iroute,ipolicy1,dins_bgn,dins_end,ipre_rcv,ipre_end, "
    		 " dwritten,nassured,itarget1,ntarget1,macct_prem,payment,dentry,overdue,ftype_pol,ftype_sp,dupdate,iupdate,nupdate,imgr,fdelay "
    		 "from car634_tmp1");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);

    if (rc != SUCCESS) {
        sprintf(msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;

    }

    return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}


char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
        char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
        char sTmp_db_name[21];

        sTmp_db_name[0]='\0';
        if (*sIpolicy != '\0' && *sIpolicy !=' ')
        {
           sTmp_db_name[0]='\0';
           strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
           strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
                  USE_BRANCH_ID));
           strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
        }
  printf("sTmp_db_name[%s]",sTmp_db_name);      
  return sTmp_db_name;
}