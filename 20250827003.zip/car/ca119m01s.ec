/************************************************/
/*   �{���W�� : ca119m01s.ec                    */
/*   �ק��� : 2004/05/05                      */
/*   �@�~�W�� : ���I���[���ڶO�v���@�@�~        */
/************************************************/

#include <stdio.h>
#include <string.h>
#include <decimal.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "commsgs.h"
#include "carmsgs.h"
$include sqlca;
#include "safeclib.h"

long MsgCode;

long car119(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car119_insert(),car119_single_query(),car119_multiple_query(),
      car119_update_exec(),car119_squery(),car119_list();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'S': rtncode = car119_squery(reply);
            break;
  case 'A':
           rtncode=car119_insert(reply);
           break;
  case 'Q':
           rtncode=car119_single_query(reply);
           break;
  case 'M':
           rtncode=car119_multiple_query(reply);
           break;
  case 'D':
  case 'U':
           rtncode=car119_update_exec(reply,command,com_len);
           break;
  case 'L':
           rtncode=car119_list(reply);
           break;
  default :
        return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
 }
 return(rtncode);
}

long car119_squery(reply)
serverReply reply;
{
     $char DBName[5],D_dbsite[5];
     $char icar_type[3];
     $char stmt[1024];
     $char c_icar_type[3];
     $int cnt = 0;  
    
     int LHiBufLen;
     long MsgCode;

     cm_buf_get("%s",DBName);
     cm_buf_get("%s",icar_type);

     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
        { return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;}
        
     $SELECT count(icode) into $cnt FROM car_type where icode = $icar_type ;
      
     cm_buf_init(ReplyBuf);
     
    if (cnt==0){
    	 cm_buf_put("%l",4021);
     }else{
         cm_buf_put("%l",M_CM_OK); 
    }     
/*     if (SQLCODE==SQLNOTFOUND){
    	 cm_buf_put("%l",4021);
     }else{
         cm_buf_put("%l",M_CM_OK); 
    }    */
     
     
     
     LHiBufLen = cm_buf_len(ReplyBuf);      
     if(SendSyncReply(reply,ReplyBuf,LHiBufLen,api_OKComplete) == False)
     {
         $WHENEVER SQLERROR CONTINUE;
         return apiRC;
     }
     
     return api_OKComplete;
             
 errexit:
        printf("sqlerrm:%s\n",sqlca.sqlerrm);
        $WHENEVER SQLERROR CONTINUE;
        MsgCode = SQLCODE;
        if (SQLCODE != 0) MsgCode = SQLCODE;
        return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

long car119_insert(reply)
serverReply reply;
{
     $char DBName[5];
     $char c_icar_type[3],c_provision[7],c_iins_type[INSURANCE_TYPE],c_coefficient[10],c_mexpense[11],c_drate[11];
     $double dec_coefficient;
     $double dbl_coefficient,dbl_mexpense;
     $dec_t dec_mexpense; 
  
     int LiBufLen;
     cm_buf_get("%s",DBName);
     cm_buf_get("%s %s %s %s %s %s",c_icar_type,c_provision,c_iins_type,c_coefficient,c_mexpense,c_drate);
     
     deccvasc( c_coefficient, strlen(c_coefficient), &dec_coefficient);
     dectodbl( &dec_coefficient, &dbl_coefficient);
     deccvasc( c_mexpense, strlen(c_mexpense), &dec_mexpense);
     dectodbl( &dec_mexpense, &dbl_mexpense);
     strcpy(c_drate,cm_to_infdate(c_drate));
     
     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
         return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     $BEGIN WORK;
     $WHENEVER SQLERROR GOTO errexit;
     
     $INSERT INTO ca_add_provision 
            (icar_type,provision,iins_type,coefficient,mexpense,drate)
      VALUES ($c_icar_type,$c_provision,$c_iins_type,$dbl_coefficient,$dec_mexpense,$c_drate);

     
/*     sprintf(LsBuffer,"INSERT INTO collate_brand \
            (imotor,sales_brand,dtl_brand,mprize,icar_type,ibrand)\
      VALUES (?,?,?,?,?,?)");
  
     $PREPARE a_id FROM $LsBuffer;
     $EXECUTE a_id USING $c_imotor,$c_sales_brand,$c_dtl_brand,$d_mprize,
                         $c_icar_type,$c_ibrand;  */
  
     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);
     LiBufLen = cm_buf_len(ReplyBuf);   

     if(SendSyncReply(reply,ReplyBuf,LiBufLen,api_OKComplete) == False)
     {
       $WHENEVER SQLERROR CONTINUE;
       $ROLLBACK WORK;
       return apiRC;
     }

     $WHENEVER SQLERROR GOTO errexit;
     $COMMIT WORK;
     return api_OKComplete;

     errexit:
         printf(" sqlerrm = %s\n",sqlca.sqlerrm);
         $WHENEVER SQLERROR CONTINUE;
         MsgCode = SQLCODE;
         $ROLLBACK WORK;
         if (SQLCODE != 0) MsgCode = SQLCODE;
         return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

/*-----------------------------------------------------------------*/
            
long car119_delete(reply)
serverReply reply;
{
    $char icar_type[3],provision[7],iins_type[INSURANCE_TYPE],coefficient[10],mexpense[11],drate[11];
    $char DBName[5];
    $char stmt[512];
    int tmp_len;
    long MsgCode;
    int LiBufLen;

    cm_buf_get("%s %s %s %s %s",DBName,icar_type,provision,iins_type,drate);
    strcpy(drate,cm_to_infdate(drate));
    
    $WHENEVER SQLERROR GOTO errexit;
    if(db_select(DBName) == False) 
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
        
    $WHENEVER SQLERROR GOTO errexit;
    $BEGIN WORK;    
      
    sprintf_s(stmt, sizeof stmt, "delete from ca_add_provision "
           " where icar_type = '%s' "
           " and provision = '%s' "
           " and iins_type = '%s' "
           " and drate = '%s'",icar_type,provision,iins_type,drate);
             
    printf("stmt=[%s]\n",stmt) ;      
 	$EXECUTE IMMEDIATE $stmt ;      
 	
    if(SQLCODE != 0) goto errexit;
        
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    tmp_len = cm_buf_len(ReplyBuf);

    if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        return apiRC;
    }  

    $WHENEVER SQLERROR GOTO errexit;
    $COMMIT WORK;
    return api_OKComplete;

errexit:
    MsgCode = SQLCODE;
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if( SQLCODE != 0) MsgCode = SQLCODE;
    return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
/*-----------------------------------------------------------------*/
long car119_single_query(reply)
serverReply reply;
{
 
 $char DBName[5];
 $char icar_type[3],provision[7],iins_type[INSURANCE_TYPE],coefficient[10],mexpense[11],drate[11];
 $char stmt[1024];
 $char c_icar_type[3],c_provision[7],c_iins_type[INSURANCE_TYPE],c_coefficient[10],c_mexpense[11],c_drate[11];

 int tmp_len;
 
 cm_buf_get("%s %s %s %s %s %s",DBName,icar_type,provision,iins_type,mexpense,drate);

 strcpy(icar_type,trim(icar_type));
 strcpy(provision,trim(provision));
 strcpy(mexpense,trim(mexpense));
 strcpy(drate,cm_to_infdate(drate));
 
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }
 
 $SELECT icar_type,provision,iins_type,coefficient,mexpense,drate
    INTO $c_icar_type,$c_provision,$c_iins_type,$c_coefficient,$c_mexpense,$c_drate
    FROM ca_add_provision
   WHERE icar_type = $icar_type
     AND provision = $provision
     AND iins_type = $iins_type
     AND drate = $drate
     and mexpense = $mexpense;

 if(SQLCODE==SQLNOTFOUND)
 {
  if(exitsub(reply,M_CM_NOT_FOUND) == True)
    return M_CM_NOT_FOUND;
  else
    return apiRC;
 }

 strcpy(c_drate,cm_from_infdate_100(c_drate));
 printf("Trace -- iins_type = [%s] \n",  iins_type);
 printf("Trace -- c_iins_type = [%s] \n",  c_iins_type);
 cm_buf_init(ReplyBuf);
 cm_buf_put("%l %s %s %s %s %s %s",
             M_CM_OK,c_icar_type,c_provision,c_iins_type,c_coefficient,c_mexpense,c_drate);


 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

 errexit:
   MsgCode = cm_show_sql_err("ca119_single_query", NULL);
  if(exitsub(reply,MsgCode) == True)
   return SQLCODE;
  else
   return apiRC;
}

long car119_multiple_query(reply)
serverReply reply;
{
 $char DBName[5];
 $char icar_type[3],provision[7],iins_type[INSURANCE_TYPE],coefficient[10],mexpense[11],drate[11];
 $char stmt[1024],stmt1[50],stmt2[50],stmt3[50],stmt4[50],stmt5[50];
 $char c_icar_type[3],c_provision[7],c_iins_type[INSURANCE_TYPE],c_coefficient[10],c_mexpense[11],c_drate[11],c_tmpdrate[11];

 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;

 cm_buf_get("%s %s %s %s %s %s",DBName,icar_type,provision,iins_type,mexpense,drate);

 strcpy(icar_type,trim(icar_type));
 strcpy(provision,trim(provision));
 strcpy(iins_type,trim(iins_type));
 strcpy(mexpense,trim(mexpense));
 strcpy(drate,trim(drate));
 
 if (strstr(icar_type,"*") != NULL){
     sprintf_s(stmt1, sizeof stmt1, "where icar_type matches '%s' ",icar_type);
 }else{
    sprintf_s(stmt1, sizeof stmt1, "where icar_type = '%s' ",icar_type);
  }   
 if (strstr(provision,"*") != NULL){
    sprintf_s(stmt2, sizeof stmt2, "and provision matches '%s'",provision);
 }else{
    sprintf_s(stmt2, sizeof stmt2, "and provision = '%s' ",provision);
  }   
 if (strstr(iins_type,"*") != NULL){
    sprintf_s(stmt3, sizeof stmt3, "and iins_type matches '%s'",iins_type);    
 }else{
    sprintf_s(stmt3, sizeof stmt3, "and iins_type = '%s' ",iins_type);    
  }
  if ((strncmp(drate,"*",1)==0)){
    sprintf_s(stmt4, sizeof stmt4, " ",drate);
 }else{
    strcpy(drate,cm_to_infdate(drate));
    sprintf_s(stmt4, sizeof stmt4, "and drate = '%s' ",drate);
 }
  if ((strncmp(mexpense,"*",1)==0)){
    sprintf_s(stmt5, sizeof stmt5, " ",mexpense);
 }else{
    sprintf_s(stmt5, sizeof stmt5, "and mexpense = '%s' ",mexpense);
 }
 
 printf("stmt1=[%s] stmt2=[%s] stmt3=[%s] stmt4=[%s] stmt5=[%s]\n",stmt1,stmt2,stmt3,stmt4,stmt5);
 
 
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

    sprintf_s(stmt, sizeof stmt, "SELECT icar_type,provision,iins_type,coefficient,mexpense,drate "
                   " FROM ca_add_provision "
                   " %s %s %s %s %s "
                " ORDER BY 1,2,3",stmt1,stmt2,stmt3,stmt4,stmt5);
    printf("stmt1\n",stmt);            
 $PREPARE rs FROM $stmt;
 $DECLARE q_cur CURSOR FOR rs;
 $OPEN q_cur;
 
 for(;;)
  {
    
    $FETCH q_cur INTO $c_icar_type,$c_provision,$c_iins_type,$c_coefficient,$c_mexpense,$c_tmpdrate;
   
    if (SQLCODE != 0) break;
    
    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();
     }


  /*  deccvasc( str_m_mprize, strlen(str_m_mprize), &dec_m_mprize);
    dectodbl( &dec_m_mprize, &d_m_mprize);   
    sprintf(str_m_mprize,"%.2f",d_m_mprize);*/
    strcpy(c_drate,cm_from_infdate_100(c_tmpdrate));
    cm_buf_put("%s %s %s %s %s %s",c_icar_type,c_provision,c_iins_type,c_coefficient,c_mexpense,c_drate);
    
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
        $CLOSE q_cur;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;

        if(replycnt > 5) sleep(3);
        else if(replycnt > 3) sleep(2);
        else if(replycnt > 1) sleep(1);

        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();

        /*sprintf(str_m_mprize,"%.2f",d_m_mprize);*/
        strcpy(c_drate,cm_from_infdate_100(c_tmpdrate));
        cm_buf_put("%s %s %s %s %s %s",c_icar_type,c_provision,c_iins_type,c_coefficient,c_mexpense,c_drate);

        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
  } /* for loop */

 $CLOSE q_cur;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
    if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
      return M_CM_NOT_FOUND;                               /*?*/
    else
      return apiRC;
  }

 errexit:
   MsgCode = cm_show_sql_err("ca119_multiple_query", NULL);
   if(exitsub(reply,MsgCode) == True)
     return SQLCODE;
   else
     return apiRC;
}
/*-----------------------------------------------------------------*/
long car119_update(reply)
serverReply reply;
{
     $char DBName[5];
     $char c_icar_type[3],c_provision[7],c_iins_type[INSURANCE_TYPE],c_coefficient[10],c_mexpense[11],c_drate[11];
     $double dec_coefficient,dec_mexpense;
     $double dbl_coefficient,dbl_mexpense;
     $char stmt[512];
     int tmp_len;
     long MsgCode;
     int LiBufLen;
     cm_buf_get("%s",DBName);
     cm_buf_get("%s %s %s %s %s %s",c_icar_type,c_provision,c_iins_type,c_coefficient,c_mexpense,c_drate);
     
     deccvasc( c_coefficient, strlen(c_coefficient), &dec_coefficient);
     dectodbl( &dec_coefficient, &dbl_coefficient);
     deccvasc( c_mexpense, strlen(c_mexpense), &dec_mexpense);
     dectodbl( &dec_mexpense, &dbl_mexpense);
     strcpy(c_drate,cm_to_infdate(c_drate));
    
    $WHENEVER SQLERROR GOTO errexit;

    if(db_select(DBName) == False) 
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    $BEGIN WORK;   
    $UPDATE ca_add_provision 
        SET coefficient = $dbl_coefficient, mexpense = $dbl_mexpense 
      WHERE icar_type = $c_icar_type 
        AND provision = $c_provision 
        AND iins_type = $c_iins_type 
        AND drate = $c_drate;
           
    if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
       {
        SQLCODE = M_CM_NOT_FOUND;
        goto errexit;
    }
       
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    tmp_len = cm_buf_len(ReplyBuf);

    if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        
        return apiRC;
    }  

    $WHENEVER SQLERROR GOTO errexit;
    $COMMIT WORK;
    return api_OKComplete;

errexit:
    MsgCode = SQLCODE;
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if( SQLCODE != 0) MsgCode = SQLCODE;
    return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
           
/*-----------------------------------------------------------------*/

long car119_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
        
 $char DBName[5];
 $char cur_icar_type[3],cur_provision[7],cur_iins_type[INSURANCE_TYPE],cur_coefficient[10],cur_mexpense[11],cur_drate[11]; 
 $dec_t  dec_coefficient,dec_mexpense;
 $double dbl_coefficient,dbl_mexpense;
  
 $char u_icar_type[3],u_provision[7],u_iins_type[INSURANCE_TYPE],u_coefficient[10],u_mexpense[11],u_drate[11];
 $dec_t  dec_u_coefficient,dec_u_mexpense;
 $double d_u_coefficient,d_u_mexpense;
 $char str_u_coefficient[10],str_u_mexpense[11];
  
 $char q_icar_type[3],q_provision[7],q_iins_type[INSURANCE_TYPE],q_coefficient[10],q_mexpense[11],q_drate[11];
 $dec_t  dec_q_coefficient,dec_q_mexpense;
 $double d_q_coefficient,d_q_mexpense;
 $char str_q_coefficient[10],str_q_mexpense[11];
 
 $double coefficient,mexpense; 
  
 char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
 int tmp_len,raw_len; long dummy;
 DBinfo *list;
 int i, j, is_del_fail=0, is_upd_fail=0;
 $char stmt_buf[300];

 comm = (char *) command;
 cm_buf_init(command);
 cm_buf_get("%c %s",&option,DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

/*  if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
     return exitsub(reply,M_CM_NOT_DBLIST) ? M_CM_NOT_DBLIST : apiRC;  */

 memcpy(&raw_len,&comm[com_len],sizeof(int));
 pos = &comm[com_len+sizeof(int)];
 raw_ptr = malloc(raw_len);
 if (raw_ptr != (char*)0)
  memcpy(raw_ptr,pos,raw_len);
 else
  { 
   return exitsub(reply,M_CM_NOT_MALLOC) ? M_CM_NOT_MALLOC : apiRC;
  }

 cm_buf_init(raw_ptr);          /* get index key from old record */
 /*cm_buf_get("%l %s %s %s %s %s %s ",
             &dummy,q_imotor,q_sales_brand,q_dtl_brand,str_q_mprize,q_icar_type,q_ibrand);*/
 cm_buf_get("%l %s %s %s %s %s %s ",             
             &dummy,q_icar_type,q_provision,q_iins_type,str_q_coefficient,str_q_mexpense,q_drate);
  /*            
 deccvasc( str_q_mprize, strlen(str_q_mprize), &dec_q_mprize);
 dectodbl( &dec_q_mprize, &d_q_mprize);*/
 
 deccvasc( str_q_coefficient, strlen(str_q_coefficient), &dec_q_coefficient);
 dectodbl( &dec_q_coefficient, &d_q_coefficient);
 deccvasc( str_q_mexpense, strlen(str_q_mexpense), &dec_q_mexpense);
 dectodbl( &dec_q_mexpense, &d_q_mexpense);
 strcpy(q_drate,cm_to_infdate(q_drate));
 
 $BEGIN WORK;
  /* 
 $SELECT imotor,sales_brand,dtl_brand,mprize,icar_type,ibrand
    INTO $cur_imotor,$cur_sales_brand,$cur_dtl_brand,$mprize,$cur_icar_type,$cur_ibrand
    FROM collate_brand
   WHERE imotor=$q_imotor AND sales_brand=$q_sales_brand AND dtl_brand = $q_dtl_brand
     AND mprize = $d_q_mprize;*/
   
 $SELECT icar_type,provision,iins_type,coefficient,mexpense,drate
    INTO $cur_icar_type,$cur_provision,$cur_iins_type,$cur_coefficient,$cur_mexpense,$cur_drate
    FROM ca_add_provision
   WHERE icar_type = $q_icar_type
     AND provision = $q_provision
     AND iins_type = $q_iins_type
     AND mexpense  = $str_q_mexpense
     AND drate     = $q_drate;

  /* if key value has been changed then SQLNOTFOUND,else put current value
     into cur_buf for comparison */

 if (SQLCODE == SQLNOTFOUND)
 {
   MsgCode = M_CM_NOT_FOUND;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(SQLCODE != 0) MsgCode = SQLCODE;
   return exitsub(reply,MsgCode) ? MsgCode : apiRC;
 }
 printf("--618 \n");
 strcpy(cur_drate,trim(cm_from_infdate_100(cur_drate)));
 
 cm_buf_init(cur_buf);
/*
 sprintf(cur_coefficient,"%.6f",coefficient);
 sprintf(cur_mexpense,"%.3f",mexpense);   
 */
 
 printf(" cur_coefficient[%s]\n",cur_coefficient);
 printf(" cur_mexpense[%s]\n",cur_mexpense);
 
/* cm_buf_put("%l %s %s %s %s %s %s ",
             dummy,cur_imotor,cur_sales_brand,cur_dtl_brand,cur_mprize,
             cur_icar_type,cur_ibrand);  */
 cm_buf_put("%l %s %s %s %s %s %s ",
             dummy,cur_icar_type,cur_provision,cur_iins_type,cur_coefficient,
             cur_mexpense,cur_drate);

 write(1,raw_ptr,raw_len);
 write(1,"\n",1);
 write(1,cur_buf,raw_len);
 write(1,"\n",1);


 printf("cur_buf[%s]\n",cur_buf);
 printf("raw_ptr[%s]\n",raw_ptr);
 if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
 {
   MsgCode = M_CM_NOT_EQUAL;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(SQLCODE != 0) MsgCode = SQLCODE;
   return exitsub(reply,MsgCode) ? MsgCode : apiRC;
 }

 /* equal, then exec DB operation */

 if ( option == 'D' )
  {
 
    sprintf_s(stmt_buf, sizeof stmt_buf, "DELETE FROM ca_add_provision "
        " WHERE icar_type= ? AND provision = ? AND iins_type = ? "
        " AND drate= ? AND mexpense = ?");
    $PREPARE d_id FROM $stmt_buf;


    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      
     }
    $EXECUTE d_id USING $q_icar_type,$q_provision,$q_iins_type,
                        $q_drate,$str_q_mexpense;
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      
     }

   if( is_del_fail ) goto errexit;
   
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
   {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
   }

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else if (option == 'U')
  {
   cm_buf_init(command);

/*   cm_buf_get("%c %s %s %s %s %s %s %s",
           &option,DBName,u_imotor,u_sales_brand,u_dtl_brand,str_u_mprize,u_icar_type,u_ibrand); */
   cm_buf_get("%c %s %s %s %s %s %s %s",
          &option,DBName,u_icar_type,u_provision,u_iins_type,str_u_coefficient,str_u_mexpense,u_drate);
/*          
    deccvasc( str_u_mprize, strlen(str_u_mprize),&dec_u_mprize);
    dectodbl( &dec_u_mprize, &d_u_mprize);*/

    deccvasc( str_u_coefficient, strlen(str_u_coefficient), &dec_u_coefficient);
    dectodbl( &dec_u_coefficient, &d_u_coefficient);
    deccvasc( str_u_mexpense, strlen(str_u_mexpense), &dec_u_mexpense);
    dectodbl( &dec_u_mexpense, &d_u_mexpense);
    strcpy(u_drate,cm_to_infdate(u_drate));

   /* grasp old key */
   cm_buf_init(raw_ptr);
 /*   cm_buf_get("%l %s %s %s %s %s %s ",&dummy,
        q_imotor,q_sales_brand,q_dtl_brand,str_q_mprize,q_icar_type,q_ibrand);
 */       
   cm_buf_get("%l %s %s %s %s %s %s ",             
            &dummy,q_icar_type,q_provision,q_iins_type,str_q_coefficient,str_q_mexpense,q_drate);
            
   strcpy(q_drate,cm_to_infdate(q_drate));         
   printf("q_drate[%s]\n",q_drate);
   printf("u_drate[%s]\n",u_drate);
   free(raw_ptr);
   
   $WHENEVER SQLERROR CONTINUE;

    sprintf_s(stmt_buf, sizeof stmt_buf,
               "UPDATE ca_add_provision "
               "    SET (icar_type,provision,iins_type,coefficient,mexpense,drate) "
               "    = (?,?,?,?,?,?) "
               "  WHERE icar_type = ? AND provision=? AND iins_type = ?  "
               "    AND drate = ?  AND mexpense =?"); 

    $PREPARE u_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
     
     }

 /*    $EXECUTE u_id USING $u_imotor,$u_sales_brand,$u_dtl_brand,$str_u_mprize,
                        $u_icar_type,$u_ibrand,
                        $q_imotor,$q_sales_brand,$q_dtl_brand,$d_q_mprize; */
                        
    $EXECUTE u_id USING  $u_icar_type,$u_provision,$u_iins_type,$d_u_coefficient,$d_u_mexpense,$u_drate,
                         $q_icar_type,$q_provision,$q_iins_type,$q_drate,$str_q_mexpense;                        
                         
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      
     }

 /* if(sqlca.sqlerrd[2] == 0)
    {
        printf(" ********************************* \n");
        sprintf(stmt_buf,"INSERT INTO collate_brand \
         (imotor,sales_brand,dtl_brand,mprize,icar_type,ibrand)\
          VALUES (?,?,?,?,?,?)");

      $PREPARE ua_id FROM $stmt_buf;
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        
       }
      $EXECUTE ua_id USING $u_imotor,$u_sales_brand,$u_dtl_brand,$d_u_mprize,
                           $u_icar_type,$u_ibrand;
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        
       }
     }                                           */
 
   if( is_upd_fail ) goto errexit;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
   {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
   }
   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else
  {
   MsgCode = M_CM_WRONG_OPTION;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
    return MsgCode;
   else
    return apiRC;
  }

errexit:
  MsgCode = SQLCODE;
  cm_show_sql_err("ca119_update_exec", stmt_buf);
  $WHENEVER SQLERROR CONTINUE;
  $ROLLBACK WORK;
  if(SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True)
   return MsgCode;
  else
   return apiRC;
}
/*-----------------------------------------------------------------*/
long car119_list(reply)
serverReply reply;
{
 int     tmp_len;
$char   DBName[5];
$char   iprovision[7], nprovision[41];
long    rc, iCount;

    $WHENEVER SQLERROR GOTO errexit;

    cm_buf_get("%s", DBName);

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
             return M_CM_DB_NOTOPEN;
        else
             return apiRC;
    }

    $DECLARE curs1 CURSOR FOR
      SELECT iprovision, nprovision
        FROM ca_provision_main
       WHERE fset='Y';

    cm_buf_init(ReplyBuf);
    cm_buf_res_msg();
    cm_buf_res_count();
    iCount=0;
    $OPEN curs1;
    for(;;)
    {
        $FETCH curs1 INTO $iprovision, $nprovision;
        if( SQLCODE == SQLNOTFOUND)
            break;
        cm_buf_put("%s %s", iprovision, nprovision);
        iCount++;
    }
    $CLOSE curs1;
    $FREE curs1;
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(iCount);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}