/**********************************************************************/
/*   program id   : ca1004q01s.ec                                     */
/*   program name : ����¾�ηl���v�d��(�O���)                        */
/*   date written : 2001/01/17                                        */
/*   date modify  : 2005/05/10                                        */
/*   author       : Jessie Leng                                       */
/*   files        : ori_ply_relation    i                             */
/*                  ori_ins_type        i                             */
/*                  edr_relation        i                             */
/*                  edr_ins_type        i                             */
/*                  appraisal           i                             */
/*                  app_ins_type        i                             */
/*                  stl_ins_type        i                             */
/*                  ca_app_victim       i                             */
/*                  ca_stl_victim       i                             */
/*   temp table   : car1004             io                            */
/*                  car1004_1           io                            */
/**********************************************************************/
#include <stdio.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include "sqlfatal.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"

#include "commsgs.h" 
#include "gls_array.h" 
#include "gls_const.h"
#include "safeclib.h"

#include <stdlib.h>
#include <decimal.h>
$include sqltypes.h;
#include "decimal.h"
#include "print.h"

char    itype[2],itype_2[2],ncode[121],nply_cnt[7],iflag[2];
char    dbgn1[11],dend1[11],cond[128];
char    *fileptr;
char    outputf[N_FILE+1],outputf_ix[N_FILE+1];
char    outputf1[N_FILE+1];
int     flag_close_dend, flag_close_dbgn, first;
int     max_cnt = 0;
double  mouts_1,msettle_1;
double  sub_mprem,sub_mfull,sub_mouts,sub_msettle,sub_mloss;
double  tot_mprem,tot_mfull,tot_mouts,tot_msettle,tot_mloss;
double  tmp_mbgn_outs,tmp_mend_outs;
double  tmp_mstl_dbgn,tmp_mstl_dend,tmp_mpayment;

$char   icode[21],DBName1[3],iquota[7],ndply_begin[11],ndply_end[11];
$char   ipolicy[21],iendorse[21],ifpce_id[11],icorps[11],itag[CA_TAG_NUM];
$char   imain_ins[7],iins_type[7],nassured[31];
$char   fedr_class[2],fcard_class[2],tmp_fulldb[40];
$char   iclaim[21],ivictim[11],daccident[11],dappraisal[11];
$char   ireason[3],iins_item[7],irela_ply[21];
$char   facc_duty[2],fdmg_duty[2];
$char   icar_type[3],nuser[19],iofficer[11],nofficer[11],nabbr[9],pre_ply[21];
$char   DBName[05];
$char   userid[11];
$char   FormFmt[N_FILE+1], FormFile[N_FILE+1], iForm_Tp[03];
$int    pid;
$int    iins_grp,ply_cnt,qcount_tmp = 0;
$double mply_prem,qcount,mfull,qfull,madjcom_prem = 0.0,qcount1 = 0.0, mpure_prem = 0.0;
$double tmp_prem, mprem = 0.0, mins_app = 0.0, msettle = 0.0, mouts = 0.0, mloss;
$double tmp_mbgn_outstl,tmp_mend_outstl;
$double tmp_mstl;
$long   dcalc,dbgn,dend,dply_begin = 0,dply_end = 0,dori_begin,dori_end;
$long   leap_flag;

main(argc, argv)
int argc;
char **argv;
{
	int rc;

	batchinit();
	strcpy(DBName,         isNULLstr(argv[1]));
	strcpy(userid,         isNULLstr(argv[2]));
	strcpy(itype,          isNULLstr(argv[3]));  
	strcpy(icode,          isNULLstr(argv[4]));
	strcpy(ncode,          isNULLstr(argv[5]));
	strcpy(dbgn1,          isNULLstr(argv[6]));
	strcpy(dend1,          isNULLstr(argv[7]));
	strcpy(iquota,         isNULLstr(argv[8]));
	strcpy(iflag,          isNULLstr(argv[9]));
	/*outputf*/
	strcpy(outputf,        isNULLstr(argv[10]));
	
	strcpy(itype_2,itype);  /*�s�@���Ӫ��ɥ�itype_2�Aitype���ɤw�g�ܦ��ŭȡA�ϥΪ��ܷ|���C*/
printf("DBName[%s]\n",DBName);
printf("userid[%s]\n",userid);
printf("itype[%s]\n",itype);
printf("icode[%s]\n",icode);
printf("ncode[%s]\n",ncode);
printf("dbgn1[%s]\n",dbgn1);
printf("dend1[%s]\n",dend1);
printf("iquota[%s]\n",iquota);
printf("iflag[%s]\n",iflag);
printf("outputf[%s]\n",outputf);

/*�Ȧs��Ʒǳ�*/
	rc = car1004_prepare();
	if (rc != SUCCESS){
		return rc;
	}

/*�έp��*/
	rc = car1004A_build();
	if (rc != SUCCESS){
		return rc;
	}
	
/*���Ӫ�*/
	rc = car1004B_build();
	if (rc != SUCCESS){
		/*updatelog('F',pid);*/
		return rc;
	}
	/*updatelog('S',pid);*/
	
	return M_CM_OK;
}

int car1004_prepare()
{
	int     rtncode,len;
	$char   stmt[1024];

	dbgn = cm_ymd_cdate(dbgn1);
	dend = cm_ymd_cdate(dend1);
	dcalc = cm_today();
printf("dbgn[%d]dend[%d]dcalc[%d]\n",dbgn,dend,dcalc);
printf("iflag[%s]\n",iflag);

	if (db_select(DBName) == FALSE) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}

	$whenever sqlerror goto errexit;

	rtncode = create_temp_table();
	if (rtncode != SUCCESS){
		return rtncode;
	}

	len = strlen(trim(iquota));
	if (len==0){
		strcpy(cond," ");
	}
	else if (len==1 && iquota[0]=='*'){
		strcpy(cond," ");
	}
	else if (iquota[len-1]=='*'){
		sprintf_s(cond, sizeof cond,"and a.iquota matches '%s' ",iquota);
	}
	else {
		sprintf_s(cond, sizeof cond,"and a.iquota = '%s' ",iquota);
	}

	if (itype[0]=='3'){
		rtncode = car1004_query_1(); /* �j�O�� */
	}
	else{
		rtncode = car1004_query_2(); /* ¾��,����,�g��H,�q���N��,�n�O�H�νs */
	}
	  
	if (rtncode != SUCCESS){
		return rtncode;
	}
	
	return SUCCESS;
    
errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}

/*--------------------------------------------------------------------*/
/* create_temp_table : �إ߼Ȧs��                                     */
/*--------------------------------------------------------------------*/
int create_temp_table()
{
	$char	stmt[1024];
	int	    i,cnt;

	$whenever sqlerror goto errexit;
/*
	if ((fileptr = getFileName()) == NULL) {
		EWRITE(userid, M_CM_BAD_FILE_NAME, "M_CM_BAD_FILE_NAME");
		return M_CM_BAD_FILE_NAME;
	}

	strcpy(outputf,fileptr);
*/
	pid=atoi(outputf);
printf("�έp���Gpid[%d]outputf[%s]\n",pid,outputf);
	strcpy(outputf_ix,outputf);
	strcat(outputf_ix,"_ix");
	strcpy(outputf1,outputf);
	strcat(outputf1,"_1");

	sprintf_s(stmt, sizeof stmt,
		" create temp table car%s "
		" (ipolicy char(20), iendorse char(20), "
		" fcard_class char(01), irela_ply char(20), ifpce_id char(10), "
		" nassured char(30), icorps char(10), itag char(%d), "
		" dply_begin date, dply_end date, iins_grp integer, "
		" iins_type char(06), mply_prem integer, qcount integer, "
		" mfull decimal(17,6), qfull decimal(15,6), dori_begin date, "
		" dori_end date, icar_type char(2), nuser char(18), "
		" iofficer char(10), nofficer char(10)) with no log; ", outputf, CA_TAG_NUM-1);
printf("stmt[%s]\n",stmt);
	$prepare pre_tbl from $stmt;
	$execute pre_tbl;

	sprintf_s(stmt, sizeof stmt,"create index car%s on car%s (ipolicy);",outputf_ix,outputf);

	$prepare pre_idx from $stmt;
	$execute pre_idx;

	sprintf_s(stmt, sizeof stmt,
		" create temp table car%s (ipolicy char(20), "
								" iclaim char(20), daccident date, iins_grp integer, "
								" iins_type char(06), ireason char(02), mouts decimal(17,6), "
								" msettle decimal(17,6), facc_duty char(2), fdmg_duty char(2)) with no log; ", outputf1);

	$prepare pre_tbl1 from $stmt;
	$execute pre_tbl1;

	return SUCCESS;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}

/*--------------------------------------------------------------------*/
/* car1004_query_1 : �j�O��l�v                                       */
/*--------------------------------------------------------------------*/
int car1004_query_1()
{
	$char   stmt[1024],stmt1[512],stmt2[512];
	int     rtncode;

	$whenever sqlerror goto errexit;

	strcpy(DBName1,substring(icode,1,2));
	strcpy(tmp_fulldb,get_car_full_db(icode));

	/* �O�� */
	sprintf_s(stmt, sizeof stmt,
			"select a.ipolicy,b.iassured,a.icorps,b.itag, "
				  " a.dply_begin,a.dply_end,d.imain_ins,c.iins_type, "
				  " c.mins_premium,a.madjcom_prem,a.fcard_class, "
				  " e.irelative_ply,b.nassured[1,30],c.mpure_prem, "
				  " a.icar_type,b.nuser,a.iofficer, "
				  " (select nname from officer where iofficer = a.iofficer) "
			 " from %s:ori_ply_relation a,%s:original_ply b, "
				  " %s:ori_ins_type c,insurance_type d, "
				  " %s:ply_relation e "
		    " where a.ipolicy[1,13] = ? "
			  " and a.dply_begin >= ? and a.dply_begin <= ? %s "
			  " and a.ipolicy = b.ipolicy "
			  " and a.ipolicy = e.ipolicy "
			  " and a.ipolicy = c.ipolicy "
			  " and c.iins_type = d.iins_type ", tmp_fulldb, tmp_fulldb, tmp_fulldb, tmp_fulldb, cond);

printf("[%s]\n",stmt);
	$prepare pre_11 from $stmt;
	$declare cur_11 cursor for pre_11;
	$open cur_11 using $icode, $dbgn, $dend;
	strcpy(iendorse," ");
	while(1)
	{
		$fetch cur_11
		  into $ipolicy,$ifpce_id,$icorps,$itag,$dply_begin,
			   $dply_end,$imain_ins,$iins_type,$mply_prem,
			   $madjcom_prem,$fcard_class,$irela_ply,$nassured,$mpure_prem,
			   $icar_type,$nuser,$iofficer,$nofficer;
		if (SQLCODE==SQLNOTFOUND) {
			break;
		}
printf("ipolicy[%s]\n",ipolicy);
		dori_begin = dply_begin;
		dori_end = dply_end;

		if (iflag[0] == '0')
		{
			if (mpure_prem != 0)
			{
				mply_prem = mpure_prem;
			}
			else
			{
				mply_prem = 0;
			}
		}

		if (strcmp(trim(iins_type),"21")==0)
		{
			if(madjcom_prem > 0 || madjcom_prem < 0)
			{
				tmp_prem = madjcom_prem;
			}
			else
			{
				tmp_prem = 0;
			}
		}
		else
		{
			if(mply_prem > 0 || mply_prem < 0)
			{
				tmp_prem = mply_prem;
			}
			else
			{
				tmp_prem = 0;
			}
		}
		qcount = 1;
		/*mfull = 0.0;*/
		qfull = 0.0;
		leap_flag = check_leap_year(dply_begin, dply_end);
		rtncode = ca_calc_365_full(dbgn, dcalc, dply_begin, dply_end, tmp_prem, qcount, &mfull, &qfull, leap_flag);
		
printf("mfull[%f]qfull[%f]\n",mfull,qfull);
		if (rtncode != SUCCESS){
			return rtncode;
		}
		 
		check_ins_grp();
		rtncode = insert_car1004();
		if (rtncode != SUCCESS){
			return rtncode;
		}
	}
	$close cur_11;
	$free  cur_11;
	/* ��� */  
	sprintf_s(stmt, sizeof stmt,
			"select a.ipolicy,a.iendorse,b.iassured,a.icorps,b.itag, "
				  " a.dedr_begin,a.dedr_end,d.imain_ins,c.iins_type, "
				  " c.medrins_prem,a.medr_adjcom,a.fedr_class,a.fcard_class, "
				  " a.irelative_ply,b.nassured[1,30],b.dply_begin,b.dply_end,c.medrpure_prem, "
				  " a.qcount,a.icar_type,b.nuser,a.iofficer, "
				  " (select nname from officer where iofficer = a.iofficer) "
			 " from %s:edr_relation a,%s:endorsement b, "
				  " %s:edr_ins_type c,insurance_type d "
		    " where a.ipolicy[1,13] = ? "
			  " and a.dedr_close is not null %s "
			  " and a.iendorse = b.iendorse "
			  " and b.dply_begin >= ? and b.dply_begin <= ? "
			  " and a.iendorse = c.iendorse "
			  " and c.iins_type = d.iins_type ", tmp_fulldb, tmp_fulldb, tmp_fulldb, cond);
printf("[%s]\n",stmt);
	$prepare pre_12 from $stmt;
	$declare cur_12 cursor for pre_12;
	$open cur_12 using $icode, $dbgn, $dend;
	while(1)
	{
		$fetch cur_12
		  into $ipolicy,$iendorse,$ifpce_id,$icorps,$itag,$dply_begin,
			   $dply_end,$imain_ins,$iins_type,$mply_prem,
			   $madjcom_prem,$fedr_class,$fcard_class,$irela_ply,
			   $nassured,$dori_begin,$dori_end,$mpure_prem,$qcount_tmp,
			   $icar_type,$nuser,$iofficer,$nofficer;
		if (SQLCODE==SQLNOTFOUND) {
			break;
		}
printf("iendorse[%s]\n",iendorse);

		if (iflag[0] == '0'){
			mply_prem = mpure_prem;
		}

		if (strcmp(trim(iins_type),"21")==0)
		{
			if (madjcom_prem > 0 || madjcom_prem < 0)
			{
				tmp_prem = madjcom_prem;
			}
			else
			{
				tmp_prem = 0;
			}
		}
		else
		{
			if (mply_prem > 0 || mply_prem < 0)
			{
				tmp_prem = mply_prem;
			}
			else
			{
				tmp_prem = 0;
			}
		}
		
		qcount = qcount_tmp;
		/*mfull = 0.0;*/
		qfull = 0.0;
		leap_flag = check_leap_year(dply_begin, dply_end);
		rtncode = ca_calc_365_full(dbgn, dcalc, dply_begin, dply_end, tmp_prem, qcount, &mfull, &qfull, leap_flag);
		if (rtncode != SUCCESS){
			return rtncode;
		}

		check_ins_grp();
		rtncode = insert_car1004();
		if (rtncode != SUCCESS){
			return rtncode;
		}
	}
	$close cur_12;
	$free  cur_12;
	/* ���p�O�� */
	sprintf_s(stmt, sizeof stmt,
			"select a.ipolicy,b.iassured,a.icorps,b.itag, "
				  " a.dply_begin,a.dply_end,d.imain_ins,c.iins_type, "
				  " c.mins_premium,a.madjcom_prem,a.fcard_class, "
				  " e.irelative_ply,b.nassured[1,30],c.mpure_prem, "
				  " a.icar_type,b.nuser,a.iofficer, "
				  " (select nname from officer where iofficer = a.iofficer) "
			 " from %s:ori_ply_relation a,%s:original_ply b, "
				  " %s:ori_ins_type c,insurance_type d, "
				  " %s:ply_relation e "
		    " where a.irelative_ply[1,13] = ? "
			  " and a.dply_begin >= ? and a.dply_begin <= ? %s "
			  " and a.ipolicy = b.ipolicy "
			  " and a.ipolicy = e.ipolicy "
			  " and a.ipolicy = c.ipolicy "
			  " and c.iins_type = d.iins_type ", tmp_fulldb, tmp_fulldb, tmp_fulldb, tmp_fulldb, cond);

printf("[%s]\n",stmt);
	$prepare pre_13 from $stmt;
	$declare cur_13 cursor for pre_13;
	$open cur_13 using $icode, $dbgn, $dend;
	strcpy(iendorse," ");
	while(1)
	{
		$fetch cur_13
		  into $ipolicy,$ifpce_id,$icorps,$itag,$dply_begin,
			   $dply_end,$imain_ins,$iins_type,$mply_prem,
			   $madjcom_prem,$fcard_class,$irela_ply,$nassured,$mpure_prem,
			   $icar_type,$nuser,$iofficer,$nofficer;
		if (SQLCODE==SQLNOTFOUND){
			break;
		}
printf("ipolicy[%s]\n",ipolicy);
		dori_begin = dply_begin;
		dori_end = dply_end;

		if (iflag[0] == '0'){
			mply_prem = mpure_prem;
		}

		if (strcmp(trim(iins_type),"21")==0)
		{
			if (madjcom_prem > 0 || madjcom_prem < 0)
			{
				tmp_prem = madjcom_prem;
			}
			else
			{
				tmp_prem = 0;
			}
		}
		else
		{
			if (mply_prem > 0 || mply_prem < 0)
			{
				tmp_prem = mply_prem;
			}
			else
			{
				tmp_prem = 0;
			}
		}
	  
		qcount = 1;
		/*mfull = 0.0;*/
		qfull = 0.0;
		leap_flag = check_leap_year(dply_begin, dply_end);
		rtncode = ca_calc_365_full(dbgn, dcalc, dply_begin, dply_end, tmp_prem, qcount, &mfull, &qfull, leap_flag);
		if (rtncode != SUCCESS){
			return rtncode;
		}

		check_ins_grp();
		rtncode = insert_car1004();
		if (rtncode != SUCCESS){
			return rtncode;
		}
	}
	$close cur_13;
	$free  cur_13;
	/* ���p��� */  
	sprintf_s(stmt, sizeof stmt,
			"select a.ipolicy,a.iendorse,b.iassured,a.icorps,b.itag, "
				  " a.dedr_begin,a.dedr_end,d.imain_ins,c.iins_type, "
				  " c.medrins_prem,a.medr_adjcom,a.fedr_class,a.fcard_class, "
				  " a.irelative_ply,b.nassured[1,30],b.dply_begin,b.dply_end,c.medrpure_prem, "
				  " a.qcount,a.icar_type,b.nuser,a.iofficer, "
				  " (select nname from officer where iofficer = a.iofficer) "
			 " from %s:edr_relation a,%s:endorsement b, "
				  " %s:edr_ins_type c,insurance_type d "
		    " where a.irelative_ply[1,13] = ? "
			  " and a.dedr_close is not null %s "
			  " and b.dply_begin >= ? and b.dply_begin <= ? "
			  " and a.iendorse = b.iendorse "
			  " and a.iendorse = c.iendorse "
			  " and c.iins_type = d.iins_type ", tmp_fulldb, tmp_fulldb, tmp_fulldb, cond);

printf("[%s]\n",stmt);
	$prepare pre_14 from $stmt;
	$declare cur_14 cursor for pre_14;
	$open cur_14 using $icode, $dbgn, $dend;
	while(1)
	{
		$fetch cur_14
		  into $ipolicy,$iendorse,$ifpce_id,$icorps,$itag,$dply_begin,
			   $dply_end,$imain_ins,$iins_type,$mply_prem,
			   $madjcom_prem,$fedr_class,$fcard_class,$irela_ply,
			   $nassured,$dori_begin,$dori_end,$mpure_prem,$qcount_tmp,
			   $icar_type,$nuser,$iofficer,$nofficer;
		if (SQLCODE==SQLNOTFOUND){
			break;
		}
printf("iendorse[%s]\n",iendorse);

		if (iflag[0] == '0'){
			mply_prem = mpure_prem;
		}

		if (strcmp(trim(iins_type),"21")==0)
		{
			if (madjcom_prem != 0){
				tmp_prem = madjcom_prem;
			}
			else{
				tmp_prem = 0;
			}
		}
		else
		{
			if (mply_prem != 0){
				tmp_prem = mply_prem;
			}
			else{
				tmp_prem = 0;
			}
		}

		qcount = qcount_tmp;
		/*mfull=0.0;*/
		qfull=0.0;
		leap_flag = check_leap_year(dply_begin, dply_end);
		rtncode = ca_calc_365_full(dbgn, dcalc, dply_begin, dply_end, tmp_prem, qcount, &mfull, &qfull, leap_flag);
		if (rtncode != SUCCESS){
			return rtncode;
		}

		check_ins_grp();
		rtncode = insert_car1004();
		if (rtncode != SUCCESS){
			return rtncode;
		}
	}
	$close cur_14;
	$free  cur_14;
	/* �z�� */
	sprintf_s(stmt, sizeof stmt,"select distinct ipolicy,fcard_class from car%s;",outputf);

	$prepare pre_15 from $stmt;
	$declare cur_15 cursor for pre_15;
	$open cur_15;
	while(1)
	{
		$fetch cur_15
		  into $ipolicy,$fcard_class;
		if (SQLCODE==SQLNOTFOUND) {
			break;
		}
		if (fcard_class[0]=='1'){
			rtncode=car1004_claim_c();
		}
		else{
			rtncode=car1004_claim_v();
		}
		 
		if (rtncode != SUCCESS){
			return rtncode;
		}
	}
	$close cur_15;
	$free  cur_15;
		 
	return SUCCESS;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}

/*--------------------------------------------------------------------*/
/* car1004_query_2 : ¾��,����,�g��H,�q���N��,�n�O�H�νs�d��             */
/*--------------------------------------------------------------------*/
int car1004_query_2()
{
	$char   stmt[1024],stmt1[81],stmt2[512];
	int     rtncode,k,count_db;
	DBinfo  *list;

	if ((list=get_db_list(&count_db,DBName)) == (char*)0){
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE){
			return M_CM_NOT_DBLIST;
		}
	}
	
	if (itype[0]=='1'){
		sprintf_s(stmt1, sizeof stmt1,"a.icorps = '%s' ",trim(icode));
	}
	else if (itype[0]=='2'){
		sprintf_s(stmt1, sizeof stmt1,"b.iassured = '%s' ",trim(icode));
	}
	else if (itype[0]=='4'){
		sprintf_s(stmt1, sizeof stmt1,"a.iofficer = '%s' ",trim(icode));
	}
	else if (itype[0]=='5'){
		sprintf_s(stmt1, sizeof stmt1,"b.iroute = '%s' ",trim(icode));
	}
	else if (itype[0]=='6'){
		sprintf_s(stmt1, sizeof stmt1,"b.iapplicant = '%s' ",trim(icode));
	}
	  
	for(k=0;k<count_db;k++) {
		/* �O�� */  
		sprintf_s(stmt, sizeof stmt,
				"select a.ipolicy,b.iassured,a.icorps,b.itag, "
					  " a.dply_begin,a.dply_end,d.imain_ins,c.iins_type, "
					  " c.mins_premium,a.madjcom_prem,a.fcard_class, "
					  " e.irelative_ply,b.nassured[1,30],c.mpure_prem, "
					  " a.icar_type,b.nuser,a.iofficer, "
					  " (select nname from officer where iofficer = a.iofficer) "
			     " from %s:ori_ply_relation a,%s:original_ply b, "
					  " %s:ori_ins_type c,insurance_type d, "
					  " %s:ply_relation e "
			    " where %s %s "
				  " and a.dply_begin >= ? and a.dply_begin <= ? "
				  " and a.ipolicy = b.ipolicy "
				  " and a.ipolicy = e.ipolicy "
				  " and a.ipolicy = c.ipolicy "
				  " and c.iins_type = d.iins_type ",
				list[k].dbname, list[k].dbname, list[k].dbname, list[k].dbname, stmt1, cond);

printf("[%s]\n",stmt);
		$prepare pre_51 from $stmt;
		$declare cur_51 cursor for pre_51;
		$open cur_51 using $dbgn, $dend;
		strcpy(iendorse," ");
		while(1) {
			$fetch cur_51
			  into $ipolicy,$ifpce_id,$icorps,$itag,$dply_begin,
				   $dply_end,$imain_ins,$iins_type,$mply_prem,
				   $madjcom_prem,$fcard_class,$irela_ply,$nassured,$mpure_prem,
				   $icar_type,$nuser,$iofficer,$nofficer;
			if (SQLCODE==SQLNOTFOUND){
				break;
			}
printf("ipolicy[%s]\n",ipolicy);
			dori_begin=dply_begin;
			dori_end=dply_end;

			if (iflag[0] == '0'){
				mply_prem = mpure_prem;
			}
			
			if (strcmp(trim(iins_type),"21")==0)
			{
				if (madjcom_prem != 0){
					tmp_prem = madjcom_prem;
				}
				else{
					tmp_prem = 0;
				}
			}
			else
			{
				if (mply_prem != 0){
					tmp_prem = mply_prem;
				}
				else{
					tmp_prem = 0;
				}
			}
			qcount=1;
			/*mfull=0.0;*/
			qfull=0.0;
			leap_flag = check_leap_year(dply_begin, dply_end);
			rtncode = ca_calc_365_full(dbgn, dcalc, dply_begin, dply_end, tmp_prem, qcount, &mfull, &qfull, leap_flag);
printf("mfull[%f]qfull[%f]\n",mfull,qfull);
			if (rtncode != SUCCESS){
				return rtncode;
			}
			
			check_ins_grp();
			rtncode = insert_car1004();
			if (rtncode != SUCCESS){
				return rtncode;
			}
		}
		$close cur_51;
		$free  cur_51;
		/* ��� */  
		sprintf_s(stmt, sizeof stmt,
				"select a.ipolicy,a.iendorse,b.iassured,a.icorps,b.itag, "
					  " a.dedr_begin,a.dedr_end,d.imain_ins,c.iins_type, "
					  " c.medrins_prem,a.medr_adjcom,a.fedr_class,a.fcard_class, "
					  " a.irelative_ply,b.nassured[1,30],b.dply_begin,b.dply_end,c.medrpure_prem, "
					  " a.qcount,a.icar_type,b.nuser,a.iofficer, "
					  " (select nname from officer where iofficer = a.iofficer) "
			     " from %s:edr_relation a,%s:endorsement b, "
					  " %s:edr_ins_type c,insurance_type d "
			    " where %s %s "
				  " and a.dedr_close is not null "
				  " and a.iendorse = b.iendorse "
				  " and b.dply_begin >= ? and b.dply_begin <= ? "
				  " and a.iendorse = c.iendorse "
				  " and c.iins_type = d.iins_type ",
				list[k].dbname, list[k].dbname, list[k].dbname, stmt1, cond);
printf("[%s]\n",stmt);
		$prepare pre_52 from $stmt;
		$declare cur_52 cursor for pre_52;
		$open cur_52 using $dbgn, $dend;
		while(1) {
			$fetch cur_52
			  into $ipolicy,$iendorse,$ifpce_id,$icorps,$itag,$dply_begin,
				   $dply_end,$imain_ins,$iins_type,$mply_prem,
				   $madjcom_prem,$fedr_class,$fcard_class,$irela_ply,
				   $nassured,$dori_begin,$dori_end,$mpure_prem,$qcount_tmp,
				   $icar_type,$nuser,$iofficer,$nofficer;
			if (SQLCODE==SQLNOTFOUND){
				break;
			}
printf("iendorse[%s]\n",iendorse);

			if (iflag[0] == '0'){
				mply_prem = mpure_prem;
			}
			

			if (strcmp(trim(iins_type),"21")==0){
				tmp_prem = madjcom_prem;
			}
			else{
				tmp_prem = mply_prem;
			}
			
			qcount = qcount_tmp;
			/*mfull = 0.0;*/
			qfull = 0.0;
			leap_flag = check_leap_year(dply_begin, dply_end);
			rtncode = ca_calc_365_full(dbgn, dcalc, dply_begin, dply_end, tmp_prem, qcount, &mfull, &qfull, leap_flag);
printf("mfull[%f]qfull[%f]\n",mfull,qfull);
			if (rtncode != SUCCESS){
				return rtncode;
			}
			
			check_ins_grp();
			rtncode = insert_car1004();
			if (rtncode != SUCCESS){
				return rtncode;
			}
		}
		$close cur_52;
		$free  cur_52;
	}
	/* �z�� */
	sprintf_s(stmt, sizeof stmt,"select distinct ipolicy,fcard_class from car%s;",outputf);
printf("�z��[%s]\n",stmt);
	$prepare pre_55 from $stmt;
	$declare cur_55 cursor for pre_55;
	$open cur_55;
	while(1) {
		$fetch cur_55
		  into $ipolicy,$fcard_class;
		if (SQLCODE==SQLNOTFOUND){
			break;
		}
printf("ipolicy[%s]fcard_class[%s]\n",ipolicy,fcard_class);
		strcpy(DBName1,substring(ipolicy,1,2));
		strcpy(tmp_fulldb,get_car_full_db(ipolicy));
		if (fcard_class[0]=='1'){
			rtncode=car1004_claim_c();
		}
		else{
			rtncode=car1004_claim_v();
		}
		
		if (rtncode != SUCCESS){
			return rtncode;
		}
	}
	$close cur_55;
	$free  cur_55;

	return SUCCESS;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
/*--------------------------------------------------------------------*/
/* car1004A_build : �s�@�έp��                                        */
/*--------------------------------------------------------------------*/
int car1004A_build()
{
	int     i, rtncode;
	long    d_cnt[5];
	double  d_mprem[5],d_mfull[5],d_mloss[5];
	char    c_cnt[7],c_mprem[13],c_mfull[13],c_mloss[13],pratio[20];
	char    pre_ply[21];
	$char   stmt[512],stmt1[512],stmt2[512];
 
	$whenever sqlerror goto errexit;

	for(i=0;i<5;i++){
		d_cnt[i]=d_mprem[i]=d_mfull[i]=d_mloss[i]=0;
	}
	ply_cnt=0;

	sprintf_s(stmt, sizeof stmt,
			"select ipolicy,sum(qcount) from car%s "
			" where fcard_class = '1' group by 1;",outputf);
	$prepare pre_43 from $stmt;
	$declare cur_43 cursor for pre_43;
	$open cur_43;
	while(1) { 
		$fetch cur_43
		  into $ipolicy,$qcount;
		if (SQLCODE==SQLNOTFOUND){
			break;
		}
		if (qcount>0) {
			ply_cnt++;
			d_cnt[4]++;
		}
		sprintf_s(stmt1, sizeof stmt1,
				"select sum(mply_prem),sum(mfull) "
					  " from car%s where ipolicy = ?;",outputf);
		$prepare pre_44 from $stmt1;
		$declare cur_44 cursor for pre_44;
		$open cur_44 using $ipolicy;
		while(1) {
			$fetch cur_44
			  into $mply_prem,$mfull;
			if (SQLCODE==SQLNOTFOUND){
				break;
			}
			d_mprem[4] += mply_prem;
			d_mfull[4] += mfull;
			sprintf_s(stmt2, sizeof stmt2,
					"select nvl(sum(mouts),0),nvl(sum(msettle),0) "
					 " from car%s where ipolicy = ?;",outputf1);
			$prepare pre_441 from $stmt2;
			$declare cur_441 cursor for pre_441;
			$open cur_441 using $ipolicy;
			$fetch cur_441 into $mouts,$msettle;
			
			d_mloss[4] += (mouts + msettle);
			$close cur_441;
			$free  cur_441;
		}
		$close cur_44;
		$free  cur_44;
	}
	$close cur_43;
	$free  cur_43;

printf("ply_cnt[%d]\n",ply_cnt);
	sprintf_s(stmt, sizeof stmt,
			"select distinct ipolicy,irela_ply from car%s "
			" where fcard_class = '2' order by 1",outputf);
	$prepare pre_41 from $stmt;
	$declare cur_41 cursor for pre_41;
	$open cur_41;
	strcpy(pre_ply," ");
	while(1) { 
		$fetch cur_41 into $ipolicy,$irela_ply;
		if (SQLCODE==SQLNOTFOUND){
			break;
		}
		if (strncmp(pre_ply,ipolicy,20)==0){
			continue;
		}
		strcpy(pre_ply,ipolicy);
		sprintf_s(stmt1, sizeof stmt1,
				"select nvl(sum(qcount),0) from car%s "
				" where ipolicy = ?;",outputf);
		$prepare pre_411 from $stmt1;
		$declare cur_411 cursor for pre_411;
		$open  cur_411 using $irela_ply;
		$fetch cur_411 into $qcount1;
		$close cur_411;
		$free cur_411;
		sprintf_s(stmt1, sizeof stmt1,
				"select sum(qcount) from car%s "
				" where ipolicy = ?;",outputf);
		$prepare pre_412 from $stmt1;
		$declare cur_412 cursor for pre_412;
		$open  cur_412 using $ipolicy;
		$fetch cur_412 into $qcount;
		if (qcount1==0 && qcount > 0) {
			ply_cnt++;
printf("ply_cnt[%d]ipolicy[%s]irela_ply[%s]\n",ply_cnt,ipolicy,irela_ply);
		}
		if (qcount>0){
			d_cnt[3]++;
		}

		$close cur_412;
		$free cur_412;
		sprintf_s(stmt1, sizeof stmt1,"select iins_grp,sum(qcount),sum(mply_prem),sum(mfull) "
					  " from car%s where ipolicy = ? group by 1;",outputf);
		$prepare pre_42 from $stmt1;
		$declare cur_42 cursor for pre_42;
		$open cur_42 using $ipolicy;
		while(1) {
			$fetch cur_42 into $iins_grp,$qcount,$mply_prem,$mfull;
			if (SQLCODE==SQLNOTFOUND){
				break;
			}
			i = iins_grp - 1;
			if (qcount > 0){
				d_cnt[i]++;
			}
			d_mprem[i] += mply_prem;
			d_mfull[i] += mfull;
			sprintf_s(stmt2, sizeof stmt2,
					"select nvl(sum(mouts),0),nvl(sum(msettle),0) "
					 " from car%s where ipolicy = ? "
					  " and iins_grp = ? ;",outputf1);
			$prepare pre_421 from $stmt2;
			$declare cur_421 cursor for pre_421;
			$open  cur_421 using $ipolicy,$iins_grp;
			$fetch cur_421 into $mouts,$msettle;
printf("ipolicy[%s]mouts[%f]msettle[%f]\n",ipolicy,mouts,msettle);
			d_mloss[i] += (mouts + msettle);
			$close cur_421;
			$free  cur_421;
		}
		$close cur_42;
		$free  cur_42;
	}
	$close cur_41;
	$free  cur_41;
	for(i=0;i<3;i++) {
		d_mprem[3] += d_mprem[i];
		d_mfull[3] += d_mfull[i];
		d_mloss[3] += d_mloss[i];
	}
	
	if(ply_cnt == 0){
		EWRITE(userid,M_CM_NOT_FOUND,"�ӫO���ơG0");
		return M_CM_NOT_FOUND;
	}

	/*�}�l�s�@�έp��*/
	$select nform_file, iForm_Tp
       into $FormFmt, $iForm_Tp
       from Form
      where ksys_grp = "CA" AND kPgmID = 1004 AND iform_tp = '1';

	strcpy(FormFmt, rtrim(FormFmt));
	sprintf_s(FormFile, sizeof FormFile, "%sA.tx", outputf);
printf("fmt[%s]file[%s]\n",FormFmt,FormFile);

	max_cnt=0;
	rgu_init_report(FormFmt,FormFile);
	
	if (itype[0]=='1'){
		rgu_put_body_string(1, "¾�ΦW��", 1);
		rgu_put_body_string(1, icode, 1);
		rgu_put_body_string(1, ncode, 1);
	}
	else if (itype[0]=='2'){
		rgu_put_body_string(1, "�Q�O�I�H", 1);
		rgu_put_body_string(1, icode, 1);
		rgu_put_body_string(1, ncode, 1);
	}
	else if (itype[0]=='3'){
		rgu_put_body_string(1, " ", 1);
		rgu_put_body_string(1, " ", 1);
		rgu_put_body_string(1, " ", 1);
	}
	else if (itype[0]=='4'){
		rgu_put_body_string(1, "�g �� �H", 1);
		rgu_put_body_string(1, icode, 1);
		rgu_put_body_string(1, ncode, 1);
	}
	else if (itype[0]=='5'){
		rgu_put_body_string(1, "�q���W��", 1);
		rgu_put_body_string(1, icode, 1);
		rgu_put_body_string(1, ncode, 1);
	}
	else if (itype[0]=='6'){
		rgu_put_body_string(1, "�n�O�H�W��", 1);
		rgu_put_body_string(1, icode, 1);
		rgu_put_body_string(1, ncode, 1);
	}
	rgu_put_body(1);
	max_cnt ++;
	
	if (itype[0]=='1'){
		rgu_put_body_string(2, " ", 1);
	}
	else if (itype[0]=='2'){
		rgu_put_body_string(2, " ", 1);
	}
	else if (itype[0]=='3'){
		rgu_put_body_string(2, icode, 1);  /*�O�渹�X*/
	}
	else if (itype[0]=='4'){
		rgu_put_body_string(2, " ", 1);
	}
	else if (itype[0]=='5'){
		rgu_put_body_string(2, " ", 1);
	}
	else if (itype[0]=='6'){
		rgu_put_body_string(2, " ", 1);
	}
	rgu_put_body_string(2, dbgn1, 1);
	rgu_put_body_string(2, dend1, 1);
	rgu_put_body(2);
	max_cnt ++;
	
	sprintf_s(nply_cnt, sizeof nply_cnt, "%d", ply_cnt);
	rgu_put_body_string(3, nply_cnt, 1);
	rgu_put_body(3);
	max_cnt ++;
	
	if (iflag[0] == '1'){
		rgu_put_body(4);
	}
	else{
		rgu_put_body(5);
	}
    max_cnt ++;
	
	for(i=0;i<5;i++){
		rfmtlong(d_cnt[i],"---,--&",c_cnt);
		rfmtdouble(d_mprem[i],"-,---,---,--&",c_mprem);
		rfmtdouble(d_mfull[i],"-,---,---,--&",c_mfull);
		rfmtdouble(d_mloss[i],"-,---,---,--&",c_mloss);
printf("c_cnt[%s], c_mprem[%s], c_mfull[%s], c_mloss[%s]\n", c_cnt, c_mprem, c_mfull, c_mloss);
		
		rgu_put_body_string(i+6, c_cnt, 1);
		rgu_put_body_string(i+6, c_mprem, 1);
		rgu_put_body_string(i+6, c_mfull, 1);
		rgu_put_body_string(i+6, c_mloss, 1);
		
		if (d_mfull[i] == 0){
			strcpy(pratio,"0.00");
		}
		else{
			rfmtdouble(d_mloss[i]/d_mfull[i]*100,"---,---.&&",pratio);
		}
printf("pratio[%s]\n", pratio);
		
		rgu_put_body_string(i+6, pratio, 1);
		rgu_put_body(i+6);
		max_cnt ++;
	}
	
	rgu_finish_report();
	/*�����s�@�έp��*/
	
	if((rtncode=save_form_info(F_FREE, "CA", 1004, userid, iForm_Tp, max_cnt, outputf))<0) {
printf("car1004A.fmt save_form_info failed\n");
		return rtncode;
	}
printf("car1004A.fmt save_form_info SUCCESS\n");
	return SUCCESS;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}

/*--------------------------------------------------------------------*/
/* car1004B_build : �s�@���Ӫ�                                        */
/*--------------------------------------------------------------------*/
int car1004B_build()
{
	int     rtncode;
	char    curtime[17];
	char    pre_fcard[2];
	$char   stmt[2048],stmt1[2048],ireason_tmp[4];
	
	$whenever sqlerror goto errexit;
	/*
	if ((fileptr = getFileName()) == NULL) {
		EWRITE(userid, M_CM_BAD_FILE_NAME, "M_CM_BAD_FILE_NAME");
		return M_CM_BAD_FILE_NAME;
	}
	strcpy(outputf,fileptr);
	pid=atoi(outputf);
	
	rtncode = insert_gb();
	if (rtncode!=SUCCESS){
		return rtncode;
	}
	*/
	
printf("���Ӫ��Gpid[%d]outputf[%s]\n",pid,outputf);

	/*�}�l�s�@���Ӫ�*/
	$select nform_file, iForm_Tp
       into $FormFmt, $iForm_Tp
       from Form
      where ksys_grp = "CA" AND kPgmID = 1004 AND iform_tp = '2';

	strcpy(FormFmt, rtrim(FormFmt));
	sprintf_s(FormFile, sizeof FormFile, "%sB.tx", outputf);
printf("fmt[%s]file[%s]\n",FormFmt,FormFile);
	
	max_cnt = 0;
	rgu_init_report(FormFmt,FormFile);

strcpy(curtime,cm_get_sysd());
printf("itype_2[0][%s], dbgn1[%s], dend1[%s], curtime[%s], icode[%s] , ncode[%s]\n", itype_2[0], dbgn1, dend1, curtime, icode, ncode);
	if (itype_2[0]=='1') {
       rgu_put_body_string(1, "¾��", 2);
	}
	else if (itype_2[0]=='2') {
	   rgu_put_body_string(1, "����", 2);
	}
	else if (itype_2[0]=='3') {
	   rgu_put_body_string(1, "�j�O��", 2);
	}
	else if (itype_2[0]=='4') {
	   rgu_put_body_string(1, "�g��H", 2);
	}
	else if (itype_2[0]=='5') {
	   rgu_put_body_string(1, "�q���N��", 2);
	}
	else if (itype_2[0]=='6') {
	   rgu_put_body_string(1, "�n�O�H�νs", 2);
	}
	rgu_put_body_string(1, dbgn1, 1);
	rgu_put_body_string(1, dend1, 1);
	rgu_put_body_string(1, cm_get_sysd(), 1);
	rgu_put_body(1);
	max_cnt ++;
	
	rgu_put_body_string(2, nply_cnt, 1);
	if (itype_2[0]=='1') {
       rgu_put_body_string(2, "¾�ΦW�١G", 1);
       rgu_put_body_string(2, icode, 1);
       rgu_put_body_string(2, ncode, 1);
	}
	else if (itype_2[0]=='2') {
	   rgu_put_body_string(2, "�Q�O�I�H�G", 1);
	   rgu_put_body_string(2, icode, 1);
	   rgu_put_body_string(2, ncode, 1);
	}
	else if (itype_2[0]=='3') {
	   rgu_put_body_string(2, " ", 1);
	   rgu_put_body_string(2, " ", 1);
	   rgu_put_body_string(2, " ", 1);
	}
	else if (itype_2[0]=='4') {
	   rgu_put_body_string(2, "�g �� �H�G", 1);
	   rgu_put_body_string(2, icode, 1);
	   rgu_put_body_string(2, ncode, 1);
	}
	else if (itype_2[0]=='5') {
	   rgu_put_body_string(2, "�q���W�١G", 1);
	   rgu_put_body_string(2, icode, 1);
	   rgu_put_body_string(2, ncode, 1);
	}
	else if (itype_2[0]=='6') {
	   rgu_put_body_string(2, "�n�O�H�W�١G", 1);
	   rgu_put_body_string(2, icode, 1);
	   rgu_put_body_string(2, ncode, 1);
	}
	rgu_put_body(2);
	max_cnt ++;

	if (iflag[0] == '1'){
		rgu_put_body(3);
	}
	else{
		rgu_put_body(5);
	}
	max_cnt ++;
	
	mouts_1 = msettle_1 = mloss=0;
	sub_mprem = sub_mouts = sub_msettle = sub_mloss = 0;
	tot_mprem = tot_mouts = tot_msettle = tot_mloss = 0;
	sprintf_s(stmt, sizeof stmt,"select fcard_class,ipolicy,ifpce_id,nassured,itag,icar_type,nuser, "
									  " dori_begin,dori_end,iofficer,nofficer, "
									  " sum(mply_prem),sum(mfull) "
								 " from car%s group by 1,2,3,4,5,6,7,8,9,10,11 order by 1,2;",
								outputf);
	printf("stmt[%s]\n",stmt);
	$prepare pre_1 from $stmt;
	$declare cursor1 cursor for pre_1;
	$open  cursor1;
	$fetch cursor1
	  into $fcard_class,$ipolicy,$ifpce_id,$nassured,$itag,$icar_type,$nuser,
		   $ndply_begin,$ndply_end,$iofficer,$nofficer,$mprem,$mfull;
	strcpy(pre_fcard,fcard_class);
	strcpy(pre_ply," ");
	while(1) {
		printf("ipolicy[%s]\n",ipolicy);
		if (pre_fcard[0]!=fcard_class[0])
		{
			car1004_print_sub();
		}
		
		printf("INTO end print sub\n");
		if (SQLCODE == SQLNOTFOUND){
			break;
		}
		
		printf("before car1004_print\n");
		car1004_print();
		printf("after car1004_print\n");
		
		if (strncmp(pre_ply,ipolicy,20)==0) {
			printf("before car1004_print2\n");
			car1004_print2();
			printf("after car1004_print2\n");
			
			goto read_next;
		}
		sprintf_s(stmt1, sizeof stmt1,"select iclaim,daccident,facc_duty,fdmg_duty,(select iins_ply from "
											" insurance_type b where b.iins_type = a.iins_type), "
											" ireason, nabbr,sum(mouts),sum(msettle) "
									   " from car%s a, outer adjustment_code "
									  " where ipolicy = ? "
										" and ireason = icode "
										" and fclass = '1'    "
								   " group by 1,2,3,4,5,6,7 ;",outputf1);
		printf("stmt1[%s]\n",stmt1);
		$prepare pre_2 from $stmt1;
		$declare cursor2 cursor for pre_2;
		$open cursor2 using $ipolicy;
		first = 0;
		$fetch cursor2 
		  into $iclaim,$daccident,$facc_duty,$fdmg_duty,
		       $iins_type,$ireason_tmp,$nabbr,$mouts,$msettle;
		if (SQLCODE == SQLNOTFOUND){
			car1004_print2();
		}
		while(1){
			if (SQLCODE == SQLNOTFOUND){
				break;
			}
			first++;
			if (strncmp(ireason_tmp,"204",3) == 0){
				strcpy(nabbr,"�O�T�I");
			}
			car1004_print1();
			$fetch cursor2 
			  into $iclaim,$daccident,$facc_duty,$fdmg_duty,
			       $iins_type, $ireason_tmp,$nabbr,$mouts,$msettle;
			if (SQLCODE == SQLNOTFOUND){
				car1004_print3();
			}
		}
		$close cursor2;
		$free  cursor2;
read_next:
		strcpy(pre_fcard,fcard_class);
		strcpy(pre_ply,ipolicy);
		$fetch cursor1 
		  into $fcard_class,$ipolicy,$ifpce_id,$nassured,$itag,$icar_type,
		       $nuser,$ndply_begin,$ndply_end,$iofficer,$nofficer,$mprem,$mfull;
		if (SQLCODE == SQLNOTFOUND){
			strcpy(fcard_class," ");
		}
	}
	$close cursor1;
	$free  cursor1;
	printf("before print_tot \n");
	car1004_print_tot();
	
	rgu_finish_report();
	/*�����s�@���Ӫ�*/
	
	if((rtncode=save_form_info(F_FREE, "CA", 1004, userid, iForm_Tp, max_cnt, outputf))<0) {
printf("car1004B.fmt save_form_info failed\n");
		return rtncode;
	}
printf("car1004B.fmt save_form_info SUCCESS\n");
	return SUCCESS;
	
errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}

/*--------------------------------------------------------------------*/
/* car1004_claim_c : �j��z��                                         */
/*--------------------------------------------------------------------*/
int car1004_claim_c()
{
	$char  stmt[512],stmt1[512],stmt2[512];
	int    rtncode,fclose;

	$whenever sqlerror goto errexit;

	strcpy(iins_type,"21");
	iins_grp = 4;
	sprintf_s(stmt, sizeof stmt,
			"select iclaim,date(daccident),iacc_reason,facc_duty,fdmg_duty "
			 " from %s:appraisal "
		    " where ipolicy = ? ",tmp_fulldb);
	$prepare pre_21 from $stmt;
	$declare cur_21 cursor for pre_21;
	$open cur_21 using $ipolicy;
	while(1) {
		$fetch cur_21 into $iclaim,$daccident,$ireason,$facc_duty,$fdmg_duty;
		if (SQLCODE==SQLNOTFOUND){
			break;
		}
printf("iclaim[%s]\n",iclaim);

		msettle = 0.0;
		mouts = 0.0;
		sprintf_s(stmt1, sizeof stmt1,
				"select iins_item,ivictim,dappraisal,mapp_cover+mapp_fee "
				 " from %s:ca_app_victim "
			    " where iclaim = ? ",tmp_fulldb);
		$prepare pre_22 from $stmt1;
		$declare cur_22 cursor for pre_22;
		$open cur_22 using $iclaim;
		while(1) {
			$fetch cur_22 into $iins_item,$ivictim,$dappraisal,$mins_app; 
printf("iins_item[%s]ivictim[%s]\n",iins_item,ivictim);
			if (SQLCODE==SQLNOTFOUND){
				break;
			}
			rtncode = ca_calc_info_msettle(DBName1,fcard_class,iclaim,iins_item,ivictim,dcalc,&tmp_mstl_dend,&flag_close_dend);
			if (rtncode != SUCCESS){
				return rtncode;
			}
			
			rtncode=ca_calc_info_msettle(DBName1,fcard_class,iclaim,iins_item,ivictim,dbgn,&tmp_mstl_dbgn,&flag_close_dbgn);
			if (rtncode != SUCCESS){
				return rtncode;
			}
			
			rtncode = ca_calc_info_payment(daccident,dappraisal,mins_app,flag_close_dend,flag_close_dbgn,tmp_mstl_dend,
											tmp_mstl_dbgn,dbgn,&tmp_mpayment,&tmp_mstl,&tmp_mbgn_outstl,&tmp_mend_outstl);
			if(tmp_mstl != 0)
			{
				msettle += tmp_mstl;
			}
			if((tmp_mend_outstl - tmp_mbgn_outstl) != 0)
			{
				mouts += (tmp_mend_outstl - tmp_mbgn_outstl);
			}
/*printf("msettle[%f]mouts[%f]\n");*/
		}
		$close cur_22;
		$free  cur_22;
		rtncode = insert_car1004_1();
		if (rtncode != SUCCESS){
			return rtncode;
		}
	}
	$close cur_21;
	$free  cur_21;

	return SUCCESS;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
/*--------------------------------------------------------------------*/
/* car1004_claim_v : ���N�z��                                         */
/*--------------------------------------------------------------------*/
int car1004_claim_v()
{
$char  stmt[512],stmt1[512],stmt2[512];
int    rtncode,fclose;

	$whenever sqlerror goto errexit;

	sprintf_s(stmt, sizeof stmt,
			"select iclaim,date(daccident),iacc_reason,facc_duty,fdmg_duty "
			 " from %s:appraisal "
			" where ipolicy = ? ",tmp_fulldb);
	$prepare pre_31 from $stmt;
	$declare cur_31 cursor for pre_31;
	$open cur_31 using $ipolicy;
	while(1) {
		$fetch cur_31
		  into $iclaim,$daccident,$ireason,$facc_duty,$fdmg_duty;
		if (SQLCODE==SQLNOTFOUND){
			break;
		}
printf("iclaim[%s]\n",iclaim);
		sprintf_s(stmt1, sizeof stmt1,
				"select a.iins_type,dappraisal,mins_app+mproc_app,b.imain_ins "
			     " from %s:app_ins_type a,insurance_type b "
			    " where iclaim = ? "
				  " and a.iins_type = b.iins_type ",tmp_fulldb);
		$prepare pre_32 from $stmt1;
		$declare cur_32 cursor for pre_32;
		$open cur_32 using $iclaim;
		while(1) {
			$fetch cur_32 into $iins_type,$dappraisal,$mins_app,$imain_ins; 
printf("iins_type[%s]\n",iins_type);
			if (SQLCODE==SQLNOTFOUND){
				break;
			}
			rtncode = ca_calc_info_msettle(DBName1, fcard_class, iclaim, iins_type, " ", dcalc, &tmp_mstl_dend, &flag_close_dend);
			if (rtncode != SUCCESS){
				return rtncode;
			}
			
			rtncode = ca_calc_info_msettle(DBName1, fcard_class, iclaim, iins_type, " ", dbgn, &tmp_mstl_dbgn, &flag_close_dbgn);
			if (rtncode != SUCCESS){
				return rtncode;
			}		 
			
			rtncode = ca_calc_info_payment(daccident, dappraisal, mins_app, flag_close_dend, flag_close_dbgn, tmp_mstl_dend, 
										 tmp_mstl_dbgn, dbgn, &tmp_mpayment, &tmp_mstl, &tmp_mbgn_outstl, &tmp_mend_outstl);
			if(tmp_mstl != 0)
			{
				msettle = tmp_mstl;
			}
			else
			{
				msettle = 0;
			}
			
			if((tmp_mend_outstl - tmp_mbgn_outstl) != 0)
			{
				mouts = (tmp_mend_outstl - tmp_mbgn_outstl);
			}
			else
			{
				mouts = 0;
			}

			printf("msettle[%f]mouts[%f]\n",msettle,mouts);
			check_ins_grp();
			rtncode = insert_car1004_1();
			if (rtncode != SUCCESS){
				return rtncode;
			}
		} 
		$close cur_32;
		$free  cur_32;
	}
	$close cur_31;
	$free  cur_31;

	return SUCCESS;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
/*--------------------------------------------------------------------*/
/* insert_car1004 : �g�J�O,�����                                   */
/*--------------------------------------------------------------------*/
int insert_car1004()
{
	$char stmt[512];
	$whenever sqlerror goto errexit;

	sprintf_s(stmt, sizeof stmt,"insert into car%s values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);",outputf);

	$prepare pre_ins from $stmt;
	$execute pre_ins using
		$ipolicy,$iendorse,$fcard_class,$irela_ply,$ifpce_id,$nassured,
		$icorps,$itag,$dply_begin,
		$dply_end,$iins_grp,$iins_type,$mply_prem,$qcount,
		$mfull,$qfull,$dori_begin,$dori_end,$icar_type,$nuser,
		$iofficer,$nofficer;

	return SUCCESS;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
/*--------------------------------------------------------------------*/
/* insert_car1004_1 : �g�J�z�߸��                                    */
/*--------------------------------------------------------------------*/
int insert_car1004_1()
{
	$char    stmt[512];
	$whenever sqlerror goto errexit;

	sprintf_s(stmt, sizeof stmt,"insert into car%s values (?,?,?,?,?,?,?,?,?,?);",outputf1);

	$prepare pre_ins1 from $stmt;
	$execute pre_ins1 using
		$ipolicy,$iclaim,$daccident,$iins_grp,$iins_type,$ireason,
		$mouts,$msettle,$facc_duty,$fdmg_duty;

	return SUCCESS;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}

/*--------------------------------------------------------------------*/
/* check_ins_grp : ��ΦA�O�I�O���P�_                               */
/*--------------------------------------------------------------------*/
int check_ins_grp()
{
	$whenever sqlerror goto errexit;
	$SELECT case when iri_ins = '01' or iins_type = '58' then 1 
				 when iri_ins = '11' then 2 
				 when iins_type = '21' then 4 
				 else 3    /* when iri_ins in ('31','51')  then '3'*/	       
			end 
	   INTO $iins_grp
	   FROM insurance_type
	  WHERE iins_type = $iins_type;
	
	if( SQLCODE == SQLNOTFOUND){
		return FAIL;
	}
	else{
		return SUCCESS; 
	}
	
errexit:
	printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
	return SQLCODE; 
}

/*--------------------------------------------------------------------*/
car1004_print()
{
char  str[20];
	rgu_put_body_string(4, ipolicy,    1);
	rgu_put_body_string(4, ifpce_id,   1);
	rgu_put_body_string(4, nassured,   1);
	rgu_put_body_string(4, nuser,      1);
	rgu_put_body_string(4, icar_type,  1);
	rgu_put_body_string(4, itag,       1);
	rgu_put_body_string(4, iofficer,   1);
	rgu_put_body_string(4, nofficer,   1);
	rgu_put_body_string(4, ndply_begin, 1);
	rgu_put_body_string(4, ndply_end,   1);
	rfmtdouble(mprem,"-,---,---,--&",str);
	rgu_put_body_string(4, str, 1);
	rfmtdouble(mfull,"-,---,---,--&",str);
	rgu_put_body_string(4, str, 1);
	sub_mprem += mprem;
	sub_mfull += mfull;
}
/*--------------------------------------------------------------------*/
car1004_print1()
{
char  str[20];
	if (first>1){
		rgu_put_body_string(4, " ",  1);
		rgu_put_body(4);
		max_cnt++;
		rgu_put_body_string(4, " ",  1);
		rgu_put_body_string(4, " ",  1);
		rgu_put_body_string(4, " ",  1);
		rgu_put_body_string(4, " ",  1);
		rgu_put_body_string(4, " ",  1);
		rgu_put_body_string(4, " ",  1);
		rgu_put_body_string(4, " ",  1);
		rgu_put_body_string(4, " ",  1);
		rgu_put_body_string(4, " ",  1);
		rgu_put_body_string(4, " ",  1);
		rgu_put_body_string(4, " ",  1);
		rgu_put_body_string(4, " ",  1);
	}
	rgu_put_body_string(4, daccident,  1);
	rgu_put_body_string(4, iclaim,     1);
	rgu_put_body_string(4, iins_type,  1);
	rgu_put_body_string(4, nabbr,      1);

	if (fdmg_duty[0] == '1'){
		rgu_put_body_string(4, "1.���F�d,�O��", 1); 
	}
	else if (fdmg_duty[0] == '2'){
		rgu_put_body_string(4, "2.�L�F�d,���O��", 1); 
	}
	else if (fdmg_duty[0] == '3'){
		rgu_put_body_string(4, "3.���F�d,���O��", 1); 
	}
	else{
		rgu_put_body_string(4, " ", 1); 
	}

	if (facc_duty[0] == '1'){
		rgu_put_body_string(4, "1.���F�d,�O��", 1); 
	}
	else if (facc_duty[0] == '2'){
		rgu_put_body_string(4, "2.�L�F�d,���O��", 1); 
	}
	else if (facc_duty[0] == '3'){
		rgu_put_body_string(4, "3.���F�d,���O��", 1); 
	}
	else{
		rgu_put_body_string(4, " ", 1); 
	}

	rfmtdouble(mouts,"-,---,---,--&",str);
	rgu_put_body_string(4, str, 1);
	rfmtdouble(msettle,"-,---,---,--&",str);
	rgu_put_body_string(4, str, 1);
	rfmtdouble(mouts + msettle,"-,---,---,--&",str);
	rgu_put_body_string(4, str, 1);
	mouts_1 += mouts;
	msettle_1 += msettle;
	mloss += (mouts + msettle);
}
/*--------------------------------------------------------------------*/
car1004_print2()
{
char  str[20];
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body(4);
	/**
	sub_mouts += mouts_1;
	sub_msettle += msettle_1;
	sub_mloss += mloss;
	mouts_1 = msettle_1 = mloss = 0;
	**/
	max_cnt++;
}
/*--------------------------------------------------------------------*/
car1004_print3()
{
char  str[20];

	if (first > 1){
		rgu_put_body_string(4, " ",  1);
		rgu_put_body(4);
		max_cnt++;
		rgu_put_body_string(4, " ",  1);
		rgu_put_body_string(4, " ",  1);
		rgu_put_body_string(4, " ",  1);
		rgu_put_body_string(4, " ",  1);
		rgu_put_body_string(4, " ",  1);
		rgu_put_body_string(4, " ",  1);
		rgu_put_body_string(4, " ",  1);
		rgu_put_body_string(4, " ",  1);
		rgu_put_body_string(4, " ",  1);
		rgu_put_body_string(4, " ",  1);
		rgu_put_body_string(4, " ",  1);
		rgu_put_body_string(4, " ",  1);
		rgu_put_body_string(4, " ",  1);
		rgu_put_body_string(4, " ",  1);
		rgu_put_body_string(4, " ",  1);
		rgu_put_body_string(4, " ",  1);
		rgu_put_body_string(4, " ",  1);
		rgu_put_body_string(4, " ",  1);
		rgu_put_body_string(4, " ",  1);
		rgu_put_body_string(4, " ",  1);
		rfmtdouble(mloss,"-,---,---,--&",str);
		rgu_put_body_string(4, str, 1);
		if (mfull == 0){
			strcpy(str,"0.00");
		}
		else{
			rfmtdouble(mloss/mfull*100,"---,---.&&",str);
		}
		rgu_put_body_string(4, str, 1);
	}
	else{
		if(mfull == 0){
			strcpy(str,"0.00");
		}
		else{
			rfmtdouble(mloss/mfull*100,"---,---.&&",str);
		}
		rgu_put_body_string(4, str, 1);
	}
	rgu_put_body(4);
	sub_mouts += mouts_1;
	sub_msettle += msettle_1;
	sub_mloss += mloss;
	mouts_1 = msettle_1 = mloss = 0;
	max_cnt++;
}
/*--------------------------------------------------------------------*/
car1004_print_sub()
{
char  str[20];

	rgu_put_body_string(4, "�p�p",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rfmtdouble(sub_mprem,"-,---,---,--&",str);
	rgu_put_body_string(4, str, 1);
	rfmtdouble(sub_mfull,"-,---,---,--&",str);
	rgu_put_body_string(4, str, 1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rfmtdouble(sub_mouts,"-,---,---,--&",str);
	rgu_put_body_string(4, str, 1);
	rfmtdouble(sub_msettle,"-,---,---,--&",str);
	rgu_put_body_string(4, str, 1);
	rfmtdouble(sub_mloss,"-,---,---,--&",str);
	rgu_put_body_string(4, str, 1);
   
	if (sub_mfull == 0){
		strcpy(str,"0.00");	
	}
	else if(sub_mfull != 0){
		rfmtdouble((sub_mloss/sub_mfull)*100,"--,---.&&",str);
	}
	
	rgu_put_body_string(4, str, 1);
	rgu_put_body(4);
	tot_mprem += sub_mprem;
	tot_mfull += sub_mfull;
	tot_mouts += sub_mouts;
	tot_msettle += sub_msettle;
	tot_mloss += sub_mloss;
	sub_mprem = sub_mouts = sub_msettle = sub_mloss = 0;
	sub_mfull = sub_mfull * 0;
	max_cnt++;
}
/*--------------------------------------------------------------------*/
car1004_print_tot()
{
char  str[20];

	rgu_put_body_string(4, "�X�p",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rfmtdouble(tot_mprem,"-,---,---,--&",str);
	rgu_put_body_string(4, str, 1);
	rfmtdouble(tot_mfull,"-,---,---,--&",str);
	rgu_put_body_string(4, str, 1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rgu_put_body_string(4, " ",  1);
	rfmtdouble(tot_mouts,"-,---,---,--&",str);
	rgu_put_body_string(4, str, 1);
	rfmtdouble(tot_msettle,"-,---,---,--&",str);
	rgu_put_body_string(4, str, 1);
	rfmtdouble(tot_mloss,"-,---,---,--&",str);
	rgu_put_body_string(4, str, 1);

	if (tot_mfull == 0){
		strcpy(str,"0.00");
	}
	else{
		rfmtdouble(tot_mloss/tot_mfull*100,"--,---.&&",str);
	}
	rgu_put_body_string(4, str, 1);
	rgu_put_body(4);
	tot_mprem = tot_mfull = tot_mouts = tot_msettle = tot_mloss = 0;
	max_cnt++;
}
/*--------------------------------------------------------------------*/
/* insert_gb : �s�Wgb_schedule���                                    */
/*--------------------------------------------------------------------*/
int insert_gb()
{
$char	curtime[17],cmd[151];

	$whenever sqlerror goto errexit;

	strcpy(curtime,cm_get_sysd());
	sprintf_s(cmd, sizeof cmd,"car1004 %s %s %s %s %s %s",
			DBName,userid,itype,ncode,dbgn1,dend1);

	$INSERT INTO gb_ScheduleLog
				 (fstatus,kpid,nuserid,itype,tctime,tstime,tetime,npgmname,noutfile,command)
		  VALUES ("R",$pid,$userid,'Q',$curtime,$curtime,"","car1004",$pid,$cmd);

	return SUCCESS;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
/*-----------------------------------------------------------------End*/