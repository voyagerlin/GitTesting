/*--------------------------------------------------*/
/*   PROGRAM : ca535m01s.ec                         */
/*                                                  */
/*   DATE    : 2003/01/22                           */
/*--------------------------------------------------*/
     
#include <stdio.h>
#include <stdlib.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;
#include <decimal.h>
#include "safeclib.h"


/*---------------------------------------------------*/
long car535(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
        long rtncode;
    long car535_squery();
    long car535_insert();
    long car535_multiple_query();
    long car535_update_exec();
    char option;

    cm_buf_init(command);
    cm_buf_get("%c",&option);

    switch(option)
    {
/*		case 'C': rtncode = car535_reject_check(reply);
					break;*/
        case 'S': rtncode = car535_squery(reply);
                         break;
        case 'I': rtncode = car535_squery_cu(reply);
                          break;
        case 'A':
                rtncode=car535_insert(reply);
            break;
        case 'M':
            rtncode=car535_multiple_query(reply);
            break;
        case 'D':
        case 'U':
            rtncode=car535_update_exec(reply,command,com_len);
            break;
        default :
            if(exitsub(reply,M_CM_WRONG_OPTION) == True)
                return M_CM_WRONG_OPTION;
        return apiRC;
    }
    return(rtncode);
}

/*--------------------------------------------------*/

long car535_squery(reply)
serverReply reply;
{
     $char DBName[5],D_dbsite[5];
     $char LHsBuffer[1024],sFullName[20];
     $char iclaim[21];
     $char fstl[2];
     $int  iclose_type=0;
     $int  reject_check=0;
     $char dvouch_end[11];
     $char s_iclaim[21];
     $char ibranch_in[3];
     $char nassured[41];
     $char stmt_buf[1024];
     $char FullDBName[50];
	 $int receipt_count;

     int LHiBufLen;
     long MsgCode;

     cm_buf_get("%s ",DBName);
     cm_buf_get("%s ",iclaim);
	 cm_buf_get("%s ",fstl);
	 cm_buf_get("%d ",&iclose_type);

     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
        { return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;}

     
     $SELECT iclaim,ibranch_in[1,2]
        INTO $s_iclaim,$ibranch_in
        FROM ca_clm_process 
       WHERE iclaim = $iclaim;
     if (SQLCODE == SQLNOTFOUND)
     {
         if(exitsub(reply,M_CA_NPOLICY_NCLAIM) == True)
             return M_CA_NPOLICY_NCLAIM;
         else
             return apiRC;
     }
	 strcpy(FullDBName,get_full_dbname(ibranch_in));
	 /*****************************************************************/
	 /*** �ŦX�H�U�����,�l�i����									***/
	 /*** 1.�ץ󪬺A��130(ñ�֧���)									***/
	 /*** 2.ñ�֧���������O�ŭ�									***/
	 /*** 3.�鵲�鬰�ŭ�(�|���鵲)									***/
	 /****															***/
	 /*****************************************************************/
	 /* �ư�car539��J���߮� modify by sylvia 107.05.03 (1070403001_SC1) */
	 /* �ư�car537��J���߮� modify by sylvia 108.01.11 (1070403002_SC1) */
	sprintf_s(stmt_buf,1024,"SELECT count(*) FROM %s:settlement a \
						WHERE iclaim = '%s' AND fstl = '%s' AND iclose_type = '%d' \
						AND dvouch_end is not null \
						AND vouch_state = '130' \
						AND dclose IS NULL \
						AND not exists (select * from sysdb:ca_onsiteproc_cost \
						    where iclaim = a.iclaim and iclose_type = a.iclose_type \
						      and dclose is null) \
						AND not exists (select * from sysdb:ca_health_recovery \
						    where iclaim = a.iclaim and iclose_type = a.iclose_type \
						      and dclose is null)", FullDBName, iclaim, fstl, iclose_type);
	printf("%s\n",stmt_buf);
	$PREPARE rej_chk FROM $stmt_buf;
	$EXECUTE rej_chk INTO $reject_check;


	sprintf_s(stmt_buf,1024,"SELECT dvouch_end FROM %s:settlement a \
						WHERE iclaim = '%s' AND fstl = '%s' AND iclose_type = '%d' \
						AND dvouch_end is not null \
						AND vouch_state = '130' \
						AND dclose IS NULL \
						AND not exists (select * from sysdb:ca_onsiteproc_cost \
						    where iclaim = a.iclaim and iclose_type = a.iclose_type \
						      and dclose is null) \
						AND not exists (select * from sysdb:ca_health_recovery \
						    where iclaim = a.iclaim and iclose_type = a.iclose_type \
						      and dclose is null)", FullDBName, iclaim, fstl, iclose_type);
	$PREPARE rej_info FROM $stmt_buf;
	$EXECUTE rej_info INTO $dvouch_end;
	printf(" stmt_buf[%s]\n",stmt_buf);
           

     cm_buf_init(ReplyBuf);
	 cm_buf_put("%l %d",M_CM_OK,reject_check);
	 cm_buf_put("%s %s %d %s ",iclaim,fstl,iclose_type,dvouch_end);

     LHiBufLen = cm_buf_len(ReplyBuf);

     if(SendSyncReply(reply,ReplyBuf,LHiBufLen,api_OKComplete) == False)
     {
         $WHENEVER SQLERROR CONTINUE;
         $ROLLBACK WORK;
         return apiRC;
     }

     $WHENEVER SQLERROR GOTO errexit;
     return api_OKComplete;

     errexit:
        printf("car535_squery sqlerrm:%s\n",sqlca.sqlerrm);
        $WHENEVER SQLERROR CONTINUE;
        MsgCode = SQLCODE;
        if (SQLCODE != 0) MsgCode = SQLCODE;
        return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

long car535_squery_cu(reply)
serverReply reply;
{
     $char DBName[5],D_dbsite[5];
     $char stmt[1024];
	 $char icode[11],ncode[41];
	 $int icount=0;
     int LHiBufLen;
     long MsgCode;

	 cm_buf_get("%s ",DBName);

     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
        { return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;}


	$SELECT count(*)
		INTO $icount
		FROM cu_code_data
		WHERE itype = '36';

	sprintf_s(stmt,1024,"SELECT icode,ncode \
						FROM cu_code_data \
						WHERE itype = '36'");
	$PREPARE cu_code FROM $stmt;
	$DECLARE csr_cu_code CURSOR FOR cu_code;
	$OPEN csr_cu_code;

	cm_buf_init(ReplyBuf);
	cm_buf_put("%l %d ",M_CM_OK,icount);

	while (1)
	{
		$FETCH csr_cu_code INTO $icode,$ncode;
		if (SQLCODE == SQLNOTFOUND)  break;
		cm_buf_put("%s %s ",icode,ncode);
	}
			 
     LHiBufLen = cm_buf_len(ReplyBuf);

     if(SendSyncReply(reply,ReplyBuf,LHiBufLen,api_OKComplete) == False)
     {
         $WHENEVER SQLERROR CONTINUE;
         $ROLLBACK WORK;
         return apiRC;
     }

     $WHENEVER SQLERROR GOTO errexit;
     return api_OKComplete;

     errexit:
        printf("car535_squery sqlerrm:%s\n",sqlca.sqlerrm);
        $WHENEVER SQLERROR CONTINUE;
        MsgCode = SQLCODE;
        if (SQLCODE != 0) MsgCode = SQLCODE;
        return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}




long car535_insert(reply)
serverReply reply;
{
    $char    DBName[5],sFullName[20];
    int      tmp_len;
    long     MsgCode;
    DBinfo   *list;
    int      k, j, is_add_fail=0, api_f;
    $char    stmt_buf[300];
    int      rows, i;

	$char   iclaim[21];
	$char   fstl[2];
	$int    iclose_type=0;
	$char   dvouch_end[11];
	$char   reject_cause[3];
	$int    qserial;
	$char   dentry[12];

	$char ipolicy[21];
	$char Full_DBName[50];
	$char option[2];
	$int sign_chk;

      int LiBufLen;

    cm_buf_get("%s",DBName);

    if (db_select(DBName) == False)
        {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
                return M_CM_DB_NOTOPEN;
        else
                return apiRC;
    }

    $WHENEVER SQLERROR GO TO errexit;
    $BEGIN WORK;
    
    strcpy(dentry, cm_cdate_str_100(cm_today()));
    strcpy(dentry, cm_to_infdate(dentry));
    printf(" dentry[%s]\n",dentry);

	cm_buf_get("%s %s %d %s %s",iclaim,fstl,&iclose_type,dvouch_end,reject_cause);

	$select ipolicy
		into $ipolicy
		from ca_clm_process 
		where iclaim = $iclaim;

	printf("for insert ipolicy[%s]\n",ipolicy);
	strcpy(sFullName, get_car_full_db(ipolicy));
	printf(" Full_DBname[%s]\n",Full_DBName);
	printf(" ************************ \n");


	/*strcpy(dreceive,cm_to_infdate(dreceive));
	strcpy(dpaperwork,cm_to_infdate(dpaperwork));*/

	sprintf_s(stmt_buf,1024, "UPDATE %s:settlement \
						SET vouch_state = 90, dvouch_bgn = null, dvouch_end = null, c_reason = '%s' \
						WHERE iclaim = '%s' AND fstl = '%s' AND iclose_type = %d ", sFullName, reject_cause, iclaim, fstl, iclose_type);
	printf("upd_stmt ==> [%s]\n",stmt_buf);

        /*****  smartflow url �h��w�|�^��
	$PREPARE upd_vouch_status FROM $stmt_buf;
	$EXECUTE upd_vouch_status;
        *****/

	printf(" ************************** \n");
	cm_buf_init(ReplyBuf);
	cm_buf_put("%l",M_CM_OK);
	LiBufLen = cm_buf_len(ReplyBuf);

	if(SendSyncReply(reply,ReplyBuf,LiBufLen,api_OKComplete) == False)
	{
		$WHENEVER SQLERROR CONTINUE;
		$ROLLBACK WORK;
		return apiRC;
	}

	$WHENEVER SQLERROR GOTO errexit;
	$COMMIT WORK;
	return api_OKComplete;

	errexit:
		printf("car535_insert SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
		$WHENEVER SQLERROR CONTINUE;
		MsgCode = SQLCODE;
		$ROLLBACK WORK;
		if (SQLCODE != 0) MsgCode = SQLCODE;
		return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

/****************************************************************************/
long car535_multiple_query(reply)
serverReply reply;
{
        /* standard defined host variables */
    $char   DBName[5];
    /* end of standard host var */
     $char   iclaim[21];
     $char   ifpce_id[11];
     $char   ifpce_id_ext[3];
     $int    qserial = 0;
     $int    mpayment = 0;
     $char   invoice[21];
     $char   dreceive[11];
     $char   dpaperwork[11];
     $char   drate[11];
     $char   dentry[11];
     $char   dsettle[11];
     $char   dclose[11];
     $char ipolicy[21];
     $char stmt_buf[500];
     $char Full_DBName[50];
      $char   old_iclaim[21];
      $char   old_ifpce_id[11];
      $char   old_ifpce_id_ext[3];
      $int    old_qserial;
      $char  nchi_full[41];


    /* standard defined data */
    char tmpbuf[4000];
    int  count=0,repbuf_len=0,tmp_len=0,replycnt=0;
    int  i,total_count=0;
    /* end of standard data */

    /* self defined data */
    $char oldicar_type[3],oldiins_type[INSURANCE_TYPE],oldisame_ins[INSURANCE_TYPE];
    $char tmpisame_ins[10];
    $char tmpinsname[29], tmpconame[29];
    /*dec_t dec_mpremium,dec_pextra_charge;*/
    /* end of self data */


    cm_buf_get("%s",DBName);
    cm_buf_get("%s %s",iclaim,ifpce_id);
     
    $WHENEVER SQLERROR GOTO errexit;
     
    if (db_select(DBName) == False)
    {
            if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
        else
                return apiRC;
    }


       $select ipolicy
          into $ipolicy
          from ca_clm_process
         where iclaim = $iclaim;

         strcpy(Full_DBName, get_car_full_db(ipolicy));

      sprintf_s(stmt_buf,1024,"select iclaim,ifpce_id,ifpce_id_ext,qserial, \
                               mpayment,invoice,dreceive,DATE(dpaperwork),  \
                               dsettle,dclose                        \
                          from %s:ca_sign_receipt                       \
                         where iclaim matches ?                      \
                           and ifpce_id matches ?                    \
                         order by 1,2,3,4",Full_DBName);
      printf("stmt[%s]\n",stmt_buf);
      EXEC SQL PREPARE Acursor  FROM :stmt_buf;
      EXEC SQL DECLARE AcursorC CURSOR FOR Acursor;
      EXEC SQL OPEN AcursorC USING :iclaim,:ifpce_id;
      while (1)
      {

          EXEC SQL FETCH AcursorC INTO :iclaim,:ifpce_id,:ifpce_id_ext,:qserial,
                                       :mpayment,:invoice,:dreceive,:dpaperwork,
                                       :dsettle,:dclose;

          if (SQLCODE == SQLNOTFOUND)  break;

           $SELECT nchi_full
              INTO $nchi_full
              FROM cu_customer
             WHERE ifpce_id = $ifpce_id
               AND ifpce_id_ext = $ifpce_id_ext;

            printf(" nchi_full[%s]\n",nchi_full);

              if (SQLCODE == SQLNOTFOUND)
              {
                  strcpy(nchi_full," ");

              }


          cm_buf_init(tmpbuf);

        if (count == 0)
        {
            cm_buf_res_msg();             /* reserve for MsgCode and count */
            cm_buf_res_count();
        }

          strcpy(dreceive,cm_from_infdate_100(dreceive));
          strcpy(dpaperwork,cm_from_infdate_100(dpaperwork));
          strcpy(dsettle,cm_from_infdate_100(dsettle));
          strcpy(dclose,cm_from_infdate_100(dclose));

        cm_buf_put("%s %s %s %d %d %s %s %s %s %s %s",
                    iclaim,ifpce_id,ifpce_id_ext,qserial,mpayment,invoice,
                    dreceive,dpaperwork,dsettle,dclose,nchi_full);
        tmp_len = cm_buf_len(tmpbuf);
        if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
        {
                memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
            repbuf_len += tmp_len;
            count++;
        }
        else                               /* more than 4K, send to client side */
        {
            cm_buf_init(ReplyBuf);
            cm_buf_put_msg(M_CM_OK);
            cm_buf_put_count(count);
            if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
            {
                $CLOSE q_cur2;
                return apiRC;
            }
            else               /* clear ReplyBuf and count to start all over again */
            {
                replycnt++;
                if (replycnt == 10)   /* more than 30K, client cannot display,error */
                {
                        cm_buf_init(ReplyBuf);
                        cm_buf_put("%l",M_CM_OUT_SPACE);
                        tmp_len = cm_buf_len(ReplyBuf);
                        if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
                                return apiRC;
                        return M_CM_OUT_SPACE;
                }
                strcpy(drate,cm_from_infdate_100(drate));
                ReplyBuf[0] = '\0';
                count = 0;
                cm_buf_init(ReplyBuf);
                cm_buf_res_msg();           /* reserve for MsgCode and count */
                cm_buf_res_count();
                cm_buf_put("%s %s %s %d %d %s %s %s %s %s %s",
                            iclaim,ifpce_id,ifpce_id_ext,qserial,mpayment,invoice,
                            dreceive,dpaperwork,dsettle,dclose,nchi_full);
                repbuf_len = cm_buf_len(ReplyBuf);
                count++;
            }
          }
     }/* for loop */
      

    if (count > 0)   /* break out, at least one record is selected */
    {
        cm_buf_init(ReplyBuf);
        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(count);
        if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
                return apiRC;
        return api_OKComplete;
    }
    else            /* break out, not any row is found */
    {
        if(exitsub(reply,M_CM_NOT_FOUND) == True)
                return M_CM_NOT_FOUND;
        else
                return apiRC;
    }

errexit:
    if(exitsub(reply,SQLCODE) == True)
        return SQLCODE;
    else
        return apiRC;
}

/*--------------------------------------------------*/
long car535_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
    /* standard defined host variables */
    $char DBName[5];
    /* end of standard host var */

       $char   iclaim[21];
       $char   ifpce_id[11];
       $char   ifpce_id_ext[3];
       $int    qserial;
       $int   mpayment;
       $int   int_mpayment;
       $char   invoice[20];
       $char   dreceive[11];
       $char   dpaperwork[12];
       $char   drate[12];
       $char   dentry[12];
       $char   dsettle[12];
       $char   dclose[12];
       $char ipolicy[20];
       $char old_iclaim[21],old_ifpce_id[11],old_ifpce_id_ext[3];
       $int old_qserial;

	   $int sign_chk;
       char rflag;
    
       $int   qserial_tmp;
       $char  dpaperwork_tmp[14];
       $char  dentry_tmp[11];
       $char  dsettle_tmp[11];
       $char  dclose_tmp[11];




    /* standard defined data */
    char option,*pos,*raw_ptr,cur_buf[6000],*comm;
    int tmp_len,raw_len;
    long dummy=0,dum_cnt=0;
    long MsgCode;
    int count=0, rows,i;
    DBinfo *list;
    int k, j, is_del_fail=0, is_upd_fail=0;
    $char stmt_buf[3000];
    $char Full_DBName[500];
    /* end of standard data */


    cm_buf_init(command);
    cm_buf_get("%c %s %l",&option,DBName,&rows);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
                return M_CM_DB_NOTOPEN;
        return apiRC;
    }

    if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
    {
        if(exitsub(reply,M_CM_NOT_DBLIST) == True)
                return M_CM_NOT_DBLIST;
        return apiRC;
    }

    $WHENEVER SQLERROR GO TO errexit;
    $BEGIN WORK;
    printf(" row[%d]\n",rows);


    if ( option == 'D' )
    {

       for (k = 0; k < rows && is_upd_fail != 3; k++)
       {
           cm_buf_get("%s %s %s %d ",iclaim,ifpce_id,ifpce_id_ext,&qserial );

           $SELECT ipolicy 
              INTO $ipolicy
              FROM ca_clm_process
             WHERE iclaim = $iclaim;
                
           if( SQLCODE == SQLNOTFOUND ) continue;
                
           strcpy(Full_DBName, get_car_full_db(ipolicy));
                
           sprintf_s(stmt_buf,1024,"DELETE FROM %s:ca_sign_receipt \
                              WHERE iclaim=? \
                                AND ifpce_id = ? \
                                AND ifpce_id_ext = ? \
                                AND qserial = ?",Full_DBName);
           $PREPARE d_id FROM $stmt_buf;

           if(SQLCODE != 0)
           {
               is_del_fail = 1;

           }
           $EXECUTE d_id USING $iclaim,$ifpce_id,$ifpce_id_ext,$qserial;
           if(SQLCODE != 0)
           {
               is_del_fail = 1;
           }

           if( is_del_fail ) goto errexit;
                
       }
       
       cm_buf_init(ReplyBuf);
       cm_buf_put("%l",M_CM_OK);
       tmp_len = cm_buf_len(ReplyBuf);
       if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
       {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            return apiRC;
       }

       $WHENEVER SQLERROR GOTO errexit;
       $COMMIT WORK;
       return api_OKComplete;
    }
    else if (option == 'U')
    {

      printf(" into option = 'U' \n");

      strcpy(dentry, cm_cdate_str_100(cm_today()));
      strcpy(dentry, cm_to_infdate(dentry));

      $WHENEVER SQLERROR continue;

      for (k = 0; k < rows && is_upd_fail != 3; k++)
      {

          cm_buf_get("%s %s %s %d %s %s %s %s %s %s %d",
                     iclaim,ifpce_id,ifpce_id_ext,&mpayment,invoice,dreceive,
                     dpaperwork,old_iclaim,old_ifpce_id,old_ifpce_id_ext,&old_qserial);

          $SELECT ipolicy
             INTO $ipolicy
             FROM ca_clm_process
            WHERE iclaim = $iclaim;

          strcpy(Full_DBName, get_car_full_db(ipolicy));
          printf(" Full_DBname[%s]\n",Full_DBName);
          printf(" ************************ \n");

          strcpy(dreceive,cm_to_infdate(dreceive));
          strcpy(dpaperwork,cm_to_infdate(dpaperwork));
          printf(" ifpce_id[%s]\n",ifpce_id);
          printf(" old_ifpce_id[%s]\n",old_ifpce_id);

			/*�ˮ�ñ���餣�o������z�� add by Max*/
		   sprintf_s(stmt_buf,1024,"SELECT count(*) FROM %s:appraisal where date(dclaim) <= '%s' and iclaim = '%s' ",
			   Full_DBName,dpaperwork,iclaim);
		   $PREPARE sign_chk FROM $stmt_buf;
		   $EXECUTE sign_chk INTO $sign_chk;
			if (sign_chk == 0)
			{
				$ROLLBACK WORK;
				return exitsub(reply,M_CA_SIGN_DATE_ERR) ? M_CA_SIGN_DATE_ERR : apiRC;
			}

          /*
          sprintf_s(stmt_buf,1024, "UPDATE %s:ca_sign_receipt \
                                SET ( ifpce_id, ifpce_id_ext, mpayment, invoice, dreceive ) \
                                  = ( ?,?,?,?,? ) \
                              WHERE iclaim = '%s' AND ifpce_id= '%s' \
                                AND ifpce_id_ext = '%s' AND qserial= %d ",
                              Full_DBName, old_iclaim, old_ifpce_id, old_ifpce_id_ext,
                              old_qserial );
          */

         


/*  Mark  Cyrus  920224
          sprintf_s(stmt_buf,1024, "UPDATE %s:ca_sign_receipt \
                                SET ( ifpce_id, ifpce_id_ext, mpayment, invoice, dreceive ) \
                                  = ( ?,?,?,?,? ) \
                              WHERE iclaim = ? AND ifpce_id= ? \
                                AND ifpce_id_ext = ? AND qserial= ? ",
                              Full_DBName);
*/
          sprintf_s(stmt_buf,1024,
           " SELECT dpaperwork, dentry,        \
                    dsettle, dclose            \
               FROM %s:ca_sign_receipt         \
              WHERE iclaim = ?                 \
                AND ifpce_id = ?               \
                AND ifpce_id_ext = ?           \
                AND qserial = ?  ",Full_DBName);
           $PREPARE sel_id FROM $stmt_buf;
           $EXECUTE sel_id 
               INTO $dpaperwork_tmp,$dentry_tmp,$dsettle_tmp,$dclose_tmp
              USING $old_iclaim,$old_ifpce_id,$old_ifpce_id_ext,$old_qserial;

             printf("stmt_buf[%s]\n",stmt_buf);
          sprintf_s(stmt_buf,1024,
           " DELETE FROM %s:ca_sign_receipt    \
              WHERE iclaim = ?                 \
                AND ifpce_id = ?               \
                AND ifpce_id_ext = ?           \
                AND qserial = ?  ",Full_DBName);
           $PREPARE del_sign FROM $stmt_buf;
           $EXECUTE del_sign
              USING $old_iclaim,$old_ifpce_id,$old_ifpce_id_ext,$old_qserial;

             printf("stmt_buf[%s]\n",stmt_buf);
          sprintf_s(stmt_buf,1024,
           " SELECT NVL(MAX(qserial),0)+1      \
               FROM %s:ca_sign_receipt         \
              WHERE iclaim = ?                 \
                AND ifpce_id = ?               \
                AND ifpce_id_ext = ? ",Full_DBName);
           $PREPARE max_qser FROM $stmt_buf;
           $EXECUTE max_qser 
               INTO $qserial_tmp
              USING $old_iclaim,$ifpce_id,$ifpce_id_ext;
           
             printf("stmt_buf[%s]\n",stmt_buf);
          sprintf_s(stmt_buf,1024,
           " INSERT INTO %s:ca_sign_receipt                       \
                  (iclaim,ifpce_id,ifpce_id_ext,qserial,          \
                   mpayment,invoice,dreceive,dpaperwork,dentry,   \
                   dsettle,dclose,ideliver)                                \
             VALUES (?,?,?,?,?,?,?,?,?,?,?,'') ",Full_DBName);
           $PREPARE ins_sign FROM $stmt_buf;
           $EXECUTE ins_sign
              USING $old_iclaim,$ifpce_id,$ifpce_id_ext,$qserial_tmp,
                    $mpayment,$invoice,$dreceive,$dpaperwork_tmp,
                    $dentry_tmp,$dsettle_tmp,$dclose_tmp;

         printf("$_$ stmt_buf[%s]\n",stmt_buf);

          /**
          $PREPARE u3_id FROM $stmt_buf;
          **/
          if(SQLCODE != 0)
          {
              is_upd_fail = 3;
              break;
          }

           printf("ifpce_id[%s]\n",ifpce_id);
           printf("ifpce_id_ext[%s]\n",ifpce_id_ext);
           printf("mpayment[%d]\n",mpayment);
           printf("invoice[%s]\n",invoice);
           printf("dreceive[%s]\n",dreceive);

           printf("\n");
           printf("old_iclaim[%s]\n",old_iclaim);
           printf("old_ifpce_id[%s]\n",old_ifpce_id);
           printf("old_ifpce_id_ext[%s]\n",old_ifpce_id_ext);
           printf("old_qserial[%d]\n",old_qserial);

          /**
          $EXECUTE u3_id USING $ifpce_id,$ifpce_id_ext,$mpayment,$invoice,$dreceive,
                               $old_iclaim,$old_ifpce_id,$old_ifpce_id_ext,$old_qserial;
          printf("flag 1\n");
          if(SQLCODE != 0)
          {
              is_upd_fail = 3;
              break;
          }
          
          **/
          printf("flag 2\n");
          $UPDATE ca_clm_process
              SET dpaperwork = $dentry
            WHERE iclaim = $iclaim;

          /*
          $WHENEVER SQLERROR CONTINUE;
          $ROLLBACK WORK;
          if(exitsub(reply,M_CM_WRONG_OPTION) == True)
            return M_CM_WRONG_OPTION;
          else
             return apiRC;
          */
          printf("flag 3\n");
      
      } /* end for (k = 0... */


      if (is_upd_fail == 3)
      {
          is_upd_fail = 1;
      }

      if( is_upd_fail ==1) goto errexit;

      cm_buf_init(ReplyBuf);
      cm_buf_put("%l",M_CM_OK);
      tmp_len = cm_buf_len(ReplyBuf);
      if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
      {
         $WHENEVER SQLERROR CONTINUE;
         $ROLLBACK WORK;
         return apiRC;
      }

      $WHENEVER SQLERROR GOTO errexit;
      $COMMIT WORK;
      return api_OKComplete;
      
    }
    else
    {
      if(exitsub(reply,M_CM_WRONG_OPTION) == True)
        return M_CM_WRONG_OPTION;
      else
        return apiRC;
    }

errexit:
    $WHENEVER SQLERROR CONTINUE;
    MsgCode = SQLCODE;
    $ROLLBACK WORK;
    if (SQLCODE != 0) MsgCode = SQLCODE;
    if(exitsub(reply,MsgCode) == True)
        return MsgCode;
    else
        return apiRC;
}

