/*--------------------------------------------------*/
/*   PROGRAM : ca106m01s.ec by Dennis Chang         */
/*   MODIFIER: Johnny Kuo 04/11/1997                */
/*             Alex 04/09/2002                      */
/*   DATE    : 1993/09/02                           */
/*--------------------------------------------------*/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;
#include <decimal.h>
#include "safeclib.h"

typedef struct {
    char   type;
 /* long   old_deduct;*/
    long   deduct;
    double qpt_bgn;
    double qpt_end;
    double rate;
    double mprem;
    double pextra_charge;
 /* char   old_drate[12];*/
    char   drate[12];
    } car106_t;

/*--------------------------------------------------*/
long car106(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	long rtncode;
	long car106_insert(),car106_single_query(),car106_multiple_query(),car106_update_exec();
	char option;

	cm_buf_init(command);
 	cm_buf_get("%c",&option);

 	switch(option)
 	{
	  	case 'A':
    		rtncode=car106_insert(reply);
        	break;
  		case 'Q':
    		rtncode=car106_single_query(reply);
        	break;
  		case 'M':
        	rtncode=car106_multiple_query(reply);
        	break;
  		case 'D':
  		case 'U':
        	rtncode=car106_update_exec(reply,command,com_len);
        	break;
  		default :
    		if(exitsub(reply,M_CM_WRONG_OPTION) == True)
        		return M_CM_WRONG_OPTION;
           	return apiRC;
 	}
 	return(rtncode);
}

/*--------------------------------------------------*/
long car106_insert(reply)
serverReply reply;
{
	$char    DBName[3],iins_type[INSURANCE_TYPE],icar_type[3],fpt[2],ical_ins[INSURANCE_TYPE];
   	$char    fcal_class[2],carins[INSURANCE_TYPE],caltype[2];
   	$char    drate[9],drate_e[12],str_rows[3];
	/*$char insname1[7],carname[11],insname2[7];*/
   	/*--$long deduct,mprem;*/
   	$long    deduct;
   	$double  qpt_bgn,qpt_end,rate,mprem,pextra_charge;
        dec_t    dec_qpt_bgn,dec_qpt_end,dec_rate,dec_mprem,dec_pextra_charge;
        char     tmp_qpt_bgn[6],tmp_qpt_end[6],tmp_rate[11],tmp_mprem[15],tmp_pextra_charge[9];
   	int      rows,tmp_len,i;
   	long     MsgCode;
   	DBinfo   *list;
   	int      k,j,is_add_fail=0, api_f;
   	$char    stmt_buf[500];
   	car106_t *alist;

   	cm_buf_get("%s %s %s %s %s %s %s",
		        DBName,icar_type,iins_type,fpt,ical_ins,fcal_class,str_rows);

   	rows=atoi(str_rows);

   	if(db_select(DBName) == False)
   	{
    	if( exitsub(reply,M_CM_DB_NOTOPEN) == True )
        	return M_CM_DB_NOTOPEN;
      	return apiRC;
   	}
	/* $BEGIN WORK;*/
	/* because this is single table head-detail, so mark it */
 	/* $INSERT INTO compulsory_premium (icar_type,qperiod,mpremium)
            VALUES ($cartype,$insperiod,$premium); */
   	alist = (car106_t *) malloc(rows * sizeof (car106_t));

   	for (k=0; k<rows; k++)
   	{
    	cm_buf_get("%l %s %s %s %s %s %s",
		        	&deduct,tmp_qpt_bgn,tmp_qpt_end,tmp_rate,tmp_mprem,tmp_pextra_charge,drate);
       	deccvasc( tmp_qpt_bgn, strlen(tmp_qpt_bgn), &dec_qpt_bgn);
       	dectodbl( &dec_qpt_bgn, &qpt_bgn);
       	deccvasc( tmp_qpt_end, strlen(tmp_qpt_end), &dec_qpt_end);
       	dectodbl( &dec_qpt_end, &qpt_end);
       	deccvasc( tmp_rate, strlen(tmp_rate), &dec_rate);
       	dectodbl( &dec_rate, &rate);
       	deccvasc( tmp_mprem, strlen(tmp_mprem), &dec_mprem);
       	dectodbl( &dec_mprem, &mprem);
       	deccvasc( tmp_pextra_charge, strlen(tmp_pextra_charge), &dec_pextra_charge);
       	dectodbl( &dec_pextra_charge, &pextra_charge);
       	alist[k].deduct= deduct;
       	alist[k].qpt_bgn=qpt_bgn;
       	alist[k].qpt_end=qpt_end;
       	alist[k].rate=rate;
       	alist[k].mprem=mprem;
       	alist[k].pextra_charge=pextra_charge;
       	strcpy(alist[k].drate,cm_to_infdate(drate));
   	}

 	if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
  	{
   		if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    	return M_CM_NOT_DBLIST;
   		return apiRC;
  	}

	$BEGIN WORK;

 	for(j=0;j<i;j++)
 	{
    	sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO %s:ca_rate "
      		   " (icar_type,iins_type,mdeduct,qpt_bgn,qpt_end,fpt,prate,mprem,pextra_charge,ical_ins,fcal_class,drate) "
      	" VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", list[j].dbname);
     	for (k=0; k<rows; k++)
     	{
        	$PREPARE b_id FROM $stmt_buf;
	 		deduct = alist[k].deduct;
  	 		qpt_bgn= alist[k].qpt_bgn;
	 		qpt_end= alist[k].qpt_end;
	 		rate=alist[k].rate;
        	mprem=alist[k].mprem;
        	pextra_charge=alist[k].pextra_charge;
        	strcpy(drate_e,alist[k].drate);
        	$EXECUTE b_id
        		USING $icar_type,$iins_type,$deduct,$qpt_bgn,$qpt_end,$fpt,$rate,$mprem,$pextra_charge,$ical_ins,$fcal_class,$drate_e;
        	if(SQLCODE != 0)
        	{
	        	is_add_fail = 3;
    	      	break;
       		}
    	}

     	if (is_add_fail == 3)
     	{
      		is_add_fail = 1;
		    break;
     	}

		cm_buf_init(ReplyBuf);
  		cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);
  		tmp_len = cm_buf_len(ReplyBuf);
  		if( j == i-1 )
    		api_f = api_OKComplete;
  		else
    		api_f = api_OK;

  		if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
    	{
    		is_add_fail = 2;
     		break;
    	}
 	} /* for loop */

	for (i = 0; i < rows; i++)
  		free( alist[i]);
	free ( (char *) alist);
	if( is_add_fail == 1 ) goto errexit;
	if( is_add_fail == 2 )
	{
   		$ROLLBACK WORK;
   		return apiRC;
  	}
   	$WHENEVER SQLERROR GOTO errexit;
   	$COMMIT WORK;
   	return api_OKComplete;

 errexit:
   	MsgCode = SQLCODE;
   	$WHENEVER SQLERROR CONTINUE;
   	$ROLLBACK WORK;
   	if( SQLCODE != 0) MsgCode = SQLCODE;
   	if(exitsub(reply,MsgCode) == True)
    	return MsgCode;
   	else
    	return apiRC;
}

/*--------------------------------------------------*/
long car106_single_query(reply)
serverReply reply;
{
    $char   DBName[3],instype[INSURANCE_TYPE],cartype[3],carins[INSURANCE_TYPE],caltype[2];
    $char   insname1[7],carname[11],insname2[7],drate_e[12],fpt[2],drate[10];
    $long   deduct,drate_l = 0,deduct_l = 0;
    $double qpt_bgn,qpt_end,rate = 0.0,mprem = 0.0,pextra_charge = 0.0;
    dec_t   dec_qpt_bgn,dec_qpt_end,dec_rate,dec_mprem,dec_pextra_charge;
    char    tmp_qpt_bgn[6],tmp_qpt_end[6],tmp_rate[11],tmp_mprem[15],tmp_pextra_charge[9];
    int     rows=0,tmp_len,first;
    char    strtmp0[50],strtmp1[50],strtmp2[50],strqptbgn[10],strqptend[10];

    cm_buf_get("%s %s %s %l %s %s %s",DBName,cartype,instype,&deduct,tmp_qpt_bgn,tmp_qpt_end,drate);

    deccvasc( tmp_qpt_bgn, strlen(tmp_qpt_bgn), &dec_qpt_bgn);
    dectodbl( &dec_qpt_bgn, &qpt_bgn);
    deccvasc( tmp_qpt_end, strlen(tmp_qpt_end), &dec_qpt_end);
    dectodbl( &dec_qpt_end, &qpt_end);
    strcpy(drate_e,cm_to_infdate(drate));

   	$WHENEVER SQLERROR GOTO errexit;

   	if (db_select(DBName) == False)
    	return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

   	cm_buf_init(ReplyBuf);
   	cm_buf_res_msg();
   	cm_buf_res_count();
      printf("instype[%s]\n",instype);

   	$SELECT nins_abbr
       INTO $insname1
       FROM insurance_type
      WHERE iins_type=$instype;

   	if(SQLCODE==SQLNOTFOUND)
	    return exitsub(reply,M_CA_NINS_TYPE) ? M_CA_NINS_TYPE : apiRC;

        printf("cartype[%s]\n",cartype);

   	if (strcmp(trim(instype),"12") == 0)
    	$SELECT ncode
           INTO $carname
           FROM car_type
          WHERE fclass="2" AND icode=$cartype;
   	else
    	$SELECT ncode
           INTO $carname
           FROM car_type
          WHERE fclass="1" AND icode=$cartype;
   
   	if(SQLCODE==SQLNOTFOUND)
    	return exitsub(reply,M_CA_NCARTYPE) ? M_CA_NCARTYPE : apiRC;

      printf("instype[%s],cartype[%s],drate_e[%s]\n",instype,cartype,drate_e);

   	$DECLARE q_cur CURSOR FOR
      SELECT fpt,prate,mprem,pextra_charge,
             ical_ins,fcal_class,drate,qpt_bgn,qpt_end,mdeduct 
        INTO $fpt,$rate,$mprem,$pextra_charge,
             $carins,$caltype,$drate_l,$qpt_bgn,$qpt_end,$deduct_l
        FROM ca_rate
       WHERE iins_type = $instype 
         AND icar_type = $cartype
         AND drate=$drate_e; 
/*	AND mdeduct=$deduct AND qpt_bgn=$qpt_bgn AND qpt_end=$qpt_end */

   	$OPEN q_cur;

	for(;;)
   	{
    	$FETCH q_cur;
      	if (SQLCODE != 0) break;
      
        first=0; 
        strcpy(insname2," ");
        strcpy(carins,trim(carins));

        if(carins[0]!='\0')
        {
            printf("carins[%s]\n",carins);

        	$SELECT nins_abbr INTO $insname2
               FROM insurance_type
              WHERE iins_type=$carins;

            if(SQLCODE==SQLNOTFOUND)
            {
               	if( exitsub(reply,M_CA_NINS_TYPE) == True )
                	return M_CA_NINS_TYPE;
               	return apiRC;
            }

        }

        sprintf_s(strqptbgn, sizeof strqptbgn,"%.1f",qpt_bgn);
        sprintf_s(strqptend, sizeof strqptend,"%.1f",qpt_end);
        strcpy(drate,cm_cdate_str_100(drate_l));

        cm_buf_put("%s %s %l %s %s %s %s %s %s %s %s %s",
          		    cartype,instype,deduct_l,strqptbgn,strqptend,fpt,
		            carins,caltype,insname1,carname,insname2,drate);
      
		rows++;

      	sprintf_s(strtmp0, sizeof strtmp0,"%.6f",rate);
      	sprintf_s(strtmp1, sizeof strtmp1,"%.5f",mprem);
      	sprintf_s(strtmp2, sizeof strtmp2,"%.4f",pextra_charge);

		cm_buf_put("%s %s %s %s",strtmp0,strtmp1,strtmp2,drate);
	}
   	$CLOSE q_cur;
   	$FREE q_cur;

   	if(rows > 0 || SQLCODE==0)      /* at least one row is selected */
   	{
    	cm_buf_put_msg(M_CM_OK);
      	cm_buf_put_count(rows);
      	tmp_len = cm_buf_len(ReplyBuf);
      	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        	return apiRC;
      	else
        	return api_OKComplete;
   	}
   	else
   	{
    	if( exitsub(reply,M_CA_NRATE) == True )
        	return M_CA_NRATE;
      	return apiRC;
   	}

errexit:
	if ( exitsub(reply,SQLCODE) == True )
    	return SQLCODE;
   	return apiRC;
}

/*--------------------------------------------------*/
long car106_multiple_query(reply)
serverReply reply;
{
	$char   DBName[3], k_instype[INSURANCE_TYPE],instype[INSURANCE_TYPE], k_cartype[3],cartype[3],drate_e[12];
   	$long   deduct = 0,drate_l = 0;
   	$char   str_qptend[10],str_qptbgn[10],str_drate_bgn[12],str_drate_end[12];
   	$char   str_rate[11],str_mprem[15],str_pextra_charge[9];
   	$double qpt_bgn,qpt_end,rate,mprem,pextra_charge;
   	char    tmpbuf[4000],drate[10];
   	dec_t   dec_qpt_bgn,dec_qpt_end,dec_rate,dec_mprem,dec_pextra_charge;
   	int     count=0,repbuf_len=0,tmp_len=0,replycnt=0;
   	int     i,total_count=0,flag;

    cm_buf_get("%s %s %s %s",DBName,k_cartype,k_instype,drate);

   	$WHENEVER SQLERROR GOTO errexit;

   	if (db_select(DBName) == False)
   	{
    	if( exitsub(reply,M_CM_DB_NOTOPEN) == True )
        	return M_CM_DB_NOTOPEN;
      	return apiRC;
   	}

   	if(drate[0] == '*')
    {
    	strcpy(str_drate_bgn,"01/01/1980");
      	strcpy(str_drate_end,"12/31/2999");
	}
   	else
    {
    	strcpy(str_drate_bgn,cm_to_infdate(drate));
      	strcpy(str_drate_end,cm_to_infdate(drate));
	}

   	$DECLARE m1_cur CURSOR FOR
      SELECT iins_type,icar_type,mdeduct,qpt_bgn,qpt_end,drate
        INTO $instype,$cartype,$deduct,$qpt_bgn,$qpt_end,$drate_l
        FROM ca_rate
       WHERE iins_type matches $k_instype 
         AND icar_type matches $k_cartype
         AND drate >=$str_drate_bgn 
         AND drate <=$str_drate_end
       ORDER BY iins_type,icar_type,mdeduct,qpt_bgn,qpt_end;

	$OPEN m1_cur;

   	for(;;)
   	{
    	$FETCH m1_cur;
     	if (SQLCODE != 0) break;

      	cm_buf_init(tmpbuf);

      	if ( count == 0 )
      	{
        	cm_buf_res_msg();             /* reserve for MsgCode and count */
         	cm_buf_res_count();
      	}

      	strcpy(drate,cm_cdate_str_100(drate_l));

      	if(strlen(itoa(qpt_bgn))<=0 )
      	{
	  		qpt_bgn=0; 
     	}

	    if(strlen(itoa(qpt_end))<=0 )
    	{
	  		qpt_end=0;
      	}

		sprintf_s(str_qptbgn, sizeof str_qptbgn,"%.1f",qpt_bgn);
      	sprintf_s(str_qptend, sizeof str_qptend,"%.1f",qpt_end);
      	/*sprintf_s(str_rate, sizeof str_rate,"%.2f",rate);*/

      	cm_buf_put("%s %s %l %s %s %s",cartype,instype,deduct,str_qptbgn,str_qptend,drate);

      	tmp_len = cm_buf_len(tmpbuf);

      	if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
      	{
        	memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
         	repbuf_len += tmp_len;
         	count++;
     	}
      	else                               /* more than 4K, send to client side */
      	{
        	cm_buf_init(ReplyBuf);
         	cm_buf_put_msg(M_CM_OK);
         	cm_buf_put_count(count);
         	if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
         	{
            	$CLOSE m1_cur;
	    		$FREE m1_cur;
            	return apiRC;
			}
        	else               /* clear ReplyBuf and count to start all over again */
        	{
            	replycnt++;
	            if (replycnt == 10)   /* more than 30K, client cannot display,error */
    	        {
        	       	cm_buf_init(ReplyBuf);
            	   	cm_buf_put("%l",M_CM_OUT_SPACE);
	               	tmp_len = cm_buf_len(ReplyBuf);
               		if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
                  	return apiRC;
               		return M_CM_OUT_SPACE;
            	}
            	ReplyBuf[0] = '\0';
            	count = 0;
            	cm_buf_init(ReplyBuf);
            	cm_buf_res_msg();           /* reserve for MsgCode and count */
            	cm_buf_res_count();
            	strcpy(drate,cm_cdate_str_100(drate_l));
	      		sprintf_s(str_qptbgn, sizeof str_qptbgn,"%.1f",qpt_bgn);
      			sprintf_s(str_qptend, sizeof str_qptend,"%.1f",qpt_end);
      			/*sprintf_s(str_rate, sizeof str_rate,"%.2f",rate);*/
      			cm_buf_put("%s %s %l %s %s %s",cartype,instype,deduct,str_qptbgn,str_qptend,drate);
            	repbuf_len = cm_buf_len(ReplyBuf);
            	count++;
        	}
		}
	} /* for loop */

   	$CLOSE m1_cur;
   	$FREE m1_cur;

   	if (count > 0)   /* break out, at least one record is selected */
   	{
      	cm_buf_init(ReplyBuf);
      	cm_buf_put_msg(M_CM_OK);
      	cm_buf_put_count(count);
      	if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
        	return apiRC;
      	return api_OKComplete;
   	}
   	else            /* break out, not any raw is found */
   	{
    	if( exitsub(reply,M_CA_NRATE) == True )
        	return M_CA_NRATE;
      	return apiRC;
   	}

errexit:
   	if ( exitsub(reply,SQLCODE) == True )
    	return SQLCODE;
   	return apiRC;
}

/*--------------------------------------------------*/
long car106_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	$char   DBName[3],instype[INSURANCE_TYPE],cartype[3],carins[INSURANCE_TYPE],caltype[2],strqptbgn[10];
   	$char   insname1[7],carname[11],insname2[7],drate_e[12],fpt[2];
   	$long   deduct = 0,drate_l = 0,old_deduct,deduct_tmp,deduct_l;
   	$double qpt_bgn,qpt_end,rate,mprem,pextra_charge;
   	$double cur_qpt_bgn,cur_qpt_end,n_qpt_bgn,n_qpt_end;
   	$long   cur_deduct,cur_mdeduct;
   	$char   old_drate_e[12];
   	$char   drate_n[12];

    dec_t  dec_rate,dec_mprem,dec_pextra_charge;
    dec_t  dec_cur_rate,dec_cur_mprem,dec_cur_pextra_charge,dec_qpt_bgn,dec_qpt_end;
    char   str_deduct[9];
    char   tmp_qptbgn[6],tmp_qptend[6],tmp_drate[10];
    char   tmp_rate[11],tmp_mprem[15],tmp_pextra_charge[9];

    int    tmp_len,raw_len,count,rows=0,i,flag,count1,y;
    char   strtmp0[50],strtmp1[50],strtmp2[50];
    char   old_drate[10],stqqptbgn[10],strqptend[10];

   	$char   cur_instype[INSURANCE_TYPE],cur_cartype[3],cur_carins[INSURANCE_TYPE],cur_caltype[2];
	$char   cur_fpt[2], cur_qptbgn[10],cur_qptend[10],cur_drate[11],drate[12];
   	$double cur_rate = 0.0,cur_mprem = 0.0,cur_pextra_charge = 0.0;

    char  cur_insname1[7],cur_carname[11],cur_insname2[7];
    char  tmp_cur_rate[21],tmp_cur_mprem[15],tmp_cur_pextra_charge[21];
    char  option,*pos,*raw_ptr,cur_buf[10000],*comm,type;
    long  dummy;
    long  MsgCode;
    int   first;
    int   k, j, is_del_fail=0, is_upd_fail=0;
   	$char  stmt_buf[500];

	car106_t *alist;
    DBinfo   *list;
   
   	memset(instype,0,sizeof(instype));
   	memset(cur_instype,0,sizeof(cur_instype));
   	memset(cur_cartype,0,sizeof(cur_cartype));
   	memset(insname1,0,sizeof(insname1));
   	memset(insname2,0,sizeof(insname2));
   	memset(carname,0,sizeof(carname));

   	comm = (char *) command;
   	cm_buf_init(command);
   	cm_buf_get("%c %s",&option,DBName);

   	$WHENEVER SQLERROR GOTO errexit;

   	if (db_select(DBName) == False)
    	return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

 	if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
		return exitsub(reply,M_CM_NOT_DBLIST) ? M_CM_NOT_DBLIST : apiRC;

   /* compare old record and current record, if the record has not been changed
      since last request, update or delete the record, otherwise return errmsg
      to client side */
   /* get old record info from command buffer */
	memcpy(&raw_len,&comm[com_len],sizeof(int));
   	pos = &comm[com_len+sizeof(int)];
   	raw_ptr = malloc(raw_len);

   	if (raw_ptr != (char*)0)
    	memcpy(raw_ptr,pos,raw_len);
   	else
   	{/* malloc fail */
    	return exitsub(reply,M_CM_NOT_MALLOC) ? M_CM_NOT_MALLOC : apiRC;
   	}

   /* get index key from old record, dummy is the MsgCode */

   	cm_buf_init(raw_ptr);
   	cm_buf_get("%l %d",&dummy,&count);
   	count1=count;
   	cm_buf_get("%s %s %l %s %s %s %s %s %s %s %s %s",
			    cartype,instype,&deduct_l,strqptbgn,strqptend,fpt,
			    carins,caltype,insname1,carname,insname2,drate);

	strcpy(drate,cm_to_infdate(drate));
	strcpy(cur_cartype,cartype);
  	strcpy(cur_instype,instype);

   	$BEGIN WORK;

   	cm_buf_init(cur_buf);    /* must reserve msg and count for comparison */
   	cm_buf_res_msg();
   	cm_buf_res_count();

   	$SELECT nins_abbr
       INTO $insname1
       FROM insurance_type
      WHERE iins_type=$cur_instype;
    if(SQLCODE==SQLNOTFOUND)
    {
    	$WHENEVER SQLERROR CONTINUE;
      	$ROLLBACK WORK;
      	return exitsub(reply, M_CA_NINS_TYPE) ? M_CA_NINS_TYPE : apiRC;
   	}
 	
   	$WHENEVER SQLERROR GOTO errexit;

   	if (strcmp(trim(cur_instype),"12") == 0)
    	$SELECT ncode
           INTO $carname
           FROM car_type
          WHERE fclass="2" AND icode=$cur_cartype;
   	else
    	$SELECT ncode
           INTO $carname
           FROM car_type
          WHERE fclass="1" AND icode=$cur_cartype;
   	if(SQLCODE==SQLNOTFOUND)
   	{
    	$WHENEVER SQLERROR CONTINUE;
      	$ROLLBACK WORK;
      	return exitsub(reply, M_CA_NCARTYPE) ? M_CA_NCARTYPE : apiRC;
   	}

   	$WHENEVER SQLERROR GOTO errexit;

   	cm_buf_put_msg(dummy);
   	cm_buf_put_count(count);

   	$DECLARE u_cur CURSOR FOR
      SELECT fpt,prate,mprem,pextra_charge,drate,
             ical_ins,fcal_class,qpt_bgn,qpt_end,mdeduct
        INTO $cur_fpt,$cur_rate,$cur_mprem,$cur_pextra_charge,$drate_l,
             $cur_carins,$cur_caltype,$qpt_bgn,$qpt_end,$deduct
        FROM ca_rate
       WHERE iins_type=$cur_instype 
         AND icar_type=$cur_cartype
         AND drate=$drate;
             
/*	AND mdeduct=$cur_deduct AND qpt_bgn=$qpt_bgn AND qpt_end=$qpt_end AND drate=$drate_e;*/

   	$OPEN u_cur;

   	rows=0;

   	for(;;)
   	{
    	$FETCH u_cur;
      	if (SQLCODE == SQLNOTFOUND) break;
/*	first=0;*/
/*	memset(insname2,0,sizeof(insname2));*/

    strcpy(insname2," ");
        strcpy(cur_carins,trim(cur_carins));

    if(cur_carins[0]!='\0')
    {
    	$SELECT nins_abbr
           INTO $insname2
           FROM insurance_type
          WHERE iins_type=$cur_carins;
        if(SQLCODE==SQLNOTFOUND)
        	return exitsub(reply,M_CA_NINS_TYPE) ? M_CA_NINS_TYPE : apiRC;
    }

    sprintf_s(cur_qptbgn, sizeof cur_qptbgn,"%.1f",qpt_bgn);
    sprintf_s(cur_qptend, sizeof cur_qptend,"%.1f",qpt_end);
    strcpy(cur_drate,cm_cdate_str_100(drate_l));

    cm_buf_put("%s %s %l %s %s %s %s %s %s %s %s %s",
                cur_cartype,cur_instype,deduct,cur_qptbgn,cur_qptend,cur_fpt,
                cur_carins,cur_caltype,insname1,carname,insname2,cur_drate);

	sprintf_s(strtmp0, sizeof strtmp0,"%.6f",cur_rate);
	sprintf_s(strtmp1, sizeof strtmp1,"%.5f",cur_mprem);
	sprintf_s(strtmp2, sizeof strtmp2,"%.4f",cur_pextra_charge);

    rows++;

    cm_buf_put("%s %s %s %s",strtmp0,strtmp1,strtmp2,cur_drate);

   	}/* end of for */
   	$CLOSE u_cur;
   	$FREE u_cur;

printf("1 count=%d\n",count);
printf("1 ROWS=%d\n",rows);

   	if(rows != count)      /* at least one row is selected */
   	{
      	MsgCode = M_CM_NOT_EQUAL;
      	$WHENEVER SQLERROR CONTINUE;
      	$ROLLBACK WORK;
      	if( SQLCODE != 0) MsgCode = SQLCODE;
      	return exitsub(reply,MsgCode) ? MsgCode : apiRC;
/*	cm_buf_put("%s %l %s",strtmp,cur_mprem,cur_drate);  */
      	cm_buf_put("%s",strtmp0);
      	cm_buf_put("%s",strtmp1);
      	cm_buf_put("%s",strtmp2);
      	cm_buf_put("%s",cur_drate);
	} /* end of for */
   	$CLOSE u_cur;
   	$FREE u_cur;
printf("2 count=%d\n",count);
printf("2 ROWS=%d\n",rows);

   	if(rows != count)      /* at least one row is selected */
   	{
      	MsgCode = M_CM_NOT_EQUAL;
      	$WHENEVER SQLERROR CONTINUE;
      	$ROLLBACK WORK;
      	if( SQLCODE != 0) MsgCode = SQLCODE;
      	return exitsub(reply,MsgCode) ? MsgCode : apiRC;
   	}
   	$WHENEVER SQLERROR GOTO errexit;

	write(1, cur_buf, raw_len); printf("]\n[");
	write(1, raw_ptr, raw_len); printf("]\n");
	
	free(raw_ptr);
    
    /* compare 2 records, not equal */
    /*
   	if (memcmp(cur_buf,raw_ptr,raw_len) != 0) 
   	{
      	MsgCode = M_CM_NOT_EQUAL;
      	$WHENEVER SQLERROR CONTINUE;
      	$ROLLBACK WORK;
      	if( SQLCODE != 0) MsgCode = SQLCODE;
      	return exitsub(reply,MsgCode) ? MsgCode : apiRC;
   	}*/
   	$WHENEVER SQLERROR GOTO errexit;

   	/* equal, then exec DB operation */
   	if( option == 'D' )
   	{
    	for(j=0;j<i;j++)
    	{
      		sprintf_s(stmt_buf, sizeof stmt_buf,
         	"DELETE FROM %s:ca_rate WHERE iins_type=? AND icar_type=? AND drate=? ",
             list[j].dbname);
       		$PREPARE d_id FROM $stmt_buf;
       		$EXECUTE d_id USING $cur_instype,$cur_cartype,$drate;
     	}
     	cm_buf_init(ReplyBuf);
     	cm_buf_put("%l", M_CM_OK);
     	tmp_len = cm_buf_len(ReplyBuf);
     	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
     	{
        	$WHENEVER SQLERROR CONTINUE;
         	$ROLLBACK WORK;
         	return apiRC;
     	}
     	$WHENEVER SQLERROR GOTO errexit;
     	$COMMIT WORK;
     	return api_OKComplete;
   	}
   	else if(option == 'U')
   	{
    	cm_buf_init(command);
    		printf("--751 -- \n");
      	cm_buf_get("%c %s",&option,DBName);
      	printf("--753 -- \n");
      	cm_buf_get("%s %s %s %s %s",cartype,instype,fpt,carins,caltype);

      	/*if ( !strcmp(instype,cur_instype) && !strcmp(cartype,cur_cartype))
        	flag = 0;
      	else
      	{
      		flag = 1;
 for head-table is the same of the detail-table, so mark it ? 
      	}*/

      	cm_buf_get("%d",&rows);
      	alist = (car106_t *) malloc(rows *sizeof (car106_t));

      	for (k = 0; k <rows; k++)
      	{
       		cm_buf_get("%c %s %s %s %s %s %s %s",&type,str_deduct,tmp_qptbgn,tmp_qptend,
       		                                      tmp_rate,tmp_mprem,tmp_pextra_charge,tmp_drate);

       		deduct_tmp=atoi(str_deduct);
	       	deccvasc( tmp_qptbgn, strlen(tmp_qptbgn),&dec_qpt_bgn);
    	   	dectodbl( &dec_qpt_bgn, &qpt_bgn);
       		deccvasc( tmp_qptend, strlen(tmp_qptend),&dec_qpt_end);
       		dectodbl( &dec_qpt_end, &qpt_end);
       		deccvasc( tmp_rate, strlen(tmp_rate), &dec_rate);
       		dectodbl( &dec_rate, &rate);
       		deccvasc( tmp_mprem, strlen(tmp_mprem), &dec_mprem);
       		dectodbl( &dec_mprem, &mprem);
       		deccvasc( tmp_pextra_charge, strlen(tmp_pextra_charge), &dec_pextra_charge);
       		dectodbl( &dec_pextra_charge, &pextra_charge);
       		alist[k].type = type;
       		alist[k].deduct=deduct_tmp;
       		alist[k].qpt_bgn=qpt_bgn;
       		alist[k].qpt_end=qpt_end;
       		alist[k].rate=rate;
       		alist[k].mprem=mprem;
       		alist[k].pextra_charge=pextra_charge;
        	strcpy(alist[k].drate,cm_to_infdate(tmp_drate));
		}

    	$WHENEVER SQLERROR GOTO errexit;
    	/* *** for ervery database *** */
    	for(j=0; j<i; j++)
    	{
    		/*sprintf_s(stmt_buf, sizeof stmt_buf,
        		"DELETE FROM %s:ca_rate WHERE iins_type=? AND icar_type=? AND drate =? ",list[j].dbname);
        	$PREPARE ty_id FROM $stmt_buf;
        	$EXECUTE ty_id USING $cur_instype,$cur_cartype,$drate;*/
        	/* *** data come from client list box *** */
        	for(k=0; k < rows; k++)
			{
           		deduct_tmp =alist[k].deduct;
           		qpt_bgn=alist[k].qpt_bgn;
           		qpt_end=alist[k].qpt_end;
           		rate= alist[k].rate;
           		mprem=alist[k].mprem;
         		pextra_charge= alist[k].pextra_charge;
           		strcpy(drate_e,alist[k].drate);
            	/*if(alist[k].type!='D')
	    		{
               		deduct_tmp =alist[k].deduct;
               		qpt_bgn=alist[k].qpt_bgn;
               		qpt_end=alist[k].qpt_end;
               		rate= alist[k].rate;
               		mprem=alist[k].mprem;
               		pextra_charge= alist[k].pextra_charge;
               		strcpy(drate_e,alist[k].drate);
               		sprintf_s(stmt_buf, sizeof stmt_buf,
                 	
                 	"INSERT INTO %s:ca_rate(icar_type,iins_type,mdeduct,qpt_bgn,\
			        	                    qpt_end,fpt,prate,mprem,pextra_charge,ical_ins,\
			            	                fcal_class,drate)\
		            	VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",list[j].dbname);
               		$PREPARE u1_id FROM $stmt_buf;
               		$EXECUTE u1_id USING $cartype,$instype,$deduct_tmp,$qpt_bgn,
                    		             $qpt_end,$fpt,$rate,$mprem,$pextra_charge,$carins,$caltype,$drate_e;
	    		}*/
                switch(alist[k].type)
                {
                	case 'A':
                    	sprintf_s(stmt_buf, sizeof stmt_buf,
                    	"INSERT INTO %s:ca_rate "
                                  " (icar_type,iins_type,mdeduct,qpt_bgn,qpt_end,fpt, "
                                  " prate,mprem,pextra_charge,ical_ins,fcal_class,drate) "
                         " VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",list[j].dbname);
						$PREPARE u1_id FROM $stmt_buf;
						$EXECUTE u1_id USING $cartype,$instype,$deduct_tmp,$qpt_bgn,$qpt_end,$fpt,
                 		                     $rate,$mprem,$pextra_charge,$carins,$caltype,$drate_e;
						if(SQLCODE != 0)
                        	is_upd_fail = 3;
						break;
					case 'D':
                    	sprintf_s(stmt_buf, sizeof stmt_buf,
                    	"DELETE FROM %s:ca_rate "
                       	" WHERE icar_type=? AND iins_type=? AND mdeduct=? "
                       	"   AND qpt_bgn=? AND qpt_end=? AND drate=?",list[j].dbname);
						$PREPARE u2_id FROM $stmt_buf;
                        $EXECUTE u2_id USING $cartype,$instype,$deduct_tmp,
                                             $qpt_bgn,$qpt_end,$drate_e;
						if(SQLCODE != 0)
                        	is_upd_fail = 3;
						break;
                    case 'U':
                       	sprintf_s(stmt_buf, sizeof stmt_buf,
                       	"UPDATE %s:%s SET (%s %s)=(%s) %s %s",list[j].dbname,"ca_rate",
                   	   			"icar_type,iins_type,mdeduct,qpt_bgn,qpt_end,fpt,",
                   				"prate,mprem,pextra_charge,ical_ins,fcal_class,drate",
                           		"?,?,?,?,?,?,?,?,?,?,?,?",
                               	"WHERE icar_type=? AND iins_type=? AND mdeduct=?",
                               	"AND qpt_bgn=? AND qpt_end=? AND drate=?");
                       	$PREPARE u3_id FROM $stmt_buf;
                       	$EXECUTE u3_id USING $cartype,$instype,$deduct_tmp,$qpt_bgn,$qpt_end,$fpt,
                       	                     $rate,$mprem,$pextra_charge,$carins,$caltype,$drate_e,
                                             $cartype,$instype,$deduct_tmp,
                                             $qpt_bgn,$qpt_end,$drate_e;
						if(SQLCODE != 0)
                           	is_upd_fail = 3;
						break;
					default:
                        $WHENEVER SQLERROR CONTINUE;
                        $ROLLBACK WORK;
                        if(exitsub(reply,M_CM_WRONG_OPTION) == True)
                        	return M_CM_WRONG_OPTION;
						else
                           	return apiRC;
				}
			}
		} /* for loop */
		
		for (i = 0; i < rows; i++)
			free( alist[i]);
		free ( (char *) alist);
		
    	cm_buf_init(ReplyBuf);
    	cm_buf_put("%l",M_CM_OK);
    	tmp_len = cm_buf_len(ReplyBuf);
    	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    	{
    		$WHENEVER SQLERROR CONTINUE;
        	$ROLLBACK WORK;
        	return apiRC;
    	}
	    $WHENEVER SQLERROR GOTO errexit;
    	$COMMIT WORK;
    	return api_OKComplete;
   	}
   	else    /* option is not 'D' or 'U' */
   	{
    	return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
   	}

errexit:
	MsgCode = SQLCODE;
	$WHENEVER SQLERROR CONTINUE;
   	$ROLLBACK WORK;
   	if( SQLCODE != 0) MsgCode = SQLCODE;
   	return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
/*--------------------------------------------------*/
