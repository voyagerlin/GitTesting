/**********************************************************************/
/*   program id   : ca208q02s.ec                                      */
/*   program name : �O�I�Ҳ��ʩ��Ӫ�(��J�ɮ�&�ץX����)               */
/*   date written : 2014/04/14                                        */
/*   date modify  : yyyy/mm/dd                                        */
/*   author       : Larry Liao                                        */                                       
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>

/*----------------------------------------------------------------------------*/
char  msgbuf[1024];
$char date[11],dToday[11],nyy[4],nmm[3],ndd[3];
char  sApHome[50];
$char DBName[05];
$char userid[11];
char  filename[1024];
int   flen;
FILE   *fp;
DBinfo *list;
$char sdata[2][21];
int   count_db,i,cnt;
long  t;
$char sForm[2],GetFileName[80];
char  outputf[N_FILE+1];

char *get_car_full_db();
/*----------------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{  
	int return_code;

	batchinit();
	strcpy(DBName, 		  isNULLstr(argv[1]));
	strcpy(userid, 		  isNULLstr(argv[2]));
	strcpy(sForm,       isNULLstr(argv[3])); /* ���� - 1:���� 2:�Ϳ��榡 */
	strcpy(GetFileName, isNULLstr(argv[4]));
	strcpy(outputf,		  isNULLstr(argv[5]));
	
	printf("--[%s]---1:����,2:�Ϳ��榡-----\n",sForm);
	
	return_code = car2082_get_db();
	if (return_code != M_CM_OK) {
		EWRITE(userid,return_code,msgbuf);
		return return_code;
	}
	
	return_code = car2082_init_data();
  if (return_code != M_CM_OK) {
     printf("error on car2082_init_data\n");
		 EWRITE(userid,return_code,"�إ� temp table ���~!");
		 return return_code;
	}

  return_code = car2082_read_data();
  if (return_code != M_CM_OK) {
		 EWRITE(userid, return_code, "�ɮ���J���~!");
		 return return_code;
	}
		
	if (strncmp(sForm,"1",1) == 0)
	{	  
	  return_code = car2082_query_detail();
    if (return_code != M_CM_OK) {
    	printf("error on car2082_query_detail\n");
		  EWRITE(userid, return_code, "�d�ߩ��Ӹ�Ʀ��~");
		  return return_code;
	  }
	  
	  return_code = car2082_print_detail();
    if (return_code != M_CM_OK) {
        printf("error on car2082_print_detail\n");
        EWRITE(userid, return_code, "�������Ӳ��s���~!");
        return return_code;
    }    
  }
  else
  {
  	return_code = car2082_query_ks();
    if (return_code != M_CM_OK) {
    	printf("error on car2082_query_ks\n");
		  EWRITE(userid, return_code, "�d�߳Ϳ�������Ʀ��~");
		  return return_code;
	  }
  	
  	return_code = car2082_print_ks();
    if (return_code != M_CM_OK) {
      printf("error on car2082_print_ks\n");
      EWRITE(userid, return_code, "����(�Ϳ��榡)���s���~!");
      return return_code;
    }
  }
  
  /* �O�I�Ҹ����s�b��Ʈw */
  if (cnt > 0)
  {
  	return_code = car2082_card_notfound();
    if (return_code != M_CM_OK) {
      printf("error on car2082_card_notfound\n");
      EWRITE(userid, return_code, "���s�ɮצ��~!");
      return return_code;
    }
  }
  
	printf("[car2082]:process ok!\n"); 
}
/*----------------------------------------------------------------------------*/
long car2082_get_db()
{
	int return_code;

	if (db_select(DBName) == False) {
		strcpy(msgbuf,"��Ʈw�L�k�}��");
		return M_CM_DB_NOTOPEN;
	}
	return_code = getApHome(sApHome);
	if (return_code < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		return return_code;
  }
  
  return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car2082_read_data()
{
    char   *bp;
    int    rc,j,k,m,n,i;
    $int   iChkDays;
    $char  icard[21];
    
		printf("BEGIN TO READ DATA\n");    

    $WHENEVER SQLERROR GOTO errexit;

    cnt = 0;
    strcpy(GetFileName, trim(GetFileName));
    sprintf(filename,"%s/dat/car/%s",sApHome,GetFileName);
    flen=1024;
    if ((fp=fopen(filename,"r"))==NULL) {
       sprintf(msgbuf,"%s �ɮ׶}�ҥ���",filename);
       EWRITE(userid,FALSE,msgbuf);
       return FALSE;
    }
    if ((bp=malloc(flen))==NULL) {
       sprintf(msgbuf,"System malloc failed !");
       EWRITE(userid,FALSE,msgbuf);
       return FALSE;
    }
		
    for (i=0;(feof(fp)==0);i++) 
	  {
		    memset(bp,0x00,flen);
		    fgets(bp,flen,fp);
		        
		    if (bp[0]==0x00)	break;
		    if (strlen(trim(bp))<10)	break;
		        	
		    for(j=0;j<500;j++)
		    sdata[j][0]='\0';
		            
		    k=m=n=0;
		    for (j=0;j<flen;j++) 
		    {
		        if (bp[j]=='\0' || bp[j]=='\n' || bp[j] == ',' || bp[j] == '\t') 
					  {
		            strncpy(sdata[k],bp+m,j-m);
		            sdata[k][j-m]='\0';
		            m=j+1;
		            k++;
		        }
		        if (bp[j]=='\n'|| bp[j]=='\n' || bp[j] == ',' || bp[j] == '\t')	break;
		        if (k > 0) break;
		    }      
				printf("-----icard[%s]-----\n",sdata[0]);
		    strcpy(icard,trim(sdata[0]));

		    if (strlen(icard) == 0) break;

		    rc = car2082_insert_card();
		    if (rc != M_CM_OK)  return M_CM_FORMAT;
		}
		    
    fclose(fp);	 
    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car2082_insert_card()
{
    $char sIcard[21],iIcard[21];
    $int  comp_cnt,card_cnt;
    
    $WHENEVER SQLERROR GOTO errexit;

	  strcpy(iIcard,sdata[0]);
	  if (strncmp(iIcard,"17",2) == 0)
	  {
	  	 strcpy(sIcard,substring(iIcard,3,18));
	  }
	  else
	  {
	  	 strcpy(sIcard,trim(iIcard));
	  }

	  $SELECT count(icard) INTO $comp_cnt
	     FROM compulsory_card
	    WHERE icard = $sIcard;
	    
    printf("------sIcard[%s]----\n",sIcard);	     
	  if (comp_cnt > 0)
	  {
	  	  printf("sIcard[%s]\n",sIcard);
	      $INSERT INTO car2082_Y VALUES($sIcard);
	  }
	  else
	  {
	  	  
	    	$SELECT count(icard) INTO $card_cnt
	         FROM card
	        WHERE icard = $sIcard;
	      if (card_cnt > 0){ 
	      	$INSERT INTO car2082_Y VALUES($sIcard);
	      }
	      else{
	      	cnt++;
	      	$INSERT INTO car2082_N VALUES($sIcard);
	      }
	  }	  	

	  return M_CM_OK;  
	  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car2082_init_data()
{   
     $WHENEVER SQLERROR GOTO errexit;
    
     t = cm_today();
     strcpy(date,cm_edate_str(t));  
     strcpy(dToday,cm_from_infdate_100(date));
     cm_split_ymd_100(dToday,nyy,nmm,ndd);
	  
	 if (strncmp(sForm,"1",1) == 0)
	 {	   
	  $create temp table car2082_1(
	      inventory_nbranch char(40),  /*�L�I���*/
	  	  nchi_full         char(40),  /*�ӻ���*/
	  	  icard             char(20),  /*�O�I����*/
	  	  dissue            char(9),   /*�ӻ��*/
	  	  ndissue           char(10),  /*�ӻ�H*/
	  	  dreceive          char(9),   /*�������*/
	  	  icar_type         char(2),   /*����*/
	  	  fstatus           char(20),  /*���ʪ��A*/
	  	  ipolicy           char(20),  /*�O�渹�X*/
	  	  sIdeliver_nbranch char(40),  /*�t�o�g����*/
	  	  ideliver          char(10),  /*�t�o�g��H*/
	  	  ndeliver          char(10),  /*�g��H*/
	  	  nleader           char(10),  /*�t�o�g��H�̷s�޲z�H*/
	  	  ileader           char(10),  /*�t�o�g��H�̷s�޲z�H�N��*/
	  	  ddeliver          char(9),   /*�t�o���*/
	  	  dalter            char(9),   /*���ʤ��*/
	  	  ialter            char(10),  /*���ʤH�N��*/
	  	  nalter            char(10),  /*���ʤH��*/
	  	  bh_ialter         char(40),  /*���ʤH�����*/
	  	  iend_type         char(4),    /*���O*/
	  	  sDdeliver_old_100 char(10),
	  	  sFin_out_char     char(8),
	  	  limit_date_100    char(10),
	  	  cnt_lastday_char  char(4)

	  )with no log;
	 }
	 else
	 {
	 	 $create temp table car2082_2(
	 	    dalter         char(7),   /* ���ʤ���ɶ� */
	 	    ibus_location  char(10),  /* �g�P�ӧO */
	 	    icard_type     char(1),   /* �O�d���O */
	 	    icard          char(20),  /* �O�I�Ҹ� */
	 	    fstatus        char(2)    /* �@�o���A */
	 	 )with no log;
	 }
	   
	  /* �s�b��Ʈw���d�� */
	  $create temp table car2082_Y(
	     icard          char(20)   /* �j���Ҹ�/���N�d�� */
	  )with no log;
	  
	  /* ���s�b��Ʈw���d�� */
	  $create temp table car2082_N(
	     icard          char(20)   /* �j���Ҹ�/���N�d�� */
	  )with no log;
	  
	  return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car2082_query_detail()
{
   int	rc;
   $char stmt[8000];
   $varchar sNchi_full[41],sIalter_bh[41];
   $char sIcard[21],sDissue[11],sNdissue[21],sDreceive[11];
   $char sIcar_type[11],sFstatus[20],sIpolicy[21],sIdeliver[21],sNdeliver[21];
   $char sIleader[11],sNleader[21],sDdeliver[11],sDalter[11],sIalter[21];
   $char sNalter[21],sIbranch[3],sIend_type[5],fstatus[3];
   $char dissue[11],dreceive[11],ddeliver[11],dalter[11],iFstatus[3];
   $char Full_DBName[40],sStmt[512];
   $int  sCover;
   $char  sTmpPolicy1[14], sTmpPolicy2[8];
   
   $char sIofficer[11],inventory_nbranch[41],sIdeliver_nbranch[41];
   $char sDdeliver_old[11],sFin_out[2],sDdeliver_old_100[11];
   $char fin_out[2];
   $char sFin_out_char[9],cnt_lastday_char[4];
   $char limit_date[11],sys[11],limit_date_100[11];
   $int sys_int,limit_date_int,cnt_lastday;
   
   $whenever sqlerror goto errexit;
   
   sprintf(stmt,"SELECT (SELECT nchi_full FROM branch WHERE ibranch = a.iissue_branch) as nchi_full,"
                "        a.icard, a.dissue, a.iofficer, a.dreceive, a.icar_type,"
                "        CASE WHEN a.fstatus != '7' "
                "        THEN decode(a.fstatus,'0','���X','1','�P��','2','�L��','3','�@�o','4','��', "
                "                    '5','�@�o�ܥ��X','6','���ܥ��X','8','������', "
                "                    'A','µ�����~','B','���Ƨ�O', "
                "                    'C','�ܺʲz����ӥ��L','D','���ϥΧ@�o','E','���l',' ') "
                "        ELSE CASE WHEN a.fstatus = '7' AND a.dreceive is not null "
                "             THEN '�t�o��' ELSE '�����' END END, "
                "        a.ipolicy, a.ideliver, "
                "       (SELECT nname FROM officer WHERE iofficer = a.ideliver), "
                "       (SELECT ileader FROM officer WHERE iofficer = a.ideliver) as ileader, "
                "        a.ddeliver, a.dalter, a.ialter, "
                "       (SELECT nname FROM officer WHERE iofficer = a.ialter), "
                "       (SELECT ibranch FROM officer WHERE iofficer = a.ialter),a.fstatus,iofficer "
                "  FROM compulsory_card a "
                " WHERE a.icard in (SELECT icard FROM car2082_Y) "
                " UNION "
                "SELECT (SELECT nchi_full FROM branch WHERE ibranch = a.iissue_branch) as nchi_full,"
                "        a.icard, a.dissue, a.iofficer, a.dreceive, a.icar_type,"
                "        CASE WHEN a.fstatus != '7' "
                "        THEN decode(a.fstatus,'0','���X','1','�P��','2','�L��','3','�@�o','4','��', "
                "                    '5','�@�o�ܥ��X','6','���ܥ��X','8','������', "
                "                    'A','µ�����~','B','���Ƨ�O', "
                "                    'C','�ܺʲz����ӥ��L','D','���ϥΧ@�o','E','���l',' ') "
                "        ELSE CASE WHEN a.fstatus = '7' AND a.dreceive is not null "
                "             THEN '�t�o��' ELSE '�����' END END, "
                "        a.ipolicy, a.ideliver, "
                "       (SELECT nname FROM officer WHERE iofficer = a.ideliver), "
                "       (SELECT ileader FROM officer WHERE iofficer = a.ideliver) as ileader, "
                "        a.ddeliver, a.dalter, a.ialter, "
                "       (SELECT nname FROM officer WHERE iofficer = a.ialter), "
                "       (SELECT ibranch FROM officer WHERE iofficer = a.ialter),a.fstatus,iofficer "
                "  FROM card a"
                " WHERE a.icard in (SELECT icard FROM car2082_Y) ");
                
    printf("Query_detail - stmt[%s]\n",stmt);
    $PREPARE tempcur FROM $stmt;
    $DECLARE card_cur CURSOR FOR tempcur;
    $OPEN    card_cur;
    
    for(;;)
    {  
        $FETCH card_cur INTO $sNchi_full,$sIcard,$sDissue,$sNdissue,$sDreceive,
                             $sIcar_type,$sFstatus,$sIpolicy,$sIdeliver,$sNdeliver,
                             $sIleader,$sDdeliver,$sDalter,$sIalter,$sNalter,
                             $sIbranch,$iFstatus,$sIofficer;                       
        if (SQLCODE==SQLNOTFOUND) break;
        	
        strcpy(sDdeliver,trim(sDdeliver));
        strcpy(dissue,  cm_from_infdate_100(sDissue));
        strcpy(dreceive,cm_from_infdate_100(sDreceive));
        strcpy(ddeliver,cm_from_infdate_100(sDdeliver));
        strcpy(dalter,  cm_from_infdate_100(sDalter));  
        
        if(sDdeliver[0] == '')
		{
			$SELECT nchi_full INTO $inventory_nbranch
			 FROM branch 
			WHERE ibranch = (SELECT iply_branch 
			                   FROM sa_branch_type 
			                  WHERE ibranch = (SELECT iquota FROM officer WHERE iofficer = $sIofficer));
			if (SQLCODE == SQLNOTFOUND) strcpy(inventory_nbranch," ");
		}
		else
		{
			$SELECT nchi_full INTO $inventory_nbranch
			   FROM branch 
			  WHERE ibranch = (SELECT iply_branch 
			                   FROM sa_branch_type 
			                  WHERE ibranch = (SELECT iquota FROM officer WHERE iofficer = $sIdeliver));
			if (SQLCODE == SQLNOTFOUND) strcpy(inventory_nbranch," ");
		}    
        
        $SELECT ddeliver_old, fin_out 
           INTO $sDdeliver_old,$sFin_out
           FROM compulsory_card
          WHERE icard = $sIcard;
        if (SQLCODE==SQLNOTFOUND)
       	{
       		strcpy(sDdeliver_old," ");
       		strcpy(sFin_out," ");
       	}
            
        strcpy(sIend_type," ");
        if (strncmp(iFstatus,"1",1) == 0)
        {
        	  strcpy(sTmpPolicy1,substring(sIpolicy,1,13));
        	  strcpy(sTmpPolicy2,substring(sIpolicy,14,7));
            $SELECT fstatus INTO $fstatus
               FROM policy_new
              WHERE ipolicy1 = $sTmpPolicy1
                AND ipolicy2 = $sTmpPolicy2
                AND itarget2 = $sIcard;
            if (SQLCODE == SQLNOTFOUND) strcpy(fstatus," ");
            
            printf("-----��窱�A[%s]-----\n",fstatus); /* C - ���P ,D - �h�O */
            if (strncmp(fstatus,"C",1) == 0){
            strcpy(sIend_type,"���P");}
            else if (strncmp(fstatus,"D",1) == 0){
            strcpy(sIend_type,"�h�O");}
            else{
            	/* �P�_�O�B�ۥ[��0 - �h�O */ 
            	strcpy(sIpolicy,trim(sIpolicy));
            	if (strlen(sIpolicy) != 0) {          	
            	strcpy(Full_DBName,get_car_full_db(sIpolicy));
            	sprintf(sStmt,"SELECT sum(minjured_cover+mdeath_cover+mdamage_cover) \
            	                 FROM %s:ply_ins_type \
            	                WHERE ipolicy = '%s' ",Full_DBName,sIpolicy);
            	$PREPARE ply_ins FROM $sStmt;
	            $DECLARE total_cur CURSOR FOR ply_ins;
	            $OPEN    total_cur;
              $FETCH   total_cur INTO $sCover;
              $CLOSE   total_cur;
	            $FREE    total_cur;     
	            
	            if (sCover > 0)            
                 strcpy(sIend_type," ");
              else
              	 strcpy(sIend_type,"�h�O");
             }
             else{
             	   strcpy(sIend_type," ");
             }	
            }
        }
        
        $SELECT nname INTO $sNleader
           FROM officer
          WHERE iofficer = $sIleader;
        if (SQLCODE == SQLNOTFOUND) strcpy(sNleader," ");
                       
        $SELECT nchi_full INTO $sIalter_bh
           FROM branch
          WHERE ibranch = $sIbranch;
        if (SQLCODE == SQLNOTFOUND) strcpy(sIalter_bh," ");
        
        $SELECT nchi_full INTO $sIdeliver_nbranch
	       FROM branch 
          WHERE ibranch = (SELECT iply_branch 
                             FROM sa_branch_type 
                            WHERE ibranch = (SELECT iquota FROM officer WHERE iofficer = $sIdeliver));
		if (SQLCODE == SQLNOTFOUND) strcpy(sIdeliver_nbranch," ");
        
        strcpy(sDdeliver_old,trim(sDdeliver_old));
        printf("sDdeliver_old[%s]\n",sDdeliver_old);
	    printf("sFin_out[%s]\n",sFin_out);
	    strcpy(sFin_out_char," ");
		strcpy(limit_date," "); 
		sys_int = limit_date_int = cnt_lastday = 0;
		strcpy(limit_date_100," ");
		strcpy(cnt_lastday_char," "); 
		strcpy(sDdeliver_old_100," ");
		sys_int = cm_today();
		strcpy(sys,cm_edate_str(sys_int));
	    if(sDdeliver_old[0] != "")
		{
			if (strncmp(sFin_out,"0",1) == 0) 
			{
				strcpy(sFin_out_char," ");
				if ((sDissue[0] != '') && (sDissue[0] != '\0'))
				{
					$SELECT skip 179 first 1 dwork
					INTO $limit_date
					FROM cm_wrktbl
					WHERE dwork > $sDissue
					ORDER BY 1;
					
					strcpy(limit_date_100,cm_from_infdate_100(limit_date));
					limit_date_int = cm_ymd_cdate(limit_date_100);	
					printf("sys_int[%d]limit_date_int[%d]\n",sys_int,limit_date_int);
					cnt_lastday = limit_date_int - sys_int;
					strcpy(cnt_lastday_char,itoa(cnt_lastday));
					printf("cnt_lastday_char[%s]cnt_lastday[%d]\n",cnt_lastday_char,cnt_lastday);
					strcpy(sDdeliver_old_100,cm_from_infdate_100(sDdeliver_old));   	
				}	
			}
			else if(strncmp(sFin_out,"1",1) == 0) 
			{
				strcpy(sFin_out_char,"�����q��");
				
				$SELECT skip 179 first 1 dwork
				INTO $limit_date
				FROM cm_wrktbl
				WHERE dwork > $sDdeliver_old
				ORDER BY 1;
				
				strcpy(limit_date_100,cm_from_infdate_100(limit_date));
				limit_date_int = cm_ymd_cdate(limit_date_100);	
				printf("sys_int[%d]limit_date_int[%d]\n",sys_int,limit_date_int);
				cnt_lastday = limit_date_int - sys_int;
				strcpy(cnt_lastday_char,itoa(cnt_lastday));
				printf("cnt_lastday_char[%s]cnt_lastday[%d]\n",cnt_lastday_char,cnt_lastday);
				strcpy(sDdeliver_old_100,cm_from_infdate_100(sDdeliver_old));
			}
			else if(strncmp(sFin_out,"2",1) == 0) 
			{
				strcpy(sFin_out_char,"�~���q��");
				$SELECT skip 29 first 1 dwork
				INTO $limit_date
				FROM cm_wrktbl
				WHERE dwork > $sDdeliver_old
				ORDER BY 1;
				
				strcpy(limit_date_100,cm_from_infdate_100(limit_date));
				printf("limit_date[%s]\n",limit_date_100);
				limit_date_int = cm_ymd_cdate(limit_date_100);
				cnt_lastday = limit_date_int - sys_int;
				strcpy(cnt_lastday_char,itoa(cnt_lastday));
				printf("cnt_lastday_char[%s]cnt_lastday[%d]\n",cnt_lastday_char,cnt_lastday);
				strcpy(sDdeliver_old_100,cm_from_infdate_100(sDdeliver_old));
			}
    	}
    	else 
    	{
    		strcpy(sFin_out_char," ");
	    	strcpy(limit_date_100," ");
	    	strcpy(cnt_lastday_char," ");
	    	strcpy(sDdeliver_old_100," ");	
    	}
  	
        $INSERT INTO car2082_1
            VALUES($inventory_nbranch,$sNchi_full,$sIcard,$dissue,$sNdissue,$dreceive,
                   $sIcar_type,$sFstatus,$sIpolicy,$sIdeliver_nbranch,$sIdeliver,$sNdeliver,
                   $sNleader,$sIleader,$ddeliver,$dalter,$sIalter,$sNalter,
                   $sIalter_bh,$sIend_type,$sDdeliver_old_100,$sFin_out_char,$limit_date_100,$cnt_lastday_char);
	
	  }
	  $CLOSE card_cur;
    $FREE  card_cur; 
    
    return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car2082_print_detail()
{
    int     rc;
    char    sfilename[128],stitle[1024],stmt[1024];

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(sfilename,"�O�I�Ҳ��ʩ��Ӫ�");
    strcpy(stitle,"�{���N��:CAR2082\t");
    strcat(stitle,sfilename);
    strcat(stitle,"\t\t\t\t\t\t\t\t\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");
    strcat(sfilename,"[CAR2082]");

    strcat(stitle,"\t�L�I���\t�ӻ���\t�O�I�Ҹ�\t�ӻ��\t�ӻ�H\t�������\t����\t");
    strcat(stitle,"���ʪ��A\t�O�渹�X\t�t�o�g��H���\t�t�o�g��H\t�g��H\t�޲z�H\t");
    strcat(stitle,"�޲z�H�N��\t�t�o��\t���ʤ��\t���ʤH�N��\t���ʤH��\t");
    strcat(stitle,"���ʤH���\t���O\t��l�t�o��\t����/�~���q��\t���^����\t�Y�N����Ѽ�\t");

    strcpy(stmt,"SELECT inventory_nbranch,nchi_full,icard,dissue,ndissue,dreceive,icar_type, "
                "       fstatus,ipolicy,sIdeliver_nbranch,ideliver,ndeliver,nleader,ileader, "
	  	          "       ddeliver,dalter,ialter,nalter,bh_ialter,iend_type,  " 
	  	          "      sDdeliver_old_100,sFin_out_char,limit_date_100,cnt_lastday_char"
                "   FROM car2082_1 "
                "  ORDER BY icard ");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);

    if (rc != SUCCESS) {
        sprintf(msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;
    
errexit:
    sqlfatal();
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}
long car2082_query_ks()
{
	  int     rc;
	  $char stmt[4096];
	  $char sDalter[8],sIbus_location[11],sIcard[21],sFstatus[3],sType[2];
	  $char fstatus[2],iFstatus[2],sIpolicy[21];
	  $char Full_DBName[40],sStmt[512];
    $int  sCover;
    $char  sTmpPolicy1[14], sTmpPolicy2[8];
	   
	  $WHENEVER SQLERROR GOTO errexit;
   
    /* �@�o���A 00 = 3,01 = A B C D E, 02 = 8, 03 = (���P/�h�O)*/
    sprintf(stmt,"SELECT year(a.dalter)-1911||to_char(a.dalter,'%%m%%d'),\
                         (SELECT ibus_location FROM officer WHERE iofficer = a.ideliver),\
                         'G',a.icard,decode(a.fstatus,'3','00','A','01','B','01','C','01','D','01','E','01','8','02','1','03',' '),\
                         a.fstatus,a.ipolicy \
                    FROM compulsory_card a \
                   WHERE a.icard in (SELECT icard FROM car2082_Y ) \
                   UNION \
                  SELECT year(a.dalter)-1911||to_char(a.dalter,'%%m%%d'),\
                         (SELECT ibus_location FROM officer WHERE iofficer = a.ideliver),\
                         'I',a.icard,decode(a.fstatus,'3','00','A','01','B','01','C','01','D','01','E','01','8','02','1','03',' '),\
                         a.fstatus,a.ipolicy \
                    FROM card a \
                   WHERE a.icard in (SELECT icard FROM car2082_Y) ");
     
     printf("Query_ks - stmt[%s]\n",stmt);
     $PREPARE tempcur1 FROM $stmt;
     $DECLARE query_cur CURSOR FOR tempcur1;
     $OPEN    query_cur;
     
     for(;;)
     {
        $FETCH query_cur INTO $sDalter,$sIbus_location,$sType,$sIcard,
                              $sFstatus,$fstatus,$sIpolicy;
        
        if (SQLCODE==SQLNOTFOUND) break;
        
        printf("-----icard_fstatus[%s]-----\n",fstatus);
        if (strncmp(fstatus,"1",1) == 0)
        {
        	 strcpy(sTmpPolicy1,substring(sIpolicy,1,13));
        	 strcpy(sTmpPolicy2,substring(sIpolicy,14,7));
        	 $SELECT fstatus INTO $iFstatus
              FROM policy_new
             WHERE ipolicy1 = $sTmpPolicy1
               AND ipolicy2 = $sTmpPolicy2
               AND itarget2 = $sIcard;
           if (SQLCODE == SQLNOTFOUND) strcpy(iFstatus," ");
           
           printf("-----��窱�A[%s]-----\n",iFstatus); /* C - ���P ,D - �h�O */
           if ((strncmp(iFstatus,"C",1) != 0) && (strncmp(iFstatus,"D",1) != 0))
           {
           	  /* �P�_�O�B�ۥ[��0 - �h�O */
           	  strcpy(sIpolicy,trim(sIpolicy));
           	  if (strlen(sIpolicy) != 0) {
           	  strcpy(Full_DBName,get_car_full_db(sIpolicy));
            	sprintf(sStmt,"SELECT sum(minjured_cover+mdeath_cover+mdamage_cover) \
            	                 FROM %s:ply_ins_type \
            	                WHERE ipolicy = '%s' ",Full_DBName,sIpolicy);
            	$PREPARE plyins FROM $sStmt;
	            $DECLARE total_cur2 CURSOR FOR plyins;
	            $OPEN    total_cur2;
              $FETCH   total_cur2 INTO $sCover;
              $CLOSE   total_cur2;
	            $FREE    total_cur2;     
	            
	            if (sCover > 0)            
                 strcpy(sFstatus," ");
              else
              	 strcpy(sFstatus,"03");
             }
             else{
             	   strcpy(sFstatus," ");
             }             	
           }          
        }
        
        $INSERT INTO car2082_2
           VALUES($sDalter,$sIbus_location,$sType,$sIcard,$sFstatus);
     }
     $CLOSE query_cur;
     $FREE  query_cur; 
    
     return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car2082_print_ks()
{
	   $char stmt[2048];
	   $char sDalter[8],sIbus_location[11],sIcard[21],sFstatus[3],sType[2];
	   $int  qcnt,rc;
	   long  t;
	   char  fname[256],errmsg[128];
	   
	   $WHENEVER SQLERROR GOTO errexit;
	  
	   rc = getApHome(sApHome);
	   if (rc < 0) {
		    strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		    return rc;
     }
   
     sprintf(stmt,"SELECT dalter,ibus_location,icard_type,icard,fstatus "
	 	              "  FROM car2082_2 "
	 	              " ORDER BY fstatus desc ");
     
     printf("stmt[%s]\n",stmt);
     $PREPARE compulsory_ks FROM $stmt;
     $DECLARE ks_cur CURSOR FOR compulsory_ks;
     $OPEN    ks_cur;
   
     strcpy(filename," ");
     sprintf(fname,"car208_�Ϳ��@�o_%s%s%s.txt",nyy,nmm,ndd);
     sprintf(filename,"%s/rptftp/%s",sApHome,fname);
     printf("-----�Ϳ��@�o�M��-----[%s]\n",filename);
     fp=fopen(filename,"w");
   
     for(;;)
     {
       $FETCH ks_cur INTO $sDalter,$sIbus_location,$sType,$sIcard,$sFstatus;
       if (SQLCODE==SQLNOTFOUND) break;      
       strcpy(sIcard,trim(sIcard));
       strcpy(sIbus_location,trim(sIbus_location));
       fprintf(fp,"%s,%s,%s,%s,%s,\n",sDalter,sIbus_location,sType,sIcard,sFstatus);      
     }
     $CLOSE ks_cur;
     $FREE  ks_cur;
     
     fclose(fp);

     rc=rptftpinsert(userid,"car208",fname);
     if (rc!=0) {
         sprintf(errmsg,"%s�g�Jrptftplist���~",fname);
         EWRITE(userid,rc,errmsg);
         return rc;
     }

     return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car2082_card_notfound()
{
	   $char sIcard[21],stmt[2048];
	   $int  rc;
	   long  t;
	   char  fname[256],errmsg[128];
	   
	   $WHENEVER SQLERROR GOTO errexit;
	  
	   rc = getApHome(sApHome);
	   if (rc < 0) {
		    strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		    return rc;
     }
     
     strcpy(filename," ");
     sprintf(fname,"car208_card_notfound[%s%s%s].txt",nyy,nmm,ndd);
     sprintf(filename,"%s/rptftp/%s",sApHome,fname);
     printf("-----card_notfound-----[%s]\n",filename);
     fp=fopen(filename,"w");
     
     $DECLARE temp_cur CURSOR FOR
       SELECT icard
				 FROM car2082_N;
     $OPEN  temp_cur;
   
     for(;;)
     {
       $FETCH temp_cur INTO $sIcard;
       if (SQLCODE==SQLNOTFOUND) break;      

       fprintf(fp,"%s\n",sIcard);      
     }
     $CLOSE temp_cur;
     $FREE  temp_cur;
     
     fclose(fp);

     rc=rptftpinsert(userid,"car208",fname);
     if (rc!=0) {
         sprintf(errmsg,"%s�g�Jrptftplist���~",fname);
         EWRITE(userid,rc,errmsg);
         return rc;
     }

     return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}
/*----------------------------------------------------------------------------*/
char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
        char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
        char sTmp_db_name[21];

        sTmp_db_name[0]='\0';
        if (*sIpolicy != '\0' && *sIpolicy !=' ')
        {
           sTmp_db_name[0]='\0';
           strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
           strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
                  USE_BRANCH_ID));
           strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
        }
  return sTmp_db_name;
}
/*---------------------------------THE END------------------------------------*/
