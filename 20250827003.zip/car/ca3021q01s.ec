/***********************************************
 * Copyright Newa 
 *
 * Program : ca3021q01s.ec
 * p32_xx_statistic
 ***********************************************/

#include <stdio.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"
#include "safeclib.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"

/*************************************************************/
long ca3021_build(iplyyear,iplymonth,userid,outputfa,ipgid,intopt)
char outputfa[30];
char userid[11],ipgid[9];
$int iplyyear,iplymonth, intopt;
{
    char      sApHome[30];
    FILE      *fptr;
    $char     tmp_big_comp[2],tmp_big_office[11],tmp_big_sales[11],
              big_comp[2],big_office[11],big_sales[11],iins_type[3],
              ffirst[2],iofficer[11],ngroup[21],nname[11],iofficer_13[4]
              ,tmp_officer[11],ipolicy[20],tmp_ipolicy[20],fcomp_class[3];

    char      prtfile[80],outputf1[80],outputf2[80];
    $int      cnt_01,cnt_05,cnt_09,cnt_11,cnt_31,cnt_51,cnt_oth,
              cnt_vol,sum_vol,avr_vol,cnt_21,mins_premium,fvol,linnum,f21;
    int       iins,rt;
    $int      id6 = 0;
    char      file[100];
    $char     errFile[100];
    char      prtstr[201],prtstr1[201];
    $char     localdb[5],Taipei_FullName[20];
    int       i, flag_check=0;
    $char     expdate[6];
    char      bgndate[9],enddate[9];
    char      errmsg[200];
    $char      iquota_tc[11], sQuery[1024], sTmp[64];
  
    strcpy(outputf1,outputfa);

    printf("INTO car3021\n");
    rt = getApHome(sApHome);
    if (rt < 0)
    {
        printf("read Config file error!!\n");
        return M_CM_READ_CONFIG_ERR;
    }

    sprintf_s(file,sizeof file,"%s/rptftp/%s",sApHome,rtrim(outputf1));

    rt = rptftpinsert(userid,ipgid,outputf1);
    if (rt != 0)
    {
        printf("rptftp error \n");
        goto errexit;
    }
    printf("ca3021 file == [%s]\n",file);

    /***** process ply********/
    if ((fptr=fopen(file,"w")) == NULL){
        sprintf_s(errmsg,sizeof errmsg,"Cannot open print file: %s",file);
        return M_CM_OPEN_FILE_FAIL;
    }

    /* *** open error log file *** */

    printf(" car3021 iplyyear = [%d]\n",iplyyear);
    printf(" car3021 imonth = [%d]\n",iplymonth);

    /* 100.03.01,�w���� �έ�W�b��(���|��intopt ==4) */
    if( intopt == 1)
        sprintf_s( sTmp,sizeof sTmp, " AND option in ('1','9') ");
     else if( intopt == 4)
        sprintf_s( sTmp,sizeof sTmp, " AND option in ('4','9') ");
     else if( intopt == 9)                     /* 950921 ,�s�W�u���ͦb ca_tmp_no �������)*/
         sprintf_s( sTmp,sizeof sTmp, " AND a.ipolicy in (select ipolicy from newa00:ca_tmp_no)");                 
    else
        strcpy( sTmp, " ");

    strcpy(ffirst,"Y");
    cnt_01 = cnt_05  = cnt_09  = cnt_11  = cnt_31 = cnt_51 = cnt_oth
           = cnt_vol = avr_vol = sum_vol = cnt_21 = fvol =f21= 0;
    $WHENEVER SQLERROR GOTO errexit;

    /* 950908,�x���Υ�09�|��ĳ��05,�P�ɦA�s�W�^09(���F�C�L����q����),�]���|���G�������I,
       �G�[�J��ĳ�έ��O�զX���O�O�P�_,�����s�̤��C�J�έp 	
    sprintf_s( sQuery,sizeof sQuery, " SELECT  ibig_comp,ibig_office,ibig_sales,iofficer,iins_type,"
              	     " mins_premium,a.linnum,a.ipolicy,fcomp_class "
        	     " FROM  policy_302 a,ply_ins_type_302 b "
       	             " WHERE  a.ipolicy = b.ipolicy "
         	     " AND  YEAR(a.dply_begin) = %d "
         	     " AND  MONTH(a.dply_begin) = %d "
         	     " AND  a.ibig_comp is not null " 
         	     " AND  a.ibig_comp <> ' ' "
         	     " AND  a.ibig_comp not in ('L','P','C') %s "
         	     " AND (b.mins_premium<>0 AND b.ori_premium<>0) "
       	     " ORDER BY a.iofficer, a.ibig_office,a.ipolicy ", iplyyear, iplymonth, sTmp);   */    
       	     
    /** 99.10.19, 100.01 �������O���_���ѷs�w�C�L **/    	     
    sprintf_s( sQuery,sizeof sQuery, " SELECT  ibig_comp,ibig_office,ibig_sales,iofficer,iins_type,"
              	     " mins_premium,a.linnum,a.ipolicy,fcomp_class "
        	     " FROM  policy_302 a,ply_ins_type_302 b "
       	             " WHERE  a.ipolicy = b.ipolicy "
         	     " AND  YEAR(a.dply_begin) = %d "
         	     " AND  MONTH(a.dply_begin) = %d "
         	     " AND  a.ibig_comp is not null " 
         	     " AND  nvl(a.ibig_comp,' ') <> ' ' "
         	     " AND  a.ibig_comp not in ('L','G') %s "
         	     " AND (b.mins_premium<>0 AND b.ori_premium<>0) "
       	     " ORDER BY a.iofficer, a.ibig_office,a.ipolicy ", iplyyear, iplymonth, sTmp);

    $PREPARE prep1 FROM $sQuery;
    $DECLARE  c_ins_302 CURSOR FOR prep1;

    $OPEN     c_ins_302;
    while(1)
    {
          $FETCH c_ins_302 INTO $big_comp,$big_office,$big_sales,$iofficer,
                                $iins_type,$mins_premium:id6,$linnum,$ipolicy,
                                $fcomp_class;

          if(SQLCODE == SQLNOTFOUND) break;

          if (id6 == -1) mins_premium = 0;


          if (ffirst[0] == 'Y')
          {
               strcpy(tmp_big_office,big_office);
               strcpy(tmp_big_sales,big_sales);
               strcpy(tmp_officer,iofficer);
               strcpy(tmp_ipolicy,ipolicy);
               strcpy(ffirst,"N");
               fvol = 0;
               f21  = 0;
          }

          if (strcmp(tmp_ipolicy,ipolicy)!=0)
          {
               fvol = 0;
               f21  = 0;
               strcpy(tmp_ipolicy,ipolicy);
          }

          if ( strcmp(tmp_big_office,big_office) != 0)
          {
               /***Ū���g�P�ӦW�١A��~�ҦW��***/
               $SELECT nname,iquota
                  INTO $nname,$iquota_tc
                  FROM officer
                 WHERE iofficer = $tmp_officer;
               strncpy(iofficer_13,tmp_officer,3);
               iofficer_13[3] = '\0';

               $SELECT ngroup
                  INTO $ngroup
                  FROM sa_frm_module
                 WHERE ifrm_module = '02'
                   AND igroup  = $iofficer_13;

               strcpy(prtstr,trim(ngroup));
               strcat(prtstr, "\t");
               strcat(prtstr,trim(nname));
               strcat(prtstr, "\t");
               strcat(prtstr,trim(tmp_big_office));
               strcat(prtstr, "\t");
               strcat(prtstr, itoa(cnt_01));
               strcat(prtstr, "\t");
               strcat(prtstr, itoa(cnt_05));
               strcat(prtstr, "\t");
               strcat(prtstr, itoa(cnt_09));
               strcat(prtstr, "\t");
               strcat(prtstr, itoa(cnt_11));
               strcat(prtstr, "\t");
               strcat(prtstr, itoa(cnt_31));
               strcat(prtstr, "\t");
               strcat(prtstr, itoa(cnt_51));
               strcat(prtstr, "\t");
               strcat(prtstr, itoa(cnt_oth));
               strcat(prtstr, "\t");
               strcat(prtstr, itoa(cnt_vol));
               strcat(prtstr, "\t");
               /******���N�I�����O�O******/
               if(cnt_vol > 0)
               	avr_vol  =   sum_vol /   cnt_vol;
               else
               	avr_vol = 0;
               strcat(prtstr, itoa(avr_vol));
               strcat(prtstr, "\t");
               strcat(prtstr, itoa(cnt_21));
               strcat(prtstr, "\t");
               strcat(prtstr,substring(tmp_officer,1,1));
               strcat(prtstr, "\t");
               strcat(prtstr,iquota_tc);
               strcat(prtstr, "\t");
               prtstr[200]= '\0';
               fprintf(fptr,"%s\n",prtstr);
               cnt_01 = cnt_05  = cnt_09 = cnt_11 = cnt_31 = cnt_51 = cnt_oth
                      = cnt_vol = avr_vol = sum_vol = cnt_21 = fvol =f21 = 0;

               strcpy(tmp_big_office,big_office);
               strcpy(tmp_big_sales,big_sales);
               strcpy(tmp_officer,iofficer);
          }

          iins = atoi(iins_type);
          switch (iins)
          {
               case   1:
                  cnt_01    +=  1;
                  break;
               case   5:
                  cnt_05    +=  1;
                  break;
               case   9:
                  cnt_09    +=  1;
                  break;
               case  11:
                  cnt_11    +=  1;
                  break;
               case  31:
                  cnt_31    +=  1;
                  break;
               case  32: case 24: case 21:
                  break;
               case 55: case 56: case 51: case 52: case 53:
                  cnt_51    +=  1;
                  break;
               default :
                  cnt_oth   +=  1;
                  break;
          }
          if ( iins!=  21)
          {
               sum_vol  +=   mins_premium;
               /****���N�I��Ƭ��[�@��****/
               if (fvol     !=   1)
               {
                   fvol = 1 ;
                   cnt_vol += 1;
               }
          }
          /**�j����***/
          if (strlen(trim(fcomp_class)) > 0 && f21 != 1)
          {
               cnt_21 += 1;
               f21     = 1;
          }
    }
    $FREE prep1;
    $CLOSE c_ins_302;
    $FREE c_ins_302;

    /***�L�̫�@��***/
    $SELECT nname
       INTO $nname
       FROM officer
      WHERE iofficer = $tmp_officer;
    strncpy(iofficer_13,tmp_officer,3);
    iofficer_13[3] = '\0';

    $SELECT ngroup
       INTO $ngroup
       FROM sa_frm_module
      WHERE ifrm_module = '02'
        AND igroup  = $iofficer_13;
    strcpy(prtstr,trim(ngroup));
    strcat(prtstr, "\t");
    strcat(prtstr,trim(nname));
    strcat(prtstr, "\t");
    strcat(prtstr,trim(tmp_big_office));
    strcat(prtstr, "\t");
    strcat(prtstr, itoa(cnt_01));
    strcat(prtstr, "\t");
    strcat(prtstr, itoa(cnt_05));
    strcat(prtstr, "\t");
    strcat(prtstr, itoa(cnt_09));
    strcat(prtstr, "\t");
    strcat(prtstr, itoa(cnt_11));
    strcat(prtstr, "\t");
    strcat(prtstr, itoa(cnt_31));
    strcat(prtstr, "\t");
    strcat(prtstr, itoa(cnt_51));
    strcat(prtstr, "\t");
    strcat(prtstr, itoa(cnt_oth));
    strcat(prtstr, "\t");
    strcat(prtstr, itoa(cnt_vol));
    strcat(prtstr, "\t");
    /******���N�I�����O�O******/
    if(cnt_vol > 0)
    	avr_vol  =   sum_vol /   cnt_vol;
    else
    	avr_vol = 0;
    strcat(prtstr, itoa(avr_vol));
    strcat(prtstr, "\t");
    strcat(prtstr, itoa(cnt_21));
    strcat(prtstr, "\t");
    strcat(prtstr,substring(tmp_officer,1,1));
    strcat(prtstr, "\t");
    strcat(prtstr,iquota_tc);
    strcat(prtstr, "\t");
    prtstr[200]= '\0';
    printf("prtstr[%s]\n",prtstr);
    fprintf(fptr,"%s\n",prtstr);

    fclose(fptr);

    return 1;

errexit:
    printf("SQLCODE:[%d], sqlstr:[%s]\n", SQLCODE, sqlca.sqlerrm);
    return 0;
}
