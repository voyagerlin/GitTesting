/************************************************/
/*						*/
/*   PROGRAM : ca519q01s.ec by Johnny Kuo	*/
/*						*/
/*   DATE    : 1997/03/06			*/
/*						*/
/************************************************/
#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "print.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"

#include "carmsgs.h"
#include "commsgs.h"
#include "ca_field.h"
#include <locator.h>
#include "safeclib.h"

extern char RPTDIR[30];

$char BodyFmt[21], TitleFmt[21];
$char FormTp[3];
$int  TotColumn, StartRow, TitleRow, ItemRow, PgLine;
$int  Width = 0;

char  SysTm[ N_TM+1];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1];
char  outputf[ N_FILE+1];
char  userid[11];

int  max_count = 0, errCode;
int  tmp_len, rec_count;
int  copies;
int  miy;


/*------------------------------------*/
#define NEXTPAGE   3
#define LINEofPAGE 30

/*** local function **/
   long car519_build(), car519_email(),car519_email2(),car519_email_B();
   void car519_title();
   void car519_page();
   long car519_tot();
   void car519_body2();
   long car519_body();
   void car519_grp();
   long car519_payment();
   void car519_nextpage();

$typedef struct {
   char DBName2[3];
   char Nchi_abv[11];
} Branch;

$Branch Brh[20];
$char   nchiabv[7];

/*** screen variable ***/
   $char  dptbgn[3], dptend[3];
   $char  clsdate[13], clsdate_ED[11];
   $char  ch_clsdate[9], Tqserial[4];
   $int   qserial = 0;

/*** report variable1 ***/
   $char  XIpolicy[PLY_LEN], XDadjust[9];
   $char  XIclaim[CLM_LEN], XFstl[2], YIadjuster[11],fcard_class[2] , frecover[2] , fsale[2];
   $int   XIclose_type;
   $long  YMdmg_stl, YMbrg_stl, YMparts_stl, YMlia_stl, YMinj_stl;
   $char  YNassured[13];
   $long  YMdmg_proc, YMlia_proc ;
   $char  ZIins_type[INS_LEN];
   $long  ZMins_proc;
    int   ZIins_type_INT;
   $char  Ipayment[13],Nsettle_type[5], Nchi_abv[13], Nchi_full[101];
   $char  fspeed[2],xfpay_cond[2],pay_kind[2];
   $long  Mpayment,pay_qserial;
   $int   Iqserial;
   $long  vouch_state = 0;	/*�q�lñ�֪��A*/

/*** report variable2 ***/
   $char ipolicy[PLY_LEN], iclaim[CLM_LEN], fstl[2];
   $int  iclose_type=0;
   $char icard[CARD_LEN], ftype[2];

/*** other variable ***/
   $char  DBName[5], DBName3[5];
    int   LoP;
    long  D1, D2, D3, D4;
    long  P11, P12, P13, P14;
    long  P21, P22, P23, P24;
    long  P31, P32, P33, P34;
    long  T11, T12, T13, T14;
    long  T21, T22, T23, T24;
    long  T31, T32, T33, T34;

    $long mdate;
    $char stmt[1024], DBName[5], sFullName[20];
    $char sLocalDB[5], sLocalName[20];
    $char sClsdate[11], eClsdate[11], sQserial[3], sIins_type[5];
    $char sIclaim[21], sFstl[2], sDclose[13], sIadjustment[10];
    $char sIemail[41], sRecipient[41], sSemail[21], sNins_type[41];
    $char sDpay[11], nchi_full[20], nname[15], tphone[16];
    $long lMins_stl = 0;
    $long lMplace_fee = 0;
    $long lMins_proc = 0;
    $long eDclose, eDpay;
    $int  eQserial, icount=0,count_nassured=0,count_leader=0;
    $int  eIclose_type = 0;
    $char leader_email[41];
    $char ioth_tag[CA_TAG_NUM],ioth_iissue[11],ioth_nassured[21];
    $char ioth_tel[12],driver_nassured[21],driver_tel[12];
    $char ileader[11];
    $char iofficer[11];
    $char nassured[21];
    $long mspeed1,mspeed2,mspeed3,mspeed4,mspeed5,mspeed6,mspeed7,mspeed8,mremit,mcheck,mtotal;
    $int  qremit,qcheck,qtotal;
    char prtstr[250], tmp_buf[10];
    char option[2];

    /* �Ӹ�B�n add by larry 103.02.19 (1030211003_C1) */
    $char sFsex[2],sNassured[21];
    $char sIoth_nassured[21],sIoth_tel[12];
    $char sDriver_nassured[21],sDriver_tel[12];



/***************************************************************************/
main(argc, argv)
int argc;
char **argv;
{
$char mbuf1[9000];
$loc_t ctxt1;

   int rc;

   batchinit();
   strcpy(DBName,isNULLstr(argv[1]));
   strcpy(userid,isNULLstr(argv[2]));
   strcpy(clsdate,isNULLstr(argv[3]));
   strcpy(Tqserial,isNULLstr(argv[4]));
   strcpy(option,isNULLstr(argv[5]));        /**** 1.car5083   2.car519 ****/
   strcpy(outputf,isNULLstr(argv[6]));

   strcpy( clsdate_ED, cm_to_infdate( clsdate));
   qserial = atoi(Tqserial);
   printf("------>clsdate_ED[%s],qserial[%d]\n",clsdate_ED,qserial);

   if (db_select(DBName) == False)
   {
       EWRITE(userid, M_CM_DB_NOTOPEN, " ");
       return M_CM_DB_NOTOPEN;
   }

  if (option[0] == '1')
  {
      /* rc=car519_email(); *//* �g�d�ثe�S���o�e��mail, �G���N������mark  mark by sylvia 106.09.01 */

      /* rc=car519_email_A(); *//* ���l�״_���v�q�� add by sylvia  */

      /* �]����ק�T�׸��j, ��I�s�sfunction car519_email_B modify by sylvia 109.06.29 (1090609004_SC1)
         1.�߮פ鵲�ɶ��G 00:00-16:00 ==>�j�ѤW�� 08:15 �o�email (project_id = 'CAR5191)
           �߮פ鵲�ɶ��G 16:01-23:59 ==>�j�G�ѤW�� 08:15 �o�email (project_id = 'CAR5191)
         2.�P�_�������,�Ԭݧ@�~�լd�O���� */


      /* �]����ק�,���A��鵲�ɼg�J,��W�߬�car5194�妸����,�Gmark���q�{��
         mark by sylvia 110.10.4  (1100825010_SC1) */
      /* rc=car519_email_B();
      if (rc != M_CM_OK)
      {
          EWRITE(userid, rc, " ");
          return rc;
      }
      printf("[5192]:build ok!\n"); */
  }



   /* ����� */
   rc=car519_build();
   if (rc != M_CM_OK)
   {
       EWRITE(userid, rc, " ");
       return rc;
   }
   printf("[5191]:build ok!\n");

   if ((rc=create_sign_form("car519",BodyFile,Width))!=0)
   {
      EWRITE(userid, rc, " ");
      return rc;
   }
   printf("[5191]:create_sign_form ok!\n");

   if ((rc=save_form_info(F_BLK1,"CA",519,userid,"",max_count,outputf))<0)
   {
        EWRITE(userid,rc,"save_form_info failed");
        return rc;
   } else
      printf("[5191]success on save_form_info.\n");





}
/***************************************************************************/
long car519_email()
{

$char mbuf[9000];
$loc_t ctxt;



/* for email */

   if (db_select(DBName) == False)
   {
       EWRITE(userid, M_CM_DB_NOTOPEN, " ");
       return M_CM_DB_NOTOPEN;
   }


printf("  *********************car519 email \n");


  sprintf_s(stmt,1024,"SELECT iclaim, fstl, iclose_type, dclose \
                    FROM ca_local_stl \
                   WHERE dclose = '%s' AND qserial = %d ",
                   clsdate_ED, qserial);

    printf("stmt[%s]\n",stmt);
    $PREPARE pcur1 FROM $stmt;
    $DECLARE cur1 CURSOR for pcur1;
    $OPEN cur1;
    while(1)
    {

    	$FETCH cur1 INTO $sIclaim, $sFstl, $eIclose_type, $sDclose;

    	if( SQLCODE == SQLNOTFOUND ) break;

    	printf("sIclaim[%s] sFstl[%s]\n",sIclaim, sFstl );

    	/* �ߥI��~�ݵo mail */
    	if( strcmp(trim(sFstl),"2" ) == 0 )
    	    continue;

    	/* �z�ߤH���B���q�B�q�ܡBLocal DB  */
    	$SELECT b.ibig_branch, b.itel, a.nname, ca.ibranch_in, ca.adjustment
           INTO $nchi_full,  $tphone,  $nname, $sLocalDB, $sIadjustment
           FROM ca_clm_process ca, officer a, ca_big_office b
          WHERE ca.iclaim = $sIclaim
            AND ca.adjustment = a.iofficer
            AND a.iquota[1,4] = b.ibig_comp[1,4]
            AND b.fclass = '3';
        printf("@_@ pass ca_clm_process\n");

    	/* ����H��� */
    	strcpy( sLocalName , get_full_dbname(sLocalDB));
    	sprintf_s(stmt,1024,"SELECT iemail, recipient,iofficer,nassured[1,20],fsex \
    	                FROM %s:adjustment_ply \
    	               WHERE iclaim = '%s'", sLocalName, sIclaim );
    	printf("stmt[%s]\n",stmt);
    	$PREPARE padj FROM $stmt;
    	$EXECUTE padj INTO $sIemail, $sRecipient,$iofficer,$nassured, $sFsex;



    	/* �S��Email���H�A�N���ť� */
 /*  	if( strlen(trim(sIemail)) == 0 )
    	{   strcpy(sIemail,"sweet");    }
    	else
    	{   count_nassured ++;      }   */

    	/* �鵲���ഫ�w�p�ߥI�� */
    	rstrdate(sDclose, &eDclose);
    	eDpay = eDclose +7;

    	strcpy( sDpay , cm_edate_str(eDpay));

    	/* �o�H�Hmail */
    	$SELECT email
           INTO $sSemail
           FROM personal:asempl
          WHERE empl_no = $sIadjustment;
    	if(SQLCODE==SQLNOTFOUND)
           continue;

        strcpy(sSemail,trim(sSemail));
        strcat(sSemail,"@tmnewa.com.tw");

    	printf("sSemail[%s]\n",sSemail );


    	$select ileader
    	  into $ileader
    	  from officer
    	 where iofficer = $iofficer;

    	 printf("iofficer[%s]\n",iofficer);
    	 printf("ileader[%s]\n",ileader);

    	 printf("00000000000000000000000000 ileader [%s]\n",ileader);


    	/* �޲z�Hmail */
    	$SELECT email
           INTO $leader_email
           FROM personal:asempl
          WHERE empl_no = $ileader;
    	if(SQLCODE==SQLNOTFOUND)
    	{  strcpy(leader_email," ");     }


        strcpy(leader_email,trim(leader_email));
        strcat(leader_email,"@tmnewa.com.tw");

    	printf("leader_email[%s]\n",leader_email );


    	/* �ǳƽߴڪ��B�r�� */

    	if( sIclaim[5] == 'V' )
    	{

    	   prtstr[0] = '\0';
    	   sprintf_s(stmt,1024,"SELECT a.iins_type, nins_type, NVL(SUM(mins_stl),0) \
    	                   FROM %s:stl_ins_type a, insurance_type b \
    	                  WHERE iclaim ='%s' AND a.iins_type = b.iins_type \
    	                    AND fstl = '1'   AND iclose_type = %d  \
    	                 GROUP BY 1,2",sLocalName, sIclaim, eIclose_type );
    	   printf("stmt[%s]\n",stmt);
    	   $PREPARE pstl FROM $stmt;
    	   $DECLARE xstl CURSOR for pstl;
    	   $OPEN xstl;
    	   while(1)
    	   {
    	      $FETCH xstl INTO $sIins_type, $sNins_type, $lMins_stl;
    	      if(SQLCODE == SQLNOTFOUND) break;

    	      printf("sIins_type[%s] lMins_stl[%d] \n",sIins_type, lMins_stl);
    	      strcat(prtstr,trim(sNins_type));
    	      strcat(prtstr,"/�ߴڪ��B");
    	      rfmtlong(lMins_stl,"--------&",tmp_buf);
    	      strcat(prtstr,tmp_buf);
    	      strcat(prtstr,"��");

    	      switch(atoi(sIins_type))
    	      {
    	      	 case 1: case 5: case 8: case 9: case 11:
    	      	    sprintf_s(stmt,1024,"SELECT NVL(SUM(mplace_fee),0) \
    	      	                    FROM %s:settlement \
    	      	                   WHERE iclaim = '%s' AND fstl = '1' \
    	      	                     AND iclose_type = %d ",
    	      	                  sLocalName, sIclaim, eIclose_type );
    	      	    printf("stmt[%s]\n",stmt);
    	      	    $PREPARE cur_fee FROM $stmt;
    	      	    $EXECUTE cur_fee INTO $lMplace_fee;

    	      	    if ( lMplace_fee > 0 )
    	      	    {
    	      	    	strcat(prtstr,"�B�z�߶O��");
    	      	    	rfmtlong(lMins_proc,"--------&",tmp_buf);
    	      	    	strcat(prtstr,tmp_buf);
    	      	    	strcat(prtstr,"��");
    	      	    }
    	      	    break;

    	      	 default:
    	      	    break;
    	      }
    	      strcat(prtstr,"|");
    	      printf("prtstr[%s]\n",prtstr);
    	   }
    	   $CLOSE xstl;
    	   $FREE  xstl;

    	}
    	else if ( sIclaim[5] == 'C' )
    	{

           prtstr[0] = '\0';
           sprintf_s(stmt,1024,"SELECT NVL(SUM(mins_stl),0) \
                           FROM %s:ca_stl_victim \
                          WHERE iclaim = '%s' AND fstl = '1' \
                            AND iclose_type = %d ",
                         sLocalName, sIclaim, eIclose_type );

           $PREPARE p_vic FROM $stmt;
           $EXECUTE p_vic INTO $lMins_stl;

           strcpy(prtstr,"�j��T���d���O�I/�ߴڪ��B ");
    	   rfmtlong(lMins_stl,"--------&",tmp_buf);
    	   strcat(prtstr,tmp_buf);
    	   strcat(prtstr,"��|");

    	}
 /*
    	  sprintf_s(stmt,1024,"SELECT ioth_tag,ioth_iissue,ioth_nassured, \
    	                       ioth_tel,driver_nassured,driver_tel \
    	      	          FROM %s:settlement \
    	      	         WHERE iclaim = '%s' AND fstl = '1' \
    	      	           AND iclose_type = %d ",
    	      	              sLocalName, sIclaim, eIclose_type );
    	  printf("stmt[%s]\n",stmt);
    	  $PREPARE cur_data FROM $stmt;
    	  $EXECUTE cur_data INTO $ioth_tag,$ioth_iissue,$ioth_nassured,
    	                         $ioth_tel,$driver_nassured,$driver_tel;
 */

         strcpy(ioth_iissue," ");
         sprintf_s(stmt,1024,
         " SELECT First 1 ioth_tag,ioth_nassured,ioth_itel,driver_nassured,driver_tel  \
             FROM %s:stl_oth_dtl                      \
            WHERE iclaim = '%s' AND fstl = '1'        \
              AND iclose_type = %d ",sLocalName, sIclaim, eIclose_type);
         printf("stmt[%s]\n",stmt);
         $PREPARE cur_data FROM $stmt;
         $EXECUTE cur_data INTO $ioth_tag,$ioth_nassured,
                                $ioth_tel,$driver_nassured,$driver_tel;


/*   if(( (strlen(trim(ioth_tag)) == 0 ) || (strlen(trim(ioth_nassured)) == 0 ) || (strlen(trim(ioth_tel)) == 0 )) && ((strlen(trim(driver_nassured)) == 0 ) || (strlen(trim(driver_nassured)) == 0 )))
    	    { strcpy(leader_email,"sweet");   }                              */


        icount++;
        printf(" sIemail[%s]\n",sIemail);
        printf(" leader_email[%s]\n",leader_email);

        /* �Ӹ�B�n (nassured,ioth_nassured,ioth_tel,driver_nassured,driver_tel)
           add by larry 103.02.19 (1030211003_C1) */
        strcpy(sFsex,trim(sFsex));
        if ( (strncmp(sFsex,"1",1) == 0) || (strncmp(sFsex,"2",1) == 0) )
        {
            strcpy(sNassured,substring(nassured,1,2));
	          strcat(sNassured,"�ݢ�");
	          strcpy(sIoth_nassured,substring(ioth_nassured,1,2));
	          strcat(sIoth_nassured,"�ݢ�");
	          strcpy(ioth_tel,trim(ioth_tel));
	          if (strlen(ioth_tel) != 0){
	              strcpy(sIoth_tel,substring(ioth_tel,1,3));
	              strcat(sIoth_tel,"XXXX");
	              strcat(sIoth_tel,substring(ioth_tel,8,4));
	          }
	          else{
	          	  strcpy(sIoth_tel," ");
	          }
	          strcpy(sDriver_nassured,substring(driver_nassured,1,2));
	          strcat(sDriver_nassured,"�ݢ�");
	          strcpy(driver_tel,trim(driver_tel));
	          if (strlen(driver_tel) != 0){
	              strcpy(sDriver_tel,substring(driver_tel,1,3));
	              strcat(sDriver_tel,"XXXX");
	              strcat(sDriver_tel,substring(driver_tel,8,4));
	          }
	          else{
	          	  strcpy(sDriver_tel," ");
	          }
	      }
	      else{
	      	  strcpy(sNassured,nassured);
	      	  strcpy(sIoth_nassured,ioth_nassured);
	      	  strcpy(sIoth_tel,ioth_tel);
	      	  strcpy(sDriver_nassured,driver_nassured);
	      	  strcpy(sDriver_tel,driver_tel);
	      }


        /* �޲z�H�o�e��Ӹ�� */

        sprintf_s(mbuf,9000,
                "�߮׸��X:%s�@\n"
                "�Q�O�I�H:%s  \n"
                "��y��Ʀp�U,�дx��������| \n "
                "�P�Ӹ��X:%s  \n"
                "���D�m�W:%s  \n"
                "���D�q��:%s  \n"
                "�r�p�m�W:%s  \n"
                "�r�p�q��:%s  \n",sIclaim,sNassured,ioth_tag,
                sIoth_nassured,sIoth_tel,sDriver_nassured,sDriver_tel);


            printf("************mbuf[%s]",mbuf);


            ctxt.loc_loctype = LOCMEMORY;
            ctxt.loc_buffer = mbuf;
            ctxt.loc_size =  strlen(mbuf) + 1;

            mdate = cm_today()+1;


            if(( (strlen(trim(ioth_tag)) == 0 ) || (strlen(trim(ioth_nassured)) == 0 ) || (strlen(trim(ioth_tel)) == 0 )) && ((strlen(trim(driver_nassured)) == 0 ) || (strlen(trim(driver_nassured)) == 0 )))
             { }
             else
             {
            $INSERT INTO batchemail
            (project_id, mail_date, receiver_email, receiver_name, cc,
             content,    key,       mail_count)
             VALUES
            ("CAR519",   $mdate,    $leader_email,	" ",	" ",
             $ctxt,      "Y",       1);
              }








        ioth_tag[0]='\0';
        ioth_iissue[0]='\0';
        ioth_nassured[0]='\0';
        ioth_tel[0]='\0';
        driver_nassured[0]='\0';
        driver_tel[0]='\0';
        nassured[0]='\0';


    }
    $CLOSE cur1;
    $FREE  cur1;

    printf("total count[%d]\n",icount);

    return M_CM_OK;

errexit:
  printf("errexit, SQLCODE=[%ld] \n", SQLCODE);




}



/***************************************************************************/
long car519_build()
{
   $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1], sFullName[20], sStmt[1024];
   int	  i, NoBranch, j=0;
   int    rtncode, rc=0;
  char  sIunit[6], sIbranch_in[BRANCH_ID];
  char  sIpolicy1[POLICY_NUM_1], sIpolicy2[POLICY_NUM_2];
  $char ifpce_id_ext[3];
  $char Isettle_type[2];

   $WHENEVER SQLERROR GOTO errexit;

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
	   kTot_Col, kPgNum_Line, kWidth
      INTO $TitleFmt, $BodyFmt,  $StartRow,  $TitleRow,  $ItemRow,
	   $TotColumn, $PgLine, $Width
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID=519 ;
     /*WHERE ksys_grp="CA" AND kPgmID=519 AND iform_tp='1'; */

   strcpy( TitleFmt,rtrim(TitleFmt));
   strcpy( BodyFmt,rtrim(BodyFmt));
   sprintf_s( TitleFile, N_FILE+1,"%s.ti",outputf);
   sprintf_s( BodyFile, N_FILE+1,"%s.bd",outputf);
   printf("TitleFile=%s, BodyFile=%s\n",TitleFile,BodyFile);

   max_count = 0;

/**** build title ***/
   rgu_init_report( TitleFmt,TitleFile);
   car519_title();
   rgu_finish_report();

/**** initial body ***/
   rgu_init_report( BodyFmt,BodyFile);

   /***** P r o c e s s   b e g i n   *****/
   $SELECT nchi_abv
      INTO $nchiabv
      FROM branch
     WHERE ibranch = $DBName;

      car519_grp(i);
      T11= T12= T13= T14=  T21= T22= T23= T24=	T31= T32= T33= T34=  0;
      P11= P12= P13= P14=  P21= P22= P23= P24=	P31= P32= P33= P34=  0;
      D1= D2= D3= D4=  0;
      LoP = 0;
	  mspeed1 = mspeed2 = mspeed3 = mspeed4 = mspeed5 = mspeed6 = mspeed7 = mspeed8 = 0;



      /*** ca_local_stl ***/
      $DECLARE Icur CURSOR FOR
	SELECT ipolicy, iclaim, fstl, iclose_type
	  INTO $XIpolicy, $XIclaim, $XFstl, $XIclose_type
	  FROM ca_local_stl
	 WHERE dclose = $clsdate_ED
	   AND qserial = $qserial
	 ORDER BY iclaim, fstl, iclose_type;
      $OPEN Icur;
      while(1)
      {
	 $FETCH Icur;
	 if( SQLCODE == SQLNOTFOUND) break;

	 printf("miy[%d] LINDofPAGE[%d] \n",miy, LINEofPAGE);

	 if ( miy >= LINEofPAGE )
	 {
	     car519_nextpage();
	 }

	 /*memcpy( DBName3, XIpolicy, 2); */ DBName3[2]='\0';
         printf ("kldebug 1 \n");
       if ((rtncode = split_policy(XIpolicy, sIpolicy1, sIpolicy2)) != M_CM_OK)
                   return rtncode;

         rtncode = cm_get_unit_in(sIpolicy1, DBName, " ", sIunit,"C3",
                            DBName3, sIbranch_in);
         if(rtncode != M_CM_OK)
         return  rtncode;

	 DBName3[2]='\0';
printf(" ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ 	DBName3[%s]\n",DBName3);
	 strcpy(sFullName, get_full_dbname(DBName3));

         printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$   sFullName[%s]\n",sFullName);
	 /*** settlement ***/
	 sprintf_s(sStmt,1024,
	   "SELECT iadjuster, vouch_state, fcard_class, frecover, fsale \
		      FROM %s:settlement \
	     WHERE iclaim = ? AND fstl = ? AND iclose_type = ? ",
		 sFullName);
	 $PREPARE body_1 FROM $sStmt;
	 $DECLARE Jcur CURSOR FOR body_1;
	 $OPEN Jcur USING $XIclaim, $XFstl, $XIclose_type;
         printf ("settlement\n");
	 while(1)
         {

	    $FETCH Jcur INTO $YIadjuster, $vouch_state, $fcard_class, $frecover, $fsale ;
	    if( SQLCODE == SQLNOTFOUND) break;

        YMdmg_stl = lGetStlVal(sFullName, "1", "1", XIclaim, XFstl, XIclose_type);
        YMbrg_stl = lGetStlVal(sFullName, "1", "2", XIclaim, XFstl, XIclose_type);
        YMparts_stl = lGetStlVal(sFullName, "1", "3", XIclaim, XFstl, XIclose_type);
        YMlia_stl = lGetStlVal(sFullName, "1", "4", XIclaim, XFstl, XIclose_type);
        YMinj_stl = lGetStlVal(sFullName, "1", "5", XIclaim, XFstl, XIclose_type);

        YMdmg_proc = lGetStlVal(sFullName, "2", "1", XIclaim, XFstl, XIclose_type);
        YMlia_proc = lGetStlVal(sFullName, "2", "2", XIclaim, XFstl, XIclose_type);


	    D1 += YMdmg_stl + YMbrg_stl + YMparts_stl;
	    D3 += YMlia_stl + YMinj_stl;

	    D2 += YMdmg_proc;
	    D4 += YMlia_proc;

            /*** adjustment_ply ***/
	    sprintf_s(sStmt,1024, "SELECT nassured[1,12] \
		 	      FROM %s:adjustment_ply \
			     WHERE iclaim = '%s'",
		    sFullName, XIclaim);
	    $PREPARE body_2 FROM $sStmt;
	    $DECLARE body2_cursor CURSOR FOR body_2;
	    $OPEN body2_cursor;
	    $FETCH body2_cursor INTO $YNassured;
	    if(SQLCODE == SQLNOTFOUND) strcpy(YNassured, " ");
	    $CLOSE body2_cursor;
	    $FREE  body2_cursor;
            printf ("adjustment_ply\n");

	    rc = car519_body();
		if (rc != 0 )
			goto errexit;
printf(" ******************************** iclaim[%s] \n",XIclaim);
            /*** payment ***/
	   sprintf_s(sStmt,1024, "SELECT ipayment, nchi_full, mpayment, fspeed, xfpay_cond, pay_kind, qserial, ifpce_id_ext \
			     FROM %s:payment \
			    WHERE iclaim = '%s' \
                              AND fstl = '%s' \
			      AND iclose_type = %d",
		      sFullName, XIclaim, XFstl, XIclose_type);
	   $PREPARE sp_kid7 FROM $sStmt;
	   $DECLARE Icur7k CURSOR FOR sp_kid7;
	   $OPEN Icur7k ;
           printf  ("payment \n");
	   while(1)
	   {
	     $FETCH Icur7k INTO $Ipayment, $Nchi_full, $Mpayment, $fspeed, $xfpay_cond, $pay_kind, $pay_qserial, $ifpce_id_ext;
	     if (SQLCODE == SQLNOTFOUND) break;

             strncpy (Nchi_abv, Nchi_full, 12);
			 /*** �ߥI�t�פ��� ***/
			 if (fspeed[0] == '1')
				 mspeed1 += Mpayment;
			 else if (fspeed[0] == '2')
				 mspeed2 += Mpayment;
			 else if (fspeed[0] == '3')
				 mspeed3 += Mpayment;
			 else if (fspeed[0] == '4')
				 mspeed4 += Mpayment;
			 else if (fspeed[0] == '5')
				 mspeed5 += Mpayment;
			 else if (fspeed[0] == '6')
				 mspeed6 += Mpayment;
			 else if (fspeed[0] == '7')
				 mspeed7 += Mpayment;
			 else if (fspeed[0] == '8')
				 mspeed8 += Mpayment;
			 else
				 mspeed1 += Mpayment;
			 /*** �I�ڱ������ ***/
			 if (xfpay_cond[0] == '1' || xfpay_cond[0] == '3')
			 {
				 qremit ++;				/*�״ڵ���*/
				 mremit += Mpayment;	/*�״ڪ��B�X�p*/
			 }
			 else
			 {
				 qcheck ++;				/*�}������*/
				 mcheck += Mpayment;	/*�}�����B�X�p*/
			 }
			 qtotal ++;
			 mtotal += Mpayment;
	    /*
	     $SELECT nchi_abv
	        INTO $Nchi_abv
	        FROM customer_basic_inf
	       WHERE ifpce_id=$Ipayment;
	     if (SQLCODE == SQLNOTFOUND) strcpy(Nchi_abv, " "); */

         /*** �����O�_���߮v ***/
         strcpy(Isettle_type,"");         
         strcpy(Nsettle_type,"");   
         $SELECT isettle_type
            INTO $Isettle_type
            FROM cu_stl_obj
           WHERE ifpce_id =$Ipayment AND ifpce_id_ext = $ifpce_id_ext;
         if (SQLCODE == SQLNOTFOUND)
         {             
             strcpy(Nsettle_type, "");
         }
         else   
         {
            if (Isettle_type[0] == '3') 
            {
                strcpy(Nsettle_type, "�߮v");
            }
            else 
            {
                strcpy(Nsettle_type, "");
            }
         }

	     rc = car519_payment();
		 if (rc != 0 )
			 goto errexit;
	   }
	   $CLOSE Icur7k;
           $FREE  Icur7k;

	   rgu_put_body( 11);	miy++;

	    D1= D2= D3= D4=  0;
	    LoP += 1;
	 }
	 $CLOSE Jcur;
         $FREE  Jcur;
      }
      $CLOSE Icur;
      $FREE  Icur;
      if(LoP > 0)   car519_page();
      rc = car519_tot();
	  if (rc != 0 )
		goto errexit;

   /***** P r o c e s s   e n d   *****/

   rgu_finish_report();

   max_count = max_count + miy;

   return M_CM_OK;

errexit:
   printf("SQLCODE:[%ld]\n", SQLCODE);
   return SQLCODE;
}

/***************************************************************************/
void car519_title()
{
   char yy[4],mm[3],dd[3],close_serial[11],Serial[3];
   char dbt[3];

   /*strcpy(Tqserial, atoi(qserial)); */
   printf ("ca519-title\n");
   sprintf_s(Tqserial,4,"%d",qserial);
   printf ("Tqserial [%s]\n",Tqserial);
   rgu_put_head_string(1, cm_sysd_cdatetime_100(cm_get_sysd()));
   cm_split_ymd_100( clsdate, yy, mm, dd);
	strcpy(yy, substring(yy,2,2));

     if( qserial < 10 )
         sprintf_s( Serial, 3 , "0%s" ,Tqserial );
     else strcpy( Serial , Tqserial );

     strcpy(dbt,trim(DBName));
     sprintf_s( close_serial , 11 , "%s%s%s%s%s" ,dbt,yy,mm,dd,Serial);
     rgu_put_head_string(1, close_serial);
     rgu_put_head_string(1, yy);
     rgu_put_head_string(1, mm);
     rgu_put_head_string(1, dd);
/*     rgu_put_head_string(1, Tqserial);   */
   rgu_put_head();
}

/***************************************************************************/
void car519_grp(i)
int i;
{
   char str[21];

   nchiabv[6] = '\0';
   rgu_put_body_string(1, DBName, 1);
   rgu_put_body_string(1, nchiabv, 1);

   rfmtlong(Iqserial, "--,--&",str);
   rgu_put_body_string( 1, str, 2);

   rgu_put_body(1);   miy++;
}

/***************************************************************************/
void car519_body2()
{
   $char str[11];


   printf("[5192]:ply[%s],crd[%s],clm[%s],fstl[%s],type[%d]\n",
				ipolicy,icard,iclaim,fstl,iclose_type);

   rgu_put_body_string(1, ipolicy, 1);
   rgu_put_body_string(1, icard, 1);
   rgu_put_body_string(1, iclaim, 1);

   if( fstl[0] == '2')
       rgu_put_body_string( 1, "�l�v", 1);
   else if( fstl[0] == '1')
       rgu_put_body_string( 1, "�ߥI", 1);

   rfmtlong(iclose_type, "&&",str);
   rgu_put_body_string(1, str, 1);

   if (ftype[0]=='1')
	strcpy(str, "��  ��  �O");

   if (ftype[0]=='2')
        strcpy(str, "�{�����X��");

   if (ftype[0]=='3')
        strcpy(str, "��̬ҬO  ");

   rgu_put_body_string(1, str, 1);

   rgu_put_body(1);

   miy ++;
}

/***************************************************************************/
long car519_body()
{
   char  str[21];
	char yy[4],mm[3],dd[3],close_serial[11],Serial[3];
	$char sStmt[1024];
   char dbt[3];

   printf( "D1=[%ld], D2=[%ld], D3=[%ld], D4=[%ld]\n", D1, D2, D3, D4);

   rgu_put_body_string( 4, XIclaim, 1);
   rgu_put_body_string( 4, XIpolicy, 1);
   rgu_put_body_string( 4, YNassured, 1);

   rfmtlong(D1, "--,---,--&",str);  rgu_put_body_string( 4, str, 2);
   rfmtlong(D2, "--,---,--&",str);  rgu_put_body_string( 4, str, 2);
   rfmtlong(D3, "--,---,--&",str);  rgu_put_body_string( 4, str, 2);
   rfmtlong(D4, "--,---,--&",str);  rgu_put_body_string( 4, str, 2);

   rgu_put_body_string( 4, YIadjuster, 1);

   if( XFstl[0] == '2')
       rgu_put_body_string( 4, "�l�v", 1);
   else if( XFstl[0] == '1')
       rgu_put_body_string( 4, "�ߥI", 1);

   rfmtlong(XIclose_type, "&&",str);  rgu_put_body_string( 4, str, 1);

	if(vouch_state == 130)
		rgu_put_body_string( 4, "�q�lñ��", 1);
	else
		rgu_put_body_string( 4, "", 1);

    /*�P�_�l�v�O*/

    if(strcmp (trim(XFstl),"1") == 0 && strcmp (trim(frecover),"") == 0)
    {
     rgu_put_body_string( 4, "", 1);
    }
    else if(strcmp (trim(XFstl),"1") == 0 && strcmp (trim(frecover),"0") == 0)
    {
     rgu_put_body_string( 4, "���ݰl�v", 1);
    }
    else if(strcmp (trim(XFstl),"1") == 0 && strcmp (trim(frecover),"1") == 0)
    {
     rgu_put_body_string( 4, "�ۦ�l�v", 1);
    }
    else if(strcmp (trim(XFstl),"1") == 0 && strcmp (trim(frecover),"2") == 0)
    {
     rgu_put_body_string( 4, "�w�ۦ�l�v", 1);
    }
    else if(strcmp (trim(XFstl),"1") == 0 && strcmp (trim(frecover),"3") == 0)
    {
     rgu_put_body_string( 4, "�k�Ȱl�v", 1);
    }
    else if(strcmp (trim(XFstl),"1") == 0 && strcmp (trim(frecover),"4") == 0)
    {
     rgu_put_body_string( 4, "�ۦ�l�v��k�Ȱl�v", 1);
    }
    else if(strcmp (trim(XFstl),"1") == 0 && strcmp (trim(frecover),"5") == 0)
    {
     rgu_put_body_string( 4, "�j���I�u��", 1);
    }
    else if(strcmp (trim(XFstl),"1") == 0 && strcmp (trim(frecover),"6") == 0)
    {
     rgu_put_body_string( 4, "�j���I�N���u�^", 1);
    }
    else if(strcmp (trim(XFstl),"1") == 0 && strcmp (trim(frecover),"7") == 0)
    {
     rgu_put_body_string( 4, "�\�i�K�l�v(����)", 1);
    }
    else if(strcmp (trim(XFstl),"2") == 0 && strcmp (trim(frecover),"") == 0)
    {
     rgu_put_body_string( 4, "", 1);
    }
    else if(strcmp (trim(XFstl),"2") == 0 && strcmp (trim(frecover),"1") == 0)
    {
     rgu_put_body_string( 4, "�l�v��", 1);
    }
    else if(strcmp (trim(XFstl),"2") == 0 && strcmp (trim(frecover),"3") == 0)
    {
     rgu_put_body_string( 4, "�l�v����", 1);
    }

    /*�P�_�u�ߧO*/

    if(strcmp (trim(XFstl),"1") == 0 && strcmp (trim(fcard_class),"1") == 0 && strcmp (trim(fsale),"") == 0)
    {
     rgu_put_body_string( 4, "", 1);
    }
    else if(strcmp (trim(XFstl),"1") == 0 && strcmp (trim(fcard_class),"1") == 0 && strcmp (trim(fsale),"0") == 0)
    {
     rgu_put_body_string( 4, "�����u��", 1);
    }
    else if(strcmp (trim(XFstl),"1") == 0 && strcmp (trim(fcard_class),"1") == 0 && strcmp (trim(fsale),"1") == 0)
    {
     rgu_put_body_string( 4, "���u��", 1);
    }
    else if(strcmp (trim(XFstl),"1") == 0 && strcmp (trim(fcard_class),"2") == 0 && strcmp (trim(fsale),"") == 0)
    {
     rgu_put_body_string( 4, "", 1);
    }
    else if(strcmp (trim(XFstl),"1") == 0 && strcmp (trim(fcard_class),"2") == 0 && strcmp (trim(fsale),"0") == 0)
    {
     rgu_put_body_string( 4, "���ݩ��", 1);
    }
    else if(strcmp (trim(XFstl),"1") == 0 && strcmp (trim(fcard_class),"2") == 0 && strcmp (trim(fsale),"1") == 0)
    {
     rgu_put_body_string( 4, "�ݩ��", 1);
    }
    else if(strcmp (trim(XFstl),"1") == 0 && strcmp (trim(fcard_class),"2") == 0 && strcmp (trim(fsale),"2") == 0)
    {
     rgu_put_body_string( 4, "���u�ߧt�S��", 1);
    }
    else if(strcmp (trim(XFstl),"2") == 0 && strcmp (trim(fsale),"") == 0)
    {
     rgu_put_body_string( 4, "", 1);
    }
    else if(strcmp (trim(XFstl),"2") == 0 && strcmp (trim(fsale),"3") == 0)
    {
     rgu_put_body_string( 4, "��槹��", 1);
    }

   rgu_put_body( 4);   miy++;

   if( XFstl[0] == '2') {
      P21 += D1;
      P22 += D2;
      P23 += D3;
      P24 += D4;
   } else {
      P11 += D1;
      P12 += D2;
      P13 += D3;
      P14 += D4;
   }
	/*** �p��Ѥ������H ca_stl_close_obj for claim ***/
	sprintf_s(Tqserial,4,"%d",qserial);
	cm_split_ymd_100( clsdate, yy, mm, dd);
	strcpy(yy, substring(yy,2,2));
	if( qserial < 10 )
		sprintf_s( Serial ,3 , "0%s" ,Tqserial );
	else strcpy( Serial , Tqserial );
printf("max flag11\n");
        strcpy(dbt,trim(DBName));
	sprintf_s( close_serial , 11 , "%s%s%s%s" ,yy,mm,dd,Serial);


        /****************************************************************  Mark 1020719
	if (option[0] == '1')
	{
	sprintf_s(sStmt,1024,"INSERT INTO ca_stl_close_obj(ibatch_no,ibranch,iclaim,fstl,iclose_type,ipolicy,nassured,mdmg_stl,mdmg_proc,mlia_stl,mlia_proc,iadjuster) \
					VALUES('%s','%s','%s','%s',%d,'%s','%s',%d,%d,%d,%d,'%s')",
						close_serial,DBName,XIclaim,XFstl,XIclose_type,XIpolicy,YNassured,D1,D2,D3,D4,YIadjuster);
printf("stmt==>[%s]\n",sStmt);
	$PREPARE close_claim FROM $sStmt;
	$EXECUTE close_claim;
	}
        *****************************************************************/
printf("max flag12\n");
	return 0;
	errexit:
		printf("SQLCODE:[%ld]\n", SQLCODE);
		return SQLCODE;


}

/***************************************************************************/
void car519_page()
{
   char str[ 21];

   P31 = P11-P21;
   P32 = P12+P22;
   P33 = P13-P23;
   P34 = P14+P24;

   rgu_put_body( 2);   miy++;

   T11+=P11; T12+=P12; T13+=P13; T14+=P14;
   T21+=P21; T22+=P22; T23+=P23; T24+=P24;
   T31+=P31; T32+=P32; T33+=P33; T34+=P34;
}

/***************************************************************************/
long car519_tot()
{
	char str[ 21];
	char yy[4],mm[3],dd[3],close_serial[11],Serial[3];
	$char sStmt[1024];
        char dbt[3];

	rfmtlong(T11, "---,---,--&",str);  rgu_put_body_string( 8, str, 2);
	rfmtlong(T12, "--,---,--&",str);  rgu_put_body_string( 8, str, 2);
	rfmtlong(T13, "---,---,--&",str);  rgu_put_body_string( 8, str, 2);
	rfmtlong(T14, "--,---,--&",str);  rgu_put_body_string( 8, str, 2);
	rgu_put_body( 8);   miy++;

	rfmtlong(T21, "---,---,--&",str);  rgu_put_body_string( 9, str, 2);
	rfmtlong(T22, "--,---,--&",str);  rgu_put_body_string( 9, str, 2);
	rfmtlong(T23, "---,---,--&",str);  rgu_put_body_string( 9, str, 2);
	rfmtlong(T24, "--,---,--&",str);  rgu_put_body_string( 9, str, 2);
	rgu_put_body( 9);   miy++;

	rfmtlong(T31, "---,---,--&",str);  rgu_put_body_string( 10, str, 2);
	rfmtlong(T32, "--,---,--&",str);  rgu_put_body_string( 10, str, 2);
	rfmtlong(T33, "---,---,--&",str);  rgu_put_body_string( 10, str, 2);
	rfmtlong(T34, "--,---,--&",str);  rgu_put_body_string( 10, str, 2);
	rgu_put_body(10);   miy = miy +3 ;
	rgu_put_body(13);   miy++;
	rgu_put_body( 2);   miy++;
printf("max flag1\n");
	/*** �p��Ѥ���D�� ca_stl_close_main ***/
	sprintf_s(Tqserial,4,"%d",qserial);
	cm_split_ymd_100( clsdate, yy, mm, dd);
	strcpy(yy, substring(yy,2,2));
	if( qserial < 10 )
		sprintf_s( Serial , 3 , "0%s" ,Tqserial );
	else strcpy( Serial , Tqserial );
        strcpy(dbt,trim(DBName));
	sprintf_s( close_serial , 11 , "%s%s%s%s" ,yy,mm,dd,Serial);

        /**********************************************************    Mark 1020719
	if (option[0] == '1')
	{
	sprintf_s(sStmt,1024,"INSERT INTO ca_stl_close_main(ibatch_no,ibranch,mspeed1,mspeed2,mspeed3,mspeed4,mspeed5,mspeed6,mspeed7,mspeed8,qremit,mremit,qcheck,mcheck,qtotal,mtotal) \
					VALUES('%s','%s',%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d)",
						close_serial,DBName,mspeed1,mspeed2,mspeed3,mspeed4,mspeed5,mspeed6,mspeed7,mspeed8,qremit,mremit,qcheck,mcheck,qtotal,mtotal);
printf("sStmt==>[%s]\n",sStmt);
	$PREPARE close_main FROM $sStmt;
	$EXECUTE close_main;
	}
        ***********************************************************/

printf("max flag2\n");
	/*** �p��Ѥ�����|�p�l���� ca_stl_close_acc ***/

        /**********************************************************     Mark 1020719
	if (option[0] == '1')
	{
	sprintf_s(sStmt,1024,"INSERT INTO ca_stl_close_acc \
		SELECT '%s', '%s', b.insure_kind,sum(decode(b.fstl,'2',0,b.mstl)),sum(b.mproc),sum(decode(b.fstl,'1',0,b.mstl))  \
			FROM ao_stl_close a INNER JOIN ao_stl_close_dtl b \
			ON a.iclose = b.iclose AND a.fstl = b.fstl AND a.iclose_type = b.iclose_type \
			WHERE a.ibatch = '%s%s' \
			GROUP BY 1,2,3",close_serial,DBName,dbt,close_serial);
	$PREPARE close_acc FROM $sStmt;
	$EXECUTE close_acc;
	}
        ***********************************************************/

printf("max flag3\n");
	return 0;

	errexit:
		printf("SQLCODE:[%ld]\n", SQLCODE);
		return SQLCODE;

}

/***************************************************************************/
long car519_payment()
{
	char buf[21];
	char yy[4],mm[3],dd[3],close_serial[11],Serial[3];
	$char sStmt[1024];
        char dbt[3];

  rgu_put_body_string(12, Ipayment, 1);
  rgu_put_body_string(12, Nchi_abv, 1);
  rfmtlong(Mpayment, "--,---,--&",buf);
  rgu_put_body_string(12, buf, 2);
  rgu_put_body_string(12, Nsettle_type, 1);
  rgu_put_body(12);   miy++;
  /*** �p��Ѥ������H ca_stl_close_obj for payment ***/
	sprintf_s(Tqserial,4,"%d",qserial);
	cm_split_ymd_100( clsdate, yy, mm, dd);
	strcpy(yy, substring(yy,2,2));
	if( qserial < 10 )
		sprintf_s( Serial, 3 , "0%s" ,Tqserial );
	else strcpy( Serial , Tqserial );
printf("max flag21\n");
        strcpy(dbt,trim(DBName));
	sprintf_s( close_serial ,11 , "%s%s%s%s" ,yy,mm,dd,Serial);

        /*******************************************************     Mark 1020719
	if (option[0] == '1')
	{
	sprintf_s(sStmt,1024,"INSERT INTO ca_stl_close_obj(ibatch_no,ibranch,iclaim,fstl,iclose_type,ipayment,nchi_full,xfpay_cond,mdmg_stl,pay_kind,qserial) \
					VALUES('%s','%s','%s','%s',%d,'%s','%s','%s',%d,'%s',%d)",
						close_serial,DBName,XIclaim,XFstl,XIclose_type,Ipayment,Nchi_full,xfpay_cond,Mpayment,pay_kind,pay_qserial);
printf("stmt==>[%s]\n",sStmt);
	$PREPARE close_payment FROM $sStmt;
	$EXECUTE close_payment;
	}
        *********************************************************/

printf("max flag22\n");
	return 0;
	errexit:
		printf("SQLCODE:[%ld]\n", SQLCODE);
		return SQLCODE;

}
/***************************************************************************/

void car519_nextpage()
{

   printf(" in next_page \n");

   rgu_put_body(2);
   rgu_put_body(13);
   rgu_put_body(3);

   nchiabv[6] = '\0';
   rgu_put_body_string(1, DBName, 1);
   rgu_put_body_string(1, nchiabv, 1);
   rgu_put_body(1);

   miy = miy +3;

   max_count = max_count + miy;
   miy = 0;


}

/* -------------------------------------------------------------------------- */
/* ���l�״_���v�q�� add by sylvia 106.09.01 (105.526001_C1)

   �߮פ鵲�ɶ��G 00:00-14:00 ==>���ѤU�� 14:20 �o�email (project_id = 'CAR5191)
   �߮פ鵲�ɶ��G 14:01-23:59 ==>�j�ѤW�� 08:15 �o�email (project_id = 'CAR5194)
 */
long car519_email_A()
{
    DBinfo  *list;

    $char mbuf[9000];
    $loc_t ctxt;
    $char eml_iclaim[21], eml_fstl[2], eml_fpart[2], eml_ipolicy[21],
          eml_ipayment[11], eml_npayment[101], eml_xiaccount[15],
          eml_project_id[8],receiver_email[51], receiver_name[17],
          eml_xibank[8], fcompensation[2], eml_str1[31];
    $char plydbname[25], stpstr1[500], stmt2[1000];
    $int  icnt, iclose_type;


    if (db_select(DBName) == False)
    {
        EWRITE(userid, M_CM_DB_NOTOPEN, " ");
        return M_CM_DB_NOTOPEN;
    }

    printf("  *********************car519 email_A \n");

    sprintf_s(stmt,1024,"SELECT a.iclaim, a.iclose_type, b.ibranch_in \
                    FROM ca_local_stl a, ca_clm_process b \
                   WHERE a.iclaim = b.iclaim \
                     and a.dclose = '%s' AND a.qserial = %d  \
                     and a.fstl = '1' ", clsdate_ED, qserial);
    printf("stmt[%s]\n",stmt);
    $PREPARE pre_A1 FROM $stmt;
    $DECLARE cur_A1 CURSOR for pre_A1;
    $OPEN cur_A1;
    while(1)
    {
    	$FETCH cur_A1 INTO $eml_iclaim, $iclose_type, $sLocalDB;
        if( SQLCODE == SQLNOTFOUND ) break;

        strcpy(eml_ipolicy, trim(eml_ipolicy));
        strcpy(plydbname , get_full_dbname(sLocalDB));

        printf("eml_iclaim=[%s]\n",eml_iclaim);

        /* "   AND qserial = %d " qserial,  */
        sprintf_s(stmt2,1000, "select b.ipolicy, c.ipayment, c.npayment, c.xiaccount, "
                      "       case when current hour to minute between '00:00' and '14:00' then "
                      "       'CAR5191' else 'CAR5194' end, xibank, b.fcompensation  "
                      "  from %s:appraisal b, %s:payment c, %s:policy d "
                      " where b.iclaim = c.iclaim and b.ipolicy = d.ipolicy "
                      "   and c.fstl = '1' and c.iclose_type = %d "
                      "   and c.ipayment = d.iassured "
                      "   and d.iassured = d.iapplicant and b.fpart <> '4' "
                      "   and b.fcompensation in ('0','1') "
                      "   and b.iclaim = '%s' ",
                      plydbname, plydbname, plydbname, iclose_type, eml_iclaim);

         printf("stmt2=[%s]\n",stmt2);
         $PREPARE pre_A2 FROM $stmt2;
         $DECLARE cur_A2 CURSOR for pre_A2;
         $OPEN cur_A2;
         $FETCH cur_A2 INTO $eml_ipolicy, $eml_ipayment, $eml_npayment, $eml_xiaccount,
    	                    $eml_project_id, $eml_xibank, $fcompensation;


    	 if( SQLCODE != SQLNOTFOUND )
    	 {
    	    strcpy(eml_ipolicy, trim(eml_ipolicy));
    	    strcpy(eml_ipayment, trim(eml_ipayment));
    	    strcpy(eml_npayment, trim(eml_npayment));
    	    strcpy(eml_xiaccount, trim(eml_xiaccount));
    	    strcpy(eml_project_id,trim(eml_project_id));
    	    strcpy(eml_xibank,trim(eml_xibank));

    	    if (strcmp(fcompensation, "0") == 0)
    	        sprintf_s(eml_str1,31, "%s (%s) ",fcompensation, "���l�αj���I");
    	    else if (strcmp(fcompensation, "1") == 0)
    	        sprintf_s(eml_str1,31, "%s (%s) ",fcompensation, "�{�����v");
    	    else
    	        sprintf_s(eml_str1,31, "%s (%s) ",fcompensation, "�{�����~,�Ь���T��");

        printf("eml_str1 = [%s]\n",eml_str1);
           /* printf("eml_ipolicy=[%s]eml_iclaim=[%s]\n",eml_ipolicy,eml_iclaim);
            printf("eml_ipayment=[%s]\n",eml_ipayment);
            printf("eml_npayment=[%s]\n",eml_npayment);
            printf("eml_xiaccount=[%s]\n",eml_xiaccount);
            printf("eml_project_id=[%s]\n",eml_project_id); */


            /* mail���e */
            sprintf_s(mbuf,9000,
                "1.�ЧY�n��smartflow�h�O�O�J��M�� <br>\n"
                "2.�q���]�ȳ��|�p�ߧY�B�z <br>\n"
                "3.��]�ȳ����Ǭ����I�� <br>\n"
                "4.�йj��W�Z�dpay201�T�w��I <br>\n"
                "5.�O�渹�X:%s <br>\n"
                "6.�߮׽s��:%s <br>\n"
                "  ���v�O: %s <br>\n"
                "7.�n(�Q)�O�I�H�m�W�G %s  <br>\n"
                "8.�n(�Q)�O�I�H����N��/�b��:  %s �� %s <br>\n",
                eml_ipolicy, eml_iclaim, eml_str1, eml_npayment, eml_xibank, eml_xiaccount);

            printf("************mbuf[%s]",mbuf);
            ctxt.loc_loctype = LOCMEMORY;
            ctxt.loc_buffer = mbuf;
            ctxt.loc_bufsize = 9000;
            ctxt.loc_size =  strlen(mbuf) + 1;

            if (strcmp(eml_project_id,"CAR5191") == 0)
                mdate = cm_today();     /* ���� */
            else
                mdate = cm_today()+1;   /* �j�� */


            /* ���H�Hmail -- �]�w�b car_code  kind = 'CL , detail = 'EMAIL_CAR519' */
            $DECLARE cur_A3 CURSOR FOR
        	 SELECT email,chinese_name
        	   FROM personal:asempl
        	  WHERE empl_no in (select detail2 from car_code where kind = 'CL'
        	                       and detail = 'EMAIL_CAR519');
            $OPEN cur_A3;
            while(1)
            {
    	        $FETCH cur_A3 INTO $receiver_email, $receiver_name;
    	        if( SQLCODE == SQLNOTFOUND ) break;

                strcpy(receiver_email,trim(receiver_email));
                strcat(receiver_email,"@tmnewa.com.tw");
                strcpy(receiver_name, trim(receiver_name));

                $INSERT INTO batchemail
                    (project_id, mail_date, receiver_email, receiver_name, cc,
                     content, key, mail_count, nsubject)
                VALUES
                    ($eml_project_id, $mdate, $receiver_email, $receiver_name,	' ',
                     $ctxt,  ' ',  1, '���l�z�ߤΫO�I�h�O�@�֥I�ڧ@�~�q��');

            }
            $CLOSE cur_A3;
            $FREE cur_A3;
        }
        $CLOSE cur_A2;
        $FREE cur_A2;
    }
    $CLOSE cur_A1;
    $FREE  cur_A1;

    printf("total count[%d]\n",icount);

    return M_CM_OK;

errexit:
  printf("errexit, SQLCODE=[%ld] \n", SQLCODE);




}

/* -------------------------------------------------------------------------- */
/* �s�����l�״_���v�q�� add by sylvia 106.09.01 (105.526001_C1)
   �߮פ鵲�ɶ��G 00:00-16:00 ==>�j�ѤW�� 08:15 �o�email (project_id = 'CAR5194)
   �߮פ鵲�ɶ��G 16:01-23:59 ==>�j2�ѤW�� 08:15 �o�email (project_id = 'CAR5194)
   */
long car519_email_B()
{
    DBinfo  *list;

    $char mbuf[9000];
    $loc_t ctxt;
    $char eml_iclaim[21], eml_fstl[2], eml_fpart[2], eml_ipolicy[21],
          eml_ipayment[11], eml_npayment[101], eml_xiaccount[15],
          eml_project_id[9],receiver_email[51], receiver_name[17],
          eml_xibank[8], fcompensation[2], eml_str1[31],
          sIassured[11], sIapplicant[11], sNassured[121], sNapplicant[121],
          sRelation[2];
    $char plydbname[25], stpstr1[500], stmt2[2000];
    $int  icnt, iclose_type, iClmCnt;


    if (db_select(DBName) == False)
    {
        EWRITE(userid, M_CM_DB_NOTOPEN, " ");
        return M_CM_DB_NOTOPEN;
    }

    printf(" ********* car519 email_B ********* \n");

    sprintf_s(stmt,1024,"SELECT a.iclaim, a.iclose_type, b.ibranch_in \
                    FROM ca_local_stl a, ca_clm_process b \
                   WHERE a.iclaim = b.iclaim \
                     and a.dclose = '%s' AND a.qserial = %d  \
                     and a.fstl = '1' ", clsdate_ED, qserial);
    printf("stmt[%s]\n",stmt);
    $PREPARE pre_B1 FROM $stmt;
    $DECLARE cur_B1 CURSOR for pre_B1;
    $OPEN cur_B1;
    while(1)
    {
    	$FETCH cur_B1 INTO $eml_iclaim, $iclose_type, $sLocalDB;
        if( SQLCODE == SQLNOTFOUND ) break;

        strcpy(eml_ipolicy, trim(eml_ipolicy));
        strcpy(plydbname , get_full_dbname(sLocalDB));

        iClmCnt = 0;
        /* "   AND qserial = %d " qserial,  */
        sprintf_s(stmt2,2000, "select b.ipolicy, c.ipayment, c.npayment, c.xiaccount, "
                      "       case when current hour to minute between '00:00' and '16:00' then "
                      "       'CAR519B1' else 'CAR519B2' end, xibank, b.fcompensation,  "
                      "       d.iassured, d.nassured, d.iapplicant, d.napplicant, "
                      "       case when fcompensation = '2' then 'd' else "
                      "             case when c.ipayment = d.iassured then "
                      "                  case when d.iassured = d.iapplicant then 'a' "
                      "                     else 'b' end "
                      "             else 'c' end "
                      "       end "
                      "  from %s:appraisal b, %s:payment c, %s:policy d, %s:stl_ins_type e "
                      " where b.iclaim = c.iclaim and b.ipolicy = d.ipolicy "
                      "   and c.fstl = '1' and c.iclose_type = %d "
                      "   and b.fpart <> '4' and c.pay_kind in ('1','2') "
                      "   and b.fcompensation in ('1','2') "
                      "   and b.iclaim = '%s' "
                      "   AND e.iclaim = c.iclaim   AND e.iclose_type = c.iclose_type "
                      "   AND e.fstl = c.fstl    AND e.iins_type IN "
                      "       (SELECT x.iins_type "
                      "          FROM insurance_type x, cu_code_data y "
                      "         WHERE x.iins_type_tradevan = y.icode "
                      "           AND y.itype = 'H2' "
                      "         UNION ALL "
                      "        SELECT icode FROM cu_code_data WHERE itype = 'HA') ",

                      plydbname, plydbname, plydbname, plydbname, iclose_type, eml_iclaim);

         printf("stmt2=[%s]\n",stmt2);
         $PREPARE pre_B2 FROM $stmt2;
         $DECLARE cur_B2 CURSOR for pre_B2;
         $OPEN cur_B2;
         while(1)
         {
            $FETCH cur_B2 INTO $eml_ipolicy, $eml_ipayment, $eml_npayment, $eml_xiaccount,
    	                    $eml_project_id, $eml_xibank, $fcompensation,
    	                    $sIassured, $sNassured, $sIapplicant, $sNapplicant,
                            $sRelation;

            if( SQLCODE == SQLNOTFOUND ) break;

    	    strcpy(eml_ipolicy, trim(eml_ipolicy));
    	    strcpy(eml_ipayment, trim(eml_ipayment));
    	    strcpy(eml_npayment, trim(eml_npayment));
    	    strcpy(eml_xiaccount, trim(eml_xiaccount));
    	    strcpy(eml_project_id,trim(eml_project_id));
    	    strcpy(eml_xibank,trim(eml_xibank));

    	    strcpy(sIassured,rtrim(sIassured));
    	    strcpy(sNassured,rtrim(sNassured));
    	    strcpy(sIapplicant,rtrim(sIapplicant));
    	    strcpy(sNapplicant,rtrim(sNapplicant));


    	    if (strcmp(fcompensation, "2") == 0)
    	        sprintf_s(eml_str1,31, "%s (%s) ",fcompensation, "�״_���v");
    	    else if (strcmp(fcompensation, "1") == 0)
    	        sprintf_s(eml_str1,31, "%s (%s) ",fcompensation, "�{�����v");
    	    else
    	        sprintf_s(eml_str1,31, "%s (%s) ",fcompensation, "�{�����~,�Ь���T��");

            printf("eml_str1 = [%s]\n",eml_str1);

            printf("eml_ipolicy=[%s]eml_iclaim=[%s]\n",eml_ipolicy,eml_iclaim);
            printf("eml_ipayment=[%s]eml_npayment=[%s]\n",eml_ipayment,eml_npayment);
            printf("eml_xiaccount=[%s]eml_project_id=[%s]\n",eml_xiaccount,eml_project_id);
            printf("sIassured=[%s]sNassured=[%s]\n",sIassured,sNassured);
            printf("sIapplicant=[%s]sNapplicant=[%s]\n",sIapplicant,sNapplicant);
            printf("sRelation=[%s]\n",sRelation);

            /* eml_xiaccount �P�_
               �{�����v�G
                    a�i�ߥI��H�׳Q�O�I�H�׭n�O�H�j�G��ܡe�n�O�H�b��B�Q�O�H�b��]�Y�ߥI��H�b��^�f
                    b�i�ߥI��H�׳Q�O�I�H �ڭn�O�H�j�G��ܡe�n�O�H�b��B�Q�O�H�b�� �����* �f
                    c�i�ߥI��H�ڳQ�O�I�H�j         �G��ܡe�n�O�H�b��B�Q�O�H�b�� �����* �f
               �״_���v�Gd ��ܡe�n�O�H�b��B�Q�O�H�b�� �����* �f  */

               if (strcmp(sRelation,"a") != 0)
               {
                    strcpy(eml_xibank, "*******");
                    strcpy(eml_xiaccount,"**************");
               }

            /* mail���e */
            sprintf_s(mbuf,9000,
                "1.�Щ�12:00�e������� <br>\n"
                "2.�ХߧY�n��smartflow�h�O�O�J�`�M�� <br>\n"
                "3.�Щ�15:00�e�q���]�ȳ��|�p�ߧY�B�z����]�ȳ��X�Ǭ����I�� <br>\n"
                "4.�O�渹�X:%s <br>\n"
                "5.�߮׽s��:%s <br>\n"
                "6 ���v�O: %s <br>\n"
                "7.�n�O�I�H�m�W�G %s  <br>\n"
                "8.�Q�O�I�H�m�W�G %s  <br>\n"
                "9.�n�O�I�H����N��/�b��:  %s �� %s <br>\n"
                "10.�Q�O�I�H����N��/�b��:  %s �� %s <br>\n"
                "11.���v�O���״_���v�ɡA�Цۦ��v���t�άd�߭n�O�H�b��P���l�״_���v�T�{�� <br>\n"
                "12.�X�I�������I�B�ѵs�I�Ψ�X�I���[�I������z�פ�A�����h�O�O�C<br>\n",
                eml_ipolicy, eml_iclaim, eml_str1, sNapplicant, sNassured,
                eml_xibank, eml_xiaccount, eml_xibank, eml_xiaccount);

            printf("************mbuf[%s]",mbuf);
            ctxt.loc_loctype = LOCMEMORY;
            ctxt.loc_buffer = mbuf;
            ctxt.loc_bufsize = 9000;
            ctxt.loc_size =  strlen(mbuf) + 1;

            if (strcmp(eml_project_id,"CAR519B1") == 0)
                mdate = cm_today()+1;       /* �j�� */
            else
                mdate = cm_today()+2;       /* �j2�� */


            /* ���H�Hmail -- �]�w�b car_code  kind = 'CL , detail = 'EMAIL_CAR519' */
            $DECLARE cur_B3 CURSOR FOR
        	 SELECT email,chinese_name
        	   FROM personal:asempl
        	  WHERE empl_no in (select detail2 from car_code where kind = 'CL'
        	                       and detail = 'EMAIL_CAR519');
            $OPEN cur_B3;
            while(1)
            {
    	        $FETCH cur_B3 INTO $receiver_email, $receiver_name;
    	        if( SQLCODE == SQLNOTFOUND ) break;

                strcpy(receiver_email,trim(receiver_email));
                strcat(receiver_email,"@tmnewa.com.tw");
                strcpy(receiver_name, trim(receiver_name));

                $INSERT INTO batchemail
                    (project_id, mail_date, receiver_email, receiver_name, cc,
                     content, key, mail_count, nsubject)
                VALUES
                    ('CAR5194', $mdate, $receiver_email, $receiver_name,	' ',
                     $ctxt,  ' ',  1, '���l�z�ߤΫO�I�h�O�@�֥I�ڧ@�~�q��');

            }
            $CLOSE cur_B3;
            $FREE cur_B3;

            iClmCnt++;
        }
        $CLOSE cur_B2;
        $FREE cur_B2;

        /* �H�@���d�s */
        if (iClmCnt > 0)
        {

            sprintf_s(mbuf,9000, "�߮׽s��:%s �����鵲�o�e %d �ʳq���H <br>\n",eml_iclaim, iClmCnt);
            ctxt.loc_loctype = LOCMEMORY;
            ctxt.loc_buffer = mbuf;
            ctxt.loc_bufsize = 9000;
            ctxt.loc_size =  strlen(mbuf) + 1;
            $INSERT INTO batchemail
                (project_id, mail_date, receiver_email, receiver_name, cc,
                 content, key, mail_count, nsubject)
             VALUES
                ('CAR5194', $mdate, 'sylvia@tmnewa.com.tw', '���Q�z', ' ',
                 $ctxt,  ' ',  1, '���l�z�ߤΫO�I�h�O�@�֥I�ڧ@�~�q��');

            $INSERT INTO batchemail
                (project_id, mail_date, receiver_email, receiver_name, cc,
                 content, key, mail_count, nsubject)
             VALUES
                ('CAR5194', $mdate, 'ealex@tmnewa.com.tw', '���ߥ�', ' ',
                 $ctxt,  ' ',  1, '���l�z�ߤΫO�I�h�O�@�֥I�ڧ@�~�q��');
        }
    }
    $CLOSE cur_B1;
    $FREE  cur_B1;

    printf("total count[%d]\n",icount);

    return M_CM_OK;

errexit:
  printf("errexit, SQLCODE=[%ld] \n", SQLCODE);

}