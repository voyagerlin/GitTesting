/************************************************
 * Copyright (C) 1995 Intellisys Corporation    *
 *                                              *
 * Program : car9994.ec  �j��M               *
 *                                              *
 ************************************************/
#include <stdio.h>
#include "api_xsrv.h"
#include "sqlfatal.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "car_common.h"
#include "safeclib.h"
#include <float.h>

/* standard data declaration */
FILE *fptr, *fptr_err;
$char userid[11], iquota[7];
char prtfile[80],outputf[80],outputf1[80];
char errmsg[200];
$char errFile[120];
/* end of standard data */
/* private data */
/* end of private data */

$char localdb[5],Taipei_FullName[20];
int  i, flag_check=0;
/* end of standard defined data */

char expdate[6];
char bgndate[11],enddate[11];
char option[2];

int   count_db,k; 
$char DBName[05];
$char msgbuf[128];
DBinfo *list;
char  sApHome[30];
int   rtncode,rc;
char  filename[30];
FILE  *fp;
char  file_catalog[200];
$char filename1[200];
$char data_yyyymm[7];

$char iproduct_tmp[3];
$long mprem_14 = 0,mprem_15 = 0,mprem_16 = 0,mprem_32 = 0;
$long mhealth_14 = 0,mhealth_15 = 0,mhealth_16 = 0,mhealth_32 = 0;

long car9994_get_db();
long car9994_build();
long car9994_final();

/*************************************************************/
main(argc,argv)
int argc;
char **argv;
{
	int rtncode,rc;
	
	strcpy(DBName,   isNULLstr(argv[1]));
	strcpy(userid,   isNULLstr(argv[2]));
	strcpy(expdate,  isNULLstr(argv[3]));
	strcpy(outputf,  isNULLstr(argv[4]));
	
	printf("DBName[%s],userid[%s],expdate[%s],outputf[%s] \n",DBName,userid,expdate,outputf);

	rc = car9994_get_db();
	if (rc != M_CM_OK)
	{
		return rc;
	}

	rc = car9994_build();
	if ( rc != SUCCESS ) {
	 	printf("error on car9991_build \n");
	 	EWRITE(userid, rc, errmsg);
		return rc;	
	}

	rc = car9994_final();
	if ( rc != SUCCESS ) {
	 	printf("error on car9991_show \n");
	 	EWRITE(userid, rc, errmsg);
		return rc;	
	}
}

long car9994_get_db()
{
	$whenever sqlerror goto errexit1;

	if (db_select(DBName) == DBName) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}
	
	rc = getApHome(sApHome);
	if (rc < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		EWRITE(userid,rc,msgbuf);
	 	return rc;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}	
	return M_CM_OK;

errexit1:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}

long car9994_build()
{
	$long  dwritten_l, tmp_dappraisal = 0;
	$char  drate_c[11];
	int    endyy,endmm;
	char   drate_yy[5],drate_mm[3],drate_dd[3];
	$char  iissue_yy[5];
	char   bgn_yy[5],bgn_mm[3],end_mm[3],prtstr[514];
	int    res,idx;
	$static date   Today;
	$char fsex[2],fmarriage[2],remotedb[5],aphome[40],imark[5];
	$char fsex_ply[2], fmarriage_ply[2], ibirth_ply[9], fcomp_class_ply[3];
	$char stmt[5120],ipro_year[5],ibrand[9],ibrand_new[9],fpt[2],icar_type[3],qcylinder_c[6];
	$double qpt = 0;
	$char fstl[2],dclaim[17],istl_recover[2],iacc_license[11],itag[CA_TAG_NUM];
	$char iclaim[21],ihealth[2],iacc_birth[9],iacc_birth_y[5],iengine[CA_ENGINE_NUM],ibody[CA_BODY_NUM],facc_sex[2];
	$char facc_marri[2],fcomp_class[3],facc_rel[2],iassured[13],iacc_reason[3];
	$char facc_duty[2],daccident[21],iacc_area[3],ipolicy[21],icard[21],iply_area[11],ipolicy_br[3];
	$long long_daccident;
	$long dply_begin = 0,dply_end = 0,bgndate_l,drate,enddate_l,prem_total,count1;
	$int iclose_type = 0,qacar_death = 0,qbcar_death = 0,qccar_death = 0,qacar_cripple = 0,qcylinder = 0;
	$int qbcar_cripple = 0,qccar_cripple = 0,qacar_injure = 0,qbcar_injure = 0,qccar_injure = 0;
	$date dgroup , ori_dgroup;
	$char  product_kind[3];
	
	char prtstr_1to25[460],dclaim_yyyy[5],dclaim_mm[3],dclaim_dd[3],oth_cardata[13];
	char ipolicy_5to19[13],dgroup_c[9],dgroup_yy[3],dgroup_mm[3],dgroup_dd[3];
	char dply_begin_c[11],dply_begin_yy[5],dply_begin_mm[3],dply_begin_dd[3];
	char dply_end_c[11],dply_end_yy[5],dply_end_mm[3],dply_end_dd[3];
	$char ibirth[9],ibirth_yyyy[5];
	char body[21],buf1[21],daccident_yyyy[5],daccident_yy[5];
	$char daccident_mm[3],daccident_dd[3],iins_item[5], victim[11];
	$long mlia_prem = 0,mbusiness,maintain;
	$double madjcom_prem = 0;
	$long  madjcom_prem_t;
	$long mcoverage,pel_cnt,sum_mapp_cover,sum_mins_stl,sum_mins_proc;
	$long mapp_cover_tot;
	$int  pel_cnt_A, pel_cnt_B, pel_cnt_C;
	$long sum_mstl_health,sum_all,sum_mins_health;
	$long tot_mcoverage_C00,tot_pel_cnt_C00,tot_sum_mapp_cover_C00,tot_sum_mins_stl_C00;
	$long tot_mcoverage,tot_pel_cnt,tot_sum_mapp_cover,tot_sum_mins_stl,victim_num;
	$long tot_sum_mstl_health,tot_sum_all,tot_sum_mins_proc,tot_sum_mins_health;
	$long tot_sum_mstl_health_C00,tot_sum_all_C00,tot_sum_mins_proc_C00,tot_sum_mins_health_C00;
	$long iself_duty,ioth_duty,ianoth_duty;
	$long mcoverage_A00,mcoverage_B00,mcoverage_C00;
	$int id1 = 0,id2 = 0,id3 = 0,id4 = 0,id5 = 0,id6 = 0;
	$int ishealth = 0;
	
	char ttday[21],ttday_yy[5],ttday_mm[3],ttday_dd[3];
	$long tmp_mins_stl , tmp_mins_proc , tmp_mstl_health , tmp_sum_all;
	
	$int  p_flag_close;
	$char flast[2],fflast[2];
	$char iproduct[13],dentry[11];
	$long p_msettle;
	$long tmp_mapp_cover;
	$char fcar_class[2],icode2[2];
	$char drate_ym[5];
	
	$char tmp_iins_item[5];
	$char tmp_ivictim[10];
	$int  tmp_iclose_type;
	$char  dpolicy_str[9];
	$char  dpolicy_eng[11];
	$char  icode[11];
	$char  drate_yyyymm[7];
	$char  victim_bak[11];
	$char  nclaim[3];
	$int   i_nclaim,stl_cnt;
	
	$char  company_flag,iclaim_flag;
	char  COMPANY_P[3];
	char  COMPANY_F[3];
	$char iclaim_a[21];
	char  companyid[3];
	int   rtn;
	$char  sFassured[2], facc_nation[2];
	$char  chk_fassured[2],chk_fsex[2];
	/* C00 mcoverage */
	$long  mcover_C1[15],mcover_C2[15];
	int    cxx;
	$char  ibroker[11], fbusiness[2],ibroker_top[11],bzfrom[3];
	
	$char ioth_fassured[2],ioth_cartype[3];
	$double ioth_qpt;
	$char ioth_fpt[2];
	$char ioth_tag[CA_TAG_NUM],ioth_card_company[3],ioth_icard[21];
	$long  mcoverageBC = 0;
	$char  ibrand6[7];
	$int   cnt = 0;
	$double mcompensation = 0, mstable = 0;
	$int qdrunk_driving = 0;
	$long mdrunk_prem = 0;
	$double mdrunk_pure_prem = 0;
	$long  mdrunk_pure_prem_l;
	$char chk_dpolicy[2];
	
	$char sIverify[21],sFsubrogation[2];
	
	$char iacc_birth_c[10];
	
	$char dclaim_1080101[2],facc_rel_bf[2];
	
	$int cnt_claim = 0;
	$char claim_iendorse[21],dgroup_tmp[11]; 
	
	$int chk_iendorse = 0;
	$char iendorse_tmp[21];
	$char dclaim_1090301[2];
	
	$int f_bgn_10811 = 0,cnt_L = 0;
	$char fcar_kind[2],irelative_ply[21];
	$char PLY_DB[31];
	$char stmtt[2048];
	
	$int cnt_payment = 0;
		
	/* ca_dev_clm_comp */
	$char  t_data_yyyymm[7],t_idata[2],t_fend_yn[2],t_fstl[2],t_istl_recover[2],t_ihealth[2],t_dclaim[9];
	$char  t_iclm_company[3],t_iclm_br[3],t_iclaim[15],t_istl_flag[2],t_dgroup[9],t_icard_company[3],t_icard_br[3],t_icard[16];
	$char  t_dply_begin[9],t_dply_end[9],t_iarea[3],t_iobjno[5],t_iissue_year[5],t_ipro_year[5],t_ibrand[9];
	$char  t_icar_type[3],t_icar_type_no[3],t_iengine[26],t_itag[13],t_fpt[2];
	$char  t_ioth_fassured[2],t_ioth_cartype[3],t_ioth_fpt[2],t_ioth_tag[13],t_ioth_comp_yn[2],t_ioth_card_company[3],t_ioth_card[18],t_fcomp_class[3];
	$char  t_drate_ym[7],t_fassured[2],t_iassured[11],t_dbirth[8],t_fsex[2],t_fmarriage[2];
	$char  t_facc_nation[2],t_iacc_license[11],t_iacc_birth[8],t_facc_sex[2],t_facc_marri[2],t_facc_rel[2];
	$char  t_iacc_reason[3],t_facc_duty[2],t_fsubrogation[2];
	$char  t_daccident[8],t_iacc_area[3],t_istl_class[4];
	$char  t_iproduct[13],t_bzfrom[3],t_dsend[9];
	$long  t_iclose_type,t_qcylinder,t_qpt,t_ioth_qpt,t_qdrunk_driving,t_mins_premium,t_mdrunk_prem;
	$long  t_iself_duty,t_ioth_duty,t_ianoth_duty;
	$long t_qacar_death,t_qacar_cripple,t_qacar_injure,t_qbcar_death,t_qbcar_cripple,t_qbcar_injure,t_qccar_death,t_qccar_cripple,t_qccar_injure;
	$long t_mcoverage,t_victim_num,t_mapp_cover,t_mins_stl,t_mins_proc,t_mstl_health,t_qhealth,t_mhealth,t_sum_all;
	$double t_madjcom_prem = 0,t_mbusiness = 0,t_maintain = 0,t_mcompensation,t_mstable = 0,t_mdrunk_pure_prem = 0;
	
	filename[0] = '\0';
	file_catalog[0] = '\0';
	sprintf_s(filename,30,"%s/rptftp/", sApHome);
	sprintf_s(filename1,200,"AUTOU17_%d.txt",atoi(expdate)+191100);
	strcpy(file_catalog, trim(filename));
	strcat(file_catalog, trim(filename1));
	printf("file_catalog[%s] \n",file_catalog);
	
	if ((fptr=fopen(file_catalog,"w")) == NULL)
	{
		sprintf_s(errmsg,200,"Cannot open print file:%s",outputf);
		return M_CM_OPEN_FILE_FAIL;
	}

	printf(">>>expdate=%s\n",expdate);
	strncpy(bgn_yy,&expdate[0],3); bgn_yy[3]='\0';
	strncpy(bgn_mm,&expdate[3],2); bgn_mm[2]='\0';
	
	if (strncmp(bgn_mm, "12",2) == 0)
	{
		endyy=atoi(bgn_yy)+1;
		endmm=1;
	}
	else
	{
	 	endyy=atoi(bgn_yy);
	 	endmm=atoi(bgn_mm)+1;
	}
	rfmtlong(endmm,"&&",end_mm);
	
	sprintf_s(bgndate,11,"%s/%s/%s",bgn_yy,bgn_mm,"01");
	sprintf_s(enddate,11,"%d/%s/%s",endyy,end_mm,"01");
	sprintf_s(data_yyyymm,7,"%s%s",itoa(atoi(bgn_yy)+1911),bgn_mm);
	printf(">>>bgndate=[%s] enddate=[%s]\n",bgndate,enddate);
	
	strcpy(dgroup_tmp,cm_to_infdate(bgndate));
	
	$WHENEVER SQLERROR GOTO errexit;
	
	rtn = getCompanyId(companyid);
	
	bgndate_l=cm_ymd_cdate(bgndate);
	enddate_l=cm_ymd_cdate(enddate);
	
	printf(">>>bgndate=[%d] enddate=[%d]\n",bgndate_l,enddate_l);
	
	/*43 ��ƻs�e���*/
	strcpy(ttday , cm_get_sysd());
	strncpy(ttday_yy,&ttday[0],4); ttday_yy[4] = '\0';
	strncpy(ttday_mm,&ttday[5],2); ttday_mm[2] = '\0';
	strncpy(ttday_dd,&ttday[8],2); ttday_dd[2] = '\0';
	
	count1=0;
	prem_total=0;

	/* 2005/03/01�H�e�ݼo���ūO�B */
	mcover_C1[0]=1400000;
	mcover_C1[1]=1170000;
	mcover_C1[2]=980000;
	mcover_C1[3]=860000;
	mcover_C1[4]=750000;
	mcover_C1[5]=630000;
	mcover_C1[6]=510000;
	mcover_C1[7]=420000;
	mcover_C1[8]=330000;
	mcover_C1[9]=260000;
	mcover_C1[10]=190000;
	mcover_C1[11]=120000;
	mcover_C1[12]=70000;
	mcover_C1[13]=50000;
	mcover_C1[14]=40000;
	/* 2005/03/01(�t)�H��ݼo���ūO�B */
	mcover_C2[0]=1500000;
	mcover_C2[1]=1250000;
	mcover_C2[2]=1050000;
	mcover_C2[3]=920000;
	mcover_C2[4]=800000;
	mcover_C2[5]=680000;
	mcover_C2[6]=550000;
	mcover_C2[7]=450000;
	mcover_C2[8]=350000;
	mcover_C2[9]=280000;
	mcover_C2[10]=200000;
	mcover_C2[11]=130000;
	mcover_C2[12]=80000;
	mcover_C2[13]=50000;
	mcover_C2[14]=40000;

     /***** prepare cursor for select ca_car_model *****/
     /* 1000530002�t�P�����N���H�ഫ�t�P�����N�����e */
	sprintf_s(stmt,5120, "SELECT ibrand_new "
                    "FROM ca_car_model "
                   "WHERE ibrand = ? "
                     "AND ibrand_new != ' ' "
                 "ORDER BY drate DESC;");
	$PREPARE pr_ibrand FROM $stmt;
	$DECLARE cur_ibrand CURSOR FOR pr_ibrand;
	printf("stmt[%s]\n", stmt);

	for(k=0;k<count_db;k++)
	{
		sprintf_s(stmt,5120,"DELETE FROM %s:ca_dev_clm_comp WHERE data_yyyymm = '%s' AND idata = 'U'",list[k].dbname,data_yyyymm);
		$PREPARE DE_ca_dev_clm_comp FROM $stmt;
		$EXECUTE DE_ca_dev_clm_comp ;
		
		sprintf_s(stmt,5120,"SELECT a.iclaim \
						FROM %s:ca_app_victim_hist a INNER JOIN %s:appraisal b ON a.iclaim = b.iclaim \
		                                             INNER JOIN %s:ply_ins_type c ON b.ipolicy = c.ipolicy \
		                                             INNER JOIN %s:adjustment_ply d ON b.iclaim = d.iclaim \
					   WHERE a.dappraisal < %ld \
		                 AND a.dappraisal = (select max(dappraisal) \
		                                       from %s:ca_app_victim_hist \
		                                      where a.iclaim = iclaim \
		                                        and a.iins_item = iins_item \
		                                        and a.ivictim = ivictim \
		                                        and dappraisal < %ld) \
		                 AND ((a.mapp_cover+a.mapp_fee)-(SELECT NVL(sum(mins_stl+mins_proc+mstl_health),0) \
		                                                   FROM %s:ca_stl_victim \
		                                                  WHERE a.iclaim = iclaim \
		                                                    AND a.ivictim = ivictim \
		                                                    AND a.iins_item = iins_item \
		                                                    AND fstl = '1' \
		                                                    AND dgroup < %ld) + \
		                                                (SELECT NVL(sum(mins_stl-mins_proc+mstl_health),0) \
		                                                   FROM %s:ca_stl_victim \
		                                                  WHERE a.iclaim = iclaim \
		                                                    AND a.ivictim = ivictim \
		                                                    AND a.iins_item = iins_item \
		                                                    AND fstl = '2' \
		                                                    AND dgroup < %ld) >= 0) \
		                                                    AND not exists (select * from %s:ca_stl_victim x \
		                                                                     where a.iclaim    = x.iclaim \
		                                                                       and a.ivictim   = x.ivictim \
		                                                                       and a.iins_item = x.iins_item \
		                                                                       and x.dgroup < %ld \
		                                                                       and ((x.iins_item[1] =  'A' and flast = '2') or \
		                                                                            (x.iins_item[1] <> 'A' and flast in('1','2')) or \
		                                                                            (x.iins_item[1] =  'A' and exists(select max(flast),sum(decode(fstl,'1',mins_stl+mins_proc,(-1)*mins_stl+mins_proc))  \
		                                                                                                                from %s:ca_stl_victim z  \
		                                                                                                               where z.iclaim = x.iclaim  \
		                                                                                                                 and z.iins_item = x.iins_item  \
		                                                                                                                 and z.ivictim = x.ivictim  \
		                                                                                                                 and z.dgroup < %ld  \
		                                                                                                              having max(flast) in('1','2') and sum(decode(fstl,'1',mins_stl+mins_proc,(-1)*mins_stl+mins_proc)) = 0 )))) \
		                  group by 1 ",list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,enddate_l,
		                               list[k].dbname,enddate_l,
		                               list[k].dbname,enddate_l,
		                               list[k].dbname,enddate_l,
		                               list[k].dbname,enddate_l,
		                               list[k].dbname,enddate_l);
		printf("stmt===>[%s]\n",stmt);
		$PREPARE car9994_claim FROM $stmt;
		$DECLARE car9994_claim_cur CURSOR FOR car9994_claim;
		$OPEN car9994_claim_cur;
		while(1)
		{
			$FETCH car9994_claim_cur INTO $iclaim;
			if (SQLCODE == SQLNOTFOUND) break;
			
			/***** �������z�w���ɸ�� *****/
			/* 0991022002�]�����F�������X�֭p�� */
			/* 1.���a�ϥN����42�u�x�����v�A�h�վ㬰41�u�x�����v */
			/* 2.���a�ϥN����63�u�x�n���v�A�h�վ㬰62�u�x�n���v */
			/* 3.���a�ϥN����65�u�������v�A�h�վ㬰64�u�������v */
			sprintf_s(stmt,5120,"SELECT dclaim,ipolicy ,icard ,iacc_license ,YEAR(dacc_birth),to_char(dacc_birth,'%%Y%%m%%d'),facc_sex, \
			                     facc_marri,facc_rel ,iacc_reason, facc_duty, \
			                     qacar_death,qacar_cripple,qacar_injure, \
			                     qbcar_death,qbcar_cripple,qbcar_injure, \
			                     qccar_death,qccar_cripple,qccar_injure,daccident, \
			                     DECODE(iacc_area,'42','41','63','62','65','64',iacc_area), facc_nation, DATE(daccident), \
			                     case when date(dclaim) >= '01/01/2019' then 'Y' else 'N' end, \
			                     case when date(dclaim) >= '03/01/2020' then 'Y' else 'N' end \
			                FROM %s:appraisal \
			               WHERE iclaim = '%s' ",list[k].dbname,iclaim);

			$PREPARE car9994_appraisal FROM $stmt;
			$EXECUTE car9994_appraisal INTO $dclaim,$ipolicy,$icard,$iacc_license,$iacc_birth_y,$iacc_birth,$facc_sex,
			                                $facc_marri ,$facc_rel,$iacc_reason,$facc_duty ,
			                                $qacar_death,$qacar_cripple,$qacar_injure,
			                                $qbcar_death,$qbcar_cripple,$qbcar_injure,
			                                $qccar_death,$qccar_cripple,$qccar_injure,
			                                $daccident,$iacc_area,$facc_nation,$long_daccident,
			                                $dclaim_1080101,$dclaim_1090301;

			/***** �����߮׫O��򥻸���� *****/
			sprintf_s(stmt,5120,"SELECT dply_begin,dply_end,DECODE(iply_area,'42','41','63','62','65','64',iply_area),YEAR(dissue),ipro_year,ibrand, \
			                     icar_type,qcylinder,iengine,ibody,itag, \
			                     fcomp_class,iassured,to_char(dbirth,'%%Y%%m%%d'),fsex,fmarriage, \
			                     CASE WHEN dply_begin >= '11/01/2019' THEN 1 ELSE 0 END \
			                FROM %s:adjustment_ply \
			               WHERE iclaim = '%s' ",list[k].dbname,iclaim);
			               
			$PREPARE car9994_adjustment_ply FROM $stmt;
			$EXECUTE car9994_adjustment_ply INTO $dply_begin,$dply_end,$iply_area,$iissue_yy,$ipro_year,$ibrand,
			                                     $icar_type,$qcylinder,$iengine,$ibody,$itag,
			                                     $fcomp_class,$iassured,$ibirth,$fsex,$fmarriage,
			                                     $f_bgn_10811;
			
			chk_iendorse = 0;
	        iendorse_tmp[0] = '\0';
	        strcpy(iendorse_tmp,getPolicyBakData(iclaim));
			strcpy(iendorse_tmp,trim(iendorse_tmp));
			printf("--iendorse_tmp[%s] \n",iendorse_tmp);
			strcpy(dclaim_1090301,trim(dclaim_1090301));
			/***** �����O����ɩM�O�����p�� *****/
			/*���z��1090301��}�l�ɥ���Ƨ�k*/
			if (strlen(iendorse_tmp) > 0 && strncmp(dclaim_1090301,"Y",1)==0)
			{		    
				chk_iendorse = 1;
				sprintf_s(stmt,5120,"SELECT a.qpt,a.fpt,b.madjcom_prem,b.mbusiness,(b.maintain + b.mresearch),b.mlia_prem,b.dpolicy, \
				                     b.fcomp_class, to_char(a.dbirth,'%%Y%%m%%d'), a.fsex, a.fmarriage, a.fassured, b.ibroker, \
				                     b.mcompensation, b.mstable, b.bzfrom,b.qdrunk_driving, \
				                     case WHEN b.dpolicy < '08/01/2016' THEN 'Y' else 'N' END,nvl(irelative_ply,'') \
				                FROM %s:policy_bak a , %s:ply_relation_bak b \
				               WHERE a.ipolicy = b.ipolicy \
				                 AND a.ipolicy = '%s'  \
				                 AND a.iendorse = b.iendorse \
				                 AND a.iendorse = '%s';" ,list[k].dbname,list[k].dbname,ipolicy,iendorse_tmp);
				printf("stmt[%s] \n",stmt);
				$PREPARE car9994_bak1 FROM $stmt;
				$EXECUTE car9994_bak1 INTO $qpt ,$fpt ,$madjcom_prem ,$mbusiness, $maintain ,$mlia_prem ,$dpolicy_eng,
				                           $fcomp_class_ply, $ibirth_ply, $fsex_ply, $fmarriage_ply, $sFassured, $ibroker,
				                           $mcompensation, $mstable, $bzfrom, $qdrunk_driving,
				                           $chk_dpolicy, $irelative_ply;
				                           
				/*�O�v�}�l�~��A���Ϥ��T�B����*/
				sprintf_s(stmt,5120,"SELECT drate_ym,nvl(iproduct,' '),mdrunk_prem,mdrunk_pure_prem \
				                FROM %s:ply_ins_type_bak \
				               WHERE ipolicy = '%s' \
				                 AND iendorse = '%s' \
				                 AND iins_type = '21' ",list[k].dbname,ipolicy,iendorse_tmp);
				printf("stmt[%s] \n",stmt);
				$PREPARE car9994_bak2 FROM $stmt;
				$EXECUTE car9994_bak2 INTO $drate_ym,$iproduct,$mdrunk_prem,$mdrunk_pure_prem;
			}
			else 
			{
				chk_iendorse = 0;
				sprintf_s(stmt,5120,"SELECT a.qpt,a.fpt,b.madjcom_prem,b.mbusiness,(b.maintain + b.mresearch),b.mlia_prem,b.dpolicy, \
				                     b.fcomp_class,to_char(a.dbirth,'%%Y%%m%%d'),a.fsex,a.fmarriage,a.fassured,b.ibroker,  \
				                     b.mcompensation,b.mstable,b.bzfrom,b.qdrunk_driving, \
				                     case WHEN b.dpolicy < '08/01/2016' THEN 'Y' else 'N' END,nvl(irelative_ply,'') \
				                FROM %s:policy a , %s:ply_relation b \
				               WHERE a.ipolicy = b.ipolicy \
				                 AND a.ipolicy = '%s' ",list[k].dbname,list[k].dbname,ipolicy);
				    
				$PREPARE car9994_ply1 FROM $stmt;
				$EXECUTE car9994_ply1 INTO $qpt ,$fpt ,$madjcom_prem ,$mbusiness, $maintain ,$mlia_prem ,$dpolicy_eng,
				                           $fcomp_class_ply, $ibirth_ply, $fsex_ply, $fmarriage_ply, $sFassured, $ibroker, 
				                           $mcompensation, $mstable, $bzfrom, $qdrunk_driving,
				                           $chk_dpolicy, $irelative_ply;
				                           
				/*�O�v�}�l�~��A���Ϥ��T�B����*/
				sprintf_s(stmt,5120,"SELECT drate_ym,nvl(iproduct,' '),mdrunk_prem,mdrunk_pure_prem \
                                FROM %s:ply_ins_type \
				               WHERE ipolicy = '%s' \
				                 AND iins_type = '21'",list[k].dbname,ipolicy);
				    
				$PREPARE car9994_ply2 FROM $stmt;
				$EXECUTE car9994_ply2 INTO $drate_ym,$iproduct,$mdrunk_prem,$mdrunk_pure_prem;
			}
	
			/*201502�s�W�C�Ө��إN���A���إN���^�k*/
			strcpy(icar_type,TRANS_CAR_TYPE(icar_type)); 
			
			rc = get_iproduct_car("21",icar_type,iproduct," ",drate_ym);
			if (rc != M_CM_OK) strcpy(iproduct,"xxxxxxxxxxxx");
		
			/* �ɰe�߮׹L��Τ@������ */
			/* ���L���B�]���ǰe-�q108/01/01�}�l-�έp�����L���߮׸ɶǨ�9992-��ӫO������A�w�s�bedr_ins_type */
			cnt_claim = 0;

			sprintf_s(stmt,5120,"SELECT iendorse \
			                FROM %s:edr_relation a \
			               WHERE a.ipolicy = '%s' \
		  	                 AND (SELECT COUNT(*) FROM %s:edr_ins_type WHERE iendorse = a.iendorse) = 0 \
			                 AND a.medrlia_prem = 0 \
			                 AND a.dendorse < '01/01/2019' \
			                 AND a.iendorse NOT IN (SELECT iendorse FROM ca_develop_claim_policy)",list[k].dbname,ipolicy,list[k].dbname);
			                 
			$PREPARE car9994_endorse_tmp FROM $stmt;
			$DECLARE car9994_endorse CURSOR FOR car9994_endorse_tmp;             
			$OPEN car9994_endorse;
			while (1)
			{
				$FETCH car9994_endorse INTO $claim_iendorse;
				if (SQLCODE == SQLNOTFOUND) break;
				$INSERT INTO ca_develop_claim_policy VALUES($iclaim,$ipolicy,$claim_iendorse,$dgroup_tmp);
			}
			$CLOSE car9994_endorse;
			$FREE car9994_endorse;
			
			$SELECT drate
			   INTO $drate
			   FROM ca_rate_date
			  WHERE icode = $drate_ym
			    AND itable = "compulsory_premium";
			if( SQLCODE == SQLNOTFOUND )
			{
				rstrdate("01/01/1998", &drate ); 
			}
			/* ���� */
			if (strcmp(icar_type,"01")==0 || 
			    strcmp(icar_type,"02")==0 ||
			    strcmp(icar_type,"32")==0)
			{
				printf("in icar_type 01 02 32\n");
				if (strcmp(trim(drate_ym),"5")==0 || strcmp(trim(drate_ym),"6")==0) 
				{
					rstrdate ("01/01/1999" , &drate);
					printf("drate[%d]\n",drate);
				}
			}
			
			company_flag=ipolicy[7];
			printf(" ipolicy[%s]",ipolicy);
			printf(" company_flag[%c]",company_flag);
			printf(" *** companyid[%s]\n",companyid);
			strcpy(COMPANY_P,companyid);
			strcpy(COMPANY_F,companyid);
			
			if(strcmp( companyid,"17")==0)
			{  
				if(company_flag > 65 )
				{  
					$select ipolicy_a
					   into $ipolicy
					   from conv_ipolicy
					  where ipolicy_n = $ipolicy;
					     
					strcpy(COMPANY_P,"16");
					printf(" ****************** CAR_COMPANY_E[%s]\n",COMPANY_P);                     
				}
				iclaim_flag=iclaim[6];
				printf(" iclaim[%s]\n",iclaim);
				printf(" iclaim_flag[%c]\n",iclaim_flag);
				if(iclaim_flag > 65 )
				{  
					$select distinct iclaim_a
				       into $iclaim_a
				       from conv_iclaim
				      where iclaim_n = $iclaim;
				    printf(" ****************** iclaim[%s]\n",iclaim_a);                 
				    strcpy(COMPANY_F,"16");
				}
				else
				{
					strcpy(iclaim_a, iclaim);
				}
			}
			else
			{
				strcpy(iclaim_a, iclaim); 
			}
			
			/* �����F�d�ʤ���*/
			sprintf_s(stmt,5120,"SELECT dentry, iclose_type, iself_duty, ioth_duty, ianoth_duty \
			                FROM %s:settlement  \
			               WHERE iclaim = '%s' \
			               ORDER BY 1 desc ,2 desc",list[k].dbname,iclaim);
			   
			$PREPARE curA_tmp FROM $stmt;
			$DECLARE curA CURSOR FOR curA_tmp;    
			$OPEN curA;
			$FETCH curA INTO $dentry, $iclose_type, $iself_duty, $ioth_duty, $ianoth_duty;
			if ( SQLCODE == SQLNOTFOUND ) 
			{
				iself_duty = 0;
				ioth_duty = 0;
				ianoth_duty = 0;
			}
			$CLOSE curA;
			$FREE curA;
	
			/************ ���B�z�򥻸����� ************/
			/* 1 ���M */
			strncpy(prtstr_1to25, "2",1);
			strcpy(t_fend_yn,"2");
			prtstr_1to25[1]='\0';
			
			/* 2 */
			strncat(prtstr_1to25, " ",1);
			strcpy(t_fstl," ");
			prtstr_1to25[2]='\0';
			
			/* 3 */
			strncat(prtstr_1to25, "0",1);
			strcpy(t_istl_recover," ");
			prtstr_1to25[3]='\0';
			
			/* 4 */
			strncat(prtstr_1to25, " ",1);
			strcpy(t_ihealth," ");
			prtstr_1to25[4]='\0';
	
			/* 5-12 �߮ר��z��� */
			strncpy(dclaim_yyyy,&dclaim[0],4); dclaim_yyyy[4] = '\0';
			strncpy(dclaim_mm,&dclaim[5],2); dclaim_mm[2] = '\0';
			strncpy(dclaim_dd,&dclaim[8],2); dclaim_dd[2] = '\0';
			strncat(prtstr_1to25, (dclaim_yyyy[0]=='\0') ? "0000" : dclaim_yyyy,4);
			strncat(prtstr_1to25, (dclaim_mm[0]=='\0') ? "00" : dclaim_mm,2);
			strncat(prtstr_1to25, (dclaim_dd[0]=='\0') ? "00" : dclaim_dd,2);
			strcpy(t_dclaim, (dclaim_yyyy[0]=='\0') ? "0000" : dclaim_yyyy);
			strcat(t_dclaim, (dclaim_mm[0]=='\0') ? "00" : dclaim_mm);
			strcat(t_dclaim, (dclaim_dd[0]=='\0') ? "00" : dclaim_dd);
			prtstr_1to25[12]='\0';
			
			/* 13-28 �߮׸��X */
			strcat(prtstr_1to25,COMPANY_F); prtstr_1to25[14]='\0';
			strcpy(t_iclm_company,COMPANY_F);
			strncat(prtstr_1to25, (iclaim_a[0]=='\0') ? "              " : iclaim_a,14);
			prtstr_1to25[28]='\0';
			strncpy(t_iclm_br, (iclaim_a[0]=='\0') ? "  " : iclaim_a,2); 
			t_iclaim[2] = '\0';
			strcpy(t_iclaim, (iclaim_a[0]=='\0') ? " " : iclaim_a); 
			
			/* 29-31 �ߥI���ơ��l�v�N�� */
			strncat(prtstr_1to25,"000",3);
			t_iclose_type = 0;
			strcpy(t_istl_flag,"0");
			prtstr_1to25[31]='\0';
			
			/* 32-39 ���פ�� */
			strncat(prtstr_1to25,"00000000",8);
			strcpy(t_dgroup,"00000000");
			prtstr_1to25[39]='\0';
			
			/* 40-58 �j���Ҹ� */
			strncat(prtstr_1to25,COMPANY_P, 2);
			strcpy(t_icard_company,COMPANY_P);
			strncpy(ipolicy_br,&ipolicy[0],2); ipolicy_br[2]='\0';
			if (ipolicy_br[0] == '\0') 
			{
				strcat(prtstr_1to25,"00");
				strcpy(t_icard_br,"00");
			}
			else 
			{
				strcat(prtstr_1to25,ipolicy_br);
				strcpy(t_icard_br,ipolicy_br);
			}
			strncat(prtstr_1to25, (icard[0]=='\0') ? "             " : icard,15);
			strcpy(t_icard, (icard[0]=='\0') ? "             " : icard); t_icard[15]='\0';
			prtstr_1to25[58]='\0';
			
			/* 59-66 �O�I�ͮĦ~�� */
			strcpy(dply_begin_c,cm_cdate_str_100(dply_begin));
			cm_split_ymd_100(dply_begin_c,dply_begin_yy,dply_begin_mm,dply_begin_dd);
			rfmtlong(atoi(dply_begin_yy)+1911,"&&&&",dply_begin_yy);
			strncat(prtstr_1to25,(dply_begin_yy[0]=='\0') ? "000" : dply_begin_yy,4);
			strncat(prtstr_1to25,(dply_begin_mm[0]=='\0') ? "00" : dply_begin_mm,2);
			strncat(prtstr_1to25,(dply_begin_dd[0]=='\0') ? "00" : dply_begin_dd,2);
			strcpy(t_dply_begin,(dply_begin_yy[0]=='\0') ? "000" : dply_begin_yy);
			strcat(t_dply_begin,(dply_begin_mm[0]=='\0') ? "00" : dply_begin_mm);
			strcat(t_dply_begin,(dply_begin_dd[0]=='\0') ? "00" : dply_begin_dd);
			prtstr_1to25[66]='\0';
	
			/* 67-74 �O�I�����*/
			strcpy(dply_end_c,cm_cdate_str_100(dply_end));
			cm_split_ymd_100(dply_end_c,dply_end_yy,dply_end_mm,dply_end_dd);
			rfmtlong(atoi(dply_end_yy)+1911,"&&&&",dply_end_yy);
			strncat(prtstr_1to25,(dply_end_yy[0]=='\0') ? "000" : dply_end_yy,4);
			strncat(prtstr_1to25,(dply_end_mm[0]=='\0') ? "00" : dply_end_mm,2);
			strncat(prtstr_1to25,(dply_end_dd[0]=='\0') ? "00" : dply_end_dd,2);
			strcpy(t_dply_end,(dply_end_yy[0]=='\0') ? "000" : dply_end_yy);
			strcat(t_dply_end,(dply_end_mm[0]=='\0') ? "00" : dply_end_mm);
			strcat(t_dply_end,(dply_end_dd[0]=='\0') ? "00" : dply_end_dd);
			 /* car950512 */
	
			/* 75-76 �ӫO�a�ϥN�� */
			strncat(prtstr_1to25, (iply_area[0]=='\0') ? "00" : iply_area,2);
			strcpy(t_iarea, (iply_area[0]=='\0') ? "00" : iply_area);
			prtstr_1to25[76]='\0';
			
			/* 77-80 �O�I�Ъ��� */
			if(strlen(trim_tail_white(ipolicy))>CAR_POLICY_LEN)
			{
				strncpy(imark,&ipolicy[CAR_POLICY_LEN],4);
				if(imark[0]=='\0')
				{
					strncat(prtstr_1to25,"0001",4);
					strcpy(t_iobjno,"0001");
				}
				else
				{
				    strncat(prtstr_1to25,imark,4);
				    strcpy(t_iobjno,imark);
				}
			}
			else
			{
				strncat(prtstr_1to25,"0001",4);
				strcpy(t_iobjno,"0001");
			}
			prtstr_1to25[80]='\0';
			
			/* 81-84 ��l�o�Ӧ~ */
			if (iissue_yy[0]=='\0') 
			{
				strcat(prtstr_1to25,"0000");
				strcpy(t_iissue_year,"0000");
			}
			else
			{
				rfmtlong(atoi(iissue_yy),"&&&&",iissue_yy);
				strcat(prtstr_1to25, iissue_yy);
				strcpy(t_iissue_year,iissue_yy);
			}
			prtstr_1to25[84]='\0';
			
			/* 85-88 �s�y�~�� */
			strncat(prtstr_1to25,(ipro_year[0]=='\0') ? "0000" : ipro_year,4);
			strcpy(t_ipro_year,(ipro_year[0]=='\0') ? "0000" : ipro_year);
			prtstr_1to25[88]='\0';
	
			/* 89-96 �t�P�����N�� */
			/* 1000530002�t�P�����N���H�ഫ�t�P�����N�����e */
			ibrand_new[0]='\0';
			$OPEN cur_ibrand USING $ibrand;
			$FETCH cur_ibrand INTO $ibrand_new;
			if (ibrand_new[0]!='\0') strcpy(ibrand, ibrand_new);
			$CLOSE cur_ibrand;
			printf("ibrand[%s]ibrand_new[%s]\n", ibrand, ibrand_new);
	
	        if(strncmp(ibrand,"MF0002",6)==0) 
	           strcpy(ibrand, "ME000200");
	           
	        if( (strncmp(ibrand,"MR0001",6)==0) || (strncmp(ibrand,"MT0001",6)==0) )
	           strcpy(ibrand, "MM000100");
	
	        if(strncmp(ibrand,"EA0001",6)==0)  /* �T���¨��� */
	           strcpy(ibrand, "MC000000");
	
	        /* �O�o�������t�P�����e6�X */
			strncpy(ibrand6, ibrand, 6);
	        ibrand6[6]='\0';
	        $SELECT COUNT(*)
	           INTO $cnt
	           FROM cu_code_data
	          WHERE itype='B9'
	            AND icode=$ibrand6;
			if (cnt>0)
			{
				/* 2010�X�� */
				sprintf_s(stmt,5120,"SELECT COUNT(*) FROM %s:ori_ply_relation \
				          WHERE ipolicy = '%s' AND dpolicy >= '01/01/2010'",list[k].dbname,ipolicy);
				$PREPARE ori_1090101 FROM $stmt;
				$EXECUTE ori_1090101 INTO $cnt;
				if (cnt>0) ibrand[4]=ibrand[5]='0';
			}
	           
			if (ibrand[0] == '\0')
			{
				strcat(prtstr_1to25,"00000000");
				strcpy(t_ibrand,"00000000");
			}
	 		else
			{     
				strncat(prtstr_1to25,ibrand,8);
				strcpy(t_ibrand,ibrand);
			}
			prtstr_1to25[96]='\0';
	
			/* 97-98 ���إN�� */
			if (strcmp(trim(icar_type),"51") == 0) 
			{
				strcat(prtstr_1to25,"34");
				strcpy(t_icar_type,"34");
			}
			else 
			{
				strncat(prtstr_1to25,(icar_type[0]=='\0') ? "00" : icar_type,2);
				strcpy(t_icar_type,(icar_type[0]=='\0') ? "00" : icar_type);
			}
			prtstr_1to25[98]='\0';
	
			/* 99-100 ���������N�����O */
			if (f_bgn_10811 > 0)
			{
				if((strcmp(icar_type,"01") == 0) || (strcmp(icar_type,"02") == 0) || (strcmp(icar_type,"32") == 0) || (strcmp(icar_type,"34") == 0))
				{
					strcpy(irelative_ply,trim(irelative_ply));
		        	if (strcmp(irelative_ply,"") != 0)
		        	{
			        	strcpy(PLY_DB,get_car_full_db(irelative_ply));
			        	sprintf_s(stmtt,2048,"SELECT count(*) FROM %s:ply_ins_type WHERE ipolicy = '%s' AND (provision = 'L' OR provision matches '*;L*' OR provision matches '*L;*') ",PLY_DB,irelative_ply);
			        	printf("stmtt[%s]\n",stmtt);
			        	$PREPARE ply_L FROM $stmtt;
				        $EXECUTE ply_L INTO $cnt_L;
			    	}
			    	else 
			    		cnt_L = 0;
			        if (cnt_L > 0) 
			        {
			        	strcat(prtstr_1to25,"02");
			        	strcpy(t_icar_type_no,"02");
			        }
		        	else 
		        	{
		        		strcat(prtstr_1to25,"01");
		        		strcpy(t_icar_type_no,"01");
		        	}
				}
				else if ((strcmp(icar_type,"07") == 0) || (strcmp(icar_type,"15") == 0))
				{
					$SELECT FIRST 1 nvl(fkind,'')
		        	   INTO $fcar_kind
		        	   FROM ca_taxi_type
		        	  WHERE icard = $icard
		        	  ORDER BY dupdate DESC;
		        	if (SQLCODE == SQLNOTFOUND) strcpy(fcar_kind,"N");
		        	
					if(strcmp(fcar_kind,"Y") == 0) 
					{
						strcat(prtstr_1to25,"04");
						strcpy(t_icar_type_no,"04");
					}
		        	else
		        	{
		        		strcat(prtstr_1to25,"03");
		        		strcpy(t_icar_type_no,"03");
		        	}
				}
				else 
				{
					strcat(prtstr_1to25,"00");
					strcpy(t_icar_type_no,"00");
				}
			}
			else		
			{
				strcat(prtstr_1to25,"00");
				strcpy(t_icar_type_no,"00");
			}
			prtstr_1to25[100]='\0';
	
			/* 101-105 �Ʈ�q*/
			t_qcylinder = qcylinder;
			rfmtlong(qcylinder,"&&&&&",qcylinder_c);
			strncat(prtstr_1to25,(qcylinder_c[0]=='\0') ? "00000" : qcylinder_c,5);
			prtstr_1to25[105]='\0';
	
			/* 106-130 �����B�������X */
			if(iengine[0]=='\0')
			{
				strncat(prtstr_1to25,(body[0]=='\0') ? "                         " : body,25);
				strcpy(t_iengine,(body[0]=='\0') ? "                         " : body,25);
			}
			else
			{
				strncat(prtstr_1to25,(iengine[0]=='\0') ? "                         " : iengine,25);
				strcpy(t_iengine,(iengine[0]=='\0') ? "                         " : iengine,25);
			}
			prtstr_1to25[130]='\0';
	
			/* 131-142 �P�Ӹ��X */
			if(strcmp(icar_type,"27") == 0 && strcmp(chk_dpolicy,"Y") == 0)
			{
				strcat(prtstr_1to25,"            ");
				strcpy(t_itag," ");
			}
			else
			{
				strncat(prtstr_1to25,(itag[0]=='\0') ? "            " : itag,12);
				strcpy(t_itag,(itag[0]=='\0') ? "            " : itag);
			}
			prtstr_1to25[142]='\0';
	
			/* 143-146 �Ӹ����� */
			buf1[0]='\0';
			rfmtdouble( (qpt*10),"&&&&", buf1);
			strncat(prtstr_1to25,(buf1[0]=='\0') ? "0050" : buf1,4);
			if(buf1[0]=='\0')
			{
				t_qpt = 50;	
			}
			else
			{
				t_qpt = qpt;
			}
			prtstr_1to25[146]='\0';
	
			/* 147 �Ӹ�����Ӹ����  */
			if ( fpt[0] == '\0' )
			{
				strcat(prtstr_1to25," ");
				strcpy(t_fpt," ");
			}
			else if(strcmp(fpt," ")==0 )
			{
				strcat(prtstr_1to25," ");
				strcpy(t_fpt," ");
			}
			else
			{
				strncat(prtstr_1to25,fpt,1);
				strcpy(t_fpt,fpt);
			}
			/* strncat(prtstr_1to25,(strlen(rtrim(fpt)) == 0 ) ? "P" : fpt,1); */
			prtstr_1to25[147]='\0';
	
			/*** 14 ��訮���  ***/
			ioth_fassured[0]=ioth_cartype[0]=ioth_qpt=ioth_fpt[0]=ioth_tag[0]=ioth_card_company[0]=ioth_icard[0]=0; 
			$DECLARE cur_stl_oth CURSOR FOR 
			  SELECT a.fvictim_nation,b.icar_type,b.qpt,
			         b.fpt,b.itag,b.ioth_card_company,b.ioth_icard
			    INTO $ioth_fassured, $ioth_cartype, $ioth_qpt,
			         $ioth_fpt, $ioth_tag, $ioth_card_company, $ioth_icard
			    FROM ca_clm_victim_data a,ca_property b
			   WHERE a.iclaim = b.iverify
			     AND a.ivictim = b.ivictim
			     AND a.fvictim_car IN ('D','E','H')
			     AND a.fdrive = '1'
			     AND a.iclaim = (SELECT iverify 
			                       FROM ca_ver_relation 
			                      WHERE iclaim = $iclaim);
			$OPEN cur_stl_oth;
			$FETCH cur_stl_oth;
			if (SQLCODE==SQLNOTFOUND)
			{
				sprintf_s(stmt,5120,"SELECT first 1  \
				                     iclose_type, ioth_fassured, ioth_cartype, ioth_qpt, \
				                     ioth_fpt, ioth_tag, NVL(ioth_card_company,''), NVL(ioth_icard,'') \
				                FROM %s:stl_oth_dtl \
				               WHERE iclaim = '%s' \
				                 AND fstl = '1' \
				               ORDER BY iclose_type DESC ",list[k].dbname,iclaim);
				$PREPARE cur_stl_oth1 FROM $stmt;
				$EXECUTE cur_stl_oth1 INTO $iclose_type, $ioth_fassured, $ioth_cartype, $ioth_qpt,
				                           $ioth_fpt, $ioth_tag, $ioth_card_company, $ioth_icard;

				strcpy(ioth_card_company,trim(ioth_card_company));
				if (SQLCODE==SQLNOTFOUND)
				{
					/* 148-155 �Q�O�I�H�N���B���ءB�������� */
					strcat(prtstr_1to25,"0000000P");
					prtstr_1to25[155]='\0';
					/* 156-167  �P�Ӹ��X ***/
					strcat(prtstr_1to25,"            ");
					prtstr_1to25[167]='\0';
					/* 168 �O�_���O�j���I 1 �O 2 �_ */
					strcat(prtstr_1to25,"2");
					prtstr_1to25[168]='\0';
					/* 169-185 ���q�N�� & �j��O�I�ҽs�� */
					strcat(prtstr_1to25,"                 ");
					prtstr_1to25[185]='\0';
					
					strcpy(t_ioth_fassured,"0");
					strcpy(t_ioth_cartype,"00");
					t_ioth_qpt = 0;
					strcpy(t_ioth_fpt,"P");
					strcpy(t_ioth_tag," ");
					strcpy(t_ioth_comp_yn,"2");
					strcpy(t_ioth_card_company," ");
					strcpy(t_ioth_card," ");
				}
				else 
				{
					/* 148-148 �Q�O�I�H�N�� */
					strncpy(daccident_yyyy,&daccident[0],4); daccident_yyyy[4]='\0';
					printf("ioth_card_company==>[%s]\n",ioth_card_company);
					if (ioth_card_company[0]=='\0' || ioth_card_company[0] == ' ' || atoi(daccident_yyyy) < 2008 ||
					    strncmp(ioth_card_company,"XX",2)==0 || strcmp(ioth_card_company,"0") == 0)
					{
						strncat(prtstr_1to25, "0" ,1);
						strcpy(t_ioth_fassured,"0");
					}
					else
					{
						if (ioth_fassured[0] == '1')
						{
							strncat(prtstr_1to25, "3", 1);
							strcpy(t_ioth_fassured,"3");
						}
						else if (ioth_fassured[0] == '2')
						{
							strncat(prtstr_1to25, "1", 1);
							strcpy(t_ioth_fassured,"1");
						}
						else
						{
							strncat(prtstr_1to25, "0", 1);
							strcpy(t_ioth_fassured,"0");
						}
					}
					prtstr_1to25[148]='\0';
					
					/* 149-150 ���������N�� */
					strcpy(ioth_cartype,TRANS_CAR_TYPE(ioth_cartype));
					if( strcmp(ioth_cartype,"98")==0 || strcmp(ioth_cartype,"99")==0 || ioth_cartype[0]=='\0' || ioth_cartype[0]==' ')
					{
						ioth_qpt = 0;
						strcpy(ioth_fpt," ");
					}
					if(strcmp(ioth_cartype,"51")==0) 
					{
						strcat(prtstr_1to25,"34");
						strcpy(t_ioth_cartype,"34");
					}
					else 
					{
						strncat(prtstr_1to25,(ioth_cartype[0]=='\0' || ioth_cartype[0]==' ') ? "98": ioth_cartype,2);
						strcpy(t_ioth_cartype,(ioth_cartype[0]=='\0' || ioth_cartype[0]==' ') ? "98": ioth_cartype);
					}
					prtstr_1to25[150]='\0';
					
					strcpy(ioth_cartype, trim(ioth_cartype));
					if((strcmp(ioth_cartype,"01")==0) || (strcmp(ioth_cartype,"02")==0))
					{
						ioth_qpt = 2.0;
						strcpy( ioth_fpt , "P");
					}
					
					
					strcpy(t_ioth_fpt,"P");
					/* 151-155 �����ƶq ���*/
					buf1[0]='\0';
					t_ioth_qpt = ioth_qpt;
					rfmtdouble((ioth_qpt*10),"&&&&",buf1);
					strncat(prtstr_1to25,(buf1[0]=='\0') ? "0000" : buf1,4);
					prtstr_1to25[154]='\0';

					if( strcmp(ioth_cartype,"98")==0 || strcmp(ioth_cartype,"99")==0 || ioth_cartype[0]=='\0' || ioth_cartype[0]==' ')
					{
						strncat(prtstr_1to25," ",1);
						strcpy(t_ioth_fpt , "0");
					}
					else 
					{
						strncat(prtstr_1to25,(ioth_fpt[0]=='\0' || ioth_fpt[0]==' ') ? "P" : ioth_fpt,1);
						strcpy(t_ioth_fpt,(ioth_fpt[0]=='\0' || ioth_fpt[0]==' ') ? "P" : ioth_fpt);
					}
					prtstr_1to25[155]='\0';
					
					if (ioth_card_company[0]=='\0' || ioth_card_company[0]==' ' || atoi(daccident_yyyy) < 2008 ||
					    strncmp(ioth_card_company,"XX",2)==0)
					{
						if( strcmp(ioth_cartype,"98")==0 || strcmp(ioth_cartype,"99")==0 || ioth_cartype[0]=='\0' || ioth_cartype[0]==' ')
						{
							/* 156-167 �P�Ӹ��X*/
							strcat(prtstr_1to25,"            ");
							strcpy(t_ioth_tag," ");
							prtstr_1to25[167] = '\0';
							/* 168-168 �O�_���O�j���I 1 �O 2 �_*/
							strcat(prtstr_1to25, "0");
							strcpy(t_ioth_comp_yn," ");
						}
						else
						{
							/* 156-167 �P�Ӹ��X*/
							if(strcmp(ioth_cartype,"27") == 0 && strcmp(chk_dpolicy,"Y") == 0)
							{
								strcat(prtstr_1to25,"            ");
								strcpy(t_ioth_tag," ");
							}
							else
							{
								strncat(prtstr_1to25,(ioth_tag[0]=='\0') ? "            " : ioth_tag,12);
								strcpy(t_ioth_tag,(ioth_tag[0]=='\0') ? "            " : ioth_tag);
							}
							prtstr_1to25[167] = '\0';
							/* 168 �O�_���O�j���I 1 �O 2 �_*/
							strcat(prtstr_1to25, "2");
							strcpy(t_ioth_comp_yn,"2");
						}
						prtstr_1to25[168] = '\0';
						/* 169-185 �j��O�I�ҽs��*/
						strcat(prtstr_1to25, "                 ");
						strcpy(t_ioth_card_company," ");
						strcpy(t_ioth_card," ");
						prtstr_1to25[185] = '\0';
					}
					else
					{
						if( strcmp(ioth_cartype,"98")==0 || strcmp(ioth_cartype,"99")==0 || ioth_cartype[0]=='\0' || ioth_cartype[0]==' ')
						{
							/* 156-167 �P�Ӹ��X*/
							strcat(prtstr_1to25,"            ");
							strcpy(t_ioth_tag," ");
							prtstr_1to25[167] = '\0';
							/* 168 �O�_���O�j���I 1 �O 2 �_*/
							strcat(prtstr_1to25, "0");
							strcpy(t_ioth_comp_yn, "0");
						}
						else
						{
							/* 156-167 �P�Ӹ��X*/
							if(strcmp(ioth_cartype,"27") == 0 && strcmp(chk_dpolicy,"Y") == 0)
							{
								strcat(prtstr_1to25,"            ");
								strcpy(t_ioth_tag," ");
							}
							else    
							{	 			 
								strncat(prtstr_1to25,(ioth_tag[0]=='\0') ? "            " : ioth_tag,12);
								strcpy(t_ioth_tag,(ioth_tag[0]=='\0') ? "            " : ioth_tag);
							}
							prtstr_1to25[167] = '\0';
							/* 168 �O�_���O�j���I 1 �O 2 �_*/
							if(ioth_card_company[0] == '\0' || strcmp(ioth_card_company,"0") == 0)
							{
								strcat(prtstr_1to25,"2");
								strcpy(t_ioth_comp_yn, "2");
							}
							else
							{
								strcat(prtstr_1to25,"1");
								strcpy(t_ioth_comp_yn, "1");
							}
						}
						prtstr_1to25[168] = '\0';
						/* 169-185 �j��O�I�ҽs��*/
						strncat(prtstr_1to25,(strlen(trim(ioth_icard))==0) ? "                 " : ioth_icard,17);
						strncpy(t_ioth_card_company,(strlen(trim(ioth_icard))==0) ? "  " : ioth_icard,2);
						strncpy(t_ioth_card,(strlen(trim(ioth_icard))==0) ? "                 " : ioth_icard,17);t_ioth_card[17] = '\0';
						prtstr_1to25[185] = '\0';
					}
				}
			}
			else
			{
				/* 148 �Q�O�I�H�N�� */
				strcpy(ioth_card_company,trim(ioth_card_company));
				strncpy(daccident_yyyy,&daccident[0],4); daccident_yyyy[4]='\0';
				printf("ioth_card_company==>[%s]\n",ioth_card_company);
				if (ioth_card_company[0]=='\0' || ioth_card_company[0] == ' ' || atoi(daccident_yyyy) < 2008 ||
				    strncmp(ioth_card_company,"XX",2)==0 || strcmp(ioth_card_company,"0") == 0)
				{
					strncat(prtstr_1to25, "0" ,1);
					strcpy(t_ioth_fassured,"0");
				}
				else
				{
					strncat(prtstr_1to25, ioth_fassured, 1);
					strcpy(t_ioth_fassured,ioth_fassured);
				}
				prtstr_1to25[148]='\0';
			
				/* 149-150 ���������N�� */
				strcpy(ioth_cartype,TRANS_CAR_TYPE(ioth_cartype));
				strcpy(ioth_cartype, trim(ioth_cartype));
				if( strcmp(ioth_cartype,"98")==0 || strcmp(ioth_cartype,"99")==0 || ioth_cartype[0]=='\0' || ioth_cartype[0]==' ')
				{
					ioth_qpt = 0;
					strcpy( ioth_fpt , " ");
				}
				if(strcmp(ioth_cartype,"51")==0) 
				{
					strcat(prtstr_1to25,"34");
					strcpy(t_ioth_cartype,"34");
				}
				else 
				{
					strncat(prtstr_1to25,(ioth_cartype[0]=='\0' || ioth_cartype[0]==' ') ? "98": ioth_cartype,2);
					strcpy(t_ioth_cartype,(ioth_cartype[0]=='\0' || ioth_cartype[0]==' ') ? "98": ioth_cartype);
				}
				prtstr_1to25[150]='\0';
	
				if((strcmp(ioth_cartype,"01")==0) || (strcmp(ioth_cartype,"02")==0))
				{
					ioth_qpt = 2.0;
					strcpy( ioth_fpt , "P");
				}
			
				/* 151-155 �����ƶq ���*/
				buf1[0]='\0';
				t_ioth_qpt = ioth_qpt;
				rfmtdouble((ioth_qpt*10),"&&&&",buf1);
				strncat(prtstr_1to25,(buf1[0]=='\0') ? "0000" : buf1,4);
				prtstr_1to25[154]='\0';
				
				if( strcmp(ioth_cartype,"98")==0 || strcmp(ioth_cartype,"99")==0 || ioth_cartype[0]=='\0' || ioth_cartype[0]==' ')
				{
					strncat(prtstr_1to25," ",1);
					strcpy(t_ioth_fpt," ");
					
				}
				else 
				{
					strncat(prtstr_1to25,(ioth_fpt[0]=='\0' || ioth_fpt[0]==' ') ? "P" : ioth_fpt,1);
					strcpy(t_ioth_fpt,(ioth_fpt[0]=='\0' || ioth_fpt[0]==' ') ? "P" : ioth_fpt);
				}
				prtstr_1to25[155]='\0';
			
				if (ioth_card_company[0]=='\0' || ioth_card_company[0]==' ' || atoi(daccident_yyyy) < 2008 ||
				strncmp(ioth_card_company,"XX",2)==0)
				{
					if( strcmp(ioth_cartype,"98")==0 || strcmp(ioth_cartype,"99")==0 || ioth_cartype[0]=='\0' || ioth_cartype[0]==' ')
					{
						/* 156-167 �P�Ӹ��X*/
						strcat(prtstr_1to25,"            ");
						strcpy(t_ioth_tag," ");
						prtstr_1to25[167] = '\0';
						/* 168-168 �O�_���O�j���I 1 �O 2 �_*/
						strcat(prtstr_1to25, "0");
						strcpy(t_ioth_comp_yn,"0");
					}
					else
					{
						/* 156-167 �P�Ӹ��X*/
						if(strcmp(ioth_cartype,"27") == 0 && strcmp(chk_dpolicy,"Y") == 0)
						{
							strcat(prtstr_1to25,"            ");
							strcpy(t_ioth_tag," ");
						}
						else
						{
							strncat(prtstr_1to25,(ioth_tag[0]=='\0') ? "            " : ioth_tag,12);
							strcpy(t_ioth_tag,(ioth_tag[0]=='\0') ? "            " : ioth_tag);
						}
						prtstr_1to25[167] = '\0';
						/* 168 �O�_���O�j���I 1 �O 2 �_*/
						strcat(prtstr_1to25, "2");
						strcpy(t_ioth_comp_yn,"2");
					}
					prtstr_1to25[168] = '\0';
					/* 169-185 �j��O�I�ҽs��*/
					strcat(prtstr_1to25, "                 ");
					strcpy(t_ioth_card_company," ");
					strcpy(t_ioth_card," ");
					prtstr_1to25[185] = '\0';
				}
				else
				{
					if( strcmp(ioth_cartype,"98")==0 || strcmp(ioth_cartype,"99")==0 || ioth_cartype[0]=='\0' || ioth_cartype[0]==' ')
					{
						/* 156-167 �P�Ӹ��X*/
						strcat(prtstr_1to25,"            ");
						strcpy(t_ioth_tag," ");
						prtstr_1to25[167] = '\0';
						/* 168-168 �O�_���O�j���I 1 �O 2 �_*/
						strcat(prtstr_1to25, "0");
						strcpy(t_ioth_comp_yn,"0");
					}
					else
					{
						/* 156-167 �P�Ӹ��X*/
						if(strcmp(ioth_cartype,"27") == 0 && strcmp(chk_dpolicy,"Y") == 0)
						{
							strcat(prtstr_1to25,"            ");
							strcpy(t_ioth_tag," ");
						}
						else    	 			 
						{
							strncat(prtstr_1to25,(ioth_tag[0]=='\0') ? "            " : ioth_tag,12);
							strcpy(t_ioth_tag,(ioth_tag[0]=='\0') ? "            " : ioth_tag);
						}
						prtstr_1to25[167] = '\0';
						/* 168-168 �O�_���O�j���I 1 �O 2 �_*/
						strcpy(ioth_card_company,trim(ioth_card_company));
						strcpy(t_ioth_card_company,ioth_card_company);
						if(ioth_card_company[0] == '\0' || strcmp(ioth_card_company,"0") == 0)
						{
							strcat(prtstr_1to25,"2");
							strcpy(t_ioth_comp_yn,"2");
						}
						else
						{
							strcat(prtstr_1to25,"1");
							strcpy(t_ioth_comp_yn,"1");
						}
					}
					prtstr_1to25[168] = '\0';
					/* 169-185 �j��O�I�ҽs��*/
					strncat(prtstr_1to25,(strlen(trim(ioth_icard))==0) ? "                 " : ioth_icard,17);
					strcpy(t_ioth_card,(strlen(trim(ioth_icard))==0) ? "                 " : ioth_icard,17);t_ioth_card[17] = '\0';
					prtstr_1to25[185] = '\0';
				}
			}
			$CLOSE cur_stl_oth;
			$FREE cur_stl_oth;
	
			/* 186-187 �����H�W�F�Ʋz�ߵ���*/
			strcpy( fcomp_class, trim(fcomp_class));
			if( (fcomp_class[0] == '\0') || (fcomp_class[0] == '0'))
			{
				strcpy( fcomp_class, fcomp_class_ply );
			}
			if( (fcomp_class[0] == '\0') || (fcomp_class[0] == '0'))
			{
				strcpy( fcomp_class, "04");
			}
			
			rfmtlong(atoi(fcomp_class),"&&",fcomp_class);
			strncat(prtstr_1to25,(fcomp_class[0]=='\0') ? "04" : fcomp_class,2);
			strcpy(t_fcomp_class,(fcomp_class[0]=='\0') ? "04" : fcomp_class);
			prtstr_1to25[187]='\0';
	
			/* 188-189 �����s�r�H�W����*/
			t_qdrunk_driving = qdrunk_driving;
			rfmtlong(qdrunk_driving,"&&",buf1);      
			strcat(prtstr_1to25,buf1);
			prtstr_1to25[189]='\0';
	
			/* 190-199 �`�O�I�O */
			t_mins_premium = mlia_prem;
			strcat(prtstr_1to25,(mlia_prem<0) ? "-" : "+");
			buf1[0]='\0';
			rfmtlong(mlia_prem,"&&&&&&&&&",buf1);
			strncat(prtstr_1to25,(buf1[0]=='\0') ? "000000000" : buf1,9);
			prtstr_1to25[199]='\0';
			
			/* 200-213 �վ��«O�O */
			t_madjcom_prem = madjcom_prem;
			strcat(prtstr_1to25,(madjcom_prem<0) ? "-" : "+");
			madjcom_prem_t = madjcom_prem * 10000;
			buf1[0]='\0';
			rfmtlong(madjcom_prem_t,"&&&&&&&&&&&&&",buf1);
			strncat(prtstr_1to25,(buf1[0]=='\0') ? "0000000000000" : buf1,13);
			prtstr_1to25[213]='\0';
	
			/* car950512 */
			strcpy(dpolicy_str,dpolicy_eng+6);
			strcat(dpolicy_str,substring(dpolicy_eng,1,2));
			strcat(dpolicy_str,substring(dpolicy_eng,4,2));
			printf("dpolicy_eng[%s]\n",dpolicy_eng);
			printf("dpolicy_str[%s]\n",dpolicy_str);
	
			if (strcmp(dpolicy_str,"20060301") < 0)
			{
				mbusiness += maintain;
				maintain = 0;
			}
			/* 214-223 �~�ȶO�� */
			t_mbusiness = mbusiness;
			strcat(prtstr_1to25,(mbusiness<0) ? "-" : "+");
			buf1[0]='\0';
			rfmtlong(mbusiness,"&&&&&&&&&",buf1);
			strncat(prtstr_1to25,(buf1[0]=='\0') ? "000000000" : buf1,9);
			prtstr_1to25[223]='\0';
	
			/* 224-233 �������O�I�O��*/
			t_maintain = maintain;
			strcat(prtstr_1to25,(maintain<0) ? "-" : "+");
			buf1[0] = '\0';
			rfmtlong(maintain, "&&&&&&&&&", buf1);
			strcat(prtstr_1to25,(buf1[0]=='\0') ? "000000000" : buf1);
			prtstr_1to25[233]='\0';
			/* car950512 */
			
			/* 234-243 �S�ɤ����B*/
			t_mcompensation = mcompensation;
			mcompensation *= 10000;
			strcat(prtstr_1to25,(mcompensation<0) ? "-" : "+");
			rfmtdouble(mcompensation, "&&&&&&&&&", buf1);
			strcat(prtstr_1to25, buf1);
			prtstr_1to25[243]='\0';
			
			/* 244-253 �w�w���*/
			t_mstable = mstable;
			mstable *= 10000;
			strcat(prtstr_1to25,(mstable<0) ? "-" : "+");
			rfmtdouble(mstable, "&&&&&&&&&", buf1);
			strcat(prtstr_1to25, buf1);
			prtstr_1to25[253]='\0';
			
			/* 254-260 �s��r���[�O*/
			t_mdrunk_prem = mdrunk_prem;
			strcat(prtstr_1to25,(mdrunk_prem<0) ? "-" : "+");
			rfmtdouble(mdrunk_prem, "&&&&&&", buf1);
			strcat(prtstr_1to25, buf1);
			prtstr_1to25[260]='\0';
			
			/* 261-271 �s��r���«O�O*/
			t_mdrunk_pure_prem = mdrunk_pure_prem;
			strcat(prtstr_1to25,(mdrunk_pure_prem<0) ? "-" : "+");
			mdrunk_pure_prem_l=dtol(mdrunk_pure_prem*10000);
			rfmtdouble(mdrunk_pure_prem_l, "&&&&&&&&&&", buf1);
			strcat(prtstr_1to25, buf1);
			prtstr_1to25[271]='\0';
	
			/* 272 �O�v��I�~�� */
			sprintf_s(stmt,5120, "SELECT to_char(drate, '%%Y%%m') FROM ca_rate_date \
			WHERE itable = 'compulsory_premium' AND icode = ? ");
			$PREPARE get_drate FROM $stmt;
			$EXECUTE get_drate INTO $drate_yyyymm USING $drate_ym;
			if (SQLCODE == SQLNOTFOUND) 
			{
				strcpy(drate_yyyymm, "000000");
			}
			strcat(prtstr_1to25,drate_yyyymm);
			strcpy(t_drate_ym,drate_yyyymm);
			prtstr_1to25[277]='\0';
	
			/* 278/279-288 �Q�O�I�H�����Ҹ��X */
			rtn = check_id(iassured,chk_fassured,chk_fsex);
			strcat(prtstr_1to25,chk_fassured);
			strcpy(t_fassured,chk_fassured);
			prtstr_1to25[278] = '\0';
			strcat(prtstr_1to25, trim(iassured));
			strcpy(t_iassured,iassured);
			for(idx=0 ; idx < (10-strlen(rtrim(iassured))); idx++)
			  strcat(prtstr_1to25, " ");
			prtstr_1to25[288]='\0';
			printf("prtstr_1to25=[%s]\n", prtstr_1to25 );
			
			printf("iassured[%s],chk_fassured[%s],chk_fsex[%s] \n",iassured,chk_fassured,chk_fsex);
			printf("ibirth_ply[%s],fsex_ply[%s],fmarriage_ply[%s] \n",ibirth_ply,fsex_ply,fmarriage_ply);
			printf("1ibirth[%s],fsex[%s],fmarriage[%s]\n",ibirth,fsex,fmarriage);
			/* 289-296 �Q�O�I�H�X�ͤ�� */
			if (strncmp(chk_fassured,"3",1)==0 || strncmp(chk_fassured,"9",1)==0)
			{
				printf("�k�H\n");
				/* �k�H����ͤ�,�ʧO,�B�� */
				strcat(prtstr_1to25, "00000000");
				strcpy(fsex,"0");
				strcpy(fmarriage, "0");
				
				strcpy(t_dbirth,"00000000");
			}
			else
			{
				printf("NO�k�H\n");
				if (strlen(rtrim(ibirth)) == 0)
				{
					strcpy( ibirth, ibirth_ply);
					strcpy( fsex,   fsex_ply);
					strcpy( fmarriage, fmarriage_ply );
				}              
				
				if (strlen(rtrim(ibirth)) == 0) 
				{
					strcat(prtstr_1to25,"00000000");
					strcpy( t_dbirth, "00000000");
				}
				else
				{
					strcat(prtstr_1to25,rtrim(ibirth));
					strcpy( t_dbirth, ibirth);
					for(idx=0 ; idx < (8-strlen(rtrim(ibirth))); idx++) strcat(prtstr_1to25, " ");
				}	
			}
			prtstr_1to25[296]='\0';
			printf("2ibirth[%s],fsex[%s],fmarriage[%s]\n",ibirth,fsex,fmarriage);
			
			/* 297 �Q�O�I�H�ʧO */
			if (chk_fsex[0]!='0') strcpy(fsex,chk_fsex);
			strncat(prtstr_1to25,((fsex[0]=='\0') || (fsex[0]==' ') || (fsex[0]=='0'))? "0" : fsex,1);
			strcpy(t_fsex,((fsex[0]=='\0') || (fsex[0]==' ') || (fsex[0]=='0'))? "0" : fsex);
			prtstr_1to25[297]='\0';
			
			/* 298 �Q�O�I�H�B�çO */
			strncat(prtstr_1to25,((fmarriage[0]=='\0') || (fmarriage[0]==' ') || (fmarriage[0]=='0'))? "0" : fmarriage,1);
			strcpy(t_fmarriage,((fmarriage[0]=='\0') || (fmarriage[0]==' ') || (fmarriage[0]=='0'))? "0" : fmarriage);
			prtstr_1to25[298]='\0';
			printf("prtstr_1to25=[%s]\n", prtstr_1to25 );
	
			/* 299 �r�p�H���� */
			/* �r�p�H�@�w���۵M�H */
			strcat(prtstr_1to25,facc_nation);
			strcpy(t_facc_nation,facc_nation);
			prtstr_1to25[299] = '\0';
			
			/* 300-309 �F�ƾr�p�H�r�Ӹ��X */
			strcat(prtstr_1to25,trim(iacc_license));
			strcpy(t_iacc_license,iacc_license);
			for(idx=0 ; idx < (10-strlen(rtrim(iacc_license))); idx++)
				strcat(prtstr_1to25, " ");
			prtstr_1to25[309]='\0';
			
			/* 310-317 �F�ƾr�p�H�X�ͦ~�� */
			if (iacc_birth[0]=='\0') 
			{
				strcat(prtstr_1to25,"00000000");
				strcpy(t_iacc_birth,"00000000");
			}
			else
			{
				rfmtlong(atoi(iacc_birth),"&&&&&&&&",iacc_birth_c);
				strcat(prtstr_1to25,iacc_birth_c);
				strcpy(t_iacc_birth,iacc_birth_c);
			}
			prtstr_1to25[317]='\0';
			
			/* 318-318 �F�ƾr�p�H�ʧO */
			if (chk_fsex[0]!='0') strcpy(facc_sex,chk_fsex);
			strncat(prtstr_1to25,(facc_sex[0]=='\0') ? "0" : facc_sex,1);
			strcpy(t_facc_sex,(facc_sex[0]=='\0') ? "0" : facc_sex);
			prtstr_1to25[318]='\0';
			
			/* 319 �F�ƾr�p�H�B�çO */
			strncat(prtstr_1to25,(facc_marri[0]=='\0') ? "0" : facc_marri,1);
			strcpy(t_facc_marri,(facc_marri[0]=='\0') ? "0" : facc_marri);
			prtstr_1to25[319]='\0';

	        /* 320 �����r�p�H�P�Q�O�I�H���Y */
			/* ���z��108/01/01��~�ϥηs�N�� */
			strcpy(dclaim_1080101,trim(dclaim_1080101));
			if(strncmp(dclaim_1080101,"Y",1)==0)
			{
				strncat(prtstr_1to25,(facc_rel[0]=='\0') ? "0" : facc_rel,1);
				strcpy(t_facc_rel,(facc_rel[0]=='\0') ? "0" : facc_rel);
			}
			else
			{
				switch(facc_rel[0])
				{
					case '1':
						strcpy(facc_rel_bf,"1"); 
						break;
					case 'D':
						strcpy(facc_rel_bf,"5"); 
						break;
					case 'G':
						strcpy(facc_rel_bf,"3"); 
						break;
					case '4':
						strcpy(facc_rel_bf,"4"); 
						break;
					case '5':
						strcpy(facc_rel_bf,"5"); 
						break;
					case 'A':
						strcpy(facc_rel_bf,"2"); 
						break;
					case 'B':
						strcpy(facc_rel_bf,"2"); 
						break;
				}
				strncat(prtstr_1to25,(facc_rel_bf[0]=='\0') ? "0" : facc_rel_bf,1);
				strcpy(t_facc_rel,(facc_rel_bf[0]=='\0') ? "0" : facc_rel_bf);
			}
			prtstr_1to25[320]='\0';
	
			/*  �F�Ƴd���ʤ����� */
			if (facc_duty[0] == '1'){
				if ((iself_duty + ioth_duty + ianoth_duty) == 0)
				{
					iself_duty = 100;
				}
				else if ((iself_duty == 0) && ( ioth_duty == 100 ))
				{
					iself_duty = 100;
					ioth_duty = 0;
				}     
			}
			
			if (facc_duty[0] == '3'){
				if ((iself_duty + ioth_duty + ianoth_duty) == 0)
					iself_duty = 100;
			}
				
			if ((facc_duty[0] == '2') && (iself_duty > 0)){
				ioth_duty = 100;
				iself_duty = 0;
			}
			
			if (facc_duty[0] == '2'){
				if ((iself_duty + ioth_duty + ianoth_duty) == 0)
					ioth_duty = 100;
			}
			
			if( strcmp(ioth_cartype,"98")==0 && ioth_duty > 0)
			{
				ioth_duty = 0;
				ianoth_duty = 100 - iself_duty;
			}
	         
			strncpy(oth_cardata,prtstr_1to25+155, 12);
			oth_cardata[12]=0x0;
	
			printf("1 iclaim=%s, o_car=%s\n", iclaim, oth_cardata);
			printf("iacc_reason=%s, facc_duty=%s, iself[%d] ioth[%d] ianoth[%d]\n",iacc_reason, facc_duty, iself_duty , ioth_duty , ianoth_duty);
			        
			/* 10007 �X�I��]11�A1:���F�d�p���A�������ι��F�Ƴd���ʤ��񳣤j��0�A�X�I��]�אּ31:�����ι��Ҧ��L�� */ 
			if( strncmp(iacc_reason,"11",2)==0 && strncmp(facc_duty,"1",1)==0 && iself_duty > 0 && ioth_duty > 0 && ianoth_duty == 0 )
			{
				if(strncmp(prtstr_1to25+155,"            ", 12) ==0) /* �L��訮��� */
				{
					printf("step 1-1\n");
					iself_duty = 100;
					ioth_duty = 0;
					ianoth_duty = 0;
				}
				else
				{
					printf("step 1-2\n");
					strcpy(iacc_reason, "31");
				}  
			}
			
			/* 10007 �X�I��]11�A2:�L�F�d�A�������ι��F�Ƴd���ʤ��񳣬�0�A�X�I��]�אּ21:��訮�L���A���F�Ƴd���ʤ���100 */ 
			if( strncmp(iacc_reason,"11",2)==0 && strncmp(facc_duty,"2",1)==0 && iself_duty == 0 && ioth_duty == 0 && ianoth_duty == 100 )
			{
				if(strncmp(prtstr_1to25+155,"            ", 12) ==0) /* �L��訮��� */
				{
					printf("step 2-1\n");
					strcpy(facc_duty, "0");
					iself_duty = 0;
					ioth_duty = 0;
					ianoth_duty = 0;
				}
				else
				{
					printf("step 2-2\n");
					strcpy(iacc_reason, "21");
					iself_duty = 0;
					ioth_duty = 100;
					ianoth_duty = 0;
				}  
			}
	
			/* 10007 �X�I��]11�A2:�L�F�d�A�����F�Ƴd���ʤ��񳣬�100�A�X�I��]�אּ21:��訮�L���A���F�Ƴd���ʤ���100 */ 
			if( strncmp(iacc_reason,"11",2)==0 && strncmp(facc_duty,"2",1)==0 && iself_duty == 0 && ioth_duty == 100 && ianoth_duty == 0 )
			{
				if(strncmp(prtstr_1to25+155,"            ", 12) ==0) /* �L��訮��� */
				{
					printf("step 2-3\n");
					strcpy(facc_duty, "0");
					iself_duty = 0;
					ioth_duty = 0;
					ianoth_duty = 0;
				}
				else
				{
					printf("step 2-4\n");
					strcpy(iacc_reason, "21");
					iself_duty = 0;
					ioth_duty = 100;
					ianoth_duty = 0;
				}  
			}
	
			/* 10007 �X�I��]12�A2:�L�F�d�A�����F�Ƴd���ʤ���0�A���F�Ƴd���ʤ���100�A�X�I��]�אּ21:��訮�L���A���F�Ƴd���ʤ���100 */ 
			if( strncmp(iacc_reason,"12",2)==0 && strncmp(facc_duty,"2",1)==0 && iself_duty == 0 && ioth_duty == 100 && ianoth_duty == 0 )
			{
				if(strncmp(prtstr_1to25+155,"            ", 12) ==0) /* �L��訮��� */
				{
					printf("step 3-1\n");
					strcpy(iacc_reason, "11");
					strcpy(facc_duty, "0");
					iself_duty = 0;
					ioth_duty = 0;
					ianoth_duty = 0;
				}
				else
				{
					printf("step 3-2\n");
					strcpy(iacc_reason, "21");
					iself_duty = 0;
					ioth_duty = 100;
					ianoth_duty = 0;
				}  
			}
	
			/* 10007 �X�I��]13�A2:�L�F�d�A�����F�Ƴd���ʤ���0�A���F�Ƴd���ʤ���100�A��L�F�Ƴd���ʤ���אּ100 */ 
			if( strncmp(iacc_reason,"13",2)==0 && strncmp(facc_duty,"2",1)==0 && iself_duty == 0 && ioth_duty == 100 && ianoth_duty == 0 )
			{
				if(strncmp(prtstr_1to25+155,"            ", 12) ==0) /* �L��訮��� */
				{
					printf("step 4-1\n");
					iself_duty = 0;
					ioth_duty = 0;
					ianoth_duty = 100;
				}
				else
				{
					printf("step 4-2\n");
					strcpy(iacc_reason, "21");
					strcpy(facc_duty, "2");
					iself_duty = 0;
					ioth_duty = 100;
					ianoth_duty = 0;
				}  
			}
			
			/* 10007 �X�I��]21�A1:�L�F�d�A�����F�Ƴd���ʤ���100�A��L�F�Ƴd���ʤ���0 */ 
			if( strncmp(iacc_reason,"21",2)==0 && strncmp(facc_duty,"1",1)==0 && iself_duty == 100 && ioth_duty == 0 && ianoth_duty == 0 )
			{
				if(strncmp(prtstr_1to25+155,"            ", 12) ==0) /* �L��訮��� */
				{
					printf("step 5-1\n");
					strcpy(iacc_reason, "11");
					strcpy(facc_duty, "1");
					iself_duty = 100;
					ioth_duty = 0;
					ianoth_duty = 0;
				}
				else
				{
					printf("step 5-2\n");
					strcpy(iacc_reason, "21");
					strcpy(facc_duty, "2");
					iself_duty = 0;
					ioth_duty = 100;
					ianoth_duty = 0;
				}
			}
	
			/* 10007 �X�I��]21�A2:�L�F�d�A���F�Ƴd���ʤ���100�A�L��訮��� */ 
			if( strncmp(iacc_reason,"21",2)==0 && strncmp(facc_duty,"2",1)==0 && iself_duty == 0 && ioth_duty == 100 && ianoth_duty == 0 )
			{
				if(strncmp(prtstr_1to25+155,"            ", 12) ==0) /* �L��訮��� */
				{
					printf("step 5-3\n");
					strcpy(iacc_reason, "11");
					strcpy(facc_duty, "0");
					iself_duty = 0;
					ioth_duty = 0;
					ianoth_duty = 0;
				}
				else
				{
					printf("step 5-4\n");
					strcpy(iacc_reason, "21");
					strcpy(facc_duty, "2");
					iself_duty = 0;
					ioth_duty = 100;
					ianoth_duty = 0;
				}
			}
	
	
			/* 10007 �X�I��]21�A2:�L�F�d�A�����F�Ƴd���ʤ���0�A��L�F�Ƴd���ʤ���100�A���F�Ƴd���ʤ���אּ100 */ 
			if( strncmp(iacc_reason,"21",2)==0 && strncmp(facc_duty,"2",1)==0 && iself_duty == 0 && ioth_duty == 0 && ianoth_duty == 100 )
			{
				if(strncmp(prtstr_1to25+155,"            ", 12) ==0) /* �L��訮��� */
				{
					printf("step 5-5\n");
					strcpy(iacc_reason, "11");
					strcpy(facc_duty, "0");
					iself_duty = 0;
					ioth_duty = 0;
					ianoth_duty = 0;
				}
				else
				{
					printf("step 5-6\n");
					strcpy(iacc_reason, "21");
					strcpy(facc_duty, "2");
					iself_duty = 0;
					ioth_duty = 100;
					ianoth_duty = 0;
				}  
			}
	
			/* 10007 �X�I��]31�A1:���F�d�A�����ι��F�Ƴd���ʤ���>100�A���F�Ƴd���ʤ���=100-���� */ 
			if( strncmp(iacc_reason,"31",2)==0 && strncmp(facc_duty,"1",1)==0 && (iself_duty+ioth_duty) > 100 &&
			    strncmp(prtstr_1to25+155,"            ", 12) !=0 )
			{
				if(iself_duty < 100)
				{
					printf("step 6-1\n");
					ioth_duty = 100 - iself_duty;
					ianoth_duty = 0;
				}
				else
				{
					if(ioth_duty < 100)
					{
						printf("step 6-2\n");
						iself_duty = 100 - ioth_duty;
						ianoth_duty = 0;
					}
					else
					{
						printf("step 6-3\n");
						iself_duty = 50;
						ioth_duty = 50;
						ianoth_duty = 0;
					}
				}
			}
	
			/* �L��訮��Ʈ� */
			if( strncmp(iacc_reason,"31",2)==0 && strncmp(facc_duty,"1",1)==0 && 
			   (iself_duty+ioth_duty) > 100 && strncmp(prtstr_1to25+155,"            ", 12) ==0 )
			{
				printf("step 7-1\n");
				strcpy(iacc_reason, "11");
				iself_duty = 100;
				ioth_duty = 0;
				ianoth_duty = 0;
			}
		 
			/* 10007 �X�I��]31�A1:�L�F�d�A�����F�Ƴd���ʤ���100 */ 
			if( strncmp(iacc_reason,"31",2)==0 && strncmp(facc_duty,"1",1)==0 && 
			    iself_duty == 100 && ioth_duty == 0 && ianoth_duty == 0 )
			{
				if(strncmp(prtstr_1to25+155,"            ", 12) ==0) /* �L��訮��� */
				{
					printf("step 8-1\n");
					strcpy(iacc_reason, "11");
					strcpy(facc_duty, "1");
					iself_duty = 100;
					ioth_duty = 0;
					ianoth_duty = 0;
				}
				else
				{
					printf("step 8-2\n");
					strcpy(iacc_reason, "21");
					strcpy(facc_duty, "2");
					iself_duty = 0;
					ioth_duty = 100;
					ianoth_duty = 0;
				}        
			}
		 
		 
			/* 10007 �X�I��]31�A2:�L�F�d�A���F�Ƴd���ʤ���100�A�X�I��]�אּ21 */ 
			if( strncmp(iacc_reason,"31",2)==0 && strncmp(facc_duty,"2",1)==0 && 
			    iself_duty == 0 && ioth_duty == 100 && ianoth_duty == 0 )
			{
				if(strncmp(prtstr_1to25+155,"            ", 12) ==0) /* �L��訮��� */
				{
					printf("step 8-3\n");
					strcpy(iacc_reason, "11");
					strcpy(facc_duty, "0");
					iself_duty = 0;
					ioth_duty = 0;
					ianoth_duty = 0;
				}
				else
				{
					printf("step 8-4\n");
					strcpy(iacc_reason, "21");
					strcpy(facc_duty, "2");
					iself_duty = 0;
					ioth_duty = 100;
					ianoth_duty = 0;
				}       
			}
	
			/* 10007 �X�I��]31�A3:���F�d���p���A�����F�Ƴd���ʤ���100�A�L��訮��ơC�X�I��]�אּ11 */ 
			if( strncmp(iacc_reason,"31",2)==0 && strncmp(facc_duty,"3",1)==0 && 
			    iself_duty == 100 && ioth_duty == 0 && ianoth_duty == 0)	     
			{
				if(strncmp(prtstr_1to25+155,"            ", 12) ==0) /* �L��訮��� */
				{
					printf("step 9-1\n");
					strcpy(iacc_reason, "11");
					iself_duty = 100;
					ioth_duty = 0;
					ianoth_duty = 0;
				}
				else
				{
					printf("step 9-2\n");
					iself_duty = 50;
					ioth_duty = 50;
					ianoth_duty = 0;
				}
			}
	                  
		 
			/* 10007 �X�I��]99�A1:���F�d�p���A��L�����F�Ƴd���ʤ���0�C��L���F�Ƴd���ʤ���אּ100-�����A��訮�F�Ƴd���ʤ���אּ0 */ 
			if( strncmp(iacc_reason,"99",2)==0 && strncmp(facc_duty,"1",1)==0 && ianoth_duty == 0 )
			{
				if(strncmp(prtstr_1to25+155,"            ", 12) ==0) /* �L��訮��� */
				{
					if(iself_duty < 100 && iself_duty > 0)
					{
						printf("step 10-1\n");
						ioth_duty = 0;
						ianoth_duty = 100 - iself_duty;
					}
					else
					{
						printf("step 10-2\n");
						iself_duty = 50;
						ioth_duty = 0;
						ianoth_duty = 50;
					}
				}
				else
				{
					printf("step 10-3\n");
					strcpy(iacc_reason, "31");
					iself_duty = 50;
					ioth_duty = 50;
					ianoth_duty = 0;
				}  
			}
	
			/* 10007 �X�I��]99�A2:�L�F�d�A��L�����F�Ƴd���ʤ���0�C��L���F�Ƴd���ʤ���אּ100�A��訮�F�Ƴd���ʤ���אּ0 */ 
			if( strncmp(iacc_reason,"99",2)==0 && strncmp(facc_duty,"2",1)==0 && ianoth_duty == 0 )
			{
				if(strncmp(prtstr_1to25+155,"            ", 12) ==0) /* �L��訮��� */
				{ 
					printf("step 11-1\n");
					iself_duty = 0;
					ioth_duty = 0;
					ianoth_duty = 100;
				}
				else
				{
					printf("step 11-2\n");
					strcpy(iacc_reason, "21");
					iself_duty = 0;
					ioth_duty = 100;
					ianoth_duty = 0;
				}
			}
			 
			/* 10007��@�ƬG�G��訮�F�d����0  142-143 */
			if( strcmp(ioth_cartype,"98")==0 && ioth_duty > 0)
			{
				printf("step 12\n");
				ioth_duty = 0;
				ianoth_duty = 100 - iself_duty;
			}
			printf("2 iclaim=%s, o_car=%s\n", iclaim, oth_cardata);
			printf("iacc_reason=%s, facc_duty=%s, iself[%d] ioth[%d] ianoth[%d]\n",iacc_reason, facc_duty, iself_duty , ioth_duty , ianoth_duty);
		         
			/* 321 �X�I��] */
			strncat(prtstr_1to25,(iacc_reason[0]=='\0') ? "  " : iacc_reason,2);
			strcpy(t_iacc_reason,(iacc_reason[0]=='\0') ? "  " : iacc_reason);
			prtstr_1to25[322]='\0';
			
			/* 323 �F�Ƴd���N�� */
			strncat(prtstr_1to25,(facc_duty[0]=='\0') ? "0" : facc_duty,1);
			strcpy(t_facc_duty,(facc_duty[0]=='\0') ? "0" : facc_duty);
			prtstr_1to25[323]='\0';
	         
			/* 324 �A�β�29���l�v�ƶ� add by larry 103.10.08 (1030521004_C2) */
			/*$SELECT iverify
			     INTO $sIverify
			     FROM ca_ver_relation
			    WHERE iclaim = $iclaim;
			if (SQLCODE == SQLNOTFOUND) strcpy(sIverify, iclaim);
			
			$SELECT fsubrogation INTO $sFsubrogation
			   FROM ca_clm_victim_data
			  WHERE ivictim = $iacc_license
			    AND iclaim = $sIverify;
			if (SQLCODE == SQLNOTFOUND) strcpy(sFsubrogation,"N");*/	
			strncat(prtstr_1to25," ",1);
			strcpy(t_fsubrogation," ");
			prtstr_1to25[324]='\0';
	         
			/* 325-327 �����F�Ƴd���ʤ��� */
			t_iself_duty = iself_duty;
			buf1[0]='\0';
			rfmtlong(iself_duty,"&&&",buf1);
			strncat(prtstr_1to25,(buf1[0]=='\0') ? "000" : buf1,3);
			prtstr_1to25[327]='\0';
			
			/* 328-330 ��訮�F�Ƴd���ʤ��� */
			t_ioth_duty = ioth_duty;
			buf1[0]='\0';
			rfmtlong(ioth_duty,"&&&",buf1);
			strncat(prtstr_1to25,(buf1[0]=='\0') ? "000" : buf1,3);
			prtstr_1to25[330]='\0';
			
			/* 331-333 ��L���F�Ƴd���ʤ��� */
			t_ianoth_duty = ianoth_duty;
			buf1[0]='\0';
			rfmtlong(ianoth_duty,"&&&",buf1);
			strncat(prtstr_1to25,(buf1[0]=='\0') ? "000" : buf1,3);
			prtstr_1to25[333]='\0';
	
			/* �ˤ`���ΥN������ */
			/* 334-348 �������ˤ`���� */
			t_qacar_death = qacar_death;t_qacar_cripple = qacar_cripple;t_qacar_injure = qacar_injure;
			strncat(prtstr_1to25,"A1",2);
			buf1[0]='\0';
			rfmtlong(qacar_death,"&&&",buf1);
			strncat(prtstr_1to25,(buf1[0]=='\0') ? "000" : buf1,3);
			prtstr_1to25[338]='\0';
			strncat(prtstr_1to25,"A2",2);
			buf1[0]='\0';
			rfmtlong(qacar_cripple,"&&&",buf1);
			strncat(prtstr_1to25,(buf1[0]=='\0') ? "000" : buf1,3);
			prtstr_1to25[343]='\0';
			strncat(prtstr_1to25,"A3",2);
			buf1[0]='\0';
			rfmtlong(qacar_injure,"&&&",buf1);
			strncat(prtstr_1to25,(buf1[0]=='\0') ? "000" : buf1,3);
			prtstr_1to25[348]='\0';
			
			/* 349-363 ��訮���ˤ`���� */
			t_qbcar_death = qbcar_death;t_qbcar_cripple = qbcar_cripple;t_qbcar_injure = qbcar_injure;
			strncat(prtstr_1to25,"B1",2);
			buf1[0]='\0';
			rfmtlong(qbcar_death,"&&&",buf1);
			strncat(prtstr_1to25,(buf1[0]=='\0') ? "000" : buf1,3);
			prtstr_1to25[353]='\0';
			strncat(prtstr_1to25,"B2",2);
			buf1[0]='\0';
			rfmtlong(qbcar_cripple,"&&&",buf1);
			strncat(prtstr_1to25,(buf1[0]=='\0') ? "000" : buf1,3);
			prtstr_1to25[358]='\0';
			strncat(prtstr_1to25,"B3",2);
			buf1[0]='\0';
			rfmtlong(qbcar_injure,"&&&",buf1);
			strncat(prtstr_1to25,(buf1[0]=='\0') ? "000" : buf1,3);
			prtstr_1to25[363]='\0';
			
			/* 364-378 ���~�H���ˤ`���� */
			t_qccar_death = qccar_death;t_qccar_cripple = qccar_cripple;t_qccar_injure = qccar_injure;
			strncat(prtstr_1to25,"C1",2);
			buf1[0]='\0';
			rfmtlong(qccar_death,"&&&",buf1);
			strncat(prtstr_1to25,(buf1[0]=='\0') ? "000" : buf1,3);
			prtstr_1to25[368]='\0';
			strncat(prtstr_1to25,"C2",2);
			buf1[0]='\0';
			rfmtlong(qccar_cripple,"&&&",buf1);
			strncat(prtstr_1to25,(buf1[0]=='\0') ? "000" : buf1,3);
			prtstr_1to25[373]='\0';
			strncat(prtstr_1to25,"C3",2);
			buf1[0]='\0';
			rfmtlong(qccar_injure,"&&&",buf1);
			strncat(prtstr_1to25,(buf1[0]=='\0') ? "000" : buf1,3);
			prtstr_1to25[378]='\0';
	
			/* 379-386 �X�I��� */
			strncpy(daccident_yyyy,&daccident[0],4); daccident_yyyy[4]='\0';
			strncpy(daccident_mm,&daccident[5],2); daccident_mm[2]='\0';
			strncpy(daccident_dd,&daccident[8],2); daccident_dd[2]='\0';
			strncat(prtstr_1to25,(daccident_yyyy[0]=='\0') ? "0000" : daccident_yyyy,4);
			strncat(prtstr_1to25,(daccident_mm[0]=='\0') ? "00" : daccident_mm,2);
			strncat(prtstr_1to25,(daccident_dd[0]=='\0') ? "00" : daccident_dd,2);
			strcpy(t_daccident,(daccident_yyyy[0]=='\0') ? "0000" : daccident_yyyy);
			strcat(t_daccident,(daccident_mm[0]=='\0') ? "00" : daccident_mm);
			strcat(t_daccident,(daccident_dd[0]=='\0') ? "00" : daccident_dd);
			prtstr_1to25[386]='\0';
			
			/* 387-388 �X�I�a�ϥN�� */
			strncat(prtstr_1to25,(iacc_area[0]=='\0') ? "00" : iacc_area,2);
			strcpy(t_iacc_area,(iacc_area[0]=='\0') ? "00" : iacc_area);
			prtstr_1to25[388]='\0';
	
			/**********************************************************************/
			tot_mcoverage = tot_pel_cnt = tot_sum_mapp_cover = 0;
			mapp_cover_tot = 0;
			tot_sum_mins_stl = tot_sum_mins_proc = tot_sum_mins_health = 0;
			tot_sum_all = 0;
			pel_cnt_A = 0;
			pel_cnt = 0;
			victim_num = 0;
			sum_mapp_cover = 0;
			tmp_mins_stl = tmp_mins_proc = tmp_mstl_health = tmp_sum_all = 0;
			
			/* �ӫ~�N�X */
			/* �@�ߥH�I�ظ�Ƭ��D */
			/* ���� */
			/*if ((!strncmp(icar_type,"01",2)) || 
			    (!strncmp(icar_type,"02",2)) ||
			    (!strncmp(icar_type,"32",2)) ||
			    (!strncmp(icar_type,"34",2)) ||
			    (!strncmp(icar_type,"35",2)))
				strcpy(fcar_class,"3");
			else{
				$SELECT fcar_class
				   INTO $fcar_class
				   FROM car_type
				  WHERE icode = $icar_type
				    AND fclass = '1';
				if (SQLCODE == SQLNOTFOUND) strcpy(fcar_class,"1");
			}
			
			strcpy(icode2," ");
			$SELECT iproduct
			   INTO $iproduct
			   FROM cm_product_code
			  WHERE iins_type = '21'
			    AND icode1 = $fcar_class
			    AND icode2 = $icode2;
			if (SQLCODE == SQLNOTFOUND) strcpy(iproduct,"000000000000");*/
	
			/* ���ݫO�B */
			$SELECT NVL(MAX(mfactor), 1500000)
			   INTO $mcoverageBC
			   FROM ca_reco_factor
			  WHERE itype=7
			    AND icode='C010'
			    AND $long_daccident BETWEEN dbegin AND dend;
	
			/******** �}�l�����I���O ********/
			/******** ���I���O�N�� = A ********/
			strcpy( victim_bak , "  ");
			/*** �v�@���C�@���`�H�B�����I�����O�Ϊ� ***/
			mcoverage_A00 = 0;
			sprintf_s(stmt,5120,"SELECT ivictim , iins_item , (mapp_cover+mapp_fee) \
			                FROM %s:ca_app_victim \
			               WHERE iclaim = '%s' \
			                 AND iins_item[1,1] = 'A' \
			               ORDER BY ivictim , iins_item ",list[k].dbname,iclaim);
			printf("stmt===>[%s]\n",stmt);
			$PREPARE car9994_victim_A_tmp FROM $stmt;
			$DECLARE car9994_victimA CURSOR FOR car9994_victim_A_tmp;
			$OPEN car9994_victimA;
			while (1)
			{
				$FETCH car9994_victimA INTO $victim , $iins_item , $tmp_mapp_cover;
				if (SQLCODE == SQLNOTFOUND) break;
				
				printf("iclaim=[%s] iins_item=[%s] victim=[%s]\n",iclaim, iins_item, victim );
				sprintf_s(stmt,5120,"SELECT First 1 dappraisal,(mapp_cover+mapp_fee) \
				                FROM %s:ca_app_victim_hist \
				               WHERE iclaim = ? \
				                 AND iins_item = ? \
				                 AND ivictim = ? \
				                 AND dappraisal < ? \
				               ORDER BY dappraisal Desc",list[k].dbname);
				printf("stmt===>[%s]\n",stmt);
				printf("iclaim=[%s],iins_item[%s],victim[%s],enddate_l[%ld],enddate[%s]\n",iclaim,iins_item,victim,enddate_l,enddate);
				$PREPARE hist_clm_A FROM $stmt;
				$EXECUTE hist_clm_A INTO $tmp_dappraisal, $tmp_mapp_cover using $iclaim, $iins_item, $victim, $enddate_l;
				
				if(SQLCODE == SQLNOTFOUND) continue;
				printf("tmp_mapp_cover=[%d]\n", tmp_mapp_cover );
				
				flast[0]  = '\0';
				fflast[0] = '\0';
				p_flag_close = 0;
				tmp_mins_stl = 0;
				tmp_mins_proc = 0;
				tmp_mstl_health = 0;
				tmp_sum_all = 0; /*** �v�M���B ***/
				
				
				sprintf_s(stmt,5120,"SELECT fstl , mins_stl , mins_proc , mstl_health , flast \
				                FROM %s:ca_stl_victim \
				               WHERE iclaim    = ? \
				                 AND ivictim   = ? \
				                 AND iins_item = ? \
				                 AND dgroup    <  ? ",list[k].dbname);
				printf("stmt===>[%s]\n",stmt);
				$PREPARE car94_stl_vitA FROM $stmt;
				$DECLARE car94_stl_vit CURSOR FOR car94_stl_vitA;
				$OPEN car94_stl_vit using $iclaim, $victim, $iins_item, $enddate_l;
				while(1)
				{
					$FETCH car94_stl_vit INTO :fstl , :tmp_mins_stl , :tmp_mins_proc , :tmp_mstl_health , :flast;
					printf("fstl=[%s] tmp_mins_stl=[%d] tmp_mins_proc=[%d] tmp_mstl_health=[%d] flast=[%s] SQLCODE[%d] [%d]\n ", fstl,tmp_mins_stl,tmp_sum_all,tmp_mstl_health,flast,SQLCODE,SQLNOTFOUND);
					if (SQLCODE == SQLNOTFOUND) break;
					
					if (flast[0] == '2') p_flag_close = 1;
					if (flast[0] == '1') strcpy(fflast,"Y");
					
					if (fstl[0] == '1') tmp_sum_all+=(tmp_mins_stl+tmp_mins_proc+tmp_mstl_health);
					else  tmp_sum_all-=(tmp_mins_stl-tmp_mins_proc);
					
					printf("iins_item=[%s] flast=[%s] tmp_sum_all=[%d]\n", iins_item, flast, tmp_sum_all );
				}
				$CLOSE car94_stl_vit;
				$FREE car94_stl_vit;
				
				/*** ���O���N��D�v,�j���I�������I���O���~�⵲��,�_�h�p�J���M ***/
				if (p_flag_close == 1) continue;
				
				/*** �K�ߵ��ץ礣�p�J���M��� ***/
				if ((tmp_sum_all == 0) && (fflast[0] == 'Y')) continue;
				
				/*** �p�⥼�M���B=�w�����B-�w�M���B ***/
				mapp_cover_tot = tmp_mapp_cover - tmp_sum_all;
				
				printf("mapp_cover_tot=[%d] tmp_mapp_cover=[%d] tmp_sum_all=[%d]",
				mapp_cover_tot, tmp_mapp_cover, tmp_sum_all );
				
				if (mapp_cover_tot < 0) mapp_cover_tot = 0;
				
				sum_mapp_cover += mapp_cover_tot;
	
				sprintf_s(stmt,5120,"select count(*) \
				                from %s:settlement a, %s:ao_close_temp b \
				               where a.fstl = '2' \
				                 and a.ireceive = b.itmp_no \
				                 and b.nclaim_obj in ('��F�|�å͸p�������d�O�I��','�������O��','��F�|�å͸p�������O��') \
				                 and a.iclaim = '%s' ",list[k].dbname,list[k].dbname,iclaim);
				printf("stmt[%s] \n",stmt);
				$PREPARE car9994_stl_ao_A FROM $stmt;
				$EXECUTE car9994_stl_ao_A INTO $ishealth;

				/*** ��C�H�O�I���B�̰��� ***/
				sprintf_s(stmt,5120,"select MAX(mcoverage) \
				                from %s:ca_app_victim \
				               where iclaim = '%s' \
				                 and iins_item[1,1] = 'A' ",list[k].dbname,iclaim);
					                 
				$PREPARE car9994_mcoverage_A FROM $stmt;
				$EXECUTE car9994_mcoverage_A INTO $mcoverage;
				
				/*** �p�⦳�X�쵹�I���O���iA�j�����`�H ***/
				if( strcmp(victim_bak, victim) != 0 )
				{
					victim_num++;
					strcpy(victim_bak, victim);
				}
				pel_cnt++;
			}
			$CLOSE car9994_victimA;
			$FREE  car9994_victimA;
	
			if (pel_cnt >0 )
			{
				/**** ��Jprtstr�r�� ****/
				strcpy(prtstr,prtstr_1to25);
	
				/* 389-391 ���I���O�N�� */
				strncat(prtstr,"A00",3);
				prtstr[391]='\0';
				
				/* 392-400 �C�ӤH�O�I���B */
				strcat(prtstr,"+");
				mcoverage=200000;
				buf1[0]='\0';
				rfmtlong(mcoverage,"&&&&&&&&",buf1);
				strncat(prtstr,(buf1[0]=='\0') ? "00000000" : buf1,8);
				prtstr[400]='\0';
				tot_mcoverage+=mcoverage;
				mcoverage_A00 = 200000;
				
				/* 401-404 �z�ߤH����ˤH�� */
				buf1[0]='\0';
				rfmtlong(victim_num,"&&&&",buf1);
				strncat(prtstr,(buf1[0]=='\0') ? "0000" : buf1,4);
				prtstr[404]='\0';
				tot_pel_cnt+=victim_num;
				
				/* 405-417 ���M���B */
				strcat(prtstr,"+");
				buf1[0]='\0';
				rfmtlong(sum_mapp_cover,"&&&&&&&&&&&&",buf1);
				strncat(prtstr,(buf1[0]=='\0') ? "000000000000" : buf1,12);
				prtstr[417]='\0';
				
				tot_sum_mapp_cover+=sum_mapp_cover;
				
				/* 418-430 ���t�ثO�z�ߪ��B */
				sum_mstl_health = ((ishealth > 0 && fstl=='2') ? sum_mstl_health : sum_mstl_health);
				sum_mins_stl = ((ishealth > 0 && fstl=='2') ? 0 : sum_mins_stl);
				strcat(prtstr,"+");
				buf1[0]='\0';
				strncat(prtstr, "000000000000" ,12);
				prtstr[430]='\0';
				
				tot_sum_mins_stl+=sum_mins_stl;
				
				/* 431-441 �z�߶O�� */
				strcat(prtstr,"+");
				buf1[0]='\0';
				strncat(prtstr, "0000000000"  ,10);
				prtstr[441]='\0';
				
				tot_sum_mins_proc+=sum_mins_proc;
				
				/* 442-452 ���I���O���B */
				strcat(prtstr,"+");
				buf1[0]='\0';
				rfmtlong(sum_mins_health,"&&&&&&&&&&",buf1);
				strncat(prtstr,  "0000000000"  ,10);
				prtstr[452]='\0';
				
				tot_sum_mins_health+=sum_mins_health;
				
				/* 453-461 ���O�I�� */
				strcat(prtstr,"+");
				buf1[0]='\0';
				strncat(prtstr,  "00000000"  ,8);
				prtstr[461]='\0';
				
				/* 462-470 ���O���B */
				strcat(prtstr,"+");
				buf1[0]='\0';
				strncat(prtstr,  "00000000"  ,8);
				prtstr[470]='\0';
				
				/* 471-483 ��ڲz�ߪ��B */
				strcat(prtstr,"+");
				buf1[0]='\0';
				rfmtlong(sum_all,"&&&&&&&&&&&&",buf1);
				strncat(prtstr, "000000000000" ,12);
				prtstr[483]='\0';
				
				tot_sum_all+=sum_all;
				
				strcpy(t_istl_class,"A00");
				t_mcoverage = mcoverage;
				t_victim_num = victim_num;
				t_mapp_cover = sum_mapp_cover;
				t_mins_stl = 0;
				t_mins_proc = 0;
				t_mstl_health = 0;
				t_qhealth = 0;
				t_mhealth = 0;
				t_sum_all = sum_all;
				
				/* 484-495 �ӫ~�N�X */
				strcat(prtstr,iproduct);
				strcpy(t_iproduct,iproduct);
				prtstr[495]='\0';
				
				strncpy(iproduct_tmp,iproduct+3,2);
				iproduct_tmp[2] = '\0';
				if (strcmp(iproduct_tmp,"14") == 0) 
				{
					mprem_14 += sum_mapp_cover;
					mhealth_14 += 0;
				}
				else if (strcmp(iproduct_tmp,"15") == 0) 
				{
					mprem_15 += sum_mapp_cover;
					mhealth_15 += 0;
				}
				else if (strcmp(iproduct_tmp,"16") == 0) 
				{
					mprem_16 += sum_mapp_cover;
					mhealth_16 += 0;
				}
				else if (strcmp(iproduct_tmp,"32") == 0) 
				{
					mprem_32 += sum_mapp_cover;
					mhealth_32 += 0;
				}
				
				/* 496-503 �ߥI��� */
				strncat(prtstr, "00000000", 8);
				prtstr[503]='\0';
				
				/* 504-505 �q���O�N�� */
				strcat(prtstr,bzfrom);
				strcpy(t_bzfrom,bzfrom);
				prtstr[505]= '\0';
				
				/* 506-513 ��ƻs�e���*/
				strcat(prtstr,ttday_yy);
				strcat(prtstr,ttday_mm);
				strcat(prtstr,ttday_dd);
				strcpy(t_dsend,ttday_yy);
				strcat(t_dsend,ttday_mm);
				strcat(t_dsend,ttday_dd);
				prtstr[513]='\0';
	
				pel_cnt_A = 1;
				count1++;
				fprintf(fptr,"%s\n",prtstr);
				
				printf("data_yyyymm[%s],t_fend_yn[%s],t_fstl[%s],t_istl_recover[%s],t_ihealth[%s],t_dclaim[%s],t_iclm_company[%s],t_iclm_br[%s],t_iclaim[%s],t_iclose_type[%d],t_istl_flag[%s] \n",
		                data_yyyymm,t_fend_yn,t_fstl,t_istl_recover,t_ihealth,t_dclaim,t_iclm_company,t_iclm_br,t_iclaim,t_iclose_type,t_istl_flag);
				printf("t_dgroup[%s],t_icard_company[%s],t_icard_br[%s],t_icard[%s],t_dply_begin[%s],t_dply_end[%s],t_iarea[%s],t_iobjno[%s],t_iissue_year[%s],t_ipro_year[%s] \n",
				        t_dgroup,t_icard_company,t_icard_br,t_icard,t_dply_begin,t_dply_end,t_iarea,t_iobjno,t_iissue_year,t_ipro_year);
				printf("t_ioth_fassured[%s],t_ioth_cartype[%s],t_ioth_qpt[%d],t_ioth_fpt[%s],t_ioth_tag[%s],t_ioth_comp_yn[%s],t_ioth_card_company[%s],t_ioth_card[%s] \n",
				        t_ioth_fassured,t_ioth_cartype,t_ioth_qpt,t_ioth_fpt,t_ioth_tag,t_ioth_comp_yn,t_ioth_card_company,t_ioth_card);
				printf("t_fcomp_class[%s],t_qdrunk_driving[%d],t_mins_premium[%d],t_madjcom_prem[%f],t_mbusiness[%f],t_maintain[%f],t_mcompensation[%f],t_mstable[%f],t_mdrunk_prem[%d],t_mdrunk_pure_prem[%f],t_drate_ym[%s] \n",
				        t_fcomp_class,t_qdrunk_driving,t_mins_premium,t_madjcom_prem,t_mbusiness,t_maintain,t_mcompensation,t_mstable,t_mdrunk_prem,t_mdrunk_pure_prem,t_drate_ym);
				printf("t_fassured[%s],t_iassured[%s],t_dbirth[%s],t_fsex[%s],t_fmarriage[%s],t_facc_nation[%s],t_iacc_license[%s],t_iacc_birth[%s],t_facc_sex[%s],t_facc_marri[%s],t_facc_rel[%s] \n",
				        t_fassured,t_iassured,t_dbirth,t_fsex,t_fmarriage,t_facc_nation,t_iacc_license,t_iacc_birth,t_facc_sex,t_facc_marri,t_facc_rel);
				printf("t_iacc_reason[%s],t_facc_duty[%s],t_fsubrogation[%s],t_iself_duty[%d],t_ioth_duty[%d],t_ianoth_duty[%d] \n",
				        t_iacc_reason,t_facc_duty,t_fsubrogation,t_iself_duty,t_ioth_duty,t_ianoth_duty);
				printf("t_qacar_death[%d],t_qacar_cripple[%d],t_qacar_injure[%d],t_qbcar_death[%d],t_qbcar_cripple[%d],t_qbcar_injure[%d],t_qccar_death[%d],t_qccar_cripple[%d],t_qccar_injure[%d] \n",
				        t_qacar_death,t_qacar_cripple,t_qacar_injure,t_qbcar_death,t_qbcar_cripple,t_qbcar_injure,t_qccar_death,t_qccar_cripple,t_qccar_injure);
				printf("t_daccident[%s],t_iacc_area[%s],t_istl_class[%s],t_mcoverage[%d],t_victim_num[%d],t_mapp_cover[%d],t_mins_stl[%d],t_mins_proc[%d],t_mstl_health[%d],t_qhealth[%d],t_mhealth[%d],t_sum_all[%d] \n",
				        t_daccident,t_iacc_area,t_istl_class,t_mcoverage,t_victim_num,t_mapp_cover,t_mins_stl,t_mins_proc,t_mstl_health,t_qhealth,t_mhealth,t_sum_all);
				printf("t_iproduct[%s],t_bzfrom[%s],t_dsend[%s] \n",
				        t_iproduct,t_bzfrom,t_dsend);
				/* �d�s��� */
				sprintf_s(stmt,5120,"INSERT INTO %s:ca_dev_clm_comp \
				                     (data_yyyymm,idata,fend_yn,fstl,istl_recover,ihealth,dclaim,iclm_company,iclm_br,iclaim,iclose_type,istl_flag, \
				                      dgroup,icard_company,icard_br,icard,dply_begin,dply_end,iarea,iobjno,iissue_year,ipro_year, \
				                      ibrand,icar_type,icar_type_no,qcylinder,iengine,itag,qpt,fpt, \
				                      ioth_fassured,ioth_cartype,ioth_qpt,ioth_fpt,ioth_tag,ioth_comp_yn,ioth_card_company,ioth_card, \
				                      fcomp_class,qdrunk_driving,mins_premium,madjcom_prem,mbusiness,maintain,mcompensation,mstable,mdrunk_prem,mdrunk_pure_prem,drate_ym, \
				                      fassured,iassured,dbirth,fsex,fmarriage,facc_nation,iacc_license,iacc_birth,facc_sex,facc_marri,facc_rel, \
				                      iacc_reason,facc_duty,fsubrogation,iself_duty,ioth_duty,ianoth_duty, \
				                      qacar_death,qacar_cripple,qacar_injure,qbcar_death,qbcar_cripple,qbcar_injure,qccar_death,qccar_cripple,qccar_injure, \
				                      daccident,iacc_area,istl_class,mcoverage,victim_num,mapp_cover,mins_stl,mins_proc,mstl_health,qhealth,mhealth,sum_all, \
				                      iproduct,bzfrom,dsend) \
				               VALUES(?,'U',?,?,?,?,?,?,?,?,?,?, \
				                      ?,?,?,?,?,?,?,?,?,?, \
				                      ?,?,?,?,?,?,?,?, \
				                      ?,?,?,?,?,?,?,?, \
				                      ?,?,?,?,?,?,?,?,?,?,?, \
				                      ?,?,?,?,?,?,?,?,?,?,?, \
				                      ?,?,?,?,?,?, \
				                      ?,?,?,?,?,?,?,?,?, \
				                      ?,?,?,?,?,?,?,?,?,?,?,?, \
				                      ?,?,?)",list[k].dbname);
				$PREPARE insert_ply_edr FROM $stmt;
				$EXECUTE insert_ply_edr using $data_yyyymm,$t_fend_yn,$t_fstl,$t_istl_recover,$t_ihealth,$t_dclaim,$t_iclm_company,$t_iclm_br,$t_iclaim,$t_iclose_type,$t_istl_flag,
				                              $t_dgroup,$t_icard_company,$t_icard_br,$t_icard,$t_dply_begin,$t_dply_end,$t_iarea,$t_iobjno,$t_iissue_year,$t_ipro_year,
				                              $t_ibrand,$t_icar_type,$t_icar_type_no,$t_qcylinder,$t_iengine,$t_itag,$t_qpt,$t_fpt,
				                              $t_ioth_fassured,$t_ioth_cartype,$t_ioth_qpt,$t_ioth_fpt,$t_ioth_tag,$t_ioth_comp_yn,$t_ioth_card_company,$t_ioth_card,
				                              $t_fcomp_class,$t_qdrunk_driving,$t_mins_premium,$t_madjcom_prem,$t_mbusiness,$t_maintain,$t_mcompensation,$t_mstable,$t_mdrunk_prem,$t_mdrunk_pure_prem,$t_drate_ym,
				                              $t_fassured,$t_iassured,$t_dbirth,$t_fsex,$t_fmarriage,$t_facc_nation,$t_iacc_license,$t_iacc_birth,$t_facc_sex,$t_facc_marri,$t_facc_rel,
				                              $t_iacc_reason,$t_facc_duty,$t_fsubrogation,$t_iself_duty,$t_ioth_duty,$t_ianoth_duty,
				                              $t_qacar_death,$t_qacar_cripple,$t_qacar_injure,$t_qbcar_death,$t_qbcar_cripple,$t_qbcar_injure,$t_qccar_death,$t_qccar_cripple,$t_qccar_injure,
				                              $t_daccident,$t_iacc_area,$t_istl_class,$t_mcoverage,$t_victim_num,$t_mapp_cover,$t_mins_stl,$t_mins_proc,$t_mstl_health,$t_qhealth,$t_mhealth,$t_sum_all,
			                              	  $t_iproduct,$t_bzfrom,$t_dsend;
			}
	 	/******** ���I���O�N�� = B **********/
	
			tot_mcoverage = 0;
			mapp_cover_tot = 0;
			tot_sum_mins_stl = tot_sum_mins_proc = tot_sum_mins_health = 0;
			tot_sum_all = 0;
			pel_cnt_B = 0;
			pel_cnt = 0;
			victim_num = 0;
			sum_mapp_cover = 0;
			tmp_mapp_cover = 0;
			mcoverage_B00  = 0;
			
			/*** �v�@���C�@���`�H�B�����`�ץ�� ***/
			sprintf_s(stmt,5120,"SELECT ivictim , iins_item , (mapp_cover+mapp_fee) \
			                FROM %s:ca_app_victim \
			               WHERE iclaim = '%s' \
			                 AND iins_item[1,1] = 'B' ",list[k].dbname,iclaim);
			                 
			$PREPARE car9994_death_tmp FROM $stmt;
			$DECLARE car9994_death CURSOR FOR car9994_death_tmp;
			$OPEN car9994_death;
			while (1)
			{
				$FETCH car9994_death INTO $victim , $iins_item , $tmp_mapp_cover;
				if (SQLCODE == SQLNOTFOUND) break;
				
				sprintf_s(stmt,5120, "SELECT First 1 dappraisal,mapp_cover+mapp_fee \
				                 FROM %s:ca_app_victim_hist \
				                WHERE iclaim = ? \
				                  AND iins_item = ? \
				                  AND ivictim = ? \
				                  AND dappraisal < ? \
				                ORDER BY dappraisal Desc",list[k].dbname);
				$PREPARE hist_clm_B FROM $stmt;
				$EXECUTE hist_clm_B into $tmp_dappraisal, $tmp_mapp_cover using $iclaim, $iins_item, $victim, $enddate_l;
				if(SQLCODE == SQLNOTFOUND) continue;
				
				flast[0] = '0';
				fflast[0] = '\0';
				sum_all = 0;
				tmp_mins_stl = 0;
				tmp_mins_proc = 0;
				tmp_sum_all = 0;
				p_flag_close = 0;
				
				/*** �p��w�M���B ***/
				sprintf_s(stmt,5120,"SELECT fstl, mins_stl, mins_proc, flast \
				                FROM %s:ca_stl_victim \
				               WHERE iclaim  = '%s' \
				                 AND ivictim = '%s' \
				                 AND iins_item = '%s' \
				                 AND dgroup < %ld ",list[k].dbname,iclaim,victim,iins_item,enddate_l);

				$PREPARE car94_stl_death_tmp FROM $stmt;
				$DECLARE car94_stl_death CURSOR FOR car94_stl_death_tmp;
				$OPEN car94_stl_death;
				while(1)
				{
					$FETCH car94_stl_death INTO :fstl, :tmp_mins_stl, :tmp_mins_proc, :flast;
					if (SQLCODE == SQLNOTFOUND) break;
					
					if (flast[0] == '1') p_flag_close = 1;
					if (flast[0] == '1') strcpy(fflast,"Y");
					
					if (fstl[0] == '1') tmp_sum_all+=(tmp_mins_stl+tmp_mins_proc);
					else if (fstl[0] == '2') tmp_sum_all-=(tmp_mins_stl-tmp_mins_proc);
				}
				$CLOSE car94_stl_death;
				$FREE car94_stl_death;
				
				/*** �̫�@�����O ***/
				if (p_flag_close == 1) continue;
				
				/*** �p�⥼�M���B ***/
				mapp_cover_tot = tmp_mapp_cover - tmp_sum_all;
				
				if (mapp_cover_tot < 0) mapp_cover_tot = 0;
				
				sum_mapp_cover += mapp_cover_tot;
				
				/*** ��C�H�O�I���B�̰��� ***/
				sprintf_s(stmt,5120,"select MAX(mcoverage) \
				                from %s:ca_app_victim \
				               where iclaim = '%s' \
				                 and iins_item[1,1] = 'B' ",list[k].dbname,iclaim);

				$PREPARE car9994_mcoverage_B FROM $stmt;
				$EXECUTE car9994_mcoverage_B INTO $mcoverage;
				
				/*** �p�⦳�X�쵹�I���O���iB�j�����`�H ***/
				victim_num++;
				pel_cnt++;
			}
			$CLOSE car9994_death;
			$FREE  car9994_death;
	
			if (pel_cnt > 0)
			{
				strcpy(prtstr,prtstr_1to25);
				
				/* 289-391 ���I���O�N�� */
				strcat(prtstr,"B00");
				prtstr[391]='\0';
				
				/* 392-400 �C�H�O�I���B */
				strcat(prtstr,"+");
				mcoverage=mcoverageBC;
				buf1[0]='\0';
				rfmtlong(mcoverage,"&&&&&&&&",buf1);
				strncat(prtstr,(buf1[0]=='\0') ? "00000000" : buf1,8);
				prtstr[400]='\0';
				tot_mcoverage+=mcoverage;
				mcoverage_B00 = mcoverage;
				
				/* 401-404 �z�ߤH�� */
				buf1[0]='\0';
				rfmtlong(pel_cnt,"&&&&",buf1);
				strncat(prtstr,(buf1[0]=='\0') ? "0000" : buf1,4);
				prtstr[404]='\0';
				tot_pel_cnt+=pel_cnt;
				
				/* 405-417 �w���l�����B */
				strcat(prtstr,"+");
				buf1[0]='\0';
				rfmtlong(sum_mapp_cover,"&&&&&&&&&&&&",buf1);
				strncat(prtstr,(buf1[0]=='\0') ? "000000000000" : buf1,12);
				prtstr[417]='\0';
				tot_sum_mapp_cover+=sum_mapp_cover;
				
				/* 418-430 ���t�ثO�z�ߪ��B */
				strcat(prtstr,"+");
				buf1[0]='\0';
				rfmtlong(sum_mins_stl,"&&&&&&&&&&&&",buf1);
				/*strcat(prtstr,(buf1[0]=='\0') ? "000000000000" : buf1); */
				strcat(prtstr, "000000000000" );
				prtstr[430]='\0';
				
				tot_sum_mins_stl+=sum_mins_stl;
				
				/* 431-441 �z�߶O�� */
				strcat(prtstr,"+");
				buf1[0]='\0';
				rfmtlong(sum_mins_proc,"&&&&&&&&&&",buf1);
				/*strcat(prtstr,(buf1[0]=='\0') ? "0000000000" : buf1); */
				strncat(prtstr, "0000000000",10 );
				prtstr[441]='\0';
				
				tot_sum_mins_proc+=sum_mins_proc;
				
				/* 442-452 */
				strcat(prtstr,"+");
				buf1[0]='\0';
				rfmtlong(sum_mins_health,"&&&&&&&&&&",buf1);
				/*strcat(prtstr,(buf1[0]=='\0') ? "0000000000" : buf1); */
				strcat(prtstr, "0000000000" );
				prtstr[452]='\0';
				
				tot_sum_mins_health+=sum_mins_health;
				
				/* 453-461 ���O�I�� */
				strcat(prtstr,"+");
				buf1[0]='\0';
				strncat(prtstr,  "00000000"  ,8);
				prtstr[461]='\0';
				
				/* 462-470 ���O���B */
				strcat(prtstr,"+");
				buf1[0]='\0';
				strncat(prtstr,  "00000000"  ,8);
				prtstr[470]='\0';
				
				/* 471-483 ��ڲz�ߪ��B */
				strcat(prtstr,"+");
				buf1[0]='\0';
				rfmtlong(sum_all,"&&&&&&&&&&&&",buf1);
				strncat(prtstr, "000000000000" ,12);
				/*strncat(prtstr,(buf1[0]=='\0') ? "000000000000" : buf1,12);*/
				prtstr[483]='\0';
				
				tot_sum_all+=sum_all;
				
				strcpy(t_istl_class,"B00");
				t_mcoverage = mcoverage;
				t_victim_num = victim_num;
				t_mapp_cover = sum_mapp_cover;
				t_mins_stl = 0;
				t_mins_proc = 0;
				t_mstl_health = 0;
				t_qhealth = 0;
				t_mhealth = 0;
				t_sum_all = 0;
				
				/* 484-495 �ӫ~�N�X */
				strcat(prtstr,iproduct);
				strcpy(t_iproduct,iproduct);
				prtstr[495]='\0';
				
				strncpy(iproduct_tmp,iproduct+3,2);
				iproduct_tmp[2] = '\0';
				if (strcmp(iproduct_tmp,"14") == 0) 
				{
					mprem_14 += sum_mapp_cover;
					mhealth_14 += 0;
				}
				else if (strcmp(iproduct_tmp,"15") == 0) 
				{
					mprem_15 += sum_mapp_cover;
					mhealth_15 += 0;
				}
				else if (strcmp(iproduct_tmp,"16") == 0) 
				{
					mprem_16 += sum_mapp_cover;
					mhealth_16 += 0;
				}
				else if (strcmp(iproduct_tmp,"32") == 0) 
				{
					mprem_32 += sum_mapp_cover;
					mhealth_32 += 0;
				}
				
				/* 496-503 �ߥI/�l�v��� */
				strncat(prtstr, "00000000", 8);
				prtstr[503]='\0';
				
				/* 504-505 �q���O�N�� */
				strcat(prtstr,bzfrom);
				strcpy(t_bzfrom,bzfrom);
				prtstr[505]= '\0';
				
				/* 505-513 ��ƻs�e���*/
				strcat(prtstr,ttday_yy);
				strcat(prtstr,ttday_mm);
				strcat(prtstr,ttday_dd);
				strcpy(t_dsend,ttday_yy);
				strcat(t_dsend,ttday_mm);
				strcat(t_dsend,ttday_dd);
				prtstr[513]='\0';
	
				count1++;
				pel_cnt_B = 1;
				
				fprintf(fptr,"%s\n",prtstr);
				
				printf("data_yyyymm[%s],t_fend_yn[%s],t_fstl[%s],t_istl_recover[%s],t_ihealth[%s],t_dclaim[%s],t_iclm_company[%s],t_iclm_br[%s],t_iclaim[%s],t_iclose_type[%d],t_istl_flag[%s] \n",
		                data_yyyymm,t_fend_yn,t_fstl,t_istl_recover,t_ihealth,t_dclaim,t_iclm_company,t_iclm_br,t_iclaim,t_iclose_type,t_istl_flag);
				printf("t_dgroup[%s],t_icard_company[%s],t_icard_br[%s],t_icard[%s],t_dply_begin[%s],t_dply_end[%s],t_iarea[%s],t_iobjno[%s],t_iissue_year[%s],t_ipro_year[%s] \n",
				        t_dgroup,t_icard_company,t_icard_br,t_icard,t_dply_begin,t_dply_end,t_iarea,t_iobjno,t_iissue_year,t_ipro_year);
				printf("t_ioth_fassured[%s],t_ioth_cartype[%s],t_ioth_qpt[%d],t_ioth_fpt[%s],t_ioth_tag[%s],t_ioth_comp_yn[%s],t_ioth_card_company[%s],t_ioth_card[%s] \n",
				        t_ioth_fassured,t_ioth_cartype,t_ioth_qpt,t_ioth_fpt,t_ioth_tag,t_ioth_comp_yn,t_ioth_card_company,t_ioth_card);
				printf("t_fcomp_class[%s],t_qdrunk_driving[%d],t_mins_premium[%d],t_madjcom_prem[%f],t_mbusiness[%f],t_maintain[%f],t_mcompensation[%f],t_mstable[%f],t_mdrunk_prem[%d],t_mdrunk_pure_prem[%f],t_drate_ym[%s] \n",
				        t_fcomp_class,t_qdrunk_driving,t_mins_premium,t_madjcom_prem,t_mbusiness,t_maintain,t_mcompensation,t_mstable,t_mdrunk_prem,t_mdrunk_pure_prem,t_drate_ym);
				printf("t_fassured[%s],t_iassured[%s],t_dbirth[%s],t_fsex[%s],t_fmarriage[%s],t_facc_nation[%s],t_iacc_license[%s],t_iacc_birth[%s],t_facc_sex[%s],t_facc_marri[%s],t_facc_rel[%s] \n",
				        t_fassured,t_iassured,t_dbirth,t_fsex,t_fmarriage,t_facc_nation,t_iacc_license,t_iacc_birth,t_facc_sex,t_facc_marri,t_facc_rel);
				printf("t_iacc_reason[%s],t_facc_duty[%s],t_fsubrogation[%s],t_iself_duty[%d],t_ioth_duty[%d],t_ianoth_duty[%d] \n",
				        t_iacc_reason,t_facc_duty,t_fsubrogation,t_iself_duty,t_ioth_duty,t_ianoth_duty);
				printf("t_qacar_death[%d],t_qacar_cripple[%d],t_qacar_injure[%d],t_qbcar_death[%d],t_qbcar_cripple[%d],t_qbcar_injure[%d],t_qccar_death[%d],t_qccar_cripple[%d],t_qccar_injure[%d] \n",
				        t_qacar_death,t_qacar_cripple,t_qacar_injure,t_qbcar_death,t_qbcar_cripple,t_qbcar_injure,t_qccar_death,t_qccar_cripple,t_qccar_injure);
				printf("t_daccident[%s],t_iacc_area[%s],t_istl_class[%s],t_mcoverage[%d],t_victim_num[%d],t_mapp_cover[%d],t_mins_stl[%d],t_mins_proc[%d],t_mstl_health[%d],t_qhealth[%d],t_mhealth[%d],t_sum_all[%d] \n",
				        t_daccident,t_iacc_area,t_istl_class,t_mcoverage,t_victim_num,t_mapp_cover,t_mins_stl,t_mins_proc,t_mstl_health,t_qhealth,t_mhealth,t_sum_all);
				printf("t_iproduct[%s],t_bzfrom[%s],t_dsend[%s] \n",
				        t_iproduct,t_bzfrom,t_dsend);
				/* �d�s��� */
				sprintf_s(stmt,5120,"INSERT INTO %s:ca_dev_clm_comp \
				                     (data_yyyymm,idata,fend_yn,fstl,istl_recover,ihealth,dclaim,iclm_company,iclm_br,iclaim,iclose_type,istl_flag, \
				                      dgroup,icard_company,icard_br,icard,dply_begin,dply_end,iarea,iobjno,iissue_year,ipro_year, \
				                      ibrand,icar_type,icar_type_no,qcylinder,iengine,itag,qpt,fpt, \
				                      ioth_fassured,ioth_cartype,ioth_qpt,ioth_fpt,ioth_tag,ioth_comp_yn,ioth_card_company,ioth_card, \
				                      fcomp_class,qdrunk_driving,mins_premium,madjcom_prem,mbusiness,maintain,mcompensation,mstable,mdrunk_prem,mdrunk_pure_prem,drate_ym, \
				                      fassured,iassured,dbirth,fsex,fmarriage,facc_nation,iacc_license,iacc_birth,facc_sex,facc_marri,facc_rel, \
				                      iacc_reason,facc_duty,fsubrogation,iself_duty,ioth_duty,ianoth_duty, \
				                      qacar_death,qacar_cripple,qacar_injure,qbcar_death,qbcar_cripple,qbcar_injure,qccar_death,qccar_cripple,qccar_injure, \
				                      daccident,iacc_area,istl_class,mcoverage,victim_num,mapp_cover,mins_stl,mins_proc,mstl_health,qhealth,mhealth,sum_all, \
				                      iproduct,bzfrom,dsend) \
				               VALUES(?,'U',?,?,?,?,?,?,?,?,?,?, \
				                      ?,?,?,?,?,?,?,?,?,?, \
				                      ?,?,?,?,?,?,?,?, \
				                      ?,?,?,?,?,?,?,?, \
				                      ?,?,?,?,?,?,?,?,?,?,?, \
				                      ?,?,?,?,?,?,?,?,?,?,?, \
				                      ?,?,?,?,?,?, \
				                      ?,?,?,?,?,?,?,?,?, \
				                      ?,?,?,?,?,?,?,?,?,?,?,?, \
				                      ?,?,?)",list[k].dbname);
				$PREPARE insert_ply_edr FROM $stmt;
				$EXECUTE insert_ply_edr using $data_yyyymm,$t_fend_yn,$t_fstl,$t_istl_recover,$t_ihealth,$t_dclaim,$t_iclm_company,$t_iclm_br,$t_iclaim,$t_iclose_type,$t_istl_flag,
				                              $t_dgroup,$t_icard_company,$t_icard_br,$t_icard,$t_dply_begin,$t_dply_end,$t_iarea,$t_iobjno,$t_iissue_year,$t_ipro_year,
				                              $t_ibrand,$t_icar_type,$t_icar_type_no,$t_qcylinder,$t_iengine,$t_itag,$t_qpt,$t_fpt,
				                              $t_ioth_fassured,$t_ioth_cartype,$t_ioth_qpt,$t_ioth_fpt,$t_ioth_tag,$t_ioth_comp_yn,$t_ioth_card_company,$t_ioth_card,
				                              $t_fcomp_class,$t_qdrunk_driving,$t_mins_premium,$t_madjcom_prem,$t_mbusiness,$t_maintain,$t_mcompensation,$t_mstable,$t_mdrunk_prem,$t_mdrunk_pure_prem,$t_drate_ym,
				                              $t_fassured,$t_iassured,$t_dbirth,$t_fsex,$t_fmarriage,$t_facc_nation,$t_iacc_license,$t_iacc_birth,$t_facc_sex,$t_facc_marri,$t_facc_rel,
				                              $t_iacc_reason,$t_facc_duty,$t_fsubrogation,$t_iself_duty,$t_ioth_duty,$t_ianoth_duty,
				                              $t_qacar_death,$t_qacar_cripple,$t_qacar_injure,$t_qbcar_death,$t_qbcar_cripple,$t_qbcar_injure,$t_qccar_death,$t_qccar_cripple,$t_qccar_injure,
				                              $t_daccident,$t_iacc_area,$t_istl_class,$t_mcoverage,$t_victim_num,$t_mapp_cover,$t_mins_stl,$t_mins_proc,$t_mstl_health,$t_qhealth,$t_mhealth,$t_sum_all,
			                              	  $t_iproduct,$t_bzfrom,$t_dsend;
			} /* end of B00 */
	         
			/******** ���I���O�N�� = C **********/
			tot_pel_cnt_C00 = 0;
			tot_sum_mapp_cover_C00 = 0;
			sum_mapp_cover = 0;
			pel_cnt = 0;
			pel_cnt_C = 0;
			mcoverage_C00=0;
			
			/*** ���H���I�I�ج���¦ ***/
			sprintf_s(stmt,5120,"SELECT DISTINCT iins_item \
			                FROM %s:ca_app_victim \
			               WHERE iclaim = '%s' \
			                 AND iins_item[1,1] = 'C' \
			               ORDER BY iins_item ",list[k].dbname,iclaim);
			$PREPARE car9994_2_tmp FROM $stmt;
			$DECLARE car9994_2 CURSOR FOR car9994_2_tmp;
			$OPEN car9994_2;
			while (1)
			{
				$FETCH car9994_2 INTO :iins_item;
				if (SQLCODE == SQLNOTFOUND) break;
				
				sum_mins_stl = sum_mins_proc = sum_mstl_health = 0;
				sum_all = 0;
				flast[0] = '\0';
				fflast[0] = '\0';
				tmp_mapp_cover = 0;
				mapp_cover_tot = 0;
				sum_mapp_cover = 0;
				
				/**** �����M���B ****/
				sprintf_s(stmt,5120,"SELECT ivictim , (mapp_cover+mapp_fee) , mcoverage \
				                FROM %s:ca_app_victim \
				               WHERE iclaim    = '%s' \
				                 AND iins_item = '%s' ",list[k].dbname,iclaim,iins_item);

				$PREPARE car9994_C00_tmp FROM $stmt;
				$DECLARE car9994_C00 CURSOR FOR car9994_C00_tmp;
				$OPEN car9994_C00;
				while(1)
				{
					$FETCH car9994_C00 INTO :victim, :tmp_mapp_cover, :mcoverage;
					if (SQLCODE == SQLNOTFOUND) break;
					
					sprintf_s(stmt,5120,"SELECT First 1 dappraisal,mapp_cover+mapp_fee \
					                FROM %s:ca_app_victim_hist \
					               WHERE iclaim = '%s' \
					                 AND iins_item = '%s' \
					                 AND ivictim = '%s' \
					                 AND dappraisal < %ld \
					               ORDER BY dappraisal Desc",list[k].dbname,iclaim,iins_item,victim,enddate_l);
					$PREPARE hist_clm_C FROM $stmt;
					$EXECUTE hist_clm_C into $tmp_dappraisal, $tmp_mapp_cover;
					if(SQLCODE == SQLNOTFOUND) continue;
					
					sprintf_s(stmt,5120,"SELECT SUM(mins_stl), SUM(mins_proc), SUM(mstl_health), \
					                     SUM(DECODE(fstl,'1',mins_stl,mins_stl*(-1))+mins_proc) , \
					                     MAX(flast) \
					                FROM %s:ca_stl_victim  \
					               WHERE iclaim    = '%s' \
					                 AND iins_item = '%s' \
					                 AND ivictim   = '%s' \
					                 AND dgroup    <  %ld ",list[k].dbname,iclaim,iins_item,victim,enddate_l);
					            
					$PREPARE car9994_stl_C FROM $stmt;
					$EXECUTE car9994_stl_C INTO $sum_mins_stl:id2,$sum_mins_proc:id3,
					                            $sum_mstl_health:id4,
					                            $sum_all:id5 , $flast:id6;
					
					if(id2==-1) sum_mins_stl = 0;
					if(id3==-1) sum_mins_proc = 0;
					if(id4==-1) sum_mins_health = 0;
					if(id5==-1) sum_all = 0;
					/* if(id6==-1) flast[0] = '0' ; */
					
					/*** �̫�@�����O,���׬O�_���K�� ***/
					if (flast[0] == '1' || flast[0] == '2')
					continue;
					
					/** �ݼo �O�B���i�� 0 **/
					if (mcoverage == 0)
					{
						cxx=atoi(substring(iins_item,2,2));
						if (tmp_dappraisal >= 38411) mcoverage=mcover_C2[cxx];
						else mcoverage=mcover_C1[cxx];
					}
					mapp_cover_tot = tmp_mapp_cover - sum_all;
					
					if (mapp_cover_tot < 0) mapp_cover_tot = 0;
					
					sum_mapp_cover += mapp_cover_tot;
					pel_cnt ++;
				}
				$CLOSE car9994_C00;
				$FREE  car9994_C00;
	               
				if (pel_cnt > 0)
				{
					mcoverage=mcoverageBC;
					if( mcoverage > mcoverage_C00 )
					mcoverage_C00 = mcoverage;
					
					strcpy(prtstr,prtstr_1to25);
					
					/* 389-391 ���I���O�N�� */
					strncat(prtstr,(iins_item[0]=='\0') ? "C01" : iins_item,3 );
					prtstr[391]='\0';
					
					/* 392-400 �C�H�O�I���B */
					if( mcoverage == 0 )
					mcoverage = mcoverage_C00;
					strcat(prtstr,"+");
					buf1[0]='\0';
					rfmtlong(mcoverage,"&&&&&&&&",buf1);
					strncat(prtstr,(buf1[0]=='\0') ? "00000000" : buf1,8);
					prtstr[400]='\0';
					tot_mcoverage+=mcoverage;
					
					/* 401-404 �z�ߤH�� */
					buf1[0]='\0';
					rfmtlong(pel_cnt,"&&&&",buf1);
					strncat(prtstr,(buf1[0]=='\0') ? "0000" : buf1,4);
					prtstr[404]='\0';
					tot_pel_cnt+=pel_cnt;
					tot_pel_cnt_C00+=pel_cnt;
					
					/* 405-417 �w���l�����B */
					strcat(prtstr,"+");
					buf1[0]='\0';
					rfmtlong(sum_mapp_cover,"&&&&&&&&&&&&",buf1);
					strncat(prtstr,(buf1[0]=='\0') ? "000000000000" : buf1,12);
					prtstr[417]='\0';
					
					tot_sum_mapp_cover+=sum_mapp_cover;
					tot_sum_mapp_cover_C00+=sum_mapp_cover;
					
					/* 418-430 ���t�ثO�z�ߪ��B */
					strcat(prtstr,"+");
					buf1[0]='\0';
					rfmtlong(sum_mins_stl,"&&&&&&&&&&&&",buf1);
					strncat(prtstr, "000000000000",12 );
					prtstr[430]='\0';
					tot_sum_mins_stl+=sum_mins_stl;
					tot_sum_mins_stl_C00+=sum_mins_stl;
					
					/* 431-441 �z�߶O�� */
					strcat(prtstr,"+");
					buf1[0]='\0';
					rfmtlong(sum_mins_proc,"&&&&&&&&&&",buf1);
					strncat(prtstr, "0000000000",10 );
					prtstr[441]='\0';
					
					tot_sum_mins_proc+=sum_mins_proc;
					tot_sum_mins_proc_C00+=sum_mins_proc;
					
					/* 442-452 ���I���O���B */
					strcat(prtstr,"+");
					buf1[0]='\0';
					rfmtlong(sum_mins_health,"&&&&&&&&&&",buf1);
					strcat(prtstr, "0000000000" );
					prtstr[452]='\0';
					
					tot_sum_mins_health+=sum_mins_health;
					tot_sum_mins_health_C00+=sum_mins_health;
					
					/* 453-461 ���O�I�� */
					strcat(prtstr,"+");
					buf1[0]='\0';
					strncat(prtstr,  "00000000"  ,8);
					prtstr[461]='\0';
					
					/* 462-470 ���O���B */
					strcat(prtstr,"+");
					buf1[0]='\0';
					strncat(prtstr,  "00000000"  ,8);
					prtstr[470]='\0';
					
					/* 471-483 ��ڲz�ߪ��B */
					strcat(prtstr,"+");
					buf1[0]='\0';
					rfmtlong(sum_all,"&&&&&&&&&&&&",buf1);
					/*strcat(prtstr,(buf1[0]=='\0') ? "000000000000" : buf1); */
					strcat(prtstr, "000000000000" );
					prtstr[483]='\0';
					
					tot_sum_all+=sum_all;
					tot_sum_all_C00+=sum_all;
					
					strcpy(t_istl_class,iins_item);
					t_mcoverage = mcoverage;
					t_victim_num = pel_cnt;
					t_mapp_cover = sum_mapp_cover;
					t_mins_stl = 0;
					t_mins_proc = 0;
					t_mstl_health = 0;
					t_qhealth = 0;
					t_mhealth = 0;
					t_sum_all = 0;
					
					/* 484-495 �ӫ~�N�X */
					strcat(prtstr,iproduct);
					strcpy(t_iproduct,iproduct);
					prtstr[495]='\0';
					
					strncpy(iproduct_tmp,iproduct+3,2);
					iproduct_tmp[2] = '\0';
					if (strcmp(iproduct_tmp,"14") == 0) 
					{
						mprem_14 += sum_mapp_cover;
						mhealth_14 += 0;
					}
					else if (strcmp(iproduct_tmp,"15") == 0) 
					{
						mprem_15 += sum_mapp_cover;
						mhealth_15 += 0;
					}
					else if (strcmp(iproduct_tmp,"16") == 0) 
					{
						mprem_16 += sum_mapp_cover;
						mhealth_16 += 0;
					}
					else if (strcmp(iproduct_tmp,"32") == 0) 
					{
						mprem_32 += sum_mapp_cover;
						mhealth_32 += 0;
					}
				
					/* 496-503 �ߥI/�l�v��� */
					strncat(prtstr, "00000000", 8);
					prtstr[503]='\0';
					
					/* 504-505 �q���O�N��*/
					strcat(prtstr,bzfrom);
					strcpy(t_bzfrom,bzfrom);
					prtstr[505]= '\0';
					
					/* 506-513 ��ƻs�e���*/
					strcat(prtstr,ttday_yy);
					strcat(prtstr,ttday_mm);
					strcat(prtstr,ttday_dd);
					strcpy(t_dsend,ttday_yy);
					strcat(t_dsend,ttday_mm);
					strcat(t_dsend,ttday_dd);
					prtstr[513]='\0';
					count1++;
					pel_cnt_C = 1;
					fprintf(fptr,"%s\n",prtstr);
					
					printf("data_yyyymm[%s],t_fend_yn[%s],t_fstl[%s],t_istl_recover[%s],t_ihealth[%s],t_dclaim[%s],t_iclm_company[%s],t_iclm_br[%s],t_iclaim[%s],t_iclose_type[%d],t_istl_flag[%s] \n",
			                data_yyyymm,t_fend_yn,t_fstl,t_istl_recover,t_ihealth,t_dclaim,t_iclm_company,t_iclm_br,t_iclaim,t_iclose_type,t_istl_flag);
					printf("t_dgroup[%s],t_icard_company[%s],t_icard_br[%s],t_icard[%s],t_dply_begin[%s],t_dply_end[%s],t_iarea[%s],t_iobjno[%s],t_iissue_year[%s],t_ipro_year[%s] \n",
					        t_dgroup,t_icard_company,t_icard_br,t_icard,t_dply_begin,t_dply_end,t_iarea,t_iobjno,t_iissue_year,t_ipro_year);
					printf("t_ioth_fassured[%s],t_ioth_cartype[%s],t_ioth_qpt[%d],t_ioth_fpt[%s],t_ioth_tag[%s],t_ioth_comp_yn[%s],t_ioth_card_company[%s],t_ioth_card[%s] \n",
					        t_ioth_fassured,t_ioth_cartype,t_ioth_qpt,t_ioth_fpt,t_ioth_tag,t_ioth_comp_yn,t_ioth_card_company,t_ioth_card);
					printf("t_fcomp_class[%s],t_qdrunk_driving[%d],t_mins_premium[%d],t_madjcom_prem[%f],t_mbusiness[%f],t_maintain[%f],t_mcompensation[%f],t_mstable[%f],t_mdrunk_prem[%d],t_mdrunk_pure_prem[%f],t_drate_ym[%s] \n",
					        t_fcomp_class,t_qdrunk_driving,t_mins_premium,t_madjcom_prem,t_mbusiness,t_maintain,t_mcompensation,t_mstable,t_mdrunk_prem,t_mdrunk_pure_prem,t_drate_ym);
					printf("t_fassured[%s],t_iassured[%s],t_dbirth[%s],t_fsex[%s],t_fmarriage[%s],t_facc_nation[%s],t_iacc_license[%s],t_iacc_birth[%s],t_facc_sex[%s],t_facc_marri[%s],t_facc_rel[%s] \n",
					        t_fassured,t_iassured,t_dbirth,t_fsex,t_fmarriage,t_facc_nation,t_iacc_license,t_iacc_birth,t_facc_sex,t_facc_marri,t_facc_rel);
					printf("t_iacc_reason[%s],t_facc_duty[%s],t_fsubrogation[%s],t_iself_duty[%d],t_ioth_duty[%d],t_ianoth_duty[%d] \n",
					        t_iacc_reason,t_facc_duty,t_fsubrogation,t_iself_duty,t_ioth_duty,t_ianoth_duty);
					printf("t_qacar_death[%d],t_qacar_cripple[%d],t_qacar_injure[%d],t_qbcar_death[%d],t_qbcar_cripple[%d],t_qbcar_injure[%d],t_qccar_death[%d],t_qccar_cripple[%d],t_qccar_injure[%d] \n",
					        t_qacar_death,t_qacar_cripple,t_qacar_injure,t_qbcar_death,t_qbcar_cripple,t_qbcar_injure,t_qccar_death,t_qccar_cripple,t_qccar_injure);
					printf("t_daccident[%s],t_iacc_area[%s],t_istl_class[%s],t_mcoverage[%d],t_victim_num[%d],t_mapp_cover[%d],t_mins_stl[%d],t_mins_proc[%d],t_mstl_health[%d],t_qhealth[%d],t_mhealth[%d],t_sum_all[%d] \n",
					        t_daccident,t_iacc_area,t_istl_class,t_mcoverage,t_victim_num,t_mapp_cover,t_mins_stl,t_mins_proc,t_mstl_health,t_qhealth,t_mhealth,t_sum_all);
					printf("t_iproduct[%s],t_bzfrom[%s],t_dsend[%s] \n",
					        t_iproduct,t_bzfrom,t_dsend);
					/* �d�s��� */
					sprintf_s(stmt,5120,"INSERT INTO %s:ca_dev_clm_comp \
					                     (data_yyyymm,idata,fend_yn,fstl,istl_recover,ihealth,dclaim,iclm_company,iclm_br,iclaim,iclose_type,istl_flag, \
					                      dgroup,icard_company,icard_br,icard,dply_begin,dply_end,iarea,iobjno,iissue_year,ipro_year, \
					                      ibrand,icar_type,icar_type_no,qcylinder,iengine,itag,qpt,fpt, \
					                      ioth_fassured,ioth_cartype,ioth_qpt,ioth_fpt,ioth_tag,ioth_comp_yn,ioth_card_company,ioth_card, \
					                      fcomp_class,qdrunk_driving,mins_premium,madjcom_prem,mbusiness,maintain,mcompensation,mstable,mdrunk_prem,mdrunk_pure_prem,drate_ym, \
					                      fassured,iassured,dbirth,fsex,fmarriage,facc_nation,iacc_license,iacc_birth,facc_sex,facc_marri,facc_rel, \
					                      iacc_reason,facc_duty,fsubrogation,iself_duty,ioth_duty,ianoth_duty, \
					                      qacar_death,qacar_cripple,qacar_injure,qbcar_death,qbcar_cripple,qbcar_injure,qccar_death,qccar_cripple,qccar_injure, \
					                      daccident,iacc_area,istl_class,mcoverage,victim_num,mapp_cover,mins_stl,mins_proc,mstl_health,qhealth,mhealth,sum_all, \
					                      iproduct,bzfrom,dsend) \
					               VALUES(?,'U',?,?,?,?,?,?,?,?,?,?, \
					                      ?,?,?,?,?,?,?,?,?,?, \
					                      ?,?,?,?,?,?,?,?, \
					                      ?,?,?,?,?,?,?,?, \
					                      ?,?,?,?,?,?,?,?,?,?,?, \
					                      ?,?,?,?,?,?,?,?,?,?,?, \
					                      ?,?,?,?,?,?, \
					                      ?,?,?,?,?,?,?,?,?, \
					                      ?,?,?,?,?,?,?,?,?,?,?,?, \
					                      ?,?,?)",list[k].dbname);
					$PREPARE insert_ply_edr FROM $stmt;
					$EXECUTE insert_ply_edr using $data_yyyymm,$t_fend_yn,$t_fstl,$t_istl_recover,$t_ihealth,$t_dclaim,$t_iclm_company,$t_iclm_br,$t_iclaim,$t_iclose_type,$t_istl_flag,
					                              $t_dgroup,$t_icard_company,$t_icard_br,$t_icard,$t_dply_begin,$t_dply_end,$t_iarea,$t_iobjno,$t_iissue_year,$t_ipro_year,
					                              $t_ibrand,$t_icar_type,$t_icar_type_no,$t_qcylinder,$t_iengine,$t_itag,$t_qpt,$t_fpt,
					                              $t_ioth_fassured,$t_ioth_cartype,$t_ioth_qpt,$t_ioth_fpt,$t_ioth_tag,$t_ioth_comp_yn,$t_ioth_card_company,$t_ioth_card,
					                              $t_fcomp_class,$t_qdrunk_driving,$t_mins_premium,$t_madjcom_prem,$t_mbusiness,$t_maintain,$t_mcompensation,$t_mstable,$t_mdrunk_prem,$t_mdrunk_pure_prem,$t_drate_ym,
					                              $t_fassured,$t_iassured,$t_dbirth,$t_fsex,$t_fmarriage,$t_facc_nation,$t_iacc_license,$t_iacc_birth,$t_facc_sex,$t_facc_marri,$t_facc_rel,
					                              $t_iacc_reason,$t_facc_duty,$t_fsubrogation,$t_iself_duty,$t_ioth_duty,$t_ianoth_duty,
					                              $t_qacar_death,$t_qacar_cripple,$t_qacar_injure,$t_qbcar_death,$t_qbcar_cripple,$t_qbcar_injure,$t_qccar_death,$t_qccar_cripple,$t_qccar_injure,
					                              $t_daccident,$t_iacc_area,$t_istl_class,$t_mcoverage,$t_victim_num,$t_mapp_cover,$t_mins_stl,$t_mins_proc,$t_mstl_health,$t_qhealth,$t_mhealth,$t_sum_all,
				                              	  $t_iproduct,$t_bzfrom,$t_dsend;
				}
			}
			$CLOSE car9994_2;
			$FREE car9994_2;
	
			/*C00*/
			if (tot_pel_cnt_C00 > 0)
			{
				/* 389-391 ���I���O�N�� */
				strcpy(prtstr,prtstr_1to25);
				strncat(prtstr,"C00",3 );
				prtstr[391]='\0';
				
				/* 392-400 �C�H�O�I���B */
				strcat(prtstr,"+");
				buf1[0]='\0';
				mcoverage = mcoverage_C00;
				rfmtlong(mcoverage,"&&&&&&&&",buf1);
				strncat(prtstr,(buf1[0]=='\0') ? "00000000" : buf1,8);
				prtstr[400]='\0';
				
				/* 401-404 �z�ߤH��*/
				buf1[0]='\0';
				rfmtlong(tot_pel_cnt_C00,"&&&&",buf1);
				strncat(prtstr,(buf1[0]=='\0') ? "0000" : buf1,4);
				prtstr[404]='\0';
				
				/* 405-417 �w���l�����B */
				strcat(prtstr,"+");
				buf1[0]='\0';
				rfmtlong(tot_sum_mapp_cover_C00,"&&&&&&&&&&&&",buf1);
				strncat(prtstr,(buf1[0]=='\0') ? "000000000000" : buf1,12);
				prtstr[417]='\0';
				
				/* 418-430 ���t�ثO�z�ߪ��B */
				strcat(prtstr,"+");
				buf1[0]='\0';
				rfmtlong(tot_sum_mins_stl_C00,"&&&&&&&&&&&&",buf1);
				/*strncat(prtstr,(buf1[0]=='\0') ? "000000000000" : buf1,12); */
				strncat(prtstr, "000000000000" ,12);
				prtstr[430]='\0';
				
				/* 431-441 �z�߶O�� */
				strcat(prtstr,"+");
				buf1[0]='\0';
				rfmtlong(tot_sum_mins_proc_C00,"&&&&&&&&&&",buf1);
				/*strncat(prtstr,(buf1[0]=='\0') ? "0000000000" : buf1,10); */
				strncat(prtstr, "0000000000" ,10);
				prtstr[441]='\0';
				
				/* 442-452 ���I���O���B */
				strcat(prtstr,"+");
				buf1[0]='\0';
				rfmtlong(tot_sum_mins_health_C00,"&&&&&&&&&&",buf1);
				/*strncat(prtstr,(buf1[0]=='\0') ? "0000000000" : buf1,10); */
				strncat(prtstr, "0000000000" ,10);
				prtstr[452]='\0';
				
				/* 453-461 ���O�I�� */
				strcat(prtstr,"+");
				buf1[0]='\0';
				strncat(prtstr,  "00000000"  ,8);
				prtstr[461]='\0';
				
				/* 462-470 ���O���B */
				strcat(prtstr,"+");
				buf1[0]='\0';
				strncat(prtstr,  "00000000"  ,8);
				prtstr[470]='\0';
				
				/* 471-483 ��ڲz�ߪ��B */
				strcat(prtstr,"+");
				buf1[0]='\0';
				rfmtlong(tot_sum_all_C00,"&&&&&&&&&&&&",buf1);
				/*strncat(prtstr,(buf1[0]=='\0') ? "000000000000" : buf1,12); */
				strncat(prtstr, "000000000000" ,12);
				prtstr[483]='\0';
				
				strcpy(t_istl_class,"C00");
				t_mcoverage = mcoverage;
				t_victim_num = tot_pel_cnt_C00;
				t_mapp_cover = tot_sum_mapp_cover_C00;
				t_mins_stl = 0;
				t_mins_proc = 0;
				t_mstl_health = 0;
				t_qhealth = 0;
				t_mhealth = 0;
				t_sum_all = 0;
				
				/* 484-4-495 �ӫ~�N�X */
				strcat(prtstr,iproduct);
				strcpy(t_iproduct,iproduct);
				prtstr[495]='\0';
				
				/* 496-503 �ߥI/�l�v���*/			
				strncat(prtstr,"00000000",8);
				prtstr[503]='\0';
				
				/* 504-505 �q���O�N��*/
				strcat(prtstr,bzfrom);
				strcpy(t_bzfrom,bzfrom);
				prtstr[505]= '\0';
				
				/* 506-513 ��ƻs�e���*/
				strcat(prtstr,ttday_yy);
				strcat(prtstr,ttday_mm);
				strcat(prtstr,ttday_dd);
				strcpy(t_dsend,ttday_yy);
				strcat(t_dsend,ttday_mm);
				strcat(t_dsend,ttday_dd);
				prtstr[513]='\0';
	
				count1++;
				fprintf(fptr,"%s\n",prtstr);
				
				printf("data_yyyymm[%s],t_fend_yn[%s],t_fstl[%s],t_istl_recover[%s],t_ihealth[%s],t_dclaim[%s],t_iclm_company[%s],t_iclm_br[%s],t_iclaim[%s],t_iclose_type[%d],t_istl_flag[%s] \n",
			            data_yyyymm,t_fend_yn,t_fstl,t_istl_recover,t_ihealth,t_dclaim,t_iclm_company,t_iclm_br,t_iclaim,t_iclose_type,t_istl_flag);
				printf("t_dgroup[%s],t_icard_company[%s],t_icard_br[%s],t_icard[%s],t_dply_begin[%s],t_dply_end[%s],t_iarea[%s],t_iobjno[%s],t_iissue_year[%s],t_ipro_year[%s] \n",
				        t_dgroup,t_icard_company,t_icard_br,t_icard,t_dply_begin,t_dply_end,t_iarea,t_iobjno,t_iissue_year,t_ipro_year);
				printf("t_ioth_fassured[%s],t_ioth_cartype[%s],t_ioth_qpt[%d],t_ioth_fpt[%s],t_ioth_tag[%s],t_ioth_comp_yn[%s],t_ioth_card_company[%s],t_ioth_card[%s] \n",
				        t_ioth_fassured,t_ioth_cartype,t_ioth_qpt,t_ioth_fpt,t_ioth_tag,t_ioth_comp_yn,t_ioth_card_company,t_ioth_card);
				printf("t_fcomp_class[%s],t_qdrunk_driving[%d],t_mins_premium[%d],t_madjcom_prem[%f],t_mbusiness[%f],t_maintain[%f],t_mcompensation[%f],t_mstable[%f],t_mdrunk_prem[%d],t_mdrunk_pure_prem[%f],t_drate_ym[%s] \n",
				        t_fcomp_class,t_qdrunk_driving,t_mins_premium,t_madjcom_prem,t_mbusiness,t_maintain,t_mcompensation,t_mstable,t_mdrunk_prem,t_mdrunk_pure_prem,t_drate_ym);
				printf("t_fassured[%s],t_iassured[%s],t_dbirth[%s],t_fsex[%s],t_fmarriage[%s],t_facc_nation[%s],t_iacc_license[%s],t_iacc_birth[%s],t_facc_sex[%s],t_facc_marri[%s],t_facc_rel[%s] \n",
				        t_fassured,t_iassured,t_dbirth,t_fsex,t_fmarriage,t_facc_nation,t_iacc_license,t_iacc_birth,t_facc_sex,t_facc_marri,t_facc_rel);
				printf("t_iacc_reason[%s],t_facc_duty[%s],t_fsubrogation[%s],t_iself_duty[%d],t_ioth_duty[%d],t_ianoth_duty[%d] \n",
				        t_iacc_reason,t_facc_duty,t_fsubrogation,t_iself_duty,t_ioth_duty,t_ianoth_duty);
				printf("t_qacar_death[%d],t_qacar_cripple[%d],t_qacar_injure[%d],t_qbcar_death[%d],t_qbcar_cripple[%d],t_qbcar_injure[%d],t_qccar_death[%d],t_qccar_cripple[%d],t_qccar_injure[%d] \n",
				        t_qacar_death,t_qacar_cripple,t_qacar_injure,t_qbcar_death,t_qbcar_cripple,t_qbcar_injure,t_qccar_death,t_qccar_cripple,t_qccar_injure);
				printf("t_daccident[%s],t_iacc_area[%s],t_istl_class[%s],t_mcoverage[%d],t_victim_num[%d],t_mapp_cover[%d],t_mins_stl[%d],t_mins_proc[%d],t_mstl_health[%d],t_qhealth[%d],t_mhealth[%d],t_sum_all[%d] \n",
				        t_daccident,t_iacc_area,t_istl_class,t_mcoverage,t_victim_num,t_mapp_cover,t_mins_stl,t_mins_proc,t_mstl_health,t_qhealth,t_mhealth,t_sum_all);
				printf("t_iproduct[%s],t_bzfrom[%s],t_dsend[%s] \n",
				        t_iproduct,t_bzfrom,t_dsend);
				/* �d�s��� */
				sprintf_s(stmt,5120,"INSERT INTO %s:ca_dev_clm_comp \
				                     (data_yyyymm,idata,fend_yn,fstl,istl_recover,ihealth,dclaim,iclm_company,iclm_br,iclaim,iclose_type,istl_flag, \
				                      dgroup,icard_company,icard_br,icard,dply_begin,dply_end,iarea,iobjno,iissue_year,ipro_year, \
				                      ibrand,icar_type,icar_type_no,qcylinder,iengine,itag,qpt,fpt, \
				                      ioth_fassured,ioth_cartype,ioth_qpt,ioth_fpt,ioth_tag,ioth_comp_yn,ioth_card_company,ioth_card, \
				                      fcomp_class,qdrunk_driving,mins_premium,madjcom_prem,mbusiness,maintain,mcompensation,mstable,mdrunk_prem,mdrunk_pure_prem,drate_ym, \
				                      fassured,iassured,dbirth,fsex,fmarriage,facc_nation,iacc_license,iacc_birth,facc_sex,facc_marri,facc_rel, \
				                      iacc_reason,facc_duty,fsubrogation,iself_duty,ioth_duty,ianoth_duty, \
				                      qacar_death,qacar_cripple,qacar_injure,qbcar_death,qbcar_cripple,qbcar_injure,qccar_death,qccar_cripple,qccar_injure, \
				                      daccident,iacc_area,istl_class,mcoverage,victim_num,mapp_cover,mins_stl,mins_proc,mstl_health,qhealth,mhealth,sum_all, \
				                      iproduct,bzfrom,dsend) \
				               VALUES(?,'U',?,?,?,?,?,?,?,?,?,?, \
				                      ?,?,?,?,?,?,?,?,?,?, \
				                      ?,?,?,?,?,?,?,?, \
				                      ?,?,?,?,?,?,?,?, \
				                      ?,?,?,?,?,?,?,?,?,?,?, \
				                      ?,?,?,?,?,?,?,?,?,?,?, \
				                      ?,?,?,?,?,?, \
				                      ?,?,?,?,?,?,?,?,?, \
				                      ?,?,?,?,?,?,?,?,?,?,?,?, \
				                      ?,?,?)",list[k].dbname);
				$PREPARE insert_ply_edr FROM $stmt;
				$EXECUTE insert_ply_edr using $data_yyyymm,$t_fend_yn,$t_fstl,$t_istl_recover,$t_ihealth,$t_dclaim,$t_iclm_company,$t_iclm_br,$t_iclaim,$t_iclose_type,$t_istl_flag,
				                              $t_dgroup,$t_icard_company,$t_icard_br,$t_icard,$t_dply_begin,$t_dply_end,$t_iarea,$t_iobjno,$t_iissue_year,$t_ipro_year,
				                              $t_ibrand,$t_icar_type,$t_icar_type_no,$t_qcylinder,$t_iengine,$t_itag,$t_qpt,$t_fpt,
				                              $t_ioth_fassured,$t_ioth_cartype,$t_ioth_qpt,$t_ioth_fpt,$t_ioth_tag,$t_ioth_comp_yn,$t_ioth_card_company,$t_ioth_card,
				                              $t_fcomp_class,$t_qdrunk_driving,$t_mins_premium,$t_madjcom_prem,$t_mbusiness,$t_maintain,$t_mcompensation,$t_mstable,$t_mdrunk_prem,$t_mdrunk_pure_prem,$t_drate_ym,
				                              $t_fassured,$t_iassured,$t_dbirth,$t_fsex,$t_fmarriage,$t_facc_nation,$t_iacc_license,$t_iacc_birth,$t_facc_sex,$t_facc_marri,$t_facc_rel,
				                              $t_iacc_reason,$t_facc_duty,$t_fsubrogation,$t_iself_duty,$t_ioth_duty,$t_ianoth_duty,
				                              $t_qacar_death,$t_qacar_cripple,$t_qacar_injure,$t_qbcar_death,$t_qbcar_cripple,$t_qbcar_injure,$t_qccar_death,$t_qccar_cripple,$t_qccar_injure,
				                              $t_daccident,$t_iacc_area,$t_istl_class,$t_mcoverage,$t_victim_num,$t_mapp_cover,$t_mins_stl,$t_mins_proc,$t_mstl_health,$t_qhealth,$t_mhealth,$t_sum_all,
				                              $t_iproduct,$t_bzfrom,$t_dsend;
			}
	
			if ((pel_cnt_A == 0) && (pel_cnt_B == 0) && (pel_cnt_C == 0))
				continue;
	
			/******** ���I���O�N�� = Z ***********/
			strcpy(prtstr,prtstr_1to25);
			
			strcat(prtstr,"Z00");
			prtstr[391]='\0';
			
			strcat(prtstr,"+");
			buf1[0]='\0';
			/*  Cyrus
			tot_mcoverage=1200000;
			
			tot_mcoverage=1600000;
			*/
			tot_mcoverage= mcoverage_A00 + mcoverage_B00 + mcoverage_C00;
			
			/* 390-398 �C�H�O�I���B */
			rfmtlong(tot_mcoverage,"&&&&&&&&",buf1);
			strncat(prtstr,(buf1[0]=='\0') ? "00000000" : buf1,8);
			prtstr[400]='\0';
			
			/* 399-402 �z�ߤH�� */
			buf1[0]='\0';
			if (tot_pel_cnt ==0 )
			continue ;
			rfmtlong(tot_pel_cnt,"&&&&",buf1);
			strcat(prtstr,(buf1[0]=='\0') ? "0000" : buf1);
			prtstr[404]='\0';
			
			/* 403-415 �w���l�����B */
			strcat(prtstr,"+");
			buf1[0]='\0';
			rfmtlong(tot_sum_mapp_cover,"&&&&&&&&&&&&",buf1);
			strcat(prtstr,(buf1[0]=='\0') ? "000000000000" : buf1);
			prtstr[417]='\0';
			
			/* 416-428 ���t�ثO�z�ߪ��B */
			strcat(prtstr,"+");
			buf1[0]='\0';
			/*rfmtlong(tot_sum_mins_stl,"&&&&&&&&&&&&",buf1);*/
			/*strcat(prtstr,(buf1[0]=='\0') ? "000000000000" : buf1); */
			strcat(prtstr, "000000000000" );
			prtstr[430]='\0';
			
			/* 429-439 �z�߶O�� */
			strcat(prtstr,"+");
			buf1[0]='\0';
			/*rfmtlong(tot_sum_mins_proc,"&&&&&&&&&&",buf1);*/
			/*strcat(prtstr,(buf1[0]=='\0') ? "0000000000" : buf1);*/
			strcat(prtstr, "0000000000" );
			prtstr[441]='\0';
			
			/* 440-450 ���I���O���B */
			strcat(prtstr,"+");
			buf1[0]='\0';
			rfmtlong(tot_sum_mins_health,"&&&&&&&&&&",buf1);
			/*strcat(prtstr,(buf1[0]=='\0') ? "0000000000" : buf1); */
			strcat(prtstr, "0000000000" );
			prtstr[452]='\0';
			
			/*451-459 ���O�I�� */
			strcat(prtstr,"+");
			buf1[0]='\0';
			strncat(prtstr,  "00000000"  ,8);
			prtstr[461]='\0';
			 
			/*460-468 ���O���B */
			strcat(prtstr,"+");
			buf1[0]='\0';
			strncat(prtstr,  "00000000"  ,8);
			prtstr[470]='\0';
			
			/* 469-481 ��ڲz�ߪ��B */
			strcat(prtstr,"+");
			buf1[0]='\0';
			rfmtlong(tot_sum_all,"&&&&&&&&&&&&",buf1);
			/*strcat(prtstr,(buf1[0]=='\0') ? "000000000000" : buf1); */
			strcat(prtstr, "000000000000" );
			prtstr[483]='\0';
			
			strcpy(t_istl_class,"Z00");
			t_mcoverage = tot_mcoverage;
			t_victim_num = tot_pel_cnt;
			t_mapp_cover = tot_sum_mapp_cover;
			t_mins_stl = 0;
			t_mins_proc = 0;
			t_mstl_health = 0;
			t_qhealth = 0;
			t_mhealth = 0;
			t_sum_all = 0;
			
			/* 482-493 �ӫ~�N�X */
			strcat(prtstr,iproduct);
			strcpy(t_iproduct,iproduct);
			prtstr[495]='\0';
			
			/* 494-501 �ߥI/�l�v��� */
			strncat(prtstr,"00000000",8);
			prtstr[503]='\0';
			
			/*502-503 �q���O�N�� */
			strcat(prtstr,bzfrom);
			strcpy(t_bzfrom,bzfrom);
			prtstr[505]= '\0';
			
			/*504-511 ��ƻs�e���*/
			strcat(prtstr,ttday_yy);
			strcat(prtstr,ttday_mm);
			strcat(prtstr,ttday_dd);
			strcpy(t_dsend,ttday_yy);
			strcat(t_dsend,ttday_mm);
			strcat(t_dsend,ttday_dd);
			prtstr[513]='\0';
			
			fprintf(fptr,"%s\n",prtstr);
			count1++;
			
			printf("data_yyyymm[%s],t_fend_yn[%s],t_fstl[%s],t_istl_recover[%s],t_ihealth[%s],t_dclaim[%s],t_iclm_company[%s],t_iclm_br[%s],t_iclaim[%s],t_iclose_type[%d],t_istl_flag[%s] \n",
		            data_yyyymm,t_fend_yn,t_fstl,t_istl_recover,t_ihealth,t_dclaim,t_iclm_company,t_iclm_br,t_iclaim,t_iclose_type,t_istl_flag);
			printf("t_dgroup[%s],t_icard_company[%s],t_icard_br[%s],t_icard[%s],t_dply_begin[%s],t_dply_end[%s],t_iarea[%s],t_iobjno[%s],t_iissue_year[%s],t_ipro_year[%s] \n",
			        t_dgroup,t_icard_company,t_icard_br,t_icard,t_dply_begin,t_dply_end,t_iarea,t_iobjno,t_iissue_year,t_ipro_year);
			printf("t_ioth_fassured[%s],t_ioth_cartype[%s],t_ioth_qpt[%d],t_ioth_fpt[%s],t_ioth_tag[%s],t_ioth_comp_yn[%s],t_ioth_card_company[%s],t_ioth_card[%s] \n",
			        t_ioth_fassured,t_ioth_cartype,t_ioth_qpt,t_ioth_fpt,t_ioth_tag,t_ioth_comp_yn,t_ioth_card_company,t_ioth_card);
			printf("t_fcomp_class[%s],t_qdrunk_driving[%d],t_mins_premium[%d],t_madjcom_prem[%f],t_mbusiness[%f],t_maintain[%f],t_mcompensation[%f],t_mstable[%f],t_mdrunk_prem[%d],t_mdrunk_pure_prem[%f],t_drate_ym[%s] \n",
			        t_fcomp_class,t_qdrunk_driving,t_mins_premium,t_madjcom_prem,t_mbusiness,t_maintain,t_mcompensation,t_mstable,t_mdrunk_prem,t_mdrunk_pure_prem,t_drate_ym);
			printf("t_fassured[%s],t_iassured[%s],t_dbirth[%s],t_fsex[%s],t_fmarriage[%s],t_facc_nation[%s],t_iacc_license[%s],t_iacc_birth[%s],t_facc_sex[%s],t_facc_marri[%s],t_facc_rel[%s] \n",
			        t_fassured,t_iassured,t_dbirth,t_fsex,t_fmarriage,t_facc_nation,t_iacc_license,t_iacc_birth,t_facc_sex,t_facc_marri,t_facc_rel);
			printf("t_iacc_reason[%s],t_facc_duty[%s],t_fsubrogation[%s],t_iself_duty[%d],t_ioth_duty[%d],t_ianoth_duty[%d] \n",
			        t_iacc_reason,t_facc_duty,t_fsubrogation,t_iself_duty,t_ioth_duty,t_ianoth_duty);
			printf("t_qacar_death[%d],t_qacar_cripple[%d],t_qacar_injure[%d],t_qbcar_death[%d],t_qbcar_cripple[%d],t_qbcar_injure[%d],t_qccar_death[%d],t_qccar_cripple[%d],t_qccar_injure[%d] \n",
			        t_qacar_death,t_qacar_cripple,t_qacar_injure,t_qbcar_death,t_qbcar_cripple,t_qbcar_injure,t_qccar_death,t_qccar_cripple,t_qccar_injure);
			printf("t_daccident[%s],t_iacc_area[%s],t_istl_class[%s],t_mcoverage[%d],t_victim_num[%d],t_mapp_cover[%d],t_mins_stl[%d],t_mins_proc[%d],t_mstl_health[%d],t_qhealth[%d],t_mhealth[%d],t_sum_all[%d] \n",
			        t_daccident,t_iacc_area,t_istl_class,t_mcoverage,t_victim_num,t_mapp_cover,t_mins_stl,t_mins_proc,t_mstl_health,t_qhealth,t_mhealth,t_sum_all);
			printf("t_iproduct[%s],t_bzfrom[%s],t_dsend[%s] \n",
			        t_iproduct,t_bzfrom,t_dsend);
			/* �d�s��� */
			sprintf_s(stmt,5120,"INSERT INTO %s:ca_dev_clm_comp \
			                     (data_yyyymm,idata,fend_yn,fstl,istl_recover,ihealth,dclaim,iclm_company,iclm_br,iclaim,iclose_type,istl_flag, \
			                      dgroup,icard_company,icard_br,icard,dply_begin,dply_end,iarea,iobjno,iissue_year,ipro_year, \
			                      ibrand,icar_type,icar_type_no,qcylinder,iengine,itag,qpt,fpt, \
			                      ioth_fassured,ioth_cartype,ioth_qpt,ioth_fpt,ioth_tag,ioth_comp_yn,ioth_card_company,ioth_card, \
			                      fcomp_class,qdrunk_driving,mins_premium,madjcom_prem,mbusiness,maintain,mcompensation,mstable,mdrunk_prem,mdrunk_pure_prem,drate_ym, \
			                      fassured,iassured,dbirth,fsex,fmarriage,facc_nation,iacc_license,iacc_birth,facc_sex,facc_marri,facc_rel, \
			                      iacc_reason,facc_duty,fsubrogation,iself_duty,ioth_duty,ianoth_duty, \
			                      qacar_death,qacar_cripple,qacar_injure,qbcar_death,qbcar_cripple,qbcar_injure,qccar_death,qccar_cripple,qccar_injure, \
			                      daccident,iacc_area,istl_class,mcoverage,victim_num,mapp_cover,mins_stl,mins_proc,mstl_health,qhealth,mhealth,sum_all, \
			                      iproduct,bzfrom,dsend) \
			               VALUES(?,'U',?,?,?,?,?,?,?,?,?,?, \
			                      ?,?,?,?,?,?,?,?,?,?, \
			                      ?,?,?,?,?,?,?,?, \
			                      ?,?,?,?,?,?,?,?, \
			                      ?,?,?,?,?,?,?,?,?,?,?, \
			                      ?,?,?,?,?,?,?,?,?,?,?, \
			                      ?,?,?,?,?,?, \
			                      ?,?,?,?,?,?,?,?,?, \
			                      ?,?,?,?,?,?,?,?,?,?,?,?, \
			                      ?,?,?)",list[k].dbname);
			$PREPARE insert_ply_edr FROM $stmt;
			$EXECUTE insert_ply_edr using $data_yyyymm,$t_fend_yn,$t_fstl,$t_istl_recover,$t_ihealth,$t_dclaim,$t_iclm_company,$t_iclm_br,$t_iclaim,$t_iclose_type,$t_istl_flag,
			                              $t_dgroup,$t_icard_company,$t_icard_br,$t_icard,$t_dply_begin,$t_dply_end,$t_iarea,$t_iobjno,$t_iissue_year,$t_ipro_year,
			                              $t_ibrand,$t_icar_type,$t_icar_type_no,$t_qcylinder,$t_iengine,$t_itag,$t_qpt,$t_fpt,
			                              $t_ioth_fassured,$t_ioth_cartype,$t_ioth_qpt,$t_ioth_fpt,$t_ioth_tag,$t_ioth_comp_yn,$t_ioth_card_company,$t_ioth_card,
			                              $t_fcomp_class,$t_qdrunk_driving,$t_mins_premium,$t_madjcom_prem,$t_mbusiness,$t_maintain,$t_mcompensation,$t_mstable,$t_mdrunk_prem,$t_mdrunk_pure_prem,$t_drate_ym,
			                              $t_fassured,$t_iassured,$t_dbirth,$t_fsex,$t_fmarriage,$t_facc_nation,$t_iacc_license,$t_iacc_birth,$t_facc_sex,$t_facc_marri,$t_facc_rel,
			                              $t_iacc_reason,$t_facc_duty,$t_fsubrogation,$t_iself_duty,$t_ioth_duty,$t_ianoth_duty,
			                              $t_qacar_death,$t_qacar_cripple,$t_qacar_injure,$t_qbcar_death,$t_qbcar_cripple,$t_qbcar_injure,$t_qccar_death,$t_qccar_cripple,$t_qccar_injure,
			                              $t_daccident,$t_iacc_area,$t_istl_class,$t_mcoverage,$t_victim_num,$t_mapp_cover,$t_mins_stl,$t_mins_proc,$t_mstl_health,$t_qhealth,$t_mhealth,$t_sum_all,
			                              $t_iproduct,$t_bzfrom,$t_dsend;
			
			prem_total+=tot_sum_mapp_cover;
	
		}
		$CLOSE car9994_claim_cur;
		$FREE car9994_claim_cur;
	}
	
	fclose(fptr);

	res = getApHome(aphome);
	if (res<0)
	{
		printf("In sigalrmcatcher func==>read config file error!!\n");
		exit(1);
	}
	
	if(count1==0)
		fprintf(fptr_err,"%s\n","�L���!!");
	else
	{
		/* �s����� */
		$SELECT iquota INTO $iquota FROM officer WHERE iofficer=$userid;
		
		rtoday(&Today);     /* get today's datetime */
		printf("### Today[%d],localdb[%s],prem_total[%d],count1[%d]\n",
		     Today,localdb,prem_total,count1);
		
		strcpy(Taipei_FullName,get_full_dbname("00"));
		
		$WHENEVER SQLERROR CONTINUE;
		
		sprintf_s(stmt,5120,"DELETE FROM %s:ca_develop \
		               WHERE iclass='9994' AND ibranch=? AND data_yyyymm = ? ",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus1 FROM $stmt;
		$EXECUTE insert_cus1 USING $DBName,$data_yyyymm;
		
		$WHENEVER SQLERROR GOTO errexit;
		
		sprintf_s(stmt,5120,"INSERT INTO %s:ca_develop \
		              (iquota,data_yyyymm,iclass,dsend,ibranch, \
		               product_kind,iins_class,mprem,qcnt,mhealth,mdrunk_pure_prem) \
		              VALUES(?,?,'9994',?,?,'14','C',?,0,?,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus14 FROM $stmt;
		$EXECUTE insert_cus14 USING $iquota,$data_yyyymm,$Today,$DBName,$mprem_14,$mhealth_14;

		sprintf_s(stmt,5120,"INSERT INTO %s:ca_develop \
		              (iquota,data_yyyymm,iclass,dsend,ibranch, \
		               product_kind,iins_class,mprem,qcnt,mhealth,mdrunk_pure_prem) \
		              VALUES(?,?,'9994',?,?,'15','C',?,0,?,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus15 FROM $stmt;
		$EXECUTE insert_cus15 USING $iquota,$data_yyyymm,$Today,$DBName,$mprem_15,$mhealth_15;

		sprintf_s(stmt,5120,"INSERT INTO %s:ca_develop \
		              (iquota,data_yyyymm,iclass,dsend,ibranch, \
		               product_kind,iins_class,mprem,qcnt,mhealth,mdrunk_pure_prem) \
		              VALUES(?,?,'9994',?,?,'16','C',?,0,?,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus16 FROM $stmt;
		$EXECUTE insert_cus16 USING $iquota,$data_yyyymm,$Today,$DBName,$mprem_16,$mhealth_16;
		
		sprintf_s(stmt,5120,"INSERT INTO %s:ca_develop \
		              (iquota,data_yyyymm,iclass,dsend,ibranch, \
		               product_kind,iins_class,mprem,qcnt,mhealth,mdrunk_pure_prem) \
		              VALUES(?,?,'9994',?,?,'32','C',?,0,?,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus32 FROM $stmt;
		$EXECUTE insert_cus32 USING $iquota,$data_yyyymm,$Today,$DBName,$mprem_32,$mhealth_32;

		sprintf_s(stmt,5120,"INSERT INTO %s:ca_develop \
		                     (iquota,data_yyyymm,iclass,dsend,ibranch,product_kind,iins_class,mprem,mhealth,qcnt,mdrunk_pure_prem) \
		              VALUES (?,?,'9994',?,?,'99','C',?,0,?,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus2 FROM $stmt;
		$EXECUTE insert_cus2
		USING $iquota,$data_yyyymm,$Today,$DBName,$prem_total,$count1;
     }

	return SUCCESS;

errexit:
	printf("usrid=%s SOLCODE=%d sqlca.sqlerrm=%s\n",userid,SQLCODE,sqlca.sqlerrm);
	sprintf_s(errmsg,200,"userid=%s SOLCODE=%d sqlca.sqlerrm=%s",userid,SQLCODE,sqlca.sqlerrm);
	fprintf(fptr_err,"%s\n",errmsg);
	return SQLCODE;
}

long car9994_final()
{
	char sTmpMsg[1024];
	$char sfilename[81],stitle[1024],stmt[1024];
	$char DBName1[5];
	$long mprem, mhealth, qcnt;
	$char product_kind[3];
    
	$WHENEVER SQLERROR GOTO errexit;
	
	strcpy(DBName1,"00");
	if (db_select(DBName1) == False)  return M_CM_DB_NOTOPEN;
	
	$SELECT sum(mprem), sum(qcnt), sum(mhealth)
	   INTO $mprem, $qcnt, $mhealth
	   FROM ca_develop
	  WHERE iclass = '9994' AND product_kind = '99'
	    AND data_yyyymm  = $data_yyyymm;

	sprintf_s(sTmpMsg,1024, "%s%s\n", "���ɧ���:", file_catalog);
	sprintf_s(sTmpMsg,1024, "%s�O�O=[%d] ����=[%d]\n",sTmpMsg, mprem, qcnt );
	
	/*29�I���p�p����*/
	sprintf_s(stmt,1024,"SELECT product_kind, sum(mprem), sum(qcnt) \
	                FROM ca_develop \
	               WHERE iclass = '9994' AND product_kind <> '99' AND data_yyyymm = '%s' \
	               GROUP BY product_kind order by 1",data_yyyymm);
	$PREPARE pre_29_kind1 FROM $stmt;
	$DECLARE cur_29_kind2 CURSOR FOR pre_29_kind1;
	$OPEN cur_29_kind2;
	while (1)
	{
		$FETCH cur_29_kind2 INTO $product_kind ,$mprem, $qcnt;
		if (SQLCODE == SQLNOTFOUND) break;
		sprintf_s(sTmpMsg,1024, "%s�I��=[%s] �O�O=[%d] �«O�O=[%d] ����=[%d]\n",sTmpMsg, product_kind, mprem, qcnt );
	}

	EWRITE(userid, M_CM_OK, sTmpMsg);
	exit(SUCCESS);
	isfinish(rtncode);

errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}
