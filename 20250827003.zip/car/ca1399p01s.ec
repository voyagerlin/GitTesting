/**********************************************************************/
/*   program id   : ca1399p01s.ec                                     */
/*   program name : ISID��Ʀ^��                                      */
/*   date written : 2021/09/28                                        */
/*   date modify  : yyyy/mm/dd                                        */
/*   shell        : car1399                                           */
/**********************************************************************/

#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include "print.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "othmsgs.h"
#include "commsgs.h"
#include "sqlfatal.h"
#include "safeclib.h"

char  	outputf[ N_FILE+1];
$char  	userid[11],sDdate[11];
char  	ddate[11];
char	sdate[11];

$char	DBName[5];
DBinfo  *list;
    
int     flen,count_db,i;
FILE    *fp;
char    sApHome[30];
$char   fname[60];
$char   filename[121];

$char	stmt[2048],stmt1[2048],stmt2[2048],stmt3[2048],stmt4[2048];
char	msgbuf[100];

$char   Full_DBName[31];
$char   ipolicy[21], iapplicant[13], iassured[13], ftype[2], 
        irelative_ply[21], fcard_class[2], itmp_policy[21], itmp_policy2[21];

/*----------------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
	int rc;
	
	batchinit();
	strcpy(DBName,  isNULLstr(argv[1]));
	strcpy(userid,  isNULLstr(argv[2]));
	strcpy(ddate,   isNULLstr(argv[3])); /* cyy/mm/dd */
	strcpy(outputf, isNULLstr(argv[4]));
	
	strcpy(sDdate,cm_to_infdate(ddate));
	printf("-----dwritten[%s]\n",sDdate);
	
	rc = car1399_get_db();
	if (rc != M_CM_OK) {
		printf("error on car1399_get_db\n");
		return rc;
	}
	
	printf("-----car1399_get_data\n");
	rc = car1399_get_data();
	if (rc != M_CM_OK) {
		printf("error on car1399_get_data\n");
		return rc;
	}
	
	printf("-----car1399_insert\n");
	rc = car1399_insert();
	if (rc != M_CM_OK) {
		printf("error on car1399_upd_data\n");
		return rc;
	}
	
	printf("[car1399]:process ok!\n"); 
}
/*----------------------------------------------------------------------------*/
long car1399_get_db()
{
	int	rc;
	
	if (db_select(DBName) == False) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "��Ʈw�L�k�}��!");
		return M_CM_DB_NOTOPEN;
	}

	rc = getApHome(sApHome);
	if (rc < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		EWRITE(userid,rc,msgbuf);
		return rc;
	}
	
	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
		return M_CM_NOT_DBLIST;
	}
	
	return M_CM_OK;
}
/*----------------------------------------------------------------------------*/
long car1399_get_data()
{
	$char stmt[2048], stmt1[4096], stmt2[2048];
	$char reason_appl[20], reason_assu[20];
	$int  cnt=0,cnt1=0,cnt2=0;
	
	$whenever SQLERROR goto errexit;
		
	$create temp table car1399_tmp1
	(
	    ipolicy1        char(20),
	    ipolicy2        char(20),
	    iapplicant      char(12),
	    iassured        char(12),
	    iappl           char(10),
	    iassu           char(10)
 	)with no log;
 		
 	$create temp table car1399_data
	(
	    ipolicy         char(20),
	    ftype           char(1)
 	)with no log;
 	$create UNIQUE INDEX data_x1 ON car1399_data (ipolicy);
 	  	 	
 	sprintf_s(stmt, sizeof stmt, " insert into car1399_tmp1                                       \n"
                       " select ipolicy1, ipolicy2, iapplicant, iassured,                         \n"
                       "        nvl((select max(date(dcreate)) from cm_isid_log x                 \n"
                       "              where x.imember = a.iapplicant                              \n"
                       "                and x.imember not in (' ', '*')                           \n"
                       "                and x.iref_num1 = a.ipolicy1[1,13]||a.ipolicy2            \n"
                       "                and date(x.dcreate) >= (a.dwritten-60)                    \n"
                       "                and date(x.dcreate) <= a.dwritten), 'Not found') iappl,   \n"
                       "        nvl((select max(date(dcreate)) from cm_isid_log x                 \n"
                       "              where x.imember = a.iassured                                \n"
                       "                and x.imember not in (' ', '*')                           \n"
                       "                and x.iref_num1 = a.ipolicy1[1,13]||a.ipolicy2            \n"
                       "                and date(x.dcreate) >= (a.dwritten-60)                    \n"
                       "                and date(x.dcreate) <= a.dwritten), 'Not found') iassu    \n"
                       "   from policy_main a                                                     \n"
                       "   where iendorsement = ' ' and isys_source = 'CAR'                       \n"
                       "   and dwritten between date('%s')-6 and '%s'; \n", sDdate, sDdate );       
        $prepare insert_tmp1 from $stmt;
 	$execute insert_tmp1;
 		
 	$select trim(ipolicy1)||trim(ipolicy2) as ipolicy, iapplicant, iassured,
 	        iappl, iassu, '1' as ftype
           from car1399_tmp1
          where iappl = 'Not found'
          union
         select trim(ipolicy1)||trim(ipolicy2), iapplicant, iassured,
                iappl, iassu, '2'
           from car1399_tmp1
          where iappl != 'Not found'
            and iassu = 'Not found'
           into temp car1399_tmp2;	
	
	$create UNIQUE INDEX tmp2_x1 ON car1399_tmp2 (ipolicy);
	$create INDEX tmp2_x2 ON car1399_tmp2 (iapplicant);
	$create INDEX tmp2_x3 ON car1399_tmp2 (iassured);
		
	for (i=0;i<count_db;i++)
	{
		sprintf_s(stmt1, sizeof stmt1, " select a.ipolicy, a.iapplicant, a.iassured, a.ftype,            \n"
 	                        "        nvl(b.irelative_ply,''), b.fcard_class, b.itmp_policy,   \n"
 	                        "   case when a.iappl != 'Not found' then ''                      \n"
 	                        "        when (select count(*) from cm_isid_log f where f.iref_num1 = b.ipolicy     \n"
 	                        "                and f.iref_num1 <>'' and f.imember = a.iapplicant) >0 then 'cm_isid_log���O��'  \n"
 	                        "        when (select count(*) from cm_isid_batch f where f.iref_num1 = b.ipolicy   \n"
 	                        "                and f.iref_num1 <>'' and f.imember = a.iapplicant) >0 then 'cm_isid_batch���O��'\n"
 	                        "        when (select count(*) from cm_isid_risk f where f.iref_num1 = b.ipolicy    \n"
 	                        "                and f.iref_num1 <>'' and f.imember = a.iapplicant) >0 then 'cm_isid_risk���O��' \n"
 	                        "        else '' end as reason_appl,    \n"
 	                        "   case when a.iappl != 'Not found' then ''                \n"
 	                        "        when (select count(*) from cm_isid_log f where f.iref_num1 = b.ipolicy     \n"
 	                        "                and f.iref_num1 <>'' and f.imember = a.iassured) >0 then 'cm_isid_log���O��'    \n"
 	                        "        when (select count(*) from cm_isid_batch f where f.iref_num1 = b.ipolicy   \n"
 	                        "                and f.iref_num1 <>'' and f.imember = a.iassured) >0 then 'cm_isid_batch���O��'  \n"
 	                        "        when (select count(*) from cm_isid_risk f where f.iref_num1 = b.ipolicy    \n"
 	                        "                and f.iref_num1 <>'' and f.imember = a.iassured) >0 then 'cm_isid_risk���O��'   \n"
 	                        "        else '' end as reason_assu,    \n"
 	                        "        (select count(*) from %s:ply_relation c where c.ipolicy = b.irelative_ply  \n"
 	                        "            and c.itmp_policy = b.itmp_policy)            \n"
 	                        "   from car1399_tmp2 a, %s:ori_ply_relation b            \n"
                                "  where a.ipolicy = b.ipolicy and b.ipolicy[6,7] <> 'V7'  \n"
                                "    and b.iofficer[1] not in ('N','W') and b.iofficer[1,2] not in ('H0','H1','H2') \n"
                                "    and not (b.iofficer[1] = 'L' and b.iofficer[7] = 'B');                         \n"
                                , list[i].dbname, list[i].dbname);       
                $prepare preA from $stmt1;
                $declare curA cursor for preA;
                $open curA;
                                
                while(1){
                	$fetch curA
                	  into $ipolicy, $iapplicant, $iassured, $ftype, 
                	       $irelative_ply, $fcard_class, $itmp_policy,
                	       $reason_appl, $reason_assu, $cnt;
                	if (SQLCODE==SQLNOTFOUND) break;
                	
                	/* �ư��bISID����table������������ */
                	if (strlen(trim(reason_appl)) > 0 && strlen(trim(reason_assu)) > 0) continue;
                	                	
                	strcpy(itmp_policy,trim(itmp_policy));
                	strcpy(irelative_ply,trim(irelative_ply));
                	                		
                	/* check�G�O�_���j+�����j��O�� (�j+���u�H���N�I�eISID) */
                	if (strcmp(fcard_class,"1") == 0 && cnt > 0) continue;               	
                	
                	/* insert �ݦ^�ɫO���� */
                	$insert into car1399_data (ipolicy, ftype)
                	 values ($ipolicy, $ftype);
        		        	
                }
                $close curA;
                $free curA;                
	}
	
	return M_CM_OK;
	
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car1399_insert()
{
	$char stmt[4096];
	
	$whenever SQLERROR goto errexit;
	
	$begin work;
	
	for (i=0;i<count_db;i++)
	{	
		sprintf_s(stmt, sizeof stmt, " insert into cm_isid_batch \n"
		               " select a.ipolicy,' ',' ','1',a.iapplicant,a.napplicant, \n"
		               "        decode(a.iapplicant_cntry,'9','TW','2','CN',' '),a.dbirth_appl, \n"
		               "        (select  \n"
		               "                case when iapp_unit='00' and iquota[1,4] not in ('1206','1701','4101') then '3201' \n"
		               "                     when iapp_unit='00' and iquota[1,4] in ('1206','1701','4101') then '4101' \n"
		               "                     when nvl((select nvl(t.iquota_grp[1,4] ,'') \n"
		               "                                 from officer a, sa_branch_type b, branch t, sa_branch_type d \n"
		               "                                where a.iquota     = b.ibranch and a.dexpire is null \n"
		               "                                  and a.iapp_unit != b.iply_branch \n"
		               "                                  and a.iapp_unit  = t.ibranch \n"
		               "                                  and t.iquota_grp = d.ibranch \n"
		               "                                  and a.iofficer   = c.iofficer),'-1') <> -1  \n"
		               "                     then nvl((select nvl(t.iquota_grp[1,4] ,'') \n"
		               "                                 from officer a, sa_branch_type b, branch t, sa_branch_type d \n"
		               "                                where a.iquota     = b.ibranch and a.dexpire is null \n"
		               "                                  and a.iapp_unit != b.iply_branch \n"
		               "                                  and a.iapp_unit  = t.ibranch \n"
		               "                                  and t.iquota_grp = d.ibranch \n"
		               "                                  and a.iofficer   = c.iofficer),'-1') \n"
		               "                     else iquota[1,4] end  \n"
		               "           from officer where iofficer = c.iofficer), \n"
		               "           'C','2','E',c.ientry,c.dentry,'',10,c.ientry, \n"
		               "           (select p.ileader from officer p where c.iofficer=p.iofficer),'','','' \n"
		               "   from %s:original_ply a, %s:ori_ply_relation c \n"
		               "  where a.ipolicy = c.ipolicy \n"
		               "    and a.iassured <> a.iapplicant \n"
		               "    and a.ipolicy in (select ipolicy from car1399_data where ftype = '1') \n"
		               "    and a.iassured <> a.iapplicant; \n", list[i].dbname, list[i].dbname);
		$prepare insert_batch1 from $stmt;
		$execute insert_batch1;
 	
		sprintf_s(stmt, sizeof stmt, " insert into cm_isid_batch \n"
		               " select a.ipolicy,' ',' ','2',a.iassured,a.nassured, \n"
		               "        decode(a.iassured_cntry,'9','TW','2','CN',' '),a.dbirth,\n"
		               "        (select  \n"
		               "                case when iapp_unit='00' and iquota[1,4] not in ('1206','1701','4101') then '3201' \n"
		               "                     when iapp_unit='00' and iquota[1,4] in ('1206','1701','4101') then '4101' \n"
		               "                     when nvl((select nvl(t.iquota_grp[1,4] ,'') \n"
		               "                                 from officer a, sa_branch_type b, branch t, sa_branch_type d \n"
		               "                                where a.iquota     = b.ibranch and a.dexpire is null \n"
		               "                                  and a.iapp_unit != b.iply_branch \n"
		               "                                  and a.iapp_unit  = t.ibranch \n"
		               "                                  and t.iquota_grp = d.ibranch \n"
		               "                                  and a.iofficer   = c.iofficer),'-1') <> -1  \n"
		               "                     then nvl((select nvl(t.iquota_grp[1,4] ,'') \n"
		               "                                 from officer a, sa_branch_type b, branch t, sa_branch_type d \n"
		               "                                where a.iquota     = b.ibranch and a.dexpire is null \n"
		               "                                  and a.iapp_unit != b.iply_branch \n"
		               "                                  and a.iapp_unit  = t.ibranch \n"
		               "                                  and t.iquota_grp = d.ibranch \n"
		               "                                  and a.iofficer   = c.iofficer),'-1') \n"
		               "                     else iquota[1,4] end  \n"
		               "           from officer where iofficer = c.iofficer), \n"
		               "           'C','2','E',c.ientry,c.dentry,'',10,c.ientry, \n"
		               "           (select p.ileader from officer p where c.iofficer=p.iofficer),'','','' \n"
		               "   from %s:original_ply a, %s:ori_ply_relation c \n"
		               "  where a.ipolicy = c.ipolicy \n"
		               "    and a.ipolicy in (select ipolicy from car1399_data) \n"
		               "    and a.iassured <> a.iapplicant; \n", list[i].dbname, list[i].dbname);
		$prepare insert_batch2 from $stmt;
		$execute insert_batch2;
		
		sprintf_s(stmt, sizeof stmt, " insert into cm_isid_batch \n"
		               " select a.ipolicy,' ',' ','3',a.iassured,a.nassured, \n"
		               "        decode(a.iassured_cntry,'9','TW','2','CN',' '),a.dbirth,  \n"
		               "        (select  \n"
		               "                case when iapp_unit='00' and iquota[1,4] not in ('1206','1701','4101') then '3201' \n"
		               "                     when iapp_unit='00' and iquota[1,4] in ('1206','1701','4101') then '4101' \n"
		               "                     when nvl((select nvl(t.iquota_grp[1,4] ,'') \n"
		               "                                 from officer a, sa_branch_type b, branch t, sa_branch_type d \n"
		               "                                where a.iquota     = b.ibranch and a.dexpire is null \n"
		               "                                  and a.iapp_unit != b.iply_branch \n"
		               "                                  and a.iapp_unit  = t.ibranch \n"
		               "                                  and t.iquota_grp = d.ibranch \n"
		               "                                  and a.iofficer   = c.iofficer),'-1') <> -1  \n"
		               "                     then nvl((select nvl(t.iquota_grp[1,4] ,'') \n"
		               "                                 from officer a, sa_branch_type b, branch t, sa_branch_type d \n"
		               "                                where a.iquota     = b.ibranch and a.dexpire is null \n"
		               "                                  and a.iapp_unit != b.iply_branch \n"
		               "                                  and a.iapp_unit  = t.ibranch \n"
		               "                                  and t.iquota_grp = d.ibranch \n"
		               "                                  and a.iofficer   = c.iofficer),'-1') \n"
		               "                     else iquota[1,4] end  \n"
		               "           from officer where iofficer = c.iofficer), \n"
		               "           'C','2','E',c.ientry,c.dentry,'',10,c.ientry, \n"
		               "           (select p.ileader from officer p where c.iofficer=p.iofficer),'','','' \n"
		               "   from %s:original_ply a, %s:ori_ply_relation c \n"
		               "  where a.ipolicy = c.ipolicy \n"
		               "    and a.ipolicy in (select ipolicy from car1399_data where ftype = '1') \n"
		               "    and a.iassured = a.iapplicant; \n", list[i].dbname, list[i].dbname);	
		$prepare insert_batch3 from $stmt;
		$execute insert_batch3;	
	}
	$commit work; 

	return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    $whenever sqlerror continue;
    $ROLLBACK WORK;
    return SQLCODE;
}
