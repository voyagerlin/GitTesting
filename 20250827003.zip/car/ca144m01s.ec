/************************************************/
/*                                              */
/*   PROGRAM : ca144m01s.ec by Julia Han        */
/*                                              */
/*   PURPOSE : ������ƺ��@��                   */
/*                                              */
/************************************************/
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "commsgs.h"
#include "carmsgs.h"
$include datetime.h;
$include sqlca;

char errbuf[512];
$int count1;
$char getfile[300];
FILE   *fp;
static int   recLen=1024;
static char  *bp;
char delimiter;
int offset;

long car144(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	long rtncode;
	long car144_insert(),car144_single_query(),car144_multiple_query();
	long car144_update_exec(),car144_CHT_iassured(),car144_chk_provision();
	long car144_insert_batch(),car144_batch_update();
	char option;
	int tmp_len;
	
	cm_buf_init(command);
	cm_buf_get("%c",&option);
	switch(option)
	{
		case 'A':
			rtncode=car144_insert(reply);
			break;
		case 'Q':
			rtncode=car144_single_query(reply);
			break;
		case 'M':
			rtncode=car144_multiple_query(reply);
			break;
		case 'D':
		case 'U':
			rtncode=car144_update_exec(reply,command,com_len);
			break;
		case '1':
			rtncode=car144_CHT_iassured(reply);
			break;
		case 'C':
			rtncode=car144_chk_provision(reply);
			break;
		case 'E':   /* ��ƾ��W�� */
			rtncode=car144_insert_batch(reply);
			
			cm_buf_init(ReplyBuf);
			cm_buf_put("%l %s" , rtncode, errbuf);
			
			tmp_len = cm_buf_len(ReplyBuf);
			if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
				return apiRC;
			else
				return api_OKComplete;
			break;
		case 'P':
			rtncode=car144_batch_update(reply);
			break;
		default :
			if(exitsub(reply,M_CM_WRONG_OPTION) == True)
				return M_CM_WRONG_OPTION;
		return apiRC;
	}
	return(rtncode);
}

long car144_insert(reply)
serverReply reply;
{
	$char DBName[5];
	$char provision[7],iassured[13],iofficer[11],iins_cat[2],iins_type[7],strirate[10];
	$char icar_type[3],iupdate[11];
	$char dpolicy_bgn[11],dpolicy_end[11],strdpolicy_bgn[11],strdpolicy_end[11];
	$char drate_bgn[11],drate_end[11],strdrate_bgn[11],strdrate_end[11];
	$int  irate,ggg;
	$char tmp_provision[7];
	$int  chk_PF = 0;
	/* �s�W���Τ���� add by sylvia 101.12.18 (1010918004_C1) */
	$char dexpire[11],strdexpire[11];
	
	int tmp_len;
	DBinfo *list;
	int i, j, is_add_fail=0, api_f;
	$char stmt_buf[300];
	long MsgCode;

	cm_buf_get("%s %s %s %s %s %s %s %s %s %s %s %s %s %s",DBName, provision, iassured, iofficer,
	            iins_cat, iins_type, icar_type, strirate, strdpolicy_bgn, strdpolicy_end,
	            strdrate_bgn, strdrate_end, strdexpire, iupdate);

	if(strlen(trim(strdpolicy_bgn)) > 0)
	{
		strcpy(dpolicy_bgn,cm_to_infdate(strdpolicy_bgn));
		strcpy(dpolicy_end,cm_to_infdate(strdpolicy_end));
	}
	else
	{
		strcpy(dpolicy_bgn,"");
		strcpy(dpolicy_end,"");
	}

	if(strlen(trim(strdrate_bgn)) > 0)
	{
		strcpy(drate_bgn,cm_to_infdate(strdrate_bgn));
		strcpy(drate_end,cm_to_infdate(strdrate_end));
	}
	else
	{
		strcpy(drate_bgn,"");
		strcpy(drate_end,"");
	}
	
	irate = atoi(strirate);

	/* ���Τ� */
	strcpy(strdexpire, trim(strdexpire));
	if (strlen(strdexpire) > 0 )
		strcpy(dexpire,cm_to_infdate(strdexpire));
	else
		strcpy(dexpire,"");

	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}

	if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
	{
		if(exitsub(reply,M_CM_NOT_DBLIST) == True)
			return M_CM_NOT_DBLIST;
		return apiRC;
	}

	printf("dexpire[%s]\n",dexpire);
	printf("dpolicy_bgn[%s]\n",dpolicy_bgn);
	printf("drate_bgn[%s]\n",drate_bgn);

	$BEGIN WORK;
  
	/*** �P�_�ͮ�(ñ��)��O�_���| BEGIN ***/

	if(strlen(trim(drate_bgn)) > 0)
	{
		/*** �������|�P�_ ***/
		$SELECT count(*)
		   INTO $count1
		   FROM ca_id_officer
		  WHERE provision =$provision
		    AND iassured = $iassured
		    AND iofficer = $iofficer
		    AND iins_cat = $iins_cat
		    AND iins_type = $iins_type
		    AND icar_type = $icar_type
		    AND (drate_bgn BETWEEN $drate_bgn AND $drate_end OR
		         drate_end BETWEEN $drate_bgn AND $drate_end OR
		         $drate_bgn BETWEEN drate_bgn AND drate_end OR
		         $drate_end BETWEEN drate_bgn AND drate_end);
	
		if(count1 >= 1)
		{
			SQLCODE = -239;
			goto errexit;
		}
	}

	if(strlen(trim(dpolicy_bgn)) > 0)
	{
		$SELECT count(*)
		   INTO $count1
		   FROM ca_id_officer
		  WHERE provision =$provision
		    AND iassured = $iassured
		    AND iofficer = $iofficer
		    AND iins_cat = $iins_cat
		    AND iins_type = $iins_type
		    AND icar_type = $icar_type
		    AND (dpolicy_bgn BETWEEN $dpolicy_bgn AND $dpolicy_end OR
		         dpolicy_end BETWEEN $dpolicy_bgn AND $dpolicy_end OR
		         $dpolicy_bgn BETWEEN dpolicy_bgn AND dpolicy_end OR
		         $dpolicy_end BETWEEN dpolicy_bgn AND dpolicy_end);
	
		if(count1 >= 1)
		{
			SQLCODE = -239;
			goto errexit;
		}
	}
	/*** �P�_�ͮ�(ñ��)��O�_���| END ***/

	/* �P�_�I�جO�_��CAR140.PF�]�w���I�� */
	chk_PF = 0;
	$SELECT count(*)
	   INTO $chk_PF
	   FROM car_code
	  WHERE kind = 'PF' AND detail = $iins_type;
	printf("chk_PF[%d]\n",chk_PF);
	if (chk_PF == 0)
	{
		SQLCODE = M_CA_INS_PF;	
		goto errexit;
	}
	
	sprintf(stmt_buf,"INSERT INTO ca_id_officer \
	                  (provision,Iassured,Iofficer,Iins_cat,Iins_type,icar_type,Irate,dpolicy_bgn,dpolicy_end,drate_bgn,drate_end,dexpire,iupdate)\
	                  VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");

	$PREPARE a_id FROM $stmt_buf;
	$EXECUTE a_id USING $provision,$iassured,$iofficer,$iins_cat,$iins_type,$icar_type,$irate,$dpolicy_bgn,$dpolicy_end,$drate_bgn,$drate_end,$dexpire,$iupdate;

   if(SQLCODE != 0) goto errexit;

	cm_buf_init(ReplyBuf);
	cm_buf_put("%l",M_CM_OK);
	tmp_len = cm_buf_len(ReplyBuf);
	api_f = api_OKComplete;

	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
	{
		is_add_fail = 2;
	}

	if( is_add_fail == 1 ) goto errexit;

	if( is_add_fail == 2 )
	{
		$ROLLBACK WORK;
		return apiRC;
	}
	
	$WHENEVER SQLERROR GOTO errexit;

	$COMMIT WORK;
	return api_OKComplete;

errexit:
	MsgCode = SQLCODE;
	$WHENEVER SQLERROR CONTINUE;
	$ROLLBACK WORK;
	if (SQLCODE != 0) MsgCode = SQLCODE;		/* rollback fail */
	if(exitsub(reply,MsgCode) ==	True)
		return MsgCode;
	else
		return apiRC;
}

long car144_single_query(reply)
serverReply reply;
{
	$char DBName[5];
	$char provision[7],iassured[13],iofficer[11],iins_cat[2],iins_type[7],icar_type[3];
	$char iassured_name[22],iofficer_name[11];
	$char dpolicy_bgn[11],dpolicy_end[11],drate_bgn[11],drate_end[11];
	$char strdpolicy_bgn[11],strdpolicy_end[11],strdrate_bgn[11],strdrate_end[11];
	$char iupdate[11],dupdate[20];
	$int  irate;
	/* �s�W���Τ���� add by sylvia 101.12.18 (1010918004_C1) */
	$char dexpire[11],strdexpire[11];

	int tmp_len;
	
	cm_buf_get("%s %s %s %s %s %s %s %s %s %s %s %s ",DBName, provision ,iassured, iofficer, iins_cat, iins_type, icar_type, strdpolicy_bgn, strdpolicy_end,
                                                      strdrate_bgn, strdrate_end, strdexpire);

	if(strlen(trim(strdpolicy_bgn)) > 0)
	{
		strcpy(dpolicy_bgn,cm_to_infdate(strdpolicy_bgn));
		strcpy(dpolicy_end,cm_to_infdate(strdpolicy_end));
	}
	
	if(strlen(trim(strdrate_bgn)) > 0)
	{
		strcpy(drate_bgn,cm_to_infdate(strdrate_bgn));
		strcpy(drate_end,cm_to_infdate(strdrate_end));
	}

	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}

	/* ���Τ� */
	strcpy(strdexpire, trim(strdexpire));
	if (strlen(strdexpire) > 0 )
	{
		strcpy(dexpire,cm_to_infdate(strdexpire));
		printf("1:dexpire=[%s]iassured=[%s]iofficer=[%s]\n",dexpire,iassured,iofficer);
		printf("1:iins_cat=[%s]iins_type=[%s]\n",iins_cat,iins_type);
		
		if(strlen(trim(strdpolicy_bgn)) > 0 && strlen(trim(strdrate_bgn)) > 0)	/*��ñ���B�ͮĤ�*/
		{
			$SELECT Irate, Iupdate, Dupdate
			   INTO $irate, $iupdate, $dupdate
			   FROM ca_id_officer
			  WHERE provision = $provision
			    AND Iassured = $iassured
			    AND Iofficer = $iofficer
			    AND Iins_cat = $iins_cat
			    AND Iins_type = $iins_type
			    AND icar_type = $icar_type
			    AND dpolicy_bgn = $dpolicy_bgn
			    AND dpolicy_end = $dpolicy_end
			    AND Drate_bgn = $drate_bgn
			    AND Drate_end = $drate_end
			    AND dexpire = $dexpire;
		}
		else if(strlen(trim(strdpolicy_bgn)) > 0)	/*��ñ���*/
		{
			$SELECT Irate, Iupdate, Dupdate
			   INTO $irate, $iupdate, $dupdate
			   FROM ca_id_officer
			  WHERE provision = $provision
			    AND Iassured = $iassured
			    AND Iofficer = $iofficer
			    AND Iins_cat = $iins_cat
			    AND Iins_type = $iins_type
			    AND icar_type = $icar_type
			    AND dpolicy_bgn = $dpolicy_bgn
			    AND dpolicy_end = $dpolicy_end
			    AND dexpire = $dexpire;
		}
		else	/*�ͮĤ�*/
		{
			$SELECT Irate, Iupdate, Dupdate
			   INTO $irate, $iupdate, $dupdate
			   FROM ca_id_officer
			  WHERE provision = $provision
			    AND Iassured = $iassured
			    AND Iofficer = $iofficer
			    AND Iins_cat = $iins_cat
			    AND Iins_type = $iins_type
			    AND icar_type = $icar_type
			    AND Drate_bgn = $drate_bgn
			    AND Drate_end = $drate_end
			    AND dexpire = $dexpire;
		}
	}
	else
	{
		printf("2:dexpire=[%s]iassured=[%s]iofficer=[%s]\n",dexpire,iassured,iofficer);
		printf("2:iins_cat=[%s]iins_type=[%s]\n",iins_cat,iins_type);

		if(strlen(trim(strdpolicy_bgn)) > 0 && strlen(trim(strdrate_bgn)) > 0)
		{
			$SELECT Irate, Iupdate, Dupdate
			   INTO $irate, $iupdate, $dupdate
		 	   FROM ca_id_officer
			  WHERE provision = $provision
			    AND Iassured = $iassured
			    AND Iofficer = $iofficer
			    AND Iins_cat = $iins_cat
			    AND Iins_type = $iins_type
		 	    AND icar_type = $icar_type
			    AND dpolicy_bgn = $dpolicy_bgn
			    AND dpolicy_end = $dpolicy_end
			    AND Drate_bgn = $drate_bgn
			    AND Drate_end = $drate_end
			    AND dexpire is null;
		}
		else if(strlen(trim(strdpolicy_bgn)) > 0)
		{
			$SELECT Irate, Iupdate, Dupdate
			   INTO $irate, $iupdate, $dupdate
			   FROM ca_id_officer
			  WHERE provision = $provision
			    AND Iassured = $iassured
			    AND Iofficer = $iofficer
			    AND Iins_cat = $iins_cat
			    AND Iins_type = $iins_type
			    AND icar_type = $icar_type
			    AND dpolicy_bgn = $dpolicy_bgn
			    AND dpolicy_end = $dpolicy_end
			    AND dexpire is null;
		}
		else
		{
			$SELECT Irate, Iupdate, Dupdate
			   INTO $irate, $iupdate, $dupdate
			   FROM ca_id_officer
			  WHERE provision = $provision
			    AND Iassured = $iassured
			    AND Iofficer = $iofficer
			    AND Iins_cat = $iins_cat
			    AND Iins_type = $iins_type
			    AND icar_type = $icar_type
			    AND Drate_bgn = $drate_bgn
			    AND Drate_end = $drate_end
			    AND dexpire is null;
		}
	}

	if(SQLCODE==SQLNOTFOUND)
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True)
			return M_CM_NOT_FOUND;
		else
			return apiRC;
	}

	/* �Q�O�I�H���� */
	$SELECT nchi_full[1,20]
	   INTO $iassured_name
	   FROM cu_customer
	  WHERE ifpce_id = $iassured
	    AND ifpce_id_ext = '';
	/* �g��H���� */
	$SELECT nname
	   INTO $iofficer_name
	   FROM officer
	  WHERE iofficer = $iofficer;

	cm_buf_init(ReplyBuf);
	cm_buf_put("%l %s %s %s %s %s %s %s %s %d %s %s %s %s %s %s %s",M_CM_OK, provision, iassured, iassured_name, iofficer, iofficer_name,
	            iins_cat, iins_type, icar_type, irate, strdpolicy_bgn, strdpolicy_end, strdrate_bgn, strdrate_end, strdexpire, iupdate, dupdate);
	tmp_len = cm_buf_len(ReplyBuf);
	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
		return apiRC;
	else
		return api_OKComplete;

errexit:
	if(exitsub(reply,SQLCODE) == True)
		return SQLCODE;
	else
		return apiRC;
}

long car144_multiple_query(reply)
serverReply reply;
{
	$char DBName[5];
	$char provision[7],iassured[13],iofficer[11],iins_cat[2],iins_type[7],icar_type[3];
	$int  irate;
	$char tmp_provision[7],tmp_iassured[13],tmp_iofficer[11],tmp_iins_cat[2],tmp_iins_type[7];
	$char strdpolicy[11],strdrate[11],tmp_drate[11],tmp_dpolicy[11],tmp_icar_type[3];
	$char dpolicy_bgn[11],dpolicy_end[11],drate_bgn[11],drate_end[11];
	$char strdpolicy_bgn[11],strdpolicy_end[11],strdrate_bgn[11],strdrate_end[11];
	$char stmt[1024];
	
	char tmpbuf[4000],stmt_dpolicy[128],stmt_drate[128], stmt_dexpire[200];
	int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
	int i,total_count=0;

	/* �s�W���Τ���� add by sylvia 101.12.18 (1010918004_C1) */
	$char dexpire[11],strdexpire[11],tmp_dexpire[11];
	
	cm_buf_get("%s %s %s %s %s %s %s %s %s",DBName, tmp_iassured, tmp_iofficer, tmp_iins_cat, tmp_iins_type, tmp_icar_type, strdpolicy, strdrate, strdexpire);
	
	strcpy(tmp_dpolicy,cm_to_infdate(strdpolicy));
	strcpy(tmp_drate,cm_to_infdate(strdrate));
	strcpy(strdexpire, trim(strdexpire));

	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}
	
	if (strcmp(trim(strdrate),"*") != 0)
	{
		strcpy(tmp_drate,cm_to_infdate(strdrate));
		sprintf(stmt_drate,"AND '%s' BETWEEN drate_bgn AND drate_end ",tmp_drate);
	} 
	else
	{
		strcpy(stmt_drate,"");
	}
	
	if (strcmp(trim(strdpolicy),"*") != 0)
	{
		strcpy(tmp_dpolicy,cm_to_infdate(strdpolicy));
		sprintf(stmt_dpolicy,"AND '%s' BETWEEN dpolicy_bgn AND dpolicy_end",tmp_dpolicy);
	}
	else
	{
		strcpy(stmt_dpolicy,"");
	}
	
	if (strcmp(trim(strdexpire),"*") != 0)
	{
		strcpy(tmp_dexpire,cm_to_infdate(strdexpire));
		sprintf(stmt_dexpire,"AND dexpire = '%s'",tmp_dexpire);
	}
	else
	{
		strcpy(stmt_dexpire,"");
	}

	sprintf(stmt,
	"select provision, Iassured, Iofficer, Iins_cat, Iins_type, icar_type, nvl(dpolicy_bgn,''), nvl(dpolicy_end,''), nvl(Drate_bgn,''), nvl(Drate_end,''), Irate, nvl(dexpire,'') \
	   from ca_id_officer \
	  where Iassured matches ? \
	    and Iofficer matches ? \
	    and Iins_cat matches ? \
	    and Iins_type matches ? \
	    and icar_type matches ? %s %s %s",stmt_dpolicy,stmt_drate,stmt_dexpire);
	printf("stmt[%s]\n",stmt);

	$PREPARE CUR_CAID FROM $stmt;
	$DECLARE IDcur CURSOR FOR CUR_CAID;
	$OPEN IDcur USING $tmp_iassured,$tmp_iofficer,$tmp_iins_cat,$tmp_iins_type,$tmp_icar_type;

	for(;;)
	{
		$FETCH IDcur INTO $provision,$iassured,$iofficer,$iins_cat,$iins_type,$icar_type,$dpolicy_bgn,$dpolicy_end,$drate_bgn,$drate_end,$irate,$dexpire;
		if (SQLCODE != 0) break;
		
		cm_buf_init(tmpbuf);
		if ( count == 0 )
		{
			cm_buf_res_msg();             /* reserve for MsgCode and count */
			cm_buf_res_count();
		}

		/* Convert Era Date to Chinese Date */
		strcpy(strdpolicy_bgn, cm_from_infdate_100(dpolicy_bgn));
		strcpy(strdpolicy_end, cm_from_infdate_100(dpolicy_end));
		strcpy(strdrate_bgn, cm_from_infdate_100(drate_bgn));
		strcpy(strdrate_end, cm_from_infdate_100(drate_end));
		strcpy(strdexpire, cm_from_infdate_100(dexpire));
		
		cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %d", provision, iassured, iofficer, iins_cat, iins_type, icar_type, strdpolicy_bgn,strdpolicy_end , strdrate_bgn, strdrate_end, strdexpire, irate);
		tmp_len = cm_buf_len(tmpbuf);
		if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
		{
			memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
			repbuf_len += tmp_len;
			count++;
		}
		else                               /* more than 4K, send to client side */
		{
			cm_buf_init(ReplyBuf);
			cm_buf_put_msg(M_CM_OK);
			cm_buf_put_count(count);
			if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
			{
				$CLOSE IDcur;
				return apiRC;
			}
			else               /* clear ReplyBuf and count to start all over again */
			{
				replycnt++;
				if (replycnt == 10)   /* more than 30K, client cannot display,error */
				{
					cm_buf_init(ReplyBuf);
					cm_buf_put("%l",M_CM_OUT_SPACE);
					tmp_len = cm_buf_len(ReplyBuf);
					if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
						return apiRC;
					return M_CM_OUT_SPACE;
				}
				ReplyBuf[0] = '\0';
				count = 0;
				cm_buf_init(ReplyBuf);
				cm_buf_res_msg();           /* reserve for MsgCode and count */
				cm_buf_res_count();
				cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %d", provision, iassured, iofficer, iins_cat, iins_type, icar_type, strdpolicy_bgn,strdpolicy_end , strdrate_bgn,strdrate_end, strdexpire, irate);
				repbuf_len = cm_buf_len(ReplyBuf);
				count++;
			}
		}
	} /* for loop */

	$CLOSE IDcur;
	if (count > 0)   /* break out, at least one record is selected */
	{
		cm_buf_init(ReplyBuf);
		cm_buf_put_msg(M_CM_OK);
		cm_buf_put_count(count);
		if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
		return apiRC;
		return api_OKComplete;
	}
	else            /* break out, not any row is found */
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
			return M_CM_NOT_FOUND;                               /*?*/
		else
			return apiRC;
	}

errexit:
	if(exitsub(reply,SQLCODE) == True)
		return SQLCODE;
	else
		return apiRC;
}

long car144_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	$char DBName[5];
	$char provision[7],iassured[13],iofficer[11],iins_cat[2],iins_type[7],icar_type[3];
	$char old_provision[7],old_iassured[13],old_iofficer[11],old_iins_cat[2],old_iins_type[7];
	$char old_drate[11],old_icar_type[3];
	$int irate;
	$char old_irate[10],strirate[10],old_iupdate[11],old_dupdate[20];
	$char iupdate[11],dbdupdate[20],dupdate[20];
	$char old_cname[22],old_nname[11];
	$char dpolicy_bgn[11],dpolicy_end[11],drate_bgn[11],drate_end[11];
	$char old_dpolicy_bgn[11],old_dpolicy_end[11],old_drate_bgn[11],old_drate_end[11];
	$char strdpolicy_bgn[11],strdpolicy_end[11],strdrate_bgn[11],strdrate_end[11];
	
	char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
	int tmp_len,raw_len;
	long dummy;
	long MsgCode;
	DBinfo *list;
	int i, j, is_upd_fail=0,is_del_fail=0;
	$char stmt_buf[1024];
	$char dexpire[11],strdexpire[11],old_dexpire[11];
	$int  chk_PF;

	comm = (char *) command;
	cm_buf_init(command);
	cm_buf_get("%c %s",&option,DBName);
	
	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == False)
	{
		if (exitsub(reply,M_CM_DB_NOTOPEN) == True) return M_CM_DB_NOTOPEN;
		else	return apiRC;
	}
	
	if ( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
	{
		if (exitsub(reply,M_CM_NOT_DBLIST) == True)	return M_CM_NOT_DBLIST;
		return apiRC;
	}

	/* get old record info from command buffer */
	memcpy(&raw_len,&comm[com_len],sizeof(int));
	pos = &comm[com_len+sizeof(int)];
	raw_ptr = malloc(raw_len);

	if (raw_ptr != (char*)0) {
		memcpy(raw_ptr,pos,raw_len);
	}
	else
	{
		if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */
			return M_CM_NOT_MALLOC;
		else
			return apiRC;
	}

	cm_buf_init(raw_ptr);          /* get index key from old record */
	printf("see if it's here!!\n");

	cm_buf_get("%l %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",&dummy, old_provision, old_iassured,
	                                                                old_cname, old_iofficer, old_nname, old_iins_cat, old_iins_type,
	                                                                old_icar_type, old_irate, strdpolicy_bgn, strdpolicy_end,
	                                                                strdrate_bgn, strdrate_end, strdexpire, old_iupdate,old_dupdate);

	if(strlen(trim(strdpolicy_bgn)) > 0)
	{
		strcpy(old_dpolicy_bgn,cm_to_infdate(strdpolicy_bgn));
		strcpy(old_dpolicy_end,cm_to_infdate(strdpolicy_end));
	}
	else
	{
		strcpy(old_dpolicy_bgn,"");
		strcpy(old_dpolicy_end,"");
	}
	
	if(strlen(trim(strdrate_bgn)) > 0)
	{
		strcpy(old_drate_bgn,cm_to_infdate(strdrate_bgn));
		strcpy(old_drate_end,cm_to_infdate(strdrate_end));
	}
	else
	{
		strcpy(old_drate_bgn,"");
		strcpy(old_drate_end,"");
	}
	
	strcpy(strdexpire, trim(strdexpire));
	strcpy(old_dexpire,cm_to_infdate(strdexpire));
	sprintf("old_dexpire=[%s]\n",old_dexpire);

	$BEGIN WORK;
	$WHENEVER SQLERROR GOTO errexit;
	/* table lock is necessary to avoid concurrent update problems */
	$LOCK TABLE ca_id_officer IN SHARE MODE;

	if (strlen(strdexpire) > 0)
	{
		if(strlen(trim(old_dpolicy_bgn)) > 0 && strlen(trim(old_drate_bgn)) > 0)
		{
			$SELECT Dupdate
	           INTO $dbdupdate
	           FROM ca_id_officer
	          WHERE provision = $old_provision
	            AND Iassured = $old_iassured
	            AND Iofficer = $old_iofficer
	            AND Iins_cat = $old_iins_cat
	            AND Iins_type = $old_iins_type
	            AND icar_type = $old_icar_type
	            AND Dpolicy_bgn = $old_dpolicy_bgn
	            AND Dpolicy_end = $old_dpolicy_end
	            AND Drate_bgn = $old_drate_bgn
	            AND Drate_end = $old_drate_end
	            AND dexpire = $old_dexpire;
		}
		else if (strlen(trim(old_dpolicy_bgn)) > 0)
		{
			$SELECT Dupdate
	           INTO $dbdupdate
	           FROM ca_id_officer
	          WHERE provision = $old_provision
	            AND Iassured = $old_iassured
	            AND Iofficer = $old_iofficer
	            AND Iins_cat = $old_iins_cat
	            AND Iins_type = $old_iins_type
	            AND icar_type = $old_icar_type
	            AND Dpolicy_bgn = $old_dpolicy_bgn
	            AND Dpolicy_end = $old_dpolicy_end
	            AND dexpire = $old_dexpire;
		}
		else
		{
			$SELECT Dupdate
	           INTO $dbdupdate
	           FROM ca_id_officer
	          WHERE provision = $old_provision
	            AND Iassured = $old_iassured
	            AND Iofficer = $old_iofficer
	            AND Iins_cat = $old_iins_cat
	            AND Iins_type = $old_iins_type
	            AND icar_type = $old_icar_type
	            AND Drate_bgn = $old_drate_bgn
	            AND Drate_end = $old_drate_end
	            AND dexpire = $old_dexpire;
		}
   	}
   	else
   	{
  		if(strlen(trim(old_dpolicy_bgn)) > 0 && strlen(trim(old_drate_bgn)) > 0)
		{
			$SELECT Dupdate
	           INTO $dbdupdate
	           FROM ca_id_officer
	          WHERE provision = $old_provision
	            AND Iassured = $old_iassured
	            AND Iofficer = $old_iofficer
	            AND Iins_cat = $old_iins_cat
	            AND Iins_type = $old_iins_type
	            AND icar_type = $old_icar_type
	            AND Dpolicy_bgn = $old_dpolicy_bgn
	            AND Dpolicy_end = $old_dpolicy_end
	            AND Drate_bgn = $old_drate_bgn
	            AND Drate_end = $old_drate_end
	            AND dexpire is null;
		}
		else if (strlen(trim(old_dpolicy_bgn)) > 0)
		{
			$SELECT Dupdate
	           INTO $dbdupdate
	           FROM ca_id_officer
	          WHERE provision = $old_provision
	            AND Iassured = $old_iassured
	            AND Iofficer = $old_iofficer
	            AND Iins_cat = $old_iins_cat
	            AND Iins_type = $old_iins_type
	            AND icar_type = $old_icar_type
	            AND Dpolicy_bgn = $old_dpolicy_bgn
	            AND Dpolicy_end = $old_dpolicy_end
	            AND dexpire is null;
		}
		else
		{
			$SELECT Dupdate
	           INTO $dbdupdate
	           FROM ca_id_officer
	          WHERE provision = $old_provision
	            AND Iassured = $old_iassured
	            AND Iofficer = $old_iofficer
	            AND Iins_cat = $old_iins_cat
	            AND Iins_type = $old_iins_type
	            AND icar_type = $old_icar_type
	            AND Drate_bgn = $old_drate_bgn
	            AND Drate_end = $old_drate_end
	            AND dexpire is null;
		}
    }
 	
	if (SQLCODE == SQLNOTFOUND)
	{
		$WHENEVER SQLERROR CONTINUE;
		$ROLLBACK WORK;
		if (exitsub(reply,M_CM_NOT_FOUND) == True)
			return M_CM_NOT_FOUND;
		else
			return apiRC;
	}
	printf("org. dentry=[%s],db. dentry[%s]\n",old_dupdate,dbdupdate);

	if (strcmp(old_dupdate,dbdupdate) != 0)
	{
		$WHENEVER SQLERROR CONTINUE;
		$ROLLBACK WORK;
		if(exitsub(reply,M_CM_NOT_EQUAL) == True)
			return M_CM_NOT_EQUAL;
		else
			return apiRC;
	}

 	$WHENEVER SQLERROR GOTO errexit;
 	/* equal, then exec DB operation */
	if ( option == 'D' )
	{
		for(j=0;j<i;j++)
		{
			if (strlen(trim(old_dexpire)) == 0)
			{
				if(strlen(trim(old_dpolicy_bgn)) != 0 && strlen(trim(old_drate_bgn)) != 0)
				{
					sprintf(stmt_buf,"DELETE FROM %s:ca_id_officer WHERE provision = ? AND Iassured=? \
			 						                                 AND Iofficer=? AND Iins_cat=? AND Iins_type=? \
			 						                                 AND icar_type=? AND dpolicy_bgn=? AND dpolicy_end=? \
			 						                                 AND drate_bgn=? AND drate_end=? AND dexpire is null" ,list[j].dbname);
					$PREPARE d_idx1 FROM $stmt_buf;
					$EXECUTE d_idx1 USING $old_provision,$old_iassured,$old_iofficer,$old_iins_cat,
					                      $old_iins_type,$old_icar_type,$old_dpolicy_bgn,$old_dpolicy_end,
					                      $old_drate_bgn,$old_drate_end;
				}
				else if(strlen(trim(old_dpolicy_bgn)) != 0)
				{
					sprintf(stmt_buf,"DELETE FROM %s:ca_id_officer WHERE provision = ? AND Iassured=? \
			 						                                 AND Iofficer=? AND Iins_cat=? AND Iins_type=? \
			 						                                 AND icar_type=? AND dpolicy_bgn=? AND dpolicy_end=? \
			 						                                 AND dexpire is null" ,list[j].dbname);
					$PREPARE d_idx2 FROM $stmt_buf;
					$EXECUTE d_idx2 USING $old_provision,$old_iassured,$old_iofficer,$old_iins_cat,
					                      $old_iins_type,$old_icar_type,$old_dpolicy_bgn,$old_dpolicy_end;
				}
				else
				{
					sprintf(stmt_buf,"DELETE FROM %s:ca_id_officer WHERE provision = ? AND Iassured=? \
			 						                                 AND Iofficer=? AND Iins_cat=? AND Iins_type=? \
			 						                                 AND icar_type=? AND drate_bgn=? AND drate_end=? AND dexpire is null" ,list[j].dbname);
					$PREPARE d_idx3 FROM $stmt_buf;
					$EXECUTE d_idx3 USING $old_provision,$old_iassured,$old_iofficer,$old_iins_cat,
					                      $old_iins_type,$old_icar_type,$old_drate_bgn,$old_drate_end;
				}
			}
   			else
   			{
   				if(strlen(trim(old_dpolicy_bgn)) != 0 && strlen(trim(old_drate_bgn)) != 0)
   				{
   					sprintf(stmt_buf,"DELETE FROM %s:ca_id_officer WHERE provision = ? AND Iassured=? \
		     						                                 AND Iofficer=? AND Iins_cat=? AND Iins_type=? \
		     						                                 AND icar_type=? AND dpolicy_bgn=? AND dpolicy_end=? \
		     						                                 AND drate_bgn=? AND drate_end=? AND dexpire = ?" ,list[j].dbname);
		    		$PREPARE d_id1 FROM $stmt_buf;
		    		$EXECUTE d_id1 USING $old_provision,$old_iassured,$old_iofficer,$old_iins_cat,
		    		                     $old_iins_type,$old_icar_type,$old_dpolicy_bgn,$old_dpolicy_end,
		    		                     $old_drate_bgn,$old_drate_end,$old_dexpire;
   				}
   				else if(strlen(trim(old_dpolicy_bgn)) != 0)
   				{
   					sprintf(stmt_buf,"DELETE FROM %s:ca_id_officer WHERE provision = ? AND Iassured=? \
		     						                                 AND Iofficer=? AND Iins_cat=? AND Iins_type=? \
		     						                                 AND icar_type=? AND dpolicy_bgn=? AND dpolicy_end=? \
		     						                                 AND dexpire = ?" ,list[j].dbname);
		    		$PREPARE d_id2 FROM $stmt_buf;
		    		$EXECUTE d_id2 USING $old_provision,$old_iassured,$old_iofficer,$old_iins_cat,
		    		                     $old_iins_type,$old_icar_type,$old_dpolicy_bgn,$old_dpolicy_end,$old_dexpire;
   				}
   				else
   				{
   					sprintf(stmt_buf,"DELETE FROM %s:ca_id_officer WHERE provision = ? AND Iassured=? \
		     						                                 AND Iofficer=? AND Iins_cat=? AND Iins_type=? \
		     						                                 AND icar_type=? AND drate_bgn=? AND drate_end=? AND dexpire = ?" ,list[j].dbname);
		    		$PREPARE d_id3 FROM $stmt_buf;
		    		$EXECUTE d_id3 USING $old_provision,$old_iassured,$old_iofficer,$old_iins_cat,
		    		                     $old_iins_type,$old_icar_type,$old_drate_bgn,$old_drate_end,$old_dexpire;
   				}
			}

			if(SQLCODE != 0)
			{
				is_del_fail = 1;
				break;
			}
		}/* for loop */
	
		if( is_del_fail ) goto errexit;
		
		cm_buf_init(ReplyBuf);
		cm_buf_put("%l",M_CM_OK);
		tmp_len = cm_buf_len(ReplyBuf);
	
		if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
		{
			$WHENEVER SQLERROR CONTINUE;
			$ROLLBACK WORK;
			return apiRC;
		}
	
		$WHENEVER SQLERROR GOTO errexit;
		$COMMIT WORK;
		return api_OKComplete;
	}
	else if (option == 'U')
	{
	   	cm_buf_init(command);
	   	cm_buf_get("%c %s",&option,DBName);
	   	cm_buf_get("%s %s %s %s %s %s %s %s %s %s %s %s %s", provision,iassured, iofficer, iins_cat, iins_type, icar_type, strirate, strdpolicy_bgn, strdpolicy_end,
  		                                                     strdrate_bgn, strdrate_end, strdexpire, iupdate);
		
		if(strlen(trim(strdpolicy_bgn)) > 0)
		{
			strcpy(dpolicy_bgn,cm_to_infdate(strdpolicy_bgn));
			strcpy(dpolicy_end,cm_to_infdate(strdpolicy_end));
		}
		else
		{
			strcpy(dpolicy_bgn,"");
			strcpy(dpolicy_end,"");
		}
		
		if(strlen(trim(strdrate_bgn)) > 0)
		{
			strcpy(drate_bgn,cm_to_infdate(strdrate_bgn));
			strcpy(drate_end,cm_to_infdate(strdrate_end));
		}
		else
		{
			strcpy(drate_bgn,"");
			strcpy(drate_end,"");
		}
		
		if(strlen(trim(strdexpire)) > 0)
			strcpy(dexpire,cm_to_infdate(strdexpire));
		else
			strcpy(dexpire,"");
		
		irate = atoi(strirate);

		printf("Iassured[%s],Iofficer[%s],Iins_cat[%s]\n",iassured,iofficer,iins_cat);
		printf("Iins_type[%s],icar_type[%s],Irate[%d]\n",iins_type,icar_type,irate);
		printf("dpolicy_bgn[%s],dpolicy_end[%s]\n",dpolicy_bgn,dpolicy_end);
		printf("Drate_bgn[%s],drate_end[%s]\n",drate_bgn,drate_end);
		printf("dexpire[%s],Iupdate[%s]\n",dexpire,iupdate);
		printf("old_iassured[%s],old_iofficer[%s],old_iins_cat[%s]\n",old_iassured,old_iofficer,old_iins_cat);
		printf("old_iins_type[%s],old_icar_type[%s]\n",old_iins_type,old_icar_type);
		printf("old_dpolicy_bgn[%s],old_dpolicy_end[%s]\n",old_dpolicy_bgn,old_dpolicy_end);
		printf("old_drate_bgn[%s],old_drate_end[%s]\n",old_drate_bgn,old_drate_end);
		printf("old_dexpire[%s]\n",old_dexpire);

		$WHENEVER SQLERROR CONTINUE;
		for(j=0;j<i;j++)
		{
	   		if(strlen(trim(old_dpolicy_bgn)) != 0 && strlen(trim(old_drate_bgn)) != 0)
	   		{
	   			sprintf(stmt_buf,"UPDATE %s:ca_id_officer SET \
			     		          (provision,Iassured,Iofficer,Iins_cat,Iins_type,icar_type,Irate,dpolicy_bgn,dpolicy_end,drate_bgn,drate_end, dexpire,Iupdate,Dupdate) \
			     		          = (?,?,?,?,?,?,?,?,?,?,?,?,?,current) \
			     		           WHERE provision =? AND Iassured=? AND Iofficer=? AND Iins_cat=? AND Iins_type=? \
			     		             AND icar_type=? AND dpolicy_bgn=? AND dpolicy_end=? \
			     		             AND Drate_bgn=? AND Drate_end=?",list[j].dbname);
				printf("1022stmt_buf[%s]\n",stmt_buf);
				$PREPARE u_id1 FROM $stmt_buf;
				$EXECUTE u_id1 USING $provision,$iassured,$iofficer,$iins_cat,$iins_type,$icar_type,$irate,$dpolicy_bgn,$dpolicy_end,$drate_bgn,$drate_end,$dexpire,$iupdate,
				                     $old_provision,$old_iassured,$old_iofficer,$old_iins_cat,$old_iins_type,$old_icar_type,
				                     $old_dpolicy_bgn,$old_dpolicy_end,$old_drate_bgn,$old_drate_end;
	   		}
	   		else if(strlen(trim(old_dpolicy_bgn)) != 0)
	   		{
	
	   			sprintf(stmt_buf,"UPDATE %s:ca_id_officer SET \
			     		          (provision,Iassured,Iofficer,Iins_cat,Iins_type,icar_type,Irate,dpolicy_bgn,dpolicy_end,drate_bgn,drate_end,dexpire,Iupdate,Dupdate) \
			     		          = (?,?,?,?,?,?,?,?,?,?,?,?,?,current) \
			     		           WHERE provision =? AND Iassured=? AND Iofficer=? AND Iins_cat=? AND Iins_type=? \
			     		             AND icar_type=? AND dpolicy_bgn=? AND dpolicy_end=? ",list[j].dbname);
				printf("1036stmt_buf[%s]\n",stmt_buf);
				$PREPARE u_id2 FROM $stmt_buf;
				$EXECUTE u_id2 USING $provision,$iassured,$iofficer,$iins_cat,$iins_type,$icar_type,$irate,$dpolicy_bgn, $dpolicy_end,$drate_bgn,$drate_end,$dexpire,$iupdate,
	       					         $old_provision,$old_iassured,$old_iofficer,$old_iins_cat,$old_iins_type,$old_icar_type,
	       					         $old_dpolicy_bgn,$old_dpolicy_end;
	   		}
	   		else
	   		{
	   			sprintf(stmt_buf,"UPDATE %s:ca_id_officer SET \
			     		          (provision,Iassured,Iofficer,Iins_cat,Iins_type,icar_type,Irate,dpolicy_bgn,dpolicy_end,Drate_bgn,drate_end,dexpire,Iupdate,Dupdate) \
			     		          = (?,?,?,?,?,?,?,?,?,?,?,?,?,current) \
			     		           WHERE provision =? AND Iassured=? AND Iofficer=? AND Iins_cat=? AND Iins_type=? \
			     		             AND icar_type=? AND Drate_bgn=? AND Drate_end=?",list[j].dbname);
				printf("1051stmt_buf[%s]\n",stmt_buf);
				$PREPARE u_id3 FROM $stmt_buf;
				$EXECUTE u_id3 USING $provision,$iassured,$iofficer,$iins_cat,$iins_type,$icar_type,$irate,$dpolicy_bgn,$dpolicy_end,$drate_bgn,$drate_end,$dexpire,$iupdate,
				                     $old_provision,$old_iassured,$old_iofficer,$old_iins_cat,$old_iins_type,$old_icar_type,
				                     $old_drate_bgn,$old_drate_end;
	   		}

    		if(SQLCODE != 0)
     		{
      			is_upd_fail = 1;
      			break;
     		}
    		if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
     		{
  				sprintf(stmt_buf,"INSERT INTO %s:ca_id_officer \
         			              (provision,Iassured,Iofficer,Iins_cat,Iins_type,icar_type,Irate,dpolicy_bgn,dpolicy_end,Drate_bgn,drate_end,dexpire,Iupdate)\
	 					          VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",list[j].dbname);

      			$PREPARE ua_id FROM $stmt_buf;
	      		if(SQLCODE != 0)
	       		{
	        			is_upd_fail = 1;
	        			break;
	       		}
	      			$EXECUTE ua_id USING $provision,$iassured,$iofficer,$iins_cat,$iins_type,$icar_type,$irate,$dpolicy_bgn,$dpolicy_end,$drate_bgn,$drate_end,$dexpire,$iupdate;
	      		if(SQLCODE != 0)
	       		{
	        			is_upd_fail = 1;
	        			break;
	       		}
			}
		} /* for loop */

		if( is_upd_fail ) goto errexit;

		cm_buf_init(ReplyBuf);
		cm_buf_put("%l",M_CM_OK);
		tmp_len = cm_buf_len(ReplyBuf);
		if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
		{
			$WHENEVER SQLERROR CONTINUE;
			$ROLLBACK WORK;
			return apiRC;
		}

		$WHENEVER SQLERROR GOTO errexit;
		$COMMIT WORK;
		return api_OKComplete;
	} 
	else 
	{
		if(exitsub(reply,M_CM_WRONG_OPTION) == True)
			return M_CM_WRONG_OPTION;
		else
			return apiRC;
	}
errexit:
	$WHENEVER SQLERROR CONTINUE;
	MsgCode = SQLCODE;
	$ROLLBACK WORK;
	if (SQLCODE != 0) MsgCode = SQLCODE;
	if(exitsub(reply,MsgCode) == True)
		return MsgCode;
	else
		return apiRC;
}

/* Check Iassured and get Chinese Name */
long car144_CHT_iassured(reply)
serverReply reply;
{
	$char DBName[5];
	$char assured_code[11];
	$char assured_name[22];
	int tmp_len;
	
	cm_buf_get("%s %s",DBName, assured_code);
	
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}
	
	$SELECT first 1 nchi_full[1,20]
	   INTO $assured_name
	   FROM cu_customer
	  WHERE ifpce_id=$assured_code;
	
	if(SQLCODE==SQLNOTFOUND)
	{
		if(exitsub(reply,M_CM_NASSURED) == True)       /*?*/
			return M_CM_NASSURED;                        /*?*/
		else
			return apiRC;
	}
	
	cm_buf_init(ReplyBuf);
	cm_buf_put("%l %s",M_CM_OK, assured_name);
	
	tmp_len = cm_buf_len(ReplyBuf);
	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
		return apiRC;
	else
		return api_OKComplete;

	errexit:
	return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/* ��ƾ��W�� */
long car144_insert_batch(reply)
serverReply reply;
{
	$char DBName[5], stmt[2048], stmt1[2048], stmt_buf[300];
	char  sApHome[30], filename[101],logname[101], cmd_str[2048], userid[11];
	$char iassured[13],iofficer[11],iins_cat[2],iins_type[7],icar_type[3];
	$char dpolicy_bgn[11],dpolicy_end[11],drate_bgn[11],drate_end[11],dexpire[11];
	$char iupdate[7],dupdate[11];
	$int  rc, cnt, rc1 ,irate;
	int   stmt_len;
	int i, j, is_add_fail=0, api_f;
	long MsgCode;
	$char provision[7],tmp_provision[7];
	$int count2,chk_PF;

	rc = getApHome(sApHome);
	if (rc<0) {
		strcpy( errbuf,"read Config file error!!-->getApHome\n");
		return rc;
	}

	sprintf(filename,"%s/dat/car/car144.txt", sApHome);
	sprintf(logname,"%s/rptftp/car144_log.txt",sApHome);

	cm_buf_get("%s %s",DBName, userid);
	
	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == False)
	{
		sprintf(errbuf,"��Ʈw�L�k�}��[%s]\n", DBName);
		return M_CM_DB_NOTOPEN;
	}

	/* ����J�Ȧs��,�T�{��J���O�_���T */
	stmt_len = 0;
	stmt_len += sprintf(stmt+stmt_len, "select * from ca_id_officer where 1=0 into temp temp1 with no log;\r\n");
	stmt_len += sprintf(stmt+stmt_len, "load from %s delimiter '\t' insert into temp1; \r\n", filename);
	sprintf(cmd_str,"dbaccess sysdb > %s 2>&1 << !\r\n"
	                "%s\r\n!", logname, stmt);

	printf("cmd_str[%s]\n",cmd_str);
	rc = system(cmd_str);
	if (rc != 0) {
		sprintf(errbuf,"load file error[%s]\n���I���ɮפU���@�~�d��[Q],�T�{���~��]", logname);
		rc1=rptftpinsert(userid,"car144","car144_log.txt");
		return rc;
	}

	/********************************************************************************************/
	/* �P�_�ͮ�(ñ��)��϶��O�_���| BEGIN */
	sprintf(getfile,"%s/dat/car/car144.txt",sApHome);
	
	if ((fp=fopen(getfile,"rt"))==NULL)
	{
		return SQLCODE;
	}
	
	if ((bp=malloc(recLen))==NULL)
	{
		printf("System malloc failed  !\n");
		return SQLCODE;
	}

	/* ���j�Ÿ� */
	delimiter = '\t';
	
	$CREATE TEMP table temp2
	(
		iassured 		char(12),
		iofficer 		char(10),
		iins_cat 		char(1),
		iins_type 		char(6),
		icar_type 		char(2),
		irate 		    int,
		provision       char(6),
		dpolicy_bgn 	date,
		dpolicy_end 	date,
		drate_bgn 		date,
		drate_end 		date,
		dexpire 		date
	)with no log;

	while(fgets(bp,recLen,fp))
	{
		if (feof(fp)) break;
		offset = 0;
		/* ��ƨ��o���Ǥ��i�ܰ�*/
		GetData(iassured,     sizeof(iassured),	    delimiter);
		GetData(iofficer,     sizeof(iofficer),     delimiter);
		GetData(iins_cat,     sizeof(iins_cat),	    delimiter);
		GetData(iins_type,    sizeof(iins_type),    delimiter);
		GetData(icar_type,    sizeof(icar_type),    delimiter);
		GetData(irate,        sizeof(irate),        delimiter);
		GetData(provision,    sizeof(provision),    delimiter);
		GetData(dpolicy_bgn,  sizeof(dpolicy_bgn),  delimiter);
		GetData(dpolicy_end,  sizeof(dpolicy_end),  delimiter);
		GetData(drate_bgn,    sizeof(drate_bgn),    delimiter);
		GetData(drate_end,    sizeof(drate_end),    delimiter);
		GetData(dexpire,      sizeof(dexpire),      delimiter);
		GetData(iupdate,      sizeof(iupdate),      delimiter);
		GetData(dupdate,      sizeof(dupdate),      delimiter);

		printf("iassured[%s]iofficer[%s]iins_cat[%s]iins_type[%s]\n",iassured,iofficer,iins_cat,iins_type);
		printf("icar_type[%s]irate[%d]\n",icar_type,irate);
		printf("dpolicy_bgn[%s]dpolicy_end[%s]\n",dpolicy_bgn,dpolicy_end);
		printf("drate_bgn[%s]drate_end[%s]\n",drate_bgn,drate_end);
		printf("dexpire[%s]iupdate[%s]dupdate[%s]\n",dexpire,iupdate,dupdate);

		$insert into temp2(iassured,iofficer,iins_cat,iins_type,icar_type,irate,provision,dpolicy_bgn,dpolicy_end,drate_bgn,drate_end,dexpire)
		  values ($iassured,$iofficer,$iins_cat,$iins_type,$icar_type,$irate,$provision,$dpolicy_bgn,$dpolicy_end,$drate_bgn,$drate_end,$dexpire);

	}
	fclose(fp);

	sprintf(stmt1, "select Iassured, Iofficer, Iins_cat, Iins_type, icar_type, provision, nvl(dpolicy_bgn,''), nvl(dpolicy_end,''), \
	                       nvl(drate_bgn,''), nvl(drate_end,''), nvl(dexpire,'') \
                      from temp2 " );
	printf("stmt1=[%s]\n",stmt1);

	$PREPARE CUR_CAID_1 FROM $stmt1;
	$DECLARE IDcur_1 CURSOR FOR CUR_CAID_1;
	$OPEN IDcur_1;

	for(;;)
	{

		$FETCH IDcur_1 INTO $iassured,$iofficer,$iins_cat,$iins_type,$icar_type,$provision,$dpolicy_bgn,$dpolicy_end,$drate_bgn,$drate_end,$dexpire;
		
		if (SQLCODE != 0) break;
		
		if(strlen(trim(drate_bgn)) > 0)
		{
			$SELECT count(*)
			   INTO $count1
			   FROM ca_id_officer
			  WHERE provision = $provision
			    AND iassured = $iassured
			    AND iofficer = $iofficer
			    AND iins_cat = $iins_cat
			    AND iins_type = $iins_type
			    AND icar_type = $icar_type
			    AND (drate_bgn BETWEEN $drate_bgn AND $drate_end OR
			         drate_end BETWEEN $drate_bgn AND $drate_end OR
			         $drate_bgn BETWEEN drate_bgn AND drate_end OR
			         $drate_end BETWEEN drate_bgn AND drate_end);
		
			if(count1 >= 1)
			{
				strcpy(errbuf,"��ƭ���");
				$CLOSE IDcur_1;
				$FREE IDcur_1;
				$DROP TABLE temp2;
				return SQLCODE;
			}
		}
		
		if(strlen(trim(dpolicy_bgn)) > 0)
		{
			$SELECT count(*)
			   INTO $count1
			   FROM ca_id_officer
			  WHERE provision = $provision
			    AND iassured = $iassured
			    AND iofficer = $iofficer
			    AND iins_cat = $iins_cat
			    AND iins_type = $iins_type
			    AND icar_type = $icar_type
			    AND (dpolicy_bgn BETWEEN $dpolicy_bgn AND $dpolicy_end OR
			         dpolicy_end BETWEEN $dpolicy_bgn AND $dpolicy_end OR
			         $dpolicy_bgn BETWEEN dpolicy_bgn AND dpolicy_end OR
			         $dpolicy_end BETWEEN dpolicy_bgn AND dpolicy_end);
		
			if(count1 >= 1)
			{
				strcpy(errbuf,"��ƭ���");
				$CLOSE IDcur_1;
				$FREE IDcur_1;
				$DROP TABLE temp2;
				return SQLCODE;
			}
		}
		/* �P�_�ͮ�(ñ��)��϶��O�_���| END */
		
		/* �P�_�I�جO�_��CAR140.PF�]�w���I�� */
		chk_PF = 0;
		$SELECT count(*)
		   INTO $chk_PF
		   FROM car_code
		  WHERE kind = 'PF' AND detail = $iins_type;
		printf("chk_PF[%d]\n",chk_PF);
		if (chk_PF == 0)
		{
			strcpy(errbuf,"�I�ض���CAR140���OPF�]�w���I��");
			$CLOSE IDcur_1;
			$FREE IDcur_1;
			$DROP TABLE temp2;
			return SQLCODE;
		}
	}
	$CLOSE IDcur_1;
	$FREE IDcur_1;
	$DROP TABLE temp2;
	/********************************************************************************************/
	/* ��J�����ɮ� */
	stmt_len = 0;
	
	stmt_len += sprintf(stmt+stmt_len, "select * from ca_id_officer where 1=0 into temp temp1 with no log;\r\n");
	stmt_len += sprintf(stmt+stmt_len, "load from %s delimiter '\t' insert into temp1; \r\n", filename);
	stmt_len += sprintf(stmt+stmt_len, "insert into ca_id_officer select * from temp1;\r\n");
	sprintf(cmd_str,"dbaccess sysdb > %s 2>&1 << !\r\n"
	                "%s\r\n!", logname,stmt);
	printf("cmd_str[%s]\n",cmd_str);
	rc = system(cmd_str);
	if (rc != 0) {
		sprintf(errbuf,"load file error[%s]\n���I���ɮפU���@�~�d��[Q],�T�{���~��]", logname);
		rc1=rptftpinsert(userid,"car144","car144_log.txt");
		return rc;
	}
	sprintf(errbuf,"���槹��");
	return M_CM_OK;

errexit:
	sprintf(errbuf,"SQLCODE[%d], sqlca.sqlerrm[%s]\n", SQLCODE, sqlca.sqlerrm);
	return SQLCODE;
}

long GetData(data, maxlen, delimiter)
char *data, delimiter;
int maxlen;
{
	int fori, pre_offset, cnt=0;

	data[0]='\0';
	pre_offset = offset;

	for (fori=pre_offset; bp[fori]!=0x00&&bp[fori]!=0x0d&&bp[fori]!=0x0a&&bp[fori]!=delimiter; fori++)
	{
		offset++;
		if (cnt < maxlen-1)
		{
			data[cnt]=bp[fori];
			cnt++;
		}
	}

	offset++; /* ���ܤU�@�� */
	if (cnt==0) data[cnt++]=0x20; /* �L��Ƶ��ť� */
	data[cnt]=0x00;
	printf("pre_offset[%d]offset[%d]len[%d]data[%s]\n", pre_offset, offset, cnt, data);
}

long car144_chk_provision(reply)
serverReply reply;
{
	$char DBName[5];
	$char iassured[13],provision[7],tmp_provision[7];
	
	int tmp_len;
	
	cm_buf_get("%s %s %s",DBName, iassured, provision);
	
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}

	if(strcmp(provision,"F") == 0)
		strcpy(tmp_provision,"G");
	else
		strcpy(tmp_provision,"F");

	$SELECT count(*)
	   INTO $count1
	   FROM ca_id_officer
	  WHERE provision = $tmp_provision
	    AND iassured = $iassured
	    AND (dexpire is null OR dexpire > today);
      
	if(count1 >= 1)
	{
		SQLCODE = -239;
		goto errexit;
	}

	cm_buf_init(ReplyBuf);
	cm_buf_put("%l",M_CM_OK);
	
	tmp_len = cm_buf_len(ReplyBuf);
	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
		return apiRC;
	else
		return api_OKComplete;

errexit:
	return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long car144_batch_update(reply)
serverReply reply;
{
	$char DBName[5];
	$char iassured[13],iofficer[11];
	$char iupdate[11];
	$char iins_type_tmp[2];
	$char icar_type[3];
	$char irate_bef[5],irate_aft[5];
	$char dpolicy_bgn_bef[11],dpolicy_end_bef[11],str_dpolicy_bgn_bef[10],str_dpolicy_end_bef[10];
	$char drate_bgn_bef[10],drate_end_bef[11],strdrate_bgn_bef[10],strdrate_end_bef[10];
	$char dexpire_bef[11],strdexpire_bef[10];
	$char dpolicy_bgn_aft[11],dpolicy_end_aft[11],str_dpolicy_bgn_aft[10],str_dpolicy_end_aft[10];
	$char drate_bgn_aft[11],drate_end_aft[11],strdrate_bgn_aft[10],strdrate_end_aft[10];
	$char dexpire_aft[11],strdexpire_aft[10];
	
	$char stmt_iassured[50],stmt_iofficer[50];
	$char stmt_icar_type[200],stmt_iins_type[200];
	$char stmt_irate[50],stmt_car[50];
	$char stmt_dpolicy_bgn[50],stmt_dpolicy_end[50];
	$char stmt_drate_bgn[50],stmt_drate_end[50];
	$char stmt_dexpire[50];
	
	$int tmp_cnt;
	
	int tmp_len;
	DBinfo *list;
	int i, j, is_add_fail=0, api_f;
	$char stmt_buf[1024];
	long MsgCode;
	
	$char *ptr,*ptr2,*ptr3;
	$char iassured_tmp[101],iofficer_tmp[101],icar_type_tmp[51];
	$char iassured_tmp2[13],iofficer_tmp2[12],icar_type_tmp2[3];
	$char stmtX1[256],stmtX2[256],stmtX3[256];
	$char stmt_buf1[1024],stmt_buf2[1024],stmt_buf3[1024];
	
	$char iassured_tmp_insert[101],iofficer_tmp_insert[101],icar_type_tmp_insert[51];

	cm_buf_get("%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s ",
	           DBName, iassured_tmp, iofficer_tmp, iins_type_tmp, icar_type_tmp,
	           irate_bef, str_dpolicy_bgn_bef, str_dpolicy_end_bef, strdrate_bgn_bef, strdrate_end_bef, strdexpire_bef,
	           irate_aft, str_dpolicy_bgn_aft, str_dpolicy_end_aft, strdrate_bgn_aft, strdrate_end_aft, strdexpire_aft,
	           iupdate);
	           
	$WHENEVER SQLERROR GOTO errexit;
	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}
	
	if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
	{
		if(exitsub(reply,M_CM_NOT_DBLIST) == True)
			return M_CM_NOT_DBLIST;
		return apiRC;
	}
	$BEGIN WORK;
	
	/*������쳣���i�H�ťաA�ܤ֭n����*/
	
	/* create temp table*/
	$CREATE TEMP TABLE t_iassured (iassured char(12)) with no log;
	$CREATE TEMP TABLE t_iofficer (iofficer char(10)) with no log;
	$CREATE TEMP TABLE t_car_type (icar_type char(2)) with no log;
	/*$TRUNCATE TABLE t_iassured;
	$TRUNCATE TABLE t_iofficer;
	$TRUNCATE TABLE t_iofficer;*/
	
	/* �Q�O�I�H */
	strcpy(iassured_tmp,trim(iassured_tmp));
	strcpy(iassured_tmp_insert,iassured_tmp);
	if(strcmp(iassured_tmp,"*") == 0)
	{
		strcpy(stmt_iassured," ");
		strcpy(iassured," ");
	}
	else 
	{
		ptr = strtok(iassured_tmp,";");
		while(ptr)
		{
			iassured_tmp2[0] = '\0';
			strcpy(iassured_tmp2,ptr);
			strcpy(iassured_tmp2,rtrim(iassured_tmp2));
			printf("iassured_tmp2[%s] \n",iassured_tmp2);
			$INSERT INTO t_iassured VALUES($iassured_tmp2);
			ptr = strtok(NULL,";");
		}
		sprintf(stmt_iassured," AND iassured IN (SELECT iassured FROM t_iassured) ");
	}
	printf("stmt_iassured[%s] \n",stmt_iassured);
	
	/* �g��N�� */
	strcpy(iofficer_tmp,trim(iofficer_tmp));
	strcpy(iofficer_tmp_insert,iofficer_tmp);
	if(strcmp(iofficer_tmp,"*") == 0)
	{
		strcpy(stmt_iofficer," ");
		strcpy(iofficer," ");
	}
	else 
	{
		ptr2 = strtok(iofficer_tmp,";");
		while(ptr2)
		{
			iofficer_tmp2[0] = '\0';
			strcpy(iofficer_tmp2,ptr2);
			strcpy(iofficer_tmp2,rtrim(iofficer_tmp2));
			printf("iofficer_tmp2[%s] \n",iofficer_tmp2);
			$INSERT INTO t_iofficer VALUES($iofficer_tmp2);
			ptr2 = strtok(NULL,";");
		}
		strcpy(stmt_iofficer," AND iofficer IN (SELECT iofficer FROM t_iofficer) ");
	}
	printf("stmt_iofficer[%s] \n",stmt_iofficer);
	
	/* �I�� */
	strcpy(iins_type_tmp,trim(iins_type_tmp));
	if(strcmp(iins_type_tmp,"*") == 0) /* �����I�� */
	{
		strcpy(iins_type_tmp," ");
	}
	else   /* 1.�����I(�t�ѵs) 2.�d���I*/
	{
		sprintf(stmt_iins_type," AND iins_type IN (SELECT iins_type FROM insurance_type WHERE fins_grp = '%s') ",iins_type_tmp);
	}

	printf("stmt_iins_type[%s] \n",stmt_iins_type);
	
	/* ���� */
	strcpy(icar_type_tmp,trim(icar_type_tmp));
	strcpy(icar_type_tmp_insert,icar_type_tmp);
	if(strcmp(icar_type_tmp,"*") == 0)
	{
		strcpy(stmt_icar_type," ");
	}
	else 
	{
		ptr3 = strtok(icar_type_tmp,";");
		while(ptr3)
		{
			icar_type_tmp2[0] = '\0';
			strcpy(icar_type_tmp2,ptr3);
			strcpy(icar_type_tmp2,rtrim(icar_type_tmp2));
			printf("icar_type_tmp2[%s] \n",icar_type_tmp2);
			$INSERT INTO t_car_type VALUES($icar_type_tmp2);
			ptr3 = strtok(NULL,";");
		}
		strcpy(stmt_icar_type," AND icar_type IN (SELECT icar_type FROM t_car_type) ");
	}
	printf("stmt_icar_type[%s] \n",stmt_icar_type);
	
	/* �󥿫e�A�ΥN�� */
	strcpy(irate_bef,trim(irate_bef));
	if(strcmp(irate_bef,"*") == 0)
	{
		strcpy(stmt_irate," ");
	}
	else
	{
		sprintf(stmt_irate," AND irate = %s ",irate_bef);
	}
	
	/* �󥿫�A�ΥN�� */
	strcpy(irate_aft, trim(irate_aft));
	if (strlen(irate_aft) > 0 )
	{
		/* Do nothing */
	}
	else
	{
		strcpy(irate_aft," ");
	}
	
	/* �󥿫eñ��� */
	strcpy(str_dpolicy_bgn_bef,trim(str_dpolicy_bgn_bef));
	if(strcmp(str_dpolicy_bgn_bef,"*") == 0)
	{
		strcpy(stmt_dpolicy_bgn,"");
		strcpy(stmt_dpolicy_end,"");
	}
	else 
	{
		strcpy(dpolicy_bgn_bef,cm_to_infdate(str_dpolicy_bgn_bef));
		strcpy(dpolicy_end_bef,cm_to_infdate(str_dpolicy_end_bef));
		sprintf(stmt_dpolicy_bgn," AND dpolicy_bgn = '%s' ",dpolicy_bgn_bef);
		sprintf(stmt_dpolicy_end," AND dpolicy_end = '%s' ",dpolicy_end_bef);
	}
	
	/* �󥿫�ñ��� */
	strcpy(str_dpolicy_bgn_aft,trim(str_dpolicy_bgn_aft));
	if(strcmp(str_dpolicy_bgn_aft,"*") == 0)
	{
		strcpy(dpolicy_bgn_aft,"");
		strcpy(dpolicy_end_aft,"");
	}
	else 
	{
		strcpy(dpolicy_bgn_aft,cm_to_infdate(str_dpolicy_bgn_aft));
		strcpy(dpolicy_end_aft,cm_to_infdate(str_dpolicy_end_aft));
	}
	printf("--1666 dpolicy_bgn_aft[%s],dpolicy_end_aft[%s]\n",dpolicy_bgn_aft,dpolicy_end_aft);
	
	/* �󥿫e�ͮĤ� */
	strcpy(strdrate_bgn_bef,trim(strdrate_bgn_bef));
	if(strcmp(strdrate_bgn_bef,"*") == 0)
	{
		strcpy(stmt_drate_bgn,"");
		strcpy(stmt_drate_end,"");
	}
	else 
	{
		strcpy(drate_bgn_bef,cm_to_infdate(strdrate_bgn_bef));
		strcpy(drate_end_bef,cm_to_infdate(strdrate_end_bef));
		sprintf(stmt_drate_bgn," AND drate_bgn = '%s' ",drate_bgn_bef);
		sprintf(stmt_drate_end," AND drate_end = '%s' ",drate_end_bef);
	}
	
	/* �󥿫�ͮĤ� */
	strcpy(strdrate_bgn_aft,trim(strdrate_bgn_aft));
	if(strcmp(strdrate_bgn_aft,"*") == 0)
	{
		strcpy(drate_bgn_aft,"");
		strcpy(drate_end_aft,"");
	}
	else
	{
		strcpy(drate_bgn_aft,cm_to_infdate(strdrate_bgn_aft));
		strcpy(drate_end_aft,cm_to_infdate(strdrate_end_aft));
	}
	
	/* �󥿫e���Τ� */
	strcpy(strdexpire_bef, trim(strdexpire_bef));
	if(strcmp(strdexpire_bef,"*") == 0)
	{
		strcpy(dexpire_bef,"");
		strcpy(stmt_dexpire," ");
	}
	else
	{
		strcpy(dexpire_bef,cm_to_infdate(strdexpire_bef));
		sprintf(stmt_dexpire," AND dexpire = '%s' ",dexpire_bef);
	}
	
	 /* �󥿫ᰱ�Τ� */
	strcpy(strdexpire_aft, trim(strdexpire_aft));
	if (strlen(strdexpire_aft) > 0 )
		strcpy(dexpire_aft,cm_to_infdate(strdexpire_aft));
	else
		strcpy(dexpire_aft," ");

	/* �T�{�󥿫e��ƬO�_�s�b */
	strcpy(stmtX1,"SELECT iassured FROM t_iassured");
	$PREPARE iassured_x FROM $stmtX1;
	$DECLARE iassured_x1 CURSOR FOR iassured_x;
	$OPEN iassured_x1;
	for(;;)
	{
		$FETCH iassured_x1 INTO $iassured;
		if(SQLCODE==SQLNOTFOUND) break;
		strcpy(iassured,trim(iassured));
		printf("iassured[%s] \n",iassured);
		
		sprintf(stmt_buf1,"SELECT count(*) \
		                    FROM ca_id_officer\
		                   WHERE 1=1 %s %s %s %s %s %s %s %s %s\
		                     AND iassured = '%s'",
		                  stmt_iofficer,stmt_iins_type,stmt_icar_type,stmt_irate,
		                  stmt_dpolicy_bgn,stmt_dpolicy_end,stmt_drate_bgn,stmt_drate_end,stmt_dexpire,iassured);
		
		printf("stmt_buf1[%s] \n",stmt_buf1);
		$PREPARE chk_data1 FROM $stmt_buf1;
		$EXECUTE chk_data1 INTO $tmp_cnt;
	
		if (tmp_cnt == 0)
		{
			$WHENEVER SQLERROR CONTINUE;
			$ROLLBACK WORK;
			if (exitsub(reply,M_CM_NOT_FOUND) == True)
				return M_CM_NOT_FOUND;
			else
				return apiRC;
		}
	}
	$CLOSE iassured_x1;
	
	strcpy(stmtX2,"SELECT iofficer FROM t_iofficer");
	$PREPARE iofficer_x FROM $stmtX2;
	$DECLARE iofficer_x1 CURSOR FOR iofficer_x;
	$OPEN iofficer_x1;
	for(;;)
	{
		$FETCH iofficer_x1 INTO $iofficer;
		if(SQLCODE==SQLNOTFOUND) break;
		strcpy(iofficer,trim(iofficer));
		printf("iofficer[%s] \n",iofficer);
		
		sprintf(stmt_buf2,"SELECT count(*) \
		                    FROM ca_id_officer\
		                   WHERE 1=1 %s %s %s %s %s %s %s %s %s \
		                     AND iofficer = '%s'",
		                  stmt_iassured,stmt_iins_type,stmt_icar_type,stmt_irate,
		                  stmt_dpolicy_bgn,stmt_dpolicy_end,stmt_drate_bgn,stmt_drate_end,stmt_dexpire,iofficer);
		
		printf("stmt_buf2[%s] \n",stmt_buf2);
		$PREPARE chk_data2 FROM $stmt_buf2;
		$EXECUTE chk_data2 INTO $tmp_cnt;
	
		if (tmp_cnt == 0)
		{
			$WHENEVER SQLERROR CONTINUE;
			$ROLLBACK WORK;
			if (exitsub(reply,M_CM_NOT_FOUND) == True)
				return M_CM_NOT_FOUND;
			else
				return apiRC;
		}
	}
	$CLOSE iofficer_x1;
	
	strcpy(stmtX3,"SELECT icar_type FROM t_car_type");
	$PREPARE car_type_x FROM $stmtX3;
	$DECLARE car_type_x1 CURSOR FOR car_type_x;
	$OPEN car_type_x1;
	for(;;)
	{
		$FETCH car_type_x1 INTO $icar_type;
		if(SQLCODE==SQLNOTFOUND) break;
		strcpy(icar_type,trim(icar_type));
		printf("icar_type[%s] \n",icar_type);
		
		sprintf(stmt_buf3,"SELECT count(*) \
		                    FROM ca_id_officer\
		                   WHERE 1=1 %s %s %s %s %s %s %s %s %s \
		                     AND icar_type = '%s'",
		                  stmt_iassured,stmt_iofficer,stmt_iins_type,stmt_irate,
		                  stmt_dpolicy_bgn,stmt_dpolicy_end,stmt_drate_bgn,stmt_drate_end,stmt_dexpire,icar_type);
		
		printf("stmt_buf3[%s] \n",stmt_buf3);
		$PREPARE chk_data3 FROM $stmt_buf3;
		$EXECUTE chk_data3 INTO $tmp_cnt;
	
		if (tmp_cnt == 0)
		{
			$WHENEVER SQLERROR CONTINUE;
			$ROLLBACK WORK;
			if (exitsub(reply,M_CM_NOT_FOUND) == True)
				return M_CM_NOT_FOUND;
			else
				return apiRC;
		}
	}
	$CLOSE car_type_x1;

	printf("iassured_tmp[%s],iofficer_tmp[%s],iins_type_tmp[%s],icar_type_tmp[%s],iupdate[%s] \n",
	        iassured_tmp,iofficer_tmp,iins_type_tmp,icar_type_tmp,iupdate);
	printf("dpolicy_bgn_bef[%s],dpolicy_end_bef[%s],drate_bgn_bef[%s],drate_end_bef[%s],dexpire_bef[%s]\n",
	        dpolicy_bgn_bef,dpolicy_end_bef,drate_bgn_bef,drate_end_bef,dexpire_bef);
	printf("dpolicy_bgn_aft[%s],dpolicy_end_aft[%s],drate_bgn_aft[%s],drate_end_aft[%s],dexpire_aft[%s]\n",
	        dpolicy_bgn_aft,dpolicy_end_aft,drate_bgn_aft,drate_end_aft,dexpire_aft);
	
	sprintf(stmt_buf,"UPDATE ca_id_officer SET \
	                         (irate,dpolicy_bgn,dpolicy_end,drate_bgn,drate_end,dexpire,iupdate,dupdate) \
	                         = (?,?,?,?,?,?,?,current) \
	                   WHERE 1=1 %s %s %s %s %s %s %s %s %s %s",
	                         stmt_iassured,stmt_iofficer,stmt_iins_type,stmt_icar_type,
	                         stmt_irate,stmt_dpolicy_bgn,stmt_dpolicy_end,stmt_drate_bgn,stmt_drate_end,stmt_dexpire);
	printf("stmt_buf[% s]\n",stmt_buf);
	$PREPARE u_batch FROM  $stmt_buf;
	$EXECUTE u_batch using $irate_aft,$dpolicy_bgn_aft,$dpolicy_end_aft,$drate_bgn_aft,$drate_end_aft,$dexpire_aft,$iupdate;
	
	printf("SQLCODE[%d]\n",SQLCODE);
	if(SQLCODE != 0) goto errexit;
	
	if(sqlca.sqlerrd[2] == 0) 
	{
		printf("no rows has been updated then insert it\n");
	}
	
	$INSERT INTO ca_id_officer_log (iassured,iofficer,iins_type,icar_type,
	                                irate_bef,dpolicy_bgn_bef,dpolicy_end_bef,drate_bgn_bef,drate_end_bef,dexpire_bef,
	                                irate_aft,dpolicy_bgn_aft,dpolicy_end_aft,drate_bgn_aft,drate_end_aft,dexpire_aft,
	                                iupdate,dupdate)
	                        VALUES ($iassured_tmp_insert,$iofficer_tmp_insert,$iins_type_tmp,$icar_type_tmp_insert,
	                                $irate_bef,$dpolicy_bgn_bef,$dpolicy_end_bef,$drate_bgn_bef,$drate_end_bef,$dexpire_bef,
	                                $irate_aft,$dpolicy_bgn_aft,$dpolicy_end_aft,$drate_bgn_aft,$drate_end_aft,$dexpire_aft,
	                                $iupdate,CURRENT);
	
	$DROP TABLE t_iassured;
	$DROP TABLE t_iofficer;
	$DROP TABLE t_car_type;
	
	cm_buf_init(ReplyBuf);
	cm_buf_put("%l",M_CM_OK);
	tmp_len = cm_buf_len(ReplyBuf);
	api_f = api_OKComplete;
	
	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
	{
		$WHENEVER SQLERROR CONTINUE;
		$ROLLBACK WORK;
		return apiRC;
	}
	
	$WHENEVER SQLERROR GOTO errexit;
	$COMMIT WORK;
	return api_OKComplete;
	
errexit:
	MsgCode = SQLCODE;
	$WHENEVER SQLERROR CONTINUE;
	$ROLLBACK WORK;
	if (SQLCODE != 0) MsgCode = SQLCODE;		/* rollback fail */
	if(exitsub(reply,MsgCode) == True)
		return MsgCode;
	else
		return apiRC;
}