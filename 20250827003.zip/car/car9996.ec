/************************************************
 * Copyright (C) 1995 Intellisys Corporation    *
 *                                              *
 * Program : car9996.ec                         *
 * ��o�i���ߥ��N�I�����                     *
 * Author  : Johnny Kuo , S.Y.HWANG.870611      *
 ************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "sqlfatal.h"
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "car_common.h"
#include <math.h>

double MyPower();
int DiffMonth();
long get_ca_car_model();
long get_dmg_cover();
long get_mcoefficient();
long get_prov_coefficient();
long get_mprem_base();

/* standard data declaration */
FILE *fptr, *fptr_err;
$char userid[11], iquota[7];
char prtfile[80],outputf[80],outputf1[80];
char errmsg[200];
$char errFile[120];
/* end of standard data */

$char localdb[5],Taipei_FullName[20];
int  i, flag_check=0;

/* end of standard defined data */
char expdate[6];
char bgndate[10],enddate[10];
char option[2];
$static char remotedb[DBNAME];
$char  sFassured[2];
 
$char  DBName[05];
$char  msgbuf[128];
DBinfo *list;
$char  errFile[120];
$static char remotedb[DBNAME]; 
int   count_db,k; 
char   sApHome[30];
int    rtncode,rc;
char   filename[30];
FILE   *fp;
char   file_catalog[200];
$char  filename1[200];
$char  data_yyyymm[7];

long car9996_get_db();
long car9996_build();
long car9996_final();
int DiffMonth();
/*************************************************************/

main(argc,argv)
int argc;
char **argv;
{
   int rtncode,rc;

   strcpy(DBName,  isNULLstr(argv[1]));
   strcpy(userid,  isNULLstr(argv[2]));
   strcpy(expdate, isNULLstr(argv[3]));
   strcpy(outputf, isNULLstr(argv[4]));

	printf("DBName[%s],userid[%s],expdate[%s],outputf[%s] \n",DBName,userid,expdate,outputf);
	
	rc = car9996_get_db();
	if (rc != M_CM_OK)
	{
		return rc;
	}
	
	rc = car9996_build();
	if ( rc != SUCCESS ) {
		printf("error on car9996_build \n");
		EWRITE(userid, rc, errmsg);
		return rc;	
	}
	
	rc = car9996_final();
	if ( rc != SUCCESS ) {
		printf("error on car9996_final \n");
		EWRITE(userid, rc, errmsg);
		return rc;	
	}
}

long car9996_get_db()
{
	$whenever sqlerror goto errexit1;

	if (db_select(DBName) == DBName) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}
	
	rc = getApHome(sApHome);
	if (rc < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		EWRITE(userid,rc,msgbuf);
	 	return rc;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}	
	return M_CM_OK;

errexit1:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}

long car9996_build()
{
	char   bgn_yy[5],bgn_mm[3],end_mm[3];
	int    endyy,endmm;
	$long  dwritten_l,dendorse;
	$double qpt,plia_acc,pdmg_acc,Maxminvalue,adjust_rate,car_t_rate,carfleet_rate;
	$char  ipolicy[POLICY_NUM_1],iendorse[ENDORSE_NUM],imark[5],Maxmin[5],iendorse_old[ENDORSE_NUM];
	$char  ipolicy_br[3],iendorse_br[3],fpt[2];
	$long  dedr_begin,dedr_end,dply_begin,dply_end;
	$char  ilicense[11],fsex[2],fmarriage[2],icar_type[3],qpt_tmp[6];
	$char  iedr_type[3],pbrg_align[2],fcar_class[2],iproduct[13],provision[21];
	$char  ibrand[9],ibrand_new[9],drate_ym[5],drate_code[7],align_code[3];
	$char  flimit[2];
	$char  pdmg_align[2],plia_align[2],iins_type[INSURANCE_TYPE];
	$char  dvp_code[3],ipro_year[5], iply_area[11];
	$long  medrdmg_cover, old_mdeduct, mdeduct,medrinj_cover,medrdea_cover;
	$long  mdamage_cover, medrdmg_cover_over;
	$long  min_cover, mdth_cover, mdmg_cover;
	$long  medrpure_prem,pure_total,mpure_prem;
	$char  sBgndate[YYYYMMDD], sEnddate[YYYYMMDD];
	$long  medrins_prem, mprem;
	$int   qcylinder,tmp_align;
	$char  icode[2],acc_tmp[5];
	$char  product_kind[3];
	
	$char  stmt_buf1[1024],stmt_buf2[2048],stmt_buf3[1024];
	$int   ipdmg_align,iplia_align,ipbrg_align;
	char   dedr_begin_c[11],dedr_end_c[11],dply_begin_c[11], qcylinder_c[6];
	char   sTmpBuf7[8], sTmpBuf9[10], sTmpBuf8[9],sTmpBuf10[10];
	char   dendorse_c[11];
	char   dedr_begin_yy[5],dedr_begin_mm[3],dedr_begin_dd[3];
	char   dedr_end_yy[5],dedr_end_mm[3],dedr_end_dd[3];
	char   dply_begin_yy[5],dply_begin_mm[3],dply_begin_dd[3];
	$char  dedr_yy[5],dedr_mm[3],ibirth_yy[5],tmp_dd[3];
	char   ilast_br[3],prtstr[318],ipolicy_tmp1[2],ipolicy_tmp2[7];
	char   iendorse_tmp1[2],iendorse_tmp2[7];
	char   cmdbuf[100],prem_c[13],prem_m[13],ttday_yy[5],ttday_mm[3],ttday_dd[3];
	char   ipolicy_no[13] ,ipolicy_no1[3] ,ipolicy_no2[11];
	char   iendorse_no[13],iendorse_no1[3],iendorse_no2[11];
	char   ilast_tmp1[2],ilast_tmp2[7];
	$long   medrdmg_subtot,medrins_subtot, medrpure_subtot,medr_subtot;
	$long   prem_subtot=0;
	char   medrins_subtot_c[10],medrpure_subtot_c[10],medr_subtot_c[10];
	long   count;
	$char  iissue_yy[5],iissue_mm[3],ttday[20], buf1[30];
	$long  mins_premium, prem_total, count1;
	long   iedr_type_l;
	char   iedr_type_c[3];
	$char  drate[11],drate_c[9];
	char   drate_yy[3],drate_mm[3],drate_dd[3],fcover[2];
	int    res, iTmpbuf;
	$char   aphome[40],iproyear[5],stmt[2048];
	$static date   Today;
	$char  ibroker[11], fbusiness[2],ibroker_top[11],bzfrom[3],fedr_class[2],chk_157[2];
	$char  ibrand6[7];
	$int   cnt,cnt2;
	$int  f_1000401 = 0; /* �O���1000401 */
	$int  f_1060101 = 0;
	$char iengine[CA_ENGINE_NUM],ibody[CA_BODY_NUM],itag[CA_TAG_NUM];
	$char provision_t[21],pro_tmp[21];
	$int pro_cnt = 0;
	$char adjust_tmp[5],carfleet_rate_tmp[5];
	
	/*���N�I�έp�W�{�վ�-�s�W���*/
	$long qpro_month;
	$char qpro_month_c[3];
	/*���m���� �t�ƪ��B*/
	$double mcar_price,mcar_price_ori,mequipment;
	mcar_price = 0.0;
	mcar_price_ori = 0.0;
	mequipment = 0.0;
	$double p_mcar_price = 0.0;
	$char mcar_price_tmp[4];
	/*�ʧO�~�֫Y��*/
	$double psex_age_lia,psex_age_dmg;
	psex_age_lia = 0.0;
	psex_age_dmg = 0.0;
	$char sex_age_tmp[4];
	
	$char iins_main[7];
	$int cnt_ins_type = 0;
	$char provision_tmp[21],provision_tmp2[21],provision_tmp_replace[21],provision_bak[21],provision_before[21];
	$char c_pro_tmp[2];
	$char icar_type_ori[3];  /*�d�O�v�ɭn�έ쨮��*/
	$int cnt_prov_t,cnt_prov;
	$int cnt_prov_t1,cnt_prov1;
	$int mpremium;
	
	$long pdepreciate_year = 0,pdepreciate_year_prov = 0;
	$long pdepreciate_year_aft = 0,pdepreciate_year_bak = 0;
	$long pdepreciate_year_tot = 0,pdepreciate_year_tot_aft = 0,pdepreciate_year_tot_bak = 0;
	$long pdepreciate_year_bak_tmp = 0,pdepreciate_year_aft_tmp = 0;
	
	$char pdepreciate_year_tmp[4],pdepreciate_year_prov_tmp[4];
	$int qprovision;
	$char iins_type_main[3],iins_type_dtl[3],iins_type_develop[3],iins_type_rule[3],frule[2],fcal_way[2];
	
	$double qdmg_acc_sum;
	$double qdmg_acc,qdmg_acc_time,qdmg_acc_year;
	
	$double coefficient = 0.0,pcar_price = 0.0;
	$int wk_qpt; 
	 
	/*���t�Y�ƫO�O/�«O�O*/
	$long mins_premium_n=0;
	$long mpure_prem_n=0;
	
	$long mprem_prov;
	$long mprem_pure_prov;
	$double mprem_base_prov;
	$long mprem_cal,mprem_pure_cal;
	$double mprem_base = 0.0;
	$char mprem_base_c[14];
	
	$int cnt_iins_main = 0;
	
	/*$double psex_age_lia = 0.0,psex_age_dmg = 0.0;*/
	$char medrins_prem_c[10];
	$char medrpure_prem_c[10];
    $char mprem_prov_c[10];
    $char mprem_pure_prov_c[10];
    $char mins_premium_n_c[10];
    $char mpure_prem_n_c[10];
    
    $int ifleet = 0;
    $long mprov_tmp = 0,mprov_pure_tmp = 0;
    $double mprov_base_tmp = 0.0;
    
    $double ca_rate_qpt = 0;
    $long qply_period;
    
    $char dissue[11];
    $int car_age150151,qday;
    $double qpassenger=0.0;
    $double pubi_acc;
    
    $long minjured_cover_tmp=0;
	/**/
	$char chk_prov[2];
    $int rc=0;
    $char v_sMsg[256];

    $long mdeduct_ori=0;
    
    $long min_cover2,mdth_cover2,mdmg_cover2,old_mdeduct2;
	$long medrinj_tmp = 0,mdmg_tmp = 0,mdeduct_tmp = 0,mdeduct_tmp2 = 0;
	
	$char fins_cal_way[2];
	
	$char icar_type_bak[3],drate_ym_bak[5],ibrand_bak[9],dissue_bak[11],ipro_year_bak[5],icar_series_bak[3],fins_cal_way_bak[2];
	$long qply_period_bak=0,dply_begin_bak=0,dply_end_bak=0;
	$long min_cover_bak=0,mdmg_cover_bak=0,mdeath_cover_bak=0,qday_bak=0,mdeduct_bak=0,mdeduct_ori_bak=0;
	$double qpt_bak = 0;
	$double mcar_price_bf = 0.0,mequipment_bf = 0.0;
	$double mcar_price_bak = 0.0,mequipment_bak = 0.0;
	$long mcover_prov_bak,mcover_ori_bak,mcover_prov_aft,mcover_ori_aft;
	$long qprovision_bak;
	$double adjust_rate_bak,pcar_price_bak,pubi_acc_bak,car_t_rate_bak,carfleet_rate_bak;
	$double mcar_price_ori_bak = 0.0;
	$double qpassenger_bak = 0.0;
	$char icar_type_ori_bak[3];
	$long mins_premium_bak,mins_premium_n_bak;
	$long mpure_prem_bak,mpure_prem_n_bak;
	$long mins_premium_aft=0,mprem_cal_aft=0,mins_premium_n_aft=0;
	$long mpure_prem_aft=0,mprem_pure_cal_aft=0,mpure_prem_n_aft=0;
	$long mprem_prov_bak=0;
	$long mprem_pure_prov_bak=0;
	$double coefficient_bak=0;
	$long mprov_tmp_bak=0;
	$long mprov_pure_tmp_bak=0;
	$long mprem_prov_aft=0;
	$long mprem_pure_prov_aft=0;
	$long mprov_tmp_aft=0,mprov_pure_tmp_aft=0;
	$long mcover1=0,mcover2=0; 
	$long mcover1_bak=0,mcover2_bak=0,mcover3_bak=0;
	$long mcover1_aft=0,mcover2_aft=0,mcover3_aft=0;
	$double mprem_base_bak=0;
	$long mprem_cal_bak=0;
	$long mprem_pure_cal_bak=0;
	$long mins_premium_tot=0;
	$long mprem_pure_prov_tot;
	$double mprem_base_tot;
	$char mins_premium_tot_c[10],mprem_pure_prov_tot_c[10],mprem_base_tot_c[14];
	$long mprem_pure_prov_over = 0;

	$int twice_20_77 = 0;
	
	$long mcover_ori_diff=0,mdamage_cover_diff=0,mcover_prov_tmp_bak=0,mcover_prov_tmp=0,mcover_prov_diff=0;
	$long mcover_prov_diff_E=0;
	$char mcover_ori_diff_c[10],mcover_prov_diff_c[10],mcover_prov_diff_E_c[10];
	
	$long qpro_month_bak;
	$char dissue_pro_tmp_bak[11],dpro_bak[11];
	char dissue_bak_100[11],dpro_bak_100[11];
	long ldissue_bak = 0,ldpro_bak = 0;
	$char fpt_bak[2];
	$char dissue_pro_tmp[11],dpro[11];
	char dissue_100[11],dpro_100[11];
	long ldissue = 0,ldpro = 0;
	$long ply_dpolicy=0;
	$char ply_dpolicy_c[11];
	$char  dpolicy_yy[5],dpolicy_mm[3],dpolicy_dd[3];
	$int chk_bak;
	$char fProvision_c[2],fProvision_e[2];
	$char fProvision_c1[2],fProvision_e1[2];
	$int chk_cover_per=0,chk_cover_E=0,chk_cover_K=0,chk_cover_Z=0;
	$int chk_cover_per1=0,chk_cover_E1=0,chk_cover_K1=0,chk_cover_Z1=0;
	$char provision1[21];
	$double mprem_base_aft;
	$char icar_series[3];
	long mdmg_cover_bak_tmp;
	$char fcar_class_p[2];
	$long mcover_prov,mcover_ori,mdamage_cover_aft;
	$char fins_grp[2];
	long iins_mult=0;
	char iin_mult_c[3];
	
	$char iri_ins[7];
	$char qdmg_acc_year_c[2],qdmg_acc_time_c[2];
	
	$int f_1090701 = 0,f_1090101 = 0,f_1120501 = 0,cnt_L = 0;
	$char fcar_kind[2],icomp_card[21];
	
	long min_tot=0,mdea_tot=0,mdmg_tot=0;
	
	$int inext = 0,inext1 = 0;
	
	$int fcontract_err=0;
	$char fcar_class_pd[2],pdepreciate_year_tmp2[5];
	
	$char sDbirth[11], sDply_begin[11];
	$double age = 0.0,psex_age_chk = 0.0;
	$int chk_plia = 0;
	$long dbirth;

	$char iproduct_tmp[3],iproduct_bef[13],iproduct_bef2[13];
	$long mprem_10 = 0,mprem_11 = 0,mprem_12 = 0,mprem_13 = 0,mprem_28 = 0;
	$long mprem_pure_10 = 0,mprem_pure_11 = 0,mprem_pure_12 = 0,mprem_pure_13 = 0,mprem_pure_28 = 0;
	$int cnt_iins_main_dtl = 0;
	
	$long medrins_prem_tmp = 0;
	
	$char provision_bk[21];
	
	$int cnt_acc=0;
	
	$double psex_age_tmp = 0;
	
	$long dply_begin_ori;
	$char dply_begin_ori_c[11],dply_begin_ori_yy[5],dply_begin_ori_mm[3],dply_begin_ori_dd[3];
	
	/* �g�Jca_dev_ply_edr */
	$char  t_data_yyyymm[7],t_idata[2],t_ipolicy[21],t_iendorse[21],t_icompany[3],t_iply_br[3],t_iply[13],t_iply_last_br[3],t_iply_last[13];
	$char  t_iedr_br[3],t_iedr[13],t_iarea[3],t_dedr_begin[9],t_dedr_end[9],t_dply_begin[9],t_dply_end[9],t_iobjno[5],t_iissue_ym[7],t_ipro_ym[7],t_ibrand[9];
	$char  t_icar_type_ori[3],t_icar_type[3],t_icar_type_no[3],t_iengine[26],t_itag[13],t_fpt[2],t_iassured[11],t_dbirth_y[5],t_fsex[2],t_fmarriage[2];
	$char  t_ipdmg_align[2],t_ipbrg_align[2],t_iplia_align[2],t_iins_type[7],t_iins_main[7],t_iins_type_main[2],t_iins_type_dtl[3];
	$char  t_iedr_type_ori[3],t_iedr_type[3],t_iins_type_dev[5],t_iins_type_rule[3],t_frule[2],t_ubi_data[9],t_fmdeduct[2];
	$char  t_iproduct[13],t_drate_ym[7],t_dendorse_ym[7],t_dpolicy_ym[7],t_bzfrom[3],t_dsend[9];
	$long  t_qcylinder,t_qpt,t_padjust_rate,t_p_mcar_price,t_qdmg_acc_year,t_qdmg_acc_time,t_pdepreciate_year;
	$long  t_minjured_cover,t_mdeath_cover,t_mdamage_cover,t_mdamage_cover_bak,t_mdamage_cover_aft,t_iins_mult;
	$long  t_mdeduct,t_mprem,t_mprem_pure,t_mprem_bak,t_mprem_pure_bak,t_mprem_aft,t_mprem_pure_aft;
	$double t_pins_acc,t_psex_age,t_mprem_pure_base,t_mprem_pure_base_bak,t_mprem_pure_base_aft,t_coefficient;

	$char  stmp[1024],stmp1[1024],stmp2[1024];
	$char  stmp_ins1[1024],stmp_ins2[1024],stmp_ins3[1024],stmp_ins4[1024];
	
	$char ply_DB[21],plyrel_DB[21];
	$char irelative_ply[21];
	
	$long minjured_cover_bak_deve,mdeath_cover_bak_deve,mdamage_cover_bak_deve,mdeduct_bak_deve;
	$long minjured_cover_deve,mdeath_cover_deve,mdamage_cover_deve,mdeduct_deve;
	$long tttmp1;
	$char tttmp2[7];
	
	$long mded_mpure_prem_bak=0,mded_mins_premium_bak=0;
	$int iedr_mon=0,iply_mon=0;
	
	$char iins_type_tmp[7];
	$char *prov,*prov_bf;
	$char prov2[7],prov_bf2[7];
	$int  prov_cnt=0;
	$int  prov_K=0,prov_T=0,prov_J=0;
	$int  prov_bf_K=0,prov_bf_T=0,prov_bf_J=0;
	
	$char iproduct_main[13],iproduct_01[13],iproduct_11[13],iproduct_31[13],iproduct_51[13];
	$int  cnt_149 = 0;
	
	$char icar_type_m[3],fcar_class_m[2],icar_type_bf[3],icar_type_bfm[3],fcar_class_bfm[2];
	
	$char nequipment[31],foil_electric[2]="",ibrand_78[3]="";
	
	$int chk_provY_noprem = 0;

	sprintf(filename,"%s/rptftp/", sApHome);
	sprintf(filename1,"AUTOX17_%d.txt",atoi(expdate)+191100);
	strcpy(file_catalog, trim(filename));
	strcat(file_catalog, trim(filename1));

	if ((fptr=fopen(file_catalog,"w")) == NULL)
	{
		sprintf(errmsg,"Cannot open print file: %s",outputf);
		return M_CM_OPEN_FILE_FAIL;
	}
	
	/* *** open error log file *** */
	res = getApHome(aphome);
	/*sprintf(errFile,"%s.%s.error",outputf,DBName);*/
	sprintf(errFile,"%s/tmp/%s.%s.error",sApHome,outputf,DBName);  /* �ץ���Ƨ��v�����D( fopen(errFile,"w")) == NULL )*/	
	printf("ERRFILE[%s]\n",errFile);
	if ((fptr_err=fopen(errFile,"w")) == NULL)
	{
	   sprintf(errmsg,"Cannot open print file: %s",errFile);
	   return M_CM_OPEN_FILE_FAIL;
	}
	
	printf(">>>expdate=%s\n",expdate);
	strncpy(bgn_yy,&expdate[0],3); bgn_yy[3]='\0';
	strncpy(bgn_mm,&expdate[3],2); bgn_mm[2]='\0';
	if (strncmp(bgn_mm, "12",2) == 0)
	{
	   endyy=atoi(bgn_yy)+1;
	   endmm=1;
	}
	else
	{
	   endyy=atoi(bgn_yy);
	   endmm=atoi(bgn_mm)+1;
	}
	rfmtlong(endmm,"&&",end_mm);
	
	sprintf(bgndate,"%s/%s/%s",bgn_yy,bgn_mm,"01");
	sprintf(enddate,"%d/%s/%s",endyy,end_mm,"01");
	sprintf(data_yyyymm,"%s%s",itoa(atoi(bgn_yy)+1911),bgn_mm);
	printf(">>>bgndate=[%s] enddate=[%s]\n",bgndate,enddate);
	
	EXEC SQL WHENEVER SQLERROR GOTO errexit;
	
	strcpy(sBgndate, cm_to_infdate(bgndate));
	strcpy(sEnddate, cm_to_infdate(enddate));
	
	printf(">>>sBgndate=[%s] sEnddate=[%s]\n", sBgndate, sEnddate);
	
	/* c199-206 ��ƻs�e��� */
	strcpy(ttday , cm_get_sysd());
	strncpy(ttday_yy,&ttday[0],4); ttday_yy[4] = '\0';
	strncpy(ttday_mm,&ttday[5],2); ttday_mm[2] = '\0';
	strncpy(ttday_dd,&ttday[8],2); ttday_dd[2] = '\0';
	
	prem_total = pure_total = count1 = 0;
	
	for(k=0;k<count_db;k++)
	{
		sprintf(stmt,"DELETE FROM %s:ca_dev_ply_edr WHERE data_yyyymm = '%s' AND idata = 'X'",list[k].dbname,data_yyyymm);
		$PREPARE DE_ca_dev_ply_edr FROM $stmt;
		$EXECUTE DE_ca_dev_ply_edr;
		
		/***** prepare cursor for select edr_relation *****/
		/*
		      case when ipolicy[6,7] = 'V7' then 'Y' else 'N' end, 
			  => 
			  CASE WHEN EXISTS(SELECT '1' FROM newa00:ori_ins_type 
	                    WHERE ipolicy = a.ipolicy 
	                      AND iins_type IN ('157','158','159','160','171','172','257','258','259','260'))
         	  THEN 'Y' ELSE 'N' END, 
		*/		
		printf("***** prepare cursor for select edr_relation *****\n");
		sprintf(stmt_buf1,"SELECT ipolicy,iendorse,dendorse,dedr_begin,dedr_end, \
		                          ipro_year,ibrand,icar_type,ibroker,bzfrom,fedr_class, \
		                          case when ipolicy[6,7] = 'V7' then 'Y' else 'N' end, \
		                          NVL(irelative_ply,''), ibrand[7,8] \
		                     FROM %s:edr_relation a \
		                    WHERE fcard_class='2' AND fedr_class not in ('3') \
		                      AND ipolicy[6,7] <> 'VW' AND ipolicy[6,7] <> 'EB' AND ipolicy[6,7] <> 'TV' \
		                      AND dendorse >= ? AND dendorse < ? AND dedr_close is not null ORDER BY iendorse",list[k].dbname);
		$PREPARE CUR_STMT1 FROM $stmt_buf1;
		$DECLARE scur_edr1 CURSOR FOR CUR_STMT1;
		
		printf("***** prepare cursor for select endorsement *****\n");
		/***** prepare cursor for select endorsement *****/
		/* 0991115001�]�����F�������X�֭p�� */
		/* 1.���a�ϥN����42�u�x�����v�A�h�վ㬰41�u�x�����v */
		/* 2.���a�ϥN����63�u�x�n���v�A�h�վ㬰62�u�x�n���v */
		/* 3.���a�ϥN����65�u�������v�A�h�վ㬰64�u�������v */
		sprintf(stmt_buf2,"SELECT %s %s %s %s %s FROM %s:%s",
		                  "DECODE(iply_area,'42','41','63','62','65','64',iply_area), qcylinder, iassured[1,10],YEAR(dissue),MONTH(dissue),",
		                  "YEAR(dbirth), fsex, fmarriage, flimit, pdmg_align, ",
		                  "pbrg_align, plia_align, qpt, fpt, fassured, ",
		                  "nvl(plia_acc,0), nvl(pdmg_acc,0),iengine,ibody,itag,mcar_price,qpro_month,qdmg_acc_sum,round(psex_age,2),qply_period,dissue,dbirth, ",
		                  "dply_begin,dply_end,nequipment,mequipment ",list[k].dbname,
		                  "endorsement WHERE iendorse= ?");
		printf("STMT2[%s]\n",stmt_buf2);
		$PREPARE CUR_STMT2 FROM $stmt_buf2;
		$DECLARE scur_endorse1 CURSOR FOR CUR_STMT2;
		
		printf("***** prepare cursor for select edr_ins_type *****\n");
		/***** prepare cursor for select edr_ins_type *****/
		sprintf(stmt_buf3,"SELECT %s %s %s FROM %s:%s %s ",
		                  "iedr_type, iins_type, medrinj_cover, medrdea_cover, ",
		                  "medrdmg_cover, mdeduct, medrins_prem,NVL(round(medrpure_prem),0), drate_ym,iproduct,nvl(provision,' '),adjust_rate,round(psex_age,2), ",
		                  "mins_premium_n,round(mpure_prem_n),pcar_price,qday,fcal_way,(safe_rate+manage_rate)/100 ",list[k].dbname,
		                  "edr_ins_type ",
		                  "WHERE iendorse = ? AND iins_type NOT IN ('33','47','48','56','50','80','89','147','136','166','266','171','172','173','174','175','561','562','563')");
		          /**  "AND iins_type[1] >= '0' AND iins_type[1] <= '9'");**/
	
		printf("STMT3[%s]\n",stmt_buf3);
		$PREPARE CUR_STMT3 FROM $stmt_buf3;
		$DECLARE scur_edr_ins_a1 CURSOR FOR CUR_STMT3;
		
		sprintf(stmt,"SELECT fcar_class FROM car_type \
		            WHERE fclass = '1' AND icode = ? ");
		$PREPARE CUR_CARCLASS FROM $stmt;
		
		/***** prepare cursor for select ca_car_model *****/
		/* 1000530002�t�P�����N���H�ഫ�t�P�����N�����e */
		sprintf(stmt, "SELECT ibrand_new "
		             "FROM ca_car_model "
		            "WHERE ibrand = ? "
		              "AND ibrand_new != ' ' "
		         "ORDER BY drate DESC;");
		$PREPARE pr_ibrand FROM $stmt;
		$DECLARE cur_ibrand CURSOR FOR pr_ibrand;
		printf("stmt[%s]\n", stmt);
		
		/*sprintf(stmt,"SELECT ncode FROM cu_code_data \
		            WHERE itype = '53' AND icode = ? ");
		$PREPARE CUR_DRATE FROM $stmt;*/
		
		sprintf(stmt,"SELECT a.iins_type_main,a.iins_type_dtl,a.iins_type_develop,a.iins_type_rule,nvl(b.fcal_way,' ') \
	                    FROM insurance_type_develop a,OUTER insurance_type b \
	                   WHERE a.iins_type = b.iins_type \
	                     AND a.iins_type = ? ");
		$PREPARE CUR_DEVELOP FROM $stmt;
		
		sprintf(stmt,"SELECT fins_grp,iri_ins \
	                    FROM insurance_type \
	                   WHERE iins_type = ? ");
		$PREPARE CUR_INSGRP FROM $stmt;
		
		sprintf(stmt,"SELECT iproduct FROM cm_product_code \
		            WHERE iins_class = 'C' AND icode2 = ' ' \
		              AND iins_type = ? AND icode1 = ? ");
		$PREPARE Acur FROM $stmt;
		
		/* provision f_af_bf(after/before) */
	    $CREATE temp TABLE prov_tmp (provision CHAR(6),f_af_bf char(1)) WITH NO log;
	    $CREATE INDEX prov_tmp_ix1 ON prov_tmp(provision,f_af_bf);
	    $CREATE temp TABLE prov_tmp2 (provision CHAR(6)) WITH NO log;
	    $CREATE INDEX prov_tmp2_inx1 ON prov_tmp(provision);
	    
	    sprintf(stmt,"SELECT dpolicy,CASE WHEN dpolicy >= '07/01/2020' THEN 1 ELSE 0 END, \
	                                 CASE WHEN dpolicy >= '01/01/2020' THEN 1 ELSE 0 END, \
	                                 CASE WHEN dpolicy >= '05/01/2023' THEN 1 ELSE 0 END  \
	                    FROM %s:ply_relation WHERE ipolicy = ? ",list[k].dbname);
		printf("stmt[%s]\n", stmt);
		$PREPARE ply_data FROM $stmt;
	
		$int count_ins=0,count_ins2=0,count_ins_X=0;
		
		printf("INTO BUILD2\n");
		$OPEN scur_edr1 USING $sBgndate,$sEnddate;
		/*$OPEN scur_edr1;*//*TEST*/
		while (1)
		{
			$FETCH scur_edr1
			  INTO $ipolicy, $iendorse, $dendorse, $dedr_begin, $dedr_end,
			       $ipro_year, $ibrand, $icar_type, $ibroker, $bzfrom, $fedr_class, $chk_157, $irelative_ply, $ibrand_78;
			
			if (SQLCODE == SQLNOTFOUND) break;
			strcpy(icar_type,trim(icar_type));
			strcpy(icar_type_ori,icar_type);
			
			$OPEN scur_endorse1 USING $iendorse;
			$FETCH scur_endorse1
			  INTO $iply_area,$qcylinder,
			       $ilicense,$iissue_yy,$iissue_mm,$ibirth_yy,$fsex,$fmarriage,$flimit,
			       $ipdmg_align,$ipbrg_align,$iplia_align,$qpt,$fpt,
			       $sFassured,$plia_acc,$pdmg_acc,$iengine,$ibody,$itag,$mcar_price,$qpro_month,$qdmg_acc_sum,
			       $psex_age_lia,$qply_period,$dissue,$dbirth,
			       $dply_begin,$dply_end,$nequipment,$mequipment;
			if (SQLCODE == SQLNOTFOUND)
			{
				$CLOSE scur_endorse1;
				continue;
			}
			$CLOSE scur_endorse1;
			
			strcpy(ply_DB, get_car_full_db(ipolicy));
			
			sprintf(stmp,"SELECT dply_begin \
			                FROM %s:ori_ply_relation \
			               WHERE ipolicy = '%s' ",ply_DB,ipolicy);
			printf("stmp[%s]\n", stmp);
			$PREPARE ply_dply_begin FROM $stmp;
			$EXECUTE ply_dply_begin INTO $dply_begin_ori;
			
			strcpy(irelative_ply, trim(irelative_ply));
			strcpy(icomp_card," ");	
			if (strlen(irelative_ply) > 0)
			{
				strcpy(plyrel_DB, get_car_full_db(irelative_ply));
				sprintf(stmp,"SELECT NVL(icard,' ') \
			                    FROM %s:ori_ply_relation \
			                   WHERE ipolicy = '%s' ",plyrel_DB,irelative_ply);
				printf("stmp[%s]\n", stmp);
				$PREPARE ply_comp_card FROM $stmp;
				$EXECUTE ply_comp_card INTO $icomp_card;
			}
			else 
			{
				strcpy(icomp_card," ");	
			}

			/* �O���1000401 */
			sprintf(stmp,"SELECT COUNT(*) \
			                FROM %s:ori_ply_relation \
			               WHERE ipolicy = '%s' AND dpolicy >= '04/01/2011' ",ply_DB,ipolicy);
			printf("stmp[%s]\n", stmp);
			$PREPARE ply_1000401 FROM $stmp;
			$EXECUTE ply_1000401 INTO $cnt;
			if (cnt>0) f_1000401 = 1;
			else f_1000401 = 0;
			
			/*�O��ñ��� < 106/01/01 �ϥ����ഫ�W�h�ǰe*/
			sprintf(stmp,"SELECT COUNT(*) \
			                FROM %s:ori_ply_relation \
			               WHERE ipolicy = '%s' AND dpolicy >= '01/01/2017' ",ply_DB,ipolicy);
			printf("stmp[%s]\n", stmp);
			$PREPARE ply_1060101 FROM $stmp;
			$EXECUTE ply_1060101 INTO $cnt2;
			if (cnt2>0) f_1060101 = 1;
			else f_1060101 = 0;

			medrins_subtot = medrpure_subtot = medr_subtot = 0;
			count = 0;
			medrinj_cover = medrdea_cover = medrdmg_cover = 0;
			
			medrins_prem = 0;
			medrpure_prem = 0;
			mins_premium_n = 0;
			mpure_prem_n = 0;
			
			$OPEN scur_edr_ins_a1 USING $iendorse;
			count_ins_X = 0;
			while (1)
			{
				if (count_ins2 > 0) {count_ins2 = 0;count_ins_X =0; break;}
				
				$FETCH scur_edr_ins_a1
				 INTO $iedr_type, $iins_type, $medrinj_cover, $medrdea_cover,
				      $medrdmg_cover, $mdeduct, $medrins_prem,$medrpure_prem, $drate_ym, $iproduct,
				      $provision,$adjust_rate,$psex_age_dmg,
				      $mins_premium_n,$mpure_prem_n,$qday,$pcar_price,$fins_cal_way,$car_t_rate;
				strcpy(iins_type, trim(iins_type));
				strcpy(iedr_type,trim(iedr_type));
				strcpy(drate_ym, trim(drate_ym));
				printf("--671 medrins_prem[%d],mins_premium_n[%d]\n",medrins_prem,mins_premium_n);
				printf("--672 medrpure_prem[%d],mpure_prem_n[%d]\n",medrpure_prem,mpure_prem_n);
				provision_bk[0] = '\0';
				if (SQLCODE == SQLNOTFOUND)
				{
					/*���F���@����]����@���Aedr_ins_type�S����Ƥ]�n�~��*/
					sprintf(stmp,"SELECT count(*)  \
				                    FROM %s:ply_ins_type_bak  \
				                   WHERE iendorse = '%s' \
				                     AND iins_type NOT IN ('33','47','48','56','50','80','89','147','136','166','266','171','172','173','174','175','561','562','563')",list[k].dbname,iendorse);
					$PREPARE ply_ins_bak FROM $stmp;
					$EXECUTE ply_ins_bak INTO $count_ins;
				
					$CLOSE scur_edr_ins_a1; /*��CLOSE ���M�|�A�iSQLNOTFOUND*/
					
					if (count_ins == 0) 
					{
					    break;
					}
					else 
					{
						if (count_ins_X > 0)
						{
							count_ins_X = 0;
							break;
						}
						else 
						{
							sprintf(stmp,"SELECT FIRST 1 a.iins_type,a.iproduct,a.psex_age,a.adjust_rate,a.drate_ym, \
							                      a.minjured_cover,a.mdeath_cover,a.mdamage_cover,a.mdeduct,NVL(a.provision,''), \
							                       (safe_rate+manage_rate)/100 \
				                            FROM %s:ply_ins_type_bak a,%s:policy_bak b  \
				                           WHERE a.iendorse = b.iendorse \
				                             AND a.iendorse = '%s' \
				                             AND a.iins_type NOT IN ('33','47','48','56','50','80','89','147','136','166','266','171','172','173','174','175','561','562','563')",list[k].dbname,list[k].dbname,iendorse);
							$PREPARE ply_ins_bak2 FROM $stmp;
							$EXECUTE ply_ins_bak2 INTO $iins_type,$iproduct,$psex_age_dmg,$adjust_rate,$drate_ym,
							                           $medrinj_cover,$medrdea_cover,$medrdmg_cover,$mdeduct,$provision_bk,$car_t_rate;

							medrins_prem = 0;
							medrpure_prem = 0;
							mins_premium_n = 0;
							mpure_prem_n = 0;
							pcar_price = 0;	  
							count_ins2 = 1;
							strcpy(iedr_type," ");
							provision[0] = '\0';
							strcpy(provision,trim(provision_bk));
							
							printf("medrinj_cover[%d],medrdea_cover[%d],medrdmg_cover[%d],mdeduct[%d],provision_bk[%s]\n",medrinj_cover,medrdea_cover,medrdmg_cover,mdeduct,provision_bk);
						}
					}
				}
				count_ins_X++;
				if( (strcmp(trim(iins_type),"29")==0) || (strcmp(trim(iins_type),"30")==0) || (strcmp(trim(iins_type),"301")==0) || (strcmp(trim(iins_type),"302")==0) || 
				    (strcmp(trim(iins_type),"238")==0)|| (strcmp(trim(iins_type),"198")==0)|| (strcmp(trim(iins_type),"530")==0))
				{
					mdeduct = 0;
				}
				
				if ((strcmp(trim(iins_type),"33")==0)  ||(strcmp(trim(iins_type),"47")==0)  ||
				    (strcmp(trim(iins_type),"48")==0)  ||(strcmp(trim(iins_type),"56")==0)  ||
				    (strcmp(trim(iins_type),"50")==0)  ||(strcmp(trim(iins_type),"80")==0)  ||
				    (strcmp(trim(iins_type),"89")==0)  ||(strcmp(trim(iins_type),"147")==0) ||
				    (strcmp(trim(iins_type),"136")==0) ||(strcmp(trim(iins_type),"166")==0) || (strcmp(trim(iins_type),"266")==0) ||
				    (strcmp(trim(iins_type),"171")==0) ||(strcmp(trim(iins_type),"172")==0) || 
				    (strcmp(trim(iins_type),"173")==0) ||(strcmp(trim(iins_type),"174")==0) || (strcmp(trim(iins_type),"175")==0) ||
					(strcmp(trim(iins_type),"561")==0) ||(strcmp(trim(iins_type),"562")==0) || (strcmp(trim(iins_type),"563")==0))
					continue;
					
				/*if (count_ins_X > 0)  continue;*/
				
				prem_total += medrins_prem;
				pure_total += medrpure_prem;
				medrins_subtot = medrins_subtot + medrins_prem;    /* �u�ݫ� */
				medrpure_subtot = medrpure_subtot + medrpure_prem;
				strcpy(iins_type, trim(iins_type));
				strcpy(ipolicy, trim(ipolicy));
				strcpy(iendorse, trim(iendorse));
				count++;
				
				iins_main[0] = '\0';
				cnt_ins_type = 0;
				cnt_ins_type++;
				cnt_prov_t = cnt_prov = 0;
				cnt_prov_t1 = cnt_prov1 = 0;
				mprov_tmp = mprov_pure_tmp = 0;
				provision_before[0] = '\0';
				provision_tmp2[0] = '\0';
				provision_tmp[0] = '\0';
				
				mprem_prov_bak = mprem_prov_aft= 0;
				mprem_pure_cal_aft = mprem_pure_cal_bak = 0;
				mprem_cal_aft = mprem_cal_bak = 0;
				mprem_base_aft = mprem_base_bak = 0;
				mprem_pure_prov_bak =mprem_pure_prov_aft= 0;
				mprov_tmp_bak = mprov_tmp_aft =0;
				mprov_pure_tmp_aft =0;
				min_cover_bak = mdmg_cover_bak = mdeath_cover_bak = 0;
				mdeduct_bak = 0;
				mpure_prem_bak = 0;
				mins_premium_bak = 0;
				mded_mpure_prem_bak = 0;
				mded_mins_premium_bak = 0;
				mins_premium_n_bak = 0;
				mpure_prem_n_bak = 0;
				carfleet_rate_bak = 0;
							
				$int ibef=0,iaft=0;
				$char fcar_class_bak[2],chk_prov_bak[2];
				$int ifleet_bak=0;
				$double cofficient_bak=0.0;
											/*��榳���[����*/
				mprem_prov = 0;
				mprem_pure_prov = 0;
				mprov_tmp_bak = 0;
				mprov_pure_tmp_bak = 0;
								
				chk_cover_per=0,chk_cover_E=0,chk_cover_K=0,chk_cover_Z=0;
				chk_cover_per1=0,chk_cover_E1=0,chk_cover_K1=0,chk_cover_Z1=0;
				
				mcover_ori_bak = 0;mcover_prov_bak = 0;
				mcover_prov_aft = 0; mcover_ori_aft = 0;
				mcover_ori = 0;mcover_prov = 0;
				printf("--iins_type[%s],iins_main[%s],provision_tmp[%s] \n",iins_type,iins_main,provision_tmp);
				
				inext=inext1=0;
				strcpy(provision_tmp,trim(provision));
				if (count_ins2 > 0)
				{
					strcpy(provision_before," ");
					strcpy(provision_before,trim(provision_before));
				}
				else
				{
					sprintf(stmp,"SELECT trim(NVL(provision,' '))  \
				                    FROM %s:ply_ins_type_bak  \
				                   WHERE iendorse = '%s' \
				                     AND iins_type = '%s'",list[k].dbname,iendorse,iins_type);
					$PREPARE ply_ins_bak_pro FROM $stmp;
					$EXECUTE ply_ins_bak_pro INTO $provision_before;
					strcpy(provision_before,trim(provision_before));
				}
				printf("--iins_type[%s],provision_tmp[%s],provision_before[%s] \n",iins_type,provision_tmp,provision_before);
				$TRUNCATE TABLE prov_tmp;  /*�M��prov_tmp*/
				$TRUNCATE TABLE prov_tmp2;
				int ibb=0,iaa=0;
				int cnt_pro_end = 0,cnt_pro_end1 = 0;
				while(cnt_ins_type>0)
				{
					$SELECT count(*) INTO $prov_cnt FROM prov_tmp2;
					if(count_ins2 > 0) prov_cnt = 0;
					
					if(cnt_ins_type == 1)
					{
						/*���[���ڱƧ�-�̷Ӫ��[�����I�ض��ǭp��*/
						cnt_iins_main = 1;
						cnt_ins_type++;
						strcpy(iins_main,iins_type);
						if(count_ins2 > 0) cnt_ins_type = 0;
						
						strcpy(icar_type_m,TRANS_CAR_TYPE(icar_type));
						$EXECUTE CUR_CARCLASS INTO $fcar_class_m USING $icar_type_m;
	
						if ((provision_tmp[0] == '' || provision_tmp == '\0') && (provision_before[0] == '' || provision_before == '\0'))
						{
							/*Do NOTHING*/
							cnt_ins_type = 0;
						}
						else if ((strcmp(iedr_type, "20") == 0) || (strcmp(iedr_type, "77") == 0))
						{
							/*Do NOTHING*/
							cnt_ins_type = 0;
						}
						else 
						{
							/* AFTER/���� */
							prov = strtok(provision_tmp,";");
							while(prov)
							{
								strcpy(prov2,prov);
								strcpy(prov2,rtrim(prov2));
								printf("prov2[%s] \n",prov2);

								if (strcmp(prov2,"R") ==0 || strcmp(prov2,"V") ==0 || strcmp(prov2,"X") ==0 || strcmp(prov2,"C") ==0 )
								{
									printf("--RVXC\n");
								}
								else if(strcmp(prov2,"E") ==0)
								{
									/*E���ڤ��e�A��05+P+E�A�h��X��ӫO�O�B��Ѿl�O�BP�ǰe*/
									chk_cover_E++;	
								}
								else if ((strcmp(prov2,"P") ==0 || strcmp(prov2,"Q") ==0 ||  strcmp(prov2,"Z") ==0) &&
								         (strcmp(iins_type,"01") != 0  && strcmp(iins_type,"05") != 0  && 
								          strcmp(iins_type,"09") != 0  && strcmp(iins_type,"11") != 0  &&
								          strcmp(iins_type,"201") != 0 && strcmp(iins_type,"205") != 0 && 
								          strcmp(iins_type,"209") != 0 && strcmp(iins_type,"211") != 0))
								{
									printf("--PQZ\n");
								}
								else if (strcmp(prov2,"M") ==0 && fcar_class_m[0] == '1')
								{
									/*M���ڶȩӫO��~��*/
									printf("--M\n");
								}
								else if ((strcmp(prov2,"M") ==0 && fcar_class_m[0] == '2') &&
								         (strcmp(iins_type,"01") != 0  && strcmp(iins_type,"05") != 0  && 
								          strcmp(iins_type,"09") != 0  && strcmp(iins_type,"11") != 0  && strcmp(iins_type,"181") != 0 && 
								          strcmp(iins_type,"201") != 0 && strcmp(iins_type,"205") != 0 && 
								          strcmp(iins_type,"209") != 0 && strcmp(iins_type,"211") != 0))
								{
									printf("--M\n");
								}
								else if (strcmp(prov2,"K") ==0 && strcmp(iins_type,"09")  != 0)
								{
									printf("--09+K\n");
								}
								else if((strcmp(prov2,"F") ==0) &&
								        (strcmp(iins_type,"01") != 0  && strcmp(iins_type,"05") != 0  && strcmp(iins_type,"09") != 0  &&
								         strcmp(iins_type,"11") != 0  && strcmp(iins_type,"31") != 0  && strcmp(iins_type,"32") != 0  && 
								         strcmp(iins_type,"201") != 0 && strcmp(iins_type,"205") != 0 && strcmp(iins_type,"209") != 0 && 
								         strcmp(iins_type,"211") != 0 && strcmp(iins_type,"231") != 0 && strcmp(iins_type,"232") != 0))
								{
									/*����F���ڶȳ��e����D�I�B�ѵs�D�I�B�d���D�I*/	
								}
								else if((strcmp(prov2,"T") ==0) &&
								        (strcmp(iins_type,"31") != 0  && strcmp(iins_type,"32") != 0 &&
								         strcmp(iins_type,"231") != 0 && strcmp(iins_type,"232") != 0))
								{
									/*����T���ڶȳ��e�d���D�I31�B32�B149*/	
								}
								else if((strcmp(prov2,"H") ==0) &&
								        (strcmp(iins_type,"05") != 0   && strcmp(iins_type,"09") != 0   && strcmp(iins_type,"31") != 0  &&
								         strcmp(iins_type,"32") != 0   && strcmp(iins_type,"149") != 0  && strcmp(iins_type,"198") != 0 &&
								         strcmp(iins_type,"255") != 0  && strcmp(iins_type,"302") != 0  &&
								         strcmp(iins_type,"205") != 0  && strcmp(iins_type,"209") != 0  && strcmp(iins_type,"231") != 0 &&
								         strcmp(iins_type,"232") != 0  && strcmp(iins_type,"249") != 0))
								{
									/*����F���ڶȳ��e����D�I�B�ѵs�D�I�B�d���D�I*/	
								}
								else if ((strcmp(prov2,"Y") ==0) &&
								         (strcmp(iins_type,"01") != 0  && strcmp(iins_type,"05") != 0  && 
								          strcmp(iins_type,"09") != 0  && 
								          strcmp(iins_type,"201") != 0 && strcmp(iins_type,"205") != 0 && 
								          strcmp(iins_type,"209") != 0 && strcmp(iins_type,"198") != 0))
								{
									/* 1130827011_C09_�s�W�s�t��W�B���[����(Y)(���e) */
									/* �t�Ʊ���01�B05�B09�B201�B205�B209�B198�~�� */
								}
							    else
							    {
							    	chk_provY_noprem = 0;
							    	if(strcmp(prov2,"Y") == 0 && mequipment >0)
							    	{
							    		/* Y���ڭp��ŶZ��S�����B�]���e fcar_class = 1 carfleet_rate=0*/
							    		ifleet = 0;carfleet_rate = 0.0;
							    		printf("mcar_price[%f],mequipment[%f]\n",mcar_price,mequipment);
										rc = get_prov_coefficient( "Y",drate_ym,"1",iins_main,icar_type_ori,0,0.0,
											                       0,0,0,0.0,0.0,0.0,
											                       mcar_price,mequipment,
											                       &ifleet,&coefficient,&chk_prov,v_sMsg);
										printf("--rc[%d] coefficient[%f] ifleet[%d] chk_prov[%s] \nv_sMsg[%s]\n",rc,coefficient,ifleet,chk_prov,v_sMsg);
										if( rc != M_CM_OK)
										{
											
										}
										if (coefficient <= 1)
										{
											chk_provY_noprem = 1;
										}
							    	}
							    	printf("chk_provY_noprem[%d] \n",chk_provY_noprem);
							    	
							    	if (chk_provY_noprem > 0)
							    	{
							    		/* For�W��Y���ˮ֡A�Y��>1�~���[�O */
							    	}
							    	else 
							    	{
										$INSERT INTO prov_tmp VALUES($prov2,'a');
										$INSERT INTO prov_tmp2 VALUES($prov2);
										printf("INTO temp TABLE prov2[%s] \n",prov2);
										prov_K = 0;
										$SELECT count(*) INTO $prov_K FROM prov_tmp WHERE provision = 'K' AND f_af_bf = 'a';
										if  (strcmp(prov2,"P") ==0) {strcpy(fProvision_c,"P"); chk_cover_per++;}
										else if (strcmp(prov2,"Q") ==0) {strcpy(fProvision_c,"Q"); chk_cover_per++;}
										else if (strcmp(prov2,"M") ==0) {strcpy(fProvision_c,"M"); chk_cover_per++;}
										else if (strcmp(prov2,"K") ==0) {chk_cover_K++;}
										cnt_prov_t++;
										if (strcmp(prov2,"Z") ==0) {strcpy(fProvision_c,"Z"); chk_cover_Z++;cnt_prov_t--;}
										
										if ((strcmp(prov2,"P") ==0) &&
									         (strcmp(iins_type,"129") == 0 || strcmp(iins_type,"20")  == 0 ||
									          strcmp(iins_type,"75")  == 0 || strcmp(iins_type,"76")  == 0 || 
									          strcmp(iins_type,"98")  == 0 || strcmp(iins_type,"110") == 0 || 
									          strcmp(iins_type,"111") == 0 || strcmp(iins_type,"23")  == 0 || 
									          strcmp(iins_type,"86")  == 0 ))
										{
											/*�o���I��P���ڤ��e���B �u���F����*/
											chk_cover_per--;cnt_prov_t--;
										}
										else if (strcmp(prov2,"P") ==0 && strcmp(iins_type,"09") == 0 && prov_K > 0)
										{
											/*K���ڻP���±��ڦP�ɶǰe�A���±��ڭn�e���u���F����*/
											chk_cover_per--;cnt_prov_t--;
										}
									}
								}
								prov = strtok(NULL,";");
							}
							
							
							sprintf(stmp,"SELECT icar_type  \
							                FROM %s:ply_relation_bak  \
							               WHERE iendorse = '%s' ",list[k].dbname,iendorse);
							$PREPARE m_icar_type_bak FROM $stmp;
							$EXECUTE m_icar_type_bak INTO $icar_type_bf;
							
							sprintf(stmp,"SELECT mcar_price,mequipment  \
							                FROM %s:policy_bak  \
							               WHERE iendorse = '%s' ",list[k].dbname,iendorse);
							$PREPARE mequipment_bak FROM $stmp;
							$EXECUTE mequipment_bak INTO $mcar_price_bf,$mequipment_bf;
							
							strcpy(icar_type_bfm,TRANS_CAR_TYPE(icar_type_bf));
							$EXECUTE CUR_CARCLASS INTO $fcar_class_bfm USING $icar_type_bfm;

							/* ���e */
							prov_bf = strtok(provision_before,";");
							while(prov_bf)
							{
								strcpy(prov_bf2,prov_bf);
								strcpy(prov_bf2,rtrim(prov_bf2));
								printf("prov2[%s] \n",prov_bf2);

								if (strcmp(prov_bf2,"R") ==0 || strcmp(prov_bf2,"V") ==0 || strcmp(prov_bf2,"X") ==0 || strcmp(prov_bf2,"C") ==0 )
								{
									printf("--RVXC\n");
								}
								else if(strcmp(prov_bf2,"E") ==0)
								{
									/*E���ڤ��e�A��05+P+E�A�h��X��ӫO�O�B��Ѿl�O�BP�ǰe*/
									chk_cover_E++;
								}
								else if ((strcmp(prov_bf2,"P") ==0 || strcmp(prov_bf2,"Q") ==0 || strcmp(prov_bf2,"Z") ==0) &&
								         (strcmp(iins_type,"01") != 0  && strcmp(iins_type,"05") != 0  && 
								          strcmp(iins_type,"09") != 0  && strcmp(iins_type,"11") != 0  &&
								          strcmp(iins_type,"201") != 0 && strcmp(iins_type,"205") != 0 && 
								          strcmp(iins_type,"209") != 0 && strcmp(iins_type,"211") != 0))
								{
									printf("--PQZ\n");
								}
								else if (strcmp(prov_bf2,"M") ==0 && fcar_class_bfm[0] == '1')
								{
									/*M���ڶȩӫO��~��*/
									printf("--M\n");
								}
								else if ((strcmp(prov_bf2,"M") ==0 && fcar_class_bfm[0] == '2') &&
								         (strcmp(iins_type,"01") != 0  && strcmp(iins_type,"05") != 0  && 
								          strcmp(iins_type,"09") != 0  && strcmp(iins_type,"11") != 0  && strcmp(iins_type,"181") != 0 &&
								          strcmp(iins_type,"201") != 0 && strcmp(iins_type,"205") != 0 && 
								          strcmp(iins_type,"209") != 0 && strcmp(iins_type,"211") != 0))
								{
									printf("--M\n");
								}
								else if (strcmp(prov_bf2,"K") ==0 && strcmp(iins_type,"09") != 0)
								{
									printf("--09+K\n");
								}
								else if((strcmp(prov_bf2,"F") ==0) &&
								        (strcmp(iins_type,"01") != 0  && strcmp(iins_type,"05") != 0  && strcmp(iins_type,"09") != 0  &&
								         strcmp(iins_type,"11") != 0  && strcmp(iins_type,"31") != 0  && strcmp(iins_type,"32") != 0  &&
								         strcmp(iins_type,"201") != 0 && strcmp(iins_type,"205") != 0 && strcmp(iins_type,"209") != 0 &&
								         strcmp(iins_type,"211") != 0 && strcmp(iins_type,"231") != 0 && strcmp(iins_type,"232") != 0))
								{
									/*����F���ڶȳ��e����D�I�B�ѵs�D�I�B�d���D�I*/
								}
								else if((strcmp(prov_bf2,"T") ==0) &&
								        (strcmp(iins_type,"31") != 0  && strcmp(iins_type,"32") != 0 &&
								         strcmp(iins_type,"231") != 0 && strcmp(iins_type,"232") != 0))
								{
									/*����T���ڶȳ��e�d���D�I31�B32�B149*/
								}
								else if((strcmp(prov_bf2,"H") ==0) &&
								        (strcmp(iins_type,"05") != 0   && strcmp(iins_type,"09") != 0   && strcmp(iins_type,"31") != 0  &&
								         strcmp(iins_type,"32") != 0   && strcmp(iins_type,"149") != 0  && strcmp(iins_type,"198") != 0 &&
								         strcmp(iins_type,"255") != 0  && strcmp(iins_type,"302") != 0  &&
								         strcmp(iins_type,"205") != 0  && strcmp(iins_type,"209") != 0  && strcmp(iins_type,"231") != 0 &&
								         strcmp(iins_type,"232") != 0  && strcmp(iins_type,"249") != 0))
								{
									/*����F���ڶȳ��e����D�I�B�ѵs�D�I�B�d���D�I*/	
								}
								else if((strcmp(prov_bf2,"Y") ==0) &&
								        (strcmp(iins_type,"01") != 0  && strcmp(iins_type,"05") != 0  && strcmp(iins_type,"09") != 0  &&
								         strcmp(iins_type,"201") != 0 && strcmp(iins_type,"205") != 0 && strcmp(iins_type,"209") != 0 &&
								         strcmp(iins_type,"198") != 0 ))
								{
									/*����F���ڶȳ��e����D�I�B�ѵs�D�I�B�d���D�I*/
								}
							    else
							    {
							    	chk_provY_noprem = 0;
							    	if(strcmp(prov_bf2,"Y") == 0 && mequipment_bf >0)
							    	{
							    		/* Y���ڭp��ŶZ��S�����B�]���e fcar_class = 1 carfleet_rate=0*/
							    		ifleet = 0;carfleet_rate = 0.0;
							    		printf("mcar_price[%f],mequipment[%f]\n",mcar_price,mequipment);
										rc = get_prov_coefficient( "Y",drate_ym,"1",iins_main,icar_type_bf,0,0.0,
											                       0,0,0,0.0,0.0,0.0,
											                       mcar_price_bf,mequipment_bf,
											                       &ifleet,&coefficient,&chk_prov,v_sMsg);
										printf("--rc[%d] coefficient[%f] ifleet[%d] chk_prov[%s] \nv_sMsg[%s]\n",rc,coefficient,ifleet,chk_prov,v_sMsg);
										if( rc != M_CM_OK)
										{
											
										}
									    /*if (coefficient == 1)*/
										if (coefficient <= 1)  /* �Y��>1�~���[�O */
										{
											chk_provY_noprem = 1;
										}
							    	}
							    	printf("chk_provY_noprem[%d] \n",chk_provY_noprem);
							    	
							    	/*if (chk_provY_noprem > 0)*/
									if (chk_provY_noprem == 1)
							    	{
							    		/* For�W��Y���ˮ֡A�Y��>1�~���[�O */
							    	}
							    	else 
							    	{
										$INSERT INTO prov_tmp VALUES($prov_bf2,'b');
										$INSERT INTO prov_tmp2 VALUES($prov_bf2);
										printf("INTO temp TABLE prov2[%s] \n",prov_bf2);
										prov_bf_K = 0;
										$SELECT count(*) INTO $prov_bf_K FROM prov_tmp WHERE provision = 'K' AND f_af_bf = 'b';
										if  (strcmp(prov_bf2,"P") ==0) {strcpy(fProvision_c1,"P"); chk_cover_per1++;}
										else if (strcmp(prov_bf2,"Q") ==0) {strcpy(fProvision_c1,"Q"); chk_cover_per1++;}
										else if (strcmp(prov_bf2,"M") ==0) {strcpy(fProvision_c1,"M"); chk_cover_per1++;}
										else if (strcmp(prov_bf2,"K") ==0) {chk_cover_K++;}
										cnt_prov_t1++;
										if (strcmp(prov_bf2,"Z") ==0) {strcpy(fProvision_c1,"Z"); chk_cover_Z1++;cnt_prov_t1--;}
										
										if ((strcmp(prov_bf2,"P") ==0) &&
									        (strcmp(iins_type,"129") == 0 || strcmp(iins_type,"20")  == 0 ||
									         strcmp(iins_type,"75")  == 0 || strcmp(iins_type,"76")  == 0 || 
									         strcmp(iins_type,"98")  == 0 || strcmp(iins_type,"110") == 0 || 
									         strcmp(iins_type,"111") == 0 || strcmp(iins_type,"23")  == 0 || 
									         strcmp(iins_type,"86")  == 0 ))
										{
											/*�o���I��P���ڤ��e���B �u���F����*/
											chk_cover_per1--;cnt_prov_t1--;
										}
										else if (strcmp(prov_bf2,"P") ==0 && strcmp(iins_type,"09") == 0 && prov_bf_K > 0)
										{
											/*K���ڻP���±��ڦP�ɶǰe�A���±��ڭn�e���u���F����*/
											chk_cover_per1--;cnt_prov_t1--;
										}
									}
								}
								prov_bf = strtok(NULL,";");
							}
	                	}
					}
					else if ((provision_tmp[0] == '' || provision_tmp == '\0') && (provision_before[0] == '' || provision_before == '\0'))
					{
						$DELETE FROM prov_tmp;
						$DELETE FROM prov_tmp2;
						cnt_ins_type = 0;
						break;
					}
					else if (prov_cnt==0)
					{
						$DELETE FROM prov_tmp;
						$DELETE FROM prov_tmp2;
						cnt_ins_type = 0;
						break;
					}
					else
					{
						$SELECT FIRST 1 provision
						   INTO $iins_type_tmp
						   FROM prov_tmp2;
						printf("iins_type_tmp[%s] \n",iins_type_tmp);
						strcpy(iins_type,iins_type_tmp);
						strcpy(iins_type,trim(iins_type));
						cnt_ins_type++;
						$DELETE FROM prov_tmp2 WHERE provision = $iins_type_tmp;
						
						prov_K = 0;
						$SELECT count(*) INTO $prov_bf_K FROM prov_tmp WHERE provision = 'K' AND f_af_bf = 'b';
						$SELECT count(*) INTO $prov_K FROM prov_tmp WHERE provision = 'K' AND f_af_bf = 'a';
						ibef = 0;iaft = 0;
						$SELECT count(*) INTO $ibef FROM prov_tmp WHERE provision = $iins_type AND provision <> 'Z' AND f_af_bf = 'b';
						$SELECT count(*) INTO $iaft FROM prov_tmp WHERE provision = $iins_type AND provision <> 'Z' AND f_af_bf = 'a';
						/*$SELECT count(*) INTO $ibef FROM prov_tmp WHERE provision = $iins_type AND f_af_bf = 'b';
						$SELECT count(*) INTO $iaft FROM prov_tmp WHERE provision = $iins_type AND f_af_bf = 'a';*/
						printf("-prov-ibef[%d],iaft[%d]\n",ibef,iaft);
						
						if (ibef > 0)
						{
							if ((strcmp(trim(iins_type),"P")==0) &&
						        (strcmp(iins_main,"129") == 0 || strcmp(iins_main,"20")  == 0 ||
						         strcmp(iins_main,"75")  == 0 || strcmp(iins_main,"76")  == 0 || 
						         strcmp(iins_main,"98")  == 0 || strcmp(iins_main,"110") == 0 || 
						         strcmp(iins_main,"111") == 0 || strcmp(iins_main,"23")  == 0 || 
						         strcmp(iins_main,"86")  == 0 ))
							{
								/*�o���I��P���ڤ��e���B �u���F����*/
								inext1++;
							}
							else if (strcmp(trim(iins_type),"P")==0 && strcmp(iins_main,"09") == 0 && prov_bf_K > 0)
							{
								/*K���ڻP���±��ڦP�ɶǰe�A���±��ڭn�e���u���F����*/
								inext1++;
							}
							else
								cnt_prov1++;
						}
						if (iaft > 0)
						{
							if ((strcmp(trim(iins_type),"P")==0) &&
						        (strcmp(iins_main,"129") == 0 || strcmp(iins_main,"20")  == 0 ||
						         strcmp(iins_main,"75")  == 0 || strcmp(iins_main,"76")  == 0 || 
						         strcmp(iins_main,"98")  == 0 || strcmp(iins_main,"110") == 0 || 
						         strcmp(iins_main,"111") == 0 || strcmp(iins_main,"23")  == 0 || 
						         strcmp(iins_main,"86")  == 0 ))
							{
								/*�o���I��P���ڤ��e���B �u���F����*/
								inext++;
							}
							else if (strcmp(trim(iins_type),"P")==0 && strcmp(iins_main,"09") == 0 && prov_K > 0)
							{
								/*K���ڻP���±��ڦP�ɶǰe�A���±��ڭn�e���u���F����*/
								inext++;
							}
							else 
								cnt_prov++;
						}
					}
					
					$EXECUTE CUR_INSGRP INTO $fins_grp,$iri_ins USING $iins_main;
					strcpy(fins_grp,trim(fins_grp));
					strcpy(iri_ins,trim(iri_ins));
					
					/* 1-4 ���q�N���Τ�����c�N�� */
					strcpy(prtstr, CAR_COMPANY);
					strcpy(t_icompany,CAR_COMPANY);
					strncpy(ipolicy_br, ipolicy, 2); ipolicy_br[2]='\0';
					if (strlen(trim(ipolicy_br)) == 0)
					{
					   strcat(prtstr,"00");
					   strcpy(t_iply_br,"00");
					}
					else
					{
					   strcat(prtstr, ipolicy_br);
					   strcpy(t_iply_br,ipolicy_br);
					   
					}
					/* 5-16 �O�渹�X */
					strncpy(ipolicy_no, ipolicy+3, 10); ipolicy_no[10]='\0';
	
					if (strlen(trim(ipolicy_no)) == 0)
					{
						strcat(prtstr,"          ");
						strcpy(t_iply," ");
					}
					else
					{
						strcat(prtstr, ipolicy_no);
						strcpy(t_iply, ipolicy_no);
					}
	
					prtstr[14]='\0';
					strcat(prtstr, "  ");
					
					/* 17-20 ���q�N���Τ�����c�N�� */
					strcat(prtstr, CAR_COMPANY);
					strncpy(iendorse_br, iendorse, 2); iendorse_br[2]='\0';
					if (strlen(trim(iendorse_br)) == 0)
					{
					    strcat(prtstr,"00");
					    strcpy(t_iedr_br,"00");
					}
					else
					{
					    strcat(prtstr,iendorse_br);
					    strcpy(t_iedr_br,iendorse_br);
					}
					
					/* 21-32 ��渹�X */
					strncpy(iendorse_no, iendorse+3, 10); iendorse_no[10]='\0';
					if (strlen(trim(iendorse_no)) == 0)
					{
						strcat(prtstr,"          ");
						strcpy(t_iedr," ");
					}
					else
					{
						strcat(prtstr,iendorse_no);
						strcpy(t_iedr,iendorse_no);
					}
					
					prtstr[30]='\0';
					strcat(prtstr, "  ");
					
					/* 33-34 �ӫO�a�ϥN�� */
					strncpy(dvp_code,iply_area,2);
					dvp_code[2]='\0';
					strcat(prtstr,dvp_code);
					strcpy(t_iarea,dvp_code);
					
					if (strlen(trim(dvp_code)) == 0)
					{   strcat(prtstr,"  ");       }
					
					/* 35-42 ���ͮİ_�l��� */
					strcpy(dedr_begin_c,cm_cdate_str_100(dedr_begin));
					cm_split_ymd_100(dedr_begin_c,dedr_begin_yy,dedr_begin_mm,dedr_begin_dd);
					/*�~*/
					if (dedr_begin_yy[0] == '\0')
					{
					    strcat(prtstr,"0000");
					    strcpy(t_dedr_begin,"0000");
					}
					else
					{
					    strcat(prtstr,itoa (1911+ (atoi (dedr_begin_yy))));
					    strcpy(t_dedr_begin,itoa (1911+ (atoi (dedr_begin_yy))));
					}
					/*��*/
					if (dedr_begin_mm[0] == '\0')
					{
					    strcat(prtstr,"00");
					    strcat(t_dedr_begin,"00");
					}
					else
					{
					    strcat(prtstr,dedr_begin_mm);
					    strcat(t_dedr_begin,dedr_begin_mm);
					}
					/*��*/
					if (dedr_begin_dd[0] == '\0')
					{
					    strcat(prtstr,"00");
					    strcat(t_dedr_begin,"00");
					}
					else
					{
					    strcat(prtstr,dedr_begin_dd);
					    strcat(t_dedr_begin,dedr_begin_dd);
					}
					
					/* 43-50 ���ͮĲפ��� */
					strcpy(dedr_end_c,cm_cdate_str_100(dedr_end));
					cm_split_ymd_100(dedr_end_c,dedr_end_yy,dedr_end_mm,dedr_end_dd);
					
					if (dedr_end_yy[0] == '\0')
					{
					    strcat(prtstr,"0000");
					    strcpy(t_dedr_end,"0000");
					}
					else
					{
					    strcat(prtstr, itoa( 1911+ (atoi(dedr_end_yy))));
					    strcpy(t_dedr_end,itoa( 1911+ (atoi(dedr_end_yy))));
					}
					
					if (dedr_end_mm[0] == '\0')
					{
					    strcat(prtstr,"00");
					    strcat(t_dedr_end,"00");
					}
					else
					{
					    strcat(prtstr,dedr_end_mm);
					    strcat(t_dedr_end,dedr_end_mm);
					}
					
					if (dedr_end_dd[0] == '\0')
					{
					    strcat(prtstr,"00");
					    strcat(t_dedr_end,"00");
					}
					else
					{
					    strcat(prtstr,dedr_end_dd);
					    strcat(t_dedr_end,dedr_end_dd);
					}
					
					/* 51-56�O�I�}�l�ͮĦ~�� */
					strcpy(dply_begin_ori_c,cm_cdate_str_100(dply_begin_ori));
					cm_split_ymd_100(dply_begin_ori_c,dply_begin_ori_yy,dply_begin_ori_mm,dply_begin_ori_dd);
					
					if (dply_begin_ori_yy[0] == '\0')
					{
					    strcat(prtstr,"0000");
					    strcpy(t_dply_begin,"0000");
					}
					else
					{
					    strcat(prtstr, itoa( 1911+ (atoi(dply_begin_ori_yy))));
					    strcpy(t_dply_begin,itoa( 1911+ (atoi(dply_begin_ori_yy))));
					}
					
					if (dply_begin_ori_mm[0] == '\0')
					{
					    strcat(prtstr,"00");
					    strcat(t_dply_begin,"00");
					}
					else
					{
					    strcat(prtstr,dply_begin_ori_mm);
					    strcat(t_dply_begin,dply_begin_ori_mm);
					}
					
					/* 57-60 �O��Ъ��s�� */
					if (strncmp(chk_157,"Y",1) == 0)
					{
						strcat(prtstr,"0000");
						strcpy(t_iobjno,"0000");
					}
					else if (strlen(ipolicy)>= 17)
					{
					    strncpy(imark, ipolicy+CAR_POLICY_LEN, 4);
					    imark[4]='\0';
					    if (strlen(rtrim(imark)) == 0)
					    {
					        strcat(prtstr,"0001");
					        strcpy(t_iobjno,"0001");
					    }
					    else
					    {
					        strcat(prtstr,imark);
					        strcpy(t_iobjno,imark);
					    }
					}
					else
					{
					    strcat(prtstr,"0001");
					    strcpy(t_iobjno,"0001");
					}
					
					f_1090701= 0;f_1090101 = 0;f_1120501 = 0;
					$EXECUTE ply_data INTO $ply_dpolicy,$f_1090701,$f_1090101,$f_1120501 USING $ipolicy; 
					if (strncmp(chk_157,"Y",1) == 0)
					{
						strcat(prtstr,"000000");      /* 61-66 ��l�o�Ӧ~�� */
						strcat(prtstr,"0000");        /* 67-72 �s�y�~�� */
						strcat(prtstr,"00");          
						strcat(prtstr,"00000000");    /* 73-80 �t�P�����N�� */
						strcat(prtstr,"00");          /* 81-82 ���������N�� */
						strcat(prtstr,"00");          /* 83-84 �����������O�N�� */
						strcpy(t_iissue_ym,"000000");
						strcpy(t_ipro_ym,"000000");
						strcpy(t_ibrand,"00000000");
						strcpy(t_icar_type_ori,"00");
						strcpy(t_icar_type,"00");
						strcpy(t_icar_type_no,"00");
					}
					else
					{
						/* 61-66 ��l�o�Ӧ~�� */
						if (iissue_yy[0] == '\0' ) 
						{
							strcat(prtstr,"0000");
							strcpy(t_iissue_ym,"0000");
						}
						else
						{
						   rfmtlong(atoi(iissue_yy),"&&&&",iissue_yy);
						   strcat(prtstr,iissue_yy);
						   strcpy(t_iissue_ym,iissue_yy);
						}
						
						if (iissue_mm[0] == '\0') 
						{
							strcat(prtstr,"00");
							strcat(t_iissue_ym,"0000");
						}
						else
						{
						   rfmtlong(atoi(iissue_mm),"&&",iissue_mm);
						   strcat(prtstr,iissue_mm);
						   strcat(t_iissue_ym,iissue_mm);
						}
						
						/* 67-72 �s�y�~�� */
						if (ipro_year[0]=='\0')
						{
						    strcat(prtstr,"0000");
						    strcpy(t_ipro_ym,"0000");
						}
						else
						{
						    strcat(prtstr,ipro_year);
						    strcpy(t_ipro_ym,ipro_year);
						}
		
						if (qpro_month <= 0) 
						{
							strcat(prtstr,"01");
							qpro_month = 1;
							strcat(t_ipro_ym,"01");
						}
						else 
						{
							rfmtlong(qpro_month,"&&",qpro_month_c);
							strcat(prtstr,qpro_month_c);
							strcat(t_ipro_ym,qpro_month_c);
						}
						
						/* 1000530002�t�P�����N���H�ഫ�t�P�����N�����e */
						ibrand_new[0]='\0';
						$OPEN cur_ibrand USING $ibrand;
						$FETCH cur_ibrand INTO $ibrand_new;
						if (ibrand_new[0]!='\0') strcpy(ibrand, ibrand_new);
						$CLOSE cur_ibrand;
						printf("ibrand[%s]ibrand_new[%s]\n", ibrand, ibrand_new);
										
						if(strncmp(ibrand,"MF0002",6)==0)
						  strcpy(ibrand, "ME000200");
						
						if( (strncmp(ibrand,"MR0001",6)==0) || (strncmp(ibrand,"MT0001",6)==0) )
						  strcpy(ibrand, "MM000100");
						
						/* �O�o�������t�P�����e6�X */
						strncpy(ibrand6, ibrand, 6);
						ibrand6[6]='\0';
						$SELECT COUNT(*)
						  INTO $cnt
						  FROM cu_code_data
						 WHERE itype='B9'
						   AND icode=$ibrand6;
						if (cnt>0)
						{
							/* 2010�X�� */
							sprintf(stmp,"SELECT count(*) \
					        	            FROM %s:ori_ply_relation \
					        	           WHERE ipolicy = '%s' \
					        	             AND dpolicy>='01/01/2010' ",list[k].dbname,ipolicy);
				        	$PREPARE ply_cnt_brand FROM $stmp;
							$EXECUTE ply_cnt_brand INTO $cnt;
							if (cnt>0) ibrand[4]=ibrand[5]='0';
						}
						
						/* 73-80�t�P�����N�� */
						if (ibrand[0] == '\0')
						{
							strcat(prtstr,"00000000");
							strcpy(t_ibrand,"00000000");
						}
						else
						{
							strcat(prtstr,ibrand);
							strcpy(t_ibrand,ibrand);
						}
						
						/* 81-82 ���������N�� */
						/*201502�s�W�C�Ө��إN���A���إN���^�k*/
						printf("--�����������O�N��\n");
						printf("--1089  icar_type_ori[%s] icar_type[%s]\n",icar_type_ori,icar_type);
						strcpy(icar_type,TRANS_CAR_TYPE(icar_type));
						if (icar_type[0] == '\0')
						    strcat(prtstr,"00");
						else if (strcmp(icar_type,"51") == 0)
						strcat(prtstr,"34");
						else
						    strcat(prtstr,icar_type);
						    
						strcpy(t_icar_type_ori,icar_type_ori);
						strcpy(t_icar_type,icar_type);
						    
						/* 83-84 �����������O�N�� */
						/*|  �����ۥ�| 01|
						  |  ������~| 02|
						  |�@��p�{��| 03|
						  |�h���p�{��| 04|*/
						if (f_1090101 > 0)
						{
							if(strcmp(icar_type,"01") == 0 || strcmp(icar_type,"02") == 0 || strcmp(icar_type,"32") == 0 || strcmp(icar_type,"34") == 0 || strcmp(icar_type,"35") == 0)
							{
								/*������L���ڴN�N����~��*/
						    	sprintf(stmp,"SELECT count(*) \
					        	                FROM %s:ply_ins_type \
					        	               WHERE ipolicy = '%s' AND (provision = 'L' OR provision matches '*;L*' OR provision matches '*L;*') ",list[k].dbname,ipolicy);
					        	$PREPARE ply_cnt_L FROM $stmp;
								$EXECUTE ply_cnt_L INTO $cnt_L;
						    	
						    	if(SQLCODE == SQLNOTFOUND) cnt_L = 0;
	
						        if (cnt_L > 0) 
						        {
						        	strcat(prtstr,"02");
						        	strcpy(t_icar_type_no,"02");
						        }
					        	else 
					        	{
					        		strcat(prtstr,"01");
					        		strcpy(t_icar_type_no,"01");
					        	}
							}
							else if(strcmp(icar_type,"07") == 0 || strcmp(icar_type,"15") == 0)
							{
								$SELECT FIRST 1 nvl(fkind,'')
					        	   INTO $fcar_kind
					        	   FROM ca_taxi_type
					        	  WHERE icard = $icomp_card
					        	  ORDER BY dupdate DESC;
					        	if (SQLCODE == SQLNOTFOUND) strcpy(fcar_kind,"N");
					        	
								if(strcmp(fcar_kind,"Y") == 0)
								{
									strcat(prtstr,"04");
									strcpy(t_icar_type_no,"04");
								}
					        	else 
					        	{
					        		strcat(prtstr,"03");
					        		strcpy(t_icar_type_no,"03");
					        	}
							}
							else if (strcmp(icar_type,"11") == 0 && equip_cmp(nequipment,"115") == TRUE) /* 1120316006_SC3_�O�o-���N�I���e�{�s�W���@�������������O�N��05�ή��s�X��t�ηs�W���@�����O */
							{
								strcat(prtstr,"05");
								strcpy(t_icar_type_no,"05");
							}
							else 
							{
								strcat(prtstr,"00");
								strcpy(t_icar_type_no,"00");
							}
						}
						else 
						{
							strcat(prtstr,"00");
							strcpy(t_icar_type_no,"00");
						}
					}
					
					if (strncmp(chk_157,"Y",1) == 0)
					{
						/* 85-89 �Ʈ�q */
						strcat(prtstr,"00000");
						/* 90-114 ����/�������X */
						strcat(prtstr,"                         ");
						/* 115-126 �P�Ӹ��X */
						strcat(prtstr,"            ");
						/* 127-131 �������� */
						strcat(prtstr,"0000 ");
						
						t_qcylinder = 0;
						strcpy(t_iengine," ");
						strcpy(t_itag," ");
						t_qpt = 0;
						strcpy(t_fpt," ");
					}
					else
					{
						/* 85-89 �Ʈ�q */
						if( (strcmp(ibrand,"E8013601")==0) && (qcylinder < 40) )
						qcylinder = 40;
						
						if( (strcmp(ibrand,"E8020601")==0) && (qcylinder < 40) )
						qcylinder = 40;
						
						rfmtlong(qcylinder,"&&&&&",qcylinder_c);
						strcat(prtstr,qcylinder_c);
						t_qcylinder = qcylinder;
						
						/* 90-114 ����/�������X */
						if ((iengine[0]=='\0' || iengine[0]==' ') && (ibody[0]=='\0' || ibody[0]==' ')) 
						{
							strcat(prtstr,"                         ");
							strcpy(t_iengine," ");
						}
						else if (iengine[0]=='\0' || iengine[0]==' ') 
						{
							strcat(prtstr,ibody);
							strcpy(t_iengine,ibody);
						}
						else 
						{
							strcat(prtstr,iengine);
							strcpy(t_iengine,iengine);
						}
						
						/* 115-126 �P�Ӹ��X */
						if (itag[0]=='\0' || itag[0]==' ') 
						{
							strcat(prtstr,"            ");
							strcpy(t_itag," ");
						}
						else 
						{
							strcat(prtstr,itag);
							strcpy(t_itag,itag);
						}
						
						/* 127-131 �������� */
						rfmtdouble((qpt*10),"&&&&", qpt_tmp);
						if ((strlen(rtrim(qpt_tmp))) == 0)
						{
						   strcat(prtstr,"0050");
						   t_qpt = 5;
						}
						else
						{
						   strcat(prtstr,qpt_tmp);
						   t_qpt = qpt *10;
						}
						
						if (strlen(trim(fpt)) == 0)
						{
						   strcat(prtstr,"P");
						   strcpy(t_fpt,"P");
						}
						else
						{
						   strcat(prtstr,fpt);
						   strcpy(t_fpt,fpt);
						}
					}
					/* 132-147 �Q�O�I�H��� */
					if (strcmp(sFassured, "1") == 0 ||
					    strcmp(sFassured, "3") == 0 ||
					    strcmp(sFassured, "5") == 0)
					{
						strcat(prtstr, rtrim(ilicense));
						for(i=0 ; i < (10-strlen(rtrim(ilicense))); i++)
							strcat(prtstr, " ");
						strcpy(t_iassured,rtrim(ilicense));
						
						if (strlen(rtrim(ibirth_yy)) == 0) 
						{
							strcat(prtstr,"0000");
							strcpy(t_dbirth_y,"0000");
						}
						else
						{
							rfmtlong(atoi(ibirth_yy),"&&&&",ibirth_yy);
							strcat (prtstr, ibirth_yy);
							strcpy(t_dbirth_y,ibirth_yy);
						}
						if (strlen(rtrim(fsex)) == 0)
						{
							strcat(prtstr,"0");
							strcpy(t_fsex,"0");
						}
						else
						{
							strcat(prtstr,fsex);
							strcpy(t_fsex,fsex);
						}
						
						if (strlen(rtrim(fmarriage)) == 0)
						{
							strcat(prtstr,"0");
							strcpy(t_fmarriage,"0");
						}
						else
						{
							strcat(prtstr,fmarriage);
							strcpy(t_fmarriage,fmarriage);
						}
					}
					else
					{
						strcat(prtstr, rtrim(ilicense));
						for(i=0 ; i < (10-strlen(rtrim(ilicense))); i++)
						strcat(prtstr, " ");
						strcat(prtstr,"0000");
						strcat(prtstr,"0");
						strcat(prtstr,"0");
						strcpy(t_iassured,rtrim(ilicense));
						strcpy(t_dbirth_y,"0000");
						strcpy(t_fsex,"0");
						strcpy(t_fmarriage,"0");
					}
					
					align_code[0]='\0';
					
					/* 148 �����I�h�����u�� */
					printf("--�h�����u��\n");
					if (strncmp(fins_grp,"1",1) == 0 && strcmp(iri_ins,"11") != 0)
					{
						tmp_align = (-1) * ipdmg_align;
						$SELECT icode into $align_code
						   FROM alignment
						  WHERE palign=$tmp_align
						    AND fclass='4';
						if (SQLCODE==SQLNOTFOUND || align_code[0]=='\0')
						{
							strcat(prtstr, "0");
							strcpy(t_ipdmg_align,"0");
						}
						else
						{
							strcat(prtstr, rtrim(align_code));
							strcpy(t_ipdmg_align,rtrim(icode));
						}
					}
					else
					{
					   strcat(prtstr, "0");
					   strcpy(t_ipdmg_align,"0");
					}
					
					/* 149 �ѵs�I�h�����u�� */
					if (strcmp(iri_ins,"11") == 0)
					{
						tmp_align = (-1) * ipbrg_align;
						$SELECT icode
						   INTO $align_code
						   FROM alignment
						  WHERE palign=$tmp_align
						    AND fclass='4';
						if (SQLCODE==SQLNOTFOUND || align_code[0]=='\0')
						{
							strcat(prtstr, "0");
							strcpy(t_ipbrg_align,"0");
						}
						else
						{
							strcat(prtstr, rtrim(align_code));
							strcpy(t_ipbrg_align,rtrim(align_code));
						}
					}
					else
					{
					   strcat(prtstr, "0");
					   strcpy(t_ipbrg_align,"0");
					}
		
					/* 150 �d���I�h�����u�� */
					if (strncmp(fins_grp,"2",1) == 0)
					{
						tmp_align = (-1) * iplia_align;
						$SELECT icode
						   INTO $align_code
						   FROM alignment
						  WHERE palign=$tmp_align
						    AND fclass='4';
						if (SQLCODE==SQLNOTFOUND || align_code[0]=='\0')
						{
							strcat(prtstr, "0");
							strcpy(t_iplia_align,"0");
						}
						else
						{
							strcat(prtstr, rtrim(align_code));
							strcpy(t_iplia_align,rtrim(align_code));
						}
					}
					else
					{
						strcat(prtstr, "0");
						strcpy(t_iplia_align,"0");
					}
					prtstr[150] = '\0';
					
					/* ���©��e */
					pdepreciate_year_tmp2[0] = '\0';
					fcontract_err = 0;
					pdepreciate_year =0;
					if ( strncmp(fins_grp,"1",1) == 0 && cnt_iins_main == 1)
					{
						pdepreciate_year_bak = 0;
						pdepreciate_year_aft = 0;
						/*$SELECT pdepreciate::int
						   INTO $pdepreciate_year_bak
						   FROM depreciation_rate a
	                      WHERE drate = (SELECT drate 
	                                       FROM ca_rate_date 
	                                      WHERE icode = $drate_ym_bak
	                                        AND itable = 'depreciation_rate')
	                        AND fcar_class = (SELECT CASE WHEN icar_grp = '1' THEN '3' ELSE fcar_class END
	                                            FROM car_type
	                                           WHERE fclass = '1' 
	                                             AND icode = $icar_type_ori_bak)
	                        AND qperiod_end  = '12';*/
						
						$SELECT pdepreciate::int
						   INTO $pdepreciate_year_aft
						   FROM depreciation_rate a
						  WHERE drate = (SELECT drate 
						                   FROM ca_rate_date 
						                  WHERE icode = $drate_ym
						                    AND itable = 'depreciation_rate')
						    AND fcar_class = (SELECT CASE WHEN icar_grp = '1' THEN '3' ELSE fcar_class END
						                        FROM car_type
						                       WHERE fclass = '1' 
						                         AND icode = $icar_type_ori)
						    AND qperiod_end  = '12';
	
						pdepreciate_year_tot = pdepreciate_year_aft;
						t_pdepreciate_year = pdepreciate_year_tot;
						printf("pdepreciate_year[%d] pdepreciate_year_tot[%d]\n",pdepreciate_year,pdepreciate_year_tot);
						rfmtlong(pdepreciate_year_tot,"&&&", pdepreciate_year_tmp);
						$EXECUTE CUR_CARCLASS INTO $fcar_class_pd USING $icar_type_ori;
						if ((pdepreciate_year_tot != 25) && fcar_class_pd[0] == '1') fcontract_err = 1;
						else if ((pdepreciate_year_tot != 30) && fcar_class_pd[0] == '2') fcontract_err = 1; 
						if (pdepreciate_year_tot >=0) strcat(pdepreciate_year_tmp2,"+");
						else strcat(pdepreciate_year_tmp2,"-");
						strcat(pdepreciate_year_tmp2,pdepreciate_year_tmp);
					}
					else if ((strcmp(iins_main,"01")  == 0 || strcmp(iins_main,"05")  == 0 || 
						      strcmp(iins_main,"09")  == 0 || strcmp(iins_main,"11")  == 0 ||
						      strcmp(iins_main,"110") == 0 || strcmp(iins_main,"111") == 0 ||
						      strcmp(iins_main,"129") == 0 || strcmp(iins_main,"20")  == 0 ||
						      strcmp(iins_main,"23")  == 0 || strcmp(iins_main,"75")  == 0 ||
						      strcmp(iins_main,"86")  == 0 || strcmp(iins_main,"86")  == 0 ||
						      strcmp(iins_main,"98")  == 0 ||
						      strcmp(iins_main,"201") == 0 || strcmp(iins_main,"205") == 0 || 
						      strcmp(iins_main,"209") == 0 || strcmp(iins_main,"211") == 0 ) && 
						      strcmp(trim(iins_type), "P")==0)
					{
						$SELECT pdepreciate::int
						   INTO $pdepreciate_year
						   FROM depreciation_rate a
	 					  WHERE drate = (SELECT drate 
	 					                   FROM ca_rate_date 
	 					                  WHERE icode = $drate_ym
	                                        AND itable = 'depreciation_rate')
	                        AND fcar_class   = '6'
	                        AND qperiod_end  = '12';
	                        
	                    printf("pdepreciate_year[%d] \n",pdepreciate_year);
	
						if (ibef > 0 && iaft == 0) pdepreciate_year_prov = 0 - (pdepreciate_year_aft - pdepreciate_year);
	                	else pdepreciate_year_prov = pdepreciate_year_aft - pdepreciate_year;
	                	t_pdepreciate_year = pdepreciate_year_prov;
						rfmtlong(pdepreciate_year_prov,"&&&", pdepreciate_year_prov_tmp);
						strcat(pdepreciate_year_tmp2,"-");
						strcat(pdepreciate_year_tmp2,pdepreciate_year_prov_tmp);
					}
					else if ((strcmp(trim(iins_main), "01")==0  || strcmp(trim(iins_main), "05")==0 ||
						      strcmp(trim(iins_main), "09")==0  || strcmp(trim(iins_main), "08")==0 ||
						      strcmp(trim(iins_main), "11")==0  ||
						      strcmp(trim(iins_main), "201")==0 || strcmp(trim(iins_main), "205")==0 ||
						      strcmp(trim(iins_main), "209")==0 || strcmp(trim(iins_main), "211")==0) &&
						      strcmp(trim(iins_type), "Q")==0)
					{
						$SELECT pdepreciate::int
						   INTO $pdepreciate_year
						   FROM depreciation_rate a
	 					  WHERE drate = (SELECT drate 
	 					                   FROM ca_rate_date 
	 					                  WHERE icode = $drate_ym
	                                        AND itable = 'depreciation_rate')
	                        AND fcar_class   = '7'
	                        AND qperiod_end  = '12';
	                        
	                    printf("pdepreciate_year[%d] \n",pdepreciate_year);
	
	                	if (ibef > 0 && iaft == 0) pdepreciate_year_prov = 0 - (pdepreciate_year_aft - pdepreciate_year);
	                	else pdepreciate_year_prov = pdepreciate_year_aft - pdepreciate_year;
	                	t_pdepreciate_year = pdepreciate_year_prov;
						rfmtlong(pdepreciate_year_prov,"&&&", pdepreciate_year_prov_tmp);
						strcat(pdepreciate_year_tmp2,"-");
						strcat(pdepreciate_year_tmp2,pdepreciate_year_prov_tmp);
					}
					else if ((strcmp(trim(iins_main), "01")==0  || strcmp(trim(iins_main), "05")==0  ||
						      strcmp(trim(iins_main), "09")==0  || strcmp(trim(iins_main), "08")==0  ||
						      strcmp(trim(iins_main), "11")==0  || strcmp(trim(iins_main), "181")==0 ||
						      strcmp(trim(iins_main), "201")==0 || strcmp(trim(iins_main), "205")==0 ||
						      strcmp(trim(iins_main), "209")==0 || strcmp(trim(iins_main), "211")==0) &&
						      strcmp(trim(iins_type), "M")==0)
					{
						$SELECT pdepreciate::int
						   INTO $pdepreciate_year
						   FROM depreciation_rate a
	 					  WHERE drate = (SELECT drate 
	 					                   FROM ca_rate_date 
	 					                  WHERE icode = $drate_ym
	                                        AND itable = 'depreciation_rate')
	                        AND fcar_class   = '8'
	                        AND qperiod_end  = '12';
	                        
	                    printf("pdepreciate_year[%d] \n",pdepreciate_year);
	
	                	if (ibef > 0 && iaft == 0) pdepreciate_year_prov = 0 - (pdepreciate_year_aft - pdepreciate_year);
	                	else pdepreciate_year_prov = pdepreciate_year_aft - pdepreciate_year;
	                	t_pdepreciate_year = pdepreciate_year_prov;
						rfmtlong(pdepreciate_year_prov,"&&&", pdepreciate_year_prov_tmp);
						strcat(pdepreciate_year_tmp2,"-");
						strcat(pdepreciate_year_tmp2,pdepreciate_year_prov_tmp);
					}
					else if ((strcmp(trim(iins_main), "01")==0  || strcmp(trim(iins_main), "05")==0  ||
						      strcmp(trim(iins_main), "09")==0  || strcmp(trim(iins_main), "08")==0  ||
						      strcmp(trim(iins_main), "11")==0  ||
						      strcmp(trim(iins_main), "201")==0 || strcmp(trim(iins_main), "205")==0 ||
						      strcmp(trim(iins_main), "209")==0 || strcmp(trim(iins_main), "211")==0) &&
						      strcmp(trim(iins_type), "Z")==0)
					{
						$SELECT pdepreciate::int
						   INTO $pdepreciate_year
						   FROM depreciation_rate a
	 					  WHERE drate = (SELECT drate 
	 					                   FROM ca_rate_date 
	 					                  WHERE icode = $drate_ym
	                                        AND itable = 'depreciation_rate')
	                        AND fcar_class   = '4'
	                        AND qperiod_end  = '12';
	                        
	                    printf("pdepreciate_year[%d] \n",pdepreciate_year);
						if (chk_cover_Z1 > 0 && chk_cover_Z == 0) pdepreciate_year_prov = 0 - (pdepreciate_year_aft - pdepreciate_year);
	                	else pdepreciate_year_prov = pdepreciate_year_aft - pdepreciate_year;
	                	t_pdepreciate_year = pdepreciate_year_prov;
						rfmtlong(pdepreciate_year_prov,"&&&", pdepreciate_year_prov_tmp);
						strcat(pdepreciate_year_tmp2,"-");
						strcat(pdepreciate_year_tmp2,pdepreciate_year_prov_tmp);
					}
					else 
					{
						strcat(pdepreciate_year_tmp2,"+000");
						t_pdepreciate_year = 0;
					}
	
	/*----------------------------------------���ʽ謰�ۭt�B�ܰʭn�e�e��----------------------------------------------*/
					sprintf(stmp,"SELECT mdeduct \
					        	    FROM %s:ply_ins_type_bak \
					               WHERE iendorse = '%s' AND iins_type = '%s' ",list[k].dbname,iendorse,iins_type);
					$PREPARE ply_bak_mdt FROM $stmp;
					$EXECUTE ply_bak_mdt INTO $old_mdeduct;
					
					strcpy(t_iins_type,iins_type);
					strcpy(t_iins_main,iins_main);
					strcpy(iins_type_main," ");
					strcpy(iins_type_dtl," ");
					strcpy(iins_type_develop , " ");
					strcpy(iins_type_rule , " "); 
					strcpy(frule, " ");
					/* �O�I�����N�� */
					/*** �o�i���߫O�I�����B�O�v�W����� ***/
					$EXECUTE CUR_DEVELOP
					    INTO $iins_type_main,$iins_type_dtl,$iins_type_develop,$iins_type_rule,$fcal_way
					   USING $iins_type;
					   
					if (SQLCODE==SQLNOTFOUND)
					{
						strcpy(iins_type_main,"!");
						strcpy(iins_type_dtl,"&&");
						strcpy(iins_type_develop,"@@");
						strcpy(iins_type_develop,"20");
						strcpy(frule,"N");
						strcpy(fcal_way," ");
					}
					
					twice_20_77 = 2;
					if ((strcmp(iedr_type, "20") == 0) || (strcmp(iedr_type, "77") == 0))
					{
						if(strcmp(iins_type,"29")==0 || strcmp(iins_type,"30")==0 ||strcmp(iins_type,"301")==0 ||strcmp(iins_type,"302")==0||strcmp(iins_type,"530")==0)
						{
							twice_20_77 = 2;
						}
						else
						{
							twice_20_77 = 1;
						}
					}
					else
					{
						twice_20_77 = 2;
					}
					printf("twice_20_77[%d] \n",twice_20_77);
					while(twice_20_77 < 3)
					{
						prtstr[150] = '\0';
						/* 1000323008-A1��100�~4��1��_�ӫO���N���I�O�o�I�ج�51�B52�B53���C�@�ӤH��˫O�B�A�H�O�B�G���e */
						if ((f_1000401==1) && (strcmp(trim(iins_type_develop),"51")==0 || strcmp(trim(iins_type_develop),"52")==0 || strcmp(trim(iins_type_develop),"53")==0))
						{
						    medrinj_cover = medrdea_cover;
						}
		
						if (fcal_way[0] == '1')
						{
							sprintf(stmt,"SELECT to_char(drate, '%%Y%%m') drate_code FROM ca_rate_date \
											WHERE itable = 'ca_rate' AND icode = ? ");
							$PREPARE CUR_DRATE_1 FROM $stmt;
						}
						else
						{
							sprintf(stmt,"SELECT to_char(drate, '%%Y%%m') drate_code FROM ca_rate_date \
											WHERE itable = 'cover_vs_premium' AND icode = ? ");
							$PREPARE CUR_DRATE_1 FROM $stmt;
						}
						
						$EXECUTE CUR_CARCLASS INTO $fcar_class USING $icar_type;
						if(SQLCODE == SQLNOTFOUND)
						{
							strcpy(fcar_class,"1");
						}
						strcpy(fcar_class,trim(fcar_class));

						minjured_cover_bak_deve = 0;mdeath_cover_bak_deve = 0;mdamage_cover_bak_deve = 0;mdeduct_bak_deve = 0;
						minjured_cover_deve = 0;mdeath_cover_deve = 0;mdamage_cover_deve = 0;mdeduct_deve = 0;
						if (atoi(iedr_type) >= 80)
						{
							sprintf(stmt,"SELECT NVL(minjured_cover,0),NVL(mdeath_cover,0),NVL(mdamage_cover,0),NVL(mdeduct,0),count(iendorse),iins_type,iendorse_old \
						                FROM %s:ply_ins_type_bak \
						               WHERE iendorse = '%s' AND ipolicy = '%s' AND iins_type = '%s' \
						               GROUP by 1,2,3,4,6,7 ",list[k].dbname,iendorse,ipolicy,iins_type);
							$PREPARE CUR_BAK_TMP1 FROM $stmt;
							$EXECUTE CUR_BAK_TMP1 INTO $minjured_cover_bak_deve,$mdeath_cover_bak_deve,$mdamage_cover_bak_deve,$mdeduct_bak_deve,$tttmp1,$tttmp2,$iendorse_old;	
							if((minjured_cover_bak_deve+mdeath_cover_bak_deve+mdamage_cover_bak_deve) ==0)
							{
								sprintf(stmt,"SELECT NVL(minjured_cover,0),NVL(mdeath_cover,0),NVL(mdamage_cover,0),NVL(mdeduct,0),count(iendorse),iins_type,iendorse_old \
						                FROM %s:ply_ins_type_bak \
						               WHERE iendorse = '%s' AND ipolicy = '%s' AND iins_type = '%s' \
						               GROUP by 1,2,3,4,6,7 ",list[k].dbname,iendorse_old,ipolicy,iins_type);
								$PREPARE CUR_BAK_TMP11 FROM $stmt;
								$EXECUTE CUR_BAK_TMP11 INTO $minjured_cover_bak_deve,$mdeath_cover_bak_deve,$mdamage_cover_bak_deve,$mdeduct_bak_deve,$tttmp1,$tttmp2,$iendorse_old;	
								if(SQLCODE == SQLNOTFOUND)
								{
									sprintf(stmt,"SELECT NVL(minjured_cover,0),NVL(mdeath_cover,0),NVL(mdamage_cover,0),NVL(mdeduct,0),count(ipolicy),iins_type \
						                FROM %s:ori_ins_type \
						               WHERE ipolicy = '%s' AND iins_type = '%s' \
						               GROUP by 1,2,3,4,6 ",list[k].dbname,ipolicy,iins_type);
									$PREPARE CUR_BAK_TMP12 FROM $stmt;
									$EXECUTE CUR_BAK_TMP12 INTO $minjured_cover_bak_deve,$mdeath_cover_bak_deve,$mdamage_cover_bak_deve,$mdeduct_bak_deve,$tttmp1,$tttmp2;	
								}
							}
							minjured_cover_deve = minjured_cover_bak_deve;
							mdeath_cover_deve   = mdeath_cover_bak_deve;
							mdamage_cover_deve  = mdamage_cover_bak_deve;
							mdeduct_deve        = mdeduct_bak_deve;
						}
						else 
						{
							sprintf(stmt,"SELECT NVL(minjured_cover,0),NVL(mdeath_cover,0),NVL(mdamage_cover,0),NVL(mdeduct,0),count(iendorse),iins_type \
							                FROM %s:ply_ins_type_bak \
							               WHERE iendorse = '%s' AND ipolicy = '%s' AND iins_type = '%s' \
							               GROUP by 1,2,3,4,6 ",list[k].dbname,iendorse,ipolicy,iins_type);
							$PREPARE CUR_BAK_TMP2 FROM $stmt;
							$EXECUTE CUR_BAK_TMP2 INTO $minjured_cover_bak_deve,$mdeath_cover_bak_deve,$mdamage_cover_bak_deve,$mdeduct_bak_deve,$tttmp1,$tttmp2;
							
							minjured_cover_deve = medrinj_cover + minjured_cover_bak_deve;
							mdeath_cover_deve   = medrdea_cover + mdeath_cover_bak_deve;
							mdamage_cover_deve  = medrdmg_cover + mdamage_cover_bak_deve;
							if (((strcmp(iedr_type, "20") == 0) || (strcmp(iedr_type, "77") == 0)) && twice_20_77 == 1)
							{
								mdeduct_tmp2 = 0;
								mdeduct_tmp2 = mdeduct;
								mdeduct = mdeduct_bak_deve;
								mdeduct_deve = mdeduct;
							}
							else if (((strcmp(iedr_type, "20") == 0) || (strcmp(iedr_type, "77") == 0)) && twice_20_77 == 2)
							{
								mdeduct = mdeduct_tmp2;
								mdeduct_deve = mdeduct;
							}
							else
							{
								mdeduct_deve = mdeduct + mdeduct_bak_deve;	
							}
						}				

						/* �W�B�d���I���ۭt�B��춷�M�� 0 */
						if( (strcmp(trim(iins_type),"29")==0) || (strcmp(trim(iins_type),"30")==0) || (strcmp(trim(iins_type),"301")==0) || (strcmp(trim(iins_type),"302")==0) ||
					        (strcmp(trim(iins_type),"238")==0)|| (strcmp(trim(iins_type),"198")==0)|| (strcmp(trim(iins_type),"530")==0))
						{
							mdeduct = 0;
							mdeduct_bak_deve = 0;
							mdeduct_deve = 0;
						}
						
						/* T */
						prov_T = 0;
						$SELECT count(*) INTO $prov_T FROM prov_tmp WHERE provision = 'T' AND f_af_bf = 'a';
						prov_bf_T = 0;
						$SELECT count(*) INTO $prov_bf_T FROM prov_tmp WHERE provision = 'T' AND f_af_bf = 'b';
						/* K */
						prov_K = 0;
						$SELECT count(*) INTO $prov_K FROM prov_tmp WHERE provision = 'K' AND f_af_bf = 'a';
						prov_bf_K = 0;
						$SELECT count(*) INTO $prov_bf_K FROM prov_tmp WHERE provision = 'K' AND f_af_bf = 'b';
						
						if (f_1060101 > 0)
						{
							if( (strcmp(trim(iins_type),"11")==0))
							{
								if(strcmp(iedr_type, "02") == 0 || count_ins2 > 0 || (mdamage_cover_deve ==0 && strcmp(iedr_type, "02") != 0 &&
								   strncmp(fedr_class,"2",1) != 0 && strncmp(fedr_class,"8",1) != 0 && atoi(iedr_type) < 80))
								{
									if ( mdeduct==0 && f_1090101 == 0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"98");
										strcpy(iins_type_develop,"14");
										strcpy(iins_type_rule,"20");
										strcpy(frule, "N");
									}
									else if((strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0))
									{
										if (f_1120501 > 0) {}
										else  strcpy(iins_type_develop , "14");
										
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"98");
										strcpy(iins_type_rule,"20");
										strcpy(frule, "N");
									}
									else if(fcontract_err == 1)
									{
										if (f_1120501 > 0) {}
										else  strcpy(iins_type_develop , "14");
										
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"98");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
								}
								else
								{
									if ( mdeduct_deve==0 && f_1090101 == 0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"98");
										strcpy(iins_type_develop,"14");
										strcpy(iins_type_rule,"20");
										strcpy(frule, "N");
									}
									else if((strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0))
									{
										if (f_1120501 > 0) {}
										else  strcpy(iins_type_develop , "14");
										
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"98");
										strcpy(iins_type_rule,"20");
										strcpy(frule, "N");
									}
									else if(fcontract_err == 1)
									{
										if (f_1120501 > 0) {}
										else  strcpy(iins_type_develop , "14");
										
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"98");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
								}
								if( fcar_class[0] == '1' )
								   strcpy(iproduct,"112100201011");
								else
								   strcpy(iproduct,"122110201011");
							}
							else if( (strcmp(trim(iins_type),"211")==0))
							{
								if((strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0))
								{
									strcpy(iins_type_main,"Z");
									strcpy(iins_type_dtl,"98");
									strcpy(iins_type_rule,"20");
									strcpy(frule, "N");
								}
								else if(fcontract_err == 1)
								{
									strcpy(iins_type_main,"Z");
									strcpy(iins_type_dtl,"98");
									strcpy(iins_type_rule , "20");
									strcpy(frule, "N");
								}
							}
							else if (strcmp(trim(iins_type), "01") == 0)
							{
								if(strcmp(iedr_type, "02") == 0 || count_ins2 > 0 || (mdamage_cover_deve ==0 && strcmp(iedr_type, "02") != 0 &&
								   strncmp(fedr_class,"2",1) != 0 && strncmp(fedr_class,"8",1) != 0 && atoi(iedr_type) < 80))
								{
									if ((mdeduct == 0 || mdeduct > 20000) && f_1090101 == 0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_develop,"08");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									else if((strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0))
									{
										if (f_1120501 > 0) {}
										else  strcpy(iins_type_develop , "08");
										
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									else if(fcontract_err == 1)
									{
										if (f_1120501 > 0) {}
										else  strcpy(iins_type_develop , "08");
										
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}	
								}
								else
								{
									if ((abs(mdeduct_deve) == 0 || abs(mdeduct_deve) > 20000) && f_1090101 == 0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_develop,"08");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									else if((strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0))
									{
										if (f_1120501 > 0) {}
										else  strcpy(iins_type_develop , "08");
										
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									else if(fcontract_err == 1)
									{
										if (f_1120501 > 0) {}
										else  strcpy(iins_type_develop , "08");
										
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
								}
							}
							else if (strcmp(trim(iins_type), "201") == 0)
							{
								if((strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0))
								{
									strcpy(iins_type_main,"Z");
									strcpy(iins_type_dtl,"97");
									strcpy(iins_type_rule , "20");
									strcpy(frule, "N");
								}
								else if(fcontract_err == 1)
								{
									strcpy(iins_type_main,"Z");
									strcpy(iins_type_dtl,"97");
									strcpy(iins_type_rule , "20");
									strcpy(frule, "N");
								}	
							}
							else if (strcmp(trim(iins_type), "05") == 0)
							{
								printf("mdeduct[%d],mdeduct_bak_deve[%d],mdeduct_deve[%d],\n icar_type_ori[%s],fcontract_err[%d] \n",mdeduct,mdeduct_bak_deve,mdeduct_deve,icar_type_ori,fcontract_err);
								if(strcmp(iedr_type, "02") == 0 || count_ins2 > 0 || (mdamage_cover_deve ==0 && strcmp(iedr_type, "02") != 0 &&
								   strncmp(fedr_class,"2",1) != 0 && strncmp(fedr_class,"8",1) != 0 && atoi(iedr_type) < 80))
								{
									if ((mdeduct == 0 || mdeduct > 20000) && f_1090101 == 0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_develop,"08");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									else if((strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0))
									{
										if (f_1120501 > 0) {}
										else  strcpy(iins_type_develop , "08");
										
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									else if(fcontract_err == 1)
									{
										if (f_1120501 > 0) {}
										else  strcpy(iins_type_develop , "08");
										
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
								}
								else 
								{
									if ((abs(mdeduct_deve) == 0 || abs(mdeduct_deve) > 20000) && f_1090101 == 0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_develop,"08");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									else if((strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0))
									{
										if (f_1120501 > 0) {}
										else  strcpy(iins_type_develop , "08");
										
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									else if(fcontract_err == 1)
									{
										if (f_1120501 > 0) {}
										else  strcpy(iins_type_develop , "08");
										
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
								}
							}
							else if (strcmp(trim(iins_type), "205") == 0)
							{
								if((strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0))
								{
									strcpy(iins_type_main,"Z");
									strcpy(iins_type_dtl,"97");
									strcpy(iins_type_rule , "20");
									strcpy(frule, "N");
								}
								else if(fcontract_err == 1)
								{
									strcpy(iins_type_main,"Z");
									strcpy(iins_type_dtl,"97");
									strcpy(iins_type_rule , "20");
									strcpy(frule, "N");
								}
							}
							else if (strcmp(trim(iins_type),"09")==0)
							{
								if(strcmp(iedr_type, "02") == 0 || count_ins2 > 0 || (mdamage_cover_deve ==0 && strcmp(iedr_type, "02") != 0 &&
								   strncmp(fedr_class,"2",1) != 0 && strncmp(fedr_class,"8",1) != 0 && atoi(iedr_type) < 80))
								{
									if (mdeduct != 0 && f_1090101 == 0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_develop, "08");
										strcpy(iins_type_rule , "20");
										strcpy(frule,"N");
									}
									
									if ((strcmp(icar_type,"03") != 0) && (strcmp(icar_type,"21") != 0) &&
										(strcmp(icar_type,"22") != 0) && (strcmp(icar_type,"04") != 0) &&
										(strcmp(icar_type,"19") != 0))
									{
										if (f_1120501 > 0) {}
										else  strcpy(iins_type_develop , "08");
										
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									if((strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0))
									{
										if (f_1120501 > 0) {}
										else  strcpy(iins_type_develop , "08");
										
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									if(fcontract_err == 1)
									{
										if (f_1120501 > 0) {}
										else  strcpy(iins_type_develop , "08");
										
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
								}
								else 
								{
									if (mdeduct_deve != 0 && f_1090101 == 0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_develop, "08");
										strcpy(iins_type_rule , "20");
										strcpy(frule,"N");
									}
									
									if ((strcmp(icar_type,"03") != 0) && (strcmp(icar_type,"21") != 0) &&
										(strcmp(icar_type,"22") != 0) && (strcmp(icar_type,"04") != 0) &&
										(strcmp(icar_type,"19") != 0))
									{
										if (f_1120501 > 0) {}
										else  strcpy(iins_type_develop , "08");
										
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									if((strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0))
									{
										if (f_1120501 > 0) {}
										else  strcpy(iins_type_develop , "08");
										
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									if(fcontract_err == 1)
									{
										if (f_1120501 > 0) {}
										else  strcpy(iins_type_develop , "08");
										
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
								}
							}
							else if (strcmp(trim(iins_type),"209")==0)
							{
								if ((strcmp(icar_type,"03") != 0) && (strcmp(icar_type,"21") != 0) &&
									(strcmp(icar_type,"22") != 0) && (strcmp(icar_type,"04") != 0) &&
									(strcmp(icar_type,"19") != 0))
								{
									strcpy(iins_type_main,"Z");
									strcpy(iins_type_dtl,"97");
									strcpy(iins_type_rule , "20");
									strcpy(frule, "N");
								}
								if((strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0))
								{
									strcpy(iins_type_main,"Z");
									strcpy(iins_type_dtl,"97");
									strcpy(iins_type_rule , "20");
									strcpy(frule, "N");
								}
								if(fcontract_err == 1)
								{
									strcpy(iins_type_main,"Z");
									strcpy(iins_type_dtl,"97");
									strcpy(iins_type_rule , "20");
									strcpy(frule, "N");
								}
							}
							else if (strcmp(trim(iins_type),"31")== 0)
							{
								printf("iedr_type[%s]\n",iedr_type);
								printf("count_ins2[%d]\n",count_ins2);
								printf("mdeduct[%d]\n",mdeduct);
								printf("medrdmg_cover[%d]\n",medrdmg_cover);
								printf("medrinj_cover[%d]\n",medrinj_cover);
								printf("provision[%s]\n",provision);
								if(strcmp(iedr_type, "02") == 0 || count_ins2 > 0 || (mdamage_cover_deve ==0 && strcmp(iedr_type, "02") != 0 &&
								   strncmp(fedr_class,"2",1) != 0 && strncmp(fedr_class,"8",1) != 0 && atoi(iedr_type) < 80))
								{
									if( abs(mdeduct) > 0 && f_1090101 == 0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"99");
										strcpy(iins_type_develop , "31");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									
									if( medrdmg_cover == 2 * medrinj_cover )
									{
										
									}
									else
									{
										if( fcar_class[0] == '1' )
										  strcpy(iproduct,"111120461211");
										else
										  strcpy(iproduct,"121130461211");
										  
										if(f_1090101 == 0)
										{
											strcpy(iins_type_main,"Z");
											strcpy(iins_type_dtl,"99");
											strcpy(iins_type_develop , "31");
											strcpy(iins_type_rule , "20");
											strcpy(frule, "N");
										}
									}
									
									if (prov_T > 0 && fcar_class[0] == '2')
									{
										if( medrdmg_cover == 2 * medrinj_cover )
											strcpy(iproduct,"121130351211");
										else 
											strcpy(iproduct,"121130461211");
									}
								}
								else 
								{	
									if( abs(mdeduct_deve) > 0 && f_1090101 == 0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"99");
										strcpy(iins_type_develop , "31");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									
									if( mdamage_cover_deve == 2 * minjured_cover_deve)
									{
										
									}
									else
									{
										if( fcar_class[0] == '1' )
										  strcpy(iproduct,"111120461211");
										else
										  strcpy(iproduct,"121130461211");
										  
										if(f_1090101 == 0)
										{
											strcpy(iins_type_main,"Z");
											strcpy(iins_type_dtl,"99");
											strcpy(iins_type_develop , "31");
											strcpy(iins_type_rule , "20");
											strcpy(frule, "N");
										}
									}
									
									if (prov_T > 0 && fcar_class[0] == '2')
									{
										if( mdamage_cover_deve == 2 * minjured_cover_deve)
											strcpy(iproduct,"121130351211");
										else 
											strcpy(iproduct,"121130461211");
									}

								}
							}
							else if (strcmp(trim(iins_type),"32") == 0)
							{
								if(strcmp(iedr_type, "02") == 0 || count_ins2 > 0 || (mdamage_cover_deve ==0 && strcmp(iedr_type, "02") != 0 &&
								   strncmp(fedr_class,"2",1) != 0 && strncmp(fedr_class,"8",1) != 0 && atoi(iedr_type) < 80))
								{
									if( abs(mdeduct) > 0 && f_1090101 == 0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"99");
										strcpy(iins_type_develop , "32");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									if (prov_T > 0 && fcar_class[0] == '2')
									{
										strcpy(iproduct,"121130361211");
									}
								}	
								else 
								{
									if( abs(mdeduct_deve) > 0 && f_1090101 == 0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"99");
										strcpy(iins_type_develop , "32");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									if (prov_T > 0 && fcar_class[0] == '2')
									{
										strcpy(iproduct,"121130361211");
									}
								}
							}
							else if ((f_1000401==0) && (strcmp(trim(iins_type),"55")==0))
							{
								if ((abs(mdeath_cover_deve) == 6000000) || (minjured_cover_deve == mdeath_cover_deve))
								{
									strcpy(iins_type_main,"Z");
									strcpy(iins_type_dtl,"91");
									strcpy(iins_type_develop, "51");
									strcpy(iins_type_rule , "20");
									strcpy(frule, "N");
								}
								else if (strcmp(trim(iins_type),"55") == 0 &&
								        (strcmp(icar_type,"03") != 0 && strcmp(icar_type,"04") != 0 &&
								         strcmp(icar_type,"05") != 0 && strcmp(icar_type,"06") != 0 &&
								         strcmp(icar_type,"11") != 0 && strcmp(icar_type,"12") != 0 &&
								         strcmp(icar_type,"18") != 0 && strcmp(icar_type,"19") != 0 &&
								         strcmp(icar_type,"20") != 0 && strcmp(icar_type,"21") != 0 &&
								         strcmp(icar_type,"22") != 0 && strcmp(icar_type,"31") != 0 ))
								{
									strcpy(iins_type_main,"Z");
									strcpy(iins_type_dtl,"91");
									strcpy(iins_type_develop, "51");
									strcpy(iins_type_rule , "20");
									strcpy(frule, "N");
								}
							}
							else if (strcmp(trim(iins_type),"55") == 0 &&
								    (strcmp(icar_type,"03") != 0 && strcmp(icar_type,"04") != 0 &&
								     strcmp(icar_type,"05") != 0 && strcmp(icar_type,"06") != 0 &&
								     strcmp(icar_type,"11") != 0 && strcmp(icar_type,"12") != 0 &&
								     strcmp(icar_type,"18") != 0 && strcmp(icar_type,"19") != 0 &&
								     strcmp(icar_type,"20") != 0 && strcmp(icar_type,"21") != 0 &&
								     strcmp(icar_type,"22") != 0 && strcmp(icar_type,"31") != 0 ))
							{
								strcpy(iins_type_main,"Z");
								strcpy(iins_type_dtl,"91");
								strcpy(iins_type_develop, "51");
								strcpy(iins_type_rule , "20");
								strcpy(frule, "N");
							}
							
							if (strcmp(iins_type,"131") == 0 || strcmp(iins_type,"132") == 0 || strcmp(iins_type,"24") == 0 ||
								strcmp(iins_type,"26") == 0  || strcmp(iins_type,"31") == 0  || strcmp(iins_type,"32") == 0 ||
								strcmp(iins_type,"41") == 0  || strcmp(iins_type,"42") == 0 )
							{
								/* 231�B232�B331�B332 132�O�v��~���A���C�J */
								chk_plia = 0;
								/*99�O�v��]�w���ʧO�~�֫Y�Ƥ~�P���|���ۦP�A�Y���e�X���涷�Φ��@�����*/
								if ((sFassured[0]=='1' || sFassured[0]=='3' || sFassured[0]=='5') && atoi(drate_ym) < 99)  /*** �۵M�H ***/
								{
									/* ���d */
									strcpy( sDbirth,     cm_cdate_str_100(dbirth));
									strcpy( sDply_begin, cm_cdate_str_100(dedr_begin));
									rc = get_age( sDbirth, sDply_begin, &age, v_sMsg);
									
									/*if (atoi(drate_ym) < 99) 
										rc = get_sex_age_factor( "2", &age, fsex, "99", &psex_age_chk, v_sMsg);
									else 
										rc = get_sex_age_factor( "2", &age, fsex, drate_ym, &psex_age_chk, v_sMsg);
										
									if (psex_age_lia != psex_age_chk) chk_plia = 1;*/

									rc = get_sex_age_factor( "2", &age, fsex, "99", &psex_age_chk, v_sMsg);
									if (psex_age_lia != psex_age_chk) chk_plia = 1;

								}
								else chk_plia = 0;
								
								printf("--psex_age_lia[%f],psex_age_chk[%f] \n",psex_age_lia,psex_age_chk);
								printf("--drate_ym[%s],sDbirth[%s],sDply_begin[%s],age[%f],chk_plia[%f] \n",drate_ym,sDbirth,sDply_begin,age,chk_plia);
								
								/*���w��31/32 131/132���ݦ~�֫Y��*/
								if (chk_plia > 0)
								{
									if (strcmp(iins_type,"31") == 0  || strcmp(iins_type,"32") == 0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"99");
										strcpy(iins_type_rule , "20"); 
										strcpy(frule, "N");
									}
								}
							}
			
							printf("--666666iins_main[%s],iins_type[%s],fins_grp[%s],iri_ins[%s]\n",iins_main,iins_type,fins_grp,iri_ins);
							if(strncmp(iins_type,"P",1) == 0 || strncmp(iins_type,"Q",1) == 0 ||
							   strncmp(iins_type,"M",1) == 0 || strncmp(iins_type,"Z",1) == 0 ||
							   strncmp(iins_type,"D",1) == 0 || strncmp(iins_type,"K",1) == 0 ||
							   strncmp(iins_type,"S",1) == 0) 
							{
								if (strncmp(fins_grp,"1",1) == 0 && strcmp(trim(iri_ins),"11") != 0)
								{
									/*strcpy(iins_type_develop, "04");*/
								}
								else if (strcmp(trim(iri_ins),"11") == 0)
								{
									strcpy(iins_type_develop, "13");
								}
								else
								{
									strcpy(iins_type_develop, "62");
								}
							}
							else if(strncmp(iins_type,"F",1) == 0 || strncmp(iins_type,"G",1) == 0 ||
							        strncmp(iins_type,"H",1) == 0 || strncmp(iins_type,"J",1) == 0 ||
							        strncmp(iins_type,"L",1) == 0 || strncmp(iins_type,"R",1) == 0 ||
							        strncmp(iins_type,"V",1) == 0) 
							{
								if (strncmp(fins_grp,"1",1) == 0 && strcmp(trim(iri_ins),"11") != 0)
								{
									/*strcpy(iins_type_develop, "04");*/
								}
								else if (strcmp(trim(iri_ins),"11") == 0)
								{
									strcpy(iins_type_develop, "13");
								}
								else
								{
									strcpy(iins_type_develop, "62");
								}
							}
						}
						else 
						{
							$SELECT iins_type_rule,frule
							   INTO $iins_type_develop,$frule
							   FROM insurance_type
							  WHERE iins_type = $iins_type;
							  
							if( (strcmp(trim(iins_type),"11")==0))
							{
								if(strcmp(iedr_type, "02") == 0 || count_ins2 > 0 || (mdamage_cover_deve ==0 && strcmp(iedr_type, "02") != 0 &&
								   strncmp(fedr_class,"2",1) != 0 && strncmp(fedr_class,"8",1) != 0 && atoi(iedr_type) < 80))
								{
									if ( mdeduct==0 && f_1090101 == 0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"98");
										strcpy(iins_type_develop,"21");
										strcpy(iins_type_rule,"20");
										strcpy(frule, "N");
									}
									else if(strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"98");
										strcpy(iins_type_develop,"21");
										strcpy(iins_type_rule,"20");
										strcpy(frule, "N");
									}
									else if(fcontract_err == 1)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"98");
										strcpy(iins_type_develop , "21");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}	
								}
								else  
								{
									if ( mdeduct_deve==0 && f_1090101 == 0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"98");
										strcpy(iins_type_develop,"21");
										strcpy(iins_type_rule,"20");
										strcpy(frule, "N");
									}
									else if(strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"98");
										strcpy(iins_type_develop,"21");
										strcpy(iins_type_rule,"20");
										strcpy(frule, "N");
									}
									else if(fcontract_err == 1)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"98");
										strcpy(iins_type_develop , "21");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
								}
								
								if( fcar_class[0] == '1' )
								   strcpy(iproduct,"112100201011");
								else
								   strcpy(iproduct,"122110201011");
							}
							else if (strcmp(trim(iins_type), "01") == 0)
							{
								if(strcmp(iedr_type, "02") == 0 || count_ins2 > 0 || (mdamage_cover_deve ==0 && strcmp(iedr_type, "02") != 0 &&
								   strncmp(fedr_class,"2",1) != 0 && strncmp(fedr_class,"8",1) != 0 && atoi(iedr_type) < 80))
								{
									if (mdeduct == 0 || mdeduct > 20000)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_develop,"15");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									else if(strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_develop,"15");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									else if(fcontract_err == 1)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_develop,"15");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
								}
								else 
								{
									if (abs(mdeduct_deve) == 0 || abs(mdeduct_deve) > 20000)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_develop,"15");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									else if(strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_develop,"15");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									else if(fcontract_err == 1)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_develop,"15");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
								}
							}
							else if (strcmp(trim(iins_type), "05") == 0)
							{
								if(strcmp(iedr_type, "02") == 0 || count_ins2 > 0 || (mdamage_cover_deve ==0 && strcmp(iedr_type, "02") != 0 &&
								   strncmp(fedr_class,"2",1) != 0 && strncmp(fedr_class,"8",1) != 0 && atoi(iedr_type) < 80))
								{
									if (mdeduct == 0 || mdeduct > 20000)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_develop,"15");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									else if(strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_develop,"15");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									else if(fcontract_err == 1)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_develop,"15");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
								}
								else 
								{
									if (abs(mdeduct_deve) == 0 || abs(mdeduct_deve) > 20000)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_develop,"15");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									else if(strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_develop,"15");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									else if(fcontract_err == 1)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_develop,"15");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
								}
							}
							else if (strcmp(trim(iins_type),"09")==0)
							{
								if(strcmp(iedr_type, "02") == 0 || count_ins2 > 0 || (mdamage_cover_deve ==0 && strcmp(iedr_type, "02") != 0 &&
								   strncmp(fedr_class,"2",1) != 0 && strncmp(fedr_class,"8",1) != 0 && atoi(iedr_type) < 80))
								{
									if (mdeduct != 0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_develop, "15");
										strcpy(iins_type_rule , "20");
										strcpy(frule,"N");
									}
									if ((strcmp(icar_type,"03") != 0) && (strcmp(icar_type,"21") != 0) &&
										(strcmp(icar_type,"22") != 0) && (strcmp(icar_type,"04") != 0) &&
										(strcmp(icar_type,"19") != 0))
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_develop, "15");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									if (prov_K > 0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_develop , "15");
										strcpy(iins_type_rule , "20");
										strcpy(frule,"N");
									}
									if (prov_bf_K > 0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_develop , "15");
										strcpy(iins_type_rule , "20");
										strcpy(frule,"N");
									}
									if(strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_develop,"15");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									if(fcontract_err == 1)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_develop,"15");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
								}
								else
								{
									if (mdeduct_deve != 0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_develop, "15");
										strcpy(iins_type_rule , "20");
										strcpy(frule,"N");
									}
									if ((strcmp(icar_type,"03") != 0) && (strcmp(icar_type,"21") != 0) &&
										(strcmp(icar_type,"22") != 0) && (strcmp(icar_type,"04") != 0) &&
										(strcmp(icar_type,"19") != 0))
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_develop, "15");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									if (prov_K > 0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_develop , "15");
										strcpy(iins_type_rule , "20");
										strcpy(frule,"N");
									}
									if (prov_bf_K > 0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_develop , "15");
										strcpy(iins_type_rule , "20");
										strcpy(frule,"N");
									}
									if(strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_develop,"15");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									if(fcontract_err == 1)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"97");
										strcpy(iins_type_develop,"15");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
								}
							}
							else if (strcmp(trim(iins_type),"31")== 0)
							{
								if(strcmp(iedr_type, "02") == 0 || count_ins2 > 0 || (mdamage_cover_deve ==0 && strcmp(iedr_type, "02") != 0 &&
								   strncmp(fedr_class,"2",1) != 0 && strncmp(fedr_class,"8",1) != 0 && atoi(iedr_type) < 80))
								{
									if( abs(mdeduct) > 0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"99");
										strcpy(iins_type_develop , "31");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									if( medrdmg_cover == 2 * medrinj_cover )
									{
										if (prov_T > 0 && fcar_class[0] == '2')
										{
											strcpy(iins_type_main,"Z");
											strcpy(iins_type_dtl,"99");
											strcpy(iins_type_develop , "31");
											strcpy(iins_type_rule , "20");
											strcpy(frule, "N");
										}
										/*if (prov_bf_T > 0 && fcar_class[0] == '2')
										{
											strcpy(iins_type_main,"Z");
											strcpy(iins_type_dtl,"99");
											strcpy(iins_type_develop , "31");
											strcpy(iins_type_rule , "20");
											strcpy(frule, "N");
										}*/
									}
									else
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"99");
										strcpy(iins_type_develop , "31");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
										
										if( fcar_class[0] == '1' )
										  strcpy(iproduct,"111120461211");
										else
										  strcpy(iproduct,"121130461211");
									}
								}	
								else
								{	
									if( abs(mdeduct_deve) > 0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"99");
										strcpy(iins_type_develop , "31");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									if( mdamage_cover_deve == 2 * minjured_cover_deve )
									{
										if (prov_T > 0 && fcar_class[0] == '2')
										{
											strcpy(iins_type_main,"Z");
											strcpy(iins_type_dtl,"99");
											strcpy(iins_type_develop , "31");
											strcpy(iins_type_rule , "20");
											strcpy(frule, "N");
										}
										/*if (prov_bf_T > 0 && fcar_class[0] == '2')
										{
											strcpy(iins_type_main,"Z");
											strcpy(iins_type_dtl,"99");
											strcpy(iins_type_develop , "31");
											strcpy(iins_type_rule , "20");
											strcpy(frule, "N");
										}*/
									}
									else
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"99");
										strcpy(iins_type_develop , "31");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
										
										if( fcar_class[0] == '1' )
										  strcpy(iproduct,"111120461211");
										else
										  strcpy(iproduct,"121130461211");
									}
								}
							}
							else if (strcmp(trim(iins_type),"32") == 0)
							{
								if(strcmp(iedr_type, "02") == 0 || count_ins2 > 0 || (mdamage_cover_deve ==0 && strcmp(iedr_type, "02") != 0 &&
								   strncmp(fedr_class,"2",1) != 0 && strncmp(fedr_class,"8",1) != 0 && atoi(iedr_type) < 80))
								{
									if( abs(mdeduct) > 0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"99");
										strcpy(iins_type_develop , "32");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									if( abs(medrdmg_cover) > 500000 )
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"99");
										strcpy(iins_type_develop , "32");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									if (prov_T > 0 && fcar_class[0] == '2')
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"99");
										strcpy(iins_type_develop , "32");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									/*if (prov_bf_T > 0 && fcar_class[0] == '2')
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"99");
										strcpy(iins_type_develop , "32");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}*/
								}
								else 
								{ 
									if( abs(mdeduct_deve) > 0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"99");
										strcpy(iins_type_develop , "32");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									if(mdamage_cover_deve > 500000 )
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"99");
										strcpy(iins_type_develop , "32");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									if (prov_T > 0 && fcar_class[0] == '2')
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"99");
										strcpy(iins_type_develop , "32");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}
									/*if (prov_bf_T > 0 && fcar_class[0] == '2')
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"99");
										strcpy(iins_type_develop , "32");
										strcpy(iins_type_rule , "20");
										strcpy(frule, "N");
									}*/
								}
							}
							else if ((f_1000401==0) && (strcmp(trim(iins_type),"55")==0))
							{
								if ((abs(mdeath_cover_deve) == 6000000) || (minjured_cover_deve == mdeath_cover_deve))
								{
									strcpy(iins_type_main,"Z");
									strcpy(iins_type_dtl,"91");
									strcpy(iins_type_develop, "62");
									strcpy(iins_type_rule , "20");
									strcpy(frule, "N");
								}
								else if (strcmp(trim(iins_type),"55") == 0 &&
								        (strcmp(icar_type,"03") != 0 && strcmp(icar_type,"04") != 0 &&
								         strcmp(icar_type,"05") != 0 && strcmp(icar_type,"06") != 0 &&
								         strcmp(icar_type,"11") != 0 && strcmp(icar_type,"12") != 0 &&
								         strcmp(icar_type,"18") != 0 && strcmp(icar_type,"19") != 0 &&
								         strcmp(icar_type,"20") != 0 && strcmp(icar_type,"21") != 0 &&
								         strcmp(icar_type,"22") != 0 && strcmp(icar_type,"31") != 0 ))
								{
									strcpy(iins_type_main,"Z");
									strcpy(iins_type_dtl,"91");
									strcpy(iins_type_develop, "62");
									strcpy(iins_type_rule , "20");
									strcpy(frule, "N");
								}
							}
							else if (strcmp(trim(iins_type),"55") == 0 &&
								    (strcmp(icar_type,"03") != 0 && strcmp(icar_type,"04") != 0 &&
								     strcmp(icar_type,"05") != 0 && strcmp(icar_type,"06") != 0 &&
								     strcmp(icar_type,"11") != 0 && strcmp(icar_type,"12") != 0 &&
								     strcmp(icar_type,"18") != 0 && strcmp(icar_type,"19") != 0 &&
								     strcmp(icar_type,"20") != 0 && strcmp(icar_type,"21") != 0 &&
								     strcmp(icar_type,"22") != 0 && strcmp(icar_type,"31") != 0 ))
							{
								strcpy(iins_type_main,"Z");
								strcpy(iins_type_dtl,"91");
								strcpy(iins_type_develop, "62");
								strcpy(iins_type_rule , "20");
								strcpy(frule, "N");
							}
							
							if (strcmp(iins_type,"131") == 0 || strcmp(iins_type,"132") == 0 || strcmp(iins_type,"24") == 0 ||
								strcmp(iins_type,"26") == 0  || strcmp(iins_type,"31") == 0  || strcmp(iins_type,"32") == 0 ||
								strcmp(iins_type,"41") == 0  || strcmp(iins_type,"42") == 0 )
							{
								chk_plia = 0;
								/*99�O�v��]�w���ʧO�~�֫Y�Ƥ~�P���|���ۦP�A�Y���e�X���涷�Φ��@�����*/
								if ((sFassured[0]=='1' || sFassured[0]=='3' || sFassured[0]=='5') && atoi(drate_ym) < 99)  /*** �۵M�H ***/
								{
									/* ���d */
									strcpy( sDbirth,     cm_cdate_str_100(dbirth));
									strcpy( sDply_begin, cm_cdate_str_100(dedr_begin));
									rc = get_age( sDbirth, sDply_begin, &age, v_sMsg);
									
									/*if (atoi(drate_ym) < 99) 
										rc = get_sex_age_factor( "2", &age, fsex, "99", &psex_age_chk, v_sMsg);
									else 
										rc = get_sex_age_factor( "2", &age, fsex, drate_ym, &psex_age_chk, v_sMsg);
										
									if (psex_age_lia != psex_age_chk) chk_plia = 1;*/

									rc = get_sex_age_factor( "2", &age, fsex, "99", &psex_age_chk, v_sMsg);
									if (psex_age_lia != psex_age_chk) chk_plia = 1;

								}
								else chk_plia = 0;
								
								printf("--drate_ym[%s],sDbirth[%s],sDply_begin[%s],age[%d],chk_plia[%d] \n",drate_ym,sDbirth,sDply_begin,age,chk_plia);
								
								if (chk_plia > 0)
								{
									/*���w��31/32 131/132���ݦ~�֫Y��*/
									if (strcmp(iins_type,"31") == 0 || strcmp(iins_type,"32") == 0)
									{
										strcpy(iins_type_main,"Z");
										strcpy(iins_type_dtl,"99");
										strcpy(iins_type_rule , "20"); 
										strcpy(frule, "N");
									}
								}
							}
			
							printf("--666666iins_main[%s],iins_type[%s],fins_grp[%s],iri_ins[%s]\n",iins_main,iins_type,fins_grp,iri_ins);
							if(strncmp(iins_type,"P",1) == 0 || strncmp(iins_type,"Q",1) == 0 ||
							   strncmp(iins_type,"M",1) == 0 || strncmp(iins_type,"Z",1) == 0 ||
							   strncmp(iins_type,"D",1) == 0 || strncmp(iins_type,"K",1) == 0 ||
							   strncmp(iins_type,"S",1) == 0) 
							{
								strcpy(iins_type_rule , "20"); 
								strcpy(frule, "N");
								if (strncmp(fins_grp,"1",1) == 0 && strcmp(trim(iri_ins),"11") != 0)
								{
									strcpy(iins_type_develop, "16");
								}
								else if (strcmp(trim(iri_ins),"11") == 0)
								{
									strcpy(iins_type_develop, "22");
								}
								else
								{
									strcpy(iins_type_develop, "62");
								}
							}
							else if(strncmp(iins_type,"F",1) == 0 || strncmp(iins_type,"G",1) == 0 ||
							        strncmp(iins_type,"H",1) == 0 || strncmp(iins_type,"J",1) == 0 ||
							        strncmp(iins_type,"L",1) == 0 || strncmp(iins_type,"R",1) == 0 ||
							        strncmp(iins_type,"V",1) == 0 || strncmp(iins_type,"T",1) == 0) 
							{
								strcpy(iins_type_rule , "20"); 
								strcpy(frule, "N");
								if (strncmp(fins_grp,"1",1) == 0 && strcmp(trim(iri_ins),"11") != 0)
								{
									strcpy(iins_type_develop, "16");
								}
								else if (strcmp(trim(iri_ins),"11") == 0)
								{
									strcpy(iins_type_develop, "22");
								}
								else
								{
									strcpy(iins_type_develop, "62");
								}
							}
						}
						
						if (f_1060101 > 0)
						{
							if (iins_type_rule[0] == '1') strcpy(frule,"Y");
							else if (iins_type_rule[0] == '2') strcpy(frule,"N");
						}
						prtstr[150] = '\0';
						printf("iins_type_main[%s] \n",iins_type_main);
						/* 151 �O�I�����j�� */
						if (strcmp(trim(iins_type_main),"")==0) 
						{
							strcat(prtstr," ");
							strcpy(t_iins_type_main," ");
						}
						else 
						{
							strcat(prtstr,trim(iins_type_main));
							strcpy(t_iins_type_main,trim(iins_type_main));
						}
						printf("iins_type_dtl[%s] \n",iins_type_dtl);
						prtstr[151] = '\0';
						/* 152-153 �O�I�����Ӷ� */
						if (strcmp(trim(iins_type_dtl),"")==0) 
						{
							strcat(prtstr,"  ");
							strcpy(t_iins_type_dtl," ");
						}
						else 
						{
							strcat(prtstr,trim(iins_type_dtl));
							strcpy(t_iins_type_dtl,trim(iins_type_dtl));
						}
						prtstr[153] = '\0';
						printf("prtstr[%s]\n",prtstr);
						
						printf("into while twice_20_77[%d] \n",twice_20_77);
						/* 154-155 ���ʽ�N�� */
						strcpy(t_iedr_type_ori,iedr_type);
						if(strncmp(fedr_class,"7",1) == 0)
						{
							strcat(prtstr,"PR");
							strcpy(t_iedr_type,"PR");
						}
						else if(count_ins2 > 0)
						{
							strcat(prtstr, "99");
							strcpy(t_iedr_type,"99");
						}
						else
						{
							if (strlen(trim(iedr_type)) == 0)
							{
								strcat(prtstr,"00");
								strcpy(t_iedr_type,"00");
							}
							else if (strcmp(iedr_type,"20") == 0 && twice_20_77 == 1)
							{
								strcat(prtstr, "11");
								strcpy(t_iedr_type,"11");
							}
							else if (strcmp(iedr_type,"77") == 0 && twice_20_77 == 1)
							{
								strcat(prtstr, "11");
								strcpy(t_iedr_type,"11");
							}
							else if (strcmp(iedr_type,"20") == 0 && twice_20_77 == 2)
							{
								if(strcmp(iins_type,"29")==0 || strcmp(iins_type,"30")==0 ||strcmp(iins_type,"301")==0 ||strcmp(iins_type,"302")==0||strcmp(iins_type,"530")==0)
								{
									strcat(prtstr, "99");
									strcpy(t_iedr_type,"99");
								}
								else
								{
									strcat(prtstr, "12");
									strcpy(t_iedr_type,"12");
								}
							}
							else if (strcmp(iedr_type,"77") == 0 && twice_20_77 == 2)
							{
								if(strcmp(iins_type,"29")==0 || strcmp(iins_type,"30")==0 ||strcmp(iins_type,"301")==0 ||strcmp(iins_type,"302")==0||strcmp(iins_type,"530")==0)
								{
									strcat(prtstr, "99");
									strcpy(t_iedr_type,"99");
								}
								else
								{
									strcat(prtstr, "12");
									strcpy(t_iedr_type,"12");
								}
							}
							else
							{
								iedr_type_l = atoi(iedr_type);
								switch(iedr_type_l)
								{
									case 40: case 78 : case 79 : case 75 : case 7: case 10: case 30:
										strcpy(iedr_type_c, "99");
										break;
									case 80: case 81 : case 82 : case 83: case 84: case 85: 
										strcpy(iedr_type_c, "99");
										break;
									case  4: case 76 :
										if (medrdmg_cover == 0)
											strcpy(iedr_type_c,"99");
										else
											strcpy(iedr_type_c,"04");
										break;
									case 50:
										strcpy(iedr_type_c,"05");
										break;
									case 60:
										strcpy(iedr_type_c,"02");
										break;
									default:
										strcpy(iedr_type_c ,trim(iedr_type));
								}
								strcat(prtstr, iedr_type_c);
								strcpy(t_iedr_type,iedr_type_c);
							}
						}
						
						/* 156-157 �I�O�N�� */
						if (strcmp(trim(iins_type_develop),"")==0) 
						{
							strcat(prtstr,"  ");
							strcpy(t_iins_type_dev," ");
						}
						else 
						{
							strcat(prtstr,trim(iins_type_develop));
							strcpy(t_iins_type_dev,trim(iins_type_develop));
						}
						/* 158-159 �I�O���� */
						if (f_1060101 > 0)
						{
							if (strcmp(trim(iins_type_rule),"")==0) 
							{
								strcat(prtstr,"20");
								strcpy(t_iins_type_rule,"20");
							}
							else 
							{
								strcat(prtstr,trim(iins_type_rule));
								strcpy(t_iins_type_rule,trim(iins_type_rule));
							}
						}
						else 
						{
							strcat(prtstr,"  ");
							strcpy(t_iins_type_rule," ");
						}
						/* 160 �O�_���W���O�v */
						if (strcmp(trim(iins_type_rule),"")==0) 
						{
							strcat(prtstr,"N");
							strcpy(t_frule,"N");
						}
						else 
						{
							strcat(prtstr,frule);
							strcpy(t_frule,frule);
						}

						/* 161-164  �����[��T�� */
						carfleet_rate = 0;
						/*if (strcmp(iins_type,"T") == 0)
						{
							carfleet_rate = car_t_rate;
						}
						else if (strcmp(iins_type,"F") == 0)
						{
							carfleet_rate = adjust_rate;
						}*/
						/* 113.08.23�D�I���[�I���n�e */
						if (car_t_rate != 0)
						{
							carfleet_rate = car_t_rate;
						}
						else if (adjust_rate != 0)
						{
							carfleet_rate = adjust_rate;
						}
						else 
						{
							carfleet_rate = 0;	
						}

						t_padjust_rate = carfleet_rate*100;
						if(carfleet_rate < 0)
						{
							strcat(prtstr,"-");
							rfmtdouble((carfleet_rate*100),"&&&", carfleet_rate_tmp);
							strcat(prtstr,carfleet_rate_tmp);
						}
						else
						{
							strcat(prtstr,"+");
							if( carfleet_rate > 0 )
							{
								rfmtdouble((carfleet_rate*100),"&&&", carfleet_rate_tmp);
								strcat(prtstr,carfleet_rate_tmp);
							}
							else
								strcat(prtstr,"000");
						}
						
						cnt_acc = 0;
						/*���ϥΨ�Y�ƭp��A���O������D�I���N�n��*/
						if (strcmp(trim(iins_type), "38")==0 || strcmp(trim(iins_type), "39")==0 ||
					        strcmp(trim(iins_type), "86")==0 || strcmp(trim(iins_type), "98")==0 ||
					        strcmp(trim(iins_type), "238")==0) 
						{
							sprintf(stmp,"SELECT count(*) \
							                FROM %s:edr_ins_type a,insurance_type b \
							               WHERE a.iins_type = b.iins_type \
							                 AND a.iendorse = '%s' \
							                 AND a.iins_type NOT IN ('38','39','86','98','238') \
							                 AND b.fins_grp = '1' \
							                 AND b.iri_ins <> '11'; ",list[k].dbname,iendorse);
							$PREPARE edr_38 FROM $stmp;
							$EXECUTE edr_38 INTO $cnt_acc;
						
						}
						else 
						{
							cnt_acc = 0;
						}
						
						/* 165-168 �[�˳]�ƫ᭫�m����T�� */
						printf("[mcar_price]  ibrand[%s],ipro_year[%s],drate_ym[%s] \n",ibrand,ipro_year,drate_ym);
						if (strncmp(chk_157,"Y",1) == 0)   /*�s���I��*/
						{
							strcat(prtstr,"+000");
							t_p_mcar_price = 0;
						}
						else if((strcmp(iins_type,"38") == 0 || strcmp(iins_type,"39") == 0 || strcmp(iins_type,"238") == 0) && cnt_acc == 0)
						{
							strcat(prtstr,"+000");
							t_p_mcar_price = 0;
						}
						else 
						{
							mcar_price_ori = 0.0;qpassenger = 0.0;
	
							if (strncmp(fins_grp,"1",1) == 0)
							{
								icar_series[0] = '\0';
								printf("ibrand[%s] ipro_year[%s] drate_ym[%s] mcar_price_ori[%f] qpassenger[%f] icar_series[%s]\n",ibrand,ipro_year,drate_ym,mcar_price_ori,qpassenger,icar_series);
								rc = get_ca_car_model(ibrand,ipro_year,drate_ym,&mcar_price_ori,&qpassenger,&icar_series);
								printf("mcar_price_ori[%f] qpassenger[%f] icar_series[%s]\n",mcar_price_ori,qpassenger,icar_series);
								if (mcar_price_ori == 0)
								{
									mcar_price_ori = mcar_price;
									strcat(prtstr,"+000");
									t_p_mcar_price = 0;
								}
								else 
								{
									p_mcar_price = (mcar_price - mcar_price_ori) / mcar_price_ori;
									if((p_mcar_price*100) > 999)
									{
										strcat(prtstr,"+999");
										t_p_mcar_price = 999;
									}
									else if ((p_mcar_price*100) < -999)
									{
										strcat(prtstr,"-999");
										t_p_mcar_price = -999;
									}
									else
									{
										rfmtdouble((p_mcar_price*100),"&&&", mcar_price_tmp);
										if (p_mcar_price < 0) strcat(prtstr,"-");
										else strcat(prtstr,"+");
										strcat(prtstr,mcar_price_tmp);
										t_p_mcar_price = p_mcar_price*100;
									}
								}
							}
							else 
							{
								strcat(prtstr,"+000");
								t_p_mcar_price = 0;
							}
						}
						
						/* 169-172 �Q�O�I�H�ߴګY�� ***/
						/*if ( cnt_iins_main == 1 ||
						    (strncmp(iins_type,"P",1) == 0 || strncmp(iins_type,"Q",1) == 0 ||
							 strncmp(iins_type,"M",1) == 0 || strncmp(iins_type,"Z",1) == 0))
						{*/
							if (strncmp(fins_grp,"1",1) == 0 && strcmp(iri_ins, "11") != 0)
							{
								if (strcmp(trim(iins_type), "38")==0 || strcmp(trim(iins_type), "39")==0 ||
							        strcmp(trim(iins_type), "86")==0 || strcmp(trim(iins_type), "98")==0 ||
							        strcmp(trim(iins_type), "238")==0)  /*���ϥΨ�Y�ƭp��A���O������D�I���N�n��*/
								{					
									if (cnt_acc > 0)
									{
										if( pdmg_acc < 0 )
										{
											strcat(prtstr,"-");
											rfmtdouble((pdmg_acc*100),"&&&", acc_tmp);
											strcat(prtstr,acc_tmp);
										}
										else
										{
											strcat(prtstr,"+");
											if( pdmg_acc > 0 )
											{
												rfmtdouble((pdmg_acc*100),"&&&", acc_tmp);
												strcat(prtstr,acc_tmp);
											}
											else strcat(prtstr,"000");
										}
										t_pins_acc = pdmg_acc;	
									}
									else 
									{
										pdmg_acc = 0;
										strcat(prtstr,"+000");
										t_pins_acc = 0;
									}
								}
								else 
								{
									if( pdmg_acc < 0 )
									{
										strcat(prtstr,"-");
										rfmtdouble((pdmg_acc*100),"&&&", acc_tmp);
										strcat(prtstr,acc_tmp);
									}
									else
									{
										strcat(prtstr,"+");
										if( pdmg_acc > 0 )
										{
											rfmtdouble((pdmg_acc*100),"&&&", acc_tmp);
											strcat(prtstr,acc_tmp);
										}
										else strcat(prtstr,"000");
									}
									t_pins_acc = pdmg_acc;
								}
							}
							else if (strncmp(fins_grp,"2",1) == 0)
							{
							 	if( strcmp(trim(iins_type), "31")==0  || strcmp(trim(iins_type), "32")==0 ||
							 	    strcmp(trim(iins_type), "231")==0 || strcmp(trim(iins_type), "232")==0)
								{
									if( plia_acc < 0 )
									{
										if (strcmp(trim(iins_type_develop), "31")==0 || strcmp(trim(iins_type_develop), "32")==0)
										{
											$SELECT ncode
											   INTO $Maxmin
											   FROM cu_code_data
											  WHERE itype='T5'
											    AND icode='2';
											Maxminvalue=atof(Maxmin);
											if (plia_acc <  Maxminvalue)
											{
												plia_acc=Maxminvalue;
											}
										}
										strcat(prtstr,"-");
										rfmtdouble((plia_acc*100),"&&&", acc_tmp);
										strcat(prtstr,acc_tmp);
									}
									else
									{
										strcat(prtstr,"+");
										if( plia_acc > 0 )
										{
											if (strcmp(trim(iins_type_develop), "31")==0 || strcmp(trim(iins_type_develop), "32")==0)
											{
												$SELECT ncode
												   INTO $Maxmin
												   FROM cu_code_data
												  WHERE itype='T5'
												    AND icode='1';
												Maxminvalue=atof(Maxmin);
												if (plia_acc >  Maxminvalue)
												{
													plia_acc=Maxminvalue;
												}
											}
											rfmtdouble((plia_acc*100),"&&&", acc_tmp);
											strcat(prtstr,acc_tmp);
										}
										else strcat(prtstr,"000");
									}
									t_pins_acc = plia_acc;
								}
								else
								{
									if( plia_acc < 0 )
									{
										strcat(prtstr,"-");
										rfmtdouble((plia_acc*100),"&&&", acc_tmp);
										strcat(prtstr,acc_tmp);
									}
									else
									{
										strcat(prtstr,"+");
										if( plia_acc > 0 )
										{
											rfmtdouble((plia_acc*100),"&&&", acc_tmp);
											strcat(prtstr,acc_tmp);
										}
										else strcat(prtstr,"000");
									}
									t_pins_acc = plia_acc;
								}
							}
							else 
							{
								strcat(prtstr, "+999");
								t_pins_acc = 9.99;
							}
						/*}
						else 
						{
							strcat(prtstr, "+999");
							t_pins_acc = 9.99;
						}*/
	
						/* 173-176 �����I�ߴڬ����I�� */
						/*�{����Ƭ�������ߴڬ����Y�ƤΤT�~���ߴڦ��ơA����ഫ�I�Ƭۮt�Y���L�ߴڦ~���I�ơC
						  �i�ߴڬ����I�� = �L�ߴڦ~���I�� + �ߴڦ����I�ơj
						  |�ߴڬ����I��|�ߴڬ����Y��|
						  |     -3     |    -0.6    |
						  |     -2     |    -0.4    |
						  |     -1     |    -0.2    |
						  |      0     |      0     |
						  |      1     |     0.2    |
						  |      2     |     0.4    |
						  |      3     |     0.6    |
						  3�I�H�W�C�W�[�@�I�A�ߴڬ����Y�ƧY�W�[0.2
						  
						  |�ߴڦ~��|�I��|�T�~���ߴڦ���|�I��|
						  |   3�~  | -3 |     1��      |  0 |
						  |   2�~  | -2 |     2��      |  1 |
						  |   1�~  | -1 |     3��      |  2 |
						  |   0�~  |  0 |     4��      |  3 |
						  4���H�W�A�C�W�[�@���ߡA�I�ƧY�W�[�@�I	*/
						/*�ߴڬ����I��*/
						printf("--�ߴڬ����I��\n");
						/*�D�I���[�I�P�@�s�ժ������Y�ƭn�ۦP*/
						qdmg_acc = 0;qdmg_acc_time = 0;qdmg_acc_year = 0;
						qdmg_acc_year_c[0] = '\0';
						qdmg_acc_time_c[0] = '\0';
						/*if ( cnt_iins_main == 1 ||
						    (strncmp(iins_type,"P",1) == 0 || strncmp(iins_type,"Q",1) == 0 ||
							 strncmp(iins_type,"M",1) == 0 || strncmp(iins_type,"Z",1) == 0))
						{*/
							if (strncmp(fins_grp,"1",1) == 0 && strcmp(iri_ins,"11") != 0)
							{
								if ((strcmp(trim(iins_type), "38")==0 || strcmp(trim(iins_type), "39")==0 ||
							         strcmp(trim(iins_type), "86")==0 || strcmp(trim(iins_type), "98")==0 ||
							         strcmp(trim(iins_type), "238")==0) && cnt_acc == 0) 
								{
									strcat(prtstr,"+0");
									strcat(prtstr,"+0");
									t_qdmg_acc_year = 0;
									t_qdmg_acc_time = 0;
								}
								else
								{
									/*qdmg_acc-�ߴڬ����I��*/
									if(pdmg_acc == 0) qdmg_acc = 0;
									else  qdmg_acc = (pdmg_acc/0.2);
									/*�L�h�T�~�ߴ��`����*/
									/*qdmg_acc_sum-�T�~���ߴ��`����*/
									/*qdmg_acc_tims-�ߴڦ����I��*/
									if (qdmg_acc_sum == 0) qdmg_acc_time = 0;
									else qdmg_acc_time = qdmg_acc_sum - 1;
									printf("qdmg_acc_time[%f] \n",qdmg_acc_time);
									/* 173-174 �L�ߴڦ~���I�� = �ߴڬ����I�� - �ߴڦ����I��*/
									qdmg_acc_year = qdmg_acc - qdmg_acc_time;
									if (qdmg_acc_year < 0) 
									{
										strcat(prtstr,"-");
										rfmtdouble(qdmg_acc_year,"&", qdmg_acc_year_c);
										strcat(prtstr,qdmg_acc_year_c);
										t_qdmg_acc_year = qdmg_acc_year;
									}
									else 
									{
										strcat(prtstr,"+");
										rfmtdouble(qdmg_acc_year,"&", qdmg_acc_year_c);
										strcat(prtstr,qdmg_acc_year_c);
										t_qdmg_acc_year = qdmg_acc_year;
									}
	
									/* 175-176 �ߴڦ����I��*/
									if (qdmg_acc_year < 0) 
									{
										if (qdmg_acc_time == 0) strcat(prtstr,"-");
										else strcat(prtstr,"+");
										rfmtdouble(qdmg_acc_time,"&", qdmg_acc_time_c);
										strcat(prtstr,qdmg_acc_time_c);
										t_qdmg_acc_time = qdmg_acc_time;
									}
									else 
									{
										strcat(prtstr,"+");
										rfmtdouble(qdmg_acc_time,"&", qdmg_acc_time_c);
										strcat(prtstr,qdmg_acc_time_c);
										t_qdmg_acc_time = qdmg_acc_time;
									}
								}
							}
							else 
							{
								strcat(prtstr,"+0");
								strcat(prtstr,"+0");
								t_qdmg_acc_year = 0;
								t_qdmg_acc_time = 0;
							}
						/*}
						else 
						{
							strcat(prtstr,"+0");
							strcat(prtstr,"+0");
							t_qdmg_acc_year = 0;
							t_qdmg_acc_time = 0;
						}*/
						
						/* 177-180 �Q�O�I�H�~�֩ʧO�Y�� */
						printf("--�Q�O�I�H�~�֩ʧO�Y��\n");
						printf("psex_age_dmg[%f],psex_age_lia[%f]",psex_age_dmg,psex_age_lia);
						sex_age_tmp[0] = '\0';
						if (strcmp(iri_ins, "11") == 0)  /*�ѵs���e�A���l�I�b�e*/
						{
							strcat(prtstr,"+000");
							t_psex_age = 0;
						}
						else
						{
							if (strcmp(sFassured, "1") == 0 || strcmp(sFassured, "3") == 0 || strcmp(sFassured, "5") == 0)
							{
								if ( strncmp(fins_grp,"1",1) == 0)
								{
									if(psex_age_dmg == 0)
									{
										psex_age_tmp = 0;
									
										sprintf(stmp,"SELECT first 1 psex_age  \
										                FROM %s:edr_ins_type \
										               WHERE iendorse = '%s'  \
										                 AND iins_type IN (SELECT iins_type FROM insurance_type WHERE fins_grp = '1' AND iri_ins <> '11') \
										                 AND psex_age <> 0 ;",list[k].dbname,iendorse);
										$PREPARE edr_sex_age FROM $stmp;
										$EXECUTE edr_sex_age INTO $psex_age_tmp;
										
										if(psex_age_tmp == 0)
										{
											/*Do nothing*/
										}
										else 
										{
											psex_age_dmg = psex_age_tmp;
										}
									}
									
									if( psex_age_dmg < 0 )
									{
										strcat(prtstr,"-");
										rfmtdouble((psex_age_dmg*100),"&&&", sex_age_tmp);
										strcat(prtstr,sex_age_tmp);
									}
									else
									{
										strcat(prtstr,"+");
										if( psex_age_dmg > 0 )
										{
											rfmtdouble((psex_age_dmg*100),"&&&", sex_age_tmp);
											strcat(prtstr,sex_age_tmp);
										}
										else strcat(prtstr,"000");
									}
									t_psex_age = psex_age_dmg;
								}
								else if( strncmp(fins_grp,"2",1) == 0 ) /* 531�B532  149 �B249 ?*/
								{
									if (strcmp(iins_type,"131") == 0 || strcmp(iins_type,"132") == 0 || strcmp(iins_type,"24") == 0 ||
									    strcmp(iins_type,"26") == 0  || strcmp(iins_type,"31") == 0  || strcmp(iins_type,"32") == 0 ||
									    strcmp(iins_type,"41") == 0  || strcmp(iins_type,"42") == 0  ||
									    strcmp(iins_type,"231") == 0 || strcmp(iins_type,"232") == 0 ||
									    strcmp(iins_type,"331") == 0 || strcmp(iins_type,"332") == 0 )
									{
										if( psex_age_lia < 0 )
										{
											strcat(prtstr,"-");
											rfmtdouble((psex_age_lia*100),"&&&", sex_age_tmp);
											strcat(prtstr,sex_age_tmp);
										}
										else
										{
											strcat(prtstr,"+");
											if( psex_age_lia > 0 )
											{
												rfmtdouble((psex_age_lia*100),"&&&", sex_age_tmp);
												strcat(prtstr,sex_age_tmp);
											}
											else strcat(prtstr,"000");
										}
										t_psex_age = psex_age_lia;
									}
									else 
									{
										strcat(prtstr,"+000");
										t_psex_age = 0;
									}
								}
								else 
								{
									strcat(prtstr,"+000");
									t_psex_age = 0;
								}
							}
							else 
							{
								strcat(prtstr,"+000");
								t_psex_age = 0;
							}
						}
						
						chk_bak = 1;/*�w�]1(��O�榳�ӫO)*/
						/*�v��p����e�O�O�B�«O�O�B�O�B����*/
						sprintf(stmp,"SELECT icar_type,qpt,drate_ym,qply_period,dply_begin,dissue,ipro_year,qday,mdeduct, \
		   				                     minjured_cover,mdamage_cover,mdeath_cover,mcar_price,ibrand, \
		   				                     mins_premium,mpure_prem,mins_premium_n,mpure_prem_n, \
		   				                     fcal_way,icar_type,dply_end, \
		   				                     qprovision,adjust_rate,pcar_price, \
		   				                     qpro_month,fpt,nvl(provision,' '),(safe_rate+manage_rate)/100,mequipment \
					        	       FROM %s:ply_relation_bak a,%s:policy_bak b,%s:ply_ins_type_bak c  \
					        	      WHERE a.ipolicy = b.ipolicy \
						                AND a.ipolicy = c.ipolicy \
						                AND a.iendorse = b.iendorse \
						                AND a.iendorse = c.iendorse \
						                AND a.iendorse = '%s' \
						                AND c.iins_type = '%s'",list[k].dbname,list[k].dbname,list[k].dbname,iendorse,iins_main);
			        	$PREPARE ply_bak_bef FROM $stmp;
						$EXECUTE ply_bak_bef INTO $icar_type_bak,$qpt_bak,$drate_ym_bak,$qply_period_bak,$dply_begin_bak,$dissue_bak,$ipro_year_bak,$qday_bak,$mdeduct_bak,
		   				                          $min_cover_bak,$mdmg_cover_bak,$mdeath_cover_bak,$mcar_price_bak,$ibrand_bak,
		   				                          $mins_premium_bak,$mpure_prem_bak,$mins_premium_n_bak,$mpure_prem_n_bak,
		   				                          $fins_cal_way_bak,$icar_type_ori_bak,$dply_end_bak,
		   				                          $qprovision_bak,$adjust_rate_bak,$pcar_price_bak,
		   				                          $qpro_month_bak,$fpt_bak,$provision_bak,$car_t_rate_bak,$mequipment_bak;
						printf("ibrand_bak[%s]",ibrand_bak);
						strcpy(icar_type_bak,TRANS_CAR_TYPE(icar_type_bak));
						
						if(SQLCODE == SQLNOTFOUND)
						{
							chk_bak = 0;
							mcar_price_bak = mcar_price;
							strcpy(ibrand_bak,ibrand);
							min_cover_bak = mdmg_cover_bak = mdeath_cover_bak = 0;
							mdeduct_bak = 0;
							mpure_prem_bak = 0;
							mins_premium_bak = 0;
							mins_premium_n_bak = 0;
							mpure_prem_n_bak = 0;
							carfleet_rate_bak = 0;
						}
						
						/* �����Y�� */
						carfleet_rate_bak = 0;
						/*if (strcmp(iins_type,"T") == 0)
						{
							carfleet_rate_bak = car_t_rate_bak;
						}
						else if(strcmp(iins_type,"F") == 0)
						{
							carfleet_rate_bak = adjust_rate_bak;
						}*/
						/* 113.08.23�D�I���[�I���n�e */
						if (car_t_rate_bak != 0)
						{
							carfleet_rate_bak = car_t_rate_bak;
						}
						else if (adjust_rate_bak != 0)
						{
							carfleet_rate_bak = adjust_rate_bak;
						}
						else 
						{
							carfleet_rate_bak = 0;	
						}
						
						if (count_ins2 > 0)
						{
							/*�¤��*/
							chk_bak = 0;
							mcar_price_bak = mcar_price;
							strcpy(ibrand_bak,ibrand);
							min_cover_bak = mdmg_cover_bak = mdeath_cover_bak = 0;
							mdeduct_bak = 0;
							mpure_prem_bak = 0;
							mins_premium_bak = 0;
							mins_premium_n_bak = 0;
							mpure_prem_n_bak = 0;
						}
						else
						{
							
						}
						/* 181-184 ���²v�ʤ��� */
						/*���e��*/
						printf("--iins_type[%s] iins_main[%s]\n",iins_type,iins_main);
						printf("--���²v�ʤ���\n");				
						strcat(prtstr,pdepreciate_year_tmp2);
						
						/* 185-192 UBI�ӫ~�O�v�]�l*/
						printf("--ubi\n");
						/*�ߤ@�@�iUBI 00007V9025252 - ���iUBI�L���*/
						/*177  �O�v�p��O�_�Ҷq���{��*/
						strcat(prtstr,"0");
						/*177  �O�v�p��O�_�Ҷq�r�p�ɬq*/
						strcat(prtstr,"0");
						/*177  �O�v�p��O�_�Ҷq�r�p���q*/
						strcat(prtstr,"0");
						/*177  �O�v�p��O�_�Ҷq��L�r�p�欰*/
						strcat(prtstr,"0");
						/*181-184  �����r�p�H�ϥβߺD���覡(�����˸m�Bapp�B���׫O�i�����B��L)*/
						strcat(prtstr,"0000");
						strcpy(t_ubi_data,"00000000");
						
						min_tot=0,mdea_tot=0,mdmg_tot=0;
						min_tot = medrinj_cover + min_cover_bak;
						mdea_tot = medrdea_cover + mdeath_cover_bak;
						mdmg_tot = medrdmg_cover + mdmg_cover_bak;
						
						if(chk_bak > 0)
						{
							printf("qpro_month_bak[%d],ipro_year_bak[%s] \n",qpro_month_bak,ipro_year_bak);
							/*��e*/
							sprintf(dpro_bak,"%s/01/%s",itoa(qpro_month_bak),ipro_year_bak);
							strcpy(dpro_bak,trim(dpro_bak));
							strcpy(dissue_bak_100,cm_from_infdate_100(dissue_bak));
							strcpy(dpro_bak_100,cm_from_infdate_100(dpro_bak));
							printf("dissue_100[%s] dpro_100[%s]\n",dissue_bak_100,dpro_bak_100);
							ldissue_bak = cm_ymd_cdate(dissue_bak_100);
							ldpro_bak = cm_ymd_cdate(dpro_bak_100);
							printf("ldissue[%d] ldpro[%d]\n",ldissue,ldpro);
							mcar_price_ori_bak = 0;
							qpassenger_bak = 0;
							icar_series_bak[0] = '\0';
							rc = get_ca_car_model(ibrand_bak,ipro_year_bak,drate_ym_bak,&mcar_price_ori_bak,&qpassenger_bak,&icar_series_bak);
							if( rc != M_CM_OK) 
							{
								mcar_price_ori_bak = 0.0;
								qpassenger_bak = 0.0;
								icar_series_bak[0] = '\0';
							}
						}
	
						/*���*/
						printf("qpro_month[%d] ipro_year[%s]\n",qpro_month,ipro_year);
						sprintf(dpro,"%s/01/%s",itoa(qpro_month),ipro_year);
						strcpy(dpro,trim(dpro));
						strcpy(dissue_100,cm_from_infdate_100(dissue));
						strcpy(dpro_100,cm_from_infdate_100(dpro));
						printf("dissue_100[%s] dpro_100[%s]\n",dissue_100,dpro_100);
						ldissue = cm_ymd_cdate(dissue_100);
						ldpro = cm_ymd_cdate(dpro_100);
						printf("ldissue[%d] ldpro[%d]\n",ldissue,ldpro);
	
						printf("chk_cover_per1[%d],chk_cover_per[%d] \n ",chk_cover_per1,chk_cover_per);
						
						if (((strcmp(iedr_type, "20") == 0) || (strcmp(iedr_type, "77") == 0)) && twice_20_77 == 1)
						{
							/*do nothing*/
						}
						else if (((strcmp(iedr_type, "20") == 0) || (strcmp(iedr_type, "77") == 0)) && twice_20_77 == 2)
						{
							/*do nothing*/
						}
						else if (count_ins2 > 0)
						{
							/*do nothing*/
						}
						else
						{
							if (cnt_iins_main == 1)
							{
								/*���e�O�B����*/
								if ((chk_cover_per1 > 0 || chk_cover_Z1 > 0) && mdmg_cover_bak != 0)
								{
									/*�겣*/
									if (strcmp(trim(icar_series_bak),"10") ==0)
									{
										if(DiffMonth(ldissue_bak,ldpro_bak)>3)
											strcpy(dissue_pro_tmp_bak,dpro_bak);
										else 
											strcpy(dissue_pro_tmp_bak,dissue_bak);
									}
									else /*�i�f*/ 
									{
										if(DiffMonth(ldissue_bak,ldpro_bak)>6)
											strcpy(dissue_pro_tmp_bak,dpro_bak);
										else 
											strcpy(dissue_pro_tmp_bak,dissue_bak);
									}
	
									printf("fins_cal_way_bak[%s],iins_type[%s],fProvision_c[%s],dissue_pro_tmp_bak[%s],drate_ym_bak[%s],icar_type_ori_bak[%s],mcar_price_bak[%f],qply_period[%d],dply_begin_bak[%ld],dply_end_bak[%ld] \n",
									        fins_cal_way_bak,iins_type,fProvision_c1,dissue_pro_tmp_bak,drate_ym_bak,icar_type_ori_bak,mcar_price_bak,qply_period_bak,dply_begin_bak,dply_end_bak);
			
									/*PQMZ�~�n�p����«O�B*/
									rc = get_dmg_cover(iins_type,fProvision_c1,dissue_pro_tmp_bak,drate_ym_bak,icar_type_ori_bak,mcar_price_bak,dply_begin_bak,&mcover_prov_bak);
									if( rc != M_CM_OK) 
									{
										mcover_prov_bak = 0;
										rc = insert_ca_log("car9996","X",iendorse,cm_edate_str(dendorse),"���[���±��ګ�O�B-bak",userid,v_sMsg);
									}
									rc = get_dmg_cover(iins_type," ",dissue_pro_tmp_bak,drate_ym_bak,icar_type_ori_bak,mcar_price_bak,dply_begin_bak,&mcover_ori_bak);
									if( rc != M_CM_OK) 
									{
										mcover_ori_bak = 0;
										rc = insert_ca_log("car9996","X",iendorse,cm_edate_str(dendorse),"����«O�B���~-aft",userid,v_sMsg);
									}
									printf("iins_main[%s] iins_type[%s] mcover_prov_bak[%d] mcover_ori_bak[%d] \n",iins_main,iins_type,mcover_prov_bak,mcover_ori_bak);
									if(mcover_ori_bak == 0 && mcover_prov_bak == 0) 
									{
										mcover_ori_bak = 1000;
									}
									else if(mcover_ori_bak == 0 && mcover_prov_bak > 0) 
									{
										mcover_ori_bak = 1000;
									}
								}
								else 
									mcover_prov_bak = mcover_ori_bak = 0;
		
								/*����O�B����*/
								if ((chk_cover_per > 0 || chk_cover_Z > 0))
								{
									if (strcmp(trim(icar_series),"10") ==0)
									{
										if(DiffMonth(ldissue,ldpro)>3)
											strcpy(dissue_pro_tmp,dpro);
										else 
											strcpy(dissue_pro_tmp,dissue);
									}
									else
									{
										if(DiffMonth(ldissue,ldpro)>6)
											strcpy(dissue_pro_tmp,dpro);
										else 
											strcpy(dissue_pro_tmp,dissue);
									}
	
									printf("fins_cal_way[%s],iins_type[%s],fProvision_c[%s],dissue_pro_tmp[%s],drate_ym[%s],icar_type_ori[%s],mcar_price[%f],qply_period[%d],dply_begin[%ld],dply_end[%ld],mcover_ori[%d] \n",
									        fins_cal_way,iins_type,fProvision_c,dissue_pro_tmp,drate_ym,icar_type_ori,mcar_price,qply_period,dply_begin,dply_end,mcover_ori);
									/*���[���±��ګ�O�B*/
									rc = get_dmg_cover(iins_type,fProvision_c,dissue_pro_tmp,drate_ym,icar_type_ori,mcar_price,dply_begin,&mcover_prov);
									if( rc != M_CM_OK) 
									{
										mcover_prov = 0;
										rc = insert_ca_log("car9996","X",iendorse,cm_edate_str(dendorse),"���[���±��ګ�O�B-bak",userid,v_sMsg);
									}
									rc = get_dmg_cover(iins_type," ",dissue_pro_tmp,drate_ym,icar_type_ori,mcar_price,dply_begin,&mcover_ori);
									if( rc != M_CM_OK) 
									{
										mcover_ori = 0;
										rc = insert_ca_log("car9996","X",iendorse,cm_edate_str(dendorse),"����«O�B���~-aft",userid,v_sMsg);
									}
									printf("iins_main[%s] iins_type[%s] mcover_prov[%d] mcover_ori[%d] \n",iins_main,iins_type,mcover_prov,mcover_ori);
									if(mcover_ori == 0 && mcover_prov == 0) 
									{
										mcover_ori = 1000;
									}
									else if(mcover_ori == 0 && mcover_prov > 0) 
									{
										mcover_ori = 1000;
									}
								}
								else
									mcover_prov = mcover_ori = 0;
	
								/*�����`�O�B*/
								mdamage_cover_aft = medrdmg_cover + mdmg_cover_bak;
								mcover_ori_aft = mcover_ori;
								if(mdamage_cover_aft == 0)
								{
									mcover_prov = mcover_ori = 0;
									mcover_ori_aft = 0;
								}
							}
						}
						
						/* 193-202 �C�H��� */
						if (cnt_iins_main == 1)
						{
							if (count_ins2 > 0)
							{
								strcat(prtstr,"+000000000");
								t_minjured_cover = 0;
							}
							else if (((strcmp(iedr_type, "20") == 0) || (strcmp(iedr_type, "77") == 0)) && twice_20_77 == 1)
							{
								if (strncmp(fins_grp,"1",1) == 0)
								{
									strcat(prtstr,"-000000000");
									t_minjured_cover = 0;
								}
								else 
								{
									strcat(prtstr,"-");
									rfmtlong(min_cover_bak,"&&&&&&&&&", sTmpBuf8);
									strcat(prtstr, sTmpBuf8);
									t_minjured_cover = 0 - min_cover_bak;
								}
							}
							else if (((strcmp(iedr_type, "20") == 0) || (strcmp(iedr_type, "77") == 0)) && twice_20_77 == 2)
							{
								if (strncmp(fins_grp,"1",1) == 0)
								{
									strcat(prtstr,"+000000000");
									t_minjured_cover = 0;
								}
								else 
								{
									strcat(prtstr,"+");
									rfmtlong(min_cover_bak,"&&&&&&&&&", sTmpBuf8);
									strcat(prtstr, sTmpBuf8);
									t_minjured_cover = min_cover_bak;
								}
							}
							else if (strncmp(fins_grp,"1",1) == 0) /*�����I������˫O�B ��38�B39*/
							{
								strcat(prtstr,"+000000000");
								t_minjured_cover = 0;
							}
							else if (strcmp(trim(iins_type), "34") == 0)
							{
								if(medrdea_cover < 0 ) strcat(prtstr,"-");
								else strcat(prtstr,"+");
								
								rfmtlong(medrdea_cover,"&&&&&&&&&",sTmpBuf8);
								strcat(prtstr,sTmpBuf8); 
								t_minjured_cover = medrdea_cover;
							}
							else
							{
								 if (medrinj_cover > 0)
								     strcpy(fcover,"+");
								 else if (medrinj_cover == 0)
								     strcpy(fcover, "+");
								 else
								     strcpy(fcover, "-");
								strcat(prtstr, fcover);
								rfmtlong(medrinj_cover, "&&&&&&&&&", sTmpBuf8);
								strcat(prtstr, sTmpBuf8);
								t_minjured_cover = medrinj_cover;
							}
						}
						else 
						{
							if (medrinj_cover > 0)
									strcpy(fcover,"+");
							else if (medrinj_cover == 0)
								strcpy(fcover, "+");
							else
								strcpy(fcover, "-");
							strcat(prtstr, fcover);
							strcat(prtstr,"000000000");
							t_minjured_cover = 0;
						}
						
						/* 203-212 �C�H���` */
						if (cnt_iins_main == 1)
						{
							if (count_ins2 > 0)
							{
								strcat(prtstr,"+000000000");
								t_mdeath_cover = 0;
							}
							else if (((strcmp(iedr_type, "20") == 0) || (strcmp(iedr_type, "77") == 0)) && twice_20_77 == 1)
							{
								strcat(prtstr,"-");
								rfmtlong(mdeath_cover_bak,"&&&&&&&&&", sTmpBuf8);
								strcat(prtstr, sTmpBuf8);
								t_mdeath_cover = 0 - mdeath_cover_bak;
							}
							else if (((strcmp(iedr_type, "20") == 0) || (strcmp(iedr_type, "77") == 0)) && twice_20_77 == 2)
							{
								strcat(prtstr,"+");
								rfmtlong(mdeath_cover_bak,"&&&&&&&&&", sTmpBuf8);
								strcat(prtstr, sTmpBuf8);
								t_mdeath_cover = mdeath_cover_bak;
							}
							else if (strncmp(fins_grp,"1",1) == 0) /*�����I���񦺤`�O�B ��38�B39*/
							{
								strcat(prtstr,"+000000000");
								t_mdeath_cover = 0;
							}
							else if (strcmp(trim(iins_type), "34") == 0)
							{
								if(medrdmg_cover < 0 ) strcat(prtstr,"-");
								else strcat(prtstr,"+");
								
								rfmtlong(medrdmg_cover,"&&&&&&&&&",sTmpBuf8);
								strcat(prtstr,sTmpBuf8); 
								t_mdeath_cover = medrdmg_cover;
							}
							else
							{
								if (medrdea_cover > 0)
									strcpy(fcover,"+");
								else if (medrdea_cover == 0)
									strcpy(fcover, "+");
								else
									strcpy(fcover, "-");
									
								strcat(prtstr, fcover);
								if( strcmp(trim(iins_type), "31") == 0  || strcmp(trim(iins_type), "131") == 0 || 
								    strcmp(trim(iins_type), "231") == 0 || strcmp(trim(iins_type), "331") == 0)
								{
									rfmtlong(medrinj_cover,"&&&&&&&&&",sTmpBuf8);
									strcat(prtstr,sTmpBuf8);    /* �ĤT�H�d�����`�M��˫O�B�ۦP */
									t_mdeath_cover = medrinj_cover;
								}
								else
								{
									rfmtlong(medrdea_cover,"&&&&&&&&&",sTmpBuf8);
									strcat(prtstr,sTmpBuf8);
									t_mdeath_cover = medrdea_cover;
								}
							}
						}
						else 
						{
							if (medrdea_cover > 0)
									strcpy(fcover,"+");
							else if (medrdea_cover == 0)
								strcpy(fcover, "+");
							else
								strcpy(fcover, "-");
							strcat(prtstr, fcover);
							strcat(prtstr,"000000000");
							t_mdeath_cover = 0;
						}
	
						/* 213-222 �C�@�ƬG */
						if (((strcmp(iedr_type, "20") == 0) || (strcmp(iedr_type, "77") == 0)) && twice_20_77 == 1)
						{
							mdmg_cover_bak_tmp = mdmg_cover_bak;
							strcat(prtstr, "-");
							if( abs(mdmg_cover_bak_tmp) > 999999999 )
								mdmg_cover_bak_tmp = 999999999;
							else
								mdmg_cover_bak_tmp = abs(mdmg_cover_bak);
					
							rfmtlong(mdmg_cover_bak_tmp, "&&&&&&&&&", sTmpBuf8);
							strcat(prtstr, sTmpBuf8);
							t_mdamage_cover = mdmg_cover_bak_tmp;
							t_mdamage_cover_bak = 0;
							t_mdamage_cover_aft = 0;
						}
						else if (((strcmp(iedr_type, "20") == 0) || (strcmp(iedr_type, "77") == 0)) && twice_20_77 == 2)
						{
							mdmg_cover_bak_tmp = mdmg_cover_bak;
							strcat(prtstr, "+");
							if( abs(mdmg_cover_bak_tmp) > 999999999 )
								mdmg_cover_bak_tmp = 999999999;
							else
								mdmg_cover_bak_tmp = abs(mdmg_cover_bak);
					
							rfmtlong(mdmg_cover_bak_tmp, "&&&&&&&&&", sTmpBuf8);
							strcat(prtstr, sTmpBuf8);
							t_mdamage_cover = mdmg_cover_bak_tmp;
							t_mdamage_cover_bak = 0;
							t_mdamage_cover_aft = 0;
						}
						else 
						{
							if (cnt_iins_main == 1 )
							{
								if (count_ins2 > 0)
								{
									strcat(prtstr,"+000000000");
									t_mdamage_cover = 0;
								}
								else if (strcmp(trim(iins_type),"10") == 0 && f_1090701 == 0)
								{
									strcat(prtstr,"+000000000");
									t_mdamage_cover = 0;
								}
								else if (chk_cover_per1 > 0 || chk_cover_per > 0 || chk_cover_Z1 > 0 || chk_cover_Z > 0)
								{
									/*mcover_ori_diff = mcover_ori - mcover_ori_bak;*/
									/*if (chk_cover_per1 > 0 || (chk_cover_Z1 > 0))
										mcover_prov_tmp_bak = mdmg_cover_bak - mcover_ori_bak;
									else 
										mcover_prov_tmp_bak = 0;
									
									if (chk_cover_per > 0 || (chk_cover_Z > 0))
										mcover_prov_tmp = mdamage_cover_aft - mcover_ori_aft;
									else 
										mcover_prov_tmp = 0;*/
	
									/*if (mcover_prov_tmp_bak < 0 && mcover_prov_tmp < 0)
									{
										mcover_prov_tmp_bak = 0;
										mcover_prov_tmp = 0;
										mcover_ori_diff = mdamage_cover_aft - mdmg_cover_bak;
									} 
									else if (mcover_prov_tmp_bak < 0 && mcover_prov_tmp > 0)
									{
										mcover_prov_tmp_bak = 0;
										mcover_ori_diff = mcover_ori_aft - mdmg_cover_bak;
									}
									else if (mcover_prov_tmp_bak > 0 && mcover_prov_tmp < 0)
									{
										mcover_prov_tmp = 0;
										mcover_ori_diff = mdamage_cover_aft - mcover_ori_bak;
									}
									else 
									{
										mcover_ori_diff = mcover_ori_aft - mcover_ori_bak;
									}*/
	
									mcover_ori_diff = mcover_ori_aft - mcover_ori_bak;
									mdamage_cover_diff = mdamage_cover_aft - mdmg_cover_bak;
									mcover_prov_diff = mdamage_cover_diff - mcover_ori_diff;
									printf("mcover_ori_aft[%d],mcover_ori_bak[%d]\n",mcover_ori_aft,mcover_ori_bak);
									printf("mdamage_cover_aft[%d],mdmg_cover_bak[%d]\n",mdamage_cover_aft,mdmg_cover_bak);
									printf("mdamage_cover_diff[%d],mcover_ori_diff[%d]\n",mdamage_cover_diff,mcover_ori_diff);
									
									if( mcover_ori_diff < 0 ) 
									{
										strcat(prtstr,"-");
										prtstr[192] = '-';
										prtstr[202] = '-';
									}
									else strcat(prtstr,"+");
									if( mcover_ori_diff > 999999999 )
										rfmtlong(mcover_ori_diff,"999999999",mcover_ori_diff_c);
									else 
										rfmtlong(mcover_ori_diff,"&&&&&&&&&",mcover_ori_diff_c);
									strcat(prtstr,mcover_ori_diff_c);
									t_mdamage_cover = mcover_ori_diff;
									t_mdamage_cover_bak = mcover_ori_bak;
									t_mdamage_cover_aft = mcover_ori_aft;
								}
								else
								{
									printf("medrdmg_cover[%d] \n",medrdmg_cover);
									if( medrdmg_cover < 0 ) 
									{
										strcat(prtstr,"-");
										prtstr[192] = '-';
										prtstr[202] = '-';
									}
									else strcat(prtstr,"+");
									if( abs(medrdmg_cover) > 999999999 )
										medrdmg_cover_over = 999999999;
									else
										medrdmg_cover_over = abs(medrdmg_cover);
									
									rfmtlong(medrdmg_cover_over, "&&&&&&&&&", sTmpBuf8);
									strcat(prtstr, sTmpBuf8);
									t_mdamage_cover = medrdmg_cover;
									t_mdamage_cover_bak = mdmg_cover_bak;
									t_mdamage_cover_aft = medrdmg_cover + mdmg_cover_bak;
								}
							}
							else if (strcmp(trim(iins_type),"P")==0 || strcmp(trim(iins_type),"Q")==0 || strcmp(trim(iins_type),"M")==0 || strcmp(trim(iins_type),"Z")==0)
							{
								printf("mcover_prov_tmp_bak[%d],mdmg_cover_bak[%d],mcover_ori_bak[%d] \n",mcover_prov_tmp_bak,mdmg_cover_bak,mcover_ori_bak);
								printf("mcover_prov_tmp[%d],mdamage_cover_aft[%d],mcover_ori[%d] \n",mcover_prov_tmp,mdamage_cover_aft,mcover_ori);
	
								if (chk_cover_K > 0)
								{
									strcat(prtstr,"+000000000");
									t_mdamage_cover = 0;
								}
								else 
								{
									printf("mcover_prov_tmp[%d],mcover_prov_tmp_bak[%d],mcover_prov_diff[%d] \n",mcover_prov_tmp,mcover_prov_tmp_bak,mcover_prov_diff);
									
									if( mcover_prov_diff < 0 ) 
									{
										strcat(prtstr,"-");
										prtstr[192] = '-';
										prtstr[202] = '-';
									}
									else strcat(prtstr,"+");
									if( mcover_prov_diff > 999999999 )
										rfmtlong(mcover_prov_diff,"999999999",mcover_prov_diff_c);
									else 
										rfmtlong(mcover_prov_diff,"&&&&&&&&&",mcover_prov_diff_c);
									strcat(prtstr, mcover_prov_diff_c);
									t_mdamage_cover = mcover_prov_diff;
								}
								t_mdamage_cover_bak = mdmg_cover_bak - mcover_ori_bak;
								t_mdamage_cover_aft = mdamage_cover_aft - mcover_ori_aft;
							}
							else
							{
								strcat(prtstr,"+000000000");
								t_mdamage_cover = 0;
								t_mdamage_cover_bak = mdmg_cover_bak;
								t_mdamage_cover_aft = medrdmg_cover + mdmg_cover_bak;
							}
						}
	
						/* 233-225 �O�٭��� */
						/*���᭿��*/
						iins_mult = 0;
						if (strcmp(trim(iins_type), "31")==0 || strcmp(trim(iins_type), "231")==0) /*�ƬG�O�B/��˫O�B*/
						{
							iins_mult = mdmg_tot/min_tot;
						}
						else if (strcmp(trim(iins_type), "109")==0)  /*(�ƬG�O�B-��˫O�B)/��˫O�B*/
						{
							iins_mult = (mdmg_tot-min_tot)/min_tot;
						}
						else if (strcmp(trim(iins_type), "301")==0)  /*2��*/
						{
							iins_mult = 2;
						}
						else if (strcmp(trim(iins_type), "302")==0)  /*2��*/
						{
							iins_mult = 2;
						}
						else if (strcmp(trim(iins_type), "131")==0 || strcmp(trim(iins_type), "331")==0)  /*�ƬG�O�B/��˫O�B*/
						{
							iins_mult = mdmg_tot/min_tot;
						}
						else if (strcmp(trim(iins_type), "124")==0)  /*2�� */
						{
							iins_mult = 2;
						}
						else if (strcmp(trim(iins_type), "34")==0)  /*2�� */
						{
							iins_mult = 1;
						}
						else if (strncmp(fins_grp,"1",1) != 0)
						{
							printf("iins_type[%s] fins_grp[%s] mdea_tot[%ld]\n",iins_type,fins_grp,mdea_tot);
							iins_mult = mdmg_tot/mdea_tot;
						}
						else
							iins_mult = 0;
						
						if (iins_mult > 99)
						{
							strcat(prtstr,"+99");
							t_iins_mult = 99;
						} 
						else 
						{
							rfmtlong(iins_mult,"&&",iin_mult_c);
							strcat(prtstr,"+");
							strcat(prtstr,iin_mult_c);
							t_iins_mult = iins_mult;
						}
				
						/* 226-233 �ۭt�B */
						/***�h�O�B���P�g�J��ۭt�B **/
						if (strcmp(iins_type,iins_main) != 0)  /*���[���ڦۭt�B0*/
						{
							strcat(prtstr,"5");	
							mdeduct = 0;
							rfmtlong(mdeduct, "&&&&&&&", sTmpBuf7);
							strcat(prtstr, sTmpBuf7);
							strcpy(t_fmdeduct,"5");
						}
						else
						{
							if(strcmp(iedr_type,"01")== 0 || strcmp(iedr_type,"02")==0)
							{
								sprintf(stmp,"SELECT mdeduct \
					        	                FROM %s:ply_ins_type_bak \
					        	               WHERE iendorse = '%s' AND iins_type = '%s' ",list[k].dbname,iendorse,iins_type);
					        	$PREPARE ply_ins_bk_mdt FROM $stmp;
								$EXECUTE ply_ins_bk_mdt INTO $mdeduct;
								
								if( (strcmp(trim(iins_type),"29")==0) || (strcmp(trim(iins_type),"30")==0))
								{
									mdeduct = 0;
								}
								
								if(strcmp(trim(iins_type), "71")==0 || strcmp(trim(iins_type), "72")==0)
								{
									strcat(prtstr,"1"); /*�s�x��*/
									strcpy(t_fmdeduct,"1");
									mdeduct = 10000;
								}
								else if(strcmp(trim(iins_type), "11")==0 || strcmp(trim(iins_type), "211")==0)
								{
									if( mdeduct == 0 )
									{
										strcat(prtstr,"5");
										strcpy(t_fmdeduct,"5");
									}
									else
									{
										strcat(prtstr,"3");
										strcpy(t_fmdeduct,"3");
									}
								}
								else if(strcmp(trim(iins_type), "08")==0)
								{
									if( abs(mdeduct) == 8 ) /*��L*/
									{
										strcat(prtstr,"4");
										mdeduct = 0;
										strcpy(t_fmdeduct,"4");
									}
									else 
									{
										strcat(prtstr,"5");
										strcpy(t_fmdeduct,"5");
									}
								}
								else if(strcmp(trim(iins_type),"01")==0  || strcmp(trim(iins_type),"05")==0 ||
								        strcmp(trim(iins_type),"201")==0 || strcmp(trim(iins_type),"205")==0)
								{
									if( mdeduct == 0 )
									{
										strcat(prtstr,"5"); /*�L�ۭt�B*/
										strcpy(t_fmdeduct,"5");
									}
									else if( abs(mdeduct) < 10 )
									{
										strcat(prtstr,"2"); /*�N��*/
										strcpy(t_fmdeduct,"2");
									}
									else 
									{
										strcat(prtstr,"1"); /*�s�x��*/
										strcpy(t_fmdeduct,"1");
									}
								}
								else if(strcmp(trim(iins_type),"09")==0 || strcmp(trim(iins_type),"209")==0)
								{
									if( mdeduct == 0 )
									{
										strcat(prtstr,"5"); /*�L�ۭt�B*/
										strcpy(t_fmdeduct,"5");
									}
									else
									{
										strcat(prtstr,"1"); /*�s�x��*/
										strcpy(t_fmdeduct,"1");
									}
								}
								else if (strcmp(trim(iins_type),"18") == 0)
								{
									strcat(prtstr,"3");	/*�ʤ���*/
									strcpy(t_fmdeduct,"3");
									if (mdeduct == 5010 || mdeduct == 6010 || mdeduct == 7510)
										mdeduct = 10;
									else if (mdeduct == 6020 || mdeduct == 7520)
									mdeduct = 20;
								}
								else if(strcmp(trim(iins_type),"28")==0)
								{
									if( mdeduct == 0 )
									{
								    	strcat(prtstr,"5"); /*�L�ۭt�B*/
								    	strcpy(t_fmdeduct,"5");
								    }
									else 
									{
										strcat(prtstr,"3"); /*�ʤ���*/
										strcpy(t_fmdeduct,"3");
									}
								}
								else if(strcmp(trim(iins_type),"98")==0)
								{
									strcat(prtstr,"5"); /*�L�ۭt�B*/
									mdeduct = 0 ;
									strcpy(t_fmdeduct,"5");
								}
								else if(strcmp(trim(iins_type), "31")==0  || strcmp(trim(iins_type), "32")==0 ||
								        strcmp(trim(iins_type), "231")==0 || strcmp(trim(iins_type), "232")==0)
								{
									if(mdeduct == 0 )
									{
										strcat(prtstr,"5");
										strcpy(t_fmdeduct,"5");
									}
									else
									{
										strcat(prtstr,"1");
										strcpy(t_fmdeduct,"1");
									}
								}
								else if(strcmp(trim(iins_type), "131")==0 || strcmp(trim(iins_type), "132")==0 ||
								        strcmp(trim(iins_type), "331")==0 || strcmp(trim(iins_type), "332")==0)
								{
									strcat(prtstr,"2");
									strcpy(t_fmdeduct,"2");
									mdeduct = 4;
								}
								else if(strcmp(trim(iins_type),"129")==0)
								{
									if( mdeduct == 0 )
									{
										strcat(prtstr,"5"); /*�L�ۭt�B*/
										strcpy(t_fmdeduct,"5");
									}
									else 
									{
										strcat(prtstr,"3"); /*�ʤ���*/
										strcpy(t_fmdeduct,"3");
									}
								}
								else if(strcmp(trim(iins_type),"122")==0)
								{
									if( mdeduct == 0 )
									{
										strcat(prtstr,"5"); /*�L�ۭt�B*/
										strcpy(t_fmdeduct,"5");
									}
									else if( abs(mdeduct) < 10 )
									{
										strcat(prtstr,"2"); /*�N��*/
										strcpy(t_fmdeduct,"2");
									}
									else 
									{
										strcat(prtstr,"1"); /*�s�x��*/
										strcpy(t_fmdeduct,"1");
									}
								}
								else if(strcmp(trim(iins_type), "113")==0)
								{
									if( mdeduct == 0 )
									{
										strcat(prtstr,"5"); /*�L�ۭt�B*/
										strcpy(t_fmdeduct,"5");
									}
									else
									{
										strcat(prtstr,"1"); /*�s�x��*/
										strcpy(t_fmdeduct,"1");
									}
								}	
								else if(strcmp(trim(iins_type), "128")==0 )
								{
									if( mdeduct == 0 )
									{
										strcat(prtstr,"5"); /*�L�ۭt�B*/
										strcpy(t_fmdeduct,"5");
									}
									else
									{
										strcat(prtstr,"3"); /*�ʤ���*/
										strcpy(t_fmdeduct,"3");
									}
								}
								else if(strcmp(trim(iins_type), "149")==0 || strcmp(trim(iins_type), "249")==0)
								{
									if( mdeduct == 0 )
									{
										strcat(prtstr,"5"); /*�L�ۭt�B*/
										strcpy(t_fmdeduct,"5");
									}
									else
									{
										strcat(prtstr,"1"); /*�s�x��*/
										strcpy(t_fmdeduct,"1");
									}
								}
								else if(strcmp(trim(iins_type), "176")==0 || strcmp(trim(iins_type), "177")==0 || strcmp(trim(iins_type), "178")==0)
								{
									if( mdeduct == 0 )
									{
										strcat(prtstr,"5");
										strcpy(t_fmdeduct,"5");
									}
									else
									{
										strcat(prtstr,"3");
										strcpy(t_fmdeduct,"3");
									}
								}
								else 
								{
									strcat(prtstr,"5");
									strcpy(t_fmdeduct,"5");
								}
								
								if (f_1060101 > 0)
								{
									if(((strcmp(trim(iins_type_develop),"13") == 0) || (strcmp(trim(iins_type_develop),"35") == 0) ||
								        (strcmp(trim(iins_type_develop),"54") == 0) || (strcmp(trim(iins_type_develop),"62") == 0) ||
								        (strcmp(trim(iins_type_develop),"33") == 0) || (strcmp(trim(iins_type_develop),"04") == 0)) && 
								        (strcmp(trim(iins_type),"28")  != 0 && strcmp(trim(iins_type),"128") != 0 &&
								         strcmp(trim(iins_type),"113") != 0 && strcmp(trim(iins_type),"149") != 0 && strcmp(trim(iins_type),"249") != 0 &&
								         strcmp(trim(iins_type),"176") != 0 && strcmp(trim(iins_type),"177") != 0 && strcmp(trim(iins_type),"178") != 0 )) 
										 
									{
										mdeduct = 0;
									}
								}
								else 
								{
									if(((strcmp(trim(iins_type_develop),"22") == 0) || (strcmp(trim(iins_type_develop),"61") == 0) ||
							           (strcmp(trim(iins_type_develop),"62") == 0) || (strcmp(trim(iins_type_develop),"16") == 0)) &&
							           (strcmp(trim(iins_type),"28")  != 0))
										mdeduct = 0;
								}

								rfmtlong(mdeduct, "&&&&&&&", sTmpBuf7);
								strcat(prtstr, sTmpBuf7);
								t_mdeduct = mdeduct;
							}
							else
							{
								if(strcmp(trim(iins_type), "71")==0 || strcmp(trim(iins_type), "72")==0)
								{
									strcat(prtstr,"1"); /*�s�x��*/
									strcpy(t_fmdeduct,"1");
									mdeduct = 10000;
								}
								else if(strcmp(trim(iins_type), "11")==0 || strcmp(trim(iins_type), "211")==0)
								{
									if( mdeduct == 0 )
									{
										strcat(prtstr,"5");
										strcpy(t_fmdeduct,"5");
									}
									else
									{
										strcat(prtstr,"3");
										strcpy(t_fmdeduct,"3");
									}
								}
								else if(strcmp(trim(iins_type), "08")==0)
								{
									if( abs(mdeduct) == 8 ) /*��L*/
									{
										 strcat(prtstr,"4");
										 strcpy(t_fmdeduct,"4");
										 mdeduct = 0;
									}
									else 
									{
										strcat(prtstr,"5");
										strcpy(t_fmdeduct,"5");
									}
								}
								else if(strcmp(trim(iins_type), "01")==0  || strcmp(trim(iins_type), "05")==0 ||
								        strcmp(trim(iins_type), "201")==0 || strcmp(trim(iins_type), "205")==0)
								{
									if( mdeduct == 0 )
									{
										strcat(prtstr,"5"); /*�L�ۭt�B*/
										strcpy(t_fmdeduct,"5");
									}
									else if( abs(mdeduct) < 10 )
									{
										strcat(prtstr,"2"); /*�N��*/
										strcpy(t_fmdeduct,"2");
									}
									else 
									{
										strcat(prtstr,"1"); /*�s�x��*/
										strcpy(t_fmdeduct,"1");
									}
								}
								else if(strcmp(trim(iins_type),"09")==0 || strcmp(trim(iins_type),"209")==0)
								{
								    if( mdeduct == 0 )
								    {
								    	strcat(prtstr,"5"); /*�L�ۭt�B*/
								    	strcpy(t_fmdeduct,"5");
								    }
								    else 
								    {
								    	strcat(prtstr,"1"); /*�s�x��*/
								    	strcpy(t_fmdeduct,"1");
								    }
								}
								else if (strcmp(trim(iins_type),"18") == 0)
								{
								    strcat(prtstr,"3");	/*�ʤ���*/
								    strcpy(t_fmdeduct,"3");
								    if (mdeduct == 5010 || mdeduct == 6010 || mdeduct == 7010)
										mdeduct = 10;
									else if (mdeduct == 6020 || mdeduct == 7020)
										mdeduct = 20;
								}
								else if(strcmp(trim(iins_type),"28")==0)
								{
								    if( mdeduct == 0 )
								    {
								        strcat(prtstr,"5"); /*�L�ۭt�B*/
								        strcpy(t_fmdeduct,"5");
								    }
								    else 
								    {
								    	strcat(prtstr,"3"); /*�ʤ���*/
								    	strcpy(t_fmdeduct,"3");
								    }
								}
								else if(strcmp(trim(iins_type),"98")==0)
								{
								    strcat(prtstr,"5"); /*�L�ۭt�B*/
								    strcpy(t_fmdeduct,"5");
								    mdeduct = 0 ;
								}
								else if(strcmp(trim(iins_type), "31")==0  || strcmp(trim(iins_type), "32")==0 ||
								        strcmp(trim(iins_type), "231")==0 || strcmp(trim(iins_type), "232")==0)
								{
								    if(mdeduct == 0 )
								    {
								    	strcat(prtstr,"5");
								    	strcpy(t_fmdeduct,"5");
								    }
								    else
								    {
								    	strcat(prtstr,"1");
								    	strcpy(t_fmdeduct,"1");
								    }
								}
								else if(strcmp(trim(iins_type), "131")==0 || strcmp(trim(iins_type), "132")==0 ||
								        strcmp(trim(iins_type), "331")==0 || strcmp(trim(iins_type), "332")==0)
								{
								    strcat(prtstr,"2");
								    strcpy(t_fmdeduct,"2");
									mdeduct = 4;
								}
								else if(strcmp(trim(iins_type),"129")==0)
								{
								    if( mdeduct == 0 )
								    {
								    	strcat(prtstr,"5"); /*�L�ۭt�B*/
								    	strcpy(t_fmdeduct,"5");
								    }
								    else
								    {
								    	strcat(prtstr,"3"); /*�ʤ���*/
								    	strcpy(t_fmdeduct,"3");
								    }
								}
								else if(strcmp(trim(iins_type), "122")==0)
								{
									if( mdeduct == 0 )
									{
										strcat(prtstr,"5"); /*�L�ۭt�B*/
										strcpy(t_fmdeduct,"5");
									}
									else if( abs(mdeduct) < 10 )
									{
										strcat(prtstr,"2"); /*�N��*/
										strcpy(t_fmdeduct,"2");
									}
									else 
									{
										strcat(prtstr,"1"); /*�s�x��*/
										strcpy(t_fmdeduct,"1");
									}
								}
								else if(strcmp(trim(iins_type), "113")==0)
								{
									if( mdeduct == 0 )
									{
										strcat(prtstr,"5"); /*�L�ۭt�B*/
										strcpy(t_fmdeduct,"5");
									}
									else
									{
										strcat(prtstr,"1"); /*�s�x��*/
										strcpy(t_fmdeduct,"1");
									}
								}	
								else if(strcmp(trim(iins_type), "128")==0 )
								{
									if( mdeduct == 0 )
									{
										strcat(prtstr,"5"); /*�L�ۭt�B*/
										strcpy(t_fmdeduct,"5");
									}
									else
									{
										strcat(prtstr,"3"); /*�ʤ���*/
										strcpy(t_fmdeduct,"3");
									}
								}
								else if(strcmp(trim(iins_type), "149")==0 || strcmp(trim(iins_type), "249")==0)
								{
									if( mdeduct == 0 )
									{
										strcat(prtstr,"5"); /*�L�ۭt�B*/
										strcpy(t_fmdeduct,"5");
									}
									else
									{
										strcat(prtstr,"1"); /*�s�x��*/
										strcpy(t_fmdeduct,"1");
									}
								}
								else if(strcmp(trim(iins_type), "176")==0 || strcmp(trim(iins_type), "177")==0 || strcmp(trim(iins_type), "178")==0)
								{
									if( mdeduct == 0 )
									{
										strcat(prtstr,"5");
										strcpy(t_fmdeduct,"5");
									}
									else
									{
										strcat(prtstr,"3");
										strcpy(t_fmdeduct,"3");
									}
								}
								else 
								{
									strcat(prtstr,"5");
									strcpy(t_fmdeduct,"5");
								}
								
								if (f_1060101 > 0)
								{
									if(((strcmp(trim(iins_type_develop),"13") == 0) || (strcmp(trim(iins_type_develop),"35") == 0) ||
								        (strcmp(trim(iins_type_develop),"54") == 0) || (strcmp(trim(iins_type_develop),"62") == 0) ||
								        (strcmp(trim(iins_type_develop),"33") == 0) || (strcmp(trim(iins_type_develop),"04") == 0)) && 
								        (strcmp(trim(iins_type),"28")  != 0 && strcmp(trim(iins_type),"128") != 0 &&
								         strcmp(trim(iins_type),"113") != 0 && strcmp(trim(iins_type),"149") != 0 && strcmp(trim(iins_type),"249") != 0 && 
								         strcmp(trim(iins_type),"176") != 0 && strcmp(trim(iins_type),"177") != 0 && strcmp(trim(iins_type),"178") != 0 ))
									{
										mdeduct = 0;
									}
								}
								else 
								{
									if(((strcmp(trim(iins_type_develop),"22") == 0) || (strcmp(trim(iins_type_develop),"61") == 0) ||
							           (strcmp(trim(iins_type_develop),"62") == 0) || (strcmp(trim(iins_type_develop),"16") == 0)) &&
							           (strcmp(trim(iins_type),"28")  != 0))
										mdeduct = 0;
								}
								
								rfmtlong(mdeduct, "&&&&&&&", sTmpBuf7);
								strcat(prtstr, sTmpBuf7);
								t_mdeduct = mdeduct;
								
								printf("--4686  iins_type_develop[%s],mdeduct[%d] \n",iins_type_develop,mdeduct);
							}
						}

						sprintf(stmp,"SELECT minjured_cover, mdeath_cover, mdamage_cover, mdeduct \
					        	        FROM %s:ply_ins_type_bak \
					        	       WHERE iendorse = '%s' AND iins_type = '%s' ",list[k].dbname,iendorse,iins_type);
			        	$PREPARE ply_ins_type_bak_cover FROM $stmp;
						$EXECUTE ply_ins_type_bak_cover INTO $min_cover2, $mdth_cover2, $mdmg_cover2, $old_mdeduct2;
						
						/* 234-267 �h���u�ݫe�O�O */
						printf("--ñ��/�«O�O \n");
						coefficient = 0.0;
						ifleet = 0;
						if (((strcmp(iedr_type, "20") == 0) || (strcmp(iedr_type, "77") == 0)) && twice_20_77 == 1)
						{
							/*�O�o���ʽ�N��11(�t��) ?���e�̷s�O��O�O*(1-�w�L���u�����)
							  �O�o���ʽ�N��12(����) ?���e�̷s�O��O�O*(1-�w�L���u�����)+�������O�O
							  ���w�L���u����ҡ��n�̦ۭt�B��諸���ۦP���p��覡 (�ݬO��M�Ϋ�D) fins_cal_way
							  $dedr_begin, $dedr_end,
							  */
							
							if(fins_cal_way[0] == 'M')
							{
								/*����p��-(�e���O�OX(��������)/�ӫO���)*/
								iedr_mon = DiffMonth(dedr_end,dedr_begin);
								iply_mon = DiffMonth(dply_end,dply_begin);
								printf("iedr_mon[%d] iply_mon[%d] \n",iedr_mon,iply_mon);
								$SELECT FIRST 1
								        ROUND($mins_premium_bak * $iedr_mon / $iply_mon)
								        INTO $mded_mins_premium_bak
								   FROM systables;
								printf("mins_premium_bak[%d] \n",mins_premium_bak);
								printf("dply_end[%d] dply_begin[%d] \n",dply_end,dply_begin);
								printf("dedr_end[%d] dedr_begin[%d] \n",dedr_end,dedr_begin);
								printf("mded_mins_premium_bak[%d] \n",mded_mins_premium_bak);
								$SELECT FIRST 1
								        ROUND($mpure_prem_bak * $iedr_mon / $iply_mon)
								        INTO $mded_mpure_prem_bak
								   FROM systables;
								printf("mpure_prem_bak[%d] \n",mpure_prem_bak);
								printf("dply_end[%d] dply_begin[%d] \n",dply_end,dply_begin);
								printf("dedr_end[%d] dedr_begin[%d] \n",dedr_end,dedr_begin);
								printf("mded_mpure_prem_bak[%d] \n",mded_mpure_prem_bak);
								
							}
							else if(fins_cal_way[0] == 'D')
							{
								/*����p��-(�e���O�OX(������Ѽ�)/�ӫO���)*/
								$SELECT FIRST 1
								        ROUND(($mins_premium_bak * ($dedr_end - $dedr_begin + 0.5)) / ($dply_end - $dply_begin))
								        INTO $mded_mins_premium_bak
								   FROM systables;
								printf("mins_premium_bak[%d] \n",mins_premium_bak);
								printf("dply_end[%d] dply_begin[%d] \n",dply_end,dply_begin);
								printf("dedr_end[%d] dedr_begin[%d] \n",dedr_end,dedr_begin);
								printf("mded_mins_premium_bak[%d] \n",mded_mins_premium_bak);
								$SELECT FIRST 1
								        ROUND(($mpure_prem_bak * ($dedr_end - $dedr_begin + 0.5)) / ($dply_end - $dply_begin))
								        INTO $mded_mpure_prem_bak
								   FROM systables;
								printf("mpure_prem_bak[%d] \n",mpure_prem_bak);
								printf("dply_end[%d] dply_begin[%d] \n",dply_end,dply_begin);
								printf("dedr_end[%d] dedr_begin[%d] \n",dedr_end,dedr_begin);
								printf("mded_mpure_prem_bak[%d] \n",mded_mpure_prem_bak);
							}
							
							strcat(prtstr,"-");
							rfmtlong(mded_mins_premium_bak, "&&&&&&&&&", sTmpBuf9);
							strcat(prtstr, sTmpBuf9);
							
							strcat(prtstr,"-");
							rfmtlong(mded_mins_premium_bak, "&&&&&&&&&", sTmpBuf9);
							strcat(prtstr, sTmpBuf9);   
							/*�[��򥻯«O�O*/
							strcat(prtstr,"-0000000000000");
							
							/*t_mprem = 0 - mins_premium_bak;
							t_mprem_pure = 0 - mpure_prem_bak;*/
							t_mprem = 0 - mded_mins_premium_bak;
							t_mprem_pure = 0 - mded_mins_premium_bak;
							t_mprem_pure_base = 0;
							t_mprem_bak = 0;
							t_mprem_pure_bak = 0;
							t_mprem_pure_base_bak = 0;
							t_mprem_aft = 0;
							t_mprem_pure_aft = 0;
							t_mprem_pure_base_aft = 0;
	
							mins_premium_tot = 0;
							mprem_pure_prov_tot = 0;
							mins_premium_tot = mins_premium_tot - mded_mins_premium_bak;
							mprem_pure_prov_tot = mprem_pure_prov_tot - mded_mins_premium_bak;
						}
						else if (((strcmp(iedr_type, "20") == 0) || (strcmp(iedr_type, "77") == 0)) && twice_20_77 == 2)
						{
							if((medrins_prem+mded_mins_premium_bak)<0)
							strcat(prtstr,"-");
							else 
							strcat(prtstr,"+");
							rfmtlong((medrins_prem+mded_mins_premium_bak), "&&&&&&&&&", sTmpBuf9);
							strcat(prtstr, sTmpBuf9);
							
							if((medrpure_prem+mded_mins_premium_bak)<0)
							strcat(prtstr,"-");
							else 
							strcat(prtstr,"+");
							rfmtlong(medrpure_prem+mded_mins_premium_bak, "&&&&&&&&&", sTmpBuf9);
							strcat(prtstr, sTmpBuf9);
							/*�[��򥻯«O�O*/   
							strcat(prtstr,"+0000000000000");
							
							t_mprem = medrins_prem+mded_mins_premium_bak;
							t_mprem_pure = medrpure_prem+mded_mins_premium_bak;
							t_mprem_pure_base = 0;
							t_mprem_bak = 0;
							t_mprem_pure_bak = 0;
							t_mprem_pure_base_bak = 0;
							t_mprem_aft = 0;
							t_mprem_pure_aft = 0;
							t_mprem_pure_base_aft = 0;
							
							mins_premium_tot = 0;
							mprem_pure_prov_tot = 0;
							mins_premium_tot = (medrins_prem+mded_mins_premium_bak);
							mprem_pure_prov_tot = (medrpure_prem+mded_mins_premium_bak);
						}
						else if (count_ins2 > 0)
						{
							cnt_iins_main_dtl = 1;
							strcat(prtstr,"+000000000");
							strcat(prtstr,"+000000000");
							strcat(prtstr,"+0000000000000");
							mins_premium_tot = 0;
							mprem_pure_prov_tot = 0;
							
							t_mprem = 0;
							t_mprem_pure = 0;
							t_mprem_pure_base = 0;
							t_mprem_bak = 0;
							t_mprem_pure_bak = 0;
							t_mprem_pure_base_bak = 0;
							t_mprem_aft = 0;
							t_mprem_pure_aft = 0;
							t_mprem_pure_base_aft = 0;
						}
						else
						{
							if (cnt_iins_main == 1)
							{
								cnt_iins_main = 0;
								cnt_iins_main_dtl = 1;
								ca_rate_qpt = 0;
								mprem_base = 0.0;      
	
								printf("icar_type_ori[%s] iins_type[%s] mdeduct[%d] medrinj_cover[%d] medrdmg_cover[%d]\n",icar_type_ori,iins_type,mdeduct,medrinj_cover,medrdmg_cover);
								mcover1 = medrinj_cover;
								mcover2 = medrdmg_cover;
								
								if(chk_bak > 0)
								{
									pubi_acc_bak = 0.0;
									printf("---ibrand_bak[%s] \n",ibrand_bak);
									printf("min_cover_bak[%d] mdmg_cover_bak[%d] \n",min_cover_bak,mdmg_cover_bak);
									mcover1_bak = min_cover_bak;
									mcover2_bak = mdeath_cover_bak;
									mcover3_bak = mdmg_cover_bak;
									
									if (strcmp(trim(iins_main),"117") == 0)
									{
										rc = get_ca_car_model(ibrand_bak,ipro_year_bak,drate_ym_bak,&mcar_price_ori_bak,&qpassenger_bak,&icar_series_bak);
										if( rc != M_CM_OK)
										{
											mcar_price_ori_bak = 0.0;
											qpassenger_bak = 0.0;
											icar_series_bak[0] = '\0';
										}
									}
									else qpassenger_bak = 0;
									
									if(strcmp(trim(iins_type),"29") == 0 || strcmp(trim(iins_type),"124") == 0)
									{
										sprintf(stmp,"SELECT mdamage_cover \
					        	                        FROM %s:ply_ins_type_bak \
					        	                       WHERE iendorse = '%s' AND iins_type = '32' ",list[k].dbname,iendorse);
					        			$PREPARE ply_ins_type_bak_mcover1 FROM $stmp;
										$EXECUTE ply_ins_type_bak_mcover1 INTO $mcover1_bak;
										
										if(SQLCODE==SQLNOTFOUND) mcover1_bak = 0;
									}
									else if(strcmp(trim(iins_type),"109") == 0)
									{
										sprintf(stmp,"SELECT mdamage_cover \
					        	                        FROM %s:ply_ins_type_bak \
					        	                       WHERE iendorse = '%s' AND iins_type = '31' ",list[k].dbname,iendorse);
					        			$PREPARE ply_ins_type_bak_mcover1_2 FROM $stmp;
										$EXECUTE ply_ins_type_bak_mcover1_2 INTO $mcover1_bak;
										if(SQLCODE==SQLNOTFOUND) mcover1_bak = 0;
									}
									else if(strcmp(trim(iins_type),"34") == 0 || strcmp(trim(iins_type),"87") == 0 || strcmp(trim(iins_type),"115") == 0)
									{
										sprintf(stmp,"SELECT mcover \
					        	                        FROM %s:ply_ins_cover_bak \
					        	                       WHERE iendorse = '%s' AND iins_type = '%s' AND icover_type = '001' ",list[k].dbname,iendorse,iins_type);
					        			$PREPARE ply_ins_cover_bak_mcover FROM $stmp;
										$EXECUTE ply_ins_cover_bak_mcover INTO $mcover1_bak;
										
										if(SQLCODE==SQLNOTFOUND) mcover1_bak = 0;
										
										sprintf(stmp,"SELECT mcover \
					        	                        FROM %s:ply_ins_cover_bak \
					        	                       WHERE iendorse = '%s' AND iins_type = '%s' AND icover_type = '002' ",list[k].dbname,iendorse,iins_type);
					        			$PREPARE ply_ins_cover_bak_mcover2 FROM $stmp;
										$EXECUTE ply_ins_cover_bak_mcover2 INTO $mcover2_bak;
										if(SQLCODE==SQLNOTFOUND) mcover2_bak = 0;
									}
									
									printf("fcal_way[%s],icar_type_ori_bak[%s],iins_type[%s],qpt_bak[%f] \n",
									        fcal_way,icar_type_ori_bak,iins_type,qpt_bak);
									printf("drate_ym_bak[%s],qply_period_bak[%d],dply_begin_bak[%d] \n",
									        drate_ym_bak,qply_period_bak,dply_begin_bak);
									
									printf("--dissue_bak[%s]\n",dissue_bak);
									printf("--ipro_year_bak[%s]\n",ipro_year_bak);
									printf("--qday_bak[%d]\n",qday_bak);
									printf("--mdeduct_bak[%d]\n",mdeduct_bak);
									printf("--mcover1_bak[%d]\n",mcover1_bak);
									printf("--mcover2_bak[%d]\n",mcover2_bak);
									printf("--mcover3_bak[%d]\n",mcover3_bak);
									printf("--qpassenger_bak[%d]\n",qpassenger_bak);
									printf("--mcar_price_bak[%f]\n",mcar_price_bak);
									printf("--ibrand_bak[%s]\n",ibrand_bak);
									
									v_sMsg[0] = '\0';
									
									prov_bf_J = 0;
									$SELECT count(*) INTO $prov_bf_J FROM prov_tmp WHERE provision = 'J' AND f_af_bf = 'b';
									if (prov_bf_J > 0)
									{
										rc = get_mprem_base(fcal_way,icar_type_ori_bak,iins_type,qpt_bak,fpt_bak,drate_ym_bak,qply_period_bak,dply_begin_bak,
											                dissue_bak,ipro_year_bak,qpro_month_bak,qday_bak,mdeduct_bak,mcover1_bak,mcover2_bak,mcover3_bak,qpassenger_bak,mcar_price_bak,ibrand_bak,"J",&mprem_base_bak,&v_sMsg);
									}
									else 
									{                
										rc = get_mprem_base(fcal_way,icar_type_ori_bak,iins_type,qpt_bak,fpt_bak,drate_ym_bak,qply_period_bak,dply_begin_bak,
											                dissue_bak,ipro_year_bak,qpro_month_bak,qday_bak,mdeduct_bak,mcover1_bak,mcover2_bak,mcover3_bak,qpassenger_bak,mcar_price_bak,ibrand_bak," ",&mprem_base_bak,&v_sMsg);
									}
									if( rc != M_CM_OK) 
									{
										mprem_base_bak = 0.0;
									}
									
									printf("mprem_base_bak[%f]\n",mprem_base_bak);
				
									if ( cnt_prov_t1 == 0 || 
									    (cnt_prov_t1 == cnt_prov1 && strstr(trim(provision),"Z") == NULL)) 
									{
										printf("--���e�I��ñ��/�«O�O-�S�����[���� ������O�O\n");	
													
										mprem_cal_bak = mins_premium_bak;
										mprem_pure_cal_bak = mpure_prem_bak;
									}
									else 
									{
										printf("--���e�I��ñ��/�«O�O-�����[���� �񥼭��Y�ƫO�O\n");
										mprem_cal_bak = mins_premium_n_bak;
										mprem_pure_cal_bak = mpure_prem_n_bak;
									}
									printf("mprem_cal_bak[%d] mprem_pure_cal_bak[%d] \n",mprem_cal_bak,mprem_pure_cal_bak);
									
								}
								/*--------------------------------------------------------------------------------------------------------------------*/
			
								/*����򥻯«O�O*/
								if(strcmp(trim(iins_type),"29") == 0 || strcmp(trim(iins_type),"124") == 0)
								{
									sprintf(stmp,"SELECT medrdmg_cover \
					        	                    FROM %s:edr_ins_type \
					        	                   WHERE iendorse = '%s' AND iins_type = '32' ",list[k].dbname,iendorse);
					        		$PREPARE edr_ins_type_mdmg FROM $stmp;
									$EXECUTE edr_ins_type_mdmg INTO $mcover1_aft;
									
									if(SQLCODE==SQLNOTFOUND) mcover1_aft = 0;
			
									mcover1_aft = mcover1_aft+ mcover1_bak;
									mcover2_aft = medrdea_cover + mcover2_bak;
									mcover3_aft = medrdmg_cover + mcover3_bak;
									/*bak_32 + ���W��32*/
								}
								else if(strcmp(trim(iins_type),"109") == 0)
								{								
									sprintf(stmp,"SELECT medrdmg_cover \
					        	                    FROM %s:edr_ins_type \
					        	                   WHERE iendorse = '%s' AND iins_type = '31' ",list[k].dbname,iendorse);
					        		$PREPARE edr_ins_type_mdmg2 FROM $stmp;
									$EXECUTE edr_ins_type_mdmg2 INTO $mcover1_aft;
									
									if(SQLCODE==SQLNOTFOUND) mcover1_aft = 0;
									
									mcover1_aft = mcover1_aft + mcover1_bak;
									mcover2_aft = medrdea_cover + mcover2_bak;
									mcover3_aft = medrdmg_cover + mcover3_bak;
									/*bak_31 + ���W��32*/
								}
								else if(strcmp(trim(iins_type),"34") == 0 || strcmp(trim(iins_type),"87") == 0 || strcmp(trim(iins_type),"115") == 0)
								{
									sprintf(stmp,"SELECT mcover \
					        	                    FROM %s:edr_ins_cover \
					        	                   WHERE iendorse = '%s' AND iins_type = '%s' AND icover_type = '001' ",list[k].dbname,iendorse,iins_type);
					        		$PREPARE edr_ins_cover_mcover FROM $stmp;
									$EXECUTE edr_ins_cover_mcover INTO $mcover1_aft;
									
									if(SQLCODE==SQLNOTFOUND) mcover1_aft = 0;
									
									sprintf(stmp,"SELECT mcover \
					        	                    FROM %s:edr_ins_cover \
					        	                   WHERE iendorse = '%s' AND iins_type = '%s' AND icover_type = '002' ",list[k].dbname,iendorse,iins_type);
					        		$PREPARE edr_ins_cover_mcover FROM $stmp;
									$EXECUTE edr_ins_cover_mcover INTO $mcover2_aft;
									if(SQLCODE==SQLNOTFOUND) mcover2_aft = 0;
									    
									mcover1_aft = mcover1_aft + mcover1_bak;
									mcover2_aft = mcover2_aft + mcover2_bak;
								}
								else 
								{
									mcover1_aft = medrinj_cover + mcover1_bak;
									mcover2_aft = medrdea_cover + mcover2_bak;
									mcover3_aft = medrdmg_cover + mcover3_bak;
								}
								
								v_sMsg[0] = '\0';
								prov_J = 0;
								$SELECT count(*) INTO $prov_J FROM prov_tmp WHERE provision = 'J' AND f_af_bf = 'a';

								if (prov_J > 0)
								{
									rc = get_mprem_base(fcal_way,icar_type_ori,iins_type,qpt,fpt,drate_ym,qply_period,dply_begin,
									                dissue,ipro_year,qpro_month,qday,mdeduct_ori,mcover1_aft,mcover2_aft,mcover3_aft,qpassenger,mcar_price,ibrand,"J",&mprem_base_aft,v_sMsg);
								}
								else 
								{
									rc = get_mprem_base(fcal_way,icar_type_ori,iins_type,qpt,fpt,drate_ym,qply_period,dply_begin,
									                dissue,ipro_year,qpro_month,qday,mdeduct_ori,mcover1_aft,mcover2_aft,mcover3_aft,qpassenger,mcar_price,ibrand," ",&mprem_base_aft,v_sMsg);
								}

								printf("mprem_base_aft[%f]\n",mprem_base_aft);
								
								if( rc != M_CM_OK) 
								{
									mprem_base_aft = 0.0;
								}
			
								printf("--�����I��ñ��/�«O�O \n");
								if ( cnt_prov_t == 0 || 
							   	   ( cnt_prov_t == cnt_prov && strstr(trim(provision),"Z") == NULL)) 
								{
									printf("--�����I��ñ��/�«O�O-�S�����[���� \n");	
									mprem_cal_aft = medrins_prem + mins_premium_bak;
									mprem_pure_cal_aft = medrpure_prem + mpure_prem_bak;
								}
								else 
								{
									printf("--�����I��ñ��/�«O�O-�����[����- \n");
									medrins_prem_tmp = 0;
									printf("mins_premium_n[%d] mins_premium[%d] \n",mins_premium_n,mins_premium);
									printf("mpure_prem_n[%d] medrpure_prem[%d] \n",mpure_prem_n,medrpure_prem);
									if (mins_premium_n == mins_premium && mins_premium_n != 0) 
									{
										mpure_prem_n = medrpure_prem;
									}
									else if(abs(medrins_prem - mins_premium_n) < abs(medrpure_prem - mpure_prem_n))
									{
										medrins_prem_tmp = (medrpure_prem - mpure_prem_n) - (medrins_prem - mins_premium_n);
										mpure_prem_n += medrins_prem_tmp;
									}
									else medrins_prem_tmp = 0;
									
									mins_premium_aft = medrins_prem + mins_premium_bak;
									mpure_prem_aft = medrpure_prem + mpure_prem_bak;
									mins_premium_n_aft = mins_premium_n + mins_premium_n_bak;
									mpure_prem_n_aft = mpure_prem_n + mpure_prem_n_bak;
									
									mprem_cal_aft = mins_premium_n + mins_premium_n_bak;
									printf("--5125  mprem_cal_aft[%d] mins_premium_n[%d] mins_premium_n_bak[%d]\n",mprem_cal_aft,mins_premium_n,mins_premium_n_bak);
									mprem_pure_cal_aft = mpure_prem_n + mpure_prem_n_bak;
									printf("--5127  mprem_pure_cal_aft[%d] mpure_prem_n[%d] mpure_prem_n_bak[%d]\n",mprem_pure_cal_aft,mpure_prem_n,mpure_prem_n_bak);
								}
	
								printf("mprem_cal_aft[%d] mprem_pure_cal_aft[%d] \n",mprem_cal_aft,mprem_pure_cal_aft);
			
								mins_premium_tot = 0;
								mprem_pure_prov_tot = 0;
								mprem_base_tot = 0;
								mins_premium_tot = mprem_cal_aft - mprem_cal_bak;
								mprem_pure_prov_tot = mprem_pure_cal_aft - mprem_pure_cal_bak;
								mprem_base_tot = mprem_base_aft - mprem_base_bak;
								
								printf("mins_premium_tot[%d] mprem_pure_prov_tot[%d] mprem_base_tot[%f]\n",mins_premium_tot,mprem_pure_prov_tot,mprem_base_tot);
								
								/*�[��ñ��O�O*/
								if( mins_premium_tot < 0 ) strcat(prtstr,"-");
								else strcat(prtstr,"+");
								rfmtlong(mins_premium_tot,"&&&&&&&&&",mins_premium_tot_c);
							    strcat(prtstr,mins_premium_tot_c);
								/*�[��«O�O*/
							    if( mprem_pure_prov_tot < 0 ) strcat(prtstr,"-");
								else strcat(prtstr,"+");
								rfmtlong(mprem_pure_prov_tot,"&&&&&&&&&",mprem_pure_prov_tot_c);
							    strcat(prtstr,mprem_pure_prov_tot_c);
								/*�[��򥻯«O�O*/    
							    if( mprem_base_tot < 0 ) strcat(prtstr,"-");
								else strcat(prtstr,"+");
								rfmtdouble((mprem_base_tot*10000),"&&&&&&&&&&&&&",mprem_base_tot_c);
							    strcat(prtstr,mprem_base_tot_c);
							    
							    t_mprem = mins_premium_tot;
								t_mprem_pure = mprem_pure_prov_tot;
								t_mprem_pure_base = mprem_base_tot;
								t_mprem_bak = mprem_cal_bak;
								t_mprem_pure_bak = mprem_pure_cal_bak;
								t_mprem_pure_base_bak = mprem_base_bak;
								t_mprem_aft = mprem_cal_aft;
								t_mprem_pure_aft = mprem_pure_cal_aft;
								t_mprem_pure_base_aft = mprem_base_aft;	
							}
							else 
							{
								/*------------------------���e�������[����-------------------------------------------*/
								printf("--5174 prov-iins_type[%s],iins_main[%s] ibef[%d] iaft[%d]\n",iins_type,iins_main,ibef,iaft);	
								if (ibef+iaft > 0)
								{
									if (ibef > 0)
									{
										printf("--���e���[����ñ��/�«O�O \n");
										printf("-���e�����Ӫ��[����\n");
										printf("-prov-iins_type[%s],iins_main[%s]\n",iins_type,iins_main);	
										if (strcmp(trim(iins_type),"Z") == 0 || (strcmp(trim(iins_type),"P")==0 && inext1 >0))
										{
											mprem_prov_bak =0;
											mprem_pure_prov_bak =0;
										}
										else if (cnt_prov_t1 == cnt_prov1) 
										{
											printf("-���e��-�Ѥ@�Ӫ��[����\n");
											printf("-main-iins_type[%s],iins_main[%s]\n",iins_type,iins_main);	
											printf("mins_premium_bak[%d],mins_premium_n_bak[%d],mprov_tmp_bak[%d]\n",mins_premium_bak,mins_premium_n_bak,mprov_tmp_bak);
											printf("mpure_prem_bak[%d],mpure_prem_n_bak[%d],mprov_pure_tmp_bak[%d]\n",mpure_prem_bak,mpure_prem_n_bak,mprov_pure_tmp_bak);
											mprem_prov_bak = mins_premium_bak - mins_premium_n_bak - mprov_tmp_bak;
											mprem_pure_prov_bak = mpure_prem_bak - mpure_prem_n_bak - mprov_pure_tmp_bak;
										}
										else 
										{
											printf("-���e��-���[���ڤ���\n");
											$EXECUTE CUR_CARCLASS INTO $fcar_class_bak USING $icar_type_ori_bak;
											if(SQLCODE == SQLNOTFOUND) strcpy(fcar_class_bak,"1");
											v_sMsg[0] = '\0';
											ifleet_bak = 0;
											
											rc = get_prov_coefficient( iins_type,drate_ym_bak,fcar_class_bak,iins_main,icar_type_ori_bak,qprovision_bak,qpt_bak,
												                       mdeduct_ori_bak,mcover1_bak,mcover2_bak,carfleet_rate_bak,pcar_price,pubi_acc_bak,
												                       mcar_price_bak,mequipment_bak,
												                       &ifleet_bak,&coefficient_bak,&chk_prov_bak,v_sMsg);
											printf("--rc[%d] coefficient_bak[%f] ifleet_bak[%d] chk_prov_bak[%s] \n",rc,coefficient_bak,ifleet_bak,chk_prov_bak,v_sMsg);
											if( rc != M_CM_OK) break;
											if (strcmp(chk_prov,"N") == 0)
											{
												mprem_prov_bak = 0;	
												mprem_pure_prov_bak = 0;
											}
											else 
											{
												printf("mprem_cal_bak[%d],mprem_pure_cal_bak[%d]",mprem_cal_bak,mprem_pure_cal_bak);
												rc = get_mcoefficient(coefficient_bak,ifleet_bak,&mprem_cal_bak,&mprem_pure_cal_bak,&mprem_prov_bak,&mprem_pure_prov_bak);
												mprov_tmp_bak += mprem_prov_bak;
												mprov_pure_tmp_bak += mprem_pure_prov_bak;
											}
											printf("--5219  mprov_tmp_bak[%d],mprem_prov_bak[%d]\n",mprov_tmp_bak,mprem_prov_bak);
											printf("mprem_cal_bak[%d],mprem_pure_cal_bak[%d]\n",mprem_cal_bak,mprem_pure_cal_bak);
											printf("mprem_prov_bak[%d],mprem_pure_prov_bak[%d]\n",mprem_prov_bak,mprem_pure_prov_bak);
										}
									}
									else
									{
										printf("-���e���S�����Ӫ��[����\n");
										mprem_prov_bak = 0;	
										mprem_pure_prov_bak = 0;	
									}
									
									if (iaft > 0)
									{	
										printf("-���ᦳ���[����\n");
										if (strcmp(trim(iins_type),"Z") == 0 || (strcmp(trim(iins_type),"P")==0 && inext >0))
										{
											mprem_prov_aft = 0;
											mprem_pure_prov_aft = 0;
										}
										else if (cnt_prov_t == cnt_prov) 
										{
											printf("-����-�Ѥ@�Ӫ��[����\n");
											printf("mins_premium_aft[%d],mins_premium_n_aft[%d],mprov_tmp_aft[%d]\n",mins_premium_aft,mins_premium_n_aft,mprov_tmp_aft);
											printf("mpure_prem_aft[%d],mpure_prem_n_aft[%d],mprov_pure_tmp_aft[%d]\n",mpure_prem_aft,mpure_prem_n_aft,mprov_pure_tmp_aft);
											mprem_prov_aft = mins_premium_aft - mins_premium_n_aft - mprov_tmp_aft;
											mprem_pure_prov_aft = mpure_prem_aft - mpure_prem_n_aft - mprov_pure_tmp_aft;
										}	
										else 
										{
											printf("-����-���[���ڤ���\n");	
											$EXECUTE CUR_CARCLASS INTO $fcar_class using $icar_type_ori;
											if(SQLCODE == SQLNOTFOUND) strcpy(fcar_class,"1");
											v_sMsg[0] = '\0';
											ifleet = 0;
		
											medrinj_tmp = min_cover2+medrinj_cover;
											mdmg_tmp = mdmg_cover2+medrdmg_cover;
											mdeduct_tmp = mdeduct+old_mdeduct2;
											
											printf("medrinj_tmp[%d],mdmg_tmp[%d]\n",medrinj_tmp,mdmg_tmp);
											rc = get_prov_coefficient( iins_type,drate_ym,fcar_class,iins_main,icar_type_ori,qprovision,qpt,
											                            abs(mdeduct_tmp),abs(medrinj_tmp),abs(mdmg_tmp),carfleet_rate,pcar_price,0.0,
											                            mcar_price,mequipment,
											                            &ifleet,&coefficient,&chk_prov,v_sMsg);
											printf("--rc[%d] coefficient[%f] ifleet[%d] chk_prov[%s] \n",rc,coefficient,ifleet,chk_prov,v_sMsg);
											if( rc != M_CM_OK) break;
											if (strcmp(chk_prov,"N") == 0)
											{
												mprem_prov_aft = 0;	
												mprem_pure_prov_aft = 0;
											}
											else 
											{
												printf("mprem_cal_aft[%d],mprem_pure_cal_aft[%d]",mprem_cal_aft,mprem_pure_cal_aft);
												rc = get_mcoefficient(coefficient,ifleet,&mprem_cal_aft,&mprem_pure_cal_aft,&mprem_prov_aft,&mprem_pure_prov_aft);
											}
											printf("mprem_cal_aft[%d],mprem_pure_cal_aft[%d]\n",mprem_cal_aft,mprem_pure_cal_aft);
											printf("mprem_prov_aft[%d],mprem_pure_prov_aft[%d]\n",mprem_prov_aft,mprem_pure_prov_aft);
		
											mprov_tmp_aft += mprem_prov_aft;
											mprov_pure_tmp_aft += mprem_pure_prov_aft;
											printf("--5280  mprov_tmp_aft[%d],mprem_prov_aft[%d]\n",mprov_tmp_aft,mprem_prov_aft);
										}
									}
									else
									{
										mprem_prov_aft = 0;	
										mprem_pure_prov_aft = 0;
									}
								}
								else
								{
									/*��0*/	
									if (strcmp(trim(iins_type),"Z") == 0)
									{
										mprem_prov_bak =0;
										mprem_pure_prov_bak =0;
										mprem_prov_aft = 0;
										mprem_pure_prov_aft = 0;
									}
									else 
									{
										mprem_prov_bak=0;
										mprem_pure_prov_bak=0;
										mprov_tmp_bak = 0;
										mprov_pure_tmp_bak = 0;
										mprem_prov_aft = 0;
										mprem_pure_prov_aft = 0;
										mprov_tmp_aft += mprem_prov_aft;
										mprov_pure_tmp_aft += mprem_pure_prov_aft;
									}
								}
								
								printf("--5300 FINAL \n");
								printf("mprem_prov_aft[%d] mprem_prov_bak[%d] \n",mprem_prov_aft,mprem_prov_bak);
								printf("mprem_pure_prov_aft[%d] mprem_pure_prov_bak[%d] \n",mprem_pure_prov_aft,mprem_pure_prov_bak);
								mprem_prov = mprem_prov_aft - mprem_prov_bak;
								mprem_pure_prov = mprem_pure_prov_aft - mprem_pure_prov_bak ;
								
								printf("mprem_prov[%d] mprem_pure_prov[%d] \n",mprem_prov,mprem_pure_prov);
								/*mprem_pure_prov = mprem_pure_prov_aft - mprem_pure_prov_bak + mprem_pure_prov_over;
								mprem_pure_prov_over = 0;
								if (mprem_prov == 0 && mprem_pure_prov !=0)
								{
									if (mprem_pure_prov < 0) mprem_pure_prov_over = mprem_pure_prov;
									else mprem_pure_prov_over = 0 - mprem_pure_prov;
									mprem_pure_prov = 0;
								}*/
	
								printf("iins_type[%s],iins_main[%s] \n",iins_type,iins_main);
								printf("mprem_prov_aft[%d],mprem_prov_bak[%d] \n",mprem_prov_aft,mprem_prov_bak);
								printf("mprem_pure_prov_aft[%d],mprem_pure_prov_bak[%d] \n",mprem_pure_prov_aft,mprem_pure_prov_bak);
								printf("mprem_prov[%d],mprem_pure_prov[%d] \n",mprem_prov,mprem_pure_prov);
								
								if (mprem_prov < 0) strcat(prtstr,"-");
								else strcat(prtstr,"+");  
								rfmtlong(mprem_prov,"&&&&&&&&&",mprem_prov_c);
								strcat(prtstr,mprem_prov_c);
								if (mprem_pure_prov < 0) strcat(prtstr,"-");
								else strcat(prtstr,"+");
								rfmtlong(mprem_pure_prov,"&&&&&&&&&",mprem_pure_prov_c);
							    strcat(prtstr,mprem_pure_prov_c);
							    if (mprem_pure_prov < 0) strcat(prtstr,"-");
								else strcat(prtstr,"+");
							    strcat(prtstr,"0000000000000");
							    
							    t_mprem = mprem_prov;
								t_mprem_pure = mprem_pure_prov;
								t_mprem_pure_base = mprem_pure_prov;
								t_mprem_bak = mprem_prov_bak;
								t_mprem_pure_bak = mprem_pure_prov_bak;
								t_mprem_pure_base_bak = 0;
								t_mprem_aft = mprem_prov_aft;
								t_mprem_pure_aft = mprem_pure_prov_aft;
								t_mprem_pure_base_aft = 0;	
							}
						}
						
						/* 268-279 �ӫ~�N�X */
						printf("iins_type[%s],iins_main[%s] \n",iins_type,iins_main);
						if (strcmp(iins_type,iins_main) != 0)
						{
							printf("get iprovision product \n");
							fcar_class_p[0] = '\0';
							printf("555*******iproduct--iins_type[%s],iins_main[%s],fcar_class_p[%s],icar_type_ori[%s] \n",iins_type,iins_main,fcar_class_p,icar_type_ori);
							if((strcmp(iins_type,"F") == 0) || (strcmp(iins_type,"G") == 0) || (strcmp(iins_type,"T") == 0))
							{
								strcpy(iproduct_bef2,iproduct_bef);
								strcpy(iproduct,iproduct_bef2);
							}
							else
							{
								$EXECUTE CUR_CARCLASS INTO $fcar_class_p USING $icar_type;
								strcpy(fcar_class_p,trim(fcar_class_p));
								
								if(((strcmp(iins_type,"L") == 0) || (strcmp(iins_type,"R") == 0)) &&
							       ((strcmp(icar_type,"01") == 0) || (strcmp(icar_type,"02") == 0) || 
							        (strcmp(icar_type,"32") == 0) || (strcmp(icar_type,"34") == 0) || (strcmp(icar_type,"35") == 0)))
								{
									strcpy(fcar_class_p,"3");
								}

								if(strncmp(ibrand_78,"01",2) == 0)
								{
									strcpy(foil_electric,"1"); /*�q��*/
								}
								else
								{
									strcpy(foil_electric,"0"); /*�o��*/
								}

								$SELECT iproduct 
								   INTO $iproduct
								   FROM ca_provision_product
								  WHERE iprovision = $iins_type
								    AND iins_type  = $iins_main
								    AND fclass     = $fcar_class_p
									AND foil_electric = $foil_electric;
								printf("SQLCODE[%d] iproduct[%s] \n",SQLCODE,iproduct);
								if (SQLCODE == SQLNOTFOUND)
								{
									if(strcmp(iins_type,"J") == 0)
									{
										$SELECT iproduct 
										   INTO $iproduct
									       FROM ca_provision_product
									      WHERE iprovision = $iins_type
									        AND iins_type  = $iins_main
									        AND fclass     = '0'
									        AND icar_type  = $icar_type_ori
											AND foil_electric = $foil_electric;
									}
									else
									{
										$SELECT iproduct 
										   INTO $iproduct
									       FROM ca_provision_product
									      WHERE iprovision = $iins_type
									        AND iins_type  = $iins_main
									        AND fclass     = '0'
									        AND icar_type  = $icar_type
											AND foil_electric = $foil_electric;	
								    }
								    printf("SQLCODE[%d] iproduct[%s] \n",SQLCODE,iproduct);
									if (SQLCODE == SQLNOTFOUND)
									{
										if (strcmp(iins_type,"Z") == 0)
											strcpy(iproduct,"122111961011");
										else 
										strcpy(iproduct,"000000000000");
									}
									else
									{
										strcpy(iproduct,trim(iproduct));
										strcat(iproduct,"11");
									}
								}
								else
								{
									strcpy(iproduct,trim(iproduct));
									strcat(iproduct,"11");
								}
							}
							iproduct[13] = '\0';
							strcat(prtstr,iproduct);
						}
						else
						{
							if ((strlen(rtrim(iproduct))) == 0)
							{
								if((strncmp(icar_type,"01",2) == 0)||(strncmp(icar_type,"02",2) == 0 ))
								{
									sprintf(fcar_class,"");
								}
								
								$EXECUTE Acur INTO $iproduct USING $iins_type,$fcar_class;
								if (SQLCODE==SQLNOTFOUND) strcpy(iproduct," ");
								
								iproduct[13] = '\0';
								if ((strlen(rtrim(iproduct))) == 0) strcat(prtstr,"000000000000");
								else
								{
									strcat(prtstr,iproduct);
								}
							}
							else
							{
								iproduct[13] = '\0';
								strcat(prtstr,iproduct);
							}
							strcpy(iproduct_bef,iproduct);
						}
						strcpy(t_iproduct,iproduct);
	
						strncpy(iproduct_tmp,iproduct+3,2);	
						iproduct_tmp[2] = '\0';
						printf("iproduct_tmp[%s] \n",iproduct_tmp);
						printf("mprem_prov[%d],mprem_pure_prov[%d]\n",mprem_prov,mprem_pure_prov);
						if (strcmp(iproduct_tmp,"10") == 0) 
						{
							if (((strcmp(iedr_type, "20") == 0) || (strcmp(iedr_type, "77") == 0)) && twice_20_77 == 1)
							{
								mprem_10 += mins_premium_tot;
								mprem_pure_10 += mprem_pure_prov_tot;
							}
							else if (((strcmp(iedr_type, "20") == 0) || (strcmp(iedr_type, "77") == 0)) && twice_20_77 == 2)
							{
								mprem_10 += mins_premium_tot;
								mprem_pure_10 += mprem_pure_prov_tot;
							}
							else if (cnt_iins_main_dtl == 1)
							{
								mprem_10 += mins_premium_tot;
								mprem_pure_10 += mprem_pure_prov_tot;
							}
							else 
							{ 
								mprem_10 += mprem_prov;
								mprem_pure_10 += mprem_pure_prov;
							}
						}
						else if (strcmp(iproduct_tmp,"11") == 0) 
						{
							if (((strcmp(iedr_type, "20") == 0) || (strcmp(iedr_type, "77") == 0)) && twice_20_77 == 1)
							{
								mprem_11 += mins_premium_tot;
								mprem_pure_11 += mprem_pure_prov_tot;
							}
							else if (((strcmp(iedr_type, "20") == 0) || (strcmp(iedr_type, "77") == 0)) && twice_20_77 == 2)
							{
								mprem_11 += mins_premium_tot;
								mprem_pure_11 += mprem_pure_prov_tot;
							}
							else if (cnt_iins_main_dtl == 1)
							{
								mprem_11 += mins_premium_tot;
								mprem_pure_11 += mprem_pure_prov_tot;
							}
							else 
							{ 
								mprem_11 += mprem_prov;
								mprem_pure_11 += mprem_pure_prov;
							}
						}
						else if (strcmp(iproduct_tmp,"12") == 0) 
						{
							if (((strcmp(iedr_type, "20") == 0) || (strcmp(iedr_type, "77") == 0)) && twice_20_77 == 1)
							{
								mprem_12 += mins_premium_tot;
								mprem_pure_12 += mprem_pure_prov_tot;
							}
							else if (((strcmp(iedr_type, "20") == 0) || (strcmp(iedr_type, "77") == 0)) && twice_20_77 == 2)
							{
								mprem_12 += mins_premium_tot;
								mprem_pure_12 += mprem_pure_prov_tot;
							}
							else if (cnt_iins_main_dtl == 1)
							{
								mprem_12 += mins_premium_tot;
								mprem_pure_12 += mprem_pure_prov_tot;
							}
							else 
							{ 
								mprem_12 += mprem_prov;
								mprem_pure_12 += mprem_pure_prov;
							}
						}
						else if (strcmp(iproduct_tmp,"13") == 0) 
						{
							if (((strcmp(iedr_type, "20") == 0) || (strcmp(iedr_type, "77") == 0)) && twice_20_77 == 1)
							{
								mprem_13 += mins_premium_tot;
								mprem_pure_13 += mprem_pure_prov_tot;
							}
							else if (((strcmp(iedr_type, "20") == 0) || (strcmp(iedr_type, "77") == 0)) && twice_20_77 == 2)
							{
								mprem_13 += mins_premium_tot;
								mprem_pure_13 += mprem_pure_prov_tot;
							}
							else if (cnt_iins_main_dtl == 1)
							{
								mprem_13 += mins_premium_tot;
								mprem_pure_13 += mprem_pure_prov_tot;
							}
							else 
							{ 
								mprem_13 += mprem_prov;
								mprem_pure_13 += mprem_pure_prov;
							}
						}
						else if (strcmp(iproduct_tmp,"28") == 0) 
						{
							if (((strcmp(iedr_type, "20") == 0) || (strcmp(iedr_type, "77") == 0)) && twice_20_77 == 1)
							{
								mprem_28 += mins_premium_tot;
								mprem_pure_28 += mprem_pure_prov_tot;
							}
							else if (((strcmp(iedr_type, "20") == 0) || (strcmp(iedr_type, "77") == 0)) && twice_20_77 == 2)
							{
								mprem_28 += mins_premium_tot;
								mprem_pure_28 += mprem_pure_prov_tot;
							}
							else if (cnt_iins_main_dtl == 1)
							{
								mprem_28 += mins_premium_tot;
								mprem_pure_28 += mprem_pure_prov_tot;
							}
							else 
							{ 
								mprem_28 += mprem_prov;
								mprem_pure_28 += mprem_pure_prov;
							}
						}
						cnt_iins_main_dtl = 0;
						
						printf("mprem_10[%d]\n",mprem_10);
						printf("mprem_11[%d]\n",mprem_11);
						printf("mprem_12[%d]\n",mprem_12);
						printf("mprem_13[%d]\n",mprem_13);
						printf("mprem_28[%d]\n",mprem_28);
						
						printf("-------dddddddddddrate_ym[%s]\n",drate_ym);
						/* 280-285 �O�v��I�~�� */
						if ((f_1000401==0) && (strcmp(trim(iins_type),"55")==0))
						{
							if (medrinj_cover > 400000 || medrinj_cover < 20000)
							    strcpy(drate_code,"200610");
							else if (medrinj_cover == 20000 || medrinj_cover == 40000 ||
							         medrinj_cover == 60000 || medrinj_cover == 80000 ||
							         medrinj_cover == 100000 || medrinj_cover == 200000 ||
							         medrinj_cover == 300000 || medrinj_cover == 400000)
							{
								if (medrdmg_cover == medrinj_cover * 5)
									strcpy(drate_code,"200607");
								else
									strcpy(drate_code,"200610");
							}
							else if ((medrdea_cover > 6000000) || (medrinj_cover = medrdea_cover))
							{
								strcpy(drate_code,"200607");
							}
							else
								strcpy(drate_code,"200610");
						}
						else if (strcmp(trim(iins_type),"26")==0 ||
						         strcmp(trim(iins_type),"71")==0 || strcmp(trim(iins_type),"72")==0)
							strcpy(drate_code,"200601");
						else if (strcmp(trim(iins_type),"41")==0 || strcmp(trim(iins_type),"42")==0 ||
						         strcmp(trim(iins_type),"81")==0 || strcmp(trim(iins_type),"82")==0)
							strcpy(drate_code,"200511");
						else if (strcmp(trim(iins_type),"51")==0 && strcmp(drate_ym,"16")==0)
							strcpy(drate_code,"200107");
						else if (strcmp(trim(iins_type),"30")==0 && strcmp(iins_type_develop,"33")!=0)
							strcpy(drate_code,"200107");
						else
						{
							printf("-------in CUR_DRATE_1\n");				
							$EXECUTE CUR_DRATE_1
							    INTO $drate_code
							   USING $drate_ym;
							if (SQLCODE==SQLNOTFOUND) strcpy(drate_code,"200107");
						}
						strcat(prtstr,drate_code);
						strcpy(t_drate_ym,drate_code);
						printf("-------drate_code[%s]\n",drate_code);	
						
						/* 286-291 ���~�� */
						strcpy(dendorse_c,cm_cdate_str_100(dendorse)); 
						cm_split_ymd_100(dendorse_c,dedr_yy,dedr_mm,tmp_dd);
						if (dedr_yy[0] == '\0')
						{
							strcat(prtstr,"0000");
							strcpy(t_dendorse_ym,"0000");
						}
						else
						{
						   strcat(prtstr,itoa(1911+(atoi(dedr_yy))));
						   strcpy(t_dendorse_ym,itoa(1911+(atoi(dedr_yy))));
						}
						if (dedr_mm[0] == '\0')
						{
							strcat(prtstr,"00");
							strcat(t_dendorse_ym,"00");
						}
						else
						{
							strcat(prtstr,dedr_mm);
							strcat(t_dendorse_ym,dedr_mm);
						}
						printf("[%s]\n",prtstr);
						/* 292-297  ñ��~�� */
						/*ñ��~��*/
						strcpy(ply_dpolicy_c, cm_cdate_str_100(ply_dpolicy));
						cm_split_ymd_100(ply_dpolicy_c, dpolicy_yy, dpolicy_mm, dpolicy_dd);
						
						if (dpolicy_yy[0] == '\0') 
						{
							strcat(prtstr,"0000");
							strcpy(t_dpolicy_ym,"0000");
						}
						else 
						{
							strcat(prtstr,itoa(1911+(atoi(dpolicy_yy))));
							strcpy(t_dpolicy_ym,itoa(1911+(atoi(dpolicy_yy))));
						}
						if (dpolicy_mm[0] == '\0') 
						{
							strcat(prtstr,"00");
							strcat(t_dpolicy_ym,"00");
						}
						else 
						{
							strcat(prtstr,dpolicy_mm);
							strcat(t_dpolicy_ym,dpolicy_mm);
						}
						prtstr[297] = '\0';
						
						/* 298-299 �q���O�N�� 2009.2�W�C�榡*/
						strcat(prtstr,bzfrom);
						strcpy(t_bzfrom,bzfrom);
						prtstr[299] = '\0';
						
						/* 300-307 ��ƻs�e��� */
						strcat(prtstr,ttday_yy);
						strcat(prtstr,ttday_mm);
						strcat(prtstr,ttday_dd);
						strcpy(t_dsend,ttday_yy);
						strcat(t_dsend,ttday_mm);
						strcat(t_dsend,ttday_dd);
						printf("twice_20_77[%d]\n",twice_20_77);
						prtstr[307]='\0';
						
						if (atoi(data_yyyymm) >= 202101)
						{
							strcat(prtstr,"0000000000");
						}
						prtstr[317]='\0';
						
						fprintf(fptr,"%s\n",prtstr);
						printf("--final iins_type[%s],iins_main[%s] \n",iins_type,iins_main);
						printf("prtstr[%s] \n",prtstr);
						count1++;
	
						printf("data_yyyymm[%s],ipolicy[%s],iendorse[%s],t_icompany[%s],t_iply_br[%s],t_iply[%s],t_iply_last_br[%s],t_iply_last[%s] \n",
						        data_yyyymm,ipolicy,iendorse,t_icompany,t_iply_br,t_iply,t_iply_last_br,t_iply_last);
						printf("t_iarea[%s],t_dedr_begin[%d],t_dedr_end[%d],t_iobjno[%s],t_iissue_ym[%s],t_ipro_ym[%s],t_ibrand[%s],t_icar_type_ori[%s],t_icar_type[%s],t_icar_type_no[%s] \n",
						        t_iarea,t_dedr_begin,t_dedr_end,t_iobjno,t_iissue_ym,t_ipro_ym,t_ibrand,t_icar_type_ori,t_icar_type,t_icar_type_no);
						printf("t_qcylinder[%d],t_iengine[%s],t_itag[%s],t_qpt[%d],t_fpt[%s],t_iassured[%s],t_dbirth_y[%s],t_fsex[%s],t_fmarriage[%s] \n",
						        t_qcylinder,t_iengine,t_itag,t_qpt,t_fpt,t_iassured,t_dbirth_y,t_fsex,t_fmarriage);
						printf("t_ipdmg_align[%s],t_ipbrg_align[%s],t_iplia_align[%s],t_iins_type[%s],t_iins_main[%s],t_iins_type_main[%s],t_iins_type_dtl[%s],t_iedr_type[%s],t_iins_type_dev[%s],t_iins_type_rule[%s],t_frule[%s] \n",
						        t_ipdmg_align,t_ipbrg_align,t_iplia_align,t_iins_type,t_iins_main,t_iins_type_main,t_iins_type_dtl,t_iedr_type,t_iins_type_dev,t_iins_type_rule,t_frule);
						printf("t_padjust_rate[%d],t_p_mcar_price[%d],t_pins_acc[%f],t_qdmg_acc_year[%d],t_qdmg_acc_time[%d],t_psex_age[%f],t_pdepreciate_year[%d],t_ubi_data[%s] \n",
						        t_padjust_rate,t_p_mcar_price,t_pins_acc,t_qdmg_acc_year,t_qdmg_acc_time,t_psex_age,t_pdepreciate_year,t_ubi_data);
						printf("t_iins_mult[%d],t_fmdeduct[%s],t_mdeduct[%d],t_mprem[%d],t_mprem_pure[%d],t_mprem_pure_base[%f] \n",
						        t_iins_mult,t_fmdeduct,t_mdeduct,t_mprem,t_mprem_pure,t_mprem_pure_base);
						printf("t_coefficient[%f],t_iproduct[%s],t_drate_ym[%s],t_dpolicy_ym[%s],t_bzfrom[%s],t_dsend[%s] \n",
						        t_coefficient,t_iproduct,t_drate_ym,t_dpolicy_ym,t_bzfrom,t_dsend);

						/* �d�s��� */
						sprintf(stmt,"INSERT INTO %s:ca_dev_ply_edr \
						                     (data_yyyymm,idata,ipolicy,iendorse,icompany,iply_br,iply,iply_last_br,iply_last, \
						                      iedr_br,iedr,iarea,dedr_begin,dedr_end,dply_begin,dply_end,iobjno,iissue_ym,ipro_ym,ibrand,icar_type_ori,icar_type,icar_type_no, \
						                      qcylinder,iengine,itag,qpt,fpt,iassured,dbirth_y,fsex,fmarriage, \
						                      ipdmg_align,ipbrg_align,iplia_align,iins_type,iins_main,iins_type_main,iins_type_dtl,iedr_type_ori,iedr_type,iins_type_dev,iins_type_rule,frule, \
						                      padjust_rate,p_mcar_price,pins_acc,qdmg_acc_year,qdmg_acc_time,psex_age,pdepreciate_year,ubi_data, \
						                      minjured_cover,mdeath_cover,mdamage_cover,mdamage_cover_bak,mdamage_cover_aft, \
						                      iins_mult,fmdeduct,mdeduct,mprem,mprem_pure,mprem_pure_base, \
						                      mprem_bak,mprem_pure_bak,mprem_pure_base_bak,mprem_aft,mprem_pure_aft,mprem_pure_base_aft, \
						                      coefficient,iproduct,drate_ym,dendorse_ym,dpolicy_ym,bzfrom,dsend) \
						              VALUES(?,'X',?,?,?,?,?,' ',' ', \
						                     ?,?,?,?,?,?,' ',?,?,?,?,?,?,?, \
						                     ?,?,?,?,?,?,?,?,?, \
						                     ?,?,?,?,?,?,?,?,?,?,?,?, \
						                     ?,?,?,?,?,?,?,?, \
						                     ?,?,?,?,?, \
						                     ?,?,?,?,?,?, \
						                     ?,?,?,?,?,?, \
						                     0,?,?,?,?,?,?)",list[k].dbname);
						$PREPARE insert_ply_edr FROM $stmt;
						$EXECUTE insert_ply_edr using $data_yyyymm,$ipolicy,$iendorse,$t_icompany,$t_iply_br,$t_iply,
						                              $t_iedr_br,$t_iedr,$t_iarea,$t_dedr_begin,$t_dedr_end,$t_dply_begin,$t_iobjno,$t_iissue_ym,$t_ipro_ym,$t_ibrand,$t_icar_type_ori,$t_icar_type,$t_icar_type_no,
						                              $t_qcylinder,$t_iengine,$t_itag,$t_qpt,$t_fpt,$t_iassured,$t_dbirth_y,$t_fsex,$t_fmarriage,
						                              $t_ipdmg_align,$t_ipbrg_align,$t_iplia_align,$t_iins_type,$t_iins_main,$t_iins_type_main,$t_iins_type_dtl,$t_iedr_type_ori,$t_iedr_type,$t_iins_type_dev,$t_iins_type_rule,$t_frule,
						                              $t_padjust_rate,$t_p_mcar_price,$t_pins_acc,$t_qdmg_acc_year,$t_qdmg_acc_time,$t_psex_age,$t_pdepreciate_year,$t_ubi_data,
						                              $t_minjured_cover,$t_mdeath_cover,$t_mdamage_cover,$t_mdamage_cover_bak,$t_mdamage_cover_aft,
						                              $t_iins_mult,$t_fmdeduct,$t_mdeduct,$t_mprem,$t_mprem_pure,$t_mprem_pure_base,
						                              $t_mprem_bak,$t_mprem_pure_bak,$t_mprem_pure_base_bak,$t_mprem_aft,$t_mprem_pure_aft,$t_mprem_pure_base_aft,
						                              $t_iproduct,$t_drate_ym,$t_dendorse_ym,$t_dpolicy_ym,$t_bzfrom,$t_dsend;
						   
						if (((strcmp(iedr_type, "20") == 0) || (strcmp(iedr_type, "77") == 0)) && twice_20_77 == 1)
						{cnt_iins_main = 1;}
						else 
						{cnt_iins_main = 0;}
						twice_20_77++;
						printf("twice_20_77[%d]\n",twice_20_77);
					}
				}
			}
		
	        if (count==0) continue;  /*�L�I�ة���=>�L�`�O�O��ƿ�*/
	
	        /* 99 �X�p�� */
			
			/* 1-34 */
	        prtstr[32] = '\0';
			/* 33-34 */
			strcat(prtstr, "  ");
			/* 35-50 */
			cm_split_ymd_100(dedr_begin_c,dedr_begin_yy,dedr_begin_mm,dedr_begin_dd);
			if (dedr_begin_yy[0] == '\0') strcat(prtstr,"0000");
			else strcat(prtstr,itoa (1911+ (atoi (dedr_begin_yy))));
			if (dedr_begin_mm[0] == '\0') strcat(prtstr,"00");
			else strcat(prtstr,dedr_begin_mm);
			if (dedr_begin_dd[0] == '\0') strcat(prtstr,"00");
			else strcat(prtstr,dedr_begin_dd);
	
			cm_split_ymd_100(dedr_end_c,dedr_end_yy,dedr_end_mm,dedr_end_dd);
			if (dedr_end_yy[0] == '\0') strcat(prtstr,"0000");
			else strcat(prtstr, itoa( 1911+ (atoi(dedr_end_yy))));
			if (dedr_end_mm[0] == '\0') strcat(prtstr,"00");
			else strcat(prtstr,dedr_end_mm);
			if (dedr_end_dd[0] == '\0') strcat(prtstr,"00");
			else strcat(prtstr,dedr_end_dd);
			
			/* 51-84 */
	        strcat(prtstr, sformat_trade(" ", 2, 34));
	        /* 85-89 */
	        strcat(prtstr, "00000");
	        /* 90-126 */
	        strcat(prtstr, sformat_trade(" ", 2, 37));
	        /* 127-130 */
	        strcat(prtstr, "0000");
	        /* 131-155 */
	        strcat(prtstr, sformat_trade(" ", 2, 25));
	        /* 156-157 */
	        strcat(prtstr, "99");
			/* 158-164 */
			strcat(prtstr, sformat_trade(" ", 2, 7));
			/* 165-168 */
			strcat(prtstr, "+000");
			/* 169-172 */
			strcat(prtstr, "+000");
			/* 173-174 */
			strcat(prtstr, "+0");
			/* 175-176 */
			strcat(prtstr, "+0");
			/* 177-180 */
			strcat(prtstr, "+000");
			/* 181-184 */
			strcat(prtstr, "+000");
			/* 185-192 */
			strcat(prtstr, sformat_trade(" ", 2, 8));
			/* 193-202 */
			strcat(prtstr, "+000000000");
			/* 203-212 */
			strcat(prtstr, "+000000000");
			/* 213-222 */
			strcat(prtstr, "+000000000");
			/* 223-225 */
			strcat(prtstr, "+00");
			/* 226 */
			strcat(prtstr, " ");
			/*227-233*/
			strcat(prtstr, "0000000");
			
	        /* 234-243 */
	        if (medrins_subtot < 0)
	            strcat(prtstr,"-");
	        else if (medrins_subtot > 0)
	            strcat(prtstr,"+");
	        else
	            strcat(prtstr, "+");
	        rfmtlong(medrins_subtot, "&&&&&&&&&", medrins_subtot_c);
	        strcat(prtstr, medrins_subtot_c);
			/* 244-253 */
	        if (medrpure_subtot < 0)
	            strcat(prtstr,"-");
	        else if (medrpure_subtot > 0)
	            strcat(prtstr,"+");
	        else
	            strcat(prtstr, "+");
	        rfmtlong(medrpure_subtot, "&&&&&&&&&", medrpure_subtot_c);
	        strcat(prtstr, medrpure_subtot_c);
	        /* 254-267 */
	        strcat(prtstr, "+0000000000000");
	
			/* 268-285 */
	        strcat(prtstr, sformat_trade(" ", 2, 18));
	
	        /* 286-291 */
	        strcpy(dendorse_c, cm_cdate_str_100(dendorse));
	        cm_split_ymd_100(dendorse_c, dedr_yy, dedr_mm, tmp_dd);
	        if (dedr_yy[0] == '\0') strcat(prtstr,"0000");
	          else strcat(prtstr,itoa(1911+(atoi(dedr_yy))));
	        if (dedr_mm[0] == '\0') strcat(prtstr,"00");
	          else strcat(prtstr,dedr_mm);
	
			/* 292-297 */
	       	strcpy(ply_dpolicy_c, cm_cdate_str_100(ply_dpolicy));
	        cm_split_ymd_100(ply_dpolicy_c, dpolicy_yy, dpolicy_mm, dpolicy_dd);	   
	        if (dpolicy_yy[0] == '\0') strcat(prtstr,"0000");
	       	else strcat(prtstr,itoa(1911+(atoi(dpolicy_yy))));
	        if (dpolicy_mm[0] == '\0') strcat(prtstr,"00");
	        else strcat(prtstr,dpolicy_mm);
	
			/* 298-307 */
			strcat(prtstr, sformat_trade(" ", 2, 10));
			
			if (atoi(data_yyyymm) >= 202101)
			{
				strcat(prtstr,"0000000000");
			}
	
			prtstr[317] = '\0';
	        fprintf(fptr,"%s\n",prtstr);
	        /*99�[�`���p����*/
	        /*count1++;*/
	
	        $CLOSE scur_edr_ins_a1;
		}
		$DROP TABLE prov_tmp;
		$DROP TABLE prov_tmp2;
	}
	$CLOSE scur_edr1;
	fclose(fptr);

	if (prem_total >= 0)
		rfmtlong(prem_total,"&&&&&&&&&&&&",prem_c);
	else
		rfmtlong(prem_total,"-&&&&&&&&&&&",prem_c);
	
	if (pure_total >= 0)
		rfmtlong(pure_total,"&&&&&&&&&&&&",prem_m);
	else
		rfmtlong(pure_total,"-&&&&&&&&&&&",prem_m);
	
	res = getApHome(aphome);
	if (res<0)
	{
		printf("In sigalrmcatcher func==>read config file error!!\n");
		exit(1);
	}
	
	if (count1==0)
		fprintf(fptr_err,"%s\n","�L���!!");
	else
	{
		 /* �s����� */
		 $SELECT iquota INTO $iquota FROM officer WHERE iofficer=$userid;
		
		 rtoday(&Today);     /* get today's datetime */
		
		 strcpy(Taipei_FullName,get_full_dbname("00"));
		
		 $WHENEVER SQLERROR CONTINUE;
		
		 sprintf(stmt,"DELETE FROM %s:ca_develop \
		                WHERE iclass='9996' AND ibranch=? AND data_yyyymm=?",Taipei_FullName);
		 printf("stmt[%s]\n",stmt);
		 $PREPARE insert_cus1 FROM $stmt;
		 $EXECUTE insert_cus1 USING $DBName,$data_yyyymm;
		
		 printf("  pure_total[%l]\n",pure_total);
		 sprintf(stmt,"INSERT INTO %s:ca_develop \
		                (iquota,data_yyyymm,iclass,dsend,ibranch, \
		                 product_kind,iins_class,mprem,qcnt,pure_mprem,mdrunk_pure_prem) \
		                VALUES(?,?,'9996',?,?,'99','C',?,?,?,0)",Taipei_FullName);
		 printf("stmt[%s]\n",stmt);
		 $PREPARE insert_cus2 FROM $stmt;
		 $EXECUTE insert_cus2
		    USING $iquota,$data_yyyymm,$Today,$DBName,$prem_total,$count1,$pure_total;
		    
		sprintf(stmt,"INSERT INTO %s:ca_develop \
		                (iquota,data_yyyymm,iclass,dsend,ibranch, \
                         product_kind,iins_class,mprem,qcnt,pure_mprem,mdrunk_pure_prem) \
						VALUES(?,?,'9996',?,?,'10','C',?,0,?,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus10 FROM $stmt;
		$EXECUTE insert_cus10
			USING $iquota,$data_yyyymm,$Today,$DBName,$mprem_10,$mprem_pure_10;
			
		sprintf(stmt,"INSERT INTO %s:ca_develop \
		                (iquota,data_yyyymm,iclass,dsend,ibranch, \
                         product_kind,iins_class,mprem,qcnt,pure_mprem,mdrunk_pure_prem) \
						VALUES(?,?,'9996',?,?,'11','C',?,0,?,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus11 FROM $stmt;
		$EXECUTE insert_cus11
			USING $iquota,$data_yyyymm,$Today,$DBName,$mprem_11,$mprem_pure_11;
			
		sprintf(stmt,"INSERT INTO %s:ca_develop \
		                (iquota,data_yyyymm,iclass,dsend,ibranch, \
                         product_kind,iins_class,mprem,qcnt,pure_mprem,mdrunk_pure_prem) \
						VALUES(?,?,'9996',?,?,'12','C',?,0,?,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus12 FROM $stmt;
		$EXECUTE insert_cus12
			USING $iquota,$data_yyyymm,$Today,$DBName,$mprem_12,$mprem_pure_12;
			
		sprintf(stmt,"INSERT INTO %s:ca_develop \
		                (iquota,data_yyyymm,iclass,dsend,ibranch, \
                         product_kind,iins_class,mprem,qcnt,pure_mprem,mdrunk_pure_prem) \
						VALUES(?,?,'9996',?,?,'13','C',?,0,?,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus13 FROM $stmt;
		$EXECUTE insert_cus13
			USING $iquota,$data_yyyymm,$Today,$DBName,$mprem_13,$mprem_pure_13;
			
		sprintf(stmt,"INSERT INTO %s:ca_develop \
		                (iquota,data_yyyymm,iclass,dsend,ibranch, \
                         product_kind,iins_class,mprem,qcnt,pure_mprem,mdrunk_pure_prem) \
						VALUES(?,?,'9996',?,?,'28','C',?,0,?,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus28 FROM $stmt;
		$EXECUTE insert_cus28
			USING $iquota,$data_yyyymm,$Today,$DBName,$mprem_28,$mprem_pure_28;
	}
	return SUCCESS;

errexit:
  printf("usrid=%s SOLCODE=%d sqlca.sqlerrm=%s\n",userid,SQLCODE,sqlca.sqlerrm);
  sprintf(errmsg,"userid=%s SOLCODE=%d sqlca.sqlerrm=%s",userid,SQLCODE,sqlca.sqlerrm);
  fprintf(fptr_err,"%s\n",errmsg);
  return SQLCODE;
}

long car9996_final()
{
	char sTmpMsg[1024];
	$char sfilename[81],stitle[1024],stmt[1024];
	$char DBName1[5];
	$long mprem, pure_mprem, qcnt;
	$char product_kind[3];
    
	$WHENEVER SQLERROR GOTO errexit;
	
	strcpy(DBName1,"00");
	if (db_select(DBName1) == False)  return M_CM_DB_NOTOPEN;
	
	$SELECT sum(mprem), sum(qcnt), sum(pure_mprem)
	   INTO $mprem, $qcnt, $pure_mprem
	   FROM ca_develop
	  WHERE iclass = '9996' AND product_kind = '99'
	    AND data_yyyymm  = $data_yyyymm;

	sprintf(sTmpMsg, "%s%s\n", "���ɧ���:", file_catalog);
	sprintf(sTmpMsg, "%s�O�O=[%d] �«O�O=[%d] ����=[%d]\n",sTmpMsg, mprem, pure_mprem, qcnt );
	
	/*29�I���p�p����*/
	sprintf(stmt,"SELECT product_kind, sum(mprem), sum(qcnt), sum(pure_mprem) \
	                FROM ca_develop \
	               WHERE iclass = '9996' AND product_kind <> '99' AND data_yyyymm = '%s' and dsend > '01/01/2022' \
	               GROUP BY product_kind order by 1",data_yyyymm);
	$PREPARE pre_29_kind1 FROM $stmt;
	$DECLARE cur_29_kind2 CURSOR FOR pre_29_kind1;
	$OPEN cur_29_kind2;
	while (1)
	{
		$FETCH cur_29_kind2 INTO $product_kind ,$mprem, $qcnt, $pure_mprem;
		if (SQLCODE == SQLNOTFOUND) break;
		sprintf(sTmpMsg, "%s�I��=[%s] �O�O=[%d] �«O�O=[%d] ����=[%d]\n",sTmpMsg, product_kind, mprem, pure_mprem, qcnt );
	}

	EWRITE(userid, M_CM_OK, sTmpMsg);
	exit(SUCCESS);
	isfinish(rtncode);

errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

int DiffMonth(d1,d2)    /* input data should be date format */
long d1, d2;
{
    short mdy1[3], mdy2[3];
    int datediff=0;

    rjulmdy(d1,mdy1);
    rjulmdy(d2,mdy2);
    datediff=(mdy1[2]*12+mdy1[0])-(mdy2[2]*12+mdy2[0]);
    printf("DiffMonth-mdy1[2][%d]mdy1[1][%d]mdy1[0][%d]\n",mdy1[2],mdy1[1],mdy1[0]);
    printf("DiffMonth-mdy2[2][%d]mdy2[1][%d]mdy2[0][%d]\n",mdy2[2],mdy2[1],mdy2[0]);
    printf("datediff[%d]\n",datediff);
    if (datediff<0) datediff=0;
    return datediff;
}