/************************************************/
/*                                              */
/*   PROGRAM : ca217m01s.ec by sylvia           */
/*                                              */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"
$include sqlca;
$include "var_length.h";


long car217(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car217_single_query(),car217_multiple_query();
 char *get_car_full_db();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'E':rtncode=car217_get_error_code(reply);
           break;
  case 'Q':
           rtncode=car217_single_query(reply);
           break;
  case 'M':
           rtncode=car217_multiple_query(reply);
           break;

  case 'U':rtncode=car217_update_exec(reply,command,com_len);
           break;
  default :
           if(exitsub(reply,M_CM_WRONG_OPTION) == True)
             return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}


/*-----------------------------------------------------------------*/
long car217_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
    $char DBName[5];
    char   option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
    int    tmp_len,raw_len;
    long   dummy;
    long   MsgCode;
    char   tmp_buf[20];
    long   tmp_long;
    $int   icnt = 0,row_guid;
   

    $char old_itag[CA_TAG_NUM], old_iassured[11], old_icard[18], old_dply_begin[11], 
          old_dply_end[11], old_dchange_date[11], old_dsend_date[11], old_ierror_code[2], 
          old_err_msg[91], old_fstatus[2], old_iendorse[21], old_nremark[201], 
          old_icreate[11], old_ncreate[11], old_dcreate[21], old_iupdate[11], 
          old_nupdate[11], old_dupdate[21], old_dtrade[11], old_ipolicy[21],
          old_sno[11];
          
    $char itag[CA_TAG_NUM], iassured[11], icard[18], dply_begin[11], dply_end[11], 
          dchange_date[11], dsend_date[11], ierror_code[2], err_msg[91], 
          fstatus[2], iendorse[21], nremark[201], icreate[11], ncreate[11],
          dcreate[21], iupdate[11], nupdate[11], dupdate[21], dtrade[11], 
          ipolicy[21],userid[11],sno[11];
          

    comm = (char *) command;
    cm_buf_init(command);
    cm_buf_get("%c %s", &option, DBName);

    $WHENEVER SQLERROR GOTO errexit;

    if(db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    memcpy(&raw_len,&comm[com_len],sizeof(int));
    pos = &comm[com_len+sizeof(int)];
    raw_ptr = malloc(raw_len);
    if (raw_ptr != (char*)0)
     memcpy(raw_ptr,pos,raw_len);
    else
     {
      if(exitsub(reply,M_CM_NOT_MALLOC) == True)
	  {
	   free(raw_ptr);
       return M_CM_NOT_MALLOC;
	  }
      else
      {
      	free(raw_ptr);
       	return apiRC;
      } 
     }
    printf("raw_ptr[%s]\n", raw_ptr);

    cm_buf_init(raw_ptr);
    cm_buf_get("%l %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
    &dummy, old_itag, old_iassured, old_icard, old_dply_begin, old_dply_end,
    old_dchange_date, old_dsend_date, old_ierror_code, old_err_msg, old_ipolicy,
    old_fstatus, old_iendorse, old_nremark, old_icreate, old_ncreate,
    old_dcreate, old_iupdate, old_nupdate, old_dupdate, old_dtrade, old_sno);


    $BEGIN WORK;

    $SELECT COUNT(*) INTO $icnt
        FROM ca_trade_crjcm
        WHERE ipolicy = $old_ipolicy
          AND dupdate = $old_dupdate
          AND row_guid = $old_sno;

    if (icnt == 0)
    {
        $ROLLBACK WORK;
        if(exitsub(reply,M_CM_NOT_EQUAL) == True)
            return M_CM_NOT_EQUAL;
        else
            return apiRC;
    }

    
    cm_buf_init(command);
    cm_buf_get("%c %s %s %s %s %s %s %s %s ",
    	        &option, DBName, ipolicy, sno, fstatus, iendorse, nremark, dupdate, userid);

    printf("ipolicy=[%s]  sno=[%s]\n",ipolicy,sno);
    printf("fstatus=[%s]  iendorse=[%s]\n",fstatus,iendorse);
    printf("userid=[%s]  dupdate=[%s]\n",userid,dupdate);
    printf("nremark=[%s]  \n",nremark);
    
    row_guid = atoi(sno);
    strcpy(iendorse, trim(iendorse));
    if (strlen(iendorse) == 0)
        strcpy(iendorse," ");
        
    strcpy(nremark, trim(nremark));
    if (strlen(nremark) == 0)
        strcpy(nremark," ");
    

    $UPDATE ca_trade_crjcm
        SET fstatus = $fstatus,  
            iendorse = $iendorse,
            nremark = $nremark,
            iupdate = $userid,
            dupdate = current
      WHERE row_guid = $row_guid;

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    tmp_len = cm_buf_len(ReplyBuf);

     if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
     {
         $WHENEVER SQLERROR CONTINUE;
         $ROLLBACK WORK;
         return apiRC;
     }

     $WHENEVER SQLERROR GOTO errexit;
     $COMMIT WORK;
     return api_OKComplete;
    
    
errexit:
    MsgCode = SQLCODE;
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if( SQLCODE != 0) MsgCode = SQLCODE;
    return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

/*----------------------------------------------------------------------------*/

long car217_single_query(reply)
serverReply reply;
{
    $char DBName[5],ipolicy[21],sno[11];

    int tmp_len,lenErr,icnt,i,x;
    

    $char itag[CA_TAG_NUM], iassured[11], icard[18], dply_begin[11], dply_end[11], 
          dchange_date[11], dsend_date[11], ierror_code[2], err_msg[91], 
          fstatus[2], iendorse[21], nremark[201], icreate[11], ncreate[11],
          dcreate[21], iupdate[11], nupdate[11], dupdate[21], dtrade[11];
    $char sFullDBName[25], stmp1[1500];
    $int  row_guid;
    $long mcover = 0;
    
    cm_buf_get("%s %s %s",DBName,ipolicy,sno);

    row_guid = atoi(sno);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
        else
            return apiRC;
    }
    

    strcpy(sFullDBName, get_car_full_db(ipolicy));
    printf("220:sFullDBName=[%s]\n",sFullDBName);

    sprintf_s(stmp1, sizeof stmp1,
        "SELECT a.itag, a.iassured, a.icard, a.dply_begin, a.dply_end,  "
                "a.dchange_date, a.dsend_date, a.ierror_code,  "
                "(select trim(chiname)||trim(engname) from car_code  "
                "  where kind = 'T2' and (detail = a.ierror_code or detail2 = a.ierror_code)) ,  "
                "a.ipolicy, a.fstatus, a.iendorse, a.nremark, a.icreate, c.nname ,  "
                "a.dcreate, a.iupdate, a.dupdate, date(a.dcreate),  "
                "(select mdamage_cover from %s:ply_ins_type where ipolicy = a.ipolicy)  "
          "FROM ca_trade_crjcm a, officer c  "
          "WHERE a.icreate = c.iofficer  "
            "and a.ipolicy = '%s' and a.row_guid = %d ", sFullDBName,ipolicy,row_guid );
            
    printf("--- stmp1 = [%s] \n",stmp1);        
    $PREPARE ply_s1 FROM $stmp1;
    $DECLARE cur_s1 CURSOR FOR ply_s1;
    $OPEN    cur_s1;
    $FETCH   cur_s1 INTO $itag, $iassured, $icard, $dply_begin, $dply_end, 
                         $dchange_date, $dsend_date, $ierror_code, $err_msg, $ipolicy, 
                         $fstatus, $iendorse, $nremark, $icreate, $ncreate,
                         $dcreate, $iupdate, $dupdate, $dtrade, $mcover;
    
    if(SQLCODE==SQLNOTFOUND)
    {
        if(exitsub(reply,M_CM_NOT_FOUND) == True)       /*?*/
            return M_CM_NOT_FOUND;                        /*?*/
        else
            return apiRC;
    }
    
    $CLOSE   cur_s1;
    $FREE    cur_s1;
    
    
    
    
    strcpy(dtrade, cm_from_infdate_100(dtrade));
    
    
    if (strcmp(iupdate,"sys_upd") == 0)
        strcpy(nupdate,"�t�Φ^��");
    else
    {
    
        $select nname into $nupdate
          from officer
         where iofficer = $iupdate;
    }

    
    printf("**********************************************\n");
    printf("itag=[%s]\n",itag);
    printf("iassured=[%s]\n",iassured);
    printf("icard=[%s]\n",icard);
    printf("dply_begin=[%s]\n",dply_begin);
    printf("dply_end=[%s]\n",dply_end);
    printf("dchange_date=[%s]\n",dchange_date);
    printf("dsend_date=[%s]\n",dsend_date);
    printf("ierror_code=[%s]\n",ierror_code);
    printf("err_msg=[%s]\n",err_msg);
    printf("ipolicy=[%s]\n",ipolicy);
    printf("fstatus=[%s]\n",fstatus);
    printf("iendorse=[%s]\n",iendorse);
    printf("nremark=[%s]\n",nremark);
    printf("icreate=[%s]\n",icreate);
    printf("ncreate=[%s]\n",ncreate);
    printf("dcreate=[%s]\n",dcreate);
    printf("iupdate=[%s]\n",iupdate);
    printf("nupdate=[%s]\n",nupdate);
    printf("dupdate=[%s]\n",dupdate);
    printf("dtrade=[%s]\n",dtrade);
    printf("sno=[%s]\n",sno);
    printf("mcover=[%ld]\n",mcover);
    printf("**********************************************\n");
        
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %s %s %s %s", M_CM_OK, itag, iassured, icard, dply_begin, dply_end);
    cm_buf_put("%s %s %s %s %s", dchange_date, dsend_date, ierror_code, err_msg, ipolicy);
    cm_buf_put("%s %s %s %s %s", fstatus, iendorse, nremark, icreate, ncreate);
    cm_buf_put("%s %s %s %s %s ", dcreate, iupdate, nupdate, dupdate, dtrade);
    cm_buf_put("%s %l ", sno, mcover);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

  errexit:
     if(exitsub(reply,SQLCODE) == True)
        return SQLCODE;
     else
        return apiRC;
}

long car217_multiple_query(reply)
serverReply reply;
{
    $char DBName[5],sDate1[11],sDate2[11],ipolicy3[5],fstatus[2],userid[11];
    $char Date_bgn[11],Date_end[11], iquota[5];
    $char ipolicy[21],icard[21],ierror_code[2], dcreate[11];
    $char stmt1[1000], stmt2[100], stmt3[100], stmt4[100];
    $char dtrade[11],itag[CA_TAG_NUM];
    $int  guid = 0;

    char tmpbuf[4000];
    int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
    int i,total_count=0;

    cm_buf_get("%s %s %s %s %s %s %s %s %s",
    DBName,sDate1,sDate2,ipolicy3,fstatus,userid,ipolicy,icard,itag);

    strcpy(Date_bgn, cm_to_infdate(sDate1));
    strcpy(Date_end, cm_to_infdate(sDate2));
    printf("Date_bgn=[%s]Date_end=[%s]\n",Date_bgn,Date_end);
    strcpy(userid, trim(userid));
    strcpy(ipolicy, trim(ipolicy));
    strcpy(icard, trim(icard));


    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
        else
            return apiRC;
    }
    
    /* �������p */
    if (strcmp(fstatus,"*") == 0)
        strcpy(stmt2," ");
    else
        sprintf_s(stmt2, sizeof stmt2,"and fstatus = '%s' ",fstatus);
        
    
    /* ���P */
    if (itag[0] == ' ')
        sprintf_s(stmt3, sizeof stmt3,"and itag  = '%s' ",itag);
    else
        sprintf_s(stmt3, sizeof stmt3,"and itag matches '%s' ",itag);
        
    /* �~�Z��� */
    $select iquota[1,4] into $iquota from officer where iofficer = $userid;    
    if (strcmp(iquota,"3201") == 0)
        strcpy(stmt4," ");
    else
        sprintf_s(stmt4, sizeof stmt4,"and ipolicy[1,2] in (select ibranch from branch where iupcomp = '%s') ",DBName);
        /*sprintf_s(stmt4, sizeof stmt4,"and ipolicy[1,2] in (select iply_branch from sa_branch_type where iupcomp = '%s') ",DBName);*/
    
    sprintf_s(stmt1, sizeof stmt1,
        "select date(dcreate), ipolicy, icard, ierror_code, fstatus, row_guid  "
         " from ca_trade_crjcm a  "
         "where date(dcreate) between '%s' and '%s'  "
         " and ipolicy matches '%s' and ipolicy[1,3] matches '%s'  "
         " and icard matches '%s' %s %s %s  "
         "order by ipolicy",Date_bgn,Date_end,ipolicy,ipolicy3,icard, stmt2,stmt3,stmt4 );

    printf("stmt1=[%s]\n",stmt1);
    $PREPARE pre_m1 FROM $stmt1;
    $DECLARE cur_m1 CURSOR for pre_m1;
    $OPEN cur_m1;
    for(;;)
    {
        $FETCH cur_m1 into $dcreate, $ipolicy, $icard, $ierror_code, $fstatus,
                           $guid;
        if (SQLCODE == SQLNOTFOUND) break;

        strcpy(dtrade, cm_from_infdate_100(dcreate));   /* ����CYY/MM/DD */
        
        cm_buf_init(tmpbuf);
        if ( count == 0 )
        {
            cm_buf_res_msg();             /* reserve for MsgCode and count */
            cm_buf_res_count();
        }
        cm_buf_put("%s %s %s %s %s %d",dtrade, ipolicy, icard, ierror_code, fstatus ,guid);
        tmp_len = cm_buf_len(tmpbuf);
        if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
        {
            memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
            repbuf_len += tmp_len;
            count++;
        }
        else                               /* more than 4K, send to client side */
        {
            cm_buf_init(ReplyBuf);
            cm_buf_put_msg(M_CM_OK);
            cm_buf_put_count(count);
            if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
            {
                $CLOSE cur_m1;
                return apiRC;
            }
            else               /* clear ReplyBuf and count to start all over again */
            {
                replycnt++;
                if (replycnt == 30)   /* more than 30K, client cannot display,error */
                {
                    cm_buf_init(ReplyBuf);
                    cm_buf_put("%l",M_CM_OUT_SPACE);
                    tmp_len = cm_buf_len(ReplyBuf);
                    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
                        return apiRC;
                    return M_CM_OUT_SPACE;
                }
                ReplyBuf[0] = '\0';
                count = 0;
                cm_buf_init(ReplyBuf);
                cm_buf_res_msg();           /* reserve for MsgCode and count */
                cm_buf_res_count();
                cm_buf_put("%s %s %s %s %s %d",dtrade, ipolicy, icard, ierror_code, fstatus ,guid);
                repbuf_len = cm_buf_len(ReplyBuf);
                count++;
            }
        }
    } /* for loop */

    $CLOSE cur_m1;
    $FREE cur_m1;
    
    if (count > 0)   /* break out, at least one record is selected */
    {
        cm_buf_init(ReplyBuf);
        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(count);
        if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
            return apiRC;
        return api_OKComplete;
    }
    else            /* break out, not any row is found */
    {
        if(exitsub(reply,M_CM_NOT_FOUND) == True)             
            return M_CM_NOT_FOUND;                            
        else
        return apiRC;
    }

 errexit:
   if(exitsub(reply,SQLCODE) == True)
     return SQLCODE;
   else
     return apiRC;
}

/* ���~�T���C�� */
long car217_get_error_code(reply)
serverReply reply;
{
    $char DBName[5];
    $char err_msg[90],stype[2];
    
    char tmpbuf[4000];
    int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
    int i,total_count=0;

    cm_buf_get("%s",DBName);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
        else
            return apiRC;
    }

    $DECLARE cur_msg1 CURSOR FOR
     SELECT 'P', trim(detail)||'�G'||trim(chiname)||trim(engname)
       INTO $stype, $err_msg
       FROM car_code
      WHERE kind = 'T2'
      union all 
     SELECT 'E', trim(detail2)||'�G'||trim(chiname)||trim(engname)
       INTO $stype, $err_msg
       FROM car_code
      WHERE kind = 'T2';

     $OPEN cur_msg1;
     for(;;)
     {
        $FETCH cur_msg1;
        if (SQLCODE != 0) break;

        cm_buf_init(tmpbuf);
        if ( count == 0 )
        {
            cm_buf_res_msg();             /* reserve for MsgCode and count */
            cm_buf_res_count();
        }
        cm_buf_put("%s %s",stype, err_msg);
        tmp_len = cm_buf_len(tmpbuf);
        if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
        {
            memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
            repbuf_len += tmp_len;
            count++;
        }
        else                               /* more than 4K, send to client side */
        {
            cm_buf_init(ReplyBuf);
            cm_buf_put_msg(M_CM_OK);
            cm_buf_put_count(count);
            if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
            {
                $CLOSE cur_msg1;
                return apiRC;
            }
            else               /* clear ReplyBuf and count to start all over again */
            {
                replycnt++;
                if (replycnt == 30)   /* more than 30K, client cannot display,error */
                {
                    cm_buf_init(ReplyBuf);
                    cm_buf_put("%l",M_CM_OUT_SPACE);
                    tmp_len = cm_buf_len(ReplyBuf);
                    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
                        return apiRC;
                    return M_CM_OUT_SPACE;
                }
                ReplyBuf[0] = '\0';
                count = 0;
                cm_buf_init(ReplyBuf);
                cm_buf_res_msg();           /* reserve for MsgCode and count */
                cm_buf_res_count();
                cm_buf_put("%s %s",stype, err_msg);
                repbuf_len = cm_buf_len(ReplyBuf);
                count++;
            }
        }
    } /* for loop */

    $CLOSE cur_msg1;
    if (count > 0)   /* break out, at least one record is selected */
    {
        cm_buf_init(ReplyBuf);
        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(count);
        if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
            return apiRC;
        return api_OKComplete;
    }
    else            /* break out, not any row is found */
    {
        if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
            return M_CM_NOT_FOUND;                               /*?*/
        else
        return apiRC;
    }

 errexit:
   if(exitsub(reply,SQLCODE) == True)
     return SQLCODE;
   else
     return apiRC;
}

char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  char sTmp_db_name[31];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
  }
  printf("sTmp_db_name[%s]\n",sTmp_db_name);
  return sTmp_db_name;
}
