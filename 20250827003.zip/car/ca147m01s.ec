/**********************************************************************/
/*                                                                    */
/*   program id   : ca147m01s.ec                                      */
/*   program name : ���I�K�Q�ө�ú�ڦ۰���O�]�w���@�@�~              */
/*   date written : 2008/02                                           */
/*   author       : Ken                                               */
/**********************************************************************/


#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "carmsgs.h"
$include sqlca;
#include "safeclib.h"

typedef struct {
    char   officer_type[2];
    char   iofficer[11];
} car147_officer_t;

        
long car147(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{  
    long car147_insert(),car147_single_query(),car147_multiple_query(),
	   	 car147_update_exec();
    char option;
    long rtncode;
    
    cm_buf_init(command);
    cm_buf_get("%c",&option);
    switch(option)
    {
/*     case '1':
              rtncode=car147_ply_query(reply);
              break;*/
       case 'A':
                rtncode=car147_insert(reply);
                break;
       case 'Q':
                rtncode=car147_single_query(reply);
                break;
       case 'M':
                rtncode=car147_multiple_query(reply);
                break;
       case 'D':
       case 'U':
                rtncode=car147_update_exec(reply,command,com_len);
                break;
       case 'G':rtncode=Get_project_list(reply);  		
                break;	                
       default :
                if(exitsub(reply,M_CM_WRONG_OPTION) == True)
                  return M_CM_WRONG_OPTION;
                return apiRC;
    }
    return(rtncode);
}

long car147_insert(reply)
serverReply reply;
{
  $char DBName[5]; 
   long MsgCode;
   int tmp_len;
   int i, j, is_add_fail=0, api_f;  
  $char stmt_buf[1024];
  $char icode_no[11], icode_name[51], inote[256], dbegin[11], dend[11], fcomp_disc[2] ,tmp_mcomp_disc[13] ,tmp_mcomp_disc_mot1[13] ,tmp_mcomp_disc_mot2[13] ,fvol_disc[2] ,tmp_pvol_disc[13] ,tmp_pvol_disc_mot1[13] ,tmp_pvol_disc_mot2[13], fmot_insure[3], fcar_insure[3],iupdate[11], dupdate[21];
  $char dbegin_ch[10],dend_ch[10];
  
  dec_t dec_mcomp_disc,dec_pvol_disc;
  dec_t dec_mcomp_disc_mot1,dec_mcomp_disc_mot2,dec_pvol_disc_mot1,dec_pvol_disc_mot2;
  $double mcomp_disc,mcomp_disc_mot1,mcomp_disc_mot2,pvol_disc,pvol_disc_mot1,pvol_disc_mot2;
  
  $char fgen302file1[2],fgen302file2[2];
  $char officer_type[2],iofficer[11];
   
   $long cnt_chk=0;
  int k,rows=0;
  
  car147_officer_t *alist_officer;
  
  cm_buf_get("%s",DBName);
  
  $WHENEVER SQLERROR GOTO errexit; 
  
  if (db_select(DBName) == False)
  {
    if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }

  cm_buf_get("%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
  icode_no, icode_name, inote, dbegin_ch,dend_ch, fcomp_disc ,tmp_mcomp_disc,tmp_mcomp_disc_mot1,tmp_mcomp_disc_mot2 ,fvol_disc ,tmp_pvol_disc,tmp_pvol_disc_mot1,tmp_pvol_disc_mot2, fmot_insure, fcar_insure,fgen302file1,fgen302file2,iupdate); 
 

  $BEGIN WORK;
  
  printf("icode_no[%s]\n" , icode_no);
  printf("tmp_mcomp_disc[%s]\n" , tmp_mcomp_disc);    
  printf("tmp_mcomp_disc_mot1[%s]\n" , tmp_mcomp_disc_mot1);    
  printf("tmp_mcomp_disc_mot2[%s]\n" , tmp_mcomp_disc_mot2);    
  printf("tmp_pvol_disc[%s]\n" , tmp_pvol_disc);    
  printf("iupdate[%s]\n" , iupdate);    

  /* string to double */
  deccvasc( tmp_mcomp_disc, strlen(tmp_mcomp_disc), &dec_mcomp_disc);
  deccvasc( tmp_mcomp_disc_mot1, strlen(tmp_mcomp_disc_mot1), &dec_mcomp_disc_mot1);
  deccvasc( tmp_mcomp_disc_mot2, strlen(tmp_mcomp_disc_mot2), &dec_mcomp_disc_mot2);
  
  dectodbl( &dec_mcomp_disc, &mcomp_disc);    
  dectodbl( &dec_mcomp_disc_mot1, &mcomp_disc_mot1);    
  dectodbl( &dec_mcomp_disc_mot2, &mcomp_disc_mot2);    
  
  deccvasc( tmp_pvol_disc, strlen(tmp_pvol_disc), &dec_pvol_disc);
  deccvasc( tmp_pvol_disc_mot1, strlen(tmp_pvol_disc_mot1), &dec_pvol_disc_mot1);
  deccvasc( tmp_pvol_disc_mot2, strlen(tmp_pvol_disc_mot2), &dec_pvol_disc_mot2);
  dectodbl( &dec_pvol_disc, &pvol_disc);
  dectodbl( &dec_pvol_disc_mot1, &pvol_disc_mot1);
  dectodbl( &dec_pvol_disc_mot2, &pvol_disc_mot2);
  
  strcpy(dbegin,cm_to_infdate(dbegin_ch));
  strcpy(dend,cm_to_infdate(dend_ch));

  printf("dbegin[%s]\n" , dbegin);
  printf("dend[%s]\n" , dend);

  printf("mboramt_proj[%f]\n" , mcomp_disc);    
  printf("mcomp_disc_mot1[%f]\n" , mcomp_disc_mot1);    
  printf("mcomp_disc_mot2[%f]\n" , mcomp_disc_mot2);    
  printf("pboramt_proj[%f]\n" , pvol_disc);    
  printf("pvol_disc_mot1[%f]\n" , pvol_disc_mot1);    
  printf("pvol_disc_mot2[%f]\n" , pvol_disc_mot2);    
    
      
  cm_buf_get("%d",&rows); /* rows of officer  */	
  alist_officer = (car147_officer_t *) malloc(rows *sizeof (car147_officer_t));
    
  for (k = 0; k <rows; k++)
  {	   
      cm_buf_get("%s %s", officer_type,iofficer);
       			
   	  strcpy(alist_officer[k].officer_type,officer_type);
   	  strcpy(alist_officer[k].iofficer,iofficer);
  }		      

  /* update car302_barcode_setup */
  sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO sysdb:car302_barcode_setup "
    " (icode_no, icode_name, inote, dbegin, dend, fcomp_disc , mcomp_disc, mcomp_disc_mot1, mcomp_disc_mot2 ,fvol_disc , pvol_disc, pvol_disc_mot1, pvol_disc_mot2, fmot_insure, fcar_insure,fgen302file1,fgen302file2,iupdate,dupdate) "
    "   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,current)");
  printf("Insert car302_barcode_setup stmt_buf[%s]\n" , stmt_buf);	

  $PREPARE u3_id FROM $stmt_buf;
  $EXECUTE u3_id USING 
        $icode_no, $icode_name, $inote, $dbegin, $dend, $fcomp_disc ,$mcomp_disc,$mcomp_disc_mot1,$mcomp_disc_mot2 ,$fvol_disc ,$pvol_disc,$pvol_disc_mot1,$pvol_disc_mot2, $fmot_insure, $fcar_insure,$fgen302file1,$fgen302file2,$iupdate ;
  
  printf("INSERT car302_barcode_setup:sqlca.sqlerrd[2][%d]\n" , sqlca.sqlerrd[2]);  
  if (sqlca.sqlerrd[2]==0){ /*�S����ƳQ���*/
	        cm_buf_init(ReplyBuf);
	        cm_buf_put("%l",M_CM_ADD_FAIL);  /*MSG:3551�s�W����*/
	        tmp_len = cm_buf_len(ReplyBuf);
	        if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
	        {
	           $WHENEVER SQLERROR CONTINUE;
	           $ROLLBACK WORK;
	           return apiRC;
	        } 
  }     
  
  if (rows>0){
	  /* Inserting car302_barcode_officer */
	  printf("Inserting car302_barcode_officer ........\n");
	
	  sprintf_s(stmt_buf, sizeof stmt_buf,
	   "INSERT INTO sysdb:car302_barcode_officer(icode_no,officer_type,iofficer,iupdate,dupdate) "
	   " VALUES (?,?,?,?,current) ");
	  $PREPARE bc_officer FROM $stmt_buf;
	
	  for (k=0; k<rows; k++){
	      
	       strcpy(officer_type,alist_officer[k].officer_type);
	       strcpy(iofficer,alist_officer[k].iofficer);
	       
	       $EXECUTE bc_officer USING $icode_no,$officer_type,$iofficer,$iupdate;
	       if(SQLCODE != 0) {
	           break;
	       }
	  }
  }
  
		for (k = 0; k < rows; k++)
			free(alist_officer[k]);
		free ( (char *) alist_officer);	 
  
  cm_buf_init(ReplyBuf);
  cm_buf_put("%l",M_CM_OK);
  tmp_len = cm_buf_len(ReplyBuf);

  if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
  {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
  }

  $WHENEVER SQLERROR GOTO errexit;
  $COMMIT WORK;
  return api_OKComplete;

errexit:
   MsgCode = SQLCODE;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
     return MsgCode;
   else
     return apiRC;
}

long car147_single_query(reply)
serverReply reply;
{
 $char DBName[5],fulldbname[21];
 
 $char s_icode_no[11];
 $char icode_no[11], icode_name[51], inote[256], dbegin[11], dend[11], fcomp_disc[2] ,fvol_disc[2] , fmot_insure[3], fcar_insure[3],iupdate[11], dupdate[21];
 $char dbegin_ch[10],dend_ch[10];
 $double mcomp_disc = 0.0,mcomp_disc_mot1 = 0.0,mcomp_disc_mot2 = 0.0,pvol_disc = 0.0,pvol_disc_mot1 = 0.0,pvol_disc_mot2 = 0.0;
 $char fgen302file1[2],fgen302file2[2];
 $char officer_type[2],iofficer[11]; 
 
  int tmp_len;
 $char stmt[4096]; 
  long count = 0;

 cm_buf_get("%s",DBName );
 cm_buf_get("%s",s_icode_no );

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
       return M_CM_DB_NOTOPEN;
   else
       return apiRC;
 }
 printf("s_icode_no[%s]\n" , s_icode_no);
 
  
 $SELECT icode_no, icode_name, inote, dbegin, dend, fcomp_disc ,mcomp_disc,mcomp_disc_mot1,mcomp_disc_mot2 ,fvol_disc ,pvol_disc,pvol_disc_mot1,pvol_disc_mot2, fmot_insure, fcar_insure,fgen302file1,fgen302file2, iupdate, dupdate
    INTO $icode_no, $icode_name, $inote, $dbegin, $dend, $fcomp_disc ,$mcomp_disc, $mcomp_disc_mot1, $mcomp_disc_mot2 ,$fvol_disc ,$pvol_disc, $pvol_disc_mot1, $pvol_disc_mot2, $fmot_insure, $fcar_insure,$fgen302file1,$fgen302file2,$iupdate, $dupdate
    FROM sysdb:car302_barcode_setup 
   WHERE icode_no = $s_icode_no;
    
    
 if(SQLCODE==SQLNOTFOUND)
 {
   if(exitsub(reply,M_CM_NOT_FOUND) == True)      
       return M_CM_NOT_FOUND;                        
   else
       return apiRC;
 }
 printf("icode_no[%s]\n" , icode_no); 
 printf("dbegin[%s] dend[%s]\n" , dbegin, dend); 
 
 strcpy(dbegin_ch , cm_from_infdate_100(dbegin)); 
 strcpy(dend_ch   , cm_from_infdate_100(dend)); 
 
 printf("dbegin_ch[%s] dend_ch[%s]\n" , dbegin_ch, dend_ch);  
  
 cm_buf_init(ReplyBuf);
 cm_buf_res_msg(); 
 cm_buf_res_count(); /* for �g��N������ */
 
 cm_buf_put("%s %s %s %s %s %s %f %f %f %s %f %f %f %s %s %s %s %s %s",
 icode_no, icode_name, inote, dbegin_ch,dend_ch, fcomp_disc ,mcomp_disc,mcomp_disc_mot1,mcomp_disc_mot2 ,fvol_disc ,pvol_disc,pvol_disc_mot1,pvol_disc_mot2, fmot_insure, fcar_insure,fgen302file1,fgen302file2,iupdate,dupdate);
 
 
/*================  �g��N���]�w     =================*/
 sprintf_s(stmt, sizeof stmt,
         "SELECT officer_type,iofficer "
         "  FROM sysdb:car302_barcode_officer "
         " WHERE icode_no = '%s' "
         , s_icode_no); 

  printf("stmt[%s]\n", stmt);

  $PREPARE pre_officer FROM $stmt;
  $DECLARE cur_officer CURSOR FOR pre_officer;
  $OPEN cur_officer;
  
  count = 0; 
  while(1){
	$FETCH cur_officer INTO $officer_type,$iofficer ;
 	if(SQLCODE==SQLNOTFOUND)
	   break;

	count ++;
 	cm_buf_put("%s %s",officer_type,iofficer);
  }
  printf("count[officer]=%d\n",count);
  
  $CLOSE cur_officer;
  $FREE cur_officer; 

 cm_buf_put_msg(M_CM_OK);    
 cm_buf_put_count(count); /* for �g��N������ */
  
  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
      return apiRC;
  else
      return api_OKComplete;

errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}

long car147_multiple_query(reply)
serverReply reply;
{
	
 $char DBName[5];
 $char s_icode_no[11],s_icode_name[51];
 $char icode_no[11], icode_name[51], inote[256], dbegin[11], dend[11], fcomp_disc[2] ,fvol_disc[2] , fmot_insure[3], fcar_insure[3],iupdate[11], dupdate[21];
 $char dbegin_ch[10],dend_ch[10];

 $char buff[250];
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0;

 cm_buf_get("%s",DBName ); 
 cm_buf_get("%s",s_icode_no );
 cm_buf_get("%s",s_icode_name );
 
 
 $WHENEVER SQLERROR GOTO errexit;


 if (db_select(DBName) == False)
 {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

printf("s_icode_no[%s]\n" , s_icode_no);

 $DECLARE cur_mquery CURSOR FOR 
   SELECT icode_no,icode_name,dbegin,dend 
     FROM  sysdb:car302_barcode_setup
    WHERE icode_no matches $s_icode_no 
      AND icode_name matches $s_icode_name 
 ORDER BY icode_no ;

 $OPEN cur_mquery;
 for(;;)
 {
     $FETCH cur_mquery INTO $icode_no,$icode_name,$dbegin,$dend ;
     if (SQLCODE != 0) break;
	 printf("icode_no[%s]\n" , icode_no); 
	 printf("dbegin[%s] dend[%s]\n" , dbegin, dend); 
	 
	 strcpy(dbegin_ch , cm_from_infdate_100(dbegin)); 
	 strcpy(dend_ch   , cm_from_infdate_100(dend));      	
	 
     cm_buf_init(tmpbuf);
     if ( count == 0 )
     {
        cm_buf_res_msg();             /* reserve for MsgCode and count */
        cm_buf_res_count();
     }
     
     cm_buf_put("%s %s %s %s ",icode_no,icode_name,dbegin_ch, dend_ch );
     tmp_len = cm_buf_len(tmpbuf);
     if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
        memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
        repbuf_len += tmp_len;
        count++;
     }
     else                               /* more than 4K, send to client side */
     {
        cm_buf_init(ReplyBuf);
        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(count);
        if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
        {
           $CLOSE q_cur;
           return apiRC;
        }
        else               /* clear ReplyBuf and count to start all over again */
        {
           replycnt++;
           if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
           cm_buf_init(ReplyBuf);
           cm_buf_put("%l",M_CM_OUT_SPACE);
           tmp_len = cm_buf_len(ReplyBuf);
           if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
               return apiRC;
           return M_CM_OUT_SPACE;
         }
         ReplyBuf[0] = '\0';
         count = 0;
         cm_buf_init(ReplyBuf);
         cm_buf_res_msg();           /* reserve for MsgCode and count */
         cm_buf_res_count();         
         
         cm_buf_put("%s %s %s %s ",icode_no,icode_name,dbegin_ch, dend_ch );
         repbuf_len = cm_buf_len(ReplyBuf);
         count++;
       }
     }
  } /* for loop */

  $CLOSE cur_mquery;
  $FREE cur_mquery;
  if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
  else            /* break out, not any row is found */
  {
    if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
      return M_CM_NOT_FOUND;                               /*?*/
    else
      return apiRC;
  }

errexit:
   if(exitsub(reply,SQLCODE) == True)
     return SQLCODE;
   else
     return apiRC;
}

long car147_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
    $char DBName[5];
    
    $char icode_no_org[11], dupdate_org[21];
    $int  count_org = 0;
    
    $char icode_no[11], icode_name[51], inote[256], dbegin[11], dend[11], fcomp_disc[2] ,tmp_mcomp_disc[13],tmp_mcomp_disc_mot1[13],tmp_mcomp_disc_mot2[13] ,fvol_disc[2] ,tmp_pvol_disc[13],tmp_pvol_disc_mot1[13],tmp_pvol_disc_mot2[13],fmot_insure[3], fcar_insure[3],iupdate[11], dupdate[21];
    $char dbegin_ch[10],dend_ch[10];
    
    dec_t dec_mcomp_disc,dec_pvol_disc;
    dec_t dec_mcomp_disc_mot1,dec_mcomp_disc_mot2,dec_pvol_disc_mot1,dec_pvol_disc_mot2;     
    $double mcomp_disc,mcomp_disc_mot1,mcomp_disc_mot2,pvol_disc,pvol_disc_mot1,pvol_disc_mot2;
    
    $char fgen302file1[2],fgen302file2[2];
    
    $char officer_type[2],iofficer[11];
        
    $long cnt_chk=0;
    int k,rows=0;    
    car147_officer_t *alist_officer;
                  
    char option,*pos,*raw_ptr,cur_buf[4000],*comm;
    int tmp_len,raw_len;
    long dummy;
    long MsgCode;
    DBinfo *list;
     int i, j, is_del_fail=0, is_upd_fail=0;
    $char stmt_buf[1024];
    
    comm = (char *) command;
    cm_buf_init(command);
    cm_buf_get("%c %s ",&option,DBName);

    $WHENEVER SQLERROR GOTO errexit;

    if(db_select(DBName) == False) 
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    cm_buf_get("%s %s", icode_no_org, dupdate_org);

    printf("icode_no_org[%s], dupdate_org[%s]\n", icode_no_org, dupdate_org);

    $BEGIN WORK;

    $SELECT COUNT(*) INTO $count_org
       FROM sysdb:car302_barcode_setup
      WHERE icode_no  = $icode_no_org
        AND dupdate   = $dupdate_org;

    if (count_org == 0) /* compare 2 records, not equal */
    {
        $ROLLBACK WORK;
        if(exitsub(reply,M_CM_NOT_EQUAL) == True)
            return M_CM_NOT_EQUAL;
        else
            return apiRC;
    }
        
    if ( option == 'D' )
    {
    	           
        $DELETE FROM sysdb:car302_barcode_officer
          WHERE icode_no = $icode_no_org ;
        printf("DELETE car302_barcode_officer:sqlca.sqlerrd[2][%d]\n" , sqlca.sqlerrd[2]); 
                         	
        $DELETE FROM sysdb:car302_barcode_setup
          WHERE icode_no = $icode_no_org ;
        printf("DELETE car302_barcode_officer:sqlca.sqlerrd[2][%d]\n" , sqlca.sqlerrd[2]); 
        if (sqlca.sqlerrd[2]==0){ /*�S����ƳQ���*/
	        cm_buf_init(ReplyBuf);
	        cm_buf_put("%l",M_CM_DELETE_FAIL); /* MSG:3556�R������*/
	        tmp_len = cm_buf_len(ReplyBuf);
	        if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
	        {
	           $WHENEVER SQLERROR CONTINUE;
	           $ROLLBACK WORK;
	           return apiRC;
	        }        	
        }
         
        cm_buf_init(ReplyBuf);
        cm_buf_put("%l",M_CM_OK);
        tmp_len = cm_buf_len(ReplyBuf);
        if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
        {
           $WHENEVER SQLERROR CONTINUE;
           $ROLLBACK WORK;
           return apiRC;
        }
     
        $WHENEVER SQLERROR GOTO errexit;
        $COMMIT WORK;
        return api_OKComplete;
   }
   else if (option == 'U')
   {

      /* ��������s����� */
      printf("OPTION U: icode_no_org[%s], dupdate_org[%s]\n",
            icode_no_org, dupdate_org);

      cm_buf_get("%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
      icode_no, icode_name, inote, dbegin_ch,dend_ch, fcomp_disc ,tmp_mcomp_disc ,tmp_mcomp_disc_mot1 ,tmp_mcomp_disc_mot2 ,fvol_disc ,tmp_pvol_disc ,tmp_pvol_disc_mot1 ,tmp_pvol_disc_mot2, fmot_insure, fcar_insure,fgen302file1,fgen302file2,iupdate);     
      
   
	  printf("icode_no[%s]\n" , icode_no);
	  printf("icode_name[%s]\n" , icode_name);
	  printf("inote[%s]\n" , inote);
	  printf("dbegin_ch[%s]\n" , dbegin_ch);
	  printf("dend_ch[%s]\n" , dend_ch);
	  printf("fcomp_disc[%s]\n" , fcomp_disc);    	  
	  printf("tmp_mcomp_disc[%s]\n" , tmp_mcomp_disc);    
	  printf("tmp_mcomp_disc_mot1[%s]\n" , tmp_mcomp_disc_mot1);    
	  printf("tmp_mcomp_disc_mot2[%s]\n" , tmp_mcomp_disc_mot2);    
	  printf("fvol_disc[%s]\n" , fvol_disc);    
	  printf("tmp_pvol_disc[%s]\n" , tmp_pvol_disc);    
	  printf("tmp_pvol_disc_mot1[%s]\n" , tmp_pvol_disc_mot1);    
	  printf("tmp_pvol_disc_mot2[%s]\n" , tmp_pvol_disc_mot2);    
	  printf("fmot_insure[%s]\n" , fmot_insure);    
	  printf("fcar_insure[%s]\n" , fcar_insure);    
	  printf("iupdate[%s]\n" , iupdate);    
	  printf("fcar_insure[%s]\n" , fcar_insure);    

      printf("fgen302file1[%s]\n" , fgen302file1);    
      printf("fgen302file2[%s]\n" , fgen302file2);    

      /* string to double */    

	  deccvasc( tmp_mcomp_disc, strlen(tmp_mcomp_disc), &dec_mcomp_disc);
	  deccvasc( tmp_mcomp_disc_mot1, strlen(tmp_mcomp_disc_mot1), &dec_mcomp_disc_mot1);
	  deccvasc( tmp_mcomp_disc_mot2, strlen(tmp_mcomp_disc_mot2), &dec_mcomp_disc_mot2);  
	  dectodbl( &dec_mcomp_disc, &mcomp_disc);    
	  dectodbl( &dec_mcomp_disc_mot1, &mcomp_disc_mot1);    
	  dectodbl( &dec_mcomp_disc_mot2, &mcomp_disc_mot2);    
	  
	  deccvasc( tmp_pvol_disc, strlen(tmp_pvol_disc), &dec_pvol_disc);
	  deccvasc( tmp_pvol_disc_mot1, strlen(tmp_pvol_disc_mot1), &dec_pvol_disc_mot1);
	  deccvasc( tmp_pvol_disc_mot2, strlen(tmp_pvol_disc_mot2), &dec_pvol_disc_mot2);
	  dectodbl( &dec_pvol_disc, &pvol_disc);
	  dectodbl( &dec_pvol_disc_mot1, &pvol_disc_mot1);
	  dectodbl( &dec_pvol_disc_mot2, &pvol_disc_mot2);
      
      strcpy(dbegin,cm_to_infdate(dbegin_ch));
      strcpy(dend,cm_to_infdate(dend_ch));
      
      printf("dbegin[%s]\n" , dbegin);
      printf("dend[%s]\n" , dend);
      
      printf("mboramt_proj[%f]\n" , mcomp_disc);    
      printf("pboramt_proj[%f]\n" , pvol_disc);   
       
          
      cm_buf_get("%d",&rows); /* rows of officer  */	
	  alist_officer = (car147_officer_t *) malloc(rows *sizeof (car147_officer_t));
	    
	  for (k = 0; k <rows; k++)
	  {	   
	      cm_buf_get("%s %s", officer_type,iofficer);
	       			
	   	  strcpy(alist_officer[k].officer_type,officer_type);
	   	  strcpy(alist_officer[k].iofficer,iofficer);
	  }
    		      
      /* update car302_barcode_setup */
      printf("Updating car302_barcode_setup ........\n");
      sprintf_s(stmt_buf, sizeof stmt_buf,"UPDATE sysdb:car302_barcode_setup "
       " SET (icode_no, icode_name, inote, dbegin, dend, fcomp_disc , mcomp_disc, mcomp_disc_mot1, mcomp_disc_mot2 ,fvol_disc , pvol_disc, pvol_disc_mot1, pvol_disc_mot2, fmot_insure, fcar_insure,fgen302file1,fgen302file2,iupdate,dupdate) "
       "    = (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,current) WHERE icode_no = ? ");
      printf("Insert car302_barcode_setup stmt_buf[%s]\n" , stmt_buf);	
    	
	  $PREPARE u3_id FROM $stmt_buf;
	  $EXECUTE u3_id USING 
	        $icode_no, $icode_name, $inote, $dbegin, $dend, $fcomp_disc ,$mcomp_disc ,$mcomp_disc_mot1 ,$mcomp_disc_mot2,$fvol_disc ,$pvol_disc ,$pvol_disc_mot1 ,$pvol_disc_mot2, $fmot_insure, $fcar_insure,$fgen302file1,$fgen302file2,$iupdate ,$icode_no_org;
      
      printf("UPDATE car302_barcode_setup:sqlca.sqlerrd[2][%d]\n" , sqlca.sqlerrd[2]);  
      if (sqlca.sqlerrd[2]==0){ /*�S����ƳQ���*/
	      cm_buf_init(ReplyBuf);
	      cm_buf_put("%l",4160); /*msg:"�ť�"*/
	      tmp_len = cm_buf_len(ReplyBuf);
	      if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
	      {
	         $WHENEVER SQLERROR CONTINUE;
	         $ROLLBACK WORK;
	         return apiRC;
	      } 
      }     
            
      /* update car302_barcode_officer */
      printf("Updating car302_barcode_officer ........\n");

  	  /* �� delete */
      sprintf_s(stmt_buf, sizeof stmt_buf,
            "DELETE FROM sysdb:car302_barcode_officer WHERE icode_no = ? ");
      $PREPARE del_officer FROM $stmt_buf;
      $EXECUTE del_officer USING $icode_no_org;

      /* �A insert */
	  sprintf_s(stmt_buf, sizeof stmt_buf,
	   "INSERT INTO sysdb:car302_barcode_officer(icode_no, officer_type,iofficer,iupdate,dupdate) "
	   " VALUES (?,?,?,?,current) ");
	            
      $PREPARE bc_officer FROM $stmt_buf;

	  for (k=0; k<rows; k++){
	      
	       strcpy(officer_type,alist_officer[k].officer_type);
	       strcpy(iofficer,alist_officer[k].iofficer);
	       
	       $EXECUTE bc_officer USING $icode_no,$officer_type,$iofficer,$iupdate;
	       if(SQLCODE != 0) {
	           break;
	       }
	  }

		for (k = 0; k < rows; k++)
			free(alist_officer[k]);
		free ( (char *) alist_officer);	  
      
      cm_buf_init(ReplyBuf);
      cm_buf_put("%l",M_CM_OK);
      tmp_len = cm_buf_len(ReplyBuf);
      if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
      {
         $WHENEVER SQLERROR CONTINUE;
         $ROLLBACK WORK;
         return apiRC;
      }
      $WHENEVER SQLERROR GOTO errexit;
      $COMMIT WORK;
      return api_OKComplete;
   }
   else
   {
      MsgCode = M_CM_WRONG_OPTION;
      $WHENEVER SQLERROR CONTINUE;
      $ROLLBACK WORK;              /* rollback fail */
      if(SQLCODE != 0) MsgCode = SQLCODE;
      if(exitsub(reply,MsgCode) == True)
        return MsgCode;
      else
        return apiRC;
   }
  
 errexit:
    MsgCode = SQLCODE;
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;              /* rollback fail */
    if(SQLCODE != 0) MsgCode = SQLCODE;
    if(exitsub(reply,MsgCode) == True)
      return MsgCode;
      else
        return apiRC;
}

long Get_project_list(reply)
serverReply reply;
{
    $char DBName[5];   
    $char icode_no[11], icode_name[51];
    $char sEnd_date[11];
    int   tmp_len,cnt;
    $char iplyyear[4],iplymonth[3];
    
    cm_buf_get("%s %s %s",DBName,iplyyear, iplymonth );
    
    $WHENEVER SQLERROR GOTO errexit;
   
    if (db_select(DBName) == False)
    {
      if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
          return M_CM_DB_NOTOPEN;
      else
          return apiRC;
    }
 
    cm_buf_init(ReplyBuf);
    cm_buf_res_msg();
    cm_buf_res_count();
    sprintf_s(sEnd_date, sizeof sEnd_date,"%s/01/%d",iplymonth,atoi(iplyyear)+1911);
    
    printf("trace iplyyear[%s]\n ",iplyyear); 
    printf("trace iplymonth[%s]\n ",iplymonth);   
    printf("trace sEnd_date[%s]\n ",sEnd_date);  
    
    cnt=0;
    $DECLARE cur_1 cursor for
      SELECT icode_no,icode_name
        INTO $icode_no,$icode_name
        FROM sysdb:car302_barcode_setup
       WHERE dbegin <= $sEnd_date AND dend >= $sEnd_date;
    $OPEN    cur_1;
    
    while(1) {
        $FETCH cur_1;
        if(SQLCODE==SQLNOTFOUND) break;
       	strcpy(icode_no  ,trim(icode_no));
       	strcpy(icode_name,trim(icode_name));       
        cm_buf_put("%s %s",icode_no,icode_name);
        cnt++;
    }
    $CLOSE cur_1;
    $FREE  cur_1;
    
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(cnt);
    tmp_len = cm_buf_len(ReplyBuf);
    
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;
    
errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}