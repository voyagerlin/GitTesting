/*******************************************/
/*                                         */
/*   �j�v�������Ӫ�                        */
/*                                         */
/*   PROGRAM : ca417q02s.ec                */
/*                                         */
/*   DATE    : 92.04.11                    */
/*******************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
$include "safeclib.h";

static DBinfo  *list;
static int  count_db, i;
extern char RPTDIR[];

static char  MsgCode[50];
static char  msgbuf[100];

$static char tmp_fulldb[200], stmt[4000],stmt1[4000];
$static char DBName[05], iForm_Tp[03];
static  char  BodyFile[ N_FILE+1];
static  char  TitleFile[ N_FILE+1];
static  char  outputf[N_FILE+1];

$static int  ItemRow, TotColumn;
$static int  StartRow,TitleRow;
$static int  PgLine, Width;
$static char sMonth[3];
$static char sMonth1[3],sMonth2[3];
$static char aaa[100];
 static int fetch=0;
$static int    ipr;

static int pagenum=1;
static int linecnt=0;

$static char yymmbgn[17],yymmend[17], sTmpIbranch[3];
$static char c_yymmbgn[17],c_yymmend[17];
$static char dptbgn[3], dptend[3];
static char userid[11];
static char FormTp[N_FILE+1];
$static int  iCnt, iCnt1, iCnt2, iTot, iTot1, iTot2;
$static char iadjuster[11];

static int  max_count, errCode;
static int  tmp_len;
static int  copies;
static int miy;

$static int temp_count;
static int  max_cnt;

$static char iprocess[21],ibroker[11],dpolicy_bgn[11],dpolicy_end[11];
$static char ipolicy[21],iins_type[7];
$static double pcomm,pagent;
$static int  mdeal,mcomm_diff,magent_diff,mdeal_diff;
$static char dadjust[11],iendorse[21],ientry[11],dentry[11];
$static char dprint[11], remark[101];
$static char nchi_abv[20],nname[20];
$static char tmp_buf[20];
$char   fstatus[2];

static long car417_get_db();
static long car417_build();
static long car417_build1();
static long car417_body();
void car417_title();  
long car417_report();
static char *get_car_full_db();  /*   �ǤJ�O�渹��X���O�檺�k�ݸ�Ʈw */
/*---------------------------------------------------------------------
  fstatus 'S':  S  :���\
  fstatus 'F':  F  :����
  fstatus '3':  ' ':�L���A
  fstatus '4':  ����
  fstatus '5':  ���ͨ������
  ---------------------------------------------------------------------*/
long car417_report(sDBName,suserid,siprocess,sfstatus,soutputf)
char sDBName[5];
char suserid[11];
char siprocess[21];
char sfstatus[2];
char soutputf[N_FILE+1];
{
   int rc;
   batchinit();


   strcpy(DBName  ,sDBName);
   strcpy(userid  ,suserid);
   strcpy(iprocess,siprocess);
   strcpy(fstatus ,sfstatus);
   strcpy(outputf ,soutputf);

   printf("DBName[%s]\n",DBName);
   printf("userid[%s]\n",userid);
   printf("iprocess[%s]\n",iprocess);
   printf("fstatus[%s]\n",fstatus);
   printf("outputf[%s]\n",outputf);


   ipr = 0;
   printf("fstatus[%s]\n",fstatus);
   rc = car417_get_db();
   if (rc != SUCCESS)
       return rc;

   max_cnt=0;
   strcpy(MsgCode," ");
   printf("fstatus[%s]\n",fstatus);
   if (fstatus[0] == '5')
   {
       rc = car417_build1("A");
       if (rc != M_CM_OK)
       {
           if (MsgCode[0]==' ')
               EWRITE(userid, rc, " ");
           else
               EWRITE(userid, rc, MsgCode);
           return rc;
       }
       max_cnt=0;
       rc = car417_build1("B");
       if (rc != M_CM_OK)
       {
           if (MsgCode[0]==' ')
               EWRITE(userid, rc, " ");
           else
               EWRITE(userid, rc, MsgCode);
           return rc;
       }
   }
   else
   {
       rc = car417_build(fstatus);
       if (rc != M_CM_OK)
       {
           if (MsgCode[0]==' ')
               EWRITE(userid, rc, " ");
           else
               EWRITE(userid, rc, MsgCode);
           return rc;
       }
   }
   return rc;
}
/*--------------------------------------------------------------------*/

long car417_build(fstatus_flag)
$char fstatus_flag[2];
{
  $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];

   int    rc;

   $WHENEVER SQLERROR GOTO errexit;
 
   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt,  $StartRow,  $TitleRow,  $ItemRow,
           $TotColumn, $PgLine, $Width, $iForm_Tp
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 417;
 
   printf(" TitleFmt[%s]\n",TitleFmt);
   printf(" BodyFmt[%s]\n",BodyFmt);
   strcpy(TitleFmt,rtrim(TitleFmt));
   sprintf_s(TitleFile, sizeof TitleFile,"%s.ti",outputf);
   strcpy(BodyFmt, rtrim(BodyFmt));
   sprintf_s(BodyFile, sizeof BodyFile, "%s.bd",outputf);
   
   rgu_init_report(BodyFmt,BodyFile);
   rc = car417_body(fstatus_flag);
   if (rc != M_CM_OK)
       return rc;
   rgu_finish_report();

   rgu_init_report(TitleFmt,TitleFile);

   car417_title();

   rgu_finish_report();

   printf(" 7777777777777777777777777 \n");
   if ((rc=save_form_info(F_BLK1, "CA", 417, userid, iForm_Tp, max_cnt, outputf))<0) {
        strcpy(MsgCode,"save_form_info failed");
        return rc;
   }
   return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}


long car417_build1(reportbd)
$char  reportbd[2];
{
  $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];

   int    rc;

   $WHENEVER SQLERROR GOTO errexit;
 
   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt,  $StartRow,  $TitleRow,  $ItemRow,
           $TotColumn, $PgLine, $Width, $iForm_Tp
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 417;
 
   printf(" TitleFmt[%s]\n",TitleFmt);
   printf(" BodyFmt[%s]\n",BodyFmt);
   strcpy(TitleFmt,rtrim(TitleFmt));
   sprintf_s(TitleFile, sizeof TitleFile,"%s%s.ti",outputf,reportbd);
   strcpy(BodyFmt, rtrim(BodyFmt));
   sprintf_s(BodyFile, sizeof BodyFile, "%s%s.bd",outputf,reportbd);
   

   printf("TitleFile[%s]\n",TitleFile);
   printf("BodyFile[%s]\n",BodyFile);

   rgu_init_report(BodyFmt,BodyFile);
   rc = car417_body(reportbd);
   if (rc != M_CM_OK)
       return rc;
   rgu_finish_report();

   rgu_init_report(TitleFmt,TitleFile);
   car417_title();
   rgu_finish_report();

   printf(" 7777777777777777777777777 \n");
   if ((rc=save_form_info(F_BLK1, "CA", 417, userid, iForm_Tp, max_cnt, outputf))<0) {
        strcpy(MsgCode,"save_form_info failed");
        return rc;
   }
   return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

/******************************************************************************************/

long car417_body(sflag)
$char sflag[2];
{
 $char iins_type[INSURANCE_TYPE];
 $long mply_prem=0, qcount=0, mins_premium=0;
 
 $char stmt_buf[4000];
 $int  id1,id2,id3,id4;
 $char sWhere[1024];
 $char icard[21], dpolicy[11];
 char  sIupcompShort[2], policyDB[21], policyDBname[41];
 int count;
 int Y;

   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False) {
       return M_CM_DB_NOTOPEN;
   }


    switch(sflag[0])
    {
        case 'S':
	case 'A':
	          strcpy(sWhere,"and fstatus = 'S' ");
		  break;
	case 'F':
	case 'B':
	          strcpy(sWhere,"and fstatus = 'F' ");
		  break;
	case '3':
	          strcpy(sWhere,"and NVL(fstatus,' ') = ' ' ");
		  break;
	case '4':
	          strcpy(sWhere," ");
		  break;
        default :
	          break;
    }
    
    rgu_put_body(1); max_cnt += 3;

    sprintf_s(stmt_buf, sizeof stmt_buf,"select iprocess,ibroker,dpolicy_bgn,dpolicy_end, "
                     "        ipolicy,iins_type,pcomm,pagent,           "
                     "        mdeal,mcomm_diff,magent_diff,mdeal_diff,  "
                     "        fstatus,dadjust,iendorse,ientry,dentry,dprint, remark    "
                     "   from ca_comm_balance                           "
                     "  where iprocess = '%s'                           "
                     "        %s                                        "
                     "  order by ipolicy,iins_type                      "
                      ,iprocess,sWhere);
    printf("stmt[%s]\n",stmt_buf);
    EXEC SQL PREPARE Acursor  FROM :stmt_buf;
    EXEC SQL DECLARE AcursorC CURSOR FOR Acursor;
    EXEC SQL OPEN AcursorC;
    ipr = 0;
    while (1)
    {
        printf(" fetch ca_comm_process \n");
        EXEC SQL FETCH AcursorC INTO :iprocess,:ibroker,:dpolicy_bgn,:dpolicy_end,
                                     :ipolicy,:iins_type,:pcomm,:pagent,
                                     :mdeal,:mcomm_diff,:magent_diff,:mdeal_diff,
                                     :fstatus,:dadjust,:iendorse,:ientry,:dentry,:dprint,:remark;

        if (SQLCODE == SQLNOTFOUND)  break;

        if ((dprint[0] != '\0') && (dprint[0] != ' '))
        {
           ipr = 1;
        }

        printf(" ********************************** \n");

           $SELECT nchi_abv
              INTO $nchi_abv
              FROM broker_agent
             WHERE ibroker = $ibroker;
             if(SQLCODE == SQLNOTFOUND) strcpy(nchi_abv, "");


           $SELECT nname
              INTO $nname
              FROM officer
             WHERE iofficer = $ientry;
             if(SQLCODE == SQLNOTFOUND) strcpy(nname, "");

            sIupcompShort[0] = ipolicy[2]; /* �O�渹�ĤT�X */
            sIupcompShort[1] = '\0';
            strcpy( policyDB, get_upcomp(sIupcompShort, USE_SHORT_BRANCH_ID, USE_BRANCH_ID));
            strcpy( policyDBname, get_full_dbname(policyDB));

            sprintf_s(stmt, sizeof stmt, "SELECT a.icard, a.dpolicy, b.mins_premium"
                           "  FROM %s:ply_relation a, %s:ply_ins_type b"
                           " WHERE a.ipolicy = b.ipolicy "
                           "   AND a.ipolicy = '%s' "
                           "   AND b.iins_type = '%s' ", policyDBname, policyDBname, ipolicy, iins_type);
            printf("stmt[%s]\n", stmt);
            $PREPARE prep1 FROM $stmt;
            $EXECUTE prep1 INTO  $icard, $dpolicy, $mins_premium;

             /****
             rgu_put_body_string(2, iprocess,1);
             rgu_put_body_string(2, ibroker,1);
             rgu_put_body_string(2, dpolicy_bgn, 1);
             rgu_put_body_string(2, dpolicy_end, 1);
             ****/
             printf("ipolicy[%s],iins_type[%s]\n",ipolicy,iins_type);
             rgu_put_body_string(2, ipolicy, 1);
             rgu_put_body_string(2, iins_type, 1);

             rfmtdouble(pcomm, "---------&.--", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 1);
             rfmtdouble(pagent,"---------&.--", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 1);
             rgu_put_body_string(2, itos(mdeal), 1);
             rgu_put_body_string(2, itos(mcomm_diff), 1);
             rgu_put_body_string(2, itos(magent_diff), 1);
             rgu_put_body_string(2, itos(mdeal_diff), 1);

             rgu_put_body_string(2, trim(fstatus), 1);
             rgu_put_body_string(2, trim(dadjust), 1);
             rgu_put_body_string(2, trim(iendorse), 1);
             rgu_put_body_string(2, trim(nname), 1);
             rgu_put_body_string(2, trim(dentry), 1);
             rgu_put_body_string(2, trim(icard), 1);
             rgu_put_body_string(2, trim(dpolicy), 1);
             rgu_put_body_string(2, trim(dprint), 1);

             rfmtlong( mins_premium,"---------&", tmp_buf);
             rgu_put_body_string(2, trim(tmp_buf), 1);

             rgu_put_body_string(2, trim(remark), 1);
             rgu_put_body(2); max_cnt ++;


    }

   return M_CM_OK;  
  
   errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
 }
 
/*----------------------------------------------------------------------------*/
void car417_title()
{   
$long icnt;
 
     if (ipr == 0)
     {
        rgu_put_head_string(1, "ñ����");
     }
     else
     {
        rgu_put_head_string(1, "�������");
     }
     printf(" dpolicy_bgn[%s]\n",dpolicy_bgn);
     rgu_put_head_string(1, dpolicy_bgn);   /* get_currdt */
     rgu_put_head_string(1, dpolicy_end);
     rgu_put_head_string(1, cm_get_sysd());
     rgu_put_head_string(1, ibroker);
     rgu_put_head_string(1, nchi_abv);
     rgu_put_head_string(1, iprocess);
     rgu_put_head();

  
}
/*----------------------------------------------------------------------------*/

char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  static char sTmp_db_name[21];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
  }
  return sTmp_db_name;
}

long car417_get_db()
{
   if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   return SUCCESS;

errexit:

   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
