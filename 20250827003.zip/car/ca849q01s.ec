/************************************************/
/*   PROGRAM : ca849q01s.ec                     */
/*   DATE    : 107.12.25                        */
/*   NOTE    : �߮ױj���ҿ�J���Ӫ�             */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
$include datetime.h;
#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"

$char DBName[05], outputf[N_FILE+1];
$char  userid[11];
DBinfo  *list;
int     count_db;


$char sBgnDate_e[11], sEndDate_e[11], sBgnDate[11], sEndDate[11], sArea[6];
$char sBasicDate[11], sBasicDate_e[11], sFwork[2];
$long lBgnDate, lEndDate;

long car849_build();
void car849_title();
long car849_body();
long car849_print();

/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
    int rc;
    
    batchinit();
    strcpy(DBName   ,  isNULLstr(argv[1]));
    strcpy(userid   ,  isNULLstr(argv[2]));
    strcpy(sBgnDate ,  isNULLstr(argv[3]));  /* �鵲��_�� */
    strcpy(sEndDate ,  isNULLstr(argv[4]));  /* �鵲�騴�� */
    strcpy(outputf  ,  isNULLstr(argv[5]));
    
    strcpy(sBgnDate_e, cm_to_infdate(sBgnDate));
    strcpy(sEndDate_e, cm_to_infdate(sEndDate));

    rc=car849_get_db();
    if (rc!=M_CM_OK)
        return rc;
   
    rc = car849_build();
    if (rc != M_CM_OK)
        return rc;

    return M_CM_OK;
   
errexit:
    printf("main :SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}

/*--------------------------------------------------------------------*/

long car849_build()
{
    int    rc;
    
    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;

    rc = car849_body();
    if (rc != M_CM_OK)
        return rc;
           
   rc = car849_print();
   if (rc != M_CM_OK)
       return rc;
   
   
   return M_CM_OK;

errexit:
   EWRITE(userid,rc,sqlca.sqlerrm);
   return SQLCODE;  
}

long car849_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

long car849_body()
{
    long rc;
    int k;
    $char stmt[9500],stmt2[3000];
    $char iclaim[CLAIM_NUM];
    
    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;

    $create temp table car849tbl
    (
       nchi_full    char(40),       -- ���
       nbranch      char(40),       -- ��O
       affiliated   char(6),        -- ���N��
       nname        char(10),       -- �z��O
       iclaim       char(20),       -- �߮׸�
       iins_type    char(6),        -- �I��
       msettle      int,            -- �ߴڪ��B
       qduty_1      int,            -- �����F�d
       qduty_2      int,            -- �]���F�d
       itag_oth     char(12),       -- ��y����
       icard_oth    char(20),       -- ��y�d��
       ivictim      char(10),       -- ��yID
       daccident    char(25),       -- �ƬG��
       qduty_A1     int,            -- ��y�F�d(����)
       qduty_A2     int             -- ��L���F�d(����)
    )with no log;

    sprintf_s(stmt,9500,
            "insert into car849tbl \
             SELECT (SELECT nchi_full FROM branch WHERE ibranch = a.iclaim[1,2]), \
                    (SELECT nbranch FROM sa_branch_type WHERE ibranch = a.affiliated), \
                    a.affiliated, \
                    (SELECT nname FROM sysdb:officer WHERE iofficer = a.adjustment), \
                    a.iclaim, b.insure_instype, b.msettle - b.mfee, \
                    (SELECT max(qduty_adjuster) FROM ca_clm_victim_data  \
                      WHERE iclaim = (SELECT iverify FROM ca_ver_relation \
                                       WHERE iclaim = a.iclaim) \
                        AND fvictim_car IN ('F')), c.qduty_adjuster, c.itag, \
                    d.ioth_icard, d.ivictim, a.daccident, \
                    (SELECT max(qduty_adjuster) FROM ca_clm_victim_data \
                      WHERE iclaim = (SELECT iverify FROM ca_ver_relation \
                                       WHERE iclaim = a.iclaim) \
                        AND fvictim_car not IN ('F','G')), \
                    100-(SELECT max(qduty_adjuster) FROM ca_clm_victim_data \
                          WHERE iclaim = (SELECT iverify FROM ca_ver_relation \
                                           WHERE iclaim = a.iclaim) \
                            AND fvictim_car IN ('F'))- (SELECT max(qduty_adjuster) \
                            FROM ca_clm_victim_data \
                          WHERE iclaim = (SELECT iverify FROM ca_ver_relation \
                                           WHERE iclaim = a.iclaim) \
                            AND fvictim_car not IN ('F','G')) \
              FROM ca_clm_process a,dwsdb:claim_stl_dtl b,ca_clm_victim_data c, \
                   ca_property d,ca_ver_relation e \
             WHERE a.iclaim = b.iclaim1   AND b.ivictim = c.ivictim \
               AND e.iclaim = a.iclaim    AND c.iclaim = e.iverify  \
               AND c.iclaim = d.iverify   AND c.ivictim = d.ivictim \
               AND c.fvictim_car NOT IN ('F','G')  AND b.fstl = 1   \
               AND a.iclaim[6] = 'C'      \
               AND b.dclose >= '%s'   AND b.dclose <= '%s' \
             GROUP BY 1,2,3,4,5,6,7,9,10,11,12,13 \
             ORDER BY a.iclaim",  sBgnDate_e,sEndDate_e);
            
    printf("stmt[%s]\n",stmt);
    $prepare pre1 from $stmt;
    $execute pre1;
    
    return M_CM_OK;
        
errexit:
   printf("car849_body ==> SQLCODE:[%ld][%s] \n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   printf("   end EWRITE \n");
   return SQLCODE;
}

long car849_print()
{
   $char sfilename[200];
   $char stitle[1000];
   $char ssql[1000];
   $char sErrmsg[100];
   $int  rc;
 
   $WHENEVER ERROR goto errexit;
   $SET LOCK MODE TO WAIT;

   strcpy(sfilename,"�߮ױj���Ҹ���J���Ӫ�");
   printf("sfilename[%s]\n",sfilename);

   strcpy(stitle, sfilename);
   printf("stitle[%s]\n",stitle);
   strcat(stitle, "\n\t");
   strcat(stitle, "�߮פ鵲����G ");
   strcat(stitle, sBgnDate_e);
   strcat(stitle, " ~ ");
   strcat(stitle, sEndDate_e);
   strcat(stitle, "\n\t���\t��O\t���N��\t�g��O\t�׸�\t�I��\t���B\t�����F�d\t�]���F�d\t");
   strcat(stitle, "��y����\t��訮�j��O�I�Ҹ�\t��yID\t�ƬG��\t��y�F�d(����)\t��L���F�d(����)\t");

   printf("stitle[%s]\n",stitle);

   sprintf_s(ssql,1000,
    " select * from car849tbl ");

   printf("ssql[%s]\n",ssql);

   rc = unload_file(outputf,"",sfilename,stitle,ssql);

   if (rc != SUCCESS)
   {
       if (rc == 3501)
       {
          sprintf_s(sErrmsg,100," ��J���^������䤣���� ",sfilename);
       }
       else
       {
          sprintf_s(sErrmsg,100," %s �ɮ׵L�k���� ",sfilename);
       }

       EWRITE(userid, rc , sErrmsg);
       exit(1);
   }
   
   return M_CM_OK;

errexit:
  printf("SQL=[%d], sqlca.sqlerrm[%s]\n", SQLCODE, sqlca.sqlerrm);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  exit(1);
    
}
