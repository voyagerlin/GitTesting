/*********************************************************/
/* Program  : car1118.ec   (Data Producer)               */
/*            �j�v�~�ȷl���v��ƷJ��                     */
/*                                                       */
/* �έp��� : ���~�ר� �B �O��~�ר�                   */
/* FUNCTION : ca_calc_365_full():�p�⺡���O�I�O          */
/*            ca_calc_info_msettle():�p��ߴڪ��B        */
/*            caxxxlib.ec :                              */
/*                                                       */
/* TEMP TABLE: ca_loss_big_temp1(�O���ŦX����O17�I�ؤ�  */
/*                              �O�渹�X)                */
/*             ca_loss_info_temp2(�O�������O�O,���M�ߴ�, */
/*                                �v�M�ߴڤά������)    */
/*             ca_loss_info_temp3(�p������)          */
/*             quota_temp                                */
/*                                                       */
/*********************************************************/

#include <stdio.h>
#include "api_xsrv.h"
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"

#include "commsgs.h"
#include "carmsgs.h"
#include "glsmsgs.h"
#include "gls_array.h"
#include "gls_const.h"

#include <time.h>

EXEC SQL include sqlca;
EXEC SQL include datetime.h;

/*--------------------------------------------------------------*/
#define SUCCESS                 1
#define FAIL                    0
#define FOUND                   sqlca.sqlcode!=SQLNOTFOUND
#define NOT_FOUND               sqlca.sqlcode==SQLNOTFOUND
#define DATENULL                0x80000000L

#define YES                     1
#define NO                      0

#define ranage                  10000

#define INS_DELIMITER           ";"
#define INS_TYPE_LIST           50

EXEC SQL define _PETER;

extern  char  RPTDIR[];
$char stmt[8000];

$struct parameter
{
  char irule[2];
  char imethod[2];
  char edbgn[11];
  char edend[11];
  char calc_end[11];
  char hist_bgn[11];
  char hist_end[11];
  char idata[2];
  char iass_idx[2];
  char iassured[11];
  char icar_idx[2];
  char icar_type[3];
  char ibra_idx[2];
  char ibranch[7];
} pa;

/* ***** Global variables ***** */

EXEC SQL BEGIN DECLARE SECTION;
     char  userid[11];
     date  Today;
     char  Today_c[13];
     char  Today_yy[5] , Today_mm[3] , Today_dd[3];
     static char exec_date[YYYYMMDD];
     static char exec_time[20];     /*** �����s�@�ɶ� ***/
     static char exec_eDbgn[20];
     static char exec_eDend[20];

     char  eDbgn[11], eDend[11];
     long  lDbgn, lDend;
     long  lCalc_end;
     char  eCalc_end[11];
     char  cWkinx[11];
     char  DBName1[5];
     char  eDhist_bgn[11];
     long  lDhist_bgn;
     char  eDhist_end[11];
     long  lDhist_end;

     char  eDtrue[11];

     static char remotedb[DBNAME];

EXEC SQL END DECLARE SECTION;

char    DBName[5];
char    outputf[80];
char    filename[200];
DBinfo  *list;
int     count_db , k ,k1;
int     count_db_tmp, k_tmp;
char    msgbuf[150];
char    errmsg[200];
int     flen;

char    sApHome[30];
char    aphome[40];
FILE    *fptr, *fptr_err;
FILE    *fp;

char    sWhere1[3000];
char    sWhere2[3000];
char    sWhere3[3000];
char    sWhere4[3000];
char    sWhere1_clm[1024];
char    sWhere2_clm[1024];
char    sWhere3_clm[1024];
char    sWhere4_clm[1024];
char    sWhere5_a[30];
char    sWhere5_b[30];

$char   sdata[4][41];
$char   nequipment[31];
$char   itag[CA_TAG_NUM];
$long   moutstand;
char    fAllDB='Y';

$char stmt_tmp1[1024],stmt_tmp2[2048];

/*** local function ***/
long car1118_process();
long car1118_get_db();
long create_temp_tbl();
long drop_temp_tbl();

extern long ca_calc_365_full();
extern long ca_loss_upd_InfoTable_prem();
extern long ca_calc_info_msettle();
extern long ca_calc_info_payment();
extern long ca_loss_upd_InfoTable_payment();

long loss_info_build1();
long loss_info_build2();
long loss_info_build3();
long loss_info_build4();
long check_leap_year();
char *get_car_full_db();

/*951122*/
struct CLAIM_INS {
   char   iins_type[INS_TYPE_LIST];     /*  ex. "4A;4B;4C;4D"  */
   char   iins_ply[INSURANCE_TYPE];     /*  ex. "24"           */
   int    flag_ins_type;
   double tmp_ins_ply_mbgn;
   double tmp_ins_ply_mend;
   double tmp_ins_ply_mstl;
   int    qbgn_outstl_ins_type;
   int    qend_outstl_ins_type;
   int    qclaim_ins_type;
   double tmp_ins_ply_mstl_dend;
   double tmp_ins_ply_mstl_dbgn;
   int    flag_ins_ply_close_dbgn;
   int    flag_ins_ply_close_dend;
   struct CLAIM_INS *next;
};

struct CLAIM_INS *Ifirst_CLM, *Icurr_CLM, *Ilast_CLM, *Icurr_CLM_Loss;
/**********************************************************************/
main(argc,argv)
int  argc;
char **argv;
{
     char  scriptFile[120];
     long  rc , res;
     int   iRtnCode;
     char  Message[1024];
     char  Message1[300];
     char  Message2[300];
     int   count_db1, k_tmp1;

     batchinit();
     strcpy(DBName,        isNULLstr(argv[1]));
     strcpy(userid,        isNULLstr(argv[2]));
     strcpy(pa.irule,      isNULLstr(argv[3]));
     strcpy(pa.imethod,    isNULLstr(argv[4]));
     strcpy(pa.edbgn,      isNULLstr(argv[5]));  /*�ͮİ_��*/
     strcpy(pa.edend,      isNULLstr(argv[6]));  /*�ͮĨ���*/
     strcpy(pa.calc_end,   isNULLstr(argv[7]));  /*�p�⨴�� : �O��~�ר�*/
     strcpy(pa.hist_end,   isNULLstr(argv[8]));  /*�����I���*/

     strcpy(pa.idata,      isNULLstr(argv[9]));  /* 1.����  2.�j�v  */
     strcpy(pa.iass_idx,   isNULLstr(argv[10])); /* �Q�O�I�H/�ϥΤHindex 1.���� 2.�Q�O�I�HID 3.�Q�O�I�H�W�� 4.�ϥΤH�W�� */
     strcpy(pa.iassured,   isNULLstr(argv[11])); /* �Q�O�I�H/�ϥΤH�W�� */
     strcpy(pa.icar_idx,   isNULLstr(argv[12])); /* ���ؤ���             1.���� 2.�T�� 3.���� 4.���إN�� */
     strcpy(pa.icar_type,  isNULLstr(argv[13])); /* ���إN�� */
     strcpy(pa.ibra_idx,   isNULLstr(argv[14])); /* ������ 1.���� 2.�����q�N�� 3.���~�Z�N�� */
     strcpy(pa.ibranch,    isNULLstr(argv[15])); /* ���~�Z�N�� */

     strcpy(outputf,       isNULLstr(argv[16]));

     strcpy(outputf,trim(outputf));

     printf("pa.irule   [%s]\n",pa.irule);
     printf("pa.imethod [%s]\n",pa.imethod);
     printf("pa.edbgn   [%s]\n",pa.edbgn);
     printf("pa.edend   [%s]\n",pa.edend);
     printf("pa.calc_end[%s]\n",pa.calc_end);
     printf("pa.hist_end[%s]\n",pa.hist_end);
     printf("pa.idata[%s]   \n",pa.idata);
     printf("pa.iass_idx[%s]\n",pa.iass_idx);

     printf("pa.iassured[%s]\n",pa.iassured);

     printf("pa.icar_idx[%s]\n",pa.icar_idx);
     printf("pa.icar_type[%s]\n",pa.icar_type);
     printf("pa.ibra_idx[%s]\n",pa.ibra_idx);
     printf("pa.ibranch[%s]\n",pa.ibranch);

     /* sWhere1    �j�v�B�����O */
     rc = car1118_get_db();
     if (rc!=M_CM_OK)
          return rc;
     if (pa.idata[0] == '1')
     {
        strcpy(sWhere1," ");
        strcpy(sWhere1_clm," ");
     }
     else
     {
        rc = getApHome(sApHome);
        if (rc < 0)
        {
            strcpy(msgbuf,"read Config file error!!-->getApHome\n");
            EWRITE(userid,rc,msgbuf);
            return rc;
        }

        rc = car1118_read_file();
        if (rc != SUCCESS)
            return rc;

        strcpy(sWhere1,
        " AND (a.icorps   in (select iroute   from car1118 where a.icorps   = car1118.iroute \
                    and iroute <> ' ' and iroute is not null) or   \
               a.iofficer in (select iofficer from car1118 where a.iofficer = car1118.iofficer)) ");
        strcpy(sWhere1_clm,
        " AND (b.icorps   in (select iroute   from car1118 where b.icorps   = car1118.iroute \
                    and iroute <> ' ' and iroute is not null) or   \
               b.iofficer in (select iofficer from car1118 where b.iofficer = car1118.iofficer)) ");


/**********************************����ɮ���J�覡
        strcpy(sWhere1,
        "AND  (a.icorps[1,4] in ('C095','C111','E004','F340','F449','G871','GA97',                           \
                                 'GC73','GD64','GE76','GF97','GH24','GH80','GI40',                           \
                                 'H067')  OR                                                                 \
              a.iofficer in ('711384QF5' ,'701581QG'  ,'711700QG'  ,'700542QG'   ,'700786QG1' ,'706476QG3',  \
                             '706476QG4' ,'707051QG3' ,'709974QG'  ,'709974QG1'  ,'710974QG'  ,'711030QG' ,  \
                             '712158QG'  ,'712316QG1' ,'YXWCA0041' ,'701581QG1'  ,'701581QG2' ,'701581QG4',  \
                             '701581QG5' ,'709163QG'  ,'709163QG1' ,'706476QG5'  ,'707051QG4' ,'710125QG' ,  \
                             '706452QG1' ,'706452QG6' ,'706641QG'  ,'706641QG10' ,'710204QG'  ,'710204QG2',  \
                             '710527QG'  ,'710527QG6' ,'710905QG'  ,'710008QG1'  ,'701134QG'  ,'711229QG' ,  \
                             '709792QH'  ,'710565QH'  ,'711267QH')  OR                                       \
              a.iofficer matches 'Y*VK*' OR                                                                  \
              a.iofficer matches 'Y*VH*' OR                                                                  \
              a.iofficer matches 'H*'    OR                                                                  \
              a.iofficer matches 'Y*VH*')   ");
***************************************************************/
     }

     if (pa.iass_idx[0] == '1')
     {
        strcpy(sWhere2," ");
     }
     else if (pa.iass_idx[0] == '2')
     {
        sprintf(sWhere2," AND  b.iassured matches '%s' ",pa.iassured);
     }
     else if (pa.iass_idx[0] == '3')
     {
        sprintf(sWhere2," AND  b.nassured matches '%s' ",pa.iassured);
     }
     else
     {
        sprintf(sWhere2," AND  b.nuser matches '%s' ",pa.iassured);
     }

     if (pa.icar_idx[0] == '1')
     {
        strcpy(sWhere3," ");
        strcpy(sWhere3_clm," ");
     }
     else if (pa.icar_idx[0] == '3')
     {
        strcpy(sWhere3,"  AND a.icar_type in ('01','02','32','34','35') ");
        strcpy(sWhere3_clm,"  AND b.icar_type in ('01','02','32','34','35') ");
     }
     else if (pa.icar_idx[0] == '2')
     {
        strcpy(sWhere3,"  AND a.icar_type not in ('01','02','32','34','35') ");
        strcpy(sWhere3_clm,"  AND b.icar_type not in ('01','02','32','34','35') ");
     }
     else
     {
        sprintf(sWhere3," AND a.icar_type = '%s' ",pa.icar_type);
        sprintf(sWhere3_clm," AND b.icar_type = '%s' ",pa.icar_type);
     }


     if (pa.ibra_idx[0] == '1')
     {
        strcpy(sWhere4," ");
        strcpy(sWhere4_clm," ");
        k_tmp = 0;
     }
     else if (pa.ibra_idx[0] == '2')
     {
        strcpy(pa.ibranch,trim(pa.ibranch));
        if (strcmp(pa.ibranch,"00") == 0)
        {
           k_tmp = 0;
        }
        else if (strcmp(pa.ibranch,"22") == 0)
        {
           k_tmp = 1;
        }
        else if (strcmp(pa.ibranch,"33") == 0)
        {
           k_tmp = 2;
        }
        else if (strcmp(pa.ibranch,"40") == 0)
        {
           k_tmp = 3;
        }
        else if (strcmp(pa.ibranch,"66") == 0)
        {
           k_tmp = 4;
        }
        else if (strcmp(pa.ibranch,"70") == 0)
        {
           k_tmp = 5;
        }
        count_db_tmp = k_tmp + 1;
        count_db = count_db_tmp;
        strcpy(sWhere4," ");
        strcpy(sWhere4_clm," ");
        fAllDB = 'N';
     }
     else
     {
        k_tmp = 0;
        sprintf(sWhere4," AND a.iquota matches '%s' ",pa.ibranch);
        sprintf(sWhere4_clm," AND c.iquota matches '%s' ",pa.ibranch);
     }
     if (strlen(sWhere4)<2){
        strcpy(sWhere5_a," ");
        strcpy(sWhere5_b," ");
      }else{
        strcpy(sWhere5_a," AND a.iquota = c.iquota");
        strcpy(sWhere5_b," AND b.iquota = c.iquota");
      }

     /*--- transfer date ---*/
     Today_c[0] = '\0';
     Today_yy[0] = '\0';
     Today_mm[0] = '\0';
     Today_dd[0] = '\0';

     strcpy(eDbgn, cm_to_infdate(pa.edbgn));
     lDbgn = cm_ymd_cdate(pa.edbgn);

     strcpy(Today_c,cm_cdate_str(lDbgn));
     cm_split_ymd_100(Today_c,Today_yy,Today_mm,Today_dd);
     sprintf(exec_eDbgn,"%s%s%s",Today_yy,Today_mm,Today_dd);

     strcpy(eDhist_end, cm_to_infdate(pa.hist_end));
     lDhist_end = cm_ymd_cdate(pa.hist_end);

     Today_c[0] = '\0';
     Today_yy[0] = '\0';
     Today_mm[0] = '\0';
     Today_dd[0] = '\0';

     strcpy(eDend, cm_to_infdate(pa.edend));
     lDend = cm_ymd_cdate(pa.edend);

     strcpy(Today_c,cm_cdate_str(lDend));
     cm_split_ymd_100(Today_c,Today_yy,Today_mm,Today_dd);
     sprintf(exec_eDend,"%s%s%s",Today_yy,Today_mm,Today_dd);

     printf("{car1118.0001}:exec_eDbgn[%s] , exec_eDend[%s]\n",exec_eDbgn , exec_eDend);

     if (*pa.irule == '2')  /*** �O��~�ר��J�p������,�����@�B�z ***/
     {
          strcpy(eCalc_end, cm_to_infdate(pa.calc_end));
          lCalc_end = cm_ymd_cdate(pa.calc_end);
     }
     else
     {
          lCalc_end = DATENULL;
     }

     if (*pa.irule == '1')
     {
          strcpy(eDtrue,eDend);
     }
     else
     {
          strcpy(eDtrue,eCalc_end);
     }

     Icurr_CLM=Ifirst_CLM=Ilast_CLM=Icurr_CLM_Loss=NULL;

     /***  ����I���H�έp�ͮİ_�����D ***/
     strcpy(eDhist_bgn, cm_to_infdate(pa.edbgn));
     lDhist_bgn = cm_ymd_cdate(pa.edbgn);

     /**** ����ɶ� exec_time [YYYY-MM-DD HH:MM] ****/
     strcpy(exec_time, cm_get_sysd());
     /***********************************************/

     memset(msgbuf,0,sizeof(msgbuf));

     strcpy(remotedb,getenv("LOCALSITE"));

     /******* �O���{������ɶ� *******/
     rtoday(&Today);
     strcpy(Today_c,cm_cdate_str(cm_today()));
     cm_split_ymd_100(Today_c,Today_yy,Today_mm,Today_dd);

     sprintf(exec_date,"%s%s%s",Today_yy,Today_mm,Today_dd);

     res = getApHome(aphome);

     filename[0] = '\0';
     sprintf(filename,"%s/rptftp/", aphome);

     /* �]temp db ������ ,�����q�令�U�����q���}�B�z */
     k_tmp1    = k_tmp;
     count_db1 = count_db;

	 printf("k_tmp1[%d]\n",k_tmp);
	 printf("count_db1[%d]\n",count_db);

     for (k1=k_tmp1;k1<count_db1;k1++){
     	 printf("k1[%d]\n",k1);
     	 if (pa.ibra_idx[0] != '2'){
	     	 k_tmp = k1 ;
	         count_db_tmp = k_tmp + 1;
	         count_db = count_db_tmp;

  			 printf("k_tmp[%d]\n",k_tmp);
			 printf("count_db[%d]\n",count_db);
         }
         printf("creating temp table ... \n");
	     rc = create_temp_tbl();
	     printf("temp table created ! \n");

	     /******* merge data *******/
	     printf("begin car1118_process ... \n");
	     if ((rc=car1118_process()) != M_CM_OK)
	     {
	          printf("return car1118 rc[%ld]\n",rc);
	          EWRITE(userid,rc,msgbuf);
	          return rc;
	     }
	     printf("end car1118_process ! \n");

	     printf("building �g��H�O ... \n");
	     /*** �g��H�O ***/
	     rc = loss_info_build2();
	     if (rc != M_CM_OK)
	        return rc;
         printf("�g��H�O�ɮפw����! \n");

	     printf("building ���Ӹ�� ... \n");
	     /*** ���Ӹ�� ***/
	     rc = loss_info_build4();
	     if (rc != M_CM_OK)
	        return rc;
         printf("���Ӹ���ɮפw����! \n");

	     /*** �߮ש��Ӹ�� ***/
	     printf("building �߮׸�� ... \n");
	     rc = loss_info_build5();
	     if (rc != M_CM_OK)
	        return rc;
         printf("�߮׸���ɮפw���� ! \n");

         printf("droping temp table ... \n");
	     rc = drop_temp_tbl();
	     printf("temp table droped ! \n");
     }

     strcpy(Message,  "�Цܲ��I�t��/�@�θ귽[N]/�d��[B]/�ɮפU���@�~[cmn202]�U���ɮ�!\n");

     if (*pa.irule == '1')
     {
         sprintf(Message1,"���~�ר�G%s ~ %s  \n",eDbgn,eDend);
     }
     else if (*pa.irule == '2')
     {
         sprintf(Message1,"�O��~�ר�G%s ~ %s  �p������G%s\n",eDbgn,eDend,eCalc_end);
     }
     else
     {
         sprintf(Message1,"�ƬG�o�ͨ�G%s ~ %s  �p������G%s\n",eDbgn,eDend,eCalc_end);
     }

     sprintf(Message2,"�����s�@�ɶ��G%s",exec_time);
     strcat(Message,Message1);
     strcat(Message,Message2);

     EWRITE(userid,M_CM_OK,Message);

     return SUCCESS;
}

/* CREATE TEMP TABLE AND PREPARE DATA FROM TABLE:officer,sa_frm_module,sa_branch_type,ca_car_model */
long car1118_get_db()
{

     EXEC SQL BEGIN DECLARE SECTION;
         char ibrand[7],nbrand_1[13],nbrand_2[31];
         int  ipro_year;
         char iquota[7];

     EXEC SQL END DECLARE SECTION;

     EXEC SQL WHENEVER SQLERROR GOTO errexit;
     if (db_select(DBName) == False)
     {
          EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
          return M_CM_DB_NOTOPEN;
     }
     if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
     {
          EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
          return M_CM_NOT_DBLIST;
     }
     return M_CM_OK;

errexit:
     EWRITE(userid,SQLCODE,sqlca.sqlerrm);
     return SQLCODE;
}

long create_temp_tbl()
{

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     sprintf(stmt_tmp1,"CREATE TEMP TABLE car1118_clm_dtl\
     (\
        iclaim        char(21)  default ' ',\
        itag          char(%d)   default ' ',\
        ipolicy       char(21)  default ' ',\
        daccident     date,\
        ibrand        char(4)   default ' ',\
        iins_type     char(6)   default ' ',\
        mapp_cover    integer   default 0,\
	    moutstanding  integer   default 0,\
    	mdecide       integer   default 0,\
        mstl          integer   default 0,\
        mrecovery     integer   default 0,\
        nuser         char(20)  default ' ',\
        nequipment    char(30)  default ' ',\
        mplace_fee    integer   default 0,\
        factory       char(100) default ' ',\
        nassured      char(20)  default ' ',\
        dclose        date\
     )WITH NO LOG;",CA_TAG_NUM-1);
     $PREPARE stmp1 FROM $stmt_tmp1;
     $EXECUTE stmp1;

     EXEC SQL CREATE unique index clmdtl ON car1118_clm_dtl (iclaim,iins_type);

     EXEC SQL CREATE TEMP TABLE car1118_clm_ply
     (
         ipolicy      char(20),
         iclaim       char(20)
     ) WITH NO LOG;

     EXEC SQL CREATE INDEX clmply ON car1118_clm_ply (ipolicy);

     EXEC SQL CREATE TEMP TABLE car1118_clm_cnt
     (
         ipolicy      char(20),
         qclm         int
     ) WITH NO LOG;

     sprintf(stmt_tmp2," CREATE TEMP TABLE ca_loss_info_temp2\
     (\
         ipolicy      char(20),\
         iins_type    char(6)  default ' ',\
         iquota       char(6)  default ' ',\
         iofficer     char(10) default ' ',\
         iroute       char(20) default ' ',\
         iresource    char(1)  default ' ',\
         iassured     char(12) default ' ',\
         nuser        char(18) default ' ',\
         icar_type    char(2)  default ' ',\
         ibrand       char(6)  default ' ',\
         icar_flag    char(1)  default ' ',\
         ideduct      smallint default 0  ,\
         mdiscount    decimal(17,6) default 0,\
         qprem        decimal(17,6) default 0,\
         mprem        decimal(17,6) default 0,\
         mpure_prem   decimal(17,6) default 0,\
         mcommission  decimal(17,6) default 0,\
         qfull        decimal(15,6) default 0,\
         mfull        decimal(17,6) default 0,\
         mfull_pure   decimal(17,6) default 0,\
         qend_outstl  decimal(17,6) default 0,\
         qclaim       decimal(17,6) default 0,\
         mbgn_outstl  decimal(17,6) default 0,\
         mend_outstl  decimal(17,6) default 0,\
         mstl         decimal(17,6) default 0,\
         itag         char(%d) default ' ',\
         dply_begin   date\
     ) WITH NO LOG;",CA_TAG_NUM-1);
     $PREPARE stmp2 FROM $stmt_tmp2;
     $EXECUTE stmp2;

     EXEC SQL CREATE INDEX ca_info_tmp2_1 on ca_loss_info_temp2 (ipolicy);
     EXEC SQL CREATE INDEX ca_info_tmp2_2 on ca_loss_info_temp2 (iins_type);
     EXEC SQL CREATE INDEX ca_info_tmp2_3 on ca_loss_info_temp2 (iquota);
     EXEC SQL CREATE INDEX ca_info_tmp2_4 on ca_loss_info_temp2 (iofficer);
     EXEC SQL CREATE INDEX ca_info_tmp2_5 on ca_loss_info_temp2 (ibrand);
     EXEC SQL CREATE INDEX ca_info_tmp2_6 on ca_loss_info_temp2
     (ipolicy,iins_type,iquota,iofficer,ibrand,icar_type,icar_flag,ideduct);
     EXEC SQL CREATE INDEX ca_info_tmp2_7 on ca_loss_info_temp2
     (ipolicy,iquota,iofficer,iroute);

     EXEC SQL CREATE TEMP TABLE ca_loss_info_temp3
     (
         ipolicy      char(20),
         iquota       char(6)  default ' ',
         iofficer     char(10) default ' ',
         iroute       char(20) default ' ',
         iresource    char(1)  default ' ',
         mdiscount    decimal(17,6) default 0,
         qprem        decimal(17,6) default 0,
         mprem        decimal(17,6) default 0,
         mpure_prem   decimal(17,6) default 0,
         mcommission  decimal(17,6) default 0,
         qfull        decimal(15,6) default 0,
         mfull        decimal(17,6) default 0,
         mfull_pure   decimal(17,6) default 0,
         qend_outstl  decimal(17,6) default 0,
         qclaim       decimal(17,6) default 0,
         mbgn_outstl  decimal(17,6) default 0,
         mend_outstl  decimal(17,6) default 0,
         mstl         decimal(17,6) default 0
     ) WITH NO LOG;

     /****************************************************/
     EXEC SQL CREATE TEMP TABLE quota_temp
     (
         iquota char(6),
         nquota char(20),
         igroup char(5),
         ngroup char(20),
         qorder char(4)
     ) WITH NO LOG;

     EXEC SQL CREATE UNIQUE INDEX quota_tmp_u1 on quota_temp (iquota);

     EXEC SQL INSERT INTO quota_temp
              SELECT a.ibranch,a.nbranch,a.igroup,b.ngroup,b.qorder
                FROM sa_branch_type a,sa_frm_module b
               WHERE a.igroup = b.igroup
                 AND b.ifrm_module = '01';

     /****** �I�ؤ��� ******/
     EXEC SQL CREATE TEMP TABLE instype_temp
     (
         iins_type char(15),
         all_iins  char(300)
     ) WITH NO LOG;
     EXEC SQL CREATE UNIQUE INDEX instype_tmp_u1 on instype_temp (iins_type);

     EXEC SQL INSERT INTO instype_temp
              VALUES ("2103" , "21");
     EXEC SQL INSERT INTO instype_temp
              VALUES ("2101" , "21");
     EXEC SQL INSERT INTO instype_temp
              VALUES ("05_deduct" , "05");
     EXEC SQL INSERT INTO instype_temp
              VALUES ("05_nodeduct" , "05");

     EXEC SQL INSERT INTO instype_temp
              SELECT iins_type,iins_type
                FROM insurance_type
               WHERE iins_type = iins_ply;

     return M_CM_OK;

errexit:
     EWRITE(userid,SQLCODE,sqlca.sqlerrm);
     return SQLCODE;
}

long drop_temp_tbl()
{
     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     EXEC SQL DROP TABLE car1118_clm_dtl;
     EXEC SQL DROP TABLE car1118_clm_ply;
     EXEC SQL DROP TABLE car1118_clm_cnt;
     EXEC SQL DROP TABLE ca_loss_info_temp2;
     EXEC SQL DROP TABLE ca_loss_info_temp3;
     EXEC SQL DROP TABLE quota_temp;
     EXEC SQL DROP TABLE instype_temp;

     return M_CM_OK;

errexit:
     EWRITE(userid,SQLCODE,sqlca.sqlerrm);
     return SQLCODE;
}

/***********************************************************************/
long car1118_process()
{
     EXEC SQL BEGIN DECLARE SECTION;
          char    stmt[8192];
          char    stmt1[1024];

          char    where_stat1[300];
          char    where_stat2[300];
          char    where_stat3[300];

          char    ipolicy[POLICY_NUM_1];
          char    irelative_ply[POLICY_NUM_1], FullDBName[20];   /*** ���p�O�渹�X�Ψ���ݸ�Ʈw ***/

          char    fcard_class[2];
          long    ldply_bgn , ldply_end;
          char    Librand[9];
          char    Licar_type[3];
          char    Licar_flag[2];
          char    Liofficer[11];
          char    Liofficer_old[11];
          char    Liquota[7];
          char    Piquota[7];
          char    sIassured[12];
          char    sUser[19];
          char    iroute[21];
          long    Lmadjcom_prem;
          long    t_dpolicy;
          char    iins_type[INSURANCE_TYPE];
          long    mins_premium;
          double  tmp_bef_inspremium;
          double  tmp_mpure_prem=0;
          double  tmp_mfull_pure=0;
          double  tmp_mcommission=0;
          double  qcount;

          double  mfull , qfull;
          double  temp_data;
          double  cnt;
          double  tmp_pprem;
          double  tmp_prem;
          long    total_count;
          long    mdeduct;
          int     ideduct;
          int     ideduct_ply;
          int     ideduct_full;
          long    dedr_begin_tp;
          long    dendorse_tp;
          char    fedr_status_tp[3];
          int     id1;
          char    nassured[21];
          char    dc_close[11];
          char    iresource[2];
          double  tmp_mdiscount=0;

          /***** ��� *****/
          char    iendorse[ENDORSE_NUM];
          double  tmp_edr_prem;
          long    ldedr_bgn , ldedr_end;
          long    Lmedr_adjcom;
          long    t_dendorse;
          double  tmp_eprem;
          char    iedr_type[3];
          long    medrins_prem ;

          /***** �z�� *****/
          char    iclaim[CLAIM_NUM];
          long    daccident;
          char    Ipolicy12[3];

          long    dappraisal;
          long    dappraisal_bgn;
          double  mins_app;
          double  mins_app_bgn,mapp_cover_bgn;
          char    factory[101],factory_1[101],factory_2[101];

          int     mdamage_cover;

          double  tmp_mpayment;
          double  tmp_mstl;

          char    iins_item[INSURANCE_TYPE];
          char    ivictim[CUSTOMER_ID];
          double  tmp_vic_mstl , tmp_vic_mbgn , tmp_vic_mend;
          double  mapp_cover;

          double  count_1, count_2;
          double  dZero;
          long    tmp_dappraisal;
          char    tmp_iins_item[INSURANCE_TYPE], tmp_ivictim[11];

     EXEC SQL END DECLARE SECTION;

     int     code;
     long    rc;
     double  c_count;

     time_t lt;
     int     iIins_type;
     int     iins_99;

     int     flag_close_dend, flag_close_dbgn;
     long    mstl_dend, mstl_dbgn;

     int     qbgn_outstl_21;
     int     qend_outstl_21;
     int     qclaim_21;
     int     flag_21_close_dend, flag_21_close_dbgn;
     double  tmp_21_mstl_dend;
     double  tmp_21_mstl_dbgn;

     long    mpayment;
     long    mstl, mbgn_outstl, mend_outstl;
     long    qstl, qbgn_outstl, qend_outstl;

     double  tmp_mbgn_outstl, tmp_mend_outstl;
     double  tmp_mstl_dend  , tmp_mstl_dbgn;

     int     qclaim;
     int     tmp_qclaim;
     int     tmp_qbgn_outstl , tmp_qend_outstl;

     long    leap_flag;   /*** �P�_�O�_���|�~ 1:���|�~ 0:�D���|�~ ***/
     double  iins_loading[100]; /*** keep �{�椧�U�I�����[�O�βv,�H��91�~4��1��H�e���O���p��«O�O���� ***/
     char    sequip_str[21];

     $double  mins_stl_1,mins_proc_1;
     $double  mins_stl_2,mins_proc_2;
     $long    mplace_fee_1,mplace_app,mplace_fee;

    $char     stmp_ins_ply[INSURANCE_TYPE];
    $char     stmp_ins_ply_pre[INSURANCE_TYPE];
    $char     stmp_ins_type_list[INS_TYPE_LIST];
    $char     stmp_ins_type[INSURANCE_TYPE+1];
    $char     stmp[INSURANCE_TYPE+1];
    int        i;
    $char      *tok;
    $char      tok_ins_list[INS_TYPE_LIST];
    int       IsPlyChg;
    int       IsIns;

     EXEC SQL WHENEVER SQLERROR GOTO errexit;
     EXEC SQL SET LOCK MODE TO WAIT 30;

    IsIns = 0;

    /*************************************************************************/
    /* 951122, ���o�Ҧ�iins_ply, �� iins_ply �ɾ��Ƨ� ��� tmp_ins_ply[] */
    sprintf(stmt,
          " SELECT iins_type,iins_ply    \
              FROM sysdb:insurance_type \
             WHERE iins_ply<>iins_type  \
             AND   iins_ply <>'21'      \
             ORDER BY iins_ply,iins_type ");
    $PREPARE get_ins_ply FROM $stmt;
    $DECLARE ins_ply_cur CURSOR FOR get_ins_ply;
    $OPEN    ins_ply_cur ;

     stmp_ins_type_list[0] = '\0';
     stmp_ins_ply[0]       = '\0';
     stmp_ins_ply_pre[0]   = '\0';
     stmp_ins_type[0]      = '\0';
     stmp[0]               = '\0';
     IsPlyChg              = 0;

     for(;;){
   		$FETCH   ins_ply_cur 	INTO  $stmp_ins_type, $stmp_ins_ply;
        if (SQLCODE == SQLNOTFOUND) {  /* insert �̥���  */
            if (stmp_ins_ply_pre[0] != '\0'){  /* ins_ply����, �B�D�Ĥ@�� */
                code = Insert_CLAIM_INS(stmp_ins_type_list,stmp_ins_ply_pre,0,0.0,0.0,0.0,0,0,0,0.0,0.0,0,0);
                if (code!=SUCCESS) return code;
            }
            break;
        }

        strcpy(stmp_ins_type,trim(stmp_ins_type));
        strcpy(stmp_ins_ply,trim(stmp_ins_ply));

        printf("stmp_ins_type1=[%s]\n",stmp_ins_type);



        if (stmp_ins_ply_pre[0] == '\0'){   /* �Ĥ@�� */

            stmp_ins_type_list[0]='\0';
            strcpy(stmp_ins_type_list,stmp_ins_type);           /* ex. "4A"    */

        }else{
        	/* �O�_�����U�@��ins_ply */

        	if (strcmp(stmp_ins_ply_pre,stmp_ins_ply)==0){

	            stmp[0]  = '\0';
	            if ((stmp_ins_ply_pre[0] != '\0')||(IsPlyChg == 0)){
	                strcat(stmp,INS_DELIMITER);
	            }
	            strcat(stmp,stmp_ins_type);     /* ex.    stmp          = ";4B"    */
	            strcpy(stmp_ins_type,stmp);     /* ex. => stmp_ins_type = ";4B"    */

	            strcat(stmp_ins_type_list,stmp_ins_type);        /* ex. "4A;4B"  */
                printf("stmp_ins_type_list=[%s]\n",stmp_ins_type_list);
                IsPlyChg = 0;

            }else{	 /* ���U�@�� ins_ply , ex. 24 --> 29 */

                code = Insert_CLAIM_INS(stmp_ins_type_list,stmp_ins_ply_pre,0,0.0,0.0,0.0,0,0,0,0.0,0.0,0,0);
                if (code!=SUCCESS) return code;

			    stmp_ins_type_list[0]='\0';
                strcpy(stmp_ins_type_list,stmp_ins_type);

                IsPlyChg = 1;
        	}
        }
        strcpy(stmp_ins_ply_pre,stmp_ins_ply);
        stmp_ins_type[0] = '\0';
     }
     /*************************************************************************/

     where_stat1[0]='\0';
     where_stat2[0]='\0';
     where_stat3[0]='\0';
     dZero = 0;
     qcount = 0;

     /*************************************************************************/
     /** keep �{�椧�U�I�����[�O�βv,�H��91�~4��1��H�e���O���p��«O�O���� */
     /** ���Hselect table ���覡�����H�קK�����[�O�Τ��վ�ӳy���B��        */
     /** �Y91�~4��1��H�e���O��椧���[�O�βv�����H�T�w                       */
     /** ��ƨӷ�:ca_rate, cover_vs_premium                                   */
     /*************************************************************************/
     for (iins_99=0 ; iins_99<100 ; iins_99++)
     {
         iins_loading[iins_99] = 0;
     }

     iins_loading[1]  = 0.345;
     iins_loading[2]  = 0.345;
     iins_loading[3]  = 0.345;
     iins_loading[5]  = 0.345;
     iins_loading[7]  = 0.345;
     iins_loading[8]  = 0.345;
     iins_loading[9]  = 0.345;
     iins_loading[11] = 0.345;
     iins_loading[12] = 0.345;
     iins_loading[17] = 0.345;
     iins_loading[18] = 0.345;
     iins_loading[19] = 0.345;
     iins_loading[24] = 0.347;
     iins_loading[30] = 0.347;
     iins_loading[33] = 0.240;
     iins_loading[14] = 0.220;
     iins_loading[15] = 0.336;
     iins_loading[16] = 0.336;
     iins_loading[31] = 0.347;
     iins_loading[32] = 0.347;
     iins_loading[47] = 0.240;
     iins_loading[51] = 0.347;
     iins_loading[52] = 0.347;
     iins_loading[53] = 0.347;
     iins_loading[61] = 0.25836;
     iins_loading[62] = 0.25836;
     iins_loading[63] = 0.25836;
     iins_loading[64] = 0.25836;
     iins_loading[65] = 0.25836;
     iins_loading[68] = 0.25836;
     iins_loading[69] = 0.25836;
     iins_loading[71] = 0.347;
     iins_loading[72] = 0.347;

     if (*pa.irule == '1')  /*** ���~�ר� ***/
     {
          /*** ���~�ר���N�L���p�⺡���O�O��ñ��O�O���O����簣�b�~ ***/
          sprintf(where_stat1, "AND a.dpolicy <= '%s' AND (a.dpolicy >= '%s' OR a.dply_end >= '%s') ",
                                 eDend, eDbgn, eDbgn);

          /*** ��~���� ***/
          sprintf(where_stat2, "AND a.dendorse <= '%s' AND (a.dendorse >= '%s' OR a.dedr_end >= '%s') ",
                                 eDend, eDbgn, eDbgn);

          /*** ��~��z�� ***/
          sprintf(where_stat3,"AND DATE(b.daccident) <= '%s'",eDend);
     }

     if (*pa.irule == '2')  /*** �O��~�ר� ***/
     {
          /*** �O���O�� ***/
          sprintf(where_stat1, "AND ((A.dpolicy >= '%s' OR A.dply_begin >= '%s') \
                                AND (A.dpolicy <= '%s' OR A.dply_begin <= '%s') AND A.dpolicy <= '%s')",
                                 eDbgn, eDbgn, eDend, eDend, eCalc_end);

          /*** �O����� ***/
          sprintf(where_stat2, "AND ((a.dendorse >= '%s' OR c.dply_begin >= '%s') \
                                AND (a.dendorse <= '%s' OR c.dply_begin <= '%s') AND a.dendorse <= '%s')",
                                eDbgn, eDbgn, eDend, eDend, eCalc_end);

          /*** �O���z�� ***/
          sprintf(where_stat3, "AND ((b.dply_begin >= '%s' AND b.dply_begin <= '%s') \
                                AND (DATE(a.daccident) >= '%s' AND DATE(a.daccident) <= '%s'))",
                                eDbgn, eDend, eDbgn, eCalc_end);
     }

/**************** �k�J�O��,���ν߮צU�q
     for(k=k_tmp;k<count_db;k++)
     {
          stmt[0] = '\0';
          sprintf(stmt,
          " SELECT a.ipolicy, a.fcard_class      \
              FROM %s:ori_ply_relation a,%s:original_ply b                  \
             WHERE a.ipolicy     = b.ipolicy                      \
               AND a.fcard_class = '2'                            \
                   %s %s %s %s %s",
           list[k].dbname,list[k].dbname,sWhere1,sWhere2,sWhere3,sWhere4,
           where_stat1);

          printf("{car1118_process.0004}:POLICY_STMT[%s]\n",stmt);

          EXEC SQL PREPARE PLY_TMP_INSERT FROM :stmt;
          EXEC SQL DECLARE ply_tmp_cur CURSOR FOR PLY_TMP_INSERT;
          EXEC SQL OPEN    ply_tmp_cur;
          for(;;)
          {
               EXEC SQL FETCH ply_tmp_cur INTO :ipolicy, :fcard_class;
               if (SQLCODE == SQLNOTFOUND) break;

               EXEC SQL INSERT INTO ca_loss_big_temp1
                                    (ipolicy,  fcard_class)
                             VALUES (:ipolicy, :fcard_class);

          }
          EXEC SQL CLOSE   ply_tmp_cur;
     }

     EXEC SQL SELECT count(*)
                INTO :count_2
                FROM ca_loss_big_temp1
               WHERE fcard_class = '2';
     printf("{car1118_process.0007}:���N�I��O�O����[%lf]\n",count_2);

     EXEC SQL UPDATE STATISTICS FOR TABLE ca_loss_big_temp1;
*********************/

     lt = time(NULL);
     printf("\n\n<<<<< Begin SELECT data From ori_ply_relation & ori_ins_type start time===>");
     printf(ctime(&lt));
     printf(">>>>>\n");
     mdeduct = 0;
     ideduct = 0;

     /******�O��*********/
     for(k=k_tmp;k<count_db;k++)
     {
         stmt[0]='\0';
         sprintf(stmt,
         " SELECT First 1 dedr_begin,dendorse,fedr_status,decode(mdeduct,0,0,1)        \
             FROM %s:ply_ins_type_hist   \
            WHERE ipolicy     = ?        \
              AND iins_type   = ?        \
              AND dedr_begin <= ?        \
              AND dendorse   <= ?        \
         ORDER BY dedr_begin DESC, dendorse DESC, fedr_status DESC ",list[k].dbname);
         $PREPARE hist_p FROM $stmt;

         stmt[0]='\0';
         sprintf(stmt,
         " SELECT First 1 dendorse,dedr_begin,fedr_status,decode(mdeduct,0,0,1)        \
             FROM %s:ply_ins_type_hist   \
            WHERE ipolicy     = ?        \
              AND iins_type   = ?        \
              AND dendorse   <= ?        \
         ORDER BY dendorse DESC, dedr_begin DESC, fedr_status DESC ",list[k].dbname);
         $PREPARE hist_p_ply FROM $stmt;

         stmt[0]='\0';

         /* 960129, �s�Wiresource���,�u�f���B ��� */
         sprintf(stmt,
         " SELECT a.ipolicy  , a.fcard_class, a.dply_begin, a.dply_end,                             \
                  c.iins_type, a.iresource, a.iquota     , a.iofficer  , NVL(b.iassured,' '),  NVL(b.nuser,' '), \
                  a.icar_type, a.ibrand[1,6], a.icar_flag , b.itag,                                 \
                  c.mins_premium, c.mpure_prem, c.mcommission+c.magent, c.mprem,                    \
                  a.mlia_prem, a.dpolicy , a.madjcom_prem, NVL(a.icorps,' '),c.mdiscount   \
             FROM %s:ori_ply_relation a,%s:ori_ins_type c,%s:original_ply b \
            WHERE a.ipolicy = b.ipolicy  \
              AND a.ipolicy = c.ipolicy  \
		  %s %s %s %s %s         \
            ORDER BY 1  ",list[k].dbname,list[k].dbname,list[k].dbname,
            where_stat1,sWhere1,sWhere2,sWhere3,sWhere4);

         EXEC SQL PREPARE PLY_CUR FROM :stmt;
         EXEC SQL DECLARE loss_ply_cur CURSOR FOR PLY_CUR;

         printf("{car1118_process.0009}:stmt[%s]\n",stmt);

         EXEC SQL OPEN loss_ply_cur;
         for(;;)
         {
              EXEC SQL FETCH loss_ply_cur INTO
                   :ipolicy,      :fcard_class, :ldply_bgn,   :ldply_end,
                   :iins_type,    :iresource,   :Liquota,     :Liofficer,   :sIassured,
                   :sUser,        :Licar_type,  :Librand,     :Licar_flag,
                   :itag,
                   :mins_premium, :tmp_mpure_prem:id1, :tmp_mcommission,
                   :tmp_bef_inspremium, :tmp_pprem,    :t_dpolicy,
                   :Lmadjcom_prem, :iroute , :tmp_mdiscount;
              if (SQLCODE == SQLNOTFOUND) break;

              printf("ipolicy[%s]\n",ipolicy);

              if (strlen(trim(iroute)) == 0)
              {
                 $SELECT NVL(iroute,' ')
                    INTO $iroute
                    FROM officer
                   WHERE iofficer = $Liofficer;
                 if (SQLCODE == SQLNOTFOUND)
                 {
                    strcpy(iroute," ");
                 }
              }

              /* ñ�����b91�~9��1��H�e���O��A�g��H��[K:�ίq]�}�Y�̡A�^�k��g��H */
              if((t_dpolicy <= cm_ymd_cdate("91/09/02")) && (strncmp(trim(Liofficer),"K",1)==0))
              {
                   EXEC SQL SELECT iofficer_old
                              INTO :Liofficer_old
                              FROM collate_policy
                             WHERE ipolicy =  :ipolicy;
                   if (Liofficer_old[0] != ' ' && Liofficer_old[0] != '\0')
                   {
                       strcpy(Liofficer, trim(Liofficer_old));
                   }
              }

              if (id1 == -1)
                   tmp_mpure_prem = 0;

              iIins_type = atoi(iins_type);

              if (strcmp(trim(iins_type),"01") == 0 || strcmp(trim(iins_type),"201") == 0)
              {
                  ideduct_ply  = 1;
                  ideduct_full = 1;
              }
              else if (strcmp(trim(iins_type),"05") == 0 ||strcmp(trim(iins_type),"205") == 0)
              {
                   if ((*pa.irule == '2') || (*pa.irule == '3'))
                   {
                       $EXECUTE hist_p
                           INTO $dedr_begin_tp,$dendorse_tp,$fedr_status_tp,$ideduct_full
                          USING $ipolicy,$iins_type,$lCalc_end,$lCalc_end;
                   }
                   else
                   {
                       $EXECUTE hist_p
                           INTO $dedr_begin_tp,$dendorse_tp,$fedr_status_tp,$ideduct_full
                          USING $ipolicy,$iins_type,$lDend,$lDend;
                   }

                   if (SQLCODE == SQLNOTFOUND)
                   {
                       ideduct_full = 1;
                   }

                   if ((*pa.irule == '2') || (*pa.irule == '3'))
                   {
                       $EXECUTE hist_p_ply
                           INTO $dendorse_tp,$dedr_begin_tp,$fedr_status_tp,$ideduct_ply
                          USING $ipolicy,$iins_type,$lCalc_end;
                   }
                   else
                   {
                       $EXECUTE hist_p_ply
                           INTO $dendorse_tp,$dedr_begin_tp,$fedr_status_tp,$ideduct_ply
                          USING $ipolicy,$iins_type,$lDend;
                   }

                   if (SQLCODE == SQLNOTFOUND)
                   {
                      ideduct_ply = 0;
                      printf("ipolicy[%s] Can't find in ply_ins_type_hist\n",ipolicy);
                   }
              }
              else if (strcmp(trim(iins_type),"08") == 0)
              {
                   ideduct_ply  = 1;
                   ideduct_full = 1;
              }
              else if (strcmp(trim(iins_type),"09") == 0 || strcmp(trim(iins_type),"209") == 0)
              {
                   ideduct_ply  = 0;
                   ideduct_full = 0;
              }
              else
              {
                   ideduct_ply  = 0;
                   ideduct_full = 0;
              }

              /* tmp_pprem==>mlia_prem �j���I��ñ��O�O */
              /* tmp_pprem==>mins_premium ���N�I�U�I�ؤ�ñ��O�I�O */
              /* �j��d���I21�H�«O�O�p�⺡���O�I�O */
              if (strcmp(trim(iins_type),"21")==0)
              {
                   tmp_prem  = (double)Lmadjcom_prem;
                   tmp_mpure_prem = (double)Lmadjcom_prem;
              }
              else
              {
                   tmp_pprem = (double)mins_premium;
                   tmp_prem  = (double)mins_premium;
                   /* 91�~04��01�餧�eñ�o���O�I�涷�p��«O�O */
                   if (t_dpolicy < cm_ymd_cdate("91/04/01"))
                   {
                        /** ���u�ݫe�O�O�p�� **/
                        /** �«O�O�|�ˤ��J   **/
                        tmp_mpure_prem = (long)((double)tmp_bef_inspremium * (1-iins_loading[iIins_type]) + 0.5);
                   }
              }

              /*�p�⺡���O�O������� 365���k*/
              mfull = qfull = 0;
              cnt   = 1;
              tmp_mfull_pure = 0;

              if (*pa.irule == '1')   /*** ��~�� ***/
              {
                   if (ldply_bgn <= lDend && ldply_end >= lDbgn)
                   {
                       /*�p��O���g�L���϶��O�_���|�~�A�u���ŦX���p�⺡���O�O�������~���p��*/
                       leap_flag = check_leap_year(ldply_bgn, ldply_end);

                           /*** ñ�溡���O�O�κ�����Ƥ��p�� ***/
                           code=ca_calc_365_full(lDbgn, lDend, ldply_bgn, ldply_end,
                                                 tmp_prem, cnt,  &mfull, &qfull, leap_flag);
                           if (code != SUCCESS)
                           {
                               sprintf(msgbuf,"ca_calc_365_full.01 ERROR [%s][%s]", ipolicy,iins_type);
                               EXEC SQL WHENEVER SQLERROR CONTINUE;
                               return code;
                           }

                           /*** �����«O�I�O,�𶷭p���� ***/
                           code=ca_calc_365_full(lDbgn, lDend, ldply_bgn, ldply_end,
                                                 tmp_mpure_prem, cnt, &tmp_mfull_pure, &temp_data, leap_flag);
                           if (code != SUCCESS)
                           {
                               sprintf(msgbuf,"ca_calc_365_full.02 ERROR [%s][%s]", ipolicy,iins_type);
                               EXEC SQL WHENEVER SQLERROR CONTINUE;
                               return code;
                           }
                   }
              }

              if (*pa.irule == '2') /*** �O��� ***/
              {
                  /***** �i�O��ͮĤ���j����έp�������~�p�⺡���O�O *****/
                  if (ldply_bgn >= lDbgn && ldply_bgn <= lDend)
                  {
                      /*�p��O���g�L���϶��O�_���|�~�A�u���ŦX���p�⺡���O�O�������~���p��*/
                      leap_flag = check_leap_year(ldply_bgn, ldply_end);

                           /* ñ�溡���O�I�O���p�� */
                           code=ca_calc_365_full(lDbgn , lCalc_end , ldply_bgn , ldply_end,
                                                 tmp_prem , cnt , &mfull , &qfull , leap_flag);
                           if (code != SUCCESS)
                           {
                                sprintf(msgbuf,"ca_calc_365_full ERROR [%s][%s]",
                                               ipolicy,iins_type);
                                EXEC SQL WHENEVER SQLERROR CONTINUE;
                                return code;
                           }
                           /* �����«O�I�O���p�� */
                           code=ca_calc_365_full(lDbgn, lCalc_end, ldply_bgn, ldply_end,
                                                 tmp_mpure_prem, cnt, &tmp_mfull_pure, &temp_data, leap_flag);
                           if (code != SUCCESS)
                           {
                                sprintf(msgbuf,"ca_calc_365_full.02 ERROR [%s][%s]", ipolicy,iins_type);
                                EXEC SQL WHENEVER SQLERROR CONTINUE;
                                return code;
                           }
                  }
              }

              if (pa.imethod[0] == '2')
              {
                 if (ldply_bgn > lDend || ldply_bgn < lDbgn)
                 {
                    cnt = 0;
                    tmp_pprem = 0;
                    tmp_mpure_prem = 0;
                    tmp_mcommission = 0;
                    tmp_mdiscount = 0;
                 }
              }
              else
              {
                 /* ñ��O�O��ñ�������έp������ */
                 if (t_dpolicy > lDend || t_dpolicy < lDbgn)
                 {
                    cnt = 0;
                    tmp_pprem = 0;
                    tmp_mpure_prem = 0;
                    tmp_mcommission = 0;
                    tmp_mdiscount = 0;
                 }
              }

              EXEC SQL WHENEVER SQLERROR GOTO errexit;

              if (strcmp(trim(iins_type),"05") == 0 || strcmp(trim(iins_type),"205") == 0)
              {
                  if (ideduct_ply == ideduct_full)
                  {
                      EXEC SQL INSERT INTO ca_loss_info_temp2
                                      (ipolicy     , iins_type   , iquota      , iofficer   ,
                                       iroute      , iresource   , iassured    , nuser      , icar_type  ,
                                       ibrand      , icar_flag   , ideduct     , mdiscount  ,
                                       qprem       , mprem       , mpure_prem  , mcommission,
                                       qfull       , mfull       , mfull_pure  ,
                                       qend_outstl , qclaim      , mbgn_outstl , mend_outstl , mstl,
				                       itag        , dply_begin )
                               VALUES (:ipolicy    , :iins_type  , :Liquota    , :Liofficer  ,
                                       :iroute     , :iresource  , :sIassured  , :sUser      , :Licar_type ,
                                       :Librand    , :Licar_flag , :ideduct_ply, :tmp_mdiscount,
                                       :cnt        , :tmp_pprem  , :tmp_mpure_prem , :tmp_mcommission,
                                       :qfull      , :mfull      , :tmp_mfull_pure,
                                       0           , 0           , 0           , 0           , 0,
				                       :itag       , :ldply_bgn );
                  }
                  else
                  {
                          /* ñ�泡�� */
                      EXEC SQL INSERT INTO ca_loss_info_temp2
                                      (ipolicy     , iins_type   , iquota      , iofficer   ,
                                       iroute      , iresource   , iassured    , nuser      , icar_type  ,
                                       ibrand      , icar_flag   , ideduct     , mdiscount  ,
                                       qprem       , mprem       , mpure_prem  , mcommission,
                                       qfull       , mfull       , mfull_pure,
                                       qend_outstl , qclaim      , mbgn_outstl , mend_outstl , mstl,
				                       itag        , dply_begin )
                               VALUES (:ipolicy    , :iins_type  , :Liquota    , :Liofficer  ,
                                       :iroute     , :iresource   , :sIassured  , :sUser      , :Licar_type ,
                                       :Librand    , :Licar_flag , :ideduct_ply, :tmp_mdiscount,
                                       :cnt        , :tmp_pprem  , :tmp_mpure_prem , :tmp_mcommission,
                                       0           , 0           , 0           ,
                                       0           , 0           , 0           , 0           , 0,
				                       :itag       , :ldply_bgn );

                          /* �������� */
                      EXEC SQL INSERT INTO ca_loss_info_temp2
                                      (ipolicy     , iins_type   , iquota      , iofficer   ,
                                       iroute      , iresource   , iassured    , nuser      , icar_type  ,
                                       ibrand      , icar_flag   , ideduct     , mdiscount  ,
                                       qprem       , mprem       , mpure_prem  , mcommission,
                                       qfull       , mfull       , mfull_pure,
                                       qend_outstl , qclaim      , mbgn_outstl , mend_outstl , mstl,
				                       itag        , dply_begin )
                               VALUES (:ipolicy    , :iins_type  , :Liquota    , :Liofficer  ,
                                       :iroute     , :iresource   , :sIassured  , :sUser      , :Licar_type ,
                                       :Librand    , :Licar_flag , :ideduct_full,0,
                                       0           , 0           , 0           , 0 ,
                                       :qfull      , :mfull      , :tmp_mfull_pure,
                                       0           , 0           , 0           , 0           , 0,
				                       :itag       , :ldply_bgn );
                  }
              }
              else
              {
                      EXEC SQL INSERT INTO ca_loss_info_temp2
                                      (ipolicy     , iins_type   , iquota      , iofficer   ,
                                       iroute      , iresource   , iassured    , nuser      , icar_type  ,
                                       ibrand      , icar_flag   , ideduct     , mdiscount,
                                       qprem       , mprem       , mpure_prem  , mcommission,
                                       qfull       , mfull       , mfull_pure,
                                       qend_outstl , qclaim      , mbgn_outstl , mend_outstl , mstl,
				                       itag        , dply_begin )
                               VALUES (:ipolicy    , :iins_type  , :Liquota    , :Liofficer  ,
                                       :iroute     , :iresource   , :sIassured  , :sUser      , :Licar_type ,
                                       :Librand    , :Licar_flag , :ideduct_ply,:tmp_mdiscount,
                                       :cnt        , :tmp_pprem  , :tmp_mpure_prem , :tmp_mcommission,
                                       :qfull      , :mfull      , :tmp_mfull_pure,
                                       0           , 0           , 0           , 0           , 0,
				                       :itag       , :ldply_bgn );
              }
         }
         EXEC SQL CLOSE loss_ply_cur;
         EXEC SQL FREE  loss_ply_cur;
     }

     lt = time(NULL);
     printf("\n\n<<<<< END SELECT data From ori_ply_relation & ori_ins_type end time===>");
     printf(ctime(&lt));
     printf(">>>>>\n");

     total_count = 0;
     EXEC SQL SELECT count(*)
                INTO :total_count
                FROM ca_loss_info_temp2;
     printf("{car1118_process.0010}:Table ca_loss_info_temp2 total_count is [%ld]\n",total_count);

/*
     EXEC SQL UPDATE STATISTICS FOR TABLE ca_loss_info_temp2;
*/
     /******���*********/
     lt = time(NULL);
     printf("\n\n<<<<< Begin SELECT data From edr_relation & edr_ins_type start time===>");
     printf(ctime(&lt));
     printf(">>>>>\n");

     for(k=k_tmp;k<count_db;k++)
     {
         qfull = 0;
         tmp_edr_prem = 0;
         mfull = 0;

         stmt[0]='\0';
         EXEC SQL WHENEVER SQLERROR GOTO errexit;

         sprintf(stmt,
         " SELECT First 1 dedr_begin,dendorse,fedr_status,decode(mdeduct,0,0,1)   \
             FROM %s:ply_ins_type_hist   \
            WHERE ipolicy     = ?        \
              AND iins_type   = ?        \
              AND dedr_begin <= ?        \
              AND dendorse   <= ?        \
         ORDER BY dedr_begin DESC, dendorse DESC, fedr_status DESC ",list[k].dbname);
         $PREPARE hist_e FROM $stmt;

         sprintf(stmt,
         " SELECT First 1 dendorse,dedr_begin,fedr_status,decode(mdeduct,0,0,1)    \
             FROM %s:ply_ins_type_hist   \
            WHERE ipolicy     = ?        \
              AND iins_type   = ?        \
              AND dendorse   <= ?        \
         ORDER BY dendorse DESC, dedr_begin DESC, fedr_status DESC ",list[k].dbname);
         $PREPARE hist_e_ply FROM $stmt;

         sprintf(stmt,"SELECT %s %s %s %s %s FROM %s:%s %s:%s %s:%s WHERE %s %s %s %s %s %s %s %s %s ",
                      "a.iendorse, a.ipolicy, a.dedr_begin, a.dedr_end, nvl(a.iresource,' '), ",
                      "a.ibrand[1,6], a.icar_type, a.iofficer, a.iquota, c.iquota,",
                      "a.medr_adjcom, c.dply_begin, c.dply_end,",
                      "a.dendorse, a.medrlia_prem, b.itag,",
                      "c.dpolicy, c.icar_flag, NVL(a.icorps,' '), NVL(b.iassured,' '), NVL(b.nuser,' ') ",
                       list[k].dbname,"edr_relation a,",
                       list[k].dbname,"endorsement b,",
                       list[k].dbname,"ori_ply_relation c",
                      "a.ipolicy = c.ipolicy ",
                      "AND a.iendorse = b.iendorse ",
                      /*"AND a.fedr_class IN ('1','4','6','9','A') ",*/
                      "AND a.dedr_close is not null ",
                      sWhere5_a,where_stat2,sWhere1,sWhere2,sWhere3,sWhere4_clm);

         printf("{car1118_process.0011}:EDR_STMT[%s]\n",stmt);

         EXEC SQL PREPARE EDR_CUR FROM :stmt;
         EXEC SQL DECLARE loss_edr_cur CURSOR FOR EDR_CUR;


         /*--- 2.1 Ū�����Ҧ��I�ظ�� ---*/
         stmt[0]='\0';
         sprintf(stmt,"SELECT iins_type, iedr_type, medrins_prem, medrpure_prem, medr_prem, qcount,   \
                              medr_commission+medr_agent ,medr_discount                               \
                         FROM %s:%s                                                                   \
                        WHERE %s",
                       list[k].dbname,"edr_ins_type ", "iendorse = ? ");

         EXEC SQL PREPARE EINS_CUR FROM :stmt;
         EXEC SQL DECLARE loss_eins_cur CURSOR FOR EINS_CUR;

         printf("{car1118_process.0012}:EDR_INS_TYPE_STMT[%s]\n",stmt);

         EXEC SQL OPEN loss_edr_cur;
         for(;;)
         {
             EXEC SQL FETCH loss_edr_cur INTO :iendorse     , :ipolicy      , :ldedr_bgn  , :ldedr_end , :iresource,
                                              :Librand      , :Licar_type   , :Liofficer  , :Liquota   , :Piquota ,
                                              :Lmedr_adjcom , :ldply_bgn    , :ldply_end  ,
                                              :t_dendorse   , :tmp_eprem    , :itag       ,
                                              :t_dpolicy    , :Licar_flag   , :iroute     , :sIassured,  :sUser ;

             if (SQLCODE == SQLNOTFOUND) break;

             printf("iendorse[%s]-ipolicy[%s]\n",iendorse,ipolicy);

             if (strlen(trim(iroute)) == 0)
             {
                $SELECT NVL(iroute,' ')
                   INTO $iroute
                   FROM officer
                  WHERE iofficer = $Liofficer;
                if (SQLCODE == SQLNOTFOUND)
                {
                   strcpy(iroute," ");
                }
             }

             /* ñ�����b91�~9��1��H�e���O��A�g��H��[K:�ίq]�}�Y�̡A�^�k��g��H */
             if((t_dpolicy <= cm_ymd_cdate("91/09/02")) && (strncmp(trim(Liofficer),"K",1)==0))
             {
                  EXEC SQL SELECT iofficer_old
                             INTO :Liofficer_old
                             FROM collate_policy
                            WHERE ipolicy =  :ipolicy;
                  if (Liofficer_old[0] != ' ' && Liofficer_old[0] != '\0')
                  {
                      strcpy(Liofficer, trim(Liofficer_old));
                  }
             }

             if (id1 == -1)
                 tmp_mpure_prem = 0;

             EXEC SQL OPEN loss_eins_cur USING :iendorse;
             for(;;)
             {
                 EXEC SQL FETCH loss_eins_cur
                           INTO :iins_type, :iedr_type, :medrins_prem, :tmp_mpure_prem:id1,
                                :tmp_bef_inspremium, :qcount, :tmp_mcommission,:tmp_mdiscount;

                 if(SQLCODE == SQLNOTFOUND) break;

                 /* 960111,�����D�� fedr_class���z�����,��ѩ����ɿz���� */
                 /*
                 if ((medrins_prem==0)&&(tmp_mpure_prem==0)&&(tmp_bef_inspremium==0)&&
                     (qcount==0)&&(tmp_mcommission==0)){
                     continue;
                 }*/

                 iIins_type = atoi(iins_type);

                 if (strcmp(trim(iins_type),"01") == 0 || strcmp(trim(iins_type),"201") == 0)
                 {
                     ideduct_ply  = 1;
                     ideduct_full = 1;
                 }
                 else if (strcmp(trim(iins_type),"05") == 0 || strcmp(trim(iins_type),"205") == 0)
                 {
                     if ((*pa.irule == '2') || (*pa.irule == '3'))
                     {
                         $EXECUTE hist_e
                             INTO $dedr_begin_tp,$dendorse_tp,$fedr_status_tp,$ideduct_full
                            USING $ipolicy,$iins_type,$lCalc_end,$lCalc_end;
                     }
                     else
                     {
                         $EXECUTE hist_e
                             INTO $dedr_begin_tp,$dendorse_tp,$fedr_status_tp,$ideduct_full
                            USING $ipolicy,$iins_type,$lDend,$lDend;
                     }

                     if (SQLCODE == SQLNOTFOUND)
                     {
                         ideduct_full = 1;
                     }

                     if ((*pa.irule == '2') || (*pa.irule == '3'))
                     {
                         $EXECUTE hist_e_ply
                             INTO $dendorse_tp,$dedr_begin_tp,$fedr_status_tp,$ideduct_ply
                            USING $ipolicy,$iins_type,$lCalc_end;
                     }
                     else
                     {
                         $EXECUTE hist_e_ply
                             INTO $dendorse_tp,$dedr_begin_tp,$fedr_status_tp,$ideduct_ply
                            USING $ipolicy,$iins_type,$lDend;
                     }

                     if (SQLCODE == SQLNOTFOUND)
                     {
                        printf("ipolicy[%s] Can't find in ply_ins_type_hist\n",ipolicy);
                        ideduct_ply = 0;
                     }
                 }
                 else if (strcmp(trim(iins_type),"08") == 0)
                 {
                      ideduct_ply  = 1;
                      ideduct_full = 1;
                 }
                 else if (strcmp(trim(iins_type),"09") == 0 || strcmp(trim(iins_type),"209") == 0)
                 {
                      ideduct_ply  = 0;
                      ideduct_full = 0;
                 }
                 else
                 {
                      ideduct_ply  = 0;
                      ideduct_full = 0;
                 }

                 cnt = qcount;

                 /*�j��d���I[21]�H�«O�O�p��l���v*/
                 if (strcmp(trim(iins_type), "21")==0)
                 {
                     tmp_edr_prem   = (double)(Lmedr_adjcom);
                     tmp_mpure_prem = (double)(Lmedr_adjcom);
                 }
                 else
                 {
                     tmp_edr_prem = (double)(medrins_prem);
                     tmp_eprem    = (double)(medrins_prem);

                     /* 91�~04��01�餧�eñ�o���O�I�涷�p��«O�O */
                     if (t_dpolicy < cm_ymd_cdate("91/04/01"))
                     {
                         if (tmp_bef_inspremium > 0)
                         {
                              /** ���u�ݫe�O�O�p�� **/
                              tmp_mpure_prem = (long)((double)tmp_bef_inspremium * (1-iins_loading[iIins_type]) + 0.5);
                         }
                         else
                         {
                              /** ���u�ݫe�O�O�p�� **/
                              tmp_mpure_prem = (long)((double)tmp_bef_inspremium * (1-iins_loading[iIins_type]) - 0.5);
                         }
                     }
                 }

                 mfull=qfull=0;
                 tmp_mfull_pure = 0;

                 if (*pa.irule == '1')   /***** ���~�ר� *****/
                 {
                     /*�p�⺡���O�O������� 365���k*/
                     if (ldedr_bgn <= lDend && ldedr_end >= lDbgn)
                     {
                         /*�p��O���g�L���϶��O�_���|�~�A�u���ŦX���p�⺡���O�O�������~���p��*/
                         leap_flag = check_leap_year(ldply_bgn, ldply_end);

                              /* ñ�溡���O�I�O���p�� */
                              code=ca_calc_365_full(lDbgn, lDend, ldedr_bgn, ldedr_end,
                                                    tmp_edr_prem, cnt,  &mfull, &qfull, leap_flag);
                              if (code != SUCCESS)
                              {
                                  sprintf(msgbuf,"endorse ca_calc_365_full ERROR [%s][%s]", iendorse ,iins_type);
                                  EXEC SQL WHENEVER SQLERROR CONTINUE;
                                  return code;
                              }

                              /* �����«O�I�O���p�� */
                              code=ca_calc_365_full(lDbgn, lDend, ldedr_bgn, ldedr_end,
                                                    tmp_mpure_prem, cnt,  &tmp_mfull_pure, &temp_data, leap_flag);
                              if (code != SUCCESS)
                              {
                                  sprintf(msgbuf,"endorse ca_calc_365_full ERROR [%s][%s]", iendorse ,iins_type);
                                  EXEC SQL WHENEVER SQLERROR CONTINUE;
                                  return code;
                              }
                     }
                 }

                 if (*pa.irule == '2')   /*** �O��~�ר� ***/
                 {
                     if (ldply_bgn >= lDbgn && ldply_bgn <= lDend)
                     {
                         /*�p��O���g�L���϶��O�_���|�~�A�u���ŦX���p�⺡���O�O�������~���p��*/
                         leap_flag = check_leap_year(ldply_bgn, ldply_end);

                             /* ñ�溡���O�I�O���p�� */
                              code=ca_calc_365_full(lDbgn, lCalc_end, ldedr_bgn, ldedr_end,
                                                    tmp_edr_prem, cnt, &mfull, &qfull, leap_flag);
                              if (code != SUCCESS)
                              {
                                  sprintf(msgbuf,"endorse ca_calc_365_full ERROR [%s][%s]",
                                                 iendorse ,iins_type);
                                  EXEC SQL WHENEVER SQLERROR CONTINUE;
                                  return code;
                              }
                              /* �����«O�I�O���p�� */
                              code=ca_calc_365_full(lDbgn, lCalc_end, ldedr_bgn, ldedr_end,
                                                    tmp_mpure_prem, cnt, &tmp_mfull_pure, &temp_data, leap_flag);
                              if (code != SUCCESS)
                              {
                                  sprintf(msgbuf,"endorse ca_calc_365_full ERROR [%s][%s]", iendorse ,iins_type);
                                  EXEC SQL WHENEVER SQLERROR CONTINUE;
                                  return code;
                              }
                     }
                 }

                 printf("pa.imethod[%s],ldply_bgn[%ld],lDbgn[%ld],lDend[%ld]\n",pa.imethod,ldply_bgn,lDbgn,lDend);

                 printf("ipolicy[%s],iendorse[%s]\n",ipolicy,iendorse);

                 if (pa.imethod[0] == '2')
                 {
                    if (ldply_bgn > lDend || ldply_bgn < lDbgn)
                    {
                        cnt       = 0;
                        tmp_eprem = 0;
                        tmp_mpure_prem = 0;
                        tmp_mcommission = 0;
                        tmp_mdiscount = 0;
                    }
                 }
                 else
                 {
                    /* ñ��O�O��ñ�������έp������ */
                    if(t_dendorse > lDend || t_dendorse < lDbgn)
                    {
                    	printf("-- ipolicy[%s],iendorse[%s]--\n",ipolicy,iendorse);
                    	printf("-- lDend[%ld],t_dendorse[%ld],lDbgn[%ld]--\n",lDend,t_dendorse,lDbgn);
                        cnt       = 0;
                        tmp_eprem = 0;
                        tmp_mpure_prem = 0;
                        tmp_mcommission = 0;
                        tmp_mdiscount = 0;
                    }
                 }

                 /* 960111,�����D�� fedr_class���z�����,��ѩ����ɿz���� */
                 if ((medrins_prem==0)&&(tmp_mpure_prem==0)&&(tmp_bef_inspremium==0)&&
                     (qcount==0)&&(tmp_mcommission==0)&&(tmp_mdiscount==0)){
                     continue;
                 }

                 strcpy(Liquota, trim(Liquota));
                 strcpy(Piquota, trim(Piquota));

                 /* �s���P���줣�P   �B   �ۭt�B�ۦP��  */
                 if ((strcmp(Liquota,Piquota) != 0) && (ideduct_ply == ideduct_full))
                 {
                     /* ñ��O�O�k�s��� */
                     code = ca_loss_upd_InfoTable_prem(ipolicy    , Liquota    , Liofficer  ,
                                                       Licar_flag , Librand    , Licar_type ,
                                                       iins_type  , ideduct_ply,
                                                       sIassured  , sUser      , iroute,
                                                       cnt        , tmp_eprem  , tmp_mpure_prem , tmp_mcommission,
                                                       dZero      , dZero      , dZero,
						                               itag       , ldedr_bgn  , iresource, tmp_mdiscount);
                     if (code != SUCCESS)
                     {
                         sprintf(msgbuf,"ca_loss_upd_InfoTable_prem ERROR [%s]", ipolicy);
                         EXEC SQL WHENEVER SQLERROR CONTINUE;
                         return code;
                     }

                     /* �����O�O�k���� */
                     code = ca_loss_upd_InfoTable_prem(ipolicy    , Piquota    , Liofficer  ,
                                                       Licar_flag , Librand    , Licar_type ,
                                                       iins_type  , ideduct_ply,
                                                       sIassured  , sUser      , iroute,
                                                       dZero      , dZero      , dZero      , dZero ,
                                                       qfull      , mfull      , tmp_mfull_pure,
						                               itag       , ldedr_bgn  , iresource, tmp_mdiscount);

                     if (code != SUCCESS)
                     {
                         sprintf(msgbuf,"ca_loss_upd_InfoTable_prem ERROR [%s]", ipolicy);
                         EXEC SQL WHENEVER SQLERROR CONTINUE;
                         return code;
                     }
                 }
                 /* �s���P���줣�P   �B   �ۭt�B���ۦP��  */
                 else if ((strcmp(Liquota,Piquota) != 0) && (ideduct_ply != ideduct_full))
                 {
                     /* ñ��O�O�k�s��� */
                     code = ca_loss_upd_InfoTable_prem(ipolicy    , Liquota    , Liofficer  ,
                                                       Licar_flag , Librand    , Licar_type ,
                                                       iins_type  , ideduct_ply    ,
                                                       sIassured  , sUser      , iroute,
                                                       cnt        , tmp_eprem  , tmp_mpure_prem , tmp_mcommission,
                                                       dZero      , dZero      , dZero,
						                               itag       , ldedr_bgn  , iresource, tmp_mdiscount);
                     if (code != SUCCESS)
                     {
                         sprintf(msgbuf,"ca_loss_upd_InfoTable_prem ERROR [%s]", ipolicy);
                         EXEC SQL WHENEVER SQLERROR CONTINUE;
                         return code;
                     }

                     /* �����O�O�k���� */
                     code = ca_loss_upd_InfoTable_prem(ipolicy    , Piquota    , Liofficer  ,
                                                       Licar_flag , Librand    , Licar_type ,
                                                       iins_type  , ideduct_full    ,
                                                       sIassured  , sUser      , iroute,
                                                       dZero      , dZero      , dZero      , dZero ,
                                                       qfull      , mfull      , tmp_mfull_pure,
						                               itag       , ldedr_bgn  , iresource, tmp_mdiscount);

                     if (code != SUCCESS)
                     {
                         sprintf(msgbuf,"ca_loss_upd_InfoTable_prem ERROR [%s]", ipolicy);
                         EXEC SQL WHENEVER SQLERROR CONTINUE;
                         return code;
                     }
                 }
                 /* �s���P����ۦP   �B   �ۭt�B���ۦP��  */
                 else if ((strcmp(Liquota,Piquota) == 0) && (ideduct_ply != ideduct_full))
                 {
                     /* ñ��O�O�k�s��� */
                     code = ca_loss_upd_InfoTable_prem(ipolicy    , Liquota    , Liofficer  ,
                                                       Licar_flag , Librand    , Licar_type ,
                                                       iins_type  , ideduct_ply    ,
                                                       sIassured  , sUser      , iroute,
                                                       cnt        , tmp_eprem  , tmp_mpure_prem , tmp_mcommission,
                                                       dZero      , dZero      , dZero,
						                               itag       , ldedr_bgn  , iresource, tmp_mdiscount);
                     if (code != SUCCESS)
                     {
                         sprintf(msgbuf,"ca_loss_upd_InfoTable_prem ERROR [%s]", ipolicy);
                         EXEC SQL WHENEVER SQLERROR CONTINUE;
                         return code;
                     }

                     /* �����O�O�k���� */
                     code = ca_loss_upd_InfoTable_prem(ipolicy    , Liquota    , Liofficer  ,
                                                       Licar_flag , Librand    , Licar_type ,
                                                       iins_type  , ideduct_full    ,
                                                       sIassured  , sUser      , iroute,
                                                       dZero      , dZero      , dZero      , dZero ,
                                                       qfull      , mfull      , tmp_mfull_pure,
						                               itag       , ldedr_bgn  , iresource, tmp_mdiscount);

                     if (code != SUCCESS)
                     {
                         sprintf(msgbuf,"ca_loss_upd_InfoTable_prem ERROR [%s]", ipolicy);
                         EXEC SQL WHENEVER SQLERROR CONTINUE;
                         return code;
                     }

                 }
                 /* ��L */
                 else
                 {
                     code = ca_loss_upd_InfoTable_prem(ipolicy    , Liquota    , Liofficer  ,
                                                       Licar_flag , Librand    , Licar_type ,
                                                       iins_type  , ideduct_ply    ,
                                                       sIassured  , sUser      , iroute,
                                                       cnt        , tmp_eprem  , tmp_mpure_prem , tmp_mcommission ,
                                                       qfull      , mfull      , tmp_mfull_pure,
						                               itag       , ldedr_bgn  , iresource, tmp_mdiscount);
                     if (code != SUCCESS)
                     {
                         sprintf(msgbuf,"ca_loss_upd_InfoTable_prem ERROR [%s]", ipolicy);
                         EXEC SQL WHENEVER SQLERROR CONTINUE;
                         return code;
                     }
                 }
                 printf("ipolicy[%s],tmp_eprem[%f]\n",ipolicy,tmp_eprem);
             }
             EXEC SQL CLOSE loss_eins_cur;
         }
         EXEC SQL CLOSE loss_edr_cur;
         EXEC SQL FREE  loss_edr_cur;
         EXEC SQL FREE  loss_eins_cur;
     }

     printf("\n\nEND SELECT data From edr_relation & edr_ins_type end time===>");
     printf(ctime(&lt));
     printf("\n");

     /********�߮�*********/
     lt = time(NULL);
     printf("\n\n<<<<< Begin SELECT data From Claim Table start time===>");
     printf(ctime(&lt));
     printf(">>>>>\n");

     for(k=k_tmp;k<count_db;k++)
     {
          /*--- 960205,Ū���I���u�f���B��� ---*/
          stmt[0]='\0';
          EXEC SQL WHENEVER SQLERROR GOTO errexit;

          sprintf(stmt,"SELECT %s FROM %s:%s WHERE %s %s ",
                       "nvl(mdiscount,0)",
                       list[k].dbname,
                       "ori_ins_type",
                       " ipolicy = ?",
                       " AND iins_type = ?" );
          EXEC SQL PREPARE Get_mdisc FROM :stmt;



          /*--- Ū���߮��I�ظ��==> ���N�I ---*/
          stmt[0]='\0';
          sprintf(stmt,"SELECT %s FROM %s:%s WHERE %s ",
          "iins_type,dappraisal,mins_app+mproc_app,mdamage_cover,mplace_app ",
                       list[k].dbname,"app_ins_type",
                       "iclaim = ?");
          EXEC SQL PREPARE APPINS_CUR FROM :stmt;
          EXEC SQL DECLARE loss_appins_cur CURSOR FOR APPINS_CUR;

          printf("{car1118_process.0013}:APP_INS_TYPE_STMT[%s]\n",stmt);

          /*--- Ū���߮��I�ظ��==> �j���I ---*/
          stmt[0]= '\0';
          sprintf(stmt,"SELECT %s FROM %s:%s WHERE %s ",
                       "iins_item, ivictim, dappraisal, mapp_cover+mapp_fee ",
                       list[k].dbname,"ca_app_victim ",
                       "iclaim = ? ");
          EXEC SQL PREPARE APPVIC_CUR FROM :stmt;
          EXEC SQL DECLARE loss_appvic_cur CURSOR FOR APPVIC_CUR;

          printf("{car1118_process.0014}:CA_APP_VICTIM_STMT[%s]\n",stmt);

          /*--- 4. ���~�׹w�����-==> ���N�I   */
          stmt[0]= '\0';
          sprintf(stmt,"SELECT First 1 %s FROM %s:%s WHERE %s %s %s ",
                       "dappraisal, mins_app+mproc_app, mplace_app ",
                       list[k].dbname,"app_ins_type_hist",
                       "iclaim = ? AND iins_type = ?",
                       "AND dappraisal < ?",
                       "ORDER BY dappraisal Desc ");
          printf("Voluntary_hist[%s]\n",stmt);
          EXEC SQL PREPARE loss_appins_bgn FROM :stmt;

          stmt[0]= '\0';
          sprintf(stmt,"SELECT First 1 %s FROM %s:%s WHERE %s %s %s ",
                       "dappraisal, mins_app+mproc_app, mplace_app ",
                       list[k].dbname,"app_ins_type_hist",
                       "iclaim = ? AND iins_type = ?",
                       "AND dappraisal <= ?",
                       "ORDER BY dappraisal Desc ");
          printf("Voluntary_hist[%s]\n",stmt);
          EXEC SQL PREPARE loss_appins_end FROM :stmt;

          /*--- 4. ���~�׹w�����-==> �j���I   */
          stmt[0]= '\0';
          sprintf(stmt,"SELECT First 1 %s FROM %s:%s WHERE %s %s %s ",
                       "iins_item, ivictim, dappraisal, mapp_cover+mapp_fee ",
                       list[k].dbname,"ca_app_victim_hist",
                       "iclaim = ? AND iins_item =?",
                       "AND ivictim =? AND dappraisal < ?",
                       "ORDER BY dappraisal Desc ");
          printf("Compulsory_hist[%s]\n",stmt);
          EXEC SQL PREPARE loss_appvic_bgn FROM :stmt;

          stmt[0]= '\0';
          sprintf(stmt,"SELECT First 1 %s FROM %s:%s WHERE %s %s %s ",
                       "iins_item, ivictim, dappraisal, mapp_cover+mapp_fee ",
                       list[k].dbname,"ca_app_victim_hist",
                       "iclaim = ? AND iins_item =?",
                       "AND ivictim =? AND dappraisal <= ?",
                       "ORDER BY dappraisal Desc ");
          printf("Compulsory_hist[%s]\n",stmt);
          EXEC SQL PREPARE loss_appvic_end FROM :stmt;

          stmt[0]= '\0';
          sprintf(stmt,
          " SELECT First 1 dedr_begin,dendorse,fedr_status,mdeduct        \
              FROM %s:ply_ins_type_hist   \
             WHERE ipolicy     = ?        \
               AND iins_type   = ?        \
               AND dedr_begin <= ?        \
               AND dendorse   <= ?        \
               AND dedr_end   >= ?        \
          ORDER BY dedr_begin DESC, dendorse DESC, fedr_status DESC ",list[k].dbname);
          $PREPARE hist_c FROM $stmt;

          /**** �ߴڲέp ****/
          stmt[0]='\0';
          sprintf(stmt,"SELECT %s %s %s %s %s FROM %s:%s %s:%s %s:%s WHERE %s %s %s %s %s %s %s %s",
                       "a.iclaim, a.fcard_class, a.ipolicy, ",
                       "b.icar_type, b.dply_begin, b.dply_end, ",
                       "b.iofficer, DATE(b.daccident), b.ibrand[1,6], ",
                       "c.iquota, c.dpolicy, c.icar_flag,NVL(b.icorps,' '),c.iresource,",
                       "NVL(b.iassured,' '),NVL(b.nuser,' '),NVL(b.itag,' '),NVL(b.nassured[1,20],' ')",
                       list[k].dbname,"appraisal a, ",
                       list[k].dbname,"adjustment_ply b, ",
                       list[k].dbname,"ori_ply_relation c ",
                       "a.iclaim = b.iclaim ",
                       "AND a.ipolicy = c.ipolicy ",
                       sWhere5_b,where_stat3,sWhere1_clm,sWhere2,sWhere3_clm,sWhere4_clm);
          EXEC SQL PREPARE CLM_CUR FROM :stmt;
          EXEC SQL DECLARE loss_clm_cur CURSOR FOR CLM_CUR;

          printf("{car1118_process.0015}:APPRAISAL_STMT[%s]\n",stmt);

          EXEC SQL OPEN loss_clm_cur;
          for(;;)
          {
              EXEC SQL FETCH loss_clm_cur INTO :iclaim     , :fcard_class , :ipolicy    ,
                                               :Licar_type , :ldply_bgn   , :ldply_end  ,
                                               :Liofficer  , :daccident   , :Librand    ,
                                               :Liquota    , :t_dpolicy   , :Licar_flag ,
                                               :iroute     , :iresource   , :sIassured   , :sUser      ,
					                           :itag       , :nassured    ;
              if (SQLCODE == SQLNOTFOUND) break;
              /*printf("iclaim[%s]\n",iclaim);*/

              sprintf(stmt,
              " SELECT nequipment        \
                  FROM conv_nequipment   \
                 WHERE ipolicy = ? ");
              $PREPARE get_nequip FROM $stmt;
              $EXECUTE get_nequip
                  INTO $nequipment
                 USING $ipolicy;
              if (SQLCODE == SQLNOTFOUND)
              {
                 strcpy(nequipment," ");
              }

              if (strlen(trim(iroute)) == 0)
              {
                 $SELECT NVL(iroute,' ')
                    INTO $iroute
                    FROM officer
                   WHERE iofficer = $Liofficer;
                 if (SQLCODE == SQLNOTFOUND)
                 {
                    strcpy(iroute," ");
                 }
              }

              strncpy(Ipolicy12,ipolicy,2);
              Ipolicy12[2] = '\0';

              EXEC SQL SELECT iupcomp
                         INTO :DBName1
                         FROM branch
                        WHERE ibranch = :Ipolicy12;

              /* ñ�����b91�~9��1��H�e���O��A�g��H��[K:�ίq]�}�Y�̡A�^�k��g��H */
              if((t_dpolicy <= cm_ymd_cdate("91/09/02")) && (strncmp(trim(Liofficer),"K",1)==0))
              {
                   EXEC SQL SELECT iofficer_old
                              INTO :Liofficer_old
                              FROM collate_policy
                             WHERE ipolicy =  :ipolicy;
                   if (Liofficer_old[0] != ' ' && Liofficer_old[0] != '\0')
                   {
                       strcpy(Liofficer, trim(Liofficer_old));
                   }
              }

              /****** ���N�I *****/
              if (fcard_class[0]=='2')
              {
              	    /*** �ߴ��I��93�B94�B95�H31�I�ج����A�G�������w�M�A�Y���@���M�h�����M ***/
				    Icurr_CLM=Ifirst_CLM;
				    while (Icurr_CLM)
				    {
					 	Icurr_CLM->flag_ins_type            = 0 ;
					 	Icurr_CLM->tmp_ins_ply_mbgn         = 0 ;
					 	Icurr_CLM->tmp_ins_ply_mend         = 0 ;
					 	Icurr_CLM->tmp_ins_ply_mstl         = 0 ;
					 	Icurr_CLM->qbgn_outstl_ins_type     = 0 ;  /*** ���쥼�M�ߴڥ�� ***/
					 	Icurr_CLM->qend_outstl_ins_type     = 0 ;  /*** �������M�ߴڥ�� ***/
					 	Icurr_CLM->qclaim_ins_type          = 0 ;  /*** �w���׽ߴڥ��   ***/
					 	Icurr_CLM->tmp_ins_ply_mstl_dend    = 0 ;
					 	Icurr_CLM->tmp_ins_ply_mstl_dbgn    = 0 ;
					 	Icurr_CLM->flag_ins_ply_close_dbgn  = 1 ;
					 	Icurr_CLM->flag_ins_ply_close_dend  = 1 ;

                        Icurr_CLM = Icurr_CLM->next;
				   }

                   tmp_mstl_dbgn = tmp_mstl_dend = 0;

                   EXEC SQL OPEN loss_appins_cur USING :iclaim;
                   for(;;)
                   {
                       EXEC SQL FETCH loss_appins_cur INTO
                            :iins_type, :dappraisal,:mins_app,:mdamage_cover,
                            :mplace_app;
                       if (SQLCODE == SQLNOTFOUND) break;

                       /** Ū�����v��� : �ܴ����I��� : �ܴ����I��� ==> ���o�̫�@���w�����B�H�p��������M���B **/
                       EXEC SQL EXECUTE loss_appins_end
                                   INTO :dappraisal, :mins_app, :mplace_app
                                  USING :iclaim, :iins_type, :lDhist_end;
                       if (SQLCODE == SQLNOTFOUND)
                       {
                           /* ��������v�ɧ䤣����ܩ�I���e�|���w�� */
                           continue;
                       }

                       if (strcmp(trim(iins_type),"01") == 0 || strcmp(trim(iins_type),"201") == 0)
                       {
                           ideduct = 1;
                       }
                       else if (strcmp(trim(iins_type),"05") == 0 || strcmp(trim(iins_type),"205") == 0)
                       {
                            if ((*pa.irule == '2') || (*pa.irule == '3'))
                            {
                                $EXECUTE hist_c
                                        INTO $dedr_begin_tp,$dendorse_tp,$fedr_status_tp,$mdeduct
                                   USING $ipolicy,$iins_type,$daccident,$lCalc_end,$daccident;
                                }
                            else
                            {
                                $EXECUTE hist_c
                                        INTO $dedr_begin_tp,$dendorse_tp,$fedr_status_tp,$mdeduct
                                   USING $ipolicy,$iins_type,$daccident,$lDend,$daccident;
                            }

                            if (SQLCODE == SQLNOTFOUND)
                            {
                                mdeduct = 1;
                            }

                            if (mdeduct == 0)
                            {
                                ideduct = 0;
                            }
                            else
                            {
                                ideduct = 1;
                            }
                       }
                       else if (strcmp(trim(iins_type),"08") == 0)
                       {
                            ideduct = 1;
                       }
                       else if (strcmp(trim(iins_type),"09") == 0 || strcmp(trim(iins_type),"209") == 0)
                       {
                            ideduct = 0;
                       }
                       else
                       {
                            ideduct = 0;
                       }

                       qclaim          = 0;
                       tmp_qclaim      = 0;
                       tmp_qbgn_outstl = 0;
                       tmp_qend_outstl = 0;
                       tmp_mstl_dbgn      = 0;
                       tmp_mstl_dend      = 0;
                       dc_close[0]     = '\0';

	               if (pa.irule[0] == '1')
		       {
                          sprintf(stmt,
                          " SELECT NVL(SUM(mins_stl),0)+NVL(SUM(mins_proc),0),   \
                                   MAX(dclose) \
                              FROM %s:stl_ins_type                               \
                             WHERE iclaim    = ?                                 \
                               AND iins_type = ?                                 \
			       AND dgroup   >= '%s'                              \
                               AND dgroup   <= '%s'                              \
                               AND fstl      = '1' ",list[k].dbname,eDbgn,eDtrue);
                          /* 950322 Ū���N���O�� */
                          sprintf(stmt1,
                          " select nvl(sum(mplace_fee),0) \
                              from %s:settlement        \
                             where iclaim = ?           \
			       and dgroup   >= '%s'     \
                               and dgroup   <= '%s'     \
                               and fstl      = '1'      ",
                               list[k].dbname,eDbgn,eDtrue);

		       }
		       else
		       {
                          sprintf(stmt,
                          " SELECT NVL(SUM(mins_stl),0)+NVL(SUM(mins_proc),0),   \
                                   MAX(dclose) \
                              FROM %s:stl_ins_type                               \
                             WHERE iclaim    = ?                                 \
                               AND iins_type = ?                                 \
                               AND dgroup   <= '%s'                              \
                               AND fstl      = '1' ",list[k].dbname,eDtrue);
                          /* 950322 Ū���N���O�� */
                          sprintf(stmt1,
                          " select nvl(sum(mplace_fee),0) \
                              from %s:settlement        \
                             where iclaim = ?           \
                               and dgroup   <= '%s'     \
                               and fstl      = '1'      ",
                               list[k].dbname,eDtrue);
                       }

                       $PREPARE get_ins_dtl_1 FROM $stmt;
                       $EXECUTE get_ins_dtl_1
                           INTO $mins_stl_1, $dc_close
                          USING $iclaim,$iins_type;

                       $PREPARE get_mplace_1 FROM $stmt1;
                       $EXECUTE get_mplace_1
                           INTO $mplace_fee_1
                          USING $iclaim;

      	               if (pa.irule[0] == '1')
		       {
                           sprintf(stmt,
                           " SELECT NVL(SUM(mins_stl),0)-NVL(SUM(mins_proc),0)    \
                               FROM %s:stl_ins_type                 \
                              WHERE iclaim    = ?                   \
                                AND iins_type = ?                   \
				AND dgroup   >= '%s'                \
                                AND dgroup   <= '%s'                \
                                AND fstl      = '2' ",list[k].dbname,eDbgn,eDtrue);
		       }
		       else
		       {
                           sprintf(stmt,
                           " SELECT NVL(SUM(mins_stl),0)-NVL(SUM(mins_proc),0) \
                               FROM %s:stl_ins_type                 \
                              WHERE iclaim    = ?                   \
                                AND iins_type = ?                   \
                                AND dgroup   <= '%s'                \
                                AND fstl      = '2' ",list[k].dbname,eDtrue);
                       }

                       $PREPARE get_ins_dtl_2 FROM $stmt;
                       $EXECUTE get_ins_dtl_2
                           INTO $mins_stl_2
                          USING $iclaim,$iins_type;

                       printf("car1118_insert_stl ipolicy[%s],iclaim[%s],iins_type[%s]\n",
                                                  ipolicy,iclaim,iins_type);

                       /****** �i����ߴڡj                     ******************/
                       /****** �p��ܲέp�_�餧�֭p[[�w�M]]�ߴڪ��B ******************/
                       code = ca_calc_info_msettle(DBName1        , fcard_class     ,
                                                   iclaim         , iins_type       ,
                                                   " "            , lDbgn           ,
                                                   &tmp_mstl_dbgn , &flag_close_dbgn);
                       if (code != SUCCESS)
                       {
                           sprintf(msgbuf,"ca_calc_info_msettle([%s],[%s]) ERR", iclaim,iins_type);
                           EXEC SQL WHENEVER SQLERROR CONTINUE;
                           return code;
                       }

                       /****** �p��ܴ���I��餧�֭p�w�����B     ****************/
                       /*printf("before loss_appins_begin[%s]\n",iclaim);*/

                       EXEC SQL EXECUTE loss_appins_bgn
                                INTO :dappraisal_bgn,:mins_app_bgn,:mplace_app
                                USING :iclaim, :iins_type, :lDhist_bgn;
                       if (SQLCODE == SQLNOTFOUND)
                       {
                           dappraisal_bgn = 0;
                           mins_app_bgn = 0;
                       }

                       /****** �i�����ߴڡj                     ******************/
                       /**********************************************************/
                       /****** �p��ܲέp����έp�����餧�֭p�w�M�ߴڪ��B ******/
                       if (*pa.irule == '1')   /*** ���~�ר�����w�M�ߴڪ��B ***/
                       {
                           code = ca_calc_info_msettle(DBName1        , fcard_class    ,
                                                       iclaim         , iins_type      ,
                                                       " "            , lDend          ,
                                                       &tmp_mstl_dend , &flag_close_dend);

                           if (code != SUCCESS)
                           {
                               sprintf(msgbuf,"ca_calc_info_msettle([%s],[%s]) ERR",iclaim,iins_type);
                               EXEC SQL WHENEVER SQLERROR CONTINUE;
                               return code;
                           }
                       }
                       else
                       {
                           code = ca_calc_info_msettle(DBName1        , fcard_class    ,
                                                       iclaim         , iins_type      ,
                                                       " "            , lCalc_end     ,
                                                       &tmp_mstl_dend , &flag_close_dend);

                           if (code != SUCCESS)
                           {
                               sprintf(msgbuf,"ca_calc_info_msettle([%s],[%s]) ERR",iclaim,iins_type);
                               EXEC SQL WHENEVER SQLERROR CONTINUE;
                               return code;
                           }
                       }

                       /**********************************************************/
                       /**********************************************************/
                       /* �p��ߴڪ��B, �w�M�ߴ�, �������M�ߴ�, ���쥼�M�ߴ�     */
                       /**********************************************************/
                       code = ca_calc_info_payment(daccident, dappraisal_bgn,
                                                   mins_app, mins_app_bgn,
                                                   flag_close_dend, flag_close_dbgn,
                                                   tmp_mstl_dend  , tmp_mstl_dbgn,
                                                   lDbgn,
                                                   &tmp_mpayment,
                                                   &tmp_mstl,
                                                   &tmp_mbgn_outstl,
                                                   &tmp_mend_outstl);
                       if (code != SUCCESS)
                       {
                           sprintf(msgbuf,"ca_calc_info_payment([%s][%s]) ERROR",iclaim,iins_type);
                           EXEC SQL WHENEVER SQLERROR CONTINUE;
                           return code;
                       }

                       moutstand = tmp_mend_outstl - tmp_mbgn_outstl;

                       printf("mins_stl_1[%f],mins_proc_1[%f]\n",mins_stl_1,mins_proc_1);
                       printf("mins_stl_2[%f],mins_proc_2[%f]\n",mins_stl_2,mins_proc_2);
                       strcpy(factory," ");
                       /* 950323 �W�[�N���O�ΤΫO�׼t */
                       if (strcmp(trim(iins_type),"01")==0 ||
                           strcmp(trim(iins_type),"05")==0 ||
                           strcmp(trim(iins_type),"08")==0 ||
                           strcmp(trim(iins_type),"09")==0 ||
                           strcmp(trim(iins_type),"201")==0 ||
                           strcmp(trim(iins_type),"205")==0 ||
                           strcmp(trim(iins_type),"209")==0) {
                           if (mins_stl_1 != 0) {
                              mplace_fee = mplace_fee_1;
                              sprintf(stmt1,
                              "select distinct nchi_full from %s:payment \
                                where iclaim = ? and xsettle_type = '6' \
                                  and pay_kind = '1' ",list[k].dbname);
                              $prepare pay_pre from $stmt1;
                              $declare pay_cur cursor for pay_pre;
                              $open pay_cur using $iclaim;
                              while(1) {
                                 $fetch pay_cur into $factory_1;
                                 if (SQLCODE==SQLNOTFOUND) break;
                                 if (strlen(trim(factory)) > 90) break;
                                 strcpy(factory_1,trim(factory_1));
                                 sprintf(factory,"%s%s;",trim(factory),
                                         factory_1);
                              }
                              $close pay_cur;
                           }
                           else {
                              mplace_fee = mplace_app;
                              sprintf(stmt1,
                              "select nvl(factory_1,' ') || nvl(factory_2,' ')\
                                 from %s:appraisal \
                                where iclaim = ? ",list[k].dbname);
                              $prepare pay_pre1 from $stmt1;
                              $execute pay_pre1 into $factory
                                       using $iclaim;
                           }
                       }
                       else mplace_fee = 0;

                       if (strcmp(trim(iins_type),"32")==0 || strcmp(trim(iins_type),"232")==0) {
                           if (mins_stl_1 != 0) {
                              sprintf(stmt1,
                              "select distinct nchi_full from %s:payment \
                                where iclaim = ? and xsettle_type = '6' \
                                  and pay_kind = '3' ",list[k].dbname);
                              $prepare pay_pre2 from $stmt1;
                              $declare pay_cur2 cursor for pay_pre2;
                              $open pay_cur2 using $iclaim;
                              while(1) {
                                 $fetch pay_cur2 into $factory_1;
                                 if (SQLCODE==SQLNOTFOUND) break;
                                 if (strlen(trim(factory)) > 90) break;
                                 strcpy(factory_1,trim(factory_1));
                                 sprintf(factory,"%s%s;",trim(factory),
                                         factory_1);
                              }
                              $close pay_cur2;
                           }
                           else {
                              sprintf(stmt1,
                              "select nvl(factory32_1,' ') || \
                                      nvl(factory32_2,' ') || \
                                      nvl(factory32_3,' ') || \
                                      nvl(factory32_4,' ') \
                                 from %s:appraisal \
                                where iclaim = ? ",list[k].dbname);
                              $prepare pay_pre3 from $stmt1;
                              $execute pay_pre3 into $factory
                                       using $iclaim;
                           }
                        }
                       printf("mplace[%d]factory[%s]\n",mplace_fee,factory);

                       rc =  car1118_insert_stl(iclaim,itag,ipolicy,daccident,iins_type,Librand,mins_app,
                                                mins_stl_1,mins_stl_2,sUser,nequipment,moutstand,(long)tmp_mstl,mplace_fee,factory,nassured,dc_close);
                       if (rc != M_CM_OK)
                       {
                           sprintf(msgbuf,"car1118_insert_stl iclaim[%s],iins_type[%s]\n",iclaim,iins_type);
                           printf("return car1118_insert_stl -> msgbuf[%s]\n",msgbuf);
                           EXEC SQL WHENEVER SQLERROR CONTINUE;
                           return rc;
                       }

                       /**********************************/
                       /**********************************/
                       /***      ���쥼�M�ߴڥ��      ***/
                       /**********************************/
                       /**********************************/

                       if (*pa.irule == '1')
                       {
                           if ((daccident <= lDbgn)   && (dappraisal_bgn < lDbgn) &&
                               (flag_close_dbgn == 0) && (dappraisal_bgn != 0))
                           {

                               tmp_qbgn_outstl = 1;

							   Icurr_CLM=Ifirst_CLM;
							   while (Icurr_CLM)
							   {
				                   if (Scan_Ins_List(Icurr_CLM->iins_type,iins_type) == SUCCESS ){
				                   	   Icurr_CLM->flag_ins_ply_close_dbgn = 0;
				                   	   break;
				                   }

		                           Icurr_CLM = Icurr_CLM->next;
							   }
                           }
                           else
                           {
                               tmp_qbgn_outstl = 0;
                           }
                       }
                       else
                       {
                           tmp_qbgn_outstl = 0;

						   Icurr_CLM=Ifirst_CLM;
						   while (Icurr_CLM)
						   {
			                   if (Scan_Ins_List(Icurr_CLM->iins_type,iins_type) == SUCCESS ){
			                   	   Icurr_CLM->flag_ins_ply_close_dbgn = 0;
			                   	   break;
			                   }

	                           Icurr_CLM = Icurr_CLM->next;
						   }
                       }

                       /**********************************/
                       /**********************************/
                       /***      �������M�ߴڥ��      ***/
                       /**********************************/
                       /**********************************/
                       if (flag_close_dend == 1) /*** �w���� ***/
                       {
                           tmp_qend_outstl = 0;
                       }
                       else                      /*** ������ ***/
                       {
                           tmp_qend_outstl = 1;

						   Icurr_CLM=Ifirst_CLM;
						   while (Icurr_CLM)
						   {
			                   if (Scan_Ins_List(Icurr_CLM->iins_type,iins_type) == SUCCESS ){
			                   	   Icurr_CLM->flag_ins_ply_close_dend = 0;
			                   	   break;
			                   }

	                           Icurr_CLM = Icurr_CLM->next;
						   }
                       }

                       /**********************************/
                       /**********************************/
                       /***      �������׽ߴڥ��      ***/
                       /**********************************/
                       /**********************************/
                       /*** �w���߮��I�حp�ߴڥ�Ƥ@�� ***/
                       if ((flag_close_dend == 1) &&
                           (tmp_mstl_dend > 0)    &&
                           ((flag_close_dbgn == 0) ||
                            (flag_close_dbgn == 1 && tmp_mstl_dbgn == 0)))
                       {
                           tmp_qclaim = 1;
                       }

                       /*** �i�K�ߵ��סj�Ρi�ߥI�����l�v��ߴڪ��B��0�j�̤��p�ߴڥ�� ***/
                       /*** �w���סA���I�ܲέp���鬰��ߥI���B�X�p��0               ***/
                       if ((flag_close_dend == 1) && (tmp_mstl_dbgn == 0) && (tmp_mstl_dend == 0))
                       {
                           tmp_qclaim = 0;
                       }

                       /*** ��~��W�@�έp�~�׬��ߥI�A���~�װl�v��ߴڪ��B��0 ***/
                       if ((tmp_mstl_dbgn > 0)    &&
                           (flag_close_dbgn == 1) &&
                           (tmp_mstl_dend == 0)   &&
                           (flag_close_dend == 1))
                       {
                           tmp_qclaim = -1;
                       }

                       /*** ���~�ר�G���s�}�פ��p���ץ�� ***/
                       if (((flag_close_dbgn == 1) && (tmp_mstl_dbgn > 0)) &&
                           ((flag_close_dend == 1) && ((tmp_mstl_dend-tmp_mstl_dbgn) > 0)))
                       {
                           tmp_qclaim = 0;
                       }



                       /*** �ĤT�H�d���I��˦��`�I�����T�ؽߥI���O�G93��� 94���` 95�ݼo ***/
                       IsIns = 0;
					   Icurr_CLM=Ifirst_CLM;
					   while (Icurr_CLM)
					   {
		                    if (Scan_Ins_List(Icurr_CLM->iins_type,iins_type) == SUCCESS ){
                                Icurr_CLM->tmp_ins_ply_mstl   += tmp_mstl;             /*** �w�M�ߴڦX�p     ***/
                                Icurr_CLM->tmp_ins_ply_mend   += tmp_mend_outstl;      /*** �������M�ߴڦX�p ***/
                                Icurr_CLM->tmp_ins_ply_mbgn   += tmp_mbgn_outstl;      /*** ���쥼�M�ߴڦX�p ***/

                                Icurr_CLM->tmp_ins_ply_mstl_dbgn   += tmp_mstl_dbgn;   /*** �p��ܴ��줧�X�p�w�M���B ***/
                                Icurr_CLM->tmp_ins_ply_mstl_dend   += tmp_mstl_dend;   /*** �p��ܴ������X�p�w�M���B ***/

                                Icurr_CLM->flag_ins_type = 1 ;
                                IsIns = 1;
                                break;
	                       	}
                            Icurr_CLM = Icurr_CLM->next;
					   }
					   if (IsIns == 0){

	                        EXEC SQL EXECUTE Get_mdisc
	                                INTO :tmp_mdiscount
	                                USING :ipolicy, :iins_type;
	                        if (SQLCODE == SQLNOTFOUND)
	                        {
	                            tmp_mdiscount = 0;
	                        }
	                        code=ca_loss_upd_InfoTable_payment(ipolicy,    Liquota,  Liofficer,
	                                                           Licar_flag, Librand,  Licar_type,
	                                                           iins_type,  ideduct,
	                                                           sIassured,  sUser,    iroute,
	                                                           tmp_qclaim,
	                                                           tmp_qend_outstl,
	                                                           tmp_qbgn_outstl,
	                                                           tmp_mstl,
	                                                           tmp_mend_outstl,
	                                                           tmp_mbgn_outstl,
	                                                           itag, ldply_bgn,iresource,tmp_mdiscount);

	                        if (code != SUCCESS)
	                        {
	                            sprintf(msgbuf,"ca_loss_upd_InfoTable_payment(c)ERR[%s][%s]", iclaim, iins_type);
	                            EXEC SQL WHENEVER SQLERROR CONTINUE;
	                            return code;
	                        }
                        }
                   }
                   /* end of while app_ins_type cursor */

                   EXEC SQL CLOSE loss_appins_cur;

                   ideduct = 0;

				   Icurr_CLM=Ifirst_CLM;
				   while (Icurr_CLM)
				   {
				   	   if (Icurr_CLM->flag_ins_type == 1){
				   	   	   /* ex.�ߥI���O93,94,95 �ন�I�� 31 */
                           strcpy(iins_type, trim(Icurr_CLM->iins_ply));

	                       /********** �ߴڥ�ƧP�_ ****************/

	                       /*** �Y�����@�ߥI���O�����M�A�Y�����M ***/
	                       /*** �ݥ����Ҭ��̫�@���ߥI�A�~������ ***/
	                       /*** �ĤT�H�d���I�L�l�v���Τ��o��     ***/
	                       /**********************************/
	                       /**********************************/
	                       /***      ���쥼�M�ߴڥ��      ***/
	                       /**********************************/
	                       /**********************************/
	                       /*** ���~�ר���쥼�M�ߴڥ�� ***/
		                   if (*pa.irule == '1')
	                       {
	                           if (Icurr_CLM->flag_ins_ply_close_dbgn == 0)
	                               Icurr_CLM->qbgn_outstl_ins_type = 1;
	                       }
	                       else   /*** ((*pa.irule == '2') || (*pa.irule == '3')) ***/
	                       {
	                           Icurr_CLM->qbgn_outstl_ins_type = 0;
	                       }
	                       /**********************************/
	                       /**********************************/
	                       /***      �������M�ߴڥ��      ***/
	                       /**********************************/
	                       /**********************************/
	                       if (Icurr_CLM->flag_ins_ply_close_dend == 0)
	                       {
	                           Icurr_CLM->qend_outstl_ins_type = 1;
	                       }
	                       /**********************************/
	                       /**********************************/
	                       /***      �������׽ߴڥ��      ***/
	                       /**********************************/
	                       /**********************************/
	                       /*** �w���߮��I�حp�ߴڥ�Ƥ@�� ***/
	                       if ((Icurr_CLM->flag_ins_ply_close_dend == 1) &&
	                           (Icurr_CLM->tmp_ins_ply_mstl_dend > 0)    &&
	                           ((Icurr_CLM->flag_ins_ply_close_dbgn == 0) ||
	                            (Icurr_CLM->flag_ins_ply_close_dbgn == 1 && Icurr_CLM->tmp_ins_ply_mstl_dbgn == 0)))
	                       {
	                           Icurr_CLM->qclaim_ins_type = 1;
	                       }
	                       /*** �K�ߵ��פ��p�ߴڥ�� ***/
	                       if ((Icurr_CLM->flag_ins_ply_close_dend == 1) && (Icurr_CLM->tmp_ins_ply_mstl_dend == 0))
	                       {
	                           Icurr_CLM->qclaim_ins_type = 0;
	                       }

	                       /*** ���~�ר�G���s�}�פ��p���ץ�� ***/
	                       if ((Icurr_CLM->flag_ins_ply_close_dbgn == 1) && ((Icurr_CLM->tmp_ins_ply_mstl_dbgn) > 0) &&
	                           (Icurr_CLM->flag_ins_ply_close_dend == 1) && ((Icurr_CLM->tmp_ins_ply_mstl_dend - Icurr_CLM->tmp_ins_ply_mstl_dbgn) > 0))
	                       {
	                           Icurr_CLM->qclaim_ins_type = 0;
	                       }

	                       /*** ���ܦ��������M��ơA�Y���@�ߥI�I�ة|���M ***/
	                       if (Icurr_CLM->qend_outstl_ins_type == 1)
	                       {
	                           Icurr_CLM->qclaim_ins_type = 0;
	                       }
	                       /******** END �ߴڥ�ƧP�_ **************/
	                        EXEC SQL EXECUTE Get_mdisc
	                                INTO :tmp_mdiscount
	                                USING :ipolicy, :iins_type;
	                        if (SQLCODE == SQLNOTFOUND)
	                        {
	                            tmp_mdiscount = 0;
	                        }
	                       code=ca_loss_upd_InfoTable_payment(ipolicy,    Liquota,   Liofficer,
	                                                          Licar_flag, Librand,   Licar_type,
	                                                          iins_type,  ideduct,
	                                                          sIassured,  sUser,    iroute,
	                                                          Icurr_CLM->qclaim_ins_type,
	                                                          Icurr_CLM->qend_outstl_ins_type,
	                                                          Icurr_CLM->qbgn_outstl_ins_type,
	                                                          Icurr_CLM->tmp_ins_ply_mstl,
	                                                          Icurr_CLM->tmp_ins_ply_mend,
	                                                          Icurr_CLM->tmp_ins_ply_mbgn,
	                                                          itag, ldply_bgn,iresource,tmp_mdiscount);

	                       if (code != SUCCESS)
	                       {
	                           sprintf(msgbuf, "ca_loss_upd_InfoTable_payment(c)ERR[%s][%s]", iclaim, iins_type);
	                           EXEC SQL WHENEVER SQLERROR CONTINUE;
	                           return code;
	                       }
                        }
                        Icurr_CLM = Icurr_CLM->next;
				   } /* end while(Icurr_CLM)  */
              }
              else if (fcard_class[0]=='1')       /***** �j���I *****/
              {
                   strcpy(iins_type , "21");

                   ideduct      = 0;
                   tmp_vic_mstl = 0;
                   tmp_vic_mbgn = 0;
                   tmp_vic_mend = 0;

                   qbgn_outstl_21 = 0;
                   qend_outstl_21 = 0;
                   qclaim_21      = 0;

                   flag_21_close_dend = 1;
                   flag_21_close_dbgn = 1;

                   tmp_21_mstl_dend = 0;
                   tmp_21_mstl_dbgn = 0;

                   EXEC SQL OPEN loss_appvic_cur USING :iclaim;

                   for(;;)
                   {
                       EXEC SQL FETCH loss_appvic_cur INTO :iins_item, :ivictim, :dappraisal,
                                                           :mapp_cover;
                       if(SQLCODE == SQLNOTFOUND) break;

                       /* Ū�����v��� */
                       EXEC SQL EXECUTE loss_appvic_end
                                   INTO :tmp_iins_item,  :tmp_ivictim,
                                        :dappraisal, :mapp_cover
                                  USING :iclaim, :iins_item, :ivictim, :lDhist_end;
                       if (SQLCODE == SQLNOTFOUND)
                       {
                              /*
                              EXEC SQL WHENEVER SQLERROR CONTINUE;
                              goto errexit;
                              */
                              continue;
                       }

                       if (*pa.irule == '1')
                       {
                            code = ca_calc_info_msettle(DBName1        , fcard_class,
                                                        iclaim         , iins_item,
                                                        ivictim        , lDend,
                                                        &tmp_mstl_dend , &flag_close_dend);
                       }

                       if (*pa.irule == '2')
                       {
                            code = ca_calc_info_msettle(DBName1        , fcard_class,
                                                        iclaim         , iins_item,
                                                        ivictim        , lCalc_end,
                                                        &tmp_mstl_dend , &flag_close_dend);
                       }

                       if (*pa.irule == '3')
                       {
                            code = ca_calc_info_msettle(DBName1        , fcard_class,
                                                        iclaim         , iins_item,
                                                        ivictim        , lCalc_end,
                                                        &tmp_mstl_dend , &flag_close_dend);
                       }

                       if (code != SUCCESS)
                       {
                            sprintf(msgbuf, "ca_calc_info_msettle([%s],[%s]) ERR",
                                    iclaim,iins_item);
                            EXEC SQL WHENEVER SQLERROR CONTINUE;
                            return code;
                       }

                       code = ca_calc_info_msettle(DBName1        , fcard_class,
                                                   iclaim         , iins_item,
                                                   ivictim        , lDbgn,
                                                   &tmp_mstl_dbgn , &flag_close_dbgn);
                       if (code != SUCCESS)
                       {
                            sprintf(msgbuf, "ca_calc_info_msettle([%s],[%s]) ERR",
                                    iclaim,iins_item);
                            EXEC SQL WHENEVER SQLERROR CONTINUE;
                            return code;
                       }

                       /* ����w�����B */
                       EXEC SQL EXECUTE loss_appvic_bgn
                                   INTO :tmp_iins_item,  :tmp_ivictim,
                                        :dappraisal_bgn, :mapp_cover_bgn
                                  USING :iclaim, :iins_item, :ivictim, :lDhist_bgn;
                       if (SQLCODE == SQLNOTFOUND)
                       {
                               /*
                               EXEC SQL WHENEVER SQLERROR CONTINUE;
                               goto errexit;
                               */
                               dappraisal_bgn = 0;
                               mapp_cover_bgn = 0;
                       }

                       /* �p��ߴڪ��B,�w�M�ߴ�,�������M,���쥼�M */
                       code = ca_calc_info_payment(daccident, dappraisal_bgn,
                                                   mapp_cover,mapp_cover_bgn,
                                                   flag_close_dend, flag_close_dbgn,
                                                   tmp_mstl_dend, tmp_mstl_dbgn,
                                                   lDbgn,
                                                   &tmp_mpayment,
                                                   &tmp_mstl,
                                                   &tmp_mbgn_outstl,
                                                   &tmp_mend_outstl);
                       if (code != SUCCESS)
                       {
                            sprintf(msgbuf, "ca_calc_info_payment([%s],[%s]) ERROR",
                                          iclaim,iins_item);
                            EXEC SQL WHENEVER SQLERROR CONTINUE;
                            return code;
                       }

                       tmp_vic_mstl += tmp_mstl;
                       tmp_vic_mbgn += tmp_mbgn_outstl;
                       tmp_vic_mend += tmp_mend_outstl;

                       tmp_21_mstl_dbgn += tmp_mstl_dbgn;
                       tmp_21_mstl_dend += tmp_mstl_dend;

                       /**********************************/
                       /**********************************/
                       /***      ���쥼�M�ߴڥ��      ***/
                       /**********************************/
                       /**********************************/
                       /*** ���~�ר���쥼�M�ߴڥ�� ***/
                       if (*pa.irule == '1')
                       {
                         if ((daccident      <= lDbgn) &&
                             (dappraisal_bgn < lDbgn) &&
                             (dappraisal_bgn != 0) &&
                             (flag_close_dbgn == 0))
                           {
                               flag_21_close_dbgn = 0;
                           }
                       }
                       else /*** ((*pa.irule == '2') || (*pa.irule == '3')) ***/
                       {
                           /*** �O��~�ר�ΨƬG�o�ͨ���쥼�M�ߴڥ��   ***/
                           /*** �L���줧��ơA�G�����p����쥼�M�ߴڥ�� ***/
                           flag_21_close_dbgn = 0;
                       }

                       /**********************************/
                       /**********************************/
                       /***      �������M�ߴڥ��      ***/
                       /**********************************/
                       /**********************************/
                       if (flag_close_dend == 0)
                       {
                           flag_21_close_dend = 0;
                       }
                   }
                   EXEC SQL CLOSE loss_appvic_cur;

                   /**********************************/
                   /**********************************/
                   /***      ���쥼�M�ߴڥ��      ***/
                   /**********************************/
                   /**********************************/
                   /*** ���~�ר���쥼�M�ߴڥ�� ***/

                   if (*pa.irule == '1')
                   {
                       if (flag_21_close_dbgn == 0)
                           qbgn_outstl_21 = 1;
                   }
                   else   /*** ((*pa.irule == '2') || (*pa.irule == '3')) ***/
                   {
                       qbgn_outstl_21 = 0;
                   }

                   /**********************************/
                   /**********************************/
                   /***      �������M�ߴڥ��      ***/
                   /**********************************/
                   /**********************************/
                   if (flag_21_close_dend == 0)
                   {
                       /*** �p�������M��Ƥ@�� ***/
                       qend_outstl_21 = 1;
                   }

                   /**********************************/
                   /**********************************/
                   /***      �������׽ߴڥ��      ***/
                   /**********************************/
                   /**********************************/
                   /*** �w���߮��I�حp�ߴڥ�Ƥ@�� ***/
                   if ((flag_21_close_dend == 1) &&
                       (tmp_21_mstl_dend > 0)    &&
                       ((flag_21_close_dbgn == 0) ||
                        ((flag_21_close_dbgn == 1) && (tmp_21_mstl_dbgn == 0))))
                   {
                       qclaim_21 = 1;
                   }

                   /*** �K�ߵ��פ��p�ߴڥ�� ***/
                   if ((flag_21_close_dend == 1) &&
                       (tmp_21_mstl_dend == 0))
                   {
                       qclaim_21 = 0;
                   }

                   /*** ���~�ר�G���s�}�פ��p���ץ�� ***/
                   if ((flag_21_close_dbgn == 1) &&
                       (tmp_21_mstl_dbgn > 0)    &&
                       (flag_21_close_dend == 1) &&
                       ((tmp_21_mstl_dend - tmp_21_mstl_dbgn) > 0))
                   {
                       qclaim_21 = 0;
                   }

                   /*** ��~��W�@�έp�~�׬��ߥI�A���~�װl�v��ߴڪ��B��0 ***/
                   if ((flag_21_close_dend == 1) &&
                       (flag_21_close_dbgn == 1) &&
                       (tmp_21_mstl_dbgn > 0) &&
                       (tmp_21_mstl_dend == 0))
                   {
                       qclaim_21 = -1;
                   }

                   /*** ���ܦ��������M��ơA�Y���@�ߥI�I�ة|���M ***/
                   if (qend_outstl_21 == 1)
                   {
                       qclaim_21 = 0;
                   }

                   /******** END �ߴڥ�ƧP�_ **************/
                    EXEC SQL EXECUTE Get_mdisc
                            INTO :tmp_mdiscount
                            USING :ipolicy, :iins_type;
                    if (SQLCODE == SQLNOTFOUND)
                    {
                        tmp_mdiscount = 0;
                    }
                   code=ca_loss_upd_InfoTable_payment(ipolicy,    Liquota,   Liofficer,
                                                      Licar_flag, Librand,   Licar_type,
                                                      iins_type,  ideduct,
                                                      sIassured,  sUser,     iroute,
                                                      qclaim_21,
                                                      qend_outstl_21,
                                                      qbgn_outstl_21,
                                                      tmp_vic_mstl,
                                                      tmp_vic_mend,
                                                      tmp_vic_mbgn,
                                                      itag, ldply_bgn,iresource,tmp_mdiscount);

                   if (code != SUCCESS)
                   {
                       sprintf(msgbuf, "ca_loss_upd_InfoTable_payment([%s],[%s]) ERROR",
                               iclaim,iins_item);
                       EXEC SQL WHENEVER SQLERROR CONTINUE;
                       return code;
                   }
              }/* fcard_class[0]=='1' */
          }
          EXEC SQL CLOSE loss_clm_cur;
          EXEC SQL FREE  loss_clm_cur;

          if (fcard_class[0]=='2')
              EXEC SQL FREE loss_appins_cur;
          if (fcard_class[0]=='1')
              EXEC SQL FREE loss_appvic_cur;

     }

     printf("\n\nEND SELECT data From Claim Table end time===>");
     printf(ctime(&lt));
     printf("\n");
/*
     EXEC SQL UPDATE STATISTICS FOR TABLE ca_loss_info_temp2;
*/
     $DELETE FROM ca_loss_info_temp2
       WHERE qprem        =   0
         AND mprem        =   0
         AND mpure_prem   =   0
         AND mcommission  =   0
         AND qfull        =   0
         AND mfull        =   0
         AND mfull_pure   =   0
         AND qend_outstl  =   0
         AND qclaim       =   0
         AND mbgn_outstl  =   0
         AND mend_outstl  =   0
         AND mstl         =   0;

     EXEC SQL UPDATE STATISTICS FOR TABLE ca_loss_info_temp2;
     EXEC SQL UPDATE STATISTICS FOR TABLE ca_loss_info_temp3;

     /* free allocated memory */
     while (Ifirst_CLM != NULL)
     {
        Icurr_CLM=Ifirst_CLM;
        Ifirst_CLM=Icurr_CLM->next;
        free(Icurr_CLM);
     }
     while (Ifirst_CLM != NULL)
     {
        Icurr_CLM_Loss=Ifirst_CLM;
        Ifirst_CLM=Icurr_CLM_Loss->next;
        free(Icurr_CLM_Loss);
     }
     return M_CM_OK;

errexit:
     printf( "[errexit]: SQLCODE=[%ld], sqlerrm=[%s]\n", SQLCODE,sqlca.sqlerrm);
     sprintf(msgbuf,"errexit ply[%s] clm[%s]", ipolicy, iclaim);
     return rc;
}

/*************************************/
/* 365���k , �p�⺡���O�O , ������� */
/*************************************/
long ca_calc_365_full(p_dbgn,  p_dend, p_dply_bgn, p_dply_end,
                      p_mprem, p_cnt , p_mfull,    p_qfull,   p_leap_flag)
long    p_dbgn, p_dend;
long    p_dply_bgn, p_dply_end;
double  p_mprem;
double  p_cnt;
double  *p_mfull, *p_qfull;
long    p_leap_flag;
{
    long    dbgn_prev;
    double  Mmiddle, Mbegin, Mend;
    double  Qmiddle, Qbegin, Qend;
    long    Qyear;

    /*----*/
    if (p_dbgn <= 0 || p_dend <= 0)
        return M_CA_DATE_ERROR;

    /*----*/
    dbgn_prev = p_dbgn - 1;

    /*----*/
    Mmiddle=Mbegin=Mend=0;
    Qmiddle=Qbegin=Qend=0;

    if (p_leap_flag == 1)   /*** �O�I�������|�~�G2��29�� ***/
    {
        Qyear = 366;
    }
    else
    {
        Qyear = 365;
    }

    /***** ���쥼���� *****/
    if (p_dply_bgn < p_dbgn && p_dply_end >= p_dbgn)
    {
        Mbegin = (double)(p_mprem * ((p_dply_end - dbgn_prev)*2-1) / (p_dply_end - p_dply_bgn) / 2);
        Qbegin = (double)(p_cnt   * ((p_dply_end - dbgn_prev)*2-1) / (Qyear) / 2);
    }

    /***** �������� *****/
    if (p_dbgn <= p_dply_bgn && p_dply_bgn <= p_dend)
    {
        Mmiddle = (double)(p_mprem);
        Qmiddle = (double)(p_cnt * (p_dply_end - p_dply_bgn) / (Qyear));
    }

    /***** ���������� *****/
    if ((p_dply_end > p_dend) && (p_dply_bgn <= p_dend))
    {
        Mend = (double)(p_mprem * ((p_dply_end - p_dend)*2-1) / (p_dply_end - p_dply_bgn) / 2);
        Qend = (double)(p_cnt   * ((p_dply_end - p_dend)*2-1) / (Qyear) / 2);
    }

    /*** �����O�O = ���쥼�����O�O + ���������O�O - �����������O�O ***/
    *p_mfull = Mbegin + Mmiddle - Mend;

    /*** ������� = ���쥼������� + ����������� - ������������� ***/
    *p_qfull = Qbegin + Qmiddle - Qend;

    return SUCCESS;
}

/**********************************************************************/
/* update or insert ca_loss_info_temp2                                */
/**********************************************************************/
long ca_loss_upd_InfoTable_prem(p_ipolicy   , p_iquota    , p_iofficer  ,
                                p_icar_flag , p_ibrand    , p_icar_type ,
                                p_iins_type , p_ideduct   ,
                                p_iassured  , p_nuser     , p_iroute    ,
                                p_cnt       , p_prem      , p_mpure_prem,   p_mcommission,
                                p_qfull     , p_mfull     , p_mfull_pure,
				                p_itag      , p_dpbgn     , P_iresource ,   P_mdiscount)
$char  *p_ipolicy   , *p_iquota , *p_iofficer;
$char  *p_icar_flag , *p_ibrand , *p_icar_type;
$char  *p_iins_type , *p_itag;
$char  *p_iassured  , *p_nuser  , *p_iroute, *P_iresource;
$int    p_ideduct;
$double p_qfull     , p_mfull;
$double p_cnt       , p_prem;
$double p_mpure_prem, p_mfull_pure;
$double p_mcommission ,P_mdiscount;
$long   p_dpbgn;
{
     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     strcpy(p_iins_type, trim(p_iins_type));

     EXEC SQL UPDATE ca_loss_info_temp2
                 SET qfull       = qfull       + $p_qfull,
                     mfull       = mfull       + $p_mfull,
                     qprem       = qprem       + $p_cnt,
                     mprem       = mprem       + $p_prem,
                     mpure_prem  = mpure_prem  + $p_mpure_prem,
                     mfull_pure  = mfull_pure  + $p_mfull_pure,
                     mcommission = mcommission + $p_mcommission,
                     mdiscount   = mdiscount   + $P_mdiscount
               WHERE ipolicy    = :p_ipolicy
                 AND iquota     = :p_iquota
                 AND iofficer   = :p_iofficer
                 AND icar_flag  = :p_icar_flag
                 AND ibrand     = :p_ibrand
                 AND icar_type  = :p_icar_type
                 AND iins_type  = :p_iins_type
                 AND ideduct    = :p_ideduct
                 AND iassured   = :p_iassured
                 AND iroute     = :p_iroute
                 AND nuser      = :p_nuser
		         AND itag       = :p_itag
		         AND dply_begin = :p_dpbgn
		         AND iresource  = :P_iresource;

     if (sqlca.sqlerrd[2]==0)
     {
         EXEC SQL INSERT INTO ca_loss_info_temp2
                              (ipolicy      , iquota      , iofficer    , icar_flag,
                               ibrand       , icar_type   , iins_type   , ideduct  ,
                               iassured     , nuser       , iroute      ,
                               qprem        , mprem       , mpure_prem  , mcommission,
                               qfull        , mfull       , mfull_pure  ,
                               qclaim       , qend_outstl , mbgn_outstl , mend_outstl , mstl,
			                   itag         , dply_begin  , iresource   , mdiscount)
                       VALUES (:p_ipolicy   , :p_iquota   , :p_iofficer , :p_icar_flag,
                               :p_ibrand    , :p_icar_type, :p_iins_type, :p_ideduct  ,
                               :p_iassured  , :p_nuser    , :p_iroute   ,
                               :p_cnt       , :p_prem     , :p_mpure_prem, :p_mcommission,
                               :p_qfull     , :p_mfull    , :p_mfull_pure,
                               0            , 0           , 0           , 0           , 0,
			                   :p_itag      , :p_dpbgn    , :P_iresource ,:P_mdiscount);
     }

     return SUCCESS;

errexit:
     printf (" ca_loss_upd_InfoTable_prem error [%s]\n", p_iins_type);
     return SQLCODE;
}

/*************************************************/
/* �I�� p_date ����,�p��ߥI��l�v�ұo���ߥI�b�B */
/*              (�O���/��~�� �@��)             */
/* return [1]�ߥI�b�B;                           */
/*        [2]�w����(1) OR ������(0)              */
/*************************************************/

long ca_calc_info_msettle(p_DB      , p_fcard_class,
                          p_iclaim  , p_iins,
                          p_ivictim , p_date,
                          p_msettle , p_flag_close)
char    p_DB[BRANCH_ID];
char    p_fcard_class[2];
$char   *p_iclaim;
$char   *p_iins;
$char   *p_ivictim;
$long   p_date;
double  *p_msettle;
int     *p_flag_close;
{
     char  DBName[DB_FULL_NAME];
     $char stmt[1024];
     $char fstl[2], flast[2],fflast[2];
     $long mins_stl, mins_proc, mins_salv, mstl_health;
     $long dgroup;

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     strcpy(DBName,get_full_dbname(p_DB));
     if (DBName[0]=='\0') return M_CM_DB_NOTOPEN;

     strcpy (p_iins,   trim(p_iins));
     strcpy (p_iclaim, trim(p_iclaim));

     /*-----------------*/
     *p_msettle    = 0;
     *p_flag_close = 0;
     flast[0]      = '\0';

     if (p_fcard_class[0] == '2')
     {
         sprintf(stmt,"SELECT %s FROM %s:%s WHERE %s",
                      "fstl, mins_stl, mins_proc, mins_salv, flast, dgroup",
                      DBName,"stl_ins_type",
                      "iclaim = ? AND iins_type = ?  AND dgroup <= ?");

         EXEC SQL PREPARE STLINS_CUR FROM :stmt;
         EXEC SQL DECLARE year_ins_info_cur CURSOR FOR STLINS_CUR;
         EXEC SQL OPEN    year_ins_info_cur USING :p_iclaim, :p_iins, :p_date;

         for (;;)
         {
             EXEC SQL FETCH year_ins_info_cur INTO :fstl, :mins_stl, :mins_proc,
                                                   :mins_salv, :flast, :dgroup;

             if (SQLCODE == SQLNOTFOUND) break;

             if (flast[0] == '1')
             {
                *p_flag_close=1;
             }

             if (fstl[0]=='1')
                 *p_msettle += (double)(mins_stl + mins_proc - mins_salv);
             else if (fstl[0]=='2')
                 *p_msettle -= (double)(mins_stl - mins_proc + mins_salv);

         }
         EXEC SQL CLOSE year_ins_info_cur;
         EXEC SQL FREE  year_ins_info_cur;
     }

     if (p_fcard_class[0] == '1')
     {
         sprintf(stmt,"SELECT %s FROM %s:%s WHERE %s %s",
                      "fstl, mins_stl, mins_proc, mstl_health, flast ",
                      DBName,"ca_stl_victim",
                      "iclaim = ? AND iins_item = ? AND ivictim = ? ",
                      " AND dgroup <= ?");
         EXEC SQL PREPARE STLINS_CUR FROM :stmt;
         EXEC SQL DECLARE year_vic_info_cur CURSOR FOR STLINS_CUR;

         EXEC SQL OPEN year_vic_info_cur USING :p_iclaim, :p_iins, :p_ivictim, :p_date;
         fflast[0] = '\0';
         while (1)
         {
            EXEC SQL FETCH year_vic_info_cur INTO :fstl, :mins_stl, :mins_proc, :mstl_health, :flast;
            if (SQLCODE == SQLNOTFOUND) break;

            if (flast[0] == '2')
                *p_flag_close=1;

            if (flast[0] == '1')
                strcpy(fflast,"Y");

            if (flast[0] == '1' && p_iins[0] == 'B')
                *p_flag_close=1;

            if (flast[0] == '1' && p_iins[0] == 'C')
                *p_flag_close=1;

            if (fstl[0]=='1')
                *p_msettle += (double)(mins_stl + mins_proc + mstl_health);
            else if (fstl[0]=='2')
                *p_msettle -= (double)(mins_stl - mins_proc + mstl_health);
         }
         EXEC SQL CLOSE year_vic_info_cur;
         EXEC SQL FREE year_vic_info_cur;

         /*******�K�ߵ���***********/
         if (*p_msettle == 0 && fflast[0] == 'Y')
              *p_flag_close = 1;
     }

     return SUCCESS;

errexit:
   return SQLCODE;
}

/**********************************************************/
/* �p��ߴڪ��B (�O���/��~�� �@��)                      */
/* return �ߴڪ��B, �w�M�ߴ�, �������M,     ���쥼�M      */
/*                  �w�M���, �������M���, ���쥼�M���  */
/**********************************************************/
long ca_calc_info_payment(p_daccident, p_dappraisal,
                          p_mapp,p_mapp_bgn,
                          p_flag_close_dend, p_flag_close_dbgn,
                          p_mstl_dend, p_mstl_dbgn,
                          p_dbgn,
                          p_mpayment,
                          p_mstl,
                          p_mbgn_outstl,
                          p_mend_outstl)
long    p_daccident, p_dappraisal;
double  p_mapp,p_mapp_bgn;
int     p_flag_close_dend, p_flag_close_dbgn;
long    p_dbgn;
double  p_mstl_dend, p_mstl_dbgn;
double *p_mpayment, *p_mstl,
       *p_mbgn_outstl,
       *p_mend_outstl;
{
     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     *p_mpayment    = 0;
     *p_mstl        = 0;
     *p_mbgn_outstl = 0;
     *p_mend_outstl = 0;

     /*-----�����w�M�ߴ� = �����w�M�ߴ� - ����w�M�ߴ� ----*/
     *p_mstl = p_mstl_dend - p_mstl_dbgn;

     /*-----�������M----*/
     if (p_flag_close_dend == 0)  /* ������,���������M */
     {
         /*** �������M�ߴ� = �w�����B - �w�M�ߴ� ***/
         *p_mend_outstl = p_mapp - p_mstl_dend;
         if (*p_mend_outstl < 0)
         {
             /*** ���ܹw�����B�C�� ***/
             *p_mend_outstl = 0;
         }
     }

     /*---- ���쥼�M�ߴ�(�X�I����ιw�����) ----*/
     if ((p_daccident <= p_dbgn) && (p_dappraisal < p_dbgn) && (p_flag_close_dbgn == 0))
     {
         /*** ���쥼�M�ߴ� = �w�����B - �ܲέp�_�l�餧�w�M�ߴ� ***/
         *p_mbgn_outstl = p_mapp_bgn - p_mstl_dbgn;
         if (*p_mbgn_outstl < 0)
         {
             *p_mbgn_outstl = 0;
         }
     }

     /*** �ߴڪ��B = �����w�M�ߴ� + �������M�ߴ� - ���쥼�M�ߴ� ***/
     *p_mpayment = *p_mstl + *p_mend_outstl - *p_mbgn_outstl;

     return SUCCESS;

errexit:
     return SQLCODE;
}

/****************************************************************************/
long ca_loss_upd_InfoTable_payment(p_ipolicy,    p_iquota, p_iofficer,
                                   p_icar_flag,  p_ibrand, p_icar_type,
                                   p_iins_type,  p_ideduct,
                                   p_iassured,   p_nuser,   p_iroute,
                                   p_qclaim,
                                   p_qend_outstl,
                                   p_qbgn_outstl,
                                   p_mstl,
                                   p_mend_outstl,
                                   p_mbgn_outstl,p_itag,   p_dpbgn,P_iresource ,P_mdiscount)
$char *p_ipolicy, *p_icar_type, *p_iins_type;
$char *p_icar_flag, *p_iofficer,*p_iquota, *p_ibrand;
$char *p_iassured, *p_nuser, *p_iroute, *p_itag, *P_iresource;
$int   p_ideduct;
$double p_mstl;
$int    p_qclaim;
$int    p_qend_outstl;
$int    p_qbgn_outstl;
$double p_mend_outstl;
$double p_mbgn_outstl, P_mdiscount;
$long   p_dpbgn;
{
     $char tmp_iins_type[INSURANCE_TYPE];
     $double dbl_moutstl, dbl_qoutstl;

     EXEC SQL WHENEVER SQLERROR GOTO errexit;
     /**
     EXEC SQL
          SELECT iins_ply INTO :tmp_iins_type
            FROM insurance_type
           WHERE iins_type = :p_iins_type;
     **/

     strcpy(tmp_iins_type, rtrim(p_iins_type));

     Icurr_CLM_Loss=Ifirst_CLM;
     while (Icurr_CLM_Loss)
	 {
	  	  if (Scan_Ins_List(Icurr_CLM_Loss->iins_type,p_iins_type) == SUCCESS ){
	  	 	  strcpy(tmp_iins_type, trim(Icurr_CLM_Loss->iins_ply));
	  	 	  break;
	  	  }
	      Icurr_CLM_Loss = Icurr_CLM_Loss->next;
	 }

     /*******
     if (strncmp(p_iins_type,"93",2)==0 ||
         strncmp(p_iins_type,"94",2)==0 ||
         strncmp(p_iins_type,"95",2)==0)
     {
         strcpy(tmp_iins_type, "31");
     }
     else if (strncmp(p_iins_type,"4A",2)==0 ||
              strncmp(p_iins_type,"4B",2)==0 ||
              strncmp(p_iins_type,"4C",2)==0 ||
              strncmp(p_iins_type,"4D",2)==0)
     {
         strcpy(tmp_iins_type, "24");
     }
     else if (strncmp(p_iins_type,"9A",2)==0 ||
              strncmp(p_iins_type,"9B",2)==0 ||
              strncmp(p_iins_type,"9C",2)==0 ||
              strncmp(p_iins_type,"9D",2)==0)
     {
         strcpy(tmp_iins_type, "29");
     }
     else if (strncmp(p_iins_type,"0A",2)==0 ||
              strncmp(p_iins_type,"0B",2)==0 ||
              strncmp(p_iins_type,"0C",2)==0 ||
              strncmp(p_iins_type,"0D",2)==0 ||
              strncmp(p_iins_type,"0E",2)==0)
     {
         strcpy(tmp_iins_type, "30");
     }
     else
     {
         strcpy(tmp_iins_type, rtrim(p_iins_type));
     }
     *************/

     /* ���M��ƶ��������쪺���� */
     /* dbl_moutstl = p_mend_outstl - p_mbgn_outstl; */
     dbl_qoutstl = p_qend_outstl - p_qbgn_outstl;

     EXEC SQL UPDATE ca_loss_info_temp2
                 SET mstl        = mstl        + $p_mstl,
                     mend_outstl = mend_outstl + $p_mend_outstl ,
                     mbgn_outstl = mbgn_outstl + $p_mbgn_outstl ,
                     qclaim      = qclaim      + $p_qclaim,
                     qend_outstl = qend_outstl + $dbl_qoutstl
               WHERE ipolicy     = :p_ipolicy
                 AND iquota      = :p_iquota
                 AND iofficer    = :p_iofficer
                 AND icar_flag   = :p_icar_flag
                 AND ibrand      = :p_ibrand
                 AND icar_type   = :p_icar_type
                 AND iins_type   = :tmp_iins_type
                 AND ideduct     = :p_ideduct
                 AND iassured    = :p_iassured
                 AND iroute      = :p_iroute
                 AND nuser       = :p_nuser
                 AND itag        = :p_itag
                 AND dply_begin  = :p_dpbgn
		         AND iresource   = :P_iresource;
     if (sqlca.sqlerrd[2]==0)
     {
         EXEC SQL INSERT INTO ca_loss_info_temp2
                              (ipolicy     , iquota        , iofficer      , icar_flag,
                               ibrand      , icar_type     , iins_type     , ideduct  ,
                               iassured    , nuser         , iroute        ,
                               qclaim      , qend_outstl   ,
                               mstl        , mend_outstl   , mbgn_outstl   ,
                               qprem       , mprem         ,
                               qfull       , mfull, itag   , dply_begin    ,iresource, mdiscount)
                       VALUES ($p_ipolicy  , $p_iquota     , $p_iofficer   , $p_icar_flag  ,
                               $p_ibrand   , $p_icar_type  , $tmp_iins_type, $p_ideduct    ,
                               $p_iassured , $p_nuser      , $p_iroute     ,
                               $p_qclaim   , $dbl_qoutstl  ,
                               $p_mstl     , $p_mend_outstl, $p_mbgn_outstl,
                               0           , 0             ,
                               0           , 0,   $p_itag,  $p_dpbgn , $P_iresource ,0);
     }
     return SUCCESS;

errexit:
     printf("sqcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
     return SQLCODE;
}

/***** �g��O *****/
long loss_info_build2()
{
     EXEC SQL BEGIN DECLARE SECTION;
         char   stmt[2048];
         int    fdata;

         char   qorder_c[7];
         char   qorder1_c[7];
         char   qorder2_c[7];

         int    qorder;
         int    qorder1;
         int    qorder2;
         int    qorder3;
         char   ntitle[21];
         char   ngroup[41];
         char   nquota[41];
         char   nname[11];
         char   iofficer[11];
         char   iquota[11];
         char   iresource[2];

         double sum_qprem , sum_mprem;
         double sum_qfull , sum_mfull;
         double sum_qclaim, sum_mstl , sum_outstl , sum_bgn_outstl;
         double sum_end_outstl;
         double total_mstl;
         double sum_mpure_prem, sum_mfull_pure;
         double sum_mcommission;
         double sum_mdiscount;

         char   sum_qprem_c[25]  , sum_mprem_c[25];
         char   sum_qfull_c[25]  , sum_mfull_c[25];
         char   sum_qclaim_c[25] , sum_mstl_c[25] , sum_outstl_c[25] , sum_bgn_outstl_c[25];
         char   total_mstl_c[25];
         char   sum_mpure_prem_c[25], sum_mfull_pure_c[25];
         char   sum_end_outstl_c[25];
         char   sum_mdiscount_c[25];

         char   iins_type[16], all_iins[301];
         char   where_stat[100];      /**** �j���I�Ϥ������ΨT�� ****/
         char   filename1[200];       /**** �ɮצW��:�g�Jrptftplist ****/

         char   where_stat1[100];     /**** ���O�s�����¨� ****/
         char   nroutename[41];
         char   iroute[21];
         char   dnname[41];
         char   sum_mcommission_c[25];
         char   nresource[31];       /* �~�Ȩӷ�����W�� */

     EXEC SQL END   DECLARE SECTION;

     char file_catalog[200];          /**** cat:filename[�Ҧb�ؿ�]+filename1[�ɮצW��] ****/
     int  i;
     char cal_rules[2];

     /*************************************************************/
     /*************************************************************/
     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     if (*pa.irule == '1')
     {
         strcpy(cal_rules,"1");
     }
     else if (*pa.irule == '2')
     {
         strcpy(cal_rules,"2");
     }
     else
     {
         strcpy(cal_rules,"3");
     }



     EXEC SQL DECLARE build2_cur CURSOR FOR
               SELECT iins_type , all_iins
                 FROM instype_temp;
     EXEC SQL OPEN    build2_cur;
     while(1)
     {
          EXEC SQL FETCH build2_cur INTO :iins_type , :all_iins;
          if (SQLCODE == SQLNOTFOUND) break;

          /*** �C�@���I�إN��iins_type�ؤ@���ɮ� ***/
          /*** �ؿ�:filename ***/

          /**** filename1 �ɮצW�� ****/
          filename1[0]='\0';
          file_catalog[0]='\0';
          where_stat1[0]='\0';

          strcpy(iins_type,trim(iins_type));
          sprintf(filename1,"c1118_%s[%s].%s.%s",cal_rules,exec_eDbgn,iins_type,outputf);
          where_stat1[0]='\0';

          strcpy(file_catalog, trim(filename));
          strcat(file_catalog, trim(filename1));


          strcpy(iins_type , trim(iins_type));
          strcpy(all_iins  , trim(all_iins));

          where_stat[0]='\0';
          if (strcmp(iins_type,"2101")==0)
          {
              strcpy(where_stat,"AND a.icar_type in ('01','02','32','34','35')");
          }
          else if (strcmp(iins_type,"2103")==0)
          {
              strcpy(where_stat,"AND a.icar_type not in ('01','02','32','34','35')");
          }
          else if (strcmp(iins_type,"05_deduct")==0)
          {
              strcpy(where_stat," AND a.ideduct = '1' ");
          }
          else if (strcmp(iins_type,"05_nodeduct")==0)
          {
              strcpy(where_stat," AND a.ideduct = '0' ");
          }
          else
          {
              where_stat[0]='\0';
          }
          /* 960129, �s�W "�~�Ȩӷ�" */
          stmt[0]='\0';
          sprintf(stmt,
                 " select b.qorder[1] , b.qorder[2] , b.qorder , a.iquota , b.ngroup,       \
                          b.nquota, c.nname , c.iofficer, a.iroute,a.iresource,             \
                          sum(mdiscount),                                                   \
                          sum(qprem),                                                       \
                          sum(mprem),                                                       \
                          sum(mpure_prem),                                                  \
                          sum(qfull),                                                       \
                          sum(mfull),                                                       \
                          sum(mfull_pure),                                                  \
                          sum(qclaim + qend_outstl),                                        \
                          sum(mstl),                                                        \
                          sum(mbgn_outstl),                                                 \
                          sum(mend_outstl),                                                 \
                          sum(mstl+mend_outstl-mbgn_outstl),                                \
                          sum(mcommission)                                                  \
                     from ca_loss_info_temp2 a , officer c , quota_temp b                   \
                    where iins_type =  ?                                                    \
                      and a.iquota   = b.iquota                                             \
                      and a.iofficer = c.iofficer                                           \
                          %s %s                                                             \
                    group by 1,2,3,4,5,6,7,8,9,10 ",where_stat, where_stat1);

    /*    printf("stmt[%s]\n",stmt); */
          EXEC SQL PREPARE stmt_cur2    FROM :stmt;
          EXEC SQL DECLARE CUR_2 CURSOR FOR stmt_cur2;
          EXEC SQL OPEN    CUR_2 USING $all_iins;
          fdata = 0;
          EXEC SQL FETCH CUR_2 INTO :qorder1,:qorder2,:qorder,:iquota,
                                    :ngroup,:nquota,:nname,:iofficer,
                                    :iroute  , :iresource ,:sum_mdiscount ,
                                    :sum_qprem,:sum_mprem,:sum_mpure_prem ,
                                    :sum_qfull,:sum_mfull,:sum_mfull_pure ,
                                    :sum_qclaim, :sum_mstl  ,
                                    :sum_bgn_outstl         ,
                                    :sum_end_outstl         ,
                                    :total_mstl,
                                    :sum_mcommission;
          if (SQLCODE!=SQLNOTFOUND) {
             fdata = 1;
             /* 951205,�����q��"00"DB �άO�����q�ɡA�HW�覡�}�ҡA�B�g�J���Y */
             if (((fAllDB == 'Y')&&(k_tmp==0))||(fAllDB == 'N')){
	             if ((fptr=fopen(file_catalog,"w")) == NULL)
	             {
	                 printf("fopen error\n");
	             }

	             /************ �B�z���W�� **********/
	             flen=fprintf(fptr,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n",
	                  "�ƧǤ@","�ƧǤG","�ƧǤT","���N��","���W��",
	                  "���²��","�g��W��","�g��N��","�q���N��",
	                  "�q���W��","�~�Ȩӷ�","�j�v�~�ȦW��","�u�f���B","ñ����","ñ��O�O",
	                  "�«O�O","�������󦨥�","�������","�����O�O",
	                  "�����«O�O","�ߴڥ��","�w�M���B",
	                  "���쥼�M���B","�������M���B","�ߴڪ��B");
             }else{
             	 /* �����q���D"00"DB �ɡA�H���[(append)�覡�}�� */
	             if ((fptr=fopen(file_catalog,"a")) == NULL)
	             {
	                 printf("fopen error\n");
	             }
             }
          }
          for(;;)
          {
              if (SQLCODE==SQLNOTFOUND) break;

              $SELECT nname
                 INTO $nroutename
                 FROM officer
                WHERE iofficer = $iroute;
                if (SQLCODE == SQLNOTFOUND)
                {
                   $SELECT nroute
                      INTO $nroutename
                      FROM cm_route
                     WHERE iroute = $iroute;
                     if (SQLCODE == SQLNOTFOUND)
                     {
                        strcpy(nroutename," ");
                     }
                }

              strcpy(qorder1_c, itoa(qorder1));
              strcpy(qorder2_c, itoa(qorder2));
              strcpy(qorder_c , itoa(qorder));

              rfmtdouble(sum_mdiscount,  "-#########&.######", sum_mdiscount_c);
              rfmtdouble(sum_qprem,  "-#########&.######", sum_qprem_c);
              rfmtdouble(sum_mprem,  "-#########&.######", sum_mprem_c);
              rfmtdouble(sum_mpure_prem,"-#########&.######", sum_mpure_prem_c);
              rfmtdouble(sum_qfull,  "-#########&.######", sum_qfull_c);
              rfmtdouble(sum_mfull,  "-#########&.######", sum_mfull_c);
              rfmtdouble(sum_mfull_pure,"-#########&.######", sum_mfull_pure_c);
              rfmtdouble(sum_qclaim, "-#########&.######", sum_qclaim_c);
              rfmtdouble(sum_mstl,   "-#########&.######", sum_mstl_c);
              rfmtdouble(sum_bgn_outstl, "-#########&.######", sum_bgn_outstl_c);
              rfmtdouble(sum_end_outstl, "-#########&.######", sum_end_outstl_c);
              rfmtdouble(total_mstl, "-#########&.######", total_mstl_c);
              rfmtdouble(sum_mcommission, "-#########&.######", sum_mcommission_c);

              if (pa.idata[0] == '2')
              {
                 sprintf(stmt,
                  " SELECT First 1 nname   \
                      FROM car1118         \
                     WHERE iofficer = ? ");
                  $PREPARE getnname FROM $stmt;
                  $EXECUTE getnname
                      INTO $dnname
                     USING $iofficer;
                 if (SQLCODE == SQLNOTFOUND)
                 {
                    sprintf(stmt,
                    " SELECT First 1 nname   \
                        FROM car1118         \
                       WHERE iroute = ? ");
                    $PREPARE getroute FROM $stmt;
                    $EXECUTE getroute
                        INTO $dnname
                       USING $iroute;
                    if (SQLCODE == SQLNOTFOUND)
                       strcpy(dnname," ");
                 }
              }else{
              	 /* 951207 */
              	 strcpy(dnname," ");
              }

              /* 960129, �~�Ȩӷ� */
              $SELECT ncode
                 INTO $nresource
                 FROM cu_code_data
               WHERE itype = '10'
                 AND icode = $iresource;
               if (SQLCODE == SQLNOTFOUND)
               {
                   strcpy(nresource," ");
               }else{
                   strcpy(nresource,trim(nresource));
               }



              flen=fprintf(fptr,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n",
                               qorder1_c, qorder2_c, qorder_c, iquota, ngroup, nquota,
                               nname    , iofficer , iroute, nroutename ,nresource, dnname,
                               sum_mdiscount_c, sum_qprem_c , sum_mprem_c , sum_mpure_prem_c , sum_mcommission_c,
                               sum_qfull_c , sum_mfull_c , sum_mfull_pure_c ,
                               sum_qclaim_c , sum_mstl_c , sum_bgn_outstl_c, sum_end_outstl_c ,
                               total_mstl_c);
              EXEC SQL FETCH CUR_2 INTO :qorder1,:qorder2,:qorder,:iquota,
                                        :ngroup,:nquota,:nname,:iofficer,
                                        :iroute  , :iresource  ,:sum_mdiscount,
                                        :sum_qprem,:sum_mprem,:sum_mpure_prem ,
                                        :sum_qfull,:sum_mfull,:sum_mfull_pure ,
                                        :sum_qclaim, :sum_mstl  ,
                                        :sum_bgn_outstl         ,
                                        :sum_end_outstl         ,
                                        :total_mstl,
                                        :sum_mcommission;
          }
          EXEC SQL CLOSE CUR_2;
          EXEC SQL FREE  CUR_2;

          if (fdata) {
              fclose(fptr);
              if (((fAllDB == 'Y')&&(k_tmp==0))||(fAllDB == 'N')){
	              EXEC SQL INSERT INTO rptftplist (nuserid,ipgid,
	                                               noutfile,dcreate)
	                                       VALUES ($userid,'car1118',
	                                               $filename1, $exec_time);
              }
          }
     }
     /******�B�z���I�ة���*********/
     EXEC SQL INSERT INTO car1118_clm_ply
       SELECT DISTINCT ipolicy,iclaim
         FROM car1118_clm_dtl
        WHERE iins_type != '21';

     EXEC SQL INSERT INTO car1118_clm_cnt
       SELECT ipolicy,count(*)
         FROM car1118_clm_ply
        GROUP BY 1;
/*
     EXEC SQL INSERT INTO ca_loss_info_temp3
       SELECT ipolicy,iquota,iofficer,iroute,iresource,sum(sum_mdiscount),
              max(qprem),sum(mprem),sum(mpure_prem),
              sum(mcommission),max(qfull),sum(mfull),
              sum(mfull_pure),max(qend_outstl),max(qclaim),
              sum(mbgn_outstl),sum(mend_outstl),sum(mstl)
         FROM ca_loss_info_temp2
        WHERE iins_type != '21'
        GROUP BY 1,2,3,4;
*/
     /* 951227, �ק��ƭp��max(qprem)=>1, max(qfull)=>sum(qfull),max(qclaim)=>sum(qclaim)  */
     EXEC SQL INSERT INTO ca_loss_info_temp3
       SELECT ipolicy,iquota,iofficer,iroute,iresource,
              sum(mdiscount),1,sum(mprem),sum(mpure_prem),
              sum(mcommission),sum(qfull),sum(mfull),
              sum(mfull_pure),max(qend_outstl),sum(qclaim),
              sum(mbgn_outstl),sum(mend_outstl),sum(mstl)
         FROM ca_loss_info_temp2
        WHERE iins_type != '21'
        GROUP BY 1,2,3,4,5,7;

/*   951227,�p�W
     EXEC SQL UPDATE ca_loss_info_temp3
                 SET qclaim = (SELECT qclm FROM car1118_clm_cnt
               WHERE car1118_clm_cnt.ipolicy = ca_loss_info_temp3.ipolicy)
               WHERE ipolicy in (select ipolicy from car1118_clm_cnt);
*/
          /**** filename1 �ɮצW�� ****/
          filename1[0]='\0';
          file_catalog[0]='\0';
          where_stat1[0]='\0';

          sprintf(filename1,"c1118_%s[%s].all.%s",cal_rules,exec_eDbgn,outputf);

          strcpy(file_catalog, trim(filename));
          strcat(file_catalog, trim(filename1));

         /* 951205,�����q��"00"DB �άO�����q�ɡA�HW�覡�}�ҡA�B�g�J���Y */
         if (((fAllDB == 'Y')&&(k_tmp==0))||(fAllDB == 'N')){
             if ((fptr=fopen(file_catalog,"w")) == NULL)
             {
                 printf("fopen error\n");
             }

	          /************ �B�z���W�� **********/
	          flen=fprintf(fptr,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n",
	                            "�ƧǤ@","�ƧǤG","�ƧǤT","���N��","���W��","���²��",
	                            "�g��W��","�g��N��","�q���N��","�q���W��","�~�Ȩӷ�","�j�v�~�ȦW��","�u�f���B","ñ����","ñ��O�O","�«O�O","�������󦨥�",
	                            "�������","�����O�O","�����«O�O",
	                            "�ߴڥ��","�w�M���B","���쥼�M���B","�������M���B","�ߴڪ��B");
         }else{
         	 /* �����q���D"00"DB �ɡA�H���[(append)�覡�}�� */
             if ((fptr=fopen(file_catalog,"a")) == NULL)
             {
                 printf("fopen error\n");
             }
         }

          stmt[0]='\0';
          sprintf(stmt,
                 " select b.qorder[1] , b.qorder[2] , b.qorder , a.iquota , b.ngroup,       \
                          b.nquota, c.nname , a.iofficer, a.iroute,a.iresource,             \
                          sum(mdiscount),                                                   \
                          sum(qprem),                                                       \
                          sum(mprem),                                                       \
                          sum(mpure_prem),                                                  \
                          sum(qfull),                                                       \
                          sum(mfull),                                                       \
                          sum(mfull_pure),                                                  \
                          sum(qclaim),                                                      \
                          sum(mstl),                                                        \
                          sum(mbgn_outstl),                                                 \
                          sum(mend_outstl),                                                 \
                          sum(mstl+mend_outstl-mbgn_outstl),                                \
                          sum(mcommission)                                                  \
                     from ca_loss_info_temp3 a , officer c , quota_temp b                   \
                    where a.iquota   = b.iquota                                             \
                      and a.iofficer = c.iofficer                                           \
                    group by 1,2,3,4,5,6,7,8,9,10 ");

      /*  printf("stmt[%s]\n",stmt); */
          EXEC SQL PREPARE stmt_cur21   FROM :stmt;
          EXEC SQL DECLARE CUR_21 CURSOR FOR stmt_cur21;
          EXEC SQL OPEN    CUR_21;
          for(;;)
          {
              EXEC SQL FETCH CUR_21 INTO :qorder1   , :qorder2   , :qorder         , :iquota  ,  :ngroup,
                                         :nquota    , :nname     , :iofficer       , :iroute  ,  :iresource,
                                         :sum_mdiscount, :sum_qprem , :sum_mprem , :sum_mpure_prem ,
                                         :sum_qfull , :sum_mfull , :sum_mfull_pure ,
                                         :sum_qclaim, :sum_mstl  ,
                                         :sum_bgn_outstl         ,
                                         :sum_end_outstl         ,
                                         :total_mstl,
                                         :sum_mcommission;
              if (SQLCODE==SQLNOTFOUND) break;

              $SELECT nname
                 INTO $nroutename
                 FROM officer
                WHERE iofficer = $iroute;
                if (SQLCODE == SQLNOTFOUND)
                {
                   $SELECT nroute
                      INTO $nroutename
                      FROM cm_route
                     WHERE iroute = $iroute;
                     if (SQLCODE == SQLNOTFOUND)
                     {
                        strcpy(nroutename," ");
                     }
                }

              strcpy(qorder1_c, itoa(qorder1));
              strcpy(qorder2_c, itoa(qorder2));
              strcpy(qorder_c , itoa(qorder));

              rfmtdouble(sum_mdiscount,  "-#########&.######", sum_mdiscount_c);
              rfmtdouble(sum_qprem,  "-#########&.######", sum_qprem_c);
              rfmtdouble(sum_mprem,  "-#########&.######", sum_mprem_c);
              rfmtdouble(sum_mpure_prem,"-#########&.######", sum_mpure_prem_c);
              rfmtdouble(sum_qfull,  "-#########&.######", sum_qfull_c);
              rfmtdouble(sum_mfull,  "-#########&.######", sum_mfull_c);
              rfmtdouble(sum_mfull_pure,"-#########&.######", sum_mfull_pure_c);
              rfmtdouble(sum_qclaim, "-#########&.######", sum_qclaim_c);
              rfmtdouble(sum_mstl,   "-#########&.######", sum_mstl_c);
              rfmtdouble(sum_bgn_outstl, "-#########&.######", sum_bgn_outstl_c);
              rfmtdouble(sum_end_outstl, "-#########&.######", sum_end_outstl_c);
              rfmtdouble(total_mstl, "-#########&.######", total_mstl_c);
              rfmtdouble(sum_mcommission, "-#########&.######", sum_mcommission_c);

              if (pa.idata[0] == '2')
              {
                 sprintf(stmt,
                  " SELECT First 1 nname   \
                      FROM car1118         \
                     WHERE iofficer = ? ");
                  $PREPARE getnname FROM $stmt;
                  $EXECUTE getnname
                      INTO $dnname
                     USING $iofficer;
                 if (SQLCODE == SQLNOTFOUND)
                 {
                    sprintf(stmt,
                    " SELECT First 1 nname   \
                        FROM car1118         \
                       WHERE iroute = ? ");
                    $PREPARE getroute FROM $stmt;
                    $EXECUTE getroute
                        INTO $dnname
                       USING $iroute;
                    if (SQLCODE == SQLNOTFOUND)
                       strcpy(dnname," ");
                 }
              }else{
              	 /* 951207 */
              	 strcpy(dnname," ");
              }

              /* 960129, �~�Ȩӷ� */
              $SELECT ncode
                 INTO $nresource
                 FROM cu_code_data
               WHERE itype = '10'
                 AND icode = $iresource;
               if (SQLCODE == SQLNOTFOUND)
               {
                   strcpy(nresource," ");
               }else{
                   strcpy(nresource,trim(nresource));
               }

              flen=fprintf(fptr,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n",
                               qorder1_c, qorder2_c, qorder_c, iquota, ngroup, nquota,
                               nname    , iofficer , iroute, nroutename , nresource , dnname,
                               sum_mdiscount_c, sum_qprem_c , sum_mprem_c , sum_mpure_prem_c , sum_mcommission_c,
                               sum_qfull_c , sum_mfull_c , sum_mfull_pure_c ,
                               sum_qclaim_c , sum_mstl_c , sum_bgn_outstl_c, sum_end_outstl_c ,
                               total_mstl_c);
          }
          EXEC SQL CLOSE CUR_21;
          EXEC SQL FREE  CUR_21;

          fclose(fptr);
          if (((fAllDB == 'Y')&&(k_tmp==0))||(fAllDB == 'N')){
	          EXEC SQL INSERT INTO rptftplist (nuserid, ipgid,     noutfile,   dcreate)
	                                   VALUES ($userid, 'car1118', $filename1, $exec_time);
          }
     /********���I�ة��ӵ���************/

     EXEC SQL CLOSE build2_cur;
     EXEC SQL FREE  build2_cur;
     return M_CM_OK;

errexit:
     printf("SOLCODE=%d sqlca.sqlerrm=%s\n",SQLCODE,sqlca.sqlerrm);
     printf(errmsg,"SOLCODE=%s sqlca.sqlerrm=%s",SQLCODE,sqlca.sqlerrm);
     fprintf(fptr_err,"%s\n",errmsg);
     return ;
}

/*--------------------------------------------------------------------*/
/***** ���Ӹ�� *****/
long loss_info_build4()
{
     EXEC SQL BEGIN DECLARE SECTION;
         char   stmt[2048];

         char   Ipolicy[21];
         char   Iins_type[7];
         char   Iquota[7];
         char   Iofficer[11];
         char   Ibrand[7];
         char   Icar_type[3];
         char   Icar_flag[2];
         char   iresource[2];

         double Qprem;
         double Mprem;

         double Mfull;
         double Mfull_pure;
         double Mpure_prem;
         double Qfull;

         double Mend_outstl;
         double Mbgn_outstl;
         double Mstl;
         double Qclaim;
         double total_mstl;
         double Mdiscount;

         char   Mfull_c[25];
         char   Mfull_pure_c[25];
         char   Mpure_prem_c[25];
         char   Mprem_c[25];
         char   Qprem_c[25];

         char   Qfull_c[25];
         char   Mend_outstl_c[25];
         char   Mbgn_outstl_c[25];
         char   Mstl_c[25];
         char   Qclaim_c[25];
         char   Ideduct_c[25];
         char   Qend_outstl_c[25];
         char   total_mstl_c[25];
         char   Mcommission_c[25];
         char   Mdiscount_c[25];

         char   filename1[200];
         int    Ideduct;
         char   nname[11];
         char   ntitle[21];
         char   ngroup[21];
         char   nsales[21];
         char   sfulldb[31];
         char   sIassured[11];
         char   User[19];
         char   iroute[21];
         char   iquota[11];
         char   itag[CA_TAG_NUM];
         char   dply_begin[11];

         double Mcommission;
         char   nbranch[61];
         char   niroute[11];
         char   nroute[41];
         char   nchi_full[61];
         char   sFins_grp[2];
         char   dnname[41];
         char   nresource[31];
         char   nequipment[31];

     EXEC SQL END   DECLARE SECTION;

     char file_catalog[200];          /**** cat:filename[�Ҧb�ؿ�]+filename1[�ɮצW��] ****/
     char cal_rules[2];

     /*************************************************************/
     /*************************************************************/
     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     /**** filename1 �ɮצW�� ****/
     filename1[0]='\0';
     file_catalog[0]='\0';

     if (*pa.irule == '1')
     {
         strcpy(cal_rules,"1");
     }
     else if (*pa.irule == '2')
     {
         strcpy(cal_rules,"2");
     }
     else
     {
         strcpy(cal_rules,"3");
     }

     sprintf(filename1 , "c1118_%s_����[%s].%s",cal_rules,exec_eDbgn,outputf);
     strcpy(file_catalog, trim(filename));
     strcat(file_catalog, trim(filename1));

     printf("{loss_info_build1.0001}:filename[%s],filename1[%s]\n",filename,filename1);
     printf("{loss_info_build1.0002}:file_catalog[%s]\n",file_catalog);

     /* 951205,�����q��"00"DB �άO�����q�ɡA�HW�覡�}�ҡA�B�g�J���Y */
     if (((fAllDB == 'Y')&&(k_tmp==0))||(fAllDB == 'N')){
         if ((fptr=fopen(file_catalog,"w")) == NULL)
         {
             printf("fopen error\n");
         }

     if (*pa.irule == '1')
     {
         strcpy(cal_rules,"1");

	     /************ �B�z���Y **************/
	     /*** ���~�ר�G�έp�_�l��[eDbgn],�έp�����[eDend],�p������[eCalc_end],�����s�@�ɶ�[exec_time] ***/
	     flen=fprintf(fptr,"%s\t%s\t%s\t%s\t%s\t%s\n",
	                       "���~�ר�:",eDbgn,"~",eDend,"�����s�@�ɶ�:",exec_time);
	     /************************************/
	     }
	     else if (*pa.irule == '2')
	     {
	         strcpy(cal_rules,"2");

	     /************ �B�z���Y **************/
	     /*** �O��~�ר�G�έp�_�l��[eDbgn],�έp�����[eDend],�p������[eCalc_end],�����s�@�ɶ�[exec_time] ***/
	     flen=fprintf(fptr,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n",
	                       "�O��~�ר�:",eDbgn,"~",eDend,"�p������",eCalc_end,"�����s�@�ɶ�:",exec_time);
	     /************************************/
	     }
	     else
	     {
	         strcpy(cal_rules,"3");
	     }

	     /************ �B�z���W�� **********/
         flen=fprintf(fptr,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t\n",
                           "�O�渹�X","�I��","���P���X","�ͮĤ��","���l���d�O","�~�Z�k�ݳ��","�~�Z�k�ݳ��W��","�g��N��","�g��W��",
                           "�q���N��","�q���W��","�~�Ȩӷ�","�j�v�~�ȦW��","�Q�O�I�HID","�Q�O�I�H�W��","�ϥΤH","���إN��",
                           "�t�P�����N��" ,"�s�¨��O","�ۭt�B���O" ,"�u�f���B","�I�إ��","ñ��O�O","�«O�O","�������󦨥�",
                           "�������","�����O�O","�����«O�O","�ߴڥ��","���쥼�M���B","�������M���B","�w�M���B","�ߴڪ��B","�t�P�t��");

     }else{
     	 /* �����q���D"00"DB �ɡA�H���[(append)�覡�}�� */
         if ((fptr=fopen(file_catalog,"a")) == NULL)
         {
             printf("fopen error\n");
         }

	     if (*pa.irule == '1'){
	         strcpy(cal_rules,"1");
	     }else if (*pa.irule == '2'){
	         strcpy(cal_rules,"2");
	     }else{
	         strcpy(cal_rules,"3");
	     }
     }



     /* 960129, �s�W "�~�Ȩӷ�","�u�f���B" */
     EXEC SQL DECLARE CUR_4 CURSOR FOR
               SELECT ipolicy , iins_type , iquota , iofficer ,
                      ibrand  , icar_type , icar_flag , ideduct ,
                      iassured, nuser     , iroute, iresource,
                      mfull_pure, mfull , qfull ,
                      mpure_prem, mprem , qprem , mcommission ,
                      mbgn_outstl , mend_outstl , mstl , qclaim+qend_outstl,
                      mend_outstl+mstl-mbgn_outstl,itag,dply_begin,mdiscount
                 FROM ca_loss_info_temp2
                WHERE iins_type != '21'
                ORDER BY ipolicy , iins_type;
     EXEC SQL OPEN CUR_4;
     for(;;)
     {
         EXEC SQL FETCH CUR_4 INTO :Ipolicy    , :Iins_type  , :Iquota    , :Iofficer   ,
                                   :Ibrand     , :Icar_type  , :Icar_flag , :Ideduct    ,
                                   :sIassured  , :User       , :iroute    , :iresource  ,
                                   :Mfull_pure , :Mfull      , :Qfull     ,
                                   :Mpure_prem , :Mprem      , :Qprem     , :Mcommission,
                                   :Mbgn_outstl, :Mend_outstl, :Mstl      , :Qclaim     ,
                                   :total_mstl , :itag       , :dply_begin,: Mdiscount;

         if (SQLCODE==SQLNOTFOUND) break;

         strcpy(Ipolicy   , trim(Ipolicy));
         strcpy(Iins_type , trim(Iins_type));
         strcpy(Iquota    , trim(Iquota));
         strcpy(Ibrand    , trim(Ibrand));
         strcpy(Icar_type , trim(Icar_type));
         strcpy(Icar_flag , trim(Icar_flag));
         strcpy(Iofficer  , trim(Iofficer));
         strcpy(Ideduct_c , itoa(Ideduct));
         strcpy(iroute    , trim(iroute));
         strcpy(sIassured , trim(sIassured));
         strcpy(User      , trim(User));
         strcpy(itag      , trim(itag));

         rfmtdouble(Mdiscount,   "-#########&.######", Mdiscount_c);
         rfmtdouble(Mprem,       "-#########&.######", Mprem_c);
         rfmtdouble(Qprem,       "-#########&.######", Qprem_c);
         rfmtdouble(Mfull_pure,  "-#########&.######", Mfull_pure_c);
         rfmtdouble(Mpure_prem,  "-#########&.######", Mpure_prem_c);
         rfmtdouble(Mcommission, "-#########&.######", Mcommission_c);
         rfmtdouble(Mfull,       "-#########&.######", Mfull_c);
         rfmtdouble(Qfull,       "-#########&.######", Qfull_c);
         rfmtdouble(Mend_outstl, "-#########&.######", Mend_outstl_c);
         rfmtdouble(Mbgn_outstl, "-#########&.######", Mbgn_outstl_c);
         rfmtdouble(Mstl,        "-#########&.######", Mstl_c);
         rfmtdouble(Qclaim,      "-#########&.######", Qclaim_c);
         rfmtdouble(total_mstl,  "-#########&.######", total_mstl_c);

             sprintf(stmt,
             " SELECT nbranch           \
                 FROM sa_branch_type    \
                WHERE ibranch = ? ");

             $PREPARE get_bra_id FROM $stmt;
             $EXECUTE get_bra_id
                 INTO $nbranch
                USING $Iquota;
             if (SQLCODE == SQLNOTFOUND)
             {
                strcpy(nbranch," ");
             }
             else
             {
                strcpy(nbranch,trim(nbranch));
             }

             $SELECT nname
                INTO $nroute
                FROM officer
               WHERE iofficer = $iroute;
               if (SQLCODE == SQLNOTFOUND)
               {
                  $SELECT nroute
                     INTO $nroute
                     FROM cm_route
                    WHERE iroute = $iroute;
                    if (SQLCODE == SQLNOTFOUND)
                    {
                       strcpy(nroute," ");
                    }
               }

             sprintf(stmt,
             " SELECT nname           \
                 FROM officer         \
                WHERE iofficer = ? ");
             $PREPARE get_nna_id FROM $stmt;
             $EXECUTE get_nna_id
                 INTO $nname
                USING $Iofficer;
             if (SQLCODE == SQLNOTFOUND)
             {
                 strcpy(nname," ");
             }
             else
             {
                 strcpy(nname,trim(nname));
             }

             sprintf(stmt,
             " SELECT First 1 nchi_full   \
                 FROM cu_customer         \
                WHERE ifpce_id = ? ");
             $PREPARE get_cus FROM $stmt;
             $EXECUTE get_cus
                 INTO $nchi_full
                USING $sIassured;
             if (SQLCODE == SQLNOTFOUND)
             {
                strcpy(nchi_full,trim(nchi_full));
             }

             sprintf(stmt,
             " SELECT fins_grp             \
                 FROM insurance_type       \
                WHERE iins_type = ? ");

             $PREPARE get_fins FROM $stmt;
             $EXECUTE get_fins
                 INTO $sFins_grp
                USING $Iins_type;

             if (pa.idata[0] == '2')
             {
                sprintf(stmt,
                 " SELECT First 1 nname   \
                     FROM car1118         \
                    WHERE iofficer = ? ");
                 $PREPARE getnname FROM $stmt;
                 $EXECUTE getnname
                     INTO $dnname
                    USING $Iofficer;
                if (SQLCODE == SQLNOTFOUND)
                {
                   sprintf(stmt,
                   " SELECT First 1 nname   \
                       FROM car1118         \
                      WHERE iroute = ? ");
                   $PREPARE getroute FROM $stmt;
                   $EXECUTE getroute
                       INTO $dnname
                      USING $iroute;
                   if (SQLCODE == SQLNOTFOUND)
                      strcpy(dnname," ");
                }
              }else{
              	 /* 951207 */
              	 strcpy(dnname," ");
              }

              /* 960129, �~�Ȩӷ� */
              $SELECT ncode
                 INTO $nresource
                 FROM cu_code_data
               WHERE itype = '10'
                 AND icode = $iresource;
               if (SQLCODE == SQLNOTFOUND)
               {
                   strcpy(nresource," ");
               }else{
                   strcpy(nresource,trim(nresource));
               }

              /* �t�P�t�� */
              $SELECT NVL(nequipment,' ')
                 INTO $nequipment
                 FROM conv_nequipment
                WHERE ipolicy = $Ipolicy;

              if (SQLCODE == SQLNOTFOUND)
              {
                 strcpy(nequipment," ");
              }


/**************
             flen=fprintf(fptr,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t\n",
                               "�O�渹�X","�I��","���l���d�O","�~�Z�k�ݳ��","�~�Z�k�ݳ��W��","�g��N��","�g��W��",
                               "�q���N��","�q���W��","�~�Ȩӷ�","�j�v�~�ȦW��","¾�ΥN��","�Q�O�I�HID","�Q�O�I�H�W��","�ϥΤH","���إN��",
                               "�t�P�����N��" ,"�s�¨��O","�ۭt�B���O" ,"�u�f���B","�I�إ��","ñ��O�O","�«O�O","�O��",
                               "�������","�����O�O","�����«O�O","�ߴڥ��","���쥼�M���B","�������M���B","�w�M���B","�ߴڪ��B","�t�P�t��");
*****************/

             flen=fprintf(fptr,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t\n",
                               Ipolicy, Iins_type, itag, dply_begin, sFins_grp, Iquota, nbranch, Iofficer, nname, iroute, nroute, nresource , dnname,
                               sIassured, nchi_full, User, Icar_type, Ibrand, Icar_flag, Ideduct_c,Mdiscount_c, Qprem_c, Mprem_c,
                               Mpure_prem_c, Mcommission_c, Qfull_c, Mfull_c, Mfull_pure_c, Qclaim_c,
                               Mbgn_outstl_c, Mend_outstl_c, Mstl_c, total_mstl_c, nequipment);

     }
     EXEC SQL CLOSE CUR_4;
     EXEC SQL FREE  CUR_4;

     fclose(fptr);

     if (((fAllDB == 'Y')&&(k_tmp==0))||(fAllDB == 'N')){
	     EXEC SQL INSERT INTO rptftplist (nuserid, ipgid,     noutfile,   dcreate)
	                              VALUES ($userid, 'car1118', $filename1, $exec_time);
	 }

     return M_CM_OK;

errexit:
     printf("SOLCODE=%d sqlca.sqlerrm=%s\n",SQLCODE,sqlca.sqlerrm);
     printf(errmsg,"SOLCODE=%s sqlca.sqlerrm=%s",SQLCODE,sqlca.sqlerrm);
     fprintf(fptr_err,"%s\n",errmsg);
     return ;
}


/************************************************************************/
/* �ˮ֫O�I�����O�_���|�~:                                              */
/* ����,�����o�ͮĤ�����褸�~��,�A�̦��~������p��̪񤧶|�~(�褸�~),  */
/* �A�N�Ӧ褸�~(�|�~)�[�W���(2��29��)��,                               */
/* �ˮָӶ|�~�O�_���O�I������,�Y��,�h�Ǧ^�@flag��[1],�_�h��[0]        */
/************************************************************************/
long check_leap_year(p_dply_bgn, p_dply_end)
long p_dply_bgn, p_dply_end;   /**** �O��ͮĤΨ����� ****/
{
     long     Leap_flag;
     char     ply_yy[4],ply_mm[3],ply_dd[3];
     int      x1, x2, x3, x4;
     int      mod_year;
     long     leap_year, leap_year_ch, leap_year_flag;
     char     Cleap_year[13];
     long     lyyyy;

     cm_long_split_3ymd(p_dply_bgn , ply_yy , ply_mm , ply_dd);

     mod_year = (atoi(ply_yy)+1911) % 4;
     if (mod_year != 0)
     {
         x4 = 4 - mod_year;
     }
     else
     {
         x4 = 0;
     }
     leap_year_ch = atoi(ply_yy) + x4;

     lyyyy = 1911 + leap_year_ch;
     x1 = lyyyy % 4;
     x2 = lyyyy % 100;
     x3 = lyyyy % 400;

     if (x1==0)
         leap_year_flag=1;
     if (x2==0)
         leap_year_flag=0;
     if (x3==0)
         leap_year_flag=1;

     if (leap_year_flag == 0)
     {
         leap_year_ch = leap_year_ch + 4;

         lyyyy = 1911 + leap_year_ch;
         x1 = lyyyy % 4;
         x2 = lyyyy % 100;
         x3 = lyyyy % 400;

         if (x1==0)
             leap_year_flag=1;
         if (x2==0)
             leap_year_flag=0;
         if (x3==0)
             leap_year_flag=1;
     }

     if (leap_year_flag == 1)
     {
         strcpy(Cleap_year, ltoa(leap_year_ch));
         strcat(Cleap_year, "/02/29");
         leap_year = cm_ymd_cdate(Cleap_year);

         if (p_dply_bgn <= leap_year && p_dply_end >= leap_year)
             Leap_flag = 1;
         else
             Leap_flag = 0;
     }
     else
     {
         Leap_flag = 0;
     }

     return Leap_flag;
}

long car1118_read_file()
{
char   *bp;
int    rc,i,j,k,m,n;

    $whenever sqlerror goto errexit;

    rc=car1118_create_temp();
    if (rc != SUCCESS)
        return rc;

    sprintf(filename,"%s/dat/car/car1118.txt",sApHome);
    if ((fp=fopen(filename,"r"))==NULL)
    {
       sprintf(msgbuf,"%s file open fail ",filename);
       return FALSE;
    }
    flen=1024;
    if ((bp=malloc(flen))==NULL)
    {
       sprintf(msgbuf,"System malloc failed !");
       return FALSE;
    }

    for (i=0;(feof(fp)==0);i++)
    {
        printf("feof[%d]\n",feof(fp));
        memset(bp,0x00,flen);
        fgets(bp,flen,fp);
        if (bp[0]==0x00)
           break;
        for(j=0;j<4;j++)
           memset(sdata[j],0x00,41);
        k=m=n=0;
        for (j=0;j<flen;j++)
        {
            if (bp[j]=='\t' || bp[j]=='\0' || bp[j]=='\n')
            {
                strncpy(sdata[k],bp+m,j-m);
                sdata[k][j-m]='\0';
                m=j+1;
                k++;
            }
            if (bp[j]=='\n')
                break;
            if (k > 3) break;
        }
        if (sdata[0][0]=='\0') continue;
        rtrim_alldata();

        printf("sdata0[%s],sdata1[%s],sdata2[%s]\n",sdata[0],sdata[1],sdata[2]);
        $INSERT INTO car1118 VALUES ($sdata[0],$sdata[1],$sdata[2]);

        if (rc!=SUCCESS)
           return rc;
    }

    return SUCCESS;
errexit:
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car1118_create_temp()
{
    $whenever sqlerror goto errexit;
    $create temp table car1118
    (
      nname      char(40)    default ' ',
      iofficer   char(10)    default ' ',
      iroute     char(20)    default ' '
    )with no log;

    $create index car1118_1 on car1118(iofficer);
    $create index car1118_2 on car1118(iroute);

    return SUCCESS;
errexit:
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/*--------------------------------------------------------------------*/
rtrim_alldata()
{
    int  x;
    for(x=0;x<4;x++)
    {
       strcpy(sdata[x],rtrim(sdata[x]));
       if (strlen(sdata[x])>20) printf("[%d][%s]\n",strlen(sdata[x]),sdata[x]);
    }
}
/*--------------------------------------------------------------------*/

long car1118_insert_stl(f_iclaim,f_itag,f_ipolicy,f_daccident,f_iins_type,
                        f_ibrand,f_mcover,f_mstl,f_mrecover,f_nuser,f_nequip,
                        f_out,f_decide,f_mplace,f_factory,f_nassured,f_dclose)
$char f_iclaim[21];
$char f_itag[CA_TAG_NUM];
$char f_ipolicy[21];
$long f_daccident;
$char f_iins_type[INSURANCE_TYPE];
$double f_mcover;
$double f_mstl;
$double f_mrecover;
$char f_nuser[19];
$char f_nequip[31];
$char f_ibrand[9];
$long f_out;
$long f_decide;
$long f_mplace;
$char f_factory[101];
$char f_nassured[21];
$char f_dclose[11];
{
$char ibrand[9];
     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     strncpy(ibrand,f_ibrand,4);
     ibrand[4] = '\0';

     printf("f_iclaim[%s],f_itag[%s],f_ipolicy[%s]\n",
             f_iclaim    ,f_itag    ,f_ipolicy);

     printf("f_daccident[%ld],f_iins_type[%s]\n",f_daccident,f_iins_type);

     printf("f_mcover[%f],f_mstl[%f],f_mrecover[%f]\n",f_mcover,f_mstl,f_mrecover);

     printf("f_nuser[%s],f_nequip[%s]\n",f_nuser,f_nequip);

     $INSERT INTO car1118_clm_dtl
       (iclaim,iins_type,itag,ipolicy,daccident,ibrand,mapp_cover,
        mstl,mrecovery,nuser,nequipment,moutstanding,mdecide,
        mplace_fee,factory,nassured,dclose)
       VALUES
       ($f_iclaim,$f_iins_type,$f_itag,$f_ipolicy,$f_daccident,$ibrand,$f_mcover,
        $f_mstl,$f_mrecover,$f_nuser,$f_nequip,$f_out,$f_decide,
        $f_mplace,$f_factory,$f_nassured,$f_dclose);

     return M_CM_OK;

errexit:
     printf("SOLCODE=%d sqlca.sqlerrm=%s\n",SQLCODE,sqlca.sqlerrm);
     printf(errmsg,"SOLCODE=%s sqlca.sqlerrm=%s",SQLCODE,sqlca.sqlerrm);
     fprintf(fptr_err,"%s\n",errmsg);
     return SQLCODE;
}

/***** �߮ש��Ӹ�� ****/
long loss_info_build5()
{
     EXEC SQL BEGIN DECLARE SECTION;

     char   stmt[2048];
     char   filename1[200];
     char  iclaim[21];
     char  iins_type[INSURANCE_TYPE];
     char  itag[CA_TAG_NUM];
     char  ipolicy[21];
     char  daccident[21];
     char  ibrand[9];
     long  mapp_cover;
     long  mstl;
     long  mrecovery;
     long  moutstanding;
     long  mdecide;
     char  nuser[21];
     char  nequipment[31];
     long  mplace;
     char  factory[101];
     char  nassured[21];
     char  dclose[11];


     char  mapp_cover_c[21];
     char  mstl_c[21];
     char  mrecovery_c[21];
     char  moutstanding_c[21];
     char  mdecide_c[21];
     char  mplace_c[21];
     char  nins_type[29];


     EXEC SQL END   DECLARE SECTION;


     char file_catalog[200];          /**** cat:filename[�Ҧb�ؿ�]+filename1[�ɮצW��] ****/
     char cal_rules[2];

     /*************************************************************/
     /*************************************************************/
     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     /**** filename1 �ɮצW�� ****/
     filename1[0]='\0';
     file_catalog[0]='\0';

     if (*pa.irule == '1'){
         strcpy(cal_rules,"1");
     }else if (*pa.irule == '2'){
         strcpy(cal_rules,"2");
     }else{
         strcpy(cal_rules,"3");
     }

     sprintf(filename1 , "c1118_%s_�߮�[%s].%s",cal_rules,exec_eDbgn,outputf);
     strcpy(file_catalog, trim(filename));
     strcat(file_catalog, trim(filename1));

     printf("{loss_info_build1.0001}:filename[%s],filename1[%s]\n",filename,filename1);
     printf("{loss_info_build1.0002}:file_catalog[%s]\n",file_catalog);

     /* 951205,�����q��"00"DB �άO�����q�ɡA�HW�覡�}�ҡA�B�g�J���Y */
     if (((fAllDB == 'Y')&&(k_tmp==0))||(fAllDB == 'N')){
         if ((fptr=fopen(file_catalog,"w")) == NULL)
         {
             printf("fopen error\n");
         }

	     if (*pa.irule == '1')
	     {
	         strcpy(cal_rules,"1");

	     /************ �B�z���Y **************/
	     /*** ���~�ר�G�έp�_�l��[eDbgn],�έp�����[eDend],�p������[eCalc_end],�����s�@�ɶ�[exec_time] ***/
	     flen=fprintf(fptr,"%s\t%s\t%s\t%s\t%s\t%s\n",
	                       "���~�ר�:",eDbgn,"~",eDend,"�����s�@�ɶ�:",exec_time);
	     /************************************/
	     }
	     else if (*pa.irule == '2')
	     {
	         strcpy(cal_rules,"2");

	     /************ �B�z���Y **************/
	     /*** �O��~�ר�G�έp�_�l��[eDbgn],�έp�����[eDend],�p������[eCalc_end],�����s�@�ɶ�[exec_time] ***/
	     flen=fprintf(fptr,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n",
	                       "�O��~�ר�:",eDbgn,"~",eDend,"�p������",eCalc_end,"�����s�@�ɶ�:",exec_time);
	     /************************************/
	     }
	     else
	     {
	         strcpy(cal_rules,"3");
	     }

	     /************ �B�z���W�� **********/

	      flen=fprintf(fptr,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n",
	                        "�߮׸��X","�I�إN��","�I�ئW��","�P�Ӹ��X","�O�渹�X",
				"�Q�O�I�H",
	                        "�X�I���","�w�����B","�ߥI���B","�l�v���B","���M���B",
	                        "�w�M���B","���פ��","�N���O��","�ϥΤH","�t�P�t��","�t�P����",
	                        "�O�׼t");
     }else{
     	 /* �����q���D"00"DB �ɡA�H���[(append)�覡�}�� */
         if ((fptr=fopen(file_catalog,"a")) == NULL)
         {
             printf("fopen error\n");
         }

	     if (*pa.irule == '1'){
	         strcpy(cal_rules,"1");
	     }else if (*pa.irule == '2'){
	         strcpy(cal_rules,"2");
	     }else{
	         strcpy(cal_rules,"3");
	     }
     }

     sprintf(stmt,
     " SELECT iclaim,iins_type,itag,ipolicy,daccident,mapp_cover, \
              mstl,mrecovery,nuser,nequipment,ibrand,moutstanding, \
              mdecide,mplace_fee,factory,nassured,dclose, \
              (select nins_type from insurance_type where iins_type = \
              a.iins_type) \
         FROM car1118_clm_dtl a \
        ORDER BY iclaim,iins_type ");
     $PREPARE get_clm_d FROM $stmt;
     $DECLARE get_clm_d_cur CURSOR FOR get_clm_d;
     $OPEN    get_clm_d_cur;
     for(;;)
     {
     $FETCH   get_clm_d_cur
       INTO   $iclaim,$iins_type,$itag,$ipolicy,$daccident,$mapp_cover,
              $mstl,$mrecovery,$nuser,$nequipment,$ibrand,$moutstanding,
              $mdecide,$mplace,$factory,$nassured,$dclose,$nins_type;
       if (SQLCODE == SQLNOTFOUND) break;

         rfmtlong(mapp_cover,  "-##########&" ,mapp_cover_c);
         rfmtlong(mstl,        "-##########&" ,mstl_c);
         rfmtlong(mrecovery,   "-##########&" ,mrecovery_c);
	 rfmtlong(moutstanding,"-##########&" ,moutstanding_c);
	 rfmtlong(mdecide     ,"-##########&" ,mdecide_c);
	 rfmtlong(mplace      ,"-##########&" ,mplace_c);

         strcpy(iclaim      ,trim(iclaim));
         strcpy(iins_type   ,trim(iins_type));
         strcpy(itag        ,trim(itag));
         strcpy(ipolicy     ,trim(ipolicy));
         strcpy(daccident   ,trim(daccident));
         strcpy(mapp_cover_c,trim(mapp_cover_c));
         strcpy(mstl_c      ,trim(mstl_c));
         strcpy(mrecovery_c ,trim(mrecovery_c));
         strcpy(nuser       ,trim(nuser));
         strcpy(nequipment  ,trim(nequipment));
         strcpy(ibrand      ,trim(ibrand));
         strcpy(factory     ,trim(factory));
         strcpy(nassured    ,trim(nassured));
         strcpy(nins_type   ,trim(nins_type));

	 strcpy(moutstanding_c,trim(moutstanding_c));
	 strcpy(mdecide_c   ,trim(mdecide_c));
         strcpy(mplace_c    ,trim(mplace_c));

         flen = fprintf(fptr,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n",
                              iclaim,iins_type,nins_type,itag,ipolicy,nassured,
                              daccident,mapp_cover_c,mstl_c,mrecovery_c,
                              moutstanding_c,mdecide_c,dclose,mplace_c,nuser,
                              nequipment,ibrand,factory);

     }
     $CLOSE get_clm_d_cur;
     $FREE  get_clm_d_cur;

     fclose(fptr);

     if (((fAllDB == 'Y')&&(k_tmp==0))||(fAllDB == 'N')){
	     EXEC SQL INSERT INTO rptftplist (nuserid, ipgid,     noutfile,   dcreate)
	                              VALUES ($userid, 'car1118', $filename1, $exec_time);
     }

     return M_CM_OK;

errexit:
     printf("SOLCODE=%d sqlca.sqlerrm=%s\n",SQLCODE,sqlca.sqlerrm);
     printf(errmsg,"SOLCODE=%s sqlca.sqlerrm=%s",SQLCODE,sqlca.sqlerrm);
     fprintf(fptr_err,"%s\n",errmsg);
     return ;
}


/*951122*/
int  Insert_CLAIM_INS(c1, c2, i1, dbl2, dbl3, dbl4, i5, i6, dbl7, dbl8, i9, i10, i11)
char *c1, *c2;
double dbl2, dbl3, dbl4 ,dbl7, dbl8;
int  i1, i5, i6, i9, i10, i11;
{
    Icurr_CLM=(struct CLAIM_INS *)malloc(sizeof(struct CLAIM_INS));
    if (Icurr_CLM==NULL) return FAIL;
    if (Ifirst_CLM==NULL)
    {
        Ifirst_CLM=Ilast_CLM=Icurr_CLM;
        Icurr_CLM->next=NULL;
    }
    else
    {
        Ilast_CLM->next = Icurr_CLM;
        Ilast_CLM       = Icurr_CLM;
        Icurr_CLM->next = NULL;
    }

    strcpy(Icurr_CLM->iins_type,     c1);
    strcpy(Icurr_CLM->iins_ply,      c2);

	Icurr_CLM->flag_ins_type            = i1 ;
	Icurr_CLM->tmp_ins_ply_mbgn         = dbl2 ;
	Icurr_CLM->tmp_ins_ply_mend         = dbl3 ;
	Icurr_CLM->tmp_ins_ply_mstl         = dbl4 ;
	Icurr_CLM->qbgn_outstl_ins_type     = i5 ;
	Icurr_CLM->qend_outstl_ins_type     = i6 ;
	Icurr_CLM->qclaim_ins_type          = dbl7 ;
	Icurr_CLM->tmp_ins_ply_mstl_dend    = dbl8 ;
	Icurr_CLM->tmp_ins_ply_mstl_dbgn    = i9 ;
	Icurr_CLM->flag_ins_ply_close_dbgn  = i10 ;
	Icurr_CLM->flag_ins_ply_close_dend  = i11 ;

    return SUCCESS;
}

/*951122*/
int Scan_Ins_List(ins_list,ins)
char *ins_list;
char *ins;
{
   char *p;
   char ins_list1[80];
   char ins1[4];

   strcpy(ins_list1,trim(ins_list));

   strcpy(ins1,trim(ins));

   p = strtok(ins_list1,INS_DELIMITER) ;   /* ���o�Ĥ@�� iins_type */

   while(p != NULL){
       if (strcmp(p,ins1)== 0){
           return SUCCESS;
       }else{
           p = strtok(NULL,INS_DELIMITER);     /* ���o�U�@�� iins_type*/
       }
   }
   return FAIL;
}
