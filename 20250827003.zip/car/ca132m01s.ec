/************************************************/
/*   �{���W�� : ca132m01s.ec                    */
/*   �s�W��� : 2004/05/10                      */
/*   �@�~�W�� : �~�רҰ�����@�@�~              */
/************************************************/

#include <stdio.h>
#include <string.h>
#include <decimal.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "commsgs.h"
#include "carmsgs.h"
$include sqlca;
#include "safeclib.h"

long MsgCode;

long car132(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car132_insert(),car132_single_query(),car132_multiple_query(),
      car132_update_exec(),car132_squery();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'A':
           rtncode=car132_insert(reply);
           break;
  case 'B':
           rtncode=car132_multiple_insert(reply);
           break;         
  case 'Q':
           rtncode=car132_single_query(reply);
           break;
  case 'M':
           rtncode=car132_multiple_query(reply);
           break;
  case 'D':
  case 'U':
           rtncode=car132_update_exec(reply,command,com_len);
           break;
  default :
        return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
 }
 return(rtncode);
}


long car132_insert(reply)
serverReply reply;
{
     $char DBName[5];
     $char c_cyear[4],c_holiday_type[3],c_holiday_bgn[11],c_holiday_end[11],c_holiday_h_bgn[13],c_holiday_h_end[13];

     int tmp_len;
     DBinfo *list;
     int i, j, is_add_fail=0, api_f;
     $char stmt_buf[512];
     long MsgCode;
     
     cm_buf_get("%s",DBName);
     cm_buf_get("%s %s %s %s",c_cyear,c_holiday_type,c_holiday_bgn,c_holiday_end);
     cm_buf_get("%s %s",c_holiday_h_bgn,c_holiday_h_end);
     
     strcpy(c_holiday_bgn,cm_to_infdate(c_holiday_bgn));
     strcpy(c_holiday_end,cm_to_infdate(c_holiday_end));
     strcpy(c_holiday_h_bgn,cm_sysd_edatetime(c_holiday_h_bgn));
     strcpy(c_holiday_h_end,cm_sysd_edatetime(c_holiday_h_end));
     
     printf("c_holiday_h_bgn[%s]\n",c_holiday_h_bgn);
     printf("c_holiday_h_end[%s]\n",c_holiday_h_end);
          
     $WHENEVER SQLERROR GOTO errexit;

	 if (db_select(DBName) == False) 
	  { 
	   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
	    return M_CM_DB_NOTOPEN;
	   else  
	    return apiRC;
	  }
	 
	 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
	  {
	   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
	    return M_CM_NOT_DBLIST;
	   return apiRC;
	  }
	  
	 $BEGIN WORK;
	 for(j=0;j<i;j++)
	 {
		  sprintf_s(stmt_buf, sizeof stmt_buf, "INSERT INTO %s:ca_holiday "
				   " (cyear,holiday_type,holiday_bgn,holiday_end,holiday_h_bgn,holiday_h_end) VALUES (?,?,?,?,?,?)",
				   list[j].dbname);
		
		  $PREPARE a_id FROM $stmt_buf;
		  if(SQLCODE != 0)
		   {
		    is_add_fail = 1;
		    break;
		   }
		  $EXECUTE a_id USING $c_cyear,$c_holiday_type,$c_holiday_bgn,$c_holiday_end,$c_holiday_h_bgn,$c_holiday_h_end;
		  if(SQLCODE != 0)
		   {
		    is_add_fail = 1;
		    break;
		   }
		  cm_buf_init(ReplyBuf);
		  cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);
		  tmp_len = cm_buf_len(ReplyBuf);
		  if( j == i-1 )
		     api_f = api_OKComplete;
		  else
		     api_f = api_OK;
		
		  if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
		    {
		     is_add_fail = 2;
		     break;
		    }  
		 #ifdef DEBUG 
		   printf("INSERT %d\n", j+1);
		 #endif
	 } /* for loop */
	
	 if( is_add_fail == 1 ) goto errexit;
	
	 if( is_add_fail == 2 ) 
	  {
	   $ROLLBACK WORK;
	   return apiRC;
	  }
	
	
	 $WHENEVER SQLERROR GOTO errexit;
	 $COMMIT WORK;
	 return api_OKComplete;
	
errexit:
  $WHENEVER SQLERROR CONTINUE;    
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True) 
   return MsgCode;
  else  
   return apiRC;
}

/*-----------------------------------------------------------------*/
long car132_multiple_insert(reply)
serverReply reply;
{
     $char DBName[5];
     $char c_cyear[4],c_holiday_type[3],c_holiday_bgn[11],c_holiday_end[11],c_holiday_h_bgn[13],c_holiday_h_end[13];
     $int  wCount;
     $long l_holiday_bgn,l_holiday_end,l_holiday_h_bgn,l_holiday_h_end;
     $char s_holiday_bgn[11],s_holiday_end[11],s_holiday_h_bgn[13],s_holiday_h_end[13];
     
     $char tmp_holiday_h_bgn[11],tmp_holiday_h_end[11];
     int k;
     int tmp_len;
     DBinfo *list;
     int i, j, is_add_fail=0, api_f;
     $char stmt_buf[512];
     long MsgCode;
     
     cm_buf_get("%s",DBName);
     cm_buf_get("%s %s %s %s",c_cyear,c_holiday_type,c_holiday_bgn,c_holiday_end);
     cm_buf_get("%s %s",c_holiday_h_bgn,c_holiday_h_end);
     cm_buf_get("%d",&wCount);                                    /* the record count we're going to insert */
     printf("wCount=[%d]\n",wCount);
     
     strcpy(c_holiday_bgn,cm_to_infdate(c_holiday_bgn));
     strcpy(c_holiday_end,cm_to_infdate(c_holiday_end));
     strcpy(c_holiday_h_bgn,cm_sysd_edatetime(c_holiday_h_bgn));  /* cht datetime(string) => informix datetime(string)*/
     strcpy(c_holiday_h_end,cm_sysd_edatetime(c_holiday_h_end));
     
     printf("c_holiday_bgn[%s]\n",c_holiday_bgn);
     printf("c_holiday_end[%s]\n",c_holiday_end);     
     printf("c_holiday_h_bgn[%s]\n",c_holiday_h_bgn);
     printf("c_holiday_h_end[%s]\n",c_holiday_h_end);
    
    
     $WHENEVER SQLERROR GOTO errexit;

	 if (db_select(DBName) == False) 
	  { 
	   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
	    return M_CM_DB_NOTOPEN;
	   else  
	    return apiRC;
	  }
	 
	 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
	  {
	   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
	    return M_CM_NOT_DBLIST;
	   return apiRC;
	  }
	  
	 $BEGIN WORK;
	 for(j=0;j<i;j++)
	 {
	 	
	 	for(k=1;k<=wCount;k++){
		 	 /*   process date and datetime  --- start   */ 		     

		     strcpy(tmp_holiday_h_bgn,cm_sysd_cdate_100(c_holiday_h_bgn));     /*  informix datetime(string) =>  cht date(string) only */
		     strcpy(tmp_holiday_h_end,cm_sysd_cdate_100(c_holiday_h_end));
		     printf("tmp_holiday_h_end(cht_date_only)=[%s]\n",tmp_holiday_h_end);  
		     strcpy(tmp_holiday_h_bgn,cm_to_infdate(tmp_holiday_h_bgn));   /*  cht date(string) only =>  informix date(string) only */     
		     strcpy(tmp_holiday_h_end,cm_to_infdate(tmp_holiday_h_end));
		     printf("tmp_holiday_h_end(to_informix_date)=[%s]\n",tmp_holiday_h_end);
		     
		     rstrdate(c_holiday_bgn,&l_holiday_bgn);                       /* informix date(string) => informix date(long)  */
		     rstrdate(c_holiday_end,&l_holiday_end);
		     rstrdate(tmp_holiday_h_bgn,&l_holiday_h_bgn);   
		     rstrdate(tmp_holiday_h_end,&l_holiday_h_end); 
		     
		     if (k>1){  /* start add weekdays only when 2nd loop and after  */
			     l_holiday_bgn   += 7;
			     l_holiday_end   += 7;
			     l_holiday_h_bgn += 7;
			     l_holiday_h_end += 7;
		     }
		     rfmtdate(l_holiday_bgn, "mm/dd/yyyy", s_holiday_bgn);         /* informix date(long) => date(formatted string) */ 
		     rfmtdate(l_holiday_end, "mm/dd/yyyy", s_holiday_end);
		     rfmtdate(l_holiday_h_bgn, "yyyy-mm-dd", s_holiday_h_bgn);
		     rfmtdate(l_holiday_h_end, "yyyy-mm-dd", s_holiday_h_end);
		     
		     strcat(s_holiday_h_bgn," 12");                                /* concat "hour" to make the "datetime" string  */ 
		     strcat(s_holiday_h_end," 12");
		     /*   process date and datetime --- end   */
		    
		     printf("c_cyear=[%s]\n",c_cyear);
		     printf("c_holiday_type=[%s]\n",c_holiday_type);		     
		     printf("s_holiday_bgn=[%s]\n",s_holiday_bgn);
			 printf("s_holiday_end=[%s]\n",s_holiday_end);
		     printf("s_holiday_h_bgn=[%s]\n",s_holiday_h_bgn);
		     printf("s_holiday_h_end=[%s]\n",s_holiday_h_end);
		 	
			 sprintf_s(stmt_buf, sizeof stmt_buf, "INSERT INTO %s:ca_holiday "
					   " (cyear,holiday_type,holiday_bgn,holiday_end,holiday_h_bgn,holiday_h_end) VALUES (?,?,?,?,?,?)",
					   list[j].dbname);
			 printf("stmt_buf[%d]=[%s]\n",k,stmt_buf);
			 $PREPARE a_id FROM $stmt_buf;
			 if(SQLCODE != 0)
			   {
			    is_add_fail = 1;
			    break;
			   }
			 $EXECUTE a_id USING $c_cyear,$c_holiday_type,$s_holiday_bgn,$s_holiday_end,$s_holiday_h_bgn,$s_holiday_h_end;
			 if(SQLCODE != 0)
			   {
			    is_add_fail = 1;
			    break;
			   }

			 #ifdef DEBUG 
			   printf("INSERT %d\n", (j+1)*k); 
			 #endif

			 strcpy(c_holiday_bgn,s_holiday_bgn);
			 strcpy(c_holiday_end,s_holiday_end);		 
			 strcpy(c_holiday_h_bgn,s_holiday_h_bgn);
			 strcpy(c_holiday_h_end,s_holiday_h_end);
		}/* k for loop */
		
	   cm_buf_init(ReplyBuf);
	   cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);
	   tmp_len = cm_buf_len(ReplyBuf);
  
	   if( j == i-1 )
	      api_f = api_OKComplete;
	   else
	      api_f = api_OK;

	   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
	     {
	      is_add_fail = 2;
	      break;
	     }  	
       if( is_add_fail == 1 ) goto errexit;
	
	   if( is_add_fail == 2 ) 
	     {
	     $ROLLBACK WORK;
	     return apiRC;
	    }
	
	  $WHENEVER SQLERROR GOTO errexit;
	  $COMMIT WORK;
	  return api_OKComplete;	     	
   } /* j for loop */

errexit:
  $WHENEVER SQLERROR CONTINUE;    
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True) 
   return MsgCode;
  else  
   return apiRC;
}


/*-----------------------------------------------------------------*/
long car132_single_query(reply)
serverReply reply;
{
 
 $char DBName[5];
 $char c_cyear[4],c_holiday_type[3],c_holiday_bgn[11],c_holiday_end[11],c_holiday_h_bgn[15],c_holiday_h_end[15];

 int tmp_len;
 
 cm_buf_get("%s",DBName);
 cm_buf_get("%s %s %s %s",c_cyear,c_holiday_type,c_holiday_bgn,c_holiday_end);

 strcpy(c_holiday_bgn,cm_to_infdate(c_holiday_bgn));
 strcpy(c_holiday_end,cm_to_infdate(c_holiday_end));
 
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }
 
 $SELECT cyear,holiday_type,holiday_bgn,holiday_end,holiday_h_bgn||'',holiday_h_end||''
    INTO $c_cyear,$c_holiday_type,$c_holiday_bgn,$c_holiday_end,$c_holiday_h_bgn,$c_holiday_h_end
    FROM ca_holiday
   WHERE cyear = $c_cyear
     AND holiday_type = $c_holiday_type
     AND holiday_bgn  = $c_holiday_bgn
     AND holiday_end  = $c_holiday_end;

 if(SQLCODE==SQLNOTFOUND)
 {
  if(exitsub(reply,M_CM_NOT_FOUND) == True)
    return M_CM_NOT_FOUND;
  else
    return apiRC;
 }

 strcpy(c_holiday_bgn,cm_from_infdate_100(c_holiday_bgn));
 strcpy(c_holiday_end,cm_from_infdate_100(c_holiday_end));
 strcpy(c_holiday_h_bgn,cm_sysd_cdatetime_100(c_holiday_h_bgn));
 strcpy(c_holiday_h_end,cm_sysd_cdatetime_100(c_holiday_h_end));
 
 printf("c_holiday_h_bgn[%s]\n",c_holiday_h_bgn);
 printf("c_holiday_h_end[%s]\n",c_holiday_h_end);
 cm_buf_init(ReplyBuf);
 cm_buf_put("%l %s %s %s %s %s %s",
             M_CM_OK,c_cyear,c_holiday_type,c_holiday_bgn,c_holiday_end,c_holiday_h_bgn,c_holiday_h_end);


 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

 errexit:
   MsgCode = cm_show_sql_err("ca132_single_query", NULL);
  if(exitsub(reply,MsgCode) == True)
   return SQLCODE;
  else
   return apiRC;
}

long car132_multiple_query(reply)
serverReply reply;
{
 $char DBName[5];
 $char cyear[4],holiday_type[3],holiday_bgn[11],holiday_end[11],holiday_h_bgn[15],holiday_h_end[15]; 
 $char c_cyear[4],c_holiday_type[3],c_holiday_bgn[11],c_holiday_end[11],c_holiday_h_bgn[15],c_holiday_h_end[15]; 
 
 $char stmt[1024],stmt1[50],stmt2[50],stmt3[50],stmt4[50];

 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;

 cm_buf_get("%s",DBName);
 cm_buf_get("%s %s %s %s",cyear,holiday_type,holiday_bgn,holiday_end);

 
 if ((strncmp(cyear,"*",1)==0)){
     sprintf_s(stmt1, sizeof stmt1, "where cyear matches '%s' ",cyear);
 }else{
    sprintf_s(stmt1, sizeof stmt1, "where cyear = '%s' ",cyear);
  }   
 if ((strncmp(holiday_type,"*",1)==0)){
    sprintf_s(stmt2, sizeof stmt2, "and holiday_type matches '%s' ",holiday_type);
 }else{
    sprintf_s(stmt2, sizeof stmt2, "and holiday_type = '%s' ",holiday_type);
  }   
 if ((strncmp(holiday_bgn,"*",1)==0)){
    /*sprintf(stmt3,"and holiday_bgn matches '%s' ",holiday_bgn);    */
    sprintf_s(stmt3, sizeof stmt3, " ");
 }else{
    strcpy(holiday_bgn,cm_to_infdate(holiday_bgn)); 
    sprintf_s(stmt3, sizeof stmt3, "and holiday_bgn = '%s' ",holiday_bgn);    
  }
  if ((strncmp(holiday_end,"*",1)==0)){
    sprintf_s(stmt4, sizeof stmt4, " ");
 }else{
    strcpy(holiday_end,cm_to_infdate(holiday_end));
    sprintf_s(stmt4, sizeof stmt4, "and holiday_end = '%s' ",holiday_end);
 }
 
 printf("stmt1=[%s] stmt2=[%s] stmt3=[%s] stmt4=[%s]\n",stmt1,stmt2,stmt3,stmt4);
 
 
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

    sprintf_s(stmt, sizeof stmt, "SELECT cyear,holiday_type,holiday_bgn,holiday_end,holiday_h_bgn,holiday_h_end "
                   " FROM ca_holiday "
                   " %s %s %s %s  "
                   " ORDER BY 1,2,3",stmt1,stmt2,stmt3,stmt4);
                
 $PREPARE rs FROM $stmt;
 $DECLARE q_cur CURSOR FOR rs;
 $OPEN q_cur;
 
 for(;;)
  {
    $FETCH q_cur INTO $c_cyear,$c_holiday_type,$c_holiday_bgn,$c_holiday_end,$c_holiday_h_bgn,$c_holiday_h_end;
   
    if (SQLCODE != 0) break;
    
    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();
     }

	 strcpy(c_holiday_bgn,cm_from_infdate_100(c_holiday_bgn));
	 strcpy(c_holiday_end,cm_from_infdate_100(c_holiday_end));
	 strcpy(c_holiday_h_bgn,cm_sysd_cdatetime_100(c_holiday_h_bgn));
	 strcpy(c_holiday_h_end,cm_sysd_cdatetime_100(c_holiday_h_end));

	 printf("c_holiday_h_bgn[%s]\n",c_holiday_h_bgn);
	 printf("c_holiday_h_end[%s]\n",c_holiday_h_end);
    
    cm_buf_put("%s %s %s %s %s %s",c_cyear,c_holiday_type,c_holiday_bgn,c_holiday_end,c_holiday_h_bgn,c_holiday_h_end);
    
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
        $CLOSE q_cur;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;

        if(replycnt > 5) sleep(3);
        else if(replycnt > 3) sleep(2);
        else if(replycnt > 1) sleep(1);

        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        
	    printf("c_holiday_bgn[%s]\n",c_holiday_bgn);
	    printf("c_holiday_end[%s]\n",c_holiday_end); 
	    printf("c_holiday_h_bgn[%s]\n",c_holiday_h_bgn);
	    printf("c_holiday_h_end[%s]\n",c_holiday_h_end);
        cm_buf_put("%s %s %s %s %s %s",c_cyear,c_holiday_type,c_holiday_bgn,c_holiday_end,c_holiday_h_bgn,c_holiday_h_end);

        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
  } /* for loop */

 $CLOSE q_cur;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
    if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
      return M_CM_NOT_FOUND;                               /*?*/
    else
      return apiRC;
  }

 errexit:
   MsgCode = cm_show_sql_err("ca132_multiple_query", NULL);
   if(exitsub(reply,MsgCode) == True)
     return SQLCODE;
   else
     return apiRC;
}
           
/*-----------------------------------------------------------------*/

long car132_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
        
 $char DBName[5];
 $char cur_cyear[4],cur_holiday_type[3],cur_holiday_bgn[11],cur_holiday_end[11],cur_holiday_h_bgn[15],cur_holiday_h_end[15]; 
 $char u_cyear[4],u_holiday_type[3],u_holiday_bgn[11],u_holiday_end[11],u_holiday_h_bgn[15],u_holiday_h_end[15]; 
 $char q_cyear[4],q_holiday_type[3],q_holiday_bgn[11],q_holiday_end[11],q_holiday_h_bgn[15],q_holiday_h_end[15]; 
 
   
 char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
 int tmp_len,raw_len; long dummy;
 DBinfo *list;
 int i, j, is_del_fail=0, is_upd_fail=0;
 $char stmt_buf[300];

 comm = (char *) command;
 cm_buf_init(command);
 cm_buf_get("%c %s",&option,DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

 memcpy(&raw_len,&comm[com_len],sizeof(int));
 pos = &comm[com_len+sizeof(int)];
 raw_ptr = malloc(raw_len);
 if (raw_ptr != (char*)0)
  memcpy(raw_ptr,pos,raw_len);
 else
  { 
   return exitsub(reply,M_CM_NOT_MALLOC) ? M_CM_NOT_MALLOC : apiRC;
  }

 cm_buf_init(raw_ptr);          /* get index key from old record */
 
 cm_buf_get("%l %s %s %s %s %s %s ",             
             &dummy,q_cyear,q_holiday_type,q_holiday_bgn,q_holiday_end,q_holiday_h_bgn,q_holiday_h_end);

 strcpy(q_holiday_bgn,cm_to_infdate(q_holiday_bgn));
 strcpy(q_holiday_end,cm_to_infdate(q_holiday_end));
 strcpy(q_holiday_h_bgn,cm_sysd_edatetime(q_holiday_h_bgn));
 strcpy(q_holiday_h_end,cm_sysd_edatetime(q_holiday_h_end));

 printf("q_holiday_bgn[%s]\n",q_holiday_bgn);
 printf("q_holiday_end[%s]\n",q_holiday_end); 
 $BEGIN WORK;
     
 $SELECT cyear,holiday_type,holiday_bgn,holiday_end,holiday_h_bgn,holiday_h_end
    INTO $cur_cyear,$cur_holiday_type,$cur_holiday_bgn,$cur_holiday_end,$cur_holiday_h_bgn,$cur_holiday_h_end
    FROM ca_holiday
   WHERE cyear = $q_cyear
     AND holiday_type = $q_holiday_type
     AND holiday_bgn  = $q_holiday_bgn
     AND holiday_end  = $q_holiday_end;

  /* if key value has been changed then SQLNOTFOUND,else put current value
     into cur_buf for comparison */


 if (SQLCODE == SQLNOTFOUND)
 {
   MsgCode = M_CM_NOT_FOUND;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(SQLCODE != 0) MsgCode = SQLCODE;
   return exitsub(reply,MsgCode) ? MsgCode : apiRC;
 }
 
 strcpy(cur_holiday_bgn,cm_from_infdate_100(cur_holiday_bgn));
 strcpy(cur_holiday_end,cm_from_infdate_100(cur_holiday_end));
 strcpy(cur_holiday_h_bgn,cm_sysd_cdatetime_100(cur_holiday_h_bgn));
 strcpy(cur_holiday_h_end,cm_sysd_cdatetime_100(cur_holiday_h_end)); 
 printf("cur_holiday_bgn[%s]\n",cur_holiday_bgn);
 printf("cur_holiday_end[%s]\n",cur_holiday_end); 
 printf("cur_holiday_h_bgn[%s]\n",cur_holiday_h_bgn);
 printf("cur_holiday_h_end[%s]\n",cur_holiday_h_end);
 
 cm_buf_init(cur_buf);

 cm_buf_put("%l %s %s %s %s %s %s ",
             dummy,cur_cyear,cur_holiday_type,cur_holiday_bgn,cur_holiday_end,
             cur_holiday_h_bgn,cur_holiday_h_end);
             
 write(1,raw_ptr,raw_len);
 write(1,"\n",1);
 write(1,cur_buf,raw_len);
 write(1,"\n",1);


 printf("cur_buf[%s]\n",cur_buf);
 printf("raw_ptr[%s]\n",raw_ptr);
 if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
 {
   MsgCode = M_CM_NOT_EQUAL;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(SQLCODE != 0) MsgCode = SQLCODE;
   return exitsub(reply,MsgCode) ? MsgCode : apiRC;
 }

 /* equal, then exec DB operation */

 if ( option == 'D' )
  {
 
    sprintf_s(stmt_buf, sizeof stmt_buf, "DELETE FROM ca_holiday "
        " WHERE cyear = ? AND holiday_type = ? AND holiday_bgn = ? "
        " AND holiday_end= ? ");
   printf("del_stmt_buf=[%s]",stmt_buf);          
    $PREPARE d_id FROM $stmt_buf;


    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      
     }
    $EXECUTE d_id USING $q_cyear,$q_holiday_type,$q_holiday_bgn,
                        $q_holiday_end;
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      
     }

   if( is_del_fail ) goto errexit;
   
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
   {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
   }

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else if (option == 'U')
  {
   cm_buf_init(command);

   cm_buf_get("%c %s %s %s %s %s %s %s",
          &option,DBName,u_cyear,u_holiday_type,u_holiday_bgn,u_holiday_end,u_holiday_h_bgn,u_holiday_h_end);

   strcpy(u_holiday_bgn,cm_to_infdate(u_holiday_bgn));
   strcpy(u_holiday_end,cm_to_infdate(u_holiday_end));
   strcpy(u_holiday_h_bgn,cm_sysd_edatetime(u_holiday_h_bgn));
   strcpy(u_holiday_h_end,cm_sysd_edatetime(u_holiday_h_end));

   /* grasp old key */
   cm_buf_init(raw_ptr);
   cm_buf_get("%l %s %s %s %s %s %s ",             
               &dummy,q_cyear,q_holiday_type,q_holiday_bgn,q_holiday_end,q_holiday_h_bgn,q_holiday_h_end);

   strcpy(q_holiday_bgn,cm_to_infdate(q_holiday_bgn));
   strcpy(q_holiday_end,cm_to_infdate(q_holiday_end));
   
   free(raw_ptr);
   printf("q_holiday_bgn[%s]\n",q_holiday_bgn);
   printf("u_holiday_bgn[%s]\n",u_holiday_bgn);
   
   $WHENEVER SQLERROR CONTINUE;

    sprintf_s(stmt_buf, sizeof stmt_buf, 
               "UPDATE ca_holiday "
               "   SET (cyear,holiday_type,holiday_bgn,holiday_end,holiday_h_bgn,holiday_h_end) "
               "       = (?,?,?,?,?,?) "
               " WHERE cyear = ? AND holiday_type = ? AND holiday_bgn = ? "
               "   AND holiday_end= ? ");

    $PREPARE u_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
     
     }
                        
    $EXECUTE u_id USING  $u_cyear,$u_holiday_type,$u_holiday_bgn,$u_holiday_end,$u_holiday_h_bgn,$u_holiday_h_end,
                         $q_cyear,$q_holiday_type,$q_holiday_bgn,$q_holiday_end;                        
                         
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      
     }

 /* if(sqlca.sqlerrd[2] == 0)
    {
        printf(" ********************************* \n");
        sprintf(stmt_buf,"INSERT INTO collate_brand \
         (imotor,sales_brand,dtl_brand,mprize,icar_type,ibrand)\
          VALUES (?,?,?,?,?,?)");

      $PREPARE ua_id FROM $stmt_buf;
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        
       }
      $EXECUTE ua_id USING $u_imotor,$u_sales_brand,$u_dtl_brand,$d_u_mprize,
                           $u_icar_type,$u_ibrand;
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        
       }
     }                                           */
 
   if( is_upd_fail ) goto errexit;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
   {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
   }
   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else
  {
   MsgCode = M_CM_WRONG_OPTION;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
    return MsgCode;
   else
    return apiRC;
  }

errexit:
  MsgCode = SQLCODE;
  cm_show_sql_err("ca132_update_exec", stmt_buf);
  $WHENEVER SQLERROR CONTINUE;
  $ROLLBACK WORK;
  if(SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True)
   return MsgCode;
  else
   return apiRC;
}
