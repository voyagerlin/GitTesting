/**********************************************************************/
/*   program id   : ca220m01s.ec                                      */
/*   program name : �h���p�{���S�����ظ�ƺ��@                        */
/*   date written : 2020/02/14                                        */
/*   date modify  : yyyy/mm/dd                                        */
/*   author       : 071004                                            */                                       
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include "cmnmsgs.h"
#include <math.h>
#include "safeclib.h"

long car220(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
  long rtncode;
  long car220_single_new();
  long car220_single_query();
  long car220_multiple_query();
  char option;
  
  cm_buf_init(command);
  cm_buf_get("%c",&option);
  switch(option)
  {     
    case 'Q':
           rtncode=car220_single_query(reply);
           break;
    case 'M':
           rtncode=car220_multiple_query(reply);
           break;
    default :
           if(exitsub(reply,M_CM_WRONG_OPTION) == True)
            return M_CM_WRONG_OPTION;
           return apiRC;
  }
    return(rtncode);                   
}
/******************************************************************************/
long car220_single_query(reply)
serverReply reply;
{
    $char DBName[DBNAME];
    $char icard[21], itag[13], icar_type[3], fkind[2];
    $char icar_type_taxi[3], sDupdate[10], sDcreate[10];
    $char dcreate[11], icreate[11], dupdate[11], iupdate[11];
    $char ncreate[11], nupdate[11];

    int tmp_len;
    
    cm_buf_get("%s %s %s", DBName, icard, itag);
    
    $WHENEVER SQLERROR GOTO errexit;
    if (db_select(DBName) == False) 
    {
       if(exitsub(reply,M_CM_DB_NOTOPEN) == True)  return M_CM_DB_NOTOPEN;
       else  return apiRC;
    }
      
    $SELECT icard, itag, icar_type, fkind, icar_type_taxi, date(dcreate), icreate, date(dupdate), iupdate
       INTO $icard, $itag, $icar_type, $fkind, $icar_type_taxi, $dcreate, $icreate, $dupdate, $iupdate
       FROM ca_taxi_type
      WHERE icard = $icard
	AND itag = $itag;
	
    if (SQLCODE == SQLNOTFOUND)
    {
        if(exitsub(reply,M_CM_NOT_FOUND) == True) return M_CM_NOT_FOUND;
        else return apiRC;
    }
   
    $SELECT chinese_name INTO $ncreate FROM personal:asempl WHERE empl_no=$icreate;
    $SELECT chinese_name INTO $nupdate FROM personal:asempl WHERE empl_no=$iupdate;
    	 
    strcpy(sDupdate,  cm_from_infdate_100(dupdate));
    strcpy(sDcreate,  cm_from_infdate_100(dcreate));
    
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s",icard, itag, icar_type, fkind, icar_type_taxi, sDcreate, icreate, sDupdate, iupdate, ncreate, nupdate);  
	
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)  return apiRC;
    else return api_OKComplete;

errexit:
printf("--car220_single_query-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    if(exitsub(reply,SQLCODE) == True) return SQLCODE;
    else return apiRC;
}
/******************************************************************************/
long car220_multiple_query(reply)
serverReply reply;
{
    $char DBName[DBNAME];
    $char cDate[11];
    $char icard[21], itag[13], icar_type[3], dcreate[11];
    $char fkind[2], icar_type_taxi[3], sDcreate[10];
    $char sStmt[1000], stmp[128], fstatus;
    
    char tmpbuf[4000];
    int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
    
    cm_buf_get("%s %s %s %s", DBName, icard, itag, dcreate);
    
    $WHENEVER SQLERROR GOTO errexit;
    if (db_select(DBName) == False)
    {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True) return M_CM_DB_NOTOPEN;
        else return apiRC;
    }
   
    if (strncmp(dcreate,"*",1) != 0){
        strcpy(cDate,cm_to_infdate(dcreate));
        sprintf_s(stmp, sizeof stmp, " AND date(dcreate) = '%s' ", cDate);
    }
    else {
    	  strcpy(stmp," ");
    }
    printf("------------stmp[%s]\n",stmp);
    sprintf_s(sStmt, sizeof sStmt,"SELECT DISTINCT icard, itag, icar_type, fkind, icar_type_taxi, date(dcreate) "
                    "FROM ca_taxi_type "
                    "WHERE icard MATCHES '%s' AND itag MATCHES '%s' %s", icard, itag, stmp);
                                       
    $PREPARE ca_taxi FROM $sStmt;                
    $DECLARE q_cur CURSOR FOR ca_taxi;    
    $OPEN q_cur;
    
    for(;;) { 
     	
    	$FETCH q_cur INTO $icard, $itag, $icar_type, $fkind, $icar_type_taxi, $dcreate;
    	if (SQLCODE != 0) break;
    		

        strcpy(sDcreate, cm_from_infdate_100(dcreate));
 
    	cm_buf_init(tmpbuf); 
    	if ( count == 0 )
     	{
      	    cm_buf_res_msg();             /* reserve for MsgCode and count */
      	    cm_buf_res_count();          
     	}
    	cm_buf_put("%s %s %s %s %s %s", icard, itag, icar_type, fkind, icar_type_taxi, sDcreate);
        tmp_len = cm_buf_len(tmpbuf);
    	if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
        {
      	    memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      	    repbuf_len += tmp_len;
      	    count++;
     	}
   	else                               /* more than 4K, send to client side */ 
     	{ 
      	    cm_buf_init(ReplyBuf);
      	    cm_buf_put_msg(M_CM_OK);
      	    cm_buf_put_count(count);
      	    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
            {
	        $CLOSE q_cur;
                return apiRC;
            }
      	    else               /* clear ReplyBuf and count to start all over again */
            {
                replycnt++;
                if (replycnt == 10)   /* more than 30K, client cannot display,error */
                {
	            cm_buf_init(ReplyBuf);
          	    cm_buf_put("%l",M_CM_OUT_SPACE);
          	    tmp_len = cm_buf_len(ReplyBuf);
          	    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
            	        return apiRC;
            	    return M_CM_OUT_SPACE; 
                }
	        ReplyBuf[0] = '\0';
	        count = 0;
	        cm_buf_init(ReplyBuf);
                cm_buf_res_msg();           /* reserve for MsgCode and count */
                cm_buf_res_count();    
                cm_buf_put("%s %s %s %s %s %s", icard, itag, icar_type, fkind, icar_type_taxi, sDcreate);
	        repbuf_len = cm_buf_len(ReplyBuf);
	        count++;
            }
        } 
    } /* for loop */

    $CLOSE q_cur;
    $FREE  q_cur;              
    	
    if (count > 0)   /* break out, at least one record is selected */
    {
        cm_buf_init(ReplyBuf);
        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(count);
        if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
            return apiRC;
        return api_OKComplete;
    }
    else            /* break out, not any row is found */
    {
       if(exitsub(reply,M_CM_NOT_FOUND) == True) 
           return M_CM_NOT_FOUND;
       else  
           return apiRC;
    } 

errexit:
printf("--car220_multiple_query-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
  if(exitsub(reply,SQLCODE) == True)  return SQLCODE;
  else return apiRC;
}
/**********************************THE END*************************************/