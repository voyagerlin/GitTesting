/************************************************/
/*                                              */
/*   PROGRAM : ca643m01s.ec by sylvia           */
/*                                              */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"
$include sqlca;
$include "var_length.h";


long car643(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car643_single_query(),car643_multiple_query();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'P':rtncode=car643_get_ipolicy(reply);
           break;
  case 'Q':
           rtncode=car643_single_query(reply);
           break;
  case 'M':
           rtncode=car643_multiple_query(reply);
           break;
  case 'A':rtncode=car643_insert(reply);
           break;
  case 'D':
  case 'U':rtncode=car643_update_exec(reply,command,com_len);
           break;
  default :
           if(exitsub(reply,M_CM_WRONG_OPTION) == True)
             return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}


long car643_insert(reply)
serverReply reply;
{
     $char DBName[5],icard[18], stmp_sql[2000];
     long   MsgCode;

    int tmp_len,lenErr,icnt,i,x;
    char strmax[20],strmin[20];

    $char dtrans[11], itag[CA_TAG_NUM], iassured[11], dbirthday[11],
          fsex[2], icar_type[3], qpt[5], fpt[2], icard_1[18], itag_1[CA_TAG_NUM],
          iassured_1[11], dbirthday_1[11], icar_type_1[3], qpt_1[5], fpt_1[2],
          dtag_change[11], nassured[3], dtransfer[11], idata_src[2], ierr_code[31],
	  dcar_status[11], icar_status[5], ncar_status[41], dtag_status[11],
	  itag_status[5], ntag_status[41], icreate[11], dcreate[21], ncreate[11],
	  iupdate[11], nupdate[11], nerr_code[301],TmpErr1[4],TmpErr2[51];

    cm_buf_get("%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
    	      DBName, icard,  itag,  iassured,  dbirthday,  fsex,                        /*6*/
              icar_type,  qpt,  fpt,  icard_1,  itag_1,                                  /*5*/
              iassured_1,  dbirthday_1,  icar_type_1,  qpt_1,  fpt_1,                    /*5*/
              dtag_change,  nassured,  dtransfer,                                        /*3*/
	      dcar_status,  icar_status,  dtag_status,  itag_status,  icreate);          /*5*/

    strcpy(dbirthday, cm_to_infdate(dbirthday));
    strcpy(dbirthday_1, cm_to_infdate(dbirthday_1));
    strcpy(dtag_change, cm_to_infdate(dtag_change));
    strcpy(dtransfer, cm_to_infdate(dtransfer));
    strcpy(dcar_status, cm_to_infdate(dcar_status));
    strcpy(dtag_status, cm_to_infdate(dtag_status));


    $WHENEVER SQLERROR GOTO errexit;

    puts("db_select");
    if(db_select(DBName) == False)
    return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    $BEGIN WORK;


    $WHENEVER SQLERROR GOTO errexit;


/*sprintf_s(stmp_sql, sizeof stmp_sql,"INSERT INTO ca_trade_notify  "
 	 "    (icard,  itag,  iassured,  dbirthday,  fsex,  "
     "        icar_type,  qpt,  fpt,  icard_1,  itag_1,  "
     "        iassured_1,  dbirthday_1,  icar_type_1,  qpt_1,  fpt_1,  "
     "        dtag_change,  nassured,  dtransfer,  "
	 "    dcar_status,  icar_status,  dtag_status,  itag_status,  icreate,  "
	 "    dcreate,  iupdate,  dupdate)  "
     "VALUES('%s', '%s', '%s', '%s', '%s',  "
     "       '%s', '%s', '%s', '%s', '%s',  "
     "       '%s', '%s', '%s', '%s', '%s',  "
     "       '%s', '%s', '%s',  "
	 "   '%s', '%s', '%s', '%s', '%s',  "
	 "   current, '%s', current)",
	     icard, itag, iassured, dbirthday, fsex,
             icar_type, qpt, fpt, icard_1, itag_1,
             iassured_1, dbirthday_1, icar_type_1, qpt_1, fpt_1,
             dtag_change, nassured, dtransfer,
	     dcar_status, icar_status, dtag_status, itag_status, icreate,
	     icreate);
     printf("stmp_sql=[%s]\n",stmp_sql); */

    $INSERT INTO ca_trade_notify
 	      (icard,  itag,  iassured,  dbirthday,  fsex,
              icar_type,  qpt,  fpt,  icard_1,  itag_1,
              iassured_1,  dbirthday_1,  icar_type_1,  qpt_1,  fpt_1,
              dtag_change,  nassured,  dtransfer,
	      dcar_status,  icar_status,  dtag_status,  itag_status,  icreate,
	      dcreate,  iupdate,  dupdate ,idata_src, ierr_code)
      VALUES($icard, $itag, $iassured, $dbirthday, $fsex,
             $icar_type, $qpt, $fpt, $icard_1, $itag_1,
             $iassured_1, $dbirthday_1, $icar_type_1, $qpt_1, $fpt_1,
             $dtag_change, $nassured, $dtransfer,
	     $dcar_status, $icar_status, $dtag_status, $itag_status, $icreate,
	     current , $icreate, current ,'0', ' ' );


    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    tmp_len = cm_buf_len(ReplyBuf);

    if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        return apiRC;
    }
    $WHENEVER SQLERROR GOTO errexit;
    $COMMIT WORK;
    return api_OKComplete;

errexit:
    MsgCode = SQLCODE;
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if( SQLCODE != 0) MsgCode = SQLCODE;
    return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

/*-----------------------------------------------------------------*/
/* �H�d���d�߫O�������� */
long car643_get_ipolicy(reply)
serverReply reply;
{
    $char DBName[5], sFullName[21], stmt[1024];
    int tmp_len;
    char tmp_card[2];
    $char userid[11];
    $char icard[21], ipolicy[21];
    $char itag[CA_TAG_NUM], iassured[13], dbirth[11], fsex[2], icar_type[3], qpt[5], fpt[2];

    cm_buf_get("%s %s ",DBName,icard);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
      if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
        return M_CM_DB_NOTOPEN;
      else
        return apiRC;
    }
	strlen( trim(icard));

    $SELECT ipolicy
       INTO $ipolicy
       FROM compulsory_card
      WHERE icard = $icard;

    printf("icard[%s]\n", icard);
    printf("ipolicy[%s]\n", ipolicy);

    if( SQLCODE == SQLNOTFOUND)
        return exitsub(reply, M_CA_NOT_CARD) ? M_CA_NOT_CARD : apiRC;

    printf("strlen( trim(ipolicy))[%d]\n", strlen( trim(ipolicy)));

    if( strlen( trim(ipolicy)) == 0)
        return exitsub(reply, M_CA_NOT_PLY) ? M_CA_NOT_PLY : apiRC;

    strcpy(sFullName, get_car_full_db(ipolicy));

    sprintf_s(stmt, sizeof stmt,"SELECT  b.itag, b.iassured, b.dbirth, b.fsex, a.icar_type, b.qpt, b.fpt  "
                  " FROM %s:ply_relation a, %s:policy b , compulsory_card c "
                  "WHERE c.ipolicy = a.ipolicy  "
                  "  AND c.ipolicy = b.ipolicy  "
                  "  AND a.ipolicy = '%s'" , sFullName, sFullName, ipolicy );
    printf("stmt[%s]\n", stmt);

    $PREPARE prep2 FROM $stmt;
    $EXECUTE prep2 INTO $itag, $iassured, $dbirth, $fsex, $icar_type, $qpt, $fpt;

    printf("dbirth1=[%s]\n",dbirth);
    strcpy(dbirth, cm_from_infdate_100(dbirth));
    printf("dbirth1=[%s]\n",dbirth);

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %s %s %s %s %s %s ",
                M_CM_OK, itag, iassured, dbirth, fsex, icar_type, qpt, fpt);

    tmp_len = cm_buf_len(ReplyBuf);

    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
      return apiRC;
    else
      return api_OKComplete;

errexit:
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}


/*----------------------------------------------------------------------------*/

long car643_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
    $char DBName[5],icard[18], stmp_sql[2000],old_icard[18];
    char   option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
    int    tmp_len,raw_len;
    long   dummy;
    long   MsgCode;
    char   tmp_buf[20];
    long   tmp_long;
    $int   iRows = 0;
    int lenErr,icnt,i,x;
    char strmax[20],strmin[20];

    $char dtrans[11], itag[CA_TAG_NUM], iassured[11], dbirthday[11],
          fsex[2], icar_type[3], qpt[5], fpt[2], icard_1[18], itag_1[CA_TAG_NUM],
          iassured_1[11], dbirthday_1[11], icar_type_1[3], qpt_1[5], fpt_1[2],
          dtag_change[11], nassured[3], dtransfer[11], idata_src[2], ierr_code[31],
	  dcar_status[11], icar_status[5], ncar_status[41], dtag_status[11],
	  itag_status[5], ntag_status[41], icreate[11], dcreate[21], ncreate[11],
	  iupdate[11], nupdate[11], nerr_code[301],TmpErr1[4],TmpErr2[51],dupdate[21];

    $char old_dtrans[11], old_itag[CA_TAG_NUM], old_iassured[11], old_dbirthday[11],
          old_fsex[2], old_icar_type[3], old_qpt[5], old_fpt[2], old_icard_1[18], old_itag_1[CA_TAG_NUM],
          old_iassured_1[11], old_dbirthday_1[11], old_icar_type_1[3], old_qpt_1[5], old_fpt_1[2],
          old_dtag_change[11], old_nassured[3], old_dtransfer[11], old_idata_src[2], old_ierr_code[31],
	  old_dcar_status[11], old_icar_status[5], old_ncar_status[41], old_dtag_status[11],
	  old_itag_status[5], old_ntag_status[41], old_icreate[11], old_dcreate[21], old_ncreate[11],
	  old_iupdate[11], old_nupdate[11], old_nerr_code[301], old_TmpErr1[4], old_TmpErr2[51],old_dupdate[21];

    comm = (char *) command;
    cm_buf_init(command);
    cm_buf_get("%c %s", &option, DBName);

    $WHENEVER SQLERROR GOTO errexit;

    if(db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    memcpy(&raw_len,&comm[com_len],sizeof(int));
    pos = &comm[com_len+sizeof(int)];
    raw_ptr = malloc(raw_len);
    if (raw_ptr != (char*)0)
     memcpy(raw_ptr,pos,raw_len);
     
    else
     {
      if(exitsub(reply,M_CM_NOT_MALLOC) == True)
       return M_CM_NOT_MALLOC;
      else
       return apiRC;
     }
     
    printf("raw_ptr[%s]\n", raw_ptr);

    cm_buf_init(raw_ptr);
    free(raw_ptr);
    cm_buf_get("%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
    &dummy, old_icard, old_itag, old_dtrans, old_iassured,
    old_dbirthday, old_fsex, old_icar_type, old_qpt, old_fpt,
    old_idata_src, old_ierr_code, old_nerr_code, old_icard_1, old_itag_1,
    old_iassured_1, old_dbirthday_1, old_icar_type_1, old_qpt_1, old_fpt_1,
    old_dtag_change, old_nassured, old_dtransfer, old_dcar_status, old_icar_status,
    old_ncar_status, old_dtag_status, old_itag_status, old_ntag_status, old_icreate,
    old_ncreate, old_dcreate, old_iupdate, old_nupdate, old_dupdate);


    $BEGIN WORK;

    $SELECT COUNT(*) INTO $iRows
        FROM ca_trade_notify
        WHERE icard = $old_icard
        AND dupdate = $old_dupdate;

    if (iRows == 0)
    {
        $ROLLBACK WORK;
        if(exitsub(reply,M_CM_NOT_EQUAL) == True)
            return M_CM_NOT_EQUAL;
        else
            return apiRC;
    }

    if( option == 'D' )
    {

         $DELETE FROM ca_trade_notify
           WHERE icard = $old_icard;

         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OK);
         tmp_len = cm_buf_len(ReplyBuf);
         if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
         {
             $WHENEVER SQLERROR CONTINUE;
             $ROLLBACK WORK;
             return apiRC;
         }

         $WHENEVER SQLERROR GOTO errexit;
         $COMMIT WORK;
         return api_OKComplete;
    }
    else if(option == 'U')
    {
         printf("OPTION U");

         cm_buf_init(command);
         cm_buf_get("%c %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
    	        &option, DBName, icard,   itag,   iassured,   dbirthday,   fsex,
                icar_type,   qpt,   fpt,  idata_src,  ierr_code,  icard_1,   itag_1,
                iassured_1,   dbirthday_1,   icar_type_1,   qpt_1,   fpt_1,
                dtag_change,   nassured,   dtransfer,
	        dcar_status,   icar_status,   dtag_status,   itag_status,   icreate );

    strcpy(dbirthday, cm_to_infdate(dbirthday));
    strcpy(dbirthday_1, cm_to_infdate(dbirthday_1));
    strcpy(dtag_change, cm_to_infdate(dtag_change));
    strcpy(dtransfer, cm_to_infdate(dtransfer));
    strcpy(dcar_status, cm_to_infdate(dcar_status));
    strcpy(dtag_status, cm_to_infdate(dtag_status));

    printf("old_dcreate=%s",old_dcreate);

         strcpy( old_icard, trim(old_icard));
         strcpy( icard, trim(icard));
         printf("icard=%s\n",icard);
	 printf("old_icard=%s\n",old_icard);

       $UPDATE ca_trade_notify
           SET itag=$itag,  iassured=$iassured,   dbirthday=$dbirthday,   fsex=$fsex,
               icar_type=$icar_type,  qpt=$qpt,   fpt=$fpt,  idata_src=$idata_src,  ierr_code=$ierr_code,  icard_1=$icard_1,   itag_1=$itag_1,
               iassured_1=$iassured_1,   dbirthday_1=$dbirthday_1,   icar_type_1=$icar_type_1,   qpt_1=$qpt_1,   fpt_1=$fpt_1,
               dtag_change=$dtag_change,   nassured=$nassured,   dtransfer=$dtransfer,
	       dcar_status=$dcar_status,   icar_status=$icar_status,   dtag_status=$dtag_status,   itag_status=$itag_status,
	       dupdate=current , iupdate=$icreate
         WHERE icard = $old_icard;

         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OK);
         tmp_len = cm_buf_len(ReplyBuf);

         if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
         {
             $WHENEVER SQLERROR CONTINUE;
             $ROLLBACK WORK;
             return apiRC;
         }

         $WHENEVER SQLERROR GOTO errexit;
         $COMMIT WORK;
         return api_OKComplete;
    }
    else
    {
         return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
    }
errexit:
    MsgCode = SQLCODE;
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if( SQLCODE != 0) MsgCode = SQLCODE;
    return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

/*----------------------------------------------------------------------------*/

long car643_single_query(reply)
serverReply reply;
{
    $char DBName[5],icard[18],date1[11];

    int tmp_len,lenErr,icnt,i,x;
    char strmax[20],strmin[20];

    $char dtrans[11], itag[CA_TAG_NUM], iassured[11], dbirthday[11],
          fsex[2], icar_type[3], qpt[5], fpt[2], icard_1[18], itag_1[CA_TAG_NUM],
          iassured_1[11], dbirthday_1[11], icar_type_1[3], qpt_1[5], fpt_1[2],
          dtag_change[11], nassured[3], dtransfer[11], idata_src[2], ierr_code[31],
	      dcar_status[11], icar_status[5], ncar_status[41], dtag_status[11],
	      itag_status[5], ntag_status[41], icreate[11], dcreate[21], ncreate[11],
	      iupdate[11], dupdate[21], nupdate[11], nerr_code[301],TmpErr1[4],TmpErr2[51];


    cm_buf_get("%s %s %s",DBName,icard,date1);

    strcpy(date1,cm_to_infdate(date1));   /* ���ɤ� */
    printf("date1=[%s]\n",date1);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
        else
            return apiRC;
    }

     $SELECT a.icard, a.itag, a.iassured, a.dbirthday, a.fsex,
             a.icar_type, a.qpt, a.fpt, a.icard_1, a.itag_1,
             a.iassured_1, a.dbirthday_1, a.icar_type_1, a.qpt_1, a.fpt_1,
             a.dtag_change, a.nassured, a.dtransfer, a.idata_src, a.ierr_code,
	         a.dcar_status, a.icar_status, a.dtag_status, a.itag_status, a.icreate,
	         a.dcreate, date(a.dcreate), a.iupdate, a.dupdate,
	         (select nname from officer c where c.iofficer = a.icreate),
	         (select nname from officer d where d.iofficer = a.iupdate)
        INTO $icard, $itag, $iassured, $dbirthday, $fsex,
             $icar_type, $qpt, $fpt, $icard_1, $itag_1,
             $iassured_1, $dbirthday_1, $icar_type_1, $qpt_1, $fpt_1,
             $dtag_change, $nassured, $dtransfer, $idata_src, $ierr_code,
	         $dcar_status, $icar_status, $dtag_status, $itag_status, $icreate,
	         $dcreate, $dtrans, $iupdate, $dupdate, $ncreate, $nupdate
        FROM ca_trade_notify a
       WHERE a.icard = $icard
         and a.dcreate >= extend(date($date1),year to second)
         and a.dcreate < extend(date($date1)+1,year to second);

    if(SQLCODE==SQLNOTFOUND)
    {
        if(exitsub(reply,M_CM_NOT_FOUND) == True)       /*?*/
            return M_CM_NOT_FOUND;                        /*?*/
        else
            return apiRC;
    }

    strcpy(dbirthday, cm_from_infdate_100(dbirthday));
    strcpy(dbirthday_1, cm_from_infdate_100(dbirthday_1));
    strcpy(dtag_change, cm_from_infdate_100(dtag_change));
    strcpy(dtransfer, cm_from_infdate_100(dtransfer));
    strcpy(dcar_status, cm_from_infdate_100(dcar_status));
    strcpy(dtag_status, cm_from_infdate_100(dtag_status));
    strcpy(dtrans, cm_from_infdate_100(dtrans));

    /* ���~�N�X�T�� */
    strcpy(ierr_code, trim(ierr_code));
    lenErr = strlen(ierr_code);
    printf("ierr_code=[%s]lenErr=[%d]\n",ierr_code,lenErr);
    if (lenErr == 0)
        strcpy(nerr_code, " ");   /* �L���~�N�X */
    else
    {
        memset(nerr_code,0x00,sizeof(nerr_code));
        icnt = lenErr/3;

        for( i = 0; i < icnt; i++)
        {
            x = i*3;
            strncpy(TmpErr1, &ierr_code[x],3);
            TmpErr1[3] = '\0';

            printf("TmpErr1=[%s]\n",TmpErr1);
            strcpy(TmpErr2, " ");
            $select trim(chiname)||';' into $TmpErr2
               from car_code
              where kind = '35'
                and detail = 'A01'
                and detail2 = $TmpErr1;

            strcat(nerr_code, trim(TmpErr2));
        }
        printf("Nerr=[%s]\n",nerr_code);
    }

    /* �������A���ʤ��� */
    strcpy(ncar_status, " ");
      $select chiname into $ncar_status
         from car_code
        where kind = '35'
          and detail = 'A02'
          and detail2 = $icar_status;

    /* �P�Ӫ��A���ʤ��� */
    strcpy(ntag_status, " ");
      $select chiname into $ntag_status
         from car_code
        where kind = '35'
          and detail = 'A03'
          and detail2 = $itag_status;

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %s %s %s", M_CM_OK, icard, itag,  dtrans, iassured);
    cm_buf_put("%s %s %s %s %s", dbirthday, fsex, icar_type, qpt, fpt);
    cm_buf_put("%s %s %s %s %s", idata_src, ierr_code, nerr_code, icard_1, itag_1);
    cm_buf_put("%s %s %s %s %s", iassured_1,dbirthday_1, icar_type_1, qpt_1, fpt_1);
    cm_buf_put("%s %s %s %s %s", dtag_change, nassured, dtransfer, dcar_status, icar_status);
    cm_buf_put("%s %s %s %s %s", ncar_status, dtag_status, itag_status, ntag_status, icreate);
    cm_buf_put("%s %s %s %s %s", ncreate, dcreate, iupdate, nupdate, dupdate);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

  errexit:
     if(exitsub(reply,SQLCODE) == True)
        return SQLCODE;
     else
        return apiRC;
}

long car643_multiple_query(reply)
serverReply reply;
{
    $char DBName[5],sDate1[11],sDate2[11],ierr1[31];
    $char Date_bgn[11],Date_end[11];
    $char icard[18],itag[CA_TAG_NUM],dcreate[11],ierr_code[31],icar_type[3];

    char tmpbuf[4000];
    int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
    int i,total_count=0;

    cm_buf_get("%s %s %s %s",DBName,sDate1,sDate2,ierr1);

    strcpy(ierr1, rtrim(ierr1));
    strcpy(Date_bgn, cm_to_infdate(sDate1));
    strcpy(Date_end, cm_to_infdate(sDate2));
    printf("Date_bgn=[%s]Date_end=[%s]\n",Date_bgn,Date_end);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
        else
            return apiRC;
    }

    $DECLARE q_cur CURSOR FOR
        SELECT icard, itag, icar_type , date(dcreate), ierr_code
          INTO $icard, $itag, $icar_type, $sDate1, $ierr_code
          FROM ca_trade_notify
         WHERE dcreate >= extend(date($Date_bgn),year to second)
           and dcreate <  extend(date($Date_end)+1,year to second)
           and ierr_code matches $ierr1
         ORDER BY dcreate desc, icard;

     $OPEN q_cur;
    for(;;)
    {
        $FETCH q_cur;
        if (SQLCODE != 0) break;

        strcpy(dcreate, cm_from_infdate_100(sDate1));   /* ����CYY/MM/DD */
        strcpy(ierr_code, trim(ierr_code));

        cm_buf_init(tmpbuf);
        if ( count == 0 )
        {
            cm_buf_res_msg();             /* reserve for MsgCode and count */
            cm_buf_res_count();
        }
        cm_buf_put("%s %s %s %s %s",icard, itag, icar_type, dcreate, ierr_code);
        tmp_len = cm_buf_len(tmpbuf);
        if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
        {
            memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
            repbuf_len += tmp_len;
            count++;
        }
        else                               /* more than 4K, send to client side */
        {
            cm_buf_init(ReplyBuf);
            cm_buf_put_msg(M_CM_OK);
            cm_buf_put_count(count);
            if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
            {
                $CLOSE q_cur;
                return apiRC;
            }
            else               /* clear ReplyBuf and count to start all over again */
            {
                replycnt++;
                if (replycnt == 30)   /* more than 30K, client cannot display,error */
                {
                    cm_buf_init(ReplyBuf);
                    cm_buf_put("%l",M_CM_OUT_SPACE);
                    tmp_len = cm_buf_len(ReplyBuf);
                    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
                        return apiRC;
                    return M_CM_OUT_SPACE;
                }
                ReplyBuf[0] = '\0';
                count = 0;
                cm_buf_init(ReplyBuf);
                cm_buf_res_msg();           /* reserve for MsgCode and count */
                cm_buf_res_count();
                cm_buf_put("%s %s %s %s %s",icard, itag, icar_type, dcreate, ierr_code);
                repbuf_len = cm_buf_len(ReplyBuf);
                count++;
            }
        }
    } /* for loop */

    $CLOSE q_cur;
    if (count > 0)   /* break out, at least one record is selected */
    {
        cm_buf_init(ReplyBuf);
        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(count);
        if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
            return apiRC;
        return api_OKComplete;
    }
    else            /* break out, not any row is found */
    {
        if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
            return M_CM_NOT_FOUND;                               /*?*/
        else
        return apiRC;
    }

 errexit:
   if(exitsub(reply,SQLCODE) == True)
     return SQLCODE;
   else
     return apiRC;
}
