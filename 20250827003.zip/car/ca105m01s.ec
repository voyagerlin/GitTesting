/************************************************/
/*                                              */
/*   PROGRAM : ca105m01s.ec by Dennis Chang     */
/*                                              */
/*   DATE    : 1993/09/01                       */
/*                                              */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;
#include <decimal.h>
#include "safeclib.h"


long car105(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car105_insert(),car105_single_query(),car105_multiple_query(),car105_update_exec();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'A':
           rtncode=car105_insert(reply);
           break;
  case 'Q':
           rtncode=car105_single_query(reply);
           break;
  case 'M':
           rtncode=car105_multiple_query(reply);
           break;
  case 'D':
  case 'U':
           rtncode=car105_update_exec(reply,command,com_len);
           break;
  default :
           if(exitsub(reply,M_CM_WRONG_OPTION) == True)
            return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}

/*-----------------------------------------------------------------*/
long car105_insert(reply)
serverReply reply;
{
 $char DBName[5],class[2],code[3];
 $double adjust;
 dec_t dec_adjust;
 char  tmp_adjust[21];
 int tmp_len;
   DBinfo *list;
   int i, j, is_add_fail=0, api_f;
   $char stmt_buf[300];
   long  MsgCode;

 cm_buf_get("%s %s %s %s",DBName,class,code,tmp_adjust);
 deccvasc( tmp_adjust, strlen(tmp_adjust), &dec_adjust);
 dectodbl( &dec_adjust, &adjust);

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
    return M_CM_DB_NOTOPEN;
   else
    return apiRC;
  }

 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
  {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
  }

 $BEGIN WORK;
 for(j=0;j<i;j++)
 {
  sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO %s:alignment "
         " (fclass,icode,palign) VALUES (?,?,?)" ,list[j].dbname);

  $PREPARE a_id FROM $stmt_buf;
  if(SQLCODE != 0)
   {
    is_add_fail = 1;
    break;
   }
  $EXECUTE a_id USING $class,$code,$adjust;
  if(SQLCODE != 0)
   {
    is_add_fail = 1;
    break;
   }
  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);
  tmp_len = cm_buf_len(ReplyBuf);
  if( j == i-1 )
     api_f = api_OKComplete;
  else
     api_f = api_OK;

  if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
    {
     is_add_fail = 2;
     break;
    }  
#ifdef DEBUG 
printf("INSERT %d\n", j+1);
#endif
 } /* for loop */

 if( is_add_fail == 1 ) goto errexit;

 if( is_add_fail == 2 ) 
  {
   $ROLLBACK WORK;
   return apiRC;
  }


 $WHENEVER SQLERROR GOTO errexit;
 $COMMIT WORK;
 return api_OKComplete;

 errexit:
   MsgCode = SQLCODE;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if( SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
    return MsgCode;
   else
    return apiRC;
}

/*-----------------------------------------------------------------*/
long car105_single_query(reply)
serverReply reply;
{
 $char DBName[5],class[2],code[3];
 $double adjust;
 int tmp_len;

 cm_buf_get("%s %s %s",DBName,class,code);


 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
    return M_CM_DB_NOTOPEN;
   else
    return apiRC;
  }

 $SELECT palign
  INTO $adjust
  FROM alignment
  WHERE fclass=$class AND icode=$code;

 if(SQLCODE==SQLNOTFOUND)
  {
   if(exitsub(reply,M_CA_NALIGN) == True)
    return M_CA_NALIGN;
   else
    return apiRC;
  }

 cm_buf_init(ReplyBuf);
 cm_buf_put("%l %s %s %e",M_CM_OK,class,code,adjust);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
  return apiRC;
 else
  return api_OKComplete;

 errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}

/*-----------------------------------------------------------------*/
long car105_multiple_query(reply)
serverReply reply;
{
 $char DBName[5],key_class[2],key_code[3],class[2],code[3];
 $double adjust;
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0;

 cm_buf_get("%s %s %s",DBName,key_class,key_code);


 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
    return M_CM_DB_NOTOPEN;
   else
    return apiRC;
  }

 $DECLARE q_cur CURSOR FOR
    SELECT fclass,icode,palign
    INTO $class, $code, $adjust
    FROM alignment
    WHERE fclass matches $key_class AND icode matches $key_code
    ORDER BY fclass;

 $OPEN q_cur;

 for(;;)
  {
    $FETCH q_cur;
    if (SQLCODE != 0) break;

    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();
     }
    cm_buf_put("%s %s %e",class,code,adjust);

    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
        $CLOSE q_cur;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s %e",class,code,adjust);

        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
  } /* for loop */

 $CLOSE q_cur;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
   if(exitsub(reply,M_CA_NALIGN) == True)
    return M_CA_NALIGN;
   else
    return apiRC;
  }

 errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}


/*-----------------------------------------------------------------*/
long car105_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 $char DBName[5],class[2],code[3];
 $char cur_class[2],cur_code[3];
 $double adjust, cur_adjust = 0.0;
 dec_t dec_adjust;
 char  tmp_adjust[21];
 char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
 int tmp_len,raw_len;
 long dummy;
   DBinfo *list;
   int i, j, is_del_fail=0, is_upd_fail=0;
   $char stmt_buf[300];
 long MsgCode;

 comm = (char *) command;
 cm_buf_init(command);
 cm_buf_get("%c %s",&option,DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
    return M_CM_DB_NOTOPEN;
   else
    return apiRC;
  }

 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
  {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
  }
 /* compare old record and current record, if the record has not been changed
    since last request, update or delete the record, otherwise return errmsg
    to client side */

 /* get old record info from command buffer */

/*
 raw_len = *(int *) &comm[com_len];
 memcpy(&raw_len,(void *)&command[com_len],sizeof(int));
*/
 memcpy(&raw_len,&comm[com_len],sizeof(int));
 pos = &comm[com_len+sizeof(int)];
 raw_ptr = malloc(raw_len);
 if (raw_ptr != (char*)0)
  memcpy(raw_ptr,pos,raw_len);
 else
  {
   if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */
    return M_CM_NOT_MALLOC;
   else
    return apiRC;
  }

 cm_buf_init(raw_ptr);          /* get index key from old record */
 cm_buf_get("%l %s %s",&dummy,cur_class,cur_code);

 $BEGIN WORK;

 $SELECT palign
  INTO $cur_adjust
  FROM alignment
  WHERE fclass=$cur_class AND icode=$cur_code;

  /* if key value has been changed then SQLNOTFOUND,else put current value
     into cur_buf for comparison */

 if (SQLCODE == SQLNOTFOUND)
  {
   MsgCode = M_CM_NOT_FOUND;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if( SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
    return MsgCode;
   else
    return apiRC;
  }

 cm_buf_init(cur_buf);
 cm_buf_put("%l %s %s %e",dummy,cur_class,cur_code,cur_adjust);

 if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
  {
   MsgCode = M_CM_NOT_EQUAL;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if( SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
    return MsgCode;
   else
    return apiRC;
  }
  
	free(raw_ptr);
 /* equal, then exec DB operation */

 if ( option == 'D' )
  {
   for(j=0;j<i;j++)
   {
    sprintf_s(stmt_buf, sizeof stmt_buf,"DELETE FROM %s: alignment WHERE fclass = ? AND icode = ?"
		,list[j].dbname); 
    $PREPARE d_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      break;
     }
    $EXECUTE d_id USING $cur_class,$cur_code;
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      break;
     }
#ifdef DEBUG 
printf("Delete %d\n", j+1);
#endif
   }/* for loop */

   if( is_del_fail ) goto errexit;
   
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else if (option == 'U')
  {
   cm_buf_init(command);
   cm_buf_get("%c %s %s %s %s",&option,DBName,class,code,tmp_adjust);
   deccvasc( tmp_adjust, strlen(tmp_adjust), &dec_adjust);
   dectodbl( &dec_adjust, &adjust);

   $WHENEVER SQLERROR CONTINUE;
   for(j=0;j<i;j++)
   {
    sprintf_s(stmt_buf, sizeof stmt_buf,"UPDATE %s:alignment "
       		" SET (fclass,icode,palign) = (?,?,?) "
     		" WHERE fclass = ? AND icode = ?",list[j].dbname);

    $PREPARE u_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      break;
     }
    $EXECUTE u_id USING $class,$code,$adjust,$cur_class,$cur_code;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      break;
     }
    if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
     {
  	sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO %s:alignment "
         " (fclass,icode,palign) VALUES (?,?,?)" ,list[j].dbname);

      $PREPARE ua_id FROM $stmt_buf;
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        break;
       }
      $EXECUTE ua_id USING $class,$code,$adjust;
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        break;
       }
     }
#ifdef DEBUG 
printf("Update %d\n", j+1);
#endif
   } /* for loop */

   if( is_upd_fail ) goto errexit;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else
  {
   if(exitsub(reply,M_CM_WRONG_OPTION) == True)
    return M_CM_WRONG_OPTION;
   else
    return apiRC;
  }

 errexit:
   MsgCode = SQLCODE;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if( SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
    return MsgCode;
   else
    return apiRC;
}
/*-----------------------------------------------------------------*/
