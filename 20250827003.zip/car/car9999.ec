/************************************************
 * Copyright (C) 1995 Intellisys Corporation    *
 *                                              *
 * Program : car9999.ec                         *
 *                                              *
 ************************************************/
#include <stdio.h>
#include "api_xsrv.h"
#include "sqlfatal.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"

/* standard data declaration */
FILE *fptr, *fptr_err;
$char userid[11], iquota[7];
char prtfile[80],outputf[80],outputf1[80];
char errmsg[200];
$char errFile[120];
/* end of standard data */
/* private data */
/* end of private data */

$char localdb[5],Taipei_FullName[20];
int  i, flag_check=0;
/* end of standard defined data */
  
char companyid[3];
int rtn;
$char  company_flag,iclaim_flag;
char  COMPANY_P[3];
char  COMPANY_F[3];

char expdate[6];
char bgndate[10],enddate[10];
char option[2];
$static char remotedb[DBNAME];
int   count_db,k; 

$char DBName[05];
$char msgbuf[128];
DBinfo *list;
char  sApHome[30];
int   rtncode,rc;
char  filename[30];
FILE  *fp;
char  file_catalog[200];
$char filename1[200];
$char data_yyyymm[7];

$char iproduct_tmp[3];
$long mprem_14 = 0,mprem_15 = 0,mprem_16 = 0;
$long mhealth_14 = 0,mhealth_15 = 0,mhealth_16 = 0;

long car9999_get_db();
long car9999_build();
long car9999_final();
/*************************************************************/
main(argc,argv)
int argc;
char **argv;
{
	int rtncode,rc;

	strcpy(DBName,       isNULLstr(argv[1]));
	strcpy(userid,       isNULLstr(argv[2]));
	strcpy(expdate,      isNULLstr(argv[3]));
	strcpy(outputf,      isNULLstr(argv[4]));
	
	printf("DBName[%s],userid[%s],expdate[%s],outputf[%s] \n",DBName,userid,expdate,outputf);
	
	rc = car9999_get_db();
	if (rc != M_CM_OK)
	{
		return rc;
	}
	
	rc = car9999_build();
	if ( rc != SUCCESS ) {
	 	printf("error on car9991_build \n");
	 	EWRITE(userid, rc, errmsg);
		return rc;	
	}
	
	rc = car9999_final();
	if ( rc != SUCCESS ) {
	 	printf("error on car9991_show \n");
	 	EWRITE(userid, rc, errmsg);
		return rc;	
	}
}

long car9999_get_db()
{
	$whenever sqlerror goto errexit1;

	if (db_select(DBName) == DBName) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}
	
	rc = getApHome(sApHome);
	if (rc < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		EWRITE(userid,rc,msgbuf);
	 	return rc;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}	
	return M_CM_OK;

errexit1:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}

long car9999_build()
{
	$long  dwritten_l;
	$char  drate_c[9];
	int    endyy,endmm;
	char   drate_yy[4],drate_mm[3],drate_dd[3];
	char   bgn_yy[5],bgn_mm[3],end_mm[3],prtstr[223];
	int    res;
	$static date   Today;
	$char fsex[2],fmarriage[2],aphome[40],imark[5];
	$char stmt[4096],ipro_year[5],ibrand[9],fpt[2],icar_type[3],qcylinder_c[6];
	$double qpt = 0;
	$char fstl[2],dclaim[17],istl_recover[2],iacc_license[11],itag[CA_TAG_NUM];
	$char iclaim[21],ihealth[2],iengine[21],ibody[21],facc_sex[2];
	$char facc_marri[2],fcomp_class[3],facc_rel[2],iassured[13],iacc_reason[3];
	$char facc_duty[2],daccident[14],iacc_area[3],ipolicy[21],icard[21],iply_area[11];
	$long dply_begin = 0,dply_end = 0,bgndate_l,drate = 0,enddate_l,prem_total,health_total,count1;
	$int iclose_type = 0,qacar_death,qbcar_death,qccar_death,qacar_cripple,qcylinder;
	$int qbcar_cripple,qccar_cripple,qacar_injure,qbcar_injure,qccar_injure;
	$date dgroup,dgroup_tmp;
	char prtstr_1to10[196],dclaim_yyyy[5],dclaim_yy[4],dclaim_mm[3],dclaim_dd[3];
	char prtstr_1to14[196], ipolicy_br[3];
	char ipolicy_5to19[13],dgroup_c[11],dgroup_yy[5],dgroup_mm[3],dgroup_dd[3];
	char dply_begin_c[11],dply_begin_yy[5],dply_begin_mm[3],dply_begin_dd[3];
	char dply_end_c[11],dply_end_yy[5],dply_end_mm[3],dply_end_dd[3];
	$char dvictim_c[11],dvictim_yy[5],dvictim_mm[3],dvictim_dd[3];
	char body[21],buf1[21],daccident_yyyy[5],daccident_yy[4];
	$char daccident_mm[3],daccident_dd[3],iins_item[5],ivictim[11],fvictim_sex[2];
	$char fvictim_car[2],fvictim_nation[2],item1[2];
	long dclaim_yy_l;
	$long mlia_prem = 0,madjcom_prem = 0,mbusiness = 0,dvictim = 0;
	$long mcoverage,pel_cnt,sum_mapp_cover,sum_mins_stl,sum_mins_proc;
	$long sum_mstl_health,sum_all,sum_mins_health;
	$long sum_qhealth,sum_mhealth;
	$long check_sum_all,check_sum_health;
	$long tot_sum_mapp_cover_A00,tot_sum_mins_stl_A00;
	$long tot_sum_mstl_health_A00,tot_sum_all_A00,tot_sum_mins_proc_A00,tot_sum_mins_health_A00;
	$long tot_sum_qhealth_A00,tot_sum_mhealth_A00;
	$long tot_mcoverage,tot_pel_cnt,tot_sum_mapp_cover,tot_sum_mins_stl;
	$long tot_sum_mstl_health,tot_sum_all,tot_sum_mins_proc,tot_sum_mins_health;
	$long tot_sum_qhealth,tot_sum_mhealth;
	$int id1 = 0,id2 = 0,id3 = 0,id4 = 0,id5 = 0;
	int data_A, data_C;
	$char istl_flag[2];
	$char iclose_type_c[3];
	$char iclaim_a[21];
	$char ttday[21],ttday_yy[5],ttday_mm[3],ttday_dd[3];
	$char iofficer[11], fbusiness[2],ibroker_top[11],bzfrom[3];
	$char iverify[21];
	$long tot_sum_mins_stl_C00, tot_sum_all_C00;
	$long long_daccident, mcoverageBC = 0;
	$char flastA[2], fhealth[2];
	$long msum_health = 0,m_total_sum = 0;
	$int iself_duty = 0;
	$char iself_duty_c[4];
	$char fsubrogation[2];
	$char sFsubrogation[2];
	
	/* ca_dev_clm_vic_comp */
	$char t_data_yyyymm[7],t_fend_yn[2],t_fstl[2],t_istl_recover[2],t_ihealth[2],t_dclaim[9],t_iclm_company[3],t_iclm_br[3],t_iclaim[15];
	$char t_istl_flag[2],t_dgroup[9],t_icard_company[3],t_icard_br[3],t_icard[16],t_dply_begin[9],t_dply_end[9];
	$char t_fvictim_nation[2],t_ivictim[11],t_dvictim_yy[5],t_fvictim_sex[2],t_fvictim_car[2],t_fsubrogation[3],t_iins_item_1[2];
	$char t_fhealth[2],t_flast[2],t_daccident[9],t_iacc_area[2],t_iply_area[2],t_iacc_reason[3],t_iins_item[5];
	$char t_bzfrom[3],t_dsend[9];
	$long t_iclose_type,t_iself_duty,t_mcoverage,t_mapp_cover,t_mins_stl,t_mins_proc,t_mstl_health,t_qhealth,t_mhealth,t_sum_all;

	filename[0] = '\0';
	file_catalog[0] = '\0';
	sprintf_s(filename, 30, "%s/rptftp/", sApHome);
	sprintf_s(filename1,200,"AUTOS17_%d.txt",atoi(expdate)+191100);
	strcpy(file_catalog, trim(filename));
	strcat(file_catalog, trim(filename1));
	printf("file_catalog[%s] \n",file_catalog);
	
	if ((fptr=fopen(file_catalog,"w")) == NULL)
	{
		sprintf_s(errmsg,200,"Cannot open print file:%s",outputf);
		return M_CM_OPEN_FILE_FAIL;
	}

	/* *** open error log file *** */
	res = getApHome(aphome);
	sprintf_s(errFile,120,"%s.%s.error",outputf,DBName);
	printf("ERRFILE[%s]\n",errFile);
	if ((fptr_err=fopen(errFile,"w")) == NULL)
	{
		sprintf_s(errmsg,200,"Cannot open print file: %s",errFile);
		return M_CM_OPEN_FILE_FAIL;
	}

	printf(">>>expdate=%s\n",expdate);
	strncpy(bgn_yy,&expdate[0],3); bgn_yy[3]='\0';
	strncpy(bgn_mm,&expdate[3],2); bgn_mm[2]='\0';
	if (strncmp(bgn_mm, "12",2) == 0){
	   endyy=atoi(bgn_yy)+1;
	   endmm=1;
	}else{
	   endyy=atoi(bgn_yy);
	   endmm=atoi(bgn_mm)+1;
	}
	rfmtlong(endmm,"&&",end_mm);
	
	sprintf_s(bgndate,10,"%s/%s/%s",bgn_yy,bgn_mm,"01");
	sprintf_s(enddate,10,"%d/%s/%s",endyy,end_mm,"01");
	sprintf_s(data_yyyymm,7,"%s%s",itoa(atoi(bgn_yy)+1911),bgn_mm);
	
	printf(">>>bgndate=[%s] enddate=[%s]\n",bgndate,enddate);
	
	$WHENEVER SQLERROR GOTO errexit;
	
	bgndate_l=cm_ymd_cdate(bgndate);
	enddate_l=cm_ymd_cdate(enddate);
	
	/*27 ��ƻs�e���*/
	strcpy(ttday , cm_get_sysd());
	strncpy(ttday_yy,&ttday[0],4); ttday_yy[4] = '\0';
	strncpy(ttday_mm,&ttday[5],2); ttday_mm[2] = '\0';
	strncpy(ttday_dd,&ttday[8],2); ttday_dd[2] = '\0';

	count1=0;
	prem_total=0;
	health_total=0;

	for(k=0;k<count_db;k++)
	{
		
		sprintf_s(stmt,4096,"DELETE FROM %s:ca_dev_clm_vic_comp WHERE data_yyyymm = '%s'",list[k].dbname,data_yyyymm);
		$PREPARE DE_ca_dev_clm_vic_comp FROM $stmt;
		$EXECUTE DE_ca_dev_clm_vic_comp ;
		
		sprintf_s(stmt,4096,"SELECT fstl,istl_recover,ihealth,iclaim,iclose_type,dgroup,istl_flag,iself_duty \
		                FROM %s:settlement a \
		               WHERE fcard_class='1' \
		                 AND dgroup >= %ld AND dgroup < %ld \
		                 AND dgroup IS NOT NULL \
		                 AND ((msettle+(SELECT NVL(SUM(mins_proc),0) \
		                                 FROM %s:ca_stl_victim \
		                                WHERE iclaim=a.iclaim \
		                                  AND fstl=a.fstl \
		                                  AND iclose_type=a.iclose_type)) > 0 OR \
		                     (SELECT NVL(SUM(mins_proc),0) \
		                                 FROM %s:ca_stl_victim \
		                                WHERE iclaim=a.iclaim \
		                                  AND fstl=a.fstl \
		                                  AND iclose_type=a.iclose_type) < 0) \
		              ORDER BY iclaim,fstl,iclose_type",list[k].dbname,bgndate_l,enddate_l,list[k].dbname, list[k].dbname);
		$PREPARE car9999_1_tmp FROM $stmt;
		$DECLARE car9999_1 CURSOR FOR car9999_1_tmp;
		$OPEN car9999_1;
		while (1)
		{
			$FETCH car9999_1 INTO $fstl,$istl_recover,$ihealth,$iclaim,$iclose_type,$dgroup,$istl_flag,$iself_duty;
			if (SQLCODE == SQLNOTFOUND) break;
			if (strcmp(trim(iclaim),"55192C00002")==0) continue;

			printf ("fstl[%s],iclaim[%s],iclose_type[%d]\n",fstl,iclaim,iclose_type);
			sprintf_s(stmt,4096,"SELECT dclaim,ipolicy,icard,iacc_license,facc_sex, \
			                     facc_marri,facc_rel,iacc_reason,facc_duty,qacar_death, \
			                     qacar_cripple,qacar_injure,qbcar_death,qbcar_cripple, \
			                     qbcar_injure,qccar_death,qccar_cripple,qccar_injure, \
			                     daccident,DECODE(iacc_area,'42','41','63','62','65','64',iacc_area), DATE(daccident) \
			                FROM %s:appraisal \
			               WHERE iclaim = '%s'",list[k].dbname,iclaim);
			printf("stmt[%s] \n",stmt);
			$PREPARE car9999_appraisal FROM $stmt;
			$EXECUTE car9999_appraisal INTO $dclaim,$ipolicy,$icard,$iacc_license,$facc_sex,
			                                $facc_marri,$facc_rel,$iacc_reason,$facc_duty,
			                                $qacar_death,$qacar_cripple,$qacar_injure,$qbcar_death,
			                                $qbcar_cripple,$qbcar_injure,$qccar_death,
			                                $qccar_cripple,$qccar_injure,$daccident,$iacc_area,$long_daccident;
			
			sprintf_s(stmt,4096,"SELECT dply_begin,dply_end,DECODE(iply_area,'42','41','63','62','65','64',iply_area),ipro_year,ibrand,icar_type, \
			                     qcylinder,iengine,ibody,itag,fcomp_class,iassured,fsex,fmarriage \
			                FROM %s:adjustment_ply \
			               WHERE iclaim = '%s'",list[k].dbname,iclaim);
			printf("stmt[%s] \n",stmt);
			$PREPARE car9999_adjustment_ply FROM $stmt;
			$EXECUTE car9999_adjustment_ply INTO $dply_begin,$dply_end,$iply_area,$ipro_year,$ibrand,
                                                 $icar_type,$qcylinder,$iengine,$ibody,$itag,$fcomp_class,$iassured,$fsex,$fmarriage;

			
			sprintf_s(stmt,4096,"SELECT a.qpt,a.fpt,b.madjcom_prem,(b.mbusiness+b.maintain),b.mlia_prem, b.iofficer, b.bzfrom \
			                FROM %s:policy a,%s:ply_relation b \
			               WHERE a.ipolicy = b.ipolicy AND a.ipolicy = '%s' ",list[k].dbname,list[k].dbname,ipolicy);
			printf("stmt[%s] \n",stmt);
			$PREPARE car9999_ply FROM $stmt;
			$EXECUTE car9999_ply INTO $qpt,$fpt,$madjcom_prem,$mbusiness,$mlia_prem,$iofficer,$bzfrom;

			
			sprintf_s(stmt,4096,"SELECT drate \
			                FROM ca_rate_date \
			               WHERE icode = (SELECT drate_ym \
			                               FROM %s:ply_ins_type \
			                              WHERE ipolicy = '%s') \
			                 AND itable = 'compulsory_premium'",list[k].dbname,ipolicy);
			printf("stmt[%s] \n",stmt);
			$PREPARE car9999_rate FROM $stmt;
			$EXECUTE car9999_rate INTO $drate;

			company_flag=ipolicy[7];
			
			printf(" ipolicy[%s]\n",ipolicy);
			printf(" company_flag[%c]\n",company_flag);
			
			/* �q��II�|��bzfrom, �Y�S�����O�¸�ƥ���, �ҥH����FUNCTION�� */
			/*1060111005_C4_�O�o�q���X�s*/
			if (bzfrom[0] == '\0' || bzfrom[0] == '' || bzfrom[0] == ' ')
			{
				printf("iofficer[%s]\n", iofficer);
				if (cm_get_bzfrom(iofficer, fbusiness,ibroker_top,bzfrom)== M_CMN_NBROKER_AGENT)
				strcpy(bzfrom,"00");
			}
			
			rtn = getCompanyId(companyid);

			if(strcmp( companyid,"17")==0)
			{
				if(company_flag > 65 )
				{
					$select ipolicy_a
					   into $ipolicy
					   from conv_ipolicy
					  where ipolicy_n = $ipolicy;
					
					strcpy(COMPANY_P,"16");
					strcpy(COMPANY_F,"17");
				
				}
				else
				{
					strcpy(COMPANY_P,"17");
					strcpy(COMPANY_F,"17");        
				}
				
				iclaim_flag=iclaim[6];
				
				if(iclaim_flag > 65 )
				{      	
					$select distinct iclaim_a
					   into $iclaim_a
					   from conv_iclaim
					  where iclaim_n = $iclaim;           
					strcpy(COMPANY_F,"16");
				}
				else
				{
					strcpy(COMPANY_F,"17");         
					strcpy(iclaim_a, iclaim);
				}
			
			}
			else
			{
				strcpy(COMPANY_P,"32");
				strcpy(COMPANY_F,"32"); 	
				strcpy(iclaim_a, iclaim);       	
			}   

			/*1*/
			strcpy(prtstr_1to10,"1");
			strcpy(t_fend_yn,"1");
			prtstr_1to10[1]='\0';
			
			/*2*/
			strncat(prtstr_1to10, (fstl[0]=='\0') ? "0" : fstl,1);
			strcpy(t_fstl, (fstl[0]=='\0') ? "0" : fstl);
			prtstr_1to10[2]='\0';
			
			/*3*/
			if( (fstl[0] == '2') && (istl_recover[0]=='1') )
			  istl_recover[0] = '3';
			
			strncat(prtstr_1to10, (strlen(trim(istl_recover))==0) ? "2" : istl_recover,1);
			strcpy(t_istl_recover, (strlen(trim(istl_recover))==0) ? "2" : istl_recover);
			prtstr_1to10[3]='\0';
			
			/*4*/ /* �᭱�ٷ|�A�P�_�@��: �H���O�����N��(12.7), �B���׫ݰ��O�l�v(12.8) => 2 */
			strncat(prtstr_1to10, (strlen(trim(ihealth))==0) ? "2" : ihealth,1);
			strcpy(t_ihealth, (strlen(trim(ihealth))==0) ? "2" : ihealth);
			prtstr_1to10[4]='\0';  
			
			/*5*/
			strncpy(dclaim_yyyy,&dclaim[0],4); dclaim_yyyy[4] = '\0';
			strncpy(dclaim_mm,&dclaim[5],2); dclaim_mm[2] = '\0';
			strncpy(dclaim_dd,&dclaim[8],2); dclaim_dd[2] = '\0';
			strncat(prtstr_1to10, (dclaim_yyyy[0]=='\0') ? "0000" : dclaim_yyyy,4);
			strncat(prtstr_1to10, (dclaim_mm[0]=='\0') ? "00" : dclaim_mm,2);
			strncat(prtstr_1to10, (dclaim_dd[0]=='\0') ? "00" : dclaim_dd,2);
			strcpy(t_dclaim, (dclaim_yyyy[0]=='\0') ? "0000" : dclaim_yyyy);
			strcat(t_dclaim, (dclaim_mm[0]=='\0') ? "00" : dclaim_mm);
			strcat(t_dclaim, (dclaim_dd[0]=='\0') ? "00" : dclaim_dd);
			prtstr_1to10[12]='\0';
			
			/*6*/
			printf ("iclaim[%s]\n",iclaim_a);
			strcat(prtstr_1to10,COMPANY_F); prtstr_1to10[14]='\0';
			strcpy(t_iclm_company,COMPANY_F);
			strncat(prtstr_1to10, (iclaim_a[0]=='\0') ? "              " : iclaim_a,14);
			strncpy(t_iclm_br, (iclaim_a[0]=='\0') ? "  " : iclaim_a,2);t_iclm_br[2] = '\0';
			strcpy(t_iclaim, (iclaim_a[0]=='\0') ? "              " : iclaim_a,14);t_iclaim[14] = '\0';
			prtstr_1to10[28]='\0';
			printf ("[%s]\n",prtstr_1to10);
			
			/* 7 29-30 �ߥI/�l�v���� */
			t_iclose_type = iclose_type;
			rfmtlong(iclose_type,"&&",iclose_type_c);
			strncat(prtstr_1to10, (iclose_type_c[0]=='\0') ? "00" : iclose_type_c,2);
			prtstr_1to10[30]='\0';
			
			/* 8 31 �ߥI�N�� */
			if ( istl_flag[0] == '\0' )
			{
				strcat(prtstr_1to10,"1");
				strcpy(t_istl_flag,"1");
			}
			else if ( strcmp(istl_flag," ") == 0 )
			{
				strcat(prtstr_1to10,"1");
				strcpy(t_istl_flag,"1");
			}
			else
			{
				strncat(prtstr_1to10,istl_flag,1);
				strcpy(t_istl_flag,istl_flag);
			}
			
			prtstr_1to10[31]='\0';
			
			/*9 32-39 ���פ��*/
			strcpy(dgroup_c,cm_cdate_str_100(dgroup));
			cm_split_ymd_100(dgroup_c,dgroup_yy,dgroup_mm,dgroup_dd);
			rfmtlong(atoi(dgroup_yy)+1911,"&&&&",dgroup_yy);
			strncat(prtstr_1to10,(dgroup_yy[0]=='\0') ? "0000" : dgroup_yy,4);
			strncat(prtstr_1to10,(dgroup_mm[0]=='\0') ? "00" : dgroup_mm,2);
			strncat(prtstr_1to10,(dgroup_dd[0]=='\0') ? "00" : dgroup_dd,2);
			strcpy(t_dgroup,(dgroup_yy[0]=='\0') ? "0000" : dgroup_yy);
			strcat(t_dgroup,(dgroup_mm[0]=='\0') ? "00" : dgroup_mm);
			strcat(t_dgroup,(dgroup_dd[0]=='\0') ? "00" : dgroup_dd);
			prtstr_1to10[39]='\0';

			/*10 40*/
			strncat(prtstr_1to10,COMPANY_P, 2);
			strcpy(t_icard_company,COMPANY_P);
			if( strcmp(COMPANY_P,"16") == 0 )
			{
				strncat(prtstr_1to10,(icard[0]=='\0') ? "                 " : icard, 17 );
				strncpy(t_icard_br,(icard[0]=='\0') ? "  " : icard, 2 ); t_icard_br[2] = '\0';
				strncpy(t_icard,(icard[0]=='\0') ? "               " : icard+2,15); t_icard[15] = '\0';
			}
			else
			{
				strncpy(ipolicy_br,&ipolicy[0],2); ipolicy_br[2]='\0';
				if (ipolicy_br[0] == '\0') 
				{
					strcat(prtstr_1to10,"00");
					strcpy(t_icard_br,"00");
				}
				else 
				{
					strcat(prtstr_1to10,ipolicy_br);           /*C3-4:������c*/
					strcpy(t_icard_br,ipolicy_br);
				}
				strncat(prtstr_1to10,(icard[0]=='\0') ? "               " : icard,15);
				strcpy(t_icard,(icard[0]=='\0') ? "               " : icard); t_icard[15] = '\0';
			}
			prtstr_1to10[58]='\0';

			/*11 59-66 �O�I���_�l��*/
			strcpy(dply_begin_c,cm_cdate_str_100(dply_begin));
			cm_split_ymd_100(dply_begin_c,dply_begin_yy,dply_begin_mm,dply_begin_dd);
			rfmtlong(atoi(dply_begin_yy)+1911,"&&&&",dply_begin_yy);
			strncat(prtstr_1to10,(dply_begin_yy[0]=='\0') ? "0000" : dply_begin_yy,4);
			strncat(prtstr_1to10,(dply_begin_mm[0]=='\0') ? "00" : dply_begin_mm,2);
			strncat(prtstr_1to10,(dply_begin_dd[0]=='\0') ? "00" : dply_begin_dd,2);
			strcpy(t_dply_begin,(dply_begin_yy[0]=='\0') ? "0000" : dply_begin_yy);
			strcat(t_dply_begin,(dply_begin_mm[0]=='\0') ? "00" : dply_begin_mm);
			strcat(t_dply_begin,(dply_begin_dd[0]=='\0') ? "00" : dply_begin_dd);
			prtstr_1to10[66]='\0';
			printf("iclaim[%s]\n",iclaim);

			/*11 67-74 car950512 �O�I�����W�C*/
			strcpy(dply_end_c,cm_cdate_str_100(dply_end));
			cm_split_ymd_100(dply_end_c,dply_end_yy,dply_end_mm,dply_end_dd);
			rfmtlong(atoi(dply_end_yy)+1911,"&&&&",dply_end_yy);
			strncat(prtstr_1to10,(dply_end_yy[0]=='\0') ? "0000" : dply_end_yy,4);
			strncat(prtstr_1to10,(dply_end_mm[0]=='\0') ? "00" : dply_end_mm,2);
			strncat(prtstr_1to10,(dply_end_dd[0]=='\0') ? "00" : dply_end_dd,2);
			strcpy(t_dply_end,(dply_end_yy[0]=='\0') ? "0000" : dply_end_yy);
			strcat(t_dply_end,(dply_end_mm[0]=='\0') ? "00" : dply_end_mm);
			strcat(t_dply_end,(dply_end_dd[0]=='\0') ? "00" : dply_end_dd);
			prtstr_1to10[74]='\0';

			/* �d�����p */
			$SELECT iverify
			   INTO $iverify
			   FROM ca_ver_relation
			  WHERE iclaim = $iclaim;
			if (SQLCODE == SQLNOTFOUND) strcpy(iverify, iclaim);
			
			/**** �������`�H��� ****/
			sprintf_s(stmt,4096,"SELECT a.ivictim, b.dvictim, b.fvictim_sex, b.fvictim_car, b.fvictim_nation, b.fhealth, b.fsubrogation \
			                FROM %s:ca_stl_victim a,ca_clm_victim_data b \
			                WHERE a.iclaim = '%s' \
			                AND b.iclaim = '%s' \
			                AND b.ivictim = a.ivictim \
			                AND a.fstl = '%s' \
			                AND a.iclose_type = %d \
			                GROUP BY a.ivictim, b.dvictim, b.fvictim_sex, b.fvictim_car, b.fvictim_nation, b.fhealth, b.fsubrogation \
			                ORDER BY a.ivictim ",list[k].dbname,iclaim,iverify,fstl,iclose_type);
			$PREPARE car9999_3_tmp FROM $stmt;
			$DECLARE car9999_3 CURSOR for car9999_3_tmp;
			$OPEN car9999_3;
			while (1)
			{
				$FETCH car9999_3 INTO $ivictim, $dvictim, $fvictim_sex, $fvictim_car, $fvictim_nation, $fhealth, $fsubrogation;
				if (SQLCODE == SQLNOTFOUND) break;

				strcpy(prtstr_1to14,prtstr_1to10);

				/*12-1*/ /* ID���~,�Y�H���O�����N��,�O�o���|�ˮ�: �D�ꤺ�۵M�H,���i�H���O�����N�� */
				if(strncmp(ivictim, "ID", 2)==0 && strlen(trim(ivictim))==5)
				{
					strcat(prtstr_1to14,"8");
					strcpy(t_fvictim_nation,"8");
				}
				else
				{
					if(strcmp(fvictim_nation,"1") == 0)
					{
						strcat(prtstr_1to14,"1");
						strcpy(t_fvictim_nation,"1");
					}
					else if(strcmp(fvictim_nation,"2") == 0)
					{
						strcat(prtstr_1to14,"2");
						strcpy(t_fvictim_nation,"2");
					}
					else
					{
						strcat(prtstr_1to14,"8");
						strcpy(t_fvictim_nation,"8");
					}
				}
				prtstr_1to14[75] = '\0';
               
				/*12-2*/
				strncat(prtstr_1to14, (ivictim[0]=='\0') ? "          " : ivictim,10);
				strcpy(t_ivictim, (ivictim[0]=='\0') ? "          " : ivictim);
				prtstr_1to14[85]='\0';

				/*12-3*/
				strcpy(dvictim_c,cm_cdate_str_100(dvictim));
				cm_split_ymd_100(dvictim_c,dvictim_yy,dvictim_mm,dvictim_dd);
				rfmtlong(atoi(dvictim_yy)+1911,"&&&&",dvictim_yy);
				strncat(prtstr_1to14,(dvictim_yy[0]=='\0') ? "0000" : dvictim_yy,4);
				strcpy(t_dvictim_yy,(dvictim_yy[0]=='\0') ? "0000" : dvictim_yy);
				prtstr_1to14[89]='\0';

   				/*12-4*/
				if( fvictim_sex[0] != '1' && fvictim_sex[0] != '2' )
				{
					if( ivictim[1] == '1' )
						strcpy(fvictim_sex,"1");
					else if( ivictim[1] == '2' )
						strcpy(fvictim_sex,"2");
				} 
				strncat(prtstr_1to14, (fvictim_sex[0]=='\0') ? "0" : fvictim_sex,1);
				strcpy(t_fvictim_sex, (fvictim_sex[0]=='\0') ? "0" : fvictim_sex);
				prtstr_1to14[90]='\0';

				/*12-5*/
				if (*fvictim_car=='A')
				{
					strncat(prtstr_1to14, "1",1);
					strcpy(t_fvictim_car, "1");
				}
				else if (*fvictim_car=='B')
				{
					strncat(prtstr_1to14, "2",1);
					strcpy(t_fvictim_car, "2");
				}
				else if (*fvictim_car=='C' || *fvictim_car == ' ')
				{
					strncat(prtstr_1to14, "3",1);
					strcpy(t_fvictim_car, "3");
				}
				else if (*fvictim_car=='D')
				{
					strncat(prtstr_1to14, "4",1);
					strcpy(t_fvictim_car, "4");
				}
				else if (*fvictim_car=='E')
				{
					strncat(prtstr_1to14, "5",1);
					strcpy(t_fvictim_car, "5");
				}
				else if (*fvictim_car=='F')
				{
					strncat(prtstr_1to14, "6",1);
					strcpy(t_fvictim_car, "6");
				}
				else
				{
					strncat(prtstr_1to14, "1",1);
					strcpy(t_fvictim_car, "1");
				}
				
				prtstr_1to14[91]='\0';

				/*** 92 �A�β�29���l�v�ƶ� add by larry 103.09.18 (1030521004_C2) */
				/*�����覡�אּ�M9993�@��*/
				$SELECT fsubrogation INTO $sFsubrogation
				   FROM ca_clm_victim_data
				  WHERE ivictim = $iacc_license
				    AND iclaim = $iverify;
				if (SQLCODE == SQLNOTFOUND) strcpy(sFsubrogation,"N");
				strncat(prtstr_1to14, (sFsubrogation[0]=='\0') ? "N" : sFsubrogation,1);
				strcpy(t_fsubrogation, (sFsubrogation[0]=='\0') ? "N" : sFsubrogation);
				prtstr_1to14[92]='\0';
				
				/*** 95 �����F�Ƴd���ʤ��� ***/
				t_iself_duty = iself_duty;
				rfmtlong(iself_duty,"&&&",iself_duty_c);
				strncat(prtstr_1to14, iself_duty_c,3);
				prtstr_1to14[95]='\0';

				/*** �d���`�H���ɭ������p ***/
				sprintf_s(stmt,4096,"SELECT DISTINCT iins_item[1,1],sum(mins_stl+mins_proc+mstl_health) \
				                FROM %s:ca_stl_victim \
				               WHERE iclaim = '%s' \
				                 AND ivictim = '%s' \
				                 AND fstl = '%s' \
				                 AND iclose_type = %d \
				                 AND iins_item[1,1] = 'B' \
				               GROUP BY 1",list[k].dbname,iclaim,ivictim,fstl,iclose_type);
				              
				$PREPARE car9999_vic_B FROM $stmt;
				$EXECUTE car9999_vic_B;
				if (SQLCODE == SQLNOTFOUND)
				{
					sprintf_s(stmt,4096,"SELECT DISTINCT iins_item[1,1],sum(mins_stl+mins_proc+mstl_health) \
				                    FROM %s:ca_stl_victim \
				                   WHERE iclaim = '%s' \
				                     AND ivictim = '%s' \
				                     AND fstl = '%s' \
				                     AND iclose_type = %d \
				                     AND iins_item[1,1] = 'C' \
				                   GROUP BY 1",list[k].dbname,iclaim,ivictim,fstl,iclose_type);
				   	$PREPARE car9999_vic_C FROM $stmt;
					$EXECUTE car9999_vic_C;
					if (SQLCODE == SQLNOTFOUND)
					{					
						sprintf_s(stmt,4096,"SELECT DISTINCT iins_item[1,1] \
						                FROM %s:ca_stl_victim \
						               WHERE iclaim = '%s' \
						                 AND ivictim = '%s' \
						                 AND fstl = '%s' \
						                 AND iclose_type = %d \
						                 AND iins_item[1,1] = 'A' \
						               GROUP BY 1",list[k].dbname,iclaim,ivictim,fstl,iclose_type);
						$PREPARE car9999_vic_A FROM $stmt;
						$EXECUTE car9999_vic_A;
						if (SQLCODE == SQLNOTFOUND) 
						{
							strcat(prtstr_1to14,"3");
							strcpy(t_iins_item_1,"3");
						}
						else 
						{
							strcat(prtstr_1to14,"3");
							strcpy(t_iins_item_1,"3");
						}
					}
					else 
					{
						strcat(prtstr_1to14,"2");
						strcpy(t_iins_item_1,"2");
					}
				}
				else 
				{
					strcat(prtstr_1to14,"1");
					strcpy(t_iins_item_1,"1");
				}
				prtstr_1to14[96]='\0';

				/* 12.7 96 ���_���O�N�� */
				/* 12.8 97 ���׫ݰ��O�l�v */
				/* ���O�d �ݫ���B�z */
				strcat(prtstr_1to14, "  ");
				strcpy(t_fhealth," "); 
				strcpy(t_flast," ");
				prtstr_1to14[98]='\0';
				
				/*13 99-106 �X�I��*/
				strncpy(daccident_yyyy,&daccident[0],4); daccident_yyyy[4]='\0';
				strncpy(daccident_mm,&daccident[5],2); daccident_mm[2]='\0';
				strncpy(daccident_dd,&daccident[8],2); daccident_dd[2]='\0';
				strncat(prtstr_1to14,(daccident_yyyy[0]=='\0') ? "0000" : daccident_yyyy,4);
				strncat(prtstr_1to14,(daccident_mm[0]=='\0') ? "00" : daccident_mm,2);
				strncat(prtstr_1to14,(daccident_dd[0]=='\0') ? "00" : daccident_dd,2);
				strcpy(t_daccident,(daccident_yyyy[0]=='\0') ? "0000" : daccident_yyyy);
				strcat(t_daccident,(daccident_mm[0]=='\0') ? "00" : daccident_mm);
				strcat(t_daccident,(daccident_dd[0]=='\0') ? "00" : daccident_dd);
				prtstr_1to14[106]='\0';
				
				/*14 107-108 �X�I�a�ϥN��*/
				strncat(prtstr_1to14, (iacc_area[0]=='\0') ? "  " : iacc_area,2);
				strcpy(t_iacc_area, (iacc_area[0]=='\0') ? "  " : iacc_area);
				prtstr_1to14[108]='\0';
				
				/*15 109-110 �ӫO�a�ϥN��*/
				strncat(prtstr_1to14, (iply_area[0]=='\0') ? "  " : iply_area,2);
				strcpy(t_iply_area, (iply_area[0]=='\0') ? "  " : iply_area);
				prtstr_1to14[110]='\0';
				
				/*16 111-112 �X�I��]�N��*/
				strncat(prtstr_1to14, (iacc_reason[0]=='\0') ? "  " : iacc_reason,2);
				strcpy(t_iacc_reason, (iacc_reason[0]=='\0') ? "  " : iacc_reason);
				prtstr_1to14[112]='\0';
				
				printf("prtstr[%s]\n",prtstr_1to14);
				
				tot_mcoverage=tot_pel_cnt=tot_sum_mapp_cover=0;
				tot_sum_mins_stl=tot_sum_mins_proc=tot_sum_mins_health=0;
				tot_sum_qhealth=tot_sum_mhealth=0;
				tot_sum_all=0;
				check_sum_all = 0;
				check_sum_health = 0;
				tot_sum_mins_stl_A00=tot_sum_mins_proc_A00=tot_sum_mins_health_A00=0;
				tot_sum_qhealth_A00=tot_sum_mhealth_A00=0;
				tot_sum_mapp_cover_A00=0;
				tot_sum_all_A00=0;
				data_A=data_C=0;
				tot_sum_mins_stl_C00=tot_sum_all_C00=0;
				
				/* ���ݫO�B */
				$SELECT NVL(MAX(mfactor), 1500000)
				   INTO $mcoverageBC
				   FROM ca_reco_factor
				  WHERE itype=7
				    AND icode='C010'
				    AND $long_daccident BETWEEN dbegin AND dend;

               /*���I���O�N��=A*/
               printf ("##### iins_item==>[A], iclaim[%s], ivictim[%s]\n",iclaim, ivictim);
               sprintf_s(stmt,4096,"SELECT DISTINCT iins_item[1,1] \
                               FROM %s:ca_stl_victim \
                              WHERE iclaim = '%s' \
                                AND fstl        = '%s' \
                                AND iclose_type = %d \
                                AND ivictim     = '%s' ",list[k].dbname,iclaim,fstl,iclose_type,ivictim);

				$PREPARE car9999_kind_tmp FROM $stmt;
				$DECLARE car9999_kind CURSOR FOR car9999_kind_tmp;
				$OPEN car9999_kind;
				while(1)
				{
					$FETCH car9999_kind INTO $item1;
					if (SQLCODE==SQLNOTFOUND) break;
					printf("item1-------->[%s]\n",item1);

					if (item1[0]=='A')
					{
						if (fstl[0]=='2') strcpy(flastA, "N");
						else
						{
							/* �O�_�����O�l�v */
							sprintf_s(stmt,4096,"SELECT NVL(SUM(case fstl when '1' then mstl_health else (-1)*mstl_health end),0), \
							                     NVL(SUM(case fstl when '1' then (mins_stl+mstl_health) else (-1)*(mins_stl+mstl_health) end),0) \
							                FROM %s:ca_stl_victim \
							               WHERE iclaim = '%s' \
							                 AND iins_item[1] = 'A'",list[k].dbname,iclaim);
							
							$PREPARE car9999_victim_A FROM $stmt;
							$EXECUTE car9999_victim_A INTO $msum_health,$m_total_sum;
						
							if (msum_health > 0 && m_total_sum<=200000) strcpy(flastA, "N");
							else
							{
								/* �O�_�����`�H�������جҵ��׫ݰ��O�l�v */
								sprintf_s(stmt,4096,"SELECT UNIQUE iclaim \
								                FROM %s:ca_app_victim a \
								               WHERE a.iclaim = '%s' \
								                 AND a.ivictim = '%s' \
								                 AND a.iins_item[1,1] = '%s' \
								                 AND NOT EXISTS (SELECT * FROM %s:ca_stl_victim \
								                                  WHERE iclaim = a.iclaim \
								                                    AND ivictim = a.ivictim \
								                                    AND iins_item = a.iins_item \
								                                    AND fstl = '1' \
								                                    AND flast IN ('1','2') \
								                                    AND dgroup < %ld)",list[k].dbname,iclaim,ivictim,item1,list[k].dbname,enddate_l);
								$PREPARE car9999_victim_A_2 FROM $stmt;
								$EXECUTE car9999_victim_A_2;
								if (SQLCODE==SQLNOTFOUND) strcpy(flastA, "Y");
								else strcpy(flastA, "N");
							}
						}
					}

					sprintf_s(stmt,4096,"SELECT a.iins_item,b.mcoverage,a.dgroup, \
					                     (b.mapp_cover+b.mapp_fee), \
					                     DECODE(a.fstl,'2',a.mins_stl*(-1),a.mins_stl),a.mins_proc,DECODE(a.fstl,'2',a.mstl_health*(-1),a.mstl_health), \
					                     SUM(DECODE(a.fstl,'2',a.mins_stl*(-1),a.mins_stl)+a.mins_proc+DECODE(a.fstl,'2',a.mstl_health*(-1),a.mstl_health)) \
					                FROM %s:ca_stl_victim a, outer %s:ca_app_victim b \
					               WHERE b.iclaim = a.iclaim \
					                 AND b.ivictim= a.ivictim \
					                 AND b.iins_item = a.iins_item \
					                 AND a.iclaim      = '%s' \
					                 AND a.fstl        = '%s' \
					                 AND a.ivictim     = '%s' \
					                 AND a.iclose_type = %d \
					                 AND a.iins_item[1,1] = '%s' \
					               GROUP BY 1,2,3,4,5,6,7 \
					               ORDER BY a.iins_item ",list[k].dbname,list[k].dbname,iclaim,fstl,ivictim,iclose_type,item1);
					
					$PREPARE car9999_victim_tmp FROM $stmt;
					$DECLARE car9999_victim CURSOR FOR car9999_victim_tmp;
					$OPEN car9999_victim;
					while(1)
					{
						$FETCH car9999_victim INTO $iins_item,$mcoverage,$dgroup_tmp,$sum_mapp_cover:id1,
						                           $sum_mins_stl:id2,$sum_mins_proc:id3,$sum_mstl_health:id4,$sum_all:id5;
						if (SQLCODE==SQLNOTFOUND) break;
						
						if(id1==-1) sum_mapp_cover=0;
						if(id2==-1) sum_mins_stl=0;
						if(id3==-1) sum_mins_proc=0;
						if(id4==-1) sum_mstl_health=0;
						if(id5==-1) sum_all=0;
						/********************************************************************
						if ((sum_mins_stl ==0) && (sum_mins_proc==0) && (sum_mstl_health==0))
						continue ;
						********************************************************************/
						if (iins_item[0]=='A')
						data_A +=1;
						
						if (iins_item[0]=='C')
						data_C +=1;
						
						strcpy(prtstr,prtstr_1to14);
						printf("#### PETER iins_item[%s]\n",iins_item);
						
						/* ���O�I�ơB���B */
						/*2017/01/09  12/1�_�ǰe�O�o�����O�I�����P���O���B���ݩ󰷫O�I�ơA�u�ݶ�����O�I��(�I��+���B)�A���O���B���b�ϥ�(���B��0)�C*/
						sum_qhealth = 0;
						sum_mhealth = 0;
						
						if (iins_item[0]=='A')
						{
							/* �B�z���_���O�N��&���׫ݰ��O�l�v */
							if (fhealth[0]=='Y')   /* ���O�N�� */
							{
								prtstr[96]='Y';
								strcpy(t_fhealth,"Y");
								if (flastA[0]=='Y') 
								{
									prtstr[97]='Y'; /* ���׫ݰ��O�l�v */
									prtstr[3]='2';  /* �|�ݰ��O�l�v */
									prtstr_1to10[3]='2';  /* �|�ݰ��O�l�v */
									prtstr_1to14[3]='2';  /* �|�ݰ��O�l�v */
									strcpy(t_ihealth,"2");
									strcpy(t_flast,"Y");
								}
								else 
								{
									prtstr[97]='N';
									strcpy(t_flast,"N");
								}
							}
							else
							{
								prtstr[96]='N';
								prtstr[97]='N';
								strcpy(t_fhealth,"N");
								strcpy(t_flast,"N");
							}
						}
						printf("####### PETER iins_item[%s] , prtstr[%s]\n",iins_item,prtstr);
	
						/*17 113-115 ���I���O�N��*/
						strncat(prtstr,(iins_item[0]=='\0') ? "    " : iins_item,4);
						strcpy(t_iins_item,(iins_item[0]=='\0') ? "    " : iins_item);
						prtstr[116]='\0';
						
						/*19 117-125 �C�H�O�I���B*/
						strcat(prtstr,(mcoverage<0) ? "-" : "+");
						if (iins_item[0]=='A')
						{
							strncat(prtstr, "00000000" ,8);
							mcoverage=0;
						}
						else
						{
							mcoverage=mcoverageBC;
							buf1[0]='\0';
							rfmtlong(mcoverage,"&&&&&&&&",buf1);
							strncat(prtstr,(buf1[0]=='\0') ? "00000000" : buf1,8);
						}
						prtstr[125]='\0';
						
						tot_mcoverage+=mcoverage;
	
						/*20 126-138 �w���l�����B*/
						strcat(prtstr,(sum_mapp_cover<0) ? "-" : "+");
						buf1[0]='\0';
						rfmtlong(sum_mapp_cover,"&&&&&&&&&&&&",buf1);
						strncat(prtstr,(buf1[0]=='\0') ? "000000000000" : buf1,12);
						prtstr[138]='\0';
						
						tot_sum_mapp_cover+=sum_mapp_cover;
						if(iins_item[0]=='A')
						tot_sum_mapp_cover_A00+=sum_mapp_cover;
						
						/* 21 139-151 ���t���O�z�ߪ��B*/
						strcat(prtstr,(sum_mins_stl<0) ? "-" : "+");
						buf1[0]='\0';
						rfmtlong(sum_mins_stl,"&&&&&&&&&&&&",buf1);
						strncat(prtstr,(buf1[0]=='\0') ? "000000000000" : buf1,12);
						prtstr[151]='\0';
						
						tot_sum_mins_stl+=sum_mins_stl;
						if(iins_item[0]=='A')
						tot_sum_mins_stl_A00+=sum_mins_stl;
						else if (iins_item[0]=='C')
						tot_sum_mins_stl_C00+=sum_mins_stl;
						
						/*22 152-162 �z�߶O��*/
						strcat(prtstr,(sum_mins_proc<0) ? "-" : "+");
						buf1[0]='\0';
						rfmtlong(sum_mins_proc,"&&&&&&&&&&",buf1);
						strncat(prtstr,(buf1[0]=='\0') ? "0000000000" : buf1,10);
						prtstr[162]='\0';
						
						tot_sum_mins_proc+=sum_mins_proc;
						if(iins_item[0]=='A')
						tot_sum_mins_proc_A00+=sum_mins_proc;
						
						/*23 163-173 ���I���O���B*/
						strcat(prtstr,(sum_mstl_health<0) ? "-" : "+");
						buf1[0]='\0';
						rfmtlong(sum_mstl_health,"&&&&&&&&&&",buf1);
						strncat(prtstr,(buf1[0]=='\0') ? "0000000000" : buf1,10);
						prtstr[173]='\0';
						
						tot_sum_mins_health+=sum_mstl_health;
						if(iins_item[0]=='A')
						tot_sum_mins_health_A00+=sum_mstl_health;
						
						/*24 174-182 ���O�I��*/
						strcat(prtstr,(sum_qhealth<0) ? "-" : "+");
						buf1[0]='\0';
						rfmtlong(sum_qhealth,"&&&&&&&&",buf1);
						strncat(prtstr,(buf1[0]=='\0') ? "00000000" : buf1,8);
						prtstr[182]='\0';
						
						tot_sum_qhealth+=sum_qhealth;
						if(iins_item[0]=='A')
						tot_sum_qhealth_A00+=sum_qhealth;
						
						/*24 183-191 ���O���B*/
						strcat(prtstr,(sum_mhealth<0) ? "-" : "+");
						buf1[0]='\0';
						rfmtlong(sum_mhealth,"&&&&&&&&",buf1);
						strncat(prtstr,(buf1[0]=='\0') ? "00000000" : buf1,8);
						prtstr[191]='\0';
						
						tot_sum_mhealth+=sum_mhealth;
						if(iins_item[0]=='A')
						tot_sum_mhealth_A00+=sum_mhealth;
						
						/*25 192-204 ��ڲz�ߪ��B*/
						strcat(prtstr,(sum_all<0) ? "-" : "+");
						buf1[0]='\0';
						rfmtlong(sum_all,"&&&&&&&&&&&&",buf1);
						strncat(prtstr,(buf1[0]=='\0') ? "000000000000" : buf1,12);
						prtstr[204]='\0';
						
						tot_sum_all+=sum_all;

						check_sum_all += (sum_mins_stl+sum_mins_proc+sum_mstl_health);
						check_sum_health += sum_mstl_health;
	
						if(iins_item[0]=='A')
							tot_sum_all_A00+=sum_all;
						else if (iins_item[0]=='C')
							tot_sum_all_C00+=sum_all;
							
						t_mcoverage = mcoverage;
						t_mapp_cover = sum_mapp_cover;
						t_mins_stl = sum_mins_stl;
						t_mins_proc = sum_mins_proc;
						t_mstl_health = sum_mstl_health;
						t_qhealth = sum_qhealth;
						t_mhealth = sum_mhealth;
						t_sum_all = sum_all;
						
						/*26 205-212 �ߥI/�l�v���*/
						strcpy(dgroup_c,cm_cdate_str_100(dgroup));
						cm_split_ymd_100(dgroup_c,dgroup_yy,dgroup_mm,dgroup_dd);
						rfmtlong(atoi(dgroup_yy)+1911,"&&&&",dgroup_yy);
						strncat(prtstr,(dgroup_yy[0]=='\0') ? "0000" : dgroup_yy,4);
						strncat(prtstr,(dgroup_mm[0]=='\0') ? "00" : dgroup_mm,2);
						strncat(prtstr,(dgroup_dd[0]=='\0') ? "00" : dgroup_dd,2);
						prtstr[212]='\0';
						
						/*27 213-214 �q���O�N�� 2009.2�W�C�榡*/
						strcat(prtstr,bzfrom);
						strcpy(t_bzfrom,bzfrom);
						prtstr[214] = '\0';
						
						/*28 ��ƻs�e���*/
						strcat(prtstr,ttday_yy);
						strcat(prtstr,ttday_mm);
						strcat(prtstr,ttday_dd);
						strcpy(t_dsend,ttday_yy);
						strcat(t_dsend,ttday_mm);
						strcat(t_dsend,ttday_dd);
						prtstr[222]='\0';
						
						count1++;
						fprintf(fptr,"%s\n",prtstr);
						
						printf("data_yyyymm[%s],t_fend_yn[%s],t_fstl[%s],t_istl_recover[%s],t_ihealth[%s],t_dclaim[%s],t_iclm_company[%s],t_iclm_br[%s],t_iclaim[%s],t_iclose_type[%d] \n",
					            data_yyyymm,t_fend_yn,t_fstl,t_istl_recover,t_ihealth,t_dclaim,t_iclm_company,t_iclm_br,t_iclaim,t_iclose_type);
						printf("t_istl_flag[%s],t_dgroup[%s],t_icard_company[%s],t_icard_br[%s],t_icard[%s],t_dply_begin[%s],t_dply_end[%s]\n",
						        t_istl_flag,t_dgroup,t_icard_company,t_icard_br,t_icard,t_dply_begin,t_dply_end);
						printf("t_fvictim_nation[%s],t_ivictim[%s],t_dvictim_yy[%s],t_fvictim_sex[%s],t_fvictim_car[%s],t_fsubrogation[%s] \n",
						        t_fvictim_nation,t_ivictim,t_dvictim_yy,t_fvictim_sex,t_fvictim_car,t_fsubrogation);
						printf("t_iself_duty[%d],t_iins_item_1[%s],t_fhealth[%s],t_flast[%s],t_daccident[%s],t_iacc_area[%s],t_iply_area[%s],t_iacc_reason[%s] \n",
						        t_iself_duty,t_iins_item_1,t_fhealth,t_flast,t_daccident,t_iacc_area,t_iply_area,t_iacc_reason);
						printf("t_iins_item[%s],t_mcoverage[%d],t_mapp_cover[%d],t_mins_stl[%d],t_mins_proc[%d],t_mstl_health[%d],t_qhealth[%d],t_mhealth[%d],t_sum_all[%d] \n",
						        t_iins_item,t_mcoverage,t_mapp_cover,t_mins_stl,t_mins_proc,t_mstl_health,t_qhealth,t_mhealth,t_sum_all);
						printf("t_bzfrom[%s],t_dsend[%s] \n",
						        t_bzfrom,t_dsend);
			         	
			         	sprintf_s(stmt,4096,"INSERT INTO %s:ca_dev_clm_vic_comp \
				                                 (data_yyyymm,fend_yn,fstl,istl_recover,ihealth,dclaim,iclm_company,iclm_br,iclaim,iclose_type, \
						                          istl_flag,dgroup,icard_company,icard_br,icard,dply_begin,dply_end, \
						                          fvictim_nation,ivictim,dvictim_yy,fvictim_sex,fvictim_car,fsubrogation, \
						                          iself_duty,iins_item_1,fhealth,flast,daccident,iacc_area,iply_area,iacc_reason, \
						                          iins_item,mcoverage,mapp_cover,mins_stl,mins_proc,mstl_health,qhealth,mhealth,sum_all, \
						                          bzfrom,dsend) \
				                          VALUES(?,?,?,?,?,?,?,?,?,?, \
				                                 ?,?,?,?,?,?,?, \
				                                 ?,?,?,?,?,?, \
				                                 ?,?,?,?,?,?,?,?, \
				                                 ?,?,?,?,?,?,?,?,?, \
				                                 ?,?)",list[k].dbname);
							$PREPARE insert_clm_vic FROM $stmt;
							$EXECUTE insert_clm_vic using $data_yyyymm,$t_fend_yn,$t_fstl,$t_istl_recover,$t_ihealth,$t_dclaim,$t_iclm_company,$t_iclm_br,$t_iclaim,$t_iclose_type,
						                                  $t_istl_flag,$t_dgroup,$t_icard_company,$t_icard_br,$t_icard,$t_dply_begin,$t_dply_end,
						                                  $t_fvictim_nation,$t_ivictim,$t_dvictim_yy,$t_fvictim_sex,$t_fvictim_car,$t_fsubrogation,
						                                  $t_iself_duty,$t_iins_item_1,$t_fhealth,$t_flast,$t_daccident,$t_iacc_area,$t_iply_area,$t_iacc_reason,
						                                  $t_iins_item,$t_mcoverage,$t_mapp_cover,$t_mins_stl,$t_mins_proc,$t_mstl_health,$t_qhealth,$t_mhealth,$t_sum_all,
						                                  $t_bzfrom,$t_dsend;
					} /*end car9999_victim */
					$CLOSE car9999_victim;
					$FREE car9999_victim;
	
   					if (data_A > 0)
					{
						strcpy(prtstr,prtstr_1to14);
						printf("prtstr[%s]\n",prtstr);
						
						data_A = 0;
						
						/* �B�z���_���O�N��&���׫ݰ��O�l�v */
						if (fhealth[0]=='Y')
						{
							prtstr[96]='Y';
							strcpy(t_fhealth,"Y");
							if (flastA[0]=='Y') 
							{
								prtstr[97]='Y'; /* ���׫ݰ��O�l�v */
								prtstr[3]='2';  /* �|�ݰ��O�l�v */
								prtstr_1to10[3]='2';  /* �|�ݰ��O�l�v */
								prtstr_1to14[3]='2';  /* �|�ݰ��O�l�v */
								strcpy(t_ihealth,"2");
								strcpy(t_flast,"Y");
							}
							else
							{
								prtstr[97]='N';
								strcpy(t_flast,"N");
							}
						}
						else
						{
							prtstr[96]='N';
							prtstr[97]='N';
							strcpy(t_fhealth,"N");
							strcpy(t_flast,"N");
						}
						
						/*17+18 */
						strcat(prtstr,"A000");
						strcpy(t_iins_item,"A000");
						prtstr[116]='\0';
						
						/*19*/
						strcat(prtstr,"+");
						buf1[0]='\0';
						strncat(prtstr, "00200000" ,10);
						tot_mcoverage+=200000;
						
						prtstr[125]='\0';
						
						/*20*/
						strcat(prtstr,(tot_sum_mapp_cover_A00<0) ? "-" : "+");
						buf1[0]='\0';
						rfmtlong(tot_sum_mapp_cover_A00,"&&&&&&&&&&&&",buf1);
						strncat(prtstr,(buf1[0]=='\0') ? "000000000000" : buf1,12);
						prtstr[138]='\0';
						
						/*21*/
						strcat(prtstr,(tot_sum_mins_stl_A00<0) ? "-" : "+");
						buf1[0]='\0';
						rfmtlong(tot_sum_mins_stl_A00,"&&&&&&&&&&&&",buf1);
						strncat(prtstr,(buf1[0]=='\0') ? "000000000000" : buf1,12);
						prtstr[151]='\0';
						/*22*/
						strcat(prtstr,(tot_sum_mins_proc_A00<0) ? "-" : "+");
						buf1[0]='\0';
						rfmtlong(tot_sum_mins_proc_A00,"&&&&&&&&&&",buf1);
						strncat(prtstr,(buf1[0]=='\0') ? "0000000000" : buf1,10);
						prtstr[162]='\0';
						
						/*23 */
						strcat(prtstr,(tot_sum_mins_health_A00<0) ? "-" : "+");
						buf1[0]='\0';
						rfmtlong(tot_sum_mins_health_A00,"&&&&&&&&&&",buf1);
						strncat(prtstr,(buf1[0]=='\0') ? "0000000000" : buf1,10);
						prtstr[173]='\0';
						
						/*24 ���O�I�ơB���B*/
						strcat(prtstr,(tot_sum_qhealth_A00<0) ? "-" : "+");
						buf1[0]='\0';
						rfmtlong(tot_sum_qhealth_A00,"&&&&&&&&",buf1);
						strncat(prtstr,(buf1[0]=='\0') ? "00000000" : buf1,8);
						prtstr[182]='\0';
						
						strcat(prtstr,(tot_sum_mhealth_A00<0) ? "-" : "+");
						buf1[0]='\0';
						rfmtlong(tot_sum_mhealth_A00,"&&&&&&&&",buf1);
						strncat(prtstr,(buf1[0]=='\0') ? "00000000" : buf1,8);
						prtstr[191]='\0';
						
						/*25*/
						strcat(prtstr,(tot_sum_all_A00<0) ? "-" : "+");
						buf1[0]='\0';
						rfmtlong(tot_sum_all_A00,"&&&&&&&&&&&&",buf1);
						strncat(prtstr,(buf1[0]=='\0') ? "000000000000" : buf1,12);
						prtstr[204]='\0';
						
						t_mcoverage = 200000;
						t_mapp_cover = tot_sum_mapp_cover_A00;
						t_mins_stl = tot_sum_mins_stl_A00;
						t_mins_proc = tot_sum_mins_proc_A00;
						t_mstl_health = tot_sum_mins_health_A00;
						t_qhealth = tot_sum_qhealth_A00;
						t_mhealth = tot_sum_mhealth_A00;
						t_sum_all = tot_sum_all_A00;
						
						/*26*/
						strcpy(dgroup_c,cm_cdate_str_100(dgroup));
						cm_split_ymd_100(dgroup_c,dgroup_yy,dgroup_mm,dgroup_dd);
						rfmtlong(atoi(dgroup_yy)+1911,"&&&&",dgroup_yy);
						strncat(prtstr,(dgroup_yy[0]=='\0') ? "0000" : dgroup_yy,4);
						strncat(prtstr,(dgroup_mm[0]=='\0') ? "00" : dgroup_mm,2);
						strncat(prtstr,(dgroup_dd[0]=='\0') ? "00" : dgroup_dd,2);
						prtstr[212]='\0';
						
						/*27 �q���O�N�� 2009.2�W�C�榡*/
						strcat(prtstr,bzfrom);
						strcpy(t_bzfrom,bzfrom);
						prtstr[214] = '\0';
						
						/*28 ��ƻs�e���*/
						strcat(prtstr,ttday_yy);
						strcat(prtstr,ttday_mm);
						strcat(prtstr,ttday_dd);
						strcpy(t_dsend,ttday_yy);
						strcat(t_dsend,ttday_mm);
						strcat(t_dsend,ttday_dd);
						prtstr[222]='\0';
						
						count1++;
						fprintf(fptr,"%s\n",prtstr);
						
						printf("data_yyyymm[%s],t_fend_yn[%s],t_fstl[%s],t_istl_recover[%s],t_ihealth[%s],t_dclaim[%s],t_iclm_company[%s],t_iclm_br[%s],t_iclaim[%s],t_iclose_type[%d] \n",
					            data_yyyymm,t_fend_yn,t_fstl,t_istl_recover,t_ihealth,t_dclaim,t_iclm_company,t_iclm_br,t_iclaim,t_iclose_type);
						printf("t_istl_flag[%s],t_dgroup[%s],t_icard_company[%s],t_icard_br[%s],t_icard[%s],t_dply_begin[%s],t_dply_end[%s]\n",
						        t_istl_flag,t_dgroup,t_icard_company,t_icard_br,t_icard,t_dply_begin,t_dply_end);
						printf("t_fvictim_nation[%s],t_ivictim[%s],t_dvictim_yy[%s],t_fvictim_sex[%s],t_fvictim_car[%s],t_fsubrogation[%s] \n",
						        t_fvictim_nation,t_ivictim,t_dvictim_yy,t_fvictim_sex,t_fvictim_car,t_fsubrogation);
						printf("t_iself_duty[%d],t_iins_item_1[%s],t_fhealth[%s],t_flast[%s],t_daccident[%s],t_iacc_area[%s],t_iply_area[%s],t_iacc_reason[%s] \n",
						        t_iself_duty,t_iins_item_1,t_fhealth,t_flast,t_daccident,t_iacc_area,t_iply_area,t_iacc_reason);
						printf("t_iins_item[%s],t_mcoverage[%d],t_mapp_cover[%d],t_mins_stl[%d],t_mins_proc[%d],t_mstl_health[%d],t_qhealth[%d],t_mhealth[%d],t_sum_all[%d] \n",
						        t_iins_item,t_mcoverage,t_mapp_cover,t_mins_stl,t_mins_proc,t_mstl_health,t_qhealth,t_mhealth,t_sum_all);
						printf("t_bzfrom[%s],t_dsend[%s] \n",
						        t_bzfrom,t_dsend);
			         	
			         	sprintf_s(stmt,4096,"INSERT INTO %s:ca_dev_clm_vic_comp \
			                                 (data_yyyymm,fend_yn,fstl,istl_recover,ihealth,dclaim,iclm_company,iclm_br,iclaim,iclose_type, \
					                          istl_flag,dgroup,icard_company,icard_br,icard,dply_begin,dply_end, \
					                          fvictim_nation,ivictim,dvictim_yy,fvictim_sex,fvictim_car,fsubrogation, \
					                          iself_duty,iins_item_1,fhealth,flast,daccident,iacc_area,iply_area,iacc_reason, \
					                          iins_item,mcoverage,mapp_cover,mins_stl,mins_proc,mstl_health,qhealth,mhealth,sum_all, \
					                          bzfrom,dsend) \
			                          VALUES(?,?,?,?,?,?,?,?,?,?, \
			                                 ?,?,?,?,?,?,?, \
			                                 ?,?,?,?,?,?, \
			                                 ?,?,?,?,?,?,?,?, \
			                                 ?,?,?,?,?,?,?,?,?, \
			                                 ?,?)",list[k].dbname);
						$PREPARE insert_clm_vic FROM $stmt;
						$EXECUTE insert_clm_vic using $data_yyyymm,$t_fend_yn,$t_fstl,$t_istl_recover,$t_ihealth,$t_dclaim,$t_iclm_company,$t_iclm_br,$t_iclaim,$t_iclose_type,
					                                  $t_istl_flag,$t_dgroup,$t_icard_company,$t_icard_br,$t_icard,$t_dply_begin,$t_dply_end,
					                                  $t_fvictim_nation,$t_ivictim,$t_dvictim_yy,$t_fvictim_sex,$t_fvictim_car,$t_fsubrogation,
					                                  $t_iself_duty,$t_iins_item_1,$t_fhealth,$t_flast,$t_daccident,$t_iacc_area,$t_iply_area,$t_iacc_reason,
					                                  $t_iins_item,$t_mcoverage,$t_mapp_cover,$t_mins_stl,$t_mins_proc,$t_mstl_health,$t_qhealth,$t_mhealth,$t_sum_all,
					                                  $t_bzfrom,$t_dsend;
					}
					else if (data_C > 0)
					{
						strcpy(prtstr,prtstr_1to14);
						printf("prtstr[%s]\n",prtstr);
						
						data_C = 0;
						
						/*17+18 */
						strncat(prtstr,"C000",4);
						strcpy(t_iins_item,"C0000");
						prtstr[116]='\0';
						
						/*19*/
						strcat(prtstr,(mcoverage<0) ? "-" : "+");
						buf1[0]='\0';
						rfmtlong(mcoverage,"&&&&&&&&",buf1);
						strncat(prtstr,(buf1[0]=='\0') ? "00000000" : buf1,8);
						prtstr[125]='\0';
						
						/*20*/
						strcat(prtstr,(sum_mapp_cover<0) ? "-" : "+");
						buf1[0]='\0';
						rfmtlong(sum_mapp_cover,"&&&&&&&&&&&&",buf1);
						strncat(prtstr,(buf1[0]=='\0') ? "000000000000" : buf1,12);
						prtstr[138]='\0';
						
						/* 21 */
						strcat(prtstr,(tot_sum_mins_stl_C00<0) ? "-" : "+");
						buf1[0]='\0';
						rfmtlong(tot_sum_mins_stl_C00,"&&&&&&&&&&&&",buf1);
						strncat(prtstr,(buf1[0]=='\0') ? "000000000000" : buf1,12);
						prtstr[151]='\0';
						
						/*22*/
						strcat(prtstr,(sum_mins_proc<0) ? "-" : "+");
						buf1[0]='\0';
						rfmtlong(sum_mins_proc,"&&&&&&&&&&",buf1);
						strncat(prtstr,(buf1[0]=='\0') ? "0000000000" : buf1,10);
						prtstr[162]='\0';
						
						/*23*/
						strcat(prtstr,(sum_mstl_health<0) ? "-" : "+");
						buf1[0]='\0';
						rfmtlong(sum_mstl_health,"&&&&&&&&&&",buf1);
						strncat(prtstr,(buf1[0]=='\0') ? "0000000000" : buf1,10);
						prtstr[173]='\0';
						
						/*24*/
						strcat(prtstr,(sum_qhealth<0) ? "-" : "+");
						buf1[0]='\0';
						rfmtlong(sum_qhealth,"&&&&&&&&",buf1);
						strncat(prtstr,(buf1[0]=='\0') ? "00000000" : buf1,8);
						prtstr[182]='\0';
						
						strcat(prtstr,(sum_mhealth<0) ? "-" : "+");
						buf1[0]='\0';
						rfmtlong(sum_mhealth,"&&&&&&&&",buf1);
						strncat(prtstr,(buf1[0]=='\0') ? "00000000" : buf1,8);
						prtstr[191]='\0';
						
						/*25*/
						strcat(prtstr,(tot_sum_all_C00<0) ? "-" : "+");
						buf1[0]='\0';
						rfmtlong(tot_sum_all_C00,"&&&&&&&&&&&&",buf1);
						strncat(prtstr,(buf1[0]=='\0') ? "000000000000" : buf1,12);
						prtstr[204]='\0';
						
						t_mcoverage = mcoverage;
						t_mapp_cover = sum_mapp_cover;
						t_mins_stl = tot_sum_mins_stl_C00;
						t_mins_proc = sum_mins_proc;
						t_mstl_health = sum_mstl_health;
						t_qhealth = sum_qhealth;
						t_mhealth = sum_mhealth;
						t_sum_all = tot_sum_all_C00;
						
						/*26*/
						strcpy(dgroup_c,cm_cdate_str_100(dgroup));
						cm_split_ymd_100(dgroup_c,dgroup_yy,dgroup_mm,dgroup_dd);
						rfmtlong(atoi(dgroup_yy)+1911,"&&&&",dgroup_yy);
						strncat(prtstr,(dgroup_yy[0]=='\0') ? "0000" : dgroup_yy,4);
						strncat(prtstr,(dgroup_mm[0]=='\0') ? "00" : dgroup_mm,2);
						strncat(prtstr,(dgroup_dd[0]=='\0') ? "00" : dgroup_dd,2);
						prtstr[212]='\0';
						
						/*27 �q���O�N�� 2009.2�W�C�榡*/
						strcat(prtstr,bzfrom);
						strcpy(t_bzfrom,bzfrom);
						prtstr[214] = '\0';
						
						/*28 ��ƻs�e���*/
						strcat(prtstr,ttday_yy);
						strcat(prtstr,ttday_mm);
						strcat(prtstr,ttday_dd);
						strcpy(t_dsend,ttday_yy);
						strcat(t_dsend,ttday_mm);
						strcat(t_dsend,ttday_dd);
						prtstr[222]='\0';
						
						count1++;
						fprintf(fptr,"%s\n",prtstr);
						
						printf("data_yyyymm[%s],t_fend_yn[%s],t_fstl[%s],t_istl_recover[%s],t_ihealth[%s],t_dclaim[%s],t_iclm_company[%s],t_iclm_br[%s],t_iclaim[%s],t_iclose_type[%d] \n",
					            data_yyyymm,t_fend_yn,t_fstl,t_istl_recover,t_ihealth,t_dclaim,t_iclm_company,t_iclm_br,t_iclaim,t_iclose_type);
						printf("t_istl_flag[%s],t_dgroup[%s],t_icard_company[%s],t_icard_br[%s],t_icard[%s],t_dply_begin[%s],t_dply_end[%s]\n",
						        t_istl_flag,t_dgroup,t_icard_company,t_icard_br,t_icard,t_dply_begin,t_dply_end);
						printf("t_fvictim_nation[%s],t_ivictim[%s],t_dvictim_yy[%s],t_fvictim_sex[%s],t_fvictim_car[%s],t_fsubrogation[%s] \n",
						        t_fvictim_nation,t_ivictim,t_dvictim_yy,t_fvictim_sex,t_fvictim_car,t_fsubrogation);
						printf("t_iself_duty[%d],t_iins_item_1[%s],t_fhealth[%s],t_flast[%s],t_daccident[%s],t_iacc_area[%s],t_iply_area[%s],t_iacc_reason[%s] \n",
						        t_iself_duty,t_iins_item_1,t_fhealth,t_flast,t_daccident,t_iacc_area,t_iply_area,t_iacc_reason);
						printf("t_iins_item[%s],t_mcoverage[%d],t_mapp_cover[%d],t_mins_stl[%d],t_mins_proc[%d],t_mstl_health[%d],t_qhealth[%d],t_mhealth[%d],t_sum_all[%d] \n",
						        t_iins_item,t_mcoverage,t_mapp_cover,t_mins_stl,t_mins_proc,t_mstl_health,t_qhealth,t_mhealth,t_sum_all);
						printf("t_bzfrom[%s],t_dsend[%s] \n",
						        t_bzfrom,t_dsend);
			         	
			         	sprintf_s(stmt,4096,"INSERT INTO %s:ca_dev_clm_vic_comp \
			                                 (data_yyyymm,fend_yn,fstl,istl_recover,ihealth,dclaim,iclm_company,iclm_br,iclaim,iclose_type, \
					                          istl_flag,dgroup,icard_company,icard_br,icard,dply_begin,dply_end, \
					                          fvictim_nation,ivictim,dvictim_yy,fvictim_sex,fvictim_car,fsubrogation, \
					                          iself_duty,iins_item_1,fhealth,flast,daccident,iacc_area,iply_area,iacc_reason, \
					                          iins_item,mcoverage,mapp_cover,mins_stl,mins_proc,mstl_health,qhealth,mhealth,sum_all, \
					                          bzfrom,dsend) \
			                          VALUES(?,?,?,?,?,?,?,?,?,?, \
			                                 ?,?,?,?,?,?,?, \
			                                 ?,?,?,?,?,?, \
			                                 ?,?,?,?,?,?,?,?, \
			                                 ?,?,?,?,?,?,?,?,?, \
			                                 ?,?)",list[k].dbname);
						$PREPARE insert_clm_vic FROM $stmt;
						$EXECUTE insert_clm_vic using $data_yyyymm,$t_fend_yn,$t_fstl,$t_istl_recover,$t_ihealth,$t_dclaim,$t_iclm_company,$t_iclm_br,$t_iclaim,$t_iclose_type,
					                                  $t_istl_flag,$t_dgroup,$t_icard_company,$t_icard_br,$t_icard,$t_dply_begin,$t_dply_end,
					                                  $t_fvictim_nation,$t_ivictim,$t_dvictim_yy,$t_fvictim_sex,$t_fvictim_car,$t_fsubrogation,
					                                  $t_iself_duty,$t_iins_item_1,$t_fhealth,$t_flast,$t_daccident,$t_iacc_area,$t_iply_area,$t_iacc_reason,
					                                  $t_iins_item,$t_mcoverage,$t_mapp_cover,$t_mins_stl,$t_mins_proc,$t_mstl_health,$t_qhealth,$t_mhealth,$t_sum_all,
					                                  $t_bzfrom,$t_dsend;
					}
				}

				/*���I���O�N��=Z*/
				strcpy(prtstr,prtstr_1to14);
				
				/*17+18 */
				strcat(prtstr,"Z000");
				strcpy(t_iins_item,"Z000");
				prtstr[116]='\0';

   				/*19*/
				strcat(prtstr,(tot_mcoverage<0) ? "-" : "+");
				buf1[0]='\0';
				rfmtlong(tot_mcoverage,"&&&&&&&&",buf1);
				strncat(prtstr,(buf1[0]=='\0') ? "00000000" : buf1,10);
				prtstr[125]='\0';
				
				/*20*/
				strcat(prtstr,(tot_sum_mapp_cover<0) ? "-" : "+");
				buf1[0]='\0';
				rfmtlong(tot_sum_mapp_cover,"&&&&&&&&&&&&",buf1);
				strncat(prtstr,(buf1[0]=='\0') ? "000000000000" : buf1,12);
				prtstr[138]='\0';
				
				/*21*/
				strcat(prtstr,(tot_sum_mins_stl<0) ? "-" : "+");
				buf1[0]='\0';
				rfmtlong(tot_sum_mins_stl,"&&&&&&&&&&&&",buf1);
				strncat(prtstr,(buf1[0]=='\0') ? "000000000000" : buf1,12);
				prtstr[151]='\0';
				
				/*22*/
				strcat(prtstr,(tot_sum_mins_proc<0) ? "-" : "+");
				buf1[0]='\0';
				rfmtlong(tot_sum_mins_proc,"&&&&&&&&&&",buf1);
				strncat(prtstr,(buf1[0]=='\0') ? "0000000000" : buf1,10);
				prtstr[162]='\0';
				
				/*23 */
				strcat(prtstr,(tot_sum_mins_health<0) ? "-" : "+");
				buf1[0]='\0';
				rfmtlong(tot_sum_mins_health,"&&&&&&&&&&",buf1);
				strncat(prtstr,(buf1[0]=='\0') ? "0000000000" : buf1,10);
				prtstr[173]='\0';
				
				/*24 */
				strcat(prtstr,(tot_sum_qhealth<0) ? "-" : "+");
				buf1[0]='\0';
				rfmtlong(tot_sum_qhealth,"&&&&&&&&",buf1);
				strncat(prtstr,(buf1[0]=='\0') ? "00000000" : buf1,8);
				prtstr[182]='\0';
				
				strcat(prtstr,(tot_sum_mhealth<0) ? "-" : "+");
				buf1[0]='\0';
				rfmtlong(tot_sum_mhealth,"&&&&&&&&",buf1);
				strncat(prtstr,(buf1[0]=='\0') ? "00000000" : buf1,8);
				prtstr[191]='\0';
				
				/*25*/
				strcat(prtstr,(tot_sum_all<0) ? "-" : "+");
				buf1[0]='\0';
				rfmtlong(tot_sum_all,"&&&&&&&&&&&&",buf1);
				strncat(prtstr,(buf1[0]=='\0') ? "000000000000" : buf1,12);
				prtstr[204]='\0';
				
				t_mcoverage = tot_mcoverage;
				t_mapp_cover = tot_sum_mapp_cover;
				t_mins_stl = tot_sum_mins_stl;
				t_mins_proc = tot_sum_mins_proc;
				t_mstl_health = tot_sum_mins_health;
				t_qhealth = tot_sum_qhealth;
				t_mhealth = tot_sum_mhealth;
				t_sum_all = tot_sum_all;
				
				/*26*/
				strcpy(dgroup_c,cm_cdate_str_100(dgroup));
				cm_split_ymd_100(dgroup_c,dgroup_yy,dgroup_mm,dgroup_dd);
				rfmtlong(atoi(dgroup_yy)+1911,"&&&&",dgroup_yy);
				strncat(prtstr,(dgroup_yy[0]=='\0') ? "0000" : dgroup_yy,4);
				strncat(prtstr,(dgroup_mm[0]=='\0') ? "00" : dgroup_mm,2);
				strncat(prtstr,(dgroup_dd[0]=='\0') ? "00" : dgroup_dd,2);
				prtstr[212]='\0';
				
				/*27 �q���O�N�� 2009.2�W�C�榡*/
				strcat(prtstr,bzfrom);
				strcpy(t_bzfrom,bzfrom);
				prtstr[214] = '\0';
				
				/*28 ��ƻs�e���*/
				strcat(prtstr,ttday_yy);
				strcat(prtstr,ttday_mm);
				strcat(prtstr,ttday_dd);
				strcpy(t_dsend,ttday_yy);
				strcat(t_dsend,ttday_mm);
				strcat(t_dsend,ttday_dd);
				prtstr[222]='\0';
				
				count1++;
				fprintf(fptr,"%s\n",prtstr);
				
				printf("data_yyyymm[%s],t_fend_yn[%s],t_fstl[%s],t_istl_recover[%s],t_ihealth[%s],t_dclaim[%s],t_iclm_company[%s],t_iclm_br[%s],t_iclaim[%s],t_iclose_type[%d] \n",
			            data_yyyymm,t_fend_yn,t_fstl,t_istl_recover,t_ihealth,t_dclaim,t_iclm_company,t_iclm_br,t_iclaim,t_iclose_type);
				printf("t_istl_flag[%s],t_dgroup[%s],t_icard_company[%s],t_icard_br[%s],t_icard[%s],t_dply_begin[%s],t_dply_end[%s]\n",
				        t_istl_flag,t_dgroup,t_icard_company,t_icard_br,t_icard,t_dply_begin,t_dply_end);
				printf("t_fvictim_nation[%s],t_ivictim[%s],t_dvictim_yy[%s],t_fvictim_sex[%s],t_fvictim_car[%s],t_fsubrogation[%s] \n",
				        t_fvictim_nation,t_ivictim,t_dvictim_yy,t_fvictim_sex,t_fvictim_car,t_fsubrogation);
				printf("t_iself_duty[%d],t_iins_item_1[%s],t_fhealth[%s],t_flast[%s],t_daccident[%s],t_iacc_area[%s],t_iply_area[%s],t_iacc_reason[%s] \n",
				        t_iself_duty,t_iins_item_1,t_fhealth,t_flast,t_daccident,t_iacc_area,t_iply_area,t_iacc_reason);
				printf("t_iins_item[%s],t_mcoverage[%d],t_mapp_cover[%d],t_mins_stl[%d],t_mins_proc[%d],t_mstl_health[%d],t_qhealth[%d],t_mhealth[%d],t_sum_all[%d] \n",
				        t_iins_item,t_mcoverage,t_mapp_cover,t_mins_stl,t_mins_proc,t_mstl_health,t_qhealth,t_mhealth,t_sum_all);
				printf("t_bzfrom[%s],t_dsend[%s] \n",
				        t_bzfrom,t_dsend);
	         	
	         	sprintf_s(stmt,4096,"INSERT INTO %s:ca_dev_clm_vic_comp \
	                                 (data_yyyymm,fend_yn,fstl,istl_recover,ihealth,dclaim,iclm_company,iclm_br,iclaim,iclose_type, \
			                          istl_flag,dgroup,icard_company,icard_br,icard,dply_begin,dply_end, \
			                          fvictim_nation,ivictim,dvictim_yy,fvictim_sex,fvictim_car,fsubrogation, \
			                          iself_duty,iins_item_1,fhealth,flast,daccident,iacc_area,iply_area,iacc_reason, \
			                          iins_item,mcoverage,mapp_cover,mins_stl,mins_proc,mstl_health,qhealth,mhealth,sum_all, \
			                          bzfrom,dsend) \
	                          VALUES(?,?,?,?,?,?,?,?,?,?, \
	                                 ?,?,?,?,?,?,?, \
	                                 ?,?,?,?,?,?, \
	                                 ?,?,?,?,?,?,?,?, \
	                                 ?,?,?,?,?,?,?,?,?, \
	                                 ?,?)",list[k].dbname);
				$PREPARE insert_clm_vic FROM $stmt;
				$EXECUTE insert_clm_vic using $data_yyyymm,$t_fend_yn,$t_fstl,$t_istl_recover,$t_ihealth,$t_dclaim,$t_iclm_company,$t_iclm_br,$t_iclaim,$t_iclose_type,
			                                  $t_istl_flag,$t_dgroup,$t_icard_company,$t_icard_br,$t_icard,$t_dply_begin,$t_dply_end,
			                                  $t_fvictim_nation,$t_ivictim,$t_dvictim_yy,$t_fvictim_sex,$t_fvictim_car,$t_fsubrogation,
			                                  $t_iself_duty,$t_iins_item_1,$t_fhealth,$t_flast,$t_daccident,$t_iacc_area,$t_iply_area,$t_iacc_reason,
			                                  $t_iins_item,$t_mcoverage,$t_mapp_cover,$t_mins_stl,$t_mins_proc,$t_mstl_health,$t_qhealth,$t_mhealth,$t_sum_all,
			                                  $t_bzfrom,$t_dsend;
				
				prem_total+=check_sum_all;
				health_total+=check_sum_health;
			}
			$CLOSE car9999_3;
			$FREE car9999_3;
		}
		$CLOSE car9999_1;
		$FREE car9999_1;
	}
	fclose(fptr);

	res = getApHome(aphome);
	if (res<0) {
		printf("In sigalrmcatcher func==>read config file error!!\n");
		exit(1);
	}

	if(count1==0) fprintf(fptr_err,"%s\n","�L���!!");
	else
	{
		$SELECT iquota INTO $iquota FROM officer WHERE iofficer=$userid;
		rtoday(&Today);
		printf("### Today[%d],DBName[%s],prem_total[%d],health_total[%d],count1[%d]\n",Today,DBName,prem_total,health_total,count1);
		strcpy(Taipei_FullName,get_full_dbname("00"));
		
		$WHENEVER SQLERROR CONTINUE;
		
		sprintf_s(stmt,4096,"DELETE FROM %s:ca_develop \
		               WHERE iclass='9999' AND ibranch=? AND data_yyyymm = ? ",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus1 FROM $stmt;
		$EXECUTE insert_cus1 USING $DBName,$data_yyyymm;
		
		$WHENEVER SQLERROR GOTO errexit;
		
		sprintf_s(stmt,4096,"INSERT INTO %s:ca_develop \
		                     (iquota,data_yyyymm,iclass,dsend,ibranch,product_kind,iins_class,mprem,mhealth,qcnt,mdrunk_pure_prem) \
		              VALUES (?,?,'9999',?,?,'99','C',?,?,?,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus2 FROM $stmt;
		$EXECUTE insert_cus2
		USING $iquota,$data_yyyymm,$Today,$DBName,$prem_total,$health_total,$count1;
	}
	
	return SUCCESS;

errexit:
  printf("usrid=%s SOLCODE=%d sqlca.sqlerrm=%s\n",userid,SQLCODE,sqlca.sqlerrm);
  sprintf_s(errmsg,200,"userid=%s SOLCODE=%d sqlca.sqlerrm=%s",userid,SQLCODE,sqlca.sqlerrm);
  fprintf(fptr_err,"%s\n",errmsg);
  return SQLCODE;
}

long car9999_final()
{
	char sTmpMsg[1024];
	$char sfilename[81],stitle[1024],stmt[1024];
	$char DBName1[5];
	$long mprem, mhealth, qcnt;
	$char product_kind[3];
    
	$WHENEVER SQLERROR GOTO errexit;
	
	strcpy(DBName1,"00");
	if (db_select(DBName1) == False)  return M_CM_DB_NOTOPEN;
	
	$SELECT sum(mprem), sum(qcnt), sum(mhealth)
	   INTO $mprem, $qcnt, $mhealth
	   FROM ca_develop
	  WHERE iclass = '9999' AND product_kind = '99'
	    AND data_yyyymm  = $data_yyyymm;

	sprintf_s(sTmpMsg,1024, "%s%s\n", "���ɧ���:", file_catalog);
	sprintf_s(sTmpMsg,1024, "%s�O�O=[%d] ���O���B=[%d] ����=[%d]\n",sTmpMsg, mprem, mhealth, qcnt );
	
	/*29�I���p�p����*/
	sprintf_s(stmt,1024,"SELECT product_kind, sum(mprem), sum(qcnt), sum(mhealth) \
	                FROM ca_develop \
	               WHERE iclass = '9999' AND product_kind <> '99' AND data_yyyymm = '%s' \
	               GROUP BY product_kind ",data_yyyymm);
	$PREPARE pre_29_kind1 FROM $stmt;
	$DECLARE cur_29_kind2 CURSOR FOR pre_29_kind1;
	$OPEN cur_29_kind2;
	while (1)
	{
		$FETCH cur_29_kind2 INTO $product_kind ,$mprem, $qcnt, $mhealth;
		if (SQLCODE == SQLNOTFOUND) break;
		sprintf_s(sTmpMsg,1024, "%s�I��=[%s] �O�O=[%d] �«O�O=[%d] ����=[%d]\n",sTmpMsg, product_kind, mprem, mhealth, qcnt );
	}

	EWRITE(userid, M_CM_OK, sTmpMsg);
	exit(SUCCESS);
	isfinish(rtncode);

errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}
