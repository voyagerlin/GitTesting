/************************************************/
/*                                              */
/*   PROGRAM : car173m01s.ec			*/
/*   Author  : 061476   			*/
/*   Date    : 2021/05/14			*/
/*   Name    : ���N�I����O�q���O���ƺ��@     */
/*                                              */
/************************************************/
     
#include <stdio.h>
#include <stdlib.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "carmsgs.h"
#include "ISvar.h"
#include "cmnmsgs.h"
#include "safeclib.h"

int *iGetChinesePos();

time_t tstart;
float  tused=0;
long   msg_code;

/*********************************************************************/
long car173(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 	long rtncode;
 	long car173_query(),car173_update(),car173_check302();
 	char option;
 	msg_code = 0;

 	cm_buf_init_x(command);
 	cm_buf_get("%c",&option);

 	switch(option)
 	{
  		case 'A':
           		rtncode=car173_check302(reply);
           		break;
  		case 'Q':
           		rtncode=car173_multiple_query(reply);
           		break;
           	case 'U':
           		rtncode=car173_update(reply,command,com_len);
           		break;
  		default :
           	if (exitsub(reply,M_CM_WRONG_OPTION) == True)
              	return M_CM_WRONG_OPTION;
           	return apiRC;
 	}
 	return(rtncode);
}
/*********************************************************************/
long car173_check302(reply)
{
    int    tmp_len;
    $char  DBName[DBNAME], userid[11];
    $char  dyy[4], dmm[3], dyymm[6];
    $char  dyymm_next[6];
    $int   cnt1=0,cnt2=0,cnt3=0;

    cm_buf_get("%s %s %s %s", DBName, userid, dyy, dmm);
    
    $WHENEVER SQLERROR GOTO errexit;
    
    if(db_select(DBName) == False)
	    return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    sprintf_s(dyymm, sizeof dyymm, "%s%s", dyy, dmm); /* ����~��(11005) */
	
    $SELECT count(*) INTO $cnt1
       FROM car_code 
      WHERE kind = 'RN' AND detail = 'car302' 
        AND chiname = 'Y' AND detail2 = $dyymm;
    
    if (SQLCODE == SQLNOTFOUND) cnt1 = 0;
    
    $SELECT count(*) INTO $cnt2
       FROM car_code 
      WHERE kind = 'RN' AND detail = 'car173' 
        AND detail2 = '1';
    
    if (SQLCODE == SQLNOTFOUND) cnt2 = 0;

    /*�Y��J����U�@�Ӥ몺��O��Ƥw�}��A�h���i�A���@��J��������*/
    if(strcmp(dmm,"12")==0)
        sprintf_s(dyymm_next, sizeof dyymm_next,"%s01",itoa(atoi(dyy)+1));
    else
        sprintf_s(dyymm_next, sizeof dyymm_next,"%s",itoa(atoi(dyymm)+1));
    
    $SELECT count(*) INTO $cnt3
       FROM car_code 
      WHERE kind = 'RN' AND detail = 'car302' 
        AND chiname = 'Y' AND detail2 = $dyymm_next;
    
    if (SQLCODE == SQLNOTFOUND) cnt3 = 0;
    
    
    cm_buf_init(ReplyBuf);
    cm_buf_put("%d %d %d", cnt1, cnt2, cnt3);
    
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False) 
        return apiRC;
    else 
        return api_OKComplete;

errexit:
  	if (exitsub(reply,SQLCODE) == True) 
     	    return SQLCODE;
  	else  
     	    return apiRC;
}
/*********************************************************************/
long car173_multiple_query(reply)
serverReply reply;
{
	/* standard defined host variables */
	$char DBName[DBNAME], userid[11];
	/* end of standard host var */
	
	/* define table fields */
	$char dyy[4], dmm[3], iofficer_in[11], iroute_in[21], ileader_in[11], fprint_Y[2], fprint_N[2];
	$int  iplyyear, iplymonth;
	$char tmp_col[10], data_tmp[16], sdate1[11], sdate2[11];
	$char stmt[4096], stmt1[800], stmt2[64], stmt3[64],
	      stmt_officer[64], stmt_route[64], stmt_leader[64];
	$char iofficer[11], nofficer[11], iroute[21], nroute[41], sNroute[20], ipolicy[21], itag[CA_TAG_NUM], 
	      nassured[121], sNassured[20], icar_type[3], dply_begin[11], nremark[256], 
	      sNremark[65], fprint[2], frenew_status[2], freason_reject[2], nStatus[5];
 	int   iTmp=0;
	/* end of define */
	
	/* standard defined data */
	int   ttlen;
	/***********long  rc;**************/
	long  lnRecCountMain;
	int   rtcode = 0;
	char  sFileName[50];
	int   nMode;
	int   iTmpLen;
	/* end of standard data */

	cm_buf_get("%s %s", DBName, userid);
	cm_buf_get("%s %s %s %s %s %s %s", dyy, dmm, iofficer_in, iroute_in, ileader_in, fprint_Y, fprint_N);
 
 	$WHENEVER SQLERROR GOTO errexit;
 		
 	if(db_select(DBName) == False)
	    return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
 	
 	/* onload�{���|���P�ɦh�H����Atemp table�ݯS���R�W */
 	$select first 1 to_char(current,'car%H%M%S') into $tmp_col from systables;
 	strcpy(tmp_col,trim(tmp_col));
 	strcpy(data_tmp,tmp_col);
 	strcat(data_tmp,userid);
 	strcpy(data_tmp,trim(data_tmp));
 	
 	sprintf_s(stmt1, sizeof stmt1,"create temp table %s (         \n"
 	               " iofficer        char(10),     \n"
 	               " nofficer        char(10),     \n"
 	               " iroute          varchar(20),  \n"
 	               " nroute          varchar(40),  \n"
 	               " ipolicy         char(20),     \n"
 	               " itag            char(12),     \n"
 	               " nassured        varchar(120), \n"
 	               " icar_type       char(2),      \n"
 	               " dply_begin      date,         \n"
 	               " nremark         varchar(255), \n"
 	               " frenew          char(1),      \n"
 	               " frenew_status   char(1),      \n"
 	               " freason_reject  char(1)       \n"
 	               " )with no log;      \n", data_tmp );
 	             
        $prepare pre_tbl from $stmt1;
        $execute pre_tbl;
        
        sprintf_s(stmt2, sizeof stmt2,"DROP TABLE %s;",data_tmp );
        $prepare dt_tbl FROM $stmt2;
	
	strcpy(dyy,trim(dyy));
	iplyyear = atoi(dyy);
	iplyyear += 1911;
	iplymonth = atoi(dmm);
	
	/* �̰_���~���_����� */
	$select first 1 MDY($iplymonth,'01',$iplyyear),add_months(MDY($iplymonth,'01',$iplyyear),1)-1
	   into $sdate1, $sdate2
	   from car_code;
 		
 	/*****************************************************/
 	ttlen=0;
 	
 	cm_buf_init_x(ReplyBuf);
 	cm_buf_res_msg_x();
 	cm_buf_res_count_x();        /* for transfer mode code */
 	cm_buf_res_count_x();        /* for table count */
 	cm_buf_res_count_x();        /* for record count */
 	
 	cm_buf_res_string_x(50);
 	
 	time(&tstart);
 	$set lock mode to wait 5;
 	lnRecCountMain = 0;   
 	/*****************************************************/    	 		
 	if (strcmp(iofficer_in,"*") == 0)
		sprintf_s(stmt_officer, sizeof stmt_officer, " " );
	else
		sprintf_s(stmt_officer, sizeof stmt_officer, " AND a.iofficer = '%s' ", iofficer_in );
	
	if (strcmp(iroute_in,"*") == 0)
		sprintf_s(stmt_route, sizeof stmt_route, " " );
	else
		sprintf_s(stmt_route, sizeof stmt_route, " AND a.iroute = '%s' ", iroute_in );
	
	if (strcmp(ileader_in,"*") == 0)
		sprintf_s(stmt_leader, sizeof stmt_leader, " " );
	else
		sprintf_s(stmt_leader, sizeof stmt_leader, " AND a.ileader = '%s' ", ileader_in );
 	 	
 	sprintf_s(stmt, sizeof stmt, " INSERT INTO %s \n"
                       " SELECT a.iofficer, b.nname, a.iroute, c.nroute, a.ipolicy,               \n"
                       "        a.itag, a.nassured, a.icar_type, a.dply_begin, a.nremark_reject,  \n"
                       "        case when a.freason_reject in ('P','7','9','B','Y','Z') then 'N' else 'Y' end, \n"
                       "        nvl(d.frenew_status,''), a.freason_reject                   \n"
                       "   FROM policy_302 a, officer b, cm_route c, outer ca_no_renew d    \n"
                       "  WHERE a.iofficer = b.iofficer AND a.iroute = c.iroute             \n"
                       "    AND a.ipolicy = d.ipolicy AND a.freason_reject <> ''            \n"
                       "    AND fcard_class = '2' AND a.dply_begin between '%s' and '%s'    \n"
                       "    AND a.iofficer[1] not in ('N','W')                              \n"
                       "  %s %s %s \n", data_tmp, sdate1, sdate2, stmt_officer, stmt_route, stmt_leader );       
        $PREPARE inset_tmp1 FROM $stmt;
 	$EXECUTE inset_tmp1;
 	
 	sprintf_s(stmt, sizeof stmt, " INSERT INTO %s \n"
                       " SELECT distinct a.iofficer, a.nofficer, a.iroute, a.nroute, a.ipolicy,   \n"
                       "        a.itag, a.nassured, a.icar_type, a.dply_end, a.remark_reject,     \n"
                       "        a.frenew, nvl(b.frenew_status,''), a.freason                      \n"
                       "   FROM sysdb:car_renew_msg a, OUTER ca_no_renew b                  \n"
                       "  WHERE a.ipolicy = b.ipolicy AND a.err_no in ('E40','E56','E57')   \n"
                       "    AND a.dply_end between '%s' and '%s'                            \n"
                       "    AND a.iofficer[1] not in ('N','W')                              \n"
                       "  %s %s %s \n", data_tmp, sdate1, sdate2, stmt_officer, stmt_route, stmt_leader );       
        $PREPARE inset_tmp2 FROM $stmt;
 	$EXECUTE inset_tmp2;
 			
	if ((strcmp(fprint_Y,"1") == 0) && (strcmp(fprint_N,"0") == 0)){
		sprintf_s(stmt3, sizeof stmt3, " AND frenew = 'Y' " );
	}
	else if ((strcmp(fprint_Y,"0") == 0) && (strcmp(fprint_N,"1") == 0)){
		sprintf_s(stmt3, sizeof stmt3, " AND frenew = 'N' " );
	}
	else{
		sprintf_s(stmt3, sizeof stmt3, " " );
	}
 	  		
 	sprintf_s(stmt, sizeof stmt, " SELECT * FROM %s WHERE 1=1 %s order by iofficer, ipolicy; \n",data_tmp,stmt3);  	 
        $PREPARE cur_cursor FROM $stmt;
        $DECLARE cur_main CURSOR FOR cur_cursor;
        $OPEN cur_main;        
        while(1)
        {
        	EXEC SQL FETCH cur_main 
        	INTO $iofficer, $nofficer, $iroute, $nroute, $ipolicy, 
        	     $itag, $nassured, $icar_type, $dply_begin, $nremark, 
        	     $fprint, $frenew_status, $freason_reject;
 	        
 	        if (SQLCODE == SQLNOTFOUND) break;

 	        strcpy(iofficer,         trim(iofficer));
 	        strcpy(nofficer,         trim(nofficer));
 	        strcpy(iroute,           trim(iroute));
 	        
 	        iTmp = iGetChinesePos(nroute,14);
 	        strcpy(sNroute,"");
 	        strncpy(sNroute,nroute,iTmp+1);
 	        sNroute[iTmp+1] = '\0';
 	        strcpy(sNroute,          trim(sNroute));
 	        
 	        strcpy(ipolicy,          trim(ipolicy));
 	        strcpy(itag,             trim(itag));
 	        
 	        iTmp = iGetChinesePos(nassured,14);
 	        strcpy(sNassured,"");
 	        strncpy(sNassured,nassured,iTmp+1);
 	        sNassured[iTmp+1] = '\0';
 	        strcpy(sNassured,        trim(sNassured));
 	        
 	        strcpy(icar_type,        trim(icar_type));
 	        strcpy(dply_begin,       trim(dply_begin));
 	        
 	        if (strcmp(freason_reject,"7") == 0)
	            	strcpy(sNremark,     "�Ь��֫Ocar102�d��");
	        else
	        {
	        	iTmp = iGetChinesePos(nremark,60);
	        	strcpy(sNremark,"");
	        	strncpy(sNremark,nremark,iTmp+1);
	        	sNremark[iTmp+1] = '\0';
	        	strcpy(sNremark,     trim(sNremark));
 	        }
 	        
 	        /*strcpy(fprint,           trim(fprint));*/
 	        
 	        strcpy(frenew_status,    trim(frenew_status));
 	        if (strcmp(frenew_status,"Y") == 0)
 	        	strcpy(nStatus,"���H");
 	        else if (strcmp(frenew_status,"N") == 0)
 	        	strcpy(nStatus,"�H");
 	        else 
 	        	strcpy(nStatus," ");
 	        

 	        rtcode = cm_buf_put_x("%s %s %s %s %s %s %s %s %s %s %s",
 	                 nStatus, iofficer, nofficer, iroute, sNroute, ipolicy, itag, sNassured,
 	                 icar_type, dply_begin, sNremark);
 	        	        
 	        if(rtcode == M_CM_FILE_OVERFLOW)
 	        {
 	        	return exitsub(reply, M_CM_FILE_OVERFLOW) ? M_CM_FILE_OVERFLOW : apiRC;
 	        }
 	        
 	        lnRecCountMain++;
        }
        $CLOSE cur_main;
        $FREE cur_main;
        
        /* 1 New function to put record count on file begin 
        cm_buf_put_count_x(lnRecCount);*/
        
        printf("System use second is: %f\n", tused);
        printf("msg_code[%d]\n", msg_code);
        /* 1 New function write the lastest data to file and close it*/
        cm_buf_end_x();
        
        /* 1 New function to get file name */
        strcpy(sFileName, cm_get_ftp_filename());
        printf("transfer file name : [%s]\n", sFileName);
        
        /* 1 New function to get transfer mode */
        nMode = cm_get_mode();
        printf("transfer mode : nMode=[%d]\n", nMode);
        
        printf("record count[%ld] \n", lnRecCountMain);
        /* Message Code */
        if (lnRecCountMain == 0)
        {
        	cm_buf_put_msg(M_CM_NOT_FOUND);
        }
        else
        {
        	cm_buf_put_msg(M_CM_OK);
        	
        	/* Transfer mode */
        	cm_buf_put_count_seq(1, (long)nMode);
        	/* Table Count */
        	cm_buf_put_count_seq(2, 1L);
        	/* RecCount */
        	cm_buf_put_count_seq(3, lnRecCountMain);
        	/* 1 New function for file name */
        	cm_buf_put_string_x(sFileName);
        }
        iTmpLen = cm_buf_len(ReplyBuf);
        
        printf("drop table data_tmp[%s]\n",stmt1);
        $EXECUTE dt_tbl;
        
        if(SendSyncReply(reply, ReplyBuf, iTmpLen, api_OKComplete) == False)
            return apiRC;
        
        return api_OKComplete;
     
errexit:
  	$EXECUTE dt_tbl;
  	printf("errexit�Gdrop table data_tmp\n"); 
  	if (exitsub(reply,SQLCODE) == True) 
     	return SQLCODE;
  	else  
     	return apiRC;
}
/*********************************************************************/
long car173_update(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	/* standard defined host variables */
	$char DBName[DBNAME], userid[11];
	/* end of standard host var */
	$char fstatus[2], ipolicy[21];
	$char stmt_buf[400];
	$int  cnt=0;
	/* define table fields */
	
	/* end of define */
	
	/* standard defined data */
	char  *comm;
	long  MsgCode;
	int   tmp_len;
	long  lnBufLen;
	char  *pBuf;
	int   k,rows=0; 
	/* end of standard data */
	
	pBuf = NULL;	
	/*cm_buf_init(command); */
	
	cm_buf_get("%s",DBName);
	lnBufLen = cm_ftp_init_x(&pBuf);
	
	$WHENEVER SQLERROR GOTO errexit;
		
	if(db_select(DBName) == False)
	    return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
	
	$BEGIN WORK;
	
	cm_buf_get("%d %s %s", &rows, fstatus, userid);
	
	for (k = 0; k <rows; k++)
	{
		cm_buf_get("%s", ipolicy);
				
		/* update ��� */
		/* update�e���T�{�ӵ���ƥ��Q���� (1091021005_SC6) */
		strcpy(fstatus,        trim(fstatus));
		
		sprintf_s(stmt_buf, sizeof stmt_buf,
			" select count(*) from ca_no_renew WHERE ipolicy = '%s' ",ipolicy);
				        
		$PREPARE cnt_tab FROM $stmt_buf;
		$EXECUTE cnt_tab INTO $cnt;
				
		if (cnt == 0){
			/* �s�W */
			$INSERT INTO ca_no_renew
				(ipolicy, frenew_status, icreate, dcreate, iupdate)
			VALUES
				($ipolicy, $fstatus, $userid, current, '');
		}else{
			/* �� */
			sprintf_s(stmt_buf, sizeof stmt_buf,
			        " UPDATE ca_no_renew                                \n"
			        "    SET (ipolicy, frenew_status, iupdate, dupdate) \n"
			        "      = ('%s','%s','%s',current)                   \n"
			        "  WHERE ipolicy = '%s';                            \n"
			        ,ipolicy,fstatus,userid,ipolicy); 
		        
		        $PREPARE up_status FROM $stmt_buf;
		        $EXECUTE up_status;
		}		
		if (SQLCODE != 0) goto errexit;
				
		if (sqlca.sqlerrd[2]==0){ /* �S����ƳQ��� */		
			SQLCODE=3524;
			goto errexit;
		}			
	}
	
	printf("after Updating ........\n");
	if (pBuf != NULL) free(pBuf);
	
	cm_buf_init(ReplyBuf);
	cm_buf_put("%l",M_CM_OK);
	tmp_len = cm_buf_len(ReplyBuf);
	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
	{
		printf("after SendSyncReply = false........\n");      	
		$WHENEVER SQLERROR CONTINUE;
		$ROLLBACK WORK;
		return apiRC;
	}
	printf("after SendSyncReply  ........\n");      	
	$WHENEVER SQLERROR GOTO errexit;
	$COMMIT WORK;
	return api_OKComplete;

 errexit:
    MsgCode = SQLCODE;
    printf("go to errexit[%d]\n",SQLCODE);
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;              /* rollback fail */
    if(SQLCODE != 0) MsgCode = SQLCODE;
    if(exitsub(reply,MsgCode) == True)
        return MsgCode;
    else
        return apiRC;
}
/*********************************************************************/
/*  ���o���^���q�������T���嵲����m                                 */
/*********************************************************************/
int *iGetChinesePos(sStrTmp,iPos)
char *sStrTmp;
int  iPos;
{
   int  iTrueLen;
   int  i,x;

   for(i = 0; i<= iPos; i++){
         if ((int)(sStrTmp[i]) >= 128){
                i++;
         }
   }
   return (i-1);
}