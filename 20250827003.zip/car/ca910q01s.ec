  /**********************************************************************/
/*                                                                    */   
/*   program id   : ca910q01s.ec                                      */
/*   program name : �����I�߮ש��Ӫ�                                */
/*   date written : 2003/11/13                                        */
/*   date modify  :                                                   */
/**********************************************************************/
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
#include <time.h>
#include "safeclib.h"

/*--------------------------------------------------------------------*/
DBinfo  *list;
int  count_db, i;
int count;
 
 char  tmp_buf[16];
 float tused=0;
 time_t tstart,tstop;
 int fetch;

/* ca_clm_process */ 
$char iclaim_area[3],iclaim[21],ipolicy[21];
$char dclaim[11],dclose[11],ibranch_in[3],idanger[2],assign[2];
$char branch_server[3];

/* ply_relation */
$char iquota[7],iofficer[11],dply_begin[11],dpolicy[11];
$char iadjuster[11],iacc_reason[3],iins_type[INSURANCE_TYPE];
$char inspect[2],claim_class[2];
$char daccident[17];
$long mins_stl,mins_app,mins_app_total;
$char nequipment[2],fclose1[2];

$char dbgn1[11],dend1[11];
$char dbgn2[11],dend2[11];
$char high_risk[2],great_claim[2],scene_accredit[2];
$char stmt_buf[5000];
$char wherestr[500],wherestr1[100];
$char poldbname[50],clmdbname[50];
$char DBName[05], iForm_Tp[03];
$char ibranch_abbr[2];
$char Fcard_class[2];
$char iins_type_str[100], fclose_str[50];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1];
char  outputf[N_FILE+1], userid[11];

char  msgbuf[100];
$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;

static int  max_cnt,num;
static char *get_car_full_db();  /*   �ǤJ�O�渹��X���O�檺�k�ݸ��*/
long car910_get_db();
long car910_build();
void car910_title();
long car910_body();
long car910_print();

/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{  
	
   $WHENEVER SQLERROR GOTO errexit;
   int rc;
   batchinit();
   strcpy(DBName, isNULLstr(argv[1]));
   strcpy(userid, isNULLstr(argv[2]));
   
   strcpy(dbgn2, isNULLstr(argv[3]));
   strcpy(dend2, isNULLstr(argv[4]));
   strcpy(high_risk, isNULLstr(argv[5]));
   strcpy(great_claim, isNULLstr(argv[6]));
   strcpy(scene_accredit, isNULLstr(argv[7]));
   strcpy(branch_server, isNULLstr(argv[8]));

   strcpy(outputf,isNULLstr(argv[9]));

   strcpy(dbgn1, cm_to_infdate(dbgn2));
   strcpy(dend1, cm_to_infdate(dend2));  

   rc = car910_get_db();
    if (rc != SUCCESS)
       return rc;

   max_cnt=0;
   rc = car910_build();
   if ( rc != FAIL){
    if ((rc=save_form_info(F_BLK1, "CA", 910, userid, iForm_Tp, max_cnt, outputf))<0)
     {
        strcpy(msgbuf,"save_form_info failed");
        return rc;
            
   
     }

   
    }
}
/*--------------------------------------------------------------------*/

long car910_build()
{
   $char  TitleFmt[N_FILE+1],BodyFmt[N_FILE+1];
   int    rc;
     $WHENEVER SQLERROR GOTO errexit;  

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 910;

   strcpy( TitleFmt,rtrim(TitleFmt));
   strcpy( BodyFmt,rtrim(BodyFmt));
   sprintf_s( TitleFile, N_FILE+1,"%s.ti",outputf);
   sprintf_s( BodyFile, N_FILE+1,"%s.bd",outputf);

printf("titlefmt = [%s]\n",TitleFile);

   rgu_init_report(TitleFmt,TitleFile);
   car910_title();
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);
   rc = car910_body();
   if (rc != M_CM_OK)
       return rc;



printf( " next is M_CM_OK \n");           
   return M_CM_OK;

errexit:
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;  
}

   
long car910_get_db()
{
        
   
   $WHENEVER SQLERROR GOTO errexit;  
   
   if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }
    
   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   return SUCCESS;

errexit:

   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

void car910_title()
{
  rgu_put_head_string(1,dbgn1);
  rgu_put_head_string(1,dend1); 
  rgu_put_head_string(1,cm_get_sysd()); 
  rgu_put_head();

}


long car910_body()
{
	int ins; 
	int rc;
	int iins_count_flag;

	$WHENEVER SQLERROR GOTO errexit;    

/*    rgu_put_body_string(1, dbgn1,1);
    rgu_put_body_string(1, dend1,1);
    rgu_put_body_string(1, cm_get_sysd(), 1);
    rgu_put_body(1);
*/
 /*   $set explain on;   */
	/**************************************/
	/*   �����I�߮�  :high_risk           */
	/*   ���j�߮�    :great_claim         */
	/*   �{�����v�߮�:scene_accredit      */
	/*       Copyright 2007.4 Max         */
	/**************************************/
	time(&tstart);
	mins_stl=mins_app=0;
	strcpy(wherestr,"");
	if (strcmp(high_risk,"1") == 0)
	{
		strcat(wherestr," and (idanger <> ' ' ");
	}
	if (strcmp(great_claim,"1") == 0)
	{
		if (strcmp(high_risk,"1") == 0)
		{
			strcat(wherestr," or assign = '1' ");
		}
		else
		{
			strcat(wherestr," and (assign = '1' ");
		}
	}
	if (strcmp(scene_accredit,"1") == 0)
	{
		if ((strcmp(high_risk,"1") == 0) || (strcmp(great_claim,"1") == 0))
		{
			strcat(wherestr, "or assign = '2' ");
		}
		else
		{
			strcat(wherestr," and (assign = '2' ");
		}
	}
	strcat(wherestr,") ");
	
	/************************************/
	/*     ��ܽ߮׳�����             */
	/*       Copyright 2007.4 Max       */
	/************************************/
	if (strcmp(branch_server,"AA") == 0)
	{
		/*strcat(wherestr,"");*/
		/*do nothing*/
	}
	else
	{
		/* CBUG20111 DECLARE�L�kEXECUTE */
		$SELECT ibranch_abbr
		   INTO $ibranch_abbr
		   FROM branch
		  WHERE ibranch = $branch_server;
		sprintf_s(wherestr1,100," and iclaim[3,3] = '%s' ",ibranch_abbr);
		strcat(wherestr,wherestr1);
	}
/* �i�H������ ca_clm_process ���w����Y�鵲��ӧP�_�N�i�H�F */
	sprintf_s(stmt_buf,5000,
            "select iclaim[1,2],iclaim,ipolicy,      \
                    dclaim,dclose,ibranch_in,        \
                    idanger, assign                          \
             from ca_clm_process                   \
             where dclaim >= '%s' and dclaim <= '%s'\
              %s ",dbgn1,dend1,wherestr);
	printf("stmt[%s]\n",stmt_buf);
	EXEC SQL PREPARE Acursor  FROM :stmt_buf;
	EXEC SQL DECLARE Acursor1 CURSOR FOR Acursor;
	EXEC SQL OPEN Acursor1;
	while (1)
	{
		EXEC SQL FETCH Acursor1 INTO :iclaim_area,:iclaim,:ipolicy,
                                     :dclaim,:dclose,:ibranch_in,
                                     :idanger,:assign;

		strcpy(inspect," ");
		strcpy(claim_class," ");

		if (SQLCODE == SQLNOTFOUND)
		{   break; }
            
/*        strcpy(poldbname,get_full_dbname(ibranch_in));*/
		strcpy(poldbname,get_car_full_db(ipolicy));
		sprintf_s(stmt_buf,5000,
                "SELECT  a.iquota[1,4]||'00',a.iofficer,a.dply_begin, \
                         a.dpolicy,b.nequipment[1]                \
                 FROM  %s:ply_relation a,%s:policy b  \
                 WHERE  a.ipolicy = '%s'                 \
                 AND  a.ipolicy = b.ipolicy ",poldbname,poldbname,ipolicy );
		printf(" stmt_buf [%s]\n",stmt_buf);
		$PREPARE curply FROM $stmt_buf;
		$EXECUTE curply INTO $iquota,$iofficer,$dply_begin,
                             $dpolicy,$nequipment;
        
		strcpy(clmdbname,get_car_full_db(ipolicy));
         
		sprintf_s(stmt_buf,5000,
                "SELECT  iadjuster,iacc_reason,daccident,inspect,claim_class,fcard_class    \
                 FROM  %s:appraisal                       \
                 WHERE  iclaim = '%s'  ",clmdbname,iclaim );
		printf(" stmt_buf [%s]\n",stmt_buf);
		$PREPARE curclm FROM $stmt_buf;
		$EXECUTE curclm INTO $iadjuster,$iacc_reason,$daccident,$inspect,$claim_class,$Fcard_class;
             
		if (Fcard_class[0]=='2')
		{
			sprintf_s(stmt_buf,5000,
                    "SELECT  iins_type,mins_app,fclose      \
                     FROM  %s:app_ins_type                \
                     WHERE  iclaim = '%s'  ",clmdbname,iclaim );     
			printf(" stmt_buf [%s]\n",stmt_buf);

		}
		else
		{
			sprintf_s(stmt_buf,5000,
                    "SELECT iins_item,sum(mapp_cover),max(fclose) \
                     FROM %s:ca_app_victim \
                     WHERE iclaim = '%s' \
                     GROUP BY iins_item ",clmdbname,iclaim );
			printf(" stmt_buf [%s]\n",stmt_buf);
		}
		strcpy(iins_type_str,"");
		strcpy(fclose_str,"");
		mins_app = 0;
		mins_stl = 0;
		$PREPARE Acursor  FROM $stmt_buf;
		$DECLARE Acursor5 CURSOR FOR Acursor;
		$OPEN Acursor5;
		iins_count_flag = 0;

		while(1)
		{
			$FETCH Acursor5 INTO $iins_type,$mins_app,$fclose1;
			if (SQLCODE == SQLNOTFOUND)
			{
				break;
			}
			if (iins_count_flag > 0)
			{
				strcat(iins_type_str,",");
				strcat(iins_type_str,trim(iins_type));
				strcat(fclose_str,",");
				strcat(fclose_str,trim(fclose1));
			}
			else
			{
				strcat(iins_type_str,trim(iins_type));
				strcat(fclose_str,trim(fclose1));
			}
			mins_app_total += mins_app;
			iins_count_flag ++;

			if (Fcard_class[0]=='2')
			{
				sprintf_s(stmt_buf,5000,
                        "SELECT sum(mins_stl)                    \
                         FROM  %s:stl_ins_type             \
                         WHERE  iclaim = '%s' ",clmdbname,iclaim );
			}
			else
			{
				sprintf_s(stmt_buf,5000,
                        "SELECT sum(mins_stl)                    \
                         FROM  %s:ca_stl_victim             \
                         WHERE  iclaim = '%s' ",clmdbname,iclaim );
			}
			mins_stl = 0;
			$PREPARE curclm2 FROM $stmt_buf;
			$DECLARE curclm22 CURSOR FOR curclm2;
			$OPEN curclm22;
			printf("stmt_buf2==>[%s]\n",stmt_buf);
			/*$EXECUTE curclm2 INTO $mins_stl;*/
			while(1)
			{
				$FETCH curclm22 INTO $mins_stl;
				if (SQLCODE == SQLNOTFOUND)
				{ 
					break;
				}				
			} 
		}
		rc=car910_print();
		if (rc != M_CM_OK)
			return rc;
	}/*End While*/

             EXEC SQL CLOSE Acursor1;
             EXEC SQL FREE Acursor1;
 

 /*  $set explain off;  */
      time(&tstop);
      tused=difftime(tstop,tstart);
      printf("�������=%f��\n",tused);
   
    return M_CM_OK;

   errexit:
   printf("build:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(FAIL);
}

long car910_print()
{
   int ins; 
   char tmp_buf[16];  
   $char nchi_full[15],nname[13],nbranch[41];
   $char officer_nname[13];
   $WHENEVER SQLERROR GOTO errexit;  
   
   $select nchi_full
      into $nchi_full
      from branch
     where ibranch = $iclaim_area;
     
   $select nname
      into $nname
      from officer
     where iofficer = $iadjuster;
   
   $select nbranch
      into $nbranch
      from sa_branch_type
     where ibranch = $iquota;
     
   $select nname
      into $officer_nname
      from officer
     where iofficer = $iofficer;
 
   rgu_put_body_string(2,trim(nchi_full),1);         /* ���z��� */
   rgu_put_body_string(2,iclaim,1);
   rgu_put_body_string(2,trim(nname),1);             /* �z�ߤH�� */
   rgu_put_body_string(2,trim(nbranch),1);           /* �X���� */
   rgu_put_body_string(2,ipolicy,1);
   rgu_put_body_string(2,trim(officer_nname),1);     /* �X��g�� */
   rgu_put_body_string(2,iacc_reason,1);        
   rgu_put_body_string(2,trim(iins_type_str),1);	 /* �I��*/
   
   
   rgu_put_body_string(2,dply_begin,1);
   rgu_put_body_string(2,dpolicy,1);
   rgu_put_body_string(2,daccident,1);
   rgu_put_body_string(2,dclaim,1);
   rgu_put_body_string(2,dclose,1);                  /* �鵲�� */
/*   rgu_put_body_string(2,iendorse,1);     */           /* ��渹�X */
/*   rgu_put_body_string(2,iedr_type,1);    */           /* ������ */
/*   rgu_put_body_string(2,dedr_begin,1);   */           /* ���ͮĤ� */
/*   rgu_put_body_string(2,dendorse,1);     */           /* ���� */
      rfmtlong(mins_app,"-##,###,##&",tmp_buf);     /*** �w�����B ***/
      rgu_put_body_string(2,trim(tmp_buf),1);    
      rfmtlong(mins_stl,"-##,###,##&",tmp_buf);     /*** �ߥI���B ***/
      rgu_put_body_string(2,trim(tmp_buf),1); 
   if(strcmp(nequipment,"1")==0)
   {   
        rgu_put_body_string(2,"��",1);            
   }
   else
   {
        rgu_put_body_string(2,"�L",1);
   }     
   rgu_put_body_string(2,idanger,1);
   rgu_put_body_string(2,trim(fclose_str),1);
   rgu_put_body_string(2,inspect,1);			/*** �վ\�O:1.�ݽվ\,2.���ݽվ\ ***/
   rgu_put_body_string(2,claim_class,1);		/*** �ץ����:1.���`��,2.���`�� ***/
   rgu_put_body_string(2,assign,1);
   
   rgu_put_body(2);
   max_cnt ++;

    return M_CM_OK;
   errexit:
   printf("build:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(FAIL);
}
 
char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
        char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
        char sTmp_db_name[21];

        sTmp_db_name[0]='\0';
        if (*sIpolicy != '\0' && *sIpolicy !=' ')
        {
           sTmp_db_name[0]='\0';
           strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
           strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
                  USE_BRANCH_ID));
           strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
        }
        return sTmp_db_name;
}
  

