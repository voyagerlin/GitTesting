  /**********************************************************************/
/*                                                                    */   
/*   program id   : ca913q01s.ec                                      */
/*   program name : ����¾���z�ߩ��Ӫ�                                */
/*   date written : 2003/12/24                                        */
/*   date modify  :                                                   */
/**********************************************************************/
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
#include <time.h>
#include "safeclib.h"

/*--------------------------------------------------------------------*/
DBinfo  *list;
int  count_db;

$char dbgn1[11],dend1[11];
$char dbgn2[11],dend2[11],dply_begin[20];
$char option[2],ori_iadjuster[11];

 char  tmp_buf[16];
 char p_nbranch[20];
 int count = 0;
 char nequipment_0[2];
 float tused=0;
 time_t tstart,tstop;
 int fetch;
 
 $char iclaim[21],iadjuster_old[11],iadjuster[11],dtrans[11];
 $char buf1[101];
 $char ibranch[3],iupcomp[3],fullname[51];
 $char ipolicy[21],daccident[21],dclaim[21],itag[CA_TAG_NUM],nassured[41];

$char DBName[05], iForm_Tp[03];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1];
char  outputf[N_FILE+1], userid[11];

char  msgbuf[100];
$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;

static int  max_cnt,num;
long car913_get_db();
long car913_build();
void car913_title();
long car913_body();


/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{  
   $WHENEVER SQLERROR GOTO errexit;
   int rc;
   batchinit();
   strcpy(DBName, isNULLstr(argv[1]));
   strcpy(userid, isNULLstr(argv[2]));
   strcpy(option, isNULLstr(argv[3]));
   strcpy(dbgn2, isNULLstr(argv[4]));
   strcpy(dend2, isNULLstr(argv[5]));
   strcpy(ori_iadjuster, isNULLstr(argv[6]));
   strcpy(outputf,isNULLstr(argv[7]));

   strcpy(dbgn1, cm_to_infdate(dbgn2));
   strcpy(dend1, cm_to_infdate(dend2));  
   
   rc = car913_get_db();
    if (rc != SUCCESS)
       return rc;

   max_cnt=0;
   rc = car913_build();
   if ( rc != FAIL){
    if ((rc=save_form_info(F_BLK0, "CA", 913, userid, iForm_Tp, max_cnt, outputf))<0)
     {
        strcpy(msgbuf,"save_form_info failed");
        return rc;
   
     }

   
    }
}
/*--------------------------------------------------------------------*/

long car913_build()
{
   $char  TitleFmt[N_FILE+1],BodyFmt[N_FILE+1];
   int    rc;

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 913;

   strcpy( TitleFmt,rtrim(TitleFmt));
   strcpy( BodyFmt,rtrim(BodyFmt));
   sprintf_s( TitleFile,21,"%s.ti",outputf);
   sprintf_s( BodyFile,21,"%s.bd",outputf);

printf("titlefmt = [%s]\n",TitleFile);

   rgu_init_report(TitleFmt,TitleFile);
   car913_title();
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);
   rc = car913_body();
   if (rc != M_CM_OK)
       return rc;



printf( " next is M_CM_OK \n");           
   return M_CM_OK;

errexit:
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;  
}

   
long car913_get_db()
{
 
   if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }
    
   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   return SUCCESS;

errexit:

   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

void car913_title()
{
  rgu_put_head_string(1," ");
  rgu_put_head_string(1," "); 
 rgu_put_head();

}


long car913_body()
{
   int ins;     
  
 
  $char stmt_buf[1024],stmt[1024],stmp[300];

        
    rgu_put_body_string(1, dbgn1,1);
    rgu_put_body_string(1, dend1,1);
    rgu_put_body_string(1, cm_get_sysd(), 1);
    rgu_put_body(1);
    
 /*   $set explain on;   */
     time(&tstart);
     
     
     
    if(strcmp(option,"0")==0)
    {  sprintf_s(buf1,101,"dtrans >= '%s' and dtrans <= '%s'",dbgn1,dend1);  }
    else
    {   printf(" **************** \n");
    	sprintf_s(buf1,101,"iadjuster_old = '%s' ",ori_iadjuster );     }
    
    printf(" buf1[%s]\n",buf1);
    
    sprintf_s(stmt_buf,1024,"select iclaim,iadjuster_old,iadjuster,dtrans   \
                        from adj_transfer          \
                       where %s                    \
                         and qserial <> 1    ",buf1 );
        printf("stmt[%s]\n",stmt_buf);
        EXEC SQL PREPARE Acursor  FROM :stmt_buf;
        EXEC SQL DECLARE Acursor1 CURSOR FOR Acursor;
        EXEC SQL OPEN Acursor1;
         while (1)
         {

            EXEC SQL FETCH Acursor1 INTO :iclaim,:iadjuster_old,:iadjuster,:dtrans;


            if (SQLCODE == SQLNOTFOUND)
            {   break; }
            
            
            strcpy(ibranch,substring(iclaim,1,2));
            
            $select iupcomp
               into $iupcomp
               from branch
              where ibranch = $ibranch;
              
            strcpy(fullname,get_full_dbname(iupcomp));
            
         sprintf_s(stmt_buf,1024,
          "select a.ipolicy,a.daccident,a.dclaim,b.itag,b.nassured[1,40]  \
             from %s:appraisal a,adjustment_ply b     \
            where a.iclaim = '%s'                       \
              and a.iclaim = b.iclaim ",fullname,iclaim );
            $prepare pre12 from $stmt_buf;
            $execute pre12 into $ipolicy,$daccident,$dclaim,$itag,$nassured;


             rgu_put_body_string(2,iclaim,1);
             rgu_put_body_string(2,ipolicy,1);
             rgu_put_body_string(2,nassured,1);
             rgu_put_body_string(2,itag,1);
             rgu_put_body_string(2,iadjuster_old,1);
             rgu_put_body_string(2,iadjuster,1);
             rgu_put_body_string(2,dtrans,1);
             rgu_put_body_string(2,daccident,1);
             rgu_put_body_string(2,dclaim,1);
            
             rgu_put_body(2);
             count ++;
             max_cnt++;
 
          }/*End While*/
             EXEC SQL CLOSE Acursor1;
             EXEC SQL FREE Acursor1;


 /*  $set explain off;  */
      time(&tstop);
      tused=difftime(tstop,tstart);
      printf("�������=%f��\n",tused);
   
    return M_CM_OK;

   errexit:
   printf("build:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(FAIL);

}
   

